0000790c663ce69b  nop [rax+rax*1], eax
0000790c663ce6a0  vmovaps xmm1, [0x0000790C65FFE010]
0000790c663ce6a8  movq xmm1, xmm1
0000790c663ce6ac  movaps [r15+0x110], xmm1
0000790c663ce6b4  vmovaps xmm1, [0x0000790C65FFE020]
0000790c663ce6bc  movq xmm1, xmm1
0000790c663ce6c0  movaps [r15+0x120], xmm1
0000790c663ce6c8  mov eax, 0x4204C0
0000790c663ce6cd  mov r14, [r13+rax*1]
0000790c663ce6d2  movq xmm1, r14
0000790c663ce6d7  movaps [r15+0x130], xmm1
0000790c663ce6df  vmovaps xmm1, [0x0000790C65FFE030]
0000790c663ce6e7  vpbroadcastq xmm1, xmm1
0000790c663ce6ec  movaps [r15+0x140], xmm1
0000790c663ce6f4  mov qword ptr [r15+0x40], 0x02
0000790c663ce6fc  vmovaps xmm15, [0x0000790C65FFE040]
0000790c663ce704  movq xmm15, xmm15
0000790c663ce709  movaps [r15+0x150], xmm15
0000790c663ce711  mov qword ptr [r15+0x58], 0x420000
0000790c663ce719  vmovaps xmm15, [0x0000790C65FFE050]
0000790c663ce721  vpbroadcastq xmm15, xmm15
0000790c663ce726  movaps [r15+0x160], xmm15
0000790c663ce72e  mov rax, [r15+0x40]
0000790c663ce732  vmovq xmm14, rax
0000790c663ce737  vpbroadcastq xmm14, xmm14
0000790c663ce73c  movaps [r15+0x170], xmm14
0000790c663ce744  mov eax, 0x4204D0
0000790c663ce749  movups xmm13, [r13+rax*1]
0000790c663ce74f  mov qword ptr [r15+0x40], 0x430518
0000790c663ce757  mov qword ptr [r15+0x50], 0x430720
0000790c663ce75f  vpmovqd xmm12, xmm13
0000790c663ce765  pxor xmm11, xmm11
0000790c663ce76a  punpcklqdq xmm12, xmm11
0000790c663ce76f  movaps [r15+0x210], xmm12
0000790c663ce777  movq xmm12, qword ptr [r15+0x120]
0000790c663ce780  movq xmm11, qword ptr [r15+0x130]
0000790c663ce789  psubd xmm12, xmm11
0000790c663ce78e  movq xmm12, xmm12
0000790c663ce793  paddq xmm13, xmm14
0000790c663ce798  movaps [r15+0x180], xmm13
0000790c663ce7a0  movq xmm14, qword ptr [r15+0x150]
0000790c663ce7a9  paddd xmm11, xmm14
0000790c663ce7ae  movq xmm11, xmm11
0000790c663ce7b3  movq xmm11, xmm11
0000790c663ce7b8  movaps [r15+0x130], xmm11
0000790c663ce7c0  pmovzxdq xmm12, xmm12
0000790c663ce7c6  psllq xmm12, 0x00
0000790c663ce7cc  movq xmm14, qword ptr [r15+0x210]
0000790c663ce7d5  movq xmm13, qword ptr [r15+0x110]
0000790c663ce7de  paddd xmm14, xmm13
0000790c663ce7e3  movq xmm14, xmm14
0000790c663ce7e8  vcvtuqq2pd xmm12, xmm12
0000790c663ce7ee  pmovzxdq xmm14, xmm14
0000790c663ce7f4  psllq xmm14, 0x00
0000790c663ce7fa  vcvtuqq2pd xmm14, xmm14
0000790c663ce800  movaps xmm13, xmm12
0000790c663ce804  mulpd xmm13, xmm1
0000790c663ce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000790c663ce80f  ptest xmm11, xmm11
0000790c663ce815  jnz 0x0000790C663CE8FF
0000790c663ce81b  movaps [r15+0x220], xmm13
0000790c663ce823  mov eax, 0x430720
0000790c663ce828  movups [r13+rax*1], xmm13
0000790c663ce82e  movaps xmm1, xmm14
0000790c663ce832  mulpd xmm1, xmm15
0000790c663ce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000790c663ce83c  ptest xmm13, xmm13
0000790c663ce842  jnz 0x0000790C663CEA4C
0000790c663ce848  movaps [r15+0x210], xmm1
0000790c663ce850  mov eax, 0x430518
0000790c663ce855  movups [r13+rax*1], xmm1
0000790c663ce85b  mov qword ptr [r15+0x48], 0x10
0000790c663ce863  xor eax, eax
0000790c663ce865  mov r14d, 0x10
0000790c663ce86b  mov r12d, 0x200
0000790c663ce871  cmp r14, r12
0000790c663ce874  cmc
0000790c663ce875  lahf
0000790c663ce876  seto al
0000790c663ce879  mov [r15+0x108], eax
0000790c663ce880  mov eax, [r15+0x108]
0000790c663ce887  sahf
0000790c663ce888  jnz 0x0000790C663CE8BA
0000790c663ce88a  cmp dword ptr [r15+0x318], 0x00
0000790c663ce892  jz 0x0000790C663CEFF0
0000790c663ce898  nop [rax+rax*1], ax
0000790c663ce8a1  nop [rax+rax*1], eax
0000790c663ce8a9  mov eax, 0x4101EC
0000790c663ce8ae  mov [r15+0x100], rax
0000790c663ce8b5  jmp 0x0000790C661FE110
0000790c663ce8ba  cmp dword ptr [r15+0x318], 0x00
0000790c663ce8c2  jz 0x0000790C663CEBA0
0000790c663ce8c8  nop [rax+rax*1], ax
0000790c663ce8d1  nop [rax+rax*1], eax
0000790c663ce8d9  mov eax, 0x4101AC
0000790c663ce8de  mov [r15+0x100], rax
0000790c663ce8e5  jmp 0x0000790C661FE110
0000790c663ce8ea  int3
0000790c663ce8eb  call 0x0000790C6620DC20
0000790c663ce8f0  jmp 0x0000790C663CE6D2
0000790c663ce8f5  call 0x0000790C6620C260
0000790c663ce8fa  jmp 0x0000790C663CE74F
0000790c663ce8ff  sub rsp, 0x08
0000790c663ce903  push rax
0000790c663ce904  push rcx
0000790c663ce905  push rdx
0000790c663ce906  push rdi
0000790c663ce907  push rsi
0000790c663ce908  push r8
0000790c663ce90a  push r9
0000790c663ce90c  push r10
0000790c663ce90e  push r11
0000790c663ce910  sub rsp, 0xF0
0000790c663ce917  vmovaps [rsp], xmm0
0000790c663ce91c  vmovaps [rsp+0x10], xmm1
0000790c663ce922  vmovaps [rsp+0x20], xmm2
0000790c663ce928  vmovaps [rsp+0x30], xmm3
0000790c663ce92e  vmovaps [rsp+0x40], xmm4
0000790c663ce934  vmovaps [rsp+0x50], xmm5
0000790c663ce93a  vmovaps [rsp+0x60], xmm6
0000790c663ce940  vmovaps [rsp+0x70], xmm7
0000790c663ce946  vmovaps [rsp+0x80], xmm8
0000790c663ce94f  vmovaps [rsp+0x90], xmm9
0000790c663ce958  vmovaps [rsp+0xA0], xmm10
0000790c663ce961  vmovaps [rsp+0xB0], xmm11
0000790c663ce96a  vmovaps [rsp+0xC0], xmm12
0000790c663ce973  vmovaps [rsp+0xD0], xmm14
0000790c663ce97c  vmovaps [rsp+0xE0], xmm15
0000790c663ce985  sub rsp, 0x30
0000790c663ce989  movaps [rsp], xmm13
0000790c663ce98e  movaps [rsp+0x10], xmm12
0000790c663ce994  movaps [rsp+0x20], xmm1
0000790c663ce999  lea rdi, [rsp]
0000790c663ce99d  mov esi, 0x00
0000790c663ce9a2  mov rax, 0x631C1759F530
0000790c663ce9ac  call rax
0000790c663ce9ae  movaps xmm13, [rsp]
0000790c663ce9b3  add rsp, 0x30
0000790c663ce9b7  vmovaps xmm0, [rsp]
0000790c663ce9bc  vmovaps xmm1, [rsp+0x10]
0000790c663ce9c2  vmovaps xmm2, [rsp+0x20]
0000790c663ce9c8  vmovaps xmm3, [rsp+0x30]
0000790c663ce9ce  vmovaps xmm4, [rsp+0x40]
0000790c663ce9d4  vmovaps xmm5, [rsp+0x50]
0000790c663ce9da  vmovaps xmm6, [rsp+0x60]
0000790c663ce9e0  vmovaps xmm7, [rsp+0x70]
0000790c663ce9e6  vmovaps xmm8, [rsp+0x80]
0000790c663ce9ef  vmovaps xmm9, [rsp+0x90]
0000790c663ce9f8  vmovaps xmm10, [rsp+0xA0]
0000790c663cea01  vmovaps xmm11, [rsp+0xB0]
0000790c663cea0a  vmovaps xmm12, [rsp+0xC0]
0000790c663cea13  vmovaps xmm14, [rsp+0xD0]
0000790c663cea1c  vmovaps xmm15, [rsp+0xE0]
0000790c663cea25  add rsp, 0xF0
0000790c663cea2c  pop r11
0000790c663cea2e  pop r10
0000790c663cea30  pop r9
0000790c663cea32  pop r8
0000790c663cea34  pop rsi
0000790c663cea35  pop rdi
0000790c663cea36  pop rdx
0000790c663cea37  pop rcx
0000790c663cea38  pop rax
0000790c663cea39  add rsp, 0x08
0000790c663cea3d  jmp 0x0000790C663CE81B
0000790c663cea42  call 0x0000790C6620C380
0000790c663cea47  jmp 0x0000790C663CE82E
0000790c663cea4c  sub rsp, 0x08
0000790c663cea50  push rax
0000790c663cea51  push rcx
0000790c663cea52  push rdx
0000790c663cea53  push rdi
0000790c663cea54  push rsi
0000790c663cea55  push r8
0000790c663cea57  push r9
0000790c663cea59  push r10
0000790c663cea5b  push r11
0000790c663cea5d  sub rsp, 0xF0
0000790c663cea64  vmovaps [rsp], xmm0
0000790c663cea69  vmovaps [rsp+0x10], xmm2
0000790c663cea6f  vmovaps [rsp+0x20], xmm3
0000790c663cea75  vmovaps [rsp+0x30], xmm4
0000790c663cea7b  vmovaps [rsp+0x40], xmm5
0000790c663cea81  vmovaps [rsp+0x50], xmm6
0000790c663cea87  vmovaps [rsp+0x60], xmm7
0000790c663cea8d  vmovaps [rsp+0x70], xmm8
0000790c663cea93  vmovaps [rsp+0x80], xmm9
0000790c663cea9c  vmovaps [rsp+0x90], xmm10
0000790c663ceaa5  vmovaps [rsp+0xA0], xmm11
0000790c663ceaae  vmovaps [rsp+0xB0], xmm12
0000790c663ceab7  vmovaps [rsp+0xC0], xmm13
0000790c663ceac0  vmovaps [rsp+0xD0], xmm14
0000790c663ceac9  vmovaps [rsp+0xE0], xmm15
0000790c663cead2  sub rsp, 0x30
0000790c663cead6  movaps [rsp], xmm1
0000790c663ceada  movaps [rsp+0x10], xmm14
0000790c663ceae0  movaps [rsp+0x20], xmm15
0000790c663ceae6  lea rdi, [rsp]
0000790c663ceaea  mov esi, 0x00
0000790c663ceaef  mov rax, 0x631C1759F530
0000790c663ceaf9  call rax
0000790c663ceafb  movaps xmm1, [rsp]
0000790c663ceaff  add rsp, 0x30
0000790c663ceb03  vmovaps xmm0, [rsp]
0000790c663ceb08  vmovaps xmm2, [rsp+0x10]
0000790c663ceb0e  vmovaps xmm3, [rsp+0x20]
0000790c663ceb14  vmovaps xmm4, [rsp+0x30]
0000790c663ceb1a  vmovaps xmm5, [rsp+0x40]
0000790c663ceb20  vmovaps xmm6, [rsp+0x50]
0000790c663ceb26  vmovaps xmm7, [rsp+0x60]
0000790c663ceb2c  vmovaps xmm8, [rsp+0x70]
0000790c663ceb32  vmovaps xmm9, [rsp+0x80]
0000790c663ceb3b  vmovaps xmm10, [rsp+0x90]
0000790c663ceb44  vmovaps xmm11, [rsp+0xA0]
0000790c663ceb4d  vmovaps xmm12, [rsp+0xB0]
0000790c663ceb56  vmovaps xmm13, [rsp+0xC0]
0000790c663ceb5f  vmovaps xmm14, [rsp+0xD0]
0000790c663ceb68  vmovaps xmm15, [rsp+0xE0]
0000790c663ceb71  add rsp, 0xF0
0000790c663ceb78  pop r11
0000790c663ceb7a  pop r10
0000790c663ceb7c  pop r9
0000790c663ceb7e  pop r8
0000790c663ceb80  pop rsi
0000790c663ceb81  pop rdi
0000790c663ceb82  pop rdx
0000790c663ceb83  pop rcx
0000790c663ceb84  pop rax
0000790c663ceb85  add rsp, 0x08
0000790c663ceb89  jmp 0x0000790C663CE848
0000790c663ceb8e  call 0x0000790C661FF540
0000790c663ceb93  jmp 0x0000790C663CE85B
0000790c663ceb98  int3
0000790c663ceb99  nop [rax], eax
0000790c663ceba0  movaps xmm1, [r15+0x180]
0000790c663ceba8  vpmovqd xmm15, xmm1
0000790c663cebae  pxor xmm14, xmm14
0000790c663cebb3  punpcklqdq xmm15, xmm14
0000790c663cebb8  movaps [r15+0x210], xmm15
0000790c663cebc0  movq xmm15, qword ptr [r15+0x120]
0000790c663cebc9  movq xmm14, qword ptr [r15+0x130]
0000790c663cebd2  psubd xmm15, xmm14
0000790c663cebd7  movq xmm15, xmm15
0000790c663cebdc  movaps xmm13, [r15+0x170]
0000790c663cebe4  paddq xmm1, xmm13
0000790c663cebe9  movaps [r15+0x180], xmm1
0000790c663cebf1  movq xmm1, qword ptr [r15+0x150]
0000790c663cebfa  paddd xmm14, xmm1
0000790c663cebff  movq xmm14, xmm14
0000790c663cec04  movq xmm14, xmm14
0000790c663cec09  movaps [r15+0x130], xmm14
0000790c663cec11  pmovzxdq xmm15, xmm15
0000790c663cec17  psllq xmm15, 0x00
0000790c663cec1d  movq xmm1, qword ptr [r15+0x210]
0000790c663cec26  movq xmm14, qword ptr [r15+0x110]
0000790c663cec2f  paddd xmm1, xmm14
0000790c663cec34  movq xmm1, xmm1
0000790c663cec38  vcvtuqq2pd xmm15, xmm15
0000790c663cec3e  pmovzxdq xmm1, xmm1
0000790c663cec43  psllq xmm1, 0x00
0000790c663cec48  vcvtuqq2pd xmm1, xmm1
0000790c663cec4e  movaps xmm14, [r15+0x140]
0000790c663cec56  movaps xmm13, xmm15
0000790c663cec5a  mulpd xmm13, xmm14
0000790c663cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000790c663cec65  ptest xmm12, xmm12
0000790c663cec6b  jnz 0x0000790C663CED4E
0000790c663cec71  movaps [r15+0x220], xmm13
0000790c663cec79  mov rax, [r15+0x48]
0000790c663cec7d  mov r14, [r15+0x50]
0000790c663cec81  lea r12, [r14+rax*1]
0000790c663cec85  movups [r13+r12*1], xmm13
0000790c663cec8b  movaps xmm15, [r15+0x160]
0000790c663cec93  movaps xmm14, xmm1
0000790c663cec97  mulpd xmm14, xmm15
0000790c663cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000790c663ceca2  ptest xmm13, xmm13
0000790c663ceca8  jnz 0x0000790C663CEE9C
0000790c663cecae  movaps [r15+0x210], xmm14
0000790c663cecb6  mov r14, [r15+0x40]
0000790c663cecba  lea r12, [r14+rax*1]
0000790c663cecbe  movups [r13+r12*1], xmm14
0000790c663cecc4  lea r14, [rax+0x10]
0000790c663cecc8  mov [r15+0x48], r14
0000790c663ceccc  xor eax, eax
0000790c663cecce  mov r12d, 0x200
0000790c663cecd4  cmp r14, r12
0000790c663cecd7  cmc
0000790c663cecd8  lahf
0000790c663cecd9  seto al
0000790c663cecdc  mov [r15+0x108], eax
0000790c663cece3  mov eax, [r15+0x108]
0000790c663cecea  sahf
0000790c663ceceb  jnz 0x0000790C663CED1D
0000790c663ceced  cmp dword ptr [r15+0x318], 0x00
0000790c663cecf5  jz 0x0000790C663CEFF0
0000790c663cecfb  nop [rax+rax*1], ax
0000790c663ced04  nop [rax+rax*1], eax
0000790c663ced0c  mov eax, 0x4101EC
0000790c663ced11  mov [r15+0x100], rax
0000790c663ced18  jmp 0x0000790C661FE110
0000790c663ced1d  cmp dword ptr [r15+0x318], 0x00
0000790c663ced25  jz 0x0000790C663CEBA0
0000790c663ced2b  nop [rax+rax*1], ax
0000790c663ced34  nop [rax+rax*1], eax
0000790c663ced3c  mov eax, 0x4101AC
0000790c663ced41  mov [r15+0x100], rax
0000790c663ced48  jmp 0x0000790C661FE110
0000790c663ced4d  int3
0000790c663ced4e  sub rsp, 0x08
0000790c663ced52  push rax
0000790c663ced53  push rcx
0000790c663ced54  push rdx
0000790c663ced55  push rdi
0000790c663ced56  push rsi
0000790c663ced57  push r8
0000790c663ced59  push r9
0000790c663ced5b  push r10
0000790c663ced5d  push r11
0000790c663ced5f  sub rsp, 0xF0
0000790c663ced66  vmovaps [rsp], xmm0
0000790c663ced6b  vmovaps [rsp+0x10], xmm1
0000790c663ced71  vmovaps [rsp+0x20], xmm2
0000790c663ced77  vmovaps [rsp+0x30], xmm3
0000790c663ced7d  vmovaps [rsp+0x40], xmm4
0000790c663ced83  vmovaps [rsp+0x50], xmm5
0000790c663ced89  vmovaps [rsp+0x60], xmm6
0000790c663ced8f  vmovaps [rsp+0x70], xmm7
0000790c663ced95  vmovaps [rsp+0x80], xmm8
0000790c663ced9e  vmovaps [rsp+0x90], xmm9
0000790c663ceda7  vmovaps [rsp+0xA0], xmm10
0000790c663cedb0  vmovaps [rsp+0xB0], xmm11
0000790c663cedb9  vmovaps [rsp+0xC0], xmm12
0000790c663cedc2  vmovaps [rsp+0xD0], xmm14
0000790c663cedcb  vmovaps [rsp+0xE0], xmm15
0000790c663cedd4  sub rsp, 0x30
0000790c663cedd8  movaps [rsp], xmm13
0000790c663ceddd  movaps [rsp+0x10], xmm15
0000790c663cede3  movaps [rsp+0x20], xmm14
0000790c663cede9  lea rdi, [rsp]
0000790c663ceded  mov esi, 0x00
0000790c663cedf2  mov rax, 0x631C1759F530
0000790c663cedfc  call rax
0000790c663cedfe  movaps xmm13, [rsp]
0000790c663cee03  add rsp, 0x30
0000790c663cee07  vmovaps xmm0, [rsp]
0000790c663cee0c  vmovaps xmm1, [rsp+0x10]
0000790c663cee12  vmovaps xmm2, [rsp+0x20]
0000790c663cee18  vmovaps xmm3, [rsp+0x30]
0000790c663cee1e  vmovaps xmm4, [rsp+0x40]
0000790c663cee24  vmovaps xmm5, [rsp+0x50]
0000790c663cee2a  vmovaps xmm6, [rsp+0x60]
0000790c663cee30  vmovaps xmm7, [rsp+0x70]
0000790c663cee36  vmovaps xmm8, [rsp+0x80]
0000790c663cee3f  vmovaps xmm9, [rsp+0x90]
0000790c663cee48  vmovaps xmm10, [rsp+0xA0]
0000790c663cee51  vmovaps xmm11, [rsp+0xB0]
0000790c663cee5a  vmovaps xmm12, [rsp+0xC0]
0000790c663cee63  vmovaps xmm14, [rsp+0xD0]
0000790c663cee6c  vmovaps xmm15, [rsp+0xE0]
0000790c663cee75  add rsp, 0xF0
0000790c663cee7c  pop r11
0000790c663cee7e  pop r10
0000790c663cee80  pop r9
0000790c663cee82  pop r8
0000790c663cee84  pop rsi
0000790c663cee85  pop rdi
0000790c663cee86  pop rdx
0000790c663cee87  pop rcx
0000790c663cee88  pop rax
0000790c663cee89  add rsp, 0x08
0000790c663cee8d  jmp 0x0000790C663CEC71
0000790c663cee92  call 0x0000790C662C2240
0000790c663cee97  jmp 0x0000790C663CEC8B
0000790c663cee9c  sub rsp, 0x08
0000790c663ceea0  push rax
0000790c663ceea1  push rcx
0000790c663ceea2  push rdx
0000790c663ceea3  push rdi
0000790c663ceea4  push rsi
0000790c663ceea5  push r8
0000790c663ceea7  push r9
0000790c663ceea9  push r10
0000790c663ceeab  push r11
0000790c663ceead  sub rsp, 0xF0
0000790c663ceeb4  vmovaps [rsp], xmm0
0000790c663ceeb9  vmovaps [rsp+0x10], xmm1
0000790c663ceebf  vmovaps [rsp+0x20], xmm2
0000790c663ceec5  vmovaps [rsp+0x30], xmm3
0000790c663ceecb  vmovaps [rsp+0x40], xmm4
0000790c663ceed1  vmovaps [rsp+0x50], xmm5
0000790c663ceed7  vmovaps [rsp+0x60], xmm6
0000790c663ceedd  vmovaps [rsp+0x70], xmm7
0000790c663ceee3  vmovaps [rsp+0x80], xmm8
0000790c663ceeec  vmovaps [rsp+0x90], xmm9
0000790c663ceef5  vmovaps [rsp+0xA0], xmm10
0000790c663ceefe  vmovaps [rsp+0xB0], xmm11
0000790c663cef07  vmovaps [rsp+0xC0], xmm12
0000790c663cef10  vmovaps [rsp+0xD0], xmm13
0000790c663cef19  vmovaps [rsp+0xE0], xmm15
0000790c663cef22  sub rsp, 0x30
0000790c663cef26  movaps [rsp], xmm14
0000790c663cef2b  movaps [rsp+0x10], xmm1
0000790c663cef30  movaps [rsp+0x20], xmm15
0000790c663cef36  lea rdi, [rsp]
0000790c663cef3a  mov esi, 0x00
0000790c663cef3f  mov rax, 0x631C1759F530
0000790c663cef49  call rax
0000790c663cef4b  movaps xmm14, [rsp]
0000790c663cef50  add rsp, 0x30
0000790c663cef54  vmovaps xmm0, [rsp]
0000790c663cef59  vmovaps xmm1, [rsp+0x10]
0000790c663cef5f  vmovaps xmm2, [rsp+0x20]
0000790c663cef65  vmovaps xmm3, [rsp+0x30]
0000790c663cef6b  vmovaps xmm4, [rsp+0x40]
0000790c663cef71  vmovaps xmm5, [rsp+0x50]
0000790c663cef77  vmovaps xmm6, [rsp+0x60]
0000790c663cef7d  vmovaps xmm7, [rsp+0x70]
0000790c663cef83  vmovaps xmm8, [rsp+0x80]
0000790c663cef8c  vmovaps xmm9, [rsp+0x90]
0000790c663cef95  vmovaps xmm10, [rsp+0xA0]
0000790c663cef9e  vmovaps xmm11, [rsp+0xB0]
0000790c663cefa7  vmovaps xmm12, [rsp+0xC0]
0000790c663cefb0  vmovaps xmm13, [rsp+0xD0]
0000790c663cefb9  vmovaps xmm15, [rsp+0xE0]
0000790c663cefc2  add rsp, 0xF0
0000790c663cefc9  pop r11
0000790c663cefcb  pop r10
0000790c663cefcd  pop r9
0000790c663cefcf  pop r8
0000790c663cefd1  pop rsi
0000790c663cefd2  pop rdi
0000790c663cefd3  pop rdx
0000790c663cefd4  pop rcx
0000790c663cefd5  pop rax
0000790c663cefd6  add rsp, 0x08
0000790c663cefda  jmp 0x0000790C663CECAE
0000790c663cefdf  call 0x0000790C662C34C0
0000790c663cefe4  jmp 0x0000790C663CECC4
0000790c663cefe9  int3
0000790c663cefea  nop [rax+rax*1], ax
0000790c663ceff0  mov rax, [r15+0xF8]
0000790c663ceff7  lea r14, [rax-0x150]
0000790c663ceffe  mov [r15+0xF8], r14
0000790c663cf005  mov rax, [r15+0x50]
0000790c663cf009  lea r12, [rax+0x80]
0000790c663cf010  movups xmm1, [r13+r12*1]
0000790c663cf016  lea r12, [rax+0x90]
0000790c663cf01d  movups xmm15, [r13+r12*1]
0000790c663cf023  mov qword ptr [r15+0x48], 0x00
0000790c663cf02b  lea r12, [rax+0x40]
0000790c663cf02f  movups xmm14, [r13+r12*1]
0000790c663cf035  lea r12, [rax+0x50]
0000790c663cf039  movups xmm13, [r13+r12*1]
0000790c663cf03f  lea r12, [r14+0x120]
0000790c663cf046  movq xmm12, qword ptr [r15+0x1C0]
0000790c663cf04f  movq xmm11, qword ptr [r15+0x1B0]
0000790c663cf058  movq r11, xmm12
0000790c663cf05d  movq r10, xmm11
0000790c663cf062  mov [r13+r12*1], r11
0000790c663cf067  lea r12, [r14+0x128]
0000790c663cf06e  mov [r13+r12*1], r10
0000790c663cf073  vxorps xmm12, xmm12, xmm12
0000790c663cf078  vpbroadcastq xmm12, xmm12
0000790c663cf07d  lea r12, [r14+0x100]
0000790c663cf084  movq xmm11, qword ptr [r15+0x200]
0000790c663cf08d  movq xmm10, qword ptr [r15+0x1F0]
0000790c663cf096  movq r11, xmm11
0000790c663cf09b  movq r10, xmm10
0000790c663cf0a0  mov [r13+r12*1], r11
0000790c663cf0a5  lea r12, [r14+0x108]
0000790c663cf0ac  mov [r13+r12*1], r10
0000790c663cf0b1  lea r12, [r14+0xE0]
0000790c663cf0b8  movups [r13+r12*1], xmm15
0000790c663cf0be  lea r12, [r14+0xF0]
0000790c663cf0c5  movups [r13+r12*1], xmm1
0000790c663cf0cb  lea r12, [rax+0xC0]
0000790c663cf0d2  movups xmm1, [r13+r12*1]
0000790c663cf0d8  lea r12, [rax+0xD0]
0000790c663cf0df  movups xmm15, [r13+r12*1]
0000790c663cf0e5  lea r12, [r14+0x110]
0000790c663cf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000790c663cf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000790c663cf0fe  movq r11, xmm11
0000790c663cf103  movq r10, xmm10
0000790c663cf108  mov [r13+r12*1], r11
0000790c663cf10d  lea r12, [r14+0x118]
0000790c663cf114  mov [r13+r12*1], r10
0000790c663cf119  movups xmm11, [r13+rax*1]
0000790c663cf11f  lea r12, [rax+0x10]
0000790c663cf123  movups xmm10, [r13+r12*1]
0000790c663cf129  lea r12, [r14+0x130]
0000790c663cf130  movq xmm9, qword ptr [r15+0x1A0]
0000790c663cf139  movq xmm8, qword ptr [r15+0x190]
0000790c663cf142  movq r11, xmm9
0000790c663cf147  movq r10, xmm8
0000790c663cf14c  mov [r13+r12*1], r11
0000790c663cf151  lea r12, [r14+0x138]
0000790c663cf158  mov [r13+r12*1], r10
0000790c663cf15d  lea r12, [rax+0x140]
0000790c663cf164  movups xmm9, [r13+r12*1]
0000790c663cf16a  lea r12, [rax+0x150]
0000790c663cf171  movups xmm8, [r13+r12*1]
0000790c663cf177  lea r12, [r14+0xC0]
0000790c663cf17e  movups [r13+r12*1], xmm15
0000790c663cf184  lea r12, [r14+0xD0]
0000790c663cf18b  movups [r13+r12*1], xmm1
0000790c663cf191  lea r12, [rax+0x100]
0000790c663cf198  movups xmm1, [r13+r12*1]
0000790c663cf19e  lea r12, [rax+0x110]
0000790c663cf1a5  movups xmm15, [r13+r12*1]
0000790c663cf1ab  lea r12, [r14+0x140]
0000790c663cf1b2  mov r11, [r15+0xE8]
0000790c663cf1b9  mov [r13+r12*1], r11
0000790c663cf1be  lea r12, [rax+0x180]
0000790c663cf1c5  movups xmm7, [r13+r12*1]
0000790c663cf1cb  lea r12, [rax+0x190]
0000790c663cf1d2  movups xmm6, [r13+r12*1]
0000790c663cf1d8  lea r12, [rax+0x1C0]
0000790c663cf1df  movups xmm5, [r13+r12*1]
0000790c663cf1e5  lea r12, [rax+0x1D0]
0000790c663cf1ec  movups xmm4, [r13+r12*1]
0000790c663cf1f2  lea r12, [r14+0x20]
0000790c663cf1f6  movups [r13+r12*1], xmm1
0000790c663cf1fc  lea r12, [r14+0x30]
0000790c663cf200  movups [r13+r12*1], xmm13
0000790c663cf206  lea r12, [rax+0x60]
0000790c663cf20a  movups xmm1, [r13+r12*1]
0000790c663cf210  lea r12, [rax+0x70]
0000790c663cf214  movups xmm13, [r13+r12*1]
0000790c663cf21a  lea r12, [rax+0x20]
0000790c663cf21e  movups xmm3, [r13+r12*1]
0000790c663cf224  lea r12, [rax+0x30]
0000790c663cf228  movups xmm2, [r13+r12*1]
0000790c663cf22e  movaps [r15+0x1F0], xmm2
0000790c663cf236  lea r12, [r14+0x60]
0000790c663cf23a  movups [r13+r12*1], xmm11
0000790c663cf240  lea r12, [r14+0x70]
0000790c663cf244  movups [r13+r12*1], xmm5
0000790c663cf24a  lea r12, [rax+0xE0]
0000790c663cf251  movups xmm11, [r13+r12*1]
0000790c663cf257  lea r12, [rax+0xF0]
0000790c663cf25e  movups xmm5, [r13+r12*1]
0000790c663cf264  lea r12, [r14+0xA0]
0000790c663cf26b  movups [r13+r12*1], xmm13
0000790c663cf271  lea r12, [r14+0xB0]
0000790c663cf278  movups [r13+r12*1], xmm1
0000790c663cf27e  lea r12, [rax+0xA0]
0000790c663cf285  movups xmm1, [r13+r12*1]
0000790c663cf28b  lea r12, [rax+0xB0]
0000790c663cf292  movups xmm13, [r13+r12*1]
0000790c663cf298  lea r12, [rax+0x120]
0000790c663cf29f  vmovaps [rsp+0x10], xmm1
0000790c663cf2a5  movups xmm1, [r13+r12*1]
0000790c663cf2ab  lea r12, [rax+0x130]
0000790c663cf2b2  vmovaps [rsp+0x20], xmm1
0000790c663cf2b8  movups xmm1, [r13+r12*1]
0000790c663cf2be  lea r12, [rax+0x160]
0000790c663cf2c5  vmovaps [rsp+0x30], xmm1
0000790c663cf2cb  movups xmm1, [r13+r12*1]
0000790c663cf2d1  lea r12, [rax+0x170]
0000790c663cf2d8  vmovaps [rsp+0x40], xmm1
0000790c663cf2de  movups xmm1, [r13+r12*1]
0000790c663cf2e4  movaps [r15+0x2B0], xmm1
0000790c663cf2ec  lea r12, [r14+0x80]
0000790c663cf2f3  movups [r13+r12*1], xmm13
0000790c663cf2f9  lea r12, [r14+0x90]
0000790c663cf300  vmovaps xmm13, [rsp+0x10]
0000790c663cf306  movups [r13+r12*1], xmm13
0000790c663cf30c  lea r12, [rax+0x1A0]
0000790c663cf313  movups xmm13, [r13+r12*1]
0000790c663cf319  lea r12, [rax+0x1B0]
0000790c663cf320  vmovaps [rsp+0x10], xmm1
0000790c663cf326  movups xmm1, [r13+r12*1]
0000790c663cf32c  movaps [r15+0x290], xmm13
0000790c663cf334  movaps [r15+0x1E0], xmm1
0000790c663cf33c  lea r12, [rax+0x1E0]
0000790c663cf343  vmovaps [rsp+0x50], xmm1
0000790c663cf349  movups xmm1, [r13+r12*1]
0000790c663cf34f  lea r12, [rax+0x1F0]
0000790c663cf356  vmovaps [rsp+0x60], xmm1
0000790c663cf35c  movups xmm1, [r13+r12*1]
0000790c663cf362  mov qword ptr [r15+0x50], 0x430920
0000790c663cf36a  lea rax, [r14+0x40]
0000790c663cf36e  vmovaps [rsp+0x70], xmm1
0000790c663cf374  vmovaps xmm1, [rsp+0x40]
0000790c663cf37a  movups [r13+rax*1], xmm1
0000790c663cf380  lea rax, [r14+0x50]
0000790c663cf384  movups [r13+rax*1], xmm10
0000790c663cf38a  vmovaps xmm1, [rsp+0x70]
0000790c663cf390  movups [r13+r14*1], xmm1
0000790c663cf396  lea rax, [r14+0x10]
0000790c663cf39a  vmovaps xmm1, [rsp+0x60]
0000790c663cf3a0  movups [r13+rax*1], xmm1
0000790c663cf3a6  mov rax, [r15+0x40]
0000790c663cf3aa  vmovaps [rsp+0x40], xmm3
0000790c663cf3b0  vmovaps xmm1, [rsp+0x40]
0000790c663cf3b6  por xmm3, xmm1
0000790c663cf3ba  vmovaps [rsp+0x40], xmm6
0000790c663cf3c0  vmovaps xmm10, [rsp+0x40]
0000790c663cf3c6  por xmm6, xmm10
0000790c663cf3cb  lea r12, [rax+0x30]
0000790c663cf3cf  mov r11, [r13+r12*1]
0000790c663cf3d4  lea r12, [rax+0x38]
0000790c663cf3d8  mov r10, [r13+r12*1]
0000790c663cf3dd  movq xmm10, r11
0000790c663cf3e2  vmovaps [rsp+0x40], xmm1
0000790c663cf3e8  movq xmm1, r10
0000790c663cf3ed  movq xmm10, xmm10
0000790c663cf3f2  vmovaps [rsp+0x60], xmm10
0000790c663cf3f8  movq xmm10, xmm10
0000790c663cf3fd  movaps [r15+0x130], xmm10
0000790c663cf405  movq xmm1, xmm1
0000790c663cf409  vmovaps [rsp+0x70], xmm1
0000790c663cf40f  movq xmm1, xmm1
0000790c663cf413  movaps [r15+0x280], xmm1
0000790c663cf41b  vmovaps [rsp+0x80], xmm9
0000790c663cf424  vmovaps xmm1, [rsp+0x80]
0000790c663cf42d  por xmm9, xmm1
0000790c663cf432  lea r12, [rax+0x20]
0000790c663cf436  mov r11, [r13+r12*1]
0000790c663cf43b  lea r12, [rax+0x28]
0000790c663cf43f  mov r10, [r13+r12*1]
0000790c663cf444  movq xmm1, r11
0000790c663cf449  movq xmm10, r10
0000790c663cf44e  movq xmm1, xmm1
0000790c663cf452  vmovaps [rsp+0x80], xmm1
0000790c663cf45b  movq xmm1, xmm1
0000790c663cf45f  movaps [r15+0x150], xmm1
0000790c663cf467  movq xmm10, xmm10
0000790c663cf46c  vmovaps [rsp+0x90], xmm10
0000790c663cf475  movq xmm10, xmm10
0000790c663cf47a  movaps [r15+0x140], xmm10
0000790c663cf482  lea r12, [rax+0x10]
0000790c663cf486  mov r11, [r13+r12*1]
0000790c663cf48b  lea r12, [rax+0x18]
0000790c663cf48f  mov r10, [r13+r12*1]
0000790c663cf494  movq xmm1, r11
0000790c663cf499  movq xmm10, r10
0000790c663cf49e  movq xmm1, xmm1
0000790c663cf4a2  vmovaps [rsp+0xA0], xmm1
0000790c663cf4ab  movq xmm1, xmm1
0000790c663cf4af  movaps [r15+0x170], xmm1
0000790c663cf4b7  movq xmm10, xmm10
0000790c663cf4bc  vmovaps [rsp+0xB0], xmm10
0000790c663cf4c5  movq xmm10, xmm10
0000790c663cf4ca  movaps [r15+0x160], xmm10
0000790c663cf4d2  mov r12, [r13+rax*1]
0000790c663cf4d7  vmovq xmm1, r12
0000790c663cf4dc  vpbroadcastq xmm1, xmm1
0000790c663cf4e1  lea r12, [rax+0x08]
0000790c663cf4e5  mov rax, [r13+r12*1]
0000790c663cf4ea  movq xmm10, rax
0000790c663cf4ef  movaps [r15+0x230], xmm10
0000790c663cf4f7  lea rax, [r14+0x50]
0000790c663cf4fb  movups xmm10, [r13+rax*1]
0000790c663cf501  lea rax, [r14+0x60]
0000790c663cf505  vmovaps [rsp+0xC0], xmm1
0000790c663cf50e  movups xmm1, [r13+rax*1]
0000790c663cf514  lea rax, [r14+0x30]
0000790c663cf518  vmovaps [rsp+0xD0], xmm1
0000790c663cf521  movups xmm1, [r13+rax*1]
0000790c663cf527  mov qword ptr [r15+0x60], 0x430920
0000790c663cf52f  mov qword ptr [r15+0x58], 0x40
0000790c663cf537  vmovaps [rsp+0xE0], xmm1
0000790c663cf540  vmovaps [rsp+0xF0], xmm15
0000790c663cf549  vmovaps xmm15, [rsp+0xC0]
0000790c663cf552  vmovaps [rsp+0xC0], xmm14
0000790c663cf55b  vmovaps xmm14, [rsp+0x40]
0000790c663cf561  vmovaps [rsp+0x40], xmm13
0000790c663cf567  movaps xmm1, xmm15
0000790c663cf56b  mulpd xmm1, xmm14
0000790c663cf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000790c663cf575  ptest xmm13, xmm13
0000790c663cf57b  jnz 0x0000790C663D0682
0000790c663cf581  movq xmm14, qword ptr [r15+0x230]
0000790c663cf58a  vmovaps [rsp+0x100], xmm14
0000790c663cf593  vpermilpd xmm14, xmm14, 0x00
0000790c663cf599  vmovaps [rsp+0x110], xmm1
0000790c663cf5a2  vmovaps xmm1, [rsp+0xE0]
0000790c663cf5ab  vmovaps [rsp+0xE0], xmm15
0000790c663cf5b4  movaps xmm13, xmm1
0000790c663cf5b8  mulpd xmm13, xmm14
0000790c663cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000790c663cf5c3  ptest xmm15, xmm15
0000790c663cf5c9  jnz 0x0000790C663D07C4
0000790c663cf5cf  vxorps xmm1, xmm1, xmm1
0000790c663cf5d3  vpbroadcastq xmm1, xmm1
0000790c663cf5d8  vmovaps xmm14, [rsp+0xE0]
0000790c663cf5e1  vmovaps [rsp+0xE0], xmm1
0000790c663cf5ea  vmovaps xmm1, [rsp+0xD0]
0000790c663cf5f3  vmovaps [rsp+0xD0], xmm13
0000790c663cf5fc  movaps xmm15, xmm14
0000790c663cf600  mulpd xmm15, xmm1
0000790c663cf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000790c663cf60b  ptest xmm13, xmm13
0000790c663cf611  jnz 0x0000790C663D0907
0000790c663cf617  movaps xmm1, xmm14
0000790c663cf61b  mulpd xmm1, xmm10
0000790c663cf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000790c663cf625  ptest xmm13, xmm13
0000790c663cf62b  jnz 0x0000790C663D0A4A
0000790c663cf631  movaps xmm13, xmm14
0000790c663cf635  mulpd xmm13, xmm2
0000790c663cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000790c663cf640  ptest xmm10, xmm10
0000790c663cf646  jnz 0x0000790C663D0B8C
0000790c663cf64c  vmovaps [rsp+0x120], xmm7
0000790c663cf655  vmovaps xmm14, [rsp+0x120]
0000790c663cf65e  por xmm7, xmm14
0000790c663cf663  vmovaps xmm14, [rsp+0xC0]
0000790c663cf66c  vmovaps xmm10, [rsp+0xC0]
0000790c663cf675  por xmm14, xmm10
0000790c663cf67a  vmovaps xmm2, [rsp+0x100]
0000790c663cf683  vpermilpd xmm2, xmm2, 0x00
0000790c663cf689  vmovaps [rsp+0xC0], xmm1
0000790c663cf692  vmovaps [rsp+0x120], xmm15
0000790c663cf69b  movaps xmm1, xmm10
0000790c663cf69f  mulpd xmm1, xmm2
0000790c663cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000790c663cf6a8  ptest xmm15, xmm15
0000790c663cf6ae  jnz 0x0000790C663D0CCF
0000790c663cf6b4  xor eax, eax
0000790c663cf6b6  mov r12d, 0x40
0000790c663cf6bc  mov r11d, 0x200
0000790c663cf6c2  cmp r12, r11
0000790c663cf6c5  cmc
0000790c663cf6c6  lahf
0000790c663cf6c7  seto al
0000790c663cf6ca  mov [r15+0x108], eax
0000790c663cf6d1  vmovaps xmm10, [rsp+0x110]
0000790c663cf6da  vmovaps xmm2, [rsp+0xE0]
0000790c663cf6e3  vmovaps [rsp+0xE0], xmm1
0000790c663cf6ec  movaps xmm15, xmm10
0000790c663cf6f0  addpd xmm15, xmm2
0000790c663cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000790c663cf6fb  ptest xmm1, xmm1
0000790c663cf700  jnz 0x0000790C663D0E10
0000790c663cf706  vmovaps xmm10, [rsp+0x120]
0000790c663cf70f  vmovaps [rsp+0x110], xmm15
0000790c663cf718  movaps xmm1, xmm10
0000790c663cf71c  addpd xmm1, xmm12
0000790c663cf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000790c663cf726  ptest xmm15, xmm15
0000790c663cf72c  jnz 0x0000790C663D0F53
0000790c663cf732  vmovaps xmm10, [rsp+0xC0]
0000790c663cf73b  vmovaps [rsp+0xC0], xmm1
0000790c663cf744  movaps xmm15, xmm10
0000790c663cf748  addpd xmm15, xmm12
0000790c663cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000790c663cf753  ptest xmm1, xmm1
0000790c663cf758  jnz 0x0000790C663D1095
0000790c663cf75e  vmovaps xmm1, [rsp+0x30]
0000790c663cf764  vmovaps xmm12, [rsp+0x30]
0000790c663cf76a  por xmm1, xmm12
0000790c663cf76f  vmovaps xmm12, [rsp+0x20]
0000790c663cf775  vmovaps xmm10, [rsp+0x20]
0000790c663cf77b  por xmm12, xmm10
0000790c663cf780  vmovaps [rsp+0x20], xmm5
0000790c663cf786  vmovaps xmm10, [rsp+0x20]
0000790c663cf78c  por xmm5, xmm10
0000790c663cf791  vmovaps [rsp+0x20], xmm11
0000790c663cf797  vmovaps xmm10, [rsp+0x20]
0000790c663cf79d  por xmm11, xmm10
0000790c663cf7a2  vmovaps [rsp+0x20], xmm4
0000790c663cf7a8  vmovaps xmm10, [rsp+0x20]
0000790c663cf7ae  por xmm4, xmm10
0000790c663cf7b3  vmovaps [rsp+0x20], xmm8
0000790c663cf7b9  vmovaps xmm10, [rsp+0x20]
0000790c663cf7bf  por xmm8, xmm10
0000790c663cf7c4  vmovaps xmm10, [rsp+0xF0]
0000790c663cf7cd  vmovaps [rsp+0x20], xmm1
0000790c663cf7d3  vmovaps xmm1, [rsp+0xF0]
0000790c663cf7dc  por xmm10, xmm1
0000790c663cf7e1  lea rax, [r14+0xA0]
0000790c663cf7e8  movups xmm1, [r13+rax*1]
0000790c663cf7ee  lea rax, [r14+0xB0]
0000790c663cf7f5  vmovaps [rsp+0x30], xmm1
0000790c663cf7fb  movups xmm1, [r13+rax*1]
0000790c663cf801  vmovaps [rsp+0xF0], xmm1
0000790c663cf80a  vmovaps [rsp+0x120], xmm15
0000790c663cf813  movaps xmm1, xmm13
0000790c663cf817  addpd xmm1, xmm2
0000790c663cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000790c663cf820  ptest xmm15, xmm15
0000790c663cf826  jnz 0x0000790C663D11ED
0000790c663cf82c  lea rax, [r14+0xF0]
0000790c663cf833  movups xmm15, [r13+rax*1]
0000790c663cf839  vmovaps xmm2, [rsp+0xC0]
0000790c663cf842  vmovaps [rsp+0xC0], xmm1
0000790c663cf84b  vmovaps xmm1, [rsp+0xE0]
0000790c663cf854  vmovaps [rsp+0xE0], xmm15
0000790c663cf85d  movaps xmm13, xmm2
0000790c663cf861  addpd xmm13, xmm1
0000790c663cf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000790c663cf86c  ptest xmm15, xmm15
0000790c663cf872  jnz 0x0000790C663D1338
0000790c663cf878  vmovaps xmm15, [rsp+0x120]
0000790c663cf881  vmovaps xmm2, [rsp+0xD0]
0000790c663cf88a  vmovaps [rsp+0xD0], xmm14
0000790c663cf893  movaps xmm1, xmm15
0000790c663cf897  addpd xmm1, xmm2
0000790c663cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000790c663cf8a0  ptest xmm14, xmm14
0000790c663cf8a6  jnz 0x0000790C663D147A
0000790c663cf8ac  vmovaps xmm15, [rsp+0x100]
0000790c663cf8b5  vpermilpd xmm15, xmm15, 0x00
0000790c663cf8bb  vmovaps xmm2, [rsp+0xF0]
0000790c663cf8c4  vmovaps [rsp+0xF0], xmm1
0000790c663cf8cd  movaps xmm14, xmm2
0000790c663cf8d1  mulpd xmm14, xmm15
0000790c663cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000790c663cf8dc  ptest xmm1, xmm1
0000790c663cf8e1  jnz 0x0000790C663D15BB
0000790c663cf8e7  vmovaps xmm1, [rsp+0xA0]
0000790c663cf8f0  vpermilpd xmm1, xmm1, 0x00
0000790c663cf8f6  vmovaps xmm2, [rsp+0xE0]
0000790c663cf8ff  vmovaps [rsp+0xE0], xmm14
0000790c663cf908  movaps xmm15, xmm2
0000790c663cf90c  mulpd xmm15, xmm1
0000790c663cf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000790c663cf917  ptest xmm14, xmm14
0000790c663cf91d  jnz 0x0000790C663D16FE
0000790c663cf923  lea rax, [r14+0xE0]
0000790c663cf92a  movups xmm1, [r13+rax*1]
0000790c663cf930  vmovaps xmm14, [rsp+0x100]
0000790c663cf939  vpermilpd xmm14, xmm14, 0x00
0000790c663cf93f  vmovaps [rsp+0x100], xmm1
0000790c663cf948  vmovaps xmm1, [rsp+0x30]
0000790c663cf94e  vmovaps [rsp+0x30], xmm15
0000790c663cf954  movaps xmm2, xmm1
0000790c663cf957  mulpd xmm2, xmm14
0000790c663cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000790c663cf961  ptest xmm15, xmm15
0000790c663cf967  jnz 0x0000790C663D184A
0000790c663cf96d  vmovaps [rsp+0x120], xmm10
0000790c663cf976  vmovaps xmm1, [rsp+0x120]
0000790c663cf97f  por xmm10, xmm1
0000790c663cf984  movaps [r15+0x300], xmm10
0000790c663cf98c  vmovaps [rsp+0x120], xmm8
0000790c663cf995  vmovaps xmm1, [rsp+0x120]
0000790c663cf99e  por xmm8, xmm1
0000790c663cf9a3  movaps [r15+0x190], xmm8
0000790c663cf9ab  vmovaps xmm1, [rsp+0xA0]
0000790c663cf9b4  vpermilpd xmm1, xmm1, 0x00
0000790c663cf9ba  vmovaps xmm14, [rsp+0x100]
0000790c663cf9c3  vmovaps [rsp+0x100], xmm13
0000790c663cf9cc  movaps xmm15, xmm14
0000790c663cf9d0  mulpd xmm15, xmm1
0000790c663cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000790c663cf9db  ptest xmm13, xmm13
0000790c663cf9e1  jnz 0x0000790C663D198B
0000790c663cf9e7  lea rax, [r14+0x90]
0000790c663cf9ee  movups xmm1, [r13+rax*1]
0000790c663cf9f4  vmovaps [rsp+0x120], xmm4
0000790c663cf9fd  vmovaps xmm14, [rsp+0x120]
0000790c663cfa06  por xmm4, xmm14
0000790c663cfa0b  movaps [r15+0x1C0], xmm4
0000790c663cfa13  vmovaps [rsp+0x120], xmm11
0000790c663cfa1c  vmovaps xmm14, [rsp+0x120]
0000790c663cfa25  por xmm11, xmm14
0000790c663cfa2a  movaps [r15+0x200], xmm11
0000790c663cfa32  vmovaps [rsp+0x120], xmm5
0000790c663cfa3b  vmovaps xmm14, [rsp+0x120]
0000790c663cfa44  por xmm5, xmm14
0000790c663cfa49  movaps [r15+0x2D0], xmm5
0000790c663cfa51  vmovaps [rsp+0x120], xmm12
0000790c663cfa5a  vmovaps xmm14, [rsp+0x120]
0000790c663cfa63  por xmm12, xmm14
0000790c663cfa68  movaps [r15+0x2E0], xmm12
0000790c663cfa70  vmovaps xmm13, [rsp+0x110]
0000790c663cfa79  vmovaps [rsp+0x110], xmm1
0000790c663cfa82  vmovaps xmm1, [rsp+0xE0]
0000790c663cfa8b  vmovaps [rsp+0xE0], xmm15
0000790c663cfa94  movaps xmm14, xmm13
0000790c663cfa98  addpd xmm14, xmm1
0000790c663cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000790c663cfaa3  ptest xmm15, xmm15
0000790c663cfaa9  jnz 0x0000790C663D1AD8
0000790c663cfaaf  vmovaps xmm1, [rsp+0xA0]
0000790c663cfab8  vpermilpd xmm1, xmm1, 0x00
0000790c663cfabe  vmovaps xmm13, [rsp+0x110]
0000790c663cfac7  vmovaps [rsp+0x110], xmm14
0000790c663cfad0  movaps xmm15, xmm13
0000790c663cfad4  mulpd xmm15, xmm1
0000790c663cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000790c663cfadf  ptest xmm14, xmm14
0000790c663cfae5  jnz 0x0000790C663D1C1B
0000790c663cfaeb  lea rax, [r14+0x80]
0000790c663cfaf2  movups xmm1, [r13+rax*1]
0000790c663cfaf8  vmovaps xmm13, [rsp+0xC0]
0000790c663cfb01  vmovaps [rsp+0xC0], xmm1
0000790c663cfb0a  movaps xmm14, xmm13
0000790c663cfb0e  addpd xmm14, xmm2
0000790c663cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000790c663cfb19  ptest xmm1, xmm1
0000790c663cfb1e  jnz 0x0000790C663D1D68
0000790c663cfb24  vmovaps xmm13, [rsp+0x100]
0000790c663cfb2d  vmovaps xmm2, [rsp+0x30]
0000790c663cfb33  vmovaps [rsp+0x30], xmm15
0000790c663cfb39  movaps xmm1, xmm13
0000790c663cfb3d  addpd xmm1, xmm2
0000790c663cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000790c663cfb46  ptest xmm15, xmm15
0000790c663cfb4c  jnz 0x0000790C663D1EAB
0000790c663cfb52  vmovaps xmm15, [rsp+0x20]
0000790c663cfb58  vmovaps xmm13, [rsp+0x20]
0000790c663cfb5e  por xmm15, xmm13
0000790c663cfb63  movaps [r15+0x2F0], xmm15
0000790c663cfb6b  vmovaps xmm13, [rsp+0xA0]
0000790c663cfb74  vpermilpd xmm13, xmm13, 0x00
0000790c663cfb7a  vmovaps [rsp+0x20], xmm1
0000790c663cfb80  vmovaps xmm1, [rsp+0xC0]
0000790c663cfb89  vmovaps [rsp+0xA0], xmm15
0000790c663cfb92  movaps xmm2, xmm1
0000790c663cfb95  mulpd xmm2, xmm13
0000790c663cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000790c663cfb9f  ptest xmm15, xmm15
0000790c663cfba5  jnz 0x0000790C663D1FEC
0000790c663cfbab  lea rax, [r14+0xD0]
0000790c663cfbb2  movups xmm1, [r13+rax*1]
0000790c663cfbb8  vmovaps xmm13, [rsp+0xF0]
0000790c663cfbc1  vmovaps [rsp+0xC0], xmm1
0000790c663cfbca  vmovaps xmm1, [rsp+0xE0]
0000790c663cfbd3  vmovaps [rsp+0xE0], xmm14
0000790c663cfbdc  movaps xmm15, xmm13
0000790c663cfbe0  addpd xmm15, xmm1
0000790c663cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000790c663cfbeb  ptest xmm14, xmm14
0000790c663cfbf1  jnz 0x0000790C663D2137
0000790c663cfbf7  vmovaps xmm1, [rsp+0xB0]
0000790c663cfc00  vpermilpd xmm1, xmm1, 0x00
0000790c663cfc06  movaps xmm14, xmm11
0000790c663cfc0a  mulpd xmm14, xmm1
0000790c663cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000790c663cfc15  ptest xmm13, xmm13
0000790c663cfc1b  jnz 0x0000790C663D227A
0000790c663cfc21  movaps [r15+0x260], xmm14
0000790c663cfc29  vxorps xmm1, xmm1, xmm1
0000790c663cfc2d  vpbroadcastq xmm1, xmm1
0000790c663cfc32  movaps [r15+0x1B0], xmm1
0000790c663cfc3a  vmovaps xmm1, [rsp+0xB0]
0000790c663cfc43  vpermilpd xmm1, xmm1, 0x00
0000790c663cfc49  vmovaps xmm11, [rsp+0xC0]
0000790c663cfc52  vmovaps [rsp+0xC0], xmm15
0000790c663cfc5b  movaps xmm13, xmm11
0000790c663cfc5f  mulpd xmm13, xmm1
0000790c663cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000790c663cfc6a  ptest xmm15, xmm15
0000790c663cfc70  jnz 0x0000790C663D23BD
0000790c663cfc76  lea rax, [r14+0xC0]
0000790c663cfc7d  movups xmm1, [r13+rax*1]
0000790c663cfc83  vmovaps xmm11, [rsp+0x110]
0000790c663cfc8c  vmovaps [rsp+0xF0], xmm1
0000790c663cfc95  vmovaps xmm1, [rsp+0x30]
0000790c663cfc9b  vmovaps [rsp+0x30], xmm14
0000790c663cfca1  movaps xmm15, xmm11
0000790c663cfca5  addpd xmm15, xmm1
0000790c663cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000790c663cfcb0  ptest xmm14, xmm14
0000790c663cfcb6  jnz 0x0000790C663D250A
0000790c663cfcbc  vmovaps [rsp+0x100], xmm9
0000790c663cfcc5  vmovaps xmm1, [rsp+0x100]
0000790c663cfcce  por xmm9, xmm1
0000790c663cfcd3  movaps [r15+0x270], xmm9
0000790c663cfcdb  vmovaps [rsp+0x100], xmm6
0000790c663cfce4  vmovaps xmm1, [rsp+0x100]
0000790c663cfced  por xmm6, xmm1
0000790c663cfcf1  movaps [r15+0x1A0], xmm6
0000790c663cfcf9  vmovaps xmm14, [rsp+0xB0]
0000790c663cfd02  vpermilpd xmm14, xmm14, 0x00
0000790c663cfd08  vmovaps xmm6, [rsp+0xF0]
0000790c663cfd11  vmovaps [rsp+0xF0], xmm1
0000790c663cfd1a  movaps xmm11, xmm6
0000790c663cfd1e  mulpd xmm11, xmm14
0000790c663cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000790c663cfd29  ptest xmm1, xmm1
0000790c663cfd2e  jnz 0x0000790C663D264D
0000790c663cfd34  lea rax, [r14+0x20]
0000790c663cfd38  movups xmm1, [r13+rax*1]
0000790c663cfd3e  movaps [r15+0x110], xmm1
0000790c663cfd46  vmovaps xmm6, [rsp+0xE0]
0000790c663cfd4f  vmovaps [rsp+0xE0], xmm1
0000790c663cfd58  movaps xmm14, xmm6
0000790c663cfd5c  addpd xmm14, xmm2
0000790c663cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000790c663cfd67  ptest xmm1, xmm1
0000790c663cfd6c  jnz 0x0000790C663D279A
0000790c663cfd72  vmovaps xmm1, [rsp+0xB0]
0000790c663cfd7b  vpermilpd xmm1, xmm1, 0x00
0000790c663cfd81  movaps xmm6, xmm5
0000790c663cfd84  mulpd xmm6, xmm1
0000790c663cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000790c663cfd8d  ptest xmm2, xmm2
0000790c663cfd92  jnz 0x0000790C663D28DC
0000790c663cfd98  vmovaps xmm5, [rsp+0x20]
0000790c663cfd9e  movaps xmm1, xmm5
0000790c663cfda1  addpd xmm1, xmm13
0000790c663cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000790c663cfdab  ptest xmm2, xmm2
0000790c663cfdb0  jnz 0x0000790C663D2A1C
0000790c663cfdb6  vmovaps xmm13, [rsp+0x80]
0000790c663cfdbf  vpermilpd xmm13, xmm13, 0x00
0000790c663cfdc5  vmovaps xmm2, [rsp+0xE0]
0000790c663cfdce  vmovaps [rsp+0x20], xmm1
0000790c663cfdd4  movaps xmm5, xmm2
0000790c663cfdd7  mulpd xmm5, xmm13
0000790c663cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000790c663cfde1  ptest xmm1, xmm1
0000790c663cfde6  jnz 0x0000790C663D2B5D
0000790c663cfdec  vmovaps xmm1, [rsp+0x80]
0000790c663cfdf5  vpermilpd xmm1, xmm1, 0x00
0000790c663cfdfb  movaps xmm13, xmm10
0000790c663cfdff  mulpd xmm13, xmm1
0000790c663cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000790c663cfe0a  ptest xmm2, xmm2
0000790c663cfe0f  jnz 0x0000790C663D2C9E
0000790c663cfe15  vmovaps xmm10, [rsp+0x30]
0000790c663cfe1b  movaps xmm1, xmm15
0000790c663cfe1f  addpd xmm1, xmm10
0000790c663cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000790c663cfe29  ptest xmm2, xmm2
0000790c663cfe2e  jnz 0x0000790C663D2DE1
0000790c663cfe34  vmovaps xmm10, [rsp+0xC0]
0000790c663cfe3d  movaps xmm15, xmm10
0000790c663cfe41  addpd xmm15, xmm11
0000790c663cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000790c663cfe4c  ptest xmm2, xmm2
0000790c663cfe51  jnz 0x0000790C663D2F23
0000790c663cfe57  vmovaps xmm11, [rsp+0x80]
0000790c663cfe60  vpermilpd xmm11, xmm11, 0x00
0000790c663cfe66  movaps xmm10, xmm12
0000790c663cfe6a  mulpd xmm10, xmm11
0000790c663cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000790c663cfe75  ptest xmm2, xmm2
0000790c663cfe7a  jnz 0x0000790C663D3067
0000790c663cfe80  vmovaps xmm12, [rsp+0x80]
0000790c663cfe89  vpermilpd xmm12, xmm12, 0x00
0000790c663cfe8f  vmovaps xmm2, [rsp+0xA0]
0000790c663cfe98  vmovaps [rsp+0x30], xmm1
0000790c663cfe9e  movaps xmm11, xmm2
0000790c663cfea2  mulpd xmm11, xmm12
0000790c663cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000790c663cfead  ptest xmm1, xmm1
0000790c663cfeb2  jnz 0x0000790C663D31AB
0000790c663cfeb8  movaps xmm1, xmm14
0000790c663cfebc  addpd xmm1, xmm6
0000790c663cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000790c663cfec5  ptest xmm12, xmm12
0000790c663cfecb  jnz 0x0000790C663D32EE
0000790c663cfed1  vmovaps xmm12, [rsp+0x20]
0000790c663cfed7  movaps xmm14, xmm12
0000790c663cfedb  addpd xmm14, xmm5
0000790c663cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000790c663cfee6  ptest xmm6, xmm6
0000790c663cfeeb  jnz 0x0000790C663D342F
0000790c663cfef1  vmovaps xmm12, [rsp+0x90]
0000790c663cfefa  vpermilpd xmm12, xmm12, 0x00
0000790c663cff00  movaps xmm6, xmm9
0000790c663cff04  mulpd xmm6, xmm12
0000790c663cff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000790c663cff0e  ptest xmm5, xmm5
0000790c663cff13  jnz 0x0000790C663D3572
0000790c663cff19  movaps xmm12, xmm15
0000790c663cff1d  addpd xmm12, xmm13
0000790c663cff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000790c663cff28  ptest xmm9, xmm9
0000790c663cff2e  jnz 0x0000790C663D36B4
0000790c663cff34  vmovaps xmm13, [rsp+0x30]
0000790c663cff3a  movaps xmm15, xmm13
0000790c663cff3e  addpd xmm15, xmm10
0000790c663cff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000790c663cff49  ptest xmm9, xmm9
0000790c663cff4f  jnz 0x0000790C663D37F8
0000790c663cff55  vmovaps xmm13, [rsp+0xD0]
0000790c663cff5e  vmovaps xmm10, [rsp+0xD0]
0000790c663cff67  por xmm13, xmm10
0000790c663cff6c  movaps [r15+0x250], xmm13
0000790c663cff74  vmovaps [rsp+0x20], xmm7
0000790c663cff7a  vmovaps xmm13, [rsp+0x20]
0000790c663cff80  por xmm7, xmm13
0000790c663cff85  movaps [r15+0x2A0], xmm7
0000790c663cff8d  vmovaps [rsp+0x20], xmm3
0000790c663cff93  vmovaps xmm13, [rsp+0x20]
0000790c663cff99  por xmm3, xmm13
0000790c663cff9e  movaps [r15+0x1D0], xmm3
0000790c663cffa6  lea rax, [r14+0x40]
0000790c663cffaa  movups xmm13, [r13+rax*1]
0000790c663cffb0  movaps [r15+0x2C0], xmm13
0000790c663cffb8  vmovaps xmm10, [rsp+0x90]
0000790c663cffc1  vpermilpd xmm10, xmm10, 0x00
0000790c663cffc7  movaps xmm9, xmm8
0000790c663cffcb  mulpd xmm9, xmm10
0000790c663cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000790c663cffd6  ptest xmm5, xmm5
0000790c663cffdb  jnz 0x0000790C663D3946
0000790c663cffe1  movaps xmm10, xmm1
0000790c663cffe5  addpd xmm10, xmm11
0000790c663cffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000790c663cfff0  ptest xmm8, xmm8
0000790c663cfff6  jnz 0x0000790C663D3A8A
0000790c663cfffc  movaps xmm1, xmm14
0000790c663d0000  addpd xmm1, xmm6
0000790c663d0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000790c663d0009  ptest xmm11, xmm11
0000790c663d000f  jnz 0x0000790C663D3BCD
0000790c663d0015  vmovaps xmm14, [rsp+0x90]
0000790c663d001e  vpermilpd xmm14, xmm14, 0x00
0000790c663d0024  movaps xmm11, xmm13
0000790c663d0028  mulpd xmm11, xmm14
0000790c663d002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000790c663d0033  ptest xmm8, xmm8
0000790c663d0039  jnz 0x0000790C663D3D0E
0000790c663d003f  vmovaps xmm14, [rsp+0x90]
0000790c663d0048  vpermilpd xmm14, xmm14, 0x00
0000790c663d004e  vmovaps xmm8, [rsp+0x10]
0000790c663d0054  movaps xmm13, xmm8
0000790c663d0058  mulpd xmm13, xmm14
0000790c663d005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000790c663d0063  ptest xmm6, xmm6
0000790c663d0068  jnz 0x0000790C663D3E52
0000790c663d006e  vmovaps xmm14, [rsp+0x60]
0000790c663d0074  vpermilpd xmm14, xmm14, 0x00
0000790c663d007a  movaps xmm8, xmm7
0000790c663d007e  mulpd xmm8, xmm14
0000790c663d0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000790c663d0089  ptest xmm6, xmm6
0000790c663d008e  jnz 0x0000790C663D3F96
0000790c663d0094  movaps xmm14, xmm12
0000790c663d0098  addpd xmm14, xmm9
0000790c663d009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000790c663d00a3  ptest xmm7, xmm7
0000790c663d00a8  jnz 0x0000790C663D40D9
0000790c663d00ae  vmovaps xmm12, [rsp+0x60]
0000790c663d00b4  vpermilpd xmm12, xmm12, 0x00
0000790c663d00ba  vmovaps xmm7, [rsp+0xF0]
0000790c663d00c3  movaps xmm9, xmm7
0000790c663d00c7  mulpd xmm9, xmm12
0000790c663d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000790c663d00d2  ptest xmm6, xmm6
0000790c663d00d7  jnz 0x0000790C663D421D
0000790c663d00dd  movaps xmm12, xmm15
0000790c663d00e1  addpd xmm12, xmm11
0000790c663d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000790c663d00ec  ptest xmm7, xmm7
0000790c663d00f1  jnz 0x0000790C663D4360
0000790c663d00f7  vmovaps xmm15, [rsp+0x60]
0000790c663d00fd  vpermilpd xmm15, xmm15, 0x00
0000790c663d0103  vmovaps xmm7, [rsp+0x40]
0000790c663d0109  movaps xmm11, xmm7
0000790c663d010d  mulpd xmm11, xmm15
0000790c663d0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000790c663d0118  ptest xmm6, xmm6
0000790c663d011d  jnz 0x0000790C663D44A4
0000790c663d0123  movaps xmm15, xmm10
0000790c663d0127  addpd xmm15, xmm13
0000790c663d012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000790c663d0132  ptest xmm7, xmm7
0000790c663d0137  jnz 0x0000790C663D45E7
0000790c663d013d  vmovaps xmm13, [rsp+0x60]
0000790c663d0143  vpermilpd xmm13, xmm13, 0x00
0000790c663d0149  vmovaps xmm7, [rsp+0x50]
0000790c663d014f  movaps xmm10, xmm7
0000790c663d0153  mulpd xmm10, xmm13
0000790c663d0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000790c663d015e  ptest xmm6, xmm6
0000790c663d0163  jnz 0x0000790C663D472B
0000790c663d0169  movaps xmm13, xmm1
0000790c663d016d  addpd xmm13, xmm8
0000790c663d0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000790c663d0178  ptest xmm7, xmm7
0000790c663d017d  jnz 0x0000790C663D486E
0000790c663d0183  lea rax, [r14+0x70]
0000790c663d0187  movups xmm1, [r13+rax*1]
0000790c663d018d  movaps [r15+0x240], xmm1
0000790c663d0195  movaps xmm8, xmm14
0000790c663d0199  addpd xmm8, xmm9
0000790c663d019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000790c663d01a4  ptest xmm7, xmm7
0000790c663d01a9  jnz 0x0000790C663D49BB
0000790c663d01af  movaps [r15+0x170], xmm8
0000790c663d01b7  vmovaps xmm14, [rsp+0x70]
0000790c663d01bd  vpermilpd xmm14, xmm14, 0x00
0000790c663d01c3  movaps xmm9, xmm1
0000790c663d01c7  mulpd xmm9, xmm14
0000790c663d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000790c663d01d2  ptest xmm7, xmm7
0000790c663d01d7  jnz 0x0000790C663D4AFF
0000790c663d01dd  vmovaps xmm1, [rsp+0x70]
0000790c663d01e3  vpermilpd xmm1, xmm1, 0x00
0000790c663d01e9  movaps xmm14, xmm4
0000790c663d01ed  mulpd xmm14, xmm1
0000790c663d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000790c663d01f8  ptest xmm7, xmm7
0000790c663d01fd  jnz 0x0000790C663D4C42
0000790c663d0203  movaps [r15+0x180], xmm14
0000790c663d020b  movaps xmm1, xmm12
0000790c663d020f  addpd xmm1, xmm11
0000790c663d0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000790c663d0219  ptest xmm7, xmm7
0000790c663d021e  jnz 0x0000790C663D4D84
0000790c663d0224  movaps [r15+0x210], xmm1
0000790c663d022c  movups xmm12, [r13+r14*1]
0000790c663d0232  lea rax, [r14+0x10]
0000790c663d0236  movups xmm11, [r13+rax*1]
0000790c663d023c  movaps [r15+0x230], xmm11
0000790c663d0244  movaps xmm7, xmm15
0000790c663d0248  addpd xmm7, xmm10
0000790c663d024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000790c663d0252  ptest xmm6, xmm6
0000790c663d0257  jnz 0x0000790C663D4EDA
0000790c663d025d  movaps [r15+0x130], xmm7
0000790c663d0265  vmovaps xmm15, [rsp+0x70]
0000790c663d026b  vpermilpd xmm15, xmm15, 0x00
0000790c663d0271  movaps xmm10, xmm11
0000790c663d0275  mulpd xmm10, xmm15
0000790c663d027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000790c663d0280  ptest xmm6, xmm6
0000790c663d0285  jnz 0x0000790C663D501C
0000790c663d028b  movaps [r15+0x220], xmm10
0000790c663d0293  vmovaps xmm15, [rsp+0x70]
0000790c663d0299  vpermilpd xmm15, xmm15, 0x00
0000790c663d029f  movaps xmm11, xmm12
0000790c663d02a3  mulpd xmm11, xmm15
0000790c663d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000790c663d02ae  ptest xmm6, xmm6
0000790c663d02b3  jnz 0x0000790C663D5160
0000790c663d02b9  movaps xmm15, xmm13
0000790c663d02bd  addpd xmm15, xmm9
0000790c663d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000790c663d02c8  ptest xmm12, xmm12
0000790c663d02ce  jnz 0x0000790C663D52A4
0000790c663d02d4  movaps [r15+0x140], xmm15
0000790c663d02dc  movaps xmm13, xmm8
0000790c663d02e0  addpd xmm13, xmm14
0000790c663d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000790c663d02eb  ptest xmm12, xmm12
0000790c663d02f1  jnz 0x0000790C663D53E8
0000790c663d02f7  movaps [r15+0x150], xmm13
0000790c663d02ff  movaps xmm14, xmm1
0000790c663d0303  addpd xmm14, xmm10
0000790c663d0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000790c663d030e  ptest xmm12, xmm12
0000790c663d0314  jnz 0x0000790C663D552C
0000790c663d031a  movaps [r15+0x160], xmm14
0000790c663d0322  movaps xmm1, xmm7
0000790c663d0325  addpd xmm1, xmm11
0000790c663d032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000790c663d032f  ptest xmm12, xmm12
0000790c663d0335  jnz 0x0000790C663D566F
0000790c663d033b  movaps [r15+0x120], xmm1
0000790c663d0343  mov eax, 0x430920
0000790c663d0348  movups [r13+rax*1], xmm15
0000790c663d034e  mov eax, 0x430930
0000790c663d0353  movups [r13+rax*1], xmm13
0000790c663d0359  mov eax, 0x430940
0000790c663d035e  movups [r13+rax*1], xmm14
0000790c663d0364  mov eax, 0x430950
0000790c663d0369  movups [r13+rax*1], xmm1
0000790c663d036f  mov eax, [r15+0x108]
0000790c663d0376  sahf
0000790c663d0377  jnz 0x0000790C663D03A9
0000790c663d0379  cmp dword ptr [r15+0x318], 0x00
0000790c663d0381  jz 0x0000790C663DB900
0000790c663d0387  nop [rax+rax*1], ax
0000790c663d0390  nop [rax+rax*1], eax
0000790c663d0398  mov eax, 0x410444
0000790c663d039d  mov [r15+0x100], rax
0000790c663d03a4  jmp 0x0000790C661FE110
0000790c663d03a9  cmp dword ptr [r15+0x318], 0x00
0000790c663d03b1  jz 0x0000790C663D57E0
0000790c663d03b7  nop [rax+rax*1], ax
0000790c663d03c0  nop [rax+rax*1], eax
0000790c663d03c8  mov eax, 0x410278
0000790c663d03cd  mov [r15+0x100], rax
0000790c663d03d4  jmp 0x0000790C661FE110
0000790c663d03d9  int3
0000790c663d03da  call 0x0000790C662B52F0
0000790c663d03df  jmp 0x0000790C663CF016
0000790c663d03e4  call 0x0000790C662C4620
0000790c663d03e9  jmp 0x0000790C663CF023
0000790c663d03ee  call 0x0000790C662C33A0
0000790c663d03f3  jmp 0x0000790C663CF035
0000790c663d03f8  call 0x0000790C662C2120
0000790c663d03fd  jmp 0x0000790C663CF03F
0000790c663d0402  call 0x0000790C662C0860
0000790c663d0407  jmp 0x0000790C663CF067
0000790c663d040c  call 0x0000790C662BF5F0
0000790c663d0411  jmp 0x0000790C663CF073
0000790c663d0416  call 0x0000790C662C0860
0000790c663d041b  jmp 0x0000790C663CF0A5
0000790c663d0420  call 0x0000790C662BF5F0
0000790c663d0425  jmp 0x0000790C663CF0B1
0000790c663d042a  call 0x0000790C662C4740
0000790c663d042f  jmp 0x0000790C663CF0BE
0000790c663d0434  call 0x0000790C662B5400
0000790c663d0439  jmp 0x0000790C663CF0CB
0000790c663d043e  call 0x0000790C662B52F0
0000790c663d0443  jmp 0x0000790C663CF0D8
0000790c663d0448  call 0x0000790C662C4620
0000790c663d044d  jmp 0x0000790C663CF0E5
0000790c663d0452  call 0x0000790C662C0860
0000790c663d0457  jmp 0x0000790C663CF10D
0000790c663d045c  call 0x0000790C662BF5F0
0000790c663d0461  jmp 0x0000790C663CF119
0000790c663d0466  call 0x0000790C66209D70
0000790c663d046b  jmp 0x0000790C663CF11F
0000790c663d0470  call 0x0000790C662BE9C0
0000790c663d0475  jmp 0x0000790C663CF129
0000790c663d047a  call 0x0000790C662C0860
0000790c663d047f  jmp 0x0000790C663CF151
0000790c663d0484  call 0x0000790C662BF5F0
0000790c663d0489  jmp 0x0000790C663CF15D
0000790c663d048e  call 0x0000790C662BD750
0000790c663d0493  jmp 0x0000790C663CF16A
0000790c663d0498  call 0x0000790C662BC4E0
0000790c663d049d  jmp 0x0000790C663CF177
0000790c663d04a2  call 0x0000790C662C4740
0000790c663d04a7  jmp 0x0000790C663CF184
0000790c663d04ac  call 0x0000790C662B5400
0000790c663d04b1  jmp 0x0000790C663CF191
0000790c663d04b6  call 0x0000790C662B52F0
0000790c663d04bb  jmp 0x0000790C663CF19E
0000790c663d04c0  call 0x0000790C662C4620
0000790c663d04c5  jmp 0x0000790C663CF1AB
0000790c663d04ca  call 0x0000790C662C0860
0000790c663d04cf  jmp 0x0000790C663CF1BE
0000790c663d04d4  call 0x0000790C662BB270
0000790c663d04d9  jmp 0x0000790C663CF1CB
0000790c663d04de  call 0x0000790C662BA000
0000790c663d04e3  jmp 0x0000790C663CF1D8
0000790c663d04e8  call 0x0000790C662B8D90
0000790c663d04ed  jmp 0x0000790C663CF1E5
0000790c663d04f2  call 0x0000790C662B8A20
0000790c663d04f7  jmp 0x0000790C663CF1F2
0000790c663d04fc  call 0x0000790C662B5400
0000790c663d0501  jmp 0x0000790C663CF1FC
0000790c663d0506  call 0x0000790C662C2240
0000790c663d050b  jmp 0x0000790C663CF206
0000790c663d0510  call 0x0000790C662B52F0
0000790c663d0515  jmp 0x0000790C663CF210
0000790c663d051a  call 0x0000790C662C2120
0000790c663d051f  jmp 0x0000790C663CF21A
0000790c663d0524  call 0x0000790C662B77B0
0000790c663d0529  jmp 0x0000790C663CF224
0000790c663d052e  call 0x0000790C662B6550
0000790c663d0533  jmp 0x0000790C663CF22E
0000790c663d0538  call 0x0000790C662BFD50
0000790c663d053d  jmp 0x0000790C663CF240
0000790c663d0542  call 0x0000790C662B8EA0
0000790c663d0547  jmp 0x0000790C663CF24A
0000790c663d054c  call 0x0000790C662BFC30
0000790c663d0551  jmp 0x0000790C663CF257
0000790c663d0556  call 0x0000790C662B8D90
0000790c663d055b  jmp 0x0000790C663CF264
0000790c663d0560  call 0x0000790C662C2240
0000790c663d0565  jmp 0x0000790C663CF271
0000790c663d056a  call 0x0000790C662B5400
0000790c663d056f  jmp 0x0000790C663CF27E
0000790c663d0574  call 0x0000790C662B52F0
0000790c663d0579  jmp 0x0000790C663CF28B
0000790c663d057e  call 0x0000790C662C2120
0000790c663d0583  jmp 0x0000790C663CF298
0000790c663d0588  call 0x0000790C662B52F0
0000790c663d058d  jmp 0x0000790C663CF2AB
0000790c663d0592  call 0x0000790C662B52F0
0000790c663d0597  jmp 0x0000790C663CF2BE
0000790c663d059c  call 0x0000790C662B52F0
0000790c663d05a1  jmp 0x0000790C663CF2D1
0000790c663d05a6  call 0x0000790C662B52F0
0000790c663d05ab  jmp 0x0000790C663CF2E4
0000790c663d05b0  call 0x0000790C662C2240
0000790c663d05b5  jmp 0x0000790C663CF2F9
0000790c663d05ba  call 0x0000790C662C2240
0000790c663d05bf  jmp 0x0000790C663CF30C
0000790c663d05c4  call 0x0000790C662C2120
0000790c663d05c9  jmp 0x0000790C663CF319
0000790c663d05ce  call 0x0000790C662B52F0
0000790c663d05d3  jmp 0x0000790C663CF32C
0000790c663d05d8  call 0x0000790C662B52F0
0000790c663d05dd  jmp 0x0000790C663CF34F
0000790c663d05e2  call 0x0000790C662B52F0
0000790c663d05e7  jmp 0x0000790C663CF362
0000790c663d05ec  call 0x0000790C661FF540
0000790c663d05f1  jmp 0x0000790C663CF380
0000790c663d05f6  call 0x0000790C66208C20
0000790c663d05fb  jmp 0x0000790C663CF38A
0000790c663d0600  call 0x0000790C662D6600
0000790c663d0605  jmp 0x0000790C663CF396
0000790c663d060a  call 0x0000790C661FF540
0000790c663d060f  jmp 0x0000790C663CF3A6
0000790c663d0614  call 0x0000790C662C0370
0000790c663d0619  jmp 0x0000790C663CF3D4
0000790c663d061e  call 0x0000790C662BF100
0000790c663d0623  jmp 0x0000790C663CF3DD
0000790c663d0628  call 0x0000790C662C0370
0000790c663d062d  jmp 0x0000790C663CF43B
0000790c663d0632  call 0x0000790C662BF100
0000790c663d0637  jmp 0x0000790C663CF444
0000790c663d063c  call 0x0000790C662C0370
0000790c663d0641  jmp 0x0000790C663CF48B
0000790c663d0646  call 0x0000790C662BF100
0000790c663d064b  jmp 0x0000790C663CF494
0000790c663d0650  call 0x0000790C6620B720
0000790c663d0655  jmp 0x0000790C663CF4D7
0000790c663d065a  call 0x0000790C662B47C0
0000790c663d065f  jmp 0x0000790C663CF4EA
0000790c663d0664  call 0x0000790C66208B00
0000790c663d0669  jmp 0x0000790C663CF501
0000790c663d066e  call 0x0000790C661FF430
0000790c663d0673  jmp 0x0000790C663CF514
0000790c663d0678  call 0x0000790C661FF430
0000790c663d067d  jmp 0x0000790C663CF527
0000790c663d0682  sub rsp, 0x08
0000790c663d0686  push rax
0000790c663d0687  push rcx
0000790c663d0688  push rdx
0000790c663d0689  push rdi
0000790c663d068a  push rsi
0000790c663d068b  push r8
0000790c663d068d  push r9
0000790c663d068f  push r10
0000790c663d0691  push r11
0000790c663d0693  sub rsp, 0xF0
0000790c663d069a  vmovaps [rsp], xmm0
0000790c663d069f  vmovaps [rsp+0x10], xmm2
0000790c663d06a5  vmovaps [rsp+0x20], xmm3
0000790c663d06ab  vmovaps [rsp+0x30], xmm4
0000790c663d06b1  vmovaps [rsp+0x40], xmm5
0000790c663d06b7  vmovaps [rsp+0x50], xmm6
0000790c663d06bd  vmovaps [rsp+0x60], xmm7
0000790c663d06c3  vmovaps [rsp+0x70], xmm8
0000790c663d06c9  vmovaps [rsp+0x80], xmm9
0000790c663d06d2  vmovaps [rsp+0x90], xmm10
0000790c663d06db  vmovaps [rsp+0xA0], xmm11
0000790c663d06e4  vmovaps [rsp+0xB0], xmm12
0000790c663d06ed  vmovaps [rsp+0xC0], xmm13
0000790c663d06f6  vmovaps [rsp+0xD0], xmm14
0000790c663d06ff  vmovaps [rsp+0xE0], xmm15
0000790c663d0708  sub rsp, 0x30
0000790c663d070c  movaps [rsp], xmm1
0000790c663d0710  movaps [rsp+0x10], xmm15
0000790c663d0716  movaps [rsp+0x20], xmm14
0000790c663d071c  lea rdi, [rsp]
0000790c663d0720  mov esi, 0x00
0000790c663d0725  mov rax, 0x631C1759F530
0000790c663d072f  call rax
0000790c663d0731  movaps xmm1, [rsp]
0000790c663d0735  add rsp, 0x30
0000790c663d0739  vmovaps xmm0, [rsp]
0000790c663d073e  vmovaps xmm2, [rsp+0x10]
0000790c663d0744  vmovaps xmm3, [rsp+0x20]
0000790c663d074a  vmovaps xmm4, [rsp+0x30]
0000790c663d0750  vmovaps xmm5, [rsp+0x40]
0000790c663d0756  vmovaps xmm6, [rsp+0x50]
0000790c663d075c  vmovaps xmm7, [rsp+0x60]
0000790c663d0762  vmovaps xmm8, [rsp+0x70]
0000790c663d0768  vmovaps xmm9, [rsp+0x80]
0000790c663d0771  vmovaps xmm10, [rsp+0x90]
0000790c663d077a  vmovaps xmm11, [rsp+0xA0]
0000790c663d0783  vmovaps xmm12, [rsp+0xB0]
0000790c663d078c  vmovaps xmm13, [rsp+0xC0]
0000790c663d0795  vmovaps xmm14, [rsp+0xD0]
0000790c663d079e  vmovaps xmm15, [rsp+0xE0]
0000790c663d07a7  add rsp, 0xF0
0000790c663d07ae  pop r11
0000790c663d07b0  pop r10
0000790c663d07b2  pop r9
0000790c663d07b4  pop r8
0000790c663d07b6  pop rsi
0000790c663d07b7  pop rdi
0000790c663d07b8  pop rdx
0000790c663d07b9  pop rcx
0000790c663d07ba  pop rax
0000790c663d07bb  add rsp, 0x08
0000790c663d07bf  jmp 0x0000790C663CF581
0000790c663d07c4  sub rsp, 0x08
0000790c663d07c8  push rax
0000790c663d07c9  push rcx
0000790c663d07ca  push rdx
0000790c663d07cb  push rdi
0000790c663d07cc  push rsi
0000790c663d07cd  push r8
0000790c663d07cf  push r9
0000790c663d07d1  push r10
0000790c663d07d3  push r11
0000790c663d07d5  sub rsp, 0xF0
0000790c663d07dc  vmovaps [rsp], xmm0
0000790c663d07e1  vmovaps [rsp+0x10], xmm1
0000790c663d07e7  vmovaps [rsp+0x20], xmm2
0000790c663d07ed  vmovaps [rsp+0x30], xmm3
0000790c663d07f3  vmovaps [rsp+0x40], xmm4
0000790c663d07f9  vmovaps [rsp+0x50], xmm5
0000790c663d07ff  vmovaps [rsp+0x60], xmm6
0000790c663d0805  vmovaps [rsp+0x70], xmm7
0000790c663d080b  vmovaps [rsp+0x80], xmm8
0000790c663d0814  vmovaps [rsp+0x90], xmm9
0000790c663d081d  vmovaps [rsp+0xA0], xmm10
0000790c663d0826  vmovaps [rsp+0xB0], xmm11
0000790c663d082f  vmovaps [rsp+0xC0], xmm12
0000790c663d0838  vmovaps [rsp+0xD0], xmm14
0000790c663d0841  vmovaps [rsp+0xE0], xmm15
0000790c663d084a  sub rsp, 0x30
0000790c663d084e  movaps [rsp], xmm13
0000790c663d0853  movaps [rsp+0x10], xmm1
0000790c663d0858  movaps [rsp+0x20], xmm14
0000790c663d085e  lea rdi, [rsp]
0000790c663d0862  mov esi, 0x00
0000790c663d0867  mov rax, 0x631C1759F530
0000790c663d0871  call rax
0000790c663d0873  movaps xmm13, [rsp]
0000790c663d0878  add rsp, 0x30
0000790c663d087c  vmovaps xmm0, [rsp]
0000790c663d0881  vmovaps xmm1, [rsp+0x10]
0000790c663d0887  vmovaps xmm2, [rsp+0x20]
0000790c663d088d  vmovaps xmm3, [rsp+0x30]
0000790c663d0893  vmovaps xmm4, [rsp+0x40]
0000790c663d0899  vmovaps xmm5, [rsp+0x50]
0000790c663d089f  vmovaps xmm6, [rsp+0x60]
0000790c663d08a5  vmovaps xmm7, [rsp+0x70]
0000790c663d08ab  vmovaps xmm8, [rsp+0x80]
0000790c663d08b4  vmovaps xmm9, [rsp+0x90]
0000790c663d08bd  vmovaps xmm10, [rsp+0xA0]
0000790c663d08c6  vmovaps xmm11, [rsp+0xB0]
0000790c663d08cf  vmovaps xmm12, [rsp+0xC0]
0000790c663d08d8  vmovaps xmm14, [rsp+0xD0]
0000790c663d08e1  vmovaps xmm15, [rsp+0xE0]
0000790c663d08ea  add rsp, 0xF0
0000790c663d08f1  pop r11
0000790c663d08f3  pop r10
0000790c663d08f5  pop r9
0000790c663d08f7  pop r8
0000790c663d08f9  pop rsi
0000790c663d08fa  pop rdi
0000790c663d08fb  pop rdx
0000790c663d08fc  pop rcx
0000790c663d08fd  pop rax
0000790c663d08fe  add rsp, 0x08
0000790c663d0902  jmp 0x0000790C663CF5CF
0000790c663d0907  sub rsp, 0x08
0000790c663d090b  push rax
0000790c663d090c  push rcx
0000790c663d090d  push rdx
0000790c663d090e  push rdi
0000790c663d090f  push rsi
0000790c663d0910  push r8
0000790c663d0912  push r9
0000790c663d0914  push r10
0000790c663d0916  push r11
0000790c663d0918  sub rsp, 0xF0
0000790c663d091f  vmovaps [rsp], xmm0
0000790c663d0924  vmovaps [rsp+0x10], xmm1
0000790c663d092a  vmovaps [rsp+0x20], xmm2
0000790c663d0930  vmovaps [rsp+0x30], xmm3
0000790c663d0936  vmovaps [rsp+0x40], xmm4
0000790c663d093c  vmovaps [rsp+0x50], xmm5
0000790c663d0942  vmovaps [rsp+0x60], xmm6
0000790c663d0948  vmovaps [rsp+0x70], xmm7
0000790c663d094e  vmovaps [rsp+0x80], xmm8
0000790c663d0957  vmovaps [rsp+0x90], xmm9
0000790c663d0960  vmovaps [rsp+0xA0], xmm10
0000790c663d0969  vmovaps [rsp+0xB0], xmm11
0000790c663d0972  vmovaps [rsp+0xC0], xmm12
0000790c663d097b  vmovaps [rsp+0xD0], xmm13
0000790c663d0984  vmovaps [rsp+0xE0], xmm14
0000790c663d098d  sub rsp, 0x30
0000790c663d0991  movaps [rsp], xmm15
0000790c663d0996  movaps [rsp+0x10], xmm14
0000790c663d099c  movaps [rsp+0x20], xmm1
0000790c663d09a1  lea rdi, [rsp]
0000790c663d09a5  mov esi, 0x00
0000790c663d09aa  mov rax, 0x631C1759F530
0000790c663d09b4  call rax
0000790c663d09b6  movaps xmm15, [rsp]
0000790c663d09bb  add rsp, 0x30
0000790c663d09bf  vmovaps xmm0, [rsp]
0000790c663d09c4  vmovaps xmm1, [rsp+0x10]
0000790c663d09ca  vmovaps xmm2, [rsp+0x20]
0000790c663d09d0  vmovaps xmm3, [rsp+0x30]
0000790c663d09d6  vmovaps xmm4, [rsp+0x40]
0000790c663d09dc  vmovaps xmm5, [rsp+0x50]
0000790c663d09e2  vmovaps xmm6, [rsp+0x60]
0000790c663d09e8  vmovaps xmm7, [rsp+0x70]
0000790c663d09ee  vmovaps xmm8, [rsp+0x80]
0000790c663d09f7  vmovaps xmm9, [rsp+0x90]
0000790c663d0a00  vmovaps xmm10, [rsp+0xA0]
0000790c663d0a09  vmovaps xmm11, [rsp+0xB0]
0000790c663d0a12  vmovaps xmm12, [rsp+0xC0]
0000790c663d0a1b  vmovaps xmm13, [rsp+0xD0]
0000790c663d0a24  vmovaps xmm14, [rsp+0xE0]
0000790c663d0a2d  add rsp, 0xF0
0000790c663d0a34  pop r11
0000790c663d0a36  pop r10
0000790c663d0a38  pop r9
0000790c663d0a3a  pop r8
0000790c663d0a3c  pop rsi
0000790c663d0a3d  pop rdi
0000790c663d0a3e  pop rdx
0000790c663d0a3f  pop rcx
0000790c663d0a40  pop rax
0000790c663d0a41  add rsp, 0x08
0000790c663d0a45  jmp 0x0000790C663CF617
0000790c663d0a4a  sub rsp, 0x08
0000790c663d0a4e  push rax
0000790c663d0a4f  push rcx
0000790c663d0a50  push rdx
0000790c663d0a51  push rdi
0000790c663d0a52  push rsi
0000790c663d0a53  push r8
0000790c663d0a55  push r9
0000790c663d0a57  push r10
0000790c663d0a59  push r11
0000790c663d0a5b  sub rsp, 0xF0
0000790c663d0a62  vmovaps [rsp], xmm0
0000790c663d0a67  vmovaps [rsp+0x10], xmm2
0000790c663d0a6d  vmovaps [rsp+0x20], xmm3
0000790c663d0a73  vmovaps [rsp+0x30], xmm4
0000790c663d0a79  vmovaps [rsp+0x40], xmm5
0000790c663d0a7f  vmovaps [rsp+0x50], xmm6
0000790c663d0a85  vmovaps [rsp+0x60], xmm7
0000790c663d0a8b  vmovaps [rsp+0x70], xmm8
0000790c663d0a91  vmovaps [rsp+0x80], xmm9
0000790c663d0a9a  vmovaps [rsp+0x90], xmm10
0000790c663d0aa3  vmovaps [rsp+0xA0], xmm11
0000790c663d0aac  vmovaps [rsp+0xB0], xmm12
0000790c663d0ab5  vmovaps [rsp+0xC0], xmm13
0000790c663d0abe  vmovaps [rsp+0xD0], xmm14
0000790c663d0ac7  vmovaps [rsp+0xE0], xmm15
0000790c663d0ad0  sub rsp, 0x30
0000790c663d0ad4  movaps [rsp], xmm1
0000790c663d0ad8  movaps [rsp+0x10], xmm14
0000790c663d0ade  movaps [rsp+0x20], xmm10
0000790c663d0ae4  lea rdi, [rsp]
0000790c663d0ae8  mov esi, 0x00
0000790c663d0aed  mov rax, 0x631C1759F530
0000790c663d0af7  call rax
0000790c663d0af9  movaps xmm1, [rsp]
0000790c663d0afd  add rsp, 0x30
0000790c663d0b01  vmovaps xmm0, [rsp]
0000790c663d0b06  vmovaps xmm2, [rsp+0x10]
0000790c663d0b0c  vmovaps xmm3, [rsp+0x20]
0000790c663d0b12  vmovaps xmm4, [rsp+0x30]
0000790c663d0b18  vmovaps xmm5, [rsp+0x40]
0000790c663d0b1e  vmovaps xmm6, [rsp+0x50]
0000790c663d0b24  vmovaps xmm7, [rsp+0x60]
0000790c663d0b2a  vmovaps xmm8, [rsp+0x70]
0000790c663d0b30  vmovaps xmm9, [rsp+0x80]
0000790c663d0b39  vmovaps xmm10, [rsp+0x90]
0000790c663d0b42  vmovaps xmm11, [rsp+0xA0]
0000790c663d0b4b  vmovaps xmm12, [rsp+0xB0]
0000790c663d0b54  vmovaps xmm13, [rsp+0xC0]
0000790c663d0b5d  vmovaps xmm14, [rsp+0xD0]
0000790c663d0b66  vmovaps xmm15, [rsp+0xE0]
0000790c663d0b6f  add rsp, 0xF0
0000790c663d0b76  pop r11
0000790c663d0b78  pop r10
0000790c663d0b7a  pop r9
0000790c663d0b7c  pop r8
0000790c663d0b7e  pop rsi
0000790c663d0b7f  pop rdi
0000790c663d0b80  pop rdx
0000790c663d0b81  pop rcx
0000790c663d0b82  pop rax
0000790c663d0b83  add rsp, 0x08
0000790c663d0b87  jmp 0x0000790C663CF631
0000790c663d0b8c  sub rsp, 0x08
0000790c663d0b90  push rax
0000790c663d0b91  push rcx
0000790c663d0b92  push rdx
0000790c663d0b93  push rdi
0000790c663d0b94  push rsi
0000790c663d0b95  push r8
0000790c663d0b97  push r9
0000790c663d0b99  push r10
0000790c663d0b9b  push r11
0000790c663d0b9d  sub rsp, 0xF0
0000790c663d0ba4  vmovaps [rsp], xmm0
0000790c663d0ba9  vmovaps [rsp+0x10], xmm1
0000790c663d0baf  vmovaps [rsp+0x20], xmm2
0000790c663d0bb5  vmovaps [rsp+0x30], xmm3
0000790c663d0bbb  vmovaps [rsp+0x40], xmm4
0000790c663d0bc1  vmovaps [rsp+0x50], xmm5
0000790c663d0bc7  vmovaps [rsp+0x60], xmm6
0000790c663d0bcd  vmovaps [rsp+0x70], xmm7
0000790c663d0bd3  vmovaps [rsp+0x80], xmm8
0000790c663d0bdc  vmovaps [rsp+0x90], xmm9
0000790c663d0be5  vmovaps [rsp+0xA0], xmm10
0000790c663d0bee  vmovaps [rsp+0xB0], xmm11
0000790c663d0bf7  vmovaps [rsp+0xC0], xmm12
0000790c663d0c00  vmovaps [rsp+0xD0], xmm14
0000790c663d0c09  vmovaps [rsp+0xE0], xmm15
0000790c663d0c12  sub rsp, 0x30
0000790c663d0c16  movaps [rsp], xmm13
0000790c663d0c1b  movaps [rsp+0x10], xmm14
0000790c663d0c21  movaps [rsp+0x20], xmm2
0000790c663d0c26  lea rdi, [rsp]
0000790c663d0c2a  mov esi, 0x00
0000790c663d0c2f  mov rax, 0x631C1759F530
0000790c663d0c39  call rax
0000790c663d0c3b  movaps xmm13, [rsp]
0000790c663d0c40  add rsp, 0x30
0000790c663d0c44  vmovaps xmm0, [rsp]
0000790c663d0c49  vmovaps xmm1, [rsp+0x10]
0000790c663d0c4f  vmovaps xmm2, [rsp+0x20]
0000790c663d0c55  vmovaps xmm3, [rsp+0x30]
0000790c663d0c5b  vmovaps xmm4, [rsp+0x40]
0000790c663d0c61  vmovaps xmm5, [rsp+0x50]
0000790c663d0c67  vmovaps xmm6, [rsp+0x60]
0000790c663d0c6d  vmovaps xmm7, [rsp+0x70]
0000790c663d0c73  vmovaps xmm8, [rsp+0x80]
0000790c663d0c7c  vmovaps xmm9, [rsp+0x90]
0000790c663d0c85  vmovaps xmm10, [rsp+0xA0]
0000790c663d0c8e  vmovaps xmm11, [rsp+0xB0]
0000790c663d0c97  vmovaps xmm12, [rsp+0xC0]
0000790c663d0ca0  vmovaps xmm14, [rsp+0xD0]
0000790c663d0ca9  vmovaps xmm15, [rsp+0xE0]
0000790c663d0cb2  add rsp, 0xF0
0000790c663d0cb9  pop r11
0000790c663d0cbb  pop r10
0000790c663d0cbd  pop r9
0000790c663d0cbf  pop r8
0000790c663d0cc1  pop rsi
0000790c663d0cc2  pop rdi
0000790c663d0cc3  pop rdx
0000790c663d0cc4  pop rcx
0000790c663d0cc5  pop rax
0000790c663d0cc6  add rsp, 0x08
0000790c663d0cca  jmp 0x0000790C663CF64C
0000790c663d0ccf  sub rsp, 0x08
0000790c663d0cd3  push rax
0000790c663d0cd4  push rcx
0000790c663d0cd5  push rdx
0000790c663d0cd6  push rdi
0000790c663d0cd7  push rsi
0000790c663d0cd8  push r8
0000790c663d0cda  push r9
0000790c663d0cdc  push r10
0000790c663d0cde  push r11
0000790c663d0ce0  sub rsp, 0xF0
0000790c663d0ce7  vmovaps [rsp], xmm0
0000790c663d0cec  vmovaps [rsp+0x10], xmm2
0000790c663d0cf2  vmovaps [rsp+0x20], xmm3
0000790c663d0cf8  vmovaps [rsp+0x30], xmm4
0000790c663d0cfe  vmovaps [rsp+0x40], xmm5
0000790c663d0d04  vmovaps [rsp+0x50], xmm6
0000790c663d0d0a  vmovaps [rsp+0x60], xmm7
0000790c663d0d10  vmovaps [rsp+0x70], xmm8
0000790c663d0d16  vmovaps [rsp+0x80], xmm9
0000790c663d0d1f  vmovaps [rsp+0x90], xmm10
0000790c663d0d28  vmovaps [rsp+0xA0], xmm11
0000790c663d0d31  vmovaps [rsp+0xB0], xmm12
0000790c663d0d3a  vmovaps [rsp+0xC0], xmm13
0000790c663d0d43  vmovaps [rsp+0xD0], xmm14
0000790c663d0d4c  vmovaps [rsp+0xE0], xmm15
0000790c663d0d55  sub rsp, 0x30
0000790c663d0d59  movaps [rsp], xmm1
0000790c663d0d5d  movaps [rsp+0x10], xmm10
0000790c663d0d63  movaps [rsp+0x20], xmm2
0000790c663d0d68  lea rdi, [rsp]
0000790c663d0d6c  mov esi, 0x00
0000790c663d0d71  mov rax, 0x631C1759F530
0000790c663d0d7b  call rax
0000790c663d0d7d  movaps xmm1, [rsp]
0000790c663d0d81  add rsp, 0x30
0000790c663d0d85  vmovaps xmm0, [rsp]
0000790c663d0d8a  vmovaps xmm2, [rsp+0x10]
0000790c663d0d90  vmovaps xmm3, [rsp+0x20]
0000790c663d0d96  vmovaps xmm4, [rsp+0x30]
0000790c663d0d9c  vmovaps xmm5, [rsp+0x40]
0000790c663d0da2  vmovaps xmm6, [rsp+0x50]
0000790c663d0da8  vmovaps xmm7, [rsp+0x60]
0000790c663d0dae  vmovaps xmm8, [rsp+0x70]
0000790c663d0db4  vmovaps xmm9, [rsp+0x80]
0000790c663d0dbd  vmovaps xmm10, [rsp+0x90]
0000790c663d0dc6  vmovaps xmm11, [rsp+0xA0]
0000790c663d0dcf  vmovaps xmm12, [rsp+0xB0]
0000790c663d0dd8  vmovaps xmm13, [rsp+0xC0]
0000790c663d0de1  vmovaps xmm14, [rsp+0xD0]
0000790c663d0dea  vmovaps xmm15, [rsp+0xE0]
0000790c663d0df3  add rsp, 0xF0
0000790c663d0dfa  pop r11
0000790c663d0dfc  pop r10
0000790c663d0dfe  pop r9
0000790c663d0e00  pop r8
0000790c663d0e02  pop rsi
0000790c663d0e03  pop rdi
0000790c663d0e04  pop rdx
0000790c663d0e05  pop rcx
0000790c663d0e06  pop rax
0000790c663d0e07  add rsp, 0x08
0000790c663d0e0b  jmp 0x0000790C663CF6B4
0000790c663d0e10  sub rsp, 0x08
0000790c663d0e14  push rax
0000790c663d0e15  push rcx
0000790c663d0e16  push rdx
0000790c663d0e17  push rdi
0000790c663d0e18  push rsi
0000790c663d0e19  push r8
0000790c663d0e1b  push r9
0000790c663d0e1d  push r10
0000790c663d0e1f  push r11
0000790c663d0e21  sub rsp, 0xF0
0000790c663d0e28  vmovaps [rsp], xmm0
0000790c663d0e2d  vmovaps [rsp+0x10], xmm1
0000790c663d0e33  vmovaps [rsp+0x20], xmm2
0000790c663d0e39  vmovaps [rsp+0x30], xmm3
0000790c663d0e3f  vmovaps [rsp+0x40], xmm4
0000790c663d0e45  vmovaps [rsp+0x50], xmm5
0000790c663d0e4b  vmovaps [rsp+0x60], xmm6
0000790c663d0e51  vmovaps [rsp+0x70], xmm7
0000790c663d0e57  vmovaps [rsp+0x80], xmm8
0000790c663d0e60  vmovaps [rsp+0x90], xmm9
0000790c663d0e69  vmovaps [rsp+0xA0], xmm10
0000790c663d0e72  vmovaps [rsp+0xB0], xmm11
0000790c663d0e7b  vmovaps [rsp+0xC0], xmm12
0000790c663d0e84  vmovaps [rsp+0xD0], xmm13
0000790c663d0e8d  vmovaps [rsp+0xE0], xmm14
0000790c663d0e96  sub rsp, 0x30
0000790c663d0e9a  movaps [rsp], xmm15
0000790c663d0e9f  movaps [rsp+0x10], xmm10
0000790c663d0ea5  movaps [rsp+0x20], xmm2
0000790c663d0eaa  lea rdi, [rsp]
0000790c663d0eae  mov esi, 0x00
0000790c663d0eb3  mov rax, 0x631C1759F530
0000790c663d0ebd  call rax
0000790c663d0ebf  movaps xmm15, [rsp]
0000790c663d0ec4  add rsp, 0x30
0000790c663d0ec8  vmovaps xmm0, [rsp]
0000790c663d0ecd  vmovaps xmm1, [rsp+0x10]
0000790c663d0ed3  vmovaps xmm2, [rsp+0x20]
0000790c663d0ed9  vmovaps xmm3, [rsp+0x30]
0000790c663d0edf  vmovaps xmm4, [rsp+0x40]
0000790c663d0ee5  vmovaps xmm5, [rsp+0x50]
0000790c663d0eeb  vmovaps xmm6, [rsp+0x60]
0000790c663d0ef1  vmovaps xmm7, [rsp+0x70]
0000790c663d0ef7  vmovaps xmm8, [rsp+0x80]
0000790c663d0f00  vmovaps xmm9, [rsp+0x90]
0000790c663d0f09  vmovaps xmm10, [rsp+0xA0]
0000790c663d0f12  vmovaps xmm11, [rsp+0xB0]
0000790c663d0f1b  vmovaps xmm12, [rsp+0xC0]
0000790c663d0f24  vmovaps xmm13, [rsp+0xD0]
0000790c663d0f2d  vmovaps xmm14, [rsp+0xE0]
0000790c663d0f36  add rsp, 0xF0
0000790c663d0f3d  pop r11
0000790c663d0f3f  pop r10
0000790c663d0f41  pop r9
0000790c663d0f43  pop r8
0000790c663d0f45  pop rsi
0000790c663d0f46  pop rdi
0000790c663d0f47  pop rdx
0000790c663d0f48  pop rcx
0000790c663d0f49  pop rax
0000790c663d0f4a  add rsp, 0x08
0000790c663d0f4e  jmp 0x0000790C663CF706
0000790c663d0f53  sub rsp, 0x08
0000790c663d0f57  push rax
0000790c663d0f58  push rcx
0000790c663d0f59  push rdx
0000790c663d0f5a  push rdi
0000790c663d0f5b  push rsi
0000790c663d0f5c  push r8
0000790c663d0f5e  push r9
0000790c663d0f60  push r10
0000790c663d0f62  push r11
0000790c663d0f64  sub rsp, 0xF0
0000790c663d0f6b  vmovaps [rsp], xmm0
0000790c663d0f70  vmovaps [rsp+0x10], xmm2
0000790c663d0f76  vmovaps [rsp+0x20], xmm3
0000790c663d0f7c  vmovaps [rsp+0x30], xmm4
0000790c663d0f82  vmovaps [rsp+0x40], xmm5
0000790c663d0f88  vmovaps [rsp+0x50], xmm6
0000790c663d0f8e  vmovaps [rsp+0x60], xmm7
0000790c663d0f94  vmovaps [rsp+0x70], xmm8
0000790c663d0f9a  vmovaps [rsp+0x80], xmm9
0000790c663d0fa3  vmovaps [rsp+0x90], xmm10
0000790c663d0fac  vmovaps [rsp+0xA0], xmm11
0000790c663d0fb5  vmovaps [rsp+0xB0], xmm12
0000790c663d0fbe  vmovaps [rsp+0xC0], xmm13
0000790c663d0fc7  vmovaps [rsp+0xD0], xmm14
0000790c663d0fd0  vmovaps [rsp+0xE0], xmm15
0000790c663d0fd9  sub rsp, 0x30
0000790c663d0fdd  movaps [rsp], xmm1
0000790c663d0fe1  movaps [rsp+0x10], xmm10
0000790c663d0fe7  movaps [rsp+0x20], xmm12
0000790c663d0fed  lea rdi, [rsp]
0000790c663d0ff1  mov esi, 0x00
0000790c663d0ff6  mov rax, 0x631C1759F530
0000790c663d1000  call rax
0000790c663d1002  movaps xmm1, [rsp]
0000790c663d1006  add rsp, 0x30
0000790c663d100a  vmovaps xmm0, [rsp]
0000790c663d100f  vmovaps xmm2, [rsp+0x10]
0000790c663d1015  vmovaps xmm3, [rsp+0x20]
0000790c663d101b  vmovaps xmm4, [rsp+0x30]
0000790c663d1021  vmovaps xmm5, [rsp+0x40]
0000790c663d1027  vmovaps xmm6, [rsp+0x50]
0000790c663d102d  vmovaps xmm7, [rsp+0x60]
0000790c663d1033  vmovaps xmm8, [rsp+0x70]
0000790c663d1039  vmovaps xmm9, [rsp+0x80]
0000790c663d1042  vmovaps xmm10, [rsp+0x90]
0000790c663d104b  vmovaps xmm11, [rsp+0xA0]
0000790c663d1054  vmovaps xmm12, [rsp+0xB0]
0000790c663d105d  vmovaps xmm13, [rsp+0xC0]
0000790c663d1066  vmovaps xmm14, [rsp+0xD0]
0000790c663d106f  vmovaps xmm15, [rsp+0xE0]
0000790c663d1078  add rsp, 0xF0
0000790c663d107f  pop r11
0000790c663d1081  pop r10
0000790c663d1083  pop r9
0000790c663d1085  pop r8
0000790c663d1087  pop rsi
0000790c663d1088  pop rdi
0000790c663d1089  pop rdx
0000790c663d108a  pop rcx
0000790c663d108b  pop rax
0000790c663d108c  add rsp, 0x08
0000790c663d1090  jmp 0x0000790C663CF732
0000790c663d1095  sub rsp, 0x08
0000790c663d1099  push rax
0000790c663d109a  push rcx
0000790c663d109b  push rdx
0000790c663d109c  push rdi
0000790c663d109d  push rsi
0000790c663d109e  push r8
0000790c663d10a0  push r9
0000790c663d10a2  push r10
0000790c663d10a4  push r11
0000790c663d10a6  sub rsp, 0xF0
0000790c663d10ad  vmovaps [rsp], xmm0
0000790c663d10b2  vmovaps [rsp+0x10], xmm1
0000790c663d10b8  vmovaps [rsp+0x20], xmm2
0000790c663d10be  vmovaps [rsp+0x30], xmm3
0000790c663d10c4  vmovaps [rsp+0x40], xmm4
0000790c663d10ca  vmovaps [rsp+0x50], xmm5
0000790c663d10d0  vmovaps [rsp+0x60], xmm6
0000790c663d10d6  vmovaps [rsp+0x70], xmm7
0000790c663d10dc  vmovaps [rsp+0x80], xmm8
0000790c663d10e5  vmovaps [rsp+0x90], xmm9
0000790c663d10ee  vmovaps [rsp+0xA0], xmm10
0000790c663d10f7  vmovaps [rsp+0xB0], xmm11
0000790c663d1100  vmovaps [rsp+0xC0], xmm12
0000790c663d1109  vmovaps [rsp+0xD0], xmm13
0000790c663d1112  vmovaps [rsp+0xE0], xmm14
0000790c663d111b  sub rsp, 0x30
0000790c663d111f  movaps [rsp], xmm15
0000790c663d1124  movaps [rsp+0x10], xmm10
0000790c663d112a  movaps [rsp+0x20], xmm12
0000790c663d1130  lea rdi, [rsp]
0000790c663d1134  mov esi, 0x00
0000790c663d1139  mov rax, 0x631C1759F530
0000790c663d1143  call rax
0000790c663d1145  movaps xmm15, [rsp]
0000790c663d114a  add rsp, 0x30
0000790c663d114e  vmovaps xmm0, [rsp]
0000790c663d1153  vmovaps xmm1, [rsp+0x10]
0000790c663d1159  vmovaps xmm2, [rsp+0x20]
0000790c663d115f  vmovaps xmm3, [rsp+0x30]
0000790c663d1165  vmovaps xmm4, [rsp+0x40]
0000790c663d116b  vmovaps xmm5, [rsp+0x50]
0000790c663d1171  vmovaps xmm6, [rsp+0x60]
0000790c663d1177  vmovaps xmm7, [rsp+0x70]
0000790c663d117d  vmovaps xmm8, [rsp+0x80]
0000790c663d1186  vmovaps xmm9, [rsp+0x90]
0000790c663d118f  vmovaps xmm10, [rsp+0xA0]
0000790c663d1198  vmovaps xmm11, [rsp+0xB0]
0000790c663d11a1  vmovaps xmm12, [rsp+0xC0]
0000790c663d11aa  vmovaps xmm13, [rsp+0xD0]
0000790c663d11b3  vmovaps xmm14, [rsp+0xE0]
0000790c663d11bc  add rsp, 0xF0
0000790c663d11c3  pop r11
0000790c663d11c5  pop r10
0000790c663d11c7  pop r9
0000790c663d11c9  pop r8
0000790c663d11cb  pop rsi
0000790c663d11cc  pop rdi
0000790c663d11cd  pop rdx
0000790c663d11ce  pop rcx
0000790c663d11cf  pop rax
0000790c663d11d0  add rsp, 0x08
0000790c663d11d4  jmp 0x0000790C663CF75E
0000790c663d11d9  call 0x0000790C661FF430
0000790c663d11de  jmp 0x0000790C663CF7EE
0000790c663d11e3  call 0x0000790C661FF430
0000790c663d11e8  jmp 0x0000790C663CF801
0000790c663d11ed  sub rsp, 0x08
0000790c663d11f1  push rax
0000790c663d11f2  push rcx
0000790c663d11f3  push rdx
0000790c663d11f4  push rdi
0000790c663d11f5  push rsi
0000790c663d11f6  push r8
0000790c663d11f8  push r9
0000790c663d11fa  push r10
0000790c663d11fc  push r11
0000790c663d11fe  sub rsp, 0xF0
0000790c663d1205  vmovaps [rsp], xmm0
0000790c663d120a  vmovaps [rsp+0x10], xmm2
0000790c663d1210  vmovaps [rsp+0x20], xmm3
0000790c663d1216  vmovaps [rsp+0x30], xmm4
0000790c663d121c  vmovaps [rsp+0x40], xmm5
0000790c663d1222  vmovaps [rsp+0x50], xmm6
0000790c663d1228  vmovaps [rsp+0x60], xmm7
0000790c663d122e  vmovaps [rsp+0x70], xmm8
0000790c663d1234  vmovaps [rsp+0x80], xmm9
0000790c663d123d  vmovaps [rsp+0x90], xmm10
0000790c663d1246  vmovaps [rsp+0xA0], xmm11
0000790c663d124f  vmovaps [rsp+0xB0], xmm12
0000790c663d1258  vmovaps [rsp+0xC0], xmm13
0000790c663d1261  vmovaps [rsp+0xD0], xmm14
0000790c663d126a  vmovaps [rsp+0xE0], xmm15
0000790c663d1273  sub rsp, 0x30
0000790c663d1277  movaps [rsp], xmm1
0000790c663d127b  movaps [rsp+0x10], xmm13
0000790c663d1281  movaps [rsp+0x20], xmm2
0000790c663d1286  lea rdi, [rsp]
0000790c663d128a  mov esi, 0x00
0000790c663d128f  mov rax, 0x631C1759F530
0000790c663d1299  call rax
0000790c663d129b  movaps xmm1, [rsp]
0000790c663d129f  add rsp, 0x30
0000790c663d12a3  vmovaps xmm0, [rsp]
0000790c663d12a8  vmovaps xmm2, [rsp+0x10]
0000790c663d12ae  vmovaps xmm3, [rsp+0x20]
0000790c663d12b4  vmovaps xmm4, [rsp+0x30]
0000790c663d12ba  vmovaps xmm5, [rsp+0x40]
0000790c663d12c0  vmovaps xmm6, [rsp+0x50]
0000790c663d12c6  vmovaps xmm7, [rsp+0x60]
0000790c663d12cc  vmovaps xmm8, [rsp+0x70]
0000790c663d12d2  vmovaps xmm9, [rsp+0x80]
0000790c663d12db  vmovaps xmm10, [rsp+0x90]
0000790c663d12e4  vmovaps xmm11, [rsp+0xA0]
0000790c663d12ed  vmovaps xmm12, [rsp+0xB0]
0000790c663d12f6  vmovaps xmm13, [rsp+0xC0]
0000790c663d12ff  vmovaps xmm14, [rsp+0xD0]
0000790c663d1308  vmovaps xmm15, [rsp+0xE0]
0000790c663d1311  add rsp, 0xF0
0000790c663d1318  pop r11
0000790c663d131a  pop r10
0000790c663d131c  pop r9
0000790c663d131e  pop r8
0000790c663d1320  pop rsi
0000790c663d1321  pop rdi
0000790c663d1322  pop rdx
0000790c663d1323  pop rcx
0000790c663d1324  pop rax
0000790c663d1325  add rsp, 0x08
0000790c663d1329  jmp 0x0000790C663CF82C
0000790c663d132e  call 0x0000790C6620E760
0000790c663d1333  jmp 0x0000790C663CF839
0000790c663d1338  sub rsp, 0x08
0000790c663d133c  push rax
0000790c663d133d  push rcx
0000790c663d133e  push rdx
0000790c663d133f  push rdi
0000790c663d1340  push rsi
0000790c663d1341  push r8
0000790c663d1343  push r9
0000790c663d1345  push r10
0000790c663d1347  push r11
0000790c663d1349  sub rsp, 0xF0
0000790c663d1350  vmovaps [rsp], xmm0
0000790c663d1355  vmovaps [rsp+0x10], xmm1
0000790c663d135b  vmovaps [rsp+0x20], xmm2
0000790c663d1361  vmovaps [rsp+0x30], xmm3
0000790c663d1367  vmovaps [rsp+0x40], xmm4
0000790c663d136d  vmovaps [rsp+0x50], xmm5
0000790c663d1373  vmovaps [rsp+0x60], xmm6
0000790c663d1379  vmovaps [rsp+0x70], xmm7
0000790c663d137f  vmovaps [rsp+0x80], xmm8
0000790c663d1388  vmovaps [rsp+0x90], xmm9
0000790c663d1391  vmovaps [rsp+0xA0], xmm10
0000790c663d139a  vmovaps [rsp+0xB0], xmm11
0000790c663d13a3  vmovaps [rsp+0xC0], xmm12
0000790c663d13ac  vmovaps [rsp+0xD0], xmm14
0000790c663d13b5  vmovaps [rsp+0xE0], xmm15
0000790c663d13be  sub rsp, 0x30
0000790c663d13c2  movaps [rsp], xmm13
0000790c663d13c7  movaps [rsp+0x10], xmm2
0000790c663d13cc  movaps [rsp+0x20], xmm1
0000790c663d13d1  lea rdi, [rsp]
0000790c663d13d5  mov esi, 0x00
0000790c663d13da  mov rax, 0x631C1759F530
0000790c663d13e4  call rax
0000790c663d13e6  movaps xmm13, [rsp]
0000790c663d13eb  add rsp, 0x30
0000790c663d13ef  vmovaps xmm0, [rsp]
0000790c663d13f4  vmovaps xmm1, [rsp+0x10]
0000790c663d13fa  vmovaps xmm2, [rsp+0x20]
0000790c663d1400  vmovaps xmm3, [rsp+0x30]
0000790c663d1406  vmovaps xmm4, [rsp+0x40]
0000790c663d140c  vmovaps xmm5, [rsp+0x50]
0000790c663d1412  vmovaps xmm6, [rsp+0x60]
0000790c663d1418  vmovaps xmm7, [rsp+0x70]
0000790c663d141e  vmovaps xmm8, [rsp+0x80]
0000790c663d1427  vmovaps xmm9, [rsp+0x90]
0000790c663d1430  vmovaps xmm10, [rsp+0xA0]
0000790c663d1439  vmovaps xmm11, [rsp+0xB0]
0000790c663d1442  vmovaps xmm12, [rsp+0xC0]
0000790c663d144b  vmovaps xmm14, [rsp+0xD0]
0000790c663d1454  vmovaps xmm15, [rsp+0xE0]
0000790c663d145d  add rsp, 0xF0
0000790c663d1464  pop r11
0000790c663d1466  pop r10
0000790c663d1468  pop r9
0000790c663d146a  pop r8
0000790c663d146c  pop rsi
0000790c663d146d  pop rdi
0000790c663d146e  pop rdx
0000790c663d146f  pop rcx
0000790c663d1470  pop rax
0000790c663d1471  add rsp, 0x08
0000790c663d1475  jmp 0x0000790C663CF878
0000790c663d147a  sub rsp, 0x08
0000790c663d147e  push rax
0000790c663d147f  push rcx
0000790c663d1480  push rdx
0000790c663d1481  push rdi
0000790c663d1482  push rsi
0000790c663d1483  push r8
0000790c663d1485  push r9
0000790c663d1487  push r10
0000790c663d1489  push r11
0000790c663d148b  sub rsp, 0xF0
0000790c663d1492  vmovaps [rsp], xmm0
0000790c663d1497  vmovaps [rsp+0x10], xmm2
0000790c663d149d  vmovaps [rsp+0x20], xmm3
0000790c663d14a3  vmovaps [rsp+0x30], xmm4
0000790c663d14a9  vmovaps [rsp+0x40], xmm5
0000790c663d14af  vmovaps [rsp+0x50], xmm6
0000790c663d14b5  vmovaps [rsp+0x60], xmm7
0000790c663d14bb  vmovaps [rsp+0x70], xmm8
0000790c663d14c1  vmovaps [rsp+0x80], xmm9
0000790c663d14ca  vmovaps [rsp+0x90], xmm10
0000790c663d14d3  vmovaps [rsp+0xA0], xmm11
0000790c663d14dc  vmovaps [rsp+0xB0], xmm12
0000790c663d14e5  vmovaps [rsp+0xC0], xmm13
0000790c663d14ee  vmovaps [rsp+0xD0], xmm14
0000790c663d14f7  vmovaps [rsp+0xE0], xmm15
0000790c663d1500  sub rsp, 0x30
0000790c663d1504  movaps [rsp], xmm1
0000790c663d1508  movaps [rsp+0x10], xmm15
0000790c663d150e  movaps [rsp+0x20], xmm2
0000790c663d1513  lea rdi, [rsp]
0000790c663d1517  mov esi, 0x00
0000790c663d151c  mov rax, 0x631C1759F530
0000790c663d1526  call rax
0000790c663d1528  movaps xmm1, [rsp]
0000790c663d152c  add rsp, 0x30
0000790c663d1530  vmovaps xmm0, [rsp]
0000790c663d1535  vmovaps xmm2, [rsp+0x10]
0000790c663d153b  vmovaps xmm3, [rsp+0x20]
0000790c663d1541  vmovaps xmm4, [rsp+0x30]
0000790c663d1547  vmovaps xmm5, [rsp+0x40]
0000790c663d154d  vmovaps xmm6, [rsp+0x50]
0000790c663d1553  vmovaps xmm7, [rsp+0x60]
0000790c663d1559  vmovaps xmm8, [rsp+0x70]
0000790c663d155f  vmovaps xmm9, [rsp+0x80]
0000790c663d1568  vmovaps xmm10, [rsp+0x90]
0000790c663d1571  vmovaps xmm11, [rsp+0xA0]
0000790c663d157a  vmovaps xmm12, [rsp+0xB0]
0000790c663d1583  vmovaps xmm13, [rsp+0xC0]
0000790c663d158c  vmovaps xmm14, [rsp+0xD0]
0000790c663d1595  vmovaps xmm15, [rsp+0xE0]
0000790c663d159e  add rsp, 0xF0
0000790c663d15a5  pop r11
0000790c663d15a7  pop r10
0000790c663d15a9  pop r9
0000790c663d15ab  pop r8
0000790c663d15ad  pop rsi
0000790c663d15ae  pop rdi
0000790c663d15af  pop rdx
0000790c663d15b0  pop rcx
0000790c663d15b1  pop rax
0000790c663d15b2  add rsp, 0x08
0000790c663d15b6  jmp 0x0000790C663CF8AC
0000790c663d15bb  sub rsp, 0x08
0000790c663d15bf  push rax
0000790c663d15c0  push rcx
0000790c663d15c1  push rdx
0000790c663d15c2  push rdi
0000790c663d15c3  push rsi
0000790c663d15c4  push r8
0000790c663d15c6  push r9
0000790c663d15c8  push r10
0000790c663d15ca  push r11
0000790c663d15cc  sub rsp, 0xF0
0000790c663d15d3  vmovaps [rsp], xmm0
0000790c663d15d8  vmovaps [rsp+0x10], xmm1
0000790c663d15de  vmovaps [rsp+0x20], xmm2
0000790c663d15e4  vmovaps [rsp+0x30], xmm3
0000790c663d15ea  vmovaps [rsp+0x40], xmm4
0000790c663d15f0  vmovaps [rsp+0x50], xmm5
0000790c663d15f6  vmovaps [rsp+0x60], xmm6
0000790c663d15fc  vmovaps [rsp+0x70], xmm7
0000790c663d1602  vmovaps [rsp+0x80], xmm8
0000790c663d160b  vmovaps [rsp+0x90], xmm9
0000790c663d1614  vmovaps [rsp+0xA0], xmm10
0000790c663d161d  vmovaps [rsp+0xB0], xmm11
0000790c663d1626  vmovaps [rsp+0xC0], xmm12
0000790c663d162f  vmovaps [rsp+0xD0], xmm13
0000790c663d1638  vmovaps [rsp+0xE0], xmm15
0000790c663d1641  sub rsp, 0x30
0000790c663d1645  movaps [rsp], xmm14
0000790c663d164a  movaps [rsp+0x10], xmm2
0000790c663d164f  movaps [rsp+0x20], xmm15
0000790c663d1655  lea rdi, [rsp]
0000790c663d1659  mov esi, 0x00
0000790c663d165e  mov rax, 0x631C1759F530
0000790c663d1668  call rax
0000790c663d166a  movaps xmm14, [rsp]
0000790c663d166f  add rsp, 0x30
0000790c663d1673  vmovaps xmm0, [rsp]
0000790c663d1678  vmovaps xmm1, [rsp+0x10]
0000790c663d167e  vmovaps xmm2, [rsp+0x20]
0000790c663d1684  vmovaps xmm3, [rsp+0x30]
0000790c663d168a  vmovaps xmm4, [rsp+0x40]
0000790c663d1690  vmovaps xmm5, [rsp+0x50]
0000790c663d1696  vmovaps xmm6, [rsp+0x60]
0000790c663d169c  vmovaps xmm7, [rsp+0x70]
0000790c663d16a2  vmovaps xmm8, [rsp+0x80]
0000790c663d16ab  vmovaps xmm9, [rsp+0x90]
0000790c663d16b4  vmovaps xmm10, [rsp+0xA0]
0000790c663d16bd  vmovaps xmm11, [rsp+0xB0]
0000790c663d16c6  vmovaps xmm12, [rsp+0xC0]
0000790c663d16cf  vmovaps xmm13, [rsp+0xD0]
0000790c663d16d8  vmovaps xmm15, [rsp+0xE0]
0000790c663d16e1  add rsp, 0xF0
0000790c663d16e8  pop r11
0000790c663d16ea  pop r10
0000790c663d16ec  pop r9
0000790c663d16ee  pop r8
0000790c663d16f0  pop rsi
0000790c663d16f1  pop rdi
0000790c663d16f2  pop rdx
0000790c663d16f3  pop rcx
0000790c663d16f4  pop rax
0000790c663d16f5  add rsp, 0x08
0000790c663d16f9  jmp 0x0000790C663CF8E7
0000790c663d16fe  sub rsp, 0x08
0000790c663d1702  push rax
0000790c663d1703  push rcx
0000790c663d1704  push rdx
0000790c663d1705  push rdi
0000790c663d1706  push rsi
0000790c663d1707  push r8
0000790c663d1709  push r9
0000790c663d170b  push r10
0000790c663d170d  push r11
0000790c663d170f  sub rsp, 0xF0
0000790c663d1716  vmovaps [rsp], xmm0
0000790c663d171b  vmovaps [rsp+0x10], xmm1
0000790c663d1721  vmovaps [rsp+0x20], xmm2
0000790c663d1727  vmovaps [rsp+0x30], xmm3
0000790c663d172d  vmovaps [rsp+0x40], xmm4
0000790c663d1733  vmovaps [rsp+0x50], xmm5
0000790c663d1739  vmovaps [rsp+0x60], xmm6
0000790c663d173f  vmovaps [rsp+0x70], xmm7
0000790c663d1745  vmovaps [rsp+0x80], xmm8
0000790c663d174e  vmovaps [rsp+0x90], xmm9
0000790c663d1757  vmovaps [rsp+0xA0], xmm10
0000790c663d1760  vmovaps [rsp+0xB0], xmm11
0000790c663d1769  vmovaps [rsp+0xC0], xmm12
0000790c663d1772  vmovaps [rsp+0xD0], xmm13
0000790c663d177b  vmovaps [rsp+0xE0], xmm14
0000790c663d1784  sub rsp, 0x30
0000790c663d1788  movaps [rsp], xmm15
0000790c663d178d  movaps [rsp+0x10], xmm2
0000790c663d1792  movaps [rsp+0x20], xmm1
0000790c663d1797  lea rdi, [rsp]
0000790c663d179b  mov esi, 0x00
0000790c663d17a0  mov rax, 0x631C1759F530
0000790c663d17aa  call rax
0000790c663d17ac  movaps xmm15, [rsp]
0000790c663d17b1  add rsp, 0x30
0000790c663d17b5  vmovaps xmm0, [rsp]
0000790c663d17ba  vmovaps xmm1, [rsp+0x10]
0000790c663d17c0  vmovaps xmm2, [rsp+0x20]
0000790c663d17c6  vmovaps xmm3, [rsp+0x30]
0000790c663d17cc  vmovaps xmm4, [rsp+0x40]
0000790c663d17d2  vmovaps xmm5, [rsp+0x50]
0000790c663d17d8  vmovaps xmm6, [rsp+0x60]
0000790c663d17de  vmovaps xmm7, [rsp+0x70]
0000790c663d17e4  vmovaps xmm8, [rsp+0x80]
0000790c663d17ed  vmovaps xmm9, [rsp+0x90]
0000790c663d17f6  vmovaps xmm10, [rsp+0xA0]
0000790c663d17ff  vmovaps xmm11, [rsp+0xB0]
0000790c663d1808  vmovaps xmm12, [rsp+0xC0]
0000790c663d1811  vmovaps xmm13, [rsp+0xD0]
0000790c663d181a  vmovaps xmm14, [rsp+0xE0]
0000790c663d1823  add rsp, 0xF0
0000790c663d182a  pop r11
0000790c663d182c  pop r10
0000790c663d182e  pop r9
0000790c663d1830  pop r8
0000790c663d1832  pop rsi
0000790c663d1833  pop rdi
0000790c663d1834  pop rdx
0000790c663d1835  pop rcx
0000790c663d1836  pop rax
0000790c663d1837  add rsp, 0x08
0000790c663d183b  jmp 0x0000790C663CF923
0000790c663d1840  call 0x0000790C661FF430
0000790c663d1845  jmp 0x0000790C663CF930
0000790c663d184a  sub rsp, 0x08
0000790c663d184e  push rax
0000790c663d184f  push rcx
0000790c663d1850  push rdx
0000790c663d1851  push rdi
0000790c663d1852  push rsi
0000790c663d1853  push r8
0000790c663d1855  push r9
0000790c663d1857  push r10
0000790c663d1859  push r11
0000790c663d185b  sub rsp, 0xF0
0000790c663d1862  vmovaps [rsp], xmm0
0000790c663d1867  vmovaps [rsp+0x10], xmm1
0000790c663d186d  vmovaps [rsp+0x20], xmm3
0000790c663d1873  vmovaps [rsp+0x30], xmm4
0000790c663d1879  vmovaps [rsp+0x40], xmm5
0000790c663d187f  vmovaps [rsp+0x50], xmm6
0000790c663d1885  vmovaps [rsp+0x60], xmm7
0000790c663d188b  vmovaps [rsp+0x70], xmm8
0000790c663d1891  vmovaps [rsp+0x80], xmm9
0000790c663d189a  vmovaps [rsp+0x90], xmm10
0000790c663d18a3  vmovaps [rsp+0xA0], xmm11
0000790c663d18ac  vmovaps [rsp+0xB0], xmm12
0000790c663d18b5  vmovaps [rsp+0xC0], xmm13
0000790c663d18be  vmovaps [rsp+0xD0], xmm14
0000790c663d18c7  vmovaps [rsp+0xE0], xmm15
0000790c663d18d0  sub rsp, 0x30
0000790c663d18d4  movaps [rsp], xmm2
0000790c663d18d8  movaps [rsp+0x10], xmm1
0000790c663d18dd  movaps [rsp+0x20], xmm14
0000790c663d18e3  lea rdi, [rsp]
0000790c663d18e7  mov esi, 0x00
0000790c663d18ec  mov rax, 0x631C1759F530
0000790c663d18f6  call rax
0000790c663d18f8  movaps xmm2, [rsp]
0000790c663d18fc  add rsp, 0x30
0000790c663d1900  vmovaps xmm0, [rsp]
0000790c663d1905  vmovaps xmm1, [rsp+0x10]
0000790c663d190b  vmovaps xmm3, [rsp+0x20]
0000790c663d1911  vmovaps xmm4, [rsp+0x30]
0000790c663d1917  vmovaps xmm5, [rsp+0x40]
0000790c663d191d  vmovaps xmm6, [rsp+0x50]
0000790c663d1923  vmovaps xmm7, [rsp+0x60]
0000790c663d1929  vmovaps xmm8, [rsp+0x70]
0000790c663d192f  vmovaps xmm9, [rsp+0x80]
0000790c663d1938  vmovaps xmm10, [rsp+0x90]
0000790c663d1941  vmovaps xmm11, [rsp+0xA0]
0000790c663d194a  vmovaps xmm12, [rsp+0xB0]
0000790c663d1953  vmovaps xmm13, [rsp+0xC0]
0000790c663d195c  vmovaps xmm14, [rsp+0xD0]
0000790c663d1965  vmovaps xmm15, [rsp+0xE0]
0000790c663d196e  add rsp, 0xF0
0000790c663d1975  pop r11
0000790c663d1977  pop r10
0000790c663d1979  pop r9
0000790c663d197b  pop r8
0000790c663d197d  pop rsi
0000790c663d197e  pop rdi
0000790c663d197f  pop rdx
0000790c663d1980  pop rcx
0000790c663d1981  pop rax
0000790c663d1982  add rsp, 0x08
0000790c663d1986  jmp 0x0000790C663CF96D
0000790c663d198b  sub rsp, 0x08
0000790c663d198f  push rax
0000790c663d1990  push rcx
0000790c663d1991  push rdx
0000790c663d1992  push rdi
0000790c663d1993  push rsi
0000790c663d1994  push r8
0000790c663d1996  push r9
0000790c663d1998  push r10
0000790c663d199a  push r11
0000790c663d199c  sub rsp, 0xF0
0000790c663d19a3  vmovaps [rsp], xmm0
0000790c663d19a8  vmovaps [rsp+0x10], xmm1
0000790c663d19ae  vmovaps [rsp+0x20], xmm2
0000790c663d19b4  vmovaps [rsp+0x30], xmm3
0000790c663d19ba  vmovaps [rsp+0x40], xmm4
0000790c663d19c0  vmovaps [rsp+0x50], xmm5
0000790c663d19c6  vmovaps [rsp+0x60], xmm6
0000790c663d19cc  vmovaps [rsp+0x70], xmm7
0000790c663d19d2  vmovaps [rsp+0x80], xmm8
0000790c663d19db  vmovaps [rsp+0x90], xmm9
0000790c663d19e4  vmovaps [rsp+0xA0], xmm10
0000790c663d19ed  vmovaps [rsp+0xB0], xmm11
0000790c663d19f6  vmovaps [rsp+0xC0], xmm12
0000790c663d19ff  vmovaps [rsp+0xD0], xmm13
0000790c663d1a08  vmovaps [rsp+0xE0], xmm14
0000790c663d1a11  sub rsp, 0x30
0000790c663d1a15  movaps [rsp], xmm15
0000790c663d1a1a  movaps [rsp+0x10], xmm14
0000790c663d1a20  movaps [rsp+0x20], xmm1
0000790c663d1a25  lea rdi, [rsp]
0000790c663d1a29  mov esi, 0x00
0000790c663d1a2e  mov rax, 0x631C1759F530
0000790c663d1a38  call rax
0000790c663d1a3a  movaps xmm15, [rsp]
0000790c663d1a3f  add rsp, 0x30
0000790c663d1a43  vmovaps xmm0, [rsp]
0000790c663d1a48  vmovaps xmm1, [rsp+0x10]
0000790c663d1a4e  vmovaps xmm2, [rsp+0x20]
0000790c663d1a54  vmovaps xmm3, [rsp+0x30]
0000790c663d1a5a  vmovaps xmm4, [rsp+0x40]
0000790c663d1a60  vmovaps xmm5, [rsp+0x50]
0000790c663d1a66  vmovaps xmm6, [rsp+0x60]
0000790c663d1a6c  vmovaps xmm7, [rsp+0x70]
0000790c663d1a72  vmovaps xmm8, [rsp+0x80]
0000790c663d1a7b  vmovaps xmm9, [rsp+0x90]
0000790c663d1a84  vmovaps xmm10, [rsp+0xA0]
0000790c663d1a8d  vmovaps xmm11, [rsp+0xB0]
0000790c663d1a96  vmovaps xmm12, [rsp+0xC0]
0000790c663d1a9f  vmovaps xmm13, [rsp+0xD0]
0000790c663d1aa8  vmovaps xmm14, [rsp+0xE0]
0000790c663d1ab1  add rsp, 0xF0
0000790c663d1ab8  pop r11
0000790c663d1aba  pop r10
0000790c663d1abc  pop r9
0000790c663d1abe  pop r8
0000790c663d1ac0  pop rsi
0000790c663d1ac1  pop rdi
0000790c663d1ac2  pop rdx
0000790c663d1ac3  pop rcx
0000790c663d1ac4  pop rax
0000790c663d1ac5  add rsp, 0x08
0000790c663d1ac9  jmp 0x0000790C663CF9E7
0000790c663d1ace  call 0x0000790C661FF430
0000790c663d1ad3  jmp 0x0000790C663CF9F4
0000790c663d1ad8  sub rsp, 0x08
0000790c663d1adc  push rax
0000790c663d1add  push rcx
0000790c663d1ade  push rdx
0000790c663d1adf  push rdi
0000790c663d1ae0  push rsi
0000790c663d1ae1  push r8
0000790c663d1ae3  push r9
0000790c663d1ae5  push r10
0000790c663d1ae7  push r11
0000790c663d1ae9  sub rsp, 0xF0
0000790c663d1af0  vmovaps [rsp], xmm0
0000790c663d1af5  vmovaps [rsp+0x10], xmm1
0000790c663d1afb  vmovaps [rsp+0x20], xmm2
0000790c663d1b01  vmovaps [rsp+0x30], xmm3
0000790c663d1b07  vmovaps [rsp+0x40], xmm4
0000790c663d1b0d  vmovaps [rsp+0x50], xmm5
0000790c663d1b13  vmovaps [rsp+0x60], xmm6
0000790c663d1b19  vmovaps [rsp+0x70], xmm7
0000790c663d1b1f  vmovaps [rsp+0x80], xmm8
0000790c663d1b28  vmovaps [rsp+0x90], xmm9
0000790c663d1b31  vmovaps [rsp+0xA0], xmm10
0000790c663d1b3a  vmovaps [rsp+0xB0], xmm11
0000790c663d1b43  vmovaps [rsp+0xC0], xmm12
0000790c663d1b4c  vmovaps [rsp+0xD0], xmm13
0000790c663d1b55  vmovaps [rsp+0xE0], xmm15
0000790c663d1b5e  sub rsp, 0x30
0000790c663d1b62  movaps [rsp], xmm14
0000790c663d1b67  movaps [rsp+0x10], xmm13
0000790c663d1b6d  movaps [rsp+0x20], xmm1
0000790c663d1b72  lea rdi, [rsp]
0000790c663d1b76  mov esi, 0x00
0000790c663d1b7b  mov rax, 0x631C1759F530
0000790c663d1b85  call rax
0000790c663d1b87  movaps xmm14, [rsp]
0000790c663d1b8c  add rsp, 0x30
0000790c663d1b90  vmovaps xmm0, [rsp]
0000790c663d1b95  vmovaps xmm1, [rsp+0x10]
0000790c663d1b9b  vmovaps xmm2, [rsp+0x20]
0000790c663d1ba1  vmovaps xmm3, [rsp+0x30]
0000790c663d1ba7  vmovaps xmm4, [rsp+0x40]
0000790c663d1bad  vmovaps xmm5, [rsp+0x50]
0000790c663d1bb3  vmovaps xmm6, [rsp+0x60]
0000790c663d1bb9  vmovaps xmm7, [rsp+0x70]
0000790c663d1bbf  vmovaps xmm8, [rsp+0x80]
0000790c663d1bc8  vmovaps xmm9, [rsp+0x90]
0000790c663d1bd1  vmovaps xmm10, [rsp+0xA0]
0000790c663d1bda  vmovaps xmm11, [rsp+0xB0]
0000790c663d1be3  vmovaps xmm12, [rsp+0xC0]
0000790c663d1bec  vmovaps xmm13, [rsp+0xD0]
0000790c663d1bf5  vmovaps xmm15, [rsp+0xE0]
0000790c663d1bfe  add rsp, 0xF0
0000790c663d1c05  pop r11
0000790c663d1c07  pop r10
0000790c663d1c09  pop r9
0000790c663d1c0b  pop r8
0000790c663d1c0d  pop rsi
0000790c663d1c0e  pop rdi
0000790c663d1c0f  pop rdx
0000790c663d1c10  pop rcx
0000790c663d1c11  pop rax
0000790c663d1c12  add rsp, 0x08
0000790c663d1c16  jmp 0x0000790C663CFAAF
0000790c663d1c1b  sub rsp, 0x08
0000790c663d1c1f  push rax
0000790c663d1c20  push rcx
0000790c663d1c21  push rdx
0000790c663d1c22  push rdi
0000790c663d1c23  push rsi
0000790c663d1c24  push r8
0000790c663d1c26  push r9
0000790c663d1c28  push r10
0000790c663d1c2a  push r11
0000790c663d1c2c  sub rsp, 0xF0
0000790c663d1c33  vmovaps [rsp], xmm0
0000790c663d1c38  vmovaps [rsp+0x10], xmm1
0000790c663d1c3e  vmovaps [rsp+0x20], xmm2
0000790c663d1c44  vmovaps [rsp+0x30], xmm3
0000790c663d1c4a  vmovaps [rsp+0x40], xmm4
0000790c663d1c50  vmovaps [rsp+0x50], xmm5
0000790c663d1c56  vmovaps [rsp+0x60], xmm6
0000790c663d1c5c  vmovaps [rsp+0x70], xmm7
0000790c663d1c62  vmovaps [rsp+0x80], xmm8
0000790c663d1c6b  vmovaps [rsp+0x90], xmm9
0000790c663d1c74  vmovaps [rsp+0xA0], xmm10
0000790c663d1c7d  vmovaps [rsp+0xB0], xmm11
0000790c663d1c86  vmovaps [rsp+0xC0], xmm12
0000790c663d1c8f  vmovaps [rsp+0xD0], xmm13
0000790c663d1c98  vmovaps [rsp+0xE0], xmm14
0000790c663d1ca1  sub rsp, 0x30
0000790c663d1ca5  movaps [rsp], xmm15
0000790c663d1caa  movaps [rsp+0x10], xmm13
0000790c663d1cb0  movaps [rsp+0x20], xmm1
0000790c663d1cb5  lea rdi, [rsp]
0000790c663d1cb9  mov esi, 0x00
0000790c663d1cbe  mov rax, 0x631C1759F530
0000790c663d1cc8  call rax
0000790c663d1cca  movaps xmm15, [rsp]
0000790c663d1ccf  add rsp, 0x30
0000790c663d1cd3  vmovaps xmm0, [rsp]
0000790c663d1cd8  vmovaps xmm1, [rsp+0x10]
0000790c663d1cde  vmovaps xmm2, [rsp+0x20]
0000790c663d1ce4  vmovaps xmm3, [rsp+0x30]
0000790c663d1cea  vmovaps xmm4, [rsp+0x40]
0000790c663d1cf0  vmovaps xmm5, [rsp+0x50]
0000790c663d1cf6  vmovaps xmm6, [rsp+0x60]
0000790c663d1cfc  vmovaps xmm7, [rsp+0x70]
0000790c663d1d02  vmovaps xmm8, [rsp+0x80]
0000790c663d1d0b  vmovaps xmm9, [rsp+0x90]
0000790c663d1d14  vmovaps xmm10, [rsp+0xA0]
0000790c663d1d1d  vmovaps xmm11, [rsp+0xB0]
0000790c663d1d26  vmovaps xmm12, [rsp+0xC0]
0000790c663d1d2f  vmovaps xmm13, [rsp+0xD0]
0000790c663d1d38  vmovaps xmm14, [rsp+0xE0]
0000790c663d1d41  add rsp, 0xF0
0000790c663d1d48  pop r11
0000790c663d1d4a  pop r10
0000790c663d1d4c  pop r9
0000790c663d1d4e  pop r8
0000790c663d1d50  pop rsi
0000790c663d1d51  pop rdi
0000790c663d1d52  pop rdx
0000790c663d1d53  pop rcx
0000790c663d1d54  pop rax
0000790c663d1d55  add rsp, 0x08
0000790c663d1d59  jmp 0x0000790C663CFAEB
0000790c663d1d5e  call 0x0000790C661FF430
0000790c663d1d63  jmp 0x0000790C663CFAF8
0000790c663d1d68  sub rsp, 0x08
0000790c663d1d6c  push rax
0000790c663d1d6d  push rcx
0000790c663d1d6e  push rdx
0000790c663d1d6f  push rdi
0000790c663d1d70  push rsi
0000790c663d1d71  push r8
0000790c663d1d73  push r9
0000790c663d1d75  push r10
0000790c663d1d77  push r11
0000790c663d1d79  sub rsp, 0xF0
0000790c663d1d80  vmovaps [rsp], xmm0
0000790c663d1d85  vmovaps [rsp+0x10], xmm1
0000790c663d1d8b  vmovaps [rsp+0x20], xmm2
0000790c663d1d91  vmovaps [rsp+0x30], xmm3
0000790c663d1d97  vmovaps [rsp+0x40], xmm4
0000790c663d1d9d  vmovaps [rsp+0x50], xmm5
0000790c663d1da3  vmovaps [rsp+0x60], xmm6
0000790c663d1da9  vmovaps [rsp+0x70], xmm7
0000790c663d1daf  vmovaps [rsp+0x80], xmm8
0000790c663d1db8  vmovaps [rsp+0x90], xmm9
0000790c663d1dc1  vmovaps [rsp+0xA0], xmm10
0000790c663d1dca  vmovaps [rsp+0xB0], xmm11
0000790c663d1dd3  vmovaps [rsp+0xC0], xmm12
0000790c663d1ddc  vmovaps [rsp+0xD0], xmm13
0000790c663d1de5  vmovaps [rsp+0xE0], xmm15
0000790c663d1dee  sub rsp, 0x30
0000790c663d1df2  movaps [rsp], xmm14
0000790c663d1df7  movaps [rsp+0x10], xmm13
0000790c663d1dfd  movaps [rsp+0x20], xmm2
0000790c663d1e02  lea rdi, [rsp]
0000790c663d1e06  mov esi, 0x00
0000790c663d1e0b  mov rax, 0x631C1759F530
0000790c663d1e15  call rax
0000790c663d1e17  movaps xmm14, [rsp]
0000790c663d1e1c  add rsp, 0x30
0000790c663d1e20  vmovaps xmm0, [rsp]
0000790c663d1e25  vmovaps xmm1, [rsp+0x10]
0000790c663d1e2b  vmovaps xmm2, [rsp+0x20]
0000790c663d1e31  vmovaps xmm3, [rsp+0x30]
0000790c663d1e37  vmovaps xmm4, [rsp+0x40]
0000790c663d1e3d  vmovaps xmm5, [rsp+0x50]
0000790c663d1e43  vmovaps xmm6, [rsp+0x60]
0000790c663d1e49  vmovaps xmm7, [rsp+0x70]
0000790c663d1e4f  vmovaps xmm8, [rsp+0x80]
0000790c663d1e58  vmovaps xmm9, [rsp+0x90]
0000790c663d1e61  vmovaps xmm10, [rsp+0xA0]
0000790c663d1e6a  vmovaps xmm11, [rsp+0xB0]
0000790c663d1e73  vmovaps xmm12, [rsp+0xC0]
0000790c663d1e7c  vmovaps xmm13, [rsp+0xD0]
0000790c663d1e85  vmovaps xmm15, [rsp+0xE0]
0000790c663d1e8e  add rsp, 0xF0
0000790c663d1e95  pop r11
0000790c663d1e97  pop r10
0000790c663d1e99  pop r9
0000790c663d1e9b  pop r8
0000790c663d1e9d  pop rsi
0000790c663d1e9e  pop rdi
0000790c663d1e9f  pop rdx
0000790c663d1ea0  pop rcx
0000790c663d1ea1  pop rax
0000790c663d1ea2  add rsp, 0x08
0000790c663d1ea6  jmp 0x0000790C663CFB24
0000790c663d1eab  sub rsp, 0x08
0000790c663d1eaf  push rax
0000790c663d1eb0  push rcx
0000790c663d1eb1  push rdx
0000790c663d1eb2  push rdi
0000790c663d1eb3  push rsi
0000790c663d1eb4  push r8
0000790c663d1eb6  push r9
0000790c663d1eb8  push r10
0000790c663d1eba  push r11
0000790c663d1ebc  sub rsp, 0xF0
0000790c663d1ec3  vmovaps [rsp], xmm0
0000790c663d1ec8  vmovaps [rsp+0x10], xmm2
0000790c663d1ece  vmovaps [rsp+0x20], xmm3
0000790c663d1ed4  vmovaps [rsp+0x30], xmm4
0000790c663d1eda  vmovaps [rsp+0x40], xmm5
0000790c663d1ee0  vmovaps [rsp+0x50], xmm6
0000790c663d1ee6  vmovaps [rsp+0x60], xmm7
0000790c663d1eec  vmovaps [rsp+0x70], xmm8
0000790c663d1ef2  vmovaps [rsp+0x80], xmm9
0000790c663d1efb  vmovaps [rsp+0x90], xmm10
0000790c663d1f04  vmovaps [rsp+0xA0], xmm11
0000790c663d1f0d  vmovaps [rsp+0xB0], xmm12
0000790c663d1f16  vmovaps [rsp+0xC0], xmm13
0000790c663d1f1f  vmovaps [rsp+0xD0], xmm14
0000790c663d1f28  vmovaps [rsp+0xE0], xmm15
0000790c663d1f31  sub rsp, 0x30
0000790c663d1f35  movaps [rsp], xmm1
0000790c663d1f39  movaps [rsp+0x10], xmm13
0000790c663d1f3f  movaps [rsp+0x20], xmm2
0000790c663d1f44  lea rdi, [rsp]
0000790c663d1f48  mov esi, 0x00
0000790c663d1f4d  mov rax, 0x631C1759F530
0000790c663d1f57  call rax
0000790c663d1f59  movaps xmm1, [rsp]
0000790c663d1f5d  add rsp, 0x30
0000790c663d1f61  vmovaps xmm0, [rsp]
0000790c663d1f66  vmovaps xmm2, [rsp+0x10]
0000790c663d1f6c  vmovaps xmm3, [rsp+0x20]
0000790c663d1f72  vmovaps xmm4, [rsp+0x30]
0000790c663d1f78  vmovaps xmm5, [rsp+0x40]
0000790c663d1f7e  vmovaps xmm6, [rsp+0x50]
0000790c663d1f84  vmovaps xmm7, [rsp+0x60]
0000790c663d1f8a  vmovaps xmm8, [rsp+0x70]
0000790c663d1f90  vmovaps xmm9, [rsp+0x80]
0000790c663d1f99  vmovaps xmm10, [rsp+0x90]
0000790c663d1fa2  vmovaps xmm11, [rsp+0xA0]
0000790c663d1fab  vmovaps xmm12, [rsp+0xB0]
0000790c663d1fb4  vmovaps xmm13, [rsp+0xC0]
0000790c663d1fbd  vmovaps xmm14, [rsp+0xD0]
0000790c663d1fc6  vmovaps xmm15, [rsp+0xE0]
0000790c663d1fcf  add rsp, 0xF0
0000790c663d1fd6  pop r11
0000790c663d1fd8  pop r10
0000790c663d1fda  pop r9
0000790c663d1fdc  pop r8
0000790c663d1fde  pop rsi
0000790c663d1fdf  pop rdi
0000790c663d1fe0  pop rdx
0000790c663d1fe1  pop rcx
0000790c663d1fe2  pop rax
0000790c663d1fe3  add rsp, 0x08
0000790c663d1fe7  jmp 0x0000790C663CFB52
0000790c663d1fec  sub rsp, 0x08
0000790c663d1ff0  push rax
0000790c663d1ff1  push rcx
0000790c663d1ff2  push rdx
0000790c663d1ff3  push rdi
0000790c663d1ff4  push rsi
0000790c663d1ff5  push r8
0000790c663d1ff7  push r9
0000790c663d1ff9  push r10
0000790c663d1ffb  push r11
0000790c663d1ffd  sub rsp, 0xF0
0000790c663d2004  vmovaps [rsp], xmm0
0000790c663d2009  vmovaps [rsp+0x10], xmm1
0000790c663d200f  vmovaps [rsp+0x20], xmm3
0000790c663d2015  vmovaps [rsp+0x30], xmm4
0000790c663d201b  vmovaps [rsp+0x40], xmm5
0000790c663d2021  vmovaps [rsp+0x50], xmm6
0000790c663d2027  vmovaps [rsp+0x60], xmm7
0000790c663d202d  vmovaps [rsp+0x70], xmm8
0000790c663d2033  vmovaps [rsp+0x80], xmm9
0000790c663d203c  vmovaps [rsp+0x90], xmm10
0000790c663d2045  vmovaps [rsp+0xA0], xmm11
0000790c663d204e  vmovaps [rsp+0xB0], xmm12
0000790c663d2057  vmovaps [rsp+0xC0], xmm13
0000790c663d2060  vmovaps [rsp+0xD0], xmm14
0000790c663d2069  vmovaps [rsp+0xE0], xmm15
0000790c663d2072  sub rsp, 0x30
0000790c663d2076  movaps [rsp], xmm2
0000790c663d207a  movaps [rsp+0x10], xmm1
0000790c663d207f  movaps [rsp+0x20], xmm13
0000790c663d2085  lea rdi, [rsp]
0000790c663d2089  mov esi, 0x00
0000790c663d208e  mov rax, 0x631C1759F530
0000790c663d2098  call rax
0000790c663d209a  movaps xmm2, [rsp]
0000790c663d209e  add rsp, 0x30
0000790c663d20a2  vmovaps xmm0, [rsp]
0000790c663d20a7  vmovaps xmm1, [rsp+0x10]
0000790c663d20ad  vmovaps xmm3, [rsp+0x20]
0000790c663d20b3  vmovaps xmm4, [rsp+0x30]
0000790c663d20b9  vmovaps xmm5, [rsp+0x40]
0000790c663d20bf  vmovaps xmm6, [rsp+0x50]
0000790c663d20c5  vmovaps xmm7, [rsp+0x60]
0000790c663d20cb  vmovaps xmm8, [rsp+0x70]
0000790c663d20d1  vmovaps xmm9, [rsp+0x80]
0000790c663d20da  vmovaps xmm10, [rsp+0x90]
0000790c663d20e3  vmovaps xmm11, [rsp+0xA0]
0000790c663d20ec  vmovaps xmm12, [rsp+0xB0]
0000790c663d20f5  vmovaps xmm13, [rsp+0xC0]
0000790c663d20fe  vmovaps xmm14, [rsp+0xD0]
0000790c663d2107  vmovaps xmm15, [rsp+0xE0]
0000790c663d2110  add rsp, 0xF0
0000790c663d2117  pop r11
0000790c663d2119  pop r10
0000790c663d211b  pop r9
0000790c663d211d  pop r8
0000790c663d211f  pop rsi
0000790c663d2120  pop rdi
0000790c663d2121  pop rdx
0000790c663d2122  pop rcx
0000790c663d2123  pop rax
0000790c663d2124  add rsp, 0x08
0000790c663d2128  jmp 0x0000790C663CFBAB
0000790c663d212d  call 0x0000790C661FF430
0000790c663d2132  jmp 0x0000790C663CFBB8
0000790c663d2137  sub rsp, 0x08
0000790c663d213b  push rax
0000790c663d213c  push rcx
0000790c663d213d  push rdx
0000790c663d213e  push rdi
0000790c663d213f  push rsi
0000790c663d2140  push r8
0000790c663d2142  push r9
0000790c663d2144  push r10
0000790c663d2146  push r11
0000790c663d2148  sub rsp, 0xF0
0000790c663d214f  vmovaps [rsp], xmm0
0000790c663d2154  vmovaps [rsp+0x10], xmm1
0000790c663d215a  vmovaps [rsp+0x20], xmm2
0000790c663d2160  vmovaps [rsp+0x30], xmm3
0000790c663d2166  vmovaps [rsp+0x40], xmm4
0000790c663d216c  vmovaps [rsp+0x50], xmm5
0000790c663d2172  vmovaps [rsp+0x60], xmm6
0000790c663d2178  vmovaps [rsp+0x70], xmm7
0000790c663d217e  vmovaps [rsp+0x80], xmm8
0000790c663d2187  vmovaps [rsp+0x90], xmm9
0000790c663d2190  vmovaps [rsp+0xA0], xmm10
0000790c663d2199  vmovaps [rsp+0xB0], xmm11
0000790c663d21a2  vmovaps [rsp+0xC0], xmm12
0000790c663d21ab  vmovaps [rsp+0xD0], xmm13
0000790c663d21b4  vmovaps [rsp+0xE0], xmm14
0000790c663d21bd  sub rsp, 0x30
0000790c663d21c1  movaps [rsp], xmm15
0000790c663d21c6  movaps [rsp+0x10], xmm13
0000790c663d21cc  movaps [rsp+0x20], xmm1
0000790c663d21d1  lea rdi, [rsp]
0000790c663d21d5  mov esi, 0x00
0000790c663d21da  mov rax, 0x631C1759F530
0000790c663d21e4  call rax
0000790c663d21e6  movaps xmm15, [rsp]
0000790c663d21eb  add rsp, 0x30
0000790c663d21ef  vmovaps xmm0, [rsp]
0000790c663d21f4  vmovaps xmm1, [rsp+0x10]
0000790c663d21fa  vmovaps xmm2, [rsp+0x20]
0000790c663d2200  vmovaps xmm3, [rsp+0x30]
0000790c663d2206  vmovaps xmm4, [rsp+0x40]
0000790c663d220c  vmovaps xmm5, [rsp+0x50]
0000790c663d2212  vmovaps xmm6, [rsp+0x60]
0000790c663d2218  vmovaps xmm7, [rsp+0x70]
0000790c663d221e  vmovaps xmm8, [rsp+0x80]
0000790c663d2227  vmovaps xmm9, [rsp+0x90]
0000790c663d2230  vmovaps xmm10, [rsp+0xA0]
0000790c663d2239  vmovaps xmm11, [rsp+0xB0]
0000790c663d2242  vmovaps xmm12, [rsp+0xC0]
0000790c663d224b  vmovaps xmm13, [rsp+0xD0]
0000790c663d2254  vmovaps xmm14, [rsp+0xE0]
0000790c663d225d  add rsp, 0xF0
0000790c663d2264  pop r11
0000790c663d2266  pop r10
0000790c663d2268  pop r9
0000790c663d226a  pop r8
0000790c663d226c  pop rsi
0000790c663d226d  pop rdi
0000790c663d226e  pop rdx
0000790c663d226f  pop rcx
0000790c663d2270  pop rax
0000790c663d2271  add rsp, 0x08
0000790c663d2275  jmp 0x0000790C663CFBF7
0000790c663d227a  sub rsp, 0x08
0000790c663d227e  push rax
0000790c663d227f  push rcx
0000790c663d2280  push rdx
0000790c663d2281  push rdi
0000790c663d2282  push rsi
0000790c663d2283  push r8
0000790c663d2285  push r9
0000790c663d2287  push r10
0000790c663d2289  push r11
0000790c663d228b  sub rsp, 0xF0
0000790c663d2292  vmovaps [rsp], xmm0
0000790c663d2297  vmovaps [rsp+0x10], xmm1
0000790c663d229d  vmovaps [rsp+0x20], xmm2
0000790c663d22a3  vmovaps [rsp+0x30], xmm3
0000790c663d22a9  vmovaps [rsp+0x40], xmm4
0000790c663d22af  vmovaps [rsp+0x50], xmm5
0000790c663d22b5  vmovaps [rsp+0x60], xmm6
0000790c663d22bb  vmovaps [rsp+0x70], xmm7
0000790c663d22c1  vmovaps [rsp+0x80], xmm8
0000790c663d22ca  vmovaps [rsp+0x90], xmm9
0000790c663d22d3  vmovaps [rsp+0xA0], xmm10
0000790c663d22dc  vmovaps [rsp+0xB0], xmm11
0000790c663d22e5  vmovaps [rsp+0xC0], xmm12
0000790c663d22ee  vmovaps [rsp+0xD0], xmm13
0000790c663d22f7  vmovaps [rsp+0xE0], xmm15
0000790c663d2300  sub rsp, 0x30
0000790c663d2304  movaps [rsp], xmm14
0000790c663d2309  movaps [rsp+0x10], xmm11
0000790c663d230f  movaps [rsp+0x20], xmm1
0000790c663d2314  lea rdi, [rsp]
0000790c663d2318  mov esi, 0x00
0000790c663d231d  mov rax, 0x631C1759F530
0000790c663d2327  call rax
0000790c663d2329  movaps xmm14, [rsp]
0000790c663d232e  add rsp, 0x30
0000790c663d2332  vmovaps xmm0, [rsp]
0000790c663d2337  vmovaps xmm1, [rsp+0x10]
0000790c663d233d  vmovaps xmm2, [rsp+0x20]
0000790c663d2343  vmovaps xmm3, [rsp+0x30]
0000790c663d2349  vmovaps xmm4, [rsp+0x40]
0000790c663d234f  vmovaps xmm5, [rsp+0x50]
0000790c663d2355  vmovaps xmm6, [rsp+0x60]
0000790c663d235b  vmovaps xmm7, [rsp+0x70]
0000790c663d2361  vmovaps xmm8, [rsp+0x80]
0000790c663d236a  vmovaps xmm9, [rsp+0x90]
0000790c663d2373  vmovaps xmm10, [rsp+0xA0]
0000790c663d237c  vmovaps xmm11, [rsp+0xB0]
0000790c663d2385  vmovaps xmm12, [rsp+0xC0]
0000790c663d238e  vmovaps xmm13, [rsp+0xD0]
0000790c663d2397  vmovaps xmm15, [rsp+0xE0]
0000790c663d23a0  add rsp, 0xF0
0000790c663d23a7  pop r11
0000790c663d23a9  pop r10
0000790c663d23ab  pop r9
0000790c663d23ad  pop r8
0000790c663d23af  pop rsi
0000790c663d23b0  pop rdi
0000790c663d23b1  pop rdx
0000790c663d23b2  pop rcx
0000790c663d23b3  pop rax
0000790c663d23b4  add rsp, 0x08
0000790c663d23b8  jmp 0x0000790C663CFC21
0000790c663d23bd  sub rsp, 0x08
0000790c663d23c1  push rax
0000790c663d23c2  push rcx
0000790c663d23c3  push rdx
0000790c663d23c4  push rdi
0000790c663d23c5  push rsi
0000790c663d23c6  push r8
0000790c663d23c8  push r9
0000790c663d23ca  push r10
0000790c663d23cc  push r11
0000790c663d23ce  sub rsp, 0xF0
0000790c663d23d5  vmovaps [rsp], xmm0
0000790c663d23da  vmovaps [rsp+0x10], xmm1
0000790c663d23e0  vmovaps [rsp+0x20], xmm2
0000790c663d23e6  vmovaps [rsp+0x30], xmm3
0000790c663d23ec  vmovaps [rsp+0x40], xmm4
0000790c663d23f2  vmovaps [rsp+0x50], xmm5
0000790c663d23f8  vmovaps [rsp+0x60], xmm6
0000790c663d23fe  vmovaps [rsp+0x70], xmm7
0000790c663d2404  vmovaps [rsp+0x80], xmm8
0000790c663d240d  vmovaps [rsp+0x90], xmm9
0000790c663d2416  vmovaps [rsp+0xA0], xmm10
0000790c663d241f  vmovaps [rsp+0xB0], xmm11
0000790c663d2428  vmovaps [rsp+0xC0], xmm12
0000790c663d2431  vmovaps [rsp+0xD0], xmm14
0000790c663d243a  vmovaps [rsp+0xE0], xmm15
0000790c663d2443  sub rsp, 0x30
0000790c663d2447  movaps [rsp], xmm13
0000790c663d244c  movaps [rsp+0x10], xmm11
0000790c663d2452  movaps [rsp+0x20], xmm1
0000790c663d2457  lea rdi, [rsp]
0000790c663d245b  mov esi, 0x00
0000790c663d2460  mov rax, 0x631C1759F530
0000790c663d246a  call rax
0000790c663d246c  movaps xmm13, [rsp]
0000790c663d2471  add rsp, 0x30
0000790c663d2475  vmovaps xmm0, [rsp]
0000790c663d247a  vmovaps xmm1, [rsp+0x10]
0000790c663d2480  vmovaps xmm2, [rsp+0x20]
0000790c663d2486  vmovaps xmm3, [rsp+0x30]
0000790c663d248c  vmovaps xmm4, [rsp+0x40]
0000790c663d2492  vmovaps xmm5, [rsp+0x50]
0000790c663d2498  vmovaps xmm6, [rsp+0x60]
0000790c663d249e  vmovaps xmm7, [rsp+0x70]
0000790c663d24a4  vmovaps xmm8, [rsp+0x80]
0000790c663d24ad  vmovaps xmm9, [rsp+0x90]
0000790c663d24b6  vmovaps xmm10, [rsp+0xA0]
0000790c663d24bf  vmovaps xmm11, [rsp+0xB0]
0000790c663d24c8  vmovaps xmm12, [rsp+0xC0]
0000790c663d24d1  vmovaps xmm14, [rsp+0xD0]
0000790c663d24da  vmovaps xmm15, [rsp+0xE0]
0000790c663d24e3  add rsp, 0xF0
0000790c663d24ea  pop r11
0000790c663d24ec  pop r10
0000790c663d24ee  pop r9
0000790c663d24f0  pop r8
0000790c663d24f2  pop rsi
0000790c663d24f3  pop rdi
0000790c663d24f4  pop rdx
0000790c663d24f5  pop rcx
0000790c663d24f6  pop rax
0000790c663d24f7  add rsp, 0x08
0000790c663d24fb  jmp 0x0000790C663CFC76
0000790c663d2500  call 0x0000790C661FF430
0000790c663d2505  jmp 0x0000790C663CFC83
0000790c663d250a  sub rsp, 0x08
0000790c663d250e  push rax
0000790c663d250f  push rcx
0000790c663d2510  push rdx
0000790c663d2511  push rdi
0000790c663d2512  push rsi
0000790c663d2513  push r8
0000790c663d2515  push r9
0000790c663d2517  push r10
0000790c663d2519  push r11
0000790c663d251b  sub rsp, 0xF0
0000790c663d2522  vmovaps [rsp], xmm0
0000790c663d2527  vmovaps [rsp+0x10], xmm1
0000790c663d252d  vmovaps [rsp+0x20], xmm2
0000790c663d2533  vmovaps [rsp+0x30], xmm3
0000790c663d2539  vmovaps [rsp+0x40], xmm4
0000790c663d253f  vmovaps [rsp+0x50], xmm5
0000790c663d2545  vmovaps [rsp+0x60], xmm6
0000790c663d254b  vmovaps [rsp+0x70], xmm7
0000790c663d2551  vmovaps [rsp+0x80], xmm8
0000790c663d255a  vmovaps [rsp+0x90], xmm9
0000790c663d2563  vmovaps [rsp+0xA0], xmm10
0000790c663d256c  vmovaps [rsp+0xB0], xmm11
0000790c663d2575  vmovaps [rsp+0xC0], xmm12
0000790c663d257e  vmovaps [rsp+0xD0], xmm13
0000790c663d2587  vmovaps [rsp+0xE0], xmm14
0000790c663d2590  sub rsp, 0x30
0000790c663d2594  movaps [rsp], xmm15
0000790c663d2599  movaps [rsp+0x10], xmm11
0000790c663d259f  movaps [rsp+0x20], xmm1
0000790c663d25a4  lea rdi, [rsp]
0000790c663d25a8  mov esi, 0x00
0000790c663d25ad  mov rax, 0x631C1759F530
0000790c663d25b7  call rax
0000790c663d25b9  movaps xmm15, [rsp]
0000790c663d25be  add rsp, 0x30
0000790c663d25c2  vmovaps xmm0, [rsp]
0000790c663d25c7  vmovaps xmm1, [rsp+0x10]
0000790c663d25cd  vmovaps xmm2, [rsp+0x20]
0000790c663d25d3  vmovaps xmm3, [rsp+0x30]
0000790c663d25d9  vmovaps xmm4, [rsp+0x40]
0000790c663d25df  vmovaps xmm5, [rsp+0x50]
0000790c663d25e5  vmovaps xmm6, [rsp+0x60]
0000790c663d25eb  vmovaps xmm7, [rsp+0x70]
0000790c663d25f1  vmovaps xmm8, [rsp+0x80]
0000790c663d25fa  vmovaps xmm9, [rsp+0x90]
0000790c663d2603  vmovaps xmm10, [rsp+0xA0]
0000790c663d260c  vmovaps xmm11, [rsp+0xB0]
0000790c663d2615  vmovaps xmm12, [rsp+0xC0]
0000790c663d261e  vmovaps xmm13, [rsp+0xD0]
0000790c663d2627  vmovaps xmm14, [rsp+0xE0]
0000790c663d2630  add rsp, 0xF0
0000790c663d2637  pop r11
0000790c663d2639  pop r10
0000790c663d263b  pop r9
0000790c663d263d  pop r8
0000790c663d263f  pop rsi
0000790c663d2640  pop rdi
0000790c663d2641  pop rdx
0000790c663d2642  pop rcx
0000790c663d2643  pop rax
0000790c663d2644  add rsp, 0x08
0000790c663d2648  jmp 0x0000790C663CFCBC
0000790c663d264d  sub rsp, 0x08
0000790c663d2651  push rax
0000790c663d2652  push rcx
0000790c663d2653  push rdx
0000790c663d2654  push rdi
0000790c663d2655  push rsi
0000790c663d2656  push r8
0000790c663d2658  push r9
0000790c663d265a  push r10
0000790c663d265c  push r11
0000790c663d265e  sub rsp, 0xF0
0000790c663d2665  vmovaps [rsp], xmm0
0000790c663d266a  vmovaps [rsp+0x10], xmm1
0000790c663d2670  vmovaps [rsp+0x20], xmm2
0000790c663d2676  vmovaps [rsp+0x30], xmm3
0000790c663d267c  vmovaps [rsp+0x40], xmm4
0000790c663d2682  vmovaps [rsp+0x50], xmm5
0000790c663d2688  vmovaps [rsp+0x60], xmm6
0000790c663d268e  vmovaps [rsp+0x70], xmm7
0000790c663d2694  vmovaps [rsp+0x80], xmm8
0000790c663d269d  vmovaps [rsp+0x90], xmm9
0000790c663d26a6  vmovaps [rsp+0xA0], xmm10
0000790c663d26af  vmovaps [rsp+0xB0], xmm12
0000790c663d26b8  vmovaps [rsp+0xC0], xmm13
0000790c663d26c1  vmovaps [rsp+0xD0], xmm14
0000790c663d26ca  vmovaps [rsp+0xE0], xmm15
0000790c663d26d3  sub rsp, 0x30
0000790c663d26d7  movaps [rsp], xmm11
0000790c663d26dc  movaps [rsp+0x10], xmm6
0000790c663d26e1  movaps [rsp+0x20], xmm14
0000790c663d26e7  lea rdi, [rsp]
0000790c663d26eb  mov esi, 0x00
0000790c663d26f0  mov rax, 0x631C1759F530
0000790c663d26fa  call rax
0000790c663d26fc  movaps xmm11, [rsp]
0000790c663d2701  add rsp, 0x30
0000790c663d2705  vmovaps xmm0, [rsp]
0000790c663d270a  vmovaps xmm1, [rsp+0x10]
0000790c663d2710  vmovaps xmm2, [rsp+0x20]
0000790c663d2716  vmovaps xmm3, [rsp+0x30]
0000790c663d271c  vmovaps xmm4, [rsp+0x40]
0000790c663d2722  vmovaps xmm5, [rsp+0x50]
0000790c663d2728  vmovaps xmm6, [rsp+0x60]
0000790c663d272e  vmovaps xmm7, [rsp+0x70]
0000790c663d2734  vmovaps xmm8, [rsp+0x80]
0000790c663d273d  vmovaps xmm9, [rsp+0x90]
0000790c663d2746  vmovaps xmm10, [rsp+0xA0]
0000790c663d274f  vmovaps xmm12, [rsp+0xB0]
0000790c663d2758  vmovaps xmm13, [rsp+0xC0]
0000790c663d2761  vmovaps xmm14, [rsp+0xD0]
0000790c663d276a  vmovaps xmm15, [rsp+0xE0]
0000790c663d2773  add rsp, 0xF0
0000790c663d277a  pop r11
0000790c663d277c  pop r10
0000790c663d277e  pop r9
0000790c663d2780  pop r8
0000790c663d2782  pop rsi
0000790c663d2783  pop rdi
0000790c663d2784  pop rdx
0000790c663d2785  pop rcx
0000790c663d2786  pop rax
0000790c663d2787  add rsp, 0x08
0000790c663d278b  jmp 0x0000790C663CFD34
0000790c663d2790  call 0x0000790C661FF430
0000790c663d2795  jmp 0x0000790C663CFD3E
0000790c663d279a  sub rsp, 0x08
0000790c663d279e  push rax
0000790c663d279f  push rcx
0000790c663d27a0  push rdx
0000790c663d27a1  push rdi
0000790c663d27a2  push rsi
0000790c663d27a3  push r8
0000790c663d27a5  push r9
0000790c663d27a7  push r10
0000790c663d27a9  push r11
0000790c663d27ab  sub rsp, 0xF0
0000790c663d27b2  vmovaps [rsp], xmm0
0000790c663d27b7  vmovaps [rsp+0x10], xmm1
0000790c663d27bd  vmovaps [rsp+0x20], xmm2
0000790c663d27c3  vmovaps [rsp+0x30], xmm3
0000790c663d27c9  vmovaps [rsp+0x40], xmm4
0000790c663d27cf  vmovaps [rsp+0x50], xmm5
0000790c663d27d5  vmovaps [rsp+0x60], xmm6
0000790c663d27db  vmovaps [rsp+0x70], xmm7
0000790c663d27e1  vmovaps [rsp+0x80], xmm8
0000790c663d27ea  vmovaps [rsp+0x90], xmm9
0000790c663d27f3  vmovaps [rsp+0xA0], xmm10
0000790c663d27fc  vmovaps [rsp+0xB0], xmm11
0000790c663d2805  vmovaps [rsp+0xC0], xmm12
0000790c663d280e  vmovaps [rsp+0xD0], xmm13
0000790c663d2817  vmovaps [rsp+0xE0], xmm15
0000790c663d2820  sub rsp, 0x30
0000790c663d2824  movaps [rsp], xmm14
0000790c663d2829  movaps [rsp+0x10], xmm6
0000790c663d282e  movaps [rsp+0x20], xmm2
0000790c663d2833  lea rdi, [rsp]
0000790c663d2837  mov esi, 0x00
0000790c663d283c  mov rax, 0x631C1759F530
0000790c663d2846  call rax
0000790c663d2848  movaps xmm14, [rsp]
0000790c663d284d  add rsp, 0x30
0000790c663d2851  vmovaps xmm0, [rsp]
0000790c663d2856  vmovaps xmm1, [rsp+0x10]
0000790c663d285c  vmovaps xmm2, [rsp+0x20]
0000790c663d2862  vmovaps xmm3, [rsp+0x30]
0000790c663d2868  vmovaps xmm4, [rsp+0x40]
0000790c663d286e  vmovaps xmm5, [rsp+0x50]
0000790c663d2874  vmovaps xmm6, [rsp+0x60]
0000790c663d287a  vmovaps xmm7, [rsp+0x70]
0000790c663d2880  vmovaps xmm8, [rsp+0x80]
0000790c663d2889  vmovaps xmm9, [rsp+0x90]
0000790c663d2892  vmovaps xmm10, [rsp+0xA0]
0000790c663d289b  vmovaps xmm11, [rsp+0xB0]
0000790c663d28a4  vmovaps xmm12, [rsp+0xC0]
0000790c663d28ad  vmovaps xmm13, [rsp+0xD0]
0000790c663d28b6  vmovaps xmm15, [rsp+0xE0]
0000790c663d28bf  add rsp, 0xF0
0000790c663d28c6  pop r11
0000790c663d28c8  pop r10
0000790c663d28ca  pop r9
0000790c663d28cc  pop r8
0000790c663d28ce  pop rsi
0000790c663d28cf  pop rdi
0000790c663d28d0  pop rdx
0000790c663d28d1  pop rcx
0000790c663d28d2  pop rax
0000790c663d28d3  add rsp, 0x08
0000790c663d28d7  jmp 0x0000790C663CFD72
0000790c663d28dc  sub rsp, 0x08
0000790c663d28e0  push rax
0000790c663d28e1  push rcx
0000790c663d28e2  push rdx
0000790c663d28e3  push rdi
0000790c663d28e4  push rsi
0000790c663d28e5  push r8
0000790c663d28e7  push r9
0000790c663d28e9  push r10
0000790c663d28eb  push r11
0000790c663d28ed  sub rsp, 0xF0
0000790c663d28f4  vmovaps [rsp], xmm0
0000790c663d28f9  vmovaps [rsp+0x10], xmm1
0000790c663d28ff  vmovaps [rsp+0x20], xmm2
0000790c663d2905  vmovaps [rsp+0x30], xmm3
0000790c663d290b  vmovaps [rsp+0x40], xmm4
0000790c663d2911  vmovaps [rsp+0x50], xmm5
0000790c663d2917  vmovaps [rsp+0x60], xmm7
0000790c663d291d  vmovaps [rsp+0x70], xmm8
0000790c663d2923  vmovaps [rsp+0x80], xmm9
0000790c663d292c  vmovaps [rsp+0x90], xmm10
0000790c663d2935  vmovaps [rsp+0xA0], xmm11
0000790c663d293e  vmovaps [rsp+0xB0], xmm12
0000790c663d2947  vmovaps [rsp+0xC0], xmm13
0000790c663d2950  vmovaps [rsp+0xD0], xmm14
0000790c663d2959  vmovaps [rsp+0xE0], xmm15
0000790c663d2962  sub rsp, 0x30
0000790c663d2966  movaps [rsp], xmm6
0000790c663d296a  movaps [rsp+0x10], xmm5
0000790c663d296f  movaps [rsp+0x20], xmm1
0000790c663d2974  lea rdi, [rsp]
0000790c663d2978  mov esi, 0x00
0000790c663d297d  mov rax, 0x631C1759F530
0000790c663d2987  call rax
0000790c663d2989  movaps xmm6, [rsp]
0000790c663d298d  add rsp, 0x30
0000790c663d2991  vmovaps xmm0, [rsp]
0000790c663d2996  vmovaps xmm1, [rsp+0x10]
0000790c663d299c  vmovaps xmm2, [rsp+0x20]
0000790c663d29a2  vmovaps xmm3, [rsp+0x30]
0000790c663d29a8  vmovaps xmm4, [rsp+0x40]
0000790c663d29ae  vmovaps xmm5, [rsp+0x50]
0000790c663d29b4  vmovaps xmm7, [rsp+0x60]
0000790c663d29ba  vmovaps xmm8, [rsp+0x70]
0000790c663d29c0  vmovaps xmm9, [rsp+0x80]
0000790c663d29c9  vmovaps xmm10, [rsp+0x90]
0000790c663d29d2  vmovaps xmm11, [rsp+0xA0]
0000790c663d29db  vmovaps xmm12, [rsp+0xB0]
0000790c663d29e4  vmovaps xmm13, [rsp+0xC0]
0000790c663d29ed  vmovaps xmm14, [rsp+0xD0]
0000790c663d29f6  vmovaps xmm15, [rsp+0xE0]
0000790c663d29ff  add rsp, 0xF0
0000790c663d2a06  pop r11
0000790c663d2a08  pop r10
0000790c663d2a0a  pop r9
0000790c663d2a0c  pop r8
0000790c663d2a0e  pop rsi
0000790c663d2a0f  pop rdi
0000790c663d2a10  pop rdx
0000790c663d2a11  pop rcx
0000790c663d2a12  pop rax
0000790c663d2a13  add rsp, 0x08
0000790c663d2a17  jmp 0x0000790C663CFD98
0000790c663d2a1c  sub rsp, 0x08
0000790c663d2a20  push rax
0000790c663d2a21  push rcx
0000790c663d2a22  push rdx
0000790c663d2a23  push rdi
0000790c663d2a24  push rsi
0000790c663d2a25  push r8
0000790c663d2a27  push r9
0000790c663d2a29  push r10
0000790c663d2a2b  push r11
0000790c663d2a2d  sub rsp, 0xF0
0000790c663d2a34  vmovaps [rsp], xmm0
0000790c663d2a39  vmovaps [rsp+0x10], xmm2
0000790c663d2a3f  vmovaps [rsp+0x20], xmm3
0000790c663d2a45  vmovaps [rsp+0x30], xmm4
0000790c663d2a4b  vmovaps [rsp+0x40], xmm5
0000790c663d2a51  vmovaps [rsp+0x50], xmm6
0000790c663d2a57  vmovaps [rsp+0x60], xmm7
0000790c663d2a5d  vmovaps [rsp+0x70], xmm8
0000790c663d2a63  vmovaps [rsp+0x80], xmm9
0000790c663d2a6c  vmovaps [rsp+0x90], xmm10
0000790c663d2a75  vmovaps [rsp+0xA0], xmm11
0000790c663d2a7e  vmovaps [rsp+0xB0], xmm12
0000790c663d2a87  vmovaps [rsp+0xC0], xmm13
0000790c663d2a90  vmovaps [rsp+0xD0], xmm14
0000790c663d2a99  vmovaps [rsp+0xE0], xmm15
0000790c663d2aa2  sub rsp, 0x30
0000790c663d2aa6  movaps [rsp], xmm1
0000790c663d2aaa  movaps [rsp+0x10], xmm5
0000790c663d2aaf  movaps [rsp+0x20], xmm13
0000790c663d2ab5  lea rdi, [rsp]
0000790c663d2ab9  mov esi, 0x00
0000790c663d2abe  mov rax, 0x631C1759F530
0000790c663d2ac8  call rax
0000790c663d2aca  movaps xmm1, [rsp]
0000790c663d2ace  add rsp, 0x30
0000790c663d2ad2  vmovaps xmm0, [rsp]
0000790c663d2ad7  vmovaps xmm2, [rsp+0x10]
0000790c663d2add  vmovaps xmm3, [rsp+0x20]
0000790c663d2ae3  vmovaps xmm4, [rsp+0x30]
0000790c663d2ae9  vmovaps xmm5, [rsp+0x40]
0000790c663d2aef  vmovaps xmm6, [rsp+0x50]
0000790c663d2af5  vmovaps xmm7, [rsp+0x60]
0000790c663d2afb  vmovaps xmm8, [rsp+0x70]
0000790c663d2b01  vmovaps xmm9, [rsp+0x80]
0000790c663d2b0a  vmovaps xmm10, [rsp+0x90]
0000790c663d2b13  vmovaps xmm11, [rsp+0xA0]
0000790c663d2b1c  vmovaps xmm12, [rsp+0xB0]
0000790c663d2b25  vmovaps xmm13, [rsp+0xC0]
0000790c663d2b2e  vmovaps xmm14, [rsp+0xD0]
0000790c663d2b37  vmovaps xmm15, [rsp+0xE0]
0000790c663d2b40  add rsp, 0xF0
0000790c663d2b47  pop r11
0000790c663d2b49  pop r10
0000790c663d2b4b  pop r9
0000790c663d2b4d  pop r8
0000790c663d2b4f  pop rsi
0000790c663d2b50  pop rdi
0000790c663d2b51  pop rdx
0000790c663d2b52  pop rcx
0000790c663d2b53  pop rax
0000790c663d2b54  add rsp, 0x08
0000790c663d2b58  jmp 0x0000790C663CFDB6
0000790c663d2b5d  sub rsp, 0x08
0000790c663d2b61  push rax
0000790c663d2b62  push rcx
0000790c663d2b63  push rdx
0000790c663d2b64  push rdi
0000790c663d2b65  push rsi
0000790c663d2b66  push r8
0000790c663d2b68  push r9
0000790c663d2b6a  push r10
0000790c663d2b6c  push r11
0000790c663d2b6e  sub rsp, 0xF0
0000790c663d2b75  vmovaps [rsp], xmm0
0000790c663d2b7a  vmovaps [rsp+0x10], xmm1
0000790c663d2b80  vmovaps [rsp+0x20], xmm2
0000790c663d2b86  vmovaps [rsp+0x30], xmm3
0000790c663d2b8c  vmovaps [rsp+0x40], xmm4
0000790c663d2b92  vmovaps [rsp+0x50], xmm6
0000790c663d2b98  vmovaps [rsp+0x60], xmm7
0000790c663d2b9e  vmovaps [rsp+0x70], xmm8
0000790c663d2ba4  vmovaps [rsp+0x80], xmm9
0000790c663d2bad  vmovaps [rsp+0x90], xmm10
0000790c663d2bb6  vmovaps [rsp+0xA0], xmm11
0000790c663d2bbf  vmovaps [rsp+0xB0], xmm12
0000790c663d2bc8  vmovaps [rsp+0xC0], xmm13
0000790c663d2bd1  vmovaps [rsp+0xD0], xmm14
0000790c663d2bda  vmovaps [rsp+0xE0], xmm15
0000790c663d2be3  sub rsp, 0x30
0000790c663d2be7  movaps [rsp], xmm5
0000790c663d2beb  movaps [rsp+0x10], xmm2
0000790c663d2bf0  movaps [rsp+0x20], xmm13
0000790c663d2bf6  lea rdi, [rsp]
0000790c663d2bfa  mov esi, 0x00
0000790c663d2bff  mov rax, 0x631C1759F530
0000790c663d2c09  call rax
0000790c663d2c0b  movaps xmm5, [rsp]
0000790c663d2c0f  add rsp, 0x30
0000790c663d2c13  vmovaps xmm0, [rsp]
0000790c663d2c18  vmovaps xmm1, [rsp+0x10]
0000790c663d2c1e  vmovaps xmm2, [rsp+0x20]
0000790c663d2c24  vmovaps xmm3, [rsp+0x30]
0000790c663d2c2a  vmovaps xmm4, [rsp+0x40]
0000790c663d2c30  vmovaps xmm6, [rsp+0x50]
0000790c663d2c36  vmovaps xmm7, [rsp+0x60]
0000790c663d2c3c  vmovaps xmm8, [rsp+0x70]
0000790c663d2c42  vmovaps xmm9, [rsp+0x80]
0000790c663d2c4b  vmovaps xmm10, [rsp+0x90]
0000790c663d2c54  vmovaps xmm11, [rsp+0xA0]
0000790c663d2c5d  vmovaps xmm12, [rsp+0xB0]
0000790c663d2c66  vmovaps xmm13, [rsp+0xC0]
0000790c663d2c6f  vmovaps xmm14, [rsp+0xD0]
0000790c663d2c78  vmovaps xmm15, [rsp+0xE0]
0000790c663d2c81  add rsp, 0xF0
0000790c663d2c88  pop r11
0000790c663d2c8a  pop r10
0000790c663d2c8c  pop r9
0000790c663d2c8e  pop r8
0000790c663d2c90  pop rsi
0000790c663d2c91  pop rdi
0000790c663d2c92  pop rdx
0000790c663d2c93  pop rcx
0000790c663d2c94  pop rax
0000790c663d2c95  add rsp, 0x08
0000790c663d2c99  jmp 0x0000790C663CFDEC
0000790c663d2c9e  sub rsp, 0x08
0000790c663d2ca2  push rax
0000790c663d2ca3  push rcx
0000790c663d2ca4  push rdx
0000790c663d2ca5  push rdi
0000790c663d2ca6  push rsi
0000790c663d2ca7  push r8
0000790c663d2ca9  push r9
0000790c663d2cab  push r10
0000790c663d2cad  push r11
0000790c663d2caf  sub rsp, 0xF0
0000790c663d2cb6  vmovaps [rsp], xmm0
0000790c663d2cbb  vmovaps [rsp+0x10], xmm1
0000790c663d2cc1  vmovaps [rsp+0x20], xmm2
0000790c663d2cc7  vmovaps [rsp+0x30], xmm3
0000790c663d2ccd  vmovaps [rsp+0x40], xmm4
0000790c663d2cd3  vmovaps [rsp+0x50], xmm5
0000790c663d2cd9  vmovaps [rsp+0x60], xmm6
0000790c663d2cdf  vmovaps [rsp+0x70], xmm7
0000790c663d2ce5  vmovaps [rsp+0x80], xmm8
0000790c663d2cee  vmovaps [rsp+0x90], xmm9
0000790c663d2cf7  vmovaps [rsp+0xA0], xmm10
0000790c663d2d00  vmovaps [rsp+0xB0], xmm11
0000790c663d2d09  vmovaps [rsp+0xC0], xmm12
0000790c663d2d12  vmovaps [rsp+0xD0], xmm14
0000790c663d2d1b  vmovaps [rsp+0xE0], xmm15
0000790c663d2d24  sub rsp, 0x30
0000790c663d2d28  movaps [rsp], xmm13
0000790c663d2d2d  movaps [rsp+0x10], xmm10
0000790c663d2d33  movaps [rsp+0x20], xmm1
0000790c663d2d38  lea rdi, [rsp]
0000790c663d2d3c  mov esi, 0x00
0000790c663d2d41  mov rax, 0x631C1759F530
0000790c663d2d4b  call rax
0000790c663d2d4d  movaps xmm13, [rsp]
0000790c663d2d52  add rsp, 0x30
0000790c663d2d56  vmovaps xmm0, [rsp]
0000790c663d2d5b  vmovaps xmm1, [rsp+0x10]
0000790c663d2d61  vmovaps xmm2, [rsp+0x20]
0000790c663d2d67  vmovaps xmm3, [rsp+0x30]
0000790c663d2d6d  vmovaps xmm4, [rsp+0x40]
0000790c663d2d73  vmovaps xmm5, [rsp+0x50]
0000790c663d2d79  vmovaps xmm6, [rsp+0x60]
0000790c663d2d7f  vmovaps xmm7, [rsp+0x70]
0000790c663d2d85  vmovaps xmm8, [rsp+0x80]
0000790c663d2d8e  vmovaps xmm9, [rsp+0x90]
0000790c663d2d97  vmovaps xmm10, [rsp+0xA0]
0000790c663d2da0  vmovaps xmm11, [rsp+0xB0]
0000790c663d2da9  vmovaps xmm12, [rsp+0xC0]
0000790c663d2db2  vmovaps xmm14, [rsp+0xD0]
0000790c663d2dbb  vmovaps xmm15, [rsp+0xE0]
0000790c663d2dc4  add rsp, 0xF0
0000790c663d2dcb  pop r11
0000790c663d2dcd  pop r10
0000790c663d2dcf  pop r9
0000790c663d2dd1  pop r8
0000790c663d2dd3  pop rsi
0000790c663d2dd4  pop rdi
0000790c663d2dd5  pop rdx
0000790c663d2dd6  pop rcx
0000790c663d2dd7  pop rax
0000790c663d2dd8  add rsp, 0x08
0000790c663d2ddc  jmp 0x0000790C663CFE15
0000790c663d2de1  sub rsp, 0x08
0000790c663d2de5  push rax
0000790c663d2de6  push rcx
0000790c663d2de7  push rdx
0000790c663d2de8  push rdi
0000790c663d2de9  push rsi
0000790c663d2dea  push r8
0000790c663d2dec  push r9
0000790c663d2dee  push r10
0000790c663d2df0  push r11
0000790c663d2df2  sub rsp, 0xF0
0000790c663d2df9  vmovaps [rsp], xmm0
0000790c663d2dfe  vmovaps [rsp+0x10], xmm2
0000790c663d2e04  vmovaps [rsp+0x20], xmm3
0000790c663d2e0a  vmovaps [rsp+0x30], xmm4
0000790c663d2e10  vmovaps [rsp+0x40], xmm5
0000790c663d2e16  vmovaps [rsp+0x50], xmm6
0000790c663d2e1c  vmovaps [rsp+0x60], xmm7
0000790c663d2e22  vmovaps [rsp+0x70], xmm8
0000790c663d2e28  vmovaps [rsp+0x80], xmm9
0000790c663d2e31  vmovaps [rsp+0x90], xmm10
0000790c663d2e3a  vmovaps [rsp+0xA0], xmm11
0000790c663d2e43  vmovaps [rsp+0xB0], xmm12
0000790c663d2e4c  vmovaps [rsp+0xC0], xmm13
0000790c663d2e55  vmovaps [rsp+0xD0], xmm14
0000790c663d2e5e  vmovaps [rsp+0xE0], xmm15
0000790c663d2e67  sub rsp, 0x30
0000790c663d2e6b  movaps [rsp], xmm1
0000790c663d2e6f  movaps [rsp+0x10], xmm15
0000790c663d2e75  movaps [rsp+0x20], xmm10
0000790c663d2e7b  lea rdi, [rsp]
0000790c663d2e7f  mov esi, 0x00
0000790c663d2e84  mov rax, 0x631C1759F530
0000790c663d2e8e  call rax
0000790c663d2e90  movaps xmm1, [rsp]
0000790c663d2e94  add rsp, 0x30
0000790c663d2e98  vmovaps xmm0, [rsp]
0000790c663d2e9d  vmovaps xmm2, [rsp+0x10]
0000790c663d2ea3  vmovaps xmm3, [rsp+0x20]
0000790c663d2ea9  vmovaps xmm4, [rsp+0x30]
0000790c663d2eaf  vmovaps xmm5, [rsp+0x40]
0000790c663d2eb5  vmovaps xmm6, [rsp+0x50]
0000790c663d2ebb  vmovaps xmm7, [rsp+0x60]
0000790c663d2ec1  vmovaps xmm8, [rsp+0x70]
0000790c663d2ec7  vmovaps xmm9, [rsp+0x80]
0000790c663d2ed0  vmovaps xmm10, [rsp+0x90]
0000790c663d2ed9  vmovaps xmm11, [rsp+0xA0]
0000790c663d2ee2  vmovaps xmm12, [rsp+0xB0]
0000790c663d2eeb  vmovaps xmm13, [rsp+0xC0]
0000790c663d2ef4  vmovaps xmm14, [rsp+0xD0]
0000790c663d2efd  vmovaps xmm15, [rsp+0xE0]
0000790c663d2f06  add rsp, 0xF0
0000790c663d2f0d  pop r11
0000790c663d2f0f  pop r10
0000790c663d2f11  pop r9
0000790c663d2f13  pop r8
0000790c663d2f15  pop rsi
0000790c663d2f16  pop rdi
0000790c663d2f17  pop rdx
0000790c663d2f18  pop rcx
0000790c663d2f19  pop rax
0000790c663d2f1a  add rsp, 0x08
0000790c663d2f1e  jmp 0x0000790C663CFE34
0000790c663d2f23  sub rsp, 0x08
0000790c663d2f27  push rax
0000790c663d2f28  push rcx
0000790c663d2f29  push rdx
0000790c663d2f2a  push rdi
0000790c663d2f2b  push rsi
0000790c663d2f2c  push r8
0000790c663d2f2e  push r9
0000790c663d2f30  push r10
0000790c663d2f32  push r11
0000790c663d2f34  sub rsp, 0xF0
0000790c663d2f3b  vmovaps [rsp], xmm0
0000790c663d2f40  vmovaps [rsp+0x10], xmm1
0000790c663d2f46  vmovaps [rsp+0x20], xmm2
0000790c663d2f4c  vmovaps [rsp+0x30], xmm3
0000790c663d2f52  vmovaps [rsp+0x40], xmm4
0000790c663d2f58  vmovaps [rsp+0x50], xmm5
0000790c663d2f5e  vmovaps [rsp+0x60], xmm6
0000790c663d2f64  vmovaps [rsp+0x70], xmm7
0000790c663d2f6a  vmovaps [rsp+0x80], xmm8
0000790c663d2f73  vmovaps [rsp+0x90], xmm9
0000790c663d2f7c  vmovaps [rsp+0xA0], xmm10
0000790c663d2f85  vmovaps [rsp+0xB0], xmm11
0000790c663d2f8e  vmovaps [rsp+0xC0], xmm12
0000790c663d2f97  vmovaps [rsp+0xD0], xmm13
0000790c663d2fa0  vmovaps [rsp+0xE0], xmm14
0000790c663d2fa9  sub rsp, 0x30
0000790c663d2fad  movaps [rsp], xmm15
0000790c663d2fb2  movaps [rsp+0x10], xmm10
0000790c663d2fb8  movaps [rsp+0x20], xmm11
0000790c663d2fbe  lea rdi, [rsp]
0000790c663d2fc2  mov esi, 0x00
0000790c663d2fc7  mov rax, 0x631C1759F530
0000790c663d2fd1  call rax
0000790c663d2fd3  movaps xmm15, [rsp]
0000790c663d2fd8  add rsp, 0x30
0000790c663d2fdc  vmovaps xmm0, [rsp]
0000790c663d2fe1  vmovaps xmm1, [rsp+0x10]
0000790c663d2fe7  vmovaps xmm2, [rsp+0x20]
0000790c663d2fed  vmovaps xmm3, [rsp+0x30]
0000790c663d2ff3  vmovaps xmm4, [rsp+0x40]
0000790c663d2ff9  vmovaps xmm5, [rsp+0x50]
0000790c663d2fff  vmovaps xmm6, [rsp+0x60]
0000790c663d3005  vmovaps xmm7, [rsp+0x70]
0000790c663d300b  vmovaps xmm8, [rsp+0x80]
0000790c663d3014  vmovaps xmm9, [rsp+0x90]
0000790c663d301d  vmovaps xmm10, [rsp+0xA0]
0000790c663d3026  vmovaps xmm11, [rsp+0xB0]
0000790c663d302f  vmovaps xmm12, [rsp+0xC0]
0000790c663d3038  vmovaps xmm13, [rsp+0xD0]
0000790c663d3041  vmovaps xmm14, [rsp+0xE0]
0000790c663d304a  add rsp, 0xF0
0000790c663d3051  pop r11
0000790c663d3053  pop r10
0000790c663d3055  pop r9
0000790c663d3057  pop r8
0000790c663d3059  pop rsi
0000790c663d305a  pop rdi
0000790c663d305b  pop rdx
0000790c663d305c  pop rcx
0000790c663d305d  pop rax
0000790c663d305e  add rsp, 0x08
0000790c663d3062  jmp 0x0000790C663CFE57
0000790c663d3067  sub rsp, 0x08
0000790c663d306b  push rax
0000790c663d306c  push rcx
0000790c663d306d  push rdx
0000790c663d306e  push rdi
0000790c663d306f  push rsi
0000790c663d3070  push r8
0000790c663d3072  push r9
0000790c663d3074  push r10
0000790c663d3076  push r11
0000790c663d3078  sub rsp, 0xF0
0000790c663d307f  vmovaps [rsp], xmm0
0000790c663d3084  vmovaps [rsp+0x10], xmm1
0000790c663d308a  vmovaps [rsp+0x20], xmm2
0000790c663d3090  vmovaps [rsp+0x30], xmm3
0000790c663d3096  vmovaps [rsp+0x40], xmm4
0000790c663d309c  vmovaps [rsp+0x50], xmm5
0000790c663d30a2  vmovaps [rsp+0x60], xmm6
0000790c663d30a8  vmovaps [rsp+0x70], xmm7
0000790c663d30ae  vmovaps [rsp+0x80], xmm8
0000790c663d30b7  vmovaps [rsp+0x90], xmm9
0000790c663d30c0  vmovaps [rsp+0xA0], xmm11
0000790c663d30c9  vmovaps [rsp+0xB0], xmm12
0000790c663d30d2  vmovaps [rsp+0xC0], xmm13
0000790c663d30db  vmovaps [rsp+0xD0], xmm14
0000790c663d30e4  vmovaps [rsp+0xE0], xmm15
0000790c663d30ed  sub rsp, 0x30
0000790c663d30f1  movaps [rsp], xmm10
0000790c663d30f6  movaps [rsp+0x10], xmm12
0000790c663d30fc  movaps [rsp+0x20], xmm11
0000790c663d3102  lea rdi, [rsp]
0000790c663d3106  mov esi, 0x00
0000790c663d310b  mov rax, 0x631C1759F530
0000790c663d3115  call rax
0000790c663d3117  movaps xmm10, [rsp]
0000790c663d311c  add rsp, 0x30
0000790c663d3120  vmovaps xmm0, [rsp]
0000790c663d3125  vmovaps xmm1, [rsp+0x10]
0000790c663d312b  vmovaps xmm2, [rsp+0x20]
0000790c663d3131  vmovaps xmm3, [rsp+0x30]
0000790c663d3137  vmovaps xmm4, [rsp+0x40]
0000790c663d313d  vmovaps xmm5, [rsp+0x50]
0000790c663d3143  vmovaps xmm6, [rsp+0x60]
0000790c663d3149  vmovaps xmm7, [rsp+0x70]
0000790c663d314f  vmovaps xmm8, [rsp+0x80]
0000790c663d3158  vmovaps xmm9, [rsp+0x90]
0000790c663d3161  vmovaps xmm11, [rsp+0xA0]
0000790c663d316a  vmovaps xmm12, [rsp+0xB0]
0000790c663d3173  vmovaps xmm13, [rsp+0xC0]
0000790c663d317c  vmovaps xmm14, [rsp+0xD0]
0000790c663d3185  vmovaps xmm15, [rsp+0xE0]
0000790c663d318e  add rsp, 0xF0
0000790c663d3195  pop r11
0000790c663d3197  pop r10
0000790c663d3199  pop r9
0000790c663d319b  pop r8
0000790c663d319d  pop rsi
0000790c663d319e  pop rdi
0000790c663d319f  pop rdx
0000790c663d31a0  pop rcx
0000790c663d31a1  pop rax
0000790c663d31a2  add rsp, 0x08
0000790c663d31a6  jmp 0x0000790C663CFE80
0000790c663d31ab  sub rsp, 0x08
0000790c663d31af  push rax
0000790c663d31b0  push rcx
0000790c663d31b1  push rdx
0000790c663d31b2  push rdi
0000790c663d31b3  push rsi
0000790c663d31b4  push r8
0000790c663d31b6  push r9
0000790c663d31b8  push r10
0000790c663d31ba  push r11
0000790c663d31bc  sub rsp, 0xF0
0000790c663d31c3  vmovaps [rsp], xmm0
0000790c663d31c8  vmovaps [rsp+0x10], xmm1
0000790c663d31ce  vmovaps [rsp+0x20], xmm2
0000790c663d31d4  vmovaps [rsp+0x30], xmm3
0000790c663d31da  vmovaps [rsp+0x40], xmm4
0000790c663d31e0  vmovaps [rsp+0x50], xmm5
0000790c663d31e6  vmovaps [rsp+0x60], xmm6
0000790c663d31ec  vmovaps [rsp+0x70], xmm7
0000790c663d31f2  vmovaps [rsp+0x80], xmm8
0000790c663d31fb  vmovaps [rsp+0x90], xmm9
0000790c663d3204  vmovaps [rsp+0xA0], xmm10
0000790c663d320d  vmovaps [rsp+0xB0], xmm12
0000790c663d3216  vmovaps [rsp+0xC0], xmm13
0000790c663d321f  vmovaps [rsp+0xD0], xmm14
0000790c663d3228  vmovaps [rsp+0xE0], xmm15
0000790c663d3231  sub rsp, 0x30
0000790c663d3235  movaps [rsp], xmm11
0000790c663d323a  movaps [rsp+0x10], xmm2
0000790c663d323f  movaps [rsp+0x20], xmm12
0000790c663d3245  lea rdi, [rsp]
0000790c663d3249  mov esi, 0x00
0000790c663d324e  mov rax, 0x631C1759F530
0000790c663d3258  call rax
0000790c663d325a  movaps xmm11, [rsp]
0000790c663d325f  add rsp, 0x30
0000790c663d3263  vmovaps xmm0, [rsp]
0000790c663d3268  vmovaps xmm1, [rsp+0x10]
0000790c663d326e  vmovaps xmm2, [rsp+0x20]
0000790c663d3274  vmovaps xmm3, [rsp+0x30]
0000790c663d327a  vmovaps xmm4, [rsp+0x40]
0000790c663d3280  vmovaps xmm5, [rsp+0x50]
0000790c663d3286  vmovaps xmm6, [rsp+0x60]
0000790c663d328c  vmovaps xmm7, [rsp+0x70]
0000790c663d3292  vmovaps xmm8, [rsp+0x80]
0000790c663d329b  vmovaps xmm9, [rsp+0x90]
0000790c663d32a4  vmovaps xmm10, [rsp+0xA0]
0000790c663d32ad  vmovaps xmm12, [rsp+0xB0]
0000790c663d32b6  vmovaps xmm13, [rsp+0xC0]
0000790c663d32bf  vmovaps xmm14, [rsp+0xD0]
0000790c663d32c8  vmovaps xmm15, [rsp+0xE0]
0000790c663d32d1  add rsp, 0xF0
0000790c663d32d8  pop r11
0000790c663d32da  pop r10
0000790c663d32dc  pop r9
0000790c663d32de  pop r8
0000790c663d32e0  pop rsi
0000790c663d32e1  pop rdi
0000790c663d32e2  pop rdx
0000790c663d32e3  pop rcx
0000790c663d32e4  pop rax
0000790c663d32e5  add rsp, 0x08
0000790c663d32e9  jmp 0x0000790C663CFEB8
0000790c663d32ee  sub rsp, 0x08
0000790c663d32f2  push rax
0000790c663d32f3  push rcx
0000790c663d32f4  push rdx
0000790c663d32f5  push rdi
0000790c663d32f6  push rsi
0000790c663d32f7  push r8
0000790c663d32f9  push r9
0000790c663d32fb  push r10
0000790c663d32fd  push r11
0000790c663d32ff  sub rsp, 0xF0
0000790c663d3306  vmovaps [rsp], xmm0
0000790c663d330b  vmovaps [rsp+0x10], xmm2
0000790c663d3311  vmovaps [rsp+0x20], xmm3
0000790c663d3317  vmovaps [rsp+0x30], xmm4
0000790c663d331d  vmovaps [rsp+0x40], xmm5
0000790c663d3323  vmovaps [rsp+0x50], xmm6
0000790c663d3329  vmovaps [rsp+0x60], xmm7
0000790c663d332f  vmovaps [rsp+0x70], xmm8
0000790c663d3335  vmovaps [rsp+0x80], xmm9
0000790c663d333e  vmovaps [rsp+0x90], xmm10
0000790c663d3347  vmovaps [rsp+0xA0], xmm11
0000790c663d3350  vmovaps [rsp+0xB0], xmm12
0000790c663d3359  vmovaps [rsp+0xC0], xmm13
0000790c663d3362  vmovaps [rsp+0xD0], xmm14
0000790c663d336b  vmovaps [rsp+0xE0], xmm15
0000790c663d3374  sub rsp, 0x30
0000790c663d3378  movaps [rsp], xmm1
0000790c663d337c  movaps [rsp+0x10], xmm14
0000790c663d3382  movaps [rsp+0x20], xmm6
0000790c663d3387  lea rdi, [rsp]
0000790c663d338b  mov esi, 0x00
0000790c663d3390  mov rax, 0x631C1759F530
0000790c663d339a  call rax
0000790c663d339c  movaps xmm1, [rsp]
0000790c663d33a0  add rsp, 0x30
0000790c663d33a4  vmovaps xmm0, [rsp]
0000790c663d33a9  vmovaps xmm2, [rsp+0x10]
0000790c663d33af  vmovaps xmm3, [rsp+0x20]
0000790c663d33b5  vmovaps xmm4, [rsp+0x30]
0000790c663d33bb  vmovaps xmm5, [rsp+0x40]
0000790c663d33c1  vmovaps xmm6, [rsp+0x50]
0000790c663d33c7  vmovaps xmm7, [rsp+0x60]
0000790c663d33cd  vmovaps xmm8, [rsp+0x70]
0000790c663d33d3  vmovaps xmm9, [rsp+0x80]
0000790c663d33dc  vmovaps xmm10, [rsp+0x90]
0000790c663d33e5  vmovaps xmm11, [rsp+0xA0]
0000790c663d33ee  vmovaps xmm12, [rsp+0xB0]
0000790c663d33f7  vmovaps xmm13, [rsp+0xC0]
0000790c663d3400  vmovaps xmm14, [rsp+0xD0]
0000790c663d3409  vmovaps xmm15, [rsp+0xE0]
0000790c663d3412  add rsp, 0xF0
0000790c663d3419  pop r11
0000790c663d341b  pop r10
0000790c663d341d  pop r9
0000790c663d341f  pop r8
0000790c663d3421  pop rsi
0000790c663d3422  pop rdi
0000790c663d3423  pop rdx
0000790c663d3424  pop rcx
0000790c663d3425  pop rax
0000790c663d3426  add rsp, 0x08
0000790c663d342a  jmp 0x0000790C663CFED1
0000790c663d342f  sub rsp, 0x08
0000790c663d3433  push rax
0000790c663d3434  push rcx
0000790c663d3435  push rdx
0000790c663d3436  push rdi
0000790c663d3437  push rsi
0000790c663d3438  push r8
0000790c663d343a  push r9
0000790c663d343c  push r10
0000790c663d343e  push r11
0000790c663d3440  sub rsp, 0xF0
0000790c663d3447  vmovaps [rsp], xmm0
0000790c663d344c  vmovaps [rsp+0x10], xmm1
0000790c663d3452  vmovaps [rsp+0x20], xmm2
0000790c663d3458  vmovaps [rsp+0x30], xmm3
0000790c663d345e  vmovaps [rsp+0x40], xmm4
0000790c663d3464  vmovaps [rsp+0x50], xmm5
0000790c663d346a  vmovaps [rsp+0x60], xmm6
0000790c663d3470  vmovaps [rsp+0x70], xmm7
0000790c663d3476  vmovaps [rsp+0x80], xmm8
0000790c663d347f  vmovaps [rsp+0x90], xmm9
0000790c663d3488  vmovaps [rsp+0xA0], xmm10
0000790c663d3491  vmovaps [rsp+0xB0], xmm11
0000790c663d349a  vmovaps [rsp+0xC0], xmm12
0000790c663d34a3  vmovaps [rsp+0xD0], xmm13
0000790c663d34ac  vmovaps [rsp+0xE0], xmm15
0000790c663d34b5  sub rsp, 0x30
0000790c663d34b9  movaps [rsp], xmm14
0000790c663d34be  movaps [rsp+0x10], xmm12
0000790c663d34c4  movaps [rsp+0x20], xmm5
0000790c663d34c9  lea rdi, [rsp]
0000790c663d34cd  mov esi, 0x00
0000790c663d34d2  mov rax, 0x631C1759F530
0000790c663d34dc  call rax
0000790c663d34de  movaps xmm14, [rsp]
0000790c663d34e3  add rsp, 0x30
0000790c663d34e7  vmovaps xmm0, [rsp]
0000790c663d34ec  vmovaps xmm1, [rsp+0x10]
0000790c663d34f2  vmovaps xmm2, [rsp+0x20]
0000790c663d34f8  vmovaps xmm3, [rsp+0x30]
0000790c663d34fe  vmovaps xmm4, [rsp+0x40]
0000790c663d3504  vmovaps xmm5, [rsp+0x50]
0000790c663d350a  vmovaps xmm6, [rsp+0x60]
0000790c663d3510  vmovaps xmm7, [rsp+0x70]
0000790c663d3516  vmovaps xmm8, [rsp+0x80]
0000790c663d351f  vmovaps xmm9, [rsp+0x90]
0000790c663d3528  vmovaps xmm10, [rsp+0xA0]
0000790c663d3531  vmovaps xmm11, [rsp+0xB0]
0000790c663d353a  vmovaps xmm12, [rsp+0xC0]
0000790c663d3543  vmovaps xmm13, [rsp+0xD0]
0000790c663d354c  vmovaps xmm15, [rsp+0xE0]
0000790c663d3555  add rsp, 0xF0
0000790c663d355c  pop r11
0000790c663d355e  pop r10
0000790c663d3560  pop r9
0000790c663d3562  pop r8
0000790c663d3564  pop rsi
0000790c663d3565  pop rdi
0000790c663d3566  pop rdx
0000790c663d3567  pop rcx
0000790c663d3568  pop rax
0000790c663d3569  add rsp, 0x08
0000790c663d356d  jmp 0x0000790C663CFEF1
0000790c663d3572  sub rsp, 0x08
0000790c663d3576  push rax
0000790c663d3577  push rcx
0000790c663d3578  push rdx
0000790c663d3579  push rdi
0000790c663d357a  push rsi
0000790c663d357b  push r8
0000790c663d357d  push r9
0000790c663d357f  push r10
0000790c663d3581  push r11
0000790c663d3583  sub rsp, 0xF0
0000790c663d358a  vmovaps [rsp], xmm0
0000790c663d358f  vmovaps [rsp+0x10], xmm1
0000790c663d3595  vmovaps [rsp+0x20], xmm2
0000790c663d359b  vmovaps [rsp+0x30], xmm3
0000790c663d35a1  vmovaps [rsp+0x40], xmm4
0000790c663d35a7  vmovaps [rsp+0x50], xmm5
0000790c663d35ad  vmovaps [rsp+0x60], xmm7
0000790c663d35b3  vmovaps [rsp+0x70], xmm8
0000790c663d35b9  vmovaps [rsp+0x80], xmm9
0000790c663d35c2  vmovaps [rsp+0x90], xmm10
0000790c663d35cb  vmovaps [rsp+0xA0], xmm11
0000790c663d35d4  vmovaps [rsp+0xB0], xmm12
0000790c663d35dd  vmovaps [rsp+0xC0], xmm13
0000790c663d35e6  vmovaps [rsp+0xD0], xmm14
0000790c663d35ef  vmovaps [rsp+0xE0], xmm15
0000790c663d35f8  sub rsp, 0x30
0000790c663d35fc  movaps [rsp], xmm6
0000790c663d3600  movaps [rsp+0x10], xmm9
0000790c663d3606  movaps [rsp+0x20], xmm12
0000790c663d360c  lea rdi, [rsp]
0000790c663d3610  mov esi, 0x00
0000790c663d3615  mov rax, 0x631C1759F530
0000790c663d361f  call rax
0000790c663d3621  movaps xmm6, [rsp]
0000790c663d3625  add rsp, 0x30
0000790c663d3629  vmovaps xmm0, [rsp]
0000790c663d362e  vmovaps xmm1, [rsp+0x10]
0000790c663d3634  vmovaps xmm2, [rsp+0x20]
0000790c663d363a  vmovaps xmm3, [rsp+0x30]
0000790c663d3640  vmovaps xmm4, [rsp+0x40]
0000790c663d3646  vmovaps xmm5, [rsp+0x50]
0000790c663d364c  vmovaps xmm7, [rsp+0x60]
0000790c663d3652  vmovaps xmm8, [rsp+0x70]
0000790c663d3658  vmovaps xmm9, [rsp+0x80]
0000790c663d3661  vmovaps xmm10, [rsp+0x90]
0000790c663d366a  vmovaps xmm11, [rsp+0xA0]
0000790c663d3673  vmovaps xmm12, [rsp+0xB0]
0000790c663d367c  vmovaps xmm13, [rsp+0xC0]
0000790c663d3685  vmovaps xmm14, [rsp+0xD0]
0000790c663d368e  vmovaps xmm15, [rsp+0xE0]
0000790c663d3697  add rsp, 0xF0
0000790c663d369e  pop r11
0000790c663d36a0  pop r10
0000790c663d36a2  pop r9
0000790c663d36a4  pop r8
0000790c663d36a6  pop rsi
0000790c663d36a7  pop rdi
0000790c663d36a8  pop rdx
0000790c663d36a9  pop rcx
0000790c663d36aa  pop rax
0000790c663d36ab  add rsp, 0x08
0000790c663d36af  jmp 0x0000790C663CFF19
0000790c663d36b4  sub rsp, 0x08
0000790c663d36b8  push rax
0000790c663d36b9  push rcx
0000790c663d36ba  push rdx
0000790c663d36bb  push rdi
0000790c663d36bc  push rsi
0000790c663d36bd  push r8
0000790c663d36bf  push r9
0000790c663d36c1  push r10
0000790c663d36c3  push r11
0000790c663d36c5  sub rsp, 0xF0
0000790c663d36cc  vmovaps [rsp], xmm0
0000790c663d36d1  vmovaps [rsp+0x10], xmm1
0000790c663d36d7  vmovaps [rsp+0x20], xmm2
0000790c663d36dd  vmovaps [rsp+0x30], xmm3
0000790c663d36e3  vmovaps [rsp+0x40], xmm4
0000790c663d36e9  vmovaps [rsp+0x50], xmm5
0000790c663d36ef  vmovaps [rsp+0x60], xmm6
0000790c663d36f5  vmovaps [rsp+0x70], xmm7
0000790c663d36fb  vmovaps [rsp+0x80], xmm8
0000790c663d3704  vmovaps [rsp+0x90], xmm9
0000790c663d370d  vmovaps [rsp+0xA0], xmm10
0000790c663d3716  vmovaps [rsp+0xB0], xmm11
0000790c663d371f  vmovaps [rsp+0xC0], xmm13
0000790c663d3728  vmovaps [rsp+0xD0], xmm14
0000790c663d3731  vmovaps [rsp+0xE0], xmm15
0000790c663d373a  sub rsp, 0x30
0000790c663d373e  movaps [rsp], xmm12
0000790c663d3743  movaps [rsp+0x10], xmm15
0000790c663d3749  movaps [rsp+0x20], xmm13
0000790c663d374f  lea rdi, [rsp]
0000790c663d3753  mov esi, 0x00
0000790c663d3758  mov rax, 0x631C1759F530
0000790c663d3762  call rax
0000790c663d3764  movaps xmm12, [rsp]
0000790c663d3769  add rsp, 0x30
0000790c663d376d  vmovaps xmm0, [rsp]
0000790c663d3772  vmovaps xmm1, [rsp+0x10]
0000790c663d3778  vmovaps xmm2, [rsp+0x20]
0000790c663d377e  vmovaps xmm3, [rsp+0x30]
0000790c663d3784  vmovaps xmm4, [rsp+0x40]
0000790c663d378a  vmovaps xmm5, [rsp+0x50]
0000790c663d3790  vmovaps xmm6, [rsp+0x60]
0000790c663d3796  vmovaps xmm7, [rsp+0x70]
0000790c663d379c  vmovaps xmm8, [rsp+0x80]
0000790c663d37a5  vmovaps xmm9, [rsp+0x90]
0000790c663d37ae  vmovaps xmm10, [rsp+0xA0]
0000790c663d37b7  vmovaps xmm11, [rsp+0xB0]
0000790c663d37c0  vmovaps xmm13, [rsp+0xC0]
0000790c663d37c9  vmovaps xmm14, [rsp+0xD0]
0000790c663d37d2  vmovaps xmm15, [rsp+0xE0]
0000790c663d37db  add rsp, 0xF0
0000790c663d37e2  pop r11
0000790c663d37e4  pop r10
0000790c663d37e6  pop r9
0000790c663d37e8  pop r8
0000790c663d37ea  pop rsi
0000790c663d37eb  pop rdi
0000790c663d37ec  pop rdx
0000790c663d37ed  pop rcx
0000790c663d37ee  pop rax
0000790c663d37ef  add rsp, 0x08
0000790c663d37f3  jmp 0x0000790C663CFF34
0000790c663d37f8  sub rsp, 0x08
0000790c663d37fc  push rax
0000790c663d37fd  push rcx
0000790c663d37fe  push rdx
0000790c663d37ff  push rdi
0000790c663d3800  push rsi
0000790c663d3801  push r8
0000790c663d3803  push r9
0000790c663d3805  push r10
0000790c663d3807  push r11
0000790c663d3809  sub rsp, 0xF0
0000790c663d3810  vmovaps [rsp], xmm0
0000790c663d3815  vmovaps [rsp+0x10], xmm1
0000790c663d381b  vmovaps [rsp+0x20], xmm2
0000790c663d3821  vmovaps [rsp+0x30], xmm3
0000790c663d3827  vmovaps [rsp+0x40], xmm4
0000790c663d382d  vmovaps [rsp+0x50], xmm5
0000790c663d3833  vmovaps [rsp+0x60], xmm6
0000790c663d3839  vmovaps [rsp+0x70], xmm7
0000790c663d383f  vmovaps [rsp+0x80], xmm8
0000790c663d3848  vmovaps [rsp+0x90], xmm9
0000790c663d3851  vmovaps [rsp+0xA0], xmm10
0000790c663d385a  vmovaps [rsp+0xB0], xmm11
0000790c663d3863  vmovaps [rsp+0xC0], xmm12
0000790c663d386c  vmovaps [rsp+0xD0], xmm13
0000790c663d3875  vmovaps [rsp+0xE0], xmm14
0000790c663d387e  sub rsp, 0x30
0000790c663d3882  movaps [rsp], xmm15
0000790c663d3887  movaps [rsp+0x10], xmm13
0000790c663d388d  movaps [rsp+0x20], xmm10
0000790c663d3893  lea rdi, [rsp]
0000790c663d3897  mov esi, 0x00
0000790c663d389c  mov rax, 0x631C1759F530
0000790c663d38a6  call rax
0000790c663d38a8  movaps xmm15, [rsp]
0000790c663d38ad  add rsp, 0x30
0000790c663d38b1  vmovaps xmm0, [rsp]
0000790c663d38b6  vmovaps xmm1, [rsp+0x10]
0000790c663d38bc  vmovaps xmm2, [rsp+0x20]
0000790c663d38c2  vmovaps xmm3, [rsp+0x30]
0000790c663d38c8  vmovaps xmm4, [rsp+0x40]
0000790c663d38ce  vmovaps xmm5, [rsp+0x50]
0000790c663d38d4  vmovaps xmm6, [rsp+0x60]
0000790c663d38da  vmovaps xmm7, [rsp+0x70]
0000790c663d38e0  vmovaps xmm8, [rsp+0x80]
0000790c663d38e9  vmovaps xmm9, [rsp+0x90]
0000790c663d38f2  vmovaps xmm10, [rsp+0xA0]
0000790c663d38fb  vmovaps xmm11, [rsp+0xB0]
0000790c663d3904  vmovaps xmm12, [rsp+0xC0]
0000790c663d390d  vmovaps xmm13, [rsp+0xD0]
0000790c663d3916  vmovaps xmm14, [rsp+0xE0]
0000790c663d391f  add rsp, 0xF0
0000790c663d3926  pop r11
0000790c663d3928  pop r10
0000790c663d392a  pop r9
0000790c663d392c  pop r8
0000790c663d392e  pop rsi
0000790c663d392f  pop rdi
0000790c663d3930  pop rdx
0000790c663d3931  pop rcx
0000790c663d3932  pop rax
0000790c663d3933  add rsp, 0x08
0000790c663d3937  jmp 0x0000790C663CFF55
0000790c663d393c  call 0x0000790C6620C260
0000790c663d3941  jmp 0x0000790C663CFFB0
0000790c663d3946  sub rsp, 0x08
0000790c663d394a  push rax
0000790c663d394b  push rcx
0000790c663d394c  push rdx
0000790c663d394d  push rdi
0000790c663d394e  push rsi
0000790c663d394f  push r8
0000790c663d3951  push r9
0000790c663d3953  push r10
0000790c663d3955  push r11
0000790c663d3957  sub rsp, 0xF0
0000790c663d395e  vmovaps [rsp], xmm0
0000790c663d3963  vmovaps [rsp+0x10], xmm1
0000790c663d3969  vmovaps [rsp+0x20], xmm2
0000790c663d396f  vmovaps [rsp+0x30], xmm3
0000790c663d3975  vmovaps [rsp+0x40], xmm4
0000790c663d397b  vmovaps [rsp+0x50], xmm5
0000790c663d3981  vmovaps [rsp+0x60], xmm6
0000790c663d3987  vmovaps [rsp+0x70], xmm7
0000790c663d398d  vmovaps [rsp+0x80], xmm8
0000790c663d3996  vmovaps [rsp+0x90], xmm10
0000790c663d399f  vmovaps [rsp+0xA0], xmm11
0000790c663d39a8  vmovaps [rsp+0xB0], xmm12
0000790c663d39b1  vmovaps [rsp+0xC0], xmm13
0000790c663d39ba  vmovaps [rsp+0xD0], xmm14
0000790c663d39c3  vmovaps [rsp+0xE0], xmm15
0000790c663d39cc  sub rsp, 0x30
0000790c663d39d0  movaps [rsp], xmm9
0000790c663d39d5  movaps [rsp+0x10], xmm8
0000790c663d39db  movaps [rsp+0x20], xmm10
0000790c663d39e1  lea rdi, [rsp]
0000790c663d39e5  mov esi, 0x00
0000790c663d39ea  mov rax, 0x631C1759F530
0000790c663d39f4  call rax
0000790c663d39f6  movaps xmm9, [rsp]
0000790c663d39fb  add rsp, 0x30
0000790c663d39ff  vmovaps xmm0, [rsp]
0000790c663d3a04  vmovaps xmm1, [rsp+0x10]
0000790c663d3a0a  vmovaps xmm2, [rsp+0x20]
0000790c663d3a10  vmovaps xmm3, [rsp+0x30]
0000790c663d3a16  vmovaps xmm4, [rsp+0x40]
0000790c663d3a1c  vmovaps xmm5, [rsp+0x50]
0000790c663d3a22  vmovaps xmm6, [rsp+0x60]
0000790c663d3a28  vmovaps xmm7, [rsp+0x70]
0000790c663d3a2e  vmovaps xmm8, [rsp+0x80]
0000790c663d3a37  vmovaps xmm10, [rsp+0x90]
0000790c663d3a40  vmovaps xmm11, [rsp+0xA0]
0000790c663d3a49  vmovaps xmm12, [rsp+0xB0]
0000790c663d3a52  vmovaps xmm13, [rsp+0xC0]
0000790c663d3a5b  vmovaps xmm14, [rsp+0xD0]
0000790c663d3a64  vmovaps xmm15, [rsp+0xE0]
0000790c663d3a6d  add rsp, 0xF0
0000790c663d3a74  pop r11
0000790c663d3a76  pop r10
0000790c663d3a78  pop r9
0000790c663d3a7a  pop r8
0000790c663d3a7c  pop rsi
0000790c663d3a7d  pop rdi
0000790c663d3a7e  pop rdx
0000790c663d3a7f  pop rcx
0000790c663d3a80  pop rax
0000790c663d3a81  add rsp, 0x08
0000790c663d3a85  jmp 0x0000790C663CFFE1
0000790c663d3a8a  sub rsp, 0x08
0000790c663d3a8e  push rax
0000790c663d3a8f  push rcx
0000790c663d3a90  push rdx
0000790c663d3a91  push rdi
0000790c663d3a92  push rsi
0000790c663d3a93  push r8
0000790c663d3a95  push r9
0000790c663d3a97  push r10
0000790c663d3a99  push r11
0000790c663d3a9b  sub rsp, 0xF0
0000790c663d3aa2  vmovaps [rsp], xmm0
0000790c663d3aa7  vmovaps [rsp+0x10], xmm1
0000790c663d3aad  vmovaps [rsp+0x20], xmm2
0000790c663d3ab3  vmovaps [rsp+0x30], xmm3
0000790c663d3ab9  vmovaps [rsp+0x40], xmm4
0000790c663d3abf  vmovaps [rsp+0x50], xmm5
0000790c663d3ac5  vmovaps [rsp+0x60], xmm6
0000790c663d3acb  vmovaps [rsp+0x70], xmm7
0000790c663d3ad1  vmovaps [rsp+0x80], xmm8
0000790c663d3ada  vmovaps [rsp+0x90], xmm9
0000790c663d3ae3  vmovaps [rsp+0xA0], xmm11
0000790c663d3aec  vmovaps [rsp+0xB0], xmm12
0000790c663d3af5  vmovaps [rsp+0xC0], xmm13
0000790c663d3afe  vmovaps [rsp+0xD0], xmm14
0000790c663d3b07  vmovaps [rsp+0xE0], xmm15
0000790c663d3b10  sub rsp, 0x30
0000790c663d3b14  movaps [rsp], xmm10
0000790c663d3b19  movaps [rsp+0x10], xmm1
0000790c663d3b1e  movaps [rsp+0x20], xmm11
0000790c663d3b24  lea rdi, [rsp]
0000790c663d3b28  mov esi, 0x00
0000790c663d3b2d  mov rax, 0x631C1759F530
0000790c663d3b37  call rax
0000790c663d3b39  movaps xmm10, [rsp]
0000790c663d3b3e  add rsp, 0x30
0000790c663d3b42  vmovaps xmm0, [rsp]
0000790c663d3b47  vmovaps xmm1, [rsp+0x10]
0000790c663d3b4d  vmovaps xmm2, [rsp+0x20]
0000790c663d3b53  vmovaps xmm3, [rsp+0x30]
0000790c663d3b59  vmovaps xmm4, [rsp+0x40]
0000790c663d3b5f  vmovaps xmm5, [rsp+0x50]
0000790c663d3b65  vmovaps xmm6, [rsp+0x60]
0000790c663d3b6b  vmovaps xmm7, [rsp+0x70]
0000790c663d3b71  vmovaps xmm8, [rsp+0x80]
0000790c663d3b7a  vmovaps xmm9, [rsp+0x90]
0000790c663d3b83  vmovaps xmm11, [rsp+0xA0]
0000790c663d3b8c  vmovaps xmm12, [rsp+0xB0]
0000790c663d3b95  vmovaps xmm13, [rsp+0xC0]
0000790c663d3b9e  vmovaps xmm14, [rsp+0xD0]
0000790c663d3ba7  vmovaps xmm15, [rsp+0xE0]
0000790c663d3bb0  add rsp, 0xF0
0000790c663d3bb7  pop r11
0000790c663d3bb9  pop r10
0000790c663d3bbb  pop r9
0000790c663d3bbd  pop r8
0000790c663d3bbf  pop rsi
0000790c663d3bc0  pop rdi
0000790c663d3bc1  pop rdx
0000790c663d3bc2  pop rcx
0000790c663d3bc3  pop rax
0000790c663d3bc4  add rsp, 0x08
0000790c663d3bc8  jmp 0x0000790C663CFFFC
0000790c663d3bcd  sub rsp, 0x08
0000790c663d3bd1  push rax
0000790c663d3bd2  push rcx
0000790c663d3bd3  push rdx
0000790c663d3bd4  push rdi
0000790c663d3bd5  push rsi
0000790c663d3bd6  push r8
0000790c663d3bd8  push r9
0000790c663d3bda  push r10
0000790c663d3bdc  push r11
0000790c663d3bde  sub rsp, 0xF0
0000790c663d3be5  vmovaps [rsp], xmm0
0000790c663d3bea  vmovaps [rsp+0x10], xmm2
0000790c663d3bf0  vmovaps [rsp+0x20], xmm3
0000790c663d3bf6  vmovaps [rsp+0x30], xmm4
0000790c663d3bfc  vmovaps [rsp+0x40], xmm5
0000790c663d3c02  vmovaps [rsp+0x50], xmm6
0000790c663d3c08  vmovaps [rsp+0x60], xmm7
0000790c663d3c0e  vmovaps [rsp+0x70], xmm8
0000790c663d3c14  vmovaps [rsp+0x80], xmm9
0000790c663d3c1d  vmovaps [rsp+0x90], xmm10
0000790c663d3c26  vmovaps [rsp+0xA0], xmm11
0000790c663d3c2f  vmovaps [rsp+0xB0], xmm12
0000790c663d3c38  vmovaps [rsp+0xC0], xmm13
0000790c663d3c41  vmovaps [rsp+0xD0], xmm14
0000790c663d3c4a  vmovaps [rsp+0xE0], xmm15
0000790c663d3c53  sub rsp, 0x30
0000790c663d3c57  movaps [rsp], xmm1
0000790c663d3c5b  movaps [rsp+0x10], xmm14
0000790c663d3c61  movaps [rsp+0x20], xmm6
0000790c663d3c66  lea rdi, [rsp]
0000790c663d3c6a  mov esi, 0x00
0000790c663d3c6f  mov rax, 0x631C1759F530
0000790c663d3c79  call rax
0000790c663d3c7b  movaps xmm1, [rsp]
0000790c663d3c7f  add rsp, 0x30
0000790c663d3c83  vmovaps xmm0, [rsp]
0000790c663d3c88  vmovaps xmm2, [rsp+0x10]
0000790c663d3c8e  vmovaps xmm3, [rsp+0x20]
0000790c663d3c94  vmovaps xmm4, [rsp+0x30]
0000790c663d3c9a  vmovaps xmm5, [rsp+0x40]
0000790c663d3ca0  vmovaps xmm6, [rsp+0x50]
0000790c663d3ca6  vmovaps xmm7, [rsp+0x60]
0000790c663d3cac  vmovaps xmm8, [rsp+0x70]
0000790c663d3cb2  vmovaps xmm9, [rsp+0x80]
0000790c663d3cbb  vmovaps xmm10, [rsp+0x90]
0000790c663d3cc4  vmovaps xmm11, [rsp+0xA0]
0000790c663d3ccd  vmovaps xmm12, [rsp+0xB0]
0000790c663d3cd6  vmovaps xmm13, [rsp+0xC0]
0000790c663d3cdf  vmovaps xmm14, [rsp+0xD0]
0000790c663d3ce8  vmovaps xmm15, [rsp+0xE0]
0000790c663d3cf1  add rsp, 0xF0
0000790c663d3cf8  pop r11
0000790c663d3cfa  pop r10
0000790c663d3cfc  pop r9
0000790c663d3cfe  pop r8
0000790c663d3d00  pop rsi
0000790c663d3d01  pop rdi
0000790c663d3d02  pop rdx
0000790c663d3d03  pop rcx
0000790c663d3d04  pop rax
0000790c663d3d05  add rsp, 0x08
0000790c663d3d09  jmp 0x0000790C663D0015
0000790c663d3d0e  sub rsp, 0x08
0000790c663d3d12  push rax
0000790c663d3d13  push rcx
0000790c663d3d14  push rdx
0000790c663d3d15  push rdi
0000790c663d3d16  push rsi
0000790c663d3d17  push r8
0000790c663d3d19  push r9
0000790c663d3d1b  push r10
0000790c663d3d1d  push r11
0000790c663d3d1f  sub rsp, 0xF0
0000790c663d3d26  vmovaps [rsp], xmm0
0000790c663d3d2b  vmovaps [rsp+0x10], xmm1
0000790c663d3d31  vmovaps [rsp+0x20], xmm2
0000790c663d3d37  vmovaps [rsp+0x30], xmm3
0000790c663d3d3d  vmovaps [rsp+0x40], xmm4
0000790c663d3d43  vmovaps [rsp+0x50], xmm5
0000790c663d3d49  vmovaps [rsp+0x60], xmm6
0000790c663d3d4f  vmovaps [rsp+0x70], xmm7
0000790c663d3d55  vmovaps [rsp+0x80], xmm8
0000790c663d3d5e  vmovaps [rsp+0x90], xmm9
0000790c663d3d67  vmovaps [rsp+0xA0], xmm10
0000790c663d3d70  vmovaps [rsp+0xB0], xmm12
0000790c663d3d79  vmovaps [rsp+0xC0], xmm13
0000790c663d3d82  vmovaps [rsp+0xD0], xmm14
0000790c663d3d8b  vmovaps [rsp+0xE0], xmm15
0000790c663d3d94  sub rsp, 0x30
0000790c663d3d98  movaps [rsp], xmm11
0000790c663d3d9d  movaps [rsp+0x10], xmm13
0000790c663d3da3  movaps [rsp+0x20], xmm14
0000790c663d3da9  lea rdi, [rsp]
0000790c663d3dad  mov esi, 0x00
0000790c663d3db2  mov rax, 0x631C1759F530
0000790c663d3dbc  call rax
0000790c663d3dbe  movaps xmm11, [rsp]
0000790c663d3dc3  add rsp, 0x30
0000790c663d3dc7  vmovaps xmm0, [rsp]
0000790c663d3dcc  vmovaps xmm1, [rsp+0x10]
0000790c663d3dd2  vmovaps xmm2, [rsp+0x20]
0000790c663d3dd8  vmovaps xmm3, [rsp+0x30]
0000790c663d3dde  vmovaps xmm4, [rsp+0x40]
0000790c663d3de4  vmovaps xmm5, [rsp+0x50]
0000790c663d3dea  vmovaps xmm6, [rsp+0x60]
0000790c663d3df0  vmovaps xmm7, [rsp+0x70]
0000790c663d3df6  vmovaps xmm8, [rsp+0x80]
0000790c663d3dff  vmovaps xmm9, [rsp+0x90]
0000790c663d3e08  vmovaps xmm10, [rsp+0xA0]
0000790c663d3e11  vmovaps xmm12, [rsp+0xB0]
0000790c663d3e1a  vmovaps xmm13, [rsp+0xC0]
0000790c663d3e23  vmovaps xmm14, [rsp+0xD0]
0000790c663d3e2c  vmovaps xmm15, [rsp+0xE0]
0000790c663d3e35  add rsp, 0xF0
0000790c663d3e3c  pop r11
0000790c663d3e3e  pop r10
0000790c663d3e40  pop r9
0000790c663d3e42  pop r8
0000790c663d3e44  pop rsi
0000790c663d3e45  pop rdi
0000790c663d3e46  pop rdx
0000790c663d3e47  pop rcx
0000790c663d3e48  pop rax
0000790c663d3e49  add rsp, 0x08
0000790c663d3e4d  jmp 0x0000790C663D003F
0000790c663d3e52  sub rsp, 0x08
0000790c663d3e56  push rax
0000790c663d3e57  push rcx
0000790c663d3e58  push rdx
0000790c663d3e59  push rdi
0000790c663d3e5a  push rsi
0000790c663d3e5b  push r8
0000790c663d3e5d  push r9
0000790c663d3e5f  push r10
0000790c663d3e61  push r11
0000790c663d3e63  sub rsp, 0xF0
0000790c663d3e6a  vmovaps [rsp], xmm0
0000790c663d3e6f  vmovaps [rsp+0x10], xmm1
0000790c663d3e75  vmovaps [rsp+0x20], xmm2
0000790c663d3e7b  vmovaps [rsp+0x30], xmm3
0000790c663d3e81  vmovaps [rsp+0x40], xmm4
0000790c663d3e87  vmovaps [rsp+0x50], xmm5
0000790c663d3e8d  vmovaps [rsp+0x60], xmm6
0000790c663d3e93  vmovaps [rsp+0x70], xmm7
0000790c663d3e99  vmovaps [rsp+0x80], xmm8
0000790c663d3ea2  vmovaps [rsp+0x90], xmm9
0000790c663d3eab  vmovaps [rsp+0xA0], xmm10
0000790c663d3eb4  vmovaps [rsp+0xB0], xmm11
0000790c663d3ebd  vmovaps [rsp+0xC0], xmm12
0000790c663d3ec6  vmovaps [rsp+0xD0], xmm14
0000790c663d3ecf  vmovaps [rsp+0xE0], xmm15
0000790c663d3ed8  sub rsp, 0x30
0000790c663d3edc  movaps [rsp], xmm13
0000790c663d3ee1  movaps [rsp+0x10], xmm8
0000790c663d3ee7  movaps [rsp+0x20], xmm14
0000790c663d3eed  lea rdi, [rsp]
0000790c663d3ef1  mov esi, 0x00
0000790c663d3ef6  mov rax, 0x631C1759F530
0000790c663d3f00  call rax
0000790c663d3f02  movaps xmm13, [rsp]
0000790c663d3f07  add rsp, 0x30
0000790c663d3f0b  vmovaps xmm0, [rsp]
0000790c663d3f10  vmovaps xmm1, [rsp+0x10]
0000790c663d3f16  vmovaps xmm2, [rsp+0x20]
0000790c663d3f1c  vmovaps xmm3, [rsp+0x30]
0000790c663d3f22  vmovaps xmm4, [rsp+0x40]
0000790c663d3f28  vmovaps xmm5, [rsp+0x50]
0000790c663d3f2e  vmovaps xmm6, [rsp+0x60]
0000790c663d3f34  vmovaps xmm7, [rsp+0x70]
0000790c663d3f3a  vmovaps xmm8, [rsp+0x80]
0000790c663d3f43  vmovaps xmm9, [rsp+0x90]
0000790c663d3f4c  vmovaps xmm10, [rsp+0xA0]
0000790c663d3f55  vmovaps xmm11, [rsp+0xB0]
0000790c663d3f5e  vmovaps xmm12, [rsp+0xC0]
0000790c663d3f67  vmovaps xmm14, [rsp+0xD0]
0000790c663d3f70  vmovaps xmm15, [rsp+0xE0]
0000790c663d3f79  add rsp, 0xF0
0000790c663d3f80  pop r11
0000790c663d3f82  pop r10
0000790c663d3f84  pop r9
0000790c663d3f86  pop r8
0000790c663d3f88  pop rsi
0000790c663d3f89  pop rdi
0000790c663d3f8a  pop rdx
0000790c663d3f8b  pop rcx
0000790c663d3f8c  pop rax
0000790c663d3f8d  add rsp, 0x08
0000790c663d3f91  jmp 0x0000790C663D006E
0000790c663d3f96  sub rsp, 0x08
0000790c663d3f9a  push rax
0000790c663d3f9b  push rcx
0000790c663d3f9c  push rdx
0000790c663d3f9d  push rdi
0000790c663d3f9e  push rsi
0000790c663d3f9f  push r8
0000790c663d3fa1  push r9
0000790c663d3fa3  push r10
0000790c663d3fa5  push r11
0000790c663d3fa7  sub rsp, 0xF0
0000790c663d3fae  vmovaps [rsp], xmm0
0000790c663d3fb3  vmovaps [rsp+0x10], xmm1
0000790c663d3fb9  vmovaps [rsp+0x20], xmm2
0000790c663d3fbf  vmovaps [rsp+0x30], xmm3
0000790c663d3fc5  vmovaps [rsp+0x40], xmm4
0000790c663d3fcb  vmovaps [rsp+0x50], xmm5
0000790c663d3fd1  vmovaps [rsp+0x60], xmm6
0000790c663d3fd7  vmovaps [rsp+0x70], xmm7
0000790c663d3fdd  vmovaps [rsp+0x80], xmm9
0000790c663d3fe6  vmovaps [rsp+0x90], xmm10
0000790c663d3fef  vmovaps [rsp+0xA0], xmm11
0000790c663d3ff8  vmovaps [rsp+0xB0], xmm12
0000790c663d4001  vmovaps [rsp+0xC0], xmm13
0000790c663d400a  vmovaps [rsp+0xD0], xmm14
0000790c663d4013  vmovaps [rsp+0xE0], xmm15
0000790c663d401c  sub rsp, 0x30
0000790c663d4020  movaps [rsp], xmm8
0000790c663d4025  movaps [rsp+0x10], xmm7
0000790c663d402a  movaps [rsp+0x20], xmm14
0000790c663d4030  lea rdi, [rsp]
0000790c663d4034  mov esi, 0x00
0000790c663d4039  mov rax, 0x631C1759F530
0000790c663d4043  call rax
0000790c663d4045  movaps xmm8, [rsp]
0000790c663d404a  add rsp, 0x30
0000790c663d404e  vmovaps xmm0, [rsp]
0000790c663d4053  vmovaps xmm1, [rsp+0x10]
0000790c663d4059  vmovaps xmm2, [rsp+0x20]
0000790c663d405f  vmovaps xmm3, [rsp+0x30]
0000790c663d4065  vmovaps xmm4, [rsp+0x40]
0000790c663d406b  vmovaps xmm5, [rsp+0x50]
0000790c663d4071  vmovaps xmm6, [rsp+0x60]
0000790c663d4077  vmovaps xmm7, [rsp+0x70]
0000790c663d407d  vmovaps xmm9, [rsp+0x80]
0000790c663d4086  vmovaps xmm10, [rsp+0x90]
0000790c663d408f  vmovaps xmm11, [rsp+0xA0]
0000790c663d4098  vmovaps xmm12, [rsp+0xB0]
0000790c663d40a1  vmovaps xmm13, [rsp+0xC0]
0000790c663d40aa  vmovaps xmm14, [rsp+0xD0]
0000790c663d40b3  vmovaps xmm15, [rsp+0xE0]
0000790c663d40bc  add rsp, 0xF0
0000790c663d40c3  pop r11
0000790c663d40c5  pop r10
0000790c663d40c7  pop r9
0000790c663d40c9  pop r8
0000790c663d40cb  pop rsi
0000790c663d40cc  pop rdi
0000790c663d40cd  pop rdx
0000790c663d40ce  pop rcx
0000790c663d40cf  pop rax
0000790c663d40d0  add rsp, 0x08
0000790c663d40d4  jmp 0x0000790C663D0094
0000790c663d40d9  sub rsp, 0x08
0000790c663d40dd  push rax
0000790c663d40de  push rcx
0000790c663d40df  push rdx
0000790c663d40e0  push rdi
0000790c663d40e1  push rsi
0000790c663d40e2  push r8
0000790c663d40e4  push r9
0000790c663d40e6  push r10
0000790c663d40e8  push r11
0000790c663d40ea  sub rsp, 0xF0
0000790c663d40f1  vmovaps [rsp], xmm0
0000790c663d40f6  vmovaps [rsp+0x10], xmm1
0000790c663d40fc  vmovaps [rsp+0x20], xmm2
0000790c663d4102  vmovaps [rsp+0x30], xmm3
0000790c663d4108  vmovaps [rsp+0x40], xmm4
0000790c663d410e  vmovaps [rsp+0x50], xmm5
0000790c663d4114  vmovaps [rsp+0x60], xmm6
0000790c663d411a  vmovaps [rsp+0x70], xmm7
0000790c663d4120  vmovaps [rsp+0x80], xmm8
0000790c663d4129  vmovaps [rsp+0x90], xmm9
0000790c663d4132  vmovaps [rsp+0xA0], xmm10
0000790c663d413b  vmovaps [rsp+0xB0], xmm11
0000790c663d4144  vmovaps [rsp+0xC0], xmm12
0000790c663d414d  vmovaps [rsp+0xD0], xmm13
0000790c663d4156  vmovaps [rsp+0xE0], xmm15
0000790c663d415f  sub rsp, 0x30
0000790c663d4163  movaps [rsp], xmm14
0000790c663d4168  movaps [rsp+0x10], xmm12
0000790c663d416e  movaps [rsp+0x20], xmm9
0000790c663d4174  lea rdi, [rsp]
0000790c663d4178  mov esi, 0x00
0000790c663d417d  mov rax, 0x631C1759F530
0000790c663d4187  call rax
0000790c663d4189  movaps xmm14, [rsp]
0000790c663d418e  add rsp, 0x30
0000790c663d4192  vmovaps xmm0, [rsp]
0000790c663d4197  vmovaps xmm1, [rsp+0x10]
0000790c663d419d  vmovaps xmm2, [rsp+0x20]
0000790c663d41a3  vmovaps xmm3, [rsp+0x30]
0000790c663d41a9  vmovaps xmm4, [rsp+0x40]
0000790c663d41af  vmovaps xmm5, [rsp+0x50]
0000790c663d41b5  vmovaps xmm6, [rsp+0x60]
0000790c663d41bb  vmovaps xmm7, [rsp+0x70]
0000790c663d41c1  vmovaps xmm8, [rsp+0x80]
0000790c663d41ca  vmovaps xmm9, [rsp+0x90]
0000790c663d41d3  vmovaps xmm10, [rsp+0xA0]
0000790c663d41dc  vmovaps xmm11, [rsp+0xB0]
0000790c663d41e5  vmovaps xmm12, [rsp+0xC0]
0000790c663d41ee  vmovaps xmm13, [rsp+0xD0]
0000790c663d41f7  vmovaps xmm15, [rsp+0xE0]
0000790c663d4200  add rsp, 0xF0
0000790c663d4207  pop r11
0000790c663d4209  pop r10
0000790c663d420b  pop r9
0000790c663d420d  pop r8
0000790c663d420f  pop rsi
0000790c663d4210  pop rdi
0000790c663d4211  pop rdx
0000790c663d4212  pop rcx
0000790c663d4213  pop rax
0000790c663d4214  add rsp, 0x08
0000790c663d4218  jmp 0x0000790C663D00AE
0000790c663d421d  sub rsp, 0x08
0000790c663d4221  push rax
0000790c663d4222  push rcx
0000790c663d4223  push rdx
0000790c663d4224  push rdi
0000790c663d4225  push rsi
0000790c663d4226  push r8
0000790c663d4228  push r9
0000790c663d422a  push r10
0000790c663d422c  push r11
0000790c663d422e  sub rsp, 0xF0
0000790c663d4235  vmovaps [rsp], xmm0
0000790c663d423a  vmovaps [rsp+0x10], xmm1
0000790c663d4240  vmovaps [rsp+0x20], xmm2
0000790c663d4246  vmovaps [rsp+0x30], xmm3
0000790c663d424c  vmovaps [rsp+0x40], xmm4
0000790c663d4252  vmovaps [rsp+0x50], xmm5
0000790c663d4258  vmovaps [rsp+0x60], xmm6
0000790c663d425e  vmovaps [rsp+0x70], xmm7
0000790c663d4264  vmovaps [rsp+0x80], xmm8
0000790c663d426d  vmovaps [rsp+0x90], xmm10
0000790c663d4276  vmovaps [rsp+0xA0], xmm11
0000790c663d427f  vmovaps [rsp+0xB0], xmm12
0000790c663d4288  vmovaps [rsp+0xC0], xmm13
0000790c663d4291  vmovaps [rsp+0xD0], xmm14
0000790c663d429a  vmovaps [rsp+0xE0], xmm15
0000790c663d42a3  sub rsp, 0x30
0000790c663d42a7  movaps [rsp], xmm9
0000790c663d42ac  movaps [rsp+0x10], xmm7
0000790c663d42b1  movaps [rsp+0x20], xmm12
0000790c663d42b7  lea rdi, [rsp]
0000790c663d42bb  mov esi, 0x00
0000790c663d42c0  mov rax, 0x631C1759F530
0000790c663d42ca  call rax
0000790c663d42cc  movaps xmm9, [rsp]
0000790c663d42d1  add rsp, 0x30
0000790c663d42d5  vmovaps xmm0, [rsp]
0000790c663d42da  vmovaps xmm1, [rsp+0x10]
0000790c663d42e0  vmovaps xmm2, [rsp+0x20]
0000790c663d42e6  vmovaps xmm3, [rsp+0x30]
0000790c663d42ec  vmovaps xmm4, [rsp+0x40]
0000790c663d42f2  vmovaps xmm5, [rsp+0x50]
0000790c663d42f8  vmovaps xmm6, [rsp+0x60]
0000790c663d42fe  vmovaps xmm7, [rsp+0x70]
0000790c663d4304  vmovaps xmm8, [rsp+0x80]
0000790c663d430d  vmovaps xmm10, [rsp+0x90]
0000790c663d4316  vmovaps xmm11, [rsp+0xA0]
0000790c663d431f  vmovaps xmm12, [rsp+0xB0]
0000790c663d4328  vmovaps xmm13, [rsp+0xC0]
0000790c663d4331  vmovaps xmm14, [rsp+0xD0]
0000790c663d433a  vmovaps xmm15, [rsp+0xE0]
0000790c663d4343  add rsp, 0xF0
0000790c663d434a  pop r11
0000790c663d434c  pop r10
0000790c663d434e  pop r9
0000790c663d4350  pop r8
0000790c663d4352  pop rsi
0000790c663d4353  pop rdi
0000790c663d4354  pop rdx
0000790c663d4355  pop rcx
0000790c663d4356  pop rax
0000790c663d4357  add rsp, 0x08
0000790c663d435b  jmp 0x0000790C663D00DD
0000790c663d4360  sub rsp, 0x08
0000790c663d4364  push rax
0000790c663d4365  push rcx
0000790c663d4366  push rdx
0000790c663d4367  push rdi
0000790c663d4368  push rsi
0000790c663d4369  push r8
0000790c663d436b  push r9
0000790c663d436d  push r10
0000790c663d436f  push r11
0000790c663d4371  sub rsp, 0xF0
0000790c663d4378  vmovaps [rsp], xmm0
0000790c663d437d  vmovaps [rsp+0x10], xmm1
0000790c663d4383  vmovaps [rsp+0x20], xmm2
0000790c663d4389  vmovaps [rsp+0x30], xmm3
0000790c663d438f  vmovaps [rsp+0x40], xmm4
0000790c663d4395  vmovaps [rsp+0x50], xmm5
0000790c663d439b  vmovaps [rsp+0x60], xmm6
0000790c663d43a1  vmovaps [rsp+0x70], xmm7
0000790c663d43a7  vmovaps [rsp+0x80], xmm8
0000790c663d43b0  vmovaps [rsp+0x90], xmm9
0000790c663d43b9  vmovaps [rsp+0xA0], xmm10
0000790c663d43c2  vmovaps [rsp+0xB0], xmm11
0000790c663d43cb  vmovaps [rsp+0xC0], xmm13
0000790c663d43d4  vmovaps [rsp+0xD0], xmm14
0000790c663d43dd  vmovaps [rsp+0xE0], xmm15
0000790c663d43e6  sub rsp, 0x30
0000790c663d43ea  movaps [rsp], xmm12
0000790c663d43ef  movaps [rsp+0x10], xmm15
0000790c663d43f5  movaps [rsp+0x20], xmm11
0000790c663d43fb  lea rdi, [rsp]
0000790c663d43ff  mov esi, 0x00
0000790c663d4404  mov rax, 0x631C1759F530
0000790c663d440e  call rax
0000790c663d4410  movaps xmm12, [rsp]
0000790c663d4415  add rsp, 0x30
0000790c663d4419  vmovaps xmm0, [rsp]
0000790c663d441e  vmovaps xmm1, [rsp+0x10]
0000790c663d4424  vmovaps xmm2, [rsp+0x20]
0000790c663d442a  vmovaps xmm3, [rsp+0x30]
0000790c663d4430  vmovaps xmm4, [rsp+0x40]
0000790c663d4436  vmovaps xmm5, [rsp+0x50]
0000790c663d443c  vmovaps xmm6, [rsp+0x60]
0000790c663d4442  vmovaps xmm7, [rsp+0x70]
0000790c663d4448  vmovaps xmm8, [rsp+0x80]
0000790c663d4451  vmovaps xmm9, [rsp+0x90]
0000790c663d445a  vmovaps xmm10, [rsp+0xA0]
0000790c663d4463  vmovaps xmm11, [rsp+0xB0]
0000790c663d446c  vmovaps xmm13, [rsp+0xC0]
0000790c663d4475  vmovaps xmm14, [rsp+0xD0]
0000790c663d447e  vmovaps xmm15, [rsp+0xE0]
0000790c663d4487  add rsp, 0xF0
0000790c663d448e  pop r11
0000790c663d4490  pop r10
0000790c663d4492  pop r9
0000790c663d4494  pop r8
0000790c663d4496  pop rsi
0000790c663d4497  pop rdi
0000790c663d4498  pop rdx
0000790c663d4499  pop rcx
0000790c663d449a  pop rax
0000790c663d449b  add rsp, 0x08
0000790c663d449f  jmp 0x0000790C663D00F7
0000790c663d44a4  sub rsp, 0x08
0000790c663d44a8  push rax
0000790c663d44a9  push rcx
0000790c663d44aa  push rdx
0000790c663d44ab  push rdi
0000790c663d44ac  push rsi
0000790c663d44ad  push r8
0000790c663d44af  push r9
0000790c663d44b1  push r10
0000790c663d44b3  push r11
0000790c663d44b5  sub rsp, 0xF0
0000790c663d44bc  vmovaps [rsp], xmm0
0000790c663d44c1  vmovaps [rsp+0x10], xmm1
0000790c663d44c7  vmovaps [rsp+0x20], xmm2
0000790c663d44cd  vmovaps [rsp+0x30], xmm3
0000790c663d44d3  vmovaps [rsp+0x40], xmm4
0000790c663d44d9  vmovaps [rsp+0x50], xmm5
0000790c663d44df  vmovaps [rsp+0x60], xmm6
0000790c663d44e5  vmovaps [rsp+0x70], xmm7
0000790c663d44eb  vmovaps [rsp+0x80], xmm8
0000790c663d44f4  vmovaps [rsp+0x90], xmm9
0000790c663d44fd  vmovaps [rsp+0xA0], xmm10
0000790c663d4506  vmovaps [rsp+0xB0], xmm12
0000790c663d450f  vmovaps [rsp+0xC0], xmm13
0000790c663d4518  vmovaps [rsp+0xD0], xmm14
0000790c663d4521  vmovaps [rsp+0xE0], xmm15
0000790c663d452a  sub rsp, 0x30
0000790c663d452e  movaps [rsp], xmm11
0000790c663d4533  movaps [rsp+0x10], xmm7
0000790c663d4538  movaps [rsp+0x20], xmm15
0000790c663d453e  lea rdi, [rsp]
0000790c663d4542  mov esi, 0x00
0000790c663d4547  mov rax, 0x631C1759F530
0000790c663d4551  call rax
0000790c663d4553  movaps xmm11, [rsp]
0000790c663d4558  add rsp, 0x30
0000790c663d455c  vmovaps xmm0, [rsp]
0000790c663d4561  vmovaps xmm1, [rsp+0x10]
0000790c663d4567  vmovaps xmm2, [rsp+0x20]
0000790c663d456d  vmovaps xmm3, [rsp+0x30]
0000790c663d4573  vmovaps xmm4, [rsp+0x40]
0000790c663d4579  vmovaps xmm5, [rsp+0x50]
0000790c663d457f  vmovaps xmm6, [rsp+0x60]
0000790c663d4585  vmovaps xmm7, [rsp+0x70]
0000790c663d458b  vmovaps xmm8, [rsp+0x80]
0000790c663d4594  vmovaps xmm9, [rsp+0x90]
0000790c663d459d  vmovaps xmm10, [rsp+0xA0]
0000790c663d45a6  vmovaps xmm12, [rsp+0xB0]
0000790c663d45af  vmovaps xmm13, [rsp+0xC0]
0000790c663d45b8  vmovaps xmm14, [rsp+0xD0]
0000790c663d45c1  vmovaps xmm15, [rsp+0xE0]
0000790c663d45ca  add rsp, 0xF0
0000790c663d45d1  pop r11
0000790c663d45d3  pop r10
0000790c663d45d5  pop r9
0000790c663d45d7  pop r8
0000790c663d45d9  pop rsi
0000790c663d45da  pop rdi
0000790c663d45db  pop rdx
0000790c663d45dc  pop rcx
0000790c663d45dd  pop rax
0000790c663d45de  add rsp, 0x08
0000790c663d45e2  jmp 0x0000790C663D0123
0000790c663d45e7  sub rsp, 0x08
0000790c663d45eb  push rax
0000790c663d45ec  push rcx
0000790c663d45ed  push rdx
0000790c663d45ee  push rdi
0000790c663d45ef  push rsi
0000790c663d45f0  push r8
0000790c663d45f2  push r9
0000790c663d45f4  push r10
0000790c663d45f6  push r11
0000790c663d45f8  sub rsp, 0xF0
0000790c663d45ff  vmovaps [rsp], xmm0
0000790c663d4604  vmovaps [rsp+0x10], xmm1
0000790c663d460a  vmovaps [rsp+0x20], xmm2
0000790c663d4610  vmovaps [rsp+0x30], xmm3
0000790c663d4616  vmovaps [rsp+0x40], xmm4
0000790c663d461c  vmovaps [rsp+0x50], xmm5
0000790c663d4622  vmovaps [rsp+0x60], xmm6
0000790c663d4628  vmovaps [rsp+0x70], xmm7
0000790c663d462e  vmovaps [rsp+0x80], xmm8
0000790c663d4637  vmovaps [rsp+0x90], xmm9
0000790c663d4640  vmovaps [rsp+0xA0], xmm10
0000790c663d4649  vmovaps [rsp+0xB0], xmm11
0000790c663d4652  vmovaps [rsp+0xC0], xmm12
0000790c663d465b  vmovaps [rsp+0xD0], xmm13
0000790c663d4664  vmovaps [rsp+0xE0], xmm14
0000790c663d466d  sub rsp, 0x30
0000790c663d4671  movaps [rsp], xmm15
0000790c663d4676  movaps [rsp+0x10], xmm10
0000790c663d467c  movaps [rsp+0x20], xmm13
0000790c663d4682  lea rdi, [rsp]
0000790c663d4686  mov esi, 0x00
0000790c663d468b  mov rax, 0x631C1759F530
0000790c663d4695  call rax
0000790c663d4697  movaps xmm15, [rsp]
0000790c663d469c  add rsp, 0x30
0000790c663d46a0  vmovaps xmm0, [rsp]
0000790c663d46a5  vmovaps xmm1, [rsp+0x10]
0000790c663d46ab  vmovaps xmm2, [rsp+0x20]
0000790c663d46b1  vmovaps xmm3, [rsp+0x30]
0000790c663d46b7  vmovaps xmm4, [rsp+0x40]
0000790c663d46bd  vmovaps xmm5, [rsp+0x50]
0000790c663d46c3  vmovaps xmm6, [rsp+0x60]
0000790c663d46c9  vmovaps xmm7, [rsp+0x70]
0000790c663d46cf  vmovaps xmm8, [rsp+0x80]
0000790c663d46d8  vmovaps xmm9, [rsp+0x90]
0000790c663d46e1  vmovaps xmm10, [rsp+0xA0]
0000790c663d46ea  vmovaps xmm11, [rsp+0xB0]
0000790c663d46f3  vmovaps xmm12, [rsp+0xC0]
0000790c663d46fc  vmovaps xmm13, [rsp+0xD0]
0000790c663d4705  vmovaps xmm14, [rsp+0xE0]
0000790c663d470e  add rsp, 0xF0
0000790c663d4715  pop r11
0000790c663d4717  pop r10
0000790c663d4719  pop r9
0000790c663d471b  pop r8
0000790c663d471d  pop rsi
0000790c663d471e  pop rdi
0000790c663d471f  pop rdx
0000790c663d4720  pop rcx
0000790c663d4721  pop rax
0000790c663d4722  add rsp, 0x08
0000790c663d4726  jmp 0x0000790C663D013D
0000790c663d472b  sub rsp, 0x08
0000790c663d472f  push rax
0000790c663d4730  push rcx
0000790c663d4731  push rdx
0000790c663d4732  push rdi
0000790c663d4733  push rsi
0000790c663d4734  push r8
0000790c663d4736  push r9
0000790c663d4738  push r10
0000790c663d473a  push r11
0000790c663d473c  sub rsp, 0xF0
0000790c663d4743  vmovaps [rsp], xmm0
0000790c663d4748  vmovaps [rsp+0x10], xmm1
0000790c663d474e  vmovaps [rsp+0x20], xmm2
0000790c663d4754  vmovaps [rsp+0x30], xmm3
0000790c663d475a  vmovaps [rsp+0x40], xmm4
0000790c663d4760  vmovaps [rsp+0x50], xmm5
0000790c663d4766  vmovaps [rsp+0x60], xmm6
0000790c663d476c  vmovaps [rsp+0x70], xmm7
0000790c663d4772  vmovaps [rsp+0x80], xmm8
0000790c663d477b  vmovaps [rsp+0x90], xmm9
0000790c663d4784  vmovaps [rsp+0xA0], xmm11
0000790c663d478d  vmovaps [rsp+0xB0], xmm12
0000790c663d4796  vmovaps [rsp+0xC0], xmm13
0000790c663d479f  vmovaps [rsp+0xD0], xmm14
0000790c663d47a8  vmovaps [rsp+0xE0], xmm15
0000790c663d47b1  sub rsp, 0x30
0000790c663d47b5  movaps [rsp], xmm10
0000790c663d47ba  movaps [rsp+0x10], xmm7
0000790c663d47bf  movaps [rsp+0x20], xmm13
0000790c663d47c5  lea rdi, [rsp]
0000790c663d47c9  mov esi, 0x00
0000790c663d47ce  mov rax, 0x631C1759F530
0000790c663d47d8  call rax
0000790c663d47da  movaps xmm10, [rsp]
0000790c663d47df  add rsp, 0x30
0000790c663d47e3  vmovaps xmm0, [rsp]
0000790c663d47e8  vmovaps xmm1, [rsp+0x10]
0000790c663d47ee  vmovaps xmm2, [rsp+0x20]
0000790c663d47f4  vmovaps xmm3, [rsp+0x30]
0000790c663d47fa  vmovaps xmm4, [rsp+0x40]
0000790c663d4800  vmovaps xmm5, [rsp+0x50]
0000790c663d4806  vmovaps xmm6, [rsp+0x60]
0000790c663d480c  vmovaps xmm7, [rsp+0x70]
0000790c663d4812  vmovaps xmm8, [rsp+0x80]
0000790c663d481b  vmovaps xmm9, [rsp+0x90]
0000790c663d4824  vmovaps xmm11, [rsp+0xA0]
0000790c663d482d  vmovaps xmm12, [rsp+0xB0]
0000790c663d4836  vmovaps xmm13, [rsp+0xC0]
0000790c663d483f  vmovaps xmm14, [rsp+0xD0]
0000790c663d4848  vmovaps xmm15, [rsp+0xE0]
0000790c663d4851  add rsp, 0xF0
0000790c663d4858  pop r11
0000790c663d485a  pop r10
0000790c663d485c  pop r9
0000790c663d485e  pop r8
0000790c663d4860  pop rsi
0000790c663d4861  pop rdi
0000790c663d4862  pop rdx
0000790c663d4863  pop rcx
0000790c663d4864  pop rax
0000790c663d4865  add rsp, 0x08
0000790c663d4869  jmp 0x0000790C663D0169
0000790c663d486e  sub rsp, 0x08
0000790c663d4872  push rax
0000790c663d4873  push rcx
0000790c663d4874  push rdx
0000790c663d4875  push rdi
0000790c663d4876  push rsi
0000790c663d4877  push r8
0000790c663d4879  push r9
0000790c663d487b  push r10
0000790c663d487d  push r11
0000790c663d487f  sub rsp, 0xF0
0000790c663d4886  vmovaps [rsp], xmm0
0000790c663d488b  vmovaps [rsp+0x10], xmm1
0000790c663d4891  vmovaps [rsp+0x20], xmm2
0000790c663d4897  vmovaps [rsp+0x30], xmm3
0000790c663d489d  vmovaps [rsp+0x40], xmm4
0000790c663d48a3  vmovaps [rsp+0x50], xmm5
0000790c663d48a9  vmovaps [rsp+0x60], xmm6
0000790c663d48af  vmovaps [rsp+0x70], xmm7
0000790c663d48b5  vmovaps [rsp+0x80], xmm8
0000790c663d48be  vmovaps [rsp+0x90], xmm9
0000790c663d48c7  vmovaps [rsp+0xA0], xmm10
0000790c663d48d0  vmovaps [rsp+0xB0], xmm11
0000790c663d48d9  vmovaps [rsp+0xC0], xmm12
0000790c663d48e2  vmovaps [rsp+0xD0], xmm14
0000790c663d48eb  vmovaps [rsp+0xE0], xmm15
0000790c663d48f4  sub rsp, 0x30
0000790c663d48f8  movaps [rsp], xmm13
0000790c663d48fd  movaps [rsp+0x10], xmm1
0000790c663d4902  movaps [rsp+0x20], xmm8
0000790c663d4908  lea rdi, [rsp]
0000790c663d490c  mov esi, 0x00
0000790c663d4911  mov rax, 0x631C1759F530
0000790c663d491b  call rax
0000790c663d491d  movaps xmm13, [rsp]
0000790c663d4922  add rsp, 0x30
0000790c663d4926  vmovaps xmm0, [rsp]
0000790c663d492b  vmovaps xmm1, [rsp+0x10]
0000790c663d4931  vmovaps xmm2, [rsp+0x20]
0000790c663d4937  vmovaps xmm3, [rsp+0x30]
0000790c663d493d  vmovaps xmm4, [rsp+0x40]
0000790c663d4943  vmovaps xmm5, [rsp+0x50]
0000790c663d4949  vmovaps xmm6, [rsp+0x60]
0000790c663d494f  vmovaps xmm7, [rsp+0x70]
0000790c663d4955  vmovaps xmm8, [rsp+0x80]
0000790c663d495e  vmovaps xmm9, [rsp+0x90]
0000790c663d4967  vmovaps xmm10, [rsp+0xA0]
0000790c663d4970  vmovaps xmm11, [rsp+0xB0]
0000790c663d4979  vmovaps xmm12, [rsp+0xC0]
0000790c663d4982  vmovaps xmm14, [rsp+0xD0]
0000790c663d498b  vmovaps xmm15, [rsp+0xE0]
0000790c663d4994  add rsp, 0xF0
0000790c663d499b  pop r11
0000790c663d499d  pop r10
0000790c663d499f  pop r9
0000790c663d49a1  pop r8
0000790c663d49a3  pop rsi
0000790c663d49a4  pop rdi
0000790c663d49a5  pop rdx
0000790c663d49a6  pop rcx
0000790c663d49a7  pop rax
0000790c663d49a8  add rsp, 0x08
0000790c663d49ac  jmp 0x0000790C663D0183
0000790c663d49b1  call 0x0000790C661FF430
0000790c663d49b6  jmp 0x0000790C663D018D
0000790c663d49bb  sub rsp, 0x08
0000790c663d49bf  push rax
0000790c663d49c0  push rcx
0000790c663d49c1  push rdx
0000790c663d49c2  push rdi
0000790c663d49c3  push rsi
0000790c663d49c4  push r8
0000790c663d49c6  push r9
0000790c663d49c8  push r10
0000790c663d49ca  push r11
0000790c663d49cc  sub rsp, 0xF0
0000790c663d49d3  vmovaps [rsp], xmm0
0000790c663d49d8  vmovaps [rsp+0x10], xmm1
0000790c663d49de  vmovaps [rsp+0x20], xmm2
0000790c663d49e4  vmovaps [rsp+0x30], xmm3
0000790c663d49ea  vmovaps [rsp+0x40], xmm4
0000790c663d49f0  vmovaps [rsp+0x50], xmm5
0000790c663d49f6  vmovaps [rsp+0x60], xmm6
0000790c663d49fc  vmovaps [rsp+0x70], xmm7
0000790c663d4a02  vmovaps [rsp+0x80], xmm9
0000790c663d4a0b  vmovaps [rsp+0x90], xmm10
0000790c663d4a14  vmovaps [rsp+0xA0], xmm11
0000790c663d4a1d  vmovaps [rsp+0xB0], xmm12
0000790c663d4a26  vmovaps [rsp+0xC0], xmm13
0000790c663d4a2f  vmovaps [rsp+0xD0], xmm14
0000790c663d4a38  vmovaps [rsp+0xE0], xmm15
0000790c663d4a41  sub rsp, 0x30
0000790c663d4a45  movaps [rsp], xmm8
0000790c663d4a4a  movaps [rsp+0x10], xmm14
0000790c663d4a50  movaps [rsp+0x20], xmm9
0000790c663d4a56  lea rdi, [rsp]
0000790c663d4a5a  mov esi, 0x00
0000790c663d4a5f  mov rax, 0x631C1759F530
0000790c663d4a69  call rax
0000790c663d4a6b  movaps xmm8, [rsp]
0000790c663d4a70  add rsp, 0x30
0000790c663d4a74  vmovaps xmm0, [rsp]
0000790c663d4a79  vmovaps xmm1, [rsp+0x10]
0000790c663d4a7f  vmovaps xmm2, [rsp+0x20]
0000790c663d4a85  vmovaps xmm3, [rsp+0x30]
0000790c663d4a8b  vmovaps xmm4, [rsp+0x40]
0000790c663d4a91  vmovaps xmm5, [rsp+0x50]
0000790c663d4a97  vmovaps xmm6, [rsp+0x60]
0000790c663d4a9d  vmovaps xmm7, [rsp+0x70]
0000790c663d4aa3  vmovaps xmm9, [rsp+0x80]
0000790c663d4aac  vmovaps xmm10, [rsp+0x90]
0000790c663d4ab5  vmovaps xmm11, [rsp+0xA0]
0000790c663d4abe  vmovaps xmm12, [rsp+0xB0]
0000790c663d4ac7  vmovaps xmm13, [rsp+0xC0]
0000790c663d4ad0  vmovaps xmm14, [rsp+0xD0]
0000790c663d4ad9  vmovaps xmm15, [rsp+0xE0]
0000790c663d4ae2  add rsp, 0xF0
0000790c663d4ae9  pop r11
0000790c663d4aeb  pop r10
0000790c663d4aed  pop r9
0000790c663d4aef  pop r8
0000790c663d4af1  pop rsi
0000790c663d4af2  pop rdi
0000790c663d4af3  pop rdx
0000790c663d4af4  pop rcx
0000790c663d4af5  pop rax
0000790c663d4af6  add rsp, 0x08
0000790c663d4afa  jmp 0x0000790C663D01AF
0000790c663d4aff  sub rsp, 0x08
0000790c663d4b03  push rax
0000790c663d4b04  push rcx
0000790c663d4b05  push rdx
0000790c663d4b06  push rdi
0000790c663d4b07  push rsi
0000790c663d4b08  push r8
0000790c663d4b0a  push r9
0000790c663d4b0c  push r10
0000790c663d4b0e  push r11
0000790c663d4b10  sub rsp, 0xF0
0000790c663d4b17  vmovaps [rsp], xmm0
0000790c663d4b1c  vmovaps [rsp+0x10], xmm1
0000790c663d4b22  vmovaps [rsp+0x20], xmm2
0000790c663d4b28  vmovaps [rsp+0x30], xmm3
0000790c663d4b2e  vmovaps [rsp+0x40], xmm4
0000790c663d4b34  vmovaps [rsp+0x50], xmm5
0000790c663d4b3a  vmovaps [rsp+0x60], xmm6
0000790c663d4b40  vmovaps [rsp+0x70], xmm7
0000790c663d4b46  vmovaps [rsp+0x80], xmm8
0000790c663d4b4f  vmovaps [rsp+0x90], xmm10
0000790c663d4b58  vmovaps [rsp+0xA0], xmm11
0000790c663d4b61  vmovaps [rsp+0xB0], xmm12
0000790c663d4b6a  vmovaps [rsp+0xC0], xmm13
0000790c663d4b73  vmovaps [rsp+0xD0], xmm14
0000790c663d4b7c  vmovaps [rsp+0xE0], xmm15
0000790c663d4b85  sub rsp, 0x30
0000790c663d4b89  movaps [rsp], xmm9
0000790c663d4b8e  movaps [rsp+0x10], xmm1
0000790c663d4b93  movaps [rsp+0x20], xmm14
0000790c663d4b99  lea rdi, [rsp]
0000790c663d4b9d  mov esi, 0x00
0000790c663d4ba2  mov rax, 0x631C1759F530
0000790c663d4bac  call rax
0000790c663d4bae  movaps xmm9, [rsp]
0000790c663d4bb3  add rsp, 0x30
0000790c663d4bb7  vmovaps xmm0, [rsp]
0000790c663d4bbc  vmovaps xmm1, [rsp+0x10]
0000790c663d4bc2  vmovaps xmm2, [rsp+0x20]
0000790c663d4bc8  vmovaps xmm3, [rsp+0x30]
0000790c663d4bce  vmovaps xmm4, [rsp+0x40]
0000790c663d4bd4  vmovaps xmm5, [rsp+0x50]
0000790c663d4bda  vmovaps xmm6, [rsp+0x60]
0000790c663d4be0  vmovaps xmm7, [rsp+0x70]
0000790c663d4be6  vmovaps xmm8, [rsp+0x80]
0000790c663d4bef  vmovaps xmm10, [rsp+0x90]
0000790c663d4bf8  vmovaps xmm11, [rsp+0xA0]
0000790c663d4c01  vmovaps xmm12, [rsp+0xB0]
0000790c663d4c0a  vmovaps xmm13, [rsp+0xC0]
0000790c663d4c13  vmovaps xmm14, [rsp+0xD0]
0000790c663d4c1c  vmovaps xmm15, [rsp+0xE0]
0000790c663d4c25  add rsp, 0xF0
0000790c663d4c2c  pop r11
0000790c663d4c2e  pop r10
0000790c663d4c30  pop r9
0000790c663d4c32  pop r8
0000790c663d4c34  pop rsi
0000790c663d4c35  pop rdi
0000790c663d4c36  pop rdx
0000790c663d4c37  pop rcx
0000790c663d4c38  pop rax
0000790c663d4c39  add rsp, 0x08
0000790c663d4c3d  jmp 0x0000790C663D01DD
0000790c663d4c42  sub rsp, 0x08
0000790c663d4c46  push rax
0000790c663d4c47  push rcx
0000790c663d4c48  push rdx
0000790c663d4c49  push rdi
0000790c663d4c4a  push rsi
0000790c663d4c4b  push r8
0000790c663d4c4d  push r9
0000790c663d4c4f  push r10
0000790c663d4c51  push r11
0000790c663d4c53  sub rsp, 0xF0
0000790c663d4c5a  vmovaps [rsp], xmm0
0000790c663d4c5f  vmovaps [rsp+0x10], xmm1
0000790c663d4c65  vmovaps [rsp+0x20], xmm2
0000790c663d4c6b  vmovaps [rsp+0x30], xmm3
0000790c663d4c71  vmovaps [rsp+0x40], xmm4
0000790c663d4c77  vmovaps [rsp+0x50], xmm5
0000790c663d4c7d  vmovaps [rsp+0x60], xmm6
0000790c663d4c83  vmovaps [rsp+0x70], xmm7
0000790c663d4c89  vmovaps [rsp+0x80], xmm8
0000790c663d4c92  vmovaps [rsp+0x90], xmm9
0000790c663d4c9b  vmovaps [rsp+0xA0], xmm10
0000790c663d4ca4  vmovaps [rsp+0xB0], xmm11
0000790c663d4cad  vmovaps [rsp+0xC0], xmm12
0000790c663d4cb6  vmovaps [rsp+0xD0], xmm13
0000790c663d4cbf  vmovaps [rsp+0xE0], xmm15
0000790c663d4cc8  sub rsp, 0x30
0000790c663d4ccc  movaps [rsp], xmm14
0000790c663d4cd1  movaps [rsp+0x10], xmm4
0000790c663d4cd6  movaps [rsp+0x20], xmm1
0000790c663d4cdb  lea rdi, [rsp]
0000790c663d4cdf  mov esi, 0x00
0000790c663d4ce4  mov rax, 0x631C1759F530
0000790c663d4cee  call rax
0000790c663d4cf0  movaps xmm14, [rsp]
0000790c663d4cf5  add rsp, 0x30
0000790c663d4cf9  vmovaps xmm0, [rsp]
0000790c663d4cfe  vmovaps xmm1, [rsp+0x10]
0000790c663d4d04  vmovaps xmm2, [rsp+0x20]
0000790c663d4d0a  vmovaps xmm3, [rsp+0x30]
0000790c663d4d10  vmovaps xmm4, [rsp+0x40]
0000790c663d4d16  vmovaps xmm5, [rsp+0x50]
0000790c663d4d1c  vmovaps xmm6, [rsp+0x60]
0000790c663d4d22  vmovaps xmm7, [rsp+0x70]
0000790c663d4d28  vmovaps xmm8, [rsp+0x80]
0000790c663d4d31  vmovaps xmm9, [rsp+0x90]
0000790c663d4d3a  vmovaps xmm10, [rsp+0xA0]
0000790c663d4d43  vmovaps xmm11, [rsp+0xB0]
0000790c663d4d4c  vmovaps xmm12, [rsp+0xC0]
0000790c663d4d55  vmovaps xmm13, [rsp+0xD0]
0000790c663d4d5e  vmovaps xmm15, [rsp+0xE0]
0000790c663d4d67  add rsp, 0xF0
0000790c663d4d6e  pop r11
0000790c663d4d70  pop r10
0000790c663d4d72  pop r9
0000790c663d4d74  pop r8
0000790c663d4d76  pop rsi
0000790c663d4d77  pop rdi
0000790c663d4d78  pop rdx
0000790c663d4d79  pop rcx
0000790c663d4d7a  pop rax
0000790c663d4d7b  add rsp, 0x08
0000790c663d4d7f  jmp 0x0000790C663D0203
0000790c663d4d84  sub rsp, 0x08
0000790c663d4d88  push rax
0000790c663d4d89  push rcx
0000790c663d4d8a  push rdx
0000790c663d4d8b  push rdi
0000790c663d4d8c  push rsi
0000790c663d4d8d  push r8
0000790c663d4d8f  push r9
0000790c663d4d91  push r10
0000790c663d4d93  push r11
0000790c663d4d95  sub rsp, 0xF0
0000790c663d4d9c  vmovaps [rsp], xmm0
0000790c663d4da1  vmovaps [rsp+0x10], xmm2
0000790c663d4da7  vmovaps [rsp+0x20], xmm3
0000790c663d4dad  vmovaps [rsp+0x30], xmm4
0000790c663d4db3  vmovaps [rsp+0x40], xmm5
0000790c663d4db9  vmovaps [rsp+0x50], xmm6
0000790c663d4dbf  vmovaps [rsp+0x60], xmm7
0000790c663d4dc5  vmovaps [rsp+0x70], xmm8
0000790c663d4dcb  vmovaps [rsp+0x80], xmm9
0000790c663d4dd4  vmovaps [rsp+0x90], xmm10
0000790c663d4ddd  vmovaps [rsp+0xA0], xmm11
0000790c663d4de6  vmovaps [rsp+0xB0], xmm12
0000790c663d4def  vmovaps [rsp+0xC0], xmm13
0000790c663d4df8  vmovaps [rsp+0xD0], xmm14
0000790c663d4e01  vmovaps [rsp+0xE0], xmm15
0000790c663d4e0a  sub rsp, 0x30
0000790c663d4e0e  movaps [rsp], xmm1
0000790c663d4e12  movaps [rsp+0x10], xmm12
0000790c663d4e18  movaps [rsp+0x20], xmm11
0000790c663d4e1e  lea rdi, [rsp]
0000790c663d4e22  mov esi, 0x00
0000790c663d4e27  mov rax, 0x631C1759F530
0000790c663d4e31  call rax
0000790c663d4e33  movaps xmm1, [rsp]
0000790c663d4e37  add rsp, 0x30
0000790c663d4e3b  vmovaps xmm0, [rsp]
0000790c663d4e40  vmovaps xmm2, [rsp+0x10]
0000790c663d4e46  vmovaps xmm3, [rsp+0x20]
0000790c663d4e4c  vmovaps xmm4, [rsp+0x30]
0000790c663d4e52  vmovaps xmm5, [rsp+0x40]
0000790c663d4e58  vmovaps xmm6, [rsp+0x50]
0000790c663d4e5e  vmovaps xmm7, [rsp+0x60]
0000790c663d4e64  vmovaps xmm8, [rsp+0x70]
0000790c663d4e6a  vmovaps xmm9, [rsp+0x80]
0000790c663d4e73  vmovaps xmm10, [rsp+0x90]
0000790c663d4e7c  vmovaps xmm11, [rsp+0xA0]
0000790c663d4e85  vmovaps xmm12, [rsp+0xB0]
0000790c663d4e8e  vmovaps xmm13, [rsp+0xC0]
0000790c663d4e97  vmovaps xmm14, [rsp+0xD0]
0000790c663d4ea0  vmovaps xmm15, [rsp+0xE0]
0000790c663d4ea9  add rsp, 0xF0
0000790c663d4eb0  pop r11
0000790c663d4eb2  pop r10
0000790c663d4eb4  pop r9
0000790c663d4eb6  pop r8
0000790c663d4eb8  pop rsi
0000790c663d4eb9  pop rdi
0000790c663d4eba  pop rdx
0000790c663d4ebb  pop rcx
0000790c663d4ebc  pop rax
0000790c663d4ebd  add rsp, 0x08
0000790c663d4ec1  jmp 0x0000790C663D0224
0000790c663d4ec6  call 0x0000790C662E20A0
0000790c663d4ecb  jmp 0x0000790C663D0232
0000790c663d4ed0  call 0x0000790C66209D70
0000790c663d4ed5  jmp 0x0000790C663D023C
0000790c663d4eda  sub rsp, 0x08
0000790c663d4ede  push rax
0000790c663d4edf  push rcx
0000790c663d4ee0  push rdx
0000790c663d4ee1  push rdi
0000790c663d4ee2  push rsi
0000790c663d4ee3  push r8
0000790c663d4ee5  push r9
0000790c663d4ee7  push r10
0000790c663d4ee9  push r11
0000790c663d4eeb  sub rsp, 0xF0
0000790c663d4ef2  vmovaps [rsp], xmm0
0000790c663d4ef7  vmovaps [rsp+0x10], xmm1
0000790c663d4efd  vmovaps [rsp+0x20], xmm2
0000790c663d4f03  vmovaps [rsp+0x30], xmm3
0000790c663d4f09  vmovaps [rsp+0x40], xmm4
0000790c663d4f0f  vmovaps [rsp+0x50], xmm5
0000790c663d4f15  vmovaps [rsp+0x60], xmm6
0000790c663d4f1b  vmovaps [rsp+0x70], xmm8
0000790c663d4f21  vmovaps [rsp+0x80], xmm9
0000790c663d4f2a  vmovaps [rsp+0x90], xmm10
0000790c663d4f33  vmovaps [rsp+0xA0], xmm11
0000790c663d4f3c  vmovaps [rsp+0xB0], xmm12
0000790c663d4f45  vmovaps [rsp+0xC0], xmm13
0000790c663d4f4e  vmovaps [rsp+0xD0], xmm14
0000790c663d4f57  vmovaps [rsp+0xE0], xmm15
0000790c663d4f60  sub rsp, 0x30
0000790c663d4f64  movaps [rsp], xmm7
0000790c663d4f68  movaps [rsp+0x10], xmm15
0000790c663d4f6e  movaps [rsp+0x20], xmm10
0000790c663d4f74  lea rdi, [rsp]
0000790c663d4f78  mov esi, 0x00
0000790c663d4f7d  mov rax, 0x631C1759F530
0000790c663d4f87  call rax
0000790c663d4f89  movaps xmm7, [rsp]
0000790c663d4f8d  add rsp, 0x30
0000790c663d4f91  vmovaps xmm0, [rsp]
0000790c663d4f96  vmovaps xmm1, [rsp+0x10]
0000790c663d4f9c  vmovaps xmm2, [rsp+0x20]
0000790c663d4fa2  vmovaps xmm3, [rsp+0x30]
0000790c663d4fa8  vmovaps xmm4, [rsp+0x40]
0000790c663d4fae  vmovaps xmm5, [rsp+0x50]
0000790c663d4fb4  vmovaps xmm6, [rsp+0x60]
0000790c663d4fba  vmovaps xmm8, [rsp+0x70]
0000790c663d4fc0  vmovaps xmm9, [rsp+0x80]
0000790c663d4fc9  vmovaps xmm10, [rsp+0x90]
0000790c663d4fd2  vmovaps xmm11, [rsp+0xA0]
0000790c663d4fdb  vmovaps xmm12, [rsp+0xB0]
0000790c663d4fe4  vmovaps xmm13, [rsp+0xC0]
0000790c663d4fed  vmovaps xmm14, [rsp+0xD0]
0000790c663d4ff6  vmovaps xmm15, [rsp+0xE0]
0000790c663d4fff  add rsp, 0xF0
0000790c663d5006  pop r11
0000790c663d5008  pop r10
0000790c663d500a  pop r9
0000790c663d500c  pop r8
0000790c663d500e  pop rsi
0000790c663d500f  pop rdi
0000790c663d5010  pop rdx
0000790c663d5011  pop rcx
0000790c663d5012  pop rax
0000790c663d5013  add rsp, 0x08
0000790c663d5017  jmp 0x0000790C663D025D
0000790c663d501c  sub rsp, 0x08
0000790c663d5020  push rax
0000790c663d5021  push rcx
0000790c663d5022  push rdx
0000790c663d5023  push rdi
0000790c663d5024  push rsi
0000790c663d5025  push r8
0000790c663d5027  push r9
0000790c663d5029  push r10
0000790c663d502b  push r11
0000790c663d502d  sub rsp, 0xF0
0000790c663d5034  vmovaps [rsp], xmm0
0000790c663d5039  vmovaps [rsp+0x10], xmm1
0000790c663d503f  vmovaps [rsp+0x20], xmm2
0000790c663d5045  vmovaps [rsp+0x30], xmm3
0000790c663d504b  vmovaps [rsp+0x40], xmm4
0000790c663d5051  vmovaps [rsp+0x50], xmm5
0000790c663d5057  vmovaps [rsp+0x60], xmm6
0000790c663d505d  vmovaps [rsp+0x70], xmm7
0000790c663d5063  vmovaps [rsp+0x80], xmm8
0000790c663d506c  vmovaps [rsp+0x90], xmm9
0000790c663d5075  vmovaps [rsp+0xA0], xmm11
0000790c663d507e  vmovaps [rsp+0xB0], xmm12
0000790c663d5087  vmovaps [rsp+0xC0], xmm13
0000790c663d5090  vmovaps [rsp+0xD0], xmm14
0000790c663d5099  vmovaps [rsp+0xE0], xmm15
0000790c663d50a2  sub rsp, 0x30
0000790c663d50a6  movaps [rsp], xmm10
0000790c663d50ab  movaps [rsp+0x10], xmm11
0000790c663d50b1  movaps [rsp+0x20], xmm15
0000790c663d50b7  lea rdi, [rsp]
0000790c663d50bb  mov esi, 0x00
0000790c663d50c0  mov rax, 0x631C1759F530
0000790c663d50ca  call rax
0000790c663d50cc  movaps xmm10, [rsp]
0000790c663d50d1  add rsp, 0x30
0000790c663d50d5  vmovaps xmm0, [rsp]
0000790c663d50da  vmovaps xmm1, [rsp+0x10]
0000790c663d50e0  vmovaps xmm2, [rsp+0x20]
0000790c663d50e6  vmovaps xmm3, [rsp+0x30]
0000790c663d50ec  vmovaps xmm4, [rsp+0x40]
0000790c663d50f2  vmovaps xmm5, [rsp+0x50]
0000790c663d50f8  vmovaps xmm6, [rsp+0x60]
0000790c663d50fe  vmovaps xmm7, [rsp+0x70]
0000790c663d5104  vmovaps xmm8, [rsp+0x80]
0000790c663d510d  vmovaps xmm9, [rsp+0x90]
0000790c663d5116  vmovaps xmm11, [rsp+0xA0]
0000790c663d511f  vmovaps xmm12, [rsp+0xB0]
0000790c663d5128  vmovaps xmm13, [rsp+0xC0]
0000790c663d5131  vmovaps xmm14, [rsp+0xD0]
0000790c663d513a  vmovaps xmm15, [rsp+0xE0]
0000790c663d5143  add rsp, 0xF0
0000790c663d514a  pop r11
0000790c663d514c  pop r10
0000790c663d514e  pop r9
0000790c663d5150  pop r8
0000790c663d5152  pop rsi
0000790c663d5153  pop rdi
0000790c663d5154  pop rdx
0000790c663d5155  pop rcx
0000790c663d5156  pop rax
0000790c663d5157  add rsp, 0x08
0000790c663d515b  jmp 0x0000790C663D028B
0000790c663d5160  sub rsp, 0x08
0000790c663d5164  push rax
0000790c663d5165  push rcx
0000790c663d5166  push rdx
0000790c663d5167  push rdi
0000790c663d5168  push rsi
0000790c663d5169  push r8
0000790c663d516b  push r9
0000790c663d516d  push r10
0000790c663d516f  push r11
0000790c663d5171  sub rsp, 0xF0
0000790c663d5178  vmovaps [rsp], xmm0
0000790c663d517d  vmovaps [rsp+0x10], xmm1
0000790c663d5183  vmovaps [rsp+0x20], xmm2
0000790c663d5189  vmovaps [rsp+0x30], xmm3
0000790c663d518f  vmovaps [rsp+0x40], xmm4
0000790c663d5195  vmovaps [rsp+0x50], xmm5
0000790c663d519b  vmovaps [rsp+0x60], xmm6
0000790c663d51a1  vmovaps [rsp+0x70], xmm7
0000790c663d51a7  vmovaps [rsp+0x80], xmm8
0000790c663d51b0  vmovaps [rsp+0x90], xmm9
0000790c663d51b9  vmovaps [rsp+0xA0], xmm10
0000790c663d51c2  vmovaps [rsp+0xB0], xmm12
0000790c663d51cb  vmovaps [rsp+0xC0], xmm13
0000790c663d51d4  vmovaps [rsp+0xD0], xmm14
0000790c663d51dd  vmovaps [rsp+0xE0], xmm15
0000790c663d51e6  sub rsp, 0x30
0000790c663d51ea  movaps [rsp], xmm11
0000790c663d51ef  movaps [rsp+0x10], xmm12
0000790c663d51f5  movaps [rsp+0x20], xmm15
0000790c663d51fb  lea rdi, [rsp]
0000790c663d51ff  mov esi, 0x00
0000790c663d5204  mov rax, 0x631C1759F530
0000790c663d520e  call rax
0000790c663d5210  movaps xmm11, [rsp]
0000790c663d5215  add rsp, 0x30
0000790c663d5219  vmovaps xmm0, [rsp]
0000790c663d521e  vmovaps xmm1, [rsp+0x10]
0000790c663d5224  vmovaps xmm2, [rsp+0x20]
0000790c663d522a  vmovaps xmm3, [rsp+0x30]
0000790c663d5230  vmovaps xmm4, [rsp+0x40]
0000790c663d5236  vmovaps xmm5, [rsp+0x50]
0000790c663d523c  vmovaps xmm6, [rsp+0x60]
0000790c663d5242  vmovaps xmm7, [rsp+0x70]
0000790c663d5248  vmovaps xmm8, [rsp+0x80]
0000790c663d5251  vmovaps xmm9, [rsp+0x90]
0000790c663d525a  vmovaps xmm10, [rsp+0xA0]
0000790c663d5263  vmovaps xmm12, [rsp+0xB0]
0000790c663d526c  vmovaps xmm13, [rsp+0xC0]
0000790c663d5275  vmovaps xmm14, [rsp+0xD0]
0000790c663d527e  vmovaps xmm15, [rsp+0xE0]
0000790c663d5287  add rsp, 0xF0
0000790c663d528e  pop r11
0000790c663d5290  pop r10
0000790c663d5292  pop r9
0000790c663d5294  pop r8
0000790c663d5296  pop rsi
0000790c663d5297  pop rdi
0000790c663d5298  pop rdx
0000790c663d5299  pop rcx
0000790c663d529a  pop rax
0000790c663d529b  add rsp, 0x08
0000790c663d529f  jmp 0x0000790C663D02B9
0000790c663d52a4  sub rsp, 0x08
0000790c663d52a8  push rax
0000790c663d52a9  push rcx
0000790c663d52aa  push rdx
0000790c663d52ab  push rdi
0000790c663d52ac  push rsi
0000790c663d52ad  push r8
0000790c663d52af  push r9
0000790c663d52b1  push r10
0000790c663d52b3  push r11
0000790c663d52b5  sub rsp, 0xF0
0000790c663d52bc  vmovaps [rsp], xmm0
0000790c663d52c1  vmovaps [rsp+0x10], xmm1
0000790c663d52c7  vmovaps [rsp+0x20], xmm2
0000790c663d52cd  vmovaps [rsp+0x30], xmm3
0000790c663d52d3  vmovaps [rsp+0x40], xmm4
0000790c663d52d9  vmovaps [rsp+0x50], xmm5
0000790c663d52df  vmovaps [rsp+0x60], xmm6
0000790c663d52e5  vmovaps [rsp+0x70], xmm7
0000790c663d52eb  vmovaps [rsp+0x80], xmm8
0000790c663d52f4  vmovaps [rsp+0x90], xmm9
0000790c663d52fd  vmovaps [rsp+0xA0], xmm10
0000790c663d5306  vmovaps [rsp+0xB0], xmm11
0000790c663d530f  vmovaps [rsp+0xC0], xmm12
0000790c663d5318  vmovaps [rsp+0xD0], xmm13
0000790c663d5321  vmovaps [rsp+0xE0], xmm14
0000790c663d532a  sub rsp, 0x30
0000790c663d532e  movaps [rsp], xmm15
0000790c663d5333  movaps [rsp+0x10], xmm13
0000790c663d5339  movaps [rsp+0x20], xmm9
0000790c663d533f  lea rdi, [rsp]
0000790c663d5343  mov esi, 0x00
0000790c663d5348  mov rax, 0x631C1759F530
0000790c663d5352  call rax
0000790c663d5354  movaps xmm15, [rsp]
0000790c663d5359  add rsp, 0x30
0000790c663d535d  vmovaps xmm0, [rsp]
0000790c663d5362  vmovaps xmm1, [rsp+0x10]
0000790c663d5368  vmovaps xmm2, [rsp+0x20]
0000790c663d536e  vmovaps xmm3, [rsp+0x30]
0000790c663d5374  vmovaps xmm4, [rsp+0x40]
0000790c663d537a  vmovaps xmm5, [rsp+0x50]
0000790c663d5380  vmovaps xmm6, [rsp+0x60]
0000790c663d5386  vmovaps xmm7, [rsp+0x70]
0000790c663d538c  vmovaps xmm8, [rsp+0x80]
0000790c663d5395  vmovaps xmm9, [rsp+0x90]
0000790c663d539e  vmovaps xmm10, [rsp+0xA0]
0000790c663d53a7  vmovaps xmm11, [rsp+0xB0]
0000790c663d53b0  vmovaps xmm12, [rsp+0xC0]
0000790c663d53b9  vmovaps xmm13, [rsp+0xD0]
0000790c663d53c2  vmovaps xmm14, [rsp+0xE0]
0000790c663d53cb  add rsp, 0xF0
0000790c663d53d2  pop r11
0000790c663d53d4  pop r10
0000790c663d53d6  pop r9
0000790c663d53d8  pop r8
0000790c663d53da  pop rsi
0000790c663d53db  pop rdi
0000790c663d53dc  pop rdx
0000790c663d53dd  pop rcx
0000790c663d53de  pop rax
0000790c663d53df  add rsp, 0x08
0000790c663d53e3  jmp 0x0000790C663D02D4
0000790c663d53e8  sub rsp, 0x08
0000790c663d53ec  push rax
0000790c663d53ed  push rcx
0000790c663d53ee  push rdx
0000790c663d53ef  push rdi
0000790c663d53f0  push rsi
0000790c663d53f1  push r8
0000790c663d53f3  push r9
0000790c663d53f5  push r10
0000790c663d53f7  push r11
0000790c663d53f9  sub rsp, 0xF0
0000790c663d5400  vmovaps [rsp], xmm0
0000790c663d5405  vmovaps [rsp+0x10], xmm1
0000790c663d540b  vmovaps [rsp+0x20], xmm2
0000790c663d5411  vmovaps [rsp+0x30], xmm3
0000790c663d5417  vmovaps [rsp+0x40], xmm4
0000790c663d541d  vmovaps [rsp+0x50], xmm5
0000790c663d5423  vmovaps [rsp+0x60], xmm6
0000790c663d5429  vmovaps [rsp+0x70], xmm7
0000790c663d542f  vmovaps [rsp+0x80], xmm8
0000790c663d5438  vmovaps [rsp+0x90], xmm9
0000790c663d5441  vmovaps [rsp+0xA0], xmm10
0000790c663d544a  vmovaps [rsp+0xB0], xmm11
0000790c663d5453  vmovaps [rsp+0xC0], xmm12
0000790c663d545c  vmovaps [rsp+0xD0], xmm14
0000790c663d5465  vmovaps [rsp+0xE0], xmm15
0000790c663d546e  sub rsp, 0x30
0000790c663d5472  movaps [rsp], xmm13
0000790c663d5477  movaps [rsp+0x10], xmm8
0000790c663d547d  movaps [rsp+0x20], xmm14
0000790c663d5483  lea rdi, [rsp]
0000790c663d5487  mov esi, 0x00
0000790c663d548c  mov rax, 0x631C1759F530
0000790c663d5496  call rax
0000790c663d5498  movaps xmm13, [rsp]
0000790c663d549d  add rsp, 0x30
0000790c663d54a1  vmovaps xmm0, [rsp]
0000790c663d54a6  vmovaps xmm1, [rsp+0x10]
0000790c663d54ac  vmovaps xmm2, [rsp+0x20]
0000790c663d54b2  vmovaps xmm3, [rsp+0x30]
0000790c663d54b8  vmovaps xmm4, [rsp+0x40]
0000790c663d54be  vmovaps xmm5, [rsp+0x50]
0000790c663d54c4  vmovaps xmm6, [rsp+0x60]
0000790c663d54ca  vmovaps xmm7, [rsp+0x70]
0000790c663d54d0  vmovaps xmm8, [rsp+0x80]
0000790c663d54d9  vmovaps xmm9, [rsp+0x90]
0000790c663d54e2  vmovaps xmm10, [rsp+0xA0]
0000790c663d54eb  vmovaps xmm11, [rsp+0xB0]
0000790c663d54f4  vmovaps xmm12, [rsp+0xC0]
0000790c663d54fd  vmovaps xmm14, [rsp+0xD0]
0000790c663d5506  vmovaps xmm15, [rsp+0xE0]
0000790c663d550f  add rsp, 0xF0
0000790c663d5516  pop r11
0000790c663d5518  pop r10
0000790c663d551a  pop r9
0000790c663d551c  pop r8
0000790c663d551e  pop rsi
0000790c663d551f  pop rdi
0000790c663d5520  pop rdx
0000790c663d5521  pop rcx
0000790c663d5522  pop rax
0000790c663d5523  add rsp, 0x08
0000790c663d5527  jmp 0x0000790C663D02F7
0000790c663d552c  sub rsp, 0x08
0000790c663d5530  push rax
0000790c663d5531  push rcx
0000790c663d5532  push rdx
0000790c663d5533  push rdi
0000790c663d5534  push rsi
0000790c663d5535  push r8
0000790c663d5537  push r9
0000790c663d5539  push r10
0000790c663d553b  push r11
0000790c663d553d  sub rsp, 0xF0
0000790c663d5544  vmovaps [rsp], xmm0
0000790c663d5549  vmovaps [rsp+0x10], xmm1
0000790c663d554f  vmovaps [rsp+0x20], xmm2
0000790c663d5555  vmovaps [rsp+0x30], xmm3
0000790c663d555b  vmovaps [rsp+0x40], xmm4
0000790c663d5561  vmovaps [rsp+0x50], xmm5
0000790c663d5567  vmovaps [rsp+0x60], xmm6
0000790c663d556d  vmovaps [rsp+0x70], xmm7
0000790c663d5573  vmovaps [rsp+0x80], xmm8
0000790c663d557c  vmovaps [rsp+0x90], xmm9
0000790c663d5585  vmovaps [rsp+0xA0], xmm10
0000790c663d558e  vmovaps [rsp+0xB0], xmm11
0000790c663d5597  vmovaps [rsp+0xC0], xmm12
0000790c663d55a0  vmovaps [rsp+0xD0], xmm13
0000790c663d55a9  vmovaps [rsp+0xE0], xmm15
0000790c663d55b2  sub rsp, 0x30
0000790c663d55b6  movaps [rsp], xmm14
0000790c663d55bb  movaps [rsp+0x10], xmm1
0000790c663d55c0  movaps [rsp+0x20], xmm10
0000790c663d55c6  lea rdi, [rsp]
0000790c663d55ca  mov esi, 0x00
0000790c663d55cf  mov rax, 0x631C1759F530
0000790c663d55d9  call rax
0000790c663d55db  movaps xmm14, [rsp]
0000790c663d55e0  add rsp, 0x30
0000790c663d55e4  vmovaps xmm0, [rsp]
0000790c663d55e9  vmovaps xmm1, [rsp+0x10]
0000790c663d55ef  vmovaps xmm2, [rsp+0x20]
0000790c663d55f5  vmovaps xmm3, [rsp+0x30]
0000790c663d55fb  vmovaps xmm4, [rsp+0x40]
0000790c663d5601  vmovaps xmm5, [rsp+0x50]
0000790c663d5607  vmovaps xmm6, [rsp+0x60]
0000790c663d560d  vmovaps xmm7, [rsp+0x70]
0000790c663d5613  vmovaps xmm8, [rsp+0x80]
0000790c663d561c  vmovaps xmm9, [rsp+0x90]
0000790c663d5625  vmovaps xmm10, [rsp+0xA0]
0000790c663d562e  vmovaps xmm11, [rsp+0xB0]
0000790c663d5637  vmovaps xmm12, [rsp+0xC0]
0000790c663d5640  vmovaps xmm13, [rsp+0xD0]
0000790c663d5649  vmovaps xmm15, [rsp+0xE0]
0000790c663d5652  add rsp, 0xF0
0000790c663d5659  pop r11
0000790c663d565b  pop r10
0000790c663d565d  pop r9
0000790c663d565f  pop r8
0000790c663d5661  pop rsi
0000790c663d5662  pop rdi
0000790c663d5663  pop rdx
0000790c663d5664  pop rcx
0000790c663d5665  pop rax
0000790c663d5666  add rsp, 0x08
0000790c663d566a  jmp 0x0000790C663D031A
0000790c663d566f  sub rsp, 0x08
0000790c663d5673  push rax
0000790c663d5674  push rcx
0000790c663d5675  push rdx
0000790c663d5676  push rdi
0000790c663d5677  push rsi
0000790c663d5678  push r8
0000790c663d567a  push r9
0000790c663d567c  push r10
0000790c663d567e  push r11
0000790c663d5680  sub rsp, 0xF0
0000790c663d5687  vmovaps [rsp], xmm0
0000790c663d568c  vmovaps [rsp+0x10], xmm2
0000790c663d5692  vmovaps [rsp+0x20], xmm3
0000790c663d5698  vmovaps [rsp+0x30], xmm4
0000790c663d569e  vmovaps [rsp+0x40], xmm5
0000790c663d56a4  vmovaps [rsp+0x50], xmm6
0000790c663d56aa  vmovaps [rsp+0x60], xmm7
0000790c663d56b0  vmovaps [rsp+0x70], xmm8
0000790c663d56b6  vmovaps [rsp+0x80], xmm9
0000790c663d56bf  vmovaps [rsp+0x90], xmm10
0000790c663d56c8  vmovaps [rsp+0xA0], xmm11
0000790c663d56d1  vmovaps [rsp+0xB0], xmm12
0000790c663d56da  vmovaps [rsp+0xC0], xmm13
0000790c663d56e3  vmovaps [rsp+0xD0], xmm14
0000790c663d56ec  vmovaps [rsp+0xE0], xmm15
0000790c663d56f5  sub rsp, 0x30
0000790c663d56f9  movaps [rsp], xmm1
0000790c663d56fd  movaps [rsp+0x10], xmm7
0000790c663d5702  movaps [rsp+0x20], xmm11
0000790c663d5708  lea rdi, [rsp]
0000790c663d570c  mov esi, 0x00
0000790c663d5711  mov rax, 0x631C1759F530
0000790c663d571b  call rax
0000790c663d571d  movaps xmm1, [rsp]
0000790c663d5721  add rsp, 0x30
0000790c663d5725  vmovaps xmm0, [rsp]
0000790c663d572a  vmovaps xmm2, [rsp+0x10]
0000790c663d5730  vmovaps xmm3, [rsp+0x20]
0000790c663d5736  vmovaps xmm4, [rsp+0x30]
0000790c663d573c  vmovaps xmm5, [rsp+0x40]
0000790c663d5742  vmovaps xmm6, [rsp+0x50]
0000790c663d5748  vmovaps xmm7, [rsp+0x60]
0000790c663d574e  vmovaps xmm8, [rsp+0x70]
0000790c663d5754  vmovaps xmm9, [rsp+0x80]
0000790c663d575d  vmovaps xmm10, [rsp+0x90]
0000790c663d5766  vmovaps xmm11, [rsp+0xA0]
0000790c663d576f  vmovaps xmm12, [rsp+0xB0]
0000790c663d5778  vmovaps xmm13, [rsp+0xC0]
0000790c663d5781  vmovaps xmm14, [rsp+0xD0]
0000790c663d578a  vmovaps xmm15, [rsp+0xE0]
0000790c663d5793  add rsp, 0xF0
0000790c663d579a  pop r11
0000790c663d579c  pop r10
0000790c663d579e  pop r9
0000790c663d57a0  pop r8
0000790c663d57a2  pop rsi
0000790c663d57a3  pop rdi
0000790c663d57a4  pop rdx
0000790c663d57a5  pop rcx
0000790c663d57a6  pop rax
0000790c663d57a7  add rsp, 0x08
0000790c663d57ab  jmp 0x0000790C663D033B
0000790c663d57b0  call 0x0000790C6620E880
0000790c663d57b5  jmp 0x0000790C663D034E
0000790c663d57ba  call 0x0000790C6620C380
0000790c663d57bf  jmp 0x0000790C663D0359
0000790c663d57c4  call 0x0000790C6620D600
0000790c663d57c9  jmp 0x0000790C663D0364
0000790c663d57ce  call 0x0000790C661FF540
0000790c663d57d3  jmp 0x0000790C663D036F
0000790c663d57d8  int3
0000790c663d57d9  nop [rax], eax
0000790c663d57e0  mov rax, [r15+0x40]
0000790c663d57e4  mov r14, [r15+0x58]
0000790c663d57e8  lea r12, [rax+r14*1]
0000790c663d57ec  movaps xmm1, [r15+0x1D0]
0000790c663d57f4  vmovaps [rsp+0x10], xmm1
0000790c663d57fa  vmovaps xmm15, [rsp+0x10]
0000790c663d5800  por xmm1, xmm15
0000790c663d5805  movaps xmm14, [r15+0x1A0]
0000790c663d580d  vmovaps [rsp+0x10], xmm14
0000790c663d5813  vmovaps xmm13, [rsp+0x10]
0000790c663d5819  por xmm14, xmm13
0000790c663d581e  lea rax, [r12+0x30]
0000790c663d5823  mov r11, [r13+rax*1]
0000790c663d5828  lea rax, [r12+0x38]
0000790c663d582d  mov r10, [r13+rax*1]
0000790c663d5832  movq xmm13, r11
0000790c663d5837  movq xmm12, r10
0000790c663d583c  movq xmm13, xmm13
0000790c663d5841  vmovaps [rsp+0x10], xmm13
0000790c663d5847  movq xmm13, xmm13
0000790c663d584c  movaps [r15+0x130], xmm13
0000790c663d5854  movq xmm12, xmm12
0000790c663d5859  vmovaps [rsp+0x20], xmm12
0000790c663d585f  movq xmm12, xmm12
0000790c663d5864  movaps [r15+0x280], xmm12
0000790c663d586c  movaps xmm13, [r15+0x270]
0000790c663d5874  vmovaps [rsp+0x30], xmm13
0000790c663d587a  vmovaps xmm12, [rsp+0x30]
0000790c663d5880  por xmm13, xmm12
0000790c663d5885  lea rax, [r12+0x20]
0000790c663d588a  mov r11, [r13+rax*1]
0000790c663d588f  lea rax, [r12+0x28]
0000790c663d5894  mov r10, [r13+rax*1]
0000790c663d5899  movq xmm12, r11
0000790c663d589e  movq xmm11, r10
0000790c663d58a3  movq xmm12, xmm12
0000790c663d58a8  vmovaps [rsp+0x30], xmm12
0000790c663d58ae  movq xmm12, xmm12
0000790c663d58b3  movaps [r15+0x150], xmm12
0000790c663d58bb  movq xmm11, xmm11
0000790c663d58c0  vmovaps [rsp+0x40], xmm11
0000790c663d58c6  movq xmm11, xmm11
0000790c663d58cb  movaps [r15+0x140], xmm11
0000790c663d58d3  lea rax, [r12+0x10]
0000790c663d58d8  mov r11, [r13+rax*1]
0000790c663d58dd  lea rax, [r12+0x18]
0000790c663d58e2  mov r10, [r13+rax*1]
0000790c663d58e7  movq xmm12, r11
0000790c663d58ec  movq xmm11, r10
0000790c663d58f1  movq xmm12, xmm12
0000790c663d58f6  vmovaps [rsp+0x50], xmm12
0000790c663d58fc  movq xmm12, xmm12
0000790c663d5901  movaps [r15+0x170], xmm12
0000790c663d5909  movq xmm11, xmm11
0000790c663d590e  vmovaps [rsp+0x60], xmm11
0000790c663d5914  movq xmm11, xmm11
0000790c663d5919  movaps [r15+0x160], xmm11
0000790c663d5921  mov rax, [r13+r12*1]
0000790c663d5926  vmovq xmm12, rax
0000790c663d592b  vpbroadcastq xmm12, xmm12
0000790c663d5930  lea rax, [r12+0x08]
0000790c663d5935  mov r12, [r13+rax*1]
0000790c663d593a  movq xmm11, r12
0000790c663d593f  movaps [r15+0x230], xmm11
0000790c663d5947  mov rax, [r15+0xF8]
0000790c663d594e  lea r12, [rax+0x50]
0000790c663d5952  movups xmm11, [r13+r12*1]
0000790c663d5958  lea r12, [rax+0x60]
0000790c663d595c  movups xmm10, [r13+r12*1]
0000790c663d5962  lea r12, [rax+0x30]
0000790c663d5966  movups xmm9, [r13+r12*1]
0000790c663d596c  mov r12, [r15+0x50]
0000790c663d5970  lea r11, [r12+r14*1]
0000790c663d5974  mov [r15+0x60], r11
0000790c663d5978  lea r12, [r14+0x40]
0000790c663d597c  mov [r15+0x58], r12
0000790c663d5980  movaps xmm8, xmm12
0000790c663d5984  mulpd xmm8, xmm15
0000790c663d5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000790c663d598f  ptest xmm7, xmm7
0000790c663d5994  jnz 0x0000790C663D67B7
0000790c663d599a  movq xmm15, qword ptr [r15+0x230]
0000790c663d59a3  vmovaps [rsp+0x70], xmm15
0000790c663d59a9  vpermilpd xmm15, xmm15, 0x00
0000790c663d59af  movaps xmm7, xmm9
0000790c663d59b3  mulpd xmm7, xmm15
0000790c663d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000790c663d59bd  ptest xmm6, xmm6
0000790c663d59c2  jnz 0x0000790C663D68FB
0000790c663d59c8  vxorps xmm15, xmm15, xmm15
0000790c663d59cd  vpbroadcastq xmm15, xmm15
0000790c663d59d2  movaps xmm9, xmm12
0000790c663d59d6  mulpd xmm9, xmm10
0000790c663d59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000790c663d59e1  ptest xmm6, xmm6
0000790c663d59e6  jnz 0x0000790C663D6A3D
0000790c663d59ec  movaps xmm10, xmm12
0000790c663d59f0  mulpd xmm10, xmm11
0000790c663d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000790c663d59fb  ptest xmm6, xmm6
0000790c663d5a00  jnz 0x0000790C663D6B81
0000790c663d5a06  movaps xmm11, [r15+0x1F0]
0000790c663d5a0e  movaps xmm6, xmm12
0000790c663d5a12  mulpd xmm6, xmm11
0000790c663d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000790c663d5a1c  ptest xmm5, xmm5
0000790c663d5a21  jnz 0x0000790C663D6CC5
0000790c663d5a27  movaps xmm12, [r15+0x2A0]
0000790c663d5a2f  vmovaps [rsp+0x80], xmm12
0000790c663d5a38  vmovaps xmm11, [rsp+0x80]
0000790c663d5a41  por xmm12, xmm11
0000790c663d5a46  movaps xmm11, [r15+0x250]
0000790c663d5a4e  vmovaps [rsp+0x80], xmm11
0000790c663d5a57  vmovaps xmm5, [rsp+0x80]
0000790c663d5a60  por xmm11, xmm5
0000790c663d5a65  vmovaps xmm4, [rsp+0x70]
0000790c663d5a6b  vpermilpd xmm4, xmm4, 0x00
0000790c663d5a71  movaps xmm3, xmm5
0000790c663d5a74  mulpd xmm3, xmm4
0000790c663d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000790c663d5a7d  ptest xmm2, xmm2
0000790c663d5a82  jnz 0x0000790C663D6E07
0000790c663d5a88  mov [rsp+0x80], rax
0000790c663d5a90  xor eax, eax
0000790c663d5a92  mov r14d, 0x200
0000790c663d5a98  cmp r12, r14
0000790c663d5a9b  cmc
0000790c663d5a9c  lahf
0000790c663d5a9d  seto al
0000790c663d5aa0  mov [r15+0x108], eax
0000790c663d5aa7  movaps xmm5, xmm8
0000790c663d5aab  addpd xmm5, xmm15
0000790c663d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000790c663d5ab5  ptest xmm4, xmm4
0000790c663d5aba  jnz 0x0000790C663D6F47
0000790c663d5ac0  movaps xmm8, [r15+0x1B0]
0000790c663d5ac8  movaps xmm4, xmm9
0000790c663d5acc  addpd xmm4, xmm8
0000790c663d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000790c663d5ad6  ptest xmm2, xmm2
0000790c663d5adb  jnz 0x0000790C663D7089
0000790c663d5ae1  movaps xmm9, xmm10
0000790c663d5ae5  addpd xmm9, xmm8
0000790c663d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000790c663d5af0  ptest xmm2, xmm2
0000790c663d5af5  jnz 0x0000790C663D71CB
0000790c663d5afb  movaps xmm10, [r15+0x2F0]
0000790c663d5b03  vmovaps [rsp+0x90], xmm10
0000790c663d5b0c  vmovaps xmm8, [rsp+0x90]
0000790c663d5b15  por xmm10, xmm8
0000790c663d5b1a  movaps xmm8, [r15+0x2E0]
0000790c663d5b22  vmovaps [rsp+0x90], xmm8
0000790c663d5b2b  vmovaps xmm2, [rsp+0x90]
0000790c663d5b34  por xmm8, xmm2
0000790c663d5b39  movaps xmm2, [r15+0x2D0]
0000790c663d5b41  vmovaps [rsp+0x90], xmm2
0000790c663d5b4a  vmovaps [rsp+0xA0], xmm1
0000790c663d5b53  vmovaps xmm1, [rsp+0x90]
0000790c663d5b5c  por xmm2, xmm1
0000790c663d5b60  movaps xmm1, [r15+0x200]
0000790c663d5b68  vmovaps [rsp+0x90], xmm1
0000790c663d5b71  vmovaps [rsp+0xB0], xmm15
0000790c663d5b7a  vmovaps xmm15, [rsp+0x90]
0000790c663d5b83  por xmm1, xmm15
0000790c663d5b88  movaps xmm15, [r15+0x1C0]
0000790c663d5b90  vmovaps [rsp+0x90], xmm15
0000790c663d5b99  vmovaps [rsp+0xC0], xmm1
0000790c663d5ba2  vmovaps xmm1, [rsp+0x90]
0000790c663d5bab  por xmm15, xmm1
0000790c663d5bb0  movaps xmm1, [r15+0x190]
0000790c663d5bb8  vmovaps [rsp+0x90], xmm1
0000790c663d5bc1  vmovaps [rsp+0xD0], xmm15
0000790c663d5bca  vmovaps xmm15, [rsp+0x90]
0000790c663d5bd3  por xmm1, xmm15
0000790c663d5bd8  movaps xmm15, [r15+0x300]
0000790c663d5be0  vmovaps [rsp+0x90], xmm15
0000790c663d5be9  vmovaps [rsp+0xE0], xmm1
0000790c663d5bf2  vmovaps xmm1, [rsp+0x90]
0000790c663d5bfb  por xmm15, xmm1
0000790c663d5c00  mov rax, [rsp+0x80]
0000790c663d5c08  lea r14, [rax+0xA0]
0000790c663d5c0f  movups xmm1, [r13+r14*1]
0000790c663d5c15  lea r14, [rax+0xB0]
0000790c663d5c1c  vmovaps [rsp+0x80], xmm1
0000790c663d5c25  movups xmm1, [r13+r14*1]
0000790c663d5c2b  vmovaps [rsp+0x90], xmm1
0000790c663d5c34  vmovaps [rsp+0xF0], xmm15
0000790c663d5c3d  vmovaps xmm15, [rsp+0xB0]
0000790c663d5c46  vmovaps [rsp+0xB0], xmm14
0000790c663d5c4f  movaps xmm1, xmm6
0000790c663d5c52  addpd xmm1, xmm15
0000790c663d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000790c663d5c5c  ptest xmm14, xmm14
0000790c663d5c62  jnz 0x0000790C663D7323
0000790c663d5c68  lea r14, [rax+0xF0]
0000790c663d5c6f  movups xmm15, [r13+r14*1]
0000790c663d5c75  movaps xmm14, xmm4
0000790c663d5c79  addpd xmm14, xmm3
0000790c663d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000790c663d5c84  ptest xmm6, xmm6
0000790c663d5c89  jnz 0x0000790C663D746E
0000790c663d5c8f  movaps xmm6, xmm9
0000790c663d5c93  addpd xmm6, xmm7
0000790c663d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000790c663d5c9c  ptest xmm4, xmm4
0000790c663d5ca1  jnz 0x0000790C663D75B0
0000790c663d5ca7  vmovaps xmm9, [rsp+0x70]
0000790c663d5cad  vpermilpd xmm9, xmm9, 0x00
0000790c663d5cb3  vmovaps xmm4, [rsp+0x90]
0000790c663d5cbc  movaps xmm7, xmm4
0000790c663d5cbf  mulpd xmm7, xmm9
0000790c663d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000790c663d5cc9  ptest xmm3, xmm3
0000790c663d5cce  jnz 0x0000790C663D76F1
0000790c663d5cd4  vmovaps xmm9, [rsp+0x50]
0000790c663d5cda  vpermilpd xmm9, xmm9, 0x00
0000790c663d5ce0  movaps xmm4, xmm15
0000790c663d5ce4  mulpd xmm4, xmm9
0000790c663d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000790c663d5cee  ptest xmm3, xmm3
0000790c663d5cf3  jnz 0x0000790C663D7832
0000790c663d5cf9  lea r14, [rax+0xE0]
0000790c663d5d00  movups xmm15, [r13+r14*1]
0000790c663d5d06  vmovaps xmm9, [rsp+0x70]
0000790c663d5d0c  vpermilpd xmm9, xmm9, 0x00
0000790c663d5d12  vmovaps [rsp+0x70], xmm1
0000790c663d5d18  vmovaps xmm1, [rsp+0x80]
0000790c663d5d21  vmovaps [rsp+0x80], xmm15
0000790c663d5d2a  movaps xmm3, xmm1
0000790c663d5d2d  mulpd xmm3, xmm9
0000790c663d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000790c663d5d37  ptest xmm15, xmm15
0000790c663d5d3d  jnz 0x0000790C663D797E
0000790c663d5d43  vmovaps xmm1, [rsp+0xF0]
0000790c663d5d4c  vmovaps xmm15, [rsp+0xF0]
0000790c663d5d55  por xmm1, xmm15
0000790c663d5d5a  movaps [r15+0x300], xmm1
0000790c663d5d62  vmovaps xmm15, [rsp+0xE0]
0000790c663d5d6b  vmovaps xmm9, [rsp+0xE0]
0000790c663d5d74  por xmm15, xmm9
0000790c663d5d79  movaps [r15+0x190], xmm15
0000790c663d5d81  vmovaps xmm9, [rsp+0x50]
0000790c663d5d87  vpermilpd xmm9, xmm9, 0x00
0000790c663d5d8d  vmovaps [rsp+0x90], xmm1
0000790c663d5d96  vmovaps [rsp+0xE0], xmm15
0000790c663d5d9f  vmovaps xmm15, [rsp+0x80]
0000790c663d5da8  vmovaps [rsp+0x80], xmm14
0000790c663d5db1  movaps xmm1, xmm15
0000790c663d5db5  mulpd xmm1, xmm9
0000790c663d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000790c663d5dbf  ptest xmm14, xmm14
0000790c663d5dc5  jnz 0x0000790C663D7ABF
0000790c663d5dcb  lea r14, [rax+0x90]
0000790c663d5dd2  movups xmm15, [r13+r14*1]
0000790c663d5dd8  vmovaps xmm14, [rsp+0xD0]
0000790c663d5de1  vmovaps xmm9, [rsp+0xD0]
0000790c663d5dea  por xmm14, xmm9
0000790c663d5def  movaps [r15+0x1C0], xmm14
0000790c663d5df7  vmovaps xmm9, [rsp+0xC0]
0000790c663d5e00  vmovaps [rsp+0xD0], xmm1
0000790c663d5e09  vmovaps xmm1, [rsp+0xC0]
0000790c663d5e12  por xmm9, xmm1
0000790c663d5e17  movaps [r15+0x200], xmm9
0000790c663d5e1f  vmovaps [rsp+0xC0], xmm2
0000790c663d5e28  vmovaps xmm1, [rsp+0xC0]
0000790c663d5e31  por xmm2, xmm1
0000790c663d5e35  movaps [r15+0x2D0], xmm2
0000790c663d5e3d  vmovaps [rsp+0xC0], xmm8
0000790c663d5e46  vmovaps xmm1, [rsp+0xC0]
0000790c663d5e4f  por xmm8, xmm1
0000790c663d5e54  movaps [r15+0x2E0], xmm8
0000790c663d5e5c  vmovaps [rsp+0xC0], xmm15
0000790c663d5e65  movaps xmm1, xmm5
0000790c663d5e68  addpd xmm1, xmm7
0000790c663d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000790c663d5e71  ptest xmm15, xmm15
0000790c663d5e77  jnz 0x0000790C663D7C0B
0000790c663d5e7d  vmovaps xmm15, [rsp+0x50]
0000790c663d5e83  vpermilpd xmm15, xmm15, 0x00
0000790c663d5e89  vmovaps xmm5, [rsp+0xC0]
0000790c663d5e92  vmovaps [rsp+0xC0], xmm1
0000790c663d5e9b  movaps xmm7, xmm5
0000790c663d5e9e  mulpd xmm7, xmm15
0000790c663d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000790c663d5ea8  ptest xmm1, xmm1
0000790c663d5ead  jnz 0x0000790C663D7D4B
0000790c663d5eb3  lea r14, [rax+0x80]
0000790c663d5eba  movups xmm1, [r13+r14*1]
0000790c663d5ec0  vmovaps xmm5, [rsp+0x70]
0000790c663d5ec6  vmovaps [rsp+0x70], xmm1
0000790c663d5ecc  movaps xmm15, xmm5
0000790c663d5ed0  addpd xmm15, xmm3
0000790c663d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000790c663d5edb  ptest xmm1, xmm1
0000790c663d5ee0  jnz 0x0000790C663D7E96
0000790c663d5ee6  vmovaps xmm5, [rsp+0x80]
0000790c663d5eef  movaps xmm1, xmm5
0000790c663d5ef2  addpd xmm1, xmm4
0000790c663d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000790c663d5efb  ptest xmm3, xmm3
0000790c663d5f00  jnz 0x0000790C663D7FD8
0000790c663d5f06  vmovaps [rsp+0x80], xmm10
0000790c663d5f0f  vmovaps xmm5, [rsp+0x80]
0000790c663d5f18  por xmm10, xmm5
0000790c663d5f1d  movaps [r15+0x2F0], xmm10
0000790c663d5f25  vmovaps xmm5, [rsp+0x50]
0000790c663d5f2b  vpermilpd xmm5, xmm5, 0x00
0000790c663d5f31  vmovaps xmm3, [rsp+0x70]
0000790c663d5f37  vmovaps [rsp+0x50], xmm1
0000790c663d5f3d  movaps xmm4, xmm3
0000790c663d5f40  mulpd xmm4, xmm5
0000790c663d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000790c663d5f49  ptest xmm1, xmm1
0000790c663d5f4e  jnz 0x0000790C663D8118
0000790c663d5f54  lea r14, [rax+0xD0]
0000790c663d5f5b  movups xmm1, [r13+r14*1]
0000790c663d5f61  vmovaps xmm3, [rsp+0xD0]
0000790c663d5f6a  vmovaps [rsp+0x70], xmm1
0000790c663d5f70  movaps xmm5, xmm6
0000790c663d5f73  addpd xmm5, xmm3
0000790c663d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000790c663d5f7c  ptest xmm1, xmm1
0000790c663d5f81  jnz 0x0000790C663D8262
0000790c663d5f87  vmovaps xmm1, [rsp+0x60]
0000790c663d5f8d  vpermilpd xmm1, xmm1, 0x00
0000790c663d5f93  movaps xmm6, xmm9
0000790c663d5f97  mulpd xmm6, xmm1
0000790c663d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000790c663d5fa0  ptest xmm3, xmm3
0000790c663d5fa5  jnz 0x0000790C663D83A2
0000790c663d5fab  movaps [r15+0x260], xmm6
0000790c663d5fb3  vxorps xmm1, xmm1, xmm1
0000790c663d5fb7  vpbroadcastq xmm1, xmm1
0000790c663d5fbc  movaps [r15+0x1B0], xmm1
0000790c663d5fc4  vmovaps xmm1, [rsp+0x60]
0000790c663d5fca  vpermilpd xmm1, xmm1, 0x00
0000790c663d5fd0  vmovaps xmm3, [rsp+0x70]
0000790c663d5fd6  vmovaps [rsp+0x70], xmm15
0000790c663d5fdc  movaps xmm9, xmm3
0000790c663d5fe0  mulpd xmm9, xmm1
0000790c663d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000790c663d5feb  ptest xmm15, xmm15
0000790c663d5ff1  jnz 0x0000790C663D84E3
0000790c663d5ff7  lea r14, [rax+0xC0]
0000790c663d5ffe  movups xmm1, [r13+r14*1]
0000790c663d6004  vmovaps xmm3, [rsp+0xC0]
0000790c663d600d  vmovaps [rsp+0x80], xmm1
0000790c663d6016  movaps xmm15, xmm3
0000790c663d601a  addpd xmm15, xmm7
0000790c663d601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000790c663d6025  ptest xmm1, xmm1
0000790c663d602a  jnz 0x0000790C663D862F
0000790c663d6030  vmovaps [rsp+0xC0], xmm13
0000790c663d6039  vmovaps xmm1, [rsp+0xC0]
0000790c663d6042  por xmm13, xmm1
0000790c663d6047  movaps [r15+0x270], xmm13
0000790c663d604f  vmovaps xmm1, [rsp+0xB0]
0000790c663d6058  vmovaps xmm7, [rsp+0xB0]
0000790c663d6061  por xmm1, xmm7
0000790c663d6065  movaps [r15+0x1A0], xmm1
0000790c663d606d  vmovaps xmm1, [rsp+0x60]
0000790c663d6073  vpermilpd xmm1, xmm1, 0x00
0000790c663d6079  vmovaps [rsp+0xB0], xmm1
0000790c663d6082  vmovaps xmm1, [rsp+0x80]
0000790c663d608b  vmovaps [rsp+0x80], xmm15
0000790c663d6094  vmovaps xmm15, [rsp+0xB0]
0000790c663d609d  vmovaps [rsp+0xB0], xmm14
0000790c663d60a6  movaps xmm3, xmm1
0000790c663d60a9  mulpd xmm3, xmm15
0000790c663d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000790c663d60b3  ptest xmm14, xmm14
0000790c663d60b9  jnz 0x0000790C663D8771
0000790c663d60bf  lea r14, [rax+0x20]
0000790c663d60c3  movups xmm1, [r13+r14*1]
0000790c663d60c9  movaps [r15+0x110], xmm1
0000790c663d60d1  vmovaps xmm14, [rsp+0x70]
0000790c663d60d7  vmovaps [rsp+0x70], xmm1
0000790c663d60dd  movaps xmm15, xmm14
0000790c663d60e1  addpd xmm15, xmm4
0000790c663d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000790c663d60ec  ptest xmm1, xmm1
0000790c663d60f1  jnz 0x0000790C663D88BC
0000790c663d60f7  vmovaps xmm1, [rsp+0x60]
0000790c663d60fd  vpermilpd xmm1, xmm1, 0x00
0000790c663d6103  movaps xmm14, xmm2
0000790c663d6107  mulpd xmm14, xmm1
0000790c663d610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000790c663d6112  ptest xmm4, xmm4
0000790c663d6117  jnz 0x0000790C663D89FF
0000790c663d611d  vmovaps xmm4, [rsp+0x50]
0000790c663d6123  movaps xmm1, xmm4
0000790c663d6126  addpd xmm1, xmm9
0000790c663d612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000790c663d6130  ptest xmm2, xmm2
0000790c663d6135  jnz 0x0000790C663D8B41
0000790c663d613b  vmovaps xmm9, [rsp+0x30]
0000790c663d6141  vpermilpd xmm9, xmm9, 0x00
0000790c663d6147  vmovaps xmm2, [rsp+0x70]
0000790c663d614d  vmovaps [rsp+0x50], xmm1
0000790c663d6153  movaps xmm4, xmm2
0000790c663d6156  mulpd xmm4, xmm9
0000790c663d615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000790c663d6160  ptest xmm1, xmm1
0000790c663d6165  jnz 0x0000790C663D8C82
0000790c663d616b  vmovaps xmm1, [rsp+0x30]
0000790c663d6171  vpermilpd xmm1, xmm1, 0x00
0000790c663d6177  vmovaps xmm2, [rsp+0x90]
0000790c663d6180  vmovaps [rsp+0x60], xmm15
0000790c663d6186  movaps xmm9, xmm2
0000790c663d618a  mulpd xmm9, xmm1
0000790c663d618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000790c663d6195  ptest xmm15, xmm15
0000790c663d619b  jnz 0x0000790C663D8DC3
0000790c663d61a1  vmovaps xmm15, [rsp+0x80]
0000790c663d61aa  movaps xmm1, xmm15
0000790c663d61ae  addpd xmm1, xmm6
0000790c663d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000790c663d61b7  ptest xmm2, xmm2
0000790c663d61bc  jnz 0x0000790C663D8F05
0000790c663d61c2  movaps xmm15, xmm5
0000790c663d61c6  addpd xmm15, xmm3
0000790c663d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000790c663d61d1  ptest xmm6, xmm6
0000790c663d61d6  jnz 0x0000790C663D9046
0000790c663d61dc  vmovaps xmm6, [rsp+0x30]
0000790c663d61e2  vpermilpd xmm6, xmm6, 0x00
0000790c663d61e8  movaps xmm5, xmm8
0000790c663d61ec  mulpd xmm5, xmm6
0000790c663d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000790c663d61f5  ptest xmm3, xmm3
0000790c663d61fa  jnz 0x0000790C663D9188
0000790c663d6200  vmovaps xmm8, [rsp+0x30]
0000790c663d6206  vpermilpd xmm8, xmm8, 0x00
0000790c663d620c  movaps xmm6, xmm10
0000790c663d6210  mulpd xmm6, xmm8
0000790c663d6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000790c663d621a  ptest xmm3, xmm3
0000790c663d621f  jnz 0x0000790C663D92C9
0000790c663d6225  vmovaps xmm8, [rsp+0x60]
0000790c663d622b  movaps xmm10, xmm8
0000790c663d622f  addpd xmm10, xmm14
0000790c663d6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000790c663d623a  ptest xmm3, xmm3
0000790c663d623f  jnz 0x0000790C663D940B
0000790c663d6245  vmovaps xmm8, [rsp+0x50]
0000790c663d624b  movaps xmm14, xmm8
0000790c663d624f  addpd xmm14, xmm4
0000790c663d6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000790c663d625a  ptest xmm3, xmm3
0000790c663d625f  jnz 0x0000790C663D954F
0000790c663d6265  vmovaps xmm8, [rsp+0x40]
0000790c663d626b  vpermilpd xmm8, xmm8, 0x00
0000790c663d6271  movaps xmm4, xmm13
0000790c663d6275  mulpd xmm4, xmm8
0000790c663d627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000790c663d627f  ptest xmm3, xmm3
0000790c663d6284  jnz 0x0000790C663D9692
0000790c663d628a  movaps xmm13, xmm15
0000790c663d628e  addpd xmm13, xmm9
0000790c663d6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000790c663d6299  ptest xmm8, xmm8
0000790c663d629f  jnz 0x0000790C663D97D4
0000790c663d62a5  movaps xmm15, xmm1
0000790c663d62a9  addpd xmm15, xmm5
0000790c663d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000790c663d62b4  ptest xmm9, xmm9
0000790c663d62ba  jnz 0x0000790C663D9918
0000790c663d62c0  vmovaps [rsp+0x30], xmm11
0000790c663d62c6  vmovaps xmm1, [rsp+0x30]
0000790c663d62cc  por xmm11, xmm1
0000790c663d62d1  movaps [r15+0x250], xmm11
0000790c663d62d9  vmovaps [rsp+0x30], xmm12
0000790c663d62df  vmovaps xmm1, [rsp+0x30]
0000790c663d62e5  por xmm12, xmm1
0000790c663d62ea  movaps [r15+0x2A0], xmm12
0000790c663d62f2  vmovaps xmm1, [rsp+0xA0]
0000790c663d62fb  vmovaps xmm11, [rsp+0xA0]
0000790c663d6304  por xmm1, xmm11
0000790c663d6309  movaps [r15+0x1D0], xmm1
0000790c663d6311  lea r14, [rax+0x40]
0000790c663d6315  movups xmm1, [r13+r14*1]
0000790c663d631b  movaps [r15+0x2C0], xmm1
0000790c663d6323  vmovaps xmm11, [rsp+0x40]
0000790c663d6329  vpermilpd xmm11, xmm11, 0x00
0000790c663d632f  vmovaps xmm8, [rsp+0xE0]
0000790c663d6338  movaps xmm9, xmm8
0000790c663d633c  mulpd xmm9, xmm11
0000790c663d6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000790c663d6347  ptest xmm5, xmm5
0000790c663d634c  jnz 0x0000790C663D9A64
0000790c663d6352  movaps xmm11, xmm10
0000790c663d6356  addpd xmm11, xmm6
0000790c663d635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000790c663d6361  ptest xmm8, xmm8
0000790c663d6367  jnz 0x0000790C663D9BA8
0000790c663d636d  movaps xmm10, xmm14
0000790c663d6371  addpd xmm10, xmm4
0000790c663d6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000790c663d637c  ptest xmm8, xmm8
0000790c663d6382  jnz 0x0000790C663D9CEB
0000790c663d6388  vmovaps xmm14, [rsp+0x40]
0000790c663d638e  vpermilpd xmm14, xmm14, 0x00
0000790c663d6394  movaps xmm8, xmm1
0000790c663d6398  mulpd xmm8, xmm14
0000790c663d639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000790c663d63a3  ptest xmm6, xmm6
0000790c663d63a8  jnz 0x0000790C663D9E2E
0000790c663d63ae  movaps xmm1, [r15+0x2B0]
0000790c663d63b6  vmovaps xmm14, [rsp+0x40]
0000790c663d63bc  vpermilpd xmm14, xmm14, 0x00
0000790c663d63c2  movaps xmm6, xmm1
0000790c663d63c5  mulpd xmm6, xmm14
0000790c663d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000790c663d63cf  ptest xmm5, xmm5
0000790c663d63d4  jnz 0x0000790C663D9F71
0000790c663d63da  vmovaps xmm1, [rsp+0x10]
0000790c663d63e0  vpermilpd xmm1, xmm1, 0x00
0000790c663d63e6  movaps xmm14, xmm12
0000790c663d63ea  mulpd xmm14, xmm1
0000790c663d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000790c663d63f5  ptest xmm5, xmm5
0000790c663d63fa  jnz 0x0000790C663DA0B2
0000790c663d6400  movaps xmm1, xmm13
0000790c663d6404  addpd xmm1, xmm9
0000790c663d6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000790c663d640e  ptest xmm12, xmm12
0000790c663d6414  jnz 0x0000790C663DA1F5
0000790c663d641a  vmovaps xmm13, [rsp+0x10]
0000790c663d6420  vpermilpd xmm13, xmm13, 0x00
0000790c663d6426  movaps xmm12, xmm7
0000790c663d642a  mulpd xmm12, xmm13
0000790c663d642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000790c663d6435  ptest xmm9, xmm9
0000790c663d643b  jnz 0x0000790C663DA337
0000790c663d6441  movaps xmm13, xmm15
0000790c663d6445  addpd xmm13, xmm8
0000790c663d644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000790c663d6450  ptest xmm9, xmm9
0000790c663d6456  jnz 0x0000790C663DA47A
0000790c663d645c  movaps xmm15, [r15+0x290]
0000790c663d6464  vmovaps xmm9, [rsp+0x10]
0000790c663d646a  vpermilpd xmm9, xmm9, 0x00
0000790c663d6470  movaps xmm8, xmm15
0000790c663d6474  mulpd xmm8, xmm9
0000790c663d6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000790c663d647f  ptest xmm7, xmm7
0000790c663d6484  jnz 0x0000790C663DA5BE
0000790c663d648a  movaps xmm15, xmm11
0000790c663d648e  addpd xmm15, xmm6
0000790c663d6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000790c663d6499  ptest xmm9, xmm9
0000790c663d649f  jnz 0x0000790C663DA702
0000790c663d64a5  movaps xmm11, [r15+0x1E0]
0000790c663d64ad  vmovaps xmm9, [rsp+0x10]
0000790c663d64b3  vpermilpd xmm9, xmm9, 0x00
0000790c663d64b9  movaps xmm7, xmm11
0000790c663d64bd  mulpd xmm7, xmm9
0000790c663d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000790c663d64c7  ptest xmm6, xmm6
0000790c663d64cc  jnz 0x0000790C663DA845
0000790c663d64d2  movaps xmm11, xmm10
0000790c663d64d6  addpd xmm11, xmm14
0000790c663d64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000790c663d64e1  ptest xmm9, xmm9
0000790c663d64e7  jnz 0x0000790C663DA987
0000790c663d64ed  lea r14, [rax+0x70]
0000790c663d64f1  movups xmm14, [r13+r14*1]
0000790c663d64f7  movaps [r15+0x240], xmm14
0000790c663d64ff  movaps xmm10, xmm1
0000790c663d6503  addpd xmm10, xmm12
0000790c663d6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000790c663d650e  ptest xmm9, xmm9
0000790c663d6514  jnz 0x0000790C663DAAD5
0000790c663d651a  movaps [r15+0x170], xmm10
0000790c663d6522  vmovaps xmm1, [rsp+0x20]
0000790c663d6528  vpermilpd xmm1, xmm1, 0x00
0000790c663d652e  movaps xmm12, xmm14
0000790c663d6532  mulpd xmm12, xmm1
0000790c663d6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000790c663d653d  ptest xmm9, xmm9
0000790c663d6543  jnz 0x0000790C663DAC18
0000790c663d6549  vmovaps xmm1, [rsp+0x20]
0000790c663d654f  vpermilpd xmm1, xmm1, 0x00
0000790c663d6555  vmovaps xmm9, [rsp+0xB0]
0000790c663d655e  movaps xmm14, xmm9
0000790c663d6562  mulpd xmm14, xmm1
0000790c663d6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000790c663d656d  ptest xmm6, xmm6
0000790c663d6572  jnz 0x0000790C663DAD5B
0000790c663d6578  movaps [r15+0x180], xmm14
0000790c663d6580  movaps xmm1, xmm13
0000790c663d6584  addpd xmm1, xmm8
0000790c663d6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000790c663d658e  ptest xmm9, xmm9
0000790c663d6594  jnz 0x0000790C663DAE9E
0000790c663d659a  movaps [r15+0x210], xmm1
0000790c663d65a2  movups xmm13, [r13+rax*1]
0000790c663d65a8  lea r14, [rax+0x10]
0000790c663d65ac  movups xmm9, [r13+r14*1]
0000790c663d65b2  movaps [r15+0x230], xmm9
0000790c663d65ba  movaps xmm8, xmm15
0000790c663d65be  addpd xmm8, xmm7
0000790c663d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000790c663d65c9  ptest xmm6, xmm6
0000790c663d65ce  jnz 0x0000790C663DAFF4
0000790c663d65d4  movaps [r15+0x130], xmm8
0000790c663d65dc  vmovaps xmm15, [rsp+0x20]
0000790c663d65e2  vpermilpd xmm15, xmm15, 0x00
0000790c663d65e8  movaps xmm7, xmm9
0000790c663d65ec  mulpd xmm7, xmm15
0000790c663d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000790c663d65f6  ptest xmm6, xmm6
0000790c663d65fb  jnz 0x0000790C663DB137
0000790c663d6601  movaps [r15+0x220], xmm7
0000790c663d6609  vmovaps xmm15, [rsp+0x20]
0000790c663d660f  vpermilpd xmm15, xmm15, 0x00
0000790c663d6615  movaps xmm9, xmm13
0000790c663d6619  mulpd xmm9, xmm15
0000790c663d661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000790c663d6624  ptest xmm6, xmm6
0000790c663d6629  jnz 0x0000790C663DB279
0000790c663d662f  movaps xmm15, xmm11
0000790c663d6633  addpd xmm15, xmm12
0000790c663d6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000790c663d663e  ptest xmm13, xmm13
0000790c663d6644  jnz 0x0000790C663DB3BD
0000790c663d664a  movaps [r15+0x140], xmm15
0000790c663d6652  movaps xmm13, xmm10
0000790c663d6656  addpd xmm13, xmm14
0000790c663d665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000790c663d6661  ptest xmm12, xmm12
0000790c663d6667  jnz 0x0000790C663DB501
0000790c663d666d  movaps [r15+0x150], xmm13
0000790c663d6675  movaps xmm14, xmm1
0000790c663d6679  addpd xmm14, xmm7
0000790c663d667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000790c663d6684  ptest xmm12, xmm12
0000790c663d668a  jnz 0x0000790C663DB645
0000790c663d6690  movaps [r15+0x160], xmm14
0000790c663d6698  movaps xmm1, xmm8
0000790c663d669c  addpd xmm1, xmm9
0000790c663d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000790c663d66a6  ptest xmm12, xmm12
0000790c663d66ac  jnz 0x0000790C663DB787
0000790c663d66b2  movaps [r15+0x120], xmm1
0000790c663d66ba  movups [r13+r11*1], xmm15
0000790c663d66c0  lea rax, [r11+0x10]
0000790c663d66c4  movups [r13+rax*1], xmm13
0000790c663d66ca  lea rax, [r11+0x20]
0000790c663d66ce  movups [r13+rax*1], xmm14
0000790c663d66d4  lea rax, [r11+0x30]
0000790c663d66d8  movups [r13+rax*1], xmm1
0000790c663d66de  mov eax, [r15+0x108]
0000790c663d66e5  sahf
0000790c663d66e6  jnz 0x0000790C663D6718
0000790c663d66e8  cmp dword ptr [r15+0x318], 0x00
0000790c663d66f0  jz 0x0000790C663DB900
0000790c663d66f6  nop [rax+rax*1], ax
0000790c663d66ff  nop [rax+rax*1], eax
0000790c663d6707  mov eax, 0x410444
0000790c663d670c  mov [r15+0x100], rax
0000790c663d6713  jmp 0x0000790C661FE110
0000790c663d6718  cmp dword ptr [r15+0x318], 0x00
0000790c663d6720  jz 0x0000790C663D57E0
0000790c663d6726  nop [rax+rax*1], ax
0000790c663d672f  nop [rax+rax*1], eax
0000790c663d6737  mov eax, 0x410278
0000790c663d673c  mov [r15+0x100], rax
0000790c663d6743  jmp 0x0000790C661FE110
0000790c663d6748  int3
0000790c663d6749  call 0x0000790C6620A4B0
0000790c663d674e  jmp 0x0000790C663D5828
0000790c663d6753  call 0x0000790C66209240
0000790c663d6758  jmp 0x0000790C663D5832
0000790c663d675d  call 0x0000790C6620A4B0
0000790c663d6762  jmp 0x0000790C663D588F
0000790c663d6767  call 0x0000790C66209240
0000790c663d676c  jmp 0x0000790C663D5899
0000790c663d6771  call 0x0000790C6620A4B0
0000790c663d6776  jmp 0x0000790C663D58DD
0000790c663d677b  call 0x0000790C66209240
0000790c663d6780  jmp 0x0000790C663D58E7
0000790c663d6785  call 0x0000790C662B47C0
0000790c663d678a  jmp 0x0000790C663D5926
0000790c663d678f  call 0x0000790C6620B720
0000790c663d6794  jmp 0x0000790C663D593A
0000790c663d6799  call 0x0000790C662BFC30
0000790c663d679e  jmp 0x0000790C663D5958
0000790c663d67a3  call 0x0000790C662BE9C0
0000790c663d67a8  jmp 0x0000790C663D5962
0000790c663d67ad  call 0x0000790C662BD750
0000790c663d67b2  jmp 0x0000790C663D596C
0000790c663d67b7  sub rsp, 0x08
0000790c663d67bb  push rax
0000790c663d67bc  push rcx
0000790c663d67bd  push rdx
0000790c663d67be  push rdi
0000790c663d67bf  push rsi
0000790c663d67c0  push r8
0000790c663d67c2  push r9
0000790c663d67c4  push r10
0000790c663d67c6  push r11
0000790c663d67c8  sub rsp, 0xF0
0000790c663d67cf  vmovaps [rsp], xmm0
0000790c663d67d4  vmovaps [rsp+0x10], xmm1
0000790c663d67da  vmovaps [rsp+0x20], xmm2
0000790c663d67e0  vmovaps [rsp+0x30], xmm3
0000790c663d67e6  vmovaps [rsp+0x40], xmm4
0000790c663d67ec  vmovaps [rsp+0x50], xmm5
0000790c663d67f2  vmovaps [rsp+0x60], xmm6
0000790c663d67f8  vmovaps [rsp+0x70], xmm7
0000790c663d67fe  vmovaps [rsp+0x80], xmm9
0000790c663d6807  vmovaps [rsp+0x90], xmm10
0000790c663d6810  vmovaps [rsp+0xA0], xmm11
0000790c663d6819  vmovaps [rsp+0xB0], xmm12
0000790c663d6822  vmovaps [rsp+0xC0], xmm13
0000790c663d682b  vmovaps [rsp+0xD0], xmm14
0000790c663d6834  vmovaps [rsp+0xE0], xmm15
0000790c663d683d  sub rsp, 0x30
0000790c663d6841  movaps [rsp], xmm8
0000790c663d6846  movaps [rsp+0x10], xmm12
0000790c663d684c  movaps [rsp+0x20], xmm15
0000790c663d6852  lea rdi, [rsp]
0000790c663d6856  mov esi, 0x00
0000790c663d685b  mov rax, 0x631C1759F530
0000790c663d6865  call rax
0000790c663d6867  movaps xmm8, [rsp]
0000790c663d686c  add rsp, 0x30
0000790c663d6870  vmovaps xmm0, [rsp]
0000790c663d6875  vmovaps xmm1, [rsp+0x10]
0000790c663d687b  vmovaps xmm2, [rsp+0x20]
0000790c663d6881  vmovaps xmm3, [rsp+0x30]
0000790c663d6887  vmovaps xmm4, [rsp+0x40]
0000790c663d688d  vmovaps xmm5, [rsp+0x50]
0000790c663d6893  vmovaps xmm6, [rsp+0x60]
0000790c663d6899  vmovaps xmm7, [rsp+0x70]
0000790c663d689f  vmovaps xmm9, [rsp+0x80]
0000790c663d68a8  vmovaps xmm10, [rsp+0x90]
0000790c663d68b1  vmovaps xmm11, [rsp+0xA0]
0000790c663d68ba  vmovaps xmm12, [rsp+0xB0]
0000790c663d68c3  vmovaps xmm13, [rsp+0xC0]
0000790c663d68cc  vmovaps xmm14, [rsp+0xD0]
0000790c663d68d5  vmovaps xmm15, [rsp+0xE0]
0000790c663d68de  add rsp, 0xF0
0000790c663d68e5  pop r11
0000790c663d68e7  pop r10
0000790c663d68e9  pop r9
0000790c663d68eb  pop r8
0000790c663d68ed  pop rsi
0000790c663d68ee  pop rdi
0000790c663d68ef  pop rdx
0000790c663d68f0  pop rcx
0000790c663d68f1  pop rax
0000790c663d68f2  add rsp, 0x08
0000790c663d68f6  jmp 0x0000790C663D599A
0000790c663d68fb  sub rsp, 0x08
0000790c663d68ff  push rax
0000790c663d6900  push rcx
0000790c663d6901  push rdx
0000790c663d6902  push rdi
0000790c663d6903  push rsi
0000790c663d6904  push r8
0000790c663d6906  push r9
0000790c663d6908  push r10
0000790c663d690a  push r11
0000790c663d690c  sub rsp, 0xF0
0000790c663d6913  vmovaps [rsp], xmm0
0000790c663d6918  vmovaps [rsp+0x10], xmm1
0000790c663d691e  vmovaps [rsp+0x20], xmm2
0000790c663d6924  vmovaps [rsp+0x30], xmm3
0000790c663d692a  vmovaps [rsp+0x40], xmm4
0000790c663d6930  vmovaps [rsp+0x50], xmm5
0000790c663d6936  vmovaps [rsp+0x60], xmm6
0000790c663d693c  vmovaps [rsp+0x70], xmm8
0000790c663d6942  vmovaps [rsp+0x80], xmm9
0000790c663d694b  vmovaps [rsp+0x90], xmm10
0000790c663d6954  vmovaps [rsp+0xA0], xmm11
0000790c663d695d  vmovaps [rsp+0xB0], xmm12
0000790c663d6966  vmovaps [rsp+0xC0], xmm13
0000790c663d696f  vmovaps [rsp+0xD0], xmm14
0000790c663d6978  vmovaps [rsp+0xE0], xmm15
0000790c663d6981  sub rsp, 0x30
0000790c663d6985  movaps [rsp], xmm7
0000790c663d6989  movaps [rsp+0x10], xmm9
0000790c663d698f  movaps [rsp+0x20], xmm15
0000790c663d6995  lea rdi, [rsp]
0000790c663d6999  mov esi, 0x00
0000790c663d699e  mov rax, 0x631C1759F530
0000790c663d69a8  call rax
0000790c663d69aa  movaps xmm7, [rsp]
0000790c663d69ae  add rsp, 0x30
0000790c663d69b2  vmovaps xmm0, [rsp]
0000790c663d69b7  vmovaps xmm1, [rsp+0x10]
0000790c663d69bd  vmovaps xmm2, [rsp+0x20]
0000790c663d69c3  vmovaps xmm3, [rsp+0x30]
0000790c663d69c9  vmovaps xmm4, [rsp+0x40]
0000790c663d69cf  vmovaps xmm5, [rsp+0x50]
0000790c663d69d5  vmovaps xmm6, [rsp+0x60]
0000790c663d69db  vmovaps xmm8, [rsp+0x70]
0000790c663d69e1  vmovaps xmm9, [rsp+0x80]
0000790c663d69ea  vmovaps xmm10, [rsp+0x90]
0000790c663d69f3  vmovaps xmm11, [rsp+0xA0]
0000790c663d69fc  vmovaps xmm12, [rsp+0xB0]
0000790c663d6a05  vmovaps xmm13, [rsp+0xC0]
0000790c663d6a0e  vmovaps xmm14, [rsp+0xD0]
0000790c663d6a17  vmovaps xmm15, [rsp+0xE0]
0000790c663d6a20  add rsp, 0xF0
0000790c663d6a27  pop r11
0000790c663d6a29  pop r10
0000790c663d6a2b  pop r9
0000790c663d6a2d  pop r8
0000790c663d6a2f  pop rsi
0000790c663d6a30  pop rdi
0000790c663d6a31  pop rdx
0000790c663d6a32  pop rcx
0000790c663d6a33  pop rax
0000790c663d6a34  add rsp, 0x08
0000790c663d6a38  jmp 0x0000790C663D59C8
0000790c663d6a3d  sub rsp, 0x08
0000790c663d6a41  push rax
0000790c663d6a42  push rcx
0000790c663d6a43  push rdx
0000790c663d6a44  push rdi
0000790c663d6a45  push rsi
0000790c663d6a46  push r8
0000790c663d6a48  push r9
0000790c663d6a4a  push r10
0000790c663d6a4c  push r11
0000790c663d6a4e  sub rsp, 0xF0
0000790c663d6a55  vmovaps [rsp], xmm0
0000790c663d6a5a  vmovaps [rsp+0x10], xmm1
0000790c663d6a60  vmovaps [rsp+0x20], xmm2
0000790c663d6a66  vmovaps [rsp+0x30], xmm3
0000790c663d6a6c  vmovaps [rsp+0x40], xmm4
0000790c663d6a72  vmovaps [rsp+0x50], xmm5
0000790c663d6a78  vmovaps [rsp+0x60], xmm6
0000790c663d6a7e  vmovaps [rsp+0x70], xmm7
0000790c663d6a84  vmovaps [rsp+0x80], xmm8
0000790c663d6a8d  vmovaps [rsp+0x90], xmm10
0000790c663d6a96  vmovaps [rsp+0xA0], xmm11
0000790c663d6a9f  vmovaps [rsp+0xB0], xmm12
0000790c663d6aa8  vmovaps [rsp+0xC0], xmm13
0000790c663d6ab1  vmovaps [rsp+0xD0], xmm14
0000790c663d6aba  vmovaps [rsp+0xE0], xmm15
0000790c663d6ac3  sub rsp, 0x30
0000790c663d6ac7  movaps [rsp], xmm9
0000790c663d6acc  movaps [rsp+0x10], xmm12
0000790c663d6ad2  movaps [rsp+0x20], xmm10
0000790c663d6ad8  lea rdi, [rsp]
0000790c663d6adc  mov esi, 0x00
0000790c663d6ae1  mov rax, 0x631C1759F530
0000790c663d6aeb  call rax
0000790c663d6aed  movaps xmm9, [rsp]
0000790c663d6af2  add rsp, 0x30
0000790c663d6af6  vmovaps xmm0, [rsp]
0000790c663d6afb  vmovaps xmm1, [rsp+0x10]
0000790c663d6b01  vmovaps xmm2, [rsp+0x20]
0000790c663d6b07  vmovaps xmm3, [rsp+0x30]
0000790c663d6b0d  vmovaps xmm4, [rsp+0x40]
0000790c663d6b13  vmovaps xmm5, [rsp+0x50]
0000790c663d6b19  vmovaps xmm6, [rsp+0x60]
0000790c663d6b1f  vmovaps xmm7, [rsp+0x70]
0000790c663d6b25  vmovaps xmm8, [rsp+0x80]
0000790c663d6b2e  vmovaps xmm10, [rsp+0x90]
0000790c663d6b37  vmovaps xmm11, [rsp+0xA0]
0000790c663d6b40  vmovaps xmm12, [rsp+0xB0]
0000790c663d6b49  vmovaps xmm13, [rsp+0xC0]
0000790c663d6b52  vmovaps xmm14, [rsp+0xD0]
0000790c663d6b5b  vmovaps xmm15, [rsp+0xE0]
0000790c663d6b64  add rsp, 0xF0
0000790c663d6b6b  pop r11
0000790c663d6b6d  pop r10
0000790c663d6b6f  pop r9
0000790c663d6b71  pop r8
0000790c663d6b73  pop rsi
0000790c663d6b74  pop rdi
0000790c663d6b75  pop rdx
0000790c663d6b76  pop rcx
0000790c663d6b77  pop rax
0000790c663d6b78  add rsp, 0x08
0000790c663d6b7c  jmp 0x0000790C663D59EC
0000790c663d6b81  sub rsp, 0x08
0000790c663d6b85  push rax
0000790c663d6b86  push rcx
0000790c663d6b87  push rdx
0000790c663d6b88  push rdi
0000790c663d6b89  push rsi
0000790c663d6b8a  push r8
0000790c663d6b8c  push r9
0000790c663d6b8e  push r10
0000790c663d6b90  push r11
0000790c663d6b92  sub rsp, 0xF0
0000790c663d6b99  vmovaps [rsp], xmm0
0000790c663d6b9e  vmovaps [rsp+0x10], xmm1
0000790c663d6ba4  vmovaps [rsp+0x20], xmm2
0000790c663d6baa  vmovaps [rsp+0x30], xmm3
0000790c663d6bb0  vmovaps [rsp+0x40], xmm4
0000790c663d6bb6  vmovaps [rsp+0x50], xmm5
0000790c663d6bbc  vmovaps [rsp+0x60], xmm6
0000790c663d6bc2  vmovaps [rsp+0x70], xmm7
0000790c663d6bc8  vmovaps [rsp+0x80], xmm8
0000790c663d6bd1  vmovaps [rsp+0x90], xmm9
0000790c663d6bda  vmovaps [rsp+0xA0], xmm11
0000790c663d6be3  vmovaps [rsp+0xB0], xmm12
0000790c663d6bec  vmovaps [rsp+0xC0], xmm13
0000790c663d6bf5  vmovaps [rsp+0xD0], xmm14
0000790c663d6bfe  vmovaps [rsp+0xE0], xmm15
0000790c663d6c07  sub rsp, 0x30
0000790c663d6c0b  movaps [rsp], xmm10
0000790c663d6c10  movaps [rsp+0x10], xmm12
0000790c663d6c16  movaps [rsp+0x20], xmm11
0000790c663d6c1c  lea rdi, [rsp]
0000790c663d6c20  mov esi, 0x00
0000790c663d6c25  mov rax, 0x631C1759F530
0000790c663d6c2f  call rax
0000790c663d6c31  movaps xmm10, [rsp]
0000790c663d6c36  add rsp, 0x30
0000790c663d6c3a  vmovaps xmm0, [rsp]
0000790c663d6c3f  vmovaps xmm1, [rsp+0x10]
0000790c663d6c45  vmovaps xmm2, [rsp+0x20]
0000790c663d6c4b  vmovaps xmm3, [rsp+0x30]
0000790c663d6c51  vmovaps xmm4, [rsp+0x40]
0000790c663d6c57  vmovaps xmm5, [rsp+0x50]
0000790c663d6c5d  vmovaps xmm6, [rsp+0x60]
0000790c663d6c63  vmovaps xmm7, [rsp+0x70]
0000790c663d6c69  vmovaps xmm8, [rsp+0x80]
0000790c663d6c72  vmovaps xmm9, [rsp+0x90]
0000790c663d6c7b  vmovaps xmm11, [rsp+0xA0]
0000790c663d6c84  vmovaps xmm12, [rsp+0xB0]
0000790c663d6c8d  vmovaps xmm13, [rsp+0xC0]
0000790c663d6c96  vmovaps xmm14, [rsp+0xD0]
0000790c663d6c9f  vmovaps xmm15, [rsp+0xE0]
0000790c663d6ca8  add rsp, 0xF0
0000790c663d6caf  pop r11
0000790c663d6cb1  pop r10
0000790c663d6cb3  pop r9
0000790c663d6cb5  pop r8
0000790c663d6cb7  pop rsi
0000790c663d6cb8  pop rdi
0000790c663d6cb9  pop rdx
0000790c663d6cba  pop rcx
0000790c663d6cbb  pop rax
0000790c663d6cbc  add rsp, 0x08
0000790c663d6cc0  jmp 0x0000790C663D5A06
0000790c663d6cc5  sub rsp, 0x08
0000790c663d6cc9  push rax
0000790c663d6cca  push rcx
0000790c663d6ccb  push rdx
0000790c663d6ccc  push rdi
0000790c663d6ccd  push rsi
0000790c663d6cce  push r8
0000790c663d6cd0  push r9
0000790c663d6cd2  push r10
0000790c663d6cd4  push r11
0000790c663d6cd6  sub rsp, 0xF0
0000790c663d6cdd  vmovaps [rsp], xmm0
0000790c663d6ce2  vmovaps [rsp+0x10], xmm1
0000790c663d6ce8  vmovaps [rsp+0x20], xmm2
0000790c663d6cee  vmovaps [rsp+0x30], xmm3
0000790c663d6cf4  vmovaps [rsp+0x40], xmm4
0000790c663d6cfa  vmovaps [rsp+0x50], xmm5
0000790c663d6d00  vmovaps [rsp+0x60], xmm7
0000790c663d6d06  vmovaps [rsp+0x70], xmm8
0000790c663d6d0c  vmovaps [rsp+0x80], xmm9
0000790c663d6d15  vmovaps [rsp+0x90], xmm10
0000790c663d6d1e  vmovaps [rsp+0xA0], xmm11
0000790c663d6d27  vmovaps [rsp+0xB0], xmm12
0000790c663d6d30  vmovaps [rsp+0xC0], xmm13
0000790c663d6d39  vmovaps [rsp+0xD0], xmm14
0000790c663d6d42  vmovaps [rsp+0xE0], xmm15
0000790c663d6d4b  sub rsp, 0x30
0000790c663d6d4f  movaps [rsp], xmm6
0000790c663d6d53  movaps [rsp+0x10], xmm12
0000790c663d6d59  movaps [rsp+0x20], xmm11
0000790c663d6d5f  lea rdi, [rsp]
0000790c663d6d63  mov esi, 0x00
0000790c663d6d68  mov rax, 0x631C1759F530
0000790c663d6d72  call rax
0000790c663d6d74  movaps xmm6, [rsp]
0000790c663d6d78  add rsp, 0x30
0000790c663d6d7c  vmovaps xmm0, [rsp]
0000790c663d6d81  vmovaps xmm1, [rsp+0x10]
0000790c663d6d87  vmovaps xmm2, [rsp+0x20]
0000790c663d6d8d  vmovaps xmm3, [rsp+0x30]
0000790c663d6d93  vmovaps xmm4, [rsp+0x40]
0000790c663d6d99  vmovaps xmm5, [rsp+0x50]
0000790c663d6d9f  vmovaps xmm7, [rsp+0x60]
0000790c663d6da5  vmovaps xmm8, [rsp+0x70]
0000790c663d6dab  vmovaps xmm9, [rsp+0x80]
0000790c663d6db4  vmovaps xmm10, [rsp+0x90]
0000790c663d6dbd  vmovaps xmm11, [rsp+0xA0]
0000790c663d6dc6  vmovaps xmm12, [rsp+0xB0]
0000790c663d6dcf  vmovaps xmm13, [rsp+0xC0]
0000790c663d6dd8  vmovaps xmm14, [rsp+0xD0]
0000790c663d6de1  vmovaps xmm15, [rsp+0xE0]
0000790c663d6dea  add rsp, 0xF0
0000790c663d6df1  pop r11
0000790c663d6df3  pop r10
0000790c663d6df5  pop r9
0000790c663d6df7  pop r8
0000790c663d6df9  pop rsi
0000790c663d6dfa  pop rdi
0000790c663d6dfb  pop rdx
0000790c663d6dfc  pop rcx
0000790c663d6dfd  pop rax
0000790c663d6dfe  add rsp, 0x08
0000790c663d6e02  jmp 0x0000790C663D5A27
0000790c663d6e07  sub rsp, 0x08
0000790c663d6e0b  push rax
0000790c663d6e0c  push rcx
0000790c663d6e0d  push rdx
0000790c663d6e0e  push rdi
0000790c663d6e0f  push rsi
0000790c663d6e10  push r8
0000790c663d6e12  push r9
0000790c663d6e14  push r10
0000790c663d6e16  push r11
0000790c663d6e18  sub rsp, 0xF0
0000790c663d6e1f  vmovaps [rsp], xmm0
0000790c663d6e24  vmovaps [rsp+0x10], xmm1
0000790c663d6e2a  vmovaps [rsp+0x20], xmm2
0000790c663d6e30  vmovaps [rsp+0x30], xmm4
0000790c663d6e36  vmovaps [rsp+0x40], xmm5
0000790c663d6e3c  vmovaps [rsp+0x50], xmm6
0000790c663d6e42  vmovaps [rsp+0x60], xmm7
0000790c663d6e48  vmovaps [rsp+0x70], xmm8
0000790c663d6e4e  vmovaps [rsp+0x80], xmm9
0000790c663d6e57  vmovaps [rsp+0x90], xmm10
0000790c663d6e60  vmovaps [rsp+0xA0], xmm11
0000790c663d6e69  vmovaps [rsp+0xB0], xmm12
0000790c663d6e72  vmovaps [rsp+0xC0], xmm13
0000790c663d6e7b  vmovaps [rsp+0xD0], xmm14
0000790c663d6e84  vmovaps [rsp+0xE0], xmm15
0000790c663d6e8d  sub rsp, 0x30
0000790c663d6e91  movaps [rsp], xmm3
0000790c663d6e95  movaps [rsp+0x10], xmm5
0000790c663d6e9a  movaps [rsp+0x20], xmm4
0000790c663d6e9f  lea rdi, [rsp]
0000790c663d6ea3  mov esi, 0x00
0000790c663d6ea8  mov rax, 0x631C1759F530
0000790c663d6eb2  call rax
0000790c663d6eb4  movaps xmm3, [rsp]
0000790c663d6eb8  add rsp, 0x30
0000790c663d6ebc  vmovaps xmm0, [rsp]
0000790c663d6ec1  vmovaps xmm1, [rsp+0x10]
0000790c663d6ec7  vmovaps xmm2, [rsp+0x20]
0000790c663d6ecd  vmovaps xmm4, [rsp+0x30]
0000790c663d6ed3  vmovaps xmm5, [rsp+0x40]
0000790c663d6ed9  vmovaps xmm6, [rsp+0x50]
0000790c663d6edf  vmovaps xmm7, [rsp+0x60]
0000790c663d6ee5  vmovaps xmm8, [rsp+0x70]
0000790c663d6eeb  vmovaps xmm9, [rsp+0x80]
0000790c663d6ef4  vmovaps xmm10, [rsp+0x90]
0000790c663d6efd  vmovaps xmm11, [rsp+0xA0]
0000790c663d6f06  vmovaps xmm12, [rsp+0xB0]
0000790c663d6f0f  vmovaps xmm13, [rsp+0xC0]
0000790c663d6f18  vmovaps xmm14, [rsp+0xD0]
0000790c663d6f21  vmovaps xmm15, [rsp+0xE0]
0000790c663d6f2a  add rsp, 0xF0
0000790c663d6f31  pop r11
0000790c663d6f33  pop r10
0000790c663d6f35  pop r9
0000790c663d6f37  pop r8
0000790c663d6f39  pop rsi
0000790c663d6f3a  pop rdi
0000790c663d6f3b  pop rdx
0000790c663d6f3c  pop rcx
0000790c663d6f3d  pop rax
0000790c663d6f3e  add rsp, 0x08
0000790c663d6f42  jmp 0x0000790C663D5A88
0000790c663d6f47  sub rsp, 0x08
0000790c663d6f4b  push rax
0000790c663d6f4c  push rcx
0000790c663d6f4d  push rdx
0000790c663d6f4e  push rdi
0000790c663d6f4f  push rsi
0000790c663d6f50  push r8
0000790c663d6f52  push r9
0000790c663d6f54  push r10
0000790c663d6f56  push r11
0000790c663d6f58  sub rsp, 0xF0
0000790c663d6f5f  vmovaps [rsp], xmm0
0000790c663d6f64  vmovaps [rsp+0x10], xmm1
0000790c663d6f6a  vmovaps [rsp+0x20], xmm2
0000790c663d6f70  vmovaps [rsp+0x30], xmm3
0000790c663d6f76  vmovaps [rsp+0x40], xmm4
0000790c663d6f7c  vmovaps [rsp+0x50], xmm6
0000790c663d6f82  vmovaps [rsp+0x60], xmm7
0000790c663d6f88  vmovaps [rsp+0x70], xmm8
0000790c663d6f8e  vmovaps [rsp+0x80], xmm9
0000790c663d6f97  vmovaps [rsp+0x90], xmm10
0000790c663d6fa0  vmovaps [rsp+0xA0], xmm11
0000790c663d6fa9  vmovaps [rsp+0xB0], xmm12
0000790c663d6fb2  vmovaps [rsp+0xC0], xmm13
0000790c663d6fbb  vmovaps [rsp+0xD0], xmm14
0000790c663d6fc4  vmovaps [rsp+0xE0], xmm15
0000790c663d6fcd  sub rsp, 0x30
0000790c663d6fd1  movaps [rsp], xmm5
0000790c663d6fd5  movaps [rsp+0x10], xmm8
0000790c663d6fdb  movaps [rsp+0x20], xmm15
0000790c663d6fe1  lea rdi, [rsp]
0000790c663d6fe5  mov esi, 0x00
0000790c663d6fea  mov rax, 0x631C1759F530
0000790c663d6ff4  call rax
0000790c663d6ff6  movaps xmm5, [rsp]
0000790c663d6ffa  add rsp, 0x30
0000790c663d6ffe  vmovaps xmm0, [rsp]
0000790c663d7003  vmovaps xmm1, [rsp+0x10]
0000790c663d7009  vmovaps xmm2, [rsp+0x20]
0000790c663d700f  vmovaps xmm3, [rsp+0x30]
0000790c663d7015  vmovaps xmm4, [rsp+0x40]
0000790c663d701b  vmovaps xmm6, [rsp+0x50]
0000790c663d7021  vmovaps xmm7, [rsp+0x60]
0000790c663d7027  vmovaps xmm8, [rsp+0x70]
0000790c663d702d  vmovaps xmm9, [rsp+0x80]
0000790c663d7036  vmovaps xmm10, [rsp+0x90]
0000790c663d703f  vmovaps xmm11, [rsp+0xA0]
0000790c663d7048  vmovaps xmm12, [rsp+0xB0]
0000790c663d7051  vmovaps xmm13, [rsp+0xC0]
0000790c663d705a  vmovaps xmm14, [rsp+0xD0]
0000790c663d7063  vmovaps xmm15, [rsp+0xE0]
0000790c663d706c  add rsp, 0xF0
0000790c663d7073  pop r11
0000790c663d7075  pop r10
0000790c663d7077  pop r9
0000790c663d7079  pop r8
0000790c663d707b  pop rsi
0000790c663d707c  pop rdi
0000790c663d707d  pop rdx
0000790c663d707e  pop rcx
0000790c663d707f  pop rax
0000790c663d7080  add rsp, 0x08
0000790c663d7084  jmp 0x0000790C663D5AC0
0000790c663d7089  sub rsp, 0x08
0000790c663d708d  push rax
0000790c663d708e  push rcx
0000790c663d708f  push rdx
0000790c663d7090  push rdi
0000790c663d7091  push rsi
0000790c663d7092  push r8
0000790c663d7094  push r9
0000790c663d7096  push r10
0000790c663d7098  push r11
0000790c663d709a  sub rsp, 0xF0
0000790c663d70a1  vmovaps [rsp], xmm0
0000790c663d70a6  vmovaps [rsp+0x10], xmm1
0000790c663d70ac  vmovaps [rsp+0x20], xmm2
0000790c663d70b2  vmovaps [rsp+0x30], xmm3
0000790c663d70b8  vmovaps [rsp+0x40], xmm5
0000790c663d70be  vmovaps [rsp+0x50], xmm6
0000790c663d70c4  vmovaps [rsp+0x60], xmm7
0000790c663d70ca  vmovaps [rsp+0x70], xmm8
0000790c663d70d0  vmovaps [rsp+0x80], xmm9
0000790c663d70d9  vmovaps [rsp+0x90], xmm10
0000790c663d70e2  vmovaps [rsp+0xA0], xmm11
0000790c663d70eb  vmovaps [rsp+0xB0], xmm12
0000790c663d70f4  vmovaps [rsp+0xC0], xmm13
0000790c663d70fd  vmovaps [rsp+0xD0], xmm14
0000790c663d7106  vmovaps [rsp+0xE0], xmm15
0000790c663d710f  sub rsp, 0x30
0000790c663d7113  movaps [rsp], xmm4
0000790c663d7117  movaps [rsp+0x10], xmm9
0000790c663d711d  movaps [rsp+0x20], xmm8
0000790c663d7123  lea rdi, [rsp]
0000790c663d7127  mov esi, 0x00
0000790c663d712c  mov rax, 0x631C1759F530
0000790c663d7136  call rax
0000790c663d7138  movaps xmm4, [rsp]
0000790c663d713c  add rsp, 0x30
0000790c663d7140  vmovaps xmm0, [rsp]
0000790c663d7145  vmovaps xmm1, [rsp+0x10]
0000790c663d714b  vmovaps xmm2, [rsp+0x20]
0000790c663d7151  vmovaps xmm3, [rsp+0x30]
0000790c663d7157  vmovaps xmm5, [rsp+0x40]
0000790c663d715d  vmovaps xmm6, [rsp+0x50]
0000790c663d7163  vmovaps xmm7, [rsp+0x60]
0000790c663d7169  vmovaps xmm8, [rsp+0x70]
0000790c663d716f  vmovaps xmm9, [rsp+0x80]
0000790c663d7178  vmovaps xmm10, [rsp+0x90]
0000790c663d7181  vmovaps xmm11, [rsp+0xA0]
0000790c663d718a  vmovaps xmm12, [rsp+0xB0]
0000790c663d7193  vmovaps xmm13, [rsp+0xC0]
0000790c663d719c  vmovaps xmm14, [rsp+0xD0]
0000790c663d71a5  vmovaps xmm15, [rsp+0xE0]
0000790c663d71ae  add rsp, 0xF0
0000790c663d71b5  pop r11
0000790c663d71b7  pop r10
0000790c663d71b9  pop r9
0000790c663d71bb  pop r8
0000790c663d71bd  pop rsi
0000790c663d71be  pop rdi
0000790c663d71bf  pop rdx
0000790c663d71c0  pop rcx
0000790c663d71c1  pop rax
0000790c663d71c2  add rsp, 0x08
0000790c663d71c6  jmp 0x0000790C663D5AE1
0000790c663d71cb  sub rsp, 0x08
0000790c663d71cf  push rax
0000790c663d71d0  push rcx
0000790c663d71d1  push rdx
0000790c663d71d2  push rdi
0000790c663d71d3  push rsi
0000790c663d71d4  push r8
0000790c663d71d6  push r9
0000790c663d71d8  push r10
0000790c663d71da  push r11
0000790c663d71dc  sub rsp, 0xF0
0000790c663d71e3  vmovaps [rsp], xmm0
0000790c663d71e8  vmovaps [rsp+0x10], xmm1
0000790c663d71ee  vmovaps [rsp+0x20], xmm2
0000790c663d71f4  vmovaps [rsp+0x30], xmm3
0000790c663d71fa  vmovaps [rsp+0x40], xmm4
0000790c663d7200  vmovaps [rsp+0x50], xmm5
0000790c663d7206  vmovaps [rsp+0x60], xmm6
0000790c663d720c  vmovaps [rsp+0x70], xmm7
0000790c663d7212  vmovaps [rsp+0x80], xmm8
0000790c663d721b  vmovaps [rsp+0x90], xmm10
0000790c663d7224  vmovaps [rsp+0xA0], xmm11
0000790c663d722d  vmovaps [rsp+0xB0], xmm12
0000790c663d7236  vmovaps [rsp+0xC0], xmm13
0000790c663d723f  vmovaps [rsp+0xD0], xmm14
0000790c663d7248  vmovaps [rsp+0xE0], xmm15
0000790c663d7251  sub rsp, 0x30
0000790c663d7255  movaps [rsp], xmm9
0000790c663d725a  movaps [rsp+0x10], xmm10
0000790c663d7260  movaps [rsp+0x20], xmm8
0000790c663d7266  lea rdi, [rsp]
0000790c663d726a  mov esi, 0x00
0000790c663d726f  mov rax, 0x631C1759F530
0000790c663d7279  call rax
0000790c663d727b  movaps xmm9, [rsp]
0000790c663d7280  add rsp, 0x30
0000790c663d7284  vmovaps xmm0, [rsp]
0000790c663d7289  vmovaps xmm1, [rsp+0x10]
0000790c663d728f  vmovaps xmm2, [rsp+0x20]
0000790c663d7295  vmovaps xmm3, [rsp+0x30]
0000790c663d729b  vmovaps xmm4, [rsp+0x40]
0000790c663d72a1  vmovaps xmm5, [rsp+0x50]
0000790c663d72a7  vmovaps xmm6, [rsp+0x60]
0000790c663d72ad  vmovaps xmm7, [rsp+0x70]
0000790c663d72b3  vmovaps xmm8, [rsp+0x80]
0000790c663d72bc  vmovaps xmm10, [rsp+0x90]
0000790c663d72c5  vmovaps xmm11, [rsp+0xA0]
0000790c663d72ce  vmovaps xmm12, [rsp+0xB0]
0000790c663d72d7  vmovaps xmm13, [rsp+0xC0]
0000790c663d72e0  vmovaps xmm14, [rsp+0xD0]
0000790c663d72e9  vmovaps xmm15, [rsp+0xE0]
0000790c663d72f2  add rsp, 0xF0
0000790c663d72f9  pop r11
0000790c663d72fb  pop r10
0000790c663d72fd  pop r9
0000790c663d72ff  pop r8
0000790c663d7301  pop rsi
0000790c663d7302  pop rdi
0000790c663d7303  pop rdx
0000790c663d7304  pop rcx
0000790c663d7305  pop rax
0000790c663d7306  add rsp, 0x08
0000790c663d730a  jmp 0x0000790C663D5AFB
0000790c663d730f  call 0x0000790C662D64F0
0000790c663d7314  jmp 0x0000790C663D5C15
0000790c663d7319  call 0x0000790C662D64F0
0000790c663d731e  jmp 0x0000790C663D5C2B
0000790c663d7323  sub rsp, 0x08
0000790c663d7327  push rax
0000790c663d7328  push rcx
0000790c663d7329  push rdx
0000790c663d732a  push rdi
0000790c663d732b  push rsi
0000790c663d732c  push r8
0000790c663d732e  push r9
0000790c663d7330  push r10
0000790c663d7332  push r11
0000790c663d7334  sub rsp, 0xF0
0000790c663d733b  vmovaps [rsp], xmm0
0000790c663d7340  vmovaps [rsp+0x10], xmm2
0000790c663d7346  vmovaps [rsp+0x20], xmm3
0000790c663d734c  vmovaps [rsp+0x30], xmm4
0000790c663d7352  vmovaps [rsp+0x40], xmm5
0000790c663d7358  vmovaps [rsp+0x50], xmm6
0000790c663d735e  vmovaps [rsp+0x60], xmm7
0000790c663d7364  vmovaps [rsp+0x70], xmm8
0000790c663d736a  vmovaps [rsp+0x80], xmm9
0000790c663d7373  vmovaps [rsp+0x90], xmm10
0000790c663d737c  vmovaps [rsp+0xA0], xmm11
0000790c663d7385  vmovaps [rsp+0xB0], xmm12
0000790c663d738e  vmovaps [rsp+0xC0], xmm13
0000790c663d7397  vmovaps [rsp+0xD0], xmm14
0000790c663d73a0  vmovaps [rsp+0xE0], xmm15
0000790c663d73a9  sub rsp, 0x30
0000790c663d73ad  movaps [rsp], xmm1
0000790c663d73b1  movaps [rsp+0x10], xmm6
0000790c663d73b6  movaps [rsp+0x20], xmm15
0000790c663d73bc  lea rdi, [rsp]
0000790c663d73c0  mov esi, 0x00
0000790c663d73c5  mov rax, 0x631C1759F530
0000790c663d73cf  call rax
0000790c663d73d1  movaps xmm1, [rsp]
0000790c663d73d5  add rsp, 0x30
0000790c663d73d9  vmovaps xmm0, [rsp]
0000790c663d73de  vmovaps xmm2, [rsp+0x10]
0000790c663d73e4  vmovaps xmm3, [rsp+0x20]
0000790c663d73ea  vmovaps xmm4, [rsp+0x30]
0000790c663d73f0  vmovaps xmm5, [rsp+0x40]
0000790c663d73f6  vmovaps xmm6, [rsp+0x50]
0000790c663d73fc  vmovaps xmm7, [rsp+0x60]
0000790c663d7402  vmovaps xmm8, [rsp+0x70]
0000790c663d7408  vmovaps xmm9, [rsp+0x80]
0000790c663d7411  vmovaps xmm10, [rsp+0x90]
0000790c663d741a  vmovaps xmm11, [rsp+0xA0]
0000790c663d7423  vmovaps xmm12, [rsp+0xB0]
0000790c663d742c  vmovaps xmm13, [rsp+0xC0]
0000790c663d7435  vmovaps xmm14, [rsp+0xD0]
0000790c663d743e  vmovaps xmm15, [rsp+0xE0]
0000790c663d7447  add rsp, 0xF0
0000790c663d744e  pop r11
0000790c663d7450  pop r10
0000790c663d7452  pop r9
0000790c663d7454  pop r8
0000790c663d7456  pop rsi
0000790c663d7457  pop rdi
0000790c663d7458  pop rdx
0000790c663d7459  pop rcx
0000790c663d745a  pop rax
0000790c663d745b  add rsp, 0x08
0000790c663d745f  jmp 0x0000790C663D5C68
0000790c663d7464  call 0x0000790C662E5820
0000790c663d7469  jmp 0x0000790C663D5C75
0000790c663d746e  sub rsp, 0x08
0000790c663d7472  push rax
0000790c663d7473  push rcx
0000790c663d7474  push rdx
0000790c663d7475  push rdi
0000790c663d7476  push rsi
0000790c663d7477  push r8
0000790c663d7479  push r9
0000790c663d747b  push r10
0000790c663d747d  push r11
0000790c663d747f  sub rsp, 0xF0
0000790c663d7486  vmovaps [rsp], xmm0
0000790c663d748b  vmovaps [rsp+0x10], xmm1
0000790c663d7491  vmovaps [rsp+0x20], xmm2
0000790c663d7497  vmovaps [rsp+0x30], xmm3
0000790c663d749d  vmovaps [rsp+0x40], xmm4
0000790c663d74a3  vmovaps [rsp+0x50], xmm5
0000790c663d74a9  vmovaps [rsp+0x60], xmm6
0000790c663d74af  vmovaps [rsp+0x70], xmm7
0000790c663d74b5  vmovaps [rsp+0x80], xmm8
0000790c663d74be  vmovaps [rsp+0x90], xmm9
0000790c663d74c7  vmovaps [rsp+0xA0], xmm10
0000790c663d74d0  vmovaps [rsp+0xB0], xmm11
0000790c663d74d9  vmovaps [rsp+0xC0], xmm12
0000790c663d74e2  vmovaps [rsp+0xD0], xmm13
0000790c663d74eb  vmovaps [rsp+0xE0], xmm15
0000790c663d74f4  sub rsp, 0x30
0000790c663d74f8  movaps [rsp], xmm14
0000790c663d74fd  movaps [rsp+0x10], xmm4
0000790c663d7502  movaps [rsp+0x20], xmm3
0000790c663d7507  lea rdi, [rsp]
0000790c663d750b  mov esi, 0x00
0000790c663d7510  mov rax, 0x631C1759F530
0000790c663d751a  call rax
0000790c663d751c  movaps xmm14, [rsp]
0000790c663d7521  add rsp, 0x30
0000790c663d7525  vmovaps xmm0, [rsp]
0000790c663d752a  vmovaps xmm1, [rsp+0x10]
0000790c663d7530  vmovaps xmm2, [rsp+0x20]
0000790c663d7536  vmovaps xmm3, [rsp+0x30]
0000790c663d753c  vmovaps xmm4, [rsp+0x40]
0000790c663d7542  vmovaps xmm5, [rsp+0x50]
0000790c663d7548  vmovaps xmm6, [rsp+0x60]
0000790c663d754e  vmovaps xmm7, [rsp+0x70]
0000790c663d7554  vmovaps xmm8, [rsp+0x80]
0000790c663d755d  vmovaps xmm9, [rsp+0x90]
0000790c663d7566  vmovaps xmm10, [rsp+0xA0]
0000790c663d756f  vmovaps xmm11, [rsp+0xB0]
0000790c663d7578  vmovaps xmm12, [rsp+0xC0]
0000790c663d7581  vmovaps xmm13, [rsp+0xD0]
0000790c663d758a  vmovaps xmm15, [rsp+0xE0]
0000790c663d7593  add rsp, 0xF0
0000790c663d759a  pop r11
0000790c663d759c  pop r10
0000790c663d759e  pop r9
0000790c663d75a0  pop r8
0000790c663d75a2  pop rsi
0000790c663d75a3  pop rdi
0000790c663d75a4  pop rdx
0000790c663d75a5  pop rcx
0000790c663d75a6  pop rax
0000790c663d75a7  add rsp, 0x08
0000790c663d75ab  jmp 0x0000790C663D5C8F
0000790c663d75b0  sub rsp, 0x08
0000790c663d75b4  push rax
0000790c663d75b5  push rcx
0000790c663d75b6  push rdx
0000790c663d75b7  push rdi
0000790c663d75b8  push rsi
0000790c663d75b9  push r8
0000790c663d75bb  push r9
0000790c663d75bd  push r10
0000790c663d75bf  push r11
0000790c663d75c1  sub rsp, 0xF0
0000790c663d75c8  vmovaps [rsp], xmm0
0000790c663d75cd  vmovaps [rsp+0x10], xmm1
0000790c663d75d3  vmovaps [rsp+0x20], xmm2
0000790c663d75d9  vmovaps [rsp+0x30], xmm3
0000790c663d75df  vmovaps [rsp+0x40], xmm4
0000790c663d75e5  vmovaps [rsp+0x50], xmm5
0000790c663d75eb  vmovaps [rsp+0x60], xmm7
0000790c663d75f1  vmovaps [rsp+0x70], xmm8
0000790c663d75f7  vmovaps [rsp+0x80], xmm9
0000790c663d7600  vmovaps [rsp+0x90], xmm10
0000790c663d7609  vmovaps [rsp+0xA0], xmm11
0000790c663d7612  vmovaps [rsp+0xB0], xmm12
0000790c663d761b  vmovaps [rsp+0xC0], xmm13
0000790c663d7624  vmovaps [rsp+0xD0], xmm14
0000790c663d762d  vmovaps [rsp+0xE0], xmm15
0000790c663d7636  sub rsp, 0x30
0000790c663d763a  movaps [rsp], xmm6
0000790c663d763e  movaps [rsp+0x10], xmm9
0000790c663d7644  movaps [rsp+0x20], xmm7
0000790c663d7649  lea rdi, [rsp]
0000790c663d764d  mov esi, 0x00
0000790c663d7652  mov rax, 0x631C1759F530
0000790c663d765c  call rax
0000790c663d765e  movaps xmm6, [rsp]
0000790c663d7662  add rsp, 0x30
0000790c663d7666  vmovaps xmm0, [rsp]
0000790c663d766b  vmovaps xmm1, [rsp+0x10]
0000790c663d7671  vmovaps xmm2, [rsp+0x20]
0000790c663d7677  vmovaps xmm3, [rsp+0x30]
0000790c663d767d  vmovaps xmm4, [rsp+0x40]
0000790c663d7683  vmovaps xmm5, [rsp+0x50]
0000790c663d7689  vmovaps xmm7, [rsp+0x60]
0000790c663d768f  vmovaps xmm8, [rsp+0x70]
0000790c663d7695  vmovaps xmm9, [rsp+0x80]
0000790c663d769e  vmovaps xmm10, [rsp+0x90]
0000790c663d76a7  vmovaps xmm11, [rsp+0xA0]
0000790c663d76b0  vmovaps xmm12, [rsp+0xB0]
0000790c663d76b9  vmovaps xmm13, [rsp+0xC0]
0000790c663d76c2  vmovaps xmm14, [rsp+0xD0]
0000790c663d76cb  vmovaps xmm15, [rsp+0xE0]
0000790c663d76d4  add rsp, 0xF0
0000790c663d76db  pop r11
0000790c663d76dd  pop r10
0000790c663d76df  pop r9
0000790c663d76e1  pop r8
0000790c663d76e3  pop rsi
0000790c663d76e4  pop rdi
0000790c663d76e5  pop rdx
0000790c663d76e6  pop rcx
0000790c663d76e7  pop rax
0000790c663d76e8  add rsp, 0x08
0000790c663d76ec  jmp 0x0000790C663D5CA7
0000790c663d76f1  sub rsp, 0x08
0000790c663d76f5  push rax
0000790c663d76f6  push rcx
0000790c663d76f7  push rdx
0000790c663d76f8  push rdi
0000790c663d76f9  push rsi
0000790c663d76fa  push r8
0000790c663d76fc  push r9
0000790c663d76fe  push r10
0000790c663d7700  push r11
0000790c663d7702  sub rsp, 0xF0
0000790c663d7709  vmovaps [rsp], xmm0
0000790c663d770e  vmovaps [rsp+0x10], xmm1
0000790c663d7714  vmovaps [rsp+0x20], xmm2
0000790c663d771a  vmovaps [rsp+0x30], xmm3
0000790c663d7720  vmovaps [rsp+0x40], xmm4
0000790c663d7726  vmovaps [rsp+0x50], xmm5
0000790c663d772c  vmovaps [rsp+0x60], xmm6
0000790c663d7732  vmovaps [rsp+0x70], xmm8
0000790c663d7738  vmovaps [rsp+0x80], xmm9
0000790c663d7741  vmovaps [rsp+0x90], xmm10
0000790c663d774a  vmovaps [rsp+0xA0], xmm11
0000790c663d7753  vmovaps [rsp+0xB0], xmm12
0000790c663d775c  vmovaps [rsp+0xC0], xmm13
0000790c663d7765  vmovaps [rsp+0xD0], xmm14
0000790c663d776e  vmovaps [rsp+0xE0], xmm15
0000790c663d7777  sub rsp, 0x30
0000790c663d777b  movaps [rsp], xmm7
0000790c663d777f  movaps [rsp+0x10], xmm4
0000790c663d7784  movaps [rsp+0x20], xmm9
0000790c663d778a  lea rdi, [rsp]
0000790c663d778e  mov esi, 0x00
0000790c663d7793  mov rax, 0x631C1759F530
0000790c663d779d  call rax
0000790c663d779f  movaps xmm7, [rsp]
0000790c663d77a3  add rsp, 0x30
0000790c663d77a7  vmovaps xmm0, [rsp]
0000790c663d77ac  vmovaps xmm1, [rsp+0x10]
0000790c663d77b2  vmovaps xmm2, [rsp+0x20]
0000790c663d77b8  vmovaps xmm3, [rsp+0x30]
0000790c663d77be  vmovaps xmm4, [rsp+0x40]
0000790c663d77c4  vmovaps xmm5, [rsp+0x50]
0000790c663d77ca  vmovaps xmm6, [rsp+0x60]
0000790c663d77d0  vmovaps xmm8, [rsp+0x70]
0000790c663d77d6  vmovaps xmm9, [rsp+0x80]
0000790c663d77df  vmovaps xmm10, [rsp+0x90]
0000790c663d77e8  vmovaps xmm11, [rsp+0xA0]
0000790c663d77f1  vmovaps xmm12, [rsp+0xB0]
0000790c663d77fa  vmovaps xmm13, [rsp+0xC0]
0000790c663d7803  vmovaps xmm14, [rsp+0xD0]
0000790c663d780c  vmovaps xmm15, [rsp+0xE0]
0000790c663d7815  add rsp, 0xF0
0000790c663d781c  pop r11
0000790c663d781e  pop r10
0000790c663d7820  pop r9
0000790c663d7822  pop r8
0000790c663d7824  pop rsi
0000790c663d7825  pop rdi
0000790c663d7826  pop rdx
0000790c663d7827  pop rcx
0000790c663d7828  pop rax
0000790c663d7829  add rsp, 0x08
0000790c663d782d  jmp 0x0000790C663D5CD4
0000790c663d7832  sub rsp, 0x08
0000790c663d7836  push rax
0000790c663d7837  push rcx
0000790c663d7838  push rdx
0000790c663d7839  push rdi
0000790c663d783a  push rsi
0000790c663d783b  push r8
0000790c663d783d  push r9
0000790c663d783f  push r10
0000790c663d7841  push r11
0000790c663d7843  sub rsp, 0xF0
0000790c663d784a  vmovaps [rsp], xmm0
0000790c663d784f  vmovaps [rsp+0x10], xmm1
0000790c663d7855  vmovaps [rsp+0x20], xmm2
0000790c663d785b  vmovaps [rsp+0x30], xmm3
0000790c663d7861  vmovaps [rsp+0x40], xmm5
0000790c663d7867  vmovaps [rsp+0x50], xmm6
0000790c663d786d  vmovaps [rsp+0x60], xmm7
0000790c663d7873  vmovaps [rsp+0x70], xmm8
0000790c663d7879  vmovaps [rsp+0x80], xmm9
0000790c663d7882  vmovaps [rsp+0x90], xmm10
0000790c663d788b  vmovaps [rsp+0xA0], xmm11
0000790c663d7894  vmovaps [rsp+0xB0], xmm12
0000790c663d789d  vmovaps [rsp+0xC0], xmm13
0000790c663d78a6  vmovaps [rsp+0xD0], xmm14
0000790c663d78af  vmovaps [rsp+0xE0], xmm15
0000790c663d78b8  sub rsp, 0x30
0000790c663d78bc  movaps [rsp], xmm4
0000790c663d78c0  movaps [rsp+0x10], xmm15
0000790c663d78c6  movaps [rsp+0x20], xmm9
0000790c663d78cc  lea rdi, [rsp]
0000790c663d78d0  mov esi, 0x00
0000790c663d78d5  mov rax, 0x631C1759F530
0000790c663d78df  call rax
0000790c663d78e1  movaps xmm4, [rsp]
0000790c663d78e5  add rsp, 0x30
0000790c663d78e9  vmovaps xmm0, [rsp]
0000790c663d78ee  vmovaps xmm1, [rsp+0x10]
0000790c663d78f4  vmovaps xmm2, [rsp+0x20]
0000790c663d78fa  vmovaps xmm3, [rsp+0x30]
0000790c663d7900  vmovaps xmm5, [rsp+0x40]
0000790c663d7906  vmovaps xmm6, [rsp+0x50]
0000790c663d790c  vmovaps xmm7, [rsp+0x60]
0000790c663d7912  vmovaps xmm8, [rsp+0x70]
0000790c663d7918  vmovaps xmm9, [rsp+0x80]
0000790c663d7921  vmovaps xmm10, [rsp+0x90]
0000790c663d792a  vmovaps xmm11, [rsp+0xA0]
0000790c663d7933  vmovaps xmm12, [rsp+0xB0]
0000790c663d793c  vmovaps xmm13, [rsp+0xC0]
0000790c663d7945  vmovaps xmm14, [rsp+0xD0]
0000790c663d794e  vmovaps xmm15, [rsp+0xE0]
0000790c663d7957  add rsp, 0xF0
0000790c663d795e  pop r11
0000790c663d7960  pop r10
0000790c663d7962  pop r9
0000790c663d7964  pop r8
0000790c663d7966  pop rsi
0000790c663d7967  pop rdi
0000790c663d7968  pop rdx
0000790c663d7969  pop rcx
0000790c663d796a  pop rax
0000790c663d796b  add rsp, 0x08
0000790c663d796f  jmp 0x0000790C663D5CF9
0000790c663d7974  call 0x0000790C662E5820
0000790c663d7979  jmp 0x0000790C663D5D06
0000790c663d797e  sub rsp, 0x08
0000790c663d7982  push rax
0000790c663d7983  push rcx
0000790c663d7984  push rdx
0000790c663d7985  push rdi
0000790c663d7986  push rsi
0000790c663d7987  push r8
0000790c663d7989  push r9
0000790c663d798b  push r10
0000790c663d798d  push r11
0000790c663d798f  sub rsp, 0xF0
0000790c663d7996  vmovaps [rsp], xmm0
0000790c663d799b  vmovaps [rsp+0x10], xmm1
0000790c663d79a1  vmovaps [rsp+0x20], xmm2
0000790c663d79a7  vmovaps [rsp+0x30], xmm4
0000790c663d79ad  vmovaps [rsp+0x40], xmm5
0000790c663d79b3  vmovaps [rsp+0x50], xmm6
0000790c663d79b9  vmovaps [rsp+0x60], xmm7
0000790c663d79bf  vmovaps [rsp+0x70], xmm8
0000790c663d79c5  vmovaps [rsp+0x80], xmm9
0000790c663d79ce  vmovaps [rsp+0x90], xmm10
0000790c663d79d7  vmovaps [rsp+0xA0], xmm11
0000790c663d79e0  vmovaps [rsp+0xB0], xmm12
0000790c663d79e9  vmovaps [rsp+0xC0], xmm13
0000790c663d79f2  vmovaps [rsp+0xD0], xmm14
0000790c663d79fb  vmovaps [rsp+0xE0], xmm15
0000790c663d7a04  sub rsp, 0x30
0000790c663d7a08  movaps [rsp], xmm3
0000790c663d7a0c  movaps [rsp+0x10], xmm1
0000790c663d7a11  movaps [rsp+0x20], xmm9
0000790c663d7a17  lea rdi, [rsp]
0000790c663d7a1b  mov esi, 0x00
0000790c663d7a20  mov rax, 0x631C1759F530
0000790c663d7a2a  call rax
0000790c663d7a2c  movaps xmm3, [rsp]
0000790c663d7a30  add rsp, 0x30
0000790c663d7a34  vmovaps xmm0, [rsp]
0000790c663d7a39  vmovaps xmm1, [rsp+0x10]
0000790c663d7a3f  vmovaps xmm2, [rsp+0x20]
0000790c663d7a45  vmovaps xmm4, [rsp+0x30]
0000790c663d7a4b  vmovaps xmm5, [rsp+0x40]
0000790c663d7a51  vmovaps xmm6, [rsp+0x50]
0000790c663d7a57  vmovaps xmm7, [rsp+0x60]
0000790c663d7a5d  vmovaps xmm8, [rsp+0x70]
0000790c663d7a63  vmovaps xmm9, [rsp+0x80]
0000790c663d7a6c  vmovaps xmm10, [rsp+0x90]
0000790c663d7a75  vmovaps xmm11, [rsp+0xA0]
0000790c663d7a7e  vmovaps xmm12, [rsp+0xB0]
0000790c663d7a87  vmovaps xmm13, [rsp+0xC0]
0000790c663d7a90  vmovaps xmm14, [rsp+0xD0]
0000790c663d7a99  vmovaps xmm15, [rsp+0xE0]
0000790c663d7aa2  add rsp, 0xF0
0000790c663d7aa9  pop r11
0000790c663d7aab  pop r10
0000790c663d7aad  pop r9
0000790c663d7aaf  pop r8
0000790c663d7ab1  pop rsi
0000790c663d7ab2  pop rdi
0000790c663d7ab3  pop rdx
0000790c663d7ab4  pop rcx
0000790c663d7ab5  pop rax
0000790c663d7ab6  add rsp, 0x08
0000790c663d7aba  jmp 0x0000790C663D5D43
0000790c663d7abf  sub rsp, 0x08
0000790c663d7ac3  push rax
0000790c663d7ac4  push rcx
0000790c663d7ac5  push rdx
0000790c663d7ac6  push rdi
0000790c663d7ac7  push rsi
0000790c663d7ac8  push r8
0000790c663d7aca  push r9
0000790c663d7acc  push r10
0000790c663d7ace  push r11
0000790c663d7ad0  sub rsp, 0xF0
0000790c663d7ad7  vmovaps [rsp], xmm0
0000790c663d7adc  vmovaps [rsp+0x10], xmm2
0000790c663d7ae2  vmovaps [rsp+0x20], xmm3
0000790c663d7ae8  vmovaps [rsp+0x30], xmm4
0000790c663d7aee  vmovaps [rsp+0x40], xmm5
0000790c663d7af4  vmovaps [rsp+0x50], xmm6
0000790c663d7afa  vmovaps [rsp+0x60], xmm7
0000790c663d7b00  vmovaps [rsp+0x70], xmm8
0000790c663d7b06  vmovaps [rsp+0x80], xmm9
0000790c663d7b0f  vmovaps [rsp+0x90], xmm10
0000790c663d7b18  vmovaps [rsp+0xA0], xmm11
0000790c663d7b21  vmovaps [rsp+0xB0], xmm12
0000790c663d7b2a  vmovaps [rsp+0xC0], xmm13
0000790c663d7b33  vmovaps [rsp+0xD0], xmm14
0000790c663d7b3c  vmovaps [rsp+0xE0], xmm15
0000790c663d7b45  sub rsp, 0x30
0000790c663d7b49  movaps [rsp], xmm1
0000790c663d7b4d  movaps [rsp+0x10], xmm15
0000790c663d7b53  movaps [rsp+0x20], xmm9
0000790c663d7b59  lea rdi, [rsp]
0000790c663d7b5d  mov esi, 0x00
0000790c663d7b62  mov rax, 0x631C1759F530
0000790c663d7b6c  call rax
0000790c663d7b6e  movaps xmm1, [rsp]
0000790c663d7b72  add rsp, 0x30
0000790c663d7b76  vmovaps xmm0, [rsp]
0000790c663d7b7b  vmovaps xmm2, [rsp+0x10]
0000790c663d7b81  vmovaps xmm3, [rsp+0x20]
0000790c663d7b87  vmovaps xmm4, [rsp+0x30]
0000790c663d7b8d  vmovaps xmm5, [rsp+0x40]
0000790c663d7b93  vmovaps xmm6, [rsp+0x50]
0000790c663d7b99  vmovaps xmm7, [rsp+0x60]
0000790c663d7b9f  vmovaps xmm8, [rsp+0x70]
0000790c663d7ba5  vmovaps xmm9, [rsp+0x80]
0000790c663d7bae  vmovaps xmm10, [rsp+0x90]
0000790c663d7bb7  vmovaps xmm11, [rsp+0xA0]
0000790c663d7bc0  vmovaps xmm12, [rsp+0xB0]
0000790c663d7bc9  vmovaps xmm13, [rsp+0xC0]
0000790c663d7bd2  vmovaps xmm14, [rsp+0xD0]
0000790c663d7bdb  vmovaps xmm15, [rsp+0xE0]
0000790c663d7be4  add rsp, 0xF0
0000790c663d7beb  pop r11
0000790c663d7bed  pop r10
0000790c663d7bef  pop r9
0000790c663d7bf1  pop r8
0000790c663d7bf3  pop rsi
0000790c663d7bf4  pop rdi
0000790c663d7bf5  pop rdx
0000790c663d7bf6  pop rcx
0000790c663d7bf7  pop rax
0000790c663d7bf8  add rsp, 0x08
0000790c663d7bfc  jmp 0x0000790C663D5DCB
0000790c663d7c01  call 0x0000790C662E5820
0000790c663d7c06  jmp 0x0000790C663D5DD8
0000790c663d7c0b  sub rsp, 0x08
0000790c663d7c0f  push rax
0000790c663d7c10  push rcx
0000790c663d7c11  push rdx
0000790c663d7c12  push rdi
0000790c663d7c13  push rsi
0000790c663d7c14  push r8
0000790c663d7c16  push r9
0000790c663d7c18  push r10
0000790c663d7c1a  push r11
0000790c663d7c1c  sub rsp, 0xF0
0000790c663d7c23  vmovaps [rsp], xmm0
0000790c663d7c28  vmovaps [rsp+0x10], xmm2
0000790c663d7c2e  vmovaps [rsp+0x20], xmm3
0000790c663d7c34  vmovaps [rsp+0x30], xmm4
0000790c663d7c3a  vmovaps [rsp+0x40], xmm5
0000790c663d7c40  vmovaps [rsp+0x50], xmm6
0000790c663d7c46  vmovaps [rsp+0x60], xmm7
0000790c663d7c4c  vmovaps [rsp+0x70], xmm8
0000790c663d7c52  vmovaps [rsp+0x80], xmm9
0000790c663d7c5b  vmovaps [rsp+0x90], xmm10
0000790c663d7c64  vmovaps [rsp+0xA0], xmm11
0000790c663d7c6d  vmovaps [rsp+0xB0], xmm12
0000790c663d7c76  vmovaps [rsp+0xC0], xmm13
0000790c663d7c7f  vmovaps [rsp+0xD0], xmm14
0000790c663d7c88  vmovaps [rsp+0xE0], xmm15
0000790c663d7c91  sub rsp, 0x30
0000790c663d7c95  movaps [rsp], xmm1
0000790c663d7c99  movaps [rsp+0x10], xmm5
0000790c663d7c9e  movaps [rsp+0x20], xmm7
0000790c663d7ca3  lea rdi, [rsp]
0000790c663d7ca7  mov esi, 0x00
0000790c663d7cac  mov rax, 0x631C1759F530
0000790c663d7cb6  call rax
0000790c663d7cb8  movaps xmm1, [rsp]
0000790c663d7cbc  add rsp, 0x30
0000790c663d7cc0  vmovaps xmm0, [rsp]
0000790c663d7cc5  vmovaps xmm2, [rsp+0x10]
0000790c663d7ccb  vmovaps xmm3, [rsp+0x20]
0000790c663d7cd1  vmovaps xmm4, [rsp+0x30]
0000790c663d7cd7  vmovaps xmm5, [rsp+0x40]
0000790c663d7cdd  vmovaps xmm6, [rsp+0x50]
0000790c663d7ce3  vmovaps xmm7, [rsp+0x60]
0000790c663d7ce9  vmovaps xmm8, [rsp+0x70]
0000790c663d7cef  vmovaps xmm9, [rsp+0x80]
0000790c663d7cf8  vmovaps xmm10, [rsp+0x90]
0000790c663d7d01  vmovaps xmm11, [rsp+0xA0]
0000790c663d7d0a  vmovaps xmm12, [rsp+0xB0]
0000790c663d7d13  vmovaps xmm13, [rsp+0xC0]
0000790c663d7d1c  vmovaps xmm14, [rsp+0xD0]
0000790c663d7d25  vmovaps xmm15, [rsp+0xE0]
0000790c663d7d2e  add rsp, 0xF0
0000790c663d7d35  pop r11
0000790c663d7d37  pop r10
0000790c663d7d39  pop r9
0000790c663d7d3b  pop r8
0000790c663d7d3d  pop rsi
0000790c663d7d3e  pop rdi
0000790c663d7d3f  pop rdx
0000790c663d7d40  pop rcx
0000790c663d7d41  pop rax
0000790c663d7d42  add rsp, 0x08
0000790c663d7d46  jmp 0x0000790C663D5E7D
0000790c663d7d4b  sub rsp, 0x08
0000790c663d7d4f  push rax
0000790c663d7d50  push rcx
0000790c663d7d51  push rdx
0000790c663d7d52  push rdi
0000790c663d7d53  push rsi
0000790c663d7d54  push r8
0000790c663d7d56  push r9
0000790c663d7d58  push r10
0000790c663d7d5a  push r11
0000790c663d7d5c  sub rsp, 0xF0
0000790c663d7d63  vmovaps [rsp], xmm0
0000790c663d7d68  vmovaps [rsp+0x10], xmm1
0000790c663d7d6e  vmovaps [rsp+0x20], xmm2
0000790c663d7d74  vmovaps [rsp+0x30], xmm3
0000790c663d7d7a  vmovaps [rsp+0x40], xmm4
0000790c663d7d80  vmovaps [rsp+0x50], xmm5
0000790c663d7d86  vmovaps [rsp+0x60], xmm6
0000790c663d7d8c  vmovaps [rsp+0x70], xmm8
0000790c663d7d92  vmovaps [rsp+0x80], xmm9
0000790c663d7d9b  vmovaps [rsp+0x90], xmm10
0000790c663d7da4  vmovaps [rsp+0xA0], xmm11
0000790c663d7dad  vmovaps [rsp+0xB0], xmm12
0000790c663d7db6  vmovaps [rsp+0xC0], xmm13
0000790c663d7dbf  vmovaps [rsp+0xD0], xmm14
0000790c663d7dc8  vmovaps [rsp+0xE0], xmm15
0000790c663d7dd1  sub rsp, 0x30
0000790c663d7dd5  movaps [rsp], xmm7
0000790c663d7dd9  movaps [rsp+0x10], xmm5
0000790c663d7dde  movaps [rsp+0x20], xmm15
0000790c663d7de4  lea rdi, [rsp]
0000790c663d7de8  mov esi, 0x00
0000790c663d7ded  mov rax, 0x631C1759F530
0000790c663d7df7  call rax
0000790c663d7df9  movaps xmm7, [rsp]
0000790c663d7dfd  add rsp, 0x30
0000790c663d7e01  vmovaps xmm0, [rsp]
0000790c663d7e06  vmovaps xmm1, [rsp+0x10]
0000790c663d7e0c  vmovaps xmm2, [rsp+0x20]
0000790c663d7e12  vmovaps xmm3, [rsp+0x30]
0000790c663d7e18  vmovaps xmm4, [rsp+0x40]
0000790c663d7e1e  vmovaps xmm5, [rsp+0x50]
0000790c663d7e24  vmovaps xmm6, [rsp+0x60]
0000790c663d7e2a  vmovaps xmm8, [rsp+0x70]
0000790c663d7e30  vmovaps xmm9, [rsp+0x80]
0000790c663d7e39  vmovaps xmm10, [rsp+0x90]
0000790c663d7e42  vmovaps xmm11, [rsp+0xA0]
0000790c663d7e4b  vmovaps xmm12, [rsp+0xB0]
0000790c663d7e54  vmovaps xmm13, [rsp+0xC0]
0000790c663d7e5d  vmovaps xmm14, [rsp+0xD0]
0000790c663d7e66  vmovaps xmm15, [rsp+0xE0]
0000790c663d7e6f  add rsp, 0xF0
0000790c663d7e76  pop r11
0000790c663d7e78  pop r10
0000790c663d7e7a  pop r9
0000790c663d7e7c  pop r8
0000790c663d7e7e  pop rsi
0000790c663d7e7f  pop rdi
0000790c663d7e80  pop rdx
0000790c663d7e81  pop rcx
0000790c663d7e82  pop rax
0000790c663d7e83  add rsp, 0x08
0000790c663d7e87  jmp 0x0000790C663D5EB3
0000790c663d7e8c  call 0x0000790C662D64F0
0000790c663d7e91  jmp 0x0000790C663D5EC0
0000790c663d7e96  sub rsp, 0x08
0000790c663d7e9a  push rax
0000790c663d7e9b  push rcx
0000790c663d7e9c  push rdx
0000790c663d7e9d  push rdi
0000790c663d7e9e  push rsi
0000790c663d7e9f  push r8
0000790c663d7ea1  push r9
0000790c663d7ea3  push r10
0000790c663d7ea5  push r11
0000790c663d7ea7  sub rsp, 0xF0
0000790c663d7eae  vmovaps [rsp], xmm0
0000790c663d7eb3  vmovaps [rsp+0x10], xmm1
0000790c663d7eb9  vmovaps [rsp+0x20], xmm2
0000790c663d7ebf  vmovaps [rsp+0x30], xmm3
0000790c663d7ec5  vmovaps [rsp+0x40], xmm4
0000790c663d7ecb  vmovaps [rsp+0x50], xmm5
0000790c663d7ed1  vmovaps [rsp+0x60], xmm6
0000790c663d7ed7  vmovaps [rsp+0x70], xmm7
0000790c663d7edd  vmovaps [rsp+0x80], xmm8
0000790c663d7ee6  vmovaps [rsp+0x90], xmm9
0000790c663d7eef  vmovaps [rsp+0xA0], xmm10
0000790c663d7ef8  vmovaps [rsp+0xB0], xmm11
0000790c663d7f01  vmovaps [rsp+0xC0], xmm12
0000790c663d7f0a  vmovaps [rsp+0xD0], xmm13
0000790c663d7f13  vmovaps [rsp+0xE0], xmm14
0000790c663d7f1c  sub rsp, 0x30
0000790c663d7f20  movaps [rsp], xmm15
0000790c663d7f25  movaps [rsp+0x10], xmm5
0000790c663d7f2a  movaps [rsp+0x20], xmm3
0000790c663d7f2f  lea rdi, [rsp]
0000790c663d7f33  mov esi, 0x00
0000790c663d7f38  mov rax, 0x631C1759F530
0000790c663d7f42  call rax
0000790c663d7f44  movaps xmm15, [rsp]
0000790c663d7f49  add rsp, 0x30
0000790c663d7f4d  vmovaps xmm0, [rsp]
0000790c663d7f52  vmovaps xmm1, [rsp+0x10]
0000790c663d7f58  vmovaps xmm2, [rsp+0x20]
0000790c663d7f5e  vmovaps xmm3, [rsp+0x30]
0000790c663d7f64  vmovaps xmm4, [rsp+0x40]
0000790c663d7f6a  vmovaps xmm5, [rsp+0x50]
0000790c663d7f70  vmovaps xmm6, [rsp+0x60]
0000790c663d7f76  vmovaps xmm7, [rsp+0x70]
0000790c663d7f7c  vmovaps xmm8, [rsp+0x80]
0000790c663d7f85  vmovaps xmm9, [rsp+0x90]
0000790c663d7f8e  vmovaps xmm10, [rsp+0xA0]
0000790c663d7f97  vmovaps xmm11, [rsp+0xB0]
0000790c663d7fa0  vmovaps xmm12, [rsp+0xC0]
0000790c663d7fa9  vmovaps xmm13, [rsp+0xD0]
0000790c663d7fb2  vmovaps xmm14, [rsp+0xE0]
0000790c663d7fbb  add rsp, 0xF0
0000790c663d7fc2  pop r11
0000790c663d7fc4  pop r10
0000790c663d7fc6  pop r9
0000790c663d7fc8  pop r8
0000790c663d7fca  pop rsi
0000790c663d7fcb  pop rdi
0000790c663d7fcc  pop rdx
0000790c663d7fcd  pop rcx
0000790c663d7fce  pop rax
0000790c663d7fcf  add rsp, 0x08
0000790c663d7fd3  jmp 0x0000790C663D5EE6
0000790c663d7fd8  sub rsp, 0x08
0000790c663d7fdc  push rax
0000790c663d7fdd  push rcx
0000790c663d7fde  push rdx
0000790c663d7fdf  push rdi
0000790c663d7fe0  push rsi
0000790c663d7fe1  push r8
0000790c663d7fe3  push r9
0000790c663d7fe5  push r10
0000790c663d7fe7  push r11
0000790c663d7fe9  sub rsp, 0xF0
0000790c663d7ff0  vmovaps [rsp], xmm0
0000790c663d7ff5  vmovaps [rsp+0x10], xmm2
0000790c663d7ffb  vmovaps [rsp+0x20], xmm3
0000790c663d8001  vmovaps [rsp+0x30], xmm4
0000790c663d8007  vmovaps [rsp+0x40], xmm5
0000790c663d800d  vmovaps [rsp+0x50], xmm6
0000790c663d8013  vmovaps [rsp+0x60], xmm7
0000790c663d8019  vmovaps [rsp+0x70], xmm8
0000790c663d801f  vmovaps [rsp+0x80], xmm9
0000790c663d8028  vmovaps [rsp+0x90], xmm10
0000790c663d8031  vmovaps [rsp+0xA0], xmm11
0000790c663d803a  vmovaps [rsp+0xB0], xmm12
0000790c663d8043  vmovaps [rsp+0xC0], xmm13
0000790c663d804c  vmovaps [rsp+0xD0], xmm14
0000790c663d8055  vmovaps [rsp+0xE0], xmm15
0000790c663d805e  sub rsp, 0x30
0000790c663d8062  movaps [rsp], xmm1
0000790c663d8066  movaps [rsp+0x10], xmm5
0000790c663d806b  movaps [rsp+0x20], xmm4
0000790c663d8070  lea rdi, [rsp]
0000790c663d8074  mov esi, 0x00
0000790c663d8079  mov rax, 0x631C1759F530
0000790c663d8083  call rax
0000790c663d8085  movaps xmm1, [rsp]
0000790c663d8089  add rsp, 0x30
0000790c663d808d  vmovaps xmm0, [rsp]
0000790c663d8092  vmovaps xmm2, [rsp+0x10]
0000790c663d8098  vmovaps xmm3, [rsp+0x20]
0000790c663d809e  vmovaps xmm4, [rsp+0x30]
0000790c663d80a4  vmovaps xmm5, [rsp+0x40]
0000790c663d80aa  vmovaps xmm6, [rsp+0x50]
0000790c663d80b0  vmovaps xmm7, [rsp+0x60]
0000790c663d80b6  vmovaps xmm8, [rsp+0x70]
0000790c663d80bc  vmovaps xmm9, [rsp+0x80]
0000790c663d80c5  vmovaps xmm10, [rsp+0x90]
0000790c663d80ce  vmovaps xmm11, [rsp+0xA0]
0000790c663d80d7  vmovaps xmm12, [rsp+0xB0]
0000790c663d80e0  vmovaps xmm13, [rsp+0xC0]
0000790c663d80e9  vmovaps xmm14, [rsp+0xD0]
0000790c663d80f2  vmovaps xmm15, [rsp+0xE0]
0000790c663d80fb  add rsp, 0xF0
0000790c663d8102  pop r11
0000790c663d8104  pop r10
0000790c663d8106  pop r9
0000790c663d8108  pop r8
0000790c663d810a  pop rsi
0000790c663d810b  pop rdi
0000790c663d810c  pop rdx
0000790c663d810d  pop rcx
0000790c663d810e  pop rax
0000790c663d810f  add rsp, 0x08
0000790c663d8113  jmp 0x0000790C663D5F06
0000790c663d8118  sub rsp, 0x08
0000790c663d811c  push rax
0000790c663d811d  push rcx
0000790c663d811e  push rdx
0000790c663d811f  push rdi
0000790c663d8120  push rsi
0000790c663d8121  push r8
0000790c663d8123  push r9
0000790c663d8125  push r10
0000790c663d8127  push r11
0000790c663d8129  sub rsp, 0xF0
0000790c663d8130  vmovaps [rsp], xmm0
0000790c663d8135  vmovaps [rsp+0x10], xmm1
0000790c663d813b  vmovaps [rsp+0x20], xmm2
0000790c663d8141  vmovaps [rsp+0x30], xmm3
0000790c663d8147  vmovaps [rsp+0x40], xmm5
0000790c663d814d  vmovaps [rsp+0x50], xmm6
0000790c663d8153  vmovaps [rsp+0x60], xmm7
0000790c663d8159  vmovaps [rsp+0x70], xmm8
0000790c663d815f  vmovaps [rsp+0x80], xmm9
0000790c663d8168  vmovaps [rsp+0x90], xmm10
0000790c663d8171  vmovaps [rsp+0xA0], xmm11
0000790c663d817a  vmovaps [rsp+0xB0], xmm12
0000790c663d8183  vmovaps [rsp+0xC0], xmm13
0000790c663d818c  vmovaps [rsp+0xD0], xmm14
0000790c663d8195  vmovaps [rsp+0xE0], xmm15
0000790c663d819e  sub rsp, 0x30
0000790c663d81a2  movaps [rsp], xmm4
0000790c663d81a6  movaps [rsp+0x10], xmm3
0000790c663d81ab  movaps [rsp+0x20], xmm5
0000790c663d81b0  lea rdi, [rsp]
0000790c663d81b4  mov esi, 0x00
0000790c663d81b9  mov rax, 0x631C1759F530
0000790c663d81c3  call rax
0000790c663d81c5  movaps xmm4, [rsp]
0000790c663d81c9  add rsp, 0x30
0000790c663d81cd  vmovaps xmm0, [rsp]
0000790c663d81d2  vmovaps xmm1, [rsp+0x10]
0000790c663d81d8  vmovaps xmm2, [rsp+0x20]
0000790c663d81de  vmovaps xmm3, [rsp+0x30]
0000790c663d81e4  vmovaps xmm5, [rsp+0x40]
0000790c663d81ea  vmovaps xmm6, [rsp+0x50]
0000790c663d81f0  vmovaps xmm7, [rsp+0x60]
0000790c663d81f6  vmovaps xmm8, [rsp+0x70]
0000790c663d81fc  vmovaps xmm9, [rsp+0x80]
0000790c663d8205  vmovaps xmm10, [rsp+0x90]
0000790c663d820e  vmovaps xmm11, [rsp+0xA0]
0000790c663d8217  vmovaps xmm12, [rsp+0xB0]
0000790c663d8220  vmovaps xmm13, [rsp+0xC0]
0000790c663d8229  vmovaps xmm14, [rsp+0xD0]
0000790c663d8232  vmovaps xmm15, [rsp+0xE0]
0000790c663d823b  add rsp, 0xF0
0000790c663d8242  pop r11
0000790c663d8244  pop r10
0000790c663d8246  pop r9
0000790c663d8248  pop r8
0000790c663d824a  pop rsi
0000790c663d824b  pop rdi
0000790c663d824c  pop rdx
0000790c663d824d  pop rcx
0000790c663d824e  pop rax
0000790c663d824f  add rsp, 0x08
0000790c663d8253  jmp 0x0000790C663D5F54
0000790c663d8258  call 0x0000790C662D64F0
0000790c663d825d  jmp 0x0000790C663D5F61
0000790c663d8262  sub rsp, 0x08
0000790c663d8266  push rax
0000790c663d8267  push rcx
0000790c663d8268  push rdx
0000790c663d8269  push rdi
0000790c663d826a  push rsi
0000790c663d826b  push r8
0000790c663d826d  push r9
0000790c663d826f  push r10
0000790c663d8271  push r11
0000790c663d8273  sub rsp, 0xF0
0000790c663d827a  vmovaps [rsp], xmm0
0000790c663d827f  vmovaps [rsp+0x10], xmm1
0000790c663d8285  vmovaps [rsp+0x20], xmm2
0000790c663d828b  vmovaps [rsp+0x30], xmm3
0000790c663d8291  vmovaps [rsp+0x40], xmm4
0000790c663d8297  vmovaps [rsp+0x50], xmm6
0000790c663d829d  vmovaps [rsp+0x60], xmm7
0000790c663d82a3  vmovaps [rsp+0x70], xmm8
0000790c663d82a9  vmovaps [rsp+0x80], xmm9
0000790c663d82b2  vmovaps [rsp+0x90], xmm10
0000790c663d82bb  vmovaps [rsp+0xA0], xmm11
0000790c663d82c4  vmovaps [rsp+0xB0], xmm12
0000790c663d82cd  vmovaps [rsp+0xC0], xmm13
0000790c663d82d6  vmovaps [rsp+0xD0], xmm14
0000790c663d82df  vmovaps [rsp+0xE0], xmm15
0000790c663d82e8  sub rsp, 0x30
0000790c663d82ec  movaps [rsp], xmm5
0000790c663d82f0  movaps [rsp+0x10], xmm6
0000790c663d82f5  movaps [rsp+0x20], xmm3
0000790c663d82fa  lea rdi, [rsp]
0000790c663d82fe  mov esi, 0x00
0000790c663d8303  mov rax, 0x631C1759F530
0000790c663d830d  call rax
0000790c663d830f  movaps xmm5, [rsp]
0000790c663d8313  add rsp, 0x30
0000790c663d8317  vmovaps xmm0, [rsp]
0000790c663d831c  vmovaps xmm1, [rsp+0x10]
0000790c663d8322  vmovaps xmm2, [rsp+0x20]
0000790c663d8328  vmovaps xmm3, [rsp+0x30]
0000790c663d832e  vmovaps xmm4, [rsp+0x40]
0000790c663d8334  vmovaps xmm6, [rsp+0x50]
0000790c663d833a  vmovaps xmm7, [rsp+0x60]
0000790c663d8340  vmovaps xmm8, [rsp+0x70]
0000790c663d8346  vmovaps xmm9, [rsp+0x80]
0000790c663d834f  vmovaps xmm10, [rsp+0x90]
0000790c663d8358  vmovaps xmm11, [rsp+0xA0]
0000790c663d8361  vmovaps xmm12, [rsp+0xB0]
0000790c663d836a  vmovaps xmm13, [rsp+0xC0]
0000790c663d8373  vmovaps xmm14, [rsp+0xD0]
0000790c663d837c  vmovaps xmm15, [rsp+0xE0]
0000790c663d8385  add rsp, 0xF0
0000790c663d838c  pop r11
0000790c663d838e  pop r10
0000790c663d8390  pop r9
0000790c663d8392  pop r8
0000790c663d8394  pop rsi
0000790c663d8395  pop rdi
0000790c663d8396  pop rdx
0000790c663d8397  pop rcx
0000790c663d8398  pop rax
0000790c663d8399  add rsp, 0x08
0000790c663d839d  jmp 0x0000790C663D5F87
0000790c663d83a2  sub rsp, 0x08
0000790c663d83a6  push rax
0000790c663d83a7  push rcx
0000790c663d83a8  push rdx
0000790c663d83a9  push rdi
0000790c663d83aa  push rsi
0000790c663d83ab  push r8
0000790c663d83ad  push r9
0000790c663d83af  push r10
0000790c663d83b1  push r11
0000790c663d83b3  sub rsp, 0xF0
0000790c663d83ba  vmovaps [rsp], xmm0
0000790c663d83bf  vmovaps [rsp+0x10], xmm1
0000790c663d83c5  vmovaps [rsp+0x20], xmm2
0000790c663d83cb  vmovaps [rsp+0x30], xmm3
0000790c663d83d1  vmovaps [rsp+0x40], xmm4
0000790c663d83d7  vmovaps [rsp+0x50], xmm5
0000790c663d83dd  vmovaps [rsp+0x60], xmm7
0000790c663d83e3  vmovaps [rsp+0x70], xmm8
0000790c663d83e9  vmovaps [rsp+0x80], xmm9
0000790c663d83f2  vmovaps [rsp+0x90], xmm10
0000790c663d83fb  vmovaps [rsp+0xA0], xmm11
0000790c663d8404  vmovaps [rsp+0xB0], xmm12
0000790c663d840d  vmovaps [rsp+0xC0], xmm13
0000790c663d8416  vmovaps [rsp+0xD0], xmm14
0000790c663d841f  vmovaps [rsp+0xE0], xmm15
0000790c663d8428  sub rsp, 0x30
0000790c663d842c  movaps [rsp], xmm6
0000790c663d8430  movaps [rsp+0x10], xmm9
0000790c663d8436  movaps [rsp+0x20], xmm1
0000790c663d843b  lea rdi, [rsp]
0000790c663d843f  mov esi, 0x00
0000790c663d8444  mov rax, 0x631C1759F530
0000790c663d844e  call rax
0000790c663d8450  movaps xmm6, [rsp]
0000790c663d8454  add rsp, 0x30
0000790c663d8458  vmovaps xmm0, [rsp]
0000790c663d845d  vmovaps xmm1, [rsp+0x10]
0000790c663d8463  vmovaps xmm2, [rsp+0x20]
0000790c663d8469  vmovaps xmm3, [rsp+0x30]
0000790c663d846f  vmovaps xmm4, [rsp+0x40]
0000790c663d8475  vmovaps xmm5, [rsp+0x50]
0000790c663d847b  vmovaps xmm7, [rsp+0x60]
0000790c663d8481  vmovaps xmm8, [rsp+0x70]
0000790c663d8487  vmovaps xmm9, [rsp+0x80]
0000790c663d8490  vmovaps xmm10, [rsp+0x90]
0000790c663d8499  vmovaps xmm11, [rsp+0xA0]
0000790c663d84a2  vmovaps xmm12, [rsp+0xB0]
0000790c663d84ab  vmovaps xmm13, [rsp+0xC0]
0000790c663d84b4  vmovaps xmm14, [rsp+0xD0]
0000790c663d84bd  vmovaps xmm15, [rsp+0xE0]
0000790c663d84c6  add rsp, 0xF0
0000790c663d84cd  pop r11
0000790c663d84cf  pop r10
0000790c663d84d1  pop r9
0000790c663d84d3  pop r8
0000790c663d84d5  pop rsi
0000790c663d84d6  pop rdi
0000790c663d84d7  pop rdx
0000790c663d84d8  pop rcx
0000790c663d84d9  pop rax
0000790c663d84da  add rsp, 0x08
0000790c663d84de  jmp 0x0000790C663D5FAB
0000790c663d84e3  sub rsp, 0x08
0000790c663d84e7  push rax
0000790c663d84e8  push rcx
0000790c663d84e9  push rdx
0000790c663d84ea  push rdi
0000790c663d84eb  push rsi
0000790c663d84ec  push r8
0000790c663d84ee  push r9
0000790c663d84f0  push r10
0000790c663d84f2  push r11
0000790c663d84f4  sub rsp, 0xF0
0000790c663d84fb  vmovaps [rsp], xmm0
0000790c663d8500  vmovaps [rsp+0x10], xmm1
0000790c663d8506  vmovaps [rsp+0x20], xmm2
0000790c663d850c  vmovaps [rsp+0x30], xmm3
0000790c663d8512  vmovaps [rsp+0x40], xmm4
0000790c663d8518  vmovaps [rsp+0x50], xmm5
0000790c663d851e  vmovaps [rsp+0x60], xmm6
0000790c663d8524  vmovaps [rsp+0x70], xmm7
0000790c663d852a  vmovaps [rsp+0x80], xmm8
0000790c663d8533  vmovaps [rsp+0x90], xmm10
0000790c663d853c  vmovaps [rsp+0xA0], xmm11
0000790c663d8545  vmovaps [rsp+0xB0], xmm12
0000790c663d854e  vmovaps [rsp+0xC0], xmm13
0000790c663d8557  vmovaps [rsp+0xD0], xmm14
0000790c663d8560  vmovaps [rsp+0xE0], xmm15
0000790c663d8569  sub rsp, 0x30
0000790c663d856d  movaps [rsp], xmm9
0000790c663d8572  movaps [rsp+0x10], xmm3
0000790c663d8577  movaps [rsp+0x20], xmm1
0000790c663d857c  lea rdi, [rsp]
0000790c663d8580  mov esi, 0x00
0000790c663d8585  mov rax, 0x631C1759F530
0000790c663d858f  call rax
0000790c663d8591  movaps xmm9, [rsp]
0000790c663d8596  add rsp, 0x30
0000790c663d859a  vmovaps xmm0, [rsp]
0000790c663d859f  vmovaps xmm1, [rsp+0x10]
0000790c663d85a5  vmovaps xmm2, [rsp+0x20]
0000790c663d85ab  vmovaps xmm3, [rsp+0x30]
0000790c663d85b1  vmovaps xmm4, [rsp+0x40]
0000790c663d85b7  vmovaps xmm5, [rsp+0x50]
0000790c663d85bd  vmovaps xmm6, [rsp+0x60]
0000790c663d85c3  vmovaps xmm7, [rsp+0x70]
0000790c663d85c9  vmovaps xmm8, [rsp+0x80]
0000790c663d85d2  vmovaps xmm10, [rsp+0x90]
0000790c663d85db  vmovaps xmm11, [rsp+0xA0]
0000790c663d85e4  vmovaps xmm12, [rsp+0xB0]
0000790c663d85ed  vmovaps xmm13, [rsp+0xC0]
0000790c663d85f6  vmovaps xmm14, [rsp+0xD0]
0000790c663d85ff  vmovaps xmm15, [rsp+0xE0]
0000790c663d8608  add rsp, 0xF0
0000790c663d860f  pop r11
0000790c663d8611  pop r10
0000790c663d8613  pop r9
0000790c663d8615  pop r8
0000790c663d8617  pop rsi
0000790c663d8618  pop rdi
0000790c663d8619  pop rdx
0000790c663d861a  pop rcx
0000790c663d861b  pop rax
0000790c663d861c  add rsp, 0x08
0000790c663d8620  jmp 0x0000790C663D5FF7
0000790c663d8625  call 0x0000790C662D64F0
0000790c663d862a  jmp 0x0000790C663D6004
0000790c663d862f  sub rsp, 0x08
0000790c663d8633  push rax
0000790c663d8634  push rcx
0000790c663d8635  push rdx
0000790c663d8636  push rdi
0000790c663d8637  push rsi
0000790c663d8638  push r8
0000790c663d863a  push r9
0000790c663d863c  push r10
0000790c663d863e  push r11
0000790c663d8640  sub rsp, 0xF0
0000790c663d8647  vmovaps [rsp], xmm0
0000790c663d864c  vmovaps [rsp+0x10], xmm1
0000790c663d8652  vmovaps [rsp+0x20], xmm2
0000790c663d8658  vmovaps [rsp+0x30], xmm3
0000790c663d865e  vmovaps [rsp+0x40], xmm4
0000790c663d8664  vmovaps [rsp+0x50], xmm5
0000790c663d866a  vmovaps [rsp+0x60], xmm6
0000790c663d8670  vmovaps [rsp+0x70], xmm7
0000790c663d8676  vmovaps [rsp+0x80], xmm8
0000790c663d867f  vmovaps [rsp+0x90], xmm9
0000790c663d8688  vmovaps [rsp+0xA0], xmm10
0000790c663d8691  vmovaps [rsp+0xB0], xmm11
0000790c663d869a  vmovaps [rsp+0xC0], xmm12
0000790c663d86a3  vmovaps [rsp+0xD0], xmm13
0000790c663d86ac  vmovaps [rsp+0xE0], xmm14
0000790c663d86b5  sub rsp, 0x30
0000790c663d86b9  movaps [rsp], xmm15
0000790c663d86be  movaps [rsp+0x10], xmm3
0000790c663d86c3  movaps [rsp+0x20], xmm7
0000790c663d86c8  lea rdi, [rsp]
0000790c663d86cc  mov esi, 0x00
0000790c663d86d1  mov rax, 0x631C1759F530
0000790c663d86db  call rax
0000790c663d86dd  movaps xmm15, [rsp]
0000790c663d86e2  add rsp, 0x30
0000790c663d86e6  vmovaps xmm0, [rsp]
0000790c663d86eb  vmovaps xmm1, [rsp+0x10]
0000790c663d86f1  vmovaps xmm2, [rsp+0x20]
0000790c663d86f7  vmovaps xmm3, [rsp+0x30]
0000790c663d86fd  vmovaps xmm4, [rsp+0x40]
0000790c663d8703  vmovaps xmm5, [rsp+0x50]
0000790c663d8709  vmovaps xmm6, [rsp+0x60]
0000790c663d870f  vmovaps xmm7, [rsp+0x70]
0000790c663d8715  vmovaps xmm8, [rsp+0x80]
0000790c663d871e  vmovaps xmm9, [rsp+0x90]
0000790c663d8727  vmovaps xmm10, [rsp+0xA0]
0000790c663d8730  vmovaps xmm11, [rsp+0xB0]
0000790c663d8739  vmovaps xmm12, [rsp+0xC0]
0000790c663d8742  vmovaps xmm13, [rsp+0xD0]
0000790c663d874b  vmovaps xmm14, [rsp+0xE0]
0000790c663d8754  add rsp, 0xF0
0000790c663d875b  pop r11
0000790c663d875d  pop r10
0000790c663d875f  pop r9
0000790c663d8761  pop r8
0000790c663d8763  pop rsi
0000790c663d8764  pop rdi
0000790c663d8765  pop rdx
0000790c663d8766  pop rcx
0000790c663d8767  pop rax
0000790c663d8768  add rsp, 0x08
0000790c663d876c  jmp 0x0000790C663D6030
0000790c663d8771  sub rsp, 0x08
0000790c663d8775  push rax
0000790c663d8776  push rcx
0000790c663d8777  push rdx
0000790c663d8778  push rdi
0000790c663d8779  push rsi
0000790c663d877a  push r8
0000790c663d877c  push r9
0000790c663d877e  push r10
0000790c663d8780  push r11
0000790c663d8782  sub rsp, 0xF0
0000790c663d8789  vmovaps [rsp], xmm0
0000790c663d878e  vmovaps [rsp+0x10], xmm1
0000790c663d8794  vmovaps [rsp+0x20], xmm2
0000790c663d879a  vmovaps [rsp+0x30], xmm4
0000790c663d87a0  vmovaps [rsp+0x40], xmm5
0000790c663d87a6  vmovaps [rsp+0x50], xmm6
0000790c663d87ac  vmovaps [rsp+0x60], xmm7
0000790c663d87b2  vmovaps [rsp+0x70], xmm8
0000790c663d87b8  vmovaps [rsp+0x80], xmm9
0000790c663d87c1  vmovaps [rsp+0x90], xmm10
0000790c663d87ca  vmovaps [rsp+0xA0], xmm11
0000790c663d87d3  vmovaps [rsp+0xB0], xmm12
0000790c663d87dc  vmovaps [rsp+0xC0], xmm13
0000790c663d87e5  vmovaps [rsp+0xD0], xmm14
0000790c663d87ee  vmovaps [rsp+0xE0], xmm15
0000790c663d87f7  sub rsp, 0x30
0000790c663d87fb  movaps [rsp], xmm3
0000790c663d87ff  movaps [rsp+0x10], xmm1
0000790c663d8804  movaps [rsp+0x20], xmm15
0000790c663d880a  lea rdi, [rsp]
0000790c663d880e  mov esi, 0x00
0000790c663d8813  mov rax, 0x631C1759F530
0000790c663d881d  call rax
0000790c663d881f  movaps xmm3, [rsp]
0000790c663d8823  add rsp, 0x30
0000790c663d8827  vmovaps xmm0, [rsp]
0000790c663d882c  vmovaps xmm1, [rsp+0x10]
0000790c663d8832  vmovaps xmm2, [rsp+0x20]
0000790c663d8838  vmovaps xmm4, [rsp+0x30]
0000790c663d883e  vmovaps xmm5, [rsp+0x40]
0000790c663d8844  vmovaps xmm6, [rsp+0x50]
0000790c663d884a  vmovaps xmm7, [rsp+0x60]
0000790c663d8850  vmovaps xmm8, [rsp+0x70]
0000790c663d8856  vmovaps xmm9, [rsp+0x80]
0000790c663d885f  vmovaps xmm10, [rsp+0x90]
0000790c663d8868  vmovaps xmm11, [rsp+0xA0]
0000790c663d8871  vmovaps xmm12, [rsp+0xB0]
0000790c663d887a  vmovaps xmm13, [rsp+0xC0]
0000790c663d8883  vmovaps xmm14, [rsp+0xD0]
0000790c663d888c  vmovaps xmm15, [rsp+0xE0]
0000790c663d8895  add rsp, 0xF0
0000790c663d889c  pop r11
0000790c663d889e  pop r10
0000790c663d88a0  pop r9
0000790c663d88a2  pop r8
0000790c663d88a4  pop rsi
0000790c663d88a5  pop rdi
0000790c663d88a6  pop rdx
0000790c663d88a7  pop rcx
0000790c663d88a8  pop rax
0000790c663d88a9  add rsp, 0x08
0000790c663d88ad  jmp 0x0000790C663D60BF
0000790c663d88b2  call 0x0000790C662D64F0
0000790c663d88b7  jmp 0x0000790C663D60C9
0000790c663d88bc  sub rsp, 0x08
0000790c663d88c0  push rax
0000790c663d88c1  push rcx
0000790c663d88c2  push rdx
0000790c663d88c3  push rdi
0000790c663d88c4  push rsi
0000790c663d88c5  push r8
0000790c663d88c7  push r9
0000790c663d88c9  push r10
0000790c663d88cb  push r11
0000790c663d88cd  sub rsp, 0xF0
0000790c663d88d4  vmovaps [rsp], xmm0
0000790c663d88d9  vmovaps [rsp+0x10], xmm1
0000790c663d88df  vmovaps [rsp+0x20], xmm2
0000790c663d88e5  vmovaps [rsp+0x30], xmm3
0000790c663d88eb  vmovaps [rsp+0x40], xmm4
0000790c663d88f1  vmovaps [rsp+0x50], xmm5
0000790c663d88f7  vmovaps [rsp+0x60], xmm6
0000790c663d88fd  vmovaps [rsp+0x70], xmm7
0000790c663d8903  vmovaps [rsp+0x80], xmm8
0000790c663d890c  vmovaps [rsp+0x90], xmm9
0000790c663d8915  vmovaps [rsp+0xA0], xmm10
0000790c663d891e  vmovaps [rsp+0xB0], xmm11
0000790c663d8927  vmovaps [rsp+0xC0], xmm12
0000790c663d8930  vmovaps [rsp+0xD0], xmm13
0000790c663d8939  vmovaps [rsp+0xE0], xmm14
0000790c663d8942  sub rsp, 0x30
0000790c663d8946  movaps [rsp], xmm15
0000790c663d894b  movaps [rsp+0x10], xmm14
0000790c663d8951  movaps [rsp+0x20], xmm4
0000790c663d8956  lea rdi, [rsp]
0000790c663d895a  mov esi, 0x00
0000790c663d895f  mov rax, 0x631C1759F530
0000790c663d8969  call rax
0000790c663d896b  movaps xmm15, [rsp]
0000790c663d8970  add rsp, 0x30
0000790c663d8974  vmovaps xmm0, [rsp]
0000790c663d8979  vmovaps xmm1, [rsp+0x10]
0000790c663d897f  vmovaps xmm2, [rsp+0x20]
0000790c663d8985  vmovaps xmm3, [rsp+0x30]
0000790c663d898b  vmovaps xmm4, [rsp+0x40]
0000790c663d8991  vmovaps xmm5, [rsp+0x50]
0000790c663d8997  vmovaps xmm6, [rsp+0x60]
0000790c663d899d  vmovaps xmm7, [rsp+0x70]
0000790c663d89a3  vmovaps xmm8, [rsp+0x80]
0000790c663d89ac  vmovaps xmm9, [rsp+0x90]
0000790c663d89b5  vmovaps xmm10, [rsp+0xA0]
0000790c663d89be  vmovaps xmm11, [rsp+0xB0]
0000790c663d89c7  vmovaps xmm12, [rsp+0xC0]
0000790c663d89d0  vmovaps xmm13, [rsp+0xD0]
0000790c663d89d9  vmovaps xmm14, [rsp+0xE0]
0000790c663d89e2  add rsp, 0xF0
0000790c663d89e9  pop r11
0000790c663d89eb  pop r10
0000790c663d89ed  pop r9
0000790c663d89ef  pop r8
0000790c663d89f1  pop rsi
0000790c663d89f2  pop rdi
0000790c663d89f3  pop rdx
0000790c663d89f4  pop rcx
0000790c663d89f5  pop rax
0000790c663d89f6  add rsp, 0x08
0000790c663d89fa  jmp 0x0000790C663D60F7
0000790c663d89ff  sub rsp, 0x08
0000790c663d8a03  push rax
0000790c663d8a04  push rcx
0000790c663d8a05  push rdx
0000790c663d8a06  push rdi
0000790c663d8a07  push rsi
0000790c663d8a08  push r8
0000790c663d8a0a  push r9
0000790c663d8a0c  push r10
0000790c663d8a0e  push r11
0000790c663d8a10  sub rsp, 0xF0
0000790c663d8a17  vmovaps [rsp], xmm0
0000790c663d8a1c  vmovaps [rsp+0x10], xmm1
0000790c663d8a22  vmovaps [rsp+0x20], xmm2
0000790c663d8a28  vmovaps [rsp+0x30], xmm3
0000790c663d8a2e  vmovaps [rsp+0x40], xmm4
0000790c663d8a34  vmovaps [rsp+0x50], xmm5
0000790c663d8a3a  vmovaps [rsp+0x60], xmm6
0000790c663d8a40  vmovaps [rsp+0x70], xmm7
0000790c663d8a46  vmovaps [rsp+0x80], xmm8
0000790c663d8a4f  vmovaps [rsp+0x90], xmm9
0000790c663d8a58  vmovaps [rsp+0xA0], xmm10
0000790c663d8a61  vmovaps [rsp+0xB0], xmm11
0000790c663d8a6a  vmovaps [rsp+0xC0], xmm12
0000790c663d8a73  vmovaps [rsp+0xD0], xmm13
0000790c663d8a7c  vmovaps [rsp+0xE0], xmm15
0000790c663d8a85  sub rsp, 0x30
0000790c663d8a89  movaps [rsp], xmm14
0000790c663d8a8e  movaps [rsp+0x10], xmm2
0000790c663d8a93  movaps [rsp+0x20], xmm1
0000790c663d8a98  lea rdi, [rsp]
0000790c663d8a9c  mov esi, 0x00
0000790c663d8aa1  mov rax, 0x631C1759F530
0000790c663d8aab  call rax
0000790c663d8aad  movaps xmm14, [rsp]
0000790c663d8ab2  add rsp, 0x30
0000790c663d8ab6  vmovaps xmm0, [rsp]
0000790c663d8abb  vmovaps xmm1, [rsp+0x10]
0000790c663d8ac1  vmovaps xmm2, [rsp+0x20]
0000790c663d8ac7  vmovaps xmm3, [rsp+0x30]
0000790c663d8acd  vmovaps xmm4, [rsp+0x40]
0000790c663d8ad3  vmovaps xmm5, [rsp+0x50]
0000790c663d8ad9  vmovaps xmm6, [rsp+0x60]
0000790c663d8adf  vmovaps xmm7, [rsp+0x70]
0000790c663d8ae5  vmovaps xmm8, [rsp+0x80]
0000790c663d8aee  vmovaps xmm9, [rsp+0x90]
0000790c663d8af7  vmovaps xmm10, [rsp+0xA0]
0000790c663d8b00  vmovaps xmm11, [rsp+0xB0]
0000790c663d8b09  vmovaps xmm12, [rsp+0xC0]
0000790c663d8b12  vmovaps xmm13, [rsp+0xD0]
0000790c663d8b1b  vmovaps xmm15, [rsp+0xE0]
0000790c663d8b24  add rsp, 0xF0
0000790c663d8b2b  pop r11
0000790c663d8b2d  pop r10
0000790c663d8b2f  pop r9
0000790c663d8b31  pop r8
0000790c663d8b33  pop rsi
0000790c663d8b34  pop rdi
0000790c663d8b35  pop rdx
0000790c663d8b36  pop rcx
0000790c663d8b37  pop rax
0000790c663d8b38  add rsp, 0x08
0000790c663d8b3c  jmp 0x0000790C663D611D
0000790c663d8b41  sub rsp, 0x08
0000790c663d8b45  push rax
0000790c663d8b46  push rcx
0000790c663d8b47  push rdx
0000790c663d8b48  push rdi
0000790c663d8b49  push rsi
0000790c663d8b4a  push r8
0000790c663d8b4c  push r9
0000790c663d8b4e  push r10
0000790c663d8b50  push r11
0000790c663d8b52  sub rsp, 0xF0
0000790c663d8b59  vmovaps [rsp], xmm0
0000790c663d8b5e  vmovaps [rsp+0x10], xmm2
0000790c663d8b64  vmovaps [rsp+0x20], xmm3
0000790c663d8b6a  vmovaps [rsp+0x30], xmm4
0000790c663d8b70  vmovaps [rsp+0x40], xmm5
0000790c663d8b76  vmovaps [rsp+0x50], xmm6
0000790c663d8b7c  vmovaps [rsp+0x60], xmm7
0000790c663d8b82  vmovaps [rsp+0x70], xmm8
0000790c663d8b88  vmovaps [rsp+0x80], xmm9
0000790c663d8b91  vmovaps [rsp+0x90], xmm10
0000790c663d8b9a  vmovaps [rsp+0xA0], xmm11
0000790c663d8ba3  vmovaps [rsp+0xB0], xmm12
0000790c663d8bac  vmovaps [rsp+0xC0], xmm13
0000790c663d8bb5  vmovaps [rsp+0xD0], xmm14
0000790c663d8bbe  vmovaps [rsp+0xE0], xmm15
0000790c663d8bc7  sub rsp, 0x30
0000790c663d8bcb  movaps [rsp], xmm1
0000790c663d8bcf  movaps [rsp+0x10], xmm4
0000790c663d8bd4  movaps [rsp+0x20], xmm9
0000790c663d8bda  lea rdi, [rsp]
0000790c663d8bde  mov esi, 0x00
0000790c663d8be3  mov rax, 0x631C1759F530
0000790c663d8bed  call rax
0000790c663d8bef  movaps xmm1, [rsp]
0000790c663d8bf3  add rsp, 0x30
0000790c663d8bf7  vmovaps xmm0, [rsp]
0000790c663d8bfc  vmovaps xmm2, [rsp+0x10]
0000790c663d8c02  vmovaps xmm3, [rsp+0x20]
0000790c663d8c08  vmovaps xmm4, [rsp+0x30]
0000790c663d8c0e  vmovaps xmm5, [rsp+0x40]
0000790c663d8c14  vmovaps xmm6, [rsp+0x50]
0000790c663d8c1a  vmovaps xmm7, [rsp+0x60]
0000790c663d8c20  vmovaps xmm8, [rsp+0x70]
0000790c663d8c26  vmovaps xmm9, [rsp+0x80]
0000790c663d8c2f  vmovaps xmm10, [rsp+0x90]
0000790c663d8c38  vmovaps xmm11, [rsp+0xA0]
0000790c663d8c41  vmovaps xmm12, [rsp+0xB0]
0000790c663d8c4a  vmovaps xmm13, [rsp+0xC0]
0000790c663d8c53  vmovaps xmm14, [rsp+0xD0]
0000790c663d8c5c  vmovaps xmm15, [rsp+0xE0]
0000790c663d8c65  add rsp, 0xF0
0000790c663d8c6c  pop r11
0000790c663d8c6e  pop r10
0000790c663d8c70  pop r9
0000790c663d8c72  pop r8
0000790c663d8c74  pop rsi
0000790c663d8c75  pop rdi
0000790c663d8c76  pop rdx
0000790c663d8c77  pop rcx
0000790c663d8c78  pop rax
0000790c663d8c79  add rsp, 0x08
0000790c663d8c7d  jmp 0x0000790C663D613B
0000790c663d8c82  sub rsp, 0x08
0000790c663d8c86  push rax
0000790c663d8c87  push rcx
0000790c663d8c88  push rdx
0000790c663d8c89  push rdi
0000790c663d8c8a  push rsi
0000790c663d8c8b  push r8
0000790c663d8c8d  push r9
0000790c663d8c8f  push r10
0000790c663d8c91  push r11
0000790c663d8c93  sub rsp, 0xF0
0000790c663d8c9a  vmovaps [rsp], xmm0
0000790c663d8c9f  vmovaps [rsp+0x10], xmm1
0000790c663d8ca5  vmovaps [rsp+0x20], xmm2
0000790c663d8cab  vmovaps [rsp+0x30], xmm3
0000790c663d8cb1  vmovaps [rsp+0x40], xmm5
0000790c663d8cb7  vmovaps [rsp+0x50], xmm6
0000790c663d8cbd  vmovaps [rsp+0x60], xmm7
0000790c663d8cc3  vmovaps [rsp+0x70], xmm8
0000790c663d8cc9  vmovaps [rsp+0x80], xmm9
0000790c663d8cd2  vmovaps [rsp+0x90], xmm10
0000790c663d8cdb  vmovaps [rsp+0xA0], xmm11
0000790c663d8ce4  vmovaps [rsp+0xB0], xmm12
0000790c663d8ced  vmovaps [rsp+0xC0], xmm13
0000790c663d8cf6  vmovaps [rsp+0xD0], xmm14
0000790c663d8cff  vmovaps [rsp+0xE0], xmm15
0000790c663d8d08  sub rsp, 0x30
0000790c663d8d0c  movaps [rsp], xmm4
0000790c663d8d10  movaps [rsp+0x10], xmm2
0000790c663d8d15  movaps [rsp+0x20], xmm9
0000790c663d8d1b  lea rdi, [rsp]
0000790c663d8d1f  mov esi, 0x00
0000790c663d8d24  mov rax, 0x631C1759F530
0000790c663d8d2e  call rax
0000790c663d8d30  movaps xmm4, [rsp]
0000790c663d8d34  add rsp, 0x30
0000790c663d8d38  vmovaps xmm0, [rsp]
0000790c663d8d3d  vmovaps xmm1, [rsp+0x10]
0000790c663d8d43  vmovaps xmm2, [rsp+0x20]
0000790c663d8d49  vmovaps xmm3, [rsp+0x30]
0000790c663d8d4f  vmovaps xmm5, [rsp+0x40]
0000790c663d8d55  vmovaps xmm6, [rsp+0x50]
0000790c663d8d5b  vmovaps xmm7, [rsp+0x60]
0000790c663d8d61  vmovaps xmm8, [rsp+0x70]
0000790c663d8d67  vmovaps xmm9, [rsp+0x80]
0000790c663d8d70  vmovaps xmm10, [rsp+0x90]
0000790c663d8d79  vmovaps xmm11, [rsp+0xA0]
0000790c663d8d82  vmovaps xmm12, [rsp+0xB0]
0000790c663d8d8b  vmovaps xmm13, [rsp+0xC0]
0000790c663d8d94  vmovaps xmm14, [rsp+0xD0]
0000790c663d8d9d  vmovaps xmm15, [rsp+0xE0]
0000790c663d8da6  add rsp, 0xF0
0000790c663d8dad  pop r11
0000790c663d8daf  pop r10
0000790c663d8db1  pop r9
0000790c663d8db3  pop r8
0000790c663d8db5  pop rsi
0000790c663d8db6  pop rdi
0000790c663d8db7  pop rdx
0000790c663d8db8  pop rcx
0000790c663d8db9  pop rax
0000790c663d8dba  add rsp, 0x08
0000790c663d8dbe  jmp 0x0000790C663D616B
0000790c663d8dc3  sub rsp, 0x08
0000790c663d8dc7  push rax
0000790c663d8dc8  push rcx
0000790c663d8dc9  push rdx
0000790c663d8dca  push rdi
0000790c663d8dcb  push rsi
0000790c663d8dcc  push r8
0000790c663d8dce  push r9
0000790c663d8dd0  push r10
0000790c663d8dd2  push r11
0000790c663d8dd4  sub rsp, 0xF0
0000790c663d8ddb  vmovaps [rsp], xmm0
0000790c663d8de0  vmovaps [rsp+0x10], xmm1
0000790c663d8de6  vmovaps [rsp+0x20], xmm2
0000790c663d8dec  vmovaps [rsp+0x30], xmm3
0000790c663d8df2  vmovaps [rsp+0x40], xmm4
0000790c663d8df8  vmovaps [rsp+0x50], xmm5
0000790c663d8dfe  vmovaps [rsp+0x60], xmm6
0000790c663d8e04  vmovaps [rsp+0x70], xmm7
0000790c663d8e0a  vmovaps [rsp+0x80], xmm8
0000790c663d8e13  vmovaps [rsp+0x90], xmm10
0000790c663d8e1c  vmovaps [rsp+0xA0], xmm11
0000790c663d8e25  vmovaps [rsp+0xB0], xmm12
0000790c663d8e2e  vmovaps [rsp+0xC0], xmm13
0000790c663d8e37  vmovaps [rsp+0xD0], xmm14
0000790c663d8e40  vmovaps [rsp+0xE0], xmm15
0000790c663d8e49  sub rsp, 0x30
0000790c663d8e4d  movaps [rsp], xmm9
0000790c663d8e52  movaps [rsp+0x10], xmm2
0000790c663d8e57  movaps [rsp+0x20], xmm1
0000790c663d8e5c  lea rdi, [rsp]
0000790c663d8e60  mov esi, 0x00
0000790c663d8e65  mov rax, 0x631C1759F530
0000790c663d8e6f  call rax
0000790c663d8e71  movaps xmm9, [rsp]
0000790c663d8e76  add rsp, 0x30
0000790c663d8e7a  vmovaps xmm0, [rsp]
0000790c663d8e7f  vmovaps xmm1, [rsp+0x10]
0000790c663d8e85  vmovaps xmm2, [rsp+0x20]
0000790c663d8e8b  vmovaps xmm3, [rsp+0x30]
0000790c663d8e91  vmovaps xmm4, [rsp+0x40]
0000790c663d8e97  vmovaps xmm5, [rsp+0x50]
0000790c663d8e9d  vmovaps xmm6, [rsp+0x60]
0000790c663d8ea3  vmovaps xmm7, [rsp+0x70]
0000790c663d8ea9  vmovaps xmm8, [rsp+0x80]
0000790c663d8eb2  vmovaps xmm10, [rsp+0x90]
0000790c663d8ebb  vmovaps xmm11, [rsp+0xA0]
0000790c663d8ec4  vmovaps xmm12, [rsp+0xB0]
0000790c663d8ecd  vmovaps xmm13, [rsp+0xC0]
0000790c663d8ed6  vmovaps xmm14, [rsp+0xD0]
0000790c663d8edf  vmovaps xmm15, [rsp+0xE0]
0000790c663d8ee8  add rsp, 0xF0
0000790c663d8eef  pop r11
0000790c663d8ef1  pop r10
0000790c663d8ef3  pop r9
0000790c663d8ef5  pop r8
0000790c663d8ef7  pop rsi
0000790c663d8ef8  pop rdi
0000790c663d8ef9  pop rdx
0000790c663d8efa  pop rcx
0000790c663d8efb  pop rax
0000790c663d8efc  add rsp, 0x08
0000790c663d8f00  jmp 0x0000790C663D61A1
0000790c663d8f05  sub rsp, 0x08
0000790c663d8f09  push rax
0000790c663d8f0a  push rcx
0000790c663d8f0b  push rdx
0000790c663d8f0c  push rdi
0000790c663d8f0d  push rsi
0000790c663d8f0e  push r8
0000790c663d8f10  push r9
0000790c663d8f12  push r10
0000790c663d8f14  push r11
0000790c663d8f16  sub rsp, 0xF0
0000790c663d8f1d  vmovaps [rsp], xmm0
0000790c663d8f22  vmovaps [rsp+0x10], xmm2
0000790c663d8f28  vmovaps [rsp+0x20], xmm3
0000790c663d8f2e  vmovaps [rsp+0x30], xmm4
0000790c663d8f34  vmovaps [rsp+0x40], xmm5
0000790c663d8f3a  vmovaps [rsp+0x50], xmm6
0000790c663d8f40  vmovaps [rsp+0x60], xmm7
0000790c663d8f46  vmovaps [rsp+0x70], xmm8
0000790c663d8f4c  vmovaps [rsp+0x80], xmm9
0000790c663d8f55  vmovaps [rsp+0x90], xmm10
0000790c663d8f5e  vmovaps [rsp+0xA0], xmm11
0000790c663d8f67  vmovaps [rsp+0xB0], xmm12
0000790c663d8f70  vmovaps [rsp+0xC0], xmm13
0000790c663d8f79  vmovaps [rsp+0xD0], xmm14
0000790c663d8f82  vmovaps [rsp+0xE0], xmm15
0000790c663d8f8b  sub rsp, 0x30
0000790c663d8f8f  movaps [rsp], xmm1
0000790c663d8f93  movaps [rsp+0x10], xmm15
0000790c663d8f99  movaps [rsp+0x20], xmm6
0000790c663d8f9e  lea rdi, [rsp]
0000790c663d8fa2  mov esi, 0x00
0000790c663d8fa7  mov rax, 0x631C1759F530
0000790c663d8fb1  call rax
0000790c663d8fb3  movaps xmm1, [rsp]
0000790c663d8fb7  add rsp, 0x30
0000790c663d8fbb  vmovaps xmm0, [rsp]
0000790c663d8fc0  vmovaps xmm2, [rsp+0x10]
0000790c663d8fc6  vmovaps xmm3, [rsp+0x20]
0000790c663d8fcc  vmovaps xmm4, [rsp+0x30]
0000790c663d8fd2  vmovaps xmm5, [rsp+0x40]
0000790c663d8fd8  vmovaps xmm6, [rsp+0x50]
0000790c663d8fde  vmovaps xmm7, [rsp+0x60]
0000790c663d8fe4  vmovaps xmm8, [rsp+0x70]
0000790c663d8fea  vmovaps xmm9, [rsp+0x80]
0000790c663d8ff3  vmovaps xmm10, [rsp+0x90]
0000790c663d8ffc  vmovaps xmm11, [rsp+0xA0]
0000790c663d9005  vmovaps xmm12, [rsp+0xB0]
0000790c663d900e  vmovaps xmm13, [rsp+0xC0]
0000790c663d9017  vmovaps xmm14, [rsp+0xD0]
0000790c663d9020  vmovaps xmm15, [rsp+0xE0]
0000790c663d9029  add rsp, 0xF0
0000790c663d9030  pop r11
0000790c663d9032  pop r10
0000790c663d9034  pop r9
0000790c663d9036  pop r8
0000790c663d9038  pop rsi
0000790c663d9039  pop rdi
0000790c663d903a  pop rdx
0000790c663d903b  pop rcx
0000790c663d903c  pop rax
0000790c663d903d  add rsp, 0x08
0000790c663d9041  jmp 0x0000790C663D61C2
0000790c663d9046  sub rsp, 0x08
0000790c663d904a  push rax
0000790c663d904b  push rcx
0000790c663d904c  push rdx
0000790c663d904d  push rdi
0000790c663d904e  push rsi
0000790c663d904f  push r8
0000790c663d9051  push r9
0000790c663d9053  push r10
0000790c663d9055  push r11
0000790c663d9057  sub rsp, 0xF0
0000790c663d905e  vmovaps [rsp], xmm0
0000790c663d9063  vmovaps [rsp+0x10], xmm1
0000790c663d9069  vmovaps [rsp+0x20], xmm2
0000790c663d906f  vmovaps [rsp+0x30], xmm3
0000790c663d9075  vmovaps [rsp+0x40], xmm4
0000790c663d907b  vmovaps [rsp+0x50], xmm5
0000790c663d9081  vmovaps [rsp+0x60], xmm6
0000790c663d9087  vmovaps [rsp+0x70], xmm7
0000790c663d908d  vmovaps [rsp+0x80], xmm8
0000790c663d9096  vmovaps [rsp+0x90], xmm9
0000790c663d909f  vmovaps [rsp+0xA0], xmm10
0000790c663d90a8  vmovaps [rsp+0xB0], xmm11
0000790c663d90b1  vmovaps [rsp+0xC0], xmm12
0000790c663d90ba  vmovaps [rsp+0xD0], xmm13
0000790c663d90c3  vmovaps [rsp+0xE0], xmm14
0000790c663d90cc  sub rsp, 0x30
0000790c663d90d0  movaps [rsp], xmm15
0000790c663d90d5  movaps [rsp+0x10], xmm5
0000790c663d90da  movaps [rsp+0x20], xmm3
0000790c663d90df  lea rdi, [rsp]
0000790c663d90e3  mov esi, 0x00
0000790c663d90e8  mov rax, 0x631C1759F530
0000790c663d90f2  call rax
0000790c663d90f4  movaps xmm15, [rsp]
0000790c663d90f9  add rsp, 0x30
0000790c663d90fd  vmovaps xmm0, [rsp]
0000790c663d9102  vmovaps xmm1, [rsp+0x10]
0000790c663d9108  vmovaps xmm2, [rsp+0x20]
0000790c663d910e  vmovaps xmm3, [rsp+0x30]
0000790c663d9114  vmovaps xmm4, [rsp+0x40]
0000790c663d911a  vmovaps xmm5, [rsp+0x50]
0000790c663d9120  vmovaps xmm6, [rsp+0x60]
0000790c663d9126  vmovaps xmm7, [rsp+0x70]
0000790c663d912c  vmovaps xmm8, [rsp+0x80]
0000790c663d9135  vmovaps xmm9, [rsp+0x90]
0000790c663d913e  vmovaps xmm10, [rsp+0xA0]
0000790c663d9147  vmovaps xmm11, [rsp+0xB0]
0000790c663d9150  vmovaps xmm12, [rsp+0xC0]
0000790c663d9159  vmovaps xmm13, [rsp+0xD0]
0000790c663d9162  vmovaps xmm14, [rsp+0xE0]
0000790c663d916b  add rsp, 0xF0
0000790c663d9172  pop r11
0000790c663d9174  pop r10
0000790c663d9176  pop r9
0000790c663d9178  pop r8
0000790c663d917a  pop rsi
0000790c663d917b  pop rdi
0000790c663d917c  pop rdx
0000790c663d917d  pop rcx
0000790c663d917e  pop rax
0000790c663d917f  add rsp, 0x08
0000790c663d9183  jmp 0x0000790C663D61DC
0000790c663d9188  sub rsp, 0x08
0000790c663d918c  push rax
0000790c663d918d  push rcx
0000790c663d918e  push rdx
0000790c663d918f  push rdi
0000790c663d9190  push rsi
0000790c663d9191  push r8
0000790c663d9193  push r9
0000790c663d9195  push r10
0000790c663d9197  push r11
0000790c663d9199  sub rsp, 0xF0
0000790c663d91a0  vmovaps [rsp], xmm0
0000790c663d91a5  vmovaps [rsp+0x10], xmm1
0000790c663d91ab  vmovaps [rsp+0x20], xmm2
0000790c663d91b1  vmovaps [rsp+0x30], xmm3
0000790c663d91b7  vmovaps [rsp+0x40], xmm4
0000790c663d91bd  vmovaps [rsp+0x50], xmm6
0000790c663d91c3  vmovaps [rsp+0x60], xmm7
0000790c663d91c9  vmovaps [rsp+0x70], xmm8
0000790c663d91cf  vmovaps [rsp+0x80], xmm9
0000790c663d91d8  vmovaps [rsp+0x90], xmm10
0000790c663d91e1  vmovaps [rsp+0xA0], xmm11
0000790c663d91ea  vmovaps [rsp+0xB0], xmm12
0000790c663d91f3  vmovaps [rsp+0xC0], xmm13
0000790c663d91fc  vmovaps [rsp+0xD0], xmm14
0000790c663d9205  vmovaps [rsp+0xE0], xmm15
0000790c663d920e  sub rsp, 0x30
0000790c663d9212  movaps [rsp], xmm5
0000790c663d9216  movaps [rsp+0x10], xmm8
0000790c663d921c  movaps [rsp+0x20], xmm6
0000790c663d9221  lea rdi, [rsp]
0000790c663d9225  mov esi, 0x00
0000790c663d922a  mov rax, 0x631C1759F530
0000790c663d9234  call rax
0000790c663d9236  movaps xmm5, [rsp]
0000790c663d923a  add rsp, 0x30
0000790c663d923e  vmovaps xmm0, [rsp]
0000790c663d9243  vmovaps xmm1, [rsp+0x10]
0000790c663d9249  vmovaps xmm2, [rsp+0x20]
0000790c663d924f  vmovaps xmm3, [rsp+0x30]
0000790c663d9255  vmovaps xmm4, [rsp+0x40]
0000790c663d925b  vmovaps xmm6, [rsp+0x50]
0000790c663d9261  vmovaps xmm7, [rsp+0x60]
0000790c663d9267  vmovaps xmm8, [rsp+0x70]
0000790c663d926d  vmovaps xmm9, [rsp+0x80]
0000790c663d9276  vmovaps xmm10, [rsp+0x90]
0000790c663d927f  vmovaps xmm11, [rsp+0xA0]
0000790c663d9288  vmovaps xmm12, [rsp+0xB0]
0000790c663d9291  vmovaps xmm13, [rsp+0xC0]
0000790c663d929a  vmovaps xmm14, [rsp+0xD0]
0000790c663d92a3  vmovaps xmm15, [rsp+0xE0]
0000790c663d92ac  add rsp, 0xF0
0000790c663d92b3  pop r11
0000790c663d92b5  pop r10
0000790c663d92b7  pop r9
0000790c663d92b9  pop r8
0000790c663d92bb  pop rsi
0000790c663d92bc  pop rdi
0000790c663d92bd  pop rdx
0000790c663d92be  pop rcx
0000790c663d92bf  pop rax
0000790c663d92c0  add rsp, 0x08
0000790c663d92c4  jmp 0x0000790C663D6200
0000790c663d92c9  sub rsp, 0x08
0000790c663d92cd  push rax
0000790c663d92ce  push rcx
0000790c663d92cf  push rdx
0000790c663d92d0  push rdi
0000790c663d92d1  push rsi
0000790c663d92d2  push r8
0000790c663d92d4  push r9
0000790c663d92d6  push r10
0000790c663d92d8  push r11
0000790c663d92da  sub rsp, 0xF0
0000790c663d92e1  vmovaps [rsp], xmm0
0000790c663d92e6  vmovaps [rsp+0x10], xmm1
0000790c663d92ec  vmovaps [rsp+0x20], xmm2
0000790c663d92f2  vmovaps [rsp+0x30], xmm3
0000790c663d92f8  vmovaps [rsp+0x40], xmm4
0000790c663d92fe  vmovaps [rsp+0x50], xmm5
0000790c663d9304  vmovaps [rsp+0x60], xmm7
0000790c663d930a  vmovaps [rsp+0x70], xmm8
0000790c663d9310  vmovaps [rsp+0x80], xmm9
0000790c663d9319  vmovaps [rsp+0x90], xmm10
0000790c663d9322  vmovaps [rsp+0xA0], xmm11
0000790c663d932b  vmovaps [rsp+0xB0], xmm12
0000790c663d9334  vmovaps [rsp+0xC0], xmm13
0000790c663d933d  vmovaps [rsp+0xD0], xmm14
0000790c663d9346  vmovaps [rsp+0xE0], xmm15
0000790c663d934f  sub rsp, 0x30
0000790c663d9353  movaps [rsp], xmm6
0000790c663d9357  movaps [rsp+0x10], xmm10
0000790c663d935d  movaps [rsp+0x20], xmm8
0000790c663d9363  lea rdi, [rsp]
0000790c663d9367  mov esi, 0x00
0000790c663d936c  mov rax, 0x631C1759F530
0000790c663d9376  call rax
0000790c663d9378  movaps xmm6, [rsp]
0000790c663d937c  add rsp, 0x30
0000790c663d9380  vmovaps xmm0, [rsp]
0000790c663d9385  vmovaps xmm1, [rsp+0x10]
0000790c663d938b  vmovaps xmm2, [rsp+0x20]
0000790c663d9391  vmovaps xmm3, [rsp+0x30]
0000790c663d9397  vmovaps xmm4, [rsp+0x40]
0000790c663d939d  vmovaps xmm5, [rsp+0x50]
0000790c663d93a3  vmovaps xmm7, [rsp+0x60]
0000790c663d93a9  vmovaps xmm8, [rsp+0x70]
0000790c663d93af  vmovaps xmm9, [rsp+0x80]
0000790c663d93b8  vmovaps xmm10, [rsp+0x90]
0000790c663d93c1  vmovaps xmm11, [rsp+0xA0]
0000790c663d93ca  vmovaps xmm12, [rsp+0xB0]
0000790c663d93d3  vmovaps xmm13, [rsp+0xC0]
0000790c663d93dc  vmovaps xmm14, [rsp+0xD0]
0000790c663d93e5  vmovaps xmm15, [rsp+0xE0]
0000790c663d93ee  add rsp, 0xF0
0000790c663d93f5  pop r11
0000790c663d93f7  pop r10
0000790c663d93f9  pop r9
0000790c663d93fb  pop r8
0000790c663d93fd  pop rsi
0000790c663d93fe  pop rdi
0000790c663d93ff  pop rdx
0000790c663d9400  pop rcx
0000790c663d9401  pop rax
0000790c663d9402  add rsp, 0x08
0000790c663d9406  jmp 0x0000790C663D6225
0000790c663d940b  sub rsp, 0x08
0000790c663d940f  push rax
0000790c663d9410  push rcx
0000790c663d9411  push rdx
0000790c663d9412  push rdi
0000790c663d9413  push rsi
0000790c663d9414  push r8
0000790c663d9416  push r9
0000790c663d9418  push r10
0000790c663d941a  push r11
0000790c663d941c  sub rsp, 0xF0
0000790c663d9423  vmovaps [rsp], xmm0
0000790c663d9428  vmovaps [rsp+0x10], xmm1
0000790c663d942e  vmovaps [rsp+0x20], xmm2
0000790c663d9434  vmovaps [rsp+0x30], xmm3
0000790c663d943a  vmovaps [rsp+0x40], xmm4
0000790c663d9440  vmovaps [rsp+0x50], xmm5
0000790c663d9446  vmovaps [rsp+0x60], xmm6
0000790c663d944c  vmovaps [rsp+0x70], xmm7
0000790c663d9452  vmovaps [rsp+0x80], xmm8
0000790c663d945b  vmovaps [rsp+0x90], xmm9
0000790c663d9464  vmovaps [rsp+0xA0], xmm11
0000790c663d946d  vmovaps [rsp+0xB0], xmm12
0000790c663d9476  vmovaps [rsp+0xC0], xmm13
0000790c663d947f  vmovaps [rsp+0xD0], xmm14
0000790c663d9488  vmovaps [rsp+0xE0], xmm15
0000790c663d9491  sub rsp, 0x30
0000790c663d9495  movaps [rsp], xmm10
0000790c663d949a  movaps [rsp+0x10], xmm8
0000790c663d94a0  movaps [rsp+0x20], xmm14
0000790c663d94a6  lea rdi, [rsp]
0000790c663d94aa  mov esi, 0x00
0000790c663d94af  mov rax, 0x631C1759F530
0000790c663d94b9  call rax
0000790c663d94bb  movaps xmm10, [rsp]
0000790c663d94c0  add rsp, 0x30
0000790c663d94c4  vmovaps xmm0, [rsp]
0000790c663d94c9  vmovaps xmm1, [rsp+0x10]
0000790c663d94cf  vmovaps xmm2, [rsp+0x20]
0000790c663d94d5  vmovaps xmm3, [rsp+0x30]
0000790c663d94db  vmovaps xmm4, [rsp+0x40]
0000790c663d94e1  vmovaps xmm5, [rsp+0x50]
0000790c663d94e7  vmovaps xmm6, [rsp+0x60]
0000790c663d94ed  vmovaps xmm7, [rsp+0x70]
0000790c663d94f3  vmovaps xmm8, [rsp+0x80]
0000790c663d94fc  vmovaps xmm9, [rsp+0x90]
0000790c663d9505  vmovaps xmm11, [rsp+0xA0]
0000790c663d950e  vmovaps xmm12, [rsp+0xB0]
0000790c663d9517  vmovaps xmm13, [rsp+0xC0]
0000790c663d9520  vmovaps xmm14, [rsp+0xD0]
0000790c663d9529  vmovaps xmm15, [rsp+0xE0]
0000790c663d9532  add rsp, 0xF0
0000790c663d9539  pop r11
0000790c663d953b  pop r10
0000790c663d953d  pop r9
0000790c663d953f  pop r8
0000790c663d9541  pop rsi
0000790c663d9542  pop rdi
0000790c663d9543  pop rdx
0000790c663d9544  pop rcx
0000790c663d9545  pop rax
0000790c663d9546  add rsp, 0x08
0000790c663d954a  jmp 0x0000790C663D6245
0000790c663d954f  sub rsp, 0x08
0000790c663d9553  push rax
0000790c663d9554  push rcx
0000790c663d9555  push rdx
0000790c663d9556  push rdi
0000790c663d9557  push rsi
0000790c663d9558  push r8
0000790c663d955a  push r9
0000790c663d955c  push r10
0000790c663d955e  push r11
0000790c663d9560  sub rsp, 0xF0
0000790c663d9567  vmovaps [rsp], xmm0
0000790c663d956c  vmovaps [rsp+0x10], xmm1
0000790c663d9572  vmovaps [rsp+0x20], xmm2
0000790c663d9578  vmovaps [rsp+0x30], xmm3
0000790c663d957e  vmovaps [rsp+0x40], xmm4
0000790c663d9584  vmovaps [rsp+0x50], xmm5
0000790c663d958a  vmovaps [rsp+0x60], xmm6
0000790c663d9590  vmovaps [rsp+0x70], xmm7
0000790c663d9596  vmovaps [rsp+0x80], xmm8
0000790c663d959f  vmovaps [rsp+0x90], xmm9
0000790c663d95a8  vmovaps [rsp+0xA0], xmm10
0000790c663d95b1  vmovaps [rsp+0xB0], xmm11
0000790c663d95ba  vmovaps [rsp+0xC0], xmm12
0000790c663d95c3  vmovaps [rsp+0xD0], xmm13
0000790c663d95cc  vmovaps [rsp+0xE0], xmm15
0000790c663d95d5  sub rsp, 0x30
0000790c663d95d9  movaps [rsp], xmm14
0000790c663d95de  movaps [rsp+0x10], xmm8
0000790c663d95e4  movaps [rsp+0x20], xmm4
0000790c663d95e9  lea rdi, [rsp]
0000790c663d95ed  mov esi, 0x00
0000790c663d95f2  mov rax, 0x631C1759F530
0000790c663d95fc  call rax
0000790c663d95fe  movaps xmm14, [rsp]
0000790c663d9603  add rsp, 0x30
0000790c663d9607  vmovaps xmm0, [rsp]
0000790c663d960c  vmovaps xmm1, [rsp+0x10]
0000790c663d9612  vmovaps xmm2, [rsp+0x20]
0000790c663d9618  vmovaps xmm3, [rsp+0x30]
0000790c663d961e  vmovaps xmm4, [rsp+0x40]
0000790c663d9624  vmovaps xmm5, [rsp+0x50]
0000790c663d962a  vmovaps xmm6, [rsp+0x60]
0000790c663d9630  vmovaps xmm7, [rsp+0x70]
0000790c663d9636  vmovaps xmm8, [rsp+0x80]
0000790c663d963f  vmovaps xmm9, [rsp+0x90]
0000790c663d9648  vmovaps xmm10, [rsp+0xA0]
0000790c663d9651  vmovaps xmm11, [rsp+0xB0]
0000790c663d965a  vmovaps xmm12, [rsp+0xC0]
0000790c663d9663  vmovaps xmm13, [rsp+0xD0]
0000790c663d966c  vmovaps xmm15, [rsp+0xE0]
0000790c663d9675  add rsp, 0xF0
0000790c663d967c  pop r11
0000790c663d967e  pop r10
0000790c663d9680  pop r9
0000790c663d9682  pop r8
0000790c663d9684  pop rsi
0000790c663d9685  pop rdi
0000790c663d9686  pop rdx
0000790c663d9687  pop rcx
0000790c663d9688  pop rax
0000790c663d9689  add rsp, 0x08
0000790c663d968d  jmp 0x0000790C663D6265
0000790c663d9692  sub rsp, 0x08
0000790c663d9696  push rax
0000790c663d9697  push rcx
0000790c663d9698  push rdx
0000790c663d9699  push rdi
0000790c663d969a  push rsi
0000790c663d969b  push r8
0000790c663d969d  push r9
0000790c663d969f  push r10
0000790c663d96a1  push r11
0000790c663d96a3  sub rsp, 0xF0
0000790c663d96aa  vmovaps [rsp], xmm0
0000790c663d96af  vmovaps [rsp+0x10], xmm1
0000790c663d96b5  vmovaps [rsp+0x20], xmm2
0000790c663d96bb  vmovaps [rsp+0x30], xmm3
0000790c663d96c1  vmovaps [rsp+0x40], xmm5
0000790c663d96c7  vmovaps [rsp+0x50], xmm6
0000790c663d96cd  vmovaps [rsp+0x60], xmm7
0000790c663d96d3  vmovaps [rsp+0x70], xmm8
0000790c663d96d9  vmovaps [rsp+0x80], xmm9
0000790c663d96e2  vmovaps [rsp+0x90], xmm10
0000790c663d96eb  vmovaps [rsp+0xA0], xmm11
0000790c663d96f4  vmovaps [rsp+0xB0], xmm12
0000790c663d96fd  vmovaps [rsp+0xC0], xmm13
0000790c663d9706  vmovaps [rsp+0xD0], xmm14
0000790c663d970f  vmovaps [rsp+0xE0], xmm15
0000790c663d9718  sub rsp, 0x30
0000790c663d971c  movaps [rsp], xmm4
0000790c663d9720  movaps [rsp+0x10], xmm13
0000790c663d9726  movaps [rsp+0x20], xmm8
0000790c663d972c  lea rdi, [rsp]
0000790c663d9730  mov esi, 0x00
0000790c663d9735  mov rax, 0x631C1759F530
0000790c663d973f  call rax
0000790c663d9741  movaps xmm4, [rsp]
0000790c663d9745  add rsp, 0x30
0000790c663d9749  vmovaps xmm0, [rsp]
0000790c663d974e  vmovaps xmm1, [rsp+0x10]
0000790c663d9754  vmovaps xmm2, [rsp+0x20]
0000790c663d975a  vmovaps xmm3, [rsp+0x30]
0000790c663d9760  vmovaps xmm5, [rsp+0x40]
0000790c663d9766  vmovaps xmm6, [rsp+0x50]
0000790c663d976c  vmovaps xmm7, [rsp+0x60]
0000790c663d9772  vmovaps xmm8, [rsp+0x70]
0000790c663d9778  vmovaps xmm9, [rsp+0x80]
0000790c663d9781  vmovaps xmm10, [rsp+0x90]
0000790c663d978a  vmovaps xmm11, [rsp+0xA0]
0000790c663d9793  vmovaps xmm12, [rsp+0xB0]
0000790c663d979c  vmovaps xmm13, [rsp+0xC0]
0000790c663d97a5  vmovaps xmm14, [rsp+0xD0]
0000790c663d97ae  vmovaps xmm15, [rsp+0xE0]
0000790c663d97b7  add rsp, 0xF0
0000790c663d97be  pop r11
0000790c663d97c0  pop r10
0000790c663d97c2  pop r9
0000790c663d97c4  pop r8
0000790c663d97c6  pop rsi
0000790c663d97c7  pop rdi
0000790c663d97c8  pop rdx
0000790c663d97c9  pop rcx
0000790c663d97ca  pop rax
0000790c663d97cb  add rsp, 0x08
0000790c663d97cf  jmp 0x0000790C663D628A
0000790c663d97d4  sub rsp, 0x08
0000790c663d97d8  push rax
0000790c663d97d9  push rcx
0000790c663d97da  push rdx
0000790c663d97db  push rdi
0000790c663d97dc  push rsi
0000790c663d97dd  push r8
0000790c663d97df  push r9
0000790c663d97e1  push r10
0000790c663d97e3  push r11
0000790c663d97e5  sub rsp, 0xF0
0000790c663d97ec  vmovaps [rsp], xmm0
0000790c663d97f1  vmovaps [rsp+0x10], xmm1
0000790c663d97f7  vmovaps [rsp+0x20], xmm2
0000790c663d97fd  vmovaps [rsp+0x30], xmm3
0000790c663d9803  vmovaps [rsp+0x40], xmm4
0000790c663d9809  vmovaps [rsp+0x50], xmm5
0000790c663d980f  vmovaps [rsp+0x60], xmm6
0000790c663d9815  vmovaps [rsp+0x70], xmm7
0000790c663d981b  vmovaps [rsp+0x80], xmm8
0000790c663d9824  vmovaps [rsp+0x90], xmm9
0000790c663d982d  vmovaps [rsp+0xA0], xmm10
0000790c663d9836  vmovaps [rsp+0xB0], xmm11
0000790c663d983f  vmovaps [rsp+0xC0], xmm12
0000790c663d9848  vmovaps [rsp+0xD0], xmm14
0000790c663d9851  vmovaps [rsp+0xE0], xmm15
0000790c663d985a  sub rsp, 0x30
0000790c663d985e  movaps [rsp], xmm13
0000790c663d9863  movaps [rsp+0x10], xmm15
0000790c663d9869  movaps [rsp+0x20], xmm9
0000790c663d986f  lea rdi, [rsp]
0000790c663d9873  mov esi, 0x00
0000790c663d9878  mov rax, 0x631C1759F530
0000790c663d9882  call rax
0000790c663d9884  movaps xmm13, [rsp]
0000790c663d9889  add rsp, 0x30
0000790c663d988d  vmovaps xmm0, [rsp]
0000790c663d9892  vmovaps xmm1, [rsp+0x10]
0000790c663d9898  vmovaps xmm2, [rsp+0x20]
0000790c663d989e  vmovaps xmm3, [rsp+0x30]
0000790c663d98a4  vmovaps xmm4, [rsp+0x40]
0000790c663d98aa  vmovaps xmm5, [rsp+0x50]
0000790c663d98b0  vmovaps xmm6, [rsp+0x60]
0000790c663d98b6  vmovaps xmm7, [rsp+0x70]
0000790c663d98bc  vmovaps xmm8, [rsp+0x80]
0000790c663d98c5  vmovaps xmm9, [rsp+0x90]
0000790c663d98ce  vmovaps xmm10, [rsp+0xA0]
0000790c663d98d7  vmovaps xmm11, [rsp+0xB0]
0000790c663d98e0  vmovaps xmm12, [rsp+0xC0]
0000790c663d98e9  vmovaps xmm14, [rsp+0xD0]
0000790c663d98f2  vmovaps xmm15, [rsp+0xE0]
0000790c663d98fb  add rsp, 0xF0
0000790c663d9902  pop r11
0000790c663d9904  pop r10
0000790c663d9906  pop r9
0000790c663d9908  pop r8
0000790c663d990a  pop rsi
0000790c663d990b  pop rdi
0000790c663d990c  pop rdx
0000790c663d990d  pop rcx
0000790c663d990e  pop rax
0000790c663d990f  add rsp, 0x08
0000790c663d9913  jmp 0x0000790C663D62A5
0000790c663d9918  sub rsp, 0x08
0000790c663d991c  push rax
0000790c663d991d  push rcx
0000790c663d991e  push rdx
0000790c663d991f  push rdi
0000790c663d9920  push rsi
0000790c663d9921  push r8
0000790c663d9923  push r9
0000790c663d9925  push r10
0000790c663d9927  push r11
0000790c663d9929  sub rsp, 0xF0
0000790c663d9930  vmovaps [rsp], xmm0
0000790c663d9935  vmovaps [rsp+0x10], xmm1
0000790c663d993b  vmovaps [rsp+0x20], xmm2
0000790c663d9941  vmovaps [rsp+0x30], xmm3
0000790c663d9947  vmovaps [rsp+0x40], xmm4
0000790c663d994d  vmovaps [rsp+0x50], xmm5
0000790c663d9953  vmovaps [rsp+0x60], xmm6
0000790c663d9959  vmovaps [rsp+0x70], xmm7
0000790c663d995f  vmovaps [rsp+0x80], xmm8
0000790c663d9968  vmovaps [rsp+0x90], xmm9
0000790c663d9971  vmovaps [rsp+0xA0], xmm10
0000790c663d997a  vmovaps [rsp+0xB0], xmm11
0000790c663d9983  vmovaps [rsp+0xC0], xmm12
0000790c663d998c  vmovaps [rsp+0xD0], xmm13
0000790c663d9995  vmovaps [rsp+0xE0], xmm14
0000790c663d999e  sub rsp, 0x30
0000790c663d99a2  movaps [rsp], xmm15
0000790c663d99a7  movaps [rsp+0x10], xmm1
0000790c663d99ac  movaps [rsp+0x20], xmm5
0000790c663d99b1  lea rdi, [rsp]
0000790c663d99b5  mov esi, 0x00
0000790c663d99ba  mov rax, 0x631C1759F530
0000790c663d99c4  call rax
0000790c663d99c6  movaps xmm15, [rsp]
0000790c663d99cb  add rsp, 0x30
0000790c663d99cf  vmovaps xmm0, [rsp]
0000790c663d99d4  vmovaps xmm1, [rsp+0x10]
0000790c663d99da  vmovaps xmm2, [rsp+0x20]
0000790c663d99e0  vmovaps xmm3, [rsp+0x30]
0000790c663d99e6  vmovaps xmm4, [rsp+0x40]
0000790c663d99ec  vmovaps xmm5, [rsp+0x50]
0000790c663d99f2  vmovaps xmm6, [rsp+0x60]
0000790c663d99f8  vmovaps xmm7, [rsp+0x70]
0000790c663d99fe  vmovaps xmm8, [rsp+0x80]
0000790c663d9a07  vmovaps xmm9, [rsp+0x90]
0000790c663d9a10  vmovaps xmm10, [rsp+0xA0]
0000790c663d9a19  vmovaps xmm11, [rsp+0xB0]
0000790c663d9a22  vmovaps xmm12, [rsp+0xC0]
0000790c663d9a2b  vmovaps xmm13, [rsp+0xD0]
0000790c663d9a34  vmovaps xmm14, [rsp+0xE0]
0000790c663d9a3d  add rsp, 0xF0
0000790c663d9a44  pop r11
0000790c663d9a46  pop r10
0000790c663d9a48  pop r9
0000790c663d9a4a  pop r8
0000790c663d9a4c  pop rsi
0000790c663d9a4d  pop rdi
0000790c663d9a4e  pop rdx
0000790c663d9a4f  pop rcx
0000790c663d9a50  pop rax
0000790c663d9a51  add rsp, 0x08
0000790c663d9a55  jmp 0x0000790C663D62C0
0000790c663d9a5a  call 0x0000790C662D64F0
0000790c663d9a5f  jmp 0x0000790C663D631B
0000790c663d9a64  sub rsp, 0x08
0000790c663d9a68  push rax
0000790c663d9a69  push rcx
0000790c663d9a6a  push rdx
0000790c663d9a6b  push rdi
0000790c663d9a6c  push rsi
0000790c663d9a6d  push r8
0000790c663d9a6f  push r9
0000790c663d9a71  push r10
0000790c663d9a73  push r11
0000790c663d9a75  sub rsp, 0xF0
0000790c663d9a7c  vmovaps [rsp], xmm0
0000790c663d9a81  vmovaps [rsp+0x10], xmm1
0000790c663d9a87  vmovaps [rsp+0x20], xmm2
0000790c663d9a8d  vmovaps [rsp+0x30], xmm3
0000790c663d9a93  vmovaps [rsp+0x40], xmm4
0000790c663d9a99  vmovaps [rsp+0x50], xmm5
0000790c663d9a9f  vmovaps [rsp+0x60], xmm6
0000790c663d9aa5  vmovaps [rsp+0x70], xmm7
0000790c663d9aab  vmovaps [rsp+0x80], xmm8
0000790c663d9ab4  vmovaps [rsp+0x90], xmm10
0000790c663d9abd  vmovaps [rsp+0xA0], xmm11
0000790c663d9ac6  vmovaps [rsp+0xB0], xmm12
0000790c663d9acf  vmovaps [rsp+0xC0], xmm13
0000790c663d9ad8  vmovaps [rsp+0xD0], xmm14
0000790c663d9ae1  vmovaps [rsp+0xE0], xmm15
0000790c663d9aea  sub rsp, 0x30
0000790c663d9aee  movaps [rsp], xmm9
0000790c663d9af3  movaps [rsp+0x10], xmm8
0000790c663d9af9  movaps [rsp+0x20], xmm11
0000790c663d9aff  lea rdi, [rsp]
0000790c663d9b03  mov esi, 0x00
0000790c663d9b08  mov rax, 0x631C1759F530
0000790c663d9b12  call rax
0000790c663d9b14  movaps xmm9, [rsp]
0000790c663d9b19  add rsp, 0x30
0000790c663d9b1d  vmovaps xmm0, [rsp]
0000790c663d9b22  vmovaps xmm1, [rsp+0x10]
0000790c663d9b28  vmovaps xmm2, [rsp+0x20]
0000790c663d9b2e  vmovaps xmm3, [rsp+0x30]
0000790c663d9b34  vmovaps xmm4, [rsp+0x40]
0000790c663d9b3a  vmovaps xmm5, [rsp+0x50]
0000790c663d9b40  vmovaps xmm6, [rsp+0x60]
0000790c663d9b46  vmovaps xmm7, [rsp+0x70]
0000790c663d9b4c  vmovaps xmm8, [rsp+0x80]
0000790c663d9b55  vmovaps xmm10, [rsp+0x90]
0000790c663d9b5e  vmovaps xmm11, [rsp+0xA0]
0000790c663d9b67  vmovaps xmm12, [rsp+0xB0]
0000790c663d9b70  vmovaps xmm13, [rsp+0xC0]
0000790c663d9b79  vmovaps xmm14, [rsp+0xD0]
0000790c663d9b82  vmovaps xmm15, [rsp+0xE0]
0000790c663d9b8b  add rsp, 0xF0
0000790c663d9b92  pop r11
0000790c663d9b94  pop r10
0000790c663d9b96  pop r9
0000790c663d9b98  pop r8
0000790c663d9b9a  pop rsi
0000790c663d9b9b  pop rdi
0000790c663d9b9c  pop rdx
0000790c663d9b9d  pop rcx
0000790c663d9b9e  pop rax
0000790c663d9b9f  add rsp, 0x08
0000790c663d9ba3  jmp 0x0000790C663D6352
0000790c663d9ba8  sub rsp, 0x08
0000790c663d9bac  push rax
0000790c663d9bad  push rcx
0000790c663d9bae  push rdx
0000790c663d9baf  push rdi
0000790c663d9bb0  push rsi
0000790c663d9bb1  push r8
0000790c663d9bb3  push r9
0000790c663d9bb5  push r10
0000790c663d9bb7  push r11
0000790c663d9bb9  sub rsp, 0xF0
0000790c663d9bc0  vmovaps [rsp], xmm0
0000790c663d9bc5  vmovaps [rsp+0x10], xmm1
0000790c663d9bcb  vmovaps [rsp+0x20], xmm2
0000790c663d9bd1  vmovaps [rsp+0x30], xmm3
0000790c663d9bd7  vmovaps [rsp+0x40], xmm4
0000790c663d9bdd  vmovaps [rsp+0x50], xmm5
0000790c663d9be3  vmovaps [rsp+0x60], xmm6
0000790c663d9be9  vmovaps [rsp+0x70], xmm7
0000790c663d9bef  vmovaps [rsp+0x80], xmm8
0000790c663d9bf8  vmovaps [rsp+0x90], xmm9
0000790c663d9c01  vmovaps [rsp+0xA0], xmm10
0000790c663d9c0a  vmovaps [rsp+0xB0], xmm12
0000790c663d9c13  vmovaps [rsp+0xC0], xmm13
0000790c663d9c1c  vmovaps [rsp+0xD0], xmm14
0000790c663d9c25  vmovaps [rsp+0xE0], xmm15
0000790c663d9c2e  sub rsp, 0x30
0000790c663d9c32  movaps [rsp], xmm11
0000790c663d9c37  movaps [rsp+0x10], xmm10
0000790c663d9c3d  movaps [rsp+0x20], xmm6
0000790c663d9c42  lea rdi, [rsp]
0000790c663d9c46  mov esi, 0x00
0000790c663d9c4b  mov rax, 0x631C1759F530
0000790c663d9c55  call rax
0000790c663d9c57  movaps xmm11, [rsp]
0000790c663d9c5c  add rsp, 0x30
0000790c663d9c60  vmovaps xmm0, [rsp]
0000790c663d9c65  vmovaps xmm1, [rsp+0x10]
0000790c663d9c6b  vmovaps xmm2, [rsp+0x20]
0000790c663d9c71  vmovaps xmm3, [rsp+0x30]
0000790c663d9c77  vmovaps xmm4, [rsp+0x40]
0000790c663d9c7d  vmovaps xmm5, [rsp+0x50]
0000790c663d9c83  vmovaps xmm6, [rsp+0x60]
0000790c663d9c89  vmovaps xmm7, [rsp+0x70]
0000790c663d9c8f  vmovaps xmm8, [rsp+0x80]
0000790c663d9c98  vmovaps xmm9, [rsp+0x90]
0000790c663d9ca1  vmovaps xmm10, [rsp+0xA0]
0000790c663d9caa  vmovaps xmm12, [rsp+0xB0]
0000790c663d9cb3  vmovaps xmm13, [rsp+0xC0]
0000790c663d9cbc  vmovaps xmm14, [rsp+0xD0]
0000790c663d9cc5  vmovaps xmm15, [rsp+0xE0]
0000790c663d9cce  add rsp, 0xF0
0000790c663d9cd5  pop r11
0000790c663d9cd7  pop r10
0000790c663d9cd9  pop r9
0000790c663d9cdb  pop r8
0000790c663d9cdd  pop rsi
0000790c663d9cde  pop rdi
0000790c663d9cdf  pop rdx
0000790c663d9ce0  pop rcx
0000790c663d9ce1  pop rax
0000790c663d9ce2  add rsp, 0x08
0000790c663d9ce6  jmp 0x0000790C663D636D
0000790c663d9ceb  sub rsp, 0x08
0000790c663d9cef  push rax
0000790c663d9cf0  push rcx
0000790c663d9cf1  push rdx
0000790c663d9cf2  push rdi
0000790c663d9cf3  push rsi
0000790c663d9cf4  push r8
0000790c663d9cf6  push r9
0000790c663d9cf8  push r10
0000790c663d9cfa  push r11
0000790c663d9cfc  sub rsp, 0xF0
0000790c663d9d03  vmovaps [rsp], xmm0
0000790c663d9d08  vmovaps [rsp+0x10], xmm1
0000790c663d9d0e  vmovaps [rsp+0x20], xmm2
0000790c663d9d14  vmovaps [rsp+0x30], xmm3
0000790c663d9d1a  vmovaps [rsp+0x40], xmm4
0000790c663d9d20  vmovaps [rsp+0x50], xmm5
0000790c663d9d26  vmovaps [rsp+0x60], xmm6
0000790c663d9d2c  vmovaps [rsp+0x70], xmm7
0000790c663d9d32  vmovaps [rsp+0x80], xmm8
0000790c663d9d3b  vmovaps [rsp+0x90], xmm9
0000790c663d9d44  vmovaps [rsp+0xA0], xmm11
0000790c663d9d4d  vmovaps [rsp+0xB0], xmm12
0000790c663d9d56  vmovaps [rsp+0xC0], xmm13
0000790c663d9d5f  vmovaps [rsp+0xD0], xmm14
0000790c663d9d68  vmovaps [rsp+0xE0], xmm15
0000790c663d9d71  sub rsp, 0x30
0000790c663d9d75  movaps [rsp], xmm10
0000790c663d9d7a  movaps [rsp+0x10], xmm14
0000790c663d9d80  movaps [rsp+0x20], xmm4
0000790c663d9d85  lea rdi, [rsp]
0000790c663d9d89  mov esi, 0x00
0000790c663d9d8e  mov rax, 0x631C1759F530
0000790c663d9d98  call rax
0000790c663d9d9a  movaps xmm10, [rsp]
0000790c663d9d9f  add rsp, 0x30
0000790c663d9da3  vmovaps xmm0, [rsp]
0000790c663d9da8  vmovaps xmm1, [rsp+0x10]
0000790c663d9dae  vmovaps xmm2, [rsp+0x20]
0000790c663d9db4  vmovaps xmm3, [rsp+0x30]
0000790c663d9dba  vmovaps xmm4, [rsp+0x40]
0000790c663d9dc0  vmovaps xmm5, [rsp+0x50]
0000790c663d9dc6  vmovaps xmm6, [rsp+0x60]
0000790c663d9dcc  vmovaps xmm7, [rsp+0x70]
0000790c663d9dd2  vmovaps xmm8, [rsp+0x80]
0000790c663d9ddb  vmovaps xmm9, [rsp+0x90]
0000790c663d9de4  vmovaps xmm11, [rsp+0xA0]
0000790c663d9ded  vmovaps xmm12, [rsp+0xB0]
0000790c663d9df6  vmovaps xmm13, [rsp+0xC0]
0000790c663d9dff  vmovaps xmm14, [rsp+0xD0]
0000790c663d9e08  vmovaps xmm15, [rsp+0xE0]
0000790c663d9e11  add rsp, 0xF0
0000790c663d9e18  pop r11
0000790c663d9e1a  pop r10
0000790c663d9e1c  pop r9
0000790c663d9e1e  pop r8
0000790c663d9e20  pop rsi
0000790c663d9e21  pop rdi
0000790c663d9e22  pop rdx
0000790c663d9e23  pop rcx
0000790c663d9e24  pop rax
0000790c663d9e25  add rsp, 0x08
0000790c663d9e29  jmp 0x0000790C663D6388
0000790c663d9e2e  sub rsp, 0x08
0000790c663d9e32  push rax
0000790c663d9e33  push rcx
0000790c663d9e34  push rdx
0000790c663d9e35  push rdi
0000790c663d9e36  push rsi
0000790c663d9e37  push r8
0000790c663d9e39  push r9
0000790c663d9e3b  push r10
0000790c663d9e3d  push r11
0000790c663d9e3f  sub rsp, 0xF0
0000790c663d9e46  vmovaps [rsp], xmm0
0000790c663d9e4b  vmovaps [rsp+0x10], xmm1
0000790c663d9e51  vmovaps [rsp+0x20], xmm2
0000790c663d9e57  vmovaps [rsp+0x30], xmm3
0000790c663d9e5d  vmovaps [rsp+0x40], xmm4
0000790c663d9e63  vmovaps [rsp+0x50], xmm5
0000790c663d9e69  vmovaps [rsp+0x60], xmm6
0000790c663d9e6f  vmovaps [rsp+0x70], xmm7
0000790c663d9e75  vmovaps [rsp+0x80], xmm9
0000790c663d9e7e  vmovaps [rsp+0x90], xmm10
0000790c663d9e87  vmovaps [rsp+0xA0], xmm11
0000790c663d9e90  vmovaps [rsp+0xB0], xmm12
0000790c663d9e99  vmovaps [rsp+0xC0], xmm13
0000790c663d9ea2  vmovaps [rsp+0xD0], xmm14
0000790c663d9eab  vmovaps [rsp+0xE0], xmm15
0000790c663d9eb4  sub rsp, 0x30
0000790c663d9eb8  movaps [rsp], xmm8
0000790c663d9ebd  movaps [rsp+0x10], xmm1
0000790c663d9ec2  movaps [rsp+0x20], xmm14
0000790c663d9ec8  lea rdi, [rsp]
0000790c663d9ecc  mov esi, 0x00
0000790c663d9ed1  mov rax, 0x631C1759F530
0000790c663d9edb  call rax
0000790c663d9edd  movaps xmm8, [rsp]
0000790c663d9ee2  add rsp, 0x30
0000790c663d9ee6  vmovaps xmm0, [rsp]
0000790c663d9eeb  vmovaps xmm1, [rsp+0x10]
0000790c663d9ef1  vmovaps xmm2, [rsp+0x20]
0000790c663d9ef7  vmovaps xmm3, [rsp+0x30]
0000790c663d9efd  vmovaps xmm4, [rsp+0x40]
0000790c663d9f03  vmovaps xmm5, [rsp+0x50]
0000790c663d9f09  vmovaps xmm6, [rsp+0x60]
0000790c663d9f0f  vmovaps xmm7, [rsp+0x70]
0000790c663d9f15  vmovaps xmm9, [rsp+0x80]
0000790c663d9f1e  vmovaps xmm10, [rsp+0x90]
0000790c663d9f27  vmovaps xmm11, [rsp+0xA0]
0000790c663d9f30  vmovaps xmm12, [rsp+0xB0]
0000790c663d9f39  vmovaps xmm13, [rsp+0xC0]
0000790c663d9f42  vmovaps xmm14, [rsp+0xD0]
0000790c663d9f4b  vmovaps xmm15, [rsp+0xE0]
0000790c663d9f54  add rsp, 0xF0
0000790c663d9f5b  pop r11
0000790c663d9f5d  pop r10
0000790c663d9f5f  pop r9
0000790c663d9f61  pop r8
0000790c663d9f63  pop rsi
0000790c663d9f64  pop rdi
0000790c663d9f65  pop rdx
0000790c663d9f66  pop rcx
0000790c663d9f67  pop rax
0000790c663d9f68  add rsp, 0x08
0000790c663d9f6c  jmp 0x0000790C663D63AE
0000790c663d9f71  sub rsp, 0x08
0000790c663d9f75  push rax
0000790c663d9f76  push rcx
0000790c663d9f77  push rdx
0000790c663d9f78  push rdi
0000790c663d9f79  push rsi
0000790c663d9f7a  push r8
0000790c663d9f7c  push r9
0000790c663d9f7e  push r10
0000790c663d9f80  push r11
0000790c663d9f82  sub rsp, 0xF0
0000790c663d9f89  vmovaps [rsp], xmm0
0000790c663d9f8e  vmovaps [rsp+0x10], xmm1
0000790c663d9f94  vmovaps [rsp+0x20], xmm2
0000790c663d9f9a  vmovaps [rsp+0x30], xmm3
0000790c663d9fa0  vmovaps [rsp+0x40], xmm4
0000790c663d9fa6  vmovaps [rsp+0x50], xmm5
0000790c663d9fac  vmovaps [rsp+0x60], xmm7
0000790c663d9fb2  vmovaps [rsp+0x70], xmm8
0000790c663d9fb8  vmovaps [rsp+0x80], xmm9
0000790c663d9fc1  vmovaps [rsp+0x90], xmm10
0000790c663d9fca  vmovaps [rsp+0xA0], xmm11
0000790c663d9fd3  vmovaps [rsp+0xB0], xmm12
0000790c663d9fdc  vmovaps [rsp+0xC0], xmm13
0000790c663d9fe5  vmovaps [rsp+0xD0], xmm14
0000790c663d9fee  vmovaps [rsp+0xE0], xmm15
0000790c663d9ff7  sub rsp, 0x30
0000790c663d9ffb  movaps [rsp], xmm6
0000790c663d9fff  movaps [rsp+0x10], xmm1
0000790c663da004  movaps [rsp+0x20], xmm14
0000790c663da00a  lea rdi, [rsp]
0000790c663da00e  mov esi, 0x00
0000790c663da013  mov rax, 0x631C1759F530
0000790c663da01d  call rax
0000790c663da01f  movaps xmm6, [rsp]
0000790c663da023  add rsp, 0x30
0000790c663da027  vmovaps xmm0, [rsp]
0000790c663da02c  vmovaps xmm1, [rsp+0x10]
0000790c663da032  vmovaps xmm2, [rsp+0x20]
0000790c663da038  vmovaps xmm3, [rsp+0x30]
0000790c663da03e  vmovaps xmm4, [rsp+0x40]
0000790c663da044  vmovaps xmm5, [rsp+0x50]
0000790c663da04a  vmovaps xmm7, [rsp+0x60]
0000790c663da050  vmovaps xmm8, [rsp+0x70]
0000790c663da056  vmovaps xmm9, [rsp+0x80]
0000790c663da05f  vmovaps xmm10, [rsp+0x90]
0000790c663da068  vmovaps xmm11, [rsp+0xA0]
0000790c663da071  vmovaps xmm12, [rsp+0xB0]
0000790c663da07a  vmovaps xmm13, [rsp+0xC0]
0000790c663da083  vmovaps xmm14, [rsp+0xD0]
0000790c663da08c  vmovaps xmm15, [rsp+0xE0]
0000790c663da095  add rsp, 0xF0
0000790c663da09c  pop r11
0000790c663da09e  pop r10
0000790c663da0a0  pop r9
0000790c663da0a2  pop r8
0000790c663da0a4  pop rsi
0000790c663da0a5  pop rdi
0000790c663da0a6  pop rdx
0000790c663da0a7  pop rcx
0000790c663da0a8  pop rax
0000790c663da0a9  add rsp, 0x08
0000790c663da0ad  jmp 0x0000790C663D63DA
0000790c663da0b2  sub rsp, 0x08
0000790c663da0b6  push rax
0000790c663da0b7  push rcx
0000790c663da0b8  push rdx
0000790c663da0b9  push rdi
0000790c663da0ba  push rsi
0000790c663da0bb  push r8
0000790c663da0bd  push r9
0000790c663da0bf  push r10
0000790c663da0c1  push r11
0000790c663da0c3  sub rsp, 0xF0
0000790c663da0ca  vmovaps [rsp], xmm0
0000790c663da0cf  vmovaps [rsp+0x10], xmm1
0000790c663da0d5  vmovaps [rsp+0x20], xmm2
0000790c663da0db  vmovaps [rsp+0x30], xmm3
0000790c663da0e1  vmovaps [rsp+0x40], xmm4
0000790c663da0e7  vmovaps [rsp+0x50], xmm5
0000790c663da0ed  vmovaps [rsp+0x60], xmm6
0000790c663da0f3  vmovaps [rsp+0x70], xmm7
0000790c663da0f9  vmovaps [rsp+0x80], xmm8
0000790c663da102  vmovaps [rsp+0x90], xmm9
0000790c663da10b  vmovaps [rsp+0xA0], xmm10
0000790c663da114  vmovaps [rsp+0xB0], xmm11
0000790c663da11d  vmovaps [rsp+0xC0], xmm12
0000790c663da126  vmovaps [rsp+0xD0], xmm13
0000790c663da12f  vmovaps [rsp+0xE0], xmm15
0000790c663da138  sub rsp, 0x30
0000790c663da13c  movaps [rsp], xmm14
0000790c663da141  movaps [rsp+0x10], xmm12
0000790c663da147  movaps [rsp+0x20], xmm1
0000790c663da14c  lea rdi, [rsp]
0000790c663da150  mov esi, 0x00
0000790c663da155  mov rax, 0x631C1759F530
0000790c663da15f  call rax
0000790c663da161  movaps xmm14, [rsp]
0000790c663da166  add rsp, 0x30
0000790c663da16a  vmovaps xmm0, [rsp]
0000790c663da16f  vmovaps xmm1, [rsp+0x10]
0000790c663da175  vmovaps xmm2, [rsp+0x20]
0000790c663da17b  vmovaps xmm3, [rsp+0x30]
0000790c663da181  vmovaps xmm4, [rsp+0x40]
0000790c663da187  vmovaps xmm5, [rsp+0x50]
0000790c663da18d  vmovaps xmm6, [rsp+0x60]
0000790c663da193  vmovaps xmm7, [rsp+0x70]
0000790c663da199  vmovaps xmm8, [rsp+0x80]
0000790c663da1a2  vmovaps xmm9, [rsp+0x90]
0000790c663da1ab  vmovaps xmm10, [rsp+0xA0]
0000790c663da1b4  vmovaps xmm11, [rsp+0xB0]
0000790c663da1bd  vmovaps xmm12, [rsp+0xC0]
0000790c663da1c6  vmovaps xmm13, [rsp+0xD0]
0000790c663da1cf  vmovaps xmm15, [rsp+0xE0]
0000790c663da1d8  add rsp, 0xF0
0000790c663da1df  pop r11
0000790c663da1e1  pop r10
0000790c663da1e3  pop r9
0000790c663da1e5  pop r8
0000790c663da1e7  pop rsi
0000790c663da1e8  pop rdi
0000790c663da1e9  pop rdx
0000790c663da1ea  pop rcx
0000790c663da1eb  pop rax
0000790c663da1ec  add rsp, 0x08
0000790c663da1f0  jmp 0x0000790C663D6400
0000790c663da1f5  sub rsp, 0x08
0000790c663da1f9  push rax
0000790c663da1fa  push rcx
0000790c663da1fb  push rdx
0000790c663da1fc  push rdi
0000790c663da1fd  push rsi
0000790c663da1fe  push r8
0000790c663da200  push r9
0000790c663da202  push r10
0000790c663da204  push r11
0000790c663da206  sub rsp, 0xF0
0000790c663da20d  vmovaps [rsp], xmm0
0000790c663da212  vmovaps [rsp+0x10], xmm2
0000790c663da218  vmovaps [rsp+0x20], xmm3
0000790c663da21e  vmovaps [rsp+0x30], xmm4
0000790c663da224  vmovaps [rsp+0x40], xmm5
0000790c663da22a  vmovaps [rsp+0x50], xmm6
0000790c663da230  vmovaps [rsp+0x60], xmm7
0000790c663da236  vmovaps [rsp+0x70], xmm8
0000790c663da23c  vmovaps [rsp+0x80], xmm9
0000790c663da245  vmovaps [rsp+0x90], xmm10
0000790c663da24e  vmovaps [rsp+0xA0], xmm11
0000790c663da257  vmovaps [rsp+0xB0], xmm12
0000790c663da260  vmovaps [rsp+0xC0], xmm13
0000790c663da269  vmovaps [rsp+0xD0], xmm14
0000790c663da272  vmovaps [rsp+0xE0], xmm15
0000790c663da27b  sub rsp, 0x30
0000790c663da27f  movaps [rsp], xmm1
0000790c663da283  movaps [rsp+0x10], xmm13
0000790c663da289  movaps [rsp+0x20], xmm9
0000790c663da28f  lea rdi, [rsp]
0000790c663da293  mov esi, 0x00
0000790c663da298  mov rax, 0x631C1759F530
0000790c663da2a2  call rax
0000790c663da2a4  movaps xmm1, [rsp]
0000790c663da2a8  add rsp, 0x30
0000790c663da2ac  vmovaps xmm0, [rsp]
0000790c663da2b1  vmovaps xmm2, [rsp+0x10]
0000790c663da2b7  vmovaps xmm3, [rsp+0x20]
0000790c663da2bd  vmovaps xmm4, [rsp+0x30]
0000790c663da2c3  vmovaps xmm5, [rsp+0x40]
0000790c663da2c9  vmovaps xmm6, [rsp+0x50]
0000790c663da2cf  vmovaps xmm7, [rsp+0x60]
0000790c663da2d5  vmovaps xmm8, [rsp+0x70]
0000790c663da2db  vmovaps xmm9, [rsp+0x80]
0000790c663da2e4  vmovaps xmm10, [rsp+0x90]
0000790c663da2ed  vmovaps xmm11, [rsp+0xA0]
0000790c663da2f6  vmovaps xmm12, [rsp+0xB0]
0000790c663da2ff  vmovaps xmm13, [rsp+0xC0]
0000790c663da308  vmovaps xmm14, [rsp+0xD0]
0000790c663da311  vmovaps xmm15, [rsp+0xE0]
0000790c663da31a  add rsp, 0xF0
0000790c663da321  pop r11
0000790c663da323  pop r10
0000790c663da325  pop r9
0000790c663da327  pop r8
0000790c663da329  pop rsi
0000790c663da32a  pop rdi
0000790c663da32b  pop rdx
0000790c663da32c  pop rcx
0000790c663da32d  pop rax
0000790c663da32e  add rsp, 0x08
0000790c663da332  jmp 0x0000790C663D641A
0000790c663da337  sub rsp, 0x08
0000790c663da33b  push rax
0000790c663da33c  push rcx
0000790c663da33d  push rdx
0000790c663da33e  push rdi
0000790c663da33f  push rsi
0000790c663da340  push r8
0000790c663da342  push r9
0000790c663da344  push r10
0000790c663da346  push r11
0000790c663da348  sub rsp, 0xF0
0000790c663da34f  vmovaps [rsp], xmm0
0000790c663da354  vmovaps [rsp+0x10], xmm1
0000790c663da35a  vmovaps [rsp+0x20], xmm2
0000790c663da360  vmovaps [rsp+0x30], xmm3
0000790c663da366  vmovaps [rsp+0x40], xmm4
0000790c663da36c  vmovaps [rsp+0x50], xmm5
0000790c663da372  vmovaps [rsp+0x60], xmm6
0000790c663da378  vmovaps [rsp+0x70], xmm7
0000790c663da37e  vmovaps [rsp+0x80], xmm8
0000790c663da387  vmovaps [rsp+0x90], xmm9
0000790c663da390  vmovaps [rsp+0xA0], xmm10
0000790c663da399  vmovaps [rsp+0xB0], xmm11
0000790c663da3a2  vmovaps [rsp+0xC0], xmm13
0000790c663da3ab  vmovaps [rsp+0xD0], xmm14
0000790c663da3b4  vmovaps [rsp+0xE0], xmm15
0000790c663da3bd  sub rsp, 0x30
0000790c663da3c1  movaps [rsp], xmm12
0000790c663da3c6  movaps [rsp+0x10], xmm7
0000790c663da3cb  movaps [rsp+0x20], xmm13
0000790c663da3d1  lea rdi, [rsp]
0000790c663da3d5  mov esi, 0x00
0000790c663da3da  mov rax, 0x631C1759F530
0000790c663da3e4  call rax
0000790c663da3e6  movaps xmm12, [rsp]
0000790c663da3eb  add rsp, 0x30
0000790c663da3ef  vmovaps xmm0, [rsp]
0000790c663da3f4  vmovaps xmm1, [rsp+0x10]
0000790c663da3fa  vmovaps xmm2, [rsp+0x20]
0000790c663da400  vmovaps xmm3, [rsp+0x30]
0000790c663da406  vmovaps xmm4, [rsp+0x40]
0000790c663da40c  vmovaps xmm5, [rsp+0x50]
0000790c663da412  vmovaps xmm6, [rsp+0x60]
0000790c663da418  vmovaps xmm7, [rsp+0x70]
0000790c663da41e  vmovaps xmm8, [rsp+0x80]
0000790c663da427  vmovaps xmm9, [rsp+0x90]
0000790c663da430  vmovaps xmm10, [rsp+0xA0]
0000790c663da439  vmovaps xmm11, [rsp+0xB0]
0000790c663da442  vmovaps xmm13, [rsp+0xC0]
0000790c663da44b  vmovaps xmm14, [rsp+0xD0]
0000790c663da454  vmovaps xmm15, [rsp+0xE0]
0000790c663da45d  add rsp, 0xF0
0000790c663da464  pop r11
0000790c663da466  pop r10
0000790c663da468  pop r9
0000790c663da46a  pop r8
0000790c663da46c  pop rsi
0000790c663da46d  pop rdi
0000790c663da46e  pop rdx
0000790c663da46f  pop rcx
0000790c663da470  pop rax
0000790c663da471  add rsp, 0x08
0000790c663da475  jmp 0x0000790C663D6441
0000790c663da47a  sub rsp, 0x08
0000790c663da47e  push rax
0000790c663da47f  push rcx
0000790c663da480  push rdx
0000790c663da481  push rdi
0000790c663da482  push rsi
0000790c663da483  push r8
0000790c663da485  push r9
0000790c663da487  push r10
0000790c663da489  push r11
0000790c663da48b  sub rsp, 0xF0
0000790c663da492  vmovaps [rsp], xmm0
0000790c663da497  vmovaps [rsp+0x10], xmm1
0000790c663da49d  vmovaps [rsp+0x20], xmm2
0000790c663da4a3  vmovaps [rsp+0x30], xmm3
0000790c663da4a9  vmovaps [rsp+0x40], xmm4
0000790c663da4af  vmovaps [rsp+0x50], xmm5
0000790c663da4b5  vmovaps [rsp+0x60], xmm6
0000790c663da4bb  vmovaps [rsp+0x70], xmm7
0000790c663da4c1  vmovaps [rsp+0x80], xmm8
0000790c663da4ca  vmovaps [rsp+0x90], xmm9
0000790c663da4d3  vmovaps [rsp+0xA0], xmm10
0000790c663da4dc  vmovaps [rsp+0xB0], xmm11
0000790c663da4e5  vmovaps [rsp+0xC0], xmm12
0000790c663da4ee  vmovaps [rsp+0xD0], xmm14
0000790c663da4f7  vmovaps [rsp+0xE0], xmm15
0000790c663da500  sub rsp, 0x30
0000790c663da504  movaps [rsp], xmm13
0000790c663da509  movaps [rsp+0x10], xmm15
0000790c663da50f  movaps [rsp+0x20], xmm8
0000790c663da515  lea rdi, [rsp]
0000790c663da519  mov esi, 0x00
0000790c663da51e  mov rax, 0x631C1759F530
0000790c663da528  call rax
0000790c663da52a  movaps xmm13, [rsp]
0000790c663da52f  add rsp, 0x30
0000790c663da533  vmovaps xmm0, [rsp]
0000790c663da538  vmovaps xmm1, [rsp+0x10]
0000790c663da53e  vmovaps xmm2, [rsp+0x20]
0000790c663da544  vmovaps xmm3, [rsp+0x30]
0000790c663da54a  vmovaps xmm4, [rsp+0x40]
0000790c663da550  vmovaps xmm5, [rsp+0x50]
0000790c663da556  vmovaps xmm6, [rsp+0x60]
0000790c663da55c  vmovaps xmm7, [rsp+0x70]
0000790c663da562  vmovaps xmm8, [rsp+0x80]
0000790c663da56b  vmovaps xmm9, [rsp+0x90]
0000790c663da574  vmovaps xmm10, [rsp+0xA0]
0000790c663da57d  vmovaps xmm11, [rsp+0xB0]
0000790c663da586  vmovaps xmm12, [rsp+0xC0]
0000790c663da58f  vmovaps xmm14, [rsp+0xD0]
0000790c663da598  vmovaps xmm15, [rsp+0xE0]
0000790c663da5a1  add rsp, 0xF0
0000790c663da5a8  pop r11
0000790c663da5aa  pop r10
0000790c663da5ac  pop r9
0000790c663da5ae  pop r8
0000790c663da5b0  pop rsi
0000790c663da5b1  pop rdi
0000790c663da5b2  pop rdx
0000790c663da5b3  pop rcx
0000790c663da5b4  pop rax
0000790c663da5b5  add rsp, 0x08
0000790c663da5b9  jmp 0x0000790C663D645C
0000790c663da5be  sub rsp, 0x08
0000790c663da5c2  push rax
0000790c663da5c3  push rcx
0000790c663da5c4  push rdx
0000790c663da5c5  push rdi
0000790c663da5c6  push rsi
0000790c663da5c7  push r8
0000790c663da5c9  push r9
0000790c663da5cb  push r10
0000790c663da5cd  push r11
0000790c663da5cf  sub rsp, 0xF0
0000790c663da5d6  vmovaps [rsp], xmm0
0000790c663da5db  vmovaps [rsp+0x10], xmm1
0000790c663da5e1  vmovaps [rsp+0x20], xmm2
0000790c663da5e7  vmovaps [rsp+0x30], xmm3
0000790c663da5ed  vmovaps [rsp+0x40], xmm4
0000790c663da5f3  vmovaps [rsp+0x50], xmm5
0000790c663da5f9  vmovaps [rsp+0x60], xmm6
0000790c663da5ff  vmovaps [rsp+0x70], xmm7
0000790c663da605  vmovaps [rsp+0x80], xmm9
0000790c663da60e  vmovaps [rsp+0x90], xmm10
0000790c663da617  vmovaps [rsp+0xA0], xmm11
0000790c663da620  vmovaps [rsp+0xB0], xmm12
0000790c663da629  vmovaps [rsp+0xC0], xmm13
0000790c663da632  vmovaps [rsp+0xD0], xmm14
0000790c663da63b  vmovaps [rsp+0xE0], xmm15
0000790c663da644  sub rsp, 0x30
0000790c663da648  movaps [rsp], xmm8
0000790c663da64d  movaps [rsp+0x10], xmm15
0000790c663da653  movaps [rsp+0x20], xmm9
0000790c663da659  lea rdi, [rsp]
0000790c663da65d  mov esi, 0x00
0000790c663da662  mov rax, 0x631C1759F530
0000790c663da66c  call rax
0000790c663da66e  movaps xmm8, [rsp]
0000790c663da673  add rsp, 0x30
0000790c663da677  vmovaps xmm0, [rsp]
0000790c663da67c  vmovaps xmm1, [rsp+0x10]
0000790c663da682  vmovaps xmm2, [rsp+0x20]
0000790c663da688  vmovaps xmm3, [rsp+0x30]
0000790c663da68e  vmovaps xmm4, [rsp+0x40]
0000790c663da694  vmovaps xmm5, [rsp+0x50]
0000790c663da69a  vmovaps xmm6, [rsp+0x60]
0000790c663da6a0  vmovaps xmm7, [rsp+0x70]
0000790c663da6a6  vmovaps xmm9, [rsp+0x80]
0000790c663da6af  vmovaps xmm10, [rsp+0x90]
0000790c663da6b8  vmovaps xmm11, [rsp+0xA0]
0000790c663da6c1  vmovaps xmm12, [rsp+0xB0]
0000790c663da6ca  vmovaps xmm13, [rsp+0xC0]
0000790c663da6d3  vmovaps xmm14, [rsp+0xD0]
0000790c663da6dc  vmovaps xmm15, [rsp+0xE0]
0000790c663da6e5  add rsp, 0xF0
0000790c663da6ec  pop r11
0000790c663da6ee  pop r10
0000790c663da6f0  pop r9
0000790c663da6f2  pop r8
0000790c663da6f4  pop rsi
0000790c663da6f5  pop rdi
0000790c663da6f6  pop rdx
0000790c663da6f7  pop rcx
0000790c663da6f8  pop rax
0000790c663da6f9  add rsp, 0x08
0000790c663da6fd  jmp 0x0000790C663D648A
0000790c663da702  sub rsp, 0x08
0000790c663da706  push rax
0000790c663da707  push rcx
0000790c663da708  push rdx
0000790c663da709  push rdi
0000790c663da70a  push rsi
0000790c663da70b  push r8
0000790c663da70d  push r9
0000790c663da70f  push r10
0000790c663da711  push r11
0000790c663da713  sub rsp, 0xF0
0000790c663da71a  vmovaps [rsp], xmm0
0000790c663da71f  vmovaps [rsp+0x10], xmm1
0000790c663da725  vmovaps [rsp+0x20], xmm2
0000790c663da72b  vmovaps [rsp+0x30], xmm3
0000790c663da731  vmovaps [rsp+0x40], xmm4
0000790c663da737  vmovaps [rsp+0x50], xmm5
0000790c663da73d  vmovaps [rsp+0x60], xmm6
0000790c663da743  vmovaps [rsp+0x70], xmm7
0000790c663da749  vmovaps [rsp+0x80], xmm8
0000790c663da752  vmovaps [rsp+0x90], xmm9
0000790c663da75b  vmovaps [rsp+0xA0], xmm10
0000790c663da764  vmovaps [rsp+0xB0], xmm11
0000790c663da76d  vmovaps [rsp+0xC0], xmm12
0000790c663da776  vmovaps [rsp+0xD0], xmm13
0000790c663da77f  vmovaps [rsp+0xE0], xmm14
0000790c663da788  sub rsp, 0x30
0000790c663da78c  movaps [rsp], xmm15
0000790c663da791  movaps [rsp+0x10], xmm11
0000790c663da797  movaps [rsp+0x20], xmm6
0000790c663da79c  lea rdi, [rsp]
0000790c663da7a0  mov esi, 0x00
0000790c663da7a5  mov rax, 0x631C1759F530
0000790c663da7af  call rax
0000790c663da7b1  movaps xmm15, [rsp]
0000790c663da7b6  add rsp, 0x30
0000790c663da7ba  vmovaps xmm0, [rsp]
0000790c663da7bf  vmovaps xmm1, [rsp+0x10]
0000790c663da7c5  vmovaps xmm2, [rsp+0x20]
0000790c663da7cb  vmovaps xmm3, [rsp+0x30]
0000790c663da7d1  vmovaps xmm4, [rsp+0x40]
0000790c663da7d7  vmovaps xmm5, [rsp+0x50]
0000790c663da7dd  vmovaps xmm6, [rsp+0x60]
0000790c663da7e3  vmovaps xmm7, [rsp+0x70]
0000790c663da7e9  vmovaps xmm8, [rsp+0x80]
0000790c663da7f2  vmovaps xmm9, [rsp+0x90]
0000790c663da7fb  vmovaps xmm10, [rsp+0xA0]
0000790c663da804  vmovaps xmm11, [rsp+0xB0]
0000790c663da80d  vmovaps xmm12, [rsp+0xC0]
0000790c663da816  vmovaps xmm13, [rsp+0xD0]
0000790c663da81f  vmovaps xmm14, [rsp+0xE0]
0000790c663da828  add rsp, 0xF0
0000790c663da82f  pop r11
0000790c663da831  pop r10
0000790c663da833  pop r9
0000790c663da835  pop r8
0000790c663da837  pop rsi
0000790c663da838  pop rdi
0000790c663da839  pop rdx
0000790c663da83a  pop rcx
0000790c663da83b  pop rax
0000790c663da83c  add rsp, 0x08
0000790c663da840  jmp 0x0000790C663D64A5
0000790c663da845  sub rsp, 0x08
0000790c663da849  push rax
0000790c663da84a  push rcx
0000790c663da84b  push rdx
0000790c663da84c  push rdi
0000790c663da84d  push rsi
0000790c663da84e  push r8
0000790c663da850  push r9
0000790c663da852  push r10
0000790c663da854  push r11
0000790c663da856  sub rsp, 0xF0
0000790c663da85d  vmovaps [rsp], xmm0
0000790c663da862  vmovaps [rsp+0x10], xmm1
0000790c663da868  vmovaps [rsp+0x20], xmm2
0000790c663da86e  vmovaps [rsp+0x30], xmm3
0000790c663da874  vmovaps [rsp+0x40], xmm4
0000790c663da87a  vmovaps [rsp+0x50], xmm5
0000790c663da880  vmovaps [rsp+0x60], xmm6
0000790c663da886  vmovaps [rsp+0x70], xmm8
0000790c663da88c  vmovaps [rsp+0x80], xmm9
0000790c663da895  vmovaps [rsp+0x90], xmm10
0000790c663da89e  vmovaps [rsp+0xA0], xmm11
0000790c663da8a7  vmovaps [rsp+0xB0], xmm12
0000790c663da8b0  vmovaps [rsp+0xC0], xmm13
0000790c663da8b9  vmovaps [rsp+0xD0], xmm14
0000790c663da8c2  vmovaps [rsp+0xE0], xmm15
0000790c663da8cb  sub rsp, 0x30
0000790c663da8cf  movaps [rsp], xmm7
0000790c663da8d3  movaps [rsp+0x10], xmm11
0000790c663da8d9  movaps [rsp+0x20], xmm9
0000790c663da8df  lea rdi, [rsp]
0000790c663da8e3  mov esi, 0x00
0000790c663da8e8  mov rax, 0x631C1759F530
0000790c663da8f2  call rax
0000790c663da8f4  movaps xmm7, [rsp]
0000790c663da8f8  add rsp, 0x30
0000790c663da8fc  vmovaps xmm0, [rsp]
0000790c663da901  vmovaps xmm1, [rsp+0x10]
0000790c663da907  vmovaps xmm2, [rsp+0x20]
0000790c663da90d  vmovaps xmm3, [rsp+0x30]
0000790c663da913  vmovaps xmm4, [rsp+0x40]
0000790c663da919  vmovaps xmm5, [rsp+0x50]
0000790c663da91f  vmovaps xmm6, [rsp+0x60]
0000790c663da925  vmovaps xmm8, [rsp+0x70]
0000790c663da92b  vmovaps xmm9, [rsp+0x80]
0000790c663da934  vmovaps xmm10, [rsp+0x90]
0000790c663da93d  vmovaps xmm11, [rsp+0xA0]
0000790c663da946  vmovaps xmm12, [rsp+0xB0]
0000790c663da94f  vmovaps xmm13, [rsp+0xC0]
0000790c663da958  vmovaps xmm14, [rsp+0xD0]
0000790c663da961  vmovaps xmm15, [rsp+0xE0]
0000790c663da96a  add rsp, 0xF0
0000790c663da971  pop r11
0000790c663da973  pop r10
0000790c663da975  pop r9
0000790c663da977  pop r8
0000790c663da979  pop rsi
0000790c663da97a  pop rdi
0000790c663da97b  pop rdx
0000790c663da97c  pop rcx
0000790c663da97d  pop rax
0000790c663da97e  add rsp, 0x08
0000790c663da982  jmp 0x0000790C663D64D2
0000790c663da987  sub rsp, 0x08
0000790c663da98b  push rax
0000790c663da98c  push rcx
0000790c663da98d  push rdx
0000790c663da98e  push rdi
0000790c663da98f  push rsi
0000790c663da990  push r8
0000790c663da992  push r9
0000790c663da994  push r10
0000790c663da996  push r11
0000790c663da998  sub rsp, 0xF0
0000790c663da99f  vmovaps [rsp], xmm0
0000790c663da9a4  vmovaps [rsp+0x10], xmm1
0000790c663da9aa  vmovaps [rsp+0x20], xmm2
0000790c663da9b0  vmovaps [rsp+0x30], xmm3
0000790c663da9b6  vmovaps [rsp+0x40], xmm4
0000790c663da9bc  vmovaps [rsp+0x50], xmm5
0000790c663da9c2  vmovaps [rsp+0x60], xmm6
0000790c663da9c8  vmovaps [rsp+0x70], xmm7
0000790c663da9ce  vmovaps [rsp+0x80], xmm8
0000790c663da9d7  vmovaps [rsp+0x90], xmm9
0000790c663da9e0  vmovaps [rsp+0xA0], xmm10
0000790c663da9e9  vmovaps [rsp+0xB0], xmm12
0000790c663da9f2  vmovaps [rsp+0xC0], xmm13
0000790c663da9fb  vmovaps [rsp+0xD0], xmm14
0000790c663daa04  vmovaps [rsp+0xE0], xmm15
0000790c663daa0d  sub rsp, 0x30
0000790c663daa11  movaps [rsp], xmm11
0000790c663daa16  movaps [rsp+0x10], xmm10
0000790c663daa1c  movaps [rsp+0x20], xmm14
0000790c663daa22  lea rdi, [rsp]
0000790c663daa26  mov esi, 0x00
0000790c663daa2b  mov rax, 0x631C1759F530
0000790c663daa35  call rax
0000790c663daa37  movaps xmm11, [rsp]
0000790c663daa3c  add rsp, 0x30
0000790c663daa40  vmovaps xmm0, [rsp]
0000790c663daa45  vmovaps xmm1, [rsp+0x10]
0000790c663daa4b  vmovaps xmm2, [rsp+0x20]
0000790c663daa51  vmovaps xmm3, [rsp+0x30]
0000790c663daa57  vmovaps xmm4, [rsp+0x40]
0000790c663daa5d  vmovaps xmm5, [rsp+0x50]
0000790c663daa63  vmovaps xmm6, [rsp+0x60]
0000790c663daa69  vmovaps xmm7, [rsp+0x70]
0000790c663daa6f  vmovaps xmm8, [rsp+0x80]
0000790c663daa78  vmovaps xmm9, [rsp+0x90]
0000790c663daa81  vmovaps xmm10, [rsp+0xA0]
0000790c663daa8a  vmovaps xmm12, [rsp+0xB0]
0000790c663daa93  vmovaps xmm13, [rsp+0xC0]
0000790c663daa9c  vmovaps xmm14, [rsp+0xD0]
0000790c663daaa5  vmovaps xmm15, [rsp+0xE0]
0000790c663daaae  add rsp, 0xF0
0000790c663daab5  pop r11
0000790c663daab7  pop r10
0000790c663daab9  pop r9
0000790c663daabb  pop r8
0000790c663daabd  pop rsi
0000790c663daabe  pop rdi
0000790c663daabf  pop rdx
0000790c663daac0  pop rcx
0000790c663daac1  pop rax
0000790c663daac2  add rsp, 0x08
0000790c663daac6  jmp 0x0000790C663D64ED
0000790c663daacb  call 0x0000790C662E45A0
0000790c663daad0  jmp 0x0000790C663D64F7
0000790c663daad5  sub rsp, 0x08
0000790c663daad9  push rax
0000790c663daada  push rcx
0000790c663daadb  push rdx
0000790c663daadc  push rdi
0000790c663daadd  push rsi
0000790c663daade  push r8
0000790c663daae0  push r9
0000790c663daae2  push r10
0000790c663daae4  push r11
0000790c663daae6  sub rsp, 0xF0
0000790c663daaed  vmovaps [rsp], xmm0
0000790c663daaf2  vmovaps [rsp+0x10], xmm1
0000790c663daaf8  vmovaps [rsp+0x20], xmm2
0000790c663daafe  vmovaps [rsp+0x30], xmm3
0000790c663dab04  vmovaps [rsp+0x40], xmm4
0000790c663dab0a  vmovaps [rsp+0x50], xmm5
0000790c663dab10  vmovaps [rsp+0x60], xmm6
0000790c663dab16  vmovaps [rsp+0x70], xmm7
0000790c663dab1c  vmovaps [rsp+0x80], xmm8
0000790c663dab25  vmovaps [rsp+0x90], xmm9
0000790c663dab2e  vmovaps [rsp+0xA0], xmm11
0000790c663dab37  vmovaps [rsp+0xB0], xmm12
0000790c663dab40  vmovaps [rsp+0xC0], xmm13
0000790c663dab49  vmovaps [rsp+0xD0], xmm14
0000790c663dab52  vmovaps [rsp+0xE0], xmm15
0000790c663dab5b  sub rsp, 0x30
0000790c663dab5f  movaps [rsp], xmm10
0000790c663dab64  movaps [rsp+0x10], xmm1
0000790c663dab69  movaps [rsp+0x20], xmm12
0000790c663dab6f  lea rdi, [rsp]
0000790c663dab73  mov esi, 0x00
0000790c663dab78  mov rax, 0x631C1759F530
0000790c663dab82  call rax
0000790c663dab84  movaps xmm10, [rsp]
0000790c663dab89  add rsp, 0x30
0000790c663dab8d  vmovaps xmm0, [rsp]
0000790c663dab92  vmovaps xmm1, [rsp+0x10]
0000790c663dab98  vmovaps xmm2, [rsp+0x20]
0000790c663dab9e  vmovaps xmm3, [rsp+0x30]
0000790c663daba4  vmovaps xmm4, [rsp+0x40]
0000790c663dabaa  vmovaps xmm5, [rsp+0x50]
0000790c663dabb0  vmovaps xmm6, [rsp+0x60]
0000790c663dabb6  vmovaps xmm7, [rsp+0x70]
0000790c663dabbc  vmovaps xmm8, [rsp+0x80]
0000790c663dabc5  vmovaps xmm9, [rsp+0x90]
0000790c663dabce  vmovaps xmm11, [rsp+0xA0]
0000790c663dabd7  vmovaps xmm12, [rsp+0xB0]
0000790c663dabe0  vmovaps xmm13, [rsp+0xC0]
0000790c663dabe9  vmovaps xmm14, [rsp+0xD0]
0000790c663dabf2  vmovaps xmm15, [rsp+0xE0]
0000790c663dabfb  add rsp, 0xF0
0000790c663dac02  pop r11
0000790c663dac04  pop r10
0000790c663dac06  pop r9
0000790c663dac08  pop r8
0000790c663dac0a  pop rsi
0000790c663dac0b  pop rdi
0000790c663dac0c  pop rdx
0000790c663dac0d  pop rcx
0000790c663dac0e  pop rax
0000790c663dac0f  add rsp, 0x08
0000790c663dac13  jmp 0x0000790C663D651A
0000790c663dac18  sub rsp, 0x08
0000790c663dac1c  push rax
0000790c663dac1d  push rcx
0000790c663dac1e  push rdx
0000790c663dac1f  push rdi
0000790c663dac20  push rsi
0000790c663dac21  push r8
0000790c663dac23  push r9
0000790c663dac25  push r10
0000790c663dac27  push r11
0000790c663dac29  sub rsp, 0xF0
0000790c663dac30  vmovaps [rsp], xmm0
0000790c663dac35  vmovaps [rsp+0x10], xmm1
0000790c663dac3b  vmovaps [rsp+0x20], xmm2
0000790c663dac41  vmovaps [rsp+0x30], xmm3
0000790c663dac47  vmovaps [rsp+0x40], xmm4
0000790c663dac4d  vmovaps [rsp+0x50], xmm5
0000790c663dac53  vmovaps [rsp+0x60], xmm6
0000790c663dac59  vmovaps [rsp+0x70], xmm7
0000790c663dac5f  vmovaps [rsp+0x80], xmm8
0000790c663dac68  vmovaps [rsp+0x90], xmm9
0000790c663dac71  vmovaps [rsp+0xA0], xmm10
0000790c663dac7a  vmovaps [rsp+0xB0], xmm11
0000790c663dac83  vmovaps [rsp+0xC0], xmm13
0000790c663dac8c  vmovaps [rsp+0xD0], xmm14
0000790c663dac95  vmovaps [rsp+0xE0], xmm15
0000790c663dac9e  sub rsp, 0x30
0000790c663daca2  movaps [rsp], xmm12
0000790c663daca7  movaps [rsp+0x10], xmm14
0000790c663dacad  movaps [rsp+0x20], xmm1
0000790c663dacb2  lea rdi, [rsp]
0000790c663dacb6  mov esi, 0x00
0000790c663dacbb  mov rax, 0x631C1759F530
0000790c663dacc5  call rax
0000790c663dacc7  movaps xmm12, [rsp]
0000790c663daccc  add rsp, 0x30
0000790c663dacd0  vmovaps xmm0, [rsp]
0000790c663dacd5  vmovaps xmm1, [rsp+0x10]
0000790c663dacdb  vmovaps xmm2, [rsp+0x20]
0000790c663dace1  vmovaps xmm3, [rsp+0x30]
0000790c663dace7  vmovaps xmm4, [rsp+0x40]
0000790c663daced  vmovaps xmm5, [rsp+0x50]
0000790c663dacf3  vmovaps xmm6, [rsp+0x60]
0000790c663dacf9  vmovaps xmm7, [rsp+0x70]
0000790c663dacff  vmovaps xmm8, [rsp+0x80]
0000790c663dad08  vmovaps xmm9, [rsp+0x90]
0000790c663dad11  vmovaps xmm10, [rsp+0xA0]
0000790c663dad1a  vmovaps xmm11, [rsp+0xB0]
0000790c663dad23  vmovaps xmm13, [rsp+0xC0]
0000790c663dad2c  vmovaps xmm14, [rsp+0xD0]
0000790c663dad35  vmovaps xmm15, [rsp+0xE0]
0000790c663dad3e  add rsp, 0xF0
0000790c663dad45  pop r11
0000790c663dad47  pop r10
0000790c663dad49  pop r9
0000790c663dad4b  pop r8
0000790c663dad4d  pop rsi
0000790c663dad4e  pop rdi
0000790c663dad4f  pop rdx
0000790c663dad50  pop rcx
0000790c663dad51  pop rax
0000790c663dad52  add rsp, 0x08
0000790c663dad56  jmp 0x0000790C663D6549
0000790c663dad5b  sub rsp, 0x08
0000790c663dad5f  push rax
0000790c663dad60  push rcx
0000790c663dad61  push rdx
0000790c663dad62  push rdi
0000790c663dad63  push rsi
0000790c663dad64  push r8
0000790c663dad66  push r9
0000790c663dad68  push r10
0000790c663dad6a  push r11
0000790c663dad6c  sub rsp, 0xF0
0000790c663dad73  vmovaps [rsp], xmm0
0000790c663dad78  vmovaps [rsp+0x10], xmm1
0000790c663dad7e  vmovaps [rsp+0x20], xmm2
0000790c663dad84  vmovaps [rsp+0x30], xmm3
0000790c663dad8a  vmovaps [rsp+0x40], xmm4
0000790c663dad90  vmovaps [rsp+0x50], xmm5
0000790c663dad96  vmovaps [rsp+0x60], xmm6
0000790c663dad9c  vmovaps [rsp+0x70], xmm7
0000790c663dada2  vmovaps [rsp+0x80], xmm8
0000790c663dadab  vmovaps [rsp+0x90], xmm9
0000790c663dadb4  vmovaps [rsp+0xA0], xmm10
0000790c663dadbd  vmovaps [rsp+0xB0], xmm11
0000790c663dadc6  vmovaps [rsp+0xC0], xmm12
0000790c663dadcf  vmovaps [rsp+0xD0], xmm13
0000790c663dadd8  vmovaps [rsp+0xE0], xmm15
0000790c663dade1  sub rsp, 0x30
0000790c663dade5  movaps [rsp], xmm14
0000790c663dadea  movaps [rsp+0x10], xmm9
0000790c663dadf0  movaps [rsp+0x20], xmm1
0000790c663dadf5  lea rdi, [rsp]
0000790c663dadf9  mov esi, 0x00
0000790c663dadfe  mov rax, 0x631C1759F530
0000790c663dae08  call rax
0000790c663dae0a  movaps xmm14, [rsp]
0000790c663dae0f  add rsp, 0x30
0000790c663dae13  vmovaps xmm0, [rsp]
0000790c663dae18  vmovaps xmm1, [rsp+0x10]
0000790c663dae1e  vmovaps xmm2, [rsp+0x20]
0000790c663dae24  vmovaps xmm3, [rsp+0x30]
0000790c663dae2a  vmovaps xmm4, [rsp+0x40]
0000790c663dae30  vmovaps xmm5, [rsp+0x50]
0000790c663dae36  vmovaps xmm6, [rsp+0x60]
0000790c663dae3c  vmovaps xmm7, [rsp+0x70]
0000790c663dae42  vmovaps xmm8, [rsp+0x80]
0000790c663dae4b  vmovaps xmm9, [rsp+0x90]
0000790c663dae54  vmovaps xmm10, [rsp+0xA0]
0000790c663dae5d  vmovaps xmm11, [rsp+0xB0]
0000790c663dae66  vmovaps xmm12, [rsp+0xC0]
0000790c663dae6f  vmovaps xmm13, [rsp+0xD0]
0000790c663dae78  vmovaps xmm15, [rsp+0xE0]
0000790c663dae81  add rsp, 0xF0
0000790c663dae88  pop r11
0000790c663dae8a  pop r10
0000790c663dae8c  pop r9
0000790c663dae8e  pop r8
0000790c663dae90  pop rsi
0000790c663dae91  pop rdi
0000790c663dae92  pop rdx
0000790c663dae93  pop rcx
0000790c663dae94  pop rax
0000790c663dae95  add rsp, 0x08
0000790c663dae99  jmp 0x0000790C663D6578
0000790c663dae9e  sub rsp, 0x08
0000790c663daea2  push rax
0000790c663daea3  push rcx
0000790c663daea4  push rdx
0000790c663daea5  push rdi
0000790c663daea6  push rsi
0000790c663daea7  push r8
0000790c663daea9  push r9
0000790c663daeab  push r10
0000790c663daead  push r11
0000790c663daeaf  sub rsp, 0xF0
0000790c663daeb6  vmovaps [rsp], xmm0
0000790c663daebb  vmovaps [rsp+0x10], xmm2
0000790c663daec1  vmovaps [rsp+0x20], xmm3
0000790c663daec7  vmovaps [rsp+0x30], xmm4
0000790c663daecd  vmovaps [rsp+0x40], xmm5
0000790c663daed3  vmovaps [rsp+0x50], xmm6
0000790c663daed9  vmovaps [rsp+0x60], xmm7
0000790c663daedf  vmovaps [rsp+0x70], xmm8
0000790c663daee5  vmovaps [rsp+0x80], xmm9
0000790c663daeee  vmovaps [rsp+0x90], xmm10
0000790c663daef7  vmovaps [rsp+0xA0], xmm11
0000790c663daf00  vmovaps [rsp+0xB0], xmm12
0000790c663daf09  vmovaps [rsp+0xC0], xmm13
0000790c663daf12  vmovaps [rsp+0xD0], xmm14
0000790c663daf1b  vmovaps [rsp+0xE0], xmm15
0000790c663daf24  sub rsp, 0x30
0000790c663daf28  movaps [rsp], xmm1
0000790c663daf2c  movaps [rsp+0x10], xmm13
0000790c663daf32  movaps [rsp+0x20], xmm8
0000790c663daf38  lea rdi, [rsp]
0000790c663daf3c  mov esi, 0x00
0000790c663daf41  mov rax, 0x631C1759F530
0000790c663daf4b  call rax
0000790c663daf4d  movaps xmm1, [rsp]
0000790c663daf51  add rsp, 0x30
0000790c663daf55  vmovaps xmm0, [rsp]
0000790c663daf5a  vmovaps xmm2, [rsp+0x10]
0000790c663daf60  vmovaps xmm3, [rsp+0x20]
0000790c663daf66  vmovaps xmm4, [rsp+0x30]
0000790c663daf6c  vmovaps xmm5, [rsp+0x40]
0000790c663daf72  vmovaps xmm6, [rsp+0x50]
0000790c663daf78  vmovaps xmm7, [rsp+0x60]
0000790c663daf7e  vmovaps xmm8, [rsp+0x70]
0000790c663daf84  vmovaps xmm9, [rsp+0x80]
0000790c663daf8d  vmovaps xmm10, [rsp+0x90]
0000790c663daf96  vmovaps xmm11, [rsp+0xA0]
0000790c663daf9f  vmovaps xmm12, [rsp+0xB0]
0000790c663dafa8  vmovaps xmm13, [rsp+0xC0]
0000790c663dafb1  vmovaps xmm14, [rsp+0xD0]
0000790c663dafba  vmovaps xmm15, [rsp+0xE0]
0000790c663dafc3  add rsp, 0xF0
0000790c663dafca  pop r11
0000790c663dafcc  pop r10
0000790c663dafce  pop r9
0000790c663dafd0  pop r8
0000790c663dafd2  pop rsi
0000790c663dafd3  pop rdi
0000790c663dafd4  pop rdx
0000790c663dafd5  pop rcx
0000790c663dafd6  pop rax
0000790c663dafd7  add rsp, 0x08
0000790c663dafdb  jmp 0x0000790C663D659A
0000790c663dafe0  call 0x0000790C6620C260
0000790c663dafe5  jmp 0x0000790C663D65A8
0000790c663dafea  call 0x0000790C662DE950
0000790c663dafef  jmp 0x0000790C663D65B2
0000790c663daff4  sub rsp, 0x08
0000790c663daff8  push rax
0000790c663daff9  push rcx
0000790c663daffa  push rdx
0000790c663daffb  push rdi
0000790c663daffc  push rsi
0000790c663daffd  push r8
0000790c663dafff  push r9
0000790c663db001  push r10
0000790c663db003  push r11
0000790c663db005  sub rsp, 0xF0
0000790c663db00c  vmovaps [rsp], xmm0
0000790c663db011  vmovaps [rsp+0x10], xmm1
0000790c663db017  vmovaps [rsp+0x20], xmm2
0000790c663db01d  vmovaps [rsp+0x30], xmm3
0000790c663db023  vmovaps [rsp+0x40], xmm4
0000790c663db029  vmovaps [rsp+0x50], xmm5
0000790c663db02f  vmovaps [rsp+0x60], xmm6
0000790c663db035  vmovaps [rsp+0x70], xmm7
0000790c663db03b  vmovaps [rsp+0x80], xmm9
0000790c663db044  vmovaps [rsp+0x90], xmm10
0000790c663db04d  vmovaps [rsp+0xA0], xmm11
0000790c663db056  vmovaps [rsp+0xB0], xmm12
0000790c663db05f  vmovaps [rsp+0xC0], xmm13
0000790c663db068  vmovaps [rsp+0xD0], xmm14
0000790c663db071  vmovaps [rsp+0xE0], xmm15
0000790c663db07a  sub rsp, 0x30
0000790c663db07e  movaps [rsp], xmm8
0000790c663db083  movaps [rsp+0x10], xmm15
0000790c663db089  movaps [rsp+0x20], xmm7
0000790c663db08e  lea rdi, [rsp]
0000790c663db092  mov esi, 0x00
0000790c663db097  mov rax, 0x631C1759F530
0000790c663db0a1  call rax
0000790c663db0a3  movaps xmm8, [rsp]
0000790c663db0a8  add rsp, 0x30
0000790c663db0ac  vmovaps xmm0, [rsp]
0000790c663db0b1  vmovaps xmm1, [rsp+0x10]
0000790c663db0b7  vmovaps xmm2, [rsp+0x20]
0000790c663db0bd  vmovaps xmm3, [rsp+0x30]
0000790c663db0c3  vmovaps xmm4, [rsp+0x40]
0000790c663db0c9  vmovaps xmm5, [rsp+0x50]
0000790c663db0cf  vmovaps xmm6, [rsp+0x60]
0000790c663db0d5  vmovaps xmm7, [rsp+0x70]
0000790c663db0db  vmovaps xmm9, [rsp+0x80]
0000790c663db0e4  vmovaps xmm10, [rsp+0x90]
0000790c663db0ed  vmovaps xmm11, [rsp+0xA0]
0000790c663db0f6  vmovaps xmm12, [rsp+0xB0]
0000790c663db0ff  vmovaps xmm13, [rsp+0xC0]
0000790c663db108  vmovaps xmm14, [rsp+0xD0]
0000790c663db111  vmovaps xmm15, [rsp+0xE0]
0000790c663db11a  add rsp, 0xF0
0000790c663db121  pop r11
0000790c663db123  pop r10
0000790c663db125  pop r9
0000790c663db127  pop r8
0000790c663db129  pop rsi
0000790c663db12a  pop rdi
0000790c663db12b  pop rdx
0000790c663db12c  pop rcx
0000790c663db12d  pop rax
0000790c663db12e  add rsp, 0x08
0000790c663db132  jmp 0x0000790C663D65D4
0000790c663db137  sub rsp, 0x08
0000790c663db13b  push rax
0000790c663db13c  push rcx
0000790c663db13d  push rdx
0000790c663db13e  push rdi
0000790c663db13f  push rsi
0000790c663db140  push r8
0000790c663db142  push r9
0000790c663db144  push r10
0000790c663db146  push r11
0000790c663db148  sub rsp, 0xF0
0000790c663db14f  vmovaps [rsp], xmm0
0000790c663db154  vmovaps [rsp+0x10], xmm1
0000790c663db15a  vmovaps [rsp+0x20], xmm2
0000790c663db160  vmovaps [rsp+0x30], xmm3
0000790c663db166  vmovaps [rsp+0x40], xmm4
0000790c663db16c  vmovaps [rsp+0x50], xmm5
0000790c663db172  vmovaps [rsp+0x60], xmm6
0000790c663db178  vmovaps [rsp+0x70], xmm8
0000790c663db17e  vmovaps [rsp+0x80], xmm9
0000790c663db187  vmovaps [rsp+0x90], xmm10
0000790c663db190  vmovaps [rsp+0xA0], xmm11
0000790c663db199  vmovaps [rsp+0xB0], xmm12
0000790c663db1a2  vmovaps [rsp+0xC0], xmm13
0000790c663db1ab  vmovaps [rsp+0xD0], xmm14
0000790c663db1b4  vmovaps [rsp+0xE0], xmm15
0000790c663db1bd  sub rsp, 0x30
0000790c663db1c1  movaps [rsp], xmm7
0000790c663db1c5  movaps [rsp+0x10], xmm9
0000790c663db1cb  movaps [rsp+0x20], xmm15
0000790c663db1d1  lea rdi, [rsp]
0000790c663db1d5  mov esi, 0x00
0000790c663db1da  mov rax, 0x631C1759F530
0000790c663db1e4  call rax
0000790c663db1e6  movaps xmm7, [rsp]
0000790c663db1ea  add rsp, 0x30
0000790c663db1ee  vmovaps xmm0, [rsp]
0000790c663db1f3  vmovaps xmm1, [rsp+0x10]
0000790c663db1f9  vmovaps xmm2, [rsp+0x20]
0000790c663db1ff  vmovaps xmm3, [rsp+0x30]
0000790c663db205  vmovaps xmm4, [rsp+0x40]
0000790c663db20b  vmovaps xmm5, [rsp+0x50]
0000790c663db211  vmovaps xmm6, [rsp+0x60]
0000790c663db217  vmovaps xmm8, [rsp+0x70]
0000790c663db21d  vmovaps xmm9, [rsp+0x80]
0000790c663db226  vmovaps xmm10, [rsp+0x90]
0000790c663db22f  vmovaps xmm11, [rsp+0xA0]
0000790c663db238  vmovaps xmm12, [rsp+0xB0]
0000790c663db241  vmovaps xmm13, [rsp+0xC0]
0000790c663db24a  vmovaps xmm14, [rsp+0xD0]
0000790c663db253  vmovaps xmm15, [rsp+0xE0]
0000790c663db25c  add rsp, 0xF0
0000790c663db263  pop r11
0000790c663db265  pop r10
0000790c663db267  pop r9
0000790c663db269  pop r8
0000790c663db26b  pop rsi
0000790c663db26c  pop rdi
0000790c663db26d  pop rdx
0000790c663db26e  pop rcx
0000790c663db26f  pop rax
0000790c663db270  add rsp, 0x08
0000790c663db274  jmp 0x0000790C663D6601
0000790c663db279  sub rsp, 0x08
0000790c663db27d  push rax
0000790c663db27e  push rcx
0000790c663db27f  push rdx
0000790c663db280  push rdi
0000790c663db281  push rsi
0000790c663db282  push r8
0000790c663db284  push r9
0000790c663db286  push r10
0000790c663db288  push r11
0000790c663db28a  sub rsp, 0xF0
0000790c663db291  vmovaps [rsp], xmm0
0000790c663db296  vmovaps [rsp+0x10], xmm1
0000790c663db29c  vmovaps [rsp+0x20], xmm2
0000790c663db2a2  vmovaps [rsp+0x30], xmm3
0000790c663db2a8  vmovaps [rsp+0x40], xmm4
0000790c663db2ae  vmovaps [rsp+0x50], xmm5
0000790c663db2b4  vmovaps [rsp+0x60], xmm6
0000790c663db2ba  vmovaps [rsp+0x70], xmm7
0000790c663db2c0  vmovaps [rsp+0x80], xmm8
0000790c663db2c9  vmovaps [rsp+0x90], xmm10
0000790c663db2d2  vmovaps [rsp+0xA0], xmm11
0000790c663db2db  vmovaps [rsp+0xB0], xmm12
0000790c663db2e4  vmovaps [rsp+0xC0], xmm13
0000790c663db2ed  vmovaps [rsp+0xD0], xmm14
0000790c663db2f6  vmovaps [rsp+0xE0], xmm15
0000790c663db2ff  sub rsp, 0x30
0000790c663db303  movaps [rsp], xmm9
0000790c663db308  movaps [rsp+0x10], xmm13
0000790c663db30e  movaps [rsp+0x20], xmm15
0000790c663db314  lea rdi, [rsp]
0000790c663db318  mov esi, 0x00
0000790c663db31d  mov rax, 0x631C1759F530
0000790c663db327  call rax
0000790c663db329  movaps xmm9, [rsp]
0000790c663db32e  add rsp, 0x30
0000790c663db332  vmovaps xmm0, [rsp]
0000790c663db337  vmovaps xmm1, [rsp+0x10]
0000790c663db33d  vmovaps xmm2, [rsp+0x20]
0000790c663db343  vmovaps xmm3, [rsp+0x30]
0000790c663db349  vmovaps xmm4, [rsp+0x40]
0000790c663db34f  vmovaps xmm5, [rsp+0x50]
0000790c663db355  vmovaps xmm6, [rsp+0x60]
0000790c663db35b  vmovaps xmm7, [rsp+0x70]
0000790c663db361  vmovaps xmm8, [rsp+0x80]
0000790c663db36a  vmovaps xmm10, [rsp+0x90]
0000790c663db373  vmovaps xmm11, [rsp+0xA0]
0000790c663db37c  vmovaps xmm12, [rsp+0xB0]
0000790c663db385  vmovaps xmm13, [rsp+0xC0]
0000790c663db38e  vmovaps xmm14, [rsp+0xD0]
0000790c663db397  vmovaps xmm15, [rsp+0xE0]
0000790c663db3a0  add rsp, 0xF0
0000790c663db3a7  pop r11
0000790c663db3a9  pop r10
0000790c663db3ab  pop r9
0000790c663db3ad  pop r8
0000790c663db3af  pop rsi
0000790c663db3b0  pop rdi
0000790c663db3b1  pop rdx
0000790c663db3b2  pop rcx
0000790c663db3b3  pop rax
0000790c663db3b4  add rsp, 0x08
0000790c663db3b8  jmp 0x0000790C663D662F
0000790c663db3bd  sub rsp, 0x08
0000790c663db3c1  push rax
0000790c663db3c2  push rcx
0000790c663db3c3  push rdx
0000790c663db3c4  push rdi
0000790c663db3c5  push rsi
0000790c663db3c6  push r8
0000790c663db3c8  push r9
0000790c663db3ca  push r10
0000790c663db3cc  push r11
0000790c663db3ce  sub rsp, 0xF0
0000790c663db3d5  vmovaps [rsp], xmm0
0000790c663db3da  vmovaps [rsp+0x10], xmm1
0000790c663db3e0  vmovaps [rsp+0x20], xmm2
0000790c663db3e6  vmovaps [rsp+0x30], xmm3
0000790c663db3ec  vmovaps [rsp+0x40], xmm4
0000790c663db3f2  vmovaps [rsp+0x50], xmm5
0000790c663db3f8  vmovaps [rsp+0x60], xmm6
0000790c663db3fe  vmovaps [rsp+0x70], xmm7
0000790c663db404  vmovaps [rsp+0x80], xmm8
0000790c663db40d  vmovaps [rsp+0x90], xmm9
0000790c663db416  vmovaps [rsp+0xA0], xmm10
0000790c663db41f  vmovaps [rsp+0xB0], xmm11
0000790c663db428  vmovaps [rsp+0xC0], xmm12
0000790c663db431  vmovaps [rsp+0xD0], xmm13
0000790c663db43a  vmovaps [rsp+0xE0], xmm14
0000790c663db443  sub rsp, 0x30
0000790c663db447  movaps [rsp], xmm15
0000790c663db44c  movaps [rsp+0x10], xmm11
0000790c663db452  movaps [rsp+0x20], xmm12
0000790c663db458  lea rdi, [rsp]
0000790c663db45c  mov esi, 0x00
0000790c663db461  mov rax, 0x631C1759F530
0000790c663db46b  call rax
0000790c663db46d  movaps xmm15, [rsp]
0000790c663db472  add rsp, 0x30
0000790c663db476  vmovaps xmm0, [rsp]
0000790c663db47b  vmovaps xmm1, [rsp+0x10]
0000790c663db481  vmovaps xmm2, [rsp+0x20]
0000790c663db487  vmovaps xmm3, [rsp+0x30]
0000790c663db48d  vmovaps xmm4, [rsp+0x40]
0000790c663db493  vmovaps xmm5, [rsp+0x50]
0000790c663db499  vmovaps xmm6, [rsp+0x60]
0000790c663db49f  vmovaps xmm7, [rsp+0x70]
0000790c663db4a5  vmovaps xmm8, [rsp+0x80]
0000790c663db4ae  vmovaps xmm9, [rsp+0x90]
0000790c663db4b7  vmovaps xmm10, [rsp+0xA0]
0000790c663db4c0  vmovaps xmm11, [rsp+0xB0]
0000790c663db4c9  vmovaps xmm12, [rsp+0xC0]
0000790c663db4d2  vmovaps xmm13, [rsp+0xD0]
0000790c663db4db  vmovaps xmm14, [rsp+0xE0]
0000790c663db4e4  add rsp, 0xF0
0000790c663db4eb  pop r11
0000790c663db4ed  pop r10
0000790c663db4ef  pop r9
0000790c663db4f1  pop r8
0000790c663db4f3  pop rsi
0000790c663db4f4  pop rdi
0000790c663db4f5  pop rdx
0000790c663db4f6  pop rcx
0000790c663db4f7  pop rax
0000790c663db4f8  add rsp, 0x08
0000790c663db4fc  jmp 0x0000790C663D664A
0000790c663db501  sub rsp, 0x08
0000790c663db505  push rax
0000790c663db506  push rcx
0000790c663db507  push rdx
0000790c663db508  push rdi
0000790c663db509  push rsi
0000790c663db50a  push r8
0000790c663db50c  push r9
0000790c663db50e  push r10
0000790c663db510  push r11
0000790c663db512  sub rsp, 0xF0
0000790c663db519  vmovaps [rsp], xmm0
0000790c663db51e  vmovaps [rsp+0x10], xmm1
0000790c663db524  vmovaps [rsp+0x20], xmm2
0000790c663db52a  vmovaps [rsp+0x30], xmm3
0000790c663db530  vmovaps [rsp+0x40], xmm4
0000790c663db536  vmovaps [rsp+0x50], xmm5
0000790c663db53c  vmovaps [rsp+0x60], xmm6
0000790c663db542  vmovaps [rsp+0x70], xmm7
0000790c663db548  vmovaps [rsp+0x80], xmm8
0000790c663db551  vmovaps [rsp+0x90], xmm9
0000790c663db55a  vmovaps [rsp+0xA0], xmm10
0000790c663db563  vmovaps [rsp+0xB0], xmm11
0000790c663db56c  vmovaps [rsp+0xC0], xmm12
0000790c663db575  vmovaps [rsp+0xD0], xmm14
0000790c663db57e  vmovaps [rsp+0xE0], xmm15
0000790c663db587  sub rsp, 0x30
0000790c663db58b  movaps [rsp], xmm13
0000790c663db590  movaps [rsp+0x10], xmm10
0000790c663db596  movaps [rsp+0x20], xmm14
0000790c663db59c  lea rdi, [rsp]
0000790c663db5a0  mov esi, 0x00
0000790c663db5a5  mov rax, 0x631C1759F530
0000790c663db5af  call rax
0000790c663db5b1  movaps xmm13, [rsp]
0000790c663db5b6  add rsp, 0x30
0000790c663db5ba  vmovaps xmm0, [rsp]
0000790c663db5bf  vmovaps xmm1, [rsp+0x10]
0000790c663db5c5  vmovaps xmm2, [rsp+0x20]
0000790c663db5cb  vmovaps xmm3, [rsp+0x30]
0000790c663db5d1  vmovaps xmm4, [rsp+0x40]
0000790c663db5d7  vmovaps xmm5, [rsp+0x50]
0000790c663db5dd  vmovaps xmm6, [rsp+0x60]
0000790c663db5e3  vmovaps xmm7, [rsp+0x70]
0000790c663db5e9  vmovaps xmm8, [rsp+0x80]
0000790c663db5f2  vmovaps xmm9, [rsp+0x90]
0000790c663db5fb  vmovaps xmm10, [rsp+0xA0]
0000790c663db604  vmovaps xmm11, [rsp+0xB0]
0000790c663db60d  vmovaps xmm12, [rsp+0xC0]
0000790c663db616  vmovaps xmm14, [rsp+0xD0]
0000790c663db61f  vmovaps xmm15, [rsp+0xE0]
0000790c663db628  add rsp, 0xF0
0000790c663db62f  pop r11
0000790c663db631  pop r10
0000790c663db633  pop r9
0000790c663db635  pop r8
0000790c663db637  pop rsi
0000790c663db638  pop rdi
0000790c663db639  pop rdx
0000790c663db63a  pop rcx
0000790c663db63b  pop rax
0000790c663db63c  add rsp, 0x08
0000790c663db640  jmp 0x0000790C663D666D
0000790c663db645  sub rsp, 0x08
0000790c663db649  push rax
0000790c663db64a  push rcx
0000790c663db64b  push rdx
0000790c663db64c  push rdi
0000790c663db64d  push rsi
0000790c663db64e  push r8
0000790c663db650  push r9
0000790c663db652  push r10
0000790c663db654  push r11
0000790c663db656  sub rsp, 0xF0
0000790c663db65d  vmovaps [rsp], xmm0
0000790c663db662  vmovaps [rsp+0x10], xmm1
0000790c663db668  vmovaps [rsp+0x20], xmm2
0000790c663db66e  vmovaps [rsp+0x30], xmm3
0000790c663db674  vmovaps [rsp+0x40], xmm4
0000790c663db67a  vmovaps [rsp+0x50], xmm5
0000790c663db680  vmovaps [rsp+0x60], xmm6
0000790c663db686  vmovaps [rsp+0x70], xmm7
0000790c663db68c  vmovaps [rsp+0x80], xmm8
0000790c663db695  vmovaps [rsp+0x90], xmm9
0000790c663db69e  vmovaps [rsp+0xA0], xmm10
0000790c663db6a7  vmovaps [rsp+0xB0], xmm11
0000790c663db6b0  vmovaps [rsp+0xC0], xmm12
0000790c663db6b9  vmovaps [rsp+0xD0], xmm13
0000790c663db6c2  vmovaps [rsp+0xE0], xmm15
0000790c663db6cb  sub rsp, 0x30
0000790c663db6cf  movaps [rsp], xmm14
0000790c663db6d4  movaps [rsp+0x10], xmm1
0000790c663db6d9  movaps [rsp+0x20], xmm7
0000790c663db6de  lea rdi, [rsp]
0000790c663db6e2  mov esi, 0x00
0000790c663db6e7  mov rax, 0x631C1759F530
0000790c663db6f1  call rax
0000790c663db6f3  movaps xmm14, [rsp]
0000790c663db6f8  add rsp, 0x30
0000790c663db6fc  vmovaps xmm0, [rsp]
0000790c663db701  vmovaps xmm1, [rsp+0x10]
0000790c663db707  vmovaps xmm2, [rsp+0x20]
0000790c663db70d  vmovaps xmm3, [rsp+0x30]
0000790c663db713  vmovaps xmm4, [rsp+0x40]
0000790c663db719  vmovaps xmm5, [rsp+0x50]
0000790c663db71f  vmovaps xmm6, [rsp+0x60]
0000790c663db725  vmovaps xmm7, [rsp+0x70]
0000790c663db72b  vmovaps xmm8, [rsp+0x80]
0000790c663db734  vmovaps xmm9, [rsp+0x90]
0000790c663db73d  vmovaps xmm10, [rsp+0xA0]
0000790c663db746  vmovaps xmm11, [rsp+0xB0]
0000790c663db74f  vmovaps xmm12, [rsp+0xC0]
0000790c663db758  vmovaps xmm13, [rsp+0xD0]
0000790c663db761  vmovaps xmm15, [rsp+0xE0]
0000790c663db76a  add rsp, 0xF0
0000790c663db771  pop r11
0000790c663db773  pop r10
0000790c663db775  pop r9
0000790c663db777  pop r8
0000790c663db779  pop rsi
0000790c663db77a  pop rdi
0000790c663db77b  pop rdx
0000790c663db77c  pop rcx
0000790c663db77d  pop rax
0000790c663db77e  add rsp, 0x08
0000790c663db782  jmp 0x0000790C663D6690
0000790c663db787  sub rsp, 0x08
0000790c663db78b  push rax
0000790c663db78c  push rcx
0000790c663db78d  push rdx
0000790c663db78e  push rdi
0000790c663db78f  push rsi
0000790c663db790  push r8
0000790c663db792  push r9
0000790c663db794  push r10
0000790c663db796  push r11
0000790c663db798  sub rsp, 0xF0
0000790c663db79f  vmovaps [rsp], xmm0
0000790c663db7a4  vmovaps [rsp+0x10], xmm2
0000790c663db7aa  vmovaps [rsp+0x20], xmm3
0000790c663db7b0  vmovaps [rsp+0x30], xmm4
0000790c663db7b6  vmovaps [rsp+0x40], xmm5
0000790c663db7bc  vmovaps [rsp+0x50], xmm6
0000790c663db7c2  vmovaps [rsp+0x60], xmm7
0000790c663db7c8  vmovaps [rsp+0x70], xmm8
0000790c663db7ce  vmovaps [rsp+0x80], xmm9
0000790c663db7d7  vmovaps [rsp+0x90], xmm10
0000790c663db7e0  vmovaps [rsp+0xA0], xmm11
0000790c663db7e9  vmovaps [rsp+0xB0], xmm12
0000790c663db7f2  vmovaps [rsp+0xC0], xmm13
0000790c663db7fb  vmovaps [rsp+0xD0], xmm14
0000790c663db804  vmovaps [rsp+0xE0], xmm15
0000790c663db80d  sub rsp, 0x30
0000790c663db811  movaps [rsp], xmm1
0000790c663db815  movaps [rsp+0x10], xmm8
0000790c663db81b  movaps [rsp+0x20], xmm9
0000790c663db821  lea rdi, [rsp]
0000790c663db825  mov esi, 0x00
0000790c663db82a  mov rax, 0x631C1759F530
0000790c663db834  call rax
0000790c663db836  movaps xmm1, [rsp]
0000790c663db83a  add rsp, 0x30
0000790c663db83e  vmovaps xmm0, [rsp]
0000790c663db843  vmovaps xmm2, [rsp+0x10]
0000790c663db849  vmovaps xmm3, [rsp+0x20]
0000790c663db84f  vmovaps xmm4, [rsp+0x30]
0000790c663db855  vmovaps xmm5, [rsp+0x40]
0000790c663db85b  vmovaps xmm6, [rsp+0x50]
0000790c663db861  vmovaps xmm7, [rsp+0x60]
0000790c663db867  vmovaps xmm8, [rsp+0x70]
0000790c663db86d  vmovaps xmm9, [rsp+0x80]
0000790c663db876  vmovaps xmm10, [rsp+0x90]
0000790c663db87f  vmovaps xmm11, [rsp+0xA0]
0000790c663db888  vmovaps xmm12, [rsp+0xB0]
0000790c663db891  vmovaps xmm13, [rsp+0xC0]
0000790c663db89a  vmovaps xmm14, [rsp+0xD0]
0000790c663db8a3  vmovaps xmm15, [rsp+0xE0]
0000790c663db8ac  add rsp, 0xF0
0000790c663db8b3  pop r11
0000790c663db8b5  pop r10
0000790c663db8b7  pop r9
0000790c663db8b9  pop r8
0000790c663db8bb  pop rsi
0000790c663db8bc  pop rdi
0000790c663db8bd  pop rdx
0000790c663db8be  pop rcx
0000790c663db8bf  pop rax
0000790c663db8c0  add rsp, 0x08
0000790c663db8c4  jmp 0x0000790C663D66B2
0000790c663db8c9  call 0x0000790C662B3E40
0000790c663db8ce  jmp 0x0000790C663D66C0
0000790c663db8d3  call 0x0000790C6620C380
0000790c663db8d8  jmp 0x0000790C663D66CA
0000790c663db8dd  call 0x0000790C6620D600
0000790c663db8e2  jmp 0x0000790C663D66D4
0000790c663db8e7  call 0x0000790C661FF540
0000790c663db8ec  jmp 0x0000790C663D66DE
0000790c663db8f1  int3
0000790c663db8f2  nop [rax+rax*1], ax
0000790c663db8fb  nop [rax+rax*1], eax
0000790c663db900  mov eax, [r15+0x48]
0000790c663db904  lea r14d, [eax+0x01]
0000790c663db909  mov [rsp+0x10], r14d
0000790c663db90e  mov r14d, r14d
0000790c663db911  mov [r15+0x48], r14
0000790c663db915  xor eax, eax
0000790c663db917  mov r14d, [rsp+0x10]
0000790c663db91c  cmp r14d, 0x1F4
0000790c663db923  cmc
0000790c663db924  lahf
0000790c663db925  seto al
0000790c663db928  mov [r15+0x108], eax
0000790c663db92f  mov eax, [r15+0x108]
0000790c663db936  sahf
0000790c663db937  jnz 0x0000790C663DB969
0000790c663db939  cmp dword ptr [r15+0x318], 0x00
0000790c663db941  jz 0x0000790C663E1AB0
0000790c663db947  nop [rax+rax*1], ax
0000790c663db950  nop [rax+rax*1], eax
0000790c663db958  mov eax, 0x410450
0000790c663db95d  mov [r15+0x100], rax
0000790c663db964  jmp 0x0000790C661FE110
0000790c663db969  cmp dword ptr [r15+0x318], 0x00
0000790c663db971  jz 0x0000790C663DB9A0
0000790c663db977  nop [rax+rax*1], ax
0000790c663db980  nop [rax+rax*1], eax
0000790c663db988  mov eax, 0x410274
0000790c663db98d  mov [r15+0x100], rax
0000790c663db994  jmp 0x0000790C661FE110
0000790c663db999  int3
0000790c663db99a  int3
0000790c663db99b  nop [rax+rax*1], eax
0000790c663db9a0  mov rax, [r15+0x40]
0000790c663db9a4  movaps xmm1, [r15+0x1D0]
0000790c663db9ac  vmovaps [rsp+0x10], xmm1
0000790c663db9b2  vmovaps xmm15, [rsp+0x10]
0000790c663db9b8  por xmm1, xmm15
0000790c663db9bd  movaps xmm14, [r15+0x1A0]
0000790c663db9c5  vmovaps [rsp+0x10], xmm14
0000790c663db9cb  vmovaps xmm13, [rsp+0x10]
0000790c663db9d1  por xmm14, xmm13
0000790c663db9d6  lea r14, [rax+0x30]
0000790c663db9da  mov r12, [r13+r14*1]
0000790c663db9df  lea r14, [rax+0x38]
0000790c663db9e3  mov r11, [r13+r14*1]
0000790c663db9e8  movq xmm13, r12
0000790c663db9ed  movq xmm12, r11
0000790c663db9f2  movq xmm13, xmm13
0000790c663db9f7  vmovaps [rsp+0x10], xmm13
0000790c663db9fd  movq xmm13, xmm13
0000790c663dba02  movaps [r15+0x130], xmm13
0000790c663dba0a  movq xmm12, xmm12
0000790c663dba0f  vmovaps [rsp+0x20], xmm12
0000790c663dba15  movq xmm12, xmm12
0000790c663dba1a  movaps [r15+0x280], xmm12
0000790c663dba22  movaps xmm13, [r15+0x270]
0000790c663dba2a  vmovaps [rsp+0x30], xmm13
0000790c663dba30  vmovaps xmm12, [rsp+0x30]
0000790c663dba36  por xmm13, xmm12
0000790c663dba3b  lea r14, [rax+0x20]
0000790c663dba3f  mov r12, [r13+r14*1]
0000790c663dba44  lea r14, [rax+0x28]
0000790c663dba48  mov r11, [r13+r14*1]
0000790c663dba4d  movq xmm12, r12
0000790c663dba52  movq xmm11, r11
0000790c663dba57  movq xmm12, xmm12
0000790c663dba5c  vmovaps [rsp+0x30], xmm12
0000790c663dba62  movq xmm12, xmm12
0000790c663dba67  movaps [r15+0x150], xmm12
0000790c663dba6f  movq xmm11, xmm11
0000790c663dba74  vmovaps [rsp+0x40], xmm11
0000790c663dba7a  movq xmm11, xmm11
0000790c663dba7f  movaps [r15+0x140], xmm11
0000790c663dba87  lea r14, [rax+0x10]
0000790c663dba8b  mov r12, [r13+r14*1]
0000790c663dba90  lea r14, [rax+0x18]
0000790c663dba94  mov r11, [r13+r14*1]
0000790c663dba99  movq xmm12, r12
0000790c663dba9e  movq xmm11, r11
0000790c663dbaa3  movq xmm12, xmm12
0000790c663dbaa8  vmovaps [rsp+0x50], xmm12
0000790c663dbaae  movq xmm12, xmm12
0000790c663dbab3  movaps [r15+0x170], xmm12
0000790c663dbabb  movq xmm11, xmm11
0000790c663dbac0  vmovaps [rsp+0x60], xmm11
0000790c663dbac6  movq xmm11, xmm11
0000790c663dbacb  movaps [r15+0x160], xmm11
0000790c663dbad3  mov r14, [r13+rax*1]
0000790c663dbad8  vmovq xmm12, r14
0000790c663dbadd  vpbroadcastq xmm12, xmm12
0000790c663dbae2  lea r14, [rax+0x08]
0000790c663dbae6  mov rax, [r13+r14*1]
0000790c663dbaeb  movq xmm11, rax
0000790c663dbaf0  movaps [r15+0x230], xmm11
0000790c663dbaf8  mov rax, [r15+0xF8]
0000790c663dbaff  lea r14, [rax+0x50]
0000790c663dbb03  movups xmm11, [r13+r14*1]
0000790c663dbb09  lea r14, [rax+0x60]
0000790c663dbb0d  movups xmm10, [r13+r14*1]
0000790c663dbb13  lea r14, [rax+0x30]
0000790c663dbb17  movups xmm9, [r13+r14*1]
0000790c663dbb1d  mov r14, [r15+0x50]
0000790c663dbb21  mov [r15+0x60], r14
0000790c663dbb25  mov qword ptr [r15+0x58], 0x40
0000790c663dbb2d  movaps xmm8, xmm12
0000790c663dbb31  mulpd xmm8, xmm15
0000790c663dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000790c663dbb3c  ptest xmm7, xmm7
0000790c663dbb41  jnz 0x0000790C663DC96A
0000790c663dbb47  movq xmm15, qword ptr [r15+0x230]
0000790c663dbb50  vmovaps [rsp+0x70], xmm15
0000790c663dbb56  vpermilpd xmm15, xmm15, 0x00
0000790c663dbb5c  movaps xmm7, xmm9
0000790c663dbb60  mulpd xmm7, xmm15
0000790c663dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000790c663dbb6a  ptest xmm6, xmm6
0000790c663dbb6f  jnz 0x0000790C663DCAAE
0000790c663dbb75  vxorps xmm15, xmm15, xmm15
0000790c663dbb7a  vpbroadcastq xmm15, xmm15
0000790c663dbb7f  movaps xmm9, xmm12
0000790c663dbb83  mulpd xmm9, xmm10
0000790c663dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000790c663dbb8e  ptest xmm6, xmm6
0000790c663dbb93  jnz 0x0000790C663DCBF0
0000790c663dbb99  movaps xmm10, xmm12
0000790c663dbb9d  mulpd xmm10, xmm11
0000790c663dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000790c663dbba8  ptest xmm6, xmm6
0000790c663dbbad  jnz 0x0000790C663DCD34
0000790c663dbbb3  movaps xmm11, [r15+0x1F0]
0000790c663dbbbb  movaps xmm6, xmm12
0000790c663dbbbf  mulpd xmm6, xmm11
0000790c663dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000790c663dbbc9  ptest xmm5, xmm5
0000790c663dbbce  jnz 0x0000790C663DCE78
0000790c663dbbd4  movaps xmm12, [r15+0x2A0]
0000790c663dbbdc  vmovaps [rsp+0x80], xmm12
0000790c663dbbe5  vmovaps xmm11, [rsp+0x80]
0000790c663dbbee  por xmm12, xmm11
0000790c663dbbf3  movaps xmm11, [r15+0x250]
0000790c663dbbfb  vmovaps [rsp+0x80], xmm11
0000790c663dbc04  vmovaps xmm5, [rsp+0x80]
0000790c663dbc0d  por xmm11, xmm5
0000790c663dbc12  vmovaps xmm4, [rsp+0x70]
0000790c663dbc18  vpermilpd xmm4, xmm4, 0x00
0000790c663dbc1e  movaps xmm3, xmm5
0000790c663dbc21  mulpd xmm3, xmm4
0000790c663dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000790c663dbc2a  ptest xmm2, xmm2
0000790c663dbc2f  jnz 0x0000790C663DCFBA
0000790c663dbc35  mov [rsp+0x80], rax
0000790c663dbc3d  xor eax, eax
0000790c663dbc3f  mov r12d, 0x40
0000790c663dbc45  mov r11d, 0x200
0000790c663dbc4b  cmp r12, r11
0000790c663dbc4e  cmc
0000790c663dbc4f  lahf
0000790c663dbc50  seto al
0000790c663dbc53  mov [r15+0x108], eax
0000790c663dbc5a  movaps xmm5, xmm8
0000790c663dbc5e  addpd xmm5, xmm15
0000790c663dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000790c663dbc68  ptest xmm4, xmm4
0000790c663dbc6d  jnz 0x0000790C663DD0FA
0000790c663dbc73  movaps xmm8, [r15+0x1B0]
0000790c663dbc7b  movaps xmm4, xmm9
0000790c663dbc7f  addpd xmm4, xmm8
0000790c663dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000790c663dbc89  ptest xmm2, xmm2
0000790c663dbc8e  jnz 0x0000790C663DD23C
0000790c663dbc94  movaps xmm9, xmm10
0000790c663dbc98  addpd xmm9, xmm8
0000790c663dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000790c663dbca3  ptest xmm2, xmm2
0000790c663dbca8  jnz 0x0000790C663DD37E
0000790c663dbcae  movaps xmm10, [r15+0x2F0]
0000790c663dbcb6  vmovaps [rsp+0x90], xmm10
0000790c663dbcbf  vmovaps xmm8, [rsp+0x90]
0000790c663dbcc8  por xmm10, xmm8
0000790c663dbccd  movaps xmm8, [r15+0x2E0]
0000790c663dbcd5  vmovaps [rsp+0x90], xmm8
0000790c663dbcde  vmovaps xmm2, [rsp+0x90]
0000790c663dbce7  por xmm8, xmm2
0000790c663dbcec  movaps xmm2, [r15+0x2D0]
0000790c663dbcf4  vmovaps [rsp+0x90], xmm2
0000790c663dbcfd  vmovaps [rsp+0xA0], xmm1
0000790c663dbd06  vmovaps xmm1, [rsp+0x90]
0000790c663dbd0f  por xmm2, xmm1
0000790c663dbd13  movaps xmm1, [r15+0x200]
0000790c663dbd1b  vmovaps [rsp+0x90], xmm1
0000790c663dbd24  vmovaps [rsp+0xB0], xmm15
0000790c663dbd2d  vmovaps xmm15, [rsp+0x90]
0000790c663dbd36  por xmm1, xmm15
0000790c663dbd3b  movaps xmm15, [r15+0x1C0]
0000790c663dbd43  vmovaps [rsp+0x90], xmm15
0000790c663dbd4c  vmovaps [rsp+0xC0], xmm1
0000790c663dbd55  vmovaps xmm1, [rsp+0x90]
0000790c663dbd5e  por xmm15, xmm1
0000790c663dbd63  movaps xmm1, [r15+0x190]
0000790c663dbd6b  vmovaps [rsp+0x90], xmm1
0000790c663dbd74  vmovaps [rsp+0xD0], xmm15
0000790c663dbd7d  vmovaps xmm15, [rsp+0x90]
0000790c663dbd86  por xmm1, xmm15
0000790c663dbd8b  movaps xmm15, [r15+0x300]
0000790c663dbd93  vmovaps [rsp+0x90], xmm15
0000790c663dbd9c  vmovaps [rsp+0xE0], xmm1
0000790c663dbda5  vmovaps xmm1, [rsp+0x90]
0000790c663dbdae  por xmm15, xmm1
0000790c663dbdb3  mov rax, [rsp+0x80]
0000790c663dbdbb  lea r12, [rax+0xA0]
0000790c663dbdc2  movups xmm1, [r13+r12*1]
0000790c663dbdc8  lea r12, [rax+0xB0]
0000790c663dbdcf  vmovaps [rsp+0x80], xmm1
0000790c663dbdd8  movups xmm1, [r13+r12*1]
0000790c663dbdde  vmovaps [rsp+0x90], xmm1
0000790c663dbde7  vmovaps [rsp+0xF0], xmm15
0000790c663dbdf0  vmovaps xmm15, [rsp+0xB0]
0000790c663dbdf9  vmovaps [rsp+0xB0], xmm14
0000790c663dbe02  movaps xmm1, xmm6
0000790c663dbe05  addpd xmm1, xmm15
0000790c663dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000790c663dbe0f  ptest xmm14, xmm14
0000790c663dbe15  jnz 0x0000790C663DD4D6
0000790c663dbe1b  lea r12, [rax+0xF0]
0000790c663dbe22  movups xmm15, [r13+r12*1]
0000790c663dbe28  movaps xmm14, xmm4
0000790c663dbe2c  addpd xmm14, xmm3
0000790c663dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000790c663dbe37  ptest xmm6, xmm6
0000790c663dbe3c  jnz 0x0000790C663DD621
0000790c663dbe42  movaps xmm6, xmm9
0000790c663dbe46  addpd xmm6, xmm7
0000790c663dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000790c663dbe4f  ptest xmm4, xmm4
0000790c663dbe54  jnz 0x0000790C663DD763
0000790c663dbe5a  vmovaps xmm9, [rsp+0x70]
0000790c663dbe60  vpermilpd xmm9, xmm9, 0x00
0000790c663dbe66  vmovaps xmm4, [rsp+0x90]
0000790c663dbe6f  movaps xmm7, xmm4
0000790c663dbe72  mulpd xmm7, xmm9
0000790c663dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000790c663dbe7c  ptest xmm3, xmm3
0000790c663dbe81  jnz 0x0000790C663DD8A4
0000790c663dbe87  vmovaps xmm9, [rsp+0x50]
0000790c663dbe8d  vpermilpd xmm9, xmm9, 0x00
0000790c663dbe93  movaps xmm4, xmm15
0000790c663dbe97  mulpd xmm4, xmm9
0000790c663dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000790c663dbea1  ptest xmm3, xmm3
0000790c663dbea6  jnz 0x0000790C663DD9E5
0000790c663dbeac  lea r12, [rax+0xE0]
0000790c663dbeb3  movups xmm15, [r13+r12*1]
0000790c663dbeb9  vmovaps xmm9, [rsp+0x70]
0000790c663dbebf  vpermilpd xmm9, xmm9, 0x00
0000790c663dbec5  vmovaps [rsp+0x70], xmm1
0000790c663dbecb  vmovaps xmm1, [rsp+0x80]
0000790c663dbed4  vmovaps [rsp+0x80], xmm15
0000790c663dbedd  movaps xmm3, xmm1
0000790c663dbee0  mulpd xmm3, xmm9
0000790c663dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000790c663dbeea  ptest xmm15, xmm15
0000790c663dbef0  jnz 0x0000790C663DDB31
0000790c663dbef6  vmovaps xmm1, [rsp+0xF0]
0000790c663dbeff  vmovaps xmm15, [rsp+0xF0]
0000790c663dbf08  por xmm1, xmm15
0000790c663dbf0d  movaps [r15+0x300], xmm1
0000790c663dbf15  vmovaps xmm15, [rsp+0xE0]
0000790c663dbf1e  vmovaps xmm9, [rsp+0xE0]
0000790c663dbf27  por xmm15, xmm9
0000790c663dbf2c  movaps [r15+0x190], xmm15
0000790c663dbf34  vmovaps xmm9, [rsp+0x50]
0000790c663dbf3a  vpermilpd xmm9, xmm9, 0x00
0000790c663dbf40  vmovaps [rsp+0x90], xmm1
0000790c663dbf49  vmovaps [rsp+0xE0], xmm15
0000790c663dbf52  vmovaps xmm15, [rsp+0x80]
0000790c663dbf5b  vmovaps [rsp+0x80], xmm14
0000790c663dbf64  movaps xmm1, xmm15
0000790c663dbf68  mulpd xmm1, xmm9
0000790c663dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000790c663dbf72  ptest xmm14, xmm14
0000790c663dbf78  jnz 0x0000790C663DDC72
0000790c663dbf7e  lea r12, [rax+0x90]
0000790c663dbf85  movups xmm15, [r13+r12*1]
0000790c663dbf8b  vmovaps xmm14, [rsp+0xD0]
0000790c663dbf94  vmovaps xmm9, [rsp+0xD0]
0000790c663dbf9d  por xmm14, xmm9
0000790c663dbfa2  movaps [r15+0x1C0], xmm14
0000790c663dbfaa  vmovaps xmm9, [rsp+0xC0]
0000790c663dbfb3  vmovaps [rsp+0xD0], xmm1
0000790c663dbfbc  vmovaps xmm1, [rsp+0xC0]
0000790c663dbfc5  por xmm9, xmm1
0000790c663dbfca  movaps [r15+0x200], xmm9
0000790c663dbfd2  vmovaps [rsp+0xC0], xmm2
0000790c663dbfdb  vmovaps xmm1, [rsp+0xC0]
0000790c663dbfe4  por xmm2, xmm1
0000790c663dbfe8  movaps [r15+0x2D0], xmm2
0000790c663dbff0  vmovaps [rsp+0xC0], xmm8
0000790c663dbff9  vmovaps xmm1, [rsp+0xC0]
0000790c663dc002  por xmm8, xmm1
0000790c663dc007  movaps [r15+0x2E0], xmm8
0000790c663dc00f  vmovaps [rsp+0xC0], xmm15
0000790c663dc018  movaps xmm1, xmm5
0000790c663dc01b  addpd xmm1, xmm7
0000790c663dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000790c663dc024  ptest xmm15, xmm15
0000790c663dc02a  jnz 0x0000790C663DDDBE
0000790c663dc030  vmovaps xmm15, [rsp+0x50]
0000790c663dc036  vpermilpd xmm15, xmm15, 0x00
0000790c663dc03c  vmovaps xmm5, [rsp+0xC0]
0000790c663dc045  vmovaps [rsp+0xC0], xmm1
0000790c663dc04e  movaps xmm7, xmm5
0000790c663dc051  mulpd xmm7, xmm15
0000790c663dc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000790c663dc05b  ptest xmm1, xmm1
0000790c663dc060  jnz 0x0000790C663DDEFE
0000790c663dc066  lea r12, [rax+0x80]
0000790c663dc06d  movups xmm1, [r13+r12*1]
0000790c663dc073  vmovaps xmm5, [rsp+0x70]
0000790c663dc079  vmovaps [rsp+0x70], xmm1
0000790c663dc07f  movaps xmm15, xmm5
0000790c663dc083  addpd xmm15, xmm3
0000790c663dc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000790c663dc08e  ptest xmm1, xmm1
0000790c663dc093  jnz 0x0000790C663DE049
0000790c663dc099  vmovaps xmm5, [rsp+0x80]
0000790c663dc0a2  movaps xmm1, xmm5
0000790c663dc0a5  addpd xmm1, xmm4
0000790c663dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000790c663dc0ae  ptest xmm3, xmm3
0000790c663dc0b3  jnz 0x0000790C663DE18B
0000790c663dc0b9  vmovaps [rsp+0x80], xmm10
0000790c663dc0c2  vmovaps xmm5, [rsp+0x80]
0000790c663dc0cb  por xmm10, xmm5
0000790c663dc0d0  movaps [r15+0x2F0], xmm10
0000790c663dc0d8  vmovaps xmm5, [rsp+0x50]
0000790c663dc0de  vpermilpd xmm5, xmm5, 0x00
0000790c663dc0e4  vmovaps xmm3, [rsp+0x70]
0000790c663dc0ea  vmovaps [rsp+0x50], xmm1
0000790c663dc0f0  movaps xmm4, xmm3
0000790c663dc0f3  mulpd xmm4, xmm5
0000790c663dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000790c663dc0fc  ptest xmm1, xmm1
0000790c663dc101  jnz 0x0000790C663DE2CB
0000790c663dc107  lea r12, [rax+0xD0]
0000790c663dc10e  movups xmm1, [r13+r12*1]
0000790c663dc114  vmovaps xmm3, [rsp+0xD0]
0000790c663dc11d  vmovaps [rsp+0x70], xmm1
0000790c663dc123  movaps xmm5, xmm6
0000790c663dc126  addpd xmm5, xmm3
0000790c663dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000790c663dc12f  ptest xmm1, xmm1
0000790c663dc134  jnz 0x0000790C663DE415
0000790c663dc13a  vmovaps xmm1, [rsp+0x60]
0000790c663dc140  vpermilpd xmm1, xmm1, 0x00
0000790c663dc146  movaps xmm6, xmm9
0000790c663dc14a  mulpd xmm6, xmm1
0000790c663dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000790c663dc153  ptest xmm3, xmm3
0000790c663dc158  jnz 0x0000790C663DE555
0000790c663dc15e  movaps [r15+0x260], xmm6
0000790c663dc166  vxorps xmm1, xmm1, xmm1
0000790c663dc16a  vpbroadcastq xmm1, xmm1
0000790c663dc16f  movaps [r15+0x1B0], xmm1
0000790c663dc177  vmovaps xmm1, [rsp+0x60]
0000790c663dc17d  vpermilpd xmm1, xmm1, 0x00
0000790c663dc183  vmovaps xmm3, [rsp+0x70]
0000790c663dc189  vmovaps [rsp+0x70], xmm15
0000790c663dc18f  movaps xmm9, xmm3
0000790c663dc193  mulpd xmm9, xmm1
0000790c663dc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000790c663dc19e  ptest xmm15, xmm15
0000790c663dc1a4  jnz 0x0000790C663DE696
0000790c663dc1aa  lea r12, [rax+0xC0]
0000790c663dc1b1  movups xmm1, [r13+r12*1]
0000790c663dc1b7  vmovaps xmm3, [rsp+0xC0]
0000790c663dc1c0  vmovaps [rsp+0x80], xmm1
0000790c663dc1c9  movaps xmm15, xmm3
0000790c663dc1cd  addpd xmm15, xmm7
0000790c663dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000790c663dc1d8  ptest xmm1, xmm1
0000790c663dc1dd  jnz 0x0000790C663DE7E2
0000790c663dc1e3  vmovaps [rsp+0xC0], xmm13
0000790c663dc1ec  vmovaps xmm1, [rsp+0xC0]
0000790c663dc1f5  por xmm13, xmm1
0000790c663dc1fa  movaps [r15+0x270], xmm13
0000790c663dc202  vmovaps xmm1, [rsp+0xB0]
0000790c663dc20b  vmovaps xmm7, [rsp+0xB0]
0000790c663dc214  por xmm1, xmm7
0000790c663dc218  movaps [r15+0x1A0], xmm1
0000790c663dc220  vmovaps xmm1, [rsp+0x60]
0000790c663dc226  vpermilpd xmm1, xmm1, 0x00
0000790c663dc22c  vmovaps [rsp+0xB0], xmm1
0000790c663dc235  vmovaps xmm1, [rsp+0x80]
0000790c663dc23e  vmovaps [rsp+0x80], xmm15
0000790c663dc247  vmovaps xmm15, [rsp+0xB0]
0000790c663dc250  vmovaps [rsp+0xB0], xmm14
0000790c663dc259  movaps xmm3, xmm1
0000790c663dc25c  mulpd xmm3, xmm15
0000790c663dc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000790c663dc266  ptest xmm14, xmm14
0000790c663dc26c  jnz 0x0000790C663DE924
0000790c663dc272  lea r12, [rax+0x20]
0000790c663dc276  movups xmm1, [r13+r12*1]
0000790c663dc27c  movaps [r15+0x110], xmm1
0000790c663dc284  vmovaps xmm14, [rsp+0x70]
0000790c663dc28a  vmovaps [rsp+0x70], xmm1
0000790c663dc290  movaps xmm15, xmm14
0000790c663dc294  addpd xmm15, xmm4
0000790c663dc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000790c663dc29f  ptest xmm1, xmm1
0000790c663dc2a4  jnz 0x0000790C663DEA6F
0000790c663dc2aa  vmovaps xmm1, [rsp+0x60]
0000790c663dc2b0  vpermilpd xmm1, xmm1, 0x00
0000790c663dc2b6  movaps xmm14, xmm2
0000790c663dc2ba  mulpd xmm14, xmm1
0000790c663dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000790c663dc2c5  ptest xmm4, xmm4
0000790c663dc2ca  jnz 0x0000790C663DEBB2
0000790c663dc2d0  vmovaps xmm4, [rsp+0x50]
0000790c663dc2d6  movaps xmm1, xmm4
0000790c663dc2d9  addpd xmm1, xmm9
0000790c663dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000790c663dc2e3  ptest xmm2, xmm2
0000790c663dc2e8  jnz 0x0000790C663DECF4
0000790c663dc2ee  vmovaps xmm9, [rsp+0x30]
0000790c663dc2f4  vpermilpd xmm9, xmm9, 0x00
0000790c663dc2fa  vmovaps xmm2, [rsp+0x70]
0000790c663dc300  vmovaps [rsp+0x50], xmm1
0000790c663dc306  movaps xmm4, xmm2
0000790c663dc309  mulpd xmm4, xmm9
0000790c663dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000790c663dc313  ptest xmm1, xmm1
0000790c663dc318  jnz 0x0000790C663DEE35
0000790c663dc31e  vmovaps xmm1, [rsp+0x30]
0000790c663dc324  vpermilpd xmm1, xmm1, 0x00
0000790c663dc32a  vmovaps xmm2, [rsp+0x90]
0000790c663dc333  vmovaps [rsp+0x60], xmm15
0000790c663dc339  movaps xmm9, xmm2
0000790c663dc33d  mulpd xmm9, xmm1
0000790c663dc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000790c663dc348  ptest xmm15, xmm15
0000790c663dc34e  jnz 0x0000790C663DEF76
0000790c663dc354  vmovaps xmm15, [rsp+0x80]
0000790c663dc35d  movaps xmm1, xmm15
0000790c663dc361  addpd xmm1, xmm6
0000790c663dc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000790c663dc36a  ptest xmm2, xmm2
0000790c663dc36f  jnz 0x0000790C663DF0B8
0000790c663dc375  movaps xmm15, xmm5
0000790c663dc379  addpd xmm15, xmm3
0000790c663dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000790c663dc384  ptest xmm6, xmm6
0000790c663dc389  jnz 0x0000790C663DF1F9
0000790c663dc38f  vmovaps xmm6, [rsp+0x30]
0000790c663dc395  vpermilpd xmm6, xmm6, 0x00
0000790c663dc39b  movaps xmm5, xmm8
0000790c663dc39f  mulpd xmm5, xmm6
0000790c663dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000790c663dc3a8  ptest xmm3, xmm3
0000790c663dc3ad  jnz 0x0000790C663DF33B
0000790c663dc3b3  vmovaps xmm8, [rsp+0x30]
0000790c663dc3b9  vpermilpd xmm8, xmm8, 0x00
0000790c663dc3bf  movaps xmm6, xmm10
0000790c663dc3c3  mulpd xmm6, xmm8
0000790c663dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000790c663dc3cd  ptest xmm3, xmm3
0000790c663dc3d2  jnz 0x0000790C663DF47C
0000790c663dc3d8  vmovaps xmm8, [rsp+0x60]
0000790c663dc3de  movaps xmm10, xmm8
0000790c663dc3e2  addpd xmm10, xmm14
0000790c663dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000790c663dc3ed  ptest xmm3, xmm3
0000790c663dc3f2  jnz 0x0000790C663DF5BE
0000790c663dc3f8  vmovaps xmm8, [rsp+0x50]
0000790c663dc3fe  movaps xmm14, xmm8
0000790c663dc402  addpd xmm14, xmm4
0000790c663dc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000790c663dc40d  ptest xmm3, xmm3
0000790c663dc412  jnz 0x0000790C663DF702
0000790c663dc418  vmovaps xmm8, [rsp+0x40]
0000790c663dc41e  vpermilpd xmm8, xmm8, 0x00
0000790c663dc424  movaps xmm4, xmm13
0000790c663dc428  mulpd xmm4, xmm8
0000790c663dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000790c663dc432  ptest xmm3, xmm3
0000790c663dc437  jnz 0x0000790C663DF845
0000790c663dc43d  movaps xmm13, xmm15
0000790c663dc441  addpd xmm13, xmm9
0000790c663dc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000790c663dc44c  ptest xmm8, xmm8
0000790c663dc452  jnz 0x0000790C663DF987
0000790c663dc458  movaps xmm15, xmm1
0000790c663dc45c  addpd xmm15, xmm5
0000790c663dc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000790c663dc467  ptest xmm9, xmm9
0000790c663dc46d  jnz 0x0000790C663DFACB
0000790c663dc473  vmovaps [rsp+0x30], xmm11
0000790c663dc479  vmovaps xmm1, [rsp+0x30]
0000790c663dc47f  por xmm11, xmm1
0000790c663dc484  movaps [r15+0x250], xmm11
0000790c663dc48c  vmovaps [rsp+0x30], xmm12
0000790c663dc492  vmovaps xmm1, [rsp+0x30]
0000790c663dc498  por xmm12, xmm1
0000790c663dc49d  movaps [r15+0x2A0], xmm12
0000790c663dc4a5  vmovaps xmm1, [rsp+0xA0]
0000790c663dc4ae  vmovaps xmm11, [rsp+0xA0]
0000790c663dc4b7  por xmm1, xmm11
0000790c663dc4bc  movaps [r15+0x1D0], xmm1
0000790c663dc4c4  lea r12, [rax+0x40]
0000790c663dc4c8  movups xmm1, [r13+r12*1]
0000790c663dc4ce  movaps [r15+0x2C0], xmm1
0000790c663dc4d6  vmovaps xmm11, [rsp+0x40]
0000790c663dc4dc  vpermilpd xmm11, xmm11, 0x00
0000790c663dc4e2  vmovaps xmm8, [rsp+0xE0]
0000790c663dc4eb  movaps xmm9, xmm8
0000790c663dc4ef  mulpd xmm9, xmm11
0000790c663dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000790c663dc4fa  ptest xmm5, xmm5
0000790c663dc4ff  jnz 0x0000790C663DFC17
0000790c663dc505  movaps xmm11, xmm10
0000790c663dc509  addpd xmm11, xmm6
0000790c663dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000790c663dc514  ptest xmm8, xmm8
0000790c663dc51a  jnz 0x0000790C663DFD5B
0000790c663dc520  movaps xmm10, xmm14
0000790c663dc524  addpd xmm10, xmm4
0000790c663dc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000790c663dc52f  ptest xmm8, xmm8
0000790c663dc535  jnz 0x0000790C663DFE9E
0000790c663dc53b  vmovaps xmm14, [rsp+0x40]
0000790c663dc541  vpermilpd xmm14, xmm14, 0x00
0000790c663dc547  movaps xmm8, xmm1
0000790c663dc54b  mulpd xmm8, xmm14
0000790c663dc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000790c663dc556  ptest xmm6, xmm6
0000790c663dc55b  jnz 0x0000790C663DFFE1
0000790c663dc561  movaps xmm1, [r15+0x2B0]
0000790c663dc569  vmovaps xmm14, [rsp+0x40]
0000790c663dc56f  vpermilpd xmm14, xmm14, 0x00
0000790c663dc575  movaps xmm6, xmm1
0000790c663dc578  mulpd xmm6, xmm14
0000790c663dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000790c663dc582  ptest xmm5, xmm5
0000790c663dc587  jnz 0x0000790C663E0124
0000790c663dc58d  vmovaps xmm1, [rsp+0x10]
0000790c663dc593  vpermilpd xmm1, xmm1, 0x00
0000790c663dc599  movaps xmm14, xmm12
0000790c663dc59d  mulpd xmm14, xmm1
0000790c663dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000790c663dc5a8  ptest xmm5, xmm5
0000790c663dc5ad  jnz 0x0000790C663E0265
0000790c663dc5b3  movaps xmm1, xmm13
0000790c663dc5b7  addpd xmm1, xmm9
0000790c663dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000790c663dc5c1  ptest xmm12, xmm12
0000790c663dc5c7  jnz 0x0000790C663E03A8
0000790c663dc5cd  vmovaps xmm13, [rsp+0x10]
0000790c663dc5d3  vpermilpd xmm13, xmm13, 0x00
0000790c663dc5d9  movaps xmm12, xmm7
0000790c663dc5dd  mulpd xmm12, xmm13
0000790c663dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000790c663dc5e8  ptest xmm9, xmm9
0000790c663dc5ee  jnz 0x0000790C663E04EA
0000790c663dc5f4  movaps xmm13, xmm15
0000790c663dc5f8  addpd xmm13, xmm8
0000790c663dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000790c663dc603  ptest xmm9, xmm9
0000790c663dc609  jnz 0x0000790C663E062D
0000790c663dc60f  movaps xmm15, [r15+0x290]
0000790c663dc617  vmovaps xmm9, [rsp+0x10]
0000790c663dc61d  vpermilpd xmm9, xmm9, 0x00
0000790c663dc623  movaps xmm8, xmm15
0000790c663dc627  mulpd xmm8, xmm9
0000790c663dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000790c663dc632  ptest xmm7, xmm7
0000790c663dc637  jnz 0x0000790C663E0771
0000790c663dc63d  movaps xmm15, xmm11
0000790c663dc641  addpd xmm15, xmm6
0000790c663dc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000790c663dc64c  ptest xmm9, xmm9
0000790c663dc652  jnz 0x0000790C663E08B5
0000790c663dc658  movaps xmm11, [r15+0x1E0]
0000790c663dc660  vmovaps xmm9, [rsp+0x10]
0000790c663dc666  vpermilpd xmm9, xmm9, 0x00
0000790c663dc66c  movaps xmm7, xmm11
0000790c663dc670  mulpd xmm7, xmm9
0000790c663dc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000790c663dc67a  ptest xmm6, xmm6
0000790c663dc67f  jnz 0x0000790C663E09F8
0000790c663dc685  movaps xmm11, xmm10
0000790c663dc689  addpd xmm11, xmm14
0000790c663dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000790c663dc694  ptest xmm9, xmm9
0000790c663dc69a  jnz 0x0000790C663E0B3A
0000790c663dc6a0  lea r12, [rax+0x70]
0000790c663dc6a4  movups xmm14, [r13+r12*1]
0000790c663dc6aa  movaps [r15+0x240], xmm14
0000790c663dc6b2  movaps xmm10, xmm1
0000790c663dc6b6  addpd xmm10, xmm12
0000790c663dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000790c663dc6c1  ptest xmm9, xmm9
0000790c663dc6c7  jnz 0x0000790C663E0C88
0000790c663dc6cd  movaps [r15+0x170], xmm10
0000790c663dc6d5  vmovaps xmm1, [rsp+0x20]
0000790c663dc6db  vpermilpd xmm1, xmm1, 0x00
0000790c663dc6e1  movaps xmm12, xmm14
0000790c663dc6e5  mulpd xmm12, xmm1
0000790c663dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000790c663dc6f0  ptest xmm9, xmm9
0000790c663dc6f6  jnz 0x0000790C663E0DCB
0000790c663dc6fc  vmovaps xmm1, [rsp+0x20]
0000790c663dc702  vpermilpd xmm1, xmm1, 0x00
0000790c663dc708  vmovaps xmm9, [rsp+0xB0]
0000790c663dc711  movaps xmm14, xmm9
0000790c663dc715  mulpd xmm14, xmm1
0000790c663dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000790c663dc720  ptest xmm6, xmm6
0000790c663dc725  jnz 0x0000790C663E0F0E
0000790c663dc72b  movaps [r15+0x180], xmm14
0000790c663dc733  movaps xmm1, xmm13
0000790c663dc737  addpd xmm1, xmm8
0000790c663dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000790c663dc741  ptest xmm9, xmm9
0000790c663dc747  jnz 0x0000790C663E1051
0000790c663dc74d  movaps [r15+0x210], xmm1
0000790c663dc755  movups xmm13, [r13+rax*1]
0000790c663dc75b  lea r12, [rax+0x10]
0000790c663dc75f  movups xmm9, [r13+r12*1]
0000790c663dc765  movaps [r15+0x230], xmm9
0000790c663dc76d  movaps xmm8, xmm15
0000790c663dc771  addpd xmm8, xmm7
0000790c663dc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000790c663dc77c  ptest xmm6, xmm6
0000790c663dc781  jnz 0x0000790C663E11A7
0000790c663dc787  movaps [r15+0x130], xmm8
0000790c663dc78f  vmovaps xmm15, [rsp+0x20]
0000790c663dc795  vpermilpd xmm15, xmm15, 0x00
0000790c663dc79b  movaps xmm7, xmm9
0000790c663dc79f  mulpd xmm7, xmm15
0000790c663dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000790c663dc7a9  ptest xmm6, xmm6
0000790c663dc7ae  jnz 0x0000790C663E12EA
0000790c663dc7b4  movaps [r15+0x220], xmm7
0000790c663dc7bc  vmovaps xmm15, [rsp+0x20]
0000790c663dc7c2  vpermilpd xmm15, xmm15, 0x00
0000790c663dc7c8  movaps xmm9, xmm13
0000790c663dc7cc  mulpd xmm9, xmm15
0000790c663dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000790c663dc7d7  ptest xmm6, xmm6
0000790c663dc7dc  jnz 0x0000790C663E142C
0000790c663dc7e2  movaps xmm15, xmm11
0000790c663dc7e6  addpd xmm15, xmm12
0000790c663dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000790c663dc7f1  ptest xmm13, xmm13
0000790c663dc7f7  jnz 0x0000790C663E1570
0000790c663dc7fd  movaps [r15+0x140], xmm15
0000790c663dc805  movaps xmm13, xmm10
0000790c663dc809  addpd xmm13, xmm14
0000790c663dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000790c663dc814  ptest xmm12, xmm12
0000790c663dc81a  jnz 0x0000790C663E16B4
0000790c663dc820  movaps [r15+0x150], xmm13
0000790c663dc828  movaps xmm14, xmm1
0000790c663dc82c  addpd xmm14, xmm7
0000790c663dc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000790c663dc837  ptest xmm12, xmm12
0000790c663dc83d  jnz 0x0000790C663E17F8
0000790c663dc843  movaps [r15+0x160], xmm14
0000790c663dc84b  movaps xmm1, xmm8
0000790c663dc84f  addpd xmm1, xmm9
0000790c663dc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000790c663dc859  ptest xmm12, xmm12
0000790c663dc85f  jnz 0x0000790C663E193A
0000790c663dc865  movaps [r15+0x120], xmm1
0000790c663dc86d  movups [r13+r14*1], xmm15
0000790c663dc873  lea rax, [r14+0x10]
0000790c663dc877  movups [r13+rax*1], xmm13
0000790c663dc87d  lea rax, [r14+0x20]
0000790c663dc881  movups [r13+rax*1], xmm14
0000790c663dc887  lea rax, [r14+0x30]
0000790c663dc88b  movups [r13+rax*1], xmm1
0000790c663dc891  mov eax, [r15+0x108]
0000790c663dc898  sahf
0000790c663dc899  jnz 0x0000790C663DC8CB
0000790c663dc89b  cmp dword ptr [r15+0x318], 0x00
0000790c663dc8a3  jz 0x0000790C663DB900
0000790c663dc8a9  nop [rax+rax*1], ax
0000790c663dc8b2  nop [rax+rax*1], eax
0000790c663dc8ba  mov eax, 0x410444
0000790c663dc8bf  mov [r15+0x100], rax
0000790c663dc8c6  jmp 0x0000790C661FE110
0000790c663dc8cb  cmp dword ptr [r15+0x318], 0x00
0000790c663dc8d3  jz 0x0000790C663D57E0
0000790c663dc8d9  nop [rax+rax*1], ax
0000790c663dc8e2  nop [rax+rax*1], eax
0000790c663dc8ea  mov eax, 0x410278
0000790c663dc8ef  mov [r15+0x100], rax
0000790c663dc8f6  jmp 0x0000790C661FE110
0000790c663dc8fb  int3
0000790c663dc8fc  call 0x0000790C662E27E0
0000790c663dc901  jmp 0x0000790C663DB9DF
0000790c663dc906  call 0x0000790C662E1570
0000790c663dc90b  jmp 0x0000790C663DB9E8
0000790c663dc910  call 0x0000790C662E27E0
0000790c663dc915  jmp 0x0000790C663DBA44
0000790c663dc91a  call 0x0000790C662E1570
0000790c663dc91f  jmp 0x0000790C663DBA4D
0000790c663dc924  call 0x0000790C662E27E0
0000790c663dc929  jmp 0x0000790C663DBA90
0000790c663dc92e  call 0x0000790C662E1570
0000790c663dc933  jmp 0x0000790C663DBA99
0000790c663dc938  call 0x0000790C6620DC20
0000790c663dc93d  jmp 0x0000790C663DBAD8
0000790c663dc942  call 0x0000790C662D59C0
0000790c663dc947  jmp 0x0000790C663DBAEB
0000790c663dc94c  call 0x0000790C662E0E30
0000790c663dc951  jmp 0x0000790C663DBB09
0000790c663dc956  call 0x0000790C662DFBC0
0000790c663dc95b  jmp 0x0000790C663DBB13
0000790c663dc960  call 0x0000790C662DE950
0000790c663dc965  jmp 0x0000790C663DBB1D
0000790c663dc96a  sub rsp, 0x08
0000790c663dc96e  push rax
0000790c663dc96f  push rcx
0000790c663dc970  push rdx
0000790c663dc971  push rdi
0000790c663dc972  push rsi
0000790c663dc973  push r8
0000790c663dc975  push r9
0000790c663dc977  push r10
0000790c663dc979  push r11
0000790c663dc97b  sub rsp, 0xF0
0000790c663dc982  vmovaps [rsp], xmm0
0000790c663dc987  vmovaps [rsp+0x10], xmm1
0000790c663dc98d  vmovaps [rsp+0x20], xmm2
0000790c663dc993  vmovaps [rsp+0x30], xmm3
0000790c663dc999  vmovaps [rsp+0x40], xmm4
0000790c663dc99f  vmovaps [rsp+0x50], xmm5
0000790c663dc9a5  vmovaps [rsp+0x60], xmm6
0000790c663dc9ab  vmovaps [rsp+0x70], xmm7
0000790c663dc9b1  vmovaps [rsp+0x80], xmm9
0000790c663dc9ba  vmovaps [rsp+0x90], xmm10
0000790c663dc9c3  vmovaps [rsp+0xA0], xmm11
0000790c663dc9cc  vmovaps [rsp+0xB0], xmm12
0000790c663dc9d5  vmovaps [rsp+0xC0], xmm13
0000790c663dc9de  vmovaps [rsp+0xD0], xmm14
0000790c663dc9e7  vmovaps [rsp+0xE0], xmm15
0000790c663dc9f0  sub rsp, 0x30
0000790c663dc9f4  movaps [rsp], xmm8
0000790c663dc9f9  movaps [rsp+0x10], xmm12
0000790c663dc9ff  movaps [rsp+0x20], xmm15
0000790c663dca05  lea rdi, [rsp]
0000790c663dca09  mov esi, 0x00
0000790c663dca0e  mov rax, 0x631C1759F530
0000790c663dca18  call rax
0000790c663dca1a  movaps xmm8, [rsp]
0000790c663dca1f  add rsp, 0x30
0000790c663dca23  vmovaps xmm0, [rsp]
0000790c663dca28  vmovaps xmm1, [rsp+0x10]
0000790c663dca2e  vmovaps xmm2, [rsp+0x20]
0000790c663dca34  vmovaps xmm3, [rsp+0x30]
0000790c663dca3a  vmovaps xmm4, [rsp+0x40]
0000790c663dca40  vmovaps xmm5, [rsp+0x50]
0000790c663dca46  vmovaps xmm6, [rsp+0x60]
0000790c663dca4c  vmovaps xmm7, [rsp+0x70]
0000790c663dca52  vmovaps xmm9, [rsp+0x80]
0000790c663dca5b  vmovaps xmm10, [rsp+0x90]
0000790c663dca64  vmovaps xmm11, [rsp+0xA0]
0000790c663dca6d  vmovaps xmm12, [rsp+0xB0]
0000790c663dca76  vmovaps xmm13, [rsp+0xC0]
0000790c663dca7f  vmovaps xmm14, [rsp+0xD0]
0000790c663dca88  vmovaps xmm15, [rsp+0xE0]
0000790c663dca91  add rsp, 0xF0
0000790c663dca98  pop r11
0000790c663dca9a  pop r10
0000790c663dca9c  pop r9
0000790c663dca9e  pop r8
0000790c663dcaa0  pop rsi
0000790c663dcaa1  pop rdi
0000790c663dcaa2  pop rdx
0000790c663dcaa3  pop rcx
0000790c663dcaa4  pop rax
0000790c663dcaa5  add rsp, 0x08
0000790c663dcaa9  jmp 0x0000790C663DBB47
0000790c663dcaae  sub rsp, 0x08
0000790c663dcab2  push rax
0000790c663dcab3  push rcx
0000790c663dcab4  push rdx
0000790c663dcab5  push rdi
0000790c663dcab6  push rsi
0000790c663dcab7  push r8
0000790c663dcab9  push r9
0000790c663dcabb  push r10
0000790c663dcabd  push r11
0000790c663dcabf  sub rsp, 0xF0
0000790c663dcac6  vmovaps [rsp], xmm0
0000790c663dcacb  vmovaps [rsp+0x10], xmm1
0000790c663dcad1  vmovaps [rsp+0x20], xmm2
0000790c663dcad7  vmovaps [rsp+0x30], xmm3
0000790c663dcadd  vmovaps [rsp+0x40], xmm4
0000790c663dcae3  vmovaps [rsp+0x50], xmm5
0000790c663dcae9  vmovaps [rsp+0x60], xmm6
0000790c663dcaef  vmovaps [rsp+0x70], xmm8
0000790c663dcaf5  vmovaps [rsp+0x80], xmm9
0000790c663dcafe  vmovaps [rsp+0x90], xmm10
0000790c663dcb07  vmovaps [rsp+0xA0], xmm11
0000790c663dcb10  vmovaps [rsp+0xB0], xmm12
0000790c663dcb19  vmovaps [rsp+0xC0], xmm13
0000790c663dcb22  vmovaps [rsp+0xD0], xmm14
0000790c663dcb2b  vmovaps [rsp+0xE0], xmm15
0000790c663dcb34  sub rsp, 0x30
0000790c663dcb38  movaps [rsp], xmm7
0000790c663dcb3c  movaps [rsp+0x10], xmm9
0000790c663dcb42  movaps [rsp+0x20], xmm15
0000790c663dcb48  lea rdi, [rsp]
0000790c663dcb4c  mov esi, 0x00
0000790c663dcb51  mov rax, 0x631C1759F530
0000790c663dcb5b  call rax
0000790c663dcb5d  movaps xmm7, [rsp]
0000790c663dcb61  add rsp, 0x30
0000790c663dcb65  vmovaps xmm0, [rsp]
0000790c663dcb6a  vmovaps xmm1, [rsp+0x10]
0000790c663dcb70  vmovaps xmm2, [rsp+0x20]
0000790c663dcb76  vmovaps xmm3, [rsp+0x30]
0000790c663dcb7c  vmovaps xmm4, [rsp+0x40]
0000790c663dcb82  vmovaps xmm5, [rsp+0x50]
0000790c663dcb88  vmovaps xmm6, [rsp+0x60]
0000790c663dcb8e  vmovaps xmm8, [rsp+0x70]
0000790c663dcb94  vmovaps xmm9, [rsp+0x80]
0000790c663dcb9d  vmovaps xmm10, [rsp+0x90]
0000790c663dcba6  vmovaps xmm11, [rsp+0xA0]
0000790c663dcbaf  vmovaps xmm12, [rsp+0xB0]
0000790c663dcbb8  vmovaps xmm13, [rsp+0xC0]
0000790c663dcbc1  vmovaps xmm14, [rsp+0xD0]
0000790c663dcbca  vmovaps xmm15, [rsp+0xE0]
0000790c663dcbd3  add rsp, 0xF0
0000790c663dcbda  pop r11
0000790c663dcbdc  pop r10
0000790c663dcbde  pop r9
0000790c663dcbe0  pop r8
0000790c663dcbe2  pop rsi
0000790c663dcbe3  pop rdi
0000790c663dcbe4  pop rdx
0000790c663dcbe5  pop rcx
0000790c663dcbe6  pop rax
0000790c663dcbe7  add rsp, 0x08
0000790c663dcbeb  jmp 0x0000790C663DBB75
0000790c663dcbf0  sub rsp, 0x08
0000790c663dcbf4  push rax
0000790c663dcbf5  push rcx
0000790c663dcbf6  push rdx
0000790c663dcbf7  push rdi
0000790c663dcbf8  push rsi
0000790c663dcbf9  push r8
0000790c663dcbfb  push r9
0000790c663dcbfd  push r10
0000790c663dcbff  push r11
0000790c663dcc01  sub rsp, 0xF0
0000790c663dcc08  vmovaps [rsp], xmm0
0000790c663dcc0d  vmovaps [rsp+0x10], xmm1
0000790c663dcc13  vmovaps [rsp+0x20], xmm2
0000790c663dcc19  vmovaps [rsp+0x30], xmm3
0000790c663dcc1f  vmovaps [rsp+0x40], xmm4
0000790c663dcc25  vmovaps [rsp+0x50], xmm5
0000790c663dcc2b  vmovaps [rsp+0x60], xmm6
0000790c663dcc31  vmovaps [rsp+0x70], xmm7
0000790c663dcc37  vmovaps [rsp+0x80], xmm8
0000790c663dcc40  vmovaps [rsp+0x90], xmm10
0000790c663dcc49  vmovaps [rsp+0xA0], xmm11
0000790c663dcc52  vmovaps [rsp+0xB0], xmm12
0000790c663dcc5b  vmovaps [rsp+0xC0], xmm13
0000790c663dcc64  vmovaps [rsp+0xD0], xmm14
0000790c663dcc6d  vmovaps [rsp+0xE0], xmm15
0000790c663dcc76  sub rsp, 0x30
0000790c663dcc7a  movaps [rsp], xmm9
0000790c663dcc7f  movaps [rsp+0x10], xmm12
0000790c663dcc85  movaps [rsp+0x20], xmm10
0000790c663dcc8b  lea rdi, [rsp]
0000790c663dcc8f  mov esi, 0x00
0000790c663dcc94  mov rax, 0x631C1759F530
0000790c663dcc9e  call rax
0000790c663dcca0  movaps xmm9, [rsp]
0000790c663dcca5  add rsp, 0x30
0000790c663dcca9  vmovaps xmm0, [rsp]
0000790c663dccae  vmovaps xmm1, [rsp+0x10]
0000790c663dccb4  vmovaps xmm2, [rsp+0x20]
0000790c663dccba  vmovaps xmm3, [rsp+0x30]
0000790c663dccc0  vmovaps xmm4, [rsp+0x40]
0000790c663dccc6  vmovaps xmm5, [rsp+0x50]
0000790c663dcccc  vmovaps xmm6, [rsp+0x60]
0000790c663dccd2  vmovaps xmm7, [rsp+0x70]
0000790c663dccd8  vmovaps xmm8, [rsp+0x80]
0000790c663dcce1  vmovaps xmm10, [rsp+0x90]
0000790c663dccea  vmovaps xmm11, [rsp+0xA0]
0000790c663dccf3  vmovaps xmm12, [rsp+0xB0]
0000790c663dccfc  vmovaps xmm13, [rsp+0xC0]
0000790c663dcd05  vmovaps xmm14, [rsp+0xD0]
0000790c663dcd0e  vmovaps xmm15, [rsp+0xE0]
0000790c663dcd17  add rsp, 0xF0
0000790c663dcd1e  pop r11
0000790c663dcd20  pop r10
0000790c663dcd22  pop r9
0000790c663dcd24  pop r8
0000790c663dcd26  pop rsi
0000790c663dcd27  pop rdi
0000790c663dcd28  pop rdx
0000790c663dcd29  pop rcx
0000790c663dcd2a  pop rax
0000790c663dcd2b  add rsp, 0x08
0000790c663dcd2f  jmp 0x0000790C663DBB99
0000790c663dcd34  sub rsp, 0x08
0000790c663dcd38  push rax
0000790c663dcd39  push rcx
0000790c663dcd3a  push rdx
0000790c663dcd3b  push rdi
0000790c663dcd3c  push rsi
0000790c663dcd3d  push r8
0000790c663dcd3f  push r9
0000790c663dcd41  push r10
0000790c663dcd43  push r11
0000790c663dcd45  sub rsp, 0xF0
0000790c663dcd4c  vmovaps [rsp], xmm0
0000790c663dcd51  vmovaps [rsp+0x10], xmm1
0000790c663dcd57  vmovaps [rsp+0x20], xmm2
0000790c663dcd5d  vmovaps [rsp+0x30], xmm3
0000790c663dcd63  vmovaps [rsp+0x40], xmm4
0000790c663dcd69  vmovaps [rsp+0x50], xmm5
0000790c663dcd6f  vmovaps [rsp+0x60], xmm6
0000790c663dcd75  vmovaps [rsp+0x70], xmm7
0000790c663dcd7b  vmovaps [rsp+0x80], xmm8
0000790c663dcd84  vmovaps [rsp+0x90], xmm9
0000790c663dcd8d  vmovaps [rsp+0xA0], xmm11
0000790c663dcd96  vmovaps [rsp+0xB0], xmm12
0000790c663dcd9f  vmovaps [rsp+0xC0], xmm13
0000790c663dcda8  vmovaps [rsp+0xD0], xmm14
0000790c663dcdb1  vmovaps [rsp+0xE0], xmm15
0000790c663dcdba  sub rsp, 0x30
0000790c663dcdbe  movaps [rsp], xmm10
0000790c663dcdc3  movaps [rsp+0x10], xmm12
0000790c663dcdc9  movaps [rsp+0x20], xmm11
0000790c663dcdcf  lea rdi, [rsp]
0000790c663dcdd3  mov esi, 0x00
0000790c663dcdd8  mov rax, 0x631C1759F530
0000790c663dcde2  call rax
0000790c663dcde4  movaps xmm10, [rsp]
0000790c663dcde9  add rsp, 0x30
0000790c663dcded  vmovaps xmm0, [rsp]
0000790c663dcdf2  vmovaps xmm1, [rsp+0x10]
0000790c663dcdf8  vmovaps xmm2, [rsp+0x20]
0000790c663dcdfe  vmovaps xmm3, [rsp+0x30]
0000790c663dce04  vmovaps xmm4, [rsp+0x40]
0000790c663dce0a  vmovaps xmm5, [rsp+0x50]
0000790c663dce10  vmovaps xmm6, [rsp+0x60]
0000790c663dce16  vmovaps xmm7, [rsp+0x70]
0000790c663dce1c  vmovaps xmm8, [rsp+0x80]
0000790c663dce25  vmovaps xmm9, [rsp+0x90]
0000790c663dce2e  vmovaps xmm11, [rsp+0xA0]
0000790c663dce37  vmovaps xmm12, [rsp+0xB0]
0000790c663dce40  vmovaps xmm13, [rsp+0xC0]
0000790c663dce49  vmovaps xmm14, [rsp+0xD0]
0000790c663dce52  vmovaps xmm15, [rsp+0xE0]
0000790c663dce5b  add rsp, 0xF0
0000790c663dce62  pop r11
0000790c663dce64  pop r10
0000790c663dce66  pop r9
0000790c663dce68  pop r8
0000790c663dce6a  pop rsi
0000790c663dce6b  pop rdi
0000790c663dce6c  pop rdx
0000790c663dce6d  pop rcx
0000790c663dce6e  pop rax
0000790c663dce6f  add rsp, 0x08
0000790c663dce73  jmp 0x0000790C663DBBB3
0000790c663dce78  sub rsp, 0x08
0000790c663dce7c  push rax
0000790c663dce7d  push rcx
0000790c663dce7e  push rdx
0000790c663dce7f  push rdi
0000790c663dce80  push rsi
0000790c663dce81  push r8
0000790c663dce83  push r9
0000790c663dce85  push r10
0000790c663dce87  push r11
0000790c663dce89  sub rsp, 0xF0
0000790c663dce90  vmovaps [rsp], xmm0
0000790c663dce95  vmovaps [rsp+0x10], xmm1
0000790c663dce9b  vmovaps [rsp+0x20], xmm2
0000790c663dcea1  vmovaps [rsp+0x30], xmm3
0000790c663dcea7  vmovaps [rsp+0x40], xmm4
0000790c663dcead  vmovaps [rsp+0x50], xmm5
0000790c663dceb3  vmovaps [rsp+0x60], xmm7
0000790c663dceb9  vmovaps [rsp+0x70], xmm8
0000790c663dcebf  vmovaps [rsp+0x80], xmm9
0000790c663dcec8  vmovaps [rsp+0x90], xmm10
0000790c663dced1  vmovaps [rsp+0xA0], xmm11
0000790c663dceda  vmovaps [rsp+0xB0], xmm12
0000790c663dcee3  vmovaps [rsp+0xC0], xmm13
0000790c663dceec  vmovaps [rsp+0xD0], xmm14
0000790c663dcef5  vmovaps [rsp+0xE0], xmm15
0000790c663dcefe  sub rsp, 0x30
0000790c663dcf02  movaps [rsp], xmm6
0000790c663dcf06  movaps [rsp+0x10], xmm12
0000790c663dcf0c  movaps [rsp+0x20], xmm11
0000790c663dcf12  lea rdi, [rsp]
0000790c663dcf16  mov esi, 0x00
0000790c663dcf1b  mov rax, 0x631C1759F530
0000790c663dcf25  call rax
0000790c663dcf27  movaps xmm6, [rsp]
0000790c663dcf2b  add rsp, 0x30
0000790c663dcf2f  vmovaps xmm0, [rsp]
0000790c663dcf34  vmovaps xmm1, [rsp+0x10]
0000790c663dcf3a  vmovaps xmm2, [rsp+0x20]
0000790c663dcf40  vmovaps xmm3, [rsp+0x30]
0000790c663dcf46  vmovaps xmm4, [rsp+0x40]
0000790c663dcf4c  vmovaps xmm5, [rsp+0x50]
0000790c663dcf52  vmovaps xmm7, [rsp+0x60]
0000790c663dcf58  vmovaps xmm8, [rsp+0x70]
0000790c663dcf5e  vmovaps xmm9, [rsp+0x80]
0000790c663dcf67  vmovaps xmm10, [rsp+0x90]
0000790c663dcf70  vmovaps xmm11, [rsp+0xA0]
0000790c663dcf79  vmovaps xmm12, [rsp+0xB0]
0000790c663dcf82  vmovaps xmm13, [rsp+0xC0]
0000790c663dcf8b  vmovaps xmm14, [rsp+0xD0]
0000790c663dcf94  vmovaps xmm15, [rsp+0xE0]
0000790c663dcf9d  add rsp, 0xF0
0000790c663dcfa4  pop r11
0000790c663dcfa6  pop r10
0000790c663dcfa8  pop r9
0000790c663dcfaa  pop r8
0000790c663dcfac  pop rsi
0000790c663dcfad  pop rdi
0000790c663dcfae  pop rdx
0000790c663dcfaf  pop rcx
0000790c663dcfb0  pop rax
0000790c663dcfb1  add rsp, 0x08
0000790c663dcfb5  jmp 0x0000790C663DBBD4
0000790c663dcfba  sub rsp, 0x08
0000790c663dcfbe  push rax
0000790c663dcfbf  push rcx
0000790c663dcfc0  push rdx
0000790c663dcfc1  push rdi
0000790c663dcfc2  push rsi
0000790c663dcfc3  push r8
0000790c663dcfc5  push r9
0000790c663dcfc7  push r10
0000790c663dcfc9  push r11
0000790c663dcfcb  sub rsp, 0xF0
0000790c663dcfd2  vmovaps [rsp], xmm0
0000790c663dcfd7  vmovaps [rsp+0x10], xmm1
0000790c663dcfdd  vmovaps [rsp+0x20], xmm2
0000790c663dcfe3  vmovaps [rsp+0x30], xmm4
0000790c663dcfe9  vmovaps [rsp+0x40], xmm5
0000790c663dcfef  vmovaps [rsp+0x50], xmm6
0000790c663dcff5  vmovaps [rsp+0x60], xmm7
0000790c663dcffb  vmovaps [rsp+0x70], xmm8
0000790c663dd001  vmovaps [rsp+0x80], xmm9
0000790c663dd00a  vmovaps [rsp+0x90], xmm10
0000790c663dd013  vmovaps [rsp+0xA0], xmm11
0000790c663dd01c  vmovaps [rsp+0xB0], xmm12
0000790c663dd025  vmovaps [rsp+0xC0], xmm13
0000790c663dd02e  vmovaps [rsp+0xD0], xmm14
0000790c663dd037  vmovaps [rsp+0xE0], xmm15
0000790c663dd040  sub rsp, 0x30
0000790c663dd044  movaps [rsp], xmm3
0000790c663dd048  movaps [rsp+0x10], xmm5
0000790c663dd04d  movaps [rsp+0x20], xmm4
0000790c663dd052  lea rdi, [rsp]
0000790c663dd056  mov esi, 0x00
0000790c663dd05b  mov rax, 0x631C1759F530
0000790c663dd065  call rax
0000790c663dd067  movaps xmm3, [rsp]
0000790c663dd06b  add rsp, 0x30
0000790c663dd06f  vmovaps xmm0, [rsp]
0000790c663dd074  vmovaps xmm1, [rsp+0x10]
0000790c663dd07a  vmovaps xmm2, [rsp+0x20]
0000790c663dd080  vmovaps xmm4, [rsp+0x30]
0000790c663dd086  vmovaps xmm5, [rsp+0x40]
0000790c663dd08c  vmovaps xmm6, [rsp+0x50]
0000790c663dd092  vmovaps xmm7, [rsp+0x60]
0000790c663dd098  vmovaps xmm8, [rsp+0x70]
0000790c663dd09e  vmovaps xmm9, [rsp+0x80]
0000790c663dd0a7  vmovaps xmm10, [rsp+0x90]
0000790c663dd0b0  vmovaps xmm11, [rsp+0xA0]
0000790c663dd0b9  vmovaps xmm12, [rsp+0xB0]
0000790c663dd0c2  vmovaps xmm13, [rsp+0xC0]
0000790c663dd0cb  vmovaps xmm14, [rsp+0xD0]
0000790c663dd0d4  vmovaps xmm15, [rsp+0xE0]
0000790c663dd0dd  add rsp, 0xF0
0000790c663dd0e4  pop r11
0000790c663dd0e6  pop r10
0000790c663dd0e8  pop r9
0000790c663dd0ea  pop r8
0000790c663dd0ec  pop rsi
0000790c663dd0ed  pop rdi
0000790c663dd0ee  pop rdx
0000790c663dd0ef  pop rcx
0000790c663dd0f0  pop rax
0000790c663dd0f1  add rsp, 0x08
0000790c663dd0f5  jmp 0x0000790C663DBC35
0000790c663dd0fa  sub rsp, 0x08
0000790c663dd0fe  push rax
0000790c663dd0ff  push rcx
0000790c663dd100  push rdx
0000790c663dd101  push rdi
0000790c663dd102  push rsi
0000790c663dd103  push r8
0000790c663dd105  push r9
0000790c663dd107  push r10
0000790c663dd109  push r11
0000790c663dd10b  sub rsp, 0xF0
0000790c663dd112  vmovaps [rsp], xmm0
0000790c663dd117  vmovaps [rsp+0x10], xmm1
0000790c663dd11d  vmovaps [rsp+0x20], xmm2
0000790c663dd123  vmovaps [rsp+0x30], xmm3
0000790c663dd129  vmovaps [rsp+0x40], xmm4
0000790c663dd12f  vmovaps [rsp+0x50], xmm6
0000790c663dd135  vmovaps [rsp+0x60], xmm7
0000790c663dd13b  vmovaps [rsp+0x70], xmm8
0000790c663dd141  vmovaps [rsp+0x80], xmm9
0000790c663dd14a  vmovaps [rsp+0x90], xmm10
0000790c663dd153  vmovaps [rsp+0xA0], xmm11
0000790c663dd15c  vmovaps [rsp+0xB0], xmm12
0000790c663dd165  vmovaps [rsp+0xC0], xmm13
0000790c663dd16e  vmovaps [rsp+0xD0], xmm14
0000790c663dd177  vmovaps [rsp+0xE0], xmm15
0000790c663dd180  sub rsp, 0x30
0000790c663dd184  movaps [rsp], xmm5
0000790c663dd188  movaps [rsp+0x10], xmm8
0000790c663dd18e  movaps [rsp+0x20], xmm15
0000790c663dd194  lea rdi, [rsp]
0000790c663dd198  mov esi, 0x00
0000790c663dd19d  mov rax, 0x631C1759F530
0000790c663dd1a7  call rax
0000790c663dd1a9  movaps xmm5, [rsp]
0000790c663dd1ad  add rsp, 0x30
0000790c663dd1b1  vmovaps xmm0, [rsp]
0000790c663dd1b6  vmovaps xmm1, [rsp+0x10]
0000790c663dd1bc  vmovaps xmm2, [rsp+0x20]
0000790c663dd1c2  vmovaps xmm3, [rsp+0x30]
0000790c663dd1c8  vmovaps xmm4, [rsp+0x40]
0000790c663dd1ce  vmovaps xmm6, [rsp+0x50]
0000790c663dd1d4  vmovaps xmm7, [rsp+0x60]
0000790c663dd1da  vmovaps xmm8, [rsp+0x70]
0000790c663dd1e0  vmovaps xmm9, [rsp+0x80]
0000790c663dd1e9  vmovaps xmm10, [rsp+0x90]
0000790c663dd1f2  vmovaps xmm11, [rsp+0xA0]
0000790c663dd1fb  vmovaps xmm12, [rsp+0xB0]
0000790c663dd204  vmovaps xmm13, [rsp+0xC0]
0000790c663dd20d  vmovaps xmm14, [rsp+0xD0]
0000790c663dd216  vmovaps xmm15, [rsp+0xE0]
0000790c663dd21f  add rsp, 0xF0
0000790c663dd226  pop r11
0000790c663dd228  pop r10
0000790c663dd22a  pop r9
0000790c663dd22c  pop r8
0000790c663dd22e  pop rsi
0000790c663dd22f  pop rdi
0000790c663dd230  pop rdx
0000790c663dd231  pop rcx
0000790c663dd232  pop rax
0000790c663dd233  add rsp, 0x08
0000790c663dd237  jmp 0x0000790C663DBC73
0000790c663dd23c  sub rsp, 0x08
0000790c663dd240  push rax
0000790c663dd241  push rcx
0000790c663dd242  push rdx
0000790c663dd243  push rdi
0000790c663dd244  push rsi
0000790c663dd245  push r8
0000790c663dd247  push r9
0000790c663dd249  push r10
0000790c663dd24b  push r11
0000790c663dd24d  sub rsp, 0xF0
0000790c663dd254  vmovaps [rsp], xmm0
0000790c663dd259  vmovaps [rsp+0x10], xmm1
0000790c663dd25f  vmovaps [rsp+0x20], xmm2
0000790c663dd265  vmovaps [rsp+0x30], xmm3
0000790c663dd26b  vmovaps [rsp+0x40], xmm5
0000790c663dd271  vmovaps [rsp+0x50], xmm6
0000790c663dd277  vmovaps [rsp+0x60], xmm7
0000790c663dd27d  vmovaps [rsp+0x70], xmm8
0000790c663dd283  vmovaps [rsp+0x80], xmm9
0000790c663dd28c  vmovaps [rsp+0x90], xmm10
0000790c663dd295  vmovaps [rsp+0xA0], xmm11
0000790c663dd29e  vmovaps [rsp+0xB0], xmm12
0000790c663dd2a7  vmovaps [rsp+0xC0], xmm13
0000790c663dd2b0  vmovaps [rsp+0xD0], xmm14
0000790c663dd2b9  vmovaps [rsp+0xE0], xmm15
0000790c663dd2c2  sub rsp, 0x30
0000790c663dd2c6  movaps [rsp], xmm4
0000790c663dd2ca  movaps [rsp+0x10], xmm9
0000790c663dd2d0  movaps [rsp+0x20], xmm8
0000790c663dd2d6  lea rdi, [rsp]
0000790c663dd2da  mov esi, 0x00
0000790c663dd2df  mov rax, 0x631C1759F530
0000790c663dd2e9  call rax
0000790c663dd2eb  movaps xmm4, [rsp]
0000790c663dd2ef  add rsp, 0x30
0000790c663dd2f3  vmovaps xmm0, [rsp]
0000790c663dd2f8  vmovaps xmm1, [rsp+0x10]
0000790c663dd2fe  vmovaps xmm2, [rsp+0x20]
0000790c663dd304  vmovaps xmm3, [rsp+0x30]
0000790c663dd30a  vmovaps xmm5, [rsp+0x40]
0000790c663dd310  vmovaps xmm6, [rsp+0x50]
0000790c663dd316  vmovaps xmm7, [rsp+0x60]
0000790c663dd31c  vmovaps xmm8, [rsp+0x70]
0000790c663dd322  vmovaps xmm9, [rsp+0x80]
0000790c663dd32b  vmovaps xmm10, [rsp+0x90]
0000790c663dd334  vmovaps xmm11, [rsp+0xA0]
0000790c663dd33d  vmovaps xmm12, [rsp+0xB0]
0000790c663dd346  vmovaps xmm13, [rsp+0xC0]
0000790c663dd34f  vmovaps xmm14, [rsp+0xD0]
0000790c663dd358  vmovaps xmm15, [rsp+0xE0]
0000790c663dd361  add rsp, 0xF0
0000790c663dd368  pop r11
0000790c663dd36a  pop r10
0000790c663dd36c  pop r9
0000790c663dd36e  pop r8
0000790c663dd370  pop rsi
0000790c663dd371  pop rdi
0000790c663dd372  pop rdx
0000790c663dd373  pop rcx
0000790c663dd374  pop rax
0000790c663dd375  add rsp, 0x08
0000790c663dd379  jmp 0x0000790C663DBC94
0000790c663dd37e  sub rsp, 0x08
0000790c663dd382  push rax
0000790c663dd383  push rcx
0000790c663dd384  push rdx
0000790c663dd385  push rdi
0000790c663dd386  push rsi
0000790c663dd387  push r8
0000790c663dd389  push r9
0000790c663dd38b  push r10
0000790c663dd38d  push r11
0000790c663dd38f  sub rsp, 0xF0
0000790c663dd396  vmovaps [rsp], xmm0
0000790c663dd39b  vmovaps [rsp+0x10], xmm1
0000790c663dd3a1  vmovaps [rsp+0x20], xmm2
0000790c663dd3a7  vmovaps [rsp+0x30], xmm3
0000790c663dd3ad  vmovaps [rsp+0x40], xmm4
0000790c663dd3b3  vmovaps [rsp+0x50], xmm5
0000790c663dd3b9  vmovaps [rsp+0x60], xmm6
0000790c663dd3bf  vmovaps [rsp+0x70], xmm7
0000790c663dd3c5  vmovaps [rsp+0x80], xmm8
0000790c663dd3ce  vmovaps [rsp+0x90], xmm10
0000790c663dd3d7  vmovaps [rsp+0xA0], xmm11
0000790c663dd3e0  vmovaps [rsp+0xB0], xmm12
0000790c663dd3e9  vmovaps [rsp+0xC0], xmm13
0000790c663dd3f2  vmovaps [rsp+0xD0], xmm14
0000790c663dd3fb  vmovaps [rsp+0xE0], xmm15
0000790c663dd404  sub rsp, 0x30
0000790c663dd408  movaps [rsp], xmm9
0000790c663dd40d  movaps [rsp+0x10], xmm10
0000790c663dd413  movaps [rsp+0x20], xmm8
0000790c663dd419  lea rdi, [rsp]
0000790c663dd41d  mov esi, 0x00
0000790c663dd422  mov rax, 0x631C1759F530
0000790c663dd42c  call rax
0000790c663dd42e  movaps xmm9, [rsp]
0000790c663dd433  add rsp, 0x30
0000790c663dd437  vmovaps xmm0, [rsp]
0000790c663dd43c  vmovaps xmm1, [rsp+0x10]
0000790c663dd442  vmovaps xmm2, [rsp+0x20]
0000790c663dd448  vmovaps xmm3, [rsp+0x30]
0000790c663dd44e  vmovaps xmm4, [rsp+0x40]
0000790c663dd454  vmovaps xmm5, [rsp+0x50]
0000790c663dd45a  vmovaps xmm6, [rsp+0x60]
0000790c663dd460  vmovaps xmm7, [rsp+0x70]
0000790c663dd466  vmovaps xmm8, [rsp+0x80]
0000790c663dd46f  vmovaps xmm10, [rsp+0x90]
0000790c663dd478  vmovaps xmm11, [rsp+0xA0]
0000790c663dd481  vmovaps xmm12, [rsp+0xB0]
0000790c663dd48a  vmovaps xmm13, [rsp+0xC0]
0000790c663dd493  vmovaps xmm14, [rsp+0xD0]
0000790c663dd49c  vmovaps xmm15, [rsp+0xE0]
0000790c663dd4a5  add rsp, 0xF0
0000790c663dd4ac  pop r11
0000790c663dd4ae  pop r10
0000790c663dd4b0  pop r9
0000790c663dd4b2  pop r8
0000790c663dd4b4  pop rsi
0000790c663dd4b5  pop rdi
0000790c663dd4b6  pop rdx
0000790c663dd4b7  pop rcx
0000790c663dd4b8  pop rax
0000790c663dd4b9  add rsp, 0x08
0000790c663dd4bd  jmp 0x0000790C663DBCAE
0000790c663dd4c2  call 0x0000790C662B52F0
0000790c663dd4c7  jmp 0x0000790C663DBDC8
0000790c663dd4cc  call 0x0000790C662B52F0
0000790c663dd4d1  jmp 0x0000790C663DBDDE
0000790c663dd4d6  sub rsp, 0x08
0000790c663dd4da  push rax
0000790c663dd4db  push rcx
0000790c663dd4dc  push rdx
0000790c663dd4dd  push rdi
0000790c663dd4de  push rsi
0000790c663dd4df  push r8
0000790c663dd4e1  push r9
0000790c663dd4e3  push r10
0000790c663dd4e5  push r11
0000790c663dd4e7  sub rsp, 0xF0
0000790c663dd4ee  vmovaps [rsp], xmm0
0000790c663dd4f3  vmovaps [rsp+0x10], xmm2
0000790c663dd4f9  vmovaps [rsp+0x20], xmm3
0000790c663dd4ff  vmovaps [rsp+0x30], xmm4
0000790c663dd505  vmovaps [rsp+0x40], xmm5
0000790c663dd50b  vmovaps [rsp+0x50], xmm6
0000790c663dd511  vmovaps [rsp+0x60], xmm7
0000790c663dd517  vmovaps [rsp+0x70], xmm8
0000790c663dd51d  vmovaps [rsp+0x80], xmm9
0000790c663dd526  vmovaps [rsp+0x90], xmm10
0000790c663dd52f  vmovaps [rsp+0xA0], xmm11
0000790c663dd538  vmovaps [rsp+0xB0], xmm12
0000790c663dd541  vmovaps [rsp+0xC0], xmm13
0000790c663dd54a  vmovaps [rsp+0xD0], xmm14
0000790c663dd553  vmovaps [rsp+0xE0], xmm15
0000790c663dd55c  sub rsp, 0x30
0000790c663dd560  movaps [rsp], xmm1
0000790c663dd564  movaps [rsp+0x10], xmm6
0000790c663dd569  movaps [rsp+0x20], xmm15
0000790c663dd56f  lea rdi, [rsp]
0000790c663dd573  mov esi, 0x00
0000790c663dd578  mov rax, 0x631C1759F530
0000790c663dd582  call rax
0000790c663dd584  movaps xmm1, [rsp]
0000790c663dd588  add rsp, 0x30
0000790c663dd58c  vmovaps xmm0, [rsp]
0000790c663dd591  vmovaps xmm2, [rsp+0x10]
0000790c663dd597  vmovaps xmm3, [rsp+0x20]
0000790c663dd59d  vmovaps xmm4, [rsp+0x30]
0000790c663dd5a3  vmovaps xmm5, [rsp+0x40]
0000790c663dd5a9  vmovaps xmm6, [rsp+0x50]
0000790c663dd5af  vmovaps xmm7, [rsp+0x60]
0000790c663dd5b5  vmovaps xmm8, [rsp+0x70]
0000790c663dd5bb  vmovaps xmm9, [rsp+0x80]
0000790c663dd5c4  vmovaps xmm10, [rsp+0x90]
0000790c663dd5cd  vmovaps xmm11, [rsp+0xA0]
0000790c663dd5d6  vmovaps xmm12, [rsp+0xB0]
0000790c663dd5df  vmovaps xmm13, [rsp+0xC0]
0000790c663dd5e8  vmovaps xmm14, [rsp+0xD0]
0000790c663dd5f1  vmovaps xmm15, [rsp+0xE0]
0000790c663dd5fa  add rsp, 0xF0
0000790c663dd601  pop r11
0000790c663dd603  pop r10
0000790c663dd605  pop r9
0000790c663dd607  pop r8
0000790c663dd609  pop rsi
0000790c663dd60a  pop rdi
0000790c663dd60b  pop rdx
0000790c663dd60c  pop rcx
0000790c663dd60d  pop rax
0000790c663dd60e  add rsp, 0x08
0000790c663dd612  jmp 0x0000790C663DBE1B
0000790c663dd617  call 0x0000790C662C4620
0000790c663dd61c  jmp 0x0000790C663DBE28
0000790c663dd621  sub rsp, 0x08
0000790c663dd625  push rax
0000790c663dd626  push rcx
0000790c663dd627  push rdx
0000790c663dd628  push rdi
0000790c663dd629  push rsi
0000790c663dd62a  push r8
0000790c663dd62c  push r9
0000790c663dd62e  push r10
0000790c663dd630  push r11
0000790c663dd632  sub rsp, 0xF0
0000790c663dd639  vmovaps [rsp], xmm0
0000790c663dd63e  vmovaps [rsp+0x10], xmm1
0000790c663dd644  vmovaps [rsp+0x20], xmm2
0000790c663dd64a  vmovaps [rsp+0x30], xmm3
0000790c663dd650  vmovaps [rsp+0x40], xmm4
0000790c663dd656  vmovaps [rsp+0x50], xmm5
0000790c663dd65c  vmovaps [rsp+0x60], xmm6
0000790c663dd662  vmovaps [rsp+0x70], xmm7
0000790c663dd668  vmovaps [rsp+0x80], xmm8
0000790c663dd671  vmovaps [rsp+0x90], xmm9
0000790c663dd67a  vmovaps [rsp+0xA0], xmm10
0000790c663dd683  vmovaps [rsp+0xB0], xmm11
0000790c663dd68c  vmovaps [rsp+0xC0], xmm12
0000790c663dd695  vmovaps [rsp+0xD0], xmm13
0000790c663dd69e  vmovaps [rsp+0xE0], xmm15
0000790c663dd6a7  sub rsp, 0x30
0000790c663dd6ab  movaps [rsp], xmm14
0000790c663dd6b0  movaps [rsp+0x10], xmm4
0000790c663dd6b5  movaps [rsp+0x20], xmm3
0000790c663dd6ba  lea rdi, [rsp]
0000790c663dd6be  mov esi, 0x00
0000790c663dd6c3  mov rax, 0x631C1759F530
0000790c663dd6cd  call rax
0000790c663dd6cf  movaps xmm14, [rsp]
0000790c663dd6d4  add rsp, 0x30
0000790c663dd6d8  vmovaps xmm0, [rsp]
0000790c663dd6dd  vmovaps xmm1, [rsp+0x10]
0000790c663dd6e3  vmovaps xmm2, [rsp+0x20]
0000790c663dd6e9  vmovaps xmm3, [rsp+0x30]
0000790c663dd6ef  vmovaps xmm4, [rsp+0x40]
0000790c663dd6f5  vmovaps xmm5, [rsp+0x50]
0000790c663dd6fb  vmovaps xmm6, [rsp+0x60]
0000790c663dd701  vmovaps xmm7, [rsp+0x70]
0000790c663dd707  vmovaps xmm8, [rsp+0x80]
0000790c663dd710  vmovaps xmm9, [rsp+0x90]
0000790c663dd719  vmovaps xmm10, [rsp+0xA0]
0000790c663dd722  vmovaps xmm11, [rsp+0xB0]
0000790c663dd72b  vmovaps xmm12, [rsp+0xC0]
0000790c663dd734  vmovaps xmm13, [rsp+0xD0]
0000790c663dd73d  vmovaps xmm15, [rsp+0xE0]
0000790c663dd746  add rsp, 0xF0
0000790c663dd74d  pop r11
0000790c663dd74f  pop r10
0000790c663dd751  pop r9
0000790c663dd753  pop r8
0000790c663dd755  pop rsi
0000790c663dd756  pop rdi
0000790c663dd757  pop rdx
0000790c663dd758  pop rcx
0000790c663dd759  pop rax
0000790c663dd75a  add rsp, 0x08
0000790c663dd75e  jmp 0x0000790C663DBE42
0000790c663dd763  sub rsp, 0x08
0000790c663dd767  push rax
0000790c663dd768  push rcx
0000790c663dd769  push rdx
0000790c663dd76a  push rdi
0000790c663dd76b  push rsi
0000790c663dd76c  push r8
0000790c663dd76e  push r9
0000790c663dd770  push r10
0000790c663dd772  push r11
0000790c663dd774  sub rsp, 0xF0
0000790c663dd77b  vmovaps [rsp], xmm0
0000790c663dd780  vmovaps [rsp+0x10], xmm1
0000790c663dd786  vmovaps [rsp+0x20], xmm2
0000790c663dd78c  vmovaps [rsp+0x30], xmm3
0000790c663dd792  vmovaps [rsp+0x40], xmm4
0000790c663dd798  vmovaps [rsp+0x50], xmm5
0000790c663dd79e  vmovaps [rsp+0x60], xmm7
0000790c663dd7a4  vmovaps [rsp+0x70], xmm8
0000790c663dd7aa  vmovaps [rsp+0x80], xmm9
0000790c663dd7b3  vmovaps [rsp+0x90], xmm10
0000790c663dd7bc  vmovaps [rsp+0xA0], xmm11
0000790c663dd7c5  vmovaps [rsp+0xB0], xmm12
0000790c663dd7ce  vmovaps [rsp+0xC0], xmm13
0000790c663dd7d7  vmovaps [rsp+0xD0], xmm14
0000790c663dd7e0  vmovaps [rsp+0xE0], xmm15
0000790c663dd7e9  sub rsp, 0x30
0000790c663dd7ed  movaps [rsp], xmm6
0000790c663dd7f1  movaps [rsp+0x10], xmm9
0000790c663dd7f7  movaps [rsp+0x20], xmm7
0000790c663dd7fc  lea rdi, [rsp]
0000790c663dd800  mov esi, 0x00
0000790c663dd805  mov rax, 0x631C1759F530
0000790c663dd80f  call rax
0000790c663dd811  movaps xmm6, [rsp]
0000790c663dd815  add rsp, 0x30
0000790c663dd819  vmovaps xmm0, [rsp]
0000790c663dd81e  vmovaps xmm1, [rsp+0x10]
0000790c663dd824  vmovaps xmm2, [rsp+0x20]
0000790c663dd82a  vmovaps xmm3, [rsp+0x30]
0000790c663dd830  vmovaps xmm4, [rsp+0x40]
0000790c663dd836  vmovaps xmm5, [rsp+0x50]
0000790c663dd83c  vmovaps xmm7, [rsp+0x60]
0000790c663dd842  vmovaps xmm8, [rsp+0x70]
0000790c663dd848  vmovaps xmm9, [rsp+0x80]
0000790c663dd851  vmovaps xmm10, [rsp+0x90]
0000790c663dd85a  vmovaps xmm11, [rsp+0xA0]
0000790c663dd863  vmovaps xmm12, [rsp+0xB0]
0000790c663dd86c  vmovaps xmm13, [rsp+0xC0]
0000790c663dd875  vmovaps xmm14, [rsp+0xD0]
0000790c663dd87e  vmovaps xmm15, [rsp+0xE0]
0000790c663dd887  add rsp, 0xF0
0000790c663dd88e  pop r11
0000790c663dd890  pop r10
0000790c663dd892  pop r9
0000790c663dd894  pop r8
0000790c663dd896  pop rsi
0000790c663dd897  pop rdi
0000790c663dd898  pop rdx
0000790c663dd899  pop rcx
0000790c663dd89a  pop rax
0000790c663dd89b  add rsp, 0x08
0000790c663dd89f  jmp 0x0000790C663DBE5A
0000790c663dd8a4  sub rsp, 0x08
0000790c663dd8a8  push rax
0000790c663dd8a9  push rcx
0000790c663dd8aa  push rdx
0000790c663dd8ab  push rdi
0000790c663dd8ac  push rsi
0000790c663dd8ad  push r8
0000790c663dd8af  push r9
0000790c663dd8b1  push r10
0000790c663dd8b3  push r11
0000790c663dd8b5  sub rsp, 0xF0
0000790c663dd8bc  vmovaps [rsp], xmm0
0000790c663dd8c1  vmovaps [rsp+0x10], xmm1
0000790c663dd8c7  vmovaps [rsp+0x20], xmm2
0000790c663dd8cd  vmovaps [rsp+0x30], xmm3
0000790c663dd8d3  vmovaps [rsp+0x40], xmm4
0000790c663dd8d9  vmovaps [rsp+0x50], xmm5
0000790c663dd8df  vmovaps [rsp+0x60], xmm6
0000790c663dd8e5  vmovaps [rsp+0x70], xmm8
0000790c663dd8eb  vmovaps [rsp+0x80], xmm9
0000790c663dd8f4  vmovaps [rsp+0x90], xmm10
0000790c663dd8fd  vmovaps [rsp+0xA0], xmm11
0000790c663dd906  vmovaps [rsp+0xB0], xmm12
0000790c663dd90f  vmovaps [rsp+0xC0], xmm13
0000790c663dd918  vmovaps [rsp+0xD0], xmm14
0000790c663dd921  vmovaps [rsp+0xE0], xmm15
0000790c663dd92a  sub rsp, 0x30
0000790c663dd92e  movaps [rsp], xmm7
0000790c663dd932  movaps [rsp+0x10], xmm4
0000790c663dd937  movaps [rsp+0x20], xmm9
0000790c663dd93d  lea rdi, [rsp]
0000790c663dd941  mov esi, 0x00
0000790c663dd946  mov rax, 0x631C1759F530
0000790c663dd950  call rax
0000790c663dd952  movaps xmm7, [rsp]
0000790c663dd956  add rsp, 0x30
0000790c663dd95a  vmovaps xmm0, [rsp]
0000790c663dd95f  vmovaps xmm1, [rsp+0x10]
0000790c663dd965  vmovaps xmm2, [rsp+0x20]
0000790c663dd96b  vmovaps xmm3, [rsp+0x30]
0000790c663dd971  vmovaps xmm4, [rsp+0x40]
0000790c663dd977  vmovaps xmm5, [rsp+0x50]
0000790c663dd97d  vmovaps xmm6, [rsp+0x60]
0000790c663dd983  vmovaps xmm8, [rsp+0x70]
0000790c663dd989  vmovaps xmm9, [rsp+0x80]
0000790c663dd992  vmovaps xmm10, [rsp+0x90]
0000790c663dd99b  vmovaps xmm11, [rsp+0xA0]
0000790c663dd9a4  vmovaps xmm12, [rsp+0xB0]
0000790c663dd9ad  vmovaps xmm13, [rsp+0xC0]
0000790c663dd9b6  vmovaps xmm14, [rsp+0xD0]
0000790c663dd9bf  vmovaps xmm15, [rsp+0xE0]
0000790c663dd9c8  add rsp, 0xF0
0000790c663dd9cf  pop r11
0000790c663dd9d1  pop r10
0000790c663dd9d3  pop r9
0000790c663dd9d5  pop r8
0000790c663dd9d7  pop rsi
0000790c663dd9d8  pop rdi
0000790c663dd9d9  pop rdx
0000790c663dd9da  pop rcx
0000790c663dd9db  pop rax
0000790c663dd9dc  add rsp, 0x08
0000790c663dd9e0  jmp 0x0000790C663DBE87
0000790c663dd9e5  sub rsp, 0x08
0000790c663dd9e9  push rax
0000790c663dd9ea  push rcx
0000790c663dd9eb  push rdx
0000790c663dd9ec  push rdi
0000790c663dd9ed  push rsi
0000790c663dd9ee  push r8
0000790c663dd9f0  push r9
0000790c663dd9f2  push r10
0000790c663dd9f4  push r11
0000790c663dd9f6  sub rsp, 0xF0
0000790c663dd9fd  vmovaps [rsp], xmm0
0000790c663dda02  vmovaps [rsp+0x10], xmm1
0000790c663dda08  vmovaps [rsp+0x20], xmm2
0000790c663dda0e  vmovaps [rsp+0x30], xmm3
0000790c663dda14  vmovaps [rsp+0x40], xmm5
0000790c663dda1a  vmovaps [rsp+0x50], xmm6
0000790c663dda20  vmovaps [rsp+0x60], xmm7
0000790c663dda26  vmovaps [rsp+0x70], xmm8
0000790c663dda2c  vmovaps [rsp+0x80], xmm9
0000790c663dda35  vmovaps [rsp+0x90], xmm10
0000790c663dda3e  vmovaps [rsp+0xA0], xmm11
0000790c663dda47  vmovaps [rsp+0xB0], xmm12
0000790c663dda50  vmovaps [rsp+0xC0], xmm13
0000790c663dda59  vmovaps [rsp+0xD0], xmm14
0000790c663dda62  vmovaps [rsp+0xE0], xmm15
0000790c663dda6b  sub rsp, 0x30
0000790c663dda6f  movaps [rsp], xmm4
0000790c663dda73  movaps [rsp+0x10], xmm15
0000790c663dda79  movaps [rsp+0x20], xmm9
0000790c663dda7f  lea rdi, [rsp]
0000790c663dda83  mov esi, 0x00
0000790c663dda88  mov rax, 0x631C1759F530
0000790c663dda92  call rax
0000790c663dda94  movaps xmm4, [rsp]
0000790c663dda98  add rsp, 0x30
0000790c663dda9c  vmovaps xmm0, [rsp]
0000790c663ddaa1  vmovaps xmm1, [rsp+0x10]
0000790c663ddaa7  vmovaps xmm2, [rsp+0x20]
0000790c663ddaad  vmovaps xmm3, [rsp+0x30]
0000790c663ddab3  vmovaps xmm5, [rsp+0x40]
0000790c663ddab9  vmovaps xmm6, [rsp+0x50]
0000790c663ddabf  vmovaps xmm7, [rsp+0x60]
0000790c663ddac5  vmovaps xmm8, [rsp+0x70]
0000790c663ddacb  vmovaps xmm9, [rsp+0x80]
0000790c663ddad4  vmovaps xmm10, [rsp+0x90]
0000790c663ddadd  vmovaps xmm11, [rsp+0xA0]
0000790c663ddae6  vmovaps xmm12, [rsp+0xB0]
0000790c663ddaef  vmovaps xmm13, [rsp+0xC0]
0000790c663ddaf8  vmovaps xmm14, [rsp+0xD0]
0000790c663ddb01  vmovaps xmm15, [rsp+0xE0]
0000790c663ddb0a  add rsp, 0xF0
0000790c663ddb11  pop r11
0000790c663ddb13  pop r10
0000790c663ddb15  pop r9
0000790c663ddb17  pop r8
0000790c663ddb19  pop rsi
0000790c663ddb1a  pop rdi
0000790c663ddb1b  pop rdx
0000790c663ddb1c  pop rcx
0000790c663ddb1d  pop rax
0000790c663ddb1e  add rsp, 0x08
0000790c663ddb22  jmp 0x0000790C663DBEAC
0000790c663ddb27  call 0x0000790C662C4620
0000790c663ddb2c  jmp 0x0000790C663DBEB9
0000790c663ddb31  sub rsp, 0x08
0000790c663ddb35  push rax
0000790c663ddb36  push rcx
0000790c663ddb37  push rdx
0000790c663ddb38  push rdi
0000790c663ddb39  push rsi
0000790c663ddb3a  push r8
0000790c663ddb3c  push r9
0000790c663ddb3e  push r10
0000790c663ddb40  push r11
0000790c663ddb42  sub rsp, 0xF0
0000790c663ddb49  vmovaps [rsp], xmm0
0000790c663ddb4e  vmovaps [rsp+0x10], xmm1
0000790c663ddb54  vmovaps [rsp+0x20], xmm2
0000790c663ddb5a  vmovaps [rsp+0x30], xmm4
0000790c663ddb60  vmovaps [rsp+0x40], xmm5
0000790c663ddb66  vmovaps [rsp+0x50], xmm6
0000790c663ddb6c  vmovaps [rsp+0x60], xmm7
0000790c663ddb72  vmovaps [rsp+0x70], xmm8
0000790c663ddb78  vmovaps [rsp+0x80], xmm9
0000790c663ddb81  vmovaps [rsp+0x90], xmm10
0000790c663ddb8a  vmovaps [rsp+0xA0], xmm11
0000790c663ddb93  vmovaps [rsp+0xB0], xmm12
0000790c663ddb9c  vmovaps [rsp+0xC0], xmm13
0000790c663ddba5  vmovaps [rsp+0xD0], xmm14
0000790c663ddbae  vmovaps [rsp+0xE0], xmm15
0000790c663ddbb7  sub rsp, 0x30
0000790c663ddbbb  movaps [rsp], xmm3
0000790c663ddbbf  movaps [rsp+0x10], xmm1
0000790c663ddbc4  movaps [rsp+0x20], xmm9
0000790c663ddbca  lea rdi, [rsp]
0000790c663ddbce  mov esi, 0x00
0000790c663ddbd3  mov rax, 0x631C1759F530
0000790c663ddbdd  call rax
0000790c663ddbdf  movaps xmm3, [rsp]
0000790c663ddbe3  add rsp, 0x30
0000790c663ddbe7  vmovaps xmm0, [rsp]
0000790c663ddbec  vmovaps xmm1, [rsp+0x10]
0000790c663ddbf2  vmovaps xmm2, [rsp+0x20]
0000790c663ddbf8  vmovaps xmm4, [rsp+0x30]
0000790c663ddbfe  vmovaps xmm5, [rsp+0x40]
0000790c663ddc04  vmovaps xmm6, [rsp+0x50]
0000790c663ddc0a  vmovaps xmm7, [rsp+0x60]
0000790c663ddc10  vmovaps xmm8, [rsp+0x70]
0000790c663ddc16  vmovaps xmm9, [rsp+0x80]
0000790c663ddc1f  vmovaps xmm10, [rsp+0x90]
0000790c663ddc28  vmovaps xmm11, [rsp+0xA0]
0000790c663ddc31  vmovaps xmm12, [rsp+0xB0]
0000790c663ddc3a  vmovaps xmm13, [rsp+0xC0]
0000790c663ddc43  vmovaps xmm14, [rsp+0xD0]
0000790c663ddc4c  vmovaps xmm15, [rsp+0xE0]
0000790c663ddc55  add rsp, 0xF0
0000790c663ddc5c  pop r11
0000790c663ddc5e  pop r10
0000790c663ddc60  pop r9
0000790c663ddc62  pop r8
0000790c663ddc64  pop rsi
0000790c663ddc65  pop rdi
0000790c663ddc66  pop rdx
0000790c663ddc67  pop rcx
0000790c663ddc68  pop rax
0000790c663ddc69  add rsp, 0x08
0000790c663ddc6d  jmp 0x0000790C663DBEF6
0000790c663ddc72  sub rsp, 0x08
0000790c663ddc76  push rax
0000790c663ddc77  push rcx
0000790c663ddc78  push rdx
0000790c663ddc79  push rdi
0000790c663ddc7a  push rsi
0000790c663ddc7b  push r8
0000790c663ddc7d  push r9
0000790c663ddc7f  push r10
0000790c663ddc81  push r11
0000790c663ddc83  sub rsp, 0xF0
0000790c663ddc8a  vmovaps [rsp], xmm0
0000790c663ddc8f  vmovaps [rsp+0x10], xmm2
0000790c663ddc95  vmovaps [rsp+0x20], xmm3
0000790c663ddc9b  vmovaps [rsp+0x30], xmm4
0000790c663ddca1  vmovaps [rsp+0x40], xmm5
0000790c663ddca7  vmovaps [rsp+0x50], xmm6
0000790c663ddcad  vmovaps [rsp+0x60], xmm7
0000790c663ddcb3  vmovaps [rsp+0x70], xmm8
0000790c663ddcb9  vmovaps [rsp+0x80], xmm9
0000790c663ddcc2  vmovaps [rsp+0x90], xmm10
0000790c663ddccb  vmovaps [rsp+0xA0], xmm11
0000790c663ddcd4  vmovaps [rsp+0xB0], xmm12
0000790c663ddcdd  vmovaps [rsp+0xC0], xmm13
0000790c663ddce6  vmovaps [rsp+0xD0], xmm14
0000790c663ddcef  vmovaps [rsp+0xE0], xmm15
0000790c663ddcf8  sub rsp, 0x30
0000790c663ddcfc  movaps [rsp], xmm1
0000790c663ddd00  movaps [rsp+0x10], xmm15
0000790c663ddd06  movaps [rsp+0x20], xmm9
0000790c663ddd0c  lea rdi, [rsp]
0000790c663ddd10  mov esi, 0x00
0000790c663ddd15  mov rax, 0x631C1759F530
0000790c663ddd1f  call rax
0000790c663ddd21  movaps xmm1, [rsp]
0000790c663ddd25  add rsp, 0x30
0000790c663ddd29  vmovaps xmm0, [rsp]
0000790c663ddd2e  vmovaps xmm2, [rsp+0x10]
0000790c663ddd34  vmovaps xmm3, [rsp+0x20]
0000790c663ddd3a  vmovaps xmm4, [rsp+0x30]
0000790c663ddd40  vmovaps xmm5, [rsp+0x40]
0000790c663ddd46  vmovaps xmm6, [rsp+0x50]
0000790c663ddd4c  vmovaps xmm7, [rsp+0x60]
0000790c663ddd52  vmovaps xmm8, [rsp+0x70]
0000790c663ddd58  vmovaps xmm9, [rsp+0x80]
0000790c663ddd61  vmovaps xmm10, [rsp+0x90]
0000790c663ddd6a  vmovaps xmm11, [rsp+0xA0]
0000790c663ddd73  vmovaps xmm12, [rsp+0xB0]
0000790c663ddd7c  vmovaps xmm13, [rsp+0xC0]
0000790c663ddd85  vmovaps xmm14, [rsp+0xD0]
0000790c663ddd8e  vmovaps xmm15, [rsp+0xE0]
0000790c663ddd97  add rsp, 0xF0
0000790c663ddd9e  pop r11
0000790c663ddda0  pop r10
0000790c663ddda2  pop r9
0000790c663ddda4  pop r8
0000790c663ddda6  pop rsi
0000790c663ddda7  pop rdi
0000790c663ddda8  pop rdx
0000790c663ddda9  pop rcx
0000790c663dddaa  pop rax
0000790c663dddab  add rsp, 0x08
0000790c663dddaf  jmp 0x0000790C663DBF7E
0000790c663dddb4  call 0x0000790C662C4620
0000790c663dddb9  jmp 0x0000790C663DBF8B
0000790c663dddbe  sub rsp, 0x08
0000790c663dddc2  push rax
0000790c663dddc3  push rcx
0000790c663dddc4  push rdx
0000790c663dddc5  push rdi
0000790c663dddc6  push rsi
0000790c663dddc7  push r8
0000790c663dddc9  push r9
0000790c663dddcb  push r10
0000790c663dddcd  push r11
0000790c663dddcf  sub rsp, 0xF0
0000790c663dddd6  vmovaps [rsp], xmm0
0000790c663ddddb  vmovaps [rsp+0x10], xmm2
0000790c663ddde1  vmovaps [rsp+0x20], xmm3
0000790c663ddde7  vmovaps [rsp+0x30], xmm4
0000790c663ddded  vmovaps [rsp+0x40], xmm5
0000790c663dddf3  vmovaps [rsp+0x50], xmm6
0000790c663dddf9  vmovaps [rsp+0x60], xmm7
0000790c663dddff  vmovaps [rsp+0x70], xmm8
0000790c663dde05  vmovaps [rsp+0x80], xmm9
0000790c663dde0e  vmovaps [rsp+0x90], xmm10
0000790c663dde17  vmovaps [rsp+0xA0], xmm11
0000790c663dde20  vmovaps [rsp+0xB0], xmm12
0000790c663dde29  vmovaps [rsp+0xC0], xmm13
0000790c663dde32  vmovaps [rsp+0xD0], xmm14
0000790c663dde3b  vmovaps [rsp+0xE0], xmm15
0000790c663dde44  sub rsp, 0x30
0000790c663dde48  movaps [rsp], xmm1
0000790c663dde4c  movaps [rsp+0x10], xmm5
0000790c663dde51  movaps [rsp+0x20], xmm7
0000790c663dde56  lea rdi, [rsp]
0000790c663dde5a  mov esi, 0x00
0000790c663dde5f  mov rax, 0x631C1759F530
0000790c663dde69  call rax
0000790c663dde6b  movaps xmm1, [rsp]
0000790c663dde6f  add rsp, 0x30
0000790c663dde73  vmovaps xmm0, [rsp]
0000790c663dde78  vmovaps xmm2, [rsp+0x10]
0000790c663dde7e  vmovaps xmm3, [rsp+0x20]
0000790c663dde84  vmovaps xmm4, [rsp+0x30]
0000790c663dde8a  vmovaps xmm5, [rsp+0x40]
0000790c663dde90  vmovaps xmm6, [rsp+0x50]
0000790c663dde96  vmovaps xmm7, [rsp+0x60]
0000790c663dde9c  vmovaps xmm8, [rsp+0x70]
0000790c663ddea2  vmovaps xmm9, [rsp+0x80]
0000790c663ddeab  vmovaps xmm10, [rsp+0x90]
0000790c663ddeb4  vmovaps xmm11, [rsp+0xA0]
0000790c663ddebd  vmovaps xmm12, [rsp+0xB0]
0000790c663ddec6  vmovaps xmm13, [rsp+0xC0]
0000790c663ddecf  vmovaps xmm14, [rsp+0xD0]
0000790c663dded8  vmovaps xmm15, [rsp+0xE0]
0000790c663ddee1  add rsp, 0xF0
0000790c663ddee8  pop r11
0000790c663ddeea  pop r10
0000790c663ddeec  pop r9
0000790c663ddeee  pop r8
0000790c663ddef0  pop rsi
0000790c663ddef1  pop rdi
0000790c663ddef2  pop rdx
0000790c663ddef3  pop rcx
0000790c663ddef4  pop rax
0000790c663ddef5  add rsp, 0x08
0000790c663ddef9  jmp 0x0000790C663DC030
0000790c663ddefe  sub rsp, 0x08
0000790c663ddf02  push rax
0000790c663ddf03  push rcx
0000790c663ddf04  push rdx
0000790c663ddf05  push rdi
0000790c663ddf06  push rsi
0000790c663ddf07  push r8
0000790c663ddf09  push r9
0000790c663ddf0b  push r10
0000790c663ddf0d  push r11
0000790c663ddf0f  sub rsp, 0xF0
0000790c663ddf16  vmovaps [rsp], xmm0
0000790c663ddf1b  vmovaps [rsp+0x10], xmm1
0000790c663ddf21  vmovaps [rsp+0x20], xmm2
0000790c663ddf27  vmovaps [rsp+0x30], xmm3
0000790c663ddf2d  vmovaps [rsp+0x40], xmm4
0000790c663ddf33  vmovaps [rsp+0x50], xmm5
0000790c663ddf39  vmovaps [rsp+0x60], xmm6
0000790c663ddf3f  vmovaps [rsp+0x70], xmm8
0000790c663ddf45  vmovaps [rsp+0x80], xmm9
0000790c663ddf4e  vmovaps [rsp+0x90], xmm10
0000790c663ddf57  vmovaps [rsp+0xA0], xmm11
0000790c663ddf60  vmovaps [rsp+0xB0], xmm12
0000790c663ddf69  vmovaps [rsp+0xC0], xmm13
0000790c663ddf72  vmovaps [rsp+0xD0], xmm14
0000790c663ddf7b  vmovaps [rsp+0xE0], xmm15
0000790c663ddf84  sub rsp, 0x30
0000790c663ddf88  movaps [rsp], xmm7
0000790c663ddf8c  movaps [rsp+0x10], xmm5
0000790c663ddf91  movaps [rsp+0x20], xmm15
0000790c663ddf97  lea rdi, [rsp]
0000790c663ddf9b  mov esi, 0x00
0000790c663ddfa0  mov rax, 0x631C1759F530
0000790c663ddfaa  call rax
0000790c663ddfac  movaps xmm7, [rsp]
0000790c663ddfb0  add rsp, 0x30
0000790c663ddfb4  vmovaps xmm0, [rsp]
0000790c663ddfb9  vmovaps xmm1, [rsp+0x10]
0000790c663ddfbf  vmovaps xmm2, [rsp+0x20]
0000790c663ddfc5  vmovaps xmm3, [rsp+0x30]
0000790c663ddfcb  vmovaps xmm4, [rsp+0x40]
0000790c663ddfd1  vmovaps xmm5, [rsp+0x50]
0000790c663ddfd7  vmovaps xmm6, [rsp+0x60]
0000790c663ddfdd  vmovaps xmm8, [rsp+0x70]
0000790c663ddfe3  vmovaps xmm9, [rsp+0x80]
0000790c663ddfec  vmovaps xmm10, [rsp+0x90]
0000790c663ddff5  vmovaps xmm11, [rsp+0xA0]
0000790c663ddffe  vmovaps xmm12, [rsp+0xB0]
0000790c663de007  vmovaps xmm13, [rsp+0xC0]
0000790c663de010  vmovaps xmm14, [rsp+0xD0]
0000790c663de019  vmovaps xmm15, [rsp+0xE0]
0000790c663de022  add rsp, 0xF0
0000790c663de029  pop r11
0000790c663de02b  pop r10
0000790c663de02d  pop r9
0000790c663de02f  pop r8
0000790c663de031  pop rsi
0000790c663de032  pop rdi
0000790c663de033  pop rdx
0000790c663de034  pop rcx
0000790c663de035  pop rax
0000790c663de036  add rsp, 0x08
0000790c663de03a  jmp 0x0000790C663DC066
0000790c663de03f  call 0x0000790C662B52F0
0000790c663de044  jmp 0x0000790C663DC073
0000790c663de049  sub rsp, 0x08
0000790c663de04d  push rax
0000790c663de04e  push rcx
0000790c663de04f  push rdx
0000790c663de050  push rdi
0000790c663de051  push rsi
0000790c663de052  push r8
0000790c663de054  push r9
0000790c663de056  push r10
0000790c663de058  push r11
0000790c663de05a  sub rsp, 0xF0
0000790c663de061  vmovaps [rsp], xmm0
0000790c663de066  vmovaps [rsp+0x10], xmm1
0000790c663de06c  vmovaps [rsp+0x20], xmm2
0000790c663de072  vmovaps [rsp+0x30], xmm3
0000790c663de078  vmovaps [rsp+0x40], xmm4
0000790c663de07e  vmovaps [rsp+0x50], xmm5
0000790c663de084  vmovaps [rsp+0x60], xmm6
0000790c663de08a  vmovaps [rsp+0x70], xmm7
0000790c663de090  vmovaps [rsp+0x80], xmm8
0000790c663de099  vmovaps [rsp+0x90], xmm9
0000790c663de0a2  vmovaps [rsp+0xA0], xmm10
0000790c663de0ab  vmovaps [rsp+0xB0], xmm11
0000790c663de0b4  vmovaps [rsp+0xC0], xmm12
0000790c663de0bd  vmovaps [rsp+0xD0], xmm13
0000790c663de0c6  vmovaps [rsp+0xE0], xmm14
0000790c663de0cf  sub rsp, 0x30
0000790c663de0d3  movaps [rsp], xmm15
0000790c663de0d8  movaps [rsp+0x10], xmm5
0000790c663de0dd  movaps [rsp+0x20], xmm3
0000790c663de0e2  lea rdi, [rsp]
0000790c663de0e6  mov esi, 0x00
0000790c663de0eb  mov rax, 0x631C1759F530
0000790c663de0f5  call rax
0000790c663de0f7  movaps xmm15, [rsp]
0000790c663de0fc  add rsp, 0x30
0000790c663de100  vmovaps xmm0, [rsp]
0000790c663de105  vmovaps xmm1, [rsp+0x10]
0000790c663de10b  vmovaps xmm2, [rsp+0x20]
0000790c663de111  vmovaps xmm3, [rsp+0x30]
0000790c663de117  vmovaps xmm4, [rsp+0x40]
0000790c663de11d  vmovaps xmm5, [rsp+0x50]
0000790c663de123  vmovaps xmm6, [rsp+0x60]
0000790c663de129  vmovaps xmm7, [rsp+0x70]
0000790c663de12f  vmovaps xmm8, [rsp+0x80]
0000790c663de138  vmovaps xmm9, [rsp+0x90]
0000790c663de141  vmovaps xmm10, [rsp+0xA0]
0000790c663de14a  vmovaps xmm11, [rsp+0xB0]
0000790c663de153  vmovaps xmm12, [rsp+0xC0]
0000790c663de15c  vmovaps xmm13, [rsp+0xD0]
0000790c663de165  vmovaps xmm14, [rsp+0xE0]
0000790c663de16e  add rsp, 0xF0
0000790c663de175  pop r11
0000790c663de177  pop r10
0000790c663de179  pop r9
0000790c663de17b  pop r8
0000790c663de17d  pop rsi
0000790c663de17e  pop rdi
0000790c663de17f  pop rdx
0000790c663de180  pop rcx
0000790c663de181  pop rax
0000790c663de182  add rsp, 0x08
0000790c663de186  jmp 0x0000790C663DC099
0000790c663de18b  sub rsp, 0x08
0000790c663de18f  push rax
0000790c663de190  push rcx
0000790c663de191  push rdx
0000790c663de192  push rdi
0000790c663de193  push rsi
0000790c663de194  push r8
0000790c663de196  push r9
0000790c663de198  push r10
0000790c663de19a  push r11
0000790c663de19c  sub rsp, 0xF0
0000790c663de1a3  vmovaps [rsp], xmm0
0000790c663de1a8  vmovaps [rsp+0x10], xmm2
0000790c663de1ae  vmovaps [rsp+0x20], xmm3
0000790c663de1b4  vmovaps [rsp+0x30], xmm4
0000790c663de1ba  vmovaps [rsp+0x40], xmm5
0000790c663de1c0  vmovaps [rsp+0x50], xmm6
0000790c663de1c6  vmovaps [rsp+0x60], xmm7
0000790c663de1cc  vmovaps [rsp+0x70], xmm8
0000790c663de1d2  vmovaps [rsp+0x80], xmm9
0000790c663de1db  vmovaps [rsp+0x90], xmm10
0000790c663de1e4  vmovaps [rsp+0xA0], xmm11
0000790c663de1ed  vmovaps [rsp+0xB0], xmm12
0000790c663de1f6  vmovaps [rsp+0xC0], xmm13
0000790c663de1ff  vmovaps [rsp+0xD0], xmm14
0000790c663de208  vmovaps [rsp+0xE0], xmm15
0000790c663de211  sub rsp, 0x30
0000790c663de215  movaps [rsp], xmm1
0000790c663de219  movaps [rsp+0x10], xmm5
0000790c663de21e  movaps [rsp+0x20], xmm4
0000790c663de223  lea rdi, [rsp]
0000790c663de227  mov esi, 0x00
0000790c663de22c  mov rax, 0x631C1759F530
0000790c663de236  call rax
0000790c663de238  movaps xmm1, [rsp]
0000790c663de23c  add rsp, 0x30
0000790c663de240  vmovaps xmm0, [rsp]
0000790c663de245  vmovaps xmm2, [rsp+0x10]
0000790c663de24b  vmovaps xmm3, [rsp+0x20]
0000790c663de251  vmovaps xmm4, [rsp+0x30]
0000790c663de257  vmovaps xmm5, [rsp+0x40]
0000790c663de25d  vmovaps xmm6, [rsp+0x50]
0000790c663de263  vmovaps xmm7, [rsp+0x60]
0000790c663de269  vmovaps xmm8, [rsp+0x70]
0000790c663de26f  vmovaps xmm9, [rsp+0x80]
0000790c663de278  vmovaps xmm10, [rsp+0x90]
0000790c663de281  vmovaps xmm11, [rsp+0xA0]
0000790c663de28a  vmovaps xmm12, [rsp+0xB0]
0000790c663de293  vmovaps xmm13, [rsp+0xC0]
0000790c663de29c  vmovaps xmm14, [rsp+0xD0]
0000790c663de2a5  vmovaps xmm15, [rsp+0xE0]
0000790c663de2ae  add rsp, 0xF0
0000790c663de2b5  pop r11
0000790c663de2b7  pop r10
0000790c663de2b9  pop r9
0000790c663de2bb  pop r8
0000790c663de2bd  pop rsi
0000790c663de2be  pop rdi
0000790c663de2bf  pop rdx
0000790c663de2c0  pop rcx
0000790c663de2c1  pop rax
0000790c663de2c2  add rsp, 0x08
0000790c663de2c6  jmp 0x0000790C663DC0B9
0000790c663de2cb  sub rsp, 0x08
0000790c663de2cf  push rax
0000790c663de2d0  push rcx
0000790c663de2d1  push rdx
0000790c663de2d2  push rdi
0000790c663de2d3  push rsi
0000790c663de2d4  push r8
0000790c663de2d6  push r9
0000790c663de2d8  push r10
0000790c663de2da  push r11
0000790c663de2dc  sub rsp, 0xF0
0000790c663de2e3  vmovaps [rsp], xmm0
0000790c663de2e8  vmovaps [rsp+0x10], xmm1
0000790c663de2ee  vmovaps [rsp+0x20], xmm2
0000790c663de2f4  vmovaps [rsp+0x30], xmm3
0000790c663de2fa  vmovaps [rsp+0x40], xmm5
0000790c663de300  vmovaps [rsp+0x50], xmm6
0000790c663de306  vmovaps [rsp+0x60], xmm7
0000790c663de30c  vmovaps [rsp+0x70], xmm8
0000790c663de312  vmovaps [rsp+0x80], xmm9
0000790c663de31b  vmovaps [rsp+0x90], xmm10
0000790c663de324  vmovaps [rsp+0xA0], xmm11
0000790c663de32d  vmovaps [rsp+0xB0], xmm12
0000790c663de336  vmovaps [rsp+0xC0], xmm13
0000790c663de33f  vmovaps [rsp+0xD0], xmm14
0000790c663de348  vmovaps [rsp+0xE0], xmm15
0000790c663de351  sub rsp, 0x30
0000790c663de355  movaps [rsp], xmm4
0000790c663de359  movaps [rsp+0x10], xmm3
0000790c663de35e  movaps [rsp+0x20], xmm5
0000790c663de363  lea rdi, [rsp]
0000790c663de367  mov esi, 0x00
0000790c663de36c  mov rax, 0x631C1759F530
0000790c663de376  call rax
0000790c663de378  movaps xmm4, [rsp]
0000790c663de37c  add rsp, 0x30
0000790c663de380  vmovaps xmm0, [rsp]
0000790c663de385  vmovaps xmm1, [rsp+0x10]
0000790c663de38b  vmovaps xmm2, [rsp+0x20]
0000790c663de391  vmovaps xmm3, [rsp+0x30]
0000790c663de397  vmovaps xmm5, [rsp+0x40]
0000790c663de39d  vmovaps xmm6, [rsp+0x50]
0000790c663de3a3  vmovaps xmm7, [rsp+0x60]
0000790c663de3a9  vmovaps xmm8, [rsp+0x70]
0000790c663de3af  vmovaps xmm9, [rsp+0x80]
0000790c663de3b8  vmovaps xmm10, [rsp+0x90]
0000790c663de3c1  vmovaps xmm11, [rsp+0xA0]
0000790c663de3ca  vmovaps xmm12, [rsp+0xB0]
0000790c663de3d3  vmovaps xmm13, [rsp+0xC0]
0000790c663de3dc  vmovaps xmm14, [rsp+0xD0]
0000790c663de3e5  vmovaps xmm15, [rsp+0xE0]
0000790c663de3ee  add rsp, 0xF0
0000790c663de3f5  pop r11
0000790c663de3f7  pop r10
0000790c663de3f9  pop r9
0000790c663de3fb  pop r8
0000790c663de3fd  pop rsi
0000790c663de3fe  pop rdi
0000790c663de3ff  pop rdx
0000790c663de400  pop rcx
0000790c663de401  pop rax
0000790c663de402  add rsp, 0x08
0000790c663de406  jmp 0x0000790C663DC107
0000790c663de40b  call 0x0000790C662B52F0
0000790c663de410  jmp 0x0000790C663DC114
0000790c663de415  sub rsp, 0x08
0000790c663de419  push rax
0000790c663de41a  push rcx
0000790c663de41b  push rdx
0000790c663de41c  push rdi
0000790c663de41d  push rsi
0000790c663de41e  push r8
0000790c663de420  push r9
0000790c663de422  push r10
0000790c663de424  push r11
0000790c663de426  sub rsp, 0xF0
0000790c663de42d  vmovaps [rsp], xmm0
0000790c663de432  vmovaps [rsp+0x10], xmm1
0000790c663de438  vmovaps [rsp+0x20], xmm2
0000790c663de43e  vmovaps [rsp+0x30], xmm3
0000790c663de444  vmovaps [rsp+0x40], xmm4
0000790c663de44a  vmovaps [rsp+0x50], xmm6
0000790c663de450  vmovaps [rsp+0x60], xmm7
0000790c663de456  vmovaps [rsp+0x70], xmm8
0000790c663de45c  vmovaps [rsp+0x80], xmm9
0000790c663de465  vmovaps [rsp+0x90], xmm10
0000790c663de46e  vmovaps [rsp+0xA0], xmm11
0000790c663de477  vmovaps [rsp+0xB0], xmm12
0000790c663de480  vmovaps [rsp+0xC0], xmm13
0000790c663de489  vmovaps [rsp+0xD0], xmm14
0000790c663de492  vmovaps [rsp+0xE0], xmm15
0000790c663de49b  sub rsp, 0x30
0000790c663de49f  movaps [rsp], xmm5
0000790c663de4a3  movaps [rsp+0x10], xmm6
0000790c663de4a8  movaps [rsp+0x20], xmm3
0000790c663de4ad  lea rdi, [rsp]
0000790c663de4b1  mov esi, 0x00
0000790c663de4b6  mov rax, 0x631C1759F530
0000790c663de4c0  call rax
0000790c663de4c2  movaps xmm5, [rsp]
0000790c663de4c6  add rsp, 0x30
0000790c663de4ca  vmovaps xmm0, [rsp]
0000790c663de4cf  vmovaps xmm1, [rsp+0x10]
0000790c663de4d5  vmovaps xmm2, [rsp+0x20]
0000790c663de4db  vmovaps xmm3, [rsp+0x30]
0000790c663de4e1  vmovaps xmm4, [rsp+0x40]
0000790c663de4e7  vmovaps xmm6, [rsp+0x50]
0000790c663de4ed  vmovaps xmm7, [rsp+0x60]
0000790c663de4f3  vmovaps xmm8, [rsp+0x70]
0000790c663de4f9  vmovaps xmm9, [rsp+0x80]
0000790c663de502  vmovaps xmm10, [rsp+0x90]
0000790c663de50b  vmovaps xmm11, [rsp+0xA0]
0000790c663de514  vmovaps xmm12, [rsp+0xB0]
0000790c663de51d  vmovaps xmm13, [rsp+0xC0]
0000790c663de526  vmovaps xmm14, [rsp+0xD0]
0000790c663de52f  vmovaps xmm15, [rsp+0xE0]
0000790c663de538  add rsp, 0xF0
0000790c663de53f  pop r11
0000790c663de541  pop r10
0000790c663de543  pop r9
0000790c663de545  pop r8
0000790c663de547  pop rsi
0000790c663de548  pop rdi
0000790c663de549  pop rdx
0000790c663de54a  pop rcx
0000790c663de54b  pop rax
0000790c663de54c  add rsp, 0x08
0000790c663de550  jmp 0x0000790C663DC13A
0000790c663de555  sub rsp, 0x08
0000790c663de559  push rax
0000790c663de55a  push rcx
0000790c663de55b  push rdx
0000790c663de55c  push rdi
0000790c663de55d  push rsi
0000790c663de55e  push r8
0000790c663de560  push r9
0000790c663de562  push r10
0000790c663de564  push r11
0000790c663de566  sub rsp, 0xF0
0000790c663de56d  vmovaps [rsp], xmm0
0000790c663de572  vmovaps [rsp+0x10], xmm1
0000790c663de578  vmovaps [rsp+0x20], xmm2
0000790c663de57e  vmovaps [rsp+0x30], xmm3
0000790c663de584  vmovaps [rsp+0x40], xmm4
0000790c663de58a  vmovaps [rsp+0x50], xmm5
0000790c663de590  vmovaps [rsp+0x60], xmm7
0000790c663de596  vmovaps [rsp+0x70], xmm8
0000790c663de59c  vmovaps [rsp+0x80], xmm9
0000790c663de5a5  vmovaps [rsp+0x90], xmm10
0000790c663de5ae  vmovaps [rsp+0xA0], xmm11
0000790c663de5b7  vmovaps [rsp+0xB0], xmm12
0000790c663de5c0  vmovaps [rsp+0xC0], xmm13
0000790c663de5c9  vmovaps [rsp+0xD0], xmm14
0000790c663de5d2  vmovaps [rsp+0xE0], xmm15
0000790c663de5db  sub rsp, 0x30
0000790c663de5df  movaps [rsp], xmm6
0000790c663de5e3  movaps [rsp+0x10], xmm9
0000790c663de5e9  movaps [rsp+0x20], xmm1
0000790c663de5ee  lea rdi, [rsp]
0000790c663de5f2  mov esi, 0x00
0000790c663de5f7  mov rax, 0x631C1759F530
0000790c663de601  call rax
0000790c663de603  movaps xmm6, [rsp]
0000790c663de607  add rsp, 0x30
0000790c663de60b  vmovaps xmm0, [rsp]
0000790c663de610  vmovaps xmm1, [rsp+0x10]
0000790c663de616  vmovaps xmm2, [rsp+0x20]
0000790c663de61c  vmovaps xmm3, [rsp+0x30]
0000790c663de622  vmovaps xmm4, [rsp+0x40]
0000790c663de628  vmovaps xmm5, [rsp+0x50]
0000790c663de62e  vmovaps xmm7, [rsp+0x60]
0000790c663de634  vmovaps xmm8, [rsp+0x70]
0000790c663de63a  vmovaps xmm9, [rsp+0x80]
0000790c663de643  vmovaps xmm10, [rsp+0x90]
0000790c663de64c  vmovaps xmm11, [rsp+0xA0]
0000790c663de655  vmovaps xmm12, [rsp+0xB0]
0000790c663de65e  vmovaps xmm13, [rsp+0xC0]
0000790c663de667  vmovaps xmm14, [rsp+0xD0]
0000790c663de670  vmovaps xmm15, [rsp+0xE0]
0000790c663de679  add rsp, 0xF0
0000790c663de680  pop r11
0000790c663de682  pop r10
0000790c663de684  pop r9
0000790c663de686  pop r8
0000790c663de688  pop rsi
0000790c663de689  pop rdi
0000790c663de68a  pop rdx
0000790c663de68b  pop rcx
0000790c663de68c  pop rax
0000790c663de68d  add rsp, 0x08
0000790c663de691  jmp 0x0000790C663DC15E
0000790c663de696  sub rsp, 0x08
0000790c663de69a  push rax
0000790c663de69b  push rcx
0000790c663de69c  push rdx
0000790c663de69d  push rdi
0000790c663de69e  push rsi
0000790c663de69f  push r8
0000790c663de6a1  push r9
0000790c663de6a3  push r10
0000790c663de6a5  push r11
0000790c663de6a7  sub rsp, 0xF0
0000790c663de6ae  vmovaps [rsp], xmm0
0000790c663de6b3  vmovaps [rsp+0x10], xmm1
0000790c663de6b9  vmovaps [rsp+0x20], xmm2
0000790c663de6bf  vmovaps [rsp+0x30], xmm3
0000790c663de6c5  vmovaps [rsp+0x40], xmm4
0000790c663de6cb  vmovaps [rsp+0x50], xmm5
0000790c663de6d1  vmovaps [rsp+0x60], xmm6
0000790c663de6d7  vmovaps [rsp+0x70], xmm7
0000790c663de6dd  vmovaps [rsp+0x80], xmm8
0000790c663de6e6  vmovaps [rsp+0x90], xmm10
0000790c663de6ef  vmovaps [rsp+0xA0], xmm11
0000790c663de6f8  vmovaps [rsp+0xB0], xmm12
0000790c663de701  vmovaps [rsp+0xC0], xmm13
0000790c663de70a  vmovaps [rsp+0xD0], xmm14
0000790c663de713  vmovaps [rsp+0xE0], xmm15
0000790c663de71c  sub rsp, 0x30
0000790c663de720  movaps [rsp], xmm9
0000790c663de725  movaps [rsp+0x10], xmm3
0000790c663de72a  movaps [rsp+0x20], xmm1
0000790c663de72f  lea rdi, [rsp]
0000790c663de733  mov esi, 0x00
0000790c663de738  mov rax, 0x631C1759F530
0000790c663de742  call rax
0000790c663de744  movaps xmm9, [rsp]
0000790c663de749  add rsp, 0x30
0000790c663de74d  vmovaps xmm0, [rsp]
0000790c663de752  vmovaps xmm1, [rsp+0x10]
0000790c663de758  vmovaps xmm2, [rsp+0x20]
0000790c663de75e  vmovaps xmm3, [rsp+0x30]
0000790c663de764  vmovaps xmm4, [rsp+0x40]
0000790c663de76a  vmovaps xmm5, [rsp+0x50]
0000790c663de770  vmovaps xmm6, [rsp+0x60]
0000790c663de776  vmovaps xmm7, [rsp+0x70]
0000790c663de77c  vmovaps xmm8, [rsp+0x80]
0000790c663de785  vmovaps xmm10, [rsp+0x90]
0000790c663de78e  vmovaps xmm11, [rsp+0xA0]
0000790c663de797  vmovaps xmm12, [rsp+0xB0]
0000790c663de7a0  vmovaps xmm13, [rsp+0xC0]
0000790c663de7a9  vmovaps xmm14, [rsp+0xD0]
0000790c663de7b2  vmovaps xmm15, [rsp+0xE0]
0000790c663de7bb  add rsp, 0xF0
0000790c663de7c2  pop r11
0000790c663de7c4  pop r10
0000790c663de7c6  pop r9
0000790c663de7c8  pop r8
0000790c663de7ca  pop rsi
0000790c663de7cb  pop rdi
0000790c663de7cc  pop rdx
0000790c663de7cd  pop rcx
0000790c663de7ce  pop rax
0000790c663de7cf  add rsp, 0x08
0000790c663de7d3  jmp 0x0000790C663DC1AA
0000790c663de7d8  call 0x0000790C662B52F0
0000790c663de7dd  jmp 0x0000790C663DC1B7
0000790c663de7e2  sub rsp, 0x08
0000790c663de7e6  push rax
0000790c663de7e7  push rcx
0000790c663de7e8  push rdx
0000790c663de7e9  push rdi
0000790c663de7ea  push rsi
0000790c663de7eb  push r8
0000790c663de7ed  push r9
0000790c663de7ef  push r10
0000790c663de7f1  push r11
0000790c663de7f3  sub rsp, 0xF0
0000790c663de7fa  vmovaps [rsp], xmm0
0000790c663de7ff  vmovaps [rsp+0x10], xmm1
0000790c663de805  vmovaps [rsp+0x20], xmm2
0000790c663de80b  vmovaps [rsp+0x30], xmm3
0000790c663de811  vmovaps [rsp+0x40], xmm4
0000790c663de817  vmovaps [rsp+0x50], xmm5
0000790c663de81d  vmovaps [rsp+0x60], xmm6
0000790c663de823  vmovaps [rsp+0x70], xmm7
0000790c663de829  vmovaps [rsp+0x80], xmm8
0000790c663de832  vmovaps [rsp+0x90], xmm9
0000790c663de83b  vmovaps [rsp+0xA0], xmm10
0000790c663de844  vmovaps [rsp+0xB0], xmm11
0000790c663de84d  vmovaps [rsp+0xC0], xmm12
0000790c663de856  vmovaps [rsp+0xD0], xmm13
0000790c663de85f  vmovaps [rsp+0xE0], xmm14
0000790c663de868  sub rsp, 0x30
0000790c663de86c  movaps [rsp], xmm15
0000790c663de871  movaps [rsp+0x10], xmm3
0000790c663de876  movaps [rsp+0x20], xmm7
0000790c663de87b  lea rdi, [rsp]
0000790c663de87f  mov esi, 0x00
0000790c663de884  mov rax, 0x631C1759F530
0000790c663de88e  call rax
0000790c663de890  movaps xmm15, [rsp]
0000790c663de895  add rsp, 0x30
0000790c663de899  vmovaps xmm0, [rsp]
0000790c663de89e  vmovaps xmm1, [rsp+0x10]
0000790c663de8a4  vmovaps xmm2, [rsp+0x20]
0000790c663de8aa  vmovaps xmm3, [rsp+0x30]
0000790c663de8b0  vmovaps xmm4, [rsp+0x40]
0000790c663de8b6  vmovaps xmm5, [rsp+0x50]
0000790c663de8bc  vmovaps xmm6, [rsp+0x60]
0000790c663de8c2  vmovaps xmm7, [rsp+0x70]
0000790c663de8c8  vmovaps xmm8, [rsp+0x80]
0000790c663de8d1  vmovaps xmm9, [rsp+0x90]
0000790c663de8da  vmovaps xmm10, [rsp+0xA0]
0000790c663de8e3  vmovaps xmm11, [rsp+0xB0]
0000790c663de8ec  vmovaps xmm12, [rsp+0xC0]
0000790c663de8f5  vmovaps xmm13, [rsp+0xD0]
0000790c663de8fe  vmovaps xmm14, [rsp+0xE0]
0000790c663de907  add rsp, 0xF0
0000790c663de90e  pop r11
0000790c663de910  pop r10
0000790c663de912  pop r9
0000790c663de914  pop r8
0000790c663de916  pop rsi
0000790c663de917  pop rdi
0000790c663de918  pop rdx
0000790c663de919  pop rcx
0000790c663de91a  pop rax
0000790c663de91b  add rsp, 0x08
0000790c663de91f  jmp 0x0000790C663DC1E3
0000790c663de924  sub rsp, 0x08
0000790c663de928  push rax
0000790c663de929  push rcx
0000790c663de92a  push rdx
0000790c663de92b  push rdi
0000790c663de92c  push rsi
0000790c663de92d  push r8
0000790c663de92f  push r9
0000790c663de931  push r10
0000790c663de933  push r11
0000790c663de935  sub rsp, 0xF0
0000790c663de93c  vmovaps [rsp], xmm0
0000790c663de941  vmovaps [rsp+0x10], xmm1
0000790c663de947  vmovaps [rsp+0x20], xmm2
0000790c663de94d  vmovaps [rsp+0x30], xmm4
0000790c663de953  vmovaps [rsp+0x40], xmm5
0000790c663de959  vmovaps [rsp+0x50], xmm6
0000790c663de95f  vmovaps [rsp+0x60], xmm7
0000790c663de965  vmovaps [rsp+0x70], xmm8
0000790c663de96b  vmovaps [rsp+0x80], xmm9
0000790c663de974  vmovaps [rsp+0x90], xmm10
0000790c663de97d  vmovaps [rsp+0xA0], xmm11
0000790c663de986  vmovaps [rsp+0xB0], xmm12
0000790c663de98f  vmovaps [rsp+0xC0], xmm13
0000790c663de998  vmovaps [rsp+0xD0], xmm14
0000790c663de9a1  vmovaps [rsp+0xE0], xmm15
0000790c663de9aa  sub rsp, 0x30
0000790c663de9ae  movaps [rsp], xmm3
0000790c663de9b2  movaps [rsp+0x10], xmm1
0000790c663de9b7  movaps [rsp+0x20], xmm15
0000790c663de9bd  lea rdi, [rsp]
0000790c663de9c1  mov esi, 0x00
0000790c663de9c6  mov rax, 0x631C1759F530
0000790c663de9d0  call rax
0000790c663de9d2  movaps xmm3, [rsp]
0000790c663de9d6  add rsp, 0x30
0000790c663de9da  vmovaps xmm0, [rsp]
0000790c663de9df  vmovaps xmm1, [rsp+0x10]
0000790c663de9e5  vmovaps xmm2, [rsp+0x20]
0000790c663de9eb  vmovaps xmm4, [rsp+0x30]
0000790c663de9f1  vmovaps xmm5, [rsp+0x40]
0000790c663de9f7  vmovaps xmm6, [rsp+0x50]
0000790c663de9fd  vmovaps xmm7, [rsp+0x60]
0000790c663dea03  vmovaps xmm8, [rsp+0x70]
0000790c663dea09  vmovaps xmm9, [rsp+0x80]
0000790c663dea12  vmovaps xmm10, [rsp+0x90]
0000790c663dea1b  vmovaps xmm11, [rsp+0xA0]
0000790c663dea24  vmovaps xmm12, [rsp+0xB0]
0000790c663dea2d  vmovaps xmm13, [rsp+0xC0]
0000790c663dea36  vmovaps xmm14, [rsp+0xD0]
0000790c663dea3f  vmovaps xmm15, [rsp+0xE0]
0000790c663dea48  add rsp, 0xF0
0000790c663dea4f  pop r11
0000790c663dea51  pop r10
0000790c663dea53  pop r9
0000790c663dea55  pop r8
0000790c663dea57  pop rsi
0000790c663dea58  pop rdi
0000790c663dea59  pop rdx
0000790c663dea5a  pop rcx
0000790c663dea5b  pop rax
0000790c663dea5c  add rsp, 0x08
0000790c663dea60  jmp 0x0000790C663DC272
0000790c663dea65  call 0x0000790C662B52F0
0000790c663dea6a  jmp 0x0000790C663DC27C
0000790c663dea6f  sub rsp, 0x08
0000790c663dea73  push rax
0000790c663dea74  push rcx
0000790c663dea75  push rdx
0000790c663dea76  push rdi
0000790c663dea77  push rsi
0000790c663dea78  push r8
0000790c663dea7a  push r9
0000790c663dea7c  push r10
0000790c663dea7e  push r11
0000790c663dea80  sub rsp, 0xF0
0000790c663dea87  vmovaps [rsp], xmm0
0000790c663dea8c  vmovaps [rsp+0x10], xmm1
0000790c663dea92  vmovaps [rsp+0x20], xmm2
0000790c663dea98  vmovaps [rsp+0x30], xmm3
0000790c663dea9e  vmovaps [rsp+0x40], xmm4
0000790c663deaa4  vmovaps [rsp+0x50], xmm5
0000790c663deaaa  vmovaps [rsp+0x60], xmm6
0000790c663deab0  vmovaps [rsp+0x70], xmm7
0000790c663deab6  vmovaps [rsp+0x80], xmm8
0000790c663deabf  vmovaps [rsp+0x90], xmm9
0000790c663deac8  vmovaps [rsp+0xA0], xmm10
0000790c663dead1  vmovaps [rsp+0xB0], xmm11
0000790c663deada  vmovaps [rsp+0xC0], xmm12
0000790c663deae3  vmovaps [rsp+0xD0], xmm13
0000790c663deaec  vmovaps [rsp+0xE0], xmm14
0000790c663deaf5  sub rsp, 0x30
0000790c663deaf9  movaps [rsp], xmm15
0000790c663deafe  movaps [rsp+0x10], xmm14
0000790c663deb04  movaps [rsp+0x20], xmm4
0000790c663deb09  lea rdi, [rsp]
0000790c663deb0d  mov esi, 0x00
0000790c663deb12  mov rax, 0x631C1759F530
0000790c663deb1c  call rax
0000790c663deb1e  movaps xmm15, [rsp]
0000790c663deb23  add rsp, 0x30
0000790c663deb27  vmovaps xmm0, [rsp]
0000790c663deb2c  vmovaps xmm1, [rsp+0x10]
0000790c663deb32  vmovaps xmm2, [rsp+0x20]
0000790c663deb38  vmovaps xmm3, [rsp+0x30]
0000790c663deb3e  vmovaps xmm4, [rsp+0x40]
0000790c663deb44  vmovaps xmm5, [rsp+0x50]
0000790c663deb4a  vmovaps xmm6, [rsp+0x60]
0000790c663deb50  vmovaps xmm7, [rsp+0x70]
0000790c663deb56  vmovaps xmm8, [rsp+0x80]
0000790c663deb5f  vmovaps xmm9, [rsp+0x90]
0000790c663deb68  vmovaps xmm10, [rsp+0xA0]
0000790c663deb71  vmovaps xmm11, [rsp+0xB0]
0000790c663deb7a  vmovaps xmm12, [rsp+0xC0]
0000790c663deb83  vmovaps xmm13, [rsp+0xD0]
0000790c663deb8c  vmovaps xmm14, [rsp+0xE0]
0000790c663deb95  add rsp, 0xF0
0000790c663deb9c  pop r11
0000790c663deb9e  pop r10
0000790c663deba0  pop r9
0000790c663deba2  pop r8
0000790c663deba4  pop rsi
0000790c663deba5  pop rdi
0000790c663deba6  pop rdx
0000790c663deba7  pop rcx
0000790c663deba8  pop rax
0000790c663deba9  add rsp, 0x08
0000790c663debad  jmp 0x0000790C663DC2AA
0000790c663debb2  sub rsp, 0x08
0000790c663debb6  push rax
0000790c663debb7  push rcx
0000790c663debb8  push rdx
0000790c663debb9  push rdi
0000790c663debba  push rsi
0000790c663debbb  push r8
0000790c663debbd  push r9
0000790c663debbf  push r10
0000790c663debc1  push r11
0000790c663debc3  sub rsp, 0xF0
0000790c663debca  vmovaps [rsp], xmm0
0000790c663debcf  vmovaps [rsp+0x10], xmm1
0000790c663debd5  vmovaps [rsp+0x20], xmm2
0000790c663debdb  vmovaps [rsp+0x30], xmm3
0000790c663debe1  vmovaps [rsp+0x40], xmm4
0000790c663debe7  vmovaps [rsp+0x50], xmm5
0000790c663debed  vmovaps [rsp+0x60], xmm6
0000790c663debf3  vmovaps [rsp+0x70], xmm7
0000790c663debf9  vmovaps [rsp+0x80], xmm8
0000790c663dec02  vmovaps [rsp+0x90], xmm9
0000790c663dec0b  vmovaps [rsp+0xA0], xmm10
0000790c663dec14  vmovaps [rsp+0xB0], xmm11
0000790c663dec1d  vmovaps [rsp+0xC0], xmm12
0000790c663dec26  vmovaps [rsp+0xD0], xmm13
0000790c663dec2f  vmovaps [rsp+0xE0], xmm15
0000790c663dec38  sub rsp, 0x30
0000790c663dec3c  movaps [rsp], xmm14
0000790c663dec41  movaps [rsp+0x10], xmm2
0000790c663dec46  movaps [rsp+0x20], xmm1
0000790c663dec4b  lea rdi, [rsp]
0000790c663dec4f  mov esi, 0x00
0000790c663dec54  mov rax, 0x631C1759F530
0000790c663dec5e  call rax
0000790c663dec60  movaps xmm14, [rsp]
0000790c663dec65  add rsp, 0x30
0000790c663dec69  vmovaps xmm0, [rsp]
0000790c663dec6e  vmovaps xmm1, [rsp+0x10]
0000790c663dec74  vmovaps xmm2, [rsp+0x20]
0000790c663dec7a  vmovaps xmm3, [rsp+0x30]
0000790c663dec80  vmovaps xmm4, [rsp+0x40]
0000790c663dec86  vmovaps xmm5, [rsp+0x50]
0000790c663dec8c  vmovaps xmm6, [rsp+0x60]
0000790c663dec92  vmovaps xmm7, [rsp+0x70]
0000790c663dec98  vmovaps xmm8, [rsp+0x80]
0000790c663deca1  vmovaps xmm9, [rsp+0x90]
0000790c663decaa  vmovaps xmm10, [rsp+0xA0]
0000790c663decb3  vmovaps xmm11, [rsp+0xB0]
0000790c663decbc  vmovaps xmm12, [rsp+0xC0]
0000790c663decc5  vmovaps xmm13, [rsp+0xD0]
0000790c663decce  vmovaps xmm15, [rsp+0xE0]
0000790c663decd7  add rsp, 0xF0
0000790c663decde  pop r11
0000790c663dece0  pop r10
0000790c663dece2  pop r9
0000790c663dece4  pop r8
0000790c663dece6  pop rsi
0000790c663dece7  pop rdi
0000790c663dece8  pop rdx
0000790c663dece9  pop rcx
0000790c663decea  pop rax
0000790c663deceb  add rsp, 0x08
0000790c663decef  jmp 0x0000790C663DC2D0
0000790c663decf4  sub rsp, 0x08
0000790c663decf8  push rax
0000790c663decf9  push rcx
0000790c663decfa  push rdx
0000790c663decfb  push rdi
0000790c663decfc  push rsi
0000790c663decfd  push r8
0000790c663decff  push r9
0000790c663ded01  push r10
0000790c663ded03  push r11
0000790c663ded05  sub rsp, 0xF0
0000790c663ded0c  vmovaps [rsp], xmm0
0000790c663ded11  vmovaps [rsp+0x10], xmm2
0000790c663ded17  vmovaps [rsp+0x20], xmm3
0000790c663ded1d  vmovaps [rsp+0x30], xmm4
0000790c663ded23  vmovaps [rsp+0x40], xmm5
0000790c663ded29  vmovaps [rsp+0x50], xmm6
0000790c663ded2f  vmovaps [rsp+0x60], xmm7
0000790c663ded35  vmovaps [rsp+0x70], xmm8
0000790c663ded3b  vmovaps [rsp+0x80], xmm9
0000790c663ded44  vmovaps [rsp+0x90], xmm10
0000790c663ded4d  vmovaps [rsp+0xA0], xmm11
0000790c663ded56  vmovaps [rsp+0xB0], xmm12
0000790c663ded5f  vmovaps [rsp+0xC0], xmm13
0000790c663ded68  vmovaps [rsp+0xD0], xmm14
0000790c663ded71  vmovaps [rsp+0xE0], xmm15
0000790c663ded7a  sub rsp, 0x30
0000790c663ded7e  movaps [rsp], xmm1
0000790c663ded82  movaps [rsp+0x10], xmm4
0000790c663ded87  movaps [rsp+0x20], xmm9
0000790c663ded8d  lea rdi, [rsp]
0000790c663ded91  mov esi, 0x00
0000790c663ded96  mov rax, 0x631C1759F530
0000790c663deda0  call rax
0000790c663deda2  movaps xmm1, [rsp]
0000790c663deda6  add rsp, 0x30
0000790c663dedaa  vmovaps xmm0, [rsp]
0000790c663dedaf  vmovaps xmm2, [rsp+0x10]
0000790c663dedb5  vmovaps xmm3, [rsp+0x20]
0000790c663dedbb  vmovaps xmm4, [rsp+0x30]
0000790c663dedc1  vmovaps xmm5, [rsp+0x40]
0000790c663dedc7  vmovaps xmm6, [rsp+0x50]
0000790c663dedcd  vmovaps xmm7, [rsp+0x60]
0000790c663dedd3  vmovaps xmm8, [rsp+0x70]
0000790c663dedd9  vmovaps xmm9, [rsp+0x80]
0000790c663dede2  vmovaps xmm10, [rsp+0x90]
0000790c663dedeb  vmovaps xmm11, [rsp+0xA0]
0000790c663dedf4  vmovaps xmm12, [rsp+0xB0]
0000790c663dedfd  vmovaps xmm13, [rsp+0xC0]
0000790c663dee06  vmovaps xmm14, [rsp+0xD0]
0000790c663dee0f  vmovaps xmm15, [rsp+0xE0]
0000790c663dee18  add rsp, 0xF0
0000790c663dee1f  pop r11
0000790c663dee21  pop r10
0000790c663dee23  pop r9
0000790c663dee25  pop r8
0000790c663dee27  pop rsi
0000790c663dee28  pop rdi
0000790c663dee29  pop rdx
0000790c663dee2a  pop rcx
0000790c663dee2b  pop rax
0000790c663dee2c  add rsp, 0x08
0000790c663dee30  jmp 0x0000790C663DC2EE
0000790c663dee35  sub rsp, 0x08
0000790c663dee39  push rax
0000790c663dee3a  push rcx
0000790c663dee3b  push rdx
0000790c663dee3c  push rdi
0000790c663dee3d  push rsi
0000790c663dee3e  push r8
0000790c663dee40  push r9
0000790c663dee42  push r10
0000790c663dee44  push r11
0000790c663dee46  sub rsp, 0xF0
0000790c663dee4d  vmovaps [rsp], xmm0
0000790c663dee52  vmovaps [rsp+0x10], xmm1
0000790c663dee58  vmovaps [rsp+0x20], xmm2
0000790c663dee5e  vmovaps [rsp+0x30], xmm3
0000790c663dee64  vmovaps [rsp+0x40], xmm5
0000790c663dee6a  vmovaps [rsp+0x50], xmm6
0000790c663dee70  vmovaps [rsp+0x60], xmm7
0000790c663dee76  vmovaps [rsp+0x70], xmm8
0000790c663dee7c  vmovaps [rsp+0x80], xmm9
0000790c663dee85  vmovaps [rsp+0x90], xmm10
0000790c663dee8e  vmovaps [rsp+0xA0], xmm11
0000790c663dee97  vmovaps [rsp+0xB0], xmm12
0000790c663deea0  vmovaps [rsp+0xC0], xmm13
0000790c663deea9  vmovaps [rsp+0xD0], xmm14
0000790c663deeb2  vmovaps [rsp+0xE0], xmm15
0000790c663deebb  sub rsp, 0x30
0000790c663deebf  movaps [rsp], xmm4
0000790c663deec3  movaps [rsp+0x10], xmm2
0000790c663deec8  movaps [rsp+0x20], xmm9
0000790c663deece  lea rdi, [rsp]
0000790c663deed2  mov esi, 0x00
0000790c663deed7  mov rax, 0x631C1759F530
0000790c663deee1  call rax
0000790c663deee3  movaps xmm4, [rsp]
0000790c663deee7  add rsp, 0x30
0000790c663deeeb  vmovaps xmm0, [rsp]
0000790c663deef0  vmovaps xmm1, [rsp+0x10]
0000790c663deef6  vmovaps xmm2, [rsp+0x20]
0000790c663deefc  vmovaps xmm3, [rsp+0x30]
0000790c663def02  vmovaps xmm5, [rsp+0x40]
0000790c663def08  vmovaps xmm6, [rsp+0x50]
0000790c663def0e  vmovaps xmm7, [rsp+0x60]
0000790c663def14  vmovaps xmm8, [rsp+0x70]
0000790c663def1a  vmovaps xmm9, [rsp+0x80]
0000790c663def23  vmovaps xmm10, [rsp+0x90]
0000790c663def2c  vmovaps xmm11, [rsp+0xA0]
0000790c663def35  vmovaps xmm12, [rsp+0xB0]
0000790c663def3e  vmovaps xmm13, [rsp+0xC0]
0000790c663def47  vmovaps xmm14, [rsp+0xD0]
0000790c663def50  vmovaps xmm15, [rsp+0xE0]
0000790c663def59  add rsp, 0xF0
0000790c663def60  pop r11
0000790c663def62  pop r10
0000790c663def64  pop r9
0000790c663def66  pop r8
0000790c663def68  pop rsi
0000790c663def69  pop rdi
0000790c663def6a  pop rdx
0000790c663def6b  pop rcx
0000790c663def6c  pop rax
0000790c663def6d  add rsp, 0x08
0000790c663def71  jmp 0x0000790C663DC31E
0000790c663def76  sub rsp, 0x08
0000790c663def7a  push rax
0000790c663def7b  push rcx
0000790c663def7c  push rdx
0000790c663def7d  push rdi
0000790c663def7e  push rsi
0000790c663def7f  push r8
0000790c663def81  push r9
0000790c663def83  push r10
0000790c663def85  push r11
0000790c663def87  sub rsp, 0xF0
0000790c663def8e  vmovaps [rsp], xmm0
0000790c663def93  vmovaps [rsp+0x10], xmm1
0000790c663def99  vmovaps [rsp+0x20], xmm2
0000790c663def9f  vmovaps [rsp+0x30], xmm3
0000790c663defa5  vmovaps [rsp+0x40], xmm4
0000790c663defab  vmovaps [rsp+0x50], xmm5
0000790c663defb1  vmovaps [rsp+0x60], xmm6
0000790c663defb7  vmovaps [rsp+0x70], xmm7
0000790c663defbd  vmovaps [rsp+0x80], xmm8
0000790c663defc6  vmovaps [rsp+0x90], xmm10
0000790c663defcf  vmovaps [rsp+0xA0], xmm11
0000790c663defd8  vmovaps [rsp+0xB0], xmm12
0000790c663defe1  vmovaps [rsp+0xC0], xmm13
0000790c663defea  vmovaps [rsp+0xD0], xmm14
0000790c663deff3  vmovaps [rsp+0xE0], xmm15
0000790c663deffc  sub rsp, 0x30
0000790c663df000  movaps [rsp], xmm9
0000790c663df005  movaps [rsp+0x10], xmm2
0000790c663df00a  movaps [rsp+0x20], xmm1
0000790c663df00f  lea rdi, [rsp]
0000790c663df013  mov esi, 0x00
0000790c663df018  mov rax, 0x631C1759F530
0000790c663df022  call rax
0000790c663df024  movaps xmm9, [rsp]
0000790c663df029  add rsp, 0x30
0000790c663df02d  vmovaps xmm0, [rsp]
0000790c663df032  vmovaps xmm1, [rsp+0x10]
0000790c663df038  vmovaps xmm2, [rsp+0x20]
0000790c663df03e  vmovaps xmm3, [rsp+0x30]
0000790c663df044  vmovaps xmm4, [rsp+0x40]
0000790c663df04a  vmovaps xmm5, [rsp+0x50]
0000790c663df050  vmovaps xmm6, [rsp+0x60]
0000790c663df056  vmovaps xmm7, [rsp+0x70]
0000790c663df05c  vmovaps xmm8, [rsp+0x80]
0000790c663df065  vmovaps xmm10, [rsp+0x90]
0000790c663df06e  vmovaps xmm11, [rsp+0xA0]
0000790c663df077  vmovaps xmm12, [rsp+0xB0]
0000790c663df080  vmovaps xmm13, [rsp+0xC0]
0000790c663df089  vmovaps xmm14, [rsp+0xD0]
0000790c663df092  vmovaps xmm15, [rsp+0xE0]
0000790c663df09b  add rsp, 0xF0
0000790c663df0a2  pop r11
0000790c663df0a4  pop r10
0000790c663df0a6  pop r9
0000790c663df0a8  pop r8
0000790c663df0aa  pop rsi
0000790c663df0ab  pop rdi
0000790c663df0ac  pop rdx
0000790c663df0ad  pop rcx
0000790c663df0ae  pop rax
0000790c663df0af  add rsp, 0x08
0000790c663df0b3  jmp 0x0000790C663DC354
0000790c663df0b8  sub rsp, 0x08
0000790c663df0bc  push rax
0000790c663df0bd  push rcx
0000790c663df0be  push rdx
0000790c663df0bf  push rdi
0000790c663df0c0  push rsi
0000790c663df0c1  push r8
0000790c663df0c3  push r9
0000790c663df0c5  push r10
0000790c663df0c7  push r11
0000790c663df0c9  sub rsp, 0xF0
0000790c663df0d0  vmovaps [rsp], xmm0
0000790c663df0d5  vmovaps [rsp+0x10], xmm2
0000790c663df0db  vmovaps [rsp+0x20], xmm3
0000790c663df0e1  vmovaps [rsp+0x30], xmm4
0000790c663df0e7  vmovaps [rsp+0x40], xmm5
0000790c663df0ed  vmovaps [rsp+0x50], xmm6
0000790c663df0f3  vmovaps [rsp+0x60], xmm7
0000790c663df0f9  vmovaps [rsp+0x70], xmm8
0000790c663df0ff  vmovaps [rsp+0x80], xmm9
0000790c663df108  vmovaps [rsp+0x90], xmm10
0000790c663df111  vmovaps [rsp+0xA0], xmm11
0000790c663df11a  vmovaps [rsp+0xB0], xmm12
0000790c663df123  vmovaps [rsp+0xC0], xmm13
0000790c663df12c  vmovaps [rsp+0xD0], xmm14
0000790c663df135  vmovaps [rsp+0xE0], xmm15
0000790c663df13e  sub rsp, 0x30
0000790c663df142  movaps [rsp], xmm1
0000790c663df146  movaps [rsp+0x10], xmm15
0000790c663df14c  movaps [rsp+0x20], xmm6
0000790c663df151  lea rdi, [rsp]
0000790c663df155  mov esi, 0x00
0000790c663df15a  mov rax, 0x631C1759F530
0000790c663df164  call rax
0000790c663df166  movaps xmm1, [rsp]
0000790c663df16a  add rsp, 0x30
0000790c663df16e  vmovaps xmm0, [rsp]
0000790c663df173  vmovaps xmm2, [rsp+0x10]
0000790c663df179  vmovaps xmm3, [rsp+0x20]
0000790c663df17f  vmovaps xmm4, [rsp+0x30]
0000790c663df185  vmovaps xmm5, [rsp+0x40]
0000790c663df18b  vmovaps xmm6, [rsp+0x50]
0000790c663df191  vmovaps xmm7, [rsp+0x60]
0000790c663df197  vmovaps xmm8, [rsp+0x70]
0000790c663df19d  vmovaps xmm9, [rsp+0x80]
0000790c663df1a6  vmovaps xmm10, [rsp+0x90]
0000790c663df1af  vmovaps xmm11, [rsp+0xA0]
0000790c663df1b8  vmovaps xmm12, [rsp+0xB0]
0000790c663df1c1  vmovaps xmm13, [rsp+0xC0]
0000790c663df1ca  vmovaps xmm14, [rsp+0xD0]
0000790c663df1d3  vmovaps xmm15, [rsp+0xE0]
0000790c663df1dc  add rsp, 0xF0
0000790c663df1e3  pop r11
0000790c663df1e5  pop r10
0000790c663df1e7  pop r9
0000790c663df1e9  pop r8
0000790c663df1eb  pop rsi
0000790c663df1ec  pop rdi
0000790c663df1ed  pop rdx
0000790c663df1ee  pop rcx
0000790c663df1ef  pop rax
0000790c663df1f0  add rsp, 0x08
0000790c663df1f4  jmp 0x0000790C663DC375
0000790c663df1f9  sub rsp, 0x08
0000790c663df1fd  push rax
0000790c663df1fe  push rcx
0000790c663df1ff  push rdx
0000790c663df200  push rdi
0000790c663df201  push rsi
0000790c663df202  push r8
0000790c663df204  push r9
0000790c663df206  push r10
0000790c663df208  push r11
0000790c663df20a  sub rsp, 0xF0
0000790c663df211  vmovaps [rsp], xmm0
0000790c663df216  vmovaps [rsp+0x10], xmm1
0000790c663df21c  vmovaps [rsp+0x20], xmm2
0000790c663df222  vmovaps [rsp+0x30], xmm3
0000790c663df228  vmovaps [rsp+0x40], xmm4
0000790c663df22e  vmovaps [rsp+0x50], xmm5
0000790c663df234  vmovaps [rsp+0x60], xmm6
0000790c663df23a  vmovaps [rsp+0x70], xmm7
0000790c663df240  vmovaps [rsp+0x80], xmm8
0000790c663df249  vmovaps [rsp+0x90], xmm9
0000790c663df252  vmovaps [rsp+0xA0], xmm10
0000790c663df25b  vmovaps [rsp+0xB0], xmm11
0000790c663df264  vmovaps [rsp+0xC0], xmm12
0000790c663df26d  vmovaps [rsp+0xD0], xmm13
0000790c663df276  vmovaps [rsp+0xE0], xmm14
0000790c663df27f  sub rsp, 0x30
0000790c663df283  movaps [rsp], xmm15
0000790c663df288  movaps [rsp+0x10], xmm5
0000790c663df28d  movaps [rsp+0x20], xmm3
0000790c663df292  lea rdi, [rsp]
0000790c663df296  mov esi, 0x00
0000790c663df29b  mov rax, 0x631C1759F530
0000790c663df2a5  call rax
0000790c663df2a7  movaps xmm15, [rsp]
0000790c663df2ac  add rsp, 0x30
0000790c663df2b0  vmovaps xmm0, [rsp]
0000790c663df2b5  vmovaps xmm1, [rsp+0x10]
0000790c663df2bb  vmovaps xmm2, [rsp+0x20]
0000790c663df2c1  vmovaps xmm3, [rsp+0x30]
0000790c663df2c7  vmovaps xmm4, [rsp+0x40]
0000790c663df2cd  vmovaps xmm5, [rsp+0x50]
0000790c663df2d3  vmovaps xmm6, [rsp+0x60]
0000790c663df2d9  vmovaps xmm7, [rsp+0x70]
0000790c663df2df  vmovaps xmm8, [rsp+0x80]
0000790c663df2e8  vmovaps xmm9, [rsp+0x90]
0000790c663df2f1  vmovaps xmm10, [rsp+0xA0]
0000790c663df2fa  vmovaps xmm11, [rsp+0xB0]
0000790c663df303  vmovaps xmm12, [rsp+0xC0]
0000790c663df30c  vmovaps xmm13, [rsp+0xD0]
0000790c663df315  vmovaps xmm14, [rsp+0xE0]
0000790c663df31e  add rsp, 0xF0
0000790c663df325  pop r11
0000790c663df327  pop r10
0000790c663df329  pop r9
0000790c663df32b  pop r8
0000790c663df32d  pop rsi
0000790c663df32e  pop rdi
0000790c663df32f  pop rdx
0000790c663df330  pop rcx
0000790c663df331  pop rax
0000790c663df332  add rsp, 0x08
0000790c663df336  jmp 0x0000790C663DC38F
0000790c663df33b  sub rsp, 0x08
0000790c663df33f  push rax
0000790c663df340  push rcx
0000790c663df341  push rdx
0000790c663df342  push rdi
0000790c663df343  push rsi
0000790c663df344  push r8
0000790c663df346  push r9
0000790c663df348  push r10
0000790c663df34a  push r11
0000790c663df34c  sub rsp, 0xF0
0000790c663df353  vmovaps [rsp], xmm0
0000790c663df358  vmovaps [rsp+0x10], xmm1
0000790c663df35e  vmovaps [rsp+0x20], xmm2
0000790c663df364  vmovaps [rsp+0x30], xmm3
0000790c663df36a  vmovaps [rsp+0x40], xmm4
0000790c663df370  vmovaps [rsp+0x50], xmm6
0000790c663df376  vmovaps [rsp+0x60], xmm7
0000790c663df37c  vmovaps [rsp+0x70], xmm8
0000790c663df382  vmovaps [rsp+0x80], xmm9
0000790c663df38b  vmovaps [rsp+0x90], xmm10
0000790c663df394  vmovaps [rsp+0xA0], xmm11
0000790c663df39d  vmovaps [rsp+0xB0], xmm12
0000790c663df3a6  vmovaps [rsp+0xC0], xmm13
0000790c663df3af  vmovaps [rsp+0xD0], xmm14
0000790c663df3b8  vmovaps [rsp+0xE0], xmm15
0000790c663df3c1  sub rsp, 0x30
0000790c663df3c5  movaps [rsp], xmm5
0000790c663df3c9  movaps [rsp+0x10], xmm8
0000790c663df3cf  movaps [rsp+0x20], xmm6
0000790c663df3d4  lea rdi, [rsp]
0000790c663df3d8  mov esi, 0x00
0000790c663df3dd  mov rax, 0x631C1759F530
0000790c663df3e7  call rax
0000790c663df3e9  movaps xmm5, [rsp]
0000790c663df3ed  add rsp, 0x30
0000790c663df3f1  vmovaps xmm0, [rsp]
0000790c663df3f6  vmovaps xmm1, [rsp+0x10]
0000790c663df3fc  vmovaps xmm2, [rsp+0x20]
0000790c663df402  vmovaps xmm3, [rsp+0x30]
0000790c663df408  vmovaps xmm4, [rsp+0x40]
0000790c663df40e  vmovaps xmm6, [rsp+0x50]
0000790c663df414  vmovaps xmm7, [rsp+0x60]
0000790c663df41a  vmovaps xmm8, [rsp+0x70]
0000790c663df420  vmovaps xmm9, [rsp+0x80]
0000790c663df429  vmovaps xmm10, [rsp+0x90]
0000790c663df432  vmovaps xmm11, [rsp+0xA0]
0000790c663df43b  vmovaps xmm12, [rsp+0xB0]
0000790c663df444  vmovaps xmm13, [rsp+0xC0]
0000790c663df44d  vmovaps xmm14, [rsp+0xD0]
0000790c663df456  vmovaps xmm15, [rsp+0xE0]
0000790c663df45f  add rsp, 0xF0
0000790c663df466  pop r11
0000790c663df468  pop r10
0000790c663df46a  pop r9
0000790c663df46c  pop r8
0000790c663df46e  pop rsi
0000790c663df46f  pop rdi
0000790c663df470  pop rdx
0000790c663df471  pop rcx
0000790c663df472  pop rax
0000790c663df473  add rsp, 0x08
0000790c663df477  jmp 0x0000790C663DC3B3
0000790c663df47c  sub rsp, 0x08
0000790c663df480  push rax
0000790c663df481  push rcx
0000790c663df482  push rdx
0000790c663df483  push rdi
0000790c663df484  push rsi
0000790c663df485  push r8
0000790c663df487  push r9
0000790c663df489  push r10
0000790c663df48b  push r11
0000790c663df48d  sub rsp, 0xF0
0000790c663df494  vmovaps [rsp], xmm0
0000790c663df499  vmovaps [rsp+0x10], xmm1
0000790c663df49f  vmovaps [rsp+0x20], xmm2
0000790c663df4a5  vmovaps [rsp+0x30], xmm3
0000790c663df4ab  vmovaps [rsp+0x40], xmm4
0000790c663df4b1  vmovaps [rsp+0x50], xmm5
0000790c663df4b7  vmovaps [rsp+0x60], xmm7
0000790c663df4bd  vmovaps [rsp+0x70], xmm8
0000790c663df4c3  vmovaps [rsp+0x80], xmm9
0000790c663df4cc  vmovaps [rsp+0x90], xmm10
0000790c663df4d5  vmovaps [rsp+0xA0], xmm11
0000790c663df4de  vmovaps [rsp+0xB0], xmm12
0000790c663df4e7  vmovaps [rsp+0xC0], xmm13
0000790c663df4f0  vmovaps [rsp+0xD0], xmm14
0000790c663df4f9  vmovaps [rsp+0xE0], xmm15
0000790c663df502  sub rsp, 0x30
0000790c663df506  movaps [rsp], xmm6
0000790c663df50a  movaps [rsp+0x10], xmm10
0000790c663df510  movaps [rsp+0x20], xmm8
0000790c663df516  lea rdi, [rsp]
0000790c663df51a  mov esi, 0x00
0000790c663df51f  mov rax, 0x631C1759F530
0000790c663df529  call rax
0000790c663df52b  movaps xmm6, [rsp]
0000790c663df52f  add rsp, 0x30
0000790c663df533  vmovaps xmm0, [rsp]
0000790c663df538  vmovaps xmm1, [rsp+0x10]
0000790c663df53e  vmovaps xmm2, [rsp+0x20]
0000790c663df544  vmovaps xmm3, [rsp+0x30]
0000790c663df54a  vmovaps xmm4, [rsp+0x40]
0000790c663df550  vmovaps xmm5, [rsp+0x50]
0000790c663df556  vmovaps xmm7, [rsp+0x60]
0000790c663df55c  vmovaps xmm8, [rsp+0x70]
0000790c663df562  vmovaps xmm9, [rsp+0x80]
0000790c663df56b  vmovaps xmm10, [rsp+0x90]
0000790c663df574  vmovaps xmm11, [rsp+0xA0]
0000790c663df57d  vmovaps xmm12, [rsp+0xB0]
0000790c663df586  vmovaps xmm13, [rsp+0xC0]
0000790c663df58f  vmovaps xmm14, [rsp+0xD0]
0000790c663df598  vmovaps xmm15, [rsp+0xE0]
0000790c663df5a1  add rsp, 0xF0
0000790c663df5a8  pop r11
0000790c663df5aa  pop r10
0000790c663df5ac  pop r9
0000790c663df5ae  pop r8
0000790c663df5b0  pop rsi
0000790c663df5b1  pop rdi
0000790c663df5b2  pop rdx
0000790c663df5b3  pop rcx
0000790c663df5b4  pop rax
0000790c663df5b5  add rsp, 0x08
0000790c663df5b9  jmp 0x0000790C663DC3D8
0000790c663df5be  sub rsp, 0x08
0000790c663df5c2  push rax
0000790c663df5c3  push rcx
0000790c663df5c4  push rdx
0000790c663df5c5  push rdi
0000790c663df5c6  push rsi
0000790c663df5c7  push r8
0000790c663df5c9  push r9
0000790c663df5cb  push r10
0000790c663df5cd  push r11
0000790c663df5cf  sub rsp, 0xF0
0000790c663df5d6  vmovaps [rsp], xmm0
0000790c663df5db  vmovaps [rsp+0x10], xmm1
0000790c663df5e1  vmovaps [rsp+0x20], xmm2
0000790c663df5e7  vmovaps [rsp+0x30], xmm3
0000790c663df5ed  vmovaps [rsp+0x40], xmm4
0000790c663df5f3  vmovaps [rsp+0x50], xmm5
0000790c663df5f9  vmovaps [rsp+0x60], xmm6
0000790c663df5ff  vmovaps [rsp+0x70], xmm7
0000790c663df605  vmovaps [rsp+0x80], xmm8
0000790c663df60e  vmovaps [rsp+0x90], xmm9
0000790c663df617  vmovaps [rsp+0xA0], xmm11
0000790c663df620  vmovaps [rsp+0xB0], xmm12
0000790c663df629  vmovaps [rsp+0xC0], xmm13
0000790c663df632  vmovaps [rsp+0xD0], xmm14
0000790c663df63b  vmovaps [rsp+0xE0], xmm15
0000790c663df644  sub rsp, 0x30
0000790c663df648  movaps [rsp], xmm10
0000790c663df64d  movaps [rsp+0x10], xmm8
0000790c663df653  movaps [rsp+0x20], xmm14
0000790c663df659  lea rdi, [rsp]
0000790c663df65d  mov esi, 0x00
0000790c663df662  mov rax, 0x631C1759F530
0000790c663df66c  call rax
0000790c663df66e  movaps xmm10, [rsp]
0000790c663df673  add rsp, 0x30
0000790c663df677  vmovaps xmm0, [rsp]
0000790c663df67c  vmovaps xmm1, [rsp+0x10]
0000790c663df682  vmovaps xmm2, [rsp+0x20]
0000790c663df688  vmovaps xmm3, [rsp+0x30]
0000790c663df68e  vmovaps xmm4, [rsp+0x40]
0000790c663df694  vmovaps xmm5, [rsp+0x50]
0000790c663df69a  vmovaps xmm6, [rsp+0x60]
0000790c663df6a0  vmovaps xmm7, [rsp+0x70]
0000790c663df6a6  vmovaps xmm8, [rsp+0x80]
0000790c663df6af  vmovaps xmm9, [rsp+0x90]
0000790c663df6b8  vmovaps xmm11, [rsp+0xA0]
0000790c663df6c1  vmovaps xmm12, [rsp+0xB0]
0000790c663df6ca  vmovaps xmm13, [rsp+0xC0]
0000790c663df6d3  vmovaps xmm14, [rsp+0xD0]
0000790c663df6dc  vmovaps xmm15, [rsp+0xE0]
0000790c663df6e5  add rsp, 0xF0
0000790c663df6ec  pop r11
0000790c663df6ee  pop r10
0000790c663df6f0  pop r9
0000790c663df6f2  pop r8
0000790c663df6f4  pop rsi
0000790c663df6f5  pop rdi
0000790c663df6f6  pop rdx
0000790c663df6f7  pop rcx
0000790c663df6f8  pop rax
0000790c663df6f9  add rsp, 0x08
0000790c663df6fd  jmp 0x0000790C663DC3F8
0000790c663df702  sub rsp, 0x08
0000790c663df706  push rax
0000790c663df707  push rcx
0000790c663df708  push rdx
0000790c663df709  push rdi
0000790c663df70a  push rsi
0000790c663df70b  push r8
0000790c663df70d  push r9
0000790c663df70f  push r10
0000790c663df711  push r11
0000790c663df713  sub rsp, 0xF0
0000790c663df71a  vmovaps [rsp], xmm0
0000790c663df71f  vmovaps [rsp+0x10], xmm1
0000790c663df725  vmovaps [rsp+0x20], xmm2
0000790c663df72b  vmovaps [rsp+0x30], xmm3
0000790c663df731  vmovaps [rsp+0x40], xmm4
0000790c663df737  vmovaps [rsp+0x50], xmm5
0000790c663df73d  vmovaps [rsp+0x60], xmm6
0000790c663df743  vmovaps [rsp+0x70], xmm7
0000790c663df749  vmovaps [rsp+0x80], xmm8
0000790c663df752  vmovaps [rsp+0x90], xmm9
0000790c663df75b  vmovaps [rsp+0xA0], xmm10
0000790c663df764  vmovaps [rsp+0xB0], xmm11
0000790c663df76d  vmovaps [rsp+0xC0], xmm12
0000790c663df776  vmovaps [rsp+0xD0], xmm13
0000790c663df77f  vmovaps [rsp+0xE0], xmm15
0000790c663df788  sub rsp, 0x30
0000790c663df78c  movaps [rsp], xmm14
0000790c663df791  movaps [rsp+0x10], xmm8
0000790c663df797  movaps [rsp+0x20], xmm4
0000790c663df79c  lea rdi, [rsp]
0000790c663df7a0  mov esi, 0x00
0000790c663df7a5  mov rax, 0x631C1759F530
0000790c663df7af  call rax
0000790c663df7b1  movaps xmm14, [rsp]
0000790c663df7b6  add rsp, 0x30
0000790c663df7ba  vmovaps xmm0, [rsp]
0000790c663df7bf  vmovaps xmm1, [rsp+0x10]
0000790c663df7c5  vmovaps xmm2, [rsp+0x20]
0000790c663df7cb  vmovaps xmm3, [rsp+0x30]
0000790c663df7d1  vmovaps xmm4, [rsp+0x40]
0000790c663df7d7  vmovaps xmm5, [rsp+0x50]
0000790c663df7dd  vmovaps xmm6, [rsp+0x60]
0000790c663df7e3  vmovaps xmm7, [rsp+0x70]
0000790c663df7e9  vmovaps xmm8, [rsp+0x80]
0000790c663df7f2  vmovaps xmm9, [rsp+0x90]
0000790c663df7fb  vmovaps xmm10, [rsp+0xA0]
0000790c663df804  vmovaps xmm11, [rsp+0xB0]
0000790c663df80d  vmovaps xmm12, [rsp+0xC0]
0000790c663df816  vmovaps xmm13, [rsp+0xD0]
0000790c663df81f  vmovaps xmm15, [rsp+0xE0]
0000790c663df828  add rsp, 0xF0
0000790c663df82f  pop r11
0000790c663df831  pop r10
0000790c663df833  pop r9
0000790c663df835  pop r8
0000790c663df837  pop rsi
0000790c663df838  pop rdi
0000790c663df839  pop rdx
0000790c663df83a  pop rcx
0000790c663df83b  pop rax
0000790c663df83c  add rsp, 0x08
0000790c663df840  jmp 0x0000790C663DC418
0000790c663df845  sub rsp, 0x08
0000790c663df849  push rax
0000790c663df84a  push rcx
0000790c663df84b  push rdx
0000790c663df84c  push rdi
0000790c663df84d  push rsi
0000790c663df84e  push r8
0000790c663df850  push r9
0000790c663df852  push r10
0000790c663df854  push r11
0000790c663df856  sub rsp, 0xF0
0000790c663df85d  vmovaps [rsp], xmm0
0000790c663df862  vmovaps [rsp+0x10], xmm1
0000790c663df868  vmovaps [rsp+0x20], xmm2
0000790c663df86e  vmovaps [rsp+0x30], xmm3
0000790c663df874  vmovaps [rsp+0x40], xmm5
0000790c663df87a  vmovaps [rsp+0x50], xmm6
0000790c663df880  vmovaps [rsp+0x60], xmm7
0000790c663df886  vmovaps [rsp+0x70], xmm8
0000790c663df88c  vmovaps [rsp+0x80], xmm9
0000790c663df895  vmovaps [rsp+0x90], xmm10
0000790c663df89e  vmovaps [rsp+0xA0], xmm11
0000790c663df8a7  vmovaps [rsp+0xB0], xmm12
0000790c663df8b0  vmovaps [rsp+0xC0], xmm13
0000790c663df8b9  vmovaps [rsp+0xD0], xmm14
0000790c663df8c2  vmovaps [rsp+0xE0], xmm15
0000790c663df8cb  sub rsp, 0x30
0000790c663df8cf  movaps [rsp], xmm4
0000790c663df8d3  movaps [rsp+0x10], xmm13
0000790c663df8d9  movaps [rsp+0x20], xmm8
0000790c663df8df  lea rdi, [rsp]
0000790c663df8e3  mov esi, 0x00
0000790c663df8e8  mov rax, 0x631C1759F530
0000790c663df8f2  call rax
0000790c663df8f4  movaps xmm4, [rsp]
0000790c663df8f8  add rsp, 0x30
0000790c663df8fc  vmovaps xmm0, [rsp]
0000790c663df901  vmovaps xmm1, [rsp+0x10]
0000790c663df907  vmovaps xmm2, [rsp+0x20]
0000790c663df90d  vmovaps xmm3, [rsp+0x30]
0000790c663df913  vmovaps xmm5, [rsp+0x40]
0000790c663df919  vmovaps xmm6, [rsp+0x50]
0000790c663df91f  vmovaps xmm7, [rsp+0x60]
0000790c663df925  vmovaps xmm8, [rsp+0x70]
0000790c663df92b  vmovaps xmm9, [rsp+0x80]
0000790c663df934  vmovaps xmm10, [rsp+0x90]
0000790c663df93d  vmovaps xmm11, [rsp+0xA0]
0000790c663df946  vmovaps xmm12, [rsp+0xB0]
0000790c663df94f  vmovaps xmm13, [rsp+0xC0]
0000790c663df958  vmovaps xmm14, [rsp+0xD0]
0000790c663df961  vmovaps xmm15, [rsp+0xE0]
0000790c663df96a  add rsp, 0xF0
0000790c663df971  pop r11
0000790c663df973  pop r10
0000790c663df975  pop r9
0000790c663df977  pop r8
0000790c663df979  pop rsi
0000790c663df97a  pop rdi
0000790c663df97b  pop rdx
0000790c663df97c  pop rcx
0000790c663df97d  pop rax
0000790c663df97e  add rsp, 0x08
0000790c663df982  jmp 0x0000790C663DC43D
0000790c663df987  sub rsp, 0x08
0000790c663df98b  push rax
0000790c663df98c  push rcx
0000790c663df98d  push rdx
0000790c663df98e  push rdi
0000790c663df98f  push rsi
0000790c663df990  push r8
0000790c663df992  push r9
0000790c663df994  push r10
0000790c663df996  push r11
0000790c663df998  sub rsp, 0xF0
0000790c663df99f  vmovaps [rsp], xmm0
0000790c663df9a4  vmovaps [rsp+0x10], xmm1
0000790c663df9aa  vmovaps [rsp+0x20], xmm2
0000790c663df9b0  vmovaps [rsp+0x30], xmm3
0000790c663df9b6  vmovaps [rsp+0x40], xmm4
0000790c663df9bc  vmovaps [rsp+0x50], xmm5
0000790c663df9c2  vmovaps [rsp+0x60], xmm6
0000790c663df9c8  vmovaps [rsp+0x70], xmm7
0000790c663df9ce  vmovaps [rsp+0x80], xmm8
0000790c663df9d7  vmovaps [rsp+0x90], xmm9
0000790c663df9e0  vmovaps [rsp+0xA0], xmm10
0000790c663df9e9  vmovaps [rsp+0xB0], xmm11
0000790c663df9f2  vmovaps [rsp+0xC0], xmm12
0000790c663df9fb  vmovaps [rsp+0xD0], xmm14
0000790c663dfa04  vmovaps [rsp+0xE0], xmm15
0000790c663dfa0d  sub rsp, 0x30
0000790c663dfa11  movaps [rsp], xmm13
0000790c663dfa16  movaps [rsp+0x10], xmm15
0000790c663dfa1c  movaps [rsp+0x20], xmm9
0000790c663dfa22  lea rdi, [rsp]
0000790c663dfa26  mov esi, 0x00
0000790c663dfa2b  mov rax, 0x631C1759F530
0000790c663dfa35  call rax
0000790c663dfa37  movaps xmm13, [rsp]
0000790c663dfa3c  add rsp, 0x30
0000790c663dfa40  vmovaps xmm0, [rsp]
0000790c663dfa45  vmovaps xmm1, [rsp+0x10]
0000790c663dfa4b  vmovaps xmm2, [rsp+0x20]
0000790c663dfa51  vmovaps xmm3, [rsp+0x30]
0000790c663dfa57  vmovaps xmm4, [rsp+0x40]
0000790c663dfa5d  vmovaps xmm5, [rsp+0x50]
0000790c663dfa63  vmovaps xmm6, [rsp+0x60]
0000790c663dfa69  vmovaps xmm7, [rsp+0x70]
0000790c663dfa6f  vmovaps xmm8, [rsp+0x80]
0000790c663dfa78  vmovaps xmm9, [rsp+0x90]
0000790c663dfa81  vmovaps xmm10, [rsp+0xA0]
0000790c663dfa8a  vmovaps xmm11, [rsp+0xB0]
0000790c663dfa93  vmovaps xmm12, [rsp+0xC0]
0000790c663dfa9c  vmovaps xmm14, [rsp+0xD0]
0000790c663dfaa5  vmovaps xmm15, [rsp+0xE0]
0000790c663dfaae  add rsp, 0xF0
0000790c663dfab5  pop r11
0000790c663dfab7  pop r10
0000790c663dfab9  pop r9
0000790c663dfabb  pop r8
0000790c663dfabd  pop rsi
0000790c663dfabe  pop rdi
0000790c663dfabf  pop rdx
0000790c663dfac0  pop rcx
0000790c663dfac1  pop rax
0000790c663dfac2  add rsp, 0x08
0000790c663dfac6  jmp 0x0000790C663DC458
0000790c663dfacb  sub rsp, 0x08
0000790c663dfacf  push rax
0000790c663dfad0  push rcx
0000790c663dfad1  push rdx
0000790c663dfad2  push rdi
0000790c663dfad3  push rsi
0000790c663dfad4  push r8
0000790c663dfad6  push r9
0000790c663dfad8  push r10
0000790c663dfada  push r11
0000790c663dfadc  sub rsp, 0xF0
0000790c663dfae3  vmovaps [rsp], xmm0
0000790c663dfae8  vmovaps [rsp+0x10], xmm1
0000790c663dfaee  vmovaps [rsp+0x20], xmm2
0000790c663dfaf4  vmovaps [rsp+0x30], xmm3
0000790c663dfafa  vmovaps [rsp+0x40], xmm4
0000790c663dfb00  vmovaps [rsp+0x50], xmm5
0000790c663dfb06  vmovaps [rsp+0x60], xmm6
0000790c663dfb0c  vmovaps [rsp+0x70], xmm7
0000790c663dfb12  vmovaps [rsp+0x80], xmm8
0000790c663dfb1b  vmovaps [rsp+0x90], xmm9
0000790c663dfb24  vmovaps [rsp+0xA0], xmm10
0000790c663dfb2d  vmovaps [rsp+0xB0], xmm11
0000790c663dfb36  vmovaps [rsp+0xC0], xmm12
0000790c663dfb3f  vmovaps [rsp+0xD0], xmm13
0000790c663dfb48  vmovaps [rsp+0xE0], xmm14
0000790c663dfb51  sub rsp, 0x30
0000790c663dfb55  movaps [rsp], xmm15
0000790c663dfb5a  movaps [rsp+0x10], xmm1
0000790c663dfb5f  movaps [rsp+0x20], xmm5
0000790c663dfb64  lea rdi, [rsp]
0000790c663dfb68  mov esi, 0x00
0000790c663dfb6d  mov rax, 0x631C1759F530
0000790c663dfb77  call rax
0000790c663dfb79  movaps xmm15, [rsp]
0000790c663dfb7e  add rsp, 0x30
0000790c663dfb82  vmovaps xmm0, [rsp]
0000790c663dfb87  vmovaps xmm1, [rsp+0x10]
0000790c663dfb8d  vmovaps xmm2, [rsp+0x20]
0000790c663dfb93  vmovaps xmm3, [rsp+0x30]
0000790c663dfb99  vmovaps xmm4, [rsp+0x40]
0000790c663dfb9f  vmovaps xmm5, [rsp+0x50]
0000790c663dfba5  vmovaps xmm6, [rsp+0x60]
0000790c663dfbab  vmovaps xmm7, [rsp+0x70]
0000790c663dfbb1  vmovaps xmm8, [rsp+0x80]
0000790c663dfbba  vmovaps xmm9, [rsp+0x90]
0000790c663dfbc3  vmovaps xmm10, [rsp+0xA0]
0000790c663dfbcc  vmovaps xmm11, [rsp+0xB0]
0000790c663dfbd5  vmovaps xmm12, [rsp+0xC0]
0000790c663dfbde  vmovaps xmm13, [rsp+0xD0]
0000790c663dfbe7  vmovaps xmm14, [rsp+0xE0]
0000790c663dfbf0  add rsp, 0xF0
0000790c663dfbf7  pop r11
0000790c663dfbf9  pop r10
0000790c663dfbfb  pop r9
0000790c663dfbfd  pop r8
0000790c663dfbff  pop rsi
0000790c663dfc00  pop rdi
0000790c663dfc01  pop rdx
0000790c663dfc02  pop rcx
0000790c663dfc03  pop rax
0000790c663dfc04  add rsp, 0x08
0000790c663dfc08  jmp 0x0000790C663DC473
0000790c663dfc0d  call 0x0000790C662B52F0
0000790c663dfc12  jmp 0x0000790C663DC4CE
0000790c663dfc17  sub rsp, 0x08
0000790c663dfc1b  push rax
0000790c663dfc1c  push rcx
0000790c663dfc1d  push rdx
0000790c663dfc1e  push rdi
0000790c663dfc1f  push rsi
0000790c663dfc20  push r8
0000790c663dfc22  push r9
0000790c663dfc24  push r10
0000790c663dfc26  push r11
0000790c663dfc28  sub rsp, 0xF0
0000790c663dfc2f  vmovaps [rsp], xmm0
0000790c663dfc34  vmovaps [rsp+0x10], xmm1
0000790c663dfc3a  vmovaps [rsp+0x20], xmm2
0000790c663dfc40  vmovaps [rsp+0x30], xmm3
0000790c663dfc46  vmovaps [rsp+0x40], xmm4
0000790c663dfc4c  vmovaps [rsp+0x50], xmm5
0000790c663dfc52  vmovaps [rsp+0x60], xmm6
0000790c663dfc58  vmovaps [rsp+0x70], xmm7
0000790c663dfc5e  vmovaps [rsp+0x80], xmm8
0000790c663dfc67  vmovaps [rsp+0x90], xmm10
0000790c663dfc70  vmovaps [rsp+0xA0], xmm11
0000790c663dfc79  vmovaps [rsp+0xB0], xmm12
0000790c663dfc82  vmovaps [rsp+0xC0], xmm13
0000790c663dfc8b  vmovaps [rsp+0xD0], xmm14
0000790c663dfc94  vmovaps [rsp+0xE0], xmm15
0000790c663dfc9d  sub rsp, 0x30
0000790c663dfca1  movaps [rsp], xmm9
0000790c663dfca6  movaps [rsp+0x10], xmm8
0000790c663dfcac  movaps [rsp+0x20], xmm11
0000790c663dfcb2  lea rdi, [rsp]
0000790c663dfcb6  mov esi, 0x00
0000790c663dfcbb  mov rax, 0x631C1759F530
0000790c663dfcc5  call rax
0000790c663dfcc7  movaps xmm9, [rsp]
0000790c663dfccc  add rsp, 0x30
0000790c663dfcd0  vmovaps xmm0, [rsp]
0000790c663dfcd5  vmovaps xmm1, [rsp+0x10]
0000790c663dfcdb  vmovaps xmm2, [rsp+0x20]
0000790c663dfce1  vmovaps xmm3, [rsp+0x30]
0000790c663dfce7  vmovaps xmm4, [rsp+0x40]
0000790c663dfced  vmovaps xmm5, [rsp+0x50]
0000790c663dfcf3  vmovaps xmm6, [rsp+0x60]
0000790c663dfcf9  vmovaps xmm7, [rsp+0x70]
0000790c663dfcff  vmovaps xmm8, [rsp+0x80]
0000790c663dfd08  vmovaps xmm10, [rsp+0x90]
0000790c663dfd11  vmovaps xmm11, [rsp+0xA0]
0000790c663dfd1a  vmovaps xmm12, [rsp+0xB0]
0000790c663dfd23  vmovaps xmm13, [rsp+0xC0]
0000790c663dfd2c  vmovaps xmm14, [rsp+0xD0]
0000790c663dfd35  vmovaps xmm15, [rsp+0xE0]
0000790c663dfd3e  add rsp, 0xF0
0000790c663dfd45  pop r11
0000790c663dfd47  pop r10
0000790c663dfd49  pop r9
0000790c663dfd4b  pop r8
0000790c663dfd4d  pop rsi
0000790c663dfd4e  pop rdi
0000790c663dfd4f  pop rdx
0000790c663dfd50  pop rcx
0000790c663dfd51  pop rax
0000790c663dfd52  add rsp, 0x08
0000790c663dfd56  jmp 0x0000790C663DC505
0000790c663dfd5b  sub rsp, 0x08
0000790c663dfd5f  push rax
0000790c663dfd60  push rcx
0000790c663dfd61  push rdx
0000790c663dfd62  push rdi
0000790c663dfd63  push rsi
0000790c663dfd64  push r8
0000790c663dfd66  push r9
0000790c663dfd68  push r10
0000790c663dfd6a  push r11
0000790c663dfd6c  sub rsp, 0xF0
0000790c663dfd73  vmovaps [rsp], xmm0
0000790c663dfd78  vmovaps [rsp+0x10], xmm1
0000790c663dfd7e  vmovaps [rsp+0x20], xmm2
0000790c663dfd84  vmovaps [rsp+0x30], xmm3
0000790c663dfd8a  vmovaps [rsp+0x40], xmm4
0000790c663dfd90  vmovaps [rsp+0x50], xmm5
0000790c663dfd96  vmovaps [rsp+0x60], xmm6
0000790c663dfd9c  vmovaps [rsp+0x70], xmm7
0000790c663dfda2  vmovaps [rsp+0x80], xmm8
0000790c663dfdab  vmovaps [rsp+0x90], xmm9
0000790c663dfdb4  vmovaps [rsp+0xA0], xmm10
0000790c663dfdbd  vmovaps [rsp+0xB0], xmm12
0000790c663dfdc6  vmovaps [rsp+0xC0], xmm13
0000790c663dfdcf  vmovaps [rsp+0xD0], xmm14
0000790c663dfdd8  vmovaps [rsp+0xE0], xmm15
0000790c663dfde1  sub rsp, 0x30
0000790c663dfde5  movaps [rsp], xmm11
0000790c663dfdea  movaps [rsp+0x10], xmm10
0000790c663dfdf0  movaps [rsp+0x20], xmm6
0000790c663dfdf5  lea rdi, [rsp]
0000790c663dfdf9  mov esi, 0x00
0000790c663dfdfe  mov rax, 0x631C1759F530
0000790c663dfe08  call rax
0000790c663dfe0a  movaps xmm11, [rsp]
0000790c663dfe0f  add rsp, 0x30
0000790c663dfe13  vmovaps xmm0, [rsp]
0000790c663dfe18  vmovaps xmm1, [rsp+0x10]
0000790c663dfe1e  vmovaps xmm2, [rsp+0x20]
0000790c663dfe24  vmovaps xmm3, [rsp+0x30]
0000790c663dfe2a  vmovaps xmm4, [rsp+0x40]
0000790c663dfe30  vmovaps xmm5, [rsp+0x50]
0000790c663dfe36  vmovaps xmm6, [rsp+0x60]
0000790c663dfe3c  vmovaps xmm7, [rsp+0x70]
0000790c663dfe42  vmovaps xmm8, [rsp+0x80]
0000790c663dfe4b  vmovaps xmm9, [rsp+0x90]
0000790c663dfe54  vmovaps xmm10, [rsp+0xA0]
0000790c663dfe5d  vmovaps xmm12, [rsp+0xB0]
0000790c663dfe66  vmovaps xmm13, [rsp+0xC0]
0000790c663dfe6f  vmovaps xmm14, [rsp+0xD0]
0000790c663dfe78  vmovaps xmm15, [rsp+0xE0]
0000790c663dfe81  add rsp, 0xF0
0000790c663dfe88  pop r11
0000790c663dfe8a  pop r10
0000790c663dfe8c  pop r9
0000790c663dfe8e  pop r8
0000790c663dfe90  pop rsi
0000790c663dfe91  pop rdi
0000790c663dfe92  pop rdx
0000790c663dfe93  pop rcx
0000790c663dfe94  pop rax
0000790c663dfe95  add rsp, 0x08
0000790c663dfe99  jmp 0x0000790C663DC520
0000790c663dfe9e  sub rsp, 0x08
0000790c663dfea2  push rax
0000790c663dfea3  push rcx
0000790c663dfea4  push rdx
0000790c663dfea5  push rdi
0000790c663dfea6  push rsi
0000790c663dfea7  push r8
0000790c663dfea9  push r9
0000790c663dfeab  push r10
0000790c663dfead  push r11
0000790c663dfeaf  sub rsp, 0xF0
0000790c663dfeb6  vmovaps [rsp], xmm0
0000790c663dfebb  vmovaps [rsp+0x10], xmm1
0000790c663dfec1  vmovaps [rsp+0x20], xmm2
0000790c663dfec7  vmovaps [rsp+0x30], xmm3
0000790c663dfecd  vmovaps [rsp+0x40], xmm4
0000790c663dfed3  vmovaps [rsp+0x50], xmm5
0000790c663dfed9  vmovaps [rsp+0x60], xmm6
0000790c663dfedf  vmovaps [rsp+0x70], xmm7
0000790c663dfee5  vmovaps [rsp+0x80], xmm8
0000790c663dfeee  vmovaps [rsp+0x90], xmm9
0000790c663dfef7  vmovaps [rsp+0xA0], xmm11
0000790c663dff00  vmovaps [rsp+0xB0], xmm12
0000790c663dff09  vmovaps [rsp+0xC0], xmm13
0000790c663dff12  vmovaps [rsp+0xD0], xmm14
0000790c663dff1b  vmovaps [rsp+0xE0], xmm15
0000790c663dff24  sub rsp, 0x30
0000790c663dff28  movaps [rsp], xmm10
0000790c663dff2d  movaps [rsp+0x10], xmm14
0000790c663dff33  movaps [rsp+0x20], xmm4
0000790c663dff38  lea rdi, [rsp]
0000790c663dff3c  mov esi, 0x00
0000790c663dff41  mov rax, 0x631C1759F530
0000790c663dff4b  call rax
0000790c663dff4d  movaps xmm10, [rsp]
0000790c663dff52  add rsp, 0x30
0000790c663dff56  vmovaps xmm0, [rsp]
0000790c663dff5b  vmovaps xmm1, [rsp+0x10]
0000790c663dff61  vmovaps xmm2, [rsp+0x20]
0000790c663dff67  vmovaps xmm3, [rsp+0x30]
0000790c663dff6d  vmovaps xmm4, [rsp+0x40]
0000790c663dff73  vmovaps xmm5, [rsp+0x50]
0000790c663dff79  vmovaps xmm6, [rsp+0x60]
0000790c663dff7f  vmovaps xmm7, [rsp+0x70]
0000790c663dff85  vmovaps xmm8, [rsp+0x80]
0000790c663dff8e  vmovaps xmm9, [rsp+0x90]
0000790c663dff97  vmovaps xmm11, [rsp+0xA0]
0000790c663dffa0  vmovaps xmm12, [rsp+0xB0]
0000790c663dffa9  vmovaps xmm13, [rsp+0xC0]
0000790c663dffb2  vmovaps xmm14, [rsp+0xD0]
0000790c663dffbb  vmovaps xmm15, [rsp+0xE0]
0000790c663dffc4  add rsp, 0xF0
0000790c663dffcb  pop r11
0000790c663dffcd  pop r10
0000790c663dffcf  pop r9
0000790c663dffd1  pop r8
0000790c663dffd3  pop rsi
0000790c663dffd4  pop rdi
0000790c663dffd5  pop rdx
0000790c663dffd6  pop rcx
0000790c663dffd7  pop rax
0000790c663dffd8  add rsp, 0x08
0000790c663dffdc  jmp 0x0000790C663DC53B
0000790c663dffe1  sub rsp, 0x08
0000790c663dffe5  push rax
0000790c663dffe6  push rcx
0000790c663dffe7  push rdx
0000790c663dffe8  push rdi
0000790c663dffe9  push rsi
0000790c663dffea  push r8
0000790c663dffec  push r9
0000790c663dffee  push r10
0000790c663dfff0  push r11
0000790c663dfff2  sub rsp, 0xF0
0000790c663dfff9  vmovaps [rsp], xmm0
0000790c663dfffe  vmovaps [rsp+0x10], xmm1
0000790c663e0004  vmovaps [rsp+0x20], xmm2
0000790c663e000a  vmovaps [rsp+0x30], xmm3
0000790c663e0010  vmovaps [rsp+0x40], xmm4
0000790c663e0016  vmovaps [rsp+0x50], xmm5
0000790c663e001c  vmovaps [rsp+0x60], xmm6
0000790c663e0022  vmovaps [rsp+0x70], xmm7
0000790c663e0028  vmovaps [rsp+0x80], xmm9
0000790c663e0031  vmovaps [rsp+0x90], xmm10
0000790c663e003a  vmovaps [rsp+0xA0], xmm11
0000790c663e0043  vmovaps [rsp+0xB0], xmm12
0000790c663e004c  vmovaps [rsp+0xC0], xmm13
0000790c663e0055  vmovaps [rsp+0xD0], xmm14
0000790c663e005e  vmovaps [rsp+0xE0], xmm15
0000790c663e0067  sub rsp, 0x30
0000790c663e006b  movaps [rsp], xmm8
0000790c663e0070  movaps [rsp+0x10], xmm1
0000790c663e0075  movaps [rsp+0x20], xmm14
0000790c663e007b  lea rdi, [rsp]
0000790c663e007f  mov esi, 0x00
0000790c663e0084  mov rax, 0x631C1759F530
0000790c663e008e  call rax
0000790c663e0090  movaps xmm8, [rsp]
0000790c663e0095  add rsp, 0x30
0000790c663e0099  vmovaps xmm0, [rsp]
0000790c663e009e  vmovaps xmm1, [rsp+0x10]
0000790c663e00a4  vmovaps xmm2, [rsp+0x20]
0000790c663e00aa  vmovaps xmm3, [rsp+0x30]
0000790c663e00b0  vmovaps xmm4, [rsp+0x40]
0000790c663e00b6  vmovaps xmm5, [rsp+0x50]
0000790c663e00bc  vmovaps xmm6, [rsp+0x60]
0000790c663e00c2  vmovaps xmm7, [rsp+0x70]
0000790c663e00c8  vmovaps xmm9, [rsp+0x80]
0000790c663e00d1  vmovaps xmm10, [rsp+0x90]
0000790c663e00da  vmovaps xmm11, [rsp+0xA0]
0000790c663e00e3  vmovaps xmm12, [rsp+0xB0]
0000790c663e00ec  vmovaps xmm13, [rsp+0xC0]
0000790c663e00f5  vmovaps xmm14, [rsp+0xD0]
0000790c663e00fe  vmovaps xmm15, [rsp+0xE0]
0000790c663e0107  add rsp, 0xF0
0000790c663e010e  pop r11
0000790c663e0110  pop r10
0000790c663e0112  pop r9
0000790c663e0114  pop r8
0000790c663e0116  pop rsi
0000790c663e0117  pop rdi
0000790c663e0118  pop rdx
0000790c663e0119  pop rcx
0000790c663e011a  pop rax
0000790c663e011b  add rsp, 0x08
0000790c663e011f  jmp 0x0000790C663DC561
0000790c663e0124  sub rsp, 0x08
0000790c663e0128  push rax
0000790c663e0129  push rcx
0000790c663e012a  push rdx
0000790c663e012b  push rdi
0000790c663e012c  push rsi
0000790c663e012d  push r8
0000790c663e012f  push r9
0000790c663e0131  push r10
0000790c663e0133  push r11
0000790c663e0135  sub rsp, 0xF0
0000790c663e013c  vmovaps [rsp], xmm0
0000790c663e0141  vmovaps [rsp+0x10], xmm1
0000790c663e0147  vmovaps [rsp+0x20], xmm2
0000790c663e014d  vmovaps [rsp+0x30], xmm3
0000790c663e0153  vmovaps [rsp+0x40], xmm4
0000790c663e0159  vmovaps [rsp+0x50], xmm5
0000790c663e015f  vmovaps [rsp+0x60], xmm7
0000790c663e0165  vmovaps [rsp+0x70], xmm8
0000790c663e016b  vmovaps [rsp+0x80], xmm9
0000790c663e0174  vmovaps [rsp+0x90], xmm10
0000790c663e017d  vmovaps [rsp+0xA0], xmm11
0000790c663e0186  vmovaps [rsp+0xB0], xmm12
0000790c663e018f  vmovaps [rsp+0xC0], xmm13
0000790c663e0198  vmovaps [rsp+0xD0], xmm14
0000790c663e01a1  vmovaps [rsp+0xE0], xmm15
0000790c663e01aa  sub rsp, 0x30
0000790c663e01ae  movaps [rsp], xmm6
0000790c663e01b2  movaps [rsp+0x10], xmm1
0000790c663e01b7  movaps [rsp+0x20], xmm14
0000790c663e01bd  lea rdi, [rsp]
0000790c663e01c1  mov esi, 0x00
0000790c663e01c6  mov rax, 0x631C1759F530
0000790c663e01d0  call rax
0000790c663e01d2  movaps xmm6, [rsp]
0000790c663e01d6  add rsp, 0x30
0000790c663e01da  vmovaps xmm0, [rsp]
0000790c663e01df  vmovaps xmm1, [rsp+0x10]
0000790c663e01e5  vmovaps xmm2, [rsp+0x20]
0000790c663e01eb  vmovaps xmm3, [rsp+0x30]
0000790c663e01f1  vmovaps xmm4, [rsp+0x40]
0000790c663e01f7  vmovaps xmm5, [rsp+0x50]
0000790c663e01fd  vmovaps xmm7, [rsp+0x60]
0000790c663e0203  vmovaps xmm8, [rsp+0x70]
0000790c663e0209  vmovaps xmm9, [rsp+0x80]
0000790c663e0212  vmovaps xmm10, [rsp+0x90]
0000790c663e021b  vmovaps xmm11, [rsp+0xA0]
0000790c663e0224  vmovaps xmm12, [rsp+0xB0]
0000790c663e022d  vmovaps xmm13, [rsp+0xC0]
0000790c663e0236  vmovaps xmm14, [rsp+0xD0]
0000790c663e023f  vmovaps xmm15, [rsp+0xE0]
0000790c663e0248  add rsp, 0xF0
0000790c663e024f  pop r11
0000790c663e0251  pop r10
0000790c663e0253  pop r9
0000790c663e0255  pop r8
0000790c663e0257  pop rsi
0000790c663e0258  pop rdi
0000790c663e0259  pop rdx
0000790c663e025a  pop rcx
0000790c663e025b  pop rax
0000790c663e025c  add rsp, 0x08
0000790c663e0260  jmp 0x0000790C663DC58D
0000790c663e0265  sub rsp, 0x08
0000790c663e0269  push rax
0000790c663e026a  push rcx
0000790c663e026b  push rdx
0000790c663e026c  push rdi
0000790c663e026d  push rsi
0000790c663e026e  push r8
0000790c663e0270  push r9
0000790c663e0272  push r10
0000790c663e0274  push r11
0000790c663e0276  sub rsp, 0xF0
0000790c663e027d  vmovaps [rsp], xmm0
0000790c663e0282  vmovaps [rsp+0x10], xmm1
0000790c663e0288  vmovaps [rsp+0x20], xmm2
0000790c663e028e  vmovaps [rsp+0x30], xmm3
0000790c663e0294  vmovaps [rsp+0x40], xmm4
0000790c663e029a  vmovaps [rsp+0x50], xmm5
0000790c663e02a0  vmovaps [rsp+0x60], xmm6
0000790c663e02a6  vmovaps [rsp+0x70], xmm7
0000790c663e02ac  vmovaps [rsp+0x80], xmm8
0000790c663e02b5  vmovaps [rsp+0x90], xmm9
0000790c663e02be  vmovaps [rsp+0xA0], xmm10
0000790c663e02c7  vmovaps [rsp+0xB0], xmm11
0000790c663e02d0  vmovaps [rsp+0xC0], xmm12
0000790c663e02d9  vmovaps [rsp+0xD0], xmm13
0000790c663e02e2  vmovaps [rsp+0xE0], xmm15
0000790c663e02eb  sub rsp, 0x30
0000790c663e02ef  movaps [rsp], xmm14
0000790c663e02f4  movaps [rsp+0x10], xmm12
0000790c663e02fa  movaps [rsp+0x20], xmm1
0000790c663e02ff  lea rdi, [rsp]
0000790c663e0303  mov esi, 0x00
0000790c663e0308  mov rax, 0x631C1759F530
0000790c663e0312  call rax
0000790c663e0314  movaps xmm14, [rsp]
0000790c663e0319  add rsp, 0x30
0000790c663e031d  vmovaps xmm0, [rsp]
0000790c663e0322  vmovaps xmm1, [rsp+0x10]
0000790c663e0328  vmovaps xmm2, [rsp+0x20]
0000790c663e032e  vmovaps xmm3, [rsp+0x30]
0000790c663e0334  vmovaps xmm4, [rsp+0x40]
0000790c663e033a  vmovaps xmm5, [rsp+0x50]
0000790c663e0340  vmovaps xmm6, [rsp+0x60]
0000790c663e0346  vmovaps xmm7, [rsp+0x70]
0000790c663e034c  vmovaps xmm8, [rsp+0x80]
0000790c663e0355  vmovaps xmm9, [rsp+0x90]
0000790c663e035e  vmovaps xmm10, [rsp+0xA0]
0000790c663e0367  vmovaps xmm11, [rsp+0xB0]
0000790c663e0370  vmovaps xmm12, [rsp+0xC0]
0000790c663e0379  vmovaps xmm13, [rsp+0xD0]
0000790c663e0382  vmovaps xmm15, [rsp+0xE0]
0000790c663e038b  add rsp, 0xF0
0000790c663e0392  pop r11
0000790c663e0394  pop r10
0000790c663e0396  pop r9
0000790c663e0398  pop r8
0000790c663e039a  pop rsi
0000790c663e039b  pop rdi
0000790c663e039c  pop rdx
0000790c663e039d  pop rcx
0000790c663e039e  pop rax
0000790c663e039f  add rsp, 0x08
0000790c663e03a3  jmp 0x0000790C663DC5B3
0000790c663e03a8  sub rsp, 0x08
0000790c663e03ac  push rax
0000790c663e03ad  push rcx
0000790c663e03ae  push rdx
0000790c663e03af  push rdi
0000790c663e03b0  push rsi
0000790c663e03b1  push r8
0000790c663e03b3  push r9
0000790c663e03b5  push r10
0000790c663e03b7  push r11
0000790c663e03b9  sub rsp, 0xF0
0000790c663e03c0  vmovaps [rsp], xmm0
0000790c663e03c5  vmovaps [rsp+0x10], xmm2
0000790c663e03cb  vmovaps [rsp+0x20], xmm3
0000790c663e03d1  vmovaps [rsp+0x30], xmm4
0000790c663e03d7  vmovaps [rsp+0x40], xmm5
0000790c663e03dd  vmovaps [rsp+0x50], xmm6
0000790c663e03e3  vmovaps [rsp+0x60], xmm7
0000790c663e03e9  vmovaps [rsp+0x70], xmm8
0000790c663e03ef  vmovaps [rsp+0x80], xmm9
0000790c663e03f8  vmovaps [rsp+0x90], xmm10
0000790c663e0401  vmovaps [rsp+0xA0], xmm11
0000790c663e040a  vmovaps [rsp+0xB0], xmm12
0000790c663e0413  vmovaps [rsp+0xC0], xmm13
0000790c663e041c  vmovaps [rsp+0xD0], xmm14
0000790c663e0425  vmovaps [rsp+0xE0], xmm15
0000790c663e042e  sub rsp, 0x30
0000790c663e0432  movaps [rsp], xmm1
0000790c663e0436  movaps [rsp+0x10], xmm13
0000790c663e043c  movaps [rsp+0x20], xmm9
0000790c663e0442  lea rdi, [rsp]
0000790c663e0446  mov esi, 0x00
0000790c663e044b  mov rax, 0x631C1759F530
0000790c663e0455  call rax
0000790c663e0457  movaps xmm1, [rsp]
0000790c663e045b  add rsp, 0x30
0000790c663e045f  vmovaps xmm0, [rsp]
0000790c663e0464  vmovaps xmm2, [rsp+0x10]
0000790c663e046a  vmovaps xmm3, [rsp+0x20]
0000790c663e0470  vmovaps xmm4, [rsp+0x30]
0000790c663e0476  vmovaps xmm5, [rsp+0x40]
0000790c663e047c  vmovaps xmm6, [rsp+0x50]
0000790c663e0482  vmovaps xmm7, [rsp+0x60]
0000790c663e0488  vmovaps xmm8, [rsp+0x70]
0000790c663e048e  vmovaps xmm9, [rsp+0x80]
0000790c663e0497  vmovaps xmm10, [rsp+0x90]
0000790c663e04a0  vmovaps xmm11, [rsp+0xA0]
0000790c663e04a9  vmovaps xmm12, [rsp+0xB0]
0000790c663e04b2  vmovaps xmm13, [rsp+0xC0]
0000790c663e04bb  vmovaps xmm14, [rsp+0xD0]
0000790c663e04c4  vmovaps xmm15, [rsp+0xE0]
0000790c663e04cd  add rsp, 0xF0
0000790c663e04d4  pop r11
0000790c663e04d6  pop r10
0000790c663e04d8  pop r9
0000790c663e04da  pop r8
0000790c663e04dc  pop rsi
0000790c663e04dd  pop rdi
0000790c663e04de  pop rdx
0000790c663e04df  pop rcx
0000790c663e04e0  pop rax
0000790c663e04e1  add rsp, 0x08
0000790c663e04e5  jmp 0x0000790C663DC5CD
0000790c663e04ea  sub rsp, 0x08
0000790c663e04ee  push rax
0000790c663e04ef  push rcx
0000790c663e04f0  push rdx
0000790c663e04f1  push rdi
0000790c663e04f2  push rsi
0000790c663e04f3  push r8
0000790c663e04f5  push r9
0000790c663e04f7  push r10
0000790c663e04f9  push r11
0000790c663e04fb  sub rsp, 0xF0
0000790c663e0502  vmovaps [rsp], xmm0
0000790c663e0507  vmovaps [rsp+0x10], xmm1
0000790c663e050d  vmovaps [rsp+0x20], xmm2
0000790c663e0513  vmovaps [rsp+0x30], xmm3
0000790c663e0519  vmovaps [rsp+0x40], xmm4
0000790c663e051f  vmovaps [rsp+0x50], xmm5
0000790c663e0525  vmovaps [rsp+0x60], xmm6
0000790c663e052b  vmovaps [rsp+0x70], xmm7
0000790c663e0531  vmovaps [rsp+0x80], xmm8
0000790c663e053a  vmovaps [rsp+0x90], xmm9
0000790c663e0543  vmovaps [rsp+0xA0], xmm10
0000790c663e054c  vmovaps [rsp+0xB0], xmm11
0000790c663e0555  vmovaps [rsp+0xC0], xmm13
0000790c663e055e  vmovaps [rsp+0xD0], xmm14
0000790c663e0567  vmovaps [rsp+0xE0], xmm15
0000790c663e0570  sub rsp, 0x30
0000790c663e0574  movaps [rsp], xmm12
0000790c663e0579  movaps [rsp+0x10], xmm7
0000790c663e057e  movaps [rsp+0x20], xmm13
0000790c663e0584  lea rdi, [rsp]
0000790c663e0588  mov esi, 0x00
0000790c663e058d  mov rax, 0x631C1759F530
0000790c663e0597  call rax
0000790c663e0599  movaps xmm12, [rsp]
0000790c663e059e  add rsp, 0x30
0000790c663e05a2  vmovaps xmm0, [rsp]
0000790c663e05a7  vmovaps xmm1, [rsp+0x10]
0000790c663e05ad  vmovaps xmm2, [rsp+0x20]
0000790c663e05b3  vmovaps xmm3, [rsp+0x30]
0000790c663e05b9  vmovaps xmm4, [rsp+0x40]
0000790c663e05bf  vmovaps xmm5, [rsp+0x50]
0000790c663e05c5  vmovaps xmm6, [rsp+0x60]
0000790c663e05cb  vmovaps xmm7, [rsp+0x70]
0000790c663e05d1  vmovaps xmm8, [rsp+0x80]
0000790c663e05da  vmovaps xmm9, [rsp+0x90]
0000790c663e05e3  vmovaps xmm10, [rsp+0xA0]
0000790c663e05ec  vmovaps xmm11, [rsp+0xB0]
0000790c663e05f5  vmovaps xmm13, [rsp+0xC0]
0000790c663e05fe  vmovaps xmm14, [rsp+0xD0]
0000790c663e0607  vmovaps xmm15, [rsp+0xE0]
0000790c663e0610  add rsp, 0xF0
0000790c663e0617  pop r11
0000790c663e0619  pop r10
0000790c663e061b  pop r9
0000790c663e061d  pop r8
0000790c663e061f  pop rsi
0000790c663e0620  pop rdi
0000790c663e0621  pop rdx
0000790c663e0622  pop rcx
0000790c663e0623  pop rax
0000790c663e0624  add rsp, 0x08
0000790c663e0628  jmp 0x0000790C663DC5F4
0000790c663e062d  sub rsp, 0x08
0000790c663e0631  push rax
0000790c663e0632  push rcx
0000790c663e0633  push rdx
0000790c663e0634  push rdi
0000790c663e0635  push rsi
0000790c663e0636  push r8
0000790c663e0638  push r9
0000790c663e063a  push r10
0000790c663e063c  push r11
0000790c663e063e  sub rsp, 0xF0
0000790c663e0645  vmovaps [rsp], xmm0
0000790c663e064a  vmovaps [rsp+0x10], xmm1
0000790c663e0650  vmovaps [rsp+0x20], xmm2
0000790c663e0656  vmovaps [rsp+0x30], xmm3
0000790c663e065c  vmovaps [rsp+0x40], xmm4
0000790c663e0662  vmovaps [rsp+0x50], xmm5
0000790c663e0668  vmovaps [rsp+0x60], xmm6
0000790c663e066e  vmovaps [rsp+0x70], xmm7
0000790c663e0674  vmovaps [rsp+0x80], xmm8
0000790c663e067d  vmovaps [rsp+0x90], xmm9
0000790c663e0686  vmovaps [rsp+0xA0], xmm10
0000790c663e068f  vmovaps [rsp+0xB0], xmm11
0000790c663e0698  vmovaps [rsp+0xC0], xmm12
0000790c663e06a1  vmovaps [rsp+0xD0], xmm14
0000790c663e06aa  vmovaps [rsp+0xE0], xmm15
0000790c663e06b3  sub rsp, 0x30
0000790c663e06b7  movaps [rsp], xmm13
0000790c663e06bc  movaps [rsp+0x10], xmm15
0000790c663e06c2  movaps [rsp+0x20], xmm8
0000790c663e06c8  lea rdi, [rsp]
0000790c663e06cc  mov esi, 0x00
0000790c663e06d1  mov rax, 0x631C1759F530
0000790c663e06db  call rax
0000790c663e06dd  movaps xmm13, [rsp]
0000790c663e06e2  add rsp, 0x30
0000790c663e06e6  vmovaps xmm0, [rsp]
0000790c663e06eb  vmovaps xmm1, [rsp+0x10]
0000790c663e06f1  vmovaps xmm2, [rsp+0x20]
0000790c663e06f7  vmovaps xmm3, [rsp+0x30]
0000790c663e06fd  vmovaps xmm4, [rsp+0x40]
0000790c663e0703  vmovaps xmm5, [rsp+0x50]
0000790c663e0709  vmovaps xmm6, [rsp+0x60]
0000790c663e070f  vmovaps xmm7, [rsp+0x70]
0000790c663e0715  vmovaps xmm8, [rsp+0x80]
0000790c663e071e  vmovaps xmm9, [rsp+0x90]
0000790c663e0727  vmovaps xmm10, [rsp+0xA0]
0000790c663e0730  vmovaps xmm11, [rsp+0xB0]
0000790c663e0739  vmovaps xmm12, [rsp+0xC0]
0000790c663e0742  vmovaps xmm14, [rsp+0xD0]
0000790c663e074b  vmovaps xmm15, [rsp+0xE0]
0000790c663e0754  add rsp, 0xF0
0000790c663e075b  pop r11
0000790c663e075d  pop r10
0000790c663e075f  pop r9
0000790c663e0761  pop r8
0000790c663e0763  pop rsi
0000790c663e0764  pop rdi
0000790c663e0765  pop rdx
0000790c663e0766  pop rcx
0000790c663e0767  pop rax
0000790c663e0768  add rsp, 0x08
0000790c663e076c  jmp 0x0000790C663DC60F
0000790c663e0771  sub rsp, 0x08
0000790c663e0775  push rax
0000790c663e0776  push rcx
0000790c663e0777  push rdx
0000790c663e0778  push rdi
0000790c663e0779  push rsi
0000790c663e077a  push r8
0000790c663e077c  push r9
0000790c663e077e  push r10
0000790c663e0780  push r11
0000790c663e0782  sub rsp, 0xF0
0000790c663e0789  vmovaps [rsp], xmm0
0000790c663e078e  vmovaps [rsp+0x10], xmm1
0000790c663e0794  vmovaps [rsp+0x20], xmm2
0000790c663e079a  vmovaps [rsp+0x30], xmm3
0000790c663e07a0  vmovaps [rsp+0x40], xmm4
0000790c663e07a6  vmovaps [rsp+0x50], xmm5
0000790c663e07ac  vmovaps [rsp+0x60], xmm6
0000790c663e07b2  vmovaps [rsp+0x70], xmm7
0000790c663e07b8  vmovaps [rsp+0x80], xmm9
0000790c663e07c1  vmovaps [rsp+0x90], xmm10
0000790c663e07ca  vmovaps [rsp+0xA0], xmm11
0000790c663e07d3  vmovaps [rsp+0xB0], xmm12
0000790c663e07dc  vmovaps [rsp+0xC0], xmm13
0000790c663e07e5  vmovaps [rsp+0xD0], xmm14
0000790c663e07ee  vmovaps [rsp+0xE0], xmm15
0000790c663e07f7  sub rsp, 0x30
0000790c663e07fb  movaps [rsp], xmm8
0000790c663e0800  movaps [rsp+0x10], xmm15
0000790c663e0806  movaps [rsp+0x20], xmm9
0000790c663e080c  lea rdi, [rsp]
0000790c663e0810  mov esi, 0x00
0000790c663e0815  mov rax, 0x631C1759F530
0000790c663e081f  call rax
0000790c663e0821  movaps xmm8, [rsp]
0000790c663e0826  add rsp, 0x30
0000790c663e082a  vmovaps xmm0, [rsp]
0000790c663e082f  vmovaps xmm1, [rsp+0x10]
0000790c663e0835  vmovaps xmm2, [rsp+0x20]
0000790c663e083b  vmovaps xmm3, [rsp+0x30]
0000790c663e0841  vmovaps xmm4, [rsp+0x40]
0000790c663e0847  vmovaps xmm5, [rsp+0x50]
0000790c663e084d  vmovaps xmm6, [rsp+0x60]
0000790c663e0853  vmovaps xmm7, [rsp+0x70]
0000790c663e0859  vmovaps xmm9, [rsp+0x80]
0000790c663e0862  vmovaps xmm10, [rsp+0x90]
0000790c663e086b  vmovaps xmm11, [rsp+0xA0]
0000790c663e0874  vmovaps xmm12, [rsp+0xB0]
0000790c663e087d  vmovaps xmm13, [rsp+0xC0]
0000790c663e0886  vmovaps xmm14, [rsp+0xD0]
0000790c663e088f  vmovaps xmm15, [rsp+0xE0]
0000790c663e0898  add rsp, 0xF0
0000790c663e089f  pop r11
0000790c663e08a1  pop r10
0000790c663e08a3  pop r9
0000790c663e08a5  pop r8
0000790c663e08a7  pop rsi
0000790c663e08a8  pop rdi
0000790c663e08a9  pop rdx
0000790c663e08aa  pop rcx
0000790c663e08ab  pop rax
0000790c663e08ac  add rsp, 0x08
0000790c663e08b0  jmp 0x0000790C663DC63D
0000790c663e08b5  sub rsp, 0x08
0000790c663e08b9  push rax
0000790c663e08ba  push rcx
0000790c663e08bb  push rdx
0000790c663e08bc  push rdi
0000790c663e08bd  push rsi
0000790c663e08be  push r8
0000790c663e08c0  push r9
0000790c663e08c2  push r10
0000790c663e08c4  push r11
0000790c663e08c6  sub rsp, 0xF0
0000790c663e08cd  vmovaps [rsp], xmm0
0000790c663e08d2  vmovaps [rsp+0x10], xmm1
0000790c663e08d8  vmovaps [rsp+0x20], xmm2
0000790c663e08de  vmovaps [rsp+0x30], xmm3
0000790c663e08e4  vmovaps [rsp+0x40], xmm4
0000790c663e08ea  vmovaps [rsp+0x50], xmm5
0000790c663e08f0  vmovaps [rsp+0x60], xmm6
0000790c663e08f6  vmovaps [rsp+0x70], xmm7
0000790c663e08fc  vmovaps [rsp+0x80], xmm8
0000790c663e0905  vmovaps [rsp+0x90], xmm9
0000790c663e090e  vmovaps [rsp+0xA0], xmm10
0000790c663e0917  vmovaps [rsp+0xB0], xmm11
0000790c663e0920  vmovaps [rsp+0xC0], xmm12
0000790c663e0929  vmovaps [rsp+0xD0], xmm13
0000790c663e0932  vmovaps [rsp+0xE0], xmm14
0000790c663e093b  sub rsp, 0x30
0000790c663e093f  movaps [rsp], xmm15
0000790c663e0944  movaps [rsp+0x10], xmm11
0000790c663e094a  movaps [rsp+0x20], xmm6
0000790c663e094f  lea rdi, [rsp]
0000790c663e0953  mov esi, 0x00
0000790c663e0958  mov rax, 0x631C1759F530
0000790c663e0962  call rax
0000790c663e0964  movaps xmm15, [rsp]
0000790c663e0969  add rsp, 0x30
0000790c663e096d  vmovaps xmm0, [rsp]
0000790c663e0972  vmovaps xmm1, [rsp+0x10]
0000790c663e0978  vmovaps xmm2, [rsp+0x20]
0000790c663e097e  vmovaps xmm3, [rsp+0x30]
0000790c663e0984  vmovaps xmm4, [rsp+0x40]
0000790c663e098a  vmovaps xmm5, [rsp+0x50]
0000790c663e0990  vmovaps xmm6, [rsp+0x60]
0000790c663e0996  vmovaps xmm7, [rsp+0x70]
0000790c663e099c  vmovaps xmm8, [rsp+0x80]
0000790c663e09a5  vmovaps xmm9, [rsp+0x90]
0000790c663e09ae  vmovaps xmm10, [rsp+0xA0]
0000790c663e09b7  vmovaps xmm11, [rsp+0xB0]
0000790c663e09c0  vmovaps xmm12, [rsp+0xC0]
0000790c663e09c9  vmovaps xmm13, [rsp+0xD0]
0000790c663e09d2  vmovaps xmm14, [rsp+0xE0]
0000790c663e09db  add rsp, 0xF0
0000790c663e09e2  pop r11
0000790c663e09e4  pop r10
0000790c663e09e6  pop r9
0000790c663e09e8  pop r8
0000790c663e09ea  pop rsi
0000790c663e09eb  pop rdi
0000790c663e09ec  pop rdx
0000790c663e09ed  pop rcx
0000790c663e09ee  pop rax
0000790c663e09ef  add rsp, 0x08
0000790c663e09f3  jmp 0x0000790C663DC658
0000790c663e09f8  sub rsp, 0x08
0000790c663e09fc  push rax
0000790c663e09fd  push rcx
0000790c663e09fe  push rdx
0000790c663e09ff  push rdi
0000790c663e0a00  push rsi
0000790c663e0a01  push r8
0000790c663e0a03  push r9
0000790c663e0a05  push r10
0000790c663e0a07  push r11
0000790c663e0a09  sub rsp, 0xF0
0000790c663e0a10  vmovaps [rsp], xmm0
0000790c663e0a15  vmovaps [rsp+0x10], xmm1
0000790c663e0a1b  vmovaps [rsp+0x20], xmm2
0000790c663e0a21  vmovaps [rsp+0x30], xmm3
0000790c663e0a27  vmovaps [rsp+0x40], xmm4
0000790c663e0a2d  vmovaps [rsp+0x50], xmm5
0000790c663e0a33  vmovaps [rsp+0x60], xmm6
0000790c663e0a39  vmovaps [rsp+0x70], xmm8
0000790c663e0a3f  vmovaps [rsp+0x80], xmm9
0000790c663e0a48  vmovaps [rsp+0x90], xmm10
0000790c663e0a51  vmovaps [rsp+0xA0], xmm11
0000790c663e0a5a  vmovaps [rsp+0xB0], xmm12
0000790c663e0a63  vmovaps [rsp+0xC0], xmm13
0000790c663e0a6c  vmovaps [rsp+0xD0], xmm14
0000790c663e0a75  vmovaps [rsp+0xE0], xmm15
0000790c663e0a7e  sub rsp, 0x30
0000790c663e0a82  movaps [rsp], xmm7
0000790c663e0a86  movaps [rsp+0x10], xmm11
0000790c663e0a8c  movaps [rsp+0x20], xmm9
0000790c663e0a92  lea rdi, [rsp]
0000790c663e0a96  mov esi, 0x00
0000790c663e0a9b  mov rax, 0x631C1759F530
0000790c663e0aa5  call rax
0000790c663e0aa7  movaps xmm7, [rsp]
0000790c663e0aab  add rsp, 0x30
0000790c663e0aaf  vmovaps xmm0, [rsp]
0000790c663e0ab4  vmovaps xmm1, [rsp+0x10]
0000790c663e0aba  vmovaps xmm2, [rsp+0x20]
0000790c663e0ac0  vmovaps xmm3, [rsp+0x30]
0000790c663e0ac6  vmovaps xmm4, [rsp+0x40]
0000790c663e0acc  vmovaps xmm5, [rsp+0x50]
0000790c663e0ad2  vmovaps xmm6, [rsp+0x60]
0000790c663e0ad8  vmovaps xmm8, [rsp+0x70]
0000790c663e0ade  vmovaps xmm9, [rsp+0x80]
0000790c663e0ae7  vmovaps xmm10, [rsp+0x90]
0000790c663e0af0  vmovaps xmm11, [rsp+0xA0]
0000790c663e0af9  vmovaps xmm12, [rsp+0xB0]
0000790c663e0b02  vmovaps xmm13, [rsp+0xC0]
0000790c663e0b0b  vmovaps xmm14, [rsp+0xD0]
0000790c663e0b14  vmovaps xmm15, [rsp+0xE0]
0000790c663e0b1d  add rsp, 0xF0
0000790c663e0b24  pop r11
0000790c663e0b26  pop r10
0000790c663e0b28  pop r9
0000790c663e0b2a  pop r8
0000790c663e0b2c  pop rsi
0000790c663e0b2d  pop rdi
0000790c663e0b2e  pop rdx
0000790c663e0b2f  pop rcx
0000790c663e0b30  pop rax
0000790c663e0b31  add rsp, 0x08
0000790c663e0b35  jmp 0x0000790C663DC685
0000790c663e0b3a  sub rsp, 0x08
0000790c663e0b3e  push rax
0000790c663e0b3f  push rcx
0000790c663e0b40  push rdx
0000790c663e0b41  push rdi
0000790c663e0b42  push rsi
0000790c663e0b43  push r8
0000790c663e0b45  push r9
0000790c663e0b47  push r10
0000790c663e0b49  push r11
0000790c663e0b4b  sub rsp, 0xF0
0000790c663e0b52  vmovaps [rsp], xmm0
0000790c663e0b57  vmovaps [rsp+0x10], xmm1
0000790c663e0b5d  vmovaps [rsp+0x20], xmm2
0000790c663e0b63  vmovaps [rsp+0x30], xmm3
0000790c663e0b69  vmovaps [rsp+0x40], xmm4
0000790c663e0b6f  vmovaps [rsp+0x50], xmm5
0000790c663e0b75  vmovaps [rsp+0x60], xmm6
0000790c663e0b7b  vmovaps [rsp+0x70], xmm7
0000790c663e0b81  vmovaps [rsp+0x80], xmm8
0000790c663e0b8a  vmovaps [rsp+0x90], xmm9
0000790c663e0b93  vmovaps [rsp+0xA0], xmm10
0000790c663e0b9c  vmovaps [rsp+0xB0], xmm12
0000790c663e0ba5  vmovaps [rsp+0xC0], xmm13
0000790c663e0bae  vmovaps [rsp+0xD0], xmm14
0000790c663e0bb7  vmovaps [rsp+0xE0], xmm15
0000790c663e0bc0  sub rsp, 0x30
0000790c663e0bc4  movaps [rsp], xmm11
0000790c663e0bc9  movaps [rsp+0x10], xmm10
0000790c663e0bcf  movaps [rsp+0x20], xmm14
0000790c663e0bd5  lea rdi, [rsp]
0000790c663e0bd9  mov esi, 0x00
0000790c663e0bde  mov rax, 0x631C1759F530
0000790c663e0be8  call rax
0000790c663e0bea  movaps xmm11, [rsp]
0000790c663e0bef  add rsp, 0x30
0000790c663e0bf3  vmovaps xmm0, [rsp]
0000790c663e0bf8  vmovaps xmm1, [rsp+0x10]
0000790c663e0bfe  vmovaps xmm2, [rsp+0x20]
0000790c663e0c04  vmovaps xmm3, [rsp+0x30]
0000790c663e0c0a  vmovaps xmm4, [rsp+0x40]
0000790c663e0c10  vmovaps xmm5, [rsp+0x50]
0000790c663e0c16  vmovaps xmm6, [rsp+0x60]
0000790c663e0c1c  vmovaps xmm7, [rsp+0x70]
0000790c663e0c22  vmovaps xmm8, [rsp+0x80]
0000790c663e0c2b  vmovaps xmm9, [rsp+0x90]
0000790c663e0c34  vmovaps xmm10, [rsp+0xA0]
0000790c663e0c3d  vmovaps xmm12, [rsp+0xB0]
0000790c663e0c46  vmovaps xmm13, [rsp+0xC0]
0000790c663e0c4f  vmovaps xmm14, [rsp+0xD0]
0000790c663e0c58  vmovaps xmm15, [rsp+0xE0]
0000790c663e0c61  add rsp, 0xF0
0000790c663e0c68  pop r11
0000790c663e0c6a  pop r10
0000790c663e0c6c  pop r9
0000790c663e0c6e  pop r8
0000790c663e0c70  pop rsi
0000790c663e0c71  pop rdi
0000790c663e0c72  pop rdx
0000790c663e0c73  pop rcx
0000790c663e0c74  pop rax
0000790c663e0c75  add rsp, 0x08
0000790c663e0c79  jmp 0x0000790C663DC6A0
0000790c663e0c7e  call 0x0000790C662C33A0
0000790c663e0c83  jmp 0x0000790C663DC6AA
0000790c663e0c88  sub rsp, 0x08
0000790c663e0c8c  push rax
0000790c663e0c8d  push rcx
0000790c663e0c8e  push rdx
0000790c663e0c8f  push rdi
0000790c663e0c90  push rsi
0000790c663e0c91  push r8
0000790c663e0c93  push r9
0000790c663e0c95  push r10
0000790c663e0c97  push r11
0000790c663e0c99  sub rsp, 0xF0
0000790c663e0ca0  vmovaps [rsp], xmm0
0000790c663e0ca5  vmovaps [rsp+0x10], xmm1
0000790c663e0cab  vmovaps [rsp+0x20], xmm2
0000790c663e0cb1  vmovaps [rsp+0x30], xmm3
0000790c663e0cb7  vmovaps [rsp+0x40], xmm4
0000790c663e0cbd  vmovaps [rsp+0x50], xmm5
0000790c663e0cc3  vmovaps [rsp+0x60], xmm6
0000790c663e0cc9  vmovaps [rsp+0x70], xmm7
0000790c663e0ccf  vmovaps [rsp+0x80], xmm8
0000790c663e0cd8  vmovaps [rsp+0x90], xmm9
0000790c663e0ce1  vmovaps [rsp+0xA0], xmm11
0000790c663e0cea  vmovaps [rsp+0xB0], xmm12
0000790c663e0cf3  vmovaps [rsp+0xC0], xmm13
0000790c663e0cfc  vmovaps [rsp+0xD0], xmm14
0000790c663e0d05  vmovaps [rsp+0xE0], xmm15
0000790c663e0d0e  sub rsp, 0x30
0000790c663e0d12  movaps [rsp], xmm10
0000790c663e0d17  movaps [rsp+0x10], xmm1
0000790c663e0d1c  movaps [rsp+0x20], xmm12
0000790c663e0d22  lea rdi, [rsp]
0000790c663e0d26  mov esi, 0x00
0000790c663e0d2b  mov rax, 0x631C1759F530
0000790c663e0d35  call rax
0000790c663e0d37  movaps xmm10, [rsp]
0000790c663e0d3c  add rsp, 0x30
0000790c663e0d40  vmovaps xmm0, [rsp]
0000790c663e0d45  vmovaps xmm1, [rsp+0x10]
0000790c663e0d4b  vmovaps xmm2, [rsp+0x20]
0000790c663e0d51  vmovaps xmm3, [rsp+0x30]
0000790c663e0d57  vmovaps xmm4, [rsp+0x40]
0000790c663e0d5d  vmovaps xmm5, [rsp+0x50]
0000790c663e0d63  vmovaps xmm6, [rsp+0x60]
0000790c663e0d69  vmovaps xmm7, [rsp+0x70]
0000790c663e0d6f  vmovaps xmm8, [rsp+0x80]
0000790c663e0d78  vmovaps xmm9, [rsp+0x90]
0000790c663e0d81  vmovaps xmm11, [rsp+0xA0]
0000790c663e0d8a  vmovaps xmm12, [rsp+0xB0]
0000790c663e0d93  vmovaps xmm13, [rsp+0xC0]
0000790c663e0d9c  vmovaps xmm14, [rsp+0xD0]
0000790c663e0da5  vmovaps xmm15, [rsp+0xE0]
0000790c663e0dae  add rsp, 0xF0
0000790c663e0db5  pop r11
0000790c663e0db7  pop r10
0000790c663e0db9  pop r9
0000790c663e0dbb  pop r8
0000790c663e0dbd  pop rsi
0000790c663e0dbe  pop rdi
0000790c663e0dbf  pop rdx
0000790c663e0dc0  pop rcx
0000790c663e0dc1  pop rax
0000790c663e0dc2  add rsp, 0x08
0000790c663e0dc6  jmp 0x0000790C663DC6CD
0000790c663e0dcb  sub rsp, 0x08
0000790c663e0dcf  push rax
0000790c663e0dd0  push rcx
0000790c663e0dd1  push rdx
0000790c663e0dd2  push rdi
0000790c663e0dd3  push rsi
0000790c663e0dd4  push r8
0000790c663e0dd6  push r9
0000790c663e0dd8  push r10
0000790c663e0dda  push r11
0000790c663e0ddc  sub rsp, 0xF0
0000790c663e0de3  vmovaps [rsp], xmm0
0000790c663e0de8  vmovaps [rsp+0x10], xmm1
0000790c663e0dee  vmovaps [rsp+0x20], xmm2
0000790c663e0df4  vmovaps [rsp+0x30], xmm3
0000790c663e0dfa  vmovaps [rsp+0x40], xmm4
0000790c663e0e00  vmovaps [rsp+0x50], xmm5
0000790c663e0e06  vmovaps [rsp+0x60], xmm6
0000790c663e0e0c  vmovaps [rsp+0x70], xmm7
0000790c663e0e12  vmovaps [rsp+0x80], xmm8
0000790c663e0e1b  vmovaps [rsp+0x90], xmm9
0000790c663e0e24  vmovaps [rsp+0xA0], xmm10
0000790c663e0e2d  vmovaps [rsp+0xB0], xmm11
0000790c663e0e36  vmovaps [rsp+0xC0], xmm13
0000790c663e0e3f  vmovaps [rsp+0xD0], xmm14
0000790c663e0e48  vmovaps [rsp+0xE0], xmm15
0000790c663e0e51  sub rsp, 0x30
0000790c663e0e55  movaps [rsp], xmm12
0000790c663e0e5a  movaps [rsp+0x10], xmm14
0000790c663e0e60  movaps [rsp+0x20], xmm1
0000790c663e0e65  lea rdi, [rsp]
0000790c663e0e69  mov esi, 0x00
0000790c663e0e6e  mov rax, 0x631C1759F530
0000790c663e0e78  call rax
0000790c663e0e7a  movaps xmm12, [rsp]
0000790c663e0e7f  add rsp, 0x30
0000790c663e0e83  vmovaps xmm0, [rsp]
0000790c663e0e88  vmovaps xmm1, [rsp+0x10]
0000790c663e0e8e  vmovaps xmm2, [rsp+0x20]
0000790c663e0e94  vmovaps xmm3, [rsp+0x30]
0000790c663e0e9a  vmovaps xmm4, [rsp+0x40]
0000790c663e0ea0  vmovaps xmm5, [rsp+0x50]
0000790c663e0ea6  vmovaps xmm6, [rsp+0x60]
0000790c663e0eac  vmovaps xmm7, [rsp+0x70]
0000790c663e0eb2  vmovaps xmm8, [rsp+0x80]
0000790c663e0ebb  vmovaps xmm9, [rsp+0x90]
0000790c663e0ec4  vmovaps xmm10, [rsp+0xA0]
0000790c663e0ecd  vmovaps xmm11, [rsp+0xB0]
0000790c663e0ed6  vmovaps xmm13, [rsp+0xC0]
0000790c663e0edf  vmovaps xmm14, [rsp+0xD0]
0000790c663e0ee8  vmovaps xmm15, [rsp+0xE0]
0000790c663e0ef1  add rsp, 0xF0
0000790c663e0ef8  pop r11
0000790c663e0efa  pop r10
0000790c663e0efc  pop r9
0000790c663e0efe  pop r8
0000790c663e0f00  pop rsi
0000790c663e0f01  pop rdi
0000790c663e0f02  pop rdx
0000790c663e0f03  pop rcx
0000790c663e0f04  pop rax
0000790c663e0f05  add rsp, 0x08
0000790c663e0f09  jmp 0x0000790C663DC6FC
0000790c663e0f0e  sub rsp, 0x08
0000790c663e0f12  push rax
0000790c663e0f13  push rcx
0000790c663e0f14  push rdx
0000790c663e0f15  push rdi
0000790c663e0f16  push rsi
0000790c663e0f17  push r8
0000790c663e0f19  push r9
0000790c663e0f1b  push r10
0000790c663e0f1d  push r11
0000790c663e0f1f  sub rsp, 0xF0
0000790c663e0f26  vmovaps [rsp], xmm0
0000790c663e0f2b  vmovaps [rsp+0x10], xmm1
0000790c663e0f31  vmovaps [rsp+0x20], xmm2
0000790c663e0f37  vmovaps [rsp+0x30], xmm3
0000790c663e0f3d  vmovaps [rsp+0x40], xmm4
0000790c663e0f43  vmovaps [rsp+0x50], xmm5
0000790c663e0f49  vmovaps [rsp+0x60], xmm6
0000790c663e0f4f  vmovaps [rsp+0x70], xmm7
0000790c663e0f55  vmovaps [rsp+0x80], xmm8
0000790c663e0f5e  vmovaps [rsp+0x90], xmm9
0000790c663e0f67  vmovaps [rsp+0xA0], xmm10
0000790c663e0f70  vmovaps [rsp+0xB0], xmm11
0000790c663e0f79  vmovaps [rsp+0xC0], xmm12
0000790c663e0f82  vmovaps [rsp+0xD0], xmm13
0000790c663e0f8b  vmovaps [rsp+0xE0], xmm15
0000790c663e0f94  sub rsp, 0x30
0000790c663e0f98  movaps [rsp], xmm14
0000790c663e0f9d  movaps [rsp+0x10], xmm9
0000790c663e0fa3  movaps [rsp+0x20], xmm1
0000790c663e0fa8  lea rdi, [rsp]
0000790c663e0fac  mov esi, 0x00
0000790c663e0fb1  mov rax, 0x631C1759F530
0000790c663e0fbb  call rax
0000790c663e0fbd  movaps xmm14, [rsp]
0000790c663e0fc2  add rsp, 0x30
0000790c663e0fc6  vmovaps xmm0, [rsp]
0000790c663e0fcb  vmovaps xmm1, [rsp+0x10]
0000790c663e0fd1  vmovaps xmm2, [rsp+0x20]
0000790c663e0fd7  vmovaps xmm3, [rsp+0x30]
0000790c663e0fdd  vmovaps xmm4, [rsp+0x40]
0000790c663e0fe3  vmovaps xmm5, [rsp+0x50]
0000790c663e0fe9  vmovaps xmm6, [rsp+0x60]
0000790c663e0fef  vmovaps xmm7, [rsp+0x70]
0000790c663e0ff5  vmovaps xmm8, [rsp+0x80]
0000790c663e0ffe  vmovaps xmm9, [rsp+0x90]
0000790c663e1007  vmovaps xmm10, [rsp+0xA0]
0000790c663e1010  vmovaps xmm11, [rsp+0xB0]
0000790c663e1019  vmovaps xmm12, [rsp+0xC0]
0000790c663e1022  vmovaps xmm13, [rsp+0xD0]
0000790c663e102b  vmovaps xmm15, [rsp+0xE0]
0000790c663e1034  add rsp, 0xF0
0000790c663e103b  pop r11
0000790c663e103d  pop r10
0000790c663e103f  pop r9
0000790c663e1041  pop r8
0000790c663e1043  pop rsi
0000790c663e1044  pop rdi
0000790c663e1045  pop rdx
0000790c663e1046  pop rcx
0000790c663e1047  pop rax
0000790c663e1048  add rsp, 0x08
0000790c663e104c  jmp 0x0000790C663DC72B
0000790c663e1051  sub rsp, 0x08
0000790c663e1055  push rax
0000790c663e1056  push rcx
0000790c663e1057  push rdx
0000790c663e1058  push rdi
0000790c663e1059  push rsi
0000790c663e105a  push r8
0000790c663e105c  push r9
0000790c663e105e  push r10
0000790c663e1060  push r11
0000790c663e1062  sub rsp, 0xF0
0000790c663e1069  vmovaps [rsp], xmm0
0000790c663e106e  vmovaps [rsp+0x10], xmm2
0000790c663e1074  vmovaps [rsp+0x20], xmm3
0000790c663e107a  vmovaps [rsp+0x30], xmm4
0000790c663e1080  vmovaps [rsp+0x40], xmm5
0000790c663e1086  vmovaps [rsp+0x50], xmm6
0000790c663e108c  vmovaps [rsp+0x60], xmm7
0000790c663e1092  vmovaps [rsp+0x70], xmm8
0000790c663e1098  vmovaps [rsp+0x80], xmm9
0000790c663e10a1  vmovaps [rsp+0x90], xmm10
0000790c663e10aa  vmovaps [rsp+0xA0], xmm11
0000790c663e10b3  vmovaps [rsp+0xB0], xmm12
0000790c663e10bc  vmovaps [rsp+0xC0], xmm13
0000790c663e10c5  vmovaps [rsp+0xD0], xmm14
0000790c663e10ce  vmovaps [rsp+0xE0], xmm15
0000790c663e10d7  sub rsp, 0x30
0000790c663e10db  movaps [rsp], xmm1
0000790c663e10df  movaps [rsp+0x10], xmm13
0000790c663e10e5  movaps [rsp+0x20], xmm8
0000790c663e10eb  lea rdi, [rsp]
0000790c663e10ef  mov esi, 0x00
0000790c663e10f4  mov rax, 0x631C1759F530
0000790c663e10fe  call rax
0000790c663e1100  movaps xmm1, [rsp]
0000790c663e1104  add rsp, 0x30
0000790c663e1108  vmovaps xmm0, [rsp]
0000790c663e110d  vmovaps xmm2, [rsp+0x10]
0000790c663e1113  vmovaps xmm3, [rsp+0x20]
0000790c663e1119  vmovaps xmm4, [rsp+0x30]
0000790c663e111f  vmovaps xmm5, [rsp+0x40]
0000790c663e1125  vmovaps xmm6, [rsp+0x50]
0000790c663e112b  vmovaps xmm7, [rsp+0x60]
0000790c663e1131  vmovaps xmm8, [rsp+0x70]
0000790c663e1137  vmovaps xmm9, [rsp+0x80]
0000790c663e1140  vmovaps xmm10, [rsp+0x90]
0000790c663e1149  vmovaps xmm11, [rsp+0xA0]
0000790c663e1152  vmovaps xmm12, [rsp+0xB0]
0000790c663e115b  vmovaps xmm13, [rsp+0xC0]
0000790c663e1164  vmovaps xmm14, [rsp+0xD0]
0000790c663e116d  vmovaps xmm15, [rsp+0xE0]
0000790c663e1176  add rsp, 0xF0
0000790c663e117d  pop r11
0000790c663e117f  pop r10
0000790c663e1181  pop r9
0000790c663e1183  pop r8
0000790c663e1185  pop rsi
0000790c663e1186  pop rdi
0000790c663e1187  pop rdx
0000790c663e1188  pop rcx
0000790c663e1189  pop rax
0000790c663e118a  add rsp, 0x08
0000790c663e118e  jmp 0x0000790C663DC74D
0000790c663e1193  call 0x0000790C6620C260
0000790c663e1198  jmp 0x0000790C663DC75B
0000790c663e119d  call 0x0000790C662BD750
0000790c663e11a2  jmp 0x0000790C663DC765
0000790c663e11a7  sub rsp, 0x08
0000790c663e11ab  push rax
0000790c663e11ac  push rcx
0000790c663e11ad  push rdx
0000790c663e11ae  push rdi
0000790c663e11af  push rsi
0000790c663e11b0  push r8
0000790c663e11b2  push r9
0000790c663e11b4  push r10
0000790c663e11b6  push r11
0000790c663e11b8  sub rsp, 0xF0
0000790c663e11bf  vmovaps [rsp], xmm0
0000790c663e11c4  vmovaps [rsp+0x10], xmm1
0000790c663e11ca  vmovaps [rsp+0x20], xmm2
0000790c663e11d0  vmovaps [rsp+0x30], xmm3
0000790c663e11d6  vmovaps [rsp+0x40], xmm4
0000790c663e11dc  vmovaps [rsp+0x50], xmm5
0000790c663e11e2  vmovaps [rsp+0x60], xmm6
0000790c663e11e8  vmovaps [rsp+0x70], xmm7
0000790c663e11ee  vmovaps [rsp+0x80], xmm9
0000790c663e11f7  vmovaps [rsp+0x90], xmm10
0000790c663e1200  vmovaps [rsp+0xA0], xmm11
0000790c663e1209  vmovaps [rsp+0xB0], xmm12
0000790c663e1212  vmovaps [rsp+0xC0], xmm13
0000790c663e121b  vmovaps [rsp+0xD0], xmm14
0000790c663e1224  vmovaps [rsp+0xE0], xmm15
0000790c663e122d  sub rsp, 0x30
0000790c663e1231  movaps [rsp], xmm8
0000790c663e1236  movaps [rsp+0x10], xmm15
0000790c663e123c  movaps [rsp+0x20], xmm7
0000790c663e1241  lea rdi, [rsp]
0000790c663e1245  mov esi, 0x00
0000790c663e124a  mov rax, 0x631C1759F530
0000790c663e1254  call rax
0000790c663e1256  movaps xmm8, [rsp]
0000790c663e125b  add rsp, 0x30
0000790c663e125f  vmovaps xmm0, [rsp]
0000790c663e1264  vmovaps xmm1, [rsp+0x10]
0000790c663e126a  vmovaps xmm2, [rsp+0x20]
0000790c663e1270  vmovaps xmm3, [rsp+0x30]
0000790c663e1276  vmovaps xmm4, [rsp+0x40]
0000790c663e127c  vmovaps xmm5, [rsp+0x50]
0000790c663e1282  vmovaps xmm6, [rsp+0x60]
0000790c663e1288  vmovaps xmm7, [rsp+0x70]
0000790c663e128e  vmovaps xmm9, [rsp+0x80]
0000790c663e1297  vmovaps xmm10, [rsp+0x90]
0000790c663e12a0  vmovaps xmm11, [rsp+0xA0]
0000790c663e12a9  vmovaps xmm12, [rsp+0xB0]
0000790c663e12b2  vmovaps xmm13, [rsp+0xC0]
0000790c663e12bb  vmovaps xmm14, [rsp+0xD0]
0000790c663e12c4  vmovaps xmm15, [rsp+0xE0]
0000790c663e12cd  add rsp, 0xF0
0000790c663e12d4  pop r11
0000790c663e12d6  pop r10
0000790c663e12d8  pop r9
0000790c663e12da  pop r8
0000790c663e12dc  pop rsi
0000790c663e12dd  pop rdi
0000790c663e12de  pop rdx
0000790c663e12df  pop rcx
0000790c663e12e0  pop rax
0000790c663e12e1  add rsp, 0x08
0000790c663e12e5  jmp 0x0000790C663DC787
0000790c663e12ea  sub rsp, 0x08
0000790c663e12ee  push rax
0000790c663e12ef  push rcx
0000790c663e12f0  push rdx
0000790c663e12f1  push rdi
0000790c663e12f2  push rsi
0000790c663e12f3  push r8
0000790c663e12f5  push r9
0000790c663e12f7  push r10
0000790c663e12f9  push r11
0000790c663e12fb  sub rsp, 0xF0
0000790c663e1302  vmovaps [rsp], xmm0
0000790c663e1307  vmovaps [rsp+0x10], xmm1
0000790c663e130d  vmovaps [rsp+0x20], xmm2
0000790c663e1313  vmovaps [rsp+0x30], xmm3
0000790c663e1319  vmovaps [rsp+0x40], xmm4
0000790c663e131f  vmovaps [rsp+0x50], xmm5
0000790c663e1325  vmovaps [rsp+0x60], xmm6
0000790c663e132b  vmovaps [rsp+0x70], xmm8
0000790c663e1331  vmovaps [rsp+0x80], xmm9
0000790c663e133a  vmovaps [rsp+0x90], xmm10
0000790c663e1343  vmovaps [rsp+0xA0], xmm11
0000790c663e134c  vmovaps [rsp+0xB0], xmm12
0000790c663e1355  vmovaps [rsp+0xC0], xmm13
0000790c663e135e  vmovaps [rsp+0xD0], xmm14
0000790c663e1367  vmovaps [rsp+0xE0], xmm15
0000790c663e1370  sub rsp, 0x30
0000790c663e1374  movaps [rsp], xmm7
0000790c663e1378  movaps [rsp+0x10], xmm9
0000790c663e137e  movaps [rsp+0x20], xmm15
0000790c663e1384  lea rdi, [rsp]
0000790c663e1388  mov esi, 0x00
0000790c663e138d  mov rax, 0x631C1759F530
0000790c663e1397  call rax
0000790c663e1399  movaps xmm7, [rsp]
0000790c663e139d  add rsp, 0x30
0000790c663e13a1  vmovaps xmm0, [rsp]
0000790c663e13a6  vmovaps xmm1, [rsp+0x10]
0000790c663e13ac  vmovaps xmm2, [rsp+0x20]
0000790c663e13b2  vmovaps xmm3, [rsp+0x30]
0000790c663e13b8  vmovaps xmm4, [rsp+0x40]
0000790c663e13be  vmovaps xmm5, [rsp+0x50]
0000790c663e13c4  vmovaps xmm6, [rsp+0x60]
0000790c663e13ca  vmovaps xmm8, [rsp+0x70]
0000790c663e13d0  vmovaps xmm9, [rsp+0x80]
0000790c663e13d9  vmovaps xmm10, [rsp+0x90]
0000790c663e13e2  vmovaps xmm11, [rsp+0xA0]
0000790c663e13eb  vmovaps xmm12, [rsp+0xB0]
0000790c663e13f4  vmovaps xmm13, [rsp+0xC0]
0000790c663e13fd  vmovaps xmm14, [rsp+0xD0]
0000790c663e1406  vmovaps xmm15, [rsp+0xE0]
0000790c663e140f  add rsp, 0xF0
0000790c663e1416  pop r11
0000790c663e1418  pop r10
0000790c663e141a  pop r9
0000790c663e141c  pop r8
0000790c663e141e  pop rsi
0000790c663e141f  pop rdi
0000790c663e1420  pop rdx
0000790c663e1421  pop rcx
0000790c663e1422  pop rax
0000790c663e1423  add rsp, 0x08
0000790c663e1427  jmp 0x0000790C663DC7B4
0000790c663e142c  sub rsp, 0x08
0000790c663e1430  push rax
0000790c663e1431  push rcx
0000790c663e1432  push rdx
0000790c663e1433  push rdi
0000790c663e1434  push rsi
0000790c663e1435  push r8
0000790c663e1437  push r9
0000790c663e1439  push r10
0000790c663e143b  push r11
0000790c663e143d  sub rsp, 0xF0
0000790c663e1444  vmovaps [rsp], xmm0
0000790c663e1449  vmovaps [rsp+0x10], xmm1
0000790c663e144f  vmovaps [rsp+0x20], xmm2
0000790c663e1455  vmovaps [rsp+0x30], xmm3
0000790c663e145b  vmovaps [rsp+0x40], xmm4
0000790c663e1461  vmovaps [rsp+0x50], xmm5
0000790c663e1467  vmovaps [rsp+0x60], xmm6
0000790c663e146d  vmovaps [rsp+0x70], xmm7
0000790c663e1473  vmovaps [rsp+0x80], xmm8
0000790c663e147c  vmovaps [rsp+0x90], xmm10
0000790c663e1485  vmovaps [rsp+0xA0], xmm11
0000790c663e148e  vmovaps [rsp+0xB0], xmm12
0000790c663e1497  vmovaps [rsp+0xC0], xmm13
0000790c663e14a0  vmovaps [rsp+0xD0], xmm14
0000790c663e14a9  vmovaps [rsp+0xE0], xmm15
0000790c663e14b2  sub rsp, 0x30
0000790c663e14b6  movaps [rsp], xmm9
0000790c663e14bb  movaps [rsp+0x10], xmm13
0000790c663e14c1  movaps [rsp+0x20], xmm15
0000790c663e14c7  lea rdi, [rsp]
0000790c663e14cb  mov esi, 0x00
0000790c663e14d0  mov rax, 0x631C1759F530
0000790c663e14da  call rax
0000790c663e14dc  movaps xmm9, [rsp]
0000790c663e14e1  add rsp, 0x30
0000790c663e14e5  vmovaps xmm0, [rsp]
0000790c663e14ea  vmovaps xmm1, [rsp+0x10]
0000790c663e14f0  vmovaps xmm2, [rsp+0x20]
0000790c663e14f6  vmovaps xmm3, [rsp+0x30]
0000790c663e14fc  vmovaps xmm4, [rsp+0x40]
0000790c663e1502  vmovaps xmm5, [rsp+0x50]
0000790c663e1508  vmovaps xmm6, [rsp+0x60]
0000790c663e150e  vmovaps xmm7, [rsp+0x70]
0000790c663e1514  vmovaps xmm8, [rsp+0x80]
0000790c663e151d  vmovaps xmm10, [rsp+0x90]
0000790c663e1526  vmovaps xmm11, [rsp+0xA0]
0000790c663e152f  vmovaps xmm12, [rsp+0xB0]
0000790c663e1538  vmovaps xmm13, [rsp+0xC0]
0000790c663e1541  vmovaps xmm14, [rsp+0xD0]
0000790c663e154a  vmovaps xmm15, [rsp+0xE0]
0000790c663e1553  add rsp, 0xF0
0000790c663e155a  pop r11
0000790c663e155c  pop r10
0000790c663e155e  pop r9
0000790c663e1560  pop r8
0000790c663e1562  pop rsi
0000790c663e1563  pop rdi
0000790c663e1564  pop rdx
0000790c663e1565  pop rcx
0000790c663e1566  pop rax
0000790c663e1567  add rsp, 0x08
0000790c663e156b  jmp 0x0000790C663DC7E2
0000790c663e1570  sub rsp, 0x08
0000790c663e1574  push rax
0000790c663e1575  push rcx
0000790c663e1576  push rdx
0000790c663e1577  push rdi
0000790c663e1578  push rsi
0000790c663e1579  push r8
0000790c663e157b  push r9
0000790c663e157d  push r10
0000790c663e157f  push r11
0000790c663e1581  sub rsp, 0xF0
0000790c663e1588  vmovaps [rsp], xmm0
0000790c663e158d  vmovaps [rsp+0x10], xmm1
0000790c663e1593  vmovaps [rsp+0x20], xmm2
0000790c663e1599  vmovaps [rsp+0x30], xmm3
0000790c663e159f  vmovaps [rsp+0x40], xmm4
0000790c663e15a5  vmovaps [rsp+0x50], xmm5
0000790c663e15ab  vmovaps [rsp+0x60], xmm6
0000790c663e15b1  vmovaps [rsp+0x70], xmm7
0000790c663e15b7  vmovaps [rsp+0x80], xmm8
0000790c663e15c0  vmovaps [rsp+0x90], xmm9
0000790c663e15c9  vmovaps [rsp+0xA0], xmm10
0000790c663e15d2  vmovaps [rsp+0xB0], xmm11
0000790c663e15db  vmovaps [rsp+0xC0], xmm12
0000790c663e15e4  vmovaps [rsp+0xD0], xmm13
0000790c663e15ed  vmovaps [rsp+0xE0], xmm14
0000790c663e15f6  sub rsp, 0x30
0000790c663e15fa  movaps [rsp], xmm15
0000790c663e15ff  movaps [rsp+0x10], xmm11
0000790c663e1605  movaps [rsp+0x20], xmm12
0000790c663e160b  lea rdi, [rsp]
0000790c663e160f  mov esi, 0x00
0000790c663e1614  mov rax, 0x631C1759F530
0000790c663e161e  call rax
0000790c663e1620  movaps xmm15, [rsp]
0000790c663e1625  add rsp, 0x30
0000790c663e1629  vmovaps xmm0, [rsp]
0000790c663e162e  vmovaps xmm1, [rsp+0x10]
0000790c663e1634  vmovaps xmm2, [rsp+0x20]
0000790c663e163a  vmovaps xmm3, [rsp+0x30]
0000790c663e1640  vmovaps xmm4, [rsp+0x40]
0000790c663e1646  vmovaps xmm5, [rsp+0x50]
0000790c663e164c  vmovaps xmm6, [rsp+0x60]
0000790c663e1652  vmovaps xmm7, [rsp+0x70]
0000790c663e1658  vmovaps xmm8, [rsp+0x80]
0000790c663e1661  vmovaps xmm9, [rsp+0x90]
0000790c663e166a  vmovaps xmm10, [rsp+0xA0]
0000790c663e1673  vmovaps xmm11, [rsp+0xB0]
0000790c663e167c  vmovaps xmm12, [rsp+0xC0]
0000790c663e1685  vmovaps xmm13, [rsp+0xD0]
0000790c663e168e  vmovaps xmm14, [rsp+0xE0]
0000790c663e1697  add rsp, 0xF0
0000790c663e169e  pop r11
0000790c663e16a0  pop r10
0000790c663e16a2  pop r9
0000790c663e16a4  pop r8
0000790c663e16a6  pop rsi
0000790c663e16a7  pop rdi
0000790c663e16a8  pop rdx
0000790c663e16a9  pop rcx
0000790c663e16aa  pop rax
0000790c663e16ab  add rsp, 0x08
0000790c663e16af  jmp 0x0000790C663DC7FD
0000790c663e16b4  sub rsp, 0x08
0000790c663e16b8  push rax
0000790c663e16b9  push rcx
0000790c663e16ba  push rdx
0000790c663e16bb  push rdi
0000790c663e16bc  push rsi
0000790c663e16bd  push r8
0000790c663e16bf  push r9
0000790c663e16c1  push r10
0000790c663e16c3  push r11
0000790c663e16c5  sub rsp, 0xF0
0000790c663e16cc  vmovaps [rsp], xmm0
0000790c663e16d1  vmovaps [rsp+0x10], xmm1
0000790c663e16d7  vmovaps [rsp+0x20], xmm2
0000790c663e16dd  vmovaps [rsp+0x30], xmm3
0000790c663e16e3  vmovaps [rsp+0x40], xmm4
0000790c663e16e9  vmovaps [rsp+0x50], xmm5
0000790c663e16ef  vmovaps [rsp+0x60], xmm6
0000790c663e16f5  vmovaps [rsp+0x70], xmm7
0000790c663e16fb  vmovaps [rsp+0x80], xmm8
0000790c663e1704  vmovaps [rsp+0x90], xmm9
0000790c663e170d  vmovaps [rsp+0xA0], xmm10
0000790c663e1716  vmovaps [rsp+0xB0], xmm11
0000790c663e171f  vmovaps [rsp+0xC0], xmm12
0000790c663e1728  vmovaps [rsp+0xD0], xmm14
0000790c663e1731  vmovaps [rsp+0xE0], xmm15
0000790c663e173a  sub rsp, 0x30
0000790c663e173e  movaps [rsp], xmm13
0000790c663e1743  movaps [rsp+0x10], xmm10
0000790c663e1749  movaps [rsp+0x20], xmm14
0000790c663e174f  lea rdi, [rsp]
0000790c663e1753  mov esi, 0x00
0000790c663e1758  mov rax, 0x631C1759F530
0000790c663e1762  call rax
0000790c663e1764  movaps xmm13, [rsp]
0000790c663e1769  add rsp, 0x30
0000790c663e176d  vmovaps xmm0, [rsp]
0000790c663e1772  vmovaps xmm1, [rsp+0x10]
0000790c663e1778  vmovaps xmm2, [rsp+0x20]
0000790c663e177e  vmovaps xmm3, [rsp+0x30]
0000790c663e1784  vmovaps xmm4, [rsp+0x40]
0000790c663e178a  vmovaps xmm5, [rsp+0x50]
0000790c663e1790  vmovaps xmm6, [rsp+0x60]
0000790c663e1796  vmovaps xmm7, [rsp+0x70]
0000790c663e179c  vmovaps xmm8, [rsp+0x80]
0000790c663e17a5  vmovaps xmm9, [rsp+0x90]
0000790c663e17ae  vmovaps xmm10, [rsp+0xA0]
0000790c663e17b7  vmovaps xmm11, [rsp+0xB0]
0000790c663e17c0  vmovaps xmm12, [rsp+0xC0]
0000790c663e17c9  vmovaps xmm14, [rsp+0xD0]
0000790c663e17d2  vmovaps xmm15, [rsp+0xE0]
0000790c663e17db  add rsp, 0xF0
0000790c663e17e2  pop r11
0000790c663e17e4  pop r10
0000790c663e17e6  pop r9
0000790c663e17e8  pop r8
0000790c663e17ea  pop rsi
0000790c663e17eb  pop rdi
0000790c663e17ec  pop rdx
0000790c663e17ed  pop rcx
0000790c663e17ee  pop rax
0000790c663e17ef  add rsp, 0x08
0000790c663e17f3  jmp 0x0000790C663DC820
0000790c663e17f8  sub rsp, 0x08
0000790c663e17fc  push rax
0000790c663e17fd  push rcx
0000790c663e17fe  push rdx
0000790c663e17ff  push rdi
0000790c663e1800  push rsi
0000790c663e1801  push r8
0000790c663e1803  push r9
0000790c663e1805  push r10
0000790c663e1807  push r11
0000790c663e1809  sub rsp, 0xF0
0000790c663e1810  vmovaps [rsp], xmm0
0000790c663e1815  vmovaps [rsp+0x10], xmm1
0000790c663e181b  vmovaps [rsp+0x20], xmm2
0000790c663e1821  vmovaps [rsp+0x30], xmm3
0000790c663e1827  vmovaps [rsp+0x40], xmm4
0000790c663e182d  vmovaps [rsp+0x50], xmm5
0000790c663e1833  vmovaps [rsp+0x60], xmm6
0000790c663e1839  vmovaps [rsp+0x70], xmm7
0000790c663e183f  vmovaps [rsp+0x80], xmm8
0000790c663e1848  vmovaps [rsp+0x90], xmm9
0000790c663e1851  vmovaps [rsp+0xA0], xmm10
0000790c663e185a  vmovaps [rsp+0xB0], xmm11
0000790c663e1863  vmovaps [rsp+0xC0], xmm12
0000790c663e186c  vmovaps [rsp+0xD0], xmm13
0000790c663e1875  vmovaps [rsp+0xE0], xmm15
0000790c663e187e  sub rsp, 0x30
0000790c663e1882  movaps [rsp], xmm14
0000790c663e1887  movaps [rsp+0x10], xmm1
0000790c663e188c  movaps [rsp+0x20], xmm7
0000790c663e1891  lea rdi, [rsp]
0000790c663e1895  mov esi, 0x00
0000790c663e189a  mov rax, 0x631C1759F530
0000790c663e18a4  call rax
0000790c663e18a6  movaps xmm14, [rsp]
0000790c663e18ab  add rsp, 0x30
0000790c663e18af  vmovaps xmm0, [rsp]
0000790c663e18b4  vmovaps xmm1, [rsp+0x10]
0000790c663e18ba  vmovaps xmm2, [rsp+0x20]
0000790c663e18c0  vmovaps xmm3, [rsp+0x30]
0000790c663e18c6  vmovaps xmm4, [rsp+0x40]
0000790c663e18cc  vmovaps xmm5, [rsp+0x50]
0000790c663e18d2  vmovaps xmm6, [rsp+0x60]
0000790c663e18d8  vmovaps xmm7, [rsp+0x70]
0000790c663e18de  vmovaps xmm8, [rsp+0x80]
0000790c663e18e7  vmovaps xmm9, [rsp+0x90]
0000790c663e18f0  vmovaps xmm10, [rsp+0xA0]
0000790c663e18f9  vmovaps xmm11, [rsp+0xB0]
0000790c663e1902  vmovaps xmm12, [rsp+0xC0]
0000790c663e190b  vmovaps xmm13, [rsp+0xD0]
0000790c663e1914  vmovaps xmm15, [rsp+0xE0]
0000790c663e191d  add rsp, 0xF0
0000790c663e1924  pop r11
0000790c663e1926  pop r10
0000790c663e1928  pop r9
0000790c663e192a  pop r8
0000790c663e192c  pop rsi
0000790c663e192d  pop rdi
0000790c663e192e  pop rdx
0000790c663e192f  pop rcx
0000790c663e1930  pop rax
0000790c663e1931  add rsp, 0x08
0000790c663e1935  jmp 0x0000790C663DC843
0000790c663e193a  sub rsp, 0x08
0000790c663e193e  push rax
0000790c663e193f  push rcx
0000790c663e1940  push rdx
0000790c663e1941  push rdi
0000790c663e1942  push rsi
0000790c663e1943  push r8
0000790c663e1945  push r9
0000790c663e1947  push r10
0000790c663e1949  push r11
0000790c663e194b  sub rsp, 0xF0
0000790c663e1952  vmovaps [rsp], xmm0
0000790c663e1957  vmovaps [rsp+0x10], xmm2
0000790c663e195d  vmovaps [rsp+0x20], xmm3
0000790c663e1963  vmovaps [rsp+0x30], xmm4
0000790c663e1969  vmovaps [rsp+0x40], xmm5
0000790c663e196f  vmovaps [rsp+0x50], xmm6
0000790c663e1975  vmovaps [rsp+0x60], xmm7
0000790c663e197b  vmovaps [rsp+0x70], xmm8
0000790c663e1981  vmovaps [rsp+0x80], xmm9
0000790c663e198a  vmovaps [rsp+0x90], xmm10
0000790c663e1993  vmovaps [rsp+0xA0], xmm11
0000790c663e199c  vmovaps [rsp+0xB0], xmm12
0000790c663e19a5  vmovaps [rsp+0xC0], xmm13
0000790c663e19ae  vmovaps [rsp+0xD0], xmm14
0000790c663e19b7  vmovaps [rsp+0xE0], xmm15
0000790c663e19c0  sub rsp, 0x30
0000790c663e19c4  movaps [rsp], xmm1
0000790c663e19c8  movaps [rsp+0x10], xmm8
0000790c663e19ce  movaps [rsp+0x20], xmm9
0000790c663e19d4  lea rdi, [rsp]
0000790c663e19d8  mov esi, 0x00
0000790c663e19dd  mov rax, 0x631C1759F530
0000790c663e19e7  call rax
0000790c663e19e9  movaps xmm1, [rsp]
0000790c663e19ed  add rsp, 0x30
0000790c663e19f1  vmovaps xmm0, [rsp]
0000790c663e19f6  vmovaps xmm2, [rsp+0x10]
0000790c663e19fc  vmovaps xmm3, [rsp+0x20]
0000790c663e1a02  vmovaps xmm4, [rsp+0x30]
0000790c663e1a08  vmovaps xmm5, [rsp+0x40]
0000790c663e1a0e  vmovaps xmm6, [rsp+0x50]
0000790c663e1a14  vmovaps xmm7, [rsp+0x60]
0000790c663e1a1a  vmovaps xmm8, [rsp+0x70]
0000790c663e1a20  vmovaps xmm9, [rsp+0x80]
0000790c663e1a29  vmovaps xmm10, [rsp+0x90]
0000790c663e1a32  vmovaps xmm11, [rsp+0xA0]
0000790c663e1a3b  vmovaps xmm12, [rsp+0xB0]
0000790c663e1a44  vmovaps xmm13, [rsp+0xC0]
0000790c663e1a4d  vmovaps xmm14, [rsp+0xD0]
0000790c663e1a56  vmovaps xmm15, [rsp+0xE0]
0000790c663e1a5f  add rsp, 0xF0
0000790c663e1a66  pop r11
0000790c663e1a68  pop r10
0000790c663e1a6a  pop r9
0000790c663e1a6c  pop r8
0000790c663e1a6e  pop rsi
0000790c663e1a6f  pop rdi
0000790c663e1a70  pop rdx
0000790c663e1a71  pop rcx
0000790c663e1a72  pop rax
0000790c663e1a73  add rsp, 0x08
0000790c663e1a77  jmp 0x0000790C663DC865
0000790c663e1a7c  call 0x0000790C662E5940
0000790c663e1a81  jmp 0x0000790C663DC873
0000790c663e1a86  call 0x0000790C6620C380
0000790c663e1a8b  jmp 0x0000790C663DC87D
0000790c663e1a90  call 0x0000790C6620D600
0000790c663e1a95  jmp 0x0000790C663DC887
0000790c663e1a9a  call 0x0000790C661FF540
0000790c663e1a9f  jmp 0x0000790C663DC891
0000790c663e1aa4  int3
0000790c663e1aa5  nop [rax+rax*1], ax
0000790c663e1aae  nop
0000790c663e1ab0  mov rax, [r15+0xF8]
0000790c663e1ab7  lea r14, [rax+0x140]
0000790c663e1abe  mov r12, [r13+r14*1]
0000790c663e1ac3  mov [r15+0xE8], r12
0000790c663e1aca  lea r14, [rax+0x130]
0000790c663e1ad1  mov r12, [r13+r14*1]
0000790c663e1ad6  lea r14, [rax+0x138]
0000790c663e1add  mov r11, [r13+r14*1]
0000790c663e1ae2  movq xmm1, r12
0000790c663e1ae7  movq xmm15, r11
0000790c663e1aec  movq xmm1, xmm1
0000790c663e1af0  movq xmm1, xmm1
0000790c663e1af4  movaps [r15+0x1A0], xmm1
0000790c663e1afc  movq xmm15, xmm15
0000790c663e1b01  movq xmm15, xmm15
0000790c663e1b06  movaps [r15+0x190], xmm15
0000790c663e1b0e  lea r14, [rax+0x120]
0000790c663e1b15  mov r12, [r13+r14*1]
0000790c663e1b1a  lea r14, [rax+0x128]
0000790c663e1b21  mov r11, [r13+r14*1]
0000790c663e1b26  movq xmm1, r12
0000790c663e1b2b  movq xmm15, r11
0000790c663e1b30  movq xmm1, xmm1
0000790c663e1b34  movq xmm1, xmm1
0000790c663e1b38  movaps [r15+0x1C0], xmm1
0000790c663e1b40  movq xmm15, xmm15
0000790c663e1b45  movq xmm15, xmm15
0000790c663e1b4a  movaps [r15+0x1B0], xmm15
0000790c663e1b52  lea r14, [rax+0x110]
0000790c663e1b59  mov r12, [r13+r14*1]
0000790c663e1b5e  lea r14, [rax+0x118]
0000790c663e1b65  mov r11, [r13+r14*1]
0000790c663e1b6a  movq xmm1, r12
0000790c663e1b6f  movq xmm15, r11
0000790c663e1b74  movq xmm1, xmm1
0000790c663e1b78  movq xmm1, xmm1
0000790c663e1b7c  movaps [r15+0x1E0], xmm1
0000790c663e1b84  movq xmm15, xmm15
0000790c663e1b89  movq xmm15, xmm15
0000790c663e1b8e  movaps [r15+0x1D0], xmm15
0000790c663e1b96  lea r14, [rax+0x100]
0000790c663e1b9d  mov r12, [r13+r14*1]
0000790c663e1ba2  lea r14, [rax+0x108]
0000790c663e1ba9  mov r11, [r13+r14*1]
0000790c663e1bae  movq xmm1, r12
0000790c663e1bb3  movq xmm15, r11
0000790c663e1bb8  movq xmm1, xmm1
0000790c663e1bbc  movq xmm1, xmm1
0000790c663e1bc0  movaps [r15+0x200], xmm1
0000790c663e1bc8  movq xmm15, xmm15
0000790c663e1bcd  movq xmm15, xmm15
0000790c663e1bd2  movaps [r15+0x1F0], xmm15
0000790c663e1bda  mov qword ptr [r15+0x40], 0x430000
0000790c663e1be2  mov r14d, 0x430510
0000790c663e1be8  mov r12, [r13+r14*1]
0000790c663e1bed  movq xmm1, r12
0000790c663e1bf2  lea r14, [rax+0x150]
0000790c663e1bf9  mov [r15+0xF8], r14
0000790c663e1c00  mov rax, [r15+0x50]
0000790c663e1c04  movups xmm15, [r13+rax*1]
0000790c663e1c0a  movaps [r15+0x120], xmm15
0000790c663e1c12  mov qword ptr [r15+0x48], 0x10
0000790c663e1c1a  xor eax, eax
0000790c663e1c1c  mov r14d, 0x10
0000790c663e1c22  mov r12d, 0x200
0000790c663e1c28  cmp r14, r12
0000790c663e1c2b  cmc
0000790c663e1c2c  lahf
0000790c663e1c2d  seto al
0000790c663e1c30  mov [r15+0x108], eax
0000790c663e1c37  pextrq rax, xmm15, 0x01
0000790c663e1c3e  movq xmm14, rax
0000790c663e1c43  movaps [r15+0x130], xmm14
0000790c663e1c4b  movq rax, xmm1
0000790c663e1c50  movq r14, xmm15
0000790c663e1c55  vmovq xmm1, rax
0000790c663e1c5a  vmovq xmm15, r14
0000790c663e1c5f  movaps xmm13, xmm1
0000790c663e1c63  addsd xmm13, xmm15
0000790c663e1c68  ucomisd xmm13, xmm13
0000790c663e1c6d  jp 0x0000790C663E1D86
0000790c663e1c73  movq xmm13, xmm13
0000790c663e1c78  movq rax, xmm13
0000790c663e1c7d  movq r14, xmm14
0000790c663e1c82  vmovq xmm1, rax
0000790c663e1c87  vmovq xmm15, r14
0000790c663e1c8c  movaps xmm14, xmm1
0000790c663e1c90  addsd xmm14, xmm15
0000790c663e1c95  ucomisd xmm14, xmm14
0000790c663e1c9a  jp 0x0000790C663E1DCE
0000790c663e1ca0  movq xmm14, xmm14
0000790c663e1ca5  movaps [r15+0x110], xmm14
0000790c663e1cad  mov eax, [r15+0x108]
0000790c663e1cb4  sahf
0000790c663e1cb5  jnz 0x0000790C663E1CE7
0000790c663e1cb7  cmp dword ptr [r15+0x318], 0x00
0000790c663e1cbf  jz 0x0000790C663E1FE0
0000790c663e1cc5  nop [rax+rax*1], ax
0000790c663e1cce  nop [rax+rax*1], eax
0000790c663e1cd6  mov eax, 0x410490
0000790c663e1cdb  mov [r15+0x100], rax
0000790c663e1ce2  jmp 0x0000790C661FE110
0000790c663e1ce7  cmp dword ptr [r15+0x318], 0x00
0000790c663e1cef  jz 0x0000790C663E1E20
0000790c663e1cf5  nop [rax+rax*1], ax
0000790c663e1cfe  nop [rax+rax*1], eax
0000790c663e1d06  mov eax, 0x410474
0000790c663e1d0b  mov [r15+0x100], rax
0000790c663e1d12  jmp 0x0000790C661FE110
0000790c663e1d17  int3
0000790c663e1d18  call 0x0000790C662E27E0
0000790c663e1d1d  jmp 0x0000790C663E1AC3
0000790c663e1d22  call 0x0000790C662E27E0
0000790c663e1d27  jmp 0x0000790C663E1AD6
0000790c663e1d2c  call 0x0000790C662E1570
0000790c663e1d31  jmp 0x0000790C663E1AE2
0000790c663e1d36  call 0x0000790C662E27E0
0000790c663e1d3b  jmp 0x0000790C663E1B1A
0000790c663e1d40  call 0x0000790C662E1570
0000790c663e1d45  jmp 0x0000790C663E1B26
0000790c663e1d4a  call 0x0000790C662E27E0
0000790c663e1d4f  jmp 0x0000790C663E1B5E
0000790c663e1d54  call 0x0000790C662E1570
0000790c663e1d59  jmp 0x0000790C663E1B6A
0000790c663e1d5e  call 0x0000790C662E27E0
0000790c663e1d63  jmp 0x0000790C663E1BA2
0000790c663e1d68  call 0x0000790C662E1570
0000790c663e1d6d  jmp 0x0000790C663E1BAE
0000790c663e1d72  call 0x0000790C662E27E0
0000790c663e1d77  jmp 0x0000790C663E1BED
0000790c663e1d7c  call 0x0000790C6620E760
0000790c663e1d81  jmp 0x0000790C663E1C0A
0000790c663e1d86  ucomisd xmm1, xmm15
0000790c663e1d8b  jp 0x0000790C663E1D9A
0000790c663e1d8d  movaps xmm13, [0x0000790C65FFE060]
0000790c663e1d95  jmp 0x0000790C663E1C73
0000790c663e1d9a  vxorps xmm0, xmm1, xmm15
0000790c663e1d9f  pextrw eax, xmm0, 0x03
0000790c663e1da4  and eax, 0x7FF8
0000790c663e1da9  cmp eax, 0x08
0000790c663e1dac  jnz 0x0000790C663E1C73
0000790c663e1db2  movq rax, xmm15
0000790c663e1db7  shl rax, 0x0D
0000790c663e1dbb  jbe 0x0000790C663E1C73
0000790c663e1dc1  vorps xmm13, xmm15, [0x0000790C65FFE070]
0000790c663e1dc9  jmp 0x0000790C663E1C73
0000790c663e1dce  ucomisd xmm1, xmm15
0000790c663e1dd3  jp 0x0000790C663E1DE2
0000790c663e1dd5  movaps xmm14, [0x0000790C65FFE060]
0000790c663e1ddd  jmp 0x0000790C663E1CA0
0000790c663e1de2  vxorps xmm0, xmm1, xmm15
0000790c663e1de7  pextrw eax, xmm0, 0x03
0000790c663e1dec  and eax, 0x7FF8
0000790c663e1df1  cmp eax, 0x08
0000790c663e1df4  jnz 0x0000790C663E1CA0
0000790c663e1dfa  movq rax, xmm15
0000790c663e1dff  shl rax, 0x0D
0000790c663e1e03  jbe 0x0000790C663E1CA0
0000790c663e1e09  vorps xmm14, xmm15, [0x0000790C65FFE070]
0000790c663e1e11  jmp 0x0000790C663E1CA0
0000790c663e1e16  int3
0000790c663e1e17  nop [rax+rax*1], ax
0000790c663e1e20  mov rax, [r15+0x48]
0000790c663e1e24  mov r14, [r15+0x50]
0000790c663e1e28  lea r12, [r14+rax*1]
0000790c663e1e2c  movups xmm1, [r13+r12*1]
0000790c663e1e32  movaps [r15+0x120], xmm1
0000790c663e1e3a  lea r14, [rax+0x10]
0000790c663e1e3e  mov [r15+0x48], r14
0000790c663e1e42  xor eax, eax
0000790c663e1e44  mov r12d, 0x200
0000790c663e1e4a  cmp r14, r12
0000790c663e1e4d  cmc
0000790c663e1e4e  lahf
0000790c663e1e4f  seto al
0000790c663e1e52  mov [r15+0x108], eax
0000790c663e1e59  pextrq rax, xmm1, 0x01
0000790c663e1e60  movq xmm15, rax
0000790c663e1e65  movaps [r15+0x130], xmm15
0000790c663e1e6d  movaps xmm14, [r15+0x110]
0000790c663e1e75  movq rax, xmm14
0000790c663e1e7a  movq r14, xmm1
0000790c663e1e7f  vmovq xmm1, rax
0000790c663e1e84  vmovq xmm14, r14
0000790c663e1e89  movaps xmm13, xmm1
0000790c663e1e8d  addsd xmm13, xmm14
0000790c663e1e92  ucomisd xmm13, xmm13
0000790c663e1e97  jp 0x0000790C663E1F4C
0000790c663e1e9d  movq xmm13, xmm13
0000790c663e1ea2  movq rax, xmm13
0000790c663e1ea7  movq r14, xmm15
0000790c663e1eac  vmovq xmm1, rax
0000790c663e1eb1  vmovq xmm15, r14
0000790c663e1eb6  movaps xmm14, xmm1
0000790c663e1eba  addsd xmm14, xmm15
0000790c663e1ebf  ucomisd xmm14, xmm14
0000790c663e1ec4  jp 0x0000790C663E1F94
0000790c663e1eca  movq xmm14, xmm14
0000790c663e1ecf  movaps [r15+0x110], xmm14
0000790c663e1ed7  mov eax, [r15+0x108]
0000790c663e1ede  sahf
0000790c663e1edf  jnz 0x0000790C663E1F11
0000790c663e1ee1  cmp dword ptr [r15+0x318], 0x00
0000790c663e1ee9  jz 0x0000790C663E1FE0
0000790c663e1eef  nop [rax+rax*1], ax
0000790c663e1ef8  nop [rax+rax*1], eax
0000790c663e1f00  mov eax, 0x410490
0000790c663e1f05  mov [r15+0x100], rax
0000790c663e1f0c  jmp 0x0000790C661FE110
0000790c663e1f11  cmp dword ptr [r15+0x318], 0x00
0000790c663e1f19  jz 0x0000790C663E1E20
0000790c663e1f1f  nop [rax+rax*1], ax
0000790c663e1f28  nop [rax+rax*1], eax
0000790c663e1f30  mov eax, 0x410474
0000790c663e1f35  mov [r15+0x100], rax
0000790c663e1f3c  jmp 0x0000790C661FE110
0000790c663e1f41  int3
0000790c663e1f42  call 0x0000790C662B52F0
0000790c663e1f47  jmp 0x0000790C663E1E32
0000790c663e1f4c  ucomisd xmm1, xmm14
0000790c663e1f51  jp 0x0000790C663E1F60
0000790c663e1f53  movaps xmm13, [0x0000790C65FFE060]
0000790c663e1f5b  jmp 0x0000790C663E1E9D
0000790c663e1f60  vxorps xmm0, xmm1, xmm14
0000790c663e1f65  pextrw eax, xmm0, 0x03
0000790c663e1f6a  and eax, 0x7FF8
0000790c663e1f6f  cmp eax, 0x08
0000790c663e1f72  jnz 0x0000790C663E1E9D
0000790c663e1f78  movq rax, xmm14
0000790c663e1f7d  shl rax, 0x0D
0000790c663e1f81  jbe 0x0000790C663E1E9D
0000790c663e1f87  vorps xmm13, xmm14, [0x0000790C65FFE070]
0000790c663e1f8f  jmp 0x0000790C663E1E9D
0000790c663e1f94  ucomisd xmm1, xmm15
0000790c663e1f99  jp 0x0000790C663E1FA8
0000790c663e1f9b  movaps xmm14, [0x0000790C65FFE060]
0000790c663e1fa3  jmp 0x0000790C663E1ECA
0000790c663e1fa8  vxorps xmm0, xmm1, xmm15
0000790c663e1fad  pextrw eax, xmm0, 0x03
0000790c663e1fb2  and eax, 0x7FF8
0000790c663e1fb7  cmp eax, 0x08
0000790c663e1fba  jnz 0x0000790C663E1ECA
0000790c663e1fc0  movq rax, xmm15
0000790c663e1fc5  shl rax, 0x0D
0000790c663e1fc9  jbe 0x0000790C663E1ECA
0000790c663e1fcf  vorps xmm14, xmm15, [0x0000790C65FFE070]
0000790c663e1fd7  jmp 0x0000790C663E1ECA
0000790c663e1fdc  int3
0000790c663e1fdd  nop [rax], eax
0000790c663e1fe0  mov rax, [r15+0x40]
0000790c663e1fe4  lea r14, [rax+0x510]
0000790c663e1feb  movaps xmm1, [r15+0x110]
0000790c663e1ff3  movq rax, xmm1
0000790c663e1ff8  mov [r13+r14*1], rax
0000790c663e1ffd  mov rax, [r15+0xF0]
0000790c663e2004  mov [r15+0x100], rax
0000790c663e200b  jmp 0x0000790C663CE5C0
0000790c663e2010  int3
0000790c663e2011  call 0x0000790C662D5EB0
0000790c663e2016  jmp 0x0000790C663E1FFD
0000790c663e201b  int3
0000790c663e201c  nop [rax], eax
0000790c663e2020  mov qword ptr [r15+0x100], 0x04
0000790c663e202b  mov esi, 0x00
0000790c663e2030  mov edx, 0x09
0000790c663e2035  mov rdi, 0x7FFECB909C60
0000790c663e203f  mov rax, 0x631C17432970
0000790c663e2049  call rax
0000790c663e204b  cmp dword ptr [r15+0x318], 0x00
0000790c663e2053  jnz 0x0000790C661FE110
0000790c663e2059  jmp 0x0000790C661FE0A0
0000790c663e205e  int3
0000790c663e205f  int3
