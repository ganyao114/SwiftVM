
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-sha/baseline/0/3.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xf8]
  18:	mov    r14,r13
  1b:	add    r14,0x68
  1f:	mov    r15,QWORD PTR [r14]
  22:	mov    QWORD PTR [r12+0x40],r15
  27:	add    r13,0x88
  2e:	mov    r14d,0x0
  34:	mov    BYTE PTR [r13+0x0],r14b
  38:	mov    r13d,0x0
  3e:	mov    DWORD PTR [r12+0x32c],r13d
  46:	sub    r15,0x38
  4a:	pushf
  4b:	pop    r11
  4d:	mov    QWORD PTR [rsp],r11
  51:	je     0xe5
  57:	jmp    0x5c
  5c:	mov    r13,QWORD PTR [r12+0xf8]
  64:	mov    r14,r13
  67:	add    r14,0x0
  6b:	mov    QWORD PTR [r12],r14
  6f:	add    r13,0x88
  76:	mov    QWORD PTR [r12+0x8],r13
  7b:	mov    r13d,0x1
  81:	mov    QWORD PTR [r12+0x10],r13
  86:	mov    r13d,0x4102b8
  8c:	mov    QWORD PTR [r12+0xf0],r13
  94:	mov    r13d,0x410338
  9a:	mov    QWORD PTR [r12+0x100],r13
  a2:	mov    r11,QWORD PTR [rsp]
  a6:	mov    QWORD PTR [r12+0x398],r11
  ae:	mov    edi,0x410338
  b3:	mov    QWORD PTR [r12+0x100],rdi
  bb:	add    rsp,0x10
  bf:	nop
  c0:	jmp    QWORD PTR [rip+0x2]        # 0xc8
  c6:	xchg   ax,ax
  c8:	loopne 0xa1
  ca:	call   QWORD PTR [rbx-0x5f]
  cd:	jg     0xcf
  cf:	add    BYTE PTR [rax],bh
  d1:	(bad)
  d2:	add    BYTE PTR [rcx+riz*4+0x7f],dl
  d6:	add    BYTE PTR [rax],al
  d8:	movabs r11,0x5fd6253550a0
  e2:	jmp    r11
  e5:	mov    r13,QWORD PTR [r12+0x98]
  ed:	ror    r13,0x3d
  f1:	and    r13,0xfffffffffffffff8
  f5:	mov    r14,QWORD PTR [r12+0xf8]
  fd:	mov    r15,r14
 100:	add    r15,0x0
 104:	mov    QWORD PTR [r12],r15
 108:	mov    r15,r14
 10b:	add    r15,0x78
 10f:	mov    QWORD PTR [r12+0x8],r15
 114:	mov    r15d,0x8
 11a:	mov    QWORD PTR [r12+0x10],r15
 11f:	movabs rcx,0xff00ff00ff00ff
 129:	mov    r15,r13
 12c:	and    r15,rcx
 12f:	shl    r15,0x8
 133:	movabs rcx,0xff00ff00ff00ff00
 13d:	and    r13,rcx
 140:	shr    r13,0x8
 144:	mov    rcx,r15
 147:	or     r13,rcx
 14a:	movabs rcx,0xffff0000ffff
 154:	mov    r15,r13
 157:	and    r15,rcx
 15a:	shl    r15,0x10
 15e:	movabs rcx,0xffff0000ffff0000
 168:	and    r13,rcx
 16b:	shr    r13,0x10
 16f:	mov    rcx,r15
 172:	or     r13,rcx
 175:	mov    r15,r13
 178:	shl    r15,0x20
 17c:	shr    r13,0x20
 180:	mov    rcx,r15
 183:	or     r13,rcx
 186:	mov    QWORD PTR [r12+0x40],r13
 18b:	add    r14,0x78
 18f:	mov    QWORD PTR [r14],r13
 192:	mov    r13d,0x0
 198:	mov    DWORD PTR [r12+0x32c],r13d
 1a0:	mov    r13d,0x4102e0
 1a6:	mov    QWORD PTR [r12+0xf0],r13
 1ae:	mov    r13d,0x410338
 1b4:	mov    QWORD PTR [r12+0x100],r13
 1bc:	mov    r11,QWORD PTR [rsp]
 1c0:	mov    QWORD PTR [r12+0x398],r11
 1c8:	mov    edi,0x410338
 1cd:	mov    QWORD PTR [r12+0x100],rdi
 1d5:	add    rsp,0x10
 1d9:	nop    DWORD PTR [rax+0x0]
 1e0:	jmp    QWORD PTR [rip+0x2]        # 0x1e8
 1e6:	xchg   ax,ax
 1e8:	loopne 0x1c1
 1ea:	call   QWORD PTR [rbx-0x5f]
 1ed:	jg     0x1ef
 1ef:	add    BYTE PTR [rax+0x8],bl
 1f2:	add    BYTE PTR [rcx+riz*4+0x7f],dl
 1f6:	add    BYTE PTR [rax],al
 1f8:	movabs r11,0x5fd6253550a0
 202:	jmp    r11
 205:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 210:	sub    rsp,0x10
 214:	mov    r11,QWORD PTR [r12+0x398]
 21c:	mov    QWORD PTR [rsp],r11
 220:	jmp    0x5c
 225:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 230:	sub    rsp,0x10
 234:	mov    r11,QWORD PTR [r12+0x398]
 23c:	mov    QWORD PTR [rsp],r11
 240:	jmp    0xe5
 245:	nop
 246:	nop
 247:	nop
