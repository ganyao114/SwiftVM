
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-matrix-scalar/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	sub    rsp,0x150
       7:	mov    r11,QWORD PTR [r12+0x398]
       f:	mov    QWORD PTR [rsp],r11
      13:	cmp    DWORD PTR [r12+0x310],0x0
      1c:	je     0xac
      22:	push   rdx
      23:	push   rsi
      24:	push   r10
      26:	push   r11
      28:	mov    rdx,QWORD PTR [rsp+0x20]
      2d:	mov    r10d,edx
      30:	and    r10d,0xc0
      37:	shl    r10d,0x18
      3b:	mov    r11d,edx
      3e:	and    r11d,0x1
      42:	shl    r11d,0x1d
      46:	or     r10d,r11d
      49:	mov    r11d,edx
      4c:	and    r11d,0x800
      53:	shl    r11d,0x11
      57:	or     r10d,r11d
      5a:	btc    r10,0x1d
      5f:	mov    r11d,0xf0000000
      65:	and    r11,r10
      68:	movabs rsi,0xffffffff0fffffff
      72:	and    rbx,rsi
      75:	or     rbx,r11
      78:	pop    r11
      7a:	pop    r10
      7c:	pop    rsi
      7d:	pop    rdx
      7e:	mov    QWORD PTR [r12+0x108],rbx
      86:	mov    eax,0x410034
      8b:	mov    QWORD PTR [r12+0x100],rax
      93:	add    rsp,0x150
      9a:	mov    eax,0x3
      9f:	movabs r11,0x557f026e8390
      a9:	jmp    r11
      ac:	mov    r13d,0x0
      b2:	mov    QWORD PTR [r12+0x58],r13
      b7:	mov    r13d,0x420000
      bd:	add    r13,0x1c0
      c4:	mov    QWORD PTR [r12+0x40],r13
      c9:	mov    r13d,0x41
      cf:	mov    QWORD PTR [r12+0x50],r13
      d4:	mov    r13d,0x420000
      da:	add    r13,0x3c0
      e1:	mov    QWORD PTR [r12+0x48],r13
      e6:	jmp    0xeb
      eb:	mov    r13,QWORD PTR [r12+0x58]
      f0:	add    r13,0x1
      f4:	mov    QWORD PTR [r12+0x60],r13
      f9:	lea    r13,[r12]
      fd:	mov    r14d,0x1e43f541
     103:	mov    r15d,0x410050
     109:	mov    rdx,QWORD PTR [rsp]
     10d:	mov    r10d,edx
     110:	and    r10d,0xc0
     117:	shl    r10d,0x18
     11b:	mov    r11d,edx
     11e:	and    r11d,0x1
     122:	shl    r11d,0x1d
     126:	or     r10d,r11d
     129:	mov    r11d,edx
     12c:	and    r11d,0x800
     133:	shl    r11d,0x11
     137:	or     r10d,r11d
     13a:	btc    r10,0x1d
     13f:	mov    r11d,0xf0000000
     145:	and    r11,r10
     148:	movabs rsi,0xffffffff0fffffff
     152:	and    rbx,rsi
     155:	or     rbx,r11
     158:	mov    QWORD PTR [r12+0x378],0x3
     164:	mov    QWORD PTR [r12+0x108],rbx
     16c:	stmxcsr DWORD PTR [r12-0x28]
     172:	ldmxcsr DWORD PTR [r12-0x38]
     178:	movabs r11,0x557f0254edc0
     182:	mov    rdi,r13
     185:	mov    rsi,r14
     188:	mov    rdx,r15
     18b:	call   r11
     18e:	ldmxcsr DWORD PTR [r12-0x28]
     194:	mov    rbx,QWORD PTR [r12+0x108]
     19c:	mov    QWORD PTR [r12+0x378],0x2
     1a8:	mov    rbp,rax
     1ab:	mov    r13,QWORD PTR [r12+0x58]
     1b0:	ror    r13,0x3d
     1b4:	and    r13,0xfffffffffffffff8
     1b8:	mov    QWORD PTR [r12+0x58],r13
     1bd:	lea    r13,[r12]
     1c1:	mov    r14d,0x1e43ed80
     1c7:	mov    r15d,0x410058
     1cd:	mov    QWORD PTR [r12+0x378],0x3
     1d9:	mov    QWORD PTR [r12+0x108],rbx
     1e1:	stmxcsr DWORD PTR [r12-0x28]
     1e7:	ldmxcsr DWORD PTR [r12-0x38]
     1ed:	movabs r11,0x557f0254edc0
     1f7:	mov    rdi,r13
     1fa:	mov    rsi,r14
     1fd:	mov    rdx,r15
     200:	call   r11
     203:	ldmxcsr DWORD PTR [r12-0x28]
     209:	mov    rbx,QWORD PTR [r12+0x108]
     211:	mov    QWORD PTR [r12+0x378],0x2
     21d:	mov    rbp,rax
     220:	mov    r13,QWORD PTR [r12+0x60]
     225:	sub    r13,0x40
     229:	mov    r13d,DWORD PTR [r12+0x50]
     22e:	pushf
     22f:	pop    r11
     231:	mov    QWORD PTR [rsp],r11
     235:	sub    r13d,0x1
     239:	mov    QWORD PTR [r12+0x50],r13
     23e:	mov    r13,QWORD PTR [r12+0x58]
     243:	mov    r14,QWORD PTR [r12+0x48]
     248:	mov    rcx,r13
     24b:	add    r14,rcx
     24e:	mov    r15,QWORD PTR [r12+0x120]
     256:	mov    QWORD PTR [r14],r15
     259:	mov    r14d,0x0
     25f:	mov    DWORD PTR [r12+0x32c],r14d
     267:	mov    r14,QWORD PTR [r12+0x40]
     26c:	mov    rcx,r13
     26f:	add    r14,rcx
     272:	mov    r13,QWORD PTR [r12+0x110]
     27a:	mov    QWORD PTR [r14],r13
     27d:	mov    r13d,0x0
     283:	mov    DWORD PTR [r12+0x32c],r13d
     28b:	mov    r13d,0x0
     291:	mov    r14,QWORD PTR [r12+0x60]
     296:	mov    rcx,r14
     299:	or     r13,rcx
     29c:	mov    QWORD PTR [r12+0x58],r13
     2a1:	mov    rcx,QWORD PTR [r12+0x380]
     2a9:	jrcxz  0x2b0
     2ab:	jmp    0x1da6
     2b0:	push   QWORD PTR [rsp]
     2b3:	popf
     2b4:	jne    0xeb
     2ba:	jmp    0x2bf
     2bf:	mov    r13d,0x0
     2c5:	mov    r14d,0x0
     2cb:	mov    QWORD PTR [r12+0x110],r13
     2d3:	mov    QWORD PTR [r12+0x118],r14
     2db:	mov    r13d,0x0
     2e1:	mov    QWORD PTR [r12+0x58],r13
     2e6:	mov    r13d,0x420000
     2ec:	add    r13,0x5c0
     2f3:	mov    QWORD PTR [r12+0x50],r13
     2f8:	jmp    0x2fd
     2fd:	mov    r13d,0x0
     303:	mov    QWORD PTR [r12+0x60],r13
     308:	mov    r13d,0x0
     30e:	mov    r14,QWORD PTR [r12+0x50]
     313:	mov    rcx,r14
     316:	or     r13,rcx
     319:	mov    QWORD PTR [r12+0x68],r13
     31e:	jmp    0x323
     323:	mov    r13,QWORD PTR [r12+0x60]
     328:	shl    r13,0x6
     32c:	mov    r14,QWORD PTR [r12+0x40]
     331:	mov    rcx,r13
     334:	add    r14,rcx
     337:	mov    QWORD PTR [r12+0x70],r14
     33c:	mov    r13,r14
     33f:	add    r13,0x8
     343:	mov    r15,QWORD PTR [r14]
     346:	mov    rbp,QWORD PTR [r13+0x0]
     34a:	mov    r13d,0x0
     350:	mov    QWORD PTR [r12+0x120],r15
     358:	mov    QWORD PTR [r12+0x128],r13
     360:	mov    r13d,0x0
     366:	mov    QWORD PTR [r12+0x130],rbp
     36e:	mov    QWORD PTR [r12+0x138],r13
     376:	add    r14,0x10
     37a:	mov    r13,r14
     37d:	add    r13,0x8
     381:	mov    r15,QWORD PTR [r14]
     384:	mov    r14,QWORD PTR [r13+0x0]
     388:	mov    r13d,0x0
     38e:	mov    QWORD PTR [r12+0x140],r15
     396:	mov    QWORD PTR [r12+0x148],r13
     39e:	mov    r13d,0x0
     3a4:	mov    QWORD PTR [r12+0x150],r14
     3ac:	mov    QWORD PTR [r12+0x158],r13
     3b4:	mov    r13,QWORD PTR [r12+0x70]
     3b9:	mov    r14,r13
     3bc:	add    r14,0x20
     3c0:	mov    r15,r14
     3c3:	add    r15,0x8
     3c7:	mov    rbp,QWORD PTR [r14]
     3ca:	mov    r14,QWORD PTR [r15]
     3cd:	mov    r15d,0x0
     3d3:	mov    QWORD PTR [r12+0x160],rbp
     3db:	mov    QWORD PTR [r12+0x168],r15
     3e3:	mov    r15d,0x0
     3e9:	mov    QWORD PTR [r12+0x170],r14
     3f1:	mov    QWORD PTR [r12+0x178],r15
     3f9:	add    r13,0x30
     3fd:	mov    r14,r13
     400:	add    r14,0x8
     404:	mov    r15,QWORD PTR [r13+0x0]
     408:	mov    r13,QWORD PTR [r14]
     40b:	mov    r14d,0x0
     411:	mov    QWORD PTR [r12+0x180],r15
     419:	mov    QWORD PTR [r12+0x188],r14
     421:	mov    r14d,0x0
     427:	mov    QWORD PTR [r12+0x210],r13
     42f:	mov    QWORD PTR [r12+0x218],r14
     437:	mov    r13d,0x0
     43d:	mov    QWORD PTR [r12+0x70],r13
     442:	jmp    0x447
     447:	mov    r13,QWORD PTR [r12+0x70]
     44c:	mov    r14,QWORD PTR [r12+0x48]
     451:	mov    rcx,r13
     454:	add    r14,rcx
     457:	mov    QWORD PTR [r12+0x78],r14
     45c:	mov    r13,QWORD PTR [r14]
     45f:	mov    r15d,0x0
     465:	mov    QWORD PTR [r12+0x220],r13
     46d:	mov    QWORD PTR [r12+0x228],r15
     475:	mov    r13,r14
     478:	add    r13,0x40
     47c:	mov    r15,QWORD PTR [r13+0x0]
     480:	mov    r13d,0x0
     486:	mov    QWORD PTR [r12+0x230],r15
     48e:	mov    QWORD PTR [r12+0x238],r13
     496:	add    r14,0x80
     49d:	mov    r13,QWORD PTR [r14]
     4a0:	mov    r14d,0x0
     4a6:	mov    QWORD PTR [r12+0x240],r13
     4ae:	mov    QWORD PTR [r12+0x248],r14
     4b6:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     4c0:	movdqa xmm2,xmm0
     4c4:	movdqu xmm0,XMMWORD PTR [r12+0x220]
     4ce:	movdqa xmm3,xmm0
     4d2:	stmxcsr DWORD PTR [rsp+0x110]
     4da:	mov    DWORD PTR [rsp+0x114],0x1f80
     4e5:	ldmxcsr DWORD PTR [rsp+0x114]
     4ed:	movdqa xmm0,xmm2
     4f1:	movdqa xmm1,xmm3
     4f5:	movq   rax,xmm0
     4fa:	add    rax,rax
     4fd:	je     0x513
     4ff:	shr    rax,0x35
     503:	sub    eax,0x201
     508:	cmp    eax,0x3fc
     50d:	ja     0x10aa
     513:	movq   rax,xmm1
     518:	add    rax,rax
     51b:	je     0x531
     51d:	shr    rax,0x35
     521:	sub    eax,0x201
     526:	cmp    eax,0x3fc
     52b:	ja     0x10aa
     531:	movq   xmm0,xmm0
     535:	movq   xmm1,xmm1
     539:	mulsd  xmm0,xmm1
     53d:	movdqa xmm4,xmm0
     541:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     54b:	movdqa xmm2,xmm0
     54f:	movdqu xmm0,XMMWORD PTR [r12+0x230]
     559:	movdqa xmm3,xmm0
     55d:	movdqa xmm0,xmm2
     561:	movdqa xmm1,xmm3
     565:	movq   rax,xmm0
     56a:	add    rax,rax
     56d:	je     0x583
     56f:	shr    rax,0x35
     573:	sub    eax,0x201
     578:	cmp    eax,0x3fc
     57d:	ja     0x10ce
     583:	movq   rax,xmm1
     588:	add    rax,rax
     58b:	je     0x5a1
     58d:	shr    rax,0x35
     591:	sub    eax,0x201
     596:	cmp    eax,0x3fc
     59b:	ja     0x10ce
     5a1:	movq   xmm0,xmm0
     5a5:	movq   xmm1,xmm1
     5a9:	mulsd  xmm0,xmm1
     5ad:	movdqa xmm5,xmm0
     5b1:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     5bb:	movdqa xmm2,xmm0
     5bf:	movdqa xmm0,xmm4
     5c3:	movdqa xmm1,xmm2
     5c7:	movq   rax,xmm0
     5cc:	add    rax,rax
     5cf:	je     0x5e5
     5d1:	shr    rax,0x35
     5d5:	sub    eax,0x201
     5da:	cmp    eax,0x3fc
     5df:	ja     0x10f2
     5e5:	movq   rax,xmm1
     5ea:	add    rax,rax
     5ed:	je     0x603
     5ef:	shr    rax,0x35
     5f3:	sub    eax,0x201
     5f8:	cmp    eax,0x3fc
     5fd:	ja     0x10f2
     603:	movq   xmm0,xmm0
     607:	movq   xmm1,xmm1
     60b:	addsd  xmm0,xmm1
     60f:	movdqa xmm3,xmm0
     613:	movdqa xmm0,xmm3
     617:	movdqa xmm1,xmm5
     61b:	movq   rax,xmm0
     620:	add    rax,rax
     623:	je     0x639
     625:	shr    rax,0x35
     629:	sub    eax,0x201
     62e:	cmp    eax,0x3fc
     633:	ja     0x1116
     639:	movq   rax,xmm1
     63e:	add    rax,rax
     641:	je     0x657
     643:	shr    rax,0x35
     647:	sub    eax,0x201
     64c:	cmp    eax,0x3fc
     651:	ja     0x1116
     657:	movq   xmm0,xmm0
     65b:	movq   xmm1,xmm1
     65f:	addsd  xmm0,xmm1
     663:	movdqa xmm2,xmm0
     667:	movdqa xmm0,xmm2
     66b:	movdqu XMMWORD PTR [r12+0x220],xmm0
     675:	movdqu xmm0,XMMWORD PTR [r12+0x140]
     67f:	movdqa xmm2,xmm0
     683:	movdqu xmm0,XMMWORD PTR [r12+0x240]
     68d:	movdqa xmm3,xmm0
     691:	movdqa xmm0,xmm2
     695:	movdqa xmm1,xmm3
     699:	movq   rax,xmm0
     69e:	add    rax,rax
     6a1:	je     0x6b7
     6a3:	shr    rax,0x35
     6a7:	sub    eax,0x201
     6ac:	cmp    eax,0x3fc
     6b1:	ja     0x113a
     6b7:	movq   rax,xmm1
     6bc:	add    rax,rax
     6bf:	je     0x6d5
     6c1:	shr    rax,0x35
     6c5:	sub    eax,0x201
     6ca:	cmp    eax,0x3fc
     6cf:	ja     0x113a
     6d5:	movq   xmm0,xmm0
     6d9:	movq   xmm1,xmm1
     6dd:	mulsd  xmm0,xmm1
     6e1:	movdqa xmm4,xmm0
     6e5:	movdqa xmm0,xmm4
     6e9:	movdqu XMMWORD PTR [r12+0x230],xmm0
     6f3:	mov    r13,QWORD PTR [r12+0x78]
     6f8:	mov    r14,r13
     6fb:	add    r14,0xc0
     702:	stmxcsr DWORD PTR [rsp+0x114]
     70a:	ldmxcsr DWORD PTR [rsp+0x110]
     712:	mov    r11d,DWORD PTR [rsp+0x114]
     71a:	shr    r11d,1
     71d:	and    r11d,0x10
     721:	or     DWORD PTR [r12+0x314],r11d
     729:	mov    r15,QWORD PTR [r14]
     72c:	mov    r14d,0x0
     732:	mov    QWORD PTR [r12+0x240],r15
     73a:	mov    QWORD PTR [r12+0x248],r14
     742:	movdqu xmm0,XMMWORD PTR [r12+0x220]
     74c:	movdqa xmm2,xmm0
     750:	stmxcsr DWORD PTR [rsp+0x110]
     758:	mov    DWORD PTR [rsp+0x114],0x1f80
     763:	ldmxcsr DWORD PTR [rsp+0x114]
     76b:	movdqa xmm0,xmm2
     76f:	movdqa xmm1,xmm4
     773:	movq   rax,xmm0
     778:	add    rax,rax
     77b:	je     0x791
     77d:	shr    rax,0x35
     781:	sub    eax,0x201
     786:	cmp    eax,0x3fc
     78b:	ja     0x115e
     791:	movq   rax,xmm1
     796:	add    rax,rax
     799:	je     0x7af
     79b:	shr    rax,0x35
     79f:	sub    eax,0x201
     7a4:	cmp    eax,0x3fc
     7a9:	ja     0x115e
     7af:	movq   xmm0,xmm0
     7b3:	movq   xmm1,xmm1
     7b7:	addsd  xmm0,xmm1
     7bb:	movdqa xmm3,xmm0
     7bf:	movdqa xmm0,xmm3
     7c3:	movdqu XMMWORD PTR [r12+0x220],xmm0
     7cd:	movdqu xmm0,XMMWORD PTR [r12+0x150]
     7d7:	movdqa xmm2,xmm0
     7db:	movdqu xmm0,XMMWORD PTR [r12+0x240]
     7e5:	movdqa xmm4,xmm0
     7e9:	movdqa xmm0,xmm2
     7ed:	movdqa xmm1,xmm4
     7f1:	movq   rax,xmm0
     7f6:	add    rax,rax
     7f9:	je     0x80f
     7fb:	shr    rax,0x35
     7ff:	sub    eax,0x201
     804:	cmp    eax,0x3fc
     809:	ja     0x1182
     80f:	movq   rax,xmm1
     814:	add    rax,rax
     817:	je     0x82d
     819:	shr    rax,0x35
     81d:	sub    eax,0x201
     822:	cmp    eax,0x3fc
     827:	ja     0x1182
     82d:	movq   xmm0,xmm0
     831:	movq   xmm1,xmm1
     835:	mulsd  xmm0,xmm1
     839:	movdqa xmm5,xmm0
     83d:	movdqa xmm0,xmm5
     841:	movdqu XMMWORD PTR [r12+0x230],xmm0
     84b:	add    r13,0x100
     852:	stmxcsr DWORD PTR [rsp+0x114]
     85a:	ldmxcsr DWORD PTR [rsp+0x110]
     862:	mov    r11d,DWORD PTR [rsp+0x114]
     86a:	shr    r11d,1
     86d:	and    r11d,0x10
     871:	or     DWORD PTR [r12+0x314],r11d
     879:	mov    r14,QWORD PTR [r13+0x0]
     87d:	mov    r13d,0x0
     883:	mov    QWORD PTR [r12+0x240],r14
     88b:	mov    QWORD PTR [r12+0x248],r13
     893:	stmxcsr DWORD PTR [rsp+0x110]
     89b:	mov    DWORD PTR [rsp+0x114],0x1f80
     8a6:	ldmxcsr DWORD PTR [rsp+0x114]
     8ae:	movdqa xmm0,xmm3
     8b2:	movdqa xmm1,xmm5
     8b6:	movq   rax,xmm0
     8bb:	add    rax,rax
     8be:	je     0x8d4
     8c0:	shr    rax,0x35
     8c4:	sub    eax,0x201
     8c9:	cmp    eax,0x3fc
     8ce:	ja     0x11a6
     8d4:	movq   rax,xmm1
     8d9:	add    rax,rax
     8dc:	je     0x8f2
     8de:	shr    rax,0x35
     8e2:	sub    eax,0x201
     8e7:	cmp    eax,0x3fc
     8ec:	ja     0x11a6
     8f2:	movq   xmm0,xmm0
     8f6:	movq   xmm1,xmm1
     8fa:	addsd  xmm0,xmm1
     8fe:	movdqa xmm2,xmm0
     902:	movdqa xmm0,xmm2
     906:	movdqu XMMWORD PTR [r12+0x220],xmm0
     910:	movdqu xmm0,XMMWORD PTR [r12+0x160]
     91a:	movdqa xmm2,xmm0
     91e:	movdqu xmm0,XMMWORD PTR [r12+0x240]
     928:	movdqa xmm3,xmm0
     92c:	movdqa xmm0,xmm2
     930:	movdqa xmm1,xmm3
     934:	movq   rax,xmm0
     939:	add    rax,rax
     93c:	je     0x952
     93e:	shr    rax,0x35
     942:	sub    eax,0x201
     947:	cmp    eax,0x3fc
     94c:	ja     0x11ca
     952:	movq   rax,xmm1
     957:	add    rax,rax
     95a:	je     0x970
     95c:	shr    rax,0x35
     960:	sub    eax,0x201
     965:	cmp    eax,0x3fc
     96a:	ja     0x11ca
     970:	movq   xmm0,xmm0
     974:	movq   xmm1,xmm1
     978:	mulsd  xmm0,xmm1
     97c:	movdqa xmm4,xmm0
     980:	movdqa xmm0,xmm4
     984:	movdqu XMMWORD PTR [r12+0x230],xmm0
     98e:	mov    r13,QWORD PTR [r12+0x78]
     993:	mov    r14,r13
     996:	add    r14,0x140
     99d:	stmxcsr DWORD PTR [rsp+0x114]
     9a5:	ldmxcsr DWORD PTR [rsp+0x110]
     9ad:	mov    r11d,DWORD PTR [rsp+0x114]
     9b5:	shr    r11d,1
     9b8:	and    r11d,0x10
     9bc:	or     DWORD PTR [r12+0x314],r11d
     9c4:	mov    r15,QWORD PTR [r14]
     9c7:	mov    r14d,0x0
     9cd:	mov    QWORD PTR [r12+0x240],r15
     9d5:	mov    QWORD PTR [r12+0x248],r14
     9dd:	movdqu xmm0,XMMWORD PTR [r12+0x220]
     9e7:	movdqa xmm2,xmm0
     9eb:	movdqu xmm0,XMMWORD PTR [r12+0x230]
     9f5:	movdqa xmm3,xmm0
     9f9:	stmxcsr DWORD PTR [rsp+0x110]
     a01:	mov    DWORD PTR [rsp+0x114],0x1f80
     a0c:	ldmxcsr DWORD PTR [rsp+0x114]
     a14:	movdqa xmm0,xmm2
     a18:	movdqa xmm1,xmm3
     a1c:	movq   rax,xmm0
     a21:	add    rax,rax
     a24:	je     0xa3a
     a26:	shr    rax,0x35
     a2a:	sub    eax,0x201
     a2f:	cmp    eax,0x3fc
     a34:	ja     0x11ee
     a3a:	movq   rax,xmm1
     a3f:	add    rax,rax
     a42:	je     0xa58
     a44:	shr    rax,0x35
     a48:	sub    eax,0x201
     a4d:	cmp    eax,0x3fc
     a52:	ja     0x11ee
     a58:	movq   xmm0,xmm0
     a5c:	movq   xmm1,xmm1
     a60:	addsd  xmm0,xmm1
     a64:	movdqa xmm4,xmm0
     a68:	movdqa xmm0,xmm4
     a6c:	movdqu XMMWORD PTR [r12+0x220],xmm0
     a76:	movdqu xmm0,XMMWORD PTR [r12+0x170]
     a80:	movdqa xmm2,xmm0
     a84:	movdqu xmm0,XMMWORD PTR [r12+0x240]
     a8e:	movdqa xmm3,xmm0
     a92:	movdqa xmm0,xmm2
     a96:	movdqa xmm1,xmm3
     a9a:	movq   rax,xmm0
     a9f:	add    rax,rax
     aa2:	je     0xab8
     aa4:	shr    rax,0x35
     aa8:	sub    eax,0x201
     aad:	cmp    eax,0x3fc
     ab2:	ja     0x1212
     ab8:	movq   rax,xmm1
     abd:	add    rax,rax
     ac0:	je     0xad6
     ac2:	shr    rax,0x35
     ac6:	sub    eax,0x201
     acb:	cmp    eax,0x3fc
     ad0:	ja     0x1212
     ad6:	movq   xmm0,xmm0
     ada:	movq   xmm1,xmm1
     ade:	mulsd  xmm0,xmm1
     ae2:	movdqa xmm5,xmm0
     ae6:	movdqa xmm0,xmm5
     aea:	movdqu XMMWORD PTR [r12+0x230],xmm0
     af4:	add    r13,0x180
     afb:	stmxcsr DWORD PTR [rsp+0x114]
     b03:	ldmxcsr DWORD PTR [rsp+0x110]
     b0b:	mov    r11d,DWORD PTR [rsp+0x114]
     b13:	shr    r11d,1
     b16:	and    r11d,0x10
     b1a:	or     DWORD PTR [r12+0x314],r11d
     b22:	mov    r14,QWORD PTR [r13+0x0]
     b26:	mov    r13d,0x0
     b2c:	mov    QWORD PTR [r12+0x240],r14
     b34:	mov    QWORD PTR [r12+0x248],r13
     b3c:	stmxcsr DWORD PTR [rsp+0x110]
     b44:	mov    DWORD PTR [rsp+0x114],0x1f80
     b4f:	ldmxcsr DWORD PTR [rsp+0x114]
     b57:	movdqa xmm0,xmm4
     b5b:	movdqa xmm1,xmm5
     b5f:	movq   rax,xmm0
     b64:	add    rax,rax
     b67:	je     0xb7d
     b69:	shr    rax,0x35
     b6d:	sub    eax,0x201
     b72:	cmp    eax,0x3fc
     b77:	ja     0x1236
     b7d:	movq   rax,xmm1
     b82:	add    rax,rax
     b85:	je     0xb9b
     b87:	shr    rax,0x35
     b8b:	sub    eax,0x201
     b90:	cmp    eax,0x3fc
     b95:	ja     0x1236
     b9b:	movq   xmm0,xmm0
     b9f:	movq   xmm1,xmm1
     ba3:	addsd  xmm0,xmm1
     ba7:	movdqa xmm2,xmm0
     bab:	movdqa xmm0,xmm2
     baf:	movdqu XMMWORD PTR [r12+0x220],xmm0
     bb9:	movdqu xmm0,XMMWORD PTR [r12+0x180]
     bc3:	movdqa xmm2,xmm0
     bc7:	movdqu xmm0,XMMWORD PTR [r12+0x240]
     bd1:	movdqa xmm3,xmm0
     bd5:	movdqa xmm0,xmm2
     bd9:	movdqa xmm1,xmm3
     bdd:	movq   rax,xmm0
     be2:	add    rax,rax
     be5:	je     0xbfb
     be7:	shr    rax,0x35
     beb:	sub    eax,0x201
     bf0:	cmp    eax,0x3fc
     bf5:	ja     0x125a
     bfb:	movq   rax,xmm1
     c00:	add    rax,rax
     c03:	je     0xc19
     c05:	shr    rax,0x35
     c09:	sub    eax,0x201
     c0e:	cmp    eax,0x3fc
     c13:	ja     0x125a
     c19:	movq   xmm0,xmm0
     c1d:	movq   xmm1,xmm1
     c21:	mulsd  xmm0,xmm1
     c25:	movdqa xmm4,xmm0
     c29:	movdqa xmm0,xmm4
     c2d:	movdqu XMMWORD PTR [r12+0x230],xmm0
     c37:	mov    r13,QWORD PTR [r12+0x78]
     c3c:	add    r13,0x1c0
     c43:	stmxcsr DWORD PTR [rsp+0x114]
     c4b:	ldmxcsr DWORD PTR [rsp+0x110]
     c53:	mov    r11d,DWORD PTR [rsp+0x114]
     c5b:	shr    r11d,1
     c5e:	and    r11d,0x10
     c62:	or     DWORD PTR [r12+0x314],r11d
     c6a:	mov    r14,QWORD PTR [r13+0x0]
     c6e:	mov    r13d,0x0
     c74:	mov    QWORD PTR [r12+0x240],r14
     c7c:	mov    QWORD PTR [r12+0x248],r13
     c84:	movdqu xmm0,XMMWORD PTR [r12+0x220]
     c8e:	movdqa xmm2,xmm0
     c92:	movdqu xmm0,XMMWORD PTR [r12+0x230]
     c9c:	movdqa xmm3,xmm0
     ca0:	stmxcsr DWORD PTR [rsp+0x110]
     ca8:	mov    DWORD PTR [rsp+0x114],0x1f80
     cb3:	ldmxcsr DWORD PTR [rsp+0x114]
     cbb:	movdqa xmm0,xmm2
     cbf:	movdqa xmm1,xmm3
     cc3:	movq   rax,xmm0
     cc8:	add    rax,rax
     ccb:	je     0xce1
     ccd:	shr    rax,0x35
     cd1:	sub    eax,0x201
     cd6:	cmp    eax,0x3fc
     cdb:	ja     0x127e
     ce1:	movq   rax,xmm1
     ce6:	add    rax,rax
     ce9:	je     0xcff
     ceb:	shr    rax,0x35
     cef:	sub    eax,0x201
     cf4:	cmp    eax,0x3fc
     cf9:	ja     0x127e
     cff:	movq   xmm0,xmm0
     d03:	movq   xmm1,xmm1
     d07:	addsd  xmm0,xmm1
     d0b:	movdqa xmm4,xmm0
     d0f:	movdqu xmm0,XMMWORD PTR [r12+0x210]
     d19:	movdqa xmm2,xmm0
     d1d:	movdqu xmm0,XMMWORD PTR [r12+0x240]
     d27:	movdqa xmm3,xmm0
     d2b:	movdqa xmm0,xmm2
     d2f:	movdqa xmm1,xmm3
     d33:	movq   rax,xmm0
     d38:	add    rax,rax
     d3b:	je     0xd51
     d3d:	shr    rax,0x35
     d41:	sub    eax,0x201
     d46:	cmp    eax,0x3fc
     d4b:	ja     0x12a2
     d51:	movq   rax,xmm1
     d56:	add    rax,rax
     d59:	je     0xd6f
     d5b:	shr    rax,0x35
     d5f:	sub    eax,0x201
     d64:	cmp    eax,0x3fc
     d69:	ja     0x12a2
     d6f:	movq   xmm0,xmm0
     d73:	movq   xmm1,xmm1
     d77:	mulsd  xmm0,xmm1
     d7b:	movdqa xmm5,xmm0
     d7f:	movdqa xmm0,xmm5
     d83:	movdqu XMMWORD PTR [r12+0x230],xmm0
     d8d:	movdqa xmm0,xmm4
     d91:	movdqa xmm1,xmm5
     d95:	movq   rax,xmm0
     d9a:	add    rax,rax
     d9d:	je     0xdb3
     d9f:	shr    rax,0x35
     da3:	sub    eax,0x201
     da8:	cmp    eax,0x3fc
     dad:	ja     0x12c6
     db3:	movq   rax,xmm1
     db8:	add    rax,rax
     dbb:	je     0xdd1
     dbd:	shr    rax,0x35
     dc1:	sub    eax,0x201
     dc6:	cmp    eax,0x3fc
     dcb:	ja     0x12c6
     dd1:	movq   xmm0,xmm0
     dd5:	movq   xmm1,xmm1
     dd9:	addsd  xmm0,xmm1
     ddd:	movdqa xmm2,xmm0
     de1:	movdqa xmm0,xmm2
     de5:	movdqu XMMWORD PTR [r12+0x220],xmm0
     def:	mov    r13,QWORD PTR [r12+0x70]
     df4:	mov    r14,QWORD PTR [r12+0x68]
     df9:	mov    rcx,r13
     dfc:	add    r14,rcx
     dff:	mov    r15,QWORD PTR [r12+0x220]
     e07:	stmxcsr DWORD PTR [rsp+0x114]
     e0f:	ldmxcsr DWORD PTR [rsp+0x110]
     e17:	mov    r11d,DWORD PTR [rsp+0x114]
     e1f:	shr    r11d,1
     e22:	and    r11d,0x10
     e26:	or     DWORD PTR [r12+0x314],r11d
     e2e:	mov    QWORD PTR [r14],r15
     e31:	mov    r14d,0x0
     e37:	mov    DWORD PTR [r12+0x32c],r14d
     e3f:	add    r13,0x8
     e43:	mov    QWORD PTR [r12+0x70],r13
     e48:	sub    r13,0x40
     e4c:	mov    rcx,QWORD PTR [r12+0x380]
     e54:	jrcxz  0xe5b
     e56:	jmp    0x1e30
     e5b:	je     0xe6d
     e61:	pushf
     e62:	pop    r11
     e64:	mov    QWORD PTR [rsp],r11
     e68:	jmp    0x447
     e6d:	mov    r13,QWORD PTR [r12+0x60]
     e72:	add    r13,0x1
     e76:	mov    QWORD PTR [r12+0x60],r13
     e7b:	mov    r14,QWORD PTR [r12+0x68]
     e80:	add    r14,0x40
     e84:	mov    QWORD PTR [r12+0x68],r14
     e89:	sub    r13,0x8
     e8d:	mov    rcx,QWORD PTR [r12+0x380]
     e95:	jrcxz  0xe9c
     e97:	jmp    0x1ec2
     e9c:	je     0xeae
     ea2:	pushf
     ea3:	pop    r11
     ea5:	mov    QWORD PTR [rsp],r11
     ea9:	jmp    0x323
     eae:	mov    r13d,DWORD PTR [r12+0x58]
     eb3:	add    r13d,0x1
     eb7:	mov    QWORD PTR [r12+0x58],r13
     ebc:	sub    r13d,0x1f4
     ec3:	mov    rcx,QWORD PTR [r12+0x380]
     ecb:	jrcxz  0xed2
     ecd:	jmp    0x1f54
     ed2:	pushf
     ed3:	pop    r11
     ed5:	mov    QWORD PTR [rsp],r11
     ed9:	jne    0x2fd
     edf:	jmp    0xee4
     ee4:	mov    r13d,0x420000
     eea:	mov    QWORD PTR [r12+0x40],r13
     eef:	mov    r13d,0x0
     ef5:	mov    QWORD PTR [r12+0x48],r13
     efa:	mov    r13d,0x4201b8
     f00:	mov    r14,QWORD PTR [r13+0x0]
     f04:	mov    r13d,0x0
     f0a:	mov    QWORD PTR [r12+0x110],r14
     f12:	mov    QWORD PTR [r12+0x118],r13
     f1a:	jmp    0xf1f
     f1f:	mov    r13,QWORD PTR [r12+0x48]
     f24:	mov    r14,QWORD PTR [r12+0x50]
     f29:	mov    rcx,r13
     f2c:	add    r14,rcx
     f2f:	mov    r15,QWORD PTR [r14]
     f32:	mov    r14d,0x0
     f38:	mov    QWORD PTR [r12+0x120],r15
     f40:	mov    QWORD PTR [r12+0x128],r14
     f48:	add    r13,0x8
     f4c:	mov    QWORD PTR [r12+0x48],r13
     f51:	sub    r13,0x200
     f58:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     f62:	movdqa xmm2,xmm0
     f66:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     f70:	movdqa xmm3,xmm0
     f74:	pushf
     f75:	pop    r11
     f77:	mov    QWORD PTR [rsp],r11
     f7b:	stmxcsr DWORD PTR [rsp+0x110]
     f83:	mov    DWORD PTR [rsp+0x114],0x1f80
     f8e:	ldmxcsr DWORD PTR [rsp+0x114]
     f96:	movdqa xmm0,xmm2
     f9a:	movdqa xmm1,xmm3
     f9e:	movq   rax,xmm0
     fa3:	add    rax,rax
     fa6:	je     0xfbc
     fa8:	shr    rax,0x35
     fac:	sub    eax,0x201
     fb1:	cmp    eax,0x3fc
     fb6:	ja     0x12ea
     fbc:	movq   rax,xmm1
     fc1:	add    rax,rax
     fc4:	je     0xfda
     fc6:	shr    rax,0x35
     fca:	sub    eax,0x201
     fcf:	cmp    eax,0x3fc
     fd4:	ja     0x12ea
     fda:	movq   xmm0,xmm0
     fde:	movq   xmm1,xmm1
     fe2:	addsd  xmm0,xmm1
     fe6:	movdqa xmm4,xmm0
     fea:	movdqa xmm0,xmm4
     fee:	movdqu XMMWORD PTR [r12+0x110],xmm0
     ff8:	stmxcsr DWORD PTR [rsp+0x114]
    1000:	ldmxcsr DWORD PTR [rsp+0x110]
    1008:	mov    r11d,DWORD PTR [rsp+0x114]
    1010:	shr    r11d,1
    1013:	and    r11d,0x10
    1017:	or     DWORD PTR [r12+0x314],r11d
    101f:	mov    rcx,QWORD PTR [r12+0x380]
    1027:	jrcxz  0x102e
    1029:	jmp    0x1fe6
    102e:	push   QWORD PTR [rsp]
    1031:	popf
    1032:	jne    0xf1f
    1038:	jmp    0x103d
    103d:	mov    r13,QWORD PTR [r12+0x40]
    1042:	add    r13,0x1b8
    1049:	mov    r14,QWORD PTR [r12+0x110]
    1051:	mov    QWORD PTR [r13+0x0],r14
    1055:	mov    r13d,0x0
    105b:	mov    DWORD PTR [r12+0x32c],r13d
    1063:	mov    rcx,QWORD PTR [r12+0x380]
    106b:	jrcxz  0x1072
    106d:	jmp    0x2070
    1072:	mov    r13,QWORD PTR [r12+0xf0]
    107a:	mov    QWORD PTR [r12+0x100],r13
    1082:	mov    r11,QWORD PTR [rsp]
    1086:	mov    QWORD PTR [r12+0x398],r11
    108e:	mov    rdi,QWORD PTR [r12+0x100]
    1096:	add    rsp,0x150
    109d:	movabs r11,0x557f026e80a0
    10a7:	jmp    r11
    10aa:	movdqa xmm0,xmm2
    10ae:	movdqa xmm1,xmm3
    10b2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    10bb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    10c4:	call   0x1310
    10c9:	jmp    0x53d
    10ce:	movdqa xmm0,xmm2
    10d2:	movdqa xmm1,xmm3
    10d6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    10df:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    10e8:	call   0x1490
    10ed:	jmp    0x5ad
    10f2:	movdqa xmm0,xmm4
    10f6:	movdqa xmm1,xmm2
    10fa:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    1103:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    110c:	call   0x1620
    1111:	jmp    0x60f
    1116:	movdqa xmm0,xmm3
    111a:	movdqa xmm1,xmm5
    111e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    1127:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    1130:	call   0x17b0
    1135:	jmp    0x663
    113a:	movdqa xmm0,xmm2
    113e:	movdqa xmm1,xmm3
    1142:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    114b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    1154:	call   0x1310
    1159:	jmp    0x6e1
    115e:	movdqa xmm0,xmm2
    1162:	movdqa xmm1,xmm4
    1166:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    116f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    1178:	call   0x1930
    117d:	jmp    0x7bb
    1182:	movdqa xmm0,xmm2
    1186:	movdqa xmm1,xmm4
    118a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    1193:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    119c:	call   0x1490
    11a1:	jmp    0x839
    11a6:	movdqa xmm0,xmm3
    11aa:	movdqa xmm1,xmm5
    11ae:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    11b7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    11c0:	call   0x17b0
    11c5:	jmp    0x8fe
    11ca:	movdqa xmm0,xmm2
    11ce:	movdqa xmm1,xmm3
    11d2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    11db:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    11e4:	call   0x1310
    11e9:	jmp    0x97c
    11ee:	movdqa xmm0,xmm2
    11f2:	movdqa xmm1,xmm3
    11f6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    11ff:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    1208:	call   0x1ab0
    120d:	jmp    0xa64
    1212:	movdqa xmm0,xmm2
    1216:	movdqa xmm1,xmm3
    121a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    1223:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    122c:	call   0x1490
    1231:	jmp    0xae2
    1236:	movdqa xmm0,xmm4
    123a:	movdqa xmm1,xmm5
    123e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    1247:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    1250:	call   0x1c30
    1255:	jmp    0xba7
    125a:	movdqa xmm0,xmm2
    125e:	movdqa xmm1,xmm3
    1262:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    126b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    1274:	call   0x1310
    1279:	jmp    0xc25
    127e:	movdqa xmm0,xmm2
    1282:	movdqa xmm1,xmm3
    1286:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    128f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    1298:	call   0x1ab0
    129d:	jmp    0xd0b
    12a2:	movdqa xmm0,xmm2
    12a6:	movdqa xmm1,xmm3
    12aa:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    12b3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    12bc:	call   0x1490
    12c1:	jmp    0xd7b
    12c6:	movdqa xmm0,xmm4
    12ca:	movdqa xmm1,xmm5
    12ce:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    12d7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    12e0:	call   0x1c30
    12e5:	jmp    0xddd
    12ea:	movdqa xmm0,xmm2
    12ee:	movdqa xmm1,xmm3
    12f2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    12fb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    1304:	call   0x1ab0
    1309:	jmp    0xfe6
    130e:	xchg   ax,ax
    1310:	sub    rsp,0x8
    1314:	stmxcsr DWORD PTR [rsp+0x124]
    131c:	ldmxcsr DWORD PTR [rsp+0x120]
    1324:	mov    r11d,DWORD PTR [rsp+0x124]
    132c:	shr    r11d,1
    132f:	and    r11d,0x10
    1333:	or     DWORD PTR [r12+0x314],r11d
    133b:	mov    QWORD PTR [r12+0x378],0x3
    1347:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    134d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    1353:	push   rdx
    1354:	push   rsi
    1355:	push   r10
    1357:	push   r11
    1359:	mov    rdx,QWORD PTR [rsp+0x30]
    135e:	mov    r10d,edx
    1361:	and    r10d,0xc0
    1368:	shl    r10d,0x18
    136c:	mov    r11d,edx
    136f:	and    r11d,0x1
    1373:	shl    r11d,0x1d
    1377:	or     r10d,r11d
    137a:	mov    r11d,edx
    137d:	and    r11d,0x800
    1384:	shl    r11d,0x11
    1388:	or     r10d,r11d
    138b:	btc    r10,0x1d
    1390:	mov    r11d,0xf0000000
    1396:	and    r11,r10
    1399:	movabs rsi,0xffffffff0fffffff
    13a3:	and    rbx,rsi
    13a6:	or     rbx,r11
    13a9:	pop    r11
    13ab:	pop    r10
    13ad:	pop    rsi
    13ae:	pop    rdx
    13af:	mov    QWORD PTR [r12+0x108],rbx
    13b7:	stmxcsr DWORD PTR [r12-0x28]
    13bd:	ldmxcsr DWORD PTR [r12-0x38]
    13c3:	lea    rdi,[rsp+0x110]
    13cb:	lea    rsi,[rsp+0xf0]
    13d3:	lea    rdx,[rsp+0x100]
    13db:	mov    ecx,0xe
    13e0:	mov    r8d,0x0
    13e6:	lea    r9,[r12+0x314]
    13ee:	movabs r11,0x557f025531b0
    13f8:	call   r11
    13fb:	ldmxcsr DWORD PTR [r12-0x28]
    1401:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    1407:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    140d:	mov    rbx,QWORD PTR [r12+0x108]
    1415:	mov    QWORD PTR [r12+0x378],0x2
    1421:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    142a:	pushf
    142b:	pop    rdx
    142c:	and    rdx,0xfffffffffffff73e
    1433:	mov    rax,rbx
    1436:	shr    rax,0x18
    143a:	and    eax,0xc0
    143f:	or     rdx,rax
    1442:	mov    rax,rbx
    1445:	shr    rax,0x1d
    1449:	and    eax,0x1
    144c:	xor    eax,0x1
    144f:	or     rdx,rax
    1452:	mov    rax,rbx
    1455:	shr    rax,0x11
    1459:	and    eax,0x800
    145e:	or     rdx,rax
    1461:	mov    QWORD PTR [rsp+0x10],rdx
    1466:	stmxcsr DWORD PTR [rsp+0x120]
    146e:	mov    DWORD PTR [rsp+0x124],0x1f80
    1479:	ldmxcsr DWORD PTR [rsp+0x124]
    1481:	add    rsp,0x8
    1485:	ret
    1486:	data16 nop WORD PTR [rax+rax*1+0x0]
    1490:	sub    rsp,0x8
    1494:	stmxcsr DWORD PTR [rsp+0x124]
    149c:	ldmxcsr DWORD PTR [rsp+0x120]
    14a4:	mov    r11d,DWORD PTR [rsp+0x124]
    14ac:	shr    r11d,1
    14af:	and    r11d,0x10
    14b3:	or     DWORD PTR [r12+0x314],r11d
    14bb:	mov    QWORD PTR [r12+0x378],0x3
    14c7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    14cd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    14d3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    14d9:	push   rdx
    14da:	push   rsi
    14db:	push   r10
    14dd:	push   r11
    14df:	mov    rdx,QWORD PTR [rsp+0x30]
    14e4:	mov    r10d,edx
    14e7:	and    r10d,0xc0
    14ee:	shl    r10d,0x18
    14f2:	mov    r11d,edx
    14f5:	and    r11d,0x1
    14f9:	shl    r11d,0x1d
    14fd:	or     r10d,r11d
    1500:	mov    r11d,edx
    1503:	and    r11d,0x800
    150a:	shl    r11d,0x11
    150e:	or     r10d,r11d
    1511:	btc    r10,0x1d
    1516:	mov    r11d,0xf0000000
    151c:	and    r11,r10
    151f:	movabs rsi,0xffffffff0fffffff
    1529:	and    rbx,rsi
    152c:	or     rbx,r11
    152f:	pop    r11
    1531:	pop    r10
    1533:	pop    rsi
    1534:	pop    rdx
    1535:	mov    QWORD PTR [r12+0x108],rbx
    153d:	stmxcsr DWORD PTR [r12-0x28]
    1543:	ldmxcsr DWORD PTR [r12-0x38]
    1549:	lea    rdi,[rsp+0x110]
    1551:	lea    rsi,[rsp+0xf0]
    1559:	lea    rdx,[rsp+0x100]
    1561:	mov    ecx,0xe
    1566:	mov    r8d,0x0
    156c:	lea    r9,[r12+0x314]
    1574:	movabs r11,0x557f025531b0
    157e:	call   r11
    1581:	ldmxcsr DWORD PTR [r12-0x28]
    1587:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    158d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    1593:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    1599:	mov    rbx,QWORD PTR [r12+0x108]
    15a1:	mov    QWORD PTR [r12+0x378],0x2
    15ad:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    15b6:	pushf
    15b7:	pop    rdx
    15b8:	and    rdx,0xfffffffffffff73e
    15bf:	mov    rax,rbx
    15c2:	shr    rax,0x18
    15c6:	and    eax,0xc0
    15cb:	or     rdx,rax
    15ce:	mov    rax,rbx
    15d1:	shr    rax,0x1d
    15d5:	and    eax,0x1
    15d8:	xor    eax,0x1
    15db:	or     rdx,rax
    15de:	mov    rax,rbx
    15e1:	shr    rax,0x11
    15e5:	and    eax,0x800
    15ea:	or     rdx,rax
    15ed:	mov    QWORD PTR [rsp+0x10],rdx
    15f2:	stmxcsr DWORD PTR [rsp+0x120]
    15fa:	mov    DWORD PTR [rsp+0x124],0x1f80
    1605:	ldmxcsr DWORD PTR [rsp+0x124]
    160d:	add    rsp,0x8
    1611:	ret
    1612:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    1620:	sub    rsp,0x8
    1624:	stmxcsr DWORD PTR [rsp+0x124]
    162c:	ldmxcsr DWORD PTR [rsp+0x120]
    1634:	mov    r11d,DWORD PTR [rsp+0x124]
    163c:	shr    r11d,1
    163f:	and    r11d,0x10
    1643:	or     DWORD PTR [r12+0x314],r11d
    164b:	mov    QWORD PTR [r12+0x378],0x3
    1657:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    165d:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    1663:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    1669:	push   rdx
    166a:	push   rsi
    166b:	push   r10
    166d:	push   r11
    166f:	mov    rdx,QWORD PTR [rsp+0x30]
    1674:	mov    r10d,edx
    1677:	and    r10d,0xc0
    167e:	shl    r10d,0x18
    1682:	mov    r11d,edx
    1685:	and    r11d,0x1
    1689:	shl    r11d,0x1d
    168d:	or     r10d,r11d
    1690:	mov    r11d,edx
    1693:	and    r11d,0x800
    169a:	shl    r11d,0x11
    169e:	or     r10d,r11d
    16a1:	btc    r10,0x1d
    16a6:	mov    r11d,0xf0000000
    16ac:	and    r11,r10
    16af:	movabs rsi,0xffffffff0fffffff
    16b9:	and    rbx,rsi
    16bc:	or     rbx,r11
    16bf:	pop    r11
    16c1:	pop    r10
    16c3:	pop    rsi
    16c4:	pop    rdx
    16c5:	mov    QWORD PTR [r12+0x108],rbx
    16cd:	stmxcsr DWORD PTR [r12-0x28]
    16d3:	ldmxcsr DWORD PTR [r12-0x38]
    16d9:	lea    rdi,[rsp+0x110]
    16e1:	lea    rsi,[rsp+0xf0]
    16e9:	lea    rdx,[rsp+0x100]
    16f1:	mov    ecx,0xc
    16f6:	mov    r8d,0x0
    16fc:	lea    r9,[r12+0x314]
    1704:	movabs r11,0x557f025531b0
    170e:	call   r11
    1711:	ldmxcsr DWORD PTR [r12-0x28]
    1717:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    171d:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    1723:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    1729:	mov    rbx,QWORD PTR [r12+0x108]
    1731:	mov    QWORD PTR [r12+0x378],0x2
    173d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    1746:	pushf
    1747:	pop    rdx
    1748:	and    rdx,0xfffffffffffff73e
    174f:	mov    rax,rbx
    1752:	shr    rax,0x18
    1756:	and    eax,0xc0
    175b:	or     rdx,rax
    175e:	mov    rax,rbx
    1761:	shr    rax,0x1d
    1765:	and    eax,0x1
    1768:	xor    eax,0x1
    176b:	or     rdx,rax
    176e:	mov    rax,rbx
    1771:	shr    rax,0x11
    1775:	and    eax,0x800
    177a:	or     rdx,rax
    177d:	mov    QWORD PTR [rsp+0x10],rdx
    1782:	stmxcsr DWORD PTR [rsp+0x120]
    178a:	mov    DWORD PTR [rsp+0x124],0x1f80
    1795:	ldmxcsr DWORD PTR [rsp+0x124]
    179d:	add    rsp,0x8
    17a1:	ret
    17a2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    17b0:	sub    rsp,0x8
    17b4:	stmxcsr DWORD PTR [rsp+0x124]
    17bc:	ldmxcsr DWORD PTR [rsp+0x120]
    17c4:	mov    r11d,DWORD PTR [rsp+0x124]
    17cc:	shr    r11d,1
    17cf:	and    r11d,0x10
    17d3:	or     DWORD PTR [r12+0x314],r11d
    17db:	mov    QWORD PTR [r12+0x378],0x3
    17e7:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    17ed:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    17f3:	push   rdx
    17f4:	push   rsi
    17f5:	push   r10
    17f7:	push   r11
    17f9:	mov    rdx,QWORD PTR [rsp+0x30]
    17fe:	mov    r10d,edx
    1801:	and    r10d,0xc0
    1808:	shl    r10d,0x18
    180c:	mov    r11d,edx
    180f:	and    r11d,0x1
    1813:	shl    r11d,0x1d
    1817:	or     r10d,r11d
    181a:	mov    r11d,edx
    181d:	and    r11d,0x800
    1824:	shl    r11d,0x11
    1828:	or     r10d,r11d
    182b:	btc    r10,0x1d
    1830:	mov    r11d,0xf0000000
    1836:	and    r11,r10
    1839:	movabs rsi,0xffffffff0fffffff
    1843:	and    rbx,rsi
    1846:	or     rbx,r11
    1849:	pop    r11
    184b:	pop    r10
    184d:	pop    rsi
    184e:	pop    rdx
    184f:	mov    QWORD PTR [r12+0x108],rbx
    1857:	stmxcsr DWORD PTR [r12-0x28]
    185d:	ldmxcsr DWORD PTR [r12-0x38]
    1863:	lea    rdi,[rsp+0x110]
    186b:	lea    rsi,[rsp+0xf0]
    1873:	lea    rdx,[rsp+0x100]
    187b:	mov    ecx,0xc
    1880:	mov    r8d,0x0
    1886:	lea    r9,[r12+0x314]
    188e:	movabs r11,0x557f025531b0
    1898:	call   r11
    189b:	ldmxcsr DWORD PTR [r12-0x28]
    18a1:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    18a7:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    18ad:	mov    rbx,QWORD PTR [r12+0x108]
    18b5:	mov    QWORD PTR [r12+0x378],0x2
    18c1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    18ca:	pushf
    18cb:	pop    rdx
    18cc:	and    rdx,0xfffffffffffff73e
    18d3:	mov    rax,rbx
    18d6:	shr    rax,0x18
    18da:	and    eax,0xc0
    18df:	or     rdx,rax
    18e2:	mov    rax,rbx
    18e5:	shr    rax,0x1d
    18e9:	and    eax,0x1
    18ec:	xor    eax,0x1
    18ef:	or     rdx,rax
    18f2:	mov    rax,rbx
    18f5:	shr    rax,0x11
    18f9:	and    eax,0x800
    18fe:	or     rdx,rax
    1901:	mov    QWORD PTR [rsp+0x10],rdx
    1906:	stmxcsr DWORD PTR [rsp+0x120]
    190e:	mov    DWORD PTR [rsp+0x124],0x1f80
    1919:	ldmxcsr DWORD PTR [rsp+0x124]
    1921:	add    rsp,0x8
    1925:	ret
    1926:	data16 nop WORD PTR [rax+rax*1+0x0]
    1930:	sub    rsp,0x8
    1934:	stmxcsr DWORD PTR [rsp+0x124]
    193c:	ldmxcsr DWORD PTR [rsp+0x120]
    1944:	mov    r11d,DWORD PTR [rsp+0x124]
    194c:	shr    r11d,1
    194f:	and    r11d,0x10
    1953:	or     DWORD PTR [r12+0x314],r11d
    195b:	mov    QWORD PTR [r12+0x378],0x3
    1967:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    196d:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    1973:	push   rdx
    1974:	push   rsi
    1975:	push   r10
    1977:	push   r11
    1979:	mov    rdx,QWORD PTR [rsp+0x30]
    197e:	mov    r10d,edx
    1981:	and    r10d,0xc0
    1988:	shl    r10d,0x18
    198c:	mov    r11d,edx
    198f:	and    r11d,0x1
    1993:	shl    r11d,0x1d
    1997:	or     r10d,r11d
    199a:	mov    r11d,edx
    199d:	and    r11d,0x800
    19a4:	shl    r11d,0x11
    19a8:	or     r10d,r11d
    19ab:	btc    r10,0x1d
    19b0:	mov    r11d,0xf0000000
    19b6:	and    r11,r10
    19b9:	movabs rsi,0xffffffff0fffffff
    19c3:	and    rbx,rsi
    19c6:	or     rbx,r11
    19c9:	pop    r11
    19cb:	pop    r10
    19cd:	pop    rsi
    19ce:	pop    rdx
    19cf:	mov    QWORD PTR [r12+0x108],rbx
    19d7:	stmxcsr DWORD PTR [r12-0x28]
    19dd:	ldmxcsr DWORD PTR [r12-0x38]
    19e3:	lea    rdi,[rsp+0x110]
    19eb:	lea    rsi,[rsp+0xf0]
    19f3:	lea    rdx,[rsp+0x100]
    19fb:	mov    ecx,0xc
    1a00:	mov    r8d,0x0
    1a06:	lea    r9,[r12+0x314]
    1a0e:	movabs r11,0x557f025531b0
    1a18:	call   r11
    1a1b:	ldmxcsr DWORD PTR [r12-0x28]
    1a21:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    1a27:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    1a2d:	mov    rbx,QWORD PTR [r12+0x108]
    1a35:	mov    QWORD PTR [r12+0x378],0x2
    1a41:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    1a4a:	pushf
    1a4b:	pop    rdx
    1a4c:	and    rdx,0xfffffffffffff73e
    1a53:	mov    rax,rbx
    1a56:	shr    rax,0x18
    1a5a:	and    eax,0xc0
    1a5f:	or     rdx,rax
    1a62:	mov    rax,rbx
    1a65:	shr    rax,0x1d
    1a69:	and    eax,0x1
    1a6c:	xor    eax,0x1
    1a6f:	or     rdx,rax
    1a72:	mov    rax,rbx
    1a75:	shr    rax,0x11
    1a79:	and    eax,0x800
    1a7e:	or     rdx,rax
    1a81:	mov    QWORD PTR [rsp+0x10],rdx
    1a86:	stmxcsr DWORD PTR [rsp+0x120]
    1a8e:	mov    DWORD PTR [rsp+0x124],0x1f80
    1a99:	ldmxcsr DWORD PTR [rsp+0x124]
    1aa1:	add    rsp,0x8
    1aa5:	ret
    1aa6:	data16 nop WORD PTR [rax+rax*1+0x0]
    1ab0:	sub    rsp,0x8
    1ab4:	stmxcsr DWORD PTR [rsp+0x124]
    1abc:	ldmxcsr DWORD PTR [rsp+0x120]
    1ac4:	mov    r11d,DWORD PTR [rsp+0x124]
    1acc:	shr    r11d,1
    1acf:	and    r11d,0x10
    1ad3:	or     DWORD PTR [r12+0x314],r11d
    1adb:	mov    QWORD PTR [r12+0x378],0x3
    1ae7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    1aed:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    1af3:	push   rdx
    1af4:	push   rsi
    1af5:	push   r10
    1af7:	push   r11
    1af9:	mov    rdx,QWORD PTR [rsp+0x30]
    1afe:	mov    r10d,edx
    1b01:	and    r10d,0xc0
    1b08:	shl    r10d,0x18
    1b0c:	mov    r11d,edx
    1b0f:	and    r11d,0x1
    1b13:	shl    r11d,0x1d
    1b17:	or     r10d,r11d
    1b1a:	mov    r11d,edx
    1b1d:	and    r11d,0x800
    1b24:	shl    r11d,0x11
    1b28:	or     r10d,r11d
    1b2b:	btc    r10,0x1d
    1b30:	mov    r11d,0xf0000000
    1b36:	and    r11,r10
    1b39:	movabs rsi,0xffffffff0fffffff
    1b43:	and    rbx,rsi
    1b46:	or     rbx,r11
    1b49:	pop    r11
    1b4b:	pop    r10
    1b4d:	pop    rsi
    1b4e:	pop    rdx
    1b4f:	mov    QWORD PTR [r12+0x108],rbx
    1b57:	stmxcsr DWORD PTR [r12-0x28]
    1b5d:	ldmxcsr DWORD PTR [r12-0x38]
    1b63:	lea    rdi,[rsp+0x110]
    1b6b:	lea    rsi,[rsp+0xf0]
    1b73:	lea    rdx,[rsp+0x100]
    1b7b:	mov    ecx,0xc
    1b80:	mov    r8d,0x0
    1b86:	lea    r9,[r12+0x314]
    1b8e:	movabs r11,0x557f025531b0
    1b98:	call   r11
    1b9b:	ldmxcsr DWORD PTR [r12-0x28]
    1ba1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    1ba7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    1bad:	mov    rbx,QWORD PTR [r12+0x108]
    1bb5:	mov    QWORD PTR [r12+0x378],0x2
    1bc1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    1bca:	pushf
    1bcb:	pop    rdx
    1bcc:	and    rdx,0xfffffffffffff73e
    1bd3:	mov    rax,rbx
    1bd6:	shr    rax,0x18
    1bda:	and    eax,0xc0
    1bdf:	or     rdx,rax
    1be2:	mov    rax,rbx
    1be5:	shr    rax,0x1d
    1be9:	and    eax,0x1
    1bec:	xor    eax,0x1
    1bef:	or     rdx,rax
    1bf2:	mov    rax,rbx
    1bf5:	shr    rax,0x11
    1bf9:	and    eax,0x800
    1bfe:	or     rdx,rax
    1c01:	mov    QWORD PTR [rsp+0x10],rdx
    1c06:	stmxcsr DWORD PTR [rsp+0x120]
    1c0e:	mov    DWORD PTR [rsp+0x124],0x1f80
    1c19:	ldmxcsr DWORD PTR [rsp+0x124]
    1c21:	add    rsp,0x8
    1c25:	ret
    1c26:	data16 nop WORD PTR [rax+rax*1+0x0]
    1c30:	sub    rsp,0x8
    1c34:	stmxcsr DWORD PTR [rsp+0x124]
    1c3c:	ldmxcsr DWORD PTR [rsp+0x120]
    1c44:	mov    r11d,DWORD PTR [rsp+0x124]
    1c4c:	shr    r11d,1
    1c4f:	and    r11d,0x10
    1c53:	or     DWORD PTR [r12+0x314],r11d
    1c5b:	mov    QWORD PTR [r12+0x378],0x3
    1c67:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    1c6d:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    1c73:	push   rdx
    1c74:	push   rsi
    1c75:	push   r10
    1c77:	push   r11
    1c79:	mov    rdx,QWORD PTR [rsp+0x30]
    1c7e:	mov    r10d,edx
    1c81:	and    r10d,0xc0
    1c88:	shl    r10d,0x18
    1c8c:	mov    r11d,edx
    1c8f:	and    r11d,0x1
    1c93:	shl    r11d,0x1d
    1c97:	or     r10d,r11d
    1c9a:	mov    r11d,edx
    1c9d:	and    r11d,0x800
    1ca4:	shl    r11d,0x11
    1ca8:	or     r10d,r11d
    1cab:	btc    r10,0x1d
    1cb0:	mov    r11d,0xf0000000
    1cb6:	and    r11,r10
    1cb9:	movabs rsi,0xffffffff0fffffff
    1cc3:	and    rbx,rsi
    1cc6:	or     rbx,r11
    1cc9:	pop    r11
    1ccb:	pop    r10
    1ccd:	pop    rsi
    1cce:	pop    rdx
    1ccf:	mov    QWORD PTR [r12+0x108],rbx
    1cd7:	stmxcsr DWORD PTR [r12-0x28]
    1cdd:	ldmxcsr DWORD PTR [r12-0x38]
    1ce3:	lea    rdi,[rsp+0x110]
    1ceb:	lea    rsi,[rsp+0xf0]
    1cf3:	lea    rdx,[rsp+0x100]
    1cfb:	mov    ecx,0xc
    1d00:	mov    r8d,0x0
    1d06:	lea    r9,[r12+0x314]
    1d0e:	movabs r11,0x557f025531b0
    1d18:	call   r11
    1d1b:	ldmxcsr DWORD PTR [r12-0x28]
    1d21:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    1d27:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    1d2d:	mov    rbx,QWORD PTR [r12+0x108]
    1d35:	mov    QWORD PTR [r12+0x378],0x2
    1d41:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    1d4a:	pushf
    1d4b:	pop    rdx
    1d4c:	and    rdx,0xfffffffffffff73e
    1d53:	mov    rax,rbx
    1d56:	shr    rax,0x18
    1d5a:	and    eax,0xc0
    1d5f:	or     rdx,rax
    1d62:	mov    rax,rbx
    1d65:	shr    rax,0x1d
    1d69:	and    eax,0x1
    1d6c:	xor    eax,0x1
    1d6f:	or     rdx,rax
    1d72:	mov    rax,rbx
    1d75:	shr    rax,0x11
    1d79:	and    eax,0x800
    1d7e:	or     rdx,rax
    1d81:	mov    QWORD PTR [rsp+0x10],rdx
    1d86:	stmxcsr DWORD PTR [rsp+0x120]
    1d8e:	mov    DWORD PTR [rsp+0x124],0x1f80
    1d99:	ldmxcsr DWORD PTR [rsp+0x124]
    1da1:	add    rsp,0x8
    1da5:	ret
    1da6:	mov    eax,0x410070
    1dab:	mov    QWORD PTR [r12+0x100],rax
    1db3:	push   rdx
    1db4:	push   rsi
    1db5:	push   r10
    1db7:	push   r11
    1db9:	mov    rdx,QWORD PTR [rsp+0x20]
    1dbe:	mov    r10d,edx
    1dc1:	and    r10d,0xc0
    1dc8:	shl    r10d,0x18
    1dcc:	mov    r11d,edx
    1dcf:	and    r11d,0x1
    1dd3:	shl    r11d,0x1d
    1dd7:	or     r10d,r11d
    1dda:	mov    r11d,edx
    1ddd:	and    r11d,0x800
    1de4:	shl    r11d,0x11
    1de8:	or     r10d,r11d
    1deb:	btc    r10,0x1d
    1df0:	mov    r11d,0xf0000000
    1df6:	and    r11,r10
    1df9:	movabs rsi,0xffffffff0fffffff
    1e03:	and    rbx,rsi
    1e06:	or     rbx,r11
    1e09:	pop    r11
    1e0b:	pop    r10
    1e0d:	pop    rsi
    1e0e:	pop    rdx
    1e0f:	mov    QWORD PTR [r12+0x108],rbx
    1e17:	add    rsp,0x150
    1e1e:	mov    eax,0xc
    1e23:	movabs r11,0x557f026e8390
    1e2d:	jmp    r11
    1e30:	mov    eax,0x410114
    1e35:	mov    QWORD PTR [r12+0x100],rax
    1e3d:	push   rdx
    1e3e:	push   rsi
    1e3f:	push   r10
    1e41:	push   r11
    1e43:	pushf
    1e44:	pop    r11
    1e46:	mov    QWORD PTR [rsp+0x20],r11
    1e4b:	mov    rdx,QWORD PTR [rsp+0x20]
    1e50:	mov    r10d,edx
    1e53:	and    r10d,0xc0
    1e5a:	shl    r10d,0x18
    1e5e:	mov    r11d,edx
    1e61:	and    r11d,0x1
    1e65:	shl    r11d,0x1d
    1e69:	or     r10d,r11d
    1e6c:	mov    r11d,edx
    1e6f:	and    r11d,0x800
    1e76:	shl    r11d,0x11
    1e7a:	or     r10d,r11d
    1e7d:	btc    r10,0x1d
    1e82:	mov    r11d,0xf0000000
    1e88:	and    r11,r10
    1e8b:	movabs rsi,0xffffffff0fffffff
    1e95:	and    rbx,rsi
    1e98:	or     rbx,r11
    1e9b:	pop    r11
    1e9d:	pop    r10
    1e9f:	pop    rsi
    1ea0:	pop    rdx
    1ea1:	mov    QWORD PTR [r12+0x108],rbx
    1ea9:	add    rsp,0x150
    1eb0:	mov    eax,0xc
    1eb5:	movabs r11,0x557f026e8390
    1ebf:	jmp    r11
    1ec2:	mov    eax,0x410124
    1ec7:	mov    QWORD PTR [r12+0x100],rax
    1ecf:	push   rdx
    1ed0:	push   rsi
    1ed1:	push   r10
    1ed3:	push   r11
    1ed5:	pushf
    1ed6:	pop    r11
    1ed8:	mov    QWORD PTR [rsp+0x20],r11
    1edd:	mov    rdx,QWORD PTR [rsp+0x20]
    1ee2:	mov    r10d,edx
    1ee5:	and    r10d,0xc0
    1eec:	shl    r10d,0x18
    1ef0:	mov    r11d,edx
    1ef3:	and    r11d,0x1
    1ef7:	shl    r11d,0x1d
    1efb:	or     r10d,r11d
    1efe:	mov    r11d,edx
    1f01:	and    r11d,0x800
    1f08:	shl    r11d,0x11
    1f0c:	or     r10d,r11d
    1f0f:	btc    r10,0x1d
    1f14:	mov    r11d,0xf0000000
    1f1a:	and    r11,r10
    1f1d:	movabs rsi,0xffffffff0fffffff
    1f27:	and    rbx,rsi
    1f2a:	or     rbx,r11
    1f2d:	pop    r11
    1f2f:	pop    r10
    1f31:	pop    rsi
    1f32:	pop    rdx
    1f33:	mov    QWORD PTR [r12+0x108],rbx
    1f3b:	add    rsp,0x150
    1f42:	mov    eax,0xc
    1f47:	movabs r11,0x557f026e8390
    1f51:	jmp    r11
    1f54:	mov    eax,0x410130
    1f59:	mov    QWORD PTR [r12+0x100],rax
    1f61:	push   rdx
    1f62:	push   rsi
    1f63:	push   r10
    1f65:	push   r11
    1f67:	pushf
    1f68:	pop    r11
    1f6a:	mov    QWORD PTR [rsp+0x20],r11
    1f6f:	mov    rdx,QWORD PTR [rsp+0x20]
    1f74:	mov    r10d,edx
    1f77:	and    r10d,0xc0
    1f7e:	shl    r10d,0x18
    1f82:	mov    r11d,edx
    1f85:	and    r11d,0x1
    1f89:	shl    r11d,0x1d
    1f8d:	or     r10d,r11d
    1f90:	mov    r11d,edx
    1f93:	and    r11d,0x800
    1f9a:	shl    r11d,0x11
    1f9e:	or     r10d,r11d
    1fa1:	btc    r10,0x1d
    1fa6:	mov    r11d,0xf0000000
    1fac:	and    r11,r10
    1faf:	movabs rsi,0xffffffff0fffffff
    1fb9:	and    rbx,rsi
    1fbc:	or     rbx,r11
    1fbf:	pop    r11
    1fc1:	pop    r10
    1fc3:	pop    rsi
    1fc4:	pop    rdx
    1fc5:	mov    QWORD PTR [r12+0x108],rbx
    1fcd:	add    rsp,0x150
    1fd4:	mov    eax,0xc
    1fd9:	movabs r11,0x557f026e8390
    1fe3:	jmp    r11
    1fe6:	mov    eax,0x410150
    1feb:	mov    QWORD PTR [r12+0x100],rax
    1ff3:	push   rdx
    1ff4:	push   rsi
    1ff5:	push   r10
    1ff7:	push   r11
    1ff9:	mov    rdx,QWORD PTR [rsp+0x20]
    1ffe:	mov    r10d,edx
    2001:	and    r10d,0xc0
    2008:	shl    r10d,0x18
    200c:	mov    r11d,edx
    200f:	and    r11d,0x1
    2013:	shl    r11d,0x1d
    2017:	or     r10d,r11d
    201a:	mov    r11d,edx
    201d:	and    r11d,0x800
    2024:	shl    r11d,0x11
    2028:	or     r10d,r11d
    202b:	btc    r10,0x1d
    2030:	mov    r11d,0xf0000000
    2036:	and    r11,r10
    2039:	movabs rsi,0xffffffff0fffffff
    2043:	and    rbx,rsi
    2046:	or     rbx,r11
    2049:	pop    r11
    204b:	pop    r10
    204d:	pop    rsi
    204e:	pop    rdx
    204f:	mov    QWORD PTR [r12+0x108],rbx
    2057:	add    rsp,0x150
    205e:	mov    eax,0xc
    2063:	movabs r11,0x557f026e8390
    206d:	jmp    r11
    2070:	mov    eax,0x410158
    2075:	mov    QWORD PTR [r12+0x100],rax
    207d:	push   rdx
    207e:	push   rsi
    207f:	push   r10
    2081:	push   r11
    2083:	mov    rdx,QWORD PTR [rsp+0x20]
    2088:	mov    r10d,edx
    208b:	and    r10d,0xc0
    2092:	shl    r10d,0x18
    2096:	mov    r11d,edx
    2099:	and    r11d,0x1
    209d:	shl    r11d,0x1d
    20a1:	or     r10d,r11d
    20a4:	mov    r11d,edx
    20a7:	and    r11d,0x800
    20ae:	shl    r11d,0x11
    20b2:	or     r10d,r11d
    20b5:	btc    r10,0x1d
    20ba:	mov    r11d,0xf0000000
    20c0:	and    r11,r10
    20c3:	movabs rsi,0xffffffff0fffffff
    20cd:	and    rbx,rsi
    20d0:	or     rbx,r11
    20d3:	pop    r11
    20d5:	pop    r10
    20d7:	pop    rsi
    20d8:	pop    rdx
    20d9:	mov    QWORD PTR [r12+0x108],rbx
    20e1:	add    rsp,0x150
    20e8:	mov    eax,0xc
    20ed:	movabs r11,0x557f026e8390
    20f7:	jmp    r11
    20fa:	nop    WORD PTR [rax+rax*1+0x0]
    2100:	sub    rsp,0x150
    2107:	mov    r11,QWORD PTR [r12+0x398]
    210f:	mov    QWORD PTR [rsp],r11
    2113:	cmp    DWORD PTR [r12+0x310],0x0
    211c:	je     0x21ac
    2122:	push   rdx
    2123:	push   rsi
    2124:	push   r10
    2126:	push   r11
    2128:	mov    rdx,QWORD PTR [rsp+0x20]
    212d:	mov    r10d,edx
    2130:	and    r10d,0xc0
    2137:	shl    r10d,0x18
    213b:	mov    r11d,edx
    213e:	and    r11d,0x1
    2142:	shl    r11d,0x1d
    2146:	or     r10d,r11d
    2149:	mov    r11d,edx
    214c:	and    r11d,0x800
    2153:	shl    r11d,0x11
    2157:	or     r10d,r11d
    215a:	btc    r10,0x1d
    215f:	mov    r11d,0xf0000000
    2165:	and    r11,r10
    2168:	movabs rsi,0xffffffff0fffffff
    2172:	and    rbx,rsi
    2175:	or     rbx,r11
    2178:	pop    r11
    217a:	pop    r10
    217c:	pop    rsi
    217d:	pop    rdx
    217e:	mov    QWORD PTR [r12+0x108],rbx
    2186:	mov    eax,0x41004c
    218b:	mov    QWORD PTR [r12+0x100],rax
    2193:	add    rsp,0x150
    219a:	mov    eax,0x3
    219f:	movabs r11,0x557f026e8390
    21a9:	jmp    r11
    21ac:	jmp    0xeb
    21b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    21c0:	sub    rsp,0x150
    21c7:	mov    r11,QWORD PTR [r12+0x398]
    21cf:	mov    QWORD PTR [rsp],r11
    21d3:	cmp    DWORD PTR [r12+0x310],0x0
    21dc:	je     0x226c
    21e2:	push   rdx
    21e3:	push   rsi
    21e4:	push   r10
    21e6:	push   r11
    21e8:	mov    rdx,QWORD PTR [rsp+0x20]
    21ed:	mov    r10d,edx
    21f0:	and    r10d,0xc0
    21f7:	shl    r10d,0x18
    21fb:	mov    r11d,edx
    21fe:	and    r11d,0x1
    2202:	shl    r11d,0x1d
    2206:	or     r10d,r11d
    2209:	mov    r11d,edx
    220c:	and    r11d,0x800
    2213:	shl    r11d,0x11
    2217:	or     r10d,r11d
    221a:	btc    r10,0x1d
    221f:	mov    r11d,0xf0000000
    2225:	and    r11,r10
    2228:	movabs rsi,0xffffffff0fffffff
    2232:	and    rbx,rsi
    2235:	or     rbx,r11
    2238:	pop    r11
    223a:	pop    r10
    223c:	pop    rsi
    223d:	pop    rdx
    223e:	mov    QWORD PTR [r12+0x108],rbx
    2246:	mov    eax,0x410074
    224b:	mov    QWORD PTR [r12+0x100],rax
    2253:	add    rsp,0x150
    225a:	mov    eax,0x3
    225f:	movabs r11,0x557f026e8390
    2269:	jmp    r11
    226c:	jmp    0x2bf
    2271:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    2280:	sub    rsp,0x150
    2287:	mov    r11,QWORD PTR [r12+0x398]
    228f:	mov    QWORD PTR [rsp],r11
    2293:	cmp    DWORD PTR [r12+0x310],0x0
    229c:	je     0x232c
    22a2:	push   rdx
    22a3:	push   rsi
    22a4:	push   r10
    22a6:	push   r11
    22a8:	mov    rdx,QWORD PTR [rsp+0x20]
    22ad:	mov    r10d,edx
    22b0:	and    r10d,0xc0
    22b7:	shl    r10d,0x18
    22bb:	mov    r11d,edx
    22be:	and    r11d,0x1
    22c2:	shl    r11d,0x1d
    22c6:	or     r10d,r11d
    22c9:	mov    r11d,edx
    22cc:	and    r11d,0x800
    22d3:	shl    r11d,0x11
    22d7:	or     r10d,r11d
    22da:	btc    r10,0x1d
    22df:	mov    r11d,0xf0000000
    22e5:	and    r11,r10
    22e8:	movabs rsi,0xffffffff0fffffff
    22f2:	and    rbx,rsi
    22f5:	or     rbx,r11
    22f8:	pop    r11
    22fa:	pop    r10
    22fc:	pop    rsi
    22fd:	pop    rdx
    22fe:	mov    QWORD PTR [r12+0x108],rbx
    2306:	mov    eax,0x410084
    230b:	mov    QWORD PTR [r12+0x100],rax
    2313:	add    rsp,0x150
    231a:	mov    eax,0x3
    231f:	movabs r11,0x557f026e8390
    2329:	jmp    r11
    232c:	jmp    0x2fd
    2331:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    2340:	sub    rsp,0x150
    2347:	mov    r11,QWORD PTR [r12+0x398]
    234f:	mov    QWORD PTR [rsp],r11
    2353:	cmp    DWORD PTR [r12+0x310],0x0
    235c:	je     0x23ec
    2362:	push   rdx
    2363:	push   rsi
    2364:	push   r10
    2366:	push   r11
    2368:	mov    rdx,QWORD PTR [rsp+0x20]
    236d:	mov    r10d,edx
    2370:	and    r10d,0xc0
    2377:	shl    r10d,0x18
    237b:	mov    r11d,edx
    237e:	and    r11d,0x1
    2382:	shl    r11d,0x1d
    2386:	or     r10d,r11d
    2389:	mov    r11d,edx
    238c:	and    r11d,0x800
    2393:	shl    r11d,0x11
    2397:	or     r10d,r11d
    239a:	btc    r10,0x1d
    239f:	mov    r11d,0xf0000000
    23a5:	and    r11,r10
    23a8:	movabs rsi,0xffffffff0fffffff
    23b2:	and    rbx,rsi
    23b5:	or     rbx,r11
    23b8:	pop    r11
    23ba:	pop    r10
    23bc:	pop    rsi
    23bd:	pop    rdx
    23be:	mov    QWORD PTR [r12+0x108],rbx
    23c6:	mov    eax,0x41008c
    23cb:	mov    QWORD PTR [r12+0x100],rax
    23d3:	add    rsp,0x150
    23da:	mov    eax,0x3
    23df:	movabs r11,0x557f026e8390
    23e9:	jmp    r11
    23ec:	jmp    0x323
    23f1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    2400:	sub    rsp,0x150
    2407:	mov    r11,QWORD PTR [r12+0x398]
    240f:	mov    QWORD PTR [rsp],r11
    2413:	cmp    DWORD PTR [r12+0x310],0x0
    241c:	je     0x24ac
    2422:	push   rdx
    2423:	push   rsi
    2424:	push   r10
    2426:	push   r11
    2428:	mov    rdx,QWORD PTR [rsp+0x20]
    242d:	mov    r10d,edx
    2430:	and    r10d,0xc0
    2437:	shl    r10d,0x18
    243b:	mov    r11d,edx
    243e:	and    r11d,0x1
    2442:	shl    r11d,0x1d
    2446:	or     r10d,r11d
    2449:	mov    r11d,edx
    244c:	and    r11d,0x800
    2453:	shl    r11d,0x11
    2457:	or     r10d,r11d
    245a:	btc    r10,0x1d
    245f:	mov    r11d,0xf0000000
    2465:	and    r11,r10
    2468:	movabs rsi,0xffffffff0fffffff
    2472:	and    rbx,rsi
    2475:	or     rbx,r11
    2478:	pop    r11
    247a:	pop    r10
    247c:	pop    rsi
    247d:	pop    rdx
    247e:	mov    QWORD PTR [r12+0x108],rbx
    2486:	mov    eax,0x4100a4
    248b:	mov    QWORD PTR [r12+0x100],rax
    2493:	add    rsp,0x150
    249a:	mov    eax,0x3
    249f:	movabs r11,0x557f026e8390
    24a9:	jmp    r11
    24ac:	jmp    0x447
    24b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    24c0:	sub    rsp,0x150
    24c7:	mov    r11,QWORD PTR [r12+0x398]
    24cf:	mov    QWORD PTR [rsp],r11
    24d3:	cmp    DWORD PTR [r12+0x310],0x0
    24dc:	je     0x256c
    24e2:	push   rdx
    24e3:	push   rsi
    24e4:	push   r10
    24e6:	push   r11
    24e8:	mov    rdx,QWORD PTR [rsp+0x20]
    24ed:	mov    r10d,edx
    24f0:	and    r10d,0xc0
    24f7:	shl    r10d,0x18
    24fb:	mov    r11d,edx
    24fe:	and    r11d,0x1
    2502:	shl    r11d,0x1d
    2506:	or     r10d,r11d
    2509:	mov    r11d,edx
    250c:	and    r11d,0x800
    2513:	shl    r11d,0x11
    2517:	or     r10d,r11d
    251a:	btc    r10,0x1d
    251f:	mov    r11d,0xf0000000
    2525:	and    r11,r10
    2528:	movabs rsi,0xffffffff0fffffff
    2532:	and    rbx,rsi
    2535:	or     rbx,r11
    2538:	pop    r11
    253a:	pop    r10
    253c:	pop    rsi
    253d:	pop    rdx
    253e:	mov    QWORD PTR [r12+0x108],rbx
    2546:	mov    eax,0x410118
    254b:	mov    QWORD PTR [r12+0x100],rax
    2553:	add    rsp,0x150
    255a:	mov    eax,0x3
    255f:	movabs r11,0x557f026e8390
    2569:	jmp    r11
    256c:	jmp    0xe6d
    2571:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    2580:	sub    rsp,0x150
    2587:	mov    r11,QWORD PTR [r12+0x398]
    258f:	mov    QWORD PTR [rsp],r11
    2593:	cmp    DWORD PTR [r12+0x310],0x0
    259c:	je     0x262c
    25a2:	push   rdx
    25a3:	push   rsi
    25a4:	push   r10
    25a6:	push   r11
    25a8:	mov    rdx,QWORD PTR [rsp+0x20]
    25ad:	mov    r10d,edx
    25b0:	and    r10d,0xc0
    25b7:	shl    r10d,0x18
    25bb:	mov    r11d,edx
    25be:	and    r11d,0x1
    25c2:	shl    r11d,0x1d
    25c6:	or     r10d,r11d
    25c9:	mov    r11d,edx
    25cc:	and    r11d,0x800
    25d3:	shl    r11d,0x11
    25d7:	or     r10d,r11d
    25da:	btc    r10,0x1d
    25df:	mov    r11d,0xf0000000
    25e5:	and    r11,r10
    25e8:	movabs rsi,0xffffffff0fffffff
    25f2:	and    rbx,rsi
    25f5:	or     rbx,r11
    25f8:	pop    r11
    25fa:	pop    r10
    25fc:	pop    rsi
    25fd:	pop    rdx
    25fe:	mov    QWORD PTR [r12+0x108],rbx
    2606:	mov    eax,0x410128
    260b:	mov    QWORD PTR [r12+0x100],rax
    2613:	add    rsp,0x150
    261a:	mov    eax,0x3
    261f:	movabs r11,0x557f026e8390
    2629:	jmp    r11
    262c:	jmp    0xeae
    2631:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    2640:	sub    rsp,0x150
    2647:	mov    r11,QWORD PTR [r12+0x398]
    264f:	mov    QWORD PTR [rsp],r11
    2653:	cmp    DWORD PTR [r12+0x310],0x0
    265c:	je     0x26ec
    2662:	push   rdx
    2663:	push   rsi
    2664:	push   r10
    2666:	push   r11
    2668:	mov    rdx,QWORD PTR [rsp+0x20]
    266d:	mov    r10d,edx
    2670:	and    r10d,0xc0
    2677:	shl    r10d,0x18
    267b:	mov    r11d,edx
    267e:	and    r11d,0x1
    2682:	shl    r11d,0x1d
    2686:	or     r10d,r11d
    2689:	mov    r11d,edx
    268c:	and    r11d,0x800
    2693:	shl    r11d,0x11
    2697:	or     r10d,r11d
    269a:	btc    r10,0x1d
    269f:	mov    r11d,0xf0000000
    26a5:	and    r11,r10
    26a8:	movabs rsi,0xffffffff0fffffff
    26b2:	and    rbx,rsi
    26b5:	or     rbx,r11
    26b8:	pop    r11
    26ba:	pop    r10
    26bc:	pop    rsi
    26bd:	pop    rdx
    26be:	mov    QWORD PTR [r12+0x108],rbx
    26c6:	mov    eax,0x410134
    26cb:	mov    QWORD PTR [r12+0x100],rax
    26d3:	add    rsp,0x150
    26da:	mov    eax,0x3
    26df:	movabs r11,0x557f026e8390
    26e9:	jmp    r11
    26ec:	jmp    0xee4
    26f1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    2700:	sub    rsp,0x150
    2707:	mov    r11,QWORD PTR [r12+0x398]
    270f:	mov    QWORD PTR [rsp],r11
    2713:	cmp    DWORD PTR [r12+0x310],0x0
    271c:	je     0x27ac
    2722:	push   rdx
    2723:	push   rsi
    2724:	push   r10
    2726:	push   r11
    2728:	mov    rdx,QWORD PTR [rsp+0x20]
    272d:	mov    r10d,edx
    2730:	and    r10d,0xc0
    2737:	shl    r10d,0x18
    273b:	mov    r11d,edx
    273e:	and    r11d,0x1
    2742:	shl    r11d,0x1d
    2746:	or     r10d,r11d
    2749:	mov    r11d,edx
    274c:	and    r11d,0x800
    2753:	shl    r11d,0x11
    2757:	or     r10d,r11d
    275a:	btc    r10,0x1d
    275f:	mov    r11d,0xf0000000
    2765:	and    r11,r10
    2768:	movabs rsi,0xffffffff0fffffff
    2772:	and    rbx,rsi
    2775:	or     rbx,r11
    2778:	pop    r11
    277a:	pop    r10
    277c:	pop    rsi
    277d:	pop    rdx
    277e:	mov    QWORD PTR [r12+0x108],rbx
    2786:	mov    eax,0x410140
    278b:	mov    QWORD PTR [r12+0x100],rax
    2793:	add    rsp,0x150
    279a:	mov    eax,0x3
    279f:	movabs r11,0x557f026e8390
    27a9:	jmp    r11
    27ac:	jmp    0xf1f
    27b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    27c0:	sub    rsp,0x150
    27c7:	mov    r11,QWORD PTR [r12+0x398]
    27cf:	mov    QWORD PTR [rsp],r11
    27d3:	cmp    DWORD PTR [r12+0x310],0x0
    27dc:	je     0x286c
    27e2:	push   rdx
    27e3:	push   rsi
    27e4:	push   r10
    27e6:	push   r11
    27e8:	mov    rdx,QWORD PTR [rsp+0x20]
    27ed:	mov    r10d,edx
    27f0:	and    r10d,0xc0
    27f7:	shl    r10d,0x18
    27fb:	mov    r11d,edx
    27fe:	and    r11d,0x1
    2802:	shl    r11d,0x1d
    2806:	or     r10d,r11d
    2809:	mov    r11d,edx
    280c:	and    r11d,0x800
    2813:	shl    r11d,0x11
    2817:	or     r10d,r11d
    281a:	btc    r10,0x1d
    281f:	mov    r11d,0xf0000000
    2825:	and    r11,r10
    2828:	movabs rsi,0xffffffff0fffffff
    2832:	and    rbx,rsi
    2835:	or     rbx,r11
    2838:	pop    r11
    283a:	pop    r10
    283c:	pop    rsi
    283d:	pop    rdx
    283e:	mov    QWORD PTR [r12+0x108],rbx
    2846:	mov    eax,0x410154
    284b:	mov    QWORD PTR [r12+0x100],rax
    2853:	add    rsp,0x150
    285a:	mov    eax,0x3
    285f:	movabs r11,0x557f026e8390
    2869:	jmp    r11
    286c:	jmp    0x103d
    2871:	nop
    2872:	nop
    2873:	nop
