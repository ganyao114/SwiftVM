000077c74edce69b  nop [rax+rax*1], eax
000077c74edce6a0  mov rax, [r15+0xF8]
000077c74edce6a7  lea r14, [rax-0x20]
000077c74edce6ab  mov r12, [r15+0xF0]
000077c74edce6b2  mov [r13+r14*1], r12
000077c74edce6b7  mov [r15+0xF8], r14
000077c74edce6be  lea r14, [rax-0x10]
000077c74edce6c2  mov r12, [r15+0xA0]
000077c74edce6c9  mov r11, [r15+0x98]
000077c74edce6d0  mov [r13+r14*1], r12
000077c74edce6d5  lea r14, [rax-0x08]
000077c74edce6d9  mov [r13+r14*1], r11
000077c74edce6de  mov qword ptr [r15+0xA0], 0x00
000077c74edce6e9  mov qword ptr [r15+0x98], 0x4202A0
000077c74edce6f4  mov eax, [r15+0xA0]
000077c74edce6fb  lea r14d, [eax+0x11]
000077c74edce700  mov r14d, r14d
000077c74edce703  mov [r15], r14
000077c74edce706  mov qword ptr [r15+0xF0], 0x410184
000077c74edce711  mov r14d, [r15+0x320]
000077c74edce718  mov eax, 0x410184
000077c74edce71d  mov rcx, 0x77C74EDCE800
000077c74edce727  mov [r15+r14*8+0x328], rax
000077c74edce72f  mov [r15+r14*8+0x368], rcx
000077c74edce737  add r14d, 0x01
000077c74edce73b  and r14d, 0x07
000077c74edce73f  mov [r15+0x320], r14d
000077c74edce746  cmp dword ptr [r15+0x318], 0x00
000077c74edce74e  jz 0x000077C74EDCE7A0
000077c74edce754  nop [rax+rax*1], ax
000077c74edce75d  nop [rax+rax*1], eax
000077c74edce765  mov eax, 0x41021C
000077c74edce76a  mov [r15+0x100], rax
000077c74edce771  jmp 0x000077C74EBFE110
000077c74edce776  int3
000077c74edce777  call 0x000077C74ECE2CE0
000077c74edce77c  jmp 0x000077C74EDCE6B7
000077c74edce781  call 0x000077C74ECE2CE0
000077c74edce786  jmp 0x000077C74EDCE6D5
000077c74edce78b  call 0x000077C74ECE1A60
000077c74edce790  jmp 0x000077C74EDCE6DE
000077c74edce795  int3
000077c74edce796  nop [rax+rax*1], ax
000077c74edce79f  nop
000077c74edce7a0  mov eax, 0x846CA68B
000077c74edce7a5  mov eax, eax
000077c74edce7a7  mov [r15+0x48], rax
000077c74edce7ab  mov eax, [r15]
000077c74edce7ae  imul eax, eax, 0x7FEB352D
000077c74edce7b4  mov [rsp+0x10], eax
000077c74edce7b8  shr eax, 0x0F
000077c74edce7bb  mov r14d, [rsp+0x10]
000077c74edce7c0  xor r14d, eax
000077c74edce7c3  imul r14d, r14d, 0x846CA68B
000077c74edce7ca  mov [rsp+0x10], r14d
000077c74edce7cf  mov r14d, r14d
000077c74edce7d2  mov [r15+0x40], r14
000077c74edce7d6  mov eax, [rsp+0x10]
000077c74edce7da  shr eax, 0x10
000077c74edce7dd  mov r14d, [rsp+0x10]
000077c74edce7e2  xor r14d, eax
000077c74edce7e5  mov r14d, r14d
000077c74edce7e8  mov [r15], r14
000077c74edce7eb  mov rax, [r15+0xF0]
000077c74edce7f2  mov [r15+0x100], rax
000077c74edce7f9  jmp 0x000077C74EDCE5C0
000077c74edce7fe  int3
000077c74edce7ff  int3
000077c74edce800  mov rax, [r15+0xA0]
000077c74edce807  mov [rsp+0x10], rax
000077c74edce80c  shl rax, 0x02
000077c74edce810  mov r14, [r15+0x98]
000077c74edce817  lea r12, [r14+rax*1]
000077c74edce81b  mov eax, [r15]
000077c74edce81e  mov [r13+r12*1], eax
000077c74edce823  mov rax, [rsp+0x10]
000077c74edce828  lea r14, [rax+0x01]
000077c74edce82c  mov [r15+0xA0], r14
000077c74edce833  xor eax, eax
000077c74edce835  mov r12d, 0x400
000077c74edce83b  cmp r14, r12
000077c74edce83e  cmc
000077c74edce83f  lahf
000077c74edce840  seto al
000077c74edce843  mov [r15+0x108], eax
000077c74edce84a  mov eax, [r15+0x108]
000077c74edce851  sahf
000077c74edce852  jnz 0x000077C74EDCE884
000077c74edce854  cmp dword ptr [r15+0x318], 0x00
000077c74edce85c  jz 0x000077C74EDCE950
000077c74edce862  nop [rax+rax*1], ax
000077c74edce86b  nop [rax+rax*1], eax
000077c74edce873  mov eax, 0x410194
000077c74edce878  mov [r15+0x100], rax
000077c74edce87f  jmp 0x000077C74EBFE110
000077c74edce884  cmp dword ptr [r15+0x318], 0x00
000077c74edce88c  jz 0x000077C74EDCE8C0
000077c74edce892  nop [rax+rax*1], ax
000077c74edce89b  nop [rax+rax*1], eax
000077c74edce8a3  mov eax, 0x41017C
000077c74edce8a8  mov [r15+0x100], rax
000077c74edce8af  jmp 0x000077C74EBFE110
000077c74edce8b4  int3
000077c74edce8b5  call 0x000077C74ECB4B70
000077c74edce8ba  jmp 0x000077C74EDCE823
000077c74edce8bf  int3
000077c74edce8c0  mov eax, [r15+0xA0]
000077c74edce8c7  lea r14d, [eax+0x11]
000077c74edce8cc  mov r14d, r14d
000077c74edce8cf  mov [r15], r14
000077c74edce8d2  mov qword ptr [r15+0xF0], 0x410184
000077c74edce8dd  mov r14d, [r15+0x320]
000077c74edce8e4  mov eax, 0x410184
000077c74edce8e9  mov rcx, 0x77C74EDCE800
000077c74edce8f3  mov [r15+r14*8+0x328], rax
000077c74edce8fb  mov [r15+r14*8+0x368], rcx
000077c74edce903  add r14d, 0x01
000077c74edce907  and r14d, 0x07
000077c74edce90b  mov [r15+0x320], r14d
000077c74edce912  cmp dword ptr [r15+0x318], 0x00
000077c74edce91a  jz 0x000077C74EDCE7A0
000077c74edce920  nop [rax+rax*1], ax
000077c74edce929  nop [rax+rax*1], eax
000077c74edce931  mov eax, 0x41021C
000077c74edce936  mov [r15+0x100], rax
000077c74edce93d  jmp 0x000077C74EBFE110
000077c74edce942  int3
000077c74edce943  int3
000077c74edce944  nop [rax+rax*1], ax
000077c74edce94d  nop [rax], eax
000077c74edce950  mov qword ptr [r15+0x40], 0x01
000077c74edce958  cmp dword ptr [r15+0x318], 0x00
000077c74edce960  jz 0x000077C74EDCE990
000077c74edce966  nop [rax+rax*1], ax
000077c74edce96f  nop [rax+rax*1], eax
000077c74edce977  mov eax, 0x4101B0
000077c74edce97c  mov [r15+0x100], rax
000077c74edce983  jmp 0x000077C74EBFE110
000077c74edce988  int3
000077c74edce989  int3
000077c74edce98a  nop [rax+rax*1], ax
000077c74edce990  mov rax, [r15+0x40]
000077c74edce994  mov [rsp+0x10], rax
000077c74edce999  shl rax, 0x02
000077c74edce99d  mov r14, [r15+0x98]
000077c74edce9a4  lea r12, [r14+rax*1]
000077c74edce9a8  mov eax, [r13+r12*1]
000077c74edce9ad  mov [rsp+0x20], eax
000077c74edce9b1  mov eax, eax
000077c74edce9b3  mov [r15+0x48], rax
000077c74edce9b7  mov rax, [rsp+0x10]
000077c74edce9bc  mov [r15+0x50], rax
000077c74edce9c0  mov eax, [r15+0x50]
000077c74edce9c4  lea r12d, [eax-0x01]
000077c74edce9c9  mov r12d, r12d
000077c74edce9cc  mov [r15+0x58], r12
000077c74edce9d0  mov rax, [r15+0x58]
000077c74edce9d4  mov r12d, eax
000077c74edce9d7  mov r12d, r12d
000077c74edce9da  shl r12, 0x02
000077c74edce9de  lea rax, [r14+r12*1]
000077c74edce9e2  mov r14d, [r13+rax*1]
000077c74edce9e7  mov [rsp+0x10], r14d
000077c74edce9ec  mov r14d, r14d
000077c74edce9ef  mov [r15+0x60], r14
000077c74edce9f3  xor eax, eax
000077c74edce9f5  mov r14d, [rsp+0x10]
000077c74edce9fa  mov r12d, [rsp+0x20]
000077c74edce9ff  cmp r14d, r12d
000077c74edcea02  cmc
000077c74edcea03  lahf
000077c74edcea04  seto al
000077c74edcea07  mov [r15+0x108], eax
000077c74edcea0e  mov eax, [r15+0x108]
000077c74edcea15  sahf
000077c74edcea16  cmc
000077c74edcea17  jbe 0x000077C74EDCEA49
000077c74edcea19  cmp dword ptr [r15+0x318], 0x00
000077c74edcea21  jz 0x000077C74EDCEA90
000077c74edcea27  nop [rax+rax*1], ax
000077c74edcea30  nop [rax+rax*1], eax
000077c74edcea38  mov eax, 0x4101C8
000077c74edcea3d  mov [r15+0x100], rax
000077c74edcea44  jmp 0x000077C74EBFE110
000077c74edcea49  cmp dword ptr [r15+0x318], 0x00
000077c74edcea51  jz 0x000077C74EDCED30
000077c74edcea57  nop [rax+rax*1], ax
000077c74edcea60  nop [rax+rax*1], eax
000077c74edcea68  mov eax, 0x4101A0
000077c74edcea6d  mov [r15+0x100], rax
000077c74edcea74  jmp 0x000077C74EBFE110
000077c74edcea79  int3
000077c74edcea7a  call 0x000077C74ECB4690
000077c74edcea7f  jmp 0x000077C74EDCE9AD
000077c74edcea84  call 0x000077C74EC0DAE0
000077c74edcea89  jmp 0x000077C74EDCE9E7
000077c74edcea8e  int3
000077c74edcea8f  nop
000077c74edcea90  mov rax, [r15+0x50]
000077c74edcea94  mov [rsp+0x10], rax
000077c74edcea99  shl rax, 0x02
000077c74edcea9d  mov r14, [r15+0x98]
000077c74edceaa4  lea r12, [r14+rax*1]
000077c74edceaa8  mov eax, [r15+0x60]
000077c74edceaac  mov [r13+r12*1], eax
000077c74edceab1  mov rax, [rsp+0x10]
000077c74edceab6  lea r14, [rax-0x01]
000077c74edceaba  mov [r15+0x50], r14
000077c74edceabe  mov rax, [r15+0x58]
000077c74edceac2  test rax, rax
000077c74edceac5  setz al
000077c74edceac8  movzx rax, al
000077c74edceacc  mov [rsp+0x414], al
000077c74edcead3  cmp byte ptr [rsp+0x414], 0x00
000077c74edceadb  jz 0x000077C74EDCEB0D
000077c74edceadd  cmp dword ptr [r15+0x318], 0x00
000077c74edceae5  jz 0x000077C74EDCEB50
000077c74edceaeb  nop [rax+rax*1], ax
000077c74edceaf4  nop [rax+rax*1], eax
000077c74edceafc  mov eax, 0x4101D4
000077c74edceb01  mov [r15+0x100], rax
000077c74edceb08  jmp 0x000077C74EBFE110
000077c74edceb0d  cmp dword ptr [r15+0x318], 0x00
000077c74edceb15  jz 0x000077C74EDCEC50
000077c74edceb1b  nop [rax+rax*1], ax
000077c74edceb24  nop [rax+rax*1], eax
000077c74edceb2c  mov eax, 0x4101B8
000077c74edceb31  mov [r15+0x100], rax
000077c74edceb38  jmp 0x000077C74EBFE110
000077c74edceb3d  int3
000077c74edceb3e  call 0x000077C74ECB4B70
000077c74edceb43  jmp 0x000077C74EDCEAB1
000077c74edceb48  int3
000077c74edceb49  nop [rax], eax
000077c74edceb50  cmp dword ptr [r15+0x318], 0x00
000077c74edceb58  jz 0x000077C74EDCEB90
000077c74edceb5e  nop [rax+rax*1], ax
000077c74edceb67  nop [rax+rax*1], eax
000077c74edceb6f  mov eax, 0x41019C
000077c74edceb74  mov [r15+0x100], rax
000077c74edceb7b  jmp 0x000077C74EBFE110
000077c74edceb80  int3
000077c74edceb81  int3
000077c74edceb82  nop [rax+rax*1], ax
000077c74edceb8b  nop [rax+rax*1], eax
000077c74edceb90  mov qword ptr [r15+0x50], 0x00
000077c74edceb98  mov rax, [r15+0x40]
000077c74edceb9c  lea r14, [rax+0x01]
000077c74edceba0  mov [r15+0x40], r14
000077c74edceba4  mov rax, [r15+0x98]
000077c74edcebab  mov r12d, [r15+0x48]
000077c74edcebaf  mov [r13+rax*1], r12d
000077c74edcebb4  xor eax, eax
000077c74edcebb6  mov r12d, 0x400
000077c74edcebbc  cmp r14, r12
000077c74edcebbf  cmc
000077c74edcebc0  lahf
000077c74edcebc1  seto al
000077c74edcebc4  mov [r15+0x108], eax
000077c74edcebcb  mov eax, [r15+0x108]
000077c74edcebd2  sahf
000077c74edcebd3  jz 0x000077C74EDCEC05
000077c74edcebd5  cmp dword ptr [r15+0x318], 0x00
000077c74edcebdd  jz 0x000077C74EDCE990
000077c74edcebe3  nop [rax+rax*1], ax
000077c74edcebec  nop [rax+rax*1], eax
000077c74edcebf4  mov eax, 0x4101B0
000077c74edcebf9  mov [r15+0x100], rax
000077c74edcec00  jmp 0x000077C74EBFE110
000077c74edcec05  cmp dword ptr [r15+0x318], 0x00
000077c74edcec0d  jz 0x000077C74EDCEDF0
000077c74edcec13  nop [rax+rax*1], ax
000077c74edcec1c  nop [rax+rax*1], eax
000077c74edcec24  mov eax, 0x4101D8
000077c74edcec29  mov [r15+0x100], rax
000077c74edcec30  jmp 0x000077C74EBFE110
000077c74edcec35  int3
000077c74edcec36  call 0x000077C74EC0BAE0
000077c74edcec3b  jmp 0x000077C74EDCEBB4
000077c74edcec40  int3
000077c74edcec41  nop [rax+rax*1], ax
000077c74edcec4a  nop [rax+rax*1], ax
000077c74edcec50  mov eax, [r15+0x50]
000077c74edcec54  lea r14d, [eax-0x01]
000077c74edcec59  mov r14d, r14d
000077c74edcec5c  mov [r15+0x58], r14
000077c74edcec60  mov rax, [r15+0x58]
000077c74edcec64  mov r14d, eax
000077c74edcec67  mov r14d, r14d
000077c74edcec6a  shl r14, 0x02
000077c74edcec6e  mov rax, [r15+0x98]
000077c74edcec75  lea r12, [rax+r14*1]
000077c74edcec79  mov eax, [r13+r12*1]
000077c74edcec7e  mov [rsp+0x10], eax
000077c74edcec82  mov eax, eax
000077c74edcec84  mov [r15+0x60], rax
000077c74edcec88  mov eax, [r15+0x48]
000077c74edcec8c  mov [rsp+0x20], eax
000077c74edcec90  xor eax, eax
000077c74edcec92  mov r14d, [rsp+0x10]
000077c74edcec97  mov r12d, [rsp+0x20]
000077c74edcec9c  cmp r14d, r12d
000077c74edcec9f  cmc
000077c74edceca0  lahf
000077c74edceca1  seto al
000077c74edceca4  mov [r15+0x108], eax
000077c74edcecab  mov eax, [r15+0x108]
000077c74edcecb2  sahf
000077c74edcecb3  cmc
000077c74edcecb4  jbe 0x000077C74EDCECE6
000077c74edcecb6  cmp dword ptr [r15+0x318], 0x00
000077c74edcecbe  jz 0x000077C74EDCEA90
000077c74edcecc4  nop [rax+rax*1], ax
000077c74edceccd  nop [rax+rax*1], eax
000077c74edcecd5  mov eax, 0x4101C8
000077c74edcecda  mov [r15+0x100], rax
000077c74edcece1  jmp 0x000077C74EBFE110
000077c74edcece6  cmp dword ptr [r15+0x318], 0x00
000077c74edcecee  jz 0x000077C74EDCED30
000077c74edcecf4  nop [rax+rax*1], ax
000077c74edcecfd  nop [rax+rax*1], eax
000077c74edced05  mov eax, 0x4101A0
000077c74edced0a  mov [r15+0x100], rax
000077c74edced11  jmp 0x000077C74EBFE110
000077c74edced16  int3
000077c74edced17  call 0x000077C74ECB4690
000077c74edced1c  jmp 0x000077C74EDCEC7E
000077c74edced21  int3
000077c74edced22  nop [rax+rax*1], ax
000077c74edced2b  nop [rax+rax*1], eax
000077c74edced30  mov rax, [r15+0x40]
000077c74edced34  lea r14, [rax+0x01]
000077c74edced38  mov [r15+0x40], r14
000077c74edced3c  mov rax, [r15+0x50]
000077c74edced40  mov r12d, eax
000077c74edced43  mov r12d, r12d
000077c74edced46  shl r12, 0x02
000077c74edced4a  mov rax, [r15+0x98]
000077c74edced51  lea r11, [rax+r12*1]
000077c74edced55  mov eax, [r15+0x48]
000077c74edced59  mov [r13+r11*1], eax
000077c74edced5e  xor eax, eax
000077c74edced60  mov r12d, 0x400
000077c74edced66  cmp r14, r12
000077c74edced69  cmc
000077c74edced6a  lahf
000077c74edced6b  seto al
000077c74edced6e  mov [r15+0x108], eax
000077c74edced75  mov eax, [r15+0x108]
000077c74edced7c  sahf
000077c74edced7d  jz 0x000077C74EDCEDAF
000077c74edced7f  cmp dword ptr [r15+0x318], 0x00
000077c74edced87  jz 0x000077C74EDCE990
000077c74edced8d  nop [rax+rax*1], ax
000077c74edced96  nop [rax+rax*1], eax
000077c74edced9e  mov eax, 0x4101B0
000077c74edceda3  mov [r15+0x100], rax
000077c74edcedaa  jmp 0x000077C74EBFE110
000077c74edcedaf  cmp dword ptr [r15+0x318], 0x00
000077c74edcedb7  jz 0x000077C74EDCEDF0
000077c74edcedbd  nop [rax+rax*1], ax
000077c74edcedc6  nop [rax+rax*1], eax
000077c74edcedce  mov eax, 0x4101D8
000077c74edcedd3  mov [r15+0x100], rax
000077c74edcedda  jmp 0x000077C74EBFE110
000077c74edceddf  int3
000077c74edcede0  call 0x000077C74ECA4270
000077c74edcede5  jmp 0x000077C74EDCED5E
000077c74edcedea  int3
000077c74edcedeb  nop [rax+rax*1], eax
000077c74edcedf0  mov qword ptr [r15+0x40], 0x420000
000077c74edcedf8  mov eax, 0x420288
000077c74edcedfd  mov r14, [r13+rax*1]
000077c74edcee02  mov rax, [r15+0x98]
000077c74edcee09  mov r12d, [r13+rax*1]
000077c74edcee0e  lea r11, [rax+0x04]
000077c74edcee12  mov eax, [r13+r11*1]
000077c74edcee17  mov r12d, r12d
000077c74edcee1a  mov [r15+0x68], r12
000077c74edcee1e  mov eax, eax
000077c74edcee20  mov [r15+0x60], rax
000077c74edcee24  mov rax, [r15+0x68]
000077c74edcee28  mov [r15+0x68], rax
000077c74edcee2c  mov qword ptr [r15+0x58], 0x02
000077c74edcee34  mov [rsp+0x10], rax
000077c74edcee39  xor eax, eax
000077c74edcee3b  mov r12d, 0x02
000077c74edcee41  mov r11d, 0x400
000077c74edcee47  cmp r12, r11
000077c74edcee4a  cmc
000077c74edcee4b  lahf
000077c74edcee4c  seto al
000077c74edcee4f  mov [r15+0x108], eax
000077c74edcee56  mov rax, [r15+0x60]
000077c74edcee5a  mov r12d, 0x02
000077c74edcee60  imul rax, r12
000077c74edcee64  mov [r15+0x50], rax
000077c74edcee68  mov rax, [rsp+0x10]
000077c74edcee6d  lea r12, [rax+r14*1]
000077c74edcee71  mov [r15+0x48], r12
000077c74edcee75  mov eax, [r15+0x108]
000077c74edcee7c  sahf
000077c74edcee7d  jnz 0x000077C74EDCEEAF
000077c74edcee7f  cmp dword ptr [r15+0x318], 0x00
000077c74edcee87  jz 0x000077C74EDCF020
000077c74edcee8d  nop [rax+rax*1], ax
000077c74edcee96  nop [rax+rax*1], eax
000077c74edcee9e  mov eax, 0x410208
000077c74edceea3  mov [r15+0x100], rax
000077c74edceeaa  jmp 0x000077C74EBFE110
000077c74edceeaf  cmp dword ptr [r15+0x318], 0x00
000077c74edceeb7  jz 0x000077C74EDCEF00
000077c74edceebd  nop [rax+rax*1], ax
000077c74edceec6  nop [rax+rax*1], eax
000077c74edceece  mov eax, 0x4101E8
000077c74edceed3  mov [r15+0x100], rax
000077c74edceeda  jmp 0x000077C74EBFE110
000077c74edceedf  int3
000077c74edceee0  call 0x000077C74EC0DC20
000077c74edceee5  jmp 0x000077C74EDCEE02
000077c74edceeea  call 0x000077C74EC0B5E0
000077c74edceeef  jmp 0x000077C74EDCEE0E
000077c74edceef4  call 0x000077C74ECA3D90
000077c74edceef9  jmp 0x000077C74EDCEE17
000077c74edceefe  int3
000077c74edceeff  nop
000077c74edcef00  mov rax, [r15+0x98]
000077c74edcef07  mov r14, [r15+0x58]
000077c74edcef0b  mov [rsp+0x10], r14
000077c74edcef10  shl r14, 0x02
000077c74edcef14  lea r12, [rax+r14*1]
000077c74edcef18  mov eax, [r13+r12*1]
000077c74edcef1d  lea r14, [r12+0x04]
000077c74edcef22  mov r12d, [r13+r14*1]
000077c74edcef27  mov eax, eax
000077c74edcef29  mov [r15+0x68], rax
000077c74edcef2d  mov r12d, r12d
000077c74edcef30  mov [r15+0x60], r12
000077c74edcef34  mov rax, [r15+0x68]
000077c74edcef38  mov [rsp+0x20], rax
000077c74edcef3d  mov r14, [rsp+0x10]
000077c74edcef42  imul rax, r14
000077c74edcef46  mov r12, [rsp+0x20]
000077c74edcef4b  lea r11, [r12+rax*1]
000077c74edcef4f  mov [r15+0x68], r11
000077c74edcef53  lea rax, [r14+0x02]
000077c74edcef57  mov [r15+0x58], rax
000077c74edcef5b  mov [rsp+0x10], rax
000077c74edcef60  xor eax, eax
000077c74edcef62  mov r14, [rsp+0x10]
000077c74edcef67  mov r12d, 0x400
000077c74edcef6d  cmp r14, r12
000077c74edcef70  cmc
000077c74edcef71  lahf
000077c74edcef72  seto al
000077c74edcef75  mov [r15+0x108], eax
000077c74edcef7c  mov rax, [r15+0x50]
000077c74edcef80  mov r12, [r15+0x60]
000077c74edcef84  imul r14, r12
000077c74edcef88  lea r12, [rax+r14*1]
000077c74edcef8c  mov [r15+0x50], r12
000077c74edcef90  mov rax, [r15+0x48]
000077c74edcef94  lea r14, [r11+rax*1]
000077c74edcef98  mov [r15+0x48], r14
000077c74edcef9c  mov eax, [r15+0x108]
000077c74edcefa3  sahf
000077c74edcefa4  jnz 0x000077C74EDCEFD6
000077c74edcefa6  cmp dword ptr [r15+0x318], 0x00
000077c74edcefae  jz 0x000077C74EDCF020
000077c74edcefb4  nop [rax+rax*1], ax
000077c74edcefbd  nop [rax+rax*1], eax
000077c74edcefc5  mov eax, 0x410208
000077c74edcefca  mov [r15+0x100], rax
000077c74edcefd1  jmp 0x000077C74EBFE110
000077c74edcefd6  cmp dword ptr [r15+0x318], 0x00
000077c74edcefde  jz 0x000077C74EDCEF00
000077c74edcefe4  nop [rax+rax*1], ax
000077c74edcefed  nop [rax+rax*1], eax
000077c74edceff5  mov eax, 0x4101E8
000077c74edceffa  mov [r15+0x100], rax
000077c74edcf001  jmp 0x000077C74EBFE110
000077c74edcf006  int3
000077c74edcf007  call 0x000077C74ECB4690
000077c74edcf00c  jmp 0x000077C74EDCEF1D
000077c74edcf011  call 0x000077C74ECE26A0
000077c74edcf016  jmp 0x000077C74EDCEF27
000077c74edcf01b  int3
000077c74edcf01c  nop [rax], eax
000077c74edcf020  mov rax, [r15+0xF8]
000077c74edcf027  lea r14, [rax+0x10]
000077c74edcf02b  mov r12, [r13+r14*1]
000077c74edcf030  lea r14, [rax+0x18]
000077c74edcf034  mov r11, [r13+r14*1]
000077c74edcf039  mov [r15+0xA0], r12
000077c74edcf040  mov [r15+0x98], r11
000077c74edcf047  mov r14, [r15+0x50]
000077c74edcf04b  mov r12, [r15+0x48]
000077c74edcf04f  lea r11, [r14+r12*1]
000077c74edcf053  mov [r15+0x48], r11
000077c74edcf057  mov r14, [r15+0x40]
000077c74edcf05b  lea r12, [r14+0x288]
000077c74edcf062  mov [r13+r12*1], r11
000077c74edcf067  mov r14, [r13+rax*1]
000077c74edcf06c  mov [r15+0xF0], r14
000077c74edcf073  lea r12, [rax+0x20]
000077c74edcf077  mov [r15+0xF8], r12
000077c74edcf07e  mov [r15+0x100], r14
000077c74edcf085  jmp 0x000077C74EDCE5C0
000077c74edcf08a  int3
000077c74edcf08b  call 0x000077C74ECE27E0
000077c74edcf090  jmp 0x000077C74EDCF030
000077c74edcf095  call 0x000077C74ECE1570
000077c74edcf09a  jmp 0x000077C74EDCF039
000077c74edcf09f  call 0x000077C74ECC0860
000077c74edcf0a4  jmp 0x000077C74EDCF067
000077c74edcf0a9  call 0x000077C74EC0DC20
000077c74edcf0ae  jmp 0x000077C74EDCF06C
000077c74edcf0b3  int3
000077c74edcf0b4  nop [rax+rax*1], ax
000077c74edcf0bd  nop [rax], eax
000077c74edcf0c0  mov qword ptr [r15+0x100], 0x04
000077c74edcf0cb  mov esi, 0x00
000077c74edcf0d0  mov edx, 0x09
000077c74edcf0d5  mov rdi, 0x7FFF3D7BDA40
000077c74edcf0df  mov rax, 0x64E59D6EC970
000077c74edcf0e9  call rax
000077c74edcf0eb  cmp dword ptr [r15+0x318], 0x00
000077c74edcf0f3  jnz 0x000077C74EBFE110
000077c74edcf0f9  jmp 0x000077C74EBFE0A0
000077c74edcf0fe  int3
000077c74edcf0ff  int3
