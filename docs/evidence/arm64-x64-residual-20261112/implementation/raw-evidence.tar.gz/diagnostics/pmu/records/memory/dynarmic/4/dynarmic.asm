000076b3babce69b  nop [rax+rax*1], eax
000076b3babce6a0  mov qword ptr [r15+0x20], 0x420060
000076b3babce6a8  mov eax, 0x420060
000076b3babce6ad  xor r14d, r14d
000076b3babce6b0  mov [r13+rax*1], r14
000076b3babce6b5  mov eax, 0x420060
000076b3babce6ba  mov r14, [r13+rax*1]
000076b3babce6bf  mov [r15+0x18], r14
000076b3babce6c3  lea rax, [r14+0x03]
000076b3babce6c7  mov [r15], rax
000076b3babce6ca  xor eax, eax
000076b3babce6cc  mov r14d, 0xB71B00
000076b3babce6d2  mov r12d, 0x01
000076b3babce6d8  sub r14, r12
000076b3babce6db  cmc
000076b3babce6dc  lahf
000076b3babce6dd  seto al
000076b3babce6e0  mov [r15+0x108], eax
000076b3babce6e7  mov [r15+0x08], r14
000076b3babce6eb  mov eax, [r15+0x108]
000076b3babce6f2  sahf
000076b3babce6f3  jnz 0x000076B3BABCE725
000076b3babce6f5  cmp dword ptr [r15+0x318], 0x00
000076b3babce6fd  jz 0x000076B3BABCE840
000076b3babce703  nop [rax+rax*1], ax
000076b3babce70c  nop [rax+rax*1], eax
000076b3babce714  mov eax, 0x410050
000076b3babce719  mov [r15+0x100], rax
000076b3babce720  jmp 0x000076B3BA9FE110
000076b3babce725  cmp dword ptr [r15+0x318], 0x00
000076b3babce72d  jz 0x000076B3BABCE770
000076b3babce733  nop [rax+rax*1], ax
000076b3babce73c  nop [rax+rax*1], eax
000076b3babce744  mov eax, 0x41003C
000076b3babce749  mov [r15+0x100], rax
000076b3babce750  jmp 0x000076B3BA9FE110
000076b3babce755  int3
000076b3babce756  call 0x000076B3BAA0E120
000076b3babce75b  jmp 0x000076B3BABCE6B5
000076b3babce760  call 0x000076B3BAA0DC20
000076b3babce765  jmp 0x000076B3BABCE6BF
000076b3babce76a  int3
000076b3babce76b  nop [rax+rax*1], eax
000076b3babce770  mov rax, [r15+0x20]
000076b3babce774  mov r14, [r15]
000076b3babce777  mov [r13+rax*1], r14
000076b3babce77c  mov r14, [r13+rax*1]
000076b3babce781  mov [r15+0x18], r14
000076b3babce785  lea rax, [r14+0x03]
000076b3babce789  mov [r15], rax
000076b3babce78c  mov rax, [r15+0x08]
000076b3babce790  mov [rsp+0x10], rax
000076b3babce795  xor eax, eax
000076b3babce797  mov r14, [rsp+0x10]
000076b3babce79c  mov r12d, 0x01
000076b3babce7a2  sub r14, r12
000076b3babce7a5  cmc
000076b3babce7a6  lahf
000076b3babce7a7  seto al
000076b3babce7aa  mov [r15+0x108], eax
000076b3babce7b1  mov [r15+0x08], r14
000076b3babce7b5  mov eax, [r15+0x108]
000076b3babce7bc  sahf
000076b3babce7bd  jnz 0x000076B3BABCE7EF
000076b3babce7bf  cmp dword ptr [r15+0x318], 0x00
000076b3babce7c7  jz 0x000076B3BABCE840
000076b3babce7cd  nop [rax+rax*1], ax
000076b3babce7d6  nop [rax+rax*1], eax
000076b3babce7de  mov eax, 0x410050
000076b3babce7e3  mov [r15+0x100], rax
000076b3babce7ea  jmp 0x000076B3BA9FE110
000076b3babce7ef  cmp dword ptr [r15+0x318], 0x00
000076b3babce7f7  jz 0x000076B3BABCE770
000076b3babce7fd  nop [rax+rax*1], ax
000076b3babce806  nop [rax+rax*1], eax
000076b3babce80e  mov eax, 0x41003C
000076b3babce813  mov [r15+0x100], rax
000076b3babce81a  jmp 0x000076B3BA9FE110
000076b3babce81f  int3
000076b3babce820  call 0x000076B3BAA0E120
000076b3babce825  jmp 0x000076B3BABCE77C
000076b3babce82a  call 0x000076B3BAA0DC20
000076b3babce82f  jmp 0x000076B3BABCE781
000076b3babce834  int3
000076b3babce835  nop [rax+rax*1], ax
000076b3babce83e  nop
000076b3babce840  mov rax, [r15+0x20]
000076b3babce844  mov r14, [r15]
000076b3babce847  mov [r13+rax*1], r14
000076b3babce84c  mov rax, [r15+0xF0]
000076b3babce853  mov [r15+0x100], rax
000076b3babce85a  jmp 0x000076B3BABCE5C0
000076b3babce85f  int3
000076b3babce860  call 0x000076B3BAA0E120
000076b3babce865  jmp 0x000076B3BABCE84C
000076b3babce86a  int3
000076b3babce86b  nop [rax+rax*1], eax
000076b3babce870  mov qword ptr [r15+0x100], 0x04
000076b3babce87b  mov esi, 0x00
000076b3babce880  mov edx, 0x09
000076b3babce885  mov rdi, 0x7FFEEA2E0DC0
000076b3babce88f  mov rax, 0x5953C42F4970
000076b3babce899  call rax
000076b3babce89b  cmp dword ptr [r15+0x318], 0x00
000076b3babce8a3  jnz 0x000076B3BA9FE110
000076b3babce8a9  jmp 0x000076B3BA9FE0A0
000076b3babce8ae  int3
000076b3babce8af  int3
