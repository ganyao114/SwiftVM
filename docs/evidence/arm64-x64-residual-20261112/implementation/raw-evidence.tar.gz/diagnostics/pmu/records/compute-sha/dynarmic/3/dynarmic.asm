00007ea19cfce69b  nop [rax+rax*1], eax
00007ea19cfce6a0  mov rax, [r15+0xF8]
00007ea19cfce6a7  lea r14, [rax-0xA0]
00007ea19cfce6ae  mov [r15+0xF8], r14
00007ea19cfce6b5  lea rax, [r14+0x90]
00007ea19cfce6bc  mov r12, [r15+0xA0]
00007ea19cfce6c3  mov r11, [r15+0x98]
00007ea19cfce6ca  mov [r13+rax*1], r12
00007ea19cfce6cf  lea rax, [r14+0x98]
00007ea19cfce6d6  mov [r13+rax*1], r11
00007ea19cfce6db  mov eax, 0x420670
00007ea19cfce6e0  movups xmm1, [r13+rax*1]
00007ea19cfce6e6  mov eax, 0x420610
00007ea19cfce6eb  movups xmm15, [r13+rax*1]
00007ea19cfce6f1  mov eax, 0x420690
00007ea19cfce6f6  movups xmm14, [r13+rax*1]
00007ea19cfce6fc  mov eax, 0x420630
00007ea19cfce701  movups xmm13, [r13+rax*1]
00007ea19cfce707  mov qword ptr [r15+0x98], 0x4308A0
00007ea19cfce712  mov eax, 0x4206A0
00007ea19cfce717  movups xmm12, [r13+rax*1]
00007ea19cfce71d  mov eax, 0x4308A0
00007ea19cfce722  movups [r13+rax*1], xmm1
00007ea19cfce728  mov eax, 0x4308B0
00007ea19cfce72d  movups [r13+rax*1], xmm15
00007ea19cfce733  mov eax, 0x4308C0
00007ea19cfce738  movups [r13+rax*1], xmm14
00007ea19cfce73e  mov eax, 0x4308D0
00007ea19cfce743  movups [r13+rax*1], xmm13
00007ea19cfce749  mov eax, 0x420600
00007ea19cfce74e  movups xmm14, [r13+rax*1]
00007ea19cfce754  mov eax, 0x4205F0
00007ea19cfce759  movups xmm13, [r13+rax*1]
00007ea19cfce75f  mov eax, 0x4309A0
00007ea19cfce764  movups [r13+rax*1], xmm1
00007ea19cfce76a  mov eax, 0x4309B0
00007ea19cfce76f  movups [r13+rax*1], xmm15
00007ea19cfce775  mov eax, 0x4308E0
00007ea19cfce77a  movups [r13+rax*1], xmm12
00007ea19cfce780  mov eax, 0x4308F0
00007ea19cfce785  movups [r13+rax*1], xmm14
00007ea19cfce78b  mov eax, 0x4205E0
00007ea19cfce790  movups xmm1, [r13+rax*1]
00007ea19cfce796  mov eax, 0x420640
00007ea19cfce79b  movups xmm15, [r13+rax*1]
00007ea19cfce7a1  mov eax, 0x430900
00007ea19cfce7a6  movups [r13+rax*1], xmm13
00007ea19cfce7ac  mov eax, 0x430910
00007ea19cfce7b1  movups [r13+rax*1], xmm1
00007ea19cfce7b7  mov eax, 0x420650
00007ea19cfce7bc  movups xmm1, [r13+rax*1]
00007ea19cfce7c2  mov eax, 0x420620
00007ea19cfce7c7  movups xmm14, [r13+rax*1]
00007ea19cfce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007ea19cfce7d5  mov eax, 0x430920
00007ea19cfce7da  movups [r13+rax*1], xmm15
00007ea19cfce7e0  mov eax, 0x430930
00007ea19cfce7e5  movups [r13+rax*1], xmm1
00007ea19cfce7eb  mov eax, 0x4206C0
00007ea19cfce7f0  movups xmm1, [r13+rax*1]
00007ea19cfce7f6  mov eax, 0x4206D0
00007ea19cfce7fb  movups xmm15, [r13+rax*1]
00007ea19cfce801  movaps [r15+0x150], xmm15
00007ea19cfce809  mov qword ptr [r15+0xA0], 0x3E8
00007ea19cfce814  mov eax, 0x430940
00007ea19cfce819  movups [r13+rax*1], xmm14
00007ea19cfce81f  mov eax, 0x430950
00007ea19cfce824  movups [r13+rax*1], xmm1
00007ea19cfce82a  mov eax, 0x4206B0
00007ea19cfce82f  movups xmm1, [r13+rax*1]
00007ea19cfce835  mov eax, 0x420660
00007ea19cfce83a  movups xmm14, [r13+rax*1]
00007ea19cfce840  movaps [r15+0x140], xmm14
00007ea19cfce848  lea rax, [r14+0x80]
00007ea19cfce84f  mov r12, [r15+0xF0]
00007ea19cfce856  mov [r13+rax*1], r12
00007ea19cfce85b  mov eax, 0x430960
00007ea19cfce860  movups [r13+rax*1], xmm15
00007ea19cfce866  mov eax, 0x430970
00007ea19cfce86b  movups [r13+rax*1], xmm1
00007ea19cfce871  mov eax, 0x420680
00007ea19cfce876  movups xmm1, [r13+rax*1]
00007ea19cfce87c  mov eax, 0x4206E0
00007ea19cfce881  mov r12, [r13+rax*1]
00007ea19cfce886  movq xmm15, r12
00007ea19cfce88b  mov qword ptr [r15+0x40], 0x4206E8
00007ea19cfce893  mov eax, 0x430980
00007ea19cfce898  movups [r13+rax*1], xmm14
00007ea19cfce89e  mov eax, 0x430990
00007ea19cfce8a3  movups [r13+rax*1], xmm1
00007ea19cfce8a9  mov eax, 0x420748
00007ea19cfce8ae  movups xmm1, [r13+rax*1]
00007ea19cfce8b4  movq rax, xmm15
00007ea19cfce8b9  mov r12d, 0x4309C0
00007ea19cfce8bf  mov [r13+r12*1], rax
00007ea19cfce8c4  mov eax, 0x420728
00007ea19cfce8c9  movups xmm15, [r13+rax*1]
00007ea19cfce8cf  mov eax, 0x420738
00007ea19cfce8d4  movups xmm14, [r13+rax*1]
00007ea19cfce8da  lea rax, [r14+0x60]
00007ea19cfce8de  movups [r13+rax*1], xmm1
00007ea19cfce8e4  mov eax, 0x4309C8
00007ea19cfce8e9  mov r12d, 0x421DF8D3
00007ea19cfce8ef  mov [r13+rax*1], r12d
00007ea19cfce8f4  lea rax, [r14+0x40]
00007ea19cfce8f8  movups [r13+rax*1], xmm15
00007ea19cfce8fe  lea rax, [r14+0x50]
00007ea19cfce902  movups [r13+rax*1], xmm14
00007ea19cfce908  mov eax, 0x4206E8
00007ea19cfce90d  movups xmm1, [r13+rax*1]
00007ea19cfce913  mov eax, 0x4206F8
00007ea19cfce918  movups xmm15, [r13+rax*1]
00007ea19cfce91e  movaps [r15+0x120], xmm15
00007ea19cfce926  movups [r13+r14*1], xmm1
00007ea19cfce92c  lea rax, [r14+0x10]
00007ea19cfce930  movups [r13+rax*1], xmm15
00007ea19cfce936  mov eax, 0x420708
00007ea19cfce93b  movups xmm1, [r13+rax*1]
00007ea19cfce941  mov eax, 0x420718
00007ea19cfce946  movups xmm15, [r13+rax*1]
00007ea19cfce94c  movaps [r15+0x110], xmm1
00007ea19cfce954  movaps [r15+0x130], xmm15
00007ea19cfce95c  lea rax, [r14+0x20]
00007ea19cfce960  movups [r13+rax*1], xmm1
00007ea19cfce966  lea rax, [r14+0x30]
00007ea19cfce96a  movups [r13+rax*1], xmm15
00007ea19cfce970  mov [r15], r14
00007ea19cfce973  mov qword ptr [r15+0x08], 0x4308A0
00007ea19cfce97b  mov qword ptr [r15+0x10], 0x12C
00007ea19cfce983  mov qword ptr [r15+0xF0], 0x410274
00007ea19cfce98e  mov r14d, [r15+0x320]
00007ea19cfce995  mov eax, 0x410274
00007ea19cfce99a  mov rcx, 0x7EA19CFD0670
00007ea19cfce9a4  mov [r15+r14*8+0x328], rax
00007ea19cfce9ac  mov [r15+r14*8+0x368], rcx
00007ea19cfce9b4  add r14d, 0x01
00007ea19cfce9b8  and r14d, 0x07
00007ea19cfce9bc  mov [r15+0x320], r14d
00007ea19cfce9c3  cmp dword ptr [r15+0x318], 0x00
00007ea19cfce9cb  jz 0x00007EA19CFCEC20
00007ea19cfce9d1  nop [rax+rax*1], ax
00007ea19cfce9da  nop [rax+rax*1], eax
00007ea19cfce9e2  mov eax, 0x410338
00007ea19cfce9e7  mov [r15+0x100], rax
00007ea19cfce9ee  jmp 0x00007EA19CDFE110
00007ea19cfce9f3  int3
00007ea19cfce9f4  call 0x00007EA19CE0BC20
00007ea19cfce9f9  jmp 0x00007EA19CFCE6CF
00007ea19cfce9fe  call 0x00007EA19CE0A9A0
00007ea19cfcea03  jmp 0x00007EA19CFCE6DB
00007ea19cfcea08  call 0x00007EA19CDFF430
00007ea19cfcea0d  jmp 0x00007EA19CFCE6E6
00007ea19cfcea12  call 0x00007EA19CE0E760
00007ea19cfcea17  jmp 0x00007EA19CFCE6F1
00007ea19cfcea1c  call 0x00007EA19CE0D4E0
00007ea19cfcea21  jmp 0x00007EA19CFCE6FC
00007ea19cfcea26  call 0x00007EA19CE0C260
00007ea19cfcea2b  jmp 0x00007EA19CFCE707
00007ea19cfcea30  call 0x00007EA19CE0AFE0
00007ea19cfcea35  jmp 0x00007EA19CFCE71D
00007ea19cfcea3a  call 0x00007EA19CDFF540
00007ea19cfcea3f  jmp 0x00007EA19CFCE728
00007ea19cfcea44  call 0x00007EA19CE0E880
00007ea19cfcea49  jmp 0x00007EA19CFCE733
00007ea19cfcea4e  call 0x00007EA19CE0D600
00007ea19cfcea53  jmp 0x00007EA19CFCE73E
00007ea19cfcea58  call 0x00007EA19CE0C380
00007ea19cfcea5d  jmp 0x00007EA19CFCE749
00007ea19cfcea62  call 0x00007EA19CE0D4E0
00007ea19cfcea67  jmp 0x00007EA19CFCE754
00007ea19cfcea6c  call 0x00007EA19CE0C260
00007ea19cfcea71  jmp 0x00007EA19CFCE75F
00007ea19cfcea76  call 0x00007EA19CDFF540
00007ea19cfcea7b  jmp 0x00007EA19CFCE76A
00007ea19cfcea80  call 0x00007EA19CE0E880
00007ea19cfcea85  jmp 0x00007EA19CFCE775
00007ea19cfcea8a  call 0x00007EA19CE0B100
00007ea19cfcea8f  jmp 0x00007EA19CFCE780
00007ea19cfcea94  call 0x00007EA19CE0D600
00007ea19cfcea99  jmp 0x00007EA19CFCE78B
00007ea19cfcea9e  call 0x00007EA19CDFF430
00007ea19cfceaa3  jmp 0x00007EA19CFCE796
00007ea19cfceaa8  call 0x00007EA19CE0E760
00007ea19cfceaad  jmp 0x00007EA19CFCE7A1
00007ea19cfceab2  call 0x00007EA19CE0C380
00007ea19cfceab7  jmp 0x00007EA19CFCE7AC
00007ea19cfceabc  call 0x00007EA19CDFF540
00007ea19cfceac1  jmp 0x00007EA19CFCE7B7
00007ea19cfceac6  call 0x00007EA19CDFF430
00007ea19cfceacb  jmp 0x00007EA19CFCE7C2
00007ea19cfcead0  call 0x00007EA19CE0D4E0
00007ea19cfcead5  jmp 0x00007EA19CFCE7CD
00007ea19cfceada  call 0x00007EA19CE0E880
00007ea19cfceadf  jmp 0x00007EA19CFCE7E0
00007ea19cfceae4  call 0x00007EA19CDFF540
00007ea19cfceae9  jmp 0x00007EA19CFCE7EB
00007ea19cfceaee  call 0x00007EA19CDFF430
00007ea19cfceaf3  jmp 0x00007EA19CFCE7F6
00007ea19cfceaf8  call 0x00007EA19CE0E760
00007ea19cfceafd  jmp 0x00007EA19CFCE801
00007ea19cfceb02  call 0x00007EA19CE0D600
00007ea19cfceb07  jmp 0x00007EA19CFCE81F
00007ea19cfceb0c  call 0x00007EA19CDFF540
00007ea19cfceb11  jmp 0x00007EA19CFCE82A
00007ea19cfceb16  call 0x00007EA19CDFF430
00007ea19cfceb1b  jmp 0x00007EA19CFCE835
00007ea19cfceb20  call 0x00007EA19CE0D4E0
00007ea19cfceb25  jmp 0x00007EA19CFCE840
00007ea19cfceb2a  call 0x00007EA19CE0BC20
00007ea19cfceb2f  jmp 0x00007EA19CFCE85B
00007ea19cfceb34  call 0x00007EA19CE0E880
00007ea19cfceb39  jmp 0x00007EA19CFCE866
00007ea19cfceb3e  call 0x00007EA19CDFF540
00007ea19cfceb43  jmp 0x00007EA19CFCE871
00007ea19cfceb48  call 0x00007EA19CDFF430
00007ea19cfceb4d  jmp 0x00007EA19CFCE87C
00007ea19cfceb52  call 0x00007EA19CE0B720
00007ea19cfceb57  jmp 0x00007EA19CFCE886
00007ea19cfceb5c  call 0x00007EA19CE0D600
00007ea19cfceb61  jmp 0x00007EA19CFCE89E
00007ea19cfceb66  call 0x00007EA19CDFF540
00007ea19cfceb6b  jmp 0x00007EA19CFCE8A9
00007ea19cfceb70  call 0x00007EA19CDFF430
00007ea19cfceb75  jmp 0x00007EA19CFCE8B4
00007ea19cfceb7a  call 0x00007EA19CEB4CB0
00007ea19cfceb7f  jmp 0x00007EA19CFCE8C4
00007ea19cfceb84  call 0x00007EA19CE0E760
00007ea19cfceb89  jmp 0x00007EA19CFCE8CF
00007ea19cfceb8e  call 0x00007EA19CE0D4E0
00007ea19cfceb93  jmp 0x00007EA19CFCE8DA
00007ea19cfceb98  call 0x00007EA19CDFF540
00007ea19cfceb9d  jmp 0x00007EA19CFCE8E4
00007ea19cfceba2  call 0x00007EA19CE0BAE0
00007ea19cfceba7  jmp 0x00007EA19CFCE8F4
00007ea19cfcebac  call 0x00007EA19CE0E880
00007ea19cfcebb1  jmp 0x00007EA19CFCE8FE
00007ea19cfcebb6  call 0x00007EA19CE0D600
00007ea19cfcebbb  jmp 0x00007EA19CFCE908
00007ea19cfcebc0  call 0x00007EA19CDFF430
00007ea19cfcebc5  jmp 0x00007EA19CFCE913
00007ea19cfcebca  call 0x00007EA19CE0E760
00007ea19cfcebcf  jmp 0x00007EA19CFCE91E
00007ea19cfcebd4  call 0x00007EA19CED6600
00007ea19cfcebd9  jmp 0x00007EA19CFCE92C
00007ea19cfcebde  call 0x00007EA19CE0E880
00007ea19cfcebe3  jmp 0x00007EA19CFCE936
00007ea19cfcebe8  call 0x00007EA19CDFF430
00007ea19cfcebed  jmp 0x00007EA19CFCE941
00007ea19cfcebf2  call 0x00007EA19CE0E760
00007ea19cfcebf7  jmp 0x00007EA19CFCE94C
00007ea19cfcebfc  call 0x00007EA19CDFF540
00007ea19cfcec01  jmp 0x00007EA19CFCE966
00007ea19cfcec06  call 0x00007EA19CE0E880
00007ea19cfcec0b  jmp 0x00007EA19CFCE970
00007ea19cfcec10  int3
00007ea19cfcec11  nop [rax+rax*1], ax
00007ea19cfcec1a  nop [rax+rax*1], ax
00007ea19cfcec20  mov rax, [r15]
00007ea19cfcec23  lea r14, [rax+0x20]
00007ea19cfcec27  mov r12, [r13+r14*1]
00007ea19cfcec2c  mov r14, [r15+0x10]
00007ea19cfcec30  lea r11, [r12+r14*1]
00007ea19cfcec34  mov [r15+0x40], r11
00007ea19cfcec38  lea r12, [rax+0x20]
00007ea19cfcec3c  mov [r13+r12*1], r11
00007ea19cfcec41  test r14, r14
00007ea19cfcec44  setz r14b
00007ea19cfcec48  movzx r14, r14b
00007ea19cfcec4c  mov [rsp+0x414], r14b
00007ea19cfcec54  cmp byte ptr [rsp+0x414], 0x00
00007ea19cfcec5c  jz 0x00007EA19CFCEC8E
00007ea19cfcec5e  cmp dword ptr [r15+0x318], 0x00
00007ea19cfcec66  mov eax, 0x4105B0
00007ea19cfcec6b  mov [r15+0x100], rax
00007ea19cfcec72  jz 0x00007EA19CDFE0A0
00007ea19cfcec78  nop [rax+rax*1], eax
00007ea19cfcec7d  mov eax, 0x4105B0
00007ea19cfcec82  mov [r15+0x100], rax
00007ea19cfcec89  jmp 0x00007EA19CDFE110
00007ea19cfcec8e  cmp dword ptr [r15+0x318], 0x00
00007ea19cfcec96  jz 0x00007EA19CFCECE0
00007ea19cfcec9c  nop [rax+rax*1], ax
00007ea19cfceca5  nop [rax+rax*1], eax
00007ea19cfcecad  mov eax, 0x410348
00007ea19cfcecb2  mov [r15+0x100], rax
00007ea19cfcecb9  jmp 0x00007EA19CDFE110
00007ea19cfcecbe  int3
00007ea19cfcecbf  call 0x00007EA19CEE27E0
00007ea19cfcecc4  jmp 0x00007EA19CFCEC2C
00007ea19cfcecc9  call 0x00007EA19CEC0860
00007ea19cfcecce  jmp 0x00007EA19CFCEC41
00007ea19cfcecd3  int3
00007ea19cfcecd4  nop [rax+rax*1], ax
00007ea19cfcecdd  nop [rax], eax
00007ea19cfcece0  mov rax, [r15+0xF8]
00007ea19cfcece7  lea r14, [rax-0x150]
00007ea19cfcecee  mov [r15+0xF8], r14
00007ea19cfcecf5  mov rax, [r15]
00007ea19cfcecf8  lea r12, [rax+0x68]
00007ea19cfcecfc  mov r11, [r13+r12*1]
00007ea19cfced01  mov [r15+0x88], r11
00007ea19cfced08  lea r12, [rax+0x28]
00007ea19cfced0c  mov [r15+0x40], r12
00007ea19cfced10  mov [r15+0x48], r14
00007ea19cfced14  mov qword ptr [r15+0x50], 0x420758
00007ea19cfced1c  lea rax, [r14+0x100]
00007ea19cfced23  mov r12, [r15+0xE8]
00007ea19cfced2a  mov r11, [r15+0xD8]
00007ea19cfced31  mov [r13+rax*1], r12
00007ea19cfced36  lea rax, [r14+0x108]
00007ea19cfced3d  mov [r13+rax*1], r11
00007ea19cfced42  lea rax, [r14+0x110]
00007ea19cfced49  mov r12, [r15+0xD0]
00007ea19cfced50  mov r11, [r15+0xC8]
00007ea19cfced57  mov [r13+rax*1], r12
00007ea19cfced5c  lea rax, [r14+0x118]
00007ea19cfced63  mov [r13+rax*1], r11
00007ea19cfced68  lea rax, [r14+0x120]
00007ea19cfced6f  mov r12, [r15+0xC0]
00007ea19cfced76  mov r11, [r15+0xB8]
00007ea19cfced7d  mov [r13+rax*1], r12
00007ea19cfced82  lea rax, [r14+0x128]
00007ea19cfced89  mov [r13+rax*1], r11
00007ea19cfced8e  lea rax, [r14+0x130]
00007ea19cfced95  mov r12, [r15+0xB0]
00007ea19cfced9c  mov r11, [r15+0xA8]
00007ea19cfceda3  mov [r13+rax*1], r12
00007ea19cfceda8  lea rax, [r14+0x138]
00007ea19cfcedaf  mov [r13+rax*1], r11
00007ea19cfcedb4  lea rax, [r14+0x140]
00007ea19cfcedbb  mov r12, [r15+0xA0]
00007ea19cfcedc2  mov r11, [r15+0x98]
00007ea19cfcedc9  mov [r13+rax*1], r12
00007ea19cfcedce  lea rax, [r14+0x148]
00007ea19cfcedd5  mov [r13+rax*1], r11
00007ea19cfcedda  cmp dword ptr [r15+0x318], 0x00
00007ea19cfcede2  jz 0x00007EA19CFCEE80
00007ea19cfcede8  nop [rax+rax*1], ax
00007ea19cfcedf1  nop [rax+rax*1], eax
00007ea19cfcedf9  mov eax, 0x410380
00007ea19cfcedfe  mov [r15+0x100], rax
00007ea19cfcee05  jmp 0x00007EA19CDFE110
00007ea19cfcee0a  int3
00007ea19cfcee0b  call 0x00007EA19CEC0370
00007ea19cfcee10  jmp 0x00007EA19CFCED01
00007ea19cfcee15  call 0x00007EA19CE0BC20
00007ea19cfcee1a  jmp 0x00007EA19CFCED36
00007ea19cfcee1f  call 0x00007EA19CE0A9A0
00007ea19cfcee24  jmp 0x00007EA19CFCED42
00007ea19cfcee29  call 0x00007EA19CE0BC20
00007ea19cfcee2e  jmp 0x00007EA19CFCED5C
00007ea19cfcee33  call 0x00007EA19CE0A9A0
00007ea19cfcee38  jmp 0x00007EA19CFCED68
00007ea19cfcee3d  call 0x00007EA19CE0BC20
00007ea19cfcee42  jmp 0x00007EA19CFCED82
00007ea19cfcee47  call 0x00007EA19CE0A9A0
00007ea19cfcee4c  jmp 0x00007EA19CFCED8E
00007ea19cfcee51  call 0x00007EA19CE0BC20
00007ea19cfcee56  jmp 0x00007EA19CFCEDA8
00007ea19cfcee5b  call 0x00007EA19CE0A9A0
00007ea19cfcee60  jmp 0x00007EA19CFCEDB4
00007ea19cfcee65  call 0x00007EA19CE0BC20
00007ea19cfcee6a  jmp 0x00007EA19CFCEDCE
00007ea19cfcee6f  call 0x00007EA19CE0A9A0
00007ea19cfcee74  jmp 0x00007EA19CFCEDDA
00007ea19cfcee79  int3
00007ea19cfcee7a  nop [rax+rax*1], ax
00007ea19cfcee80  mov rax, [r15+0x08]
00007ea19cfcee84  movzx r14d, byte ptr [r13+rax*1]
00007ea19cfcee8a  movzx r14d, r14b
00007ea19cfcee8e  mov [rsp+0x10], r14d
00007ea19cfcee93  mov r14d, r14d
00007ea19cfcee96  mov [r15+0x58], r14
00007ea19cfcee9a  lea r14, [rax+0x01]
00007ea19cfcee9e  mov [r15+0x08], r14
00007ea19cfceea2  mov rax, [r15+0x88]
00007ea19cfceea9  lea r14, [rax+0x01]
00007ea19cfceead  mov r12, [r15]
00007ea19cfceeb0  lea r11, [r12+0x68]
00007ea19cfceeb5  mov [r13+r11*1], r14
00007ea19cfceeba  lea r14, [r12+rax*1]
00007ea19cfceebe  mov [r15+0x60], r14
00007ea19cfceec2  lea rax, [r14+0x28]
00007ea19cfceec6  mov r11d, [rsp+0x10]
00007ea19cfceecb  movzx r14d, r11b
00007ea19cfceecf  mov [r13+rax*1], r14b
00007ea19cfceed4  lea rax, [r12+0x68]
00007ea19cfceed9  mov r14, [r13+rax*1]
00007ea19cfceede  mov [r15+0x88], r14
00007ea19cfceee5  xor eax, eax
00007ea19cfceee7  mov r12d, 0x40
00007ea19cfceeed  cmp r14, r12
00007ea19cfceef0  cmc
00007ea19cfceef1  lahf
00007ea19cfceef2  seto al
00007ea19cfceef5  mov [r15+0x108], eax
00007ea19cfceefc  mov eax, [r15+0x108]
00007ea19cfcef03  sahf
00007ea19cfcef04  jnz 0x00007EA19CFCEF36
00007ea19cfcef06  cmp dword ptr [r15+0x318], 0x00
00007ea19cfcef0e  jz 0x00007EA19CFCF020
00007ea19cfcef14  nop [rax+rax*1], ax
00007ea19cfcef1d  nop [rax+rax*1], eax
00007ea19cfcef25  mov eax, 0x4103A0
00007ea19cfcef2a  mov [r15+0x100], rax
00007ea19cfcef31  jmp 0x00007EA19CDFE110
00007ea19cfcef36  cmp dword ptr [r15+0x318], 0x00
00007ea19cfcef3e  jz 0x00007EA19CFCEF90
00007ea19cfcef44  nop [rax+rax*1], ax
00007ea19cfcef4d  nop [rax+rax*1], eax
00007ea19cfcef55  mov eax, 0x410378
00007ea19cfcef5a  mov [r15+0x100], rax
00007ea19cfcef61  jmp 0x00007EA19CDFE110
00007ea19cfcef66  int3
00007ea19cfcef67  call 0x00007EA19CE0D860
00007ea19cfcef6c  jmp 0x00007EA19CFCEE8A
00007ea19cfcef71  call 0x00007EA19CEB36E0
00007ea19cfcef76  jmp 0x00007EA19CFCEEBA
00007ea19cfcef7b  call 0x00007EA19CE0DD60
00007ea19cfcef80  jmp 0x00007EA19CFCEED4
00007ea19cfcef85  call 0x00007EA19CE0DC20
00007ea19cfcef8a  jmp 0x00007EA19CFCEEDE
00007ea19cfcef8f  int3
00007ea19cfcef90  mov rax, [r15+0x10]
00007ea19cfcef94  lea r14, [rax-0x01]
00007ea19cfcef98  mov [r15+0x10], r14
00007ea19cfcef9c  test r14, r14
00007ea19cfcef9f  setz r14b
00007ea19cfcefa3  movzx r14, r14b
00007ea19cfcefa7  mov [rsp+0x414], r14b
00007ea19cfcefaf  cmp byte ptr [rsp+0x414], 0x00
00007ea19cfcefb7  jz 0x00007EA19CFCEFE9
00007ea19cfcefb9  cmp dword ptr [r15+0x318], 0x00
00007ea19cfcefc1  jz 0x00007EA19CFD0520
00007ea19cfcefc7  nop [rax+rax*1], ax
00007ea19cfcefd0  nop [rax+rax*1], eax
00007ea19cfcefd8  mov eax, 0x410598
00007ea19cfcefdd  mov [r15+0x100], rax
00007ea19cfcefe4  jmp 0x00007EA19CDFE110
00007ea19cfcefe9  cmp dword ptr [r15+0x318], 0x00
00007ea19cfceff1  jz 0x00007EA19CFCEE80
00007ea19cfceff7  nop [rax+rax*1], ax
00007ea19cfcf000  nop [rax+rax*1], eax
00007ea19cfcf008  mov eax, 0x410380
00007ea19cfcf00d  mov [r15+0x100], rax
00007ea19cfcf014  jmp 0x00007EA19CDFE110
00007ea19cfcf019  int3
00007ea19cfcf01a  int3
00007ea19cfcf01b  nop [rax+rax*1], eax
00007ea19cfcf020  mov rax, [r15+0x40]
00007ea19cfcf024  movzx r14d, byte ptr [r13+rax*1]
00007ea19cfcf02a  movaps xmm1, [r15+0x110]
00007ea19cfcf032  pinsrb xmm1, r14d, 0x00
00007ea19cfcf039  lea r14, [rax+0x01]
00007ea19cfcf03d  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf043  movaps xmm15, [r15+0x120]
00007ea19cfcf04b  pinsrb xmm15, r12d, 0x00
00007ea19cfcf052  lea r14, [rax+0x02]
00007ea19cfcf056  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf05c  movaps xmm14, [r15+0x130]
00007ea19cfcf064  pinsrb xmm14, r12d, 0x00
00007ea19cfcf06b  lea r14, [rax+0x03]
00007ea19cfcf06f  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf075  movaps xmm13, [r15+0x140]
00007ea19cfcf07d  pinsrb xmm13, r12d, 0x00
00007ea19cfcf084  lea r14, [rax+0x04]
00007ea19cfcf088  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf08e  pinsrb xmm1, r12d, 0x01
00007ea19cfcf095  lea r14, [rax+0x05]
00007ea19cfcf099  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf09f  pinsrb xmm15, r12d, 0x01
00007ea19cfcf0a6  lea r14, [rax+0x06]
00007ea19cfcf0aa  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf0b0  pinsrb xmm14, r12d, 0x01
00007ea19cfcf0b7  lea r14, [rax+0x07]
00007ea19cfcf0bb  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf0c1  pinsrb xmm13, r12d, 0x01
00007ea19cfcf0c8  lea r14, [rax+0x08]
00007ea19cfcf0cc  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf0d2  pinsrb xmm1, r12d, 0x02
00007ea19cfcf0d9  lea r14, [rax+0x09]
00007ea19cfcf0dd  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf0e3  pinsrb xmm15, r12d, 0x02
00007ea19cfcf0ea  lea r14, [rax+0x0A]
00007ea19cfcf0ee  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf0f4  pinsrb xmm14, r12d, 0x02
00007ea19cfcf0fb  lea r14, [rax+0x0B]
00007ea19cfcf0ff  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf105  pinsrb xmm13, r12d, 0x02
00007ea19cfcf10c  lea r14, [rax+0x0C]
00007ea19cfcf110  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf116  pinsrb xmm1, r12d, 0x03
00007ea19cfcf11d  lea r14, [rax+0x0D]
00007ea19cfcf121  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf127  pinsrb xmm15, r12d, 0x03
00007ea19cfcf12e  lea r14, [rax+0x0E]
00007ea19cfcf132  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf138  pinsrb xmm14, r12d, 0x03
00007ea19cfcf13f  lea r14, [rax+0x0F]
00007ea19cfcf143  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf149  pinsrb xmm13, r12d, 0x03
00007ea19cfcf150  lea r14, [rax+0x10]
00007ea19cfcf154  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf15a  pinsrb xmm1, r12d, 0x04
00007ea19cfcf161  lea r14, [rax+0x11]
00007ea19cfcf165  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf16b  pinsrb xmm15, r12d, 0x04
00007ea19cfcf172  lea r14, [rax+0x12]
00007ea19cfcf176  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf17c  pinsrb xmm14, r12d, 0x04
00007ea19cfcf183  lea r14, [rax+0x13]
00007ea19cfcf187  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf18d  pinsrb xmm13, r12d, 0x04
00007ea19cfcf194  lea r14, [rax+0x14]
00007ea19cfcf198  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf19e  pinsrb xmm1, r12d, 0x05
00007ea19cfcf1a5  lea r14, [rax+0x15]
00007ea19cfcf1a9  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf1af  pinsrb xmm15, r12d, 0x05
00007ea19cfcf1b6  lea r14, [rax+0x16]
00007ea19cfcf1ba  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf1c0  pinsrb xmm14, r12d, 0x05
00007ea19cfcf1c7  lea r14, [rax+0x17]
00007ea19cfcf1cb  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf1d1  pinsrb xmm13, r12d, 0x05
00007ea19cfcf1d8  lea r14, [rax+0x18]
00007ea19cfcf1dc  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf1e2  pinsrb xmm1, r12d, 0x06
00007ea19cfcf1e9  lea r14, [rax+0x19]
00007ea19cfcf1ed  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf1f3  pinsrb xmm15, r12d, 0x06
00007ea19cfcf1fa  lea r14, [rax+0x1A]
00007ea19cfcf1fe  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf204  pinsrb xmm14, r12d, 0x06
00007ea19cfcf20b  lea r14, [rax+0x1B]
00007ea19cfcf20f  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf215  pinsrb xmm13, r12d, 0x06
00007ea19cfcf21c  lea r14, [rax+0x1C]
00007ea19cfcf220  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf226  pinsrb xmm1, r12d, 0x07
00007ea19cfcf22d  lea r14, [rax+0x1D]
00007ea19cfcf231  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf237  pinsrb xmm15, r12d, 0x07
00007ea19cfcf23e  lea r14, [rax+0x1E]
00007ea19cfcf242  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf248  pinsrb xmm14, r12d, 0x07
00007ea19cfcf24f  lea r14, [rax+0x1F]
00007ea19cfcf253  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf259  pinsrb xmm13, r12d, 0x07
00007ea19cfcf260  lea r14, [rax+0x20]
00007ea19cfcf264  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf26a  pinsrb xmm1, r12d, 0x08
00007ea19cfcf271  lea r14, [rax+0x21]
00007ea19cfcf275  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf27b  pinsrb xmm15, r12d, 0x08
00007ea19cfcf282  lea r14, [rax+0x22]
00007ea19cfcf286  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf28c  pinsrb xmm14, r12d, 0x08
00007ea19cfcf293  lea r14, [rax+0x23]
00007ea19cfcf297  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf29d  pinsrb xmm13, r12d, 0x08
00007ea19cfcf2a4  lea r14, [rax+0x24]
00007ea19cfcf2a8  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf2ae  pinsrb xmm1, r12d, 0x09
00007ea19cfcf2b5  lea r14, [rax+0x25]
00007ea19cfcf2b9  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf2bf  pinsrb xmm15, r12d, 0x09
00007ea19cfcf2c6  lea r14, [rax+0x26]
00007ea19cfcf2ca  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf2d0  pinsrb xmm14, r12d, 0x09
00007ea19cfcf2d7  lea r14, [rax+0x27]
00007ea19cfcf2db  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf2e1  pinsrb xmm13, r12d, 0x09
00007ea19cfcf2e8  lea r14, [rax+0x28]
00007ea19cfcf2ec  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf2f2  pinsrb xmm1, r12d, 0x0A
00007ea19cfcf2f9  lea r14, [rax+0x29]
00007ea19cfcf2fd  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf303  pinsrb xmm15, r12d, 0x0A
00007ea19cfcf30a  lea r14, [rax+0x2A]
00007ea19cfcf30e  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf314  pinsrb xmm14, r12d, 0x0A
00007ea19cfcf31b  lea r14, [rax+0x2B]
00007ea19cfcf31f  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf325  pinsrb xmm13, r12d, 0x0A
00007ea19cfcf32c  lea r14, [rax+0x2C]
00007ea19cfcf330  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf336  pinsrb xmm1, r12d, 0x0B
00007ea19cfcf33d  lea r14, [rax+0x2D]
00007ea19cfcf341  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf347  pinsrb xmm15, r12d, 0x0B
00007ea19cfcf34e  lea r14, [rax+0x2E]
00007ea19cfcf352  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf358  pinsrb xmm14, r12d, 0x0B
00007ea19cfcf35f  lea r14, [rax+0x2F]
00007ea19cfcf363  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf369  pinsrb xmm13, r12d, 0x0B
00007ea19cfcf370  lea r14, [rax+0x30]
00007ea19cfcf374  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf37a  pinsrb xmm1, r12d, 0x0C
00007ea19cfcf381  lea r14, [rax+0x31]
00007ea19cfcf385  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf38b  pinsrb xmm15, r12d, 0x0C
00007ea19cfcf392  lea r14, [rax+0x32]
00007ea19cfcf396  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf39c  pinsrb xmm14, r12d, 0x0C
00007ea19cfcf3a3  lea r14, [rax+0x33]
00007ea19cfcf3a7  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf3ad  pinsrb xmm13, r12d, 0x0C
00007ea19cfcf3b4  lea r14, [rax+0x34]
00007ea19cfcf3b8  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf3be  pinsrb xmm1, r12d, 0x0D
00007ea19cfcf3c5  lea r14, [rax+0x35]
00007ea19cfcf3c9  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf3cf  pinsrb xmm15, r12d, 0x0D
00007ea19cfcf3d6  lea r14, [rax+0x36]
00007ea19cfcf3da  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf3e0  pinsrb xmm14, r12d, 0x0D
00007ea19cfcf3e7  lea r14, [rax+0x37]
00007ea19cfcf3eb  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf3f1  pinsrb xmm13, r12d, 0x0D
00007ea19cfcf3f8  lea r14, [rax+0x38]
00007ea19cfcf3fc  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf402  pinsrb xmm1, r12d, 0x0E
00007ea19cfcf409  lea r14, [rax+0x39]
00007ea19cfcf40d  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf413  pinsrb xmm15, r12d, 0x0E
00007ea19cfcf41a  lea r14, [rax+0x3A]
00007ea19cfcf41e  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf424  pinsrb xmm14, r12d, 0x0E
00007ea19cfcf42b  lea r14, [rax+0x3B]
00007ea19cfcf42f  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf435  pinsrb xmm13, r12d, 0x0E
00007ea19cfcf43c  lea r14, [rax+0x3C]
00007ea19cfcf440  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf446  pinsrb xmm1, r12d, 0x0F
00007ea19cfcf44d  movaps [r15+0x110], xmm1
00007ea19cfcf455  lea r14, [rax+0x3D]
00007ea19cfcf459  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf45f  pinsrb xmm15, r12d, 0x0F
00007ea19cfcf466  movaps [r15+0x120], xmm15
00007ea19cfcf46e  lea r14, [rax+0x3E]
00007ea19cfcf472  movzx r12d, byte ptr [r13+r14*1]
00007ea19cfcf478  pinsrb xmm14, r12d, 0x0F
00007ea19cfcf47f  movaps [r15+0x130], xmm14
00007ea19cfcf487  lea r14, [rax+0x3F]
00007ea19cfcf48b  movzx eax, byte ptr [r13+r14*1]
00007ea19cfcf491  pinsrb xmm13, eax, 0x0F
00007ea19cfcf498  movaps [r15+0x140], xmm13
00007ea19cfcf4a0  movq xmm1, qword ptr [r15+0x120]
00007ea19cfcf4a9  pmovzxbw xmm1, xmm1
00007ea19cfcf4ae  psllw xmm1, 0x00
00007ea19cfcf4b3  movaps [r15+0x150], xmm1
00007ea19cfcf4bb  movq xmm1, qword ptr [r15+0x130]
00007ea19cfcf4c4  pmovzxbw xmm1, xmm1
00007ea19cfcf4c9  psllw xmm1, 0x00
00007ea19cfcf4ce  movaps [r15+0x160], xmm1
00007ea19cfcf4d6  movq xmm1, qword ptr [r15+0x110]
00007ea19cfcf4df  pmovzxbw xmm1, xmm1
00007ea19cfcf4e4  psllw xmm1, 0x00
00007ea19cfcf4e9  movaps [r15+0x170], xmm1
00007ea19cfcf4f1  movaps xmm15, [r15+0x110]
00007ea19cfcf4f9  pextrq rax, xmm15, 0x01
00007ea19cfcf500  movq xmm15, rax
00007ea19cfcf505  pmovzxbw xmm15, xmm15
00007ea19cfcf50b  psllw xmm15, 0x00
00007ea19cfcf511  movaps [r15+0x180], xmm15
00007ea19cfcf519  movaps xmm14, [r15+0x120]
00007ea19cfcf521  pextrq rax, xmm14, 0x01
00007ea19cfcf528  movq xmm14, rax
00007ea19cfcf52d  pmovzxbw xmm14, xmm14
00007ea19cfcf533  psllw xmm14, 0x00
00007ea19cfcf539  movaps [r15+0x210], xmm14
00007ea19cfcf541  movaps xmm13, [r15+0x130]
00007ea19cfcf549  pextrq rax, xmm13, 0x01
00007ea19cfcf550  movq xmm13, rax
00007ea19cfcf555  pmovzxbw xmm13, xmm13
00007ea19cfcf55b  psllw xmm13, 0x00
00007ea19cfcf561  movaps [r15+0x220], xmm13
00007ea19cfcf569  movq xmm12, qword ptr [r15+0x140]
00007ea19cfcf572  pmovzxbw xmm12, xmm12
00007ea19cfcf578  psllw xmm12, 0x00
00007ea19cfcf57e  movaps [r15+0x250], xmm12
00007ea19cfcf586  movaps xmm12, [r15+0x140]
00007ea19cfcf58e  pextrq rax, xmm12, 0x01
00007ea19cfcf595  movq xmm12, rax
00007ea19cfcf59a  pmovzxbw xmm12, xmm12
00007ea19cfcf5a0  psllw xmm12, 0x00
00007ea19cfcf5a6  movaps [r15+0x110], xmm12
00007ea19cfcf5ae  movq xmm11, qword ptr [r15+0x150]
00007ea19cfcf5b7  pmovzxwd xmm11, xmm11
00007ea19cfcf5bd  pslld xmm11, 0x10
00007ea19cfcf5c3  movq xmm10, qword ptr [r15+0x160]
00007ea19cfcf5cc  pmovzxwd xmm10, xmm10
00007ea19cfcf5d2  pslld xmm10, 0x08
00007ea19cfcf5d8  pextrq rax, xmm1, 0x01
00007ea19cfcf5df  movq xmm1, rax
00007ea19cfcf5e4  pmovzxwd xmm1, xmm1
00007ea19cfcf5e9  pslld xmm1, 0x00
00007ea19cfcf5ee  movaps [r15+0x260], xmm1
00007ea19cfcf5f6  pextrq rax, xmm15, 0x01
00007ea19cfcf5fd  movq xmm15, rax
00007ea19cfcf602  pmovzxwd xmm15, xmm15
00007ea19cfcf608  pslld xmm15, 0x00
00007ea19cfcf60e  movaps [r15+0x270], xmm15
00007ea19cfcf616  movq xmm9, qword ptr [r15+0x170]
00007ea19cfcf61f  pmovzxwd xmm9, xmm9
00007ea19cfcf625  pslld xmm9, 0x00
00007ea19cfcf62b  pextrq rax, xmm14, 0x01
00007ea19cfcf632  movq xmm14, rax
00007ea19cfcf637  pmovzxwd xmm14, xmm14
00007ea19cfcf63d  pslld xmm14, 0x10
00007ea19cfcf643  movaps [r15+0x280], xmm14
00007ea19cfcf64b  movq xmm8, qword ptr [r15+0x180]
00007ea19cfcf654  pmovzxwd xmm8, xmm8
00007ea19cfcf65a  pslld xmm8, 0x00
00007ea19cfcf660  movq xmm7, qword ptr [r15+0x210]
00007ea19cfcf669  pmovzxwd xmm7, xmm7
00007ea19cfcf66e  pslld xmm7, 0x10
00007ea19cfcf673  movaps xmm6, [r15+0x150]
00007ea19cfcf67b  pextrq rax, xmm6, 0x01
00007ea19cfcf682  movq xmm6, rax
00007ea19cfcf687  pmovzxwd xmm6, xmm6
00007ea19cfcf68c  pslld xmm6, 0x10
00007ea19cfcf691  por xmm11, xmm10
00007ea19cfcf696  movaps [r15+0x230], xmm11
00007ea19cfcf69e  pextrq rax, xmm13, 0x01
00007ea19cfcf6a5  movq xmm13, rax
00007ea19cfcf6aa  pmovzxwd xmm13, xmm13
00007ea19cfcf6b0  pslld xmm13, 0x08
00007ea19cfcf6b6  movaps [r15+0x240], xmm13
00007ea19cfcf6be  movq xmm10, qword ptr [r15+0x220]
00007ea19cfcf6c7  pmovzxwd xmm10, xmm10
00007ea19cfcf6cd  pslld xmm10, 0x08
00007ea19cfcf6d3  movaps xmm5, [r15+0x160]
00007ea19cfcf6db  pextrq rax, xmm5, 0x01
00007ea19cfcf6e2  movq xmm5, rax
00007ea19cfcf6e7  pmovzxwd xmm5, xmm5
00007ea19cfcf6ec  pslld xmm5, 0x08
00007ea19cfcf6f1  pslld xmm9, 0x18
00007ea19cfcf6f7  pslld xmm15, 0x18
00007ea19cfcf6fd  pslld xmm8, 0x18
00007ea19cfcf703  movq xmm4, qword ptr [r15+0x250]
00007ea19cfcf70c  pmovzxwd xmm4, xmm4
00007ea19cfcf711  pslld xmm4, 0x00
00007ea19cfcf716  por xmm14, xmm13
00007ea19cfcf71b  por xmm7, xmm10
00007ea19cfcf720  movaps [r15+0x210], xmm7
00007ea19cfcf728  pslld xmm1, 0x18
00007ea19cfcf72d  movaps [r15+0x220], xmm1
00007ea19cfcf735  por xmm6, xmm5
00007ea19cfcf739  por xmm11, xmm9
00007ea19cfcf73e  movaps [r15+0x160], xmm11
00007ea19cfcf746  pextrq rax, xmm12, 0x01
00007ea19cfcf74d  movq xmm13, rax
00007ea19cfcf752  pmovzxwd xmm13, xmm13
00007ea19cfcf758  pslld xmm13, 0x00
00007ea19cfcf75e  movaps [r15+0x170], xmm13
00007ea19cfcf766  movq xmm12, qword ptr [r15+0x110]
00007ea19cfcf76f  pmovzxwd xmm12, xmm12
00007ea19cfcf775  pslld xmm12, 0x00
00007ea19cfcf77b  por xmm14, xmm15
00007ea19cfcf780  por xmm7, xmm8
00007ea19cfcf785  movaps xmm15, [r15+0x250]
00007ea19cfcf78d  pextrq rax, xmm15, 0x01
00007ea19cfcf794  movq xmm15, rax
00007ea19cfcf799  pmovzxwd xmm15, xmm15
00007ea19cfcf79f  pslld xmm15, 0x00
00007ea19cfcf7a5  movaps [r15+0x180], xmm15
00007ea19cfcf7ad  por xmm6, xmm1
00007ea19cfcf7b1  movaps [r15+0x150], xmm6
00007ea19cfcf7b9  por xmm11, xmm4
00007ea19cfcf7be  movaps [r15+0x140], xmm11
00007ea19cfcf7c6  por xmm7, xmm12
00007ea19cfcf7cb  movaps [r15+0x110], xmm7
00007ea19cfcf7d3  por xmm14, xmm13
00007ea19cfcf7d8  movaps [r15+0x120], xmm14
00007ea19cfcf7e0  por xmm6, xmm15
00007ea19cfcf7e5  movaps [r15+0x130], xmm6
00007ea19cfcf7ed  mov rax, [r15+0xF8]
00007ea19cfcf7f4  lea r14, [rax+0x20]
00007ea19cfcf7f8  movups [r13+r14*1], xmm7
00007ea19cfcf7fe  lea r14, [rax+0x30]
00007ea19cfcf802  movups [r13+r14*1], xmm14
00007ea19cfcf808  movups [r13+rax*1], xmm11
00007ea19cfcf80e  lea r14, [rax+0x10]
00007ea19cfcf812  movups [r13+r14*1], xmm6
00007ea19cfcf818  mov r14d, [r13+rax*1]
00007ea19cfcf81d  mov rax, [r15+0x48]
00007ea19cfcf821  mov [r15+0x68], rax
00007ea19cfcf825  mov qword ptr [r15+0x58], 0x04
00007ea19cfcf82d  lea r12, [rax+0x04]
00007ea19cfcf831  mov r11d, [r13+r12*1]
00007ea19cfcf836  mov [rsp+0x10], r11d
00007ea19cfcf83b  mov r11d, r11d
00007ea19cfcf83e  mov [r15+0x70], r11
00007ea19cfcf842  lea r12, [rax+0x38]
00007ea19cfcf846  mov r11d, [r13+r12*1]
00007ea19cfcf84b  lea r12, [rax+0x24]
00007ea19cfcf84f  mov r10d, [r13+r12*1]
00007ea19cfcf854  mov [rsp+0x20], r10d
00007ea19cfcf859  mov r10d, r10d
00007ea19cfcf85c  mov [r15+0x90], r10
00007ea19cfcf863  mov [rsp+0x30], rax
00007ea19cfcf868  xor eax, eax
00007ea19cfcf86a  mov r12d, 0x04
00007ea19cfcf870  mov r10d, 0xC0
00007ea19cfcf876  cmp r12, r10
00007ea19cfcf879  cmc
00007ea19cfcf87a  lahf
00007ea19cfcf87b  seto al
00007ea19cfcf87e  mov [r15+0x108], eax
00007ea19cfcf885  mov eax, [rsp+0x10]
00007ea19cfcf889  mov r12d, [rsp+0x10]
00007ea19cfcf88e  shrd eax, r12d, 0x07
00007ea19cfcf893  mov [rsp+0x10], r11d
00007ea19cfcf898  mov r10d, [rsp+0x10]
00007ea19cfcf89d  shrd r11d, r10d, 0x11
00007ea19cfcf8a2  mov r9d, [rsp+0x20]
00007ea19cfcf8a7  lea r8d, [r9d+r14d*1]
00007ea19cfcf8ac  rorx r14d, r12d, 0x12
00007ea19cfcf8b2  xor eax, r14d
00007ea19cfcf8b5  rorx r14d, r10d, 0x13
00007ea19cfcf8bb  xor r11d, r14d
00007ea19cfcf8be  mov [rsp+0x10], r11d
00007ea19cfcf8c3  mov r11d, r11d
00007ea19cfcf8c6  mov [r15+0x88], r11
00007ea19cfcf8cd  mov [rsp+0x20], r12d
00007ea19cfcf8d2  shr r12d, 0x03
00007ea19cfcf8d6  xor eax, r12d
00007ea19cfcf8d9  mov [rsp+0x40], eax
00007ea19cfcf8dd  mov eax, eax
00007ea19cfcf8df  mov [r15+0x80], rax
00007ea19cfcf8e6  shr r10d, 0x0A
00007ea19cfcf8ea  mov eax, [rsp+0x10]
00007ea19cfcf8ee  xor eax, r10d
00007ea19cfcf8f1  mov [rsp+0x10], eax
00007ea19cfcf8f5  mov eax, eax
00007ea19cfcf8f7  mov [r15+0x78], rax
00007ea19cfcf8fb  mov eax, [rsp+0x40]
00007ea19cfcf8ff  lea r14d, [r8d+eax*1]
00007ea19cfcf904  mov eax, [rsp+0x10]
00007ea19cfcf908  lea r12d, [r14d+eax*1]
00007ea19cfcf90d  mov rax, [rsp+0x30]
00007ea19cfcf912  lea r14, [rax+0x40]
00007ea19cfcf916  mov [r13+r14*1], r12d
00007ea19cfcf91b  mov eax, [rsp+0x20]
00007ea19cfcf91f  mov eax, eax
00007ea19cfcf921  mov [r15+0x60], rax
00007ea19cfcf925  mov eax, [r15+0x108]
00007ea19cfcf92c  sahf
00007ea19cfcf92d  jnz 0x00007EA19CFCF95F
00007ea19cfcf92f  cmp dword ptr [r15+0x318], 0x00
00007ea19cfcf937  jz 0x00007EA19CFCFE20
00007ea19cfcf93d  nop [rax+rax*1], ax
00007ea19cfcf946  nop [rax+rax*1], eax
00007ea19cfcf94e  mov eax, 0x41049C
00007ea19cfcf953  mov [r15+0x100], rax
00007ea19cfcf95a  jmp 0x00007EA19CDFE110
00007ea19cfcf95f  cmp dword ptr [r15+0x318], 0x00
00007ea19cfcf967  jz 0x00007EA19CFCFC70
00007ea19cfcf96d  nop [rax+rax*1], ax
00007ea19cfcf976  nop [rax+rax*1], eax
00007ea19cfcf97e  mov eax, 0x410454
00007ea19cfcf983  mov [r15+0x100], rax
00007ea19cfcf98a  jmp 0x00007EA19CDFE110
00007ea19cfcf98f  int3
00007ea19cfcf990  call 0x00007EA19CE0D860
00007ea19cfcf995  jmp 0x00007EA19CFCF02A
00007ea19cfcf99a  call 0x00007EA19CEE2420
00007ea19cfcf99f  jmp 0x00007EA19CFCF043
00007ea19cfcf9a4  call 0x00007EA19CEE2420
00007ea19cfcf9a9  jmp 0x00007EA19CFCF05C
00007ea19cfcf9ae  call 0x00007EA19CEE2420
00007ea19cfcf9b3  jmp 0x00007EA19CFCF075
00007ea19cfcf9b8  call 0x00007EA19CEE2420
00007ea19cfcf9bd  jmp 0x00007EA19CFCF08E
00007ea19cfcf9c2  call 0x00007EA19CEE2420
00007ea19cfcf9c7  jmp 0x00007EA19CFCF09F
00007ea19cfcf9cc  call 0x00007EA19CEE2420
00007ea19cfcf9d1  jmp 0x00007EA19CFCF0B0
00007ea19cfcf9d6  call 0x00007EA19CEE2420
00007ea19cfcf9db  jmp 0x00007EA19CFCF0C1
00007ea19cfcf9e0  call 0x00007EA19CEE2420
00007ea19cfcf9e5  jmp 0x00007EA19CFCF0D2
00007ea19cfcf9ea  call 0x00007EA19CEE2420
00007ea19cfcf9ef  jmp 0x00007EA19CFCF0E3
00007ea19cfcf9f4  call 0x00007EA19CEE2420
00007ea19cfcf9f9  jmp 0x00007EA19CFCF0F4
00007ea19cfcf9fe  call 0x00007EA19CEE2420
00007ea19cfcfa03  jmp 0x00007EA19CFCF105
00007ea19cfcfa08  call 0x00007EA19CEE2420
00007ea19cfcfa0d  jmp 0x00007EA19CFCF116
00007ea19cfcfa12  call 0x00007EA19CEE2420
00007ea19cfcfa17  jmp 0x00007EA19CFCF127
00007ea19cfcfa1c  call 0x00007EA19CEE2420
00007ea19cfcfa21  jmp 0x00007EA19CFCF138
00007ea19cfcfa26  call 0x00007EA19CEE2420
00007ea19cfcfa2b  jmp 0x00007EA19CFCF149
00007ea19cfcfa30  call 0x00007EA19CEE2420
00007ea19cfcfa35  jmp 0x00007EA19CFCF15A
00007ea19cfcfa3a  call 0x00007EA19CEE2420
00007ea19cfcfa3f  jmp 0x00007EA19CFCF16B
00007ea19cfcfa44  call 0x00007EA19CEE2420
00007ea19cfcfa49  jmp 0x00007EA19CFCF17C
00007ea19cfcfa4e  call 0x00007EA19CEE2420
00007ea19cfcfa53  jmp 0x00007EA19CFCF18D
00007ea19cfcfa58  call 0x00007EA19CEE2420
00007ea19cfcfa5d  jmp 0x00007EA19CFCF19E
00007ea19cfcfa62  call 0x00007EA19CEE2420
00007ea19cfcfa67  jmp 0x00007EA19CFCF1AF
00007ea19cfcfa6c  call 0x00007EA19CEE2420
00007ea19cfcfa71  jmp 0x00007EA19CFCF1C0
00007ea19cfcfa76  call 0x00007EA19CEE2420
00007ea19cfcfa7b  jmp 0x00007EA19CFCF1D1
00007ea19cfcfa80  call 0x00007EA19CEE2420
00007ea19cfcfa85  jmp 0x00007EA19CFCF1E2
00007ea19cfcfa8a  call 0x00007EA19CEE2420
00007ea19cfcfa8f  jmp 0x00007EA19CFCF1F3
00007ea19cfcfa94  call 0x00007EA19CEE2420
00007ea19cfcfa99  jmp 0x00007EA19CFCF204
00007ea19cfcfa9e  call 0x00007EA19CEE2420
00007ea19cfcfaa3  jmp 0x00007EA19CFCF215
00007ea19cfcfaa8  call 0x00007EA19CEE2420
00007ea19cfcfaad  jmp 0x00007EA19CFCF226
00007ea19cfcfab2  call 0x00007EA19CEE2420
00007ea19cfcfab7  jmp 0x00007EA19CFCF237
00007ea19cfcfabc  call 0x00007EA19CEE2420
00007ea19cfcfac1  jmp 0x00007EA19CFCF248
00007ea19cfcfac6  call 0x00007EA19CEE2420
00007ea19cfcfacb  jmp 0x00007EA19CFCF259
00007ea19cfcfad0  call 0x00007EA19CEE2420
00007ea19cfcfad5  jmp 0x00007EA19CFCF26A
00007ea19cfcfada  call 0x00007EA19CEE2420
00007ea19cfcfadf  jmp 0x00007EA19CFCF27B
00007ea19cfcfae4  call 0x00007EA19CEE2420
00007ea19cfcfae9  jmp 0x00007EA19CFCF28C
00007ea19cfcfaee  call 0x00007EA19CEE2420
00007ea19cfcfaf3  jmp 0x00007EA19CFCF29D
00007ea19cfcfaf8  call 0x00007EA19CEE2420
00007ea19cfcfafd  jmp 0x00007EA19CFCF2AE
00007ea19cfcfb02  call 0x00007EA19CEE2420
00007ea19cfcfb07  jmp 0x00007EA19CFCF2BF
00007ea19cfcfb0c  call 0x00007EA19CEE2420
00007ea19cfcfb11  jmp 0x00007EA19CFCF2D0
00007ea19cfcfb16  call 0x00007EA19CEE2420
00007ea19cfcfb1b  jmp 0x00007EA19CFCF2E1
00007ea19cfcfb20  call 0x00007EA19CEE2420
00007ea19cfcfb25  jmp 0x00007EA19CFCF2F2
00007ea19cfcfb2a  call 0x00007EA19CEE2420
00007ea19cfcfb2f  jmp 0x00007EA19CFCF303
00007ea19cfcfb34  call 0x00007EA19CEE2420
00007ea19cfcfb39  jmp 0x00007EA19CFCF314
00007ea19cfcfb3e  call 0x00007EA19CEE2420
00007ea19cfcfb43  jmp 0x00007EA19CFCF325
00007ea19cfcfb48  call 0x00007EA19CEE2420
00007ea19cfcfb4d  jmp 0x00007EA19CFCF336
00007ea19cfcfb52  call 0x00007EA19CEE2420
00007ea19cfcfb57  jmp 0x00007EA19CFCF347
00007ea19cfcfb5c  call 0x00007EA19CEE2420
00007ea19cfcfb61  jmp 0x00007EA19CFCF358
00007ea19cfcfb66  call 0x00007EA19CEE2420
00007ea19cfcfb6b  jmp 0x00007EA19CFCF369
00007ea19cfcfb70  call 0x00007EA19CEE2420
00007ea19cfcfb75  jmp 0x00007EA19CFCF37A
00007ea19cfcfb7a  call 0x00007EA19CEE2420
00007ea19cfcfb7f  jmp 0x00007EA19CFCF38B
00007ea19cfcfb84  call 0x00007EA19CEE2420
00007ea19cfcfb89  jmp 0x00007EA19CFCF39C
00007ea19cfcfb8e  call 0x00007EA19CEE2420
00007ea19cfcfb93  jmp 0x00007EA19CFCF3AD
00007ea19cfcfb98  call 0x00007EA19CEE2420
00007ea19cfcfb9d  jmp 0x00007EA19CFCF3BE
00007ea19cfcfba2  call 0x00007EA19CEE2420
00007ea19cfcfba7  jmp 0x00007EA19CFCF3CF
00007ea19cfcfbac  call 0x00007EA19CEE2420
00007ea19cfcfbb1  jmp 0x00007EA19CFCF3E0
00007ea19cfcfbb6  call 0x00007EA19CEE2420
00007ea19cfcfbbb  jmp 0x00007EA19CFCF3F1
00007ea19cfcfbc0  call 0x00007EA19CEE2420
00007ea19cfcfbc5  jmp 0x00007EA19CFCF402
00007ea19cfcfbca  call 0x00007EA19CEE2420
00007ea19cfcfbcf  jmp 0x00007EA19CFCF413
00007ea19cfcfbd4  call 0x00007EA19CEE2420
00007ea19cfcfbd9  jmp 0x00007EA19CFCF424
00007ea19cfcfbde  call 0x00007EA19CEE2420
00007ea19cfcfbe3  jmp 0x00007EA19CFCF435
00007ea19cfcfbe8  call 0x00007EA19CEE2420
00007ea19cfcfbed  jmp 0x00007EA19CFCF446
00007ea19cfcfbf2  call 0x00007EA19CEE2420
00007ea19cfcfbf7  jmp 0x00007EA19CFCF45F
00007ea19cfcfbfc  call 0x00007EA19CEE2420
00007ea19cfcfc01  jmp 0x00007EA19CFCF478
00007ea19cfcfc06  call 0x00007EA19CED5610
00007ea19cfcfc0b  jmp 0x00007EA19CFCF491
00007ea19cfcfc10  call 0x00007EA19CEDC580
00007ea19cfcfc15  jmp 0x00007EA19CFCF7FE
00007ea19cfcfc1a  call 0x00007EA19CEE46C0
00007ea19cfcfc1f  jmp 0x00007EA19CFCF808
00007ea19cfcfc24  call 0x00007EA19CE09E90
00007ea19cfcfc29  jmp 0x00007EA19CFCF80E
00007ea19cfcfc2e  call 0x00007EA19CEDB310
00007ea19cfcfc33  jmp 0x00007EA19CFCF818
00007ea19cfcfc38  call 0x00007EA19CE0DAE0
00007ea19cfcfc3d  jmp 0x00007EA19CFCF81D
00007ea19cfcfc42  call 0x00007EA19CEC0230
00007ea19cfcfc47  jmp 0x00007EA19CFCF836
00007ea19cfcfc4c  call 0x00007EA19CEC0230
00007ea19cfcfc51  jmp 0x00007EA19CFCF84B
00007ea19cfcfc56  call 0x00007EA19CEBEFC0
00007ea19cfcfc5b  jmp 0x00007EA19CFCF854
00007ea19cfcfc60  call 0x00007EA19CEE2BA0
00007ea19cfcfc65  jmp 0x00007EA19CFCF91B
00007ea19cfcfc6a  int3
00007ea19cfcfc6b  nop [rax+rax*1], eax
00007ea19cfcfc70  mov rax, [r15+0x48]
00007ea19cfcfc74  mov r14, [r15+0x58]
00007ea19cfcfc78  lea r12, [rax+r14*1]
00007ea19cfcfc7c  mov [r15+0x68], r12
00007ea19cfcfc80  lea rax, [r14+0x04]
00007ea19cfcfc84  mov [r15+0x58], rax
00007ea19cfcfc88  lea r14, [r12+0x04]
00007ea19cfcfc8d  mov r11d, [r13+r14*1]
00007ea19cfcfc92  mov [rsp+0x10], r11d
00007ea19cfcfc97  mov r11d, r11d
00007ea19cfcfc9a  mov [r15+0x70], r11
00007ea19cfcfc9e  lea r14, [r12+0x38]
00007ea19cfcfca3  mov r11d, [r13+r14*1]
00007ea19cfcfca8  lea r14, [r12+0x24]
00007ea19cfcfcad  mov r10d, [r13+r14*1]
00007ea19cfcfcb2  mov [rsp+0x20], r10d
00007ea19cfcfcb7  mov r10d, r10d
00007ea19cfcfcba  mov [r15+0x90], r10
00007ea19cfcfcc1  mov [rsp+0x30], rax
00007ea19cfcfcc6  xor eax, eax
00007ea19cfcfcc8  mov r14, [rsp+0x30]
00007ea19cfcfccd  mov r10d, 0xC0
00007ea19cfcfcd3  cmp r14, r10
00007ea19cfcfcd6  cmc
00007ea19cfcfcd7  lahf
00007ea19cfcfcd8  seto al
00007ea19cfcfcdb  mov [r15+0x108], eax
00007ea19cfcfce2  mov eax, [rsp+0x10]
00007ea19cfcfce6  mov r14d, [rsp+0x10]
00007ea19cfcfceb  shrd eax, r14d, 0x07
00007ea19cfcfcf0  mov [rsp+0x10], r11d
00007ea19cfcfcf5  mov r10d, [rsp+0x10]
00007ea19cfcfcfa  shrd r11d, r10d, 0x11
00007ea19cfcfcff  mov r9d, [r15+0x60]
00007ea19cfcfd03  mov r8d, [rsp+0x20]
00007ea19cfcfd08  lea ebp, [r8d+r9d*1]
00007ea19cfcfd0d  rorx r9d, r14d, 0x12
00007ea19cfcfd13  xor eax, r9d
00007ea19cfcfd16  rorx r9d, r10d, 0x13
00007ea19cfcfd1c  xor r11d, r9d
00007ea19cfcfd1f  mov [rsp+0x10], r11d
00007ea19cfcfd24  mov r11d, r11d
00007ea19cfcfd27  mov [r15+0x88], r11
00007ea19cfcfd2e  mov [rsp+0x20], r14d
00007ea19cfcfd33  shr r14d, 0x03
00007ea19cfcfd37  xor eax, r14d
00007ea19cfcfd3a  mov [rsp+0x30], eax
00007ea19cfcfd3e  mov eax, eax
00007ea19cfcfd40  mov [r15+0x80], rax
00007ea19cfcfd47  shr r10d, 0x0A
00007ea19cfcfd4b  mov eax, [rsp+0x10]
00007ea19cfcfd4f  xor eax, r10d
00007ea19cfcfd52  mov [rsp+0x10], eax
00007ea19cfcfd56  mov eax, eax
00007ea19cfcfd58  mov [r15+0x78], rax
00007ea19cfcfd5c  mov eax, [rsp+0x30]
00007ea19cfcfd60  lea r14d, [ebp+eax*1]
00007ea19cfcfd66  mov eax, [rsp+0x10]
00007ea19cfcfd6a  lea r11d, [r14d+eax*1]
00007ea19cfcfd6f  lea rax, [r12+0x40]
00007ea19cfcfd74  mov [r13+rax*1], r11d
00007ea19cfcfd79  mov eax, [rsp+0x20]
00007ea19cfcfd7d  mov eax, eax
00007ea19cfcfd7f  mov [r15+0x60], rax
00007ea19cfcfd83  mov eax, [r15+0x108]
00007ea19cfcfd8a  sahf
00007ea19cfcfd8b  jnz 0x00007EA19CFCFDBD
00007ea19cfcfd8d  cmp dword ptr [r15+0x318], 0x00
00007ea19cfcfd95  jz 0x00007EA19CFCFE20
00007ea19cfcfd9b  nop [rax+rax*1], ax
00007ea19cfcfda4  nop [rax+rax*1], eax
00007ea19cfcfdac  mov eax, 0x41049C
00007ea19cfcfdb1  mov [r15+0x100], rax
00007ea19cfcfdb8  jmp 0x00007EA19CDFE110
00007ea19cfcfdbd  cmp dword ptr [r15+0x318], 0x00
00007ea19cfcfdc5  jz 0x00007EA19CFCFC70
00007ea19cfcfdcb  nop [rax+rax*1], ax
00007ea19cfcfdd4  nop [rax+rax*1], eax
00007ea19cfcfddc  mov eax, 0x410454
00007ea19cfcfde1  mov [r15+0x100], rax
00007ea19cfcfde8  jmp 0x00007EA19CDFE110
00007ea19cfcfded  int3
00007ea19cfcfdee  call 0x00007EA19CEE1430
00007ea19cfcfdf3  jmp 0x00007EA19CFCFC92
00007ea19cfcfdf8  call 0x00007EA19CEE1430
00007ea19cfcfdfd  jmp 0x00007EA19CFCFCA8
00007ea19cfcfe02  call 0x00007EA19CEE01C0
00007ea19cfcfe07  jmp 0x00007EA19CFCFCB2
00007ea19cfcfe0c  call 0x00007EA19CE0A860
00007ea19cfcfe11  jmp 0x00007EA19CFCFD79
00007ea19cfcfe16  int3
00007ea19cfcfe17  nop [rax+rax*1], ax
00007ea19cfcfe20  mov rax, [r15]
00007ea19cfcfe23  mov r14d, [r13+rax*1]
00007ea19cfcfe28  lea r12, [rax+0x04]
00007ea19cfcfe2c  mov r11d, [r13+r12*1]
00007ea19cfcfe31  mov [rsp+0x10], r14d
00007ea19cfcfe36  mov r14d, r14d
00007ea19cfcfe39  mov [r15+0x78], r14
00007ea19cfcfe3d  mov [rsp+0x20], r11d
00007ea19cfcfe42  mov r11d, r11d
00007ea19cfcfe45  mov [r15+0x80], r11
00007ea19cfcfe4c  lea r14, [rax+0x08]
00007ea19cfcfe50  mov r12d, [r13+r14*1]
00007ea19cfcfe55  lea r14, [rax+0x0C]
00007ea19cfcfe59  mov r11d, [r13+r14*1]
00007ea19cfcfe5e  mov [rsp+0x30], r12d
00007ea19cfcfe63  mov r12d, r12d
00007ea19cfcfe66  mov [r15+0x70], r12
00007ea19cfcfe6a  mov [rsp+0x40], r11d
00007ea19cfcfe6f  mov r11d, r11d
00007ea19cfcfe72  mov [r15+0x68], r11
00007ea19cfcfe76  lea r14, [rax+0x18]
00007ea19cfcfe7a  mov r12d, [r13+r14*1]
00007ea19cfcfe7f  lea r14, [rax+0x1C]
00007ea19cfcfe83  mov r11d, [r13+r14*1]
00007ea19cfcfe88  mov [rsp+0x50], r12d
00007ea19cfcfe8d  mov r12d, r12d
00007ea19cfcfe90  mov [r15+0x58], r12
00007ea19cfcfe94  mov [rsp+0x60], r11d
00007ea19cfcfe99  mov r11d, r11d
00007ea19cfcfe9c  mov [r15+0x60], r11
00007ea19cfcfea0  lea r14, [rax+0x10]
00007ea19cfcfea4  mov r12d, [r13+r14*1]
00007ea19cfcfea9  lea r14, [rax+0x14]
00007ea19cfcfead  mov eax, [r13+r14*1]
00007ea19cfcfeb2  mov [rsp+0x70], r12d
00007ea19cfcfeb7  mov r12d, r12d
00007ea19cfcfeba  mov [r15+0x18], r12
00007ea19cfcfebe  mov [rsp+0x80], eax
00007ea19cfcfec5  mov eax, eax
00007ea19cfcfec7  mov [r15+0x90], rax
00007ea19cfcfece  mov eax, [rsp+0x70]
00007ea19cfcfed2  mov eax, eax
00007ea19cfcfed4  mov [r15+0x30], rax
00007ea19cfcfed8  mov eax, [rsp+0x50]
00007ea19cfcfedc  mov eax, eax
00007ea19cfcfede  mov [r15+0xA0], rax
00007ea19cfcfee5  mov eax, [rsp+0x30]
00007ea19cfcfee9  mov eax, eax
00007ea19cfcfeeb  mov [r15+0x28], rax
00007ea19cfcfeef  mov eax, [rsp+0x20]
00007ea19cfcfef3  mov eax, eax
00007ea19cfcfef5  mov [r15+0x98], rax
00007ea19cfcfefc  mov eax, [rsp+0x10]
00007ea19cfcff00  mov eax, eax
00007ea19cfcff02  mov [r15+0x38], rax
00007ea19cfcff06  mov eax, [rsp+0x70]
00007ea19cfcff0a  mov r14d, [rsp+0x70]
00007ea19cfcff0f  shrd eax, r14d, 0x06
00007ea19cfcff14  mov [rsp+0x70], r14d
00007ea19cfcff19  mov r12d, [rsp+0x80]
00007ea19cfcff21  and r14d, r12d
00007ea19cfcff24  mov r11d, [rsp+0x10]
00007ea19cfcff29  mov r10d, [rsp+0x10]
00007ea19cfcff2e  shrd r11d, r10d, 0x02
00007ea19cfcff33  mov [rsp+0x10], r12d
00007ea19cfcff38  mov r12d, r12d
00007ea19cfcff3b  mov [r15+0x20], r12
00007ea19cfcff3f  mov r12, [r15+0x50]
00007ea19cfcff43  mov r9d, [r13+r12*1]
00007ea19cfcff48  mov r12d, [rsp+0x50]
00007ea19cfcff4d  mov r8d, [rsp+0x70]
00007ea19cfcff52  andn ebp, r8d, r12d
00007ea19cfcff57  mov edi, [rsp+0x60]
00007ea19cfcff5b  lea esi, [r14d+edi*1]
00007ea19cfcff60  rorx r14d, r8d, 0x0B
00007ea19cfcff66  xor eax, r14d
00007ea19cfcff69  rorx r14d, r10d, 0x0D
00007ea19cfcff6f  xor r11d, r14d
00007ea19cfcff72  lea edi, [esi+ebp*1]
00007ea19cfcff76  mov r14, [r15+0x48]
00007ea19cfcff7a  mov ebp, [r13+r14*1]
00007ea19cfcff7f  mov r14d, [rsp+0x30]
00007ea19cfcff84  mov esi, [rsp+0x20]
00007ea19cfcff88  and r14d, esi
00007ea19cfcff8b  mov [rsp+0x20], r14d
00007ea19cfcff90  mov r14d, r14d
00007ea19cfcff93  mov [r15+0xD8], r14
00007ea19cfcff9a  lea r14d, [edi+r9d*1]
00007ea19cfcff9f  mov r9d, [rsp+0x30]
00007ea19cfcffa4  xor r9d, esi
00007ea19cfcffa7  rorx edi, r8d, 0x19
00007ea19cfcffad  xor eax, edi
00007ea19cfcffaf  and r9d, r10d
00007ea19cfcffb2  rorx edi, r10d, 0x16
00007ea19cfcffb8  xor r11d, edi
00007ea19cfcffbb  mov [rsp+0x30], r11d
00007ea19cfcffc0  mov r11d, r11d
00007ea19cfcffc3  mov [r15+0xD0], r11
00007ea19cfcffca  lea r11d, [r14d+ebp*1]
00007ea19cfcffcf  mov r10d, [rsp+0x20]
00007ea19cfcffd4  xor r9d, r10d
00007ea19cfcffd7  lea r14d, [r11d+eax*1]
00007ea19cfcffdc  mov qword ptr [r15+0x88], 0x04
00007ea19cfcffe7  mov eax, [rsp+0x30]
00007ea19cfcffeb  lea r11d, [r9d+eax*1]
00007ea19cfcfff0  mov eax, [rsp+0x40]
00007ea19cfcfff4  lea r10d, [r14d+eax*1]
00007ea19cfcfff9  mov r10d, r10d
00007ea19cfcfffc  mov [r15+0xB8], r10
00007ea19cfd0003  xor eax, eax
00007ea19cfd0005  mov r10d, 0x04
00007ea19cfd000b  mov r9d, 0x100
00007ea19cfd0011  cmp r10, r9
00007ea19cfd0014  cmc
00007ea19cfd0015  lahf
00007ea19cfd0016  seto al
00007ea19cfd0019  mov [r15+0x108], eax
00007ea19cfd0020  lea eax, [r11d+r14d*1]
00007ea19cfd0025  mov eax, eax
00007ea19cfd0027  mov [r15+0xA8], rax
00007ea19cfd002e  mov r12d, r12d
00007ea19cfd0031  mov [r15+0xB0], r12
00007ea19cfd0038  mov eax, [rsp+0x10]
00007ea19cfd003c  mov eax, eax
00007ea19cfd003e  mov [r15+0xC0], rax
00007ea19cfd0045  mov r8d, r8d
00007ea19cfd0048  mov [r15+0xC8], r8
00007ea19cfd004f  mov eax, [r15+0x108]
00007ea19cfd0056  sahf
00007ea19cfd0057  jnz 0x00007EA19CFD0089
00007ea19cfd0059  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd0061  jz 0x00007EA19CFD0350
00007ea19cfd0067  nop [rax+rax*1], ax
00007ea19cfd0070  nop [rax+rax*1], eax
00007ea19cfd0078  mov eax, 0x41055C
00007ea19cfd007d  mov [r15+0x100], rax
00007ea19cfd0084  jmp 0x00007EA19CDFE110
00007ea19cfd0089  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd0091  jz 0x00007EA19CFD0120
00007ea19cfd0097  nop [rax+rax*1], ax
00007ea19cfd00a0  nop [rax+rax*1], eax
00007ea19cfd00a8  mov eax, 0x4104D0
00007ea19cfd00ad  mov [r15+0x100], rax
00007ea19cfd00b4  jmp 0x00007EA19CDFE110
00007ea19cfd00b9  int3
00007ea19cfd00ba  call 0x00007EA19CE0DAE0
00007ea19cfd00bf  jmp 0x00007EA19CFCFE28
00007ea19cfd00c4  call 0x00007EA19CEC0230
00007ea19cfd00c9  jmp 0x00007EA19CFCFE31
00007ea19cfd00ce  call 0x00007EA19CEE26A0
00007ea19cfd00d3  jmp 0x00007EA19CFCFE55
00007ea19cfd00d8  call 0x00007EA19CEE1430
00007ea19cfd00dd  jmp 0x00007EA19CFCFE5E
00007ea19cfd00e2  call 0x00007EA19CEE26A0
00007ea19cfd00e7  jmp 0x00007EA19CFCFE7F
00007ea19cfd00ec  call 0x00007EA19CEE1430
00007ea19cfd00f1  jmp 0x00007EA19CFCFE88
00007ea19cfd00f6  call 0x00007EA19CEE26A0
00007ea19cfd00fb  jmp 0x00007EA19CFCFEA9
00007ea19cfd0100  call 0x00007EA19CED5890
00007ea19cfd0105  jmp 0x00007EA19CFCFEB2
00007ea19cfd010a  call 0x00007EA19CEBDD50
00007ea19cfd010f  jmp 0x00007EA19CFCFF48
00007ea19cfd0114  call 0x00007EA19CEDA580
00007ea19cfd0119  jmp 0x00007EA19CFCFF7F
00007ea19cfd011e  int3
00007ea19cfd011f  nop
00007ea19cfd0120  mov eax, [r15+0xB8]
00007ea19cfd0127  mov [rsp+0x10], eax
00007ea19cfd012b  mov eax, eax
00007ea19cfd012d  mov [r15+0x30], rax
00007ea19cfd0131  mov eax, [r15+0xC0]
00007ea19cfd0138  mov [rsp+0x20], eax
00007ea19cfd013c  mov eax, eax
00007ea19cfd013e  mov [r15+0xA0], rax
00007ea19cfd0145  mov eax, [r15+0x28]
00007ea19cfd0149  mov r14d, [r15+0x98]
00007ea19cfd0150  mov [rsp+0x30], r14d
00007ea19cfd0155  mov r14d, r14d
00007ea19cfd0158  mov [r15+0x28], r14
00007ea19cfd015c  mov r14d, [r15+0x38]
00007ea19cfd0160  mov [rsp+0x40], r14d
00007ea19cfd0165  mov r14d, r14d
00007ea19cfd0168  mov [r15+0x98], r14
00007ea19cfd016f  mov r14d, [r15+0xA8]
00007ea19cfd0176  mov [rsp+0x50], r14d
00007ea19cfd017b  mov r14d, r14d
00007ea19cfd017e  mov [r15+0x38], r14
00007ea19cfd0182  mov r14d, [rsp+0x10]
00007ea19cfd0187  mov r12d, [rsp+0x10]
00007ea19cfd018c  shrd r14d, r12d, 0x06
00007ea19cfd0191  mov r11d, [r15+0xC8]
00007ea19cfd0198  mov [rsp+0x10], r12d
00007ea19cfd019d  and r12d, r11d
00007ea19cfd01a0  mov r10d, [rsp+0x50]
00007ea19cfd01a5  mov r9d, [rsp+0x50]
00007ea19cfd01aa  shrd r10d, r9d, 0x02
00007ea19cfd01af  mov [rsp+0x50], r11d
00007ea19cfd01b4  mov r11d, r11d
00007ea19cfd01b7  mov [r15+0x20], r11
00007ea19cfd01bb  mov r11, [r15+0x88]
00007ea19cfd01c2  mov r8, [r15+0x50]
00007ea19cfd01c6  lea rbp, [r8+r11*1]
00007ea19cfd01ca  mov r8d, [r13+rbp*1]
00007ea19cfd01cf  mov ebp, [rsp+0x20]
00007ea19cfd01d3  mov edi, [rsp+0x10]
00007ea19cfd01d7  andn esi, edi, ebp
00007ea19cfd01dc  mov edx, [r15+0xB0]
00007ea19cfd01e3  lea ecx, [r12d+edx*1]
00007ea19cfd01e8  rorx r12d, edi, 0x0B
00007ea19cfd01ee  xor r14d, r12d
00007ea19cfd01f1  rorx r12d, r9d, 0x0D
00007ea19cfd01f7  xor r10d, r12d
00007ea19cfd01fa  lea r12d, [ecx+esi*1]
00007ea19cfd01ff  mov rsi, [r15+0x48]
00007ea19cfd0203  lea rdx, [rsi+r11*1]
00007ea19cfd0207  mov esi, [r13+rdx*1]
00007ea19cfd020c  mov edx, [rsp+0x30]
00007ea19cfd0210  mov ecx, [rsp+0x40]
00007ea19cfd0214  and edx, ecx
00007ea19cfd0216  mov [rsp+0x10], edx
00007ea19cfd021a  mov edx, edx
00007ea19cfd021c  mov [r15+0xD8], rdx
00007ea19cfd0223  lea edx, [r12d+r8d*1]
00007ea19cfd0228  mov r12d, [rsp+0x30]
00007ea19cfd022d  xor r12d, ecx
00007ea19cfd0230  rorx r8d, edi, 0x19
00007ea19cfd0236  xor r14d, r8d
00007ea19cfd0239  and r12d, r9d
00007ea19cfd023c  rorx r8d, r9d, 0x16
00007ea19cfd0242  xor r10d, r8d
00007ea19cfd0245  mov [rsp+0x20], r10d
00007ea19cfd024a  mov r10d, r10d
00007ea19cfd024d  mov [r15+0xD0], r10
00007ea19cfd0254  lea r10d, [edx+esi*1]
00007ea19cfd0259  mov r9d, [rsp+0x10]
00007ea19cfd025e  xor r12d, r9d
00007ea19cfd0261  lea r9d, [r10d+r14d*1]
00007ea19cfd0266  lea r14, [r11+0x04]
00007ea19cfd026a  mov [r15+0x88], r14
00007ea19cfd0271  mov r11d, [rsp+0x20]
00007ea19cfd0276  lea r10d, [r12d+r11d*1]
00007ea19cfd027b  lea r11d, [r9d+eax*1]
00007ea19cfd0280  mov r11d, r11d
00007ea19cfd0283  mov [r15+0xB8], r11
00007ea19cfd028a  xor eax, eax
00007ea19cfd028c  mov r12d, 0x100
00007ea19cfd0292  cmp r14, r12
00007ea19cfd0295  cmc
00007ea19cfd0296  lahf
00007ea19cfd0297  seto al
00007ea19cfd029a  mov [r15+0x108], eax
00007ea19cfd02a1  lea eax, [r10d+r9d*1]
00007ea19cfd02a6  mov eax, eax
00007ea19cfd02a8  mov [r15+0xA8], rax
00007ea19cfd02af  mov ebp, ebp
00007ea19cfd02b1  mov [r15+0xB0], rbp
00007ea19cfd02b8  mov eax, [rsp+0x50]
00007ea19cfd02bc  mov eax, eax
00007ea19cfd02be  mov [r15+0xC0], rax
00007ea19cfd02c5  mov edi, edi
00007ea19cfd02c7  mov [r15+0xC8], rdi
00007ea19cfd02ce  mov eax, [r15+0x108]
00007ea19cfd02d5  sahf
00007ea19cfd02d6  jnz 0x00007EA19CFD0308
00007ea19cfd02d8  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd02e0  jz 0x00007EA19CFD0350
00007ea19cfd02e6  nop [rax+rax*1], ax
00007ea19cfd02ef  nop [rax+rax*1], eax
00007ea19cfd02f7  mov eax, 0x41055C
00007ea19cfd02fc  mov [r15+0x100], rax
00007ea19cfd0303  jmp 0x00007EA19CDFE110
00007ea19cfd0308  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd0310  jz 0x00007EA19CFD0120
00007ea19cfd0316  nop [rax+rax*1], ax
00007ea19cfd031f  nop [rax+rax*1], eax
00007ea19cfd0327  mov eax, 0x4104D0
00007ea19cfd032c  mov [r15+0x100], rax
00007ea19cfd0333  jmp 0x00007EA19CDFE110
00007ea19cfd0338  int3
00007ea19cfd0339  call 0x00007EA19CE49010
00007ea19cfd033e  jmp 0x00007EA19CFD01CF
00007ea19cfd0343  call 0x00007EA19CE25930
00007ea19cfd0348  jmp 0x00007EA19CFD020C
00007ea19cfd034d  int3
00007ea19cfd034e  nop
00007ea19cfd0350  mov eax, [r15+0x98]
00007ea19cfd0357  mov r14d, [r15+0x70]
00007ea19cfd035b  lea r12d, [eax+r14d*1]
00007ea19cfd0360  mov eax, [r15+0x28]
00007ea19cfd0364  mov r14d, [r15+0x68]
00007ea19cfd0368  lea r11d, [eax+r14d*1]
00007ea19cfd036d  mov qword ptr [r15+0x88], 0x00
00007ea19cfd0378  mov eax, [r15+0xA8]
00007ea19cfd037f  mov r14d, [r15+0x78]
00007ea19cfd0383  lea r10d, [eax+r14d*1]
00007ea19cfd0388  mov [rsp+0x10], r10d
00007ea19cfd038d  mov r10d, r10d
00007ea19cfd0390  mov [r15+0x78], r10
00007ea19cfd0394  mov eax, [r15+0x38]
00007ea19cfd0398  mov r14d, [r15+0x80]
00007ea19cfd039f  lea r10d, [eax+r14d*1]
00007ea19cfd03a4  mov [rsp+0x20], r10d
00007ea19cfd03a9  mov r10d, r10d
00007ea19cfd03ac  mov [r15+0x80], r10
00007ea19cfd03b3  mov rax, [r15]
00007ea19cfd03b6  lea r14, [rax+0x08]
00007ea19cfd03ba  mov [r13+r14*1], r12d
00007ea19cfd03bf  lea r14, [rax+0x0C]
00007ea19cfd03c3  mov [r13+r14*1], r11d
00007ea19cfd03c8  mov r14d, [r15+0xB8]
00007ea19cfd03cf  mov r12d, [r15+0x18]
00007ea19cfd03d3  lea r11d, [r14d+r12d*1]
00007ea19cfd03d8  mov [rsp+0x30], r11d
00007ea19cfd03dd  mov r11d, r11d
00007ea19cfd03e0  mov [r15+0x68], r11
00007ea19cfd03e4  mov r14d, [r15+0x30]
00007ea19cfd03e8  mov r12d, [r15+0x90]
00007ea19cfd03ef  lea r11d, [r14d+r12d*1]
00007ea19cfd03f4  mov [rsp+0x40], r11d
00007ea19cfd03f9  mov r11d, r11d
00007ea19cfd03fc  mov [r15+0x70], r11
00007ea19cfd0400  mov r14d, [r15+0x20]
00007ea19cfd0404  mov r12d, [r15+0x58]
00007ea19cfd0408  lea r11d, [r14d+r12d*1]
00007ea19cfd040d  mov [rsp+0x50], r11d
00007ea19cfd0412  mov r11d, r11d
00007ea19cfd0415  mov [r15+0x58], r11
00007ea19cfd0419  mov r14d, [r15+0xA0]
00007ea19cfd0420  mov r12d, [r15+0x60]
00007ea19cfd0424  lea r11d, [r14d+r12d*1]
00007ea19cfd0429  mov [rsp+0x60], r11d
00007ea19cfd042e  mov r11d, r11d
00007ea19cfd0431  mov [r15+0x60], r11
00007ea19cfd0435  mov r14d, [rsp+0x10]
00007ea19cfd043a  mov [r13+rax*1], r14d
00007ea19cfd043f  lea r14, [rax+0x04]
00007ea19cfd0443  mov r12d, [rsp+0x20]
00007ea19cfd0448  mov [r13+r14*1], r12d
00007ea19cfd044d  lea r14, [rax+0x10]
00007ea19cfd0451  mov r12d, [rsp+0x30]
00007ea19cfd0456  mov [r13+r14*1], r12d
00007ea19cfd045b  lea r14, [rax+0x14]
00007ea19cfd045f  mov r12d, [rsp+0x40]
00007ea19cfd0464  mov [r13+r14*1], r12d
00007ea19cfd0469  lea r14, [rax+0x18]
00007ea19cfd046d  mov r12d, [rsp+0x50]
00007ea19cfd0472  mov [r13+r14*1], r12d
00007ea19cfd0477  lea r14, [rax+0x1C]
00007ea19cfd047b  mov r12d, [rsp+0x60]
00007ea19cfd0480  mov [r13+r14*1], r12d
00007ea19cfd0485  lea r14, [rax+0x68]
00007ea19cfd0489  xor eax, eax
00007ea19cfd048b  mov [r13+r14*1], rax
00007ea19cfd0490  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd0498  jz 0x00007EA19CFCEF90
00007ea19cfd049e  nop [rax+rax*1], ax
00007ea19cfd04a7  nop [rax+rax*1], eax
00007ea19cfd04af  mov eax, 0x410378
00007ea19cfd04b4  mov [r15+0x100], rax
00007ea19cfd04bb  jmp 0x00007EA19CDFE110
00007ea19cfd04c0  int3
00007ea19cfd04c1  call 0x00007EA19CEE2BA0
00007ea19cfd04c6  jmp 0x00007EA19CFD03BF
00007ea19cfd04cb  call 0x00007EA19CEE1920
00007ea19cfd04d0  jmp 0x00007EA19CFD03C8
00007ea19cfd04d5  call 0x00007EA19CE0DFE0
00007ea19cfd04da  jmp 0x00007EA19CFD043F
00007ea19cfd04df  call 0x00007EA19CEE2BA0
00007ea19cfd04e4  jmp 0x00007EA19CFD044D
00007ea19cfd04e9  call 0x00007EA19CEE2BA0
00007ea19cfd04ee  jmp 0x00007EA19CFD045B
00007ea19cfd04f3  call 0x00007EA19CEE2BA0
00007ea19cfd04f8  jmp 0x00007EA19CFD0469
00007ea19cfd04fd  call 0x00007EA19CEE2BA0
00007ea19cfd0502  jmp 0x00007EA19CFD0477
00007ea19cfd0507  call 0x00007EA19CEE2BA0
00007ea19cfd050c  jmp 0x00007EA19CFD0485
00007ea19cfd0511  call 0x00007EA19CED5EB0
00007ea19cfd0516  jmp 0x00007EA19CFD0490
00007ea19cfd051b  int3
00007ea19cfd051c  nop [rax], eax
00007ea19cfd0520  mov rax, [r15+0xF8]
00007ea19cfd0527  lea r14, [rax+0x140]
00007ea19cfd052e  mov r12, [r13+r14*1]
00007ea19cfd0533  lea r14, [rax+0x148]
00007ea19cfd053a  mov r11, [r13+r14*1]
00007ea19cfd053f  mov [r15+0xA0], r12
00007ea19cfd0546  mov [r15+0x98], r11
00007ea19cfd054d  lea r14, [rax+0x130]
00007ea19cfd0554  mov r12, [r13+r14*1]
00007ea19cfd0559  lea r14, [rax+0x138]
00007ea19cfd0560  mov r11, [r13+r14*1]
00007ea19cfd0565  mov [r15+0xB0], r12
00007ea19cfd056c  mov [r15+0xA8], r11
00007ea19cfd0573  lea r14, [rax+0x120]
00007ea19cfd057a  mov r12, [r13+r14*1]
00007ea19cfd057f  lea r14, [rax+0x128]
00007ea19cfd0586  mov r11, [r13+r14*1]
00007ea19cfd058b  mov [r15+0xC0], r12
00007ea19cfd0592  mov [r15+0xB8], r11
00007ea19cfd0599  lea r14, [rax+0x110]
00007ea19cfd05a0  mov r12, [r13+r14*1]
00007ea19cfd05a5  lea r14, [rax+0x118]
00007ea19cfd05ac  mov r11, [r13+r14*1]
00007ea19cfd05b1  mov [r15+0xD0], r12
00007ea19cfd05b8  mov [r15+0xC8], r11
00007ea19cfd05bf  lea r14, [rax+0x100]
00007ea19cfd05c6  mov r12, [r13+r14*1]
00007ea19cfd05cb  lea r14, [rax+0x108]
00007ea19cfd05d2  mov r11, [r13+r14*1]
00007ea19cfd05d7  mov [r15+0xE8], r12
00007ea19cfd05de  mov [r15+0xD8], r11
00007ea19cfd05e5  lea r14, [rax+0x150]
00007ea19cfd05ec  mov [r15+0xF8], r14
00007ea19cfd05f3  mov rax, [r15+0xF0]
00007ea19cfd05fa  mov [r15+0x100], rax
00007ea19cfd0601  jmp 0x00007EA19CFCE5C0
00007ea19cfd0606  int3
00007ea19cfd0607  call 0x00007EA19CEE27E0
00007ea19cfd060c  jmp 0x00007EA19CFD0533
00007ea19cfd0611  call 0x00007EA19CEE1570
00007ea19cfd0616  jmp 0x00007EA19CFD053F
00007ea19cfd061b  call 0x00007EA19CEE27E0
00007ea19cfd0620  jmp 0x00007EA19CFD0559
00007ea19cfd0625  call 0x00007EA19CEE1570
00007ea19cfd062a  jmp 0x00007EA19CFD0565
00007ea19cfd062f  call 0x00007EA19CEE27E0
00007ea19cfd0634  jmp 0x00007EA19CFD057F
00007ea19cfd0639  call 0x00007EA19CEE1570
00007ea19cfd063e  jmp 0x00007EA19CFD058B
00007ea19cfd0643  call 0x00007EA19CEE27E0
00007ea19cfd0648  jmp 0x00007EA19CFD05A5
00007ea19cfd064d  call 0x00007EA19CEE1570
00007ea19cfd0652  jmp 0x00007EA19CFD05B1
00007ea19cfd0657  call 0x00007EA19CEE27E0
00007ea19cfd065c  jmp 0x00007EA19CFD05CB
00007ea19cfd0661  call 0x00007EA19CEE1570
00007ea19cfd0666  jmp 0x00007EA19CFD05D7
00007ea19cfd066b  int3
00007ea19cfd066c  nop [rax], eax
00007ea19cfd0670  mov eax, [r15+0xA0]
00007ea19cfd0677  mov [rsp+0x10], eax
00007ea19cfd067b  xor eax, eax
00007ea19cfd067d  mov r14d, [rsp+0x10]
00007ea19cfd0682  sub r14d, 0x01
00007ea19cfd0686  cmc
00007ea19cfd0687  lahf
00007ea19cfd0688  seto al
00007ea19cfd068b  mov [r15+0x108], eax
00007ea19cfd0692  mov r14d, r14d
00007ea19cfd0695  mov [r15+0xA0], r14
00007ea19cfd069c  mov eax, [r15+0x108]
00007ea19cfd06a3  sahf
00007ea19cfd06a4  jnz 0x00007EA19CFD06D6
00007ea19cfd06a6  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd06ae  jz 0x00007EA19CFD07A0
00007ea19cfd06b4  nop [rax+rax*1], ax
00007ea19cfd06bd  nop [rax+rax*1], eax
00007ea19cfd06c5  mov eax, 0x41027C
00007ea19cfd06ca  mov [r15+0x100], rax
00007ea19cfd06d1  jmp 0x00007EA19CDFE110
00007ea19cfd06d6  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd06de  jz 0x00007EA19CFD0710
00007ea19cfd06e4  nop [rax+rax*1], ax
00007ea19cfd06ed  nop [rax+rax*1], eax
00007ea19cfd06f5  mov eax, 0x410264
00007ea19cfd06fa  mov [r15+0x100], rax
00007ea19cfd0701  jmp 0x00007EA19CDFE110
00007ea19cfd0706  int3
00007ea19cfd0707  int3
00007ea19cfd0708  nop [rax+rax*1], eax
00007ea19cfd0710  mov rax, [r15+0xF8]
00007ea19cfd0717  mov [r15], rax
00007ea19cfd071a  mov rax, [r15+0x98]
00007ea19cfd0721  mov [r15+0x08], rax
00007ea19cfd0725  mov qword ptr [r15+0x10], 0x12C
00007ea19cfd072d  mov qword ptr [r15+0xF0], 0x410274
00007ea19cfd0738  mov r14d, [r15+0x320]
00007ea19cfd073f  mov eax, 0x410274
00007ea19cfd0744  mov rcx, 0x7EA19CFD0670
00007ea19cfd074e  mov [r15+r14*8+0x328], rax
00007ea19cfd0756  mov [r15+r14*8+0x368], rcx
00007ea19cfd075e  add r14d, 0x01
00007ea19cfd0762  and r14d, 0x07
00007ea19cfd0766  mov [r15+0x320], r14d
00007ea19cfd076d  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd0775  jz 0x00007EA19CFCEC20
00007ea19cfd077b  nop [rax+rax*1], ax
00007ea19cfd0784  nop [rax+rax*1], eax
00007ea19cfd078c  mov eax, 0x410338
00007ea19cfd0791  mov [r15+0x100], rax
00007ea19cfd0798  jmp 0x00007EA19CDFE110
00007ea19cfd079d  int3
00007ea19cfd079e  int3
00007ea19cfd079f  nop
00007ea19cfd07a0  mov rax, [r15+0xF8]
00007ea19cfd07a7  lea r14, [rax+0x20]
00007ea19cfd07ab  mov r12, [r13+r14*1]
00007ea19cfd07b0  mov [r15+0x98], r12
00007ea19cfd07b7  mov qword ptr [r15+0x40], 0x80
00007ea19cfd07bf  mov [r15], rax
00007ea19cfd07c2  lea r14, [rax+0x8C]
00007ea19cfd07c9  mov [r15+0x08], r14
00007ea19cfd07cd  mov qword ptr [r15+0x10], 0x01
00007ea19cfd07d5  lea r14, [rax+0x8C]
00007ea19cfd07dc  mov eax, 0x80
00007ea19cfd07e1  mov [r13+r14*1], al
00007ea19cfd07e6  mov qword ptr [r15+0xF0], 0x410298
00007ea19cfd07f1  mov r14d, [r15+0x320]
00007ea19cfd07f8  mov eax, 0x410298
00007ea19cfd07fd  mov rcx, 0x7EA19CFD0870
00007ea19cfd0807  mov [r15+r14*8+0x328], rax
00007ea19cfd080f  mov [r15+r14*8+0x368], rcx
00007ea19cfd0817  add r14d, 0x01
00007ea19cfd081b  and r14d, 0x07
00007ea19cfd081f  mov [r15+0x320], r14d
00007ea19cfd0826  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd082e  jz 0x00007EA19CFCEC20
00007ea19cfd0834  nop [rax+rax*1], ax
00007ea19cfd083d  nop [rax+rax*1], eax
00007ea19cfd0845  mov eax, 0x410338
00007ea19cfd084a  mov [r15+0x100], rax
00007ea19cfd0851  jmp 0x00007EA19CDFE110
00007ea19cfd0856  int3
00007ea19cfd0857  call 0x00007EA19CEE27E0
00007ea19cfd085c  jmp 0x00007EA19CFD07B0
00007ea19cfd0861  call 0x00007EA19CED5AF0
00007ea19cfd0866  jmp 0x00007EA19CFD07E6
00007ea19cfd086b  int3
00007ea19cfd086c  nop [rax], eax
00007ea19cfd0870  mov rax, [r15+0xF8]
00007ea19cfd0877  lea r14, [rax+0x68]
00007ea19cfd087b  mov r12, [r13+r14*1]
00007ea19cfd0880  mov [r15+0x40], r12
00007ea19cfd0884  lea r14, [rax+0x88]
00007ea19cfd088b  xor eax, eax
00007ea19cfd088d  mov [r13+r14*1], al
00007ea19cfd0892  xor eax, eax
00007ea19cfd0894  mov r14d, 0x38
00007ea19cfd089a  cmp r12, r14
00007ea19cfd089d  cmc
00007ea19cfd089e  lahf
00007ea19cfd089f  seto al
00007ea19cfd08a2  mov [r15+0x108], eax
00007ea19cfd08a9  mov eax, [r15+0x108]
00007ea19cfd08b0  sahf
00007ea19cfd08b1  jz 0x00007EA19CFD08E3
00007ea19cfd08b3  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd08bb  jz 0x00007EA19CFD0930
00007ea19cfd08c1  nop [rax+rax*1], ax
00007ea19cfd08ca  nop [rax+rax*1], eax
00007ea19cfd08d2  mov eax, 0x4102A8
00007ea19cfd08d7  mov [r15+0x100], rax
00007ea19cfd08de  jmp 0x00007EA19CDFE110
00007ea19cfd08e3  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd08eb  jz 0x00007EA19CFD0A70
00007ea19cfd08f1  nop [rax+rax*1], ax
00007ea19cfd08fa  nop [rax+rax*1], eax
00007ea19cfd0902  mov eax, 0x4102C4
00007ea19cfd0907  mov [r15+0x100], rax
00007ea19cfd090e  jmp 0x00007EA19CDFE110
00007ea19cfd0913  int3
00007ea19cfd0914  call 0x00007EA19CEE27E0
00007ea19cfd0919  jmp 0x00007EA19CFD0880
00007ea19cfd091e  call 0x00007EA19CED5AF0
00007ea19cfd0923  jmp 0x00007EA19CFD0892
00007ea19cfd0928  int3
00007ea19cfd0929  nop [rax], eax
00007ea19cfd0930  mov rax, [r15+0xF8]
00007ea19cfd0937  mov [r15], rax
00007ea19cfd093a  lea r14, [rax+0x88]
00007ea19cfd0941  mov [r15+0x08], r14
00007ea19cfd0945  mov qword ptr [r15+0x10], 0x01
00007ea19cfd094d  mov qword ptr [r15+0xF0], 0x4102B8
00007ea19cfd0958  mov r14d, [r15+0x320]
00007ea19cfd095f  mov eax, 0x4102B8
00007ea19cfd0964  mov rcx, 0x7EA19CFD09C0
00007ea19cfd096e  mov [r15+r14*8+0x328], rax
00007ea19cfd0976  mov [r15+r14*8+0x368], rcx
00007ea19cfd097e  add r14d, 0x01
00007ea19cfd0982  and r14d, 0x07
00007ea19cfd0986  mov [r15+0x320], r14d
00007ea19cfd098d  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd0995  jz 0x00007EA19CFCEC20
00007ea19cfd099b  nop [rax+rax*1], ax
00007ea19cfd09a4  nop [rax+rax*1], eax
00007ea19cfd09ac  mov eax, 0x410338
00007ea19cfd09b1  mov [r15+0x100], rax
00007ea19cfd09b8  jmp 0x00007EA19CDFE110
00007ea19cfd09bd  int3
00007ea19cfd09be  int3
00007ea19cfd09bf  nop
00007ea19cfd09c0  mov rax, [r15+0xF8]
00007ea19cfd09c7  lea r14, [rax+0x68]
00007ea19cfd09cb  mov rax, [r13+r14*1]
00007ea19cfd09d0  mov [r15+0x40], rax
00007ea19cfd09d4  mov [rsp+0x10], rax
00007ea19cfd09d9  xor eax, eax
00007ea19cfd09db  mov r14, [rsp+0x10]
00007ea19cfd09e0  mov r12d, 0x38
00007ea19cfd09e6  cmp r14, r12
00007ea19cfd09e9  cmc
00007ea19cfd09ea  lahf
00007ea19cfd09eb  seto al
00007ea19cfd09ee  mov [r15+0x108], eax
00007ea19cfd09f5  mov eax, [r15+0x108]
00007ea19cfd09fc  sahf
00007ea19cfd09fd  jnz 0x00007EA19CFD0A2F
00007ea19cfd09ff  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd0a07  jz 0x00007EA19CFD0A70
00007ea19cfd0a0d  nop [rax+rax*1], ax
00007ea19cfd0a16  nop [rax+rax*1], eax
00007ea19cfd0a1e  mov eax, 0x4102C4
00007ea19cfd0a23  mov [r15+0x100], rax
00007ea19cfd0a2a  jmp 0x00007EA19CDFE110
00007ea19cfd0a2f  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd0a37  jz 0x00007EA19CFD0930
00007ea19cfd0a3d  nop [rax+rax*1], ax
00007ea19cfd0a46  nop [rax+rax*1], eax
00007ea19cfd0a4e  mov eax, 0x4102A8
00007ea19cfd0a53  mov [r15+0x100], rax
00007ea19cfd0a5a  jmp 0x00007EA19CDFE110
00007ea19cfd0a5f  int3
00007ea19cfd0a60  call 0x00007EA19CED59C0
00007ea19cfd0a65  jmp 0x00007EA19CFD09D0
00007ea19cfd0a6a  int3
00007ea19cfd0a6b  nop [rax+rax*1], eax
00007ea19cfd0a70  mov rax, [r15+0x98]
00007ea19cfd0a77  rorx r14, rax, 0x3D
00007ea19cfd0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007ea19cfd0a81  mov rax, [r15+0xF8]
00007ea19cfd0a88  mov [r15], rax
00007ea19cfd0a8b  lea r12, [rax+0x78]
00007ea19cfd0a8f  mov [r15+0x08], r12
00007ea19cfd0a93  mov qword ptr [r15+0x10], 0x08
00007ea19cfd0a9b  bswap r14
00007ea19cfd0a9e  mov [r15+0x40], r14
00007ea19cfd0aa2  lea r12, [rax+0x78]
00007ea19cfd0aa6  mov [r13+r12*1], r14
00007ea19cfd0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007ea19cfd0ab6  mov r14d, [r15+0x320]
00007ea19cfd0abd  mov eax, 0x4102E0
00007ea19cfd0ac2  mov rcx, 0x7EA19CFD0B30
00007ea19cfd0acc  mov [r15+r14*8+0x328], rax
00007ea19cfd0ad4  mov [r15+r14*8+0x368], rcx
00007ea19cfd0adc  add r14d, 0x01
00007ea19cfd0ae0  and r14d, 0x07
00007ea19cfd0ae4  mov [r15+0x320], r14d
00007ea19cfd0aeb  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd0af3  jz 0x00007EA19CFCEC20
00007ea19cfd0af9  nop [rax+rax*1], ax
00007ea19cfd0b02  nop [rax+rax*1], eax
00007ea19cfd0b0a  mov eax, 0x410338
00007ea19cfd0b0f  mov [r15+0x100], rax
00007ea19cfd0b16  jmp 0x00007EA19CDFE110
00007ea19cfd0b1b  int3
00007ea19cfd0b1c  call 0x00007EA19CEC3FE0
00007ea19cfd0b21  jmp 0x00007EA19CFD0AAB
00007ea19cfd0b26  int3
00007ea19cfd0b27  nop [rax+rax*1], ax
00007ea19cfd0b30  mov rax, [r15+0xF8]
00007ea19cfd0b37  mov r14d, [r13+rax*1]
00007ea19cfd0b3c  lea r12, [rax+0x04]
00007ea19cfd0b40  mov r11d, [r13+r12*1]
00007ea19cfd0b45  lea r12, [rax+0x08]
00007ea19cfd0b49  mov r10d, [r13+r12*1]
00007ea19cfd0b4e  lea r12, [rax+0x0C]
00007ea19cfd0b52  mov r9d, [r13+r12*1]
00007ea19cfd0b57  mov qword ptr [r15+0x48], 0x430860
00007ea19cfd0b5f  lea r12, [rax+0x80]
00007ea19cfd0b66  mov r8, [r13+r12*1]
00007ea19cfd0b6b  mov [r15+0xF0], r8
00007ea19cfd0b72  bswap r14d
00007ea19cfd0b75  bswap r11d
00007ea19cfd0b78  mov r12d, 0x430860
00007ea19cfd0b7e  mov [r13+r12*1], r14d
00007ea19cfd0b83  mov r14d, 0x430864
00007ea19cfd0b89  mov [r13+r14*1], r11d
00007ea19cfd0b8e  bswap r10d
00007ea19cfd0b91  bswap r9d
00007ea19cfd0b94  lea r14, [rax+0x10]
00007ea19cfd0b98  mov r12d, [r13+r14*1]
00007ea19cfd0b9d  lea r14, [rax+0x14]
00007ea19cfd0ba1  mov r11d, [r13+r14*1]
00007ea19cfd0ba6  mov r14d, 0x430868
00007ea19cfd0bac  mov [r13+r14*1], r10d
00007ea19cfd0bb1  mov r14d, 0x43086C
00007ea19cfd0bb7  mov [r13+r14*1], r9d
00007ea19cfd0bbc  lea r14, [rax+0x90]
00007ea19cfd0bc3  mov r10, [r13+r14*1]
00007ea19cfd0bc8  lea r14, [rax+0x98]
00007ea19cfd0bcf  mov r9, [r13+r14*1]
00007ea19cfd0bd4  mov [r15+0xA0], r10
00007ea19cfd0bdb  mov [r15+0x98], r9
00007ea19cfd0be2  bswap r12d
00007ea19cfd0be5  bswap r11d
00007ea19cfd0be8  mov [rsp+0x10], r11d
00007ea19cfd0bed  mov r11d, r11d
00007ea19cfd0bf0  mov [r15+0x58], r11
00007ea19cfd0bf4  lea r14, [rax+0x18]
00007ea19cfd0bf8  mov r11d, [r13+r14*1]
00007ea19cfd0bfd  lea r14, [rax+0x1C]
00007ea19cfd0c01  mov r10d, [r13+r14*1]
00007ea19cfd0c06  mov [rsp+0x20], r10d
00007ea19cfd0c0b  mov r10d, r10d
00007ea19cfd0c0e  mov [r15+0x60], r10
00007ea19cfd0c12  mov r14d, 0x430870
00007ea19cfd0c18  mov [r13+r14*1], r12d
00007ea19cfd0c1d  mov r14d, 0x430874
00007ea19cfd0c23  mov r12d, [rsp+0x10]
00007ea19cfd0c28  mov [r13+r14*1], r12d
00007ea19cfd0c2d  bswap r11d
00007ea19cfd0c30  mov [rsp+0x10], r11d
00007ea19cfd0c35  mov r11d, r11d
00007ea19cfd0c38  mov [r15+0x40], r11
00007ea19cfd0c3c  mov r14d, [rsp+0x20]
00007ea19cfd0c41  bswap r14d
00007ea19cfd0c44  mov [rsp+0x20], r14d
00007ea19cfd0c49  mov r14d, r14d
00007ea19cfd0c4c  mov [r15+0x50], r14
00007ea19cfd0c50  mov r14d, 0x430878
00007ea19cfd0c56  mov r12d, [rsp+0x10]
00007ea19cfd0c5b  mov [r13+r14*1], r12d
00007ea19cfd0c60  mov r14d, 0x43087C
00007ea19cfd0c66  mov r12d, [rsp+0x20]
00007ea19cfd0c6b  mov [r13+r14*1], r12d
00007ea19cfd0c70  lea r14, [rax+0xA0]
00007ea19cfd0c77  mov [r15+0xF8], r14
00007ea19cfd0c7e  mov [r15+0x100], r8
00007ea19cfd0c85  jmp 0x00007EA19CFCE5C0
00007ea19cfd0c8a  int3
00007ea19cfd0c8b  call 0x00007EA19CE0DAE0
00007ea19cfd0c90  jmp 0x00007EA19CFD0B3C
00007ea19cfd0c95  call 0x00007EA19CEC0230
00007ea19cfd0c9a  jmp 0x00007EA19CFD0B45
00007ea19cfd0c9f  call 0x00007EA19CEBEFC0
00007ea19cfd0ca4  jmp 0x00007EA19CFD0B4E
00007ea19cfd0ca9  call 0x00007EA19CEBDD50
00007ea19cfd0cae  jmp 0x00007EA19CFD0B57
00007ea19cfd0cb3  call 0x00007EA19CEBCC20
00007ea19cfd0cb8  jmp 0x00007EA19CFD0B6B
00007ea19cfd0cbd  call 0x00007EA19CEC3EA0
00007ea19cfd0cc2  jmp 0x00007EA19CFD0B83
00007ea19cfd0cc7  call 0x00007EA19CEE1920
00007ea19cfd0ccc  jmp 0x00007EA19CFD0B8E
00007ea19cfd0cd1  call 0x00007EA19CEE26A0
00007ea19cfd0cd6  jmp 0x00007EA19CFD0B9D
00007ea19cfd0cdb  call 0x00007EA19CEE1430
00007ea19cfd0ce0  jmp 0x00007EA19CFD0BA6
00007ea19cfd0ce5  call 0x00007EA19CEE06B0
00007ea19cfd0cea  jmp 0x00007EA19CFD0BB1
00007ea19cfd0cef  call 0x00007EA19CEDF440
00007ea19cfd0cf4  jmp 0x00007EA19CFD0BBC
00007ea19cfd0cf9  call 0x00007EA19CEE0300
00007ea19cfd0cfe  jmp 0x00007EA19CFD0BC8
00007ea19cfd0d03  call 0x00007EA19CEDF090
00007ea19cfd0d08  jmp 0x00007EA19CFD0BD4
00007ea19cfd0d0d  call 0x00007EA19CEE1430
00007ea19cfd0d12  jmp 0x00007EA19CFD0BFD
00007ea19cfd0d17  call 0x00007EA19CEE01C0
00007ea19cfd0d1c  jmp 0x00007EA19CFD0C06
00007ea19cfd0d21  call 0x00007EA19CEE2BA0
00007ea19cfd0d26  jmp 0x00007EA19CFD0C1D
00007ea19cfd0d2b  call 0x00007EA19CEE2BA0
00007ea19cfd0d30  jmp 0x00007EA19CFD0C2D
00007ea19cfd0d35  call 0x00007EA19CEE2BA0
00007ea19cfd0d3a  jmp 0x00007EA19CFD0C60
00007ea19cfd0d3f  call 0x00007EA19CEE2BA0
00007ea19cfd0d44  jmp 0x00007EA19CFD0C70
00007ea19cfd0d49  int3
00007ea19cfd0d4a  nop [rax+rax*1], ax
00007ea19cfd0d50  mov qword ptr [r15+0x100], 0x04
00007ea19cfd0d5b  mov esi, 0x00
00007ea19cfd0d60  mov edx, 0x09
00007ea19cfd0d65  mov rdi, 0x7FFC9EFEF2C0
00007ea19cfd0d6f  mov rax, 0x592FAF82E970
00007ea19cfd0d79  call rax
00007ea19cfd0d7b  cmp dword ptr [r15+0x318], 0x00
00007ea19cfd0d83  jnz 0x00007EA19CDFE110
00007ea19cfd0d89  jmp 0x00007EA19CDFE0A0
00007ea19cfd0d8e  int3
00007ea19cfd0d8f  int3
