00007bbd89bce69b  nop [rax+rax*1], eax
00007bbd89bce6a0  mov qword ptr [r15+0x20], 0x420060
00007bbd89bce6a8  mov eax, 0x420060
00007bbd89bce6ad  xor r14d, r14d
00007bbd89bce6b0  mov [r13+rax*1], r14
00007bbd89bce6b5  mov eax, 0x420060
00007bbd89bce6ba  mov r14, [r13+rax*1]
00007bbd89bce6bf  mov [r15+0x18], r14
00007bbd89bce6c3  lea rax, [r14+0x03]
00007bbd89bce6c7  mov [r15], rax
00007bbd89bce6ca  xor eax, eax
00007bbd89bce6cc  mov r14d, 0xB71B00
00007bbd89bce6d2  mov r12d, 0x01
00007bbd89bce6d8  sub r14, r12
00007bbd89bce6db  cmc
00007bbd89bce6dc  lahf
00007bbd89bce6dd  seto al
00007bbd89bce6e0  mov [r15+0x108], eax
00007bbd89bce6e7  mov [r15+0x08], r14
00007bbd89bce6eb  mov eax, [r15+0x108]
00007bbd89bce6f2  sahf
00007bbd89bce6f3  jnz 0x00007BBD89BCE725
00007bbd89bce6f5  cmp dword ptr [r15+0x318], 0x00
00007bbd89bce6fd  jz 0x00007BBD89BCE840
00007bbd89bce703  nop [rax+rax*1], ax
00007bbd89bce70c  nop [rax+rax*1], eax
00007bbd89bce714  mov eax, 0x410050
00007bbd89bce719  mov [r15+0x100], rax
00007bbd89bce720  jmp 0x00007BBD899FE110
00007bbd89bce725  cmp dword ptr [r15+0x318], 0x00
00007bbd89bce72d  jz 0x00007BBD89BCE770
00007bbd89bce733  nop [rax+rax*1], ax
00007bbd89bce73c  nop [rax+rax*1], eax
00007bbd89bce744  mov eax, 0x41003C
00007bbd89bce749  mov [r15+0x100], rax
00007bbd89bce750  jmp 0x00007BBD899FE110
00007bbd89bce755  int3
00007bbd89bce756  call 0x00007BBD89A0E120
00007bbd89bce75b  jmp 0x00007BBD89BCE6B5
00007bbd89bce760  call 0x00007BBD89A0DC20
00007bbd89bce765  jmp 0x00007BBD89BCE6BF
00007bbd89bce76a  int3
00007bbd89bce76b  nop [rax+rax*1], eax
00007bbd89bce770  mov rax, [r15+0x20]
00007bbd89bce774  mov r14, [r15]
00007bbd89bce777  mov [r13+rax*1], r14
00007bbd89bce77c  mov r14, [r13+rax*1]
00007bbd89bce781  mov [r15+0x18], r14
00007bbd89bce785  lea rax, [r14+0x03]
00007bbd89bce789  mov [r15], rax
00007bbd89bce78c  mov rax, [r15+0x08]
00007bbd89bce790  mov [rsp+0x10], rax
00007bbd89bce795  xor eax, eax
00007bbd89bce797  mov r14, [rsp+0x10]
00007bbd89bce79c  mov r12d, 0x01
00007bbd89bce7a2  sub r14, r12
00007bbd89bce7a5  cmc
00007bbd89bce7a6  lahf
00007bbd89bce7a7  seto al
00007bbd89bce7aa  mov [r15+0x108], eax
00007bbd89bce7b1  mov [r15+0x08], r14
00007bbd89bce7b5  mov eax, [r15+0x108]
00007bbd89bce7bc  sahf
00007bbd89bce7bd  jnz 0x00007BBD89BCE7EF
00007bbd89bce7bf  cmp dword ptr [r15+0x318], 0x00
00007bbd89bce7c7  jz 0x00007BBD89BCE840
00007bbd89bce7cd  nop [rax+rax*1], ax
00007bbd89bce7d6  nop [rax+rax*1], eax
00007bbd89bce7de  mov eax, 0x410050
00007bbd89bce7e3  mov [r15+0x100], rax
00007bbd89bce7ea  jmp 0x00007BBD899FE110
00007bbd89bce7ef  cmp dword ptr [r15+0x318], 0x00
00007bbd89bce7f7  jz 0x00007BBD89BCE770
00007bbd89bce7fd  nop [rax+rax*1], ax
00007bbd89bce806  nop [rax+rax*1], eax
00007bbd89bce80e  mov eax, 0x41003C
00007bbd89bce813  mov [r15+0x100], rax
00007bbd89bce81a  jmp 0x00007BBD899FE110
00007bbd89bce81f  int3
00007bbd89bce820  call 0x00007BBD89A0E120
00007bbd89bce825  jmp 0x00007BBD89BCE77C
00007bbd89bce82a  call 0x00007BBD89A0DC20
00007bbd89bce82f  jmp 0x00007BBD89BCE781
00007bbd89bce834  int3
00007bbd89bce835  nop [rax+rax*1], ax
00007bbd89bce83e  nop
00007bbd89bce840  mov rax, [r15+0x20]
00007bbd89bce844  mov r14, [r15]
00007bbd89bce847  mov [r13+rax*1], r14
00007bbd89bce84c  mov rax, [r15+0xF0]
00007bbd89bce853  mov [r15+0x100], rax
00007bbd89bce85a  jmp 0x00007BBD89BCE5C0
00007bbd89bce85f  int3
00007bbd89bce860  call 0x00007BBD89A0E120
00007bbd89bce865  jmp 0x00007BBD89BCE84C
00007bbd89bce86a  int3
00007bbd89bce86b  nop [rax+rax*1], eax
00007bbd89bce870  mov qword ptr [r15+0x100], 0x04
00007bbd89bce87b  mov esi, 0x00
00007bbd89bce880  mov edx, 0x09
00007bbd89bce885  mov rdi, 0x7FFFEAD28870
00007bbd89bce88f  mov rax, 0x634BFF530970
00007bbd89bce899  call rax
00007bbd89bce89b  cmp dword ptr [r15+0x318], 0x00
00007bbd89bce8a3  jnz 0x00007BBD899FE110
00007bbd89bce8a9  jmp 0x00007BBD899FE0A0
00007bbd89bce8ae  int3
00007bbd89bce8af  int3
