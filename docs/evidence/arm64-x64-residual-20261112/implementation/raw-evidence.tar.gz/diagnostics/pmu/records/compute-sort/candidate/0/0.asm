
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-sort/candidate/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xf8]
  18:	sub    r13,0x20
  1c:	mov    r14,QWORD PTR [r12+0xf0]
  24:	mov    QWORD PTR [r13+0x0],r14
  28:	mov    r14d,0x0
  2e:	mov    DWORD PTR [r12+0x32c],r14d
  36:	mov    QWORD PTR [r12+0xf8],r13
  3e:	add    r13,0x10
  42:	mov    r14,r13
  45:	add    r14,0x8
  49:	mov    r15,QWORD PTR [r12+0xa0]
  51:	mov    rbp,QWORD PTR [r12+0x98]
  59:	mov    QWORD PTR [r13+0x0],r15
  5d:	mov    QWORD PTR [r14],rbp
  60:	mov    r13d,0x0
  66:	mov    QWORD PTR [r12+0xa0],r13
  6e:	mov    r13d,0x420000
  74:	add    r13,0x2a0
  7b:	mov    QWORD PTR [r12+0x98],r13
  83:	mov    r13d,0x11
  89:	mov    QWORD PTR [r12],r13
  8d:	mov    r13d,0x410184
  93:	mov    QWORD PTR [r12+0xf0],r13
  9b:	mov    r13d,0x41021c
  a1:	mov    QWORD PTR [r12+0x100],r13
  a9:	mov    r11,QWORD PTR [rsp]
  ad:	mov    QWORD PTR [r12+0x398],r11
  b5:	mov    edi,0x41021c
  ba:	mov    QWORD PTR [r12+0x100],rdi
  c2:	add    rsp,0x10
  c6:	xchg   ax,ax
  c8:	jmp    QWORD PTR [rip+0x2]        # 0xd0
  ce:	xchg   ax,ax
  d0:	lock loopne 0xa2
  d3:	popf
  d4:	loope  0x155
  d6:	add    BYTE PTR [rax],al
  d8:	loopne 0xba
  da:	iret
  db:	popf
  dc:	loope  0x15d
  de:	add    BYTE PTR [rax],al
  e0:	movabs r11,0x5c931c45a940
  ea:	jmp    r11
  ed:	nop
  ee:	nop
  ef:	nop
