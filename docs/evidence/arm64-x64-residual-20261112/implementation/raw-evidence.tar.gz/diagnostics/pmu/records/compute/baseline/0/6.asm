
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute/baseline/0/6.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13d,DWORD PTR [r12]
  14:	mov    r14d,r13d
  17:	mov    r14d,r14d
  1a:	shr    r14d,0x10
  1e:	mov    ecx,r14d
  21:	xor    r13,rcx
  24:	mov    r13d,r13d
  27:	mov    QWORD PTR [r12+0x40],r13
  2c:	mov    r14d,0x352d
  32:	mov    QWORD PTR [r12+0x48],r14
  37:	mov    r14d,0x352d
  3d:	mov    r15d,0x7feb
  43:	and    r15d,0xffff
  4a:	mov    rax,r14
  4d:	movabs rcx,0xffffffff0000ffff
  57:	and    rax,rcx
  5a:	mov    rdx,r15
  5d:	shl    rdx,0x10
  61:	mov    ecx,0xffff0000
  66:	and    rdx,rcx
  69:	or     rax,rdx
  6c:	mov    ebp,eax
  6e:	mov    QWORD PTR [r12+0x48],rbp
  73:	mov    r14d,0x0
  79:	mov    eax,r13d
  7c:	mov    ecx,ebp
  7e:	imul   rax,rcx
  82:	mov    r15d,eax
  85:	mov    ecx,r15d
  88:	mov    r13d,r14d
  8b:	add    r13d,ecx
  8e:	mov    QWORD PTR [r12+0x40],r13
  93:	mov    r14d,0xa68b
  99:	mov    QWORD PTR [r12+0x48],r14
  9e:	mov    r14d,0xa68b
  a4:	mov    r15d,0x846c
  aa:	and    r15d,0xffff
  b1:	mov    rax,r14
  b4:	movabs rcx,0xffffffff0000ffff
  be:	and    rax,rcx
  c1:	mov    rdx,r15
  c4:	shl    rdx,0x10
  c8:	mov    ecx,0xffff0000
  cd:	and    rdx,rcx
  d0:	or     rax,rdx
  d3:	mov    ebp,eax
  d5:	mov    QWORD PTR [r12+0x48],rbp
  da:	mov    r14d,r13d
  dd:	mov    r14d,r14d
  e0:	shr    r14d,0xf
  e4:	mov    ecx,r14d
  e7:	xor    r13,rcx
  ea:	mov    r13d,r13d
  ed:	mov    QWORD PTR [r12+0x40],r13
  f2:	mov    r14d,0x0
  f8:	mov    eax,r13d
  fb:	mov    ecx,ebp
  fd:	imul   rax,rcx
 101:	mov    r15d,eax
 104:	mov    ecx,r15d
 107:	mov    r13d,r14d
 10a:	add    r13d,ecx
 10d:	mov    QWORD PTR [r12+0x40],r13
 112:	mov    r14d,r13d
 115:	mov    r14d,r14d
 118:	shr    r14d,0x10
 11c:	mov    ecx,r14d
 11f:	xor    r13,rcx
 122:	mov    r13d,r13d
 125:	mov    QWORD PTR [r12],r13
 129:	mov    rcx,QWORD PTR [r12+0x380]
 131:	jrcxz  0x138
 133:	jmp    0x16d
 138:	mov    r13,QWORD PTR [r12+0xf0]
 140:	mov    QWORD PTR [r12+0x100],r13
 148:	mov    r11,QWORD PTR [rsp]
 14c:	mov    QWORD PTR [r12+0x398],r11
 154:	mov    rdi,QWORD PTR [r12+0x100]
 15c:	add    rsp,0x10
 160:	movabs r11,0x57780bcbe0a0
 16a:	jmp    r11
 16d:	mov    eax,0x4109c8
 172:	mov    QWORD PTR [r12+0x100],rax
 17a:	push   rdx
 17b:	push   rsi
 17c:	push   r10
 17e:	push   r11
 180:	mov    rdx,QWORD PTR [rsp+0x20]
 185:	mov    r10d,edx
 188:	and    r10d,0xc0
 18f:	shl    r10d,0x18
 193:	mov    r11d,edx
 196:	and    r11d,0x1
 19a:	shl    r11d,0x1d
 19e:	or     r10d,r11d
 1a1:	mov    r11d,edx
 1a4:	and    r11d,0x800
 1ab:	shl    r11d,0x11
 1af:	or     r10d,r11d
 1b2:	btc    r10,0x1d
 1b7:	mov    r11d,0xf0000000
 1bd:	and    r11,r10
 1c0:	movabs rsi,0xffffffff0fffffff
 1ca:	and    rbx,rsi
 1cd:	or     rbx,r11
 1d0:	pop    r11
 1d2:	pop    r10
 1d4:	pop    rsi
 1d5:	pop    rdx
 1d6:	mov    QWORD PTR [r12+0x108],rbx
 1de:	add    rsp,0x10
 1e2:	mov    eax,0xc
 1e7:	movabs r11,0x57780bcbe390
 1f1:	jmp    r11
