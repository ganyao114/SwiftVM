
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xf8]
  18:	sub    r13,0x1e0
  1f:	mov    QWORD PTR [r12+0xf8],r13
  27:	mov    r14d,0x420000
  2d:	mov    QWORD PTR [r12+0x40],r14
  32:	mov    r14d,0x420000
  38:	mov    QWORD PTR [r12+0x48],r14
  3d:	add    r13,0x1d0
  44:	mov    r14,r13
  47:	add    r14,0x8
  4b:	mov    r15,QWORD PTR [r12+0xa0]
  53:	mov    rbp,QWORD PTR [r12+0x98]
  5b:	mov    QWORD PTR [r13+0x0],r15
  5f:	mov    r13d,0x0
  65:	mov    DWORD PTR [r12+0x32c],r13d
  6d:	mov    QWORD PTR [r14],rbp
  70:	mov    r13d,0x0
  76:	mov    DWORD PTR [r12+0x32c],r13d
  7e:	mov    r13d,0x420aa0
  84:	movdqu xmm2,XMMWORD PTR [r13+0x0]
  8a:	movdqa xmm0,xmm2
  8e:	movdqu XMMWORD PTR [r12+0x110],xmm0
  98:	mov    r13d,0x420000
  9e:	mov    QWORD PTR [r12+0x40],r13
  a3:	mov    r13d,0x420a30
  a9:	movdqu xmm3,XMMWORD PTR [r13+0x0]
  af:	movdqa xmm0,xmm3
  b3:	movdqu XMMWORD PTR [r12+0x120],xmm0
  bd:	mov    r13d,0x420000
  c3:	mov    QWORD PTR [r12+0x48],r13
  c8:	mov    r13d,0x420ac0
  ce:	movdqu xmm4,XMMWORD PTR [r13+0x0]
  d4:	movdqa xmm0,xmm4
  d8:	movdqu XMMWORD PTR [r12+0x130],xmm0
  e2:	mov    r13d,0x420000
  e8:	mov    QWORD PTR [r12+0x40],r13
  ed:	mov    r13d,0x420a60
  f3:	movdqu xmm5,XMMWORD PTR [r13+0x0]
  f9:	movdqa xmm0,xmm5
  fd:	movdqu XMMWORD PTR [r12+0x140],xmm0
 107:	mov    r13d,0x430000
 10d:	add    r13,0xcd0
 114:	mov    QWORD PTR [r12+0x98],r13
 11c:	mov    r14,QWORD PTR [r12+0x40]
 121:	add    r14,0xad0
 128:	movdqu xmm6,XMMWORD PTR [r14]
 12d:	movdqa xmm0,xmm6
 131:	movdqu XMMWORD PTR [r12+0x150],xmm0
 13b:	mov    r14d,0x420000
 141:	mov    QWORD PTR [r12+0x40],r14
 146:	mov    r14,r13
 149:	add    r14,0x10
 14d:	movdqu XMMWORD PTR [r13+0x0],xmm2
 153:	mov    r15d,0x0
 159:	mov    DWORD PTR [r12+0x32c],r15d
 161:	movdqu XMMWORD PTR [r14],xmm3
 166:	mov    r14d,0x0
 16c:	mov    DWORD PTR [r12+0x32c],r14d
 174:	mov    r14,r13
 177:	add    r14,0x20
 17b:	mov    r15,r14
 17e:	add    r15,0x10
 182:	movdqu XMMWORD PTR [r14],xmm4
 187:	mov    r14d,0x0
 18d:	mov    DWORD PTR [r12+0x32c],r14d
 195:	movdqu XMMWORD PTR [r15],xmm5
 19a:	mov    r14d,0x0
 1a0:	mov    DWORD PTR [r12+0x32c],r14d
 1a8:	mov    r14d,0x420a20
 1ae:	movdqu xmm4,XMMWORD PTR [r14]
 1b3:	movdqa xmm0,xmm4
 1b7:	movdqu XMMWORD PTR [r12+0x130],xmm0
 1c1:	mov    r14d,0x420000
 1c7:	mov    QWORD PTR [r12+0x40],r14
 1cc:	mov    r14d,0x420a10
 1d2:	movdqu xmm5,XMMWORD PTR [r14]
 1d7:	movdqa xmm0,xmm5
 1db:	movdqu XMMWORD PTR [r12+0x140],xmm0
 1e5:	mov    r14d,0x420000
 1eb:	mov    QWORD PTR [r12+0x40],r14
 1f0:	mov    r14,r13
 1f3:	add    r14,0x100
 1fa:	mov    r15,r14
 1fd:	add    r15,0x10
 201:	movdqu XMMWORD PTR [r14],xmm2
 206:	mov    r14d,0x0
 20c:	mov    DWORD PTR [r12+0x32c],r14d
 214:	movdqu XMMWORD PTR [r15],xmm3
 219:	mov    r14d,0x0
 21f:	mov    DWORD PTR [r12+0x32c],r14d
 227:	add    r13,0x40
 22b:	mov    r14,r13
 22e:	add    r14,0x10
 232:	movdqu XMMWORD PTR [r13+0x0],xmm6
 238:	mov    r13d,0x0
 23e:	mov    DWORD PTR [r12+0x32c],r13d
 246:	movdqu XMMWORD PTR [r14],xmm4
 24b:	mov    r13d,0x0
 251:	mov    DWORD PTR [r12+0x32c],r13d
 259:	mov    r13d,0x420a00
 25f:	movdqu xmm2,XMMWORD PTR [r13+0x0]
 265:	movdqa xmm0,xmm2
 269:	movdqu XMMWORD PTR [r12+0x130],xmm0
 273:	mov    r13d,0x420000
 279:	mov    QWORD PTR [r12+0x40],r13
 27e:	mov    r13d,0x420a70
 284:	movdqu xmm3,XMMWORD PTR [r13+0x0]
 28a:	movdqa xmm0,xmm3
 28e:	movdqu XMMWORD PTR [r12+0x150],xmm0
 298:	mov    r13d,0x420000
 29e:	mov    QWORD PTR [r12+0x40],r13
 2a3:	mov    r13d,0xf8d3
 2a9:	mov    QWORD PTR [r12+0x48],r13
 2ae:	mov    r13,QWORD PTR [r12+0x98]
 2b6:	mov    r14,r13
 2b9:	add    r14,0x60
 2bd:	mov    r15,r14
 2c0:	add    r15,0x10
 2c4:	movdqu XMMWORD PTR [r14],xmm5
 2c9:	mov    r14d,0x0
 2cf:	mov    DWORD PTR [r12+0x32c],r14d
 2d7:	movdqu XMMWORD PTR [r15],xmm2
 2dc:	mov    r14d,0x0
 2e2:	mov    DWORD PTR [r12+0x32c],r14d
 2ea:	mov    r14d,0x420a80
 2f0:	movdqu xmm2,XMMWORD PTR [r14]
 2f5:	movdqa xmm0,xmm2
 2f9:	movdqu XMMWORD PTR [r12+0x130],xmm0
 303:	mov    r14d,0x420000
 309:	mov    QWORD PTR [r12+0x40],r14
 30e:	mov    r14d,0x420a50
 314:	movdqu xmm2,XMMWORD PTR [r14]
 319:	movdqa xmm0,xmm2
 31d:	movdqu XMMWORD PTR [r12+0x140],xmm0
 327:	mov    r14d,0x420000
 32d:	mov    QWORD PTR [r12+0x40],r14
 332:	mov    r14d,0xf8d3
 338:	mov    r15d,0x421d
 33e:	and    r15d,0xffff
 345:	mov    rax,r14
 348:	movabs rcx,0xffffffff0000ffff
 352:	and    rax,rcx
 355:	mov    rdx,r15
 358:	shl    rdx,0x10
 35c:	mov    ecx,0xffff0000
 361:	and    rdx,rcx
 364:	or     rax,rdx
 367:	mov    ebp,eax
 369:	mov    QWORD PTR [r12+0x48],rbp
 36e:	mov    r14,r13
 371:	add    r14,0x80
 378:	mov    r15,r14
 37b:	add    r15,0x10
 37f:	movdqu xmm0,XMMWORD PTR [r12+0x130]
 389:	movdqa xmm2,xmm0
 38d:	movdqu XMMWORD PTR [r14],xmm3
 392:	mov    r14d,0x0
 398:	mov    DWORD PTR [r12+0x32c],r14d
 3a0:	movdqu XMMWORD PTR [r15],xmm2
 3a5:	mov    r14d,0x0
 3ab:	mov    DWORD PTR [r12+0x32c],r14d
 3b3:	mov    r14d,0x420af0
 3b9:	movdqu xmm2,XMMWORD PTR [r14]
 3be:	movdqa xmm0,xmm2
 3c2:	movdqu XMMWORD PTR [r12+0x130],xmm0
 3cc:	mov    r14d,0x420000
 3d2:	mov    QWORD PTR [r12+0x40],r14
 3d7:	mov    r14d,0x420b00
 3dd:	movdqu xmm3,XMMWORD PTR [r14]
 3e2:	movdqa xmm0,xmm3
 3e6:	movdqu XMMWORD PTR [r12+0x150],xmm0
 3f0:	mov    r14d,0x420000
 3f6:	mov    QWORD PTR [r12+0x40],r14
 3fb:	mov    r14d,0x3e8
 401:	mov    QWORD PTR [r12+0xa0],r14
 409:	add    r13,0xa0
 410:	mov    r14,r13
 413:	add    r14,0x10
 417:	movdqu xmm0,XMMWORD PTR [r12+0x140]
 421:	movdqa xmm3,xmm0
 425:	movdqu XMMWORD PTR [r13+0x0],xmm3
 42b:	mov    r13d,0x0
 431:	mov    DWORD PTR [r12+0x32c],r13d
 439:	movdqu XMMWORD PTR [r14],xmm2
 43e:	mov    r13d,0x0
 444:	mov    DWORD PTR [r12+0x32c],r13d
 44c:	mov    r13,QWORD PTR [r12+0x40]
 451:	add    r13,0xae0
 458:	movdqu xmm2,XMMWORD PTR [r13+0x0]
 45e:	movdqa xmm0,xmm2
 462:	movdqu XMMWORD PTR [r12+0x130],xmm0
 46c:	mov    r13d,0x420000
 472:	mov    QWORD PTR [r12+0x40],r13
 477:	mov    r13d,0x420a90
 47d:	movdqu xmm2,XMMWORD PTR [r13+0x0]
 483:	movdqa xmm0,xmm2
 487:	movdqu XMMWORD PTR [r12+0x140],xmm0
 491:	mov    r13d,0x420000
 497:	mov    QWORD PTR [r12+0x40],r13
 49c:	mov    r13,QWORD PTR [r12+0xf8]
 4a4:	add    r13,0x180
 4ab:	mov    r14,r13
 4ae:	add    r14,0x8
 4b2:	mov    r15,QWORD PTR [r12+0x200]
 4ba:	mov    rbp,QWORD PTR [r12+0x1f0]
 4c2:	mov    QWORD PTR [r13+0x0],r15
 4c6:	mov    r13d,0x0
 4cc:	mov    DWORD PTR [r12+0x32c],r13d
 4d4:	mov    QWORD PTR [r14],rbp
 4d7:	mov    r13d,0x0
 4dd:	mov    DWORD PTR [r12+0x32c],r13d
 4e5:	mov    r13,QWORD PTR [r12+0x98]
 4ed:	mov    r14,r13
 4f0:	add    r14,0xc0
 4f7:	mov    r15,r14
 4fa:	add    r15,0x10
 4fe:	movdqu xmm0,XMMWORD PTR [r12+0x150]
 508:	movdqa xmm2,xmm0
 50c:	movdqu xmm0,XMMWORD PTR [r12+0x130]
 516:	movdqa xmm3,xmm0
 51a:	movdqu XMMWORD PTR [r14],xmm2
 51f:	mov    r14d,0x0
 525:	mov    DWORD PTR [r12+0x32c],r14d
 52d:	movdqu XMMWORD PTR [r15],xmm3
 532:	mov    r14d,0x0
 538:	mov    DWORD PTR [r12+0x32c],r14d
 540:	mov    r14d,0x420ab0
 546:	movdqu xmm2,XMMWORD PTR [r14]
 54b:	movdqa xmm0,xmm2
 54f:	movdqu XMMWORD PTR [r12+0x130],xmm0
 559:	mov    r14d,0x420000
 55f:	mov    QWORD PTR [r12+0x40],r14
 564:	mov    r14d,0x420b18
 56a:	mov    r15,QWORD PTR [r14]
 56d:	mov    r14d,0x0
 573:	mov    QWORD PTR [r12+0x110],r15
 57b:	mov    QWORD PTR [r12+0x118],r14
 583:	mov    r14d,0x420b20
 589:	mov    QWORD PTR [r12+0x40],r14
 58e:	mov    r14,r13
 591:	add    r14,0xe0
 598:	mov    rbp,r14
 59b:	add    rbp,0x10
 59f:	movdqu xmm0,XMMWORD PTR [r12+0x140]
 5a9:	movdqa xmm3,xmm0
 5ad:	movdqu XMMWORD PTR [r14],xmm3
 5b2:	mov    r14d,0x0
 5b8:	mov    DWORD PTR [r12+0x32c],r14d
 5c0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
 5c5:	mov    r14d,0x0
 5cb:	mov    DWORD PTR [r12+0x32c],r14d
 5d3:	mov    r14d,0x420b80
 5d9:	movdqu xmm2,XMMWORD PTR [r14]
 5de:	movdqa xmm0,xmm2
 5e2:	movdqu XMMWORD PTR [r12+0x130],xmm0
 5ec:	add    r13,0x120
 5f3:	mov    QWORD PTR [r13+0x0],r15
 5f7:	mov    r13d,0x0
 5fd:	mov    DWORD PTR [r12+0x32c],r13d
 605:	mov    r13d,0x420b60
 60b:	mov    r14d,0x420b70
 611:	movdqu xmm3,XMMWORD PTR [r13+0x0]
 617:	movdqu xmm4,XMMWORD PTR [r14]
 61c:	movdqa xmm0,xmm3
 620:	movdqu XMMWORD PTR [r12+0x120],xmm0
 62a:	movdqa xmm0,xmm4
 62e:	movdqu XMMWORD PTR [r12+0x110],xmm0
 638:	mov    r13,QWORD PTR [r12+0xf8]
 640:	mov    r14,r13
 643:	add    r14,0x160
 64a:	movdqu XMMWORD PTR [r14],xmm2
 64f:	mov    r14d,0x0
 655:	mov    DWORD PTR [r12+0x32c],r14d
 65d:	mov    r14,r13
 660:	add    r14,0x190
 667:	mov    r15,r14
 66a:	add    r15,0x8
 66e:	mov    rbp,QWORD PTR [r12+0x1e0]
 676:	mov    r8,QWORD PTR [r12+0x1d0]
 67e:	mov    QWORD PTR [r14],rbp
 681:	mov    r14d,0x0
 687:	mov    DWORD PTR [r12+0x32c],r14d
 68f:	mov    QWORD PTR [r15],r8
 692:	mov    r14d,0x0
 698:	mov    DWORD PTR [r12+0x32c],r14d
 6a0:	mov    r14,r13
 6a3:	add    r14,0x140
 6aa:	mov    r15,r14
 6ad:	add    r15,0x10
 6b1:	movdqu XMMWORD PTR [r14],xmm3
 6b6:	mov    r14d,0x0
 6bc:	mov    DWORD PTR [r12+0x32c],r14d
 6c4:	movdqu XMMWORD PTR [r15],xmm4
 6c9:	mov    r14d,0x0
 6cf:	mov    DWORD PTR [r12+0x32c],r14d
 6d7:	mov    r14d,0x420b20
 6dd:	mov    r15d,0x420b30
 6e3:	movdqu xmm2,XMMWORD PTR [r14]
 6e8:	movdqu xmm3,XMMWORD PTR [r15]
 6ed:	movdqa xmm0,xmm2
 6f1:	movdqu XMMWORD PTR [r12+0x110],xmm0
 6fb:	movdqa xmm0,xmm3
 6ff:	movdqu XMMWORD PTR [r12+0x120],xmm0
 709:	mov    r14,r13
 70c:	add    r14,0x1a0
 713:	mov    r15,r14
 716:	add    r15,0x8
 71a:	mov    rbp,QWORD PTR [r12+0x1c0]
 722:	mov    r8,QWORD PTR [r12+0x1b0]
 72a:	mov    QWORD PTR [r14],rbp
 72d:	mov    r14d,0x0
 733:	mov    DWORD PTR [r12+0x32c],r14d
 73b:	mov    QWORD PTR [r15],r8
 73e:	mov    r14d,0x0
 744:	mov    DWORD PTR [r12+0x32c],r14d
 74c:	mov    r14,r13
 74f:	add    r14,0x1b0
 756:	mov    r15,r14
 759:	add    r15,0x8
 75d:	mov    rbp,QWORD PTR [r12+0x1a0]
 765:	mov    r8,QWORD PTR [r12+0x190]
 76d:	mov    QWORD PTR [r14],rbp
 770:	mov    r14d,0x0
 776:	mov    DWORD PTR [r12+0x32c],r14d
 77e:	mov    QWORD PTR [r15],r8
 781:	mov    r14d,0x0
 787:	mov    DWORD PTR [r12+0x32c],r14d
 78f:	add    r13,0x100
 796:	mov    r14,r13
 799:	add    r14,0x10
 79d:	movdqu xmm0,XMMWORD PTR [r12+0x110]
 7a7:	movdqa xmm2,xmm0
 7ab:	movdqu xmm0,XMMWORD PTR [r12+0x120]
 7b5:	movdqa xmm3,xmm0
 7b9:	movdqu XMMWORD PTR [r13+0x0],xmm2
 7bf:	mov    r13d,0x0
 7c5:	mov    DWORD PTR [r12+0x32c],r13d
 7cd:	movdqu XMMWORD PTR [r14],xmm3
 7d2:	mov    r13d,0x0
 7d8:	mov    DWORD PTR [r12+0x32c],r13d
 7e0:	mov    r13,QWORD PTR [r12+0x40]
 7e5:	add    r13,0x20
 7e9:	mov    r14,r13
 7ec:	add    r14,0x10
 7f0:	movdqu xmm2,XMMWORD PTR [r13+0x0]
 7f6:	movdqu xmm3,XMMWORD PTR [r14]
 7fb:	movdqa xmm0,xmm2
 7ff:	movdqu XMMWORD PTR [r12+0x110],xmm0
 809:	movdqa xmm0,xmm3
 80d:	movdqu XMMWORD PTR [r12+0x130],xmm0
 817:	mov    r13,QWORD PTR [r12+0xf8]
 81f:	mov    r14,r13
 822:	add    r14,0x1c0
 829:	mov    r15,r14
 82c:	add    r15,0x8
 830:	mov    rbp,QWORD PTR [r12+0xe8]
 838:	mov    r8,QWORD PTR [r12+0xf0]
 840:	mov    QWORD PTR [r14],rbp
 843:	mov    r14d,0x0
 849:	mov    DWORD PTR [r12+0x32c],r14d
 851:	mov    QWORD PTR [r15],r8
 854:	mov    r14d,0x0
 85a:	mov    DWORD PTR [r12+0x32c],r14d
 862:	mov    r14,QWORD PTR [r12+0x98]
 86a:	mov    r15,r14
 86d:	add    r15,0x128
 874:	mov    ebp,DWORD PTR [r12+0x48]
 879:	mov    DWORD PTR [r15],ebp
 87c:	mov    r15d,0x0
 882:	mov    DWORD PTR [r12+0x32c],r15d
 88a:	mov    r15,r13
 88d:	add    r15,0x120
 894:	mov    rbp,r15
 897:	add    rbp,0x10
 89b:	movdqu xmm0,XMMWORD PTR [r12+0x110]
 8a5:	movdqa xmm2,xmm0
 8a9:	movdqu XMMWORD PTR [r15],xmm2
 8ae:	mov    r15d,0x0
 8b4:	mov    DWORD PTR [r12+0x32c],r15d
 8bc:	movdqu XMMWORD PTR [rbp+0x0],xmm3
 8c1:	mov    r15d,0x0
 8c7:	mov    DWORD PTR [r12+0x32c],r15d
 8cf:	add    r13,0x100
 8d6:	mov    QWORD PTR [r12],r13
 8da:	mov    r13d,0x0
 8e0:	mov    rcx,r14
 8e3:	or     r13,rcx
 8e6:	mov    QWORD PTR [r12+0x8],r13
 8eb:	mov    r13d,0x12c
 8f1:	mov    QWORD PTR [r12+0x10],r13
 8f6:	mov    r13d,0x410284
 8fc:	mov    QWORD PTR [r12+0xf0],r13
 904:	mov    r13d,0x410728
 90a:	mov    QWORD PTR [r12+0x100],r13
 912:	mov    r11,QWORD PTR [rsp]
 916:	mov    QWORD PTR [r12+0x398],r11
 91e:	mov    edi,0x410728
 923:	mov    QWORD PTR [r12+0x100],rdi
 92b:	add    rsp,0x10
 92f:	nop
 930:	jmp    QWORD PTR [rip+0x2]        # 0x938
 936:	xchg   ax,ax
 938:	(bad)
 939:	jmp    0x710da9cd
 93e:	add    BYTE PTR [rax],al
 940:	rex.W jmp 0x710da9d5
 946:	add    BYTE PTR [rax],al
 948:	movabs r11,0x57780bcbe0a0
 952:	jmp    r11
 955:	nop
 956:	nop
 957:	nop
