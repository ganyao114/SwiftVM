
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/memory/candidate/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13d,0x1b00
  16:	mov    r14d,0xb7
  1c:	and    r14d,0xffff
  23:	mov    rax,r13
  26:	movabs rcx,0xffffffff0000ffff
  30:	and    rax,rcx
  33:	mov    rdx,r14
  36:	shl    rdx,0x10
  3a:	mov    ecx,0xffff0000
  3f:	and    rdx,rcx
  42:	or     rax,rdx
  45:	mov    r15,rax
  48:	mov    QWORD PTR [r12+0x8],r15
  4d:	mov    r13d,0x420060
  53:	mov    QWORD PTR [r12+0x20],r13
  58:	mov    r13d,0x0
  5e:	mov    QWORD PTR [r12],r13
  62:	mov    r11,rax
  65:	movzx  eax,WORD PTR [rsp]
  69:	add    al,0x7f
  6b:	sahf
  6c:	mov    rax,r11
  6f:	jmp    0x74
  74:	mov    r13,QWORD PTR [r12+0x20]
  79:	mov    r14,QWORD PTR [r12]
  7d:	mov    QWORD PTR [r13+0x0],r14
  81:	mov    r14d,0x0
  87:	mov    DWORD PTR [r12+0x32c],r14d
  8f:	mov    r14,QWORD PTR [r13+0x0]
  93:	mov    QWORD PTR [r12+0x18],r14
  98:	lea    r14,[r14+0x3]
  9c:	mov    QWORD PTR [r12],r14
  a0:	mov    r13,QWORD PTR [r12+0x8]
  a5:	sub    r13,0x1
  a9:	mov    QWORD PTR [r12+0x8],r13
  ae:	mov    rcx,QWORD PTR [r12+0x380]
  b6:	jrcxz  0xbd
  b8:	jmp    0x135
  bd:	jne    0x74
  c3:	mov    r11,rax
  c6:	lahf
  c7:	seto   al
  ca:	mov    WORD PTR [rsp],ax
  ce:	mov    rax,r11
  d1:	jmp    0xd6
  d6:	mov    r13,QWORD PTR [r12+0x20]
  db:	mov    r14,QWORD PTR [r12]
  df:	mov    QWORD PTR [r13+0x0],r14
  e3:	mov    r13d,0x0
  e9:	mov    DWORD PTR [r12+0x32c],r13d
  f1:	mov    rcx,QWORD PTR [r12+0x380]
  f9:	jrcxz  0x100
  fb:	jmp    0x1c6
 100:	mov    r13,QWORD PTR [r12+0xf0]
 108:	mov    QWORD PTR [r12+0x100],r13
 110:	mov    r11,QWORD PTR [rsp]
 114:	mov    QWORD PTR [r12+0x398],r11
 11c:	mov    rdi,QWORD PTR [r12+0x100]
 124:	add    rsp,0x10
 128:	movabs r11,0x5f71ea375940
 132:	jmp    r11
 135:	mov    eax,0x41004c
 13a:	mov    QWORD PTR [r12+0x100],rax
 142:	push   rdx
 143:	push   rsi
 144:	push   r10
 146:	push   r11
 148:	mov    r11,rax
 14b:	lahf
 14c:	seto   al
 14f:	mov    WORD PTR [rsp+0x20],ax
 154:	mov    rax,r11
 157:	mov    rdx,QWORD PTR [rsp+0x20]
 15c:	mov    r10d,edx
 15f:	and    r10d,0xc000
 166:	shl    r10d,0x10
 16a:	mov    r11d,edx
 16d:	and    r11d,0x100
 174:	shl    r11d,0x15
 178:	or     r10d,r11d
 17b:	and    edx,0x1
 17e:	shl    edx,0x1c
 181:	or     r10d,edx
 184:	btc    r10,0x1d
 189:	mov    r11d,0xf0000000
 18f:	and    r11,r10
 192:	movabs rsi,0xffffffff0fffffff
 19c:	and    rbx,rsi
 19f:	or     rbx,r11
 1a2:	pop    r11
 1a4:	pop    r10
 1a6:	pop    rsi
 1a7:	pop    rdx
 1a8:	mov    QWORD PTR [r12+0x108],rbx
 1b0:	add    rsp,0x10
 1b4:	mov    eax,0xc
 1b9:	movabs r11,0x5f71ea375ca0
 1c3:	jmp    r11
 1c6:	mov    eax,0x410054
 1cb:	mov    QWORD PTR [r12+0x100],rax
 1d3:	push   rdx
 1d4:	push   rsi
 1d5:	push   r10
 1d7:	push   r11
 1d9:	mov    rdx,QWORD PTR [rsp+0x20]
 1de:	mov    r10d,edx
 1e1:	and    r10d,0xc000
 1e8:	shl    r10d,0x10
 1ec:	mov    r11d,edx
 1ef:	and    r11d,0x100
 1f6:	shl    r11d,0x15
 1fa:	or     r10d,r11d
 1fd:	and    edx,0x1
 200:	shl    edx,0x1c
 203:	or     r10d,edx
 206:	btc    r10,0x1d
 20b:	mov    r11d,0xf0000000
 211:	and    r11,r10
 214:	movabs rsi,0xffffffff0fffffff
 21e:	and    rbx,rsi
 221:	or     rbx,r11
 224:	pop    r11
 226:	pop    r10
 228:	pop    rsi
 229:	pop    rdx
 22a:	mov    QWORD PTR [r12+0x108],rbx
 232:	add    rsp,0x10
 236:	mov    eax,0xc
 23b:	movabs r11,0x5f71ea375ca0
 245:	jmp    r11
 248:	nop    DWORD PTR [rax+rax*1+0x0]
 250:	sub    rsp,0x10
 254:	mov    r11,QWORD PTR [r12+0x398]
 25c:	mov    QWORD PTR [rsp],r11
 260:	mov    r11,rax
 263:	movzx  eax,WORD PTR [rsp]
 267:	add    al,0x7f
 269:	sahf
 26a:	mov    rax,r11
 26d:	jmp    0x74
 272:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
 280:	sub    rsp,0x10
 284:	mov    r11,QWORD PTR [r12+0x398]
 28c:	mov    QWORD PTR [rsp],r11
 290:	jmp    0xd6
 295:	nop
 296:	nop
 297:	nop
