000075e5f6dce69b  nop [rax+rax*1], eax
000075e5f6dce6a0  mov qword ptr [r15+0x40], 0x4201C0
000075e5f6dce6a8  mov qword ptr [r15+0x48], 0x4203C0
000075e5f6dce6b0  mov qword ptr [r15+0x60], 0x01
000075e5f6dce6b8  xorps xmm1, xmm1
000075e5f6dce6bb  mov eax, 0x41
000075e5f6dce6c0  vcvtusi2sd xmm1, xmm1, eax
000075e5f6dce6c6  mulsd xmm1, [0x000075E5F69FE010]
000075e5f6dce6ce  movq xmm1, xmm1
000075e5f6dce6d2  movaps [r15+0x120], xmm1
000075e5f6dce6da  mov eax, [r15+0x60]
000075e5f6dce6de  xorps xmm15, xmm15
000075e5f6dce6e2  vcvtusi2sd xmm15, xmm15, eax
000075e5f6dce6e8  mulsd xmm15, [0x000075E5F69FE020]
000075e5f6dce6f1  movq xmm15, xmm15
000075e5f6dce6f6  movaps [r15+0x110], xmm15
000075e5f6dce6fe  mov rax, [r15+0x60]
000075e5f6dce702  mov [rsp+0x10], rax
000075e5f6dce707  xor eax, eax
000075e5f6dce709  mov r14, [rsp+0x10]
000075e5f6dce70e  mov r12d, 0x40
000075e5f6dce714  cmp r14, r12
000075e5f6dce717  cmc
000075e5f6dce718  lahf
000075e5f6dce719  seto al
000075e5f6dce71c  mov [r15+0x108], eax
000075e5f6dce723  mov qword ptr [r15+0x50], 0x40
000075e5f6dce72b  movq rax, xmm1
000075e5f6dce730  mov r12d, 0x4203C0
000075e5f6dce736  mov [r13+r12*1], rax
000075e5f6dce73b  movq rax, xmm15
000075e5f6dce740  mov r12d, 0x4201C0
000075e5f6dce746  mov [r13+r12*1], rax
000075e5f6dce74b  mov [r15+0x58], r14
000075e5f6dce74f  mov eax, [r15+0x108]
000075e5f6dce756  sahf
000075e5f6dce757  jnz 0x000075E5F6DCE789
000075e5f6dce759  cmp dword ptr [r15+0x318], 0x00
000075e5f6dce761  jz 0x000075E5F6DCE910
000075e5f6dce767  nop [rax+rax*1], ax
000075e5f6dce770  nop [rax+rax*1], eax
000075e5f6dce778  mov eax, 0x410074
000075e5f6dce77d  mov [r15+0x100], rax
000075e5f6dce784  jmp 0x000075E5F6BFE110
000075e5f6dce789  cmp dword ptr [r15+0x318], 0x00
000075e5f6dce791  jz 0x000075E5F6DCE7D0
000075e5f6dce797  nop [rax+rax*1], ax
000075e5f6dce7a0  nop [rax+rax*1], eax
000075e5f6dce7a8  mov eax, 0x41004C
000075e5f6dce7ad  mov [r15+0x100], rax
000075e5f6dce7b4  jmp 0x000075E5F6BFE110
000075e5f6dce7b9  int3
000075e5f6dce7ba  call 0x000075E5F6CB4CB0
000075e5f6dce7bf  jmp 0x000075E5F6DCE73B
000075e5f6dce7c4  call 0x000075E5F6CB4CB0
000075e5f6dce7c9  jmp 0x000075E5F6DCE74B
000075e5f6dce7ce  int3
000075e5f6dce7cf  nop
000075e5f6dce7d0  mov rax, [r15+0x58]
000075e5f6dce7d4  lea r14, [rax+0x01]
000075e5f6dce7d8  mov [r15+0x60], r14
000075e5f6dce7dc  mov r14d, [r15+0x50]
000075e5f6dce7e0  xorps xmm1, xmm1
000075e5f6dce7e3  vcvtusi2sd xmm1, xmm1, r14d
000075e5f6dce7e9  mulsd xmm1, [0x000075E5F69FE010]
000075e5f6dce7f1  movq xmm1, xmm1
000075e5f6dce7f5  movaps [r15+0x120], xmm1
000075e5f6dce7fd  rorx r12, rax, 0x3D
000075e5f6dce803  and r12, 0xFFFFFFFFFFFFFFF8
000075e5f6dce807  mov eax, [r15+0x60]
000075e5f6dce80b  xorps xmm15, xmm15
000075e5f6dce80f  vcvtusi2sd xmm15, xmm15, eax
000075e5f6dce815  mulsd xmm15, [0x000075E5F69FE020]
000075e5f6dce81e  movq xmm15, xmm15
000075e5f6dce823  movaps [r15+0x110], xmm15
000075e5f6dce82b  mov rax, [r15+0x60]
000075e5f6dce82f  mov [rsp+0x10], rax
000075e5f6dce834  xor eax, eax
000075e5f6dce836  mov r11, [rsp+0x10]
000075e5f6dce83b  mov r10d, 0x40
000075e5f6dce841  cmp r11, r10
000075e5f6dce844  cmc
000075e5f6dce845  lahf
000075e5f6dce846  seto al
000075e5f6dce849  mov [r15+0x108], eax
000075e5f6dce850  lea eax, [r14d-0x01]
000075e5f6dce855  mov eax, eax
000075e5f6dce857  mov [r15+0x50], rax
000075e5f6dce85b  mov rax, [r15+0x48]
000075e5f6dce85f  lea r14, [rax+r12*1]
000075e5f6dce863  movq rax, xmm1
000075e5f6dce868  mov [r13+r14*1], rax
000075e5f6dce86d  mov rax, [r15+0x40]
000075e5f6dce871  lea r14, [rax+r12*1]
000075e5f6dce875  movq rax, xmm15
000075e5f6dce87a  mov [r13+r14*1], rax
000075e5f6dce87f  mov [r15+0x58], r11
000075e5f6dce883  mov eax, [r15+0x108]
000075e5f6dce88a  sahf
000075e5f6dce88b  jnz 0x000075E5F6DCE8BD
000075e5f6dce88d  cmp dword ptr [r15+0x318], 0x00
000075e5f6dce895  jz 0x000075E5F6DCE910
000075e5f6dce89b  nop [rax+rax*1], ax
000075e5f6dce8a4  nop [rax+rax*1], eax
000075e5f6dce8ac  mov eax, 0x410074
000075e5f6dce8b1  mov [r15+0x100], rax
000075e5f6dce8b8  jmp 0x000075E5F6BFE110
000075e5f6dce8bd  cmp dword ptr [r15+0x318], 0x00
000075e5f6dce8c5  jz 0x000075E5F6DCE7D0
000075e5f6dce8cb  nop [rax+rax*1], ax
000075e5f6dce8d4  nop [rax+rax*1], eax
000075e5f6dce8dc  mov eax, 0x41004C
000075e5f6dce8e1  mov [r15+0x100], rax
000075e5f6dce8e8  jmp 0x000075E5F6BFE110
000075e5f6dce8ed  int3
000075e5f6dce8ee  call 0x000075E5F6CD5EB0
000075e5f6dce8f3  jmp 0x000075E5F6DCE86D
000075e5f6dce8f8  call 0x000075E5F6CD5EB0
000075e5f6dce8fd  jmp 0x000075E5F6DCE87F
000075e5f6dce902  int3
000075e5f6dce903  nop [rax+rax*1], ax
000075e5f6dce90c  nop [rax], eax
000075e5f6dce910  vxorps xmm1, xmm1, xmm1
000075e5f6dce914  movq xmm1, xmm1
000075e5f6dce918  movaps [r15+0x110], xmm1
000075e5f6dce920  mov qword ptr [r15+0x58], 0x00
000075e5f6dce928  mov qword ptr [r15+0x50], 0x4205C0
000075e5f6dce930  mov qword ptr [r15+0x60], 0x00
000075e5f6dce938  mov qword ptr [r15+0x68], 0x4205C0
000075e5f6dce940  mov rax, [r15+0x40]
000075e5f6dce944  mov r14, [r13+rax*1]
000075e5f6dce949  lea r12, [rax+0x08]
000075e5f6dce94d  mov r11, [r13+r12*1]
000075e5f6dce952  movq xmm15, r14
000075e5f6dce957  movq xmm14, r11
000075e5f6dce95c  movq xmm15, xmm15
000075e5f6dce961  movq xmm15, xmm15
000075e5f6dce966  movaps [r15+0x120], xmm15
000075e5f6dce96e  movq xmm14, xmm14
000075e5f6dce973  movq xmm14, xmm14
000075e5f6dce978  movaps [r15+0x130], xmm14
000075e5f6dce980  lea r14, [rax+0x10]
000075e5f6dce984  mov r12, [r13+r14*1]
000075e5f6dce989  lea r14, [rax+0x18]
000075e5f6dce98d  mov r11, [r13+r14*1]
000075e5f6dce992  movq xmm15, r12
000075e5f6dce997  movq xmm14, r11
000075e5f6dce99c  movq xmm15, xmm15
000075e5f6dce9a1  movq xmm15, xmm15
000075e5f6dce9a6  movaps [r15+0x140], xmm15
000075e5f6dce9ae  movq xmm14, xmm14
000075e5f6dce9b3  movq xmm14, xmm14
000075e5f6dce9b8  movaps [r15+0x150], xmm14
000075e5f6dce9c0  lea r14, [rax+0x20]
000075e5f6dce9c4  mov r12, [r13+r14*1]
000075e5f6dce9c9  lea r14, [rax+0x28]
000075e5f6dce9cd  mov r11, [r13+r14*1]
000075e5f6dce9d2  movq xmm15, r12
000075e5f6dce9d7  movq xmm14, r11
000075e5f6dce9dc  movq xmm15, xmm15
000075e5f6dce9e1  movq xmm15, xmm15
000075e5f6dce9e6  movaps [r15+0x160], xmm15
000075e5f6dce9ee  movq xmm14, xmm14
000075e5f6dce9f3  movq xmm14, xmm14
000075e5f6dce9f8  movaps [r15+0x170], xmm14
000075e5f6dcea00  lea r14, [rax+0x30]
000075e5f6dcea04  mov r12, [r13+r14*1]
000075e5f6dcea09  lea r14, [rax+0x38]
000075e5f6dcea0d  mov rax, [r13+r14*1]
000075e5f6dcea12  movq xmm15, r12
000075e5f6dcea17  movq xmm14, rax
000075e5f6dcea1c  movq xmm15, xmm15
000075e5f6dcea21  movq xmm15, xmm15
000075e5f6dcea26  movaps [r15+0x180], xmm15
000075e5f6dcea2e  movq xmm14, xmm14
000075e5f6dcea33  movq xmm14, xmm14
000075e5f6dcea38  movaps [r15+0x210], xmm14
000075e5f6dcea40  mov rax, [r15+0x48]
000075e5f6dcea44  mov [r15+0x78], rax
000075e5f6dcea48  mov r14, [r13+rax*1]
000075e5f6dcea4d  movq xmm15, r14
000075e5f6dcea52  lea r14, [rax+0x40]
000075e5f6dcea56  mov r12, [r13+r14*1]
000075e5f6dcea5b  movq xmm14, r12
000075e5f6dcea60  lea r14, [rax+0x80]
000075e5f6dcea67  mov r12, [r13+r14*1]
000075e5f6dcea6c  movq xmm13, r12
000075e5f6dcea71  movaps xmm12, [r15+0x120]
000075e5f6dcea79  movq r14, xmm12
000075e5f6dcea7e  movq r12, xmm15
000075e5f6dcea83  vmovq xmm15, r14
000075e5f6dcea88  vmovq xmm12, r12
000075e5f6dcea8d  movaps xmm11, xmm15
000075e5f6dcea91  mulsd xmm11, xmm12
000075e5f6dcea96  ucomisd xmm11, xmm11
000075e5f6dcea9b  jp 0x000075E5F6DCEEFC
000075e5f6dceaa1  movq xmm11, xmm11
000075e5f6dceaa6  movaps xmm15, [r15+0x130]
000075e5f6dceaae  movq r14, xmm15
000075e5f6dceab3  movq r12, xmm14
000075e5f6dceab8  vmovq xmm15, r14
000075e5f6dceabd  vmovq xmm14, r12
000075e5f6dceac2  movaps xmm12, xmm15
000075e5f6dceac6  mulsd xmm12, xmm14
000075e5f6dceacb  ucomisd xmm12, xmm12
000075e5f6dcead0  jp 0x000075E5F6DCEF48
000075e5f6dcead6  movq xmm12, xmm12
000075e5f6dceadb  movq r14, xmm11
000075e5f6dceae0  movq r12, xmm1
000075e5f6dceae5  vmovq xmm1, r14
000075e5f6dceaea  vmovq xmm15, r12
000075e5f6dceaef  movaps xmm14, xmm1
000075e5f6dceaf3  addsd xmm14, xmm15
000075e5f6dceaf8  ucomisd xmm14, xmm14
000075e5f6dceafd  jp 0x000075E5F6DCEF94
000075e5f6dceb03  movq xmm14, xmm14
000075e5f6dceb08  movq r14, xmm14
000075e5f6dceb0d  movq r12, xmm12
000075e5f6dceb12  vmovq xmm1, r14
000075e5f6dceb17  vmovq xmm15, r12
000075e5f6dceb1c  movaps xmm14, xmm1
000075e5f6dceb20  addsd xmm14, xmm15
000075e5f6dceb25  ucomisd xmm14, xmm14
000075e5f6dceb2a  jp 0x000075E5F6DCEFE0
000075e5f6dceb30  movq xmm14, xmm14
000075e5f6dceb35  movaps xmm1, [r15+0x140]
000075e5f6dceb3d  movq r14, xmm1
000075e5f6dceb42  movq r12, xmm13
000075e5f6dceb47  vmovq xmm1, r14
000075e5f6dceb4c  vmovq xmm15, r12
000075e5f6dceb51  movaps xmm13, xmm1
000075e5f6dceb55  mulsd xmm13, xmm15
000075e5f6dceb5a  ucomisd xmm13, xmm13
000075e5f6dceb5f  jp 0x000075E5F6DCF02C
000075e5f6dceb65  movq xmm13, xmm13
000075e5f6dceb6a  lea r14, [rax+0xC0]
000075e5f6dceb71  mov r12, [r13+r14*1]
000075e5f6dceb76  movq xmm1, r12
000075e5f6dceb7b  movq r14, xmm14
000075e5f6dceb80  movq r12, xmm13
000075e5f6dceb85  vmovq xmm15, r14
000075e5f6dceb8a  vmovq xmm14, r12
000075e5f6dceb8f  movaps xmm13, xmm15
000075e5f6dceb93  addsd xmm13, xmm14
000075e5f6dceb98  ucomisd xmm13, xmm13
000075e5f6dceb9d  jp 0x000075E5F6DCF082
000075e5f6dceba3  movq xmm13, xmm13
000075e5f6dceba8  movaps xmm15, [r15+0x150]
000075e5f6dcebb0  movq r14, xmm15
000075e5f6dcebb5  movq r12, xmm1
000075e5f6dcebba  vmovq xmm1, r14
000075e5f6dcebbf  vmovq xmm15, r12
000075e5f6dcebc4  movaps xmm14, xmm1
000075e5f6dcebc8  mulsd xmm14, xmm15
000075e5f6dcebcd  ucomisd xmm14, xmm14
000075e5f6dcebd2  jp 0x000075E5F6DCF0CE
000075e5f6dcebd8  movq xmm14, xmm14
000075e5f6dcebdd  lea r14, [rax+0x100]
000075e5f6dcebe4  mov r12, [r13+r14*1]
000075e5f6dcebe9  movq xmm1, r12
000075e5f6dcebee  movq r14, xmm13
000075e5f6dcebf3  movq r12, xmm14
000075e5f6dcebf8  vmovq xmm15, r14
000075e5f6dcebfd  vmovq xmm14, r12
000075e5f6dcec02  movaps xmm13, xmm15
000075e5f6dcec06  addsd xmm13, xmm14
000075e5f6dcec0b  ucomisd xmm13, xmm13
000075e5f6dcec10  jp 0x000075E5F6DCF124
000075e5f6dcec16  movq xmm13, xmm13
000075e5f6dcec1b  movaps xmm15, [r15+0x160]
000075e5f6dcec23  movq r14, xmm15
000075e5f6dcec28  movq r12, xmm1
000075e5f6dcec2d  vmovq xmm1, r14
000075e5f6dcec32  vmovq xmm15, r12
000075e5f6dcec37  movaps xmm14, xmm1
000075e5f6dcec3b  mulsd xmm14, xmm15
000075e5f6dcec40  ucomisd xmm14, xmm14
000075e5f6dcec45  jp 0x000075E5F6DCF170
000075e5f6dcec4b  movq xmm14, xmm14
000075e5f6dcec50  lea r14, [rax+0x140]
000075e5f6dcec57  mov r12, [r13+r14*1]
000075e5f6dcec5c  movq xmm1, r12
000075e5f6dcec61  movq r14, xmm13
000075e5f6dcec66  movq r12, xmm14
000075e5f6dcec6b  vmovq xmm15, r14
000075e5f6dcec70  vmovq xmm14, r12
000075e5f6dcec75  movaps xmm13, xmm15
000075e5f6dcec79  addsd xmm13, xmm14
000075e5f6dcec7e  ucomisd xmm13, xmm13
000075e5f6dcec83  jp 0x000075E5F6DCF1C6
000075e5f6dcec89  movq xmm13, xmm13
000075e5f6dcec8e  movaps xmm15, [r15+0x170]
000075e5f6dcec96  movq r14, xmm15
000075e5f6dcec9b  movq r12, xmm1
000075e5f6dceca0  vmovq xmm1, r14
000075e5f6dceca5  vmovq xmm15, r12
000075e5f6dcecaa  movaps xmm14, xmm1
000075e5f6dcecae  mulsd xmm14, xmm15
000075e5f6dcecb3  ucomisd xmm14, xmm14
000075e5f6dcecb8  jp 0x000075E5F6DCF212
000075e5f6dcecbe  movq xmm14, xmm14
000075e5f6dcecc3  lea r14, [rax+0x180]
000075e5f6dcecca  mov r12, [r13+r14*1]
000075e5f6dceccf  movq xmm1, r12
000075e5f6dcecd4  movq r14, xmm13
000075e5f6dcecd9  movq r12, xmm14
000075e5f6dcecde  vmovq xmm15, r14
000075e5f6dcece3  vmovq xmm14, r12
000075e5f6dcece8  movaps xmm13, xmm15
000075e5f6dcecec  addsd xmm13, xmm14
000075e5f6dcecf1  ucomisd xmm13, xmm13
000075e5f6dcecf6  jp 0x000075E5F6DCF268
000075e5f6dcecfc  movq xmm13, xmm13
000075e5f6dced01  movaps xmm15, [r15+0x180]
000075e5f6dced09  movq r14, xmm15
000075e5f6dced0e  movq r12, xmm1
000075e5f6dced13  vmovq xmm1, r14
000075e5f6dced18  vmovq xmm15, r12
000075e5f6dced1d  movaps xmm14, xmm1
000075e5f6dced21  mulsd xmm14, xmm15
000075e5f6dced26  ucomisd xmm14, xmm14
000075e5f6dced2b  jp 0x000075E5F6DCF2B4
000075e5f6dced31  movq xmm14, xmm14
000075e5f6dced36  lea r14, [rax+0x1C0]
000075e5f6dced3d  mov rax, [r13+r14*1]
000075e5f6dced42  movq xmm1, rax
000075e5f6dced47  movaps [r15+0x240], xmm1
000075e5f6dced4f  movq rax, xmm13
000075e5f6dced54  movq r14, xmm14
000075e5f6dced59  vmovq xmm15, rax
000075e5f6dced5e  vmovq xmm14, r14
000075e5f6dced63  movaps xmm13, xmm15
000075e5f6dced67  addsd xmm13, xmm14
000075e5f6dced6c  ucomisd xmm13, xmm13
000075e5f6dced71  jp 0x000075E5F6DCF30A
000075e5f6dced77  movq xmm13, xmm13
000075e5f6dced7c  movaps xmm15, [r15+0x210]
000075e5f6dced84  movq rax, xmm15
000075e5f6dced89  movq r14, xmm1
000075e5f6dced8e  vmovq xmm1, rax
000075e5f6dced93  vmovq xmm15, r14
000075e5f6dced98  movaps xmm14, xmm1
000075e5f6dced9c  mulsd xmm14, xmm15
000075e5f6dceda1  ucomisd xmm14, xmm14
000075e5f6dceda6  jp 0x000075E5F6DCF352
000075e5f6dcedac  movq xmm14, xmm14
000075e5f6dcedb1  movaps [r15+0x230], xmm14
000075e5f6dcedb9  movq rax, xmm13
000075e5f6dcedbe  movq r14, xmm14
000075e5f6dcedc3  vmovq xmm1, rax
000075e5f6dcedc8  vmovq xmm15, r14
000075e5f6dcedcd  movaps xmm14, xmm1
000075e5f6dcedd1  addsd xmm14, xmm15
000075e5f6dcedd6  ucomisd xmm14, xmm14
000075e5f6dceddb  jp 0x000075E5F6DCF39A
000075e5f6dcede1  movq xmm14, xmm14
000075e5f6dcede6  movaps [r15+0x220], xmm14
000075e5f6dcedee  movq rax, xmm14
000075e5f6dcedf3  mov r14d, 0x4205C0
000075e5f6dcedf9  mov [r13+r14*1], rax
000075e5f6dcedfe  mov qword ptr [r15+0x70], 0x08
000075e5f6dcee06  xor eax, eax
000075e5f6dcee08  mov r14d, 0x08
000075e5f6dcee0e  mov r12d, 0x40
000075e5f6dcee14  cmp r14, r12
000075e5f6dcee17  cmc
000075e5f6dcee18  lahf
000075e5f6dcee19  seto al
000075e5f6dcee1c  mov [r15+0x108], eax
000075e5f6dcee23  mov eax, [r15+0x108]
000075e5f6dcee2a  sahf
000075e5f6dcee2b  jnz 0x000075E5F6DCEE5D
000075e5f6dcee2d  cmp dword ptr [r15+0x318], 0x00
000075e5f6dcee35  jz 0x000075E5F6DCFD40
000075e5f6dcee3b  nop [rax+rax*1], ax
000075e5f6dcee44  nop [rax+rax*1], eax
000075e5f6dcee4c  mov eax, 0x410118
000075e5f6dcee51  mov [r15+0x100], rax
000075e5f6dcee58  jmp 0x000075E5F6BFE110
000075e5f6dcee5d  cmp dword ptr [r15+0x318], 0x00
000075e5f6dcee65  jz 0x000075E5F6DCF3F0
000075e5f6dcee6b  nop [rax+rax*1], ax
000075e5f6dcee74  nop [rax+rax*1], eax
000075e5f6dcee7c  mov eax, 0x4100A4
000075e5f6dcee81  mov [r15+0x100], rax
000075e5f6dcee88  jmp 0x000075E5F6BFE110
000075e5f6dcee8d  int3
000075e5f6dcee8e  call 0x000075E5F6C0DC20
000075e5f6dcee93  jmp 0x000075E5F6DCE949
000075e5f6dcee98  call 0x000075E5F6CC0370
000075e5f6dcee9d  jmp 0x000075E5F6DCE952
000075e5f6dceea2  call 0x000075E5F6CE27E0
000075e5f6dceea7  jmp 0x000075E5F6DCE989
000075e5f6dceeac  call 0x000075E5F6CE1570
000075e5f6dceeb1  jmp 0x000075E5F6DCE992
000075e5f6dceeb6  call 0x000075E5F6CE27E0
000075e5f6dceebb  jmp 0x000075E5F6DCE9C9
000075e5f6dceec0  call 0x000075E5F6CE1570
000075e5f6dceec5  jmp 0x000075E5F6DCE9D2
000075e5f6dceeca  call 0x000075E5F6CE27E0
000075e5f6dceecf  jmp 0x000075E5F6DCEA09
000075e5f6dceed4  call 0x000075E5F6CD59C0
000075e5f6dceed9  jmp 0x000075E5F6DCEA12
000075e5f6dceede  call 0x000075E5F6C0DC20
000075e5f6dceee3  jmp 0x000075E5F6DCEA4D
000075e5f6dceee8  call 0x000075E5F6CE27E0
000075e5f6dceeed  jmp 0x000075E5F6DCEA5B
000075e5f6dceef2  call 0x000075E5F6CE27E0
000075e5f6dceef7  jmp 0x000075E5F6DCEA6C
000075e5f6dceefc  ucomisd xmm15, xmm12
000075e5f6dcef01  jp 0x000075E5F6DCEF10
000075e5f6dcef03  movaps xmm11, [0x000075E5F69FE030]
000075e5f6dcef0b  jmp 0x000075E5F6DCEAA1
000075e5f6dcef10  vxorps xmm0, xmm15, xmm12
000075e5f6dcef15  pextrw r14d, xmm0, 0x03
000075e5f6dcef1b  and r14d, 0x7FF8
000075e5f6dcef22  cmp r14d, 0x08
000075e5f6dcef26  jnz 0x000075E5F6DCEAA1
000075e5f6dcef2c  movq r14, xmm12
000075e5f6dcef31  shl r14, 0x0D
000075e5f6dcef35  jbe 0x000075E5F6DCEAA1
000075e5f6dcef3b  vorps xmm11, xmm12, [0x000075E5F69FE040]
000075e5f6dcef43  jmp 0x000075E5F6DCEAA1
000075e5f6dcef48  ucomisd xmm15, xmm14
000075e5f6dcef4d  jp 0x000075E5F6DCEF5C
000075e5f6dcef4f  movaps xmm12, [0x000075E5F69FE030]
000075e5f6dcef57  jmp 0x000075E5F6DCEAD6
000075e5f6dcef5c  vxorps xmm0, xmm15, xmm14
000075e5f6dcef61  pextrw r14d, xmm0, 0x03
000075e5f6dcef67  and r14d, 0x7FF8
000075e5f6dcef6e  cmp r14d, 0x08
000075e5f6dcef72  jnz 0x000075E5F6DCEAD6
000075e5f6dcef78  movq r14, xmm14
000075e5f6dcef7d  shl r14, 0x0D
000075e5f6dcef81  jbe 0x000075E5F6DCEAD6
000075e5f6dcef87  vorps xmm12, xmm14, [0x000075E5F69FE040]
000075e5f6dcef8f  jmp 0x000075E5F6DCEAD6
000075e5f6dcef94  ucomisd xmm1, xmm15
000075e5f6dcef99  jp 0x000075E5F6DCEFA8
000075e5f6dcef9b  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcefa3  jmp 0x000075E5F6DCEB03
000075e5f6dcefa8  vxorps xmm0, xmm1, xmm15
000075e5f6dcefad  pextrw r14d, xmm0, 0x03
000075e5f6dcefb3  and r14d, 0x7FF8
000075e5f6dcefba  cmp r14d, 0x08
000075e5f6dcefbe  jnz 0x000075E5F6DCEB03
000075e5f6dcefc4  movq r14, xmm15
000075e5f6dcefc9  shl r14, 0x0D
000075e5f6dcefcd  jbe 0x000075E5F6DCEB03
000075e5f6dcefd3  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcefdb  jmp 0x000075E5F6DCEB03
000075e5f6dcefe0  ucomisd xmm1, xmm15
000075e5f6dcefe5  jp 0x000075E5F6DCEFF4
000075e5f6dcefe7  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcefef  jmp 0x000075E5F6DCEB30
000075e5f6dceff4  vxorps xmm0, xmm1, xmm15
000075e5f6dceff9  pextrw r14d, xmm0, 0x03
000075e5f6dcefff  and r14d, 0x7FF8
000075e5f6dcf006  cmp r14d, 0x08
000075e5f6dcf00a  jnz 0x000075E5F6DCEB30
000075e5f6dcf010  movq r14, xmm15
000075e5f6dcf015  shl r14, 0x0D
000075e5f6dcf019  jbe 0x000075E5F6DCEB30
000075e5f6dcf01f  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcf027  jmp 0x000075E5F6DCEB30
000075e5f6dcf02c  ucomisd xmm1, xmm15
000075e5f6dcf031  jp 0x000075E5F6DCF040
000075e5f6dcf033  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dcf03b  jmp 0x000075E5F6DCEB65
000075e5f6dcf040  vxorps xmm0, xmm1, xmm15
000075e5f6dcf045  pextrw r14d, xmm0, 0x03
000075e5f6dcf04b  and r14d, 0x7FF8
000075e5f6dcf052  cmp r14d, 0x08
000075e5f6dcf056  jnz 0x000075E5F6DCEB65
000075e5f6dcf05c  movq r14, xmm15
000075e5f6dcf061  shl r14, 0x0D
000075e5f6dcf065  jbe 0x000075E5F6DCEB65
000075e5f6dcf06b  vorps xmm13, xmm15, [0x000075E5F69FE040]
000075e5f6dcf073  jmp 0x000075E5F6DCEB65
000075e5f6dcf078  call 0x000075E5F6CE27E0
000075e5f6dcf07d  jmp 0x000075E5F6DCEB76
000075e5f6dcf082  ucomisd xmm15, xmm14
000075e5f6dcf087  jp 0x000075E5F6DCF096
000075e5f6dcf089  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dcf091  jmp 0x000075E5F6DCEBA3
000075e5f6dcf096  vxorps xmm0, xmm15, xmm14
000075e5f6dcf09b  pextrw r14d, xmm0, 0x03
000075e5f6dcf0a1  and r14d, 0x7FF8
000075e5f6dcf0a8  cmp r14d, 0x08
000075e5f6dcf0ac  jnz 0x000075E5F6DCEBA3
000075e5f6dcf0b2  movq r14, xmm14
000075e5f6dcf0b7  shl r14, 0x0D
000075e5f6dcf0bb  jbe 0x000075E5F6DCEBA3
000075e5f6dcf0c1  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dcf0c9  jmp 0x000075E5F6DCEBA3
000075e5f6dcf0ce  ucomisd xmm1, xmm15
000075e5f6dcf0d3  jp 0x000075E5F6DCF0E2
000075e5f6dcf0d5  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcf0dd  jmp 0x000075E5F6DCEBD8
000075e5f6dcf0e2  vxorps xmm0, xmm1, xmm15
000075e5f6dcf0e7  pextrw r14d, xmm0, 0x03
000075e5f6dcf0ed  and r14d, 0x7FF8
000075e5f6dcf0f4  cmp r14d, 0x08
000075e5f6dcf0f8  jnz 0x000075E5F6DCEBD8
000075e5f6dcf0fe  movq r14, xmm15
000075e5f6dcf103  shl r14, 0x0D
000075e5f6dcf107  jbe 0x000075E5F6DCEBD8
000075e5f6dcf10d  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcf115  jmp 0x000075E5F6DCEBD8
000075e5f6dcf11a  call 0x000075E5F6CE27E0
000075e5f6dcf11f  jmp 0x000075E5F6DCEBE9
000075e5f6dcf124  ucomisd xmm15, xmm14
000075e5f6dcf129  jp 0x000075E5F6DCF138
000075e5f6dcf12b  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dcf133  jmp 0x000075E5F6DCEC16
000075e5f6dcf138  vxorps xmm0, xmm15, xmm14
000075e5f6dcf13d  pextrw r14d, xmm0, 0x03
000075e5f6dcf143  and r14d, 0x7FF8
000075e5f6dcf14a  cmp r14d, 0x08
000075e5f6dcf14e  jnz 0x000075E5F6DCEC16
000075e5f6dcf154  movq r14, xmm14
000075e5f6dcf159  shl r14, 0x0D
000075e5f6dcf15d  jbe 0x000075E5F6DCEC16
000075e5f6dcf163  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dcf16b  jmp 0x000075E5F6DCEC16
000075e5f6dcf170  ucomisd xmm1, xmm15
000075e5f6dcf175  jp 0x000075E5F6DCF184
000075e5f6dcf177  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcf17f  jmp 0x000075E5F6DCEC4B
000075e5f6dcf184  vxorps xmm0, xmm1, xmm15
000075e5f6dcf189  pextrw r14d, xmm0, 0x03
000075e5f6dcf18f  and r14d, 0x7FF8
000075e5f6dcf196  cmp r14d, 0x08
000075e5f6dcf19a  jnz 0x000075E5F6DCEC4B
000075e5f6dcf1a0  movq r14, xmm15
000075e5f6dcf1a5  shl r14, 0x0D
000075e5f6dcf1a9  jbe 0x000075E5F6DCEC4B
000075e5f6dcf1af  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcf1b7  jmp 0x000075E5F6DCEC4B
000075e5f6dcf1bc  call 0x000075E5F6CE27E0
000075e5f6dcf1c1  jmp 0x000075E5F6DCEC5C
000075e5f6dcf1c6  ucomisd xmm15, xmm14
000075e5f6dcf1cb  jp 0x000075E5F6DCF1DA
000075e5f6dcf1cd  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dcf1d5  jmp 0x000075E5F6DCEC89
000075e5f6dcf1da  vxorps xmm0, xmm15, xmm14
000075e5f6dcf1df  pextrw r14d, xmm0, 0x03
000075e5f6dcf1e5  and r14d, 0x7FF8
000075e5f6dcf1ec  cmp r14d, 0x08
000075e5f6dcf1f0  jnz 0x000075E5F6DCEC89
000075e5f6dcf1f6  movq r14, xmm14
000075e5f6dcf1fb  shl r14, 0x0D
000075e5f6dcf1ff  jbe 0x000075E5F6DCEC89
000075e5f6dcf205  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dcf20d  jmp 0x000075E5F6DCEC89
000075e5f6dcf212  ucomisd xmm1, xmm15
000075e5f6dcf217  jp 0x000075E5F6DCF226
000075e5f6dcf219  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcf221  jmp 0x000075E5F6DCECBE
000075e5f6dcf226  vxorps xmm0, xmm1, xmm15
000075e5f6dcf22b  pextrw r14d, xmm0, 0x03
000075e5f6dcf231  and r14d, 0x7FF8
000075e5f6dcf238  cmp r14d, 0x08
000075e5f6dcf23c  jnz 0x000075E5F6DCECBE
000075e5f6dcf242  movq r14, xmm15
000075e5f6dcf247  shl r14, 0x0D
000075e5f6dcf24b  jbe 0x000075E5F6DCECBE
000075e5f6dcf251  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcf259  jmp 0x000075E5F6DCECBE
000075e5f6dcf25e  call 0x000075E5F6CE27E0
000075e5f6dcf263  jmp 0x000075E5F6DCECCF
000075e5f6dcf268  ucomisd xmm15, xmm14
000075e5f6dcf26d  jp 0x000075E5F6DCF27C
000075e5f6dcf26f  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dcf277  jmp 0x000075E5F6DCECFC
000075e5f6dcf27c  vxorps xmm0, xmm15, xmm14
000075e5f6dcf281  pextrw r14d, xmm0, 0x03
000075e5f6dcf287  and r14d, 0x7FF8
000075e5f6dcf28e  cmp r14d, 0x08
000075e5f6dcf292  jnz 0x000075E5F6DCECFC
000075e5f6dcf298  movq r14, xmm14
000075e5f6dcf29d  shl r14, 0x0D
000075e5f6dcf2a1  jbe 0x000075E5F6DCECFC
000075e5f6dcf2a7  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dcf2af  jmp 0x000075E5F6DCECFC
000075e5f6dcf2b4  ucomisd xmm1, xmm15
000075e5f6dcf2b9  jp 0x000075E5F6DCF2C8
000075e5f6dcf2bb  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcf2c3  jmp 0x000075E5F6DCED31
000075e5f6dcf2c8  vxorps xmm0, xmm1, xmm15
000075e5f6dcf2cd  pextrw r14d, xmm0, 0x03
000075e5f6dcf2d3  and r14d, 0x7FF8
000075e5f6dcf2da  cmp r14d, 0x08
000075e5f6dcf2de  jnz 0x000075E5F6DCED31
000075e5f6dcf2e4  movq r14, xmm15
000075e5f6dcf2e9  shl r14, 0x0D
000075e5f6dcf2ed  jbe 0x000075E5F6DCED31
000075e5f6dcf2f3  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcf2fb  jmp 0x000075E5F6DCED31
000075e5f6dcf300  call 0x000075E5F6CD59C0
000075e5f6dcf305  jmp 0x000075E5F6DCED42
000075e5f6dcf30a  ucomisd xmm15, xmm14
000075e5f6dcf30f  jp 0x000075E5F6DCF31E
000075e5f6dcf311  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dcf319  jmp 0x000075E5F6DCED77
000075e5f6dcf31e  vxorps xmm0, xmm15, xmm14
000075e5f6dcf323  pextrw eax, xmm0, 0x03
000075e5f6dcf328  and eax, 0x7FF8
000075e5f6dcf32d  cmp eax, 0x08
000075e5f6dcf330  jnz 0x000075E5F6DCED77
000075e5f6dcf336  movq rax, xmm14
000075e5f6dcf33b  shl rax, 0x0D
000075e5f6dcf33f  jbe 0x000075E5F6DCED77
000075e5f6dcf345  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dcf34d  jmp 0x000075E5F6DCED77
000075e5f6dcf352  ucomisd xmm1, xmm15
000075e5f6dcf357  jp 0x000075E5F6DCF366
000075e5f6dcf359  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcf361  jmp 0x000075E5F6DCEDAC
000075e5f6dcf366  vxorps xmm0, xmm1, xmm15
000075e5f6dcf36b  pextrw eax, xmm0, 0x03
000075e5f6dcf370  and eax, 0x7FF8
000075e5f6dcf375  cmp eax, 0x08
000075e5f6dcf378  jnz 0x000075E5F6DCEDAC
000075e5f6dcf37e  movq rax, xmm15
000075e5f6dcf383  shl rax, 0x0D
000075e5f6dcf387  jbe 0x000075E5F6DCEDAC
000075e5f6dcf38d  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcf395  jmp 0x000075E5F6DCEDAC
000075e5f6dcf39a  ucomisd xmm1, xmm15
000075e5f6dcf39f  jp 0x000075E5F6DCF3AE
000075e5f6dcf3a1  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcf3a9  jmp 0x000075E5F6DCEDE1
000075e5f6dcf3ae  vxorps xmm0, xmm1, xmm15
000075e5f6dcf3b3  pextrw eax, xmm0, 0x03
000075e5f6dcf3b8  and eax, 0x7FF8
000075e5f6dcf3bd  cmp eax, 0x08
000075e5f6dcf3c0  jnz 0x000075E5F6DCEDE1
000075e5f6dcf3c6  movq rax, xmm15
000075e5f6dcf3cb  shl rax, 0x0D
000075e5f6dcf3cf  jbe 0x000075E5F6DCEDE1
000075e5f6dcf3d5  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcf3dd  jmp 0x000075E5F6DCEDE1
000075e5f6dcf3e2  call 0x000075E5F6CD5EB0
000075e5f6dcf3e7  jmp 0x000075E5F6DCEDFE
000075e5f6dcf3ec  int3
000075e5f6dcf3ed  nop [rax], eax
000075e5f6dcf3f0  mov rax, [r15+0x48]
000075e5f6dcf3f4  mov r14, [r15+0x70]
000075e5f6dcf3f8  lea r12, [rax+r14*1]
000075e5f6dcf3fc  mov [r15+0x78], r12
000075e5f6dcf400  mov rax, [r13+r12*1]
000075e5f6dcf405  movq xmm1, rax
000075e5f6dcf40a  lea rax, [r12+0x40]
000075e5f6dcf40f  mov r11, [r13+rax*1]
000075e5f6dcf414  movq xmm15, r11
000075e5f6dcf419  lea rax, [r12+0x80]
000075e5f6dcf421  mov r11, [r13+rax*1]
000075e5f6dcf426  movq xmm14, r11
000075e5f6dcf42b  movaps xmm13, [r15+0x120]
000075e5f6dcf433  movq rax, xmm13
000075e5f6dcf438  movq r11, xmm1
000075e5f6dcf43d  vmovq xmm1, rax
000075e5f6dcf442  vmovq xmm13, r11
000075e5f6dcf447  movaps xmm12, xmm1
000075e5f6dcf44b  mulsd xmm12, xmm13
000075e5f6dcf450  ucomisd xmm12, xmm12
000075e5f6dcf455  jp 0x000075E5F6DCF879
000075e5f6dcf45b  movq xmm12, xmm12
000075e5f6dcf460  movaps xmm1, [r15+0x130]
000075e5f6dcf468  movq rax, xmm1
000075e5f6dcf46d  movq r11, xmm15
000075e5f6dcf472  vmovq xmm1, rax
000075e5f6dcf477  vmovq xmm15, r11
000075e5f6dcf47c  movaps xmm13, xmm1
000075e5f6dcf480  mulsd xmm13, xmm15
000075e5f6dcf485  ucomisd xmm13, xmm13
000075e5f6dcf48a  jp 0x000075E5F6DCF8C1
000075e5f6dcf490  movq xmm13, xmm13
000075e5f6dcf495  movq rax, xmm12
000075e5f6dcf49a  movaps xmm1, [r15+0x110]
000075e5f6dcf4a2  movq r11, xmm1
000075e5f6dcf4a7  vmovq xmm1, rax
000075e5f6dcf4ac  vmovq xmm15, r11
000075e5f6dcf4b1  movaps xmm12, xmm1
000075e5f6dcf4b5  addsd xmm12, xmm15
000075e5f6dcf4ba  ucomisd xmm12, xmm12
000075e5f6dcf4bf  jp 0x000075E5F6DCF909
000075e5f6dcf4c5  movq xmm12, xmm12
000075e5f6dcf4ca  movq rax, xmm12
000075e5f6dcf4cf  movq r11, xmm13
000075e5f6dcf4d4  vmovq xmm1, rax
000075e5f6dcf4d9  vmovq xmm15, r11
000075e5f6dcf4de  movaps xmm13, xmm1
000075e5f6dcf4e2  addsd xmm13, xmm15
000075e5f6dcf4e7  ucomisd xmm13, xmm13
000075e5f6dcf4ec  jp 0x000075E5F6DCF951
000075e5f6dcf4f2  movq xmm13, xmm13
000075e5f6dcf4f7  movaps xmm1, [r15+0x140]
000075e5f6dcf4ff  movq rax, xmm1
000075e5f6dcf504  movq r11, xmm14
000075e5f6dcf509  vmovq xmm1, rax
000075e5f6dcf50e  vmovq xmm15, r11
000075e5f6dcf513  movaps xmm14, xmm1
000075e5f6dcf517  mulsd xmm14, xmm15
000075e5f6dcf51c  ucomisd xmm14, xmm14
000075e5f6dcf521  jp 0x000075E5F6DCF999
000075e5f6dcf527  movq xmm14, xmm14
000075e5f6dcf52c  lea rax, [r12+0xC0]
000075e5f6dcf534  mov r11, [r13+rax*1]
000075e5f6dcf539  movq xmm1, r11
000075e5f6dcf53e  movq rax, xmm13
000075e5f6dcf543  movq r11, xmm14
000075e5f6dcf548  vmovq xmm15, rax
000075e5f6dcf54d  vmovq xmm14, r11
000075e5f6dcf552  movaps xmm13, xmm15
000075e5f6dcf556  addsd xmm13, xmm14
000075e5f6dcf55b  ucomisd xmm13, xmm13
000075e5f6dcf560  jp 0x000075E5F6DCF9EB
000075e5f6dcf566  movq xmm13, xmm13
000075e5f6dcf56b  movaps xmm15, [r15+0x150]
000075e5f6dcf573  movq rax, xmm15
000075e5f6dcf578  movq r11, xmm1
000075e5f6dcf57d  vmovq xmm1, rax
000075e5f6dcf582  vmovq xmm15, r11
000075e5f6dcf587  movaps xmm14, xmm1
000075e5f6dcf58b  mulsd xmm14, xmm15
000075e5f6dcf590  ucomisd xmm14, xmm14
000075e5f6dcf595  jp 0x000075E5F6DCFA33
000075e5f6dcf59b  movq xmm14, xmm14
000075e5f6dcf5a0  lea rax, [r12+0x100]
000075e5f6dcf5a8  mov r11, [r13+rax*1]
000075e5f6dcf5ad  movq xmm1, r11
000075e5f6dcf5b2  movq rax, xmm13
000075e5f6dcf5b7  movq r11, xmm14
000075e5f6dcf5bc  vmovq xmm15, rax
000075e5f6dcf5c1  vmovq xmm14, r11
000075e5f6dcf5c6  movaps xmm13, xmm15
000075e5f6dcf5ca  addsd xmm13, xmm14
000075e5f6dcf5cf  ucomisd xmm13, xmm13
000075e5f6dcf5d4  jp 0x000075E5F6DCFA85
000075e5f6dcf5da  movq xmm13, xmm13
000075e5f6dcf5df  movaps xmm15, [r15+0x160]
000075e5f6dcf5e7  movq rax, xmm15
000075e5f6dcf5ec  movq r11, xmm1
000075e5f6dcf5f1  vmovq xmm1, rax
000075e5f6dcf5f6  vmovq xmm15, r11
000075e5f6dcf5fb  movaps xmm14, xmm1
000075e5f6dcf5ff  mulsd xmm14, xmm15
000075e5f6dcf604  ucomisd xmm14, xmm14
000075e5f6dcf609  jp 0x000075E5F6DCFACD
000075e5f6dcf60f  movq xmm14, xmm14
000075e5f6dcf614  lea rax, [r12+0x140]
000075e5f6dcf61c  mov r11, [r13+rax*1]
000075e5f6dcf621  movq xmm1, r11
000075e5f6dcf626  movq rax, xmm13
000075e5f6dcf62b  movq r11, xmm14
000075e5f6dcf630  vmovq xmm15, rax
000075e5f6dcf635  vmovq xmm14, r11
000075e5f6dcf63a  movaps xmm13, xmm15
000075e5f6dcf63e  addsd xmm13, xmm14
000075e5f6dcf643  ucomisd xmm13, xmm13
000075e5f6dcf648  jp 0x000075E5F6DCFB1F
000075e5f6dcf64e  movq xmm13, xmm13
000075e5f6dcf653  movaps xmm15, [r15+0x170]
000075e5f6dcf65b  movq rax, xmm15
000075e5f6dcf660  movq r11, xmm1
000075e5f6dcf665  vmovq xmm1, rax
000075e5f6dcf66a  vmovq xmm15, r11
000075e5f6dcf66f  movaps xmm14, xmm1
000075e5f6dcf673  mulsd xmm14, xmm15
000075e5f6dcf678  ucomisd xmm14, xmm14
000075e5f6dcf67d  jp 0x000075E5F6DCFB67
000075e5f6dcf683  movq xmm14, xmm14
000075e5f6dcf688  lea rax, [r12+0x180]
000075e5f6dcf690  mov r11, [r13+rax*1]
000075e5f6dcf695  movq xmm1, r11
000075e5f6dcf69a  movq rax, xmm13
000075e5f6dcf69f  movq r11, xmm14
000075e5f6dcf6a4  vmovq xmm15, rax
000075e5f6dcf6a9  vmovq xmm14, r11
000075e5f6dcf6ae  movaps xmm13, xmm15
000075e5f6dcf6b2  addsd xmm13, xmm14
000075e5f6dcf6b7  ucomisd xmm13, xmm13
000075e5f6dcf6bc  jp 0x000075E5F6DCFBB9
000075e5f6dcf6c2  movq xmm13, xmm13
000075e5f6dcf6c7  movaps xmm15, [r15+0x180]
000075e5f6dcf6cf  movq rax, xmm15
000075e5f6dcf6d4  movq r11, xmm1
000075e5f6dcf6d9  vmovq xmm1, rax
000075e5f6dcf6de  vmovq xmm15, r11
000075e5f6dcf6e3  movaps xmm14, xmm1
000075e5f6dcf6e7  mulsd xmm14, xmm15
000075e5f6dcf6ec  ucomisd xmm14, xmm14
000075e5f6dcf6f1  jp 0x000075E5F6DCFC01
000075e5f6dcf6f7  movq xmm14, xmm14
000075e5f6dcf6fc  lea rax, [r12+0x1C0]
000075e5f6dcf704  mov r12, [r13+rax*1]
000075e5f6dcf709  movq xmm1, r12
000075e5f6dcf70e  movaps [r15+0x240], xmm1
000075e5f6dcf716  movq rax, xmm13
000075e5f6dcf71b  movq r12, xmm14
000075e5f6dcf720  vmovq xmm15, rax
000075e5f6dcf725  vmovq xmm14, r12
000075e5f6dcf72a  movaps xmm13, xmm15
000075e5f6dcf72e  addsd xmm13, xmm14
000075e5f6dcf733  ucomisd xmm13, xmm13
000075e5f6dcf738  jp 0x000075E5F6DCFC53
000075e5f6dcf73e  movq xmm13, xmm13
000075e5f6dcf743  movaps xmm15, [r15+0x210]
000075e5f6dcf74b  movq rax, xmm15
000075e5f6dcf750  movq r12, xmm1
000075e5f6dcf755  vmovq xmm1, rax
000075e5f6dcf75a  vmovq xmm15, r12
000075e5f6dcf75f  movaps xmm14, xmm1
000075e5f6dcf763  mulsd xmm14, xmm15
000075e5f6dcf768  ucomisd xmm14, xmm14
000075e5f6dcf76d  jp 0x000075E5F6DCFC9B
000075e5f6dcf773  movq xmm14, xmm14
000075e5f6dcf778  movaps [r15+0x230], xmm14
000075e5f6dcf780  movq rax, xmm13
000075e5f6dcf785  movq r12, xmm14
000075e5f6dcf78a  vmovq xmm1, rax
000075e5f6dcf78f  vmovq xmm15, r12
000075e5f6dcf794  movaps xmm14, xmm1
000075e5f6dcf798  addsd xmm14, xmm15
000075e5f6dcf79d  ucomisd xmm14, xmm14
000075e5f6dcf7a2  jp 0x000075E5F6DCFCE3
000075e5f6dcf7a8  movq xmm14, xmm14
000075e5f6dcf7ad  movaps [r15+0x220], xmm14
000075e5f6dcf7b5  mov rax, [r15+0x68]
000075e5f6dcf7b9  lea r12, [rax+r14*1]
000075e5f6dcf7bd  movq rax, xmm14
000075e5f6dcf7c2  mov [r13+r12*1], rax
000075e5f6dcf7c7  lea rax, [r14+0x08]
000075e5f6dcf7cb  mov [r15+0x70], rax
000075e5f6dcf7cf  mov [rsp+0x10], rax
000075e5f6dcf7d4  xor eax, eax
000075e5f6dcf7d6  mov r14, [rsp+0x10]
000075e5f6dcf7db  mov r12d, 0x40
000075e5f6dcf7e1  cmp r14, r12
000075e5f6dcf7e4  cmc
000075e5f6dcf7e5  lahf
000075e5f6dcf7e6  seto al
000075e5f6dcf7e9  mov [r15+0x108], eax
000075e5f6dcf7f0  mov eax, [r15+0x108]
000075e5f6dcf7f7  sahf
000075e5f6dcf7f8  jnz 0x000075E5F6DCF82A
000075e5f6dcf7fa  cmp dword ptr [r15+0x318], 0x00
000075e5f6dcf802  jz 0x000075E5F6DCFD40
000075e5f6dcf808  nop [rax+rax*1], ax
000075e5f6dcf811  nop [rax+rax*1], eax
000075e5f6dcf819  mov eax, 0x410118
000075e5f6dcf81e  mov [r15+0x100], rax
000075e5f6dcf825  jmp 0x000075E5F6BFE110
000075e5f6dcf82a  cmp dword ptr [r15+0x318], 0x00
000075e5f6dcf832  jz 0x000075E5F6DCF3F0
000075e5f6dcf838  nop [rax+rax*1], ax
000075e5f6dcf841  nop [rax+rax*1], eax
000075e5f6dcf849  mov eax, 0x4100A4
000075e5f6dcf84e  mov [r15+0x100], rax
000075e5f6dcf855  jmp 0x000075E5F6BFE110
000075e5f6dcf85a  int3
000075e5f6dcf85b  call 0x000075E5F6CB47C0
000075e5f6dcf860  jmp 0x000075E5F6DCF405
000075e5f6dcf865  call 0x000075E5F6C0A4B0
000075e5f6dcf86a  jmp 0x000075E5F6DCF414
000075e5f6dcf86f  call 0x000075E5F6C0A4B0
000075e5f6dcf874  jmp 0x000075E5F6DCF426
000075e5f6dcf879  ucomisd xmm1, xmm13
000075e5f6dcf87e  jp 0x000075E5F6DCF88D
000075e5f6dcf880  movaps xmm12, [0x000075E5F69FE030]
000075e5f6dcf888  jmp 0x000075E5F6DCF45B
000075e5f6dcf88d  vxorps xmm0, xmm1, xmm13
000075e5f6dcf892  pextrw eax, xmm0, 0x03
000075e5f6dcf897  and eax, 0x7FF8
000075e5f6dcf89c  cmp eax, 0x08
000075e5f6dcf89f  jnz 0x000075E5F6DCF45B
000075e5f6dcf8a5  movq rax, xmm13
000075e5f6dcf8aa  shl rax, 0x0D
000075e5f6dcf8ae  jbe 0x000075E5F6DCF45B
000075e5f6dcf8b4  vorps xmm12, xmm13, [0x000075E5F69FE040]
000075e5f6dcf8bc  jmp 0x000075E5F6DCF45B
000075e5f6dcf8c1  ucomisd xmm1, xmm15
000075e5f6dcf8c6  jp 0x000075E5F6DCF8D5
000075e5f6dcf8c8  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dcf8d0  jmp 0x000075E5F6DCF490
000075e5f6dcf8d5  vxorps xmm0, xmm1, xmm15
000075e5f6dcf8da  pextrw eax, xmm0, 0x03
000075e5f6dcf8df  and eax, 0x7FF8
000075e5f6dcf8e4  cmp eax, 0x08
000075e5f6dcf8e7  jnz 0x000075E5F6DCF490
000075e5f6dcf8ed  movq rax, xmm15
000075e5f6dcf8f2  shl rax, 0x0D
000075e5f6dcf8f6  jbe 0x000075E5F6DCF490
000075e5f6dcf8fc  vorps xmm13, xmm15, [0x000075E5F69FE040]
000075e5f6dcf904  jmp 0x000075E5F6DCF490
000075e5f6dcf909  ucomisd xmm1, xmm15
000075e5f6dcf90e  jp 0x000075E5F6DCF91D
000075e5f6dcf910  movaps xmm12, [0x000075E5F69FE030]
000075e5f6dcf918  jmp 0x000075E5F6DCF4C5
000075e5f6dcf91d  vxorps xmm0, xmm1, xmm15
000075e5f6dcf922  pextrw eax, xmm0, 0x03
000075e5f6dcf927  and eax, 0x7FF8
000075e5f6dcf92c  cmp eax, 0x08
000075e5f6dcf92f  jnz 0x000075E5F6DCF4C5
000075e5f6dcf935  movq rax, xmm15
000075e5f6dcf93a  shl rax, 0x0D
000075e5f6dcf93e  jbe 0x000075E5F6DCF4C5
000075e5f6dcf944  vorps xmm12, xmm15, [0x000075E5F69FE040]
000075e5f6dcf94c  jmp 0x000075E5F6DCF4C5
000075e5f6dcf951  ucomisd xmm1, xmm15
000075e5f6dcf956  jp 0x000075E5F6DCF965
000075e5f6dcf958  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dcf960  jmp 0x000075E5F6DCF4F2
000075e5f6dcf965  vxorps xmm0, xmm1, xmm15
000075e5f6dcf96a  pextrw eax, xmm0, 0x03
000075e5f6dcf96f  and eax, 0x7FF8
000075e5f6dcf974  cmp eax, 0x08
000075e5f6dcf977  jnz 0x000075E5F6DCF4F2
000075e5f6dcf97d  movq rax, xmm15
000075e5f6dcf982  shl rax, 0x0D
000075e5f6dcf986  jbe 0x000075E5F6DCF4F2
000075e5f6dcf98c  vorps xmm13, xmm15, [0x000075E5F69FE040]
000075e5f6dcf994  jmp 0x000075E5F6DCF4F2
000075e5f6dcf999  ucomisd xmm1, xmm15
000075e5f6dcf99e  jp 0x000075E5F6DCF9AD
000075e5f6dcf9a0  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcf9a8  jmp 0x000075E5F6DCF527
000075e5f6dcf9ad  vxorps xmm0, xmm1, xmm15
000075e5f6dcf9b2  pextrw eax, xmm0, 0x03
000075e5f6dcf9b7  and eax, 0x7FF8
000075e5f6dcf9bc  cmp eax, 0x08
000075e5f6dcf9bf  jnz 0x000075E5F6DCF527
000075e5f6dcf9c5  movq rax, xmm15
000075e5f6dcf9ca  shl rax, 0x0D
000075e5f6dcf9ce  jbe 0x000075E5F6DCF527
000075e5f6dcf9d4  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcf9dc  jmp 0x000075E5F6DCF527
000075e5f6dcf9e1  call 0x000075E5F6C0A4B0
000075e5f6dcf9e6  jmp 0x000075E5F6DCF539
000075e5f6dcf9eb  ucomisd xmm15, xmm14
000075e5f6dcf9f0  jp 0x000075E5F6DCF9FF
000075e5f6dcf9f2  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dcf9fa  jmp 0x000075E5F6DCF566
000075e5f6dcf9ff  vxorps xmm0, xmm15, xmm14
000075e5f6dcfa04  pextrw eax, xmm0, 0x03
000075e5f6dcfa09  and eax, 0x7FF8
000075e5f6dcfa0e  cmp eax, 0x08
000075e5f6dcfa11  jnz 0x000075E5F6DCF566
000075e5f6dcfa17  movq rax, xmm14
000075e5f6dcfa1c  shl rax, 0x0D
000075e5f6dcfa20  jbe 0x000075E5F6DCF566
000075e5f6dcfa26  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dcfa2e  jmp 0x000075E5F6DCF566
000075e5f6dcfa33  ucomisd xmm1, xmm15
000075e5f6dcfa38  jp 0x000075E5F6DCFA47
000075e5f6dcfa3a  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcfa42  jmp 0x000075E5F6DCF59B
000075e5f6dcfa47  vxorps xmm0, xmm1, xmm15
000075e5f6dcfa4c  pextrw eax, xmm0, 0x03
000075e5f6dcfa51  and eax, 0x7FF8
000075e5f6dcfa56  cmp eax, 0x08
000075e5f6dcfa59  jnz 0x000075E5F6DCF59B
000075e5f6dcfa5f  movq rax, xmm15
000075e5f6dcfa64  shl rax, 0x0D
000075e5f6dcfa68  jbe 0x000075E5F6DCF59B
000075e5f6dcfa6e  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcfa76  jmp 0x000075E5F6DCF59B
000075e5f6dcfa7b  call 0x000075E5F6C0A4B0
000075e5f6dcfa80  jmp 0x000075E5F6DCF5AD
000075e5f6dcfa85  ucomisd xmm15, xmm14
000075e5f6dcfa8a  jp 0x000075E5F6DCFA99
000075e5f6dcfa8c  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dcfa94  jmp 0x000075E5F6DCF5DA
000075e5f6dcfa99  vxorps xmm0, xmm15, xmm14
000075e5f6dcfa9e  pextrw eax, xmm0, 0x03
000075e5f6dcfaa3  and eax, 0x7FF8
000075e5f6dcfaa8  cmp eax, 0x08
000075e5f6dcfaab  jnz 0x000075E5F6DCF5DA
000075e5f6dcfab1  movq rax, xmm14
000075e5f6dcfab6  shl rax, 0x0D
000075e5f6dcfaba  jbe 0x000075E5F6DCF5DA
000075e5f6dcfac0  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dcfac8  jmp 0x000075E5F6DCF5DA
000075e5f6dcfacd  ucomisd xmm1, xmm15
000075e5f6dcfad2  jp 0x000075E5F6DCFAE1
000075e5f6dcfad4  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcfadc  jmp 0x000075E5F6DCF60F
000075e5f6dcfae1  vxorps xmm0, xmm1, xmm15
000075e5f6dcfae6  pextrw eax, xmm0, 0x03
000075e5f6dcfaeb  and eax, 0x7FF8
000075e5f6dcfaf0  cmp eax, 0x08
000075e5f6dcfaf3  jnz 0x000075E5F6DCF60F
000075e5f6dcfaf9  movq rax, xmm15
000075e5f6dcfafe  shl rax, 0x0D
000075e5f6dcfb02  jbe 0x000075E5F6DCF60F
000075e5f6dcfb08  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcfb10  jmp 0x000075E5F6DCF60F
000075e5f6dcfb15  call 0x000075E5F6C0A4B0
000075e5f6dcfb1a  jmp 0x000075E5F6DCF621
000075e5f6dcfb1f  ucomisd xmm15, xmm14
000075e5f6dcfb24  jp 0x000075E5F6DCFB33
000075e5f6dcfb26  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dcfb2e  jmp 0x000075E5F6DCF64E
000075e5f6dcfb33  vxorps xmm0, xmm15, xmm14
000075e5f6dcfb38  pextrw eax, xmm0, 0x03
000075e5f6dcfb3d  and eax, 0x7FF8
000075e5f6dcfb42  cmp eax, 0x08
000075e5f6dcfb45  jnz 0x000075E5F6DCF64E
000075e5f6dcfb4b  movq rax, xmm14
000075e5f6dcfb50  shl rax, 0x0D
000075e5f6dcfb54  jbe 0x000075E5F6DCF64E
000075e5f6dcfb5a  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dcfb62  jmp 0x000075E5F6DCF64E
000075e5f6dcfb67  ucomisd xmm1, xmm15
000075e5f6dcfb6c  jp 0x000075E5F6DCFB7B
000075e5f6dcfb6e  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcfb76  jmp 0x000075E5F6DCF683
000075e5f6dcfb7b  vxorps xmm0, xmm1, xmm15
000075e5f6dcfb80  pextrw eax, xmm0, 0x03
000075e5f6dcfb85  and eax, 0x7FF8
000075e5f6dcfb8a  cmp eax, 0x08
000075e5f6dcfb8d  jnz 0x000075E5F6DCF683
000075e5f6dcfb93  movq rax, xmm15
000075e5f6dcfb98  shl rax, 0x0D
000075e5f6dcfb9c  jbe 0x000075E5F6DCF683
000075e5f6dcfba2  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcfbaa  jmp 0x000075E5F6DCF683
000075e5f6dcfbaf  call 0x000075E5F6C0A4B0
000075e5f6dcfbb4  jmp 0x000075E5F6DCF695
000075e5f6dcfbb9  ucomisd xmm15, xmm14
000075e5f6dcfbbe  jp 0x000075E5F6DCFBCD
000075e5f6dcfbc0  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dcfbc8  jmp 0x000075E5F6DCF6C2
000075e5f6dcfbcd  vxorps xmm0, xmm15, xmm14
000075e5f6dcfbd2  pextrw eax, xmm0, 0x03
000075e5f6dcfbd7  and eax, 0x7FF8
000075e5f6dcfbdc  cmp eax, 0x08
000075e5f6dcfbdf  jnz 0x000075E5F6DCF6C2
000075e5f6dcfbe5  movq rax, xmm14
000075e5f6dcfbea  shl rax, 0x0D
000075e5f6dcfbee  jbe 0x000075E5F6DCF6C2
000075e5f6dcfbf4  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dcfbfc  jmp 0x000075E5F6DCF6C2
000075e5f6dcfc01  ucomisd xmm1, xmm15
000075e5f6dcfc06  jp 0x000075E5F6DCFC15
000075e5f6dcfc08  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcfc10  jmp 0x000075E5F6DCF6F7
000075e5f6dcfc15  vxorps xmm0, xmm1, xmm15
000075e5f6dcfc1a  pextrw eax, xmm0, 0x03
000075e5f6dcfc1f  and eax, 0x7FF8
000075e5f6dcfc24  cmp eax, 0x08
000075e5f6dcfc27  jnz 0x000075E5F6DCF6F7
000075e5f6dcfc2d  movq rax, xmm15
000075e5f6dcfc32  shl rax, 0x0D
000075e5f6dcfc36  jbe 0x000075E5F6DCF6F7
000075e5f6dcfc3c  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcfc44  jmp 0x000075E5F6DCF6F7
000075e5f6dcfc49  call 0x000075E5F6C0B720
000075e5f6dcfc4e  jmp 0x000075E5F6DCF709
000075e5f6dcfc53  ucomisd xmm15, xmm14
000075e5f6dcfc58  jp 0x000075E5F6DCFC67
000075e5f6dcfc5a  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dcfc62  jmp 0x000075E5F6DCF73E
000075e5f6dcfc67  vxorps xmm0, xmm15, xmm14
000075e5f6dcfc6c  pextrw eax, xmm0, 0x03
000075e5f6dcfc71  and eax, 0x7FF8
000075e5f6dcfc76  cmp eax, 0x08
000075e5f6dcfc79  jnz 0x000075E5F6DCF73E
000075e5f6dcfc7f  movq rax, xmm14
000075e5f6dcfc84  shl rax, 0x0D
000075e5f6dcfc88  jbe 0x000075E5F6DCF73E
000075e5f6dcfc8e  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dcfc96  jmp 0x000075E5F6DCF73E
000075e5f6dcfc9b  ucomisd xmm1, xmm15
000075e5f6dcfca0  jp 0x000075E5F6DCFCAF
000075e5f6dcfca2  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcfcaa  jmp 0x000075E5F6DCF773
000075e5f6dcfcaf  vxorps xmm0, xmm1, xmm15
000075e5f6dcfcb4  pextrw eax, xmm0, 0x03
000075e5f6dcfcb9  and eax, 0x7FF8
000075e5f6dcfcbe  cmp eax, 0x08
000075e5f6dcfcc1  jnz 0x000075E5F6DCF773
000075e5f6dcfcc7  movq rax, xmm15
000075e5f6dcfccc  shl rax, 0x0D
000075e5f6dcfcd0  jbe 0x000075E5F6DCF773
000075e5f6dcfcd6  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcfcde  jmp 0x000075E5F6DCF773
000075e5f6dcfce3  ucomisd xmm1, xmm15
000075e5f6dcfce8  jp 0x000075E5F6DCFCF7
000075e5f6dcfcea  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dcfcf2  jmp 0x000075E5F6DCF7A8
000075e5f6dcfcf7  vxorps xmm0, xmm1, xmm15
000075e5f6dcfcfc  pextrw eax, xmm0, 0x03
000075e5f6dcfd01  and eax, 0x7FF8
000075e5f6dcfd06  cmp eax, 0x08
000075e5f6dcfd09  jnz 0x000075E5F6DCF7A8
000075e5f6dcfd0f  movq rax, xmm15
000075e5f6dcfd14  shl rax, 0x0D
000075e5f6dcfd18  jbe 0x000075E5F6DCF7A8
000075e5f6dcfd1e  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dcfd26  jmp 0x000075E5F6DCF7A8
000075e5f6dcfd2b  call 0x000075E5F6CB4CB0
000075e5f6dcfd30  jmp 0x000075E5F6DCF7C7
000075e5f6dcfd35  int3
000075e5f6dcfd36  nop [rax+rax*1], ax
000075e5f6dcfd3f  nop
000075e5f6dcfd40  mov rax, [r15+0x60]
000075e5f6dcfd44  lea r14, [rax+0x01]
000075e5f6dcfd48  mov [r15+0x60], r14
000075e5f6dcfd4c  mov rax, [r15+0x68]
000075e5f6dcfd50  lea r12, [rax+0x40]
000075e5f6dcfd54  mov [r15+0x68], r12
000075e5f6dcfd58  xor eax, eax
000075e5f6dcfd5a  mov r12d, 0x08
000075e5f6dcfd60  cmp r14, r12
000075e5f6dcfd63  cmc
000075e5f6dcfd64  lahf
000075e5f6dcfd65  seto al
000075e5f6dcfd68  mov [r15+0x108], eax
000075e5f6dcfd6f  mov eax, [r15+0x108]
000075e5f6dcfd76  sahf
000075e5f6dcfd77  jnz 0x000075E5F6DCFDA9
000075e5f6dcfd79  cmp dword ptr [r15+0x318], 0x00
000075e5f6dcfd81  jz 0x000075E5F6DD08A0
000075e5f6dcfd87  nop [rax+rax*1], ax
000075e5f6dcfd90  nop [rax+rax*1], eax
000075e5f6dcfd98  mov eax, 0x410128
000075e5f6dcfd9d  mov [r15+0x100], rax
000075e5f6dcfda4  jmp 0x000075E5F6BFE110
000075e5f6dcfda9  cmp dword ptr [r15+0x318], 0x00
000075e5f6dcfdb1  jz 0x000075E5F6DCFDE0
000075e5f6dcfdb7  nop [rax+rax*1], ax
000075e5f6dcfdc0  nop [rax+rax*1], eax
000075e5f6dcfdc8  mov eax, 0x41008C
000075e5f6dcfdcd  mov [r15+0x100], rax
000075e5f6dcfdd4  jmp 0x000075E5F6BFE110
000075e5f6dcfdd9  int3
000075e5f6dcfdda  int3
000075e5f6dcfddb  nop [rax+rax*1], eax
000075e5f6dcfde0  mov rax, [r15+0x40]
000075e5f6dcfde4  mov r14, [r15+0x60]
000075e5f6dcfde8  shl r14, 0x06
000075e5f6dcfdec  lea r12, [rax+r14*1]
000075e5f6dcfdf0  mov rax, [r13+r12*1]
000075e5f6dcfdf5  lea r14, [r12+0x08]
000075e5f6dcfdfa  mov r11, [r13+r14*1]
000075e5f6dcfdff  movq xmm1, rax
000075e5f6dcfe04  movq xmm15, r11
000075e5f6dcfe09  movq xmm1, xmm1
000075e5f6dcfe0d  movq xmm1, xmm1
000075e5f6dcfe11  movaps [r15+0x120], xmm1
000075e5f6dcfe19  movq xmm15, xmm15
000075e5f6dcfe1e  movq xmm15, xmm15
000075e5f6dcfe23  movaps [r15+0x130], xmm15
000075e5f6dcfe2b  lea rax, [r12+0x10]
000075e5f6dcfe30  mov r14, [r13+rax*1]
000075e5f6dcfe35  lea rax, [r12+0x18]
000075e5f6dcfe3a  mov r11, [r13+rax*1]
000075e5f6dcfe3f  movq xmm1, r14
000075e5f6dcfe44  movq xmm15, r11
000075e5f6dcfe49  movq xmm1, xmm1
000075e5f6dcfe4d  movq xmm1, xmm1
000075e5f6dcfe51  movaps [r15+0x140], xmm1
000075e5f6dcfe59  movq xmm15, xmm15
000075e5f6dcfe5e  movq xmm15, xmm15
000075e5f6dcfe63  movaps [r15+0x150], xmm15
000075e5f6dcfe6b  lea rax, [r12+0x20]
000075e5f6dcfe70  mov r14, [r13+rax*1]
000075e5f6dcfe75  lea rax, [r12+0x28]
000075e5f6dcfe7a  mov r11, [r13+rax*1]
000075e5f6dcfe7f  movq xmm1, r14
000075e5f6dcfe84  movq xmm15, r11
000075e5f6dcfe89  movq xmm1, xmm1
000075e5f6dcfe8d  movq xmm1, xmm1
000075e5f6dcfe91  movaps [r15+0x160], xmm1
000075e5f6dcfe99  movq xmm15, xmm15
000075e5f6dcfe9e  movq xmm15, xmm15
000075e5f6dcfea3  movaps [r15+0x170], xmm15
000075e5f6dcfeab  lea rax, [r12+0x30]
000075e5f6dcfeb0  mov r14, [r13+rax*1]
000075e5f6dcfeb5  lea rax, [r12+0x38]
000075e5f6dcfeba  mov r12, [r13+rax*1]
000075e5f6dcfebf  movq xmm1, r14
000075e5f6dcfec4  movq xmm15, r12
000075e5f6dcfec9  movq xmm1, xmm1
000075e5f6dcfecd  movq xmm1, xmm1
000075e5f6dcfed1  movaps [r15+0x180], xmm1
000075e5f6dcfed9  movq xmm15, xmm15
000075e5f6dcfede  movq xmm15, xmm15
000075e5f6dcfee3  movaps [r15+0x210], xmm15
000075e5f6dcfeeb  mov rax, [r15+0x48]
000075e5f6dcfeef  mov [r15+0x78], rax
000075e5f6dcfef3  mov r14, [r13+rax*1]
000075e5f6dcfef8  movq xmm1, r14
000075e5f6dcfefd  lea r14, [rax+0x40]
000075e5f6dcff01  mov r12, [r13+r14*1]
000075e5f6dcff06  movq xmm15, r12
000075e5f6dcff0b  lea r14, [rax+0x80]
000075e5f6dcff12  mov r12, [r13+r14*1]
000075e5f6dcff17  movq xmm14, r12
000075e5f6dcff1c  movaps xmm13, [r15+0x120]
000075e5f6dcff24  movq r14, xmm13
000075e5f6dcff29  movq r12, xmm1
000075e5f6dcff2e  vmovq xmm1, r14
000075e5f6dcff33  vmovq xmm13, r12
000075e5f6dcff38  movaps xmm12, xmm1
000075e5f6dcff3c  mulsd xmm12, xmm13
000075e5f6dcff41  ucomisd xmm12, xmm12
000075e5f6dcff46  jp 0x000075E5F6DD03AD
000075e5f6dcff4c  movq xmm12, xmm12
000075e5f6dcff51  movaps xmm1, [r15+0x130]
000075e5f6dcff59  movq r14, xmm1
000075e5f6dcff5e  movq r12, xmm15
000075e5f6dcff63  vmovq xmm1, r14
000075e5f6dcff68  vmovq xmm15, r12
000075e5f6dcff6d  movaps xmm13, xmm1
000075e5f6dcff71  mulsd xmm13, xmm15
000075e5f6dcff76  ucomisd xmm13, xmm13
000075e5f6dcff7b  jp 0x000075E5F6DD03F9
000075e5f6dcff81  movq xmm13, xmm13
000075e5f6dcff86  movq r14, xmm12
000075e5f6dcff8b  movaps xmm1, [r15+0x110]
000075e5f6dcff93  movq r12, xmm1
000075e5f6dcff98  vmovq xmm1, r14
000075e5f6dcff9d  vmovq xmm15, r12
000075e5f6dcffa2  movaps xmm12, xmm1
000075e5f6dcffa6  addsd xmm12, xmm15
000075e5f6dcffab  ucomisd xmm12, xmm12
000075e5f6dcffb0  jp 0x000075E5F6DD0445
000075e5f6dcffb6  movq xmm12, xmm12
000075e5f6dcffbb  movq r14, xmm12
000075e5f6dcffc0  movq r12, xmm13
000075e5f6dcffc5  vmovq xmm1, r14
000075e5f6dcffca  vmovq xmm15, r12
000075e5f6dcffcf  movaps xmm13, xmm1
000075e5f6dcffd3  addsd xmm13, xmm15
000075e5f6dcffd8  ucomisd xmm13, xmm13
000075e5f6dcffdd  jp 0x000075E5F6DD0491
000075e5f6dcffe3  movq xmm13, xmm13
000075e5f6dcffe8  movaps xmm1, [r15+0x140]
000075e5f6dcfff0  movq r14, xmm1
000075e5f6dcfff5  movq r12, xmm14
000075e5f6dcfffa  vmovq xmm1, r14
000075e5f6dcffff  vmovq xmm15, r12
000075e5f6dd0004  movaps xmm14, xmm1
000075e5f6dd0008  mulsd xmm14, xmm15
000075e5f6dd000d  ucomisd xmm14, xmm14
000075e5f6dd0012  jp 0x000075E5F6DD04DD
000075e5f6dd0018  movq xmm14, xmm14
000075e5f6dd001d  lea r14, [rax+0xC0]
000075e5f6dd0024  mov r12, [r13+r14*1]
000075e5f6dd0029  movq xmm1, r12
000075e5f6dd002e  movq r14, xmm13
000075e5f6dd0033  movq r12, xmm14
000075e5f6dd0038  vmovq xmm15, r14
000075e5f6dd003d  vmovq xmm14, r12
000075e5f6dd0042  movaps xmm13, xmm15
000075e5f6dd0046  addsd xmm13, xmm14
000075e5f6dd004b  ucomisd xmm13, xmm13
000075e5f6dd0050  jp 0x000075E5F6DD0533
000075e5f6dd0056  movq xmm13, xmm13
000075e5f6dd005b  movaps xmm15, [r15+0x150]
000075e5f6dd0063  movq r14, xmm15
000075e5f6dd0068  movq r12, xmm1
000075e5f6dd006d  vmovq xmm1, r14
000075e5f6dd0072  vmovq xmm15, r12
000075e5f6dd0077  movaps xmm14, xmm1
000075e5f6dd007b  mulsd xmm14, xmm15
000075e5f6dd0080  ucomisd xmm14, xmm14
000075e5f6dd0085  jp 0x000075E5F6DD057F
000075e5f6dd008b  movq xmm14, xmm14
000075e5f6dd0090  lea r14, [rax+0x100]
000075e5f6dd0097  mov r12, [r13+r14*1]
000075e5f6dd009c  movq xmm1, r12
000075e5f6dd00a1  movq r14, xmm13
000075e5f6dd00a6  movq r12, xmm14
000075e5f6dd00ab  vmovq xmm15, r14
000075e5f6dd00b0  vmovq xmm14, r12
000075e5f6dd00b5  movaps xmm13, xmm15
000075e5f6dd00b9  addsd xmm13, xmm14
000075e5f6dd00be  ucomisd xmm13, xmm13
000075e5f6dd00c3  jp 0x000075E5F6DD05D5
000075e5f6dd00c9  movq xmm13, xmm13
000075e5f6dd00ce  movaps xmm15, [r15+0x160]
000075e5f6dd00d6  movq r14, xmm15
000075e5f6dd00db  movq r12, xmm1
000075e5f6dd00e0  vmovq xmm1, r14
000075e5f6dd00e5  vmovq xmm15, r12
000075e5f6dd00ea  movaps xmm14, xmm1
000075e5f6dd00ee  mulsd xmm14, xmm15
000075e5f6dd00f3  ucomisd xmm14, xmm14
000075e5f6dd00f8  jp 0x000075E5F6DD0621
000075e5f6dd00fe  movq xmm14, xmm14
000075e5f6dd0103  lea r14, [rax+0x140]
000075e5f6dd010a  mov r12, [r13+r14*1]
000075e5f6dd010f  movq xmm1, r12
000075e5f6dd0114  movq r14, xmm13
000075e5f6dd0119  movq r12, xmm14
000075e5f6dd011e  vmovq xmm15, r14
000075e5f6dd0123  vmovq xmm14, r12
000075e5f6dd0128  movaps xmm13, xmm15
000075e5f6dd012c  addsd xmm13, xmm14
000075e5f6dd0131  ucomisd xmm13, xmm13
000075e5f6dd0136  jp 0x000075E5F6DD0677
000075e5f6dd013c  movq xmm13, xmm13
000075e5f6dd0141  movaps xmm15, [r15+0x170]
000075e5f6dd0149  movq r14, xmm15
000075e5f6dd014e  movq r12, xmm1
000075e5f6dd0153  vmovq xmm1, r14
000075e5f6dd0158  vmovq xmm15, r12
000075e5f6dd015d  movaps xmm14, xmm1
000075e5f6dd0161  mulsd xmm14, xmm15
000075e5f6dd0166  ucomisd xmm14, xmm14
000075e5f6dd016b  jp 0x000075E5F6DD06C3
000075e5f6dd0171  movq xmm14, xmm14
000075e5f6dd0176  lea r14, [rax+0x180]
000075e5f6dd017d  mov r12, [r13+r14*1]
000075e5f6dd0182  movq xmm1, r12
000075e5f6dd0187  movq r14, xmm13
000075e5f6dd018c  movq r12, xmm14
000075e5f6dd0191  vmovq xmm15, r14
000075e5f6dd0196  vmovq xmm14, r12
000075e5f6dd019b  movaps xmm13, xmm15
000075e5f6dd019f  addsd xmm13, xmm14
000075e5f6dd01a4  ucomisd xmm13, xmm13
000075e5f6dd01a9  jp 0x000075E5F6DD0719
000075e5f6dd01af  movq xmm13, xmm13
000075e5f6dd01b4  movaps xmm15, [r15+0x180]
000075e5f6dd01bc  movq r14, xmm15
000075e5f6dd01c1  movq r12, xmm1
000075e5f6dd01c6  vmovq xmm1, r14
000075e5f6dd01cb  vmovq xmm15, r12
000075e5f6dd01d0  movaps xmm14, xmm1
000075e5f6dd01d4  mulsd xmm14, xmm15
000075e5f6dd01d9  ucomisd xmm14, xmm14
000075e5f6dd01de  jp 0x000075E5F6DD0765
000075e5f6dd01e4  movq xmm14, xmm14
000075e5f6dd01e9  lea r14, [rax+0x1C0]
000075e5f6dd01f0  mov rax, [r13+r14*1]
000075e5f6dd01f5  movq xmm1, rax
000075e5f6dd01fa  movaps [r15+0x240], xmm1
000075e5f6dd0202  movq rax, xmm13
000075e5f6dd0207  movq r14, xmm14
000075e5f6dd020c  vmovq xmm15, rax
000075e5f6dd0211  vmovq xmm14, r14
000075e5f6dd0216  movaps xmm13, xmm15
000075e5f6dd021a  addsd xmm13, xmm14
000075e5f6dd021f  ucomisd xmm13, xmm13
000075e5f6dd0224  jp 0x000075E5F6DD07BB
000075e5f6dd022a  movq xmm13, xmm13
000075e5f6dd022f  movaps xmm15, [r15+0x210]
000075e5f6dd0237  movq rax, xmm15
000075e5f6dd023c  movq r14, xmm1
000075e5f6dd0241  vmovq xmm1, rax
000075e5f6dd0246  vmovq xmm15, r14
000075e5f6dd024b  movaps xmm14, xmm1
000075e5f6dd024f  mulsd xmm14, xmm15
000075e5f6dd0254  ucomisd xmm14, xmm14
000075e5f6dd0259  jp 0x000075E5F6DD0803
000075e5f6dd025f  movq xmm14, xmm14
000075e5f6dd0264  movaps [r15+0x230], xmm14
000075e5f6dd026c  movq rax, xmm13
000075e5f6dd0271  movq r14, xmm14
000075e5f6dd0276  vmovq xmm1, rax
000075e5f6dd027b  vmovq xmm15, r14
000075e5f6dd0280  movaps xmm14, xmm1
000075e5f6dd0284  addsd xmm14, xmm15
000075e5f6dd0289  ucomisd xmm14, xmm14
000075e5f6dd028e  jp 0x000075E5F6DD084B
000075e5f6dd0294  movq xmm14, xmm14
000075e5f6dd0299  movaps [r15+0x220], xmm14
000075e5f6dd02a1  mov rax, [r15+0x68]
000075e5f6dd02a5  movq r14, xmm14
000075e5f6dd02aa  mov [r13+rax*1], r14
000075e5f6dd02af  mov qword ptr [r15+0x70], 0x08
000075e5f6dd02b7  xor eax, eax
000075e5f6dd02b9  mov r14d, 0x08
000075e5f6dd02bf  mov r12d, 0x40
000075e5f6dd02c5  cmp r14, r12
000075e5f6dd02c8  cmc
000075e5f6dd02c9  lahf
000075e5f6dd02ca  seto al
000075e5f6dd02cd  mov [r15+0x108], eax
000075e5f6dd02d4  mov eax, [r15+0x108]
000075e5f6dd02db  sahf
000075e5f6dd02dc  jnz 0x000075E5F6DD030E
000075e5f6dd02de  cmp dword ptr [r15+0x318], 0x00
000075e5f6dd02e6  jz 0x000075E5F6DCFD40
000075e5f6dd02ec  nop [rax+rax*1], ax
000075e5f6dd02f5  nop [rax+rax*1], eax
000075e5f6dd02fd  mov eax, 0x410118
000075e5f6dd0302  mov [r15+0x100], rax
000075e5f6dd0309  jmp 0x000075E5F6BFE110
000075e5f6dd030e  cmp dword ptr [r15+0x318], 0x00
000075e5f6dd0316  jz 0x000075E5F6DCF3F0
000075e5f6dd031c  nop [rax+rax*1], ax
000075e5f6dd0325  nop [rax+rax*1], eax
000075e5f6dd032d  mov eax, 0x4100A4
000075e5f6dd0332  mov [r15+0x100], rax
000075e5f6dd0339  jmp 0x000075E5F6BFE110
000075e5f6dd033e  int3
000075e5f6dd033f  call 0x000075E5F6CB47C0
000075e5f6dd0344  jmp 0x000075E5F6DCFDF5
000075e5f6dd0349  call 0x000075E5F6CE1570
000075e5f6dd034e  jmp 0x000075E5F6DCFDFF
000075e5f6dd0353  call 0x000075E5F6C0DC20
000075e5f6dd0358  jmp 0x000075E5F6DCFE35
000075e5f6dd035d  call 0x000075E5F6C0A4B0
000075e5f6dd0362  jmp 0x000075E5F6DCFE3F
000075e5f6dd0367  call 0x000075E5F6C0DC20
000075e5f6dd036c  jmp 0x000075E5F6DCFE75
000075e5f6dd0371  call 0x000075E5F6C0A4B0
000075e5f6dd0376  jmp 0x000075E5F6DCFE7F
000075e5f6dd037b  call 0x000075E5F6C0DC20
000075e5f6dd0380  jmp 0x000075E5F6DCFEB5
000075e5f6dd0385  call 0x000075E5F6C0B720
000075e5f6dd038a  jmp 0x000075E5F6DCFEBF
000075e5f6dd038f  call 0x000075E5F6C0DC20
000075e5f6dd0394  jmp 0x000075E5F6DCFEF8
000075e5f6dd0399  call 0x000075E5F6CE27E0
000075e5f6dd039e  jmp 0x000075E5F6DCFF06
000075e5f6dd03a3  call 0x000075E5F6CE27E0
000075e5f6dd03a8  jmp 0x000075E5F6DCFF17
000075e5f6dd03ad  ucomisd xmm1, xmm13
000075e5f6dd03b2  jp 0x000075E5F6DD03C1
000075e5f6dd03b4  movaps xmm12, [0x000075E5F69FE030]
000075e5f6dd03bc  jmp 0x000075E5F6DCFF4C
000075e5f6dd03c1  vxorps xmm0, xmm1, xmm13
000075e5f6dd03c6  pextrw r14d, xmm0, 0x03
000075e5f6dd03cc  and r14d, 0x7FF8
000075e5f6dd03d3  cmp r14d, 0x08
000075e5f6dd03d7  jnz 0x000075E5F6DCFF4C
000075e5f6dd03dd  movq r14, xmm13
000075e5f6dd03e2  shl r14, 0x0D
000075e5f6dd03e6  jbe 0x000075E5F6DCFF4C
000075e5f6dd03ec  vorps xmm12, xmm13, [0x000075E5F69FE040]
000075e5f6dd03f4  jmp 0x000075E5F6DCFF4C
000075e5f6dd03f9  ucomisd xmm1, xmm15
000075e5f6dd03fe  jp 0x000075E5F6DD040D
000075e5f6dd0400  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd0408  jmp 0x000075E5F6DCFF81
000075e5f6dd040d  vxorps xmm0, xmm1, xmm15
000075e5f6dd0412  pextrw r14d, xmm0, 0x03
000075e5f6dd0418  and r14d, 0x7FF8
000075e5f6dd041f  cmp r14d, 0x08
000075e5f6dd0423  jnz 0x000075E5F6DCFF81
000075e5f6dd0429  movq r14, xmm15
000075e5f6dd042e  shl r14, 0x0D
000075e5f6dd0432  jbe 0x000075E5F6DCFF81
000075e5f6dd0438  vorps xmm13, xmm15, [0x000075E5F69FE040]
000075e5f6dd0440  jmp 0x000075E5F6DCFF81
000075e5f6dd0445  ucomisd xmm1, xmm15
000075e5f6dd044a  jp 0x000075E5F6DD0459
000075e5f6dd044c  movaps xmm12, [0x000075E5F69FE030]
000075e5f6dd0454  jmp 0x000075E5F6DCFFB6
000075e5f6dd0459  vxorps xmm0, xmm1, xmm15
000075e5f6dd045e  pextrw r14d, xmm0, 0x03
000075e5f6dd0464  and r14d, 0x7FF8
000075e5f6dd046b  cmp r14d, 0x08
000075e5f6dd046f  jnz 0x000075E5F6DCFFB6
000075e5f6dd0475  movq r14, xmm15
000075e5f6dd047a  shl r14, 0x0D
000075e5f6dd047e  jbe 0x000075E5F6DCFFB6
000075e5f6dd0484  vorps xmm12, xmm15, [0x000075E5F69FE040]
000075e5f6dd048c  jmp 0x000075E5F6DCFFB6
000075e5f6dd0491  ucomisd xmm1, xmm15
000075e5f6dd0496  jp 0x000075E5F6DD04A5
000075e5f6dd0498  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd04a0  jmp 0x000075E5F6DCFFE3
000075e5f6dd04a5  vxorps xmm0, xmm1, xmm15
000075e5f6dd04aa  pextrw r14d, xmm0, 0x03
000075e5f6dd04b0  and r14d, 0x7FF8
000075e5f6dd04b7  cmp r14d, 0x08
000075e5f6dd04bb  jnz 0x000075E5F6DCFFE3
000075e5f6dd04c1  movq r14, xmm15
000075e5f6dd04c6  shl r14, 0x0D
000075e5f6dd04ca  jbe 0x000075E5F6DCFFE3
000075e5f6dd04d0  vorps xmm13, xmm15, [0x000075E5F69FE040]
000075e5f6dd04d8  jmp 0x000075E5F6DCFFE3
000075e5f6dd04dd  ucomisd xmm1, xmm15
000075e5f6dd04e2  jp 0x000075E5F6DD04F1
000075e5f6dd04e4  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd04ec  jmp 0x000075E5F6DD0018
000075e5f6dd04f1  vxorps xmm0, xmm1, xmm15
000075e5f6dd04f6  pextrw r14d, xmm0, 0x03
000075e5f6dd04fc  and r14d, 0x7FF8
000075e5f6dd0503  cmp r14d, 0x08
000075e5f6dd0507  jnz 0x000075E5F6DD0018
000075e5f6dd050d  movq r14, xmm15
000075e5f6dd0512  shl r14, 0x0D
000075e5f6dd0516  jbe 0x000075E5F6DD0018
000075e5f6dd051c  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd0524  jmp 0x000075E5F6DD0018
000075e5f6dd0529  call 0x000075E5F6CE27E0
000075e5f6dd052e  jmp 0x000075E5F6DD0029
000075e5f6dd0533  ucomisd xmm15, xmm14
000075e5f6dd0538  jp 0x000075E5F6DD0547
000075e5f6dd053a  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd0542  jmp 0x000075E5F6DD0056
000075e5f6dd0547  vxorps xmm0, xmm15, xmm14
000075e5f6dd054c  pextrw r14d, xmm0, 0x03
000075e5f6dd0552  and r14d, 0x7FF8
000075e5f6dd0559  cmp r14d, 0x08
000075e5f6dd055d  jnz 0x000075E5F6DD0056
000075e5f6dd0563  movq r14, xmm14
000075e5f6dd0568  shl r14, 0x0D
000075e5f6dd056c  jbe 0x000075E5F6DD0056
000075e5f6dd0572  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dd057a  jmp 0x000075E5F6DD0056
000075e5f6dd057f  ucomisd xmm1, xmm15
000075e5f6dd0584  jp 0x000075E5F6DD0593
000075e5f6dd0586  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd058e  jmp 0x000075E5F6DD008B
000075e5f6dd0593  vxorps xmm0, xmm1, xmm15
000075e5f6dd0598  pextrw r14d, xmm0, 0x03
000075e5f6dd059e  and r14d, 0x7FF8
000075e5f6dd05a5  cmp r14d, 0x08
000075e5f6dd05a9  jnz 0x000075E5F6DD008B
000075e5f6dd05af  movq r14, xmm15
000075e5f6dd05b4  shl r14, 0x0D
000075e5f6dd05b8  jbe 0x000075E5F6DD008B
000075e5f6dd05be  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd05c6  jmp 0x000075E5F6DD008B
000075e5f6dd05cb  call 0x000075E5F6CE27E0
000075e5f6dd05d0  jmp 0x000075E5F6DD009C
000075e5f6dd05d5  ucomisd xmm15, xmm14
000075e5f6dd05da  jp 0x000075E5F6DD05E9
000075e5f6dd05dc  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd05e4  jmp 0x000075E5F6DD00C9
000075e5f6dd05e9  vxorps xmm0, xmm15, xmm14
000075e5f6dd05ee  pextrw r14d, xmm0, 0x03
000075e5f6dd05f4  and r14d, 0x7FF8
000075e5f6dd05fb  cmp r14d, 0x08
000075e5f6dd05ff  jnz 0x000075E5F6DD00C9
000075e5f6dd0605  movq r14, xmm14
000075e5f6dd060a  shl r14, 0x0D
000075e5f6dd060e  jbe 0x000075E5F6DD00C9
000075e5f6dd0614  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dd061c  jmp 0x000075E5F6DD00C9
000075e5f6dd0621  ucomisd xmm1, xmm15
000075e5f6dd0626  jp 0x000075E5F6DD0635
000075e5f6dd0628  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd0630  jmp 0x000075E5F6DD00FE
000075e5f6dd0635  vxorps xmm0, xmm1, xmm15
000075e5f6dd063a  pextrw r14d, xmm0, 0x03
000075e5f6dd0640  and r14d, 0x7FF8
000075e5f6dd0647  cmp r14d, 0x08
000075e5f6dd064b  jnz 0x000075E5F6DD00FE
000075e5f6dd0651  movq r14, xmm15
000075e5f6dd0656  shl r14, 0x0D
000075e5f6dd065a  jbe 0x000075E5F6DD00FE
000075e5f6dd0660  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd0668  jmp 0x000075E5F6DD00FE
000075e5f6dd066d  call 0x000075E5F6CE27E0
000075e5f6dd0672  jmp 0x000075E5F6DD010F
000075e5f6dd0677  ucomisd xmm15, xmm14
000075e5f6dd067c  jp 0x000075E5F6DD068B
000075e5f6dd067e  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd0686  jmp 0x000075E5F6DD013C
000075e5f6dd068b  vxorps xmm0, xmm15, xmm14
000075e5f6dd0690  pextrw r14d, xmm0, 0x03
000075e5f6dd0696  and r14d, 0x7FF8
000075e5f6dd069d  cmp r14d, 0x08
000075e5f6dd06a1  jnz 0x000075E5F6DD013C
000075e5f6dd06a7  movq r14, xmm14
000075e5f6dd06ac  shl r14, 0x0D
000075e5f6dd06b0  jbe 0x000075E5F6DD013C
000075e5f6dd06b6  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dd06be  jmp 0x000075E5F6DD013C
000075e5f6dd06c3  ucomisd xmm1, xmm15
000075e5f6dd06c8  jp 0x000075E5F6DD06D7
000075e5f6dd06ca  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd06d2  jmp 0x000075E5F6DD0171
000075e5f6dd06d7  vxorps xmm0, xmm1, xmm15
000075e5f6dd06dc  pextrw r14d, xmm0, 0x03
000075e5f6dd06e2  and r14d, 0x7FF8
000075e5f6dd06e9  cmp r14d, 0x08
000075e5f6dd06ed  jnz 0x000075E5F6DD0171
000075e5f6dd06f3  movq r14, xmm15
000075e5f6dd06f8  shl r14, 0x0D
000075e5f6dd06fc  jbe 0x000075E5F6DD0171
000075e5f6dd0702  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd070a  jmp 0x000075E5F6DD0171
000075e5f6dd070f  call 0x000075E5F6CE27E0
000075e5f6dd0714  jmp 0x000075E5F6DD0182
000075e5f6dd0719  ucomisd xmm15, xmm14
000075e5f6dd071e  jp 0x000075E5F6DD072D
000075e5f6dd0720  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd0728  jmp 0x000075E5F6DD01AF
000075e5f6dd072d  vxorps xmm0, xmm15, xmm14
000075e5f6dd0732  pextrw r14d, xmm0, 0x03
000075e5f6dd0738  and r14d, 0x7FF8
000075e5f6dd073f  cmp r14d, 0x08
000075e5f6dd0743  jnz 0x000075E5F6DD01AF
000075e5f6dd0749  movq r14, xmm14
000075e5f6dd074e  shl r14, 0x0D
000075e5f6dd0752  jbe 0x000075E5F6DD01AF
000075e5f6dd0758  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dd0760  jmp 0x000075E5F6DD01AF
000075e5f6dd0765  ucomisd xmm1, xmm15
000075e5f6dd076a  jp 0x000075E5F6DD0779
000075e5f6dd076c  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd0774  jmp 0x000075E5F6DD01E4
000075e5f6dd0779  vxorps xmm0, xmm1, xmm15
000075e5f6dd077e  pextrw r14d, xmm0, 0x03
000075e5f6dd0784  and r14d, 0x7FF8
000075e5f6dd078b  cmp r14d, 0x08
000075e5f6dd078f  jnz 0x000075E5F6DD01E4
000075e5f6dd0795  movq r14, xmm15
000075e5f6dd079a  shl r14, 0x0D
000075e5f6dd079e  jbe 0x000075E5F6DD01E4
000075e5f6dd07a4  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd07ac  jmp 0x000075E5F6DD01E4
000075e5f6dd07b1  call 0x000075E5F6CD59C0
000075e5f6dd07b6  jmp 0x000075E5F6DD01F5
000075e5f6dd07bb  ucomisd xmm15, xmm14
000075e5f6dd07c0  jp 0x000075E5F6DD07CF
000075e5f6dd07c2  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd07ca  jmp 0x000075E5F6DD022A
000075e5f6dd07cf  vxorps xmm0, xmm15, xmm14
000075e5f6dd07d4  pextrw eax, xmm0, 0x03
000075e5f6dd07d9  and eax, 0x7FF8
000075e5f6dd07de  cmp eax, 0x08
000075e5f6dd07e1  jnz 0x000075E5F6DD022A
000075e5f6dd07e7  movq rax, xmm14
000075e5f6dd07ec  shl rax, 0x0D
000075e5f6dd07f0  jbe 0x000075E5F6DD022A
000075e5f6dd07f6  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dd07fe  jmp 0x000075E5F6DD022A
000075e5f6dd0803  ucomisd xmm1, xmm15
000075e5f6dd0808  jp 0x000075E5F6DD0817
000075e5f6dd080a  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd0812  jmp 0x000075E5F6DD025F
000075e5f6dd0817  vxorps xmm0, xmm1, xmm15
000075e5f6dd081c  pextrw eax, xmm0, 0x03
000075e5f6dd0821  and eax, 0x7FF8
000075e5f6dd0826  cmp eax, 0x08
000075e5f6dd0829  jnz 0x000075E5F6DD025F
000075e5f6dd082f  movq rax, xmm15
000075e5f6dd0834  shl rax, 0x0D
000075e5f6dd0838  jbe 0x000075E5F6DD025F
000075e5f6dd083e  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd0846  jmp 0x000075E5F6DD025F
000075e5f6dd084b  ucomisd xmm1, xmm15
000075e5f6dd0850  jp 0x000075E5F6DD085F
000075e5f6dd0852  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd085a  jmp 0x000075E5F6DD0294
000075e5f6dd085f  vxorps xmm0, xmm1, xmm15
000075e5f6dd0864  pextrw eax, xmm0, 0x03
000075e5f6dd0869  and eax, 0x7FF8
000075e5f6dd086e  cmp eax, 0x08
000075e5f6dd0871  jnz 0x000075E5F6DD0294
000075e5f6dd0877  movq rax, xmm15
000075e5f6dd087c  shl rax, 0x0D
000075e5f6dd0880  jbe 0x000075E5F6DD0294
000075e5f6dd0886  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd088e  jmp 0x000075E5F6DD0294
000075e5f6dd0893  call 0x000075E5F6C0E120
000075e5f6dd0898  jmp 0x000075E5F6DD02AF
000075e5f6dd089d  int3
000075e5f6dd089e  nop
000075e5f6dd08a0  mov eax, [r15+0x58]
000075e5f6dd08a4  lea r14d, [eax+0x01]
000075e5f6dd08a9  mov [rsp+0x10], r14d
000075e5f6dd08ae  mov r14d, r14d
000075e5f6dd08b1  mov [r15+0x58], r14
000075e5f6dd08b5  xor eax, eax
000075e5f6dd08b7  mov r14d, [rsp+0x10]
000075e5f6dd08bc  cmp r14d, 0x1F4
000075e5f6dd08c3  cmc
000075e5f6dd08c4  lahf
000075e5f6dd08c5  seto al
000075e5f6dd08c8  mov [r15+0x108], eax
000075e5f6dd08cf  mov eax, [r15+0x108]
000075e5f6dd08d6  sahf
000075e5f6dd08d7  jnz 0x000075E5F6DD0909
000075e5f6dd08d9  cmp dword ptr [r15+0x318], 0x00
000075e5f6dd08e1  jz 0x000075E5F6DD1410
000075e5f6dd08e7  nop [rax+rax*1], ax
000075e5f6dd08f0  nop [rax+rax*1], eax
000075e5f6dd08f8  mov eax, 0x410134
000075e5f6dd08fd  mov [r15+0x100], rax
000075e5f6dd0904  jmp 0x000075E5F6BFE110
000075e5f6dd0909  cmp dword ptr [r15+0x318], 0x00
000075e5f6dd0911  jz 0x000075E5F6DD0940
000075e5f6dd0917  nop [rax+rax*1], ax
000075e5f6dd0920  nop [rax+rax*1], eax
000075e5f6dd0928  mov eax, 0x410084
000075e5f6dd092d  mov [r15+0x100], rax
000075e5f6dd0934  jmp 0x000075E5F6BFE110
000075e5f6dd0939  int3
000075e5f6dd093a  int3
000075e5f6dd093b  nop [rax+rax*1], eax
000075e5f6dd0940  mov qword ptr [r15+0x60], 0x00
000075e5f6dd0948  mov rax, [r15+0x50]
000075e5f6dd094c  mov [r15+0x68], rax
000075e5f6dd0950  mov r14, [r15+0x40]
000075e5f6dd0954  mov r12, [r13+r14*1]
000075e5f6dd0959  lea r11, [r14+0x08]
000075e5f6dd095d  mov r10, [r13+r11*1]
000075e5f6dd0962  movq xmm1, r12
000075e5f6dd0967  movq xmm15, r10
000075e5f6dd096c  movq xmm1, xmm1
000075e5f6dd0970  movq xmm1, xmm1
000075e5f6dd0974  movaps [r15+0x120], xmm1
000075e5f6dd097c  movq xmm15, xmm15
000075e5f6dd0981  movq xmm15, xmm15
000075e5f6dd0986  movaps [r15+0x130], xmm15
000075e5f6dd098e  lea r12, [r14+0x10]
000075e5f6dd0992  mov r11, [r13+r12*1]
000075e5f6dd0997  lea r12, [r14+0x18]
000075e5f6dd099b  mov r10, [r13+r12*1]
000075e5f6dd09a0  movq xmm1, r11
000075e5f6dd09a5  movq xmm15, r10
000075e5f6dd09aa  movq xmm1, xmm1
000075e5f6dd09ae  movq xmm1, xmm1
000075e5f6dd09b2  movaps [r15+0x140], xmm1
000075e5f6dd09ba  movq xmm15, xmm15
000075e5f6dd09bf  movq xmm15, xmm15
000075e5f6dd09c4  movaps [r15+0x150], xmm15
000075e5f6dd09cc  lea r12, [r14+0x20]
000075e5f6dd09d0  mov r11, [r13+r12*1]
000075e5f6dd09d5  lea r12, [r14+0x28]
000075e5f6dd09d9  mov r10, [r13+r12*1]
000075e5f6dd09de  movq xmm1, r11
000075e5f6dd09e3  movq xmm15, r10
000075e5f6dd09e8  movq xmm1, xmm1
000075e5f6dd09ec  movq xmm1, xmm1
000075e5f6dd09f0  movaps [r15+0x160], xmm1
000075e5f6dd09f8  movq xmm15, xmm15
000075e5f6dd09fd  movq xmm15, xmm15
000075e5f6dd0a02  movaps [r15+0x170], xmm15
000075e5f6dd0a0a  lea r12, [r14+0x30]
000075e5f6dd0a0e  mov r11, [r13+r12*1]
000075e5f6dd0a13  lea r12, [r14+0x38]
000075e5f6dd0a17  mov r14, [r13+r12*1]
000075e5f6dd0a1c  movq xmm1, r11
000075e5f6dd0a21  movq xmm15, r14
000075e5f6dd0a26  movq xmm1, xmm1
000075e5f6dd0a2a  movq xmm1, xmm1
000075e5f6dd0a2e  movaps [r15+0x180], xmm1
000075e5f6dd0a36  movq xmm15, xmm15
000075e5f6dd0a3b  movq xmm15, xmm15
000075e5f6dd0a40  movaps [r15+0x210], xmm15
000075e5f6dd0a48  mov r14, [r15+0x48]
000075e5f6dd0a4c  mov [r15+0x78], r14
000075e5f6dd0a50  mov r12, [r13+r14*1]
000075e5f6dd0a55  movq xmm1, r12
000075e5f6dd0a5a  lea r12, [r14+0x40]
000075e5f6dd0a5e  mov r11, [r13+r12*1]
000075e5f6dd0a63  movq xmm15, r11
000075e5f6dd0a68  lea r12, [r14+0x80]
000075e5f6dd0a6f  mov r11, [r13+r12*1]
000075e5f6dd0a74  movq xmm14, r11
000075e5f6dd0a79  movaps xmm13, [r15+0x120]
000075e5f6dd0a81  movq r12, xmm13
000075e5f6dd0a86  movq r11, xmm1
000075e5f6dd0a8b  vmovq xmm1, r12
000075e5f6dd0a90  vmovq xmm13, r11
000075e5f6dd0a95  movaps xmm12, xmm1
000075e5f6dd0a99  mulsd xmm12, xmm13
000075e5f6dd0a9e  ucomisd xmm12, xmm12
000075e5f6dd0aa3  jp 0x000075E5F6DD0F06
000075e5f6dd0aa9  movq xmm12, xmm12
000075e5f6dd0aae  movaps xmm1, [r15+0x130]
000075e5f6dd0ab6  movq r12, xmm1
000075e5f6dd0abb  movq r11, xmm15
000075e5f6dd0ac0  vmovq xmm1, r12
000075e5f6dd0ac5  vmovq xmm15, r11
000075e5f6dd0aca  movaps xmm13, xmm1
000075e5f6dd0ace  mulsd xmm13, xmm15
000075e5f6dd0ad3  ucomisd xmm13, xmm13
000075e5f6dd0ad8  jp 0x000075E5F6DD0F52
000075e5f6dd0ade  movq xmm13, xmm13
000075e5f6dd0ae3  movq r12, xmm12
000075e5f6dd0ae8  movaps xmm1, [r15+0x110]
000075e5f6dd0af0  movq r11, xmm1
000075e5f6dd0af5  vmovq xmm1, r12
000075e5f6dd0afa  vmovq xmm15, r11
000075e5f6dd0aff  movaps xmm12, xmm1
000075e5f6dd0b03  addsd xmm12, xmm15
000075e5f6dd0b08  ucomisd xmm12, xmm12
000075e5f6dd0b0d  jp 0x000075E5F6DD0F9E
000075e5f6dd0b13  movq xmm12, xmm12
000075e5f6dd0b18  movq r12, xmm12
000075e5f6dd0b1d  movq r11, xmm13
000075e5f6dd0b22  vmovq xmm1, r12
000075e5f6dd0b27  vmovq xmm15, r11
000075e5f6dd0b2c  movaps xmm13, xmm1
000075e5f6dd0b30  addsd xmm13, xmm15
000075e5f6dd0b35  ucomisd xmm13, xmm13
000075e5f6dd0b3a  jp 0x000075E5F6DD0FEA
000075e5f6dd0b40  movq xmm13, xmm13
000075e5f6dd0b45  movaps xmm1, [r15+0x140]
000075e5f6dd0b4d  movq r12, xmm1
000075e5f6dd0b52  movq r11, xmm14
000075e5f6dd0b57  vmovq xmm1, r12
000075e5f6dd0b5c  vmovq xmm15, r11
000075e5f6dd0b61  movaps xmm14, xmm1
000075e5f6dd0b65  mulsd xmm14, xmm15
000075e5f6dd0b6a  ucomisd xmm14, xmm14
000075e5f6dd0b6f  jp 0x000075E5F6DD1036
000075e5f6dd0b75  movq xmm14, xmm14
000075e5f6dd0b7a  lea r12, [r14+0xC0]
000075e5f6dd0b81  mov r11, [r13+r12*1]
000075e5f6dd0b86  movq xmm1, r11
000075e5f6dd0b8b  movq r12, xmm13
000075e5f6dd0b90  movq r11, xmm14
000075e5f6dd0b95  vmovq xmm15, r12
000075e5f6dd0b9a  vmovq xmm14, r11
000075e5f6dd0b9f  movaps xmm13, xmm15
000075e5f6dd0ba3  addsd xmm13, xmm14
000075e5f6dd0ba8  ucomisd xmm13, xmm13
000075e5f6dd0bad  jp 0x000075E5F6DD108C
000075e5f6dd0bb3  movq xmm13, xmm13
000075e5f6dd0bb8  movaps xmm15, [r15+0x150]
000075e5f6dd0bc0  movq r12, xmm15
000075e5f6dd0bc5  movq r11, xmm1
000075e5f6dd0bca  vmovq xmm1, r12
000075e5f6dd0bcf  vmovq xmm15, r11
000075e5f6dd0bd4  movaps xmm14, xmm1
000075e5f6dd0bd8  mulsd xmm14, xmm15
000075e5f6dd0bdd  ucomisd xmm14, xmm14
000075e5f6dd0be2  jp 0x000075E5F6DD10D8
000075e5f6dd0be8  movq xmm14, xmm14
000075e5f6dd0bed  lea r12, [r14+0x100]
000075e5f6dd0bf4  mov r11, [r13+r12*1]
000075e5f6dd0bf9  movq xmm1, r11
000075e5f6dd0bfe  movq r12, xmm13
000075e5f6dd0c03  movq r11, xmm14
000075e5f6dd0c08  vmovq xmm15, r12
000075e5f6dd0c0d  vmovq xmm14, r11
000075e5f6dd0c12  movaps xmm13, xmm15
000075e5f6dd0c16  addsd xmm13, xmm14
000075e5f6dd0c1b  ucomisd xmm13, xmm13
000075e5f6dd0c20  jp 0x000075E5F6DD112E
000075e5f6dd0c26  movq xmm13, xmm13
000075e5f6dd0c2b  movaps xmm15, [r15+0x160]
000075e5f6dd0c33  movq r12, xmm15
000075e5f6dd0c38  movq r11, xmm1
000075e5f6dd0c3d  vmovq xmm1, r12
000075e5f6dd0c42  vmovq xmm15, r11
000075e5f6dd0c47  movaps xmm14, xmm1
000075e5f6dd0c4b  mulsd xmm14, xmm15
000075e5f6dd0c50  ucomisd xmm14, xmm14
000075e5f6dd0c55  jp 0x000075E5F6DD117A
000075e5f6dd0c5b  movq xmm14, xmm14
000075e5f6dd0c60  lea r12, [r14+0x140]
000075e5f6dd0c67  mov r11, [r13+r12*1]
000075e5f6dd0c6c  movq xmm1, r11
000075e5f6dd0c71  movq r12, xmm13
000075e5f6dd0c76  movq r11, xmm14
000075e5f6dd0c7b  vmovq xmm15, r12
000075e5f6dd0c80  vmovq xmm14, r11
000075e5f6dd0c85  movaps xmm13, xmm15
000075e5f6dd0c89  addsd xmm13, xmm14
000075e5f6dd0c8e  ucomisd xmm13, xmm13
000075e5f6dd0c93  jp 0x000075E5F6DD11D0
000075e5f6dd0c99  movq xmm13, xmm13
000075e5f6dd0c9e  movaps xmm15, [r15+0x170]
000075e5f6dd0ca6  movq r12, xmm15
000075e5f6dd0cab  movq r11, xmm1
000075e5f6dd0cb0  vmovq xmm1, r12
000075e5f6dd0cb5  vmovq xmm15, r11
000075e5f6dd0cba  movaps xmm14, xmm1
000075e5f6dd0cbe  mulsd xmm14, xmm15
000075e5f6dd0cc3  ucomisd xmm14, xmm14
000075e5f6dd0cc8  jp 0x000075E5F6DD121C
000075e5f6dd0cce  movq xmm14, xmm14
000075e5f6dd0cd3  lea r12, [r14+0x180]
000075e5f6dd0cda  mov r11, [r13+r12*1]
000075e5f6dd0cdf  movq xmm1, r11
000075e5f6dd0ce4  movq r12, xmm13
000075e5f6dd0ce9  movq r11, xmm14
000075e5f6dd0cee  vmovq xmm15, r12
000075e5f6dd0cf3  vmovq xmm14, r11
000075e5f6dd0cf8  movaps xmm13, xmm15
000075e5f6dd0cfc  addsd xmm13, xmm14
000075e5f6dd0d01  ucomisd xmm13, xmm13
000075e5f6dd0d06  jp 0x000075E5F6DD1272
000075e5f6dd0d0c  movq xmm13, xmm13
000075e5f6dd0d11  movaps xmm15, [r15+0x180]
000075e5f6dd0d19  movq r12, xmm15
000075e5f6dd0d1e  movq r11, xmm1
000075e5f6dd0d23  vmovq xmm1, r12
000075e5f6dd0d28  vmovq xmm15, r11
000075e5f6dd0d2d  movaps xmm14, xmm1
000075e5f6dd0d31  mulsd xmm14, xmm15
000075e5f6dd0d36  ucomisd xmm14, xmm14
000075e5f6dd0d3b  jp 0x000075E5F6DD12BE
000075e5f6dd0d41  movq xmm14, xmm14
000075e5f6dd0d46  lea r12, [r14+0x1C0]
000075e5f6dd0d4d  mov r14, [r13+r12*1]
000075e5f6dd0d52  movq xmm1, r14
000075e5f6dd0d57  movaps [r15+0x240], xmm1
000075e5f6dd0d5f  movq r14, xmm13
000075e5f6dd0d64  movq r12, xmm14
000075e5f6dd0d69  vmovq xmm15, r14
000075e5f6dd0d6e  vmovq xmm14, r12
000075e5f6dd0d73  movaps xmm13, xmm15
000075e5f6dd0d77  addsd xmm13, xmm14
000075e5f6dd0d7c  ucomisd xmm13, xmm13
000075e5f6dd0d81  jp 0x000075E5F6DD1314
000075e5f6dd0d87  movq xmm13, xmm13
000075e5f6dd0d8c  movaps xmm15, [r15+0x210]
000075e5f6dd0d94  movq r14, xmm15
000075e5f6dd0d99  movq r12, xmm1
000075e5f6dd0d9e  vmovq xmm1, r14
000075e5f6dd0da3  vmovq xmm15, r12
000075e5f6dd0da8  movaps xmm14, xmm1
000075e5f6dd0dac  mulsd xmm14, xmm15
000075e5f6dd0db1  ucomisd xmm14, xmm14
000075e5f6dd0db6  jp 0x000075E5F6DD1360
000075e5f6dd0dbc  movq xmm14, xmm14
000075e5f6dd0dc1  movaps [r15+0x230], xmm14
000075e5f6dd0dc9  movq r14, xmm13
000075e5f6dd0dce  movq r12, xmm14
000075e5f6dd0dd3  vmovq xmm1, r14
000075e5f6dd0dd8  vmovq xmm15, r12
000075e5f6dd0ddd  movaps xmm14, xmm1
000075e5f6dd0de1  addsd xmm14, xmm15
000075e5f6dd0de6  ucomisd xmm14, xmm14
000075e5f6dd0deb  jp 0x000075E5F6DD13AC
000075e5f6dd0df1  movq xmm14, xmm14
000075e5f6dd0df6  movaps [r15+0x220], xmm14
000075e5f6dd0dfe  movq r14, xmm14
000075e5f6dd0e03  mov [r13+rax*1], r14
000075e5f6dd0e08  mov qword ptr [r15+0x70], 0x08
000075e5f6dd0e10  xor eax, eax
000075e5f6dd0e12  mov r14d, 0x08
000075e5f6dd0e18  mov r12d, 0x40
000075e5f6dd0e1e  cmp r14, r12
000075e5f6dd0e21  cmc
000075e5f6dd0e22  lahf
000075e5f6dd0e23  seto al
000075e5f6dd0e26  mov [r15+0x108], eax
000075e5f6dd0e2d  mov eax, [r15+0x108]
000075e5f6dd0e34  sahf
000075e5f6dd0e35  jnz 0x000075E5F6DD0E67
000075e5f6dd0e37  cmp dword ptr [r15+0x318], 0x00
000075e5f6dd0e3f  jz 0x000075E5F6DCFD40
000075e5f6dd0e45  nop [rax+rax*1], ax
000075e5f6dd0e4e  nop [rax+rax*1], eax
000075e5f6dd0e56  mov eax, 0x410118
000075e5f6dd0e5b  mov [r15+0x100], rax
000075e5f6dd0e62  jmp 0x000075E5F6BFE110
000075e5f6dd0e67  cmp dword ptr [r15+0x318], 0x00
000075e5f6dd0e6f  jz 0x000075E5F6DCF3F0
000075e5f6dd0e75  nop [rax+rax*1], ax
000075e5f6dd0e7e  nop [rax+rax*1], eax
000075e5f6dd0e86  mov eax, 0x4100A4
000075e5f6dd0e8b  mov [r15+0x100], rax
000075e5f6dd0e92  jmp 0x000075E5F6BFE110
000075e5f6dd0e97  int3
000075e5f6dd0e98  call 0x000075E5F6CE27E0
000075e5f6dd0e9d  jmp 0x000075E5F6DD0959
000075e5f6dd0ea2  call 0x000075E5F6CAE800
000075e5f6dd0ea7  jmp 0x000075E5F6DD0962
000075e5f6dd0eac  call 0x000075E5F6CC0370
000075e5f6dd0eb1  jmp 0x000075E5F6DD0997
000075e5f6dd0eb6  call 0x000075E5F6CBF100
000075e5f6dd0ebb  jmp 0x000075E5F6DD09A0
000075e5f6dd0ec0  call 0x000075E5F6CC0370
000075e5f6dd0ec5  jmp 0x000075E5F6DD09D5
000075e5f6dd0eca  call 0x000075E5F6CBF100
000075e5f6dd0ecf  jmp 0x000075E5F6DD09DE
000075e5f6dd0ed4  call 0x000075E5F6CC0370
000075e5f6dd0ed9  jmp 0x000075E5F6DD0A13
000075e5f6dd0ede  call 0x000075E5F6CC3AE0
000075e5f6dd0ee3  jmp 0x000075E5F6DD0A1C
000075e5f6dd0ee8  call 0x000075E5F6CE27E0
000075e5f6dd0eed  jmp 0x000075E5F6DD0A55
000075e5f6dd0ef2  call 0x000075E5F6CC0370
000075e5f6dd0ef7  jmp 0x000075E5F6DD0A63
000075e5f6dd0efc  call 0x000075E5F6CC0370
000075e5f6dd0f01  jmp 0x000075E5F6DD0A74
000075e5f6dd0f06  ucomisd xmm1, xmm13
000075e5f6dd0f0b  jp 0x000075E5F6DD0F1A
000075e5f6dd0f0d  movaps xmm12, [0x000075E5F69FE030]
000075e5f6dd0f15  jmp 0x000075E5F6DD0AA9
000075e5f6dd0f1a  vxorps xmm0, xmm1, xmm13
000075e5f6dd0f1f  pextrw r12d, xmm0, 0x03
000075e5f6dd0f25  and r12d, 0x7FF8
000075e5f6dd0f2c  cmp r12d, 0x08
000075e5f6dd0f30  jnz 0x000075E5F6DD0AA9
000075e5f6dd0f36  movq r12, xmm13
000075e5f6dd0f3b  shl r12, 0x0D
000075e5f6dd0f3f  jbe 0x000075E5F6DD0AA9
000075e5f6dd0f45  vorps xmm12, xmm13, [0x000075E5F69FE040]
000075e5f6dd0f4d  jmp 0x000075E5F6DD0AA9
000075e5f6dd0f52  ucomisd xmm1, xmm15
000075e5f6dd0f57  jp 0x000075E5F6DD0F66
000075e5f6dd0f59  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd0f61  jmp 0x000075E5F6DD0ADE
000075e5f6dd0f66  vxorps xmm0, xmm1, xmm15
000075e5f6dd0f6b  pextrw r12d, xmm0, 0x03
000075e5f6dd0f71  and r12d, 0x7FF8
000075e5f6dd0f78  cmp r12d, 0x08
000075e5f6dd0f7c  jnz 0x000075E5F6DD0ADE
000075e5f6dd0f82  movq r12, xmm15
000075e5f6dd0f87  shl r12, 0x0D
000075e5f6dd0f8b  jbe 0x000075E5F6DD0ADE
000075e5f6dd0f91  vorps xmm13, xmm15, [0x000075E5F69FE040]
000075e5f6dd0f99  jmp 0x000075E5F6DD0ADE
000075e5f6dd0f9e  ucomisd xmm1, xmm15
000075e5f6dd0fa3  jp 0x000075E5F6DD0FB2
000075e5f6dd0fa5  movaps xmm12, [0x000075E5F69FE030]
000075e5f6dd0fad  jmp 0x000075E5F6DD0B13
000075e5f6dd0fb2  vxorps xmm0, xmm1, xmm15
000075e5f6dd0fb7  pextrw r12d, xmm0, 0x03
000075e5f6dd0fbd  and r12d, 0x7FF8
000075e5f6dd0fc4  cmp r12d, 0x08
000075e5f6dd0fc8  jnz 0x000075E5F6DD0B13
000075e5f6dd0fce  movq r12, xmm15
000075e5f6dd0fd3  shl r12, 0x0D
000075e5f6dd0fd7  jbe 0x000075E5F6DD0B13
000075e5f6dd0fdd  vorps xmm12, xmm15, [0x000075E5F69FE040]
000075e5f6dd0fe5  jmp 0x000075E5F6DD0B13
000075e5f6dd0fea  ucomisd xmm1, xmm15
000075e5f6dd0fef  jp 0x000075E5F6DD0FFE
000075e5f6dd0ff1  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd0ff9  jmp 0x000075E5F6DD0B40
000075e5f6dd0ffe  vxorps xmm0, xmm1, xmm15
000075e5f6dd1003  pextrw r12d, xmm0, 0x03
000075e5f6dd1009  and r12d, 0x7FF8
000075e5f6dd1010  cmp r12d, 0x08
000075e5f6dd1014  jnz 0x000075E5F6DD0B40
000075e5f6dd101a  movq r12, xmm15
000075e5f6dd101f  shl r12, 0x0D
000075e5f6dd1023  jbe 0x000075E5F6DD0B40
000075e5f6dd1029  vorps xmm13, xmm15, [0x000075E5F69FE040]
000075e5f6dd1031  jmp 0x000075E5F6DD0B40
000075e5f6dd1036  ucomisd xmm1, xmm15
000075e5f6dd103b  jp 0x000075E5F6DD104A
000075e5f6dd103d  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd1045  jmp 0x000075E5F6DD0B75
000075e5f6dd104a  vxorps xmm0, xmm1, xmm15
000075e5f6dd104f  pextrw r12d, xmm0, 0x03
000075e5f6dd1055  and r12d, 0x7FF8
000075e5f6dd105c  cmp r12d, 0x08
000075e5f6dd1060  jnz 0x000075E5F6DD0B75
000075e5f6dd1066  movq r12, xmm15
000075e5f6dd106b  shl r12, 0x0D
000075e5f6dd106f  jbe 0x000075E5F6DD0B75
000075e5f6dd1075  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd107d  jmp 0x000075E5F6DD0B75
000075e5f6dd1082  call 0x000075E5F6CC0370
000075e5f6dd1087  jmp 0x000075E5F6DD0B86
000075e5f6dd108c  ucomisd xmm15, xmm14
000075e5f6dd1091  jp 0x000075E5F6DD10A0
000075e5f6dd1093  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd109b  jmp 0x000075E5F6DD0BB3
000075e5f6dd10a0  vxorps xmm0, xmm15, xmm14
000075e5f6dd10a5  pextrw r12d, xmm0, 0x03
000075e5f6dd10ab  and r12d, 0x7FF8
000075e5f6dd10b2  cmp r12d, 0x08
000075e5f6dd10b6  jnz 0x000075E5F6DD0BB3
000075e5f6dd10bc  movq r12, xmm14
000075e5f6dd10c1  shl r12, 0x0D
000075e5f6dd10c5  jbe 0x000075E5F6DD0BB3
000075e5f6dd10cb  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dd10d3  jmp 0x000075E5F6DD0BB3
000075e5f6dd10d8  ucomisd xmm1, xmm15
000075e5f6dd10dd  jp 0x000075E5F6DD10EC
000075e5f6dd10df  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd10e7  jmp 0x000075E5F6DD0BE8
000075e5f6dd10ec  vxorps xmm0, xmm1, xmm15
000075e5f6dd10f1  pextrw r12d, xmm0, 0x03
000075e5f6dd10f7  and r12d, 0x7FF8
000075e5f6dd10fe  cmp r12d, 0x08
000075e5f6dd1102  jnz 0x000075E5F6DD0BE8
000075e5f6dd1108  movq r12, xmm15
000075e5f6dd110d  shl r12, 0x0D
000075e5f6dd1111  jbe 0x000075E5F6DD0BE8
000075e5f6dd1117  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd111f  jmp 0x000075E5F6DD0BE8
000075e5f6dd1124  call 0x000075E5F6CC0370
000075e5f6dd1129  jmp 0x000075E5F6DD0BF9
000075e5f6dd112e  ucomisd xmm15, xmm14
000075e5f6dd1133  jp 0x000075E5F6DD1142
000075e5f6dd1135  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd113d  jmp 0x000075E5F6DD0C26
000075e5f6dd1142  vxorps xmm0, xmm15, xmm14
000075e5f6dd1147  pextrw r12d, xmm0, 0x03
000075e5f6dd114d  and r12d, 0x7FF8
000075e5f6dd1154  cmp r12d, 0x08
000075e5f6dd1158  jnz 0x000075E5F6DD0C26
000075e5f6dd115e  movq r12, xmm14
000075e5f6dd1163  shl r12, 0x0D
000075e5f6dd1167  jbe 0x000075E5F6DD0C26
000075e5f6dd116d  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dd1175  jmp 0x000075E5F6DD0C26
000075e5f6dd117a  ucomisd xmm1, xmm15
000075e5f6dd117f  jp 0x000075E5F6DD118E
000075e5f6dd1181  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd1189  jmp 0x000075E5F6DD0C5B
000075e5f6dd118e  vxorps xmm0, xmm1, xmm15
000075e5f6dd1193  pextrw r12d, xmm0, 0x03
000075e5f6dd1199  and r12d, 0x7FF8
000075e5f6dd11a0  cmp r12d, 0x08
000075e5f6dd11a4  jnz 0x000075E5F6DD0C5B
000075e5f6dd11aa  movq r12, xmm15
000075e5f6dd11af  shl r12, 0x0D
000075e5f6dd11b3  jbe 0x000075E5F6DD0C5B
000075e5f6dd11b9  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd11c1  jmp 0x000075E5F6DD0C5B
000075e5f6dd11c6  call 0x000075E5F6CC0370
000075e5f6dd11cb  jmp 0x000075E5F6DD0C6C
000075e5f6dd11d0  ucomisd xmm15, xmm14
000075e5f6dd11d5  jp 0x000075E5F6DD11E4
000075e5f6dd11d7  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd11df  jmp 0x000075E5F6DD0C99
000075e5f6dd11e4  vxorps xmm0, xmm15, xmm14
000075e5f6dd11e9  pextrw r12d, xmm0, 0x03
000075e5f6dd11ef  and r12d, 0x7FF8
000075e5f6dd11f6  cmp r12d, 0x08
000075e5f6dd11fa  jnz 0x000075E5F6DD0C99
000075e5f6dd1200  movq r12, xmm14
000075e5f6dd1205  shl r12, 0x0D
000075e5f6dd1209  jbe 0x000075E5F6DD0C99
000075e5f6dd120f  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dd1217  jmp 0x000075E5F6DD0C99
000075e5f6dd121c  ucomisd xmm1, xmm15
000075e5f6dd1221  jp 0x000075E5F6DD1230
000075e5f6dd1223  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd122b  jmp 0x000075E5F6DD0CCE
000075e5f6dd1230  vxorps xmm0, xmm1, xmm15
000075e5f6dd1235  pextrw r12d, xmm0, 0x03
000075e5f6dd123b  and r12d, 0x7FF8
000075e5f6dd1242  cmp r12d, 0x08
000075e5f6dd1246  jnz 0x000075E5F6DD0CCE
000075e5f6dd124c  movq r12, xmm15
000075e5f6dd1251  shl r12, 0x0D
000075e5f6dd1255  jbe 0x000075E5F6DD0CCE
000075e5f6dd125b  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd1263  jmp 0x000075E5F6DD0CCE
000075e5f6dd1268  call 0x000075E5F6CC0370
000075e5f6dd126d  jmp 0x000075E5F6DD0CDF
000075e5f6dd1272  ucomisd xmm15, xmm14
000075e5f6dd1277  jp 0x000075E5F6DD1286
000075e5f6dd1279  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd1281  jmp 0x000075E5F6DD0D0C
000075e5f6dd1286  vxorps xmm0, xmm15, xmm14
000075e5f6dd128b  pextrw r12d, xmm0, 0x03
000075e5f6dd1291  and r12d, 0x7FF8
000075e5f6dd1298  cmp r12d, 0x08
000075e5f6dd129c  jnz 0x000075E5F6DD0D0C
000075e5f6dd12a2  movq r12, xmm14
000075e5f6dd12a7  shl r12, 0x0D
000075e5f6dd12ab  jbe 0x000075E5F6DD0D0C
000075e5f6dd12b1  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dd12b9  jmp 0x000075E5F6DD0D0C
000075e5f6dd12be  ucomisd xmm1, xmm15
000075e5f6dd12c3  jp 0x000075E5F6DD12D2
000075e5f6dd12c5  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd12cd  jmp 0x000075E5F6DD0D41
000075e5f6dd12d2  vxorps xmm0, xmm1, xmm15
000075e5f6dd12d7  pextrw r12d, xmm0, 0x03
000075e5f6dd12dd  and r12d, 0x7FF8
000075e5f6dd12e4  cmp r12d, 0x08
000075e5f6dd12e8  jnz 0x000075E5F6DD0D41
000075e5f6dd12ee  movq r12, xmm15
000075e5f6dd12f3  shl r12, 0x0D
000075e5f6dd12f7  jbe 0x000075E5F6DD0D41
000075e5f6dd12fd  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd1305  jmp 0x000075E5F6DD0D41
000075e5f6dd130a  call 0x000075E5F6CC3AE0
000075e5f6dd130f  jmp 0x000075E5F6DD0D52
000075e5f6dd1314  ucomisd xmm15, xmm14
000075e5f6dd1319  jp 0x000075E5F6DD1328
000075e5f6dd131b  movaps xmm13, [0x000075E5F69FE030]
000075e5f6dd1323  jmp 0x000075E5F6DD0D87
000075e5f6dd1328  vxorps xmm0, xmm15, xmm14
000075e5f6dd132d  pextrw r14d, xmm0, 0x03
000075e5f6dd1333  and r14d, 0x7FF8
000075e5f6dd133a  cmp r14d, 0x08
000075e5f6dd133e  jnz 0x000075E5F6DD0D87
000075e5f6dd1344  movq r14, xmm14
000075e5f6dd1349  shl r14, 0x0D
000075e5f6dd134d  jbe 0x000075E5F6DD0D87
000075e5f6dd1353  vorps xmm13, xmm14, [0x000075E5F69FE040]
000075e5f6dd135b  jmp 0x000075E5F6DD0D87
000075e5f6dd1360  ucomisd xmm1, xmm15
000075e5f6dd1365  jp 0x000075E5F6DD1374
000075e5f6dd1367  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd136f  jmp 0x000075E5F6DD0DBC
000075e5f6dd1374  vxorps xmm0, xmm1, xmm15
000075e5f6dd1379  pextrw r14d, xmm0, 0x03
000075e5f6dd137f  and r14d, 0x7FF8
000075e5f6dd1386  cmp r14d, 0x08
000075e5f6dd138a  jnz 0x000075E5F6DD0DBC
000075e5f6dd1390  movq r14, xmm15
000075e5f6dd1395  shl r14, 0x0D
000075e5f6dd1399  jbe 0x000075E5F6DD0DBC
000075e5f6dd139f  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd13a7  jmp 0x000075E5F6DD0DBC
000075e5f6dd13ac  ucomisd xmm1, xmm15
000075e5f6dd13b1  jp 0x000075E5F6DD13C0
000075e5f6dd13b3  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd13bb  jmp 0x000075E5F6DD0DF1
000075e5f6dd13c0  vxorps xmm0, xmm1, xmm15
000075e5f6dd13c5  pextrw r14d, xmm0, 0x03
000075e5f6dd13cb  and r14d, 0x7FF8
000075e5f6dd13d2  cmp r14d, 0x08
000075e5f6dd13d6  jnz 0x000075E5F6DD0DF1
000075e5f6dd13dc  movq r14, xmm15
000075e5f6dd13e1  shl r14, 0x0D
000075e5f6dd13e5  jbe 0x000075E5F6DD0DF1
000075e5f6dd13eb  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd13f3  jmp 0x000075E5F6DD0DF1
000075e5f6dd13f8  call 0x000075E5F6C0E120
000075e5f6dd13fd  jmp 0x000075E5F6DD0E08
000075e5f6dd1402  int3
000075e5f6dd1403  nop [rax+rax*1], ax
000075e5f6dd140c  nop [rax], eax
000075e5f6dd1410  mov qword ptr [r15+0x40], 0x420000
000075e5f6dd1418  mov eax, 0x4201B8
000075e5f6dd141d  mov r14, [r13+rax*1]
000075e5f6dd1422  movq xmm1, r14
000075e5f6dd1427  mov rax, [r15+0x50]
000075e5f6dd142b  mov r14, [r13+rax*1]
000075e5f6dd1430  movq xmm15, r14
000075e5f6dd1435  movaps [r15+0x120], xmm15
000075e5f6dd143d  mov qword ptr [r15+0x48], 0x08
000075e5f6dd1445  xor eax, eax
000075e5f6dd1447  mov r14d, 0x08
000075e5f6dd144d  mov r12d, 0x200
000075e5f6dd1453  cmp r14, r12
000075e5f6dd1456  cmc
000075e5f6dd1457  lahf
000075e5f6dd1458  seto al
000075e5f6dd145b  mov [r15+0x108], eax
000075e5f6dd1462  movq rax, xmm1
000075e5f6dd1467  movq r14, xmm15
000075e5f6dd146c  vmovq xmm1, rax
000075e5f6dd1471  vmovq xmm15, r14
000075e5f6dd1476  movaps xmm14, xmm1
000075e5f6dd147a  addsd xmm14, xmm15
000075e5f6dd147f  ucomisd xmm14, xmm14
000075e5f6dd1484  jp 0x000075E5F6DD1516
000075e5f6dd148a  movq xmm14, xmm14
000075e5f6dd148f  movaps [r15+0x110], xmm14
000075e5f6dd1497  mov eax, [r15+0x108]
000075e5f6dd149e  sahf
000075e5f6dd149f  jnz 0x000075E5F6DD14D1
000075e5f6dd14a1  cmp dword ptr [r15+0x318], 0x00
000075e5f6dd14a9  jz 0x000075E5F6DD16A0
000075e5f6dd14af  nop [rax+rax*1], ax
000075e5f6dd14b8  nop [rax+rax*1], eax
000075e5f6dd14c0  mov eax, 0x410154
000075e5f6dd14c5  mov [r15+0x100], rax
000075e5f6dd14cc  jmp 0x000075E5F6BFE110
000075e5f6dd14d1  cmp dword ptr [r15+0x318], 0x00
000075e5f6dd14d9  jz 0x000075E5F6DD1560
000075e5f6dd14df  nop [rax+rax*1], ax
000075e5f6dd14e8  nop [rax+rax*1], eax
000075e5f6dd14f0  mov eax, 0x410140
000075e5f6dd14f5  mov [r15+0x100], rax
000075e5f6dd14fc  jmp 0x000075E5F6BFE110
000075e5f6dd1501  int3
000075e5f6dd1502  call 0x000075E5F6C0DC20
000075e5f6dd1507  jmp 0x000075E5F6DD1422
000075e5f6dd150c  call 0x000075E5F6C0DC20
000075e5f6dd1511  jmp 0x000075E5F6DD1430
000075e5f6dd1516  ucomisd xmm1, xmm15
000075e5f6dd151b  jp 0x000075E5F6DD152A
000075e5f6dd151d  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd1525  jmp 0x000075E5F6DD148A
000075e5f6dd152a  vxorps xmm0, xmm1, xmm15
000075e5f6dd152f  pextrw eax, xmm0, 0x03
000075e5f6dd1534  and eax, 0x7FF8
000075e5f6dd1539  cmp eax, 0x08
000075e5f6dd153c  jnz 0x000075E5F6DD148A
000075e5f6dd1542  movq rax, xmm15
000075e5f6dd1547  shl rax, 0x0D
000075e5f6dd154b  jbe 0x000075E5F6DD148A
000075e5f6dd1551  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd1559  jmp 0x000075E5F6DD148A
000075e5f6dd155e  int3
000075e5f6dd155f  nop
000075e5f6dd1560  mov rax, [r15+0x48]
000075e5f6dd1564  mov r14, [r15+0x50]
000075e5f6dd1568  lea r12, [r14+rax*1]
000075e5f6dd156c  mov r14, [r13+r12*1]
000075e5f6dd1571  movq xmm1, r14
000075e5f6dd1576  movaps [r15+0x120], xmm1
000075e5f6dd157e  lea r14, [rax+0x08]
000075e5f6dd1582  mov [r15+0x48], r14
000075e5f6dd1586  xor eax, eax
000075e5f6dd1588  mov r12d, 0x200
000075e5f6dd158e  cmp r14, r12
000075e5f6dd1591  cmc
000075e5f6dd1592  lahf
000075e5f6dd1593  seto al
000075e5f6dd1596  mov [r15+0x108], eax
000075e5f6dd159d  movaps xmm15, [r15+0x110]
000075e5f6dd15a5  movq rax, xmm15
000075e5f6dd15aa  movq r14, xmm1
000075e5f6dd15af  vmovq xmm1, rax
000075e5f6dd15b4  vmovq xmm15, r14
000075e5f6dd15b9  movaps xmm14, xmm1
000075e5f6dd15bd  addsd xmm14, xmm15
000075e5f6dd15c2  ucomisd xmm14, xmm14
000075e5f6dd15c7  jp 0x000075E5F6DD164F
000075e5f6dd15cd  movq xmm14, xmm14
000075e5f6dd15d2  movaps [r15+0x110], xmm14
000075e5f6dd15da  mov eax, [r15+0x108]
000075e5f6dd15e1  sahf
000075e5f6dd15e2  jnz 0x000075E5F6DD1614
000075e5f6dd15e4  cmp dword ptr [r15+0x318], 0x00
000075e5f6dd15ec  jz 0x000075E5F6DD16A0
000075e5f6dd15f2  nop [rax+rax*1], ax
000075e5f6dd15fb  nop [rax+rax*1], eax
000075e5f6dd1603  mov eax, 0x410154
000075e5f6dd1608  mov [r15+0x100], rax
000075e5f6dd160f  jmp 0x000075E5F6BFE110
000075e5f6dd1614  cmp dword ptr [r15+0x318], 0x00
000075e5f6dd161c  jz 0x000075E5F6DD1560
000075e5f6dd1622  nop [rax+rax*1], ax
000075e5f6dd162b  nop [rax+rax*1], eax
000075e5f6dd1633  mov eax, 0x410140
000075e5f6dd1638  mov [r15+0x100], rax
000075e5f6dd163f  jmp 0x000075E5F6BFE110
000075e5f6dd1644  int3
000075e5f6dd1645  call 0x000075E5F6CC3AE0
000075e5f6dd164a  jmp 0x000075E5F6DD1571
000075e5f6dd164f  ucomisd xmm1, xmm15
000075e5f6dd1654  jp 0x000075E5F6DD1663
000075e5f6dd1656  movaps xmm14, [0x000075E5F69FE030]
000075e5f6dd165e  jmp 0x000075E5F6DD15CD
000075e5f6dd1663  vxorps xmm0, xmm1, xmm15
000075e5f6dd1668  pextrw eax, xmm0, 0x03
000075e5f6dd166d  and eax, 0x7FF8
000075e5f6dd1672  cmp eax, 0x08
000075e5f6dd1675  jnz 0x000075E5F6DD15CD
000075e5f6dd167b  movq rax, xmm15
000075e5f6dd1680  shl rax, 0x0D
000075e5f6dd1684  jbe 0x000075E5F6DD15CD
000075e5f6dd168a  vorps xmm14, xmm15, [0x000075E5F69FE040]
000075e5f6dd1692  jmp 0x000075E5F6DD15CD
000075e5f6dd1697  int3
000075e5f6dd1698  nop [rax+rax*1], eax
000075e5f6dd16a0  mov rax, [r15+0x40]
000075e5f6dd16a4  lea r14, [rax+0x1B8]
000075e5f6dd16ab  movaps xmm1, [r15+0x110]
000075e5f6dd16b3  movq rax, xmm1
000075e5f6dd16b8  mov [r13+r14*1], rax
000075e5f6dd16bd  mov rax, [r15+0xF0]
000075e5f6dd16c4  mov [r15+0x100], rax
000075e5f6dd16cb  jmp 0x000075E5F6DCE5C0
000075e5f6dd16d0  int3
000075e5f6dd16d1  call 0x000075E5F6CD5EB0
000075e5f6dd16d6  jmp 0x000075E5F6DD16BD
000075e5f6dd16db  int3
000075e5f6dd16dc  nop [rax], eax
000075e5f6dd16e0  mov qword ptr [r15+0x100], 0x04
000075e5f6dd16eb  mov esi, 0x00
000075e5f6dd16f0  mov edx, 0x09
000075e5f6dd16f5  mov rdi, 0x7FFCCF56BE80
000075e5f6dd16ff  mov rax, 0x589E13647970
000075e5f6dd1709  call rax
000075e5f6dd170b  cmp dword ptr [r15+0x318], 0x00
000075e5f6dd1713  jnz 0x000075E5F6BFE110
000075e5f6dd1719  jmp 0x000075E5F6BFE0A0
000075e5f6dd171e  int3
000075e5f6dd171f  int3
