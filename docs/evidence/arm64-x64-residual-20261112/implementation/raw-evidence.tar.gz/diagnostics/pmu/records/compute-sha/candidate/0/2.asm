
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-sha/candidate/0/2.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r13d,DWORD PTR [r12+0xa0]
   c:	sub    r13d,0x1
  10:	mov    QWORD PTR [r12+0xa0],r13
  18:	mov    rcx,QWORD PTR [r12+0x380]
  20:	jrcxz  0x27
  22:	jmp    0x1a5
  27:	jne    0x40
  2d:	mov    r11,rax
  30:	lahf
  31:	seto   al
  34:	mov    WORD PTR [rsp],ax
  38:	mov    rax,r11
  3b:	jmp    0x53
  40:	mov    r11,rax
  43:	lahf
  44:	seto   al
  47:	mov    WORD PTR [rsp],ax
  4b:	mov    rax,r11
  4e:	jmp    0x115
  53:	mov    r13,QWORD PTR [r12+0xf8]
  5b:	mov    r14,r13
  5e:	add    r14,0x20
  62:	mov    r15,QWORD PTR [r14]
  65:	mov    QWORD PTR [r12+0x98],r15
  6d:	mov    r14d,0x80
  73:	mov    QWORD PTR [r12+0x40],r14
  78:	mov    QWORD PTR [r12],r13
  7c:	mov    r14,r13
  7f:	add    r14,0x8c
  86:	mov    QWORD PTR [r12+0x8],r14
  8b:	mov    r14d,0x1
  91:	mov    QWORD PTR [r12+0x10],r14
  96:	add    r13,0x8c
  9d:	movzx  r14d,BYTE PTR [r12+0x40]
  a3:	mov    BYTE PTR [r13+0x0],r14b
  a7:	mov    r13d,0x0
  ad:	mov    DWORD PTR [r12+0x32c],r13d
  b5:	mov    r13d,0x410298
  bb:	mov    QWORD PTR [r12+0xf0],r13
  c3:	mov    r13d,0x410338
  c9:	mov    QWORD PTR [r12+0x100],r13
  d1:	mov    r11,QWORD PTR [rsp]
  d5:	mov    QWORD PTR [r12+0x398],r11
  dd:	mov    edi,0x410338
  e2:	mov    QWORD PTR [r12+0x100],rdi
  ea:	add    rsp,0x10
  ee:	xchg   ax,ax
  f0:	jmp    QWORD PTR [rip+0x2]        # 0xf8
  f6:	xchg   ax,ax
  f8:	shl    ah,0xef
  fb:	sbb    eax,0x7da1
 100:	push   0xffffffffa11df00b
 105:	jge    0x107
 107:	add    BYTE PTR [rcx-0x45],cl
 10a:	rex or DWORD PTR [rbx],edx
 10d:	adc    eax,0x5804
 112:	jmp    r11
 115:	mov    r13,QWORD PTR [r12+0xf8]
 11d:	mov    QWORD PTR [r12],r13
 121:	mov    r13d,0x0
 127:	mov    r14,QWORD PTR [r12+0x98]
 12f:	or     r13,r14
 132:	mov    QWORD PTR [r12+0x8],r13
 137:	mov    r13d,0x12c
 13d:	mov    QWORD PTR [r12+0x10],r13
 142:	mov    r13d,0x410274
 148:	mov    QWORD PTR [r12+0xf0],r13
 150:	mov    r13d,0x410338
 156:	mov    QWORD PTR [r12+0x100],r13
 15e:	mov    r11,QWORD PTR [rsp]
 162:	mov    QWORD PTR [r12+0x398],r11
 16a:	mov    edi,0x410338
 16f:	mov    QWORD PTR [r12+0x100],rdi
 177:	add    rsp,0x10
 17b:	nop    DWORD PTR [rax+rax*1+0x0]
 180:	jmp    QWORD PTR [rip+0x2]        # 0x188
 186:	xchg   ax,ax
 188:	shl    ah,0xef
 18b:	sbb    eax,0x7da1
 190:	clc
 191:	or     esi,eax
 193:	sbb    eax,0x7da1
 198:	movabs r11,0x580415130940
 1a2:	jmp    r11
 1a5:	mov    eax,0x410278
 1aa:	mov    QWORD PTR [r12+0x100],rax
 1b2:	push   rdx
 1b3:	push   rsi
 1b4:	push   r10
 1b6:	push   r11
 1b8:	mov    r11,rax
 1bb:	lahf
 1bc:	seto   al
 1bf:	mov    WORD PTR [rsp+0x20],ax
 1c4:	mov    rax,r11
 1c7:	mov    rdx,QWORD PTR [rsp+0x20]
 1cc:	mov    r10d,edx
 1cf:	and    r10d,0xc000
 1d6:	shl    r10d,0x10
 1da:	mov    r11d,edx
 1dd:	and    r11d,0x100
 1e4:	shl    r11d,0x15
 1e8:	or     r10d,r11d
 1eb:	and    edx,0x1
 1ee:	shl    edx,0x1c
 1f1:	or     r10d,edx
 1f4:	btc    r10,0x1d
 1f9:	mov    r11d,0xf0000000
 1ff:	and    r11,r10
 202:	movabs rsi,0xffffffff0fffffff
 20c:	and    rbx,rsi
 20f:	or     rbx,r11
 212:	pop    r11
 214:	pop    r10
 216:	pop    rsi
 217:	pop    rdx
 218:	mov    QWORD PTR [r12+0x108],rbx
 220:	add    rsp,0x10
 224:	mov    eax,0xc
 229:	movabs r11,0x580415130ca0
 233:	jmp    r11
 236:	data16 nop WORD PTR [rax+rax*1+0x0]
 240:	sub    rsp,0x10
 244:	mov    r11,QWORD PTR [r12+0x398]
 24c:	mov    QWORD PTR [rsp],r11
 250:	jmp    0x53
 255:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 260:	sub    rsp,0x10
 264:	mov    r11,QWORD PTR [r12+0x398]
 26c:	mov    QWORD PTR [rsp],r11
 270:	jmp    0x115
 275:	nop
 276:	nop
 277:	nop
