
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/memory/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13d,0x1b00
  16:	mov    r14d,0xb7
  1c:	and    r14d,0xffff
  23:	mov    rax,r13
  26:	movabs rcx,0xffffffff0000ffff
  30:	and    rax,rcx
  33:	mov    rdx,r14
  36:	shl    rdx,0x10
  3a:	mov    ecx,0xffff0000
  3f:	and    rdx,rcx
  42:	or     rax,rdx
  45:	mov    r15,rax
  48:	mov    QWORD PTR [r12+0x8],r15
  4d:	mov    r13d,0x420060
  53:	mov    QWORD PTR [r12+0x20],r13
  58:	mov    r13d,0x0
  5e:	mov    QWORD PTR [r12],r13
  62:	jmp    0x67
  67:	mov    r13,QWORD PTR [r12+0x20]
  6c:	mov    r14,QWORD PTR [r12]
  70:	mov    QWORD PTR [r13+0x0],r14
  74:	mov    r14d,0x0
  7a:	mov    DWORD PTR [r12+0x32c],r14d
  82:	mov    r14,QWORD PTR [r13+0x0]
  86:	mov    QWORD PTR [r12+0x18],r14
  8b:	add    r14,0x3
  8f:	mov    QWORD PTR [r12],r14
  93:	mov    r13,QWORD PTR [r12+0x8]
  98:	sub    r13,0x1
  9c:	mov    QWORD PTR [r12+0x8],r13
  a1:	mov    rcx,QWORD PTR [r12+0x380]
  a9:	jrcxz  0xb0
  ab:	jmp    0x121
  b0:	pushf
  b1:	pop    r11
  b3:	mov    QWORD PTR [rsp],r11
  b7:	jne    0x67
  bd:	jmp    0xc2
  c2:	mov    r13,QWORD PTR [r12+0x20]
  c7:	mov    r14,QWORD PTR [r12]
  cb:	mov    QWORD PTR [r13+0x0],r14
  cf:	mov    r13d,0x0
  d5:	mov    DWORD PTR [r12+0x32c],r13d
  dd:	mov    rcx,QWORD PTR [r12+0x380]
  e5:	jrcxz  0xec
  e7:	jmp    0x1b0
  ec:	mov    r13,QWORD PTR [r12+0xf0]
  f4:	mov    QWORD PTR [r12+0x100],r13
  fc:	mov    r11,QWORD PTR [rsp]
 100:	mov    QWORD PTR [r12+0x398],r11
 108:	mov    rdi,QWORD PTR [r12+0x100]
 110:	add    rsp,0x10
 114:	movabs r11,0x5dac368e40a0
 11e:	jmp    r11
 121:	mov    eax,0x41004c
 126:	mov    QWORD PTR [r12+0x100],rax
 12e:	push   rdx
 12f:	push   rsi
 130:	push   r10
 132:	push   r11
 134:	pushf
 135:	pop    r11
 137:	mov    QWORD PTR [rsp+0x20],r11
 13c:	mov    rdx,QWORD PTR [rsp+0x20]
 141:	mov    r10d,edx
 144:	and    r10d,0xc0
 14b:	shl    r10d,0x18
 14f:	mov    r11d,edx
 152:	and    r11d,0x1
 156:	shl    r11d,0x1d
 15a:	or     r10d,r11d
 15d:	mov    r11d,edx
 160:	and    r11d,0x800
 167:	shl    r11d,0x11
 16b:	or     r10d,r11d
 16e:	btc    r10,0x1d
 173:	mov    r11d,0xf0000000
 179:	and    r11,r10
 17c:	movabs rsi,0xffffffff0fffffff
 186:	and    rbx,rsi
 189:	or     rbx,r11
 18c:	pop    r11
 18e:	pop    r10
 190:	pop    rsi
 191:	pop    rdx
 192:	mov    QWORD PTR [r12+0x108],rbx
 19a:	add    rsp,0x10
 19e:	mov    eax,0xc
 1a3:	movabs r11,0x5dac368e4390
 1ad:	jmp    r11
 1b0:	mov    eax,0x410054
 1b5:	mov    QWORD PTR [r12+0x100],rax
 1bd:	push   rdx
 1be:	push   rsi
 1bf:	push   r10
 1c1:	push   r11
 1c3:	mov    rdx,QWORD PTR [rsp+0x20]
 1c8:	mov    r10d,edx
 1cb:	and    r10d,0xc0
 1d2:	shl    r10d,0x18
 1d6:	mov    r11d,edx
 1d9:	and    r11d,0x1
 1dd:	shl    r11d,0x1d
 1e1:	or     r10d,r11d
 1e4:	mov    r11d,edx
 1e7:	and    r11d,0x800
 1ee:	shl    r11d,0x11
 1f2:	or     r10d,r11d
 1f5:	btc    r10,0x1d
 1fa:	mov    r11d,0xf0000000
 200:	and    r11,r10
 203:	movabs rsi,0xffffffff0fffffff
 20d:	and    rbx,rsi
 210:	or     rbx,r11
 213:	pop    r11
 215:	pop    r10
 217:	pop    rsi
 218:	pop    rdx
 219:	mov    QWORD PTR [r12+0x108],rbx
 221:	add    rsp,0x10
 225:	mov    eax,0xc
 22a:	movabs r11,0x5dac368e4390
 234:	jmp    r11
 237:	nop    WORD PTR [rax+rax*1+0x0]
 240:	sub    rsp,0x10
 244:	mov    r11,QWORD PTR [r12+0x398]
 24c:	mov    QWORD PTR [rsp],r11
 250:	jmp    0x67
 255:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 260:	sub    rsp,0x10
 264:	mov    r11,QWORD PTR [r12+0x398]
 26c:	mov    QWORD PTR [rsp],r11
 270:	jmp    0xc2
 275:	nop
 276:	nop
 277:	nop
