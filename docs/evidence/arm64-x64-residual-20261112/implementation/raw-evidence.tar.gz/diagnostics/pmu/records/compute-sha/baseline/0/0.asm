
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-sha/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xf8]
  18:	sub    r13,0xa0
  1f:	mov    QWORD PTR [r12+0xf8],r13
  27:	mov    r14d,0x420000
  2d:	mov    QWORD PTR [r12+0x40],r14
  32:	mov    r14d,0x420000
  38:	mov    QWORD PTR [r12+0x48],r14
  3d:	add    r13,0x90
  44:	mov    r14,r13
  47:	add    r14,0x8
  4b:	mov    r15,QWORD PTR [r12+0xa0]
  53:	mov    rbp,QWORD PTR [r12+0x98]
  5b:	mov    QWORD PTR [r13+0x0],r15
  5f:	mov    r13d,0x0
  65:	mov    DWORD PTR [r12+0x32c],r13d
  6d:	mov    QWORD PTR [r14],rbp
  70:	mov    r13d,0x0
  76:	mov    DWORD PTR [r12+0x32c],r13d
  7e:	mov    r13d,0x420670
  84:	movdqu xmm2,XMMWORD PTR [r13+0x0]
  8a:	movdqa xmm0,xmm2
  8e:	movdqu XMMWORD PTR [r12+0x110],xmm0
  98:	mov    r13d,0x420000
  9e:	mov    QWORD PTR [r12+0x40],r13
  a3:	mov    r13d,0x420610
  a9:	movdqu xmm3,XMMWORD PTR [r13+0x0]
  af:	movdqa xmm0,xmm3
  b3:	movdqu XMMWORD PTR [r12+0x120],xmm0
  bd:	mov    r13d,0x420000
  c3:	mov    QWORD PTR [r12+0x48],r13
  c8:	mov    r13d,0x420690
  ce:	movdqu xmm4,XMMWORD PTR [r13+0x0]
  d4:	movdqa xmm0,xmm4
  d8:	movdqu XMMWORD PTR [r12+0x130],xmm0
  e2:	mov    r13d,0x420000
  e8:	mov    QWORD PTR [r12+0x40],r13
  ed:	mov    r13d,0x420630
  f3:	movdqu xmm5,XMMWORD PTR [r13+0x0]
  f9:	movdqa xmm0,xmm5
  fd:	movdqu XMMWORD PTR [r12+0x140],xmm0
 107:	mov    r13d,0x430000
 10d:	add    r13,0x8a0
 114:	mov    QWORD PTR [r12+0x98],r13
 11c:	mov    r14,QWORD PTR [r12+0x40]
 121:	add    r14,0x6a0
 128:	movdqu xmm6,XMMWORD PTR [r14]
 12d:	movdqa xmm0,xmm6
 131:	movdqu XMMWORD PTR [r12+0x150],xmm0
 13b:	mov    r14d,0x420000
 141:	mov    QWORD PTR [r12+0x40],r14
 146:	mov    r14,r13
 149:	add    r14,0x10
 14d:	movdqu XMMWORD PTR [r13+0x0],xmm2
 153:	mov    r15d,0x0
 159:	mov    DWORD PTR [r12+0x32c],r15d
 161:	movdqu XMMWORD PTR [r14],xmm3
 166:	mov    r14d,0x0
 16c:	mov    DWORD PTR [r12+0x32c],r14d
 174:	mov    r14,r13
 177:	add    r14,0x20
 17b:	mov    r15,r14
 17e:	add    r15,0x10
 182:	movdqu XMMWORD PTR [r14],xmm4
 187:	mov    r14d,0x0
 18d:	mov    DWORD PTR [r12+0x32c],r14d
 195:	movdqu XMMWORD PTR [r15],xmm5
 19a:	mov    r14d,0x0
 1a0:	mov    DWORD PTR [r12+0x32c],r14d
 1a8:	mov    r14d,0x420600
 1ae:	movdqu xmm4,XMMWORD PTR [r14]
 1b3:	movdqa xmm0,xmm4
 1b7:	movdqu XMMWORD PTR [r12+0x130],xmm0
 1c1:	mov    r14d,0x420000
 1c7:	mov    QWORD PTR [r12+0x40],r14
 1cc:	mov    r14d,0x4205f0
 1d2:	movdqu xmm5,XMMWORD PTR [r14]
 1d7:	movdqa xmm0,xmm5
 1db:	movdqu XMMWORD PTR [r12+0x140],xmm0
 1e5:	mov    r14d,0x420000
 1eb:	mov    QWORD PTR [r12+0x40],r14
 1f0:	mov    r14,r13
 1f3:	add    r14,0x100
 1fa:	mov    r15,r14
 1fd:	add    r15,0x10
 201:	movdqu XMMWORD PTR [r14],xmm2
 206:	mov    r14d,0x0
 20c:	mov    DWORD PTR [r12+0x32c],r14d
 214:	movdqu XMMWORD PTR [r15],xmm3
 219:	mov    r14d,0x0
 21f:	mov    DWORD PTR [r12+0x32c],r14d
 227:	add    r13,0x40
 22b:	mov    r14,r13
 22e:	add    r14,0x10
 232:	movdqu XMMWORD PTR [r13+0x0],xmm6
 238:	mov    r13d,0x0
 23e:	mov    DWORD PTR [r12+0x32c],r13d
 246:	movdqu XMMWORD PTR [r14],xmm4
 24b:	mov    r13d,0x0
 251:	mov    DWORD PTR [r12+0x32c],r13d
 259:	mov    r13d,0x4205e0
 25f:	movdqu xmm2,XMMWORD PTR [r13+0x0]
 265:	movdqa xmm0,xmm2
 269:	movdqu XMMWORD PTR [r12+0x130],xmm0
 273:	mov    r13d,0x420000
 279:	mov    QWORD PTR [r12+0x40],r13
 27e:	mov    r13d,0x420640
 284:	movdqu xmm3,XMMWORD PTR [r13+0x0]
 28a:	movdqa xmm0,xmm3
 28e:	movdqu XMMWORD PTR [r12+0x150],xmm0
 298:	mov    r13d,0x420000
 29e:	mov    QWORD PTR [r12+0x40],r13
 2a3:	mov    r13d,0xf8d3
 2a9:	mov    QWORD PTR [r12+0x48],r13
 2ae:	mov    r13,QWORD PTR [r12+0x98]
 2b6:	mov    r14,r13
 2b9:	add    r14,0x60
 2bd:	mov    r15,r14
 2c0:	add    r15,0x10
 2c4:	movdqu XMMWORD PTR [r14],xmm5
 2c9:	mov    r14d,0x0
 2cf:	mov    DWORD PTR [r12+0x32c],r14d
 2d7:	movdqu XMMWORD PTR [r15],xmm2
 2dc:	mov    r14d,0x0
 2e2:	mov    DWORD PTR [r12+0x32c],r14d
 2ea:	mov    r14d,0x420650
 2f0:	movdqu xmm2,XMMWORD PTR [r14]
 2f5:	movdqa xmm0,xmm2
 2f9:	movdqu XMMWORD PTR [r12+0x130],xmm0
 303:	mov    r14d,0x420000
 309:	mov    QWORD PTR [r12+0x40],r14
 30e:	mov    r14d,0x420620
 314:	movdqu xmm2,XMMWORD PTR [r14]
 319:	movdqa xmm0,xmm2
 31d:	movdqu XMMWORD PTR [r12+0x140],xmm0
 327:	mov    r14d,0x420000
 32d:	mov    QWORD PTR [r12+0x40],r14
 332:	mov    r14d,0xf8d3
 338:	mov    r15d,0x421d
 33e:	and    r15d,0xffff
 345:	mov    rax,r14
 348:	movabs rcx,0xffffffff0000ffff
 352:	and    rax,rcx
 355:	mov    rdx,r15
 358:	shl    rdx,0x10
 35c:	mov    ecx,0xffff0000
 361:	and    rdx,rcx
 364:	or     rax,rdx
 367:	mov    ebp,eax
 369:	mov    QWORD PTR [r12+0x48],rbp
 36e:	mov    r14,r13
 371:	add    r14,0x80
 378:	mov    r15,r14
 37b:	add    r15,0x10
 37f:	movdqu xmm0,XMMWORD PTR [r12+0x130]
 389:	movdqa xmm2,xmm0
 38d:	movdqu XMMWORD PTR [r14],xmm3
 392:	mov    r14d,0x0
 398:	mov    DWORD PTR [r12+0x32c],r14d
 3a0:	movdqu XMMWORD PTR [r15],xmm2
 3a5:	mov    r14d,0x0
 3ab:	mov    DWORD PTR [r12+0x32c],r14d
 3b3:	mov    r14d,0x4206c0
 3b9:	movdqu xmm2,XMMWORD PTR [r14]
 3be:	movdqa xmm0,xmm2
 3c2:	movdqu XMMWORD PTR [r12+0x130],xmm0
 3cc:	mov    r14d,0x420000
 3d2:	mov    QWORD PTR [r12+0x40],r14
 3d7:	mov    r14d,0x4206d0
 3dd:	movdqu xmm3,XMMWORD PTR [r14]
 3e2:	movdqa xmm0,xmm3
 3e6:	movdqu XMMWORD PTR [r12+0x150],xmm0
 3f0:	mov    r14d,0x420000
 3f6:	mov    QWORD PTR [r12+0x40],r14
 3fb:	mov    r14d,0x3e8
 401:	mov    QWORD PTR [r12+0xa0],r14
 409:	add    r13,0xa0
 410:	mov    r14,r13
 413:	add    r14,0x10
 417:	movdqu xmm0,XMMWORD PTR [r12+0x140]
 421:	movdqa xmm3,xmm0
 425:	movdqu XMMWORD PTR [r13+0x0],xmm3
 42b:	mov    r13d,0x0
 431:	mov    DWORD PTR [r12+0x32c],r13d
 439:	movdqu XMMWORD PTR [r14],xmm2
 43e:	mov    r13d,0x0
 444:	mov    DWORD PTR [r12+0x32c],r13d
 44c:	mov    r13,QWORD PTR [r12+0x40]
 451:	add    r13,0x6b0
 458:	movdqu xmm2,XMMWORD PTR [r13+0x0]
 45e:	movdqa xmm0,xmm2
 462:	movdqu XMMWORD PTR [r12+0x130],xmm0
 46c:	mov    r13d,0x420000
 472:	mov    QWORD PTR [r12+0x40],r13
 477:	mov    r13d,0x420660
 47d:	movdqu xmm2,XMMWORD PTR [r13+0x0]
 483:	movdqa xmm0,xmm2
 487:	movdqu XMMWORD PTR [r12+0x140],xmm0
 491:	mov    r13d,0x420000
 497:	mov    QWORD PTR [r12+0x40],r13
 49c:	mov    r13,QWORD PTR [r12+0xf8]
 4a4:	add    r13,0x80
 4ab:	mov    r14,QWORD PTR [r12+0xf0]
 4b3:	mov    QWORD PTR [r13+0x0],r14
 4b7:	mov    r13d,0x0
 4bd:	mov    DWORD PTR [r12+0x32c],r13d
 4c5:	mov    r13,QWORD PTR [r12+0x98]
 4cd:	mov    r14,r13
 4d0:	add    r14,0xc0
 4d7:	mov    r15,r14
 4da:	add    r15,0x10
 4de:	movdqu xmm0,XMMWORD PTR [r12+0x150]
 4e8:	movdqa xmm2,xmm0
 4ec:	movdqu xmm0,XMMWORD PTR [r12+0x130]
 4f6:	movdqa xmm3,xmm0
 4fa:	movdqu XMMWORD PTR [r14],xmm2
 4ff:	mov    r14d,0x0
 505:	mov    DWORD PTR [r12+0x32c],r14d
 50d:	movdqu XMMWORD PTR [r15],xmm3
 512:	mov    r14d,0x0
 518:	mov    DWORD PTR [r12+0x32c],r14d
 520:	mov    r14d,0x420680
 526:	movdqu xmm2,XMMWORD PTR [r14]
 52b:	movdqa xmm0,xmm2
 52f:	movdqu XMMWORD PTR [r12+0x130],xmm0
 539:	mov    r14d,0x420000
 53f:	mov    QWORD PTR [r12+0x40],r14
 544:	mov    r14d,0x4206e0
 54a:	mov    r15,QWORD PTR [r14]
 54d:	mov    r14d,0x0
 553:	mov    QWORD PTR [r12+0x110],r15
 55b:	mov    QWORD PTR [r12+0x118],r14
 563:	mov    r14d,0x4206e8
 569:	mov    QWORD PTR [r12+0x40],r14
 56e:	mov    r14,r13
 571:	add    r14,0xe0
 578:	mov    rbp,r14
 57b:	add    rbp,0x10
 57f:	movdqu xmm0,XMMWORD PTR [r12+0x140]
 589:	movdqa xmm3,xmm0
 58d:	movdqu XMMWORD PTR [r14],xmm3
 592:	mov    r14d,0x0
 598:	mov    DWORD PTR [r12+0x32c],r14d
 5a0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
 5a5:	mov    r14d,0x0
 5ab:	mov    DWORD PTR [r12+0x32c],r14d
 5b3:	mov    r14d,0x420748
 5b9:	movdqu xmm2,XMMWORD PTR [r14]
 5be:	movdqa xmm0,xmm2
 5c2:	movdqu XMMWORD PTR [r12+0x130],xmm0
 5cc:	add    r13,0x120
 5d3:	mov    QWORD PTR [r13+0x0],r15
 5d7:	mov    r13d,0x0
 5dd:	mov    DWORD PTR [r12+0x32c],r13d
 5e5:	mov    r13d,0x420728
 5eb:	mov    r14d,0x420738
 5f1:	movdqu xmm3,XMMWORD PTR [r13+0x0]
 5f7:	movdqu xmm4,XMMWORD PTR [r14]
 5fc:	movdqa xmm0,xmm3
 600:	movdqu XMMWORD PTR [r12+0x120],xmm0
 60a:	movdqa xmm0,xmm4
 60e:	movdqu XMMWORD PTR [r12+0x110],xmm0
 618:	mov    r13,QWORD PTR [r12+0xf8]
 620:	mov    r14,r13
 623:	add    r14,0x60
 627:	movdqu XMMWORD PTR [r14],xmm2
 62c:	mov    r14d,0x0
 632:	mov    DWORD PTR [r12+0x32c],r14d
 63a:	mov    r14,QWORD PTR [r12+0x98]
 642:	mov    r15,r14
 645:	add    r15,0x128
 64c:	mov    ebp,DWORD PTR [r12+0x48]
 651:	mov    DWORD PTR [r15],ebp
 654:	mov    r15d,0x0
 65a:	mov    DWORD PTR [r12+0x32c],r15d
 662:	mov    r15,r13
 665:	add    r15,0x40
 669:	mov    rbp,r15
 66c:	add    rbp,0x10
 670:	movdqu XMMWORD PTR [r15],xmm3
 675:	mov    r15d,0x0
 67b:	mov    DWORD PTR [r12+0x32c],r15d
 683:	movdqu XMMWORD PTR [rbp+0x0],xmm4
 688:	mov    r15d,0x0
 68e:	mov    DWORD PTR [r12+0x32c],r15d
 696:	mov    r15d,0x4206e8
 69c:	mov    ebp,0x4206f8
 6a1:	movdqu xmm2,XMMWORD PTR [r15]
 6a6:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
 6ab:	movdqa xmm0,xmm2
 6af:	movdqu XMMWORD PTR [r12+0x110],xmm0
 6b9:	movdqa xmm0,xmm3
 6bd:	movdqu XMMWORD PTR [r12+0x120],xmm0
 6c7:	mov    r15,r13
 6ca:	add    r15,0x10
 6ce:	movdqu XMMWORD PTR [r13+0x0],xmm2
 6d4:	mov    ebp,0x0
 6d9:	mov    DWORD PTR [r12+0x32c],ebp
 6e1:	movdqu XMMWORD PTR [r15],xmm3
 6e6:	mov    r15d,0x0
 6ec:	mov    DWORD PTR [r12+0x32c],r15d
 6f4:	mov    r15d,0x420708
 6fa:	mov    ebp,0x420718
 6ff:	movdqu xmm2,XMMWORD PTR [r15]
 704:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
 709:	movdqa xmm0,xmm2
 70d:	movdqu XMMWORD PTR [r12+0x110],xmm0
 717:	movdqa xmm0,xmm3
 71b:	movdqu XMMWORD PTR [r12+0x130],xmm0
 725:	mov    r15,r13
 728:	add    r15,0x20
 72c:	mov    rbp,r15
 72f:	add    rbp,0x10
 733:	movdqu XMMWORD PTR [r15],xmm2
 738:	mov    r15d,0x0
 73e:	mov    DWORD PTR [r12+0x32c],r15d
 746:	movdqu XMMWORD PTR [rbp+0x0],xmm3
 74b:	mov    r15d,0x0
 751:	mov    DWORD PTR [r12+0x32c],r15d
 759:	add    r13,0x0
 75d:	mov    QWORD PTR [r12],r13
 761:	mov    r13d,0x0
 767:	mov    rcx,r14
 76a:	or     r13,rcx
 76d:	mov    QWORD PTR [r12+0x8],r13
 772:	mov    r13d,0x12c
 778:	mov    QWORD PTR [r12+0x10],r13
 77d:	mov    r13d,0x410274
 783:	mov    QWORD PTR [r12+0xf0],r13
 78b:	mov    r13d,0x410338
 791:	mov    QWORD PTR [r12+0x100],r13
 799:	mov    r11,QWORD PTR [rsp]
 79d:	mov    QWORD PTR [r12+0x398],r11
 7a5:	mov    edi,0x410338
 7aa:	mov    QWORD PTR [r12+0x100],rdi
 7b2:	add    rsp,0x10
 7b6:	xchg   ax,ax
 7b8:	jmp    QWORD PTR [rip+0x2]        # 0x7c0
 7be:	xchg   ax,ax
 7c0:	loopne 0x799
 7c2:	call   QWORD PTR [rbx-0x5f]
 7c5:	jg     0x7c7
 7c7:	add    al,dl
 7c9:	xlat   BYTE PTR ds:[rbx]
 7ca:	call   QWORD PTR [rbx-0x5f]
 7cd:	jg     0x7cf
 7cf:	add    BYTE PTR [rcx-0x45],cl
 7d2:	movabs al,ds:0x4100005fd6253550
 7db:	jmp    rbx
 7dd:	nop
 7de:	nop
 7df:	nop
