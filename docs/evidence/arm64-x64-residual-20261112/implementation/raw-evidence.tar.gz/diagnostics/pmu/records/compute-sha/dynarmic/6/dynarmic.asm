00007029abfce69b  nop [rax+rax*1], eax
00007029abfce6a0  mov rax, [r15+0xF8]
00007029abfce6a7  lea r14, [rax-0xA0]
00007029abfce6ae  mov [r15+0xF8], r14
00007029abfce6b5  lea rax, [r14+0x90]
00007029abfce6bc  mov r12, [r15+0xA0]
00007029abfce6c3  mov r11, [r15+0x98]
00007029abfce6ca  mov [r13+rax*1], r12
00007029abfce6cf  lea rax, [r14+0x98]
00007029abfce6d6  mov [r13+rax*1], r11
00007029abfce6db  mov eax, 0x420670
00007029abfce6e0  movups xmm1, [r13+rax*1]
00007029abfce6e6  mov eax, 0x420610
00007029abfce6eb  movups xmm15, [r13+rax*1]
00007029abfce6f1  mov eax, 0x420690
00007029abfce6f6  movups xmm14, [r13+rax*1]
00007029abfce6fc  mov eax, 0x420630
00007029abfce701  movups xmm13, [r13+rax*1]
00007029abfce707  mov qword ptr [r15+0x98], 0x4308A0
00007029abfce712  mov eax, 0x4206A0
00007029abfce717  movups xmm12, [r13+rax*1]
00007029abfce71d  mov eax, 0x4308A0
00007029abfce722  movups [r13+rax*1], xmm1
00007029abfce728  mov eax, 0x4308B0
00007029abfce72d  movups [r13+rax*1], xmm15
00007029abfce733  mov eax, 0x4308C0
00007029abfce738  movups [r13+rax*1], xmm14
00007029abfce73e  mov eax, 0x4308D0
00007029abfce743  movups [r13+rax*1], xmm13
00007029abfce749  mov eax, 0x420600
00007029abfce74e  movups xmm14, [r13+rax*1]
00007029abfce754  mov eax, 0x4205F0
00007029abfce759  movups xmm13, [r13+rax*1]
00007029abfce75f  mov eax, 0x4309A0
00007029abfce764  movups [r13+rax*1], xmm1
00007029abfce76a  mov eax, 0x4309B0
00007029abfce76f  movups [r13+rax*1], xmm15
00007029abfce775  mov eax, 0x4308E0
00007029abfce77a  movups [r13+rax*1], xmm12
00007029abfce780  mov eax, 0x4308F0
00007029abfce785  movups [r13+rax*1], xmm14
00007029abfce78b  mov eax, 0x4205E0
00007029abfce790  movups xmm1, [r13+rax*1]
00007029abfce796  mov eax, 0x420640
00007029abfce79b  movups xmm15, [r13+rax*1]
00007029abfce7a1  mov eax, 0x430900
00007029abfce7a6  movups [r13+rax*1], xmm13
00007029abfce7ac  mov eax, 0x430910
00007029abfce7b1  movups [r13+rax*1], xmm1
00007029abfce7b7  mov eax, 0x420650
00007029abfce7bc  movups xmm1, [r13+rax*1]
00007029abfce7c2  mov eax, 0x420620
00007029abfce7c7  movups xmm14, [r13+rax*1]
00007029abfce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007029abfce7d5  mov eax, 0x430920
00007029abfce7da  movups [r13+rax*1], xmm15
00007029abfce7e0  mov eax, 0x430930
00007029abfce7e5  movups [r13+rax*1], xmm1
00007029abfce7eb  mov eax, 0x4206C0
00007029abfce7f0  movups xmm1, [r13+rax*1]
00007029abfce7f6  mov eax, 0x4206D0
00007029abfce7fb  movups xmm15, [r13+rax*1]
00007029abfce801  movaps [r15+0x150], xmm15
00007029abfce809  mov qword ptr [r15+0xA0], 0x3E8
00007029abfce814  mov eax, 0x430940
00007029abfce819  movups [r13+rax*1], xmm14
00007029abfce81f  mov eax, 0x430950
00007029abfce824  movups [r13+rax*1], xmm1
00007029abfce82a  mov eax, 0x4206B0
00007029abfce82f  movups xmm1, [r13+rax*1]
00007029abfce835  mov eax, 0x420660
00007029abfce83a  movups xmm14, [r13+rax*1]
00007029abfce840  movaps [r15+0x140], xmm14
00007029abfce848  lea rax, [r14+0x80]
00007029abfce84f  mov r12, [r15+0xF0]
00007029abfce856  mov [r13+rax*1], r12
00007029abfce85b  mov eax, 0x430960
00007029abfce860  movups [r13+rax*1], xmm15
00007029abfce866  mov eax, 0x430970
00007029abfce86b  movups [r13+rax*1], xmm1
00007029abfce871  mov eax, 0x420680
00007029abfce876  movups xmm1, [r13+rax*1]
00007029abfce87c  mov eax, 0x4206E0
00007029abfce881  mov r12, [r13+rax*1]
00007029abfce886  movq xmm15, r12
00007029abfce88b  mov qword ptr [r15+0x40], 0x4206E8
00007029abfce893  mov eax, 0x430980
00007029abfce898  movups [r13+rax*1], xmm14
00007029abfce89e  mov eax, 0x430990
00007029abfce8a3  movups [r13+rax*1], xmm1
00007029abfce8a9  mov eax, 0x420748
00007029abfce8ae  movups xmm1, [r13+rax*1]
00007029abfce8b4  movq rax, xmm15
00007029abfce8b9  mov r12d, 0x4309C0
00007029abfce8bf  mov [r13+r12*1], rax
00007029abfce8c4  mov eax, 0x420728
00007029abfce8c9  movups xmm15, [r13+rax*1]
00007029abfce8cf  mov eax, 0x420738
00007029abfce8d4  movups xmm14, [r13+rax*1]
00007029abfce8da  lea rax, [r14+0x60]
00007029abfce8de  movups [r13+rax*1], xmm1
00007029abfce8e4  mov eax, 0x4309C8
00007029abfce8e9  mov r12d, 0x421DF8D3
00007029abfce8ef  mov [r13+rax*1], r12d
00007029abfce8f4  lea rax, [r14+0x40]
00007029abfce8f8  movups [r13+rax*1], xmm15
00007029abfce8fe  lea rax, [r14+0x50]
00007029abfce902  movups [r13+rax*1], xmm14
00007029abfce908  mov eax, 0x4206E8
00007029abfce90d  movups xmm1, [r13+rax*1]
00007029abfce913  mov eax, 0x4206F8
00007029abfce918  movups xmm15, [r13+rax*1]
00007029abfce91e  movaps [r15+0x120], xmm15
00007029abfce926  movups [r13+r14*1], xmm1
00007029abfce92c  lea rax, [r14+0x10]
00007029abfce930  movups [r13+rax*1], xmm15
00007029abfce936  mov eax, 0x420708
00007029abfce93b  movups xmm1, [r13+rax*1]
00007029abfce941  mov eax, 0x420718
00007029abfce946  movups xmm15, [r13+rax*1]
00007029abfce94c  movaps [r15+0x110], xmm1
00007029abfce954  movaps [r15+0x130], xmm15
00007029abfce95c  lea rax, [r14+0x20]
00007029abfce960  movups [r13+rax*1], xmm1
00007029abfce966  lea rax, [r14+0x30]
00007029abfce96a  movups [r13+rax*1], xmm15
00007029abfce970  mov [r15], r14
00007029abfce973  mov qword ptr [r15+0x08], 0x4308A0
00007029abfce97b  mov qword ptr [r15+0x10], 0x12C
00007029abfce983  mov qword ptr [r15+0xF0], 0x410274
00007029abfce98e  mov r14d, [r15+0x320]
00007029abfce995  mov eax, 0x410274
00007029abfce99a  mov rcx, 0x7029ABFD0670
00007029abfce9a4  mov [r15+r14*8+0x328], rax
00007029abfce9ac  mov [r15+r14*8+0x368], rcx
00007029abfce9b4  add r14d, 0x01
00007029abfce9b8  and r14d, 0x07
00007029abfce9bc  mov [r15+0x320], r14d
00007029abfce9c3  cmp dword ptr [r15+0x318], 0x00
00007029abfce9cb  jz 0x00007029ABFCEC20
00007029abfce9d1  nop [rax+rax*1], ax
00007029abfce9da  nop [rax+rax*1], eax
00007029abfce9e2  mov eax, 0x410338
00007029abfce9e7  mov [r15+0x100], rax
00007029abfce9ee  jmp 0x00007029ABDFE110
00007029abfce9f3  int3
00007029abfce9f4  call 0x00007029ABE0BC20
00007029abfce9f9  jmp 0x00007029ABFCE6CF
00007029abfce9fe  call 0x00007029ABE0A9A0
00007029abfcea03  jmp 0x00007029ABFCE6DB
00007029abfcea08  call 0x00007029ABDFF430
00007029abfcea0d  jmp 0x00007029ABFCE6E6
00007029abfcea12  call 0x00007029ABE0E760
00007029abfcea17  jmp 0x00007029ABFCE6F1
00007029abfcea1c  call 0x00007029ABE0D4E0
00007029abfcea21  jmp 0x00007029ABFCE6FC
00007029abfcea26  call 0x00007029ABE0C260
00007029abfcea2b  jmp 0x00007029ABFCE707
00007029abfcea30  call 0x00007029ABE0AFE0
00007029abfcea35  jmp 0x00007029ABFCE71D
00007029abfcea3a  call 0x00007029ABDFF540
00007029abfcea3f  jmp 0x00007029ABFCE728
00007029abfcea44  call 0x00007029ABE0E880
00007029abfcea49  jmp 0x00007029ABFCE733
00007029abfcea4e  call 0x00007029ABE0D600
00007029abfcea53  jmp 0x00007029ABFCE73E
00007029abfcea58  call 0x00007029ABE0C380
00007029abfcea5d  jmp 0x00007029ABFCE749
00007029abfcea62  call 0x00007029ABE0D4E0
00007029abfcea67  jmp 0x00007029ABFCE754
00007029abfcea6c  call 0x00007029ABE0C260
00007029abfcea71  jmp 0x00007029ABFCE75F
00007029abfcea76  call 0x00007029ABDFF540
00007029abfcea7b  jmp 0x00007029ABFCE76A
00007029abfcea80  call 0x00007029ABE0E880
00007029abfcea85  jmp 0x00007029ABFCE775
00007029abfcea8a  call 0x00007029ABE0B100
00007029abfcea8f  jmp 0x00007029ABFCE780
00007029abfcea94  call 0x00007029ABE0D600
00007029abfcea99  jmp 0x00007029ABFCE78B
00007029abfcea9e  call 0x00007029ABDFF430
00007029abfceaa3  jmp 0x00007029ABFCE796
00007029abfceaa8  call 0x00007029ABE0E760
00007029abfceaad  jmp 0x00007029ABFCE7A1
00007029abfceab2  call 0x00007029ABE0C380
00007029abfceab7  jmp 0x00007029ABFCE7AC
00007029abfceabc  call 0x00007029ABDFF540
00007029abfceac1  jmp 0x00007029ABFCE7B7
00007029abfceac6  call 0x00007029ABDFF430
00007029abfceacb  jmp 0x00007029ABFCE7C2
00007029abfcead0  call 0x00007029ABE0D4E0
00007029abfcead5  jmp 0x00007029ABFCE7CD
00007029abfceada  call 0x00007029ABE0E880
00007029abfceadf  jmp 0x00007029ABFCE7E0
00007029abfceae4  call 0x00007029ABDFF540
00007029abfceae9  jmp 0x00007029ABFCE7EB
00007029abfceaee  call 0x00007029ABDFF430
00007029abfceaf3  jmp 0x00007029ABFCE7F6
00007029abfceaf8  call 0x00007029ABE0E760
00007029abfceafd  jmp 0x00007029ABFCE801
00007029abfceb02  call 0x00007029ABE0D600
00007029abfceb07  jmp 0x00007029ABFCE81F
00007029abfceb0c  call 0x00007029ABDFF540
00007029abfceb11  jmp 0x00007029ABFCE82A
00007029abfceb16  call 0x00007029ABDFF430
00007029abfceb1b  jmp 0x00007029ABFCE835
00007029abfceb20  call 0x00007029ABE0D4E0
00007029abfceb25  jmp 0x00007029ABFCE840
00007029abfceb2a  call 0x00007029ABE0BC20
00007029abfceb2f  jmp 0x00007029ABFCE85B
00007029abfceb34  call 0x00007029ABE0E880
00007029abfceb39  jmp 0x00007029ABFCE866
00007029abfceb3e  call 0x00007029ABDFF540
00007029abfceb43  jmp 0x00007029ABFCE871
00007029abfceb48  call 0x00007029ABDFF430
00007029abfceb4d  jmp 0x00007029ABFCE87C
00007029abfceb52  call 0x00007029ABE0B720
00007029abfceb57  jmp 0x00007029ABFCE886
00007029abfceb5c  call 0x00007029ABE0D600
00007029abfceb61  jmp 0x00007029ABFCE89E
00007029abfceb66  call 0x00007029ABDFF540
00007029abfceb6b  jmp 0x00007029ABFCE8A9
00007029abfceb70  call 0x00007029ABDFF430
00007029abfceb75  jmp 0x00007029ABFCE8B4
00007029abfceb7a  call 0x00007029ABEB4CB0
00007029abfceb7f  jmp 0x00007029ABFCE8C4
00007029abfceb84  call 0x00007029ABE0E760
00007029abfceb89  jmp 0x00007029ABFCE8CF
00007029abfceb8e  call 0x00007029ABE0D4E0
00007029abfceb93  jmp 0x00007029ABFCE8DA
00007029abfceb98  call 0x00007029ABDFF540
00007029abfceb9d  jmp 0x00007029ABFCE8E4
00007029abfceba2  call 0x00007029ABE0BAE0
00007029abfceba7  jmp 0x00007029ABFCE8F4
00007029abfcebac  call 0x00007029ABE0E880
00007029abfcebb1  jmp 0x00007029ABFCE8FE
00007029abfcebb6  call 0x00007029ABE0D600
00007029abfcebbb  jmp 0x00007029ABFCE908
00007029abfcebc0  call 0x00007029ABDFF430
00007029abfcebc5  jmp 0x00007029ABFCE913
00007029abfcebca  call 0x00007029ABE0E760
00007029abfcebcf  jmp 0x00007029ABFCE91E
00007029abfcebd4  call 0x00007029ABED6600
00007029abfcebd9  jmp 0x00007029ABFCE92C
00007029abfcebde  call 0x00007029ABE0E880
00007029abfcebe3  jmp 0x00007029ABFCE936
00007029abfcebe8  call 0x00007029ABDFF430
00007029abfcebed  jmp 0x00007029ABFCE941
00007029abfcebf2  call 0x00007029ABE0E760
00007029abfcebf7  jmp 0x00007029ABFCE94C
00007029abfcebfc  call 0x00007029ABDFF540
00007029abfcec01  jmp 0x00007029ABFCE966
00007029abfcec06  call 0x00007029ABE0E880
00007029abfcec0b  jmp 0x00007029ABFCE970
00007029abfcec10  int3
00007029abfcec11  nop [rax+rax*1], ax
00007029abfcec1a  nop [rax+rax*1], ax
00007029abfcec20  mov rax, [r15]
00007029abfcec23  lea r14, [rax+0x20]
00007029abfcec27  mov r12, [r13+r14*1]
00007029abfcec2c  mov r14, [r15+0x10]
00007029abfcec30  lea r11, [r12+r14*1]
00007029abfcec34  mov [r15+0x40], r11
00007029abfcec38  lea r12, [rax+0x20]
00007029abfcec3c  mov [r13+r12*1], r11
00007029abfcec41  test r14, r14
00007029abfcec44  setz r14b
00007029abfcec48  movzx r14, r14b
00007029abfcec4c  mov [rsp+0x414], r14b
00007029abfcec54  cmp byte ptr [rsp+0x414], 0x00
00007029abfcec5c  jz 0x00007029ABFCEC8E
00007029abfcec5e  cmp dword ptr [r15+0x318], 0x00
00007029abfcec66  mov eax, 0x4105B0
00007029abfcec6b  mov [r15+0x100], rax
00007029abfcec72  jz 0x00007029ABDFE0A0
00007029abfcec78  nop [rax+rax*1], eax
00007029abfcec7d  mov eax, 0x4105B0
00007029abfcec82  mov [r15+0x100], rax
00007029abfcec89  jmp 0x00007029ABDFE110
00007029abfcec8e  cmp dword ptr [r15+0x318], 0x00
00007029abfcec96  jz 0x00007029ABFCECE0
00007029abfcec9c  nop [rax+rax*1], ax
00007029abfceca5  nop [rax+rax*1], eax
00007029abfcecad  mov eax, 0x410348
00007029abfcecb2  mov [r15+0x100], rax
00007029abfcecb9  jmp 0x00007029ABDFE110
00007029abfcecbe  int3
00007029abfcecbf  call 0x00007029ABEE27E0
00007029abfcecc4  jmp 0x00007029ABFCEC2C
00007029abfcecc9  call 0x00007029ABEC0860
00007029abfcecce  jmp 0x00007029ABFCEC41
00007029abfcecd3  int3
00007029abfcecd4  nop [rax+rax*1], ax
00007029abfcecdd  nop [rax], eax
00007029abfcece0  mov rax, [r15+0xF8]
00007029abfcece7  lea r14, [rax-0x150]
00007029abfcecee  mov [r15+0xF8], r14
00007029abfcecf5  mov rax, [r15]
00007029abfcecf8  lea r12, [rax+0x68]
00007029abfcecfc  mov r11, [r13+r12*1]
00007029abfced01  mov [r15+0x88], r11
00007029abfced08  lea r12, [rax+0x28]
00007029abfced0c  mov [r15+0x40], r12
00007029abfced10  mov [r15+0x48], r14
00007029abfced14  mov qword ptr [r15+0x50], 0x420758
00007029abfced1c  lea rax, [r14+0x100]
00007029abfced23  mov r12, [r15+0xE8]
00007029abfced2a  mov r11, [r15+0xD8]
00007029abfced31  mov [r13+rax*1], r12
00007029abfced36  lea rax, [r14+0x108]
00007029abfced3d  mov [r13+rax*1], r11
00007029abfced42  lea rax, [r14+0x110]
00007029abfced49  mov r12, [r15+0xD0]
00007029abfced50  mov r11, [r15+0xC8]
00007029abfced57  mov [r13+rax*1], r12
00007029abfced5c  lea rax, [r14+0x118]
00007029abfced63  mov [r13+rax*1], r11
00007029abfced68  lea rax, [r14+0x120]
00007029abfced6f  mov r12, [r15+0xC0]
00007029abfced76  mov r11, [r15+0xB8]
00007029abfced7d  mov [r13+rax*1], r12
00007029abfced82  lea rax, [r14+0x128]
00007029abfced89  mov [r13+rax*1], r11
00007029abfced8e  lea rax, [r14+0x130]
00007029abfced95  mov r12, [r15+0xB0]
00007029abfced9c  mov r11, [r15+0xA8]
00007029abfceda3  mov [r13+rax*1], r12
00007029abfceda8  lea rax, [r14+0x138]
00007029abfcedaf  mov [r13+rax*1], r11
00007029abfcedb4  lea rax, [r14+0x140]
00007029abfcedbb  mov r12, [r15+0xA0]
00007029abfcedc2  mov r11, [r15+0x98]
00007029abfcedc9  mov [r13+rax*1], r12
00007029abfcedce  lea rax, [r14+0x148]
00007029abfcedd5  mov [r13+rax*1], r11
00007029abfcedda  cmp dword ptr [r15+0x318], 0x00
00007029abfcede2  jz 0x00007029ABFCEE80
00007029abfcede8  nop [rax+rax*1], ax
00007029abfcedf1  nop [rax+rax*1], eax
00007029abfcedf9  mov eax, 0x410380
00007029abfcedfe  mov [r15+0x100], rax
00007029abfcee05  jmp 0x00007029ABDFE110
00007029abfcee0a  int3
00007029abfcee0b  call 0x00007029ABEC0370
00007029abfcee10  jmp 0x00007029ABFCED01
00007029abfcee15  call 0x00007029ABE0BC20
00007029abfcee1a  jmp 0x00007029ABFCED36
00007029abfcee1f  call 0x00007029ABE0A9A0
00007029abfcee24  jmp 0x00007029ABFCED42
00007029abfcee29  call 0x00007029ABE0BC20
00007029abfcee2e  jmp 0x00007029ABFCED5C
00007029abfcee33  call 0x00007029ABE0A9A0
00007029abfcee38  jmp 0x00007029ABFCED68
00007029abfcee3d  call 0x00007029ABE0BC20
00007029abfcee42  jmp 0x00007029ABFCED82
00007029abfcee47  call 0x00007029ABE0A9A0
00007029abfcee4c  jmp 0x00007029ABFCED8E
00007029abfcee51  call 0x00007029ABE0BC20
00007029abfcee56  jmp 0x00007029ABFCEDA8
00007029abfcee5b  call 0x00007029ABE0A9A0
00007029abfcee60  jmp 0x00007029ABFCEDB4
00007029abfcee65  call 0x00007029ABE0BC20
00007029abfcee6a  jmp 0x00007029ABFCEDCE
00007029abfcee6f  call 0x00007029ABE0A9A0
00007029abfcee74  jmp 0x00007029ABFCEDDA
00007029abfcee79  int3
00007029abfcee7a  nop [rax+rax*1], ax
00007029abfcee80  mov rax, [r15+0x08]
00007029abfcee84  movzx r14d, byte ptr [r13+rax*1]
00007029abfcee8a  movzx r14d, r14b
00007029abfcee8e  mov [rsp+0x10], r14d
00007029abfcee93  mov r14d, r14d
00007029abfcee96  mov [r15+0x58], r14
00007029abfcee9a  lea r14, [rax+0x01]
00007029abfcee9e  mov [r15+0x08], r14
00007029abfceea2  mov rax, [r15+0x88]
00007029abfceea9  lea r14, [rax+0x01]
00007029abfceead  mov r12, [r15]
00007029abfceeb0  lea r11, [r12+0x68]
00007029abfceeb5  mov [r13+r11*1], r14
00007029abfceeba  lea r14, [r12+rax*1]
00007029abfceebe  mov [r15+0x60], r14
00007029abfceec2  lea rax, [r14+0x28]
00007029abfceec6  mov r11d, [rsp+0x10]
00007029abfceecb  movzx r14d, r11b
00007029abfceecf  mov [r13+rax*1], r14b
00007029abfceed4  lea rax, [r12+0x68]
00007029abfceed9  mov r14, [r13+rax*1]
00007029abfceede  mov [r15+0x88], r14
00007029abfceee5  xor eax, eax
00007029abfceee7  mov r12d, 0x40
00007029abfceeed  cmp r14, r12
00007029abfceef0  cmc
00007029abfceef1  lahf
00007029abfceef2  seto al
00007029abfceef5  mov [r15+0x108], eax
00007029abfceefc  mov eax, [r15+0x108]
00007029abfcef03  sahf
00007029abfcef04  jnz 0x00007029ABFCEF36
00007029abfcef06  cmp dword ptr [r15+0x318], 0x00
00007029abfcef0e  jz 0x00007029ABFCF020
00007029abfcef14  nop [rax+rax*1], ax
00007029abfcef1d  nop [rax+rax*1], eax
00007029abfcef25  mov eax, 0x4103A0
00007029abfcef2a  mov [r15+0x100], rax
00007029abfcef31  jmp 0x00007029ABDFE110
00007029abfcef36  cmp dword ptr [r15+0x318], 0x00
00007029abfcef3e  jz 0x00007029ABFCEF90
00007029abfcef44  nop [rax+rax*1], ax
00007029abfcef4d  nop [rax+rax*1], eax
00007029abfcef55  mov eax, 0x410378
00007029abfcef5a  mov [r15+0x100], rax
00007029abfcef61  jmp 0x00007029ABDFE110
00007029abfcef66  int3
00007029abfcef67  call 0x00007029ABE0D860
00007029abfcef6c  jmp 0x00007029ABFCEE8A
00007029abfcef71  call 0x00007029ABEB36E0
00007029abfcef76  jmp 0x00007029ABFCEEBA
00007029abfcef7b  call 0x00007029ABE0DD60
00007029abfcef80  jmp 0x00007029ABFCEED4
00007029abfcef85  call 0x00007029ABE0DC20
00007029abfcef8a  jmp 0x00007029ABFCEEDE
00007029abfcef8f  int3
00007029abfcef90  mov rax, [r15+0x10]
00007029abfcef94  lea r14, [rax-0x01]
00007029abfcef98  mov [r15+0x10], r14
00007029abfcef9c  test r14, r14
00007029abfcef9f  setz r14b
00007029abfcefa3  movzx r14, r14b
00007029abfcefa7  mov [rsp+0x414], r14b
00007029abfcefaf  cmp byte ptr [rsp+0x414], 0x00
00007029abfcefb7  jz 0x00007029ABFCEFE9
00007029abfcefb9  cmp dword ptr [r15+0x318], 0x00
00007029abfcefc1  jz 0x00007029ABFD0520
00007029abfcefc7  nop [rax+rax*1], ax
00007029abfcefd0  nop [rax+rax*1], eax
00007029abfcefd8  mov eax, 0x410598
00007029abfcefdd  mov [r15+0x100], rax
00007029abfcefe4  jmp 0x00007029ABDFE110
00007029abfcefe9  cmp dword ptr [r15+0x318], 0x00
00007029abfceff1  jz 0x00007029ABFCEE80
00007029abfceff7  nop [rax+rax*1], ax
00007029abfcf000  nop [rax+rax*1], eax
00007029abfcf008  mov eax, 0x410380
00007029abfcf00d  mov [r15+0x100], rax
00007029abfcf014  jmp 0x00007029ABDFE110
00007029abfcf019  int3
00007029abfcf01a  int3
00007029abfcf01b  nop [rax+rax*1], eax
00007029abfcf020  mov rax, [r15+0x40]
00007029abfcf024  movzx r14d, byte ptr [r13+rax*1]
00007029abfcf02a  movaps xmm1, [r15+0x110]
00007029abfcf032  pinsrb xmm1, r14d, 0x00
00007029abfcf039  lea r14, [rax+0x01]
00007029abfcf03d  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf043  movaps xmm15, [r15+0x120]
00007029abfcf04b  pinsrb xmm15, r12d, 0x00
00007029abfcf052  lea r14, [rax+0x02]
00007029abfcf056  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf05c  movaps xmm14, [r15+0x130]
00007029abfcf064  pinsrb xmm14, r12d, 0x00
00007029abfcf06b  lea r14, [rax+0x03]
00007029abfcf06f  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf075  movaps xmm13, [r15+0x140]
00007029abfcf07d  pinsrb xmm13, r12d, 0x00
00007029abfcf084  lea r14, [rax+0x04]
00007029abfcf088  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf08e  pinsrb xmm1, r12d, 0x01
00007029abfcf095  lea r14, [rax+0x05]
00007029abfcf099  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf09f  pinsrb xmm15, r12d, 0x01
00007029abfcf0a6  lea r14, [rax+0x06]
00007029abfcf0aa  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf0b0  pinsrb xmm14, r12d, 0x01
00007029abfcf0b7  lea r14, [rax+0x07]
00007029abfcf0bb  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf0c1  pinsrb xmm13, r12d, 0x01
00007029abfcf0c8  lea r14, [rax+0x08]
00007029abfcf0cc  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf0d2  pinsrb xmm1, r12d, 0x02
00007029abfcf0d9  lea r14, [rax+0x09]
00007029abfcf0dd  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf0e3  pinsrb xmm15, r12d, 0x02
00007029abfcf0ea  lea r14, [rax+0x0A]
00007029abfcf0ee  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf0f4  pinsrb xmm14, r12d, 0x02
00007029abfcf0fb  lea r14, [rax+0x0B]
00007029abfcf0ff  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf105  pinsrb xmm13, r12d, 0x02
00007029abfcf10c  lea r14, [rax+0x0C]
00007029abfcf110  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf116  pinsrb xmm1, r12d, 0x03
00007029abfcf11d  lea r14, [rax+0x0D]
00007029abfcf121  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf127  pinsrb xmm15, r12d, 0x03
00007029abfcf12e  lea r14, [rax+0x0E]
00007029abfcf132  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf138  pinsrb xmm14, r12d, 0x03
00007029abfcf13f  lea r14, [rax+0x0F]
00007029abfcf143  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf149  pinsrb xmm13, r12d, 0x03
00007029abfcf150  lea r14, [rax+0x10]
00007029abfcf154  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf15a  pinsrb xmm1, r12d, 0x04
00007029abfcf161  lea r14, [rax+0x11]
00007029abfcf165  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf16b  pinsrb xmm15, r12d, 0x04
00007029abfcf172  lea r14, [rax+0x12]
00007029abfcf176  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf17c  pinsrb xmm14, r12d, 0x04
00007029abfcf183  lea r14, [rax+0x13]
00007029abfcf187  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf18d  pinsrb xmm13, r12d, 0x04
00007029abfcf194  lea r14, [rax+0x14]
00007029abfcf198  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf19e  pinsrb xmm1, r12d, 0x05
00007029abfcf1a5  lea r14, [rax+0x15]
00007029abfcf1a9  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf1af  pinsrb xmm15, r12d, 0x05
00007029abfcf1b6  lea r14, [rax+0x16]
00007029abfcf1ba  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf1c0  pinsrb xmm14, r12d, 0x05
00007029abfcf1c7  lea r14, [rax+0x17]
00007029abfcf1cb  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf1d1  pinsrb xmm13, r12d, 0x05
00007029abfcf1d8  lea r14, [rax+0x18]
00007029abfcf1dc  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf1e2  pinsrb xmm1, r12d, 0x06
00007029abfcf1e9  lea r14, [rax+0x19]
00007029abfcf1ed  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf1f3  pinsrb xmm15, r12d, 0x06
00007029abfcf1fa  lea r14, [rax+0x1A]
00007029abfcf1fe  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf204  pinsrb xmm14, r12d, 0x06
00007029abfcf20b  lea r14, [rax+0x1B]
00007029abfcf20f  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf215  pinsrb xmm13, r12d, 0x06
00007029abfcf21c  lea r14, [rax+0x1C]
00007029abfcf220  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf226  pinsrb xmm1, r12d, 0x07
00007029abfcf22d  lea r14, [rax+0x1D]
00007029abfcf231  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf237  pinsrb xmm15, r12d, 0x07
00007029abfcf23e  lea r14, [rax+0x1E]
00007029abfcf242  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf248  pinsrb xmm14, r12d, 0x07
00007029abfcf24f  lea r14, [rax+0x1F]
00007029abfcf253  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf259  pinsrb xmm13, r12d, 0x07
00007029abfcf260  lea r14, [rax+0x20]
00007029abfcf264  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf26a  pinsrb xmm1, r12d, 0x08
00007029abfcf271  lea r14, [rax+0x21]
00007029abfcf275  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf27b  pinsrb xmm15, r12d, 0x08
00007029abfcf282  lea r14, [rax+0x22]
00007029abfcf286  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf28c  pinsrb xmm14, r12d, 0x08
00007029abfcf293  lea r14, [rax+0x23]
00007029abfcf297  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf29d  pinsrb xmm13, r12d, 0x08
00007029abfcf2a4  lea r14, [rax+0x24]
00007029abfcf2a8  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf2ae  pinsrb xmm1, r12d, 0x09
00007029abfcf2b5  lea r14, [rax+0x25]
00007029abfcf2b9  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf2bf  pinsrb xmm15, r12d, 0x09
00007029abfcf2c6  lea r14, [rax+0x26]
00007029abfcf2ca  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf2d0  pinsrb xmm14, r12d, 0x09
00007029abfcf2d7  lea r14, [rax+0x27]
00007029abfcf2db  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf2e1  pinsrb xmm13, r12d, 0x09
00007029abfcf2e8  lea r14, [rax+0x28]
00007029abfcf2ec  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf2f2  pinsrb xmm1, r12d, 0x0A
00007029abfcf2f9  lea r14, [rax+0x29]
00007029abfcf2fd  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf303  pinsrb xmm15, r12d, 0x0A
00007029abfcf30a  lea r14, [rax+0x2A]
00007029abfcf30e  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf314  pinsrb xmm14, r12d, 0x0A
00007029abfcf31b  lea r14, [rax+0x2B]
00007029abfcf31f  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf325  pinsrb xmm13, r12d, 0x0A
00007029abfcf32c  lea r14, [rax+0x2C]
00007029abfcf330  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf336  pinsrb xmm1, r12d, 0x0B
00007029abfcf33d  lea r14, [rax+0x2D]
00007029abfcf341  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf347  pinsrb xmm15, r12d, 0x0B
00007029abfcf34e  lea r14, [rax+0x2E]
00007029abfcf352  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf358  pinsrb xmm14, r12d, 0x0B
00007029abfcf35f  lea r14, [rax+0x2F]
00007029abfcf363  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf369  pinsrb xmm13, r12d, 0x0B
00007029abfcf370  lea r14, [rax+0x30]
00007029abfcf374  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf37a  pinsrb xmm1, r12d, 0x0C
00007029abfcf381  lea r14, [rax+0x31]
00007029abfcf385  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf38b  pinsrb xmm15, r12d, 0x0C
00007029abfcf392  lea r14, [rax+0x32]
00007029abfcf396  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf39c  pinsrb xmm14, r12d, 0x0C
00007029abfcf3a3  lea r14, [rax+0x33]
00007029abfcf3a7  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf3ad  pinsrb xmm13, r12d, 0x0C
00007029abfcf3b4  lea r14, [rax+0x34]
00007029abfcf3b8  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf3be  pinsrb xmm1, r12d, 0x0D
00007029abfcf3c5  lea r14, [rax+0x35]
00007029abfcf3c9  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf3cf  pinsrb xmm15, r12d, 0x0D
00007029abfcf3d6  lea r14, [rax+0x36]
00007029abfcf3da  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf3e0  pinsrb xmm14, r12d, 0x0D
00007029abfcf3e7  lea r14, [rax+0x37]
00007029abfcf3eb  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf3f1  pinsrb xmm13, r12d, 0x0D
00007029abfcf3f8  lea r14, [rax+0x38]
00007029abfcf3fc  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf402  pinsrb xmm1, r12d, 0x0E
00007029abfcf409  lea r14, [rax+0x39]
00007029abfcf40d  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf413  pinsrb xmm15, r12d, 0x0E
00007029abfcf41a  lea r14, [rax+0x3A]
00007029abfcf41e  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf424  pinsrb xmm14, r12d, 0x0E
00007029abfcf42b  lea r14, [rax+0x3B]
00007029abfcf42f  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf435  pinsrb xmm13, r12d, 0x0E
00007029abfcf43c  lea r14, [rax+0x3C]
00007029abfcf440  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf446  pinsrb xmm1, r12d, 0x0F
00007029abfcf44d  movaps [r15+0x110], xmm1
00007029abfcf455  lea r14, [rax+0x3D]
00007029abfcf459  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf45f  pinsrb xmm15, r12d, 0x0F
00007029abfcf466  movaps [r15+0x120], xmm15
00007029abfcf46e  lea r14, [rax+0x3E]
00007029abfcf472  movzx r12d, byte ptr [r13+r14*1]
00007029abfcf478  pinsrb xmm14, r12d, 0x0F
00007029abfcf47f  movaps [r15+0x130], xmm14
00007029abfcf487  lea r14, [rax+0x3F]
00007029abfcf48b  movzx eax, byte ptr [r13+r14*1]
00007029abfcf491  pinsrb xmm13, eax, 0x0F
00007029abfcf498  movaps [r15+0x140], xmm13
00007029abfcf4a0  movq xmm1, qword ptr [r15+0x120]
00007029abfcf4a9  pmovzxbw xmm1, xmm1
00007029abfcf4ae  psllw xmm1, 0x00
00007029abfcf4b3  movaps [r15+0x150], xmm1
00007029abfcf4bb  movq xmm1, qword ptr [r15+0x130]
00007029abfcf4c4  pmovzxbw xmm1, xmm1
00007029abfcf4c9  psllw xmm1, 0x00
00007029abfcf4ce  movaps [r15+0x160], xmm1
00007029abfcf4d6  movq xmm1, qword ptr [r15+0x110]
00007029abfcf4df  pmovzxbw xmm1, xmm1
00007029abfcf4e4  psllw xmm1, 0x00
00007029abfcf4e9  movaps [r15+0x170], xmm1
00007029abfcf4f1  movaps xmm15, [r15+0x110]
00007029abfcf4f9  pextrq rax, xmm15, 0x01
00007029abfcf500  movq xmm15, rax
00007029abfcf505  pmovzxbw xmm15, xmm15
00007029abfcf50b  psllw xmm15, 0x00
00007029abfcf511  movaps [r15+0x180], xmm15
00007029abfcf519  movaps xmm14, [r15+0x120]
00007029abfcf521  pextrq rax, xmm14, 0x01
00007029abfcf528  movq xmm14, rax
00007029abfcf52d  pmovzxbw xmm14, xmm14
00007029abfcf533  psllw xmm14, 0x00
00007029abfcf539  movaps [r15+0x210], xmm14
00007029abfcf541  movaps xmm13, [r15+0x130]
00007029abfcf549  pextrq rax, xmm13, 0x01
00007029abfcf550  movq xmm13, rax
00007029abfcf555  pmovzxbw xmm13, xmm13
00007029abfcf55b  psllw xmm13, 0x00
00007029abfcf561  movaps [r15+0x220], xmm13
00007029abfcf569  movq xmm12, qword ptr [r15+0x140]
00007029abfcf572  pmovzxbw xmm12, xmm12
00007029abfcf578  psllw xmm12, 0x00
00007029abfcf57e  movaps [r15+0x250], xmm12
00007029abfcf586  movaps xmm12, [r15+0x140]
00007029abfcf58e  pextrq rax, xmm12, 0x01
00007029abfcf595  movq xmm12, rax
00007029abfcf59a  pmovzxbw xmm12, xmm12
00007029abfcf5a0  psllw xmm12, 0x00
00007029abfcf5a6  movaps [r15+0x110], xmm12
00007029abfcf5ae  movq xmm11, qword ptr [r15+0x150]
00007029abfcf5b7  pmovzxwd xmm11, xmm11
00007029abfcf5bd  pslld xmm11, 0x10
00007029abfcf5c3  movq xmm10, qword ptr [r15+0x160]
00007029abfcf5cc  pmovzxwd xmm10, xmm10
00007029abfcf5d2  pslld xmm10, 0x08
00007029abfcf5d8  pextrq rax, xmm1, 0x01
00007029abfcf5df  movq xmm1, rax
00007029abfcf5e4  pmovzxwd xmm1, xmm1
00007029abfcf5e9  pslld xmm1, 0x00
00007029abfcf5ee  movaps [r15+0x260], xmm1
00007029abfcf5f6  pextrq rax, xmm15, 0x01
00007029abfcf5fd  movq xmm15, rax
00007029abfcf602  pmovzxwd xmm15, xmm15
00007029abfcf608  pslld xmm15, 0x00
00007029abfcf60e  movaps [r15+0x270], xmm15
00007029abfcf616  movq xmm9, qword ptr [r15+0x170]
00007029abfcf61f  pmovzxwd xmm9, xmm9
00007029abfcf625  pslld xmm9, 0x00
00007029abfcf62b  pextrq rax, xmm14, 0x01
00007029abfcf632  movq xmm14, rax
00007029abfcf637  pmovzxwd xmm14, xmm14
00007029abfcf63d  pslld xmm14, 0x10
00007029abfcf643  movaps [r15+0x280], xmm14
00007029abfcf64b  movq xmm8, qword ptr [r15+0x180]
00007029abfcf654  pmovzxwd xmm8, xmm8
00007029abfcf65a  pslld xmm8, 0x00
00007029abfcf660  movq xmm7, qword ptr [r15+0x210]
00007029abfcf669  pmovzxwd xmm7, xmm7
00007029abfcf66e  pslld xmm7, 0x10
00007029abfcf673  movaps xmm6, [r15+0x150]
00007029abfcf67b  pextrq rax, xmm6, 0x01
00007029abfcf682  movq xmm6, rax
00007029abfcf687  pmovzxwd xmm6, xmm6
00007029abfcf68c  pslld xmm6, 0x10
00007029abfcf691  por xmm11, xmm10
00007029abfcf696  movaps [r15+0x230], xmm11
00007029abfcf69e  pextrq rax, xmm13, 0x01
00007029abfcf6a5  movq xmm13, rax
00007029abfcf6aa  pmovzxwd xmm13, xmm13
00007029abfcf6b0  pslld xmm13, 0x08
00007029abfcf6b6  movaps [r15+0x240], xmm13
00007029abfcf6be  movq xmm10, qword ptr [r15+0x220]
00007029abfcf6c7  pmovzxwd xmm10, xmm10
00007029abfcf6cd  pslld xmm10, 0x08
00007029abfcf6d3  movaps xmm5, [r15+0x160]
00007029abfcf6db  pextrq rax, xmm5, 0x01
00007029abfcf6e2  movq xmm5, rax
00007029abfcf6e7  pmovzxwd xmm5, xmm5
00007029abfcf6ec  pslld xmm5, 0x08
00007029abfcf6f1  pslld xmm9, 0x18
00007029abfcf6f7  pslld xmm15, 0x18
00007029abfcf6fd  pslld xmm8, 0x18
00007029abfcf703  movq xmm4, qword ptr [r15+0x250]
00007029abfcf70c  pmovzxwd xmm4, xmm4
00007029abfcf711  pslld xmm4, 0x00
00007029abfcf716  por xmm14, xmm13
00007029abfcf71b  por xmm7, xmm10
00007029abfcf720  movaps [r15+0x210], xmm7
00007029abfcf728  pslld xmm1, 0x18
00007029abfcf72d  movaps [r15+0x220], xmm1
00007029abfcf735  por xmm6, xmm5
00007029abfcf739  por xmm11, xmm9
00007029abfcf73e  movaps [r15+0x160], xmm11
00007029abfcf746  pextrq rax, xmm12, 0x01
00007029abfcf74d  movq xmm13, rax
00007029abfcf752  pmovzxwd xmm13, xmm13
00007029abfcf758  pslld xmm13, 0x00
00007029abfcf75e  movaps [r15+0x170], xmm13
00007029abfcf766  movq xmm12, qword ptr [r15+0x110]
00007029abfcf76f  pmovzxwd xmm12, xmm12
00007029abfcf775  pslld xmm12, 0x00
00007029abfcf77b  por xmm14, xmm15
00007029abfcf780  por xmm7, xmm8
00007029abfcf785  movaps xmm15, [r15+0x250]
00007029abfcf78d  pextrq rax, xmm15, 0x01
00007029abfcf794  movq xmm15, rax
00007029abfcf799  pmovzxwd xmm15, xmm15
00007029abfcf79f  pslld xmm15, 0x00
00007029abfcf7a5  movaps [r15+0x180], xmm15
00007029abfcf7ad  por xmm6, xmm1
00007029abfcf7b1  movaps [r15+0x150], xmm6
00007029abfcf7b9  por xmm11, xmm4
00007029abfcf7be  movaps [r15+0x140], xmm11
00007029abfcf7c6  por xmm7, xmm12
00007029abfcf7cb  movaps [r15+0x110], xmm7
00007029abfcf7d3  por xmm14, xmm13
00007029abfcf7d8  movaps [r15+0x120], xmm14
00007029abfcf7e0  por xmm6, xmm15
00007029abfcf7e5  movaps [r15+0x130], xmm6
00007029abfcf7ed  mov rax, [r15+0xF8]
00007029abfcf7f4  lea r14, [rax+0x20]
00007029abfcf7f8  movups [r13+r14*1], xmm7
00007029abfcf7fe  lea r14, [rax+0x30]
00007029abfcf802  movups [r13+r14*1], xmm14
00007029abfcf808  movups [r13+rax*1], xmm11
00007029abfcf80e  lea r14, [rax+0x10]
00007029abfcf812  movups [r13+r14*1], xmm6
00007029abfcf818  mov r14d, [r13+rax*1]
00007029abfcf81d  mov rax, [r15+0x48]
00007029abfcf821  mov [r15+0x68], rax
00007029abfcf825  mov qword ptr [r15+0x58], 0x04
00007029abfcf82d  lea r12, [rax+0x04]
00007029abfcf831  mov r11d, [r13+r12*1]
00007029abfcf836  mov [rsp+0x10], r11d
00007029abfcf83b  mov r11d, r11d
00007029abfcf83e  mov [r15+0x70], r11
00007029abfcf842  lea r12, [rax+0x38]
00007029abfcf846  mov r11d, [r13+r12*1]
00007029abfcf84b  lea r12, [rax+0x24]
00007029abfcf84f  mov r10d, [r13+r12*1]
00007029abfcf854  mov [rsp+0x20], r10d
00007029abfcf859  mov r10d, r10d
00007029abfcf85c  mov [r15+0x90], r10
00007029abfcf863  mov [rsp+0x30], rax
00007029abfcf868  xor eax, eax
00007029abfcf86a  mov r12d, 0x04
00007029abfcf870  mov r10d, 0xC0
00007029abfcf876  cmp r12, r10
00007029abfcf879  cmc
00007029abfcf87a  lahf
00007029abfcf87b  seto al
00007029abfcf87e  mov [r15+0x108], eax
00007029abfcf885  mov eax, [rsp+0x10]
00007029abfcf889  mov r12d, [rsp+0x10]
00007029abfcf88e  shrd eax, r12d, 0x07
00007029abfcf893  mov [rsp+0x10], r11d
00007029abfcf898  mov r10d, [rsp+0x10]
00007029abfcf89d  shrd r11d, r10d, 0x11
00007029abfcf8a2  mov r9d, [rsp+0x20]
00007029abfcf8a7  lea r8d, [r9d+r14d*1]
00007029abfcf8ac  rorx r14d, r12d, 0x12
00007029abfcf8b2  xor eax, r14d
00007029abfcf8b5  rorx r14d, r10d, 0x13
00007029abfcf8bb  xor r11d, r14d
00007029abfcf8be  mov [rsp+0x10], r11d
00007029abfcf8c3  mov r11d, r11d
00007029abfcf8c6  mov [r15+0x88], r11
00007029abfcf8cd  mov [rsp+0x20], r12d
00007029abfcf8d2  shr r12d, 0x03
00007029abfcf8d6  xor eax, r12d
00007029abfcf8d9  mov [rsp+0x40], eax
00007029abfcf8dd  mov eax, eax
00007029abfcf8df  mov [r15+0x80], rax
00007029abfcf8e6  shr r10d, 0x0A
00007029abfcf8ea  mov eax, [rsp+0x10]
00007029abfcf8ee  xor eax, r10d
00007029abfcf8f1  mov [rsp+0x10], eax
00007029abfcf8f5  mov eax, eax
00007029abfcf8f7  mov [r15+0x78], rax
00007029abfcf8fb  mov eax, [rsp+0x40]
00007029abfcf8ff  lea r14d, [r8d+eax*1]
00007029abfcf904  mov eax, [rsp+0x10]
00007029abfcf908  lea r12d, [r14d+eax*1]
00007029abfcf90d  mov rax, [rsp+0x30]
00007029abfcf912  lea r14, [rax+0x40]
00007029abfcf916  mov [r13+r14*1], r12d
00007029abfcf91b  mov eax, [rsp+0x20]
00007029abfcf91f  mov eax, eax
00007029abfcf921  mov [r15+0x60], rax
00007029abfcf925  mov eax, [r15+0x108]
00007029abfcf92c  sahf
00007029abfcf92d  jnz 0x00007029ABFCF95F
00007029abfcf92f  cmp dword ptr [r15+0x318], 0x00
00007029abfcf937  jz 0x00007029ABFCFE20
00007029abfcf93d  nop [rax+rax*1], ax
00007029abfcf946  nop [rax+rax*1], eax
00007029abfcf94e  mov eax, 0x41049C
00007029abfcf953  mov [r15+0x100], rax
00007029abfcf95a  jmp 0x00007029ABDFE110
00007029abfcf95f  cmp dword ptr [r15+0x318], 0x00
00007029abfcf967  jz 0x00007029ABFCFC70
00007029abfcf96d  nop [rax+rax*1], ax
00007029abfcf976  nop [rax+rax*1], eax
00007029abfcf97e  mov eax, 0x410454
00007029abfcf983  mov [r15+0x100], rax
00007029abfcf98a  jmp 0x00007029ABDFE110
00007029abfcf98f  int3
00007029abfcf990  call 0x00007029ABE0D860
00007029abfcf995  jmp 0x00007029ABFCF02A
00007029abfcf99a  call 0x00007029ABEE2420
00007029abfcf99f  jmp 0x00007029ABFCF043
00007029abfcf9a4  call 0x00007029ABEE2420
00007029abfcf9a9  jmp 0x00007029ABFCF05C
00007029abfcf9ae  call 0x00007029ABEE2420
00007029abfcf9b3  jmp 0x00007029ABFCF075
00007029abfcf9b8  call 0x00007029ABEE2420
00007029abfcf9bd  jmp 0x00007029ABFCF08E
00007029abfcf9c2  call 0x00007029ABEE2420
00007029abfcf9c7  jmp 0x00007029ABFCF09F
00007029abfcf9cc  call 0x00007029ABEE2420
00007029abfcf9d1  jmp 0x00007029ABFCF0B0
00007029abfcf9d6  call 0x00007029ABEE2420
00007029abfcf9db  jmp 0x00007029ABFCF0C1
00007029abfcf9e0  call 0x00007029ABEE2420
00007029abfcf9e5  jmp 0x00007029ABFCF0D2
00007029abfcf9ea  call 0x00007029ABEE2420
00007029abfcf9ef  jmp 0x00007029ABFCF0E3
00007029abfcf9f4  call 0x00007029ABEE2420
00007029abfcf9f9  jmp 0x00007029ABFCF0F4
00007029abfcf9fe  call 0x00007029ABEE2420
00007029abfcfa03  jmp 0x00007029ABFCF105
00007029abfcfa08  call 0x00007029ABEE2420
00007029abfcfa0d  jmp 0x00007029ABFCF116
00007029abfcfa12  call 0x00007029ABEE2420
00007029abfcfa17  jmp 0x00007029ABFCF127
00007029abfcfa1c  call 0x00007029ABEE2420
00007029abfcfa21  jmp 0x00007029ABFCF138
00007029abfcfa26  call 0x00007029ABEE2420
00007029abfcfa2b  jmp 0x00007029ABFCF149
00007029abfcfa30  call 0x00007029ABEE2420
00007029abfcfa35  jmp 0x00007029ABFCF15A
00007029abfcfa3a  call 0x00007029ABEE2420
00007029abfcfa3f  jmp 0x00007029ABFCF16B
00007029abfcfa44  call 0x00007029ABEE2420
00007029abfcfa49  jmp 0x00007029ABFCF17C
00007029abfcfa4e  call 0x00007029ABEE2420
00007029abfcfa53  jmp 0x00007029ABFCF18D
00007029abfcfa58  call 0x00007029ABEE2420
00007029abfcfa5d  jmp 0x00007029ABFCF19E
00007029abfcfa62  call 0x00007029ABEE2420
00007029abfcfa67  jmp 0x00007029ABFCF1AF
00007029abfcfa6c  call 0x00007029ABEE2420
00007029abfcfa71  jmp 0x00007029ABFCF1C0
00007029abfcfa76  call 0x00007029ABEE2420
00007029abfcfa7b  jmp 0x00007029ABFCF1D1
00007029abfcfa80  call 0x00007029ABEE2420
00007029abfcfa85  jmp 0x00007029ABFCF1E2
00007029abfcfa8a  call 0x00007029ABEE2420
00007029abfcfa8f  jmp 0x00007029ABFCF1F3
00007029abfcfa94  call 0x00007029ABEE2420
00007029abfcfa99  jmp 0x00007029ABFCF204
00007029abfcfa9e  call 0x00007029ABEE2420
00007029abfcfaa3  jmp 0x00007029ABFCF215
00007029abfcfaa8  call 0x00007029ABEE2420
00007029abfcfaad  jmp 0x00007029ABFCF226
00007029abfcfab2  call 0x00007029ABEE2420
00007029abfcfab7  jmp 0x00007029ABFCF237
00007029abfcfabc  call 0x00007029ABEE2420
00007029abfcfac1  jmp 0x00007029ABFCF248
00007029abfcfac6  call 0x00007029ABEE2420
00007029abfcfacb  jmp 0x00007029ABFCF259
00007029abfcfad0  call 0x00007029ABEE2420
00007029abfcfad5  jmp 0x00007029ABFCF26A
00007029abfcfada  call 0x00007029ABEE2420
00007029abfcfadf  jmp 0x00007029ABFCF27B
00007029abfcfae4  call 0x00007029ABEE2420
00007029abfcfae9  jmp 0x00007029ABFCF28C
00007029abfcfaee  call 0x00007029ABEE2420
00007029abfcfaf3  jmp 0x00007029ABFCF29D
00007029abfcfaf8  call 0x00007029ABEE2420
00007029abfcfafd  jmp 0x00007029ABFCF2AE
00007029abfcfb02  call 0x00007029ABEE2420
00007029abfcfb07  jmp 0x00007029ABFCF2BF
00007029abfcfb0c  call 0x00007029ABEE2420
00007029abfcfb11  jmp 0x00007029ABFCF2D0
00007029abfcfb16  call 0x00007029ABEE2420
00007029abfcfb1b  jmp 0x00007029ABFCF2E1
00007029abfcfb20  call 0x00007029ABEE2420
00007029abfcfb25  jmp 0x00007029ABFCF2F2
00007029abfcfb2a  call 0x00007029ABEE2420
00007029abfcfb2f  jmp 0x00007029ABFCF303
00007029abfcfb34  call 0x00007029ABEE2420
00007029abfcfb39  jmp 0x00007029ABFCF314
00007029abfcfb3e  call 0x00007029ABEE2420
00007029abfcfb43  jmp 0x00007029ABFCF325
00007029abfcfb48  call 0x00007029ABEE2420
00007029abfcfb4d  jmp 0x00007029ABFCF336
00007029abfcfb52  call 0x00007029ABEE2420
00007029abfcfb57  jmp 0x00007029ABFCF347
00007029abfcfb5c  call 0x00007029ABEE2420
00007029abfcfb61  jmp 0x00007029ABFCF358
00007029abfcfb66  call 0x00007029ABEE2420
00007029abfcfb6b  jmp 0x00007029ABFCF369
00007029abfcfb70  call 0x00007029ABEE2420
00007029abfcfb75  jmp 0x00007029ABFCF37A
00007029abfcfb7a  call 0x00007029ABEE2420
00007029abfcfb7f  jmp 0x00007029ABFCF38B
00007029abfcfb84  call 0x00007029ABEE2420
00007029abfcfb89  jmp 0x00007029ABFCF39C
00007029abfcfb8e  call 0x00007029ABEE2420
00007029abfcfb93  jmp 0x00007029ABFCF3AD
00007029abfcfb98  call 0x00007029ABEE2420
00007029abfcfb9d  jmp 0x00007029ABFCF3BE
00007029abfcfba2  call 0x00007029ABEE2420
00007029abfcfba7  jmp 0x00007029ABFCF3CF
00007029abfcfbac  call 0x00007029ABEE2420
00007029abfcfbb1  jmp 0x00007029ABFCF3E0
00007029abfcfbb6  call 0x00007029ABEE2420
00007029abfcfbbb  jmp 0x00007029ABFCF3F1
00007029abfcfbc0  call 0x00007029ABEE2420
00007029abfcfbc5  jmp 0x00007029ABFCF402
00007029abfcfbca  call 0x00007029ABEE2420
00007029abfcfbcf  jmp 0x00007029ABFCF413
00007029abfcfbd4  call 0x00007029ABEE2420
00007029abfcfbd9  jmp 0x00007029ABFCF424
00007029abfcfbde  call 0x00007029ABEE2420
00007029abfcfbe3  jmp 0x00007029ABFCF435
00007029abfcfbe8  call 0x00007029ABEE2420
00007029abfcfbed  jmp 0x00007029ABFCF446
00007029abfcfbf2  call 0x00007029ABEE2420
00007029abfcfbf7  jmp 0x00007029ABFCF45F
00007029abfcfbfc  call 0x00007029ABEE2420
00007029abfcfc01  jmp 0x00007029ABFCF478
00007029abfcfc06  call 0x00007029ABED5610
00007029abfcfc0b  jmp 0x00007029ABFCF491
00007029abfcfc10  call 0x00007029ABEDC580
00007029abfcfc15  jmp 0x00007029ABFCF7FE
00007029abfcfc1a  call 0x00007029ABEE46C0
00007029abfcfc1f  jmp 0x00007029ABFCF808
00007029abfcfc24  call 0x00007029ABE09E90
00007029abfcfc29  jmp 0x00007029ABFCF80E
00007029abfcfc2e  call 0x00007029ABEDB310
00007029abfcfc33  jmp 0x00007029ABFCF818
00007029abfcfc38  call 0x00007029ABE0DAE0
00007029abfcfc3d  jmp 0x00007029ABFCF81D
00007029abfcfc42  call 0x00007029ABEC0230
00007029abfcfc47  jmp 0x00007029ABFCF836
00007029abfcfc4c  call 0x00007029ABEC0230
00007029abfcfc51  jmp 0x00007029ABFCF84B
00007029abfcfc56  call 0x00007029ABEBEFC0
00007029abfcfc5b  jmp 0x00007029ABFCF854
00007029abfcfc60  call 0x00007029ABEE2BA0
00007029abfcfc65  jmp 0x00007029ABFCF91B
00007029abfcfc6a  int3
00007029abfcfc6b  nop [rax+rax*1], eax
00007029abfcfc70  mov rax, [r15+0x48]
00007029abfcfc74  mov r14, [r15+0x58]
00007029abfcfc78  lea r12, [rax+r14*1]
00007029abfcfc7c  mov [r15+0x68], r12
00007029abfcfc80  lea rax, [r14+0x04]
00007029abfcfc84  mov [r15+0x58], rax
00007029abfcfc88  lea r14, [r12+0x04]
00007029abfcfc8d  mov r11d, [r13+r14*1]
00007029abfcfc92  mov [rsp+0x10], r11d
00007029abfcfc97  mov r11d, r11d
00007029abfcfc9a  mov [r15+0x70], r11
00007029abfcfc9e  lea r14, [r12+0x38]
00007029abfcfca3  mov r11d, [r13+r14*1]
00007029abfcfca8  lea r14, [r12+0x24]
00007029abfcfcad  mov r10d, [r13+r14*1]
00007029abfcfcb2  mov [rsp+0x20], r10d
00007029abfcfcb7  mov r10d, r10d
00007029abfcfcba  mov [r15+0x90], r10
00007029abfcfcc1  mov [rsp+0x30], rax
00007029abfcfcc6  xor eax, eax
00007029abfcfcc8  mov r14, [rsp+0x30]
00007029abfcfccd  mov r10d, 0xC0
00007029abfcfcd3  cmp r14, r10
00007029abfcfcd6  cmc
00007029abfcfcd7  lahf
00007029abfcfcd8  seto al
00007029abfcfcdb  mov [r15+0x108], eax
00007029abfcfce2  mov eax, [rsp+0x10]
00007029abfcfce6  mov r14d, [rsp+0x10]
00007029abfcfceb  shrd eax, r14d, 0x07
00007029abfcfcf0  mov [rsp+0x10], r11d
00007029abfcfcf5  mov r10d, [rsp+0x10]
00007029abfcfcfa  shrd r11d, r10d, 0x11
00007029abfcfcff  mov r9d, [r15+0x60]
00007029abfcfd03  mov r8d, [rsp+0x20]
00007029abfcfd08  lea ebp, [r8d+r9d*1]
00007029abfcfd0d  rorx r9d, r14d, 0x12
00007029abfcfd13  xor eax, r9d
00007029abfcfd16  rorx r9d, r10d, 0x13
00007029abfcfd1c  xor r11d, r9d
00007029abfcfd1f  mov [rsp+0x10], r11d
00007029abfcfd24  mov r11d, r11d
00007029abfcfd27  mov [r15+0x88], r11
00007029abfcfd2e  mov [rsp+0x20], r14d
00007029abfcfd33  shr r14d, 0x03
00007029abfcfd37  xor eax, r14d
00007029abfcfd3a  mov [rsp+0x30], eax
00007029abfcfd3e  mov eax, eax
00007029abfcfd40  mov [r15+0x80], rax
00007029abfcfd47  shr r10d, 0x0A
00007029abfcfd4b  mov eax, [rsp+0x10]
00007029abfcfd4f  xor eax, r10d
00007029abfcfd52  mov [rsp+0x10], eax
00007029abfcfd56  mov eax, eax
00007029abfcfd58  mov [r15+0x78], rax
00007029abfcfd5c  mov eax, [rsp+0x30]
00007029abfcfd60  lea r14d, [ebp+eax*1]
00007029abfcfd66  mov eax, [rsp+0x10]
00007029abfcfd6a  lea r11d, [r14d+eax*1]
00007029abfcfd6f  lea rax, [r12+0x40]
00007029abfcfd74  mov [r13+rax*1], r11d
00007029abfcfd79  mov eax, [rsp+0x20]
00007029abfcfd7d  mov eax, eax
00007029abfcfd7f  mov [r15+0x60], rax
00007029abfcfd83  mov eax, [r15+0x108]
00007029abfcfd8a  sahf
00007029abfcfd8b  jnz 0x00007029ABFCFDBD
00007029abfcfd8d  cmp dword ptr [r15+0x318], 0x00
00007029abfcfd95  jz 0x00007029ABFCFE20
00007029abfcfd9b  nop [rax+rax*1], ax
00007029abfcfda4  nop [rax+rax*1], eax
00007029abfcfdac  mov eax, 0x41049C
00007029abfcfdb1  mov [r15+0x100], rax
00007029abfcfdb8  jmp 0x00007029ABDFE110
00007029abfcfdbd  cmp dword ptr [r15+0x318], 0x00
00007029abfcfdc5  jz 0x00007029ABFCFC70
00007029abfcfdcb  nop [rax+rax*1], ax
00007029abfcfdd4  nop [rax+rax*1], eax
00007029abfcfddc  mov eax, 0x410454
00007029abfcfde1  mov [r15+0x100], rax
00007029abfcfde8  jmp 0x00007029ABDFE110
00007029abfcfded  int3
00007029abfcfdee  call 0x00007029ABEE1430
00007029abfcfdf3  jmp 0x00007029ABFCFC92
00007029abfcfdf8  call 0x00007029ABEE1430
00007029abfcfdfd  jmp 0x00007029ABFCFCA8
00007029abfcfe02  call 0x00007029ABEE01C0
00007029abfcfe07  jmp 0x00007029ABFCFCB2
00007029abfcfe0c  call 0x00007029ABE0A860
00007029abfcfe11  jmp 0x00007029ABFCFD79
00007029abfcfe16  int3
00007029abfcfe17  nop [rax+rax*1], ax
00007029abfcfe20  mov rax, [r15]
00007029abfcfe23  mov r14d, [r13+rax*1]
00007029abfcfe28  lea r12, [rax+0x04]
00007029abfcfe2c  mov r11d, [r13+r12*1]
00007029abfcfe31  mov [rsp+0x10], r14d
00007029abfcfe36  mov r14d, r14d
00007029abfcfe39  mov [r15+0x78], r14
00007029abfcfe3d  mov [rsp+0x20], r11d
00007029abfcfe42  mov r11d, r11d
00007029abfcfe45  mov [r15+0x80], r11
00007029abfcfe4c  lea r14, [rax+0x08]
00007029abfcfe50  mov r12d, [r13+r14*1]
00007029abfcfe55  lea r14, [rax+0x0C]
00007029abfcfe59  mov r11d, [r13+r14*1]
00007029abfcfe5e  mov [rsp+0x30], r12d
00007029abfcfe63  mov r12d, r12d
00007029abfcfe66  mov [r15+0x70], r12
00007029abfcfe6a  mov [rsp+0x40], r11d
00007029abfcfe6f  mov r11d, r11d
00007029abfcfe72  mov [r15+0x68], r11
00007029abfcfe76  lea r14, [rax+0x18]
00007029abfcfe7a  mov r12d, [r13+r14*1]
00007029abfcfe7f  lea r14, [rax+0x1C]
00007029abfcfe83  mov r11d, [r13+r14*1]
00007029abfcfe88  mov [rsp+0x50], r12d
00007029abfcfe8d  mov r12d, r12d
00007029abfcfe90  mov [r15+0x58], r12
00007029abfcfe94  mov [rsp+0x60], r11d
00007029abfcfe99  mov r11d, r11d
00007029abfcfe9c  mov [r15+0x60], r11
00007029abfcfea0  lea r14, [rax+0x10]
00007029abfcfea4  mov r12d, [r13+r14*1]
00007029abfcfea9  lea r14, [rax+0x14]
00007029abfcfead  mov eax, [r13+r14*1]
00007029abfcfeb2  mov [rsp+0x70], r12d
00007029abfcfeb7  mov r12d, r12d
00007029abfcfeba  mov [r15+0x18], r12
00007029abfcfebe  mov [rsp+0x80], eax
00007029abfcfec5  mov eax, eax
00007029abfcfec7  mov [r15+0x90], rax
00007029abfcfece  mov eax, [rsp+0x70]
00007029abfcfed2  mov eax, eax
00007029abfcfed4  mov [r15+0x30], rax
00007029abfcfed8  mov eax, [rsp+0x50]
00007029abfcfedc  mov eax, eax
00007029abfcfede  mov [r15+0xA0], rax
00007029abfcfee5  mov eax, [rsp+0x30]
00007029abfcfee9  mov eax, eax
00007029abfcfeeb  mov [r15+0x28], rax
00007029abfcfeef  mov eax, [rsp+0x20]
00007029abfcfef3  mov eax, eax
00007029abfcfef5  mov [r15+0x98], rax
00007029abfcfefc  mov eax, [rsp+0x10]
00007029abfcff00  mov eax, eax
00007029abfcff02  mov [r15+0x38], rax
00007029abfcff06  mov eax, [rsp+0x70]
00007029abfcff0a  mov r14d, [rsp+0x70]
00007029abfcff0f  shrd eax, r14d, 0x06
00007029abfcff14  mov [rsp+0x70], r14d
00007029abfcff19  mov r12d, [rsp+0x80]
00007029abfcff21  and r14d, r12d
00007029abfcff24  mov r11d, [rsp+0x10]
00007029abfcff29  mov r10d, [rsp+0x10]
00007029abfcff2e  shrd r11d, r10d, 0x02
00007029abfcff33  mov [rsp+0x10], r12d
00007029abfcff38  mov r12d, r12d
00007029abfcff3b  mov [r15+0x20], r12
00007029abfcff3f  mov r12, [r15+0x50]
00007029abfcff43  mov r9d, [r13+r12*1]
00007029abfcff48  mov r12d, [rsp+0x50]
00007029abfcff4d  mov r8d, [rsp+0x70]
00007029abfcff52  andn ebp, r8d, r12d
00007029abfcff57  mov edi, [rsp+0x60]
00007029abfcff5b  lea esi, [r14d+edi*1]
00007029abfcff60  rorx r14d, r8d, 0x0B
00007029abfcff66  xor eax, r14d
00007029abfcff69  rorx r14d, r10d, 0x0D
00007029abfcff6f  xor r11d, r14d
00007029abfcff72  lea edi, [esi+ebp*1]
00007029abfcff76  mov r14, [r15+0x48]
00007029abfcff7a  mov ebp, [r13+r14*1]
00007029abfcff7f  mov r14d, [rsp+0x30]
00007029abfcff84  mov esi, [rsp+0x20]
00007029abfcff88  and r14d, esi
00007029abfcff8b  mov [rsp+0x20], r14d
00007029abfcff90  mov r14d, r14d
00007029abfcff93  mov [r15+0xD8], r14
00007029abfcff9a  lea r14d, [edi+r9d*1]
00007029abfcff9f  mov r9d, [rsp+0x30]
00007029abfcffa4  xor r9d, esi
00007029abfcffa7  rorx edi, r8d, 0x19
00007029abfcffad  xor eax, edi
00007029abfcffaf  and r9d, r10d
00007029abfcffb2  rorx edi, r10d, 0x16
00007029abfcffb8  xor r11d, edi
00007029abfcffbb  mov [rsp+0x30], r11d
00007029abfcffc0  mov r11d, r11d
00007029abfcffc3  mov [r15+0xD0], r11
00007029abfcffca  lea r11d, [r14d+ebp*1]
00007029abfcffcf  mov r10d, [rsp+0x20]
00007029abfcffd4  xor r9d, r10d
00007029abfcffd7  lea r14d, [r11d+eax*1]
00007029abfcffdc  mov qword ptr [r15+0x88], 0x04
00007029abfcffe7  mov eax, [rsp+0x30]
00007029abfcffeb  lea r11d, [r9d+eax*1]
00007029abfcfff0  mov eax, [rsp+0x40]
00007029abfcfff4  lea r10d, [r14d+eax*1]
00007029abfcfff9  mov r10d, r10d
00007029abfcfffc  mov [r15+0xB8], r10
00007029abfd0003  xor eax, eax
00007029abfd0005  mov r10d, 0x04
00007029abfd000b  mov r9d, 0x100
00007029abfd0011  cmp r10, r9
00007029abfd0014  cmc
00007029abfd0015  lahf
00007029abfd0016  seto al
00007029abfd0019  mov [r15+0x108], eax
00007029abfd0020  lea eax, [r11d+r14d*1]
00007029abfd0025  mov eax, eax
00007029abfd0027  mov [r15+0xA8], rax
00007029abfd002e  mov r12d, r12d
00007029abfd0031  mov [r15+0xB0], r12
00007029abfd0038  mov eax, [rsp+0x10]
00007029abfd003c  mov eax, eax
00007029abfd003e  mov [r15+0xC0], rax
00007029abfd0045  mov r8d, r8d
00007029abfd0048  mov [r15+0xC8], r8
00007029abfd004f  mov eax, [r15+0x108]
00007029abfd0056  sahf
00007029abfd0057  jnz 0x00007029ABFD0089
00007029abfd0059  cmp dword ptr [r15+0x318], 0x00
00007029abfd0061  jz 0x00007029ABFD0350
00007029abfd0067  nop [rax+rax*1], ax
00007029abfd0070  nop [rax+rax*1], eax
00007029abfd0078  mov eax, 0x41055C
00007029abfd007d  mov [r15+0x100], rax
00007029abfd0084  jmp 0x00007029ABDFE110
00007029abfd0089  cmp dword ptr [r15+0x318], 0x00
00007029abfd0091  jz 0x00007029ABFD0120
00007029abfd0097  nop [rax+rax*1], ax
00007029abfd00a0  nop [rax+rax*1], eax
00007029abfd00a8  mov eax, 0x4104D0
00007029abfd00ad  mov [r15+0x100], rax
00007029abfd00b4  jmp 0x00007029ABDFE110
00007029abfd00b9  int3
00007029abfd00ba  call 0x00007029ABE0DAE0
00007029abfd00bf  jmp 0x00007029ABFCFE28
00007029abfd00c4  call 0x00007029ABEC0230
00007029abfd00c9  jmp 0x00007029ABFCFE31
00007029abfd00ce  call 0x00007029ABEE26A0
00007029abfd00d3  jmp 0x00007029ABFCFE55
00007029abfd00d8  call 0x00007029ABEE1430
00007029abfd00dd  jmp 0x00007029ABFCFE5E
00007029abfd00e2  call 0x00007029ABEE26A0
00007029abfd00e7  jmp 0x00007029ABFCFE7F
00007029abfd00ec  call 0x00007029ABEE1430
00007029abfd00f1  jmp 0x00007029ABFCFE88
00007029abfd00f6  call 0x00007029ABEE26A0
00007029abfd00fb  jmp 0x00007029ABFCFEA9
00007029abfd0100  call 0x00007029ABED5890
00007029abfd0105  jmp 0x00007029ABFCFEB2
00007029abfd010a  call 0x00007029ABEBDD50
00007029abfd010f  jmp 0x00007029ABFCFF48
00007029abfd0114  call 0x00007029ABEDA580
00007029abfd0119  jmp 0x00007029ABFCFF7F
00007029abfd011e  int3
00007029abfd011f  nop
00007029abfd0120  mov eax, [r15+0xB8]
00007029abfd0127  mov [rsp+0x10], eax
00007029abfd012b  mov eax, eax
00007029abfd012d  mov [r15+0x30], rax
00007029abfd0131  mov eax, [r15+0xC0]
00007029abfd0138  mov [rsp+0x20], eax
00007029abfd013c  mov eax, eax
00007029abfd013e  mov [r15+0xA0], rax
00007029abfd0145  mov eax, [r15+0x28]
00007029abfd0149  mov r14d, [r15+0x98]
00007029abfd0150  mov [rsp+0x30], r14d
00007029abfd0155  mov r14d, r14d
00007029abfd0158  mov [r15+0x28], r14
00007029abfd015c  mov r14d, [r15+0x38]
00007029abfd0160  mov [rsp+0x40], r14d
00007029abfd0165  mov r14d, r14d
00007029abfd0168  mov [r15+0x98], r14
00007029abfd016f  mov r14d, [r15+0xA8]
00007029abfd0176  mov [rsp+0x50], r14d
00007029abfd017b  mov r14d, r14d
00007029abfd017e  mov [r15+0x38], r14
00007029abfd0182  mov r14d, [rsp+0x10]
00007029abfd0187  mov r12d, [rsp+0x10]
00007029abfd018c  shrd r14d, r12d, 0x06
00007029abfd0191  mov r11d, [r15+0xC8]
00007029abfd0198  mov [rsp+0x10], r12d
00007029abfd019d  and r12d, r11d
00007029abfd01a0  mov r10d, [rsp+0x50]
00007029abfd01a5  mov r9d, [rsp+0x50]
00007029abfd01aa  shrd r10d, r9d, 0x02
00007029abfd01af  mov [rsp+0x50], r11d
00007029abfd01b4  mov r11d, r11d
00007029abfd01b7  mov [r15+0x20], r11
00007029abfd01bb  mov r11, [r15+0x88]
00007029abfd01c2  mov r8, [r15+0x50]
00007029abfd01c6  lea rbp, [r8+r11*1]
00007029abfd01ca  mov r8d, [r13+rbp*1]
00007029abfd01cf  mov ebp, [rsp+0x20]
00007029abfd01d3  mov edi, [rsp+0x10]
00007029abfd01d7  andn esi, edi, ebp
00007029abfd01dc  mov edx, [r15+0xB0]
00007029abfd01e3  lea ecx, [r12d+edx*1]
00007029abfd01e8  rorx r12d, edi, 0x0B
00007029abfd01ee  xor r14d, r12d
00007029abfd01f1  rorx r12d, r9d, 0x0D
00007029abfd01f7  xor r10d, r12d
00007029abfd01fa  lea r12d, [ecx+esi*1]
00007029abfd01ff  mov rsi, [r15+0x48]
00007029abfd0203  lea rdx, [rsi+r11*1]
00007029abfd0207  mov esi, [r13+rdx*1]
00007029abfd020c  mov edx, [rsp+0x30]
00007029abfd0210  mov ecx, [rsp+0x40]
00007029abfd0214  and edx, ecx
00007029abfd0216  mov [rsp+0x10], edx
00007029abfd021a  mov edx, edx
00007029abfd021c  mov [r15+0xD8], rdx
00007029abfd0223  lea edx, [r12d+r8d*1]
00007029abfd0228  mov r12d, [rsp+0x30]
00007029abfd022d  xor r12d, ecx
00007029abfd0230  rorx r8d, edi, 0x19
00007029abfd0236  xor r14d, r8d
00007029abfd0239  and r12d, r9d
00007029abfd023c  rorx r8d, r9d, 0x16
00007029abfd0242  xor r10d, r8d
00007029abfd0245  mov [rsp+0x20], r10d
00007029abfd024a  mov r10d, r10d
00007029abfd024d  mov [r15+0xD0], r10
00007029abfd0254  lea r10d, [edx+esi*1]
00007029abfd0259  mov r9d, [rsp+0x10]
00007029abfd025e  xor r12d, r9d
00007029abfd0261  lea r9d, [r10d+r14d*1]
00007029abfd0266  lea r14, [r11+0x04]
00007029abfd026a  mov [r15+0x88], r14
00007029abfd0271  mov r11d, [rsp+0x20]
00007029abfd0276  lea r10d, [r12d+r11d*1]
00007029abfd027b  lea r11d, [r9d+eax*1]
00007029abfd0280  mov r11d, r11d
00007029abfd0283  mov [r15+0xB8], r11
00007029abfd028a  xor eax, eax
00007029abfd028c  mov r12d, 0x100
00007029abfd0292  cmp r14, r12
00007029abfd0295  cmc
00007029abfd0296  lahf
00007029abfd0297  seto al
00007029abfd029a  mov [r15+0x108], eax
00007029abfd02a1  lea eax, [r10d+r9d*1]
00007029abfd02a6  mov eax, eax
00007029abfd02a8  mov [r15+0xA8], rax
00007029abfd02af  mov ebp, ebp
00007029abfd02b1  mov [r15+0xB0], rbp
00007029abfd02b8  mov eax, [rsp+0x50]
00007029abfd02bc  mov eax, eax
00007029abfd02be  mov [r15+0xC0], rax
00007029abfd02c5  mov edi, edi
00007029abfd02c7  mov [r15+0xC8], rdi
00007029abfd02ce  mov eax, [r15+0x108]
00007029abfd02d5  sahf
00007029abfd02d6  jnz 0x00007029ABFD0308
00007029abfd02d8  cmp dword ptr [r15+0x318], 0x00
00007029abfd02e0  jz 0x00007029ABFD0350
00007029abfd02e6  nop [rax+rax*1], ax
00007029abfd02ef  nop [rax+rax*1], eax
00007029abfd02f7  mov eax, 0x41055C
00007029abfd02fc  mov [r15+0x100], rax
00007029abfd0303  jmp 0x00007029ABDFE110
00007029abfd0308  cmp dword ptr [r15+0x318], 0x00
00007029abfd0310  jz 0x00007029ABFD0120
00007029abfd0316  nop [rax+rax*1], ax
00007029abfd031f  nop [rax+rax*1], eax
00007029abfd0327  mov eax, 0x4104D0
00007029abfd032c  mov [r15+0x100], rax
00007029abfd0333  jmp 0x00007029ABDFE110
00007029abfd0338  int3
00007029abfd0339  call 0x00007029ABE49010
00007029abfd033e  jmp 0x00007029ABFD01CF
00007029abfd0343  call 0x00007029ABE25930
00007029abfd0348  jmp 0x00007029ABFD020C
00007029abfd034d  int3
00007029abfd034e  nop
00007029abfd0350  mov eax, [r15+0x98]
00007029abfd0357  mov r14d, [r15+0x70]
00007029abfd035b  lea r12d, [eax+r14d*1]
00007029abfd0360  mov eax, [r15+0x28]
00007029abfd0364  mov r14d, [r15+0x68]
00007029abfd0368  lea r11d, [eax+r14d*1]
00007029abfd036d  mov qword ptr [r15+0x88], 0x00
00007029abfd0378  mov eax, [r15+0xA8]
00007029abfd037f  mov r14d, [r15+0x78]
00007029abfd0383  lea r10d, [eax+r14d*1]
00007029abfd0388  mov [rsp+0x10], r10d
00007029abfd038d  mov r10d, r10d
00007029abfd0390  mov [r15+0x78], r10
00007029abfd0394  mov eax, [r15+0x38]
00007029abfd0398  mov r14d, [r15+0x80]
00007029abfd039f  lea r10d, [eax+r14d*1]
00007029abfd03a4  mov [rsp+0x20], r10d
00007029abfd03a9  mov r10d, r10d
00007029abfd03ac  mov [r15+0x80], r10
00007029abfd03b3  mov rax, [r15]
00007029abfd03b6  lea r14, [rax+0x08]
00007029abfd03ba  mov [r13+r14*1], r12d
00007029abfd03bf  lea r14, [rax+0x0C]
00007029abfd03c3  mov [r13+r14*1], r11d
00007029abfd03c8  mov r14d, [r15+0xB8]
00007029abfd03cf  mov r12d, [r15+0x18]
00007029abfd03d3  lea r11d, [r14d+r12d*1]
00007029abfd03d8  mov [rsp+0x30], r11d
00007029abfd03dd  mov r11d, r11d
00007029abfd03e0  mov [r15+0x68], r11
00007029abfd03e4  mov r14d, [r15+0x30]
00007029abfd03e8  mov r12d, [r15+0x90]
00007029abfd03ef  lea r11d, [r14d+r12d*1]
00007029abfd03f4  mov [rsp+0x40], r11d
00007029abfd03f9  mov r11d, r11d
00007029abfd03fc  mov [r15+0x70], r11
00007029abfd0400  mov r14d, [r15+0x20]
00007029abfd0404  mov r12d, [r15+0x58]
00007029abfd0408  lea r11d, [r14d+r12d*1]
00007029abfd040d  mov [rsp+0x50], r11d
00007029abfd0412  mov r11d, r11d
00007029abfd0415  mov [r15+0x58], r11
00007029abfd0419  mov r14d, [r15+0xA0]
00007029abfd0420  mov r12d, [r15+0x60]
00007029abfd0424  lea r11d, [r14d+r12d*1]
00007029abfd0429  mov [rsp+0x60], r11d
00007029abfd042e  mov r11d, r11d
00007029abfd0431  mov [r15+0x60], r11
00007029abfd0435  mov r14d, [rsp+0x10]
00007029abfd043a  mov [r13+rax*1], r14d
00007029abfd043f  lea r14, [rax+0x04]
00007029abfd0443  mov r12d, [rsp+0x20]
00007029abfd0448  mov [r13+r14*1], r12d
00007029abfd044d  lea r14, [rax+0x10]
00007029abfd0451  mov r12d, [rsp+0x30]
00007029abfd0456  mov [r13+r14*1], r12d
00007029abfd045b  lea r14, [rax+0x14]
00007029abfd045f  mov r12d, [rsp+0x40]
00007029abfd0464  mov [r13+r14*1], r12d
00007029abfd0469  lea r14, [rax+0x18]
00007029abfd046d  mov r12d, [rsp+0x50]
00007029abfd0472  mov [r13+r14*1], r12d
00007029abfd0477  lea r14, [rax+0x1C]
00007029abfd047b  mov r12d, [rsp+0x60]
00007029abfd0480  mov [r13+r14*1], r12d
00007029abfd0485  lea r14, [rax+0x68]
00007029abfd0489  xor eax, eax
00007029abfd048b  mov [r13+r14*1], rax
00007029abfd0490  cmp dword ptr [r15+0x318], 0x00
00007029abfd0498  jz 0x00007029ABFCEF90
00007029abfd049e  nop [rax+rax*1], ax
00007029abfd04a7  nop [rax+rax*1], eax
00007029abfd04af  mov eax, 0x410378
00007029abfd04b4  mov [r15+0x100], rax
00007029abfd04bb  jmp 0x00007029ABDFE110
00007029abfd04c0  int3
00007029abfd04c1  call 0x00007029ABEE2BA0
00007029abfd04c6  jmp 0x00007029ABFD03BF
00007029abfd04cb  call 0x00007029ABEE1920
00007029abfd04d0  jmp 0x00007029ABFD03C8
00007029abfd04d5  call 0x00007029ABE0DFE0
00007029abfd04da  jmp 0x00007029ABFD043F
00007029abfd04df  call 0x00007029ABEE2BA0
00007029abfd04e4  jmp 0x00007029ABFD044D
00007029abfd04e9  call 0x00007029ABEE2BA0
00007029abfd04ee  jmp 0x00007029ABFD045B
00007029abfd04f3  call 0x00007029ABEE2BA0
00007029abfd04f8  jmp 0x00007029ABFD0469
00007029abfd04fd  call 0x00007029ABEE2BA0
00007029abfd0502  jmp 0x00007029ABFD0477
00007029abfd0507  call 0x00007029ABEE2BA0
00007029abfd050c  jmp 0x00007029ABFD0485
00007029abfd0511  call 0x00007029ABED5EB0
00007029abfd0516  jmp 0x00007029ABFD0490
00007029abfd051b  int3
00007029abfd051c  nop [rax], eax
00007029abfd0520  mov rax, [r15+0xF8]
00007029abfd0527  lea r14, [rax+0x140]
00007029abfd052e  mov r12, [r13+r14*1]
00007029abfd0533  lea r14, [rax+0x148]
00007029abfd053a  mov r11, [r13+r14*1]
00007029abfd053f  mov [r15+0xA0], r12
00007029abfd0546  mov [r15+0x98], r11
00007029abfd054d  lea r14, [rax+0x130]
00007029abfd0554  mov r12, [r13+r14*1]
00007029abfd0559  lea r14, [rax+0x138]
00007029abfd0560  mov r11, [r13+r14*1]
00007029abfd0565  mov [r15+0xB0], r12
00007029abfd056c  mov [r15+0xA8], r11
00007029abfd0573  lea r14, [rax+0x120]
00007029abfd057a  mov r12, [r13+r14*1]
00007029abfd057f  lea r14, [rax+0x128]
00007029abfd0586  mov r11, [r13+r14*1]
00007029abfd058b  mov [r15+0xC0], r12
00007029abfd0592  mov [r15+0xB8], r11
00007029abfd0599  lea r14, [rax+0x110]
00007029abfd05a0  mov r12, [r13+r14*1]
00007029abfd05a5  lea r14, [rax+0x118]
00007029abfd05ac  mov r11, [r13+r14*1]
00007029abfd05b1  mov [r15+0xD0], r12
00007029abfd05b8  mov [r15+0xC8], r11
00007029abfd05bf  lea r14, [rax+0x100]
00007029abfd05c6  mov r12, [r13+r14*1]
00007029abfd05cb  lea r14, [rax+0x108]
00007029abfd05d2  mov r11, [r13+r14*1]
00007029abfd05d7  mov [r15+0xE8], r12
00007029abfd05de  mov [r15+0xD8], r11
00007029abfd05e5  lea r14, [rax+0x150]
00007029abfd05ec  mov [r15+0xF8], r14
00007029abfd05f3  mov rax, [r15+0xF0]
00007029abfd05fa  mov [r15+0x100], rax
00007029abfd0601  jmp 0x00007029ABFCE5C0
00007029abfd0606  int3
00007029abfd0607  call 0x00007029ABEE27E0
00007029abfd060c  jmp 0x00007029ABFD0533
00007029abfd0611  call 0x00007029ABEE1570
00007029abfd0616  jmp 0x00007029ABFD053F
00007029abfd061b  call 0x00007029ABEE27E0
00007029abfd0620  jmp 0x00007029ABFD0559
00007029abfd0625  call 0x00007029ABEE1570
00007029abfd062a  jmp 0x00007029ABFD0565
00007029abfd062f  call 0x00007029ABEE27E0
00007029abfd0634  jmp 0x00007029ABFD057F
00007029abfd0639  call 0x00007029ABEE1570
00007029abfd063e  jmp 0x00007029ABFD058B
00007029abfd0643  call 0x00007029ABEE27E0
00007029abfd0648  jmp 0x00007029ABFD05A5
00007029abfd064d  call 0x00007029ABEE1570
00007029abfd0652  jmp 0x00007029ABFD05B1
00007029abfd0657  call 0x00007029ABEE27E0
00007029abfd065c  jmp 0x00007029ABFD05CB
00007029abfd0661  call 0x00007029ABEE1570
00007029abfd0666  jmp 0x00007029ABFD05D7
00007029abfd066b  int3
00007029abfd066c  nop [rax], eax
00007029abfd0670  mov eax, [r15+0xA0]
00007029abfd0677  mov [rsp+0x10], eax
00007029abfd067b  xor eax, eax
00007029abfd067d  mov r14d, [rsp+0x10]
00007029abfd0682  sub r14d, 0x01
00007029abfd0686  cmc
00007029abfd0687  lahf
00007029abfd0688  seto al
00007029abfd068b  mov [r15+0x108], eax
00007029abfd0692  mov r14d, r14d
00007029abfd0695  mov [r15+0xA0], r14
00007029abfd069c  mov eax, [r15+0x108]
00007029abfd06a3  sahf
00007029abfd06a4  jnz 0x00007029ABFD06D6
00007029abfd06a6  cmp dword ptr [r15+0x318], 0x00
00007029abfd06ae  jz 0x00007029ABFD07A0
00007029abfd06b4  nop [rax+rax*1], ax
00007029abfd06bd  nop [rax+rax*1], eax
00007029abfd06c5  mov eax, 0x41027C
00007029abfd06ca  mov [r15+0x100], rax
00007029abfd06d1  jmp 0x00007029ABDFE110
00007029abfd06d6  cmp dword ptr [r15+0x318], 0x00
00007029abfd06de  jz 0x00007029ABFD0710
00007029abfd06e4  nop [rax+rax*1], ax
00007029abfd06ed  nop [rax+rax*1], eax
00007029abfd06f5  mov eax, 0x410264
00007029abfd06fa  mov [r15+0x100], rax
00007029abfd0701  jmp 0x00007029ABDFE110
00007029abfd0706  int3
00007029abfd0707  int3
00007029abfd0708  nop [rax+rax*1], eax
00007029abfd0710  mov rax, [r15+0xF8]
00007029abfd0717  mov [r15], rax
00007029abfd071a  mov rax, [r15+0x98]
00007029abfd0721  mov [r15+0x08], rax
00007029abfd0725  mov qword ptr [r15+0x10], 0x12C
00007029abfd072d  mov qword ptr [r15+0xF0], 0x410274
00007029abfd0738  mov r14d, [r15+0x320]
00007029abfd073f  mov eax, 0x410274
00007029abfd0744  mov rcx, 0x7029ABFD0670
00007029abfd074e  mov [r15+r14*8+0x328], rax
00007029abfd0756  mov [r15+r14*8+0x368], rcx
00007029abfd075e  add r14d, 0x01
00007029abfd0762  and r14d, 0x07
00007029abfd0766  mov [r15+0x320], r14d
00007029abfd076d  cmp dword ptr [r15+0x318], 0x00
00007029abfd0775  jz 0x00007029ABFCEC20
00007029abfd077b  nop [rax+rax*1], ax
00007029abfd0784  nop [rax+rax*1], eax
00007029abfd078c  mov eax, 0x410338
00007029abfd0791  mov [r15+0x100], rax
00007029abfd0798  jmp 0x00007029ABDFE110
00007029abfd079d  int3
00007029abfd079e  int3
00007029abfd079f  nop
00007029abfd07a0  mov rax, [r15+0xF8]
00007029abfd07a7  lea r14, [rax+0x20]
00007029abfd07ab  mov r12, [r13+r14*1]
00007029abfd07b0  mov [r15+0x98], r12
00007029abfd07b7  mov qword ptr [r15+0x40], 0x80
00007029abfd07bf  mov [r15], rax
00007029abfd07c2  lea r14, [rax+0x8C]
00007029abfd07c9  mov [r15+0x08], r14
00007029abfd07cd  mov qword ptr [r15+0x10], 0x01
00007029abfd07d5  lea r14, [rax+0x8C]
00007029abfd07dc  mov eax, 0x80
00007029abfd07e1  mov [r13+r14*1], al
00007029abfd07e6  mov qword ptr [r15+0xF0], 0x410298
00007029abfd07f1  mov r14d, [r15+0x320]
00007029abfd07f8  mov eax, 0x410298
00007029abfd07fd  mov rcx, 0x7029ABFD0870
00007029abfd0807  mov [r15+r14*8+0x328], rax
00007029abfd080f  mov [r15+r14*8+0x368], rcx
00007029abfd0817  add r14d, 0x01
00007029abfd081b  and r14d, 0x07
00007029abfd081f  mov [r15+0x320], r14d
00007029abfd0826  cmp dword ptr [r15+0x318], 0x00
00007029abfd082e  jz 0x00007029ABFCEC20
00007029abfd0834  nop [rax+rax*1], ax
00007029abfd083d  nop [rax+rax*1], eax
00007029abfd0845  mov eax, 0x410338
00007029abfd084a  mov [r15+0x100], rax
00007029abfd0851  jmp 0x00007029ABDFE110
00007029abfd0856  int3
00007029abfd0857  call 0x00007029ABEE27E0
00007029abfd085c  jmp 0x00007029ABFD07B0
00007029abfd0861  call 0x00007029ABED5AF0
00007029abfd0866  jmp 0x00007029ABFD07E6
00007029abfd086b  int3
00007029abfd086c  nop [rax], eax
00007029abfd0870  mov rax, [r15+0xF8]
00007029abfd0877  lea r14, [rax+0x68]
00007029abfd087b  mov r12, [r13+r14*1]
00007029abfd0880  mov [r15+0x40], r12
00007029abfd0884  lea r14, [rax+0x88]
00007029abfd088b  xor eax, eax
00007029abfd088d  mov [r13+r14*1], al
00007029abfd0892  xor eax, eax
00007029abfd0894  mov r14d, 0x38
00007029abfd089a  cmp r12, r14
00007029abfd089d  cmc
00007029abfd089e  lahf
00007029abfd089f  seto al
00007029abfd08a2  mov [r15+0x108], eax
00007029abfd08a9  mov eax, [r15+0x108]
00007029abfd08b0  sahf
00007029abfd08b1  jz 0x00007029ABFD08E3
00007029abfd08b3  cmp dword ptr [r15+0x318], 0x00
00007029abfd08bb  jz 0x00007029ABFD0930
00007029abfd08c1  nop [rax+rax*1], ax
00007029abfd08ca  nop [rax+rax*1], eax
00007029abfd08d2  mov eax, 0x4102A8
00007029abfd08d7  mov [r15+0x100], rax
00007029abfd08de  jmp 0x00007029ABDFE110
00007029abfd08e3  cmp dword ptr [r15+0x318], 0x00
00007029abfd08eb  jz 0x00007029ABFD0A70
00007029abfd08f1  nop [rax+rax*1], ax
00007029abfd08fa  nop [rax+rax*1], eax
00007029abfd0902  mov eax, 0x4102C4
00007029abfd0907  mov [r15+0x100], rax
00007029abfd090e  jmp 0x00007029ABDFE110
00007029abfd0913  int3
00007029abfd0914  call 0x00007029ABEE27E0
00007029abfd0919  jmp 0x00007029ABFD0880
00007029abfd091e  call 0x00007029ABED5AF0
00007029abfd0923  jmp 0x00007029ABFD0892
00007029abfd0928  int3
00007029abfd0929  nop [rax], eax
00007029abfd0930  mov rax, [r15+0xF8]
00007029abfd0937  mov [r15], rax
00007029abfd093a  lea r14, [rax+0x88]
00007029abfd0941  mov [r15+0x08], r14
00007029abfd0945  mov qword ptr [r15+0x10], 0x01
00007029abfd094d  mov qword ptr [r15+0xF0], 0x4102B8
00007029abfd0958  mov r14d, [r15+0x320]
00007029abfd095f  mov eax, 0x4102B8
00007029abfd0964  mov rcx, 0x7029ABFD09C0
00007029abfd096e  mov [r15+r14*8+0x328], rax
00007029abfd0976  mov [r15+r14*8+0x368], rcx
00007029abfd097e  add r14d, 0x01
00007029abfd0982  and r14d, 0x07
00007029abfd0986  mov [r15+0x320], r14d
00007029abfd098d  cmp dword ptr [r15+0x318], 0x00
00007029abfd0995  jz 0x00007029ABFCEC20
00007029abfd099b  nop [rax+rax*1], ax
00007029abfd09a4  nop [rax+rax*1], eax
00007029abfd09ac  mov eax, 0x410338
00007029abfd09b1  mov [r15+0x100], rax
00007029abfd09b8  jmp 0x00007029ABDFE110
00007029abfd09bd  int3
00007029abfd09be  int3
00007029abfd09bf  nop
00007029abfd09c0  mov rax, [r15+0xF8]
00007029abfd09c7  lea r14, [rax+0x68]
00007029abfd09cb  mov rax, [r13+r14*1]
00007029abfd09d0  mov [r15+0x40], rax
00007029abfd09d4  mov [rsp+0x10], rax
00007029abfd09d9  xor eax, eax
00007029abfd09db  mov r14, [rsp+0x10]
00007029abfd09e0  mov r12d, 0x38
00007029abfd09e6  cmp r14, r12
00007029abfd09e9  cmc
00007029abfd09ea  lahf
00007029abfd09eb  seto al
00007029abfd09ee  mov [r15+0x108], eax
00007029abfd09f5  mov eax, [r15+0x108]
00007029abfd09fc  sahf
00007029abfd09fd  jnz 0x00007029ABFD0A2F
00007029abfd09ff  cmp dword ptr [r15+0x318], 0x00
00007029abfd0a07  jz 0x00007029ABFD0A70
00007029abfd0a0d  nop [rax+rax*1], ax
00007029abfd0a16  nop [rax+rax*1], eax
00007029abfd0a1e  mov eax, 0x4102C4
00007029abfd0a23  mov [r15+0x100], rax
00007029abfd0a2a  jmp 0x00007029ABDFE110
00007029abfd0a2f  cmp dword ptr [r15+0x318], 0x00
00007029abfd0a37  jz 0x00007029ABFD0930
00007029abfd0a3d  nop [rax+rax*1], ax
00007029abfd0a46  nop [rax+rax*1], eax
00007029abfd0a4e  mov eax, 0x4102A8
00007029abfd0a53  mov [r15+0x100], rax
00007029abfd0a5a  jmp 0x00007029ABDFE110
00007029abfd0a5f  int3
00007029abfd0a60  call 0x00007029ABED59C0
00007029abfd0a65  jmp 0x00007029ABFD09D0
00007029abfd0a6a  int3
00007029abfd0a6b  nop [rax+rax*1], eax
00007029abfd0a70  mov rax, [r15+0x98]
00007029abfd0a77  rorx r14, rax, 0x3D
00007029abfd0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007029abfd0a81  mov rax, [r15+0xF8]
00007029abfd0a88  mov [r15], rax
00007029abfd0a8b  lea r12, [rax+0x78]
00007029abfd0a8f  mov [r15+0x08], r12
00007029abfd0a93  mov qword ptr [r15+0x10], 0x08
00007029abfd0a9b  bswap r14
00007029abfd0a9e  mov [r15+0x40], r14
00007029abfd0aa2  lea r12, [rax+0x78]
00007029abfd0aa6  mov [r13+r12*1], r14
00007029abfd0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007029abfd0ab6  mov r14d, [r15+0x320]
00007029abfd0abd  mov eax, 0x4102E0
00007029abfd0ac2  mov rcx, 0x7029ABFD0B30
00007029abfd0acc  mov [r15+r14*8+0x328], rax
00007029abfd0ad4  mov [r15+r14*8+0x368], rcx
00007029abfd0adc  add r14d, 0x01
00007029abfd0ae0  and r14d, 0x07
00007029abfd0ae4  mov [r15+0x320], r14d
00007029abfd0aeb  cmp dword ptr [r15+0x318], 0x00
00007029abfd0af3  jz 0x00007029ABFCEC20
00007029abfd0af9  nop [rax+rax*1], ax
00007029abfd0b02  nop [rax+rax*1], eax
00007029abfd0b0a  mov eax, 0x410338
00007029abfd0b0f  mov [r15+0x100], rax
00007029abfd0b16  jmp 0x00007029ABDFE110
00007029abfd0b1b  int3
00007029abfd0b1c  call 0x00007029ABEC3FE0
00007029abfd0b21  jmp 0x00007029ABFD0AAB
00007029abfd0b26  int3
00007029abfd0b27  nop [rax+rax*1], ax
00007029abfd0b30  mov rax, [r15+0xF8]
00007029abfd0b37  mov r14d, [r13+rax*1]
00007029abfd0b3c  lea r12, [rax+0x04]
00007029abfd0b40  mov r11d, [r13+r12*1]
00007029abfd0b45  lea r12, [rax+0x08]
00007029abfd0b49  mov r10d, [r13+r12*1]
00007029abfd0b4e  lea r12, [rax+0x0C]
00007029abfd0b52  mov r9d, [r13+r12*1]
00007029abfd0b57  mov qword ptr [r15+0x48], 0x430860
00007029abfd0b5f  lea r12, [rax+0x80]
00007029abfd0b66  mov r8, [r13+r12*1]
00007029abfd0b6b  mov [r15+0xF0], r8
00007029abfd0b72  bswap r14d
00007029abfd0b75  bswap r11d
00007029abfd0b78  mov r12d, 0x430860
00007029abfd0b7e  mov [r13+r12*1], r14d
00007029abfd0b83  mov r14d, 0x430864
00007029abfd0b89  mov [r13+r14*1], r11d
00007029abfd0b8e  bswap r10d
00007029abfd0b91  bswap r9d
00007029abfd0b94  lea r14, [rax+0x10]
00007029abfd0b98  mov r12d, [r13+r14*1]
00007029abfd0b9d  lea r14, [rax+0x14]
00007029abfd0ba1  mov r11d, [r13+r14*1]
00007029abfd0ba6  mov r14d, 0x430868
00007029abfd0bac  mov [r13+r14*1], r10d
00007029abfd0bb1  mov r14d, 0x43086C
00007029abfd0bb7  mov [r13+r14*1], r9d
00007029abfd0bbc  lea r14, [rax+0x90]
00007029abfd0bc3  mov r10, [r13+r14*1]
00007029abfd0bc8  lea r14, [rax+0x98]
00007029abfd0bcf  mov r9, [r13+r14*1]
00007029abfd0bd4  mov [r15+0xA0], r10
00007029abfd0bdb  mov [r15+0x98], r9
00007029abfd0be2  bswap r12d
00007029abfd0be5  bswap r11d
00007029abfd0be8  mov [rsp+0x10], r11d
00007029abfd0bed  mov r11d, r11d
00007029abfd0bf0  mov [r15+0x58], r11
00007029abfd0bf4  lea r14, [rax+0x18]
00007029abfd0bf8  mov r11d, [r13+r14*1]
00007029abfd0bfd  lea r14, [rax+0x1C]
00007029abfd0c01  mov r10d, [r13+r14*1]
00007029abfd0c06  mov [rsp+0x20], r10d
00007029abfd0c0b  mov r10d, r10d
00007029abfd0c0e  mov [r15+0x60], r10
00007029abfd0c12  mov r14d, 0x430870
00007029abfd0c18  mov [r13+r14*1], r12d
00007029abfd0c1d  mov r14d, 0x430874
00007029abfd0c23  mov r12d, [rsp+0x10]
00007029abfd0c28  mov [r13+r14*1], r12d
00007029abfd0c2d  bswap r11d
00007029abfd0c30  mov [rsp+0x10], r11d
00007029abfd0c35  mov r11d, r11d
00007029abfd0c38  mov [r15+0x40], r11
00007029abfd0c3c  mov r14d, [rsp+0x20]
00007029abfd0c41  bswap r14d
00007029abfd0c44  mov [rsp+0x20], r14d
00007029abfd0c49  mov r14d, r14d
00007029abfd0c4c  mov [r15+0x50], r14
00007029abfd0c50  mov r14d, 0x430878
00007029abfd0c56  mov r12d, [rsp+0x10]
00007029abfd0c5b  mov [r13+r14*1], r12d
00007029abfd0c60  mov r14d, 0x43087C
00007029abfd0c66  mov r12d, [rsp+0x20]
00007029abfd0c6b  mov [r13+r14*1], r12d
00007029abfd0c70  lea r14, [rax+0xA0]
00007029abfd0c77  mov [r15+0xF8], r14
00007029abfd0c7e  mov [r15+0x100], r8
00007029abfd0c85  jmp 0x00007029ABFCE5C0
00007029abfd0c8a  int3
00007029abfd0c8b  call 0x00007029ABE0DAE0
00007029abfd0c90  jmp 0x00007029ABFD0B3C
00007029abfd0c95  call 0x00007029ABEC0230
00007029abfd0c9a  jmp 0x00007029ABFD0B45
00007029abfd0c9f  call 0x00007029ABEBEFC0
00007029abfd0ca4  jmp 0x00007029ABFD0B4E
00007029abfd0ca9  call 0x00007029ABEBDD50
00007029abfd0cae  jmp 0x00007029ABFD0B57
00007029abfd0cb3  call 0x00007029ABEBCC20
00007029abfd0cb8  jmp 0x00007029ABFD0B6B
00007029abfd0cbd  call 0x00007029ABEC3EA0
00007029abfd0cc2  jmp 0x00007029ABFD0B83
00007029abfd0cc7  call 0x00007029ABEE1920
00007029abfd0ccc  jmp 0x00007029ABFD0B8E
00007029abfd0cd1  call 0x00007029ABEE26A0
00007029abfd0cd6  jmp 0x00007029ABFD0B9D
00007029abfd0cdb  call 0x00007029ABEE1430
00007029abfd0ce0  jmp 0x00007029ABFD0BA6
00007029abfd0ce5  call 0x00007029ABEE06B0
00007029abfd0cea  jmp 0x00007029ABFD0BB1
00007029abfd0cef  call 0x00007029ABEDF440
00007029abfd0cf4  jmp 0x00007029ABFD0BBC
00007029abfd0cf9  call 0x00007029ABEE0300
00007029abfd0cfe  jmp 0x00007029ABFD0BC8
00007029abfd0d03  call 0x00007029ABEDF090
00007029abfd0d08  jmp 0x00007029ABFD0BD4
00007029abfd0d0d  call 0x00007029ABEE1430
00007029abfd0d12  jmp 0x00007029ABFD0BFD
00007029abfd0d17  call 0x00007029ABEE01C0
00007029abfd0d1c  jmp 0x00007029ABFD0C06
00007029abfd0d21  call 0x00007029ABEE2BA0
00007029abfd0d26  jmp 0x00007029ABFD0C1D
00007029abfd0d2b  call 0x00007029ABEE2BA0
00007029abfd0d30  jmp 0x00007029ABFD0C2D
00007029abfd0d35  call 0x00007029ABEE2BA0
00007029abfd0d3a  jmp 0x00007029ABFD0C60
00007029abfd0d3f  call 0x00007029ABEE2BA0
00007029abfd0d44  jmp 0x00007029ABFD0C70
00007029abfd0d49  int3
00007029abfd0d4a  nop [rax+rax*1], ax
00007029abfd0d50  mov qword ptr [r15+0x100], 0x04
00007029abfd0d5b  mov esi, 0x00
00007029abfd0d60  mov edx, 0x09
00007029abfd0d65  mov rdi, 0x7FFF5C456220
00007029abfd0d6f  mov rax, 0x5F05FB378970
00007029abfd0d79  call rax
00007029abfd0d7b  cmp dword ptr [r15+0x318], 0x00
00007029abfd0d83  jnz 0x00007029ABDFE110
00007029abfd0d89  jmp 0x00007029ABDFE0A0
00007029abfd0d8e  int3
00007029abfd0d8f  int3
