
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-matrix/candidate/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	sub    rsp,0x150
       7:	mov    r11,QWORD PTR [r12+0x398]
       f:	mov    QWORD PTR [rsp],r11
      13:	cmp    DWORD PTR [r12+0x310],0x0
      1c:	je     0xa7
      22:	push   rdx
      23:	push   rsi
      24:	push   r10
      26:	push   r11
      28:	mov    rdx,QWORD PTR [rsp+0x20]
      2d:	mov    r10d,edx
      30:	and    r10d,0xc000
      37:	shl    r10d,0x10
      3b:	mov    r11d,edx
      3e:	and    r11d,0x100
      45:	shl    r11d,0x15
      49:	or     r10d,r11d
      4c:	and    edx,0x1
      4f:	shl    edx,0x1c
      52:	or     r10d,edx
      55:	btc    r10,0x1d
      5a:	mov    r11d,0xf0000000
      60:	and    r11,r10
      63:	movabs rsi,0xffffffff0fffffff
      6d:	and    rbx,rsi
      70:	or     rbx,r11
      73:	pop    r11
      75:	pop    r10
      77:	pop    rsi
      78:	pop    rdx
      79:	mov    QWORD PTR [r12+0x108],rbx
      81:	mov    eax,0x410168
      86:	mov    QWORD PTR [r12+0x100],rax
      8e:	add    rsp,0x150
      95:	mov    eax,0x3
      9a:	movabs r11,0x63ec266e1ca0
      a4:	jmp    r11
      a7:	mov    r13d,0x420000
      ad:	mov    QWORD PTR [r12+0x40],r13
      b2:	movabs r13,0x100000001
      bc:	mov    r14d,0x0
      c2:	mov    QWORD PTR [r12+0x110],r13
      ca:	mov    QWORD PTR [r12+0x118],r14
      d2:	movabs r13,0x3fa0000000000000
      dc:	mov    QWORD PTR [r12+0x50],r13
      e1:	movabs r13,0x4100000041
      eb:	mov    r14d,0x0
      f1:	mov    QWORD PTR [r12+0x120],r13
      f9:	mov    QWORD PTR [r12+0x128],r14
     101:	mov    r13d,0x4204c0
     107:	mov    r14,QWORD PTR [r13+0x0]
     10b:	mov    r13d,0x0
     111:	mov    QWORD PTR [r12+0x130],r14
     119:	mov    QWORD PTR [r12+0x138],r13
     121:	movabs r13,0x3fc0000000000000
     12b:	movabs r14,0x3fc0000000000000
     135:	mov    QWORD PTR [r12+0x140],r13
     13d:	mov    QWORD PTR [r12+0x148],r14
     145:	mov    r13d,0x2
     14b:	mov    QWORD PTR [r12+0x40],r13
     150:	movabs r13,0x200000002
     15a:	mov    r14d,0x0
     160:	mov    QWORD PTR [r12+0x150],r13
     168:	mov    QWORD PTR [r12+0x158],r14
     170:	mov    r13d,0x420000
     176:	mov    QWORD PTR [r12+0x58],r13
     17b:	movabs r13,0x3fa0000000000000
     185:	mov    QWORD PTR [r12+0x160],r13
     18d:	mov    QWORD PTR [r12+0x168],r13
     195:	mov    r13d,0x2
     19b:	mov    QWORD PTR [r12+0x170],r13
     1a3:	mov    QWORD PTR [r12+0x178],r13
     1ab:	mov    r13d,0x4204d0
     1b1:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     1b7:	movdqu XMMWORD PTR [r12+0x180],xmm2
     1c1:	mov    r13d,0x0
     1c7:	mov    QWORD PTR [r12+0x48],r13
     1cc:	mov    r13d,0x430000
     1d2:	add    r13,0x518
     1d9:	mov    QWORD PTR [r12+0x40],r13
     1de:	mov    r13d,0x430000
     1e4:	add    r13,0x720
     1eb:	mov    QWORD PTR [r12+0x50],r13
     1f0:	mov    r11,rax
     1f3:	movzx  eax,WORD PTR [rsp]
     1f7:	add    al,0x7f
     1f9:	sahf
     1fa:	mov    rax,r11
     1fd:	jmp    0x202
     202:	mov    r13,QWORD PTR [r12+0x180]
     20a:	mov    r14,QWORD PTR [r12+0x188]
     212:	mov    r15d,0x0
     218:	mov    r11,rax
     21b:	lahf
     21c:	seto   al
     21f:	mov    WORD PTR [rsp],ax
     223:	mov    rax,r11
     226:	mov    ecx,0xffffffff
     22b:	and    r13,rcx
     22e:	mov    rbp,r15
     231:	or     rbp,r13
     234:	mov    ecx,0xffffffff
     239:	and    r14,rcx
     23c:	shl    r14,0x20
     240:	or     rbp,r14
     243:	mov    QWORD PTR [r12+0x210],rbp
     24b:	mov    QWORD PTR [r12+0x218],r15
     253:	movdqu xmm2,XMMWORD PTR [r12+0x120]
     25d:	movdqu xmm3,XMMWORD PTR [r12+0x130]
     267:	movdqa xmm1,xmm3
     26b:	psubd  xmm2,xmm1
     26f:	movdqa xmm14,xmm2
     274:	movdqa xmm1,xmm14
     279:	movq   rax,xmm1
     27e:	mov    r13,rax
     281:	movdqu xmm2,XMMWORD PTR [r12+0x180]
     28b:	movdqu xmm4,XMMWORD PTR [r12+0x170]
     295:	movdqa xmm1,xmm4
     299:	paddq  xmm2,xmm1
     29d:	movdqu XMMWORD PTR [r12+0x180],xmm2
     2a7:	movdqu xmm2,XMMWORD PTR [r12+0x150]
     2b1:	movdqa xmm1,xmm2
     2b5:	paddd  xmm3,xmm1
     2b9:	movdqa xmm14,xmm3
     2be:	movdqa xmm1,xmm14
     2c3:	movq   rax,xmm1
     2c8:	mov    r14,rax
     2cb:	mov    r15d,0x0
     2d1:	mov    QWORD PTR [r12+0x130],r14
     2d9:	mov    QWORD PTR [r12+0x138],r15
     2e1:	mov    r14d,0x0
     2e7:	mov    ecx,0xffffffff
     2ec:	mov    r15,r13
     2ef:	and    r15,rcx
     2f2:	mov    rbp,r14
     2f5:	or     rbp,r15
     2f8:	shr    r13,0x20
     2fc:	mov    ecx,0xffffffff
     301:	and    r13,rcx
     304:	or     r14,r13
     307:	mov    QWORD PTR [r12+0x220],rbp
     30f:	mov    QWORD PTR [r12+0x228],r14
     317:	movdqu xmm2,XMMWORD PTR [r12+0x210]
     321:	movdqu xmm3,XMMWORD PTR [r12+0x110]
     32b:	movdqa xmm1,xmm3
     32f:	paddd  xmm2,xmm1
     333:	movdqa xmm14,xmm2
     338:	movdqa xmm1,xmm14
     33d:	movq   rax,xmm1
     342:	mov    r13,rax
     345:	mov    r14d,0x0
     34b:	mov    QWORD PTR [r12+0x210],r13
     353:	mov    QWORD PTR [r12+0x218],r14
     35b:	lea    r13,[r12]
     35f:	movabs r14,0xb6e61da31
     369:	mov    r15d,0x4101c4
     36f:	mov    rdx,QWORD PTR [rsp]
     373:	mov    r10d,edx
     376:	and    r10d,0xc000
     37d:	shl    r10d,0x10
     381:	mov    r11d,edx
     384:	and    r11d,0x100
     38b:	shl    r11d,0x15
     38f:	or     r10d,r11d
     392:	and    edx,0x1
     395:	shl    edx,0x1c
     398:	or     r10d,edx
     39b:	btc    r10,0x1d
     3a0:	mov    r11d,0xf0000000
     3a6:	and    r11,r10
     3a9:	movabs rsi,0xffffffff0fffffff
     3b3:	and    rbx,rsi
     3b6:	or     rbx,r11
     3b9:	mov    QWORD PTR [r12+0x378],0x3
     3c5:	mov    QWORD PTR [r12+0x108],rbx
     3cd:	stmxcsr DWORD PTR [r12-0x28]
     3d3:	mov    r10d,DWORD PTR [r12-0x28]
     3d8:	test   r10d,0x3f
     3df:	je     0x404
     3e5:	mov    r11d,r10d
     3e8:	shr    r10d,1
     3eb:	and    r10d,0x1e
     3ef:	and    r11d,0x1
     3f3:	or     r10d,r11d
     3f6:	or     DWORD PTR [r12+0x314],r10d
     3fe:	and    DWORD PTR [r12-0x28],0xffffffc0
     404:	ldmxcsr DWORD PTR [r12-0x38]
     40a:	movabs r11,0x63ec265435e0
     414:	mov    rdi,r13
     417:	mov    rsi,r14
     41a:	mov    rdx,r15
     41d:	call   r11
     420:	ldmxcsr DWORD PTR [r12-0x28]
     426:	mov    rbx,QWORD PTR [r12+0x108]
     42e:	mov    QWORD PTR [r12+0x378],0x2
     43a:	mov    rbp,rax
     43d:	mov    r13,QWORD PTR [r12+0x210]
     445:	mov    r14d,0x0
     44b:	mov    ecx,0xffffffff
     450:	mov    r15,r13
     453:	and    r15,rcx
     456:	mov    rbp,r14
     459:	or     rbp,r15
     45c:	shr    r13,0x20
     460:	mov    ecx,0xffffffff
     465:	and    r13,rcx
     468:	or     r14,r13
     46b:	mov    QWORD PTR [r12+0x210],rbp
     473:	mov    QWORD PTR [r12+0x218],r14
     47b:	lea    r13,[r12]
     47f:	movabs r14,0xb6e61da10
     489:	mov    r15d,0x4101cc
     48f:	mov    QWORD PTR [r12+0x378],0x3
     49b:	mov    QWORD PTR [r12+0x108],rbx
     4a3:	stmxcsr DWORD PTR [r12-0x28]
     4a9:	mov    r10d,DWORD PTR [r12-0x28]
     4ae:	test   r10d,0x3f
     4b5:	je     0x4da
     4bb:	mov    r11d,r10d
     4be:	shr    r10d,1
     4c1:	and    r10d,0x1e
     4c5:	and    r11d,0x1
     4c9:	or     r10d,r11d
     4cc:	or     DWORD PTR [r12+0x314],r10d
     4d4:	and    DWORD PTR [r12-0x28],0xffffffc0
     4da:	ldmxcsr DWORD PTR [r12-0x38]
     4e0:	movabs r11,0x63ec265435e0
     4ea:	mov    rdi,r13
     4ed:	mov    rsi,r14
     4f0:	mov    rdx,r15
     4f3:	call   r11
     4f6:	ldmxcsr DWORD PTR [r12-0x28]
     4fc:	mov    rbx,QWORD PTR [r12+0x108]
     504:	mov    QWORD PTR [r12+0x378],0x2
     510:	mov    rbp,rax
     513:	movdqu xmm2,XMMWORD PTR [r12+0x220]
     51d:	movdqu xmm3,XMMWORD PTR [r12+0x140]
     527:	movdqa xmm0,xmm2
     52b:	movdqa xmm1,xmm3
     52f:	mulpd  xmm0,xmm1
     533:	movdqa xmm14,xmm0
     538:	movdqu xmm15,XMMWORD PTR [rip+0x9d4f]        # 0xa290
     541:	pand   xmm14,xmm15
     546:	movdqu xmm15,XMMWORD PTR [rip+0x9d51]        # 0xa2a0
     54f:	pcmpeqq xmm14,xmm15
     555:	movdqa xmm15,xmm0
     55a:	cmpunordpd xmm15,xmm0
     560:	por    xmm14,xmm15
     565:	pmovmskb ecx,xmm14
     56a:	jrcxz  0x571
     56c:	jmp    0x2bee
     571:	movdqa xmm4,xmm0
     575:	movdqu XMMWORD PTR [r12+0x220],xmm4
     57f:	mov    r13,QWORD PTR [r12+0x48]
     584:	mov    r14,QWORD PTR [r12+0x50]
     589:	add    r14,r13
     58c:	movdqu XMMWORD PTR [r14],xmm4
     591:	mov    r14d,0x0
     597:	mov    DWORD PTR [r12+0x32c],r14d
     59f:	movdqu xmm2,XMMWORD PTR [r12+0x210]
     5a9:	movdqu xmm3,XMMWORD PTR [r12+0x160]
     5b3:	movdqa xmm0,xmm2
     5b7:	movdqa xmm1,xmm3
     5bb:	mulpd  xmm0,xmm1
     5bf:	movdqa xmm14,xmm0
     5c4:	movdqu xmm15,XMMWORD PTR [rip+0x9cc3]        # 0xa290
     5cd:	pand   xmm14,xmm15
     5d2:	movdqu xmm15,XMMWORD PTR [rip+0x9cc5]        # 0xa2a0
     5db:	pcmpeqq xmm14,xmm15
     5e1:	movdqa xmm15,xmm0
     5e6:	cmpunordpd xmm15,xmm0
     5ec:	por    xmm14,xmm15
     5f1:	pmovmskb ecx,xmm14
     5f6:	jrcxz  0x5fd
     5f8:	jmp    0x2c12
     5fd:	movdqa xmm4,xmm0
     601:	movdqu XMMWORD PTR [r12+0x210],xmm4
     60b:	mov    r14,QWORD PTR [r12+0x40]
     610:	add    r14,r13
     613:	movdqu XMMWORD PTR [r14],xmm4
     618:	add    r13,0x10
     61c:	mov    QWORD PTR [r12+0x48],r13
     621:	sub    r13,0x200
     628:	mov    rcx,QWORD PTR [r12+0x380]
     630:	jrcxz  0x637
     632:	jmp    0x9a25
     637:	jne    0x202
     63d:	mov    r11,rax
     640:	lahf
     641:	seto   al
     644:	mov    WORD PTR [rsp],ax
     648:	mov    rax,r11
     64b:	jmp    0x650
     650:	mov    r13,QWORD PTR [r12+0xf8]
     658:	sub    r13,0x150
     65f:	mov    QWORD PTR [r12+0xf8],r13
     667:	mov    r14,QWORD PTR [r12+0x50]
     66c:	mov    r15,r14
     66f:	add    r15,0x80
     676:	mov    rbp,r15
     679:	add    rbp,0x10
     67d:	movdqu xmm2,XMMWORD PTR [r15]
     682:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     687:	movdqu XMMWORD PTR [r12+0x130],xmm2
     691:	movdqu XMMWORD PTR [r12+0x110],xmm3
     69b:	mov    r15d,0x0
     6a1:	mov    QWORD PTR [r12+0x48],r15
     6a6:	mov    r15,r14
     6a9:	add    r15,0x40
     6ad:	mov    rbp,r15
     6b0:	add    rbp,0x10
     6b4:	movdqu xmm4,XMMWORD PTR [r15]
     6b9:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
     6be:	movdqu XMMWORD PTR [r12+0x250],xmm4
     6c8:	movdqu XMMWORD PTR [r12+0x120],xmm5
     6d2:	mov    r15,r13
     6d5:	add    r15,0x120
     6dc:	mov    rbp,r15
     6df:	add    rbp,0x8
     6e3:	mov    r8,QWORD PTR [r12+0x1c0]
     6eb:	mov    r9,QWORD PTR [r12+0x1b0]
     6f3:	mov    QWORD PTR [r15],r8
     6f6:	mov    r15d,0x0
     6fc:	mov    DWORD PTR [r12+0x32c],r15d
     704:	mov    QWORD PTR [rbp+0x0],r9
     708:	mov    r15d,0x0
     70e:	mov    ebp,0x0
     713:	mov    QWORD PTR [r12+0x1b0],r15
     71b:	mov    QWORD PTR [r12+0x1b8],rbp
     723:	mov    r15,r13
     726:	add    r15,0x100
     72d:	mov    rbp,r15
     730:	add    rbp,0x8
     734:	mov    r8,QWORD PTR [r12+0x200]
     73c:	mov    r9,QWORD PTR [r12+0x1f0]
     744:	mov    QWORD PTR [r15],r8
     747:	mov    QWORD PTR [rbp+0x0],r9
     74b:	mov    r15,r13
     74e:	add    r15,0xe0
     755:	mov    rbp,r15
     758:	add    rbp,0x10
     75c:	movdqu XMMWORD PTR [r15],xmm3
     761:	movdqu XMMWORD PTR [rbp+0x0],xmm2
     766:	mov    r15,r14
     769:	add    r15,0xc0
     770:	mov    rbp,r15
     773:	add    rbp,0x10
     777:	movdqu xmm2,XMMWORD PTR [r15]
     77c:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     781:	movdqu XMMWORD PTR [r12+0x130],xmm2
     78b:	movdqu XMMWORD PTR [r12+0x110],xmm3
     795:	mov    r15,r13
     798:	add    r15,0x110
     79f:	mov    rbp,r15
     7a2:	add    rbp,0x8
     7a6:	mov    r8,QWORD PTR [r12+0x1e0]
     7ae:	mov    r9,QWORD PTR [r12+0x1d0]
     7b6:	mov    QWORD PTR [r15],r8
     7b9:	mov    QWORD PTR [rbp+0x0],r9
     7bd:	mov    r15,r14
     7c0:	add    r15,0x10
     7c4:	movdqu xmm4,XMMWORD PTR [r14]
     7c9:	movdqu xmm6,XMMWORD PTR [r15]
     7ce:	movdqu XMMWORD PTR [r12+0x170],xmm4
     7d8:	movdqu XMMWORD PTR [r12+0x180],xmm6
     7e2:	mov    r15,r13
     7e5:	add    r15,0x130
     7ec:	mov    rbp,r15
     7ef:	add    rbp,0x8
     7f3:	mov    r8,QWORD PTR [r12+0x1a0]
     7fb:	mov    r9,QWORD PTR [r12+0x190]
     803:	mov    QWORD PTR [r15],r8
     806:	mov    QWORD PTR [rbp+0x0],r9
     80a:	mov    r15,r14
     80d:	add    r15,0x140
     814:	mov    rbp,r15
     817:	add    rbp,0x10
     81b:	movdqu xmm7,XMMWORD PTR [r15]
     820:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
     826:	movdqu XMMWORD PTR [r12+0x270],xmm7
     830:	movdqu XMMWORD PTR [r12+0x190],xmm8
     83a:	mov    r15,r13
     83d:	add    r15,0xc0
     844:	mov    rbp,r15
     847:	add    rbp,0x10
     84b:	movdqu XMMWORD PTR [r15],xmm3
     850:	movdqu XMMWORD PTR [rbp+0x0],xmm2
     855:	mov    r15,r14
     858:	add    r15,0x100
     85f:	mov    rbp,r15
     862:	add    rbp,0x10
     866:	movdqu xmm2,XMMWORD PTR [r15]
     86b:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     870:	movdqu XMMWORD PTR [r12+0x110],xmm2
     87a:	movdqu XMMWORD PTR [r12+0x300],xmm3
     884:	mov    r15,r13
     887:	add    r15,0x140
     88e:	mov    rbp,QWORD PTR [r12+0xe8]
     896:	mov    QWORD PTR [r15],rbp
     899:	mov    r15,r14
     89c:	add    r15,0x180
     8a3:	mov    rbp,r15
     8a6:	add    rbp,0x10
     8aa:	movdqu xmm3,XMMWORD PTR [r15]
     8af:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
     8b4:	movdqu XMMWORD PTR [r12+0x2a0],xmm3
     8be:	movdqu XMMWORD PTR [r12+0x1a0],xmm7
     8c8:	mov    r15,r14
     8cb:	add    r15,0x1c0
     8d2:	mov    rbp,r15
     8d5:	add    rbp,0x10
     8d9:	movdqu xmm3,XMMWORD PTR [r15]
     8de:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
     8e3:	movdqu XMMWORD PTR [r12+0x240],xmm3
     8ed:	movdqu XMMWORD PTR [r12+0x1c0],xmm7
     8f7:	mov    r15,r13
     8fa:	add    r15,0x20
     8fe:	mov    rbp,r15
     901:	add    rbp,0x10
     905:	movdqu XMMWORD PTR [r15],xmm2
     90a:	movdqu XMMWORD PTR [rbp+0x0],xmm5
     90f:	mov    r15,r14
     912:	add    r15,0x60
     916:	mov    rbp,r15
     919:	add    rbp,0x10
     91d:	movdqu xmm2,XMMWORD PTR [r15]
     922:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
     927:	movdqu XMMWORD PTR [r12+0x110],xmm2
     931:	movdqu XMMWORD PTR [r12+0x120],xmm5
     93b:	mov    r15,r14
     93e:	add    r15,0x20
     942:	mov    rbp,r15
     945:	add    rbp,0x10
     949:	movdqu xmm7,XMMWORD PTR [r15]
     94e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
     954:	movdqu XMMWORD PTR [r12+0x1d0],xmm7
     95e:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
     968:	mov    r15,r13
     96b:	add    r15,0x60
     96f:	mov    rbp,r15
     972:	add    rbp,0x10
     976:	movdqu XMMWORD PTR [r15],xmm4
     97b:	movdqu XMMWORD PTR [rbp+0x0],xmm3
     980:	mov    r15,r14
     983:	add    r15,0xe0
     98a:	mov    rbp,r15
     98d:	add    rbp,0x10
     991:	movdqu xmm3,XMMWORD PTR [r15]
     996:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
     99b:	movdqu XMMWORD PTR [r12+0x200],xmm3
     9a5:	movdqu XMMWORD PTR [r12+0x2d0],xmm4
     9af:	mov    r15,r13
     9b2:	add    r15,0xa0
     9b9:	mov    rbp,r15
     9bc:	add    rbp,0x10
     9c0:	movdqu XMMWORD PTR [r15],xmm5
     9c5:	movdqu XMMWORD PTR [rbp+0x0],xmm2
     9ca:	mov    r15,r14
     9cd:	add    r15,0xa0
     9d4:	mov    rbp,r15
     9d7:	add    rbp,0x10
     9db:	movdqu xmm2,XMMWORD PTR [r15]
     9e0:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     9e5:	movdqu XMMWORD PTR [r12+0x110],xmm2
     9ef:	movdqu XMMWORD PTR [r12+0x120],xmm3
     9f9:	mov    r15,r14
     9fc:	add    r15,0x120
     a03:	mov    rbp,r15
     a06:	add    rbp,0x10
     a0a:	movdqu xmm4,XMMWORD PTR [r15]
     a0f:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
     a14:	movdqu XMMWORD PTR [r12+0x2e0],xmm4
     a1e:	movdqu XMMWORD PTR [r12+0x2f0],xmm5
     a28:	mov    r15,r14
     a2b:	add    r15,0x160
     a32:	mov    rbp,r15
     a35:	add    rbp,0x10
     a39:	movdqu xmm4,XMMWORD PTR [r15]
     a3e:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
     a43:	movdqu XMMWORD PTR [r12+0x2c0],xmm4
     a4d:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
     a57:	mov    r15,r13
     a5a:	add    r15,0x80
     a61:	mov    rbp,r15
     a64:	add    rbp,0x10
     a68:	movdqu XMMWORD PTR [r15],xmm3
     a6d:	movdqu XMMWORD PTR [rbp+0x0],xmm2
     a72:	mov    r15,r14
     a75:	add    r15,0x1a0
     a7c:	mov    rbp,r15
     a7f:	add    rbp,0x10
     a83:	movdqu xmm2,XMMWORD PTR [r15]
     a88:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     a8d:	movdqu XMMWORD PTR [r12+0x290],xmm2
     a97:	movdqu XMMWORD PTR [r12+0x1e0],xmm3
     aa1:	add    r14,0x1e0
     aa8:	mov    r15,r14
     aab:	add    r15,0x10
     aaf:	movdqu xmm2,XMMWORD PTR [r14]
     ab4:	movdqu xmm3,XMMWORD PTR [r15]
     ab9:	movdqu XMMWORD PTR [r12+0x230],xmm2
     ac3:	movdqu XMMWORD PTR [r12+0x280],xmm3
     acd:	mov    r14d,0x430000
     ad3:	add    r14,0x920
     ada:	mov    QWORD PTR [r12+0x50],r14
     adf:	mov    r14,r13
     ae2:	add    r14,0x40
     ae6:	mov    r15,r14
     ae9:	add    r15,0x10
     aed:	movdqu XMMWORD PTR [r14],xmm4
     af2:	movdqu XMMWORD PTR [r15],xmm6
     af7:	mov    r14,r13
     afa:	add    r14,0x10
     afe:	movdqu XMMWORD PTR [r13+0x0],xmm3
     b04:	movdqu XMMWORD PTR [r14],xmm2
     b09:	mov    r11,rax
     b0c:	movzx  eax,WORD PTR [rsp]
     b10:	add    al,0x7f
     b12:	sahf
     b13:	mov    rax,r11
     b16:	jmp    0xb1b
     b1b:	mov    r13d,0x0
     b21:	mov    QWORD PTR [r12+0x58],r13
     b26:	mov    r11,rax
     b29:	lahf
     b2a:	seto   al
     b2d:	mov    WORD PTR [rsp],ax
     b31:	mov    rax,r11
     b34:	jmp    0xb39
     b39:	mov    r13,QWORD PTR [r12+0x58]
     b3e:	mov    r14,QWORD PTR [r12+0x40]
     b43:	add    r14,r13
     b46:	mov    QWORD PTR [r12+0x60],r14
     b4b:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
     b55:	movdqa xmm0,xmm2
     b59:	movdqa xmm1,xmm2
     b5d:	por    xmm0,xmm1
     b61:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
     b6b:	movdqu xmm4,XMMWORD PTR [r12+0x1a0]
     b75:	movdqa xmm0,xmm4
     b79:	movdqa xmm1,xmm4
     b7d:	por    xmm0,xmm1
     b81:	movdqu XMMWORD PTR [r12+0x120],xmm0
     b8b:	mov    r15,r14
     b8e:	add    r15,0x30
     b92:	mov    rbp,r15
     b95:	add    rbp,0x8
     b99:	mov    r8,QWORD PTR [r15]
     b9c:	mov    r15,QWORD PTR [rbp+0x0]
     ba0:	mov    ebp,0x0
     ba5:	mov    QWORD PTR [r12+0x130],r8
     bad:	mov    QWORD PTR [r12+0x138],rbp
     bb5:	mov    ebp,0x0
     bba:	mov    QWORD PTR [r12+0x280],r15
     bc2:	mov    QWORD PTR [r12+0x288],rbp
     bca:	movdqu xmm5,XMMWORD PTR [r12+0x270]
     bd4:	movdqa xmm0,xmm5
     bd8:	movdqa xmm1,xmm5
     bdc:	por    xmm0,xmm1
     be0:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
     bea:	mov    r15,r14
     bed:	add    r15,0x20
     bf1:	mov    rbp,r15
     bf4:	add    rbp,0x8
     bf8:	mov    r8,QWORD PTR [r15]
     bfb:	mov    r15,QWORD PTR [rbp+0x0]
     bff:	mov    ebp,0x0
     c04:	mov    QWORD PTR [r12+0x150],r8
     c0c:	mov    QWORD PTR [r12+0x158],rbp
     c14:	mov    ebp,0x0
     c19:	mov    QWORD PTR [r12+0x140],r15
     c21:	mov    QWORD PTR [r12+0x148],rbp
     c29:	mov    r15,r14
     c2c:	add    r15,0x10
     c30:	mov    rbp,r15
     c33:	add    rbp,0x8
     c37:	mov    r8,QWORD PTR [r15]
     c3a:	mov    r15,QWORD PTR [rbp+0x0]
     c3e:	mov    ebp,0x0
     c43:	mov    QWORD PTR [r12+0x170],r8
     c4b:	mov    QWORD PTR [r12+0x178],rbp
     c53:	mov    ebp,0x0
     c58:	mov    QWORD PTR [r12+0x160],r15
     c60:	mov    QWORD PTR [r12+0x168],rbp
     c68:	mov    r15d,0x8
     c6e:	mov    rbp,QWORD PTR [r14]
     c71:	mov    QWORD PTR [r12+0x180],rbp
     c79:	mov    QWORD PTR [r12+0x188],rbp
     c81:	add    r14,r15
     c84:	mov    QWORD PTR [r12+0x60],r14
     c89:	mov    r15,QWORD PTR [r14]
     c8c:	mov    r14d,0x0
     c92:	mov    QWORD PTR [r12+0x230],r15
     c9a:	mov    QWORD PTR [r12+0x238],r14
     ca2:	mov    r14,QWORD PTR [r12+0xf8]
     caa:	mov    r15,r14
     cad:	add    r15,0x50
     cb1:	mov    rbp,r15
     cb4:	add    rbp,0x10
     cb8:	movdqu xmm6,XMMWORD PTR [r15]
     cbd:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
     cc2:	movdqu XMMWORD PTR [r12+0x220],xmm6
     ccc:	movdqu XMMWORD PTR [r12+0x210],xmm7
     cd6:	mov    r15,r14
     cd9:	add    r15,0x30
     cdd:	movdqu xmm8,XMMWORD PTR [r15]
     ce2:	movdqu XMMWORD PTR [r12+0x110],xmm8
     cec:	mov    r15,QWORD PTR [r12+0x50]
     cf1:	add    r15,r13
     cf4:	mov    QWORD PTR [r12+0x60],r15
     cf9:	add    r13,0x40
     cfd:	mov    QWORD PTR [r12+0x58],r13
     d02:	movdqu xmm9,XMMWORD PTR [r12+0x180]
     d0c:	movdqa xmm0,xmm9
     d11:	movdqa xmm1,xmm2
     d15:	mulpd  xmm0,xmm1
     d19:	movdqa xmm14,xmm0
     d1e:	movdqu xmm15,XMMWORD PTR [rip+0x9569]        # 0xa290
     d27:	pand   xmm14,xmm15
     d2c:	movdqu xmm15,XMMWORD PTR [rip+0x956b]        # 0xa2a0
     d35:	pcmpeqq xmm14,xmm15
     d3b:	movdqa xmm15,xmm0
     d40:	cmpunordpd xmm15,xmm0
     d46:	por    xmm14,xmm15
     d4b:	pmovmskb ecx,xmm14
     d50:	jrcxz  0xd57
     d52:	jmp    0x2c36
     d57:	movdqa xmm10,xmm0
     d5c:	movdqu xmm2,XMMWORD PTR [r12+0x230]
     d66:	movdqa xmm0,xmm8
     d6b:	movdqa xmm1,xmm2
     d6f:	pshufd xmm1,xmm1,0x44
     d74:	mulpd  xmm0,xmm1
     d78:	movdqa xmm14,xmm0
     d7d:	movdqu xmm15,XMMWORD PTR [rip+0x950a]        # 0xa290
     d86:	pand   xmm14,xmm15
     d8b:	movdqu xmm15,XMMWORD PTR [rip+0x950c]        # 0xa2a0
     d94:	pcmpeqq xmm14,xmm15
     d9a:	movdqa xmm15,xmm0
     d9f:	cmpunordpd xmm15,xmm0
     da5:	por    xmm14,xmm15
     daa:	pmovmskb ecx,xmm14
     daf:	jrcxz  0xdb6
     db1:	jmp    0x2c5b
     db6:	movdqa xmm11,xmm0
     dbb:	movdqu XMMWORD PTR [r12+0x260],xmm11
     dc5:	mov    ebp,0x0
     dca:	mov    r8d,0x0
     dd0:	mov    QWORD PTR [r12+0x110],rbp
     dd8:	mov    QWORD PTR [r12+0x118],r8
     de0:	movdqa xmm0,xmm9
     de5:	movdqa xmm1,xmm7
     de9:	mulpd  xmm0,xmm1
     ded:	movdqa xmm14,xmm0
     df2:	movdqu xmm15,XMMWORD PTR [rip+0x9495]        # 0xa290
     dfb:	pand   xmm14,xmm15
     e00:	movdqu xmm15,XMMWORD PTR [rip+0x9497]        # 0xa2a0
     e09:	pcmpeqq xmm14,xmm15
     e0f:	movdqa xmm15,xmm0
     e14:	cmpunordpd xmm15,xmm0
     e1a:	por    xmm14,xmm15
     e1f:	pmovmskb ecx,xmm14
     e24:	jrcxz  0xe2b
     e26:	jmp    0x2c80
     e2b:	movdqa xmm8,xmm0
     e30:	movdqa xmm0,xmm9
     e35:	movdqa xmm1,xmm6
     e39:	mulpd  xmm0,xmm1
     e3d:	movdqa xmm14,xmm0
     e42:	movdqu xmm15,XMMWORD PTR [rip+0x9445]        # 0xa290
     e4b:	pand   xmm14,xmm15
     e50:	movdqu xmm15,XMMWORD PTR [rip+0x9447]        # 0xa2a0
     e59:	pcmpeqq xmm14,xmm15
     e5f:	movdqa xmm15,xmm0
     e64:	cmpunordpd xmm15,xmm0
     e6a:	por    xmm14,xmm15
     e6f:	pmovmskb ecx,xmm14
     e74:	jrcxz  0xe7b
     e76:	jmp    0x2ca5
     e7b:	movdqa xmm7,xmm0
     e7f:	movdqu xmm6,XMMWORD PTR [r12+0x1f0]
     e89:	movdqa xmm0,xmm9
     e8e:	movdqa xmm1,xmm6
     e92:	mulpd  xmm0,xmm1
     e96:	movdqa xmm14,xmm0
     e9b:	movdqu xmm15,XMMWORD PTR [rip+0x93ec]        # 0xa290
     ea4:	pand   xmm14,xmm15
     ea9:	movdqu xmm15,XMMWORD PTR [rip+0x93ee]        # 0xa2a0
     eb2:	pcmpeqq xmm14,xmm15
     eb8:	movdqa xmm15,xmm0
     ebd:	cmpunordpd xmm15,xmm0
     ec3:	por    xmm14,xmm15
     ec8:	pmovmskb ecx,xmm14
     ecd:	jrcxz  0xed4
     ecf:	jmp    0x2cca
     ed4:	movdqa xmm12,xmm0
     ed9:	movdqu XMMWORD PTR [r12+0x180],xmm12
     ee3:	movdqu xmm6,XMMWORD PTR [r12+0x2a0]
     eed:	movdqa xmm0,xmm6
     ef1:	movdqa xmm1,xmm6
     ef5:	por    xmm0,xmm1
     ef9:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
     f03:	movdqu xmm9,XMMWORD PTR [r12+0x250]
     f0d:	movdqa xmm0,xmm9
     f12:	movdqa xmm1,xmm9
     f17:	por    xmm0,xmm1
     f1b:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
     f25:	movdqa xmm0,xmm9
     f2a:	movdqa xmm1,xmm2
     f2e:	pshufd xmm1,xmm1,0x44
     f33:	mulpd  xmm0,xmm1
     f37:	movdqa xmm14,xmm0
     f3c:	movdqu xmm15,XMMWORD PTR [rip+0x934b]        # 0xa290
     f45:	pand   xmm14,xmm15
     f4a:	movdqu xmm15,XMMWORD PTR [rip+0x934d]        # 0xa2a0
     f53:	pcmpeqq xmm14,xmm15
     f59:	movdqa xmm15,xmm0
     f5e:	cmpunordpd xmm15,xmm0
     f64:	por    xmm14,xmm15
     f69:	pmovmskb ecx,xmm14
     f6e:	jrcxz  0xf75
     f70:	jmp    0x2cef
     f75:	movdqa xmm4,xmm0
     f79:	movdqu XMMWORD PTR [r12+0x250],xmm4
     f83:	sub    r13,0x200
     f8a:	movdqu xmm9,XMMWORD PTR [r12+0x110]
     f94:	movdqa xmm0,xmm10
     f99:	movdqa xmm1,xmm9
     f9e:	addpd  xmm0,xmm1
     fa2:	movdqa xmm14,xmm0
     fa7:	movdqu xmm15,XMMWORD PTR [rip+0x92e0]        # 0xa290
     fb0:	pand   xmm14,xmm15
     fb5:	movdqu xmm15,XMMWORD PTR [rip+0x92e2]        # 0xa2a0
     fbe:	pcmpeqq xmm14,xmm15
     fc4:	movdqa xmm15,xmm0
     fc9:	cmpunordpd xmm15,xmm0
     fcf:	por    xmm14,xmm15
     fd4:	pmovmskb ecx,xmm14
     fd9:	jrcxz  0xfe0
     fdb:	jmp    0x2d14
     fe0:	movdqu XMMWORD PTR [r12+0x240],xmm0
     fea:	movdqu xmm10,XMMWORD PTR [r12+0x1b0]
     ff4:	movdqa xmm0,xmm8
     ff9:	movdqa xmm1,xmm10
     ffe:	addpd  xmm0,xmm1
    1002:	movdqa xmm14,xmm0
    1007:	movdqu xmm15,XMMWORD PTR [rip+0x9280]        # 0xa290
    1010:	pand   xmm14,xmm15
    1015:	movdqu xmm15,XMMWORD PTR [rip+0x9282]        # 0xa2a0
    101e:	pcmpeqq xmm14,xmm15
    1024:	movdqa xmm15,xmm0
    1029:	cmpunordpd xmm15,xmm0
    102f:	por    xmm14,xmm15
    1034:	pmovmskb ecx,xmm14
    1039:	jrcxz  0x1040
    103b:	jmp    0x2d55
    1040:	movdqa xmm6,xmm0
    1044:	movdqu XMMWORD PTR [r12+0x210],xmm6
    104e:	movdqa xmm0,xmm7
    1052:	movdqa xmm1,xmm10
    1057:	addpd  xmm0,xmm1
    105b:	movdqa xmm14,xmm0
    1060:	movdqu xmm15,XMMWORD PTR [rip+0x9227]        # 0xa290
    1069:	pand   xmm14,xmm15
    106e:	movdqu xmm15,XMMWORD PTR [rip+0x9229]        # 0xa2a0
    1077:	pcmpeqq xmm14,xmm15
    107d:	movdqa xmm15,xmm0
    1082:	cmpunordpd xmm15,xmm0
    1088:	por    xmm14,xmm15
    108d:	pmovmskb ecx,xmm14
    1092:	jrcxz  0x1099
    1094:	jmp    0x2d96
    1099:	movdqa xmm8,xmm0
    109e:	movdqu XMMWORD PTR [r12+0x220],xmm8
    10a8:	movdqu xmm7,XMMWORD PTR [r12+0x2f0]
    10b2:	setne  BYTE PTR [rsp+0x8]
    10b7:	mov    r11,rax
    10ba:	lahf
    10bb:	seto   al
    10be:	mov    WORD PTR [rsp],ax
    10c2:	mov    rax,r11
    10c5:	movdqa xmm0,xmm7
    10c9:	movdqa xmm1,xmm7
    10cd:	por    xmm0,xmm1
    10d1:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    10db:	movdqu xmm10,XMMWORD PTR [r12+0x2e0]
    10e5:	movdqa xmm0,xmm10
    10ea:	movdqa xmm1,xmm10
    10ef:	por    xmm0,xmm1
    10f3:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    10fd:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    1107:	movdqa xmm0,xmm13
    110c:	movdqa xmm1,xmm13
    1111:	por    xmm0,xmm1
    1115:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    111f:	movdqu xmm5,XMMWORD PTR [r12+0x200]
    1129:	movdqa xmm0,xmm5
    112d:	movdqa xmm1,xmm5
    1131:	por    xmm0,xmm1
    1135:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    113f:	movdqu xmm7,XMMWORD PTR [r12+0x1c0]
    1149:	movdqa xmm1,xmm7
    114d:	por    xmm7,xmm1
    1151:	movdqu XMMWORD PTR [r12+0x200],xmm7
    115b:	movdqu xmm3,XMMWORD PTR [r12+0x190]
    1165:	movdqa xmm1,xmm3
    1169:	por    xmm3,xmm1
    116d:	movdqu XMMWORD PTR [r12+0x1c0],xmm3
    1177:	movdqu xmm10,XMMWORD PTR [r12+0x300]
    1181:	movdqa xmm1,xmm10
    1186:	por    xmm10,xmm1
    118b:	movdqu XMMWORD PTR [r12+0x190],xmm10
    1195:	mov    r13,r14
    1198:	add    r13,0xa0
    119f:	mov    rbp,r13
    11a2:	add    rbp,0x10
    11a6:	movdqu xmm13,XMMWORD PTR [r13+0x0]
    11ac:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    11b1:	movdqu XMMWORD PTR [r12+0x300],xmm13
    11bb:	movdqu XMMWORD PTR [r12+0x270],xmm5
    11c5:	movdqa xmm0,xmm12
    11ca:	movdqa xmm1,xmm9
    11cf:	addpd  xmm0,xmm1
    11d3:	movdqa xmm14,xmm0
    11d8:	movdqu xmm15,XMMWORD PTR [rip+0x90af]        # 0xa290
    11e1:	pand   xmm14,xmm15
    11e6:	movdqu xmm15,XMMWORD PTR [rip+0x90b1]        # 0xa2a0
    11ef:	pcmpeqq xmm14,xmm15
    11f5:	movdqa xmm15,xmm0
    11fa:	cmpunordpd xmm15,xmm0
    1200:	por    xmm14,xmm15
    1205:	pmovmskb ecx,xmm14
    120a:	jrcxz  0x1211
    120c:	jmp    0x2dd6
    1211:	movdqu XMMWORD PTR [r12+0x180],xmm0
    121b:	mov    r13,r14
    121e:	add    r13,0xf0
    1225:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    122b:	movdqu XMMWORD PTR [r12+0x110],xmm9
    1235:	movdqa xmm0,xmm6
    1239:	movdqa xmm1,xmm4
    123d:	addpd  xmm0,xmm1
    1241:	movdqa xmm14,xmm0
    1246:	movdqu xmm15,XMMWORD PTR [rip+0x9041]        # 0xa290
    124f:	pand   xmm14,xmm15
    1254:	movdqu xmm15,XMMWORD PTR [rip+0x9043]        # 0xa2a0
    125d:	pcmpeqq xmm14,xmm15
    1263:	movdqa xmm15,xmm0
    1268:	cmpunordpd xmm15,xmm0
    126e:	por    xmm14,xmm15
    1273:	pmovmskb ecx,xmm14
    1278:	jrcxz  0x127f
    127a:	jmp    0x2dfc
    127f:	movdqa xmm12,xmm0
    1284:	movdqu XMMWORD PTR [r12+0x210],xmm12
    128e:	movdqa xmm0,xmm8
    1293:	movdqa xmm1,xmm11
    1298:	addpd  xmm0,xmm1
    129c:	movdqa xmm14,xmm0
    12a1:	movdqu xmm15,XMMWORD PTR [rip+0x8fe6]        # 0xa290
    12aa:	pand   xmm14,xmm15
    12af:	movdqu xmm15,XMMWORD PTR [rip+0x8fe8]        # 0xa2a0
    12b8:	pcmpeqq xmm14,xmm15
    12be:	movdqa xmm15,xmm0
    12c3:	cmpunordpd xmm15,xmm0
    12c9:	por    xmm14,xmm15
    12ce:	pmovmskb ecx,xmm14
    12d3:	jrcxz  0x12da
    12d5:	jmp    0x2e20
    12da:	movdqa xmm4,xmm0
    12de:	movdqu XMMWORD PTR [r12+0x220],xmm4
    12e8:	movdqa xmm0,xmm5
    12ec:	movdqa xmm1,xmm2
    12f0:	pshufd xmm1,xmm1,0x44
    12f5:	mulpd  xmm0,xmm1
    12f9:	movdqa xmm14,xmm0
    12fe:	movdqu xmm15,XMMWORD PTR [rip+0x8f89]        # 0xa290
    1307:	pand   xmm14,xmm15
    130c:	movdqu xmm15,XMMWORD PTR [rip+0x8f8b]        # 0xa2a0
    1315:	pcmpeqq xmm14,xmm15
    131b:	movdqa xmm15,xmm0
    1320:	cmpunordpd xmm15,xmm0
    1326:	por    xmm14,xmm15
    132b:	pmovmskb ecx,xmm14
    1330:	jrcxz  0x1337
    1332:	jmp    0x2e46
    1337:	movdqa xmm6,xmm0
    133b:	movdqu XMMWORD PTR [r12+0x270],xmm6
    1345:	movdqu xmm5,XMMWORD PTR [r12+0x170]
    134f:	movdqa xmm0,xmm9
    1354:	movdqa xmm1,xmm5
    1358:	pshufd xmm1,xmm1,0x44
    135d:	mulpd  xmm0,xmm1
    1361:	movdqa xmm14,xmm0
    1366:	movdqu xmm15,XMMWORD PTR [rip+0x8f21]        # 0xa290
    136f:	pand   xmm14,xmm15
    1374:	movdqu xmm15,XMMWORD PTR [rip+0x8f23]        # 0xa2a0
    137d:	pcmpeqq xmm14,xmm15
    1383:	movdqa xmm15,xmm0
    1388:	cmpunordpd xmm15,xmm0
    138e:	por    xmm14,xmm15
    1393:	pmovmskb ecx,xmm14
    1398:	jrcxz  0x139f
    139a:	jmp    0x2e6a
    139f:	movdqa xmm8,xmm0
    13a4:	movdqu XMMWORD PTR [r12+0x250],xmm8
    13ae:	mov    r13,r14
    13b1:	add    r13,0xe0
    13b8:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    13be:	movdqu XMMWORD PTR [r12+0x110],xmm9
    13c8:	movdqa xmm0,xmm13
    13cd:	movdqa xmm1,xmm2
    13d1:	pshufd xmm1,xmm1,0x44
    13d6:	mulpd  xmm0,xmm1
    13da:	movdqa xmm14,xmm0
    13df:	movdqu xmm15,XMMWORD PTR [rip+0x8ea8]        # 0xa290
    13e8:	pand   xmm14,xmm15
    13ed:	movdqu xmm15,XMMWORD PTR [rip+0x8eaa]        # 0xa2a0
    13f6:	pcmpeqq xmm14,xmm15
    13fc:	movdqa xmm15,xmm0
    1401:	cmpunordpd xmm15,xmm0
    1407:	por    xmm14,xmm15
    140c:	pmovmskb ecx,xmm14
    1411:	jrcxz  0x1418
    1413:	jmp    0x2e8f
    1418:	movdqa xmm11,xmm0
    141d:	movdqu XMMWORD PTR [r12+0x230],xmm11
    1427:	movdqa xmm0,xmm10
    142c:	movdqa xmm1,xmm10
    1431:	por    xmm0,xmm1
    1435:	movdqu XMMWORD PTR [r12+0x300],xmm0
    143f:	movdqa xmm0,xmm3
    1443:	movdqa xmm1,xmm3
    1447:	por    xmm0,xmm1
    144b:	movdqu XMMWORD PTR [r12+0x190],xmm0
    1455:	movdqa xmm0,xmm9
    145a:	movdqa xmm1,xmm5
    145e:	pshufd xmm1,xmm1,0x44
    1463:	mulpd  xmm0,xmm1
    1467:	movdqa xmm14,xmm0
    146c:	movdqu xmm15,XMMWORD PTR [rip+0x8e1b]        # 0xa290
    1475:	pand   xmm14,xmm15
    147a:	movdqu xmm15,XMMWORD PTR [rip+0x8e1d]        # 0xa2a0
    1483:	pcmpeqq xmm14,xmm15
    1489:	movdqa xmm15,xmm0
    148e:	cmpunordpd xmm15,xmm0
    1494:	por    xmm14,xmm15
    1499:	pmovmskb ecx,xmm14
    149e:	jrcxz  0x14a5
    14a0:	jmp    0x2eb4
    14a5:	movdqa xmm2,xmm0
    14a9:	movdqu XMMWORD PTR [r12+0x260],xmm2
    14b3:	mov    r13,r14
    14b6:	add    r13,0x90
    14bd:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    14c3:	movdqu XMMWORD PTR [r12+0x110],xmm9
    14cd:	movdqa xmm0,xmm7
    14d1:	movdqa xmm1,xmm7
    14d5:	por    xmm0,xmm1
    14d9:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    14e3:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    14ed:	movdqu xmm1,XMMWORD PTR [r12+0x2d0]
    14f7:	por    xmm13,xmm1
    14fc:	movdqu XMMWORD PTR [r12+0x200],xmm13
    1506:	movdqu xmm7,XMMWORD PTR [r12+0x2e0]
    1510:	movdqu xmm1,XMMWORD PTR [r12+0x2e0]
    151a:	por    xmm7,xmm1
    151e:	movdqu XMMWORD PTR [r12+0x2d0],xmm7
    1528:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    1532:	movdqu xmm1,XMMWORD PTR [r12+0x2f0]
    153c:	por    xmm0,xmm1
    1540:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    154a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    1554:	movdqa xmm1,xmm6
    1558:	addpd  xmm0,xmm1
    155c:	movdqa xmm14,xmm0
    1561:	movdqu xmm15,XMMWORD PTR [rip+0x8d26]        # 0xa290
    156a:	pand   xmm14,xmm15
    156f:	movdqu xmm15,XMMWORD PTR [rip+0x8d28]        # 0xa2a0
    1578:	pcmpeqq xmm14,xmm15
    157e:	movdqa xmm15,xmm0
    1583:	cmpunordpd xmm15,xmm0
    1589:	por    xmm14,xmm15
    158e:	pmovmskb ecx,xmm14
    1593:	jrcxz  0x159a
    1595:	jmp    0x2ed9
    159a:	movdqa xmm3,xmm0
    159e:	movdqu XMMWORD PTR [r12+0x240],xmm3
    15a8:	movdqa xmm0,xmm9
    15ad:	movdqa xmm1,xmm5
    15b1:	pshufd xmm1,xmm1,0x44
    15b6:	mulpd  xmm0,xmm1
    15ba:	movdqa xmm14,xmm0
    15bf:	movdqu xmm15,XMMWORD PTR [rip+0x8cc8]        # 0xa290
    15c8:	pand   xmm14,xmm15
    15cd:	movdqu xmm15,XMMWORD PTR [rip+0x8cca]        # 0xa2a0
    15d6:	pcmpeqq xmm14,xmm15
    15dc:	movdqa xmm15,xmm0
    15e1:	cmpunordpd xmm15,xmm0
    15e7:	por    xmm14,xmm15
    15ec:	pmovmskb ecx,xmm14
    15f1:	jrcxz  0x15f8
    15f3:	jmp    0x2f03
    15f8:	movdqa xmm6,xmm0
    15fc:	movdqu XMMWORD PTR [r12+0x270],xmm6
    1606:	mov    r13,r14
    1609:	add    r13,0x80
    1610:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    1616:	movdqu XMMWORD PTR [r12+0x110],xmm9
    1620:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    162a:	movdqa xmm1,xmm11
    162f:	addpd  xmm0,xmm1
    1633:	movdqa xmm14,xmm0
    1638:	movdqu xmm15,XMMWORD PTR [rip+0x8c4f]        # 0xa290
    1641:	pand   xmm14,xmm15
    1646:	movdqu xmm15,XMMWORD PTR [rip+0x8c51]        # 0xa2a0
    164f:	pcmpeqq xmm14,xmm15
    1655:	movdqa xmm15,xmm0
    165a:	cmpunordpd xmm15,xmm0
    1660:	por    xmm14,xmm15
    1665:	pmovmskb ecx,xmm14
    166a:	jrcxz  0x1671
    166c:	jmp    0x2f28
    1671:	movdqa xmm10,xmm0
    1676:	movdqu XMMWORD PTR [r12+0x180],xmm10
    1680:	movdqa xmm0,xmm12
    1685:	movdqa xmm1,xmm8
    168a:	addpd  xmm0,xmm1
    168e:	movdqa xmm14,xmm0
    1693:	movdqu xmm15,XMMWORD PTR [rip+0x8bf4]        # 0xa290
    169c:	pand   xmm14,xmm15
    16a1:	movdqu xmm15,XMMWORD PTR [rip+0x8bf6]        # 0xa2a0
    16aa:	pcmpeqq xmm14,xmm15
    16b0:	movdqa xmm15,xmm0
    16b5:	cmpunordpd xmm15,xmm0
    16bb:	por    xmm14,xmm15
    16c0:	pmovmskb ecx,xmm14
    16c5:	jrcxz  0x16cc
    16c7:	jmp    0x2f53
    16cc:	movdqa xmm11,xmm0
    16d1:	movdqu XMMWORD PTR [r12+0x210],xmm11
    16db:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    16e5:	movdqu xmm1,XMMWORD PTR [r12+0x1b0]
    16ef:	por    xmm0,xmm1
    16f3:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    16fd:	movdqa xmm0,xmm9
    1702:	movdqa xmm1,xmm5
    1706:	pshufd xmm1,xmm1,0x44
    170b:	mulpd  xmm0,xmm1
    170f:	movdqa xmm14,xmm0
    1714:	movdqu xmm15,XMMWORD PTR [rip+0x8b73]        # 0xa290
    171d:	pand   xmm14,xmm15
    1722:	movdqu xmm15,XMMWORD PTR [rip+0x8b75]        # 0xa2a0
    172b:	pcmpeqq xmm14,xmm15
    1731:	movdqa xmm15,xmm0
    1736:	cmpunordpd xmm15,xmm0
    173c:	por    xmm14,xmm15
    1741:	pmovmskb ecx,xmm14
    1746:	jrcxz  0x174d
    1748:	jmp    0x2f79
    174d:	movdqa xmm12,xmm0
    1752:	movdqu XMMWORD PTR [r12+0x170],xmm12
    175c:	mov    r13,r14
    175f:	add    r13,0xd0
    1766:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    176c:	movdqu XMMWORD PTR [r12+0x110],xmm5
    1776:	movdqa xmm0,xmm4
    177a:	movdqa xmm1,xmm2
    177e:	addpd  xmm0,xmm1
    1782:	movdqa xmm14,xmm0
    1787:	movdqu xmm15,XMMWORD PTR [rip+0x8b00]        # 0xa290
    1790:	pand   xmm14,xmm15
    1795:	movdqu xmm15,XMMWORD PTR [rip+0x8b02]        # 0xa2a0
    179e:	pcmpeqq xmm14,xmm15
    17a4:	movdqa xmm15,xmm0
    17a9:	cmpunordpd xmm15,xmm0
    17af:	por    xmm14,xmm15
    17b4:	pmovmskb ecx,xmm14
    17b9:	jrcxz  0x17c0
    17bb:	jmp    0x2f9e
    17c0:	movdqa xmm9,xmm0
    17c5:	movdqu XMMWORD PTR [r12+0x220],xmm9
    17cf:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    17d9:	movdqa xmm0,xmm13
    17de:	movdqa xmm1,xmm2
    17e2:	pshufd xmm1,xmm1,0x44
    17e7:	mulpd  xmm0,xmm1
    17eb:	movdqa xmm14,xmm0
    17f0:	movdqu xmm15,XMMWORD PTR [rip+0x8a97]        # 0xa290
    17f9:	pand   xmm14,xmm15
    17fe:	movdqu xmm15,XMMWORD PTR [rip+0x8a99]        # 0xa2a0
    1807:	pcmpeqq xmm14,xmm15
    180d:	movdqa xmm15,xmm0
    1812:	cmpunordpd xmm15,xmm0
    1818:	por    xmm14,xmm15
    181d:	pmovmskb ecx,xmm14
    1822:	jrcxz  0x1829
    1824:	jmp    0x2fc2
    1829:	movdqa xmm4,xmm0
    182d:	movdqu XMMWORD PTR [r12+0x260],xmm4
    1837:	mov    r13d,0x0
    183d:	mov    ebp,0x0
    1842:	mov    QWORD PTR [r12+0x1b0],r13
    184a:	mov    QWORD PTR [r12+0x1b8],rbp
    1852:	movdqa xmm0,xmm5
    1856:	movdqa xmm1,xmm2
    185a:	pshufd xmm1,xmm1,0x44
    185f:	mulpd  xmm0,xmm1
    1863:	movdqa xmm14,xmm0
    1868:	movdqu xmm15,XMMWORD PTR [rip+0x8a1f]        # 0xa290
    1871:	pand   xmm14,xmm15
    1876:	movdqu xmm15,XMMWORD PTR [rip+0x8a21]        # 0xa2a0
    187f:	pcmpeqq xmm14,xmm15
    1885:	movdqa xmm15,xmm0
    188a:	cmpunordpd xmm15,xmm0
    1890:	por    xmm14,xmm15
    1895:	pmovmskb ecx,xmm14
    189a:	jrcxz  0x18a1
    189c:	jmp    0x2fe7
    18a1:	movdqa xmm13,xmm0
    18a6:	movdqu XMMWORD PTR [r12+0x230],xmm13
    18b0:	mov    r13,r14
    18b3:	add    r13,0xc0
    18ba:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    18c0:	movdqu XMMWORD PTR [r12+0x110],xmm5
    18ca:	movdqa xmm0,xmm3
    18ce:	movdqa xmm1,xmm6
    18d2:	addpd  xmm0,xmm1
    18d6:	movdqa xmm14,xmm0
    18db:	movdqu xmm15,XMMWORD PTR [rip+0x89ac]        # 0xa290
    18e4:	pand   xmm14,xmm15
    18e9:	movdqu xmm15,XMMWORD PTR [rip+0x89ae]        # 0xa2a0
    18f2:	pcmpeqq xmm14,xmm15
    18f8:	movdqa xmm15,xmm0
    18fd:	cmpunordpd xmm15,xmm0
    1903:	por    xmm14,xmm15
    1908:	pmovmskb ecx,xmm14
    190d:	jrcxz  0x1914
    190f:	jmp    0x300b
    1914:	movdqa xmm8,xmm0
    1919:	movdqu XMMWORD PTR [r12+0x240],xmm8
    1923:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    192d:	movdqu xmm1,XMMWORD PTR [r12+0x1a0]
    1937:	por    xmm0,xmm1
    193b:	movdqu XMMWORD PTR [r12+0x270],xmm0
    1945:	movdqu xmm6,XMMWORD PTR [r12+0x120]
    194f:	movdqu xmm1,XMMWORD PTR [r12+0x120]
    1959:	por    xmm6,xmm1
    195d:	movdqu XMMWORD PTR [r12+0x1a0],xmm6
    1967:	movdqa xmm0,xmm5
    196b:	movdqa xmm1,xmm2
    196f:	pshufd xmm1,xmm1,0x44
    1974:	mulpd  xmm0,xmm1
    1978:	movdqa xmm14,xmm0
    197d:	movdqu xmm15,XMMWORD PTR [rip+0x890a]        # 0xa290
    1986:	pand   xmm14,xmm15
    198b:	movdqu xmm15,XMMWORD PTR [rip+0x890c]        # 0xa2a0
    1994:	pcmpeqq xmm14,xmm15
    199a:	movdqa xmm15,xmm0
    199f:	cmpunordpd xmm15,xmm0
    19a5:	por    xmm14,xmm15
    19aa:	pmovmskb ecx,xmm14
    19af:	jrcxz  0x19b6
    19b1:	jmp    0x302f
    19b6:	movdqa xmm6,xmm0
    19ba:	movdqu XMMWORD PTR [r12+0x250],xmm6
    19c4:	mov    r13,r14
    19c7:	add    r13,0x20
    19cb:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    19d1:	movdqu XMMWORD PTR [r12+0x110],xmm5
    19db:	movdqa xmm0,xmm10
    19e0:	movdqa xmm1,xmm12
    19e5:	addpd  xmm0,xmm1
    19e9:	movdqa xmm14,xmm0
    19ee:	movdqu xmm15,XMMWORD PTR [rip+0x8899]        # 0xa290
    19f7:	pand   xmm14,xmm15
    19fc:	movdqu xmm15,XMMWORD PTR [rip+0x889b]        # 0xa2a0
    1a05:	pcmpeqq xmm14,xmm15
    1a0b:	movdqa xmm15,xmm0
    1a10:	cmpunordpd xmm15,xmm0
    1a16:	por    xmm14,xmm15
    1a1b:	pmovmskb ecx,xmm14
    1a20:	jrcxz  0x1a27
    1a22:	jmp    0x3053
    1a27:	movdqa xmm3,xmm0
    1a2b:	movdqa xmm0,xmm7
    1a2f:	movdqa xmm1,xmm2
    1a33:	pshufd xmm1,xmm1,0x44
    1a38:	mulpd  xmm0,xmm1
    1a3c:	movdqa xmm14,xmm0
    1a41:	movdqu xmm15,XMMWORD PTR [rip+0x8846]        # 0xa290
    1a4a:	pand   xmm14,xmm15
    1a4f:	movdqu xmm15,XMMWORD PTR [rip+0x8848]        # 0xa2a0
    1a58:	pcmpeqq xmm14,xmm15
    1a5e:	movdqa xmm15,xmm0
    1a63:	cmpunordpd xmm15,xmm0
    1a69:	por    xmm14,xmm15
    1a6e:	pmovmskb ecx,xmm14
    1a73:	jrcxz  0x1a7a
    1a75:	jmp    0x3079
    1a7a:	movdqa xmm10,xmm0
    1a7f:	movdqa xmm0,xmm11
    1a84:	movdqa xmm1,xmm13
    1a89:	addpd  xmm0,xmm1
    1a8d:	movdqa xmm14,xmm0
    1a92:	movdqu xmm15,XMMWORD PTR [rip+0x87f5]        # 0xa290
    1a9b:	pand   xmm14,xmm15
    1aa0:	movdqu xmm15,XMMWORD PTR [rip+0x87f7]        # 0xa2a0
    1aa9:	pcmpeqq xmm14,xmm15
    1aaf:	movdqa xmm15,xmm0
    1ab4:	cmpunordpd xmm15,xmm0
    1aba:	por    xmm14,xmm15
    1abf:	pmovmskb ecx,xmm14
    1ac4:	jrcxz  0x1acb
    1ac6:	jmp    0x309d
    1acb:	movdqa xmm2,xmm0
    1acf:	movdqu xmm7,XMMWORD PTR [r12+0x150]
    1ad9:	movdqa xmm0,xmm5
    1add:	movdqa xmm1,xmm7
    1ae1:	pshufd xmm1,xmm1,0x44
    1ae6:	mulpd  xmm0,xmm1
    1aea:	movdqa xmm14,xmm0
    1aef:	movdqu xmm15,XMMWORD PTR [rip+0x8798]        # 0xa290
    1af8:	pand   xmm14,xmm15
    1afd:	movdqu xmm15,XMMWORD PTR [rip+0x879a]        # 0xa2a0
    1b06:	pcmpeqq xmm14,xmm15
    1b0c:	movdqa xmm15,xmm0
    1b11:	cmpunordpd xmm15,xmm0
    1b17:	por    xmm14,xmm15
    1b1c:	pmovmskb ecx,xmm14
    1b21:	jrcxz  0x1b28
    1b23:	jmp    0x30c3
    1b28:	movdqa xmm11,xmm0
    1b2d:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    1b37:	movdqa xmm1,xmm7
    1b3b:	pshufd xmm1,xmm1,0x44
    1b40:	mulpd  xmm0,xmm1
    1b44:	movdqa xmm14,xmm0
    1b49:	movdqu xmm15,XMMWORD PTR [rip+0x873e]        # 0xa290
    1b52:	pand   xmm14,xmm15
    1b57:	movdqu xmm15,XMMWORD PTR [rip+0x8740]        # 0xa2a0
    1b60:	pcmpeqq xmm14,xmm15
    1b66:	movdqa xmm15,xmm0
    1b6b:	cmpunordpd xmm15,xmm0
    1b71:	por    xmm14,xmm15
    1b76:	pmovmskb ecx,xmm14
    1b7b:	jrcxz  0x1b82
    1b7d:	jmp    0x30e7
    1b82:	movdqa xmm5,xmm0
    1b86:	movdqa xmm0,xmm8
    1b8b:	movdqa xmm1,xmm4
    1b8f:	addpd  xmm0,xmm1
    1b93:	movdqa xmm14,xmm0
    1b98:	movdqu xmm15,XMMWORD PTR [rip+0x86ef]        # 0xa290
    1ba1:	pand   xmm14,xmm15
    1ba6:	movdqu xmm15,XMMWORD PTR [rip+0x86f1]        # 0xa2a0
    1baf:	pcmpeqq xmm14,xmm15
    1bb5:	movdqa xmm15,xmm0
    1bba:	cmpunordpd xmm15,xmm0
    1bc0:	por    xmm14,xmm15
    1bc5:	pmovmskb ecx,xmm14
    1bca:	jrcxz  0x1bd1
    1bcc:	jmp    0x3111
    1bd1:	movdqa xmm12,xmm0
    1bd6:	movdqu XMMWORD PTR [r12+0x240],xmm12
    1be0:	movdqa xmm0,xmm9
    1be5:	movdqa xmm1,xmm6
    1be9:	addpd  xmm0,xmm1
    1bed:	movdqa xmm14,xmm0
    1bf2:	movdqu xmm15,XMMWORD PTR [rip+0x8695]        # 0xa290
    1bfb:	pand   xmm14,xmm15
    1c00:	movdqu xmm15,XMMWORD PTR [rip+0x8697]        # 0xa2a0
    1c09:	pcmpeqq xmm14,xmm15
    1c0f:	movdqa xmm15,xmm0
    1c14:	cmpunordpd xmm15,xmm0
    1c1a:	por    xmm14,xmm15
    1c1f:	pmovmskb ecx,xmm14
    1c24:	jrcxz  0x1c2b
    1c26:	jmp    0x3136
    1c2b:	movdqa xmm4,xmm0
    1c2f:	movdqu XMMWORD PTR [r12+0x220],xmm4
    1c39:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    1c43:	movdqa xmm1,xmm7
    1c47:	pshufd xmm1,xmm1,0x44
    1c4c:	mulpd  xmm0,xmm1
    1c50:	movdqa xmm14,xmm0
    1c55:	movdqu xmm15,XMMWORD PTR [rip+0x8632]        # 0xa290
    1c5e:	pand   xmm14,xmm15
    1c63:	movdqu xmm15,XMMWORD PTR [rip+0x8634]        # 0xa2a0
    1c6c:	pcmpeqq xmm14,xmm15
    1c72:	movdqa xmm15,xmm0
    1c77:	cmpunordpd xmm15,xmm0
    1c7d:	por    xmm14,xmm15
    1c82:	pmovmskb ecx,xmm14
    1c87:	jrcxz  0x1c8e
    1c89:	jmp    0x315b
    1c8e:	movdqa xmm6,xmm0
    1c92:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    1c9c:	movdqa xmm1,xmm7
    1ca0:	pshufd xmm1,xmm1,0x44
    1ca5:	mulpd  xmm0,xmm1
    1ca9:	movdqa xmm14,xmm0
    1cae:	movdqu xmm15,XMMWORD PTR [rip+0x85d9]        # 0xa290
    1cb7:	pand   xmm14,xmm15
    1cbc:	movdqu xmm15,XMMWORD PTR [rip+0x85db]        # 0xa2a0
    1cc5:	pcmpeqq xmm14,xmm15
    1ccb:	movdqa xmm15,xmm0
    1cd0:	cmpunordpd xmm15,xmm0
    1cd6:	por    xmm14,xmm15
    1cdb:	pmovmskb ecx,xmm14
    1ce0:	jrcxz  0x1ce7
    1ce2:	jmp    0x3185
    1ce7:	movdqa xmm8,xmm0
    1cec:	movdqu XMMWORD PTR [r12+0x150],xmm8
    1cf6:	movdqa xmm0,xmm3
    1cfa:	movdqa xmm1,xmm10
    1cff:	addpd  xmm0,xmm1
    1d03:	movdqa xmm14,xmm0
    1d08:	movdqu xmm15,XMMWORD PTR [rip+0x857f]        # 0xa290
    1d11:	pand   xmm14,xmm15
    1d16:	movdqu xmm15,XMMWORD PTR [rip+0x8581]        # 0xa2a0
    1d1f:	pcmpeqq xmm14,xmm15
    1d25:	movdqa xmm15,xmm0
    1d2a:	cmpunordpd xmm15,xmm0
    1d30:	por    xmm14,xmm15
    1d35:	pmovmskb ecx,xmm14
    1d3a:	jrcxz  0x1d41
    1d3c:	jmp    0x31af
    1d41:	movdqa xmm7,xmm0
    1d45:	movdqu XMMWORD PTR [r12+0x160],xmm7
    1d4f:	movdqa xmm0,xmm2
    1d53:	movdqa xmm1,xmm11
    1d58:	addpd  xmm0,xmm1
    1d5c:	movdqa xmm14,xmm0
    1d61:	movdqu xmm15,XMMWORD PTR [rip+0x8526]        # 0xa290
    1d6a:	pand   xmm14,xmm15
    1d6f:	movdqu xmm15,XMMWORD PTR [rip+0x8528]        # 0xa2a0
    1d78:	pcmpeqq xmm14,xmm15
    1d7e:	movdqa xmm15,xmm0
    1d83:	cmpunordpd xmm15,xmm0
    1d89:	por    xmm14,xmm15
    1d8e:	pmovmskb ecx,xmm14
    1d93:	jrcxz  0x1d9a
    1d95:	jmp    0x31d4
    1d9a:	movdqa xmm3,xmm0
    1d9e:	movdqu XMMWORD PTR [r12+0x170],xmm3
    1da8:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    1db2:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    1dbc:	movdqa xmm1,xmm2
    1dc0:	pshufd xmm1,xmm1,0x44
    1dc5:	mulpd  xmm0,xmm1
    1dc9:	movdqa xmm14,xmm0
    1dce:	movdqu xmm15,XMMWORD PTR [rip+0x84b9]        # 0xa290
    1dd7:	pand   xmm14,xmm15
    1ddc:	movdqu xmm15,XMMWORD PTR [rip+0x84bb]        # 0xa2a0
    1de5:	pcmpeqq xmm14,xmm15
    1deb:	movdqa xmm15,xmm0
    1df0:	cmpunordpd xmm15,xmm0
    1df6:	por    xmm14,xmm15
    1dfb:	pmovmskb ecx,xmm14
    1e00:	jrcxz  0x1e07
    1e02:	jmp    0x31f9
    1e07:	movdqa xmm9,xmm0
    1e0c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    1e16:	movdqa xmm0,xmm4
    1e1a:	movdqa xmm1,xmm5
    1e1e:	addpd  xmm0,xmm1
    1e22:	movdqa xmm14,xmm0
    1e27:	movdqu xmm15,XMMWORD PTR [rip+0x8460]        # 0xa290
    1e30:	pand   xmm14,xmm15
    1e35:	movdqu xmm15,XMMWORD PTR [rip+0x8462]        # 0xa2a0
    1e3e:	pcmpeqq xmm14,xmm15
    1e44:	movdqa xmm15,xmm0
    1e49:	cmpunordpd xmm15,xmm0
    1e4f:	por    xmm14,xmm15
    1e54:	pmovmskb ecx,xmm14
    1e59:	jrcxz  0x1e60
    1e5b:	jmp    0x3223
    1e60:	movdqa xmm10,xmm0
    1e65:	movdqu XMMWORD PTR [r12+0x210],xmm10
    1e6f:	movdqa xmm0,xmm12
    1e74:	movdqa xmm1,xmm6
    1e78:	addpd  xmm0,xmm1
    1e7c:	movdqa xmm14,xmm0
    1e81:	movdqu xmm15,XMMWORD PTR [rip+0x8406]        # 0xa290
    1e8a:	pand   xmm14,xmm15
    1e8f:	movdqu xmm15,XMMWORD PTR [rip+0x8408]        # 0xa2a0
    1e98:	pcmpeqq xmm14,xmm15
    1e9e:	movdqa xmm15,xmm0
    1ea3:	cmpunordpd xmm15,xmm0
    1ea9:	por    xmm14,xmm15
    1eae:	pmovmskb ecx,xmm14
    1eb3:	jrcxz  0x1eba
    1eb5:	jmp    0x3247
    1eba:	movdqa xmm4,xmm0
    1ebe:	movdqu XMMWORD PTR [r12+0x230],xmm4
    1ec8:	movdqu xmm5,XMMWORD PTR [r12+0x2a0]
    1ed2:	movdqu xmm1,XMMWORD PTR [r12+0x2a0]
    1edc:	por    xmm5,xmm1
    1ee0:	movdqu XMMWORD PTR [r12+0x250],xmm5
    1eea:	movdqu xmm5,XMMWORD PTR [r12+0x1d0]
    1ef4:	movdqu xmm1,XMMWORD PTR [r12+0x1d0]
    1efe:	por    xmm5,xmm1
    1f02:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    1f0c:	movdqu xmm6,XMMWORD PTR [r12+0x2c0]
    1f16:	movdqu xmm1,XMMWORD PTR [r12+0x2c0]
    1f20:	por    xmm6,xmm1
    1f24:	movdqu XMMWORD PTR [r12+0x1d0],xmm6
    1f2e:	mov    r13,r14
    1f31:	add    r13,0x40
    1f35:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    1f3b:	movdqu XMMWORD PTR [r12+0x2c0],xmm6
    1f45:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    1f4f:	movdqa xmm1,xmm2
    1f53:	pshufd xmm1,xmm1,0x44
    1f58:	mulpd  xmm0,xmm1
    1f5c:	movdqa xmm14,xmm0
    1f61:	movdqu xmm15,XMMWORD PTR [rip+0x8326]        # 0xa290
    1f6a:	pand   xmm14,xmm15
    1f6f:	movdqu xmm15,XMMWORD PTR [rip+0x8328]        # 0xa2a0
    1f78:	pcmpeqq xmm14,xmm15
    1f7e:	movdqa xmm15,xmm0
    1f83:	cmpunordpd xmm15,xmm0
    1f89:	por    xmm14,xmm15
    1f8e:	pmovmskb ecx,xmm14
    1f93:	jrcxz  0x1f9a
    1f95:	jmp    0x326c
    1f9a:	movdqa xmm11,xmm0
    1f9f:	movdqa xmm0,xmm7
    1fa3:	movdqa xmm1,xmm8
    1fa8:	addpd  xmm0,xmm1
    1fac:	movdqa xmm14,xmm0
    1fb1:	movdqu xmm15,XMMWORD PTR [rip+0x82d6]        # 0xa290
    1fba:	pand   xmm14,xmm15
    1fbf:	movdqu xmm15,XMMWORD PTR [rip+0x82d8]        # 0xa2a0
    1fc8:	pcmpeqq xmm14,xmm15
    1fce:	movdqa xmm15,xmm0
    1fd3:	cmpunordpd xmm15,xmm0
    1fd9:	por    xmm14,xmm15
    1fde:	pmovmskb ecx,xmm14
    1fe3:	jrcxz  0x1fea
    1fe5:	jmp    0x3296
    1fea:	movdqa xmm12,xmm0
    1fef:	movdqa xmm0,xmm3
    1ff3:	movdqa xmm1,xmm9
    1ff8:	addpd  xmm0,xmm1
    1ffc:	movdqa xmm14,xmm0
    2001:	movdqu xmm15,XMMWORD PTR [rip+0x8286]        # 0xa290
    200a:	pand   xmm14,xmm15
    200f:	movdqu xmm15,XMMWORD PTR [rip+0x8288]        # 0xa2a0
    2018:	pcmpeqq xmm14,xmm15
    201e:	movdqa xmm15,xmm0
    2023:	cmpunordpd xmm15,xmm0
    2029:	por    xmm14,xmm15
    202e:	pmovmskb ecx,xmm14
    2033:	jrcxz  0x203a
    2035:	jmp    0x32bb
    203a:	movdqa xmm7,xmm0
    203e:	movdqu XMMWORD PTR [r12+0x160],xmm7
    2048:	movdqa xmm0,xmm6
    204c:	movdqa xmm1,xmm2
    2050:	pshufd xmm1,xmm1,0x44
    2055:	mulpd  xmm0,xmm1
    2059:	movdqa xmm14,xmm0
    205e:	movdqu xmm15,XMMWORD PTR [rip+0x8229]        # 0xa290
    2067:	pand   xmm14,xmm15
    206c:	movdqu xmm15,XMMWORD PTR [rip+0x822b]        # 0xa2a0
    2075:	pcmpeqq xmm14,xmm15
    207b:	movdqa xmm15,xmm0
    2080:	cmpunordpd xmm15,xmm0
    2086:	por    xmm14,xmm15
    208b:	pmovmskb ecx,xmm14
    2090:	jrcxz  0x2097
    2092:	jmp    0x32e0
    2097:	movdqa xmm3,xmm0
    209b:	movdqu XMMWORD PTR [r12+0x240],xmm3
    20a5:	movdqu xmm6,XMMWORD PTR [r12+0x2b0]
    20af:	movdqa xmm0,xmm6
    20b3:	movdqa xmm1,xmm2
    20b7:	pshufd xmm1,xmm1,0x44
    20bc:	mulpd  xmm0,xmm1
    20c0:	movdqa xmm14,xmm0
    20c5:	movdqu xmm15,XMMWORD PTR [rip+0x81c2]        # 0xa290
    20ce:	pand   xmm14,xmm15
    20d3:	movdqu xmm15,XMMWORD PTR [rip+0x81c4]        # 0xa2a0
    20dc:	pcmpeqq xmm14,xmm15
    20e2:	movdqa xmm15,xmm0
    20e7:	cmpunordpd xmm15,xmm0
    20ed:	por    xmm14,xmm15
    20f2:	pmovmskb ecx,xmm14
    20f7:	jrcxz  0x20fe
    20f9:	jmp    0x3304
    20fe:	movdqa xmm8,xmm0
    2103:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    210d:	movdqa xmm0,xmm5
    2111:	movdqa xmm1,xmm2
    2115:	pshufd xmm1,xmm1,0x44
    211a:	mulpd  xmm0,xmm1
    211e:	movdqa xmm14,xmm0
    2123:	movdqu xmm15,XMMWORD PTR [rip+0x8164]        # 0xa290
    212c:	pand   xmm14,xmm15
    2131:	movdqu xmm15,XMMWORD PTR [rip+0x8166]        # 0xa2a0
    213a:	pcmpeqq xmm14,xmm15
    2140:	movdqa xmm15,xmm0
    2145:	cmpunordpd xmm15,xmm0
    214b:	por    xmm14,xmm15
    2150:	pmovmskb ecx,xmm14
    2155:	jrcxz  0x215c
    2157:	jmp    0x3328
    215c:	movdqa xmm6,xmm0
    2160:	movdqu XMMWORD PTR [r12+0x170],xmm6
    216a:	movdqa xmm0,xmm10
    216f:	movdqa xmm1,xmm11
    2174:	addpd  xmm0,xmm1
    2178:	movdqa xmm14,xmm0
    217d:	movdqu xmm15,XMMWORD PTR [rip+0x810a]        # 0xa290
    2186:	pand   xmm14,xmm15
    218b:	movdqu xmm15,XMMWORD PTR [rip+0x810c]        # 0xa2a0
    2194:	pcmpeqq xmm14,xmm15
    219a:	movdqa xmm15,xmm0
    219f:	cmpunordpd xmm15,xmm0
    21a5:	por    xmm14,xmm15
    21aa:	pmovmskb ecx,xmm14
    21af:	jrcxz  0x21b6
    21b1:	jmp    0x334c
    21b6:	movdqa xmm5,xmm0
    21ba:	movdqu XMMWORD PTR [r12+0x180],xmm5
    21c4:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    21ce:	movdqa xmm1,xmm2
    21d2:	pshufd xmm1,xmm1,0x44
    21d7:	mulpd  xmm0,xmm1
    21db:	movdqa xmm14,xmm0
    21e0:	movdqu xmm15,XMMWORD PTR [rip+0x80a7]        # 0xa290
    21e9:	pand   xmm14,xmm15
    21ee:	movdqu xmm15,XMMWORD PTR [rip+0x80a9]        # 0xa2a0
    21f7:	pcmpeqq xmm14,xmm15
    21fd:	movdqa xmm15,xmm0
    2202:	cmpunordpd xmm15,xmm0
    2208:	por    xmm14,xmm15
    220d:	pmovmskb ecx,xmm14
    2212:	jrcxz  0x2219
    2214:	jmp    0x3372
    2219:	movdqa xmm9,xmm0
    221e:	movdqu XMMWORD PTR [r12+0x210],xmm9
    2228:	movdqa xmm0,xmm4
    222c:	movdqa xmm1,xmm3
    2230:	addpd  xmm0,xmm1
    2234:	movdqa xmm14,xmm0
    2239:	movdqu xmm15,XMMWORD PTR [rip+0x804e]        # 0xa290
    2242:	pand   xmm14,xmm15
    2247:	movdqu xmm15,XMMWORD PTR [rip+0x8050]        # 0xa2a0
    2250:	pcmpeqq xmm14,xmm15
    2256:	movdqa xmm15,xmm0
    225b:	cmpunordpd xmm15,xmm0
    2261:	por    xmm14,xmm15
    2266:	pmovmskb ecx,xmm14
    226b:	jrcxz  0x2272
    226d:	jmp    0x339c
    2272:	movdqa xmm10,xmm0
    2277:	movdqu XMMWORD PTR [r12+0x220],xmm10
    2281:	movdqu xmm3,XMMWORD PTR [r12+0x290]
    228b:	movdqa xmm0,xmm3
    228f:	movdqa xmm1,xmm2
    2293:	pshufd xmm1,xmm1,0x44
    2298:	mulpd  xmm0,xmm1
    229c:	movdqa xmm14,xmm0
    22a1:	movdqu xmm15,XMMWORD PTR [rip+0x7fe6]        # 0xa290
    22aa:	pand   xmm14,xmm15
    22af:	movdqu xmm15,XMMWORD PTR [rip+0x7fe8]        # 0xa2a0
    22b8:	pcmpeqq xmm14,xmm15
    22be:	movdqa xmm15,xmm0
    22c3:	cmpunordpd xmm15,xmm0
    22c9:	por    xmm14,xmm15
    22ce:	pmovmskb ecx,xmm14
    22d3:	jrcxz  0x22da
    22d5:	jmp    0x33c0
    22da:	movdqa xmm4,xmm0
    22de:	movdqu XMMWORD PTR [r12+0x230],xmm4
    22e8:	movdqa xmm0,xmm12
    22ed:	movdqa xmm1,xmm8
    22f2:	addpd  xmm0,xmm1
    22f6:	movdqa xmm14,xmm0
    22fb:	movdqu xmm15,XMMWORD PTR [rip+0x7f8c]        # 0xa290
    2304:	pand   xmm14,xmm15
    2309:	movdqu xmm15,XMMWORD PTR [rip+0x7f8e]        # 0xa2a0
    2312:	pcmpeqq xmm14,xmm15
    2318:	movdqa xmm15,xmm0
    231d:	cmpunordpd xmm15,xmm0
    2323:	por    xmm14,xmm15
    2328:	pmovmskb ecx,xmm14
    232d:	jrcxz  0x2334
    232f:	jmp    0x33e4
    2334:	movdqa xmm3,xmm0
    2338:	movdqu XMMWORD PTR [r12+0x140],xmm3
    2342:	movdqu xmm8,XMMWORD PTR [r12+0x1e0]
    234c:	movdqa xmm0,xmm8
    2351:	movdqa xmm1,xmm2
    2355:	pshufd xmm1,xmm1,0x44
    235a:	mulpd  xmm0,xmm1
    235e:	movdqa xmm14,xmm0
    2363:	movdqu xmm15,XMMWORD PTR [rip+0x7f24]        # 0xa290
    236c:	pand   xmm14,xmm15
    2371:	movdqu xmm15,XMMWORD PTR [rip+0x7f26]        # 0xa2a0
    237a:	pcmpeqq xmm14,xmm15
    2380:	movdqa xmm15,xmm0
    2385:	cmpunordpd xmm15,xmm0
    238b:	por    xmm14,xmm15
    2390:	pmovmskb ecx,xmm14
    2395:	jrcxz  0x239c
    2397:	jmp    0x340a
    239c:	movdqa xmm11,xmm0
    23a1:	movdqu XMMWORD PTR [r12+0x130],xmm11
    23ab:	movdqa xmm0,xmm7
    23af:	movdqa xmm1,xmm6
    23b3:	addpd  xmm0,xmm1
    23b7:	movdqa xmm14,xmm0
    23bc:	movdqu xmm15,XMMWORD PTR [rip+0x7ecb]        # 0xa290
    23c5:	pand   xmm14,xmm15
    23ca:	movdqu xmm15,XMMWORD PTR [rip+0x7ecd]        # 0xa2a0
    23d3:	pcmpeqq xmm14,xmm15
    23d9:	movdqa xmm15,xmm0
    23de:	cmpunordpd xmm15,xmm0
    23e4:	por    xmm14,xmm15
    23e9:	pmovmskb ecx,xmm14
    23ee:	jrcxz  0x23f5
    23f0:	jmp    0x342f
    23f5:	movdqa xmm2,xmm0
    23f9:	movdqu XMMWORD PTR [r12+0x150],xmm2
    2403:	mov    r13,r14
    2406:	add    r13,0x70
    240a:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    2410:	movdqu XMMWORD PTR [r12+0x240],xmm6
    241a:	movdqa xmm0,xmm5
    241e:	movdqa xmm1,xmm9
    2423:	addpd  xmm0,xmm1
    2427:	movdqa xmm14,xmm0
    242c:	movdqu xmm15,XMMWORD PTR [rip+0x7e5b]        # 0xa290
    2435:	pand   xmm14,xmm15
    243a:	movdqu xmm15,XMMWORD PTR [rip+0x7e5d]        # 0xa2a0
    2443:	pcmpeqq xmm14,xmm15
    2449:	movdqa xmm15,xmm0
    244e:	cmpunordpd xmm15,xmm0
    2454:	por    xmm14,xmm15
    2459:	pmovmskb ecx,xmm14
    245e:	jrcxz  0x2465
    2460:	jmp    0x3453
    2465:	movdqa xmm7,xmm0
    2469:	movdqu XMMWORD PTR [r12+0x170],xmm7
    2473:	movdqu xmm5,XMMWORD PTR [r12+0x280]
    247d:	movdqa xmm0,xmm6
    2481:	movdqa xmm1,xmm5
    2485:	pshufd xmm1,xmm1,0x44
    248a:	mulpd  xmm0,xmm1
    248e:	movdqa xmm14,xmm0
    2493:	movdqu xmm15,XMMWORD PTR [rip+0x7df4]        # 0xa290
    249c:	pand   xmm14,xmm15
    24a1:	movdqu xmm15,XMMWORD PTR [rip+0x7df6]        # 0xa2a0
    24aa:	pcmpeqq xmm14,xmm15
    24b0:	movdqa xmm15,xmm0
    24b5:	cmpunordpd xmm15,xmm0
    24bb:	por    xmm14,xmm15
    24c0:	pmovmskb ecx,xmm14
    24c5:	jrcxz  0x24cc
    24c7:	jmp    0x3478
    24cc:	movdqa xmm8,xmm0
    24d1:	movdqu XMMWORD PTR [r12+0x160],xmm8
    24db:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    24e5:	movdqa xmm1,xmm5
    24e9:	pshufd xmm1,xmm1,0x44
    24ee:	mulpd  xmm0,xmm1
    24f2:	movdqa xmm14,xmm0
    24f7:	movdqu xmm15,XMMWORD PTR [rip+0x7d90]        # 0xa290
    2500:	pand   xmm14,xmm15
    2505:	movdqu xmm15,XMMWORD PTR [rip+0x7d92]        # 0xa2a0
    250e:	pcmpeqq xmm14,xmm15
    2514:	movdqa xmm15,xmm0
    2519:	cmpunordpd xmm15,xmm0
    251f:	por    xmm14,xmm15
    2524:	pmovmskb ecx,xmm14
    2529:	jrcxz  0x2530
    252b:	jmp    0x349c
    2530:	movdqa xmm6,xmm0
    2534:	movdqu XMMWORD PTR [r12+0x180],xmm6
    253e:	movdqa xmm0,xmm10
    2543:	movdqa xmm1,xmm4
    2547:	addpd  xmm0,xmm1
    254b:	movdqa xmm14,xmm0
    2550:	movdqu xmm15,XMMWORD PTR [rip+0x7d37]        # 0xa290
    2559:	pand   xmm14,xmm15
    255e:	movdqu xmm15,XMMWORD PTR [rip+0x7d39]        # 0xa2a0
    2567:	pcmpeqq xmm14,xmm15
    256d:	movdqa xmm15,xmm0
    2572:	cmpunordpd xmm15,xmm0
    2578:	por    xmm14,xmm15
    257d:	pmovmskb ecx,xmm14
    2582:	jrcxz  0x2589
    2584:	jmp    0x34c6
    2589:	movdqa xmm9,xmm0
    258e:	movdqu XMMWORD PTR [r12+0x210],xmm9
    2598:	mov    r13,r14
    259b:	add    r13,0x10
    259f:	movdqu xmm4,XMMWORD PTR [r14]
    25a4:	movdqu xmm10,XMMWORD PTR [r13+0x0]
    25aa:	movdqu XMMWORD PTR [r12+0x230],xmm10
    25b4:	movdqa xmm0,xmm3
    25b8:	movdqa xmm1,xmm11
    25bd:	addpd  xmm0,xmm1
    25c1:	movdqa xmm14,xmm0
    25c6:	movdqu xmm15,XMMWORD PTR [rip+0x7cc1]        # 0xa290
    25cf:	pand   xmm14,xmm15
    25d4:	movdqu xmm15,XMMWORD PTR [rip+0x7cc3]        # 0xa2a0
    25dd:	pcmpeqq xmm14,xmm15
    25e3:	movdqa xmm15,xmm0
    25e8:	cmpunordpd xmm15,xmm0
    25ee:	por    xmm14,xmm15
    25f3:	pmovmskb ecx,xmm14
    25f8:	jrcxz  0x25ff
    25fa:	jmp    0x34eb
    25ff:	movdqa xmm12,xmm0
    2604:	movdqu XMMWORD PTR [r12+0x130],xmm12
    260e:	movdqa xmm0,xmm10
    2613:	movdqa xmm1,xmm5
    2617:	pshufd xmm1,xmm1,0x44
    261c:	mulpd  xmm0,xmm1
    2620:	movdqa xmm14,xmm0
    2625:	movdqu xmm15,XMMWORD PTR [rip+0x7c62]        # 0xa290
    262e:	pand   xmm14,xmm15
    2633:	movdqu xmm15,XMMWORD PTR [rip+0x7c64]        # 0xa2a0
    263c:	pcmpeqq xmm14,xmm15
    2642:	movdqa xmm15,xmm0
    2647:	cmpunordpd xmm15,xmm0
    264d:	por    xmm14,xmm15
    2652:	pmovmskb ecx,xmm14
    2657:	jrcxz  0x265e
    2659:	jmp    0x3510
    265e:	movdqa xmm3,xmm0
    2662:	movdqu XMMWORD PTR [r12+0x220],xmm3
    266c:	movdqa xmm0,xmm4
    2670:	movdqa xmm1,xmm5
    2674:	pshufd xmm1,xmm1,0x44
    2679:	mulpd  xmm0,xmm1
    267d:	movdqa xmm14,xmm0
    2682:	movdqu xmm15,XMMWORD PTR [rip+0x7c05]        # 0xa290
    268b:	pand   xmm14,xmm15
    2690:	movdqu xmm15,XMMWORD PTR [rip+0x7c07]        # 0xa2a0
    2699:	pcmpeqq xmm14,xmm15
    269f:	movdqa xmm15,xmm0
    26a4:	cmpunordpd xmm15,xmm0
    26aa:	por    xmm14,xmm15
    26af:	pmovmskb ecx,xmm14
    26b4:	jrcxz  0x26bb
    26b6:	jmp    0x3535
    26bb:	movdqa xmm10,xmm0
    26c0:	movdqa xmm0,xmm2
    26c4:	movdqa xmm1,xmm8
    26c9:	addpd  xmm0,xmm1
    26cd:	movdqa xmm14,xmm0
    26d2:	movdqu xmm15,XMMWORD PTR [rip+0x7bb5]        # 0xa290
    26db:	pand   xmm14,xmm15
    26e0:	movdqu xmm15,XMMWORD PTR [rip+0x7bb7]        # 0xa2a0
    26e9:	pcmpeqq xmm14,xmm15
    26ef:	movdqa xmm15,xmm0
    26f4:	cmpunordpd xmm15,xmm0
    26fa:	por    xmm14,xmm15
    26ff:	pmovmskb ecx,xmm14
    2704:	jrcxz  0x270b
    2706:	jmp    0x3559
    270b:	movdqa xmm4,xmm0
    270f:	movdqu XMMWORD PTR [r12+0x140],xmm4
    2719:	movdqa xmm0,xmm7
    271d:	movdqa xmm1,xmm6
    2721:	addpd  xmm0,xmm1
    2725:	movdqa xmm14,xmm0
    272a:	movdqu xmm15,XMMWORD PTR [rip+0x7b5d]        # 0xa290
    2733:	pand   xmm14,xmm15
    2738:	movdqu xmm15,XMMWORD PTR [rip+0x7b5f]        # 0xa2a0
    2741:	pcmpeqq xmm14,xmm15
    2747:	movdqa xmm15,xmm0
    274c:	cmpunordpd xmm15,xmm0
    2752:	por    xmm14,xmm15
    2757:	pmovmskb ecx,xmm14
    275c:	jrcxz  0x2763
    275e:	jmp    0x357e
    2763:	movdqa xmm2,xmm0
    2767:	movdqu XMMWORD PTR [r12+0x150],xmm2
    2771:	movdqa xmm0,xmm9
    2776:	movdqa xmm1,xmm3
    277a:	addpd  xmm0,xmm1
    277e:	movdqa xmm14,xmm0
    2783:	movdqu xmm15,XMMWORD PTR [rip+0x7b04]        # 0xa290
    278c:	pand   xmm14,xmm15
    2791:	movdqu xmm15,XMMWORD PTR [rip+0x7b06]        # 0xa2a0
    279a:	pcmpeqq xmm14,xmm15
    27a0:	movdqa xmm15,xmm0
    27a5:	cmpunordpd xmm15,xmm0
    27ab:	por    xmm14,xmm15
    27b0:	pmovmskb ecx,xmm14
    27b5:	jrcxz  0x27bc
    27b7:	jmp    0x35a2
    27bc:	movdqa xmm5,xmm0
    27c0:	movdqu XMMWORD PTR [r12+0x160],xmm5
    27ca:	movdqa xmm0,xmm12
    27cf:	movdqa xmm1,xmm10
    27d4:	addpd  xmm0,xmm1
    27d8:	movdqa xmm14,xmm0
    27dd:	movdqu xmm15,XMMWORD PTR [rip+0x7aaa]        # 0xa290
    27e6:	pand   xmm14,xmm15
    27eb:	movdqu xmm15,XMMWORD PTR [rip+0x7aac]        # 0xa2a0
    27f4:	pcmpeqq xmm14,xmm15
    27fa:	movdqa xmm15,xmm0
    27ff:	cmpunordpd xmm15,xmm0
    2805:	por    xmm14,xmm15
    280a:	pmovmskb ecx,xmm14
    280f:	jrcxz  0x2816
    2811:	jmp    0x35c7
    2816:	movdqa xmm3,xmm0
    281a:	movdqu XMMWORD PTR [r12+0x120],xmm3
    2824:	mov    r13,r15
    2827:	add    r13,0x10
    282b:	movdqu XMMWORD PTR [r15],xmm4
    2830:	mov    r14d,0x0
    2836:	mov    DWORD PTR [r12+0x32c],r14d
    283e:	movdqu XMMWORD PTR [r13+0x0],xmm2
    2844:	add    r15,0x20
    2848:	mov    r13,r15
    284b:	add    r13,0x10
    284f:	movdqu XMMWORD PTR [r15],xmm5
    2854:	movdqu XMMWORD PTR [r13+0x0],xmm3
    285a:	mov    rcx,QWORD PTR [r12+0x380]
    2862:	jrcxz  0x2869
    2864:	jmp    0x9ab9
    2869:	cmp    BYTE PTR [rsp+0x8],0x0
    286e:	jne    0xb39
    2874:	jmp    0x2879
    2879:	mov    r13d,DWORD PTR [r12+0x48]
    287e:	add    r13d,0x1
    2882:	mov    QWORD PTR [r12+0x48],r13
    2887:	sub    r13d,0x1f4
    288e:	mov    rcx,QWORD PTR [r12+0x380]
    2896:	jrcxz  0x289d
    2898:	jmp    0x9b3e
    289d:	jne    0xb1b
    28a3:	mov    r11,rax
    28a6:	lahf
    28a7:	seto   al
    28aa:	mov    WORD PTR [rsp],ax
    28ae:	mov    rax,r11
    28b1:	jmp    0x28b6
    28b6:	mov    r13d,0x0
    28bc:	mov    QWORD PTR [r12+0x48],r13
    28c1:	mov    r13,QWORD PTR [r12+0xf8]
    28c9:	mov    r14,r13
    28cc:	add    r14,0x140
    28d3:	mov    r15,QWORD PTR [r14]
    28d6:	mov    QWORD PTR [r12+0xe8],r15
    28de:	mov    r14,r13
    28e1:	add    r14,0x130
    28e8:	mov    r15,r14
    28eb:	add    r15,0x8
    28ef:	mov    rbp,QWORD PTR [r14]
    28f2:	mov    r14,QWORD PTR [r15]
    28f5:	mov    r15d,0x0
    28fb:	mov    QWORD PTR [r12+0x1a0],rbp
    2903:	mov    QWORD PTR [r12+0x1a8],r15
    290b:	mov    r15d,0x0
    2911:	mov    QWORD PTR [r12+0x190],r14
    2919:	mov    QWORD PTR [r12+0x198],r15
    2921:	mov    r14,r13
    2924:	add    r14,0x120
    292b:	mov    r15,r14
    292e:	add    r15,0x8
    2932:	mov    rbp,QWORD PTR [r14]
    2935:	mov    r14,QWORD PTR [r15]
    2938:	mov    r15d,0x0
    293e:	mov    QWORD PTR [r12+0x1c0],rbp
    2946:	mov    QWORD PTR [r12+0x1c8],r15
    294e:	mov    r15d,0x0
    2954:	mov    QWORD PTR [r12+0x1b0],r14
    295c:	mov    QWORD PTR [r12+0x1b8],r15
    2964:	mov    r14,r13
    2967:	add    r14,0x110
    296e:	mov    r15,r14
    2971:	add    r15,0x8
    2975:	mov    rbp,QWORD PTR [r14]
    2978:	mov    r14,QWORD PTR [r15]
    297b:	mov    r15d,0x0
    2981:	mov    QWORD PTR [r12+0x1e0],rbp
    2989:	mov    QWORD PTR [r12+0x1e8],r15
    2991:	mov    r15d,0x0
    2997:	mov    QWORD PTR [r12+0x1d0],r14
    299f:	mov    QWORD PTR [r12+0x1d8],r15
    29a7:	mov    r14,r13
    29aa:	add    r14,0x100
    29b1:	mov    r15,r14
    29b4:	add    r15,0x8
    29b8:	mov    rbp,QWORD PTR [r14]
    29bb:	mov    r14,QWORD PTR [r15]
    29be:	mov    r15d,0x0
    29c4:	mov    QWORD PTR [r12+0x200],rbp
    29cc:	mov    QWORD PTR [r12+0x208],r15
    29d4:	mov    r15d,0x0
    29da:	mov    QWORD PTR [r12+0x1f0],r14
    29e2:	mov    QWORD PTR [r12+0x1f8],r15
    29ea:	mov    r14d,0x430000
    29f0:	mov    QWORD PTR [r12+0x40],r14
    29f5:	mov    r14d,0x430510
    29fb:	mov    r15,QWORD PTR [r14]
    29fe:	mov    r14d,0x0
    2a04:	mov    QWORD PTR [r12+0x110],r15
    2a0c:	mov    QWORD PTR [r12+0x118],r14
    2a14:	add    r13,0x150
    2a1b:	mov    QWORD PTR [r12+0xf8],r13
    2a23:	jmp    0x2a28
    2a28:	mov    r13,QWORD PTR [r12+0x48]
    2a2d:	mov    r14,QWORD PTR [r12+0x50]
    2a32:	add    r14,r13
    2a35:	movdqu xmm2,XMMWORD PTR [r14]
    2a3a:	movdqu XMMWORD PTR [r12+0x120],xmm2
    2a44:	add    r13,0x10
    2a48:	mov    QWORD PTR [r12+0x48],r13
    2a4d:	sub    r13,0x200
    2a54:	mov    r13,QWORD PTR [r12+0x128]
    2a5c:	mov    r14d,0x0
    2a62:	mov    QWORD PTR [r12+0x130],r13
    2a6a:	mov    QWORD PTR [r12+0x138],r14
    2a72:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    2a7c:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    2a86:	movdqa xmm0,xmm2
    2a8a:	movdqa xmm1,xmm3
    2a8e:	movq   xmm0,xmm0
    2a92:	movq   xmm1,xmm1
    2a96:	addsd  xmm0,xmm1
    2a9a:	movdqa xmm14,xmm0
    2a9f:	movdqu xmm15,XMMWORD PTR [rip+0x77e8]        # 0xa290
    2aa8:	pand   xmm14,xmm15
    2aad:	movdqu xmm15,XMMWORD PTR [rip+0x77ea]        # 0xa2a0
    2ab6:	pcmpeqq xmm14,xmm15
    2abc:	movdqa xmm15,xmm0
    2ac1:	cmpunordpd xmm15,xmm0
    2ac7:	por    xmm14,xmm15
    2acc:	pmovmskb ecx,xmm14
    2ad1:	jrcxz  0x2ad8
    2ad3:	jmp    0x35ed
    2ad8:	movdqa xmm4,xmm0
    2adc:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    2ae6:	movdqa xmm0,xmm4
    2aea:	movdqa xmm1,xmm2
    2aee:	movq   xmm0,xmm0
    2af2:	movq   xmm1,xmm1
    2af6:	addsd  xmm0,xmm1
    2afa:	movdqa xmm14,xmm0
    2aff:	movdqu xmm15,XMMWORD PTR [rip+0x7788]        # 0xa290
    2b08:	pand   xmm14,xmm15
    2b0d:	movdqu xmm15,XMMWORD PTR [rip+0x778a]        # 0xa2a0
    2b16:	pcmpeqq xmm14,xmm15
    2b1c:	movdqa xmm15,xmm0
    2b21:	cmpunordpd xmm15,xmm0
    2b27:	por    xmm14,xmm15
    2b2c:	pmovmskb ecx,xmm14
    2b31:	jrcxz  0x2b38
    2b33:	jmp    0x362c
    2b38:	movdqa xmm3,xmm0
    2b3c:	movdqu XMMWORD PTR [r12+0x110],xmm3
    2b46:	mov    rcx,QWORD PTR [r12+0x380]
    2b4e:	jrcxz  0x2b55
    2b50:	jmp    0x9bd2
    2b55:	jne    0x2b6e
    2b5b:	mov    r11,rax
    2b5e:	lahf
    2b5f:	seto   al
    2b62:	mov    WORD PTR [rsp],ax
    2b66:	mov    rax,r11
    2b69:	jmp    0x2b81
    2b6e:	mov    r11,rax
    2b71:	lahf
    2b72:	seto   al
    2b75:	mov    WORD PTR [rsp],ax
    2b79:	mov    rax,r11
    2b7c:	jmp    0x2a28
    2b81:	mov    r13,QWORD PTR [r12+0x40]
    2b86:	add    r13,0x510
    2b8d:	mov    r14,QWORD PTR [r12+0x110]
    2b95:	mov    QWORD PTR [r13+0x0],r14
    2b99:	mov    r13d,0x0
    2b9f:	mov    DWORD PTR [r12+0x32c],r13d
    2ba7:	mov    rcx,QWORD PTR [r12+0x380]
    2baf:	jrcxz  0x2bb6
    2bb1:	jmp    0x9c66
    2bb6:	mov    r13,QWORD PTR [r12+0xf0]
    2bbe:	mov    QWORD PTR [r12+0x100],r13
    2bc6:	mov    r11,QWORD PTR [rsp]
    2bca:	mov    QWORD PTR [r12+0x398],r11
    2bd2:	mov    rdi,QWORD PTR [r12+0x100]
    2bda:	add    rsp,0x150
    2be1:	movabs r11,0x63ec266e1940
    2beb:	jmp    r11
    2bee:	movdqa xmm0,xmm2
    2bf2:	movdqa xmm1,xmm3
    2bf6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2bff:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2c08:	call   0x3670
    2c0d:	jmp    0x571
    2c12:	movdqa xmm0,xmm2
    2c16:	movdqa xmm1,xmm3
    2c1a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2c23:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2c2c:	call   0x3670
    2c31:	jmp    0x5fd
    2c36:	movdqa xmm0,xmm9
    2c3b:	movdqa xmm1,xmm2
    2c3f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2c48:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2c51:	call   0x3740
    2c56:	jmp    0xd57
    2c5b:	movdqa xmm0,xmm8
    2c60:	movdqa xmm1,xmm2
    2c64:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2c6d:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2c76:	call   0x3850
    2c7b:	jmp    0xdb6
    2c80:	movdqa xmm0,xmm9
    2c85:	movdqa xmm1,xmm7
    2c89:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2c92:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2c9b:	call   0x3970
    2ca0:	jmp    0xe2b
    2ca5:	movdqa xmm0,xmm9
    2caa:	movdqa xmm1,xmm6
    2cae:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2cb7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2cc0:	call   0x3a90
    2cc5:	jmp    0xe7b
    2cca:	movdqa xmm0,xmm9
    2ccf:	movdqa xmm1,xmm6
    2cd3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2cdc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2ce5:	call   0x3bb0
    2cea:	jmp    0xed4
    2cef:	movdqa xmm0,xmm9
    2cf4:	movdqa xmm1,xmm2
    2cf8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2d01:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2d0a:	call   0x3ce0
    2d0f:	jmp    0xf75
    2d14:	mov    r11,rax
    2d17:	lahf
    2d18:	seto   al
    2d1b:	mov    WORD PTR [rsp],ax
    2d1f:	mov    rax,r11
    2d22:	movdqa xmm0,xmm10
    2d27:	movdqa xmm1,xmm9
    2d2c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2d35:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2d3e:	call   0x3e20
    2d43:	mov    r11,rax
    2d46:	movzx  eax,WORD PTR [rsp]
    2d4a:	add    al,0x7f
    2d4c:	sahf
    2d4d:	mov    rax,r11
    2d50:	jmp    0xfe0
    2d55:	mov    r11,rax
    2d58:	lahf
    2d59:	seto   al
    2d5c:	mov    WORD PTR [rsp],ax
    2d60:	mov    rax,r11
    2d63:	movdqa xmm0,xmm8
    2d68:	movdqa xmm1,xmm10
    2d6d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2d76:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2d7f:	call   0x3e20
    2d84:	mov    r11,rax
    2d87:	movzx  eax,WORD PTR [rsp]
    2d8b:	add    al,0x7f
    2d8d:	sahf
    2d8e:	mov    rax,r11
    2d91:	jmp    0x1040
    2d96:	mov    r11,rax
    2d99:	lahf
    2d9a:	seto   al
    2d9d:	mov    WORD PTR [rsp],ax
    2da1:	mov    rax,r11
    2da4:	movdqa xmm0,xmm7
    2da8:	movdqa xmm1,xmm10
    2dad:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2db6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2dbf:	call   0x3ff0
    2dc4:	mov    r11,rax
    2dc7:	movzx  eax,WORD PTR [rsp]
    2dcb:	add    al,0x7f
    2dcd:	sahf
    2dce:	mov    rax,r11
    2dd1:	jmp    0x1099
    2dd6:	movdqa xmm0,xmm12
    2ddb:	movdqa xmm1,xmm9
    2de0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2de9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2df2:	call   0x41b0
    2df7:	jmp    0x1211
    2dfc:	movdqa xmm0,xmm6
    2e00:	movdqa xmm1,xmm4
    2e04:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2e0d:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2e16:	call   0x43b0
    2e1b:	jmp    0x127f
    2e20:	movdqa xmm0,xmm8
    2e25:	movdqa xmm1,xmm11
    2e2a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2e33:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2e3c:	call   0x45a0
    2e41:	jmp    0x12da
    2e46:	movdqa xmm0,xmm5
    2e4a:	movdqa xmm1,xmm2
    2e4e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2e57:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2e60:	call   0x4790
    2e65:	jmp    0x1337
    2e6a:	movdqa xmm0,xmm9
    2e6f:	movdqa xmm1,xmm5
    2e73:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2e7c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2e85:	call   0x4960
    2e8a:	jmp    0x139f
    2e8f:	movdqa xmm0,xmm13
    2e94:	movdqa xmm1,xmm2
    2e98:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2ea1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2eaa:	call   0x4b40
    2eaf:	jmp    0x1418
    2eb4:	movdqa xmm0,xmm9
    2eb9:	movdqa xmm1,xmm5
    2ebd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2ec6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2ecf:	call   0x4d30
    2ed4:	jmp    0x14a5
    2ed9:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    2ee3:	movdqa xmm1,xmm6
    2ee7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2ef0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2ef9:	call   0x4ef0
    2efe:	jmp    0x159a
    2f03:	movdqa xmm0,xmm9
    2f08:	movdqa xmm1,xmm5
    2f0c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2f15:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2f1e:	call   0x50d0
    2f23:	jmp    0x15f8
    2f28:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    2f32:	movdqa xmm1,xmm11
    2f37:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2f40:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2f49:	call   0x52b0
    2f4e:	jmp    0x1671
    2f53:	movdqa xmm0,xmm12
    2f58:	movdqa xmm1,xmm8
    2f5d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2f66:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2f6f:	call   0x54a0
    2f74:	jmp    0x16cc
    2f79:	movdqa xmm0,xmm9
    2f7e:	movdqa xmm1,xmm5
    2f82:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2f8b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2f94:	call   0x5690
    2f99:	jmp    0x174d
    2f9e:	movdqa xmm0,xmm4
    2fa2:	movdqa xmm1,xmm2
    2fa6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2faf:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2fb8:	call   0x5870
    2fbd:	jmp    0x17c0
    2fc2:	movdqa xmm0,xmm13
    2fc7:	movdqa xmm1,xmm2
    2fcb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2fd4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    2fdd:	call   0x5a50
    2fe2:	jmp    0x1829
    2fe7:	movdqa xmm0,xmm5
    2feb:	movdqa xmm1,xmm2
    2fef:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    2ff8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3001:	call   0x5c30
    3006:	jmp    0x18a1
    300b:	movdqa xmm0,xmm3
    300f:	movdqa xmm1,xmm6
    3013:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    301c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3025:	call   0x5e10
    302a:	jmp    0x1914
    302f:	movdqa xmm0,xmm5
    3033:	movdqa xmm1,xmm2
    3037:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3040:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3049:	call   0x6000
    304e:	jmp    0x19b6
    3053:	movdqa xmm0,xmm10
    3058:	movdqa xmm1,xmm12
    305d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3066:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    306f:	call   0x61f0
    3074:	jmp    0x1a27
    3079:	movdqa xmm0,xmm7
    307d:	movdqa xmm1,xmm2
    3081:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    308a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3093:	call   0x63f0
    3098:	jmp    0x1a7a
    309d:	movdqa xmm0,xmm11
    30a2:	movdqa xmm1,xmm13
    30a7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    30b0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    30b9:	call   0x65d0
    30be:	jmp    0x1acb
    30c3:	movdqa xmm0,xmm5
    30c7:	movdqa xmm1,xmm7
    30cb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    30d4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    30dd:	call   0x67b0
    30e2:	jmp    0x1b28
    30e7:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    30f1:	movdqa xmm1,xmm7
    30f5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    30fe:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3107:	call   0x6980
    310c:	jmp    0x1b82
    3111:	movdqa xmm0,xmm8
    3116:	movdqa xmm1,xmm4
    311a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3123:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    312c:	call   0x6b50
    3131:	jmp    0x1bd1
    3136:	movdqa xmm0,xmm9
    313b:	movdqa xmm1,xmm6
    313f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3148:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3151:	call   0x6d30
    3156:	jmp    0x1c2b
    315b:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    3165:	movdqa xmm1,xmm7
    3169:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3172:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    317b:	call   0x6f00
    3180:	jmp    0x1c8e
    3185:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    318f:	movdqa xmm1,xmm7
    3193:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    319c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    31a5:	call   0x70c0
    31aa:	jmp    0x1ce7
    31af:	movdqa xmm0,xmm3
    31b3:	movdqa xmm1,xmm10
    31b8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    31c1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    31ca:	call   0x7290
    31cf:	jmp    0x1d41
    31d4:	movdqa xmm0,xmm2
    31d8:	movdqa xmm1,xmm11
    31dd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    31e6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    31ef:	call   0x7460
    31f4:	jmp    0x1d9a
    31f9:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    3203:	movdqa xmm1,xmm2
    3207:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3210:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3219:	call   0x7620
    321e:	jmp    0x1e07
    3223:	movdqa xmm0,xmm4
    3227:	movdqa xmm1,xmm5
    322b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3234:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    323d:	call   0x77d0
    3242:	jmp    0x1e60
    3247:	movdqa xmm0,xmm12
    324c:	movdqa xmm1,xmm6
    3250:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3259:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3262:	call   0x79a0
    3267:	jmp    0x1eba
    326c:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    3276:	movdqa xmm1,xmm2
    327a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3283:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    328c:	call   0x67b0
    3291:	jmp    0x1f9a
    3296:	movdqa xmm0,xmm7
    329a:	movdqa xmm1,xmm8
    329f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    32a8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    32b1:	call   0x6b50
    32b6:	jmp    0x1fea
    32bb:	movdqa xmm0,xmm3
    32bf:	movdqa xmm1,xmm9
    32c4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    32cd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    32d6:	call   0x7b60
    32db:	jmp    0x203a
    32e0:	movdqa xmm0,xmm6
    32e4:	movdqa xmm1,xmm2
    32e8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    32f1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    32fa:	call   0x7d30
    32ff:	jmp    0x2097
    3304:	movdqa xmm0,xmm6
    3308:	movdqa xmm1,xmm2
    330c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3315:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    331e:	call   0x70c0
    3323:	jmp    0x20fe
    3328:	movdqa xmm0,xmm5
    332c:	movdqa xmm1,xmm2
    3330:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3339:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3342:	call   0x7ef0
    3347:	jmp    0x215c
    334c:	movdqa xmm0,xmm10
    3351:	movdqa xmm1,xmm11
    3356:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    335f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3368:	call   0x80c0
    336d:	jmp    0x21b6
    3372:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    337c:	movdqa xmm1,xmm2
    3380:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3389:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3392:	call   0x7620
    3397:	jmp    0x2219
    339c:	movdqa xmm0,xmm4
    33a0:	movdqa xmm1,xmm3
    33a4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    33ad:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    33b6:	call   0x77d0
    33bb:	jmp    0x2272
    33c0:	movdqa xmm0,xmm3
    33c4:	movdqa xmm1,xmm2
    33c8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    33d1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    33da:	call   0x8290
    33df:	jmp    0x22da
    33e4:	movdqa xmm0,xmm12
    33e9:	movdqa xmm1,xmm8
    33ee:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    33f7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3400:	call   0x8460
    3405:	jmp    0x2334
    340a:	movdqa xmm0,xmm8
    340f:	movdqa xmm1,xmm2
    3413:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    341c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3425:	call   0x67b0
    342a:	jmp    0x239c
    342f:	movdqa xmm0,xmm7
    3433:	movdqa xmm1,xmm6
    3437:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3440:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3449:	call   0x8630
    344e:	jmp    0x23f5
    3453:	movdqa xmm0,xmm5
    3457:	movdqa xmm1,xmm9
    345c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3465:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    346e:	call   0x87f0
    3473:	jmp    0x2465
    3478:	movdqa xmm0,xmm6
    347c:	movdqa xmm1,xmm5
    3480:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3489:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3492:	call   0x89b0
    3497:	jmp    0x24cc
    349c:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    34a6:	movdqa xmm1,xmm5
    34aa:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    34b3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    34bc:	call   0x8b60
    34c1:	jmp    0x2530
    34c6:	movdqa xmm0,xmm10
    34cb:	movdqa xmm1,xmm4
    34cf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    34d8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    34e1:	call   0x8d20
    34e6:	jmp    0x2589
    34eb:	movdqa xmm0,xmm3
    34ef:	movdqa xmm1,xmm11
    34f4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    34fd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3506:	call   0x6b50
    350b:	jmp    0x25ff
    3510:	movdqa xmm0,xmm10
    3515:	movdqa xmm1,xmm5
    3519:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3522:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    352b:	call   0x8ef0
    3530:	jmp    0x265e
    3535:	movdqa xmm0,xmm4
    3539:	movdqa xmm1,xmm5
    353d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    3546:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    354f:	call   0x90c0
    3554:	jmp    0x26bb
    3559:	movdqa xmm0,xmm2
    355d:	movdqa xmm1,xmm8
    3562:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    356b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3574:	call   0x79a0
    3579:	jmp    0x270b
    357e:	movdqa xmm0,xmm7
    3582:	movdqa xmm1,xmm6
    3586:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    358f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3598:	call   0x9290
    359d:	jmp    0x2763
    35a2:	movdqa xmm0,xmm9
    35a7:	movdqa xmm1,xmm3
    35ab:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    35b4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    35bd:	call   0x9440
    35c2:	jmp    0x27bc
    35c7:	movdqa xmm0,xmm12
    35cc:	movdqa xmm1,xmm10
    35d1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    35da:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    35e3:	call   0x95e0
    35e8:	jmp    0x2816
    35ed:	mov    r11,rax
    35f0:	lahf
    35f1:	seto   al
    35f4:	mov    WORD PTR [rsp],ax
    35f8:	mov    rax,r11
    35fb:	movdqa xmm0,xmm2
    35ff:	movdqa xmm1,xmm3
    3603:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    360c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3615:	call   0x9770
    361a:	mov    r11,rax
    361d:	movzx  eax,WORD PTR [rsp]
    3621:	add    al,0x7f
    3623:	sahf
    3624:	mov    rax,r11
    3627:	jmp    0x2ad8
    362c:	mov    r11,rax
    362f:	lahf
    3630:	seto   al
    3633:	mov    WORD PTR [rsp],ax
    3637:	mov    rax,r11
    363a:	movdqa xmm0,xmm4
    363e:	movdqa xmm1,xmm2
    3642:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    364b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    3654:	call   0x98d0
    3659:	mov    r11,rax
    365c:	movzx  eax,WORD PTR [rsp]
    3660:	add    al,0x7f
    3662:	sahf
    3663:	mov    rax,r11
    3666:	jmp    0x2b38
    366b:	nop    DWORD PTR [rax+rax*1+0x0]
    3670:	sub    rsp,0x8
    3674:	mov    QWORD PTR [r12+0x378],0x3
    3680:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    3686:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    368c:	mov    QWORD PTR [r12+0x108],rbx
    3694:	stmxcsr DWORD PTR [r12-0x28]
    369a:	mov    r10d,DWORD PTR [r12-0x28]
    369f:	test   r10d,0x3f
    36a6:	je     0x36cb
    36ac:	mov    r11d,r10d
    36af:	shr    r10d,1
    36b2:	and    r10d,0x1e
    36b6:	and    r11d,0x1
    36ba:	or     r10d,r11d
    36bd:	or     DWORD PTR [r12+0x314],r10d
    36c5:	and    DWORD PTR [r12-0x28],0xffffffc0
    36cb:	ldmxcsr DWORD PTR [r12-0x38]
    36d1:	lea    rdi,[rsp+0x110]
    36d9:	lea    rsi,[rsp+0xf0]
    36e1:	lea    rdx,[rsp+0x100]
    36e9:	mov    ecx,0x16
    36ee:	mov    r8d,0x0
    36f4:	lea    r9,[r12+0x314]
    36fc:	movabs r11,0x63ec26548650
    3706:	call   r11
    3709:	ldmxcsr DWORD PTR [r12-0x28]
    370f:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3715:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    371b:	mov    rbx,QWORD PTR [r12+0x108]
    3723:	mov    QWORD PTR [r12+0x378],0x2
    372f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    3738:	add    rsp,0x8
    373c:	ret
    373d:	nop    DWORD PTR [rax]
    3740:	sub    rsp,0x8
    3744:	mov    QWORD PTR [r12+0x378],0x3
    3750:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    3756:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    375c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    3762:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    376c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    3776:	mov    QWORD PTR [r12+0x108],rbx
    377e:	stmxcsr DWORD PTR [r12-0x28]
    3784:	mov    r10d,DWORD PTR [r12-0x28]
    3789:	test   r10d,0x3f
    3790:	je     0x37b5
    3796:	mov    r11d,r10d
    3799:	shr    r10d,1
    379c:	and    r10d,0x1e
    37a0:	and    r11d,0x1
    37a4:	or     r10d,r11d
    37a7:	or     DWORD PTR [r12+0x314],r10d
    37af:	and    DWORD PTR [r12-0x28],0xffffffc0
    37b5:	ldmxcsr DWORD PTR [r12-0x38]
    37bb:	lea    rdi,[rsp+0x110]
    37c3:	lea    rsi,[rsp+0xf0]
    37cb:	lea    rdx,[rsp+0x100]
    37d3:	mov    ecx,0x16
    37d8:	mov    r8d,0x0
    37de:	lea    r9,[r12+0x314]
    37e6:	movabs r11,0x63ec26548650
    37f0:	call   r11
    37f3:	ldmxcsr DWORD PTR [r12-0x28]
    37f9:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    37ff:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    3805:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    380b:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    3815:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    381f:	mov    rbx,QWORD PTR [r12+0x108]
    3827:	mov    QWORD PTR [r12+0x378],0x2
    3833:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    383c:	add    rsp,0x8
    3840:	ret
    3841:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    3850:	sub    rsp,0x8
    3854:	mov    QWORD PTR [r12+0x378],0x3
    3860:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    3866:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    386c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    3872:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    387c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    3886:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    3890:	mov    QWORD PTR [r12+0x108],rbx
    3898:	stmxcsr DWORD PTR [r12-0x28]
    389e:	mov    r10d,DWORD PTR [r12-0x28]
    38a3:	test   r10d,0x3f
    38aa:	je     0x38cf
    38b0:	mov    r11d,r10d
    38b3:	shr    r10d,1
    38b6:	and    r10d,0x1e
    38ba:	and    r11d,0x1
    38be:	or     r10d,r11d
    38c1:	or     DWORD PTR [r12+0x314],r10d
    38c9:	and    DWORD PTR [r12-0x28],0xffffffc0
    38cf:	ldmxcsr DWORD PTR [r12-0x38]
    38d5:	lea    rdi,[rsp+0x110]
    38dd:	lea    rsi,[rsp+0xf0]
    38e5:	lea    rdx,[rsp+0x100]
    38ed:	mov    ecx,0x56
    38f2:	mov    r8d,0x0
    38f8:	lea    r9,[r12+0x314]
    3900:	movabs r11,0x63ec26548650
    390a:	call   r11
    390d:	ldmxcsr DWORD PTR [r12-0x28]
    3913:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3919:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    391f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    3925:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    392f:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    3939:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    3943:	mov    rbx,QWORD PTR [r12+0x108]
    394b:	mov    QWORD PTR [r12+0x378],0x2
    3957:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    3960:	add    rsp,0x8
    3964:	ret
    3965:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    3970:	sub    rsp,0x8
    3974:	mov    QWORD PTR [r12+0x378],0x3
    3980:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    3986:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    398c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    3992:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    399c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    39a6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    39b0:	mov    QWORD PTR [r12+0x108],rbx
    39b8:	stmxcsr DWORD PTR [r12-0x28]
    39be:	mov    r10d,DWORD PTR [r12-0x28]
    39c3:	test   r10d,0x3f
    39ca:	je     0x39ef
    39d0:	mov    r11d,r10d
    39d3:	shr    r10d,1
    39d6:	and    r10d,0x1e
    39da:	and    r11d,0x1
    39de:	or     r10d,r11d
    39e1:	or     DWORD PTR [r12+0x314],r10d
    39e9:	and    DWORD PTR [r12-0x28],0xffffffc0
    39ef:	ldmxcsr DWORD PTR [r12-0x38]
    39f5:	lea    rdi,[rsp+0x110]
    39fd:	lea    rsi,[rsp+0xf0]
    3a05:	lea    rdx,[rsp+0x100]
    3a0d:	mov    ecx,0x16
    3a12:	mov    r8d,0x0
    3a18:	lea    r9,[r12+0x314]
    3a20:	movabs r11,0x63ec26548650
    3a2a:	call   r11
    3a2d:	ldmxcsr DWORD PTR [r12-0x28]
    3a33:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3a39:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    3a3f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    3a45:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    3a4f:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    3a59:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    3a63:	mov    rbx,QWORD PTR [r12+0x108]
    3a6b:	mov    QWORD PTR [r12+0x378],0x2
    3a77:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    3a80:	add    rsp,0x8
    3a84:	ret
    3a85:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    3a90:	sub    rsp,0x8
    3a94:	mov    QWORD PTR [r12+0x378],0x3
    3aa0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    3aa6:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    3aac:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    3ab6:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    3ac0:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    3aca:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    3ad4:	mov    QWORD PTR [r12+0x108],rbx
    3adc:	stmxcsr DWORD PTR [r12-0x28]
    3ae2:	mov    r10d,DWORD PTR [r12-0x28]
    3ae7:	test   r10d,0x3f
    3aee:	je     0x3b13
    3af4:	mov    r11d,r10d
    3af7:	shr    r10d,1
    3afa:	and    r10d,0x1e
    3afe:	and    r11d,0x1
    3b02:	or     r10d,r11d
    3b05:	or     DWORD PTR [r12+0x314],r10d
    3b0d:	and    DWORD PTR [r12-0x28],0xffffffc0
    3b13:	ldmxcsr DWORD PTR [r12-0x38]
    3b19:	lea    rdi,[rsp+0x110]
    3b21:	lea    rsi,[rsp+0xf0]
    3b29:	lea    rdx,[rsp+0x100]
    3b31:	mov    ecx,0x16
    3b36:	mov    r8d,0x0
    3b3c:	lea    r9,[r12+0x314]
    3b44:	movabs r11,0x63ec26548650
    3b4e:	call   r11
    3b51:	ldmxcsr DWORD PTR [r12-0x28]
    3b57:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3b5d:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    3b63:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    3b6d:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    3b77:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    3b81:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    3b8b:	mov    rbx,QWORD PTR [r12+0x108]
    3b93:	mov    QWORD PTR [r12+0x378],0x2
    3b9f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    3ba8:	add    rsp,0x8
    3bac:	ret
    3bad:	nop    DWORD PTR [rax]
    3bb0:	sub    rsp,0x8
    3bb4:	mov    QWORD PTR [r12+0x378],0x3
    3bc0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    3bc6:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    3bcc:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    3bd2:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    3bdc:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    3be6:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    3bf0:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    3bfa:	mov    QWORD PTR [r12+0x108],rbx
    3c02:	stmxcsr DWORD PTR [r12-0x28]
    3c08:	mov    r10d,DWORD PTR [r12-0x28]
    3c0d:	test   r10d,0x3f
    3c14:	je     0x3c39
    3c1a:	mov    r11d,r10d
    3c1d:	shr    r10d,1
    3c20:	and    r10d,0x1e
    3c24:	and    r11d,0x1
    3c28:	or     r10d,r11d
    3c2b:	or     DWORD PTR [r12+0x314],r10d
    3c33:	and    DWORD PTR [r12-0x28],0xffffffc0
    3c39:	ldmxcsr DWORD PTR [r12-0x38]
    3c3f:	lea    rdi,[rsp+0x110]
    3c47:	lea    rsi,[rsp+0xf0]
    3c4f:	lea    rdx,[rsp+0x100]
    3c57:	mov    ecx,0x16
    3c5c:	mov    r8d,0x0
    3c62:	lea    r9,[r12+0x314]
    3c6a:	movabs r11,0x63ec26548650
    3c74:	call   r11
    3c77:	ldmxcsr DWORD PTR [r12-0x28]
    3c7d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3c83:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    3c89:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    3c8f:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    3c99:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    3ca3:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    3cad:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    3cb7:	mov    rbx,QWORD PTR [r12+0x108]
    3cbf:	mov    QWORD PTR [r12+0x378],0x2
    3ccb:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    3cd4:	add    rsp,0x8
    3cd8:	ret
    3cd9:	nop    DWORD PTR [rax+0x0]
    3ce0:	sub    rsp,0x8
    3ce4:	mov    QWORD PTR [r12+0x378],0x3
    3cf0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    3cf6:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    3cfc:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    3d06:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    3d10:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    3d1a:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    3d24:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    3d2e:	mov    QWORD PTR [r12+0x108],rbx
    3d36:	stmxcsr DWORD PTR [r12-0x28]
    3d3c:	mov    r10d,DWORD PTR [r12-0x28]
    3d41:	test   r10d,0x3f
    3d48:	je     0x3d6d
    3d4e:	mov    r11d,r10d
    3d51:	shr    r10d,1
    3d54:	and    r10d,0x1e
    3d58:	and    r11d,0x1
    3d5c:	or     r10d,r11d
    3d5f:	or     DWORD PTR [r12+0x314],r10d
    3d67:	and    DWORD PTR [r12-0x28],0xffffffc0
    3d6d:	ldmxcsr DWORD PTR [r12-0x38]
    3d73:	lea    rdi,[rsp+0x110]
    3d7b:	lea    rsi,[rsp+0xf0]
    3d83:	lea    rdx,[rsp+0x100]
    3d8b:	mov    ecx,0x56
    3d90:	mov    r8d,0x0
    3d96:	lea    r9,[r12+0x314]
    3d9e:	movabs r11,0x63ec26548650
    3da8:	call   r11
    3dab:	ldmxcsr DWORD PTR [r12-0x28]
    3db1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3db7:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    3dbd:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    3dc7:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    3dd1:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    3ddb:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    3de5:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    3def:	mov    rbx,QWORD PTR [r12+0x108]
    3df7:	mov    QWORD PTR [r12+0x378],0x2
    3e03:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    3e0c:	add    rsp,0x8
    3e10:	ret
    3e11:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    3e20:	sub    rsp,0x8
    3e24:	mov    QWORD PTR [r12+0x378],0x3
    3e30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    3e36:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    3e3c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    3e42:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    3e4c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    3e56:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    3e60:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    3e6a:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    3e74:	push   rdx
    3e75:	push   rsi
    3e76:	push   r10
    3e78:	push   r11
    3e7a:	mov    rdx,QWORD PTR [rsp+0x30]
    3e7f:	mov    r10d,edx
    3e82:	and    r10d,0xc000
    3e89:	shl    r10d,0x10
    3e8d:	mov    r11d,edx
    3e90:	and    r11d,0x100
    3e97:	shl    r11d,0x15
    3e9b:	or     r10d,r11d
    3e9e:	and    edx,0x1
    3ea1:	shl    edx,0x1c
    3ea4:	or     r10d,edx
    3ea7:	btc    r10,0x1d
    3eac:	mov    r11d,0xf0000000
    3eb2:	and    r11,r10
    3eb5:	movabs rsi,0xffffffff0fffffff
    3ebf:	and    rbx,rsi
    3ec2:	or     rbx,r11
    3ec5:	pop    r11
    3ec7:	pop    r10
    3ec9:	pop    rsi
    3eca:	pop    rdx
    3ecb:	mov    QWORD PTR [r12+0x108],rbx
    3ed3:	stmxcsr DWORD PTR [r12-0x28]
    3ed9:	mov    r10d,DWORD PTR [r12-0x28]
    3ede:	test   r10d,0x3f
    3ee5:	je     0x3f0a
    3eeb:	mov    r11d,r10d
    3eee:	shr    r10d,1
    3ef1:	and    r10d,0x1e
    3ef5:	and    r11d,0x1
    3ef9:	or     r10d,r11d
    3efc:	or     DWORD PTR [r12+0x314],r10d
    3f04:	and    DWORD PTR [r12-0x28],0xffffffc0
    3f0a:	ldmxcsr DWORD PTR [r12-0x38]
    3f10:	lea    rdi,[rsp+0x110]
    3f18:	lea    rsi,[rsp+0xf0]
    3f20:	lea    rdx,[rsp+0x100]
    3f28:	mov    ecx,0x14
    3f2d:	mov    r8d,0x0
    3f33:	lea    r9,[r12+0x314]
    3f3b:	movabs r11,0x63ec26548650
    3f45:	call   r11
    3f48:	ldmxcsr DWORD PTR [r12-0x28]
    3f4e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    3f54:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    3f5a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    3f60:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    3f6a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    3f74:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    3f7e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    3f88:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    3f92:	mov    rbx,QWORD PTR [r12+0x108]
    3f9a:	mov    QWORD PTR [r12+0x378],0x2
    3fa6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    3faf:	mov    rdx,rbx
    3fb2:	shr    rdx,0x10
    3fb6:	and    edx,0xc000
    3fbc:	mov    rax,rbx
    3fbf:	shr    rax,0x15
    3fc3:	and    eax,0x100
    3fc8:	xor    eax,0x100
    3fcd:	or     edx,eax
    3fcf:	mov    rax,rbx
    3fd2:	shr    rax,0x1c
    3fd6:	and    eax,0x1
    3fd9:	or     edx,eax
    3fdb:	mov    QWORD PTR [rsp+0x10],rdx
    3fe0:	add    rsp,0x8
    3fe4:	ret
    3fe5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    3ff0:	sub    rsp,0x8
    3ff4:	mov    QWORD PTR [r12+0x378],0x3
    4000:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    4006:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    400c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    4012:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    4018:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    4022:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    402c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    4036:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    4040:	push   rdx
    4041:	push   rsi
    4042:	push   r10
    4044:	push   r11
    4046:	mov    rdx,QWORD PTR [rsp+0x30]
    404b:	mov    r10d,edx
    404e:	and    r10d,0xc000
    4055:	shl    r10d,0x10
    4059:	mov    r11d,edx
    405c:	and    r11d,0x100
    4063:	shl    r11d,0x15
    4067:	or     r10d,r11d
    406a:	and    edx,0x1
    406d:	shl    edx,0x1c
    4070:	or     r10d,edx
    4073:	btc    r10,0x1d
    4078:	mov    r11d,0xf0000000
    407e:	and    r11,r10
    4081:	movabs rsi,0xffffffff0fffffff
    408b:	and    rbx,rsi
    408e:	or     rbx,r11
    4091:	pop    r11
    4093:	pop    r10
    4095:	pop    rsi
    4096:	pop    rdx
    4097:	mov    QWORD PTR [r12+0x108],rbx
    409f:	stmxcsr DWORD PTR [r12-0x28]
    40a5:	mov    r10d,DWORD PTR [r12-0x28]
    40aa:	test   r10d,0x3f
    40b1:	je     0x40d6
    40b7:	mov    r11d,r10d
    40ba:	shr    r10d,1
    40bd:	and    r10d,0x1e
    40c1:	and    r11d,0x1
    40c5:	or     r10d,r11d
    40c8:	or     DWORD PTR [r12+0x314],r10d
    40d0:	and    DWORD PTR [r12-0x28],0xffffffc0
    40d6:	ldmxcsr DWORD PTR [r12-0x38]
    40dc:	lea    rdi,[rsp+0x110]
    40e4:	lea    rsi,[rsp+0xf0]
    40ec:	lea    rdx,[rsp+0x100]
    40f4:	mov    ecx,0x14
    40f9:	mov    r8d,0x0
    40ff:	lea    r9,[r12+0x314]
    4107:	movabs r11,0x63ec26548650
    4111:	call   r11
    4114:	ldmxcsr DWORD PTR [r12-0x28]
    411a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    4120:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    4126:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    412c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    4132:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    413c:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    4146:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    4150:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    415a:	mov    rbx,QWORD PTR [r12+0x108]
    4162:	mov    QWORD PTR [r12+0x378],0x2
    416e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    4177:	mov    rdx,rbx
    417a:	shr    rdx,0x10
    417e:	and    edx,0xc000
    4184:	mov    rax,rbx
    4187:	shr    rax,0x15
    418b:	and    eax,0x100
    4190:	xor    eax,0x100
    4195:	or     edx,eax
    4197:	mov    rax,rbx
    419a:	shr    rax,0x1c
    419e:	and    eax,0x1
    41a1:	or     edx,eax
    41a3:	mov    QWORD PTR [rsp+0x10],rdx
    41a8:	add    rsp,0x8
    41ac:	ret
    41ad:	nop    DWORD PTR [rax]
    41b0:	sub    rsp,0x8
    41b4:	mov    QWORD PTR [r12+0x378],0x3
    41c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    41c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    41cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    41d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    41d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    41de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    41e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    41ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    41f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    4202:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    420c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    4216:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    4220:	push   rdx
    4221:	push   rsi
    4222:	push   r10
    4224:	push   r11
    4226:	mov    rdx,QWORD PTR [rsp+0x30]
    422b:	mov    r10d,edx
    422e:	and    r10d,0xc000
    4235:	shl    r10d,0x10
    4239:	mov    r11d,edx
    423c:	and    r11d,0x100
    4243:	shl    r11d,0x15
    4247:	or     r10d,r11d
    424a:	and    edx,0x1
    424d:	shl    edx,0x1c
    4250:	or     r10d,edx
    4253:	btc    r10,0x1d
    4258:	mov    r11d,0xf0000000
    425e:	and    r11,r10
    4261:	movabs rsi,0xffffffff0fffffff
    426b:	and    rbx,rsi
    426e:	or     rbx,r11
    4271:	pop    r11
    4273:	pop    r10
    4275:	pop    rsi
    4276:	pop    rdx
    4277:	mov    QWORD PTR [r12+0x108],rbx
    427f:	stmxcsr DWORD PTR [r12-0x28]
    4285:	mov    r10d,DWORD PTR [r12-0x28]
    428a:	test   r10d,0x3f
    4291:	je     0x42b6
    4297:	mov    r11d,r10d
    429a:	shr    r10d,1
    429d:	and    r10d,0x1e
    42a1:	and    r11d,0x1
    42a5:	or     r10d,r11d
    42a8:	or     DWORD PTR [r12+0x314],r10d
    42b0:	and    DWORD PTR [r12-0x28],0xffffffc0
    42b6:	ldmxcsr DWORD PTR [r12-0x38]
    42bc:	lea    rdi,[rsp+0x110]
    42c4:	lea    rsi,[rsp+0xf0]
    42cc:	lea    rdx,[rsp+0x100]
    42d4:	mov    ecx,0x14
    42d9:	mov    r8d,0x0
    42df:	lea    r9,[r12+0x314]
    42e7:	movabs r11,0x63ec26548650
    42f1:	call   r11
    42f4:	ldmxcsr DWORD PTR [r12-0x28]
    42fa:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    4300:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    4306:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    430c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    4312:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    4318:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    431e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    4328:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    4332:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    433c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    4346:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    4350:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    435a:	mov    rbx,QWORD PTR [r12+0x108]
    4362:	mov    QWORD PTR [r12+0x378],0x2
    436e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    4377:	mov    rdx,rbx
    437a:	shr    rdx,0x10
    437e:	and    edx,0xc000
    4384:	mov    rax,rbx
    4387:	shr    rax,0x15
    438b:	and    eax,0x100
    4390:	xor    eax,0x100
    4395:	or     edx,eax
    4397:	mov    rax,rbx
    439a:	shr    rax,0x1c
    439e:	and    eax,0x1
    43a1:	or     edx,eax
    43a3:	mov    QWORD PTR [rsp+0x10],rdx
    43a8:	add    rsp,0x8
    43ac:	ret
    43ad:	nop    DWORD PTR [rax]
    43b0:	sub    rsp,0x8
    43b4:	mov    QWORD PTR [r12+0x378],0x3
    43c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    43c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    43cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    43d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    43d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    43de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    43e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    43ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    43f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    4402:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    440c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    4416:	push   rdx
    4417:	push   rsi
    4418:	push   r10
    441a:	push   r11
    441c:	mov    rdx,QWORD PTR [rsp+0x30]
    4421:	mov    r10d,edx
    4424:	and    r10d,0xc000
    442b:	shl    r10d,0x10
    442f:	mov    r11d,edx
    4432:	and    r11d,0x100
    4439:	shl    r11d,0x15
    443d:	or     r10d,r11d
    4440:	and    edx,0x1
    4443:	shl    edx,0x1c
    4446:	or     r10d,edx
    4449:	btc    r10,0x1d
    444e:	mov    r11d,0xf0000000
    4454:	and    r11,r10
    4457:	movabs rsi,0xffffffff0fffffff
    4461:	and    rbx,rsi
    4464:	or     rbx,r11
    4467:	pop    r11
    4469:	pop    r10
    446b:	pop    rsi
    446c:	pop    rdx
    446d:	mov    QWORD PTR [r12+0x108],rbx
    4475:	stmxcsr DWORD PTR [r12-0x28]
    447b:	mov    r10d,DWORD PTR [r12-0x28]
    4480:	test   r10d,0x3f
    4487:	je     0x44ac
    448d:	mov    r11d,r10d
    4490:	shr    r10d,1
    4493:	and    r10d,0x1e
    4497:	and    r11d,0x1
    449b:	or     r10d,r11d
    449e:	or     DWORD PTR [r12+0x314],r10d
    44a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    44ac:	ldmxcsr DWORD PTR [r12-0x38]
    44b2:	lea    rdi,[rsp+0x110]
    44ba:	lea    rsi,[rsp+0xf0]
    44c2:	lea    rdx,[rsp+0x100]
    44ca:	mov    ecx,0x14
    44cf:	mov    r8d,0x0
    44d5:	lea    r9,[r12+0x314]
    44dd:	movabs r11,0x63ec26548650
    44e7:	call   r11
    44ea:	ldmxcsr DWORD PTR [r12-0x28]
    44f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    44f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    44fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    4502:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    4508:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    450e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    4514:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    451e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    4528:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    4532:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    453c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    4546:	mov    rbx,QWORD PTR [r12+0x108]
    454e:	mov    QWORD PTR [r12+0x378],0x2
    455a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    4563:	mov    rdx,rbx
    4566:	shr    rdx,0x10
    456a:	and    edx,0xc000
    4570:	mov    rax,rbx
    4573:	shr    rax,0x15
    4577:	and    eax,0x100
    457c:	xor    eax,0x100
    4581:	or     edx,eax
    4583:	mov    rax,rbx
    4586:	shr    rax,0x1c
    458a:	and    eax,0x1
    458d:	or     edx,eax
    458f:	mov    QWORD PTR [rsp+0x10],rdx
    4594:	add    rsp,0x8
    4598:	ret
    4599:	nop    DWORD PTR [rax+0x0]
    45a0:	sub    rsp,0x8
    45a4:	mov    QWORD PTR [r12+0x378],0x3
    45b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    45b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    45bc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    45c2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    45c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    45d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    45dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    45e6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    45f0:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    45fa:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    4604:	push   rdx
    4605:	push   rsi
    4606:	push   r10
    4608:	push   r11
    460a:	mov    rdx,QWORD PTR [rsp+0x30]
    460f:	mov    r10d,edx
    4612:	and    r10d,0xc000
    4619:	shl    r10d,0x10
    461d:	mov    r11d,edx
    4620:	and    r11d,0x100
    4627:	shl    r11d,0x15
    462b:	or     r10d,r11d
    462e:	and    edx,0x1
    4631:	shl    edx,0x1c
    4634:	or     r10d,edx
    4637:	btc    r10,0x1d
    463c:	mov    r11d,0xf0000000
    4642:	and    r11,r10
    4645:	movabs rsi,0xffffffff0fffffff
    464f:	and    rbx,rsi
    4652:	or     rbx,r11
    4655:	pop    r11
    4657:	pop    r10
    4659:	pop    rsi
    465a:	pop    rdx
    465b:	mov    QWORD PTR [r12+0x108],rbx
    4663:	stmxcsr DWORD PTR [r12-0x28]
    4669:	mov    r10d,DWORD PTR [r12-0x28]
    466e:	test   r10d,0x3f
    4675:	je     0x469a
    467b:	mov    r11d,r10d
    467e:	shr    r10d,1
    4681:	and    r10d,0x1e
    4685:	and    r11d,0x1
    4689:	or     r10d,r11d
    468c:	or     DWORD PTR [r12+0x314],r10d
    4694:	and    DWORD PTR [r12-0x28],0xffffffc0
    469a:	ldmxcsr DWORD PTR [r12-0x38]
    46a0:	lea    rdi,[rsp+0x110]
    46a8:	lea    rsi,[rsp+0xf0]
    46b0:	lea    rdx,[rsp+0x100]
    46b8:	mov    ecx,0x14
    46bd:	mov    r8d,0x0
    46c3:	lea    r9,[r12+0x314]
    46cb:	movabs r11,0x63ec26548650
    46d5:	call   r11
    46d8:	ldmxcsr DWORD PTR [r12-0x28]
    46de:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    46e4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    46ea:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    46f0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    46f6:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    4700:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    470a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    4714:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    471e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    4728:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    4732:	mov    rbx,QWORD PTR [r12+0x108]
    473a:	mov    QWORD PTR [r12+0x378],0x2
    4746:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    474f:	mov    rdx,rbx
    4752:	shr    rdx,0x10
    4756:	and    edx,0xc000
    475c:	mov    rax,rbx
    475f:	shr    rax,0x15
    4763:	and    eax,0x100
    4768:	xor    eax,0x100
    476d:	or     edx,eax
    476f:	mov    rax,rbx
    4772:	shr    rax,0x1c
    4776:	and    eax,0x1
    4779:	or     edx,eax
    477b:	mov    QWORD PTR [rsp+0x10],rdx
    4780:	add    rsp,0x8
    4784:	ret
    4785:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    4790:	sub    rsp,0x8
    4794:	mov    QWORD PTR [r12+0x378],0x3
    47a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    47a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    47ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    47b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    47b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    47be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    47c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    47d2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    47dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    47e6:	push   rdx
    47e7:	push   rsi
    47e8:	push   r10
    47ea:	push   r11
    47ec:	mov    rdx,QWORD PTR [rsp+0x30]
    47f1:	mov    r10d,edx
    47f4:	and    r10d,0xc000
    47fb:	shl    r10d,0x10
    47ff:	mov    r11d,edx
    4802:	and    r11d,0x100
    4809:	shl    r11d,0x15
    480d:	or     r10d,r11d
    4810:	and    edx,0x1
    4813:	shl    edx,0x1c
    4816:	or     r10d,edx
    4819:	btc    r10,0x1d
    481e:	mov    r11d,0xf0000000
    4824:	and    r11,r10
    4827:	movabs rsi,0xffffffff0fffffff
    4831:	and    rbx,rsi
    4834:	or     rbx,r11
    4837:	pop    r11
    4839:	pop    r10
    483b:	pop    rsi
    483c:	pop    rdx
    483d:	mov    QWORD PTR [r12+0x108],rbx
    4845:	stmxcsr DWORD PTR [r12-0x28]
    484b:	mov    r10d,DWORD PTR [r12-0x28]
    4850:	test   r10d,0x3f
    4857:	je     0x487c
    485d:	mov    r11d,r10d
    4860:	shr    r10d,1
    4863:	and    r10d,0x1e
    4867:	and    r11d,0x1
    486b:	or     r10d,r11d
    486e:	or     DWORD PTR [r12+0x314],r10d
    4876:	and    DWORD PTR [r12-0x28],0xffffffc0
    487c:	ldmxcsr DWORD PTR [r12-0x38]
    4882:	lea    rdi,[rsp+0x110]
    488a:	lea    rsi,[rsp+0xf0]
    4892:	lea    rdx,[rsp+0x100]
    489a:	mov    ecx,0x56
    489f:	mov    r8d,0x0
    48a5:	lea    r9,[r12+0x314]
    48ad:	movabs r11,0x63ec26548650
    48b7:	call   r11
    48ba:	ldmxcsr DWORD PTR [r12-0x28]
    48c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    48c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    48cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    48d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    48d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    48de:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    48e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    48f2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    48fc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    4906:	mov    rbx,QWORD PTR [r12+0x108]
    490e:	mov    QWORD PTR [r12+0x378],0x2
    491a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    4923:	mov    rdx,rbx
    4926:	shr    rdx,0x10
    492a:	and    edx,0xc000
    4930:	mov    rax,rbx
    4933:	shr    rax,0x15
    4937:	and    eax,0x100
    493c:	xor    eax,0x100
    4941:	or     edx,eax
    4943:	mov    rax,rbx
    4946:	shr    rax,0x1c
    494a:	and    eax,0x1
    494d:	or     edx,eax
    494f:	mov    QWORD PTR [rsp+0x10],rdx
    4954:	add    rsp,0x8
    4958:	ret
    4959:	nop    DWORD PTR [rax+0x0]
    4960:	sub    rsp,0x8
    4964:	mov    QWORD PTR [r12+0x378],0x3
    4970:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    4976:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    497c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    4982:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    4988:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    498e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    4994:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    499e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    49a8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    49b2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    49bc:	push   rdx
    49bd:	push   rsi
    49be:	push   r10
    49c0:	push   r11
    49c2:	mov    rdx,QWORD PTR [rsp+0x30]
    49c7:	mov    r10d,edx
    49ca:	and    r10d,0xc000
    49d1:	shl    r10d,0x10
    49d5:	mov    r11d,edx
    49d8:	and    r11d,0x100
    49df:	shl    r11d,0x15
    49e3:	or     r10d,r11d
    49e6:	and    edx,0x1
    49e9:	shl    edx,0x1c
    49ec:	or     r10d,edx
    49ef:	btc    r10,0x1d
    49f4:	mov    r11d,0xf0000000
    49fa:	and    r11,r10
    49fd:	movabs rsi,0xffffffff0fffffff
    4a07:	and    rbx,rsi
    4a0a:	or     rbx,r11
    4a0d:	pop    r11
    4a0f:	pop    r10
    4a11:	pop    rsi
    4a12:	pop    rdx
    4a13:	mov    QWORD PTR [r12+0x108],rbx
    4a1b:	stmxcsr DWORD PTR [r12-0x28]
    4a21:	mov    r10d,DWORD PTR [r12-0x28]
    4a26:	test   r10d,0x3f
    4a2d:	je     0x4a52
    4a33:	mov    r11d,r10d
    4a36:	shr    r10d,1
    4a39:	and    r10d,0x1e
    4a3d:	and    r11d,0x1
    4a41:	or     r10d,r11d
    4a44:	or     DWORD PTR [r12+0x314],r10d
    4a4c:	and    DWORD PTR [r12-0x28],0xffffffc0
    4a52:	ldmxcsr DWORD PTR [r12-0x38]
    4a58:	lea    rdi,[rsp+0x110]
    4a60:	lea    rsi,[rsp+0xf0]
    4a68:	lea    rdx,[rsp+0x100]
    4a70:	mov    ecx,0x56
    4a75:	mov    r8d,0x0
    4a7b:	lea    r9,[r12+0x314]
    4a83:	movabs r11,0x63ec26548650
    4a8d:	call   r11
    4a90:	ldmxcsr DWORD PTR [r12-0x28]
    4a96:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    4a9c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    4aa2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    4aa8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    4aae:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    4ab4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    4aba:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    4ac4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    4ace:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    4ad8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    4ae2:	mov    rbx,QWORD PTR [r12+0x108]
    4aea:	mov    QWORD PTR [r12+0x378],0x2
    4af6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    4aff:	mov    rdx,rbx
    4b02:	shr    rdx,0x10
    4b06:	and    edx,0xc000
    4b0c:	mov    rax,rbx
    4b0f:	shr    rax,0x15
    4b13:	and    eax,0x100
    4b18:	xor    eax,0x100
    4b1d:	or     edx,eax
    4b1f:	mov    rax,rbx
    4b22:	shr    rax,0x1c
    4b26:	and    eax,0x1
    4b29:	or     edx,eax
    4b2b:	mov    QWORD PTR [rsp+0x10],rdx
    4b30:	add    rsp,0x8
    4b34:	ret
    4b35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    4b40:	sub    rsp,0x8
    4b44:	mov    QWORD PTR [r12+0x378],0x3
    4b50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    4b56:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    4b5c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    4b62:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    4b68:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    4b6e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    4b74:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    4b7e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    4b88:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    4b92:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    4b9c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    4ba6:	push   rdx
    4ba7:	push   rsi
    4ba8:	push   r10
    4baa:	push   r11
    4bac:	mov    rdx,QWORD PTR [rsp+0x30]
    4bb1:	mov    r10d,edx
    4bb4:	and    r10d,0xc000
    4bbb:	shl    r10d,0x10
    4bbf:	mov    r11d,edx
    4bc2:	and    r11d,0x100
    4bc9:	shl    r11d,0x15
    4bcd:	or     r10d,r11d
    4bd0:	and    edx,0x1
    4bd3:	shl    edx,0x1c
    4bd6:	or     r10d,edx
    4bd9:	btc    r10,0x1d
    4bde:	mov    r11d,0xf0000000
    4be4:	and    r11,r10
    4be7:	movabs rsi,0xffffffff0fffffff
    4bf1:	and    rbx,rsi
    4bf4:	or     rbx,r11
    4bf7:	pop    r11
    4bf9:	pop    r10
    4bfb:	pop    rsi
    4bfc:	pop    rdx
    4bfd:	mov    QWORD PTR [r12+0x108],rbx
    4c05:	stmxcsr DWORD PTR [r12-0x28]
    4c0b:	mov    r10d,DWORD PTR [r12-0x28]
    4c10:	test   r10d,0x3f
    4c17:	je     0x4c3c
    4c1d:	mov    r11d,r10d
    4c20:	shr    r10d,1
    4c23:	and    r10d,0x1e
    4c27:	and    r11d,0x1
    4c2b:	or     r10d,r11d
    4c2e:	or     DWORD PTR [r12+0x314],r10d
    4c36:	and    DWORD PTR [r12-0x28],0xffffffc0
    4c3c:	ldmxcsr DWORD PTR [r12-0x38]
    4c42:	lea    rdi,[rsp+0x110]
    4c4a:	lea    rsi,[rsp+0xf0]
    4c52:	lea    rdx,[rsp+0x100]
    4c5a:	mov    ecx,0x56
    4c5f:	mov    r8d,0x0
    4c65:	lea    r9,[r12+0x314]
    4c6d:	movabs r11,0x63ec26548650
    4c77:	call   r11
    4c7a:	ldmxcsr DWORD PTR [r12-0x28]
    4c80:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    4c86:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    4c8c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    4c92:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    4c98:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    4c9e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    4ca4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    4cae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    4cb8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    4cc2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    4ccc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    4cd6:	mov    rbx,QWORD PTR [r12+0x108]
    4cde:	mov    QWORD PTR [r12+0x378],0x2
    4cea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    4cf3:	mov    rdx,rbx
    4cf6:	shr    rdx,0x10
    4cfa:	and    edx,0xc000
    4d00:	mov    rax,rbx
    4d03:	shr    rax,0x15
    4d07:	and    eax,0x100
    4d0c:	xor    eax,0x100
    4d11:	or     edx,eax
    4d13:	mov    rax,rbx
    4d16:	shr    rax,0x1c
    4d1a:	and    eax,0x1
    4d1d:	or     edx,eax
    4d1f:	mov    QWORD PTR [rsp+0x10],rdx
    4d24:	add    rsp,0x8
    4d28:	ret
    4d29:	nop    DWORD PTR [rax+0x0]
    4d30:	sub    rsp,0x8
    4d34:	mov    QWORD PTR [r12+0x378],0x3
    4d40:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    4d46:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    4d4c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    4d52:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    4d58:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    4d62:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    4d6c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    4d76:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    4d80:	push   rdx
    4d81:	push   rsi
    4d82:	push   r10
    4d84:	push   r11
    4d86:	mov    rdx,QWORD PTR [rsp+0x30]
    4d8b:	mov    r10d,edx
    4d8e:	and    r10d,0xc000
    4d95:	shl    r10d,0x10
    4d99:	mov    r11d,edx
    4d9c:	and    r11d,0x100
    4da3:	shl    r11d,0x15
    4da7:	or     r10d,r11d
    4daa:	and    edx,0x1
    4dad:	shl    edx,0x1c
    4db0:	or     r10d,edx
    4db3:	btc    r10,0x1d
    4db8:	mov    r11d,0xf0000000
    4dbe:	and    r11,r10
    4dc1:	movabs rsi,0xffffffff0fffffff
    4dcb:	and    rbx,rsi
    4dce:	or     rbx,r11
    4dd1:	pop    r11
    4dd3:	pop    r10
    4dd5:	pop    rsi
    4dd6:	pop    rdx
    4dd7:	mov    QWORD PTR [r12+0x108],rbx
    4ddf:	stmxcsr DWORD PTR [r12-0x28]
    4de5:	mov    r10d,DWORD PTR [r12-0x28]
    4dea:	test   r10d,0x3f
    4df1:	je     0x4e16
    4df7:	mov    r11d,r10d
    4dfa:	shr    r10d,1
    4dfd:	and    r10d,0x1e
    4e01:	and    r11d,0x1
    4e05:	or     r10d,r11d
    4e08:	or     DWORD PTR [r12+0x314],r10d
    4e10:	and    DWORD PTR [r12-0x28],0xffffffc0
    4e16:	ldmxcsr DWORD PTR [r12-0x38]
    4e1c:	lea    rdi,[rsp+0x110]
    4e24:	lea    rsi,[rsp+0xf0]
    4e2c:	lea    rdx,[rsp+0x100]
    4e34:	mov    ecx,0x56
    4e39:	mov    r8d,0x0
    4e3f:	lea    r9,[r12+0x314]
    4e47:	movabs r11,0x63ec26548650
    4e51:	call   r11
    4e54:	ldmxcsr DWORD PTR [r12-0x28]
    4e5a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    4e60:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    4e66:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    4e6c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    4e72:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    4e7c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    4e86:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    4e90:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    4e9a:	mov    rbx,QWORD PTR [r12+0x108]
    4ea2:	mov    QWORD PTR [r12+0x378],0x2
    4eae:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    4eb7:	mov    rdx,rbx
    4eba:	shr    rdx,0x10
    4ebe:	and    edx,0xc000
    4ec4:	mov    rax,rbx
    4ec7:	shr    rax,0x15
    4ecb:	and    eax,0x100
    4ed0:	xor    eax,0x100
    4ed5:	or     edx,eax
    4ed7:	mov    rax,rbx
    4eda:	shr    rax,0x1c
    4ede:	and    eax,0x1
    4ee1:	or     edx,eax
    4ee3:	mov    QWORD PTR [rsp+0x10],rdx
    4ee8:	add    rsp,0x8
    4eec:	ret
    4eed:	nop    DWORD PTR [rax]
    4ef0:	sub    rsp,0x8
    4ef4:	mov    QWORD PTR [r12+0x378],0x3
    4f00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    4f06:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    4f0c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    4f12:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    4f18:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    4f1e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    4f28:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    4f32:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    4f3c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    4f46:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    4f50:	push   rdx
    4f51:	push   rsi
    4f52:	push   r10
    4f54:	push   r11
    4f56:	mov    rdx,QWORD PTR [rsp+0x30]
    4f5b:	mov    r10d,edx
    4f5e:	and    r10d,0xc000
    4f65:	shl    r10d,0x10
    4f69:	mov    r11d,edx
    4f6c:	and    r11d,0x100
    4f73:	shl    r11d,0x15
    4f77:	or     r10d,r11d
    4f7a:	and    edx,0x1
    4f7d:	shl    edx,0x1c
    4f80:	or     r10d,edx
    4f83:	btc    r10,0x1d
    4f88:	mov    r11d,0xf0000000
    4f8e:	and    r11,r10
    4f91:	movabs rsi,0xffffffff0fffffff
    4f9b:	and    rbx,rsi
    4f9e:	or     rbx,r11
    4fa1:	pop    r11
    4fa3:	pop    r10
    4fa5:	pop    rsi
    4fa6:	pop    rdx
    4fa7:	mov    QWORD PTR [r12+0x108],rbx
    4faf:	stmxcsr DWORD PTR [r12-0x28]
    4fb5:	mov    r10d,DWORD PTR [r12-0x28]
    4fba:	test   r10d,0x3f
    4fc1:	je     0x4fe6
    4fc7:	mov    r11d,r10d
    4fca:	shr    r10d,1
    4fcd:	and    r10d,0x1e
    4fd1:	and    r11d,0x1
    4fd5:	or     r10d,r11d
    4fd8:	or     DWORD PTR [r12+0x314],r10d
    4fe0:	and    DWORD PTR [r12-0x28],0xffffffc0
    4fe6:	ldmxcsr DWORD PTR [r12-0x38]
    4fec:	lea    rdi,[rsp+0x110]
    4ff4:	lea    rsi,[rsp+0xf0]
    4ffc:	lea    rdx,[rsp+0x100]
    5004:	mov    ecx,0x14
    5009:	mov    r8d,0x0
    500f:	lea    r9,[r12+0x314]
    5017:	movabs r11,0x63ec26548650
    5021:	call   r11
    5024:	ldmxcsr DWORD PTR [r12-0x28]
    502a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5030:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    5036:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    503c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    5042:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5048:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    5052:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    505c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    5066:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    5070:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    507a:	mov    rbx,QWORD PTR [r12+0x108]
    5082:	mov    QWORD PTR [r12+0x378],0x2
    508e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5097:	mov    rdx,rbx
    509a:	shr    rdx,0x10
    509e:	and    edx,0xc000
    50a4:	mov    rax,rbx
    50a7:	shr    rax,0x15
    50ab:	and    eax,0x100
    50b0:	xor    eax,0x100
    50b5:	or     edx,eax
    50b7:	mov    rax,rbx
    50ba:	shr    rax,0x1c
    50be:	and    eax,0x1
    50c1:	or     edx,eax
    50c3:	mov    QWORD PTR [rsp+0x10],rdx
    50c8:	add    rsp,0x8
    50cc:	ret
    50cd:	nop    DWORD PTR [rax]
    50d0:	sub    rsp,0x8
    50d4:	mov    QWORD PTR [r12+0x378],0x3
    50e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    50e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    50ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    50f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    50f8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    50fe:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    5108:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    5112:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    511c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    5126:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    5130:	push   rdx
    5131:	push   rsi
    5132:	push   r10
    5134:	push   r11
    5136:	mov    rdx,QWORD PTR [rsp+0x30]
    513b:	mov    r10d,edx
    513e:	and    r10d,0xc000
    5145:	shl    r10d,0x10
    5149:	mov    r11d,edx
    514c:	and    r11d,0x100
    5153:	shl    r11d,0x15
    5157:	or     r10d,r11d
    515a:	and    edx,0x1
    515d:	shl    edx,0x1c
    5160:	or     r10d,edx
    5163:	btc    r10,0x1d
    5168:	mov    r11d,0xf0000000
    516e:	and    r11,r10
    5171:	movabs rsi,0xffffffff0fffffff
    517b:	and    rbx,rsi
    517e:	or     rbx,r11
    5181:	pop    r11
    5183:	pop    r10
    5185:	pop    rsi
    5186:	pop    rdx
    5187:	mov    QWORD PTR [r12+0x108],rbx
    518f:	stmxcsr DWORD PTR [r12-0x28]
    5195:	mov    r10d,DWORD PTR [r12-0x28]
    519a:	test   r10d,0x3f
    51a1:	je     0x51c6
    51a7:	mov    r11d,r10d
    51aa:	shr    r10d,1
    51ad:	and    r10d,0x1e
    51b1:	and    r11d,0x1
    51b5:	or     r10d,r11d
    51b8:	or     DWORD PTR [r12+0x314],r10d
    51c0:	and    DWORD PTR [r12-0x28],0xffffffc0
    51c6:	ldmxcsr DWORD PTR [r12-0x38]
    51cc:	lea    rdi,[rsp+0x110]
    51d4:	lea    rsi,[rsp+0xf0]
    51dc:	lea    rdx,[rsp+0x100]
    51e4:	mov    ecx,0x56
    51e9:	mov    r8d,0x0
    51ef:	lea    r9,[r12+0x314]
    51f7:	movabs r11,0x63ec26548650
    5201:	call   r11
    5204:	ldmxcsr DWORD PTR [r12-0x28]
    520a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5210:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5216:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    521c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    5222:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5228:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    5232:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    523c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    5246:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    5250:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    525a:	mov    rbx,QWORD PTR [r12+0x108]
    5262:	mov    QWORD PTR [r12+0x378],0x2
    526e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5277:	mov    rdx,rbx
    527a:	shr    rdx,0x10
    527e:	and    edx,0xc000
    5284:	mov    rax,rbx
    5287:	shr    rax,0x15
    528b:	and    eax,0x100
    5290:	xor    eax,0x100
    5295:	or     edx,eax
    5297:	mov    rax,rbx
    529a:	shr    rax,0x1c
    529e:	and    eax,0x1
    52a1:	or     edx,eax
    52a3:	mov    QWORD PTR [rsp+0x10],rdx
    52a8:	add    rsp,0x8
    52ac:	ret
    52ad:	nop    DWORD PTR [rax]
    52b0:	sub    rsp,0x8
    52b4:	mov    QWORD PTR [r12+0x378],0x3
    52c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    52c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    52cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    52d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    52d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    52de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    52e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    52ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    52f8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    5302:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    530c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    5316:	push   rdx
    5317:	push   rsi
    5318:	push   r10
    531a:	push   r11
    531c:	mov    rdx,QWORD PTR [rsp+0x30]
    5321:	mov    r10d,edx
    5324:	and    r10d,0xc000
    532b:	shl    r10d,0x10
    532f:	mov    r11d,edx
    5332:	and    r11d,0x100
    5339:	shl    r11d,0x15
    533d:	or     r10d,r11d
    5340:	and    edx,0x1
    5343:	shl    edx,0x1c
    5346:	or     r10d,edx
    5349:	btc    r10,0x1d
    534e:	mov    r11d,0xf0000000
    5354:	and    r11,r10
    5357:	movabs rsi,0xffffffff0fffffff
    5361:	and    rbx,rsi
    5364:	or     rbx,r11
    5367:	pop    r11
    5369:	pop    r10
    536b:	pop    rsi
    536c:	pop    rdx
    536d:	mov    QWORD PTR [r12+0x108],rbx
    5375:	stmxcsr DWORD PTR [r12-0x28]
    537b:	mov    r10d,DWORD PTR [r12-0x28]
    5380:	test   r10d,0x3f
    5387:	je     0x53ac
    538d:	mov    r11d,r10d
    5390:	shr    r10d,1
    5393:	and    r10d,0x1e
    5397:	and    r11d,0x1
    539b:	or     r10d,r11d
    539e:	or     DWORD PTR [r12+0x314],r10d
    53a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    53ac:	ldmxcsr DWORD PTR [r12-0x38]
    53b2:	lea    rdi,[rsp+0x110]
    53ba:	lea    rsi,[rsp+0xf0]
    53c2:	lea    rdx,[rsp+0x100]
    53ca:	mov    ecx,0x14
    53cf:	mov    r8d,0x0
    53d5:	lea    r9,[r12+0x314]
    53dd:	movabs r11,0x63ec26548650
    53e7:	call   r11
    53ea:	ldmxcsr DWORD PTR [r12-0x28]
    53f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    53f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    53fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    5402:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    5408:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    540e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5414:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    541e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    5428:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    5432:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    543c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    5446:	mov    rbx,QWORD PTR [r12+0x108]
    544e:	mov    QWORD PTR [r12+0x378],0x2
    545a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5463:	mov    rdx,rbx
    5466:	shr    rdx,0x10
    546a:	and    edx,0xc000
    5470:	mov    rax,rbx
    5473:	shr    rax,0x15
    5477:	and    eax,0x100
    547c:	xor    eax,0x100
    5481:	or     edx,eax
    5483:	mov    rax,rbx
    5486:	shr    rax,0x1c
    548a:	and    eax,0x1
    548d:	or     edx,eax
    548f:	mov    QWORD PTR [rsp+0x10],rdx
    5494:	add    rsp,0x8
    5498:	ret
    5499:	nop    DWORD PTR [rax+0x0]
    54a0:	sub    rsp,0x8
    54a4:	mov    QWORD PTR [r12+0x378],0x3
    54b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    54b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    54bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    54c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    54c8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    54ce:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    54d4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    54de:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    54e8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    54f2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    54fc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    5506:	push   rdx
    5507:	push   rsi
    5508:	push   r10
    550a:	push   r11
    550c:	mov    rdx,QWORD PTR [rsp+0x30]
    5511:	mov    r10d,edx
    5514:	and    r10d,0xc000
    551b:	shl    r10d,0x10
    551f:	mov    r11d,edx
    5522:	and    r11d,0x100
    5529:	shl    r11d,0x15
    552d:	or     r10d,r11d
    5530:	and    edx,0x1
    5533:	shl    edx,0x1c
    5536:	or     r10d,edx
    5539:	btc    r10,0x1d
    553e:	mov    r11d,0xf0000000
    5544:	and    r11,r10
    5547:	movabs rsi,0xffffffff0fffffff
    5551:	and    rbx,rsi
    5554:	or     rbx,r11
    5557:	pop    r11
    5559:	pop    r10
    555b:	pop    rsi
    555c:	pop    rdx
    555d:	mov    QWORD PTR [r12+0x108],rbx
    5565:	stmxcsr DWORD PTR [r12-0x28]
    556b:	mov    r10d,DWORD PTR [r12-0x28]
    5570:	test   r10d,0x3f
    5577:	je     0x559c
    557d:	mov    r11d,r10d
    5580:	shr    r10d,1
    5583:	and    r10d,0x1e
    5587:	and    r11d,0x1
    558b:	or     r10d,r11d
    558e:	or     DWORD PTR [r12+0x314],r10d
    5596:	and    DWORD PTR [r12-0x28],0xffffffc0
    559c:	ldmxcsr DWORD PTR [r12-0x38]
    55a2:	lea    rdi,[rsp+0x110]
    55aa:	lea    rsi,[rsp+0xf0]
    55b2:	lea    rdx,[rsp+0x100]
    55ba:	mov    ecx,0x14
    55bf:	mov    r8d,0x0
    55c5:	lea    r9,[r12+0x314]
    55cd:	movabs r11,0x63ec26548650
    55d7:	call   r11
    55da:	ldmxcsr DWORD PTR [r12-0x28]
    55e0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    55e6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    55ec:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    55f2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    55f8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    55fe:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5604:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    560e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    5618:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    5622:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    562c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    5636:	mov    rbx,QWORD PTR [r12+0x108]
    563e:	mov    QWORD PTR [r12+0x378],0x2
    564a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5653:	mov    rdx,rbx
    5656:	shr    rdx,0x10
    565a:	and    edx,0xc000
    5660:	mov    rax,rbx
    5663:	shr    rax,0x15
    5667:	and    eax,0x100
    566c:	xor    eax,0x100
    5671:	or     edx,eax
    5673:	mov    rax,rbx
    5676:	shr    rax,0x1c
    567a:	and    eax,0x1
    567d:	or     edx,eax
    567f:	mov    QWORD PTR [rsp+0x10],rdx
    5684:	add    rsp,0x8
    5688:	ret
    5689:	nop    DWORD PTR [rax+0x0]
    5690:	sub    rsp,0x8
    5694:	mov    QWORD PTR [r12+0x378],0x3
    56a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    56a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    56ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    56b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    56b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    56be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    56c4:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    56ce:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    56d8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    56e2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    56ec:	push   rdx
    56ed:	push   rsi
    56ee:	push   r10
    56f0:	push   r11
    56f2:	mov    rdx,QWORD PTR [rsp+0x30]
    56f7:	mov    r10d,edx
    56fa:	and    r10d,0xc000
    5701:	shl    r10d,0x10
    5705:	mov    r11d,edx
    5708:	and    r11d,0x100
    570f:	shl    r11d,0x15
    5713:	or     r10d,r11d
    5716:	and    edx,0x1
    5719:	shl    edx,0x1c
    571c:	or     r10d,edx
    571f:	btc    r10,0x1d
    5724:	mov    r11d,0xf0000000
    572a:	and    r11,r10
    572d:	movabs rsi,0xffffffff0fffffff
    5737:	and    rbx,rsi
    573a:	or     rbx,r11
    573d:	pop    r11
    573f:	pop    r10
    5741:	pop    rsi
    5742:	pop    rdx
    5743:	mov    QWORD PTR [r12+0x108],rbx
    574b:	stmxcsr DWORD PTR [r12-0x28]
    5751:	mov    r10d,DWORD PTR [r12-0x28]
    5756:	test   r10d,0x3f
    575d:	je     0x5782
    5763:	mov    r11d,r10d
    5766:	shr    r10d,1
    5769:	and    r10d,0x1e
    576d:	and    r11d,0x1
    5771:	or     r10d,r11d
    5774:	or     DWORD PTR [r12+0x314],r10d
    577c:	and    DWORD PTR [r12-0x28],0xffffffc0
    5782:	ldmxcsr DWORD PTR [r12-0x38]
    5788:	lea    rdi,[rsp+0x110]
    5790:	lea    rsi,[rsp+0xf0]
    5798:	lea    rdx,[rsp+0x100]
    57a0:	mov    ecx,0x56
    57a5:	mov    r8d,0x0
    57ab:	lea    r9,[r12+0x314]
    57b3:	movabs r11,0x63ec26548650
    57bd:	call   r11
    57c0:	ldmxcsr DWORD PTR [r12-0x28]
    57c6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    57cc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    57d2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    57d8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    57de:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    57e4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    57ea:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    57f4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    57fe:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    5808:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    5812:	mov    rbx,QWORD PTR [r12+0x108]
    581a:	mov    QWORD PTR [r12+0x378],0x2
    5826:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    582f:	mov    rdx,rbx
    5832:	shr    rdx,0x10
    5836:	and    edx,0xc000
    583c:	mov    rax,rbx
    583f:	shr    rax,0x15
    5843:	and    eax,0x100
    5848:	xor    eax,0x100
    584d:	or     edx,eax
    584f:	mov    rax,rbx
    5852:	shr    rax,0x1c
    5856:	and    eax,0x1
    5859:	or     edx,eax
    585b:	mov    QWORD PTR [rsp+0x10],rdx
    5860:	add    rsp,0x8
    5864:	ret
    5865:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    5870:	sub    rsp,0x8
    5874:	mov    QWORD PTR [r12+0x378],0x3
    5880:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5886:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    588c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    5892:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    5898:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    589e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    58a4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    58ae:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    58b8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    58c2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    58cc:	push   rdx
    58cd:	push   rsi
    58ce:	push   r10
    58d0:	push   r11
    58d2:	mov    rdx,QWORD PTR [rsp+0x30]
    58d7:	mov    r10d,edx
    58da:	and    r10d,0xc000
    58e1:	shl    r10d,0x10
    58e5:	mov    r11d,edx
    58e8:	and    r11d,0x100
    58ef:	shl    r11d,0x15
    58f3:	or     r10d,r11d
    58f6:	and    edx,0x1
    58f9:	shl    edx,0x1c
    58fc:	or     r10d,edx
    58ff:	btc    r10,0x1d
    5904:	mov    r11d,0xf0000000
    590a:	and    r11,r10
    590d:	movabs rsi,0xffffffff0fffffff
    5917:	and    rbx,rsi
    591a:	or     rbx,r11
    591d:	pop    r11
    591f:	pop    r10
    5921:	pop    rsi
    5922:	pop    rdx
    5923:	mov    QWORD PTR [r12+0x108],rbx
    592b:	stmxcsr DWORD PTR [r12-0x28]
    5931:	mov    r10d,DWORD PTR [r12-0x28]
    5936:	test   r10d,0x3f
    593d:	je     0x5962
    5943:	mov    r11d,r10d
    5946:	shr    r10d,1
    5949:	and    r10d,0x1e
    594d:	and    r11d,0x1
    5951:	or     r10d,r11d
    5954:	or     DWORD PTR [r12+0x314],r10d
    595c:	and    DWORD PTR [r12-0x28],0xffffffc0
    5962:	ldmxcsr DWORD PTR [r12-0x38]
    5968:	lea    rdi,[rsp+0x110]
    5970:	lea    rsi,[rsp+0xf0]
    5978:	lea    rdx,[rsp+0x100]
    5980:	mov    ecx,0x14
    5985:	mov    r8d,0x0
    598b:	lea    r9,[r12+0x314]
    5993:	movabs r11,0x63ec26548650
    599d:	call   r11
    59a0:	ldmxcsr DWORD PTR [r12-0x28]
    59a6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    59ac:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    59b2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    59b8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    59be:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    59c4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    59ca:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    59d4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    59de:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    59e8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    59f2:	mov    rbx,QWORD PTR [r12+0x108]
    59fa:	mov    QWORD PTR [r12+0x378],0x2
    5a06:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5a0f:	mov    rdx,rbx
    5a12:	shr    rdx,0x10
    5a16:	and    edx,0xc000
    5a1c:	mov    rax,rbx
    5a1f:	shr    rax,0x15
    5a23:	and    eax,0x100
    5a28:	xor    eax,0x100
    5a2d:	or     edx,eax
    5a2f:	mov    rax,rbx
    5a32:	shr    rax,0x1c
    5a36:	and    eax,0x1
    5a39:	or     edx,eax
    5a3b:	mov    QWORD PTR [rsp+0x10],rdx
    5a40:	add    rsp,0x8
    5a44:	ret
    5a45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    5a50:	sub    rsp,0x8
    5a54:	mov    QWORD PTR [r12+0x378],0x3
    5a60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5a66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5a6c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    5a72:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    5a78:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    5a7e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    5a88:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    5a92:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    5a9c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    5aa6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    5ab0:	push   rdx
    5ab1:	push   rsi
    5ab2:	push   r10
    5ab4:	push   r11
    5ab6:	mov    rdx,QWORD PTR [rsp+0x30]
    5abb:	mov    r10d,edx
    5abe:	and    r10d,0xc000
    5ac5:	shl    r10d,0x10
    5ac9:	mov    r11d,edx
    5acc:	and    r11d,0x100
    5ad3:	shl    r11d,0x15
    5ad7:	or     r10d,r11d
    5ada:	and    edx,0x1
    5add:	shl    edx,0x1c
    5ae0:	or     r10d,edx
    5ae3:	btc    r10,0x1d
    5ae8:	mov    r11d,0xf0000000
    5aee:	and    r11,r10
    5af1:	movabs rsi,0xffffffff0fffffff
    5afb:	and    rbx,rsi
    5afe:	or     rbx,r11
    5b01:	pop    r11
    5b03:	pop    r10
    5b05:	pop    rsi
    5b06:	pop    rdx
    5b07:	mov    QWORD PTR [r12+0x108],rbx
    5b0f:	stmxcsr DWORD PTR [r12-0x28]
    5b15:	mov    r10d,DWORD PTR [r12-0x28]
    5b1a:	test   r10d,0x3f
    5b21:	je     0x5b46
    5b27:	mov    r11d,r10d
    5b2a:	shr    r10d,1
    5b2d:	and    r10d,0x1e
    5b31:	and    r11d,0x1
    5b35:	or     r10d,r11d
    5b38:	or     DWORD PTR [r12+0x314],r10d
    5b40:	and    DWORD PTR [r12-0x28],0xffffffc0
    5b46:	ldmxcsr DWORD PTR [r12-0x38]
    5b4c:	lea    rdi,[rsp+0x110]
    5b54:	lea    rsi,[rsp+0xf0]
    5b5c:	lea    rdx,[rsp+0x100]
    5b64:	mov    ecx,0x56
    5b69:	mov    r8d,0x0
    5b6f:	lea    r9,[r12+0x314]
    5b77:	movabs r11,0x63ec26548650
    5b81:	call   r11
    5b84:	ldmxcsr DWORD PTR [r12-0x28]
    5b8a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5b90:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5b96:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    5b9c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    5ba2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5ba8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    5bb2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    5bbc:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    5bc6:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    5bd0:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    5bda:	mov    rbx,QWORD PTR [r12+0x108]
    5be2:	mov    QWORD PTR [r12+0x378],0x2
    5bee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5bf7:	mov    rdx,rbx
    5bfa:	shr    rdx,0x10
    5bfe:	and    edx,0xc000
    5c04:	mov    rax,rbx
    5c07:	shr    rax,0x15
    5c0b:	and    eax,0x100
    5c10:	xor    eax,0x100
    5c15:	or     edx,eax
    5c17:	mov    rax,rbx
    5c1a:	shr    rax,0x1c
    5c1e:	and    eax,0x1
    5c21:	or     edx,eax
    5c23:	mov    QWORD PTR [rsp+0x10],rdx
    5c28:	add    rsp,0x8
    5c2c:	ret
    5c2d:	nop    DWORD PTR [rax]
    5c30:	sub    rsp,0x8
    5c34:	mov    QWORD PTR [r12+0x378],0x3
    5c40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5c46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5c4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    5c52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    5c58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    5c5e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    5c64:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    5c6e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    5c78:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    5c82:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    5c8c:	push   rdx
    5c8d:	push   rsi
    5c8e:	push   r10
    5c90:	push   r11
    5c92:	mov    rdx,QWORD PTR [rsp+0x30]
    5c97:	mov    r10d,edx
    5c9a:	and    r10d,0xc000
    5ca1:	shl    r10d,0x10
    5ca5:	mov    r11d,edx
    5ca8:	and    r11d,0x100
    5caf:	shl    r11d,0x15
    5cb3:	or     r10d,r11d
    5cb6:	and    edx,0x1
    5cb9:	shl    edx,0x1c
    5cbc:	or     r10d,edx
    5cbf:	btc    r10,0x1d
    5cc4:	mov    r11d,0xf0000000
    5cca:	and    r11,r10
    5ccd:	movabs rsi,0xffffffff0fffffff
    5cd7:	and    rbx,rsi
    5cda:	or     rbx,r11
    5cdd:	pop    r11
    5cdf:	pop    r10
    5ce1:	pop    rsi
    5ce2:	pop    rdx
    5ce3:	mov    QWORD PTR [r12+0x108],rbx
    5ceb:	stmxcsr DWORD PTR [r12-0x28]
    5cf1:	mov    r10d,DWORD PTR [r12-0x28]
    5cf6:	test   r10d,0x3f
    5cfd:	je     0x5d22
    5d03:	mov    r11d,r10d
    5d06:	shr    r10d,1
    5d09:	and    r10d,0x1e
    5d0d:	and    r11d,0x1
    5d11:	or     r10d,r11d
    5d14:	or     DWORD PTR [r12+0x314],r10d
    5d1c:	and    DWORD PTR [r12-0x28],0xffffffc0
    5d22:	ldmxcsr DWORD PTR [r12-0x38]
    5d28:	lea    rdi,[rsp+0x110]
    5d30:	lea    rsi,[rsp+0xf0]
    5d38:	lea    rdx,[rsp+0x100]
    5d40:	mov    ecx,0x56
    5d45:	mov    r8d,0x0
    5d4b:	lea    r9,[r12+0x314]
    5d53:	movabs r11,0x63ec26548650
    5d5d:	call   r11
    5d60:	ldmxcsr DWORD PTR [r12-0x28]
    5d66:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5d6c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5d72:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    5d78:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    5d7e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    5d84:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5d8a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    5d94:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    5d9e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    5da8:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    5db2:	mov    rbx,QWORD PTR [r12+0x108]
    5dba:	mov    QWORD PTR [r12+0x378],0x2
    5dc6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5dcf:	mov    rdx,rbx
    5dd2:	shr    rdx,0x10
    5dd6:	and    edx,0xc000
    5ddc:	mov    rax,rbx
    5ddf:	shr    rax,0x15
    5de3:	and    eax,0x100
    5de8:	xor    eax,0x100
    5ded:	or     edx,eax
    5def:	mov    rax,rbx
    5df2:	shr    rax,0x1c
    5df6:	and    eax,0x1
    5df9:	or     edx,eax
    5dfb:	mov    QWORD PTR [rsp+0x10],rdx
    5e00:	add    rsp,0x8
    5e04:	ret
    5e05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    5e10:	sub    rsp,0x8
    5e14:	mov    QWORD PTR [r12+0x378],0x3
    5e20:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5e26:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5e2c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    5e32:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    5e38:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    5e3e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    5e44:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    5e4e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    5e58:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    5e62:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    5e6c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    5e76:	push   rdx
    5e77:	push   rsi
    5e78:	push   r10
    5e7a:	push   r11
    5e7c:	mov    rdx,QWORD PTR [rsp+0x30]
    5e81:	mov    r10d,edx
    5e84:	and    r10d,0xc000
    5e8b:	shl    r10d,0x10
    5e8f:	mov    r11d,edx
    5e92:	and    r11d,0x100
    5e99:	shl    r11d,0x15
    5e9d:	or     r10d,r11d
    5ea0:	and    edx,0x1
    5ea3:	shl    edx,0x1c
    5ea6:	or     r10d,edx
    5ea9:	btc    r10,0x1d
    5eae:	mov    r11d,0xf0000000
    5eb4:	and    r11,r10
    5eb7:	movabs rsi,0xffffffff0fffffff
    5ec1:	and    rbx,rsi
    5ec4:	or     rbx,r11
    5ec7:	pop    r11
    5ec9:	pop    r10
    5ecb:	pop    rsi
    5ecc:	pop    rdx
    5ecd:	mov    QWORD PTR [r12+0x108],rbx
    5ed5:	stmxcsr DWORD PTR [r12-0x28]
    5edb:	mov    r10d,DWORD PTR [r12-0x28]
    5ee0:	test   r10d,0x3f
    5ee7:	je     0x5f0c
    5eed:	mov    r11d,r10d
    5ef0:	shr    r10d,1
    5ef3:	and    r10d,0x1e
    5ef7:	and    r11d,0x1
    5efb:	or     r10d,r11d
    5efe:	or     DWORD PTR [r12+0x314],r10d
    5f06:	and    DWORD PTR [r12-0x28],0xffffffc0
    5f0c:	ldmxcsr DWORD PTR [r12-0x38]
    5f12:	lea    rdi,[rsp+0x110]
    5f1a:	lea    rsi,[rsp+0xf0]
    5f22:	lea    rdx,[rsp+0x100]
    5f2a:	mov    ecx,0x14
    5f2f:	mov    r8d,0x0
    5f35:	lea    r9,[r12+0x314]
    5f3d:	movabs r11,0x63ec26548650
    5f47:	call   r11
    5f4a:	ldmxcsr DWORD PTR [r12-0x28]
    5f50:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5f56:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5f5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    5f62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    5f68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    5f6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    5f74:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    5f7e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    5f88:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    5f92:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    5f9c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    5fa6:	mov    rbx,QWORD PTR [r12+0x108]
    5fae:	mov    QWORD PTR [r12+0x378],0x2
    5fba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5fc3:	mov    rdx,rbx
    5fc6:	shr    rdx,0x10
    5fca:	and    edx,0xc000
    5fd0:	mov    rax,rbx
    5fd3:	shr    rax,0x15
    5fd7:	and    eax,0x100
    5fdc:	xor    eax,0x100
    5fe1:	or     edx,eax
    5fe3:	mov    rax,rbx
    5fe6:	shr    rax,0x1c
    5fea:	and    eax,0x1
    5fed:	or     edx,eax
    5fef:	mov    QWORD PTR [rsp+0x10],rdx
    5ff4:	add    rsp,0x8
    5ff8:	ret
    5ff9:	nop    DWORD PTR [rax+0x0]
    6000:	sub    rsp,0x8
    6004:	mov    QWORD PTR [r12+0x378],0x3
    6010:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6016:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    601c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6022:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6028:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    6032:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    603c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    6046:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    6050:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    605a:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    6064:	push   rdx
    6065:	push   rsi
    6066:	push   r10
    6068:	push   r11
    606a:	mov    rdx,QWORD PTR [rsp+0x30]
    606f:	mov    r10d,edx
    6072:	and    r10d,0xc000
    6079:	shl    r10d,0x10
    607d:	mov    r11d,edx
    6080:	and    r11d,0x100
    6087:	shl    r11d,0x15
    608b:	or     r10d,r11d
    608e:	and    edx,0x1
    6091:	shl    edx,0x1c
    6094:	or     r10d,edx
    6097:	btc    r10,0x1d
    609c:	mov    r11d,0xf0000000
    60a2:	and    r11,r10
    60a5:	movabs rsi,0xffffffff0fffffff
    60af:	and    rbx,rsi
    60b2:	or     rbx,r11
    60b5:	pop    r11
    60b7:	pop    r10
    60b9:	pop    rsi
    60ba:	pop    rdx
    60bb:	mov    QWORD PTR [r12+0x108],rbx
    60c3:	stmxcsr DWORD PTR [r12-0x28]
    60c9:	mov    r10d,DWORD PTR [r12-0x28]
    60ce:	test   r10d,0x3f
    60d5:	je     0x60fa
    60db:	mov    r11d,r10d
    60de:	shr    r10d,1
    60e1:	and    r10d,0x1e
    60e5:	and    r11d,0x1
    60e9:	or     r10d,r11d
    60ec:	or     DWORD PTR [r12+0x314],r10d
    60f4:	and    DWORD PTR [r12-0x28],0xffffffc0
    60fa:	ldmxcsr DWORD PTR [r12-0x38]
    6100:	lea    rdi,[rsp+0x110]
    6108:	lea    rsi,[rsp+0xf0]
    6110:	lea    rdx,[rsp+0x100]
    6118:	mov    ecx,0x56
    611d:	mov    r8d,0x0
    6123:	lea    r9,[r12+0x314]
    612b:	movabs r11,0x63ec26548650
    6135:	call   r11
    6138:	ldmxcsr DWORD PTR [r12-0x28]
    613e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6144:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    614a:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    6150:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6156:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    6160:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    616a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    6174:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    617e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    6188:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    6192:	mov    rbx,QWORD PTR [r12+0x108]
    619a:	mov    QWORD PTR [r12+0x378],0x2
    61a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    61af:	mov    rdx,rbx
    61b2:	shr    rdx,0x10
    61b6:	and    edx,0xc000
    61bc:	mov    rax,rbx
    61bf:	shr    rax,0x15
    61c3:	and    eax,0x100
    61c8:	xor    eax,0x100
    61cd:	or     edx,eax
    61cf:	mov    rax,rbx
    61d2:	shr    rax,0x1c
    61d6:	and    eax,0x1
    61d9:	or     edx,eax
    61db:	mov    QWORD PTR [rsp+0x10],rdx
    61e0:	add    rsp,0x8
    61e4:	ret
    61e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    61f0:	sub    rsp,0x8
    61f4:	mov    QWORD PTR [r12+0x378],0x3
    6200:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6206:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    620c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6212:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    6218:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    621e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    6228:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    6232:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    623c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    6246:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    6250:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    625a:	push   rdx
    625b:	push   rsi
    625c:	push   r10
    625e:	push   r11
    6260:	mov    rdx,QWORD PTR [rsp+0x30]
    6265:	mov    r10d,edx
    6268:	and    r10d,0xc000
    626f:	shl    r10d,0x10
    6273:	mov    r11d,edx
    6276:	and    r11d,0x100
    627d:	shl    r11d,0x15
    6281:	or     r10d,r11d
    6284:	and    edx,0x1
    6287:	shl    edx,0x1c
    628a:	or     r10d,edx
    628d:	btc    r10,0x1d
    6292:	mov    r11d,0xf0000000
    6298:	and    r11,r10
    629b:	movabs rsi,0xffffffff0fffffff
    62a5:	and    rbx,rsi
    62a8:	or     rbx,r11
    62ab:	pop    r11
    62ad:	pop    r10
    62af:	pop    rsi
    62b0:	pop    rdx
    62b1:	mov    QWORD PTR [r12+0x108],rbx
    62b9:	stmxcsr DWORD PTR [r12-0x28]
    62bf:	mov    r10d,DWORD PTR [r12-0x28]
    62c4:	test   r10d,0x3f
    62cb:	je     0x62f0
    62d1:	mov    r11d,r10d
    62d4:	shr    r10d,1
    62d7:	and    r10d,0x1e
    62db:	and    r11d,0x1
    62df:	or     r10d,r11d
    62e2:	or     DWORD PTR [r12+0x314],r10d
    62ea:	and    DWORD PTR [r12-0x28],0xffffffc0
    62f0:	ldmxcsr DWORD PTR [r12-0x38]
    62f6:	lea    rdi,[rsp+0x110]
    62fe:	lea    rsi,[rsp+0xf0]
    6306:	lea    rdx,[rsp+0x100]
    630e:	mov    ecx,0x14
    6313:	mov    r8d,0x0
    6319:	lea    r9,[r12+0x314]
    6321:	movabs r11,0x63ec26548650
    632b:	call   r11
    632e:	ldmxcsr DWORD PTR [r12-0x28]
    6334:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    633a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6340:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    6346:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    634c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6352:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    635c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    6366:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    6370:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    637a:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    6384:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    638e:	mov    rbx,QWORD PTR [r12+0x108]
    6396:	mov    QWORD PTR [r12+0x378],0x2
    63a2:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    63ab:	mov    rdx,rbx
    63ae:	shr    rdx,0x10
    63b2:	and    edx,0xc000
    63b8:	mov    rax,rbx
    63bb:	shr    rax,0x15
    63bf:	and    eax,0x100
    63c4:	xor    eax,0x100
    63c9:	or     edx,eax
    63cb:	mov    rax,rbx
    63ce:	shr    rax,0x1c
    63d2:	and    eax,0x1
    63d5:	or     edx,eax
    63d7:	mov    QWORD PTR [rsp+0x10],rdx
    63dc:	add    rsp,0x8
    63e0:	ret
    63e1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    63f0:	sub    rsp,0x8
    63f4:	mov    QWORD PTR [r12+0x378],0x3
    6400:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6406:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    640c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6412:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6418:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    641e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6424:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    642e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    6438:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    6442:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    644c:	push   rdx
    644d:	push   rsi
    644e:	push   r10
    6450:	push   r11
    6452:	mov    rdx,QWORD PTR [rsp+0x30]
    6457:	mov    r10d,edx
    645a:	and    r10d,0xc000
    6461:	shl    r10d,0x10
    6465:	mov    r11d,edx
    6468:	and    r11d,0x100
    646f:	shl    r11d,0x15
    6473:	or     r10d,r11d
    6476:	and    edx,0x1
    6479:	shl    edx,0x1c
    647c:	or     r10d,edx
    647f:	btc    r10,0x1d
    6484:	mov    r11d,0xf0000000
    648a:	and    r11,r10
    648d:	movabs rsi,0xffffffff0fffffff
    6497:	and    rbx,rsi
    649a:	or     rbx,r11
    649d:	pop    r11
    649f:	pop    r10
    64a1:	pop    rsi
    64a2:	pop    rdx
    64a3:	mov    QWORD PTR [r12+0x108],rbx
    64ab:	stmxcsr DWORD PTR [r12-0x28]
    64b1:	mov    r10d,DWORD PTR [r12-0x28]
    64b6:	test   r10d,0x3f
    64bd:	je     0x64e2
    64c3:	mov    r11d,r10d
    64c6:	shr    r10d,1
    64c9:	and    r10d,0x1e
    64cd:	and    r11d,0x1
    64d1:	or     r10d,r11d
    64d4:	or     DWORD PTR [r12+0x314],r10d
    64dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    64e2:	ldmxcsr DWORD PTR [r12-0x38]
    64e8:	lea    rdi,[rsp+0x110]
    64f0:	lea    rsi,[rsp+0xf0]
    64f8:	lea    rdx,[rsp+0x100]
    6500:	mov    ecx,0x56
    6505:	mov    r8d,0x0
    650b:	lea    r9,[r12+0x314]
    6513:	movabs r11,0x63ec26548650
    651d:	call   r11
    6520:	ldmxcsr DWORD PTR [r12-0x28]
    6526:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    652c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6532:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6538:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    653e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    6544:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    654a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    6554:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    655e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    6568:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    6572:	mov    rbx,QWORD PTR [r12+0x108]
    657a:	mov    QWORD PTR [r12+0x378],0x2
    6586:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    658f:	mov    rdx,rbx
    6592:	shr    rdx,0x10
    6596:	and    edx,0xc000
    659c:	mov    rax,rbx
    659f:	shr    rax,0x15
    65a3:	and    eax,0x100
    65a8:	xor    eax,0x100
    65ad:	or     edx,eax
    65af:	mov    rax,rbx
    65b2:	shr    rax,0x1c
    65b6:	and    eax,0x1
    65b9:	or     edx,eax
    65bb:	mov    QWORD PTR [rsp+0x10],rdx
    65c0:	add    rsp,0x8
    65c4:	ret
    65c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    65d0:	sub    rsp,0x8
    65d4:	mov    QWORD PTR [r12+0x378],0x3
    65e0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    65e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    65ec:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    65f2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    65f8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    6602:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    660c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    6616:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    6620:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    662a:	push   rdx
    662b:	push   rsi
    662c:	push   r10
    662e:	push   r11
    6630:	mov    rdx,QWORD PTR [rsp+0x30]
    6635:	mov    r10d,edx
    6638:	and    r10d,0xc000
    663f:	shl    r10d,0x10
    6643:	mov    r11d,edx
    6646:	and    r11d,0x100
    664d:	shl    r11d,0x15
    6651:	or     r10d,r11d
    6654:	and    edx,0x1
    6657:	shl    edx,0x1c
    665a:	or     r10d,edx
    665d:	btc    r10,0x1d
    6662:	mov    r11d,0xf0000000
    6668:	and    r11,r10
    666b:	movabs rsi,0xffffffff0fffffff
    6675:	and    rbx,rsi
    6678:	or     rbx,r11
    667b:	pop    r11
    667d:	pop    r10
    667f:	pop    rsi
    6680:	pop    rdx
    6681:	mov    QWORD PTR [r12+0x108],rbx
    6689:	stmxcsr DWORD PTR [r12-0x28]
    668f:	mov    r10d,DWORD PTR [r12-0x28]
    6694:	test   r10d,0x3f
    669b:	je     0x66c0
    66a1:	mov    r11d,r10d
    66a4:	shr    r10d,1
    66a7:	and    r10d,0x1e
    66ab:	and    r11d,0x1
    66af:	or     r10d,r11d
    66b2:	or     DWORD PTR [r12+0x314],r10d
    66ba:	and    DWORD PTR [r12-0x28],0xffffffc0
    66c0:	ldmxcsr DWORD PTR [r12-0x38]
    66c6:	lea    rdi,[rsp+0x110]
    66ce:	lea    rsi,[rsp+0xf0]
    66d6:	lea    rdx,[rsp+0x100]
    66de:	mov    ecx,0x14
    66e3:	mov    r8d,0x0
    66e9:	lea    r9,[r12+0x314]
    66f1:	movabs r11,0x63ec26548650
    66fb:	call   r11
    66fe:	ldmxcsr DWORD PTR [r12-0x28]
    6704:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    670a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6710:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    6716:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    671c:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    6726:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    6730:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    673a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    6744:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    674e:	mov    rbx,QWORD PTR [r12+0x108]
    6756:	mov    QWORD PTR [r12+0x378],0x2
    6762:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    676b:	mov    rdx,rbx
    676e:	shr    rdx,0x10
    6772:	and    edx,0xc000
    6778:	mov    rax,rbx
    677b:	shr    rax,0x15
    677f:	and    eax,0x100
    6784:	xor    eax,0x100
    6789:	or     edx,eax
    678b:	mov    rax,rbx
    678e:	shr    rax,0x1c
    6792:	and    eax,0x1
    6795:	or     edx,eax
    6797:	mov    QWORD PTR [rsp+0x10],rdx
    679c:	add    rsp,0x8
    67a0:	ret
    67a1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    67b0:	sub    rsp,0x8
    67b4:	mov    QWORD PTR [r12+0x378],0x3
    67c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    67c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    67cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    67d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    67d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    67de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    67e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    67ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    67f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    6802:	push   rdx
    6803:	push   rsi
    6804:	push   r10
    6806:	push   r11
    6808:	mov    rdx,QWORD PTR [rsp+0x30]
    680d:	mov    r10d,edx
    6810:	and    r10d,0xc000
    6817:	shl    r10d,0x10
    681b:	mov    r11d,edx
    681e:	and    r11d,0x100
    6825:	shl    r11d,0x15
    6829:	or     r10d,r11d
    682c:	and    edx,0x1
    682f:	shl    edx,0x1c
    6832:	or     r10d,edx
    6835:	btc    r10,0x1d
    683a:	mov    r11d,0xf0000000
    6840:	and    r11,r10
    6843:	movabs rsi,0xffffffff0fffffff
    684d:	and    rbx,rsi
    6850:	or     rbx,r11
    6853:	pop    r11
    6855:	pop    r10
    6857:	pop    rsi
    6858:	pop    rdx
    6859:	mov    QWORD PTR [r12+0x108],rbx
    6861:	stmxcsr DWORD PTR [r12-0x28]
    6867:	mov    r10d,DWORD PTR [r12-0x28]
    686c:	test   r10d,0x3f
    6873:	je     0x6898
    6879:	mov    r11d,r10d
    687c:	shr    r10d,1
    687f:	and    r10d,0x1e
    6883:	and    r11d,0x1
    6887:	or     r10d,r11d
    688a:	or     DWORD PTR [r12+0x314],r10d
    6892:	and    DWORD PTR [r12-0x28],0xffffffc0
    6898:	ldmxcsr DWORD PTR [r12-0x38]
    689e:	lea    rdi,[rsp+0x110]
    68a6:	lea    rsi,[rsp+0xf0]
    68ae:	lea    rdx,[rsp+0x100]
    68b6:	mov    ecx,0x56
    68bb:	mov    r8d,0x0
    68c1:	lea    r9,[r12+0x314]
    68c9:	movabs r11,0x63ec26548650
    68d3:	call   r11
    68d6:	ldmxcsr DWORD PTR [r12-0x28]
    68dc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    68e2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    68e8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    68ee:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    68f4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    68fa:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6900:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    690a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    6914:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    691e:	mov    rbx,QWORD PTR [r12+0x108]
    6926:	mov    QWORD PTR [r12+0x378],0x2
    6932:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    693b:	mov    rdx,rbx
    693e:	shr    rdx,0x10
    6942:	and    edx,0xc000
    6948:	mov    rax,rbx
    694b:	shr    rax,0x15
    694f:	and    eax,0x100
    6954:	xor    eax,0x100
    6959:	or     edx,eax
    695b:	mov    rax,rbx
    695e:	shr    rax,0x1c
    6962:	and    eax,0x1
    6965:	or     edx,eax
    6967:	mov    QWORD PTR [rsp+0x10],rdx
    696c:	add    rsp,0x8
    6970:	ret
    6971:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    6980:	sub    rsp,0x8
    6984:	mov    QWORD PTR [r12+0x378],0x3
    6990:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6996:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    699c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    69a2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    69a8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    69ae:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    69b8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    69c2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    69cc:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    69d6:	push   rdx
    69d7:	push   rsi
    69d8:	push   r10
    69da:	push   r11
    69dc:	mov    rdx,QWORD PTR [rsp+0x30]
    69e1:	mov    r10d,edx
    69e4:	and    r10d,0xc000
    69eb:	shl    r10d,0x10
    69ef:	mov    r11d,edx
    69f2:	and    r11d,0x100
    69f9:	shl    r11d,0x15
    69fd:	or     r10d,r11d
    6a00:	and    edx,0x1
    6a03:	shl    edx,0x1c
    6a06:	or     r10d,edx
    6a09:	btc    r10,0x1d
    6a0e:	mov    r11d,0xf0000000
    6a14:	and    r11,r10
    6a17:	movabs rsi,0xffffffff0fffffff
    6a21:	and    rbx,rsi
    6a24:	or     rbx,r11
    6a27:	pop    r11
    6a29:	pop    r10
    6a2b:	pop    rsi
    6a2c:	pop    rdx
    6a2d:	mov    QWORD PTR [r12+0x108],rbx
    6a35:	stmxcsr DWORD PTR [r12-0x28]
    6a3b:	mov    r10d,DWORD PTR [r12-0x28]
    6a40:	test   r10d,0x3f
    6a47:	je     0x6a6c
    6a4d:	mov    r11d,r10d
    6a50:	shr    r10d,1
    6a53:	and    r10d,0x1e
    6a57:	and    r11d,0x1
    6a5b:	or     r10d,r11d
    6a5e:	or     DWORD PTR [r12+0x314],r10d
    6a66:	and    DWORD PTR [r12-0x28],0xffffffc0
    6a6c:	ldmxcsr DWORD PTR [r12-0x38]
    6a72:	lea    rdi,[rsp+0x110]
    6a7a:	lea    rsi,[rsp+0xf0]
    6a82:	lea    rdx,[rsp+0x100]
    6a8a:	mov    ecx,0x56
    6a8f:	mov    r8d,0x0
    6a95:	lea    r9,[r12+0x314]
    6a9d:	movabs r11,0x63ec26548650
    6aa7:	call   r11
    6aaa:	ldmxcsr DWORD PTR [r12-0x28]
    6ab0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6ab6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6abc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6ac2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    6ac8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6ace:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    6ad8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    6ae2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    6aec:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    6af6:	mov    rbx,QWORD PTR [r12+0x108]
    6afe:	mov    QWORD PTR [r12+0x378],0x2
    6b0a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6b13:	mov    rdx,rbx
    6b16:	shr    rdx,0x10
    6b1a:	and    edx,0xc000
    6b20:	mov    rax,rbx
    6b23:	shr    rax,0x15
    6b27:	and    eax,0x100
    6b2c:	xor    eax,0x100
    6b31:	or     edx,eax
    6b33:	mov    rax,rbx
    6b36:	shr    rax,0x1c
    6b3a:	and    eax,0x1
    6b3d:	or     edx,eax
    6b3f:	mov    QWORD PTR [rsp+0x10],rdx
    6b44:	add    rsp,0x8
    6b48:	ret
    6b49:	nop    DWORD PTR [rax+0x0]
    6b50:	sub    rsp,0x8
    6b54:	mov    QWORD PTR [r12+0x378],0x3
    6b60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6b66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6b6c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6b72:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6b78:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    6b7e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6b84:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    6b8e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    6b98:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    6ba2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    6bac:	push   rdx
    6bad:	push   rsi
    6bae:	push   r10
    6bb0:	push   r11
    6bb2:	mov    rdx,QWORD PTR [rsp+0x30]
    6bb7:	mov    r10d,edx
    6bba:	and    r10d,0xc000
    6bc1:	shl    r10d,0x10
    6bc5:	mov    r11d,edx
    6bc8:	and    r11d,0x100
    6bcf:	shl    r11d,0x15
    6bd3:	or     r10d,r11d
    6bd6:	and    edx,0x1
    6bd9:	shl    edx,0x1c
    6bdc:	or     r10d,edx
    6bdf:	btc    r10,0x1d
    6be4:	mov    r11d,0xf0000000
    6bea:	and    r11,r10
    6bed:	movabs rsi,0xffffffff0fffffff
    6bf7:	and    rbx,rsi
    6bfa:	or     rbx,r11
    6bfd:	pop    r11
    6bff:	pop    r10
    6c01:	pop    rsi
    6c02:	pop    rdx
    6c03:	mov    QWORD PTR [r12+0x108],rbx
    6c0b:	stmxcsr DWORD PTR [r12-0x28]
    6c11:	mov    r10d,DWORD PTR [r12-0x28]
    6c16:	test   r10d,0x3f
    6c1d:	je     0x6c42
    6c23:	mov    r11d,r10d
    6c26:	shr    r10d,1
    6c29:	and    r10d,0x1e
    6c2d:	and    r11d,0x1
    6c31:	or     r10d,r11d
    6c34:	or     DWORD PTR [r12+0x314],r10d
    6c3c:	and    DWORD PTR [r12-0x28],0xffffffc0
    6c42:	ldmxcsr DWORD PTR [r12-0x38]
    6c48:	lea    rdi,[rsp+0x110]
    6c50:	lea    rsi,[rsp+0xf0]
    6c58:	lea    rdx,[rsp+0x100]
    6c60:	mov    ecx,0x14
    6c65:	mov    r8d,0x0
    6c6b:	lea    r9,[r12+0x314]
    6c73:	movabs r11,0x63ec26548650
    6c7d:	call   r11
    6c80:	ldmxcsr DWORD PTR [r12-0x28]
    6c86:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6c8c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6c92:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6c98:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    6c9e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    6ca4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6caa:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    6cb4:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    6cbe:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    6cc8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    6cd2:	mov    rbx,QWORD PTR [r12+0x108]
    6cda:	mov    QWORD PTR [r12+0x378],0x2
    6ce6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6cef:	mov    rdx,rbx
    6cf2:	shr    rdx,0x10
    6cf6:	and    edx,0xc000
    6cfc:	mov    rax,rbx
    6cff:	shr    rax,0x15
    6d03:	and    eax,0x100
    6d08:	xor    eax,0x100
    6d0d:	or     edx,eax
    6d0f:	mov    rax,rbx
    6d12:	shr    rax,0x1c
    6d16:	and    eax,0x1
    6d19:	or     edx,eax
    6d1b:	mov    QWORD PTR [rsp+0x10],rdx
    6d20:	add    rsp,0x8
    6d24:	ret
    6d25:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    6d30:	sub    rsp,0x8
    6d34:	mov    QWORD PTR [r12+0x378],0x3
    6d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6d46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6d4c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6d52:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    6d58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    6d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    6d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    6d7c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    6d86:	push   rdx
    6d87:	push   rsi
    6d88:	push   r10
    6d8a:	push   r11
    6d8c:	mov    rdx,QWORD PTR [rsp+0x30]
    6d91:	mov    r10d,edx
    6d94:	and    r10d,0xc000
    6d9b:	shl    r10d,0x10
    6d9f:	mov    r11d,edx
    6da2:	and    r11d,0x100
    6da9:	shl    r11d,0x15
    6dad:	or     r10d,r11d
    6db0:	and    edx,0x1
    6db3:	shl    edx,0x1c
    6db6:	or     r10d,edx
    6db9:	btc    r10,0x1d
    6dbe:	mov    r11d,0xf0000000
    6dc4:	and    r11,r10
    6dc7:	movabs rsi,0xffffffff0fffffff
    6dd1:	and    rbx,rsi
    6dd4:	or     rbx,r11
    6dd7:	pop    r11
    6dd9:	pop    r10
    6ddb:	pop    rsi
    6ddc:	pop    rdx
    6ddd:	mov    QWORD PTR [r12+0x108],rbx
    6de5:	stmxcsr DWORD PTR [r12-0x28]
    6deb:	mov    r10d,DWORD PTR [r12-0x28]
    6df0:	test   r10d,0x3f
    6df7:	je     0x6e1c
    6dfd:	mov    r11d,r10d
    6e00:	shr    r10d,1
    6e03:	and    r10d,0x1e
    6e07:	and    r11d,0x1
    6e0b:	or     r10d,r11d
    6e0e:	or     DWORD PTR [r12+0x314],r10d
    6e16:	and    DWORD PTR [r12-0x28],0xffffffc0
    6e1c:	ldmxcsr DWORD PTR [r12-0x38]
    6e22:	lea    rdi,[rsp+0x110]
    6e2a:	lea    rsi,[rsp+0xf0]
    6e32:	lea    rdx,[rsp+0x100]
    6e3a:	mov    ecx,0x14
    6e3f:	mov    r8d,0x0
    6e45:	lea    r9,[r12+0x314]
    6e4d:	movabs r11,0x63ec26548650
    6e57:	call   r11
    6e5a:	ldmxcsr DWORD PTR [r12-0x28]
    6e60:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6e66:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6e6c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    6e72:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    6e78:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    6e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    6e92:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    6e9c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    6ea6:	mov    rbx,QWORD PTR [r12+0x108]
    6eae:	mov    QWORD PTR [r12+0x378],0x2
    6eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6ec3:	mov    rdx,rbx
    6ec6:	shr    rdx,0x10
    6eca:	and    edx,0xc000
    6ed0:	mov    rax,rbx
    6ed3:	shr    rax,0x15
    6ed7:	and    eax,0x100
    6edc:	xor    eax,0x100
    6ee1:	or     edx,eax
    6ee3:	mov    rax,rbx
    6ee6:	shr    rax,0x1c
    6eea:	and    eax,0x1
    6eed:	or     edx,eax
    6eef:	mov    QWORD PTR [rsp+0x10],rdx
    6ef4:	add    rsp,0x8
    6ef8:	ret
    6ef9:	nop    DWORD PTR [rax+0x0]
    6f00:	sub    rsp,0x8
    6f04:	mov    QWORD PTR [r12+0x378],0x3
    6f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6f16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6f1c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6f22:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    6f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6f2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    6f38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    6f42:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    6f4c:	push   rdx
    6f4d:	push   rsi
    6f4e:	push   r10
    6f50:	push   r11
    6f52:	mov    rdx,QWORD PTR [rsp+0x30]
    6f57:	mov    r10d,edx
    6f5a:	and    r10d,0xc000
    6f61:	shl    r10d,0x10
    6f65:	mov    r11d,edx
    6f68:	and    r11d,0x100
    6f6f:	shl    r11d,0x15
    6f73:	or     r10d,r11d
    6f76:	and    edx,0x1
    6f79:	shl    edx,0x1c
    6f7c:	or     r10d,edx
    6f7f:	btc    r10,0x1d
    6f84:	mov    r11d,0xf0000000
    6f8a:	and    r11,r10
    6f8d:	movabs rsi,0xffffffff0fffffff
    6f97:	and    rbx,rsi
    6f9a:	or     rbx,r11
    6f9d:	pop    r11
    6f9f:	pop    r10
    6fa1:	pop    rsi
    6fa2:	pop    rdx
    6fa3:	mov    QWORD PTR [r12+0x108],rbx
    6fab:	stmxcsr DWORD PTR [r12-0x28]
    6fb1:	mov    r10d,DWORD PTR [r12-0x28]
    6fb6:	test   r10d,0x3f
    6fbd:	je     0x6fe2
    6fc3:	mov    r11d,r10d
    6fc6:	shr    r10d,1
    6fc9:	and    r10d,0x1e
    6fcd:	and    r11d,0x1
    6fd1:	or     r10d,r11d
    6fd4:	or     DWORD PTR [r12+0x314],r10d
    6fdc:	and    DWORD PTR [r12-0x28],0xffffffc0
    6fe2:	ldmxcsr DWORD PTR [r12-0x38]
    6fe8:	lea    rdi,[rsp+0x110]
    6ff0:	lea    rsi,[rsp+0xf0]
    6ff8:	lea    rdx,[rsp+0x100]
    7000:	mov    ecx,0x56
    7005:	mov    r8d,0x0
    700b:	lea    r9,[r12+0x314]
    7013:	movabs r11,0x63ec26548650
    701d:	call   r11
    7020:	ldmxcsr DWORD PTR [r12-0x28]
    7026:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    702c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7032:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7038:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    703e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7044:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    704e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7058:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7062:	mov    rbx,QWORD PTR [r12+0x108]
    706a:	mov    QWORD PTR [r12+0x378],0x2
    7076:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    707f:	mov    rdx,rbx
    7082:	shr    rdx,0x10
    7086:	and    edx,0xc000
    708c:	mov    rax,rbx
    708f:	shr    rax,0x15
    7093:	and    eax,0x100
    7098:	xor    eax,0x100
    709d:	or     edx,eax
    709f:	mov    rax,rbx
    70a2:	shr    rax,0x1c
    70a6:	and    eax,0x1
    70a9:	or     edx,eax
    70ab:	mov    QWORD PTR [rsp+0x10],rdx
    70b0:	add    rsp,0x8
    70b4:	ret
    70b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    70c0:	sub    rsp,0x8
    70c4:	mov    QWORD PTR [r12+0x378],0x3
    70d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    70d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    70dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    70e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    70e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    70ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    70f4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    70fe:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7108:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7112:	push   rdx
    7113:	push   rsi
    7114:	push   r10
    7116:	push   r11
    7118:	mov    rdx,QWORD PTR [rsp+0x30]
    711d:	mov    r10d,edx
    7120:	and    r10d,0xc000
    7127:	shl    r10d,0x10
    712b:	mov    r11d,edx
    712e:	and    r11d,0x100
    7135:	shl    r11d,0x15
    7139:	or     r10d,r11d
    713c:	and    edx,0x1
    713f:	shl    edx,0x1c
    7142:	or     r10d,edx
    7145:	btc    r10,0x1d
    714a:	mov    r11d,0xf0000000
    7150:	and    r11,r10
    7153:	movabs rsi,0xffffffff0fffffff
    715d:	and    rbx,rsi
    7160:	or     rbx,r11
    7163:	pop    r11
    7165:	pop    r10
    7167:	pop    rsi
    7168:	pop    rdx
    7169:	mov    QWORD PTR [r12+0x108],rbx
    7171:	stmxcsr DWORD PTR [r12-0x28]
    7177:	mov    r10d,DWORD PTR [r12-0x28]
    717c:	test   r10d,0x3f
    7183:	je     0x71a8
    7189:	mov    r11d,r10d
    718c:	shr    r10d,1
    718f:	and    r10d,0x1e
    7193:	and    r11d,0x1
    7197:	or     r10d,r11d
    719a:	or     DWORD PTR [r12+0x314],r10d
    71a2:	and    DWORD PTR [r12-0x28],0xffffffc0
    71a8:	ldmxcsr DWORD PTR [r12-0x38]
    71ae:	lea    rdi,[rsp+0x110]
    71b6:	lea    rsi,[rsp+0xf0]
    71be:	lea    rdx,[rsp+0x100]
    71c6:	mov    ecx,0x56
    71cb:	mov    r8d,0x0
    71d1:	lea    r9,[r12+0x314]
    71d9:	movabs r11,0x63ec26548650
    71e3:	call   r11
    71e6:	ldmxcsr DWORD PTR [r12-0x28]
    71ec:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71f2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71f8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    71fe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7204:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    720a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7210:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    721a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7224:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    722e:	mov    rbx,QWORD PTR [r12+0x108]
    7236:	mov    QWORD PTR [r12+0x378],0x2
    7242:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    724b:	mov    rdx,rbx
    724e:	shr    rdx,0x10
    7252:	and    edx,0xc000
    7258:	mov    rax,rbx
    725b:	shr    rax,0x15
    725f:	and    eax,0x100
    7264:	xor    eax,0x100
    7269:	or     edx,eax
    726b:	mov    rax,rbx
    726e:	shr    rax,0x1c
    7272:	and    eax,0x1
    7275:	or     edx,eax
    7277:	mov    QWORD PTR [rsp+0x10],rdx
    727c:	add    rsp,0x8
    7280:	ret
    7281:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7290:	sub    rsp,0x8
    7294:	mov    QWORD PTR [r12+0x378],0x3
    72a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e6:	push   rdx
    72e7:	push   rsi
    72e8:	push   r10
    72ea:	push   r11
    72ec:	mov    rdx,QWORD PTR [rsp+0x30]
    72f1:	mov    r10d,edx
    72f4:	and    r10d,0xc000
    72fb:	shl    r10d,0x10
    72ff:	mov    r11d,edx
    7302:	and    r11d,0x100
    7309:	shl    r11d,0x15
    730d:	or     r10d,r11d
    7310:	and    edx,0x1
    7313:	shl    edx,0x1c
    7316:	or     r10d,edx
    7319:	btc    r10,0x1d
    731e:	mov    r11d,0xf0000000
    7324:	and    r11,r10
    7327:	movabs rsi,0xffffffff0fffffff
    7331:	and    rbx,rsi
    7334:	or     rbx,r11
    7337:	pop    r11
    7339:	pop    r10
    733b:	pop    rsi
    733c:	pop    rdx
    733d:	mov    QWORD PTR [r12+0x108],rbx
    7345:	stmxcsr DWORD PTR [r12-0x28]
    734b:	mov    r10d,DWORD PTR [r12-0x28]
    7350:	test   r10d,0x3f
    7357:	je     0x737c
    735d:	mov    r11d,r10d
    7360:	shr    r10d,1
    7363:	and    r10d,0x1e
    7367:	and    r11d,0x1
    736b:	or     r10d,r11d
    736e:	or     DWORD PTR [r12+0x314],r10d
    7376:	and    DWORD PTR [r12-0x28],0xffffffc0
    737c:	ldmxcsr DWORD PTR [r12-0x38]
    7382:	lea    rdi,[rsp+0x110]
    738a:	lea    rsi,[rsp+0xf0]
    7392:	lea    rdx,[rsp+0x100]
    739a:	mov    ecx,0x14
    739f:	mov    r8d,0x0
    73a5:	lea    r9,[r12+0x314]
    73ad:	movabs r11,0x63ec26548650
    73b7:	call   r11
    73ba:	ldmxcsr DWORD PTR [r12-0x28]
    73c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    73c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    73cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    73d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    73d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    73de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    73e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    73f2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    73fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7406:	mov    rbx,QWORD PTR [r12+0x108]
    740e:	mov    QWORD PTR [r12+0x378],0x2
    741a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7423:	mov    rdx,rbx
    7426:	shr    rdx,0x10
    742a:	and    edx,0xc000
    7430:	mov    rax,rbx
    7433:	shr    rax,0x15
    7437:	and    eax,0x100
    743c:	xor    eax,0x100
    7441:	or     edx,eax
    7443:	mov    rax,rbx
    7446:	shr    rax,0x1c
    744a:	and    eax,0x1
    744d:	or     edx,eax
    744f:	mov    QWORD PTR [rsp+0x10],rdx
    7454:	add    rsp,0x8
    7458:	ret
    7459:	nop    DWORD PTR [rax+0x0]
    7460:	sub    rsp,0x8
    7464:	mov    QWORD PTR [r12+0x378],0x3
    7470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    747c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    748e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7498:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74ac:	push   rdx
    74ad:	push   rsi
    74ae:	push   r10
    74b0:	push   r11
    74b2:	mov    rdx,QWORD PTR [rsp+0x30]
    74b7:	mov    r10d,edx
    74ba:	and    r10d,0xc000
    74c1:	shl    r10d,0x10
    74c5:	mov    r11d,edx
    74c8:	and    r11d,0x100
    74cf:	shl    r11d,0x15
    74d3:	or     r10d,r11d
    74d6:	and    edx,0x1
    74d9:	shl    edx,0x1c
    74dc:	or     r10d,edx
    74df:	btc    r10,0x1d
    74e4:	mov    r11d,0xf0000000
    74ea:	and    r11,r10
    74ed:	movabs rsi,0xffffffff0fffffff
    74f7:	and    rbx,rsi
    74fa:	or     rbx,r11
    74fd:	pop    r11
    74ff:	pop    r10
    7501:	pop    rsi
    7502:	pop    rdx
    7503:	mov    QWORD PTR [r12+0x108],rbx
    750b:	stmxcsr DWORD PTR [r12-0x28]
    7511:	mov    r10d,DWORD PTR [r12-0x28]
    7516:	test   r10d,0x3f
    751d:	je     0x7542
    7523:	mov    r11d,r10d
    7526:	shr    r10d,1
    7529:	and    r10d,0x1e
    752d:	and    r11d,0x1
    7531:	or     r10d,r11d
    7534:	or     DWORD PTR [r12+0x314],r10d
    753c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7542:	ldmxcsr DWORD PTR [r12-0x38]
    7548:	lea    rdi,[rsp+0x110]
    7550:	lea    rsi,[rsp+0xf0]
    7558:	lea    rdx,[rsp+0x100]
    7560:	mov    ecx,0x14
    7565:	mov    r8d,0x0
    756b:	lea    r9,[r12+0x314]
    7573:	movabs r11,0x63ec26548650
    757d:	call   r11
    7580:	ldmxcsr DWORD PTR [r12-0x28]
    7586:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    758c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7592:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7598:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    759e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    75a4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    75ae:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    75b8:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    75c2:	mov    rbx,QWORD PTR [r12+0x108]
    75ca:	mov    QWORD PTR [r12+0x378],0x2
    75d6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75df:	mov    rdx,rbx
    75e2:	shr    rdx,0x10
    75e6:	and    edx,0xc000
    75ec:	mov    rax,rbx
    75ef:	shr    rax,0x15
    75f3:	and    eax,0x100
    75f8:	xor    eax,0x100
    75fd:	or     edx,eax
    75ff:	mov    rax,rbx
    7602:	shr    rax,0x1c
    7606:	and    eax,0x1
    7609:	or     edx,eax
    760b:	mov    QWORD PTR [rsp+0x10],rdx
    7610:	add    rsp,0x8
    7614:	ret
    7615:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7620:	sub    rsp,0x8
    7624:	mov    QWORD PTR [r12+0x378],0x3
    7630:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7636:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    763c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7642:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7648:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    764e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7654:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    765e:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7668:	push   rdx
    7669:	push   rsi
    766a:	push   r10
    766c:	push   r11
    766e:	mov    rdx,QWORD PTR [rsp+0x30]
    7673:	mov    r10d,edx
    7676:	and    r10d,0xc000
    767d:	shl    r10d,0x10
    7681:	mov    r11d,edx
    7684:	and    r11d,0x100
    768b:	shl    r11d,0x15
    768f:	or     r10d,r11d
    7692:	and    edx,0x1
    7695:	shl    edx,0x1c
    7698:	or     r10d,edx
    769b:	btc    r10,0x1d
    76a0:	mov    r11d,0xf0000000
    76a6:	and    r11,r10
    76a9:	movabs rsi,0xffffffff0fffffff
    76b3:	and    rbx,rsi
    76b6:	or     rbx,r11
    76b9:	pop    r11
    76bb:	pop    r10
    76bd:	pop    rsi
    76be:	pop    rdx
    76bf:	mov    QWORD PTR [r12+0x108],rbx
    76c7:	stmxcsr DWORD PTR [r12-0x28]
    76cd:	mov    r10d,DWORD PTR [r12-0x28]
    76d2:	test   r10d,0x3f
    76d9:	je     0x76fe
    76df:	mov    r11d,r10d
    76e2:	shr    r10d,1
    76e5:	and    r10d,0x1e
    76e9:	and    r11d,0x1
    76ed:	or     r10d,r11d
    76f0:	or     DWORD PTR [r12+0x314],r10d
    76f8:	and    DWORD PTR [r12-0x28],0xffffffc0
    76fe:	ldmxcsr DWORD PTR [r12-0x38]
    7704:	lea    rdi,[rsp+0x110]
    770c:	lea    rsi,[rsp+0xf0]
    7714:	lea    rdx,[rsp+0x100]
    771c:	mov    ecx,0x56
    7721:	mov    r8d,0x0
    7727:	lea    r9,[r12+0x314]
    772f:	movabs r11,0x63ec26548650
    7739:	call   r11
    773c:	ldmxcsr DWORD PTR [r12-0x28]
    7742:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7748:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    774e:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7754:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    775a:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7760:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7766:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7770:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    777a:	mov    rbx,QWORD PTR [r12+0x108]
    7782:	mov    QWORD PTR [r12+0x378],0x2
    778e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7797:	mov    rdx,rbx
    779a:	shr    rdx,0x10
    779e:	and    edx,0xc000
    77a4:	mov    rax,rbx
    77a7:	shr    rax,0x15
    77ab:	and    eax,0x100
    77b0:	xor    eax,0x100
    77b5:	or     edx,eax
    77b7:	mov    rax,rbx
    77ba:	shr    rax,0x1c
    77be:	and    eax,0x1
    77c1:	or     edx,eax
    77c3:	mov    QWORD PTR [rsp+0x10],rdx
    77c8:	add    rsp,0x8
    77cc:	ret
    77cd:	nop    DWORD PTR [rax]
    77d0:	sub    rsp,0x8
    77d4:	mov    QWORD PTR [r12+0x378],0x3
    77e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77f8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77fe:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7804:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    780e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7818:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7822:	push   rdx
    7823:	push   rsi
    7824:	push   r10
    7826:	push   r11
    7828:	mov    rdx,QWORD PTR [rsp+0x30]
    782d:	mov    r10d,edx
    7830:	and    r10d,0xc000
    7837:	shl    r10d,0x10
    783b:	mov    r11d,edx
    783e:	and    r11d,0x100
    7845:	shl    r11d,0x15
    7849:	or     r10d,r11d
    784c:	and    edx,0x1
    784f:	shl    edx,0x1c
    7852:	or     r10d,edx
    7855:	btc    r10,0x1d
    785a:	mov    r11d,0xf0000000
    7860:	and    r11,r10
    7863:	movabs rsi,0xffffffff0fffffff
    786d:	and    rbx,rsi
    7870:	or     rbx,r11
    7873:	pop    r11
    7875:	pop    r10
    7877:	pop    rsi
    7878:	pop    rdx
    7879:	mov    QWORD PTR [r12+0x108],rbx
    7881:	stmxcsr DWORD PTR [r12-0x28]
    7887:	mov    r10d,DWORD PTR [r12-0x28]
    788c:	test   r10d,0x3f
    7893:	je     0x78b8
    7899:	mov    r11d,r10d
    789c:	shr    r10d,1
    789f:	and    r10d,0x1e
    78a3:	and    r11d,0x1
    78a7:	or     r10d,r11d
    78aa:	or     DWORD PTR [r12+0x314],r10d
    78b2:	and    DWORD PTR [r12-0x28],0xffffffc0
    78b8:	ldmxcsr DWORD PTR [r12-0x38]
    78be:	lea    rdi,[rsp+0x110]
    78c6:	lea    rsi,[rsp+0xf0]
    78ce:	lea    rdx,[rsp+0x100]
    78d6:	mov    ecx,0x14
    78db:	mov    r8d,0x0
    78e1:	lea    r9,[r12+0x314]
    78e9:	movabs r11,0x63ec26548650
    78f3:	call   r11
    78f6:	ldmxcsr DWORD PTR [r12-0x28]
    78fc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7902:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7908:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    790e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7914:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    791a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7920:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    792a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7934:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    793e:	mov    rbx,QWORD PTR [r12+0x108]
    7946:	mov    QWORD PTR [r12+0x378],0x2
    7952:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    795b:	mov    rdx,rbx
    795e:	shr    rdx,0x10
    7962:	and    edx,0xc000
    7968:	mov    rax,rbx
    796b:	shr    rax,0x15
    796f:	and    eax,0x100
    7974:	xor    eax,0x100
    7979:	or     edx,eax
    797b:	mov    rax,rbx
    797e:	shr    rax,0x1c
    7982:	and    eax,0x1
    7985:	or     edx,eax
    7987:	mov    QWORD PTR [rsp+0x10],rdx
    798c:	add    rsp,0x8
    7990:	ret
    7991:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    79a0:	sub    rsp,0x8
    79a4:	mov    QWORD PTR [r12+0x378],0x3
    79b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    79b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    79bc:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    79c2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    79c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    79d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    79dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    79e6:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    79f0:	push   rdx
    79f1:	push   rsi
    79f2:	push   r10
    79f4:	push   r11
    79f6:	mov    rdx,QWORD PTR [rsp+0x30]
    79fb:	mov    r10d,edx
    79fe:	and    r10d,0xc000
    7a05:	shl    r10d,0x10
    7a09:	mov    r11d,edx
    7a0c:	and    r11d,0x100
    7a13:	shl    r11d,0x15
    7a17:	or     r10d,r11d
    7a1a:	and    edx,0x1
    7a1d:	shl    edx,0x1c
    7a20:	or     r10d,edx
    7a23:	btc    r10,0x1d
    7a28:	mov    r11d,0xf0000000
    7a2e:	and    r11,r10
    7a31:	movabs rsi,0xffffffff0fffffff
    7a3b:	and    rbx,rsi
    7a3e:	or     rbx,r11
    7a41:	pop    r11
    7a43:	pop    r10
    7a45:	pop    rsi
    7a46:	pop    rdx
    7a47:	mov    QWORD PTR [r12+0x108],rbx
    7a4f:	stmxcsr DWORD PTR [r12-0x28]
    7a55:	mov    r10d,DWORD PTR [r12-0x28]
    7a5a:	test   r10d,0x3f
    7a61:	je     0x7a86
    7a67:	mov    r11d,r10d
    7a6a:	shr    r10d,1
    7a6d:	and    r10d,0x1e
    7a71:	and    r11d,0x1
    7a75:	or     r10d,r11d
    7a78:	or     DWORD PTR [r12+0x314],r10d
    7a80:	and    DWORD PTR [r12-0x28],0xffffffc0
    7a86:	ldmxcsr DWORD PTR [r12-0x38]
    7a8c:	lea    rdi,[rsp+0x110]
    7a94:	lea    rsi,[rsp+0xf0]
    7a9c:	lea    rdx,[rsp+0x100]
    7aa4:	mov    ecx,0x14
    7aa9:	mov    r8d,0x0
    7aaf:	lea    r9,[r12+0x314]
    7ab7:	movabs r11,0x63ec26548650
    7ac1:	call   r11
    7ac4:	ldmxcsr DWORD PTR [r12-0x28]
    7aca:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7ad0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7ad6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7adc:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7ae2:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7aec:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7af6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7b00:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7b0a:	mov    rbx,QWORD PTR [r12+0x108]
    7b12:	mov    QWORD PTR [r12+0x378],0x2
    7b1e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7b27:	mov    rdx,rbx
    7b2a:	shr    rdx,0x10
    7b2e:	and    edx,0xc000
    7b34:	mov    rax,rbx
    7b37:	shr    rax,0x15
    7b3b:	and    eax,0x100
    7b40:	xor    eax,0x100
    7b45:	or     edx,eax
    7b47:	mov    rax,rbx
    7b4a:	shr    rax,0x1c
    7b4e:	and    eax,0x1
    7b51:	or     edx,eax
    7b53:	mov    QWORD PTR [rsp+0x10],rdx
    7b58:	add    rsp,0x8
    7b5c:	ret
    7b5d:	nop    DWORD PTR [rax]
    7b60:	sub    rsp,0x8
    7b64:	mov    QWORD PTR [r12+0x378],0x3
    7b70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7b76:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7b7c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7b82:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7b88:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7b8e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7b98:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7ba2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7bac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7bb6:	push   rdx
    7bb7:	push   rsi
    7bb8:	push   r10
    7bba:	push   r11
    7bbc:	mov    rdx,QWORD PTR [rsp+0x30]
    7bc1:	mov    r10d,edx
    7bc4:	and    r10d,0xc000
    7bcb:	shl    r10d,0x10
    7bcf:	mov    r11d,edx
    7bd2:	and    r11d,0x100
    7bd9:	shl    r11d,0x15
    7bdd:	or     r10d,r11d
    7be0:	and    edx,0x1
    7be3:	shl    edx,0x1c
    7be6:	or     r10d,edx
    7be9:	btc    r10,0x1d
    7bee:	mov    r11d,0xf0000000
    7bf4:	and    r11,r10
    7bf7:	movabs rsi,0xffffffff0fffffff
    7c01:	and    rbx,rsi
    7c04:	or     rbx,r11
    7c07:	pop    r11
    7c09:	pop    r10
    7c0b:	pop    rsi
    7c0c:	pop    rdx
    7c0d:	mov    QWORD PTR [r12+0x108],rbx
    7c15:	stmxcsr DWORD PTR [r12-0x28]
    7c1b:	mov    r10d,DWORD PTR [r12-0x28]
    7c20:	test   r10d,0x3f
    7c27:	je     0x7c4c
    7c2d:	mov    r11d,r10d
    7c30:	shr    r10d,1
    7c33:	and    r10d,0x1e
    7c37:	and    r11d,0x1
    7c3b:	or     r10d,r11d
    7c3e:	or     DWORD PTR [r12+0x314],r10d
    7c46:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c4c:	ldmxcsr DWORD PTR [r12-0x38]
    7c52:	lea    rdi,[rsp+0x110]
    7c5a:	lea    rsi,[rsp+0xf0]
    7c62:	lea    rdx,[rsp+0x100]
    7c6a:	mov    ecx,0x14
    7c6f:	mov    r8d,0x0
    7c75:	lea    r9,[r12+0x314]
    7c7d:	movabs r11,0x63ec26548650
    7c87:	call   r11
    7c8a:	ldmxcsr DWORD PTR [r12-0x28]
    7c90:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c96:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7ca2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7ca8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7cae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7cb8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7cc2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7ccc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7cd6:	mov    rbx,QWORD PTR [r12+0x108]
    7cde:	mov    QWORD PTR [r12+0x378],0x2
    7cea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7cf3:	mov    rdx,rbx
    7cf6:	shr    rdx,0x10
    7cfa:	and    edx,0xc000
    7d00:	mov    rax,rbx
    7d03:	shr    rax,0x15
    7d07:	and    eax,0x100
    7d0c:	xor    eax,0x100
    7d11:	or     edx,eax
    7d13:	mov    rax,rbx
    7d16:	shr    rax,0x1c
    7d1a:	and    eax,0x1
    7d1d:	or     edx,eax
    7d1f:	mov    QWORD PTR [rsp+0x10],rdx
    7d24:	add    rsp,0x8
    7d28:	ret
    7d29:	nop    DWORD PTR [rax+0x0]
    7d30:	sub    rsp,0x8
    7d34:	mov    QWORD PTR [r12+0x378],0x3
    7d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7d46:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7d4c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7d52:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7d58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7d5e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7d68:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7d72:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7d7c:	push   rdx
    7d7d:	push   rsi
    7d7e:	push   r10
    7d80:	push   r11
    7d82:	mov    rdx,QWORD PTR [rsp+0x30]
    7d87:	mov    r10d,edx
    7d8a:	and    r10d,0xc000
    7d91:	shl    r10d,0x10
    7d95:	mov    r11d,edx
    7d98:	and    r11d,0x100
    7d9f:	shl    r11d,0x15
    7da3:	or     r10d,r11d
    7da6:	and    edx,0x1
    7da9:	shl    edx,0x1c
    7dac:	or     r10d,edx
    7daf:	btc    r10,0x1d
    7db4:	mov    r11d,0xf0000000
    7dba:	and    r11,r10
    7dbd:	movabs rsi,0xffffffff0fffffff
    7dc7:	and    rbx,rsi
    7dca:	or     rbx,r11
    7dcd:	pop    r11
    7dcf:	pop    r10
    7dd1:	pop    rsi
    7dd2:	pop    rdx
    7dd3:	mov    QWORD PTR [r12+0x108],rbx
    7ddb:	stmxcsr DWORD PTR [r12-0x28]
    7de1:	mov    r10d,DWORD PTR [r12-0x28]
    7de6:	test   r10d,0x3f
    7ded:	je     0x7e12
    7df3:	mov    r11d,r10d
    7df6:	shr    r10d,1
    7df9:	and    r10d,0x1e
    7dfd:	and    r11d,0x1
    7e01:	or     r10d,r11d
    7e04:	or     DWORD PTR [r12+0x314],r10d
    7e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7e12:	ldmxcsr DWORD PTR [r12-0x38]
    7e18:	lea    rdi,[rsp+0x110]
    7e20:	lea    rsi,[rsp+0xf0]
    7e28:	lea    rdx,[rsp+0x100]
    7e30:	mov    ecx,0x56
    7e35:	mov    r8d,0x0
    7e3b:	lea    r9,[r12+0x314]
    7e43:	movabs r11,0x63ec26548650
    7e4d:	call   r11
    7e50:	ldmxcsr DWORD PTR [r12-0x28]
    7e56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7e5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7e62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7e68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7e6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7e74:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7e7e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7e88:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7e92:	mov    rbx,QWORD PTR [r12+0x108]
    7e9a:	mov    QWORD PTR [r12+0x378],0x2
    7ea6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7eaf:	mov    rdx,rbx
    7eb2:	shr    rdx,0x10
    7eb6:	and    edx,0xc000
    7ebc:	mov    rax,rbx
    7ebf:	shr    rax,0x15
    7ec3:	and    eax,0x100
    7ec8:	xor    eax,0x100
    7ecd:	or     edx,eax
    7ecf:	mov    rax,rbx
    7ed2:	shr    rax,0x1c
    7ed6:	and    eax,0x1
    7ed9:	or     edx,eax
    7edb:	mov    QWORD PTR [rsp+0x10],rdx
    7ee0:	add    rsp,0x8
    7ee4:	ret
    7ee5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7ef0:	sub    rsp,0x8
    7ef4:	mov    QWORD PTR [r12+0x378],0x3
    7f00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7f06:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7f0c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7f12:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7f18:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7f1e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7f28:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7f32:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7f3c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7f46:	push   rdx
    7f47:	push   rsi
    7f48:	push   r10
    7f4a:	push   r11
    7f4c:	mov    rdx,QWORD PTR [rsp+0x30]
    7f51:	mov    r10d,edx
    7f54:	and    r10d,0xc000
    7f5b:	shl    r10d,0x10
    7f5f:	mov    r11d,edx
    7f62:	and    r11d,0x100
    7f69:	shl    r11d,0x15
    7f6d:	or     r10d,r11d
    7f70:	and    edx,0x1
    7f73:	shl    edx,0x1c
    7f76:	or     r10d,edx
    7f79:	btc    r10,0x1d
    7f7e:	mov    r11d,0xf0000000
    7f84:	and    r11,r10
    7f87:	movabs rsi,0xffffffff0fffffff
    7f91:	and    rbx,rsi
    7f94:	or     rbx,r11
    7f97:	pop    r11
    7f99:	pop    r10
    7f9b:	pop    rsi
    7f9c:	pop    rdx
    7f9d:	mov    QWORD PTR [r12+0x108],rbx
    7fa5:	stmxcsr DWORD PTR [r12-0x28]
    7fab:	mov    r10d,DWORD PTR [r12-0x28]
    7fb0:	test   r10d,0x3f
    7fb7:	je     0x7fdc
    7fbd:	mov    r11d,r10d
    7fc0:	shr    r10d,1
    7fc3:	and    r10d,0x1e
    7fc7:	and    r11d,0x1
    7fcb:	or     r10d,r11d
    7fce:	or     DWORD PTR [r12+0x314],r10d
    7fd6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7fdc:	ldmxcsr DWORD PTR [r12-0x38]
    7fe2:	lea    rdi,[rsp+0x110]
    7fea:	lea    rsi,[rsp+0xf0]
    7ff2:	lea    rdx,[rsp+0x100]
    7ffa:	mov    ecx,0x56
    7fff:	mov    r8d,0x0
    8005:	lea    r9,[r12+0x314]
    800d:	movabs r11,0x63ec26548650
    8017:	call   r11
    801a:	ldmxcsr DWORD PTR [r12-0x28]
    8020:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    8026:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    802c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    8032:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    8038:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    803e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    8048:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    8052:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    805c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    8066:	mov    rbx,QWORD PTR [r12+0x108]
    806e:	mov    QWORD PTR [r12+0x378],0x2
    807a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    8083:	mov    rdx,rbx
    8086:	shr    rdx,0x10
    808a:	and    edx,0xc000
    8090:	mov    rax,rbx
    8093:	shr    rax,0x15
    8097:	and    eax,0x100
    809c:	xor    eax,0x100
    80a1:	or     edx,eax
    80a3:	mov    rax,rbx
    80a6:	shr    rax,0x1c
    80aa:	and    eax,0x1
    80ad:	or     edx,eax
    80af:	mov    QWORD PTR [rsp+0x10],rdx
    80b4:	add    rsp,0x8
    80b8:	ret
    80b9:	nop    DWORD PTR [rax+0x0]
    80c0:	sub    rsp,0x8
    80c4:	mov    QWORD PTR [r12+0x378],0x3
    80d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    80d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    80dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    80e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    80e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    80ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    80f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    8102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    810c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    8116:	push   rdx
    8117:	push   rsi
    8118:	push   r10
    811a:	push   r11
    811c:	mov    rdx,QWORD PTR [rsp+0x30]
    8121:	mov    r10d,edx
    8124:	and    r10d,0xc000
    812b:	shl    r10d,0x10
    812f:	mov    r11d,edx
    8132:	and    r11d,0x100
    8139:	shl    r11d,0x15
    813d:	or     r10d,r11d
    8140:	and    edx,0x1
    8143:	shl    edx,0x1c
    8146:	or     r10d,edx
    8149:	btc    r10,0x1d
    814e:	mov    r11d,0xf0000000
    8154:	and    r11,r10
    8157:	movabs rsi,0xffffffff0fffffff
    8161:	and    rbx,rsi
    8164:	or     rbx,r11
    8167:	pop    r11
    8169:	pop    r10
    816b:	pop    rsi
    816c:	pop    rdx
    816d:	mov    QWORD PTR [r12+0x108],rbx
    8175:	stmxcsr DWORD PTR [r12-0x28]
    817b:	mov    r10d,DWORD PTR [r12-0x28]
    8180:	test   r10d,0x3f
    8187:	je     0x81ac
    818d:	mov    r11d,r10d
    8190:	shr    r10d,1
    8193:	and    r10d,0x1e
    8197:	and    r11d,0x1
    819b:	or     r10d,r11d
    819e:	or     DWORD PTR [r12+0x314],r10d
    81a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    81ac:	ldmxcsr DWORD PTR [r12-0x38]
    81b2:	lea    rdi,[rsp+0x110]
    81ba:	lea    rsi,[rsp+0xf0]
    81c2:	lea    rdx,[rsp+0x100]
    81ca:	mov    ecx,0x14
    81cf:	mov    r8d,0x0
    81d5:	lea    r9,[r12+0x314]
    81dd:	movabs r11,0x63ec26548650
    81e7:	call   r11
    81ea:	ldmxcsr DWORD PTR [r12-0x28]
    81f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    81f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    81fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    8202:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    8208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    820e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    8218:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    8222:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    822c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    8236:	mov    rbx,QWORD PTR [r12+0x108]
    823e:	mov    QWORD PTR [r12+0x378],0x2
    824a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    8253:	mov    rdx,rbx
    8256:	shr    rdx,0x10
    825a:	and    edx,0xc000
    8260:	mov    rax,rbx
    8263:	shr    rax,0x15
    8267:	and    eax,0x100
    826c:	xor    eax,0x100
    8271:	or     edx,eax
    8273:	mov    rax,rbx
    8276:	shr    rax,0x1c
    827a:	and    eax,0x1
    827d:	or     edx,eax
    827f:	mov    QWORD PTR [rsp+0x10],rdx
    8284:	add    rsp,0x8
    8288:	ret
    8289:	nop    DWORD PTR [rax+0x0]
    8290:	sub    rsp,0x8
    8294:	mov    QWORD PTR [r12+0x378],0x3
    82a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    82a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    82ac:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    82b2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    82b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    82be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    82c8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    82d2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    82dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    82e6:	push   rdx
    82e7:	push   rsi
    82e8:	push   r10
    82ea:	push   r11
    82ec:	mov    rdx,QWORD PTR [rsp+0x30]
    82f1:	mov    r10d,edx
    82f4:	and    r10d,0xc000
    82fb:	shl    r10d,0x10
    82ff:	mov    r11d,edx
    8302:	and    r11d,0x100
    8309:	shl    r11d,0x15
    830d:	or     r10d,r11d
    8310:	and    edx,0x1
    8313:	shl    edx,0x1c
    8316:	or     r10d,edx
    8319:	btc    r10,0x1d
    831e:	mov    r11d,0xf0000000
    8324:	and    r11,r10
    8327:	movabs rsi,0xffffffff0fffffff
    8331:	and    rbx,rsi
    8334:	or     rbx,r11
    8337:	pop    r11
    8339:	pop    r10
    833b:	pop    rsi
    833c:	pop    rdx
    833d:	mov    QWORD PTR [r12+0x108],rbx
    8345:	stmxcsr DWORD PTR [r12-0x28]
    834b:	mov    r10d,DWORD PTR [r12-0x28]
    8350:	test   r10d,0x3f
    8357:	je     0x837c
    835d:	mov    r11d,r10d
    8360:	shr    r10d,1
    8363:	and    r10d,0x1e
    8367:	and    r11d,0x1
    836b:	or     r10d,r11d
    836e:	or     DWORD PTR [r12+0x314],r10d
    8376:	and    DWORD PTR [r12-0x28],0xffffffc0
    837c:	ldmxcsr DWORD PTR [r12-0x38]
    8382:	lea    rdi,[rsp+0x110]
    838a:	lea    rsi,[rsp+0xf0]
    8392:	lea    rdx,[rsp+0x100]
    839a:	mov    ecx,0x56
    839f:	mov    r8d,0x0
    83a5:	lea    r9,[r12+0x314]
    83ad:	movabs r11,0x63ec26548650
    83b7:	call   r11
    83ba:	ldmxcsr DWORD PTR [r12-0x28]
    83c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    83c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    83cc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    83d2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    83d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    83de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    83e8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    83f2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    83fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    8406:	mov    rbx,QWORD PTR [r12+0x108]
    840e:	mov    QWORD PTR [r12+0x378],0x2
    841a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    8423:	mov    rdx,rbx
    8426:	shr    rdx,0x10
    842a:	and    edx,0xc000
    8430:	mov    rax,rbx
    8433:	shr    rax,0x15
    8437:	and    eax,0x100
    843c:	xor    eax,0x100
    8441:	or     edx,eax
    8443:	mov    rax,rbx
    8446:	shr    rax,0x1c
    844a:	and    eax,0x1
    844d:	or     edx,eax
    844f:	mov    QWORD PTR [rsp+0x10],rdx
    8454:	add    rsp,0x8
    8458:	ret
    8459:	nop    DWORD PTR [rax+0x0]
    8460:	sub    rsp,0x8
    8464:	mov    QWORD PTR [r12+0x378],0x3
    8470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    8476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    847c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    8482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    8488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    848e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    8498:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    84a2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    84ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    84b6:	push   rdx
    84b7:	push   rsi
    84b8:	push   r10
    84ba:	push   r11
    84bc:	mov    rdx,QWORD PTR [rsp+0x30]
    84c1:	mov    r10d,edx
    84c4:	and    r10d,0xc000
    84cb:	shl    r10d,0x10
    84cf:	mov    r11d,edx
    84d2:	and    r11d,0x100
    84d9:	shl    r11d,0x15
    84dd:	or     r10d,r11d
    84e0:	and    edx,0x1
    84e3:	shl    edx,0x1c
    84e6:	or     r10d,edx
    84e9:	btc    r10,0x1d
    84ee:	mov    r11d,0xf0000000
    84f4:	and    r11,r10
    84f7:	movabs rsi,0xffffffff0fffffff
    8501:	and    rbx,rsi
    8504:	or     rbx,r11
    8507:	pop    r11
    8509:	pop    r10
    850b:	pop    rsi
    850c:	pop    rdx
    850d:	mov    QWORD PTR [r12+0x108],rbx
    8515:	stmxcsr DWORD PTR [r12-0x28]
    851b:	mov    r10d,DWORD PTR [r12-0x28]
    8520:	test   r10d,0x3f
    8527:	je     0x854c
    852d:	mov    r11d,r10d
    8530:	shr    r10d,1
    8533:	and    r10d,0x1e
    8537:	and    r11d,0x1
    853b:	or     r10d,r11d
    853e:	or     DWORD PTR [r12+0x314],r10d
    8546:	and    DWORD PTR [r12-0x28],0xffffffc0
    854c:	ldmxcsr DWORD PTR [r12-0x38]
    8552:	lea    rdi,[rsp+0x110]
    855a:	lea    rsi,[rsp+0xf0]
    8562:	lea    rdx,[rsp+0x100]
    856a:	mov    ecx,0x14
    856f:	mov    r8d,0x0
    8575:	lea    r9,[r12+0x314]
    857d:	movabs r11,0x63ec26548650
    8587:	call   r11
    858a:	ldmxcsr DWORD PTR [r12-0x28]
    8590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    8596:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    859c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    85a2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    85a8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    85ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    85b8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    85c2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    85cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    85d6:	mov    rbx,QWORD PTR [r12+0x108]
    85de:	mov    QWORD PTR [r12+0x378],0x2
    85ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    85f3:	mov    rdx,rbx
    85f6:	shr    rdx,0x10
    85fa:	and    edx,0xc000
    8600:	mov    rax,rbx
    8603:	shr    rax,0x15
    8607:	and    eax,0x100
    860c:	xor    eax,0x100
    8611:	or     edx,eax
    8613:	mov    rax,rbx
    8616:	shr    rax,0x1c
    861a:	and    eax,0x1
    861d:	or     edx,eax
    861f:	mov    QWORD PTR [rsp+0x10],rdx
    8624:	add    rsp,0x8
    8628:	ret
    8629:	nop    DWORD PTR [rax+0x0]
    8630:	sub    rsp,0x8
    8634:	mov    QWORD PTR [r12+0x378],0x3
    8640:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    8646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    864c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    8652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    8658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    865e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    8668:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    8672:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    867c:	push   rdx
    867d:	push   rsi
    867e:	push   r10
    8680:	push   r11
    8682:	mov    rdx,QWORD PTR [rsp+0x30]
    8687:	mov    r10d,edx
    868a:	and    r10d,0xc000
    8691:	shl    r10d,0x10
    8695:	mov    r11d,edx
    8698:	and    r11d,0x100
    869f:	shl    r11d,0x15
    86a3:	or     r10d,r11d
    86a6:	and    edx,0x1
    86a9:	shl    edx,0x1c
    86ac:	or     r10d,edx
    86af:	btc    r10,0x1d
    86b4:	mov    r11d,0xf0000000
    86ba:	and    r11,r10
    86bd:	movabs rsi,0xffffffff0fffffff
    86c7:	and    rbx,rsi
    86ca:	or     rbx,r11
    86cd:	pop    r11
    86cf:	pop    r10
    86d1:	pop    rsi
    86d2:	pop    rdx
    86d3:	mov    QWORD PTR [r12+0x108],rbx
    86db:	stmxcsr DWORD PTR [r12-0x28]
    86e1:	mov    r10d,DWORD PTR [r12-0x28]
    86e6:	test   r10d,0x3f
    86ed:	je     0x8712
    86f3:	mov    r11d,r10d
    86f6:	shr    r10d,1
    86f9:	and    r10d,0x1e
    86fd:	and    r11d,0x1
    8701:	or     r10d,r11d
    8704:	or     DWORD PTR [r12+0x314],r10d
    870c:	and    DWORD PTR [r12-0x28],0xffffffc0
    8712:	ldmxcsr DWORD PTR [r12-0x38]
    8718:	lea    rdi,[rsp+0x110]
    8720:	lea    rsi,[rsp+0xf0]
    8728:	lea    rdx,[rsp+0x100]
    8730:	mov    ecx,0x14
    8735:	mov    r8d,0x0
    873b:	lea    r9,[r12+0x314]
    8743:	movabs r11,0x63ec26548650
    874d:	call   r11
    8750:	ldmxcsr DWORD PTR [r12-0x28]
    8756:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    875c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    8762:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    8768:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    876e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    8774:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    877e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    8788:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    8792:	mov    rbx,QWORD PTR [r12+0x108]
    879a:	mov    QWORD PTR [r12+0x378],0x2
    87a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    87af:	mov    rdx,rbx
    87b2:	shr    rdx,0x10
    87b6:	and    edx,0xc000
    87bc:	mov    rax,rbx
    87bf:	shr    rax,0x15
    87c3:	and    eax,0x100
    87c8:	xor    eax,0x100
    87cd:	or     edx,eax
    87cf:	mov    rax,rbx
    87d2:	shr    rax,0x1c
    87d6:	and    eax,0x1
    87d9:	or     edx,eax
    87db:	mov    QWORD PTR [rsp+0x10],rdx
    87e0:	add    rsp,0x8
    87e4:	ret
    87e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    87f0:	sub    rsp,0x8
    87f4:	mov    QWORD PTR [r12+0x378],0x3
    8800:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    8806:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    880c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    8812:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    8818:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    881e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    8828:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    8832:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    883c:	push   rdx
    883d:	push   rsi
    883e:	push   r10
    8840:	push   r11
    8842:	mov    rdx,QWORD PTR [rsp+0x30]
    8847:	mov    r10d,edx
    884a:	and    r10d,0xc000
    8851:	shl    r10d,0x10
    8855:	mov    r11d,edx
    8858:	and    r11d,0x100
    885f:	shl    r11d,0x15
    8863:	or     r10d,r11d
    8866:	and    edx,0x1
    8869:	shl    edx,0x1c
    886c:	or     r10d,edx
    886f:	btc    r10,0x1d
    8874:	mov    r11d,0xf0000000
    887a:	and    r11,r10
    887d:	movabs rsi,0xffffffff0fffffff
    8887:	and    rbx,rsi
    888a:	or     rbx,r11
    888d:	pop    r11
    888f:	pop    r10
    8891:	pop    rsi
    8892:	pop    rdx
    8893:	mov    QWORD PTR [r12+0x108],rbx
    889b:	stmxcsr DWORD PTR [r12-0x28]
    88a1:	mov    r10d,DWORD PTR [r12-0x28]
    88a6:	test   r10d,0x3f
    88ad:	je     0x88d2
    88b3:	mov    r11d,r10d
    88b6:	shr    r10d,1
    88b9:	and    r10d,0x1e
    88bd:	and    r11d,0x1
    88c1:	or     r10d,r11d
    88c4:	or     DWORD PTR [r12+0x314],r10d
    88cc:	and    DWORD PTR [r12-0x28],0xffffffc0
    88d2:	ldmxcsr DWORD PTR [r12-0x38]
    88d8:	lea    rdi,[rsp+0x110]
    88e0:	lea    rsi,[rsp+0xf0]
    88e8:	lea    rdx,[rsp+0x100]
    88f0:	mov    ecx,0x14
    88f5:	mov    r8d,0x0
    88fb:	lea    r9,[r12+0x314]
    8903:	movabs r11,0x63ec26548650
    890d:	call   r11
    8910:	ldmxcsr DWORD PTR [r12-0x28]
    8916:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    891c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    8922:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    8928:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    892e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    8934:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    893e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    8948:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    8952:	mov    rbx,QWORD PTR [r12+0x108]
    895a:	mov    QWORD PTR [r12+0x378],0x2
    8966:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    896f:	mov    rdx,rbx
    8972:	shr    rdx,0x10
    8976:	and    edx,0xc000
    897c:	mov    rax,rbx
    897f:	shr    rax,0x15
    8983:	and    eax,0x100
    8988:	xor    eax,0x100
    898d:	or     edx,eax
    898f:	mov    rax,rbx
    8992:	shr    rax,0x1c
    8996:	and    eax,0x1
    8999:	or     edx,eax
    899b:	mov    QWORD PTR [rsp+0x10],rdx
    89a0:	add    rsp,0x8
    89a4:	ret
    89a5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    89b0:	sub    rsp,0x8
    89b4:	mov    QWORD PTR [r12+0x378],0x3
    89c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    89c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    89cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    89d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    89d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    89de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    89e4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    89ee:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    89f8:	push   rdx
    89f9:	push   rsi
    89fa:	push   r10
    89fc:	push   r11
    89fe:	mov    rdx,QWORD PTR [rsp+0x30]
    8a03:	mov    r10d,edx
    8a06:	and    r10d,0xc000
    8a0d:	shl    r10d,0x10
    8a11:	mov    r11d,edx
    8a14:	and    r11d,0x100
    8a1b:	shl    r11d,0x15
    8a1f:	or     r10d,r11d
    8a22:	and    edx,0x1
    8a25:	shl    edx,0x1c
    8a28:	or     r10d,edx
    8a2b:	btc    r10,0x1d
    8a30:	mov    r11d,0xf0000000
    8a36:	and    r11,r10
    8a39:	movabs rsi,0xffffffff0fffffff
    8a43:	and    rbx,rsi
    8a46:	or     rbx,r11
    8a49:	pop    r11
    8a4b:	pop    r10
    8a4d:	pop    rsi
    8a4e:	pop    rdx
    8a4f:	mov    QWORD PTR [r12+0x108],rbx
    8a57:	stmxcsr DWORD PTR [r12-0x28]
    8a5d:	mov    r10d,DWORD PTR [r12-0x28]
    8a62:	test   r10d,0x3f
    8a69:	je     0x8a8e
    8a6f:	mov    r11d,r10d
    8a72:	shr    r10d,1
    8a75:	and    r10d,0x1e
    8a79:	and    r11d,0x1
    8a7d:	or     r10d,r11d
    8a80:	or     DWORD PTR [r12+0x314],r10d
    8a88:	and    DWORD PTR [r12-0x28],0xffffffc0
    8a8e:	ldmxcsr DWORD PTR [r12-0x38]
    8a94:	lea    rdi,[rsp+0x110]
    8a9c:	lea    rsi,[rsp+0xf0]
    8aa4:	lea    rdx,[rsp+0x100]
    8aac:	mov    ecx,0x56
    8ab1:	mov    r8d,0x0
    8ab7:	lea    r9,[r12+0x314]
    8abf:	movabs r11,0x63ec26548650
    8ac9:	call   r11
    8acc:	ldmxcsr DWORD PTR [r12-0x28]
    8ad2:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    8ad8:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    8ade:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    8ae4:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    8aea:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    8af0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    8af6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    8b00:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    8b0a:	mov    rbx,QWORD PTR [r12+0x108]
    8b12:	mov    QWORD PTR [r12+0x378],0x2
    8b1e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    8b27:	mov    rdx,rbx
    8b2a:	shr    rdx,0x10
    8b2e:	and    edx,0xc000
    8b34:	mov    rax,rbx
    8b37:	shr    rax,0x15
    8b3b:	and    eax,0x100
    8b40:	xor    eax,0x100
    8b45:	or     edx,eax
    8b47:	mov    rax,rbx
    8b4a:	shr    rax,0x1c
    8b4e:	and    eax,0x1
    8b51:	or     edx,eax
    8b53:	mov    QWORD PTR [rsp+0x10],rdx
    8b58:	add    rsp,0x8
    8b5c:	ret
    8b5d:	nop    DWORD PTR [rax]
    8b60:	sub    rsp,0x8
    8b64:	mov    QWORD PTR [r12+0x378],0x3
    8b70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    8b76:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    8b7c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    8b82:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    8b88:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    8b8e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    8b98:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    8ba2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    8bac:	push   rdx
    8bad:	push   rsi
    8bae:	push   r10
    8bb0:	push   r11
    8bb2:	mov    rdx,QWORD PTR [rsp+0x30]
    8bb7:	mov    r10d,edx
    8bba:	and    r10d,0xc000
    8bc1:	shl    r10d,0x10
    8bc5:	mov    r11d,edx
    8bc8:	and    r11d,0x100
    8bcf:	shl    r11d,0x15
    8bd3:	or     r10d,r11d
    8bd6:	and    edx,0x1
    8bd9:	shl    edx,0x1c
    8bdc:	or     r10d,edx
    8bdf:	btc    r10,0x1d
    8be4:	mov    r11d,0xf0000000
    8bea:	and    r11,r10
    8bed:	movabs rsi,0xffffffff0fffffff
    8bf7:	and    rbx,rsi
    8bfa:	or     rbx,r11
    8bfd:	pop    r11
    8bff:	pop    r10
    8c01:	pop    rsi
    8c02:	pop    rdx
    8c03:	mov    QWORD PTR [r12+0x108],rbx
    8c0b:	stmxcsr DWORD PTR [r12-0x28]
    8c11:	mov    r10d,DWORD PTR [r12-0x28]
    8c16:	test   r10d,0x3f
    8c1d:	je     0x8c42
    8c23:	mov    r11d,r10d
    8c26:	shr    r10d,1
    8c29:	and    r10d,0x1e
    8c2d:	and    r11d,0x1
    8c31:	or     r10d,r11d
    8c34:	or     DWORD PTR [r12+0x314],r10d
    8c3c:	and    DWORD PTR [r12-0x28],0xffffffc0
    8c42:	ldmxcsr DWORD PTR [r12-0x38]
    8c48:	lea    rdi,[rsp+0x110]
    8c50:	lea    rsi,[rsp+0xf0]
    8c58:	lea    rdx,[rsp+0x100]
    8c60:	mov    ecx,0x56
    8c65:	mov    r8d,0x0
    8c6b:	lea    r9,[r12+0x314]
    8c73:	movabs r11,0x63ec26548650
    8c7d:	call   r11
    8c80:	ldmxcsr DWORD PTR [r12-0x28]
    8c86:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    8c8c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    8c92:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    8c98:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    8c9e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    8ca4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    8cae:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    8cb8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    8cc2:	mov    rbx,QWORD PTR [r12+0x108]
    8cca:	mov    QWORD PTR [r12+0x378],0x2
    8cd6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    8cdf:	mov    rdx,rbx
    8ce2:	shr    rdx,0x10
    8ce6:	and    edx,0xc000
    8cec:	mov    rax,rbx
    8cef:	shr    rax,0x15
    8cf3:	and    eax,0x100
    8cf8:	xor    eax,0x100
    8cfd:	or     edx,eax
    8cff:	mov    rax,rbx
    8d02:	shr    rax,0x1c
    8d06:	and    eax,0x1
    8d09:	or     edx,eax
    8d0b:	mov    QWORD PTR [rsp+0x10],rdx
    8d10:	add    rsp,0x8
    8d14:	ret
    8d15:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    8d20:	sub    rsp,0x8
    8d24:	mov    QWORD PTR [r12+0x378],0x3
    8d30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    8d36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    8d3c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    8d42:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    8d48:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    8d4e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    8d54:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    8d5e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    8d68:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    8d72:	push   rdx
    8d73:	push   rsi
    8d74:	push   r10
    8d76:	push   r11
    8d78:	mov    rdx,QWORD PTR [rsp+0x30]
    8d7d:	mov    r10d,edx
    8d80:	and    r10d,0xc000
    8d87:	shl    r10d,0x10
    8d8b:	mov    r11d,edx
    8d8e:	and    r11d,0x100
    8d95:	shl    r11d,0x15
    8d99:	or     r10d,r11d
    8d9c:	and    edx,0x1
    8d9f:	shl    edx,0x1c
    8da2:	or     r10d,edx
    8da5:	btc    r10,0x1d
    8daa:	mov    r11d,0xf0000000
    8db0:	and    r11,r10
    8db3:	movabs rsi,0xffffffff0fffffff
    8dbd:	and    rbx,rsi
    8dc0:	or     rbx,r11
    8dc3:	pop    r11
    8dc5:	pop    r10
    8dc7:	pop    rsi
    8dc8:	pop    rdx
    8dc9:	mov    QWORD PTR [r12+0x108],rbx
    8dd1:	stmxcsr DWORD PTR [r12-0x28]
    8dd7:	mov    r10d,DWORD PTR [r12-0x28]
    8ddc:	test   r10d,0x3f
    8de3:	je     0x8e08
    8de9:	mov    r11d,r10d
    8dec:	shr    r10d,1
    8def:	and    r10d,0x1e
    8df3:	and    r11d,0x1
    8df7:	or     r10d,r11d
    8dfa:	or     DWORD PTR [r12+0x314],r10d
    8e02:	and    DWORD PTR [r12-0x28],0xffffffc0
    8e08:	ldmxcsr DWORD PTR [r12-0x38]
    8e0e:	lea    rdi,[rsp+0x110]
    8e16:	lea    rsi,[rsp+0xf0]
    8e1e:	lea    rdx,[rsp+0x100]
    8e26:	mov    ecx,0x14
    8e2b:	mov    r8d,0x0
    8e31:	lea    r9,[r12+0x314]
    8e39:	movabs r11,0x63ec26548650
    8e43:	call   r11
    8e46:	ldmxcsr DWORD PTR [r12-0x28]
    8e4c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    8e52:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    8e58:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    8e5e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    8e64:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    8e6a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    8e70:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    8e7a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    8e84:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    8e8e:	mov    rbx,QWORD PTR [r12+0x108]
    8e96:	mov    QWORD PTR [r12+0x378],0x2
    8ea2:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    8eab:	mov    rdx,rbx
    8eae:	shr    rdx,0x10
    8eb2:	and    edx,0xc000
    8eb8:	mov    rax,rbx
    8ebb:	shr    rax,0x15
    8ebf:	and    eax,0x100
    8ec4:	xor    eax,0x100
    8ec9:	or     edx,eax
    8ecb:	mov    rax,rbx
    8ece:	shr    rax,0x1c
    8ed2:	and    eax,0x1
    8ed5:	or     edx,eax
    8ed7:	mov    QWORD PTR [rsp+0x10],rdx
    8edc:	add    rsp,0x8
    8ee0:	ret
    8ee1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    8ef0:	sub    rsp,0x8
    8ef4:	mov    QWORD PTR [r12+0x378],0x3
    8f00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    8f06:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    8f0c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    8f12:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    8f18:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    8f1e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    8f28:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    8f32:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    8f3c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    8f46:	push   rdx
    8f47:	push   rsi
    8f48:	push   r10
    8f4a:	push   r11
    8f4c:	mov    rdx,QWORD PTR [rsp+0x30]
    8f51:	mov    r10d,edx
    8f54:	and    r10d,0xc000
    8f5b:	shl    r10d,0x10
    8f5f:	mov    r11d,edx
    8f62:	and    r11d,0x100
    8f69:	shl    r11d,0x15
    8f6d:	or     r10d,r11d
    8f70:	and    edx,0x1
    8f73:	shl    edx,0x1c
    8f76:	or     r10d,edx
    8f79:	btc    r10,0x1d
    8f7e:	mov    r11d,0xf0000000
    8f84:	and    r11,r10
    8f87:	movabs rsi,0xffffffff0fffffff
    8f91:	and    rbx,rsi
    8f94:	or     rbx,r11
    8f97:	pop    r11
    8f99:	pop    r10
    8f9b:	pop    rsi
    8f9c:	pop    rdx
    8f9d:	mov    QWORD PTR [r12+0x108],rbx
    8fa5:	stmxcsr DWORD PTR [r12-0x28]
    8fab:	mov    r10d,DWORD PTR [r12-0x28]
    8fb0:	test   r10d,0x3f
    8fb7:	je     0x8fdc
    8fbd:	mov    r11d,r10d
    8fc0:	shr    r10d,1
    8fc3:	and    r10d,0x1e
    8fc7:	and    r11d,0x1
    8fcb:	or     r10d,r11d
    8fce:	or     DWORD PTR [r12+0x314],r10d
    8fd6:	and    DWORD PTR [r12-0x28],0xffffffc0
    8fdc:	ldmxcsr DWORD PTR [r12-0x38]
    8fe2:	lea    rdi,[rsp+0x110]
    8fea:	lea    rsi,[rsp+0xf0]
    8ff2:	lea    rdx,[rsp+0x100]
    8ffa:	mov    ecx,0x56
    8fff:	mov    r8d,0x0
    9005:	lea    r9,[r12+0x314]
    900d:	movabs r11,0x63ec26548650
    9017:	call   r11
    901a:	ldmxcsr DWORD PTR [r12-0x28]
    9020:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    9026:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    902c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    9032:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    9038:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    903e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    9048:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    9052:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    905c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    9066:	mov    rbx,QWORD PTR [r12+0x108]
    906e:	mov    QWORD PTR [r12+0x378],0x2
    907a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    9083:	mov    rdx,rbx
    9086:	shr    rdx,0x10
    908a:	and    edx,0xc000
    9090:	mov    rax,rbx
    9093:	shr    rax,0x15
    9097:	and    eax,0x100
    909c:	xor    eax,0x100
    90a1:	or     edx,eax
    90a3:	mov    rax,rbx
    90a6:	shr    rax,0x1c
    90aa:	and    eax,0x1
    90ad:	or     edx,eax
    90af:	mov    QWORD PTR [rsp+0x10],rdx
    90b4:	add    rsp,0x8
    90b8:	ret
    90b9:	nop    DWORD PTR [rax+0x0]
    90c0:	sub    rsp,0x8
    90c4:	mov    QWORD PTR [r12+0x378],0x3
    90d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    90d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    90dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    90e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    90e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    90ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    90f4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    90fe:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    9108:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    9112:	push   rdx
    9113:	push   rsi
    9114:	push   r10
    9116:	push   r11
    9118:	mov    rdx,QWORD PTR [rsp+0x30]
    911d:	mov    r10d,edx
    9120:	and    r10d,0xc000
    9127:	shl    r10d,0x10
    912b:	mov    r11d,edx
    912e:	and    r11d,0x100
    9135:	shl    r11d,0x15
    9139:	or     r10d,r11d
    913c:	and    edx,0x1
    913f:	shl    edx,0x1c
    9142:	or     r10d,edx
    9145:	btc    r10,0x1d
    914a:	mov    r11d,0xf0000000
    9150:	and    r11,r10
    9153:	movabs rsi,0xffffffff0fffffff
    915d:	and    rbx,rsi
    9160:	or     rbx,r11
    9163:	pop    r11
    9165:	pop    r10
    9167:	pop    rsi
    9168:	pop    rdx
    9169:	mov    QWORD PTR [r12+0x108],rbx
    9171:	stmxcsr DWORD PTR [r12-0x28]
    9177:	mov    r10d,DWORD PTR [r12-0x28]
    917c:	test   r10d,0x3f
    9183:	je     0x91a8
    9189:	mov    r11d,r10d
    918c:	shr    r10d,1
    918f:	and    r10d,0x1e
    9193:	and    r11d,0x1
    9197:	or     r10d,r11d
    919a:	or     DWORD PTR [r12+0x314],r10d
    91a2:	and    DWORD PTR [r12-0x28],0xffffffc0
    91a8:	ldmxcsr DWORD PTR [r12-0x38]
    91ae:	lea    rdi,[rsp+0x110]
    91b6:	lea    rsi,[rsp+0xf0]
    91be:	lea    rdx,[rsp+0x100]
    91c6:	mov    ecx,0x56
    91cb:	mov    r8d,0x0
    91d1:	lea    r9,[r12+0x314]
    91d9:	movabs r11,0x63ec26548650
    91e3:	call   r11
    91e6:	ldmxcsr DWORD PTR [r12-0x28]
    91ec:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    91f2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    91f8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    91fe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    9204:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    920a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    9210:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    921a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    9224:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    922e:	mov    rbx,QWORD PTR [r12+0x108]
    9236:	mov    QWORD PTR [r12+0x378],0x2
    9242:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    924b:	mov    rdx,rbx
    924e:	shr    rdx,0x10
    9252:	and    edx,0xc000
    9258:	mov    rax,rbx
    925b:	shr    rax,0x15
    925f:	and    eax,0x100
    9264:	xor    eax,0x100
    9269:	or     edx,eax
    926b:	mov    rax,rbx
    926e:	shr    rax,0x1c
    9272:	and    eax,0x1
    9275:	or     edx,eax
    9277:	mov    QWORD PTR [rsp+0x10],rdx
    927c:	add    rsp,0x8
    9280:	ret
    9281:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    9290:	sub    rsp,0x8
    9294:	mov    QWORD PTR [r12+0x378],0x3
    92a0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    92a6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    92ac:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    92b2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    92b8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    92c2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    92cc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    92d6:	push   rdx
    92d7:	push   rsi
    92d8:	push   r10
    92da:	push   r11
    92dc:	mov    rdx,QWORD PTR [rsp+0x30]
    92e1:	mov    r10d,edx
    92e4:	and    r10d,0xc000
    92eb:	shl    r10d,0x10
    92ef:	mov    r11d,edx
    92f2:	and    r11d,0x100
    92f9:	shl    r11d,0x15
    92fd:	or     r10d,r11d
    9300:	and    edx,0x1
    9303:	shl    edx,0x1c
    9306:	or     r10d,edx
    9309:	btc    r10,0x1d
    930e:	mov    r11d,0xf0000000
    9314:	and    r11,r10
    9317:	movabs rsi,0xffffffff0fffffff
    9321:	and    rbx,rsi
    9324:	or     rbx,r11
    9327:	pop    r11
    9329:	pop    r10
    932b:	pop    rsi
    932c:	pop    rdx
    932d:	mov    QWORD PTR [r12+0x108],rbx
    9335:	stmxcsr DWORD PTR [r12-0x28]
    933b:	mov    r10d,DWORD PTR [r12-0x28]
    9340:	test   r10d,0x3f
    9347:	je     0x936c
    934d:	mov    r11d,r10d
    9350:	shr    r10d,1
    9353:	and    r10d,0x1e
    9357:	and    r11d,0x1
    935b:	or     r10d,r11d
    935e:	or     DWORD PTR [r12+0x314],r10d
    9366:	and    DWORD PTR [r12-0x28],0xffffffc0
    936c:	ldmxcsr DWORD PTR [r12-0x38]
    9372:	lea    rdi,[rsp+0x110]
    937a:	lea    rsi,[rsp+0xf0]
    9382:	lea    rdx,[rsp+0x100]
    938a:	mov    ecx,0x14
    938f:	mov    r8d,0x0
    9395:	lea    r9,[r12+0x314]
    939d:	movabs r11,0x63ec26548650
    93a7:	call   r11
    93aa:	ldmxcsr DWORD PTR [r12-0x28]
    93b0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    93b6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    93bc:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    93c2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    93c8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    93d2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    93dc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    93e6:	mov    rbx,QWORD PTR [r12+0x108]
    93ee:	mov    QWORD PTR [r12+0x378],0x2
    93fa:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    9403:	mov    rdx,rbx
    9406:	shr    rdx,0x10
    940a:	and    edx,0xc000
    9410:	mov    rax,rbx
    9413:	shr    rax,0x15
    9417:	and    eax,0x100
    941c:	xor    eax,0x100
    9421:	or     edx,eax
    9423:	mov    rax,rbx
    9426:	shr    rax,0x1c
    942a:	and    eax,0x1
    942d:	or     edx,eax
    942f:	mov    QWORD PTR [rsp+0x10],rdx
    9434:	add    rsp,0x8
    9438:	ret
    9439:	nop    DWORD PTR [rax+0x0]
    9440:	sub    rsp,0x8
    9444:	mov    QWORD PTR [r12+0x378],0x3
    9450:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    9456:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    945c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    9462:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    946c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    9476:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    9480:	push   rdx
    9481:	push   rsi
    9482:	push   r10
    9484:	push   r11
    9486:	mov    rdx,QWORD PTR [rsp+0x30]
    948b:	mov    r10d,edx
    948e:	and    r10d,0xc000
    9495:	shl    r10d,0x10
    9499:	mov    r11d,edx
    949c:	and    r11d,0x100
    94a3:	shl    r11d,0x15
    94a7:	or     r10d,r11d
    94aa:	and    edx,0x1
    94ad:	shl    edx,0x1c
    94b0:	or     r10d,edx
    94b3:	btc    r10,0x1d
    94b8:	mov    r11d,0xf0000000
    94be:	and    r11,r10
    94c1:	movabs rsi,0xffffffff0fffffff
    94cb:	and    rbx,rsi
    94ce:	or     rbx,r11
    94d1:	pop    r11
    94d3:	pop    r10
    94d5:	pop    rsi
    94d6:	pop    rdx
    94d7:	mov    QWORD PTR [r12+0x108],rbx
    94df:	stmxcsr DWORD PTR [r12-0x28]
    94e5:	mov    r10d,DWORD PTR [r12-0x28]
    94ea:	test   r10d,0x3f
    94f1:	je     0x9516
    94f7:	mov    r11d,r10d
    94fa:	shr    r10d,1
    94fd:	and    r10d,0x1e
    9501:	and    r11d,0x1
    9505:	or     r10d,r11d
    9508:	or     DWORD PTR [r12+0x314],r10d
    9510:	and    DWORD PTR [r12-0x28],0xffffffc0
    9516:	ldmxcsr DWORD PTR [r12-0x38]
    951c:	lea    rdi,[rsp+0x110]
    9524:	lea    rsi,[rsp+0xf0]
    952c:	lea    rdx,[rsp+0x100]
    9534:	mov    ecx,0x14
    9539:	mov    r8d,0x0
    953f:	lea    r9,[r12+0x314]
    9547:	movabs r11,0x63ec26548650
    9551:	call   r11
    9554:	ldmxcsr DWORD PTR [r12-0x28]
    955a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    9560:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    9566:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    956c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    9576:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    9580:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    958a:	mov    rbx,QWORD PTR [r12+0x108]
    9592:	mov    QWORD PTR [r12+0x378],0x2
    959e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    95a7:	mov    rdx,rbx
    95aa:	shr    rdx,0x10
    95ae:	and    edx,0xc000
    95b4:	mov    rax,rbx
    95b7:	shr    rax,0x15
    95bb:	and    eax,0x100
    95c0:	xor    eax,0x100
    95c5:	or     edx,eax
    95c7:	mov    rax,rbx
    95ca:	shr    rax,0x1c
    95ce:	and    eax,0x1
    95d1:	or     edx,eax
    95d3:	mov    QWORD PTR [rsp+0x10],rdx
    95d8:	add    rsp,0x8
    95dc:	ret
    95dd:	nop    DWORD PTR [rax]
    95e0:	sub    rsp,0x8
    95e4:	mov    QWORD PTR [r12+0x378],0x3
    95f0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    95f6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    95fc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    9602:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    960c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    9616:	push   rdx
    9617:	push   rsi
    9618:	push   r10
    961a:	push   r11
    961c:	mov    rdx,QWORD PTR [rsp+0x30]
    9621:	mov    r10d,edx
    9624:	and    r10d,0xc000
    962b:	shl    r10d,0x10
    962f:	mov    r11d,edx
    9632:	and    r11d,0x100
    9639:	shl    r11d,0x15
    963d:	or     r10d,r11d
    9640:	and    edx,0x1
    9643:	shl    edx,0x1c
    9646:	or     r10d,edx
    9649:	btc    r10,0x1d
    964e:	mov    r11d,0xf0000000
    9654:	and    r11,r10
    9657:	movabs rsi,0xffffffff0fffffff
    9661:	and    rbx,rsi
    9664:	or     rbx,r11
    9667:	pop    r11
    9669:	pop    r10
    966b:	pop    rsi
    966c:	pop    rdx
    966d:	mov    QWORD PTR [r12+0x108],rbx
    9675:	stmxcsr DWORD PTR [r12-0x28]
    967b:	mov    r10d,DWORD PTR [r12-0x28]
    9680:	test   r10d,0x3f
    9687:	je     0x96ac
    968d:	mov    r11d,r10d
    9690:	shr    r10d,1
    9693:	and    r10d,0x1e
    9697:	and    r11d,0x1
    969b:	or     r10d,r11d
    969e:	or     DWORD PTR [r12+0x314],r10d
    96a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    96ac:	ldmxcsr DWORD PTR [r12-0x38]
    96b2:	lea    rdi,[rsp+0x110]
    96ba:	lea    rsi,[rsp+0xf0]
    96c2:	lea    rdx,[rsp+0x100]
    96ca:	mov    ecx,0x14
    96cf:	mov    r8d,0x0
    96d5:	lea    r9,[r12+0x314]
    96dd:	movabs r11,0x63ec26548650
    96e7:	call   r11
    96ea:	ldmxcsr DWORD PTR [r12-0x28]
    96f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    96f6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    96fc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    9702:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    970c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    9716:	mov    rbx,QWORD PTR [r12+0x108]
    971e:	mov    QWORD PTR [r12+0x378],0x2
    972a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    9733:	mov    rdx,rbx
    9736:	shr    rdx,0x10
    973a:	and    edx,0xc000
    9740:	mov    rax,rbx
    9743:	shr    rax,0x15
    9747:	and    eax,0x100
    974c:	xor    eax,0x100
    9751:	or     edx,eax
    9753:	mov    rax,rbx
    9756:	shr    rax,0x1c
    975a:	and    eax,0x1
    975d:	or     edx,eax
    975f:	mov    QWORD PTR [rsp+0x10],rdx
    9764:	add    rsp,0x8
    9768:	ret
    9769:	nop    DWORD PTR [rax+0x0]
    9770:	sub    rsp,0x8
    9774:	mov    QWORD PTR [r12+0x378],0x3
    9780:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    9786:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    978c:	push   rdx
    978d:	push   rsi
    978e:	push   r10
    9790:	push   r11
    9792:	mov    rdx,QWORD PTR [rsp+0x30]
    9797:	mov    r10d,edx
    979a:	and    r10d,0xc000
    97a1:	shl    r10d,0x10
    97a5:	mov    r11d,edx
    97a8:	and    r11d,0x100
    97af:	shl    r11d,0x15
    97b3:	or     r10d,r11d
    97b6:	and    edx,0x1
    97b9:	shl    edx,0x1c
    97bc:	or     r10d,edx
    97bf:	btc    r10,0x1d
    97c4:	mov    r11d,0xf0000000
    97ca:	and    r11,r10
    97cd:	movabs rsi,0xffffffff0fffffff
    97d7:	and    rbx,rsi
    97da:	or     rbx,r11
    97dd:	pop    r11
    97df:	pop    r10
    97e1:	pop    rsi
    97e2:	pop    rdx
    97e3:	mov    QWORD PTR [r12+0x108],rbx
    97eb:	stmxcsr DWORD PTR [r12-0x28]
    97f1:	mov    r10d,DWORD PTR [r12-0x28]
    97f6:	test   r10d,0x3f
    97fd:	je     0x9822
    9803:	mov    r11d,r10d
    9806:	shr    r10d,1
    9809:	and    r10d,0x1e
    980d:	and    r11d,0x1
    9811:	or     r10d,r11d
    9814:	or     DWORD PTR [r12+0x314],r10d
    981c:	and    DWORD PTR [r12-0x28],0xffffffc0
    9822:	ldmxcsr DWORD PTR [r12-0x38]
    9828:	lea    rdi,[rsp+0x110]
    9830:	lea    rsi,[rsp+0xf0]
    9838:	lea    rdx,[rsp+0x100]
    9840:	mov    ecx,0xc
    9845:	mov    r8d,0x0
    984b:	lea    r9,[r12+0x314]
    9853:	movabs r11,0x63ec26548650
    985d:	call   r11
    9860:	ldmxcsr DWORD PTR [r12-0x28]
    9866:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    986c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    9872:	mov    rbx,QWORD PTR [r12+0x108]
    987a:	mov    QWORD PTR [r12+0x378],0x2
    9886:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    988f:	mov    rdx,rbx
    9892:	shr    rdx,0x10
    9896:	and    edx,0xc000
    989c:	mov    rax,rbx
    989f:	shr    rax,0x15
    98a3:	and    eax,0x100
    98a8:	xor    eax,0x100
    98ad:	or     edx,eax
    98af:	mov    rax,rbx
    98b2:	shr    rax,0x1c
    98b6:	and    eax,0x1
    98b9:	or     edx,eax
    98bb:	mov    QWORD PTR [rsp+0x10],rdx
    98c0:	add    rsp,0x8
    98c4:	ret
    98c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    98d0:	sub    rsp,0x8
    98d4:	mov    QWORD PTR [r12+0x378],0x3
    98e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    98e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    98ec:	push   rdx
    98ed:	push   rsi
    98ee:	push   r10
    98f0:	push   r11
    98f2:	mov    rdx,QWORD PTR [rsp+0x30]
    98f7:	mov    r10d,edx
    98fa:	and    r10d,0xc000
    9901:	shl    r10d,0x10
    9905:	mov    r11d,edx
    9908:	and    r11d,0x100
    990f:	shl    r11d,0x15
    9913:	or     r10d,r11d
    9916:	and    edx,0x1
    9919:	shl    edx,0x1c
    991c:	or     r10d,edx
    991f:	btc    r10,0x1d
    9924:	mov    r11d,0xf0000000
    992a:	and    r11,r10
    992d:	movabs rsi,0xffffffff0fffffff
    9937:	and    rbx,rsi
    993a:	or     rbx,r11
    993d:	pop    r11
    993f:	pop    r10
    9941:	pop    rsi
    9942:	pop    rdx
    9943:	mov    QWORD PTR [r12+0x108],rbx
    994b:	stmxcsr DWORD PTR [r12-0x28]
    9951:	mov    r10d,DWORD PTR [r12-0x28]
    9956:	test   r10d,0x3f
    995d:	je     0x9982
    9963:	mov    r11d,r10d
    9966:	shr    r10d,1
    9969:	and    r10d,0x1e
    996d:	and    r11d,0x1
    9971:	or     r10d,r11d
    9974:	or     DWORD PTR [r12+0x314],r10d
    997c:	and    DWORD PTR [r12-0x28],0xffffffc0
    9982:	ldmxcsr DWORD PTR [r12-0x38]
    9988:	lea    rdi,[rsp+0x110]
    9990:	lea    rsi,[rsp+0xf0]
    9998:	lea    rdx,[rsp+0x100]
    99a0:	mov    ecx,0xc
    99a5:	mov    r8d,0x0
    99ab:	lea    r9,[r12+0x314]
    99b3:	movabs r11,0x63ec26548650
    99bd:	call   r11
    99c0:	ldmxcsr DWORD PTR [r12-0x28]
    99c6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    99cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    99d2:	mov    rbx,QWORD PTR [r12+0x108]
    99da:	mov    QWORD PTR [r12+0x378],0x2
    99e6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    99ef:	mov    rdx,rbx
    99f2:	shr    rdx,0x10
    99f6:	and    edx,0xc000
    99fc:	mov    rax,rbx
    99ff:	shr    rax,0x15
    9a03:	and    eax,0x100
    9a08:	xor    eax,0x100
    9a0d:	or     edx,eax
    9a0f:	mov    rax,rbx
    9a12:	shr    rax,0x1c
    9a16:	and    eax,0x1
    9a19:	or     edx,eax
    9a1b:	mov    QWORD PTR [rsp+0x10],rdx
    9a20:	add    rsp,0x8
    9a24:	ret
    9a25:	mov    eax,0x4101e8
    9a2a:	mov    QWORD PTR [r12+0x100],rax
    9a32:	push   rdx
    9a33:	push   rsi
    9a34:	push   r10
    9a36:	push   r11
    9a38:	mov    r11,rax
    9a3b:	lahf
    9a3c:	seto   al
    9a3f:	mov    WORD PTR [rsp+0x20],ax
    9a44:	mov    rax,r11
    9a47:	mov    rdx,QWORD PTR [rsp+0x20]
    9a4c:	mov    r10d,edx
    9a4f:	and    r10d,0xc000
    9a56:	shl    r10d,0x10
    9a5a:	mov    r11d,edx
    9a5d:	and    r11d,0x100
    9a64:	shl    r11d,0x15
    9a68:	or     r10d,r11d
    9a6b:	and    edx,0x1
    9a6e:	shl    edx,0x1c
    9a71:	or     r10d,edx
    9a74:	btc    r10,0x1d
    9a79:	mov    r11d,0xf0000000
    9a7f:	and    r11,r10
    9a82:	movabs rsi,0xffffffff0fffffff
    9a8c:	and    rbx,rsi
    9a8f:	or     rbx,r11
    9a92:	pop    r11
    9a94:	pop    r10
    9a96:	pop    rsi
    9a97:	pop    rdx
    9a98:	mov    QWORD PTR [r12+0x108],rbx
    9aa0:	add    rsp,0x150
    9aa7:	mov    eax,0xc
    9aac:	movabs r11,0x63ec266e1ca0
    9ab6:	jmp    r11
    9ab9:	mov    eax,0x410440
    9abe:	mov    QWORD PTR [r12+0x100],rax
    9ac6:	push   rdx
    9ac7:	push   rsi
    9ac8:	push   r10
    9aca:	push   r11
    9acc:	mov    rdx,QWORD PTR [rsp+0x20]
    9ad1:	mov    r10d,edx
    9ad4:	and    r10d,0xc000
    9adb:	shl    r10d,0x10
    9adf:	mov    r11d,edx
    9ae2:	and    r11d,0x100
    9ae9:	shl    r11d,0x15
    9aed:	or     r10d,r11d
    9af0:	and    edx,0x1
    9af3:	shl    edx,0x1c
    9af6:	or     r10d,edx
    9af9:	btc    r10,0x1d
    9afe:	mov    r11d,0xf0000000
    9b04:	and    r11,r10
    9b07:	movabs rsi,0xffffffff0fffffff
    9b11:	and    rbx,rsi
    9b14:	or     rbx,r11
    9b17:	pop    r11
    9b19:	pop    r10
    9b1b:	pop    rsi
    9b1c:	pop    rdx
    9b1d:	mov    QWORD PTR [r12+0x108],rbx
    9b25:	add    rsp,0x150
    9b2c:	mov    eax,0xc
    9b31:	movabs r11,0x63ec266e1ca0
    9b3b:	jmp    r11
    9b3e:	mov    eax,0x41044c
    9b43:	mov    QWORD PTR [r12+0x100],rax
    9b4b:	push   rdx
    9b4c:	push   rsi
    9b4d:	push   r10
    9b4f:	push   r11
    9b51:	mov    r11,rax
    9b54:	lahf
    9b55:	seto   al
    9b58:	mov    WORD PTR [rsp+0x20],ax
    9b5d:	mov    rax,r11
    9b60:	mov    rdx,QWORD PTR [rsp+0x20]
    9b65:	mov    r10d,edx
    9b68:	and    r10d,0xc000
    9b6f:	shl    r10d,0x10
    9b73:	mov    r11d,edx
    9b76:	and    r11d,0x100
    9b7d:	shl    r11d,0x15
    9b81:	or     r10d,r11d
    9b84:	and    edx,0x1
    9b87:	shl    edx,0x1c
    9b8a:	or     r10d,edx
    9b8d:	btc    r10,0x1d
    9b92:	mov    r11d,0xf0000000
    9b98:	and    r11,r10
    9b9b:	movabs rsi,0xffffffff0fffffff
    9ba5:	and    rbx,rsi
    9ba8:	or     rbx,r11
    9bab:	pop    r11
    9bad:	pop    r10
    9baf:	pop    rsi
    9bb0:	pop    rdx
    9bb1:	mov    QWORD PTR [r12+0x108],rbx
    9bb9:	add    rsp,0x150
    9bc0:	mov    eax,0xc
    9bc5:	movabs r11,0x63ec266e1ca0
    9bcf:	jmp    r11
    9bd2:	mov    eax,0x41048c
    9bd7:	mov    QWORD PTR [r12+0x100],rax
    9bdf:	push   rdx
    9be0:	push   rsi
    9be1:	push   r10
    9be3:	push   r11
    9be5:	mov    r11,rax
    9be8:	lahf
    9be9:	seto   al
    9bec:	mov    WORD PTR [rsp+0x20],ax
    9bf1:	mov    rax,r11
    9bf4:	mov    rdx,QWORD PTR [rsp+0x20]
    9bf9:	mov    r10d,edx
    9bfc:	and    r10d,0xc000
    9c03:	shl    r10d,0x10
    9c07:	mov    r11d,edx
    9c0a:	and    r11d,0x100
    9c11:	shl    r11d,0x15
    9c15:	or     r10d,r11d
    9c18:	and    edx,0x1
    9c1b:	shl    edx,0x1c
    9c1e:	or     r10d,edx
    9c21:	btc    r10,0x1d
    9c26:	mov    r11d,0xf0000000
    9c2c:	and    r11,r10
    9c2f:	movabs rsi,0xffffffff0fffffff
    9c39:	and    rbx,rsi
    9c3c:	or     rbx,r11
    9c3f:	pop    r11
    9c41:	pop    r10
    9c43:	pop    rsi
    9c44:	pop    rdx
    9c45:	mov    QWORD PTR [r12+0x108],rbx
    9c4d:	add    rsp,0x150
    9c54:	mov    eax,0xc
    9c59:	movabs r11,0x63ec266e1ca0
    9c63:	jmp    r11
    9c66:	mov    eax,0x410494
    9c6b:	mov    QWORD PTR [r12+0x100],rax
    9c73:	push   rdx
    9c74:	push   rsi
    9c75:	push   r10
    9c77:	push   r11
    9c79:	mov    rdx,QWORD PTR [rsp+0x20]
    9c7e:	mov    r10d,edx
    9c81:	and    r10d,0xc000
    9c88:	shl    r10d,0x10
    9c8c:	mov    r11d,edx
    9c8f:	and    r11d,0x100
    9c96:	shl    r11d,0x15
    9c9a:	or     r10d,r11d
    9c9d:	and    edx,0x1
    9ca0:	shl    edx,0x1c
    9ca3:	or     r10d,edx
    9ca6:	btc    r10,0x1d
    9cab:	mov    r11d,0xf0000000
    9cb1:	and    r11,r10
    9cb4:	movabs rsi,0xffffffff0fffffff
    9cbe:	and    rbx,rsi
    9cc1:	or     rbx,r11
    9cc4:	pop    r11
    9cc6:	pop    r10
    9cc8:	pop    rsi
    9cc9:	pop    rdx
    9cca:	mov    QWORD PTR [r12+0x108],rbx
    9cd2:	add    rsp,0x150
    9cd9:	mov    eax,0xc
    9cde:	movabs r11,0x63ec266e1ca0
    9ce8:	jmp    r11
    9ceb:	nop    DWORD PTR [rax+rax*1+0x0]
    9cf0:	sub    rsp,0x150
    9cf7:	mov    r11,QWORD PTR [r12+0x398]
    9cff:	mov    QWORD PTR [rsp],r11
    9d03:	cmp    DWORD PTR [r12+0x310],0x0
    9d0c:	je     0x9d97
    9d12:	push   rdx
    9d13:	push   rsi
    9d14:	push   r10
    9d16:	push   r11
    9d18:	mov    rdx,QWORD PTR [rsp+0x20]
    9d1d:	mov    r10d,edx
    9d20:	and    r10d,0xc000
    9d27:	shl    r10d,0x10
    9d2b:	mov    r11d,edx
    9d2e:	and    r11d,0x100
    9d35:	shl    r11d,0x15
    9d39:	or     r10d,r11d
    9d3c:	and    edx,0x1
    9d3f:	shl    edx,0x1c
    9d42:	or     r10d,edx
    9d45:	btc    r10,0x1d
    9d4a:	mov    r11d,0xf0000000
    9d50:	and    r11,r10
    9d53:	movabs rsi,0xffffffff0fffffff
    9d5d:	and    rbx,rsi
    9d60:	or     rbx,r11
    9d63:	pop    r11
    9d65:	pop    r10
    9d67:	pop    rsi
    9d68:	pop    rdx
    9d69:	mov    QWORD PTR [r12+0x108],rbx
    9d71:	mov    eax,0x4101ac
    9d76:	mov    QWORD PTR [r12+0x100],rax
    9d7e:	add    rsp,0x150
    9d85:	mov    eax,0x3
    9d8a:	movabs r11,0x63ec266e1ca0
    9d94:	jmp    r11
    9d97:	mov    r11,rax
    9d9a:	movzx  eax,WORD PTR [rsp]
    9d9e:	add    al,0x7f
    9da0:	sahf
    9da1:	mov    rax,r11
    9da4:	jmp    0x202
    9da9:	nop    DWORD PTR [rax+0x0]
    9db0:	sub    rsp,0x150
    9db7:	mov    r11,QWORD PTR [r12+0x398]
    9dbf:	mov    QWORD PTR [rsp],r11
    9dc3:	cmp    DWORD PTR [r12+0x310],0x0
    9dcc:	je     0x9e57
    9dd2:	push   rdx
    9dd3:	push   rsi
    9dd4:	push   r10
    9dd6:	push   r11
    9dd8:	mov    rdx,QWORD PTR [rsp+0x20]
    9ddd:	mov    r10d,edx
    9de0:	and    r10d,0xc000
    9de7:	shl    r10d,0x10
    9deb:	mov    r11d,edx
    9dee:	and    r11d,0x100
    9df5:	shl    r11d,0x15
    9df9:	or     r10d,r11d
    9dfc:	and    edx,0x1
    9dff:	shl    edx,0x1c
    9e02:	or     r10d,edx
    9e05:	btc    r10,0x1d
    9e0a:	mov    r11d,0xf0000000
    9e10:	and    r11,r10
    9e13:	movabs rsi,0xffffffff0fffffff
    9e1d:	and    rbx,rsi
    9e20:	or     rbx,r11
    9e23:	pop    r11
    9e25:	pop    r10
    9e27:	pop    rsi
    9e28:	pop    rdx
    9e29:	mov    QWORD PTR [r12+0x108],rbx
    9e31:	mov    eax,0x4101ec
    9e36:	mov    QWORD PTR [r12+0x100],rax
    9e3e:	add    rsp,0x150
    9e45:	mov    eax,0x3
    9e4a:	movabs r11,0x63ec266e1ca0
    9e54:	jmp    r11
    9e57:	jmp    0x650
    9e5c:	nop    DWORD PTR [rax+0x0]
    9e60:	sub    rsp,0x150
    9e67:	mov    r11,QWORD PTR [r12+0x398]
    9e6f:	mov    QWORD PTR [rsp],r11
    9e73:	cmp    DWORD PTR [r12+0x310],0x0
    9e7c:	je     0x9f07
    9e82:	push   rdx
    9e83:	push   rsi
    9e84:	push   r10
    9e86:	push   r11
    9e88:	mov    rdx,QWORD PTR [rsp+0x20]
    9e8d:	mov    r10d,edx
    9e90:	and    r10d,0xc000
    9e97:	shl    r10d,0x10
    9e9b:	mov    r11d,edx
    9e9e:	and    r11d,0x100
    9ea5:	shl    r11d,0x15
    9ea9:	or     r10d,r11d
    9eac:	and    edx,0x1
    9eaf:	shl    edx,0x1c
    9eb2:	or     r10d,edx
    9eb5:	btc    r10,0x1d
    9eba:	mov    r11d,0xf0000000
    9ec0:	and    r11,r10
    9ec3:	movabs rsi,0xffffffff0fffffff
    9ecd:	and    rbx,rsi
    9ed0:	or     rbx,r11
    9ed3:	pop    r11
    9ed5:	pop    r10
    9ed7:	pop    rsi
    9ed8:	pop    rdx
    9ed9:	mov    QWORD PTR [r12+0x108],rbx
    9ee1:	mov    eax,0x410274
    9ee6:	mov    QWORD PTR [r12+0x100],rax
    9eee:	add    rsp,0x150
    9ef5:	mov    eax,0x3
    9efa:	movabs r11,0x63ec266e1ca0
    9f04:	jmp    r11
    9f07:	mov    r11,rax
    9f0a:	movzx  eax,WORD PTR [rsp]
    9f0e:	add    al,0x7f
    9f10:	sahf
    9f11:	mov    rax,r11
    9f14:	jmp    0xb1b
    9f19:	nop    DWORD PTR [rax+0x0]
    9f20:	sub    rsp,0x150
    9f27:	mov    r11,QWORD PTR [r12+0x398]
    9f2f:	mov    QWORD PTR [rsp],r11
    9f33:	cmp    DWORD PTR [r12+0x310],0x0
    9f3c:	je     0x9fc7
    9f42:	push   rdx
    9f43:	push   rsi
    9f44:	push   r10
    9f46:	push   r11
    9f48:	mov    rdx,QWORD PTR [rsp+0x20]
    9f4d:	mov    r10d,edx
    9f50:	and    r10d,0xc000
    9f57:	shl    r10d,0x10
    9f5b:	mov    r11d,edx
    9f5e:	and    r11d,0x100
    9f65:	shl    r11d,0x15
    9f69:	or     r10d,r11d
    9f6c:	and    edx,0x1
    9f6f:	shl    edx,0x1c
    9f72:	or     r10d,edx
    9f75:	btc    r10,0x1d
    9f7a:	mov    r11d,0xf0000000
    9f80:	and    r11,r10
    9f83:	movabs rsi,0xffffffff0fffffff
    9f8d:	and    rbx,rsi
    9f90:	or     rbx,r11
    9f93:	pop    r11
    9f95:	pop    r10
    9f97:	pop    rsi
    9f98:	pop    rdx
    9f99:	mov    QWORD PTR [r12+0x108],rbx
    9fa1:	mov    eax,0x410278
    9fa6:	mov    QWORD PTR [r12+0x100],rax
    9fae:	add    rsp,0x150
    9fb5:	mov    eax,0x3
    9fba:	movabs r11,0x63ec266e1ca0
    9fc4:	jmp    r11
    9fc7:	jmp    0xb39
    9fcc:	nop    DWORD PTR [rax+0x0]
    9fd0:	sub    rsp,0x150
    9fd7:	mov    r11,QWORD PTR [r12+0x398]
    9fdf:	mov    QWORD PTR [rsp],r11
    9fe3:	cmp    DWORD PTR [r12+0x310],0x0
    9fec:	je     0xa077
    9ff2:	push   rdx
    9ff3:	push   rsi
    9ff4:	push   r10
    9ff6:	push   r11
    9ff8:	mov    rdx,QWORD PTR [rsp+0x20]
    9ffd:	mov    r10d,edx
    a000:	and    r10d,0xc000
    a007:	shl    r10d,0x10
    a00b:	mov    r11d,edx
    a00e:	and    r11d,0x100
    a015:	shl    r11d,0x15
    a019:	or     r10d,r11d
    a01c:	and    edx,0x1
    a01f:	shl    edx,0x1c
    a022:	or     r10d,edx
    a025:	btc    r10,0x1d
    a02a:	mov    r11d,0xf0000000
    a030:	and    r11,r10
    a033:	movabs rsi,0xffffffff0fffffff
    a03d:	and    rbx,rsi
    a040:	or     rbx,r11
    a043:	pop    r11
    a045:	pop    r10
    a047:	pop    rsi
    a048:	pop    rdx
    a049:	mov    QWORD PTR [r12+0x108],rbx
    a051:	mov    eax,0x410444
    a056:	mov    QWORD PTR [r12+0x100],rax
    a05e:	add    rsp,0x150
    a065:	mov    eax,0x3
    a06a:	movabs r11,0x63ec266e1ca0
    a074:	jmp    r11
    a077:	jmp    0x2879
    a07c:	nop    DWORD PTR [rax+0x0]
    a080:	sub    rsp,0x150
    a087:	mov    r11,QWORD PTR [r12+0x398]
    a08f:	mov    QWORD PTR [rsp],r11
    a093:	cmp    DWORD PTR [r12+0x310],0x0
    a09c:	je     0xa127
    a0a2:	push   rdx
    a0a3:	push   rsi
    a0a4:	push   r10
    a0a6:	push   r11
    a0a8:	mov    rdx,QWORD PTR [rsp+0x20]
    a0ad:	mov    r10d,edx
    a0b0:	and    r10d,0xc000
    a0b7:	shl    r10d,0x10
    a0bb:	mov    r11d,edx
    a0be:	and    r11d,0x100
    a0c5:	shl    r11d,0x15
    a0c9:	or     r10d,r11d
    a0cc:	and    edx,0x1
    a0cf:	shl    edx,0x1c
    a0d2:	or     r10d,edx
    a0d5:	btc    r10,0x1d
    a0da:	mov    r11d,0xf0000000
    a0e0:	and    r11,r10
    a0e3:	movabs rsi,0xffffffff0fffffff
    a0ed:	and    rbx,rsi
    a0f0:	or     rbx,r11
    a0f3:	pop    r11
    a0f5:	pop    r10
    a0f7:	pop    rsi
    a0f8:	pop    rdx
    a0f9:	mov    QWORD PTR [r12+0x108],rbx
    a101:	mov    eax,0x410450
    a106:	mov    QWORD PTR [r12+0x100],rax
    a10e:	add    rsp,0x150
    a115:	mov    eax,0x3
    a11a:	movabs r11,0x63ec266e1ca0
    a124:	jmp    r11
    a127:	jmp    0x28b6
    a12c:	nop    DWORD PTR [rax+0x0]
    a130:	sub    rsp,0x150
    a137:	mov    r11,QWORD PTR [r12+0x398]
    a13f:	mov    QWORD PTR [rsp],r11
    a143:	cmp    DWORD PTR [r12+0x310],0x0
    a14c:	je     0xa1d7
    a152:	push   rdx
    a153:	push   rsi
    a154:	push   r10
    a156:	push   r11
    a158:	mov    rdx,QWORD PTR [rsp+0x20]
    a15d:	mov    r10d,edx
    a160:	and    r10d,0xc000
    a167:	shl    r10d,0x10
    a16b:	mov    r11d,edx
    a16e:	and    r11d,0x100
    a175:	shl    r11d,0x15
    a179:	or     r10d,r11d
    a17c:	and    edx,0x1
    a17f:	shl    edx,0x1c
    a182:	or     r10d,edx
    a185:	btc    r10,0x1d
    a18a:	mov    r11d,0xf0000000
    a190:	and    r11,r10
    a193:	movabs rsi,0xffffffff0fffffff
    a19d:	and    rbx,rsi
    a1a0:	or     rbx,r11
    a1a3:	pop    r11
    a1a5:	pop    r10
    a1a7:	pop    rsi
    a1a8:	pop    rdx
    a1a9:	mov    QWORD PTR [r12+0x108],rbx
    a1b1:	mov    eax,0x410474
    a1b6:	mov    QWORD PTR [r12+0x100],rax
    a1be:	add    rsp,0x150
    a1c5:	mov    eax,0x3
    a1ca:	movabs r11,0x63ec266e1ca0
    a1d4:	jmp    r11
    a1d7:	jmp    0x2a28
    a1dc:	nop    DWORD PTR [rax+0x0]
    a1e0:	sub    rsp,0x150
    a1e7:	mov    r11,QWORD PTR [r12+0x398]
    a1ef:	mov    QWORD PTR [rsp],r11
    a1f3:	cmp    DWORD PTR [r12+0x310],0x0
    a1fc:	je     0xa287
    a202:	push   rdx
    a203:	push   rsi
    a204:	push   r10
    a206:	push   r11
    a208:	mov    rdx,QWORD PTR [rsp+0x20]
    a20d:	mov    r10d,edx
    a210:	and    r10d,0xc000
    a217:	shl    r10d,0x10
    a21b:	mov    r11d,edx
    a21e:	and    r11d,0x100
    a225:	shl    r11d,0x15
    a229:	or     r10d,r11d
    a22c:	and    edx,0x1
    a22f:	shl    edx,0x1c
    a232:	or     r10d,edx
    a235:	btc    r10,0x1d
    a23a:	mov    r11d,0xf0000000
    a240:	and    r11,r10
    a243:	movabs rsi,0xffffffff0fffffff
    a24d:	and    rbx,rsi
    a250:	or     rbx,r11
    a253:	pop    r11
    a255:	pop    r10
    a257:	pop    rsi
    a258:	pop    rdx
    a259:	mov    QWORD PTR [r12+0x108],rbx
    a261:	mov    eax,0x410490
    a266:	mov    QWORD PTR [r12+0x100],rax
    a26e:	add    rsp,0x150
    a275:	mov    eax,0x3
    a27a:	movabs r11,0x63ec266e1ca0
    a284:	jmp    r11
    a287:	jmp    0x2b81
    a28c:	nop    DWORD PTR [rax+0x0]
    a290:	(bad)
    a291:	(bad)
    a292:	(bad)
    a293:	(bad)
    a294:	(bad)
    a295:	(bad)
    a296:	(bad)
    a297:	jg     0xa298
    a299:	(bad)
    a29a:	(bad)
    a29b:	(bad)
    a29c:	(bad)
    a29d:	(bad)
    a29e:	(bad)
    a29f:	jg     0xa2a1
    a2a1:	add    BYTE PTR [rax],al
    a2a3:	add    BYTE PTR [rax],al
    a2a5:	add    BYTE PTR [rax],dl
    a2a7:	add    BYTE PTR [rax],al
    a2a9:	add    BYTE PTR [rax],al
    a2ab:	add    BYTE PTR [rax],al
    a2ad:	add    BYTE PTR [rax],dl
	...
