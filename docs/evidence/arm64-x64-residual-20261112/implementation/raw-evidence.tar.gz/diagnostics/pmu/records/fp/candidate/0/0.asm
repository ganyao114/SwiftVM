
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/fp/candidate/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x150
   7:	mov    r11,QWORD PTR [r12+0x398]
   f:	mov    QWORD PTR [rsp],r11
  13:	cmp    DWORD PTR [r12+0x310],0x0
  1c:	je     0xa7
  22:	push   rdx
  23:	push   rsi
  24:	push   r10
  26:	push   r11
  28:	mov    rdx,QWORD PTR [rsp+0x20]
  2d:	mov    r10d,edx
  30:	and    r10d,0xc000
  37:	shl    r10d,0x10
  3b:	mov    r11d,edx
  3e:	and    r11d,0x100
  45:	shl    r11d,0x15
  49:	or     r10d,r11d
  4c:	and    edx,0x1
  4f:	shl    edx,0x1c
  52:	or     r10d,edx
  55:	btc    r10,0x1d
  5a:	mov    r11d,0xf0000000
  60:	and    r11,r10
  63:	movabs rsi,0xffffffff0fffffff
  6d:	and    rbx,rsi
  70:	or     rbx,r11
  73:	pop    r11
  75:	pop    r10
  77:	pop    rsi
  78:	pop    rdx
  79:	mov    QWORD PTR [r12+0x108],rbx
  81:	mov    eax,0x410028
  86:	mov    QWORD PTR [r12+0x100],rax
  8e:	add    rsp,0x150
  95:	mov    eax,0x3
  9a:	movabs r11,0x6312a3e11ca0
  a4:	jmp    r11
  a7:	mov    r13d,0x4240
  ad:	mov    r14d,0xf
  b3:	and    r14d,0xffff
  ba:	mov    rax,r13
  bd:	movabs rcx,0xffffffff0000ffff
  c7:	and    rax,rcx
  ca:	mov    rdx,r14
  cd:	shl    rdx,0x10
  d1:	mov    ecx,0xffff0000
  d6:	and    rdx,rcx
  d9:	or     rax,rdx
  dc:	mov    r15,rax
  df:	mov    QWORD PTR [r12+0x8],r15
  e4:	mov    r13d,0x420060
  ea:	mov    QWORD PTR [r12+0x20],r13
  ef:	mov    r13d,0x0
  f5:	mov    QWORD PTR [r12],r13
  f9:	mov    r13d,0x0
  ff:	movabs r14,0x3ff0000000000000
 109:	mov    QWORD PTR [r12+0x110],r14
 111:	mov    QWORD PTR [r12+0x118],r13
 119:	mov    r13d,0x0
 11f:	movabs r14,0x3ff8000000000000
 129:	mov    QWORD PTR [r12+0x120],r14
 131:	mov    QWORD PTR [r12+0x128],r13
 139:	jmp    0x13e
 13e:	movdqu xmm2,XMMWORD PTR [r12+0x110]
 148:	movdqu xmm3,XMMWORD PTR [r12+0x120]
 152:	movdqa xmm0,xmm2
 156:	movdqa xmm1,xmm3
 15a:	movq   xmm0,xmm0
 15e:	movq   xmm1,xmm1
 162:	addsd  xmm0,xmm1
 166:	movdqa xmm14,xmm0
 16b:	movdqu xmm15,XMMWORD PTR [rip+0x45c]        # 0x5d0
 174:	pand   xmm14,xmm15
 179:	movdqu xmm15,XMMWORD PTR [rip+0x45e]        # 0x5e0
 182:	pcmpeqq xmm14,xmm15
 188:	movdqa xmm15,xmm0
 18d:	cmpunordpd xmm15,xmm0
 193:	por    xmm14,xmm15
 198:	pmovmskb ecx,xmm14
 19d:	jrcxz  0x1a4
 19f:	jmp    0x24e
 1a4:	movdqa xmm4,xmm0
 1a8:	movdqu XMMWORD PTR [r12+0x110],xmm4
 1b2:	mov    r13,QWORD PTR [r12+0x8]
 1b7:	sub    r13,0x1
 1bb:	mov    QWORD PTR [r12+0x8],r13
 1c0:	mov    rcx,QWORD PTR [r12+0x380]
 1c8:	jrcxz  0x1cf
 1ca:	jmp    0x34d
 1cf:	jne    0x13e
 1d5:	mov    r11,rax
 1d8:	lahf
 1d9:	seto   al
 1dc:	mov    WORD PTR [rsp],ax
 1e0:	mov    rax,r11
 1e3:	jmp    0x1e8
 1e8:	mov    r13,QWORD PTR [r12+0x20]
 1ed:	mov    r14,QWORD PTR [r12+0x110]
 1f5:	mov    QWORD PTR [r13+0x0],r14
 1f9:	mov    r13d,0x0
 1ff:	mov    DWORD PTR [r12+0x32c],r13d
 207:	mov    rcx,QWORD PTR [r12+0x380]
 20f:	jrcxz  0x216
 211:	jmp    0x3e1
 216:	mov    r13,QWORD PTR [r12+0xf0]
 21e:	mov    QWORD PTR [r12+0x100],r13
 226:	mov    r11,QWORD PTR [rsp]
 22a:	mov    QWORD PTR [r12+0x398],r11
 232:	mov    rdi,QWORD PTR [r12+0x100]
 23a:	add    rsp,0x150
 241:	movabs r11,0x6312a3e11940
 24b:	jmp    r11
 24e:	movdqa xmm0,xmm2
 252:	movdqa xmm1,xmm3
 256:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 25f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 268:	call   0x280
 26d:	jmp    0x1a4
 272:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
 280:	sub    rsp,0x8
 284:	mov    QWORD PTR [r12+0x378],0x3
 290:	movdqu XMMWORD PTR [rsp+0x20],xmm2
 296:	movdqu XMMWORD PTR [rsp+0x30],xmm3
 29c:	mov    QWORD PTR [r12+0x108],rbx
 2a4:	stmxcsr DWORD PTR [r12-0x28]
 2aa:	mov    r10d,DWORD PTR [r12-0x28]
 2af:	test   r10d,0x3f
 2b6:	je     0x2db
 2bc:	mov    r11d,r10d
 2bf:	shr    r10d,1
 2c2:	and    r10d,0x1e
 2c6:	and    r11d,0x1
 2ca:	or     r10d,r11d
 2cd:	or     DWORD PTR [r12+0x314],r10d
 2d5:	and    DWORD PTR [r12-0x28],0xffffffc0
 2db:	ldmxcsr DWORD PTR [r12-0x38]
 2e1:	lea    rdi,[rsp+0x110]
 2e9:	lea    rsi,[rsp+0xf0]
 2f1:	lea    rdx,[rsp+0x100]
 2f9:	mov    ecx,0xc
 2fe:	mov    r8d,0x0
 304:	lea    r9,[r12+0x314]
 30c:	movabs r11,0x6312a3c78650
 316:	call   r11
 319:	ldmxcsr DWORD PTR [r12-0x28]
 31f:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
 325:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
 32b:	mov    rbx,QWORD PTR [r12+0x108]
 333:	mov    QWORD PTR [r12+0x378],0x2
 33f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
 348:	add    rsp,0x8
 34c:	ret
 34d:	mov    eax,0x41004c
 352:	mov    QWORD PTR [r12+0x100],rax
 35a:	push   rdx
 35b:	push   rsi
 35c:	push   r10
 35e:	push   r11
 360:	mov    r11,rax
 363:	lahf
 364:	seto   al
 367:	mov    WORD PTR [rsp+0x20],ax
 36c:	mov    rax,r11
 36f:	mov    rdx,QWORD PTR [rsp+0x20]
 374:	mov    r10d,edx
 377:	and    r10d,0xc000
 37e:	shl    r10d,0x10
 382:	mov    r11d,edx
 385:	and    r11d,0x100
 38c:	shl    r11d,0x15
 390:	or     r10d,r11d
 393:	and    edx,0x1
 396:	shl    edx,0x1c
 399:	or     r10d,edx
 39c:	btc    r10,0x1d
 3a1:	mov    r11d,0xf0000000
 3a7:	and    r11,r10
 3aa:	movabs rsi,0xffffffff0fffffff
 3b4:	and    rbx,rsi
 3b7:	or     rbx,r11
 3ba:	pop    r11
 3bc:	pop    r10
 3be:	pop    rsi
 3bf:	pop    rdx
 3c0:	mov    QWORD PTR [r12+0x108],rbx
 3c8:	add    rsp,0x150
 3cf:	mov    eax,0xc
 3d4:	movabs r11,0x6312a3e11ca0
 3de:	jmp    r11
 3e1:	mov    eax,0x410054
 3e6:	mov    QWORD PTR [r12+0x100],rax
 3ee:	push   rdx
 3ef:	push   rsi
 3f0:	push   r10
 3f2:	push   r11
 3f4:	mov    rdx,QWORD PTR [rsp+0x20]
 3f9:	mov    r10d,edx
 3fc:	and    r10d,0xc000
 403:	shl    r10d,0x10
 407:	mov    r11d,edx
 40a:	and    r11d,0x100
 411:	shl    r11d,0x15
 415:	or     r10d,r11d
 418:	and    edx,0x1
 41b:	shl    edx,0x1c
 41e:	or     r10d,edx
 421:	btc    r10,0x1d
 426:	mov    r11d,0xf0000000
 42c:	and    r11,r10
 42f:	movabs rsi,0xffffffff0fffffff
 439:	and    rbx,rsi
 43c:	or     rbx,r11
 43f:	pop    r11
 441:	pop    r10
 443:	pop    rsi
 444:	pop    rdx
 445:	mov    QWORD PTR [r12+0x108],rbx
 44d:	add    rsp,0x150
 454:	mov    eax,0xc
 459:	movabs r11,0x6312a3e11ca0
 463:	jmp    r11
 466:	data16 nop WORD PTR [rax+rax*1+0x0]
 470:	sub    rsp,0x150
 477:	mov    r11,QWORD PTR [r12+0x398]
 47f:	mov    QWORD PTR [rsp],r11
 483:	cmp    DWORD PTR [r12+0x310],0x0
 48c:	je     0x517
 492:	push   rdx
 493:	push   rsi
 494:	push   r10
 496:	push   r11
 498:	mov    rdx,QWORD PTR [rsp+0x20]
 49d:	mov    r10d,edx
 4a0:	and    r10d,0xc000
 4a7:	shl    r10d,0x10
 4ab:	mov    r11d,edx
 4ae:	and    r11d,0x100
 4b5:	shl    r11d,0x15
 4b9:	or     r10d,r11d
 4bc:	and    edx,0x1
 4bf:	shl    edx,0x1c
 4c2:	or     r10d,edx
 4c5:	btc    r10,0x1d
 4ca:	mov    r11d,0xf0000000
 4d0:	and    r11,r10
 4d3:	movabs rsi,0xffffffff0fffffff
 4dd:	and    rbx,rsi
 4e0:	or     rbx,r11
 4e3:	pop    r11
 4e5:	pop    r10
 4e7:	pop    rsi
 4e8:	pop    rdx
 4e9:	mov    QWORD PTR [r12+0x108],rbx
 4f1:	mov    eax,0x410044
 4f6:	mov    QWORD PTR [r12+0x100],rax
 4fe:	add    rsp,0x150
 505:	mov    eax,0x3
 50a:	movabs r11,0x6312a3e11ca0
 514:	jmp    r11
 517:	jmp    0x13e
 51c:	nop    DWORD PTR [rax+0x0]
 520:	sub    rsp,0x150
 527:	mov    r11,QWORD PTR [r12+0x398]
 52f:	mov    QWORD PTR [rsp],r11
 533:	cmp    DWORD PTR [r12+0x310],0x0
 53c:	je     0x5c7
 542:	push   rdx
 543:	push   rsi
 544:	push   r10
 546:	push   r11
 548:	mov    rdx,QWORD PTR [rsp+0x20]
 54d:	mov    r10d,edx
 550:	and    r10d,0xc000
 557:	shl    r10d,0x10
 55b:	mov    r11d,edx
 55e:	and    r11d,0x100
 565:	shl    r11d,0x15
 569:	or     r10d,r11d
 56c:	and    edx,0x1
 56f:	shl    edx,0x1c
 572:	or     r10d,edx
 575:	btc    r10,0x1d
 57a:	mov    r11d,0xf0000000
 580:	and    r11,r10
 583:	movabs rsi,0xffffffff0fffffff
 58d:	and    rbx,rsi
 590:	or     rbx,r11
 593:	pop    r11
 595:	pop    r10
 597:	pop    rsi
 598:	pop    rdx
 599:	mov    QWORD PTR [r12+0x108],rbx
 5a1:	mov    eax,0x410050
 5a6:	mov    QWORD PTR [r12+0x100],rax
 5ae:	add    rsp,0x150
 5b5:	mov    eax,0x3
 5ba:	movabs r11,0x6312a3e11ca0
 5c4:	jmp    r11
 5c7:	jmp    0x1e8
 5cc:	nop    DWORD PTR [rax+0x0]
 5d0:	(bad)
 5d1:	(bad)
 5d2:	(bad)
 5d3:	(bad)
 5d4:	(bad)
 5d5:	(bad)
 5d6:	(bad)
 5d7:	jg     0x5d8
 5d9:	(bad)
 5da:	(bad)
 5db:	(bad)
 5dc:	(bad)
 5dd:	(bad)
 5de:	(bad)
 5df:	jg     0x5e1
 5e1:	add    BYTE PTR [rax],al
 5e3:	add    BYTE PTR [rax],al
 5e5:	add    BYTE PTR [rax],dl
 5e7:	add    BYTE PTR [rax],al
 5e9:	add    BYTE PTR [rax],al
 5eb:	add    BYTE PTR [rax],al
 5ed:	add    BYTE PTR [rax],dl
	...
