00007c5024bce69b  nop [rax+rax*1], eax
00007c5024bce6a0  mov qword ptr [r15+0x20], 0x420080
00007c5024bce6a8  mov qword ptr [r15], 0x00
00007c5024bce6af  vmovaps xmm1, [0x00007C50247FE010]
00007c5024bce6b7  movq xmm1, xmm1
00007c5024bce6bb  vmovaps xmm15, [0x00007C50247FE020]
00007c5024bce6c3  movq xmm15, xmm15
00007c5024bce6c8  movaps [r15+0x120], xmm15
00007c5024bce6d0  movq rax, xmm1
00007c5024bce6d5  movq r14, xmm15
00007c5024bce6da  vmovq xmm1, rax
00007c5024bce6df  vmovq xmm14, r14
00007c5024bce6e4  movaps xmm13, xmm1
00007c5024bce6e8  addsd xmm13, xmm14
00007c5024bce6ed  ucomisd xmm13, xmm13
00007c5024bce6f2  jp 0x00007C5024BCE8CC
00007c5024bce6f8  movq xmm13, xmm13
00007c5024bce6fd  movq rax, xmm13
00007c5024bce702  movq r14, xmm15
00007c5024bce707  vmovq xmm1, rax
00007c5024bce70c  vmovq xmm14, r14
00007c5024bce711  movaps xmm13, xmm1
00007c5024bce715  addsd xmm13, xmm14
00007c5024bce71a  ucomisd xmm13, xmm13
00007c5024bce71f  jp 0x00007C5024BCE914
00007c5024bce725  movq xmm13, xmm13
00007c5024bce72a  movq rax, xmm13
00007c5024bce72f  movq r14, xmm15
00007c5024bce734  vmovq xmm1, rax
00007c5024bce739  vmovq xmm14, r14
00007c5024bce73e  movaps xmm13, xmm1
00007c5024bce742  addsd xmm13, xmm14
00007c5024bce747  ucomisd xmm13, xmm13
00007c5024bce74c  jp 0x00007C5024BCE95C
00007c5024bce752  movq xmm13, xmm13
00007c5024bce757  movq rax, xmm13
00007c5024bce75c  movq r14, xmm15
00007c5024bce761  vmovq xmm1, rax
00007c5024bce766  vmovq xmm14, r14
00007c5024bce76b  movaps xmm13, xmm1
00007c5024bce76f  addsd xmm13, xmm14
00007c5024bce774  ucomisd xmm13, xmm13
00007c5024bce779  jp 0x00007C5024BCE9A4
00007c5024bce77f  movq xmm13, xmm13
00007c5024bce784  movq rax, xmm13
00007c5024bce789  movq r14, xmm15
00007c5024bce78e  vmovq xmm1, rax
00007c5024bce793  vmovq xmm14, r14
00007c5024bce798  movaps xmm13, xmm1
00007c5024bce79c  addsd xmm13, xmm14
00007c5024bce7a1  ucomisd xmm13, xmm13
00007c5024bce7a6  jp 0x00007C5024BCE9EC
00007c5024bce7ac  movq xmm13, xmm13
00007c5024bce7b1  movq rax, xmm13
00007c5024bce7b6  movq r14, xmm15
00007c5024bce7bb  vmovq xmm1, rax
00007c5024bce7c0  vmovq xmm14, r14
00007c5024bce7c5  movaps xmm13, xmm1
00007c5024bce7c9  addsd xmm13, xmm14
00007c5024bce7ce  ucomisd xmm13, xmm13
00007c5024bce7d3  jp 0x00007C5024BCEA34
00007c5024bce7d9  movq xmm13, xmm13
00007c5024bce7de  movq rax, xmm13
00007c5024bce7e3  movq r14, xmm15
00007c5024bce7e8  vmovq xmm1, rax
00007c5024bce7ed  vmovq xmm14, r14
00007c5024bce7f2  movaps xmm13, xmm1
00007c5024bce7f6  addsd xmm13, xmm14
00007c5024bce7fb  ucomisd xmm13, xmm13
00007c5024bce800  jp 0x00007C5024BCEA7C
00007c5024bce806  movq xmm13, xmm13
00007c5024bce80b  movq rax, xmm13
00007c5024bce810  movq r14, xmm15
00007c5024bce815  vmovq xmm1, rax
00007c5024bce81a  vmovq xmm15, r14
00007c5024bce81f  movaps xmm14, xmm1
00007c5024bce823  addsd xmm14, xmm15
00007c5024bce828  ucomisd xmm14, xmm14
00007c5024bce82d  jp 0x00007C5024BCEAC4
00007c5024bce833  movq xmm14, xmm14
00007c5024bce838  movaps [r15+0x110], xmm14
00007c5024bce840  xor eax, eax
00007c5024bce842  mov r14d, 0x1E848
00007c5024bce848  mov r12d, 0x01
00007c5024bce84e  sub r14, r12
00007c5024bce851  cmc
00007c5024bce852  lahf
00007c5024bce853  seto al
00007c5024bce856  mov [r15+0x108], eax
00007c5024bce85d  mov [r15+0x08], r14
00007c5024bce861  mov eax, [r15+0x108]
00007c5024bce868  sahf
00007c5024bce869  jnz 0x00007C5024BCE89B
00007c5024bce86b  cmp dword ptr [r15+0x318], 0x00
00007c5024bce873  jz 0x00007C5024BCEF70
00007c5024bce879  nop [rax+rax*1], ax
00007c5024bce882  nop [rax+rax*1], eax
00007c5024bce88a  mov eax, 0x41006C
00007c5024bce88f  mov [r15+0x100], rax
00007c5024bce896  jmp 0x00007C50249FE110
00007c5024bce89b  cmp dword ptr [r15+0x318], 0x00
00007c5024bce8a3  jz 0x00007C5024BCEB10
00007c5024bce8a9  nop [rax+rax*1], ax
00007c5024bce8b2  nop [rax+rax*1], eax
00007c5024bce8ba  mov eax, 0x410044
00007c5024bce8bf  mov [r15+0x100], rax
00007c5024bce8c6  jmp 0x00007C50249FE110
00007c5024bce8cb  int3
00007c5024bce8cc  ucomisd xmm1, xmm14
00007c5024bce8d1  jp 0x00007C5024BCE8E0
00007c5024bce8d3  movaps xmm13, [0x00007C50247FE030]
00007c5024bce8db  jmp 0x00007C5024BCE6F8
00007c5024bce8e0  vxorps xmm0, xmm1, xmm14
00007c5024bce8e5  pextrw eax, xmm0, 0x03
00007c5024bce8ea  and eax, 0x7FF8
00007c5024bce8ef  cmp eax, 0x08
00007c5024bce8f2  jnz 0x00007C5024BCE6F8
00007c5024bce8f8  movq rax, xmm14
00007c5024bce8fd  shl rax, 0x0D
00007c5024bce901  jbe 0x00007C5024BCE6F8
00007c5024bce907  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bce90f  jmp 0x00007C5024BCE6F8
00007c5024bce914  ucomisd xmm1, xmm14
00007c5024bce919  jp 0x00007C5024BCE928
00007c5024bce91b  movaps xmm13, [0x00007C50247FE030]
00007c5024bce923  jmp 0x00007C5024BCE725
00007c5024bce928  vxorps xmm0, xmm1, xmm14
00007c5024bce92d  pextrw eax, xmm0, 0x03
00007c5024bce932  and eax, 0x7FF8
00007c5024bce937  cmp eax, 0x08
00007c5024bce93a  jnz 0x00007C5024BCE725
00007c5024bce940  movq rax, xmm14
00007c5024bce945  shl rax, 0x0D
00007c5024bce949  jbe 0x00007C5024BCE725
00007c5024bce94f  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bce957  jmp 0x00007C5024BCE725
00007c5024bce95c  ucomisd xmm1, xmm14
00007c5024bce961  jp 0x00007C5024BCE970
00007c5024bce963  movaps xmm13, [0x00007C50247FE030]
00007c5024bce96b  jmp 0x00007C5024BCE752
00007c5024bce970  vxorps xmm0, xmm1, xmm14
00007c5024bce975  pextrw eax, xmm0, 0x03
00007c5024bce97a  and eax, 0x7FF8
00007c5024bce97f  cmp eax, 0x08
00007c5024bce982  jnz 0x00007C5024BCE752
00007c5024bce988  movq rax, xmm14
00007c5024bce98d  shl rax, 0x0D
00007c5024bce991  jbe 0x00007C5024BCE752
00007c5024bce997  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bce99f  jmp 0x00007C5024BCE752
00007c5024bce9a4  ucomisd xmm1, xmm14
00007c5024bce9a9  jp 0x00007C5024BCE9B8
00007c5024bce9ab  movaps xmm13, [0x00007C50247FE030]
00007c5024bce9b3  jmp 0x00007C5024BCE77F
00007c5024bce9b8  vxorps xmm0, xmm1, xmm14
00007c5024bce9bd  pextrw eax, xmm0, 0x03
00007c5024bce9c2  and eax, 0x7FF8
00007c5024bce9c7  cmp eax, 0x08
00007c5024bce9ca  jnz 0x00007C5024BCE77F
00007c5024bce9d0  movq rax, xmm14
00007c5024bce9d5  shl rax, 0x0D
00007c5024bce9d9  jbe 0x00007C5024BCE77F
00007c5024bce9df  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bce9e7  jmp 0x00007C5024BCE77F
00007c5024bce9ec  ucomisd xmm1, xmm14
00007c5024bce9f1  jp 0x00007C5024BCEA00
00007c5024bce9f3  movaps xmm13, [0x00007C50247FE030]
00007c5024bce9fb  jmp 0x00007C5024BCE7AC
00007c5024bcea00  vxorps xmm0, xmm1, xmm14
00007c5024bcea05  pextrw eax, xmm0, 0x03
00007c5024bcea0a  and eax, 0x7FF8
00007c5024bcea0f  cmp eax, 0x08
00007c5024bcea12  jnz 0x00007C5024BCE7AC
00007c5024bcea18  movq rax, xmm14
00007c5024bcea1d  shl rax, 0x0D
00007c5024bcea21  jbe 0x00007C5024BCE7AC
00007c5024bcea27  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bcea2f  jmp 0x00007C5024BCE7AC
00007c5024bcea34  ucomisd xmm1, xmm14
00007c5024bcea39  jp 0x00007C5024BCEA48
00007c5024bcea3b  movaps xmm13, [0x00007C50247FE030]
00007c5024bcea43  jmp 0x00007C5024BCE7D9
00007c5024bcea48  vxorps xmm0, xmm1, xmm14
00007c5024bcea4d  pextrw eax, xmm0, 0x03
00007c5024bcea52  and eax, 0x7FF8
00007c5024bcea57  cmp eax, 0x08
00007c5024bcea5a  jnz 0x00007C5024BCE7D9
00007c5024bcea60  movq rax, xmm14
00007c5024bcea65  shl rax, 0x0D
00007c5024bcea69  jbe 0x00007C5024BCE7D9
00007c5024bcea6f  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bcea77  jmp 0x00007C5024BCE7D9
00007c5024bcea7c  ucomisd xmm1, xmm14
00007c5024bcea81  jp 0x00007C5024BCEA90
00007c5024bcea83  movaps xmm13, [0x00007C50247FE030]
00007c5024bcea8b  jmp 0x00007C5024BCE806
00007c5024bcea90  vxorps xmm0, xmm1, xmm14
00007c5024bcea95  pextrw eax, xmm0, 0x03
00007c5024bcea9a  and eax, 0x7FF8
00007c5024bcea9f  cmp eax, 0x08
00007c5024bceaa2  jnz 0x00007C5024BCE806
00007c5024bceaa8  movq rax, xmm14
00007c5024bceaad  shl rax, 0x0D
00007c5024bceab1  jbe 0x00007C5024BCE806
00007c5024bceab7  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bceabf  jmp 0x00007C5024BCE806
00007c5024bceac4  ucomisd xmm1, xmm15
00007c5024bceac9  jp 0x00007C5024BCEAD8
00007c5024bceacb  movaps xmm14, [0x00007C50247FE030]
00007c5024bcead3  jmp 0x00007C5024BCE833
00007c5024bcead8  vxorps xmm0, xmm1, xmm15
00007c5024bceadd  pextrw eax, xmm0, 0x03
00007c5024bceae2  and eax, 0x7FF8
00007c5024bceae7  cmp eax, 0x08
00007c5024bceaea  jnz 0x00007C5024BCE833
00007c5024bceaf0  movq rax, xmm15
00007c5024bceaf5  shl rax, 0x0D
00007c5024bceaf9  jbe 0x00007C5024BCE833
00007c5024bceaff  vorps xmm14, xmm15, [0x00007C50247FE040]
00007c5024bceb07  jmp 0x00007C5024BCE833
00007c5024bceb0c  int3
00007c5024bceb0d  nop [rax], eax
00007c5024bceb10  movaps xmm1, [r15+0x110]
00007c5024bceb18  movq rax, xmm1
00007c5024bceb1d  movaps xmm1, [r15+0x120]
00007c5024bceb25  movq r14, xmm1
00007c5024bceb2a  vmovq xmm15, rax
00007c5024bceb2f  vmovq xmm14, r14
00007c5024bceb34  movaps xmm13, xmm15
00007c5024bceb38  addsd xmm13, xmm14
00007c5024bceb3d  ucomisd xmm13, xmm13
00007c5024bceb42  jp 0x00007C5024BCED24
00007c5024bceb48  movq xmm13, xmm13
00007c5024bceb4d  movq rax, xmm13
00007c5024bceb52  movq r14, xmm1
00007c5024bceb57  vmovq xmm15, rax
00007c5024bceb5c  vmovq xmm14, r14
00007c5024bceb61  movaps xmm13, xmm15
00007c5024bceb65  addsd xmm13, xmm14
00007c5024bceb6a  ucomisd xmm13, xmm13
00007c5024bceb6f  jp 0x00007C5024BCED6C
00007c5024bceb75  movq xmm13, xmm13
00007c5024bceb7a  movq rax, xmm13
00007c5024bceb7f  movq r14, xmm1
00007c5024bceb84  vmovq xmm15, rax
00007c5024bceb89  vmovq xmm14, r14
00007c5024bceb8e  movaps xmm13, xmm15
00007c5024bceb92  addsd xmm13, xmm14
00007c5024bceb97  ucomisd xmm13, xmm13
00007c5024bceb9c  jp 0x00007C5024BCEDB4
00007c5024bceba2  movq xmm13, xmm13
00007c5024bceba7  movq rax, xmm13
00007c5024bcebac  movq r14, xmm1
00007c5024bcebb1  vmovq xmm15, rax
00007c5024bcebb6  vmovq xmm14, r14
00007c5024bcebbb  movaps xmm13, xmm15
00007c5024bcebbf  addsd xmm13, xmm14
00007c5024bcebc4  ucomisd xmm13, xmm13
00007c5024bcebc9  jp 0x00007C5024BCEDFC
00007c5024bcebcf  movq xmm13, xmm13
00007c5024bcebd4  movq rax, xmm13
00007c5024bcebd9  movq r14, xmm1
00007c5024bcebde  vmovq xmm15, rax
00007c5024bcebe3  vmovq xmm14, r14
00007c5024bcebe8  movaps xmm13, xmm15
00007c5024bcebec  addsd xmm13, xmm14
00007c5024bcebf1  ucomisd xmm13, xmm13
00007c5024bcebf6  jp 0x00007C5024BCEE44
00007c5024bcebfc  movq xmm13, xmm13
00007c5024bcec01  movq rax, xmm13
00007c5024bcec06  movq r14, xmm1
00007c5024bcec0b  vmovq xmm15, rax
00007c5024bcec10  vmovq xmm14, r14
00007c5024bcec15  movaps xmm13, xmm15
00007c5024bcec19  addsd xmm13, xmm14
00007c5024bcec1e  ucomisd xmm13, xmm13
00007c5024bcec23  jp 0x00007C5024BCEE8C
00007c5024bcec29  movq xmm13, xmm13
00007c5024bcec2e  movq rax, xmm13
00007c5024bcec33  movq r14, xmm1
00007c5024bcec38  vmovq xmm15, rax
00007c5024bcec3d  vmovq xmm14, r14
00007c5024bcec42  movaps xmm13, xmm15
00007c5024bcec46  addsd xmm13, xmm14
00007c5024bcec4b  ucomisd xmm13, xmm13
00007c5024bcec50  jp 0x00007C5024BCEED4
00007c5024bcec56  movq xmm13, xmm13
00007c5024bcec5b  movq rax, xmm13
00007c5024bcec60  movq r14, xmm1
00007c5024bcec65  vmovq xmm1, rax
00007c5024bcec6a  vmovq xmm15, r14
00007c5024bcec6f  movaps xmm14, xmm1
00007c5024bcec73  addsd xmm14, xmm15
00007c5024bcec78  ucomisd xmm14, xmm14
00007c5024bcec7d  jp 0x00007C5024BCEF1C
00007c5024bcec83  movq xmm14, xmm14
00007c5024bcec88  movaps [r15+0x110], xmm14
00007c5024bcec90  mov rax, [r15+0x08]
00007c5024bcec94  mov [rsp+0x10], rax
00007c5024bcec99  xor eax, eax
00007c5024bcec9b  mov r14, [rsp+0x10]
00007c5024bceca0  mov r12d, 0x01
00007c5024bceca6  sub r14, r12
00007c5024bceca9  cmc
00007c5024bcecaa  lahf
00007c5024bcecab  seto al
00007c5024bcecae  mov [r15+0x108], eax
00007c5024bcecb5  mov [r15+0x08], r14
00007c5024bcecb9  mov eax, [r15+0x108]
00007c5024bcecc0  sahf
00007c5024bcecc1  jnz 0x00007C5024BCECF3
00007c5024bcecc3  cmp dword ptr [r15+0x318], 0x00
00007c5024bceccb  jz 0x00007C5024BCEF70
00007c5024bcecd1  nop [rax+rax*1], ax
00007c5024bcecda  nop [rax+rax*1], eax
00007c5024bcece2  mov eax, 0x41006C
00007c5024bcece7  mov [r15+0x100], rax
00007c5024bcecee  jmp 0x00007C50249FE110
00007c5024bcecf3  cmp dword ptr [r15+0x318], 0x00
00007c5024bcecfb  jz 0x00007C5024BCEB10
00007c5024bced01  nop [rax+rax*1], ax
00007c5024bced0a  nop [rax+rax*1], eax
00007c5024bced12  mov eax, 0x410044
00007c5024bced17  mov [r15+0x100], rax
00007c5024bced1e  jmp 0x00007C50249FE110
00007c5024bced23  int3
00007c5024bced24  ucomisd xmm15, xmm14
00007c5024bced29  jp 0x00007C5024BCED38
00007c5024bced2b  movaps xmm13, [0x00007C50247FE030]
00007c5024bced33  jmp 0x00007C5024BCEB48
00007c5024bced38  vxorps xmm0, xmm15, xmm14
00007c5024bced3d  pextrw eax, xmm0, 0x03
00007c5024bced42  and eax, 0x7FF8
00007c5024bced47  cmp eax, 0x08
00007c5024bced4a  jnz 0x00007C5024BCEB48
00007c5024bced50  movq rax, xmm14
00007c5024bced55  shl rax, 0x0D
00007c5024bced59  jbe 0x00007C5024BCEB48
00007c5024bced5f  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bced67  jmp 0x00007C5024BCEB48
00007c5024bced6c  ucomisd xmm15, xmm14
00007c5024bced71  jp 0x00007C5024BCED80
00007c5024bced73  movaps xmm13, [0x00007C50247FE030]
00007c5024bced7b  jmp 0x00007C5024BCEB75
00007c5024bced80  vxorps xmm0, xmm15, xmm14
00007c5024bced85  pextrw eax, xmm0, 0x03
00007c5024bced8a  and eax, 0x7FF8
00007c5024bced8f  cmp eax, 0x08
00007c5024bced92  jnz 0x00007C5024BCEB75
00007c5024bced98  movq rax, xmm14
00007c5024bced9d  shl rax, 0x0D
00007c5024bceda1  jbe 0x00007C5024BCEB75
00007c5024bceda7  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bcedaf  jmp 0x00007C5024BCEB75
00007c5024bcedb4  ucomisd xmm15, xmm14
00007c5024bcedb9  jp 0x00007C5024BCEDC8
00007c5024bcedbb  movaps xmm13, [0x00007C50247FE030]
00007c5024bcedc3  jmp 0x00007C5024BCEBA2
00007c5024bcedc8  vxorps xmm0, xmm15, xmm14
00007c5024bcedcd  pextrw eax, xmm0, 0x03
00007c5024bcedd2  and eax, 0x7FF8
00007c5024bcedd7  cmp eax, 0x08
00007c5024bcedda  jnz 0x00007C5024BCEBA2
00007c5024bcede0  movq rax, xmm14
00007c5024bcede5  shl rax, 0x0D
00007c5024bcede9  jbe 0x00007C5024BCEBA2
00007c5024bcedef  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bcedf7  jmp 0x00007C5024BCEBA2
00007c5024bcedfc  ucomisd xmm15, xmm14
00007c5024bcee01  jp 0x00007C5024BCEE10
00007c5024bcee03  movaps xmm13, [0x00007C50247FE030]
00007c5024bcee0b  jmp 0x00007C5024BCEBCF
00007c5024bcee10  vxorps xmm0, xmm15, xmm14
00007c5024bcee15  pextrw eax, xmm0, 0x03
00007c5024bcee1a  and eax, 0x7FF8
00007c5024bcee1f  cmp eax, 0x08
00007c5024bcee22  jnz 0x00007C5024BCEBCF
00007c5024bcee28  movq rax, xmm14
00007c5024bcee2d  shl rax, 0x0D
00007c5024bcee31  jbe 0x00007C5024BCEBCF
00007c5024bcee37  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bcee3f  jmp 0x00007C5024BCEBCF
00007c5024bcee44  ucomisd xmm15, xmm14
00007c5024bcee49  jp 0x00007C5024BCEE58
00007c5024bcee4b  movaps xmm13, [0x00007C50247FE030]
00007c5024bcee53  jmp 0x00007C5024BCEBFC
00007c5024bcee58  vxorps xmm0, xmm15, xmm14
00007c5024bcee5d  pextrw eax, xmm0, 0x03
00007c5024bcee62  and eax, 0x7FF8
00007c5024bcee67  cmp eax, 0x08
00007c5024bcee6a  jnz 0x00007C5024BCEBFC
00007c5024bcee70  movq rax, xmm14
00007c5024bcee75  shl rax, 0x0D
00007c5024bcee79  jbe 0x00007C5024BCEBFC
00007c5024bcee7f  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bcee87  jmp 0x00007C5024BCEBFC
00007c5024bcee8c  ucomisd xmm15, xmm14
00007c5024bcee91  jp 0x00007C5024BCEEA0
00007c5024bcee93  movaps xmm13, [0x00007C50247FE030]
00007c5024bcee9b  jmp 0x00007C5024BCEC29
00007c5024bceea0  vxorps xmm0, xmm15, xmm14
00007c5024bceea5  pextrw eax, xmm0, 0x03
00007c5024bceeaa  and eax, 0x7FF8
00007c5024bceeaf  cmp eax, 0x08
00007c5024bceeb2  jnz 0x00007C5024BCEC29
00007c5024bceeb8  movq rax, xmm14
00007c5024bceebd  shl rax, 0x0D
00007c5024bceec1  jbe 0x00007C5024BCEC29
00007c5024bceec7  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bceecf  jmp 0x00007C5024BCEC29
00007c5024bceed4  ucomisd xmm15, xmm14
00007c5024bceed9  jp 0x00007C5024BCEEE8
00007c5024bceedb  movaps xmm13, [0x00007C50247FE030]
00007c5024bceee3  jmp 0x00007C5024BCEC56
00007c5024bceee8  vxorps xmm0, xmm15, xmm14
00007c5024bceeed  pextrw eax, xmm0, 0x03
00007c5024bceef2  and eax, 0x7FF8
00007c5024bceef7  cmp eax, 0x08
00007c5024bceefa  jnz 0x00007C5024BCEC56
00007c5024bcef00  movq rax, xmm14
00007c5024bcef05  shl rax, 0x0D
00007c5024bcef09  jbe 0x00007C5024BCEC56
00007c5024bcef0f  vorps xmm13, xmm14, [0x00007C50247FE040]
00007c5024bcef17  jmp 0x00007C5024BCEC56
00007c5024bcef1c  ucomisd xmm1, xmm15
00007c5024bcef21  jp 0x00007C5024BCEF30
00007c5024bcef23  movaps xmm14, [0x00007C50247FE030]
00007c5024bcef2b  jmp 0x00007C5024BCEC83
00007c5024bcef30  vxorps xmm0, xmm1, xmm15
00007c5024bcef35  pextrw eax, xmm0, 0x03
00007c5024bcef3a  and eax, 0x7FF8
00007c5024bcef3f  cmp eax, 0x08
00007c5024bcef42  jnz 0x00007C5024BCEC83
00007c5024bcef48  movq rax, xmm15
00007c5024bcef4d  shl rax, 0x0D
00007c5024bcef51  jbe 0x00007C5024BCEC83
00007c5024bcef57  vorps xmm14, xmm15, [0x00007C50247FE040]
00007c5024bcef5f  jmp 0x00007C5024BCEC83
00007c5024bcef64  int3
00007c5024bcef65  nop [rax+rax*1], ax
00007c5024bcef6e  nop
00007c5024bcef70  mov rax, [r15+0x20]
00007c5024bcef74  movaps xmm1, [r15+0x110]
00007c5024bcef7c  movq r14, xmm1
00007c5024bcef81  mov [r13+rax*1], r14
00007c5024bcef86  mov rax, [r15+0xF0]
00007c5024bcef8d  mov [r15+0x100], rax
00007c5024bcef94  jmp 0x00007C5024BCE5C0
00007c5024bcef99  int3
00007c5024bcef9a  call 0x00007C5024A0E120
00007c5024bcef9f  jmp 0x00007C5024BCEF86
00007c5024bcefa4  int3
00007c5024bcefa5  nop [rax+rax*1], ax
00007c5024bcefae  nop
00007c5024bcefb0  mov qword ptr [r15+0x100], 0x04
00007c5024bcefbb  mov esi, 0x00
00007c5024bcefc0  mov edx, 0x09
00007c5024bcefc5  mov rdi, 0x7FFD501CA620
00007c5024bcefcf  mov rax, 0x56BCE3D81970
00007c5024bcefd9  call rax
00007c5024bcefdb  cmp dword ptr [r15+0x318], 0x00
00007c5024bcefe3  jnz 0x00007C50249FE110
00007c5024bcefe9  jmp 0x00007C50249FE0A0
00007c5024bcefee  int3
00007c5024bcefef  int3
