0000796caedce69b  nop [rax+rax*1], eax
0000796caedce6a0  vmovaps xmm1, [0x0000796CAE9FE010]
0000796caedce6a8  movq xmm1, xmm1
0000796caedce6ac  movaps [r15+0x110], xmm1
0000796caedce6b4  vmovaps xmm1, [0x0000796CAE9FE020]
0000796caedce6bc  movq xmm1, xmm1
0000796caedce6c0  movaps [r15+0x120], xmm1
0000796caedce6c8  mov eax, 0x4204C0
0000796caedce6cd  mov r14, [r13+rax*1]
0000796caedce6d2  movq xmm1, r14
0000796caedce6d7  movaps [r15+0x130], xmm1
0000796caedce6df  vmovaps xmm1, [0x0000796CAE9FE030]
0000796caedce6e7  vpbroadcastq xmm1, xmm1
0000796caedce6ec  movaps [r15+0x140], xmm1
0000796caedce6f4  mov qword ptr [r15+0x40], 0x02
0000796caedce6fc  vmovaps xmm15, [0x0000796CAE9FE040]
0000796caedce704  movq xmm15, xmm15
0000796caedce709  movaps [r15+0x150], xmm15
0000796caedce711  mov qword ptr [r15+0x58], 0x420000
0000796caedce719  vmovaps xmm15, [0x0000796CAE9FE050]
0000796caedce721  vpbroadcastq xmm15, xmm15
0000796caedce726  movaps [r15+0x160], xmm15
0000796caedce72e  mov rax, [r15+0x40]
0000796caedce732  vmovq xmm14, rax
0000796caedce737  vpbroadcastq xmm14, xmm14
0000796caedce73c  movaps [r15+0x170], xmm14
0000796caedce744  mov eax, 0x4204D0
0000796caedce749  movups xmm13, [r13+rax*1]
0000796caedce74f  mov qword ptr [r15+0x40], 0x430518
0000796caedce757  mov qword ptr [r15+0x50], 0x430720
0000796caedce75f  vpmovqd xmm12, xmm13
0000796caedce765  pxor xmm11, xmm11
0000796caedce76a  punpcklqdq xmm12, xmm11
0000796caedce76f  movaps [r15+0x210], xmm12
0000796caedce777  movq xmm12, qword ptr [r15+0x120]
0000796caedce780  movq xmm11, qword ptr [r15+0x130]
0000796caedce789  psubd xmm12, xmm11
0000796caedce78e  movq xmm12, xmm12
0000796caedce793  paddq xmm13, xmm14
0000796caedce798  movaps [r15+0x180], xmm13
0000796caedce7a0  movq xmm14, qword ptr [r15+0x150]
0000796caedce7a9  paddd xmm11, xmm14
0000796caedce7ae  movq xmm11, xmm11
0000796caedce7b3  movq xmm11, xmm11
0000796caedce7b8  movaps [r15+0x130], xmm11
0000796caedce7c0  pmovzxdq xmm12, xmm12
0000796caedce7c6  psllq xmm12, 0x00
0000796caedce7cc  movq xmm14, qword ptr [r15+0x210]
0000796caedce7d5  movq xmm13, qword ptr [r15+0x110]
0000796caedce7de  paddd xmm14, xmm13
0000796caedce7e3  movq xmm14, xmm14
0000796caedce7e8  vcvtuqq2pd xmm12, xmm12
0000796caedce7ee  pmovzxdq xmm14, xmm14
0000796caedce7f4  psllq xmm14, 0x00
0000796caedce7fa  vcvtuqq2pd xmm14, xmm14
0000796caedce800  movaps xmm13, xmm12
0000796caedce804  mulpd xmm13, xmm1
0000796caedce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000796caedce80f  ptest xmm11, xmm11
0000796caedce815  jnz 0x0000796CAEDCE8FF
0000796caedce81b  movaps [r15+0x220], xmm13
0000796caedce823  mov eax, 0x430720
0000796caedce828  movups [r13+rax*1], xmm13
0000796caedce82e  movaps xmm1, xmm14
0000796caedce832  mulpd xmm1, xmm15
0000796caedce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000796caedce83c  ptest xmm13, xmm13
0000796caedce842  jnz 0x0000796CAEDCEA4C
0000796caedce848  movaps [r15+0x210], xmm1
0000796caedce850  mov eax, 0x430518
0000796caedce855  movups [r13+rax*1], xmm1
0000796caedce85b  mov qword ptr [r15+0x48], 0x10
0000796caedce863  xor eax, eax
0000796caedce865  mov r14d, 0x10
0000796caedce86b  mov r12d, 0x200
0000796caedce871  cmp r14, r12
0000796caedce874  cmc
0000796caedce875  lahf
0000796caedce876  seto al
0000796caedce879  mov [r15+0x108], eax
0000796caedce880  mov eax, [r15+0x108]
0000796caedce887  sahf
0000796caedce888  jnz 0x0000796CAEDCE8BA
0000796caedce88a  cmp dword ptr [r15+0x318], 0x00
0000796caedce892  jz 0x0000796CAEDCEFF0
0000796caedce898  nop [rax+rax*1], ax
0000796caedce8a1  nop [rax+rax*1], eax
0000796caedce8a9  mov eax, 0x4101EC
0000796caedce8ae  mov [r15+0x100], rax
0000796caedce8b5  jmp 0x0000796CAEBFE110
0000796caedce8ba  cmp dword ptr [r15+0x318], 0x00
0000796caedce8c2  jz 0x0000796CAEDCEBA0
0000796caedce8c8  nop [rax+rax*1], ax
0000796caedce8d1  nop [rax+rax*1], eax
0000796caedce8d9  mov eax, 0x4101AC
0000796caedce8de  mov [r15+0x100], rax
0000796caedce8e5  jmp 0x0000796CAEBFE110
0000796caedce8ea  int3
0000796caedce8eb  call 0x0000796CAEC0DC20
0000796caedce8f0  jmp 0x0000796CAEDCE6D2
0000796caedce8f5  call 0x0000796CAEC0C260
0000796caedce8fa  jmp 0x0000796CAEDCE74F
0000796caedce8ff  sub rsp, 0x08
0000796caedce903  push rax
0000796caedce904  push rcx
0000796caedce905  push rdx
0000796caedce906  push rdi
0000796caedce907  push rsi
0000796caedce908  push r8
0000796caedce90a  push r9
0000796caedce90c  push r10
0000796caedce90e  push r11
0000796caedce910  sub rsp, 0xF0
0000796caedce917  vmovaps [rsp], xmm0
0000796caedce91c  vmovaps [rsp+0x10], xmm1
0000796caedce922  vmovaps [rsp+0x20], xmm2
0000796caedce928  vmovaps [rsp+0x30], xmm3
0000796caedce92e  vmovaps [rsp+0x40], xmm4
0000796caedce934  vmovaps [rsp+0x50], xmm5
0000796caedce93a  vmovaps [rsp+0x60], xmm6
0000796caedce940  vmovaps [rsp+0x70], xmm7
0000796caedce946  vmovaps [rsp+0x80], xmm8
0000796caedce94f  vmovaps [rsp+0x90], xmm9
0000796caedce958  vmovaps [rsp+0xA0], xmm10
0000796caedce961  vmovaps [rsp+0xB0], xmm11
0000796caedce96a  vmovaps [rsp+0xC0], xmm12
0000796caedce973  vmovaps [rsp+0xD0], xmm14
0000796caedce97c  vmovaps [rsp+0xE0], xmm15
0000796caedce985  sub rsp, 0x30
0000796caedce989  movaps [rsp], xmm13
0000796caedce98e  movaps [rsp+0x10], xmm12
0000796caedce994  movaps [rsp+0x20], xmm1
0000796caedce999  lea rdi, [rsp]
0000796caedce99d  mov esi, 0x00
0000796caedce9a2  mov rax, 0x56877063A530
0000796caedce9ac  call rax
0000796caedce9ae  movaps xmm13, [rsp]
0000796caedce9b3  add rsp, 0x30
0000796caedce9b7  vmovaps xmm0, [rsp]
0000796caedce9bc  vmovaps xmm1, [rsp+0x10]
0000796caedce9c2  vmovaps xmm2, [rsp+0x20]
0000796caedce9c8  vmovaps xmm3, [rsp+0x30]
0000796caedce9ce  vmovaps xmm4, [rsp+0x40]
0000796caedce9d4  vmovaps xmm5, [rsp+0x50]
0000796caedce9da  vmovaps xmm6, [rsp+0x60]
0000796caedce9e0  vmovaps xmm7, [rsp+0x70]
0000796caedce9e6  vmovaps xmm8, [rsp+0x80]
0000796caedce9ef  vmovaps xmm9, [rsp+0x90]
0000796caedce9f8  vmovaps xmm10, [rsp+0xA0]
0000796caedcea01  vmovaps xmm11, [rsp+0xB0]
0000796caedcea0a  vmovaps xmm12, [rsp+0xC0]
0000796caedcea13  vmovaps xmm14, [rsp+0xD0]
0000796caedcea1c  vmovaps xmm15, [rsp+0xE0]
0000796caedcea25  add rsp, 0xF0
0000796caedcea2c  pop r11
0000796caedcea2e  pop r10
0000796caedcea30  pop r9
0000796caedcea32  pop r8
0000796caedcea34  pop rsi
0000796caedcea35  pop rdi
0000796caedcea36  pop rdx
0000796caedcea37  pop rcx
0000796caedcea38  pop rax
0000796caedcea39  add rsp, 0x08
0000796caedcea3d  jmp 0x0000796CAEDCE81B
0000796caedcea42  call 0x0000796CAEC0C380
0000796caedcea47  jmp 0x0000796CAEDCE82E
0000796caedcea4c  sub rsp, 0x08
0000796caedcea50  push rax
0000796caedcea51  push rcx
0000796caedcea52  push rdx
0000796caedcea53  push rdi
0000796caedcea54  push rsi
0000796caedcea55  push r8
0000796caedcea57  push r9
0000796caedcea59  push r10
0000796caedcea5b  push r11
0000796caedcea5d  sub rsp, 0xF0
0000796caedcea64  vmovaps [rsp], xmm0
0000796caedcea69  vmovaps [rsp+0x10], xmm2
0000796caedcea6f  vmovaps [rsp+0x20], xmm3
0000796caedcea75  vmovaps [rsp+0x30], xmm4
0000796caedcea7b  vmovaps [rsp+0x40], xmm5
0000796caedcea81  vmovaps [rsp+0x50], xmm6
0000796caedcea87  vmovaps [rsp+0x60], xmm7
0000796caedcea8d  vmovaps [rsp+0x70], xmm8
0000796caedcea93  vmovaps [rsp+0x80], xmm9
0000796caedcea9c  vmovaps [rsp+0x90], xmm10
0000796caedceaa5  vmovaps [rsp+0xA0], xmm11
0000796caedceaae  vmovaps [rsp+0xB0], xmm12
0000796caedceab7  vmovaps [rsp+0xC0], xmm13
0000796caedceac0  vmovaps [rsp+0xD0], xmm14
0000796caedceac9  vmovaps [rsp+0xE0], xmm15
0000796caedcead2  sub rsp, 0x30
0000796caedcead6  movaps [rsp], xmm1
0000796caedceada  movaps [rsp+0x10], xmm14
0000796caedceae0  movaps [rsp+0x20], xmm15
0000796caedceae6  lea rdi, [rsp]
0000796caedceaea  mov esi, 0x00
0000796caedceaef  mov rax, 0x56877063A530
0000796caedceaf9  call rax
0000796caedceafb  movaps xmm1, [rsp]
0000796caedceaff  add rsp, 0x30
0000796caedceb03  vmovaps xmm0, [rsp]
0000796caedceb08  vmovaps xmm2, [rsp+0x10]
0000796caedceb0e  vmovaps xmm3, [rsp+0x20]
0000796caedceb14  vmovaps xmm4, [rsp+0x30]
0000796caedceb1a  vmovaps xmm5, [rsp+0x40]
0000796caedceb20  vmovaps xmm6, [rsp+0x50]
0000796caedceb26  vmovaps xmm7, [rsp+0x60]
0000796caedceb2c  vmovaps xmm8, [rsp+0x70]
0000796caedceb32  vmovaps xmm9, [rsp+0x80]
0000796caedceb3b  vmovaps xmm10, [rsp+0x90]
0000796caedceb44  vmovaps xmm11, [rsp+0xA0]
0000796caedceb4d  vmovaps xmm12, [rsp+0xB0]
0000796caedceb56  vmovaps xmm13, [rsp+0xC0]
0000796caedceb5f  vmovaps xmm14, [rsp+0xD0]
0000796caedceb68  vmovaps xmm15, [rsp+0xE0]
0000796caedceb71  add rsp, 0xF0
0000796caedceb78  pop r11
0000796caedceb7a  pop r10
0000796caedceb7c  pop r9
0000796caedceb7e  pop r8
0000796caedceb80  pop rsi
0000796caedceb81  pop rdi
0000796caedceb82  pop rdx
0000796caedceb83  pop rcx
0000796caedceb84  pop rax
0000796caedceb85  add rsp, 0x08
0000796caedceb89  jmp 0x0000796CAEDCE848
0000796caedceb8e  call 0x0000796CAEBFF540
0000796caedceb93  jmp 0x0000796CAEDCE85B
0000796caedceb98  int3
0000796caedceb99  nop [rax], eax
0000796caedceba0  movaps xmm1, [r15+0x180]
0000796caedceba8  vpmovqd xmm15, xmm1
0000796caedcebae  pxor xmm14, xmm14
0000796caedcebb3  punpcklqdq xmm15, xmm14
0000796caedcebb8  movaps [r15+0x210], xmm15
0000796caedcebc0  movq xmm15, qword ptr [r15+0x120]
0000796caedcebc9  movq xmm14, qword ptr [r15+0x130]
0000796caedcebd2  psubd xmm15, xmm14
0000796caedcebd7  movq xmm15, xmm15
0000796caedcebdc  movaps xmm13, [r15+0x170]
0000796caedcebe4  paddq xmm1, xmm13
0000796caedcebe9  movaps [r15+0x180], xmm1
0000796caedcebf1  movq xmm1, qword ptr [r15+0x150]
0000796caedcebfa  paddd xmm14, xmm1
0000796caedcebff  movq xmm14, xmm14
0000796caedcec04  movq xmm14, xmm14
0000796caedcec09  movaps [r15+0x130], xmm14
0000796caedcec11  pmovzxdq xmm15, xmm15
0000796caedcec17  psllq xmm15, 0x00
0000796caedcec1d  movq xmm1, qword ptr [r15+0x210]
0000796caedcec26  movq xmm14, qword ptr [r15+0x110]
0000796caedcec2f  paddd xmm1, xmm14
0000796caedcec34  movq xmm1, xmm1
0000796caedcec38  vcvtuqq2pd xmm15, xmm15
0000796caedcec3e  pmovzxdq xmm1, xmm1
0000796caedcec43  psllq xmm1, 0x00
0000796caedcec48  vcvtuqq2pd xmm1, xmm1
0000796caedcec4e  movaps xmm14, [r15+0x140]
0000796caedcec56  movaps xmm13, xmm15
0000796caedcec5a  mulpd xmm13, xmm14
0000796caedcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000796caedcec65  ptest xmm12, xmm12
0000796caedcec6b  jnz 0x0000796CAEDCED4E
0000796caedcec71  movaps [r15+0x220], xmm13
0000796caedcec79  mov rax, [r15+0x48]
0000796caedcec7d  mov r14, [r15+0x50]
0000796caedcec81  lea r12, [r14+rax*1]
0000796caedcec85  movups [r13+r12*1], xmm13
0000796caedcec8b  movaps xmm15, [r15+0x160]
0000796caedcec93  movaps xmm14, xmm1
0000796caedcec97  mulpd xmm14, xmm15
0000796caedcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000796caedceca2  ptest xmm13, xmm13
0000796caedceca8  jnz 0x0000796CAEDCEE9C
0000796caedcecae  movaps [r15+0x210], xmm14
0000796caedcecb6  mov r14, [r15+0x40]
0000796caedcecba  lea r12, [r14+rax*1]
0000796caedcecbe  movups [r13+r12*1], xmm14
0000796caedcecc4  lea r14, [rax+0x10]
0000796caedcecc8  mov [r15+0x48], r14
0000796caedceccc  xor eax, eax
0000796caedcecce  mov r12d, 0x200
0000796caedcecd4  cmp r14, r12
0000796caedcecd7  cmc
0000796caedcecd8  lahf
0000796caedcecd9  seto al
0000796caedcecdc  mov [r15+0x108], eax
0000796caedcece3  mov eax, [r15+0x108]
0000796caedcecea  sahf
0000796caedceceb  jnz 0x0000796CAEDCED1D
0000796caedceced  cmp dword ptr [r15+0x318], 0x00
0000796caedcecf5  jz 0x0000796CAEDCEFF0
0000796caedcecfb  nop [rax+rax*1], ax
0000796caedced04  nop [rax+rax*1], eax
0000796caedced0c  mov eax, 0x4101EC
0000796caedced11  mov [r15+0x100], rax
0000796caedced18  jmp 0x0000796CAEBFE110
0000796caedced1d  cmp dword ptr [r15+0x318], 0x00
0000796caedced25  jz 0x0000796CAEDCEBA0
0000796caedced2b  nop [rax+rax*1], ax
0000796caedced34  nop [rax+rax*1], eax
0000796caedced3c  mov eax, 0x4101AC
0000796caedced41  mov [r15+0x100], rax
0000796caedced48  jmp 0x0000796CAEBFE110
0000796caedced4d  int3
0000796caedced4e  sub rsp, 0x08
0000796caedced52  push rax
0000796caedced53  push rcx
0000796caedced54  push rdx
0000796caedced55  push rdi
0000796caedced56  push rsi
0000796caedced57  push r8
0000796caedced59  push r9
0000796caedced5b  push r10
0000796caedced5d  push r11
0000796caedced5f  sub rsp, 0xF0
0000796caedced66  vmovaps [rsp], xmm0
0000796caedced6b  vmovaps [rsp+0x10], xmm1
0000796caedced71  vmovaps [rsp+0x20], xmm2
0000796caedced77  vmovaps [rsp+0x30], xmm3
0000796caedced7d  vmovaps [rsp+0x40], xmm4
0000796caedced83  vmovaps [rsp+0x50], xmm5
0000796caedced89  vmovaps [rsp+0x60], xmm6
0000796caedced8f  vmovaps [rsp+0x70], xmm7
0000796caedced95  vmovaps [rsp+0x80], xmm8
0000796caedced9e  vmovaps [rsp+0x90], xmm9
0000796caedceda7  vmovaps [rsp+0xA0], xmm10
0000796caedcedb0  vmovaps [rsp+0xB0], xmm11
0000796caedcedb9  vmovaps [rsp+0xC0], xmm12
0000796caedcedc2  vmovaps [rsp+0xD0], xmm14
0000796caedcedcb  vmovaps [rsp+0xE0], xmm15
0000796caedcedd4  sub rsp, 0x30
0000796caedcedd8  movaps [rsp], xmm13
0000796caedceddd  movaps [rsp+0x10], xmm15
0000796caedcede3  movaps [rsp+0x20], xmm14
0000796caedcede9  lea rdi, [rsp]
0000796caedceded  mov esi, 0x00
0000796caedcedf2  mov rax, 0x56877063A530
0000796caedcedfc  call rax
0000796caedcedfe  movaps xmm13, [rsp]
0000796caedcee03  add rsp, 0x30
0000796caedcee07  vmovaps xmm0, [rsp]
0000796caedcee0c  vmovaps xmm1, [rsp+0x10]
0000796caedcee12  vmovaps xmm2, [rsp+0x20]
0000796caedcee18  vmovaps xmm3, [rsp+0x30]
0000796caedcee1e  vmovaps xmm4, [rsp+0x40]
0000796caedcee24  vmovaps xmm5, [rsp+0x50]
0000796caedcee2a  vmovaps xmm6, [rsp+0x60]
0000796caedcee30  vmovaps xmm7, [rsp+0x70]
0000796caedcee36  vmovaps xmm8, [rsp+0x80]
0000796caedcee3f  vmovaps xmm9, [rsp+0x90]
0000796caedcee48  vmovaps xmm10, [rsp+0xA0]
0000796caedcee51  vmovaps xmm11, [rsp+0xB0]
0000796caedcee5a  vmovaps xmm12, [rsp+0xC0]
0000796caedcee63  vmovaps xmm14, [rsp+0xD0]
0000796caedcee6c  vmovaps xmm15, [rsp+0xE0]
0000796caedcee75  add rsp, 0xF0
0000796caedcee7c  pop r11
0000796caedcee7e  pop r10
0000796caedcee80  pop r9
0000796caedcee82  pop r8
0000796caedcee84  pop rsi
0000796caedcee85  pop rdi
0000796caedcee86  pop rdx
0000796caedcee87  pop rcx
0000796caedcee88  pop rax
0000796caedcee89  add rsp, 0x08
0000796caedcee8d  jmp 0x0000796CAEDCEC71
0000796caedcee92  call 0x0000796CAECC2240
0000796caedcee97  jmp 0x0000796CAEDCEC8B
0000796caedcee9c  sub rsp, 0x08
0000796caedceea0  push rax
0000796caedceea1  push rcx
0000796caedceea2  push rdx
0000796caedceea3  push rdi
0000796caedceea4  push rsi
0000796caedceea5  push r8
0000796caedceea7  push r9
0000796caedceea9  push r10
0000796caedceeab  push r11
0000796caedceead  sub rsp, 0xF0
0000796caedceeb4  vmovaps [rsp], xmm0
0000796caedceeb9  vmovaps [rsp+0x10], xmm1
0000796caedceebf  vmovaps [rsp+0x20], xmm2
0000796caedceec5  vmovaps [rsp+0x30], xmm3
0000796caedceecb  vmovaps [rsp+0x40], xmm4
0000796caedceed1  vmovaps [rsp+0x50], xmm5
0000796caedceed7  vmovaps [rsp+0x60], xmm6
0000796caedceedd  vmovaps [rsp+0x70], xmm7
0000796caedceee3  vmovaps [rsp+0x80], xmm8
0000796caedceeec  vmovaps [rsp+0x90], xmm9
0000796caedceef5  vmovaps [rsp+0xA0], xmm10
0000796caedceefe  vmovaps [rsp+0xB0], xmm11
0000796caedcef07  vmovaps [rsp+0xC0], xmm12
0000796caedcef10  vmovaps [rsp+0xD0], xmm13
0000796caedcef19  vmovaps [rsp+0xE0], xmm15
0000796caedcef22  sub rsp, 0x30
0000796caedcef26  movaps [rsp], xmm14
0000796caedcef2b  movaps [rsp+0x10], xmm1
0000796caedcef30  movaps [rsp+0x20], xmm15
0000796caedcef36  lea rdi, [rsp]
0000796caedcef3a  mov esi, 0x00
0000796caedcef3f  mov rax, 0x56877063A530
0000796caedcef49  call rax
0000796caedcef4b  movaps xmm14, [rsp]
0000796caedcef50  add rsp, 0x30
0000796caedcef54  vmovaps xmm0, [rsp]
0000796caedcef59  vmovaps xmm1, [rsp+0x10]
0000796caedcef5f  vmovaps xmm2, [rsp+0x20]
0000796caedcef65  vmovaps xmm3, [rsp+0x30]
0000796caedcef6b  vmovaps xmm4, [rsp+0x40]
0000796caedcef71  vmovaps xmm5, [rsp+0x50]
0000796caedcef77  vmovaps xmm6, [rsp+0x60]
0000796caedcef7d  vmovaps xmm7, [rsp+0x70]
0000796caedcef83  vmovaps xmm8, [rsp+0x80]
0000796caedcef8c  vmovaps xmm9, [rsp+0x90]
0000796caedcef95  vmovaps xmm10, [rsp+0xA0]
0000796caedcef9e  vmovaps xmm11, [rsp+0xB0]
0000796caedcefa7  vmovaps xmm12, [rsp+0xC0]
0000796caedcefb0  vmovaps xmm13, [rsp+0xD0]
0000796caedcefb9  vmovaps xmm15, [rsp+0xE0]
0000796caedcefc2  add rsp, 0xF0
0000796caedcefc9  pop r11
0000796caedcefcb  pop r10
0000796caedcefcd  pop r9
0000796caedcefcf  pop r8
0000796caedcefd1  pop rsi
0000796caedcefd2  pop rdi
0000796caedcefd3  pop rdx
0000796caedcefd4  pop rcx
0000796caedcefd5  pop rax
0000796caedcefd6  add rsp, 0x08
0000796caedcefda  jmp 0x0000796CAEDCECAE
0000796caedcefdf  call 0x0000796CAECC34C0
0000796caedcefe4  jmp 0x0000796CAEDCECC4
0000796caedcefe9  int3
0000796caedcefea  nop [rax+rax*1], ax
0000796caedceff0  mov rax, [r15+0xF8]
0000796caedceff7  lea r14, [rax-0x150]
0000796caedceffe  mov [r15+0xF8], r14
0000796caedcf005  mov rax, [r15+0x50]
0000796caedcf009  lea r12, [rax+0x80]
0000796caedcf010  movups xmm1, [r13+r12*1]
0000796caedcf016  lea r12, [rax+0x90]
0000796caedcf01d  movups xmm15, [r13+r12*1]
0000796caedcf023  mov qword ptr [r15+0x48], 0x00
0000796caedcf02b  lea r12, [rax+0x40]
0000796caedcf02f  movups xmm14, [r13+r12*1]
0000796caedcf035  lea r12, [rax+0x50]
0000796caedcf039  movups xmm13, [r13+r12*1]
0000796caedcf03f  lea r12, [r14+0x120]
0000796caedcf046  movq xmm12, qword ptr [r15+0x1C0]
0000796caedcf04f  movq xmm11, qword ptr [r15+0x1B0]
0000796caedcf058  movq r11, xmm12
0000796caedcf05d  movq r10, xmm11
0000796caedcf062  mov [r13+r12*1], r11
0000796caedcf067  lea r12, [r14+0x128]
0000796caedcf06e  mov [r13+r12*1], r10
0000796caedcf073  vxorps xmm12, xmm12, xmm12
0000796caedcf078  vpbroadcastq xmm12, xmm12
0000796caedcf07d  lea r12, [r14+0x100]
0000796caedcf084  movq xmm11, qword ptr [r15+0x200]
0000796caedcf08d  movq xmm10, qword ptr [r15+0x1F0]
0000796caedcf096  movq r11, xmm11
0000796caedcf09b  movq r10, xmm10
0000796caedcf0a0  mov [r13+r12*1], r11
0000796caedcf0a5  lea r12, [r14+0x108]
0000796caedcf0ac  mov [r13+r12*1], r10
0000796caedcf0b1  lea r12, [r14+0xE0]
0000796caedcf0b8  movups [r13+r12*1], xmm15
0000796caedcf0be  lea r12, [r14+0xF0]
0000796caedcf0c5  movups [r13+r12*1], xmm1
0000796caedcf0cb  lea r12, [rax+0xC0]
0000796caedcf0d2  movups xmm1, [r13+r12*1]
0000796caedcf0d8  lea r12, [rax+0xD0]
0000796caedcf0df  movups xmm15, [r13+r12*1]
0000796caedcf0e5  lea r12, [r14+0x110]
0000796caedcf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000796caedcf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000796caedcf0fe  movq r11, xmm11
0000796caedcf103  movq r10, xmm10
0000796caedcf108  mov [r13+r12*1], r11
0000796caedcf10d  lea r12, [r14+0x118]
0000796caedcf114  mov [r13+r12*1], r10
0000796caedcf119  movups xmm11, [r13+rax*1]
0000796caedcf11f  lea r12, [rax+0x10]
0000796caedcf123  movups xmm10, [r13+r12*1]
0000796caedcf129  lea r12, [r14+0x130]
0000796caedcf130  movq xmm9, qword ptr [r15+0x1A0]
0000796caedcf139  movq xmm8, qword ptr [r15+0x190]
0000796caedcf142  movq r11, xmm9
0000796caedcf147  movq r10, xmm8
0000796caedcf14c  mov [r13+r12*1], r11
0000796caedcf151  lea r12, [r14+0x138]
0000796caedcf158  mov [r13+r12*1], r10
0000796caedcf15d  lea r12, [rax+0x140]
0000796caedcf164  movups xmm9, [r13+r12*1]
0000796caedcf16a  lea r12, [rax+0x150]
0000796caedcf171  movups xmm8, [r13+r12*1]
0000796caedcf177  lea r12, [r14+0xC0]
0000796caedcf17e  movups [r13+r12*1], xmm15
0000796caedcf184  lea r12, [r14+0xD0]
0000796caedcf18b  movups [r13+r12*1], xmm1
0000796caedcf191  lea r12, [rax+0x100]
0000796caedcf198  movups xmm1, [r13+r12*1]
0000796caedcf19e  lea r12, [rax+0x110]
0000796caedcf1a5  movups xmm15, [r13+r12*1]
0000796caedcf1ab  lea r12, [r14+0x140]
0000796caedcf1b2  mov r11, [r15+0xE8]
0000796caedcf1b9  mov [r13+r12*1], r11
0000796caedcf1be  lea r12, [rax+0x180]
0000796caedcf1c5  movups xmm7, [r13+r12*1]
0000796caedcf1cb  lea r12, [rax+0x190]
0000796caedcf1d2  movups xmm6, [r13+r12*1]
0000796caedcf1d8  lea r12, [rax+0x1C0]
0000796caedcf1df  movups xmm5, [r13+r12*1]
0000796caedcf1e5  lea r12, [rax+0x1D0]
0000796caedcf1ec  movups xmm4, [r13+r12*1]
0000796caedcf1f2  lea r12, [r14+0x20]
0000796caedcf1f6  movups [r13+r12*1], xmm1
0000796caedcf1fc  lea r12, [r14+0x30]
0000796caedcf200  movups [r13+r12*1], xmm13
0000796caedcf206  lea r12, [rax+0x60]
0000796caedcf20a  movups xmm1, [r13+r12*1]
0000796caedcf210  lea r12, [rax+0x70]
0000796caedcf214  movups xmm13, [r13+r12*1]
0000796caedcf21a  lea r12, [rax+0x20]
0000796caedcf21e  movups xmm3, [r13+r12*1]
0000796caedcf224  lea r12, [rax+0x30]
0000796caedcf228  movups xmm2, [r13+r12*1]
0000796caedcf22e  movaps [r15+0x1F0], xmm2
0000796caedcf236  lea r12, [r14+0x60]
0000796caedcf23a  movups [r13+r12*1], xmm11
0000796caedcf240  lea r12, [r14+0x70]
0000796caedcf244  movups [r13+r12*1], xmm5
0000796caedcf24a  lea r12, [rax+0xE0]
0000796caedcf251  movups xmm11, [r13+r12*1]
0000796caedcf257  lea r12, [rax+0xF0]
0000796caedcf25e  movups xmm5, [r13+r12*1]
0000796caedcf264  lea r12, [r14+0xA0]
0000796caedcf26b  movups [r13+r12*1], xmm13
0000796caedcf271  lea r12, [r14+0xB0]
0000796caedcf278  movups [r13+r12*1], xmm1
0000796caedcf27e  lea r12, [rax+0xA0]
0000796caedcf285  movups xmm1, [r13+r12*1]
0000796caedcf28b  lea r12, [rax+0xB0]
0000796caedcf292  movups xmm13, [r13+r12*1]
0000796caedcf298  lea r12, [rax+0x120]
0000796caedcf29f  vmovaps [rsp+0x10], xmm1
0000796caedcf2a5  movups xmm1, [r13+r12*1]
0000796caedcf2ab  lea r12, [rax+0x130]
0000796caedcf2b2  vmovaps [rsp+0x20], xmm1
0000796caedcf2b8  movups xmm1, [r13+r12*1]
0000796caedcf2be  lea r12, [rax+0x160]
0000796caedcf2c5  vmovaps [rsp+0x30], xmm1
0000796caedcf2cb  movups xmm1, [r13+r12*1]
0000796caedcf2d1  lea r12, [rax+0x170]
0000796caedcf2d8  vmovaps [rsp+0x40], xmm1
0000796caedcf2de  movups xmm1, [r13+r12*1]
0000796caedcf2e4  movaps [r15+0x2B0], xmm1
0000796caedcf2ec  lea r12, [r14+0x80]
0000796caedcf2f3  movups [r13+r12*1], xmm13
0000796caedcf2f9  lea r12, [r14+0x90]
0000796caedcf300  vmovaps xmm13, [rsp+0x10]
0000796caedcf306  movups [r13+r12*1], xmm13
0000796caedcf30c  lea r12, [rax+0x1A0]
0000796caedcf313  movups xmm13, [r13+r12*1]
0000796caedcf319  lea r12, [rax+0x1B0]
0000796caedcf320  vmovaps [rsp+0x10], xmm1
0000796caedcf326  movups xmm1, [r13+r12*1]
0000796caedcf32c  movaps [r15+0x290], xmm13
0000796caedcf334  movaps [r15+0x1E0], xmm1
0000796caedcf33c  lea r12, [rax+0x1E0]
0000796caedcf343  vmovaps [rsp+0x50], xmm1
0000796caedcf349  movups xmm1, [r13+r12*1]
0000796caedcf34f  lea r12, [rax+0x1F0]
0000796caedcf356  vmovaps [rsp+0x60], xmm1
0000796caedcf35c  movups xmm1, [r13+r12*1]
0000796caedcf362  mov qword ptr [r15+0x50], 0x430920
0000796caedcf36a  lea rax, [r14+0x40]
0000796caedcf36e  vmovaps [rsp+0x70], xmm1
0000796caedcf374  vmovaps xmm1, [rsp+0x40]
0000796caedcf37a  movups [r13+rax*1], xmm1
0000796caedcf380  lea rax, [r14+0x50]
0000796caedcf384  movups [r13+rax*1], xmm10
0000796caedcf38a  vmovaps xmm1, [rsp+0x70]
0000796caedcf390  movups [r13+r14*1], xmm1
0000796caedcf396  lea rax, [r14+0x10]
0000796caedcf39a  vmovaps xmm1, [rsp+0x60]
0000796caedcf3a0  movups [r13+rax*1], xmm1
0000796caedcf3a6  mov rax, [r15+0x40]
0000796caedcf3aa  vmovaps [rsp+0x40], xmm3
0000796caedcf3b0  vmovaps xmm1, [rsp+0x40]
0000796caedcf3b6  por xmm3, xmm1
0000796caedcf3ba  vmovaps [rsp+0x40], xmm6
0000796caedcf3c0  vmovaps xmm10, [rsp+0x40]
0000796caedcf3c6  por xmm6, xmm10
0000796caedcf3cb  lea r12, [rax+0x30]
0000796caedcf3cf  mov r11, [r13+r12*1]
0000796caedcf3d4  lea r12, [rax+0x38]
0000796caedcf3d8  mov r10, [r13+r12*1]
0000796caedcf3dd  movq xmm10, r11
0000796caedcf3e2  vmovaps [rsp+0x40], xmm1
0000796caedcf3e8  movq xmm1, r10
0000796caedcf3ed  movq xmm10, xmm10
0000796caedcf3f2  vmovaps [rsp+0x60], xmm10
0000796caedcf3f8  movq xmm10, xmm10
0000796caedcf3fd  movaps [r15+0x130], xmm10
0000796caedcf405  movq xmm1, xmm1
0000796caedcf409  vmovaps [rsp+0x70], xmm1
0000796caedcf40f  movq xmm1, xmm1
0000796caedcf413  movaps [r15+0x280], xmm1
0000796caedcf41b  vmovaps [rsp+0x80], xmm9
0000796caedcf424  vmovaps xmm1, [rsp+0x80]
0000796caedcf42d  por xmm9, xmm1
0000796caedcf432  lea r12, [rax+0x20]
0000796caedcf436  mov r11, [r13+r12*1]
0000796caedcf43b  lea r12, [rax+0x28]
0000796caedcf43f  mov r10, [r13+r12*1]
0000796caedcf444  movq xmm1, r11
0000796caedcf449  movq xmm10, r10
0000796caedcf44e  movq xmm1, xmm1
0000796caedcf452  vmovaps [rsp+0x80], xmm1
0000796caedcf45b  movq xmm1, xmm1
0000796caedcf45f  movaps [r15+0x150], xmm1
0000796caedcf467  movq xmm10, xmm10
0000796caedcf46c  vmovaps [rsp+0x90], xmm10
0000796caedcf475  movq xmm10, xmm10
0000796caedcf47a  movaps [r15+0x140], xmm10
0000796caedcf482  lea r12, [rax+0x10]
0000796caedcf486  mov r11, [r13+r12*1]
0000796caedcf48b  lea r12, [rax+0x18]
0000796caedcf48f  mov r10, [r13+r12*1]
0000796caedcf494  movq xmm1, r11
0000796caedcf499  movq xmm10, r10
0000796caedcf49e  movq xmm1, xmm1
0000796caedcf4a2  vmovaps [rsp+0xA0], xmm1
0000796caedcf4ab  movq xmm1, xmm1
0000796caedcf4af  movaps [r15+0x170], xmm1
0000796caedcf4b7  movq xmm10, xmm10
0000796caedcf4bc  vmovaps [rsp+0xB0], xmm10
0000796caedcf4c5  movq xmm10, xmm10
0000796caedcf4ca  movaps [r15+0x160], xmm10
0000796caedcf4d2  mov r12, [r13+rax*1]
0000796caedcf4d7  vmovq xmm1, r12
0000796caedcf4dc  vpbroadcastq xmm1, xmm1
0000796caedcf4e1  lea r12, [rax+0x08]
0000796caedcf4e5  mov rax, [r13+r12*1]
0000796caedcf4ea  movq xmm10, rax
0000796caedcf4ef  movaps [r15+0x230], xmm10
0000796caedcf4f7  lea rax, [r14+0x50]
0000796caedcf4fb  movups xmm10, [r13+rax*1]
0000796caedcf501  lea rax, [r14+0x60]
0000796caedcf505  vmovaps [rsp+0xC0], xmm1
0000796caedcf50e  movups xmm1, [r13+rax*1]
0000796caedcf514  lea rax, [r14+0x30]
0000796caedcf518  vmovaps [rsp+0xD0], xmm1
0000796caedcf521  movups xmm1, [r13+rax*1]
0000796caedcf527  mov qword ptr [r15+0x60], 0x430920
0000796caedcf52f  mov qword ptr [r15+0x58], 0x40
0000796caedcf537  vmovaps [rsp+0xE0], xmm1
0000796caedcf540  vmovaps [rsp+0xF0], xmm15
0000796caedcf549  vmovaps xmm15, [rsp+0xC0]
0000796caedcf552  vmovaps [rsp+0xC0], xmm14
0000796caedcf55b  vmovaps xmm14, [rsp+0x40]
0000796caedcf561  vmovaps [rsp+0x40], xmm13
0000796caedcf567  movaps xmm1, xmm15
0000796caedcf56b  mulpd xmm1, xmm14
0000796caedcf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000796caedcf575  ptest xmm13, xmm13
0000796caedcf57b  jnz 0x0000796CAEDD0682
0000796caedcf581  movq xmm14, qword ptr [r15+0x230]
0000796caedcf58a  vmovaps [rsp+0x100], xmm14
0000796caedcf593  vpermilpd xmm14, xmm14, 0x00
0000796caedcf599  vmovaps [rsp+0x110], xmm1
0000796caedcf5a2  vmovaps xmm1, [rsp+0xE0]
0000796caedcf5ab  vmovaps [rsp+0xE0], xmm15
0000796caedcf5b4  movaps xmm13, xmm1
0000796caedcf5b8  mulpd xmm13, xmm14
0000796caedcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000796caedcf5c3  ptest xmm15, xmm15
0000796caedcf5c9  jnz 0x0000796CAEDD07C4
0000796caedcf5cf  vxorps xmm1, xmm1, xmm1
0000796caedcf5d3  vpbroadcastq xmm1, xmm1
0000796caedcf5d8  vmovaps xmm14, [rsp+0xE0]
0000796caedcf5e1  vmovaps [rsp+0xE0], xmm1
0000796caedcf5ea  vmovaps xmm1, [rsp+0xD0]
0000796caedcf5f3  vmovaps [rsp+0xD0], xmm13
0000796caedcf5fc  movaps xmm15, xmm14
0000796caedcf600  mulpd xmm15, xmm1
0000796caedcf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000796caedcf60b  ptest xmm13, xmm13
0000796caedcf611  jnz 0x0000796CAEDD0907
0000796caedcf617  movaps xmm1, xmm14
0000796caedcf61b  mulpd xmm1, xmm10
0000796caedcf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000796caedcf625  ptest xmm13, xmm13
0000796caedcf62b  jnz 0x0000796CAEDD0A4A
0000796caedcf631  movaps xmm13, xmm14
0000796caedcf635  mulpd xmm13, xmm2
0000796caedcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000796caedcf640  ptest xmm10, xmm10
0000796caedcf646  jnz 0x0000796CAEDD0B8C
0000796caedcf64c  vmovaps [rsp+0x120], xmm7
0000796caedcf655  vmovaps xmm14, [rsp+0x120]
0000796caedcf65e  por xmm7, xmm14
0000796caedcf663  vmovaps xmm14, [rsp+0xC0]
0000796caedcf66c  vmovaps xmm10, [rsp+0xC0]
0000796caedcf675  por xmm14, xmm10
0000796caedcf67a  vmovaps xmm2, [rsp+0x100]
0000796caedcf683  vpermilpd xmm2, xmm2, 0x00
0000796caedcf689  vmovaps [rsp+0xC0], xmm1
0000796caedcf692  vmovaps [rsp+0x120], xmm15
0000796caedcf69b  movaps xmm1, xmm10
0000796caedcf69f  mulpd xmm1, xmm2
0000796caedcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000796caedcf6a8  ptest xmm15, xmm15
0000796caedcf6ae  jnz 0x0000796CAEDD0CCF
0000796caedcf6b4  xor eax, eax
0000796caedcf6b6  mov r12d, 0x40
0000796caedcf6bc  mov r11d, 0x200
0000796caedcf6c2  cmp r12, r11
0000796caedcf6c5  cmc
0000796caedcf6c6  lahf
0000796caedcf6c7  seto al
0000796caedcf6ca  mov [r15+0x108], eax
0000796caedcf6d1  vmovaps xmm10, [rsp+0x110]
0000796caedcf6da  vmovaps xmm2, [rsp+0xE0]
0000796caedcf6e3  vmovaps [rsp+0xE0], xmm1
0000796caedcf6ec  movaps xmm15, xmm10
0000796caedcf6f0  addpd xmm15, xmm2
0000796caedcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000796caedcf6fb  ptest xmm1, xmm1
0000796caedcf700  jnz 0x0000796CAEDD0E10
0000796caedcf706  vmovaps xmm10, [rsp+0x120]
0000796caedcf70f  vmovaps [rsp+0x110], xmm15
0000796caedcf718  movaps xmm1, xmm10
0000796caedcf71c  addpd xmm1, xmm12
0000796caedcf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000796caedcf726  ptest xmm15, xmm15
0000796caedcf72c  jnz 0x0000796CAEDD0F53
0000796caedcf732  vmovaps xmm10, [rsp+0xC0]
0000796caedcf73b  vmovaps [rsp+0xC0], xmm1
0000796caedcf744  movaps xmm15, xmm10
0000796caedcf748  addpd xmm15, xmm12
0000796caedcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000796caedcf753  ptest xmm1, xmm1
0000796caedcf758  jnz 0x0000796CAEDD1095
0000796caedcf75e  vmovaps xmm1, [rsp+0x30]
0000796caedcf764  vmovaps xmm12, [rsp+0x30]
0000796caedcf76a  por xmm1, xmm12
0000796caedcf76f  vmovaps xmm12, [rsp+0x20]
0000796caedcf775  vmovaps xmm10, [rsp+0x20]
0000796caedcf77b  por xmm12, xmm10
0000796caedcf780  vmovaps [rsp+0x20], xmm5
0000796caedcf786  vmovaps xmm10, [rsp+0x20]
0000796caedcf78c  por xmm5, xmm10
0000796caedcf791  vmovaps [rsp+0x20], xmm11
0000796caedcf797  vmovaps xmm10, [rsp+0x20]
0000796caedcf79d  por xmm11, xmm10
0000796caedcf7a2  vmovaps [rsp+0x20], xmm4
0000796caedcf7a8  vmovaps xmm10, [rsp+0x20]
0000796caedcf7ae  por xmm4, xmm10
0000796caedcf7b3  vmovaps [rsp+0x20], xmm8
0000796caedcf7b9  vmovaps xmm10, [rsp+0x20]
0000796caedcf7bf  por xmm8, xmm10
0000796caedcf7c4  vmovaps xmm10, [rsp+0xF0]
0000796caedcf7cd  vmovaps [rsp+0x20], xmm1
0000796caedcf7d3  vmovaps xmm1, [rsp+0xF0]
0000796caedcf7dc  por xmm10, xmm1
0000796caedcf7e1  lea rax, [r14+0xA0]
0000796caedcf7e8  movups xmm1, [r13+rax*1]
0000796caedcf7ee  lea rax, [r14+0xB0]
0000796caedcf7f5  vmovaps [rsp+0x30], xmm1
0000796caedcf7fb  movups xmm1, [r13+rax*1]
0000796caedcf801  vmovaps [rsp+0xF0], xmm1
0000796caedcf80a  vmovaps [rsp+0x120], xmm15
0000796caedcf813  movaps xmm1, xmm13
0000796caedcf817  addpd xmm1, xmm2
0000796caedcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000796caedcf820  ptest xmm15, xmm15
0000796caedcf826  jnz 0x0000796CAEDD11ED
0000796caedcf82c  lea rax, [r14+0xF0]
0000796caedcf833  movups xmm15, [r13+rax*1]
0000796caedcf839  vmovaps xmm2, [rsp+0xC0]
0000796caedcf842  vmovaps [rsp+0xC0], xmm1
0000796caedcf84b  vmovaps xmm1, [rsp+0xE0]
0000796caedcf854  vmovaps [rsp+0xE0], xmm15
0000796caedcf85d  movaps xmm13, xmm2
0000796caedcf861  addpd xmm13, xmm1
0000796caedcf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000796caedcf86c  ptest xmm15, xmm15
0000796caedcf872  jnz 0x0000796CAEDD1338
0000796caedcf878  vmovaps xmm15, [rsp+0x120]
0000796caedcf881  vmovaps xmm2, [rsp+0xD0]
0000796caedcf88a  vmovaps [rsp+0xD0], xmm14
0000796caedcf893  movaps xmm1, xmm15
0000796caedcf897  addpd xmm1, xmm2
0000796caedcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000796caedcf8a0  ptest xmm14, xmm14
0000796caedcf8a6  jnz 0x0000796CAEDD147A
0000796caedcf8ac  vmovaps xmm15, [rsp+0x100]
0000796caedcf8b5  vpermilpd xmm15, xmm15, 0x00
0000796caedcf8bb  vmovaps xmm2, [rsp+0xF0]
0000796caedcf8c4  vmovaps [rsp+0xF0], xmm1
0000796caedcf8cd  movaps xmm14, xmm2
0000796caedcf8d1  mulpd xmm14, xmm15
0000796caedcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000796caedcf8dc  ptest xmm1, xmm1
0000796caedcf8e1  jnz 0x0000796CAEDD15BB
0000796caedcf8e7  vmovaps xmm1, [rsp+0xA0]
0000796caedcf8f0  vpermilpd xmm1, xmm1, 0x00
0000796caedcf8f6  vmovaps xmm2, [rsp+0xE0]
0000796caedcf8ff  vmovaps [rsp+0xE0], xmm14
0000796caedcf908  movaps xmm15, xmm2
0000796caedcf90c  mulpd xmm15, xmm1
0000796caedcf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000796caedcf917  ptest xmm14, xmm14
0000796caedcf91d  jnz 0x0000796CAEDD16FE
0000796caedcf923  lea rax, [r14+0xE0]
0000796caedcf92a  movups xmm1, [r13+rax*1]
0000796caedcf930  vmovaps xmm14, [rsp+0x100]
0000796caedcf939  vpermilpd xmm14, xmm14, 0x00
0000796caedcf93f  vmovaps [rsp+0x100], xmm1
0000796caedcf948  vmovaps xmm1, [rsp+0x30]
0000796caedcf94e  vmovaps [rsp+0x30], xmm15
0000796caedcf954  movaps xmm2, xmm1
0000796caedcf957  mulpd xmm2, xmm14
0000796caedcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000796caedcf961  ptest xmm15, xmm15
0000796caedcf967  jnz 0x0000796CAEDD184A
0000796caedcf96d  vmovaps [rsp+0x120], xmm10
0000796caedcf976  vmovaps xmm1, [rsp+0x120]
0000796caedcf97f  por xmm10, xmm1
0000796caedcf984  movaps [r15+0x300], xmm10
0000796caedcf98c  vmovaps [rsp+0x120], xmm8
0000796caedcf995  vmovaps xmm1, [rsp+0x120]
0000796caedcf99e  por xmm8, xmm1
0000796caedcf9a3  movaps [r15+0x190], xmm8
0000796caedcf9ab  vmovaps xmm1, [rsp+0xA0]
0000796caedcf9b4  vpermilpd xmm1, xmm1, 0x00
0000796caedcf9ba  vmovaps xmm14, [rsp+0x100]
0000796caedcf9c3  vmovaps [rsp+0x100], xmm13
0000796caedcf9cc  movaps xmm15, xmm14
0000796caedcf9d0  mulpd xmm15, xmm1
0000796caedcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000796caedcf9db  ptest xmm13, xmm13
0000796caedcf9e1  jnz 0x0000796CAEDD198B
0000796caedcf9e7  lea rax, [r14+0x90]
0000796caedcf9ee  movups xmm1, [r13+rax*1]
0000796caedcf9f4  vmovaps [rsp+0x120], xmm4
0000796caedcf9fd  vmovaps xmm14, [rsp+0x120]
0000796caedcfa06  por xmm4, xmm14
0000796caedcfa0b  movaps [r15+0x1C0], xmm4
0000796caedcfa13  vmovaps [rsp+0x120], xmm11
0000796caedcfa1c  vmovaps xmm14, [rsp+0x120]
0000796caedcfa25  por xmm11, xmm14
0000796caedcfa2a  movaps [r15+0x200], xmm11
0000796caedcfa32  vmovaps [rsp+0x120], xmm5
0000796caedcfa3b  vmovaps xmm14, [rsp+0x120]
0000796caedcfa44  por xmm5, xmm14
0000796caedcfa49  movaps [r15+0x2D0], xmm5
0000796caedcfa51  vmovaps [rsp+0x120], xmm12
0000796caedcfa5a  vmovaps xmm14, [rsp+0x120]
0000796caedcfa63  por xmm12, xmm14
0000796caedcfa68  movaps [r15+0x2E0], xmm12
0000796caedcfa70  vmovaps xmm13, [rsp+0x110]
0000796caedcfa79  vmovaps [rsp+0x110], xmm1
0000796caedcfa82  vmovaps xmm1, [rsp+0xE0]
0000796caedcfa8b  vmovaps [rsp+0xE0], xmm15
0000796caedcfa94  movaps xmm14, xmm13
0000796caedcfa98  addpd xmm14, xmm1
0000796caedcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000796caedcfaa3  ptest xmm15, xmm15
0000796caedcfaa9  jnz 0x0000796CAEDD1AD8
0000796caedcfaaf  vmovaps xmm1, [rsp+0xA0]
0000796caedcfab8  vpermilpd xmm1, xmm1, 0x00
0000796caedcfabe  vmovaps xmm13, [rsp+0x110]
0000796caedcfac7  vmovaps [rsp+0x110], xmm14
0000796caedcfad0  movaps xmm15, xmm13
0000796caedcfad4  mulpd xmm15, xmm1
0000796caedcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000796caedcfadf  ptest xmm14, xmm14
0000796caedcfae5  jnz 0x0000796CAEDD1C1B
0000796caedcfaeb  lea rax, [r14+0x80]
0000796caedcfaf2  movups xmm1, [r13+rax*1]
0000796caedcfaf8  vmovaps xmm13, [rsp+0xC0]
0000796caedcfb01  vmovaps [rsp+0xC0], xmm1
0000796caedcfb0a  movaps xmm14, xmm13
0000796caedcfb0e  addpd xmm14, xmm2
0000796caedcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000796caedcfb19  ptest xmm1, xmm1
0000796caedcfb1e  jnz 0x0000796CAEDD1D68
0000796caedcfb24  vmovaps xmm13, [rsp+0x100]
0000796caedcfb2d  vmovaps xmm2, [rsp+0x30]
0000796caedcfb33  vmovaps [rsp+0x30], xmm15
0000796caedcfb39  movaps xmm1, xmm13
0000796caedcfb3d  addpd xmm1, xmm2
0000796caedcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000796caedcfb46  ptest xmm15, xmm15
0000796caedcfb4c  jnz 0x0000796CAEDD1EAB
0000796caedcfb52  vmovaps xmm15, [rsp+0x20]
0000796caedcfb58  vmovaps xmm13, [rsp+0x20]
0000796caedcfb5e  por xmm15, xmm13
0000796caedcfb63  movaps [r15+0x2F0], xmm15
0000796caedcfb6b  vmovaps xmm13, [rsp+0xA0]
0000796caedcfb74  vpermilpd xmm13, xmm13, 0x00
0000796caedcfb7a  vmovaps [rsp+0x20], xmm1
0000796caedcfb80  vmovaps xmm1, [rsp+0xC0]
0000796caedcfb89  vmovaps [rsp+0xA0], xmm15
0000796caedcfb92  movaps xmm2, xmm1
0000796caedcfb95  mulpd xmm2, xmm13
0000796caedcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000796caedcfb9f  ptest xmm15, xmm15
0000796caedcfba5  jnz 0x0000796CAEDD1FEC
0000796caedcfbab  lea rax, [r14+0xD0]
0000796caedcfbb2  movups xmm1, [r13+rax*1]
0000796caedcfbb8  vmovaps xmm13, [rsp+0xF0]
0000796caedcfbc1  vmovaps [rsp+0xC0], xmm1
0000796caedcfbca  vmovaps xmm1, [rsp+0xE0]
0000796caedcfbd3  vmovaps [rsp+0xE0], xmm14
0000796caedcfbdc  movaps xmm15, xmm13
0000796caedcfbe0  addpd xmm15, xmm1
0000796caedcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000796caedcfbeb  ptest xmm14, xmm14
0000796caedcfbf1  jnz 0x0000796CAEDD2137
0000796caedcfbf7  vmovaps xmm1, [rsp+0xB0]
0000796caedcfc00  vpermilpd xmm1, xmm1, 0x00
0000796caedcfc06  movaps xmm14, xmm11
0000796caedcfc0a  mulpd xmm14, xmm1
0000796caedcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000796caedcfc15  ptest xmm13, xmm13
0000796caedcfc1b  jnz 0x0000796CAEDD227A
0000796caedcfc21  movaps [r15+0x260], xmm14
0000796caedcfc29  vxorps xmm1, xmm1, xmm1
0000796caedcfc2d  vpbroadcastq xmm1, xmm1
0000796caedcfc32  movaps [r15+0x1B0], xmm1
0000796caedcfc3a  vmovaps xmm1, [rsp+0xB0]
0000796caedcfc43  vpermilpd xmm1, xmm1, 0x00
0000796caedcfc49  vmovaps xmm11, [rsp+0xC0]
0000796caedcfc52  vmovaps [rsp+0xC0], xmm15
0000796caedcfc5b  movaps xmm13, xmm11
0000796caedcfc5f  mulpd xmm13, xmm1
0000796caedcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000796caedcfc6a  ptest xmm15, xmm15
0000796caedcfc70  jnz 0x0000796CAEDD23BD
0000796caedcfc76  lea rax, [r14+0xC0]
0000796caedcfc7d  movups xmm1, [r13+rax*1]
0000796caedcfc83  vmovaps xmm11, [rsp+0x110]
0000796caedcfc8c  vmovaps [rsp+0xF0], xmm1
0000796caedcfc95  vmovaps xmm1, [rsp+0x30]
0000796caedcfc9b  vmovaps [rsp+0x30], xmm14
0000796caedcfca1  movaps xmm15, xmm11
0000796caedcfca5  addpd xmm15, xmm1
0000796caedcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000796caedcfcb0  ptest xmm14, xmm14
0000796caedcfcb6  jnz 0x0000796CAEDD250A
0000796caedcfcbc  vmovaps [rsp+0x100], xmm9
0000796caedcfcc5  vmovaps xmm1, [rsp+0x100]
0000796caedcfcce  por xmm9, xmm1
0000796caedcfcd3  movaps [r15+0x270], xmm9
0000796caedcfcdb  vmovaps [rsp+0x100], xmm6
0000796caedcfce4  vmovaps xmm1, [rsp+0x100]
0000796caedcfced  por xmm6, xmm1
0000796caedcfcf1  movaps [r15+0x1A0], xmm6
0000796caedcfcf9  vmovaps xmm14, [rsp+0xB0]
0000796caedcfd02  vpermilpd xmm14, xmm14, 0x00
0000796caedcfd08  vmovaps xmm6, [rsp+0xF0]
0000796caedcfd11  vmovaps [rsp+0xF0], xmm1
0000796caedcfd1a  movaps xmm11, xmm6
0000796caedcfd1e  mulpd xmm11, xmm14
0000796caedcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000796caedcfd29  ptest xmm1, xmm1
0000796caedcfd2e  jnz 0x0000796CAEDD264D
0000796caedcfd34  lea rax, [r14+0x20]
0000796caedcfd38  movups xmm1, [r13+rax*1]
0000796caedcfd3e  movaps [r15+0x110], xmm1
0000796caedcfd46  vmovaps xmm6, [rsp+0xE0]
0000796caedcfd4f  vmovaps [rsp+0xE0], xmm1
0000796caedcfd58  movaps xmm14, xmm6
0000796caedcfd5c  addpd xmm14, xmm2
0000796caedcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000796caedcfd67  ptest xmm1, xmm1
0000796caedcfd6c  jnz 0x0000796CAEDD279A
0000796caedcfd72  vmovaps xmm1, [rsp+0xB0]
0000796caedcfd7b  vpermilpd xmm1, xmm1, 0x00
0000796caedcfd81  movaps xmm6, xmm5
0000796caedcfd84  mulpd xmm6, xmm1
0000796caedcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000796caedcfd8d  ptest xmm2, xmm2
0000796caedcfd92  jnz 0x0000796CAEDD28DC
0000796caedcfd98  vmovaps xmm5, [rsp+0x20]
0000796caedcfd9e  movaps xmm1, xmm5
0000796caedcfda1  addpd xmm1, xmm13
0000796caedcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000796caedcfdab  ptest xmm2, xmm2
0000796caedcfdb0  jnz 0x0000796CAEDD2A1C
0000796caedcfdb6  vmovaps xmm13, [rsp+0x80]
0000796caedcfdbf  vpermilpd xmm13, xmm13, 0x00
0000796caedcfdc5  vmovaps xmm2, [rsp+0xE0]
0000796caedcfdce  vmovaps [rsp+0x20], xmm1
0000796caedcfdd4  movaps xmm5, xmm2
0000796caedcfdd7  mulpd xmm5, xmm13
0000796caedcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000796caedcfde1  ptest xmm1, xmm1
0000796caedcfde6  jnz 0x0000796CAEDD2B5D
0000796caedcfdec  vmovaps xmm1, [rsp+0x80]
0000796caedcfdf5  vpermilpd xmm1, xmm1, 0x00
0000796caedcfdfb  movaps xmm13, xmm10
0000796caedcfdff  mulpd xmm13, xmm1
0000796caedcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000796caedcfe0a  ptest xmm2, xmm2
0000796caedcfe0f  jnz 0x0000796CAEDD2C9E
0000796caedcfe15  vmovaps xmm10, [rsp+0x30]
0000796caedcfe1b  movaps xmm1, xmm15
0000796caedcfe1f  addpd xmm1, xmm10
0000796caedcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000796caedcfe29  ptest xmm2, xmm2
0000796caedcfe2e  jnz 0x0000796CAEDD2DE1
0000796caedcfe34  vmovaps xmm10, [rsp+0xC0]
0000796caedcfe3d  movaps xmm15, xmm10
0000796caedcfe41  addpd xmm15, xmm11
0000796caedcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000796caedcfe4c  ptest xmm2, xmm2
0000796caedcfe51  jnz 0x0000796CAEDD2F23
0000796caedcfe57  vmovaps xmm11, [rsp+0x80]
0000796caedcfe60  vpermilpd xmm11, xmm11, 0x00
0000796caedcfe66  movaps xmm10, xmm12
0000796caedcfe6a  mulpd xmm10, xmm11
0000796caedcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000796caedcfe75  ptest xmm2, xmm2
0000796caedcfe7a  jnz 0x0000796CAEDD3067
0000796caedcfe80  vmovaps xmm12, [rsp+0x80]
0000796caedcfe89  vpermilpd xmm12, xmm12, 0x00
0000796caedcfe8f  vmovaps xmm2, [rsp+0xA0]
0000796caedcfe98  vmovaps [rsp+0x30], xmm1
0000796caedcfe9e  movaps xmm11, xmm2
0000796caedcfea2  mulpd xmm11, xmm12
0000796caedcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000796caedcfead  ptest xmm1, xmm1
0000796caedcfeb2  jnz 0x0000796CAEDD31AB
0000796caedcfeb8  movaps xmm1, xmm14
0000796caedcfebc  addpd xmm1, xmm6
0000796caedcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000796caedcfec5  ptest xmm12, xmm12
0000796caedcfecb  jnz 0x0000796CAEDD32EE
0000796caedcfed1  vmovaps xmm12, [rsp+0x20]
0000796caedcfed7  movaps xmm14, xmm12
0000796caedcfedb  addpd xmm14, xmm5
0000796caedcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000796caedcfee6  ptest xmm6, xmm6
0000796caedcfeeb  jnz 0x0000796CAEDD342F
0000796caedcfef1  vmovaps xmm12, [rsp+0x90]
0000796caedcfefa  vpermilpd xmm12, xmm12, 0x00
0000796caedcff00  movaps xmm6, xmm9
0000796caedcff04  mulpd xmm6, xmm12
0000796caedcff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000796caedcff0e  ptest xmm5, xmm5
0000796caedcff13  jnz 0x0000796CAEDD3572
0000796caedcff19  movaps xmm12, xmm15
0000796caedcff1d  addpd xmm12, xmm13
0000796caedcff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000796caedcff28  ptest xmm9, xmm9
0000796caedcff2e  jnz 0x0000796CAEDD36B4
0000796caedcff34  vmovaps xmm13, [rsp+0x30]
0000796caedcff3a  movaps xmm15, xmm13
0000796caedcff3e  addpd xmm15, xmm10
0000796caedcff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000796caedcff49  ptest xmm9, xmm9
0000796caedcff4f  jnz 0x0000796CAEDD37F8
0000796caedcff55  vmovaps xmm13, [rsp+0xD0]
0000796caedcff5e  vmovaps xmm10, [rsp+0xD0]
0000796caedcff67  por xmm13, xmm10
0000796caedcff6c  movaps [r15+0x250], xmm13
0000796caedcff74  vmovaps [rsp+0x20], xmm7
0000796caedcff7a  vmovaps xmm13, [rsp+0x20]
0000796caedcff80  por xmm7, xmm13
0000796caedcff85  movaps [r15+0x2A0], xmm7
0000796caedcff8d  vmovaps [rsp+0x20], xmm3
0000796caedcff93  vmovaps xmm13, [rsp+0x20]
0000796caedcff99  por xmm3, xmm13
0000796caedcff9e  movaps [r15+0x1D0], xmm3
0000796caedcffa6  lea rax, [r14+0x40]
0000796caedcffaa  movups xmm13, [r13+rax*1]
0000796caedcffb0  movaps [r15+0x2C0], xmm13
0000796caedcffb8  vmovaps xmm10, [rsp+0x90]
0000796caedcffc1  vpermilpd xmm10, xmm10, 0x00
0000796caedcffc7  movaps xmm9, xmm8
0000796caedcffcb  mulpd xmm9, xmm10
0000796caedcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000796caedcffd6  ptest xmm5, xmm5
0000796caedcffdb  jnz 0x0000796CAEDD3946
0000796caedcffe1  movaps xmm10, xmm1
0000796caedcffe5  addpd xmm10, xmm11
0000796caedcffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000796caedcfff0  ptest xmm8, xmm8
0000796caedcfff6  jnz 0x0000796CAEDD3A8A
0000796caedcfffc  movaps xmm1, xmm14
0000796caedd0000  addpd xmm1, xmm6
0000796caedd0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000796caedd0009  ptest xmm11, xmm11
0000796caedd000f  jnz 0x0000796CAEDD3BCD
0000796caedd0015  vmovaps xmm14, [rsp+0x90]
0000796caedd001e  vpermilpd xmm14, xmm14, 0x00
0000796caedd0024  movaps xmm11, xmm13
0000796caedd0028  mulpd xmm11, xmm14
0000796caedd002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000796caedd0033  ptest xmm8, xmm8
0000796caedd0039  jnz 0x0000796CAEDD3D0E
0000796caedd003f  vmovaps xmm14, [rsp+0x90]
0000796caedd0048  vpermilpd xmm14, xmm14, 0x00
0000796caedd004e  vmovaps xmm8, [rsp+0x10]
0000796caedd0054  movaps xmm13, xmm8
0000796caedd0058  mulpd xmm13, xmm14
0000796caedd005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000796caedd0063  ptest xmm6, xmm6
0000796caedd0068  jnz 0x0000796CAEDD3E52
0000796caedd006e  vmovaps xmm14, [rsp+0x60]
0000796caedd0074  vpermilpd xmm14, xmm14, 0x00
0000796caedd007a  movaps xmm8, xmm7
0000796caedd007e  mulpd xmm8, xmm14
0000796caedd0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000796caedd0089  ptest xmm6, xmm6
0000796caedd008e  jnz 0x0000796CAEDD3F96
0000796caedd0094  movaps xmm14, xmm12
0000796caedd0098  addpd xmm14, xmm9
0000796caedd009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000796caedd00a3  ptest xmm7, xmm7
0000796caedd00a8  jnz 0x0000796CAEDD40D9
0000796caedd00ae  vmovaps xmm12, [rsp+0x60]
0000796caedd00b4  vpermilpd xmm12, xmm12, 0x00
0000796caedd00ba  vmovaps xmm7, [rsp+0xF0]
0000796caedd00c3  movaps xmm9, xmm7
0000796caedd00c7  mulpd xmm9, xmm12
0000796caedd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000796caedd00d2  ptest xmm6, xmm6
0000796caedd00d7  jnz 0x0000796CAEDD421D
0000796caedd00dd  movaps xmm12, xmm15
0000796caedd00e1  addpd xmm12, xmm11
0000796caedd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000796caedd00ec  ptest xmm7, xmm7
0000796caedd00f1  jnz 0x0000796CAEDD4360
0000796caedd00f7  vmovaps xmm15, [rsp+0x60]
0000796caedd00fd  vpermilpd xmm15, xmm15, 0x00
0000796caedd0103  vmovaps xmm7, [rsp+0x40]
0000796caedd0109  movaps xmm11, xmm7
0000796caedd010d  mulpd xmm11, xmm15
0000796caedd0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000796caedd0118  ptest xmm6, xmm6
0000796caedd011d  jnz 0x0000796CAEDD44A4
0000796caedd0123  movaps xmm15, xmm10
0000796caedd0127  addpd xmm15, xmm13
0000796caedd012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000796caedd0132  ptest xmm7, xmm7
0000796caedd0137  jnz 0x0000796CAEDD45E7
0000796caedd013d  vmovaps xmm13, [rsp+0x60]
0000796caedd0143  vpermilpd xmm13, xmm13, 0x00
0000796caedd0149  vmovaps xmm7, [rsp+0x50]
0000796caedd014f  movaps xmm10, xmm7
0000796caedd0153  mulpd xmm10, xmm13
0000796caedd0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000796caedd015e  ptest xmm6, xmm6
0000796caedd0163  jnz 0x0000796CAEDD472B
0000796caedd0169  movaps xmm13, xmm1
0000796caedd016d  addpd xmm13, xmm8
0000796caedd0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000796caedd0178  ptest xmm7, xmm7
0000796caedd017d  jnz 0x0000796CAEDD486E
0000796caedd0183  lea rax, [r14+0x70]
0000796caedd0187  movups xmm1, [r13+rax*1]
0000796caedd018d  movaps [r15+0x240], xmm1
0000796caedd0195  movaps xmm8, xmm14
0000796caedd0199  addpd xmm8, xmm9
0000796caedd019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000796caedd01a4  ptest xmm7, xmm7
0000796caedd01a9  jnz 0x0000796CAEDD49BB
0000796caedd01af  movaps [r15+0x170], xmm8
0000796caedd01b7  vmovaps xmm14, [rsp+0x70]
0000796caedd01bd  vpermilpd xmm14, xmm14, 0x00
0000796caedd01c3  movaps xmm9, xmm1
0000796caedd01c7  mulpd xmm9, xmm14
0000796caedd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000796caedd01d2  ptest xmm7, xmm7
0000796caedd01d7  jnz 0x0000796CAEDD4AFF
0000796caedd01dd  vmovaps xmm1, [rsp+0x70]
0000796caedd01e3  vpermilpd xmm1, xmm1, 0x00
0000796caedd01e9  movaps xmm14, xmm4
0000796caedd01ed  mulpd xmm14, xmm1
0000796caedd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000796caedd01f8  ptest xmm7, xmm7
0000796caedd01fd  jnz 0x0000796CAEDD4C42
0000796caedd0203  movaps [r15+0x180], xmm14
0000796caedd020b  movaps xmm1, xmm12
0000796caedd020f  addpd xmm1, xmm11
0000796caedd0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000796caedd0219  ptest xmm7, xmm7
0000796caedd021e  jnz 0x0000796CAEDD4D84
0000796caedd0224  movaps [r15+0x210], xmm1
0000796caedd022c  movups xmm12, [r13+r14*1]
0000796caedd0232  lea rax, [r14+0x10]
0000796caedd0236  movups xmm11, [r13+rax*1]
0000796caedd023c  movaps [r15+0x230], xmm11
0000796caedd0244  movaps xmm7, xmm15
0000796caedd0248  addpd xmm7, xmm10
0000796caedd024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000796caedd0252  ptest xmm6, xmm6
0000796caedd0257  jnz 0x0000796CAEDD4EDA
0000796caedd025d  movaps [r15+0x130], xmm7
0000796caedd0265  vmovaps xmm15, [rsp+0x70]
0000796caedd026b  vpermilpd xmm15, xmm15, 0x00
0000796caedd0271  movaps xmm10, xmm11
0000796caedd0275  mulpd xmm10, xmm15
0000796caedd027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000796caedd0280  ptest xmm6, xmm6
0000796caedd0285  jnz 0x0000796CAEDD501C
0000796caedd028b  movaps [r15+0x220], xmm10
0000796caedd0293  vmovaps xmm15, [rsp+0x70]
0000796caedd0299  vpermilpd xmm15, xmm15, 0x00
0000796caedd029f  movaps xmm11, xmm12
0000796caedd02a3  mulpd xmm11, xmm15
0000796caedd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000796caedd02ae  ptest xmm6, xmm6
0000796caedd02b3  jnz 0x0000796CAEDD5160
0000796caedd02b9  movaps xmm15, xmm13
0000796caedd02bd  addpd xmm15, xmm9
0000796caedd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000796caedd02c8  ptest xmm12, xmm12
0000796caedd02ce  jnz 0x0000796CAEDD52A4
0000796caedd02d4  movaps [r15+0x140], xmm15
0000796caedd02dc  movaps xmm13, xmm8
0000796caedd02e0  addpd xmm13, xmm14
0000796caedd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000796caedd02eb  ptest xmm12, xmm12
0000796caedd02f1  jnz 0x0000796CAEDD53E8
0000796caedd02f7  movaps [r15+0x150], xmm13
0000796caedd02ff  movaps xmm14, xmm1
0000796caedd0303  addpd xmm14, xmm10
0000796caedd0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000796caedd030e  ptest xmm12, xmm12
0000796caedd0314  jnz 0x0000796CAEDD552C
0000796caedd031a  movaps [r15+0x160], xmm14
0000796caedd0322  movaps xmm1, xmm7
0000796caedd0325  addpd xmm1, xmm11
0000796caedd032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000796caedd032f  ptest xmm12, xmm12
0000796caedd0335  jnz 0x0000796CAEDD566F
0000796caedd033b  movaps [r15+0x120], xmm1
0000796caedd0343  mov eax, 0x430920
0000796caedd0348  movups [r13+rax*1], xmm15
0000796caedd034e  mov eax, 0x430930
0000796caedd0353  movups [r13+rax*1], xmm13
0000796caedd0359  mov eax, 0x430940
0000796caedd035e  movups [r13+rax*1], xmm14
0000796caedd0364  mov eax, 0x430950
0000796caedd0369  movups [r13+rax*1], xmm1
0000796caedd036f  mov eax, [r15+0x108]
0000796caedd0376  sahf
0000796caedd0377  jnz 0x0000796CAEDD03A9
0000796caedd0379  cmp dword ptr [r15+0x318], 0x00
0000796caedd0381  jz 0x0000796CAEDDB900
0000796caedd0387  nop [rax+rax*1], ax
0000796caedd0390  nop [rax+rax*1], eax
0000796caedd0398  mov eax, 0x410444
0000796caedd039d  mov [r15+0x100], rax
0000796caedd03a4  jmp 0x0000796CAEBFE110
0000796caedd03a9  cmp dword ptr [r15+0x318], 0x00
0000796caedd03b1  jz 0x0000796CAEDD57E0
0000796caedd03b7  nop [rax+rax*1], ax
0000796caedd03c0  nop [rax+rax*1], eax
0000796caedd03c8  mov eax, 0x410278
0000796caedd03cd  mov [r15+0x100], rax
0000796caedd03d4  jmp 0x0000796CAEBFE110
0000796caedd03d9  int3
0000796caedd03da  call 0x0000796CAECB52F0
0000796caedd03df  jmp 0x0000796CAEDCF016
0000796caedd03e4  call 0x0000796CAECC4620
0000796caedd03e9  jmp 0x0000796CAEDCF023
0000796caedd03ee  call 0x0000796CAECC33A0
0000796caedd03f3  jmp 0x0000796CAEDCF035
0000796caedd03f8  call 0x0000796CAECC2120
0000796caedd03fd  jmp 0x0000796CAEDCF03F
0000796caedd0402  call 0x0000796CAECC0860
0000796caedd0407  jmp 0x0000796CAEDCF067
0000796caedd040c  call 0x0000796CAECBF5F0
0000796caedd0411  jmp 0x0000796CAEDCF073
0000796caedd0416  call 0x0000796CAECC0860
0000796caedd041b  jmp 0x0000796CAEDCF0A5
0000796caedd0420  call 0x0000796CAECBF5F0
0000796caedd0425  jmp 0x0000796CAEDCF0B1
0000796caedd042a  call 0x0000796CAECC4740
0000796caedd042f  jmp 0x0000796CAEDCF0BE
0000796caedd0434  call 0x0000796CAECB5400
0000796caedd0439  jmp 0x0000796CAEDCF0CB
0000796caedd043e  call 0x0000796CAECB52F0
0000796caedd0443  jmp 0x0000796CAEDCF0D8
0000796caedd0448  call 0x0000796CAECC4620
0000796caedd044d  jmp 0x0000796CAEDCF0E5
0000796caedd0452  call 0x0000796CAECC0860
0000796caedd0457  jmp 0x0000796CAEDCF10D
0000796caedd045c  call 0x0000796CAECBF5F0
0000796caedd0461  jmp 0x0000796CAEDCF119
0000796caedd0466  call 0x0000796CAEC09D70
0000796caedd046b  jmp 0x0000796CAEDCF11F
0000796caedd0470  call 0x0000796CAECBE9C0
0000796caedd0475  jmp 0x0000796CAEDCF129
0000796caedd047a  call 0x0000796CAECC0860
0000796caedd047f  jmp 0x0000796CAEDCF151
0000796caedd0484  call 0x0000796CAECBF5F0
0000796caedd0489  jmp 0x0000796CAEDCF15D
0000796caedd048e  call 0x0000796CAECBD750
0000796caedd0493  jmp 0x0000796CAEDCF16A
0000796caedd0498  call 0x0000796CAECBC4E0
0000796caedd049d  jmp 0x0000796CAEDCF177
0000796caedd04a2  call 0x0000796CAECC4740
0000796caedd04a7  jmp 0x0000796CAEDCF184
0000796caedd04ac  call 0x0000796CAECB5400
0000796caedd04b1  jmp 0x0000796CAEDCF191
0000796caedd04b6  call 0x0000796CAECB52F0
0000796caedd04bb  jmp 0x0000796CAEDCF19E
0000796caedd04c0  call 0x0000796CAECC4620
0000796caedd04c5  jmp 0x0000796CAEDCF1AB
0000796caedd04ca  call 0x0000796CAECC0860
0000796caedd04cf  jmp 0x0000796CAEDCF1BE
0000796caedd04d4  call 0x0000796CAECBB270
0000796caedd04d9  jmp 0x0000796CAEDCF1CB
0000796caedd04de  call 0x0000796CAECBA000
0000796caedd04e3  jmp 0x0000796CAEDCF1D8
0000796caedd04e8  call 0x0000796CAECB8D90
0000796caedd04ed  jmp 0x0000796CAEDCF1E5
0000796caedd04f2  call 0x0000796CAECB8A20
0000796caedd04f7  jmp 0x0000796CAEDCF1F2
0000796caedd04fc  call 0x0000796CAECB5400
0000796caedd0501  jmp 0x0000796CAEDCF1FC
0000796caedd0506  call 0x0000796CAECC2240
0000796caedd050b  jmp 0x0000796CAEDCF206
0000796caedd0510  call 0x0000796CAECB52F0
0000796caedd0515  jmp 0x0000796CAEDCF210
0000796caedd051a  call 0x0000796CAECC2120
0000796caedd051f  jmp 0x0000796CAEDCF21A
0000796caedd0524  call 0x0000796CAECB77B0
0000796caedd0529  jmp 0x0000796CAEDCF224
0000796caedd052e  call 0x0000796CAECB6550
0000796caedd0533  jmp 0x0000796CAEDCF22E
0000796caedd0538  call 0x0000796CAECBFD50
0000796caedd053d  jmp 0x0000796CAEDCF240
0000796caedd0542  call 0x0000796CAECB8EA0
0000796caedd0547  jmp 0x0000796CAEDCF24A
0000796caedd054c  call 0x0000796CAECBFC30
0000796caedd0551  jmp 0x0000796CAEDCF257
0000796caedd0556  call 0x0000796CAECB8D90
0000796caedd055b  jmp 0x0000796CAEDCF264
0000796caedd0560  call 0x0000796CAECC2240
0000796caedd0565  jmp 0x0000796CAEDCF271
0000796caedd056a  call 0x0000796CAECB5400
0000796caedd056f  jmp 0x0000796CAEDCF27E
0000796caedd0574  call 0x0000796CAECB52F0
0000796caedd0579  jmp 0x0000796CAEDCF28B
0000796caedd057e  call 0x0000796CAECC2120
0000796caedd0583  jmp 0x0000796CAEDCF298
0000796caedd0588  call 0x0000796CAECB52F0
0000796caedd058d  jmp 0x0000796CAEDCF2AB
0000796caedd0592  call 0x0000796CAECB52F0
0000796caedd0597  jmp 0x0000796CAEDCF2BE
0000796caedd059c  call 0x0000796CAECB52F0
0000796caedd05a1  jmp 0x0000796CAEDCF2D1
0000796caedd05a6  call 0x0000796CAECB52F0
0000796caedd05ab  jmp 0x0000796CAEDCF2E4
0000796caedd05b0  call 0x0000796CAECC2240
0000796caedd05b5  jmp 0x0000796CAEDCF2F9
0000796caedd05ba  call 0x0000796CAECC2240
0000796caedd05bf  jmp 0x0000796CAEDCF30C
0000796caedd05c4  call 0x0000796CAECC2120
0000796caedd05c9  jmp 0x0000796CAEDCF319
0000796caedd05ce  call 0x0000796CAECB52F0
0000796caedd05d3  jmp 0x0000796CAEDCF32C
0000796caedd05d8  call 0x0000796CAECB52F0
0000796caedd05dd  jmp 0x0000796CAEDCF34F
0000796caedd05e2  call 0x0000796CAECB52F0
0000796caedd05e7  jmp 0x0000796CAEDCF362
0000796caedd05ec  call 0x0000796CAEBFF540
0000796caedd05f1  jmp 0x0000796CAEDCF380
0000796caedd05f6  call 0x0000796CAEC08C20
0000796caedd05fb  jmp 0x0000796CAEDCF38A
0000796caedd0600  call 0x0000796CAECD6600
0000796caedd0605  jmp 0x0000796CAEDCF396
0000796caedd060a  call 0x0000796CAEBFF540
0000796caedd060f  jmp 0x0000796CAEDCF3A6
0000796caedd0614  call 0x0000796CAECC0370
0000796caedd0619  jmp 0x0000796CAEDCF3D4
0000796caedd061e  call 0x0000796CAECBF100
0000796caedd0623  jmp 0x0000796CAEDCF3DD
0000796caedd0628  call 0x0000796CAECC0370
0000796caedd062d  jmp 0x0000796CAEDCF43B
0000796caedd0632  call 0x0000796CAECBF100
0000796caedd0637  jmp 0x0000796CAEDCF444
0000796caedd063c  call 0x0000796CAECC0370
0000796caedd0641  jmp 0x0000796CAEDCF48B
0000796caedd0646  call 0x0000796CAECBF100
0000796caedd064b  jmp 0x0000796CAEDCF494
0000796caedd0650  call 0x0000796CAEC0B720
0000796caedd0655  jmp 0x0000796CAEDCF4D7
0000796caedd065a  call 0x0000796CAECB47C0
0000796caedd065f  jmp 0x0000796CAEDCF4EA
0000796caedd0664  call 0x0000796CAEC08B00
0000796caedd0669  jmp 0x0000796CAEDCF501
0000796caedd066e  call 0x0000796CAEBFF430
0000796caedd0673  jmp 0x0000796CAEDCF514
0000796caedd0678  call 0x0000796CAEBFF430
0000796caedd067d  jmp 0x0000796CAEDCF527
0000796caedd0682  sub rsp, 0x08
0000796caedd0686  push rax
0000796caedd0687  push rcx
0000796caedd0688  push rdx
0000796caedd0689  push rdi
0000796caedd068a  push rsi
0000796caedd068b  push r8
0000796caedd068d  push r9
0000796caedd068f  push r10
0000796caedd0691  push r11
0000796caedd0693  sub rsp, 0xF0
0000796caedd069a  vmovaps [rsp], xmm0
0000796caedd069f  vmovaps [rsp+0x10], xmm2
0000796caedd06a5  vmovaps [rsp+0x20], xmm3
0000796caedd06ab  vmovaps [rsp+0x30], xmm4
0000796caedd06b1  vmovaps [rsp+0x40], xmm5
0000796caedd06b7  vmovaps [rsp+0x50], xmm6
0000796caedd06bd  vmovaps [rsp+0x60], xmm7
0000796caedd06c3  vmovaps [rsp+0x70], xmm8
0000796caedd06c9  vmovaps [rsp+0x80], xmm9
0000796caedd06d2  vmovaps [rsp+0x90], xmm10
0000796caedd06db  vmovaps [rsp+0xA0], xmm11
0000796caedd06e4  vmovaps [rsp+0xB0], xmm12
0000796caedd06ed  vmovaps [rsp+0xC0], xmm13
0000796caedd06f6  vmovaps [rsp+0xD0], xmm14
0000796caedd06ff  vmovaps [rsp+0xE0], xmm15
0000796caedd0708  sub rsp, 0x30
0000796caedd070c  movaps [rsp], xmm1
0000796caedd0710  movaps [rsp+0x10], xmm15
0000796caedd0716  movaps [rsp+0x20], xmm14
0000796caedd071c  lea rdi, [rsp]
0000796caedd0720  mov esi, 0x00
0000796caedd0725  mov rax, 0x56877063A530
0000796caedd072f  call rax
0000796caedd0731  movaps xmm1, [rsp]
0000796caedd0735  add rsp, 0x30
0000796caedd0739  vmovaps xmm0, [rsp]
0000796caedd073e  vmovaps xmm2, [rsp+0x10]
0000796caedd0744  vmovaps xmm3, [rsp+0x20]
0000796caedd074a  vmovaps xmm4, [rsp+0x30]
0000796caedd0750  vmovaps xmm5, [rsp+0x40]
0000796caedd0756  vmovaps xmm6, [rsp+0x50]
0000796caedd075c  vmovaps xmm7, [rsp+0x60]
0000796caedd0762  vmovaps xmm8, [rsp+0x70]
0000796caedd0768  vmovaps xmm9, [rsp+0x80]
0000796caedd0771  vmovaps xmm10, [rsp+0x90]
0000796caedd077a  vmovaps xmm11, [rsp+0xA0]
0000796caedd0783  vmovaps xmm12, [rsp+0xB0]
0000796caedd078c  vmovaps xmm13, [rsp+0xC0]
0000796caedd0795  vmovaps xmm14, [rsp+0xD0]
0000796caedd079e  vmovaps xmm15, [rsp+0xE0]
0000796caedd07a7  add rsp, 0xF0
0000796caedd07ae  pop r11
0000796caedd07b0  pop r10
0000796caedd07b2  pop r9
0000796caedd07b4  pop r8
0000796caedd07b6  pop rsi
0000796caedd07b7  pop rdi
0000796caedd07b8  pop rdx
0000796caedd07b9  pop rcx
0000796caedd07ba  pop rax
0000796caedd07bb  add rsp, 0x08
0000796caedd07bf  jmp 0x0000796CAEDCF581
0000796caedd07c4  sub rsp, 0x08
0000796caedd07c8  push rax
0000796caedd07c9  push rcx
0000796caedd07ca  push rdx
0000796caedd07cb  push rdi
0000796caedd07cc  push rsi
0000796caedd07cd  push r8
0000796caedd07cf  push r9
0000796caedd07d1  push r10
0000796caedd07d3  push r11
0000796caedd07d5  sub rsp, 0xF0
0000796caedd07dc  vmovaps [rsp], xmm0
0000796caedd07e1  vmovaps [rsp+0x10], xmm1
0000796caedd07e7  vmovaps [rsp+0x20], xmm2
0000796caedd07ed  vmovaps [rsp+0x30], xmm3
0000796caedd07f3  vmovaps [rsp+0x40], xmm4
0000796caedd07f9  vmovaps [rsp+0x50], xmm5
0000796caedd07ff  vmovaps [rsp+0x60], xmm6
0000796caedd0805  vmovaps [rsp+0x70], xmm7
0000796caedd080b  vmovaps [rsp+0x80], xmm8
0000796caedd0814  vmovaps [rsp+0x90], xmm9
0000796caedd081d  vmovaps [rsp+0xA0], xmm10
0000796caedd0826  vmovaps [rsp+0xB0], xmm11
0000796caedd082f  vmovaps [rsp+0xC0], xmm12
0000796caedd0838  vmovaps [rsp+0xD0], xmm14
0000796caedd0841  vmovaps [rsp+0xE0], xmm15
0000796caedd084a  sub rsp, 0x30
0000796caedd084e  movaps [rsp], xmm13
0000796caedd0853  movaps [rsp+0x10], xmm1
0000796caedd0858  movaps [rsp+0x20], xmm14
0000796caedd085e  lea rdi, [rsp]
0000796caedd0862  mov esi, 0x00
0000796caedd0867  mov rax, 0x56877063A530
0000796caedd0871  call rax
0000796caedd0873  movaps xmm13, [rsp]
0000796caedd0878  add rsp, 0x30
0000796caedd087c  vmovaps xmm0, [rsp]
0000796caedd0881  vmovaps xmm1, [rsp+0x10]
0000796caedd0887  vmovaps xmm2, [rsp+0x20]
0000796caedd088d  vmovaps xmm3, [rsp+0x30]
0000796caedd0893  vmovaps xmm4, [rsp+0x40]
0000796caedd0899  vmovaps xmm5, [rsp+0x50]
0000796caedd089f  vmovaps xmm6, [rsp+0x60]
0000796caedd08a5  vmovaps xmm7, [rsp+0x70]
0000796caedd08ab  vmovaps xmm8, [rsp+0x80]
0000796caedd08b4  vmovaps xmm9, [rsp+0x90]
0000796caedd08bd  vmovaps xmm10, [rsp+0xA0]
0000796caedd08c6  vmovaps xmm11, [rsp+0xB0]
0000796caedd08cf  vmovaps xmm12, [rsp+0xC0]
0000796caedd08d8  vmovaps xmm14, [rsp+0xD0]
0000796caedd08e1  vmovaps xmm15, [rsp+0xE0]
0000796caedd08ea  add rsp, 0xF0
0000796caedd08f1  pop r11
0000796caedd08f3  pop r10
0000796caedd08f5  pop r9
0000796caedd08f7  pop r8
0000796caedd08f9  pop rsi
0000796caedd08fa  pop rdi
0000796caedd08fb  pop rdx
0000796caedd08fc  pop rcx
0000796caedd08fd  pop rax
0000796caedd08fe  add rsp, 0x08
0000796caedd0902  jmp 0x0000796CAEDCF5CF
0000796caedd0907  sub rsp, 0x08
0000796caedd090b  push rax
0000796caedd090c  push rcx
0000796caedd090d  push rdx
0000796caedd090e  push rdi
0000796caedd090f  push rsi
0000796caedd0910  push r8
0000796caedd0912  push r9
0000796caedd0914  push r10
0000796caedd0916  push r11
0000796caedd0918  sub rsp, 0xF0
0000796caedd091f  vmovaps [rsp], xmm0
0000796caedd0924  vmovaps [rsp+0x10], xmm1
0000796caedd092a  vmovaps [rsp+0x20], xmm2
0000796caedd0930  vmovaps [rsp+0x30], xmm3
0000796caedd0936  vmovaps [rsp+0x40], xmm4
0000796caedd093c  vmovaps [rsp+0x50], xmm5
0000796caedd0942  vmovaps [rsp+0x60], xmm6
0000796caedd0948  vmovaps [rsp+0x70], xmm7
0000796caedd094e  vmovaps [rsp+0x80], xmm8
0000796caedd0957  vmovaps [rsp+0x90], xmm9
0000796caedd0960  vmovaps [rsp+0xA0], xmm10
0000796caedd0969  vmovaps [rsp+0xB0], xmm11
0000796caedd0972  vmovaps [rsp+0xC0], xmm12
0000796caedd097b  vmovaps [rsp+0xD0], xmm13
0000796caedd0984  vmovaps [rsp+0xE0], xmm14
0000796caedd098d  sub rsp, 0x30
0000796caedd0991  movaps [rsp], xmm15
0000796caedd0996  movaps [rsp+0x10], xmm14
0000796caedd099c  movaps [rsp+0x20], xmm1
0000796caedd09a1  lea rdi, [rsp]
0000796caedd09a5  mov esi, 0x00
0000796caedd09aa  mov rax, 0x56877063A530
0000796caedd09b4  call rax
0000796caedd09b6  movaps xmm15, [rsp]
0000796caedd09bb  add rsp, 0x30
0000796caedd09bf  vmovaps xmm0, [rsp]
0000796caedd09c4  vmovaps xmm1, [rsp+0x10]
0000796caedd09ca  vmovaps xmm2, [rsp+0x20]
0000796caedd09d0  vmovaps xmm3, [rsp+0x30]
0000796caedd09d6  vmovaps xmm4, [rsp+0x40]
0000796caedd09dc  vmovaps xmm5, [rsp+0x50]
0000796caedd09e2  vmovaps xmm6, [rsp+0x60]
0000796caedd09e8  vmovaps xmm7, [rsp+0x70]
0000796caedd09ee  vmovaps xmm8, [rsp+0x80]
0000796caedd09f7  vmovaps xmm9, [rsp+0x90]
0000796caedd0a00  vmovaps xmm10, [rsp+0xA0]
0000796caedd0a09  vmovaps xmm11, [rsp+0xB0]
0000796caedd0a12  vmovaps xmm12, [rsp+0xC0]
0000796caedd0a1b  vmovaps xmm13, [rsp+0xD0]
0000796caedd0a24  vmovaps xmm14, [rsp+0xE0]
0000796caedd0a2d  add rsp, 0xF0
0000796caedd0a34  pop r11
0000796caedd0a36  pop r10
0000796caedd0a38  pop r9
0000796caedd0a3a  pop r8
0000796caedd0a3c  pop rsi
0000796caedd0a3d  pop rdi
0000796caedd0a3e  pop rdx
0000796caedd0a3f  pop rcx
0000796caedd0a40  pop rax
0000796caedd0a41  add rsp, 0x08
0000796caedd0a45  jmp 0x0000796CAEDCF617
0000796caedd0a4a  sub rsp, 0x08
0000796caedd0a4e  push rax
0000796caedd0a4f  push rcx
0000796caedd0a50  push rdx
0000796caedd0a51  push rdi
0000796caedd0a52  push rsi
0000796caedd0a53  push r8
0000796caedd0a55  push r9
0000796caedd0a57  push r10
0000796caedd0a59  push r11
0000796caedd0a5b  sub rsp, 0xF0
0000796caedd0a62  vmovaps [rsp], xmm0
0000796caedd0a67  vmovaps [rsp+0x10], xmm2
0000796caedd0a6d  vmovaps [rsp+0x20], xmm3
0000796caedd0a73  vmovaps [rsp+0x30], xmm4
0000796caedd0a79  vmovaps [rsp+0x40], xmm5
0000796caedd0a7f  vmovaps [rsp+0x50], xmm6
0000796caedd0a85  vmovaps [rsp+0x60], xmm7
0000796caedd0a8b  vmovaps [rsp+0x70], xmm8
0000796caedd0a91  vmovaps [rsp+0x80], xmm9
0000796caedd0a9a  vmovaps [rsp+0x90], xmm10
0000796caedd0aa3  vmovaps [rsp+0xA0], xmm11
0000796caedd0aac  vmovaps [rsp+0xB0], xmm12
0000796caedd0ab5  vmovaps [rsp+0xC0], xmm13
0000796caedd0abe  vmovaps [rsp+0xD0], xmm14
0000796caedd0ac7  vmovaps [rsp+0xE0], xmm15
0000796caedd0ad0  sub rsp, 0x30
0000796caedd0ad4  movaps [rsp], xmm1
0000796caedd0ad8  movaps [rsp+0x10], xmm14
0000796caedd0ade  movaps [rsp+0x20], xmm10
0000796caedd0ae4  lea rdi, [rsp]
0000796caedd0ae8  mov esi, 0x00
0000796caedd0aed  mov rax, 0x56877063A530
0000796caedd0af7  call rax
0000796caedd0af9  movaps xmm1, [rsp]
0000796caedd0afd  add rsp, 0x30
0000796caedd0b01  vmovaps xmm0, [rsp]
0000796caedd0b06  vmovaps xmm2, [rsp+0x10]
0000796caedd0b0c  vmovaps xmm3, [rsp+0x20]
0000796caedd0b12  vmovaps xmm4, [rsp+0x30]
0000796caedd0b18  vmovaps xmm5, [rsp+0x40]
0000796caedd0b1e  vmovaps xmm6, [rsp+0x50]
0000796caedd0b24  vmovaps xmm7, [rsp+0x60]
0000796caedd0b2a  vmovaps xmm8, [rsp+0x70]
0000796caedd0b30  vmovaps xmm9, [rsp+0x80]
0000796caedd0b39  vmovaps xmm10, [rsp+0x90]
0000796caedd0b42  vmovaps xmm11, [rsp+0xA0]
0000796caedd0b4b  vmovaps xmm12, [rsp+0xB0]
0000796caedd0b54  vmovaps xmm13, [rsp+0xC0]
0000796caedd0b5d  vmovaps xmm14, [rsp+0xD0]
0000796caedd0b66  vmovaps xmm15, [rsp+0xE0]
0000796caedd0b6f  add rsp, 0xF0
0000796caedd0b76  pop r11
0000796caedd0b78  pop r10
0000796caedd0b7a  pop r9
0000796caedd0b7c  pop r8
0000796caedd0b7e  pop rsi
0000796caedd0b7f  pop rdi
0000796caedd0b80  pop rdx
0000796caedd0b81  pop rcx
0000796caedd0b82  pop rax
0000796caedd0b83  add rsp, 0x08
0000796caedd0b87  jmp 0x0000796CAEDCF631
0000796caedd0b8c  sub rsp, 0x08
0000796caedd0b90  push rax
0000796caedd0b91  push rcx
0000796caedd0b92  push rdx
0000796caedd0b93  push rdi
0000796caedd0b94  push rsi
0000796caedd0b95  push r8
0000796caedd0b97  push r9
0000796caedd0b99  push r10
0000796caedd0b9b  push r11
0000796caedd0b9d  sub rsp, 0xF0
0000796caedd0ba4  vmovaps [rsp], xmm0
0000796caedd0ba9  vmovaps [rsp+0x10], xmm1
0000796caedd0baf  vmovaps [rsp+0x20], xmm2
0000796caedd0bb5  vmovaps [rsp+0x30], xmm3
0000796caedd0bbb  vmovaps [rsp+0x40], xmm4
0000796caedd0bc1  vmovaps [rsp+0x50], xmm5
0000796caedd0bc7  vmovaps [rsp+0x60], xmm6
0000796caedd0bcd  vmovaps [rsp+0x70], xmm7
0000796caedd0bd3  vmovaps [rsp+0x80], xmm8
0000796caedd0bdc  vmovaps [rsp+0x90], xmm9
0000796caedd0be5  vmovaps [rsp+0xA0], xmm10
0000796caedd0bee  vmovaps [rsp+0xB0], xmm11
0000796caedd0bf7  vmovaps [rsp+0xC0], xmm12
0000796caedd0c00  vmovaps [rsp+0xD0], xmm14
0000796caedd0c09  vmovaps [rsp+0xE0], xmm15
0000796caedd0c12  sub rsp, 0x30
0000796caedd0c16  movaps [rsp], xmm13
0000796caedd0c1b  movaps [rsp+0x10], xmm14
0000796caedd0c21  movaps [rsp+0x20], xmm2
0000796caedd0c26  lea rdi, [rsp]
0000796caedd0c2a  mov esi, 0x00
0000796caedd0c2f  mov rax, 0x56877063A530
0000796caedd0c39  call rax
0000796caedd0c3b  movaps xmm13, [rsp]
0000796caedd0c40  add rsp, 0x30
0000796caedd0c44  vmovaps xmm0, [rsp]
0000796caedd0c49  vmovaps xmm1, [rsp+0x10]
0000796caedd0c4f  vmovaps xmm2, [rsp+0x20]
0000796caedd0c55  vmovaps xmm3, [rsp+0x30]
0000796caedd0c5b  vmovaps xmm4, [rsp+0x40]
0000796caedd0c61  vmovaps xmm5, [rsp+0x50]
0000796caedd0c67  vmovaps xmm6, [rsp+0x60]
0000796caedd0c6d  vmovaps xmm7, [rsp+0x70]
0000796caedd0c73  vmovaps xmm8, [rsp+0x80]
0000796caedd0c7c  vmovaps xmm9, [rsp+0x90]
0000796caedd0c85  vmovaps xmm10, [rsp+0xA0]
0000796caedd0c8e  vmovaps xmm11, [rsp+0xB0]
0000796caedd0c97  vmovaps xmm12, [rsp+0xC0]
0000796caedd0ca0  vmovaps xmm14, [rsp+0xD0]
0000796caedd0ca9  vmovaps xmm15, [rsp+0xE0]
0000796caedd0cb2  add rsp, 0xF0
0000796caedd0cb9  pop r11
0000796caedd0cbb  pop r10
0000796caedd0cbd  pop r9
0000796caedd0cbf  pop r8
0000796caedd0cc1  pop rsi
0000796caedd0cc2  pop rdi
0000796caedd0cc3  pop rdx
0000796caedd0cc4  pop rcx
0000796caedd0cc5  pop rax
0000796caedd0cc6  add rsp, 0x08
0000796caedd0cca  jmp 0x0000796CAEDCF64C
0000796caedd0ccf  sub rsp, 0x08
0000796caedd0cd3  push rax
0000796caedd0cd4  push rcx
0000796caedd0cd5  push rdx
0000796caedd0cd6  push rdi
0000796caedd0cd7  push rsi
0000796caedd0cd8  push r8
0000796caedd0cda  push r9
0000796caedd0cdc  push r10
0000796caedd0cde  push r11
0000796caedd0ce0  sub rsp, 0xF0
0000796caedd0ce7  vmovaps [rsp], xmm0
0000796caedd0cec  vmovaps [rsp+0x10], xmm2
0000796caedd0cf2  vmovaps [rsp+0x20], xmm3
0000796caedd0cf8  vmovaps [rsp+0x30], xmm4
0000796caedd0cfe  vmovaps [rsp+0x40], xmm5
0000796caedd0d04  vmovaps [rsp+0x50], xmm6
0000796caedd0d0a  vmovaps [rsp+0x60], xmm7
0000796caedd0d10  vmovaps [rsp+0x70], xmm8
0000796caedd0d16  vmovaps [rsp+0x80], xmm9
0000796caedd0d1f  vmovaps [rsp+0x90], xmm10
0000796caedd0d28  vmovaps [rsp+0xA0], xmm11
0000796caedd0d31  vmovaps [rsp+0xB0], xmm12
0000796caedd0d3a  vmovaps [rsp+0xC0], xmm13
0000796caedd0d43  vmovaps [rsp+0xD0], xmm14
0000796caedd0d4c  vmovaps [rsp+0xE0], xmm15
0000796caedd0d55  sub rsp, 0x30
0000796caedd0d59  movaps [rsp], xmm1
0000796caedd0d5d  movaps [rsp+0x10], xmm10
0000796caedd0d63  movaps [rsp+0x20], xmm2
0000796caedd0d68  lea rdi, [rsp]
0000796caedd0d6c  mov esi, 0x00
0000796caedd0d71  mov rax, 0x56877063A530
0000796caedd0d7b  call rax
0000796caedd0d7d  movaps xmm1, [rsp]
0000796caedd0d81  add rsp, 0x30
0000796caedd0d85  vmovaps xmm0, [rsp]
0000796caedd0d8a  vmovaps xmm2, [rsp+0x10]
0000796caedd0d90  vmovaps xmm3, [rsp+0x20]
0000796caedd0d96  vmovaps xmm4, [rsp+0x30]
0000796caedd0d9c  vmovaps xmm5, [rsp+0x40]
0000796caedd0da2  vmovaps xmm6, [rsp+0x50]
0000796caedd0da8  vmovaps xmm7, [rsp+0x60]
0000796caedd0dae  vmovaps xmm8, [rsp+0x70]
0000796caedd0db4  vmovaps xmm9, [rsp+0x80]
0000796caedd0dbd  vmovaps xmm10, [rsp+0x90]
0000796caedd0dc6  vmovaps xmm11, [rsp+0xA0]
0000796caedd0dcf  vmovaps xmm12, [rsp+0xB0]
0000796caedd0dd8  vmovaps xmm13, [rsp+0xC0]
0000796caedd0de1  vmovaps xmm14, [rsp+0xD0]
0000796caedd0dea  vmovaps xmm15, [rsp+0xE0]
0000796caedd0df3  add rsp, 0xF0
0000796caedd0dfa  pop r11
0000796caedd0dfc  pop r10
0000796caedd0dfe  pop r9
0000796caedd0e00  pop r8
0000796caedd0e02  pop rsi
0000796caedd0e03  pop rdi
0000796caedd0e04  pop rdx
0000796caedd0e05  pop rcx
0000796caedd0e06  pop rax
0000796caedd0e07  add rsp, 0x08
0000796caedd0e0b  jmp 0x0000796CAEDCF6B4
0000796caedd0e10  sub rsp, 0x08
0000796caedd0e14  push rax
0000796caedd0e15  push rcx
0000796caedd0e16  push rdx
0000796caedd0e17  push rdi
0000796caedd0e18  push rsi
0000796caedd0e19  push r8
0000796caedd0e1b  push r9
0000796caedd0e1d  push r10
0000796caedd0e1f  push r11
0000796caedd0e21  sub rsp, 0xF0
0000796caedd0e28  vmovaps [rsp], xmm0
0000796caedd0e2d  vmovaps [rsp+0x10], xmm1
0000796caedd0e33  vmovaps [rsp+0x20], xmm2
0000796caedd0e39  vmovaps [rsp+0x30], xmm3
0000796caedd0e3f  vmovaps [rsp+0x40], xmm4
0000796caedd0e45  vmovaps [rsp+0x50], xmm5
0000796caedd0e4b  vmovaps [rsp+0x60], xmm6
0000796caedd0e51  vmovaps [rsp+0x70], xmm7
0000796caedd0e57  vmovaps [rsp+0x80], xmm8
0000796caedd0e60  vmovaps [rsp+0x90], xmm9
0000796caedd0e69  vmovaps [rsp+0xA0], xmm10
0000796caedd0e72  vmovaps [rsp+0xB0], xmm11
0000796caedd0e7b  vmovaps [rsp+0xC0], xmm12
0000796caedd0e84  vmovaps [rsp+0xD0], xmm13
0000796caedd0e8d  vmovaps [rsp+0xE0], xmm14
0000796caedd0e96  sub rsp, 0x30
0000796caedd0e9a  movaps [rsp], xmm15
0000796caedd0e9f  movaps [rsp+0x10], xmm10
0000796caedd0ea5  movaps [rsp+0x20], xmm2
0000796caedd0eaa  lea rdi, [rsp]
0000796caedd0eae  mov esi, 0x00
0000796caedd0eb3  mov rax, 0x56877063A530
0000796caedd0ebd  call rax
0000796caedd0ebf  movaps xmm15, [rsp]
0000796caedd0ec4  add rsp, 0x30
0000796caedd0ec8  vmovaps xmm0, [rsp]
0000796caedd0ecd  vmovaps xmm1, [rsp+0x10]
0000796caedd0ed3  vmovaps xmm2, [rsp+0x20]
0000796caedd0ed9  vmovaps xmm3, [rsp+0x30]
0000796caedd0edf  vmovaps xmm4, [rsp+0x40]
0000796caedd0ee5  vmovaps xmm5, [rsp+0x50]
0000796caedd0eeb  vmovaps xmm6, [rsp+0x60]
0000796caedd0ef1  vmovaps xmm7, [rsp+0x70]
0000796caedd0ef7  vmovaps xmm8, [rsp+0x80]
0000796caedd0f00  vmovaps xmm9, [rsp+0x90]
0000796caedd0f09  vmovaps xmm10, [rsp+0xA0]
0000796caedd0f12  vmovaps xmm11, [rsp+0xB0]
0000796caedd0f1b  vmovaps xmm12, [rsp+0xC0]
0000796caedd0f24  vmovaps xmm13, [rsp+0xD0]
0000796caedd0f2d  vmovaps xmm14, [rsp+0xE0]
0000796caedd0f36  add rsp, 0xF0
0000796caedd0f3d  pop r11
0000796caedd0f3f  pop r10
0000796caedd0f41  pop r9
0000796caedd0f43  pop r8
0000796caedd0f45  pop rsi
0000796caedd0f46  pop rdi
0000796caedd0f47  pop rdx
0000796caedd0f48  pop rcx
0000796caedd0f49  pop rax
0000796caedd0f4a  add rsp, 0x08
0000796caedd0f4e  jmp 0x0000796CAEDCF706
0000796caedd0f53  sub rsp, 0x08
0000796caedd0f57  push rax
0000796caedd0f58  push rcx
0000796caedd0f59  push rdx
0000796caedd0f5a  push rdi
0000796caedd0f5b  push rsi
0000796caedd0f5c  push r8
0000796caedd0f5e  push r9
0000796caedd0f60  push r10
0000796caedd0f62  push r11
0000796caedd0f64  sub rsp, 0xF0
0000796caedd0f6b  vmovaps [rsp], xmm0
0000796caedd0f70  vmovaps [rsp+0x10], xmm2
0000796caedd0f76  vmovaps [rsp+0x20], xmm3
0000796caedd0f7c  vmovaps [rsp+0x30], xmm4
0000796caedd0f82  vmovaps [rsp+0x40], xmm5
0000796caedd0f88  vmovaps [rsp+0x50], xmm6
0000796caedd0f8e  vmovaps [rsp+0x60], xmm7
0000796caedd0f94  vmovaps [rsp+0x70], xmm8
0000796caedd0f9a  vmovaps [rsp+0x80], xmm9
0000796caedd0fa3  vmovaps [rsp+0x90], xmm10
0000796caedd0fac  vmovaps [rsp+0xA0], xmm11
0000796caedd0fb5  vmovaps [rsp+0xB0], xmm12
0000796caedd0fbe  vmovaps [rsp+0xC0], xmm13
0000796caedd0fc7  vmovaps [rsp+0xD0], xmm14
0000796caedd0fd0  vmovaps [rsp+0xE0], xmm15
0000796caedd0fd9  sub rsp, 0x30
0000796caedd0fdd  movaps [rsp], xmm1
0000796caedd0fe1  movaps [rsp+0x10], xmm10
0000796caedd0fe7  movaps [rsp+0x20], xmm12
0000796caedd0fed  lea rdi, [rsp]
0000796caedd0ff1  mov esi, 0x00
0000796caedd0ff6  mov rax, 0x56877063A530
0000796caedd1000  call rax
0000796caedd1002  movaps xmm1, [rsp]
0000796caedd1006  add rsp, 0x30
0000796caedd100a  vmovaps xmm0, [rsp]
0000796caedd100f  vmovaps xmm2, [rsp+0x10]
0000796caedd1015  vmovaps xmm3, [rsp+0x20]
0000796caedd101b  vmovaps xmm4, [rsp+0x30]
0000796caedd1021  vmovaps xmm5, [rsp+0x40]
0000796caedd1027  vmovaps xmm6, [rsp+0x50]
0000796caedd102d  vmovaps xmm7, [rsp+0x60]
0000796caedd1033  vmovaps xmm8, [rsp+0x70]
0000796caedd1039  vmovaps xmm9, [rsp+0x80]
0000796caedd1042  vmovaps xmm10, [rsp+0x90]
0000796caedd104b  vmovaps xmm11, [rsp+0xA0]
0000796caedd1054  vmovaps xmm12, [rsp+0xB0]
0000796caedd105d  vmovaps xmm13, [rsp+0xC0]
0000796caedd1066  vmovaps xmm14, [rsp+0xD0]
0000796caedd106f  vmovaps xmm15, [rsp+0xE0]
0000796caedd1078  add rsp, 0xF0
0000796caedd107f  pop r11
0000796caedd1081  pop r10
0000796caedd1083  pop r9
0000796caedd1085  pop r8
0000796caedd1087  pop rsi
0000796caedd1088  pop rdi
0000796caedd1089  pop rdx
0000796caedd108a  pop rcx
0000796caedd108b  pop rax
0000796caedd108c  add rsp, 0x08
0000796caedd1090  jmp 0x0000796CAEDCF732
0000796caedd1095  sub rsp, 0x08
0000796caedd1099  push rax
0000796caedd109a  push rcx
0000796caedd109b  push rdx
0000796caedd109c  push rdi
0000796caedd109d  push rsi
0000796caedd109e  push r8
0000796caedd10a0  push r9
0000796caedd10a2  push r10
0000796caedd10a4  push r11
0000796caedd10a6  sub rsp, 0xF0
0000796caedd10ad  vmovaps [rsp], xmm0
0000796caedd10b2  vmovaps [rsp+0x10], xmm1
0000796caedd10b8  vmovaps [rsp+0x20], xmm2
0000796caedd10be  vmovaps [rsp+0x30], xmm3
0000796caedd10c4  vmovaps [rsp+0x40], xmm4
0000796caedd10ca  vmovaps [rsp+0x50], xmm5
0000796caedd10d0  vmovaps [rsp+0x60], xmm6
0000796caedd10d6  vmovaps [rsp+0x70], xmm7
0000796caedd10dc  vmovaps [rsp+0x80], xmm8
0000796caedd10e5  vmovaps [rsp+0x90], xmm9
0000796caedd10ee  vmovaps [rsp+0xA0], xmm10
0000796caedd10f7  vmovaps [rsp+0xB0], xmm11
0000796caedd1100  vmovaps [rsp+0xC0], xmm12
0000796caedd1109  vmovaps [rsp+0xD0], xmm13
0000796caedd1112  vmovaps [rsp+0xE0], xmm14
0000796caedd111b  sub rsp, 0x30
0000796caedd111f  movaps [rsp], xmm15
0000796caedd1124  movaps [rsp+0x10], xmm10
0000796caedd112a  movaps [rsp+0x20], xmm12
0000796caedd1130  lea rdi, [rsp]
0000796caedd1134  mov esi, 0x00
0000796caedd1139  mov rax, 0x56877063A530
0000796caedd1143  call rax
0000796caedd1145  movaps xmm15, [rsp]
0000796caedd114a  add rsp, 0x30
0000796caedd114e  vmovaps xmm0, [rsp]
0000796caedd1153  vmovaps xmm1, [rsp+0x10]
0000796caedd1159  vmovaps xmm2, [rsp+0x20]
0000796caedd115f  vmovaps xmm3, [rsp+0x30]
0000796caedd1165  vmovaps xmm4, [rsp+0x40]
0000796caedd116b  vmovaps xmm5, [rsp+0x50]
0000796caedd1171  vmovaps xmm6, [rsp+0x60]
0000796caedd1177  vmovaps xmm7, [rsp+0x70]
0000796caedd117d  vmovaps xmm8, [rsp+0x80]
0000796caedd1186  vmovaps xmm9, [rsp+0x90]
0000796caedd118f  vmovaps xmm10, [rsp+0xA0]
0000796caedd1198  vmovaps xmm11, [rsp+0xB0]
0000796caedd11a1  vmovaps xmm12, [rsp+0xC0]
0000796caedd11aa  vmovaps xmm13, [rsp+0xD0]
0000796caedd11b3  vmovaps xmm14, [rsp+0xE0]
0000796caedd11bc  add rsp, 0xF0
0000796caedd11c3  pop r11
0000796caedd11c5  pop r10
0000796caedd11c7  pop r9
0000796caedd11c9  pop r8
0000796caedd11cb  pop rsi
0000796caedd11cc  pop rdi
0000796caedd11cd  pop rdx
0000796caedd11ce  pop rcx
0000796caedd11cf  pop rax
0000796caedd11d0  add rsp, 0x08
0000796caedd11d4  jmp 0x0000796CAEDCF75E
0000796caedd11d9  call 0x0000796CAEBFF430
0000796caedd11de  jmp 0x0000796CAEDCF7EE
0000796caedd11e3  call 0x0000796CAEBFF430
0000796caedd11e8  jmp 0x0000796CAEDCF801
0000796caedd11ed  sub rsp, 0x08
0000796caedd11f1  push rax
0000796caedd11f2  push rcx
0000796caedd11f3  push rdx
0000796caedd11f4  push rdi
0000796caedd11f5  push rsi
0000796caedd11f6  push r8
0000796caedd11f8  push r9
0000796caedd11fa  push r10
0000796caedd11fc  push r11
0000796caedd11fe  sub rsp, 0xF0
0000796caedd1205  vmovaps [rsp], xmm0
0000796caedd120a  vmovaps [rsp+0x10], xmm2
0000796caedd1210  vmovaps [rsp+0x20], xmm3
0000796caedd1216  vmovaps [rsp+0x30], xmm4
0000796caedd121c  vmovaps [rsp+0x40], xmm5
0000796caedd1222  vmovaps [rsp+0x50], xmm6
0000796caedd1228  vmovaps [rsp+0x60], xmm7
0000796caedd122e  vmovaps [rsp+0x70], xmm8
0000796caedd1234  vmovaps [rsp+0x80], xmm9
0000796caedd123d  vmovaps [rsp+0x90], xmm10
0000796caedd1246  vmovaps [rsp+0xA0], xmm11
0000796caedd124f  vmovaps [rsp+0xB0], xmm12
0000796caedd1258  vmovaps [rsp+0xC0], xmm13
0000796caedd1261  vmovaps [rsp+0xD0], xmm14
0000796caedd126a  vmovaps [rsp+0xE0], xmm15
0000796caedd1273  sub rsp, 0x30
0000796caedd1277  movaps [rsp], xmm1
0000796caedd127b  movaps [rsp+0x10], xmm13
0000796caedd1281  movaps [rsp+0x20], xmm2
0000796caedd1286  lea rdi, [rsp]
0000796caedd128a  mov esi, 0x00
0000796caedd128f  mov rax, 0x56877063A530
0000796caedd1299  call rax
0000796caedd129b  movaps xmm1, [rsp]
0000796caedd129f  add rsp, 0x30
0000796caedd12a3  vmovaps xmm0, [rsp]
0000796caedd12a8  vmovaps xmm2, [rsp+0x10]
0000796caedd12ae  vmovaps xmm3, [rsp+0x20]
0000796caedd12b4  vmovaps xmm4, [rsp+0x30]
0000796caedd12ba  vmovaps xmm5, [rsp+0x40]
0000796caedd12c0  vmovaps xmm6, [rsp+0x50]
0000796caedd12c6  vmovaps xmm7, [rsp+0x60]
0000796caedd12cc  vmovaps xmm8, [rsp+0x70]
0000796caedd12d2  vmovaps xmm9, [rsp+0x80]
0000796caedd12db  vmovaps xmm10, [rsp+0x90]
0000796caedd12e4  vmovaps xmm11, [rsp+0xA0]
0000796caedd12ed  vmovaps xmm12, [rsp+0xB0]
0000796caedd12f6  vmovaps xmm13, [rsp+0xC0]
0000796caedd12ff  vmovaps xmm14, [rsp+0xD0]
0000796caedd1308  vmovaps xmm15, [rsp+0xE0]
0000796caedd1311  add rsp, 0xF0
0000796caedd1318  pop r11
0000796caedd131a  pop r10
0000796caedd131c  pop r9
0000796caedd131e  pop r8
0000796caedd1320  pop rsi
0000796caedd1321  pop rdi
0000796caedd1322  pop rdx
0000796caedd1323  pop rcx
0000796caedd1324  pop rax
0000796caedd1325  add rsp, 0x08
0000796caedd1329  jmp 0x0000796CAEDCF82C
0000796caedd132e  call 0x0000796CAEC0E760
0000796caedd1333  jmp 0x0000796CAEDCF839
0000796caedd1338  sub rsp, 0x08
0000796caedd133c  push rax
0000796caedd133d  push rcx
0000796caedd133e  push rdx
0000796caedd133f  push rdi
0000796caedd1340  push rsi
0000796caedd1341  push r8
0000796caedd1343  push r9
0000796caedd1345  push r10
0000796caedd1347  push r11
0000796caedd1349  sub rsp, 0xF0
0000796caedd1350  vmovaps [rsp], xmm0
0000796caedd1355  vmovaps [rsp+0x10], xmm1
0000796caedd135b  vmovaps [rsp+0x20], xmm2
0000796caedd1361  vmovaps [rsp+0x30], xmm3
0000796caedd1367  vmovaps [rsp+0x40], xmm4
0000796caedd136d  vmovaps [rsp+0x50], xmm5
0000796caedd1373  vmovaps [rsp+0x60], xmm6
0000796caedd1379  vmovaps [rsp+0x70], xmm7
0000796caedd137f  vmovaps [rsp+0x80], xmm8
0000796caedd1388  vmovaps [rsp+0x90], xmm9
0000796caedd1391  vmovaps [rsp+0xA0], xmm10
0000796caedd139a  vmovaps [rsp+0xB0], xmm11
0000796caedd13a3  vmovaps [rsp+0xC0], xmm12
0000796caedd13ac  vmovaps [rsp+0xD0], xmm14
0000796caedd13b5  vmovaps [rsp+0xE0], xmm15
0000796caedd13be  sub rsp, 0x30
0000796caedd13c2  movaps [rsp], xmm13
0000796caedd13c7  movaps [rsp+0x10], xmm2
0000796caedd13cc  movaps [rsp+0x20], xmm1
0000796caedd13d1  lea rdi, [rsp]
0000796caedd13d5  mov esi, 0x00
0000796caedd13da  mov rax, 0x56877063A530
0000796caedd13e4  call rax
0000796caedd13e6  movaps xmm13, [rsp]
0000796caedd13eb  add rsp, 0x30
0000796caedd13ef  vmovaps xmm0, [rsp]
0000796caedd13f4  vmovaps xmm1, [rsp+0x10]
0000796caedd13fa  vmovaps xmm2, [rsp+0x20]
0000796caedd1400  vmovaps xmm3, [rsp+0x30]
0000796caedd1406  vmovaps xmm4, [rsp+0x40]
0000796caedd140c  vmovaps xmm5, [rsp+0x50]
0000796caedd1412  vmovaps xmm6, [rsp+0x60]
0000796caedd1418  vmovaps xmm7, [rsp+0x70]
0000796caedd141e  vmovaps xmm8, [rsp+0x80]
0000796caedd1427  vmovaps xmm9, [rsp+0x90]
0000796caedd1430  vmovaps xmm10, [rsp+0xA0]
0000796caedd1439  vmovaps xmm11, [rsp+0xB0]
0000796caedd1442  vmovaps xmm12, [rsp+0xC0]
0000796caedd144b  vmovaps xmm14, [rsp+0xD0]
0000796caedd1454  vmovaps xmm15, [rsp+0xE0]
0000796caedd145d  add rsp, 0xF0
0000796caedd1464  pop r11
0000796caedd1466  pop r10
0000796caedd1468  pop r9
0000796caedd146a  pop r8
0000796caedd146c  pop rsi
0000796caedd146d  pop rdi
0000796caedd146e  pop rdx
0000796caedd146f  pop rcx
0000796caedd1470  pop rax
0000796caedd1471  add rsp, 0x08
0000796caedd1475  jmp 0x0000796CAEDCF878
0000796caedd147a  sub rsp, 0x08
0000796caedd147e  push rax
0000796caedd147f  push rcx
0000796caedd1480  push rdx
0000796caedd1481  push rdi
0000796caedd1482  push rsi
0000796caedd1483  push r8
0000796caedd1485  push r9
0000796caedd1487  push r10
0000796caedd1489  push r11
0000796caedd148b  sub rsp, 0xF0
0000796caedd1492  vmovaps [rsp], xmm0
0000796caedd1497  vmovaps [rsp+0x10], xmm2
0000796caedd149d  vmovaps [rsp+0x20], xmm3
0000796caedd14a3  vmovaps [rsp+0x30], xmm4
0000796caedd14a9  vmovaps [rsp+0x40], xmm5
0000796caedd14af  vmovaps [rsp+0x50], xmm6
0000796caedd14b5  vmovaps [rsp+0x60], xmm7
0000796caedd14bb  vmovaps [rsp+0x70], xmm8
0000796caedd14c1  vmovaps [rsp+0x80], xmm9
0000796caedd14ca  vmovaps [rsp+0x90], xmm10
0000796caedd14d3  vmovaps [rsp+0xA0], xmm11
0000796caedd14dc  vmovaps [rsp+0xB0], xmm12
0000796caedd14e5  vmovaps [rsp+0xC0], xmm13
0000796caedd14ee  vmovaps [rsp+0xD0], xmm14
0000796caedd14f7  vmovaps [rsp+0xE0], xmm15
0000796caedd1500  sub rsp, 0x30
0000796caedd1504  movaps [rsp], xmm1
0000796caedd1508  movaps [rsp+0x10], xmm15
0000796caedd150e  movaps [rsp+0x20], xmm2
0000796caedd1513  lea rdi, [rsp]
0000796caedd1517  mov esi, 0x00
0000796caedd151c  mov rax, 0x56877063A530
0000796caedd1526  call rax
0000796caedd1528  movaps xmm1, [rsp]
0000796caedd152c  add rsp, 0x30
0000796caedd1530  vmovaps xmm0, [rsp]
0000796caedd1535  vmovaps xmm2, [rsp+0x10]
0000796caedd153b  vmovaps xmm3, [rsp+0x20]
0000796caedd1541  vmovaps xmm4, [rsp+0x30]
0000796caedd1547  vmovaps xmm5, [rsp+0x40]
0000796caedd154d  vmovaps xmm6, [rsp+0x50]
0000796caedd1553  vmovaps xmm7, [rsp+0x60]
0000796caedd1559  vmovaps xmm8, [rsp+0x70]
0000796caedd155f  vmovaps xmm9, [rsp+0x80]
0000796caedd1568  vmovaps xmm10, [rsp+0x90]
0000796caedd1571  vmovaps xmm11, [rsp+0xA0]
0000796caedd157a  vmovaps xmm12, [rsp+0xB0]
0000796caedd1583  vmovaps xmm13, [rsp+0xC0]
0000796caedd158c  vmovaps xmm14, [rsp+0xD0]
0000796caedd1595  vmovaps xmm15, [rsp+0xE0]
0000796caedd159e  add rsp, 0xF0
0000796caedd15a5  pop r11
0000796caedd15a7  pop r10
0000796caedd15a9  pop r9
0000796caedd15ab  pop r8
0000796caedd15ad  pop rsi
0000796caedd15ae  pop rdi
0000796caedd15af  pop rdx
0000796caedd15b0  pop rcx
0000796caedd15b1  pop rax
0000796caedd15b2  add rsp, 0x08
0000796caedd15b6  jmp 0x0000796CAEDCF8AC
0000796caedd15bb  sub rsp, 0x08
0000796caedd15bf  push rax
0000796caedd15c0  push rcx
0000796caedd15c1  push rdx
0000796caedd15c2  push rdi
0000796caedd15c3  push rsi
0000796caedd15c4  push r8
0000796caedd15c6  push r9
0000796caedd15c8  push r10
0000796caedd15ca  push r11
0000796caedd15cc  sub rsp, 0xF0
0000796caedd15d3  vmovaps [rsp], xmm0
0000796caedd15d8  vmovaps [rsp+0x10], xmm1
0000796caedd15de  vmovaps [rsp+0x20], xmm2
0000796caedd15e4  vmovaps [rsp+0x30], xmm3
0000796caedd15ea  vmovaps [rsp+0x40], xmm4
0000796caedd15f0  vmovaps [rsp+0x50], xmm5
0000796caedd15f6  vmovaps [rsp+0x60], xmm6
0000796caedd15fc  vmovaps [rsp+0x70], xmm7
0000796caedd1602  vmovaps [rsp+0x80], xmm8
0000796caedd160b  vmovaps [rsp+0x90], xmm9
0000796caedd1614  vmovaps [rsp+0xA0], xmm10
0000796caedd161d  vmovaps [rsp+0xB0], xmm11
0000796caedd1626  vmovaps [rsp+0xC0], xmm12
0000796caedd162f  vmovaps [rsp+0xD0], xmm13
0000796caedd1638  vmovaps [rsp+0xE0], xmm15
0000796caedd1641  sub rsp, 0x30
0000796caedd1645  movaps [rsp], xmm14
0000796caedd164a  movaps [rsp+0x10], xmm2
0000796caedd164f  movaps [rsp+0x20], xmm15
0000796caedd1655  lea rdi, [rsp]
0000796caedd1659  mov esi, 0x00
0000796caedd165e  mov rax, 0x56877063A530
0000796caedd1668  call rax
0000796caedd166a  movaps xmm14, [rsp]
0000796caedd166f  add rsp, 0x30
0000796caedd1673  vmovaps xmm0, [rsp]
0000796caedd1678  vmovaps xmm1, [rsp+0x10]
0000796caedd167e  vmovaps xmm2, [rsp+0x20]
0000796caedd1684  vmovaps xmm3, [rsp+0x30]
0000796caedd168a  vmovaps xmm4, [rsp+0x40]
0000796caedd1690  vmovaps xmm5, [rsp+0x50]
0000796caedd1696  vmovaps xmm6, [rsp+0x60]
0000796caedd169c  vmovaps xmm7, [rsp+0x70]
0000796caedd16a2  vmovaps xmm8, [rsp+0x80]
0000796caedd16ab  vmovaps xmm9, [rsp+0x90]
0000796caedd16b4  vmovaps xmm10, [rsp+0xA0]
0000796caedd16bd  vmovaps xmm11, [rsp+0xB0]
0000796caedd16c6  vmovaps xmm12, [rsp+0xC0]
0000796caedd16cf  vmovaps xmm13, [rsp+0xD0]
0000796caedd16d8  vmovaps xmm15, [rsp+0xE0]
0000796caedd16e1  add rsp, 0xF0
0000796caedd16e8  pop r11
0000796caedd16ea  pop r10
0000796caedd16ec  pop r9
0000796caedd16ee  pop r8
0000796caedd16f0  pop rsi
0000796caedd16f1  pop rdi
0000796caedd16f2  pop rdx
0000796caedd16f3  pop rcx
0000796caedd16f4  pop rax
0000796caedd16f5  add rsp, 0x08
0000796caedd16f9  jmp 0x0000796CAEDCF8E7
0000796caedd16fe  sub rsp, 0x08
0000796caedd1702  push rax
0000796caedd1703  push rcx
0000796caedd1704  push rdx
0000796caedd1705  push rdi
0000796caedd1706  push rsi
0000796caedd1707  push r8
0000796caedd1709  push r9
0000796caedd170b  push r10
0000796caedd170d  push r11
0000796caedd170f  sub rsp, 0xF0
0000796caedd1716  vmovaps [rsp], xmm0
0000796caedd171b  vmovaps [rsp+0x10], xmm1
0000796caedd1721  vmovaps [rsp+0x20], xmm2
0000796caedd1727  vmovaps [rsp+0x30], xmm3
0000796caedd172d  vmovaps [rsp+0x40], xmm4
0000796caedd1733  vmovaps [rsp+0x50], xmm5
0000796caedd1739  vmovaps [rsp+0x60], xmm6
0000796caedd173f  vmovaps [rsp+0x70], xmm7
0000796caedd1745  vmovaps [rsp+0x80], xmm8
0000796caedd174e  vmovaps [rsp+0x90], xmm9
0000796caedd1757  vmovaps [rsp+0xA0], xmm10
0000796caedd1760  vmovaps [rsp+0xB0], xmm11
0000796caedd1769  vmovaps [rsp+0xC0], xmm12
0000796caedd1772  vmovaps [rsp+0xD0], xmm13
0000796caedd177b  vmovaps [rsp+0xE0], xmm14
0000796caedd1784  sub rsp, 0x30
0000796caedd1788  movaps [rsp], xmm15
0000796caedd178d  movaps [rsp+0x10], xmm2
0000796caedd1792  movaps [rsp+0x20], xmm1
0000796caedd1797  lea rdi, [rsp]
0000796caedd179b  mov esi, 0x00
0000796caedd17a0  mov rax, 0x56877063A530
0000796caedd17aa  call rax
0000796caedd17ac  movaps xmm15, [rsp]
0000796caedd17b1  add rsp, 0x30
0000796caedd17b5  vmovaps xmm0, [rsp]
0000796caedd17ba  vmovaps xmm1, [rsp+0x10]
0000796caedd17c0  vmovaps xmm2, [rsp+0x20]
0000796caedd17c6  vmovaps xmm3, [rsp+0x30]
0000796caedd17cc  vmovaps xmm4, [rsp+0x40]
0000796caedd17d2  vmovaps xmm5, [rsp+0x50]
0000796caedd17d8  vmovaps xmm6, [rsp+0x60]
0000796caedd17de  vmovaps xmm7, [rsp+0x70]
0000796caedd17e4  vmovaps xmm8, [rsp+0x80]
0000796caedd17ed  vmovaps xmm9, [rsp+0x90]
0000796caedd17f6  vmovaps xmm10, [rsp+0xA0]
0000796caedd17ff  vmovaps xmm11, [rsp+0xB0]
0000796caedd1808  vmovaps xmm12, [rsp+0xC0]
0000796caedd1811  vmovaps xmm13, [rsp+0xD0]
0000796caedd181a  vmovaps xmm14, [rsp+0xE0]
0000796caedd1823  add rsp, 0xF0
0000796caedd182a  pop r11
0000796caedd182c  pop r10
0000796caedd182e  pop r9
0000796caedd1830  pop r8
0000796caedd1832  pop rsi
0000796caedd1833  pop rdi
0000796caedd1834  pop rdx
0000796caedd1835  pop rcx
0000796caedd1836  pop rax
0000796caedd1837  add rsp, 0x08
0000796caedd183b  jmp 0x0000796CAEDCF923
0000796caedd1840  call 0x0000796CAEBFF430
0000796caedd1845  jmp 0x0000796CAEDCF930
0000796caedd184a  sub rsp, 0x08
0000796caedd184e  push rax
0000796caedd184f  push rcx
0000796caedd1850  push rdx
0000796caedd1851  push rdi
0000796caedd1852  push rsi
0000796caedd1853  push r8
0000796caedd1855  push r9
0000796caedd1857  push r10
0000796caedd1859  push r11
0000796caedd185b  sub rsp, 0xF0
0000796caedd1862  vmovaps [rsp], xmm0
0000796caedd1867  vmovaps [rsp+0x10], xmm1
0000796caedd186d  vmovaps [rsp+0x20], xmm3
0000796caedd1873  vmovaps [rsp+0x30], xmm4
0000796caedd1879  vmovaps [rsp+0x40], xmm5
0000796caedd187f  vmovaps [rsp+0x50], xmm6
0000796caedd1885  vmovaps [rsp+0x60], xmm7
0000796caedd188b  vmovaps [rsp+0x70], xmm8
0000796caedd1891  vmovaps [rsp+0x80], xmm9
0000796caedd189a  vmovaps [rsp+0x90], xmm10
0000796caedd18a3  vmovaps [rsp+0xA0], xmm11
0000796caedd18ac  vmovaps [rsp+0xB0], xmm12
0000796caedd18b5  vmovaps [rsp+0xC0], xmm13
0000796caedd18be  vmovaps [rsp+0xD0], xmm14
0000796caedd18c7  vmovaps [rsp+0xE0], xmm15
0000796caedd18d0  sub rsp, 0x30
0000796caedd18d4  movaps [rsp], xmm2
0000796caedd18d8  movaps [rsp+0x10], xmm1
0000796caedd18dd  movaps [rsp+0x20], xmm14
0000796caedd18e3  lea rdi, [rsp]
0000796caedd18e7  mov esi, 0x00
0000796caedd18ec  mov rax, 0x56877063A530
0000796caedd18f6  call rax
0000796caedd18f8  movaps xmm2, [rsp]
0000796caedd18fc  add rsp, 0x30
0000796caedd1900  vmovaps xmm0, [rsp]
0000796caedd1905  vmovaps xmm1, [rsp+0x10]
0000796caedd190b  vmovaps xmm3, [rsp+0x20]
0000796caedd1911  vmovaps xmm4, [rsp+0x30]
0000796caedd1917  vmovaps xmm5, [rsp+0x40]
0000796caedd191d  vmovaps xmm6, [rsp+0x50]
0000796caedd1923  vmovaps xmm7, [rsp+0x60]
0000796caedd1929  vmovaps xmm8, [rsp+0x70]
0000796caedd192f  vmovaps xmm9, [rsp+0x80]
0000796caedd1938  vmovaps xmm10, [rsp+0x90]
0000796caedd1941  vmovaps xmm11, [rsp+0xA0]
0000796caedd194a  vmovaps xmm12, [rsp+0xB0]
0000796caedd1953  vmovaps xmm13, [rsp+0xC0]
0000796caedd195c  vmovaps xmm14, [rsp+0xD0]
0000796caedd1965  vmovaps xmm15, [rsp+0xE0]
0000796caedd196e  add rsp, 0xF0
0000796caedd1975  pop r11
0000796caedd1977  pop r10
0000796caedd1979  pop r9
0000796caedd197b  pop r8
0000796caedd197d  pop rsi
0000796caedd197e  pop rdi
0000796caedd197f  pop rdx
0000796caedd1980  pop rcx
0000796caedd1981  pop rax
0000796caedd1982  add rsp, 0x08
0000796caedd1986  jmp 0x0000796CAEDCF96D
0000796caedd198b  sub rsp, 0x08
0000796caedd198f  push rax
0000796caedd1990  push rcx
0000796caedd1991  push rdx
0000796caedd1992  push rdi
0000796caedd1993  push rsi
0000796caedd1994  push r8
0000796caedd1996  push r9
0000796caedd1998  push r10
0000796caedd199a  push r11
0000796caedd199c  sub rsp, 0xF0
0000796caedd19a3  vmovaps [rsp], xmm0
0000796caedd19a8  vmovaps [rsp+0x10], xmm1
0000796caedd19ae  vmovaps [rsp+0x20], xmm2
0000796caedd19b4  vmovaps [rsp+0x30], xmm3
0000796caedd19ba  vmovaps [rsp+0x40], xmm4
0000796caedd19c0  vmovaps [rsp+0x50], xmm5
0000796caedd19c6  vmovaps [rsp+0x60], xmm6
0000796caedd19cc  vmovaps [rsp+0x70], xmm7
0000796caedd19d2  vmovaps [rsp+0x80], xmm8
0000796caedd19db  vmovaps [rsp+0x90], xmm9
0000796caedd19e4  vmovaps [rsp+0xA0], xmm10
0000796caedd19ed  vmovaps [rsp+0xB0], xmm11
0000796caedd19f6  vmovaps [rsp+0xC0], xmm12
0000796caedd19ff  vmovaps [rsp+0xD0], xmm13
0000796caedd1a08  vmovaps [rsp+0xE0], xmm14
0000796caedd1a11  sub rsp, 0x30
0000796caedd1a15  movaps [rsp], xmm15
0000796caedd1a1a  movaps [rsp+0x10], xmm14
0000796caedd1a20  movaps [rsp+0x20], xmm1
0000796caedd1a25  lea rdi, [rsp]
0000796caedd1a29  mov esi, 0x00
0000796caedd1a2e  mov rax, 0x56877063A530
0000796caedd1a38  call rax
0000796caedd1a3a  movaps xmm15, [rsp]
0000796caedd1a3f  add rsp, 0x30
0000796caedd1a43  vmovaps xmm0, [rsp]
0000796caedd1a48  vmovaps xmm1, [rsp+0x10]
0000796caedd1a4e  vmovaps xmm2, [rsp+0x20]
0000796caedd1a54  vmovaps xmm3, [rsp+0x30]
0000796caedd1a5a  vmovaps xmm4, [rsp+0x40]
0000796caedd1a60  vmovaps xmm5, [rsp+0x50]
0000796caedd1a66  vmovaps xmm6, [rsp+0x60]
0000796caedd1a6c  vmovaps xmm7, [rsp+0x70]
0000796caedd1a72  vmovaps xmm8, [rsp+0x80]
0000796caedd1a7b  vmovaps xmm9, [rsp+0x90]
0000796caedd1a84  vmovaps xmm10, [rsp+0xA0]
0000796caedd1a8d  vmovaps xmm11, [rsp+0xB0]
0000796caedd1a96  vmovaps xmm12, [rsp+0xC0]
0000796caedd1a9f  vmovaps xmm13, [rsp+0xD0]
0000796caedd1aa8  vmovaps xmm14, [rsp+0xE0]
0000796caedd1ab1  add rsp, 0xF0
0000796caedd1ab8  pop r11
0000796caedd1aba  pop r10
0000796caedd1abc  pop r9
0000796caedd1abe  pop r8
0000796caedd1ac0  pop rsi
0000796caedd1ac1  pop rdi
0000796caedd1ac2  pop rdx
0000796caedd1ac3  pop rcx
0000796caedd1ac4  pop rax
0000796caedd1ac5  add rsp, 0x08
0000796caedd1ac9  jmp 0x0000796CAEDCF9E7
0000796caedd1ace  call 0x0000796CAEBFF430
0000796caedd1ad3  jmp 0x0000796CAEDCF9F4
0000796caedd1ad8  sub rsp, 0x08
0000796caedd1adc  push rax
0000796caedd1add  push rcx
0000796caedd1ade  push rdx
0000796caedd1adf  push rdi
0000796caedd1ae0  push rsi
0000796caedd1ae1  push r8
0000796caedd1ae3  push r9
0000796caedd1ae5  push r10
0000796caedd1ae7  push r11
0000796caedd1ae9  sub rsp, 0xF0
0000796caedd1af0  vmovaps [rsp], xmm0
0000796caedd1af5  vmovaps [rsp+0x10], xmm1
0000796caedd1afb  vmovaps [rsp+0x20], xmm2
0000796caedd1b01  vmovaps [rsp+0x30], xmm3
0000796caedd1b07  vmovaps [rsp+0x40], xmm4
0000796caedd1b0d  vmovaps [rsp+0x50], xmm5
0000796caedd1b13  vmovaps [rsp+0x60], xmm6
0000796caedd1b19  vmovaps [rsp+0x70], xmm7
0000796caedd1b1f  vmovaps [rsp+0x80], xmm8
0000796caedd1b28  vmovaps [rsp+0x90], xmm9
0000796caedd1b31  vmovaps [rsp+0xA0], xmm10
0000796caedd1b3a  vmovaps [rsp+0xB0], xmm11
0000796caedd1b43  vmovaps [rsp+0xC0], xmm12
0000796caedd1b4c  vmovaps [rsp+0xD0], xmm13
0000796caedd1b55  vmovaps [rsp+0xE0], xmm15
0000796caedd1b5e  sub rsp, 0x30
0000796caedd1b62  movaps [rsp], xmm14
0000796caedd1b67  movaps [rsp+0x10], xmm13
0000796caedd1b6d  movaps [rsp+0x20], xmm1
0000796caedd1b72  lea rdi, [rsp]
0000796caedd1b76  mov esi, 0x00
0000796caedd1b7b  mov rax, 0x56877063A530
0000796caedd1b85  call rax
0000796caedd1b87  movaps xmm14, [rsp]
0000796caedd1b8c  add rsp, 0x30
0000796caedd1b90  vmovaps xmm0, [rsp]
0000796caedd1b95  vmovaps xmm1, [rsp+0x10]
0000796caedd1b9b  vmovaps xmm2, [rsp+0x20]
0000796caedd1ba1  vmovaps xmm3, [rsp+0x30]
0000796caedd1ba7  vmovaps xmm4, [rsp+0x40]
0000796caedd1bad  vmovaps xmm5, [rsp+0x50]
0000796caedd1bb3  vmovaps xmm6, [rsp+0x60]
0000796caedd1bb9  vmovaps xmm7, [rsp+0x70]
0000796caedd1bbf  vmovaps xmm8, [rsp+0x80]
0000796caedd1bc8  vmovaps xmm9, [rsp+0x90]
0000796caedd1bd1  vmovaps xmm10, [rsp+0xA0]
0000796caedd1bda  vmovaps xmm11, [rsp+0xB0]
0000796caedd1be3  vmovaps xmm12, [rsp+0xC0]
0000796caedd1bec  vmovaps xmm13, [rsp+0xD0]
0000796caedd1bf5  vmovaps xmm15, [rsp+0xE0]
0000796caedd1bfe  add rsp, 0xF0
0000796caedd1c05  pop r11
0000796caedd1c07  pop r10
0000796caedd1c09  pop r9
0000796caedd1c0b  pop r8
0000796caedd1c0d  pop rsi
0000796caedd1c0e  pop rdi
0000796caedd1c0f  pop rdx
0000796caedd1c10  pop rcx
0000796caedd1c11  pop rax
0000796caedd1c12  add rsp, 0x08
0000796caedd1c16  jmp 0x0000796CAEDCFAAF
0000796caedd1c1b  sub rsp, 0x08
0000796caedd1c1f  push rax
0000796caedd1c20  push rcx
0000796caedd1c21  push rdx
0000796caedd1c22  push rdi
0000796caedd1c23  push rsi
0000796caedd1c24  push r8
0000796caedd1c26  push r9
0000796caedd1c28  push r10
0000796caedd1c2a  push r11
0000796caedd1c2c  sub rsp, 0xF0
0000796caedd1c33  vmovaps [rsp], xmm0
0000796caedd1c38  vmovaps [rsp+0x10], xmm1
0000796caedd1c3e  vmovaps [rsp+0x20], xmm2
0000796caedd1c44  vmovaps [rsp+0x30], xmm3
0000796caedd1c4a  vmovaps [rsp+0x40], xmm4
0000796caedd1c50  vmovaps [rsp+0x50], xmm5
0000796caedd1c56  vmovaps [rsp+0x60], xmm6
0000796caedd1c5c  vmovaps [rsp+0x70], xmm7
0000796caedd1c62  vmovaps [rsp+0x80], xmm8
0000796caedd1c6b  vmovaps [rsp+0x90], xmm9
0000796caedd1c74  vmovaps [rsp+0xA0], xmm10
0000796caedd1c7d  vmovaps [rsp+0xB0], xmm11
0000796caedd1c86  vmovaps [rsp+0xC0], xmm12
0000796caedd1c8f  vmovaps [rsp+0xD0], xmm13
0000796caedd1c98  vmovaps [rsp+0xE0], xmm14
0000796caedd1ca1  sub rsp, 0x30
0000796caedd1ca5  movaps [rsp], xmm15
0000796caedd1caa  movaps [rsp+0x10], xmm13
0000796caedd1cb0  movaps [rsp+0x20], xmm1
0000796caedd1cb5  lea rdi, [rsp]
0000796caedd1cb9  mov esi, 0x00
0000796caedd1cbe  mov rax, 0x56877063A530
0000796caedd1cc8  call rax
0000796caedd1cca  movaps xmm15, [rsp]
0000796caedd1ccf  add rsp, 0x30
0000796caedd1cd3  vmovaps xmm0, [rsp]
0000796caedd1cd8  vmovaps xmm1, [rsp+0x10]
0000796caedd1cde  vmovaps xmm2, [rsp+0x20]
0000796caedd1ce4  vmovaps xmm3, [rsp+0x30]
0000796caedd1cea  vmovaps xmm4, [rsp+0x40]
0000796caedd1cf0  vmovaps xmm5, [rsp+0x50]
0000796caedd1cf6  vmovaps xmm6, [rsp+0x60]
0000796caedd1cfc  vmovaps xmm7, [rsp+0x70]
0000796caedd1d02  vmovaps xmm8, [rsp+0x80]
0000796caedd1d0b  vmovaps xmm9, [rsp+0x90]
0000796caedd1d14  vmovaps xmm10, [rsp+0xA0]
0000796caedd1d1d  vmovaps xmm11, [rsp+0xB0]
0000796caedd1d26  vmovaps xmm12, [rsp+0xC0]
0000796caedd1d2f  vmovaps xmm13, [rsp+0xD0]
0000796caedd1d38  vmovaps xmm14, [rsp+0xE0]
0000796caedd1d41  add rsp, 0xF0
0000796caedd1d48  pop r11
0000796caedd1d4a  pop r10
0000796caedd1d4c  pop r9
0000796caedd1d4e  pop r8
0000796caedd1d50  pop rsi
0000796caedd1d51  pop rdi
0000796caedd1d52  pop rdx
0000796caedd1d53  pop rcx
0000796caedd1d54  pop rax
0000796caedd1d55  add rsp, 0x08
0000796caedd1d59  jmp 0x0000796CAEDCFAEB
0000796caedd1d5e  call 0x0000796CAEBFF430
0000796caedd1d63  jmp 0x0000796CAEDCFAF8
0000796caedd1d68  sub rsp, 0x08
0000796caedd1d6c  push rax
0000796caedd1d6d  push rcx
0000796caedd1d6e  push rdx
0000796caedd1d6f  push rdi
0000796caedd1d70  push rsi
0000796caedd1d71  push r8
0000796caedd1d73  push r9
0000796caedd1d75  push r10
0000796caedd1d77  push r11
0000796caedd1d79  sub rsp, 0xF0
0000796caedd1d80  vmovaps [rsp], xmm0
0000796caedd1d85  vmovaps [rsp+0x10], xmm1
0000796caedd1d8b  vmovaps [rsp+0x20], xmm2
0000796caedd1d91  vmovaps [rsp+0x30], xmm3
0000796caedd1d97  vmovaps [rsp+0x40], xmm4
0000796caedd1d9d  vmovaps [rsp+0x50], xmm5
0000796caedd1da3  vmovaps [rsp+0x60], xmm6
0000796caedd1da9  vmovaps [rsp+0x70], xmm7
0000796caedd1daf  vmovaps [rsp+0x80], xmm8
0000796caedd1db8  vmovaps [rsp+0x90], xmm9
0000796caedd1dc1  vmovaps [rsp+0xA0], xmm10
0000796caedd1dca  vmovaps [rsp+0xB0], xmm11
0000796caedd1dd3  vmovaps [rsp+0xC0], xmm12
0000796caedd1ddc  vmovaps [rsp+0xD0], xmm13
0000796caedd1de5  vmovaps [rsp+0xE0], xmm15
0000796caedd1dee  sub rsp, 0x30
0000796caedd1df2  movaps [rsp], xmm14
0000796caedd1df7  movaps [rsp+0x10], xmm13
0000796caedd1dfd  movaps [rsp+0x20], xmm2
0000796caedd1e02  lea rdi, [rsp]
0000796caedd1e06  mov esi, 0x00
0000796caedd1e0b  mov rax, 0x56877063A530
0000796caedd1e15  call rax
0000796caedd1e17  movaps xmm14, [rsp]
0000796caedd1e1c  add rsp, 0x30
0000796caedd1e20  vmovaps xmm0, [rsp]
0000796caedd1e25  vmovaps xmm1, [rsp+0x10]
0000796caedd1e2b  vmovaps xmm2, [rsp+0x20]
0000796caedd1e31  vmovaps xmm3, [rsp+0x30]
0000796caedd1e37  vmovaps xmm4, [rsp+0x40]
0000796caedd1e3d  vmovaps xmm5, [rsp+0x50]
0000796caedd1e43  vmovaps xmm6, [rsp+0x60]
0000796caedd1e49  vmovaps xmm7, [rsp+0x70]
0000796caedd1e4f  vmovaps xmm8, [rsp+0x80]
0000796caedd1e58  vmovaps xmm9, [rsp+0x90]
0000796caedd1e61  vmovaps xmm10, [rsp+0xA0]
0000796caedd1e6a  vmovaps xmm11, [rsp+0xB0]
0000796caedd1e73  vmovaps xmm12, [rsp+0xC0]
0000796caedd1e7c  vmovaps xmm13, [rsp+0xD0]
0000796caedd1e85  vmovaps xmm15, [rsp+0xE0]
0000796caedd1e8e  add rsp, 0xF0
0000796caedd1e95  pop r11
0000796caedd1e97  pop r10
0000796caedd1e99  pop r9
0000796caedd1e9b  pop r8
0000796caedd1e9d  pop rsi
0000796caedd1e9e  pop rdi
0000796caedd1e9f  pop rdx
0000796caedd1ea0  pop rcx
0000796caedd1ea1  pop rax
0000796caedd1ea2  add rsp, 0x08
0000796caedd1ea6  jmp 0x0000796CAEDCFB24
0000796caedd1eab  sub rsp, 0x08
0000796caedd1eaf  push rax
0000796caedd1eb0  push rcx
0000796caedd1eb1  push rdx
0000796caedd1eb2  push rdi
0000796caedd1eb3  push rsi
0000796caedd1eb4  push r8
0000796caedd1eb6  push r9
0000796caedd1eb8  push r10
0000796caedd1eba  push r11
0000796caedd1ebc  sub rsp, 0xF0
0000796caedd1ec3  vmovaps [rsp], xmm0
0000796caedd1ec8  vmovaps [rsp+0x10], xmm2
0000796caedd1ece  vmovaps [rsp+0x20], xmm3
0000796caedd1ed4  vmovaps [rsp+0x30], xmm4
0000796caedd1eda  vmovaps [rsp+0x40], xmm5
0000796caedd1ee0  vmovaps [rsp+0x50], xmm6
0000796caedd1ee6  vmovaps [rsp+0x60], xmm7
0000796caedd1eec  vmovaps [rsp+0x70], xmm8
0000796caedd1ef2  vmovaps [rsp+0x80], xmm9
0000796caedd1efb  vmovaps [rsp+0x90], xmm10
0000796caedd1f04  vmovaps [rsp+0xA0], xmm11
0000796caedd1f0d  vmovaps [rsp+0xB0], xmm12
0000796caedd1f16  vmovaps [rsp+0xC0], xmm13
0000796caedd1f1f  vmovaps [rsp+0xD0], xmm14
0000796caedd1f28  vmovaps [rsp+0xE0], xmm15
0000796caedd1f31  sub rsp, 0x30
0000796caedd1f35  movaps [rsp], xmm1
0000796caedd1f39  movaps [rsp+0x10], xmm13
0000796caedd1f3f  movaps [rsp+0x20], xmm2
0000796caedd1f44  lea rdi, [rsp]
0000796caedd1f48  mov esi, 0x00
0000796caedd1f4d  mov rax, 0x56877063A530
0000796caedd1f57  call rax
0000796caedd1f59  movaps xmm1, [rsp]
0000796caedd1f5d  add rsp, 0x30
0000796caedd1f61  vmovaps xmm0, [rsp]
0000796caedd1f66  vmovaps xmm2, [rsp+0x10]
0000796caedd1f6c  vmovaps xmm3, [rsp+0x20]
0000796caedd1f72  vmovaps xmm4, [rsp+0x30]
0000796caedd1f78  vmovaps xmm5, [rsp+0x40]
0000796caedd1f7e  vmovaps xmm6, [rsp+0x50]
0000796caedd1f84  vmovaps xmm7, [rsp+0x60]
0000796caedd1f8a  vmovaps xmm8, [rsp+0x70]
0000796caedd1f90  vmovaps xmm9, [rsp+0x80]
0000796caedd1f99  vmovaps xmm10, [rsp+0x90]
0000796caedd1fa2  vmovaps xmm11, [rsp+0xA0]
0000796caedd1fab  vmovaps xmm12, [rsp+0xB0]
0000796caedd1fb4  vmovaps xmm13, [rsp+0xC0]
0000796caedd1fbd  vmovaps xmm14, [rsp+0xD0]
0000796caedd1fc6  vmovaps xmm15, [rsp+0xE0]
0000796caedd1fcf  add rsp, 0xF0
0000796caedd1fd6  pop r11
0000796caedd1fd8  pop r10
0000796caedd1fda  pop r9
0000796caedd1fdc  pop r8
0000796caedd1fde  pop rsi
0000796caedd1fdf  pop rdi
0000796caedd1fe0  pop rdx
0000796caedd1fe1  pop rcx
0000796caedd1fe2  pop rax
0000796caedd1fe3  add rsp, 0x08
0000796caedd1fe7  jmp 0x0000796CAEDCFB52
0000796caedd1fec  sub rsp, 0x08
0000796caedd1ff0  push rax
0000796caedd1ff1  push rcx
0000796caedd1ff2  push rdx
0000796caedd1ff3  push rdi
0000796caedd1ff4  push rsi
0000796caedd1ff5  push r8
0000796caedd1ff7  push r9
0000796caedd1ff9  push r10
0000796caedd1ffb  push r11
0000796caedd1ffd  sub rsp, 0xF0
0000796caedd2004  vmovaps [rsp], xmm0
0000796caedd2009  vmovaps [rsp+0x10], xmm1
0000796caedd200f  vmovaps [rsp+0x20], xmm3
0000796caedd2015  vmovaps [rsp+0x30], xmm4
0000796caedd201b  vmovaps [rsp+0x40], xmm5
0000796caedd2021  vmovaps [rsp+0x50], xmm6
0000796caedd2027  vmovaps [rsp+0x60], xmm7
0000796caedd202d  vmovaps [rsp+0x70], xmm8
0000796caedd2033  vmovaps [rsp+0x80], xmm9
0000796caedd203c  vmovaps [rsp+0x90], xmm10
0000796caedd2045  vmovaps [rsp+0xA0], xmm11
0000796caedd204e  vmovaps [rsp+0xB0], xmm12
0000796caedd2057  vmovaps [rsp+0xC0], xmm13
0000796caedd2060  vmovaps [rsp+0xD0], xmm14
0000796caedd2069  vmovaps [rsp+0xE0], xmm15
0000796caedd2072  sub rsp, 0x30
0000796caedd2076  movaps [rsp], xmm2
0000796caedd207a  movaps [rsp+0x10], xmm1
0000796caedd207f  movaps [rsp+0x20], xmm13
0000796caedd2085  lea rdi, [rsp]
0000796caedd2089  mov esi, 0x00
0000796caedd208e  mov rax, 0x56877063A530
0000796caedd2098  call rax
0000796caedd209a  movaps xmm2, [rsp]
0000796caedd209e  add rsp, 0x30
0000796caedd20a2  vmovaps xmm0, [rsp]
0000796caedd20a7  vmovaps xmm1, [rsp+0x10]
0000796caedd20ad  vmovaps xmm3, [rsp+0x20]
0000796caedd20b3  vmovaps xmm4, [rsp+0x30]
0000796caedd20b9  vmovaps xmm5, [rsp+0x40]
0000796caedd20bf  vmovaps xmm6, [rsp+0x50]
0000796caedd20c5  vmovaps xmm7, [rsp+0x60]
0000796caedd20cb  vmovaps xmm8, [rsp+0x70]
0000796caedd20d1  vmovaps xmm9, [rsp+0x80]
0000796caedd20da  vmovaps xmm10, [rsp+0x90]
0000796caedd20e3  vmovaps xmm11, [rsp+0xA0]
0000796caedd20ec  vmovaps xmm12, [rsp+0xB0]
0000796caedd20f5  vmovaps xmm13, [rsp+0xC0]
0000796caedd20fe  vmovaps xmm14, [rsp+0xD0]
0000796caedd2107  vmovaps xmm15, [rsp+0xE0]
0000796caedd2110  add rsp, 0xF0
0000796caedd2117  pop r11
0000796caedd2119  pop r10
0000796caedd211b  pop r9
0000796caedd211d  pop r8
0000796caedd211f  pop rsi
0000796caedd2120  pop rdi
0000796caedd2121  pop rdx
0000796caedd2122  pop rcx
0000796caedd2123  pop rax
0000796caedd2124  add rsp, 0x08
0000796caedd2128  jmp 0x0000796CAEDCFBAB
0000796caedd212d  call 0x0000796CAEBFF430
0000796caedd2132  jmp 0x0000796CAEDCFBB8
0000796caedd2137  sub rsp, 0x08
0000796caedd213b  push rax
0000796caedd213c  push rcx
0000796caedd213d  push rdx
0000796caedd213e  push rdi
0000796caedd213f  push rsi
0000796caedd2140  push r8
0000796caedd2142  push r9
0000796caedd2144  push r10
0000796caedd2146  push r11
0000796caedd2148  sub rsp, 0xF0
0000796caedd214f  vmovaps [rsp], xmm0
0000796caedd2154  vmovaps [rsp+0x10], xmm1
0000796caedd215a  vmovaps [rsp+0x20], xmm2
0000796caedd2160  vmovaps [rsp+0x30], xmm3
0000796caedd2166  vmovaps [rsp+0x40], xmm4
0000796caedd216c  vmovaps [rsp+0x50], xmm5
0000796caedd2172  vmovaps [rsp+0x60], xmm6
0000796caedd2178  vmovaps [rsp+0x70], xmm7
0000796caedd217e  vmovaps [rsp+0x80], xmm8
0000796caedd2187  vmovaps [rsp+0x90], xmm9
0000796caedd2190  vmovaps [rsp+0xA0], xmm10
0000796caedd2199  vmovaps [rsp+0xB0], xmm11
0000796caedd21a2  vmovaps [rsp+0xC0], xmm12
0000796caedd21ab  vmovaps [rsp+0xD0], xmm13
0000796caedd21b4  vmovaps [rsp+0xE0], xmm14
0000796caedd21bd  sub rsp, 0x30
0000796caedd21c1  movaps [rsp], xmm15
0000796caedd21c6  movaps [rsp+0x10], xmm13
0000796caedd21cc  movaps [rsp+0x20], xmm1
0000796caedd21d1  lea rdi, [rsp]
0000796caedd21d5  mov esi, 0x00
0000796caedd21da  mov rax, 0x56877063A530
0000796caedd21e4  call rax
0000796caedd21e6  movaps xmm15, [rsp]
0000796caedd21eb  add rsp, 0x30
0000796caedd21ef  vmovaps xmm0, [rsp]
0000796caedd21f4  vmovaps xmm1, [rsp+0x10]
0000796caedd21fa  vmovaps xmm2, [rsp+0x20]
0000796caedd2200  vmovaps xmm3, [rsp+0x30]
0000796caedd2206  vmovaps xmm4, [rsp+0x40]
0000796caedd220c  vmovaps xmm5, [rsp+0x50]
0000796caedd2212  vmovaps xmm6, [rsp+0x60]
0000796caedd2218  vmovaps xmm7, [rsp+0x70]
0000796caedd221e  vmovaps xmm8, [rsp+0x80]
0000796caedd2227  vmovaps xmm9, [rsp+0x90]
0000796caedd2230  vmovaps xmm10, [rsp+0xA0]
0000796caedd2239  vmovaps xmm11, [rsp+0xB0]
0000796caedd2242  vmovaps xmm12, [rsp+0xC0]
0000796caedd224b  vmovaps xmm13, [rsp+0xD0]
0000796caedd2254  vmovaps xmm14, [rsp+0xE0]
0000796caedd225d  add rsp, 0xF0
0000796caedd2264  pop r11
0000796caedd2266  pop r10
0000796caedd2268  pop r9
0000796caedd226a  pop r8
0000796caedd226c  pop rsi
0000796caedd226d  pop rdi
0000796caedd226e  pop rdx
0000796caedd226f  pop rcx
0000796caedd2270  pop rax
0000796caedd2271  add rsp, 0x08
0000796caedd2275  jmp 0x0000796CAEDCFBF7
0000796caedd227a  sub rsp, 0x08
0000796caedd227e  push rax
0000796caedd227f  push rcx
0000796caedd2280  push rdx
0000796caedd2281  push rdi
0000796caedd2282  push rsi
0000796caedd2283  push r8
0000796caedd2285  push r9
0000796caedd2287  push r10
0000796caedd2289  push r11
0000796caedd228b  sub rsp, 0xF0
0000796caedd2292  vmovaps [rsp], xmm0
0000796caedd2297  vmovaps [rsp+0x10], xmm1
0000796caedd229d  vmovaps [rsp+0x20], xmm2
0000796caedd22a3  vmovaps [rsp+0x30], xmm3
0000796caedd22a9  vmovaps [rsp+0x40], xmm4
0000796caedd22af  vmovaps [rsp+0x50], xmm5
0000796caedd22b5  vmovaps [rsp+0x60], xmm6
0000796caedd22bb  vmovaps [rsp+0x70], xmm7
0000796caedd22c1  vmovaps [rsp+0x80], xmm8
0000796caedd22ca  vmovaps [rsp+0x90], xmm9
0000796caedd22d3  vmovaps [rsp+0xA0], xmm10
0000796caedd22dc  vmovaps [rsp+0xB0], xmm11
0000796caedd22e5  vmovaps [rsp+0xC0], xmm12
0000796caedd22ee  vmovaps [rsp+0xD0], xmm13
0000796caedd22f7  vmovaps [rsp+0xE0], xmm15
0000796caedd2300  sub rsp, 0x30
0000796caedd2304  movaps [rsp], xmm14
0000796caedd2309  movaps [rsp+0x10], xmm11
0000796caedd230f  movaps [rsp+0x20], xmm1
0000796caedd2314  lea rdi, [rsp]
0000796caedd2318  mov esi, 0x00
0000796caedd231d  mov rax, 0x56877063A530
0000796caedd2327  call rax
0000796caedd2329  movaps xmm14, [rsp]
0000796caedd232e  add rsp, 0x30
0000796caedd2332  vmovaps xmm0, [rsp]
0000796caedd2337  vmovaps xmm1, [rsp+0x10]
0000796caedd233d  vmovaps xmm2, [rsp+0x20]
0000796caedd2343  vmovaps xmm3, [rsp+0x30]
0000796caedd2349  vmovaps xmm4, [rsp+0x40]
0000796caedd234f  vmovaps xmm5, [rsp+0x50]
0000796caedd2355  vmovaps xmm6, [rsp+0x60]
0000796caedd235b  vmovaps xmm7, [rsp+0x70]
0000796caedd2361  vmovaps xmm8, [rsp+0x80]
0000796caedd236a  vmovaps xmm9, [rsp+0x90]
0000796caedd2373  vmovaps xmm10, [rsp+0xA0]
0000796caedd237c  vmovaps xmm11, [rsp+0xB0]
0000796caedd2385  vmovaps xmm12, [rsp+0xC0]
0000796caedd238e  vmovaps xmm13, [rsp+0xD0]
0000796caedd2397  vmovaps xmm15, [rsp+0xE0]
0000796caedd23a0  add rsp, 0xF0
0000796caedd23a7  pop r11
0000796caedd23a9  pop r10
0000796caedd23ab  pop r9
0000796caedd23ad  pop r8
0000796caedd23af  pop rsi
0000796caedd23b0  pop rdi
0000796caedd23b1  pop rdx
0000796caedd23b2  pop rcx
0000796caedd23b3  pop rax
0000796caedd23b4  add rsp, 0x08
0000796caedd23b8  jmp 0x0000796CAEDCFC21
0000796caedd23bd  sub rsp, 0x08
0000796caedd23c1  push rax
0000796caedd23c2  push rcx
0000796caedd23c3  push rdx
0000796caedd23c4  push rdi
0000796caedd23c5  push rsi
0000796caedd23c6  push r8
0000796caedd23c8  push r9
0000796caedd23ca  push r10
0000796caedd23cc  push r11
0000796caedd23ce  sub rsp, 0xF0
0000796caedd23d5  vmovaps [rsp], xmm0
0000796caedd23da  vmovaps [rsp+0x10], xmm1
0000796caedd23e0  vmovaps [rsp+0x20], xmm2
0000796caedd23e6  vmovaps [rsp+0x30], xmm3
0000796caedd23ec  vmovaps [rsp+0x40], xmm4
0000796caedd23f2  vmovaps [rsp+0x50], xmm5
0000796caedd23f8  vmovaps [rsp+0x60], xmm6
0000796caedd23fe  vmovaps [rsp+0x70], xmm7
0000796caedd2404  vmovaps [rsp+0x80], xmm8
0000796caedd240d  vmovaps [rsp+0x90], xmm9
0000796caedd2416  vmovaps [rsp+0xA0], xmm10
0000796caedd241f  vmovaps [rsp+0xB0], xmm11
0000796caedd2428  vmovaps [rsp+0xC0], xmm12
0000796caedd2431  vmovaps [rsp+0xD0], xmm14
0000796caedd243a  vmovaps [rsp+0xE0], xmm15
0000796caedd2443  sub rsp, 0x30
0000796caedd2447  movaps [rsp], xmm13
0000796caedd244c  movaps [rsp+0x10], xmm11
0000796caedd2452  movaps [rsp+0x20], xmm1
0000796caedd2457  lea rdi, [rsp]
0000796caedd245b  mov esi, 0x00
0000796caedd2460  mov rax, 0x56877063A530
0000796caedd246a  call rax
0000796caedd246c  movaps xmm13, [rsp]
0000796caedd2471  add rsp, 0x30
0000796caedd2475  vmovaps xmm0, [rsp]
0000796caedd247a  vmovaps xmm1, [rsp+0x10]
0000796caedd2480  vmovaps xmm2, [rsp+0x20]
0000796caedd2486  vmovaps xmm3, [rsp+0x30]
0000796caedd248c  vmovaps xmm4, [rsp+0x40]
0000796caedd2492  vmovaps xmm5, [rsp+0x50]
0000796caedd2498  vmovaps xmm6, [rsp+0x60]
0000796caedd249e  vmovaps xmm7, [rsp+0x70]
0000796caedd24a4  vmovaps xmm8, [rsp+0x80]
0000796caedd24ad  vmovaps xmm9, [rsp+0x90]
0000796caedd24b6  vmovaps xmm10, [rsp+0xA0]
0000796caedd24bf  vmovaps xmm11, [rsp+0xB0]
0000796caedd24c8  vmovaps xmm12, [rsp+0xC0]
0000796caedd24d1  vmovaps xmm14, [rsp+0xD0]
0000796caedd24da  vmovaps xmm15, [rsp+0xE0]
0000796caedd24e3  add rsp, 0xF0
0000796caedd24ea  pop r11
0000796caedd24ec  pop r10
0000796caedd24ee  pop r9
0000796caedd24f0  pop r8
0000796caedd24f2  pop rsi
0000796caedd24f3  pop rdi
0000796caedd24f4  pop rdx
0000796caedd24f5  pop rcx
0000796caedd24f6  pop rax
0000796caedd24f7  add rsp, 0x08
0000796caedd24fb  jmp 0x0000796CAEDCFC76
0000796caedd2500  call 0x0000796CAEBFF430
0000796caedd2505  jmp 0x0000796CAEDCFC83
0000796caedd250a  sub rsp, 0x08
0000796caedd250e  push rax
0000796caedd250f  push rcx
0000796caedd2510  push rdx
0000796caedd2511  push rdi
0000796caedd2512  push rsi
0000796caedd2513  push r8
0000796caedd2515  push r9
0000796caedd2517  push r10
0000796caedd2519  push r11
0000796caedd251b  sub rsp, 0xF0
0000796caedd2522  vmovaps [rsp], xmm0
0000796caedd2527  vmovaps [rsp+0x10], xmm1
0000796caedd252d  vmovaps [rsp+0x20], xmm2
0000796caedd2533  vmovaps [rsp+0x30], xmm3
0000796caedd2539  vmovaps [rsp+0x40], xmm4
0000796caedd253f  vmovaps [rsp+0x50], xmm5
0000796caedd2545  vmovaps [rsp+0x60], xmm6
0000796caedd254b  vmovaps [rsp+0x70], xmm7
0000796caedd2551  vmovaps [rsp+0x80], xmm8
0000796caedd255a  vmovaps [rsp+0x90], xmm9
0000796caedd2563  vmovaps [rsp+0xA0], xmm10
0000796caedd256c  vmovaps [rsp+0xB0], xmm11
0000796caedd2575  vmovaps [rsp+0xC0], xmm12
0000796caedd257e  vmovaps [rsp+0xD0], xmm13
0000796caedd2587  vmovaps [rsp+0xE0], xmm14
0000796caedd2590  sub rsp, 0x30
0000796caedd2594  movaps [rsp], xmm15
0000796caedd2599  movaps [rsp+0x10], xmm11
0000796caedd259f  movaps [rsp+0x20], xmm1
0000796caedd25a4  lea rdi, [rsp]
0000796caedd25a8  mov esi, 0x00
0000796caedd25ad  mov rax, 0x56877063A530
0000796caedd25b7  call rax
0000796caedd25b9  movaps xmm15, [rsp]
0000796caedd25be  add rsp, 0x30
0000796caedd25c2  vmovaps xmm0, [rsp]
0000796caedd25c7  vmovaps xmm1, [rsp+0x10]
0000796caedd25cd  vmovaps xmm2, [rsp+0x20]
0000796caedd25d3  vmovaps xmm3, [rsp+0x30]
0000796caedd25d9  vmovaps xmm4, [rsp+0x40]
0000796caedd25df  vmovaps xmm5, [rsp+0x50]
0000796caedd25e5  vmovaps xmm6, [rsp+0x60]
0000796caedd25eb  vmovaps xmm7, [rsp+0x70]
0000796caedd25f1  vmovaps xmm8, [rsp+0x80]
0000796caedd25fa  vmovaps xmm9, [rsp+0x90]
0000796caedd2603  vmovaps xmm10, [rsp+0xA0]
0000796caedd260c  vmovaps xmm11, [rsp+0xB0]
0000796caedd2615  vmovaps xmm12, [rsp+0xC0]
0000796caedd261e  vmovaps xmm13, [rsp+0xD0]
0000796caedd2627  vmovaps xmm14, [rsp+0xE0]
0000796caedd2630  add rsp, 0xF0
0000796caedd2637  pop r11
0000796caedd2639  pop r10
0000796caedd263b  pop r9
0000796caedd263d  pop r8
0000796caedd263f  pop rsi
0000796caedd2640  pop rdi
0000796caedd2641  pop rdx
0000796caedd2642  pop rcx
0000796caedd2643  pop rax
0000796caedd2644  add rsp, 0x08
0000796caedd2648  jmp 0x0000796CAEDCFCBC
0000796caedd264d  sub rsp, 0x08
0000796caedd2651  push rax
0000796caedd2652  push rcx
0000796caedd2653  push rdx
0000796caedd2654  push rdi
0000796caedd2655  push rsi
0000796caedd2656  push r8
0000796caedd2658  push r9
0000796caedd265a  push r10
0000796caedd265c  push r11
0000796caedd265e  sub rsp, 0xF0
0000796caedd2665  vmovaps [rsp], xmm0
0000796caedd266a  vmovaps [rsp+0x10], xmm1
0000796caedd2670  vmovaps [rsp+0x20], xmm2
0000796caedd2676  vmovaps [rsp+0x30], xmm3
0000796caedd267c  vmovaps [rsp+0x40], xmm4
0000796caedd2682  vmovaps [rsp+0x50], xmm5
0000796caedd2688  vmovaps [rsp+0x60], xmm6
0000796caedd268e  vmovaps [rsp+0x70], xmm7
0000796caedd2694  vmovaps [rsp+0x80], xmm8
0000796caedd269d  vmovaps [rsp+0x90], xmm9
0000796caedd26a6  vmovaps [rsp+0xA0], xmm10
0000796caedd26af  vmovaps [rsp+0xB0], xmm12
0000796caedd26b8  vmovaps [rsp+0xC0], xmm13
0000796caedd26c1  vmovaps [rsp+0xD0], xmm14
0000796caedd26ca  vmovaps [rsp+0xE0], xmm15
0000796caedd26d3  sub rsp, 0x30
0000796caedd26d7  movaps [rsp], xmm11
0000796caedd26dc  movaps [rsp+0x10], xmm6
0000796caedd26e1  movaps [rsp+0x20], xmm14
0000796caedd26e7  lea rdi, [rsp]
0000796caedd26eb  mov esi, 0x00
0000796caedd26f0  mov rax, 0x56877063A530
0000796caedd26fa  call rax
0000796caedd26fc  movaps xmm11, [rsp]
0000796caedd2701  add rsp, 0x30
0000796caedd2705  vmovaps xmm0, [rsp]
0000796caedd270a  vmovaps xmm1, [rsp+0x10]
0000796caedd2710  vmovaps xmm2, [rsp+0x20]
0000796caedd2716  vmovaps xmm3, [rsp+0x30]
0000796caedd271c  vmovaps xmm4, [rsp+0x40]
0000796caedd2722  vmovaps xmm5, [rsp+0x50]
0000796caedd2728  vmovaps xmm6, [rsp+0x60]
0000796caedd272e  vmovaps xmm7, [rsp+0x70]
0000796caedd2734  vmovaps xmm8, [rsp+0x80]
0000796caedd273d  vmovaps xmm9, [rsp+0x90]
0000796caedd2746  vmovaps xmm10, [rsp+0xA0]
0000796caedd274f  vmovaps xmm12, [rsp+0xB0]
0000796caedd2758  vmovaps xmm13, [rsp+0xC0]
0000796caedd2761  vmovaps xmm14, [rsp+0xD0]
0000796caedd276a  vmovaps xmm15, [rsp+0xE0]
0000796caedd2773  add rsp, 0xF0
0000796caedd277a  pop r11
0000796caedd277c  pop r10
0000796caedd277e  pop r9
0000796caedd2780  pop r8
0000796caedd2782  pop rsi
0000796caedd2783  pop rdi
0000796caedd2784  pop rdx
0000796caedd2785  pop rcx
0000796caedd2786  pop rax
0000796caedd2787  add rsp, 0x08
0000796caedd278b  jmp 0x0000796CAEDCFD34
0000796caedd2790  call 0x0000796CAEBFF430
0000796caedd2795  jmp 0x0000796CAEDCFD3E
0000796caedd279a  sub rsp, 0x08
0000796caedd279e  push rax
0000796caedd279f  push rcx
0000796caedd27a0  push rdx
0000796caedd27a1  push rdi
0000796caedd27a2  push rsi
0000796caedd27a3  push r8
0000796caedd27a5  push r9
0000796caedd27a7  push r10
0000796caedd27a9  push r11
0000796caedd27ab  sub rsp, 0xF0
0000796caedd27b2  vmovaps [rsp], xmm0
0000796caedd27b7  vmovaps [rsp+0x10], xmm1
0000796caedd27bd  vmovaps [rsp+0x20], xmm2
0000796caedd27c3  vmovaps [rsp+0x30], xmm3
0000796caedd27c9  vmovaps [rsp+0x40], xmm4
0000796caedd27cf  vmovaps [rsp+0x50], xmm5
0000796caedd27d5  vmovaps [rsp+0x60], xmm6
0000796caedd27db  vmovaps [rsp+0x70], xmm7
0000796caedd27e1  vmovaps [rsp+0x80], xmm8
0000796caedd27ea  vmovaps [rsp+0x90], xmm9
0000796caedd27f3  vmovaps [rsp+0xA0], xmm10
0000796caedd27fc  vmovaps [rsp+0xB0], xmm11
0000796caedd2805  vmovaps [rsp+0xC0], xmm12
0000796caedd280e  vmovaps [rsp+0xD0], xmm13
0000796caedd2817  vmovaps [rsp+0xE0], xmm15
0000796caedd2820  sub rsp, 0x30
0000796caedd2824  movaps [rsp], xmm14
0000796caedd2829  movaps [rsp+0x10], xmm6
0000796caedd282e  movaps [rsp+0x20], xmm2
0000796caedd2833  lea rdi, [rsp]
0000796caedd2837  mov esi, 0x00
0000796caedd283c  mov rax, 0x56877063A530
0000796caedd2846  call rax
0000796caedd2848  movaps xmm14, [rsp]
0000796caedd284d  add rsp, 0x30
0000796caedd2851  vmovaps xmm0, [rsp]
0000796caedd2856  vmovaps xmm1, [rsp+0x10]
0000796caedd285c  vmovaps xmm2, [rsp+0x20]
0000796caedd2862  vmovaps xmm3, [rsp+0x30]
0000796caedd2868  vmovaps xmm4, [rsp+0x40]
0000796caedd286e  vmovaps xmm5, [rsp+0x50]
0000796caedd2874  vmovaps xmm6, [rsp+0x60]
0000796caedd287a  vmovaps xmm7, [rsp+0x70]
0000796caedd2880  vmovaps xmm8, [rsp+0x80]
0000796caedd2889  vmovaps xmm9, [rsp+0x90]
0000796caedd2892  vmovaps xmm10, [rsp+0xA0]
0000796caedd289b  vmovaps xmm11, [rsp+0xB0]
0000796caedd28a4  vmovaps xmm12, [rsp+0xC0]
0000796caedd28ad  vmovaps xmm13, [rsp+0xD0]
0000796caedd28b6  vmovaps xmm15, [rsp+0xE0]
0000796caedd28bf  add rsp, 0xF0
0000796caedd28c6  pop r11
0000796caedd28c8  pop r10
0000796caedd28ca  pop r9
0000796caedd28cc  pop r8
0000796caedd28ce  pop rsi
0000796caedd28cf  pop rdi
0000796caedd28d0  pop rdx
0000796caedd28d1  pop rcx
0000796caedd28d2  pop rax
0000796caedd28d3  add rsp, 0x08
0000796caedd28d7  jmp 0x0000796CAEDCFD72
0000796caedd28dc  sub rsp, 0x08
0000796caedd28e0  push rax
0000796caedd28e1  push rcx
0000796caedd28e2  push rdx
0000796caedd28e3  push rdi
0000796caedd28e4  push rsi
0000796caedd28e5  push r8
0000796caedd28e7  push r9
0000796caedd28e9  push r10
0000796caedd28eb  push r11
0000796caedd28ed  sub rsp, 0xF0
0000796caedd28f4  vmovaps [rsp], xmm0
0000796caedd28f9  vmovaps [rsp+0x10], xmm1
0000796caedd28ff  vmovaps [rsp+0x20], xmm2
0000796caedd2905  vmovaps [rsp+0x30], xmm3
0000796caedd290b  vmovaps [rsp+0x40], xmm4
0000796caedd2911  vmovaps [rsp+0x50], xmm5
0000796caedd2917  vmovaps [rsp+0x60], xmm7
0000796caedd291d  vmovaps [rsp+0x70], xmm8
0000796caedd2923  vmovaps [rsp+0x80], xmm9
0000796caedd292c  vmovaps [rsp+0x90], xmm10
0000796caedd2935  vmovaps [rsp+0xA0], xmm11
0000796caedd293e  vmovaps [rsp+0xB0], xmm12
0000796caedd2947  vmovaps [rsp+0xC0], xmm13
0000796caedd2950  vmovaps [rsp+0xD0], xmm14
0000796caedd2959  vmovaps [rsp+0xE0], xmm15
0000796caedd2962  sub rsp, 0x30
0000796caedd2966  movaps [rsp], xmm6
0000796caedd296a  movaps [rsp+0x10], xmm5
0000796caedd296f  movaps [rsp+0x20], xmm1
0000796caedd2974  lea rdi, [rsp]
0000796caedd2978  mov esi, 0x00
0000796caedd297d  mov rax, 0x56877063A530
0000796caedd2987  call rax
0000796caedd2989  movaps xmm6, [rsp]
0000796caedd298d  add rsp, 0x30
0000796caedd2991  vmovaps xmm0, [rsp]
0000796caedd2996  vmovaps xmm1, [rsp+0x10]
0000796caedd299c  vmovaps xmm2, [rsp+0x20]
0000796caedd29a2  vmovaps xmm3, [rsp+0x30]
0000796caedd29a8  vmovaps xmm4, [rsp+0x40]
0000796caedd29ae  vmovaps xmm5, [rsp+0x50]
0000796caedd29b4  vmovaps xmm7, [rsp+0x60]
0000796caedd29ba  vmovaps xmm8, [rsp+0x70]
0000796caedd29c0  vmovaps xmm9, [rsp+0x80]
0000796caedd29c9  vmovaps xmm10, [rsp+0x90]
0000796caedd29d2  vmovaps xmm11, [rsp+0xA0]
0000796caedd29db  vmovaps xmm12, [rsp+0xB0]
0000796caedd29e4  vmovaps xmm13, [rsp+0xC0]
0000796caedd29ed  vmovaps xmm14, [rsp+0xD0]
0000796caedd29f6  vmovaps xmm15, [rsp+0xE0]
0000796caedd29ff  add rsp, 0xF0
0000796caedd2a06  pop r11
0000796caedd2a08  pop r10
0000796caedd2a0a  pop r9
0000796caedd2a0c  pop r8
0000796caedd2a0e  pop rsi
0000796caedd2a0f  pop rdi
0000796caedd2a10  pop rdx
0000796caedd2a11  pop rcx
0000796caedd2a12  pop rax
0000796caedd2a13  add rsp, 0x08
0000796caedd2a17  jmp 0x0000796CAEDCFD98
0000796caedd2a1c  sub rsp, 0x08
0000796caedd2a20  push rax
0000796caedd2a21  push rcx
0000796caedd2a22  push rdx
0000796caedd2a23  push rdi
0000796caedd2a24  push rsi
0000796caedd2a25  push r8
0000796caedd2a27  push r9
0000796caedd2a29  push r10
0000796caedd2a2b  push r11
0000796caedd2a2d  sub rsp, 0xF0
0000796caedd2a34  vmovaps [rsp], xmm0
0000796caedd2a39  vmovaps [rsp+0x10], xmm2
0000796caedd2a3f  vmovaps [rsp+0x20], xmm3
0000796caedd2a45  vmovaps [rsp+0x30], xmm4
0000796caedd2a4b  vmovaps [rsp+0x40], xmm5
0000796caedd2a51  vmovaps [rsp+0x50], xmm6
0000796caedd2a57  vmovaps [rsp+0x60], xmm7
0000796caedd2a5d  vmovaps [rsp+0x70], xmm8
0000796caedd2a63  vmovaps [rsp+0x80], xmm9
0000796caedd2a6c  vmovaps [rsp+0x90], xmm10
0000796caedd2a75  vmovaps [rsp+0xA0], xmm11
0000796caedd2a7e  vmovaps [rsp+0xB0], xmm12
0000796caedd2a87  vmovaps [rsp+0xC0], xmm13
0000796caedd2a90  vmovaps [rsp+0xD0], xmm14
0000796caedd2a99  vmovaps [rsp+0xE0], xmm15
0000796caedd2aa2  sub rsp, 0x30
0000796caedd2aa6  movaps [rsp], xmm1
0000796caedd2aaa  movaps [rsp+0x10], xmm5
0000796caedd2aaf  movaps [rsp+0x20], xmm13
0000796caedd2ab5  lea rdi, [rsp]
0000796caedd2ab9  mov esi, 0x00
0000796caedd2abe  mov rax, 0x56877063A530
0000796caedd2ac8  call rax
0000796caedd2aca  movaps xmm1, [rsp]
0000796caedd2ace  add rsp, 0x30
0000796caedd2ad2  vmovaps xmm0, [rsp]
0000796caedd2ad7  vmovaps xmm2, [rsp+0x10]
0000796caedd2add  vmovaps xmm3, [rsp+0x20]
0000796caedd2ae3  vmovaps xmm4, [rsp+0x30]
0000796caedd2ae9  vmovaps xmm5, [rsp+0x40]
0000796caedd2aef  vmovaps xmm6, [rsp+0x50]
0000796caedd2af5  vmovaps xmm7, [rsp+0x60]
0000796caedd2afb  vmovaps xmm8, [rsp+0x70]
0000796caedd2b01  vmovaps xmm9, [rsp+0x80]
0000796caedd2b0a  vmovaps xmm10, [rsp+0x90]
0000796caedd2b13  vmovaps xmm11, [rsp+0xA0]
0000796caedd2b1c  vmovaps xmm12, [rsp+0xB0]
0000796caedd2b25  vmovaps xmm13, [rsp+0xC0]
0000796caedd2b2e  vmovaps xmm14, [rsp+0xD0]
0000796caedd2b37  vmovaps xmm15, [rsp+0xE0]
0000796caedd2b40  add rsp, 0xF0
0000796caedd2b47  pop r11
0000796caedd2b49  pop r10
0000796caedd2b4b  pop r9
0000796caedd2b4d  pop r8
0000796caedd2b4f  pop rsi
0000796caedd2b50  pop rdi
0000796caedd2b51  pop rdx
0000796caedd2b52  pop rcx
0000796caedd2b53  pop rax
0000796caedd2b54  add rsp, 0x08
0000796caedd2b58  jmp 0x0000796CAEDCFDB6
0000796caedd2b5d  sub rsp, 0x08
0000796caedd2b61  push rax
0000796caedd2b62  push rcx
0000796caedd2b63  push rdx
0000796caedd2b64  push rdi
0000796caedd2b65  push rsi
0000796caedd2b66  push r8
0000796caedd2b68  push r9
0000796caedd2b6a  push r10
0000796caedd2b6c  push r11
0000796caedd2b6e  sub rsp, 0xF0
0000796caedd2b75  vmovaps [rsp], xmm0
0000796caedd2b7a  vmovaps [rsp+0x10], xmm1
0000796caedd2b80  vmovaps [rsp+0x20], xmm2
0000796caedd2b86  vmovaps [rsp+0x30], xmm3
0000796caedd2b8c  vmovaps [rsp+0x40], xmm4
0000796caedd2b92  vmovaps [rsp+0x50], xmm6
0000796caedd2b98  vmovaps [rsp+0x60], xmm7
0000796caedd2b9e  vmovaps [rsp+0x70], xmm8
0000796caedd2ba4  vmovaps [rsp+0x80], xmm9
0000796caedd2bad  vmovaps [rsp+0x90], xmm10
0000796caedd2bb6  vmovaps [rsp+0xA0], xmm11
0000796caedd2bbf  vmovaps [rsp+0xB0], xmm12
0000796caedd2bc8  vmovaps [rsp+0xC0], xmm13
0000796caedd2bd1  vmovaps [rsp+0xD0], xmm14
0000796caedd2bda  vmovaps [rsp+0xE0], xmm15
0000796caedd2be3  sub rsp, 0x30
0000796caedd2be7  movaps [rsp], xmm5
0000796caedd2beb  movaps [rsp+0x10], xmm2
0000796caedd2bf0  movaps [rsp+0x20], xmm13
0000796caedd2bf6  lea rdi, [rsp]
0000796caedd2bfa  mov esi, 0x00
0000796caedd2bff  mov rax, 0x56877063A530
0000796caedd2c09  call rax
0000796caedd2c0b  movaps xmm5, [rsp]
0000796caedd2c0f  add rsp, 0x30
0000796caedd2c13  vmovaps xmm0, [rsp]
0000796caedd2c18  vmovaps xmm1, [rsp+0x10]
0000796caedd2c1e  vmovaps xmm2, [rsp+0x20]
0000796caedd2c24  vmovaps xmm3, [rsp+0x30]
0000796caedd2c2a  vmovaps xmm4, [rsp+0x40]
0000796caedd2c30  vmovaps xmm6, [rsp+0x50]
0000796caedd2c36  vmovaps xmm7, [rsp+0x60]
0000796caedd2c3c  vmovaps xmm8, [rsp+0x70]
0000796caedd2c42  vmovaps xmm9, [rsp+0x80]
0000796caedd2c4b  vmovaps xmm10, [rsp+0x90]
0000796caedd2c54  vmovaps xmm11, [rsp+0xA0]
0000796caedd2c5d  vmovaps xmm12, [rsp+0xB0]
0000796caedd2c66  vmovaps xmm13, [rsp+0xC0]
0000796caedd2c6f  vmovaps xmm14, [rsp+0xD0]
0000796caedd2c78  vmovaps xmm15, [rsp+0xE0]
0000796caedd2c81  add rsp, 0xF0
0000796caedd2c88  pop r11
0000796caedd2c8a  pop r10
0000796caedd2c8c  pop r9
0000796caedd2c8e  pop r8
0000796caedd2c90  pop rsi
0000796caedd2c91  pop rdi
0000796caedd2c92  pop rdx
0000796caedd2c93  pop rcx
0000796caedd2c94  pop rax
0000796caedd2c95  add rsp, 0x08
0000796caedd2c99  jmp 0x0000796CAEDCFDEC
0000796caedd2c9e  sub rsp, 0x08
0000796caedd2ca2  push rax
0000796caedd2ca3  push rcx
0000796caedd2ca4  push rdx
0000796caedd2ca5  push rdi
0000796caedd2ca6  push rsi
0000796caedd2ca7  push r8
0000796caedd2ca9  push r9
0000796caedd2cab  push r10
0000796caedd2cad  push r11
0000796caedd2caf  sub rsp, 0xF0
0000796caedd2cb6  vmovaps [rsp], xmm0
0000796caedd2cbb  vmovaps [rsp+0x10], xmm1
0000796caedd2cc1  vmovaps [rsp+0x20], xmm2
0000796caedd2cc7  vmovaps [rsp+0x30], xmm3
0000796caedd2ccd  vmovaps [rsp+0x40], xmm4
0000796caedd2cd3  vmovaps [rsp+0x50], xmm5
0000796caedd2cd9  vmovaps [rsp+0x60], xmm6
0000796caedd2cdf  vmovaps [rsp+0x70], xmm7
0000796caedd2ce5  vmovaps [rsp+0x80], xmm8
0000796caedd2cee  vmovaps [rsp+0x90], xmm9
0000796caedd2cf7  vmovaps [rsp+0xA0], xmm10
0000796caedd2d00  vmovaps [rsp+0xB0], xmm11
0000796caedd2d09  vmovaps [rsp+0xC0], xmm12
0000796caedd2d12  vmovaps [rsp+0xD0], xmm14
0000796caedd2d1b  vmovaps [rsp+0xE0], xmm15
0000796caedd2d24  sub rsp, 0x30
0000796caedd2d28  movaps [rsp], xmm13
0000796caedd2d2d  movaps [rsp+0x10], xmm10
0000796caedd2d33  movaps [rsp+0x20], xmm1
0000796caedd2d38  lea rdi, [rsp]
0000796caedd2d3c  mov esi, 0x00
0000796caedd2d41  mov rax, 0x56877063A530
0000796caedd2d4b  call rax
0000796caedd2d4d  movaps xmm13, [rsp]
0000796caedd2d52  add rsp, 0x30
0000796caedd2d56  vmovaps xmm0, [rsp]
0000796caedd2d5b  vmovaps xmm1, [rsp+0x10]
0000796caedd2d61  vmovaps xmm2, [rsp+0x20]
0000796caedd2d67  vmovaps xmm3, [rsp+0x30]
0000796caedd2d6d  vmovaps xmm4, [rsp+0x40]
0000796caedd2d73  vmovaps xmm5, [rsp+0x50]
0000796caedd2d79  vmovaps xmm6, [rsp+0x60]
0000796caedd2d7f  vmovaps xmm7, [rsp+0x70]
0000796caedd2d85  vmovaps xmm8, [rsp+0x80]
0000796caedd2d8e  vmovaps xmm9, [rsp+0x90]
0000796caedd2d97  vmovaps xmm10, [rsp+0xA0]
0000796caedd2da0  vmovaps xmm11, [rsp+0xB0]
0000796caedd2da9  vmovaps xmm12, [rsp+0xC0]
0000796caedd2db2  vmovaps xmm14, [rsp+0xD0]
0000796caedd2dbb  vmovaps xmm15, [rsp+0xE0]
0000796caedd2dc4  add rsp, 0xF0
0000796caedd2dcb  pop r11
0000796caedd2dcd  pop r10
0000796caedd2dcf  pop r9
0000796caedd2dd1  pop r8
0000796caedd2dd3  pop rsi
0000796caedd2dd4  pop rdi
0000796caedd2dd5  pop rdx
0000796caedd2dd6  pop rcx
0000796caedd2dd7  pop rax
0000796caedd2dd8  add rsp, 0x08
0000796caedd2ddc  jmp 0x0000796CAEDCFE15
0000796caedd2de1  sub rsp, 0x08
0000796caedd2de5  push rax
0000796caedd2de6  push rcx
0000796caedd2de7  push rdx
0000796caedd2de8  push rdi
0000796caedd2de9  push rsi
0000796caedd2dea  push r8
0000796caedd2dec  push r9
0000796caedd2dee  push r10
0000796caedd2df0  push r11
0000796caedd2df2  sub rsp, 0xF0
0000796caedd2df9  vmovaps [rsp], xmm0
0000796caedd2dfe  vmovaps [rsp+0x10], xmm2
0000796caedd2e04  vmovaps [rsp+0x20], xmm3
0000796caedd2e0a  vmovaps [rsp+0x30], xmm4
0000796caedd2e10  vmovaps [rsp+0x40], xmm5
0000796caedd2e16  vmovaps [rsp+0x50], xmm6
0000796caedd2e1c  vmovaps [rsp+0x60], xmm7
0000796caedd2e22  vmovaps [rsp+0x70], xmm8
0000796caedd2e28  vmovaps [rsp+0x80], xmm9
0000796caedd2e31  vmovaps [rsp+0x90], xmm10
0000796caedd2e3a  vmovaps [rsp+0xA0], xmm11
0000796caedd2e43  vmovaps [rsp+0xB0], xmm12
0000796caedd2e4c  vmovaps [rsp+0xC0], xmm13
0000796caedd2e55  vmovaps [rsp+0xD0], xmm14
0000796caedd2e5e  vmovaps [rsp+0xE0], xmm15
0000796caedd2e67  sub rsp, 0x30
0000796caedd2e6b  movaps [rsp], xmm1
0000796caedd2e6f  movaps [rsp+0x10], xmm15
0000796caedd2e75  movaps [rsp+0x20], xmm10
0000796caedd2e7b  lea rdi, [rsp]
0000796caedd2e7f  mov esi, 0x00
0000796caedd2e84  mov rax, 0x56877063A530
0000796caedd2e8e  call rax
0000796caedd2e90  movaps xmm1, [rsp]
0000796caedd2e94  add rsp, 0x30
0000796caedd2e98  vmovaps xmm0, [rsp]
0000796caedd2e9d  vmovaps xmm2, [rsp+0x10]
0000796caedd2ea3  vmovaps xmm3, [rsp+0x20]
0000796caedd2ea9  vmovaps xmm4, [rsp+0x30]
0000796caedd2eaf  vmovaps xmm5, [rsp+0x40]
0000796caedd2eb5  vmovaps xmm6, [rsp+0x50]
0000796caedd2ebb  vmovaps xmm7, [rsp+0x60]
0000796caedd2ec1  vmovaps xmm8, [rsp+0x70]
0000796caedd2ec7  vmovaps xmm9, [rsp+0x80]
0000796caedd2ed0  vmovaps xmm10, [rsp+0x90]
0000796caedd2ed9  vmovaps xmm11, [rsp+0xA0]
0000796caedd2ee2  vmovaps xmm12, [rsp+0xB0]
0000796caedd2eeb  vmovaps xmm13, [rsp+0xC0]
0000796caedd2ef4  vmovaps xmm14, [rsp+0xD0]
0000796caedd2efd  vmovaps xmm15, [rsp+0xE0]
0000796caedd2f06  add rsp, 0xF0
0000796caedd2f0d  pop r11
0000796caedd2f0f  pop r10
0000796caedd2f11  pop r9
0000796caedd2f13  pop r8
0000796caedd2f15  pop rsi
0000796caedd2f16  pop rdi
0000796caedd2f17  pop rdx
0000796caedd2f18  pop rcx
0000796caedd2f19  pop rax
0000796caedd2f1a  add rsp, 0x08
0000796caedd2f1e  jmp 0x0000796CAEDCFE34
0000796caedd2f23  sub rsp, 0x08
0000796caedd2f27  push rax
0000796caedd2f28  push rcx
0000796caedd2f29  push rdx
0000796caedd2f2a  push rdi
0000796caedd2f2b  push rsi
0000796caedd2f2c  push r8
0000796caedd2f2e  push r9
0000796caedd2f30  push r10
0000796caedd2f32  push r11
0000796caedd2f34  sub rsp, 0xF0
0000796caedd2f3b  vmovaps [rsp], xmm0
0000796caedd2f40  vmovaps [rsp+0x10], xmm1
0000796caedd2f46  vmovaps [rsp+0x20], xmm2
0000796caedd2f4c  vmovaps [rsp+0x30], xmm3
0000796caedd2f52  vmovaps [rsp+0x40], xmm4
0000796caedd2f58  vmovaps [rsp+0x50], xmm5
0000796caedd2f5e  vmovaps [rsp+0x60], xmm6
0000796caedd2f64  vmovaps [rsp+0x70], xmm7
0000796caedd2f6a  vmovaps [rsp+0x80], xmm8
0000796caedd2f73  vmovaps [rsp+0x90], xmm9
0000796caedd2f7c  vmovaps [rsp+0xA0], xmm10
0000796caedd2f85  vmovaps [rsp+0xB0], xmm11
0000796caedd2f8e  vmovaps [rsp+0xC0], xmm12
0000796caedd2f97  vmovaps [rsp+0xD0], xmm13
0000796caedd2fa0  vmovaps [rsp+0xE0], xmm14
0000796caedd2fa9  sub rsp, 0x30
0000796caedd2fad  movaps [rsp], xmm15
0000796caedd2fb2  movaps [rsp+0x10], xmm10
0000796caedd2fb8  movaps [rsp+0x20], xmm11
0000796caedd2fbe  lea rdi, [rsp]
0000796caedd2fc2  mov esi, 0x00
0000796caedd2fc7  mov rax, 0x56877063A530
0000796caedd2fd1  call rax
0000796caedd2fd3  movaps xmm15, [rsp]
0000796caedd2fd8  add rsp, 0x30
0000796caedd2fdc  vmovaps xmm0, [rsp]
0000796caedd2fe1  vmovaps xmm1, [rsp+0x10]
0000796caedd2fe7  vmovaps xmm2, [rsp+0x20]
0000796caedd2fed  vmovaps xmm3, [rsp+0x30]
0000796caedd2ff3  vmovaps xmm4, [rsp+0x40]
0000796caedd2ff9  vmovaps xmm5, [rsp+0x50]
0000796caedd2fff  vmovaps xmm6, [rsp+0x60]
0000796caedd3005  vmovaps xmm7, [rsp+0x70]
0000796caedd300b  vmovaps xmm8, [rsp+0x80]
0000796caedd3014  vmovaps xmm9, [rsp+0x90]
0000796caedd301d  vmovaps xmm10, [rsp+0xA0]
0000796caedd3026  vmovaps xmm11, [rsp+0xB0]
0000796caedd302f  vmovaps xmm12, [rsp+0xC0]
0000796caedd3038  vmovaps xmm13, [rsp+0xD0]
0000796caedd3041  vmovaps xmm14, [rsp+0xE0]
0000796caedd304a  add rsp, 0xF0
0000796caedd3051  pop r11
0000796caedd3053  pop r10
0000796caedd3055  pop r9
0000796caedd3057  pop r8
0000796caedd3059  pop rsi
0000796caedd305a  pop rdi
0000796caedd305b  pop rdx
0000796caedd305c  pop rcx
0000796caedd305d  pop rax
0000796caedd305e  add rsp, 0x08
0000796caedd3062  jmp 0x0000796CAEDCFE57
0000796caedd3067  sub rsp, 0x08
0000796caedd306b  push rax
0000796caedd306c  push rcx
0000796caedd306d  push rdx
0000796caedd306e  push rdi
0000796caedd306f  push rsi
0000796caedd3070  push r8
0000796caedd3072  push r9
0000796caedd3074  push r10
0000796caedd3076  push r11
0000796caedd3078  sub rsp, 0xF0
0000796caedd307f  vmovaps [rsp], xmm0
0000796caedd3084  vmovaps [rsp+0x10], xmm1
0000796caedd308a  vmovaps [rsp+0x20], xmm2
0000796caedd3090  vmovaps [rsp+0x30], xmm3
0000796caedd3096  vmovaps [rsp+0x40], xmm4
0000796caedd309c  vmovaps [rsp+0x50], xmm5
0000796caedd30a2  vmovaps [rsp+0x60], xmm6
0000796caedd30a8  vmovaps [rsp+0x70], xmm7
0000796caedd30ae  vmovaps [rsp+0x80], xmm8
0000796caedd30b7  vmovaps [rsp+0x90], xmm9
0000796caedd30c0  vmovaps [rsp+0xA0], xmm11
0000796caedd30c9  vmovaps [rsp+0xB0], xmm12
0000796caedd30d2  vmovaps [rsp+0xC0], xmm13
0000796caedd30db  vmovaps [rsp+0xD0], xmm14
0000796caedd30e4  vmovaps [rsp+0xE0], xmm15
0000796caedd30ed  sub rsp, 0x30
0000796caedd30f1  movaps [rsp], xmm10
0000796caedd30f6  movaps [rsp+0x10], xmm12
0000796caedd30fc  movaps [rsp+0x20], xmm11
0000796caedd3102  lea rdi, [rsp]
0000796caedd3106  mov esi, 0x00
0000796caedd310b  mov rax, 0x56877063A530
0000796caedd3115  call rax
0000796caedd3117  movaps xmm10, [rsp]
0000796caedd311c  add rsp, 0x30
0000796caedd3120  vmovaps xmm0, [rsp]
0000796caedd3125  vmovaps xmm1, [rsp+0x10]
0000796caedd312b  vmovaps xmm2, [rsp+0x20]
0000796caedd3131  vmovaps xmm3, [rsp+0x30]
0000796caedd3137  vmovaps xmm4, [rsp+0x40]
0000796caedd313d  vmovaps xmm5, [rsp+0x50]
0000796caedd3143  vmovaps xmm6, [rsp+0x60]
0000796caedd3149  vmovaps xmm7, [rsp+0x70]
0000796caedd314f  vmovaps xmm8, [rsp+0x80]
0000796caedd3158  vmovaps xmm9, [rsp+0x90]
0000796caedd3161  vmovaps xmm11, [rsp+0xA0]
0000796caedd316a  vmovaps xmm12, [rsp+0xB0]
0000796caedd3173  vmovaps xmm13, [rsp+0xC0]
0000796caedd317c  vmovaps xmm14, [rsp+0xD0]
0000796caedd3185  vmovaps xmm15, [rsp+0xE0]
0000796caedd318e  add rsp, 0xF0
0000796caedd3195  pop r11
0000796caedd3197  pop r10
0000796caedd3199  pop r9
0000796caedd319b  pop r8
0000796caedd319d  pop rsi
0000796caedd319e  pop rdi
0000796caedd319f  pop rdx
0000796caedd31a0  pop rcx
0000796caedd31a1  pop rax
0000796caedd31a2  add rsp, 0x08
0000796caedd31a6  jmp 0x0000796CAEDCFE80
0000796caedd31ab  sub rsp, 0x08
0000796caedd31af  push rax
0000796caedd31b0  push rcx
0000796caedd31b1  push rdx
0000796caedd31b2  push rdi
0000796caedd31b3  push rsi
0000796caedd31b4  push r8
0000796caedd31b6  push r9
0000796caedd31b8  push r10
0000796caedd31ba  push r11
0000796caedd31bc  sub rsp, 0xF0
0000796caedd31c3  vmovaps [rsp], xmm0
0000796caedd31c8  vmovaps [rsp+0x10], xmm1
0000796caedd31ce  vmovaps [rsp+0x20], xmm2
0000796caedd31d4  vmovaps [rsp+0x30], xmm3
0000796caedd31da  vmovaps [rsp+0x40], xmm4
0000796caedd31e0  vmovaps [rsp+0x50], xmm5
0000796caedd31e6  vmovaps [rsp+0x60], xmm6
0000796caedd31ec  vmovaps [rsp+0x70], xmm7
0000796caedd31f2  vmovaps [rsp+0x80], xmm8
0000796caedd31fb  vmovaps [rsp+0x90], xmm9
0000796caedd3204  vmovaps [rsp+0xA0], xmm10
0000796caedd320d  vmovaps [rsp+0xB0], xmm12
0000796caedd3216  vmovaps [rsp+0xC0], xmm13
0000796caedd321f  vmovaps [rsp+0xD0], xmm14
0000796caedd3228  vmovaps [rsp+0xE0], xmm15
0000796caedd3231  sub rsp, 0x30
0000796caedd3235  movaps [rsp], xmm11
0000796caedd323a  movaps [rsp+0x10], xmm2
0000796caedd323f  movaps [rsp+0x20], xmm12
0000796caedd3245  lea rdi, [rsp]
0000796caedd3249  mov esi, 0x00
0000796caedd324e  mov rax, 0x56877063A530
0000796caedd3258  call rax
0000796caedd325a  movaps xmm11, [rsp]
0000796caedd325f  add rsp, 0x30
0000796caedd3263  vmovaps xmm0, [rsp]
0000796caedd3268  vmovaps xmm1, [rsp+0x10]
0000796caedd326e  vmovaps xmm2, [rsp+0x20]
0000796caedd3274  vmovaps xmm3, [rsp+0x30]
0000796caedd327a  vmovaps xmm4, [rsp+0x40]
0000796caedd3280  vmovaps xmm5, [rsp+0x50]
0000796caedd3286  vmovaps xmm6, [rsp+0x60]
0000796caedd328c  vmovaps xmm7, [rsp+0x70]
0000796caedd3292  vmovaps xmm8, [rsp+0x80]
0000796caedd329b  vmovaps xmm9, [rsp+0x90]
0000796caedd32a4  vmovaps xmm10, [rsp+0xA0]
0000796caedd32ad  vmovaps xmm12, [rsp+0xB0]
0000796caedd32b6  vmovaps xmm13, [rsp+0xC0]
0000796caedd32bf  vmovaps xmm14, [rsp+0xD0]
0000796caedd32c8  vmovaps xmm15, [rsp+0xE0]
0000796caedd32d1  add rsp, 0xF0
0000796caedd32d8  pop r11
0000796caedd32da  pop r10
0000796caedd32dc  pop r9
0000796caedd32de  pop r8
0000796caedd32e0  pop rsi
0000796caedd32e1  pop rdi
0000796caedd32e2  pop rdx
0000796caedd32e3  pop rcx
0000796caedd32e4  pop rax
0000796caedd32e5  add rsp, 0x08
0000796caedd32e9  jmp 0x0000796CAEDCFEB8
0000796caedd32ee  sub rsp, 0x08
0000796caedd32f2  push rax
0000796caedd32f3  push rcx
0000796caedd32f4  push rdx
0000796caedd32f5  push rdi
0000796caedd32f6  push rsi
0000796caedd32f7  push r8
0000796caedd32f9  push r9
0000796caedd32fb  push r10
0000796caedd32fd  push r11
0000796caedd32ff  sub rsp, 0xF0
0000796caedd3306  vmovaps [rsp], xmm0
0000796caedd330b  vmovaps [rsp+0x10], xmm2
0000796caedd3311  vmovaps [rsp+0x20], xmm3
0000796caedd3317  vmovaps [rsp+0x30], xmm4
0000796caedd331d  vmovaps [rsp+0x40], xmm5
0000796caedd3323  vmovaps [rsp+0x50], xmm6
0000796caedd3329  vmovaps [rsp+0x60], xmm7
0000796caedd332f  vmovaps [rsp+0x70], xmm8
0000796caedd3335  vmovaps [rsp+0x80], xmm9
0000796caedd333e  vmovaps [rsp+0x90], xmm10
0000796caedd3347  vmovaps [rsp+0xA0], xmm11
0000796caedd3350  vmovaps [rsp+0xB0], xmm12
0000796caedd3359  vmovaps [rsp+0xC0], xmm13
0000796caedd3362  vmovaps [rsp+0xD0], xmm14
0000796caedd336b  vmovaps [rsp+0xE0], xmm15
0000796caedd3374  sub rsp, 0x30
0000796caedd3378  movaps [rsp], xmm1
0000796caedd337c  movaps [rsp+0x10], xmm14
0000796caedd3382  movaps [rsp+0x20], xmm6
0000796caedd3387  lea rdi, [rsp]
0000796caedd338b  mov esi, 0x00
0000796caedd3390  mov rax, 0x56877063A530
0000796caedd339a  call rax
0000796caedd339c  movaps xmm1, [rsp]
0000796caedd33a0  add rsp, 0x30
0000796caedd33a4  vmovaps xmm0, [rsp]
0000796caedd33a9  vmovaps xmm2, [rsp+0x10]
0000796caedd33af  vmovaps xmm3, [rsp+0x20]
0000796caedd33b5  vmovaps xmm4, [rsp+0x30]
0000796caedd33bb  vmovaps xmm5, [rsp+0x40]
0000796caedd33c1  vmovaps xmm6, [rsp+0x50]
0000796caedd33c7  vmovaps xmm7, [rsp+0x60]
0000796caedd33cd  vmovaps xmm8, [rsp+0x70]
0000796caedd33d3  vmovaps xmm9, [rsp+0x80]
0000796caedd33dc  vmovaps xmm10, [rsp+0x90]
0000796caedd33e5  vmovaps xmm11, [rsp+0xA0]
0000796caedd33ee  vmovaps xmm12, [rsp+0xB0]
0000796caedd33f7  vmovaps xmm13, [rsp+0xC0]
0000796caedd3400  vmovaps xmm14, [rsp+0xD0]
0000796caedd3409  vmovaps xmm15, [rsp+0xE0]
0000796caedd3412  add rsp, 0xF0
0000796caedd3419  pop r11
0000796caedd341b  pop r10
0000796caedd341d  pop r9
0000796caedd341f  pop r8
0000796caedd3421  pop rsi
0000796caedd3422  pop rdi
0000796caedd3423  pop rdx
0000796caedd3424  pop rcx
0000796caedd3425  pop rax
0000796caedd3426  add rsp, 0x08
0000796caedd342a  jmp 0x0000796CAEDCFED1
0000796caedd342f  sub rsp, 0x08
0000796caedd3433  push rax
0000796caedd3434  push rcx
0000796caedd3435  push rdx
0000796caedd3436  push rdi
0000796caedd3437  push rsi
0000796caedd3438  push r8
0000796caedd343a  push r9
0000796caedd343c  push r10
0000796caedd343e  push r11
0000796caedd3440  sub rsp, 0xF0
0000796caedd3447  vmovaps [rsp], xmm0
0000796caedd344c  vmovaps [rsp+0x10], xmm1
0000796caedd3452  vmovaps [rsp+0x20], xmm2
0000796caedd3458  vmovaps [rsp+0x30], xmm3
0000796caedd345e  vmovaps [rsp+0x40], xmm4
0000796caedd3464  vmovaps [rsp+0x50], xmm5
0000796caedd346a  vmovaps [rsp+0x60], xmm6
0000796caedd3470  vmovaps [rsp+0x70], xmm7
0000796caedd3476  vmovaps [rsp+0x80], xmm8
0000796caedd347f  vmovaps [rsp+0x90], xmm9
0000796caedd3488  vmovaps [rsp+0xA0], xmm10
0000796caedd3491  vmovaps [rsp+0xB0], xmm11
0000796caedd349a  vmovaps [rsp+0xC0], xmm12
0000796caedd34a3  vmovaps [rsp+0xD0], xmm13
0000796caedd34ac  vmovaps [rsp+0xE0], xmm15
0000796caedd34b5  sub rsp, 0x30
0000796caedd34b9  movaps [rsp], xmm14
0000796caedd34be  movaps [rsp+0x10], xmm12
0000796caedd34c4  movaps [rsp+0x20], xmm5
0000796caedd34c9  lea rdi, [rsp]
0000796caedd34cd  mov esi, 0x00
0000796caedd34d2  mov rax, 0x56877063A530
0000796caedd34dc  call rax
0000796caedd34de  movaps xmm14, [rsp]
0000796caedd34e3  add rsp, 0x30
0000796caedd34e7  vmovaps xmm0, [rsp]
0000796caedd34ec  vmovaps xmm1, [rsp+0x10]
0000796caedd34f2  vmovaps xmm2, [rsp+0x20]
0000796caedd34f8  vmovaps xmm3, [rsp+0x30]
0000796caedd34fe  vmovaps xmm4, [rsp+0x40]
0000796caedd3504  vmovaps xmm5, [rsp+0x50]
0000796caedd350a  vmovaps xmm6, [rsp+0x60]
0000796caedd3510  vmovaps xmm7, [rsp+0x70]
0000796caedd3516  vmovaps xmm8, [rsp+0x80]
0000796caedd351f  vmovaps xmm9, [rsp+0x90]
0000796caedd3528  vmovaps xmm10, [rsp+0xA0]
0000796caedd3531  vmovaps xmm11, [rsp+0xB0]
0000796caedd353a  vmovaps xmm12, [rsp+0xC0]
0000796caedd3543  vmovaps xmm13, [rsp+0xD0]
0000796caedd354c  vmovaps xmm15, [rsp+0xE0]
0000796caedd3555  add rsp, 0xF0
0000796caedd355c  pop r11
0000796caedd355e  pop r10
0000796caedd3560  pop r9
0000796caedd3562  pop r8
0000796caedd3564  pop rsi
0000796caedd3565  pop rdi
0000796caedd3566  pop rdx
0000796caedd3567  pop rcx
0000796caedd3568  pop rax
0000796caedd3569  add rsp, 0x08
0000796caedd356d  jmp 0x0000796CAEDCFEF1
0000796caedd3572  sub rsp, 0x08
0000796caedd3576  push rax
0000796caedd3577  push rcx
0000796caedd3578  push rdx
0000796caedd3579  push rdi
0000796caedd357a  push rsi
0000796caedd357b  push r8
0000796caedd357d  push r9
0000796caedd357f  push r10
0000796caedd3581  push r11
0000796caedd3583  sub rsp, 0xF0
0000796caedd358a  vmovaps [rsp], xmm0
0000796caedd358f  vmovaps [rsp+0x10], xmm1
0000796caedd3595  vmovaps [rsp+0x20], xmm2
0000796caedd359b  vmovaps [rsp+0x30], xmm3
0000796caedd35a1  vmovaps [rsp+0x40], xmm4
0000796caedd35a7  vmovaps [rsp+0x50], xmm5
0000796caedd35ad  vmovaps [rsp+0x60], xmm7
0000796caedd35b3  vmovaps [rsp+0x70], xmm8
0000796caedd35b9  vmovaps [rsp+0x80], xmm9
0000796caedd35c2  vmovaps [rsp+0x90], xmm10
0000796caedd35cb  vmovaps [rsp+0xA0], xmm11
0000796caedd35d4  vmovaps [rsp+0xB0], xmm12
0000796caedd35dd  vmovaps [rsp+0xC0], xmm13
0000796caedd35e6  vmovaps [rsp+0xD0], xmm14
0000796caedd35ef  vmovaps [rsp+0xE0], xmm15
0000796caedd35f8  sub rsp, 0x30
0000796caedd35fc  movaps [rsp], xmm6
0000796caedd3600  movaps [rsp+0x10], xmm9
0000796caedd3606  movaps [rsp+0x20], xmm12
0000796caedd360c  lea rdi, [rsp]
0000796caedd3610  mov esi, 0x00
0000796caedd3615  mov rax, 0x56877063A530
0000796caedd361f  call rax
0000796caedd3621  movaps xmm6, [rsp]
0000796caedd3625  add rsp, 0x30
0000796caedd3629  vmovaps xmm0, [rsp]
0000796caedd362e  vmovaps xmm1, [rsp+0x10]
0000796caedd3634  vmovaps xmm2, [rsp+0x20]
0000796caedd363a  vmovaps xmm3, [rsp+0x30]
0000796caedd3640  vmovaps xmm4, [rsp+0x40]
0000796caedd3646  vmovaps xmm5, [rsp+0x50]
0000796caedd364c  vmovaps xmm7, [rsp+0x60]
0000796caedd3652  vmovaps xmm8, [rsp+0x70]
0000796caedd3658  vmovaps xmm9, [rsp+0x80]
0000796caedd3661  vmovaps xmm10, [rsp+0x90]
0000796caedd366a  vmovaps xmm11, [rsp+0xA0]
0000796caedd3673  vmovaps xmm12, [rsp+0xB0]
0000796caedd367c  vmovaps xmm13, [rsp+0xC0]
0000796caedd3685  vmovaps xmm14, [rsp+0xD0]
0000796caedd368e  vmovaps xmm15, [rsp+0xE0]
0000796caedd3697  add rsp, 0xF0
0000796caedd369e  pop r11
0000796caedd36a0  pop r10
0000796caedd36a2  pop r9
0000796caedd36a4  pop r8
0000796caedd36a6  pop rsi
0000796caedd36a7  pop rdi
0000796caedd36a8  pop rdx
0000796caedd36a9  pop rcx
0000796caedd36aa  pop rax
0000796caedd36ab  add rsp, 0x08
0000796caedd36af  jmp 0x0000796CAEDCFF19
0000796caedd36b4  sub rsp, 0x08
0000796caedd36b8  push rax
0000796caedd36b9  push rcx
0000796caedd36ba  push rdx
0000796caedd36bb  push rdi
0000796caedd36bc  push rsi
0000796caedd36bd  push r8
0000796caedd36bf  push r9
0000796caedd36c1  push r10
0000796caedd36c3  push r11
0000796caedd36c5  sub rsp, 0xF0
0000796caedd36cc  vmovaps [rsp], xmm0
0000796caedd36d1  vmovaps [rsp+0x10], xmm1
0000796caedd36d7  vmovaps [rsp+0x20], xmm2
0000796caedd36dd  vmovaps [rsp+0x30], xmm3
0000796caedd36e3  vmovaps [rsp+0x40], xmm4
0000796caedd36e9  vmovaps [rsp+0x50], xmm5
0000796caedd36ef  vmovaps [rsp+0x60], xmm6
0000796caedd36f5  vmovaps [rsp+0x70], xmm7
0000796caedd36fb  vmovaps [rsp+0x80], xmm8
0000796caedd3704  vmovaps [rsp+0x90], xmm9
0000796caedd370d  vmovaps [rsp+0xA0], xmm10
0000796caedd3716  vmovaps [rsp+0xB0], xmm11
0000796caedd371f  vmovaps [rsp+0xC0], xmm13
0000796caedd3728  vmovaps [rsp+0xD0], xmm14
0000796caedd3731  vmovaps [rsp+0xE0], xmm15
0000796caedd373a  sub rsp, 0x30
0000796caedd373e  movaps [rsp], xmm12
0000796caedd3743  movaps [rsp+0x10], xmm15
0000796caedd3749  movaps [rsp+0x20], xmm13
0000796caedd374f  lea rdi, [rsp]
0000796caedd3753  mov esi, 0x00
0000796caedd3758  mov rax, 0x56877063A530
0000796caedd3762  call rax
0000796caedd3764  movaps xmm12, [rsp]
0000796caedd3769  add rsp, 0x30
0000796caedd376d  vmovaps xmm0, [rsp]
0000796caedd3772  vmovaps xmm1, [rsp+0x10]
0000796caedd3778  vmovaps xmm2, [rsp+0x20]
0000796caedd377e  vmovaps xmm3, [rsp+0x30]
0000796caedd3784  vmovaps xmm4, [rsp+0x40]
0000796caedd378a  vmovaps xmm5, [rsp+0x50]
0000796caedd3790  vmovaps xmm6, [rsp+0x60]
0000796caedd3796  vmovaps xmm7, [rsp+0x70]
0000796caedd379c  vmovaps xmm8, [rsp+0x80]
0000796caedd37a5  vmovaps xmm9, [rsp+0x90]
0000796caedd37ae  vmovaps xmm10, [rsp+0xA0]
0000796caedd37b7  vmovaps xmm11, [rsp+0xB0]
0000796caedd37c0  vmovaps xmm13, [rsp+0xC0]
0000796caedd37c9  vmovaps xmm14, [rsp+0xD0]
0000796caedd37d2  vmovaps xmm15, [rsp+0xE0]
0000796caedd37db  add rsp, 0xF0
0000796caedd37e2  pop r11
0000796caedd37e4  pop r10
0000796caedd37e6  pop r9
0000796caedd37e8  pop r8
0000796caedd37ea  pop rsi
0000796caedd37eb  pop rdi
0000796caedd37ec  pop rdx
0000796caedd37ed  pop rcx
0000796caedd37ee  pop rax
0000796caedd37ef  add rsp, 0x08
0000796caedd37f3  jmp 0x0000796CAEDCFF34
0000796caedd37f8  sub rsp, 0x08
0000796caedd37fc  push rax
0000796caedd37fd  push rcx
0000796caedd37fe  push rdx
0000796caedd37ff  push rdi
0000796caedd3800  push rsi
0000796caedd3801  push r8
0000796caedd3803  push r9
0000796caedd3805  push r10
0000796caedd3807  push r11
0000796caedd3809  sub rsp, 0xF0
0000796caedd3810  vmovaps [rsp], xmm0
0000796caedd3815  vmovaps [rsp+0x10], xmm1
0000796caedd381b  vmovaps [rsp+0x20], xmm2
0000796caedd3821  vmovaps [rsp+0x30], xmm3
0000796caedd3827  vmovaps [rsp+0x40], xmm4
0000796caedd382d  vmovaps [rsp+0x50], xmm5
0000796caedd3833  vmovaps [rsp+0x60], xmm6
0000796caedd3839  vmovaps [rsp+0x70], xmm7
0000796caedd383f  vmovaps [rsp+0x80], xmm8
0000796caedd3848  vmovaps [rsp+0x90], xmm9
0000796caedd3851  vmovaps [rsp+0xA0], xmm10
0000796caedd385a  vmovaps [rsp+0xB0], xmm11
0000796caedd3863  vmovaps [rsp+0xC0], xmm12
0000796caedd386c  vmovaps [rsp+0xD0], xmm13
0000796caedd3875  vmovaps [rsp+0xE0], xmm14
0000796caedd387e  sub rsp, 0x30
0000796caedd3882  movaps [rsp], xmm15
0000796caedd3887  movaps [rsp+0x10], xmm13
0000796caedd388d  movaps [rsp+0x20], xmm10
0000796caedd3893  lea rdi, [rsp]
0000796caedd3897  mov esi, 0x00
0000796caedd389c  mov rax, 0x56877063A530
0000796caedd38a6  call rax
0000796caedd38a8  movaps xmm15, [rsp]
0000796caedd38ad  add rsp, 0x30
0000796caedd38b1  vmovaps xmm0, [rsp]
0000796caedd38b6  vmovaps xmm1, [rsp+0x10]
0000796caedd38bc  vmovaps xmm2, [rsp+0x20]
0000796caedd38c2  vmovaps xmm3, [rsp+0x30]
0000796caedd38c8  vmovaps xmm4, [rsp+0x40]
0000796caedd38ce  vmovaps xmm5, [rsp+0x50]
0000796caedd38d4  vmovaps xmm6, [rsp+0x60]
0000796caedd38da  vmovaps xmm7, [rsp+0x70]
0000796caedd38e0  vmovaps xmm8, [rsp+0x80]
0000796caedd38e9  vmovaps xmm9, [rsp+0x90]
0000796caedd38f2  vmovaps xmm10, [rsp+0xA0]
0000796caedd38fb  vmovaps xmm11, [rsp+0xB0]
0000796caedd3904  vmovaps xmm12, [rsp+0xC0]
0000796caedd390d  vmovaps xmm13, [rsp+0xD0]
0000796caedd3916  vmovaps xmm14, [rsp+0xE0]
0000796caedd391f  add rsp, 0xF0
0000796caedd3926  pop r11
0000796caedd3928  pop r10
0000796caedd392a  pop r9
0000796caedd392c  pop r8
0000796caedd392e  pop rsi
0000796caedd392f  pop rdi
0000796caedd3930  pop rdx
0000796caedd3931  pop rcx
0000796caedd3932  pop rax
0000796caedd3933  add rsp, 0x08
0000796caedd3937  jmp 0x0000796CAEDCFF55
0000796caedd393c  call 0x0000796CAEC0C260
0000796caedd3941  jmp 0x0000796CAEDCFFB0
0000796caedd3946  sub rsp, 0x08
0000796caedd394a  push rax
0000796caedd394b  push rcx
0000796caedd394c  push rdx
0000796caedd394d  push rdi
0000796caedd394e  push rsi
0000796caedd394f  push r8
0000796caedd3951  push r9
0000796caedd3953  push r10
0000796caedd3955  push r11
0000796caedd3957  sub rsp, 0xF0
0000796caedd395e  vmovaps [rsp], xmm0
0000796caedd3963  vmovaps [rsp+0x10], xmm1
0000796caedd3969  vmovaps [rsp+0x20], xmm2
0000796caedd396f  vmovaps [rsp+0x30], xmm3
0000796caedd3975  vmovaps [rsp+0x40], xmm4
0000796caedd397b  vmovaps [rsp+0x50], xmm5
0000796caedd3981  vmovaps [rsp+0x60], xmm6
0000796caedd3987  vmovaps [rsp+0x70], xmm7
0000796caedd398d  vmovaps [rsp+0x80], xmm8
0000796caedd3996  vmovaps [rsp+0x90], xmm10
0000796caedd399f  vmovaps [rsp+0xA0], xmm11
0000796caedd39a8  vmovaps [rsp+0xB0], xmm12
0000796caedd39b1  vmovaps [rsp+0xC0], xmm13
0000796caedd39ba  vmovaps [rsp+0xD0], xmm14
0000796caedd39c3  vmovaps [rsp+0xE0], xmm15
0000796caedd39cc  sub rsp, 0x30
0000796caedd39d0  movaps [rsp], xmm9
0000796caedd39d5  movaps [rsp+0x10], xmm8
0000796caedd39db  movaps [rsp+0x20], xmm10
0000796caedd39e1  lea rdi, [rsp]
0000796caedd39e5  mov esi, 0x00
0000796caedd39ea  mov rax, 0x56877063A530
0000796caedd39f4  call rax
0000796caedd39f6  movaps xmm9, [rsp]
0000796caedd39fb  add rsp, 0x30
0000796caedd39ff  vmovaps xmm0, [rsp]
0000796caedd3a04  vmovaps xmm1, [rsp+0x10]
0000796caedd3a0a  vmovaps xmm2, [rsp+0x20]
0000796caedd3a10  vmovaps xmm3, [rsp+0x30]
0000796caedd3a16  vmovaps xmm4, [rsp+0x40]
0000796caedd3a1c  vmovaps xmm5, [rsp+0x50]
0000796caedd3a22  vmovaps xmm6, [rsp+0x60]
0000796caedd3a28  vmovaps xmm7, [rsp+0x70]
0000796caedd3a2e  vmovaps xmm8, [rsp+0x80]
0000796caedd3a37  vmovaps xmm10, [rsp+0x90]
0000796caedd3a40  vmovaps xmm11, [rsp+0xA0]
0000796caedd3a49  vmovaps xmm12, [rsp+0xB0]
0000796caedd3a52  vmovaps xmm13, [rsp+0xC0]
0000796caedd3a5b  vmovaps xmm14, [rsp+0xD0]
0000796caedd3a64  vmovaps xmm15, [rsp+0xE0]
0000796caedd3a6d  add rsp, 0xF0
0000796caedd3a74  pop r11
0000796caedd3a76  pop r10
0000796caedd3a78  pop r9
0000796caedd3a7a  pop r8
0000796caedd3a7c  pop rsi
0000796caedd3a7d  pop rdi
0000796caedd3a7e  pop rdx
0000796caedd3a7f  pop rcx
0000796caedd3a80  pop rax
0000796caedd3a81  add rsp, 0x08
0000796caedd3a85  jmp 0x0000796CAEDCFFE1
0000796caedd3a8a  sub rsp, 0x08
0000796caedd3a8e  push rax
0000796caedd3a8f  push rcx
0000796caedd3a90  push rdx
0000796caedd3a91  push rdi
0000796caedd3a92  push rsi
0000796caedd3a93  push r8
0000796caedd3a95  push r9
0000796caedd3a97  push r10
0000796caedd3a99  push r11
0000796caedd3a9b  sub rsp, 0xF0
0000796caedd3aa2  vmovaps [rsp], xmm0
0000796caedd3aa7  vmovaps [rsp+0x10], xmm1
0000796caedd3aad  vmovaps [rsp+0x20], xmm2
0000796caedd3ab3  vmovaps [rsp+0x30], xmm3
0000796caedd3ab9  vmovaps [rsp+0x40], xmm4
0000796caedd3abf  vmovaps [rsp+0x50], xmm5
0000796caedd3ac5  vmovaps [rsp+0x60], xmm6
0000796caedd3acb  vmovaps [rsp+0x70], xmm7
0000796caedd3ad1  vmovaps [rsp+0x80], xmm8
0000796caedd3ada  vmovaps [rsp+0x90], xmm9
0000796caedd3ae3  vmovaps [rsp+0xA0], xmm11
0000796caedd3aec  vmovaps [rsp+0xB0], xmm12
0000796caedd3af5  vmovaps [rsp+0xC0], xmm13
0000796caedd3afe  vmovaps [rsp+0xD0], xmm14
0000796caedd3b07  vmovaps [rsp+0xE0], xmm15
0000796caedd3b10  sub rsp, 0x30
0000796caedd3b14  movaps [rsp], xmm10
0000796caedd3b19  movaps [rsp+0x10], xmm1
0000796caedd3b1e  movaps [rsp+0x20], xmm11
0000796caedd3b24  lea rdi, [rsp]
0000796caedd3b28  mov esi, 0x00
0000796caedd3b2d  mov rax, 0x56877063A530
0000796caedd3b37  call rax
0000796caedd3b39  movaps xmm10, [rsp]
0000796caedd3b3e  add rsp, 0x30
0000796caedd3b42  vmovaps xmm0, [rsp]
0000796caedd3b47  vmovaps xmm1, [rsp+0x10]
0000796caedd3b4d  vmovaps xmm2, [rsp+0x20]
0000796caedd3b53  vmovaps xmm3, [rsp+0x30]
0000796caedd3b59  vmovaps xmm4, [rsp+0x40]
0000796caedd3b5f  vmovaps xmm5, [rsp+0x50]
0000796caedd3b65  vmovaps xmm6, [rsp+0x60]
0000796caedd3b6b  vmovaps xmm7, [rsp+0x70]
0000796caedd3b71  vmovaps xmm8, [rsp+0x80]
0000796caedd3b7a  vmovaps xmm9, [rsp+0x90]
0000796caedd3b83  vmovaps xmm11, [rsp+0xA0]
0000796caedd3b8c  vmovaps xmm12, [rsp+0xB0]
0000796caedd3b95  vmovaps xmm13, [rsp+0xC0]
0000796caedd3b9e  vmovaps xmm14, [rsp+0xD0]
0000796caedd3ba7  vmovaps xmm15, [rsp+0xE0]
0000796caedd3bb0  add rsp, 0xF0
0000796caedd3bb7  pop r11
0000796caedd3bb9  pop r10
0000796caedd3bbb  pop r9
0000796caedd3bbd  pop r8
0000796caedd3bbf  pop rsi
0000796caedd3bc0  pop rdi
0000796caedd3bc1  pop rdx
0000796caedd3bc2  pop rcx
0000796caedd3bc3  pop rax
0000796caedd3bc4  add rsp, 0x08
0000796caedd3bc8  jmp 0x0000796CAEDCFFFC
0000796caedd3bcd  sub rsp, 0x08
0000796caedd3bd1  push rax
0000796caedd3bd2  push rcx
0000796caedd3bd3  push rdx
0000796caedd3bd4  push rdi
0000796caedd3bd5  push rsi
0000796caedd3bd6  push r8
0000796caedd3bd8  push r9
0000796caedd3bda  push r10
0000796caedd3bdc  push r11
0000796caedd3bde  sub rsp, 0xF0
0000796caedd3be5  vmovaps [rsp], xmm0
0000796caedd3bea  vmovaps [rsp+0x10], xmm2
0000796caedd3bf0  vmovaps [rsp+0x20], xmm3
0000796caedd3bf6  vmovaps [rsp+0x30], xmm4
0000796caedd3bfc  vmovaps [rsp+0x40], xmm5
0000796caedd3c02  vmovaps [rsp+0x50], xmm6
0000796caedd3c08  vmovaps [rsp+0x60], xmm7
0000796caedd3c0e  vmovaps [rsp+0x70], xmm8
0000796caedd3c14  vmovaps [rsp+0x80], xmm9
0000796caedd3c1d  vmovaps [rsp+0x90], xmm10
0000796caedd3c26  vmovaps [rsp+0xA0], xmm11
0000796caedd3c2f  vmovaps [rsp+0xB0], xmm12
0000796caedd3c38  vmovaps [rsp+0xC0], xmm13
0000796caedd3c41  vmovaps [rsp+0xD0], xmm14
0000796caedd3c4a  vmovaps [rsp+0xE0], xmm15
0000796caedd3c53  sub rsp, 0x30
0000796caedd3c57  movaps [rsp], xmm1
0000796caedd3c5b  movaps [rsp+0x10], xmm14
0000796caedd3c61  movaps [rsp+0x20], xmm6
0000796caedd3c66  lea rdi, [rsp]
0000796caedd3c6a  mov esi, 0x00
0000796caedd3c6f  mov rax, 0x56877063A530
0000796caedd3c79  call rax
0000796caedd3c7b  movaps xmm1, [rsp]
0000796caedd3c7f  add rsp, 0x30
0000796caedd3c83  vmovaps xmm0, [rsp]
0000796caedd3c88  vmovaps xmm2, [rsp+0x10]
0000796caedd3c8e  vmovaps xmm3, [rsp+0x20]
0000796caedd3c94  vmovaps xmm4, [rsp+0x30]
0000796caedd3c9a  vmovaps xmm5, [rsp+0x40]
0000796caedd3ca0  vmovaps xmm6, [rsp+0x50]
0000796caedd3ca6  vmovaps xmm7, [rsp+0x60]
0000796caedd3cac  vmovaps xmm8, [rsp+0x70]
0000796caedd3cb2  vmovaps xmm9, [rsp+0x80]
0000796caedd3cbb  vmovaps xmm10, [rsp+0x90]
0000796caedd3cc4  vmovaps xmm11, [rsp+0xA0]
0000796caedd3ccd  vmovaps xmm12, [rsp+0xB0]
0000796caedd3cd6  vmovaps xmm13, [rsp+0xC0]
0000796caedd3cdf  vmovaps xmm14, [rsp+0xD0]
0000796caedd3ce8  vmovaps xmm15, [rsp+0xE0]
0000796caedd3cf1  add rsp, 0xF0
0000796caedd3cf8  pop r11
0000796caedd3cfa  pop r10
0000796caedd3cfc  pop r9
0000796caedd3cfe  pop r8
0000796caedd3d00  pop rsi
0000796caedd3d01  pop rdi
0000796caedd3d02  pop rdx
0000796caedd3d03  pop rcx
0000796caedd3d04  pop rax
0000796caedd3d05  add rsp, 0x08
0000796caedd3d09  jmp 0x0000796CAEDD0015
0000796caedd3d0e  sub rsp, 0x08
0000796caedd3d12  push rax
0000796caedd3d13  push rcx
0000796caedd3d14  push rdx
0000796caedd3d15  push rdi
0000796caedd3d16  push rsi
0000796caedd3d17  push r8
0000796caedd3d19  push r9
0000796caedd3d1b  push r10
0000796caedd3d1d  push r11
0000796caedd3d1f  sub rsp, 0xF0
0000796caedd3d26  vmovaps [rsp], xmm0
0000796caedd3d2b  vmovaps [rsp+0x10], xmm1
0000796caedd3d31  vmovaps [rsp+0x20], xmm2
0000796caedd3d37  vmovaps [rsp+0x30], xmm3
0000796caedd3d3d  vmovaps [rsp+0x40], xmm4
0000796caedd3d43  vmovaps [rsp+0x50], xmm5
0000796caedd3d49  vmovaps [rsp+0x60], xmm6
0000796caedd3d4f  vmovaps [rsp+0x70], xmm7
0000796caedd3d55  vmovaps [rsp+0x80], xmm8
0000796caedd3d5e  vmovaps [rsp+0x90], xmm9
0000796caedd3d67  vmovaps [rsp+0xA0], xmm10
0000796caedd3d70  vmovaps [rsp+0xB0], xmm12
0000796caedd3d79  vmovaps [rsp+0xC0], xmm13
0000796caedd3d82  vmovaps [rsp+0xD0], xmm14
0000796caedd3d8b  vmovaps [rsp+0xE0], xmm15
0000796caedd3d94  sub rsp, 0x30
0000796caedd3d98  movaps [rsp], xmm11
0000796caedd3d9d  movaps [rsp+0x10], xmm13
0000796caedd3da3  movaps [rsp+0x20], xmm14
0000796caedd3da9  lea rdi, [rsp]
0000796caedd3dad  mov esi, 0x00
0000796caedd3db2  mov rax, 0x56877063A530
0000796caedd3dbc  call rax
0000796caedd3dbe  movaps xmm11, [rsp]
0000796caedd3dc3  add rsp, 0x30
0000796caedd3dc7  vmovaps xmm0, [rsp]
0000796caedd3dcc  vmovaps xmm1, [rsp+0x10]
0000796caedd3dd2  vmovaps xmm2, [rsp+0x20]
0000796caedd3dd8  vmovaps xmm3, [rsp+0x30]
0000796caedd3dde  vmovaps xmm4, [rsp+0x40]
0000796caedd3de4  vmovaps xmm5, [rsp+0x50]
0000796caedd3dea  vmovaps xmm6, [rsp+0x60]
0000796caedd3df0  vmovaps xmm7, [rsp+0x70]
0000796caedd3df6  vmovaps xmm8, [rsp+0x80]
0000796caedd3dff  vmovaps xmm9, [rsp+0x90]
0000796caedd3e08  vmovaps xmm10, [rsp+0xA0]
0000796caedd3e11  vmovaps xmm12, [rsp+0xB0]
0000796caedd3e1a  vmovaps xmm13, [rsp+0xC0]
0000796caedd3e23  vmovaps xmm14, [rsp+0xD0]
0000796caedd3e2c  vmovaps xmm15, [rsp+0xE0]
0000796caedd3e35  add rsp, 0xF0
0000796caedd3e3c  pop r11
0000796caedd3e3e  pop r10
0000796caedd3e40  pop r9
0000796caedd3e42  pop r8
0000796caedd3e44  pop rsi
0000796caedd3e45  pop rdi
0000796caedd3e46  pop rdx
0000796caedd3e47  pop rcx
0000796caedd3e48  pop rax
0000796caedd3e49  add rsp, 0x08
0000796caedd3e4d  jmp 0x0000796CAEDD003F
0000796caedd3e52  sub rsp, 0x08
0000796caedd3e56  push rax
0000796caedd3e57  push rcx
0000796caedd3e58  push rdx
0000796caedd3e59  push rdi
0000796caedd3e5a  push rsi
0000796caedd3e5b  push r8
0000796caedd3e5d  push r9
0000796caedd3e5f  push r10
0000796caedd3e61  push r11
0000796caedd3e63  sub rsp, 0xF0
0000796caedd3e6a  vmovaps [rsp], xmm0
0000796caedd3e6f  vmovaps [rsp+0x10], xmm1
0000796caedd3e75  vmovaps [rsp+0x20], xmm2
0000796caedd3e7b  vmovaps [rsp+0x30], xmm3
0000796caedd3e81  vmovaps [rsp+0x40], xmm4
0000796caedd3e87  vmovaps [rsp+0x50], xmm5
0000796caedd3e8d  vmovaps [rsp+0x60], xmm6
0000796caedd3e93  vmovaps [rsp+0x70], xmm7
0000796caedd3e99  vmovaps [rsp+0x80], xmm8
0000796caedd3ea2  vmovaps [rsp+0x90], xmm9
0000796caedd3eab  vmovaps [rsp+0xA0], xmm10
0000796caedd3eb4  vmovaps [rsp+0xB0], xmm11
0000796caedd3ebd  vmovaps [rsp+0xC0], xmm12
0000796caedd3ec6  vmovaps [rsp+0xD0], xmm14
0000796caedd3ecf  vmovaps [rsp+0xE0], xmm15
0000796caedd3ed8  sub rsp, 0x30
0000796caedd3edc  movaps [rsp], xmm13
0000796caedd3ee1  movaps [rsp+0x10], xmm8
0000796caedd3ee7  movaps [rsp+0x20], xmm14
0000796caedd3eed  lea rdi, [rsp]
0000796caedd3ef1  mov esi, 0x00
0000796caedd3ef6  mov rax, 0x56877063A530
0000796caedd3f00  call rax
0000796caedd3f02  movaps xmm13, [rsp]
0000796caedd3f07  add rsp, 0x30
0000796caedd3f0b  vmovaps xmm0, [rsp]
0000796caedd3f10  vmovaps xmm1, [rsp+0x10]
0000796caedd3f16  vmovaps xmm2, [rsp+0x20]
0000796caedd3f1c  vmovaps xmm3, [rsp+0x30]
0000796caedd3f22  vmovaps xmm4, [rsp+0x40]
0000796caedd3f28  vmovaps xmm5, [rsp+0x50]
0000796caedd3f2e  vmovaps xmm6, [rsp+0x60]
0000796caedd3f34  vmovaps xmm7, [rsp+0x70]
0000796caedd3f3a  vmovaps xmm8, [rsp+0x80]
0000796caedd3f43  vmovaps xmm9, [rsp+0x90]
0000796caedd3f4c  vmovaps xmm10, [rsp+0xA0]
0000796caedd3f55  vmovaps xmm11, [rsp+0xB0]
0000796caedd3f5e  vmovaps xmm12, [rsp+0xC0]
0000796caedd3f67  vmovaps xmm14, [rsp+0xD0]
0000796caedd3f70  vmovaps xmm15, [rsp+0xE0]
0000796caedd3f79  add rsp, 0xF0
0000796caedd3f80  pop r11
0000796caedd3f82  pop r10
0000796caedd3f84  pop r9
0000796caedd3f86  pop r8
0000796caedd3f88  pop rsi
0000796caedd3f89  pop rdi
0000796caedd3f8a  pop rdx
0000796caedd3f8b  pop rcx
0000796caedd3f8c  pop rax
0000796caedd3f8d  add rsp, 0x08
0000796caedd3f91  jmp 0x0000796CAEDD006E
0000796caedd3f96  sub rsp, 0x08
0000796caedd3f9a  push rax
0000796caedd3f9b  push rcx
0000796caedd3f9c  push rdx
0000796caedd3f9d  push rdi
0000796caedd3f9e  push rsi
0000796caedd3f9f  push r8
0000796caedd3fa1  push r9
0000796caedd3fa3  push r10
0000796caedd3fa5  push r11
0000796caedd3fa7  sub rsp, 0xF0
0000796caedd3fae  vmovaps [rsp], xmm0
0000796caedd3fb3  vmovaps [rsp+0x10], xmm1
0000796caedd3fb9  vmovaps [rsp+0x20], xmm2
0000796caedd3fbf  vmovaps [rsp+0x30], xmm3
0000796caedd3fc5  vmovaps [rsp+0x40], xmm4
0000796caedd3fcb  vmovaps [rsp+0x50], xmm5
0000796caedd3fd1  vmovaps [rsp+0x60], xmm6
0000796caedd3fd7  vmovaps [rsp+0x70], xmm7
0000796caedd3fdd  vmovaps [rsp+0x80], xmm9
0000796caedd3fe6  vmovaps [rsp+0x90], xmm10
0000796caedd3fef  vmovaps [rsp+0xA0], xmm11
0000796caedd3ff8  vmovaps [rsp+0xB0], xmm12
0000796caedd4001  vmovaps [rsp+0xC0], xmm13
0000796caedd400a  vmovaps [rsp+0xD0], xmm14
0000796caedd4013  vmovaps [rsp+0xE0], xmm15
0000796caedd401c  sub rsp, 0x30
0000796caedd4020  movaps [rsp], xmm8
0000796caedd4025  movaps [rsp+0x10], xmm7
0000796caedd402a  movaps [rsp+0x20], xmm14
0000796caedd4030  lea rdi, [rsp]
0000796caedd4034  mov esi, 0x00
0000796caedd4039  mov rax, 0x56877063A530
0000796caedd4043  call rax
0000796caedd4045  movaps xmm8, [rsp]
0000796caedd404a  add rsp, 0x30
0000796caedd404e  vmovaps xmm0, [rsp]
0000796caedd4053  vmovaps xmm1, [rsp+0x10]
0000796caedd4059  vmovaps xmm2, [rsp+0x20]
0000796caedd405f  vmovaps xmm3, [rsp+0x30]
0000796caedd4065  vmovaps xmm4, [rsp+0x40]
0000796caedd406b  vmovaps xmm5, [rsp+0x50]
0000796caedd4071  vmovaps xmm6, [rsp+0x60]
0000796caedd4077  vmovaps xmm7, [rsp+0x70]
0000796caedd407d  vmovaps xmm9, [rsp+0x80]
0000796caedd4086  vmovaps xmm10, [rsp+0x90]
0000796caedd408f  vmovaps xmm11, [rsp+0xA0]
0000796caedd4098  vmovaps xmm12, [rsp+0xB0]
0000796caedd40a1  vmovaps xmm13, [rsp+0xC0]
0000796caedd40aa  vmovaps xmm14, [rsp+0xD0]
0000796caedd40b3  vmovaps xmm15, [rsp+0xE0]
0000796caedd40bc  add rsp, 0xF0
0000796caedd40c3  pop r11
0000796caedd40c5  pop r10
0000796caedd40c7  pop r9
0000796caedd40c9  pop r8
0000796caedd40cb  pop rsi
0000796caedd40cc  pop rdi
0000796caedd40cd  pop rdx
0000796caedd40ce  pop rcx
0000796caedd40cf  pop rax
0000796caedd40d0  add rsp, 0x08
0000796caedd40d4  jmp 0x0000796CAEDD0094
0000796caedd40d9  sub rsp, 0x08
0000796caedd40dd  push rax
0000796caedd40de  push rcx
0000796caedd40df  push rdx
0000796caedd40e0  push rdi
0000796caedd40e1  push rsi
0000796caedd40e2  push r8
0000796caedd40e4  push r9
0000796caedd40e6  push r10
0000796caedd40e8  push r11
0000796caedd40ea  sub rsp, 0xF0
0000796caedd40f1  vmovaps [rsp], xmm0
0000796caedd40f6  vmovaps [rsp+0x10], xmm1
0000796caedd40fc  vmovaps [rsp+0x20], xmm2
0000796caedd4102  vmovaps [rsp+0x30], xmm3
0000796caedd4108  vmovaps [rsp+0x40], xmm4
0000796caedd410e  vmovaps [rsp+0x50], xmm5
0000796caedd4114  vmovaps [rsp+0x60], xmm6
0000796caedd411a  vmovaps [rsp+0x70], xmm7
0000796caedd4120  vmovaps [rsp+0x80], xmm8
0000796caedd4129  vmovaps [rsp+0x90], xmm9
0000796caedd4132  vmovaps [rsp+0xA0], xmm10
0000796caedd413b  vmovaps [rsp+0xB0], xmm11
0000796caedd4144  vmovaps [rsp+0xC0], xmm12
0000796caedd414d  vmovaps [rsp+0xD0], xmm13
0000796caedd4156  vmovaps [rsp+0xE0], xmm15
0000796caedd415f  sub rsp, 0x30
0000796caedd4163  movaps [rsp], xmm14
0000796caedd4168  movaps [rsp+0x10], xmm12
0000796caedd416e  movaps [rsp+0x20], xmm9
0000796caedd4174  lea rdi, [rsp]
0000796caedd4178  mov esi, 0x00
0000796caedd417d  mov rax, 0x56877063A530
0000796caedd4187  call rax
0000796caedd4189  movaps xmm14, [rsp]
0000796caedd418e  add rsp, 0x30
0000796caedd4192  vmovaps xmm0, [rsp]
0000796caedd4197  vmovaps xmm1, [rsp+0x10]
0000796caedd419d  vmovaps xmm2, [rsp+0x20]
0000796caedd41a3  vmovaps xmm3, [rsp+0x30]
0000796caedd41a9  vmovaps xmm4, [rsp+0x40]
0000796caedd41af  vmovaps xmm5, [rsp+0x50]
0000796caedd41b5  vmovaps xmm6, [rsp+0x60]
0000796caedd41bb  vmovaps xmm7, [rsp+0x70]
0000796caedd41c1  vmovaps xmm8, [rsp+0x80]
0000796caedd41ca  vmovaps xmm9, [rsp+0x90]
0000796caedd41d3  vmovaps xmm10, [rsp+0xA0]
0000796caedd41dc  vmovaps xmm11, [rsp+0xB0]
0000796caedd41e5  vmovaps xmm12, [rsp+0xC0]
0000796caedd41ee  vmovaps xmm13, [rsp+0xD0]
0000796caedd41f7  vmovaps xmm15, [rsp+0xE0]
0000796caedd4200  add rsp, 0xF0
0000796caedd4207  pop r11
0000796caedd4209  pop r10
0000796caedd420b  pop r9
0000796caedd420d  pop r8
0000796caedd420f  pop rsi
0000796caedd4210  pop rdi
0000796caedd4211  pop rdx
0000796caedd4212  pop rcx
0000796caedd4213  pop rax
0000796caedd4214  add rsp, 0x08
0000796caedd4218  jmp 0x0000796CAEDD00AE
0000796caedd421d  sub rsp, 0x08
0000796caedd4221  push rax
0000796caedd4222  push rcx
0000796caedd4223  push rdx
0000796caedd4224  push rdi
0000796caedd4225  push rsi
0000796caedd4226  push r8
0000796caedd4228  push r9
0000796caedd422a  push r10
0000796caedd422c  push r11
0000796caedd422e  sub rsp, 0xF0
0000796caedd4235  vmovaps [rsp], xmm0
0000796caedd423a  vmovaps [rsp+0x10], xmm1
0000796caedd4240  vmovaps [rsp+0x20], xmm2
0000796caedd4246  vmovaps [rsp+0x30], xmm3
0000796caedd424c  vmovaps [rsp+0x40], xmm4
0000796caedd4252  vmovaps [rsp+0x50], xmm5
0000796caedd4258  vmovaps [rsp+0x60], xmm6
0000796caedd425e  vmovaps [rsp+0x70], xmm7
0000796caedd4264  vmovaps [rsp+0x80], xmm8
0000796caedd426d  vmovaps [rsp+0x90], xmm10
0000796caedd4276  vmovaps [rsp+0xA0], xmm11
0000796caedd427f  vmovaps [rsp+0xB0], xmm12
0000796caedd4288  vmovaps [rsp+0xC0], xmm13
0000796caedd4291  vmovaps [rsp+0xD0], xmm14
0000796caedd429a  vmovaps [rsp+0xE0], xmm15
0000796caedd42a3  sub rsp, 0x30
0000796caedd42a7  movaps [rsp], xmm9
0000796caedd42ac  movaps [rsp+0x10], xmm7
0000796caedd42b1  movaps [rsp+0x20], xmm12
0000796caedd42b7  lea rdi, [rsp]
0000796caedd42bb  mov esi, 0x00
0000796caedd42c0  mov rax, 0x56877063A530
0000796caedd42ca  call rax
0000796caedd42cc  movaps xmm9, [rsp]
0000796caedd42d1  add rsp, 0x30
0000796caedd42d5  vmovaps xmm0, [rsp]
0000796caedd42da  vmovaps xmm1, [rsp+0x10]
0000796caedd42e0  vmovaps xmm2, [rsp+0x20]
0000796caedd42e6  vmovaps xmm3, [rsp+0x30]
0000796caedd42ec  vmovaps xmm4, [rsp+0x40]
0000796caedd42f2  vmovaps xmm5, [rsp+0x50]
0000796caedd42f8  vmovaps xmm6, [rsp+0x60]
0000796caedd42fe  vmovaps xmm7, [rsp+0x70]
0000796caedd4304  vmovaps xmm8, [rsp+0x80]
0000796caedd430d  vmovaps xmm10, [rsp+0x90]
0000796caedd4316  vmovaps xmm11, [rsp+0xA0]
0000796caedd431f  vmovaps xmm12, [rsp+0xB0]
0000796caedd4328  vmovaps xmm13, [rsp+0xC0]
0000796caedd4331  vmovaps xmm14, [rsp+0xD0]
0000796caedd433a  vmovaps xmm15, [rsp+0xE0]
0000796caedd4343  add rsp, 0xF0
0000796caedd434a  pop r11
0000796caedd434c  pop r10
0000796caedd434e  pop r9
0000796caedd4350  pop r8
0000796caedd4352  pop rsi
0000796caedd4353  pop rdi
0000796caedd4354  pop rdx
0000796caedd4355  pop rcx
0000796caedd4356  pop rax
0000796caedd4357  add rsp, 0x08
0000796caedd435b  jmp 0x0000796CAEDD00DD
0000796caedd4360  sub rsp, 0x08
0000796caedd4364  push rax
0000796caedd4365  push rcx
0000796caedd4366  push rdx
0000796caedd4367  push rdi
0000796caedd4368  push rsi
0000796caedd4369  push r8
0000796caedd436b  push r9
0000796caedd436d  push r10
0000796caedd436f  push r11
0000796caedd4371  sub rsp, 0xF0
0000796caedd4378  vmovaps [rsp], xmm0
0000796caedd437d  vmovaps [rsp+0x10], xmm1
0000796caedd4383  vmovaps [rsp+0x20], xmm2
0000796caedd4389  vmovaps [rsp+0x30], xmm3
0000796caedd438f  vmovaps [rsp+0x40], xmm4
0000796caedd4395  vmovaps [rsp+0x50], xmm5
0000796caedd439b  vmovaps [rsp+0x60], xmm6
0000796caedd43a1  vmovaps [rsp+0x70], xmm7
0000796caedd43a7  vmovaps [rsp+0x80], xmm8
0000796caedd43b0  vmovaps [rsp+0x90], xmm9
0000796caedd43b9  vmovaps [rsp+0xA0], xmm10
0000796caedd43c2  vmovaps [rsp+0xB0], xmm11
0000796caedd43cb  vmovaps [rsp+0xC0], xmm13
0000796caedd43d4  vmovaps [rsp+0xD0], xmm14
0000796caedd43dd  vmovaps [rsp+0xE0], xmm15
0000796caedd43e6  sub rsp, 0x30
0000796caedd43ea  movaps [rsp], xmm12
0000796caedd43ef  movaps [rsp+0x10], xmm15
0000796caedd43f5  movaps [rsp+0x20], xmm11
0000796caedd43fb  lea rdi, [rsp]
0000796caedd43ff  mov esi, 0x00
0000796caedd4404  mov rax, 0x56877063A530
0000796caedd440e  call rax
0000796caedd4410  movaps xmm12, [rsp]
0000796caedd4415  add rsp, 0x30
0000796caedd4419  vmovaps xmm0, [rsp]
0000796caedd441e  vmovaps xmm1, [rsp+0x10]
0000796caedd4424  vmovaps xmm2, [rsp+0x20]
0000796caedd442a  vmovaps xmm3, [rsp+0x30]
0000796caedd4430  vmovaps xmm4, [rsp+0x40]
0000796caedd4436  vmovaps xmm5, [rsp+0x50]
0000796caedd443c  vmovaps xmm6, [rsp+0x60]
0000796caedd4442  vmovaps xmm7, [rsp+0x70]
0000796caedd4448  vmovaps xmm8, [rsp+0x80]
0000796caedd4451  vmovaps xmm9, [rsp+0x90]
0000796caedd445a  vmovaps xmm10, [rsp+0xA0]
0000796caedd4463  vmovaps xmm11, [rsp+0xB0]
0000796caedd446c  vmovaps xmm13, [rsp+0xC0]
0000796caedd4475  vmovaps xmm14, [rsp+0xD0]
0000796caedd447e  vmovaps xmm15, [rsp+0xE0]
0000796caedd4487  add rsp, 0xF0
0000796caedd448e  pop r11
0000796caedd4490  pop r10
0000796caedd4492  pop r9
0000796caedd4494  pop r8
0000796caedd4496  pop rsi
0000796caedd4497  pop rdi
0000796caedd4498  pop rdx
0000796caedd4499  pop rcx
0000796caedd449a  pop rax
0000796caedd449b  add rsp, 0x08
0000796caedd449f  jmp 0x0000796CAEDD00F7
0000796caedd44a4  sub rsp, 0x08
0000796caedd44a8  push rax
0000796caedd44a9  push rcx
0000796caedd44aa  push rdx
0000796caedd44ab  push rdi
0000796caedd44ac  push rsi
0000796caedd44ad  push r8
0000796caedd44af  push r9
0000796caedd44b1  push r10
0000796caedd44b3  push r11
0000796caedd44b5  sub rsp, 0xF0
0000796caedd44bc  vmovaps [rsp], xmm0
0000796caedd44c1  vmovaps [rsp+0x10], xmm1
0000796caedd44c7  vmovaps [rsp+0x20], xmm2
0000796caedd44cd  vmovaps [rsp+0x30], xmm3
0000796caedd44d3  vmovaps [rsp+0x40], xmm4
0000796caedd44d9  vmovaps [rsp+0x50], xmm5
0000796caedd44df  vmovaps [rsp+0x60], xmm6
0000796caedd44e5  vmovaps [rsp+0x70], xmm7
0000796caedd44eb  vmovaps [rsp+0x80], xmm8
0000796caedd44f4  vmovaps [rsp+0x90], xmm9
0000796caedd44fd  vmovaps [rsp+0xA0], xmm10
0000796caedd4506  vmovaps [rsp+0xB0], xmm12
0000796caedd450f  vmovaps [rsp+0xC0], xmm13
0000796caedd4518  vmovaps [rsp+0xD0], xmm14
0000796caedd4521  vmovaps [rsp+0xE0], xmm15
0000796caedd452a  sub rsp, 0x30
0000796caedd452e  movaps [rsp], xmm11
0000796caedd4533  movaps [rsp+0x10], xmm7
0000796caedd4538  movaps [rsp+0x20], xmm15
0000796caedd453e  lea rdi, [rsp]
0000796caedd4542  mov esi, 0x00
0000796caedd4547  mov rax, 0x56877063A530
0000796caedd4551  call rax
0000796caedd4553  movaps xmm11, [rsp]
0000796caedd4558  add rsp, 0x30
0000796caedd455c  vmovaps xmm0, [rsp]
0000796caedd4561  vmovaps xmm1, [rsp+0x10]
0000796caedd4567  vmovaps xmm2, [rsp+0x20]
0000796caedd456d  vmovaps xmm3, [rsp+0x30]
0000796caedd4573  vmovaps xmm4, [rsp+0x40]
0000796caedd4579  vmovaps xmm5, [rsp+0x50]
0000796caedd457f  vmovaps xmm6, [rsp+0x60]
0000796caedd4585  vmovaps xmm7, [rsp+0x70]
0000796caedd458b  vmovaps xmm8, [rsp+0x80]
0000796caedd4594  vmovaps xmm9, [rsp+0x90]
0000796caedd459d  vmovaps xmm10, [rsp+0xA0]
0000796caedd45a6  vmovaps xmm12, [rsp+0xB0]
0000796caedd45af  vmovaps xmm13, [rsp+0xC0]
0000796caedd45b8  vmovaps xmm14, [rsp+0xD0]
0000796caedd45c1  vmovaps xmm15, [rsp+0xE0]
0000796caedd45ca  add rsp, 0xF0
0000796caedd45d1  pop r11
0000796caedd45d3  pop r10
0000796caedd45d5  pop r9
0000796caedd45d7  pop r8
0000796caedd45d9  pop rsi
0000796caedd45da  pop rdi
0000796caedd45db  pop rdx
0000796caedd45dc  pop rcx
0000796caedd45dd  pop rax
0000796caedd45de  add rsp, 0x08
0000796caedd45e2  jmp 0x0000796CAEDD0123
0000796caedd45e7  sub rsp, 0x08
0000796caedd45eb  push rax
0000796caedd45ec  push rcx
0000796caedd45ed  push rdx
0000796caedd45ee  push rdi
0000796caedd45ef  push rsi
0000796caedd45f0  push r8
0000796caedd45f2  push r9
0000796caedd45f4  push r10
0000796caedd45f6  push r11
0000796caedd45f8  sub rsp, 0xF0
0000796caedd45ff  vmovaps [rsp], xmm0
0000796caedd4604  vmovaps [rsp+0x10], xmm1
0000796caedd460a  vmovaps [rsp+0x20], xmm2
0000796caedd4610  vmovaps [rsp+0x30], xmm3
0000796caedd4616  vmovaps [rsp+0x40], xmm4
0000796caedd461c  vmovaps [rsp+0x50], xmm5
0000796caedd4622  vmovaps [rsp+0x60], xmm6
0000796caedd4628  vmovaps [rsp+0x70], xmm7
0000796caedd462e  vmovaps [rsp+0x80], xmm8
0000796caedd4637  vmovaps [rsp+0x90], xmm9
0000796caedd4640  vmovaps [rsp+0xA0], xmm10
0000796caedd4649  vmovaps [rsp+0xB0], xmm11
0000796caedd4652  vmovaps [rsp+0xC0], xmm12
0000796caedd465b  vmovaps [rsp+0xD0], xmm13
0000796caedd4664  vmovaps [rsp+0xE0], xmm14
0000796caedd466d  sub rsp, 0x30
0000796caedd4671  movaps [rsp], xmm15
0000796caedd4676  movaps [rsp+0x10], xmm10
0000796caedd467c  movaps [rsp+0x20], xmm13
0000796caedd4682  lea rdi, [rsp]
0000796caedd4686  mov esi, 0x00
0000796caedd468b  mov rax, 0x56877063A530
0000796caedd4695  call rax
0000796caedd4697  movaps xmm15, [rsp]
0000796caedd469c  add rsp, 0x30
0000796caedd46a0  vmovaps xmm0, [rsp]
0000796caedd46a5  vmovaps xmm1, [rsp+0x10]
0000796caedd46ab  vmovaps xmm2, [rsp+0x20]
0000796caedd46b1  vmovaps xmm3, [rsp+0x30]
0000796caedd46b7  vmovaps xmm4, [rsp+0x40]
0000796caedd46bd  vmovaps xmm5, [rsp+0x50]
0000796caedd46c3  vmovaps xmm6, [rsp+0x60]
0000796caedd46c9  vmovaps xmm7, [rsp+0x70]
0000796caedd46cf  vmovaps xmm8, [rsp+0x80]
0000796caedd46d8  vmovaps xmm9, [rsp+0x90]
0000796caedd46e1  vmovaps xmm10, [rsp+0xA0]
0000796caedd46ea  vmovaps xmm11, [rsp+0xB0]
0000796caedd46f3  vmovaps xmm12, [rsp+0xC0]
0000796caedd46fc  vmovaps xmm13, [rsp+0xD0]
0000796caedd4705  vmovaps xmm14, [rsp+0xE0]
0000796caedd470e  add rsp, 0xF0
0000796caedd4715  pop r11
0000796caedd4717  pop r10
0000796caedd4719  pop r9
0000796caedd471b  pop r8
0000796caedd471d  pop rsi
0000796caedd471e  pop rdi
0000796caedd471f  pop rdx
0000796caedd4720  pop rcx
0000796caedd4721  pop rax
0000796caedd4722  add rsp, 0x08
0000796caedd4726  jmp 0x0000796CAEDD013D
0000796caedd472b  sub rsp, 0x08
0000796caedd472f  push rax
0000796caedd4730  push rcx
0000796caedd4731  push rdx
0000796caedd4732  push rdi
0000796caedd4733  push rsi
0000796caedd4734  push r8
0000796caedd4736  push r9
0000796caedd4738  push r10
0000796caedd473a  push r11
0000796caedd473c  sub rsp, 0xF0
0000796caedd4743  vmovaps [rsp], xmm0
0000796caedd4748  vmovaps [rsp+0x10], xmm1
0000796caedd474e  vmovaps [rsp+0x20], xmm2
0000796caedd4754  vmovaps [rsp+0x30], xmm3
0000796caedd475a  vmovaps [rsp+0x40], xmm4
0000796caedd4760  vmovaps [rsp+0x50], xmm5
0000796caedd4766  vmovaps [rsp+0x60], xmm6
0000796caedd476c  vmovaps [rsp+0x70], xmm7
0000796caedd4772  vmovaps [rsp+0x80], xmm8
0000796caedd477b  vmovaps [rsp+0x90], xmm9
0000796caedd4784  vmovaps [rsp+0xA0], xmm11
0000796caedd478d  vmovaps [rsp+0xB0], xmm12
0000796caedd4796  vmovaps [rsp+0xC0], xmm13
0000796caedd479f  vmovaps [rsp+0xD0], xmm14
0000796caedd47a8  vmovaps [rsp+0xE0], xmm15
0000796caedd47b1  sub rsp, 0x30
0000796caedd47b5  movaps [rsp], xmm10
0000796caedd47ba  movaps [rsp+0x10], xmm7
0000796caedd47bf  movaps [rsp+0x20], xmm13
0000796caedd47c5  lea rdi, [rsp]
0000796caedd47c9  mov esi, 0x00
0000796caedd47ce  mov rax, 0x56877063A530
0000796caedd47d8  call rax
0000796caedd47da  movaps xmm10, [rsp]
0000796caedd47df  add rsp, 0x30
0000796caedd47e3  vmovaps xmm0, [rsp]
0000796caedd47e8  vmovaps xmm1, [rsp+0x10]
0000796caedd47ee  vmovaps xmm2, [rsp+0x20]
0000796caedd47f4  vmovaps xmm3, [rsp+0x30]
0000796caedd47fa  vmovaps xmm4, [rsp+0x40]
0000796caedd4800  vmovaps xmm5, [rsp+0x50]
0000796caedd4806  vmovaps xmm6, [rsp+0x60]
0000796caedd480c  vmovaps xmm7, [rsp+0x70]
0000796caedd4812  vmovaps xmm8, [rsp+0x80]
0000796caedd481b  vmovaps xmm9, [rsp+0x90]
0000796caedd4824  vmovaps xmm11, [rsp+0xA0]
0000796caedd482d  vmovaps xmm12, [rsp+0xB0]
0000796caedd4836  vmovaps xmm13, [rsp+0xC0]
0000796caedd483f  vmovaps xmm14, [rsp+0xD0]
0000796caedd4848  vmovaps xmm15, [rsp+0xE0]
0000796caedd4851  add rsp, 0xF0
0000796caedd4858  pop r11
0000796caedd485a  pop r10
0000796caedd485c  pop r9
0000796caedd485e  pop r8
0000796caedd4860  pop rsi
0000796caedd4861  pop rdi
0000796caedd4862  pop rdx
0000796caedd4863  pop rcx
0000796caedd4864  pop rax
0000796caedd4865  add rsp, 0x08
0000796caedd4869  jmp 0x0000796CAEDD0169
0000796caedd486e  sub rsp, 0x08
0000796caedd4872  push rax
0000796caedd4873  push rcx
0000796caedd4874  push rdx
0000796caedd4875  push rdi
0000796caedd4876  push rsi
0000796caedd4877  push r8
0000796caedd4879  push r9
0000796caedd487b  push r10
0000796caedd487d  push r11
0000796caedd487f  sub rsp, 0xF0
0000796caedd4886  vmovaps [rsp], xmm0
0000796caedd488b  vmovaps [rsp+0x10], xmm1
0000796caedd4891  vmovaps [rsp+0x20], xmm2
0000796caedd4897  vmovaps [rsp+0x30], xmm3
0000796caedd489d  vmovaps [rsp+0x40], xmm4
0000796caedd48a3  vmovaps [rsp+0x50], xmm5
0000796caedd48a9  vmovaps [rsp+0x60], xmm6
0000796caedd48af  vmovaps [rsp+0x70], xmm7
0000796caedd48b5  vmovaps [rsp+0x80], xmm8
0000796caedd48be  vmovaps [rsp+0x90], xmm9
0000796caedd48c7  vmovaps [rsp+0xA0], xmm10
0000796caedd48d0  vmovaps [rsp+0xB0], xmm11
0000796caedd48d9  vmovaps [rsp+0xC0], xmm12
0000796caedd48e2  vmovaps [rsp+0xD0], xmm14
0000796caedd48eb  vmovaps [rsp+0xE0], xmm15
0000796caedd48f4  sub rsp, 0x30
0000796caedd48f8  movaps [rsp], xmm13
0000796caedd48fd  movaps [rsp+0x10], xmm1
0000796caedd4902  movaps [rsp+0x20], xmm8
0000796caedd4908  lea rdi, [rsp]
0000796caedd490c  mov esi, 0x00
0000796caedd4911  mov rax, 0x56877063A530
0000796caedd491b  call rax
0000796caedd491d  movaps xmm13, [rsp]
0000796caedd4922  add rsp, 0x30
0000796caedd4926  vmovaps xmm0, [rsp]
0000796caedd492b  vmovaps xmm1, [rsp+0x10]
0000796caedd4931  vmovaps xmm2, [rsp+0x20]
0000796caedd4937  vmovaps xmm3, [rsp+0x30]
0000796caedd493d  vmovaps xmm4, [rsp+0x40]
0000796caedd4943  vmovaps xmm5, [rsp+0x50]
0000796caedd4949  vmovaps xmm6, [rsp+0x60]
0000796caedd494f  vmovaps xmm7, [rsp+0x70]
0000796caedd4955  vmovaps xmm8, [rsp+0x80]
0000796caedd495e  vmovaps xmm9, [rsp+0x90]
0000796caedd4967  vmovaps xmm10, [rsp+0xA0]
0000796caedd4970  vmovaps xmm11, [rsp+0xB0]
0000796caedd4979  vmovaps xmm12, [rsp+0xC0]
0000796caedd4982  vmovaps xmm14, [rsp+0xD0]
0000796caedd498b  vmovaps xmm15, [rsp+0xE0]
0000796caedd4994  add rsp, 0xF0
0000796caedd499b  pop r11
0000796caedd499d  pop r10
0000796caedd499f  pop r9
0000796caedd49a1  pop r8
0000796caedd49a3  pop rsi
0000796caedd49a4  pop rdi
0000796caedd49a5  pop rdx
0000796caedd49a6  pop rcx
0000796caedd49a7  pop rax
0000796caedd49a8  add rsp, 0x08
0000796caedd49ac  jmp 0x0000796CAEDD0183
0000796caedd49b1  call 0x0000796CAEBFF430
0000796caedd49b6  jmp 0x0000796CAEDD018D
0000796caedd49bb  sub rsp, 0x08
0000796caedd49bf  push rax
0000796caedd49c0  push rcx
0000796caedd49c1  push rdx
0000796caedd49c2  push rdi
0000796caedd49c3  push rsi
0000796caedd49c4  push r8
0000796caedd49c6  push r9
0000796caedd49c8  push r10
0000796caedd49ca  push r11
0000796caedd49cc  sub rsp, 0xF0
0000796caedd49d3  vmovaps [rsp], xmm0
0000796caedd49d8  vmovaps [rsp+0x10], xmm1
0000796caedd49de  vmovaps [rsp+0x20], xmm2
0000796caedd49e4  vmovaps [rsp+0x30], xmm3
0000796caedd49ea  vmovaps [rsp+0x40], xmm4
0000796caedd49f0  vmovaps [rsp+0x50], xmm5
0000796caedd49f6  vmovaps [rsp+0x60], xmm6
0000796caedd49fc  vmovaps [rsp+0x70], xmm7
0000796caedd4a02  vmovaps [rsp+0x80], xmm9
0000796caedd4a0b  vmovaps [rsp+0x90], xmm10
0000796caedd4a14  vmovaps [rsp+0xA0], xmm11
0000796caedd4a1d  vmovaps [rsp+0xB0], xmm12
0000796caedd4a26  vmovaps [rsp+0xC0], xmm13
0000796caedd4a2f  vmovaps [rsp+0xD0], xmm14
0000796caedd4a38  vmovaps [rsp+0xE0], xmm15
0000796caedd4a41  sub rsp, 0x30
0000796caedd4a45  movaps [rsp], xmm8
0000796caedd4a4a  movaps [rsp+0x10], xmm14
0000796caedd4a50  movaps [rsp+0x20], xmm9
0000796caedd4a56  lea rdi, [rsp]
0000796caedd4a5a  mov esi, 0x00
0000796caedd4a5f  mov rax, 0x56877063A530
0000796caedd4a69  call rax
0000796caedd4a6b  movaps xmm8, [rsp]
0000796caedd4a70  add rsp, 0x30
0000796caedd4a74  vmovaps xmm0, [rsp]
0000796caedd4a79  vmovaps xmm1, [rsp+0x10]
0000796caedd4a7f  vmovaps xmm2, [rsp+0x20]
0000796caedd4a85  vmovaps xmm3, [rsp+0x30]
0000796caedd4a8b  vmovaps xmm4, [rsp+0x40]
0000796caedd4a91  vmovaps xmm5, [rsp+0x50]
0000796caedd4a97  vmovaps xmm6, [rsp+0x60]
0000796caedd4a9d  vmovaps xmm7, [rsp+0x70]
0000796caedd4aa3  vmovaps xmm9, [rsp+0x80]
0000796caedd4aac  vmovaps xmm10, [rsp+0x90]
0000796caedd4ab5  vmovaps xmm11, [rsp+0xA0]
0000796caedd4abe  vmovaps xmm12, [rsp+0xB0]
0000796caedd4ac7  vmovaps xmm13, [rsp+0xC0]
0000796caedd4ad0  vmovaps xmm14, [rsp+0xD0]
0000796caedd4ad9  vmovaps xmm15, [rsp+0xE0]
0000796caedd4ae2  add rsp, 0xF0
0000796caedd4ae9  pop r11
0000796caedd4aeb  pop r10
0000796caedd4aed  pop r9
0000796caedd4aef  pop r8
0000796caedd4af1  pop rsi
0000796caedd4af2  pop rdi
0000796caedd4af3  pop rdx
0000796caedd4af4  pop rcx
0000796caedd4af5  pop rax
0000796caedd4af6  add rsp, 0x08
0000796caedd4afa  jmp 0x0000796CAEDD01AF
0000796caedd4aff  sub rsp, 0x08
0000796caedd4b03  push rax
0000796caedd4b04  push rcx
0000796caedd4b05  push rdx
0000796caedd4b06  push rdi
0000796caedd4b07  push rsi
0000796caedd4b08  push r8
0000796caedd4b0a  push r9
0000796caedd4b0c  push r10
0000796caedd4b0e  push r11
0000796caedd4b10  sub rsp, 0xF0
0000796caedd4b17  vmovaps [rsp], xmm0
0000796caedd4b1c  vmovaps [rsp+0x10], xmm1
0000796caedd4b22  vmovaps [rsp+0x20], xmm2
0000796caedd4b28  vmovaps [rsp+0x30], xmm3
0000796caedd4b2e  vmovaps [rsp+0x40], xmm4
0000796caedd4b34  vmovaps [rsp+0x50], xmm5
0000796caedd4b3a  vmovaps [rsp+0x60], xmm6
0000796caedd4b40  vmovaps [rsp+0x70], xmm7
0000796caedd4b46  vmovaps [rsp+0x80], xmm8
0000796caedd4b4f  vmovaps [rsp+0x90], xmm10
0000796caedd4b58  vmovaps [rsp+0xA0], xmm11
0000796caedd4b61  vmovaps [rsp+0xB0], xmm12
0000796caedd4b6a  vmovaps [rsp+0xC0], xmm13
0000796caedd4b73  vmovaps [rsp+0xD0], xmm14
0000796caedd4b7c  vmovaps [rsp+0xE0], xmm15
0000796caedd4b85  sub rsp, 0x30
0000796caedd4b89  movaps [rsp], xmm9
0000796caedd4b8e  movaps [rsp+0x10], xmm1
0000796caedd4b93  movaps [rsp+0x20], xmm14
0000796caedd4b99  lea rdi, [rsp]
0000796caedd4b9d  mov esi, 0x00
0000796caedd4ba2  mov rax, 0x56877063A530
0000796caedd4bac  call rax
0000796caedd4bae  movaps xmm9, [rsp]
0000796caedd4bb3  add rsp, 0x30
0000796caedd4bb7  vmovaps xmm0, [rsp]
0000796caedd4bbc  vmovaps xmm1, [rsp+0x10]
0000796caedd4bc2  vmovaps xmm2, [rsp+0x20]
0000796caedd4bc8  vmovaps xmm3, [rsp+0x30]
0000796caedd4bce  vmovaps xmm4, [rsp+0x40]
0000796caedd4bd4  vmovaps xmm5, [rsp+0x50]
0000796caedd4bda  vmovaps xmm6, [rsp+0x60]
0000796caedd4be0  vmovaps xmm7, [rsp+0x70]
0000796caedd4be6  vmovaps xmm8, [rsp+0x80]
0000796caedd4bef  vmovaps xmm10, [rsp+0x90]
0000796caedd4bf8  vmovaps xmm11, [rsp+0xA0]
0000796caedd4c01  vmovaps xmm12, [rsp+0xB0]
0000796caedd4c0a  vmovaps xmm13, [rsp+0xC0]
0000796caedd4c13  vmovaps xmm14, [rsp+0xD0]
0000796caedd4c1c  vmovaps xmm15, [rsp+0xE0]
0000796caedd4c25  add rsp, 0xF0
0000796caedd4c2c  pop r11
0000796caedd4c2e  pop r10
0000796caedd4c30  pop r9
0000796caedd4c32  pop r8
0000796caedd4c34  pop rsi
0000796caedd4c35  pop rdi
0000796caedd4c36  pop rdx
0000796caedd4c37  pop rcx
0000796caedd4c38  pop rax
0000796caedd4c39  add rsp, 0x08
0000796caedd4c3d  jmp 0x0000796CAEDD01DD
0000796caedd4c42  sub rsp, 0x08
0000796caedd4c46  push rax
0000796caedd4c47  push rcx
0000796caedd4c48  push rdx
0000796caedd4c49  push rdi
0000796caedd4c4a  push rsi
0000796caedd4c4b  push r8
0000796caedd4c4d  push r9
0000796caedd4c4f  push r10
0000796caedd4c51  push r11
0000796caedd4c53  sub rsp, 0xF0
0000796caedd4c5a  vmovaps [rsp], xmm0
0000796caedd4c5f  vmovaps [rsp+0x10], xmm1
0000796caedd4c65  vmovaps [rsp+0x20], xmm2
0000796caedd4c6b  vmovaps [rsp+0x30], xmm3
0000796caedd4c71  vmovaps [rsp+0x40], xmm4
0000796caedd4c77  vmovaps [rsp+0x50], xmm5
0000796caedd4c7d  vmovaps [rsp+0x60], xmm6
0000796caedd4c83  vmovaps [rsp+0x70], xmm7
0000796caedd4c89  vmovaps [rsp+0x80], xmm8
0000796caedd4c92  vmovaps [rsp+0x90], xmm9
0000796caedd4c9b  vmovaps [rsp+0xA0], xmm10
0000796caedd4ca4  vmovaps [rsp+0xB0], xmm11
0000796caedd4cad  vmovaps [rsp+0xC0], xmm12
0000796caedd4cb6  vmovaps [rsp+0xD0], xmm13
0000796caedd4cbf  vmovaps [rsp+0xE0], xmm15
0000796caedd4cc8  sub rsp, 0x30
0000796caedd4ccc  movaps [rsp], xmm14
0000796caedd4cd1  movaps [rsp+0x10], xmm4
0000796caedd4cd6  movaps [rsp+0x20], xmm1
0000796caedd4cdb  lea rdi, [rsp]
0000796caedd4cdf  mov esi, 0x00
0000796caedd4ce4  mov rax, 0x56877063A530
0000796caedd4cee  call rax
0000796caedd4cf0  movaps xmm14, [rsp]
0000796caedd4cf5  add rsp, 0x30
0000796caedd4cf9  vmovaps xmm0, [rsp]
0000796caedd4cfe  vmovaps xmm1, [rsp+0x10]
0000796caedd4d04  vmovaps xmm2, [rsp+0x20]
0000796caedd4d0a  vmovaps xmm3, [rsp+0x30]
0000796caedd4d10  vmovaps xmm4, [rsp+0x40]
0000796caedd4d16  vmovaps xmm5, [rsp+0x50]
0000796caedd4d1c  vmovaps xmm6, [rsp+0x60]
0000796caedd4d22  vmovaps xmm7, [rsp+0x70]
0000796caedd4d28  vmovaps xmm8, [rsp+0x80]
0000796caedd4d31  vmovaps xmm9, [rsp+0x90]
0000796caedd4d3a  vmovaps xmm10, [rsp+0xA0]
0000796caedd4d43  vmovaps xmm11, [rsp+0xB0]
0000796caedd4d4c  vmovaps xmm12, [rsp+0xC0]
0000796caedd4d55  vmovaps xmm13, [rsp+0xD0]
0000796caedd4d5e  vmovaps xmm15, [rsp+0xE0]
0000796caedd4d67  add rsp, 0xF0
0000796caedd4d6e  pop r11
0000796caedd4d70  pop r10
0000796caedd4d72  pop r9
0000796caedd4d74  pop r8
0000796caedd4d76  pop rsi
0000796caedd4d77  pop rdi
0000796caedd4d78  pop rdx
0000796caedd4d79  pop rcx
0000796caedd4d7a  pop rax
0000796caedd4d7b  add rsp, 0x08
0000796caedd4d7f  jmp 0x0000796CAEDD0203
0000796caedd4d84  sub rsp, 0x08
0000796caedd4d88  push rax
0000796caedd4d89  push rcx
0000796caedd4d8a  push rdx
0000796caedd4d8b  push rdi
0000796caedd4d8c  push rsi
0000796caedd4d8d  push r8
0000796caedd4d8f  push r9
0000796caedd4d91  push r10
0000796caedd4d93  push r11
0000796caedd4d95  sub rsp, 0xF0
0000796caedd4d9c  vmovaps [rsp], xmm0
0000796caedd4da1  vmovaps [rsp+0x10], xmm2
0000796caedd4da7  vmovaps [rsp+0x20], xmm3
0000796caedd4dad  vmovaps [rsp+0x30], xmm4
0000796caedd4db3  vmovaps [rsp+0x40], xmm5
0000796caedd4db9  vmovaps [rsp+0x50], xmm6
0000796caedd4dbf  vmovaps [rsp+0x60], xmm7
0000796caedd4dc5  vmovaps [rsp+0x70], xmm8
0000796caedd4dcb  vmovaps [rsp+0x80], xmm9
0000796caedd4dd4  vmovaps [rsp+0x90], xmm10
0000796caedd4ddd  vmovaps [rsp+0xA0], xmm11
0000796caedd4de6  vmovaps [rsp+0xB0], xmm12
0000796caedd4def  vmovaps [rsp+0xC0], xmm13
0000796caedd4df8  vmovaps [rsp+0xD0], xmm14
0000796caedd4e01  vmovaps [rsp+0xE0], xmm15
0000796caedd4e0a  sub rsp, 0x30
0000796caedd4e0e  movaps [rsp], xmm1
0000796caedd4e12  movaps [rsp+0x10], xmm12
0000796caedd4e18  movaps [rsp+0x20], xmm11
0000796caedd4e1e  lea rdi, [rsp]
0000796caedd4e22  mov esi, 0x00
0000796caedd4e27  mov rax, 0x56877063A530
0000796caedd4e31  call rax
0000796caedd4e33  movaps xmm1, [rsp]
0000796caedd4e37  add rsp, 0x30
0000796caedd4e3b  vmovaps xmm0, [rsp]
0000796caedd4e40  vmovaps xmm2, [rsp+0x10]
0000796caedd4e46  vmovaps xmm3, [rsp+0x20]
0000796caedd4e4c  vmovaps xmm4, [rsp+0x30]
0000796caedd4e52  vmovaps xmm5, [rsp+0x40]
0000796caedd4e58  vmovaps xmm6, [rsp+0x50]
0000796caedd4e5e  vmovaps xmm7, [rsp+0x60]
0000796caedd4e64  vmovaps xmm8, [rsp+0x70]
0000796caedd4e6a  vmovaps xmm9, [rsp+0x80]
0000796caedd4e73  vmovaps xmm10, [rsp+0x90]
0000796caedd4e7c  vmovaps xmm11, [rsp+0xA0]
0000796caedd4e85  vmovaps xmm12, [rsp+0xB0]
0000796caedd4e8e  vmovaps xmm13, [rsp+0xC0]
0000796caedd4e97  vmovaps xmm14, [rsp+0xD0]
0000796caedd4ea0  vmovaps xmm15, [rsp+0xE0]
0000796caedd4ea9  add rsp, 0xF0
0000796caedd4eb0  pop r11
0000796caedd4eb2  pop r10
0000796caedd4eb4  pop r9
0000796caedd4eb6  pop r8
0000796caedd4eb8  pop rsi
0000796caedd4eb9  pop rdi
0000796caedd4eba  pop rdx
0000796caedd4ebb  pop rcx
0000796caedd4ebc  pop rax
0000796caedd4ebd  add rsp, 0x08
0000796caedd4ec1  jmp 0x0000796CAEDD0224
0000796caedd4ec6  call 0x0000796CAECE20A0
0000796caedd4ecb  jmp 0x0000796CAEDD0232
0000796caedd4ed0  call 0x0000796CAEC09D70
0000796caedd4ed5  jmp 0x0000796CAEDD023C
0000796caedd4eda  sub rsp, 0x08
0000796caedd4ede  push rax
0000796caedd4edf  push rcx
0000796caedd4ee0  push rdx
0000796caedd4ee1  push rdi
0000796caedd4ee2  push rsi
0000796caedd4ee3  push r8
0000796caedd4ee5  push r9
0000796caedd4ee7  push r10
0000796caedd4ee9  push r11
0000796caedd4eeb  sub rsp, 0xF0
0000796caedd4ef2  vmovaps [rsp], xmm0
0000796caedd4ef7  vmovaps [rsp+0x10], xmm1
0000796caedd4efd  vmovaps [rsp+0x20], xmm2
0000796caedd4f03  vmovaps [rsp+0x30], xmm3
0000796caedd4f09  vmovaps [rsp+0x40], xmm4
0000796caedd4f0f  vmovaps [rsp+0x50], xmm5
0000796caedd4f15  vmovaps [rsp+0x60], xmm6
0000796caedd4f1b  vmovaps [rsp+0x70], xmm8
0000796caedd4f21  vmovaps [rsp+0x80], xmm9
0000796caedd4f2a  vmovaps [rsp+0x90], xmm10
0000796caedd4f33  vmovaps [rsp+0xA0], xmm11
0000796caedd4f3c  vmovaps [rsp+0xB0], xmm12
0000796caedd4f45  vmovaps [rsp+0xC0], xmm13
0000796caedd4f4e  vmovaps [rsp+0xD0], xmm14
0000796caedd4f57  vmovaps [rsp+0xE0], xmm15
0000796caedd4f60  sub rsp, 0x30
0000796caedd4f64  movaps [rsp], xmm7
0000796caedd4f68  movaps [rsp+0x10], xmm15
0000796caedd4f6e  movaps [rsp+0x20], xmm10
0000796caedd4f74  lea rdi, [rsp]
0000796caedd4f78  mov esi, 0x00
0000796caedd4f7d  mov rax, 0x56877063A530
0000796caedd4f87  call rax
0000796caedd4f89  movaps xmm7, [rsp]
0000796caedd4f8d  add rsp, 0x30
0000796caedd4f91  vmovaps xmm0, [rsp]
0000796caedd4f96  vmovaps xmm1, [rsp+0x10]
0000796caedd4f9c  vmovaps xmm2, [rsp+0x20]
0000796caedd4fa2  vmovaps xmm3, [rsp+0x30]
0000796caedd4fa8  vmovaps xmm4, [rsp+0x40]
0000796caedd4fae  vmovaps xmm5, [rsp+0x50]
0000796caedd4fb4  vmovaps xmm6, [rsp+0x60]
0000796caedd4fba  vmovaps xmm8, [rsp+0x70]
0000796caedd4fc0  vmovaps xmm9, [rsp+0x80]
0000796caedd4fc9  vmovaps xmm10, [rsp+0x90]
0000796caedd4fd2  vmovaps xmm11, [rsp+0xA0]
0000796caedd4fdb  vmovaps xmm12, [rsp+0xB0]
0000796caedd4fe4  vmovaps xmm13, [rsp+0xC0]
0000796caedd4fed  vmovaps xmm14, [rsp+0xD0]
0000796caedd4ff6  vmovaps xmm15, [rsp+0xE0]
0000796caedd4fff  add rsp, 0xF0
0000796caedd5006  pop r11
0000796caedd5008  pop r10
0000796caedd500a  pop r9
0000796caedd500c  pop r8
0000796caedd500e  pop rsi
0000796caedd500f  pop rdi
0000796caedd5010  pop rdx
0000796caedd5011  pop rcx
0000796caedd5012  pop rax
0000796caedd5013  add rsp, 0x08
0000796caedd5017  jmp 0x0000796CAEDD025D
0000796caedd501c  sub rsp, 0x08
0000796caedd5020  push rax
0000796caedd5021  push rcx
0000796caedd5022  push rdx
0000796caedd5023  push rdi
0000796caedd5024  push rsi
0000796caedd5025  push r8
0000796caedd5027  push r9
0000796caedd5029  push r10
0000796caedd502b  push r11
0000796caedd502d  sub rsp, 0xF0
0000796caedd5034  vmovaps [rsp], xmm0
0000796caedd5039  vmovaps [rsp+0x10], xmm1
0000796caedd503f  vmovaps [rsp+0x20], xmm2
0000796caedd5045  vmovaps [rsp+0x30], xmm3
0000796caedd504b  vmovaps [rsp+0x40], xmm4
0000796caedd5051  vmovaps [rsp+0x50], xmm5
0000796caedd5057  vmovaps [rsp+0x60], xmm6
0000796caedd505d  vmovaps [rsp+0x70], xmm7
0000796caedd5063  vmovaps [rsp+0x80], xmm8
0000796caedd506c  vmovaps [rsp+0x90], xmm9
0000796caedd5075  vmovaps [rsp+0xA0], xmm11
0000796caedd507e  vmovaps [rsp+0xB0], xmm12
0000796caedd5087  vmovaps [rsp+0xC0], xmm13
0000796caedd5090  vmovaps [rsp+0xD0], xmm14
0000796caedd5099  vmovaps [rsp+0xE0], xmm15
0000796caedd50a2  sub rsp, 0x30
0000796caedd50a6  movaps [rsp], xmm10
0000796caedd50ab  movaps [rsp+0x10], xmm11
0000796caedd50b1  movaps [rsp+0x20], xmm15
0000796caedd50b7  lea rdi, [rsp]
0000796caedd50bb  mov esi, 0x00
0000796caedd50c0  mov rax, 0x56877063A530
0000796caedd50ca  call rax
0000796caedd50cc  movaps xmm10, [rsp]
0000796caedd50d1  add rsp, 0x30
0000796caedd50d5  vmovaps xmm0, [rsp]
0000796caedd50da  vmovaps xmm1, [rsp+0x10]
0000796caedd50e0  vmovaps xmm2, [rsp+0x20]
0000796caedd50e6  vmovaps xmm3, [rsp+0x30]
0000796caedd50ec  vmovaps xmm4, [rsp+0x40]
0000796caedd50f2  vmovaps xmm5, [rsp+0x50]
0000796caedd50f8  vmovaps xmm6, [rsp+0x60]
0000796caedd50fe  vmovaps xmm7, [rsp+0x70]
0000796caedd5104  vmovaps xmm8, [rsp+0x80]
0000796caedd510d  vmovaps xmm9, [rsp+0x90]
0000796caedd5116  vmovaps xmm11, [rsp+0xA0]
0000796caedd511f  vmovaps xmm12, [rsp+0xB0]
0000796caedd5128  vmovaps xmm13, [rsp+0xC0]
0000796caedd5131  vmovaps xmm14, [rsp+0xD0]
0000796caedd513a  vmovaps xmm15, [rsp+0xE0]
0000796caedd5143  add rsp, 0xF0
0000796caedd514a  pop r11
0000796caedd514c  pop r10
0000796caedd514e  pop r9
0000796caedd5150  pop r8
0000796caedd5152  pop rsi
0000796caedd5153  pop rdi
0000796caedd5154  pop rdx
0000796caedd5155  pop rcx
0000796caedd5156  pop rax
0000796caedd5157  add rsp, 0x08
0000796caedd515b  jmp 0x0000796CAEDD028B
0000796caedd5160  sub rsp, 0x08
0000796caedd5164  push rax
0000796caedd5165  push rcx
0000796caedd5166  push rdx
0000796caedd5167  push rdi
0000796caedd5168  push rsi
0000796caedd5169  push r8
0000796caedd516b  push r9
0000796caedd516d  push r10
0000796caedd516f  push r11
0000796caedd5171  sub rsp, 0xF0
0000796caedd5178  vmovaps [rsp], xmm0
0000796caedd517d  vmovaps [rsp+0x10], xmm1
0000796caedd5183  vmovaps [rsp+0x20], xmm2
0000796caedd5189  vmovaps [rsp+0x30], xmm3
0000796caedd518f  vmovaps [rsp+0x40], xmm4
0000796caedd5195  vmovaps [rsp+0x50], xmm5
0000796caedd519b  vmovaps [rsp+0x60], xmm6
0000796caedd51a1  vmovaps [rsp+0x70], xmm7
0000796caedd51a7  vmovaps [rsp+0x80], xmm8
0000796caedd51b0  vmovaps [rsp+0x90], xmm9
0000796caedd51b9  vmovaps [rsp+0xA0], xmm10
0000796caedd51c2  vmovaps [rsp+0xB0], xmm12
0000796caedd51cb  vmovaps [rsp+0xC0], xmm13
0000796caedd51d4  vmovaps [rsp+0xD0], xmm14
0000796caedd51dd  vmovaps [rsp+0xE0], xmm15
0000796caedd51e6  sub rsp, 0x30
0000796caedd51ea  movaps [rsp], xmm11
0000796caedd51ef  movaps [rsp+0x10], xmm12
0000796caedd51f5  movaps [rsp+0x20], xmm15
0000796caedd51fb  lea rdi, [rsp]
0000796caedd51ff  mov esi, 0x00
0000796caedd5204  mov rax, 0x56877063A530
0000796caedd520e  call rax
0000796caedd5210  movaps xmm11, [rsp]
0000796caedd5215  add rsp, 0x30
0000796caedd5219  vmovaps xmm0, [rsp]
0000796caedd521e  vmovaps xmm1, [rsp+0x10]
0000796caedd5224  vmovaps xmm2, [rsp+0x20]
0000796caedd522a  vmovaps xmm3, [rsp+0x30]
0000796caedd5230  vmovaps xmm4, [rsp+0x40]
0000796caedd5236  vmovaps xmm5, [rsp+0x50]
0000796caedd523c  vmovaps xmm6, [rsp+0x60]
0000796caedd5242  vmovaps xmm7, [rsp+0x70]
0000796caedd5248  vmovaps xmm8, [rsp+0x80]
0000796caedd5251  vmovaps xmm9, [rsp+0x90]
0000796caedd525a  vmovaps xmm10, [rsp+0xA0]
0000796caedd5263  vmovaps xmm12, [rsp+0xB0]
0000796caedd526c  vmovaps xmm13, [rsp+0xC0]
0000796caedd5275  vmovaps xmm14, [rsp+0xD0]
0000796caedd527e  vmovaps xmm15, [rsp+0xE0]
0000796caedd5287  add rsp, 0xF0
0000796caedd528e  pop r11
0000796caedd5290  pop r10
0000796caedd5292  pop r9
0000796caedd5294  pop r8
0000796caedd5296  pop rsi
0000796caedd5297  pop rdi
0000796caedd5298  pop rdx
0000796caedd5299  pop rcx
0000796caedd529a  pop rax
0000796caedd529b  add rsp, 0x08
0000796caedd529f  jmp 0x0000796CAEDD02B9
0000796caedd52a4  sub rsp, 0x08
0000796caedd52a8  push rax
0000796caedd52a9  push rcx
0000796caedd52aa  push rdx
0000796caedd52ab  push rdi
0000796caedd52ac  push rsi
0000796caedd52ad  push r8
0000796caedd52af  push r9
0000796caedd52b1  push r10
0000796caedd52b3  push r11
0000796caedd52b5  sub rsp, 0xF0
0000796caedd52bc  vmovaps [rsp], xmm0
0000796caedd52c1  vmovaps [rsp+0x10], xmm1
0000796caedd52c7  vmovaps [rsp+0x20], xmm2
0000796caedd52cd  vmovaps [rsp+0x30], xmm3
0000796caedd52d3  vmovaps [rsp+0x40], xmm4
0000796caedd52d9  vmovaps [rsp+0x50], xmm5
0000796caedd52df  vmovaps [rsp+0x60], xmm6
0000796caedd52e5  vmovaps [rsp+0x70], xmm7
0000796caedd52eb  vmovaps [rsp+0x80], xmm8
0000796caedd52f4  vmovaps [rsp+0x90], xmm9
0000796caedd52fd  vmovaps [rsp+0xA0], xmm10
0000796caedd5306  vmovaps [rsp+0xB0], xmm11
0000796caedd530f  vmovaps [rsp+0xC0], xmm12
0000796caedd5318  vmovaps [rsp+0xD0], xmm13
0000796caedd5321  vmovaps [rsp+0xE0], xmm14
0000796caedd532a  sub rsp, 0x30
0000796caedd532e  movaps [rsp], xmm15
0000796caedd5333  movaps [rsp+0x10], xmm13
0000796caedd5339  movaps [rsp+0x20], xmm9
0000796caedd533f  lea rdi, [rsp]
0000796caedd5343  mov esi, 0x00
0000796caedd5348  mov rax, 0x56877063A530
0000796caedd5352  call rax
0000796caedd5354  movaps xmm15, [rsp]
0000796caedd5359  add rsp, 0x30
0000796caedd535d  vmovaps xmm0, [rsp]
0000796caedd5362  vmovaps xmm1, [rsp+0x10]
0000796caedd5368  vmovaps xmm2, [rsp+0x20]
0000796caedd536e  vmovaps xmm3, [rsp+0x30]
0000796caedd5374  vmovaps xmm4, [rsp+0x40]
0000796caedd537a  vmovaps xmm5, [rsp+0x50]
0000796caedd5380  vmovaps xmm6, [rsp+0x60]
0000796caedd5386  vmovaps xmm7, [rsp+0x70]
0000796caedd538c  vmovaps xmm8, [rsp+0x80]
0000796caedd5395  vmovaps xmm9, [rsp+0x90]
0000796caedd539e  vmovaps xmm10, [rsp+0xA0]
0000796caedd53a7  vmovaps xmm11, [rsp+0xB0]
0000796caedd53b0  vmovaps xmm12, [rsp+0xC0]
0000796caedd53b9  vmovaps xmm13, [rsp+0xD0]
0000796caedd53c2  vmovaps xmm14, [rsp+0xE0]
0000796caedd53cb  add rsp, 0xF0
0000796caedd53d2  pop r11
0000796caedd53d4  pop r10
0000796caedd53d6  pop r9
0000796caedd53d8  pop r8
0000796caedd53da  pop rsi
0000796caedd53db  pop rdi
0000796caedd53dc  pop rdx
0000796caedd53dd  pop rcx
0000796caedd53de  pop rax
0000796caedd53df  add rsp, 0x08
0000796caedd53e3  jmp 0x0000796CAEDD02D4
0000796caedd53e8  sub rsp, 0x08
0000796caedd53ec  push rax
0000796caedd53ed  push rcx
0000796caedd53ee  push rdx
0000796caedd53ef  push rdi
0000796caedd53f0  push rsi
0000796caedd53f1  push r8
0000796caedd53f3  push r9
0000796caedd53f5  push r10
0000796caedd53f7  push r11
0000796caedd53f9  sub rsp, 0xF0
0000796caedd5400  vmovaps [rsp], xmm0
0000796caedd5405  vmovaps [rsp+0x10], xmm1
0000796caedd540b  vmovaps [rsp+0x20], xmm2
0000796caedd5411  vmovaps [rsp+0x30], xmm3
0000796caedd5417  vmovaps [rsp+0x40], xmm4
0000796caedd541d  vmovaps [rsp+0x50], xmm5
0000796caedd5423  vmovaps [rsp+0x60], xmm6
0000796caedd5429  vmovaps [rsp+0x70], xmm7
0000796caedd542f  vmovaps [rsp+0x80], xmm8
0000796caedd5438  vmovaps [rsp+0x90], xmm9
0000796caedd5441  vmovaps [rsp+0xA0], xmm10
0000796caedd544a  vmovaps [rsp+0xB0], xmm11
0000796caedd5453  vmovaps [rsp+0xC0], xmm12
0000796caedd545c  vmovaps [rsp+0xD0], xmm14
0000796caedd5465  vmovaps [rsp+0xE0], xmm15
0000796caedd546e  sub rsp, 0x30
0000796caedd5472  movaps [rsp], xmm13
0000796caedd5477  movaps [rsp+0x10], xmm8
0000796caedd547d  movaps [rsp+0x20], xmm14
0000796caedd5483  lea rdi, [rsp]
0000796caedd5487  mov esi, 0x00
0000796caedd548c  mov rax, 0x56877063A530
0000796caedd5496  call rax
0000796caedd5498  movaps xmm13, [rsp]
0000796caedd549d  add rsp, 0x30
0000796caedd54a1  vmovaps xmm0, [rsp]
0000796caedd54a6  vmovaps xmm1, [rsp+0x10]
0000796caedd54ac  vmovaps xmm2, [rsp+0x20]
0000796caedd54b2  vmovaps xmm3, [rsp+0x30]
0000796caedd54b8  vmovaps xmm4, [rsp+0x40]
0000796caedd54be  vmovaps xmm5, [rsp+0x50]
0000796caedd54c4  vmovaps xmm6, [rsp+0x60]
0000796caedd54ca  vmovaps xmm7, [rsp+0x70]
0000796caedd54d0  vmovaps xmm8, [rsp+0x80]
0000796caedd54d9  vmovaps xmm9, [rsp+0x90]
0000796caedd54e2  vmovaps xmm10, [rsp+0xA0]
0000796caedd54eb  vmovaps xmm11, [rsp+0xB0]
0000796caedd54f4  vmovaps xmm12, [rsp+0xC0]
0000796caedd54fd  vmovaps xmm14, [rsp+0xD0]
0000796caedd5506  vmovaps xmm15, [rsp+0xE0]
0000796caedd550f  add rsp, 0xF0
0000796caedd5516  pop r11
0000796caedd5518  pop r10
0000796caedd551a  pop r9
0000796caedd551c  pop r8
0000796caedd551e  pop rsi
0000796caedd551f  pop rdi
0000796caedd5520  pop rdx
0000796caedd5521  pop rcx
0000796caedd5522  pop rax
0000796caedd5523  add rsp, 0x08
0000796caedd5527  jmp 0x0000796CAEDD02F7
0000796caedd552c  sub rsp, 0x08
0000796caedd5530  push rax
0000796caedd5531  push rcx
0000796caedd5532  push rdx
0000796caedd5533  push rdi
0000796caedd5534  push rsi
0000796caedd5535  push r8
0000796caedd5537  push r9
0000796caedd5539  push r10
0000796caedd553b  push r11
0000796caedd553d  sub rsp, 0xF0
0000796caedd5544  vmovaps [rsp], xmm0
0000796caedd5549  vmovaps [rsp+0x10], xmm1
0000796caedd554f  vmovaps [rsp+0x20], xmm2
0000796caedd5555  vmovaps [rsp+0x30], xmm3
0000796caedd555b  vmovaps [rsp+0x40], xmm4
0000796caedd5561  vmovaps [rsp+0x50], xmm5
0000796caedd5567  vmovaps [rsp+0x60], xmm6
0000796caedd556d  vmovaps [rsp+0x70], xmm7
0000796caedd5573  vmovaps [rsp+0x80], xmm8
0000796caedd557c  vmovaps [rsp+0x90], xmm9
0000796caedd5585  vmovaps [rsp+0xA0], xmm10
0000796caedd558e  vmovaps [rsp+0xB0], xmm11
0000796caedd5597  vmovaps [rsp+0xC0], xmm12
0000796caedd55a0  vmovaps [rsp+0xD0], xmm13
0000796caedd55a9  vmovaps [rsp+0xE0], xmm15
0000796caedd55b2  sub rsp, 0x30
0000796caedd55b6  movaps [rsp], xmm14
0000796caedd55bb  movaps [rsp+0x10], xmm1
0000796caedd55c0  movaps [rsp+0x20], xmm10
0000796caedd55c6  lea rdi, [rsp]
0000796caedd55ca  mov esi, 0x00
0000796caedd55cf  mov rax, 0x56877063A530
0000796caedd55d9  call rax
0000796caedd55db  movaps xmm14, [rsp]
0000796caedd55e0  add rsp, 0x30
0000796caedd55e4  vmovaps xmm0, [rsp]
0000796caedd55e9  vmovaps xmm1, [rsp+0x10]
0000796caedd55ef  vmovaps xmm2, [rsp+0x20]
0000796caedd55f5  vmovaps xmm3, [rsp+0x30]
0000796caedd55fb  vmovaps xmm4, [rsp+0x40]
0000796caedd5601  vmovaps xmm5, [rsp+0x50]
0000796caedd5607  vmovaps xmm6, [rsp+0x60]
0000796caedd560d  vmovaps xmm7, [rsp+0x70]
0000796caedd5613  vmovaps xmm8, [rsp+0x80]
0000796caedd561c  vmovaps xmm9, [rsp+0x90]
0000796caedd5625  vmovaps xmm10, [rsp+0xA0]
0000796caedd562e  vmovaps xmm11, [rsp+0xB0]
0000796caedd5637  vmovaps xmm12, [rsp+0xC0]
0000796caedd5640  vmovaps xmm13, [rsp+0xD0]
0000796caedd5649  vmovaps xmm15, [rsp+0xE0]
0000796caedd5652  add rsp, 0xF0
0000796caedd5659  pop r11
0000796caedd565b  pop r10
0000796caedd565d  pop r9
0000796caedd565f  pop r8
0000796caedd5661  pop rsi
0000796caedd5662  pop rdi
0000796caedd5663  pop rdx
0000796caedd5664  pop rcx
0000796caedd5665  pop rax
0000796caedd5666  add rsp, 0x08
0000796caedd566a  jmp 0x0000796CAEDD031A
0000796caedd566f  sub rsp, 0x08
0000796caedd5673  push rax
0000796caedd5674  push rcx
0000796caedd5675  push rdx
0000796caedd5676  push rdi
0000796caedd5677  push rsi
0000796caedd5678  push r8
0000796caedd567a  push r9
0000796caedd567c  push r10
0000796caedd567e  push r11
0000796caedd5680  sub rsp, 0xF0
0000796caedd5687  vmovaps [rsp], xmm0
0000796caedd568c  vmovaps [rsp+0x10], xmm2
0000796caedd5692  vmovaps [rsp+0x20], xmm3
0000796caedd5698  vmovaps [rsp+0x30], xmm4
0000796caedd569e  vmovaps [rsp+0x40], xmm5
0000796caedd56a4  vmovaps [rsp+0x50], xmm6
0000796caedd56aa  vmovaps [rsp+0x60], xmm7
0000796caedd56b0  vmovaps [rsp+0x70], xmm8
0000796caedd56b6  vmovaps [rsp+0x80], xmm9
0000796caedd56bf  vmovaps [rsp+0x90], xmm10
0000796caedd56c8  vmovaps [rsp+0xA0], xmm11
0000796caedd56d1  vmovaps [rsp+0xB0], xmm12
0000796caedd56da  vmovaps [rsp+0xC0], xmm13
0000796caedd56e3  vmovaps [rsp+0xD0], xmm14
0000796caedd56ec  vmovaps [rsp+0xE0], xmm15
0000796caedd56f5  sub rsp, 0x30
0000796caedd56f9  movaps [rsp], xmm1
0000796caedd56fd  movaps [rsp+0x10], xmm7
0000796caedd5702  movaps [rsp+0x20], xmm11
0000796caedd5708  lea rdi, [rsp]
0000796caedd570c  mov esi, 0x00
0000796caedd5711  mov rax, 0x56877063A530
0000796caedd571b  call rax
0000796caedd571d  movaps xmm1, [rsp]
0000796caedd5721  add rsp, 0x30
0000796caedd5725  vmovaps xmm0, [rsp]
0000796caedd572a  vmovaps xmm2, [rsp+0x10]
0000796caedd5730  vmovaps xmm3, [rsp+0x20]
0000796caedd5736  vmovaps xmm4, [rsp+0x30]
0000796caedd573c  vmovaps xmm5, [rsp+0x40]
0000796caedd5742  vmovaps xmm6, [rsp+0x50]
0000796caedd5748  vmovaps xmm7, [rsp+0x60]
0000796caedd574e  vmovaps xmm8, [rsp+0x70]
0000796caedd5754  vmovaps xmm9, [rsp+0x80]
0000796caedd575d  vmovaps xmm10, [rsp+0x90]
0000796caedd5766  vmovaps xmm11, [rsp+0xA0]
0000796caedd576f  vmovaps xmm12, [rsp+0xB0]
0000796caedd5778  vmovaps xmm13, [rsp+0xC0]
0000796caedd5781  vmovaps xmm14, [rsp+0xD0]
0000796caedd578a  vmovaps xmm15, [rsp+0xE0]
0000796caedd5793  add rsp, 0xF0
0000796caedd579a  pop r11
0000796caedd579c  pop r10
0000796caedd579e  pop r9
0000796caedd57a0  pop r8
0000796caedd57a2  pop rsi
0000796caedd57a3  pop rdi
0000796caedd57a4  pop rdx
0000796caedd57a5  pop rcx
0000796caedd57a6  pop rax
0000796caedd57a7  add rsp, 0x08
0000796caedd57ab  jmp 0x0000796CAEDD033B
0000796caedd57b0  call 0x0000796CAEC0E880
0000796caedd57b5  jmp 0x0000796CAEDD034E
0000796caedd57ba  call 0x0000796CAEC0C380
0000796caedd57bf  jmp 0x0000796CAEDD0359
0000796caedd57c4  call 0x0000796CAEC0D600
0000796caedd57c9  jmp 0x0000796CAEDD0364
0000796caedd57ce  call 0x0000796CAEBFF540
0000796caedd57d3  jmp 0x0000796CAEDD036F
0000796caedd57d8  int3
0000796caedd57d9  nop [rax], eax
0000796caedd57e0  mov rax, [r15+0x40]
0000796caedd57e4  mov r14, [r15+0x58]
0000796caedd57e8  lea r12, [rax+r14*1]
0000796caedd57ec  movaps xmm1, [r15+0x1D0]
0000796caedd57f4  vmovaps [rsp+0x10], xmm1
0000796caedd57fa  vmovaps xmm15, [rsp+0x10]
0000796caedd5800  por xmm1, xmm15
0000796caedd5805  movaps xmm14, [r15+0x1A0]
0000796caedd580d  vmovaps [rsp+0x10], xmm14
0000796caedd5813  vmovaps xmm13, [rsp+0x10]
0000796caedd5819  por xmm14, xmm13
0000796caedd581e  lea rax, [r12+0x30]
0000796caedd5823  mov r11, [r13+rax*1]
0000796caedd5828  lea rax, [r12+0x38]
0000796caedd582d  mov r10, [r13+rax*1]
0000796caedd5832  movq xmm13, r11
0000796caedd5837  movq xmm12, r10
0000796caedd583c  movq xmm13, xmm13
0000796caedd5841  vmovaps [rsp+0x10], xmm13
0000796caedd5847  movq xmm13, xmm13
0000796caedd584c  movaps [r15+0x130], xmm13
0000796caedd5854  movq xmm12, xmm12
0000796caedd5859  vmovaps [rsp+0x20], xmm12
0000796caedd585f  movq xmm12, xmm12
0000796caedd5864  movaps [r15+0x280], xmm12
0000796caedd586c  movaps xmm13, [r15+0x270]
0000796caedd5874  vmovaps [rsp+0x30], xmm13
0000796caedd587a  vmovaps xmm12, [rsp+0x30]
0000796caedd5880  por xmm13, xmm12
0000796caedd5885  lea rax, [r12+0x20]
0000796caedd588a  mov r11, [r13+rax*1]
0000796caedd588f  lea rax, [r12+0x28]
0000796caedd5894  mov r10, [r13+rax*1]
0000796caedd5899  movq xmm12, r11
0000796caedd589e  movq xmm11, r10
0000796caedd58a3  movq xmm12, xmm12
0000796caedd58a8  vmovaps [rsp+0x30], xmm12
0000796caedd58ae  movq xmm12, xmm12
0000796caedd58b3  movaps [r15+0x150], xmm12
0000796caedd58bb  movq xmm11, xmm11
0000796caedd58c0  vmovaps [rsp+0x40], xmm11
0000796caedd58c6  movq xmm11, xmm11
0000796caedd58cb  movaps [r15+0x140], xmm11
0000796caedd58d3  lea rax, [r12+0x10]
0000796caedd58d8  mov r11, [r13+rax*1]
0000796caedd58dd  lea rax, [r12+0x18]
0000796caedd58e2  mov r10, [r13+rax*1]
0000796caedd58e7  movq xmm12, r11
0000796caedd58ec  movq xmm11, r10
0000796caedd58f1  movq xmm12, xmm12
0000796caedd58f6  vmovaps [rsp+0x50], xmm12
0000796caedd58fc  movq xmm12, xmm12
0000796caedd5901  movaps [r15+0x170], xmm12
0000796caedd5909  movq xmm11, xmm11
0000796caedd590e  vmovaps [rsp+0x60], xmm11
0000796caedd5914  movq xmm11, xmm11
0000796caedd5919  movaps [r15+0x160], xmm11
0000796caedd5921  mov rax, [r13+r12*1]
0000796caedd5926  vmovq xmm12, rax
0000796caedd592b  vpbroadcastq xmm12, xmm12
0000796caedd5930  lea rax, [r12+0x08]
0000796caedd5935  mov r12, [r13+rax*1]
0000796caedd593a  movq xmm11, r12
0000796caedd593f  movaps [r15+0x230], xmm11
0000796caedd5947  mov rax, [r15+0xF8]
0000796caedd594e  lea r12, [rax+0x50]
0000796caedd5952  movups xmm11, [r13+r12*1]
0000796caedd5958  lea r12, [rax+0x60]
0000796caedd595c  movups xmm10, [r13+r12*1]
0000796caedd5962  lea r12, [rax+0x30]
0000796caedd5966  movups xmm9, [r13+r12*1]
0000796caedd596c  mov r12, [r15+0x50]
0000796caedd5970  lea r11, [r12+r14*1]
0000796caedd5974  mov [r15+0x60], r11
0000796caedd5978  lea r12, [r14+0x40]
0000796caedd597c  mov [r15+0x58], r12
0000796caedd5980  movaps xmm8, xmm12
0000796caedd5984  mulpd xmm8, xmm15
0000796caedd5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000796caedd598f  ptest xmm7, xmm7
0000796caedd5994  jnz 0x0000796CAEDD67B7
0000796caedd599a  movq xmm15, qword ptr [r15+0x230]
0000796caedd59a3  vmovaps [rsp+0x70], xmm15
0000796caedd59a9  vpermilpd xmm15, xmm15, 0x00
0000796caedd59af  movaps xmm7, xmm9
0000796caedd59b3  mulpd xmm7, xmm15
0000796caedd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000796caedd59bd  ptest xmm6, xmm6
0000796caedd59c2  jnz 0x0000796CAEDD68FB
0000796caedd59c8  vxorps xmm15, xmm15, xmm15
0000796caedd59cd  vpbroadcastq xmm15, xmm15
0000796caedd59d2  movaps xmm9, xmm12
0000796caedd59d6  mulpd xmm9, xmm10
0000796caedd59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000796caedd59e1  ptest xmm6, xmm6
0000796caedd59e6  jnz 0x0000796CAEDD6A3D
0000796caedd59ec  movaps xmm10, xmm12
0000796caedd59f0  mulpd xmm10, xmm11
0000796caedd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000796caedd59fb  ptest xmm6, xmm6
0000796caedd5a00  jnz 0x0000796CAEDD6B81
0000796caedd5a06  movaps xmm11, [r15+0x1F0]
0000796caedd5a0e  movaps xmm6, xmm12
0000796caedd5a12  mulpd xmm6, xmm11
0000796caedd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000796caedd5a1c  ptest xmm5, xmm5
0000796caedd5a21  jnz 0x0000796CAEDD6CC5
0000796caedd5a27  movaps xmm12, [r15+0x2A0]
0000796caedd5a2f  vmovaps [rsp+0x80], xmm12
0000796caedd5a38  vmovaps xmm11, [rsp+0x80]
0000796caedd5a41  por xmm12, xmm11
0000796caedd5a46  movaps xmm11, [r15+0x250]
0000796caedd5a4e  vmovaps [rsp+0x80], xmm11
0000796caedd5a57  vmovaps xmm5, [rsp+0x80]
0000796caedd5a60  por xmm11, xmm5
0000796caedd5a65  vmovaps xmm4, [rsp+0x70]
0000796caedd5a6b  vpermilpd xmm4, xmm4, 0x00
0000796caedd5a71  movaps xmm3, xmm5
0000796caedd5a74  mulpd xmm3, xmm4
0000796caedd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000796caedd5a7d  ptest xmm2, xmm2
0000796caedd5a82  jnz 0x0000796CAEDD6E07
0000796caedd5a88  mov [rsp+0x80], rax
0000796caedd5a90  xor eax, eax
0000796caedd5a92  mov r14d, 0x200
0000796caedd5a98  cmp r12, r14
0000796caedd5a9b  cmc
0000796caedd5a9c  lahf
0000796caedd5a9d  seto al
0000796caedd5aa0  mov [r15+0x108], eax
0000796caedd5aa7  movaps xmm5, xmm8
0000796caedd5aab  addpd xmm5, xmm15
0000796caedd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000796caedd5ab5  ptest xmm4, xmm4
0000796caedd5aba  jnz 0x0000796CAEDD6F47
0000796caedd5ac0  movaps xmm8, [r15+0x1B0]
0000796caedd5ac8  movaps xmm4, xmm9
0000796caedd5acc  addpd xmm4, xmm8
0000796caedd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000796caedd5ad6  ptest xmm2, xmm2
0000796caedd5adb  jnz 0x0000796CAEDD7089
0000796caedd5ae1  movaps xmm9, xmm10
0000796caedd5ae5  addpd xmm9, xmm8
0000796caedd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000796caedd5af0  ptest xmm2, xmm2
0000796caedd5af5  jnz 0x0000796CAEDD71CB
0000796caedd5afb  movaps xmm10, [r15+0x2F0]
0000796caedd5b03  vmovaps [rsp+0x90], xmm10
0000796caedd5b0c  vmovaps xmm8, [rsp+0x90]
0000796caedd5b15  por xmm10, xmm8
0000796caedd5b1a  movaps xmm8, [r15+0x2E0]
0000796caedd5b22  vmovaps [rsp+0x90], xmm8
0000796caedd5b2b  vmovaps xmm2, [rsp+0x90]
0000796caedd5b34  por xmm8, xmm2
0000796caedd5b39  movaps xmm2, [r15+0x2D0]
0000796caedd5b41  vmovaps [rsp+0x90], xmm2
0000796caedd5b4a  vmovaps [rsp+0xA0], xmm1
0000796caedd5b53  vmovaps xmm1, [rsp+0x90]
0000796caedd5b5c  por xmm2, xmm1
0000796caedd5b60  movaps xmm1, [r15+0x200]
0000796caedd5b68  vmovaps [rsp+0x90], xmm1
0000796caedd5b71  vmovaps [rsp+0xB0], xmm15
0000796caedd5b7a  vmovaps xmm15, [rsp+0x90]
0000796caedd5b83  por xmm1, xmm15
0000796caedd5b88  movaps xmm15, [r15+0x1C0]
0000796caedd5b90  vmovaps [rsp+0x90], xmm15
0000796caedd5b99  vmovaps [rsp+0xC0], xmm1
0000796caedd5ba2  vmovaps xmm1, [rsp+0x90]
0000796caedd5bab  por xmm15, xmm1
0000796caedd5bb0  movaps xmm1, [r15+0x190]
0000796caedd5bb8  vmovaps [rsp+0x90], xmm1
0000796caedd5bc1  vmovaps [rsp+0xD0], xmm15
0000796caedd5bca  vmovaps xmm15, [rsp+0x90]
0000796caedd5bd3  por xmm1, xmm15
0000796caedd5bd8  movaps xmm15, [r15+0x300]
0000796caedd5be0  vmovaps [rsp+0x90], xmm15
0000796caedd5be9  vmovaps [rsp+0xE0], xmm1
0000796caedd5bf2  vmovaps xmm1, [rsp+0x90]
0000796caedd5bfb  por xmm15, xmm1
0000796caedd5c00  mov rax, [rsp+0x80]
0000796caedd5c08  lea r14, [rax+0xA0]
0000796caedd5c0f  movups xmm1, [r13+r14*1]
0000796caedd5c15  lea r14, [rax+0xB0]
0000796caedd5c1c  vmovaps [rsp+0x80], xmm1
0000796caedd5c25  movups xmm1, [r13+r14*1]
0000796caedd5c2b  vmovaps [rsp+0x90], xmm1
0000796caedd5c34  vmovaps [rsp+0xF0], xmm15
0000796caedd5c3d  vmovaps xmm15, [rsp+0xB0]
0000796caedd5c46  vmovaps [rsp+0xB0], xmm14
0000796caedd5c4f  movaps xmm1, xmm6
0000796caedd5c52  addpd xmm1, xmm15
0000796caedd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000796caedd5c5c  ptest xmm14, xmm14
0000796caedd5c62  jnz 0x0000796CAEDD7323
0000796caedd5c68  lea r14, [rax+0xF0]
0000796caedd5c6f  movups xmm15, [r13+r14*1]
0000796caedd5c75  movaps xmm14, xmm4
0000796caedd5c79  addpd xmm14, xmm3
0000796caedd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000796caedd5c84  ptest xmm6, xmm6
0000796caedd5c89  jnz 0x0000796CAEDD746E
0000796caedd5c8f  movaps xmm6, xmm9
0000796caedd5c93  addpd xmm6, xmm7
0000796caedd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000796caedd5c9c  ptest xmm4, xmm4
0000796caedd5ca1  jnz 0x0000796CAEDD75B0
0000796caedd5ca7  vmovaps xmm9, [rsp+0x70]
0000796caedd5cad  vpermilpd xmm9, xmm9, 0x00
0000796caedd5cb3  vmovaps xmm4, [rsp+0x90]
0000796caedd5cbc  movaps xmm7, xmm4
0000796caedd5cbf  mulpd xmm7, xmm9
0000796caedd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000796caedd5cc9  ptest xmm3, xmm3
0000796caedd5cce  jnz 0x0000796CAEDD76F1
0000796caedd5cd4  vmovaps xmm9, [rsp+0x50]
0000796caedd5cda  vpermilpd xmm9, xmm9, 0x00
0000796caedd5ce0  movaps xmm4, xmm15
0000796caedd5ce4  mulpd xmm4, xmm9
0000796caedd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000796caedd5cee  ptest xmm3, xmm3
0000796caedd5cf3  jnz 0x0000796CAEDD7832
0000796caedd5cf9  lea r14, [rax+0xE0]
0000796caedd5d00  movups xmm15, [r13+r14*1]
0000796caedd5d06  vmovaps xmm9, [rsp+0x70]
0000796caedd5d0c  vpermilpd xmm9, xmm9, 0x00
0000796caedd5d12  vmovaps [rsp+0x70], xmm1
0000796caedd5d18  vmovaps xmm1, [rsp+0x80]
0000796caedd5d21  vmovaps [rsp+0x80], xmm15
0000796caedd5d2a  movaps xmm3, xmm1
0000796caedd5d2d  mulpd xmm3, xmm9
0000796caedd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000796caedd5d37  ptest xmm15, xmm15
0000796caedd5d3d  jnz 0x0000796CAEDD797E
0000796caedd5d43  vmovaps xmm1, [rsp+0xF0]
0000796caedd5d4c  vmovaps xmm15, [rsp+0xF0]
0000796caedd5d55  por xmm1, xmm15
0000796caedd5d5a  movaps [r15+0x300], xmm1
0000796caedd5d62  vmovaps xmm15, [rsp+0xE0]
0000796caedd5d6b  vmovaps xmm9, [rsp+0xE0]
0000796caedd5d74  por xmm15, xmm9
0000796caedd5d79  movaps [r15+0x190], xmm15
0000796caedd5d81  vmovaps xmm9, [rsp+0x50]
0000796caedd5d87  vpermilpd xmm9, xmm9, 0x00
0000796caedd5d8d  vmovaps [rsp+0x90], xmm1
0000796caedd5d96  vmovaps [rsp+0xE0], xmm15
0000796caedd5d9f  vmovaps xmm15, [rsp+0x80]
0000796caedd5da8  vmovaps [rsp+0x80], xmm14
0000796caedd5db1  movaps xmm1, xmm15
0000796caedd5db5  mulpd xmm1, xmm9
0000796caedd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000796caedd5dbf  ptest xmm14, xmm14
0000796caedd5dc5  jnz 0x0000796CAEDD7ABF
0000796caedd5dcb  lea r14, [rax+0x90]
0000796caedd5dd2  movups xmm15, [r13+r14*1]
0000796caedd5dd8  vmovaps xmm14, [rsp+0xD0]
0000796caedd5de1  vmovaps xmm9, [rsp+0xD0]
0000796caedd5dea  por xmm14, xmm9
0000796caedd5def  movaps [r15+0x1C0], xmm14
0000796caedd5df7  vmovaps xmm9, [rsp+0xC0]
0000796caedd5e00  vmovaps [rsp+0xD0], xmm1
0000796caedd5e09  vmovaps xmm1, [rsp+0xC0]
0000796caedd5e12  por xmm9, xmm1
0000796caedd5e17  movaps [r15+0x200], xmm9
0000796caedd5e1f  vmovaps [rsp+0xC0], xmm2
0000796caedd5e28  vmovaps xmm1, [rsp+0xC0]
0000796caedd5e31  por xmm2, xmm1
0000796caedd5e35  movaps [r15+0x2D0], xmm2
0000796caedd5e3d  vmovaps [rsp+0xC0], xmm8
0000796caedd5e46  vmovaps xmm1, [rsp+0xC0]
0000796caedd5e4f  por xmm8, xmm1
0000796caedd5e54  movaps [r15+0x2E0], xmm8
0000796caedd5e5c  vmovaps [rsp+0xC0], xmm15
0000796caedd5e65  movaps xmm1, xmm5
0000796caedd5e68  addpd xmm1, xmm7
0000796caedd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000796caedd5e71  ptest xmm15, xmm15
0000796caedd5e77  jnz 0x0000796CAEDD7C0B
0000796caedd5e7d  vmovaps xmm15, [rsp+0x50]
0000796caedd5e83  vpermilpd xmm15, xmm15, 0x00
0000796caedd5e89  vmovaps xmm5, [rsp+0xC0]
0000796caedd5e92  vmovaps [rsp+0xC0], xmm1
0000796caedd5e9b  movaps xmm7, xmm5
0000796caedd5e9e  mulpd xmm7, xmm15
0000796caedd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000796caedd5ea8  ptest xmm1, xmm1
0000796caedd5ead  jnz 0x0000796CAEDD7D4B
0000796caedd5eb3  lea r14, [rax+0x80]
0000796caedd5eba  movups xmm1, [r13+r14*1]
0000796caedd5ec0  vmovaps xmm5, [rsp+0x70]
0000796caedd5ec6  vmovaps [rsp+0x70], xmm1
0000796caedd5ecc  movaps xmm15, xmm5
0000796caedd5ed0  addpd xmm15, xmm3
0000796caedd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000796caedd5edb  ptest xmm1, xmm1
0000796caedd5ee0  jnz 0x0000796CAEDD7E96
0000796caedd5ee6  vmovaps xmm5, [rsp+0x80]
0000796caedd5eef  movaps xmm1, xmm5
0000796caedd5ef2  addpd xmm1, xmm4
0000796caedd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000796caedd5efb  ptest xmm3, xmm3
0000796caedd5f00  jnz 0x0000796CAEDD7FD8
0000796caedd5f06  vmovaps [rsp+0x80], xmm10
0000796caedd5f0f  vmovaps xmm5, [rsp+0x80]
0000796caedd5f18  por xmm10, xmm5
0000796caedd5f1d  movaps [r15+0x2F0], xmm10
0000796caedd5f25  vmovaps xmm5, [rsp+0x50]
0000796caedd5f2b  vpermilpd xmm5, xmm5, 0x00
0000796caedd5f31  vmovaps xmm3, [rsp+0x70]
0000796caedd5f37  vmovaps [rsp+0x50], xmm1
0000796caedd5f3d  movaps xmm4, xmm3
0000796caedd5f40  mulpd xmm4, xmm5
0000796caedd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000796caedd5f49  ptest xmm1, xmm1
0000796caedd5f4e  jnz 0x0000796CAEDD8118
0000796caedd5f54  lea r14, [rax+0xD0]
0000796caedd5f5b  movups xmm1, [r13+r14*1]
0000796caedd5f61  vmovaps xmm3, [rsp+0xD0]
0000796caedd5f6a  vmovaps [rsp+0x70], xmm1
0000796caedd5f70  movaps xmm5, xmm6
0000796caedd5f73  addpd xmm5, xmm3
0000796caedd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000796caedd5f7c  ptest xmm1, xmm1
0000796caedd5f81  jnz 0x0000796CAEDD8262
0000796caedd5f87  vmovaps xmm1, [rsp+0x60]
0000796caedd5f8d  vpermilpd xmm1, xmm1, 0x00
0000796caedd5f93  movaps xmm6, xmm9
0000796caedd5f97  mulpd xmm6, xmm1
0000796caedd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000796caedd5fa0  ptest xmm3, xmm3
0000796caedd5fa5  jnz 0x0000796CAEDD83A2
0000796caedd5fab  movaps [r15+0x260], xmm6
0000796caedd5fb3  vxorps xmm1, xmm1, xmm1
0000796caedd5fb7  vpbroadcastq xmm1, xmm1
0000796caedd5fbc  movaps [r15+0x1B0], xmm1
0000796caedd5fc4  vmovaps xmm1, [rsp+0x60]
0000796caedd5fca  vpermilpd xmm1, xmm1, 0x00
0000796caedd5fd0  vmovaps xmm3, [rsp+0x70]
0000796caedd5fd6  vmovaps [rsp+0x70], xmm15
0000796caedd5fdc  movaps xmm9, xmm3
0000796caedd5fe0  mulpd xmm9, xmm1
0000796caedd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000796caedd5feb  ptest xmm15, xmm15
0000796caedd5ff1  jnz 0x0000796CAEDD84E3
0000796caedd5ff7  lea r14, [rax+0xC0]
0000796caedd5ffe  movups xmm1, [r13+r14*1]
0000796caedd6004  vmovaps xmm3, [rsp+0xC0]
0000796caedd600d  vmovaps [rsp+0x80], xmm1
0000796caedd6016  movaps xmm15, xmm3
0000796caedd601a  addpd xmm15, xmm7
0000796caedd601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000796caedd6025  ptest xmm1, xmm1
0000796caedd602a  jnz 0x0000796CAEDD862F
0000796caedd6030  vmovaps [rsp+0xC0], xmm13
0000796caedd6039  vmovaps xmm1, [rsp+0xC0]
0000796caedd6042  por xmm13, xmm1
0000796caedd6047  movaps [r15+0x270], xmm13
0000796caedd604f  vmovaps xmm1, [rsp+0xB0]
0000796caedd6058  vmovaps xmm7, [rsp+0xB0]
0000796caedd6061  por xmm1, xmm7
0000796caedd6065  movaps [r15+0x1A0], xmm1
0000796caedd606d  vmovaps xmm1, [rsp+0x60]
0000796caedd6073  vpermilpd xmm1, xmm1, 0x00
0000796caedd6079  vmovaps [rsp+0xB0], xmm1
0000796caedd6082  vmovaps xmm1, [rsp+0x80]
0000796caedd608b  vmovaps [rsp+0x80], xmm15
0000796caedd6094  vmovaps xmm15, [rsp+0xB0]
0000796caedd609d  vmovaps [rsp+0xB0], xmm14
0000796caedd60a6  movaps xmm3, xmm1
0000796caedd60a9  mulpd xmm3, xmm15
0000796caedd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000796caedd60b3  ptest xmm14, xmm14
0000796caedd60b9  jnz 0x0000796CAEDD8771
0000796caedd60bf  lea r14, [rax+0x20]
0000796caedd60c3  movups xmm1, [r13+r14*1]
0000796caedd60c9  movaps [r15+0x110], xmm1
0000796caedd60d1  vmovaps xmm14, [rsp+0x70]
0000796caedd60d7  vmovaps [rsp+0x70], xmm1
0000796caedd60dd  movaps xmm15, xmm14
0000796caedd60e1  addpd xmm15, xmm4
0000796caedd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000796caedd60ec  ptest xmm1, xmm1
0000796caedd60f1  jnz 0x0000796CAEDD88BC
0000796caedd60f7  vmovaps xmm1, [rsp+0x60]
0000796caedd60fd  vpermilpd xmm1, xmm1, 0x00
0000796caedd6103  movaps xmm14, xmm2
0000796caedd6107  mulpd xmm14, xmm1
0000796caedd610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000796caedd6112  ptest xmm4, xmm4
0000796caedd6117  jnz 0x0000796CAEDD89FF
0000796caedd611d  vmovaps xmm4, [rsp+0x50]
0000796caedd6123  movaps xmm1, xmm4
0000796caedd6126  addpd xmm1, xmm9
0000796caedd612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000796caedd6130  ptest xmm2, xmm2
0000796caedd6135  jnz 0x0000796CAEDD8B41
0000796caedd613b  vmovaps xmm9, [rsp+0x30]
0000796caedd6141  vpermilpd xmm9, xmm9, 0x00
0000796caedd6147  vmovaps xmm2, [rsp+0x70]
0000796caedd614d  vmovaps [rsp+0x50], xmm1
0000796caedd6153  movaps xmm4, xmm2
0000796caedd6156  mulpd xmm4, xmm9
0000796caedd615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000796caedd6160  ptest xmm1, xmm1
0000796caedd6165  jnz 0x0000796CAEDD8C82
0000796caedd616b  vmovaps xmm1, [rsp+0x30]
0000796caedd6171  vpermilpd xmm1, xmm1, 0x00
0000796caedd6177  vmovaps xmm2, [rsp+0x90]
0000796caedd6180  vmovaps [rsp+0x60], xmm15
0000796caedd6186  movaps xmm9, xmm2
0000796caedd618a  mulpd xmm9, xmm1
0000796caedd618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000796caedd6195  ptest xmm15, xmm15
0000796caedd619b  jnz 0x0000796CAEDD8DC3
0000796caedd61a1  vmovaps xmm15, [rsp+0x80]
0000796caedd61aa  movaps xmm1, xmm15
0000796caedd61ae  addpd xmm1, xmm6
0000796caedd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000796caedd61b7  ptest xmm2, xmm2
0000796caedd61bc  jnz 0x0000796CAEDD8F05
0000796caedd61c2  movaps xmm15, xmm5
0000796caedd61c6  addpd xmm15, xmm3
0000796caedd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000796caedd61d1  ptest xmm6, xmm6
0000796caedd61d6  jnz 0x0000796CAEDD9046
0000796caedd61dc  vmovaps xmm6, [rsp+0x30]
0000796caedd61e2  vpermilpd xmm6, xmm6, 0x00
0000796caedd61e8  movaps xmm5, xmm8
0000796caedd61ec  mulpd xmm5, xmm6
0000796caedd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000796caedd61f5  ptest xmm3, xmm3
0000796caedd61fa  jnz 0x0000796CAEDD9188
0000796caedd6200  vmovaps xmm8, [rsp+0x30]
0000796caedd6206  vpermilpd xmm8, xmm8, 0x00
0000796caedd620c  movaps xmm6, xmm10
0000796caedd6210  mulpd xmm6, xmm8
0000796caedd6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000796caedd621a  ptest xmm3, xmm3
0000796caedd621f  jnz 0x0000796CAEDD92C9
0000796caedd6225  vmovaps xmm8, [rsp+0x60]
0000796caedd622b  movaps xmm10, xmm8
0000796caedd622f  addpd xmm10, xmm14
0000796caedd6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000796caedd623a  ptest xmm3, xmm3
0000796caedd623f  jnz 0x0000796CAEDD940B
0000796caedd6245  vmovaps xmm8, [rsp+0x50]
0000796caedd624b  movaps xmm14, xmm8
0000796caedd624f  addpd xmm14, xmm4
0000796caedd6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000796caedd625a  ptest xmm3, xmm3
0000796caedd625f  jnz 0x0000796CAEDD954F
0000796caedd6265  vmovaps xmm8, [rsp+0x40]
0000796caedd626b  vpermilpd xmm8, xmm8, 0x00
0000796caedd6271  movaps xmm4, xmm13
0000796caedd6275  mulpd xmm4, xmm8
0000796caedd627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000796caedd627f  ptest xmm3, xmm3
0000796caedd6284  jnz 0x0000796CAEDD9692
0000796caedd628a  movaps xmm13, xmm15
0000796caedd628e  addpd xmm13, xmm9
0000796caedd6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000796caedd6299  ptest xmm8, xmm8
0000796caedd629f  jnz 0x0000796CAEDD97D4
0000796caedd62a5  movaps xmm15, xmm1
0000796caedd62a9  addpd xmm15, xmm5
0000796caedd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000796caedd62b4  ptest xmm9, xmm9
0000796caedd62ba  jnz 0x0000796CAEDD9918
0000796caedd62c0  vmovaps [rsp+0x30], xmm11
0000796caedd62c6  vmovaps xmm1, [rsp+0x30]
0000796caedd62cc  por xmm11, xmm1
0000796caedd62d1  movaps [r15+0x250], xmm11
0000796caedd62d9  vmovaps [rsp+0x30], xmm12
0000796caedd62df  vmovaps xmm1, [rsp+0x30]
0000796caedd62e5  por xmm12, xmm1
0000796caedd62ea  movaps [r15+0x2A0], xmm12
0000796caedd62f2  vmovaps xmm1, [rsp+0xA0]
0000796caedd62fb  vmovaps xmm11, [rsp+0xA0]
0000796caedd6304  por xmm1, xmm11
0000796caedd6309  movaps [r15+0x1D0], xmm1
0000796caedd6311  lea r14, [rax+0x40]
0000796caedd6315  movups xmm1, [r13+r14*1]
0000796caedd631b  movaps [r15+0x2C0], xmm1
0000796caedd6323  vmovaps xmm11, [rsp+0x40]
0000796caedd6329  vpermilpd xmm11, xmm11, 0x00
0000796caedd632f  vmovaps xmm8, [rsp+0xE0]
0000796caedd6338  movaps xmm9, xmm8
0000796caedd633c  mulpd xmm9, xmm11
0000796caedd6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000796caedd6347  ptest xmm5, xmm5
0000796caedd634c  jnz 0x0000796CAEDD9A64
0000796caedd6352  movaps xmm11, xmm10
0000796caedd6356  addpd xmm11, xmm6
0000796caedd635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000796caedd6361  ptest xmm8, xmm8
0000796caedd6367  jnz 0x0000796CAEDD9BA8
0000796caedd636d  movaps xmm10, xmm14
0000796caedd6371  addpd xmm10, xmm4
0000796caedd6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000796caedd637c  ptest xmm8, xmm8
0000796caedd6382  jnz 0x0000796CAEDD9CEB
0000796caedd6388  vmovaps xmm14, [rsp+0x40]
0000796caedd638e  vpermilpd xmm14, xmm14, 0x00
0000796caedd6394  movaps xmm8, xmm1
0000796caedd6398  mulpd xmm8, xmm14
0000796caedd639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000796caedd63a3  ptest xmm6, xmm6
0000796caedd63a8  jnz 0x0000796CAEDD9E2E
0000796caedd63ae  movaps xmm1, [r15+0x2B0]
0000796caedd63b6  vmovaps xmm14, [rsp+0x40]
0000796caedd63bc  vpermilpd xmm14, xmm14, 0x00
0000796caedd63c2  movaps xmm6, xmm1
0000796caedd63c5  mulpd xmm6, xmm14
0000796caedd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000796caedd63cf  ptest xmm5, xmm5
0000796caedd63d4  jnz 0x0000796CAEDD9F71
0000796caedd63da  vmovaps xmm1, [rsp+0x10]
0000796caedd63e0  vpermilpd xmm1, xmm1, 0x00
0000796caedd63e6  movaps xmm14, xmm12
0000796caedd63ea  mulpd xmm14, xmm1
0000796caedd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000796caedd63f5  ptest xmm5, xmm5
0000796caedd63fa  jnz 0x0000796CAEDDA0B2
0000796caedd6400  movaps xmm1, xmm13
0000796caedd6404  addpd xmm1, xmm9
0000796caedd6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000796caedd640e  ptest xmm12, xmm12
0000796caedd6414  jnz 0x0000796CAEDDA1F5
0000796caedd641a  vmovaps xmm13, [rsp+0x10]
0000796caedd6420  vpermilpd xmm13, xmm13, 0x00
0000796caedd6426  movaps xmm12, xmm7
0000796caedd642a  mulpd xmm12, xmm13
0000796caedd642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000796caedd6435  ptest xmm9, xmm9
0000796caedd643b  jnz 0x0000796CAEDDA337
0000796caedd6441  movaps xmm13, xmm15
0000796caedd6445  addpd xmm13, xmm8
0000796caedd644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000796caedd6450  ptest xmm9, xmm9
0000796caedd6456  jnz 0x0000796CAEDDA47A
0000796caedd645c  movaps xmm15, [r15+0x290]
0000796caedd6464  vmovaps xmm9, [rsp+0x10]
0000796caedd646a  vpermilpd xmm9, xmm9, 0x00
0000796caedd6470  movaps xmm8, xmm15
0000796caedd6474  mulpd xmm8, xmm9
0000796caedd6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000796caedd647f  ptest xmm7, xmm7
0000796caedd6484  jnz 0x0000796CAEDDA5BE
0000796caedd648a  movaps xmm15, xmm11
0000796caedd648e  addpd xmm15, xmm6
0000796caedd6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000796caedd6499  ptest xmm9, xmm9
0000796caedd649f  jnz 0x0000796CAEDDA702
0000796caedd64a5  movaps xmm11, [r15+0x1E0]
0000796caedd64ad  vmovaps xmm9, [rsp+0x10]
0000796caedd64b3  vpermilpd xmm9, xmm9, 0x00
0000796caedd64b9  movaps xmm7, xmm11
0000796caedd64bd  mulpd xmm7, xmm9
0000796caedd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000796caedd64c7  ptest xmm6, xmm6
0000796caedd64cc  jnz 0x0000796CAEDDA845
0000796caedd64d2  movaps xmm11, xmm10
0000796caedd64d6  addpd xmm11, xmm14
0000796caedd64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000796caedd64e1  ptest xmm9, xmm9
0000796caedd64e7  jnz 0x0000796CAEDDA987
0000796caedd64ed  lea r14, [rax+0x70]
0000796caedd64f1  movups xmm14, [r13+r14*1]
0000796caedd64f7  movaps [r15+0x240], xmm14
0000796caedd64ff  movaps xmm10, xmm1
0000796caedd6503  addpd xmm10, xmm12
0000796caedd6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000796caedd650e  ptest xmm9, xmm9
0000796caedd6514  jnz 0x0000796CAEDDAAD5
0000796caedd651a  movaps [r15+0x170], xmm10
0000796caedd6522  vmovaps xmm1, [rsp+0x20]
0000796caedd6528  vpermilpd xmm1, xmm1, 0x00
0000796caedd652e  movaps xmm12, xmm14
0000796caedd6532  mulpd xmm12, xmm1
0000796caedd6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000796caedd653d  ptest xmm9, xmm9
0000796caedd6543  jnz 0x0000796CAEDDAC18
0000796caedd6549  vmovaps xmm1, [rsp+0x20]
0000796caedd654f  vpermilpd xmm1, xmm1, 0x00
0000796caedd6555  vmovaps xmm9, [rsp+0xB0]
0000796caedd655e  movaps xmm14, xmm9
0000796caedd6562  mulpd xmm14, xmm1
0000796caedd6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000796caedd656d  ptest xmm6, xmm6
0000796caedd6572  jnz 0x0000796CAEDDAD5B
0000796caedd6578  movaps [r15+0x180], xmm14
0000796caedd6580  movaps xmm1, xmm13
0000796caedd6584  addpd xmm1, xmm8
0000796caedd6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000796caedd658e  ptest xmm9, xmm9
0000796caedd6594  jnz 0x0000796CAEDDAE9E
0000796caedd659a  movaps [r15+0x210], xmm1
0000796caedd65a2  movups xmm13, [r13+rax*1]
0000796caedd65a8  lea r14, [rax+0x10]
0000796caedd65ac  movups xmm9, [r13+r14*1]
0000796caedd65b2  movaps [r15+0x230], xmm9
0000796caedd65ba  movaps xmm8, xmm15
0000796caedd65be  addpd xmm8, xmm7
0000796caedd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000796caedd65c9  ptest xmm6, xmm6
0000796caedd65ce  jnz 0x0000796CAEDDAFF4
0000796caedd65d4  movaps [r15+0x130], xmm8
0000796caedd65dc  vmovaps xmm15, [rsp+0x20]
0000796caedd65e2  vpermilpd xmm15, xmm15, 0x00
0000796caedd65e8  movaps xmm7, xmm9
0000796caedd65ec  mulpd xmm7, xmm15
0000796caedd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000796caedd65f6  ptest xmm6, xmm6
0000796caedd65fb  jnz 0x0000796CAEDDB137
0000796caedd6601  movaps [r15+0x220], xmm7
0000796caedd6609  vmovaps xmm15, [rsp+0x20]
0000796caedd660f  vpermilpd xmm15, xmm15, 0x00
0000796caedd6615  movaps xmm9, xmm13
0000796caedd6619  mulpd xmm9, xmm15
0000796caedd661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000796caedd6624  ptest xmm6, xmm6
0000796caedd6629  jnz 0x0000796CAEDDB279
0000796caedd662f  movaps xmm15, xmm11
0000796caedd6633  addpd xmm15, xmm12
0000796caedd6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000796caedd663e  ptest xmm13, xmm13
0000796caedd6644  jnz 0x0000796CAEDDB3BD
0000796caedd664a  movaps [r15+0x140], xmm15
0000796caedd6652  movaps xmm13, xmm10
0000796caedd6656  addpd xmm13, xmm14
0000796caedd665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000796caedd6661  ptest xmm12, xmm12
0000796caedd6667  jnz 0x0000796CAEDDB501
0000796caedd666d  movaps [r15+0x150], xmm13
0000796caedd6675  movaps xmm14, xmm1
0000796caedd6679  addpd xmm14, xmm7
0000796caedd667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000796caedd6684  ptest xmm12, xmm12
0000796caedd668a  jnz 0x0000796CAEDDB645
0000796caedd6690  movaps [r15+0x160], xmm14
0000796caedd6698  movaps xmm1, xmm8
0000796caedd669c  addpd xmm1, xmm9
0000796caedd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000796caedd66a6  ptest xmm12, xmm12
0000796caedd66ac  jnz 0x0000796CAEDDB787
0000796caedd66b2  movaps [r15+0x120], xmm1
0000796caedd66ba  movups [r13+r11*1], xmm15
0000796caedd66c0  lea rax, [r11+0x10]
0000796caedd66c4  movups [r13+rax*1], xmm13
0000796caedd66ca  lea rax, [r11+0x20]
0000796caedd66ce  movups [r13+rax*1], xmm14
0000796caedd66d4  lea rax, [r11+0x30]
0000796caedd66d8  movups [r13+rax*1], xmm1
0000796caedd66de  mov eax, [r15+0x108]
0000796caedd66e5  sahf
0000796caedd66e6  jnz 0x0000796CAEDD6718
0000796caedd66e8  cmp dword ptr [r15+0x318], 0x00
0000796caedd66f0  jz 0x0000796CAEDDB900
0000796caedd66f6  nop [rax+rax*1], ax
0000796caedd66ff  nop [rax+rax*1], eax
0000796caedd6707  mov eax, 0x410444
0000796caedd670c  mov [r15+0x100], rax
0000796caedd6713  jmp 0x0000796CAEBFE110
0000796caedd6718  cmp dword ptr [r15+0x318], 0x00
0000796caedd6720  jz 0x0000796CAEDD57E0
0000796caedd6726  nop [rax+rax*1], ax
0000796caedd672f  nop [rax+rax*1], eax
0000796caedd6737  mov eax, 0x410278
0000796caedd673c  mov [r15+0x100], rax
0000796caedd6743  jmp 0x0000796CAEBFE110
0000796caedd6748  int3
0000796caedd6749  call 0x0000796CAEC0A4B0
0000796caedd674e  jmp 0x0000796CAEDD5828
0000796caedd6753  call 0x0000796CAEC09240
0000796caedd6758  jmp 0x0000796CAEDD5832
0000796caedd675d  call 0x0000796CAEC0A4B0
0000796caedd6762  jmp 0x0000796CAEDD588F
0000796caedd6767  call 0x0000796CAEC09240
0000796caedd676c  jmp 0x0000796CAEDD5899
0000796caedd6771  call 0x0000796CAEC0A4B0
0000796caedd6776  jmp 0x0000796CAEDD58DD
0000796caedd677b  call 0x0000796CAEC09240
0000796caedd6780  jmp 0x0000796CAEDD58E7
0000796caedd6785  call 0x0000796CAECB47C0
0000796caedd678a  jmp 0x0000796CAEDD5926
0000796caedd678f  call 0x0000796CAEC0B720
0000796caedd6794  jmp 0x0000796CAEDD593A
0000796caedd6799  call 0x0000796CAECBFC30
0000796caedd679e  jmp 0x0000796CAEDD5958
0000796caedd67a3  call 0x0000796CAECBE9C0
0000796caedd67a8  jmp 0x0000796CAEDD5962
0000796caedd67ad  call 0x0000796CAECBD750
0000796caedd67b2  jmp 0x0000796CAEDD596C
0000796caedd67b7  sub rsp, 0x08
0000796caedd67bb  push rax
0000796caedd67bc  push rcx
0000796caedd67bd  push rdx
0000796caedd67be  push rdi
0000796caedd67bf  push rsi
0000796caedd67c0  push r8
0000796caedd67c2  push r9
0000796caedd67c4  push r10
0000796caedd67c6  push r11
0000796caedd67c8  sub rsp, 0xF0
0000796caedd67cf  vmovaps [rsp], xmm0
0000796caedd67d4  vmovaps [rsp+0x10], xmm1
0000796caedd67da  vmovaps [rsp+0x20], xmm2
0000796caedd67e0  vmovaps [rsp+0x30], xmm3
0000796caedd67e6  vmovaps [rsp+0x40], xmm4
0000796caedd67ec  vmovaps [rsp+0x50], xmm5
0000796caedd67f2  vmovaps [rsp+0x60], xmm6
0000796caedd67f8  vmovaps [rsp+0x70], xmm7
0000796caedd67fe  vmovaps [rsp+0x80], xmm9
0000796caedd6807  vmovaps [rsp+0x90], xmm10
0000796caedd6810  vmovaps [rsp+0xA0], xmm11
0000796caedd6819  vmovaps [rsp+0xB0], xmm12
0000796caedd6822  vmovaps [rsp+0xC0], xmm13
0000796caedd682b  vmovaps [rsp+0xD0], xmm14
0000796caedd6834  vmovaps [rsp+0xE0], xmm15
0000796caedd683d  sub rsp, 0x30
0000796caedd6841  movaps [rsp], xmm8
0000796caedd6846  movaps [rsp+0x10], xmm12
0000796caedd684c  movaps [rsp+0x20], xmm15
0000796caedd6852  lea rdi, [rsp]
0000796caedd6856  mov esi, 0x00
0000796caedd685b  mov rax, 0x56877063A530
0000796caedd6865  call rax
0000796caedd6867  movaps xmm8, [rsp]
0000796caedd686c  add rsp, 0x30
0000796caedd6870  vmovaps xmm0, [rsp]
0000796caedd6875  vmovaps xmm1, [rsp+0x10]
0000796caedd687b  vmovaps xmm2, [rsp+0x20]
0000796caedd6881  vmovaps xmm3, [rsp+0x30]
0000796caedd6887  vmovaps xmm4, [rsp+0x40]
0000796caedd688d  vmovaps xmm5, [rsp+0x50]
0000796caedd6893  vmovaps xmm6, [rsp+0x60]
0000796caedd6899  vmovaps xmm7, [rsp+0x70]
0000796caedd689f  vmovaps xmm9, [rsp+0x80]
0000796caedd68a8  vmovaps xmm10, [rsp+0x90]
0000796caedd68b1  vmovaps xmm11, [rsp+0xA0]
0000796caedd68ba  vmovaps xmm12, [rsp+0xB0]
0000796caedd68c3  vmovaps xmm13, [rsp+0xC0]
0000796caedd68cc  vmovaps xmm14, [rsp+0xD0]
0000796caedd68d5  vmovaps xmm15, [rsp+0xE0]
0000796caedd68de  add rsp, 0xF0
0000796caedd68e5  pop r11
0000796caedd68e7  pop r10
0000796caedd68e9  pop r9
0000796caedd68eb  pop r8
0000796caedd68ed  pop rsi
0000796caedd68ee  pop rdi
0000796caedd68ef  pop rdx
0000796caedd68f0  pop rcx
0000796caedd68f1  pop rax
0000796caedd68f2  add rsp, 0x08
0000796caedd68f6  jmp 0x0000796CAEDD599A
0000796caedd68fb  sub rsp, 0x08
0000796caedd68ff  push rax
0000796caedd6900  push rcx
0000796caedd6901  push rdx
0000796caedd6902  push rdi
0000796caedd6903  push rsi
0000796caedd6904  push r8
0000796caedd6906  push r9
0000796caedd6908  push r10
0000796caedd690a  push r11
0000796caedd690c  sub rsp, 0xF0
0000796caedd6913  vmovaps [rsp], xmm0
0000796caedd6918  vmovaps [rsp+0x10], xmm1
0000796caedd691e  vmovaps [rsp+0x20], xmm2
0000796caedd6924  vmovaps [rsp+0x30], xmm3
0000796caedd692a  vmovaps [rsp+0x40], xmm4
0000796caedd6930  vmovaps [rsp+0x50], xmm5
0000796caedd6936  vmovaps [rsp+0x60], xmm6
0000796caedd693c  vmovaps [rsp+0x70], xmm8
0000796caedd6942  vmovaps [rsp+0x80], xmm9
0000796caedd694b  vmovaps [rsp+0x90], xmm10
0000796caedd6954  vmovaps [rsp+0xA0], xmm11
0000796caedd695d  vmovaps [rsp+0xB0], xmm12
0000796caedd6966  vmovaps [rsp+0xC0], xmm13
0000796caedd696f  vmovaps [rsp+0xD0], xmm14
0000796caedd6978  vmovaps [rsp+0xE0], xmm15
0000796caedd6981  sub rsp, 0x30
0000796caedd6985  movaps [rsp], xmm7
0000796caedd6989  movaps [rsp+0x10], xmm9
0000796caedd698f  movaps [rsp+0x20], xmm15
0000796caedd6995  lea rdi, [rsp]
0000796caedd6999  mov esi, 0x00
0000796caedd699e  mov rax, 0x56877063A530
0000796caedd69a8  call rax
0000796caedd69aa  movaps xmm7, [rsp]
0000796caedd69ae  add rsp, 0x30
0000796caedd69b2  vmovaps xmm0, [rsp]
0000796caedd69b7  vmovaps xmm1, [rsp+0x10]
0000796caedd69bd  vmovaps xmm2, [rsp+0x20]
0000796caedd69c3  vmovaps xmm3, [rsp+0x30]
0000796caedd69c9  vmovaps xmm4, [rsp+0x40]
0000796caedd69cf  vmovaps xmm5, [rsp+0x50]
0000796caedd69d5  vmovaps xmm6, [rsp+0x60]
0000796caedd69db  vmovaps xmm8, [rsp+0x70]
0000796caedd69e1  vmovaps xmm9, [rsp+0x80]
0000796caedd69ea  vmovaps xmm10, [rsp+0x90]
0000796caedd69f3  vmovaps xmm11, [rsp+0xA0]
0000796caedd69fc  vmovaps xmm12, [rsp+0xB0]
0000796caedd6a05  vmovaps xmm13, [rsp+0xC0]
0000796caedd6a0e  vmovaps xmm14, [rsp+0xD0]
0000796caedd6a17  vmovaps xmm15, [rsp+0xE0]
0000796caedd6a20  add rsp, 0xF0
0000796caedd6a27  pop r11
0000796caedd6a29  pop r10
0000796caedd6a2b  pop r9
0000796caedd6a2d  pop r8
0000796caedd6a2f  pop rsi
0000796caedd6a30  pop rdi
0000796caedd6a31  pop rdx
0000796caedd6a32  pop rcx
0000796caedd6a33  pop rax
0000796caedd6a34  add rsp, 0x08
0000796caedd6a38  jmp 0x0000796CAEDD59C8
0000796caedd6a3d  sub rsp, 0x08
0000796caedd6a41  push rax
0000796caedd6a42  push rcx
0000796caedd6a43  push rdx
0000796caedd6a44  push rdi
0000796caedd6a45  push rsi
0000796caedd6a46  push r8
0000796caedd6a48  push r9
0000796caedd6a4a  push r10
0000796caedd6a4c  push r11
0000796caedd6a4e  sub rsp, 0xF0
0000796caedd6a55  vmovaps [rsp], xmm0
0000796caedd6a5a  vmovaps [rsp+0x10], xmm1
0000796caedd6a60  vmovaps [rsp+0x20], xmm2
0000796caedd6a66  vmovaps [rsp+0x30], xmm3
0000796caedd6a6c  vmovaps [rsp+0x40], xmm4
0000796caedd6a72  vmovaps [rsp+0x50], xmm5
0000796caedd6a78  vmovaps [rsp+0x60], xmm6
0000796caedd6a7e  vmovaps [rsp+0x70], xmm7
0000796caedd6a84  vmovaps [rsp+0x80], xmm8
0000796caedd6a8d  vmovaps [rsp+0x90], xmm10
0000796caedd6a96  vmovaps [rsp+0xA0], xmm11
0000796caedd6a9f  vmovaps [rsp+0xB0], xmm12
0000796caedd6aa8  vmovaps [rsp+0xC0], xmm13
0000796caedd6ab1  vmovaps [rsp+0xD0], xmm14
0000796caedd6aba  vmovaps [rsp+0xE0], xmm15
0000796caedd6ac3  sub rsp, 0x30
0000796caedd6ac7  movaps [rsp], xmm9
0000796caedd6acc  movaps [rsp+0x10], xmm12
0000796caedd6ad2  movaps [rsp+0x20], xmm10
0000796caedd6ad8  lea rdi, [rsp]
0000796caedd6adc  mov esi, 0x00
0000796caedd6ae1  mov rax, 0x56877063A530
0000796caedd6aeb  call rax
0000796caedd6aed  movaps xmm9, [rsp]
0000796caedd6af2  add rsp, 0x30
0000796caedd6af6  vmovaps xmm0, [rsp]
0000796caedd6afb  vmovaps xmm1, [rsp+0x10]
0000796caedd6b01  vmovaps xmm2, [rsp+0x20]
0000796caedd6b07  vmovaps xmm3, [rsp+0x30]
0000796caedd6b0d  vmovaps xmm4, [rsp+0x40]
0000796caedd6b13  vmovaps xmm5, [rsp+0x50]
0000796caedd6b19  vmovaps xmm6, [rsp+0x60]
0000796caedd6b1f  vmovaps xmm7, [rsp+0x70]
0000796caedd6b25  vmovaps xmm8, [rsp+0x80]
0000796caedd6b2e  vmovaps xmm10, [rsp+0x90]
0000796caedd6b37  vmovaps xmm11, [rsp+0xA0]
0000796caedd6b40  vmovaps xmm12, [rsp+0xB0]
0000796caedd6b49  vmovaps xmm13, [rsp+0xC0]
0000796caedd6b52  vmovaps xmm14, [rsp+0xD0]
0000796caedd6b5b  vmovaps xmm15, [rsp+0xE0]
0000796caedd6b64  add rsp, 0xF0
0000796caedd6b6b  pop r11
0000796caedd6b6d  pop r10
0000796caedd6b6f  pop r9
0000796caedd6b71  pop r8
0000796caedd6b73  pop rsi
0000796caedd6b74  pop rdi
0000796caedd6b75  pop rdx
0000796caedd6b76  pop rcx
0000796caedd6b77  pop rax
0000796caedd6b78  add rsp, 0x08
0000796caedd6b7c  jmp 0x0000796CAEDD59EC
0000796caedd6b81  sub rsp, 0x08
0000796caedd6b85  push rax
0000796caedd6b86  push rcx
0000796caedd6b87  push rdx
0000796caedd6b88  push rdi
0000796caedd6b89  push rsi
0000796caedd6b8a  push r8
0000796caedd6b8c  push r9
0000796caedd6b8e  push r10
0000796caedd6b90  push r11
0000796caedd6b92  sub rsp, 0xF0
0000796caedd6b99  vmovaps [rsp], xmm0
0000796caedd6b9e  vmovaps [rsp+0x10], xmm1
0000796caedd6ba4  vmovaps [rsp+0x20], xmm2
0000796caedd6baa  vmovaps [rsp+0x30], xmm3
0000796caedd6bb0  vmovaps [rsp+0x40], xmm4
0000796caedd6bb6  vmovaps [rsp+0x50], xmm5
0000796caedd6bbc  vmovaps [rsp+0x60], xmm6
0000796caedd6bc2  vmovaps [rsp+0x70], xmm7
0000796caedd6bc8  vmovaps [rsp+0x80], xmm8
0000796caedd6bd1  vmovaps [rsp+0x90], xmm9
0000796caedd6bda  vmovaps [rsp+0xA0], xmm11
0000796caedd6be3  vmovaps [rsp+0xB0], xmm12
0000796caedd6bec  vmovaps [rsp+0xC0], xmm13
0000796caedd6bf5  vmovaps [rsp+0xD0], xmm14
0000796caedd6bfe  vmovaps [rsp+0xE0], xmm15
0000796caedd6c07  sub rsp, 0x30
0000796caedd6c0b  movaps [rsp], xmm10
0000796caedd6c10  movaps [rsp+0x10], xmm12
0000796caedd6c16  movaps [rsp+0x20], xmm11
0000796caedd6c1c  lea rdi, [rsp]
0000796caedd6c20  mov esi, 0x00
0000796caedd6c25  mov rax, 0x56877063A530
0000796caedd6c2f  call rax
0000796caedd6c31  movaps xmm10, [rsp]
0000796caedd6c36  add rsp, 0x30
0000796caedd6c3a  vmovaps xmm0, [rsp]
0000796caedd6c3f  vmovaps xmm1, [rsp+0x10]
0000796caedd6c45  vmovaps xmm2, [rsp+0x20]
0000796caedd6c4b  vmovaps xmm3, [rsp+0x30]
0000796caedd6c51  vmovaps xmm4, [rsp+0x40]
0000796caedd6c57  vmovaps xmm5, [rsp+0x50]
0000796caedd6c5d  vmovaps xmm6, [rsp+0x60]
0000796caedd6c63  vmovaps xmm7, [rsp+0x70]
0000796caedd6c69  vmovaps xmm8, [rsp+0x80]
0000796caedd6c72  vmovaps xmm9, [rsp+0x90]
0000796caedd6c7b  vmovaps xmm11, [rsp+0xA0]
0000796caedd6c84  vmovaps xmm12, [rsp+0xB0]
0000796caedd6c8d  vmovaps xmm13, [rsp+0xC0]
0000796caedd6c96  vmovaps xmm14, [rsp+0xD0]
0000796caedd6c9f  vmovaps xmm15, [rsp+0xE0]
0000796caedd6ca8  add rsp, 0xF0
0000796caedd6caf  pop r11
0000796caedd6cb1  pop r10
0000796caedd6cb3  pop r9
0000796caedd6cb5  pop r8
0000796caedd6cb7  pop rsi
0000796caedd6cb8  pop rdi
0000796caedd6cb9  pop rdx
0000796caedd6cba  pop rcx
0000796caedd6cbb  pop rax
0000796caedd6cbc  add rsp, 0x08
0000796caedd6cc0  jmp 0x0000796CAEDD5A06
0000796caedd6cc5  sub rsp, 0x08
0000796caedd6cc9  push rax
0000796caedd6cca  push rcx
0000796caedd6ccb  push rdx
0000796caedd6ccc  push rdi
0000796caedd6ccd  push rsi
0000796caedd6cce  push r8
0000796caedd6cd0  push r9
0000796caedd6cd2  push r10
0000796caedd6cd4  push r11
0000796caedd6cd6  sub rsp, 0xF0
0000796caedd6cdd  vmovaps [rsp], xmm0
0000796caedd6ce2  vmovaps [rsp+0x10], xmm1
0000796caedd6ce8  vmovaps [rsp+0x20], xmm2
0000796caedd6cee  vmovaps [rsp+0x30], xmm3
0000796caedd6cf4  vmovaps [rsp+0x40], xmm4
0000796caedd6cfa  vmovaps [rsp+0x50], xmm5
0000796caedd6d00  vmovaps [rsp+0x60], xmm7
0000796caedd6d06  vmovaps [rsp+0x70], xmm8
0000796caedd6d0c  vmovaps [rsp+0x80], xmm9
0000796caedd6d15  vmovaps [rsp+0x90], xmm10
0000796caedd6d1e  vmovaps [rsp+0xA0], xmm11
0000796caedd6d27  vmovaps [rsp+0xB0], xmm12
0000796caedd6d30  vmovaps [rsp+0xC0], xmm13
0000796caedd6d39  vmovaps [rsp+0xD0], xmm14
0000796caedd6d42  vmovaps [rsp+0xE0], xmm15
0000796caedd6d4b  sub rsp, 0x30
0000796caedd6d4f  movaps [rsp], xmm6
0000796caedd6d53  movaps [rsp+0x10], xmm12
0000796caedd6d59  movaps [rsp+0x20], xmm11
0000796caedd6d5f  lea rdi, [rsp]
0000796caedd6d63  mov esi, 0x00
0000796caedd6d68  mov rax, 0x56877063A530
0000796caedd6d72  call rax
0000796caedd6d74  movaps xmm6, [rsp]
0000796caedd6d78  add rsp, 0x30
0000796caedd6d7c  vmovaps xmm0, [rsp]
0000796caedd6d81  vmovaps xmm1, [rsp+0x10]
0000796caedd6d87  vmovaps xmm2, [rsp+0x20]
0000796caedd6d8d  vmovaps xmm3, [rsp+0x30]
0000796caedd6d93  vmovaps xmm4, [rsp+0x40]
0000796caedd6d99  vmovaps xmm5, [rsp+0x50]
0000796caedd6d9f  vmovaps xmm7, [rsp+0x60]
0000796caedd6da5  vmovaps xmm8, [rsp+0x70]
0000796caedd6dab  vmovaps xmm9, [rsp+0x80]
0000796caedd6db4  vmovaps xmm10, [rsp+0x90]
0000796caedd6dbd  vmovaps xmm11, [rsp+0xA0]
0000796caedd6dc6  vmovaps xmm12, [rsp+0xB0]
0000796caedd6dcf  vmovaps xmm13, [rsp+0xC0]
0000796caedd6dd8  vmovaps xmm14, [rsp+0xD0]
0000796caedd6de1  vmovaps xmm15, [rsp+0xE0]
0000796caedd6dea  add rsp, 0xF0
0000796caedd6df1  pop r11
0000796caedd6df3  pop r10
0000796caedd6df5  pop r9
0000796caedd6df7  pop r8
0000796caedd6df9  pop rsi
0000796caedd6dfa  pop rdi
0000796caedd6dfb  pop rdx
0000796caedd6dfc  pop rcx
0000796caedd6dfd  pop rax
0000796caedd6dfe  add rsp, 0x08
0000796caedd6e02  jmp 0x0000796CAEDD5A27
0000796caedd6e07  sub rsp, 0x08
0000796caedd6e0b  push rax
0000796caedd6e0c  push rcx
0000796caedd6e0d  push rdx
0000796caedd6e0e  push rdi
0000796caedd6e0f  push rsi
0000796caedd6e10  push r8
0000796caedd6e12  push r9
0000796caedd6e14  push r10
0000796caedd6e16  push r11
0000796caedd6e18  sub rsp, 0xF0
0000796caedd6e1f  vmovaps [rsp], xmm0
0000796caedd6e24  vmovaps [rsp+0x10], xmm1
0000796caedd6e2a  vmovaps [rsp+0x20], xmm2
0000796caedd6e30  vmovaps [rsp+0x30], xmm4
0000796caedd6e36  vmovaps [rsp+0x40], xmm5
0000796caedd6e3c  vmovaps [rsp+0x50], xmm6
0000796caedd6e42  vmovaps [rsp+0x60], xmm7
0000796caedd6e48  vmovaps [rsp+0x70], xmm8
0000796caedd6e4e  vmovaps [rsp+0x80], xmm9
0000796caedd6e57  vmovaps [rsp+0x90], xmm10
0000796caedd6e60  vmovaps [rsp+0xA0], xmm11
0000796caedd6e69  vmovaps [rsp+0xB0], xmm12
0000796caedd6e72  vmovaps [rsp+0xC0], xmm13
0000796caedd6e7b  vmovaps [rsp+0xD0], xmm14
0000796caedd6e84  vmovaps [rsp+0xE0], xmm15
0000796caedd6e8d  sub rsp, 0x30
0000796caedd6e91  movaps [rsp], xmm3
0000796caedd6e95  movaps [rsp+0x10], xmm5
0000796caedd6e9a  movaps [rsp+0x20], xmm4
0000796caedd6e9f  lea rdi, [rsp]
0000796caedd6ea3  mov esi, 0x00
0000796caedd6ea8  mov rax, 0x56877063A530
0000796caedd6eb2  call rax
0000796caedd6eb4  movaps xmm3, [rsp]
0000796caedd6eb8  add rsp, 0x30
0000796caedd6ebc  vmovaps xmm0, [rsp]
0000796caedd6ec1  vmovaps xmm1, [rsp+0x10]
0000796caedd6ec7  vmovaps xmm2, [rsp+0x20]
0000796caedd6ecd  vmovaps xmm4, [rsp+0x30]
0000796caedd6ed3  vmovaps xmm5, [rsp+0x40]
0000796caedd6ed9  vmovaps xmm6, [rsp+0x50]
0000796caedd6edf  vmovaps xmm7, [rsp+0x60]
0000796caedd6ee5  vmovaps xmm8, [rsp+0x70]
0000796caedd6eeb  vmovaps xmm9, [rsp+0x80]
0000796caedd6ef4  vmovaps xmm10, [rsp+0x90]
0000796caedd6efd  vmovaps xmm11, [rsp+0xA0]
0000796caedd6f06  vmovaps xmm12, [rsp+0xB0]
0000796caedd6f0f  vmovaps xmm13, [rsp+0xC0]
0000796caedd6f18  vmovaps xmm14, [rsp+0xD0]
0000796caedd6f21  vmovaps xmm15, [rsp+0xE0]
0000796caedd6f2a  add rsp, 0xF0
0000796caedd6f31  pop r11
0000796caedd6f33  pop r10
0000796caedd6f35  pop r9
0000796caedd6f37  pop r8
0000796caedd6f39  pop rsi
0000796caedd6f3a  pop rdi
0000796caedd6f3b  pop rdx
0000796caedd6f3c  pop rcx
0000796caedd6f3d  pop rax
0000796caedd6f3e  add rsp, 0x08
0000796caedd6f42  jmp 0x0000796CAEDD5A88
0000796caedd6f47  sub rsp, 0x08
0000796caedd6f4b  push rax
0000796caedd6f4c  push rcx
0000796caedd6f4d  push rdx
0000796caedd6f4e  push rdi
0000796caedd6f4f  push rsi
0000796caedd6f50  push r8
0000796caedd6f52  push r9
0000796caedd6f54  push r10
0000796caedd6f56  push r11
0000796caedd6f58  sub rsp, 0xF0
0000796caedd6f5f  vmovaps [rsp], xmm0
0000796caedd6f64  vmovaps [rsp+0x10], xmm1
0000796caedd6f6a  vmovaps [rsp+0x20], xmm2
0000796caedd6f70  vmovaps [rsp+0x30], xmm3
0000796caedd6f76  vmovaps [rsp+0x40], xmm4
0000796caedd6f7c  vmovaps [rsp+0x50], xmm6
0000796caedd6f82  vmovaps [rsp+0x60], xmm7
0000796caedd6f88  vmovaps [rsp+0x70], xmm8
0000796caedd6f8e  vmovaps [rsp+0x80], xmm9
0000796caedd6f97  vmovaps [rsp+0x90], xmm10
0000796caedd6fa0  vmovaps [rsp+0xA0], xmm11
0000796caedd6fa9  vmovaps [rsp+0xB0], xmm12
0000796caedd6fb2  vmovaps [rsp+0xC0], xmm13
0000796caedd6fbb  vmovaps [rsp+0xD0], xmm14
0000796caedd6fc4  vmovaps [rsp+0xE0], xmm15
0000796caedd6fcd  sub rsp, 0x30
0000796caedd6fd1  movaps [rsp], xmm5
0000796caedd6fd5  movaps [rsp+0x10], xmm8
0000796caedd6fdb  movaps [rsp+0x20], xmm15
0000796caedd6fe1  lea rdi, [rsp]
0000796caedd6fe5  mov esi, 0x00
0000796caedd6fea  mov rax, 0x56877063A530
0000796caedd6ff4  call rax
0000796caedd6ff6  movaps xmm5, [rsp]
0000796caedd6ffa  add rsp, 0x30
0000796caedd6ffe  vmovaps xmm0, [rsp]
0000796caedd7003  vmovaps xmm1, [rsp+0x10]
0000796caedd7009  vmovaps xmm2, [rsp+0x20]
0000796caedd700f  vmovaps xmm3, [rsp+0x30]
0000796caedd7015  vmovaps xmm4, [rsp+0x40]
0000796caedd701b  vmovaps xmm6, [rsp+0x50]
0000796caedd7021  vmovaps xmm7, [rsp+0x60]
0000796caedd7027  vmovaps xmm8, [rsp+0x70]
0000796caedd702d  vmovaps xmm9, [rsp+0x80]
0000796caedd7036  vmovaps xmm10, [rsp+0x90]
0000796caedd703f  vmovaps xmm11, [rsp+0xA0]
0000796caedd7048  vmovaps xmm12, [rsp+0xB0]
0000796caedd7051  vmovaps xmm13, [rsp+0xC0]
0000796caedd705a  vmovaps xmm14, [rsp+0xD0]
0000796caedd7063  vmovaps xmm15, [rsp+0xE0]
0000796caedd706c  add rsp, 0xF0
0000796caedd7073  pop r11
0000796caedd7075  pop r10
0000796caedd7077  pop r9
0000796caedd7079  pop r8
0000796caedd707b  pop rsi
0000796caedd707c  pop rdi
0000796caedd707d  pop rdx
0000796caedd707e  pop rcx
0000796caedd707f  pop rax
0000796caedd7080  add rsp, 0x08
0000796caedd7084  jmp 0x0000796CAEDD5AC0
0000796caedd7089  sub rsp, 0x08
0000796caedd708d  push rax
0000796caedd708e  push rcx
0000796caedd708f  push rdx
0000796caedd7090  push rdi
0000796caedd7091  push rsi
0000796caedd7092  push r8
0000796caedd7094  push r9
0000796caedd7096  push r10
0000796caedd7098  push r11
0000796caedd709a  sub rsp, 0xF0
0000796caedd70a1  vmovaps [rsp], xmm0
0000796caedd70a6  vmovaps [rsp+0x10], xmm1
0000796caedd70ac  vmovaps [rsp+0x20], xmm2
0000796caedd70b2  vmovaps [rsp+0x30], xmm3
0000796caedd70b8  vmovaps [rsp+0x40], xmm5
0000796caedd70be  vmovaps [rsp+0x50], xmm6
0000796caedd70c4  vmovaps [rsp+0x60], xmm7
0000796caedd70ca  vmovaps [rsp+0x70], xmm8
0000796caedd70d0  vmovaps [rsp+0x80], xmm9
0000796caedd70d9  vmovaps [rsp+0x90], xmm10
0000796caedd70e2  vmovaps [rsp+0xA0], xmm11
0000796caedd70eb  vmovaps [rsp+0xB0], xmm12
0000796caedd70f4  vmovaps [rsp+0xC0], xmm13
0000796caedd70fd  vmovaps [rsp+0xD0], xmm14
0000796caedd7106  vmovaps [rsp+0xE0], xmm15
0000796caedd710f  sub rsp, 0x30
0000796caedd7113  movaps [rsp], xmm4
0000796caedd7117  movaps [rsp+0x10], xmm9
0000796caedd711d  movaps [rsp+0x20], xmm8
0000796caedd7123  lea rdi, [rsp]
0000796caedd7127  mov esi, 0x00
0000796caedd712c  mov rax, 0x56877063A530
0000796caedd7136  call rax
0000796caedd7138  movaps xmm4, [rsp]
0000796caedd713c  add rsp, 0x30
0000796caedd7140  vmovaps xmm0, [rsp]
0000796caedd7145  vmovaps xmm1, [rsp+0x10]
0000796caedd714b  vmovaps xmm2, [rsp+0x20]
0000796caedd7151  vmovaps xmm3, [rsp+0x30]
0000796caedd7157  vmovaps xmm5, [rsp+0x40]
0000796caedd715d  vmovaps xmm6, [rsp+0x50]
0000796caedd7163  vmovaps xmm7, [rsp+0x60]
0000796caedd7169  vmovaps xmm8, [rsp+0x70]
0000796caedd716f  vmovaps xmm9, [rsp+0x80]
0000796caedd7178  vmovaps xmm10, [rsp+0x90]
0000796caedd7181  vmovaps xmm11, [rsp+0xA0]
0000796caedd718a  vmovaps xmm12, [rsp+0xB0]
0000796caedd7193  vmovaps xmm13, [rsp+0xC0]
0000796caedd719c  vmovaps xmm14, [rsp+0xD0]
0000796caedd71a5  vmovaps xmm15, [rsp+0xE0]
0000796caedd71ae  add rsp, 0xF0
0000796caedd71b5  pop r11
0000796caedd71b7  pop r10
0000796caedd71b9  pop r9
0000796caedd71bb  pop r8
0000796caedd71bd  pop rsi
0000796caedd71be  pop rdi
0000796caedd71bf  pop rdx
0000796caedd71c0  pop rcx
0000796caedd71c1  pop rax
0000796caedd71c2  add rsp, 0x08
0000796caedd71c6  jmp 0x0000796CAEDD5AE1
0000796caedd71cb  sub rsp, 0x08
0000796caedd71cf  push rax
0000796caedd71d0  push rcx
0000796caedd71d1  push rdx
0000796caedd71d2  push rdi
0000796caedd71d3  push rsi
0000796caedd71d4  push r8
0000796caedd71d6  push r9
0000796caedd71d8  push r10
0000796caedd71da  push r11
0000796caedd71dc  sub rsp, 0xF0
0000796caedd71e3  vmovaps [rsp], xmm0
0000796caedd71e8  vmovaps [rsp+0x10], xmm1
0000796caedd71ee  vmovaps [rsp+0x20], xmm2
0000796caedd71f4  vmovaps [rsp+0x30], xmm3
0000796caedd71fa  vmovaps [rsp+0x40], xmm4
0000796caedd7200  vmovaps [rsp+0x50], xmm5
0000796caedd7206  vmovaps [rsp+0x60], xmm6
0000796caedd720c  vmovaps [rsp+0x70], xmm7
0000796caedd7212  vmovaps [rsp+0x80], xmm8
0000796caedd721b  vmovaps [rsp+0x90], xmm10
0000796caedd7224  vmovaps [rsp+0xA0], xmm11
0000796caedd722d  vmovaps [rsp+0xB0], xmm12
0000796caedd7236  vmovaps [rsp+0xC0], xmm13
0000796caedd723f  vmovaps [rsp+0xD0], xmm14
0000796caedd7248  vmovaps [rsp+0xE0], xmm15
0000796caedd7251  sub rsp, 0x30
0000796caedd7255  movaps [rsp], xmm9
0000796caedd725a  movaps [rsp+0x10], xmm10
0000796caedd7260  movaps [rsp+0x20], xmm8
0000796caedd7266  lea rdi, [rsp]
0000796caedd726a  mov esi, 0x00
0000796caedd726f  mov rax, 0x56877063A530
0000796caedd7279  call rax
0000796caedd727b  movaps xmm9, [rsp]
0000796caedd7280  add rsp, 0x30
0000796caedd7284  vmovaps xmm0, [rsp]
0000796caedd7289  vmovaps xmm1, [rsp+0x10]
0000796caedd728f  vmovaps xmm2, [rsp+0x20]
0000796caedd7295  vmovaps xmm3, [rsp+0x30]
0000796caedd729b  vmovaps xmm4, [rsp+0x40]
0000796caedd72a1  vmovaps xmm5, [rsp+0x50]
0000796caedd72a7  vmovaps xmm6, [rsp+0x60]
0000796caedd72ad  vmovaps xmm7, [rsp+0x70]
0000796caedd72b3  vmovaps xmm8, [rsp+0x80]
0000796caedd72bc  vmovaps xmm10, [rsp+0x90]
0000796caedd72c5  vmovaps xmm11, [rsp+0xA0]
0000796caedd72ce  vmovaps xmm12, [rsp+0xB0]
0000796caedd72d7  vmovaps xmm13, [rsp+0xC0]
0000796caedd72e0  vmovaps xmm14, [rsp+0xD0]
0000796caedd72e9  vmovaps xmm15, [rsp+0xE0]
0000796caedd72f2  add rsp, 0xF0
0000796caedd72f9  pop r11
0000796caedd72fb  pop r10
0000796caedd72fd  pop r9
0000796caedd72ff  pop r8
0000796caedd7301  pop rsi
0000796caedd7302  pop rdi
0000796caedd7303  pop rdx
0000796caedd7304  pop rcx
0000796caedd7305  pop rax
0000796caedd7306  add rsp, 0x08
0000796caedd730a  jmp 0x0000796CAEDD5AFB
0000796caedd730f  call 0x0000796CAECD64F0
0000796caedd7314  jmp 0x0000796CAEDD5C15
0000796caedd7319  call 0x0000796CAECD64F0
0000796caedd731e  jmp 0x0000796CAEDD5C2B
0000796caedd7323  sub rsp, 0x08
0000796caedd7327  push rax
0000796caedd7328  push rcx
0000796caedd7329  push rdx
0000796caedd732a  push rdi
0000796caedd732b  push rsi
0000796caedd732c  push r8
0000796caedd732e  push r9
0000796caedd7330  push r10
0000796caedd7332  push r11
0000796caedd7334  sub rsp, 0xF0
0000796caedd733b  vmovaps [rsp], xmm0
0000796caedd7340  vmovaps [rsp+0x10], xmm2
0000796caedd7346  vmovaps [rsp+0x20], xmm3
0000796caedd734c  vmovaps [rsp+0x30], xmm4
0000796caedd7352  vmovaps [rsp+0x40], xmm5
0000796caedd7358  vmovaps [rsp+0x50], xmm6
0000796caedd735e  vmovaps [rsp+0x60], xmm7
0000796caedd7364  vmovaps [rsp+0x70], xmm8
0000796caedd736a  vmovaps [rsp+0x80], xmm9
0000796caedd7373  vmovaps [rsp+0x90], xmm10
0000796caedd737c  vmovaps [rsp+0xA0], xmm11
0000796caedd7385  vmovaps [rsp+0xB0], xmm12
0000796caedd738e  vmovaps [rsp+0xC0], xmm13
0000796caedd7397  vmovaps [rsp+0xD0], xmm14
0000796caedd73a0  vmovaps [rsp+0xE0], xmm15
0000796caedd73a9  sub rsp, 0x30
0000796caedd73ad  movaps [rsp], xmm1
0000796caedd73b1  movaps [rsp+0x10], xmm6
0000796caedd73b6  movaps [rsp+0x20], xmm15
0000796caedd73bc  lea rdi, [rsp]
0000796caedd73c0  mov esi, 0x00
0000796caedd73c5  mov rax, 0x56877063A530
0000796caedd73cf  call rax
0000796caedd73d1  movaps xmm1, [rsp]
0000796caedd73d5  add rsp, 0x30
0000796caedd73d9  vmovaps xmm0, [rsp]
0000796caedd73de  vmovaps xmm2, [rsp+0x10]
0000796caedd73e4  vmovaps xmm3, [rsp+0x20]
0000796caedd73ea  vmovaps xmm4, [rsp+0x30]
0000796caedd73f0  vmovaps xmm5, [rsp+0x40]
0000796caedd73f6  vmovaps xmm6, [rsp+0x50]
0000796caedd73fc  vmovaps xmm7, [rsp+0x60]
0000796caedd7402  vmovaps xmm8, [rsp+0x70]
0000796caedd7408  vmovaps xmm9, [rsp+0x80]
0000796caedd7411  vmovaps xmm10, [rsp+0x90]
0000796caedd741a  vmovaps xmm11, [rsp+0xA0]
0000796caedd7423  vmovaps xmm12, [rsp+0xB0]
0000796caedd742c  vmovaps xmm13, [rsp+0xC0]
0000796caedd7435  vmovaps xmm14, [rsp+0xD0]
0000796caedd743e  vmovaps xmm15, [rsp+0xE0]
0000796caedd7447  add rsp, 0xF0
0000796caedd744e  pop r11
0000796caedd7450  pop r10
0000796caedd7452  pop r9
0000796caedd7454  pop r8
0000796caedd7456  pop rsi
0000796caedd7457  pop rdi
0000796caedd7458  pop rdx
0000796caedd7459  pop rcx
0000796caedd745a  pop rax
0000796caedd745b  add rsp, 0x08
0000796caedd745f  jmp 0x0000796CAEDD5C68
0000796caedd7464  call 0x0000796CAECE5820
0000796caedd7469  jmp 0x0000796CAEDD5C75
0000796caedd746e  sub rsp, 0x08
0000796caedd7472  push rax
0000796caedd7473  push rcx
0000796caedd7474  push rdx
0000796caedd7475  push rdi
0000796caedd7476  push rsi
0000796caedd7477  push r8
0000796caedd7479  push r9
0000796caedd747b  push r10
0000796caedd747d  push r11
0000796caedd747f  sub rsp, 0xF0
0000796caedd7486  vmovaps [rsp], xmm0
0000796caedd748b  vmovaps [rsp+0x10], xmm1
0000796caedd7491  vmovaps [rsp+0x20], xmm2
0000796caedd7497  vmovaps [rsp+0x30], xmm3
0000796caedd749d  vmovaps [rsp+0x40], xmm4
0000796caedd74a3  vmovaps [rsp+0x50], xmm5
0000796caedd74a9  vmovaps [rsp+0x60], xmm6
0000796caedd74af  vmovaps [rsp+0x70], xmm7
0000796caedd74b5  vmovaps [rsp+0x80], xmm8
0000796caedd74be  vmovaps [rsp+0x90], xmm9
0000796caedd74c7  vmovaps [rsp+0xA0], xmm10
0000796caedd74d0  vmovaps [rsp+0xB0], xmm11
0000796caedd74d9  vmovaps [rsp+0xC0], xmm12
0000796caedd74e2  vmovaps [rsp+0xD0], xmm13
0000796caedd74eb  vmovaps [rsp+0xE0], xmm15
0000796caedd74f4  sub rsp, 0x30
0000796caedd74f8  movaps [rsp], xmm14
0000796caedd74fd  movaps [rsp+0x10], xmm4
0000796caedd7502  movaps [rsp+0x20], xmm3
0000796caedd7507  lea rdi, [rsp]
0000796caedd750b  mov esi, 0x00
0000796caedd7510  mov rax, 0x56877063A530
0000796caedd751a  call rax
0000796caedd751c  movaps xmm14, [rsp]
0000796caedd7521  add rsp, 0x30
0000796caedd7525  vmovaps xmm0, [rsp]
0000796caedd752a  vmovaps xmm1, [rsp+0x10]
0000796caedd7530  vmovaps xmm2, [rsp+0x20]
0000796caedd7536  vmovaps xmm3, [rsp+0x30]
0000796caedd753c  vmovaps xmm4, [rsp+0x40]
0000796caedd7542  vmovaps xmm5, [rsp+0x50]
0000796caedd7548  vmovaps xmm6, [rsp+0x60]
0000796caedd754e  vmovaps xmm7, [rsp+0x70]
0000796caedd7554  vmovaps xmm8, [rsp+0x80]
0000796caedd755d  vmovaps xmm9, [rsp+0x90]
0000796caedd7566  vmovaps xmm10, [rsp+0xA0]
0000796caedd756f  vmovaps xmm11, [rsp+0xB0]
0000796caedd7578  vmovaps xmm12, [rsp+0xC0]
0000796caedd7581  vmovaps xmm13, [rsp+0xD0]
0000796caedd758a  vmovaps xmm15, [rsp+0xE0]
0000796caedd7593  add rsp, 0xF0
0000796caedd759a  pop r11
0000796caedd759c  pop r10
0000796caedd759e  pop r9
0000796caedd75a0  pop r8
0000796caedd75a2  pop rsi
0000796caedd75a3  pop rdi
0000796caedd75a4  pop rdx
0000796caedd75a5  pop rcx
0000796caedd75a6  pop rax
0000796caedd75a7  add rsp, 0x08
0000796caedd75ab  jmp 0x0000796CAEDD5C8F
0000796caedd75b0  sub rsp, 0x08
0000796caedd75b4  push rax
0000796caedd75b5  push rcx
0000796caedd75b6  push rdx
0000796caedd75b7  push rdi
0000796caedd75b8  push rsi
0000796caedd75b9  push r8
0000796caedd75bb  push r9
0000796caedd75bd  push r10
0000796caedd75bf  push r11
0000796caedd75c1  sub rsp, 0xF0
0000796caedd75c8  vmovaps [rsp], xmm0
0000796caedd75cd  vmovaps [rsp+0x10], xmm1
0000796caedd75d3  vmovaps [rsp+0x20], xmm2
0000796caedd75d9  vmovaps [rsp+0x30], xmm3
0000796caedd75df  vmovaps [rsp+0x40], xmm4
0000796caedd75e5  vmovaps [rsp+0x50], xmm5
0000796caedd75eb  vmovaps [rsp+0x60], xmm7
0000796caedd75f1  vmovaps [rsp+0x70], xmm8
0000796caedd75f7  vmovaps [rsp+0x80], xmm9
0000796caedd7600  vmovaps [rsp+0x90], xmm10
0000796caedd7609  vmovaps [rsp+0xA0], xmm11
0000796caedd7612  vmovaps [rsp+0xB0], xmm12
0000796caedd761b  vmovaps [rsp+0xC0], xmm13
0000796caedd7624  vmovaps [rsp+0xD0], xmm14
0000796caedd762d  vmovaps [rsp+0xE0], xmm15
0000796caedd7636  sub rsp, 0x30
0000796caedd763a  movaps [rsp], xmm6
0000796caedd763e  movaps [rsp+0x10], xmm9
0000796caedd7644  movaps [rsp+0x20], xmm7
0000796caedd7649  lea rdi, [rsp]
0000796caedd764d  mov esi, 0x00
0000796caedd7652  mov rax, 0x56877063A530
0000796caedd765c  call rax
0000796caedd765e  movaps xmm6, [rsp]
0000796caedd7662  add rsp, 0x30
0000796caedd7666  vmovaps xmm0, [rsp]
0000796caedd766b  vmovaps xmm1, [rsp+0x10]
0000796caedd7671  vmovaps xmm2, [rsp+0x20]
0000796caedd7677  vmovaps xmm3, [rsp+0x30]
0000796caedd767d  vmovaps xmm4, [rsp+0x40]
0000796caedd7683  vmovaps xmm5, [rsp+0x50]
0000796caedd7689  vmovaps xmm7, [rsp+0x60]
0000796caedd768f  vmovaps xmm8, [rsp+0x70]
0000796caedd7695  vmovaps xmm9, [rsp+0x80]
0000796caedd769e  vmovaps xmm10, [rsp+0x90]
0000796caedd76a7  vmovaps xmm11, [rsp+0xA0]
0000796caedd76b0  vmovaps xmm12, [rsp+0xB0]
0000796caedd76b9  vmovaps xmm13, [rsp+0xC0]
0000796caedd76c2  vmovaps xmm14, [rsp+0xD0]
0000796caedd76cb  vmovaps xmm15, [rsp+0xE0]
0000796caedd76d4  add rsp, 0xF0
0000796caedd76db  pop r11
0000796caedd76dd  pop r10
0000796caedd76df  pop r9
0000796caedd76e1  pop r8
0000796caedd76e3  pop rsi
0000796caedd76e4  pop rdi
0000796caedd76e5  pop rdx
0000796caedd76e6  pop rcx
0000796caedd76e7  pop rax
0000796caedd76e8  add rsp, 0x08
0000796caedd76ec  jmp 0x0000796CAEDD5CA7
0000796caedd76f1  sub rsp, 0x08
0000796caedd76f5  push rax
0000796caedd76f6  push rcx
0000796caedd76f7  push rdx
0000796caedd76f8  push rdi
0000796caedd76f9  push rsi
0000796caedd76fa  push r8
0000796caedd76fc  push r9
0000796caedd76fe  push r10
0000796caedd7700  push r11
0000796caedd7702  sub rsp, 0xF0
0000796caedd7709  vmovaps [rsp], xmm0
0000796caedd770e  vmovaps [rsp+0x10], xmm1
0000796caedd7714  vmovaps [rsp+0x20], xmm2
0000796caedd771a  vmovaps [rsp+0x30], xmm3
0000796caedd7720  vmovaps [rsp+0x40], xmm4
0000796caedd7726  vmovaps [rsp+0x50], xmm5
0000796caedd772c  vmovaps [rsp+0x60], xmm6
0000796caedd7732  vmovaps [rsp+0x70], xmm8
0000796caedd7738  vmovaps [rsp+0x80], xmm9
0000796caedd7741  vmovaps [rsp+0x90], xmm10
0000796caedd774a  vmovaps [rsp+0xA0], xmm11
0000796caedd7753  vmovaps [rsp+0xB0], xmm12
0000796caedd775c  vmovaps [rsp+0xC0], xmm13
0000796caedd7765  vmovaps [rsp+0xD0], xmm14
0000796caedd776e  vmovaps [rsp+0xE0], xmm15
0000796caedd7777  sub rsp, 0x30
0000796caedd777b  movaps [rsp], xmm7
0000796caedd777f  movaps [rsp+0x10], xmm4
0000796caedd7784  movaps [rsp+0x20], xmm9
0000796caedd778a  lea rdi, [rsp]
0000796caedd778e  mov esi, 0x00
0000796caedd7793  mov rax, 0x56877063A530
0000796caedd779d  call rax
0000796caedd779f  movaps xmm7, [rsp]
0000796caedd77a3  add rsp, 0x30
0000796caedd77a7  vmovaps xmm0, [rsp]
0000796caedd77ac  vmovaps xmm1, [rsp+0x10]
0000796caedd77b2  vmovaps xmm2, [rsp+0x20]
0000796caedd77b8  vmovaps xmm3, [rsp+0x30]
0000796caedd77be  vmovaps xmm4, [rsp+0x40]
0000796caedd77c4  vmovaps xmm5, [rsp+0x50]
0000796caedd77ca  vmovaps xmm6, [rsp+0x60]
0000796caedd77d0  vmovaps xmm8, [rsp+0x70]
0000796caedd77d6  vmovaps xmm9, [rsp+0x80]
0000796caedd77df  vmovaps xmm10, [rsp+0x90]
0000796caedd77e8  vmovaps xmm11, [rsp+0xA0]
0000796caedd77f1  vmovaps xmm12, [rsp+0xB0]
0000796caedd77fa  vmovaps xmm13, [rsp+0xC0]
0000796caedd7803  vmovaps xmm14, [rsp+0xD0]
0000796caedd780c  vmovaps xmm15, [rsp+0xE0]
0000796caedd7815  add rsp, 0xF0
0000796caedd781c  pop r11
0000796caedd781e  pop r10
0000796caedd7820  pop r9
0000796caedd7822  pop r8
0000796caedd7824  pop rsi
0000796caedd7825  pop rdi
0000796caedd7826  pop rdx
0000796caedd7827  pop rcx
0000796caedd7828  pop rax
0000796caedd7829  add rsp, 0x08
0000796caedd782d  jmp 0x0000796CAEDD5CD4
0000796caedd7832  sub rsp, 0x08
0000796caedd7836  push rax
0000796caedd7837  push rcx
0000796caedd7838  push rdx
0000796caedd7839  push rdi
0000796caedd783a  push rsi
0000796caedd783b  push r8
0000796caedd783d  push r9
0000796caedd783f  push r10
0000796caedd7841  push r11
0000796caedd7843  sub rsp, 0xF0
0000796caedd784a  vmovaps [rsp], xmm0
0000796caedd784f  vmovaps [rsp+0x10], xmm1
0000796caedd7855  vmovaps [rsp+0x20], xmm2
0000796caedd785b  vmovaps [rsp+0x30], xmm3
0000796caedd7861  vmovaps [rsp+0x40], xmm5
0000796caedd7867  vmovaps [rsp+0x50], xmm6
0000796caedd786d  vmovaps [rsp+0x60], xmm7
0000796caedd7873  vmovaps [rsp+0x70], xmm8
0000796caedd7879  vmovaps [rsp+0x80], xmm9
0000796caedd7882  vmovaps [rsp+0x90], xmm10
0000796caedd788b  vmovaps [rsp+0xA0], xmm11
0000796caedd7894  vmovaps [rsp+0xB0], xmm12
0000796caedd789d  vmovaps [rsp+0xC0], xmm13
0000796caedd78a6  vmovaps [rsp+0xD0], xmm14
0000796caedd78af  vmovaps [rsp+0xE0], xmm15
0000796caedd78b8  sub rsp, 0x30
0000796caedd78bc  movaps [rsp], xmm4
0000796caedd78c0  movaps [rsp+0x10], xmm15
0000796caedd78c6  movaps [rsp+0x20], xmm9
0000796caedd78cc  lea rdi, [rsp]
0000796caedd78d0  mov esi, 0x00
0000796caedd78d5  mov rax, 0x56877063A530
0000796caedd78df  call rax
0000796caedd78e1  movaps xmm4, [rsp]
0000796caedd78e5  add rsp, 0x30
0000796caedd78e9  vmovaps xmm0, [rsp]
0000796caedd78ee  vmovaps xmm1, [rsp+0x10]
0000796caedd78f4  vmovaps xmm2, [rsp+0x20]
0000796caedd78fa  vmovaps xmm3, [rsp+0x30]
0000796caedd7900  vmovaps xmm5, [rsp+0x40]
0000796caedd7906  vmovaps xmm6, [rsp+0x50]
0000796caedd790c  vmovaps xmm7, [rsp+0x60]
0000796caedd7912  vmovaps xmm8, [rsp+0x70]
0000796caedd7918  vmovaps xmm9, [rsp+0x80]
0000796caedd7921  vmovaps xmm10, [rsp+0x90]
0000796caedd792a  vmovaps xmm11, [rsp+0xA0]
0000796caedd7933  vmovaps xmm12, [rsp+0xB0]
0000796caedd793c  vmovaps xmm13, [rsp+0xC0]
0000796caedd7945  vmovaps xmm14, [rsp+0xD0]
0000796caedd794e  vmovaps xmm15, [rsp+0xE0]
0000796caedd7957  add rsp, 0xF0
0000796caedd795e  pop r11
0000796caedd7960  pop r10
0000796caedd7962  pop r9
0000796caedd7964  pop r8
0000796caedd7966  pop rsi
0000796caedd7967  pop rdi
0000796caedd7968  pop rdx
0000796caedd7969  pop rcx
0000796caedd796a  pop rax
0000796caedd796b  add rsp, 0x08
0000796caedd796f  jmp 0x0000796CAEDD5CF9
0000796caedd7974  call 0x0000796CAECE5820
0000796caedd7979  jmp 0x0000796CAEDD5D06
0000796caedd797e  sub rsp, 0x08
0000796caedd7982  push rax
0000796caedd7983  push rcx
0000796caedd7984  push rdx
0000796caedd7985  push rdi
0000796caedd7986  push rsi
0000796caedd7987  push r8
0000796caedd7989  push r9
0000796caedd798b  push r10
0000796caedd798d  push r11
0000796caedd798f  sub rsp, 0xF0
0000796caedd7996  vmovaps [rsp], xmm0
0000796caedd799b  vmovaps [rsp+0x10], xmm1
0000796caedd79a1  vmovaps [rsp+0x20], xmm2
0000796caedd79a7  vmovaps [rsp+0x30], xmm4
0000796caedd79ad  vmovaps [rsp+0x40], xmm5
0000796caedd79b3  vmovaps [rsp+0x50], xmm6
0000796caedd79b9  vmovaps [rsp+0x60], xmm7
0000796caedd79bf  vmovaps [rsp+0x70], xmm8
0000796caedd79c5  vmovaps [rsp+0x80], xmm9
0000796caedd79ce  vmovaps [rsp+0x90], xmm10
0000796caedd79d7  vmovaps [rsp+0xA0], xmm11
0000796caedd79e0  vmovaps [rsp+0xB0], xmm12
0000796caedd79e9  vmovaps [rsp+0xC0], xmm13
0000796caedd79f2  vmovaps [rsp+0xD0], xmm14
0000796caedd79fb  vmovaps [rsp+0xE0], xmm15
0000796caedd7a04  sub rsp, 0x30
0000796caedd7a08  movaps [rsp], xmm3
0000796caedd7a0c  movaps [rsp+0x10], xmm1
0000796caedd7a11  movaps [rsp+0x20], xmm9
0000796caedd7a17  lea rdi, [rsp]
0000796caedd7a1b  mov esi, 0x00
0000796caedd7a20  mov rax, 0x56877063A530
0000796caedd7a2a  call rax
0000796caedd7a2c  movaps xmm3, [rsp]
0000796caedd7a30  add rsp, 0x30
0000796caedd7a34  vmovaps xmm0, [rsp]
0000796caedd7a39  vmovaps xmm1, [rsp+0x10]
0000796caedd7a3f  vmovaps xmm2, [rsp+0x20]
0000796caedd7a45  vmovaps xmm4, [rsp+0x30]
0000796caedd7a4b  vmovaps xmm5, [rsp+0x40]
0000796caedd7a51  vmovaps xmm6, [rsp+0x50]
0000796caedd7a57  vmovaps xmm7, [rsp+0x60]
0000796caedd7a5d  vmovaps xmm8, [rsp+0x70]
0000796caedd7a63  vmovaps xmm9, [rsp+0x80]
0000796caedd7a6c  vmovaps xmm10, [rsp+0x90]
0000796caedd7a75  vmovaps xmm11, [rsp+0xA0]
0000796caedd7a7e  vmovaps xmm12, [rsp+0xB0]
0000796caedd7a87  vmovaps xmm13, [rsp+0xC0]
0000796caedd7a90  vmovaps xmm14, [rsp+0xD0]
0000796caedd7a99  vmovaps xmm15, [rsp+0xE0]
0000796caedd7aa2  add rsp, 0xF0
0000796caedd7aa9  pop r11
0000796caedd7aab  pop r10
0000796caedd7aad  pop r9
0000796caedd7aaf  pop r8
0000796caedd7ab1  pop rsi
0000796caedd7ab2  pop rdi
0000796caedd7ab3  pop rdx
0000796caedd7ab4  pop rcx
0000796caedd7ab5  pop rax
0000796caedd7ab6  add rsp, 0x08
0000796caedd7aba  jmp 0x0000796CAEDD5D43
0000796caedd7abf  sub rsp, 0x08
0000796caedd7ac3  push rax
0000796caedd7ac4  push rcx
0000796caedd7ac5  push rdx
0000796caedd7ac6  push rdi
0000796caedd7ac7  push rsi
0000796caedd7ac8  push r8
0000796caedd7aca  push r9
0000796caedd7acc  push r10
0000796caedd7ace  push r11
0000796caedd7ad0  sub rsp, 0xF0
0000796caedd7ad7  vmovaps [rsp], xmm0
0000796caedd7adc  vmovaps [rsp+0x10], xmm2
0000796caedd7ae2  vmovaps [rsp+0x20], xmm3
0000796caedd7ae8  vmovaps [rsp+0x30], xmm4
0000796caedd7aee  vmovaps [rsp+0x40], xmm5
0000796caedd7af4  vmovaps [rsp+0x50], xmm6
0000796caedd7afa  vmovaps [rsp+0x60], xmm7
0000796caedd7b00  vmovaps [rsp+0x70], xmm8
0000796caedd7b06  vmovaps [rsp+0x80], xmm9
0000796caedd7b0f  vmovaps [rsp+0x90], xmm10
0000796caedd7b18  vmovaps [rsp+0xA0], xmm11
0000796caedd7b21  vmovaps [rsp+0xB0], xmm12
0000796caedd7b2a  vmovaps [rsp+0xC0], xmm13
0000796caedd7b33  vmovaps [rsp+0xD0], xmm14
0000796caedd7b3c  vmovaps [rsp+0xE0], xmm15
0000796caedd7b45  sub rsp, 0x30
0000796caedd7b49  movaps [rsp], xmm1
0000796caedd7b4d  movaps [rsp+0x10], xmm15
0000796caedd7b53  movaps [rsp+0x20], xmm9
0000796caedd7b59  lea rdi, [rsp]
0000796caedd7b5d  mov esi, 0x00
0000796caedd7b62  mov rax, 0x56877063A530
0000796caedd7b6c  call rax
0000796caedd7b6e  movaps xmm1, [rsp]
0000796caedd7b72  add rsp, 0x30
0000796caedd7b76  vmovaps xmm0, [rsp]
0000796caedd7b7b  vmovaps xmm2, [rsp+0x10]
0000796caedd7b81  vmovaps xmm3, [rsp+0x20]
0000796caedd7b87  vmovaps xmm4, [rsp+0x30]
0000796caedd7b8d  vmovaps xmm5, [rsp+0x40]
0000796caedd7b93  vmovaps xmm6, [rsp+0x50]
0000796caedd7b99  vmovaps xmm7, [rsp+0x60]
0000796caedd7b9f  vmovaps xmm8, [rsp+0x70]
0000796caedd7ba5  vmovaps xmm9, [rsp+0x80]
0000796caedd7bae  vmovaps xmm10, [rsp+0x90]
0000796caedd7bb7  vmovaps xmm11, [rsp+0xA0]
0000796caedd7bc0  vmovaps xmm12, [rsp+0xB0]
0000796caedd7bc9  vmovaps xmm13, [rsp+0xC0]
0000796caedd7bd2  vmovaps xmm14, [rsp+0xD0]
0000796caedd7bdb  vmovaps xmm15, [rsp+0xE0]
0000796caedd7be4  add rsp, 0xF0
0000796caedd7beb  pop r11
0000796caedd7bed  pop r10
0000796caedd7bef  pop r9
0000796caedd7bf1  pop r8
0000796caedd7bf3  pop rsi
0000796caedd7bf4  pop rdi
0000796caedd7bf5  pop rdx
0000796caedd7bf6  pop rcx
0000796caedd7bf7  pop rax
0000796caedd7bf8  add rsp, 0x08
0000796caedd7bfc  jmp 0x0000796CAEDD5DCB
0000796caedd7c01  call 0x0000796CAECE5820
0000796caedd7c06  jmp 0x0000796CAEDD5DD8
0000796caedd7c0b  sub rsp, 0x08
0000796caedd7c0f  push rax
0000796caedd7c10  push rcx
0000796caedd7c11  push rdx
0000796caedd7c12  push rdi
0000796caedd7c13  push rsi
0000796caedd7c14  push r8
0000796caedd7c16  push r9
0000796caedd7c18  push r10
0000796caedd7c1a  push r11
0000796caedd7c1c  sub rsp, 0xF0
0000796caedd7c23  vmovaps [rsp], xmm0
0000796caedd7c28  vmovaps [rsp+0x10], xmm2
0000796caedd7c2e  vmovaps [rsp+0x20], xmm3
0000796caedd7c34  vmovaps [rsp+0x30], xmm4
0000796caedd7c3a  vmovaps [rsp+0x40], xmm5
0000796caedd7c40  vmovaps [rsp+0x50], xmm6
0000796caedd7c46  vmovaps [rsp+0x60], xmm7
0000796caedd7c4c  vmovaps [rsp+0x70], xmm8
0000796caedd7c52  vmovaps [rsp+0x80], xmm9
0000796caedd7c5b  vmovaps [rsp+0x90], xmm10
0000796caedd7c64  vmovaps [rsp+0xA0], xmm11
0000796caedd7c6d  vmovaps [rsp+0xB0], xmm12
0000796caedd7c76  vmovaps [rsp+0xC0], xmm13
0000796caedd7c7f  vmovaps [rsp+0xD0], xmm14
0000796caedd7c88  vmovaps [rsp+0xE0], xmm15
0000796caedd7c91  sub rsp, 0x30
0000796caedd7c95  movaps [rsp], xmm1
0000796caedd7c99  movaps [rsp+0x10], xmm5
0000796caedd7c9e  movaps [rsp+0x20], xmm7
0000796caedd7ca3  lea rdi, [rsp]
0000796caedd7ca7  mov esi, 0x00
0000796caedd7cac  mov rax, 0x56877063A530
0000796caedd7cb6  call rax
0000796caedd7cb8  movaps xmm1, [rsp]
0000796caedd7cbc  add rsp, 0x30
0000796caedd7cc0  vmovaps xmm0, [rsp]
0000796caedd7cc5  vmovaps xmm2, [rsp+0x10]
0000796caedd7ccb  vmovaps xmm3, [rsp+0x20]
0000796caedd7cd1  vmovaps xmm4, [rsp+0x30]
0000796caedd7cd7  vmovaps xmm5, [rsp+0x40]
0000796caedd7cdd  vmovaps xmm6, [rsp+0x50]
0000796caedd7ce3  vmovaps xmm7, [rsp+0x60]
0000796caedd7ce9  vmovaps xmm8, [rsp+0x70]
0000796caedd7cef  vmovaps xmm9, [rsp+0x80]
0000796caedd7cf8  vmovaps xmm10, [rsp+0x90]
0000796caedd7d01  vmovaps xmm11, [rsp+0xA0]
0000796caedd7d0a  vmovaps xmm12, [rsp+0xB0]
0000796caedd7d13  vmovaps xmm13, [rsp+0xC0]
0000796caedd7d1c  vmovaps xmm14, [rsp+0xD0]
0000796caedd7d25  vmovaps xmm15, [rsp+0xE0]
0000796caedd7d2e  add rsp, 0xF0
0000796caedd7d35  pop r11
0000796caedd7d37  pop r10
0000796caedd7d39  pop r9
0000796caedd7d3b  pop r8
0000796caedd7d3d  pop rsi
0000796caedd7d3e  pop rdi
0000796caedd7d3f  pop rdx
0000796caedd7d40  pop rcx
0000796caedd7d41  pop rax
0000796caedd7d42  add rsp, 0x08
0000796caedd7d46  jmp 0x0000796CAEDD5E7D
0000796caedd7d4b  sub rsp, 0x08
0000796caedd7d4f  push rax
0000796caedd7d50  push rcx
0000796caedd7d51  push rdx
0000796caedd7d52  push rdi
0000796caedd7d53  push rsi
0000796caedd7d54  push r8
0000796caedd7d56  push r9
0000796caedd7d58  push r10
0000796caedd7d5a  push r11
0000796caedd7d5c  sub rsp, 0xF0
0000796caedd7d63  vmovaps [rsp], xmm0
0000796caedd7d68  vmovaps [rsp+0x10], xmm1
0000796caedd7d6e  vmovaps [rsp+0x20], xmm2
0000796caedd7d74  vmovaps [rsp+0x30], xmm3
0000796caedd7d7a  vmovaps [rsp+0x40], xmm4
0000796caedd7d80  vmovaps [rsp+0x50], xmm5
0000796caedd7d86  vmovaps [rsp+0x60], xmm6
0000796caedd7d8c  vmovaps [rsp+0x70], xmm8
0000796caedd7d92  vmovaps [rsp+0x80], xmm9
0000796caedd7d9b  vmovaps [rsp+0x90], xmm10
0000796caedd7da4  vmovaps [rsp+0xA0], xmm11
0000796caedd7dad  vmovaps [rsp+0xB0], xmm12
0000796caedd7db6  vmovaps [rsp+0xC0], xmm13
0000796caedd7dbf  vmovaps [rsp+0xD0], xmm14
0000796caedd7dc8  vmovaps [rsp+0xE0], xmm15
0000796caedd7dd1  sub rsp, 0x30
0000796caedd7dd5  movaps [rsp], xmm7
0000796caedd7dd9  movaps [rsp+0x10], xmm5
0000796caedd7dde  movaps [rsp+0x20], xmm15
0000796caedd7de4  lea rdi, [rsp]
0000796caedd7de8  mov esi, 0x00
0000796caedd7ded  mov rax, 0x56877063A530
0000796caedd7df7  call rax
0000796caedd7df9  movaps xmm7, [rsp]
0000796caedd7dfd  add rsp, 0x30
0000796caedd7e01  vmovaps xmm0, [rsp]
0000796caedd7e06  vmovaps xmm1, [rsp+0x10]
0000796caedd7e0c  vmovaps xmm2, [rsp+0x20]
0000796caedd7e12  vmovaps xmm3, [rsp+0x30]
0000796caedd7e18  vmovaps xmm4, [rsp+0x40]
0000796caedd7e1e  vmovaps xmm5, [rsp+0x50]
0000796caedd7e24  vmovaps xmm6, [rsp+0x60]
0000796caedd7e2a  vmovaps xmm8, [rsp+0x70]
0000796caedd7e30  vmovaps xmm9, [rsp+0x80]
0000796caedd7e39  vmovaps xmm10, [rsp+0x90]
0000796caedd7e42  vmovaps xmm11, [rsp+0xA0]
0000796caedd7e4b  vmovaps xmm12, [rsp+0xB0]
0000796caedd7e54  vmovaps xmm13, [rsp+0xC0]
0000796caedd7e5d  vmovaps xmm14, [rsp+0xD0]
0000796caedd7e66  vmovaps xmm15, [rsp+0xE0]
0000796caedd7e6f  add rsp, 0xF0
0000796caedd7e76  pop r11
0000796caedd7e78  pop r10
0000796caedd7e7a  pop r9
0000796caedd7e7c  pop r8
0000796caedd7e7e  pop rsi
0000796caedd7e7f  pop rdi
0000796caedd7e80  pop rdx
0000796caedd7e81  pop rcx
0000796caedd7e82  pop rax
0000796caedd7e83  add rsp, 0x08
0000796caedd7e87  jmp 0x0000796CAEDD5EB3
0000796caedd7e8c  call 0x0000796CAECD64F0
0000796caedd7e91  jmp 0x0000796CAEDD5EC0
0000796caedd7e96  sub rsp, 0x08
0000796caedd7e9a  push rax
0000796caedd7e9b  push rcx
0000796caedd7e9c  push rdx
0000796caedd7e9d  push rdi
0000796caedd7e9e  push rsi
0000796caedd7e9f  push r8
0000796caedd7ea1  push r9
0000796caedd7ea3  push r10
0000796caedd7ea5  push r11
0000796caedd7ea7  sub rsp, 0xF0
0000796caedd7eae  vmovaps [rsp], xmm0
0000796caedd7eb3  vmovaps [rsp+0x10], xmm1
0000796caedd7eb9  vmovaps [rsp+0x20], xmm2
0000796caedd7ebf  vmovaps [rsp+0x30], xmm3
0000796caedd7ec5  vmovaps [rsp+0x40], xmm4
0000796caedd7ecb  vmovaps [rsp+0x50], xmm5
0000796caedd7ed1  vmovaps [rsp+0x60], xmm6
0000796caedd7ed7  vmovaps [rsp+0x70], xmm7
0000796caedd7edd  vmovaps [rsp+0x80], xmm8
0000796caedd7ee6  vmovaps [rsp+0x90], xmm9
0000796caedd7eef  vmovaps [rsp+0xA0], xmm10
0000796caedd7ef8  vmovaps [rsp+0xB0], xmm11
0000796caedd7f01  vmovaps [rsp+0xC0], xmm12
0000796caedd7f0a  vmovaps [rsp+0xD0], xmm13
0000796caedd7f13  vmovaps [rsp+0xE0], xmm14
0000796caedd7f1c  sub rsp, 0x30
0000796caedd7f20  movaps [rsp], xmm15
0000796caedd7f25  movaps [rsp+0x10], xmm5
0000796caedd7f2a  movaps [rsp+0x20], xmm3
0000796caedd7f2f  lea rdi, [rsp]
0000796caedd7f33  mov esi, 0x00
0000796caedd7f38  mov rax, 0x56877063A530
0000796caedd7f42  call rax
0000796caedd7f44  movaps xmm15, [rsp]
0000796caedd7f49  add rsp, 0x30
0000796caedd7f4d  vmovaps xmm0, [rsp]
0000796caedd7f52  vmovaps xmm1, [rsp+0x10]
0000796caedd7f58  vmovaps xmm2, [rsp+0x20]
0000796caedd7f5e  vmovaps xmm3, [rsp+0x30]
0000796caedd7f64  vmovaps xmm4, [rsp+0x40]
0000796caedd7f6a  vmovaps xmm5, [rsp+0x50]
0000796caedd7f70  vmovaps xmm6, [rsp+0x60]
0000796caedd7f76  vmovaps xmm7, [rsp+0x70]
0000796caedd7f7c  vmovaps xmm8, [rsp+0x80]
0000796caedd7f85  vmovaps xmm9, [rsp+0x90]
0000796caedd7f8e  vmovaps xmm10, [rsp+0xA0]
0000796caedd7f97  vmovaps xmm11, [rsp+0xB0]
0000796caedd7fa0  vmovaps xmm12, [rsp+0xC0]
0000796caedd7fa9  vmovaps xmm13, [rsp+0xD0]
0000796caedd7fb2  vmovaps xmm14, [rsp+0xE0]
0000796caedd7fbb  add rsp, 0xF0
0000796caedd7fc2  pop r11
0000796caedd7fc4  pop r10
0000796caedd7fc6  pop r9
0000796caedd7fc8  pop r8
0000796caedd7fca  pop rsi
0000796caedd7fcb  pop rdi
0000796caedd7fcc  pop rdx
0000796caedd7fcd  pop rcx
0000796caedd7fce  pop rax
0000796caedd7fcf  add rsp, 0x08
0000796caedd7fd3  jmp 0x0000796CAEDD5EE6
0000796caedd7fd8  sub rsp, 0x08
0000796caedd7fdc  push rax
0000796caedd7fdd  push rcx
0000796caedd7fde  push rdx
0000796caedd7fdf  push rdi
0000796caedd7fe0  push rsi
0000796caedd7fe1  push r8
0000796caedd7fe3  push r9
0000796caedd7fe5  push r10
0000796caedd7fe7  push r11
0000796caedd7fe9  sub rsp, 0xF0
0000796caedd7ff0  vmovaps [rsp], xmm0
0000796caedd7ff5  vmovaps [rsp+0x10], xmm2
0000796caedd7ffb  vmovaps [rsp+0x20], xmm3
0000796caedd8001  vmovaps [rsp+0x30], xmm4
0000796caedd8007  vmovaps [rsp+0x40], xmm5
0000796caedd800d  vmovaps [rsp+0x50], xmm6
0000796caedd8013  vmovaps [rsp+0x60], xmm7
0000796caedd8019  vmovaps [rsp+0x70], xmm8
0000796caedd801f  vmovaps [rsp+0x80], xmm9
0000796caedd8028  vmovaps [rsp+0x90], xmm10
0000796caedd8031  vmovaps [rsp+0xA0], xmm11
0000796caedd803a  vmovaps [rsp+0xB0], xmm12
0000796caedd8043  vmovaps [rsp+0xC0], xmm13
0000796caedd804c  vmovaps [rsp+0xD0], xmm14
0000796caedd8055  vmovaps [rsp+0xE0], xmm15
0000796caedd805e  sub rsp, 0x30
0000796caedd8062  movaps [rsp], xmm1
0000796caedd8066  movaps [rsp+0x10], xmm5
0000796caedd806b  movaps [rsp+0x20], xmm4
0000796caedd8070  lea rdi, [rsp]
0000796caedd8074  mov esi, 0x00
0000796caedd8079  mov rax, 0x56877063A530
0000796caedd8083  call rax
0000796caedd8085  movaps xmm1, [rsp]
0000796caedd8089  add rsp, 0x30
0000796caedd808d  vmovaps xmm0, [rsp]
0000796caedd8092  vmovaps xmm2, [rsp+0x10]
0000796caedd8098  vmovaps xmm3, [rsp+0x20]
0000796caedd809e  vmovaps xmm4, [rsp+0x30]
0000796caedd80a4  vmovaps xmm5, [rsp+0x40]
0000796caedd80aa  vmovaps xmm6, [rsp+0x50]
0000796caedd80b0  vmovaps xmm7, [rsp+0x60]
0000796caedd80b6  vmovaps xmm8, [rsp+0x70]
0000796caedd80bc  vmovaps xmm9, [rsp+0x80]
0000796caedd80c5  vmovaps xmm10, [rsp+0x90]
0000796caedd80ce  vmovaps xmm11, [rsp+0xA0]
0000796caedd80d7  vmovaps xmm12, [rsp+0xB0]
0000796caedd80e0  vmovaps xmm13, [rsp+0xC0]
0000796caedd80e9  vmovaps xmm14, [rsp+0xD0]
0000796caedd80f2  vmovaps xmm15, [rsp+0xE0]
0000796caedd80fb  add rsp, 0xF0
0000796caedd8102  pop r11
0000796caedd8104  pop r10
0000796caedd8106  pop r9
0000796caedd8108  pop r8
0000796caedd810a  pop rsi
0000796caedd810b  pop rdi
0000796caedd810c  pop rdx
0000796caedd810d  pop rcx
0000796caedd810e  pop rax
0000796caedd810f  add rsp, 0x08
0000796caedd8113  jmp 0x0000796CAEDD5F06
0000796caedd8118  sub rsp, 0x08
0000796caedd811c  push rax
0000796caedd811d  push rcx
0000796caedd811e  push rdx
0000796caedd811f  push rdi
0000796caedd8120  push rsi
0000796caedd8121  push r8
0000796caedd8123  push r9
0000796caedd8125  push r10
0000796caedd8127  push r11
0000796caedd8129  sub rsp, 0xF0
0000796caedd8130  vmovaps [rsp], xmm0
0000796caedd8135  vmovaps [rsp+0x10], xmm1
0000796caedd813b  vmovaps [rsp+0x20], xmm2
0000796caedd8141  vmovaps [rsp+0x30], xmm3
0000796caedd8147  vmovaps [rsp+0x40], xmm5
0000796caedd814d  vmovaps [rsp+0x50], xmm6
0000796caedd8153  vmovaps [rsp+0x60], xmm7
0000796caedd8159  vmovaps [rsp+0x70], xmm8
0000796caedd815f  vmovaps [rsp+0x80], xmm9
0000796caedd8168  vmovaps [rsp+0x90], xmm10
0000796caedd8171  vmovaps [rsp+0xA0], xmm11
0000796caedd817a  vmovaps [rsp+0xB0], xmm12
0000796caedd8183  vmovaps [rsp+0xC0], xmm13
0000796caedd818c  vmovaps [rsp+0xD0], xmm14
0000796caedd8195  vmovaps [rsp+0xE0], xmm15
0000796caedd819e  sub rsp, 0x30
0000796caedd81a2  movaps [rsp], xmm4
0000796caedd81a6  movaps [rsp+0x10], xmm3
0000796caedd81ab  movaps [rsp+0x20], xmm5
0000796caedd81b0  lea rdi, [rsp]
0000796caedd81b4  mov esi, 0x00
0000796caedd81b9  mov rax, 0x56877063A530
0000796caedd81c3  call rax
0000796caedd81c5  movaps xmm4, [rsp]
0000796caedd81c9  add rsp, 0x30
0000796caedd81cd  vmovaps xmm0, [rsp]
0000796caedd81d2  vmovaps xmm1, [rsp+0x10]
0000796caedd81d8  vmovaps xmm2, [rsp+0x20]
0000796caedd81de  vmovaps xmm3, [rsp+0x30]
0000796caedd81e4  vmovaps xmm5, [rsp+0x40]
0000796caedd81ea  vmovaps xmm6, [rsp+0x50]
0000796caedd81f0  vmovaps xmm7, [rsp+0x60]
0000796caedd81f6  vmovaps xmm8, [rsp+0x70]
0000796caedd81fc  vmovaps xmm9, [rsp+0x80]
0000796caedd8205  vmovaps xmm10, [rsp+0x90]
0000796caedd820e  vmovaps xmm11, [rsp+0xA0]
0000796caedd8217  vmovaps xmm12, [rsp+0xB0]
0000796caedd8220  vmovaps xmm13, [rsp+0xC0]
0000796caedd8229  vmovaps xmm14, [rsp+0xD0]
0000796caedd8232  vmovaps xmm15, [rsp+0xE0]
0000796caedd823b  add rsp, 0xF0
0000796caedd8242  pop r11
0000796caedd8244  pop r10
0000796caedd8246  pop r9
0000796caedd8248  pop r8
0000796caedd824a  pop rsi
0000796caedd824b  pop rdi
0000796caedd824c  pop rdx
0000796caedd824d  pop rcx
0000796caedd824e  pop rax
0000796caedd824f  add rsp, 0x08
0000796caedd8253  jmp 0x0000796CAEDD5F54
0000796caedd8258  call 0x0000796CAECD64F0
0000796caedd825d  jmp 0x0000796CAEDD5F61
0000796caedd8262  sub rsp, 0x08
0000796caedd8266  push rax
0000796caedd8267  push rcx
0000796caedd8268  push rdx
0000796caedd8269  push rdi
0000796caedd826a  push rsi
0000796caedd826b  push r8
0000796caedd826d  push r9
0000796caedd826f  push r10
0000796caedd8271  push r11
0000796caedd8273  sub rsp, 0xF0
0000796caedd827a  vmovaps [rsp], xmm0
0000796caedd827f  vmovaps [rsp+0x10], xmm1
0000796caedd8285  vmovaps [rsp+0x20], xmm2
0000796caedd828b  vmovaps [rsp+0x30], xmm3
0000796caedd8291  vmovaps [rsp+0x40], xmm4
0000796caedd8297  vmovaps [rsp+0x50], xmm6
0000796caedd829d  vmovaps [rsp+0x60], xmm7
0000796caedd82a3  vmovaps [rsp+0x70], xmm8
0000796caedd82a9  vmovaps [rsp+0x80], xmm9
0000796caedd82b2  vmovaps [rsp+0x90], xmm10
0000796caedd82bb  vmovaps [rsp+0xA0], xmm11
0000796caedd82c4  vmovaps [rsp+0xB0], xmm12
0000796caedd82cd  vmovaps [rsp+0xC0], xmm13
0000796caedd82d6  vmovaps [rsp+0xD0], xmm14
0000796caedd82df  vmovaps [rsp+0xE0], xmm15
0000796caedd82e8  sub rsp, 0x30
0000796caedd82ec  movaps [rsp], xmm5
0000796caedd82f0  movaps [rsp+0x10], xmm6
0000796caedd82f5  movaps [rsp+0x20], xmm3
0000796caedd82fa  lea rdi, [rsp]
0000796caedd82fe  mov esi, 0x00
0000796caedd8303  mov rax, 0x56877063A530
0000796caedd830d  call rax
0000796caedd830f  movaps xmm5, [rsp]
0000796caedd8313  add rsp, 0x30
0000796caedd8317  vmovaps xmm0, [rsp]
0000796caedd831c  vmovaps xmm1, [rsp+0x10]
0000796caedd8322  vmovaps xmm2, [rsp+0x20]
0000796caedd8328  vmovaps xmm3, [rsp+0x30]
0000796caedd832e  vmovaps xmm4, [rsp+0x40]
0000796caedd8334  vmovaps xmm6, [rsp+0x50]
0000796caedd833a  vmovaps xmm7, [rsp+0x60]
0000796caedd8340  vmovaps xmm8, [rsp+0x70]
0000796caedd8346  vmovaps xmm9, [rsp+0x80]
0000796caedd834f  vmovaps xmm10, [rsp+0x90]
0000796caedd8358  vmovaps xmm11, [rsp+0xA0]
0000796caedd8361  vmovaps xmm12, [rsp+0xB0]
0000796caedd836a  vmovaps xmm13, [rsp+0xC0]
0000796caedd8373  vmovaps xmm14, [rsp+0xD0]
0000796caedd837c  vmovaps xmm15, [rsp+0xE0]
0000796caedd8385  add rsp, 0xF0
0000796caedd838c  pop r11
0000796caedd838e  pop r10
0000796caedd8390  pop r9
0000796caedd8392  pop r8
0000796caedd8394  pop rsi
0000796caedd8395  pop rdi
0000796caedd8396  pop rdx
0000796caedd8397  pop rcx
0000796caedd8398  pop rax
0000796caedd8399  add rsp, 0x08
0000796caedd839d  jmp 0x0000796CAEDD5F87
0000796caedd83a2  sub rsp, 0x08
0000796caedd83a6  push rax
0000796caedd83a7  push rcx
0000796caedd83a8  push rdx
0000796caedd83a9  push rdi
0000796caedd83aa  push rsi
0000796caedd83ab  push r8
0000796caedd83ad  push r9
0000796caedd83af  push r10
0000796caedd83b1  push r11
0000796caedd83b3  sub rsp, 0xF0
0000796caedd83ba  vmovaps [rsp], xmm0
0000796caedd83bf  vmovaps [rsp+0x10], xmm1
0000796caedd83c5  vmovaps [rsp+0x20], xmm2
0000796caedd83cb  vmovaps [rsp+0x30], xmm3
0000796caedd83d1  vmovaps [rsp+0x40], xmm4
0000796caedd83d7  vmovaps [rsp+0x50], xmm5
0000796caedd83dd  vmovaps [rsp+0x60], xmm7
0000796caedd83e3  vmovaps [rsp+0x70], xmm8
0000796caedd83e9  vmovaps [rsp+0x80], xmm9
0000796caedd83f2  vmovaps [rsp+0x90], xmm10
0000796caedd83fb  vmovaps [rsp+0xA0], xmm11
0000796caedd8404  vmovaps [rsp+0xB0], xmm12
0000796caedd840d  vmovaps [rsp+0xC0], xmm13
0000796caedd8416  vmovaps [rsp+0xD0], xmm14
0000796caedd841f  vmovaps [rsp+0xE0], xmm15
0000796caedd8428  sub rsp, 0x30
0000796caedd842c  movaps [rsp], xmm6
0000796caedd8430  movaps [rsp+0x10], xmm9
0000796caedd8436  movaps [rsp+0x20], xmm1
0000796caedd843b  lea rdi, [rsp]
0000796caedd843f  mov esi, 0x00
0000796caedd8444  mov rax, 0x56877063A530
0000796caedd844e  call rax
0000796caedd8450  movaps xmm6, [rsp]
0000796caedd8454  add rsp, 0x30
0000796caedd8458  vmovaps xmm0, [rsp]
0000796caedd845d  vmovaps xmm1, [rsp+0x10]
0000796caedd8463  vmovaps xmm2, [rsp+0x20]
0000796caedd8469  vmovaps xmm3, [rsp+0x30]
0000796caedd846f  vmovaps xmm4, [rsp+0x40]
0000796caedd8475  vmovaps xmm5, [rsp+0x50]
0000796caedd847b  vmovaps xmm7, [rsp+0x60]
0000796caedd8481  vmovaps xmm8, [rsp+0x70]
0000796caedd8487  vmovaps xmm9, [rsp+0x80]
0000796caedd8490  vmovaps xmm10, [rsp+0x90]
0000796caedd8499  vmovaps xmm11, [rsp+0xA0]
0000796caedd84a2  vmovaps xmm12, [rsp+0xB0]
0000796caedd84ab  vmovaps xmm13, [rsp+0xC0]
0000796caedd84b4  vmovaps xmm14, [rsp+0xD0]
0000796caedd84bd  vmovaps xmm15, [rsp+0xE0]
0000796caedd84c6  add rsp, 0xF0
0000796caedd84cd  pop r11
0000796caedd84cf  pop r10
0000796caedd84d1  pop r9
0000796caedd84d3  pop r8
0000796caedd84d5  pop rsi
0000796caedd84d6  pop rdi
0000796caedd84d7  pop rdx
0000796caedd84d8  pop rcx
0000796caedd84d9  pop rax
0000796caedd84da  add rsp, 0x08
0000796caedd84de  jmp 0x0000796CAEDD5FAB
0000796caedd84e3  sub rsp, 0x08
0000796caedd84e7  push rax
0000796caedd84e8  push rcx
0000796caedd84e9  push rdx
0000796caedd84ea  push rdi
0000796caedd84eb  push rsi
0000796caedd84ec  push r8
0000796caedd84ee  push r9
0000796caedd84f0  push r10
0000796caedd84f2  push r11
0000796caedd84f4  sub rsp, 0xF0
0000796caedd84fb  vmovaps [rsp], xmm0
0000796caedd8500  vmovaps [rsp+0x10], xmm1
0000796caedd8506  vmovaps [rsp+0x20], xmm2
0000796caedd850c  vmovaps [rsp+0x30], xmm3
0000796caedd8512  vmovaps [rsp+0x40], xmm4
0000796caedd8518  vmovaps [rsp+0x50], xmm5
0000796caedd851e  vmovaps [rsp+0x60], xmm6
0000796caedd8524  vmovaps [rsp+0x70], xmm7
0000796caedd852a  vmovaps [rsp+0x80], xmm8
0000796caedd8533  vmovaps [rsp+0x90], xmm10
0000796caedd853c  vmovaps [rsp+0xA0], xmm11
0000796caedd8545  vmovaps [rsp+0xB0], xmm12
0000796caedd854e  vmovaps [rsp+0xC0], xmm13
0000796caedd8557  vmovaps [rsp+0xD0], xmm14
0000796caedd8560  vmovaps [rsp+0xE0], xmm15
0000796caedd8569  sub rsp, 0x30
0000796caedd856d  movaps [rsp], xmm9
0000796caedd8572  movaps [rsp+0x10], xmm3
0000796caedd8577  movaps [rsp+0x20], xmm1
0000796caedd857c  lea rdi, [rsp]
0000796caedd8580  mov esi, 0x00
0000796caedd8585  mov rax, 0x56877063A530
0000796caedd858f  call rax
0000796caedd8591  movaps xmm9, [rsp]
0000796caedd8596  add rsp, 0x30
0000796caedd859a  vmovaps xmm0, [rsp]
0000796caedd859f  vmovaps xmm1, [rsp+0x10]
0000796caedd85a5  vmovaps xmm2, [rsp+0x20]
0000796caedd85ab  vmovaps xmm3, [rsp+0x30]
0000796caedd85b1  vmovaps xmm4, [rsp+0x40]
0000796caedd85b7  vmovaps xmm5, [rsp+0x50]
0000796caedd85bd  vmovaps xmm6, [rsp+0x60]
0000796caedd85c3  vmovaps xmm7, [rsp+0x70]
0000796caedd85c9  vmovaps xmm8, [rsp+0x80]
0000796caedd85d2  vmovaps xmm10, [rsp+0x90]
0000796caedd85db  vmovaps xmm11, [rsp+0xA0]
0000796caedd85e4  vmovaps xmm12, [rsp+0xB0]
0000796caedd85ed  vmovaps xmm13, [rsp+0xC0]
0000796caedd85f6  vmovaps xmm14, [rsp+0xD0]
0000796caedd85ff  vmovaps xmm15, [rsp+0xE0]
0000796caedd8608  add rsp, 0xF0
0000796caedd860f  pop r11
0000796caedd8611  pop r10
0000796caedd8613  pop r9
0000796caedd8615  pop r8
0000796caedd8617  pop rsi
0000796caedd8618  pop rdi
0000796caedd8619  pop rdx
0000796caedd861a  pop rcx
0000796caedd861b  pop rax
0000796caedd861c  add rsp, 0x08
0000796caedd8620  jmp 0x0000796CAEDD5FF7
0000796caedd8625  call 0x0000796CAECD64F0
0000796caedd862a  jmp 0x0000796CAEDD6004
0000796caedd862f  sub rsp, 0x08
0000796caedd8633  push rax
0000796caedd8634  push rcx
0000796caedd8635  push rdx
0000796caedd8636  push rdi
0000796caedd8637  push rsi
0000796caedd8638  push r8
0000796caedd863a  push r9
0000796caedd863c  push r10
0000796caedd863e  push r11
0000796caedd8640  sub rsp, 0xF0
0000796caedd8647  vmovaps [rsp], xmm0
0000796caedd864c  vmovaps [rsp+0x10], xmm1
0000796caedd8652  vmovaps [rsp+0x20], xmm2
0000796caedd8658  vmovaps [rsp+0x30], xmm3
0000796caedd865e  vmovaps [rsp+0x40], xmm4
0000796caedd8664  vmovaps [rsp+0x50], xmm5
0000796caedd866a  vmovaps [rsp+0x60], xmm6
0000796caedd8670  vmovaps [rsp+0x70], xmm7
0000796caedd8676  vmovaps [rsp+0x80], xmm8
0000796caedd867f  vmovaps [rsp+0x90], xmm9
0000796caedd8688  vmovaps [rsp+0xA0], xmm10
0000796caedd8691  vmovaps [rsp+0xB0], xmm11
0000796caedd869a  vmovaps [rsp+0xC0], xmm12
0000796caedd86a3  vmovaps [rsp+0xD0], xmm13
0000796caedd86ac  vmovaps [rsp+0xE0], xmm14
0000796caedd86b5  sub rsp, 0x30
0000796caedd86b9  movaps [rsp], xmm15
0000796caedd86be  movaps [rsp+0x10], xmm3
0000796caedd86c3  movaps [rsp+0x20], xmm7
0000796caedd86c8  lea rdi, [rsp]
0000796caedd86cc  mov esi, 0x00
0000796caedd86d1  mov rax, 0x56877063A530
0000796caedd86db  call rax
0000796caedd86dd  movaps xmm15, [rsp]
0000796caedd86e2  add rsp, 0x30
0000796caedd86e6  vmovaps xmm0, [rsp]
0000796caedd86eb  vmovaps xmm1, [rsp+0x10]
0000796caedd86f1  vmovaps xmm2, [rsp+0x20]
0000796caedd86f7  vmovaps xmm3, [rsp+0x30]
0000796caedd86fd  vmovaps xmm4, [rsp+0x40]
0000796caedd8703  vmovaps xmm5, [rsp+0x50]
0000796caedd8709  vmovaps xmm6, [rsp+0x60]
0000796caedd870f  vmovaps xmm7, [rsp+0x70]
0000796caedd8715  vmovaps xmm8, [rsp+0x80]
0000796caedd871e  vmovaps xmm9, [rsp+0x90]
0000796caedd8727  vmovaps xmm10, [rsp+0xA0]
0000796caedd8730  vmovaps xmm11, [rsp+0xB0]
0000796caedd8739  vmovaps xmm12, [rsp+0xC0]
0000796caedd8742  vmovaps xmm13, [rsp+0xD0]
0000796caedd874b  vmovaps xmm14, [rsp+0xE0]
0000796caedd8754  add rsp, 0xF0
0000796caedd875b  pop r11
0000796caedd875d  pop r10
0000796caedd875f  pop r9
0000796caedd8761  pop r8
0000796caedd8763  pop rsi
0000796caedd8764  pop rdi
0000796caedd8765  pop rdx
0000796caedd8766  pop rcx
0000796caedd8767  pop rax
0000796caedd8768  add rsp, 0x08
0000796caedd876c  jmp 0x0000796CAEDD6030
0000796caedd8771  sub rsp, 0x08
0000796caedd8775  push rax
0000796caedd8776  push rcx
0000796caedd8777  push rdx
0000796caedd8778  push rdi
0000796caedd8779  push rsi
0000796caedd877a  push r8
0000796caedd877c  push r9
0000796caedd877e  push r10
0000796caedd8780  push r11
0000796caedd8782  sub rsp, 0xF0
0000796caedd8789  vmovaps [rsp], xmm0
0000796caedd878e  vmovaps [rsp+0x10], xmm1
0000796caedd8794  vmovaps [rsp+0x20], xmm2
0000796caedd879a  vmovaps [rsp+0x30], xmm4
0000796caedd87a0  vmovaps [rsp+0x40], xmm5
0000796caedd87a6  vmovaps [rsp+0x50], xmm6
0000796caedd87ac  vmovaps [rsp+0x60], xmm7
0000796caedd87b2  vmovaps [rsp+0x70], xmm8
0000796caedd87b8  vmovaps [rsp+0x80], xmm9
0000796caedd87c1  vmovaps [rsp+0x90], xmm10
0000796caedd87ca  vmovaps [rsp+0xA0], xmm11
0000796caedd87d3  vmovaps [rsp+0xB0], xmm12
0000796caedd87dc  vmovaps [rsp+0xC0], xmm13
0000796caedd87e5  vmovaps [rsp+0xD0], xmm14
0000796caedd87ee  vmovaps [rsp+0xE0], xmm15
0000796caedd87f7  sub rsp, 0x30
0000796caedd87fb  movaps [rsp], xmm3
0000796caedd87ff  movaps [rsp+0x10], xmm1
0000796caedd8804  movaps [rsp+0x20], xmm15
0000796caedd880a  lea rdi, [rsp]
0000796caedd880e  mov esi, 0x00
0000796caedd8813  mov rax, 0x56877063A530
0000796caedd881d  call rax
0000796caedd881f  movaps xmm3, [rsp]
0000796caedd8823  add rsp, 0x30
0000796caedd8827  vmovaps xmm0, [rsp]
0000796caedd882c  vmovaps xmm1, [rsp+0x10]
0000796caedd8832  vmovaps xmm2, [rsp+0x20]
0000796caedd8838  vmovaps xmm4, [rsp+0x30]
0000796caedd883e  vmovaps xmm5, [rsp+0x40]
0000796caedd8844  vmovaps xmm6, [rsp+0x50]
0000796caedd884a  vmovaps xmm7, [rsp+0x60]
0000796caedd8850  vmovaps xmm8, [rsp+0x70]
0000796caedd8856  vmovaps xmm9, [rsp+0x80]
0000796caedd885f  vmovaps xmm10, [rsp+0x90]
0000796caedd8868  vmovaps xmm11, [rsp+0xA0]
0000796caedd8871  vmovaps xmm12, [rsp+0xB0]
0000796caedd887a  vmovaps xmm13, [rsp+0xC0]
0000796caedd8883  vmovaps xmm14, [rsp+0xD0]
0000796caedd888c  vmovaps xmm15, [rsp+0xE0]
0000796caedd8895  add rsp, 0xF0
0000796caedd889c  pop r11
0000796caedd889e  pop r10
0000796caedd88a0  pop r9
0000796caedd88a2  pop r8
0000796caedd88a4  pop rsi
0000796caedd88a5  pop rdi
0000796caedd88a6  pop rdx
0000796caedd88a7  pop rcx
0000796caedd88a8  pop rax
0000796caedd88a9  add rsp, 0x08
0000796caedd88ad  jmp 0x0000796CAEDD60BF
0000796caedd88b2  call 0x0000796CAECD64F0
0000796caedd88b7  jmp 0x0000796CAEDD60C9
0000796caedd88bc  sub rsp, 0x08
0000796caedd88c0  push rax
0000796caedd88c1  push rcx
0000796caedd88c2  push rdx
0000796caedd88c3  push rdi
0000796caedd88c4  push rsi
0000796caedd88c5  push r8
0000796caedd88c7  push r9
0000796caedd88c9  push r10
0000796caedd88cb  push r11
0000796caedd88cd  sub rsp, 0xF0
0000796caedd88d4  vmovaps [rsp], xmm0
0000796caedd88d9  vmovaps [rsp+0x10], xmm1
0000796caedd88df  vmovaps [rsp+0x20], xmm2
0000796caedd88e5  vmovaps [rsp+0x30], xmm3
0000796caedd88eb  vmovaps [rsp+0x40], xmm4
0000796caedd88f1  vmovaps [rsp+0x50], xmm5
0000796caedd88f7  vmovaps [rsp+0x60], xmm6
0000796caedd88fd  vmovaps [rsp+0x70], xmm7
0000796caedd8903  vmovaps [rsp+0x80], xmm8
0000796caedd890c  vmovaps [rsp+0x90], xmm9
0000796caedd8915  vmovaps [rsp+0xA0], xmm10
0000796caedd891e  vmovaps [rsp+0xB0], xmm11
0000796caedd8927  vmovaps [rsp+0xC0], xmm12
0000796caedd8930  vmovaps [rsp+0xD0], xmm13
0000796caedd8939  vmovaps [rsp+0xE0], xmm14
0000796caedd8942  sub rsp, 0x30
0000796caedd8946  movaps [rsp], xmm15
0000796caedd894b  movaps [rsp+0x10], xmm14
0000796caedd8951  movaps [rsp+0x20], xmm4
0000796caedd8956  lea rdi, [rsp]
0000796caedd895a  mov esi, 0x00
0000796caedd895f  mov rax, 0x56877063A530
0000796caedd8969  call rax
0000796caedd896b  movaps xmm15, [rsp]
0000796caedd8970  add rsp, 0x30
0000796caedd8974  vmovaps xmm0, [rsp]
0000796caedd8979  vmovaps xmm1, [rsp+0x10]
0000796caedd897f  vmovaps xmm2, [rsp+0x20]
0000796caedd8985  vmovaps xmm3, [rsp+0x30]
0000796caedd898b  vmovaps xmm4, [rsp+0x40]
0000796caedd8991  vmovaps xmm5, [rsp+0x50]
0000796caedd8997  vmovaps xmm6, [rsp+0x60]
0000796caedd899d  vmovaps xmm7, [rsp+0x70]
0000796caedd89a3  vmovaps xmm8, [rsp+0x80]
0000796caedd89ac  vmovaps xmm9, [rsp+0x90]
0000796caedd89b5  vmovaps xmm10, [rsp+0xA0]
0000796caedd89be  vmovaps xmm11, [rsp+0xB0]
0000796caedd89c7  vmovaps xmm12, [rsp+0xC0]
0000796caedd89d0  vmovaps xmm13, [rsp+0xD0]
0000796caedd89d9  vmovaps xmm14, [rsp+0xE0]
0000796caedd89e2  add rsp, 0xF0
0000796caedd89e9  pop r11
0000796caedd89eb  pop r10
0000796caedd89ed  pop r9
0000796caedd89ef  pop r8
0000796caedd89f1  pop rsi
0000796caedd89f2  pop rdi
0000796caedd89f3  pop rdx
0000796caedd89f4  pop rcx
0000796caedd89f5  pop rax
0000796caedd89f6  add rsp, 0x08
0000796caedd89fa  jmp 0x0000796CAEDD60F7
0000796caedd89ff  sub rsp, 0x08
0000796caedd8a03  push rax
0000796caedd8a04  push rcx
0000796caedd8a05  push rdx
0000796caedd8a06  push rdi
0000796caedd8a07  push rsi
0000796caedd8a08  push r8
0000796caedd8a0a  push r9
0000796caedd8a0c  push r10
0000796caedd8a0e  push r11
0000796caedd8a10  sub rsp, 0xF0
0000796caedd8a17  vmovaps [rsp], xmm0
0000796caedd8a1c  vmovaps [rsp+0x10], xmm1
0000796caedd8a22  vmovaps [rsp+0x20], xmm2
0000796caedd8a28  vmovaps [rsp+0x30], xmm3
0000796caedd8a2e  vmovaps [rsp+0x40], xmm4
0000796caedd8a34  vmovaps [rsp+0x50], xmm5
0000796caedd8a3a  vmovaps [rsp+0x60], xmm6
0000796caedd8a40  vmovaps [rsp+0x70], xmm7
0000796caedd8a46  vmovaps [rsp+0x80], xmm8
0000796caedd8a4f  vmovaps [rsp+0x90], xmm9
0000796caedd8a58  vmovaps [rsp+0xA0], xmm10
0000796caedd8a61  vmovaps [rsp+0xB0], xmm11
0000796caedd8a6a  vmovaps [rsp+0xC0], xmm12
0000796caedd8a73  vmovaps [rsp+0xD0], xmm13
0000796caedd8a7c  vmovaps [rsp+0xE0], xmm15
0000796caedd8a85  sub rsp, 0x30
0000796caedd8a89  movaps [rsp], xmm14
0000796caedd8a8e  movaps [rsp+0x10], xmm2
0000796caedd8a93  movaps [rsp+0x20], xmm1
0000796caedd8a98  lea rdi, [rsp]
0000796caedd8a9c  mov esi, 0x00
0000796caedd8aa1  mov rax, 0x56877063A530
0000796caedd8aab  call rax
0000796caedd8aad  movaps xmm14, [rsp]
0000796caedd8ab2  add rsp, 0x30
0000796caedd8ab6  vmovaps xmm0, [rsp]
0000796caedd8abb  vmovaps xmm1, [rsp+0x10]
0000796caedd8ac1  vmovaps xmm2, [rsp+0x20]
0000796caedd8ac7  vmovaps xmm3, [rsp+0x30]
0000796caedd8acd  vmovaps xmm4, [rsp+0x40]
0000796caedd8ad3  vmovaps xmm5, [rsp+0x50]
0000796caedd8ad9  vmovaps xmm6, [rsp+0x60]
0000796caedd8adf  vmovaps xmm7, [rsp+0x70]
0000796caedd8ae5  vmovaps xmm8, [rsp+0x80]
0000796caedd8aee  vmovaps xmm9, [rsp+0x90]
0000796caedd8af7  vmovaps xmm10, [rsp+0xA0]
0000796caedd8b00  vmovaps xmm11, [rsp+0xB0]
0000796caedd8b09  vmovaps xmm12, [rsp+0xC0]
0000796caedd8b12  vmovaps xmm13, [rsp+0xD0]
0000796caedd8b1b  vmovaps xmm15, [rsp+0xE0]
0000796caedd8b24  add rsp, 0xF0
0000796caedd8b2b  pop r11
0000796caedd8b2d  pop r10
0000796caedd8b2f  pop r9
0000796caedd8b31  pop r8
0000796caedd8b33  pop rsi
0000796caedd8b34  pop rdi
0000796caedd8b35  pop rdx
0000796caedd8b36  pop rcx
0000796caedd8b37  pop rax
0000796caedd8b38  add rsp, 0x08
0000796caedd8b3c  jmp 0x0000796CAEDD611D
0000796caedd8b41  sub rsp, 0x08
0000796caedd8b45  push rax
0000796caedd8b46  push rcx
0000796caedd8b47  push rdx
0000796caedd8b48  push rdi
0000796caedd8b49  push rsi
0000796caedd8b4a  push r8
0000796caedd8b4c  push r9
0000796caedd8b4e  push r10
0000796caedd8b50  push r11
0000796caedd8b52  sub rsp, 0xF0
0000796caedd8b59  vmovaps [rsp], xmm0
0000796caedd8b5e  vmovaps [rsp+0x10], xmm2
0000796caedd8b64  vmovaps [rsp+0x20], xmm3
0000796caedd8b6a  vmovaps [rsp+0x30], xmm4
0000796caedd8b70  vmovaps [rsp+0x40], xmm5
0000796caedd8b76  vmovaps [rsp+0x50], xmm6
0000796caedd8b7c  vmovaps [rsp+0x60], xmm7
0000796caedd8b82  vmovaps [rsp+0x70], xmm8
0000796caedd8b88  vmovaps [rsp+0x80], xmm9
0000796caedd8b91  vmovaps [rsp+0x90], xmm10
0000796caedd8b9a  vmovaps [rsp+0xA0], xmm11
0000796caedd8ba3  vmovaps [rsp+0xB0], xmm12
0000796caedd8bac  vmovaps [rsp+0xC0], xmm13
0000796caedd8bb5  vmovaps [rsp+0xD0], xmm14
0000796caedd8bbe  vmovaps [rsp+0xE0], xmm15
0000796caedd8bc7  sub rsp, 0x30
0000796caedd8bcb  movaps [rsp], xmm1
0000796caedd8bcf  movaps [rsp+0x10], xmm4
0000796caedd8bd4  movaps [rsp+0x20], xmm9
0000796caedd8bda  lea rdi, [rsp]
0000796caedd8bde  mov esi, 0x00
0000796caedd8be3  mov rax, 0x56877063A530
0000796caedd8bed  call rax
0000796caedd8bef  movaps xmm1, [rsp]
0000796caedd8bf3  add rsp, 0x30
0000796caedd8bf7  vmovaps xmm0, [rsp]
0000796caedd8bfc  vmovaps xmm2, [rsp+0x10]
0000796caedd8c02  vmovaps xmm3, [rsp+0x20]
0000796caedd8c08  vmovaps xmm4, [rsp+0x30]
0000796caedd8c0e  vmovaps xmm5, [rsp+0x40]
0000796caedd8c14  vmovaps xmm6, [rsp+0x50]
0000796caedd8c1a  vmovaps xmm7, [rsp+0x60]
0000796caedd8c20  vmovaps xmm8, [rsp+0x70]
0000796caedd8c26  vmovaps xmm9, [rsp+0x80]
0000796caedd8c2f  vmovaps xmm10, [rsp+0x90]
0000796caedd8c38  vmovaps xmm11, [rsp+0xA0]
0000796caedd8c41  vmovaps xmm12, [rsp+0xB0]
0000796caedd8c4a  vmovaps xmm13, [rsp+0xC0]
0000796caedd8c53  vmovaps xmm14, [rsp+0xD0]
0000796caedd8c5c  vmovaps xmm15, [rsp+0xE0]
0000796caedd8c65  add rsp, 0xF0
0000796caedd8c6c  pop r11
0000796caedd8c6e  pop r10
0000796caedd8c70  pop r9
0000796caedd8c72  pop r8
0000796caedd8c74  pop rsi
0000796caedd8c75  pop rdi
0000796caedd8c76  pop rdx
0000796caedd8c77  pop rcx
0000796caedd8c78  pop rax
0000796caedd8c79  add rsp, 0x08
0000796caedd8c7d  jmp 0x0000796CAEDD613B
0000796caedd8c82  sub rsp, 0x08
0000796caedd8c86  push rax
0000796caedd8c87  push rcx
0000796caedd8c88  push rdx
0000796caedd8c89  push rdi
0000796caedd8c8a  push rsi
0000796caedd8c8b  push r8
0000796caedd8c8d  push r9
0000796caedd8c8f  push r10
0000796caedd8c91  push r11
0000796caedd8c93  sub rsp, 0xF0
0000796caedd8c9a  vmovaps [rsp], xmm0
0000796caedd8c9f  vmovaps [rsp+0x10], xmm1
0000796caedd8ca5  vmovaps [rsp+0x20], xmm2
0000796caedd8cab  vmovaps [rsp+0x30], xmm3
0000796caedd8cb1  vmovaps [rsp+0x40], xmm5
0000796caedd8cb7  vmovaps [rsp+0x50], xmm6
0000796caedd8cbd  vmovaps [rsp+0x60], xmm7
0000796caedd8cc3  vmovaps [rsp+0x70], xmm8
0000796caedd8cc9  vmovaps [rsp+0x80], xmm9
0000796caedd8cd2  vmovaps [rsp+0x90], xmm10
0000796caedd8cdb  vmovaps [rsp+0xA0], xmm11
0000796caedd8ce4  vmovaps [rsp+0xB0], xmm12
0000796caedd8ced  vmovaps [rsp+0xC0], xmm13
0000796caedd8cf6  vmovaps [rsp+0xD0], xmm14
0000796caedd8cff  vmovaps [rsp+0xE0], xmm15
0000796caedd8d08  sub rsp, 0x30
0000796caedd8d0c  movaps [rsp], xmm4
0000796caedd8d10  movaps [rsp+0x10], xmm2
0000796caedd8d15  movaps [rsp+0x20], xmm9
0000796caedd8d1b  lea rdi, [rsp]
0000796caedd8d1f  mov esi, 0x00
0000796caedd8d24  mov rax, 0x56877063A530
0000796caedd8d2e  call rax
0000796caedd8d30  movaps xmm4, [rsp]
0000796caedd8d34  add rsp, 0x30
0000796caedd8d38  vmovaps xmm0, [rsp]
0000796caedd8d3d  vmovaps xmm1, [rsp+0x10]
0000796caedd8d43  vmovaps xmm2, [rsp+0x20]
0000796caedd8d49  vmovaps xmm3, [rsp+0x30]
0000796caedd8d4f  vmovaps xmm5, [rsp+0x40]
0000796caedd8d55  vmovaps xmm6, [rsp+0x50]
0000796caedd8d5b  vmovaps xmm7, [rsp+0x60]
0000796caedd8d61  vmovaps xmm8, [rsp+0x70]
0000796caedd8d67  vmovaps xmm9, [rsp+0x80]
0000796caedd8d70  vmovaps xmm10, [rsp+0x90]
0000796caedd8d79  vmovaps xmm11, [rsp+0xA0]
0000796caedd8d82  vmovaps xmm12, [rsp+0xB0]
0000796caedd8d8b  vmovaps xmm13, [rsp+0xC0]
0000796caedd8d94  vmovaps xmm14, [rsp+0xD0]
0000796caedd8d9d  vmovaps xmm15, [rsp+0xE0]
0000796caedd8da6  add rsp, 0xF0
0000796caedd8dad  pop r11
0000796caedd8daf  pop r10
0000796caedd8db1  pop r9
0000796caedd8db3  pop r8
0000796caedd8db5  pop rsi
0000796caedd8db6  pop rdi
0000796caedd8db7  pop rdx
0000796caedd8db8  pop rcx
0000796caedd8db9  pop rax
0000796caedd8dba  add rsp, 0x08
0000796caedd8dbe  jmp 0x0000796CAEDD616B
0000796caedd8dc3  sub rsp, 0x08
0000796caedd8dc7  push rax
0000796caedd8dc8  push rcx
0000796caedd8dc9  push rdx
0000796caedd8dca  push rdi
0000796caedd8dcb  push rsi
0000796caedd8dcc  push r8
0000796caedd8dce  push r9
0000796caedd8dd0  push r10
0000796caedd8dd2  push r11
0000796caedd8dd4  sub rsp, 0xF0
0000796caedd8ddb  vmovaps [rsp], xmm0
0000796caedd8de0  vmovaps [rsp+0x10], xmm1
0000796caedd8de6  vmovaps [rsp+0x20], xmm2
0000796caedd8dec  vmovaps [rsp+0x30], xmm3
0000796caedd8df2  vmovaps [rsp+0x40], xmm4
0000796caedd8df8  vmovaps [rsp+0x50], xmm5
0000796caedd8dfe  vmovaps [rsp+0x60], xmm6
0000796caedd8e04  vmovaps [rsp+0x70], xmm7
0000796caedd8e0a  vmovaps [rsp+0x80], xmm8
0000796caedd8e13  vmovaps [rsp+0x90], xmm10
0000796caedd8e1c  vmovaps [rsp+0xA0], xmm11
0000796caedd8e25  vmovaps [rsp+0xB0], xmm12
0000796caedd8e2e  vmovaps [rsp+0xC0], xmm13
0000796caedd8e37  vmovaps [rsp+0xD0], xmm14
0000796caedd8e40  vmovaps [rsp+0xE0], xmm15
0000796caedd8e49  sub rsp, 0x30
0000796caedd8e4d  movaps [rsp], xmm9
0000796caedd8e52  movaps [rsp+0x10], xmm2
0000796caedd8e57  movaps [rsp+0x20], xmm1
0000796caedd8e5c  lea rdi, [rsp]
0000796caedd8e60  mov esi, 0x00
0000796caedd8e65  mov rax, 0x56877063A530
0000796caedd8e6f  call rax
0000796caedd8e71  movaps xmm9, [rsp]
0000796caedd8e76  add rsp, 0x30
0000796caedd8e7a  vmovaps xmm0, [rsp]
0000796caedd8e7f  vmovaps xmm1, [rsp+0x10]
0000796caedd8e85  vmovaps xmm2, [rsp+0x20]
0000796caedd8e8b  vmovaps xmm3, [rsp+0x30]
0000796caedd8e91  vmovaps xmm4, [rsp+0x40]
0000796caedd8e97  vmovaps xmm5, [rsp+0x50]
0000796caedd8e9d  vmovaps xmm6, [rsp+0x60]
0000796caedd8ea3  vmovaps xmm7, [rsp+0x70]
0000796caedd8ea9  vmovaps xmm8, [rsp+0x80]
0000796caedd8eb2  vmovaps xmm10, [rsp+0x90]
0000796caedd8ebb  vmovaps xmm11, [rsp+0xA0]
0000796caedd8ec4  vmovaps xmm12, [rsp+0xB0]
0000796caedd8ecd  vmovaps xmm13, [rsp+0xC0]
0000796caedd8ed6  vmovaps xmm14, [rsp+0xD0]
0000796caedd8edf  vmovaps xmm15, [rsp+0xE0]
0000796caedd8ee8  add rsp, 0xF0
0000796caedd8eef  pop r11
0000796caedd8ef1  pop r10
0000796caedd8ef3  pop r9
0000796caedd8ef5  pop r8
0000796caedd8ef7  pop rsi
0000796caedd8ef8  pop rdi
0000796caedd8ef9  pop rdx
0000796caedd8efa  pop rcx
0000796caedd8efb  pop rax
0000796caedd8efc  add rsp, 0x08
0000796caedd8f00  jmp 0x0000796CAEDD61A1
0000796caedd8f05  sub rsp, 0x08
0000796caedd8f09  push rax
0000796caedd8f0a  push rcx
0000796caedd8f0b  push rdx
0000796caedd8f0c  push rdi
0000796caedd8f0d  push rsi
0000796caedd8f0e  push r8
0000796caedd8f10  push r9
0000796caedd8f12  push r10
0000796caedd8f14  push r11
0000796caedd8f16  sub rsp, 0xF0
0000796caedd8f1d  vmovaps [rsp], xmm0
0000796caedd8f22  vmovaps [rsp+0x10], xmm2
0000796caedd8f28  vmovaps [rsp+0x20], xmm3
0000796caedd8f2e  vmovaps [rsp+0x30], xmm4
0000796caedd8f34  vmovaps [rsp+0x40], xmm5
0000796caedd8f3a  vmovaps [rsp+0x50], xmm6
0000796caedd8f40  vmovaps [rsp+0x60], xmm7
0000796caedd8f46  vmovaps [rsp+0x70], xmm8
0000796caedd8f4c  vmovaps [rsp+0x80], xmm9
0000796caedd8f55  vmovaps [rsp+0x90], xmm10
0000796caedd8f5e  vmovaps [rsp+0xA0], xmm11
0000796caedd8f67  vmovaps [rsp+0xB0], xmm12
0000796caedd8f70  vmovaps [rsp+0xC0], xmm13
0000796caedd8f79  vmovaps [rsp+0xD0], xmm14
0000796caedd8f82  vmovaps [rsp+0xE0], xmm15
0000796caedd8f8b  sub rsp, 0x30
0000796caedd8f8f  movaps [rsp], xmm1
0000796caedd8f93  movaps [rsp+0x10], xmm15
0000796caedd8f99  movaps [rsp+0x20], xmm6
0000796caedd8f9e  lea rdi, [rsp]
0000796caedd8fa2  mov esi, 0x00
0000796caedd8fa7  mov rax, 0x56877063A530
0000796caedd8fb1  call rax
0000796caedd8fb3  movaps xmm1, [rsp]
0000796caedd8fb7  add rsp, 0x30
0000796caedd8fbb  vmovaps xmm0, [rsp]
0000796caedd8fc0  vmovaps xmm2, [rsp+0x10]
0000796caedd8fc6  vmovaps xmm3, [rsp+0x20]
0000796caedd8fcc  vmovaps xmm4, [rsp+0x30]
0000796caedd8fd2  vmovaps xmm5, [rsp+0x40]
0000796caedd8fd8  vmovaps xmm6, [rsp+0x50]
0000796caedd8fde  vmovaps xmm7, [rsp+0x60]
0000796caedd8fe4  vmovaps xmm8, [rsp+0x70]
0000796caedd8fea  vmovaps xmm9, [rsp+0x80]
0000796caedd8ff3  vmovaps xmm10, [rsp+0x90]
0000796caedd8ffc  vmovaps xmm11, [rsp+0xA0]
0000796caedd9005  vmovaps xmm12, [rsp+0xB0]
0000796caedd900e  vmovaps xmm13, [rsp+0xC0]
0000796caedd9017  vmovaps xmm14, [rsp+0xD0]
0000796caedd9020  vmovaps xmm15, [rsp+0xE0]
0000796caedd9029  add rsp, 0xF0
0000796caedd9030  pop r11
0000796caedd9032  pop r10
0000796caedd9034  pop r9
0000796caedd9036  pop r8
0000796caedd9038  pop rsi
0000796caedd9039  pop rdi
0000796caedd903a  pop rdx
0000796caedd903b  pop rcx
0000796caedd903c  pop rax
0000796caedd903d  add rsp, 0x08
0000796caedd9041  jmp 0x0000796CAEDD61C2
0000796caedd9046  sub rsp, 0x08
0000796caedd904a  push rax
0000796caedd904b  push rcx
0000796caedd904c  push rdx
0000796caedd904d  push rdi
0000796caedd904e  push rsi
0000796caedd904f  push r8
0000796caedd9051  push r9
0000796caedd9053  push r10
0000796caedd9055  push r11
0000796caedd9057  sub rsp, 0xF0
0000796caedd905e  vmovaps [rsp], xmm0
0000796caedd9063  vmovaps [rsp+0x10], xmm1
0000796caedd9069  vmovaps [rsp+0x20], xmm2
0000796caedd906f  vmovaps [rsp+0x30], xmm3
0000796caedd9075  vmovaps [rsp+0x40], xmm4
0000796caedd907b  vmovaps [rsp+0x50], xmm5
0000796caedd9081  vmovaps [rsp+0x60], xmm6
0000796caedd9087  vmovaps [rsp+0x70], xmm7
0000796caedd908d  vmovaps [rsp+0x80], xmm8
0000796caedd9096  vmovaps [rsp+0x90], xmm9
0000796caedd909f  vmovaps [rsp+0xA0], xmm10
0000796caedd90a8  vmovaps [rsp+0xB0], xmm11
0000796caedd90b1  vmovaps [rsp+0xC0], xmm12
0000796caedd90ba  vmovaps [rsp+0xD0], xmm13
0000796caedd90c3  vmovaps [rsp+0xE0], xmm14
0000796caedd90cc  sub rsp, 0x30
0000796caedd90d0  movaps [rsp], xmm15
0000796caedd90d5  movaps [rsp+0x10], xmm5
0000796caedd90da  movaps [rsp+0x20], xmm3
0000796caedd90df  lea rdi, [rsp]
0000796caedd90e3  mov esi, 0x00
0000796caedd90e8  mov rax, 0x56877063A530
0000796caedd90f2  call rax
0000796caedd90f4  movaps xmm15, [rsp]
0000796caedd90f9  add rsp, 0x30
0000796caedd90fd  vmovaps xmm0, [rsp]
0000796caedd9102  vmovaps xmm1, [rsp+0x10]
0000796caedd9108  vmovaps xmm2, [rsp+0x20]
0000796caedd910e  vmovaps xmm3, [rsp+0x30]
0000796caedd9114  vmovaps xmm4, [rsp+0x40]
0000796caedd911a  vmovaps xmm5, [rsp+0x50]
0000796caedd9120  vmovaps xmm6, [rsp+0x60]
0000796caedd9126  vmovaps xmm7, [rsp+0x70]
0000796caedd912c  vmovaps xmm8, [rsp+0x80]
0000796caedd9135  vmovaps xmm9, [rsp+0x90]
0000796caedd913e  vmovaps xmm10, [rsp+0xA0]
0000796caedd9147  vmovaps xmm11, [rsp+0xB0]
0000796caedd9150  vmovaps xmm12, [rsp+0xC0]
0000796caedd9159  vmovaps xmm13, [rsp+0xD0]
0000796caedd9162  vmovaps xmm14, [rsp+0xE0]
0000796caedd916b  add rsp, 0xF0
0000796caedd9172  pop r11
0000796caedd9174  pop r10
0000796caedd9176  pop r9
0000796caedd9178  pop r8
0000796caedd917a  pop rsi
0000796caedd917b  pop rdi
0000796caedd917c  pop rdx
0000796caedd917d  pop rcx
0000796caedd917e  pop rax
0000796caedd917f  add rsp, 0x08
0000796caedd9183  jmp 0x0000796CAEDD61DC
0000796caedd9188  sub rsp, 0x08
0000796caedd918c  push rax
0000796caedd918d  push rcx
0000796caedd918e  push rdx
0000796caedd918f  push rdi
0000796caedd9190  push rsi
0000796caedd9191  push r8
0000796caedd9193  push r9
0000796caedd9195  push r10
0000796caedd9197  push r11
0000796caedd9199  sub rsp, 0xF0
0000796caedd91a0  vmovaps [rsp], xmm0
0000796caedd91a5  vmovaps [rsp+0x10], xmm1
0000796caedd91ab  vmovaps [rsp+0x20], xmm2
0000796caedd91b1  vmovaps [rsp+0x30], xmm3
0000796caedd91b7  vmovaps [rsp+0x40], xmm4
0000796caedd91bd  vmovaps [rsp+0x50], xmm6
0000796caedd91c3  vmovaps [rsp+0x60], xmm7
0000796caedd91c9  vmovaps [rsp+0x70], xmm8
0000796caedd91cf  vmovaps [rsp+0x80], xmm9
0000796caedd91d8  vmovaps [rsp+0x90], xmm10
0000796caedd91e1  vmovaps [rsp+0xA0], xmm11
0000796caedd91ea  vmovaps [rsp+0xB0], xmm12
0000796caedd91f3  vmovaps [rsp+0xC0], xmm13
0000796caedd91fc  vmovaps [rsp+0xD0], xmm14
0000796caedd9205  vmovaps [rsp+0xE0], xmm15
0000796caedd920e  sub rsp, 0x30
0000796caedd9212  movaps [rsp], xmm5
0000796caedd9216  movaps [rsp+0x10], xmm8
0000796caedd921c  movaps [rsp+0x20], xmm6
0000796caedd9221  lea rdi, [rsp]
0000796caedd9225  mov esi, 0x00
0000796caedd922a  mov rax, 0x56877063A530
0000796caedd9234  call rax
0000796caedd9236  movaps xmm5, [rsp]
0000796caedd923a  add rsp, 0x30
0000796caedd923e  vmovaps xmm0, [rsp]
0000796caedd9243  vmovaps xmm1, [rsp+0x10]
0000796caedd9249  vmovaps xmm2, [rsp+0x20]
0000796caedd924f  vmovaps xmm3, [rsp+0x30]
0000796caedd9255  vmovaps xmm4, [rsp+0x40]
0000796caedd925b  vmovaps xmm6, [rsp+0x50]
0000796caedd9261  vmovaps xmm7, [rsp+0x60]
0000796caedd9267  vmovaps xmm8, [rsp+0x70]
0000796caedd926d  vmovaps xmm9, [rsp+0x80]
0000796caedd9276  vmovaps xmm10, [rsp+0x90]
0000796caedd927f  vmovaps xmm11, [rsp+0xA0]
0000796caedd9288  vmovaps xmm12, [rsp+0xB0]
0000796caedd9291  vmovaps xmm13, [rsp+0xC0]
0000796caedd929a  vmovaps xmm14, [rsp+0xD0]
0000796caedd92a3  vmovaps xmm15, [rsp+0xE0]
0000796caedd92ac  add rsp, 0xF0
0000796caedd92b3  pop r11
0000796caedd92b5  pop r10
0000796caedd92b7  pop r9
0000796caedd92b9  pop r8
0000796caedd92bb  pop rsi
0000796caedd92bc  pop rdi
0000796caedd92bd  pop rdx
0000796caedd92be  pop rcx
0000796caedd92bf  pop rax
0000796caedd92c0  add rsp, 0x08
0000796caedd92c4  jmp 0x0000796CAEDD6200
0000796caedd92c9  sub rsp, 0x08
0000796caedd92cd  push rax
0000796caedd92ce  push rcx
0000796caedd92cf  push rdx
0000796caedd92d0  push rdi
0000796caedd92d1  push rsi
0000796caedd92d2  push r8
0000796caedd92d4  push r9
0000796caedd92d6  push r10
0000796caedd92d8  push r11
0000796caedd92da  sub rsp, 0xF0
0000796caedd92e1  vmovaps [rsp], xmm0
0000796caedd92e6  vmovaps [rsp+0x10], xmm1
0000796caedd92ec  vmovaps [rsp+0x20], xmm2
0000796caedd92f2  vmovaps [rsp+0x30], xmm3
0000796caedd92f8  vmovaps [rsp+0x40], xmm4
0000796caedd92fe  vmovaps [rsp+0x50], xmm5
0000796caedd9304  vmovaps [rsp+0x60], xmm7
0000796caedd930a  vmovaps [rsp+0x70], xmm8
0000796caedd9310  vmovaps [rsp+0x80], xmm9
0000796caedd9319  vmovaps [rsp+0x90], xmm10
0000796caedd9322  vmovaps [rsp+0xA0], xmm11
0000796caedd932b  vmovaps [rsp+0xB0], xmm12
0000796caedd9334  vmovaps [rsp+0xC0], xmm13
0000796caedd933d  vmovaps [rsp+0xD0], xmm14
0000796caedd9346  vmovaps [rsp+0xE0], xmm15
0000796caedd934f  sub rsp, 0x30
0000796caedd9353  movaps [rsp], xmm6
0000796caedd9357  movaps [rsp+0x10], xmm10
0000796caedd935d  movaps [rsp+0x20], xmm8
0000796caedd9363  lea rdi, [rsp]
0000796caedd9367  mov esi, 0x00
0000796caedd936c  mov rax, 0x56877063A530
0000796caedd9376  call rax
0000796caedd9378  movaps xmm6, [rsp]
0000796caedd937c  add rsp, 0x30
0000796caedd9380  vmovaps xmm0, [rsp]
0000796caedd9385  vmovaps xmm1, [rsp+0x10]
0000796caedd938b  vmovaps xmm2, [rsp+0x20]
0000796caedd9391  vmovaps xmm3, [rsp+0x30]
0000796caedd9397  vmovaps xmm4, [rsp+0x40]
0000796caedd939d  vmovaps xmm5, [rsp+0x50]
0000796caedd93a3  vmovaps xmm7, [rsp+0x60]
0000796caedd93a9  vmovaps xmm8, [rsp+0x70]
0000796caedd93af  vmovaps xmm9, [rsp+0x80]
0000796caedd93b8  vmovaps xmm10, [rsp+0x90]
0000796caedd93c1  vmovaps xmm11, [rsp+0xA0]
0000796caedd93ca  vmovaps xmm12, [rsp+0xB0]
0000796caedd93d3  vmovaps xmm13, [rsp+0xC0]
0000796caedd93dc  vmovaps xmm14, [rsp+0xD0]
0000796caedd93e5  vmovaps xmm15, [rsp+0xE0]
0000796caedd93ee  add rsp, 0xF0
0000796caedd93f5  pop r11
0000796caedd93f7  pop r10
0000796caedd93f9  pop r9
0000796caedd93fb  pop r8
0000796caedd93fd  pop rsi
0000796caedd93fe  pop rdi
0000796caedd93ff  pop rdx
0000796caedd9400  pop rcx
0000796caedd9401  pop rax
0000796caedd9402  add rsp, 0x08
0000796caedd9406  jmp 0x0000796CAEDD6225
0000796caedd940b  sub rsp, 0x08
0000796caedd940f  push rax
0000796caedd9410  push rcx
0000796caedd9411  push rdx
0000796caedd9412  push rdi
0000796caedd9413  push rsi
0000796caedd9414  push r8
0000796caedd9416  push r9
0000796caedd9418  push r10
0000796caedd941a  push r11
0000796caedd941c  sub rsp, 0xF0
0000796caedd9423  vmovaps [rsp], xmm0
0000796caedd9428  vmovaps [rsp+0x10], xmm1
0000796caedd942e  vmovaps [rsp+0x20], xmm2
0000796caedd9434  vmovaps [rsp+0x30], xmm3
0000796caedd943a  vmovaps [rsp+0x40], xmm4
0000796caedd9440  vmovaps [rsp+0x50], xmm5
0000796caedd9446  vmovaps [rsp+0x60], xmm6
0000796caedd944c  vmovaps [rsp+0x70], xmm7
0000796caedd9452  vmovaps [rsp+0x80], xmm8
0000796caedd945b  vmovaps [rsp+0x90], xmm9
0000796caedd9464  vmovaps [rsp+0xA0], xmm11
0000796caedd946d  vmovaps [rsp+0xB0], xmm12
0000796caedd9476  vmovaps [rsp+0xC0], xmm13
0000796caedd947f  vmovaps [rsp+0xD0], xmm14
0000796caedd9488  vmovaps [rsp+0xE0], xmm15
0000796caedd9491  sub rsp, 0x30
0000796caedd9495  movaps [rsp], xmm10
0000796caedd949a  movaps [rsp+0x10], xmm8
0000796caedd94a0  movaps [rsp+0x20], xmm14
0000796caedd94a6  lea rdi, [rsp]
0000796caedd94aa  mov esi, 0x00
0000796caedd94af  mov rax, 0x56877063A530
0000796caedd94b9  call rax
0000796caedd94bb  movaps xmm10, [rsp]
0000796caedd94c0  add rsp, 0x30
0000796caedd94c4  vmovaps xmm0, [rsp]
0000796caedd94c9  vmovaps xmm1, [rsp+0x10]
0000796caedd94cf  vmovaps xmm2, [rsp+0x20]
0000796caedd94d5  vmovaps xmm3, [rsp+0x30]
0000796caedd94db  vmovaps xmm4, [rsp+0x40]
0000796caedd94e1  vmovaps xmm5, [rsp+0x50]
0000796caedd94e7  vmovaps xmm6, [rsp+0x60]
0000796caedd94ed  vmovaps xmm7, [rsp+0x70]
0000796caedd94f3  vmovaps xmm8, [rsp+0x80]
0000796caedd94fc  vmovaps xmm9, [rsp+0x90]
0000796caedd9505  vmovaps xmm11, [rsp+0xA0]
0000796caedd950e  vmovaps xmm12, [rsp+0xB0]
0000796caedd9517  vmovaps xmm13, [rsp+0xC0]
0000796caedd9520  vmovaps xmm14, [rsp+0xD0]
0000796caedd9529  vmovaps xmm15, [rsp+0xE0]
0000796caedd9532  add rsp, 0xF0
0000796caedd9539  pop r11
0000796caedd953b  pop r10
0000796caedd953d  pop r9
0000796caedd953f  pop r8
0000796caedd9541  pop rsi
0000796caedd9542  pop rdi
0000796caedd9543  pop rdx
0000796caedd9544  pop rcx
0000796caedd9545  pop rax
0000796caedd9546  add rsp, 0x08
0000796caedd954a  jmp 0x0000796CAEDD6245
0000796caedd954f  sub rsp, 0x08
0000796caedd9553  push rax
0000796caedd9554  push rcx
0000796caedd9555  push rdx
0000796caedd9556  push rdi
0000796caedd9557  push rsi
0000796caedd9558  push r8
0000796caedd955a  push r9
0000796caedd955c  push r10
0000796caedd955e  push r11
0000796caedd9560  sub rsp, 0xF0
0000796caedd9567  vmovaps [rsp], xmm0
0000796caedd956c  vmovaps [rsp+0x10], xmm1
0000796caedd9572  vmovaps [rsp+0x20], xmm2
0000796caedd9578  vmovaps [rsp+0x30], xmm3
0000796caedd957e  vmovaps [rsp+0x40], xmm4
0000796caedd9584  vmovaps [rsp+0x50], xmm5
0000796caedd958a  vmovaps [rsp+0x60], xmm6
0000796caedd9590  vmovaps [rsp+0x70], xmm7
0000796caedd9596  vmovaps [rsp+0x80], xmm8
0000796caedd959f  vmovaps [rsp+0x90], xmm9
0000796caedd95a8  vmovaps [rsp+0xA0], xmm10
0000796caedd95b1  vmovaps [rsp+0xB0], xmm11
0000796caedd95ba  vmovaps [rsp+0xC0], xmm12
0000796caedd95c3  vmovaps [rsp+0xD0], xmm13
0000796caedd95cc  vmovaps [rsp+0xE0], xmm15
0000796caedd95d5  sub rsp, 0x30
0000796caedd95d9  movaps [rsp], xmm14
0000796caedd95de  movaps [rsp+0x10], xmm8
0000796caedd95e4  movaps [rsp+0x20], xmm4
0000796caedd95e9  lea rdi, [rsp]
0000796caedd95ed  mov esi, 0x00
0000796caedd95f2  mov rax, 0x56877063A530
0000796caedd95fc  call rax
0000796caedd95fe  movaps xmm14, [rsp]
0000796caedd9603  add rsp, 0x30
0000796caedd9607  vmovaps xmm0, [rsp]
0000796caedd960c  vmovaps xmm1, [rsp+0x10]
0000796caedd9612  vmovaps xmm2, [rsp+0x20]
0000796caedd9618  vmovaps xmm3, [rsp+0x30]
0000796caedd961e  vmovaps xmm4, [rsp+0x40]
0000796caedd9624  vmovaps xmm5, [rsp+0x50]
0000796caedd962a  vmovaps xmm6, [rsp+0x60]
0000796caedd9630  vmovaps xmm7, [rsp+0x70]
0000796caedd9636  vmovaps xmm8, [rsp+0x80]
0000796caedd963f  vmovaps xmm9, [rsp+0x90]
0000796caedd9648  vmovaps xmm10, [rsp+0xA0]
0000796caedd9651  vmovaps xmm11, [rsp+0xB0]
0000796caedd965a  vmovaps xmm12, [rsp+0xC0]
0000796caedd9663  vmovaps xmm13, [rsp+0xD0]
0000796caedd966c  vmovaps xmm15, [rsp+0xE0]
0000796caedd9675  add rsp, 0xF0
0000796caedd967c  pop r11
0000796caedd967e  pop r10
0000796caedd9680  pop r9
0000796caedd9682  pop r8
0000796caedd9684  pop rsi
0000796caedd9685  pop rdi
0000796caedd9686  pop rdx
0000796caedd9687  pop rcx
0000796caedd9688  pop rax
0000796caedd9689  add rsp, 0x08
0000796caedd968d  jmp 0x0000796CAEDD6265
0000796caedd9692  sub rsp, 0x08
0000796caedd9696  push rax
0000796caedd9697  push rcx
0000796caedd9698  push rdx
0000796caedd9699  push rdi
0000796caedd969a  push rsi
0000796caedd969b  push r8
0000796caedd969d  push r9
0000796caedd969f  push r10
0000796caedd96a1  push r11
0000796caedd96a3  sub rsp, 0xF0
0000796caedd96aa  vmovaps [rsp], xmm0
0000796caedd96af  vmovaps [rsp+0x10], xmm1
0000796caedd96b5  vmovaps [rsp+0x20], xmm2
0000796caedd96bb  vmovaps [rsp+0x30], xmm3
0000796caedd96c1  vmovaps [rsp+0x40], xmm5
0000796caedd96c7  vmovaps [rsp+0x50], xmm6
0000796caedd96cd  vmovaps [rsp+0x60], xmm7
0000796caedd96d3  vmovaps [rsp+0x70], xmm8
0000796caedd96d9  vmovaps [rsp+0x80], xmm9
0000796caedd96e2  vmovaps [rsp+0x90], xmm10
0000796caedd96eb  vmovaps [rsp+0xA0], xmm11
0000796caedd96f4  vmovaps [rsp+0xB0], xmm12
0000796caedd96fd  vmovaps [rsp+0xC0], xmm13
0000796caedd9706  vmovaps [rsp+0xD0], xmm14
0000796caedd970f  vmovaps [rsp+0xE0], xmm15
0000796caedd9718  sub rsp, 0x30
0000796caedd971c  movaps [rsp], xmm4
0000796caedd9720  movaps [rsp+0x10], xmm13
0000796caedd9726  movaps [rsp+0x20], xmm8
0000796caedd972c  lea rdi, [rsp]
0000796caedd9730  mov esi, 0x00
0000796caedd9735  mov rax, 0x56877063A530
0000796caedd973f  call rax
0000796caedd9741  movaps xmm4, [rsp]
0000796caedd9745  add rsp, 0x30
0000796caedd9749  vmovaps xmm0, [rsp]
0000796caedd974e  vmovaps xmm1, [rsp+0x10]
0000796caedd9754  vmovaps xmm2, [rsp+0x20]
0000796caedd975a  vmovaps xmm3, [rsp+0x30]
0000796caedd9760  vmovaps xmm5, [rsp+0x40]
0000796caedd9766  vmovaps xmm6, [rsp+0x50]
0000796caedd976c  vmovaps xmm7, [rsp+0x60]
0000796caedd9772  vmovaps xmm8, [rsp+0x70]
0000796caedd9778  vmovaps xmm9, [rsp+0x80]
0000796caedd9781  vmovaps xmm10, [rsp+0x90]
0000796caedd978a  vmovaps xmm11, [rsp+0xA0]
0000796caedd9793  vmovaps xmm12, [rsp+0xB0]
0000796caedd979c  vmovaps xmm13, [rsp+0xC0]
0000796caedd97a5  vmovaps xmm14, [rsp+0xD0]
0000796caedd97ae  vmovaps xmm15, [rsp+0xE0]
0000796caedd97b7  add rsp, 0xF0
0000796caedd97be  pop r11
0000796caedd97c0  pop r10
0000796caedd97c2  pop r9
0000796caedd97c4  pop r8
0000796caedd97c6  pop rsi
0000796caedd97c7  pop rdi
0000796caedd97c8  pop rdx
0000796caedd97c9  pop rcx
0000796caedd97ca  pop rax
0000796caedd97cb  add rsp, 0x08
0000796caedd97cf  jmp 0x0000796CAEDD628A
0000796caedd97d4  sub rsp, 0x08
0000796caedd97d8  push rax
0000796caedd97d9  push rcx
0000796caedd97da  push rdx
0000796caedd97db  push rdi
0000796caedd97dc  push rsi
0000796caedd97dd  push r8
0000796caedd97df  push r9
0000796caedd97e1  push r10
0000796caedd97e3  push r11
0000796caedd97e5  sub rsp, 0xF0
0000796caedd97ec  vmovaps [rsp], xmm0
0000796caedd97f1  vmovaps [rsp+0x10], xmm1
0000796caedd97f7  vmovaps [rsp+0x20], xmm2
0000796caedd97fd  vmovaps [rsp+0x30], xmm3
0000796caedd9803  vmovaps [rsp+0x40], xmm4
0000796caedd9809  vmovaps [rsp+0x50], xmm5
0000796caedd980f  vmovaps [rsp+0x60], xmm6
0000796caedd9815  vmovaps [rsp+0x70], xmm7
0000796caedd981b  vmovaps [rsp+0x80], xmm8
0000796caedd9824  vmovaps [rsp+0x90], xmm9
0000796caedd982d  vmovaps [rsp+0xA0], xmm10
0000796caedd9836  vmovaps [rsp+0xB0], xmm11
0000796caedd983f  vmovaps [rsp+0xC0], xmm12
0000796caedd9848  vmovaps [rsp+0xD0], xmm14
0000796caedd9851  vmovaps [rsp+0xE0], xmm15
0000796caedd985a  sub rsp, 0x30
0000796caedd985e  movaps [rsp], xmm13
0000796caedd9863  movaps [rsp+0x10], xmm15
0000796caedd9869  movaps [rsp+0x20], xmm9
0000796caedd986f  lea rdi, [rsp]
0000796caedd9873  mov esi, 0x00
0000796caedd9878  mov rax, 0x56877063A530
0000796caedd9882  call rax
0000796caedd9884  movaps xmm13, [rsp]
0000796caedd9889  add rsp, 0x30
0000796caedd988d  vmovaps xmm0, [rsp]
0000796caedd9892  vmovaps xmm1, [rsp+0x10]
0000796caedd9898  vmovaps xmm2, [rsp+0x20]
0000796caedd989e  vmovaps xmm3, [rsp+0x30]
0000796caedd98a4  vmovaps xmm4, [rsp+0x40]
0000796caedd98aa  vmovaps xmm5, [rsp+0x50]
0000796caedd98b0  vmovaps xmm6, [rsp+0x60]
0000796caedd98b6  vmovaps xmm7, [rsp+0x70]
0000796caedd98bc  vmovaps xmm8, [rsp+0x80]
0000796caedd98c5  vmovaps xmm9, [rsp+0x90]
0000796caedd98ce  vmovaps xmm10, [rsp+0xA0]
0000796caedd98d7  vmovaps xmm11, [rsp+0xB0]
0000796caedd98e0  vmovaps xmm12, [rsp+0xC0]
0000796caedd98e9  vmovaps xmm14, [rsp+0xD0]
0000796caedd98f2  vmovaps xmm15, [rsp+0xE0]
0000796caedd98fb  add rsp, 0xF0
0000796caedd9902  pop r11
0000796caedd9904  pop r10
0000796caedd9906  pop r9
0000796caedd9908  pop r8
0000796caedd990a  pop rsi
0000796caedd990b  pop rdi
0000796caedd990c  pop rdx
0000796caedd990d  pop rcx
0000796caedd990e  pop rax
0000796caedd990f  add rsp, 0x08
0000796caedd9913  jmp 0x0000796CAEDD62A5
0000796caedd9918  sub rsp, 0x08
0000796caedd991c  push rax
0000796caedd991d  push rcx
0000796caedd991e  push rdx
0000796caedd991f  push rdi
0000796caedd9920  push rsi
0000796caedd9921  push r8
0000796caedd9923  push r9
0000796caedd9925  push r10
0000796caedd9927  push r11
0000796caedd9929  sub rsp, 0xF0
0000796caedd9930  vmovaps [rsp], xmm0
0000796caedd9935  vmovaps [rsp+0x10], xmm1
0000796caedd993b  vmovaps [rsp+0x20], xmm2
0000796caedd9941  vmovaps [rsp+0x30], xmm3
0000796caedd9947  vmovaps [rsp+0x40], xmm4
0000796caedd994d  vmovaps [rsp+0x50], xmm5
0000796caedd9953  vmovaps [rsp+0x60], xmm6
0000796caedd9959  vmovaps [rsp+0x70], xmm7
0000796caedd995f  vmovaps [rsp+0x80], xmm8
0000796caedd9968  vmovaps [rsp+0x90], xmm9
0000796caedd9971  vmovaps [rsp+0xA0], xmm10
0000796caedd997a  vmovaps [rsp+0xB0], xmm11
0000796caedd9983  vmovaps [rsp+0xC0], xmm12
0000796caedd998c  vmovaps [rsp+0xD0], xmm13
0000796caedd9995  vmovaps [rsp+0xE0], xmm14
0000796caedd999e  sub rsp, 0x30
0000796caedd99a2  movaps [rsp], xmm15
0000796caedd99a7  movaps [rsp+0x10], xmm1
0000796caedd99ac  movaps [rsp+0x20], xmm5
0000796caedd99b1  lea rdi, [rsp]
0000796caedd99b5  mov esi, 0x00
0000796caedd99ba  mov rax, 0x56877063A530
0000796caedd99c4  call rax
0000796caedd99c6  movaps xmm15, [rsp]
0000796caedd99cb  add rsp, 0x30
0000796caedd99cf  vmovaps xmm0, [rsp]
0000796caedd99d4  vmovaps xmm1, [rsp+0x10]
0000796caedd99da  vmovaps xmm2, [rsp+0x20]
0000796caedd99e0  vmovaps xmm3, [rsp+0x30]
0000796caedd99e6  vmovaps xmm4, [rsp+0x40]
0000796caedd99ec  vmovaps xmm5, [rsp+0x50]
0000796caedd99f2  vmovaps xmm6, [rsp+0x60]
0000796caedd99f8  vmovaps xmm7, [rsp+0x70]
0000796caedd99fe  vmovaps xmm8, [rsp+0x80]
0000796caedd9a07  vmovaps xmm9, [rsp+0x90]
0000796caedd9a10  vmovaps xmm10, [rsp+0xA0]
0000796caedd9a19  vmovaps xmm11, [rsp+0xB0]
0000796caedd9a22  vmovaps xmm12, [rsp+0xC0]
0000796caedd9a2b  vmovaps xmm13, [rsp+0xD0]
0000796caedd9a34  vmovaps xmm14, [rsp+0xE0]
0000796caedd9a3d  add rsp, 0xF0
0000796caedd9a44  pop r11
0000796caedd9a46  pop r10
0000796caedd9a48  pop r9
0000796caedd9a4a  pop r8
0000796caedd9a4c  pop rsi
0000796caedd9a4d  pop rdi
0000796caedd9a4e  pop rdx
0000796caedd9a4f  pop rcx
0000796caedd9a50  pop rax
0000796caedd9a51  add rsp, 0x08
0000796caedd9a55  jmp 0x0000796CAEDD62C0
0000796caedd9a5a  call 0x0000796CAECD64F0
0000796caedd9a5f  jmp 0x0000796CAEDD631B
0000796caedd9a64  sub rsp, 0x08
0000796caedd9a68  push rax
0000796caedd9a69  push rcx
0000796caedd9a6a  push rdx
0000796caedd9a6b  push rdi
0000796caedd9a6c  push rsi
0000796caedd9a6d  push r8
0000796caedd9a6f  push r9
0000796caedd9a71  push r10
0000796caedd9a73  push r11
0000796caedd9a75  sub rsp, 0xF0
0000796caedd9a7c  vmovaps [rsp], xmm0
0000796caedd9a81  vmovaps [rsp+0x10], xmm1
0000796caedd9a87  vmovaps [rsp+0x20], xmm2
0000796caedd9a8d  vmovaps [rsp+0x30], xmm3
0000796caedd9a93  vmovaps [rsp+0x40], xmm4
0000796caedd9a99  vmovaps [rsp+0x50], xmm5
0000796caedd9a9f  vmovaps [rsp+0x60], xmm6
0000796caedd9aa5  vmovaps [rsp+0x70], xmm7
0000796caedd9aab  vmovaps [rsp+0x80], xmm8
0000796caedd9ab4  vmovaps [rsp+0x90], xmm10
0000796caedd9abd  vmovaps [rsp+0xA0], xmm11
0000796caedd9ac6  vmovaps [rsp+0xB0], xmm12
0000796caedd9acf  vmovaps [rsp+0xC0], xmm13
0000796caedd9ad8  vmovaps [rsp+0xD0], xmm14
0000796caedd9ae1  vmovaps [rsp+0xE0], xmm15
0000796caedd9aea  sub rsp, 0x30
0000796caedd9aee  movaps [rsp], xmm9
0000796caedd9af3  movaps [rsp+0x10], xmm8
0000796caedd9af9  movaps [rsp+0x20], xmm11
0000796caedd9aff  lea rdi, [rsp]
0000796caedd9b03  mov esi, 0x00
0000796caedd9b08  mov rax, 0x56877063A530
0000796caedd9b12  call rax
0000796caedd9b14  movaps xmm9, [rsp]
0000796caedd9b19  add rsp, 0x30
0000796caedd9b1d  vmovaps xmm0, [rsp]
0000796caedd9b22  vmovaps xmm1, [rsp+0x10]
0000796caedd9b28  vmovaps xmm2, [rsp+0x20]
0000796caedd9b2e  vmovaps xmm3, [rsp+0x30]
0000796caedd9b34  vmovaps xmm4, [rsp+0x40]
0000796caedd9b3a  vmovaps xmm5, [rsp+0x50]
0000796caedd9b40  vmovaps xmm6, [rsp+0x60]
0000796caedd9b46  vmovaps xmm7, [rsp+0x70]
0000796caedd9b4c  vmovaps xmm8, [rsp+0x80]
0000796caedd9b55  vmovaps xmm10, [rsp+0x90]
0000796caedd9b5e  vmovaps xmm11, [rsp+0xA0]
0000796caedd9b67  vmovaps xmm12, [rsp+0xB0]
0000796caedd9b70  vmovaps xmm13, [rsp+0xC0]
0000796caedd9b79  vmovaps xmm14, [rsp+0xD0]
0000796caedd9b82  vmovaps xmm15, [rsp+0xE0]
0000796caedd9b8b  add rsp, 0xF0
0000796caedd9b92  pop r11
0000796caedd9b94  pop r10
0000796caedd9b96  pop r9
0000796caedd9b98  pop r8
0000796caedd9b9a  pop rsi
0000796caedd9b9b  pop rdi
0000796caedd9b9c  pop rdx
0000796caedd9b9d  pop rcx
0000796caedd9b9e  pop rax
0000796caedd9b9f  add rsp, 0x08
0000796caedd9ba3  jmp 0x0000796CAEDD6352
0000796caedd9ba8  sub rsp, 0x08
0000796caedd9bac  push rax
0000796caedd9bad  push rcx
0000796caedd9bae  push rdx
0000796caedd9baf  push rdi
0000796caedd9bb0  push rsi
0000796caedd9bb1  push r8
0000796caedd9bb3  push r9
0000796caedd9bb5  push r10
0000796caedd9bb7  push r11
0000796caedd9bb9  sub rsp, 0xF0
0000796caedd9bc0  vmovaps [rsp], xmm0
0000796caedd9bc5  vmovaps [rsp+0x10], xmm1
0000796caedd9bcb  vmovaps [rsp+0x20], xmm2
0000796caedd9bd1  vmovaps [rsp+0x30], xmm3
0000796caedd9bd7  vmovaps [rsp+0x40], xmm4
0000796caedd9bdd  vmovaps [rsp+0x50], xmm5
0000796caedd9be3  vmovaps [rsp+0x60], xmm6
0000796caedd9be9  vmovaps [rsp+0x70], xmm7
0000796caedd9bef  vmovaps [rsp+0x80], xmm8
0000796caedd9bf8  vmovaps [rsp+0x90], xmm9
0000796caedd9c01  vmovaps [rsp+0xA0], xmm10
0000796caedd9c0a  vmovaps [rsp+0xB0], xmm12
0000796caedd9c13  vmovaps [rsp+0xC0], xmm13
0000796caedd9c1c  vmovaps [rsp+0xD0], xmm14
0000796caedd9c25  vmovaps [rsp+0xE0], xmm15
0000796caedd9c2e  sub rsp, 0x30
0000796caedd9c32  movaps [rsp], xmm11
0000796caedd9c37  movaps [rsp+0x10], xmm10
0000796caedd9c3d  movaps [rsp+0x20], xmm6
0000796caedd9c42  lea rdi, [rsp]
0000796caedd9c46  mov esi, 0x00
0000796caedd9c4b  mov rax, 0x56877063A530
0000796caedd9c55  call rax
0000796caedd9c57  movaps xmm11, [rsp]
0000796caedd9c5c  add rsp, 0x30
0000796caedd9c60  vmovaps xmm0, [rsp]
0000796caedd9c65  vmovaps xmm1, [rsp+0x10]
0000796caedd9c6b  vmovaps xmm2, [rsp+0x20]
0000796caedd9c71  vmovaps xmm3, [rsp+0x30]
0000796caedd9c77  vmovaps xmm4, [rsp+0x40]
0000796caedd9c7d  vmovaps xmm5, [rsp+0x50]
0000796caedd9c83  vmovaps xmm6, [rsp+0x60]
0000796caedd9c89  vmovaps xmm7, [rsp+0x70]
0000796caedd9c8f  vmovaps xmm8, [rsp+0x80]
0000796caedd9c98  vmovaps xmm9, [rsp+0x90]
0000796caedd9ca1  vmovaps xmm10, [rsp+0xA0]
0000796caedd9caa  vmovaps xmm12, [rsp+0xB0]
0000796caedd9cb3  vmovaps xmm13, [rsp+0xC0]
0000796caedd9cbc  vmovaps xmm14, [rsp+0xD0]
0000796caedd9cc5  vmovaps xmm15, [rsp+0xE0]
0000796caedd9cce  add rsp, 0xF0
0000796caedd9cd5  pop r11
0000796caedd9cd7  pop r10
0000796caedd9cd9  pop r9
0000796caedd9cdb  pop r8
0000796caedd9cdd  pop rsi
0000796caedd9cde  pop rdi
0000796caedd9cdf  pop rdx
0000796caedd9ce0  pop rcx
0000796caedd9ce1  pop rax
0000796caedd9ce2  add rsp, 0x08
0000796caedd9ce6  jmp 0x0000796CAEDD636D
0000796caedd9ceb  sub rsp, 0x08
0000796caedd9cef  push rax
0000796caedd9cf0  push rcx
0000796caedd9cf1  push rdx
0000796caedd9cf2  push rdi
0000796caedd9cf3  push rsi
0000796caedd9cf4  push r8
0000796caedd9cf6  push r9
0000796caedd9cf8  push r10
0000796caedd9cfa  push r11
0000796caedd9cfc  sub rsp, 0xF0
0000796caedd9d03  vmovaps [rsp], xmm0
0000796caedd9d08  vmovaps [rsp+0x10], xmm1
0000796caedd9d0e  vmovaps [rsp+0x20], xmm2
0000796caedd9d14  vmovaps [rsp+0x30], xmm3
0000796caedd9d1a  vmovaps [rsp+0x40], xmm4
0000796caedd9d20  vmovaps [rsp+0x50], xmm5
0000796caedd9d26  vmovaps [rsp+0x60], xmm6
0000796caedd9d2c  vmovaps [rsp+0x70], xmm7
0000796caedd9d32  vmovaps [rsp+0x80], xmm8
0000796caedd9d3b  vmovaps [rsp+0x90], xmm9
0000796caedd9d44  vmovaps [rsp+0xA0], xmm11
0000796caedd9d4d  vmovaps [rsp+0xB0], xmm12
0000796caedd9d56  vmovaps [rsp+0xC0], xmm13
0000796caedd9d5f  vmovaps [rsp+0xD0], xmm14
0000796caedd9d68  vmovaps [rsp+0xE0], xmm15
0000796caedd9d71  sub rsp, 0x30
0000796caedd9d75  movaps [rsp], xmm10
0000796caedd9d7a  movaps [rsp+0x10], xmm14
0000796caedd9d80  movaps [rsp+0x20], xmm4
0000796caedd9d85  lea rdi, [rsp]
0000796caedd9d89  mov esi, 0x00
0000796caedd9d8e  mov rax, 0x56877063A530
0000796caedd9d98  call rax
0000796caedd9d9a  movaps xmm10, [rsp]
0000796caedd9d9f  add rsp, 0x30
0000796caedd9da3  vmovaps xmm0, [rsp]
0000796caedd9da8  vmovaps xmm1, [rsp+0x10]
0000796caedd9dae  vmovaps xmm2, [rsp+0x20]
0000796caedd9db4  vmovaps xmm3, [rsp+0x30]
0000796caedd9dba  vmovaps xmm4, [rsp+0x40]
0000796caedd9dc0  vmovaps xmm5, [rsp+0x50]
0000796caedd9dc6  vmovaps xmm6, [rsp+0x60]
0000796caedd9dcc  vmovaps xmm7, [rsp+0x70]
0000796caedd9dd2  vmovaps xmm8, [rsp+0x80]
0000796caedd9ddb  vmovaps xmm9, [rsp+0x90]
0000796caedd9de4  vmovaps xmm11, [rsp+0xA0]
0000796caedd9ded  vmovaps xmm12, [rsp+0xB0]
0000796caedd9df6  vmovaps xmm13, [rsp+0xC0]
0000796caedd9dff  vmovaps xmm14, [rsp+0xD0]
0000796caedd9e08  vmovaps xmm15, [rsp+0xE0]
0000796caedd9e11  add rsp, 0xF0
0000796caedd9e18  pop r11
0000796caedd9e1a  pop r10
0000796caedd9e1c  pop r9
0000796caedd9e1e  pop r8
0000796caedd9e20  pop rsi
0000796caedd9e21  pop rdi
0000796caedd9e22  pop rdx
0000796caedd9e23  pop rcx
0000796caedd9e24  pop rax
0000796caedd9e25  add rsp, 0x08
0000796caedd9e29  jmp 0x0000796CAEDD6388
0000796caedd9e2e  sub rsp, 0x08
0000796caedd9e32  push rax
0000796caedd9e33  push rcx
0000796caedd9e34  push rdx
0000796caedd9e35  push rdi
0000796caedd9e36  push rsi
0000796caedd9e37  push r8
0000796caedd9e39  push r9
0000796caedd9e3b  push r10
0000796caedd9e3d  push r11
0000796caedd9e3f  sub rsp, 0xF0
0000796caedd9e46  vmovaps [rsp], xmm0
0000796caedd9e4b  vmovaps [rsp+0x10], xmm1
0000796caedd9e51  vmovaps [rsp+0x20], xmm2
0000796caedd9e57  vmovaps [rsp+0x30], xmm3
0000796caedd9e5d  vmovaps [rsp+0x40], xmm4
0000796caedd9e63  vmovaps [rsp+0x50], xmm5
0000796caedd9e69  vmovaps [rsp+0x60], xmm6
0000796caedd9e6f  vmovaps [rsp+0x70], xmm7
0000796caedd9e75  vmovaps [rsp+0x80], xmm9
0000796caedd9e7e  vmovaps [rsp+0x90], xmm10
0000796caedd9e87  vmovaps [rsp+0xA0], xmm11
0000796caedd9e90  vmovaps [rsp+0xB0], xmm12
0000796caedd9e99  vmovaps [rsp+0xC0], xmm13
0000796caedd9ea2  vmovaps [rsp+0xD0], xmm14
0000796caedd9eab  vmovaps [rsp+0xE0], xmm15
0000796caedd9eb4  sub rsp, 0x30
0000796caedd9eb8  movaps [rsp], xmm8
0000796caedd9ebd  movaps [rsp+0x10], xmm1
0000796caedd9ec2  movaps [rsp+0x20], xmm14
0000796caedd9ec8  lea rdi, [rsp]
0000796caedd9ecc  mov esi, 0x00
0000796caedd9ed1  mov rax, 0x56877063A530
0000796caedd9edb  call rax
0000796caedd9edd  movaps xmm8, [rsp]
0000796caedd9ee2  add rsp, 0x30
0000796caedd9ee6  vmovaps xmm0, [rsp]
0000796caedd9eeb  vmovaps xmm1, [rsp+0x10]
0000796caedd9ef1  vmovaps xmm2, [rsp+0x20]
0000796caedd9ef7  vmovaps xmm3, [rsp+0x30]
0000796caedd9efd  vmovaps xmm4, [rsp+0x40]
0000796caedd9f03  vmovaps xmm5, [rsp+0x50]
0000796caedd9f09  vmovaps xmm6, [rsp+0x60]
0000796caedd9f0f  vmovaps xmm7, [rsp+0x70]
0000796caedd9f15  vmovaps xmm9, [rsp+0x80]
0000796caedd9f1e  vmovaps xmm10, [rsp+0x90]
0000796caedd9f27  vmovaps xmm11, [rsp+0xA0]
0000796caedd9f30  vmovaps xmm12, [rsp+0xB0]
0000796caedd9f39  vmovaps xmm13, [rsp+0xC0]
0000796caedd9f42  vmovaps xmm14, [rsp+0xD0]
0000796caedd9f4b  vmovaps xmm15, [rsp+0xE0]
0000796caedd9f54  add rsp, 0xF0
0000796caedd9f5b  pop r11
0000796caedd9f5d  pop r10
0000796caedd9f5f  pop r9
0000796caedd9f61  pop r8
0000796caedd9f63  pop rsi
0000796caedd9f64  pop rdi
0000796caedd9f65  pop rdx
0000796caedd9f66  pop rcx
0000796caedd9f67  pop rax
0000796caedd9f68  add rsp, 0x08
0000796caedd9f6c  jmp 0x0000796CAEDD63AE
0000796caedd9f71  sub rsp, 0x08
0000796caedd9f75  push rax
0000796caedd9f76  push rcx
0000796caedd9f77  push rdx
0000796caedd9f78  push rdi
0000796caedd9f79  push rsi
0000796caedd9f7a  push r8
0000796caedd9f7c  push r9
0000796caedd9f7e  push r10
0000796caedd9f80  push r11
0000796caedd9f82  sub rsp, 0xF0
0000796caedd9f89  vmovaps [rsp], xmm0
0000796caedd9f8e  vmovaps [rsp+0x10], xmm1
0000796caedd9f94  vmovaps [rsp+0x20], xmm2
0000796caedd9f9a  vmovaps [rsp+0x30], xmm3
0000796caedd9fa0  vmovaps [rsp+0x40], xmm4
0000796caedd9fa6  vmovaps [rsp+0x50], xmm5
0000796caedd9fac  vmovaps [rsp+0x60], xmm7
0000796caedd9fb2  vmovaps [rsp+0x70], xmm8
0000796caedd9fb8  vmovaps [rsp+0x80], xmm9
0000796caedd9fc1  vmovaps [rsp+0x90], xmm10
0000796caedd9fca  vmovaps [rsp+0xA0], xmm11
0000796caedd9fd3  vmovaps [rsp+0xB0], xmm12
0000796caedd9fdc  vmovaps [rsp+0xC0], xmm13
0000796caedd9fe5  vmovaps [rsp+0xD0], xmm14
0000796caedd9fee  vmovaps [rsp+0xE0], xmm15
0000796caedd9ff7  sub rsp, 0x30
0000796caedd9ffb  movaps [rsp], xmm6
0000796caedd9fff  movaps [rsp+0x10], xmm1
0000796caedda004  movaps [rsp+0x20], xmm14
0000796caedda00a  lea rdi, [rsp]
0000796caedda00e  mov esi, 0x00
0000796caedda013  mov rax, 0x56877063A530
0000796caedda01d  call rax
0000796caedda01f  movaps xmm6, [rsp]
0000796caedda023  add rsp, 0x30
0000796caedda027  vmovaps xmm0, [rsp]
0000796caedda02c  vmovaps xmm1, [rsp+0x10]
0000796caedda032  vmovaps xmm2, [rsp+0x20]
0000796caedda038  vmovaps xmm3, [rsp+0x30]
0000796caedda03e  vmovaps xmm4, [rsp+0x40]
0000796caedda044  vmovaps xmm5, [rsp+0x50]
0000796caedda04a  vmovaps xmm7, [rsp+0x60]
0000796caedda050  vmovaps xmm8, [rsp+0x70]
0000796caedda056  vmovaps xmm9, [rsp+0x80]
0000796caedda05f  vmovaps xmm10, [rsp+0x90]
0000796caedda068  vmovaps xmm11, [rsp+0xA0]
0000796caedda071  vmovaps xmm12, [rsp+0xB0]
0000796caedda07a  vmovaps xmm13, [rsp+0xC0]
0000796caedda083  vmovaps xmm14, [rsp+0xD0]
0000796caedda08c  vmovaps xmm15, [rsp+0xE0]
0000796caedda095  add rsp, 0xF0
0000796caedda09c  pop r11
0000796caedda09e  pop r10
0000796caedda0a0  pop r9
0000796caedda0a2  pop r8
0000796caedda0a4  pop rsi
0000796caedda0a5  pop rdi
0000796caedda0a6  pop rdx
0000796caedda0a7  pop rcx
0000796caedda0a8  pop rax
0000796caedda0a9  add rsp, 0x08
0000796caedda0ad  jmp 0x0000796CAEDD63DA
0000796caedda0b2  sub rsp, 0x08
0000796caedda0b6  push rax
0000796caedda0b7  push rcx
0000796caedda0b8  push rdx
0000796caedda0b9  push rdi
0000796caedda0ba  push rsi
0000796caedda0bb  push r8
0000796caedda0bd  push r9
0000796caedda0bf  push r10
0000796caedda0c1  push r11
0000796caedda0c3  sub rsp, 0xF0
0000796caedda0ca  vmovaps [rsp], xmm0
0000796caedda0cf  vmovaps [rsp+0x10], xmm1
0000796caedda0d5  vmovaps [rsp+0x20], xmm2
0000796caedda0db  vmovaps [rsp+0x30], xmm3
0000796caedda0e1  vmovaps [rsp+0x40], xmm4
0000796caedda0e7  vmovaps [rsp+0x50], xmm5
0000796caedda0ed  vmovaps [rsp+0x60], xmm6
0000796caedda0f3  vmovaps [rsp+0x70], xmm7
0000796caedda0f9  vmovaps [rsp+0x80], xmm8
0000796caedda102  vmovaps [rsp+0x90], xmm9
0000796caedda10b  vmovaps [rsp+0xA0], xmm10
0000796caedda114  vmovaps [rsp+0xB0], xmm11
0000796caedda11d  vmovaps [rsp+0xC0], xmm12
0000796caedda126  vmovaps [rsp+0xD0], xmm13
0000796caedda12f  vmovaps [rsp+0xE0], xmm15
0000796caedda138  sub rsp, 0x30
0000796caedda13c  movaps [rsp], xmm14
0000796caedda141  movaps [rsp+0x10], xmm12
0000796caedda147  movaps [rsp+0x20], xmm1
0000796caedda14c  lea rdi, [rsp]
0000796caedda150  mov esi, 0x00
0000796caedda155  mov rax, 0x56877063A530
0000796caedda15f  call rax
0000796caedda161  movaps xmm14, [rsp]
0000796caedda166  add rsp, 0x30
0000796caedda16a  vmovaps xmm0, [rsp]
0000796caedda16f  vmovaps xmm1, [rsp+0x10]
0000796caedda175  vmovaps xmm2, [rsp+0x20]
0000796caedda17b  vmovaps xmm3, [rsp+0x30]
0000796caedda181  vmovaps xmm4, [rsp+0x40]
0000796caedda187  vmovaps xmm5, [rsp+0x50]
0000796caedda18d  vmovaps xmm6, [rsp+0x60]
0000796caedda193  vmovaps xmm7, [rsp+0x70]
0000796caedda199  vmovaps xmm8, [rsp+0x80]
0000796caedda1a2  vmovaps xmm9, [rsp+0x90]
0000796caedda1ab  vmovaps xmm10, [rsp+0xA0]
0000796caedda1b4  vmovaps xmm11, [rsp+0xB0]
0000796caedda1bd  vmovaps xmm12, [rsp+0xC0]
0000796caedda1c6  vmovaps xmm13, [rsp+0xD0]
0000796caedda1cf  vmovaps xmm15, [rsp+0xE0]
0000796caedda1d8  add rsp, 0xF0
0000796caedda1df  pop r11
0000796caedda1e1  pop r10
0000796caedda1e3  pop r9
0000796caedda1e5  pop r8
0000796caedda1e7  pop rsi
0000796caedda1e8  pop rdi
0000796caedda1e9  pop rdx
0000796caedda1ea  pop rcx
0000796caedda1eb  pop rax
0000796caedda1ec  add rsp, 0x08
0000796caedda1f0  jmp 0x0000796CAEDD6400
0000796caedda1f5  sub rsp, 0x08
0000796caedda1f9  push rax
0000796caedda1fa  push rcx
0000796caedda1fb  push rdx
0000796caedda1fc  push rdi
0000796caedda1fd  push rsi
0000796caedda1fe  push r8
0000796caedda200  push r9
0000796caedda202  push r10
0000796caedda204  push r11
0000796caedda206  sub rsp, 0xF0
0000796caedda20d  vmovaps [rsp], xmm0
0000796caedda212  vmovaps [rsp+0x10], xmm2
0000796caedda218  vmovaps [rsp+0x20], xmm3
0000796caedda21e  vmovaps [rsp+0x30], xmm4
0000796caedda224  vmovaps [rsp+0x40], xmm5
0000796caedda22a  vmovaps [rsp+0x50], xmm6
0000796caedda230  vmovaps [rsp+0x60], xmm7
0000796caedda236  vmovaps [rsp+0x70], xmm8
0000796caedda23c  vmovaps [rsp+0x80], xmm9
0000796caedda245  vmovaps [rsp+0x90], xmm10
0000796caedda24e  vmovaps [rsp+0xA0], xmm11
0000796caedda257  vmovaps [rsp+0xB0], xmm12
0000796caedda260  vmovaps [rsp+0xC0], xmm13
0000796caedda269  vmovaps [rsp+0xD0], xmm14
0000796caedda272  vmovaps [rsp+0xE0], xmm15
0000796caedda27b  sub rsp, 0x30
0000796caedda27f  movaps [rsp], xmm1
0000796caedda283  movaps [rsp+0x10], xmm13
0000796caedda289  movaps [rsp+0x20], xmm9
0000796caedda28f  lea rdi, [rsp]
0000796caedda293  mov esi, 0x00
0000796caedda298  mov rax, 0x56877063A530
0000796caedda2a2  call rax
0000796caedda2a4  movaps xmm1, [rsp]
0000796caedda2a8  add rsp, 0x30
0000796caedda2ac  vmovaps xmm0, [rsp]
0000796caedda2b1  vmovaps xmm2, [rsp+0x10]
0000796caedda2b7  vmovaps xmm3, [rsp+0x20]
0000796caedda2bd  vmovaps xmm4, [rsp+0x30]
0000796caedda2c3  vmovaps xmm5, [rsp+0x40]
0000796caedda2c9  vmovaps xmm6, [rsp+0x50]
0000796caedda2cf  vmovaps xmm7, [rsp+0x60]
0000796caedda2d5  vmovaps xmm8, [rsp+0x70]
0000796caedda2db  vmovaps xmm9, [rsp+0x80]
0000796caedda2e4  vmovaps xmm10, [rsp+0x90]
0000796caedda2ed  vmovaps xmm11, [rsp+0xA0]
0000796caedda2f6  vmovaps xmm12, [rsp+0xB0]
0000796caedda2ff  vmovaps xmm13, [rsp+0xC0]
0000796caedda308  vmovaps xmm14, [rsp+0xD0]
0000796caedda311  vmovaps xmm15, [rsp+0xE0]
0000796caedda31a  add rsp, 0xF0
0000796caedda321  pop r11
0000796caedda323  pop r10
0000796caedda325  pop r9
0000796caedda327  pop r8
0000796caedda329  pop rsi
0000796caedda32a  pop rdi
0000796caedda32b  pop rdx
0000796caedda32c  pop rcx
0000796caedda32d  pop rax
0000796caedda32e  add rsp, 0x08
0000796caedda332  jmp 0x0000796CAEDD641A
0000796caedda337  sub rsp, 0x08
0000796caedda33b  push rax
0000796caedda33c  push rcx
0000796caedda33d  push rdx
0000796caedda33e  push rdi
0000796caedda33f  push rsi
0000796caedda340  push r8
0000796caedda342  push r9
0000796caedda344  push r10
0000796caedda346  push r11
0000796caedda348  sub rsp, 0xF0
0000796caedda34f  vmovaps [rsp], xmm0
0000796caedda354  vmovaps [rsp+0x10], xmm1
0000796caedda35a  vmovaps [rsp+0x20], xmm2
0000796caedda360  vmovaps [rsp+0x30], xmm3
0000796caedda366  vmovaps [rsp+0x40], xmm4
0000796caedda36c  vmovaps [rsp+0x50], xmm5
0000796caedda372  vmovaps [rsp+0x60], xmm6
0000796caedda378  vmovaps [rsp+0x70], xmm7
0000796caedda37e  vmovaps [rsp+0x80], xmm8
0000796caedda387  vmovaps [rsp+0x90], xmm9
0000796caedda390  vmovaps [rsp+0xA0], xmm10
0000796caedda399  vmovaps [rsp+0xB0], xmm11
0000796caedda3a2  vmovaps [rsp+0xC0], xmm13
0000796caedda3ab  vmovaps [rsp+0xD0], xmm14
0000796caedda3b4  vmovaps [rsp+0xE0], xmm15
0000796caedda3bd  sub rsp, 0x30
0000796caedda3c1  movaps [rsp], xmm12
0000796caedda3c6  movaps [rsp+0x10], xmm7
0000796caedda3cb  movaps [rsp+0x20], xmm13
0000796caedda3d1  lea rdi, [rsp]
0000796caedda3d5  mov esi, 0x00
0000796caedda3da  mov rax, 0x56877063A530
0000796caedda3e4  call rax
0000796caedda3e6  movaps xmm12, [rsp]
0000796caedda3eb  add rsp, 0x30
0000796caedda3ef  vmovaps xmm0, [rsp]
0000796caedda3f4  vmovaps xmm1, [rsp+0x10]
0000796caedda3fa  vmovaps xmm2, [rsp+0x20]
0000796caedda400  vmovaps xmm3, [rsp+0x30]
0000796caedda406  vmovaps xmm4, [rsp+0x40]
0000796caedda40c  vmovaps xmm5, [rsp+0x50]
0000796caedda412  vmovaps xmm6, [rsp+0x60]
0000796caedda418  vmovaps xmm7, [rsp+0x70]
0000796caedda41e  vmovaps xmm8, [rsp+0x80]
0000796caedda427  vmovaps xmm9, [rsp+0x90]
0000796caedda430  vmovaps xmm10, [rsp+0xA0]
0000796caedda439  vmovaps xmm11, [rsp+0xB0]
0000796caedda442  vmovaps xmm13, [rsp+0xC0]
0000796caedda44b  vmovaps xmm14, [rsp+0xD0]
0000796caedda454  vmovaps xmm15, [rsp+0xE0]
0000796caedda45d  add rsp, 0xF0
0000796caedda464  pop r11
0000796caedda466  pop r10
0000796caedda468  pop r9
0000796caedda46a  pop r8
0000796caedda46c  pop rsi
0000796caedda46d  pop rdi
0000796caedda46e  pop rdx
0000796caedda46f  pop rcx
0000796caedda470  pop rax
0000796caedda471  add rsp, 0x08
0000796caedda475  jmp 0x0000796CAEDD6441
0000796caedda47a  sub rsp, 0x08
0000796caedda47e  push rax
0000796caedda47f  push rcx
0000796caedda480  push rdx
0000796caedda481  push rdi
0000796caedda482  push rsi
0000796caedda483  push r8
0000796caedda485  push r9
0000796caedda487  push r10
0000796caedda489  push r11
0000796caedda48b  sub rsp, 0xF0
0000796caedda492  vmovaps [rsp], xmm0
0000796caedda497  vmovaps [rsp+0x10], xmm1
0000796caedda49d  vmovaps [rsp+0x20], xmm2
0000796caedda4a3  vmovaps [rsp+0x30], xmm3
0000796caedda4a9  vmovaps [rsp+0x40], xmm4
0000796caedda4af  vmovaps [rsp+0x50], xmm5
0000796caedda4b5  vmovaps [rsp+0x60], xmm6
0000796caedda4bb  vmovaps [rsp+0x70], xmm7
0000796caedda4c1  vmovaps [rsp+0x80], xmm8
0000796caedda4ca  vmovaps [rsp+0x90], xmm9
0000796caedda4d3  vmovaps [rsp+0xA0], xmm10
0000796caedda4dc  vmovaps [rsp+0xB0], xmm11
0000796caedda4e5  vmovaps [rsp+0xC0], xmm12
0000796caedda4ee  vmovaps [rsp+0xD0], xmm14
0000796caedda4f7  vmovaps [rsp+0xE0], xmm15
0000796caedda500  sub rsp, 0x30
0000796caedda504  movaps [rsp], xmm13
0000796caedda509  movaps [rsp+0x10], xmm15
0000796caedda50f  movaps [rsp+0x20], xmm8
0000796caedda515  lea rdi, [rsp]
0000796caedda519  mov esi, 0x00
0000796caedda51e  mov rax, 0x56877063A530
0000796caedda528  call rax
0000796caedda52a  movaps xmm13, [rsp]
0000796caedda52f  add rsp, 0x30
0000796caedda533  vmovaps xmm0, [rsp]
0000796caedda538  vmovaps xmm1, [rsp+0x10]
0000796caedda53e  vmovaps xmm2, [rsp+0x20]
0000796caedda544  vmovaps xmm3, [rsp+0x30]
0000796caedda54a  vmovaps xmm4, [rsp+0x40]
0000796caedda550  vmovaps xmm5, [rsp+0x50]
0000796caedda556  vmovaps xmm6, [rsp+0x60]
0000796caedda55c  vmovaps xmm7, [rsp+0x70]
0000796caedda562  vmovaps xmm8, [rsp+0x80]
0000796caedda56b  vmovaps xmm9, [rsp+0x90]
0000796caedda574  vmovaps xmm10, [rsp+0xA0]
0000796caedda57d  vmovaps xmm11, [rsp+0xB0]
0000796caedda586  vmovaps xmm12, [rsp+0xC0]
0000796caedda58f  vmovaps xmm14, [rsp+0xD0]
0000796caedda598  vmovaps xmm15, [rsp+0xE0]
0000796caedda5a1  add rsp, 0xF0
0000796caedda5a8  pop r11
0000796caedda5aa  pop r10
0000796caedda5ac  pop r9
0000796caedda5ae  pop r8
0000796caedda5b0  pop rsi
0000796caedda5b1  pop rdi
0000796caedda5b2  pop rdx
0000796caedda5b3  pop rcx
0000796caedda5b4  pop rax
0000796caedda5b5  add rsp, 0x08
0000796caedda5b9  jmp 0x0000796CAEDD645C
0000796caedda5be  sub rsp, 0x08
0000796caedda5c2  push rax
0000796caedda5c3  push rcx
0000796caedda5c4  push rdx
0000796caedda5c5  push rdi
0000796caedda5c6  push rsi
0000796caedda5c7  push r8
0000796caedda5c9  push r9
0000796caedda5cb  push r10
0000796caedda5cd  push r11
0000796caedda5cf  sub rsp, 0xF0
0000796caedda5d6  vmovaps [rsp], xmm0
0000796caedda5db  vmovaps [rsp+0x10], xmm1
0000796caedda5e1  vmovaps [rsp+0x20], xmm2
0000796caedda5e7  vmovaps [rsp+0x30], xmm3
0000796caedda5ed  vmovaps [rsp+0x40], xmm4
0000796caedda5f3  vmovaps [rsp+0x50], xmm5
0000796caedda5f9  vmovaps [rsp+0x60], xmm6
0000796caedda5ff  vmovaps [rsp+0x70], xmm7
0000796caedda605  vmovaps [rsp+0x80], xmm9
0000796caedda60e  vmovaps [rsp+0x90], xmm10
0000796caedda617  vmovaps [rsp+0xA0], xmm11
0000796caedda620  vmovaps [rsp+0xB0], xmm12
0000796caedda629  vmovaps [rsp+0xC0], xmm13
0000796caedda632  vmovaps [rsp+0xD0], xmm14
0000796caedda63b  vmovaps [rsp+0xE0], xmm15
0000796caedda644  sub rsp, 0x30
0000796caedda648  movaps [rsp], xmm8
0000796caedda64d  movaps [rsp+0x10], xmm15
0000796caedda653  movaps [rsp+0x20], xmm9
0000796caedda659  lea rdi, [rsp]
0000796caedda65d  mov esi, 0x00
0000796caedda662  mov rax, 0x56877063A530
0000796caedda66c  call rax
0000796caedda66e  movaps xmm8, [rsp]
0000796caedda673  add rsp, 0x30
0000796caedda677  vmovaps xmm0, [rsp]
0000796caedda67c  vmovaps xmm1, [rsp+0x10]
0000796caedda682  vmovaps xmm2, [rsp+0x20]
0000796caedda688  vmovaps xmm3, [rsp+0x30]
0000796caedda68e  vmovaps xmm4, [rsp+0x40]
0000796caedda694  vmovaps xmm5, [rsp+0x50]
0000796caedda69a  vmovaps xmm6, [rsp+0x60]
0000796caedda6a0  vmovaps xmm7, [rsp+0x70]
0000796caedda6a6  vmovaps xmm9, [rsp+0x80]
0000796caedda6af  vmovaps xmm10, [rsp+0x90]
0000796caedda6b8  vmovaps xmm11, [rsp+0xA0]
0000796caedda6c1  vmovaps xmm12, [rsp+0xB0]
0000796caedda6ca  vmovaps xmm13, [rsp+0xC0]
0000796caedda6d3  vmovaps xmm14, [rsp+0xD0]
0000796caedda6dc  vmovaps xmm15, [rsp+0xE0]
0000796caedda6e5  add rsp, 0xF0
0000796caedda6ec  pop r11
0000796caedda6ee  pop r10
0000796caedda6f0  pop r9
0000796caedda6f2  pop r8
0000796caedda6f4  pop rsi
0000796caedda6f5  pop rdi
0000796caedda6f6  pop rdx
0000796caedda6f7  pop rcx
0000796caedda6f8  pop rax
0000796caedda6f9  add rsp, 0x08
0000796caedda6fd  jmp 0x0000796CAEDD648A
0000796caedda702  sub rsp, 0x08
0000796caedda706  push rax
0000796caedda707  push rcx
0000796caedda708  push rdx
0000796caedda709  push rdi
0000796caedda70a  push rsi
0000796caedda70b  push r8
0000796caedda70d  push r9
0000796caedda70f  push r10
0000796caedda711  push r11
0000796caedda713  sub rsp, 0xF0
0000796caedda71a  vmovaps [rsp], xmm0
0000796caedda71f  vmovaps [rsp+0x10], xmm1
0000796caedda725  vmovaps [rsp+0x20], xmm2
0000796caedda72b  vmovaps [rsp+0x30], xmm3
0000796caedda731  vmovaps [rsp+0x40], xmm4
0000796caedda737  vmovaps [rsp+0x50], xmm5
0000796caedda73d  vmovaps [rsp+0x60], xmm6
0000796caedda743  vmovaps [rsp+0x70], xmm7
0000796caedda749  vmovaps [rsp+0x80], xmm8
0000796caedda752  vmovaps [rsp+0x90], xmm9
0000796caedda75b  vmovaps [rsp+0xA0], xmm10
0000796caedda764  vmovaps [rsp+0xB0], xmm11
0000796caedda76d  vmovaps [rsp+0xC0], xmm12
0000796caedda776  vmovaps [rsp+0xD0], xmm13
0000796caedda77f  vmovaps [rsp+0xE0], xmm14
0000796caedda788  sub rsp, 0x30
0000796caedda78c  movaps [rsp], xmm15
0000796caedda791  movaps [rsp+0x10], xmm11
0000796caedda797  movaps [rsp+0x20], xmm6
0000796caedda79c  lea rdi, [rsp]
0000796caedda7a0  mov esi, 0x00
0000796caedda7a5  mov rax, 0x56877063A530
0000796caedda7af  call rax
0000796caedda7b1  movaps xmm15, [rsp]
0000796caedda7b6  add rsp, 0x30
0000796caedda7ba  vmovaps xmm0, [rsp]
0000796caedda7bf  vmovaps xmm1, [rsp+0x10]
0000796caedda7c5  vmovaps xmm2, [rsp+0x20]
0000796caedda7cb  vmovaps xmm3, [rsp+0x30]
0000796caedda7d1  vmovaps xmm4, [rsp+0x40]
0000796caedda7d7  vmovaps xmm5, [rsp+0x50]
0000796caedda7dd  vmovaps xmm6, [rsp+0x60]
0000796caedda7e3  vmovaps xmm7, [rsp+0x70]
0000796caedda7e9  vmovaps xmm8, [rsp+0x80]
0000796caedda7f2  vmovaps xmm9, [rsp+0x90]
0000796caedda7fb  vmovaps xmm10, [rsp+0xA0]
0000796caedda804  vmovaps xmm11, [rsp+0xB0]
0000796caedda80d  vmovaps xmm12, [rsp+0xC0]
0000796caedda816  vmovaps xmm13, [rsp+0xD0]
0000796caedda81f  vmovaps xmm14, [rsp+0xE0]
0000796caedda828  add rsp, 0xF0
0000796caedda82f  pop r11
0000796caedda831  pop r10
0000796caedda833  pop r9
0000796caedda835  pop r8
0000796caedda837  pop rsi
0000796caedda838  pop rdi
0000796caedda839  pop rdx
0000796caedda83a  pop rcx
0000796caedda83b  pop rax
0000796caedda83c  add rsp, 0x08
0000796caedda840  jmp 0x0000796CAEDD64A5
0000796caedda845  sub rsp, 0x08
0000796caedda849  push rax
0000796caedda84a  push rcx
0000796caedda84b  push rdx
0000796caedda84c  push rdi
0000796caedda84d  push rsi
0000796caedda84e  push r8
0000796caedda850  push r9
0000796caedda852  push r10
0000796caedda854  push r11
0000796caedda856  sub rsp, 0xF0
0000796caedda85d  vmovaps [rsp], xmm0
0000796caedda862  vmovaps [rsp+0x10], xmm1
0000796caedda868  vmovaps [rsp+0x20], xmm2
0000796caedda86e  vmovaps [rsp+0x30], xmm3
0000796caedda874  vmovaps [rsp+0x40], xmm4
0000796caedda87a  vmovaps [rsp+0x50], xmm5
0000796caedda880  vmovaps [rsp+0x60], xmm6
0000796caedda886  vmovaps [rsp+0x70], xmm8
0000796caedda88c  vmovaps [rsp+0x80], xmm9
0000796caedda895  vmovaps [rsp+0x90], xmm10
0000796caedda89e  vmovaps [rsp+0xA0], xmm11
0000796caedda8a7  vmovaps [rsp+0xB0], xmm12
0000796caedda8b0  vmovaps [rsp+0xC0], xmm13
0000796caedda8b9  vmovaps [rsp+0xD0], xmm14
0000796caedda8c2  vmovaps [rsp+0xE0], xmm15
0000796caedda8cb  sub rsp, 0x30
0000796caedda8cf  movaps [rsp], xmm7
0000796caedda8d3  movaps [rsp+0x10], xmm11
0000796caedda8d9  movaps [rsp+0x20], xmm9
0000796caedda8df  lea rdi, [rsp]
0000796caedda8e3  mov esi, 0x00
0000796caedda8e8  mov rax, 0x56877063A530
0000796caedda8f2  call rax
0000796caedda8f4  movaps xmm7, [rsp]
0000796caedda8f8  add rsp, 0x30
0000796caedda8fc  vmovaps xmm0, [rsp]
0000796caedda901  vmovaps xmm1, [rsp+0x10]
0000796caedda907  vmovaps xmm2, [rsp+0x20]
0000796caedda90d  vmovaps xmm3, [rsp+0x30]
0000796caedda913  vmovaps xmm4, [rsp+0x40]
0000796caedda919  vmovaps xmm5, [rsp+0x50]
0000796caedda91f  vmovaps xmm6, [rsp+0x60]
0000796caedda925  vmovaps xmm8, [rsp+0x70]
0000796caedda92b  vmovaps xmm9, [rsp+0x80]
0000796caedda934  vmovaps xmm10, [rsp+0x90]
0000796caedda93d  vmovaps xmm11, [rsp+0xA0]
0000796caedda946  vmovaps xmm12, [rsp+0xB0]
0000796caedda94f  vmovaps xmm13, [rsp+0xC0]
0000796caedda958  vmovaps xmm14, [rsp+0xD0]
0000796caedda961  vmovaps xmm15, [rsp+0xE0]
0000796caedda96a  add rsp, 0xF0
0000796caedda971  pop r11
0000796caedda973  pop r10
0000796caedda975  pop r9
0000796caedda977  pop r8
0000796caedda979  pop rsi
0000796caedda97a  pop rdi
0000796caedda97b  pop rdx
0000796caedda97c  pop rcx
0000796caedda97d  pop rax
0000796caedda97e  add rsp, 0x08
0000796caedda982  jmp 0x0000796CAEDD64D2
0000796caedda987  sub rsp, 0x08
0000796caedda98b  push rax
0000796caedda98c  push rcx
0000796caedda98d  push rdx
0000796caedda98e  push rdi
0000796caedda98f  push rsi
0000796caedda990  push r8
0000796caedda992  push r9
0000796caedda994  push r10
0000796caedda996  push r11
0000796caedda998  sub rsp, 0xF0
0000796caedda99f  vmovaps [rsp], xmm0
0000796caedda9a4  vmovaps [rsp+0x10], xmm1
0000796caedda9aa  vmovaps [rsp+0x20], xmm2
0000796caedda9b0  vmovaps [rsp+0x30], xmm3
0000796caedda9b6  vmovaps [rsp+0x40], xmm4
0000796caedda9bc  vmovaps [rsp+0x50], xmm5
0000796caedda9c2  vmovaps [rsp+0x60], xmm6
0000796caedda9c8  vmovaps [rsp+0x70], xmm7
0000796caedda9ce  vmovaps [rsp+0x80], xmm8
0000796caedda9d7  vmovaps [rsp+0x90], xmm9
0000796caedda9e0  vmovaps [rsp+0xA0], xmm10
0000796caedda9e9  vmovaps [rsp+0xB0], xmm12
0000796caedda9f2  vmovaps [rsp+0xC0], xmm13
0000796caedda9fb  vmovaps [rsp+0xD0], xmm14
0000796caeddaa04  vmovaps [rsp+0xE0], xmm15
0000796caeddaa0d  sub rsp, 0x30
0000796caeddaa11  movaps [rsp], xmm11
0000796caeddaa16  movaps [rsp+0x10], xmm10
0000796caeddaa1c  movaps [rsp+0x20], xmm14
0000796caeddaa22  lea rdi, [rsp]
0000796caeddaa26  mov esi, 0x00
0000796caeddaa2b  mov rax, 0x56877063A530
0000796caeddaa35  call rax
0000796caeddaa37  movaps xmm11, [rsp]
0000796caeddaa3c  add rsp, 0x30
0000796caeddaa40  vmovaps xmm0, [rsp]
0000796caeddaa45  vmovaps xmm1, [rsp+0x10]
0000796caeddaa4b  vmovaps xmm2, [rsp+0x20]
0000796caeddaa51  vmovaps xmm3, [rsp+0x30]
0000796caeddaa57  vmovaps xmm4, [rsp+0x40]
0000796caeddaa5d  vmovaps xmm5, [rsp+0x50]
0000796caeddaa63  vmovaps xmm6, [rsp+0x60]
0000796caeddaa69  vmovaps xmm7, [rsp+0x70]
0000796caeddaa6f  vmovaps xmm8, [rsp+0x80]
0000796caeddaa78  vmovaps xmm9, [rsp+0x90]
0000796caeddaa81  vmovaps xmm10, [rsp+0xA0]
0000796caeddaa8a  vmovaps xmm12, [rsp+0xB0]
0000796caeddaa93  vmovaps xmm13, [rsp+0xC0]
0000796caeddaa9c  vmovaps xmm14, [rsp+0xD0]
0000796caeddaaa5  vmovaps xmm15, [rsp+0xE0]
0000796caeddaaae  add rsp, 0xF0
0000796caeddaab5  pop r11
0000796caeddaab7  pop r10
0000796caeddaab9  pop r9
0000796caeddaabb  pop r8
0000796caeddaabd  pop rsi
0000796caeddaabe  pop rdi
0000796caeddaabf  pop rdx
0000796caeddaac0  pop rcx
0000796caeddaac1  pop rax
0000796caeddaac2  add rsp, 0x08
0000796caeddaac6  jmp 0x0000796CAEDD64ED
0000796caeddaacb  call 0x0000796CAECE45A0
0000796caeddaad0  jmp 0x0000796CAEDD64F7
0000796caeddaad5  sub rsp, 0x08
0000796caeddaad9  push rax
0000796caeddaada  push rcx
0000796caeddaadb  push rdx
0000796caeddaadc  push rdi
0000796caeddaadd  push rsi
0000796caeddaade  push r8
0000796caeddaae0  push r9
0000796caeddaae2  push r10
0000796caeddaae4  push r11
0000796caeddaae6  sub rsp, 0xF0
0000796caeddaaed  vmovaps [rsp], xmm0
0000796caeddaaf2  vmovaps [rsp+0x10], xmm1
0000796caeddaaf8  vmovaps [rsp+0x20], xmm2
0000796caeddaafe  vmovaps [rsp+0x30], xmm3
0000796caeddab04  vmovaps [rsp+0x40], xmm4
0000796caeddab0a  vmovaps [rsp+0x50], xmm5
0000796caeddab10  vmovaps [rsp+0x60], xmm6
0000796caeddab16  vmovaps [rsp+0x70], xmm7
0000796caeddab1c  vmovaps [rsp+0x80], xmm8
0000796caeddab25  vmovaps [rsp+0x90], xmm9
0000796caeddab2e  vmovaps [rsp+0xA0], xmm11
0000796caeddab37  vmovaps [rsp+0xB0], xmm12
0000796caeddab40  vmovaps [rsp+0xC0], xmm13
0000796caeddab49  vmovaps [rsp+0xD0], xmm14
0000796caeddab52  vmovaps [rsp+0xE0], xmm15
0000796caeddab5b  sub rsp, 0x30
0000796caeddab5f  movaps [rsp], xmm10
0000796caeddab64  movaps [rsp+0x10], xmm1
0000796caeddab69  movaps [rsp+0x20], xmm12
0000796caeddab6f  lea rdi, [rsp]
0000796caeddab73  mov esi, 0x00
0000796caeddab78  mov rax, 0x56877063A530
0000796caeddab82  call rax
0000796caeddab84  movaps xmm10, [rsp]
0000796caeddab89  add rsp, 0x30
0000796caeddab8d  vmovaps xmm0, [rsp]
0000796caeddab92  vmovaps xmm1, [rsp+0x10]
0000796caeddab98  vmovaps xmm2, [rsp+0x20]
0000796caeddab9e  vmovaps xmm3, [rsp+0x30]
0000796caeddaba4  vmovaps xmm4, [rsp+0x40]
0000796caeddabaa  vmovaps xmm5, [rsp+0x50]
0000796caeddabb0  vmovaps xmm6, [rsp+0x60]
0000796caeddabb6  vmovaps xmm7, [rsp+0x70]
0000796caeddabbc  vmovaps xmm8, [rsp+0x80]
0000796caeddabc5  vmovaps xmm9, [rsp+0x90]
0000796caeddabce  vmovaps xmm11, [rsp+0xA0]
0000796caeddabd7  vmovaps xmm12, [rsp+0xB0]
0000796caeddabe0  vmovaps xmm13, [rsp+0xC0]
0000796caeddabe9  vmovaps xmm14, [rsp+0xD0]
0000796caeddabf2  vmovaps xmm15, [rsp+0xE0]
0000796caeddabfb  add rsp, 0xF0
0000796caeddac02  pop r11
0000796caeddac04  pop r10
0000796caeddac06  pop r9
0000796caeddac08  pop r8
0000796caeddac0a  pop rsi
0000796caeddac0b  pop rdi
0000796caeddac0c  pop rdx
0000796caeddac0d  pop rcx
0000796caeddac0e  pop rax
0000796caeddac0f  add rsp, 0x08
0000796caeddac13  jmp 0x0000796CAEDD651A
0000796caeddac18  sub rsp, 0x08
0000796caeddac1c  push rax
0000796caeddac1d  push rcx
0000796caeddac1e  push rdx
0000796caeddac1f  push rdi
0000796caeddac20  push rsi
0000796caeddac21  push r8
0000796caeddac23  push r9
0000796caeddac25  push r10
0000796caeddac27  push r11
0000796caeddac29  sub rsp, 0xF0
0000796caeddac30  vmovaps [rsp], xmm0
0000796caeddac35  vmovaps [rsp+0x10], xmm1
0000796caeddac3b  vmovaps [rsp+0x20], xmm2
0000796caeddac41  vmovaps [rsp+0x30], xmm3
0000796caeddac47  vmovaps [rsp+0x40], xmm4
0000796caeddac4d  vmovaps [rsp+0x50], xmm5
0000796caeddac53  vmovaps [rsp+0x60], xmm6
0000796caeddac59  vmovaps [rsp+0x70], xmm7
0000796caeddac5f  vmovaps [rsp+0x80], xmm8
0000796caeddac68  vmovaps [rsp+0x90], xmm9
0000796caeddac71  vmovaps [rsp+0xA0], xmm10
0000796caeddac7a  vmovaps [rsp+0xB0], xmm11
0000796caeddac83  vmovaps [rsp+0xC0], xmm13
0000796caeddac8c  vmovaps [rsp+0xD0], xmm14
0000796caeddac95  vmovaps [rsp+0xE0], xmm15
0000796caeddac9e  sub rsp, 0x30
0000796caeddaca2  movaps [rsp], xmm12
0000796caeddaca7  movaps [rsp+0x10], xmm14
0000796caeddacad  movaps [rsp+0x20], xmm1
0000796caeddacb2  lea rdi, [rsp]
0000796caeddacb6  mov esi, 0x00
0000796caeddacbb  mov rax, 0x56877063A530
0000796caeddacc5  call rax
0000796caeddacc7  movaps xmm12, [rsp]
0000796caeddaccc  add rsp, 0x30
0000796caeddacd0  vmovaps xmm0, [rsp]
0000796caeddacd5  vmovaps xmm1, [rsp+0x10]
0000796caeddacdb  vmovaps xmm2, [rsp+0x20]
0000796caeddace1  vmovaps xmm3, [rsp+0x30]
0000796caeddace7  vmovaps xmm4, [rsp+0x40]
0000796caeddaced  vmovaps xmm5, [rsp+0x50]
0000796caeddacf3  vmovaps xmm6, [rsp+0x60]
0000796caeddacf9  vmovaps xmm7, [rsp+0x70]
0000796caeddacff  vmovaps xmm8, [rsp+0x80]
0000796caeddad08  vmovaps xmm9, [rsp+0x90]
0000796caeddad11  vmovaps xmm10, [rsp+0xA0]
0000796caeddad1a  vmovaps xmm11, [rsp+0xB0]
0000796caeddad23  vmovaps xmm13, [rsp+0xC0]
0000796caeddad2c  vmovaps xmm14, [rsp+0xD0]
0000796caeddad35  vmovaps xmm15, [rsp+0xE0]
0000796caeddad3e  add rsp, 0xF0
0000796caeddad45  pop r11
0000796caeddad47  pop r10
0000796caeddad49  pop r9
0000796caeddad4b  pop r8
0000796caeddad4d  pop rsi
0000796caeddad4e  pop rdi
0000796caeddad4f  pop rdx
0000796caeddad50  pop rcx
0000796caeddad51  pop rax
0000796caeddad52  add rsp, 0x08
0000796caeddad56  jmp 0x0000796CAEDD6549
0000796caeddad5b  sub rsp, 0x08
0000796caeddad5f  push rax
0000796caeddad60  push rcx
0000796caeddad61  push rdx
0000796caeddad62  push rdi
0000796caeddad63  push rsi
0000796caeddad64  push r8
0000796caeddad66  push r9
0000796caeddad68  push r10
0000796caeddad6a  push r11
0000796caeddad6c  sub rsp, 0xF0
0000796caeddad73  vmovaps [rsp], xmm0
0000796caeddad78  vmovaps [rsp+0x10], xmm1
0000796caeddad7e  vmovaps [rsp+0x20], xmm2
0000796caeddad84  vmovaps [rsp+0x30], xmm3
0000796caeddad8a  vmovaps [rsp+0x40], xmm4
0000796caeddad90  vmovaps [rsp+0x50], xmm5
0000796caeddad96  vmovaps [rsp+0x60], xmm6
0000796caeddad9c  vmovaps [rsp+0x70], xmm7
0000796caeddada2  vmovaps [rsp+0x80], xmm8
0000796caeddadab  vmovaps [rsp+0x90], xmm9
0000796caeddadb4  vmovaps [rsp+0xA0], xmm10
0000796caeddadbd  vmovaps [rsp+0xB0], xmm11
0000796caeddadc6  vmovaps [rsp+0xC0], xmm12
0000796caeddadcf  vmovaps [rsp+0xD0], xmm13
0000796caeddadd8  vmovaps [rsp+0xE0], xmm15
0000796caeddade1  sub rsp, 0x30
0000796caeddade5  movaps [rsp], xmm14
0000796caeddadea  movaps [rsp+0x10], xmm9
0000796caeddadf0  movaps [rsp+0x20], xmm1
0000796caeddadf5  lea rdi, [rsp]
0000796caeddadf9  mov esi, 0x00
0000796caeddadfe  mov rax, 0x56877063A530
0000796caeddae08  call rax
0000796caeddae0a  movaps xmm14, [rsp]
0000796caeddae0f  add rsp, 0x30
0000796caeddae13  vmovaps xmm0, [rsp]
0000796caeddae18  vmovaps xmm1, [rsp+0x10]
0000796caeddae1e  vmovaps xmm2, [rsp+0x20]
0000796caeddae24  vmovaps xmm3, [rsp+0x30]
0000796caeddae2a  vmovaps xmm4, [rsp+0x40]
0000796caeddae30  vmovaps xmm5, [rsp+0x50]
0000796caeddae36  vmovaps xmm6, [rsp+0x60]
0000796caeddae3c  vmovaps xmm7, [rsp+0x70]
0000796caeddae42  vmovaps xmm8, [rsp+0x80]
0000796caeddae4b  vmovaps xmm9, [rsp+0x90]
0000796caeddae54  vmovaps xmm10, [rsp+0xA0]
0000796caeddae5d  vmovaps xmm11, [rsp+0xB0]
0000796caeddae66  vmovaps xmm12, [rsp+0xC0]
0000796caeddae6f  vmovaps xmm13, [rsp+0xD0]
0000796caeddae78  vmovaps xmm15, [rsp+0xE0]
0000796caeddae81  add rsp, 0xF0
0000796caeddae88  pop r11
0000796caeddae8a  pop r10
0000796caeddae8c  pop r9
0000796caeddae8e  pop r8
0000796caeddae90  pop rsi
0000796caeddae91  pop rdi
0000796caeddae92  pop rdx
0000796caeddae93  pop rcx
0000796caeddae94  pop rax
0000796caeddae95  add rsp, 0x08
0000796caeddae99  jmp 0x0000796CAEDD6578
0000796caeddae9e  sub rsp, 0x08
0000796caeddaea2  push rax
0000796caeddaea3  push rcx
0000796caeddaea4  push rdx
0000796caeddaea5  push rdi
0000796caeddaea6  push rsi
0000796caeddaea7  push r8
0000796caeddaea9  push r9
0000796caeddaeab  push r10
0000796caeddaead  push r11
0000796caeddaeaf  sub rsp, 0xF0
0000796caeddaeb6  vmovaps [rsp], xmm0
0000796caeddaebb  vmovaps [rsp+0x10], xmm2
0000796caeddaec1  vmovaps [rsp+0x20], xmm3
0000796caeddaec7  vmovaps [rsp+0x30], xmm4
0000796caeddaecd  vmovaps [rsp+0x40], xmm5
0000796caeddaed3  vmovaps [rsp+0x50], xmm6
0000796caeddaed9  vmovaps [rsp+0x60], xmm7
0000796caeddaedf  vmovaps [rsp+0x70], xmm8
0000796caeddaee5  vmovaps [rsp+0x80], xmm9
0000796caeddaeee  vmovaps [rsp+0x90], xmm10
0000796caeddaef7  vmovaps [rsp+0xA0], xmm11
0000796caeddaf00  vmovaps [rsp+0xB0], xmm12
0000796caeddaf09  vmovaps [rsp+0xC0], xmm13
0000796caeddaf12  vmovaps [rsp+0xD0], xmm14
0000796caeddaf1b  vmovaps [rsp+0xE0], xmm15
0000796caeddaf24  sub rsp, 0x30
0000796caeddaf28  movaps [rsp], xmm1
0000796caeddaf2c  movaps [rsp+0x10], xmm13
0000796caeddaf32  movaps [rsp+0x20], xmm8
0000796caeddaf38  lea rdi, [rsp]
0000796caeddaf3c  mov esi, 0x00
0000796caeddaf41  mov rax, 0x56877063A530
0000796caeddaf4b  call rax
0000796caeddaf4d  movaps xmm1, [rsp]
0000796caeddaf51  add rsp, 0x30
0000796caeddaf55  vmovaps xmm0, [rsp]
0000796caeddaf5a  vmovaps xmm2, [rsp+0x10]
0000796caeddaf60  vmovaps xmm3, [rsp+0x20]
0000796caeddaf66  vmovaps xmm4, [rsp+0x30]
0000796caeddaf6c  vmovaps xmm5, [rsp+0x40]
0000796caeddaf72  vmovaps xmm6, [rsp+0x50]
0000796caeddaf78  vmovaps xmm7, [rsp+0x60]
0000796caeddaf7e  vmovaps xmm8, [rsp+0x70]
0000796caeddaf84  vmovaps xmm9, [rsp+0x80]
0000796caeddaf8d  vmovaps xmm10, [rsp+0x90]
0000796caeddaf96  vmovaps xmm11, [rsp+0xA0]
0000796caeddaf9f  vmovaps xmm12, [rsp+0xB0]
0000796caeddafa8  vmovaps xmm13, [rsp+0xC0]
0000796caeddafb1  vmovaps xmm14, [rsp+0xD0]
0000796caeddafba  vmovaps xmm15, [rsp+0xE0]
0000796caeddafc3  add rsp, 0xF0
0000796caeddafca  pop r11
0000796caeddafcc  pop r10
0000796caeddafce  pop r9
0000796caeddafd0  pop r8
0000796caeddafd2  pop rsi
0000796caeddafd3  pop rdi
0000796caeddafd4  pop rdx
0000796caeddafd5  pop rcx
0000796caeddafd6  pop rax
0000796caeddafd7  add rsp, 0x08
0000796caeddafdb  jmp 0x0000796CAEDD659A
0000796caeddafe0  call 0x0000796CAEC0C260
0000796caeddafe5  jmp 0x0000796CAEDD65A8
0000796caeddafea  call 0x0000796CAECDE950
0000796caeddafef  jmp 0x0000796CAEDD65B2
0000796caeddaff4  sub rsp, 0x08
0000796caeddaff8  push rax
0000796caeddaff9  push rcx
0000796caeddaffa  push rdx
0000796caeddaffb  push rdi
0000796caeddaffc  push rsi
0000796caeddaffd  push r8
0000796caeddafff  push r9
0000796caeddb001  push r10
0000796caeddb003  push r11
0000796caeddb005  sub rsp, 0xF0
0000796caeddb00c  vmovaps [rsp], xmm0
0000796caeddb011  vmovaps [rsp+0x10], xmm1
0000796caeddb017  vmovaps [rsp+0x20], xmm2
0000796caeddb01d  vmovaps [rsp+0x30], xmm3
0000796caeddb023  vmovaps [rsp+0x40], xmm4
0000796caeddb029  vmovaps [rsp+0x50], xmm5
0000796caeddb02f  vmovaps [rsp+0x60], xmm6
0000796caeddb035  vmovaps [rsp+0x70], xmm7
0000796caeddb03b  vmovaps [rsp+0x80], xmm9
0000796caeddb044  vmovaps [rsp+0x90], xmm10
0000796caeddb04d  vmovaps [rsp+0xA0], xmm11
0000796caeddb056  vmovaps [rsp+0xB0], xmm12
0000796caeddb05f  vmovaps [rsp+0xC0], xmm13
0000796caeddb068  vmovaps [rsp+0xD0], xmm14
0000796caeddb071  vmovaps [rsp+0xE0], xmm15
0000796caeddb07a  sub rsp, 0x30
0000796caeddb07e  movaps [rsp], xmm8
0000796caeddb083  movaps [rsp+0x10], xmm15
0000796caeddb089  movaps [rsp+0x20], xmm7
0000796caeddb08e  lea rdi, [rsp]
0000796caeddb092  mov esi, 0x00
0000796caeddb097  mov rax, 0x56877063A530
0000796caeddb0a1  call rax
0000796caeddb0a3  movaps xmm8, [rsp]
0000796caeddb0a8  add rsp, 0x30
0000796caeddb0ac  vmovaps xmm0, [rsp]
0000796caeddb0b1  vmovaps xmm1, [rsp+0x10]
0000796caeddb0b7  vmovaps xmm2, [rsp+0x20]
0000796caeddb0bd  vmovaps xmm3, [rsp+0x30]
0000796caeddb0c3  vmovaps xmm4, [rsp+0x40]
0000796caeddb0c9  vmovaps xmm5, [rsp+0x50]
0000796caeddb0cf  vmovaps xmm6, [rsp+0x60]
0000796caeddb0d5  vmovaps xmm7, [rsp+0x70]
0000796caeddb0db  vmovaps xmm9, [rsp+0x80]
0000796caeddb0e4  vmovaps xmm10, [rsp+0x90]
0000796caeddb0ed  vmovaps xmm11, [rsp+0xA0]
0000796caeddb0f6  vmovaps xmm12, [rsp+0xB0]
0000796caeddb0ff  vmovaps xmm13, [rsp+0xC0]
0000796caeddb108  vmovaps xmm14, [rsp+0xD0]
0000796caeddb111  vmovaps xmm15, [rsp+0xE0]
0000796caeddb11a  add rsp, 0xF0
0000796caeddb121  pop r11
0000796caeddb123  pop r10
0000796caeddb125  pop r9
0000796caeddb127  pop r8
0000796caeddb129  pop rsi
0000796caeddb12a  pop rdi
0000796caeddb12b  pop rdx
0000796caeddb12c  pop rcx
0000796caeddb12d  pop rax
0000796caeddb12e  add rsp, 0x08
0000796caeddb132  jmp 0x0000796CAEDD65D4
0000796caeddb137  sub rsp, 0x08
0000796caeddb13b  push rax
0000796caeddb13c  push rcx
0000796caeddb13d  push rdx
0000796caeddb13e  push rdi
0000796caeddb13f  push rsi
0000796caeddb140  push r8
0000796caeddb142  push r9
0000796caeddb144  push r10
0000796caeddb146  push r11
0000796caeddb148  sub rsp, 0xF0
0000796caeddb14f  vmovaps [rsp], xmm0
0000796caeddb154  vmovaps [rsp+0x10], xmm1
0000796caeddb15a  vmovaps [rsp+0x20], xmm2
0000796caeddb160  vmovaps [rsp+0x30], xmm3
0000796caeddb166  vmovaps [rsp+0x40], xmm4
0000796caeddb16c  vmovaps [rsp+0x50], xmm5
0000796caeddb172  vmovaps [rsp+0x60], xmm6
0000796caeddb178  vmovaps [rsp+0x70], xmm8
0000796caeddb17e  vmovaps [rsp+0x80], xmm9
0000796caeddb187  vmovaps [rsp+0x90], xmm10
0000796caeddb190  vmovaps [rsp+0xA0], xmm11
0000796caeddb199  vmovaps [rsp+0xB0], xmm12
0000796caeddb1a2  vmovaps [rsp+0xC0], xmm13
0000796caeddb1ab  vmovaps [rsp+0xD0], xmm14
0000796caeddb1b4  vmovaps [rsp+0xE0], xmm15
0000796caeddb1bd  sub rsp, 0x30
0000796caeddb1c1  movaps [rsp], xmm7
0000796caeddb1c5  movaps [rsp+0x10], xmm9
0000796caeddb1cb  movaps [rsp+0x20], xmm15
0000796caeddb1d1  lea rdi, [rsp]
0000796caeddb1d5  mov esi, 0x00
0000796caeddb1da  mov rax, 0x56877063A530
0000796caeddb1e4  call rax
0000796caeddb1e6  movaps xmm7, [rsp]
0000796caeddb1ea  add rsp, 0x30
0000796caeddb1ee  vmovaps xmm0, [rsp]
0000796caeddb1f3  vmovaps xmm1, [rsp+0x10]
0000796caeddb1f9  vmovaps xmm2, [rsp+0x20]
0000796caeddb1ff  vmovaps xmm3, [rsp+0x30]
0000796caeddb205  vmovaps xmm4, [rsp+0x40]
0000796caeddb20b  vmovaps xmm5, [rsp+0x50]
0000796caeddb211  vmovaps xmm6, [rsp+0x60]
0000796caeddb217  vmovaps xmm8, [rsp+0x70]
0000796caeddb21d  vmovaps xmm9, [rsp+0x80]
0000796caeddb226  vmovaps xmm10, [rsp+0x90]
0000796caeddb22f  vmovaps xmm11, [rsp+0xA0]
0000796caeddb238  vmovaps xmm12, [rsp+0xB0]
0000796caeddb241  vmovaps xmm13, [rsp+0xC0]
0000796caeddb24a  vmovaps xmm14, [rsp+0xD0]
0000796caeddb253  vmovaps xmm15, [rsp+0xE0]
0000796caeddb25c  add rsp, 0xF0
0000796caeddb263  pop r11
0000796caeddb265  pop r10
0000796caeddb267  pop r9
0000796caeddb269  pop r8
0000796caeddb26b  pop rsi
0000796caeddb26c  pop rdi
0000796caeddb26d  pop rdx
0000796caeddb26e  pop rcx
0000796caeddb26f  pop rax
0000796caeddb270  add rsp, 0x08
0000796caeddb274  jmp 0x0000796CAEDD6601
0000796caeddb279  sub rsp, 0x08
0000796caeddb27d  push rax
0000796caeddb27e  push rcx
0000796caeddb27f  push rdx
0000796caeddb280  push rdi
0000796caeddb281  push rsi
0000796caeddb282  push r8
0000796caeddb284  push r9
0000796caeddb286  push r10
0000796caeddb288  push r11
0000796caeddb28a  sub rsp, 0xF0
0000796caeddb291  vmovaps [rsp], xmm0
0000796caeddb296  vmovaps [rsp+0x10], xmm1
0000796caeddb29c  vmovaps [rsp+0x20], xmm2
0000796caeddb2a2  vmovaps [rsp+0x30], xmm3
0000796caeddb2a8  vmovaps [rsp+0x40], xmm4
0000796caeddb2ae  vmovaps [rsp+0x50], xmm5
0000796caeddb2b4  vmovaps [rsp+0x60], xmm6
0000796caeddb2ba  vmovaps [rsp+0x70], xmm7
0000796caeddb2c0  vmovaps [rsp+0x80], xmm8
0000796caeddb2c9  vmovaps [rsp+0x90], xmm10
0000796caeddb2d2  vmovaps [rsp+0xA0], xmm11
0000796caeddb2db  vmovaps [rsp+0xB0], xmm12
0000796caeddb2e4  vmovaps [rsp+0xC0], xmm13
0000796caeddb2ed  vmovaps [rsp+0xD0], xmm14
0000796caeddb2f6  vmovaps [rsp+0xE0], xmm15
0000796caeddb2ff  sub rsp, 0x30
0000796caeddb303  movaps [rsp], xmm9
0000796caeddb308  movaps [rsp+0x10], xmm13
0000796caeddb30e  movaps [rsp+0x20], xmm15
0000796caeddb314  lea rdi, [rsp]
0000796caeddb318  mov esi, 0x00
0000796caeddb31d  mov rax, 0x56877063A530
0000796caeddb327  call rax
0000796caeddb329  movaps xmm9, [rsp]
0000796caeddb32e  add rsp, 0x30
0000796caeddb332  vmovaps xmm0, [rsp]
0000796caeddb337  vmovaps xmm1, [rsp+0x10]
0000796caeddb33d  vmovaps xmm2, [rsp+0x20]
0000796caeddb343  vmovaps xmm3, [rsp+0x30]
0000796caeddb349  vmovaps xmm4, [rsp+0x40]
0000796caeddb34f  vmovaps xmm5, [rsp+0x50]
0000796caeddb355  vmovaps xmm6, [rsp+0x60]
0000796caeddb35b  vmovaps xmm7, [rsp+0x70]
0000796caeddb361  vmovaps xmm8, [rsp+0x80]
0000796caeddb36a  vmovaps xmm10, [rsp+0x90]
0000796caeddb373  vmovaps xmm11, [rsp+0xA0]
0000796caeddb37c  vmovaps xmm12, [rsp+0xB0]
0000796caeddb385  vmovaps xmm13, [rsp+0xC0]
0000796caeddb38e  vmovaps xmm14, [rsp+0xD0]
0000796caeddb397  vmovaps xmm15, [rsp+0xE0]
0000796caeddb3a0  add rsp, 0xF0
0000796caeddb3a7  pop r11
0000796caeddb3a9  pop r10
0000796caeddb3ab  pop r9
0000796caeddb3ad  pop r8
0000796caeddb3af  pop rsi
0000796caeddb3b0  pop rdi
0000796caeddb3b1  pop rdx
0000796caeddb3b2  pop rcx
0000796caeddb3b3  pop rax
0000796caeddb3b4  add rsp, 0x08
0000796caeddb3b8  jmp 0x0000796CAEDD662F
0000796caeddb3bd  sub rsp, 0x08
0000796caeddb3c1  push rax
0000796caeddb3c2  push rcx
0000796caeddb3c3  push rdx
0000796caeddb3c4  push rdi
0000796caeddb3c5  push rsi
0000796caeddb3c6  push r8
0000796caeddb3c8  push r9
0000796caeddb3ca  push r10
0000796caeddb3cc  push r11
0000796caeddb3ce  sub rsp, 0xF0
0000796caeddb3d5  vmovaps [rsp], xmm0
0000796caeddb3da  vmovaps [rsp+0x10], xmm1
0000796caeddb3e0  vmovaps [rsp+0x20], xmm2
0000796caeddb3e6  vmovaps [rsp+0x30], xmm3
0000796caeddb3ec  vmovaps [rsp+0x40], xmm4
0000796caeddb3f2  vmovaps [rsp+0x50], xmm5
0000796caeddb3f8  vmovaps [rsp+0x60], xmm6
0000796caeddb3fe  vmovaps [rsp+0x70], xmm7
0000796caeddb404  vmovaps [rsp+0x80], xmm8
0000796caeddb40d  vmovaps [rsp+0x90], xmm9
0000796caeddb416  vmovaps [rsp+0xA0], xmm10
0000796caeddb41f  vmovaps [rsp+0xB0], xmm11
0000796caeddb428  vmovaps [rsp+0xC0], xmm12
0000796caeddb431  vmovaps [rsp+0xD0], xmm13
0000796caeddb43a  vmovaps [rsp+0xE0], xmm14
0000796caeddb443  sub rsp, 0x30
0000796caeddb447  movaps [rsp], xmm15
0000796caeddb44c  movaps [rsp+0x10], xmm11
0000796caeddb452  movaps [rsp+0x20], xmm12
0000796caeddb458  lea rdi, [rsp]
0000796caeddb45c  mov esi, 0x00
0000796caeddb461  mov rax, 0x56877063A530
0000796caeddb46b  call rax
0000796caeddb46d  movaps xmm15, [rsp]
0000796caeddb472  add rsp, 0x30
0000796caeddb476  vmovaps xmm0, [rsp]
0000796caeddb47b  vmovaps xmm1, [rsp+0x10]
0000796caeddb481  vmovaps xmm2, [rsp+0x20]
0000796caeddb487  vmovaps xmm3, [rsp+0x30]
0000796caeddb48d  vmovaps xmm4, [rsp+0x40]
0000796caeddb493  vmovaps xmm5, [rsp+0x50]
0000796caeddb499  vmovaps xmm6, [rsp+0x60]
0000796caeddb49f  vmovaps xmm7, [rsp+0x70]
0000796caeddb4a5  vmovaps xmm8, [rsp+0x80]
0000796caeddb4ae  vmovaps xmm9, [rsp+0x90]
0000796caeddb4b7  vmovaps xmm10, [rsp+0xA0]
0000796caeddb4c0  vmovaps xmm11, [rsp+0xB0]
0000796caeddb4c9  vmovaps xmm12, [rsp+0xC0]
0000796caeddb4d2  vmovaps xmm13, [rsp+0xD0]
0000796caeddb4db  vmovaps xmm14, [rsp+0xE0]
0000796caeddb4e4  add rsp, 0xF0
0000796caeddb4eb  pop r11
0000796caeddb4ed  pop r10
0000796caeddb4ef  pop r9
0000796caeddb4f1  pop r8
0000796caeddb4f3  pop rsi
0000796caeddb4f4  pop rdi
0000796caeddb4f5  pop rdx
0000796caeddb4f6  pop rcx
0000796caeddb4f7  pop rax
0000796caeddb4f8  add rsp, 0x08
0000796caeddb4fc  jmp 0x0000796CAEDD664A
0000796caeddb501  sub rsp, 0x08
0000796caeddb505  push rax
0000796caeddb506  push rcx
0000796caeddb507  push rdx
0000796caeddb508  push rdi
0000796caeddb509  push rsi
0000796caeddb50a  push r8
0000796caeddb50c  push r9
0000796caeddb50e  push r10
0000796caeddb510  push r11
0000796caeddb512  sub rsp, 0xF0
0000796caeddb519  vmovaps [rsp], xmm0
0000796caeddb51e  vmovaps [rsp+0x10], xmm1
0000796caeddb524  vmovaps [rsp+0x20], xmm2
0000796caeddb52a  vmovaps [rsp+0x30], xmm3
0000796caeddb530  vmovaps [rsp+0x40], xmm4
0000796caeddb536  vmovaps [rsp+0x50], xmm5
0000796caeddb53c  vmovaps [rsp+0x60], xmm6
0000796caeddb542  vmovaps [rsp+0x70], xmm7
0000796caeddb548  vmovaps [rsp+0x80], xmm8
0000796caeddb551  vmovaps [rsp+0x90], xmm9
0000796caeddb55a  vmovaps [rsp+0xA0], xmm10
0000796caeddb563  vmovaps [rsp+0xB0], xmm11
0000796caeddb56c  vmovaps [rsp+0xC0], xmm12
0000796caeddb575  vmovaps [rsp+0xD0], xmm14
0000796caeddb57e  vmovaps [rsp+0xE0], xmm15
0000796caeddb587  sub rsp, 0x30
0000796caeddb58b  movaps [rsp], xmm13
0000796caeddb590  movaps [rsp+0x10], xmm10
0000796caeddb596  movaps [rsp+0x20], xmm14
0000796caeddb59c  lea rdi, [rsp]
0000796caeddb5a0  mov esi, 0x00
0000796caeddb5a5  mov rax, 0x56877063A530
0000796caeddb5af  call rax
0000796caeddb5b1  movaps xmm13, [rsp]
0000796caeddb5b6  add rsp, 0x30
0000796caeddb5ba  vmovaps xmm0, [rsp]
0000796caeddb5bf  vmovaps xmm1, [rsp+0x10]
0000796caeddb5c5  vmovaps xmm2, [rsp+0x20]
0000796caeddb5cb  vmovaps xmm3, [rsp+0x30]
0000796caeddb5d1  vmovaps xmm4, [rsp+0x40]
0000796caeddb5d7  vmovaps xmm5, [rsp+0x50]
0000796caeddb5dd  vmovaps xmm6, [rsp+0x60]
0000796caeddb5e3  vmovaps xmm7, [rsp+0x70]
0000796caeddb5e9  vmovaps xmm8, [rsp+0x80]
0000796caeddb5f2  vmovaps xmm9, [rsp+0x90]
0000796caeddb5fb  vmovaps xmm10, [rsp+0xA0]
0000796caeddb604  vmovaps xmm11, [rsp+0xB0]
0000796caeddb60d  vmovaps xmm12, [rsp+0xC0]
0000796caeddb616  vmovaps xmm14, [rsp+0xD0]
0000796caeddb61f  vmovaps xmm15, [rsp+0xE0]
0000796caeddb628  add rsp, 0xF0
0000796caeddb62f  pop r11
0000796caeddb631  pop r10
0000796caeddb633  pop r9
0000796caeddb635  pop r8
0000796caeddb637  pop rsi
0000796caeddb638  pop rdi
0000796caeddb639  pop rdx
0000796caeddb63a  pop rcx
0000796caeddb63b  pop rax
0000796caeddb63c  add rsp, 0x08
0000796caeddb640  jmp 0x0000796CAEDD666D
0000796caeddb645  sub rsp, 0x08
0000796caeddb649  push rax
0000796caeddb64a  push rcx
0000796caeddb64b  push rdx
0000796caeddb64c  push rdi
0000796caeddb64d  push rsi
0000796caeddb64e  push r8
0000796caeddb650  push r9
0000796caeddb652  push r10
0000796caeddb654  push r11
0000796caeddb656  sub rsp, 0xF0
0000796caeddb65d  vmovaps [rsp], xmm0
0000796caeddb662  vmovaps [rsp+0x10], xmm1
0000796caeddb668  vmovaps [rsp+0x20], xmm2
0000796caeddb66e  vmovaps [rsp+0x30], xmm3
0000796caeddb674  vmovaps [rsp+0x40], xmm4
0000796caeddb67a  vmovaps [rsp+0x50], xmm5
0000796caeddb680  vmovaps [rsp+0x60], xmm6
0000796caeddb686  vmovaps [rsp+0x70], xmm7
0000796caeddb68c  vmovaps [rsp+0x80], xmm8
0000796caeddb695  vmovaps [rsp+0x90], xmm9
0000796caeddb69e  vmovaps [rsp+0xA0], xmm10
0000796caeddb6a7  vmovaps [rsp+0xB0], xmm11
0000796caeddb6b0  vmovaps [rsp+0xC0], xmm12
0000796caeddb6b9  vmovaps [rsp+0xD0], xmm13
0000796caeddb6c2  vmovaps [rsp+0xE0], xmm15
0000796caeddb6cb  sub rsp, 0x30
0000796caeddb6cf  movaps [rsp], xmm14
0000796caeddb6d4  movaps [rsp+0x10], xmm1
0000796caeddb6d9  movaps [rsp+0x20], xmm7
0000796caeddb6de  lea rdi, [rsp]
0000796caeddb6e2  mov esi, 0x00
0000796caeddb6e7  mov rax, 0x56877063A530
0000796caeddb6f1  call rax
0000796caeddb6f3  movaps xmm14, [rsp]
0000796caeddb6f8  add rsp, 0x30
0000796caeddb6fc  vmovaps xmm0, [rsp]
0000796caeddb701  vmovaps xmm1, [rsp+0x10]
0000796caeddb707  vmovaps xmm2, [rsp+0x20]
0000796caeddb70d  vmovaps xmm3, [rsp+0x30]
0000796caeddb713  vmovaps xmm4, [rsp+0x40]
0000796caeddb719  vmovaps xmm5, [rsp+0x50]
0000796caeddb71f  vmovaps xmm6, [rsp+0x60]
0000796caeddb725  vmovaps xmm7, [rsp+0x70]
0000796caeddb72b  vmovaps xmm8, [rsp+0x80]
0000796caeddb734  vmovaps xmm9, [rsp+0x90]
0000796caeddb73d  vmovaps xmm10, [rsp+0xA0]
0000796caeddb746  vmovaps xmm11, [rsp+0xB0]
0000796caeddb74f  vmovaps xmm12, [rsp+0xC0]
0000796caeddb758  vmovaps xmm13, [rsp+0xD0]
0000796caeddb761  vmovaps xmm15, [rsp+0xE0]
0000796caeddb76a  add rsp, 0xF0
0000796caeddb771  pop r11
0000796caeddb773  pop r10
0000796caeddb775  pop r9
0000796caeddb777  pop r8
0000796caeddb779  pop rsi
0000796caeddb77a  pop rdi
0000796caeddb77b  pop rdx
0000796caeddb77c  pop rcx
0000796caeddb77d  pop rax
0000796caeddb77e  add rsp, 0x08
0000796caeddb782  jmp 0x0000796CAEDD6690
0000796caeddb787  sub rsp, 0x08
0000796caeddb78b  push rax
0000796caeddb78c  push rcx
0000796caeddb78d  push rdx
0000796caeddb78e  push rdi
0000796caeddb78f  push rsi
0000796caeddb790  push r8
0000796caeddb792  push r9
0000796caeddb794  push r10
0000796caeddb796  push r11
0000796caeddb798  sub rsp, 0xF0
0000796caeddb79f  vmovaps [rsp], xmm0
0000796caeddb7a4  vmovaps [rsp+0x10], xmm2
0000796caeddb7aa  vmovaps [rsp+0x20], xmm3
0000796caeddb7b0  vmovaps [rsp+0x30], xmm4
0000796caeddb7b6  vmovaps [rsp+0x40], xmm5
0000796caeddb7bc  vmovaps [rsp+0x50], xmm6
0000796caeddb7c2  vmovaps [rsp+0x60], xmm7
0000796caeddb7c8  vmovaps [rsp+0x70], xmm8
0000796caeddb7ce  vmovaps [rsp+0x80], xmm9
0000796caeddb7d7  vmovaps [rsp+0x90], xmm10
0000796caeddb7e0  vmovaps [rsp+0xA0], xmm11
0000796caeddb7e9  vmovaps [rsp+0xB0], xmm12
0000796caeddb7f2  vmovaps [rsp+0xC0], xmm13
0000796caeddb7fb  vmovaps [rsp+0xD0], xmm14
0000796caeddb804  vmovaps [rsp+0xE0], xmm15
0000796caeddb80d  sub rsp, 0x30
0000796caeddb811  movaps [rsp], xmm1
0000796caeddb815  movaps [rsp+0x10], xmm8
0000796caeddb81b  movaps [rsp+0x20], xmm9
0000796caeddb821  lea rdi, [rsp]
0000796caeddb825  mov esi, 0x00
0000796caeddb82a  mov rax, 0x56877063A530
0000796caeddb834  call rax
0000796caeddb836  movaps xmm1, [rsp]
0000796caeddb83a  add rsp, 0x30
0000796caeddb83e  vmovaps xmm0, [rsp]
0000796caeddb843  vmovaps xmm2, [rsp+0x10]
0000796caeddb849  vmovaps xmm3, [rsp+0x20]
0000796caeddb84f  vmovaps xmm4, [rsp+0x30]
0000796caeddb855  vmovaps xmm5, [rsp+0x40]
0000796caeddb85b  vmovaps xmm6, [rsp+0x50]
0000796caeddb861  vmovaps xmm7, [rsp+0x60]
0000796caeddb867  vmovaps xmm8, [rsp+0x70]
0000796caeddb86d  vmovaps xmm9, [rsp+0x80]
0000796caeddb876  vmovaps xmm10, [rsp+0x90]
0000796caeddb87f  vmovaps xmm11, [rsp+0xA0]
0000796caeddb888  vmovaps xmm12, [rsp+0xB0]
0000796caeddb891  vmovaps xmm13, [rsp+0xC0]
0000796caeddb89a  vmovaps xmm14, [rsp+0xD0]
0000796caeddb8a3  vmovaps xmm15, [rsp+0xE0]
0000796caeddb8ac  add rsp, 0xF0
0000796caeddb8b3  pop r11
0000796caeddb8b5  pop r10
0000796caeddb8b7  pop r9
0000796caeddb8b9  pop r8
0000796caeddb8bb  pop rsi
0000796caeddb8bc  pop rdi
0000796caeddb8bd  pop rdx
0000796caeddb8be  pop rcx
0000796caeddb8bf  pop rax
0000796caeddb8c0  add rsp, 0x08
0000796caeddb8c4  jmp 0x0000796CAEDD66B2
0000796caeddb8c9  call 0x0000796CAECB3E40
0000796caeddb8ce  jmp 0x0000796CAEDD66C0
0000796caeddb8d3  call 0x0000796CAEC0C380
0000796caeddb8d8  jmp 0x0000796CAEDD66CA
0000796caeddb8dd  call 0x0000796CAEC0D600
0000796caeddb8e2  jmp 0x0000796CAEDD66D4
0000796caeddb8e7  call 0x0000796CAEBFF540
0000796caeddb8ec  jmp 0x0000796CAEDD66DE
0000796caeddb8f1  int3
0000796caeddb8f2  nop [rax+rax*1], ax
0000796caeddb8fb  nop [rax+rax*1], eax
0000796caeddb900  mov eax, [r15+0x48]
0000796caeddb904  lea r14d, [eax+0x01]
0000796caeddb909  mov [rsp+0x10], r14d
0000796caeddb90e  mov r14d, r14d
0000796caeddb911  mov [r15+0x48], r14
0000796caeddb915  xor eax, eax
0000796caeddb917  mov r14d, [rsp+0x10]
0000796caeddb91c  cmp r14d, 0x1F4
0000796caeddb923  cmc
0000796caeddb924  lahf
0000796caeddb925  seto al
0000796caeddb928  mov [r15+0x108], eax
0000796caeddb92f  mov eax, [r15+0x108]
0000796caeddb936  sahf
0000796caeddb937  jnz 0x0000796CAEDDB969
0000796caeddb939  cmp dword ptr [r15+0x318], 0x00
0000796caeddb941  jz 0x0000796CAEDE1AB0
0000796caeddb947  nop [rax+rax*1], ax
0000796caeddb950  nop [rax+rax*1], eax
0000796caeddb958  mov eax, 0x410450
0000796caeddb95d  mov [r15+0x100], rax
0000796caeddb964  jmp 0x0000796CAEBFE110
0000796caeddb969  cmp dword ptr [r15+0x318], 0x00
0000796caeddb971  jz 0x0000796CAEDDB9A0
0000796caeddb977  nop [rax+rax*1], ax
0000796caeddb980  nop [rax+rax*1], eax
0000796caeddb988  mov eax, 0x410274
0000796caeddb98d  mov [r15+0x100], rax
0000796caeddb994  jmp 0x0000796CAEBFE110
0000796caeddb999  int3
0000796caeddb99a  int3
0000796caeddb99b  nop [rax+rax*1], eax
0000796caeddb9a0  mov rax, [r15+0x40]
0000796caeddb9a4  movaps xmm1, [r15+0x1D0]
0000796caeddb9ac  vmovaps [rsp+0x10], xmm1
0000796caeddb9b2  vmovaps xmm15, [rsp+0x10]
0000796caeddb9b8  por xmm1, xmm15
0000796caeddb9bd  movaps xmm14, [r15+0x1A0]
0000796caeddb9c5  vmovaps [rsp+0x10], xmm14
0000796caeddb9cb  vmovaps xmm13, [rsp+0x10]
0000796caeddb9d1  por xmm14, xmm13
0000796caeddb9d6  lea r14, [rax+0x30]
0000796caeddb9da  mov r12, [r13+r14*1]
0000796caeddb9df  lea r14, [rax+0x38]
0000796caeddb9e3  mov r11, [r13+r14*1]
0000796caeddb9e8  movq xmm13, r12
0000796caeddb9ed  movq xmm12, r11
0000796caeddb9f2  movq xmm13, xmm13
0000796caeddb9f7  vmovaps [rsp+0x10], xmm13
0000796caeddb9fd  movq xmm13, xmm13
0000796caeddba02  movaps [r15+0x130], xmm13
0000796caeddba0a  movq xmm12, xmm12
0000796caeddba0f  vmovaps [rsp+0x20], xmm12
0000796caeddba15  movq xmm12, xmm12
0000796caeddba1a  movaps [r15+0x280], xmm12
0000796caeddba22  movaps xmm13, [r15+0x270]
0000796caeddba2a  vmovaps [rsp+0x30], xmm13
0000796caeddba30  vmovaps xmm12, [rsp+0x30]
0000796caeddba36  por xmm13, xmm12
0000796caeddba3b  lea r14, [rax+0x20]
0000796caeddba3f  mov r12, [r13+r14*1]
0000796caeddba44  lea r14, [rax+0x28]
0000796caeddba48  mov r11, [r13+r14*1]
0000796caeddba4d  movq xmm12, r12
0000796caeddba52  movq xmm11, r11
0000796caeddba57  movq xmm12, xmm12
0000796caeddba5c  vmovaps [rsp+0x30], xmm12
0000796caeddba62  movq xmm12, xmm12
0000796caeddba67  movaps [r15+0x150], xmm12
0000796caeddba6f  movq xmm11, xmm11
0000796caeddba74  vmovaps [rsp+0x40], xmm11
0000796caeddba7a  movq xmm11, xmm11
0000796caeddba7f  movaps [r15+0x140], xmm11
0000796caeddba87  lea r14, [rax+0x10]
0000796caeddba8b  mov r12, [r13+r14*1]
0000796caeddba90  lea r14, [rax+0x18]
0000796caeddba94  mov r11, [r13+r14*1]
0000796caeddba99  movq xmm12, r12
0000796caeddba9e  movq xmm11, r11
0000796caeddbaa3  movq xmm12, xmm12
0000796caeddbaa8  vmovaps [rsp+0x50], xmm12
0000796caeddbaae  movq xmm12, xmm12
0000796caeddbab3  movaps [r15+0x170], xmm12
0000796caeddbabb  movq xmm11, xmm11
0000796caeddbac0  vmovaps [rsp+0x60], xmm11
0000796caeddbac6  movq xmm11, xmm11
0000796caeddbacb  movaps [r15+0x160], xmm11
0000796caeddbad3  mov r14, [r13+rax*1]
0000796caeddbad8  vmovq xmm12, r14
0000796caeddbadd  vpbroadcastq xmm12, xmm12
0000796caeddbae2  lea r14, [rax+0x08]
0000796caeddbae6  mov rax, [r13+r14*1]
0000796caeddbaeb  movq xmm11, rax
0000796caeddbaf0  movaps [r15+0x230], xmm11
0000796caeddbaf8  mov rax, [r15+0xF8]
0000796caeddbaff  lea r14, [rax+0x50]
0000796caeddbb03  movups xmm11, [r13+r14*1]
0000796caeddbb09  lea r14, [rax+0x60]
0000796caeddbb0d  movups xmm10, [r13+r14*1]
0000796caeddbb13  lea r14, [rax+0x30]
0000796caeddbb17  movups xmm9, [r13+r14*1]
0000796caeddbb1d  mov r14, [r15+0x50]
0000796caeddbb21  mov [r15+0x60], r14
0000796caeddbb25  mov qword ptr [r15+0x58], 0x40
0000796caeddbb2d  movaps xmm8, xmm12
0000796caeddbb31  mulpd xmm8, xmm15
0000796caeddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000796caeddbb3c  ptest xmm7, xmm7
0000796caeddbb41  jnz 0x0000796CAEDDC96A
0000796caeddbb47  movq xmm15, qword ptr [r15+0x230]
0000796caeddbb50  vmovaps [rsp+0x70], xmm15
0000796caeddbb56  vpermilpd xmm15, xmm15, 0x00
0000796caeddbb5c  movaps xmm7, xmm9
0000796caeddbb60  mulpd xmm7, xmm15
0000796caeddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000796caeddbb6a  ptest xmm6, xmm6
0000796caeddbb6f  jnz 0x0000796CAEDDCAAE
0000796caeddbb75  vxorps xmm15, xmm15, xmm15
0000796caeddbb7a  vpbroadcastq xmm15, xmm15
0000796caeddbb7f  movaps xmm9, xmm12
0000796caeddbb83  mulpd xmm9, xmm10
0000796caeddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000796caeddbb8e  ptest xmm6, xmm6
0000796caeddbb93  jnz 0x0000796CAEDDCBF0
0000796caeddbb99  movaps xmm10, xmm12
0000796caeddbb9d  mulpd xmm10, xmm11
0000796caeddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000796caeddbba8  ptest xmm6, xmm6
0000796caeddbbad  jnz 0x0000796CAEDDCD34
0000796caeddbbb3  movaps xmm11, [r15+0x1F0]
0000796caeddbbbb  movaps xmm6, xmm12
0000796caeddbbbf  mulpd xmm6, xmm11
0000796caeddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000796caeddbbc9  ptest xmm5, xmm5
0000796caeddbbce  jnz 0x0000796CAEDDCE78
0000796caeddbbd4  movaps xmm12, [r15+0x2A0]
0000796caeddbbdc  vmovaps [rsp+0x80], xmm12
0000796caeddbbe5  vmovaps xmm11, [rsp+0x80]
0000796caeddbbee  por xmm12, xmm11
0000796caeddbbf3  movaps xmm11, [r15+0x250]
0000796caeddbbfb  vmovaps [rsp+0x80], xmm11
0000796caeddbc04  vmovaps xmm5, [rsp+0x80]
0000796caeddbc0d  por xmm11, xmm5
0000796caeddbc12  vmovaps xmm4, [rsp+0x70]
0000796caeddbc18  vpermilpd xmm4, xmm4, 0x00
0000796caeddbc1e  movaps xmm3, xmm5
0000796caeddbc21  mulpd xmm3, xmm4
0000796caeddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000796caeddbc2a  ptest xmm2, xmm2
0000796caeddbc2f  jnz 0x0000796CAEDDCFBA
0000796caeddbc35  mov [rsp+0x80], rax
0000796caeddbc3d  xor eax, eax
0000796caeddbc3f  mov r12d, 0x40
0000796caeddbc45  mov r11d, 0x200
0000796caeddbc4b  cmp r12, r11
0000796caeddbc4e  cmc
0000796caeddbc4f  lahf
0000796caeddbc50  seto al
0000796caeddbc53  mov [r15+0x108], eax
0000796caeddbc5a  movaps xmm5, xmm8
0000796caeddbc5e  addpd xmm5, xmm15
0000796caeddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000796caeddbc68  ptest xmm4, xmm4
0000796caeddbc6d  jnz 0x0000796CAEDDD0FA
0000796caeddbc73  movaps xmm8, [r15+0x1B0]
0000796caeddbc7b  movaps xmm4, xmm9
0000796caeddbc7f  addpd xmm4, xmm8
0000796caeddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000796caeddbc89  ptest xmm2, xmm2
0000796caeddbc8e  jnz 0x0000796CAEDDD23C
0000796caeddbc94  movaps xmm9, xmm10
0000796caeddbc98  addpd xmm9, xmm8
0000796caeddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000796caeddbca3  ptest xmm2, xmm2
0000796caeddbca8  jnz 0x0000796CAEDDD37E
0000796caeddbcae  movaps xmm10, [r15+0x2F0]
0000796caeddbcb6  vmovaps [rsp+0x90], xmm10
0000796caeddbcbf  vmovaps xmm8, [rsp+0x90]
0000796caeddbcc8  por xmm10, xmm8
0000796caeddbccd  movaps xmm8, [r15+0x2E0]
0000796caeddbcd5  vmovaps [rsp+0x90], xmm8
0000796caeddbcde  vmovaps xmm2, [rsp+0x90]
0000796caeddbce7  por xmm8, xmm2
0000796caeddbcec  movaps xmm2, [r15+0x2D0]
0000796caeddbcf4  vmovaps [rsp+0x90], xmm2
0000796caeddbcfd  vmovaps [rsp+0xA0], xmm1
0000796caeddbd06  vmovaps xmm1, [rsp+0x90]
0000796caeddbd0f  por xmm2, xmm1
0000796caeddbd13  movaps xmm1, [r15+0x200]
0000796caeddbd1b  vmovaps [rsp+0x90], xmm1
0000796caeddbd24  vmovaps [rsp+0xB0], xmm15
0000796caeddbd2d  vmovaps xmm15, [rsp+0x90]
0000796caeddbd36  por xmm1, xmm15
0000796caeddbd3b  movaps xmm15, [r15+0x1C0]
0000796caeddbd43  vmovaps [rsp+0x90], xmm15
0000796caeddbd4c  vmovaps [rsp+0xC0], xmm1
0000796caeddbd55  vmovaps xmm1, [rsp+0x90]
0000796caeddbd5e  por xmm15, xmm1
0000796caeddbd63  movaps xmm1, [r15+0x190]
0000796caeddbd6b  vmovaps [rsp+0x90], xmm1
0000796caeddbd74  vmovaps [rsp+0xD0], xmm15
0000796caeddbd7d  vmovaps xmm15, [rsp+0x90]
0000796caeddbd86  por xmm1, xmm15
0000796caeddbd8b  movaps xmm15, [r15+0x300]
0000796caeddbd93  vmovaps [rsp+0x90], xmm15
0000796caeddbd9c  vmovaps [rsp+0xE0], xmm1
0000796caeddbda5  vmovaps xmm1, [rsp+0x90]
0000796caeddbdae  por xmm15, xmm1
0000796caeddbdb3  mov rax, [rsp+0x80]
0000796caeddbdbb  lea r12, [rax+0xA0]
0000796caeddbdc2  movups xmm1, [r13+r12*1]
0000796caeddbdc8  lea r12, [rax+0xB0]
0000796caeddbdcf  vmovaps [rsp+0x80], xmm1
0000796caeddbdd8  movups xmm1, [r13+r12*1]
0000796caeddbdde  vmovaps [rsp+0x90], xmm1
0000796caeddbde7  vmovaps [rsp+0xF0], xmm15
0000796caeddbdf0  vmovaps xmm15, [rsp+0xB0]
0000796caeddbdf9  vmovaps [rsp+0xB0], xmm14
0000796caeddbe02  movaps xmm1, xmm6
0000796caeddbe05  addpd xmm1, xmm15
0000796caeddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000796caeddbe0f  ptest xmm14, xmm14
0000796caeddbe15  jnz 0x0000796CAEDDD4D6
0000796caeddbe1b  lea r12, [rax+0xF0]
0000796caeddbe22  movups xmm15, [r13+r12*1]
0000796caeddbe28  movaps xmm14, xmm4
0000796caeddbe2c  addpd xmm14, xmm3
0000796caeddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000796caeddbe37  ptest xmm6, xmm6
0000796caeddbe3c  jnz 0x0000796CAEDDD621
0000796caeddbe42  movaps xmm6, xmm9
0000796caeddbe46  addpd xmm6, xmm7
0000796caeddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000796caeddbe4f  ptest xmm4, xmm4
0000796caeddbe54  jnz 0x0000796CAEDDD763
0000796caeddbe5a  vmovaps xmm9, [rsp+0x70]
0000796caeddbe60  vpermilpd xmm9, xmm9, 0x00
0000796caeddbe66  vmovaps xmm4, [rsp+0x90]
0000796caeddbe6f  movaps xmm7, xmm4
0000796caeddbe72  mulpd xmm7, xmm9
0000796caeddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000796caeddbe7c  ptest xmm3, xmm3
0000796caeddbe81  jnz 0x0000796CAEDDD8A4
0000796caeddbe87  vmovaps xmm9, [rsp+0x50]
0000796caeddbe8d  vpermilpd xmm9, xmm9, 0x00
0000796caeddbe93  movaps xmm4, xmm15
0000796caeddbe97  mulpd xmm4, xmm9
0000796caeddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000796caeddbea1  ptest xmm3, xmm3
0000796caeddbea6  jnz 0x0000796CAEDDD9E5
0000796caeddbeac  lea r12, [rax+0xE0]
0000796caeddbeb3  movups xmm15, [r13+r12*1]
0000796caeddbeb9  vmovaps xmm9, [rsp+0x70]
0000796caeddbebf  vpermilpd xmm9, xmm9, 0x00
0000796caeddbec5  vmovaps [rsp+0x70], xmm1
0000796caeddbecb  vmovaps xmm1, [rsp+0x80]
0000796caeddbed4  vmovaps [rsp+0x80], xmm15
0000796caeddbedd  movaps xmm3, xmm1
0000796caeddbee0  mulpd xmm3, xmm9
0000796caeddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000796caeddbeea  ptest xmm15, xmm15
0000796caeddbef0  jnz 0x0000796CAEDDDB31
0000796caeddbef6  vmovaps xmm1, [rsp+0xF0]
0000796caeddbeff  vmovaps xmm15, [rsp+0xF0]
0000796caeddbf08  por xmm1, xmm15
0000796caeddbf0d  movaps [r15+0x300], xmm1
0000796caeddbf15  vmovaps xmm15, [rsp+0xE0]
0000796caeddbf1e  vmovaps xmm9, [rsp+0xE0]
0000796caeddbf27  por xmm15, xmm9
0000796caeddbf2c  movaps [r15+0x190], xmm15
0000796caeddbf34  vmovaps xmm9, [rsp+0x50]
0000796caeddbf3a  vpermilpd xmm9, xmm9, 0x00
0000796caeddbf40  vmovaps [rsp+0x90], xmm1
0000796caeddbf49  vmovaps [rsp+0xE0], xmm15
0000796caeddbf52  vmovaps xmm15, [rsp+0x80]
0000796caeddbf5b  vmovaps [rsp+0x80], xmm14
0000796caeddbf64  movaps xmm1, xmm15
0000796caeddbf68  mulpd xmm1, xmm9
0000796caeddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000796caeddbf72  ptest xmm14, xmm14
0000796caeddbf78  jnz 0x0000796CAEDDDC72
0000796caeddbf7e  lea r12, [rax+0x90]
0000796caeddbf85  movups xmm15, [r13+r12*1]
0000796caeddbf8b  vmovaps xmm14, [rsp+0xD0]
0000796caeddbf94  vmovaps xmm9, [rsp+0xD0]
0000796caeddbf9d  por xmm14, xmm9
0000796caeddbfa2  movaps [r15+0x1C0], xmm14
0000796caeddbfaa  vmovaps xmm9, [rsp+0xC0]
0000796caeddbfb3  vmovaps [rsp+0xD0], xmm1
0000796caeddbfbc  vmovaps xmm1, [rsp+0xC0]
0000796caeddbfc5  por xmm9, xmm1
0000796caeddbfca  movaps [r15+0x200], xmm9
0000796caeddbfd2  vmovaps [rsp+0xC0], xmm2
0000796caeddbfdb  vmovaps xmm1, [rsp+0xC0]
0000796caeddbfe4  por xmm2, xmm1
0000796caeddbfe8  movaps [r15+0x2D0], xmm2
0000796caeddbff0  vmovaps [rsp+0xC0], xmm8
0000796caeddbff9  vmovaps xmm1, [rsp+0xC0]
0000796caeddc002  por xmm8, xmm1
0000796caeddc007  movaps [r15+0x2E0], xmm8
0000796caeddc00f  vmovaps [rsp+0xC0], xmm15
0000796caeddc018  movaps xmm1, xmm5
0000796caeddc01b  addpd xmm1, xmm7
0000796caeddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000796caeddc024  ptest xmm15, xmm15
0000796caeddc02a  jnz 0x0000796CAEDDDDBE
0000796caeddc030  vmovaps xmm15, [rsp+0x50]
0000796caeddc036  vpermilpd xmm15, xmm15, 0x00
0000796caeddc03c  vmovaps xmm5, [rsp+0xC0]
0000796caeddc045  vmovaps [rsp+0xC0], xmm1
0000796caeddc04e  movaps xmm7, xmm5
0000796caeddc051  mulpd xmm7, xmm15
0000796caeddc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000796caeddc05b  ptest xmm1, xmm1
0000796caeddc060  jnz 0x0000796CAEDDDEFE
0000796caeddc066  lea r12, [rax+0x80]
0000796caeddc06d  movups xmm1, [r13+r12*1]
0000796caeddc073  vmovaps xmm5, [rsp+0x70]
0000796caeddc079  vmovaps [rsp+0x70], xmm1
0000796caeddc07f  movaps xmm15, xmm5
0000796caeddc083  addpd xmm15, xmm3
0000796caeddc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000796caeddc08e  ptest xmm1, xmm1
0000796caeddc093  jnz 0x0000796CAEDDE049
0000796caeddc099  vmovaps xmm5, [rsp+0x80]
0000796caeddc0a2  movaps xmm1, xmm5
0000796caeddc0a5  addpd xmm1, xmm4
0000796caeddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000796caeddc0ae  ptest xmm3, xmm3
0000796caeddc0b3  jnz 0x0000796CAEDDE18B
0000796caeddc0b9  vmovaps [rsp+0x80], xmm10
0000796caeddc0c2  vmovaps xmm5, [rsp+0x80]
0000796caeddc0cb  por xmm10, xmm5
0000796caeddc0d0  movaps [r15+0x2F0], xmm10
0000796caeddc0d8  vmovaps xmm5, [rsp+0x50]
0000796caeddc0de  vpermilpd xmm5, xmm5, 0x00
0000796caeddc0e4  vmovaps xmm3, [rsp+0x70]
0000796caeddc0ea  vmovaps [rsp+0x50], xmm1
0000796caeddc0f0  movaps xmm4, xmm3
0000796caeddc0f3  mulpd xmm4, xmm5
0000796caeddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000796caeddc0fc  ptest xmm1, xmm1
0000796caeddc101  jnz 0x0000796CAEDDE2CB
0000796caeddc107  lea r12, [rax+0xD0]
0000796caeddc10e  movups xmm1, [r13+r12*1]
0000796caeddc114  vmovaps xmm3, [rsp+0xD0]
0000796caeddc11d  vmovaps [rsp+0x70], xmm1
0000796caeddc123  movaps xmm5, xmm6
0000796caeddc126  addpd xmm5, xmm3
0000796caeddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000796caeddc12f  ptest xmm1, xmm1
0000796caeddc134  jnz 0x0000796CAEDDE415
0000796caeddc13a  vmovaps xmm1, [rsp+0x60]
0000796caeddc140  vpermilpd xmm1, xmm1, 0x00
0000796caeddc146  movaps xmm6, xmm9
0000796caeddc14a  mulpd xmm6, xmm1
0000796caeddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000796caeddc153  ptest xmm3, xmm3
0000796caeddc158  jnz 0x0000796CAEDDE555
0000796caeddc15e  movaps [r15+0x260], xmm6
0000796caeddc166  vxorps xmm1, xmm1, xmm1
0000796caeddc16a  vpbroadcastq xmm1, xmm1
0000796caeddc16f  movaps [r15+0x1B0], xmm1
0000796caeddc177  vmovaps xmm1, [rsp+0x60]
0000796caeddc17d  vpermilpd xmm1, xmm1, 0x00
0000796caeddc183  vmovaps xmm3, [rsp+0x70]
0000796caeddc189  vmovaps [rsp+0x70], xmm15
0000796caeddc18f  movaps xmm9, xmm3
0000796caeddc193  mulpd xmm9, xmm1
0000796caeddc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000796caeddc19e  ptest xmm15, xmm15
0000796caeddc1a4  jnz 0x0000796CAEDDE696
0000796caeddc1aa  lea r12, [rax+0xC0]
0000796caeddc1b1  movups xmm1, [r13+r12*1]
0000796caeddc1b7  vmovaps xmm3, [rsp+0xC0]
0000796caeddc1c0  vmovaps [rsp+0x80], xmm1
0000796caeddc1c9  movaps xmm15, xmm3
0000796caeddc1cd  addpd xmm15, xmm7
0000796caeddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000796caeddc1d8  ptest xmm1, xmm1
0000796caeddc1dd  jnz 0x0000796CAEDDE7E2
0000796caeddc1e3  vmovaps [rsp+0xC0], xmm13
0000796caeddc1ec  vmovaps xmm1, [rsp+0xC0]
0000796caeddc1f5  por xmm13, xmm1
0000796caeddc1fa  movaps [r15+0x270], xmm13
0000796caeddc202  vmovaps xmm1, [rsp+0xB0]
0000796caeddc20b  vmovaps xmm7, [rsp+0xB0]
0000796caeddc214  por xmm1, xmm7
0000796caeddc218  movaps [r15+0x1A0], xmm1
0000796caeddc220  vmovaps xmm1, [rsp+0x60]
0000796caeddc226  vpermilpd xmm1, xmm1, 0x00
0000796caeddc22c  vmovaps [rsp+0xB0], xmm1
0000796caeddc235  vmovaps xmm1, [rsp+0x80]
0000796caeddc23e  vmovaps [rsp+0x80], xmm15
0000796caeddc247  vmovaps xmm15, [rsp+0xB0]
0000796caeddc250  vmovaps [rsp+0xB0], xmm14
0000796caeddc259  movaps xmm3, xmm1
0000796caeddc25c  mulpd xmm3, xmm15
0000796caeddc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000796caeddc266  ptest xmm14, xmm14
0000796caeddc26c  jnz 0x0000796CAEDDE924
0000796caeddc272  lea r12, [rax+0x20]
0000796caeddc276  movups xmm1, [r13+r12*1]
0000796caeddc27c  movaps [r15+0x110], xmm1
0000796caeddc284  vmovaps xmm14, [rsp+0x70]
0000796caeddc28a  vmovaps [rsp+0x70], xmm1
0000796caeddc290  movaps xmm15, xmm14
0000796caeddc294  addpd xmm15, xmm4
0000796caeddc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000796caeddc29f  ptest xmm1, xmm1
0000796caeddc2a4  jnz 0x0000796CAEDDEA6F
0000796caeddc2aa  vmovaps xmm1, [rsp+0x60]
0000796caeddc2b0  vpermilpd xmm1, xmm1, 0x00
0000796caeddc2b6  movaps xmm14, xmm2
0000796caeddc2ba  mulpd xmm14, xmm1
0000796caeddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000796caeddc2c5  ptest xmm4, xmm4
0000796caeddc2ca  jnz 0x0000796CAEDDEBB2
0000796caeddc2d0  vmovaps xmm4, [rsp+0x50]
0000796caeddc2d6  movaps xmm1, xmm4
0000796caeddc2d9  addpd xmm1, xmm9
0000796caeddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000796caeddc2e3  ptest xmm2, xmm2
0000796caeddc2e8  jnz 0x0000796CAEDDECF4
0000796caeddc2ee  vmovaps xmm9, [rsp+0x30]
0000796caeddc2f4  vpermilpd xmm9, xmm9, 0x00
0000796caeddc2fa  vmovaps xmm2, [rsp+0x70]
0000796caeddc300  vmovaps [rsp+0x50], xmm1
0000796caeddc306  movaps xmm4, xmm2
0000796caeddc309  mulpd xmm4, xmm9
0000796caeddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000796caeddc313  ptest xmm1, xmm1
0000796caeddc318  jnz 0x0000796CAEDDEE35
0000796caeddc31e  vmovaps xmm1, [rsp+0x30]
0000796caeddc324  vpermilpd xmm1, xmm1, 0x00
0000796caeddc32a  vmovaps xmm2, [rsp+0x90]
0000796caeddc333  vmovaps [rsp+0x60], xmm15
0000796caeddc339  movaps xmm9, xmm2
0000796caeddc33d  mulpd xmm9, xmm1
0000796caeddc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000796caeddc348  ptest xmm15, xmm15
0000796caeddc34e  jnz 0x0000796CAEDDEF76
0000796caeddc354  vmovaps xmm15, [rsp+0x80]
0000796caeddc35d  movaps xmm1, xmm15
0000796caeddc361  addpd xmm1, xmm6
0000796caeddc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000796caeddc36a  ptest xmm2, xmm2
0000796caeddc36f  jnz 0x0000796CAEDDF0B8
0000796caeddc375  movaps xmm15, xmm5
0000796caeddc379  addpd xmm15, xmm3
0000796caeddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000796caeddc384  ptest xmm6, xmm6
0000796caeddc389  jnz 0x0000796CAEDDF1F9
0000796caeddc38f  vmovaps xmm6, [rsp+0x30]
0000796caeddc395  vpermilpd xmm6, xmm6, 0x00
0000796caeddc39b  movaps xmm5, xmm8
0000796caeddc39f  mulpd xmm5, xmm6
0000796caeddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000796caeddc3a8  ptest xmm3, xmm3
0000796caeddc3ad  jnz 0x0000796CAEDDF33B
0000796caeddc3b3  vmovaps xmm8, [rsp+0x30]
0000796caeddc3b9  vpermilpd xmm8, xmm8, 0x00
0000796caeddc3bf  movaps xmm6, xmm10
0000796caeddc3c3  mulpd xmm6, xmm8
0000796caeddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000796caeddc3cd  ptest xmm3, xmm3
0000796caeddc3d2  jnz 0x0000796CAEDDF47C
0000796caeddc3d8  vmovaps xmm8, [rsp+0x60]
0000796caeddc3de  movaps xmm10, xmm8
0000796caeddc3e2  addpd xmm10, xmm14
0000796caeddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000796caeddc3ed  ptest xmm3, xmm3
0000796caeddc3f2  jnz 0x0000796CAEDDF5BE
0000796caeddc3f8  vmovaps xmm8, [rsp+0x50]
0000796caeddc3fe  movaps xmm14, xmm8
0000796caeddc402  addpd xmm14, xmm4
0000796caeddc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000796caeddc40d  ptest xmm3, xmm3
0000796caeddc412  jnz 0x0000796CAEDDF702
0000796caeddc418  vmovaps xmm8, [rsp+0x40]
0000796caeddc41e  vpermilpd xmm8, xmm8, 0x00
0000796caeddc424  movaps xmm4, xmm13
0000796caeddc428  mulpd xmm4, xmm8
0000796caeddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000796caeddc432  ptest xmm3, xmm3
0000796caeddc437  jnz 0x0000796CAEDDF845
0000796caeddc43d  movaps xmm13, xmm15
0000796caeddc441  addpd xmm13, xmm9
0000796caeddc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000796caeddc44c  ptest xmm8, xmm8
0000796caeddc452  jnz 0x0000796CAEDDF987
0000796caeddc458  movaps xmm15, xmm1
0000796caeddc45c  addpd xmm15, xmm5
0000796caeddc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000796caeddc467  ptest xmm9, xmm9
0000796caeddc46d  jnz 0x0000796CAEDDFACB
0000796caeddc473  vmovaps [rsp+0x30], xmm11
0000796caeddc479  vmovaps xmm1, [rsp+0x30]
0000796caeddc47f  por xmm11, xmm1
0000796caeddc484  movaps [r15+0x250], xmm11
0000796caeddc48c  vmovaps [rsp+0x30], xmm12
0000796caeddc492  vmovaps xmm1, [rsp+0x30]
0000796caeddc498  por xmm12, xmm1
0000796caeddc49d  movaps [r15+0x2A0], xmm12
0000796caeddc4a5  vmovaps xmm1, [rsp+0xA0]
0000796caeddc4ae  vmovaps xmm11, [rsp+0xA0]
0000796caeddc4b7  por xmm1, xmm11
0000796caeddc4bc  movaps [r15+0x1D0], xmm1
0000796caeddc4c4  lea r12, [rax+0x40]
0000796caeddc4c8  movups xmm1, [r13+r12*1]
0000796caeddc4ce  movaps [r15+0x2C0], xmm1
0000796caeddc4d6  vmovaps xmm11, [rsp+0x40]
0000796caeddc4dc  vpermilpd xmm11, xmm11, 0x00
0000796caeddc4e2  vmovaps xmm8, [rsp+0xE0]
0000796caeddc4eb  movaps xmm9, xmm8
0000796caeddc4ef  mulpd xmm9, xmm11
0000796caeddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000796caeddc4fa  ptest xmm5, xmm5
0000796caeddc4ff  jnz 0x0000796CAEDDFC17
0000796caeddc505  movaps xmm11, xmm10
0000796caeddc509  addpd xmm11, xmm6
0000796caeddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000796caeddc514  ptest xmm8, xmm8
0000796caeddc51a  jnz 0x0000796CAEDDFD5B
0000796caeddc520  movaps xmm10, xmm14
0000796caeddc524  addpd xmm10, xmm4
0000796caeddc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000796caeddc52f  ptest xmm8, xmm8
0000796caeddc535  jnz 0x0000796CAEDDFE9E
0000796caeddc53b  vmovaps xmm14, [rsp+0x40]
0000796caeddc541  vpermilpd xmm14, xmm14, 0x00
0000796caeddc547  movaps xmm8, xmm1
0000796caeddc54b  mulpd xmm8, xmm14
0000796caeddc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000796caeddc556  ptest xmm6, xmm6
0000796caeddc55b  jnz 0x0000796CAEDDFFE1
0000796caeddc561  movaps xmm1, [r15+0x2B0]
0000796caeddc569  vmovaps xmm14, [rsp+0x40]
0000796caeddc56f  vpermilpd xmm14, xmm14, 0x00
0000796caeddc575  movaps xmm6, xmm1
0000796caeddc578  mulpd xmm6, xmm14
0000796caeddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000796caeddc582  ptest xmm5, xmm5
0000796caeddc587  jnz 0x0000796CAEDE0124
0000796caeddc58d  vmovaps xmm1, [rsp+0x10]
0000796caeddc593  vpermilpd xmm1, xmm1, 0x00
0000796caeddc599  movaps xmm14, xmm12
0000796caeddc59d  mulpd xmm14, xmm1
0000796caeddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000796caeddc5a8  ptest xmm5, xmm5
0000796caeddc5ad  jnz 0x0000796CAEDE0265
0000796caeddc5b3  movaps xmm1, xmm13
0000796caeddc5b7  addpd xmm1, xmm9
0000796caeddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000796caeddc5c1  ptest xmm12, xmm12
0000796caeddc5c7  jnz 0x0000796CAEDE03A8
0000796caeddc5cd  vmovaps xmm13, [rsp+0x10]
0000796caeddc5d3  vpermilpd xmm13, xmm13, 0x00
0000796caeddc5d9  movaps xmm12, xmm7
0000796caeddc5dd  mulpd xmm12, xmm13
0000796caeddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000796caeddc5e8  ptest xmm9, xmm9
0000796caeddc5ee  jnz 0x0000796CAEDE04EA
0000796caeddc5f4  movaps xmm13, xmm15
0000796caeddc5f8  addpd xmm13, xmm8
0000796caeddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000796caeddc603  ptest xmm9, xmm9
0000796caeddc609  jnz 0x0000796CAEDE062D
0000796caeddc60f  movaps xmm15, [r15+0x290]
0000796caeddc617  vmovaps xmm9, [rsp+0x10]
0000796caeddc61d  vpermilpd xmm9, xmm9, 0x00
0000796caeddc623  movaps xmm8, xmm15
0000796caeddc627  mulpd xmm8, xmm9
0000796caeddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000796caeddc632  ptest xmm7, xmm7
0000796caeddc637  jnz 0x0000796CAEDE0771
0000796caeddc63d  movaps xmm15, xmm11
0000796caeddc641  addpd xmm15, xmm6
0000796caeddc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000796caeddc64c  ptest xmm9, xmm9
0000796caeddc652  jnz 0x0000796CAEDE08B5
0000796caeddc658  movaps xmm11, [r15+0x1E0]
0000796caeddc660  vmovaps xmm9, [rsp+0x10]
0000796caeddc666  vpermilpd xmm9, xmm9, 0x00
0000796caeddc66c  movaps xmm7, xmm11
0000796caeddc670  mulpd xmm7, xmm9
0000796caeddc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000796caeddc67a  ptest xmm6, xmm6
0000796caeddc67f  jnz 0x0000796CAEDE09F8
0000796caeddc685  movaps xmm11, xmm10
0000796caeddc689  addpd xmm11, xmm14
0000796caeddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000796caeddc694  ptest xmm9, xmm9
0000796caeddc69a  jnz 0x0000796CAEDE0B3A
0000796caeddc6a0  lea r12, [rax+0x70]
0000796caeddc6a4  movups xmm14, [r13+r12*1]
0000796caeddc6aa  movaps [r15+0x240], xmm14
0000796caeddc6b2  movaps xmm10, xmm1
0000796caeddc6b6  addpd xmm10, xmm12
0000796caeddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000796caeddc6c1  ptest xmm9, xmm9
0000796caeddc6c7  jnz 0x0000796CAEDE0C88
0000796caeddc6cd  movaps [r15+0x170], xmm10
0000796caeddc6d5  vmovaps xmm1, [rsp+0x20]
0000796caeddc6db  vpermilpd xmm1, xmm1, 0x00
0000796caeddc6e1  movaps xmm12, xmm14
0000796caeddc6e5  mulpd xmm12, xmm1
0000796caeddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000796caeddc6f0  ptest xmm9, xmm9
0000796caeddc6f6  jnz 0x0000796CAEDE0DCB
0000796caeddc6fc  vmovaps xmm1, [rsp+0x20]
0000796caeddc702  vpermilpd xmm1, xmm1, 0x00
0000796caeddc708  vmovaps xmm9, [rsp+0xB0]
0000796caeddc711  movaps xmm14, xmm9
0000796caeddc715  mulpd xmm14, xmm1
0000796caeddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000796caeddc720  ptest xmm6, xmm6
0000796caeddc725  jnz 0x0000796CAEDE0F0E
0000796caeddc72b  movaps [r15+0x180], xmm14
0000796caeddc733  movaps xmm1, xmm13
0000796caeddc737  addpd xmm1, xmm8
0000796caeddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000796caeddc741  ptest xmm9, xmm9
0000796caeddc747  jnz 0x0000796CAEDE1051
0000796caeddc74d  movaps [r15+0x210], xmm1
0000796caeddc755  movups xmm13, [r13+rax*1]
0000796caeddc75b  lea r12, [rax+0x10]
0000796caeddc75f  movups xmm9, [r13+r12*1]
0000796caeddc765  movaps [r15+0x230], xmm9
0000796caeddc76d  movaps xmm8, xmm15
0000796caeddc771  addpd xmm8, xmm7
0000796caeddc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000796caeddc77c  ptest xmm6, xmm6
0000796caeddc781  jnz 0x0000796CAEDE11A7
0000796caeddc787  movaps [r15+0x130], xmm8
0000796caeddc78f  vmovaps xmm15, [rsp+0x20]
0000796caeddc795  vpermilpd xmm15, xmm15, 0x00
0000796caeddc79b  movaps xmm7, xmm9
0000796caeddc79f  mulpd xmm7, xmm15
0000796caeddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000796caeddc7a9  ptest xmm6, xmm6
0000796caeddc7ae  jnz 0x0000796CAEDE12EA
0000796caeddc7b4  movaps [r15+0x220], xmm7
0000796caeddc7bc  vmovaps xmm15, [rsp+0x20]
0000796caeddc7c2  vpermilpd xmm15, xmm15, 0x00
0000796caeddc7c8  movaps xmm9, xmm13
0000796caeddc7cc  mulpd xmm9, xmm15
0000796caeddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000796caeddc7d7  ptest xmm6, xmm6
0000796caeddc7dc  jnz 0x0000796CAEDE142C
0000796caeddc7e2  movaps xmm15, xmm11
0000796caeddc7e6  addpd xmm15, xmm12
0000796caeddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000796caeddc7f1  ptest xmm13, xmm13
0000796caeddc7f7  jnz 0x0000796CAEDE1570
0000796caeddc7fd  movaps [r15+0x140], xmm15
0000796caeddc805  movaps xmm13, xmm10
0000796caeddc809  addpd xmm13, xmm14
0000796caeddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000796caeddc814  ptest xmm12, xmm12
0000796caeddc81a  jnz 0x0000796CAEDE16B4
0000796caeddc820  movaps [r15+0x150], xmm13
0000796caeddc828  movaps xmm14, xmm1
0000796caeddc82c  addpd xmm14, xmm7
0000796caeddc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000796caeddc837  ptest xmm12, xmm12
0000796caeddc83d  jnz 0x0000796CAEDE17F8
0000796caeddc843  movaps [r15+0x160], xmm14
0000796caeddc84b  movaps xmm1, xmm8
0000796caeddc84f  addpd xmm1, xmm9
0000796caeddc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000796caeddc859  ptest xmm12, xmm12
0000796caeddc85f  jnz 0x0000796CAEDE193A
0000796caeddc865  movaps [r15+0x120], xmm1
0000796caeddc86d  movups [r13+r14*1], xmm15
0000796caeddc873  lea rax, [r14+0x10]
0000796caeddc877  movups [r13+rax*1], xmm13
0000796caeddc87d  lea rax, [r14+0x20]
0000796caeddc881  movups [r13+rax*1], xmm14
0000796caeddc887  lea rax, [r14+0x30]
0000796caeddc88b  movups [r13+rax*1], xmm1
0000796caeddc891  mov eax, [r15+0x108]
0000796caeddc898  sahf
0000796caeddc899  jnz 0x0000796CAEDDC8CB
0000796caeddc89b  cmp dword ptr [r15+0x318], 0x00
0000796caeddc8a3  jz 0x0000796CAEDDB900
0000796caeddc8a9  nop [rax+rax*1], ax
0000796caeddc8b2  nop [rax+rax*1], eax
0000796caeddc8ba  mov eax, 0x410444
0000796caeddc8bf  mov [r15+0x100], rax
0000796caeddc8c6  jmp 0x0000796CAEBFE110
0000796caeddc8cb  cmp dword ptr [r15+0x318], 0x00
0000796caeddc8d3  jz 0x0000796CAEDD57E0
0000796caeddc8d9  nop [rax+rax*1], ax
0000796caeddc8e2  nop [rax+rax*1], eax
0000796caeddc8ea  mov eax, 0x410278
0000796caeddc8ef  mov [r15+0x100], rax
0000796caeddc8f6  jmp 0x0000796CAEBFE110
0000796caeddc8fb  int3
0000796caeddc8fc  call 0x0000796CAECE27E0
0000796caeddc901  jmp 0x0000796CAEDDB9DF
0000796caeddc906  call 0x0000796CAECE1570
0000796caeddc90b  jmp 0x0000796CAEDDB9E8
0000796caeddc910  call 0x0000796CAECE27E0
0000796caeddc915  jmp 0x0000796CAEDDBA44
0000796caeddc91a  call 0x0000796CAECE1570
0000796caeddc91f  jmp 0x0000796CAEDDBA4D
0000796caeddc924  call 0x0000796CAECE27E0
0000796caeddc929  jmp 0x0000796CAEDDBA90
0000796caeddc92e  call 0x0000796CAECE1570
0000796caeddc933  jmp 0x0000796CAEDDBA99
0000796caeddc938  call 0x0000796CAEC0DC20
0000796caeddc93d  jmp 0x0000796CAEDDBAD8
0000796caeddc942  call 0x0000796CAECD59C0
0000796caeddc947  jmp 0x0000796CAEDDBAEB
0000796caeddc94c  call 0x0000796CAECE0E30
0000796caeddc951  jmp 0x0000796CAEDDBB09
0000796caeddc956  call 0x0000796CAECDFBC0
0000796caeddc95b  jmp 0x0000796CAEDDBB13
0000796caeddc960  call 0x0000796CAECDE950
0000796caeddc965  jmp 0x0000796CAEDDBB1D
0000796caeddc96a  sub rsp, 0x08
0000796caeddc96e  push rax
0000796caeddc96f  push rcx
0000796caeddc970  push rdx
0000796caeddc971  push rdi
0000796caeddc972  push rsi
0000796caeddc973  push r8
0000796caeddc975  push r9
0000796caeddc977  push r10
0000796caeddc979  push r11
0000796caeddc97b  sub rsp, 0xF0
0000796caeddc982  vmovaps [rsp], xmm0
0000796caeddc987  vmovaps [rsp+0x10], xmm1
0000796caeddc98d  vmovaps [rsp+0x20], xmm2
0000796caeddc993  vmovaps [rsp+0x30], xmm3
0000796caeddc999  vmovaps [rsp+0x40], xmm4
0000796caeddc99f  vmovaps [rsp+0x50], xmm5
0000796caeddc9a5  vmovaps [rsp+0x60], xmm6
0000796caeddc9ab  vmovaps [rsp+0x70], xmm7
0000796caeddc9b1  vmovaps [rsp+0x80], xmm9
0000796caeddc9ba  vmovaps [rsp+0x90], xmm10
0000796caeddc9c3  vmovaps [rsp+0xA0], xmm11
0000796caeddc9cc  vmovaps [rsp+0xB0], xmm12
0000796caeddc9d5  vmovaps [rsp+0xC0], xmm13
0000796caeddc9de  vmovaps [rsp+0xD0], xmm14
0000796caeddc9e7  vmovaps [rsp+0xE0], xmm15
0000796caeddc9f0  sub rsp, 0x30
0000796caeddc9f4  movaps [rsp], xmm8
0000796caeddc9f9  movaps [rsp+0x10], xmm12
0000796caeddc9ff  movaps [rsp+0x20], xmm15
0000796caeddca05  lea rdi, [rsp]
0000796caeddca09  mov esi, 0x00
0000796caeddca0e  mov rax, 0x56877063A530
0000796caeddca18  call rax
0000796caeddca1a  movaps xmm8, [rsp]
0000796caeddca1f  add rsp, 0x30
0000796caeddca23  vmovaps xmm0, [rsp]
0000796caeddca28  vmovaps xmm1, [rsp+0x10]
0000796caeddca2e  vmovaps xmm2, [rsp+0x20]
0000796caeddca34  vmovaps xmm3, [rsp+0x30]
0000796caeddca3a  vmovaps xmm4, [rsp+0x40]
0000796caeddca40  vmovaps xmm5, [rsp+0x50]
0000796caeddca46  vmovaps xmm6, [rsp+0x60]
0000796caeddca4c  vmovaps xmm7, [rsp+0x70]
0000796caeddca52  vmovaps xmm9, [rsp+0x80]
0000796caeddca5b  vmovaps xmm10, [rsp+0x90]
0000796caeddca64  vmovaps xmm11, [rsp+0xA0]
0000796caeddca6d  vmovaps xmm12, [rsp+0xB0]
0000796caeddca76  vmovaps xmm13, [rsp+0xC0]
0000796caeddca7f  vmovaps xmm14, [rsp+0xD0]
0000796caeddca88  vmovaps xmm15, [rsp+0xE0]
0000796caeddca91  add rsp, 0xF0
0000796caeddca98  pop r11
0000796caeddca9a  pop r10
0000796caeddca9c  pop r9
0000796caeddca9e  pop r8
0000796caeddcaa0  pop rsi
0000796caeddcaa1  pop rdi
0000796caeddcaa2  pop rdx
0000796caeddcaa3  pop rcx
0000796caeddcaa4  pop rax
0000796caeddcaa5  add rsp, 0x08
0000796caeddcaa9  jmp 0x0000796CAEDDBB47
0000796caeddcaae  sub rsp, 0x08
0000796caeddcab2  push rax
0000796caeddcab3  push rcx
0000796caeddcab4  push rdx
0000796caeddcab5  push rdi
0000796caeddcab6  push rsi
0000796caeddcab7  push r8
0000796caeddcab9  push r9
0000796caeddcabb  push r10
0000796caeddcabd  push r11
0000796caeddcabf  sub rsp, 0xF0
0000796caeddcac6  vmovaps [rsp], xmm0
0000796caeddcacb  vmovaps [rsp+0x10], xmm1
0000796caeddcad1  vmovaps [rsp+0x20], xmm2
0000796caeddcad7  vmovaps [rsp+0x30], xmm3
0000796caeddcadd  vmovaps [rsp+0x40], xmm4
0000796caeddcae3  vmovaps [rsp+0x50], xmm5
0000796caeddcae9  vmovaps [rsp+0x60], xmm6
0000796caeddcaef  vmovaps [rsp+0x70], xmm8
0000796caeddcaf5  vmovaps [rsp+0x80], xmm9
0000796caeddcafe  vmovaps [rsp+0x90], xmm10
0000796caeddcb07  vmovaps [rsp+0xA0], xmm11
0000796caeddcb10  vmovaps [rsp+0xB0], xmm12
0000796caeddcb19  vmovaps [rsp+0xC0], xmm13
0000796caeddcb22  vmovaps [rsp+0xD0], xmm14
0000796caeddcb2b  vmovaps [rsp+0xE0], xmm15
0000796caeddcb34  sub rsp, 0x30
0000796caeddcb38  movaps [rsp], xmm7
0000796caeddcb3c  movaps [rsp+0x10], xmm9
0000796caeddcb42  movaps [rsp+0x20], xmm15
0000796caeddcb48  lea rdi, [rsp]
0000796caeddcb4c  mov esi, 0x00
0000796caeddcb51  mov rax, 0x56877063A530
0000796caeddcb5b  call rax
0000796caeddcb5d  movaps xmm7, [rsp]
0000796caeddcb61  add rsp, 0x30
0000796caeddcb65  vmovaps xmm0, [rsp]
0000796caeddcb6a  vmovaps xmm1, [rsp+0x10]
0000796caeddcb70  vmovaps xmm2, [rsp+0x20]
0000796caeddcb76  vmovaps xmm3, [rsp+0x30]
0000796caeddcb7c  vmovaps xmm4, [rsp+0x40]
0000796caeddcb82  vmovaps xmm5, [rsp+0x50]
0000796caeddcb88  vmovaps xmm6, [rsp+0x60]
0000796caeddcb8e  vmovaps xmm8, [rsp+0x70]
0000796caeddcb94  vmovaps xmm9, [rsp+0x80]
0000796caeddcb9d  vmovaps xmm10, [rsp+0x90]
0000796caeddcba6  vmovaps xmm11, [rsp+0xA0]
0000796caeddcbaf  vmovaps xmm12, [rsp+0xB0]
0000796caeddcbb8  vmovaps xmm13, [rsp+0xC0]
0000796caeddcbc1  vmovaps xmm14, [rsp+0xD0]
0000796caeddcbca  vmovaps xmm15, [rsp+0xE0]
0000796caeddcbd3  add rsp, 0xF0
0000796caeddcbda  pop r11
0000796caeddcbdc  pop r10
0000796caeddcbde  pop r9
0000796caeddcbe0  pop r8
0000796caeddcbe2  pop rsi
0000796caeddcbe3  pop rdi
0000796caeddcbe4  pop rdx
0000796caeddcbe5  pop rcx
0000796caeddcbe6  pop rax
0000796caeddcbe7  add rsp, 0x08
0000796caeddcbeb  jmp 0x0000796CAEDDBB75
0000796caeddcbf0  sub rsp, 0x08
0000796caeddcbf4  push rax
0000796caeddcbf5  push rcx
0000796caeddcbf6  push rdx
0000796caeddcbf7  push rdi
0000796caeddcbf8  push rsi
0000796caeddcbf9  push r8
0000796caeddcbfb  push r9
0000796caeddcbfd  push r10
0000796caeddcbff  push r11
0000796caeddcc01  sub rsp, 0xF0
0000796caeddcc08  vmovaps [rsp], xmm0
0000796caeddcc0d  vmovaps [rsp+0x10], xmm1
0000796caeddcc13  vmovaps [rsp+0x20], xmm2
0000796caeddcc19  vmovaps [rsp+0x30], xmm3
0000796caeddcc1f  vmovaps [rsp+0x40], xmm4
0000796caeddcc25  vmovaps [rsp+0x50], xmm5
0000796caeddcc2b  vmovaps [rsp+0x60], xmm6
0000796caeddcc31  vmovaps [rsp+0x70], xmm7
0000796caeddcc37  vmovaps [rsp+0x80], xmm8
0000796caeddcc40  vmovaps [rsp+0x90], xmm10
0000796caeddcc49  vmovaps [rsp+0xA0], xmm11
0000796caeddcc52  vmovaps [rsp+0xB0], xmm12
0000796caeddcc5b  vmovaps [rsp+0xC0], xmm13
0000796caeddcc64  vmovaps [rsp+0xD0], xmm14
0000796caeddcc6d  vmovaps [rsp+0xE0], xmm15
0000796caeddcc76  sub rsp, 0x30
0000796caeddcc7a  movaps [rsp], xmm9
0000796caeddcc7f  movaps [rsp+0x10], xmm12
0000796caeddcc85  movaps [rsp+0x20], xmm10
0000796caeddcc8b  lea rdi, [rsp]
0000796caeddcc8f  mov esi, 0x00
0000796caeddcc94  mov rax, 0x56877063A530
0000796caeddcc9e  call rax
0000796caeddcca0  movaps xmm9, [rsp]
0000796caeddcca5  add rsp, 0x30
0000796caeddcca9  vmovaps xmm0, [rsp]
0000796caeddccae  vmovaps xmm1, [rsp+0x10]
0000796caeddccb4  vmovaps xmm2, [rsp+0x20]
0000796caeddccba  vmovaps xmm3, [rsp+0x30]
0000796caeddccc0  vmovaps xmm4, [rsp+0x40]
0000796caeddccc6  vmovaps xmm5, [rsp+0x50]
0000796caeddcccc  vmovaps xmm6, [rsp+0x60]
0000796caeddccd2  vmovaps xmm7, [rsp+0x70]
0000796caeddccd8  vmovaps xmm8, [rsp+0x80]
0000796caeddcce1  vmovaps xmm10, [rsp+0x90]
0000796caeddccea  vmovaps xmm11, [rsp+0xA0]
0000796caeddccf3  vmovaps xmm12, [rsp+0xB0]
0000796caeddccfc  vmovaps xmm13, [rsp+0xC0]
0000796caeddcd05  vmovaps xmm14, [rsp+0xD0]
0000796caeddcd0e  vmovaps xmm15, [rsp+0xE0]
0000796caeddcd17  add rsp, 0xF0
0000796caeddcd1e  pop r11
0000796caeddcd20  pop r10
0000796caeddcd22  pop r9
0000796caeddcd24  pop r8
0000796caeddcd26  pop rsi
0000796caeddcd27  pop rdi
0000796caeddcd28  pop rdx
0000796caeddcd29  pop rcx
0000796caeddcd2a  pop rax
0000796caeddcd2b  add rsp, 0x08
0000796caeddcd2f  jmp 0x0000796CAEDDBB99
0000796caeddcd34  sub rsp, 0x08
0000796caeddcd38  push rax
0000796caeddcd39  push rcx
0000796caeddcd3a  push rdx
0000796caeddcd3b  push rdi
0000796caeddcd3c  push rsi
0000796caeddcd3d  push r8
0000796caeddcd3f  push r9
0000796caeddcd41  push r10
0000796caeddcd43  push r11
0000796caeddcd45  sub rsp, 0xF0
0000796caeddcd4c  vmovaps [rsp], xmm0
0000796caeddcd51  vmovaps [rsp+0x10], xmm1
0000796caeddcd57  vmovaps [rsp+0x20], xmm2
0000796caeddcd5d  vmovaps [rsp+0x30], xmm3
0000796caeddcd63  vmovaps [rsp+0x40], xmm4
0000796caeddcd69  vmovaps [rsp+0x50], xmm5
0000796caeddcd6f  vmovaps [rsp+0x60], xmm6
0000796caeddcd75  vmovaps [rsp+0x70], xmm7
0000796caeddcd7b  vmovaps [rsp+0x80], xmm8
0000796caeddcd84  vmovaps [rsp+0x90], xmm9
0000796caeddcd8d  vmovaps [rsp+0xA0], xmm11
0000796caeddcd96  vmovaps [rsp+0xB0], xmm12
0000796caeddcd9f  vmovaps [rsp+0xC0], xmm13
0000796caeddcda8  vmovaps [rsp+0xD0], xmm14
0000796caeddcdb1  vmovaps [rsp+0xE0], xmm15
0000796caeddcdba  sub rsp, 0x30
0000796caeddcdbe  movaps [rsp], xmm10
0000796caeddcdc3  movaps [rsp+0x10], xmm12
0000796caeddcdc9  movaps [rsp+0x20], xmm11
0000796caeddcdcf  lea rdi, [rsp]
0000796caeddcdd3  mov esi, 0x00
0000796caeddcdd8  mov rax, 0x56877063A530
0000796caeddcde2  call rax
0000796caeddcde4  movaps xmm10, [rsp]
0000796caeddcde9  add rsp, 0x30
0000796caeddcded  vmovaps xmm0, [rsp]
0000796caeddcdf2  vmovaps xmm1, [rsp+0x10]
0000796caeddcdf8  vmovaps xmm2, [rsp+0x20]
0000796caeddcdfe  vmovaps xmm3, [rsp+0x30]
0000796caeddce04  vmovaps xmm4, [rsp+0x40]
0000796caeddce0a  vmovaps xmm5, [rsp+0x50]
0000796caeddce10  vmovaps xmm6, [rsp+0x60]
0000796caeddce16  vmovaps xmm7, [rsp+0x70]
0000796caeddce1c  vmovaps xmm8, [rsp+0x80]
0000796caeddce25  vmovaps xmm9, [rsp+0x90]
0000796caeddce2e  vmovaps xmm11, [rsp+0xA0]
0000796caeddce37  vmovaps xmm12, [rsp+0xB0]
0000796caeddce40  vmovaps xmm13, [rsp+0xC0]
0000796caeddce49  vmovaps xmm14, [rsp+0xD0]
0000796caeddce52  vmovaps xmm15, [rsp+0xE0]
0000796caeddce5b  add rsp, 0xF0
0000796caeddce62  pop r11
0000796caeddce64  pop r10
0000796caeddce66  pop r9
0000796caeddce68  pop r8
0000796caeddce6a  pop rsi
0000796caeddce6b  pop rdi
0000796caeddce6c  pop rdx
0000796caeddce6d  pop rcx
0000796caeddce6e  pop rax
0000796caeddce6f  add rsp, 0x08
0000796caeddce73  jmp 0x0000796CAEDDBBB3
0000796caeddce78  sub rsp, 0x08
0000796caeddce7c  push rax
0000796caeddce7d  push rcx
0000796caeddce7e  push rdx
0000796caeddce7f  push rdi
0000796caeddce80  push rsi
0000796caeddce81  push r8
0000796caeddce83  push r9
0000796caeddce85  push r10
0000796caeddce87  push r11
0000796caeddce89  sub rsp, 0xF0
0000796caeddce90  vmovaps [rsp], xmm0
0000796caeddce95  vmovaps [rsp+0x10], xmm1
0000796caeddce9b  vmovaps [rsp+0x20], xmm2
0000796caeddcea1  vmovaps [rsp+0x30], xmm3
0000796caeddcea7  vmovaps [rsp+0x40], xmm4
0000796caeddcead  vmovaps [rsp+0x50], xmm5
0000796caeddceb3  vmovaps [rsp+0x60], xmm7
0000796caeddceb9  vmovaps [rsp+0x70], xmm8
0000796caeddcebf  vmovaps [rsp+0x80], xmm9
0000796caeddcec8  vmovaps [rsp+0x90], xmm10
0000796caeddced1  vmovaps [rsp+0xA0], xmm11
0000796caeddceda  vmovaps [rsp+0xB0], xmm12
0000796caeddcee3  vmovaps [rsp+0xC0], xmm13
0000796caeddceec  vmovaps [rsp+0xD0], xmm14
0000796caeddcef5  vmovaps [rsp+0xE0], xmm15
0000796caeddcefe  sub rsp, 0x30
0000796caeddcf02  movaps [rsp], xmm6
0000796caeddcf06  movaps [rsp+0x10], xmm12
0000796caeddcf0c  movaps [rsp+0x20], xmm11
0000796caeddcf12  lea rdi, [rsp]
0000796caeddcf16  mov esi, 0x00
0000796caeddcf1b  mov rax, 0x56877063A530
0000796caeddcf25  call rax
0000796caeddcf27  movaps xmm6, [rsp]
0000796caeddcf2b  add rsp, 0x30
0000796caeddcf2f  vmovaps xmm0, [rsp]
0000796caeddcf34  vmovaps xmm1, [rsp+0x10]
0000796caeddcf3a  vmovaps xmm2, [rsp+0x20]
0000796caeddcf40  vmovaps xmm3, [rsp+0x30]
0000796caeddcf46  vmovaps xmm4, [rsp+0x40]
0000796caeddcf4c  vmovaps xmm5, [rsp+0x50]
0000796caeddcf52  vmovaps xmm7, [rsp+0x60]
0000796caeddcf58  vmovaps xmm8, [rsp+0x70]
0000796caeddcf5e  vmovaps xmm9, [rsp+0x80]
0000796caeddcf67  vmovaps xmm10, [rsp+0x90]
0000796caeddcf70  vmovaps xmm11, [rsp+0xA0]
0000796caeddcf79  vmovaps xmm12, [rsp+0xB0]
0000796caeddcf82  vmovaps xmm13, [rsp+0xC0]
0000796caeddcf8b  vmovaps xmm14, [rsp+0xD0]
0000796caeddcf94  vmovaps xmm15, [rsp+0xE0]
0000796caeddcf9d  add rsp, 0xF0
0000796caeddcfa4  pop r11
0000796caeddcfa6  pop r10
0000796caeddcfa8  pop r9
0000796caeddcfaa  pop r8
0000796caeddcfac  pop rsi
0000796caeddcfad  pop rdi
0000796caeddcfae  pop rdx
0000796caeddcfaf  pop rcx
0000796caeddcfb0  pop rax
0000796caeddcfb1  add rsp, 0x08
0000796caeddcfb5  jmp 0x0000796CAEDDBBD4
0000796caeddcfba  sub rsp, 0x08
0000796caeddcfbe  push rax
0000796caeddcfbf  push rcx
0000796caeddcfc0  push rdx
0000796caeddcfc1  push rdi
0000796caeddcfc2  push rsi
0000796caeddcfc3  push r8
0000796caeddcfc5  push r9
0000796caeddcfc7  push r10
0000796caeddcfc9  push r11
0000796caeddcfcb  sub rsp, 0xF0
0000796caeddcfd2  vmovaps [rsp], xmm0
0000796caeddcfd7  vmovaps [rsp+0x10], xmm1
0000796caeddcfdd  vmovaps [rsp+0x20], xmm2
0000796caeddcfe3  vmovaps [rsp+0x30], xmm4
0000796caeddcfe9  vmovaps [rsp+0x40], xmm5
0000796caeddcfef  vmovaps [rsp+0x50], xmm6
0000796caeddcff5  vmovaps [rsp+0x60], xmm7
0000796caeddcffb  vmovaps [rsp+0x70], xmm8
0000796caeddd001  vmovaps [rsp+0x80], xmm9
0000796caeddd00a  vmovaps [rsp+0x90], xmm10
0000796caeddd013  vmovaps [rsp+0xA0], xmm11
0000796caeddd01c  vmovaps [rsp+0xB0], xmm12
0000796caeddd025  vmovaps [rsp+0xC0], xmm13
0000796caeddd02e  vmovaps [rsp+0xD0], xmm14
0000796caeddd037  vmovaps [rsp+0xE0], xmm15
0000796caeddd040  sub rsp, 0x30
0000796caeddd044  movaps [rsp], xmm3
0000796caeddd048  movaps [rsp+0x10], xmm5
0000796caeddd04d  movaps [rsp+0x20], xmm4
0000796caeddd052  lea rdi, [rsp]
0000796caeddd056  mov esi, 0x00
0000796caeddd05b  mov rax, 0x56877063A530
0000796caeddd065  call rax
0000796caeddd067  movaps xmm3, [rsp]
0000796caeddd06b  add rsp, 0x30
0000796caeddd06f  vmovaps xmm0, [rsp]
0000796caeddd074  vmovaps xmm1, [rsp+0x10]
0000796caeddd07a  vmovaps xmm2, [rsp+0x20]
0000796caeddd080  vmovaps xmm4, [rsp+0x30]
0000796caeddd086  vmovaps xmm5, [rsp+0x40]
0000796caeddd08c  vmovaps xmm6, [rsp+0x50]
0000796caeddd092  vmovaps xmm7, [rsp+0x60]
0000796caeddd098  vmovaps xmm8, [rsp+0x70]
0000796caeddd09e  vmovaps xmm9, [rsp+0x80]
0000796caeddd0a7  vmovaps xmm10, [rsp+0x90]
0000796caeddd0b0  vmovaps xmm11, [rsp+0xA0]
0000796caeddd0b9  vmovaps xmm12, [rsp+0xB0]
0000796caeddd0c2  vmovaps xmm13, [rsp+0xC0]
0000796caeddd0cb  vmovaps xmm14, [rsp+0xD0]
0000796caeddd0d4  vmovaps xmm15, [rsp+0xE0]
0000796caeddd0dd  add rsp, 0xF0
0000796caeddd0e4  pop r11
0000796caeddd0e6  pop r10
0000796caeddd0e8  pop r9
0000796caeddd0ea  pop r8
0000796caeddd0ec  pop rsi
0000796caeddd0ed  pop rdi
0000796caeddd0ee  pop rdx
0000796caeddd0ef  pop rcx
0000796caeddd0f0  pop rax
0000796caeddd0f1  add rsp, 0x08
0000796caeddd0f5  jmp 0x0000796CAEDDBC35
0000796caeddd0fa  sub rsp, 0x08
0000796caeddd0fe  push rax
0000796caeddd0ff  push rcx
0000796caeddd100  push rdx
0000796caeddd101  push rdi
0000796caeddd102  push rsi
0000796caeddd103  push r8
0000796caeddd105  push r9
0000796caeddd107  push r10
0000796caeddd109  push r11
0000796caeddd10b  sub rsp, 0xF0
0000796caeddd112  vmovaps [rsp], xmm0
0000796caeddd117  vmovaps [rsp+0x10], xmm1
0000796caeddd11d  vmovaps [rsp+0x20], xmm2
0000796caeddd123  vmovaps [rsp+0x30], xmm3
0000796caeddd129  vmovaps [rsp+0x40], xmm4
0000796caeddd12f  vmovaps [rsp+0x50], xmm6
0000796caeddd135  vmovaps [rsp+0x60], xmm7
0000796caeddd13b  vmovaps [rsp+0x70], xmm8
0000796caeddd141  vmovaps [rsp+0x80], xmm9
0000796caeddd14a  vmovaps [rsp+0x90], xmm10
0000796caeddd153  vmovaps [rsp+0xA0], xmm11
0000796caeddd15c  vmovaps [rsp+0xB0], xmm12
0000796caeddd165  vmovaps [rsp+0xC0], xmm13
0000796caeddd16e  vmovaps [rsp+0xD0], xmm14
0000796caeddd177  vmovaps [rsp+0xE0], xmm15
0000796caeddd180  sub rsp, 0x30
0000796caeddd184  movaps [rsp], xmm5
0000796caeddd188  movaps [rsp+0x10], xmm8
0000796caeddd18e  movaps [rsp+0x20], xmm15
0000796caeddd194  lea rdi, [rsp]
0000796caeddd198  mov esi, 0x00
0000796caeddd19d  mov rax, 0x56877063A530
0000796caeddd1a7  call rax
0000796caeddd1a9  movaps xmm5, [rsp]
0000796caeddd1ad  add rsp, 0x30
0000796caeddd1b1  vmovaps xmm0, [rsp]
0000796caeddd1b6  vmovaps xmm1, [rsp+0x10]
0000796caeddd1bc  vmovaps xmm2, [rsp+0x20]
0000796caeddd1c2  vmovaps xmm3, [rsp+0x30]
0000796caeddd1c8  vmovaps xmm4, [rsp+0x40]
0000796caeddd1ce  vmovaps xmm6, [rsp+0x50]
0000796caeddd1d4  vmovaps xmm7, [rsp+0x60]
0000796caeddd1da  vmovaps xmm8, [rsp+0x70]
0000796caeddd1e0  vmovaps xmm9, [rsp+0x80]
0000796caeddd1e9  vmovaps xmm10, [rsp+0x90]
0000796caeddd1f2  vmovaps xmm11, [rsp+0xA0]
0000796caeddd1fb  vmovaps xmm12, [rsp+0xB0]
0000796caeddd204  vmovaps xmm13, [rsp+0xC0]
0000796caeddd20d  vmovaps xmm14, [rsp+0xD0]
0000796caeddd216  vmovaps xmm15, [rsp+0xE0]
0000796caeddd21f  add rsp, 0xF0
0000796caeddd226  pop r11
0000796caeddd228  pop r10
0000796caeddd22a  pop r9
0000796caeddd22c  pop r8
0000796caeddd22e  pop rsi
0000796caeddd22f  pop rdi
0000796caeddd230  pop rdx
0000796caeddd231  pop rcx
0000796caeddd232  pop rax
0000796caeddd233  add rsp, 0x08
0000796caeddd237  jmp 0x0000796CAEDDBC73
0000796caeddd23c  sub rsp, 0x08
0000796caeddd240  push rax
0000796caeddd241  push rcx
0000796caeddd242  push rdx
0000796caeddd243  push rdi
0000796caeddd244  push rsi
0000796caeddd245  push r8
0000796caeddd247  push r9
0000796caeddd249  push r10
0000796caeddd24b  push r11
0000796caeddd24d  sub rsp, 0xF0
0000796caeddd254  vmovaps [rsp], xmm0
0000796caeddd259  vmovaps [rsp+0x10], xmm1
0000796caeddd25f  vmovaps [rsp+0x20], xmm2
0000796caeddd265  vmovaps [rsp+0x30], xmm3
0000796caeddd26b  vmovaps [rsp+0x40], xmm5
0000796caeddd271  vmovaps [rsp+0x50], xmm6
0000796caeddd277  vmovaps [rsp+0x60], xmm7
0000796caeddd27d  vmovaps [rsp+0x70], xmm8
0000796caeddd283  vmovaps [rsp+0x80], xmm9
0000796caeddd28c  vmovaps [rsp+0x90], xmm10
0000796caeddd295  vmovaps [rsp+0xA0], xmm11
0000796caeddd29e  vmovaps [rsp+0xB0], xmm12
0000796caeddd2a7  vmovaps [rsp+0xC0], xmm13
0000796caeddd2b0  vmovaps [rsp+0xD0], xmm14
0000796caeddd2b9  vmovaps [rsp+0xE0], xmm15
0000796caeddd2c2  sub rsp, 0x30
0000796caeddd2c6  movaps [rsp], xmm4
0000796caeddd2ca  movaps [rsp+0x10], xmm9
0000796caeddd2d0  movaps [rsp+0x20], xmm8
0000796caeddd2d6  lea rdi, [rsp]
0000796caeddd2da  mov esi, 0x00
0000796caeddd2df  mov rax, 0x56877063A530
0000796caeddd2e9  call rax
0000796caeddd2eb  movaps xmm4, [rsp]
0000796caeddd2ef  add rsp, 0x30
0000796caeddd2f3  vmovaps xmm0, [rsp]
0000796caeddd2f8  vmovaps xmm1, [rsp+0x10]
0000796caeddd2fe  vmovaps xmm2, [rsp+0x20]
0000796caeddd304  vmovaps xmm3, [rsp+0x30]
0000796caeddd30a  vmovaps xmm5, [rsp+0x40]
0000796caeddd310  vmovaps xmm6, [rsp+0x50]
0000796caeddd316  vmovaps xmm7, [rsp+0x60]
0000796caeddd31c  vmovaps xmm8, [rsp+0x70]
0000796caeddd322  vmovaps xmm9, [rsp+0x80]
0000796caeddd32b  vmovaps xmm10, [rsp+0x90]
0000796caeddd334  vmovaps xmm11, [rsp+0xA0]
0000796caeddd33d  vmovaps xmm12, [rsp+0xB0]
0000796caeddd346  vmovaps xmm13, [rsp+0xC0]
0000796caeddd34f  vmovaps xmm14, [rsp+0xD0]
0000796caeddd358  vmovaps xmm15, [rsp+0xE0]
0000796caeddd361  add rsp, 0xF0
0000796caeddd368  pop r11
0000796caeddd36a  pop r10
0000796caeddd36c  pop r9
0000796caeddd36e  pop r8
0000796caeddd370  pop rsi
0000796caeddd371  pop rdi
0000796caeddd372  pop rdx
0000796caeddd373  pop rcx
0000796caeddd374  pop rax
0000796caeddd375  add rsp, 0x08
0000796caeddd379  jmp 0x0000796CAEDDBC94
0000796caeddd37e  sub rsp, 0x08
0000796caeddd382  push rax
0000796caeddd383  push rcx
0000796caeddd384  push rdx
0000796caeddd385  push rdi
0000796caeddd386  push rsi
0000796caeddd387  push r8
0000796caeddd389  push r9
0000796caeddd38b  push r10
0000796caeddd38d  push r11
0000796caeddd38f  sub rsp, 0xF0
0000796caeddd396  vmovaps [rsp], xmm0
0000796caeddd39b  vmovaps [rsp+0x10], xmm1
0000796caeddd3a1  vmovaps [rsp+0x20], xmm2
0000796caeddd3a7  vmovaps [rsp+0x30], xmm3
0000796caeddd3ad  vmovaps [rsp+0x40], xmm4
0000796caeddd3b3  vmovaps [rsp+0x50], xmm5
0000796caeddd3b9  vmovaps [rsp+0x60], xmm6
0000796caeddd3bf  vmovaps [rsp+0x70], xmm7
0000796caeddd3c5  vmovaps [rsp+0x80], xmm8
0000796caeddd3ce  vmovaps [rsp+0x90], xmm10
0000796caeddd3d7  vmovaps [rsp+0xA0], xmm11
0000796caeddd3e0  vmovaps [rsp+0xB0], xmm12
0000796caeddd3e9  vmovaps [rsp+0xC0], xmm13
0000796caeddd3f2  vmovaps [rsp+0xD0], xmm14
0000796caeddd3fb  vmovaps [rsp+0xE0], xmm15
0000796caeddd404  sub rsp, 0x30
0000796caeddd408  movaps [rsp], xmm9
0000796caeddd40d  movaps [rsp+0x10], xmm10
0000796caeddd413  movaps [rsp+0x20], xmm8
0000796caeddd419  lea rdi, [rsp]
0000796caeddd41d  mov esi, 0x00
0000796caeddd422  mov rax, 0x56877063A530
0000796caeddd42c  call rax
0000796caeddd42e  movaps xmm9, [rsp]
0000796caeddd433  add rsp, 0x30
0000796caeddd437  vmovaps xmm0, [rsp]
0000796caeddd43c  vmovaps xmm1, [rsp+0x10]
0000796caeddd442  vmovaps xmm2, [rsp+0x20]
0000796caeddd448  vmovaps xmm3, [rsp+0x30]
0000796caeddd44e  vmovaps xmm4, [rsp+0x40]
0000796caeddd454  vmovaps xmm5, [rsp+0x50]
0000796caeddd45a  vmovaps xmm6, [rsp+0x60]
0000796caeddd460  vmovaps xmm7, [rsp+0x70]
0000796caeddd466  vmovaps xmm8, [rsp+0x80]
0000796caeddd46f  vmovaps xmm10, [rsp+0x90]
0000796caeddd478  vmovaps xmm11, [rsp+0xA0]
0000796caeddd481  vmovaps xmm12, [rsp+0xB0]
0000796caeddd48a  vmovaps xmm13, [rsp+0xC0]
0000796caeddd493  vmovaps xmm14, [rsp+0xD0]
0000796caeddd49c  vmovaps xmm15, [rsp+0xE0]
0000796caeddd4a5  add rsp, 0xF0
0000796caeddd4ac  pop r11
0000796caeddd4ae  pop r10
0000796caeddd4b0  pop r9
0000796caeddd4b2  pop r8
0000796caeddd4b4  pop rsi
0000796caeddd4b5  pop rdi
0000796caeddd4b6  pop rdx
0000796caeddd4b7  pop rcx
0000796caeddd4b8  pop rax
0000796caeddd4b9  add rsp, 0x08
0000796caeddd4bd  jmp 0x0000796CAEDDBCAE
0000796caeddd4c2  call 0x0000796CAECB52F0
0000796caeddd4c7  jmp 0x0000796CAEDDBDC8
0000796caeddd4cc  call 0x0000796CAECB52F0
0000796caeddd4d1  jmp 0x0000796CAEDDBDDE
0000796caeddd4d6  sub rsp, 0x08
0000796caeddd4da  push rax
0000796caeddd4db  push rcx
0000796caeddd4dc  push rdx
0000796caeddd4dd  push rdi
0000796caeddd4de  push rsi
0000796caeddd4df  push r8
0000796caeddd4e1  push r9
0000796caeddd4e3  push r10
0000796caeddd4e5  push r11
0000796caeddd4e7  sub rsp, 0xF0
0000796caeddd4ee  vmovaps [rsp], xmm0
0000796caeddd4f3  vmovaps [rsp+0x10], xmm2
0000796caeddd4f9  vmovaps [rsp+0x20], xmm3
0000796caeddd4ff  vmovaps [rsp+0x30], xmm4
0000796caeddd505  vmovaps [rsp+0x40], xmm5
0000796caeddd50b  vmovaps [rsp+0x50], xmm6
0000796caeddd511  vmovaps [rsp+0x60], xmm7
0000796caeddd517  vmovaps [rsp+0x70], xmm8
0000796caeddd51d  vmovaps [rsp+0x80], xmm9
0000796caeddd526  vmovaps [rsp+0x90], xmm10
0000796caeddd52f  vmovaps [rsp+0xA0], xmm11
0000796caeddd538  vmovaps [rsp+0xB0], xmm12
0000796caeddd541  vmovaps [rsp+0xC0], xmm13
0000796caeddd54a  vmovaps [rsp+0xD0], xmm14
0000796caeddd553  vmovaps [rsp+0xE0], xmm15
0000796caeddd55c  sub rsp, 0x30
0000796caeddd560  movaps [rsp], xmm1
0000796caeddd564  movaps [rsp+0x10], xmm6
0000796caeddd569  movaps [rsp+0x20], xmm15
0000796caeddd56f  lea rdi, [rsp]
0000796caeddd573  mov esi, 0x00
0000796caeddd578  mov rax, 0x56877063A530
0000796caeddd582  call rax
0000796caeddd584  movaps xmm1, [rsp]
0000796caeddd588  add rsp, 0x30
0000796caeddd58c  vmovaps xmm0, [rsp]
0000796caeddd591  vmovaps xmm2, [rsp+0x10]
0000796caeddd597  vmovaps xmm3, [rsp+0x20]
0000796caeddd59d  vmovaps xmm4, [rsp+0x30]
0000796caeddd5a3  vmovaps xmm5, [rsp+0x40]
0000796caeddd5a9  vmovaps xmm6, [rsp+0x50]
0000796caeddd5af  vmovaps xmm7, [rsp+0x60]
0000796caeddd5b5  vmovaps xmm8, [rsp+0x70]
0000796caeddd5bb  vmovaps xmm9, [rsp+0x80]
0000796caeddd5c4  vmovaps xmm10, [rsp+0x90]
0000796caeddd5cd  vmovaps xmm11, [rsp+0xA0]
0000796caeddd5d6  vmovaps xmm12, [rsp+0xB0]
0000796caeddd5df  vmovaps xmm13, [rsp+0xC0]
0000796caeddd5e8  vmovaps xmm14, [rsp+0xD0]
0000796caeddd5f1  vmovaps xmm15, [rsp+0xE0]
0000796caeddd5fa  add rsp, 0xF0
0000796caeddd601  pop r11
0000796caeddd603  pop r10
0000796caeddd605  pop r9
0000796caeddd607  pop r8
0000796caeddd609  pop rsi
0000796caeddd60a  pop rdi
0000796caeddd60b  pop rdx
0000796caeddd60c  pop rcx
0000796caeddd60d  pop rax
0000796caeddd60e  add rsp, 0x08
0000796caeddd612  jmp 0x0000796CAEDDBE1B
0000796caeddd617  call 0x0000796CAECC4620
0000796caeddd61c  jmp 0x0000796CAEDDBE28
0000796caeddd621  sub rsp, 0x08
0000796caeddd625  push rax
0000796caeddd626  push rcx
0000796caeddd627  push rdx
0000796caeddd628  push rdi
0000796caeddd629  push rsi
0000796caeddd62a  push r8
0000796caeddd62c  push r9
0000796caeddd62e  push r10
0000796caeddd630  push r11
0000796caeddd632  sub rsp, 0xF0
0000796caeddd639  vmovaps [rsp], xmm0
0000796caeddd63e  vmovaps [rsp+0x10], xmm1
0000796caeddd644  vmovaps [rsp+0x20], xmm2
0000796caeddd64a  vmovaps [rsp+0x30], xmm3
0000796caeddd650  vmovaps [rsp+0x40], xmm4
0000796caeddd656  vmovaps [rsp+0x50], xmm5
0000796caeddd65c  vmovaps [rsp+0x60], xmm6
0000796caeddd662  vmovaps [rsp+0x70], xmm7
0000796caeddd668  vmovaps [rsp+0x80], xmm8
0000796caeddd671  vmovaps [rsp+0x90], xmm9
0000796caeddd67a  vmovaps [rsp+0xA0], xmm10
0000796caeddd683  vmovaps [rsp+0xB0], xmm11
0000796caeddd68c  vmovaps [rsp+0xC0], xmm12
0000796caeddd695  vmovaps [rsp+0xD0], xmm13
0000796caeddd69e  vmovaps [rsp+0xE0], xmm15
0000796caeddd6a7  sub rsp, 0x30
0000796caeddd6ab  movaps [rsp], xmm14
0000796caeddd6b0  movaps [rsp+0x10], xmm4
0000796caeddd6b5  movaps [rsp+0x20], xmm3
0000796caeddd6ba  lea rdi, [rsp]
0000796caeddd6be  mov esi, 0x00
0000796caeddd6c3  mov rax, 0x56877063A530
0000796caeddd6cd  call rax
0000796caeddd6cf  movaps xmm14, [rsp]
0000796caeddd6d4  add rsp, 0x30
0000796caeddd6d8  vmovaps xmm0, [rsp]
0000796caeddd6dd  vmovaps xmm1, [rsp+0x10]
0000796caeddd6e3  vmovaps xmm2, [rsp+0x20]
0000796caeddd6e9  vmovaps xmm3, [rsp+0x30]
0000796caeddd6ef  vmovaps xmm4, [rsp+0x40]
0000796caeddd6f5  vmovaps xmm5, [rsp+0x50]
0000796caeddd6fb  vmovaps xmm6, [rsp+0x60]
0000796caeddd701  vmovaps xmm7, [rsp+0x70]
0000796caeddd707  vmovaps xmm8, [rsp+0x80]
0000796caeddd710  vmovaps xmm9, [rsp+0x90]
0000796caeddd719  vmovaps xmm10, [rsp+0xA0]
0000796caeddd722  vmovaps xmm11, [rsp+0xB0]
0000796caeddd72b  vmovaps xmm12, [rsp+0xC0]
0000796caeddd734  vmovaps xmm13, [rsp+0xD0]
0000796caeddd73d  vmovaps xmm15, [rsp+0xE0]
0000796caeddd746  add rsp, 0xF0
0000796caeddd74d  pop r11
0000796caeddd74f  pop r10
0000796caeddd751  pop r9
0000796caeddd753  pop r8
0000796caeddd755  pop rsi
0000796caeddd756  pop rdi
0000796caeddd757  pop rdx
0000796caeddd758  pop rcx
0000796caeddd759  pop rax
0000796caeddd75a  add rsp, 0x08
0000796caeddd75e  jmp 0x0000796CAEDDBE42
0000796caeddd763  sub rsp, 0x08
0000796caeddd767  push rax
0000796caeddd768  push rcx
0000796caeddd769  push rdx
0000796caeddd76a  push rdi
0000796caeddd76b  push rsi
0000796caeddd76c  push r8
0000796caeddd76e  push r9
0000796caeddd770  push r10
0000796caeddd772  push r11
0000796caeddd774  sub rsp, 0xF0
0000796caeddd77b  vmovaps [rsp], xmm0
0000796caeddd780  vmovaps [rsp+0x10], xmm1
0000796caeddd786  vmovaps [rsp+0x20], xmm2
0000796caeddd78c  vmovaps [rsp+0x30], xmm3
0000796caeddd792  vmovaps [rsp+0x40], xmm4
0000796caeddd798  vmovaps [rsp+0x50], xmm5
0000796caeddd79e  vmovaps [rsp+0x60], xmm7
0000796caeddd7a4  vmovaps [rsp+0x70], xmm8
0000796caeddd7aa  vmovaps [rsp+0x80], xmm9
0000796caeddd7b3  vmovaps [rsp+0x90], xmm10
0000796caeddd7bc  vmovaps [rsp+0xA0], xmm11
0000796caeddd7c5  vmovaps [rsp+0xB0], xmm12
0000796caeddd7ce  vmovaps [rsp+0xC0], xmm13
0000796caeddd7d7  vmovaps [rsp+0xD0], xmm14
0000796caeddd7e0  vmovaps [rsp+0xE0], xmm15
0000796caeddd7e9  sub rsp, 0x30
0000796caeddd7ed  movaps [rsp], xmm6
0000796caeddd7f1  movaps [rsp+0x10], xmm9
0000796caeddd7f7  movaps [rsp+0x20], xmm7
0000796caeddd7fc  lea rdi, [rsp]
0000796caeddd800  mov esi, 0x00
0000796caeddd805  mov rax, 0x56877063A530
0000796caeddd80f  call rax
0000796caeddd811  movaps xmm6, [rsp]
0000796caeddd815  add rsp, 0x30
0000796caeddd819  vmovaps xmm0, [rsp]
0000796caeddd81e  vmovaps xmm1, [rsp+0x10]
0000796caeddd824  vmovaps xmm2, [rsp+0x20]
0000796caeddd82a  vmovaps xmm3, [rsp+0x30]
0000796caeddd830  vmovaps xmm4, [rsp+0x40]
0000796caeddd836  vmovaps xmm5, [rsp+0x50]
0000796caeddd83c  vmovaps xmm7, [rsp+0x60]
0000796caeddd842  vmovaps xmm8, [rsp+0x70]
0000796caeddd848  vmovaps xmm9, [rsp+0x80]
0000796caeddd851  vmovaps xmm10, [rsp+0x90]
0000796caeddd85a  vmovaps xmm11, [rsp+0xA0]
0000796caeddd863  vmovaps xmm12, [rsp+0xB0]
0000796caeddd86c  vmovaps xmm13, [rsp+0xC0]
0000796caeddd875  vmovaps xmm14, [rsp+0xD0]
0000796caeddd87e  vmovaps xmm15, [rsp+0xE0]
0000796caeddd887  add rsp, 0xF0
0000796caeddd88e  pop r11
0000796caeddd890  pop r10
0000796caeddd892  pop r9
0000796caeddd894  pop r8
0000796caeddd896  pop rsi
0000796caeddd897  pop rdi
0000796caeddd898  pop rdx
0000796caeddd899  pop rcx
0000796caeddd89a  pop rax
0000796caeddd89b  add rsp, 0x08
0000796caeddd89f  jmp 0x0000796CAEDDBE5A
0000796caeddd8a4  sub rsp, 0x08
0000796caeddd8a8  push rax
0000796caeddd8a9  push rcx
0000796caeddd8aa  push rdx
0000796caeddd8ab  push rdi
0000796caeddd8ac  push rsi
0000796caeddd8ad  push r8
0000796caeddd8af  push r9
0000796caeddd8b1  push r10
0000796caeddd8b3  push r11
0000796caeddd8b5  sub rsp, 0xF0
0000796caeddd8bc  vmovaps [rsp], xmm0
0000796caeddd8c1  vmovaps [rsp+0x10], xmm1
0000796caeddd8c7  vmovaps [rsp+0x20], xmm2
0000796caeddd8cd  vmovaps [rsp+0x30], xmm3
0000796caeddd8d3  vmovaps [rsp+0x40], xmm4
0000796caeddd8d9  vmovaps [rsp+0x50], xmm5
0000796caeddd8df  vmovaps [rsp+0x60], xmm6
0000796caeddd8e5  vmovaps [rsp+0x70], xmm8
0000796caeddd8eb  vmovaps [rsp+0x80], xmm9
0000796caeddd8f4  vmovaps [rsp+0x90], xmm10
0000796caeddd8fd  vmovaps [rsp+0xA0], xmm11
0000796caeddd906  vmovaps [rsp+0xB0], xmm12
0000796caeddd90f  vmovaps [rsp+0xC0], xmm13
0000796caeddd918  vmovaps [rsp+0xD0], xmm14
0000796caeddd921  vmovaps [rsp+0xE0], xmm15
0000796caeddd92a  sub rsp, 0x30
0000796caeddd92e  movaps [rsp], xmm7
0000796caeddd932  movaps [rsp+0x10], xmm4
0000796caeddd937  movaps [rsp+0x20], xmm9
0000796caeddd93d  lea rdi, [rsp]
0000796caeddd941  mov esi, 0x00
0000796caeddd946  mov rax, 0x56877063A530
0000796caeddd950  call rax
0000796caeddd952  movaps xmm7, [rsp]
0000796caeddd956  add rsp, 0x30
0000796caeddd95a  vmovaps xmm0, [rsp]
0000796caeddd95f  vmovaps xmm1, [rsp+0x10]
0000796caeddd965  vmovaps xmm2, [rsp+0x20]
0000796caeddd96b  vmovaps xmm3, [rsp+0x30]
0000796caeddd971  vmovaps xmm4, [rsp+0x40]
0000796caeddd977  vmovaps xmm5, [rsp+0x50]
0000796caeddd97d  vmovaps xmm6, [rsp+0x60]
0000796caeddd983  vmovaps xmm8, [rsp+0x70]
0000796caeddd989  vmovaps xmm9, [rsp+0x80]
0000796caeddd992  vmovaps xmm10, [rsp+0x90]
0000796caeddd99b  vmovaps xmm11, [rsp+0xA0]
0000796caeddd9a4  vmovaps xmm12, [rsp+0xB0]
0000796caeddd9ad  vmovaps xmm13, [rsp+0xC0]
0000796caeddd9b6  vmovaps xmm14, [rsp+0xD0]
0000796caeddd9bf  vmovaps xmm15, [rsp+0xE0]
0000796caeddd9c8  add rsp, 0xF0
0000796caeddd9cf  pop r11
0000796caeddd9d1  pop r10
0000796caeddd9d3  pop r9
0000796caeddd9d5  pop r8
0000796caeddd9d7  pop rsi
0000796caeddd9d8  pop rdi
0000796caeddd9d9  pop rdx
0000796caeddd9da  pop rcx
0000796caeddd9db  pop rax
0000796caeddd9dc  add rsp, 0x08
0000796caeddd9e0  jmp 0x0000796CAEDDBE87
0000796caeddd9e5  sub rsp, 0x08
0000796caeddd9e9  push rax
0000796caeddd9ea  push rcx
0000796caeddd9eb  push rdx
0000796caeddd9ec  push rdi
0000796caeddd9ed  push rsi
0000796caeddd9ee  push r8
0000796caeddd9f0  push r9
0000796caeddd9f2  push r10
0000796caeddd9f4  push r11
0000796caeddd9f6  sub rsp, 0xF0
0000796caeddd9fd  vmovaps [rsp], xmm0
0000796caeddda02  vmovaps [rsp+0x10], xmm1
0000796caeddda08  vmovaps [rsp+0x20], xmm2
0000796caeddda0e  vmovaps [rsp+0x30], xmm3
0000796caeddda14  vmovaps [rsp+0x40], xmm5
0000796caeddda1a  vmovaps [rsp+0x50], xmm6
0000796caeddda20  vmovaps [rsp+0x60], xmm7
0000796caeddda26  vmovaps [rsp+0x70], xmm8
0000796caeddda2c  vmovaps [rsp+0x80], xmm9
0000796caeddda35  vmovaps [rsp+0x90], xmm10
0000796caeddda3e  vmovaps [rsp+0xA0], xmm11
0000796caeddda47  vmovaps [rsp+0xB0], xmm12
0000796caeddda50  vmovaps [rsp+0xC0], xmm13
0000796caeddda59  vmovaps [rsp+0xD0], xmm14
0000796caeddda62  vmovaps [rsp+0xE0], xmm15
0000796caeddda6b  sub rsp, 0x30
0000796caeddda6f  movaps [rsp], xmm4
0000796caeddda73  movaps [rsp+0x10], xmm15
0000796caeddda79  movaps [rsp+0x20], xmm9
0000796caeddda7f  lea rdi, [rsp]
0000796caeddda83  mov esi, 0x00
0000796caeddda88  mov rax, 0x56877063A530
0000796caeddda92  call rax
0000796caeddda94  movaps xmm4, [rsp]
0000796caeddda98  add rsp, 0x30
0000796caeddda9c  vmovaps xmm0, [rsp]
0000796caedddaa1  vmovaps xmm1, [rsp+0x10]
0000796caedddaa7  vmovaps xmm2, [rsp+0x20]
0000796caedddaad  vmovaps xmm3, [rsp+0x30]
0000796caedddab3  vmovaps xmm5, [rsp+0x40]
0000796caedddab9  vmovaps xmm6, [rsp+0x50]
0000796caedddabf  vmovaps xmm7, [rsp+0x60]
0000796caedddac5  vmovaps xmm8, [rsp+0x70]
0000796caedddacb  vmovaps xmm9, [rsp+0x80]
0000796caedddad4  vmovaps xmm10, [rsp+0x90]
0000796caedddadd  vmovaps xmm11, [rsp+0xA0]
0000796caedddae6  vmovaps xmm12, [rsp+0xB0]
0000796caedddaef  vmovaps xmm13, [rsp+0xC0]
0000796caedddaf8  vmovaps xmm14, [rsp+0xD0]
0000796caedddb01  vmovaps xmm15, [rsp+0xE0]
0000796caedddb0a  add rsp, 0xF0
0000796caedddb11  pop r11
0000796caedddb13  pop r10
0000796caedddb15  pop r9
0000796caedddb17  pop r8
0000796caedddb19  pop rsi
0000796caedddb1a  pop rdi
0000796caedddb1b  pop rdx
0000796caedddb1c  pop rcx
0000796caedddb1d  pop rax
0000796caedddb1e  add rsp, 0x08
0000796caedddb22  jmp 0x0000796CAEDDBEAC
0000796caedddb27  call 0x0000796CAECC4620
0000796caedddb2c  jmp 0x0000796CAEDDBEB9
0000796caedddb31  sub rsp, 0x08
0000796caedddb35  push rax
0000796caedddb36  push rcx
0000796caedddb37  push rdx
0000796caedddb38  push rdi
0000796caedddb39  push rsi
0000796caedddb3a  push r8
0000796caedddb3c  push r9
0000796caedddb3e  push r10
0000796caedddb40  push r11
0000796caedddb42  sub rsp, 0xF0
0000796caedddb49  vmovaps [rsp], xmm0
0000796caedddb4e  vmovaps [rsp+0x10], xmm1
0000796caedddb54  vmovaps [rsp+0x20], xmm2
0000796caedddb5a  vmovaps [rsp+0x30], xmm4
0000796caedddb60  vmovaps [rsp+0x40], xmm5
0000796caedddb66  vmovaps [rsp+0x50], xmm6
0000796caedddb6c  vmovaps [rsp+0x60], xmm7
0000796caedddb72  vmovaps [rsp+0x70], xmm8
0000796caedddb78  vmovaps [rsp+0x80], xmm9
0000796caedddb81  vmovaps [rsp+0x90], xmm10
0000796caedddb8a  vmovaps [rsp+0xA0], xmm11
0000796caedddb93  vmovaps [rsp+0xB0], xmm12
0000796caedddb9c  vmovaps [rsp+0xC0], xmm13
0000796caedddba5  vmovaps [rsp+0xD0], xmm14
0000796caedddbae  vmovaps [rsp+0xE0], xmm15
0000796caedddbb7  sub rsp, 0x30
0000796caedddbbb  movaps [rsp], xmm3
0000796caedddbbf  movaps [rsp+0x10], xmm1
0000796caedddbc4  movaps [rsp+0x20], xmm9
0000796caedddbca  lea rdi, [rsp]
0000796caedddbce  mov esi, 0x00
0000796caedddbd3  mov rax, 0x56877063A530
0000796caedddbdd  call rax
0000796caedddbdf  movaps xmm3, [rsp]
0000796caedddbe3  add rsp, 0x30
0000796caedddbe7  vmovaps xmm0, [rsp]
0000796caedddbec  vmovaps xmm1, [rsp+0x10]
0000796caedddbf2  vmovaps xmm2, [rsp+0x20]
0000796caedddbf8  vmovaps xmm4, [rsp+0x30]
0000796caedddbfe  vmovaps xmm5, [rsp+0x40]
0000796caedddc04  vmovaps xmm6, [rsp+0x50]
0000796caedddc0a  vmovaps xmm7, [rsp+0x60]
0000796caedddc10  vmovaps xmm8, [rsp+0x70]
0000796caedddc16  vmovaps xmm9, [rsp+0x80]
0000796caedddc1f  vmovaps xmm10, [rsp+0x90]
0000796caedddc28  vmovaps xmm11, [rsp+0xA0]
0000796caedddc31  vmovaps xmm12, [rsp+0xB0]
0000796caedddc3a  vmovaps xmm13, [rsp+0xC0]
0000796caedddc43  vmovaps xmm14, [rsp+0xD0]
0000796caedddc4c  vmovaps xmm15, [rsp+0xE0]
0000796caedddc55  add rsp, 0xF0
0000796caedddc5c  pop r11
0000796caedddc5e  pop r10
0000796caedddc60  pop r9
0000796caedddc62  pop r8
0000796caedddc64  pop rsi
0000796caedddc65  pop rdi
0000796caedddc66  pop rdx
0000796caedddc67  pop rcx
0000796caedddc68  pop rax
0000796caedddc69  add rsp, 0x08
0000796caedddc6d  jmp 0x0000796CAEDDBEF6
0000796caedddc72  sub rsp, 0x08
0000796caedddc76  push rax
0000796caedddc77  push rcx
0000796caedddc78  push rdx
0000796caedddc79  push rdi
0000796caedddc7a  push rsi
0000796caedddc7b  push r8
0000796caedddc7d  push r9
0000796caedddc7f  push r10
0000796caedddc81  push r11
0000796caedddc83  sub rsp, 0xF0
0000796caedddc8a  vmovaps [rsp], xmm0
0000796caedddc8f  vmovaps [rsp+0x10], xmm2
0000796caedddc95  vmovaps [rsp+0x20], xmm3
0000796caedddc9b  vmovaps [rsp+0x30], xmm4
0000796caedddca1  vmovaps [rsp+0x40], xmm5
0000796caedddca7  vmovaps [rsp+0x50], xmm6
0000796caedddcad  vmovaps [rsp+0x60], xmm7
0000796caedddcb3  vmovaps [rsp+0x70], xmm8
0000796caedddcb9  vmovaps [rsp+0x80], xmm9
0000796caedddcc2  vmovaps [rsp+0x90], xmm10
0000796caedddccb  vmovaps [rsp+0xA0], xmm11
0000796caedddcd4  vmovaps [rsp+0xB0], xmm12
0000796caedddcdd  vmovaps [rsp+0xC0], xmm13
0000796caedddce6  vmovaps [rsp+0xD0], xmm14
0000796caedddcef  vmovaps [rsp+0xE0], xmm15
0000796caedddcf8  sub rsp, 0x30
0000796caedddcfc  movaps [rsp], xmm1
0000796caedddd00  movaps [rsp+0x10], xmm15
0000796caedddd06  movaps [rsp+0x20], xmm9
0000796caedddd0c  lea rdi, [rsp]
0000796caedddd10  mov esi, 0x00
0000796caedddd15  mov rax, 0x56877063A530
0000796caedddd1f  call rax
0000796caedddd21  movaps xmm1, [rsp]
0000796caedddd25  add rsp, 0x30
0000796caedddd29  vmovaps xmm0, [rsp]
0000796caedddd2e  vmovaps xmm2, [rsp+0x10]
0000796caedddd34  vmovaps xmm3, [rsp+0x20]
0000796caedddd3a  vmovaps xmm4, [rsp+0x30]
0000796caedddd40  vmovaps xmm5, [rsp+0x40]
0000796caedddd46  vmovaps xmm6, [rsp+0x50]
0000796caedddd4c  vmovaps xmm7, [rsp+0x60]
0000796caedddd52  vmovaps xmm8, [rsp+0x70]
0000796caedddd58  vmovaps xmm9, [rsp+0x80]
0000796caedddd61  vmovaps xmm10, [rsp+0x90]
0000796caedddd6a  vmovaps xmm11, [rsp+0xA0]
0000796caedddd73  vmovaps xmm12, [rsp+0xB0]
0000796caedddd7c  vmovaps xmm13, [rsp+0xC0]
0000796caedddd85  vmovaps xmm14, [rsp+0xD0]
0000796caedddd8e  vmovaps xmm15, [rsp+0xE0]
0000796caedddd97  add rsp, 0xF0
0000796caedddd9e  pop r11
0000796caedddda0  pop r10
0000796caedddda2  pop r9
0000796caedddda4  pop r8
0000796caedddda6  pop rsi
0000796caedddda7  pop rdi
0000796caedddda8  pop rdx
0000796caedddda9  pop rcx
0000796caeddddaa  pop rax
0000796caeddddab  add rsp, 0x08
0000796caeddddaf  jmp 0x0000796CAEDDBF7E
0000796caeddddb4  call 0x0000796CAECC4620
0000796caeddddb9  jmp 0x0000796CAEDDBF8B
0000796caeddddbe  sub rsp, 0x08
0000796caeddddc2  push rax
0000796caeddddc3  push rcx
0000796caeddddc4  push rdx
0000796caeddddc5  push rdi
0000796caeddddc6  push rsi
0000796caeddddc7  push r8
0000796caeddddc9  push r9
0000796caeddddcb  push r10
0000796caeddddcd  push r11
0000796caeddddcf  sub rsp, 0xF0
0000796caeddddd6  vmovaps [rsp], xmm0
0000796caedddddb  vmovaps [rsp+0x10], xmm2
0000796caedddde1  vmovaps [rsp+0x20], xmm3
0000796caedddde7  vmovaps [rsp+0x30], xmm4
0000796caedddded  vmovaps [rsp+0x40], xmm5
0000796caeddddf3  vmovaps [rsp+0x50], xmm6
0000796caeddddf9  vmovaps [rsp+0x60], xmm7
0000796caeddddff  vmovaps [rsp+0x70], xmm8
0000796caeddde05  vmovaps [rsp+0x80], xmm9
0000796caeddde0e  vmovaps [rsp+0x90], xmm10
0000796caeddde17  vmovaps [rsp+0xA0], xmm11
0000796caeddde20  vmovaps [rsp+0xB0], xmm12
0000796caeddde29  vmovaps [rsp+0xC0], xmm13
0000796caeddde32  vmovaps [rsp+0xD0], xmm14
0000796caeddde3b  vmovaps [rsp+0xE0], xmm15
0000796caeddde44  sub rsp, 0x30
0000796caeddde48  movaps [rsp], xmm1
0000796caeddde4c  movaps [rsp+0x10], xmm5
0000796caeddde51  movaps [rsp+0x20], xmm7
0000796caeddde56  lea rdi, [rsp]
0000796caeddde5a  mov esi, 0x00
0000796caeddde5f  mov rax, 0x56877063A530
0000796caeddde69  call rax
0000796caeddde6b  movaps xmm1, [rsp]
0000796caeddde6f  add rsp, 0x30
0000796caeddde73  vmovaps xmm0, [rsp]
0000796caeddde78  vmovaps xmm2, [rsp+0x10]
0000796caeddde7e  vmovaps xmm3, [rsp+0x20]
0000796caeddde84  vmovaps xmm4, [rsp+0x30]
0000796caeddde8a  vmovaps xmm5, [rsp+0x40]
0000796caeddde90  vmovaps xmm6, [rsp+0x50]
0000796caeddde96  vmovaps xmm7, [rsp+0x60]
0000796caeddde9c  vmovaps xmm8, [rsp+0x70]
0000796caedddea2  vmovaps xmm9, [rsp+0x80]
0000796caedddeab  vmovaps xmm10, [rsp+0x90]
0000796caedddeb4  vmovaps xmm11, [rsp+0xA0]
0000796caedddebd  vmovaps xmm12, [rsp+0xB0]
0000796caedddec6  vmovaps xmm13, [rsp+0xC0]
0000796caedddecf  vmovaps xmm14, [rsp+0xD0]
0000796caeddded8  vmovaps xmm15, [rsp+0xE0]
0000796caedddee1  add rsp, 0xF0
0000796caedddee8  pop r11
0000796caedddeea  pop r10
0000796caedddeec  pop r9
0000796caedddeee  pop r8
0000796caedddef0  pop rsi
0000796caedddef1  pop rdi
0000796caedddef2  pop rdx
0000796caedddef3  pop rcx
0000796caedddef4  pop rax
0000796caedddef5  add rsp, 0x08
0000796caedddef9  jmp 0x0000796CAEDDC030
0000796caedddefe  sub rsp, 0x08
0000796caedddf02  push rax
0000796caedddf03  push rcx
0000796caedddf04  push rdx
0000796caedddf05  push rdi
0000796caedddf06  push rsi
0000796caedddf07  push r8
0000796caedddf09  push r9
0000796caedddf0b  push r10
0000796caedddf0d  push r11
0000796caedddf0f  sub rsp, 0xF0
0000796caedddf16  vmovaps [rsp], xmm0
0000796caedddf1b  vmovaps [rsp+0x10], xmm1
0000796caedddf21  vmovaps [rsp+0x20], xmm2
0000796caedddf27  vmovaps [rsp+0x30], xmm3
0000796caedddf2d  vmovaps [rsp+0x40], xmm4
0000796caedddf33  vmovaps [rsp+0x50], xmm5
0000796caedddf39  vmovaps [rsp+0x60], xmm6
0000796caedddf3f  vmovaps [rsp+0x70], xmm8
0000796caedddf45  vmovaps [rsp+0x80], xmm9
0000796caedddf4e  vmovaps [rsp+0x90], xmm10
0000796caedddf57  vmovaps [rsp+0xA0], xmm11
0000796caedddf60  vmovaps [rsp+0xB0], xmm12
0000796caedddf69  vmovaps [rsp+0xC0], xmm13
0000796caedddf72  vmovaps [rsp+0xD0], xmm14
0000796caedddf7b  vmovaps [rsp+0xE0], xmm15
0000796caedddf84  sub rsp, 0x30
0000796caedddf88  movaps [rsp], xmm7
0000796caedddf8c  movaps [rsp+0x10], xmm5
0000796caedddf91  movaps [rsp+0x20], xmm15
0000796caedddf97  lea rdi, [rsp]
0000796caedddf9b  mov esi, 0x00
0000796caedddfa0  mov rax, 0x56877063A530
0000796caedddfaa  call rax
0000796caedddfac  movaps xmm7, [rsp]
0000796caedddfb0  add rsp, 0x30
0000796caedddfb4  vmovaps xmm0, [rsp]
0000796caedddfb9  vmovaps xmm1, [rsp+0x10]
0000796caedddfbf  vmovaps xmm2, [rsp+0x20]
0000796caedddfc5  vmovaps xmm3, [rsp+0x30]
0000796caedddfcb  vmovaps xmm4, [rsp+0x40]
0000796caedddfd1  vmovaps xmm5, [rsp+0x50]
0000796caedddfd7  vmovaps xmm6, [rsp+0x60]
0000796caedddfdd  vmovaps xmm8, [rsp+0x70]
0000796caedddfe3  vmovaps xmm9, [rsp+0x80]
0000796caedddfec  vmovaps xmm10, [rsp+0x90]
0000796caedddff5  vmovaps xmm11, [rsp+0xA0]
0000796caedddffe  vmovaps xmm12, [rsp+0xB0]
0000796caedde007  vmovaps xmm13, [rsp+0xC0]
0000796caedde010  vmovaps xmm14, [rsp+0xD0]
0000796caedde019  vmovaps xmm15, [rsp+0xE0]
0000796caedde022  add rsp, 0xF0
0000796caedde029  pop r11
0000796caedde02b  pop r10
0000796caedde02d  pop r9
0000796caedde02f  pop r8
0000796caedde031  pop rsi
0000796caedde032  pop rdi
0000796caedde033  pop rdx
0000796caedde034  pop rcx
0000796caedde035  pop rax
0000796caedde036  add rsp, 0x08
0000796caedde03a  jmp 0x0000796CAEDDC066
0000796caedde03f  call 0x0000796CAECB52F0
0000796caedde044  jmp 0x0000796CAEDDC073
0000796caedde049  sub rsp, 0x08
0000796caedde04d  push rax
0000796caedde04e  push rcx
0000796caedde04f  push rdx
0000796caedde050  push rdi
0000796caedde051  push rsi
0000796caedde052  push r8
0000796caedde054  push r9
0000796caedde056  push r10
0000796caedde058  push r11
0000796caedde05a  sub rsp, 0xF0
0000796caedde061  vmovaps [rsp], xmm0
0000796caedde066  vmovaps [rsp+0x10], xmm1
0000796caedde06c  vmovaps [rsp+0x20], xmm2
0000796caedde072  vmovaps [rsp+0x30], xmm3
0000796caedde078  vmovaps [rsp+0x40], xmm4
0000796caedde07e  vmovaps [rsp+0x50], xmm5
0000796caedde084  vmovaps [rsp+0x60], xmm6
0000796caedde08a  vmovaps [rsp+0x70], xmm7
0000796caedde090  vmovaps [rsp+0x80], xmm8
0000796caedde099  vmovaps [rsp+0x90], xmm9
0000796caedde0a2  vmovaps [rsp+0xA0], xmm10
0000796caedde0ab  vmovaps [rsp+0xB0], xmm11
0000796caedde0b4  vmovaps [rsp+0xC0], xmm12
0000796caedde0bd  vmovaps [rsp+0xD0], xmm13
0000796caedde0c6  vmovaps [rsp+0xE0], xmm14
0000796caedde0cf  sub rsp, 0x30
0000796caedde0d3  movaps [rsp], xmm15
0000796caedde0d8  movaps [rsp+0x10], xmm5
0000796caedde0dd  movaps [rsp+0x20], xmm3
0000796caedde0e2  lea rdi, [rsp]
0000796caedde0e6  mov esi, 0x00
0000796caedde0eb  mov rax, 0x56877063A530
0000796caedde0f5  call rax
0000796caedde0f7  movaps xmm15, [rsp]
0000796caedde0fc  add rsp, 0x30
0000796caedde100  vmovaps xmm0, [rsp]
0000796caedde105  vmovaps xmm1, [rsp+0x10]
0000796caedde10b  vmovaps xmm2, [rsp+0x20]
0000796caedde111  vmovaps xmm3, [rsp+0x30]
0000796caedde117  vmovaps xmm4, [rsp+0x40]
0000796caedde11d  vmovaps xmm5, [rsp+0x50]
0000796caedde123  vmovaps xmm6, [rsp+0x60]
0000796caedde129  vmovaps xmm7, [rsp+0x70]
0000796caedde12f  vmovaps xmm8, [rsp+0x80]
0000796caedde138  vmovaps xmm9, [rsp+0x90]
0000796caedde141  vmovaps xmm10, [rsp+0xA0]
0000796caedde14a  vmovaps xmm11, [rsp+0xB0]
0000796caedde153  vmovaps xmm12, [rsp+0xC0]
0000796caedde15c  vmovaps xmm13, [rsp+0xD0]
0000796caedde165  vmovaps xmm14, [rsp+0xE0]
0000796caedde16e  add rsp, 0xF0
0000796caedde175  pop r11
0000796caedde177  pop r10
0000796caedde179  pop r9
0000796caedde17b  pop r8
0000796caedde17d  pop rsi
0000796caedde17e  pop rdi
0000796caedde17f  pop rdx
0000796caedde180  pop rcx
0000796caedde181  pop rax
0000796caedde182  add rsp, 0x08
0000796caedde186  jmp 0x0000796CAEDDC099
0000796caedde18b  sub rsp, 0x08
0000796caedde18f  push rax
0000796caedde190  push rcx
0000796caedde191  push rdx
0000796caedde192  push rdi
0000796caedde193  push rsi
0000796caedde194  push r8
0000796caedde196  push r9
0000796caedde198  push r10
0000796caedde19a  push r11
0000796caedde19c  sub rsp, 0xF0
0000796caedde1a3  vmovaps [rsp], xmm0
0000796caedde1a8  vmovaps [rsp+0x10], xmm2
0000796caedde1ae  vmovaps [rsp+0x20], xmm3
0000796caedde1b4  vmovaps [rsp+0x30], xmm4
0000796caedde1ba  vmovaps [rsp+0x40], xmm5
0000796caedde1c0  vmovaps [rsp+0x50], xmm6
0000796caedde1c6  vmovaps [rsp+0x60], xmm7
0000796caedde1cc  vmovaps [rsp+0x70], xmm8
0000796caedde1d2  vmovaps [rsp+0x80], xmm9
0000796caedde1db  vmovaps [rsp+0x90], xmm10
0000796caedde1e4  vmovaps [rsp+0xA0], xmm11
0000796caedde1ed  vmovaps [rsp+0xB0], xmm12
0000796caedde1f6  vmovaps [rsp+0xC0], xmm13
0000796caedde1ff  vmovaps [rsp+0xD0], xmm14
0000796caedde208  vmovaps [rsp+0xE0], xmm15
0000796caedde211  sub rsp, 0x30
0000796caedde215  movaps [rsp], xmm1
0000796caedde219  movaps [rsp+0x10], xmm5
0000796caedde21e  movaps [rsp+0x20], xmm4
0000796caedde223  lea rdi, [rsp]
0000796caedde227  mov esi, 0x00
0000796caedde22c  mov rax, 0x56877063A530
0000796caedde236  call rax
0000796caedde238  movaps xmm1, [rsp]
0000796caedde23c  add rsp, 0x30
0000796caedde240  vmovaps xmm0, [rsp]
0000796caedde245  vmovaps xmm2, [rsp+0x10]
0000796caedde24b  vmovaps xmm3, [rsp+0x20]
0000796caedde251  vmovaps xmm4, [rsp+0x30]
0000796caedde257  vmovaps xmm5, [rsp+0x40]
0000796caedde25d  vmovaps xmm6, [rsp+0x50]
0000796caedde263  vmovaps xmm7, [rsp+0x60]
0000796caedde269  vmovaps xmm8, [rsp+0x70]
0000796caedde26f  vmovaps xmm9, [rsp+0x80]
0000796caedde278  vmovaps xmm10, [rsp+0x90]
0000796caedde281  vmovaps xmm11, [rsp+0xA0]
0000796caedde28a  vmovaps xmm12, [rsp+0xB0]
0000796caedde293  vmovaps xmm13, [rsp+0xC0]
0000796caedde29c  vmovaps xmm14, [rsp+0xD0]
0000796caedde2a5  vmovaps xmm15, [rsp+0xE0]
0000796caedde2ae  add rsp, 0xF0
0000796caedde2b5  pop r11
0000796caedde2b7  pop r10
0000796caedde2b9  pop r9
0000796caedde2bb  pop r8
0000796caedde2bd  pop rsi
0000796caedde2be  pop rdi
0000796caedde2bf  pop rdx
0000796caedde2c0  pop rcx
0000796caedde2c1  pop rax
0000796caedde2c2  add rsp, 0x08
0000796caedde2c6  jmp 0x0000796CAEDDC0B9
0000796caedde2cb  sub rsp, 0x08
0000796caedde2cf  push rax
0000796caedde2d0  push rcx
0000796caedde2d1  push rdx
0000796caedde2d2  push rdi
0000796caedde2d3  push rsi
0000796caedde2d4  push r8
0000796caedde2d6  push r9
0000796caedde2d8  push r10
0000796caedde2da  push r11
0000796caedde2dc  sub rsp, 0xF0
0000796caedde2e3  vmovaps [rsp], xmm0
0000796caedde2e8  vmovaps [rsp+0x10], xmm1
0000796caedde2ee  vmovaps [rsp+0x20], xmm2
0000796caedde2f4  vmovaps [rsp+0x30], xmm3
0000796caedde2fa  vmovaps [rsp+0x40], xmm5
0000796caedde300  vmovaps [rsp+0x50], xmm6
0000796caedde306  vmovaps [rsp+0x60], xmm7
0000796caedde30c  vmovaps [rsp+0x70], xmm8
0000796caedde312  vmovaps [rsp+0x80], xmm9
0000796caedde31b  vmovaps [rsp+0x90], xmm10
0000796caedde324  vmovaps [rsp+0xA0], xmm11
0000796caedde32d  vmovaps [rsp+0xB0], xmm12
0000796caedde336  vmovaps [rsp+0xC0], xmm13
0000796caedde33f  vmovaps [rsp+0xD0], xmm14
0000796caedde348  vmovaps [rsp+0xE0], xmm15
0000796caedde351  sub rsp, 0x30
0000796caedde355  movaps [rsp], xmm4
0000796caedde359  movaps [rsp+0x10], xmm3
0000796caedde35e  movaps [rsp+0x20], xmm5
0000796caedde363  lea rdi, [rsp]
0000796caedde367  mov esi, 0x00
0000796caedde36c  mov rax, 0x56877063A530
0000796caedde376  call rax
0000796caedde378  movaps xmm4, [rsp]
0000796caedde37c  add rsp, 0x30
0000796caedde380  vmovaps xmm0, [rsp]
0000796caedde385  vmovaps xmm1, [rsp+0x10]
0000796caedde38b  vmovaps xmm2, [rsp+0x20]
0000796caedde391  vmovaps xmm3, [rsp+0x30]
0000796caedde397  vmovaps xmm5, [rsp+0x40]
0000796caedde39d  vmovaps xmm6, [rsp+0x50]
0000796caedde3a3  vmovaps xmm7, [rsp+0x60]
0000796caedde3a9  vmovaps xmm8, [rsp+0x70]
0000796caedde3af  vmovaps xmm9, [rsp+0x80]
0000796caedde3b8  vmovaps xmm10, [rsp+0x90]
0000796caedde3c1  vmovaps xmm11, [rsp+0xA0]
0000796caedde3ca  vmovaps xmm12, [rsp+0xB0]
0000796caedde3d3  vmovaps xmm13, [rsp+0xC0]
0000796caedde3dc  vmovaps xmm14, [rsp+0xD0]
0000796caedde3e5  vmovaps xmm15, [rsp+0xE0]
0000796caedde3ee  add rsp, 0xF0
0000796caedde3f5  pop r11
0000796caedde3f7  pop r10
0000796caedde3f9  pop r9
0000796caedde3fb  pop r8
0000796caedde3fd  pop rsi
0000796caedde3fe  pop rdi
0000796caedde3ff  pop rdx
0000796caedde400  pop rcx
0000796caedde401  pop rax
0000796caedde402  add rsp, 0x08
0000796caedde406  jmp 0x0000796CAEDDC107
0000796caedde40b  call 0x0000796CAECB52F0
0000796caedde410  jmp 0x0000796CAEDDC114
0000796caedde415  sub rsp, 0x08
0000796caedde419  push rax
0000796caedde41a  push rcx
0000796caedde41b  push rdx
0000796caedde41c  push rdi
0000796caedde41d  push rsi
0000796caedde41e  push r8
0000796caedde420  push r9
0000796caedde422  push r10
0000796caedde424  push r11
0000796caedde426  sub rsp, 0xF0
0000796caedde42d  vmovaps [rsp], xmm0
0000796caedde432  vmovaps [rsp+0x10], xmm1
0000796caedde438  vmovaps [rsp+0x20], xmm2
0000796caedde43e  vmovaps [rsp+0x30], xmm3
0000796caedde444  vmovaps [rsp+0x40], xmm4
0000796caedde44a  vmovaps [rsp+0x50], xmm6
0000796caedde450  vmovaps [rsp+0x60], xmm7
0000796caedde456  vmovaps [rsp+0x70], xmm8
0000796caedde45c  vmovaps [rsp+0x80], xmm9
0000796caedde465  vmovaps [rsp+0x90], xmm10
0000796caedde46e  vmovaps [rsp+0xA0], xmm11
0000796caedde477  vmovaps [rsp+0xB0], xmm12
0000796caedde480  vmovaps [rsp+0xC0], xmm13
0000796caedde489  vmovaps [rsp+0xD0], xmm14
0000796caedde492  vmovaps [rsp+0xE0], xmm15
0000796caedde49b  sub rsp, 0x30
0000796caedde49f  movaps [rsp], xmm5
0000796caedde4a3  movaps [rsp+0x10], xmm6
0000796caedde4a8  movaps [rsp+0x20], xmm3
0000796caedde4ad  lea rdi, [rsp]
0000796caedde4b1  mov esi, 0x00
0000796caedde4b6  mov rax, 0x56877063A530
0000796caedde4c0  call rax
0000796caedde4c2  movaps xmm5, [rsp]
0000796caedde4c6  add rsp, 0x30
0000796caedde4ca  vmovaps xmm0, [rsp]
0000796caedde4cf  vmovaps xmm1, [rsp+0x10]
0000796caedde4d5  vmovaps xmm2, [rsp+0x20]
0000796caedde4db  vmovaps xmm3, [rsp+0x30]
0000796caedde4e1  vmovaps xmm4, [rsp+0x40]
0000796caedde4e7  vmovaps xmm6, [rsp+0x50]
0000796caedde4ed  vmovaps xmm7, [rsp+0x60]
0000796caedde4f3  vmovaps xmm8, [rsp+0x70]
0000796caedde4f9  vmovaps xmm9, [rsp+0x80]
0000796caedde502  vmovaps xmm10, [rsp+0x90]
0000796caedde50b  vmovaps xmm11, [rsp+0xA0]
0000796caedde514  vmovaps xmm12, [rsp+0xB0]
0000796caedde51d  vmovaps xmm13, [rsp+0xC0]
0000796caedde526  vmovaps xmm14, [rsp+0xD0]
0000796caedde52f  vmovaps xmm15, [rsp+0xE0]
0000796caedde538  add rsp, 0xF0
0000796caedde53f  pop r11
0000796caedde541  pop r10
0000796caedde543  pop r9
0000796caedde545  pop r8
0000796caedde547  pop rsi
0000796caedde548  pop rdi
0000796caedde549  pop rdx
0000796caedde54a  pop rcx
0000796caedde54b  pop rax
0000796caedde54c  add rsp, 0x08
0000796caedde550  jmp 0x0000796CAEDDC13A
0000796caedde555  sub rsp, 0x08
0000796caedde559  push rax
0000796caedde55a  push rcx
0000796caedde55b  push rdx
0000796caedde55c  push rdi
0000796caedde55d  push rsi
0000796caedde55e  push r8
0000796caedde560  push r9
0000796caedde562  push r10
0000796caedde564  push r11
0000796caedde566  sub rsp, 0xF0
0000796caedde56d  vmovaps [rsp], xmm0
0000796caedde572  vmovaps [rsp+0x10], xmm1
0000796caedde578  vmovaps [rsp+0x20], xmm2
0000796caedde57e  vmovaps [rsp+0x30], xmm3
0000796caedde584  vmovaps [rsp+0x40], xmm4
0000796caedde58a  vmovaps [rsp+0x50], xmm5
0000796caedde590  vmovaps [rsp+0x60], xmm7
0000796caedde596  vmovaps [rsp+0x70], xmm8
0000796caedde59c  vmovaps [rsp+0x80], xmm9
0000796caedde5a5  vmovaps [rsp+0x90], xmm10
0000796caedde5ae  vmovaps [rsp+0xA0], xmm11
0000796caedde5b7  vmovaps [rsp+0xB0], xmm12
0000796caedde5c0  vmovaps [rsp+0xC0], xmm13
0000796caedde5c9  vmovaps [rsp+0xD0], xmm14
0000796caedde5d2  vmovaps [rsp+0xE0], xmm15
0000796caedde5db  sub rsp, 0x30
0000796caedde5df  movaps [rsp], xmm6
0000796caedde5e3  movaps [rsp+0x10], xmm9
0000796caedde5e9  movaps [rsp+0x20], xmm1
0000796caedde5ee  lea rdi, [rsp]
0000796caedde5f2  mov esi, 0x00
0000796caedde5f7  mov rax, 0x56877063A530
0000796caedde601  call rax
0000796caedde603  movaps xmm6, [rsp]
0000796caedde607  add rsp, 0x30
0000796caedde60b  vmovaps xmm0, [rsp]
0000796caedde610  vmovaps xmm1, [rsp+0x10]
0000796caedde616  vmovaps xmm2, [rsp+0x20]
0000796caedde61c  vmovaps xmm3, [rsp+0x30]
0000796caedde622  vmovaps xmm4, [rsp+0x40]
0000796caedde628  vmovaps xmm5, [rsp+0x50]
0000796caedde62e  vmovaps xmm7, [rsp+0x60]
0000796caedde634  vmovaps xmm8, [rsp+0x70]
0000796caedde63a  vmovaps xmm9, [rsp+0x80]
0000796caedde643  vmovaps xmm10, [rsp+0x90]
0000796caedde64c  vmovaps xmm11, [rsp+0xA0]
0000796caedde655  vmovaps xmm12, [rsp+0xB0]
0000796caedde65e  vmovaps xmm13, [rsp+0xC0]
0000796caedde667  vmovaps xmm14, [rsp+0xD0]
0000796caedde670  vmovaps xmm15, [rsp+0xE0]
0000796caedde679  add rsp, 0xF0
0000796caedde680  pop r11
0000796caedde682  pop r10
0000796caedde684  pop r9
0000796caedde686  pop r8
0000796caedde688  pop rsi
0000796caedde689  pop rdi
0000796caedde68a  pop rdx
0000796caedde68b  pop rcx
0000796caedde68c  pop rax
0000796caedde68d  add rsp, 0x08
0000796caedde691  jmp 0x0000796CAEDDC15E
0000796caedde696  sub rsp, 0x08
0000796caedde69a  push rax
0000796caedde69b  push rcx
0000796caedde69c  push rdx
0000796caedde69d  push rdi
0000796caedde69e  push rsi
0000796caedde69f  push r8
0000796caedde6a1  push r9
0000796caedde6a3  push r10
0000796caedde6a5  push r11
0000796caedde6a7  sub rsp, 0xF0
0000796caedde6ae  vmovaps [rsp], xmm0
0000796caedde6b3  vmovaps [rsp+0x10], xmm1
0000796caedde6b9  vmovaps [rsp+0x20], xmm2
0000796caedde6bf  vmovaps [rsp+0x30], xmm3
0000796caedde6c5  vmovaps [rsp+0x40], xmm4
0000796caedde6cb  vmovaps [rsp+0x50], xmm5
0000796caedde6d1  vmovaps [rsp+0x60], xmm6
0000796caedde6d7  vmovaps [rsp+0x70], xmm7
0000796caedde6dd  vmovaps [rsp+0x80], xmm8
0000796caedde6e6  vmovaps [rsp+0x90], xmm10
0000796caedde6ef  vmovaps [rsp+0xA0], xmm11
0000796caedde6f8  vmovaps [rsp+0xB0], xmm12
0000796caedde701  vmovaps [rsp+0xC0], xmm13
0000796caedde70a  vmovaps [rsp+0xD0], xmm14
0000796caedde713  vmovaps [rsp+0xE0], xmm15
0000796caedde71c  sub rsp, 0x30
0000796caedde720  movaps [rsp], xmm9
0000796caedde725  movaps [rsp+0x10], xmm3
0000796caedde72a  movaps [rsp+0x20], xmm1
0000796caedde72f  lea rdi, [rsp]
0000796caedde733  mov esi, 0x00
0000796caedde738  mov rax, 0x56877063A530
0000796caedde742  call rax
0000796caedde744  movaps xmm9, [rsp]
0000796caedde749  add rsp, 0x30
0000796caedde74d  vmovaps xmm0, [rsp]
0000796caedde752  vmovaps xmm1, [rsp+0x10]
0000796caedde758  vmovaps xmm2, [rsp+0x20]
0000796caedde75e  vmovaps xmm3, [rsp+0x30]
0000796caedde764  vmovaps xmm4, [rsp+0x40]
0000796caedde76a  vmovaps xmm5, [rsp+0x50]
0000796caedde770  vmovaps xmm6, [rsp+0x60]
0000796caedde776  vmovaps xmm7, [rsp+0x70]
0000796caedde77c  vmovaps xmm8, [rsp+0x80]
0000796caedde785  vmovaps xmm10, [rsp+0x90]
0000796caedde78e  vmovaps xmm11, [rsp+0xA0]
0000796caedde797  vmovaps xmm12, [rsp+0xB0]
0000796caedde7a0  vmovaps xmm13, [rsp+0xC0]
0000796caedde7a9  vmovaps xmm14, [rsp+0xD0]
0000796caedde7b2  vmovaps xmm15, [rsp+0xE0]
0000796caedde7bb  add rsp, 0xF0
0000796caedde7c2  pop r11
0000796caedde7c4  pop r10
0000796caedde7c6  pop r9
0000796caedde7c8  pop r8
0000796caedde7ca  pop rsi
0000796caedde7cb  pop rdi
0000796caedde7cc  pop rdx
0000796caedde7cd  pop rcx
0000796caedde7ce  pop rax
0000796caedde7cf  add rsp, 0x08
0000796caedde7d3  jmp 0x0000796CAEDDC1AA
0000796caedde7d8  call 0x0000796CAECB52F0
0000796caedde7dd  jmp 0x0000796CAEDDC1B7
0000796caedde7e2  sub rsp, 0x08
0000796caedde7e6  push rax
0000796caedde7e7  push rcx
0000796caedde7e8  push rdx
0000796caedde7e9  push rdi
0000796caedde7ea  push rsi
0000796caedde7eb  push r8
0000796caedde7ed  push r9
0000796caedde7ef  push r10
0000796caedde7f1  push r11
0000796caedde7f3  sub rsp, 0xF0
0000796caedde7fa  vmovaps [rsp], xmm0
0000796caedde7ff  vmovaps [rsp+0x10], xmm1
0000796caedde805  vmovaps [rsp+0x20], xmm2
0000796caedde80b  vmovaps [rsp+0x30], xmm3
0000796caedde811  vmovaps [rsp+0x40], xmm4
0000796caedde817  vmovaps [rsp+0x50], xmm5
0000796caedde81d  vmovaps [rsp+0x60], xmm6
0000796caedde823  vmovaps [rsp+0x70], xmm7
0000796caedde829  vmovaps [rsp+0x80], xmm8
0000796caedde832  vmovaps [rsp+0x90], xmm9
0000796caedde83b  vmovaps [rsp+0xA0], xmm10
0000796caedde844  vmovaps [rsp+0xB0], xmm11
0000796caedde84d  vmovaps [rsp+0xC0], xmm12
0000796caedde856  vmovaps [rsp+0xD0], xmm13
0000796caedde85f  vmovaps [rsp+0xE0], xmm14
0000796caedde868  sub rsp, 0x30
0000796caedde86c  movaps [rsp], xmm15
0000796caedde871  movaps [rsp+0x10], xmm3
0000796caedde876  movaps [rsp+0x20], xmm7
0000796caedde87b  lea rdi, [rsp]
0000796caedde87f  mov esi, 0x00
0000796caedde884  mov rax, 0x56877063A530
0000796caedde88e  call rax
0000796caedde890  movaps xmm15, [rsp]
0000796caedde895  add rsp, 0x30
0000796caedde899  vmovaps xmm0, [rsp]
0000796caedde89e  vmovaps xmm1, [rsp+0x10]
0000796caedde8a4  vmovaps xmm2, [rsp+0x20]
0000796caedde8aa  vmovaps xmm3, [rsp+0x30]
0000796caedde8b0  vmovaps xmm4, [rsp+0x40]
0000796caedde8b6  vmovaps xmm5, [rsp+0x50]
0000796caedde8bc  vmovaps xmm6, [rsp+0x60]
0000796caedde8c2  vmovaps xmm7, [rsp+0x70]
0000796caedde8c8  vmovaps xmm8, [rsp+0x80]
0000796caedde8d1  vmovaps xmm9, [rsp+0x90]
0000796caedde8da  vmovaps xmm10, [rsp+0xA0]
0000796caedde8e3  vmovaps xmm11, [rsp+0xB0]
0000796caedde8ec  vmovaps xmm12, [rsp+0xC0]
0000796caedde8f5  vmovaps xmm13, [rsp+0xD0]
0000796caedde8fe  vmovaps xmm14, [rsp+0xE0]
0000796caedde907  add rsp, 0xF0
0000796caedde90e  pop r11
0000796caedde910  pop r10
0000796caedde912  pop r9
0000796caedde914  pop r8
0000796caedde916  pop rsi
0000796caedde917  pop rdi
0000796caedde918  pop rdx
0000796caedde919  pop rcx
0000796caedde91a  pop rax
0000796caedde91b  add rsp, 0x08
0000796caedde91f  jmp 0x0000796CAEDDC1E3
0000796caedde924  sub rsp, 0x08
0000796caedde928  push rax
0000796caedde929  push rcx
0000796caedde92a  push rdx
0000796caedde92b  push rdi
0000796caedde92c  push rsi
0000796caedde92d  push r8
0000796caedde92f  push r9
0000796caedde931  push r10
0000796caedde933  push r11
0000796caedde935  sub rsp, 0xF0
0000796caedde93c  vmovaps [rsp], xmm0
0000796caedde941  vmovaps [rsp+0x10], xmm1
0000796caedde947  vmovaps [rsp+0x20], xmm2
0000796caedde94d  vmovaps [rsp+0x30], xmm4
0000796caedde953  vmovaps [rsp+0x40], xmm5
0000796caedde959  vmovaps [rsp+0x50], xmm6
0000796caedde95f  vmovaps [rsp+0x60], xmm7
0000796caedde965  vmovaps [rsp+0x70], xmm8
0000796caedde96b  vmovaps [rsp+0x80], xmm9
0000796caedde974  vmovaps [rsp+0x90], xmm10
0000796caedde97d  vmovaps [rsp+0xA0], xmm11
0000796caedde986  vmovaps [rsp+0xB0], xmm12
0000796caedde98f  vmovaps [rsp+0xC0], xmm13
0000796caedde998  vmovaps [rsp+0xD0], xmm14
0000796caedde9a1  vmovaps [rsp+0xE0], xmm15
0000796caedde9aa  sub rsp, 0x30
0000796caedde9ae  movaps [rsp], xmm3
0000796caedde9b2  movaps [rsp+0x10], xmm1
0000796caedde9b7  movaps [rsp+0x20], xmm15
0000796caedde9bd  lea rdi, [rsp]
0000796caedde9c1  mov esi, 0x00
0000796caedde9c6  mov rax, 0x56877063A530
0000796caedde9d0  call rax
0000796caedde9d2  movaps xmm3, [rsp]
0000796caedde9d6  add rsp, 0x30
0000796caedde9da  vmovaps xmm0, [rsp]
0000796caedde9df  vmovaps xmm1, [rsp+0x10]
0000796caedde9e5  vmovaps xmm2, [rsp+0x20]
0000796caedde9eb  vmovaps xmm4, [rsp+0x30]
0000796caedde9f1  vmovaps xmm5, [rsp+0x40]
0000796caedde9f7  vmovaps xmm6, [rsp+0x50]
0000796caedde9fd  vmovaps xmm7, [rsp+0x60]
0000796caeddea03  vmovaps xmm8, [rsp+0x70]
0000796caeddea09  vmovaps xmm9, [rsp+0x80]
0000796caeddea12  vmovaps xmm10, [rsp+0x90]
0000796caeddea1b  vmovaps xmm11, [rsp+0xA0]
0000796caeddea24  vmovaps xmm12, [rsp+0xB0]
0000796caeddea2d  vmovaps xmm13, [rsp+0xC0]
0000796caeddea36  vmovaps xmm14, [rsp+0xD0]
0000796caeddea3f  vmovaps xmm15, [rsp+0xE0]
0000796caeddea48  add rsp, 0xF0
0000796caeddea4f  pop r11
0000796caeddea51  pop r10
0000796caeddea53  pop r9
0000796caeddea55  pop r8
0000796caeddea57  pop rsi
0000796caeddea58  pop rdi
0000796caeddea59  pop rdx
0000796caeddea5a  pop rcx
0000796caeddea5b  pop rax
0000796caeddea5c  add rsp, 0x08
0000796caeddea60  jmp 0x0000796CAEDDC272
0000796caeddea65  call 0x0000796CAECB52F0
0000796caeddea6a  jmp 0x0000796CAEDDC27C
0000796caeddea6f  sub rsp, 0x08
0000796caeddea73  push rax
0000796caeddea74  push rcx
0000796caeddea75  push rdx
0000796caeddea76  push rdi
0000796caeddea77  push rsi
0000796caeddea78  push r8
0000796caeddea7a  push r9
0000796caeddea7c  push r10
0000796caeddea7e  push r11
0000796caeddea80  sub rsp, 0xF0
0000796caeddea87  vmovaps [rsp], xmm0
0000796caeddea8c  vmovaps [rsp+0x10], xmm1
0000796caeddea92  vmovaps [rsp+0x20], xmm2
0000796caeddea98  vmovaps [rsp+0x30], xmm3
0000796caeddea9e  vmovaps [rsp+0x40], xmm4
0000796caeddeaa4  vmovaps [rsp+0x50], xmm5
0000796caeddeaaa  vmovaps [rsp+0x60], xmm6
0000796caeddeab0  vmovaps [rsp+0x70], xmm7
0000796caeddeab6  vmovaps [rsp+0x80], xmm8
0000796caeddeabf  vmovaps [rsp+0x90], xmm9
0000796caeddeac8  vmovaps [rsp+0xA0], xmm10
0000796caeddead1  vmovaps [rsp+0xB0], xmm11
0000796caeddeada  vmovaps [rsp+0xC0], xmm12
0000796caeddeae3  vmovaps [rsp+0xD0], xmm13
0000796caeddeaec  vmovaps [rsp+0xE0], xmm14
0000796caeddeaf5  sub rsp, 0x30
0000796caeddeaf9  movaps [rsp], xmm15
0000796caeddeafe  movaps [rsp+0x10], xmm14
0000796caeddeb04  movaps [rsp+0x20], xmm4
0000796caeddeb09  lea rdi, [rsp]
0000796caeddeb0d  mov esi, 0x00
0000796caeddeb12  mov rax, 0x56877063A530
0000796caeddeb1c  call rax
0000796caeddeb1e  movaps xmm15, [rsp]
0000796caeddeb23  add rsp, 0x30
0000796caeddeb27  vmovaps xmm0, [rsp]
0000796caeddeb2c  vmovaps xmm1, [rsp+0x10]
0000796caeddeb32  vmovaps xmm2, [rsp+0x20]
0000796caeddeb38  vmovaps xmm3, [rsp+0x30]
0000796caeddeb3e  vmovaps xmm4, [rsp+0x40]
0000796caeddeb44  vmovaps xmm5, [rsp+0x50]
0000796caeddeb4a  vmovaps xmm6, [rsp+0x60]
0000796caeddeb50  vmovaps xmm7, [rsp+0x70]
0000796caeddeb56  vmovaps xmm8, [rsp+0x80]
0000796caeddeb5f  vmovaps xmm9, [rsp+0x90]
0000796caeddeb68  vmovaps xmm10, [rsp+0xA0]
0000796caeddeb71  vmovaps xmm11, [rsp+0xB0]
0000796caeddeb7a  vmovaps xmm12, [rsp+0xC0]
0000796caeddeb83  vmovaps xmm13, [rsp+0xD0]
0000796caeddeb8c  vmovaps xmm14, [rsp+0xE0]
0000796caeddeb95  add rsp, 0xF0
0000796caeddeb9c  pop r11
0000796caeddeb9e  pop r10
0000796caeddeba0  pop r9
0000796caeddeba2  pop r8
0000796caeddeba4  pop rsi
0000796caeddeba5  pop rdi
0000796caeddeba6  pop rdx
0000796caeddeba7  pop rcx
0000796caeddeba8  pop rax
0000796caeddeba9  add rsp, 0x08
0000796caeddebad  jmp 0x0000796CAEDDC2AA
0000796caeddebb2  sub rsp, 0x08
0000796caeddebb6  push rax
0000796caeddebb7  push rcx
0000796caeddebb8  push rdx
0000796caeddebb9  push rdi
0000796caeddebba  push rsi
0000796caeddebbb  push r8
0000796caeddebbd  push r9
0000796caeddebbf  push r10
0000796caeddebc1  push r11
0000796caeddebc3  sub rsp, 0xF0
0000796caeddebca  vmovaps [rsp], xmm0
0000796caeddebcf  vmovaps [rsp+0x10], xmm1
0000796caeddebd5  vmovaps [rsp+0x20], xmm2
0000796caeddebdb  vmovaps [rsp+0x30], xmm3
0000796caeddebe1  vmovaps [rsp+0x40], xmm4
0000796caeddebe7  vmovaps [rsp+0x50], xmm5
0000796caeddebed  vmovaps [rsp+0x60], xmm6
0000796caeddebf3  vmovaps [rsp+0x70], xmm7
0000796caeddebf9  vmovaps [rsp+0x80], xmm8
0000796caeddec02  vmovaps [rsp+0x90], xmm9
0000796caeddec0b  vmovaps [rsp+0xA0], xmm10
0000796caeddec14  vmovaps [rsp+0xB0], xmm11
0000796caeddec1d  vmovaps [rsp+0xC0], xmm12
0000796caeddec26  vmovaps [rsp+0xD0], xmm13
0000796caeddec2f  vmovaps [rsp+0xE0], xmm15
0000796caeddec38  sub rsp, 0x30
0000796caeddec3c  movaps [rsp], xmm14
0000796caeddec41  movaps [rsp+0x10], xmm2
0000796caeddec46  movaps [rsp+0x20], xmm1
0000796caeddec4b  lea rdi, [rsp]
0000796caeddec4f  mov esi, 0x00
0000796caeddec54  mov rax, 0x56877063A530
0000796caeddec5e  call rax
0000796caeddec60  movaps xmm14, [rsp]
0000796caeddec65  add rsp, 0x30
0000796caeddec69  vmovaps xmm0, [rsp]
0000796caeddec6e  vmovaps xmm1, [rsp+0x10]
0000796caeddec74  vmovaps xmm2, [rsp+0x20]
0000796caeddec7a  vmovaps xmm3, [rsp+0x30]
0000796caeddec80  vmovaps xmm4, [rsp+0x40]
0000796caeddec86  vmovaps xmm5, [rsp+0x50]
0000796caeddec8c  vmovaps xmm6, [rsp+0x60]
0000796caeddec92  vmovaps xmm7, [rsp+0x70]
0000796caeddec98  vmovaps xmm8, [rsp+0x80]
0000796caeddeca1  vmovaps xmm9, [rsp+0x90]
0000796caeddecaa  vmovaps xmm10, [rsp+0xA0]
0000796caeddecb3  vmovaps xmm11, [rsp+0xB0]
0000796caeddecbc  vmovaps xmm12, [rsp+0xC0]
0000796caeddecc5  vmovaps xmm13, [rsp+0xD0]
0000796caeddecce  vmovaps xmm15, [rsp+0xE0]
0000796caeddecd7  add rsp, 0xF0
0000796caeddecde  pop r11
0000796caeddece0  pop r10
0000796caeddece2  pop r9
0000796caeddece4  pop r8
0000796caeddece6  pop rsi
0000796caeddece7  pop rdi
0000796caeddece8  pop rdx
0000796caeddece9  pop rcx
0000796caeddecea  pop rax
0000796caeddeceb  add rsp, 0x08
0000796caeddecef  jmp 0x0000796CAEDDC2D0
0000796caeddecf4  sub rsp, 0x08
0000796caeddecf8  push rax
0000796caeddecf9  push rcx
0000796caeddecfa  push rdx
0000796caeddecfb  push rdi
0000796caeddecfc  push rsi
0000796caeddecfd  push r8
0000796caeddecff  push r9
0000796caedded01  push r10
0000796caedded03  push r11
0000796caedded05  sub rsp, 0xF0
0000796caedded0c  vmovaps [rsp], xmm0
0000796caedded11  vmovaps [rsp+0x10], xmm2
0000796caedded17  vmovaps [rsp+0x20], xmm3
0000796caedded1d  vmovaps [rsp+0x30], xmm4
0000796caedded23  vmovaps [rsp+0x40], xmm5
0000796caedded29  vmovaps [rsp+0x50], xmm6
0000796caedded2f  vmovaps [rsp+0x60], xmm7
0000796caedded35  vmovaps [rsp+0x70], xmm8
0000796caedded3b  vmovaps [rsp+0x80], xmm9
0000796caedded44  vmovaps [rsp+0x90], xmm10
0000796caedded4d  vmovaps [rsp+0xA0], xmm11
0000796caedded56  vmovaps [rsp+0xB0], xmm12
0000796caedded5f  vmovaps [rsp+0xC0], xmm13
0000796caedded68  vmovaps [rsp+0xD0], xmm14
0000796caedded71  vmovaps [rsp+0xE0], xmm15
0000796caedded7a  sub rsp, 0x30
0000796caedded7e  movaps [rsp], xmm1
0000796caedded82  movaps [rsp+0x10], xmm4
0000796caedded87  movaps [rsp+0x20], xmm9
0000796caedded8d  lea rdi, [rsp]
0000796caedded91  mov esi, 0x00
0000796caedded96  mov rax, 0x56877063A530
0000796caeddeda0  call rax
0000796caeddeda2  movaps xmm1, [rsp]
0000796caeddeda6  add rsp, 0x30
0000796caeddedaa  vmovaps xmm0, [rsp]
0000796caeddedaf  vmovaps xmm2, [rsp+0x10]
0000796caeddedb5  vmovaps xmm3, [rsp+0x20]
0000796caeddedbb  vmovaps xmm4, [rsp+0x30]
0000796caeddedc1  vmovaps xmm5, [rsp+0x40]
0000796caeddedc7  vmovaps xmm6, [rsp+0x50]
0000796caeddedcd  vmovaps xmm7, [rsp+0x60]
0000796caeddedd3  vmovaps xmm8, [rsp+0x70]
0000796caeddedd9  vmovaps xmm9, [rsp+0x80]
0000796caeddede2  vmovaps xmm10, [rsp+0x90]
0000796caeddedeb  vmovaps xmm11, [rsp+0xA0]
0000796caeddedf4  vmovaps xmm12, [rsp+0xB0]
0000796caeddedfd  vmovaps xmm13, [rsp+0xC0]
0000796caeddee06  vmovaps xmm14, [rsp+0xD0]
0000796caeddee0f  vmovaps xmm15, [rsp+0xE0]
0000796caeddee18  add rsp, 0xF0
0000796caeddee1f  pop r11
0000796caeddee21  pop r10
0000796caeddee23  pop r9
0000796caeddee25  pop r8
0000796caeddee27  pop rsi
0000796caeddee28  pop rdi
0000796caeddee29  pop rdx
0000796caeddee2a  pop rcx
0000796caeddee2b  pop rax
0000796caeddee2c  add rsp, 0x08
0000796caeddee30  jmp 0x0000796CAEDDC2EE
0000796caeddee35  sub rsp, 0x08
0000796caeddee39  push rax
0000796caeddee3a  push rcx
0000796caeddee3b  push rdx
0000796caeddee3c  push rdi
0000796caeddee3d  push rsi
0000796caeddee3e  push r8
0000796caeddee40  push r9
0000796caeddee42  push r10
0000796caeddee44  push r11
0000796caeddee46  sub rsp, 0xF0
0000796caeddee4d  vmovaps [rsp], xmm0
0000796caeddee52  vmovaps [rsp+0x10], xmm1
0000796caeddee58  vmovaps [rsp+0x20], xmm2
0000796caeddee5e  vmovaps [rsp+0x30], xmm3
0000796caeddee64  vmovaps [rsp+0x40], xmm5
0000796caeddee6a  vmovaps [rsp+0x50], xmm6
0000796caeddee70  vmovaps [rsp+0x60], xmm7
0000796caeddee76  vmovaps [rsp+0x70], xmm8
0000796caeddee7c  vmovaps [rsp+0x80], xmm9
0000796caeddee85  vmovaps [rsp+0x90], xmm10
0000796caeddee8e  vmovaps [rsp+0xA0], xmm11
0000796caeddee97  vmovaps [rsp+0xB0], xmm12
0000796caeddeea0  vmovaps [rsp+0xC0], xmm13
0000796caeddeea9  vmovaps [rsp+0xD0], xmm14
0000796caeddeeb2  vmovaps [rsp+0xE0], xmm15
0000796caeddeebb  sub rsp, 0x30
0000796caeddeebf  movaps [rsp], xmm4
0000796caeddeec3  movaps [rsp+0x10], xmm2
0000796caeddeec8  movaps [rsp+0x20], xmm9
0000796caeddeece  lea rdi, [rsp]
0000796caeddeed2  mov esi, 0x00
0000796caeddeed7  mov rax, 0x56877063A530
0000796caeddeee1  call rax
0000796caeddeee3  movaps xmm4, [rsp]
0000796caeddeee7  add rsp, 0x30
0000796caeddeeeb  vmovaps xmm0, [rsp]
0000796caeddeef0  vmovaps xmm1, [rsp+0x10]
0000796caeddeef6  vmovaps xmm2, [rsp+0x20]
0000796caeddeefc  vmovaps xmm3, [rsp+0x30]
0000796caeddef02  vmovaps xmm5, [rsp+0x40]
0000796caeddef08  vmovaps xmm6, [rsp+0x50]
0000796caeddef0e  vmovaps xmm7, [rsp+0x60]
0000796caeddef14  vmovaps xmm8, [rsp+0x70]
0000796caeddef1a  vmovaps xmm9, [rsp+0x80]
0000796caeddef23  vmovaps xmm10, [rsp+0x90]
0000796caeddef2c  vmovaps xmm11, [rsp+0xA0]
0000796caeddef35  vmovaps xmm12, [rsp+0xB0]
0000796caeddef3e  vmovaps xmm13, [rsp+0xC0]
0000796caeddef47  vmovaps xmm14, [rsp+0xD0]
0000796caeddef50  vmovaps xmm15, [rsp+0xE0]
0000796caeddef59  add rsp, 0xF0
0000796caeddef60  pop r11
0000796caeddef62  pop r10
0000796caeddef64  pop r9
0000796caeddef66  pop r8
0000796caeddef68  pop rsi
0000796caeddef69  pop rdi
0000796caeddef6a  pop rdx
0000796caeddef6b  pop rcx
0000796caeddef6c  pop rax
0000796caeddef6d  add rsp, 0x08
0000796caeddef71  jmp 0x0000796CAEDDC31E
0000796caeddef76  sub rsp, 0x08
0000796caeddef7a  push rax
0000796caeddef7b  push rcx
0000796caeddef7c  push rdx
0000796caeddef7d  push rdi
0000796caeddef7e  push rsi
0000796caeddef7f  push r8
0000796caeddef81  push r9
0000796caeddef83  push r10
0000796caeddef85  push r11
0000796caeddef87  sub rsp, 0xF0
0000796caeddef8e  vmovaps [rsp], xmm0
0000796caeddef93  vmovaps [rsp+0x10], xmm1
0000796caeddef99  vmovaps [rsp+0x20], xmm2
0000796caeddef9f  vmovaps [rsp+0x30], xmm3
0000796caeddefa5  vmovaps [rsp+0x40], xmm4
0000796caeddefab  vmovaps [rsp+0x50], xmm5
0000796caeddefb1  vmovaps [rsp+0x60], xmm6
0000796caeddefb7  vmovaps [rsp+0x70], xmm7
0000796caeddefbd  vmovaps [rsp+0x80], xmm8
0000796caeddefc6  vmovaps [rsp+0x90], xmm10
0000796caeddefcf  vmovaps [rsp+0xA0], xmm11
0000796caeddefd8  vmovaps [rsp+0xB0], xmm12
0000796caeddefe1  vmovaps [rsp+0xC0], xmm13
0000796caeddefea  vmovaps [rsp+0xD0], xmm14
0000796caeddeff3  vmovaps [rsp+0xE0], xmm15
0000796caeddeffc  sub rsp, 0x30
0000796caeddf000  movaps [rsp], xmm9
0000796caeddf005  movaps [rsp+0x10], xmm2
0000796caeddf00a  movaps [rsp+0x20], xmm1
0000796caeddf00f  lea rdi, [rsp]
0000796caeddf013  mov esi, 0x00
0000796caeddf018  mov rax, 0x56877063A530
0000796caeddf022  call rax
0000796caeddf024  movaps xmm9, [rsp]
0000796caeddf029  add rsp, 0x30
0000796caeddf02d  vmovaps xmm0, [rsp]
0000796caeddf032  vmovaps xmm1, [rsp+0x10]
0000796caeddf038  vmovaps xmm2, [rsp+0x20]
0000796caeddf03e  vmovaps xmm3, [rsp+0x30]
0000796caeddf044  vmovaps xmm4, [rsp+0x40]
0000796caeddf04a  vmovaps xmm5, [rsp+0x50]
0000796caeddf050  vmovaps xmm6, [rsp+0x60]
0000796caeddf056  vmovaps xmm7, [rsp+0x70]
0000796caeddf05c  vmovaps xmm8, [rsp+0x80]
0000796caeddf065  vmovaps xmm10, [rsp+0x90]
0000796caeddf06e  vmovaps xmm11, [rsp+0xA0]
0000796caeddf077  vmovaps xmm12, [rsp+0xB0]
0000796caeddf080  vmovaps xmm13, [rsp+0xC0]
0000796caeddf089  vmovaps xmm14, [rsp+0xD0]
0000796caeddf092  vmovaps xmm15, [rsp+0xE0]
0000796caeddf09b  add rsp, 0xF0
0000796caeddf0a2  pop r11
0000796caeddf0a4  pop r10
0000796caeddf0a6  pop r9
0000796caeddf0a8  pop r8
0000796caeddf0aa  pop rsi
0000796caeddf0ab  pop rdi
0000796caeddf0ac  pop rdx
0000796caeddf0ad  pop rcx
0000796caeddf0ae  pop rax
0000796caeddf0af  add rsp, 0x08
0000796caeddf0b3  jmp 0x0000796CAEDDC354
0000796caeddf0b8  sub rsp, 0x08
0000796caeddf0bc  push rax
0000796caeddf0bd  push rcx
0000796caeddf0be  push rdx
0000796caeddf0bf  push rdi
0000796caeddf0c0  push rsi
0000796caeddf0c1  push r8
0000796caeddf0c3  push r9
0000796caeddf0c5  push r10
0000796caeddf0c7  push r11
0000796caeddf0c9  sub rsp, 0xF0
0000796caeddf0d0  vmovaps [rsp], xmm0
0000796caeddf0d5  vmovaps [rsp+0x10], xmm2
0000796caeddf0db  vmovaps [rsp+0x20], xmm3
0000796caeddf0e1  vmovaps [rsp+0x30], xmm4
0000796caeddf0e7  vmovaps [rsp+0x40], xmm5
0000796caeddf0ed  vmovaps [rsp+0x50], xmm6
0000796caeddf0f3  vmovaps [rsp+0x60], xmm7
0000796caeddf0f9  vmovaps [rsp+0x70], xmm8
0000796caeddf0ff  vmovaps [rsp+0x80], xmm9
0000796caeddf108  vmovaps [rsp+0x90], xmm10
0000796caeddf111  vmovaps [rsp+0xA0], xmm11
0000796caeddf11a  vmovaps [rsp+0xB0], xmm12
0000796caeddf123  vmovaps [rsp+0xC0], xmm13
0000796caeddf12c  vmovaps [rsp+0xD0], xmm14
0000796caeddf135  vmovaps [rsp+0xE0], xmm15
0000796caeddf13e  sub rsp, 0x30
0000796caeddf142  movaps [rsp], xmm1
0000796caeddf146  movaps [rsp+0x10], xmm15
0000796caeddf14c  movaps [rsp+0x20], xmm6
0000796caeddf151  lea rdi, [rsp]
0000796caeddf155  mov esi, 0x00
0000796caeddf15a  mov rax, 0x56877063A530
0000796caeddf164  call rax
0000796caeddf166  movaps xmm1, [rsp]
0000796caeddf16a  add rsp, 0x30
0000796caeddf16e  vmovaps xmm0, [rsp]
0000796caeddf173  vmovaps xmm2, [rsp+0x10]
0000796caeddf179  vmovaps xmm3, [rsp+0x20]
0000796caeddf17f  vmovaps xmm4, [rsp+0x30]
0000796caeddf185  vmovaps xmm5, [rsp+0x40]
0000796caeddf18b  vmovaps xmm6, [rsp+0x50]
0000796caeddf191  vmovaps xmm7, [rsp+0x60]
0000796caeddf197  vmovaps xmm8, [rsp+0x70]
0000796caeddf19d  vmovaps xmm9, [rsp+0x80]
0000796caeddf1a6  vmovaps xmm10, [rsp+0x90]
0000796caeddf1af  vmovaps xmm11, [rsp+0xA0]
0000796caeddf1b8  vmovaps xmm12, [rsp+0xB0]
0000796caeddf1c1  vmovaps xmm13, [rsp+0xC0]
0000796caeddf1ca  vmovaps xmm14, [rsp+0xD0]
0000796caeddf1d3  vmovaps xmm15, [rsp+0xE0]
0000796caeddf1dc  add rsp, 0xF0
0000796caeddf1e3  pop r11
0000796caeddf1e5  pop r10
0000796caeddf1e7  pop r9
0000796caeddf1e9  pop r8
0000796caeddf1eb  pop rsi
0000796caeddf1ec  pop rdi
0000796caeddf1ed  pop rdx
0000796caeddf1ee  pop rcx
0000796caeddf1ef  pop rax
0000796caeddf1f0  add rsp, 0x08
0000796caeddf1f4  jmp 0x0000796CAEDDC375
0000796caeddf1f9  sub rsp, 0x08
0000796caeddf1fd  push rax
0000796caeddf1fe  push rcx
0000796caeddf1ff  push rdx
0000796caeddf200  push rdi
0000796caeddf201  push rsi
0000796caeddf202  push r8
0000796caeddf204  push r9
0000796caeddf206  push r10
0000796caeddf208  push r11
0000796caeddf20a  sub rsp, 0xF0
0000796caeddf211  vmovaps [rsp], xmm0
0000796caeddf216  vmovaps [rsp+0x10], xmm1
0000796caeddf21c  vmovaps [rsp+0x20], xmm2
0000796caeddf222  vmovaps [rsp+0x30], xmm3
0000796caeddf228  vmovaps [rsp+0x40], xmm4
0000796caeddf22e  vmovaps [rsp+0x50], xmm5
0000796caeddf234  vmovaps [rsp+0x60], xmm6
0000796caeddf23a  vmovaps [rsp+0x70], xmm7
0000796caeddf240  vmovaps [rsp+0x80], xmm8
0000796caeddf249  vmovaps [rsp+0x90], xmm9
0000796caeddf252  vmovaps [rsp+0xA0], xmm10
0000796caeddf25b  vmovaps [rsp+0xB0], xmm11
0000796caeddf264  vmovaps [rsp+0xC0], xmm12
0000796caeddf26d  vmovaps [rsp+0xD0], xmm13
0000796caeddf276  vmovaps [rsp+0xE0], xmm14
0000796caeddf27f  sub rsp, 0x30
0000796caeddf283  movaps [rsp], xmm15
0000796caeddf288  movaps [rsp+0x10], xmm5
0000796caeddf28d  movaps [rsp+0x20], xmm3
0000796caeddf292  lea rdi, [rsp]
0000796caeddf296  mov esi, 0x00
0000796caeddf29b  mov rax, 0x56877063A530
0000796caeddf2a5  call rax
0000796caeddf2a7  movaps xmm15, [rsp]
0000796caeddf2ac  add rsp, 0x30
0000796caeddf2b0  vmovaps xmm0, [rsp]
0000796caeddf2b5  vmovaps xmm1, [rsp+0x10]
0000796caeddf2bb  vmovaps xmm2, [rsp+0x20]
0000796caeddf2c1  vmovaps xmm3, [rsp+0x30]
0000796caeddf2c7  vmovaps xmm4, [rsp+0x40]
0000796caeddf2cd  vmovaps xmm5, [rsp+0x50]
0000796caeddf2d3  vmovaps xmm6, [rsp+0x60]
0000796caeddf2d9  vmovaps xmm7, [rsp+0x70]
0000796caeddf2df  vmovaps xmm8, [rsp+0x80]
0000796caeddf2e8  vmovaps xmm9, [rsp+0x90]
0000796caeddf2f1  vmovaps xmm10, [rsp+0xA0]
0000796caeddf2fa  vmovaps xmm11, [rsp+0xB0]
0000796caeddf303  vmovaps xmm12, [rsp+0xC0]
0000796caeddf30c  vmovaps xmm13, [rsp+0xD0]
0000796caeddf315  vmovaps xmm14, [rsp+0xE0]
0000796caeddf31e  add rsp, 0xF0
0000796caeddf325  pop r11
0000796caeddf327  pop r10
0000796caeddf329  pop r9
0000796caeddf32b  pop r8
0000796caeddf32d  pop rsi
0000796caeddf32e  pop rdi
0000796caeddf32f  pop rdx
0000796caeddf330  pop rcx
0000796caeddf331  pop rax
0000796caeddf332  add rsp, 0x08
0000796caeddf336  jmp 0x0000796CAEDDC38F
0000796caeddf33b  sub rsp, 0x08
0000796caeddf33f  push rax
0000796caeddf340  push rcx
0000796caeddf341  push rdx
0000796caeddf342  push rdi
0000796caeddf343  push rsi
0000796caeddf344  push r8
0000796caeddf346  push r9
0000796caeddf348  push r10
0000796caeddf34a  push r11
0000796caeddf34c  sub rsp, 0xF0
0000796caeddf353  vmovaps [rsp], xmm0
0000796caeddf358  vmovaps [rsp+0x10], xmm1
0000796caeddf35e  vmovaps [rsp+0x20], xmm2
0000796caeddf364  vmovaps [rsp+0x30], xmm3
0000796caeddf36a  vmovaps [rsp+0x40], xmm4
0000796caeddf370  vmovaps [rsp+0x50], xmm6
0000796caeddf376  vmovaps [rsp+0x60], xmm7
0000796caeddf37c  vmovaps [rsp+0x70], xmm8
0000796caeddf382  vmovaps [rsp+0x80], xmm9
0000796caeddf38b  vmovaps [rsp+0x90], xmm10
0000796caeddf394  vmovaps [rsp+0xA0], xmm11
0000796caeddf39d  vmovaps [rsp+0xB0], xmm12
0000796caeddf3a6  vmovaps [rsp+0xC0], xmm13
0000796caeddf3af  vmovaps [rsp+0xD0], xmm14
0000796caeddf3b8  vmovaps [rsp+0xE0], xmm15
0000796caeddf3c1  sub rsp, 0x30
0000796caeddf3c5  movaps [rsp], xmm5
0000796caeddf3c9  movaps [rsp+0x10], xmm8
0000796caeddf3cf  movaps [rsp+0x20], xmm6
0000796caeddf3d4  lea rdi, [rsp]
0000796caeddf3d8  mov esi, 0x00
0000796caeddf3dd  mov rax, 0x56877063A530
0000796caeddf3e7  call rax
0000796caeddf3e9  movaps xmm5, [rsp]
0000796caeddf3ed  add rsp, 0x30
0000796caeddf3f1  vmovaps xmm0, [rsp]
0000796caeddf3f6  vmovaps xmm1, [rsp+0x10]
0000796caeddf3fc  vmovaps xmm2, [rsp+0x20]
0000796caeddf402  vmovaps xmm3, [rsp+0x30]
0000796caeddf408  vmovaps xmm4, [rsp+0x40]
0000796caeddf40e  vmovaps xmm6, [rsp+0x50]
0000796caeddf414  vmovaps xmm7, [rsp+0x60]
0000796caeddf41a  vmovaps xmm8, [rsp+0x70]
0000796caeddf420  vmovaps xmm9, [rsp+0x80]
0000796caeddf429  vmovaps xmm10, [rsp+0x90]
0000796caeddf432  vmovaps xmm11, [rsp+0xA0]
0000796caeddf43b  vmovaps xmm12, [rsp+0xB0]
0000796caeddf444  vmovaps xmm13, [rsp+0xC0]
0000796caeddf44d  vmovaps xmm14, [rsp+0xD0]
0000796caeddf456  vmovaps xmm15, [rsp+0xE0]
0000796caeddf45f  add rsp, 0xF0
0000796caeddf466  pop r11
0000796caeddf468  pop r10
0000796caeddf46a  pop r9
0000796caeddf46c  pop r8
0000796caeddf46e  pop rsi
0000796caeddf46f  pop rdi
0000796caeddf470  pop rdx
0000796caeddf471  pop rcx
0000796caeddf472  pop rax
0000796caeddf473  add rsp, 0x08
0000796caeddf477  jmp 0x0000796CAEDDC3B3
0000796caeddf47c  sub rsp, 0x08
0000796caeddf480  push rax
0000796caeddf481  push rcx
0000796caeddf482  push rdx
0000796caeddf483  push rdi
0000796caeddf484  push rsi
0000796caeddf485  push r8
0000796caeddf487  push r9
0000796caeddf489  push r10
0000796caeddf48b  push r11
0000796caeddf48d  sub rsp, 0xF0
0000796caeddf494  vmovaps [rsp], xmm0
0000796caeddf499  vmovaps [rsp+0x10], xmm1
0000796caeddf49f  vmovaps [rsp+0x20], xmm2
0000796caeddf4a5  vmovaps [rsp+0x30], xmm3
0000796caeddf4ab  vmovaps [rsp+0x40], xmm4
0000796caeddf4b1  vmovaps [rsp+0x50], xmm5
0000796caeddf4b7  vmovaps [rsp+0x60], xmm7
0000796caeddf4bd  vmovaps [rsp+0x70], xmm8
0000796caeddf4c3  vmovaps [rsp+0x80], xmm9
0000796caeddf4cc  vmovaps [rsp+0x90], xmm10
0000796caeddf4d5  vmovaps [rsp+0xA0], xmm11
0000796caeddf4de  vmovaps [rsp+0xB0], xmm12
0000796caeddf4e7  vmovaps [rsp+0xC0], xmm13
0000796caeddf4f0  vmovaps [rsp+0xD0], xmm14
0000796caeddf4f9  vmovaps [rsp+0xE0], xmm15
0000796caeddf502  sub rsp, 0x30
0000796caeddf506  movaps [rsp], xmm6
0000796caeddf50a  movaps [rsp+0x10], xmm10
0000796caeddf510  movaps [rsp+0x20], xmm8
0000796caeddf516  lea rdi, [rsp]
0000796caeddf51a  mov esi, 0x00
0000796caeddf51f  mov rax, 0x56877063A530
0000796caeddf529  call rax
0000796caeddf52b  movaps xmm6, [rsp]
0000796caeddf52f  add rsp, 0x30
0000796caeddf533  vmovaps xmm0, [rsp]
0000796caeddf538  vmovaps xmm1, [rsp+0x10]
0000796caeddf53e  vmovaps xmm2, [rsp+0x20]
0000796caeddf544  vmovaps xmm3, [rsp+0x30]
0000796caeddf54a  vmovaps xmm4, [rsp+0x40]
0000796caeddf550  vmovaps xmm5, [rsp+0x50]
0000796caeddf556  vmovaps xmm7, [rsp+0x60]
0000796caeddf55c  vmovaps xmm8, [rsp+0x70]
0000796caeddf562  vmovaps xmm9, [rsp+0x80]
0000796caeddf56b  vmovaps xmm10, [rsp+0x90]
0000796caeddf574  vmovaps xmm11, [rsp+0xA0]
0000796caeddf57d  vmovaps xmm12, [rsp+0xB0]
0000796caeddf586  vmovaps xmm13, [rsp+0xC0]
0000796caeddf58f  vmovaps xmm14, [rsp+0xD0]
0000796caeddf598  vmovaps xmm15, [rsp+0xE0]
0000796caeddf5a1  add rsp, 0xF0
0000796caeddf5a8  pop r11
0000796caeddf5aa  pop r10
0000796caeddf5ac  pop r9
0000796caeddf5ae  pop r8
0000796caeddf5b0  pop rsi
0000796caeddf5b1  pop rdi
0000796caeddf5b2  pop rdx
0000796caeddf5b3  pop rcx
0000796caeddf5b4  pop rax
0000796caeddf5b5  add rsp, 0x08
0000796caeddf5b9  jmp 0x0000796CAEDDC3D8
0000796caeddf5be  sub rsp, 0x08
0000796caeddf5c2  push rax
0000796caeddf5c3  push rcx
0000796caeddf5c4  push rdx
0000796caeddf5c5  push rdi
0000796caeddf5c6  push rsi
0000796caeddf5c7  push r8
0000796caeddf5c9  push r9
0000796caeddf5cb  push r10
0000796caeddf5cd  push r11
0000796caeddf5cf  sub rsp, 0xF0
0000796caeddf5d6  vmovaps [rsp], xmm0
0000796caeddf5db  vmovaps [rsp+0x10], xmm1
0000796caeddf5e1  vmovaps [rsp+0x20], xmm2
0000796caeddf5e7  vmovaps [rsp+0x30], xmm3
0000796caeddf5ed  vmovaps [rsp+0x40], xmm4
0000796caeddf5f3  vmovaps [rsp+0x50], xmm5
0000796caeddf5f9  vmovaps [rsp+0x60], xmm6
0000796caeddf5ff  vmovaps [rsp+0x70], xmm7
0000796caeddf605  vmovaps [rsp+0x80], xmm8
0000796caeddf60e  vmovaps [rsp+0x90], xmm9
0000796caeddf617  vmovaps [rsp+0xA0], xmm11
0000796caeddf620  vmovaps [rsp+0xB0], xmm12
0000796caeddf629  vmovaps [rsp+0xC0], xmm13
0000796caeddf632  vmovaps [rsp+0xD0], xmm14
0000796caeddf63b  vmovaps [rsp+0xE0], xmm15
0000796caeddf644  sub rsp, 0x30
0000796caeddf648  movaps [rsp], xmm10
0000796caeddf64d  movaps [rsp+0x10], xmm8
0000796caeddf653  movaps [rsp+0x20], xmm14
0000796caeddf659  lea rdi, [rsp]
0000796caeddf65d  mov esi, 0x00
0000796caeddf662  mov rax, 0x56877063A530
0000796caeddf66c  call rax
0000796caeddf66e  movaps xmm10, [rsp]
0000796caeddf673  add rsp, 0x30
0000796caeddf677  vmovaps xmm0, [rsp]
0000796caeddf67c  vmovaps xmm1, [rsp+0x10]
0000796caeddf682  vmovaps xmm2, [rsp+0x20]
0000796caeddf688  vmovaps xmm3, [rsp+0x30]
0000796caeddf68e  vmovaps xmm4, [rsp+0x40]
0000796caeddf694  vmovaps xmm5, [rsp+0x50]
0000796caeddf69a  vmovaps xmm6, [rsp+0x60]
0000796caeddf6a0  vmovaps xmm7, [rsp+0x70]
0000796caeddf6a6  vmovaps xmm8, [rsp+0x80]
0000796caeddf6af  vmovaps xmm9, [rsp+0x90]
0000796caeddf6b8  vmovaps xmm11, [rsp+0xA0]
0000796caeddf6c1  vmovaps xmm12, [rsp+0xB0]
0000796caeddf6ca  vmovaps xmm13, [rsp+0xC0]
0000796caeddf6d3  vmovaps xmm14, [rsp+0xD0]
0000796caeddf6dc  vmovaps xmm15, [rsp+0xE0]
0000796caeddf6e5  add rsp, 0xF0
0000796caeddf6ec  pop r11
0000796caeddf6ee  pop r10
0000796caeddf6f0  pop r9
0000796caeddf6f2  pop r8
0000796caeddf6f4  pop rsi
0000796caeddf6f5  pop rdi
0000796caeddf6f6  pop rdx
0000796caeddf6f7  pop rcx
0000796caeddf6f8  pop rax
0000796caeddf6f9  add rsp, 0x08
0000796caeddf6fd  jmp 0x0000796CAEDDC3F8
0000796caeddf702  sub rsp, 0x08
0000796caeddf706  push rax
0000796caeddf707  push rcx
0000796caeddf708  push rdx
0000796caeddf709  push rdi
0000796caeddf70a  push rsi
0000796caeddf70b  push r8
0000796caeddf70d  push r9
0000796caeddf70f  push r10
0000796caeddf711  push r11
0000796caeddf713  sub rsp, 0xF0
0000796caeddf71a  vmovaps [rsp], xmm0
0000796caeddf71f  vmovaps [rsp+0x10], xmm1
0000796caeddf725  vmovaps [rsp+0x20], xmm2
0000796caeddf72b  vmovaps [rsp+0x30], xmm3
0000796caeddf731  vmovaps [rsp+0x40], xmm4
0000796caeddf737  vmovaps [rsp+0x50], xmm5
0000796caeddf73d  vmovaps [rsp+0x60], xmm6
0000796caeddf743  vmovaps [rsp+0x70], xmm7
0000796caeddf749  vmovaps [rsp+0x80], xmm8
0000796caeddf752  vmovaps [rsp+0x90], xmm9
0000796caeddf75b  vmovaps [rsp+0xA0], xmm10
0000796caeddf764  vmovaps [rsp+0xB0], xmm11
0000796caeddf76d  vmovaps [rsp+0xC0], xmm12
0000796caeddf776  vmovaps [rsp+0xD0], xmm13
0000796caeddf77f  vmovaps [rsp+0xE0], xmm15
0000796caeddf788  sub rsp, 0x30
0000796caeddf78c  movaps [rsp], xmm14
0000796caeddf791  movaps [rsp+0x10], xmm8
0000796caeddf797  movaps [rsp+0x20], xmm4
0000796caeddf79c  lea rdi, [rsp]
0000796caeddf7a0  mov esi, 0x00
0000796caeddf7a5  mov rax, 0x56877063A530
0000796caeddf7af  call rax
0000796caeddf7b1  movaps xmm14, [rsp]
0000796caeddf7b6  add rsp, 0x30
0000796caeddf7ba  vmovaps xmm0, [rsp]
0000796caeddf7bf  vmovaps xmm1, [rsp+0x10]
0000796caeddf7c5  vmovaps xmm2, [rsp+0x20]
0000796caeddf7cb  vmovaps xmm3, [rsp+0x30]
0000796caeddf7d1  vmovaps xmm4, [rsp+0x40]
0000796caeddf7d7  vmovaps xmm5, [rsp+0x50]
0000796caeddf7dd  vmovaps xmm6, [rsp+0x60]
0000796caeddf7e3  vmovaps xmm7, [rsp+0x70]
0000796caeddf7e9  vmovaps xmm8, [rsp+0x80]
0000796caeddf7f2  vmovaps xmm9, [rsp+0x90]
0000796caeddf7fb  vmovaps xmm10, [rsp+0xA0]
0000796caeddf804  vmovaps xmm11, [rsp+0xB0]
0000796caeddf80d  vmovaps xmm12, [rsp+0xC0]
0000796caeddf816  vmovaps xmm13, [rsp+0xD0]
0000796caeddf81f  vmovaps xmm15, [rsp+0xE0]
0000796caeddf828  add rsp, 0xF0
0000796caeddf82f  pop r11
0000796caeddf831  pop r10
0000796caeddf833  pop r9
0000796caeddf835  pop r8
0000796caeddf837  pop rsi
0000796caeddf838  pop rdi
0000796caeddf839  pop rdx
0000796caeddf83a  pop rcx
0000796caeddf83b  pop rax
0000796caeddf83c  add rsp, 0x08
0000796caeddf840  jmp 0x0000796CAEDDC418
0000796caeddf845  sub rsp, 0x08
0000796caeddf849  push rax
0000796caeddf84a  push rcx
0000796caeddf84b  push rdx
0000796caeddf84c  push rdi
0000796caeddf84d  push rsi
0000796caeddf84e  push r8
0000796caeddf850  push r9
0000796caeddf852  push r10
0000796caeddf854  push r11
0000796caeddf856  sub rsp, 0xF0
0000796caeddf85d  vmovaps [rsp], xmm0
0000796caeddf862  vmovaps [rsp+0x10], xmm1
0000796caeddf868  vmovaps [rsp+0x20], xmm2
0000796caeddf86e  vmovaps [rsp+0x30], xmm3
0000796caeddf874  vmovaps [rsp+0x40], xmm5
0000796caeddf87a  vmovaps [rsp+0x50], xmm6
0000796caeddf880  vmovaps [rsp+0x60], xmm7
0000796caeddf886  vmovaps [rsp+0x70], xmm8
0000796caeddf88c  vmovaps [rsp+0x80], xmm9
0000796caeddf895  vmovaps [rsp+0x90], xmm10
0000796caeddf89e  vmovaps [rsp+0xA0], xmm11
0000796caeddf8a7  vmovaps [rsp+0xB0], xmm12
0000796caeddf8b0  vmovaps [rsp+0xC0], xmm13
0000796caeddf8b9  vmovaps [rsp+0xD0], xmm14
0000796caeddf8c2  vmovaps [rsp+0xE0], xmm15
0000796caeddf8cb  sub rsp, 0x30
0000796caeddf8cf  movaps [rsp], xmm4
0000796caeddf8d3  movaps [rsp+0x10], xmm13
0000796caeddf8d9  movaps [rsp+0x20], xmm8
0000796caeddf8df  lea rdi, [rsp]
0000796caeddf8e3  mov esi, 0x00
0000796caeddf8e8  mov rax, 0x56877063A530
0000796caeddf8f2  call rax
0000796caeddf8f4  movaps xmm4, [rsp]
0000796caeddf8f8  add rsp, 0x30
0000796caeddf8fc  vmovaps xmm0, [rsp]
0000796caeddf901  vmovaps xmm1, [rsp+0x10]
0000796caeddf907  vmovaps xmm2, [rsp+0x20]
0000796caeddf90d  vmovaps xmm3, [rsp+0x30]
0000796caeddf913  vmovaps xmm5, [rsp+0x40]
0000796caeddf919  vmovaps xmm6, [rsp+0x50]
0000796caeddf91f  vmovaps xmm7, [rsp+0x60]
0000796caeddf925  vmovaps xmm8, [rsp+0x70]
0000796caeddf92b  vmovaps xmm9, [rsp+0x80]
0000796caeddf934  vmovaps xmm10, [rsp+0x90]
0000796caeddf93d  vmovaps xmm11, [rsp+0xA0]
0000796caeddf946  vmovaps xmm12, [rsp+0xB0]
0000796caeddf94f  vmovaps xmm13, [rsp+0xC0]
0000796caeddf958  vmovaps xmm14, [rsp+0xD0]
0000796caeddf961  vmovaps xmm15, [rsp+0xE0]
0000796caeddf96a  add rsp, 0xF0
0000796caeddf971  pop r11
0000796caeddf973  pop r10
0000796caeddf975  pop r9
0000796caeddf977  pop r8
0000796caeddf979  pop rsi
0000796caeddf97a  pop rdi
0000796caeddf97b  pop rdx
0000796caeddf97c  pop rcx
0000796caeddf97d  pop rax
0000796caeddf97e  add rsp, 0x08
0000796caeddf982  jmp 0x0000796CAEDDC43D
0000796caeddf987  sub rsp, 0x08
0000796caeddf98b  push rax
0000796caeddf98c  push rcx
0000796caeddf98d  push rdx
0000796caeddf98e  push rdi
0000796caeddf98f  push rsi
0000796caeddf990  push r8
0000796caeddf992  push r9
0000796caeddf994  push r10
0000796caeddf996  push r11
0000796caeddf998  sub rsp, 0xF0
0000796caeddf99f  vmovaps [rsp], xmm0
0000796caeddf9a4  vmovaps [rsp+0x10], xmm1
0000796caeddf9aa  vmovaps [rsp+0x20], xmm2
0000796caeddf9b0  vmovaps [rsp+0x30], xmm3
0000796caeddf9b6  vmovaps [rsp+0x40], xmm4
0000796caeddf9bc  vmovaps [rsp+0x50], xmm5
0000796caeddf9c2  vmovaps [rsp+0x60], xmm6
0000796caeddf9c8  vmovaps [rsp+0x70], xmm7
0000796caeddf9ce  vmovaps [rsp+0x80], xmm8
0000796caeddf9d7  vmovaps [rsp+0x90], xmm9
0000796caeddf9e0  vmovaps [rsp+0xA0], xmm10
0000796caeddf9e9  vmovaps [rsp+0xB0], xmm11
0000796caeddf9f2  vmovaps [rsp+0xC0], xmm12
0000796caeddf9fb  vmovaps [rsp+0xD0], xmm14
0000796caeddfa04  vmovaps [rsp+0xE0], xmm15
0000796caeddfa0d  sub rsp, 0x30
0000796caeddfa11  movaps [rsp], xmm13
0000796caeddfa16  movaps [rsp+0x10], xmm15
0000796caeddfa1c  movaps [rsp+0x20], xmm9
0000796caeddfa22  lea rdi, [rsp]
0000796caeddfa26  mov esi, 0x00
0000796caeddfa2b  mov rax, 0x56877063A530
0000796caeddfa35  call rax
0000796caeddfa37  movaps xmm13, [rsp]
0000796caeddfa3c  add rsp, 0x30
0000796caeddfa40  vmovaps xmm0, [rsp]
0000796caeddfa45  vmovaps xmm1, [rsp+0x10]
0000796caeddfa4b  vmovaps xmm2, [rsp+0x20]
0000796caeddfa51  vmovaps xmm3, [rsp+0x30]
0000796caeddfa57  vmovaps xmm4, [rsp+0x40]
0000796caeddfa5d  vmovaps xmm5, [rsp+0x50]
0000796caeddfa63  vmovaps xmm6, [rsp+0x60]
0000796caeddfa69  vmovaps xmm7, [rsp+0x70]
0000796caeddfa6f  vmovaps xmm8, [rsp+0x80]
0000796caeddfa78  vmovaps xmm9, [rsp+0x90]
0000796caeddfa81  vmovaps xmm10, [rsp+0xA0]
0000796caeddfa8a  vmovaps xmm11, [rsp+0xB0]
0000796caeddfa93  vmovaps xmm12, [rsp+0xC0]
0000796caeddfa9c  vmovaps xmm14, [rsp+0xD0]
0000796caeddfaa5  vmovaps xmm15, [rsp+0xE0]
0000796caeddfaae  add rsp, 0xF0
0000796caeddfab5  pop r11
0000796caeddfab7  pop r10
0000796caeddfab9  pop r9
0000796caeddfabb  pop r8
0000796caeddfabd  pop rsi
0000796caeddfabe  pop rdi
0000796caeddfabf  pop rdx
0000796caeddfac0  pop rcx
0000796caeddfac1  pop rax
0000796caeddfac2  add rsp, 0x08
0000796caeddfac6  jmp 0x0000796CAEDDC458
0000796caeddfacb  sub rsp, 0x08
0000796caeddfacf  push rax
0000796caeddfad0  push rcx
0000796caeddfad1  push rdx
0000796caeddfad2  push rdi
0000796caeddfad3  push rsi
0000796caeddfad4  push r8
0000796caeddfad6  push r9
0000796caeddfad8  push r10
0000796caeddfada  push r11
0000796caeddfadc  sub rsp, 0xF0
0000796caeddfae3  vmovaps [rsp], xmm0
0000796caeddfae8  vmovaps [rsp+0x10], xmm1
0000796caeddfaee  vmovaps [rsp+0x20], xmm2
0000796caeddfaf4  vmovaps [rsp+0x30], xmm3
0000796caeddfafa  vmovaps [rsp+0x40], xmm4
0000796caeddfb00  vmovaps [rsp+0x50], xmm5
0000796caeddfb06  vmovaps [rsp+0x60], xmm6
0000796caeddfb0c  vmovaps [rsp+0x70], xmm7
0000796caeddfb12  vmovaps [rsp+0x80], xmm8
0000796caeddfb1b  vmovaps [rsp+0x90], xmm9
0000796caeddfb24  vmovaps [rsp+0xA0], xmm10
0000796caeddfb2d  vmovaps [rsp+0xB0], xmm11
0000796caeddfb36  vmovaps [rsp+0xC0], xmm12
0000796caeddfb3f  vmovaps [rsp+0xD0], xmm13
0000796caeddfb48  vmovaps [rsp+0xE0], xmm14
0000796caeddfb51  sub rsp, 0x30
0000796caeddfb55  movaps [rsp], xmm15
0000796caeddfb5a  movaps [rsp+0x10], xmm1
0000796caeddfb5f  movaps [rsp+0x20], xmm5
0000796caeddfb64  lea rdi, [rsp]
0000796caeddfb68  mov esi, 0x00
0000796caeddfb6d  mov rax, 0x56877063A530
0000796caeddfb77  call rax
0000796caeddfb79  movaps xmm15, [rsp]
0000796caeddfb7e  add rsp, 0x30
0000796caeddfb82  vmovaps xmm0, [rsp]
0000796caeddfb87  vmovaps xmm1, [rsp+0x10]
0000796caeddfb8d  vmovaps xmm2, [rsp+0x20]
0000796caeddfb93  vmovaps xmm3, [rsp+0x30]
0000796caeddfb99  vmovaps xmm4, [rsp+0x40]
0000796caeddfb9f  vmovaps xmm5, [rsp+0x50]
0000796caeddfba5  vmovaps xmm6, [rsp+0x60]
0000796caeddfbab  vmovaps xmm7, [rsp+0x70]
0000796caeddfbb1  vmovaps xmm8, [rsp+0x80]
0000796caeddfbba  vmovaps xmm9, [rsp+0x90]
0000796caeddfbc3  vmovaps xmm10, [rsp+0xA0]
0000796caeddfbcc  vmovaps xmm11, [rsp+0xB0]
0000796caeddfbd5  vmovaps xmm12, [rsp+0xC0]
0000796caeddfbde  vmovaps xmm13, [rsp+0xD0]
0000796caeddfbe7  vmovaps xmm14, [rsp+0xE0]
0000796caeddfbf0  add rsp, 0xF0
0000796caeddfbf7  pop r11
0000796caeddfbf9  pop r10
0000796caeddfbfb  pop r9
0000796caeddfbfd  pop r8
0000796caeddfbff  pop rsi
0000796caeddfc00  pop rdi
0000796caeddfc01  pop rdx
0000796caeddfc02  pop rcx
0000796caeddfc03  pop rax
0000796caeddfc04  add rsp, 0x08
0000796caeddfc08  jmp 0x0000796CAEDDC473
0000796caeddfc0d  call 0x0000796CAECB52F0
0000796caeddfc12  jmp 0x0000796CAEDDC4CE
0000796caeddfc17  sub rsp, 0x08
0000796caeddfc1b  push rax
0000796caeddfc1c  push rcx
0000796caeddfc1d  push rdx
0000796caeddfc1e  push rdi
0000796caeddfc1f  push rsi
0000796caeddfc20  push r8
0000796caeddfc22  push r9
0000796caeddfc24  push r10
0000796caeddfc26  push r11
0000796caeddfc28  sub rsp, 0xF0
0000796caeddfc2f  vmovaps [rsp], xmm0
0000796caeddfc34  vmovaps [rsp+0x10], xmm1
0000796caeddfc3a  vmovaps [rsp+0x20], xmm2
0000796caeddfc40  vmovaps [rsp+0x30], xmm3
0000796caeddfc46  vmovaps [rsp+0x40], xmm4
0000796caeddfc4c  vmovaps [rsp+0x50], xmm5
0000796caeddfc52  vmovaps [rsp+0x60], xmm6
0000796caeddfc58  vmovaps [rsp+0x70], xmm7
0000796caeddfc5e  vmovaps [rsp+0x80], xmm8
0000796caeddfc67  vmovaps [rsp+0x90], xmm10
0000796caeddfc70  vmovaps [rsp+0xA0], xmm11
0000796caeddfc79  vmovaps [rsp+0xB0], xmm12
0000796caeddfc82  vmovaps [rsp+0xC0], xmm13
0000796caeddfc8b  vmovaps [rsp+0xD0], xmm14
0000796caeddfc94  vmovaps [rsp+0xE0], xmm15
0000796caeddfc9d  sub rsp, 0x30
0000796caeddfca1  movaps [rsp], xmm9
0000796caeddfca6  movaps [rsp+0x10], xmm8
0000796caeddfcac  movaps [rsp+0x20], xmm11
0000796caeddfcb2  lea rdi, [rsp]
0000796caeddfcb6  mov esi, 0x00
0000796caeddfcbb  mov rax, 0x56877063A530
0000796caeddfcc5  call rax
0000796caeddfcc7  movaps xmm9, [rsp]
0000796caeddfccc  add rsp, 0x30
0000796caeddfcd0  vmovaps xmm0, [rsp]
0000796caeddfcd5  vmovaps xmm1, [rsp+0x10]
0000796caeddfcdb  vmovaps xmm2, [rsp+0x20]
0000796caeddfce1  vmovaps xmm3, [rsp+0x30]
0000796caeddfce7  vmovaps xmm4, [rsp+0x40]
0000796caeddfced  vmovaps xmm5, [rsp+0x50]
0000796caeddfcf3  vmovaps xmm6, [rsp+0x60]
0000796caeddfcf9  vmovaps xmm7, [rsp+0x70]
0000796caeddfcff  vmovaps xmm8, [rsp+0x80]
0000796caeddfd08  vmovaps xmm10, [rsp+0x90]
0000796caeddfd11  vmovaps xmm11, [rsp+0xA0]
0000796caeddfd1a  vmovaps xmm12, [rsp+0xB0]
0000796caeddfd23  vmovaps xmm13, [rsp+0xC0]
0000796caeddfd2c  vmovaps xmm14, [rsp+0xD0]
0000796caeddfd35  vmovaps xmm15, [rsp+0xE0]
0000796caeddfd3e  add rsp, 0xF0
0000796caeddfd45  pop r11
0000796caeddfd47  pop r10
0000796caeddfd49  pop r9
0000796caeddfd4b  pop r8
0000796caeddfd4d  pop rsi
0000796caeddfd4e  pop rdi
0000796caeddfd4f  pop rdx
0000796caeddfd50  pop rcx
0000796caeddfd51  pop rax
0000796caeddfd52  add rsp, 0x08
0000796caeddfd56  jmp 0x0000796CAEDDC505
0000796caeddfd5b  sub rsp, 0x08
0000796caeddfd5f  push rax
0000796caeddfd60  push rcx
0000796caeddfd61  push rdx
0000796caeddfd62  push rdi
0000796caeddfd63  push rsi
0000796caeddfd64  push r8
0000796caeddfd66  push r9
0000796caeddfd68  push r10
0000796caeddfd6a  push r11
0000796caeddfd6c  sub rsp, 0xF0
0000796caeddfd73  vmovaps [rsp], xmm0
0000796caeddfd78  vmovaps [rsp+0x10], xmm1
0000796caeddfd7e  vmovaps [rsp+0x20], xmm2
0000796caeddfd84  vmovaps [rsp+0x30], xmm3
0000796caeddfd8a  vmovaps [rsp+0x40], xmm4
0000796caeddfd90  vmovaps [rsp+0x50], xmm5
0000796caeddfd96  vmovaps [rsp+0x60], xmm6
0000796caeddfd9c  vmovaps [rsp+0x70], xmm7
0000796caeddfda2  vmovaps [rsp+0x80], xmm8
0000796caeddfdab  vmovaps [rsp+0x90], xmm9
0000796caeddfdb4  vmovaps [rsp+0xA0], xmm10
0000796caeddfdbd  vmovaps [rsp+0xB0], xmm12
0000796caeddfdc6  vmovaps [rsp+0xC0], xmm13
0000796caeddfdcf  vmovaps [rsp+0xD0], xmm14
0000796caeddfdd8  vmovaps [rsp+0xE0], xmm15
0000796caeddfde1  sub rsp, 0x30
0000796caeddfde5  movaps [rsp], xmm11
0000796caeddfdea  movaps [rsp+0x10], xmm10
0000796caeddfdf0  movaps [rsp+0x20], xmm6
0000796caeddfdf5  lea rdi, [rsp]
0000796caeddfdf9  mov esi, 0x00
0000796caeddfdfe  mov rax, 0x56877063A530
0000796caeddfe08  call rax
0000796caeddfe0a  movaps xmm11, [rsp]
0000796caeddfe0f  add rsp, 0x30
0000796caeddfe13  vmovaps xmm0, [rsp]
0000796caeddfe18  vmovaps xmm1, [rsp+0x10]
0000796caeddfe1e  vmovaps xmm2, [rsp+0x20]
0000796caeddfe24  vmovaps xmm3, [rsp+0x30]
0000796caeddfe2a  vmovaps xmm4, [rsp+0x40]
0000796caeddfe30  vmovaps xmm5, [rsp+0x50]
0000796caeddfe36  vmovaps xmm6, [rsp+0x60]
0000796caeddfe3c  vmovaps xmm7, [rsp+0x70]
0000796caeddfe42  vmovaps xmm8, [rsp+0x80]
0000796caeddfe4b  vmovaps xmm9, [rsp+0x90]
0000796caeddfe54  vmovaps xmm10, [rsp+0xA0]
0000796caeddfe5d  vmovaps xmm12, [rsp+0xB0]
0000796caeddfe66  vmovaps xmm13, [rsp+0xC0]
0000796caeddfe6f  vmovaps xmm14, [rsp+0xD0]
0000796caeddfe78  vmovaps xmm15, [rsp+0xE0]
0000796caeddfe81  add rsp, 0xF0
0000796caeddfe88  pop r11
0000796caeddfe8a  pop r10
0000796caeddfe8c  pop r9
0000796caeddfe8e  pop r8
0000796caeddfe90  pop rsi
0000796caeddfe91  pop rdi
0000796caeddfe92  pop rdx
0000796caeddfe93  pop rcx
0000796caeddfe94  pop rax
0000796caeddfe95  add rsp, 0x08
0000796caeddfe99  jmp 0x0000796CAEDDC520
0000796caeddfe9e  sub rsp, 0x08
0000796caeddfea2  push rax
0000796caeddfea3  push rcx
0000796caeddfea4  push rdx
0000796caeddfea5  push rdi
0000796caeddfea6  push rsi
0000796caeddfea7  push r8
0000796caeddfea9  push r9
0000796caeddfeab  push r10
0000796caeddfead  push r11
0000796caeddfeaf  sub rsp, 0xF0
0000796caeddfeb6  vmovaps [rsp], xmm0
0000796caeddfebb  vmovaps [rsp+0x10], xmm1
0000796caeddfec1  vmovaps [rsp+0x20], xmm2
0000796caeddfec7  vmovaps [rsp+0x30], xmm3
0000796caeddfecd  vmovaps [rsp+0x40], xmm4
0000796caeddfed3  vmovaps [rsp+0x50], xmm5
0000796caeddfed9  vmovaps [rsp+0x60], xmm6
0000796caeddfedf  vmovaps [rsp+0x70], xmm7
0000796caeddfee5  vmovaps [rsp+0x80], xmm8
0000796caeddfeee  vmovaps [rsp+0x90], xmm9
0000796caeddfef7  vmovaps [rsp+0xA0], xmm11
0000796caeddff00  vmovaps [rsp+0xB0], xmm12
0000796caeddff09  vmovaps [rsp+0xC0], xmm13
0000796caeddff12  vmovaps [rsp+0xD0], xmm14
0000796caeddff1b  vmovaps [rsp+0xE0], xmm15
0000796caeddff24  sub rsp, 0x30
0000796caeddff28  movaps [rsp], xmm10
0000796caeddff2d  movaps [rsp+0x10], xmm14
0000796caeddff33  movaps [rsp+0x20], xmm4
0000796caeddff38  lea rdi, [rsp]
0000796caeddff3c  mov esi, 0x00
0000796caeddff41  mov rax, 0x56877063A530
0000796caeddff4b  call rax
0000796caeddff4d  movaps xmm10, [rsp]
0000796caeddff52  add rsp, 0x30
0000796caeddff56  vmovaps xmm0, [rsp]
0000796caeddff5b  vmovaps xmm1, [rsp+0x10]
0000796caeddff61  vmovaps xmm2, [rsp+0x20]
0000796caeddff67  vmovaps xmm3, [rsp+0x30]
0000796caeddff6d  vmovaps xmm4, [rsp+0x40]
0000796caeddff73  vmovaps xmm5, [rsp+0x50]
0000796caeddff79  vmovaps xmm6, [rsp+0x60]
0000796caeddff7f  vmovaps xmm7, [rsp+0x70]
0000796caeddff85  vmovaps xmm8, [rsp+0x80]
0000796caeddff8e  vmovaps xmm9, [rsp+0x90]
0000796caeddff97  vmovaps xmm11, [rsp+0xA0]
0000796caeddffa0  vmovaps xmm12, [rsp+0xB0]
0000796caeddffa9  vmovaps xmm13, [rsp+0xC0]
0000796caeddffb2  vmovaps xmm14, [rsp+0xD0]
0000796caeddffbb  vmovaps xmm15, [rsp+0xE0]
0000796caeddffc4  add rsp, 0xF0
0000796caeddffcb  pop r11
0000796caeddffcd  pop r10
0000796caeddffcf  pop r9
0000796caeddffd1  pop r8
0000796caeddffd3  pop rsi
0000796caeddffd4  pop rdi
0000796caeddffd5  pop rdx
0000796caeddffd6  pop rcx
0000796caeddffd7  pop rax
0000796caeddffd8  add rsp, 0x08
0000796caeddffdc  jmp 0x0000796CAEDDC53B
0000796caeddffe1  sub rsp, 0x08
0000796caeddffe5  push rax
0000796caeddffe6  push rcx
0000796caeddffe7  push rdx
0000796caeddffe8  push rdi
0000796caeddffe9  push rsi
0000796caeddffea  push r8
0000796caeddffec  push r9
0000796caeddffee  push r10
0000796caeddfff0  push r11
0000796caeddfff2  sub rsp, 0xF0
0000796caeddfff9  vmovaps [rsp], xmm0
0000796caeddfffe  vmovaps [rsp+0x10], xmm1
0000796caede0004  vmovaps [rsp+0x20], xmm2
0000796caede000a  vmovaps [rsp+0x30], xmm3
0000796caede0010  vmovaps [rsp+0x40], xmm4
0000796caede0016  vmovaps [rsp+0x50], xmm5
0000796caede001c  vmovaps [rsp+0x60], xmm6
0000796caede0022  vmovaps [rsp+0x70], xmm7
0000796caede0028  vmovaps [rsp+0x80], xmm9
0000796caede0031  vmovaps [rsp+0x90], xmm10
0000796caede003a  vmovaps [rsp+0xA0], xmm11
0000796caede0043  vmovaps [rsp+0xB0], xmm12
0000796caede004c  vmovaps [rsp+0xC0], xmm13
0000796caede0055  vmovaps [rsp+0xD0], xmm14
0000796caede005e  vmovaps [rsp+0xE0], xmm15
0000796caede0067  sub rsp, 0x30
0000796caede006b  movaps [rsp], xmm8
0000796caede0070  movaps [rsp+0x10], xmm1
0000796caede0075  movaps [rsp+0x20], xmm14
0000796caede007b  lea rdi, [rsp]
0000796caede007f  mov esi, 0x00
0000796caede0084  mov rax, 0x56877063A530
0000796caede008e  call rax
0000796caede0090  movaps xmm8, [rsp]
0000796caede0095  add rsp, 0x30
0000796caede0099  vmovaps xmm0, [rsp]
0000796caede009e  vmovaps xmm1, [rsp+0x10]
0000796caede00a4  vmovaps xmm2, [rsp+0x20]
0000796caede00aa  vmovaps xmm3, [rsp+0x30]
0000796caede00b0  vmovaps xmm4, [rsp+0x40]
0000796caede00b6  vmovaps xmm5, [rsp+0x50]
0000796caede00bc  vmovaps xmm6, [rsp+0x60]
0000796caede00c2  vmovaps xmm7, [rsp+0x70]
0000796caede00c8  vmovaps xmm9, [rsp+0x80]
0000796caede00d1  vmovaps xmm10, [rsp+0x90]
0000796caede00da  vmovaps xmm11, [rsp+0xA0]
0000796caede00e3  vmovaps xmm12, [rsp+0xB0]
0000796caede00ec  vmovaps xmm13, [rsp+0xC0]
0000796caede00f5  vmovaps xmm14, [rsp+0xD0]
0000796caede00fe  vmovaps xmm15, [rsp+0xE0]
0000796caede0107  add rsp, 0xF0
0000796caede010e  pop r11
0000796caede0110  pop r10
0000796caede0112  pop r9
0000796caede0114  pop r8
0000796caede0116  pop rsi
0000796caede0117  pop rdi
0000796caede0118  pop rdx
0000796caede0119  pop rcx
0000796caede011a  pop rax
0000796caede011b  add rsp, 0x08
0000796caede011f  jmp 0x0000796CAEDDC561
0000796caede0124  sub rsp, 0x08
0000796caede0128  push rax
0000796caede0129  push rcx
0000796caede012a  push rdx
0000796caede012b  push rdi
0000796caede012c  push rsi
0000796caede012d  push r8
0000796caede012f  push r9
0000796caede0131  push r10
0000796caede0133  push r11
0000796caede0135  sub rsp, 0xF0
0000796caede013c  vmovaps [rsp], xmm0
0000796caede0141  vmovaps [rsp+0x10], xmm1
0000796caede0147  vmovaps [rsp+0x20], xmm2
0000796caede014d  vmovaps [rsp+0x30], xmm3
0000796caede0153  vmovaps [rsp+0x40], xmm4
0000796caede0159  vmovaps [rsp+0x50], xmm5
0000796caede015f  vmovaps [rsp+0x60], xmm7
0000796caede0165  vmovaps [rsp+0x70], xmm8
0000796caede016b  vmovaps [rsp+0x80], xmm9
0000796caede0174  vmovaps [rsp+0x90], xmm10
0000796caede017d  vmovaps [rsp+0xA0], xmm11
0000796caede0186  vmovaps [rsp+0xB0], xmm12
0000796caede018f  vmovaps [rsp+0xC0], xmm13
0000796caede0198  vmovaps [rsp+0xD0], xmm14
0000796caede01a1  vmovaps [rsp+0xE0], xmm15
0000796caede01aa  sub rsp, 0x30
0000796caede01ae  movaps [rsp], xmm6
0000796caede01b2  movaps [rsp+0x10], xmm1
0000796caede01b7  movaps [rsp+0x20], xmm14
0000796caede01bd  lea rdi, [rsp]
0000796caede01c1  mov esi, 0x00
0000796caede01c6  mov rax, 0x56877063A530
0000796caede01d0  call rax
0000796caede01d2  movaps xmm6, [rsp]
0000796caede01d6  add rsp, 0x30
0000796caede01da  vmovaps xmm0, [rsp]
0000796caede01df  vmovaps xmm1, [rsp+0x10]
0000796caede01e5  vmovaps xmm2, [rsp+0x20]
0000796caede01eb  vmovaps xmm3, [rsp+0x30]
0000796caede01f1  vmovaps xmm4, [rsp+0x40]
0000796caede01f7  vmovaps xmm5, [rsp+0x50]
0000796caede01fd  vmovaps xmm7, [rsp+0x60]
0000796caede0203  vmovaps xmm8, [rsp+0x70]
0000796caede0209  vmovaps xmm9, [rsp+0x80]
0000796caede0212  vmovaps xmm10, [rsp+0x90]
0000796caede021b  vmovaps xmm11, [rsp+0xA0]
0000796caede0224  vmovaps xmm12, [rsp+0xB0]
0000796caede022d  vmovaps xmm13, [rsp+0xC0]
0000796caede0236  vmovaps xmm14, [rsp+0xD0]
0000796caede023f  vmovaps xmm15, [rsp+0xE0]
0000796caede0248  add rsp, 0xF0
0000796caede024f  pop r11
0000796caede0251  pop r10
0000796caede0253  pop r9
0000796caede0255  pop r8
0000796caede0257  pop rsi
0000796caede0258  pop rdi
0000796caede0259  pop rdx
0000796caede025a  pop rcx
0000796caede025b  pop rax
0000796caede025c  add rsp, 0x08
0000796caede0260  jmp 0x0000796CAEDDC58D
0000796caede0265  sub rsp, 0x08
0000796caede0269  push rax
0000796caede026a  push rcx
0000796caede026b  push rdx
0000796caede026c  push rdi
0000796caede026d  push rsi
0000796caede026e  push r8
0000796caede0270  push r9
0000796caede0272  push r10
0000796caede0274  push r11
0000796caede0276  sub rsp, 0xF0
0000796caede027d  vmovaps [rsp], xmm0
0000796caede0282  vmovaps [rsp+0x10], xmm1
0000796caede0288  vmovaps [rsp+0x20], xmm2
0000796caede028e  vmovaps [rsp+0x30], xmm3
0000796caede0294  vmovaps [rsp+0x40], xmm4
0000796caede029a  vmovaps [rsp+0x50], xmm5
0000796caede02a0  vmovaps [rsp+0x60], xmm6
0000796caede02a6  vmovaps [rsp+0x70], xmm7
0000796caede02ac  vmovaps [rsp+0x80], xmm8
0000796caede02b5  vmovaps [rsp+0x90], xmm9
0000796caede02be  vmovaps [rsp+0xA0], xmm10
0000796caede02c7  vmovaps [rsp+0xB0], xmm11
0000796caede02d0  vmovaps [rsp+0xC0], xmm12
0000796caede02d9  vmovaps [rsp+0xD0], xmm13
0000796caede02e2  vmovaps [rsp+0xE0], xmm15
0000796caede02eb  sub rsp, 0x30
0000796caede02ef  movaps [rsp], xmm14
0000796caede02f4  movaps [rsp+0x10], xmm12
0000796caede02fa  movaps [rsp+0x20], xmm1
0000796caede02ff  lea rdi, [rsp]
0000796caede0303  mov esi, 0x00
0000796caede0308  mov rax, 0x56877063A530
0000796caede0312  call rax
0000796caede0314  movaps xmm14, [rsp]
0000796caede0319  add rsp, 0x30
0000796caede031d  vmovaps xmm0, [rsp]
0000796caede0322  vmovaps xmm1, [rsp+0x10]
0000796caede0328  vmovaps xmm2, [rsp+0x20]
0000796caede032e  vmovaps xmm3, [rsp+0x30]
0000796caede0334  vmovaps xmm4, [rsp+0x40]
0000796caede033a  vmovaps xmm5, [rsp+0x50]
0000796caede0340  vmovaps xmm6, [rsp+0x60]
0000796caede0346  vmovaps xmm7, [rsp+0x70]
0000796caede034c  vmovaps xmm8, [rsp+0x80]
0000796caede0355  vmovaps xmm9, [rsp+0x90]
0000796caede035e  vmovaps xmm10, [rsp+0xA0]
0000796caede0367  vmovaps xmm11, [rsp+0xB0]
0000796caede0370  vmovaps xmm12, [rsp+0xC0]
0000796caede0379  vmovaps xmm13, [rsp+0xD0]
0000796caede0382  vmovaps xmm15, [rsp+0xE0]
0000796caede038b  add rsp, 0xF0
0000796caede0392  pop r11
0000796caede0394  pop r10
0000796caede0396  pop r9
0000796caede0398  pop r8
0000796caede039a  pop rsi
0000796caede039b  pop rdi
0000796caede039c  pop rdx
0000796caede039d  pop rcx
0000796caede039e  pop rax
0000796caede039f  add rsp, 0x08
0000796caede03a3  jmp 0x0000796CAEDDC5B3
0000796caede03a8  sub rsp, 0x08
0000796caede03ac  push rax
0000796caede03ad  push rcx
0000796caede03ae  push rdx
0000796caede03af  push rdi
0000796caede03b0  push rsi
0000796caede03b1  push r8
0000796caede03b3  push r9
0000796caede03b5  push r10
0000796caede03b7  push r11
0000796caede03b9  sub rsp, 0xF0
0000796caede03c0  vmovaps [rsp], xmm0
0000796caede03c5  vmovaps [rsp+0x10], xmm2
0000796caede03cb  vmovaps [rsp+0x20], xmm3
0000796caede03d1  vmovaps [rsp+0x30], xmm4
0000796caede03d7  vmovaps [rsp+0x40], xmm5
0000796caede03dd  vmovaps [rsp+0x50], xmm6
0000796caede03e3  vmovaps [rsp+0x60], xmm7
0000796caede03e9  vmovaps [rsp+0x70], xmm8
0000796caede03ef  vmovaps [rsp+0x80], xmm9
0000796caede03f8  vmovaps [rsp+0x90], xmm10
0000796caede0401  vmovaps [rsp+0xA0], xmm11
0000796caede040a  vmovaps [rsp+0xB0], xmm12
0000796caede0413  vmovaps [rsp+0xC0], xmm13
0000796caede041c  vmovaps [rsp+0xD0], xmm14
0000796caede0425  vmovaps [rsp+0xE0], xmm15
0000796caede042e  sub rsp, 0x30
0000796caede0432  movaps [rsp], xmm1
0000796caede0436  movaps [rsp+0x10], xmm13
0000796caede043c  movaps [rsp+0x20], xmm9
0000796caede0442  lea rdi, [rsp]
0000796caede0446  mov esi, 0x00
0000796caede044b  mov rax, 0x56877063A530
0000796caede0455  call rax
0000796caede0457  movaps xmm1, [rsp]
0000796caede045b  add rsp, 0x30
0000796caede045f  vmovaps xmm0, [rsp]
0000796caede0464  vmovaps xmm2, [rsp+0x10]
0000796caede046a  vmovaps xmm3, [rsp+0x20]
0000796caede0470  vmovaps xmm4, [rsp+0x30]
0000796caede0476  vmovaps xmm5, [rsp+0x40]
0000796caede047c  vmovaps xmm6, [rsp+0x50]
0000796caede0482  vmovaps xmm7, [rsp+0x60]
0000796caede0488  vmovaps xmm8, [rsp+0x70]
0000796caede048e  vmovaps xmm9, [rsp+0x80]
0000796caede0497  vmovaps xmm10, [rsp+0x90]
0000796caede04a0  vmovaps xmm11, [rsp+0xA0]
0000796caede04a9  vmovaps xmm12, [rsp+0xB0]
0000796caede04b2  vmovaps xmm13, [rsp+0xC0]
0000796caede04bb  vmovaps xmm14, [rsp+0xD0]
0000796caede04c4  vmovaps xmm15, [rsp+0xE0]
0000796caede04cd  add rsp, 0xF0
0000796caede04d4  pop r11
0000796caede04d6  pop r10
0000796caede04d8  pop r9
0000796caede04da  pop r8
0000796caede04dc  pop rsi
0000796caede04dd  pop rdi
0000796caede04de  pop rdx
0000796caede04df  pop rcx
0000796caede04e0  pop rax
0000796caede04e1  add rsp, 0x08
0000796caede04e5  jmp 0x0000796CAEDDC5CD
0000796caede04ea  sub rsp, 0x08
0000796caede04ee  push rax
0000796caede04ef  push rcx
0000796caede04f0  push rdx
0000796caede04f1  push rdi
0000796caede04f2  push rsi
0000796caede04f3  push r8
0000796caede04f5  push r9
0000796caede04f7  push r10
0000796caede04f9  push r11
0000796caede04fb  sub rsp, 0xF0
0000796caede0502  vmovaps [rsp], xmm0
0000796caede0507  vmovaps [rsp+0x10], xmm1
0000796caede050d  vmovaps [rsp+0x20], xmm2
0000796caede0513  vmovaps [rsp+0x30], xmm3
0000796caede0519  vmovaps [rsp+0x40], xmm4
0000796caede051f  vmovaps [rsp+0x50], xmm5
0000796caede0525  vmovaps [rsp+0x60], xmm6
0000796caede052b  vmovaps [rsp+0x70], xmm7
0000796caede0531  vmovaps [rsp+0x80], xmm8
0000796caede053a  vmovaps [rsp+0x90], xmm9
0000796caede0543  vmovaps [rsp+0xA0], xmm10
0000796caede054c  vmovaps [rsp+0xB0], xmm11
0000796caede0555  vmovaps [rsp+0xC0], xmm13
0000796caede055e  vmovaps [rsp+0xD0], xmm14
0000796caede0567  vmovaps [rsp+0xE0], xmm15
0000796caede0570  sub rsp, 0x30
0000796caede0574  movaps [rsp], xmm12
0000796caede0579  movaps [rsp+0x10], xmm7
0000796caede057e  movaps [rsp+0x20], xmm13
0000796caede0584  lea rdi, [rsp]
0000796caede0588  mov esi, 0x00
0000796caede058d  mov rax, 0x56877063A530
0000796caede0597  call rax
0000796caede0599  movaps xmm12, [rsp]
0000796caede059e  add rsp, 0x30
0000796caede05a2  vmovaps xmm0, [rsp]
0000796caede05a7  vmovaps xmm1, [rsp+0x10]
0000796caede05ad  vmovaps xmm2, [rsp+0x20]
0000796caede05b3  vmovaps xmm3, [rsp+0x30]
0000796caede05b9  vmovaps xmm4, [rsp+0x40]
0000796caede05bf  vmovaps xmm5, [rsp+0x50]
0000796caede05c5  vmovaps xmm6, [rsp+0x60]
0000796caede05cb  vmovaps xmm7, [rsp+0x70]
0000796caede05d1  vmovaps xmm8, [rsp+0x80]
0000796caede05da  vmovaps xmm9, [rsp+0x90]
0000796caede05e3  vmovaps xmm10, [rsp+0xA0]
0000796caede05ec  vmovaps xmm11, [rsp+0xB0]
0000796caede05f5  vmovaps xmm13, [rsp+0xC0]
0000796caede05fe  vmovaps xmm14, [rsp+0xD0]
0000796caede0607  vmovaps xmm15, [rsp+0xE0]
0000796caede0610  add rsp, 0xF0
0000796caede0617  pop r11
0000796caede0619  pop r10
0000796caede061b  pop r9
0000796caede061d  pop r8
0000796caede061f  pop rsi
0000796caede0620  pop rdi
0000796caede0621  pop rdx
0000796caede0622  pop rcx
0000796caede0623  pop rax
0000796caede0624  add rsp, 0x08
0000796caede0628  jmp 0x0000796CAEDDC5F4
0000796caede062d  sub rsp, 0x08
0000796caede0631  push rax
0000796caede0632  push rcx
0000796caede0633  push rdx
0000796caede0634  push rdi
0000796caede0635  push rsi
0000796caede0636  push r8
0000796caede0638  push r9
0000796caede063a  push r10
0000796caede063c  push r11
0000796caede063e  sub rsp, 0xF0
0000796caede0645  vmovaps [rsp], xmm0
0000796caede064a  vmovaps [rsp+0x10], xmm1
0000796caede0650  vmovaps [rsp+0x20], xmm2
0000796caede0656  vmovaps [rsp+0x30], xmm3
0000796caede065c  vmovaps [rsp+0x40], xmm4
0000796caede0662  vmovaps [rsp+0x50], xmm5
0000796caede0668  vmovaps [rsp+0x60], xmm6
0000796caede066e  vmovaps [rsp+0x70], xmm7
0000796caede0674  vmovaps [rsp+0x80], xmm8
0000796caede067d  vmovaps [rsp+0x90], xmm9
0000796caede0686  vmovaps [rsp+0xA0], xmm10
0000796caede068f  vmovaps [rsp+0xB0], xmm11
0000796caede0698  vmovaps [rsp+0xC0], xmm12
0000796caede06a1  vmovaps [rsp+0xD0], xmm14
0000796caede06aa  vmovaps [rsp+0xE0], xmm15
0000796caede06b3  sub rsp, 0x30
0000796caede06b7  movaps [rsp], xmm13
0000796caede06bc  movaps [rsp+0x10], xmm15
0000796caede06c2  movaps [rsp+0x20], xmm8
0000796caede06c8  lea rdi, [rsp]
0000796caede06cc  mov esi, 0x00
0000796caede06d1  mov rax, 0x56877063A530
0000796caede06db  call rax
0000796caede06dd  movaps xmm13, [rsp]
0000796caede06e2  add rsp, 0x30
0000796caede06e6  vmovaps xmm0, [rsp]
0000796caede06eb  vmovaps xmm1, [rsp+0x10]
0000796caede06f1  vmovaps xmm2, [rsp+0x20]
0000796caede06f7  vmovaps xmm3, [rsp+0x30]
0000796caede06fd  vmovaps xmm4, [rsp+0x40]
0000796caede0703  vmovaps xmm5, [rsp+0x50]
0000796caede0709  vmovaps xmm6, [rsp+0x60]
0000796caede070f  vmovaps xmm7, [rsp+0x70]
0000796caede0715  vmovaps xmm8, [rsp+0x80]
0000796caede071e  vmovaps xmm9, [rsp+0x90]
0000796caede0727  vmovaps xmm10, [rsp+0xA0]
0000796caede0730  vmovaps xmm11, [rsp+0xB0]
0000796caede0739  vmovaps xmm12, [rsp+0xC0]
0000796caede0742  vmovaps xmm14, [rsp+0xD0]
0000796caede074b  vmovaps xmm15, [rsp+0xE0]
0000796caede0754  add rsp, 0xF0
0000796caede075b  pop r11
0000796caede075d  pop r10
0000796caede075f  pop r9
0000796caede0761  pop r8
0000796caede0763  pop rsi
0000796caede0764  pop rdi
0000796caede0765  pop rdx
0000796caede0766  pop rcx
0000796caede0767  pop rax
0000796caede0768  add rsp, 0x08
0000796caede076c  jmp 0x0000796CAEDDC60F
0000796caede0771  sub rsp, 0x08
0000796caede0775  push rax
0000796caede0776  push rcx
0000796caede0777  push rdx
0000796caede0778  push rdi
0000796caede0779  push rsi
0000796caede077a  push r8
0000796caede077c  push r9
0000796caede077e  push r10
0000796caede0780  push r11
0000796caede0782  sub rsp, 0xF0
0000796caede0789  vmovaps [rsp], xmm0
0000796caede078e  vmovaps [rsp+0x10], xmm1
0000796caede0794  vmovaps [rsp+0x20], xmm2
0000796caede079a  vmovaps [rsp+0x30], xmm3
0000796caede07a0  vmovaps [rsp+0x40], xmm4
0000796caede07a6  vmovaps [rsp+0x50], xmm5
0000796caede07ac  vmovaps [rsp+0x60], xmm6
0000796caede07b2  vmovaps [rsp+0x70], xmm7
0000796caede07b8  vmovaps [rsp+0x80], xmm9
0000796caede07c1  vmovaps [rsp+0x90], xmm10
0000796caede07ca  vmovaps [rsp+0xA0], xmm11
0000796caede07d3  vmovaps [rsp+0xB0], xmm12
0000796caede07dc  vmovaps [rsp+0xC0], xmm13
0000796caede07e5  vmovaps [rsp+0xD0], xmm14
0000796caede07ee  vmovaps [rsp+0xE0], xmm15
0000796caede07f7  sub rsp, 0x30
0000796caede07fb  movaps [rsp], xmm8
0000796caede0800  movaps [rsp+0x10], xmm15
0000796caede0806  movaps [rsp+0x20], xmm9
0000796caede080c  lea rdi, [rsp]
0000796caede0810  mov esi, 0x00
0000796caede0815  mov rax, 0x56877063A530
0000796caede081f  call rax
0000796caede0821  movaps xmm8, [rsp]
0000796caede0826  add rsp, 0x30
0000796caede082a  vmovaps xmm0, [rsp]
0000796caede082f  vmovaps xmm1, [rsp+0x10]
0000796caede0835  vmovaps xmm2, [rsp+0x20]
0000796caede083b  vmovaps xmm3, [rsp+0x30]
0000796caede0841  vmovaps xmm4, [rsp+0x40]
0000796caede0847  vmovaps xmm5, [rsp+0x50]
0000796caede084d  vmovaps xmm6, [rsp+0x60]
0000796caede0853  vmovaps xmm7, [rsp+0x70]
0000796caede0859  vmovaps xmm9, [rsp+0x80]
0000796caede0862  vmovaps xmm10, [rsp+0x90]
0000796caede086b  vmovaps xmm11, [rsp+0xA0]
0000796caede0874  vmovaps xmm12, [rsp+0xB0]
0000796caede087d  vmovaps xmm13, [rsp+0xC0]
0000796caede0886  vmovaps xmm14, [rsp+0xD0]
0000796caede088f  vmovaps xmm15, [rsp+0xE0]
0000796caede0898  add rsp, 0xF0
0000796caede089f  pop r11
0000796caede08a1  pop r10
0000796caede08a3  pop r9
0000796caede08a5  pop r8
0000796caede08a7  pop rsi
0000796caede08a8  pop rdi
0000796caede08a9  pop rdx
0000796caede08aa  pop rcx
0000796caede08ab  pop rax
0000796caede08ac  add rsp, 0x08
0000796caede08b0  jmp 0x0000796CAEDDC63D
0000796caede08b5  sub rsp, 0x08
0000796caede08b9  push rax
0000796caede08ba  push rcx
0000796caede08bb  push rdx
0000796caede08bc  push rdi
0000796caede08bd  push rsi
0000796caede08be  push r8
0000796caede08c0  push r9
0000796caede08c2  push r10
0000796caede08c4  push r11
0000796caede08c6  sub rsp, 0xF0
0000796caede08cd  vmovaps [rsp], xmm0
0000796caede08d2  vmovaps [rsp+0x10], xmm1
0000796caede08d8  vmovaps [rsp+0x20], xmm2
0000796caede08de  vmovaps [rsp+0x30], xmm3
0000796caede08e4  vmovaps [rsp+0x40], xmm4
0000796caede08ea  vmovaps [rsp+0x50], xmm5
0000796caede08f0  vmovaps [rsp+0x60], xmm6
0000796caede08f6  vmovaps [rsp+0x70], xmm7
0000796caede08fc  vmovaps [rsp+0x80], xmm8
0000796caede0905  vmovaps [rsp+0x90], xmm9
0000796caede090e  vmovaps [rsp+0xA0], xmm10
0000796caede0917  vmovaps [rsp+0xB0], xmm11
0000796caede0920  vmovaps [rsp+0xC0], xmm12
0000796caede0929  vmovaps [rsp+0xD0], xmm13
0000796caede0932  vmovaps [rsp+0xE0], xmm14
0000796caede093b  sub rsp, 0x30
0000796caede093f  movaps [rsp], xmm15
0000796caede0944  movaps [rsp+0x10], xmm11
0000796caede094a  movaps [rsp+0x20], xmm6
0000796caede094f  lea rdi, [rsp]
0000796caede0953  mov esi, 0x00
0000796caede0958  mov rax, 0x56877063A530
0000796caede0962  call rax
0000796caede0964  movaps xmm15, [rsp]
0000796caede0969  add rsp, 0x30
0000796caede096d  vmovaps xmm0, [rsp]
0000796caede0972  vmovaps xmm1, [rsp+0x10]
0000796caede0978  vmovaps xmm2, [rsp+0x20]
0000796caede097e  vmovaps xmm3, [rsp+0x30]
0000796caede0984  vmovaps xmm4, [rsp+0x40]
0000796caede098a  vmovaps xmm5, [rsp+0x50]
0000796caede0990  vmovaps xmm6, [rsp+0x60]
0000796caede0996  vmovaps xmm7, [rsp+0x70]
0000796caede099c  vmovaps xmm8, [rsp+0x80]
0000796caede09a5  vmovaps xmm9, [rsp+0x90]
0000796caede09ae  vmovaps xmm10, [rsp+0xA0]
0000796caede09b7  vmovaps xmm11, [rsp+0xB0]
0000796caede09c0  vmovaps xmm12, [rsp+0xC0]
0000796caede09c9  vmovaps xmm13, [rsp+0xD0]
0000796caede09d2  vmovaps xmm14, [rsp+0xE0]
0000796caede09db  add rsp, 0xF0
0000796caede09e2  pop r11
0000796caede09e4  pop r10
0000796caede09e6  pop r9
0000796caede09e8  pop r8
0000796caede09ea  pop rsi
0000796caede09eb  pop rdi
0000796caede09ec  pop rdx
0000796caede09ed  pop rcx
0000796caede09ee  pop rax
0000796caede09ef  add rsp, 0x08
0000796caede09f3  jmp 0x0000796CAEDDC658
0000796caede09f8  sub rsp, 0x08
0000796caede09fc  push rax
0000796caede09fd  push rcx
0000796caede09fe  push rdx
0000796caede09ff  push rdi
0000796caede0a00  push rsi
0000796caede0a01  push r8
0000796caede0a03  push r9
0000796caede0a05  push r10
0000796caede0a07  push r11
0000796caede0a09  sub rsp, 0xF0
0000796caede0a10  vmovaps [rsp], xmm0
0000796caede0a15  vmovaps [rsp+0x10], xmm1
0000796caede0a1b  vmovaps [rsp+0x20], xmm2
0000796caede0a21  vmovaps [rsp+0x30], xmm3
0000796caede0a27  vmovaps [rsp+0x40], xmm4
0000796caede0a2d  vmovaps [rsp+0x50], xmm5
0000796caede0a33  vmovaps [rsp+0x60], xmm6
0000796caede0a39  vmovaps [rsp+0x70], xmm8
0000796caede0a3f  vmovaps [rsp+0x80], xmm9
0000796caede0a48  vmovaps [rsp+0x90], xmm10
0000796caede0a51  vmovaps [rsp+0xA0], xmm11
0000796caede0a5a  vmovaps [rsp+0xB0], xmm12
0000796caede0a63  vmovaps [rsp+0xC0], xmm13
0000796caede0a6c  vmovaps [rsp+0xD0], xmm14
0000796caede0a75  vmovaps [rsp+0xE0], xmm15
0000796caede0a7e  sub rsp, 0x30
0000796caede0a82  movaps [rsp], xmm7
0000796caede0a86  movaps [rsp+0x10], xmm11
0000796caede0a8c  movaps [rsp+0x20], xmm9
0000796caede0a92  lea rdi, [rsp]
0000796caede0a96  mov esi, 0x00
0000796caede0a9b  mov rax, 0x56877063A530
0000796caede0aa5  call rax
0000796caede0aa7  movaps xmm7, [rsp]
0000796caede0aab  add rsp, 0x30
0000796caede0aaf  vmovaps xmm0, [rsp]
0000796caede0ab4  vmovaps xmm1, [rsp+0x10]
0000796caede0aba  vmovaps xmm2, [rsp+0x20]
0000796caede0ac0  vmovaps xmm3, [rsp+0x30]
0000796caede0ac6  vmovaps xmm4, [rsp+0x40]
0000796caede0acc  vmovaps xmm5, [rsp+0x50]
0000796caede0ad2  vmovaps xmm6, [rsp+0x60]
0000796caede0ad8  vmovaps xmm8, [rsp+0x70]
0000796caede0ade  vmovaps xmm9, [rsp+0x80]
0000796caede0ae7  vmovaps xmm10, [rsp+0x90]
0000796caede0af0  vmovaps xmm11, [rsp+0xA0]
0000796caede0af9  vmovaps xmm12, [rsp+0xB0]
0000796caede0b02  vmovaps xmm13, [rsp+0xC0]
0000796caede0b0b  vmovaps xmm14, [rsp+0xD0]
0000796caede0b14  vmovaps xmm15, [rsp+0xE0]
0000796caede0b1d  add rsp, 0xF0
0000796caede0b24  pop r11
0000796caede0b26  pop r10
0000796caede0b28  pop r9
0000796caede0b2a  pop r8
0000796caede0b2c  pop rsi
0000796caede0b2d  pop rdi
0000796caede0b2e  pop rdx
0000796caede0b2f  pop rcx
0000796caede0b30  pop rax
0000796caede0b31  add rsp, 0x08
0000796caede0b35  jmp 0x0000796CAEDDC685
0000796caede0b3a  sub rsp, 0x08
0000796caede0b3e  push rax
0000796caede0b3f  push rcx
0000796caede0b40  push rdx
0000796caede0b41  push rdi
0000796caede0b42  push rsi
0000796caede0b43  push r8
0000796caede0b45  push r9
0000796caede0b47  push r10
0000796caede0b49  push r11
0000796caede0b4b  sub rsp, 0xF0
0000796caede0b52  vmovaps [rsp], xmm0
0000796caede0b57  vmovaps [rsp+0x10], xmm1
0000796caede0b5d  vmovaps [rsp+0x20], xmm2
0000796caede0b63  vmovaps [rsp+0x30], xmm3
0000796caede0b69  vmovaps [rsp+0x40], xmm4
0000796caede0b6f  vmovaps [rsp+0x50], xmm5
0000796caede0b75  vmovaps [rsp+0x60], xmm6
0000796caede0b7b  vmovaps [rsp+0x70], xmm7
0000796caede0b81  vmovaps [rsp+0x80], xmm8
0000796caede0b8a  vmovaps [rsp+0x90], xmm9
0000796caede0b93  vmovaps [rsp+0xA0], xmm10
0000796caede0b9c  vmovaps [rsp+0xB0], xmm12
0000796caede0ba5  vmovaps [rsp+0xC0], xmm13
0000796caede0bae  vmovaps [rsp+0xD0], xmm14
0000796caede0bb7  vmovaps [rsp+0xE0], xmm15
0000796caede0bc0  sub rsp, 0x30
0000796caede0bc4  movaps [rsp], xmm11
0000796caede0bc9  movaps [rsp+0x10], xmm10
0000796caede0bcf  movaps [rsp+0x20], xmm14
0000796caede0bd5  lea rdi, [rsp]
0000796caede0bd9  mov esi, 0x00
0000796caede0bde  mov rax, 0x56877063A530
0000796caede0be8  call rax
0000796caede0bea  movaps xmm11, [rsp]
0000796caede0bef  add rsp, 0x30
0000796caede0bf3  vmovaps xmm0, [rsp]
0000796caede0bf8  vmovaps xmm1, [rsp+0x10]
0000796caede0bfe  vmovaps xmm2, [rsp+0x20]
0000796caede0c04  vmovaps xmm3, [rsp+0x30]
0000796caede0c0a  vmovaps xmm4, [rsp+0x40]
0000796caede0c10  vmovaps xmm5, [rsp+0x50]
0000796caede0c16  vmovaps xmm6, [rsp+0x60]
0000796caede0c1c  vmovaps xmm7, [rsp+0x70]
0000796caede0c22  vmovaps xmm8, [rsp+0x80]
0000796caede0c2b  vmovaps xmm9, [rsp+0x90]
0000796caede0c34  vmovaps xmm10, [rsp+0xA0]
0000796caede0c3d  vmovaps xmm12, [rsp+0xB0]
0000796caede0c46  vmovaps xmm13, [rsp+0xC0]
0000796caede0c4f  vmovaps xmm14, [rsp+0xD0]
0000796caede0c58  vmovaps xmm15, [rsp+0xE0]
0000796caede0c61  add rsp, 0xF0
0000796caede0c68  pop r11
0000796caede0c6a  pop r10
0000796caede0c6c  pop r9
0000796caede0c6e  pop r8
0000796caede0c70  pop rsi
0000796caede0c71  pop rdi
0000796caede0c72  pop rdx
0000796caede0c73  pop rcx
0000796caede0c74  pop rax
0000796caede0c75  add rsp, 0x08
0000796caede0c79  jmp 0x0000796CAEDDC6A0
0000796caede0c7e  call 0x0000796CAECC33A0
0000796caede0c83  jmp 0x0000796CAEDDC6AA
0000796caede0c88  sub rsp, 0x08
0000796caede0c8c  push rax
0000796caede0c8d  push rcx
0000796caede0c8e  push rdx
0000796caede0c8f  push rdi
0000796caede0c90  push rsi
0000796caede0c91  push r8
0000796caede0c93  push r9
0000796caede0c95  push r10
0000796caede0c97  push r11
0000796caede0c99  sub rsp, 0xF0
0000796caede0ca0  vmovaps [rsp], xmm0
0000796caede0ca5  vmovaps [rsp+0x10], xmm1
0000796caede0cab  vmovaps [rsp+0x20], xmm2
0000796caede0cb1  vmovaps [rsp+0x30], xmm3
0000796caede0cb7  vmovaps [rsp+0x40], xmm4
0000796caede0cbd  vmovaps [rsp+0x50], xmm5
0000796caede0cc3  vmovaps [rsp+0x60], xmm6
0000796caede0cc9  vmovaps [rsp+0x70], xmm7
0000796caede0ccf  vmovaps [rsp+0x80], xmm8
0000796caede0cd8  vmovaps [rsp+0x90], xmm9
0000796caede0ce1  vmovaps [rsp+0xA0], xmm11
0000796caede0cea  vmovaps [rsp+0xB0], xmm12
0000796caede0cf3  vmovaps [rsp+0xC0], xmm13
0000796caede0cfc  vmovaps [rsp+0xD0], xmm14
0000796caede0d05  vmovaps [rsp+0xE0], xmm15
0000796caede0d0e  sub rsp, 0x30
0000796caede0d12  movaps [rsp], xmm10
0000796caede0d17  movaps [rsp+0x10], xmm1
0000796caede0d1c  movaps [rsp+0x20], xmm12
0000796caede0d22  lea rdi, [rsp]
0000796caede0d26  mov esi, 0x00
0000796caede0d2b  mov rax, 0x56877063A530
0000796caede0d35  call rax
0000796caede0d37  movaps xmm10, [rsp]
0000796caede0d3c  add rsp, 0x30
0000796caede0d40  vmovaps xmm0, [rsp]
0000796caede0d45  vmovaps xmm1, [rsp+0x10]
0000796caede0d4b  vmovaps xmm2, [rsp+0x20]
0000796caede0d51  vmovaps xmm3, [rsp+0x30]
0000796caede0d57  vmovaps xmm4, [rsp+0x40]
0000796caede0d5d  vmovaps xmm5, [rsp+0x50]
0000796caede0d63  vmovaps xmm6, [rsp+0x60]
0000796caede0d69  vmovaps xmm7, [rsp+0x70]
0000796caede0d6f  vmovaps xmm8, [rsp+0x80]
0000796caede0d78  vmovaps xmm9, [rsp+0x90]
0000796caede0d81  vmovaps xmm11, [rsp+0xA0]
0000796caede0d8a  vmovaps xmm12, [rsp+0xB0]
0000796caede0d93  vmovaps xmm13, [rsp+0xC0]
0000796caede0d9c  vmovaps xmm14, [rsp+0xD0]
0000796caede0da5  vmovaps xmm15, [rsp+0xE0]
0000796caede0dae  add rsp, 0xF0
0000796caede0db5  pop r11
0000796caede0db7  pop r10
0000796caede0db9  pop r9
0000796caede0dbb  pop r8
0000796caede0dbd  pop rsi
0000796caede0dbe  pop rdi
0000796caede0dbf  pop rdx
0000796caede0dc0  pop rcx
0000796caede0dc1  pop rax
0000796caede0dc2  add rsp, 0x08
0000796caede0dc6  jmp 0x0000796CAEDDC6CD
0000796caede0dcb  sub rsp, 0x08
0000796caede0dcf  push rax
0000796caede0dd0  push rcx
0000796caede0dd1  push rdx
0000796caede0dd2  push rdi
0000796caede0dd3  push rsi
0000796caede0dd4  push r8
0000796caede0dd6  push r9
0000796caede0dd8  push r10
0000796caede0dda  push r11
0000796caede0ddc  sub rsp, 0xF0
0000796caede0de3  vmovaps [rsp], xmm0
0000796caede0de8  vmovaps [rsp+0x10], xmm1
0000796caede0dee  vmovaps [rsp+0x20], xmm2
0000796caede0df4  vmovaps [rsp+0x30], xmm3
0000796caede0dfa  vmovaps [rsp+0x40], xmm4
0000796caede0e00  vmovaps [rsp+0x50], xmm5
0000796caede0e06  vmovaps [rsp+0x60], xmm6
0000796caede0e0c  vmovaps [rsp+0x70], xmm7
0000796caede0e12  vmovaps [rsp+0x80], xmm8
0000796caede0e1b  vmovaps [rsp+0x90], xmm9
0000796caede0e24  vmovaps [rsp+0xA0], xmm10
0000796caede0e2d  vmovaps [rsp+0xB0], xmm11
0000796caede0e36  vmovaps [rsp+0xC0], xmm13
0000796caede0e3f  vmovaps [rsp+0xD0], xmm14
0000796caede0e48  vmovaps [rsp+0xE0], xmm15
0000796caede0e51  sub rsp, 0x30
0000796caede0e55  movaps [rsp], xmm12
0000796caede0e5a  movaps [rsp+0x10], xmm14
0000796caede0e60  movaps [rsp+0x20], xmm1
0000796caede0e65  lea rdi, [rsp]
0000796caede0e69  mov esi, 0x00
0000796caede0e6e  mov rax, 0x56877063A530
0000796caede0e78  call rax
0000796caede0e7a  movaps xmm12, [rsp]
0000796caede0e7f  add rsp, 0x30
0000796caede0e83  vmovaps xmm0, [rsp]
0000796caede0e88  vmovaps xmm1, [rsp+0x10]
0000796caede0e8e  vmovaps xmm2, [rsp+0x20]
0000796caede0e94  vmovaps xmm3, [rsp+0x30]
0000796caede0e9a  vmovaps xmm4, [rsp+0x40]
0000796caede0ea0  vmovaps xmm5, [rsp+0x50]
0000796caede0ea6  vmovaps xmm6, [rsp+0x60]
0000796caede0eac  vmovaps xmm7, [rsp+0x70]
0000796caede0eb2  vmovaps xmm8, [rsp+0x80]
0000796caede0ebb  vmovaps xmm9, [rsp+0x90]
0000796caede0ec4  vmovaps xmm10, [rsp+0xA0]
0000796caede0ecd  vmovaps xmm11, [rsp+0xB0]
0000796caede0ed6  vmovaps xmm13, [rsp+0xC0]
0000796caede0edf  vmovaps xmm14, [rsp+0xD0]
0000796caede0ee8  vmovaps xmm15, [rsp+0xE0]
0000796caede0ef1  add rsp, 0xF0
0000796caede0ef8  pop r11
0000796caede0efa  pop r10
0000796caede0efc  pop r9
0000796caede0efe  pop r8
0000796caede0f00  pop rsi
0000796caede0f01  pop rdi
0000796caede0f02  pop rdx
0000796caede0f03  pop rcx
0000796caede0f04  pop rax
0000796caede0f05  add rsp, 0x08
0000796caede0f09  jmp 0x0000796CAEDDC6FC
0000796caede0f0e  sub rsp, 0x08
0000796caede0f12  push rax
0000796caede0f13  push rcx
0000796caede0f14  push rdx
0000796caede0f15  push rdi
0000796caede0f16  push rsi
0000796caede0f17  push r8
0000796caede0f19  push r9
0000796caede0f1b  push r10
0000796caede0f1d  push r11
0000796caede0f1f  sub rsp, 0xF0
0000796caede0f26  vmovaps [rsp], xmm0
0000796caede0f2b  vmovaps [rsp+0x10], xmm1
0000796caede0f31  vmovaps [rsp+0x20], xmm2
0000796caede0f37  vmovaps [rsp+0x30], xmm3
0000796caede0f3d  vmovaps [rsp+0x40], xmm4
0000796caede0f43  vmovaps [rsp+0x50], xmm5
0000796caede0f49  vmovaps [rsp+0x60], xmm6
0000796caede0f4f  vmovaps [rsp+0x70], xmm7
0000796caede0f55  vmovaps [rsp+0x80], xmm8
0000796caede0f5e  vmovaps [rsp+0x90], xmm9
0000796caede0f67  vmovaps [rsp+0xA0], xmm10
0000796caede0f70  vmovaps [rsp+0xB0], xmm11
0000796caede0f79  vmovaps [rsp+0xC0], xmm12
0000796caede0f82  vmovaps [rsp+0xD0], xmm13
0000796caede0f8b  vmovaps [rsp+0xE0], xmm15
0000796caede0f94  sub rsp, 0x30
0000796caede0f98  movaps [rsp], xmm14
0000796caede0f9d  movaps [rsp+0x10], xmm9
0000796caede0fa3  movaps [rsp+0x20], xmm1
0000796caede0fa8  lea rdi, [rsp]
0000796caede0fac  mov esi, 0x00
0000796caede0fb1  mov rax, 0x56877063A530
0000796caede0fbb  call rax
0000796caede0fbd  movaps xmm14, [rsp]
0000796caede0fc2  add rsp, 0x30
0000796caede0fc6  vmovaps xmm0, [rsp]
0000796caede0fcb  vmovaps xmm1, [rsp+0x10]
0000796caede0fd1  vmovaps xmm2, [rsp+0x20]
0000796caede0fd7  vmovaps xmm3, [rsp+0x30]
0000796caede0fdd  vmovaps xmm4, [rsp+0x40]
0000796caede0fe3  vmovaps xmm5, [rsp+0x50]
0000796caede0fe9  vmovaps xmm6, [rsp+0x60]
0000796caede0fef  vmovaps xmm7, [rsp+0x70]
0000796caede0ff5  vmovaps xmm8, [rsp+0x80]
0000796caede0ffe  vmovaps xmm9, [rsp+0x90]
0000796caede1007  vmovaps xmm10, [rsp+0xA0]
0000796caede1010  vmovaps xmm11, [rsp+0xB0]
0000796caede1019  vmovaps xmm12, [rsp+0xC0]
0000796caede1022  vmovaps xmm13, [rsp+0xD0]
0000796caede102b  vmovaps xmm15, [rsp+0xE0]
0000796caede1034  add rsp, 0xF0
0000796caede103b  pop r11
0000796caede103d  pop r10
0000796caede103f  pop r9
0000796caede1041  pop r8
0000796caede1043  pop rsi
0000796caede1044  pop rdi
0000796caede1045  pop rdx
0000796caede1046  pop rcx
0000796caede1047  pop rax
0000796caede1048  add rsp, 0x08
0000796caede104c  jmp 0x0000796CAEDDC72B
0000796caede1051  sub rsp, 0x08
0000796caede1055  push rax
0000796caede1056  push rcx
0000796caede1057  push rdx
0000796caede1058  push rdi
0000796caede1059  push rsi
0000796caede105a  push r8
0000796caede105c  push r9
0000796caede105e  push r10
0000796caede1060  push r11
0000796caede1062  sub rsp, 0xF0
0000796caede1069  vmovaps [rsp], xmm0
0000796caede106e  vmovaps [rsp+0x10], xmm2
0000796caede1074  vmovaps [rsp+0x20], xmm3
0000796caede107a  vmovaps [rsp+0x30], xmm4
0000796caede1080  vmovaps [rsp+0x40], xmm5
0000796caede1086  vmovaps [rsp+0x50], xmm6
0000796caede108c  vmovaps [rsp+0x60], xmm7
0000796caede1092  vmovaps [rsp+0x70], xmm8
0000796caede1098  vmovaps [rsp+0x80], xmm9
0000796caede10a1  vmovaps [rsp+0x90], xmm10
0000796caede10aa  vmovaps [rsp+0xA0], xmm11
0000796caede10b3  vmovaps [rsp+0xB0], xmm12
0000796caede10bc  vmovaps [rsp+0xC0], xmm13
0000796caede10c5  vmovaps [rsp+0xD0], xmm14
0000796caede10ce  vmovaps [rsp+0xE0], xmm15
0000796caede10d7  sub rsp, 0x30
0000796caede10db  movaps [rsp], xmm1
0000796caede10df  movaps [rsp+0x10], xmm13
0000796caede10e5  movaps [rsp+0x20], xmm8
0000796caede10eb  lea rdi, [rsp]
0000796caede10ef  mov esi, 0x00
0000796caede10f4  mov rax, 0x56877063A530
0000796caede10fe  call rax
0000796caede1100  movaps xmm1, [rsp]
0000796caede1104  add rsp, 0x30
0000796caede1108  vmovaps xmm0, [rsp]
0000796caede110d  vmovaps xmm2, [rsp+0x10]
0000796caede1113  vmovaps xmm3, [rsp+0x20]
0000796caede1119  vmovaps xmm4, [rsp+0x30]
0000796caede111f  vmovaps xmm5, [rsp+0x40]
0000796caede1125  vmovaps xmm6, [rsp+0x50]
0000796caede112b  vmovaps xmm7, [rsp+0x60]
0000796caede1131  vmovaps xmm8, [rsp+0x70]
0000796caede1137  vmovaps xmm9, [rsp+0x80]
0000796caede1140  vmovaps xmm10, [rsp+0x90]
0000796caede1149  vmovaps xmm11, [rsp+0xA0]
0000796caede1152  vmovaps xmm12, [rsp+0xB0]
0000796caede115b  vmovaps xmm13, [rsp+0xC0]
0000796caede1164  vmovaps xmm14, [rsp+0xD0]
0000796caede116d  vmovaps xmm15, [rsp+0xE0]
0000796caede1176  add rsp, 0xF0
0000796caede117d  pop r11
0000796caede117f  pop r10
0000796caede1181  pop r9
0000796caede1183  pop r8
0000796caede1185  pop rsi
0000796caede1186  pop rdi
0000796caede1187  pop rdx
0000796caede1188  pop rcx
0000796caede1189  pop rax
0000796caede118a  add rsp, 0x08
0000796caede118e  jmp 0x0000796CAEDDC74D
0000796caede1193  call 0x0000796CAEC0C260
0000796caede1198  jmp 0x0000796CAEDDC75B
0000796caede119d  call 0x0000796CAECBD750
0000796caede11a2  jmp 0x0000796CAEDDC765
0000796caede11a7  sub rsp, 0x08
0000796caede11ab  push rax
0000796caede11ac  push rcx
0000796caede11ad  push rdx
0000796caede11ae  push rdi
0000796caede11af  push rsi
0000796caede11b0  push r8
0000796caede11b2  push r9
0000796caede11b4  push r10
0000796caede11b6  push r11
0000796caede11b8  sub rsp, 0xF0
0000796caede11bf  vmovaps [rsp], xmm0
0000796caede11c4  vmovaps [rsp+0x10], xmm1
0000796caede11ca  vmovaps [rsp+0x20], xmm2
0000796caede11d0  vmovaps [rsp+0x30], xmm3
0000796caede11d6  vmovaps [rsp+0x40], xmm4
0000796caede11dc  vmovaps [rsp+0x50], xmm5
0000796caede11e2  vmovaps [rsp+0x60], xmm6
0000796caede11e8  vmovaps [rsp+0x70], xmm7
0000796caede11ee  vmovaps [rsp+0x80], xmm9
0000796caede11f7  vmovaps [rsp+0x90], xmm10
0000796caede1200  vmovaps [rsp+0xA0], xmm11
0000796caede1209  vmovaps [rsp+0xB0], xmm12
0000796caede1212  vmovaps [rsp+0xC0], xmm13
0000796caede121b  vmovaps [rsp+0xD0], xmm14
0000796caede1224  vmovaps [rsp+0xE0], xmm15
0000796caede122d  sub rsp, 0x30
0000796caede1231  movaps [rsp], xmm8
0000796caede1236  movaps [rsp+0x10], xmm15
0000796caede123c  movaps [rsp+0x20], xmm7
0000796caede1241  lea rdi, [rsp]
0000796caede1245  mov esi, 0x00
0000796caede124a  mov rax, 0x56877063A530
0000796caede1254  call rax
0000796caede1256  movaps xmm8, [rsp]
0000796caede125b  add rsp, 0x30
0000796caede125f  vmovaps xmm0, [rsp]
0000796caede1264  vmovaps xmm1, [rsp+0x10]
0000796caede126a  vmovaps xmm2, [rsp+0x20]
0000796caede1270  vmovaps xmm3, [rsp+0x30]
0000796caede1276  vmovaps xmm4, [rsp+0x40]
0000796caede127c  vmovaps xmm5, [rsp+0x50]
0000796caede1282  vmovaps xmm6, [rsp+0x60]
0000796caede1288  vmovaps xmm7, [rsp+0x70]
0000796caede128e  vmovaps xmm9, [rsp+0x80]
0000796caede1297  vmovaps xmm10, [rsp+0x90]
0000796caede12a0  vmovaps xmm11, [rsp+0xA0]
0000796caede12a9  vmovaps xmm12, [rsp+0xB0]
0000796caede12b2  vmovaps xmm13, [rsp+0xC0]
0000796caede12bb  vmovaps xmm14, [rsp+0xD0]
0000796caede12c4  vmovaps xmm15, [rsp+0xE0]
0000796caede12cd  add rsp, 0xF0
0000796caede12d4  pop r11
0000796caede12d6  pop r10
0000796caede12d8  pop r9
0000796caede12da  pop r8
0000796caede12dc  pop rsi
0000796caede12dd  pop rdi
0000796caede12de  pop rdx
0000796caede12df  pop rcx
0000796caede12e0  pop rax
0000796caede12e1  add rsp, 0x08
0000796caede12e5  jmp 0x0000796CAEDDC787
0000796caede12ea  sub rsp, 0x08
0000796caede12ee  push rax
0000796caede12ef  push rcx
0000796caede12f0  push rdx
0000796caede12f1  push rdi
0000796caede12f2  push rsi
0000796caede12f3  push r8
0000796caede12f5  push r9
0000796caede12f7  push r10
0000796caede12f9  push r11
0000796caede12fb  sub rsp, 0xF0
0000796caede1302  vmovaps [rsp], xmm0
0000796caede1307  vmovaps [rsp+0x10], xmm1
0000796caede130d  vmovaps [rsp+0x20], xmm2
0000796caede1313  vmovaps [rsp+0x30], xmm3
0000796caede1319  vmovaps [rsp+0x40], xmm4
0000796caede131f  vmovaps [rsp+0x50], xmm5
0000796caede1325  vmovaps [rsp+0x60], xmm6
0000796caede132b  vmovaps [rsp+0x70], xmm8
0000796caede1331  vmovaps [rsp+0x80], xmm9
0000796caede133a  vmovaps [rsp+0x90], xmm10
0000796caede1343  vmovaps [rsp+0xA0], xmm11
0000796caede134c  vmovaps [rsp+0xB0], xmm12
0000796caede1355  vmovaps [rsp+0xC0], xmm13
0000796caede135e  vmovaps [rsp+0xD0], xmm14
0000796caede1367  vmovaps [rsp+0xE0], xmm15
0000796caede1370  sub rsp, 0x30
0000796caede1374  movaps [rsp], xmm7
0000796caede1378  movaps [rsp+0x10], xmm9
0000796caede137e  movaps [rsp+0x20], xmm15
0000796caede1384  lea rdi, [rsp]
0000796caede1388  mov esi, 0x00
0000796caede138d  mov rax, 0x56877063A530
0000796caede1397  call rax
0000796caede1399  movaps xmm7, [rsp]
0000796caede139d  add rsp, 0x30
0000796caede13a1  vmovaps xmm0, [rsp]
0000796caede13a6  vmovaps xmm1, [rsp+0x10]
0000796caede13ac  vmovaps xmm2, [rsp+0x20]
0000796caede13b2  vmovaps xmm3, [rsp+0x30]
0000796caede13b8  vmovaps xmm4, [rsp+0x40]
0000796caede13be  vmovaps xmm5, [rsp+0x50]
0000796caede13c4  vmovaps xmm6, [rsp+0x60]
0000796caede13ca  vmovaps xmm8, [rsp+0x70]
0000796caede13d0  vmovaps xmm9, [rsp+0x80]
0000796caede13d9  vmovaps xmm10, [rsp+0x90]
0000796caede13e2  vmovaps xmm11, [rsp+0xA0]
0000796caede13eb  vmovaps xmm12, [rsp+0xB0]
0000796caede13f4  vmovaps xmm13, [rsp+0xC0]
0000796caede13fd  vmovaps xmm14, [rsp+0xD0]
0000796caede1406  vmovaps xmm15, [rsp+0xE0]
0000796caede140f  add rsp, 0xF0
0000796caede1416  pop r11
0000796caede1418  pop r10
0000796caede141a  pop r9
0000796caede141c  pop r8
0000796caede141e  pop rsi
0000796caede141f  pop rdi
0000796caede1420  pop rdx
0000796caede1421  pop rcx
0000796caede1422  pop rax
0000796caede1423  add rsp, 0x08
0000796caede1427  jmp 0x0000796CAEDDC7B4
0000796caede142c  sub rsp, 0x08
0000796caede1430  push rax
0000796caede1431  push rcx
0000796caede1432  push rdx
0000796caede1433  push rdi
0000796caede1434  push rsi
0000796caede1435  push r8
0000796caede1437  push r9
0000796caede1439  push r10
0000796caede143b  push r11
0000796caede143d  sub rsp, 0xF0
0000796caede1444  vmovaps [rsp], xmm0
0000796caede1449  vmovaps [rsp+0x10], xmm1
0000796caede144f  vmovaps [rsp+0x20], xmm2
0000796caede1455  vmovaps [rsp+0x30], xmm3
0000796caede145b  vmovaps [rsp+0x40], xmm4
0000796caede1461  vmovaps [rsp+0x50], xmm5
0000796caede1467  vmovaps [rsp+0x60], xmm6
0000796caede146d  vmovaps [rsp+0x70], xmm7
0000796caede1473  vmovaps [rsp+0x80], xmm8
0000796caede147c  vmovaps [rsp+0x90], xmm10
0000796caede1485  vmovaps [rsp+0xA0], xmm11
0000796caede148e  vmovaps [rsp+0xB0], xmm12
0000796caede1497  vmovaps [rsp+0xC0], xmm13
0000796caede14a0  vmovaps [rsp+0xD0], xmm14
0000796caede14a9  vmovaps [rsp+0xE0], xmm15
0000796caede14b2  sub rsp, 0x30
0000796caede14b6  movaps [rsp], xmm9
0000796caede14bb  movaps [rsp+0x10], xmm13
0000796caede14c1  movaps [rsp+0x20], xmm15
0000796caede14c7  lea rdi, [rsp]
0000796caede14cb  mov esi, 0x00
0000796caede14d0  mov rax, 0x56877063A530
0000796caede14da  call rax
0000796caede14dc  movaps xmm9, [rsp]
0000796caede14e1  add rsp, 0x30
0000796caede14e5  vmovaps xmm0, [rsp]
0000796caede14ea  vmovaps xmm1, [rsp+0x10]
0000796caede14f0  vmovaps xmm2, [rsp+0x20]
0000796caede14f6  vmovaps xmm3, [rsp+0x30]
0000796caede14fc  vmovaps xmm4, [rsp+0x40]
0000796caede1502  vmovaps xmm5, [rsp+0x50]
0000796caede1508  vmovaps xmm6, [rsp+0x60]
0000796caede150e  vmovaps xmm7, [rsp+0x70]
0000796caede1514  vmovaps xmm8, [rsp+0x80]
0000796caede151d  vmovaps xmm10, [rsp+0x90]
0000796caede1526  vmovaps xmm11, [rsp+0xA0]
0000796caede152f  vmovaps xmm12, [rsp+0xB0]
0000796caede1538  vmovaps xmm13, [rsp+0xC0]
0000796caede1541  vmovaps xmm14, [rsp+0xD0]
0000796caede154a  vmovaps xmm15, [rsp+0xE0]
0000796caede1553  add rsp, 0xF0
0000796caede155a  pop r11
0000796caede155c  pop r10
0000796caede155e  pop r9
0000796caede1560  pop r8
0000796caede1562  pop rsi
0000796caede1563  pop rdi
0000796caede1564  pop rdx
0000796caede1565  pop rcx
0000796caede1566  pop rax
0000796caede1567  add rsp, 0x08
0000796caede156b  jmp 0x0000796CAEDDC7E2
0000796caede1570  sub rsp, 0x08
0000796caede1574  push rax
0000796caede1575  push rcx
0000796caede1576  push rdx
0000796caede1577  push rdi
0000796caede1578  push rsi
0000796caede1579  push r8
0000796caede157b  push r9
0000796caede157d  push r10
0000796caede157f  push r11
0000796caede1581  sub rsp, 0xF0
0000796caede1588  vmovaps [rsp], xmm0
0000796caede158d  vmovaps [rsp+0x10], xmm1
0000796caede1593  vmovaps [rsp+0x20], xmm2
0000796caede1599  vmovaps [rsp+0x30], xmm3
0000796caede159f  vmovaps [rsp+0x40], xmm4
0000796caede15a5  vmovaps [rsp+0x50], xmm5
0000796caede15ab  vmovaps [rsp+0x60], xmm6
0000796caede15b1  vmovaps [rsp+0x70], xmm7
0000796caede15b7  vmovaps [rsp+0x80], xmm8
0000796caede15c0  vmovaps [rsp+0x90], xmm9
0000796caede15c9  vmovaps [rsp+0xA0], xmm10
0000796caede15d2  vmovaps [rsp+0xB0], xmm11
0000796caede15db  vmovaps [rsp+0xC0], xmm12
0000796caede15e4  vmovaps [rsp+0xD0], xmm13
0000796caede15ed  vmovaps [rsp+0xE0], xmm14
0000796caede15f6  sub rsp, 0x30
0000796caede15fa  movaps [rsp], xmm15
0000796caede15ff  movaps [rsp+0x10], xmm11
0000796caede1605  movaps [rsp+0x20], xmm12
0000796caede160b  lea rdi, [rsp]
0000796caede160f  mov esi, 0x00
0000796caede1614  mov rax, 0x56877063A530
0000796caede161e  call rax
0000796caede1620  movaps xmm15, [rsp]
0000796caede1625  add rsp, 0x30
0000796caede1629  vmovaps xmm0, [rsp]
0000796caede162e  vmovaps xmm1, [rsp+0x10]
0000796caede1634  vmovaps xmm2, [rsp+0x20]
0000796caede163a  vmovaps xmm3, [rsp+0x30]
0000796caede1640  vmovaps xmm4, [rsp+0x40]
0000796caede1646  vmovaps xmm5, [rsp+0x50]
0000796caede164c  vmovaps xmm6, [rsp+0x60]
0000796caede1652  vmovaps xmm7, [rsp+0x70]
0000796caede1658  vmovaps xmm8, [rsp+0x80]
0000796caede1661  vmovaps xmm9, [rsp+0x90]
0000796caede166a  vmovaps xmm10, [rsp+0xA0]
0000796caede1673  vmovaps xmm11, [rsp+0xB0]
0000796caede167c  vmovaps xmm12, [rsp+0xC0]
0000796caede1685  vmovaps xmm13, [rsp+0xD0]
0000796caede168e  vmovaps xmm14, [rsp+0xE0]
0000796caede1697  add rsp, 0xF0
0000796caede169e  pop r11
0000796caede16a0  pop r10
0000796caede16a2  pop r9
0000796caede16a4  pop r8
0000796caede16a6  pop rsi
0000796caede16a7  pop rdi
0000796caede16a8  pop rdx
0000796caede16a9  pop rcx
0000796caede16aa  pop rax
0000796caede16ab  add rsp, 0x08
0000796caede16af  jmp 0x0000796CAEDDC7FD
0000796caede16b4  sub rsp, 0x08
0000796caede16b8  push rax
0000796caede16b9  push rcx
0000796caede16ba  push rdx
0000796caede16bb  push rdi
0000796caede16bc  push rsi
0000796caede16bd  push r8
0000796caede16bf  push r9
0000796caede16c1  push r10
0000796caede16c3  push r11
0000796caede16c5  sub rsp, 0xF0
0000796caede16cc  vmovaps [rsp], xmm0
0000796caede16d1  vmovaps [rsp+0x10], xmm1
0000796caede16d7  vmovaps [rsp+0x20], xmm2
0000796caede16dd  vmovaps [rsp+0x30], xmm3
0000796caede16e3  vmovaps [rsp+0x40], xmm4
0000796caede16e9  vmovaps [rsp+0x50], xmm5
0000796caede16ef  vmovaps [rsp+0x60], xmm6
0000796caede16f5  vmovaps [rsp+0x70], xmm7
0000796caede16fb  vmovaps [rsp+0x80], xmm8
0000796caede1704  vmovaps [rsp+0x90], xmm9
0000796caede170d  vmovaps [rsp+0xA0], xmm10
0000796caede1716  vmovaps [rsp+0xB0], xmm11
0000796caede171f  vmovaps [rsp+0xC0], xmm12
0000796caede1728  vmovaps [rsp+0xD0], xmm14
0000796caede1731  vmovaps [rsp+0xE0], xmm15
0000796caede173a  sub rsp, 0x30
0000796caede173e  movaps [rsp], xmm13
0000796caede1743  movaps [rsp+0x10], xmm10
0000796caede1749  movaps [rsp+0x20], xmm14
0000796caede174f  lea rdi, [rsp]
0000796caede1753  mov esi, 0x00
0000796caede1758  mov rax, 0x56877063A530
0000796caede1762  call rax
0000796caede1764  movaps xmm13, [rsp]
0000796caede1769  add rsp, 0x30
0000796caede176d  vmovaps xmm0, [rsp]
0000796caede1772  vmovaps xmm1, [rsp+0x10]
0000796caede1778  vmovaps xmm2, [rsp+0x20]
0000796caede177e  vmovaps xmm3, [rsp+0x30]
0000796caede1784  vmovaps xmm4, [rsp+0x40]
0000796caede178a  vmovaps xmm5, [rsp+0x50]
0000796caede1790  vmovaps xmm6, [rsp+0x60]
0000796caede1796  vmovaps xmm7, [rsp+0x70]
0000796caede179c  vmovaps xmm8, [rsp+0x80]
0000796caede17a5  vmovaps xmm9, [rsp+0x90]
0000796caede17ae  vmovaps xmm10, [rsp+0xA0]
0000796caede17b7  vmovaps xmm11, [rsp+0xB0]
0000796caede17c0  vmovaps xmm12, [rsp+0xC0]
0000796caede17c9  vmovaps xmm14, [rsp+0xD0]
0000796caede17d2  vmovaps xmm15, [rsp+0xE0]
0000796caede17db  add rsp, 0xF0
0000796caede17e2  pop r11
0000796caede17e4  pop r10
0000796caede17e6  pop r9
0000796caede17e8  pop r8
0000796caede17ea  pop rsi
0000796caede17eb  pop rdi
0000796caede17ec  pop rdx
0000796caede17ed  pop rcx
0000796caede17ee  pop rax
0000796caede17ef  add rsp, 0x08
0000796caede17f3  jmp 0x0000796CAEDDC820
0000796caede17f8  sub rsp, 0x08
0000796caede17fc  push rax
0000796caede17fd  push rcx
0000796caede17fe  push rdx
0000796caede17ff  push rdi
0000796caede1800  push rsi
0000796caede1801  push r8
0000796caede1803  push r9
0000796caede1805  push r10
0000796caede1807  push r11
0000796caede1809  sub rsp, 0xF0
0000796caede1810  vmovaps [rsp], xmm0
0000796caede1815  vmovaps [rsp+0x10], xmm1
0000796caede181b  vmovaps [rsp+0x20], xmm2
0000796caede1821  vmovaps [rsp+0x30], xmm3
0000796caede1827  vmovaps [rsp+0x40], xmm4
0000796caede182d  vmovaps [rsp+0x50], xmm5
0000796caede1833  vmovaps [rsp+0x60], xmm6
0000796caede1839  vmovaps [rsp+0x70], xmm7
0000796caede183f  vmovaps [rsp+0x80], xmm8
0000796caede1848  vmovaps [rsp+0x90], xmm9
0000796caede1851  vmovaps [rsp+0xA0], xmm10
0000796caede185a  vmovaps [rsp+0xB0], xmm11
0000796caede1863  vmovaps [rsp+0xC0], xmm12
0000796caede186c  vmovaps [rsp+0xD0], xmm13
0000796caede1875  vmovaps [rsp+0xE0], xmm15
0000796caede187e  sub rsp, 0x30
0000796caede1882  movaps [rsp], xmm14
0000796caede1887  movaps [rsp+0x10], xmm1
0000796caede188c  movaps [rsp+0x20], xmm7
0000796caede1891  lea rdi, [rsp]
0000796caede1895  mov esi, 0x00
0000796caede189a  mov rax, 0x56877063A530
0000796caede18a4  call rax
0000796caede18a6  movaps xmm14, [rsp]
0000796caede18ab  add rsp, 0x30
0000796caede18af  vmovaps xmm0, [rsp]
0000796caede18b4  vmovaps xmm1, [rsp+0x10]
0000796caede18ba  vmovaps xmm2, [rsp+0x20]
0000796caede18c0  vmovaps xmm3, [rsp+0x30]
0000796caede18c6  vmovaps xmm4, [rsp+0x40]
0000796caede18cc  vmovaps xmm5, [rsp+0x50]
0000796caede18d2  vmovaps xmm6, [rsp+0x60]
0000796caede18d8  vmovaps xmm7, [rsp+0x70]
0000796caede18de  vmovaps xmm8, [rsp+0x80]
0000796caede18e7  vmovaps xmm9, [rsp+0x90]
0000796caede18f0  vmovaps xmm10, [rsp+0xA0]
0000796caede18f9  vmovaps xmm11, [rsp+0xB0]
0000796caede1902  vmovaps xmm12, [rsp+0xC0]
0000796caede190b  vmovaps xmm13, [rsp+0xD0]
0000796caede1914  vmovaps xmm15, [rsp+0xE0]
0000796caede191d  add rsp, 0xF0
0000796caede1924  pop r11
0000796caede1926  pop r10
0000796caede1928  pop r9
0000796caede192a  pop r8
0000796caede192c  pop rsi
0000796caede192d  pop rdi
0000796caede192e  pop rdx
0000796caede192f  pop rcx
0000796caede1930  pop rax
0000796caede1931  add rsp, 0x08
0000796caede1935  jmp 0x0000796CAEDDC843
0000796caede193a  sub rsp, 0x08
0000796caede193e  push rax
0000796caede193f  push rcx
0000796caede1940  push rdx
0000796caede1941  push rdi
0000796caede1942  push rsi
0000796caede1943  push r8
0000796caede1945  push r9
0000796caede1947  push r10
0000796caede1949  push r11
0000796caede194b  sub rsp, 0xF0
0000796caede1952  vmovaps [rsp], xmm0
0000796caede1957  vmovaps [rsp+0x10], xmm2
0000796caede195d  vmovaps [rsp+0x20], xmm3
0000796caede1963  vmovaps [rsp+0x30], xmm4
0000796caede1969  vmovaps [rsp+0x40], xmm5
0000796caede196f  vmovaps [rsp+0x50], xmm6
0000796caede1975  vmovaps [rsp+0x60], xmm7
0000796caede197b  vmovaps [rsp+0x70], xmm8
0000796caede1981  vmovaps [rsp+0x80], xmm9
0000796caede198a  vmovaps [rsp+0x90], xmm10
0000796caede1993  vmovaps [rsp+0xA0], xmm11
0000796caede199c  vmovaps [rsp+0xB0], xmm12
0000796caede19a5  vmovaps [rsp+0xC0], xmm13
0000796caede19ae  vmovaps [rsp+0xD0], xmm14
0000796caede19b7  vmovaps [rsp+0xE0], xmm15
0000796caede19c0  sub rsp, 0x30
0000796caede19c4  movaps [rsp], xmm1
0000796caede19c8  movaps [rsp+0x10], xmm8
0000796caede19ce  movaps [rsp+0x20], xmm9
0000796caede19d4  lea rdi, [rsp]
0000796caede19d8  mov esi, 0x00
0000796caede19dd  mov rax, 0x56877063A530
0000796caede19e7  call rax
0000796caede19e9  movaps xmm1, [rsp]
0000796caede19ed  add rsp, 0x30
0000796caede19f1  vmovaps xmm0, [rsp]
0000796caede19f6  vmovaps xmm2, [rsp+0x10]
0000796caede19fc  vmovaps xmm3, [rsp+0x20]
0000796caede1a02  vmovaps xmm4, [rsp+0x30]
0000796caede1a08  vmovaps xmm5, [rsp+0x40]
0000796caede1a0e  vmovaps xmm6, [rsp+0x50]
0000796caede1a14  vmovaps xmm7, [rsp+0x60]
0000796caede1a1a  vmovaps xmm8, [rsp+0x70]
0000796caede1a20  vmovaps xmm9, [rsp+0x80]
0000796caede1a29  vmovaps xmm10, [rsp+0x90]
0000796caede1a32  vmovaps xmm11, [rsp+0xA0]
0000796caede1a3b  vmovaps xmm12, [rsp+0xB0]
0000796caede1a44  vmovaps xmm13, [rsp+0xC0]
0000796caede1a4d  vmovaps xmm14, [rsp+0xD0]
0000796caede1a56  vmovaps xmm15, [rsp+0xE0]
0000796caede1a5f  add rsp, 0xF0
0000796caede1a66  pop r11
0000796caede1a68  pop r10
0000796caede1a6a  pop r9
0000796caede1a6c  pop r8
0000796caede1a6e  pop rsi
0000796caede1a6f  pop rdi
0000796caede1a70  pop rdx
0000796caede1a71  pop rcx
0000796caede1a72  pop rax
0000796caede1a73  add rsp, 0x08
0000796caede1a77  jmp 0x0000796CAEDDC865
0000796caede1a7c  call 0x0000796CAECE5940
0000796caede1a81  jmp 0x0000796CAEDDC873
0000796caede1a86  call 0x0000796CAEC0C380
0000796caede1a8b  jmp 0x0000796CAEDDC87D
0000796caede1a90  call 0x0000796CAEC0D600
0000796caede1a95  jmp 0x0000796CAEDDC887
0000796caede1a9a  call 0x0000796CAEBFF540
0000796caede1a9f  jmp 0x0000796CAEDDC891
0000796caede1aa4  int3
0000796caede1aa5  nop [rax+rax*1], ax
0000796caede1aae  nop
0000796caede1ab0  mov rax, [r15+0xF8]
0000796caede1ab7  lea r14, [rax+0x140]
0000796caede1abe  mov r12, [r13+r14*1]
0000796caede1ac3  mov [r15+0xE8], r12
0000796caede1aca  lea r14, [rax+0x130]
0000796caede1ad1  mov r12, [r13+r14*1]
0000796caede1ad6  lea r14, [rax+0x138]
0000796caede1add  mov r11, [r13+r14*1]
0000796caede1ae2  movq xmm1, r12
0000796caede1ae7  movq xmm15, r11
0000796caede1aec  movq xmm1, xmm1
0000796caede1af0  movq xmm1, xmm1
0000796caede1af4  movaps [r15+0x1A0], xmm1
0000796caede1afc  movq xmm15, xmm15
0000796caede1b01  movq xmm15, xmm15
0000796caede1b06  movaps [r15+0x190], xmm15
0000796caede1b0e  lea r14, [rax+0x120]
0000796caede1b15  mov r12, [r13+r14*1]
0000796caede1b1a  lea r14, [rax+0x128]
0000796caede1b21  mov r11, [r13+r14*1]
0000796caede1b26  movq xmm1, r12
0000796caede1b2b  movq xmm15, r11
0000796caede1b30  movq xmm1, xmm1
0000796caede1b34  movq xmm1, xmm1
0000796caede1b38  movaps [r15+0x1C0], xmm1
0000796caede1b40  movq xmm15, xmm15
0000796caede1b45  movq xmm15, xmm15
0000796caede1b4a  movaps [r15+0x1B0], xmm15
0000796caede1b52  lea r14, [rax+0x110]
0000796caede1b59  mov r12, [r13+r14*1]
0000796caede1b5e  lea r14, [rax+0x118]
0000796caede1b65  mov r11, [r13+r14*1]
0000796caede1b6a  movq xmm1, r12
0000796caede1b6f  movq xmm15, r11
0000796caede1b74  movq xmm1, xmm1
0000796caede1b78  movq xmm1, xmm1
0000796caede1b7c  movaps [r15+0x1E0], xmm1
0000796caede1b84  movq xmm15, xmm15
0000796caede1b89  movq xmm15, xmm15
0000796caede1b8e  movaps [r15+0x1D0], xmm15
0000796caede1b96  lea r14, [rax+0x100]
0000796caede1b9d  mov r12, [r13+r14*1]
0000796caede1ba2  lea r14, [rax+0x108]
0000796caede1ba9  mov r11, [r13+r14*1]
0000796caede1bae  movq xmm1, r12
0000796caede1bb3  movq xmm15, r11
0000796caede1bb8  movq xmm1, xmm1
0000796caede1bbc  movq xmm1, xmm1
0000796caede1bc0  movaps [r15+0x200], xmm1
0000796caede1bc8  movq xmm15, xmm15
0000796caede1bcd  movq xmm15, xmm15
0000796caede1bd2  movaps [r15+0x1F0], xmm15
0000796caede1bda  mov qword ptr [r15+0x40], 0x430000
0000796caede1be2  mov r14d, 0x430510
0000796caede1be8  mov r12, [r13+r14*1]
0000796caede1bed  movq xmm1, r12
0000796caede1bf2  lea r14, [rax+0x150]
0000796caede1bf9  mov [r15+0xF8], r14
0000796caede1c00  mov rax, [r15+0x50]
0000796caede1c04  movups xmm15, [r13+rax*1]
0000796caede1c0a  movaps [r15+0x120], xmm15
0000796caede1c12  mov qword ptr [r15+0x48], 0x10
0000796caede1c1a  xor eax, eax
0000796caede1c1c  mov r14d, 0x10
0000796caede1c22  mov r12d, 0x200
0000796caede1c28  cmp r14, r12
0000796caede1c2b  cmc
0000796caede1c2c  lahf
0000796caede1c2d  seto al
0000796caede1c30  mov [r15+0x108], eax
0000796caede1c37  pextrq rax, xmm15, 0x01
0000796caede1c3e  movq xmm14, rax
0000796caede1c43  movaps [r15+0x130], xmm14
0000796caede1c4b  movq rax, xmm1
0000796caede1c50  movq r14, xmm15
0000796caede1c55  vmovq xmm1, rax
0000796caede1c5a  vmovq xmm15, r14
0000796caede1c5f  movaps xmm13, xmm1
0000796caede1c63  addsd xmm13, xmm15
0000796caede1c68  ucomisd xmm13, xmm13
0000796caede1c6d  jp 0x0000796CAEDE1D86
0000796caede1c73  movq xmm13, xmm13
0000796caede1c78  movq rax, xmm13
0000796caede1c7d  movq r14, xmm14
0000796caede1c82  vmovq xmm1, rax
0000796caede1c87  vmovq xmm15, r14
0000796caede1c8c  movaps xmm14, xmm1
0000796caede1c90  addsd xmm14, xmm15
0000796caede1c95  ucomisd xmm14, xmm14
0000796caede1c9a  jp 0x0000796CAEDE1DCE
0000796caede1ca0  movq xmm14, xmm14
0000796caede1ca5  movaps [r15+0x110], xmm14
0000796caede1cad  mov eax, [r15+0x108]
0000796caede1cb4  sahf
0000796caede1cb5  jnz 0x0000796CAEDE1CE7
0000796caede1cb7  cmp dword ptr [r15+0x318], 0x00
0000796caede1cbf  jz 0x0000796CAEDE1FE0
0000796caede1cc5  nop [rax+rax*1], ax
0000796caede1cce  nop [rax+rax*1], eax
0000796caede1cd6  mov eax, 0x410490
0000796caede1cdb  mov [r15+0x100], rax
0000796caede1ce2  jmp 0x0000796CAEBFE110
0000796caede1ce7  cmp dword ptr [r15+0x318], 0x00
0000796caede1cef  jz 0x0000796CAEDE1E20
0000796caede1cf5  nop [rax+rax*1], ax
0000796caede1cfe  nop [rax+rax*1], eax
0000796caede1d06  mov eax, 0x410474
0000796caede1d0b  mov [r15+0x100], rax
0000796caede1d12  jmp 0x0000796CAEBFE110
0000796caede1d17  int3
0000796caede1d18  call 0x0000796CAECE27E0
0000796caede1d1d  jmp 0x0000796CAEDE1AC3
0000796caede1d22  call 0x0000796CAECE27E0
0000796caede1d27  jmp 0x0000796CAEDE1AD6
0000796caede1d2c  call 0x0000796CAECE1570
0000796caede1d31  jmp 0x0000796CAEDE1AE2
0000796caede1d36  call 0x0000796CAECE27E0
0000796caede1d3b  jmp 0x0000796CAEDE1B1A
0000796caede1d40  call 0x0000796CAECE1570
0000796caede1d45  jmp 0x0000796CAEDE1B26
0000796caede1d4a  call 0x0000796CAECE27E0
0000796caede1d4f  jmp 0x0000796CAEDE1B5E
0000796caede1d54  call 0x0000796CAECE1570
0000796caede1d59  jmp 0x0000796CAEDE1B6A
0000796caede1d5e  call 0x0000796CAECE27E0
0000796caede1d63  jmp 0x0000796CAEDE1BA2
0000796caede1d68  call 0x0000796CAECE1570
0000796caede1d6d  jmp 0x0000796CAEDE1BAE
0000796caede1d72  call 0x0000796CAECE27E0
0000796caede1d77  jmp 0x0000796CAEDE1BED
0000796caede1d7c  call 0x0000796CAEC0E760
0000796caede1d81  jmp 0x0000796CAEDE1C0A
0000796caede1d86  ucomisd xmm1, xmm15
0000796caede1d8b  jp 0x0000796CAEDE1D9A
0000796caede1d8d  movaps xmm13, [0x0000796CAE9FE060]
0000796caede1d95  jmp 0x0000796CAEDE1C73
0000796caede1d9a  vxorps xmm0, xmm1, xmm15
0000796caede1d9f  pextrw eax, xmm0, 0x03
0000796caede1da4  and eax, 0x7FF8
0000796caede1da9  cmp eax, 0x08
0000796caede1dac  jnz 0x0000796CAEDE1C73
0000796caede1db2  movq rax, xmm15
0000796caede1db7  shl rax, 0x0D
0000796caede1dbb  jbe 0x0000796CAEDE1C73
0000796caede1dc1  vorps xmm13, xmm15, [0x0000796CAE9FE070]
0000796caede1dc9  jmp 0x0000796CAEDE1C73
0000796caede1dce  ucomisd xmm1, xmm15
0000796caede1dd3  jp 0x0000796CAEDE1DE2
0000796caede1dd5  movaps xmm14, [0x0000796CAE9FE060]
0000796caede1ddd  jmp 0x0000796CAEDE1CA0
0000796caede1de2  vxorps xmm0, xmm1, xmm15
0000796caede1de7  pextrw eax, xmm0, 0x03
0000796caede1dec  and eax, 0x7FF8
0000796caede1df1  cmp eax, 0x08
0000796caede1df4  jnz 0x0000796CAEDE1CA0
0000796caede1dfa  movq rax, xmm15
0000796caede1dff  shl rax, 0x0D
0000796caede1e03  jbe 0x0000796CAEDE1CA0
0000796caede1e09  vorps xmm14, xmm15, [0x0000796CAE9FE070]
0000796caede1e11  jmp 0x0000796CAEDE1CA0
0000796caede1e16  int3
0000796caede1e17  nop [rax+rax*1], ax
0000796caede1e20  mov rax, [r15+0x48]
0000796caede1e24  mov r14, [r15+0x50]
0000796caede1e28  lea r12, [r14+rax*1]
0000796caede1e2c  movups xmm1, [r13+r12*1]
0000796caede1e32  movaps [r15+0x120], xmm1
0000796caede1e3a  lea r14, [rax+0x10]
0000796caede1e3e  mov [r15+0x48], r14
0000796caede1e42  xor eax, eax
0000796caede1e44  mov r12d, 0x200
0000796caede1e4a  cmp r14, r12
0000796caede1e4d  cmc
0000796caede1e4e  lahf
0000796caede1e4f  seto al
0000796caede1e52  mov [r15+0x108], eax
0000796caede1e59  pextrq rax, xmm1, 0x01
0000796caede1e60  movq xmm15, rax
0000796caede1e65  movaps [r15+0x130], xmm15
0000796caede1e6d  movaps xmm14, [r15+0x110]
0000796caede1e75  movq rax, xmm14
0000796caede1e7a  movq r14, xmm1
0000796caede1e7f  vmovq xmm1, rax
0000796caede1e84  vmovq xmm14, r14
0000796caede1e89  movaps xmm13, xmm1
0000796caede1e8d  addsd xmm13, xmm14
0000796caede1e92  ucomisd xmm13, xmm13
0000796caede1e97  jp 0x0000796CAEDE1F4C
0000796caede1e9d  movq xmm13, xmm13
0000796caede1ea2  movq rax, xmm13
0000796caede1ea7  movq r14, xmm15
0000796caede1eac  vmovq xmm1, rax
0000796caede1eb1  vmovq xmm15, r14
0000796caede1eb6  movaps xmm14, xmm1
0000796caede1eba  addsd xmm14, xmm15
0000796caede1ebf  ucomisd xmm14, xmm14
0000796caede1ec4  jp 0x0000796CAEDE1F94
0000796caede1eca  movq xmm14, xmm14
0000796caede1ecf  movaps [r15+0x110], xmm14
0000796caede1ed7  mov eax, [r15+0x108]
0000796caede1ede  sahf
0000796caede1edf  jnz 0x0000796CAEDE1F11
0000796caede1ee1  cmp dword ptr [r15+0x318], 0x00
0000796caede1ee9  jz 0x0000796CAEDE1FE0
0000796caede1eef  nop [rax+rax*1], ax
0000796caede1ef8  nop [rax+rax*1], eax
0000796caede1f00  mov eax, 0x410490
0000796caede1f05  mov [r15+0x100], rax
0000796caede1f0c  jmp 0x0000796CAEBFE110
0000796caede1f11  cmp dword ptr [r15+0x318], 0x00
0000796caede1f19  jz 0x0000796CAEDE1E20
0000796caede1f1f  nop [rax+rax*1], ax
0000796caede1f28  nop [rax+rax*1], eax
0000796caede1f30  mov eax, 0x410474
0000796caede1f35  mov [r15+0x100], rax
0000796caede1f3c  jmp 0x0000796CAEBFE110
0000796caede1f41  int3
0000796caede1f42  call 0x0000796CAECB52F0
0000796caede1f47  jmp 0x0000796CAEDE1E32
0000796caede1f4c  ucomisd xmm1, xmm14
0000796caede1f51  jp 0x0000796CAEDE1F60
0000796caede1f53  movaps xmm13, [0x0000796CAE9FE060]
0000796caede1f5b  jmp 0x0000796CAEDE1E9D
0000796caede1f60  vxorps xmm0, xmm1, xmm14
0000796caede1f65  pextrw eax, xmm0, 0x03
0000796caede1f6a  and eax, 0x7FF8
0000796caede1f6f  cmp eax, 0x08
0000796caede1f72  jnz 0x0000796CAEDE1E9D
0000796caede1f78  movq rax, xmm14
0000796caede1f7d  shl rax, 0x0D
0000796caede1f81  jbe 0x0000796CAEDE1E9D
0000796caede1f87  vorps xmm13, xmm14, [0x0000796CAE9FE070]
0000796caede1f8f  jmp 0x0000796CAEDE1E9D
0000796caede1f94  ucomisd xmm1, xmm15
0000796caede1f99  jp 0x0000796CAEDE1FA8
0000796caede1f9b  movaps xmm14, [0x0000796CAE9FE060]
0000796caede1fa3  jmp 0x0000796CAEDE1ECA
0000796caede1fa8  vxorps xmm0, xmm1, xmm15
0000796caede1fad  pextrw eax, xmm0, 0x03
0000796caede1fb2  and eax, 0x7FF8
0000796caede1fb7  cmp eax, 0x08
0000796caede1fba  jnz 0x0000796CAEDE1ECA
0000796caede1fc0  movq rax, xmm15
0000796caede1fc5  shl rax, 0x0D
0000796caede1fc9  jbe 0x0000796CAEDE1ECA
0000796caede1fcf  vorps xmm14, xmm15, [0x0000796CAE9FE070]
0000796caede1fd7  jmp 0x0000796CAEDE1ECA
0000796caede1fdc  int3
0000796caede1fdd  nop [rax], eax
0000796caede1fe0  mov rax, [r15+0x40]
0000796caede1fe4  lea r14, [rax+0x510]
0000796caede1feb  movaps xmm1, [r15+0x110]
0000796caede1ff3  movq rax, xmm1
0000796caede1ff8  mov [r13+r14*1], rax
0000796caede1ffd  mov rax, [r15+0xF0]
0000796caede2004  mov [r15+0x100], rax
0000796caede200b  jmp 0x0000796CAEDCE5C0
0000796caede2010  int3
0000796caede2011  call 0x0000796CAECD5EB0
0000796caede2016  jmp 0x0000796CAEDE1FFD
0000796caede201b  int3
0000796caede201c  nop [rax], eax
0000796caede2020  mov qword ptr [r15+0x100], 0x04
0000796caede202b  mov esi, 0x00
0000796caede2030  mov edx, 0x09
0000796caede2035  mov rdi, 0x7FFFC53940C0
0000796caede203f  mov rax, 0x5687704CD970
0000796caede2049  call rax
0000796caede204b  cmp dword ptr [r15+0x318], 0x00
0000796caede2053  jnz 0x0000796CAEBFE110
0000796caede2059  jmp 0x0000796CAEBFE0A0
0000796caede205e  int3
0000796caede205f  int3
