00007dd8c99ce69b  nop [rax+rax*1], eax
00007dd8c99ce6a0  vmovaps xmm1, [0x00007DD8C95FE010]
00007dd8c99ce6a8  movq xmm1, xmm1
00007dd8c99ce6ac  movaps [r15+0x110], xmm1
00007dd8c99ce6b4  vmovaps xmm1, [0x00007DD8C95FE020]
00007dd8c99ce6bc  movq xmm1, xmm1
00007dd8c99ce6c0  movaps [r15+0x120], xmm1
00007dd8c99ce6c8  mov eax, 0x4204C0
00007dd8c99ce6cd  mov r14, [r13+rax*1]
00007dd8c99ce6d2  movq xmm1, r14
00007dd8c99ce6d7  movaps [r15+0x130], xmm1
00007dd8c99ce6df  vmovaps xmm1, [0x00007DD8C95FE030]
00007dd8c99ce6e7  vpbroadcastq xmm1, xmm1
00007dd8c99ce6ec  movaps [r15+0x140], xmm1
00007dd8c99ce6f4  mov qword ptr [r15+0x40], 0x02
00007dd8c99ce6fc  vmovaps xmm15, [0x00007DD8C95FE040]
00007dd8c99ce704  movq xmm15, xmm15
00007dd8c99ce709  movaps [r15+0x150], xmm15
00007dd8c99ce711  mov qword ptr [r15+0x58], 0x420000
00007dd8c99ce719  vmovaps xmm15, [0x00007DD8C95FE050]
00007dd8c99ce721  vpbroadcastq xmm15, xmm15
00007dd8c99ce726  movaps [r15+0x160], xmm15
00007dd8c99ce72e  mov rax, [r15+0x40]
00007dd8c99ce732  vmovq xmm14, rax
00007dd8c99ce737  vpbroadcastq xmm14, xmm14
00007dd8c99ce73c  movaps [r15+0x170], xmm14
00007dd8c99ce744  mov eax, 0x4204D0
00007dd8c99ce749  movups xmm13, [r13+rax*1]
00007dd8c99ce74f  mov qword ptr [r15+0x40], 0x430518
00007dd8c99ce757  mov qword ptr [r15+0x50], 0x430720
00007dd8c99ce75f  vpmovqd xmm12, xmm13
00007dd8c99ce765  pxor xmm11, xmm11
00007dd8c99ce76a  punpcklqdq xmm12, xmm11
00007dd8c99ce76f  movaps [r15+0x210], xmm12
00007dd8c99ce777  movq xmm12, qword ptr [r15+0x120]
00007dd8c99ce780  movq xmm11, qword ptr [r15+0x130]
00007dd8c99ce789  psubd xmm12, xmm11
00007dd8c99ce78e  movq xmm12, xmm12
00007dd8c99ce793  paddq xmm13, xmm14
00007dd8c99ce798  movaps [r15+0x180], xmm13
00007dd8c99ce7a0  movq xmm14, qword ptr [r15+0x150]
00007dd8c99ce7a9  paddd xmm11, xmm14
00007dd8c99ce7ae  movq xmm11, xmm11
00007dd8c99ce7b3  movq xmm11, xmm11
00007dd8c99ce7b8  movaps [r15+0x130], xmm11
00007dd8c99ce7c0  pmovzxdq xmm12, xmm12
00007dd8c99ce7c6  psllq xmm12, 0x00
00007dd8c99ce7cc  movq xmm14, qword ptr [r15+0x210]
00007dd8c99ce7d5  movq xmm13, qword ptr [r15+0x110]
00007dd8c99ce7de  paddd xmm14, xmm13
00007dd8c99ce7e3  movq xmm14, xmm14
00007dd8c99ce7e8  vcvtuqq2pd xmm12, xmm12
00007dd8c99ce7ee  pmovzxdq xmm14, xmm14
00007dd8c99ce7f4  psllq xmm14, 0x00
00007dd8c99ce7fa  vcvtuqq2pd xmm14, xmm14
00007dd8c99ce800  movaps xmm13, xmm12
00007dd8c99ce804  mulpd xmm13, xmm1
00007dd8c99ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007dd8c99ce80f  ptest xmm11, xmm11
00007dd8c99ce815  jnz 0x00007DD8C99CE8FF
00007dd8c99ce81b  movaps [r15+0x220], xmm13
00007dd8c99ce823  mov eax, 0x430720
00007dd8c99ce828  movups [r13+rax*1], xmm13
00007dd8c99ce82e  movaps xmm1, xmm14
00007dd8c99ce832  mulpd xmm1, xmm15
00007dd8c99ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007dd8c99ce83c  ptest xmm13, xmm13
00007dd8c99ce842  jnz 0x00007DD8C99CEA4C
00007dd8c99ce848  movaps [r15+0x210], xmm1
00007dd8c99ce850  mov eax, 0x430518
00007dd8c99ce855  movups [r13+rax*1], xmm1
00007dd8c99ce85b  mov qword ptr [r15+0x48], 0x10
00007dd8c99ce863  xor eax, eax
00007dd8c99ce865  mov r14d, 0x10
00007dd8c99ce86b  mov r12d, 0x200
00007dd8c99ce871  cmp r14, r12
00007dd8c99ce874  cmc
00007dd8c99ce875  lahf
00007dd8c99ce876  seto al
00007dd8c99ce879  mov [r15+0x108], eax
00007dd8c99ce880  mov eax, [r15+0x108]
00007dd8c99ce887  sahf
00007dd8c99ce888  jnz 0x00007DD8C99CE8BA
00007dd8c99ce88a  cmp dword ptr [r15+0x318], 0x00
00007dd8c99ce892  jz 0x00007DD8C99CEFF0
00007dd8c99ce898  nop [rax+rax*1], ax
00007dd8c99ce8a1  nop [rax+rax*1], eax
00007dd8c99ce8a9  mov eax, 0x4101EC
00007dd8c99ce8ae  mov [r15+0x100], rax
00007dd8c99ce8b5  jmp 0x00007DD8C97FE110
00007dd8c99ce8ba  cmp dword ptr [r15+0x318], 0x00
00007dd8c99ce8c2  jz 0x00007DD8C99CEBA0
00007dd8c99ce8c8  nop [rax+rax*1], ax
00007dd8c99ce8d1  nop [rax+rax*1], eax
00007dd8c99ce8d9  mov eax, 0x4101AC
00007dd8c99ce8de  mov [r15+0x100], rax
00007dd8c99ce8e5  jmp 0x00007DD8C97FE110
00007dd8c99ce8ea  int3
00007dd8c99ce8eb  call 0x00007DD8C980DC20
00007dd8c99ce8f0  jmp 0x00007DD8C99CE6D2
00007dd8c99ce8f5  call 0x00007DD8C980C260
00007dd8c99ce8fa  jmp 0x00007DD8C99CE74F
00007dd8c99ce8ff  sub rsp, 0x08
00007dd8c99ce903  push rax
00007dd8c99ce904  push rcx
00007dd8c99ce905  push rdx
00007dd8c99ce906  push rdi
00007dd8c99ce907  push rsi
00007dd8c99ce908  push r8
00007dd8c99ce90a  push r9
00007dd8c99ce90c  push r10
00007dd8c99ce90e  push r11
00007dd8c99ce910  sub rsp, 0xF0
00007dd8c99ce917  vmovaps [rsp], xmm0
00007dd8c99ce91c  vmovaps [rsp+0x10], xmm1
00007dd8c99ce922  vmovaps [rsp+0x20], xmm2
00007dd8c99ce928  vmovaps [rsp+0x30], xmm3
00007dd8c99ce92e  vmovaps [rsp+0x40], xmm4
00007dd8c99ce934  vmovaps [rsp+0x50], xmm5
00007dd8c99ce93a  vmovaps [rsp+0x60], xmm6
00007dd8c99ce940  vmovaps [rsp+0x70], xmm7
00007dd8c99ce946  vmovaps [rsp+0x80], xmm8
00007dd8c99ce94f  vmovaps [rsp+0x90], xmm9
00007dd8c99ce958  vmovaps [rsp+0xA0], xmm10
00007dd8c99ce961  vmovaps [rsp+0xB0], xmm11
00007dd8c99ce96a  vmovaps [rsp+0xC0], xmm12
00007dd8c99ce973  vmovaps [rsp+0xD0], xmm14
00007dd8c99ce97c  vmovaps [rsp+0xE0], xmm15
00007dd8c99ce985  sub rsp, 0x30
00007dd8c99ce989  movaps [rsp], xmm13
00007dd8c99ce98e  movaps [rsp+0x10], xmm12
00007dd8c99ce994  movaps [rsp+0x20], xmm1
00007dd8c99ce999  lea rdi, [rsp]
00007dd8c99ce99d  mov esi, 0x00
00007dd8c99ce9a2  mov rax, 0x55FEBBDB5530
00007dd8c99ce9ac  call rax
00007dd8c99ce9ae  movaps xmm13, [rsp]
00007dd8c99ce9b3  add rsp, 0x30
00007dd8c99ce9b7  vmovaps xmm0, [rsp]
00007dd8c99ce9bc  vmovaps xmm1, [rsp+0x10]
00007dd8c99ce9c2  vmovaps xmm2, [rsp+0x20]
00007dd8c99ce9c8  vmovaps xmm3, [rsp+0x30]
00007dd8c99ce9ce  vmovaps xmm4, [rsp+0x40]
00007dd8c99ce9d4  vmovaps xmm5, [rsp+0x50]
00007dd8c99ce9da  vmovaps xmm6, [rsp+0x60]
00007dd8c99ce9e0  vmovaps xmm7, [rsp+0x70]
00007dd8c99ce9e6  vmovaps xmm8, [rsp+0x80]
00007dd8c99ce9ef  vmovaps xmm9, [rsp+0x90]
00007dd8c99ce9f8  vmovaps xmm10, [rsp+0xA0]
00007dd8c99cea01  vmovaps xmm11, [rsp+0xB0]
00007dd8c99cea0a  vmovaps xmm12, [rsp+0xC0]
00007dd8c99cea13  vmovaps xmm14, [rsp+0xD0]
00007dd8c99cea1c  vmovaps xmm15, [rsp+0xE0]
00007dd8c99cea25  add rsp, 0xF0
00007dd8c99cea2c  pop r11
00007dd8c99cea2e  pop r10
00007dd8c99cea30  pop r9
00007dd8c99cea32  pop r8
00007dd8c99cea34  pop rsi
00007dd8c99cea35  pop rdi
00007dd8c99cea36  pop rdx
00007dd8c99cea37  pop rcx
00007dd8c99cea38  pop rax
00007dd8c99cea39  add rsp, 0x08
00007dd8c99cea3d  jmp 0x00007DD8C99CE81B
00007dd8c99cea42  call 0x00007DD8C980C380
00007dd8c99cea47  jmp 0x00007DD8C99CE82E
00007dd8c99cea4c  sub rsp, 0x08
00007dd8c99cea50  push rax
00007dd8c99cea51  push rcx
00007dd8c99cea52  push rdx
00007dd8c99cea53  push rdi
00007dd8c99cea54  push rsi
00007dd8c99cea55  push r8
00007dd8c99cea57  push r9
00007dd8c99cea59  push r10
00007dd8c99cea5b  push r11
00007dd8c99cea5d  sub rsp, 0xF0
00007dd8c99cea64  vmovaps [rsp], xmm0
00007dd8c99cea69  vmovaps [rsp+0x10], xmm2
00007dd8c99cea6f  vmovaps [rsp+0x20], xmm3
00007dd8c99cea75  vmovaps [rsp+0x30], xmm4
00007dd8c99cea7b  vmovaps [rsp+0x40], xmm5
00007dd8c99cea81  vmovaps [rsp+0x50], xmm6
00007dd8c99cea87  vmovaps [rsp+0x60], xmm7
00007dd8c99cea8d  vmovaps [rsp+0x70], xmm8
00007dd8c99cea93  vmovaps [rsp+0x80], xmm9
00007dd8c99cea9c  vmovaps [rsp+0x90], xmm10
00007dd8c99ceaa5  vmovaps [rsp+0xA0], xmm11
00007dd8c99ceaae  vmovaps [rsp+0xB0], xmm12
00007dd8c99ceab7  vmovaps [rsp+0xC0], xmm13
00007dd8c99ceac0  vmovaps [rsp+0xD0], xmm14
00007dd8c99ceac9  vmovaps [rsp+0xE0], xmm15
00007dd8c99cead2  sub rsp, 0x30
00007dd8c99cead6  movaps [rsp], xmm1
00007dd8c99ceada  movaps [rsp+0x10], xmm14
00007dd8c99ceae0  movaps [rsp+0x20], xmm15
00007dd8c99ceae6  lea rdi, [rsp]
00007dd8c99ceaea  mov esi, 0x00
00007dd8c99ceaef  mov rax, 0x55FEBBDB5530
00007dd8c99ceaf9  call rax
00007dd8c99ceafb  movaps xmm1, [rsp]
00007dd8c99ceaff  add rsp, 0x30
00007dd8c99ceb03  vmovaps xmm0, [rsp]
00007dd8c99ceb08  vmovaps xmm2, [rsp+0x10]
00007dd8c99ceb0e  vmovaps xmm3, [rsp+0x20]
00007dd8c99ceb14  vmovaps xmm4, [rsp+0x30]
00007dd8c99ceb1a  vmovaps xmm5, [rsp+0x40]
00007dd8c99ceb20  vmovaps xmm6, [rsp+0x50]
00007dd8c99ceb26  vmovaps xmm7, [rsp+0x60]
00007dd8c99ceb2c  vmovaps xmm8, [rsp+0x70]
00007dd8c99ceb32  vmovaps xmm9, [rsp+0x80]
00007dd8c99ceb3b  vmovaps xmm10, [rsp+0x90]
00007dd8c99ceb44  vmovaps xmm11, [rsp+0xA0]
00007dd8c99ceb4d  vmovaps xmm12, [rsp+0xB0]
00007dd8c99ceb56  vmovaps xmm13, [rsp+0xC0]
00007dd8c99ceb5f  vmovaps xmm14, [rsp+0xD0]
00007dd8c99ceb68  vmovaps xmm15, [rsp+0xE0]
00007dd8c99ceb71  add rsp, 0xF0
00007dd8c99ceb78  pop r11
00007dd8c99ceb7a  pop r10
00007dd8c99ceb7c  pop r9
00007dd8c99ceb7e  pop r8
00007dd8c99ceb80  pop rsi
00007dd8c99ceb81  pop rdi
00007dd8c99ceb82  pop rdx
00007dd8c99ceb83  pop rcx
00007dd8c99ceb84  pop rax
00007dd8c99ceb85  add rsp, 0x08
00007dd8c99ceb89  jmp 0x00007DD8C99CE848
00007dd8c99ceb8e  call 0x00007DD8C97FF540
00007dd8c99ceb93  jmp 0x00007DD8C99CE85B
00007dd8c99ceb98  int3
00007dd8c99ceb99  nop [rax], eax
00007dd8c99ceba0  movaps xmm1, [r15+0x180]
00007dd8c99ceba8  vpmovqd xmm15, xmm1
00007dd8c99cebae  pxor xmm14, xmm14
00007dd8c99cebb3  punpcklqdq xmm15, xmm14
00007dd8c99cebb8  movaps [r15+0x210], xmm15
00007dd8c99cebc0  movq xmm15, qword ptr [r15+0x120]
00007dd8c99cebc9  movq xmm14, qword ptr [r15+0x130]
00007dd8c99cebd2  psubd xmm15, xmm14
00007dd8c99cebd7  movq xmm15, xmm15
00007dd8c99cebdc  movaps xmm13, [r15+0x170]
00007dd8c99cebe4  paddq xmm1, xmm13
00007dd8c99cebe9  movaps [r15+0x180], xmm1
00007dd8c99cebf1  movq xmm1, qword ptr [r15+0x150]
00007dd8c99cebfa  paddd xmm14, xmm1
00007dd8c99cebff  movq xmm14, xmm14
00007dd8c99cec04  movq xmm14, xmm14
00007dd8c99cec09  movaps [r15+0x130], xmm14
00007dd8c99cec11  pmovzxdq xmm15, xmm15
00007dd8c99cec17  psllq xmm15, 0x00
00007dd8c99cec1d  movq xmm1, qword ptr [r15+0x210]
00007dd8c99cec26  movq xmm14, qword ptr [r15+0x110]
00007dd8c99cec2f  paddd xmm1, xmm14
00007dd8c99cec34  movq xmm1, xmm1
00007dd8c99cec38  vcvtuqq2pd xmm15, xmm15
00007dd8c99cec3e  pmovzxdq xmm1, xmm1
00007dd8c99cec43  psllq xmm1, 0x00
00007dd8c99cec48  vcvtuqq2pd xmm1, xmm1
00007dd8c99cec4e  movaps xmm14, [r15+0x140]
00007dd8c99cec56  movaps xmm13, xmm15
00007dd8c99cec5a  mulpd xmm13, xmm14
00007dd8c99cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007dd8c99cec65  ptest xmm12, xmm12
00007dd8c99cec6b  jnz 0x00007DD8C99CED4E
00007dd8c99cec71  movaps [r15+0x220], xmm13
00007dd8c99cec79  mov rax, [r15+0x48]
00007dd8c99cec7d  mov r14, [r15+0x50]
00007dd8c99cec81  lea r12, [r14+rax*1]
00007dd8c99cec85  movups [r13+r12*1], xmm13
00007dd8c99cec8b  movaps xmm15, [r15+0x160]
00007dd8c99cec93  movaps xmm14, xmm1
00007dd8c99cec97  mulpd xmm14, xmm15
00007dd8c99cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007dd8c99ceca2  ptest xmm13, xmm13
00007dd8c99ceca8  jnz 0x00007DD8C99CEE9C
00007dd8c99cecae  movaps [r15+0x210], xmm14
00007dd8c99cecb6  mov r14, [r15+0x40]
00007dd8c99cecba  lea r12, [r14+rax*1]
00007dd8c99cecbe  movups [r13+r12*1], xmm14
00007dd8c99cecc4  lea r14, [rax+0x10]
00007dd8c99cecc8  mov [r15+0x48], r14
00007dd8c99ceccc  xor eax, eax
00007dd8c99cecce  mov r12d, 0x200
00007dd8c99cecd4  cmp r14, r12
00007dd8c99cecd7  cmc
00007dd8c99cecd8  lahf
00007dd8c99cecd9  seto al
00007dd8c99cecdc  mov [r15+0x108], eax
00007dd8c99cece3  mov eax, [r15+0x108]
00007dd8c99cecea  sahf
00007dd8c99ceceb  jnz 0x00007DD8C99CED1D
00007dd8c99ceced  cmp dword ptr [r15+0x318], 0x00
00007dd8c99cecf5  jz 0x00007DD8C99CEFF0
00007dd8c99cecfb  nop [rax+rax*1], ax
00007dd8c99ced04  nop [rax+rax*1], eax
00007dd8c99ced0c  mov eax, 0x4101EC
00007dd8c99ced11  mov [r15+0x100], rax
00007dd8c99ced18  jmp 0x00007DD8C97FE110
00007dd8c99ced1d  cmp dword ptr [r15+0x318], 0x00
00007dd8c99ced25  jz 0x00007DD8C99CEBA0
00007dd8c99ced2b  nop [rax+rax*1], ax
00007dd8c99ced34  nop [rax+rax*1], eax
00007dd8c99ced3c  mov eax, 0x4101AC
00007dd8c99ced41  mov [r15+0x100], rax
00007dd8c99ced48  jmp 0x00007DD8C97FE110
00007dd8c99ced4d  int3
00007dd8c99ced4e  sub rsp, 0x08
00007dd8c99ced52  push rax
00007dd8c99ced53  push rcx
00007dd8c99ced54  push rdx
00007dd8c99ced55  push rdi
00007dd8c99ced56  push rsi
00007dd8c99ced57  push r8
00007dd8c99ced59  push r9
00007dd8c99ced5b  push r10
00007dd8c99ced5d  push r11
00007dd8c99ced5f  sub rsp, 0xF0
00007dd8c99ced66  vmovaps [rsp], xmm0
00007dd8c99ced6b  vmovaps [rsp+0x10], xmm1
00007dd8c99ced71  vmovaps [rsp+0x20], xmm2
00007dd8c99ced77  vmovaps [rsp+0x30], xmm3
00007dd8c99ced7d  vmovaps [rsp+0x40], xmm4
00007dd8c99ced83  vmovaps [rsp+0x50], xmm5
00007dd8c99ced89  vmovaps [rsp+0x60], xmm6
00007dd8c99ced8f  vmovaps [rsp+0x70], xmm7
00007dd8c99ced95  vmovaps [rsp+0x80], xmm8
00007dd8c99ced9e  vmovaps [rsp+0x90], xmm9
00007dd8c99ceda7  vmovaps [rsp+0xA0], xmm10
00007dd8c99cedb0  vmovaps [rsp+0xB0], xmm11
00007dd8c99cedb9  vmovaps [rsp+0xC0], xmm12
00007dd8c99cedc2  vmovaps [rsp+0xD0], xmm14
00007dd8c99cedcb  vmovaps [rsp+0xE0], xmm15
00007dd8c99cedd4  sub rsp, 0x30
00007dd8c99cedd8  movaps [rsp], xmm13
00007dd8c99ceddd  movaps [rsp+0x10], xmm15
00007dd8c99cede3  movaps [rsp+0x20], xmm14
00007dd8c99cede9  lea rdi, [rsp]
00007dd8c99ceded  mov esi, 0x00
00007dd8c99cedf2  mov rax, 0x55FEBBDB5530
00007dd8c99cedfc  call rax
00007dd8c99cedfe  movaps xmm13, [rsp]
00007dd8c99cee03  add rsp, 0x30
00007dd8c99cee07  vmovaps xmm0, [rsp]
00007dd8c99cee0c  vmovaps xmm1, [rsp+0x10]
00007dd8c99cee12  vmovaps xmm2, [rsp+0x20]
00007dd8c99cee18  vmovaps xmm3, [rsp+0x30]
00007dd8c99cee1e  vmovaps xmm4, [rsp+0x40]
00007dd8c99cee24  vmovaps xmm5, [rsp+0x50]
00007dd8c99cee2a  vmovaps xmm6, [rsp+0x60]
00007dd8c99cee30  vmovaps xmm7, [rsp+0x70]
00007dd8c99cee36  vmovaps xmm8, [rsp+0x80]
00007dd8c99cee3f  vmovaps xmm9, [rsp+0x90]
00007dd8c99cee48  vmovaps xmm10, [rsp+0xA0]
00007dd8c99cee51  vmovaps xmm11, [rsp+0xB0]
00007dd8c99cee5a  vmovaps xmm12, [rsp+0xC0]
00007dd8c99cee63  vmovaps xmm14, [rsp+0xD0]
00007dd8c99cee6c  vmovaps xmm15, [rsp+0xE0]
00007dd8c99cee75  add rsp, 0xF0
00007dd8c99cee7c  pop r11
00007dd8c99cee7e  pop r10
00007dd8c99cee80  pop r9
00007dd8c99cee82  pop r8
00007dd8c99cee84  pop rsi
00007dd8c99cee85  pop rdi
00007dd8c99cee86  pop rdx
00007dd8c99cee87  pop rcx
00007dd8c99cee88  pop rax
00007dd8c99cee89  add rsp, 0x08
00007dd8c99cee8d  jmp 0x00007DD8C99CEC71
00007dd8c99cee92  call 0x00007DD8C98C2240
00007dd8c99cee97  jmp 0x00007DD8C99CEC8B
00007dd8c99cee9c  sub rsp, 0x08
00007dd8c99ceea0  push rax
00007dd8c99ceea1  push rcx
00007dd8c99ceea2  push rdx
00007dd8c99ceea3  push rdi
00007dd8c99ceea4  push rsi
00007dd8c99ceea5  push r8
00007dd8c99ceea7  push r9
00007dd8c99ceea9  push r10
00007dd8c99ceeab  push r11
00007dd8c99ceead  sub rsp, 0xF0
00007dd8c99ceeb4  vmovaps [rsp], xmm0
00007dd8c99ceeb9  vmovaps [rsp+0x10], xmm1
00007dd8c99ceebf  vmovaps [rsp+0x20], xmm2
00007dd8c99ceec5  vmovaps [rsp+0x30], xmm3
00007dd8c99ceecb  vmovaps [rsp+0x40], xmm4
00007dd8c99ceed1  vmovaps [rsp+0x50], xmm5
00007dd8c99ceed7  vmovaps [rsp+0x60], xmm6
00007dd8c99ceedd  vmovaps [rsp+0x70], xmm7
00007dd8c99ceee3  vmovaps [rsp+0x80], xmm8
00007dd8c99ceeec  vmovaps [rsp+0x90], xmm9
00007dd8c99ceef5  vmovaps [rsp+0xA0], xmm10
00007dd8c99ceefe  vmovaps [rsp+0xB0], xmm11
00007dd8c99cef07  vmovaps [rsp+0xC0], xmm12
00007dd8c99cef10  vmovaps [rsp+0xD0], xmm13
00007dd8c99cef19  vmovaps [rsp+0xE0], xmm15
00007dd8c99cef22  sub rsp, 0x30
00007dd8c99cef26  movaps [rsp], xmm14
00007dd8c99cef2b  movaps [rsp+0x10], xmm1
00007dd8c99cef30  movaps [rsp+0x20], xmm15
00007dd8c99cef36  lea rdi, [rsp]
00007dd8c99cef3a  mov esi, 0x00
00007dd8c99cef3f  mov rax, 0x55FEBBDB5530
00007dd8c99cef49  call rax
00007dd8c99cef4b  movaps xmm14, [rsp]
00007dd8c99cef50  add rsp, 0x30
00007dd8c99cef54  vmovaps xmm0, [rsp]
00007dd8c99cef59  vmovaps xmm1, [rsp+0x10]
00007dd8c99cef5f  vmovaps xmm2, [rsp+0x20]
00007dd8c99cef65  vmovaps xmm3, [rsp+0x30]
00007dd8c99cef6b  vmovaps xmm4, [rsp+0x40]
00007dd8c99cef71  vmovaps xmm5, [rsp+0x50]
00007dd8c99cef77  vmovaps xmm6, [rsp+0x60]
00007dd8c99cef7d  vmovaps xmm7, [rsp+0x70]
00007dd8c99cef83  vmovaps xmm8, [rsp+0x80]
00007dd8c99cef8c  vmovaps xmm9, [rsp+0x90]
00007dd8c99cef95  vmovaps xmm10, [rsp+0xA0]
00007dd8c99cef9e  vmovaps xmm11, [rsp+0xB0]
00007dd8c99cefa7  vmovaps xmm12, [rsp+0xC0]
00007dd8c99cefb0  vmovaps xmm13, [rsp+0xD0]
00007dd8c99cefb9  vmovaps xmm15, [rsp+0xE0]
00007dd8c99cefc2  add rsp, 0xF0
00007dd8c99cefc9  pop r11
00007dd8c99cefcb  pop r10
00007dd8c99cefcd  pop r9
00007dd8c99cefcf  pop r8
00007dd8c99cefd1  pop rsi
00007dd8c99cefd2  pop rdi
00007dd8c99cefd3  pop rdx
00007dd8c99cefd4  pop rcx
00007dd8c99cefd5  pop rax
00007dd8c99cefd6  add rsp, 0x08
00007dd8c99cefda  jmp 0x00007DD8C99CECAE
00007dd8c99cefdf  call 0x00007DD8C98C34C0
00007dd8c99cefe4  jmp 0x00007DD8C99CECC4
00007dd8c99cefe9  int3
00007dd8c99cefea  nop [rax+rax*1], ax
00007dd8c99ceff0  mov rax, [r15+0xF8]
00007dd8c99ceff7  lea r14, [rax-0x150]
00007dd8c99ceffe  mov [r15+0xF8], r14
00007dd8c99cf005  mov rax, [r15+0x50]
00007dd8c99cf009  lea r12, [rax+0x80]
00007dd8c99cf010  movups xmm1, [r13+r12*1]
00007dd8c99cf016  lea r12, [rax+0x90]
00007dd8c99cf01d  movups xmm15, [r13+r12*1]
00007dd8c99cf023  mov qword ptr [r15+0x48], 0x00
00007dd8c99cf02b  lea r12, [rax+0x40]
00007dd8c99cf02f  movups xmm14, [r13+r12*1]
00007dd8c99cf035  lea r12, [rax+0x50]
00007dd8c99cf039  movups xmm13, [r13+r12*1]
00007dd8c99cf03f  lea r12, [r14+0x120]
00007dd8c99cf046  movq xmm12, qword ptr [r15+0x1C0]
00007dd8c99cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007dd8c99cf058  movq r11, xmm12
00007dd8c99cf05d  movq r10, xmm11
00007dd8c99cf062  mov [r13+r12*1], r11
00007dd8c99cf067  lea r12, [r14+0x128]
00007dd8c99cf06e  mov [r13+r12*1], r10
00007dd8c99cf073  vxorps xmm12, xmm12, xmm12
00007dd8c99cf078  vpbroadcastq xmm12, xmm12
00007dd8c99cf07d  lea r12, [r14+0x100]
00007dd8c99cf084  movq xmm11, qword ptr [r15+0x200]
00007dd8c99cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007dd8c99cf096  movq r11, xmm11
00007dd8c99cf09b  movq r10, xmm10
00007dd8c99cf0a0  mov [r13+r12*1], r11
00007dd8c99cf0a5  lea r12, [r14+0x108]
00007dd8c99cf0ac  mov [r13+r12*1], r10
00007dd8c99cf0b1  lea r12, [r14+0xE0]
00007dd8c99cf0b8  movups [r13+r12*1], xmm15
00007dd8c99cf0be  lea r12, [r14+0xF0]
00007dd8c99cf0c5  movups [r13+r12*1], xmm1
00007dd8c99cf0cb  lea r12, [rax+0xC0]
00007dd8c99cf0d2  movups xmm1, [r13+r12*1]
00007dd8c99cf0d8  lea r12, [rax+0xD0]
00007dd8c99cf0df  movups xmm15, [r13+r12*1]
00007dd8c99cf0e5  lea r12, [r14+0x110]
00007dd8c99cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007dd8c99cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007dd8c99cf0fe  movq r11, xmm11
00007dd8c99cf103  movq r10, xmm10
00007dd8c99cf108  mov [r13+r12*1], r11
00007dd8c99cf10d  lea r12, [r14+0x118]
00007dd8c99cf114  mov [r13+r12*1], r10
00007dd8c99cf119  movups xmm11, [r13+rax*1]
00007dd8c99cf11f  lea r12, [rax+0x10]
00007dd8c99cf123  movups xmm10, [r13+r12*1]
00007dd8c99cf129  lea r12, [r14+0x130]
00007dd8c99cf130  movq xmm9, qword ptr [r15+0x1A0]
00007dd8c99cf139  movq xmm8, qword ptr [r15+0x190]
00007dd8c99cf142  movq r11, xmm9
00007dd8c99cf147  movq r10, xmm8
00007dd8c99cf14c  mov [r13+r12*1], r11
00007dd8c99cf151  lea r12, [r14+0x138]
00007dd8c99cf158  mov [r13+r12*1], r10
00007dd8c99cf15d  lea r12, [rax+0x140]
00007dd8c99cf164  movups xmm9, [r13+r12*1]
00007dd8c99cf16a  lea r12, [rax+0x150]
00007dd8c99cf171  movups xmm8, [r13+r12*1]
00007dd8c99cf177  lea r12, [r14+0xC0]
00007dd8c99cf17e  movups [r13+r12*1], xmm15
00007dd8c99cf184  lea r12, [r14+0xD0]
00007dd8c99cf18b  movups [r13+r12*1], xmm1
00007dd8c99cf191  lea r12, [rax+0x100]
00007dd8c99cf198  movups xmm1, [r13+r12*1]
00007dd8c99cf19e  lea r12, [rax+0x110]
00007dd8c99cf1a5  movups xmm15, [r13+r12*1]
00007dd8c99cf1ab  lea r12, [r14+0x140]
00007dd8c99cf1b2  mov r11, [r15+0xE8]
00007dd8c99cf1b9  mov [r13+r12*1], r11
00007dd8c99cf1be  lea r12, [rax+0x180]
00007dd8c99cf1c5  movups xmm7, [r13+r12*1]
00007dd8c99cf1cb  lea r12, [rax+0x190]
00007dd8c99cf1d2  movups xmm6, [r13+r12*1]
00007dd8c99cf1d8  lea r12, [rax+0x1C0]
00007dd8c99cf1df  movups xmm5, [r13+r12*1]
00007dd8c99cf1e5  lea r12, [rax+0x1D0]
00007dd8c99cf1ec  movups xmm4, [r13+r12*1]
00007dd8c99cf1f2  lea r12, [r14+0x20]
00007dd8c99cf1f6  movups [r13+r12*1], xmm1
00007dd8c99cf1fc  lea r12, [r14+0x30]
00007dd8c99cf200  movups [r13+r12*1], xmm13
00007dd8c99cf206  lea r12, [rax+0x60]
00007dd8c99cf20a  movups xmm1, [r13+r12*1]
00007dd8c99cf210  lea r12, [rax+0x70]
00007dd8c99cf214  movups xmm13, [r13+r12*1]
00007dd8c99cf21a  lea r12, [rax+0x20]
00007dd8c99cf21e  movups xmm3, [r13+r12*1]
00007dd8c99cf224  lea r12, [rax+0x30]
00007dd8c99cf228  movups xmm2, [r13+r12*1]
00007dd8c99cf22e  movaps [r15+0x1F0], xmm2
00007dd8c99cf236  lea r12, [r14+0x60]
00007dd8c99cf23a  movups [r13+r12*1], xmm11
00007dd8c99cf240  lea r12, [r14+0x70]
00007dd8c99cf244  movups [r13+r12*1], xmm5
00007dd8c99cf24a  lea r12, [rax+0xE0]
00007dd8c99cf251  movups xmm11, [r13+r12*1]
00007dd8c99cf257  lea r12, [rax+0xF0]
00007dd8c99cf25e  movups xmm5, [r13+r12*1]
00007dd8c99cf264  lea r12, [r14+0xA0]
00007dd8c99cf26b  movups [r13+r12*1], xmm13
00007dd8c99cf271  lea r12, [r14+0xB0]
00007dd8c99cf278  movups [r13+r12*1], xmm1
00007dd8c99cf27e  lea r12, [rax+0xA0]
00007dd8c99cf285  movups xmm1, [r13+r12*1]
00007dd8c99cf28b  lea r12, [rax+0xB0]
00007dd8c99cf292  movups xmm13, [r13+r12*1]
00007dd8c99cf298  lea r12, [rax+0x120]
00007dd8c99cf29f  vmovaps [rsp+0x10], xmm1
00007dd8c99cf2a5  movups xmm1, [r13+r12*1]
00007dd8c99cf2ab  lea r12, [rax+0x130]
00007dd8c99cf2b2  vmovaps [rsp+0x20], xmm1
00007dd8c99cf2b8  movups xmm1, [r13+r12*1]
00007dd8c99cf2be  lea r12, [rax+0x160]
00007dd8c99cf2c5  vmovaps [rsp+0x30], xmm1
00007dd8c99cf2cb  movups xmm1, [r13+r12*1]
00007dd8c99cf2d1  lea r12, [rax+0x170]
00007dd8c99cf2d8  vmovaps [rsp+0x40], xmm1
00007dd8c99cf2de  movups xmm1, [r13+r12*1]
00007dd8c99cf2e4  movaps [r15+0x2B0], xmm1
00007dd8c99cf2ec  lea r12, [r14+0x80]
00007dd8c99cf2f3  movups [r13+r12*1], xmm13
00007dd8c99cf2f9  lea r12, [r14+0x90]
00007dd8c99cf300  vmovaps xmm13, [rsp+0x10]
00007dd8c99cf306  movups [r13+r12*1], xmm13
00007dd8c99cf30c  lea r12, [rax+0x1A0]
00007dd8c99cf313  movups xmm13, [r13+r12*1]
00007dd8c99cf319  lea r12, [rax+0x1B0]
00007dd8c99cf320  vmovaps [rsp+0x10], xmm1
00007dd8c99cf326  movups xmm1, [r13+r12*1]
00007dd8c99cf32c  movaps [r15+0x290], xmm13
00007dd8c99cf334  movaps [r15+0x1E0], xmm1
00007dd8c99cf33c  lea r12, [rax+0x1E0]
00007dd8c99cf343  vmovaps [rsp+0x50], xmm1
00007dd8c99cf349  movups xmm1, [r13+r12*1]
00007dd8c99cf34f  lea r12, [rax+0x1F0]
00007dd8c99cf356  vmovaps [rsp+0x60], xmm1
00007dd8c99cf35c  movups xmm1, [r13+r12*1]
00007dd8c99cf362  mov qword ptr [r15+0x50], 0x430920
00007dd8c99cf36a  lea rax, [r14+0x40]
00007dd8c99cf36e  vmovaps [rsp+0x70], xmm1
00007dd8c99cf374  vmovaps xmm1, [rsp+0x40]
00007dd8c99cf37a  movups [r13+rax*1], xmm1
00007dd8c99cf380  lea rax, [r14+0x50]
00007dd8c99cf384  movups [r13+rax*1], xmm10
00007dd8c99cf38a  vmovaps xmm1, [rsp+0x70]
00007dd8c99cf390  movups [r13+r14*1], xmm1
00007dd8c99cf396  lea rax, [r14+0x10]
00007dd8c99cf39a  vmovaps xmm1, [rsp+0x60]
00007dd8c99cf3a0  movups [r13+rax*1], xmm1
00007dd8c99cf3a6  mov rax, [r15+0x40]
00007dd8c99cf3aa  vmovaps [rsp+0x40], xmm3
00007dd8c99cf3b0  vmovaps xmm1, [rsp+0x40]
00007dd8c99cf3b6  por xmm3, xmm1
00007dd8c99cf3ba  vmovaps [rsp+0x40], xmm6
00007dd8c99cf3c0  vmovaps xmm10, [rsp+0x40]
00007dd8c99cf3c6  por xmm6, xmm10
00007dd8c99cf3cb  lea r12, [rax+0x30]
00007dd8c99cf3cf  mov r11, [r13+r12*1]
00007dd8c99cf3d4  lea r12, [rax+0x38]
00007dd8c99cf3d8  mov r10, [r13+r12*1]
00007dd8c99cf3dd  movq xmm10, r11
00007dd8c99cf3e2  vmovaps [rsp+0x40], xmm1
00007dd8c99cf3e8  movq xmm1, r10
00007dd8c99cf3ed  movq xmm10, xmm10
00007dd8c99cf3f2  vmovaps [rsp+0x60], xmm10
00007dd8c99cf3f8  movq xmm10, xmm10
00007dd8c99cf3fd  movaps [r15+0x130], xmm10
00007dd8c99cf405  movq xmm1, xmm1
00007dd8c99cf409  vmovaps [rsp+0x70], xmm1
00007dd8c99cf40f  movq xmm1, xmm1
00007dd8c99cf413  movaps [r15+0x280], xmm1
00007dd8c99cf41b  vmovaps [rsp+0x80], xmm9
00007dd8c99cf424  vmovaps xmm1, [rsp+0x80]
00007dd8c99cf42d  por xmm9, xmm1
00007dd8c99cf432  lea r12, [rax+0x20]
00007dd8c99cf436  mov r11, [r13+r12*1]
00007dd8c99cf43b  lea r12, [rax+0x28]
00007dd8c99cf43f  mov r10, [r13+r12*1]
00007dd8c99cf444  movq xmm1, r11
00007dd8c99cf449  movq xmm10, r10
00007dd8c99cf44e  movq xmm1, xmm1
00007dd8c99cf452  vmovaps [rsp+0x80], xmm1
00007dd8c99cf45b  movq xmm1, xmm1
00007dd8c99cf45f  movaps [r15+0x150], xmm1
00007dd8c99cf467  movq xmm10, xmm10
00007dd8c99cf46c  vmovaps [rsp+0x90], xmm10
00007dd8c99cf475  movq xmm10, xmm10
00007dd8c99cf47a  movaps [r15+0x140], xmm10
00007dd8c99cf482  lea r12, [rax+0x10]
00007dd8c99cf486  mov r11, [r13+r12*1]
00007dd8c99cf48b  lea r12, [rax+0x18]
00007dd8c99cf48f  mov r10, [r13+r12*1]
00007dd8c99cf494  movq xmm1, r11
00007dd8c99cf499  movq xmm10, r10
00007dd8c99cf49e  movq xmm1, xmm1
00007dd8c99cf4a2  vmovaps [rsp+0xA0], xmm1
00007dd8c99cf4ab  movq xmm1, xmm1
00007dd8c99cf4af  movaps [r15+0x170], xmm1
00007dd8c99cf4b7  movq xmm10, xmm10
00007dd8c99cf4bc  vmovaps [rsp+0xB0], xmm10
00007dd8c99cf4c5  movq xmm10, xmm10
00007dd8c99cf4ca  movaps [r15+0x160], xmm10
00007dd8c99cf4d2  mov r12, [r13+rax*1]
00007dd8c99cf4d7  vmovq xmm1, r12
00007dd8c99cf4dc  vpbroadcastq xmm1, xmm1
00007dd8c99cf4e1  lea r12, [rax+0x08]
00007dd8c99cf4e5  mov rax, [r13+r12*1]
00007dd8c99cf4ea  movq xmm10, rax
00007dd8c99cf4ef  movaps [r15+0x230], xmm10
00007dd8c99cf4f7  lea rax, [r14+0x50]
00007dd8c99cf4fb  movups xmm10, [r13+rax*1]
00007dd8c99cf501  lea rax, [r14+0x60]
00007dd8c99cf505  vmovaps [rsp+0xC0], xmm1
00007dd8c99cf50e  movups xmm1, [r13+rax*1]
00007dd8c99cf514  lea rax, [r14+0x30]
00007dd8c99cf518  vmovaps [rsp+0xD0], xmm1
00007dd8c99cf521  movups xmm1, [r13+rax*1]
00007dd8c99cf527  mov qword ptr [r15+0x60], 0x430920
00007dd8c99cf52f  mov qword ptr [r15+0x58], 0x40
00007dd8c99cf537  vmovaps [rsp+0xE0], xmm1
00007dd8c99cf540  vmovaps [rsp+0xF0], xmm15
00007dd8c99cf549  vmovaps xmm15, [rsp+0xC0]
00007dd8c99cf552  vmovaps [rsp+0xC0], xmm14
00007dd8c99cf55b  vmovaps xmm14, [rsp+0x40]
00007dd8c99cf561  vmovaps [rsp+0x40], xmm13
00007dd8c99cf567  movaps xmm1, xmm15
00007dd8c99cf56b  mulpd xmm1, xmm14
00007dd8c99cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007dd8c99cf575  ptest xmm13, xmm13
00007dd8c99cf57b  jnz 0x00007DD8C99D0682
00007dd8c99cf581  movq xmm14, qword ptr [r15+0x230]
00007dd8c99cf58a  vmovaps [rsp+0x100], xmm14
00007dd8c99cf593  vpermilpd xmm14, xmm14, 0x00
00007dd8c99cf599  vmovaps [rsp+0x110], xmm1
00007dd8c99cf5a2  vmovaps xmm1, [rsp+0xE0]
00007dd8c99cf5ab  vmovaps [rsp+0xE0], xmm15
00007dd8c99cf5b4  movaps xmm13, xmm1
00007dd8c99cf5b8  mulpd xmm13, xmm14
00007dd8c99cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007dd8c99cf5c3  ptest xmm15, xmm15
00007dd8c99cf5c9  jnz 0x00007DD8C99D07C4
00007dd8c99cf5cf  vxorps xmm1, xmm1, xmm1
00007dd8c99cf5d3  vpbroadcastq xmm1, xmm1
00007dd8c99cf5d8  vmovaps xmm14, [rsp+0xE0]
00007dd8c99cf5e1  vmovaps [rsp+0xE0], xmm1
00007dd8c99cf5ea  vmovaps xmm1, [rsp+0xD0]
00007dd8c99cf5f3  vmovaps [rsp+0xD0], xmm13
00007dd8c99cf5fc  movaps xmm15, xmm14
00007dd8c99cf600  mulpd xmm15, xmm1
00007dd8c99cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007dd8c99cf60b  ptest xmm13, xmm13
00007dd8c99cf611  jnz 0x00007DD8C99D0907
00007dd8c99cf617  movaps xmm1, xmm14
00007dd8c99cf61b  mulpd xmm1, xmm10
00007dd8c99cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007dd8c99cf625  ptest xmm13, xmm13
00007dd8c99cf62b  jnz 0x00007DD8C99D0A4A
00007dd8c99cf631  movaps xmm13, xmm14
00007dd8c99cf635  mulpd xmm13, xmm2
00007dd8c99cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007dd8c99cf640  ptest xmm10, xmm10
00007dd8c99cf646  jnz 0x00007DD8C99D0B8C
00007dd8c99cf64c  vmovaps [rsp+0x120], xmm7
00007dd8c99cf655  vmovaps xmm14, [rsp+0x120]
00007dd8c99cf65e  por xmm7, xmm14
00007dd8c99cf663  vmovaps xmm14, [rsp+0xC0]
00007dd8c99cf66c  vmovaps xmm10, [rsp+0xC0]
00007dd8c99cf675  por xmm14, xmm10
00007dd8c99cf67a  vmovaps xmm2, [rsp+0x100]
00007dd8c99cf683  vpermilpd xmm2, xmm2, 0x00
00007dd8c99cf689  vmovaps [rsp+0xC0], xmm1
00007dd8c99cf692  vmovaps [rsp+0x120], xmm15
00007dd8c99cf69b  movaps xmm1, xmm10
00007dd8c99cf69f  mulpd xmm1, xmm2
00007dd8c99cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd8c99cf6a8  ptest xmm15, xmm15
00007dd8c99cf6ae  jnz 0x00007DD8C99D0CCF
00007dd8c99cf6b4  xor eax, eax
00007dd8c99cf6b6  mov r12d, 0x40
00007dd8c99cf6bc  mov r11d, 0x200
00007dd8c99cf6c2  cmp r12, r11
00007dd8c99cf6c5  cmc
00007dd8c99cf6c6  lahf
00007dd8c99cf6c7  seto al
00007dd8c99cf6ca  mov [r15+0x108], eax
00007dd8c99cf6d1  vmovaps xmm10, [rsp+0x110]
00007dd8c99cf6da  vmovaps xmm2, [rsp+0xE0]
00007dd8c99cf6e3  vmovaps [rsp+0xE0], xmm1
00007dd8c99cf6ec  movaps xmm15, xmm10
00007dd8c99cf6f0  addpd xmm15, xmm2
00007dd8c99cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8c99cf6fb  ptest xmm1, xmm1
00007dd8c99cf700  jnz 0x00007DD8C99D0E10
00007dd8c99cf706  vmovaps xmm10, [rsp+0x120]
00007dd8c99cf70f  vmovaps [rsp+0x110], xmm15
00007dd8c99cf718  movaps xmm1, xmm10
00007dd8c99cf71c  addpd xmm1, xmm12
00007dd8c99cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd8c99cf726  ptest xmm15, xmm15
00007dd8c99cf72c  jnz 0x00007DD8C99D0F53
00007dd8c99cf732  vmovaps xmm10, [rsp+0xC0]
00007dd8c99cf73b  vmovaps [rsp+0xC0], xmm1
00007dd8c99cf744  movaps xmm15, xmm10
00007dd8c99cf748  addpd xmm15, xmm12
00007dd8c99cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8c99cf753  ptest xmm1, xmm1
00007dd8c99cf758  jnz 0x00007DD8C99D1095
00007dd8c99cf75e  vmovaps xmm1, [rsp+0x30]
00007dd8c99cf764  vmovaps xmm12, [rsp+0x30]
00007dd8c99cf76a  por xmm1, xmm12
00007dd8c99cf76f  vmovaps xmm12, [rsp+0x20]
00007dd8c99cf775  vmovaps xmm10, [rsp+0x20]
00007dd8c99cf77b  por xmm12, xmm10
00007dd8c99cf780  vmovaps [rsp+0x20], xmm5
00007dd8c99cf786  vmovaps xmm10, [rsp+0x20]
00007dd8c99cf78c  por xmm5, xmm10
00007dd8c99cf791  vmovaps [rsp+0x20], xmm11
00007dd8c99cf797  vmovaps xmm10, [rsp+0x20]
00007dd8c99cf79d  por xmm11, xmm10
00007dd8c99cf7a2  vmovaps [rsp+0x20], xmm4
00007dd8c99cf7a8  vmovaps xmm10, [rsp+0x20]
00007dd8c99cf7ae  por xmm4, xmm10
00007dd8c99cf7b3  vmovaps [rsp+0x20], xmm8
00007dd8c99cf7b9  vmovaps xmm10, [rsp+0x20]
00007dd8c99cf7bf  por xmm8, xmm10
00007dd8c99cf7c4  vmovaps xmm10, [rsp+0xF0]
00007dd8c99cf7cd  vmovaps [rsp+0x20], xmm1
00007dd8c99cf7d3  vmovaps xmm1, [rsp+0xF0]
00007dd8c99cf7dc  por xmm10, xmm1
00007dd8c99cf7e1  lea rax, [r14+0xA0]
00007dd8c99cf7e8  movups xmm1, [r13+rax*1]
00007dd8c99cf7ee  lea rax, [r14+0xB0]
00007dd8c99cf7f5  vmovaps [rsp+0x30], xmm1
00007dd8c99cf7fb  movups xmm1, [r13+rax*1]
00007dd8c99cf801  vmovaps [rsp+0xF0], xmm1
00007dd8c99cf80a  vmovaps [rsp+0x120], xmm15
00007dd8c99cf813  movaps xmm1, xmm13
00007dd8c99cf817  addpd xmm1, xmm2
00007dd8c99cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd8c99cf820  ptest xmm15, xmm15
00007dd8c99cf826  jnz 0x00007DD8C99D11ED
00007dd8c99cf82c  lea rax, [r14+0xF0]
00007dd8c99cf833  movups xmm15, [r13+rax*1]
00007dd8c99cf839  vmovaps xmm2, [rsp+0xC0]
00007dd8c99cf842  vmovaps [rsp+0xC0], xmm1
00007dd8c99cf84b  vmovaps xmm1, [rsp+0xE0]
00007dd8c99cf854  vmovaps [rsp+0xE0], xmm15
00007dd8c99cf85d  movaps xmm13, xmm2
00007dd8c99cf861  addpd xmm13, xmm1
00007dd8c99cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007dd8c99cf86c  ptest xmm15, xmm15
00007dd8c99cf872  jnz 0x00007DD8C99D1338
00007dd8c99cf878  vmovaps xmm15, [rsp+0x120]
00007dd8c99cf881  vmovaps xmm2, [rsp+0xD0]
00007dd8c99cf88a  vmovaps [rsp+0xD0], xmm14
00007dd8c99cf893  movaps xmm1, xmm15
00007dd8c99cf897  addpd xmm1, xmm2
00007dd8c99cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd8c99cf8a0  ptest xmm14, xmm14
00007dd8c99cf8a6  jnz 0x00007DD8C99D147A
00007dd8c99cf8ac  vmovaps xmm15, [rsp+0x100]
00007dd8c99cf8b5  vpermilpd xmm15, xmm15, 0x00
00007dd8c99cf8bb  vmovaps xmm2, [rsp+0xF0]
00007dd8c99cf8c4  vmovaps [rsp+0xF0], xmm1
00007dd8c99cf8cd  movaps xmm14, xmm2
00007dd8c99cf8d1  mulpd xmm14, xmm15
00007dd8c99cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007dd8c99cf8dc  ptest xmm1, xmm1
00007dd8c99cf8e1  jnz 0x00007DD8C99D15BB
00007dd8c99cf8e7  vmovaps xmm1, [rsp+0xA0]
00007dd8c99cf8f0  vpermilpd xmm1, xmm1, 0x00
00007dd8c99cf8f6  vmovaps xmm2, [rsp+0xE0]
00007dd8c99cf8ff  vmovaps [rsp+0xE0], xmm14
00007dd8c99cf908  movaps xmm15, xmm2
00007dd8c99cf90c  mulpd xmm15, xmm1
00007dd8c99cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007dd8c99cf917  ptest xmm14, xmm14
00007dd8c99cf91d  jnz 0x00007DD8C99D16FE
00007dd8c99cf923  lea rax, [r14+0xE0]
00007dd8c99cf92a  movups xmm1, [r13+rax*1]
00007dd8c99cf930  vmovaps xmm14, [rsp+0x100]
00007dd8c99cf939  vpermilpd xmm14, xmm14, 0x00
00007dd8c99cf93f  vmovaps [rsp+0x100], xmm1
00007dd8c99cf948  vmovaps xmm1, [rsp+0x30]
00007dd8c99cf94e  vmovaps [rsp+0x30], xmm15
00007dd8c99cf954  movaps xmm2, xmm1
00007dd8c99cf957  mulpd xmm2, xmm14
00007dd8c99cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007dd8c99cf961  ptest xmm15, xmm15
00007dd8c99cf967  jnz 0x00007DD8C99D184A
00007dd8c99cf96d  vmovaps [rsp+0x120], xmm10
00007dd8c99cf976  vmovaps xmm1, [rsp+0x120]
00007dd8c99cf97f  por xmm10, xmm1
00007dd8c99cf984  movaps [r15+0x300], xmm10
00007dd8c99cf98c  vmovaps [rsp+0x120], xmm8
00007dd8c99cf995  vmovaps xmm1, [rsp+0x120]
00007dd8c99cf99e  por xmm8, xmm1
00007dd8c99cf9a3  movaps [r15+0x190], xmm8
00007dd8c99cf9ab  vmovaps xmm1, [rsp+0xA0]
00007dd8c99cf9b4  vpermilpd xmm1, xmm1, 0x00
00007dd8c99cf9ba  vmovaps xmm14, [rsp+0x100]
00007dd8c99cf9c3  vmovaps [rsp+0x100], xmm13
00007dd8c99cf9cc  movaps xmm15, xmm14
00007dd8c99cf9d0  mulpd xmm15, xmm1
00007dd8c99cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007dd8c99cf9db  ptest xmm13, xmm13
00007dd8c99cf9e1  jnz 0x00007DD8C99D198B
00007dd8c99cf9e7  lea rax, [r14+0x90]
00007dd8c99cf9ee  movups xmm1, [r13+rax*1]
00007dd8c99cf9f4  vmovaps [rsp+0x120], xmm4
00007dd8c99cf9fd  vmovaps xmm14, [rsp+0x120]
00007dd8c99cfa06  por xmm4, xmm14
00007dd8c99cfa0b  movaps [r15+0x1C0], xmm4
00007dd8c99cfa13  vmovaps [rsp+0x120], xmm11
00007dd8c99cfa1c  vmovaps xmm14, [rsp+0x120]
00007dd8c99cfa25  por xmm11, xmm14
00007dd8c99cfa2a  movaps [r15+0x200], xmm11
00007dd8c99cfa32  vmovaps [rsp+0x120], xmm5
00007dd8c99cfa3b  vmovaps xmm14, [rsp+0x120]
00007dd8c99cfa44  por xmm5, xmm14
00007dd8c99cfa49  movaps [r15+0x2D0], xmm5
00007dd8c99cfa51  vmovaps [rsp+0x120], xmm12
00007dd8c99cfa5a  vmovaps xmm14, [rsp+0x120]
00007dd8c99cfa63  por xmm12, xmm14
00007dd8c99cfa68  movaps [r15+0x2E0], xmm12
00007dd8c99cfa70  vmovaps xmm13, [rsp+0x110]
00007dd8c99cfa79  vmovaps [rsp+0x110], xmm1
00007dd8c99cfa82  vmovaps xmm1, [rsp+0xE0]
00007dd8c99cfa8b  vmovaps [rsp+0xE0], xmm15
00007dd8c99cfa94  movaps xmm14, xmm13
00007dd8c99cfa98  addpd xmm14, xmm1
00007dd8c99cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007dd8c99cfaa3  ptest xmm15, xmm15
00007dd8c99cfaa9  jnz 0x00007DD8C99D1AD8
00007dd8c99cfaaf  vmovaps xmm1, [rsp+0xA0]
00007dd8c99cfab8  vpermilpd xmm1, xmm1, 0x00
00007dd8c99cfabe  vmovaps xmm13, [rsp+0x110]
00007dd8c99cfac7  vmovaps [rsp+0x110], xmm14
00007dd8c99cfad0  movaps xmm15, xmm13
00007dd8c99cfad4  mulpd xmm15, xmm1
00007dd8c99cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007dd8c99cfadf  ptest xmm14, xmm14
00007dd8c99cfae5  jnz 0x00007DD8C99D1C1B
00007dd8c99cfaeb  lea rax, [r14+0x80]
00007dd8c99cfaf2  movups xmm1, [r13+rax*1]
00007dd8c99cfaf8  vmovaps xmm13, [rsp+0xC0]
00007dd8c99cfb01  vmovaps [rsp+0xC0], xmm1
00007dd8c99cfb0a  movaps xmm14, xmm13
00007dd8c99cfb0e  addpd xmm14, xmm2
00007dd8c99cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007dd8c99cfb19  ptest xmm1, xmm1
00007dd8c99cfb1e  jnz 0x00007DD8C99D1D68
00007dd8c99cfb24  vmovaps xmm13, [rsp+0x100]
00007dd8c99cfb2d  vmovaps xmm2, [rsp+0x30]
00007dd8c99cfb33  vmovaps [rsp+0x30], xmm15
00007dd8c99cfb39  movaps xmm1, xmm13
00007dd8c99cfb3d  addpd xmm1, xmm2
00007dd8c99cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd8c99cfb46  ptest xmm15, xmm15
00007dd8c99cfb4c  jnz 0x00007DD8C99D1EAB
00007dd8c99cfb52  vmovaps xmm15, [rsp+0x20]
00007dd8c99cfb58  vmovaps xmm13, [rsp+0x20]
00007dd8c99cfb5e  por xmm15, xmm13
00007dd8c99cfb63  movaps [r15+0x2F0], xmm15
00007dd8c99cfb6b  vmovaps xmm13, [rsp+0xA0]
00007dd8c99cfb74  vpermilpd xmm13, xmm13, 0x00
00007dd8c99cfb7a  vmovaps [rsp+0x20], xmm1
00007dd8c99cfb80  vmovaps xmm1, [rsp+0xC0]
00007dd8c99cfb89  vmovaps [rsp+0xA0], xmm15
00007dd8c99cfb92  movaps xmm2, xmm1
00007dd8c99cfb95  mulpd xmm2, xmm13
00007dd8c99cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007dd8c99cfb9f  ptest xmm15, xmm15
00007dd8c99cfba5  jnz 0x00007DD8C99D1FEC
00007dd8c99cfbab  lea rax, [r14+0xD0]
00007dd8c99cfbb2  movups xmm1, [r13+rax*1]
00007dd8c99cfbb8  vmovaps xmm13, [rsp+0xF0]
00007dd8c99cfbc1  vmovaps [rsp+0xC0], xmm1
00007dd8c99cfbca  vmovaps xmm1, [rsp+0xE0]
00007dd8c99cfbd3  vmovaps [rsp+0xE0], xmm14
00007dd8c99cfbdc  movaps xmm15, xmm13
00007dd8c99cfbe0  addpd xmm15, xmm1
00007dd8c99cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007dd8c99cfbeb  ptest xmm14, xmm14
00007dd8c99cfbf1  jnz 0x00007DD8C99D2137
00007dd8c99cfbf7  vmovaps xmm1, [rsp+0xB0]
00007dd8c99cfc00  vpermilpd xmm1, xmm1, 0x00
00007dd8c99cfc06  movaps xmm14, xmm11
00007dd8c99cfc0a  mulpd xmm14, xmm1
00007dd8c99cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007dd8c99cfc15  ptest xmm13, xmm13
00007dd8c99cfc1b  jnz 0x00007DD8C99D227A
00007dd8c99cfc21  movaps [r15+0x260], xmm14
00007dd8c99cfc29  vxorps xmm1, xmm1, xmm1
00007dd8c99cfc2d  vpbroadcastq xmm1, xmm1
00007dd8c99cfc32  movaps [r15+0x1B0], xmm1
00007dd8c99cfc3a  vmovaps xmm1, [rsp+0xB0]
00007dd8c99cfc43  vpermilpd xmm1, xmm1, 0x00
00007dd8c99cfc49  vmovaps xmm11, [rsp+0xC0]
00007dd8c99cfc52  vmovaps [rsp+0xC0], xmm15
00007dd8c99cfc5b  movaps xmm13, xmm11
00007dd8c99cfc5f  mulpd xmm13, xmm1
00007dd8c99cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007dd8c99cfc6a  ptest xmm15, xmm15
00007dd8c99cfc70  jnz 0x00007DD8C99D23BD
00007dd8c99cfc76  lea rax, [r14+0xC0]
00007dd8c99cfc7d  movups xmm1, [r13+rax*1]
00007dd8c99cfc83  vmovaps xmm11, [rsp+0x110]
00007dd8c99cfc8c  vmovaps [rsp+0xF0], xmm1
00007dd8c99cfc95  vmovaps xmm1, [rsp+0x30]
00007dd8c99cfc9b  vmovaps [rsp+0x30], xmm14
00007dd8c99cfca1  movaps xmm15, xmm11
00007dd8c99cfca5  addpd xmm15, xmm1
00007dd8c99cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007dd8c99cfcb0  ptest xmm14, xmm14
00007dd8c99cfcb6  jnz 0x00007DD8C99D250A
00007dd8c99cfcbc  vmovaps [rsp+0x100], xmm9
00007dd8c99cfcc5  vmovaps xmm1, [rsp+0x100]
00007dd8c99cfcce  por xmm9, xmm1
00007dd8c99cfcd3  movaps [r15+0x270], xmm9
00007dd8c99cfcdb  vmovaps [rsp+0x100], xmm6
00007dd8c99cfce4  vmovaps xmm1, [rsp+0x100]
00007dd8c99cfced  por xmm6, xmm1
00007dd8c99cfcf1  movaps [r15+0x1A0], xmm6
00007dd8c99cfcf9  vmovaps xmm14, [rsp+0xB0]
00007dd8c99cfd02  vpermilpd xmm14, xmm14, 0x00
00007dd8c99cfd08  vmovaps xmm6, [rsp+0xF0]
00007dd8c99cfd11  vmovaps [rsp+0xF0], xmm1
00007dd8c99cfd1a  movaps xmm11, xmm6
00007dd8c99cfd1e  mulpd xmm11, xmm14
00007dd8c99cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007dd8c99cfd29  ptest xmm1, xmm1
00007dd8c99cfd2e  jnz 0x00007DD8C99D264D
00007dd8c99cfd34  lea rax, [r14+0x20]
00007dd8c99cfd38  movups xmm1, [r13+rax*1]
00007dd8c99cfd3e  movaps [r15+0x110], xmm1
00007dd8c99cfd46  vmovaps xmm6, [rsp+0xE0]
00007dd8c99cfd4f  vmovaps [rsp+0xE0], xmm1
00007dd8c99cfd58  movaps xmm14, xmm6
00007dd8c99cfd5c  addpd xmm14, xmm2
00007dd8c99cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007dd8c99cfd67  ptest xmm1, xmm1
00007dd8c99cfd6c  jnz 0x00007DD8C99D279A
00007dd8c99cfd72  vmovaps xmm1, [rsp+0xB0]
00007dd8c99cfd7b  vpermilpd xmm1, xmm1, 0x00
00007dd8c99cfd81  movaps xmm6, xmm5
00007dd8c99cfd84  mulpd xmm6, xmm1
00007dd8c99cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007dd8c99cfd8d  ptest xmm2, xmm2
00007dd8c99cfd92  jnz 0x00007DD8C99D28DC
00007dd8c99cfd98  vmovaps xmm5, [rsp+0x20]
00007dd8c99cfd9e  movaps xmm1, xmm5
00007dd8c99cfda1  addpd xmm1, xmm13
00007dd8c99cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd8c99cfdab  ptest xmm2, xmm2
00007dd8c99cfdb0  jnz 0x00007DD8C99D2A1C
00007dd8c99cfdb6  vmovaps xmm13, [rsp+0x80]
00007dd8c99cfdbf  vpermilpd xmm13, xmm13, 0x00
00007dd8c99cfdc5  vmovaps xmm2, [rsp+0xE0]
00007dd8c99cfdce  vmovaps [rsp+0x20], xmm1
00007dd8c99cfdd4  movaps xmm5, xmm2
00007dd8c99cfdd7  mulpd xmm5, xmm13
00007dd8c99cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007dd8c99cfde1  ptest xmm1, xmm1
00007dd8c99cfde6  jnz 0x00007DD8C99D2B5D
00007dd8c99cfdec  vmovaps xmm1, [rsp+0x80]
00007dd8c99cfdf5  vpermilpd xmm1, xmm1, 0x00
00007dd8c99cfdfb  movaps xmm13, xmm10
00007dd8c99cfdff  mulpd xmm13, xmm1
00007dd8c99cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007dd8c99cfe0a  ptest xmm2, xmm2
00007dd8c99cfe0f  jnz 0x00007DD8C99D2C9E
00007dd8c99cfe15  vmovaps xmm10, [rsp+0x30]
00007dd8c99cfe1b  movaps xmm1, xmm15
00007dd8c99cfe1f  addpd xmm1, xmm10
00007dd8c99cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd8c99cfe29  ptest xmm2, xmm2
00007dd8c99cfe2e  jnz 0x00007DD8C99D2DE1
00007dd8c99cfe34  vmovaps xmm10, [rsp+0xC0]
00007dd8c99cfe3d  movaps xmm15, xmm10
00007dd8c99cfe41  addpd xmm15, xmm11
00007dd8c99cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007dd8c99cfe4c  ptest xmm2, xmm2
00007dd8c99cfe51  jnz 0x00007DD8C99D2F23
00007dd8c99cfe57  vmovaps xmm11, [rsp+0x80]
00007dd8c99cfe60  vpermilpd xmm11, xmm11, 0x00
00007dd8c99cfe66  movaps xmm10, xmm12
00007dd8c99cfe6a  mulpd xmm10, xmm11
00007dd8c99cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007dd8c99cfe75  ptest xmm2, xmm2
00007dd8c99cfe7a  jnz 0x00007DD8C99D3067
00007dd8c99cfe80  vmovaps xmm12, [rsp+0x80]
00007dd8c99cfe89  vpermilpd xmm12, xmm12, 0x00
00007dd8c99cfe8f  vmovaps xmm2, [rsp+0xA0]
00007dd8c99cfe98  vmovaps [rsp+0x30], xmm1
00007dd8c99cfe9e  movaps xmm11, xmm2
00007dd8c99cfea2  mulpd xmm11, xmm12
00007dd8c99cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007dd8c99cfead  ptest xmm1, xmm1
00007dd8c99cfeb2  jnz 0x00007DD8C99D31AB
00007dd8c99cfeb8  movaps xmm1, xmm14
00007dd8c99cfebc  addpd xmm1, xmm6
00007dd8c99cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd8c99cfec5  ptest xmm12, xmm12
00007dd8c99cfecb  jnz 0x00007DD8C99D32EE
00007dd8c99cfed1  vmovaps xmm12, [rsp+0x20]
00007dd8c99cfed7  movaps xmm14, xmm12
00007dd8c99cfedb  addpd xmm14, xmm5
00007dd8c99cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007dd8c99cfee6  ptest xmm6, xmm6
00007dd8c99cfeeb  jnz 0x00007DD8C99D342F
00007dd8c99cfef1  vmovaps xmm12, [rsp+0x90]
00007dd8c99cfefa  vpermilpd xmm12, xmm12, 0x00
00007dd8c99cff00  movaps xmm6, xmm9
00007dd8c99cff04  mulpd xmm6, xmm12
00007dd8c99cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd8c99cff0e  ptest xmm5, xmm5
00007dd8c99cff13  jnz 0x00007DD8C99D3572
00007dd8c99cff19  movaps xmm12, xmm15
00007dd8c99cff1d  addpd xmm12, xmm13
00007dd8c99cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007dd8c99cff28  ptest xmm9, xmm9
00007dd8c99cff2e  jnz 0x00007DD8C99D36B4
00007dd8c99cff34  vmovaps xmm13, [rsp+0x30]
00007dd8c99cff3a  movaps xmm15, xmm13
00007dd8c99cff3e  addpd xmm15, xmm10
00007dd8c99cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007dd8c99cff49  ptest xmm9, xmm9
00007dd8c99cff4f  jnz 0x00007DD8C99D37F8
00007dd8c99cff55  vmovaps xmm13, [rsp+0xD0]
00007dd8c99cff5e  vmovaps xmm10, [rsp+0xD0]
00007dd8c99cff67  por xmm13, xmm10
00007dd8c99cff6c  movaps [r15+0x250], xmm13
00007dd8c99cff74  vmovaps [rsp+0x20], xmm7
00007dd8c99cff7a  vmovaps xmm13, [rsp+0x20]
00007dd8c99cff80  por xmm7, xmm13
00007dd8c99cff85  movaps [r15+0x2A0], xmm7
00007dd8c99cff8d  vmovaps [rsp+0x20], xmm3
00007dd8c99cff93  vmovaps xmm13, [rsp+0x20]
00007dd8c99cff99  por xmm3, xmm13
00007dd8c99cff9e  movaps [r15+0x1D0], xmm3
00007dd8c99cffa6  lea rax, [r14+0x40]
00007dd8c99cffaa  movups xmm13, [r13+rax*1]
00007dd8c99cffb0  movaps [r15+0x2C0], xmm13
00007dd8c99cffb8  vmovaps xmm10, [rsp+0x90]
00007dd8c99cffc1  vpermilpd xmm10, xmm10, 0x00
00007dd8c99cffc7  movaps xmm9, xmm8
00007dd8c99cffcb  mulpd xmm9, xmm10
00007dd8c99cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007dd8c99cffd6  ptest xmm5, xmm5
00007dd8c99cffdb  jnz 0x00007DD8C99D3946
00007dd8c99cffe1  movaps xmm10, xmm1
00007dd8c99cffe5  addpd xmm10, xmm11
00007dd8c99cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007dd8c99cfff0  ptest xmm8, xmm8
00007dd8c99cfff6  jnz 0x00007DD8C99D3A8A
00007dd8c99cfffc  movaps xmm1, xmm14
00007dd8c99d0000  addpd xmm1, xmm6
00007dd8c99d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007dd8c99d0009  ptest xmm11, xmm11
00007dd8c99d000f  jnz 0x00007DD8C99D3BCD
00007dd8c99d0015  vmovaps xmm14, [rsp+0x90]
00007dd8c99d001e  vpermilpd xmm14, xmm14, 0x00
00007dd8c99d0024  movaps xmm11, xmm13
00007dd8c99d0028  mulpd xmm11, xmm14
00007dd8c99d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007dd8c99d0033  ptest xmm8, xmm8
00007dd8c99d0039  jnz 0x00007DD8C99D3D0E
00007dd8c99d003f  vmovaps xmm14, [rsp+0x90]
00007dd8c99d0048  vpermilpd xmm14, xmm14, 0x00
00007dd8c99d004e  vmovaps xmm8, [rsp+0x10]
00007dd8c99d0054  movaps xmm13, xmm8
00007dd8c99d0058  mulpd xmm13, xmm14
00007dd8c99d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007dd8c99d0063  ptest xmm6, xmm6
00007dd8c99d0068  jnz 0x00007DD8C99D3E52
00007dd8c99d006e  vmovaps xmm14, [rsp+0x60]
00007dd8c99d0074  vpermilpd xmm14, xmm14, 0x00
00007dd8c99d007a  movaps xmm8, xmm7
00007dd8c99d007e  mulpd xmm8, xmm14
00007dd8c99d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd8c99d0089  ptest xmm6, xmm6
00007dd8c99d008e  jnz 0x00007DD8C99D3F96
00007dd8c99d0094  movaps xmm14, xmm12
00007dd8c99d0098  addpd xmm14, xmm9
00007dd8c99d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007dd8c99d00a3  ptest xmm7, xmm7
00007dd8c99d00a8  jnz 0x00007DD8C99D40D9
00007dd8c99d00ae  vmovaps xmm12, [rsp+0x60]
00007dd8c99d00b4  vpermilpd xmm12, xmm12, 0x00
00007dd8c99d00ba  vmovaps xmm7, [rsp+0xF0]
00007dd8c99d00c3  movaps xmm9, xmm7
00007dd8c99d00c7  mulpd xmm9, xmm12
00007dd8c99d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd8c99d00d2  ptest xmm6, xmm6
00007dd8c99d00d7  jnz 0x00007DD8C99D421D
00007dd8c99d00dd  movaps xmm12, xmm15
00007dd8c99d00e1  addpd xmm12, xmm11
00007dd8c99d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007dd8c99d00ec  ptest xmm7, xmm7
00007dd8c99d00f1  jnz 0x00007DD8C99D4360
00007dd8c99d00f7  vmovaps xmm15, [rsp+0x60]
00007dd8c99d00fd  vpermilpd xmm15, xmm15, 0x00
00007dd8c99d0103  vmovaps xmm7, [rsp+0x40]
00007dd8c99d0109  movaps xmm11, xmm7
00007dd8c99d010d  mulpd xmm11, xmm15
00007dd8c99d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007dd8c99d0118  ptest xmm6, xmm6
00007dd8c99d011d  jnz 0x00007DD8C99D44A4
00007dd8c99d0123  movaps xmm15, xmm10
00007dd8c99d0127  addpd xmm15, xmm13
00007dd8c99d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007dd8c99d0132  ptest xmm7, xmm7
00007dd8c99d0137  jnz 0x00007DD8C99D45E7
00007dd8c99d013d  vmovaps xmm13, [rsp+0x60]
00007dd8c99d0143  vpermilpd xmm13, xmm13, 0x00
00007dd8c99d0149  vmovaps xmm7, [rsp+0x50]
00007dd8c99d014f  movaps xmm10, xmm7
00007dd8c99d0153  mulpd xmm10, xmm13
00007dd8c99d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007dd8c99d015e  ptest xmm6, xmm6
00007dd8c99d0163  jnz 0x00007DD8C99D472B
00007dd8c99d0169  movaps xmm13, xmm1
00007dd8c99d016d  addpd xmm13, xmm8
00007dd8c99d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007dd8c99d0178  ptest xmm7, xmm7
00007dd8c99d017d  jnz 0x00007DD8C99D486E
00007dd8c99d0183  lea rax, [r14+0x70]
00007dd8c99d0187  movups xmm1, [r13+rax*1]
00007dd8c99d018d  movaps [r15+0x240], xmm1
00007dd8c99d0195  movaps xmm8, xmm14
00007dd8c99d0199  addpd xmm8, xmm9
00007dd8c99d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd8c99d01a4  ptest xmm7, xmm7
00007dd8c99d01a9  jnz 0x00007DD8C99D49BB
00007dd8c99d01af  movaps [r15+0x170], xmm8
00007dd8c99d01b7  vmovaps xmm14, [rsp+0x70]
00007dd8c99d01bd  vpermilpd xmm14, xmm14, 0x00
00007dd8c99d01c3  movaps xmm9, xmm1
00007dd8c99d01c7  mulpd xmm9, xmm14
00007dd8c99d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007dd8c99d01d2  ptest xmm7, xmm7
00007dd8c99d01d7  jnz 0x00007DD8C99D4AFF
00007dd8c99d01dd  vmovaps xmm1, [rsp+0x70]
00007dd8c99d01e3  vpermilpd xmm1, xmm1, 0x00
00007dd8c99d01e9  movaps xmm14, xmm4
00007dd8c99d01ed  mulpd xmm14, xmm1
00007dd8c99d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007dd8c99d01f8  ptest xmm7, xmm7
00007dd8c99d01fd  jnz 0x00007DD8C99D4C42
00007dd8c99d0203  movaps [r15+0x180], xmm14
00007dd8c99d020b  movaps xmm1, xmm12
00007dd8c99d020f  addpd xmm1, xmm11
00007dd8c99d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007dd8c99d0219  ptest xmm7, xmm7
00007dd8c99d021e  jnz 0x00007DD8C99D4D84
00007dd8c99d0224  movaps [r15+0x210], xmm1
00007dd8c99d022c  movups xmm12, [r13+r14*1]
00007dd8c99d0232  lea rax, [r14+0x10]
00007dd8c99d0236  movups xmm11, [r13+rax*1]
00007dd8c99d023c  movaps [r15+0x230], xmm11
00007dd8c99d0244  movaps xmm7, xmm15
00007dd8c99d0248  addpd xmm7, xmm10
00007dd8c99d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8c99d0252  ptest xmm6, xmm6
00007dd8c99d0257  jnz 0x00007DD8C99D4EDA
00007dd8c99d025d  movaps [r15+0x130], xmm7
00007dd8c99d0265  vmovaps xmm15, [rsp+0x70]
00007dd8c99d026b  vpermilpd xmm15, xmm15, 0x00
00007dd8c99d0271  movaps xmm10, xmm11
00007dd8c99d0275  mulpd xmm10, xmm15
00007dd8c99d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007dd8c99d0280  ptest xmm6, xmm6
00007dd8c99d0285  jnz 0x00007DD8C99D501C
00007dd8c99d028b  movaps [r15+0x220], xmm10
00007dd8c99d0293  vmovaps xmm15, [rsp+0x70]
00007dd8c99d0299  vpermilpd xmm15, xmm15, 0x00
00007dd8c99d029f  movaps xmm11, xmm12
00007dd8c99d02a3  mulpd xmm11, xmm15
00007dd8c99d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007dd8c99d02ae  ptest xmm6, xmm6
00007dd8c99d02b3  jnz 0x00007DD8C99D5160
00007dd8c99d02b9  movaps xmm15, xmm13
00007dd8c99d02bd  addpd xmm15, xmm9
00007dd8c99d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007dd8c99d02c8  ptest xmm12, xmm12
00007dd8c99d02ce  jnz 0x00007DD8C99D52A4
00007dd8c99d02d4  movaps [r15+0x140], xmm15
00007dd8c99d02dc  movaps xmm13, xmm8
00007dd8c99d02e0  addpd xmm13, xmm14
00007dd8c99d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007dd8c99d02eb  ptest xmm12, xmm12
00007dd8c99d02f1  jnz 0x00007DD8C99D53E8
00007dd8c99d02f7  movaps [r15+0x150], xmm13
00007dd8c99d02ff  movaps xmm14, xmm1
00007dd8c99d0303  addpd xmm14, xmm10
00007dd8c99d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007dd8c99d030e  ptest xmm12, xmm12
00007dd8c99d0314  jnz 0x00007DD8C99D552C
00007dd8c99d031a  movaps [r15+0x160], xmm14
00007dd8c99d0322  movaps xmm1, xmm7
00007dd8c99d0325  addpd xmm1, xmm11
00007dd8c99d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd8c99d032f  ptest xmm12, xmm12
00007dd8c99d0335  jnz 0x00007DD8C99D566F
00007dd8c99d033b  movaps [r15+0x120], xmm1
00007dd8c99d0343  mov eax, 0x430920
00007dd8c99d0348  movups [r13+rax*1], xmm15
00007dd8c99d034e  mov eax, 0x430930
00007dd8c99d0353  movups [r13+rax*1], xmm13
00007dd8c99d0359  mov eax, 0x430940
00007dd8c99d035e  movups [r13+rax*1], xmm14
00007dd8c99d0364  mov eax, 0x430950
00007dd8c99d0369  movups [r13+rax*1], xmm1
00007dd8c99d036f  mov eax, [r15+0x108]
00007dd8c99d0376  sahf
00007dd8c99d0377  jnz 0x00007DD8C99D03A9
00007dd8c99d0379  cmp dword ptr [r15+0x318], 0x00
00007dd8c99d0381  jz 0x00007DD8C99DB900
00007dd8c99d0387  nop [rax+rax*1], ax
00007dd8c99d0390  nop [rax+rax*1], eax
00007dd8c99d0398  mov eax, 0x410444
00007dd8c99d039d  mov [r15+0x100], rax
00007dd8c99d03a4  jmp 0x00007DD8C97FE110
00007dd8c99d03a9  cmp dword ptr [r15+0x318], 0x00
00007dd8c99d03b1  jz 0x00007DD8C99D57E0
00007dd8c99d03b7  nop [rax+rax*1], ax
00007dd8c99d03c0  nop [rax+rax*1], eax
00007dd8c99d03c8  mov eax, 0x410278
00007dd8c99d03cd  mov [r15+0x100], rax
00007dd8c99d03d4  jmp 0x00007DD8C97FE110
00007dd8c99d03d9  int3
00007dd8c99d03da  call 0x00007DD8C98B52F0
00007dd8c99d03df  jmp 0x00007DD8C99CF016
00007dd8c99d03e4  call 0x00007DD8C98C4620
00007dd8c99d03e9  jmp 0x00007DD8C99CF023
00007dd8c99d03ee  call 0x00007DD8C98C33A0
00007dd8c99d03f3  jmp 0x00007DD8C99CF035
00007dd8c99d03f8  call 0x00007DD8C98C2120
00007dd8c99d03fd  jmp 0x00007DD8C99CF03F
00007dd8c99d0402  call 0x00007DD8C98C0860
00007dd8c99d0407  jmp 0x00007DD8C99CF067
00007dd8c99d040c  call 0x00007DD8C98BF5F0
00007dd8c99d0411  jmp 0x00007DD8C99CF073
00007dd8c99d0416  call 0x00007DD8C98C0860
00007dd8c99d041b  jmp 0x00007DD8C99CF0A5
00007dd8c99d0420  call 0x00007DD8C98BF5F0
00007dd8c99d0425  jmp 0x00007DD8C99CF0B1
00007dd8c99d042a  call 0x00007DD8C98C4740
00007dd8c99d042f  jmp 0x00007DD8C99CF0BE
00007dd8c99d0434  call 0x00007DD8C98B5400
00007dd8c99d0439  jmp 0x00007DD8C99CF0CB
00007dd8c99d043e  call 0x00007DD8C98B52F0
00007dd8c99d0443  jmp 0x00007DD8C99CF0D8
00007dd8c99d0448  call 0x00007DD8C98C4620
00007dd8c99d044d  jmp 0x00007DD8C99CF0E5
00007dd8c99d0452  call 0x00007DD8C98C0860
00007dd8c99d0457  jmp 0x00007DD8C99CF10D
00007dd8c99d045c  call 0x00007DD8C98BF5F0
00007dd8c99d0461  jmp 0x00007DD8C99CF119
00007dd8c99d0466  call 0x00007DD8C9809D70
00007dd8c99d046b  jmp 0x00007DD8C99CF11F
00007dd8c99d0470  call 0x00007DD8C98BE9C0
00007dd8c99d0475  jmp 0x00007DD8C99CF129
00007dd8c99d047a  call 0x00007DD8C98C0860
00007dd8c99d047f  jmp 0x00007DD8C99CF151
00007dd8c99d0484  call 0x00007DD8C98BF5F0
00007dd8c99d0489  jmp 0x00007DD8C99CF15D
00007dd8c99d048e  call 0x00007DD8C98BD750
00007dd8c99d0493  jmp 0x00007DD8C99CF16A
00007dd8c99d0498  call 0x00007DD8C98BC4E0
00007dd8c99d049d  jmp 0x00007DD8C99CF177
00007dd8c99d04a2  call 0x00007DD8C98C4740
00007dd8c99d04a7  jmp 0x00007DD8C99CF184
00007dd8c99d04ac  call 0x00007DD8C98B5400
00007dd8c99d04b1  jmp 0x00007DD8C99CF191
00007dd8c99d04b6  call 0x00007DD8C98B52F0
00007dd8c99d04bb  jmp 0x00007DD8C99CF19E
00007dd8c99d04c0  call 0x00007DD8C98C4620
00007dd8c99d04c5  jmp 0x00007DD8C99CF1AB
00007dd8c99d04ca  call 0x00007DD8C98C0860
00007dd8c99d04cf  jmp 0x00007DD8C99CF1BE
00007dd8c99d04d4  call 0x00007DD8C98BB270
00007dd8c99d04d9  jmp 0x00007DD8C99CF1CB
00007dd8c99d04de  call 0x00007DD8C98BA000
00007dd8c99d04e3  jmp 0x00007DD8C99CF1D8
00007dd8c99d04e8  call 0x00007DD8C98B8D90
00007dd8c99d04ed  jmp 0x00007DD8C99CF1E5
00007dd8c99d04f2  call 0x00007DD8C98B8A20
00007dd8c99d04f7  jmp 0x00007DD8C99CF1F2
00007dd8c99d04fc  call 0x00007DD8C98B5400
00007dd8c99d0501  jmp 0x00007DD8C99CF1FC
00007dd8c99d0506  call 0x00007DD8C98C2240
00007dd8c99d050b  jmp 0x00007DD8C99CF206
00007dd8c99d0510  call 0x00007DD8C98B52F0
00007dd8c99d0515  jmp 0x00007DD8C99CF210
00007dd8c99d051a  call 0x00007DD8C98C2120
00007dd8c99d051f  jmp 0x00007DD8C99CF21A
00007dd8c99d0524  call 0x00007DD8C98B77B0
00007dd8c99d0529  jmp 0x00007DD8C99CF224
00007dd8c99d052e  call 0x00007DD8C98B6550
00007dd8c99d0533  jmp 0x00007DD8C99CF22E
00007dd8c99d0538  call 0x00007DD8C98BFD50
00007dd8c99d053d  jmp 0x00007DD8C99CF240
00007dd8c99d0542  call 0x00007DD8C98B8EA0
00007dd8c99d0547  jmp 0x00007DD8C99CF24A
00007dd8c99d054c  call 0x00007DD8C98BFC30
00007dd8c99d0551  jmp 0x00007DD8C99CF257
00007dd8c99d0556  call 0x00007DD8C98B8D90
00007dd8c99d055b  jmp 0x00007DD8C99CF264
00007dd8c99d0560  call 0x00007DD8C98C2240
00007dd8c99d0565  jmp 0x00007DD8C99CF271
00007dd8c99d056a  call 0x00007DD8C98B5400
00007dd8c99d056f  jmp 0x00007DD8C99CF27E
00007dd8c99d0574  call 0x00007DD8C98B52F0
00007dd8c99d0579  jmp 0x00007DD8C99CF28B
00007dd8c99d057e  call 0x00007DD8C98C2120
00007dd8c99d0583  jmp 0x00007DD8C99CF298
00007dd8c99d0588  call 0x00007DD8C98B52F0
00007dd8c99d058d  jmp 0x00007DD8C99CF2AB
00007dd8c99d0592  call 0x00007DD8C98B52F0
00007dd8c99d0597  jmp 0x00007DD8C99CF2BE
00007dd8c99d059c  call 0x00007DD8C98B52F0
00007dd8c99d05a1  jmp 0x00007DD8C99CF2D1
00007dd8c99d05a6  call 0x00007DD8C98B52F0
00007dd8c99d05ab  jmp 0x00007DD8C99CF2E4
00007dd8c99d05b0  call 0x00007DD8C98C2240
00007dd8c99d05b5  jmp 0x00007DD8C99CF2F9
00007dd8c99d05ba  call 0x00007DD8C98C2240
00007dd8c99d05bf  jmp 0x00007DD8C99CF30C
00007dd8c99d05c4  call 0x00007DD8C98C2120
00007dd8c99d05c9  jmp 0x00007DD8C99CF319
00007dd8c99d05ce  call 0x00007DD8C98B52F0
00007dd8c99d05d3  jmp 0x00007DD8C99CF32C
00007dd8c99d05d8  call 0x00007DD8C98B52F0
00007dd8c99d05dd  jmp 0x00007DD8C99CF34F
00007dd8c99d05e2  call 0x00007DD8C98B52F0
00007dd8c99d05e7  jmp 0x00007DD8C99CF362
00007dd8c99d05ec  call 0x00007DD8C97FF540
00007dd8c99d05f1  jmp 0x00007DD8C99CF380
00007dd8c99d05f6  call 0x00007DD8C9808C20
00007dd8c99d05fb  jmp 0x00007DD8C99CF38A
00007dd8c99d0600  call 0x00007DD8C98D6600
00007dd8c99d0605  jmp 0x00007DD8C99CF396
00007dd8c99d060a  call 0x00007DD8C97FF540
00007dd8c99d060f  jmp 0x00007DD8C99CF3A6
00007dd8c99d0614  call 0x00007DD8C98C0370
00007dd8c99d0619  jmp 0x00007DD8C99CF3D4
00007dd8c99d061e  call 0x00007DD8C98BF100
00007dd8c99d0623  jmp 0x00007DD8C99CF3DD
00007dd8c99d0628  call 0x00007DD8C98C0370
00007dd8c99d062d  jmp 0x00007DD8C99CF43B
00007dd8c99d0632  call 0x00007DD8C98BF100
00007dd8c99d0637  jmp 0x00007DD8C99CF444
00007dd8c99d063c  call 0x00007DD8C98C0370
00007dd8c99d0641  jmp 0x00007DD8C99CF48B
00007dd8c99d0646  call 0x00007DD8C98BF100
00007dd8c99d064b  jmp 0x00007DD8C99CF494
00007dd8c99d0650  call 0x00007DD8C980B720
00007dd8c99d0655  jmp 0x00007DD8C99CF4D7
00007dd8c99d065a  call 0x00007DD8C98B47C0
00007dd8c99d065f  jmp 0x00007DD8C99CF4EA
00007dd8c99d0664  call 0x00007DD8C9808B00
00007dd8c99d0669  jmp 0x00007DD8C99CF501
00007dd8c99d066e  call 0x00007DD8C97FF430
00007dd8c99d0673  jmp 0x00007DD8C99CF514
00007dd8c99d0678  call 0x00007DD8C97FF430
00007dd8c99d067d  jmp 0x00007DD8C99CF527
00007dd8c99d0682  sub rsp, 0x08
00007dd8c99d0686  push rax
00007dd8c99d0687  push rcx
00007dd8c99d0688  push rdx
00007dd8c99d0689  push rdi
00007dd8c99d068a  push rsi
00007dd8c99d068b  push r8
00007dd8c99d068d  push r9
00007dd8c99d068f  push r10
00007dd8c99d0691  push r11
00007dd8c99d0693  sub rsp, 0xF0
00007dd8c99d069a  vmovaps [rsp], xmm0
00007dd8c99d069f  vmovaps [rsp+0x10], xmm2
00007dd8c99d06a5  vmovaps [rsp+0x20], xmm3
00007dd8c99d06ab  vmovaps [rsp+0x30], xmm4
00007dd8c99d06b1  vmovaps [rsp+0x40], xmm5
00007dd8c99d06b7  vmovaps [rsp+0x50], xmm6
00007dd8c99d06bd  vmovaps [rsp+0x60], xmm7
00007dd8c99d06c3  vmovaps [rsp+0x70], xmm8
00007dd8c99d06c9  vmovaps [rsp+0x80], xmm9
00007dd8c99d06d2  vmovaps [rsp+0x90], xmm10
00007dd8c99d06db  vmovaps [rsp+0xA0], xmm11
00007dd8c99d06e4  vmovaps [rsp+0xB0], xmm12
00007dd8c99d06ed  vmovaps [rsp+0xC0], xmm13
00007dd8c99d06f6  vmovaps [rsp+0xD0], xmm14
00007dd8c99d06ff  vmovaps [rsp+0xE0], xmm15
00007dd8c99d0708  sub rsp, 0x30
00007dd8c99d070c  movaps [rsp], xmm1
00007dd8c99d0710  movaps [rsp+0x10], xmm15
00007dd8c99d0716  movaps [rsp+0x20], xmm14
00007dd8c99d071c  lea rdi, [rsp]
00007dd8c99d0720  mov esi, 0x00
00007dd8c99d0725  mov rax, 0x55FEBBDB5530
00007dd8c99d072f  call rax
00007dd8c99d0731  movaps xmm1, [rsp]
00007dd8c99d0735  add rsp, 0x30
00007dd8c99d0739  vmovaps xmm0, [rsp]
00007dd8c99d073e  vmovaps xmm2, [rsp+0x10]
00007dd8c99d0744  vmovaps xmm3, [rsp+0x20]
00007dd8c99d074a  vmovaps xmm4, [rsp+0x30]
00007dd8c99d0750  vmovaps xmm5, [rsp+0x40]
00007dd8c99d0756  vmovaps xmm6, [rsp+0x50]
00007dd8c99d075c  vmovaps xmm7, [rsp+0x60]
00007dd8c99d0762  vmovaps xmm8, [rsp+0x70]
00007dd8c99d0768  vmovaps xmm9, [rsp+0x80]
00007dd8c99d0771  vmovaps xmm10, [rsp+0x90]
00007dd8c99d077a  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d0783  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d078c  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d0795  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d079e  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d07a7  add rsp, 0xF0
00007dd8c99d07ae  pop r11
00007dd8c99d07b0  pop r10
00007dd8c99d07b2  pop r9
00007dd8c99d07b4  pop r8
00007dd8c99d07b6  pop rsi
00007dd8c99d07b7  pop rdi
00007dd8c99d07b8  pop rdx
00007dd8c99d07b9  pop rcx
00007dd8c99d07ba  pop rax
00007dd8c99d07bb  add rsp, 0x08
00007dd8c99d07bf  jmp 0x00007DD8C99CF581
00007dd8c99d07c4  sub rsp, 0x08
00007dd8c99d07c8  push rax
00007dd8c99d07c9  push rcx
00007dd8c99d07ca  push rdx
00007dd8c99d07cb  push rdi
00007dd8c99d07cc  push rsi
00007dd8c99d07cd  push r8
00007dd8c99d07cf  push r9
00007dd8c99d07d1  push r10
00007dd8c99d07d3  push r11
00007dd8c99d07d5  sub rsp, 0xF0
00007dd8c99d07dc  vmovaps [rsp], xmm0
00007dd8c99d07e1  vmovaps [rsp+0x10], xmm1
00007dd8c99d07e7  vmovaps [rsp+0x20], xmm2
00007dd8c99d07ed  vmovaps [rsp+0x30], xmm3
00007dd8c99d07f3  vmovaps [rsp+0x40], xmm4
00007dd8c99d07f9  vmovaps [rsp+0x50], xmm5
00007dd8c99d07ff  vmovaps [rsp+0x60], xmm6
00007dd8c99d0805  vmovaps [rsp+0x70], xmm7
00007dd8c99d080b  vmovaps [rsp+0x80], xmm8
00007dd8c99d0814  vmovaps [rsp+0x90], xmm9
00007dd8c99d081d  vmovaps [rsp+0xA0], xmm10
00007dd8c99d0826  vmovaps [rsp+0xB0], xmm11
00007dd8c99d082f  vmovaps [rsp+0xC0], xmm12
00007dd8c99d0838  vmovaps [rsp+0xD0], xmm14
00007dd8c99d0841  vmovaps [rsp+0xE0], xmm15
00007dd8c99d084a  sub rsp, 0x30
00007dd8c99d084e  movaps [rsp], xmm13
00007dd8c99d0853  movaps [rsp+0x10], xmm1
00007dd8c99d0858  movaps [rsp+0x20], xmm14
00007dd8c99d085e  lea rdi, [rsp]
00007dd8c99d0862  mov esi, 0x00
00007dd8c99d0867  mov rax, 0x55FEBBDB5530
00007dd8c99d0871  call rax
00007dd8c99d0873  movaps xmm13, [rsp]
00007dd8c99d0878  add rsp, 0x30
00007dd8c99d087c  vmovaps xmm0, [rsp]
00007dd8c99d0881  vmovaps xmm1, [rsp+0x10]
00007dd8c99d0887  vmovaps xmm2, [rsp+0x20]
00007dd8c99d088d  vmovaps xmm3, [rsp+0x30]
00007dd8c99d0893  vmovaps xmm4, [rsp+0x40]
00007dd8c99d0899  vmovaps xmm5, [rsp+0x50]
00007dd8c99d089f  vmovaps xmm6, [rsp+0x60]
00007dd8c99d08a5  vmovaps xmm7, [rsp+0x70]
00007dd8c99d08ab  vmovaps xmm8, [rsp+0x80]
00007dd8c99d08b4  vmovaps xmm9, [rsp+0x90]
00007dd8c99d08bd  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d08c6  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d08cf  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d08d8  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d08e1  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d08ea  add rsp, 0xF0
00007dd8c99d08f1  pop r11
00007dd8c99d08f3  pop r10
00007dd8c99d08f5  pop r9
00007dd8c99d08f7  pop r8
00007dd8c99d08f9  pop rsi
00007dd8c99d08fa  pop rdi
00007dd8c99d08fb  pop rdx
00007dd8c99d08fc  pop rcx
00007dd8c99d08fd  pop rax
00007dd8c99d08fe  add rsp, 0x08
00007dd8c99d0902  jmp 0x00007DD8C99CF5CF
00007dd8c99d0907  sub rsp, 0x08
00007dd8c99d090b  push rax
00007dd8c99d090c  push rcx
00007dd8c99d090d  push rdx
00007dd8c99d090e  push rdi
00007dd8c99d090f  push rsi
00007dd8c99d0910  push r8
00007dd8c99d0912  push r9
00007dd8c99d0914  push r10
00007dd8c99d0916  push r11
00007dd8c99d0918  sub rsp, 0xF0
00007dd8c99d091f  vmovaps [rsp], xmm0
00007dd8c99d0924  vmovaps [rsp+0x10], xmm1
00007dd8c99d092a  vmovaps [rsp+0x20], xmm2
00007dd8c99d0930  vmovaps [rsp+0x30], xmm3
00007dd8c99d0936  vmovaps [rsp+0x40], xmm4
00007dd8c99d093c  vmovaps [rsp+0x50], xmm5
00007dd8c99d0942  vmovaps [rsp+0x60], xmm6
00007dd8c99d0948  vmovaps [rsp+0x70], xmm7
00007dd8c99d094e  vmovaps [rsp+0x80], xmm8
00007dd8c99d0957  vmovaps [rsp+0x90], xmm9
00007dd8c99d0960  vmovaps [rsp+0xA0], xmm10
00007dd8c99d0969  vmovaps [rsp+0xB0], xmm11
00007dd8c99d0972  vmovaps [rsp+0xC0], xmm12
00007dd8c99d097b  vmovaps [rsp+0xD0], xmm13
00007dd8c99d0984  vmovaps [rsp+0xE0], xmm14
00007dd8c99d098d  sub rsp, 0x30
00007dd8c99d0991  movaps [rsp], xmm15
00007dd8c99d0996  movaps [rsp+0x10], xmm14
00007dd8c99d099c  movaps [rsp+0x20], xmm1
00007dd8c99d09a1  lea rdi, [rsp]
00007dd8c99d09a5  mov esi, 0x00
00007dd8c99d09aa  mov rax, 0x55FEBBDB5530
00007dd8c99d09b4  call rax
00007dd8c99d09b6  movaps xmm15, [rsp]
00007dd8c99d09bb  add rsp, 0x30
00007dd8c99d09bf  vmovaps xmm0, [rsp]
00007dd8c99d09c4  vmovaps xmm1, [rsp+0x10]
00007dd8c99d09ca  vmovaps xmm2, [rsp+0x20]
00007dd8c99d09d0  vmovaps xmm3, [rsp+0x30]
00007dd8c99d09d6  vmovaps xmm4, [rsp+0x40]
00007dd8c99d09dc  vmovaps xmm5, [rsp+0x50]
00007dd8c99d09e2  vmovaps xmm6, [rsp+0x60]
00007dd8c99d09e8  vmovaps xmm7, [rsp+0x70]
00007dd8c99d09ee  vmovaps xmm8, [rsp+0x80]
00007dd8c99d09f7  vmovaps xmm9, [rsp+0x90]
00007dd8c99d0a00  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d0a09  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d0a12  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d0a1b  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d0a24  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d0a2d  add rsp, 0xF0
00007dd8c99d0a34  pop r11
00007dd8c99d0a36  pop r10
00007dd8c99d0a38  pop r9
00007dd8c99d0a3a  pop r8
00007dd8c99d0a3c  pop rsi
00007dd8c99d0a3d  pop rdi
00007dd8c99d0a3e  pop rdx
00007dd8c99d0a3f  pop rcx
00007dd8c99d0a40  pop rax
00007dd8c99d0a41  add rsp, 0x08
00007dd8c99d0a45  jmp 0x00007DD8C99CF617
00007dd8c99d0a4a  sub rsp, 0x08
00007dd8c99d0a4e  push rax
00007dd8c99d0a4f  push rcx
00007dd8c99d0a50  push rdx
00007dd8c99d0a51  push rdi
00007dd8c99d0a52  push rsi
00007dd8c99d0a53  push r8
00007dd8c99d0a55  push r9
00007dd8c99d0a57  push r10
00007dd8c99d0a59  push r11
00007dd8c99d0a5b  sub rsp, 0xF0
00007dd8c99d0a62  vmovaps [rsp], xmm0
00007dd8c99d0a67  vmovaps [rsp+0x10], xmm2
00007dd8c99d0a6d  vmovaps [rsp+0x20], xmm3
00007dd8c99d0a73  vmovaps [rsp+0x30], xmm4
00007dd8c99d0a79  vmovaps [rsp+0x40], xmm5
00007dd8c99d0a7f  vmovaps [rsp+0x50], xmm6
00007dd8c99d0a85  vmovaps [rsp+0x60], xmm7
00007dd8c99d0a8b  vmovaps [rsp+0x70], xmm8
00007dd8c99d0a91  vmovaps [rsp+0x80], xmm9
00007dd8c99d0a9a  vmovaps [rsp+0x90], xmm10
00007dd8c99d0aa3  vmovaps [rsp+0xA0], xmm11
00007dd8c99d0aac  vmovaps [rsp+0xB0], xmm12
00007dd8c99d0ab5  vmovaps [rsp+0xC0], xmm13
00007dd8c99d0abe  vmovaps [rsp+0xD0], xmm14
00007dd8c99d0ac7  vmovaps [rsp+0xE0], xmm15
00007dd8c99d0ad0  sub rsp, 0x30
00007dd8c99d0ad4  movaps [rsp], xmm1
00007dd8c99d0ad8  movaps [rsp+0x10], xmm14
00007dd8c99d0ade  movaps [rsp+0x20], xmm10
00007dd8c99d0ae4  lea rdi, [rsp]
00007dd8c99d0ae8  mov esi, 0x00
00007dd8c99d0aed  mov rax, 0x55FEBBDB5530
00007dd8c99d0af7  call rax
00007dd8c99d0af9  movaps xmm1, [rsp]
00007dd8c99d0afd  add rsp, 0x30
00007dd8c99d0b01  vmovaps xmm0, [rsp]
00007dd8c99d0b06  vmovaps xmm2, [rsp+0x10]
00007dd8c99d0b0c  vmovaps xmm3, [rsp+0x20]
00007dd8c99d0b12  vmovaps xmm4, [rsp+0x30]
00007dd8c99d0b18  vmovaps xmm5, [rsp+0x40]
00007dd8c99d0b1e  vmovaps xmm6, [rsp+0x50]
00007dd8c99d0b24  vmovaps xmm7, [rsp+0x60]
00007dd8c99d0b2a  vmovaps xmm8, [rsp+0x70]
00007dd8c99d0b30  vmovaps xmm9, [rsp+0x80]
00007dd8c99d0b39  vmovaps xmm10, [rsp+0x90]
00007dd8c99d0b42  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d0b4b  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d0b54  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d0b5d  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d0b66  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d0b6f  add rsp, 0xF0
00007dd8c99d0b76  pop r11
00007dd8c99d0b78  pop r10
00007dd8c99d0b7a  pop r9
00007dd8c99d0b7c  pop r8
00007dd8c99d0b7e  pop rsi
00007dd8c99d0b7f  pop rdi
00007dd8c99d0b80  pop rdx
00007dd8c99d0b81  pop rcx
00007dd8c99d0b82  pop rax
00007dd8c99d0b83  add rsp, 0x08
00007dd8c99d0b87  jmp 0x00007DD8C99CF631
00007dd8c99d0b8c  sub rsp, 0x08
00007dd8c99d0b90  push rax
00007dd8c99d0b91  push rcx
00007dd8c99d0b92  push rdx
00007dd8c99d0b93  push rdi
00007dd8c99d0b94  push rsi
00007dd8c99d0b95  push r8
00007dd8c99d0b97  push r9
00007dd8c99d0b99  push r10
00007dd8c99d0b9b  push r11
00007dd8c99d0b9d  sub rsp, 0xF0
00007dd8c99d0ba4  vmovaps [rsp], xmm0
00007dd8c99d0ba9  vmovaps [rsp+0x10], xmm1
00007dd8c99d0baf  vmovaps [rsp+0x20], xmm2
00007dd8c99d0bb5  vmovaps [rsp+0x30], xmm3
00007dd8c99d0bbb  vmovaps [rsp+0x40], xmm4
00007dd8c99d0bc1  vmovaps [rsp+0x50], xmm5
00007dd8c99d0bc7  vmovaps [rsp+0x60], xmm6
00007dd8c99d0bcd  vmovaps [rsp+0x70], xmm7
00007dd8c99d0bd3  vmovaps [rsp+0x80], xmm8
00007dd8c99d0bdc  vmovaps [rsp+0x90], xmm9
00007dd8c99d0be5  vmovaps [rsp+0xA0], xmm10
00007dd8c99d0bee  vmovaps [rsp+0xB0], xmm11
00007dd8c99d0bf7  vmovaps [rsp+0xC0], xmm12
00007dd8c99d0c00  vmovaps [rsp+0xD0], xmm14
00007dd8c99d0c09  vmovaps [rsp+0xE0], xmm15
00007dd8c99d0c12  sub rsp, 0x30
00007dd8c99d0c16  movaps [rsp], xmm13
00007dd8c99d0c1b  movaps [rsp+0x10], xmm14
00007dd8c99d0c21  movaps [rsp+0x20], xmm2
00007dd8c99d0c26  lea rdi, [rsp]
00007dd8c99d0c2a  mov esi, 0x00
00007dd8c99d0c2f  mov rax, 0x55FEBBDB5530
00007dd8c99d0c39  call rax
00007dd8c99d0c3b  movaps xmm13, [rsp]
00007dd8c99d0c40  add rsp, 0x30
00007dd8c99d0c44  vmovaps xmm0, [rsp]
00007dd8c99d0c49  vmovaps xmm1, [rsp+0x10]
00007dd8c99d0c4f  vmovaps xmm2, [rsp+0x20]
00007dd8c99d0c55  vmovaps xmm3, [rsp+0x30]
00007dd8c99d0c5b  vmovaps xmm4, [rsp+0x40]
00007dd8c99d0c61  vmovaps xmm5, [rsp+0x50]
00007dd8c99d0c67  vmovaps xmm6, [rsp+0x60]
00007dd8c99d0c6d  vmovaps xmm7, [rsp+0x70]
00007dd8c99d0c73  vmovaps xmm8, [rsp+0x80]
00007dd8c99d0c7c  vmovaps xmm9, [rsp+0x90]
00007dd8c99d0c85  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d0c8e  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d0c97  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d0ca0  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d0ca9  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d0cb2  add rsp, 0xF0
00007dd8c99d0cb9  pop r11
00007dd8c99d0cbb  pop r10
00007dd8c99d0cbd  pop r9
00007dd8c99d0cbf  pop r8
00007dd8c99d0cc1  pop rsi
00007dd8c99d0cc2  pop rdi
00007dd8c99d0cc3  pop rdx
00007dd8c99d0cc4  pop rcx
00007dd8c99d0cc5  pop rax
00007dd8c99d0cc6  add rsp, 0x08
00007dd8c99d0cca  jmp 0x00007DD8C99CF64C
00007dd8c99d0ccf  sub rsp, 0x08
00007dd8c99d0cd3  push rax
00007dd8c99d0cd4  push rcx
00007dd8c99d0cd5  push rdx
00007dd8c99d0cd6  push rdi
00007dd8c99d0cd7  push rsi
00007dd8c99d0cd8  push r8
00007dd8c99d0cda  push r9
00007dd8c99d0cdc  push r10
00007dd8c99d0cde  push r11
00007dd8c99d0ce0  sub rsp, 0xF0
00007dd8c99d0ce7  vmovaps [rsp], xmm0
00007dd8c99d0cec  vmovaps [rsp+0x10], xmm2
00007dd8c99d0cf2  vmovaps [rsp+0x20], xmm3
00007dd8c99d0cf8  vmovaps [rsp+0x30], xmm4
00007dd8c99d0cfe  vmovaps [rsp+0x40], xmm5
00007dd8c99d0d04  vmovaps [rsp+0x50], xmm6
00007dd8c99d0d0a  vmovaps [rsp+0x60], xmm7
00007dd8c99d0d10  vmovaps [rsp+0x70], xmm8
00007dd8c99d0d16  vmovaps [rsp+0x80], xmm9
00007dd8c99d0d1f  vmovaps [rsp+0x90], xmm10
00007dd8c99d0d28  vmovaps [rsp+0xA0], xmm11
00007dd8c99d0d31  vmovaps [rsp+0xB0], xmm12
00007dd8c99d0d3a  vmovaps [rsp+0xC0], xmm13
00007dd8c99d0d43  vmovaps [rsp+0xD0], xmm14
00007dd8c99d0d4c  vmovaps [rsp+0xE0], xmm15
00007dd8c99d0d55  sub rsp, 0x30
00007dd8c99d0d59  movaps [rsp], xmm1
00007dd8c99d0d5d  movaps [rsp+0x10], xmm10
00007dd8c99d0d63  movaps [rsp+0x20], xmm2
00007dd8c99d0d68  lea rdi, [rsp]
00007dd8c99d0d6c  mov esi, 0x00
00007dd8c99d0d71  mov rax, 0x55FEBBDB5530
00007dd8c99d0d7b  call rax
00007dd8c99d0d7d  movaps xmm1, [rsp]
00007dd8c99d0d81  add rsp, 0x30
00007dd8c99d0d85  vmovaps xmm0, [rsp]
00007dd8c99d0d8a  vmovaps xmm2, [rsp+0x10]
00007dd8c99d0d90  vmovaps xmm3, [rsp+0x20]
00007dd8c99d0d96  vmovaps xmm4, [rsp+0x30]
00007dd8c99d0d9c  vmovaps xmm5, [rsp+0x40]
00007dd8c99d0da2  vmovaps xmm6, [rsp+0x50]
00007dd8c99d0da8  vmovaps xmm7, [rsp+0x60]
00007dd8c99d0dae  vmovaps xmm8, [rsp+0x70]
00007dd8c99d0db4  vmovaps xmm9, [rsp+0x80]
00007dd8c99d0dbd  vmovaps xmm10, [rsp+0x90]
00007dd8c99d0dc6  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d0dcf  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d0dd8  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d0de1  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d0dea  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d0df3  add rsp, 0xF0
00007dd8c99d0dfa  pop r11
00007dd8c99d0dfc  pop r10
00007dd8c99d0dfe  pop r9
00007dd8c99d0e00  pop r8
00007dd8c99d0e02  pop rsi
00007dd8c99d0e03  pop rdi
00007dd8c99d0e04  pop rdx
00007dd8c99d0e05  pop rcx
00007dd8c99d0e06  pop rax
00007dd8c99d0e07  add rsp, 0x08
00007dd8c99d0e0b  jmp 0x00007DD8C99CF6B4
00007dd8c99d0e10  sub rsp, 0x08
00007dd8c99d0e14  push rax
00007dd8c99d0e15  push rcx
00007dd8c99d0e16  push rdx
00007dd8c99d0e17  push rdi
00007dd8c99d0e18  push rsi
00007dd8c99d0e19  push r8
00007dd8c99d0e1b  push r9
00007dd8c99d0e1d  push r10
00007dd8c99d0e1f  push r11
00007dd8c99d0e21  sub rsp, 0xF0
00007dd8c99d0e28  vmovaps [rsp], xmm0
00007dd8c99d0e2d  vmovaps [rsp+0x10], xmm1
00007dd8c99d0e33  vmovaps [rsp+0x20], xmm2
00007dd8c99d0e39  vmovaps [rsp+0x30], xmm3
00007dd8c99d0e3f  vmovaps [rsp+0x40], xmm4
00007dd8c99d0e45  vmovaps [rsp+0x50], xmm5
00007dd8c99d0e4b  vmovaps [rsp+0x60], xmm6
00007dd8c99d0e51  vmovaps [rsp+0x70], xmm7
00007dd8c99d0e57  vmovaps [rsp+0x80], xmm8
00007dd8c99d0e60  vmovaps [rsp+0x90], xmm9
00007dd8c99d0e69  vmovaps [rsp+0xA0], xmm10
00007dd8c99d0e72  vmovaps [rsp+0xB0], xmm11
00007dd8c99d0e7b  vmovaps [rsp+0xC0], xmm12
00007dd8c99d0e84  vmovaps [rsp+0xD0], xmm13
00007dd8c99d0e8d  vmovaps [rsp+0xE0], xmm14
00007dd8c99d0e96  sub rsp, 0x30
00007dd8c99d0e9a  movaps [rsp], xmm15
00007dd8c99d0e9f  movaps [rsp+0x10], xmm10
00007dd8c99d0ea5  movaps [rsp+0x20], xmm2
00007dd8c99d0eaa  lea rdi, [rsp]
00007dd8c99d0eae  mov esi, 0x00
00007dd8c99d0eb3  mov rax, 0x55FEBBDB5530
00007dd8c99d0ebd  call rax
00007dd8c99d0ebf  movaps xmm15, [rsp]
00007dd8c99d0ec4  add rsp, 0x30
00007dd8c99d0ec8  vmovaps xmm0, [rsp]
00007dd8c99d0ecd  vmovaps xmm1, [rsp+0x10]
00007dd8c99d0ed3  vmovaps xmm2, [rsp+0x20]
00007dd8c99d0ed9  vmovaps xmm3, [rsp+0x30]
00007dd8c99d0edf  vmovaps xmm4, [rsp+0x40]
00007dd8c99d0ee5  vmovaps xmm5, [rsp+0x50]
00007dd8c99d0eeb  vmovaps xmm6, [rsp+0x60]
00007dd8c99d0ef1  vmovaps xmm7, [rsp+0x70]
00007dd8c99d0ef7  vmovaps xmm8, [rsp+0x80]
00007dd8c99d0f00  vmovaps xmm9, [rsp+0x90]
00007dd8c99d0f09  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d0f12  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d0f1b  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d0f24  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d0f2d  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d0f36  add rsp, 0xF0
00007dd8c99d0f3d  pop r11
00007dd8c99d0f3f  pop r10
00007dd8c99d0f41  pop r9
00007dd8c99d0f43  pop r8
00007dd8c99d0f45  pop rsi
00007dd8c99d0f46  pop rdi
00007dd8c99d0f47  pop rdx
00007dd8c99d0f48  pop rcx
00007dd8c99d0f49  pop rax
00007dd8c99d0f4a  add rsp, 0x08
00007dd8c99d0f4e  jmp 0x00007DD8C99CF706
00007dd8c99d0f53  sub rsp, 0x08
00007dd8c99d0f57  push rax
00007dd8c99d0f58  push rcx
00007dd8c99d0f59  push rdx
00007dd8c99d0f5a  push rdi
00007dd8c99d0f5b  push rsi
00007dd8c99d0f5c  push r8
00007dd8c99d0f5e  push r9
00007dd8c99d0f60  push r10
00007dd8c99d0f62  push r11
00007dd8c99d0f64  sub rsp, 0xF0
00007dd8c99d0f6b  vmovaps [rsp], xmm0
00007dd8c99d0f70  vmovaps [rsp+0x10], xmm2
00007dd8c99d0f76  vmovaps [rsp+0x20], xmm3
00007dd8c99d0f7c  vmovaps [rsp+0x30], xmm4
00007dd8c99d0f82  vmovaps [rsp+0x40], xmm5
00007dd8c99d0f88  vmovaps [rsp+0x50], xmm6
00007dd8c99d0f8e  vmovaps [rsp+0x60], xmm7
00007dd8c99d0f94  vmovaps [rsp+0x70], xmm8
00007dd8c99d0f9a  vmovaps [rsp+0x80], xmm9
00007dd8c99d0fa3  vmovaps [rsp+0x90], xmm10
00007dd8c99d0fac  vmovaps [rsp+0xA0], xmm11
00007dd8c99d0fb5  vmovaps [rsp+0xB0], xmm12
00007dd8c99d0fbe  vmovaps [rsp+0xC0], xmm13
00007dd8c99d0fc7  vmovaps [rsp+0xD0], xmm14
00007dd8c99d0fd0  vmovaps [rsp+0xE0], xmm15
00007dd8c99d0fd9  sub rsp, 0x30
00007dd8c99d0fdd  movaps [rsp], xmm1
00007dd8c99d0fe1  movaps [rsp+0x10], xmm10
00007dd8c99d0fe7  movaps [rsp+0x20], xmm12
00007dd8c99d0fed  lea rdi, [rsp]
00007dd8c99d0ff1  mov esi, 0x00
00007dd8c99d0ff6  mov rax, 0x55FEBBDB5530
00007dd8c99d1000  call rax
00007dd8c99d1002  movaps xmm1, [rsp]
00007dd8c99d1006  add rsp, 0x30
00007dd8c99d100a  vmovaps xmm0, [rsp]
00007dd8c99d100f  vmovaps xmm2, [rsp+0x10]
00007dd8c99d1015  vmovaps xmm3, [rsp+0x20]
00007dd8c99d101b  vmovaps xmm4, [rsp+0x30]
00007dd8c99d1021  vmovaps xmm5, [rsp+0x40]
00007dd8c99d1027  vmovaps xmm6, [rsp+0x50]
00007dd8c99d102d  vmovaps xmm7, [rsp+0x60]
00007dd8c99d1033  vmovaps xmm8, [rsp+0x70]
00007dd8c99d1039  vmovaps xmm9, [rsp+0x80]
00007dd8c99d1042  vmovaps xmm10, [rsp+0x90]
00007dd8c99d104b  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d1054  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d105d  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d1066  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d106f  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d1078  add rsp, 0xF0
00007dd8c99d107f  pop r11
00007dd8c99d1081  pop r10
00007dd8c99d1083  pop r9
00007dd8c99d1085  pop r8
00007dd8c99d1087  pop rsi
00007dd8c99d1088  pop rdi
00007dd8c99d1089  pop rdx
00007dd8c99d108a  pop rcx
00007dd8c99d108b  pop rax
00007dd8c99d108c  add rsp, 0x08
00007dd8c99d1090  jmp 0x00007DD8C99CF732
00007dd8c99d1095  sub rsp, 0x08
00007dd8c99d1099  push rax
00007dd8c99d109a  push rcx
00007dd8c99d109b  push rdx
00007dd8c99d109c  push rdi
00007dd8c99d109d  push rsi
00007dd8c99d109e  push r8
00007dd8c99d10a0  push r9
00007dd8c99d10a2  push r10
00007dd8c99d10a4  push r11
00007dd8c99d10a6  sub rsp, 0xF0
00007dd8c99d10ad  vmovaps [rsp], xmm0
00007dd8c99d10b2  vmovaps [rsp+0x10], xmm1
00007dd8c99d10b8  vmovaps [rsp+0x20], xmm2
00007dd8c99d10be  vmovaps [rsp+0x30], xmm3
00007dd8c99d10c4  vmovaps [rsp+0x40], xmm4
00007dd8c99d10ca  vmovaps [rsp+0x50], xmm5
00007dd8c99d10d0  vmovaps [rsp+0x60], xmm6
00007dd8c99d10d6  vmovaps [rsp+0x70], xmm7
00007dd8c99d10dc  vmovaps [rsp+0x80], xmm8
00007dd8c99d10e5  vmovaps [rsp+0x90], xmm9
00007dd8c99d10ee  vmovaps [rsp+0xA0], xmm10
00007dd8c99d10f7  vmovaps [rsp+0xB0], xmm11
00007dd8c99d1100  vmovaps [rsp+0xC0], xmm12
00007dd8c99d1109  vmovaps [rsp+0xD0], xmm13
00007dd8c99d1112  vmovaps [rsp+0xE0], xmm14
00007dd8c99d111b  sub rsp, 0x30
00007dd8c99d111f  movaps [rsp], xmm15
00007dd8c99d1124  movaps [rsp+0x10], xmm10
00007dd8c99d112a  movaps [rsp+0x20], xmm12
00007dd8c99d1130  lea rdi, [rsp]
00007dd8c99d1134  mov esi, 0x00
00007dd8c99d1139  mov rax, 0x55FEBBDB5530
00007dd8c99d1143  call rax
00007dd8c99d1145  movaps xmm15, [rsp]
00007dd8c99d114a  add rsp, 0x30
00007dd8c99d114e  vmovaps xmm0, [rsp]
00007dd8c99d1153  vmovaps xmm1, [rsp+0x10]
00007dd8c99d1159  vmovaps xmm2, [rsp+0x20]
00007dd8c99d115f  vmovaps xmm3, [rsp+0x30]
00007dd8c99d1165  vmovaps xmm4, [rsp+0x40]
00007dd8c99d116b  vmovaps xmm5, [rsp+0x50]
00007dd8c99d1171  vmovaps xmm6, [rsp+0x60]
00007dd8c99d1177  vmovaps xmm7, [rsp+0x70]
00007dd8c99d117d  vmovaps xmm8, [rsp+0x80]
00007dd8c99d1186  vmovaps xmm9, [rsp+0x90]
00007dd8c99d118f  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d1198  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d11a1  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d11aa  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d11b3  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d11bc  add rsp, 0xF0
00007dd8c99d11c3  pop r11
00007dd8c99d11c5  pop r10
00007dd8c99d11c7  pop r9
00007dd8c99d11c9  pop r8
00007dd8c99d11cb  pop rsi
00007dd8c99d11cc  pop rdi
00007dd8c99d11cd  pop rdx
00007dd8c99d11ce  pop rcx
00007dd8c99d11cf  pop rax
00007dd8c99d11d0  add rsp, 0x08
00007dd8c99d11d4  jmp 0x00007DD8C99CF75E
00007dd8c99d11d9  call 0x00007DD8C97FF430
00007dd8c99d11de  jmp 0x00007DD8C99CF7EE
00007dd8c99d11e3  call 0x00007DD8C97FF430
00007dd8c99d11e8  jmp 0x00007DD8C99CF801
00007dd8c99d11ed  sub rsp, 0x08
00007dd8c99d11f1  push rax
00007dd8c99d11f2  push rcx
00007dd8c99d11f3  push rdx
00007dd8c99d11f4  push rdi
00007dd8c99d11f5  push rsi
00007dd8c99d11f6  push r8
00007dd8c99d11f8  push r9
00007dd8c99d11fa  push r10
00007dd8c99d11fc  push r11
00007dd8c99d11fe  sub rsp, 0xF0
00007dd8c99d1205  vmovaps [rsp], xmm0
00007dd8c99d120a  vmovaps [rsp+0x10], xmm2
00007dd8c99d1210  vmovaps [rsp+0x20], xmm3
00007dd8c99d1216  vmovaps [rsp+0x30], xmm4
00007dd8c99d121c  vmovaps [rsp+0x40], xmm5
00007dd8c99d1222  vmovaps [rsp+0x50], xmm6
00007dd8c99d1228  vmovaps [rsp+0x60], xmm7
00007dd8c99d122e  vmovaps [rsp+0x70], xmm8
00007dd8c99d1234  vmovaps [rsp+0x80], xmm9
00007dd8c99d123d  vmovaps [rsp+0x90], xmm10
00007dd8c99d1246  vmovaps [rsp+0xA0], xmm11
00007dd8c99d124f  vmovaps [rsp+0xB0], xmm12
00007dd8c99d1258  vmovaps [rsp+0xC0], xmm13
00007dd8c99d1261  vmovaps [rsp+0xD0], xmm14
00007dd8c99d126a  vmovaps [rsp+0xE0], xmm15
00007dd8c99d1273  sub rsp, 0x30
00007dd8c99d1277  movaps [rsp], xmm1
00007dd8c99d127b  movaps [rsp+0x10], xmm13
00007dd8c99d1281  movaps [rsp+0x20], xmm2
00007dd8c99d1286  lea rdi, [rsp]
00007dd8c99d128a  mov esi, 0x00
00007dd8c99d128f  mov rax, 0x55FEBBDB5530
00007dd8c99d1299  call rax
00007dd8c99d129b  movaps xmm1, [rsp]
00007dd8c99d129f  add rsp, 0x30
00007dd8c99d12a3  vmovaps xmm0, [rsp]
00007dd8c99d12a8  vmovaps xmm2, [rsp+0x10]
00007dd8c99d12ae  vmovaps xmm3, [rsp+0x20]
00007dd8c99d12b4  vmovaps xmm4, [rsp+0x30]
00007dd8c99d12ba  vmovaps xmm5, [rsp+0x40]
00007dd8c99d12c0  vmovaps xmm6, [rsp+0x50]
00007dd8c99d12c6  vmovaps xmm7, [rsp+0x60]
00007dd8c99d12cc  vmovaps xmm8, [rsp+0x70]
00007dd8c99d12d2  vmovaps xmm9, [rsp+0x80]
00007dd8c99d12db  vmovaps xmm10, [rsp+0x90]
00007dd8c99d12e4  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d12ed  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d12f6  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d12ff  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d1308  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d1311  add rsp, 0xF0
00007dd8c99d1318  pop r11
00007dd8c99d131a  pop r10
00007dd8c99d131c  pop r9
00007dd8c99d131e  pop r8
00007dd8c99d1320  pop rsi
00007dd8c99d1321  pop rdi
00007dd8c99d1322  pop rdx
00007dd8c99d1323  pop rcx
00007dd8c99d1324  pop rax
00007dd8c99d1325  add rsp, 0x08
00007dd8c99d1329  jmp 0x00007DD8C99CF82C
00007dd8c99d132e  call 0x00007DD8C980E760
00007dd8c99d1333  jmp 0x00007DD8C99CF839
00007dd8c99d1338  sub rsp, 0x08
00007dd8c99d133c  push rax
00007dd8c99d133d  push rcx
00007dd8c99d133e  push rdx
00007dd8c99d133f  push rdi
00007dd8c99d1340  push rsi
00007dd8c99d1341  push r8
00007dd8c99d1343  push r9
00007dd8c99d1345  push r10
00007dd8c99d1347  push r11
00007dd8c99d1349  sub rsp, 0xF0
00007dd8c99d1350  vmovaps [rsp], xmm0
00007dd8c99d1355  vmovaps [rsp+0x10], xmm1
00007dd8c99d135b  vmovaps [rsp+0x20], xmm2
00007dd8c99d1361  vmovaps [rsp+0x30], xmm3
00007dd8c99d1367  vmovaps [rsp+0x40], xmm4
00007dd8c99d136d  vmovaps [rsp+0x50], xmm5
00007dd8c99d1373  vmovaps [rsp+0x60], xmm6
00007dd8c99d1379  vmovaps [rsp+0x70], xmm7
00007dd8c99d137f  vmovaps [rsp+0x80], xmm8
00007dd8c99d1388  vmovaps [rsp+0x90], xmm9
00007dd8c99d1391  vmovaps [rsp+0xA0], xmm10
00007dd8c99d139a  vmovaps [rsp+0xB0], xmm11
00007dd8c99d13a3  vmovaps [rsp+0xC0], xmm12
00007dd8c99d13ac  vmovaps [rsp+0xD0], xmm14
00007dd8c99d13b5  vmovaps [rsp+0xE0], xmm15
00007dd8c99d13be  sub rsp, 0x30
00007dd8c99d13c2  movaps [rsp], xmm13
00007dd8c99d13c7  movaps [rsp+0x10], xmm2
00007dd8c99d13cc  movaps [rsp+0x20], xmm1
00007dd8c99d13d1  lea rdi, [rsp]
00007dd8c99d13d5  mov esi, 0x00
00007dd8c99d13da  mov rax, 0x55FEBBDB5530
00007dd8c99d13e4  call rax
00007dd8c99d13e6  movaps xmm13, [rsp]
00007dd8c99d13eb  add rsp, 0x30
00007dd8c99d13ef  vmovaps xmm0, [rsp]
00007dd8c99d13f4  vmovaps xmm1, [rsp+0x10]
00007dd8c99d13fa  vmovaps xmm2, [rsp+0x20]
00007dd8c99d1400  vmovaps xmm3, [rsp+0x30]
00007dd8c99d1406  vmovaps xmm4, [rsp+0x40]
00007dd8c99d140c  vmovaps xmm5, [rsp+0x50]
00007dd8c99d1412  vmovaps xmm6, [rsp+0x60]
00007dd8c99d1418  vmovaps xmm7, [rsp+0x70]
00007dd8c99d141e  vmovaps xmm8, [rsp+0x80]
00007dd8c99d1427  vmovaps xmm9, [rsp+0x90]
00007dd8c99d1430  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d1439  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d1442  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d144b  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d1454  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d145d  add rsp, 0xF0
00007dd8c99d1464  pop r11
00007dd8c99d1466  pop r10
00007dd8c99d1468  pop r9
00007dd8c99d146a  pop r8
00007dd8c99d146c  pop rsi
00007dd8c99d146d  pop rdi
00007dd8c99d146e  pop rdx
00007dd8c99d146f  pop rcx
00007dd8c99d1470  pop rax
00007dd8c99d1471  add rsp, 0x08
00007dd8c99d1475  jmp 0x00007DD8C99CF878
00007dd8c99d147a  sub rsp, 0x08
00007dd8c99d147e  push rax
00007dd8c99d147f  push rcx
00007dd8c99d1480  push rdx
00007dd8c99d1481  push rdi
00007dd8c99d1482  push rsi
00007dd8c99d1483  push r8
00007dd8c99d1485  push r9
00007dd8c99d1487  push r10
00007dd8c99d1489  push r11
00007dd8c99d148b  sub rsp, 0xF0
00007dd8c99d1492  vmovaps [rsp], xmm0
00007dd8c99d1497  vmovaps [rsp+0x10], xmm2
00007dd8c99d149d  vmovaps [rsp+0x20], xmm3
00007dd8c99d14a3  vmovaps [rsp+0x30], xmm4
00007dd8c99d14a9  vmovaps [rsp+0x40], xmm5
00007dd8c99d14af  vmovaps [rsp+0x50], xmm6
00007dd8c99d14b5  vmovaps [rsp+0x60], xmm7
00007dd8c99d14bb  vmovaps [rsp+0x70], xmm8
00007dd8c99d14c1  vmovaps [rsp+0x80], xmm9
00007dd8c99d14ca  vmovaps [rsp+0x90], xmm10
00007dd8c99d14d3  vmovaps [rsp+0xA0], xmm11
00007dd8c99d14dc  vmovaps [rsp+0xB0], xmm12
00007dd8c99d14e5  vmovaps [rsp+0xC0], xmm13
00007dd8c99d14ee  vmovaps [rsp+0xD0], xmm14
00007dd8c99d14f7  vmovaps [rsp+0xE0], xmm15
00007dd8c99d1500  sub rsp, 0x30
00007dd8c99d1504  movaps [rsp], xmm1
00007dd8c99d1508  movaps [rsp+0x10], xmm15
00007dd8c99d150e  movaps [rsp+0x20], xmm2
00007dd8c99d1513  lea rdi, [rsp]
00007dd8c99d1517  mov esi, 0x00
00007dd8c99d151c  mov rax, 0x55FEBBDB5530
00007dd8c99d1526  call rax
00007dd8c99d1528  movaps xmm1, [rsp]
00007dd8c99d152c  add rsp, 0x30
00007dd8c99d1530  vmovaps xmm0, [rsp]
00007dd8c99d1535  vmovaps xmm2, [rsp+0x10]
00007dd8c99d153b  vmovaps xmm3, [rsp+0x20]
00007dd8c99d1541  vmovaps xmm4, [rsp+0x30]
00007dd8c99d1547  vmovaps xmm5, [rsp+0x40]
00007dd8c99d154d  vmovaps xmm6, [rsp+0x50]
00007dd8c99d1553  vmovaps xmm7, [rsp+0x60]
00007dd8c99d1559  vmovaps xmm8, [rsp+0x70]
00007dd8c99d155f  vmovaps xmm9, [rsp+0x80]
00007dd8c99d1568  vmovaps xmm10, [rsp+0x90]
00007dd8c99d1571  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d157a  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d1583  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d158c  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d1595  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d159e  add rsp, 0xF0
00007dd8c99d15a5  pop r11
00007dd8c99d15a7  pop r10
00007dd8c99d15a9  pop r9
00007dd8c99d15ab  pop r8
00007dd8c99d15ad  pop rsi
00007dd8c99d15ae  pop rdi
00007dd8c99d15af  pop rdx
00007dd8c99d15b0  pop rcx
00007dd8c99d15b1  pop rax
00007dd8c99d15b2  add rsp, 0x08
00007dd8c99d15b6  jmp 0x00007DD8C99CF8AC
00007dd8c99d15bb  sub rsp, 0x08
00007dd8c99d15bf  push rax
00007dd8c99d15c0  push rcx
00007dd8c99d15c1  push rdx
00007dd8c99d15c2  push rdi
00007dd8c99d15c3  push rsi
00007dd8c99d15c4  push r8
00007dd8c99d15c6  push r9
00007dd8c99d15c8  push r10
00007dd8c99d15ca  push r11
00007dd8c99d15cc  sub rsp, 0xF0
00007dd8c99d15d3  vmovaps [rsp], xmm0
00007dd8c99d15d8  vmovaps [rsp+0x10], xmm1
00007dd8c99d15de  vmovaps [rsp+0x20], xmm2
00007dd8c99d15e4  vmovaps [rsp+0x30], xmm3
00007dd8c99d15ea  vmovaps [rsp+0x40], xmm4
00007dd8c99d15f0  vmovaps [rsp+0x50], xmm5
00007dd8c99d15f6  vmovaps [rsp+0x60], xmm6
00007dd8c99d15fc  vmovaps [rsp+0x70], xmm7
00007dd8c99d1602  vmovaps [rsp+0x80], xmm8
00007dd8c99d160b  vmovaps [rsp+0x90], xmm9
00007dd8c99d1614  vmovaps [rsp+0xA0], xmm10
00007dd8c99d161d  vmovaps [rsp+0xB0], xmm11
00007dd8c99d1626  vmovaps [rsp+0xC0], xmm12
00007dd8c99d162f  vmovaps [rsp+0xD0], xmm13
00007dd8c99d1638  vmovaps [rsp+0xE0], xmm15
00007dd8c99d1641  sub rsp, 0x30
00007dd8c99d1645  movaps [rsp], xmm14
00007dd8c99d164a  movaps [rsp+0x10], xmm2
00007dd8c99d164f  movaps [rsp+0x20], xmm15
00007dd8c99d1655  lea rdi, [rsp]
00007dd8c99d1659  mov esi, 0x00
00007dd8c99d165e  mov rax, 0x55FEBBDB5530
00007dd8c99d1668  call rax
00007dd8c99d166a  movaps xmm14, [rsp]
00007dd8c99d166f  add rsp, 0x30
00007dd8c99d1673  vmovaps xmm0, [rsp]
00007dd8c99d1678  vmovaps xmm1, [rsp+0x10]
00007dd8c99d167e  vmovaps xmm2, [rsp+0x20]
00007dd8c99d1684  vmovaps xmm3, [rsp+0x30]
00007dd8c99d168a  vmovaps xmm4, [rsp+0x40]
00007dd8c99d1690  vmovaps xmm5, [rsp+0x50]
00007dd8c99d1696  vmovaps xmm6, [rsp+0x60]
00007dd8c99d169c  vmovaps xmm7, [rsp+0x70]
00007dd8c99d16a2  vmovaps xmm8, [rsp+0x80]
00007dd8c99d16ab  vmovaps xmm9, [rsp+0x90]
00007dd8c99d16b4  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d16bd  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d16c6  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d16cf  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d16d8  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d16e1  add rsp, 0xF0
00007dd8c99d16e8  pop r11
00007dd8c99d16ea  pop r10
00007dd8c99d16ec  pop r9
00007dd8c99d16ee  pop r8
00007dd8c99d16f0  pop rsi
00007dd8c99d16f1  pop rdi
00007dd8c99d16f2  pop rdx
00007dd8c99d16f3  pop rcx
00007dd8c99d16f4  pop rax
00007dd8c99d16f5  add rsp, 0x08
00007dd8c99d16f9  jmp 0x00007DD8C99CF8E7
00007dd8c99d16fe  sub rsp, 0x08
00007dd8c99d1702  push rax
00007dd8c99d1703  push rcx
00007dd8c99d1704  push rdx
00007dd8c99d1705  push rdi
00007dd8c99d1706  push rsi
00007dd8c99d1707  push r8
00007dd8c99d1709  push r9
00007dd8c99d170b  push r10
00007dd8c99d170d  push r11
00007dd8c99d170f  sub rsp, 0xF0
00007dd8c99d1716  vmovaps [rsp], xmm0
00007dd8c99d171b  vmovaps [rsp+0x10], xmm1
00007dd8c99d1721  vmovaps [rsp+0x20], xmm2
00007dd8c99d1727  vmovaps [rsp+0x30], xmm3
00007dd8c99d172d  vmovaps [rsp+0x40], xmm4
00007dd8c99d1733  vmovaps [rsp+0x50], xmm5
00007dd8c99d1739  vmovaps [rsp+0x60], xmm6
00007dd8c99d173f  vmovaps [rsp+0x70], xmm7
00007dd8c99d1745  vmovaps [rsp+0x80], xmm8
00007dd8c99d174e  vmovaps [rsp+0x90], xmm9
00007dd8c99d1757  vmovaps [rsp+0xA0], xmm10
00007dd8c99d1760  vmovaps [rsp+0xB0], xmm11
00007dd8c99d1769  vmovaps [rsp+0xC0], xmm12
00007dd8c99d1772  vmovaps [rsp+0xD0], xmm13
00007dd8c99d177b  vmovaps [rsp+0xE0], xmm14
00007dd8c99d1784  sub rsp, 0x30
00007dd8c99d1788  movaps [rsp], xmm15
00007dd8c99d178d  movaps [rsp+0x10], xmm2
00007dd8c99d1792  movaps [rsp+0x20], xmm1
00007dd8c99d1797  lea rdi, [rsp]
00007dd8c99d179b  mov esi, 0x00
00007dd8c99d17a0  mov rax, 0x55FEBBDB5530
00007dd8c99d17aa  call rax
00007dd8c99d17ac  movaps xmm15, [rsp]
00007dd8c99d17b1  add rsp, 0x30
00007dd8c99d17b5  vmovaps xmm0, [rsp]
00007dd8c99d17ba  vmovaps xmm1, [rsp+0x10]
00007dd8c99d17c0  vmovaps xmm2, [rsp+0x20]
00007dd8c99d17c6  vmovaps xmm3, [rsp+0x30]
00007dd8c99d17cc  vmovaps xmm4, [rsp+0x40]
00007dd8c99d17d2  vmovaps xmm5, [rsp+0x50]
00007dd8c99d17d8  vmovaps xmm6, [rsp+0x60]
00007dd8c99d17de  vmovaps xmm7, [rsp+0x70]
00007dd8c99d17e4  vmovaps xmm8, [rsp+0x80]
00007dd8c99d17ed  vmovaps xmm9, [rsp+0x90]
00007dd8c99d17f6  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d17ff  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d1808  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d1811  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d181a  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d1823  add rsp, 0xF0
00007dd8c99d182a  pop r11
00007dd8c99d182c  pop r10
00007dd8c99d182e  pop r9
00007dd8c99d1830  pop r8
00007dd8c99d1832  pop rsi
00007dd8c99d1833  pop rdi
00007dd8c99d1834  pop rdx
00007dd8c99d1835  pop rcx
00007dd8c99d1836  pop rax
00007dd8c99d1837  add rsp, 0x08
00007dd8c99d183b  jmp 0x00007DD8C99CF923
00007dd8c99d1840  call 0x00007DD8C97FF430
00007dd8c99d1845  jmp 0x00007DD8C99CF930
00007dd8c99d184a  sub rsp, 0x08
00007dd8c99d184e  push rax
00007dd8c99d184f  push rcx
00007dd8c99d1850  push rdx
00007dd8c99d1851  push rdi
00007dd8c99d1852  push rsi
00007dd8c99d1853  push r8
00007dd8c99d1855  push r9
00007dd8c99d1857  push r10
00007dd8c99d1859  push r11
00007dd8c99d185b  sub rsp, 0xF0
00007dd8c99d1862  vmovaps [rsp], xmm0
00007dd8c99d1867  vmovaps [rsp+0x10], xmm1
00007dd8c99d186d  vmovaps [rsp+0x20], xmm3
00007dd8c99d1873  vmovaps [rsp+0x30], xmm4
00007dd8c99d1879  vmovaps [rsp+0x40], xmm5
00007dd8c99d187f  vmovaps [rsp+0x50], xmm6
00007dd8c99d1885  vmovaps [rsp+0x60], xmm7
00007dd8c99d188b  vmovaps [rsp+0x70], xmm8
00007dd8c99d1891  vmovaps [rsp+0x80], xmm9
00007dd8c99d189a  vmovaps [rsp+0x90], xmm10
00007dd8c99d18a3  vmovaps [rsp+0xA0], xmm11
00007dd8c99d18ac  vmovaps [rsp+0xB0], xmm12
00007dd8c99d18b5  vmovaps [rsp+0xC0], xmm13
00007dd8c99d18be  vmovaps [rsp+0xD0], xmm14
00007dd8c99d18c7  vmovaps [rsp+0xE0], xmm15
00007dd8c99d18d0  sub rsp, 0x30
00007dd8c99d18d4  movaps [rsp], xmm2
00007dd8c99d18d8  movaps [rsp+0x10], xmm1
00007dd8c99d18dd  movaps [rsp+0x20], xmm14
00007dd8c99d18e3  lea rdi, [rsp]
00007dd8c99d18e7  mov esi, 0x00
00007dd8c99d18ec  mov rax, 0x55FEBBDB5530
00007dd8c99d18f6  call rax
00007dd8c99d18f8  movaps xmm2, [rsp]
00007dd8c99d18fc  add rsp, 0x30
00007dd8c99d1900  vmovaps xmm0, [rsp]
00007dd8c99d1905  vmovaps xmm1, [rsp+0x10]
00007dd8c99d190b  vmovaps xmm3, [rsp+0x20]
00007dd8c99d1911  vmovaps xmm4, [rsp+0x30]
00007dd8c99d1917  vmovaps xmm5, [rsp+0x40]
00007dd8c99d191d  vmovaps xmm6, [rsp+0x50]
00007dd8c99d1923  vmovaps xmm7, [rsp+0x60]
00007dd8c99d1929  vmovaps xmm8, [rsp+0x70]
00007dd8c99d192f  vmovaps xmm9, [rsp+0x80]
00007dd8c99d1938  vmovaps xmm10, [rsp+0x90]
00007dd8c99d1941  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d194a  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d1953  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d195c  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d1965  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d196e  add rsp, 0xF0
00007dd8c99d1975  pop r11
00007dd8c99d1977  pop r10
00007dd8c99d1979  pop r9
00007dd8c99d197b  pop r8
00007dd8c99d197d  pop rsi
00007dd8c99d197e  pop rdi
00007dd8c99d197f  pop rdx
00007dd8c99d1980  pop rcx
00007dd8c99d1981  pop rax
00007dd8c99d1982  add rsp, 0x08
00007dd8c99d1986  jmp 0x00007DD8C99CF96D
00007dd8c99d198b  sub rsp, 0x08
00007dd8c99d198f  push rax
00007dd8c99d1990  push rcx
00007dd8c99d1991  push rdx
00007dd8c99d1992  push rdi
00007dd8c99d1993  push rsi
00007dd8c99d1994  push r8
00007dd8c99d1996  push r9
00007dd8c99d1998  push r10
00007dd8c99d199a  push r11
00007dd8c99d199c  sub rsp, 0xF0
00007dd8c99d19a3  vmovaps [rsp], xmm0
00007dd8c99d19a8  vmovaps [rsp+0x10], xmm1
00007dd8c99d19ae  vmovaps [rsp+0x20], xmm2
00007dd8c99d19b4  vmovaps [rsp+0x30], xmm3
00007dd8c99d19ba  vmovaps [rsp+0x40], xmm4
00007dd8c99d19c0  vmovaps [rsp+0x50], xmm5
00007dd8c99d19c6  vmovaps [rsp+0x60], xmm6
00007dd8c99d19cc  vmovaps [rsp+0x70], xmm7
00007dd8c99d19d2  vmovaps [rsp+0x80], xmm8
00007dd8c99d19db  vmovaps [rsp+0x90], xmm9
00007dd8c99d19e4  vmovaps [rsp+0xA0], xmm10
00007dd8c99d19ed  vmovaps [rsp+0xB0], xmm11
00007dd8c99d19f6  vmovaps [rsp+0xC0], xmm12
00007dd8c99d19ff  vmovaps [rsp+0xD0], xmm13
00007dd8c99d1a08  vmovaps [rsp+0xE0], xmm14
00007dd8c99d1a11  sub rsp, 0x30
00007dd8c99d1a15  movaps [rsp], xmm15
00007dd8c99d1a1a  movaps [rsp+0x10], xmm14
00007dd8c99d1a20  movaps [rsp+0x20], xmm1
00007dd8c99d1a25  lea rdi, [rsp]
00007dd8c99d1a29  mov esi, 0x00
00007dd8c99d1a2e  mov rax, 0x55FEBBDB5530
00007dd8c99d1a38  call rax
00007dd8c99d1a3a  movaps xmm15, [rsp]
00007dd8c99d1a3f  add rsp, 0x30
00007dd8c99d1a43  vmovaps xmm0, [rsp]
00007dd8c99d1a48  vmovaps xmm1, [rsp+0x10]
00007dd8c99d1a4e  vmovaps xmm2, [rsp+0x20]
00007dd8c99d1a54  vmovaps xmm3, [rsp+0x30]
00007dd8c99d1a5a  vmovaps xmm4, [rsp+0x40]
00007dd8c99d1a60  vmovaps xmm5, [rsp+0x50]
00007dd8c99d1a66  vmovaps xmm6, [rsp+0x60]
00007dd8c99d1a6c  vmovaps xmm7, [rsp+0x70]
00007dd8c99d1a72  vmovaps xmm8, [rsp+0x80]
00007dd8c99d1a7b  vmovaps xmm9, [rsp+0x90]
00007dd8c99d1a84  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d1a8d  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d1a96  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d1a9f  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d1aa8  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d1ab1  add rsp, 0xF0
00007dd8c99d1ab8  pop r11
00007dd8c99d1aba  pop r10
00007dd8c99d1abc  pop r9
00007dd8c99d1abe  pop r8
00007dd8c99d1ac0  pop rsi
00007dd8c99d1ac1  pop rdi
00007dd8c99d1ac2  pop rdx
00007dd8c99d1ac3  pop rcx
00007dd8c99d1ac4  pop rax
00007dd8c99d1ac5  add rsp, 0x08
00007dd8c99d1ac9  jmp 0x00007DD8C99CF9E7
00007dd8c99d1ace  call 0x00007DD8C97FF430
00007dd8c99d1ad3  jmp 0x00007DD8C99CF9F4
00007dd8c99d1ad8  sub rsp, 0x08
00007dd8c99d1adc  push rax
00007dd8c99d1add  push rcx
00007dd8c99d1ade  push rdx
00007dd8c99d1adf  push rdi
00007dd8c99d1ae0  push rsi
00007dd8c99d1ae1  push r8
00007dd8c99d1ae3  push r9
00007dd8c99d1ae5  push r10
00007dd8c99d1ae7  push r11
00007dd8c99d1ae9  sub rsp, 0xF0
00007dd8c99d1af0  vmovaps [rsp], xmm0
00007dd8c99d1af5  vmovaps [rsp+0x10], xmm1
00007dd8c99d1afb  vmovaps [rsp+0x20], xmm2
00007dd8c99d1b01  vmovaps [rsp+0x30], xmm3
00007dd8c99d1b07  vmovaps [rsp+0x40], xmm4
00007dd8c99d1b0d  vmovaps [rsp+0x50], xmm5
00007dd8c99d1b13  vmovaps [rsp+0x60], xmm6
00007dd8c99d1b19  vmovaps [rsp+0x70], xmm7
00007dd8c99d1b1f  vmovaps [rsp+0x80], xmm8
00007dd8c99d1b28  vmovaps [rsp+0x90], xmm9
00007dd8c99d1b31  vmovaps [rsp+0xA0], xmm10
00007dd8c99d1b3a  vmovaps [rsp+0xB0], xmm11
00007dd8c99d1b43  vmovaps [rsp+0xC0], xmm12
00007dd8c99d1b4c  vmovaps [rsp+0xD0], xmm13
00007dd8c99d1b55  vmovaps [rsp+0xE0], xmm15
00007dd8c99d1b5e  sub rsp, 0x30
00007dd8c99d1b62  movaps [rsp], xmm14
00007dd8c99d1b67  movaps [rsp+0x10], xmm13
00007dd8c99d1b6d  movaps [rsp+0x20], xmm1
00007dd8c99d1b72  lea rdi, [rsp]
00007dd8c99d1b76  mov esi, 0x00
00007dd8c99d1b7b  mov rax, 0x55FEBBDB5530
00007dd8c99d1b85  call rax
00007dd8c99d1b87  movaps xmm14, [rsp]
00007dd8c99d1b8c  add rsp, 0x30
00007dd8c99d1b90  vmovaps xmm0, [rsp]
00007dd8c99d1b95  vmovaps xmm1, [rsp+0x10]
00007dd8c99d1b9b  vmovaps xmm2, [rsp+0x20]
00007dd8c99d1ba1  vmovaps xmm3, [rsp+0x30]
00007dd8c99d1ba7  vmovaps xmm4, [rsp+0x40]
00007dd8c99d1bad  vmovaps xmm5, [rsp+0x50]
00007dd8c99d1bb3  vmovaps xmm6, [rsp+0x60]
00007dd8c99d1bb9  vmovaps xmm7, [rsp+0x70]
00007dd8c99d1bbf  vmovaps xmm8, [rsp+0x80]
00007dd8c99d1bc8  vmovaps xmm9, [rsp+0x90]
00007dd8c99d1bd1  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d1bda  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d1be3  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d1bec  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d1bf5  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d1bfe  add rsp, 0xF0
00007dd8c99d1c05  pop r11
00007dd8c99d1c07  pop r10
00007dd8c99d1c09  pop r9
00007dd8c99d1c0b  pop r8
00007dd8c99d1c0d  pop rsi
00007dd8c99d1c0e  pop rdi
00007dd8c99d1c0f  pop rdx
00007dd8c99d1c10  pop rcx
00007dd8c99d1c11  pop rax
00007dd8c99d1c12  add rsp, 0x08
00007dd8c99d1c16  jmp 0x00007DD8C99CFAAF
00007dd8c99d1c1b  sub rsp, 0x08
00007dd8c99d1c1f  push rax
00007dd8c99d1c20  push rcx
00007dd8c99d1c21  push rdx
00007dd8c99d1c22  push rdi
00007dd8c99d1c23  push rsi
00007dd8c99d1c24  push r8
00007dd8c99d1c26  push r9
00007dd8c99d1c28  push r10
00007dd8c99d1c2a  push r11
00007dd8c99d1c2c  sub rsp, 0xF0
00007dd8c99d1c33  vmovaps [rsp], xmm0
00007dd8c99d1c38  vmovaps [rsp+0x10], xmm1
00007dd8c99d1c3e  vmovaps [rsp+0x20], xmm2
00007dd8c99d1c44  vmovaps [rsp+0x30], xmm3
00007dd8c99d1c4a  vmovaps [rsp+0x40], xmm4
00007dd8c99d1c50  vmovaps [rsp+0x50], xmm5
00007dd8c99d1c56  vmovaps [rsp+0x60], xmm6
00007dd8c99d1c5c  vmovaps [rsp+0x70], xmm7
00007dd8c99d1c62  vmovaps [rsp+0x80], xmm8
00007dd8c99d1c6b  vmovaps [rsp+0x90], xmm9
00007dd8c99d1c74  vmovaps [rsp+0xA0], xmm10
00007dd8c99d1c7d  vmovaps [rsp+0xB0], xmm11
00007dd8c99d1c86  vmovaps [rsp+0xC0], xmm12
00007dd8c99d1c8f  vmovaps [rsp+0xD0], xmm13
00007dd8c99d1c98  vmovaps [rsp+0xE0], xmm14
00007dd8c99d1ca1  sub rsp, 0x30
00007dd8c99d1ca5  movaps [rsp], xmm15
00007dd8c99d1caa  movaps [rsp+0x10], xmm13
00007dd8c99d1cb0  movaps [rsp+0x20], xmm1
00007dd8c99d1cb5  lea rdi, [rsp]
00007dd8c99d1cb9  mov esi, 0x00
00007dd8c99d1cbe  mov rax, 0x55FEBBDB5530
00007dd8c99d1cc8  call rax
00007dd8c99d1cca  movaps xmm15, [rsp]
00007dd8c99d1ccf  add rsp, 0x30
00007dd8c99d1cd3  vmovaps xmm0, [rsp]
00007dd8c99d1cd8  vmovaps xmm1, [rsp+0x10]
00007dd8c99d1cde  vmovaps xmm2, [rsp+0x20]
00007dd8c99d1ce4  vmovaps xmm3, [rsp+0x30]
00007dd8c99d1cea  vmovaps xmm4, [rsp+0x40]
00007dd8c99d1cf0  vmovaps xmm5, [rsp+0x50]
00007dd8c99d1cf6  vmovaps xmm6, [rsp+0x60]
00007dd8c99d1cfc  vmovaps xmm7, [rsp+0x70]
00007dd8c99d1d02  vmovaps xmm8, [rsp+0x80]
00007dd8c99d1d0b  vmovaps xmm9, [rsp+0x90]
00007dd8c99d1d14  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d1d1d  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d1d26  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d1d2f  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d1d38  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d1d41  add rsp, 0xF0
00007dd8c99d1d48  pop r11
00007dd8c99d1d4a  pop r10
00007dd8c99d1d4c  pop r9
00007dd8c99d1d4e  pop r8
00007dd8c99d1d50  pop rsi
00007dd8c99d1d51  pop rdi
00007dd8c99d1d52  pop rdx
00007dd8c99d1d53  pop rcx
00007dd8c99d1d54  pop rax
00007dd8c99d1d55  add rsp, 0x08
00007dd8c99d1d59  jmp 0x00007DD8C99CFAEB
00007dd8c99d1d5e  call 0x00007DD8C97FF430
00007dd8c99d1d63  jmp 0x00007DD8C99CFAF8
00007dd8c99d1d68  sub rsp, 0x08
00007dd8c99d1d6c  push rax
00007dd8c99d1d6d  push rcx
00007dd8c99d1d6e  push rdx
00007dd8c99d1d6f  push rdi
00007dd8c99d1d70  push rsi
00007dd8c99d1d71  push r8
00007dd8c99d1d73  push r9
00007dd8c99d1d75  push r10
00007dd8c99d1d77  push r11
00007dd8c99d1d79  sub rsp, 0xF0
00007dd8c99d1d80  vmovaps [rsp], xmm0
00007dd8c99d1d85  vmovaps [rsp+0x10], xmm1
00007dd8c99d1d8b  vmovaps [rsp+0x20], xmm2
00007dd8c99d1d91  vmovaps [rsp+0x30], xmm3
00007dd8c99d1d97  vmovaps [rsp+0x40], xmm4
00007dd8c99d1d9d  vmovaps [rsp+0x50], xmm5
00007dd8c99d1da3  vmovaps [rsp+0x60], xmm6
00007dd8c99d1da9  vmovaps [rsp+0x70], xmm7
00007dd8c99d1daf  vmovaps [rsp+0x80], xmm8
00007dd8c99d1db8  vmovaps [rsp+0x90], xmm9
00007dd8c99d1dc1  vmovaps [rsp+0xA0], xmm10
00007dd8c99d1dca  vmovaps [rsp+0xB0], xmm11
00007dd8c99d1dd3  vmovaps [rsp+0xC0], xmm12
00007dd8c99d1ddc  vmovaps [rsp+0xD0], xmm13
00007dd8c99d1de5  vmovaps [rsp+0xE0], xmm15
00007dd8c99d1dee  sub rsp, 0x30
00007dd8c99d1df2  movaps [rsp], xmm14
00007dd8c99d1df7  movaps [rsp+0x10], xmm13
00007dd8c99d1dfd  movaps [rsp+0x20], xmm2
00007dd8c99d1e02  lea rdi, [rsp]
00007dd8c99d1e06  mov esi, 0x00
00007dd8c99d1e0b  mov rax, 0x55FEBBDB5530
00007dd8c99d1e15  call rax
00007dd8c99d1e17  movaps xmm14, [rsp]
00007dd8c99d1e1c  add rsp, 0x30
00007dd8c99d1e20  vmovaps xmm0, [rsp]
00007dd8c99d1e25  vmovaps xmm1, [rsp+0x10]
00007dd8c99d1e2b  vmovaps xmm2, [rsp+0x20]
00007dd8c99d1e31  vmovaps xmm3, [rsp+0x30]
00007dd8c99d1e37  vmovaps xmm4, [rsp+0x40]
00007dd8c99d1e3d  vmovaps xmm5, [rsp+0x50]
00007dd8c99d1e43  vmovaps xmm6, [rsp+0x60]
00007dd8c99d1e49  vmovaps xmm7, [rsp+0x70]
00007dd8c99d1e4f  vmovaps xmm8, [rsp+0x80]
00007dd8c99d1e58  vmovaps xmm9, [rsp+0x90]
00007dd8c99d1e61  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d1e6a  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d1e73  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d1e7c  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d1e85  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d1e8e  add rsp, 0xF0
00007dd8c99d1e95  pop r11
00007dd8c99d1e97  pop r10
00007dd8c99d1e99  pop r9
00007dd8c99d1e9b  pop r8
00007dd8c99d1e9d  pop rsi
00007dd8c99d1e9e  pop rdi
00007dd8c99d1e9f  pop rdx
00007dd8c99d1ea0  pop rcx
00007dd8c99d1ea1  pop rax
00007dd8c99d1ea2  add rsp, 0x08
00007dd8c99d1ea6  jmp 0x00007DD8C99CFB24
00007dd8c99d1eab  sub rsp, 0x08
00007dd8c99d1eaf  push rax
00007dd8c99d1eb0  push rcx
00007dd8c99d1eb1  push rdx
00007dd8c99d1eb2  push rdi
00007dd8c99d1eb3  push rsi
00007dd8c99d1eb4  push r8
00007dd8c99d1eb6  push r9
00007dd8c99d1eb8  push r10
00007dd8c99d1eba  push r11
00007dd8c99d1ebc  sub rsp, 0xF0
00007dd8c99d1ec3  vmovaps [rsp], xmm0
00007dd8c99d1ec8  vmovaps [rsp+0x10], xmm2
00007dd8c99d1ece  vmovaps [rsp+0x20], xmm3
00007dd8c99d1ed4  vmovaps [rsp+0x30], xmm4
00007dd8c99d1eda  vmovaps [rsp+0x40], xmm5
00007dd8c99d1ee0  vmovaps [rsp+0x50], xmm6
00007dd8c99d1ee6  vmovaps [rsp+0x60], xmm7
00007dd8c99d1eec  vmovaps [rsp+0x70], xmm8
00007dd8c99d1ef2  vmovaps [rsp+0x80], xmm9
00007dd8c99d1efb  vmovaps [rsp+0x90], xmm10
00007dd8c99d1f04  vmovaps [rsp+0xA0], xmm11
00007dd8c99d1f0d  vmovaps [rsp+0xB0], xmm12
00007dd8c99d1f16  vmovaps [rsp+0xC0], xmm13
00007dd8c99d1f1f  vmovaps [rsp+0xD0], xmm14
00007dd8c99d1f28  vmovaps [rsp+0xE0], xmm15
00007dd8c99d1f31  sub rsp, 0x30
00007dd8c99d1f35  movaps [rsp], xmm1
00007dd8c99d1f39  movaps [rsp+0x10], xmm13
00007dd8c99d1f3f  movaps [rsp+0x20], xmm2
00007dd8c99d1f44  lea rdi, [rsp]
00007dd8c99d1f48  mov esi, 0x00
00007dd8c99d1f4d  mov rax, 0x55FEBBDB5530
00007dd8c99d1f57  call rax
00007dd8c99d1f59  movaps xmm1, [rsp]
00007dd8c99d1f5d  add rsp, 0x30
00007dd8c99d1f61  vmovaps xmm0, [rsp]
00007dd8c99d1f66  vmovaps xmm2, [rsp+0x10]
00007dd8c99d1f6c  vmovaps xmm3, [rsp+0x20]
00007dd8c99d1f72  vmovaps xmm4, [rsp+0x30]
00007dd8c99d1f78  vmovaps xmm5, [rsp+0x40]
00007dd8c99d1f7e  vmovaps xmm6, [rsp+0x50]
00007dd8c99d1f84  vmovaps xmm7, [rsp+0x60]
00007dd8c99d1f8a  vmovaps xmm8, [rsp+0x70]
00007dd8c99d1f90  vmovaps xmm9, [rsp+0x80]
00007dd8c99d1f99  vmovaps xmm10, [rsp+0x90]
00007dd8c99d1fa2  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d1fab  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d1fb4  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d1fbd  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d1fc6  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d1fcf  add rsp, 0xF0
00007dd8c99d1fd6  pop r11
00007dd8c99d1fd8  pop r10
00007dd8c99d1fda  pop r9
00007dd8c99d1fdc  pop r8
00007dd8c99d1fde  pop rsi
00007dd8c99d1fdf  pop rdi
00007dd8c99d1fe0  pop rdx
00007dd8c99d1fe1  pop rcx
00007dd8c99d1fe2  pop rax
00007dd8c99d1fe3  add rsp, 0x08
00007dd8c99d1fe7  jmp 0x00007DD8C99CFB52
00007dd8c99d1fec  sub rsp, 0x08
00007dd8c99d1ff0  push rax
00007dd8c99d1ff1  push rcx
00007dd8c99d1ff2  push rdx
00007dd8c99d1ff3  push rdi
00007dd8c99d1ff4  push rsi
00007dd8c99d1ff5  push r8
00007dd8c99d1ff7  push r9
00007dd8c99d1ff9  push r10
00007dd8c99d1ffb  push r11
00007dd8c99d1ffd  sub rsp, 0xF0
00007dd8c99d2004  vmovaps [rsp], xmm0
00007dd8c99d2009  vmovaps [rsp+0x10], xmm1
00007dd8c99d200f  vmovaps [rsp+0x20], xmm3
00007dd8c99d2015  vmovaps [rsp+0x30], xmm4
00007dd8c99d201b  vmovaps [rsp+0x40], xmm5
00007dd8c99d2021  vmovaps [rsp+0x50], xmm6
00007dd8c99d2027  vmovaps [rsp+0x60], xmm7
00007dd8c99d202d  vmovaps [rsp+0x70], xmm8
00007dd8c99d2033  vmovaps [rsp+0x80], xmm9
00007dd8c99d203c  vmovaps [rsp+0x90], xmm10
00007dd8c99d2045  vmovaps [rsp+0xA0], xmm11
00007dd8c99d204e  vmovaps [rsp+0xB0], xmm12
00007dd8c99d2057  vmovaps [rsp+0xC0], xmm13
00007dd8c99d2060  vmovaps [rsp+0xD0], xmm14
00007dd8c99d2069  vmovaps [rsp+0xE0], xmm15
00007dd8c99d2072  sub rsp, 0x30
00007dd8c99d2076  movaps [rsp], xmm2
00007dd8c99d207a  movaps [rsp+0x10], xmm1
00007dd8c99d207f  movaps [rsp+0x20], xmm13
00007dd8c99d2085  lea rdi, [rsp]
00007dd8c99d2089  mov esi, 0x00
00007dd8c99d208e  mov rax, 0x55FEBBDB5530
00007dd8c99d2098  call rax
00007dd8c99d209a  movaps xmm2, [rsp]
00007dd8c99d209e  add rsp, 0x30
00007dd8c99d20a2  vmovaps xmm0, [rsp]
00007dd8c99d20a7  vmovaps xmm1, [rsp+0x10]
00007dd8c99d20ad  vmovaps xmm3, [rsp+0x20]
00007dd8c99d20b3  vmovaps xmm4, [rsp+0x30]
00007dd8c99d20b9  vmovaps xmm5, [rsp+0x40]
00007dd8c99d20bf  vmovaps xmm6, [rsp+0x50]
00007dd8c99d20c5  vmovaps xmm7, [rsp+0x60]
00007dd8c99d20cb  vmovaps xmm8, [rsp+0x70]
00007dd8c99d20d1  vmovaps xmm9, [rsp+0x80]
00007dd8c99d20da  vmovaps xmm10, [rsp+0x90]
00007dd8c99d20e3  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d20ec  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d20f5  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d20fe  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d2107  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d2110  add rsp, 0xF0
00007dd8c99d2117  pop r11
00007dd8c99d2119  pop r10
00007dd8c99d211b  pop r9
00007dd8c99d211d  pop r8
00007dd8c99d211f  pop rsi
00007dd8c99d2120  pop rdi
00007dd8c99d2121  pop rdx
00007dd8c99d2122  pop rcx
00007dd8c99d2123  pop rax
00007dd8c99d2124  add rsp, 0x08
00007dd8c99d2128  jmp 0x00007DD8C99CFBAB
00007dd8c99d212d  call 0x00007DD8C97FF430
00007dd8c99d2132  jmp 0x00007DD8C99CFBB8
00007dd8c99d2137  sub rsp, 0x08
00007dd8c99d213b  push rax
00007dd8c99d213c  push rcx
00007dd8c99d213d  push rdx
00007dd8c99d213e  push rdi
00007dd8c99d213f  push rsi
00007dd8c99d2140  push r8
00007dd8c99d2142  push r9
00007dd8c99d2144  push r10
00007dd8c99d2146  push r11
00007dd8c99d2148  sub rsp, 0xF0
00007dd8c99d214f  vmovaps [rsp], xmm0
00007dd8c99d2154  vmovaps [rsp+0x10], xmm1
00007dd8c99d215a  vmovaps [rsp+0x20], xmm2
00007dd8c99d2160  vmovaps [rsp+0x30], xmm3
00007dd8c99d2166  vmovaps [rsp+0x40], xmm4
00007dd8c99d216c  vmovaps [rsp+0x50], xmm5
00007dd8c99d2172  vmovaps [rsp+0x60], xmm6
00007dd8c99d2178  vmovaps [rsp+0x70], xmm7
00007dd8c99d217e  vmovaps [rsp+0x80], xmm8
00007dd8c99d2187  vmovaps [rsp+0x90], xmm9
00007dd8c99d2190  vmovaps [rsp+0xA0], xmm10
00007dd8c99d2199  vmovaps [rsp+0xB0], xmm11
00007dd8c99d21a2  vmovaps [rsp+0xC0], xmm12
00007dd8c99d21ab  vmovaps [rsp+0xD0], xmm13
00007dd8c99d21b4  vmovaps [rsp+0xE0], xmm14
00007dd8c99d21bd  sub rsp, 0x30
00007dd8c99d21c1  movaps [rsp], xmm15
00007dd8c99d21c6  movaps [rsp+0x10], xmm13
00007dd8c99d21cc  movaps [rsp+0x20], xmm1
00007dd8c99d21d1  lea rdi, [rsp]
00007dd8c99d21d5  mov esi, 0x00
00007dd8c99d21da  mov rax, 0x55FEBBDB5530
00007dd8c99d21e4  call rax
00007dd8c99d21e6  movaps xmm15, [rsp]
00007dd8c99d21eb  add rsp, 0x30
00007dd8c99d21ef  vmovaps xmm0, [rsp]
00007dd8c99d21f4  vmovaps xmm1, [rsp+0x10]
00007dd8c99d21fa  vmovaps xmm2, [rsp+0x20]
00007dd8c99d2200  vmovaps xmm3, [rsp+0x30]
00007dd8c99d2206  vmovaps xmm4, [rsp+0x40]
00007dd8c99d220c  vmovaps xmm5, [rsp+0x50]
00007dd8c99d2212  vmovaps xmm6, [rsp+0x60]
00007dd8c99d2218  vmovaps xmm7, [rsp+0x70]
00007dd8c99d221e  vmovaps xmm8, [rsp+0x80]
00007dd8c99d2227  vmovaps xmm9, [rsp+0x90]
00007dd8c99d2230  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d2239  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d2242  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d224b  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d2254  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d225d  add rsp, 0xF0
00007dd8c99d2264  pop r11
00007dd8c99d2266  pop r10
00007dd8c99d2268  pop r9
00007dd8c99d226a  pop r8
00007dd8c99d226c  pop rsi
00007dd8c99d226d  pop rdi
00007dd8c99d226e  pop rdx
00007dd8c99d226f  pop rcx
00007dd8c99d2270  pop rax
00007dd8c99d2271  add rsp, 0x08
00007dd8c99d2275  jmp 0x00007DD8C99CFBF7
00007dd8c99d227a  sub rsp, 0x08
00007dd8c99d227e  push rax
00007dd8c99d227f  push rcx
00007dd8c99d2280  push rdx
00007dd8c99d2281  push rdi
00007dd8c99d2282  push rsi
00007dd8c99d2283  push r8
00007dd8c99d2285  push r9
00007dd8c99d2287  push r10
00007dd8c99d2289  push r11
00007dd8c99d228b  sub rsp, 0xF0
00007dd8c99d2292  vmovaps [rsp], xmm0
00007dd8c99d2297  vmovaps [rsp+0x10], xmm1
00007dd8c99d229d  vmovaps [rsp+0x20], xmm2
00007dd8c99d22a3  vmovaps [rsp+0x30], xmm3
00007dd8c99d22a9  vmovaps [rsp+0x40], xmm4
00007dd8c99d22af  vmovaps [rsp+0x50], xmm5
00007dd8c99d22b5  vmovaps [rsp+0x60], xmm6
00007dd8c99d22bb  vmovaps [rsp+0x70], xmm7
00007dd8c99d22c1  vmovaps [rsp+0x80], xmm8
00007dd8c99d22ca  vmovaps [rsp+0x90], xmm9
00007dd8c99d22d3  vmovaps [rsp+0xA0], xmm10
00007dd8c99d22dc  vmovaps [rsp+0xB0], xmm11
00007dd8c99d22e5  vmovaps [rsp+0xC0], xmm12
00007dd8c99d22ee  vmovaps [rsp+0xD0], xmm13
00007dd8c99d22f7  vmovaps [rsp+0xE0], xmm15
00007dd8c99d2300  sub rsp, 0x30
00007dd8c99d2304  movaps [rsp], xmm14
00007dd8c99d2309  movaps [rsp+0x10], xmm11
00007dd8c99d230f  movaps [rsp+0x20], xmm1
00007dd8c99d2314  lea rdi, [rsp]
00007dd8c99d2318  mov esi, 0x00
00007dd8c99d231d  mov rax, 0x55FEBBDB5530
00007dd8c99d2327  call rax
00007dd8c99d2329  movaps xmm14, [rsp]
00007dd8c99d232e  add rsp, 0x30
00007dd8c99d2332  vmovaps xmm0, [rsp]
00007dd8c99d2337  vmovaps xmm1, [rsp+0x10]
00007dd8c99d233d  vmovaps xmm2, [rsp+0x20]
00007dd8c99d2343  vmovaps xmm3, [rsp+0x30]
00007dd8c99d2349  vmovaps xmm4, [rsp+0x40]
00007dd8c99d234f  vmovaps xmm5, [rsp+0x50]
00007dd8c99d2355  vmovaps xmm6, [rsp+0x60]
00007dd8c99d235b  vmovaps xmm7, [rsp+0x70]
00007dd8c99d2361  vmovaps xmm8, [rsp+0x80]
00007dd8c99d236a  vmovaps xmm9, [rsp+0x90]
00007dd8c99d2373  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d237c  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d2385  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d238e  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d2397  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d23a0  add rsp, 0xF0
00007dd8c99d23a7  pop r11
00007dd8c99d23a9  pop r10
00007dd8c99d23ab  pop r9
00007dd8c99d23ad  pop r8
00007dd8c99d23af  pop rsi
00007dd8c99d23b0  pop rdi
00007dd8c99d23b1  pop rdx
00007dd8c99d23b2  pop rcx
00007dd8c99d23b3  pop rax
00007dd8c99d23b4  add rsp, 0x08
00007dd8c99d23b8  jmp 0x00007DD8C99CFC21
00007dd8c99d23bd  sub rsp, 0x08
00007dd8c99d23c1  push rax
00007dd8c99d23c2  push rcx
00007dd8c99d23c3  push rdx
00007dd8c99d23c4  push rdi
00007dd8c99d23c5  push rsi
00007dd8c99d23c6  push r8
00007dd8c99d23c8  push r9
00007dd8c99d23ca  push r10
00007dd8c99d23cc  push r11
00007dd8c99d23ce  sub rsp, 0xF0
00007dd8c99d23d5  vmovaps [rsp], xmm0
00007dd8c99d23da  vmovaps [rsp+0x10], xmm1
00007dd8c99d23e0  vmovaps [rsp+0x20], xmm2
00007dd8c99d23e6  vmovaps [rsp+0x30], xmm3
00007dd8c99d23ec  vmovaps [rsp+0x40], xmm4
00007dd8c99d23f2  vmovaps [rsp+0x50], xmm5
00007dd8c99d23f8  vmovaps [rsp+0x60], xmm6
00007dd8c99d23fe  vmovaps [rsp+0x70], xmm7
00007dd8c99d2404  vmovaps [rsp+0x80], xmm8
00007dd8c99d240d  vmovaps [rsp+0x90], xmm9
00007dd8c99d2416  vmovaps [rsp+0xA0], xmm10
00007dd8c99d241f  vmovaps [rsp+0xB0], xmm11
00007dd8c99d2428  vmovaps [rsp+0xC0], xmm12
00007dd8c99d2431  vmovaps [rsp+0xD0], xmm14
00007dd8c99d243a  vmovaps [rsp+0xE0], xmm15
00007dd8c99d2443  sub rsp, 0x30
00007dd8c99d2447  movaps [rsp], xmm13
00007dd8c99d244c  movaps [rsp+0x10], xmm11
00007dd8c99d2452  movaps [rsp+0x20], xmm1
00007dd8c99d2457  lea rdi, [rsp]
00007dd8c99d245b  mov esi, 0x00
00007dd8c99d2460  mov rax, 0x55FEBBDB5530
00007dd8c99d246a  call rax
00007dd8c99d246c  movaps xmm13, [rsp]
00007dd8c99d2471  add rsp, 0x30
00007dd8c99d2475  vmovaps xmm0, [rsp]
00007dd8c99d247a  vmovaps xmm1, [rsp+0x10]
00007dd8c99d2480  vmovaps xmm2, [rsp+0x20]
00007dd8c99d2486  vmovaps xmm3, [rsp+0x30]
00007dd8c99d248c  vmovaps xmm4, [rsp+0x40]
00007dd8c99d2492  vmovaps xmm5, [rsp+0x50]
00007dd8c99d2498  vmovaps xmm6, [rsp+0x60]
00007dd8c99d249e  vmovaps xmm7, [rsp+0x70]
00007dd8c99d24a4  vmovaps xmm8, [rsp+0x80]
00007dd8c99d24ad  vmovaps xmm9, [rsp+0x90]
00007dd8c99d24b6  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d24bf  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d24c8  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d24d1  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d24da  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d24e3  add rsp, 0xF0
00007dd8c99d24ea  pop r11
00007dd8c99d24ec  pop r10
00007dd8c99d24ee  pop r9
00007dd8c99d24f0  pop r8
00007dd8c99d24f2  pop rsi
00007dd8c99d24f3  pop rdi
00007dd8c99d24f4  pop rdx
00007dd8c99d24f5  pop rcx
00007dd8c99d24f6  pop rax
00007dd8c99d24f7  add rsp, 0x08
00007dd8c99d24fb  jmp 0x00007DD8C99CFC76
00007dd8c99d2500  call 0x00007DD8C97FF430
00007dd8c99d2505  jmp 0x00007DD8C99CFC83
00007dd8c99d250a  sub rsp, 0x08
00007dd8c99d250e  push rax
00007dd8c99d250f  push rcx
00007dd8c99d2510  push rdx
00007dd8c99d2511  push rdi
00007dd8c99d2512  push rsi
00007dd8c99d2513  push r8
00007dd8c99d2515  push r9
00007dd8c99d2517  push r10
00007dd8c99d2519  push r11
00007dd8c99d251b  sub rsp, 0xF0
00007dd8c99d2522  vmovaps [rsp], xmm0
00007dd8c99d2527  vmovaps [rsp+0x10], xmm1
00007dd8c99d252d  vmovaps [rsp+0x20], xmm2
00007dd8c99d2533  vmovaps [rsp+0x30], xmm3
00007dd8c99d2539  vmovaps [rsp+0x40], xmm4
00007dd8c99d253f  vmovaps [rsp+0x50], xmm5
00007dd8c99d2545  vmovaps [rsp+0x60], xmm6
00007dd8c99d254b  vmovaps [rsp+0x70], xmm7
00007dd8c99d2551  vmovaps [rsp+0x80], xmm8
00007dd8c99d255a  vmovaps [rsp+0x90], xmm9
00007dd8c99d2563  vmovaps [rsp+0xA0], xmm10
00007dd8c99d256c  vmovaps [rsp+0xB0], xmm11
00007dd8c99d2575  vmovaps [rsp+0xC0], xmm12
00007dd8c99d257e  vmovaps [rsp+0xD0], xmm13
00007dd8c99d2587  vmovaps [rsp+0xE0], xmm14
00007dd8c99d2590  sub rsp, 0x30
00007dd8c99d2594  movaps [rsp], xmm15
00007dd8c99d2599  movaps [rsp+0x10], xmm11
00007dd8c99d259f  movaps [rsp+0x20], xmm1
00007dd8c99d25a4  lea rdi, [rsp]
00007dd8c99d25a8  mov esi, 0x00
00007dd8c99d25ad  mov rax, 0x55FEBBDB5530
00007dd8c99d25b7  call rax
00007dd8c99d25b9  movaps xmm15, [rsp]
00007dd8c99d25be  add rsp, 0x30
00007dd8c99d25c2  vmovaps xmm0, [rsp]
00007dd8c99d25c7  vmovaps xmm1, [rsp+0x10]
00007dd8c99d25cd  vmovaps xmm2, [rsp+0x20]
00007dd8c99d25d3  vmovaps xmm3, [rsp+0x30]
00007dd8c99d25d9  vmovaps xmm4, [rsp+0x40]
00007dd8c99d25df  vmovaps xmm5, [rsp+0x50]
00007dd8c99d25e5  vmovaps xmm6, [rsp+0x60]
00007dd8c99d25eb  vmovaps xmm7, [rsp+0x70]
00007dd8c99d25f1  vmovaps xmm8, [rsp+0x80]
00007dd8c99d25fa  vmovaps xmm9, [rsp+0x90]
00007dd8c99d2603  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d260c  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d2615  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d261e  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d2627  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d2630  add rsp, 0xF0
00007dd8c99d2637  pop r11
00007dd8c99d2639  pop r10
00007dd8c99d263b  pop r9
00007dd8c99d263d  pop r8
00007dd8c99d263f  pop rsi
00007dd8c99d2640  pop rdi
00007dd8c99d2641  pop rdx
00007dd8c99d2642  pop rcx
00007dd8c99d2643  pop rax
00007dd8c99d2644  add rsp, 0x08
00007dd8c99d2648  jmp 0x00007DD8C99CFCBC
00007dd8c99d264d  sub rsp, 0x08
00007dd8c99d2651  push rax
00007dd8c99d2652  push rcx
00007dd8c99d2653  push rdx
00007dd8c99d2654  push rdi
00007dd8c99d2655  push rsi
00007dd8c99d2656  push r8
00007dd8c99d2658  push r9
00007dd8c99d265a  push r10
00007dd8c99d265c  push r11
00007dd8c99d265e  sub rsp, 0xF0
00007dd8c99d2665  vmovaps [rsp], xmm0
00007dd8c99d266a  vmovaps [rsp+0x10], xmm1
00007dd8c99d2670  vmovaps [rsp+0x20], xmm2
00007dd8c99d2676  vmovaps [rsp+0x30], xmm3
00007dd8c99d267c  vmovaps [rsp+0x40], xmm4
00007dd8c99d2682  vmovaps [rsp+0x50], xmm5
00007dd8c99d2688  vmovaps [rsp+0x60], xmm6
00007dd8c99d268e  vmovaps [rsp+0x70], xmm7
00007dd8c99d2694  vmovaps [rsp+0x80], xmm8
00007dd8c99d269d  vmovaps [rsp+0x90], xmm9
00007dd8c99d26a6  vmovaps [rsp+0xA0], xmm10
00007dd8c99d26af  vmovaps [rsp+0xB0], xmm12
00007dd8c99d26b8  vmovaps [rsp+0xC0], xmm13
00007dd8c99d26c1  vmovaps [rsp+0xD0], xmm14
00007dd8c99d26ca  vmovaps [rsp+0xE0], xmm15
00007dd8c99d26d3  sub rsp, 0x30
00007dd8c99d26d7  movaps [rsp], xmm11
00007dd8c99d26dc  movaps [rsp+0x10], xmm6
00007dd8c99d26e1  movaps [rsp+0x20], xmm14
00007dd8c99d26e7  lea rdi, [rsp]
00007dd8c99d26eb  mov esi, 0x00
00007dd8c99d26f0  mov rax, 0x55FEBBDB5530
00007dd8c99d26fa  call rax
00007dd8c99d26fc  movaps xmm11, [rsp]
00007dd8c99d2701  add rsp, 0x30
00007dd8c99d2705  vmovaps xmm0, [rsp]
00007dd8c99d270a  vmovaps xmm1, [rsp+0x10]
00007dd8c99d2710  vmovaps xmm2, [rsp+0x20]
00007dd8c99d2716  vmovaps xmm3, [rsp+0x30]
00007dd8c99d271c  vmovaps xmm4, [rsp+0x40]
00007dd8c99d2722  vmovaps xmm5, [rsp+0x50]
00007dd8c99d2728  vmovaps xmm6, [rsp+0x60]
00007dd8c99d272e  vmovaps xmm7, [rsp+0x70]
00007dd8c99d2734  vmovaps xmm8, [rsp+0x80]
00007dd8c99d273d  vmovaps xmm9, [rsp+0x90]
00007dd8c99d2746  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d274f  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d2758  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d2761  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d276a  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d2773  add rsp, 0xF0
00007dd8c99d277a  pop r11
00007dd8c99d277c  pop r10
00007dd8c99d277e  pop r9
00007dd8c99d2780  pop r8
00007dd8c99d2782  pop rsi
00007dd8c99d2783  pop rdi
00007dd8c99d2784  pop rdx
00007dd8c99d2785  pop rcx
00007dd8c99d2786  pop rax
00007dd8c99d2787  add rsp, 0x08
00007dd8c99d278b  jmp 0x00007DD8C99CFD34
00007dd8c99d2790  call 0x00007DD8C97FF430
00007dd8c99d2795  jmp 0x00007DD8C99CFD3E
00007dd8c99d279a  sub rsp, 0x08
00007dd8c99d279e  push rax
00007dd8c99d279f  push rcx
00007dd8c99d27a0  push rdx
00007dd8c99d27a1  push rdi
00007dd8c99d27a2  push rsi
00007dd8c99d27a3  push r8
00007dd8c99d27a5  push r9
00007dd8c99d27a7  push r10
00007dd8c99d27a9  push r11
00007dd8c99d27ab  sub rsp, 0xF0
00007dd8c99d27b2  vmovaps [rsp], xmm0
00007dd8c99d27b7  vmovaps [rsp+0x10], xmm1
00007dd8c99d27bd  vmovaps [rsp+0x20], xmm2
00007dd8c99d27c3  vmovaps [rsp+0x30], xmm3
00007dd8c99d27c9  vmovaps [rsp+0x40], xmm4
00007dd8c99d27cf  vmovaps [rsp+0x50], xmm5
00007dd8c99d27d5  vmovaps [rsp+0x60], xmm6
00007dd8c99d27db  vmovaps [rsp+0x70], xmm7
00007dd8c99d27e1  vmovaps [rsp+0x80], xmm8
00007dd8c99d27ea  vmovaps [rsp+0x90], xmm9
00007dd8c99d27f3  vmovaps [rsp+0xA0], xmm10
00007dd8c99d27fc  vmovaps [rsp+0xB0], xmm11
00007dd8c99d2805  vmovaps [rsp+0xC0], xmm12
00007dd8c99d280e  vmovaps [rsp+0xD0], xmm13
00007dd8c99d2817  vmovaps [rsp+0xE0], xmm15
00007dd8c99d2820  sub rsp, 0x30
00007dd8c99d2824  movaps [rsp], xmm14
00007dd8c99d2829  movaps [rsp+0x10], xmm6
00007dd8c99d282e  movaps [rsp+0x20], xmm2
00007dd8c99d2833  lea rdi, [rsp]
00007dd8c99d2837  mov esi, 0x00
00007dd8c99d283c  mov rax, 0x55FEBBDB5530
00007dd8c99d2846  call rax
00007dd8c99d2848  movaps xmm14, [rsp]
00007dd8c99d284d  add rsp, 0x30
00007dd8c99d2851  vmovaps xmm0, [rsp]
00007dd8c99d2856  vmovaps xmm1, [rsp+0x10]
00007dd8c99d285c  vmovaps xmm2, [rsp+0x20]
00007dd8c99d2862  vmovaps xmm3, [rsp+0x30]
00007dd8c99d2868  vmovaps xmm4, [rsp+0x40]
00007dd8c99d286e  vmovaps xmm5, [rsp+0x50]
00007dd8c99d2874  vmovaps xmm6, [rsp+0x60]
00007dd8c99d287a  vmovaps xmm7, [rsp+0x70]
00007dd8c99d2880  vmovaps xmm8, [rsp+0x80]
00007dd8c99d2889  vmovaps xmm9, [rsp+0x90]
00007dd8c99d2892  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d289b  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d28a4  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d28ad  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d28b6  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d28bf  add rsp, 0xF0
00007dd8c99d28c6  pop r11
00007dd8c99d28c8  pop r10
00007dd8c99d28ca  pop r9
00007dd8c99d28cc  pop r8
00007dd8c99d28ce  pop rsi
00007dd8c99d28cf  pop rdi
00007dd8c99d28d0  pop rdx
00007dd8c99d28d1  pop rcx
00007dd8c99d28d2  pop rax
00007dd8c99d28d3  add rsp, 0x08
00007dd8c99d28d7  jmp 0x00007DD8C99CFD72
00007dd8c99d28dc  sub rsp, 0x08
00007dd8c99d28e0  push rax
00007dd8c99d28e1  push rcx
00007dd8c99d28e2  push rdx
00007dd8c99d28e3  push rdi
00007dd8c99d28e4  push rsi
00007dd8c99d28e5  push r8
00007dd8c99d28e7  push r9
00007dd8c99d28e9  push r10
00007dd8c99d28eb  push r11
00007dd8c99d28ed  sub rsp, 0xF0
00007dd8c99d28f4  vmovaps [rsp], xmm0
00007dd8c99d28f9  vmovaps [rsp+0x10], xmm1
00007dd8c99d28ff  vmovaps [rsp+0x20], xmm2
00007dd8c99d2905  vmovaps [rsp+0x30], xmm3
00007dd8c99d290b  vmovaps [rsp+0x40], xmm4
00007dd8c99d2911  vmovaps [rsp+0x50], xmm5
00007dd8c99d2917  vmovaps [rsp+0x60], xmm7
00007dd8c99d291d  vmovaps [rsp+0x70], xmm8
00007dd8c99d2923  vmovaps [rsp+0x80], xmm9
00007dd8c99d292c  vmovaps [rsp+0x90], xmm10
00007dd8c99d2935  vmovaps [rsp+0xA0], xmm11
00007dd8c99d293e  vmovaps [rsp+0xB0], xmm12
00007dd8c99d2947  vmovaps [rsp+0xC0], xmm13
00007dd8c99d2950  vmovaps [rsp+0xD0], xmm14
00007dd8c99d2959  vmovaps [rsp+0xE0], xmm15
00007dd8c99d2962  sub rsp, 0x30
00007dd8c99d2966  movaps [rsp], xmm6
00007dd8c99d296a  movaps [rsp+0x10], xmm5
00007dd8c99d296f  movaps [rsp+0x20], xmm1
00007dd8c99d2974  lea rdi, [rsp]
00007dd8c99d2978  mov esi, 0x00
00007dd8c99d297d  mov rax, 0x55FEBBDB5530
00007dd8c99d2987  call rax
00007dd8c99d2989  movaps xmm6, [rsp]
00007dd8c99d298d  add rsp, 0x30
00007dd8c99d2991  vmovaps xmm0, [rsp]
00007dd8c99d2996  vmovaps xmm1, [rsp+0x10]
00007dd8c99d299c  vmovaps xmm2, [rsp+0x20]
00007dd8c99d29a2  vmovaps xmm3, [rsp+0x30]
00007dd8c99d29a8  vmovaps xmm4, [rsp+0x40]
00007dd8c99d29ae  vmovaps xmm5, [rsp+0x50]
00007dd8c99d29b4  vmovaps xmm7, [rsp+0x60]
00007dd8c99d29ba  vmovaps xmm8, [rsp+0x70]
00007dd8c99d29c0  vmovaps xmm9, [rsp+0x80]
00007dd8c99d29c9  vmovaps xmm10, [rsp+0x90]
00007dd8c99d29d2  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d29db  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d29e4  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d29ed  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d29f6  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d29ff  add rsp, 0xF0
00007dd8c99d2a06  pop r11
00007dd8c99d2a08  pop r10
00007dd8c99d2a0a  pop r9
00007dd8c99d2a0c  pop r8
00007dd8c99d2a0e  pop rsi
00007dd8c99d2a0f  pop rdi
00007dd8c99d2a10  pop rdx
00007dd8c99d2a11  pop rcx
00007dd8c99d2a12  pop rax
00007dd8c99d2a13  add rsp, 0x08
00007dd8c99d2a17  jmp 0x00007DD8C99CFD98
00007dd8c99d2a1c  sub rsp, 0x08
00007dd8c99d2a20  push rax
00007dd8c99d2a21  push rcx
00007dd8c99d2a22  push rdx
00007dd8c99d2a23  push rdi
00007dd8c99d2a24  push rsi
00007dd8c99d2a25  push r8
00007dd8c99d2a27  push r9
00007dd8c99d2a29  push r10
00007dd8c99d2a2b  push r11
00007dd8c99d2a2d  sub rsp, 0xF0
00007dd8c99d2a34  vmovaps [rsp], xmm0
00007dd8c99d2a39  vmovaps [rsp+0x10], xmm2
00007dd8c99d2a3f  vmovaps [rsp+0x20], xmm3
00007dd8c99d2a45  vmovaps [rsp+0x30], xmm4
00007dd8c99d2a4b  vmovaps [rsp+0x40], xmm5
00007dd8c99d2a51  vmovaps [rsp+0x50], xmm6
00007dd8c99d2a57  vmovaps [rsp+0x60], xmm7
00007dd8c99d2a5d  vmovaps [rsp+0x70], xmm8
00007dd8c99d2a63  vmovaps [rsp+0x80], xmm9
00007dd8c99d2a6c  vmovaps [rsp+0x90], xmm10
00007dd8c99d2a75  vmovaps [rsp+0xA0], xmm11
00007dd8c99d2a7e  vmovaps [rsp+0xB0], xmm12
00007dd8c99d2a87  vmovaps [rsp+0xC0], xmm13
00007dd8c99d2a90  vmovaps [rsp+0xD0], xmm14
00007dd8c99d2a99  vmovaps [rsp+0xE0], xmm15
00007dd8c99d2aa2  sub rsp, 0x30
00007dd8c99d2aa6  movaps [rsp], xmm1
00007dd8c99d2aaa  movaps [rsp+0x10], xmm5
00007dd8c99d2aaf  movaps [rsp+0x20], xmm13
00007dd8c99d2ab5  lea rdi, [rsp]
00007dd8c99d2ab9  mov esi, 0x00
00007dd8c99d2abe  mov rax, 0x55FEBBDB5530
00007dd8c99d2ac8  call rax
00007dd8c99d2aca  movaps xmm1, [rsp]
00007dd8c99d2ace  add rsp, 0x30
00007dd8c99d2ad2  vmovaps xmm0, [rsp]
00007dd8c99d2ad7  vmovaps xmm2, [rsp+0x10]
00007dd8c99d2add  vmovaps xmm3, [rsp+0x20]
00007dd8c99d2ae3  vmovaps xmm4, [rsp+0x30]
00007dd8c99d2ae9  vmovaps xmm5, [rsp+0x40]
00007dd8c99d2aef  vmovaps xmm6, [rsp+0x50]
00007dd8c99d2af5  vmovaps xmm7, [rsp+0x60]
00007dd8c99d2afb  vmovaps xmm8, [rsp+0x70]
00007dd8c99d2b01  vmovaps xmm9, [rsp+0x80]
00007dd8c99d2b0a  vmovaps xmm10, [rsp+0x90]
00007dd8c99d2b13  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d2b1c  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d2b25  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d2b2e  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d2b37  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d2b40  add rsp, 0xF0
00007dd8c99d2b47  pop r11
00007dd8c99d2b49  pop r10
00007dd8c99d2b4b  pop r9
00007dd8c99d2b4d  pop r8
00007dd8c99d2b4f  pop rsi
00007dd8c99d2b50  pop rdi
00007dd8c99d2b51  pop rdx
00007dd8c99d2b52  pop rcx
00007dd8c99d2b53  pop rax
00007dd8c99d2b54  add rsp, 0x08
00007dd8c99d2b58  jmp 0x00007DD8C99CFDB6
00007dd8c99d2b5d  sub rsp, 0x08
00007dd8c99d2b61  push rax
00007dd8c99d2b62  push rcx
00007dd8c99d2b63  push rdx
00007dd8c99d2b64  push rdi
00007dd8c99d2b65  push rsi
00007dd8c99d2b66  push r8
00007dd8c99d2b68  push r9
00007dd8c99d2b6a  push r10
00007dd8c99d2b6c  push r11
00007dd8c99d2b6e  sub rsp, 0xF0
00007dd8c99d2b75  vmovaps [rsp], xmm0
00007dd8c99d2b7a  vmovaps [rsp+0x10], xmm1
00007dd8c99d2b80  vmovaps [rsp+0x20], xmm2
00007dd8c99d2b86  vmovaps [rsp+0x30], xmm3
00007dd8c99d2b8c  vmovaps [rsp+0x40], xmm4
00007dd8c99d2b92  vmovaps [rsp+0x50], xmm6
00007dd8c99d2b98  vmovaps [rsp+0x60], xmm7
00007dd8c99d2b9e  vmovaps [rsp+0x70], xmm8
00007dd8c99d2ba4  vmovaps [rsp+0x80], xmm9
00007dd8c99d2bad  vmovaps [rsp+0x90], xmm10
00007dd8c99d2bb6  vmovaps [rsp+0xA0], xmm11
00007dd8c99d2bbf  vmovaps [rsp+0xB0], xmm12
00007dd8c99d2bc8  vmovaps [rsp+0xC0], xmm13
00007dd8c99d2bd1  vmovaps [rsp+0xD0], xmm14
00007dd8c99d2bda  vmovaps [rsp+0xE0], xmm15
00007dd8c99d2be3  sub rsp, 0x30
00007dd8c99d2be7  movaps [rsp], xmm5
00007dd8c99d2beb  movaps [rsp+0x10], xmm2
00007dd8c99d2bf0  movaps [rsp+0x20], xmm13
00007dd8c99d2bf6  lea rdi, [rsp]
00007dd8c99d2bfa  mov esi, 0x00
00007dd8c99d2bff  mov rax, 0x55FEBBDB5530
00007dd8c99d2c09  call rax
00007dd8c99d2c0b  movaps xmm5, [rsp]
00007dd8c99d2c0f  add rsp, 0x30
00007dd8c99d2c13  vmovaps xmm0, [rsp]
00007dd8c99d2c18  vmovaps xmm1, [rsp+0x10]
00007dd8c99d2c1e  vmovaps xmm2, [rsp+0x20]
00007dd8c99d2c24  vmovaps xmm3, [rsp+0x30]
00007dd8c99d2c2a  vmovaps xmm4, [rsp+0x40]
00007dd8c99d2c30  vmovaps xmm6, [rsp+0x50]
00007dd8c99d2c36  vmovaps xmm7, [rsp+0x60]
00007dd8c99d2c3c  vmovaps xmm8, [rsp+0x70]
00007dd8c99d2c42  vmovaps xmm9, [rsp+0x80]
00007dd8c99d2c4b  vmovaps xmm10, [rsp+0x90]
00007dd8c99d2c54  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d2c5d  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d2c66  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d2c6f  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d2c78  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d2c81  add rsp, 0xF0
00007dd8c99d2c88  pop r11
00007dd8c99d2c8a  pop r10
00007dd8c99d2c8c  pop r9
00007dd8c99d2c8e  pop r8
00007dd8c99d2c90  pop rsi
00007dd8c99d2c91  pop rdi
00007dd8c99d2c92  pop rdx
00007dd8c99d2c93  pop rcx
00007dd8c99d2c94  pop rax
00007dd8c99d2c95  add rsp, 0x08
00007dd8c99d2c99  jmp 0x00007DD8C99CFDEC
00007dd8c99d2c9e  sub rsp, 0x08
00007dd8c99d2ca2  push rax
00007dd8c99d2ca3  push rcx
00007dd8c99d2ca4  push rdx
00007dd8c99d2ca5  push rdi
00007dd8c99d2ca6  push rsi
00007dd8c99d2ca7  push r8
00007dd8c99d2ca9  push r9
00007dd8c99d2cab  push r10
00007dd8c99d2cad  push r11
00007dd8c99d2caf  sub rsp, 0xF0
00007dd8c99d2cb6  vmovaps [rsp], xmm0
00007dd8c99d2cbb  vmovaps [rsp+0x10], xmm1
00007dd8c99d2cc1  vmovaps [rsp+0x20], xmm2
00007dd8c99d2cc7  vmovaps [rsp+0x30], xmm3
00007dd8c99d2ccd  vmovaps [rsp+0x40], xmm4
00007dd8c99d2cd3  vmovaps [rsp+0x50], xmm5
00007dd8c99d2cd9  vmovaps [rsp+0x60], xmm6
00007dd8c99d2cdf  vmovaps [rsp+0x70], xmm7
00007dd8c99d2ce5  vmovaps [rsp+0x80], xmm8
00007dd8c99d2cee  vmovaps [rsp+0x90], xmm9
00007dd8c99d2cf7  vmovaps [rsp+0xA0], xmm10
00007dd8c99d2d00  vmovaps [rsp+0xB0], xmm11
00007dd8c99d2d09  vmovaps [rsp+0xC0], xmm12
00007dd8c99d2d12  vmovaps [rsp+0xD0], xmm14
00007dd8c99d2d1b  vmovaps [rsp+0xE0], xmm15
00007dd8c99d2d24  sub rsp, 0x30
00007dd8c99d2d28  movaps [rsp], xmm13
00007dd8c99d2d2d  movaps [rsp+0x10], xmm10
00007dd8c99d2d33  movaps [rsp+0x20], xmm1
00007dd8c99d2d38  lea rdi, [rsp]
00007dd8c99d2d3c  mov esi, 0x00
00007dd8c99d2d41  mov rax, 0x55FEBBDB5530
00007dd8c99d2d4b  call rax
00007dd8c99d2d4d  movaps xmm13, [rsp]
00007dd8c99d2d52  add rsp, 0x30
00007dd8c99d2d56  vmovaps xmm0, [rsp]
00007dd8c99d2d5b  vmovaps xmm1, [rsp+0x10]
00007dd8c99d2d61  vmovaps xmm2, [rsp+0x20]
00007dd8c99d2d67  vmovaps xmm3, [rsp+0x30]
00007dd8c99d2d6d  vmovaps xmm4, [rsp+0x40]
00007dd8c99d2d73  vmovaps xmm5, [rsp+0x50]
00007dd8c99d2d79  vmovaps xmm6, [rsp+0x60]
00007dd8c99d2d7f  vmovaps xmm7, [rsp+0x70]
00007dd8c99d2d85  vmovaps xmm8, [rsp+0x80]
00007dd8c99d2d8e  vmovaps xmm9, [rsp+0x90]
00007dd8c99d2d97  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d2da0  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d2da9  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d2db2  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d2dbb  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d2dc4  add rsp, 0xF0
00007dd8c99d2dcb  pop r11
00007dd8c99d2dcd  pop r10
00007dd8c99d2dcf  pop r9
00007dd8c99d2dd1  pop r8
00007dd8c99d2dd3  pop rsi
00007dd8c99d2dd4  pop rdi
00007dd8c99d2dd5  pop rdx
00007dd8c99d2dd6  pop rcx
00007dd8c99d2dd7  pop rax
00007dd8c99d2dd8  add rsp, 0x08
00007dd8c99d2ddc  jmp 0x00007DD8C99CFE15
00007dd8c99d2de1  sub rsp, 0x08
00007dd8c99d2de5  push rax
00007dd8c99d2de6  push rcx
00007dd8c99d2de7  push rdx
00007dd8c99d2de8  push rdi
00007dd8c99d2de9  push rsi
00007dd8c99d2dea  push r8
00007dd8c99d2dec  push r9
00007dd8c99d2dee  push r10
00007dd8c99d2df0  push r11
00007dd8c99d2df2  sub rsp, 0xF0
00007dd8c99d2df9  vmovaps [rsp], xmm0
00007dd8c99d2dfe  vmovaps [rsp+0x10], xmm2
00007dd8c99d2e04  vmovaps [rsp+0x20], xmm3
00007dd8c99d2e0a  vmovaps [rsp+0x30], xmm4
00007dd8c99d2e10  vmovaps [rsp+0x40], xmm5
00007dd8c99d2e16  vmovaps [rsp+0x50], xmm6
00007dd8c99d2e1c  vmovaps [rsp+0x60], xmm7
00007dd8c99d2e22  vmovaps [rsp+0x70], xmm8
00007dd8c99d2e28  vmovaps [rsp+0x80], xmm9
00007dd8c99d2e31  vmovaps [rsp+0x90], xmm10
00007dd8c99d2e3a  vmovaps [rsp+0xA0], xmm11
00007dd8c99d2e43  vmovaps [rsp+0xB0], xmm12
00007dd8c99d2e4c  vmovaps [rsp+0xC0], xmm13
00007dd8c99d2e55  vmovaps [rsp+0xD0], xmm14
00007dd8c99d2e5e  vmovaps [rsp+0xE0], xmm15
00007dd8c99d2e67  sub rsp, 0x30
00007dd8c99d2e6b  movaps [rsp], xmm1
00007dd8c99d2e6f  movaps [rsp+0x10], xmm15
00007dd8c99d2e75  movaps [rsp+0x20], xmm10
00007dd8c99d2e7b  lea rdi, [rsp]
00007dd8c99d2e7f  mov esi, 0x00
00007dd8c99d2e84  mov rax, 0x55FEBBDB5530
00007dd8c99d2e8e  call rax
00007dd8c99d2e90  movaps xmm1, [rsp]
00007dd8c99d2e94  add rsp, 0x30
00007dd8c99d2e98  vmovaps xmm0, [rsp]
00007dd8c99d2e9d  vmovaps xmm2, [rsp+0x10]
00007dd8c99d2ea3  vmovaps xmm3, [rsp+0x20]
00007dd8c99d2ea9  vmovaps xmm4, [rsp+0x30]
00007dd8c99d2eaf  vmovaps xmm5, [rsp+0x40]
00007dd8c99d2eb5  vmovaps xmm6, [rsp+0x50]
00007dd8c99d2ebb  vmovaps xmm7, [rsp+0x60]
00007dd8c99d2ec1  vmovaps xmm8, [rsp+0x70]
00007dd8c99d2ec7  vmovaps xmm9, [rsp+0x80]
00007dd8c99d2ed0  vmovaps xmm10, [rsp+0x90]
00007dd8c99d2ed9  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d2ee2  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d2eeb  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d2ef4  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d2efd  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d2f06  add rsp, 0xF0
00007dd8c99d2f0d  pop r11
00007dd8c99d2f0f  pop r10
00007dd8c99d2f11  pop r9
00007dd8c99d2f13  pop r8
00007dd8c99d2f15  pop rsi
00007dd8c99d2f16  pop rdi
00007dd8c99d2f17  pop rdx
00007dd8c99d2f18  pop rcx
00007dd8c99d2f19  pop rax
00007dd8c99d2f1a  add rsp, 0x08
00007dd8c99d2f1e  jmp 0x00007DD8C99CFE34
00007dd8c99d2f23  sub rsp, 0x08
00007dd8c99d2f27  push rax
00007dd8c99d2f28  push rcx
00007dd8c99d2f29  push rdx
00007dd8c99d2f2a  push rdi
00007dd8c99d2f2b  push rsi
00007dd8c99d2f2c  push r8
00007dd8c99d2f2e  push r9
00007dd8c99d2f30  push r10
00007dd8c99d2f32  push r11
00007dd8c99d2f34  sub rsp, 0xF0
00007dd8c99d2f3b  vmovaps [rsp], xmm0
00007dd8c99d2f40  vmovaps [rsp+0x10], xmm1
00007dd8c99d2f46  vmovaps [rsp+0x20], xmm2
00007dd8c99d2f4c  vmovaps [rsp+0x30], xmm3
00007dd8c99d2f52  vmovaps [rsp+0x40], xmm4
00007dd8c99d2f58  vmovaps [rsp+0x50], xmm5
00007dd8c99d2f5e  vmovaps [rsp+0x60], xmm6
00007dd8c99d2f64  vmovaps [rsp+0x70], xmm7
00007dd8c99d2f6a  vmovaps [rsp+0x80], xmm8
00007dd8c99d2f73  vmovaps [rsp+0x90], xmm9
00007dd8c99d2f7c  vmovaps [rsp+0xA0], xmm10
00007dd8c99d2f85  vmovaps [rsp+0xB0], xmm11
00007dd8c99d2f8e  vmovaps [rsp+0xC0], xmm12
00007dd8c99d2f97  vmovaps [rsp+0xD0], xmm13
00007dd8c99d2fa0  vmovaps [rsp+0xE0], xmm14
00007dd8c99d2fa9  sub rsp, 0x30
00007dd8c99d2fad  movaps [rsp], xmm15
00007dd8c99d2fb2  movaps [rsp+0x10], xmm10
00007dd8c99d2fb8  movaps [rsp+0x20], xmm11
00007dd8c99d2fbe  lea rdi, [rsp]
00007dd8c99d2fc2  mov esi, 0x00
00007dd8c99d2fc7  mov rax, 0x55FEBBDB5530
00007dd8c99d2fd1  call rax
00007dd8c99d2fd3  movaps xmm15, [rsp]
00007dd8c99d2fd8  add rsp, 0x30
00007dd8c99d2fdc  vmovaps xmm0, [rsp]
00007dd8c99d2fe1  vmovaps xmm1, [rsp+0x10]
00007dd8c99d2fe7  vmovaps xmm2, [rsp+0x20]
00007dd8c99d2fed  vmovaps xmm3, [rsp+0x30]
00007dd8c99d2ff3  vmovaps xmm4, [rsp+0x40]
00007dd8c99d2ff9  vmovaps xmm5, [rsp+0x50]
00007dd8c99d2fff  vmovaps xmm6, [rsp+0x60]
00007dd8c99d3005  vmovaps xmm7, [rsp+0x70]
00007dd8c99d300b  vmovaps xmm8, [rsp+0x80]
00007dd8c99d3014  vmovaps xmm9, [rsp+0x90]
00007dd8c99d301d  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d3026  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d302f  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d3038  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d3041  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d304a  add rsp, 0xF0
00007dd8c99d3051  pop r11
00007dd8c99d3053  pop r10
00007dd8c99d3055  pop r9
00007dd8c99d3057  pop r8
00007dd8c99d3059  pop rsi
00007dd8c99d305a  pop rdi
00007dd8c99d305b  pop rdx
00007dd8c99d305c  pop rcx
00007dd8c99d305d  pop rax
00007dd8c99d305e  add rsp, 0x08
00007dd8c99d3062  jmp 0x00007DD8C99CFE57
00007dd8c99d3067  sub rsp, 0x08
00007dd8c99d306b  push rax
00007dd8c99d306c  push rcx
00007dd8c99d306d  push rdx
00007dd8c99d306e  push rdi
00007dd8c99d306f  push rsi
00007dd8c99d3070  push r8
00007dd8c99d3072  push r9
00007dd8c99d3074  push r10
00007dd8c99d3076  push r11
00007dd8c99d3078  sub rsp, 0xF0
00007dd8c99d307f  vmovaps [rsp], xmm0
00007dd8c99d3084  vmovaps [rsp+0x10], xmm1
00007dd8c99d308a  vmovaps [rsp+0x20], xmm2
00007dd8c99d3090  vmovaps [rsp+0x30], xmm3
00007dd8c99d3096  vmovaps [rsp+0x40], xmm4
00007dd8c99d309c  vmovaps [rsp+0x50], xmm5
00007dd8c99d30a2  vmovaps [rsp+0x60], xmm6
00007dd8c99d30a8  vmovaps [rsp+0x70], xmm7
00007dd8c99d30ae  vmovaps [rsp+0x80], xmm8
00007dd8c99d30b7  vmovaps [rsp+0x90], xmm9
00007dd8c99d30c0  vmovaps [rsp+0xA0], xmm11
00007dd8c99d30c9  vmovaps [rsp+0xB0], xmm12
00007dd8c99d30d2  vmovaps [rsp+0xC0], xmm13
00007dd8c99d30db  vmovaps [rsp+0xD0], xmm14
00007dd8c99d30e4  vmovaps [rsp+0xE0], xmm15
00007dd8c99d30ed  sub rsp, 0x30
00007dd8c99d30f1  movaps [rsp], xmm10
00007dd8c99d30f6  movaps [rsp+0x10], xmm12
00007dd8c99d30fc  movaps [rsp+0x20], xmm11
00007dd8c99d3102  lea rdi, [rsp]
00007dd8c99d3106  mov esi, 0x00
00007dd8c99d310b  mov rax, 0x55FEBBDB5530
00007dd8c99d3115  call rax
00007dd8c99d3117  movaps xmm10, [rsp]
00007dd8c99d311c  add rsp, 0x30
00007dd8c99d3120  vmovaps xmm0, [rsp]
00007dd8c99d3125  vmovaps xmm1, [rsp+0x10]
00007dd8c99d312b  vmovaps xmm2, [rsp+0x20]
00007dd8c99d3131  vmovaps xmm3, [rsp+0x30]
00007dd8c99d3137  vmovaps xmm4, [rsp+0x40]
00007dd8c99d313d  vmovaps xmm5, [rsp+0x50]
00007dd8c99d3143  vmovaps xmm6, [rsp+0x60]
00007dd8c99d3149  vmovaps xmm7, [rsp+0x70]
00007dd8c99d314f  vmovaps xmm8, [rsp+0x80]
00007dd8c99d3158  vmovaps xmm9, [rsp+0x90]
00007dd8c99d3161  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d316a  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d3173  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d317c  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d3185  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d318e  add rsp, 0xF0
00007dd8c99d3195  pop r11
00007dd8c99d3197  pop r10
00007dd8c99d3199  pop r9
00007dd8c99d319b  pop r8
00007dd8c99d319d  pop rsi
00007dd8c99d319e  pop rdi
00007dd8c99d319f  pop rdx
00007dd8c99d31a0  pop rcx
00007dd8c99d31a1  pop rax
00007dd8c99d31a2  add rsp, 0x08
00007dd8c99d31a6  jmp 0x00007DD8C99CFE80
00007dd8c99d31ab  sub rsp, 0x08
00007dd8c99d31af  push rax
00007dd8c99d31b0  push rcx
00007dd8c99d31b1  push rdx
00007dd8c99d31b2  push rdi
00007dd8c99d31b3  push rsi
00007dd8c99d31b4  push r8
00007dd8c99d31b6  push r9
00007dd8c99d31b8  push r10
00007dd8c99d31ba  push r11
00007dd8c99d31bc  sub rsp, 0xF0
00007dd8c99d31c3  vmovaps [rsp], xmm0
00007dd8c99d31c8  vmovaps [rsp+0x10], xmm1
00007dd8c99d31ce  vmovaps [rsp+0x20], xmm2
00007dd8c99d31d4  vmovaps [rsp+0x30], xmm3
00007dd8c99d31da  vmovaps [rsp+0x40], xmm4
00007dd8c99d31e0  vmovaps [rsp+0x50], xmm5
00007dd8c99d31e6  vmovaps [rsp+0x60], xmm6
00007dd8c99d31ec  vmovaps [rsp+0x70], xmm7
00007dd8c99d31f2  vmovaps [rsp+0x80], xmm8
00007dd8c99d31fb  vmovaps [rsp+0x90], xmm9
00007dd8c99d3204  vmovaps [rsp+0xA0], xmm10
00007dd8c99d320d  vmovaps [rsp+0xB0], xmm12
00007dd8c99d3216  vmovaps [rsp+0xC0], xmm13
00007dd8c99d321f  vmovaps [rsp+0xD0], xmm14
00007dd8c99d3228  vmovaps [rsp+0xE0], xmm15
00007dd8c99d3231  sub rsp, 0x30
00007dd8c99d3235  movaps [rsp], xmm11
00007dd8c99d323a  movaps [rsp+0x10], xmm2
00007dd8c99d323f  movaps [rsp+0x20], xmm12
00007dd8c99d3245  lea rdi, [rsp]
00007dd8c99d3249  mov esi, 0x00
00007dd8c99d324e  mov rax, 0x55FEBBDB5530
00007dd8c99d3258  call rax
00007dd8c99d325a  movaps xmm11, [rsp]
00007dd8c99d325f  add rsp, 0x30
00007dd8c99d3263  vmovaps xmm0, [rsp]
00007dd8c99d3268  vmovaps xmm1, [rsp+0x10]
00007dd8c99d326e  vmovaps xmm2, [rsp+0x20]
00007dd8c99d3274  vmovaps xmm3, [rsp+0x30]
00007dd8c99d327a  vmovaps xmm4, [rsp+0x40]
00007dd8c99d3280  vmovaps xmm5, [rsp+0x50]
00007dd8c99d3286  vmovaps xmm6, [rsp+0x60]
00007dd8c99d328c  vmovaps xmm7, [rsp+0x70]
00007dd8c99d3292  vmovaps xmm8, [rsp+0x80]
00007dd8c99d329b  vmovaps xmm9, [rsp+0x90]
00007dd8c99d32a4  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d32ad  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d32b6  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d32bf  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d32c8  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d32d1  add rsp, 0xF0
00007dd8c99d32d8  pop r11
00007dd8c99d32da  pop r10
00007dd8c99d32dc  pop r9
00007dd8c99d32de  pop r8
00007dd8c99d32e0  pop rsi
00007dd8c99d32e1  pop rdi
00007dd8c99d32e2  pop rdx
00007dd8c99d32e3  pop rcx
00007dd8c99d32e4  pop rax
00007dd8c99d32e5  add rsp, 0x08
00007dd8c99d32e9  jmp 0x00007DD8C99CFEB8
00007dd8c99d32ee  sub rsp, 0x08
00007dd8c99d32f2  push rax
00007dd8c99d32f3  push rcx
00007dd8c99d32f4  push rdx
00007dd8c99d32f5  push rdi
00007dd8c99d32f6  push rsi
00007dd8c99d32f7  push r8
00007dd8c99d32f9  push r9
00007dd8c99d32fb  push r10
00007dd8c99d32fd  push r11
00007dd8c99d32ff  sub rsp, 0xF0
00007dd8c99d3306  vmovaps [rsp], xmm0
00007dd8c99d330b  vmovaps [rsp+0x10], xmm2
00007dd8c99d3311  vmovaps [rsp+0x20], xmm3
00007dd8c99d3317  vmovaps [rsp+0x30], xmm4
00007dd8c99d331d  vmovaps [rsp+0x40], xmm5
00007dd8c99d3323  vmovaps [rsp+0x50], xmm6
00007dd8c99d3329  vmovaps [rsp+0x60], xmm7
00007dd8c99d332f  vmovaps [rsp+0x70], xmm8
00007dd8c99d3335  vmovaps [rsp+0x80], xmm9
00007dd8c99d333e  vmovaps [rsp+0x90], xmm10
00007dd8c99d3347  vmovaps [rsp+0xA0], xmm11
00007dd8c99d3350  vmovaps [rsp+0xB0], xmm12
00007dd8c99d3359  vmovaps [rsp+0xC0], xmm13
00007dd8c99d3362  vmovaps [rsp+0xD0], xmm14
00007dd8c99d336b  vmovaps [rsp+0xE0], xmm15
00007dd8c99d3374  sub rsp, 0x30
00007dd8c99d3378  movaps [rsp], xmm1
00007dd8c99d337c  movaps [rsp+0x10], xmm14
00007dd8c99d3382  movaps [rsp+0x20], xmm6
00007dd8c99d3387  lea rdi, [rsp]
00007dd8c99d338b  mov esi, 0x00
00007dd8c99d3390  mov rax, 0x55FEBBDB5530
00007dd8c99d339a  call rax
00007dd8c99d339c  movaps xmm1, [rsp]
00007dd8c99d33a0  add rsp, 0x30
00007dd8c99d33a4  vmovaps xmm0, [rsp]
00007dd8c99d33a9  vmovaps xmm2, [rsp+0x10]
00007dd8c99d33af  vmovaps xmm3, [rsp+0x20]
00007dd8c99d33b5  vmovaps xmm4, [rsp+0x30]
00007dd8c99d33bb  vmovaps xmm5, [rsp+0x40]
00007dd8c99d33c1  vmovaps xmm6, [rsp+0x50]
00007dd8c99d33c7  vmovaps xmm7, [rsp+0x60]
00007dd8c99d33cd  vmovaps xmm8, [rsp+0x70]
00007dd8c99d33d3  vmovaps xmm9, [rsp+0x80]
00007dd8c99d33dc  vmovaps xmm10, [rsp+0x90]
00007dd8c99d33e5  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d33ee  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d33f7  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d3400  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d3409  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d3412  add rsp, 0xF0
00007dd8c99d3419  pop r11
00007dd8c99d341b  pop r10
00007dd8c99d341d  pop r9
00007dd8c99d341f  pop r8
00007dd8c99d3421  pop rsi
00007dd8c99d3422  pop rdi
00007dd8c99d3423  pop rdx
00007dd8c99d3424  pop rcx
00007dd8c99d3425  pop rax
00007dd8c99d3426  add rsp, 0x08
00007dd8c99d342a  jmp 0x00007DD8C99CFED1
00007dd8c99d342f  sub rsp, 0x08
00007dd8c99d3433  push rax
00007dd8c99d3434  push rcx
00007dd8c99d3435  push rdx
00007dd8c99d3436  push rdi
00007dd8c99d3437  push rsi
00007dd8c99d3438  push r8
00007dd8c99d343a  push r9
00007dd8c99d343c  push r10
00007dd8c99d343e  push r11
00007dd8c99d3440  sub rsp, 0xF0
00007dd8c99d3447  vmovaps [rsp], xmm0
00007dd8c99d344c  vmovaps [rsp+0x10], xmm1
00007dd8c99d3452  vmovaps [rsp+0x20], xmm2
00007dd8c99d3458  vmovaps [rsp+0x30], xmm3
00007dd8c99d345e  vmovaps [rsp+0x40], xmm4
00007dd8c99d3464  vmovaps [rsp+0x50], xmm5
00007dd8c99d346a  vmovaps [rsp+0x60], xmm6
00007dd8c99d3470  vmovaps [rsp+0x70], xmm7
00007dd8c99d3476  vmovaps [rsp+0x80], xmm8
00007dd8c99d347f  vmovaps [rsp+0x90], xmm9
00007dd8c99d3488  vmovaps [rsp+0xA0], xmm10
00007dd8c99d3491  vmovaps [rsp+0xB0], xmm11
00007dd8c99d349a  vmovaps [rsp+0xC0], xmm12
00007dd8c99d34a3  vmovaps [rsp+0xD0], xmm13
00007dd8c99d34ac  vmovaps [rsp+0xE0], xmm15
00007dd8c99d34b5  sub rsp, 0x30
00007dd8c99d34b9  movaps [rsp], xmm14
00007dd8c99d34be  movaps [rsp+0x10], xmm12
00007dd8c99d34c4  movaps [rsp+0x20], xmm5
00007dd8c99d34c9  lea rdi, [rsp]
00007dd8c99d34cd  mov esi, 0x00
00007dd8c99d34d2  mov rax, 0x55FEBBDB5530
00007dd8c99d34dc  call rax
00007dd8c99d34de  movaps xmm14, [rsp]
00007dd8c99d34e3  add rsp, 0x30
00007dd8c99d34e7  vmovaps xmm0, [rsp]
00007dd8c99d34ec  vmovaps xmm1, [rsp+0x10]
00007dd8c99d34f2  vmovaps xmm2, [rsp+0x20]
00007dd8c99d34f8  vmovaps xmm3, [rsp+0x30]
00007dd8c99d34fe  vmovaps xmm4, [rsp+0x40]
00007dd8c99d3504  vmovaps xmm5, [rsp+0x50]
00007dd8c99d350a  vmovaps xmm6, [rsp+0x60]
00007dd8c99d3510  vmovaps xmm7, [rsp+0x70]
00007dd8c99d3516  vmovaps xmm8, [rsp+0x80]
00007dd8c99d351f  vmovaps xmm9, [rsp+0x90]
00007dd8c99d3528  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d3531  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d353a  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d3543  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d354c  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d3555  add rsp, 0xF0
00007dd8c99d355c  pop r11
00007dd8c99d355e  pop r10
00007dd8c99d3560  pop r9
00007dd8c99d3562  pop r8
00007dd8c99d3564  pop rsi
00007dd8c99d3565  pop rdi
00007dd8c99d3566  pop rdx
00007dd8c99d3567  pop rcx
00007dd8c99d3568  pop rax
00007dd8c99d3569  add rsp, 0x08
00007dd8c99d356d  jmp 0x00007DD8C99CFEF1
00007dd8c99d3572  sub rsp, 0x08
00007dd8c99d3576  push rax
00007dd8c99d3577  push rcx
00007dd8c99d3578  push rdx
00007dd8c99d3579  push rdi
00007dd8c99d357a  push rsi
00007dd8c99d357b  push r8
00007dd8c99d357d  push r9
00007dd8c99d357f  push r10
00007dd8c99d3581  push r11
00007dd8c99d3583  sub rsp, 0xF0
00007dd8c99d358a  vmovaps [rsp], xmm0
00007dd8c99d358f  vmovaps [rsp+0x10], xmm1
00007dd8c99d3595  vmovaps [rsp+0x20], xmm2
00007dd8c99d359b  vmovaps [rsp+0x30], xmm3
00007dd8c99d35a1  vmovaps [rsp+0x40], xmm4
00007dd8c99d35a7  vmovaps [rsp+0x50], xmm5
00007dd8c99d35ad  vmovaps [rsp+0x60], xmm7
00007dd8c99d35b3  vmovaps [rsp+0x70], xmm8
00007dd8c99d35b9  vmovaps [rsp+0x80], xmm9
00007dd8c99d35c2  vmovaps [rsp+0x90], xmm10
00007dd8c99d35cb  vmovaps [rsp+0xA0], xmm11
00007dd8c99d35d4  vmovaps [rsp+0xB0], xmm12
00007dd8c99d35dd  vmovaps [rsp+0xC0], xmm13
00007dd8c99d35e6  vmovaps [rsp+0xD0], xmm14
00007dd8c99d35ef  vmovaps [rsp+0xE0], xmm15
00007dd8c99d35f8  sub rsp, 0x30
00007dd8c99d35fc  movaps [rsp], xmm6
00007dd8c99d3600  movaps [rsp+0x10], xmm9
00007dd8c99d3606  movaps [rsp+0x20], xmm12
00007dd8c99d360c  lea rdi, [rsp]
00007dd8c99d3610  mov esi, 0x00
00007dd8c99d3615  mov rax, 0x55FEBBDB5530
00007dd8c99d361f  call rax
00007dd8c99d3621  movaps xmm6, [rsp]
00007dd8c99d3625  add rsp, 0x30
00007dd8c99d3629  vmovaps xmm0, [rsp]
00007dd8c99d362e  vmovaps xmm1, [rsp+0x10]
00007dd8c99d3634  vmovaps xmm2, [rsp+0x20]
00007dd8c99d363a  vmovaps xmm3, [rsp+0x30]
00007dd8c99d3640  vmovaps xmm4, [rsp+0x40]
00007dd8c99d3646  vmovaps xmm5, [rsp+0x50]
00007dd8c99d364c  vmovaps xmm7, [rsp+0x60]
00007dd8c99d3652  vmovaps xmm8, [rsp+0x70]
00007dd8c99d3658  vmovaps xmm9, [rsp+0x80]
00007dd8c99d3661  vmovaps xmm10, [rsp+0x90]
00007dd8c99d366a  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d3673  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d367c  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d3685  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d368e  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d3697  add rsp, 0xF0
00007dd8c99d369e  pop r11
00007dd8c99d36a0  pop r10
00007dd8c99d36a2  pop r9
00007dd8c99d36a4  pop r8
00007dd8c99d36a6  pop rsi
00007dd8c99d36a7  pop rdi
00007dd8c99d36a8  pop rdx
00007dd8c99d36a9  pop rcx
00007dd8c99d36aa  pop rax
00007dd8c99d36ab  add rsp, 0x08
00007dd8c99d36af  jmp 0x00007DD8C99CFF19
00007dd8c99d36b4  sub rsp, 0x08
00007dd8c99d36b8  push rax
00007dd8c99d36b9  push rcx
00007dd8c99d36ba  push rdx
00007dd8c99d36bb  push rdi
00007dd8c99d36bc  push rsi
00007dd8c99d36bd  push r8
00007dd8c99d36bf  push r9
00007dd8c99d36c1  push r10
00007dd8c99d36c3  push r11
00007dd8c99d36c5  sub rsp, 0xF0
00007dd8c99d36cc  vmovaps [rsp], xmm0
00007dd8c99d36d1  vmovaps [rsp+0x10], xmm1
00007dd8c99d36d7  vmovaps [rsp+0x20], xmm2
00007dd8c99d36dd  vmovaps [rsp+0x30], xmm3
00007dd8c99d36e3  vmovaps [rsp+0x40], xmm4
00007dd8c99d36e9  vmovaps [rsp+0x50], xmm5
00007dd8c99d36ef  vmovaps [rsp+0x60], xmm6
00007dd8c99d36f5  vmovaps [rsp+0x70], xmm7
00007dd8c99d36fb  vmovaps [rsp+0x80], xmm8
00007dd8c99d3704  vmovaps [rsp+0x90], xmm9
00007dd8c99d370d  vmovaps [rsp+0xA0], xmm10
00007dd8c99d3716  vmovaps [rsp+0xB0], xmm11
00007dd8c99d371f  vmovaps [rsp+0xC0], xmm13
00007dd8c99d3728  vmovaps [rsp+0xD0], xmm14
00007dd8c99d3731  vmovaps [rsp+0xE0], xmm15
00007dd8c99d373a  sub rsp, 0x30
00007dd8c99d373e  movaps [rsp], xmm12
00007dd8c99d3743  movaps [rsp+0x10], xmm15
00007dd8c99d3749  movaps [rsp+0x20], xmm13
00007dd8c99d374f  lea rdi, [rsp]
00007dd8c99d3753  mov esi, 0x00
00007dd8c99d3758  mov rax, 0x55FEBBDB5530
00007dd8c99d3762  call rax
00007dd8c99d3764  movaps xmm12, [rsp]
00007dd8c99d3769  add rsp, 0x30
00007dd8c99d376d  vmovaps xmm0, [rsp]
00007dd8c99d3772  vmovaps xmm1, [rsp+0x10]
00007dd8c99d3778  vmovaps xmm2, [rsp+0x20]
00007dd8c99d377e  vmovaps xmm3, [rsp+0x30]
00007dd8c99d3784  vmovaps xmm4, [rsp+0x40]
00007dd8c99d378a  vmovaps xmm5, [rsp+0x50]
00007dd8c99d3790  vmovaps xmm6, [rsp+0x60]
00007dd8c99d3796  vmovaps xmm7, [rsp+0x70]
00007dd8c99d379c  vmovaps xmm8, [rsp+0x80]
00007dd8c99d37a5  vmovaps xmm9, [rsp+0x90]
00007dd8c99d37ae  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d37b7  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d37c0  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d37c9  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d37d2  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d37db  add rsp, 0xF0
00007dd8c99d37e2  pop r11
00007dd8c99d37e4  pop r10
00007dd8c99d37e6  pop r9
00007dd8c99d37e8  pop r8
00007dd8c99d37ea  pop rsi
00007dd8c99d37eb  pop rdi
00007dd8c99d37ec  pop rdx
00007dd8c99d37ed  pop rcx
00007dd8c99d37ee  pop rax
00007dd8c99d37ef  add rsp, 0x08
00007dd8c99d37f3  jmp 0x00007DD8C99CFF34
00007dd8c99d37f8  sub rsp, 0x08
00007dd8c99d37fc  push rax
00007dd8c99d37fd  push rcx
00007dd8c99d37fe  push rdx
00007dd8c99d37ff  push rdi
00007dd8c99d3800  push rsi
00007dd8c99d3801  push r8
00007dd8c99d3803  push r9
00007dd8c99d3805  push r10
00007dd8c99d3807  push r11
00007dd8c99d3809  sub rsp, 0xF0
00007dd8c99d3810  vmovaps [rsp], xmm0
00007dd8c99d3815  vmovaps [rsp+0x10], xmm1
00007dd8c99d381b  vmovaps [rsp+0x20], xmm2
00007dd8c99d3821  vmovaps [rsp+0x30], xmm3
00007dd8c99d3827  vmovaps [rsp+0x40], xmm4
00007dd8c99d382d  vmovaps [rsp+0x50], xmm5
00007dd8c99d3833  vmovaps [rsp+0x60], xmm6
00007dd8c99d3839  vmovaps [rsp+0x70], xmm7
00007dd8c99d383f  vmovaps [rsp+0x80], xmm8
00007dd8c99d3848  vmovaps [rsp+0x90], xmm9
00007dd8c99d3851  vmovaps [rsp+0xA0], xmm10
00007dd8c99d385a  vmovaps [rsp+0xB0], xmm11
00007dd8c99d3863  vmovaps [rsp+0xC0], xmm12
00007dd8c99d386c  vmovaps [rsp+0xD0], xmm13
00007dd8c99d3875  vmovaps [rsp+0xE0], xmm14
00007dd8c99d387e  sub rsp, 0x30
00007dd8c99d3882  movaps [rsp], xmm15
00007dd8c99d3887  movaps [rsp+0x10], xmm13
00007dd8c99d388d  movaps [rsp+0x20], xmm10
00007dd8c99d3893  lea rdi, [rsp]
00007dd8c99d3897  mov esi, 0x00
00007dd8c99d389c  mov rax, 0x55FEBBDB5530
00007dd8c99d38a6  call rax
00007dd8c99d38a8  movaps xmm15, [rsp]
00007dd8c99d38ad  add rsp, 0x30
00007dd8c99d38b1  vmovaps xmm0, [rsp]
00007dd8c99d38b6  vmovaps xmm1, [rsp+0x10]
00007dd8c99d38bc  vmovaps xmm2, [rsp+0x20]
00007dd8c99d38c2  vmovaps xmm3, [rsp+0x30]
00007dd8c99d38c8  vmovaps xmm4, [rsp+0x40]
00007dd8c99d38ce  vmovaps xmm5, [rsp+0x50]
00007dd8c99d38d4  vmovaps xmm6, [rsp+0x60]
00007dd8c99d38da  vmovaps xmm7, [rsp+0x70]
00007dd8c99d38e0  vmovaps xmm8, [rsp+0x80]
00007dd8c99d38e9  vmovaps xmm9, [rsp+0x90]
00007dd8c99d38f2  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d38fb  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d3904  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d390d  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d3916  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d391f  add rsp, 0xF0
00007dd8c99d3926  pop r11
00007dd8c99d3928  pop r10
00007dd8c99d392a  pop r9
00007dd8c99d392c  pop r8
00007dd8c99d392e  pop rsi
00007dd8c99d392f  pop rdi
00007dd8c99d3930  pop rdx
00007dd8c99d3931  pop rcx
00007dd8c99d3932  pop rax
00007dd8c99d3933  add rsp, 0x08
00007dd8c99d3937  jmp 0x00007DD8C99CFF55
00007dd8c99d393c  call 0x00007DD8C980C260
00007dd8c99d3941  jmp 0x00007DD8C99CFFB0
00007dd8c99d3946  sub rsp, 0x08
00007dd8c99d394a  push rax
00007dd8c99d394b  push rcx
00007dd8c99d394c  push rdx
00007dd8c99d394d  push rdi
00007dd8c99d394e  push rsi
00007dd8c99d394f  push r8
00007dd8c99d3951  push r9
00007dd8c99d3953  push r10
00007dd8c99d3955  push r11
00007dd8c99d3957  sub rsp, 0xF0
00007dd8c99d395e  vmovaps [rsp], xmm0
00007dd8c99d3963  vmovaps [rsp+0x10], xmm1
00007dd8c99d3969  vmovaps [rsp+0x20], xmm2
00007dd8c99d396f  vmovaps [rsp+0x30], xmm3
00007dd8c99d3975  vmovaps [rsp+0x40], xmm4
00007dd8c99d397b  vmovaps [rsp+0x50], xmm5
00007dd8c99d3981  vmovaps [rsp+0x60], xmm6
00007dd8c99d3987  vmovaps [rsp+0x70], xmm7
00007dd8c99d398d  vmovaps [rsp+0x80], xmm8
00007dd8c99d3996  vmovaps [rsp+0x90], xmm10
00007dd8c99d399f  vmovaps [rsp+0xA0], xmm11
00007dd8c99d39a8  vmovaps [rsp+0xB0], xmm12
00007dd8c99d39b1  vmovaps [rsp+0xC0], xmm13
00007dd8c99d39ba  vmovaps [rsp+0xD0], xmm14
00007dd8c99d39c3  vmovaps [rsp+0xE0], xmm15
00007dd8c99d39cc  sub rsp, 0x30
00007dd8c99d39d0  movaps [rsp], xmm9
00007dd8c99d39d5  movaps [rsp+0x10], xmm8
00007dd8c99d39db  movaps [rsp+0x20], xmm10
00007dd8c99d39e1  lea rdi, [rsp]
00007dd8c99d39e5  mov esi, 0x00
00007dd8c99d39ea  mov rax, 0x55FEBBDB5530
00007dd8c99d39f4  call rax
00007dd8c99d39f6  movaps xmm9, [rsp]
00007dd8c99d39fb  add rsp, 0x30
00007dd8c99d39ff  vmovaps xmm0, [rsp]
00007dd8c99d3a04  vmovaps xmm1, [rsp+0x10]
00007dd8c99d3a0a  vmovaps xmm2, [rsp+0x20]
00007dd8c99d3a10  vmovaps xmm3, [rsp+0x30]
00007dd8c99d3a16  vmovaps xmm4, [rsp+0x40]
00007dd8c99d3a1c  vmovaps xmm5, [rsp+0x50]
00007dd8c99d3a22  vmovaps xmm6, [rsp+0x60]
00007dd8c99d3a28  vmovaps xmm7, [rsp+0x70]
00007dd8c99d3a2e  vmovaps xmm8, [rsp+0x80]
00007dd8c99d3a37  vmovaps xmm10, [rsp+0x90]
00007dd8c99d3a40  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d3a49  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d3a52  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d3a5b  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d3a64  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d3a6d  add rsp, 0xF0
00007dd8c99d3a74  pop r11
00007dd8c99d3a76  pop r10
00007dd8c99d3a78  pop r9
00007dd8c99d3a7a  pop r8
00007dd8c99d3a7c  pop rsi
00007dd8c99d3a7d  pop rdi
00007dd8c99d3a7e  pop rdx
00007dd8c99d3a7f  pop rcx
00007dd8c99d3a80  pop rax
00007dd8c99d3a81  add rsp, 0x08
00007dd8c99d3a85  jmp 0x00007DD8C99CFFE1
00007dd8c99d3a8a  sub rsp, 0x08
00007dd8c99d3a8e  push rax
00007dd8c99d3a8f  push rcx
00007dd8c99d3a90  push rdx
00007dd8c99d3a91  push rdi
00007dd8c99d3a92  push rsi
00007dd8c99d3a93  push r8
00007dd8c99d3a95  push r9
00007dd8c99d3a97  push r10
00007dd8c99d3a99  push r11
00007dd8c99d3a9b  sub rsp, 0xF0
00007dd8c99d3aa2  vmovaps [rsp], xmm0
00007dd8c99d3aa7  vmovaps [rsp+0x10], xmm1
00007dd8c99d3aad  vmovaps [rsp+0x20], xmm2
00007dd8c99d3ab3  vmovaps [rsp+0x30], xmm3
00007dd8c99d3ab9  vmovaps [rsp+0x40], xmm4
00007dd8c99d3abf  vmovaps [rsp+0x50], xmm5
00007dd8c99d3ac5  vmovaps [rsp+0x60], xmm6
00007dd8c99d3acb  vmovaps [rsp+0x70], xmm7
00007dd8c99d3ad1  vmovaps [rsp+0x80], xmm8
00007dd8c99d3ada  vmovaps [rsp+0x90], xmm9
00007dd8c99d3ae3  vmovaps [rsp+0xA0], xmm11
00007dd8c99d3aec  vmovaps [rsp+0xB0], xmm12
00007dd8c99d3af5  vmovaps [rsp+0xC0], xmm13
00007dd8c99d3afe  vmovaps [rsp+0xD0], xmm14
00007dd8c99d3b07  vmovaps [rsp+0xE0], xmm15
00007dd8c99d3b10  sub rsp, 0x30
00007dd8c99d3b14  movaps [rsp], xmm10
00007dd8c99d3b19  movaps [rsp+0x10], xmm1
00007dd8c99d3b1e  movaps [rsp+0x20], xmm11
00007dd8c99d3b24  lea rdi, [rsp]
00007dd8c99d3b28  mov esi, 0x00
00007dd8c99d3b2d  mov rax, 0x55FEBBDB5530
00007dd8c99d3b37  call rax
00007dd8c99d3b39  movaps xmm10, [rsp]
00007dd8c99d3b3e  add rsp, 0x30
00007dd8c99d3b42  vmovaps xmm0, [rsp]
00007dd8c99d3b47  vmovaps xmm1, [rsp+0x10]
00007dd8c99d3b4d  vmovaps xmm2, [rsp+0x20]
00007dd8c99d3b53  vmovaps xmm3, [rsp+0x30]
00007dd8c99d3b59  vmovaps xmm4, [rsp+0x40]
00007dd8c99d3b5f  vmovaps xmm5, [rsp+0x50]
00007dd8c99d3b65  vmovaps xmm6, [rsp+0x60]
00007dd8c99d3b6b  vmovaps xmm7, [rsp+0x70]
00007dd8c99d3b71  vmovaps xmm8, [rsp+0x80]
00007dd8c99d3b7a  vmovaps xmm9, [rsp+0x90]
00007dd8c99d3b83  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d3b8c  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d3b95  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d3b9e  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d3ba7  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d3bb0  add rsp, 0xF0
00007dd8c99d3bb7  pop r11
00007dd8c99d3bb9  pop r10
00007dd8c99d3bbb  pop r9
00007dd8c99d3bbd  pop r8
00007dd8c99d3bbf  pop rsi
00007dd8c99d3bc0  pop rdi
00007dd8c99d3bc1  pop rdx
00007dd8c99d3bc2  pop rcx
00007dd8c99d3bc3  pop rax
00007dd8c99d3bc4  add rsp, 0x08
00007dd8c99d3bc8  jmp 0x00007DD8C99CFFFC
00007dd8c99d3bcd  sub rsp, 0x08
00007dd8c99d3bd1  push rax
00007dd8c99d3bd2  push rcx
00007dd8c99d3bd3  push rdx
00007dd8c99d3bd4  push rdi
00007dd8c99d3bd5  push rsi
00007dd8c99d3bd6  push r8
00007dd8c99d3bd8  push r9
00007dd8c99d3bda  push r10
00007dd8c99d3bdc  push r11
00007dd8c99d3bde  sub rsp, 0xF0
00007dd8c99d3be5  vmovaps [rsp], xmm0
00007dd8c99d3bea  vmovaps [rsp+0x10], xmm2
00007dd8c99d3bf0  vmovaps [rsp+0x20], xmm3
00007dd8c99d3bf6  vmovaps [rsp+0x30], xmm4
00007dd8c99d3bfc  vmovaps [rsp+0x40], xmm5
00007dd8c99d3c02  vmovaps [rsp+0x50], xmm6
00007dd8c99d3c08  vmovaps [rsp+0x60], xmm7
00007dd8c99d3c0e  vmovaps [rsp+0x70], xmm8
00007dd8c99d3c14  vmovaps [rsp+0x80], xmm9
00007dd8c99d3c1d  vmovaps [rsp+0x90], xmm10
00007dd8c99d3c26  vmovaps [rsp+0xA0], xmm11
00007dd8c99d3c2f  vmovaps [rsp+0xB0], xmm12
00007dd8c99d3c38  vmovaps [rsp+0xC0], xmm13
00007dd8c99d3c41  vmovaps [rsp+0xD0], xmm14
00007dd8c99d3c4a  vmovaps [rsp+0xE0], xmm15
00007dd8c99d3c53  sub rsp, 0x30
00007dd8c99d3c57  movaps [rsp], xmm1
00007dd8c99d3c5b  movaps [rsp+0x10], xmm14
00007dd8c99d3c61  movaps [rsp+0x20], xmm6
00007dd8c99d3c66  lea rdi, [rsp]
00007dd8c99d3c6a  mov esi, 0x00
00007dd8c99d3c6f  mov rax, 0x55FEBBDB5530
00007dd8c99d3c79  call rax
00007dd8c99d3c7b  movaps xmm1, [rsp]
00007dd8c99d3c7f  add rsp, 0x30
00007dd8c99d3c83  vmovaps xmm0, [rsp]
00007dd8c99d3c88  vmovaps xmm2, [rsp+0x10]
00007dd8c99d3c8e  vmovaps xmm3, [rsp+0x20]
00007dd8c99d3c94  vmovaps xmm4, [rsp+0x30]
00007dd8c99d3c9a  vmovaps xmm5, [rsp+0x40]
00007dd8c99d3ca0  vmovaps xmm6, [rsp+0x50]
00007dd8c99d3ca6  vmovaps xmm7, [rsp+0x60]
00007dd8c99d3cac  vmovaps xmm8, [rsp+0x70]
00007dd8c99d3cb2  vmovaps xmm9, [rsp+0x80]
00007dd8c99d3cbb  vmovaps xmm10, [rsp+0x90]
00007dd8c99d3cc4  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d3ccd  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d3cd6  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d3cdf  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d3ce8  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d3cf1  add rsp, 0xF0
00007dd8c99d3cf8  pop r11
00007dd8c99d3cfa  pop r10
00007dd8c99d3cfc  pop r9
00007dd8c99d3cfe  pop r8
00007dd8c99d3d00  pop rsi
00007dd8c99d3d01  pop rdi
00007dd8c99d3d02  pop rdx
00007dd8c99d3d03  pop rcx
00007dd8c99d3d04  pop rax
00007dd8c99d3d05  add rsp, 0x08
00007dd8c99d3d09  jmp 0x00007DD8C99D0015
00007dd8c99d3d0e  sub rsp, 0x08
00007dd8c99d3d12  push rax
00007dd8c99d3d13  push rcx
00007dd8c99d3d14  push rdx
00007dd8c99d3d15  push rdi
00007dd8c99d3d16  push rsi
00007dd8c99d3d17  push r8
00007dd8c99d3d19  push r9
00007dd8c99d3d1b  push r10
00007dd8c99d3d1d  push r11
00007dd8c99d3d1f  sub rsp, 0xF0
00007dd8c99d3d26  vmovaps [rsp], xmm0
00007dd8c99d3d2b  vmovaps [rsp+0x10], xmm1
00007dd8c99d3d31  vmovaps [rsp+0x20], xmm2
00007dd8c99d3d37  vmovaps [rsp+0x30], xmm3
00007dd8c99d3d3d  vmovaps [rsp+0x40], xmm4
00007dd8c99d3d43  vmovaps [rsp+0x50], xmm5
00007dd8c99d3d49  vmovaps [rsp+0x60], xmm6
00007dd8c99d3d4f  vmovaps [rsp+0x70], xmm7
00007dd8c99d3d55  vmovaps [rsp+0x80], xmm8
00007dd8c99d3d5e  vmovaps [rsp+0x90], xmm9
00007dd8c99d3d67  vmovaps [rsp+0xA0], xmm10
00007dd8c99d3d70  vmovaps [rsp+0xB0], xmm12
00007dd8c99d3d79  vmovaps [rsp+0xC0], xmm13
00007dd8c99d3d82  vmovaps [rsp+0xD0], xmm14
00007dd8c99d3d8b  vmovaps [rsp+0xE0], xmm15
00007dd8c99d3d94  sub rsp, 0x30
00007dd8c99d3d98  movaps [rsp], xmm11
00007dd8c99d3d9d  movaps [rsp+0x10], xmm13
00007dd8c99d3da3  movaps [rsp+0x20], xmm14
00007dd8c99d3da9  lea rdi, [rsp]
00007dd8c99d3dad  mov esi, 0x00
00007dd8c99d3db2  mov rax, 0x55FEBBDB5530
00007dd8c99d3dbc  call rax
00007dd8c99d3dbe  movaps xmm11, [rsp]
00007dd8c99d3dc3  add rsp, 0x30
00007dd8c99d3dc7  vmovaps xmm0, [rsp]
00007dd8c99d3dcc  vmovaps xmm1, [rsp+0x10]
00007dd8c99d3dd2  vmovaps xmm2, [rsp+0x20]
00007dd8c99d3dd8  vmovaps xmm3, [rsp+0x30]
00007dd8c99d3dde  vmovaps xmm4, [rsp+0x40]
00007dd8c99d3de4  vmovaps xmm5, [rsp+0x50]
00007dd8c99d3dea  vmovaps xmm6, [rsp+0x60]
00007dd8c99d3df0  vmovaps xmm7, [rsp+0x70]
00007dd8c99d3df6  vmovaps xmm8, [rsp+0x80]
00007dd8c99d3dff  vmovaps xmm9, [rsp+0x90]
00007dd8c99d3e08  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d3e11  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d3e1a  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d3e23  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d3e2c  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d3e35  add rsp, 0xF0
00007dd8c99d3e3c  pop r11
00007dd8c99d3e3e  pop r10
00007dd8c99d3e40  pop r9
00007dd8c99d3e42  pop r8
00007dd8c99d3e44  pop rsi
00007dd8c99d3e45  pop rdi
00007dd8c99d3e46  pop rdx
00007dd8c99d3e47  pop rcx
00007dd8c99d3e48  pop rax
00007dd8c99d3e49  add rsp, 0x08
00007dd8c99d3e4d  jmp 0x00007DD8C99D003F
00007dd8c99d3e52  sub rsp, 0x08
00007dd8c99d3e56  push rax
00007dd8c99d3e57  push rcx
00007dd8c99d3e58  push rdx
00007dd8c99d3e59  push rdi
00007dd8c99d3e5a  push rsi
00007dd8c99d3e5b  push r8
00007dd8c99d3e5d  push r9
00007dd8c99d3e5f  push r10
00007dd8c99d3e61  push r11
00007dd8c99d3e63  sub rsp, 0xF0
00007dd8c99d3e6a  vmovaps [rsp], xmm0
00007dd8c99d3e6f  vmovaps [rsp+0x10], xmm1
00007dd8c99d3e75  vmovaps [rsp+0x20], xmm2
00007dd8c99d3e7b  vmovaps [rsp+0x30], xmm3
00007dd8c99d3e81  vmovaps [rsp+0x40], xmm4
00007dd8c99d3e87  vmovaps [rsp+0x50], xmm5
00007dd8c99d3e8d  vmovaps [rsp+0x60], xmm6
00007dd8c99d3e93  vmovaps [rsp+0x70], xmm7
00007dd8c99d3e99  vmovaps [rsp+0x80], xmm8
00007dd8c99d3ea2  vmovaps [rsp+0x90], xmm9
00007dd8c99d3eab  vmovaps [rsp+0xA0], xmm10
00007dd8c99d3eb4  vmovaps [rsp+0xB0], xmm11
00007dd8c99d3ebd  vmovaps [rsp+0xC0], xmm12
00007dd8c99d3ec6  vmovaps [rsp+0xD0], xmm14
00007dd8c99d3ecf  vmovaps [rsp+0xE0], xmm15
00007dd8c99d3ed8  sub rsp, 0x30
00007dd8c99d3edc  movaps [rsp], xmm13
00007dd8c99d3ee1  movaps [rsp+0x10], xmm8
00007dd8c99d3ee7  movaps [rsp+0x20], xmm14
00007dd8c99d3eed  lea rdi, [rsp]
00007dd8c99d3ef1  mov esi, 0x00
00007dd8c99d3ef6  mov rax, 0x55FEBBDB5530
00007dd8c99d3f00  call rax
00007dd8c99d3f02  movaps xmm13, [rsp]
00007dd8c99d3f07  add rsp, 0x30
00007dd8c99d3f0b  vmovaps xmm0, [rsp]
00007dd8c99d3f10  vmovaps xmm1, [rsp+0x10]
00007dd8c99d3f16  vmovaps xmm2, [rsp+0x20]
00007dd8c99d3f1c  vmovaps xmm3, [rsp+0x30]
00007dd8c99d3f22  vmovaps xmm4, [rsp+0x40]
00007dd8c99d3f28  vmovaps xmm5, [rsp+0x50]
00007dd8c99d3f2e  vmovaps xmm6, [rsp+0x60]
00007dd8c99d3f34  vmovaps xmm7, [rsp+0x70]
00007dd8c99d3f3a  vmovaps xmm8, [rsp+0x80]
00007dd8c99d3f43  vmovaps xmm9, [rsp+0x90]
00007dd8c99d3f4c  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d3f55  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d3f5e  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d3f67  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d3f70  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d3f79  add rsp, 0xF0
00007dd8c99d3f80  pop r11
00007dd8c99d3f82  pop r10
00007dd8c99d3f84  pop r9
00007dd8c99d3f86  pop r8
00007dd8c99d3f88  pop rsi
00007dd8c99d3f89  pop rdi
00007dd8c99d3f8a  pop rdx
00007dd8c99d3f8b  pop rcx
00007dd8c99d3f8c  pop rax
00007dd8c99d3f8d  add rsp, 0x08
00007dd8c99d3f91  jmp 0x00007DD8C99D006E
00007dd8c99d3f96  sub rsp, 0x08
00007dd8c99d3f9a  push rax
00007dd8c99d3f9b  push rcx
00007dd8c99d3f9c  push rdx
00007dd8c99d3f9d  push rdi
00007dd8c99d3f9e  push rsi
00007dd8c99d3f9f  push r8
00007dd8c99d3fa1  push r9
00007dd8c99d3fa3  push r10
00007dd8c99d3fa5  push r11
00007dd8c99d3fa7  sub rsp, 0xF0
00007dd8c99d3fae  vmovaps [rsp], xmm0
00007dd8c99d3fb3  vmovaps [rsp+0x10], xmm1
00007dd8c99d3fb9  vmovaps [rsp+0x20], xmm2
00007dd8c99d3fbf  vmovaps [rsp+0x30], xmm3
00007dd8c99d3fc5  vmovaps [rsp+0x40], xmm4
00007dd8c99d3fcb  vmovaps [rsp+0x50], xmm5
00007dd8c99d3fd1  vmovaps [rsp+0x60], xmm6
00007dd8c99d3fd7  vmovaps [rsp+0x70], xmm7
00007dd8c99d3fdd  vmovaps [rsp+0x80], xmm9
00007dd8c99d3fe6  vmovaps [rsp+0x90], xmm10
00007dd8c99d3fef  vmovaps [rsp+0xA0], xmm11
00007dd8c99d3ff8  vmovaps [rsp+0xB0], xmm12
00007dd8c99d4001  vmovaps [rsp+0xC0], xmm13
00007dd8c99d400a  vmovaps [rsp+0xD0], xmm14
00007dd8c99d4013  vmovaps [rsp+0xE0], xmm15
00007dd8c99d401c  sub rsp, 0x30
00007dd8c99d4020  movaps [rsp], xmm8
00007dd8c99d4025  movaps [rsp+0x10], xmm7
00007dd8c99d402a  movaps [rsp+0x20], xmm14
00007dd8c99d4030  lea rdi, [rsp]
00007dd8c99d4034  mov esi, 0x00
00007dd8c99d4039  mov rax, 0x55FEBBDB5530
00007dd8c99d4043  call rax
00007dd8c99d4045  movaps xmm8, [rsp]
00007dd8c99d404a  add rsp, 0x30
00007dd8c99d404e  vmovaps xmm0, [rsp]
00007dd8c99d4053  vmovaps xmm1, [rsp+0x10]
00007dd8c99d4059  vmovaps xmm2, [rsp+0x20]
00007dd8c99d405f  vmovaps xmm3, [rsp+0x30]
00007dd8c99d4065  vmovaps xmm4, [rsp+0x40]
00007dd8c99d406b  vmovaps xmm5, [rsp+0x50]
00007dd8c99d4071  vmovaps xmm6, [rsp+0x60]
00007dd8c99d4077  vmovaps xmm7, [rsp+0x70]
00007dd8c99d407d  vmovaps xmm9, [rsp+0x80]
00007dd8c99d4086  vmovaps xmm10, [rsp+0x90]
00007dd8c99d408f  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d4098  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d40a1  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d40aa  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d40b3  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d40bc  add rsp, 0xF0
00007dd8c99d40c3  pop r11
00007dd8c99d40c5  pop r10
00007dd8c99d40c7  pop r9
00007dd8c99d40c9  pop r8
00007dd8c99d40cb  pop rsi
00007dd8c99d40cc  pop rdi
00007dd8c99d40cd  pop rdx
00007dd8c99d40ce  pop rcx
00007dd8c99d40cf  pop rax
00007dd8c99d40d0  add rsp, 0x08
00007dd8c99d40d4  jmp 0x00007DD8C99D0094
00007dd8c99d40d9  sub rsp, 0x08
00007dd8c99d40dd  push rax
00007dd8c99d40de  push rcx
00007dd8c99d40df  push rdx
00007dd8c99d40e0  push rdi
00007dd8c99d40e1  push rsi
00007dd8c99d40e2  push r8
00007dd8c99d40e4  push r9
00007dd8c99d40e6  push r10
00007dd8c99d40e8  push r11
00007dd8c99d40ea  sub rsp, 0xF0
00007dd8c99d40f1  vmovaps [rsp], xmm0
00007dd8c99d40f6  vmovaps [rsp+0x10], xmm1
00007dd8c99d40fc  vmovaps [rsp+0x20], xmm2
00007dd8c99d4102  vmovaps [rsp+0x30], xmm3
00007dd8c99d4108  vmovaps [rsp+0x40], xmm4
00007dd8c99d410e  vmovaps [rsp+0x50], xmm5
00007dd8c99d4114  vmovaps [rsp+0x60], xmm6
00007dd8c99d411a  vmovaps [rsp+0x70], xmm7
00007dd8c99d4120  vmovaps [rsp+0x80], xmm8
00007dd8c99d4129  vmovaps [rsp+0x90], xmm9
00007dd8c99d4132  vmovaps [rsp+0xA0], xmm10
00007dd8c99d413b  vmovaps [rsp+0xB0], xmm11
00007dd8c99d4144  vmovaps [rsp+0xC0], xmm12
00007dd8c99d414d  vmovaps [rsp+0xD0], xmm13
00007dd8c99d4156  vmovaps [rsp+0xE0], xmm15
00007dd8c99d415f  sub rsp, 0x30
00007dd8c99d4163  movaps [rsp], xmm14
00007dd8c99d4168  movaps [rsp+0x10], xmm12
00007dd8c99d416e  movaps [rsp+0x20], xmm9
00007dd8c99d4174  lea rdi, [rsp]
00007dd8c99d4178  mov esi, 0x00
00007dd8c99d417d  mov rax, 0x55FEBBDB5530
00007dd8c99d4187  call rax
00007dd8c99d4189  movaps xmm14, [rsp]
00007dd8c99d418e  add rsp, 0x30
00007dd8c99d4192  vmovaps xmm0, [rsp]
00007dd8c99d4197  vmovaps xmm1, [rsp+0x10]
00007dd8c99d419d  vmovaps xmm2, [rsp+0x20]
00007dd8c99d41a3  vmovaps xmm3, [rsp+0x30]
00007dd8c99d41a9  vmovaps xmm4, [rsp+0x40]
00007dd8c99d41af  vmovaps xmm5, [rsp+0x50]
00007dd8c99d41b5  vmovaps xmm6, [rsp+0x60]
00007dd8c99d41bb  vmovaps xmm7, [rsp+0x70]
00007dd8c99d41c1  vmovaps xmm8, [rsp+0x80]
00007dd8c99d41ca  vmovaps xmm9, [rsp+0x90]
00007dd8c99d41d3  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d41dc  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d41e5  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d41ee  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d41f7  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d4200  add rsp, 0xF0
00007dd8c99d4207  pop r11
00007dd8c99d4209  pop r10
00007dd8c99d420b  pop r9
00007dd8c99d420d  pop r8
00007dd8c99d420f  pop rsi
00007dd8c99d4210  pop rdi
00007dd8c99d4211  pop rdx
00007dd8c99d4212  pop rcx
00007dd8c99d4213  pop rax
00007dd8c99d4214  add rsp, 0x08
00007dd8c99d4218  jmp 0x00007DD8C99D00AE
00007dd8c99d421d  sub rsp, 0x08
00007dd8c99d4221  push rax
00007dd8c99d4222  push rcx
00007dd8c99d4223  push rdx
00007dd8c99d4224  push rdi
00007dd8c99d4225  push rsi
00007dd8c99d4226  push r8
00007dd8c99d4228  push r9
00007dd8c99d422a  push r10
00007dd8c99d422c  push r11
00007dd8c99d422e  sub rsp, 0xF0
00007dd8c99d4235  vmovaps [rsp], xmm0
00007dd8c99d423a  vmovaps [rsp+0x10], xmm1
00007dd8c99d4240  vmovaps [rsp+0x20], xmm2
00007dd8c99d4246  vmovaps [rsp+0x30], xmm3
00007dd8c99d424c  vmovaps [rsp+0x40], xmm4
00007dd8c99d4252  vmovaps [rsp+0x50], xmm5
00007dd8c99d4258  vmovaps [rsp+0x60], xmm6
00007dd8c99d425e  vmovaps [rsp+0x70], xmm7
00007dd8c99d4264  vmovaps [rsp+0x80], xmm8
00007dd8c99d426d  vmovaps [rsp+0x90], xmm10
00007dd8c99d4276  vmovaps [rsp+0xA0], xmm11
00007dd8c99d427f  vmovaps [rsp+0xB0], xmm12
00007dd8c99d4288  vmovaps [rsp+0xC0], xmm13
00007dd8c99d4291  vmovaps [rsp+0xD0], xmm14
00007dd8c99d429a  vmovaps [rsp+0xE0], xmm15
00007dd8c99d42a3  sub rsp, 0x30
00007dd8c99d42a7  movaps [rsp], xmm9
00007dd8c99d42ac  movaps [rsp+0x10], xmm7
00007dd8c99d42b1  movaps [rsp+0x20], xmm12
00007dd8c99d42b7  lea rdi, [rsp]
00007dd8c99d42bb  mov esi, 0x00
00007dd8c99d42c0  mov rax, 0x55FEBBDB5530
00007dd8c99d42ca  call rax
00007dd8c99d42cc  movaps xmm9, [rsp]
00007dd8c99d42d1  add rsp, 0x30
00007dd8c99d42d5  vmovaps xmm0, [rsp]
00007dd8c99d42da  vmovaps xmm1, [rsp+0x10]
00007dd8c99d42e0  vmovaps xmm2, [rsp+0x20]
00007dd8c99d42e6  vmovaps xmm3, [rsp+0x30]
00007dd8c99d42ec  vmovaps xmm4, [rsp+0x40]
00007dd8c99d42f2  vmovaps xmm5, [rsp+0x50]
00007dd8c99d42f8  vmovaps xmm6, [rsp+0x60]
00007dd8c99d42fe  vmovaps xmm7, [rsp+0x70]
00007dd8c99d4304  vmovaps xmm8, [rsp+0x80]
00007dd8c99d430d  vmovaps xmm10, [rsp+0x90]
00007dd8c99d4316  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d431f  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d4328  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d4331  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d433a  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d4343  add rsp, 0xF0
00007dd8c99d434a  pop r11
00007dd8c99d434c  pop r10
00007dd8c99d434e  pop r9
00007dd8c99d4350  pop r8
00007dd8c99d4352  pop rsi
00007dd8c99d4353  pop rdi
00007dd8c99d4354  pop rdx
00007dd8c99d4355  pop rcx
00007dd8c99d4356  pop rax
00007dd8c99d4357  add rsp, 0x08
00007dd8c99d435b  jmp 0x00007DD8C99D00DD
00007dd8c99d4360  sub rsp, 0x08
00007dd8c99d4364  push rax
00007dd8c99d4365  push rcx
00007dd8c99d4366  push rdx
00007dd8c99d4367  push rdi
00007dd8c99d4368  push rsi
00007dd8c99d4369  push r8
00007dd8c99d436b  push r9
00007dd8c99d436d  push r10
00007dd8c99d436f  push r11
00007dd8c99d4371  sub rsp, 0xF0
00007dd8c99d4378  vmovaps [rsp], xmm0
00007dd8c99d437d  vmovaps [rsp+0x10], xmm1
00007dd8c99d4383  vmovaps [rsp+0x20], xmm2
00007dd8c99d4389  vmovaps [rsp+0x30], xmm3
00007dd8c99d438f  vmovaps [rsp+0x40], xmm4
00007dd8c99d4395  vmovaps [rsp+0x50], xmm5
00007dd8c99d439b  vmovaps [rsp+0x60], xmm6
00007dd8c99d43a1  vmovaps [rsp+0x70], xmm7
00007dd8c99d43a7  vmovaps [rsp+0x80], xmm8
00007dd8c99d43b0  vmovaps [rsp+0x90], xmm9
00007dd8c99d43b9  vmovaps [rsp+0xA0], xmm10
00007dd8c99d43c2  vmovaps [rsp+0xB0], xmm11
00007dd8c99d43cb  vmovaps [rsp+0xC0], xmm13
00007dd8c99d43d4  vmovaps [rsp+0xD0], xmm14
00007dd8c99d43dd  vmovaps [rsp+0xE0], xmm15
00007dd8c99d43e6  sub rsp, 0x30
00007dd8c99d43ea  movaps [rsp], xmm12
00007dd8c99d43ef  movaps [rsp+0x10], xmm15
00007dd8c99d43f5  movaps [rsp+0x20], xmm11
00007dd8c99d43fb  lea rdi, [rsp]
00007dd8c99d43ff  mov esi, 0x00
00007dd8c99d4404  mov rax, 0x55FEBBDB5530
00007dd8c99d440e  call rax
00007dd8c99d4410  movaps xmm12, [rsp]
00007dd8c99d4415  add rsp, 0x30
00007dd8c99d4419  vmovaps xmm0, [rsp]
00007dd8c99d441e  vmovaps xmm1, [rsp+0x10]
00007dd8c99d4424  vmovaps xmm2, [rsp+0x20]
00007dd8c99d442a  vmovaps xmm3, [rsp+0x30]
00007dd8c99d4430  vmovaps xmm4, [rsp+0x40]
00007dd8c99d4436  vmovaps xmm5, [rsp+0x50]
00007dd8c99d443c  vmovaps xmm6, [rsp+0x60]
00007dd8c99d4442  vmovaps xmm7, [rsp+0x70]
00007dd8c99d4448  vmovaps xmm8, [rsp+0x80]
00007dd8c99d4451  vmovaps xmm9, [rsp+0x90]
00007dd8c99d445a  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d4463  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d446c  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d4475  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d447e  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d4487  add rsp, 0xF0
00007dd8c99d448e  pop r11
00007dd8c99d4490  pop r10
00007dd8c99d4492  pop r9
00007dd8c99d4494  pop r8
00007dd8c99d4496  pop rsi
00007dd8c99d4497  pop rdi
00007dd8c99d4498  pop rdx
00007dd8c99d4499  pop rcx
00007dd8c99d449a  pop rax
00007dd8c99d449b  add rsp, 0x08
00007dd8c99d449f  jmp 0x00007DD8C99D00F7
00007dd8c99d44a4  sub rsp, 0x08
00007dd8c99d44a8  push rax
00007dd8c99d44a9  push rcx
00007dd8c99d44aa  push rdx
00007dd8c99d44ab  push rdi
00007dd8c99d44ac  push rsi
00007dd8c99d44ad  push r8
00007dd8c99d44af  push r9
00007dd8c99d44b1  push r10
00007dd8c99d44b3  push r11
00007dd8c99d44b5  sub rsp, 0xF0
00007dd8c99d44bc  vmovaps [rsp], xmm0
00007dd8c99d44c1  vmovaps [rsp+0x10], xmm1
00007dd8c99d44c7  vmovaps [rsp+0x20], xmm2
00007dd8c99d44cd  vmovaps [rsp+0x30], xmm3
00007dd8c99d44d3  vmovaps [rsp+0x40], xmm4
00007dd8c99d44d9  vmovaps [rsp+0x50], xmm5
00007dd8c99d44df  vmovaps [rsp+0x60], xmm6
00007dd8c99d44e5  vmovaps [rsp+0x70], xmm7
00007dd8c99d44eb  vmovaps [rsp+0x80], xmm8
00007dd8c99d44f4  vmovaps [rsp+0x90], xmm9
00007dd8c99d44fd  vmovaps [rsp+0xA0], xmm10
00007dd8c99d4506  vmovaps [rsp+0xB0], xmm12
00007dd8c99d450f  vmovaps [rsp+0xC0], xmm13
00007dd8c99d4518  vmovaps [rsp+0xD0], xmm14
00007dd8c99d4521  vmovaps [rsp+0xE0], xmm15
00007dd8c99d452a  sub rsp, 0x30
00007dd8c99d452e  movaps [rsp], xmm11
00007dd8c99d4533  movaps [rsp+0x10], xmm7
00007dd8c99d4538  movaps [rsp+0x20], xmm15
00007dd8c99d453e  lea rdi, [rsp]
00007dd8c99d4542  mov esi, 0x00
00007dd8c99d4547  mov rax, 0x55FEBBDB5530
00007dd8c99d4551  call rax
00007dd8c99d4553  movaps xmm11, [rsp]
00007dd8c99d4558  add rsp, 0x30
00007dd8c99d455c  vmovaps xmm0, [rsp]
00007dd8c99d4561  vmovaps xmm1, [rsp+0x10]
00007dd8c99d4567  vmovaps xmm2, [rsp+0x20]
00007dd8c99d456d  vmovaps xmm3, [rsp+0x30]
00007dd8c99d4573  vmovaps xmm4, [rsp+0x40]
00007dd8c99d4579  vmovaps xmm5, [rsp+0x50]
00007dd8c99d457f  vmovaps xmm6, [rsp+0x60]
00007dd8c99d4585  vmovaps xmm7, [rsp+0x70]
00007dd8c99d458b  vmovaps xmm8, [rsp+0x80]
00007dd8c99d4594  vmovaps xmm9, [rsp+0x90]
00007dd8c99d459d  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d45a6  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d45af  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d45b8  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d45c1  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d45ca  add rsp, 0xF0
00007dd8c99d45d1  pop r11
00007dd8c99d45d3  pop r10
00007dd8c99d45d5  pop r9
00007dd8c99d45d7  pop r8
00007dd8c99d45d9  pop rsi
00007dd8c99d45da  pop rdi
00007dd8c99d45db  pop rdx
00007dd8c99d45dc  pop rcx
00007dd8c99d45dd  pop rax
00007dd8c99d45de  add rsp, 0x08
00007dd8c99d45e2  jmp 0x00007DD8C99D0123
00007dd8c99d45e7  sub rsp, 0x08
00007dd8c99d45eb  push rax
00007dd8c99d45ec  push rcx
00007dd8c99d45ed  push rdx
00007dd8c99d45ee  push rdi
00007dd8c99d45ef  push rsi
00007dd8c99d45f0  push r8
00007dd8c99d45f2  push r9
00007dd8c99d45f4  push r10
00007dd8c99d45f6  push r11
00007dd8c99d45f8  sub rsp, 0xF0
00007dd8c99d45ff  vmovaps [rsp], xmm0
00007dd8c99d4604  vmovaps [rsp+0x10], xmm1
00007dd8c99d460a  vmovaps [rsp+0x20], xmm2
00007dd8c99d4610  vmovaps [rsp+0x30], xmm3
00007dd8c99d4616  vmovaps [rsp+0x40], xmm4
00007dd8c99d461c  vmovaps [rsp+0x50], xmm5
00007dd8c99d4622  vmovaps [rsp+0x60], xmm6
00007dd8c99d4628  vmovaps [rsp+0x70], xmm7
00007dd8c99d462e  vmovaps [rsp+0x80], xmm8
00007dd8c99d4637  vmovaps [rsp+0x90], xmm9
00007dd8c99d4640  vmovaps [rsp+0xA0], xmm10
00007dd8c99d4649  vmovaps [rsp+0xB0], xmm11
00007dd8c99d4652  vmovaps [rsp+0xC0], xmm12
00007dd8c99d465b  vmovaps [rsp+0xD0], xmm13
00007dd8c99d4664  vmovaps [rsp+0xE0], xmm14
00007dd8c99d466d  sub rsp, 0x30
00007dd8c99d4671  movaps [rsp], xmm15
00007dd8c99d4676  movaps [rsp+0x10], xmm10
00007dd8c99d467c  movaps [rsp+0x20], xmm13
00007dd8c99d4682  lea rdi, [rsp]
00007dd8c99d4686  mov esi, 0x00
00007dd8c99d468b  mov rax, 0x55FEBBDB5530
00007dd8c99d4695  call rax
00007dd8c99d4697  movaps xmm15, [rsp]
00007dd8c99d469c  add rsp, 0x30
00007dd8c99d46a0  vmovaps xmm0, [rsp]
00007dd8c99d46a5  vmovaps xmm1, [rsp+0x10]
00007dd8c99d46ab  vmovaps xmm2, [rsp+0x20]
00007dd8c99d46b1  vmovaps xmm3, [rsp+0x30]
00007dd8c99d46b7  vmovaps xmm4, [rsp+0x40]
00007dd8c99d46bd  vmovaps xmm5, [rsp+0x50]
00007dd8c99d46c3  vmovaps xmm6, [rsp+0x60]
00007dd8c99d46c9  vmovaps xmm7, [rsp+0x70]
00007dd8c99d46cf  vmovaps xmm8, [rsp+0x80]
00007dd8c99d46d8  vmovaps xmm9, [rsp+0x90]
00007dd8c99d46e1  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d46ea  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d46f3  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d46fc  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d4705  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d470e  add rsp, 0xF0
00007dd8c99d4715  pop r11
00007dd8c99d4717  pop r10
00007dd8c99d4719  pop r9
00007dd8c99d471b  pop r8
00007dd8c99d471d  pop rsi
00007dd8c99d471e  pop rdi
00007dd8c99d471f  pop rdx
00007dd8c99d4720  pop rcx
00007dd8c99d4721  pop rax
00007dd8c99d4722  add rsp, 0x08
00007dd8c99d4726  jmp 0x00007DD8C99D013D
00007dd8c99d472b  sub rsp, 0x08
00007dd8c99d472f  push rax
00007dd8c99d4730  push rcx
00007dd8c99d4731  push rdx
00007dd8c99d4732  push rdi
00007dd8c99d4733  push rsi
00007dd8c99d4734  push r8
00007dd8c99d4736  push r9
00007dd8c99d4738  push r10
00007dd8c99d473a  push r11
00007dd8c99d473c  sub rsp, 0xF0
00007dd8c99d4743  vmovaps [rsp], xmm0
00007dd8c99d4748  vmovaps [rsp+0x10], xmm1
00007dd8c99d474e  vmovaps [rsp+0x20], xmm2
00007dd8c99d4754  vmovaps [rsp+0x30], xmm3
00007dd8c99d475a  vmovaps [rsp+0x40], xmm4
00007dd8c99d4760  vmovaps [rsp+0x50], xmm5
00007dd8c99d4766  vmovaps [rsp+0x60], xmm6
00007dd8c99d476c  vmovaps [rsp+0x70], xmm7
00007dd8c99d4772  vmovaps [rsp+0x80], xmm8
00007dd8c99d477b  vmovaps [rsp+0x90], xmm9
00007dd8c99d4784  vmovaps [rsp+0xA0], xmm11
00007dd8c99d478d  vmovaps [rsp+0xB0], xmm12
00007dd8c99d4796  vmovaps [rsp+0xC0], xmm13
00007dd8c99d479f  vmovaps [rsp+0xD0], xmm14
00007dd8c99d47a8  vmovaps [rsp+0xE0], xmm15
00007dd8c99d47b1  sub rsp, 0x30
00007dd8c99d47b5  movaps [rsp], xmm10
00007dd8c99d47ba  movaps [rsp+0x10], xmm7
00007dd8c99d47bf  movaps [rsp+0x20], xmm13
00007dd8c99d47c5  lea rdi, [rsp]
00007dd8c99d47c9  mov esi, 0x00
00007dd8c99d47ce  mov rax, 0x55FEBBDB5530
00007dd8c99d47d8  call rax
00007dd8c99d47da  movaps xmm10, [rsp]
00007dd8c99d47df  add rsp, 0x30
00007dd8c99d47e3  vmovaps xmm0, [rsp]
00007dd8c99d47e8  vmovaps xmm1, [rsp+0x10]
00007dd8c99d47ee  vmovaps xmm2, [rsp+0x20]
00007dd8c99d47f4  vmovaps xmm3, [rsp+0x30]
00007dd8c99d47fa  vmovaps xmm4, [rsp+0x40]
00007dd8c99d4800  vmovaps xmm5, [rsp+0x50]
00007dd8c99d4806  vmovaps xmm6, [rsp+0x60]
00007dd8c99d480c  vmovaps xmm7, [rsp+0x70]
00007dd8c99d4812  vmovaps xmm8, [rsp+0x80]
00007dd8c99d481b  vmovaps xmm9, [rsp+0x90]
00007dd8c99d4824  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d482d  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d4836  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d483f  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d4848  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d4851  add rsp, 0xF0
00007dd8c99d4858  pop r11
00007dd8c99d485a  pop r10
00007dd8c99d485c  pop r9
00007dd8c99d485e  pop r8
00007dd8c99d4860  pop rsi
00007dd8c99d4861  pop rdi
00007dd8c99d4862  pop rdx
00007dd8c99d4863  pop rcx
00007dd8c99d4864  pop rax
00007dd8c99d4865  add rsp, 0x08
00007dd8c99d4869  jmp 0x00007DD8C99D0169
00007dd8c99d486e  sub rsp, 0x08
00007dd8c99d4872  push rax
00007dd8c99d4873  push rcx
00007dd8c99d4874  push rdx
00007dd8c99d4875  push rdi
00007dd8c99d4876  push rsi
00007dd8c99d4877  push r8
00007dd8c99d4879  push r9
00007dd8c99d487b  push r10
00007dd8c99d487d  push r11
00007dd8c99d487f  sub rsp, 0xF0
00007dd8c99d4886  vmovaps [rsp], xmm0
00007dd8c99d488b  vmovaps [rsp+0x10], xmm1
00007dd8c99d4891  vmovaps [rsp+0x20], xmm2
00007dd8c99d4897  vmovaps [rsp+0x30], xmm3
00007dd8c99d489d  vmovaps [rsp+0x40], xmm4
00007dd8c99d48a3  vmovaps [rsp+0x50], xmm5
00007dd8c99d48a9  vmovaps [rsp+0x60], xmm6
00007dd8c99d48af  vmovaps [rsp+0x70], xmm7
00007dd8c99d48b5  vmovaps [rsp+0x80], xmm8
00007dd8c99d48be  vmovaps [rsp+0x90], xmm9
00007dd8c99d48c7  vmovaps [rsp+0xA0], xmm10
00007dd8c99d48d0  vmovaps [rsp+0xB0], xmm11
00007dd8c99d48d9  vmovaps [rsp+0xC0], xmm12
00007dd8c99d48e2  vmovaps [rsp+0xD0], xmm14
00007dd8c99d48eb  vmovaps [rsp+0xE0], xmm15
00007dd8c99d48f4  sub rsp, 0x30
00007dd8c99d48f8  movaps [rsp], xmm13
00007dd8c99d48fd  movaps [rsp+0x10], xmm1
00007dd8c99d4902  movaps [rsp+0x20], xmm8
00007dd8c99d4908  lea rdi, [rsp]
00007dd8c99d490c  mov esi, 0x00
00007dd8c99d4911  mov rax, 0x55FEBBDB5530
00007dd8c99d491b  call rax
00007dd8c99d491d  movaps xmm13, [rsp]
00007dd8c99d4922  add rsp, 0x30
00007dd8c99d4926  vmovaps xmm0, [rsp]
00007dd8c99d492b  vmovaps xmm1, [rsp+0x10]
00007dd8c99d4931  vmovaps xmm2, [rsp+0x20]
00007dd8c99d4937  vmovaps xmm3, [rsp+0x30]
00007dd8c99d493d  vmovaps xmm4, [rsp+0x40]
00007dd8c99d4943  vmovaps xmm5, [rsp+0x50]
00007dd8c99d4949  vmovaps xmm6, [rsp+0x60]
00007dd8c99d494f  vmovaps xmm7, [rsp+0x70]
00007dd8c99d4955  vmovaps xmm8, [rsp+0x80]
00007dd8c99d495e  vmovaps xmm9, [rsp+0x90]
00007dd8c99d4967  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d4970  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d4979  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d4982  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d498b  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d4994  add rsp, 0xF0
00007dd8c99d499b  pop r11
00007dd8c99d499d  pop r10
00007dd8c99d499f  pop r9
00007dd8c99d49a1  pop r8
00007dd8c99d49a3  pop rsi
00007dd8c99d49a4  pop rdi
00007dd8c99d49a5  pop rdx
00007dd8c99d49a6  pop rcx
00007dd8c99d49a7  pop rax
00007dd8c99d49a8  add rsp, 0x08
00007dd8c99d49ac  jmp 0x00007DD8C99D0183
00007dd8c99d49b1  call 0x00007DD8C97FF430
00007dd8c99d49b6  jmp 0x00007DD8C99D018D
00007dd8c99d49bb  sub rsp, 0x08
00007dd8c99d49bf  push rax
00007dd8c99d49c0  push rcx
00007dd8c99d49c1  push rdx
00007dd8c99d49c2  push rdi
00007dd8c99d49c3  push rsi
00007dd8c99d49c4  push r8
00007dd8c99d49c6  push r9
00007dd8c99d49c8  push r10
00007dd8c99d49ca  push r11
00007dd8c99d49cc  sub rsp, 0xF0
00007dd8c99d49d3  vmovaps [rsp], xmm0
00007dd8c99d49d8  vmovaps [rsp+0x10], xmm1
00007dd8c99d49de  vmovaps [rsp+0x20], xmm2
00007dd8c99d49e4  vmovaps [rsp+0x30], xmm3
00007dd8c99d49ea  vmovaps [rsp+0x40], xmm4
00007dd8c99d49f0  vmovaps [rsp+0x50], xmm5
00007dd8c99d49f6  vmovaps [rsp+0x60], xmm6
00007dd8c99d49fc  vmovaps [rsp+0x70], xmm7
00007dd8c99d4a02  vmovaps [rsp+0x80], xmm9
00007dd8c99d4a0b  vmovaps [rsp+0x90], xmm10
00007dd8c99d4a14  vmovaps [rsp+0xA0], xmm11
00007dd8c99d4a1d  vmovaps [rsp+0xB0], xmm12
00007dd8c99d4a26  vmovaps [rsp+0xC0], xmm13
00007dd8c99d4a2f  vmovaps [rsp+0xD0], xmm14
00007dd8c99d4a38  vmovaps [rsp+0xE0], xmm15
00007dd8c99d4a41  sub rsp, 0x30
00007dd8c99d4a45  movaps [rsp], xmm8
00007dd8c99d4a4a  movaps [rsp+0x10], xmm14
00007dd8c99d4a50  movaps [rsp+0x20], xmm9
00007dd8c99d4a56  lea rdi, [rsp]
00007dd8c99d4a5a  mov esi, 0x00
00007dd8c99d4a5f  mov rax, 0x55FEBBDB5530
00007dd8c99d4a69  call rax
00007dd8c99d4a6b  movaps xmm8, [rsp]
00007dd8c99d4a70  add rsp, 0x30
00007dd8c99d4a74  vmovaps xmm0, [rsp]
00007dd8c99d4a79  vmovaps xmm1, [rsp+0x10]
00007dd8c99d4a7f  vmovaps xmm2, [rsp+0x20]
00007dd8c99d4a85  vmovaps xmm3, [rsp+0x30]
00007dd8c99d4a8b  vmovaps xmm4, [rsp+0x40]
00007dd8c99d4a91  vmovaps xmm5, [rsp+0x50]
00007dd8c99d4a97  vmovaps xmm6, [rsp+0x60]
00007dd8c99d4a9d  vmovaps xmm7, [rsp+0x70]
00007dd8c99d4aa3  vmovaps xmm9, [rsp+0x80]
00007dd8c99d4aac  vmovaps xmm10, [rsp+0x90]
00007dd8c99d4ab5  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d4abe  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d4ac7  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d4ad0  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d4ad9  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d4ae2  add rsp, 0xF0
00007dd8c99d4ae9  pop r11
00007dd8c99d4aeb  pop r10
00007dd8c99d4aed  pop r9
00007dd8c99d4aef  pop r8
00007dd8c99d4af1  pop rsi
00007dd8c99d4af2  pop rdi
00007dd8c99d4af3  pop rdx
00007dd8c99d4af4  pop rcx
00007dd8c99d4af5  pop rax
00007dd8c99d4af6  add rsp, 0x08
00007dd8c99d4afa  jmp 0x00007DD8C99D01AF
00007dd8c99d4aff  sub rsp, 0x08
00007dd8c99d4b03  push rax
00007dd8c99d4b04  push rcx
00007dd8c99d4b05  push rdx
00007dd8c99d4b06  push rdi
00007dd8c99d4b07  push rsi
00007dd8c99d4b08  push r8
00007dd8c99d4b0a  push r9
00007dd8c99d4b0c  push r10
00007dd8c99d4b0e  push r11
00007dd8c99d4b10  sub rsp, 0xF0
00007dd8c99d4b17  vmovaps [rsp], xmm0
00007dd8c99d4b1c  vmovaps [rsp+0x10], xmm1
00007dd8c99d4b22  vmovaps [rsp+0x20], xmm2
00007dd8c99d4b28  vmovaps [rsp+0x30], xmm3
00007dd8c99d4b2e  vmovaps [rsp+0x40], xmm4
00007dd8c99d4b34  vmovaps [rsp+0x50], xmm5
00007dd8c99d4b3a  vmovaps [rsp+0x60], xmm6
00007dd8c99d4b40  vmovaps [rsp+0x70], xmm7
00007dd8c99d4b46  vmovaps [rsp+0x80], xmm8
00007dd8c99d4b4f  vmovaps [rsp+0x90], xmm10
00007dd8c99d4b58  vmovaps [rsp+0xA0], xmm11
00007dd8c99d4b61  vmovaps [rsp+0xB0], xmm12
00007dd8c99d4b6a  vmovaps [rsp+0xC0], xmm13
00007dd8c99d4b73  vmovaps [rsp+0xD0], xmm14
00007dd8c99d4b7c  vmovaps [rsp+0xE0], xmm15
00007dd8c99d4b85  sub rsp, 0x30
00007dd8c99d4b89  movaps [rsp], xmm9
00007dd8c99d4b8e  movaps [rsp+0x10], xmm1
00007dd8c99d4b93  movaps [rsp+0x20], xmm14
00007dd8c99d4b99  lea rdi, [rsp]
00007dd8c99d4b9d  mov esi, 0x00
00007dd8c99d4ba2  mov rax, 0x55FEBBDB5530
00007dd8c99d4bac  call rax
00007dd8c99d4bae  movaps xmm9, [rsp]
00007dd8c99d4bb3  add rsp, 0x30
00007dd8c99d4bb7  vmovaps xmm0, [rsp]
00007dd8c99d4bbc  vmovaps xmm1, [rsp+0x10]
00007dd8c99d4bc2  vmovaps xmm2, [rsp+0x20]
00007dd8c99d4bc8  vmovaps xmm3, [rsp+0x30]
00007dd8c99d4bce  vmovaps xmm4, [rsp+0x40]
00007dd8c99d4bd4  vmovaps xmm5, [rsp+0x50]
00007dd8c99d4bda  vmovaps xmm6, [rsp+0x60]
00007dd8c99d4be0  vmovaps xmm7, [rsp+0x70]
00007dd8c99d4be6  vmovaps xmm8, [rsp+0x80]
00007dd8c99d4bef  vmovaps xmm10, [rsp+0x90]
00007dd8c99d4bf8  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d4c01  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d4c0a  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d4c13  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d4c1c  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d4c25  add rsp, 0xF0
00007dd8c99d4c2c  pop r11
00007dd8c99d4c2e  pop r10
00007dd8c99d4c30  pop r9
00007dd8c99d4c32  pop r8
00007dd8c99d4c34  pop rsi
00007dd8c99d4c35  pop rdi
00007dd8c99d4c36  pop rdx
00007dd8c99d4c37  pop rcx
00007dd8c99d4c38  pop rax
00007dd8c99d4c39  add rsp, 0x08
00007dd8c99d4c3d  jmp 0x00007DD8C99D01DD
00007dd8c99d4c42  sub rsp, 0x08
00007dd8c99d4c46  push rax
00007dd8c99d4c47  push rcx
00007dd8c99d4c48  push rdx
00007dd8c99d4c49  push rdi
00007dd8c99d4c4a  push rsi
00007dd8c99d4c4b  push r8
00007dd8c99d4c4d  push r9
00007dd8c99d4c4f  push r10
00007dd8c99d4c51  push r11
00007dd8c99d4c53  sub rsp, 0xF0
00007dd8c99d4c5a  vmovaps [rsp], xmm0
00007dd8c99d4c5f  vmovaps [rsp+0x10], xmm1
00007dd8c99d4c65  vmovaps [rsp+0x20], xmm2
00007dd8c99d4c6b  vmovaps [rsp+0x30], xmm3
00007dd8c99d4c71  vmovaps [rsp+0x40], xmm4
00007dd8c99d4c77  vmovaps [rsp+0x50], xmm5
00007dd8c99d4c7d  vmovaps [rsp+0x60], xmm6
00007dd8c99d4c83  vmovaps [rsp+0x70], xmm7
00007dd8c99d4c89  vmovaps [rsp+0x80], xmm8
00007dd8c99d4c92  vmovaps [rsp+0x90], xmm9
00007dd8c99d4c9b  vmovaps [rsp+0xA0], xmm10
00007dd8c99d4ca4  vmovaps [rsp+0xB0], xmm11
00007dd8c99d4cad  vmovaps [rsp+0xC0], xmm12
00007dd8c99d4cb6  vmovaps [rsp+0xD0], xmm13
00007dd8c99d4cbf  vmovaps [rsp+0xE0], xmm15
00007dd8c99d4cc8  sub rsp, 0x30
00007dd8c99d4ccc  movaps [rsp], xmm14
00007dd8c99d4cd1  movaps [rsp+0x10], xmm4
00007dd8c99d4cd6  movaps [rsp+0x20], xmm1
00007dd8c99d4cdb  lea rdi, [rsp]
00007dd8c99d4cdf  mov esi, 0x00
00007dd8c99d4ce4  mov rax, 0x55FEBBDB5530
00007dd8c99d4cee  call rax
00007dd8c99d4cf0  movaps xmm14, [rsp]
00007dd8c99d4cf5  add rsp, 0x30
00007dd8c99d4cf9  vmovaps xmm0, [rsp]
00007dd8c99d4cfe  vmovaps xmm1, [rsp+0x10]
00007dd8c99d4d04  vmovaps xmm2, [rsp+0x20]
00007dd8c99d4d0a  vmovaps xmm3, [rsp+0x30]
00007dd8c99d4d10  vmovaps xmm4, [rsp+0x40]
00007dd8c99d4d16  vmovaps xmm5, [rsp+0x50]
00007dd8c99d4d1c  vmovaps xmm6, [rsp+0x60]
00007dd8c99d4d22  vmovaps xmm7, [rsp+0x70]
00007dd8c99d4d28  vmovaps xmm8, [rsp+0x80]
00007dd8c99d4d31  vmovaps xmm9, [rsp+0x90]
00007dd8c99d4d3a  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d4d43  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d4d4c  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d4d55  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d4d5e  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d4d67  add rsp, 0xF0
00007dd8c99d4d6e  pop r11
00007dd8c99d4d70  pop r10
00007dd8c99d4d72  pop r9
00007dd8c99d4d74  pop r8
00007dd8c99d4d76  pop rsi
00007dd8c99d4d77  pop rdi
00007dd8c99d4d78  pop rdx
00007dd8c99d4d79  pop rcx
00007dd8c99d4d7a  pop rax
00007dd8c99d4d7b  add rsp, 0x08
00007dd8c99d4d7f  jmp 0x00007DD8C99D0203
00007dd8c99d4d84  sub rsp, 0x08
00007dd8c99d4d88  push rax
00007dd8c99d4d89  push rcx
00007dd8c99d4d8a  push rdx
00007dd8c99d4d8b  push rdi
00007dd8c99d4d8c  push rsi
00007dd8c99d4d8d  push r8
00007dd8c99d4d8f  push r9
00007dd8c99d4d91  push r10
00007dd8c99d4d93  push r11
00007dd8c99d4d95  sub rsp, 0xF0
00007dd8c99d4d9c  vmovaps [rsp], xmm0
00007dd8c99d4da1  vmovaps [rsp+0x10], xmm2
00007dd8c99d4da7  vmovaps [rsp+0x20], xmm3
00007dd8c99d4dad  vmovaps [rsp+0x30], xmm4
00007dd8c99d4db3  vmovaps [rsp+0x40], xmm5
00007dd8c99d4db9  vmovaps [rsp+0x50], xmm6
00007dd8c99d4dbf  vmovaps [rsp+0x60], xmm7
00007dd8c99d4dc5  vmovaps [rsp+0x70], xmm8
00007dd8c99d4dcb  vmovaps [rsp+0x80], xmm9
00007dd8c99d4dd4  vmovaps [rsp+0x90], xmm10
00007dd8c99d4ddd  vmovaps [rsp+0xA0], xmm11
00007dd8c99d4de6  vmovaps [rsp+0xB0], xmm12
00007dd8c99d4def  vmovaps [rsp+0xC0], xmm13
00007dd8c99d4df8  vmovaps [rsp+0xD0], xmm14
00007dd8c99d4e01  vmovaps [rsp+0xE0], xmm15
00007dd8c99d4e0a  sub rsp, 0x30
00007dd8c99d4e0e  movaps [rsp], xmm1
00007dd8c99d4e12  movaps [rsp+0x10], xmm12
00007dd8c99d4e18  movaps [rsp+0x20], xmm11
00007dd8c99d4e1e  lea rdi, [rsp]
00007dd8c99d4e22  mov esi, 0x00
00007dd8c99d4e27  mov rax, 0x55FEBBDB5530
00007dd8c99d4e31  call rax
00007dd8c99d4e33  movaps xmm1, [rsp]
00007dd8c99d4e37  add rsp, 0x30
00007dd8c99d4e3b  vmovaps xmm0, [rsp]
00007dd8c99d4e40  vmovaps xmm2, [rsp+0x10]
00007dd8c99d4e46  vmovaps xmm3, [rsp+0x20]
00007dd8c99d4e4c  vmovaps xmm4, [rsp+0x30]
00007dd8c99d4e52  vmovaps xmm5, [rsp+0x40]
00007dd8c99d4e58  vmovaps xmm6, [rsp+0x50]
00007dd8c99d4e5e  vmovaps xmm7, [rsp+0x60]
00007dd8c99d4e64  vmovaps xmm8, [rsp+0x70]
00007dd8c99d4e6a  vmovaps xmm9, [rsp+0x80]
00007dd8c99d4e73  vmovaps xmm10, [rsp+0x90]
00007dd8c99d4e7c  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d4e85  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d4e8e  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d4e97  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d4ea0  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d4ea9  add rsp, 0xF0
00007dd8c99d4eb0  pop r11
00007dd8c99d4eb2  pop r10
00007dd8c99d4eb4  pop r9
00007dd8c99d4eb6  pop r8
00007dd8c99d4eb8  pop rsi
00007dd8c99d4eb9  pop rdi
00007dd8c99d4eba  pop rdx
00007dd8c99d4ebb  pop rcx
00007dd8c99d4ebc  pop rax
00007dd8c99d4ebd  add rsp, 0x08
00007dd8c99d4ec1  jmp 0x00007DD8C99D0224
00007dd8c99d4ec6  call 0x00007DD8C98E20A0
00007dd8c99d4ecb  jmp 0x00007DD8C99D0232
00007dd8c99d4ed0  call 0x00007DD8C9809D70
00007dd8c99d4ed5  jmp 0x00007DD8C99D023C
00007dd8c99d4eda  sub rsp, 0x08
00007dd8c99d4ede  push rax
00007dd8c99d4edf  push rcx
00007dd8c99d4ee0  push rdx
00007dd8c99d4ee1  push rdi
00007dd8c99d4ee2  push rsi
00007dd8c99d4ee3  push r8
00007dd8c99d4ee5  push r9
00007dd8c99d4ee7  push r10
00007dd8c99d4ee9  push r11
00007dd8c99d4eeb  sub rsp, 0xF0
00007dd8c99d4ef2  vmovaps [rsp], xmm0
00007dd8c99d4ef7  vmovaps [rsp+0x10], xmm1
00007dd8c99d4efd  vmovaps [rsp+0x20], xmm2
00007dd8c99d4f03  vmovaps [rsp+0x30], xmm3
00007dd8c99d4f09  vmovaps [rsp+0x40], xmm4
00007dd8c99d4f0f  vmovaps [rsp+0x50], xmm5
00007dd8c99d4f15  vmovaps [rsp+0x60], xmm6
00007dd8c99d4f1b  vmovaps [rsp+0x70], xmm8
00007dd8c99d4f21  vmovaps [rsp+0x80], xmm9
00007dd8c99d4f2a  vmovaps [rsp+0x90], xmm10
00007dd8c99d4f33  vmovaps [rsp+0xA0], xmm11
00007dd8c99d4f3c  vmovaps [rsp+0xB0], xmm12
00007dd8c99d4f45  vmovaps [rsp+0xC0], xmm13
00007dd8c99d4f4e  vmovaps [rsp+0xD0], xmm14
00007dd8c99d4f57  vmovaps [rsp+0xE0], xmm15
00007dd8c99d4f60  sub rsp, 0x30
00007dd8c99d4f64  movaps [rsp], xmm7
00007dd8c99d4f68  movaps [rsp+0x10], xmm15
00007dd8c99d4f6e  movaps [rsp+0x20], xmm10
00007dd8c99d4f74  lea rdi, [rsp]
00007dd8c99d4f78  mov esi, 0x00
00007dd8c99d4f7d  mov rax, 0x55FEBBDB5530
00007dd8c99d4f87  call rax
00007dd8c99d4f89  movaps xmm7, [rsp]
00007dd8c99d4f8d  add rsp, 0x30
00007dd8c99d4f91  vmovaps xmm0, [rsp]
00007dd8c99d4f96  vmovaps xmm1, [rsp+0x10]
00007dd8c99d4f9c  vmovaps xmm2, [rsp+0x20]
00007dd8c99d4fa2  vmovaps xmm3, [rsp+0x30]
00007dd8c99d4fa8  vmovaps xmm4, [rsp+0x40]
00007dd8c99d4fae  vmovaps xmm5, [rsp+0x50]
00007dd8c99d4fb4  vmovaps xmm6, [rsp+0x60]
00007dd8c99d4fba  vmovaps xmm8, [rsp+0x70]
00007dd8c99d4fc0  vmovaps xmm9, [rsp+0x80]
00007dd8c99d4fc9  vmovaps xmm10, [rsp+0x90]
00007dd8c99d4fd2  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d4fdb  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d4fe4  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d4fed  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d4ff6  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d4fff  add rsp, 0xF0
00007dd8c99d5006  pop r11
00007dd8c99d5008  pop r10
00007dd8c99d500a  pop r9
00007dd8c99d500c  pop r8
00007dd8c99d500e  pop rsi
00007dd8c99d500f  pop rdi
00007dd8c99d5010  pop rdx
00007dd8c99d5011  pop rcx
00007dd8c99d5012  pop rax
00007dd8c99d5013  add rsp, 0x08
00007dd8c99d5017  jmp 0x00007DD8C99D025D
00007dd8c99d501c  sub rsp, 0x08
00007dd8c99d5020  push rax
00007dd8c99d5021  push rcx
00007dd8c99d5022  push rdx
00007dd8c99d5023  push rdi
00007dd8c99d5024  push rsi
00007dd8c99d5025  push r8
00007dd8c99d5027  push r9
00007dd8c99d5029  push r10
00007dd8c99d502b  push r11
00007dd8c99d502d  sub rsp, 0xF0
00007dd8c99d5034  vmovaps [rsp], xmm0
00007dd8c99d5039  vmovaps [rsp+0x10], xmm1
00007dd8c99d503f  vmovaps [rsp+0x20], xmm2
00007dd8c99d5045  vmovaps [rsp+0x30], xmm3
00007dd8c99d504b  vmovaps [rsp+0x40], xmm4
00007dd8c99d5051  vmovaps [rsp+0x50], xmm5
00007dd8c99d5057  vmovaps [rsp+0x60], xmm6
00007dd8c99d505d  vmovaps [rsp+0x70], xmm7
00007dd8c99d5063  vmovaps [rsp+0x80], xmm8
00007dd8c99d506c  vmovaps [rsp+0x90], xmm9
00007dd8c99d5075  vmovaps [rsp+0xA0], xmm11
00007dd8c99d507e  vmovaps [rsp+0xB0], xmm12
00007dd8c99d5087  vmovaps [rsp+0xC0], xmm13
00007dd8c99d5090  vmovaps [rsp+0xD0], xmm14
00007dd8c99d5099  vmovaps [rsp+0xE0], xmm15
00007dd8c99d50a2  sub rsp, 0x30
00007dd8c99d50a6  movaps [rsp], xmm10
00007dd8c99d50ab  movaps [rsp+0x10], xmm11
00007dd8c99d50b1  movaps [rsp+0x20], xmm15
00007dd8c99d50b7  lea rdi, [rsp]
00007dd8c99d50bb  mov esi, 0x00
00007dd8c99d50c0  mov rax, 0x55FEBBDB5530
00007dd8c99d50ca  call rax
00007dd8c99d50cc  movaps xmm10, [rsp]
00007dd8c99d50d1  add rsp, 0x30
00007dd8c99d50d5  vmovaps xmm0, [rsp]
00007dd8c99d50da  vmovaps xmm1, [rsp+0x10]
00007dd8c99d50e0  vmovaps xmm2, [rsp+0x20]
00007dd8c99d50e6  vmovaps xmm3, [rsp+0x30]
00007dd8c99d50ec  vmovaps xmm4, [rsp+0x40]
00007dd8c99d50f2  vmovaps xmm5, [rsp+0x50]
00007dd8c99d50f8  vmovaps xmm6, [rsp+0x60]
00007dd8c99d50fe  vmovaps xmm7, [rsp+0x70]
00007dd8c99d5104  vmovaps xmm8, [rsp+0x80]
00007dd8c99d510d  vmovaps xmm9, [rsp+0x90]
00007dd8c99d5116  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d511f  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d5128  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d5131  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d513a  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d5143  add rsp, 0xF0
00007dd8c99d514a  pop r11
00007dd8c99d514c  pop r10
00007dd8c99d514e  pop r9
00007dd8c99d5150  pop r8
00007dd8c99d5152  pop rsi
00007dd8c99d5153  pop rdi
00007dd8c99d5154  pop rdx
00007dd8c99d5155  pop rcx
00007dd8c99d5156  pop rax
00007dd8c99d5157  add rsp, 0x08
00007dd8c99d515b  jmp 0x00007DD8C99D028B
00007dd8c99d5160  sub rsp, 0x08
00007dd8c99d5164  push rax
00007dd8c99d5165  push rcx
00007dd8c99d5166  push rdx
00007dd8c99d5167  push rdi
00007dd8c99d5168  push rsi
00007dd8c99d5169  push r8
00007dd8c99d516b  push r9
00007dd8c99d516d  push r10
00007dd8c99d516f  push r11
00007dd8c99d5171  sub rsp, 0xF0
00007dd8c99d5178  vmovaps [rsp], xmm0
00007dd8c99d517d  vmovaps [rsp+0x10], xmm1
00007dd8c99d5183  vmovaps [rsp+0x20], xmm2
00007dd8c99d5189  vmovaps [rsp+0x30], xmm3
00007dd8c99d518f  vmovaps [rsp+0x40], xmm4
00007dd8c99d5195  vmovaps [rsp+0x50], xmm5
00007dd8c99d519b  vmovaps [rsp+0x60], xmm6
00007dd8c99d51a1  vmovaps [rsp+0x70], xmm7
00007dd8c99d51a7  vmovaps [rsp+0x80], xmm8
00007dd8c99d51b0  vmovaps [rsp+0x90], xmm9
00007dd8c99d51b9  vmovaps [rsp+0xA0], xmm10
00007dd8c99d51c2  vmovaps [rsp+0xB0], xmm12
00007dd8c99d51cb  vmovaps [rsp+0xC0], xmm13
00007dd8c99d51d4  vmovaps [rsp+0xD0], xmm14
00007dd8c99d51dd  vmovaps [rsp+0xE0], xmm15
00007dd8c99d51e6  sub rsp, 0x30
00007dd8c99d51ea  movaps [rsp], xmm11
00007dd8c99d51ef  movaps [rsp+0x10], xmm12
00007dd8c99d51f5  movaps [rsp+0x20], xmm15
00007dd8c99d51fb  lea rdi, [rsp]
00007dd8c99d51ff  mov esi, 0x00
00007dd8c99d5204  mov rax, 0x55FEBBDB5530
00007dd8c99d520e  call rax
00007dd8c99d5210  movaps xmm11, [rsp]
00007dd8c99d5215  add rsp, 0x30
00007dd8c99d5219  vmovaps xmm0, [rsp]
00007dd8c99d521e  vmovaps xmm1, [rsp+0x10]
00007dd8c99d5224  vmovaps xmm2, [rsp+0x20]
00007dd8c99d522a  vmovaps xmm3, [rsp+0x30]
00007dd8c99d5230  vmovaps xmm4, [rsp+0x40]
00007dd8c99d5236  vmovaps xmm5, [rsp+0x50]
00007dd8c99d523c  vmovaps xmm6, [rsp+0x60]
00007dd8c99d5242  vmovaps xmm7, [rsp+0x70]
00007dd8c99d5248  vmovaps xmm8, [rsp+0x80]
00007dd8c99d5251  vmovaps xmm9, [rsp+0x90]
00007dd8c99d525a  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d5263  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d526c  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d5275  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d527e  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d5287  add rsp, 0xF0
00007dd8c99d528e  pop r11
00007dd8c99d5290  pop r10
00007dd8c99d5292  pop r9
00007dd8c99d5294  pop r8
00007dd8c99d5296  pop rsi
00007dd8c99d5297  pop rdi
00007dd8c99d5298  pop rdx
00007dd8c99d5299  pop rcx
00007dd8c99d529a  pop rax
00007dd8c99d529b  add rsp, 0x08
00007dd8c99d529f  jmp 0x00007DD8C99D02B9
00007dd8c99d52a4  sub rsp, 0x08
00007dd8c99d52a8  push rax
00007dd8c99d52a9  push rcx
00007dd8c99d52aa  push rdx
00007dd8c99d52ab  push rdi
00007dd8c99d52ac  push rsi
00007dd8c99d52ad  push r8
00007dd8c99d52af  push r9
00007dd8c99d52b1  push r10
00007dd8c99d52b3  push r11
00007dd8c99d52b5  sub rsp, 0xF0
00007dd8c99d52bc  vmovaps [rsp], xmm0
00007dd8c99d52c1  vmovaps [rsp+0x10], xmm1
00007dd8c99d52c7  vmovaps [rsp+0x20], xmm2
00007dd8c99d52cd  vmovaps [rsp+0x30], xmm3
00007dd8c99d52d3  vmovaps [rsp+0x40], xmm4
00007dd8c99d52d9  vmovaps [rsp+0x50], xmm5
00007dd8c99d52df  vmovaps [rsp+0x60], xmm6
00007dd8c99d52e5  vmovaps [rsp+0x70], xmm7
00007dd8c99d52eb  vmovaps [rsp+0x80], xmm8
00007dd8c99d52f4  vmovaps [rsp+0x90], xmm9
00007dd8c99d52fd  vmovaps [rsp+0xA0], xmm10
00007dd8c99d5306  vmovaps [rsp+0xB0], xmm11
00007dd8c99d530f  vmovaps [rsp+0xC0], xmm12
00007dd8c99d5318  vmovaps [rsp+0xD0], xmm13
00007dd8c99d5321  vmovaps [rsp+0xE0], xmm14
00007dd8c99d532a  sub rsp, 0x30
00007dd8c99d532e  movaps [rsp], xmm15
00007dd8c99d5333  movaps [rsp+0x10], xmm13
00007dd8c99d5339  movaps [rsp+0x20], xmm9
00007dd8c99d533f  lea rdi, [rsp]
00007dd8c99d5343  mov esi, 0x00
00007dd8c99d5348  mov rax, 0x55FEBBDB5530
00007dd8c99d5352  call rax
00007dd8c99d5354  movaps xmm15, [rsp]
00007dd8c99d5359  add rsp, 0x30
00007dd8c99d535d  vmovaps xmm0, [rsp]
00007dd8c99d5362  vmovaps xmm1, [rsp+0x10]
00007dd8c99d5368  vmovaps xmm2, [rsp+0x20]
00007dd8c99d536e  vmovaps xmm3, [rsp+0x30]
00007dd8c99d5374  vmovaps xmm4, [rsp+0x40]
00007dd8c99d537a  vmovaps xmm5, [rsp+0x50]
00007dd8c99d5380  vmovaps xmm6, [rsp+0x60]
00007dd8c99d5386  vmovaps xmm7, [rsp+0x70]
00007dd8c99d538c  vmovaps xmm8, [rsp+0x80]
00007dd8c99d5395  vmovaps xmm9, [rsp+0x90]
00007dd8c99d539e  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d53a7  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d53b0  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d53b9  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d53c2  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d53cb  add rsp, 0xF0
00007dd8c99d53d2  pop r11
00007dd8c99d53d4  pop r10
00007dd8c99d53d6  pop r9
00007dd8c99d53d8  pop r8
00007dd8c99d53da  pop rsi
00007dd8c99d53db  pop rdi
00007dd8c99d53dc  pop rdx
00007dd8c99d53dd  pop rcx
00007dd8c99d53de  pop rax
00007dd8c99d53df  add rsp, 0x08
00007dd8c99d53e3  jmp 0x00007DD8C99D02D4
00007dd8c99d53e8  sub rsp, 0x08
00007dd8c99d53ec  push rax
00007dd8c99d53ed  push rcx
00007dd8c99d53ee  push rdx
00007dd8c99d53ef  push rdi
00007dd8c99d53f0  push rsi
00007dd8c99d53f1  push r8
00007dd8c99d53f3  push r9
00007dd8c99d53f5  push r10
00007dd8c99d53f7  push r11
00007dd8c99d53f9  sub rsp, 0xF0
00007dd8c99d5400  vmovaps [rsp], xmm0
00007dd8c99d5405  vmovaps [rsp+0x10], xmm1
00007dd8c99d540b  vmovaps [rsp+0x20], xmm2
00007dd8c99d5411  vmovaps [rsp+0x30], xmm3
00007dd8c99d5417  vmovaps [rsp+0x40], xmm4
00007dd8c99d541d  vmovaps [rsp+0x50], xmm5
00007dd8c99d5423  vmovaps [rsp+0x60], xmm6
00007dd8c99d5429  vmovaps [rsp+0x70], xmm7
00007dd8c99d542f  vmovaps [rsp+0x80], xmm8
00007dd8c99d5438  vmovaps [rsp+0x90], xmm9
00007dd8c99d5441  vmovaps [rsp+0xA0], xmm10
00007dd8c99d544a  vmovaps [rsp+0xB0], xmm11
00007dd8c99d5453  vmovaps [rsp+0xC0], xmm12
00007dd8c99d545c  vmovaps [rsp+0xD0], xmm14
00007dd8c99d5465  vmovaps [rsp+0xE0], xmm15
00007dd8c99d546e  sub rsp, 0x30
00007dd8c99d5472  movaps [rsp], xmm13
00007dd8c99d5477  movaps [rsp+0x10], xmm8
00007dd8c99d547d  movaps [rsp+0x20], xmm14
00007dd8c99d5483  lea rdi, [rsp]
00007dd8c99d5487  mov esi, 0x00
00007dd8c99d548c  mov rax, 0x55FEBBDB5530
00007dd8c99d5496  call rax
00007dd8c99d5498  movaps xmm13, [rsp]
00007dd8c99d549d  add rsp, 0x30
00007dd8c99d54a1  vmovaps xmm0, [rsp]
00007dd8c99d54a6  vmovaps xmm1, [rsp+0x10]
00007dd8c99d54ac  vmovaps xmm2, [rsp+0x20]
00007dd8c99d54b2  vmovaps xmm3, [rsp+0x30]
00007dd8c99d54b8  vmovaps xmm4, [rsp+0x40]
00007dd8c99d54be  vmovaps xmm5, [rsp+0x50]
00007dd8c99d54c4  vmovaps xmm6, [rsp+0x60]
00007dd8c99d54ca  vmovaps xmm7, [rsp+0x70]
00007dd8c99d54d0  vmovaps xmm8, [rsp+0x80]
00007dd8c99d54d9  vmovaps xmm9, [rsp+0x90]
00007dd8c99d54e2  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d54eb  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d54f4  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d54fd  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d5506  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d550f  add rsp, 0xF0
00007dd8c99d5516  pop r11
00007dd8c99d5518  pop r10
00007dd8c99d551a  pop r9
00007dd8c99d551c  pop r8
00007dd8c99d551e  pop rsi
00007dd8c99d551f  pop rdi
00007dd8c99d5520  pop rdx
00007dd8c99d5521  pop rcx
00007dd8c99d5522  pop rax
00007dd8c99d5523  add rsp, 0x08
00007dd8c99d5527  jmp 0x00007DD8C99D02F7
00007dd8c99d552c  sub rsp, 0x08
00007dd8c99d5530  push rax
00007dd8c99d5531  push rcx
00007dd8c99d5532  push rdx
00007dd8c99d5533  push rdi
00007dd8c99d5534  push rsi
00007dd8c99d5535  push r8
00007dd8c99d5537  push r9
00007dd8c99d5539  push r10
00007dd8c99d553b  push r11
00007dd8c99d553d  sub rsp, 0xF0
00007dd8c99d5544  vmovaps [rsp], xmm0
00007dd8c99d5549  vmovaps [rsp+0x10], xmm1
00007dd8c99d554f  vmovaps [rsp+0x20], xmm2
00007dd8c99d5555  vmovaps [rsp+0x30], xmm3
00007dd8c99d555b  vmovaps [rsp+0x40], xmm4
00007dd8c99d5561  vmovaps [rsp+0x50], xmm5
00007dd8c99d5567  vmovaps [rsp+0x60], xmm6
00007dd8c99d556d  vmovaps [rsp+0x70], xmm7
00007dd8c99d5573  vmovaps [rsp+0x80], xmm8
00007dd8c99d557c  vmovaps [rsp+0x90], xmm9
00007dd8c99d5585  vmovaps [rsp+0xA0], xmm10
00007dd8c99d558e  vmovaps [rsp+0xB0], xmm11
00007dd8c99d5597  vmovaps [rsp+0xC0], xmm12
00007dd8c99d55a0  vmovaps [rsp+0xD0], xmm13
00007dd8c99d55a9  vmovaps [rsp+0xE0], xmm15
00007dd8c99d55b2  sub rsp, 0x30
00007dd8c99d55b6  movaps [rsp], xmm14
00007dd8c99d55bb  movaps [rsp+0x10], xmm1
00007dd8c99d55c0  movaps [rsp+0x20], xmm10
00007dd8c99d55c6  lea rdi, [rsp]
00007dd8c99d55ca  mov esi, 0x00
00007dd8c99d55cf  mov rax, 0x55FEBBDB5530
00007dd8c99d55d9  call rax
00007dd8c99d55db  movaps xmm14, [rsp]
00007dd8c99d55e0  add rsp, 0x30
00007dd8c99d55e4  vmovaps xmm0, [rsp]
00007dd8c99d55e9  vmovaps xmm1, [rsp+0x10]
00007dd8c99d55ef  vmovaps xmm2, [rsp+0x20]
00007dd8c99d55f5  vmovaps xmm3, [rsp+0x30]
00007dd8c99d55fb  vmovaps xmm4, [rsp+0x40]
00007dd8c99d5601  vmovaps xmm5, [rsp+0x50]
00007dd8c99d5607  vmovaps xmm6, [rsp+0x60]
00007dd8c99d560d  vmovaps xmm7, [rsp+0x70]
00007dd8c99d5613  vmovaps xmm8, [rsp+0x80]
00007dd8c99d561c  vmovaps xmm9, [rsp+0x90]
00007dd8c99d5625  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d562e  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d5637  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d5640  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d5649  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d5652  add rsp, 0xF0
00007dd8c99d5659  pop r11
00007dd8c99d565b  pop r10
00007dd8c99d565d  pop r9
00007dd8c99d565f  pop r8
00007dd8c99d5661  pop rsi
00007dd8c99d5662  pop rdi
00007dd8c99d5663  pop rdx
00007dd8c99d5664  pop rcx
00007dd8c99d5665  pop rax
00007dd8c99d5666  add rsp, 0x08
00007dd8c99d566a  jmp 0x00007DD8C99D031A
00007dd8c99d566f  sub rsp, 0x08
00007dd8c99d5673  push rax
00007dd8c99d5674  push rcx
00007dd8c99d5675  push rdx
00007dd8c99d5676  push rdi
00007dd8c99d5677  push rsi
00007dd8c99d5678  push r8
00007dd8c99d567a  push r9
00007dd8c99d567c  push r10
00007dd8c99d567e  push r11
00007dd8c99d5680  sub rsp, 0xF0
00007dd8c99d5687  vmovaps [rsp], xmm0
00007dd8c99d568c  vmovaps [rsp+0x10], xmm2
00007dd8c99d5692  vmovaps [rsp+0x20], xmm3
00007dd8c99d5698  vmovaps [rsp+0x30], xmm4
00007dd8c99d569e  vmovaps [rsp+0x40], xmm5
00007dd8c99d56a4  vmovaps [rsp+0x50], xmm6
00007dd8c99d56aa  vmovaps [rsp+0x60], xmm7
00007dd8c99d56b0  vmovaps [rsp+0x70], xmm8
00007dd8c99d56b6  vmovaps [rsp+0x80], xmm9
00007dd8c99d56bf  vmovaps [rsp+0x90], xmm10
00007dd8c99d56c8  vmovaps [rsp+0xA0], xmm11
00007dd8c99d56d1  vmovaps [rsp+0xB0], xmm12
00007dd8c99d56da  vmovaps [rsp+0xC0], xmm13
00007dd8c99d56e3  vmovaps [rsp+0xD0], xmm14
00007dd8c99d56ec  vmovaps [rsp+0xE0], xmm15
00007dd8c99d56f5  sub rsp, 0x30
00007dd8c99d56f9  movaps [rsp], xmm1
00007dd8c99d56fd  movaps [rsp+0x10], xmm7
00007dd8c99d5702  movaps [rsp+0x20], xmm11
00007dd8c99d5708  lea rdi, [rsp]
00007dd8c99d570c  mov esi, 0x00
00007dd8c99d5711  mov rax, 0x55FEBBDB5530
00007dd8c99d571b  call rax
00007dd8c99d571d  movaps xmm1, [rsp]
00007dd8c99d5721  add rsp, 0x30
00007dd8c99d5725  vmovaps xmm0, [rsp]
00007dd8c99d572a  vmovaps xmm2, [rsp+0x10]
00007dd8c99d5730  vmovaps xmm3, [rsp+0x20]
00007dd8c99d5736  vmovaps xmm4, [rsp+0x30]
00007dd8c99d573c  vmovaps xmm5, [rsp+0x40]
00007dd8c99d5742  vmovaps xmm6, [rsp+0x50]
00007dd8c99d5748  vmovaps xmm7, [rsp+0x60]
00007dd8c99d574e  vmovaps xmm8, [rsp+0x70]
00007dd8c99d5754  vmovaps xmm9, [rsp+0x80]
00007dd8c99d575d  vmovaps xmm10, [rsp+0x90]
00007dd8c99d5766  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d576f  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d5778  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d5781  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d578a  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d5793  add rsp, 0xF0
00007dd8c99d579a  pop r11
00007dd8c99d579c  pop r10
00007dd8c99d579e  pop r9
00007dd8c99d57a0  pop r8
00007dd8c99d57a2  pop rsi
00007dd8c99d57a3  pop rdi
00007dd8c99d57a4  pop rdx
00007dd8c99d57a5  pop rcx
00007dd8c99d57a6  pop rax
00007dd8c99d57a7  add rsp, 0x08
00007dd8c99d57ab  jmp 0x00007DD8C99D033B
00007dd8c99d57b0  call 0x00007DD8C980E880
00007dd8c99d57b5  jmp 0x00007DD8C99D034E
00007dd8c99d57ba  call 0x00007DD8C980C380
00007dd8c99d57bf  jmp 0x00007DD8C99D0359
00007dd8c99d57c4  call 0x00007DD8C980D600
00007dd8c99d57c9  jmp 0x00007DD8C99D0364
00007dd8c99d57ce  call 0x00007DD8C97FF540
00007dd8c99d57d3  jmp 0x00007DD8C99D036F
00007dd8c99d57d8  int3
00007dd8c99d57d9  nop [rax], eax
00007dd8c99d57e0  mov rax, [r15+0x40]
00007dd8c99d57e4  mov r14, [r15+0x58]
00007dd8c99d57e8  lea r12, [rax+r14*1]
00007dd8c99d57ec  movaps xmm1, [r15+0x1D0]
00007dd8c99d57f4  vmovaps [rsp+0x10], xmm1
00007dd8c99d57fa  vmovaps xmm15, [rsp+0x10]
00007dd8c99d5800  por xmm1, xmm15
00007dd8c99d5805  movaps xmm14, [r15+0x1A0]
00007dd8c99d580d  vmovaps [rsp+0x10], xmm14
00007dd8c99d5813  vmovaps xmm13, [rsp+0x10]
00007dd8c99d5819  por xmm14, xmm13
00007dd8c99d581e  lea rax, [r12+0x30]
00007dd8c99d5823  mov r11, [r13+rax*1]
00007dd8c99d5828  lea rax, [r12+0x38]
00007dd8c99d582d  mov r10, [r13+rax*1]
00007dd8c99d5832  movq xmm13, r11
00007dd8c99d5837  movq xmm12, r10
00007dd8c99d583c  movq xmm13, xmm13
00007dd8c99d5841  vmovaps [rsp+0x10], xmm13
00007dd8c99d5847  movq xmm13, xmm13
00007dd8c99d584c  movaps [r15+0x130], xmm13
00007dd8c99d5854  movq xmm12, xmm12
00007dd8c99d5859  vmovaps [rsp+0x20], xmm12
00007dd8c99d585f  movq xmm12, xmm12
00007dd8c99d5864  movaps [r15+0x280], xmm12
00007dd8c99d586c  movaps xmm13, [r15+0x270]
00007dd8c99d5874  vmovaps [rsp+0x30], xmm13
00007dd8c99d587a  vmovaps xmm12, [rsp+0x30]
00007dd8c99d5880  por xmm13, xmm12
00007dd8c99d5885  lea rax, [r12+0x20]
00007dd8c99d588a  mov r11, [r13+rax*1]
00007dd8c99d588f  lea rax, [r12+0x28]
00007dd8c99d5894  mov r10, [r13+rax*1]
00007dd8c99d5899  movq xmm12, r11
00007dd8c99d589e  movq xmm11, r10
00007dd8c99d58a3  movq xmm12, xmm12
00007dd8c99d58a8  vmovaps [rsp+0x30], xmm12
00007dd8c99d58ae  movq xmm12, xmm12
00007dd8c99d58b3  movaps [r15+0x150], xmm12
00007dd8c99d58bb  movq xmm11, xmm11
00007dd8c99d58c0  vmovaps [rsp+0x40], xmm11
00007dd8c99d58c6  movq xmm11, xmm11
00007dd8c99d58cb  movaps [r15+0x140], xmm11
00007dd8c99d58d3  lea rax, [r12+0x10]
00007dd8c99d58d8  mov r11, [r13+rax*1]
00007dd8c99d58dd  lea rax, [r12+0x18]
00007dd8c99d58e2  mov r10, [r13+rax*1]
00007dd8c99d58e7  movq xmm12, r11
00007dd8c99d58ec  movq xmm11, r10
00007dd8c99d58f1  movq xmm12, xmm12
00007dd8c99d58f6  vmovaps [rsp+0x50], xmm12
00007dd8c99d58fc  movq xmm12, xmm12
00007dd8c99d5901  movaps [r15+0x170], xmm12
00007dd8c99d5909  movq xmm11, xmm11
00007dd8c99d590e  vmovaps [rsp+0x60], xmm11
00007dd8c99d5914  movq xmm11, xmm11
00007dd8c99d5919  movaps [r15+0x160], xmm11
00007dd8c99d5921  mov rax, [r13+r12*1]
00007dd8c99d5926  vmovq xmm12, rax
00007dd8c99d592b  vpbroadcastq xmm12, xmm12
00007dd8c99d5930  lea rax, [r12+0x08]
00007dd8c99d5935  mov r12, [r13+rax*1]
00007dd8c99d593a  movq xmm11, r12
00007dd8c99d593f  movaps [r15+0x230], xmm11
00007dd8c99d5947  mov rax, [r15+0xF8]
00007dd8c99d594e  lea r12, [rax+0x50]
00007dd8c99d5952  movups xmm11, [r13+r12*1]
00007dd8c99d5958  lea r12, [rax+0x60]
00007dd8c99d595c  movups xmm10, [r13+r12*1]
00007dd8c99d5962  lea r12, [rax+0x30]
00007dd8c99d5966  movups xmm9, [r13+r12*1]
00007dd8c99d596c  mov r12, [r15+0x50]
00007dd8c99d5970  lea r11, [r12+r14*1]
00007dd8c99d5974  mov [r15+0x60], r11
00007dd8c99d5978  lea r12, [r14+0x40]
00007dd8c99d597c  mov [r15+0x58], r12
00007dd8c99d5980  movaps xmm8, xmm12
00007dd8c99d5984  mulpd xmm8, xmm15
00007dd8c99d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd8c99d598f  ptest xmm7, xmm7
00007dd8c99d5994  jnz 0x00007DD8C99D67B7
00007dd8c99d599a  movq xmm15, qword ptr [r15+0x230]
00007dd8c99d59a3  vmovaps [rsp+0x70], xmm15
00007dd8c99d59a9  vpermilpd xmm15, xmm15, 0x00
00007dd8c99d59af  movaps xmm7, xmm9
00007dd8c99d59b3  mulpd xmm7, xmm15
00007dd8c99d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8c99d59bd  ptest xmm6, xmm6
00007dd8c99d59c2  jnz 0x00007DD8C99D68FB
00007dd8c99d59c8  vxorps xmm15, xmm15, xmm15
00007dd8c99d59cd  vpbroadcastq xmm15, xmm15
00007dd8c99d59d2  movaps xmm9, xmm12
00007dd8c99d59d6  mulpd xmm9, xmm10
00007dd8c99d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd8c99d59e1  ptest xmm6, xmm6
00007dd8c99d59e6  jnz 0x00007DD8C99D6A3D
00007dd8c99d59ec  movaps xmm10, xmm12
00007dd8c99d59f0  mulpd xmm10, xmm11
00007dd8c99d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007dd8c99d59fb  ptest xmm6, xmm6
00007dd8c99d5a00  jnz 0x00007DD8C99D6B81
00007dd8c99d5a06  movaps xmm11, [r15+0x1F0]
00007dd8c99d5a0e  movaps xmm6, xmm12
00007dd8c99d5a12  mulpd xmm6, xmm11
00007dd8c99d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd8c99d5a1c  ptest xmm5, xmm5
00007dd8c99d5a21  jnz 0x00007DD8C99D6CC5
00007dd8c99d5a27  movaps xmm12, [r15+0x2A0]
00007dd8c99d5a2f  vmovaps [rsp+0x80], xmm12
00007dd8c99d5a38  vmovaps xmm11, [rsp+0x80]
00007dd8c99d5a41  por xmm12, xmm11
00007dd8c99d5a46  movaps xmm11, [r15+0x250]
00007dd8c99d5a4e  vmovaps [rsp+0x80], xmm11
00007dd8c99d5a57  vmovaps xmm5, [rsp+0x80]
00007dd8c99d5a60  por xmm11, xmm5
00007dd8c99d5a65  vmovaps xmm4, [rsp+0x70]
00007dd8c99d5a6b  vpermilpd xmm4, xmm4, 0x00
00007dd8c99d5a71  movaps xmm3, xmm5
00007dd8c99d5a74  mulpd xmm3, xmm4
00007dd8c99d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007dd8c99d5a7d  ptest xmm2, xmm2
00007dd8c99d5a82  jnz 0x00007DD8C99D6E07
00007dd8c99d5a88  mov [rsp+0x80], rax
00007dd8c99d5a90  xor eax, eax
00007dd8c99d5a92  mov r14d, 0x200
00007dd8c99d5a98  cmp r12, r14
00007dd8c99d5a9b  cmc
00007dd8c99d5a9c  lahf
00007dd8c99d5a9d  seto al
00007dd8c99d5aa0  mov [r15+0x108], eax
00007dd8c99d5aa7  movaps xmm5, xmm8
00007dd8c99d5aab  addpd xmm5, xmm15
00007dd8c99d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007dd8c99d5ab5  ptest xmm4, xmm4
00007dd8c99d5aba  jnz 0x00007DD8C99D6F47
00007dd8c99d5ac0  movaps xmm8, [r15+0x1B0]
00007dd8c99d5ac8  movaps xmm4, xmm9
00007dd8c99d5acc  addpd xmm4, xmm8
00007dd8c99d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007dd8c99d5ad6  ptest xmm2, xmm2
00007dd8c99d5adb  jnz 0x00007DD8C99D7089
00007dd8c99d5ae1  movaps xmm9, xmm10
00007dd8c99d5ae5  addpd xmm9, xmm8
00007dd8c99d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007dd8c99d5af0  ptest xmm2, xmm2
00007dd8c99d5af5  jnz 0x00007DD8C99D71CB
00007dd8c99d5afb  movaps xmm10, [r15+0x2F0]
00007dd8c99d5b03  vmovaps [rsp+0x90], xmm10
00007dd8c99d5b0c  vmovaps xmm8, [rsp+0x90]
00007dd8c99d5b15  por xmm10, xmm8
00007dd8c99d5b1a  movaps xmm8, [r15+0x2E0]
00007dd8c99d5b22  vmovaps [rsp+0x90], xmm8
00007dd8c99d5b2b  vmovaps xmm2, [rsp+0x90]
00007dd8c99d5b34  por xmm8, xmm2
00007dd8c99d5b39  movaps xmm2, [r15+0x2D0]
00007dd8c99d5b41  vmovaps [rsp+0x90], xmm2
00007dd8c99d5b4a  vmovaps [rsp+0xA0], xmm1
00007dd8c99d5b53  vmovaps xmm1, [rsp+0x90]
00007dd8c99d5b5c  por xmm2, xmm1
00007dd8c99d5b60  movaps xmm1, [r15+0x200]
00007dd8c99d5b68  vmovaps [rsp+0x90], xmm1
00007dd8c99d5b71  vmovaps [rsp+0xB0], xmm15
00007dd8c99d5b7a  vmovaps xmm15, [rsp+0x90]
00007dd8c99d5b83  por xmm1, xmm15
00007dd8c99d5b88  movaps xmm15, [r15+0x1C0]
00007dd8c99d5b90  vmovaps [rsp+0x90], xmm15
00007dd8c99d5b99  vmovaps [rsp+0xC0], xmm1
00007dd8c99d5ba2  vmovaps xmm1, [rsp+0x90]
00007dd8c99d5bab  por xmm15, xmm1
00007dd8c99d5bb0  movaps xmm1, [r15+0x190]
00007dd8c99d5bb8  vmovaps [rsp+0x90], xmm1
00007dd8c99d5bc1  vmovaps [rsp+0xD0], xmm15
00007dd8c99d5bca  vmovaps xmm15, [rsp+0x90]
00007dd8c99d5bd3  por xmm1, xmm15
00007dd8c99d5bd8  movaps xmm15, [r15+0x300]
00007dd8c99d5be0  vmovaps [rsp+0x90], xmm15
00007dd8c99d5be9  vmovaps [rsp+0xE0], xmm1
00007dd8c99d5bf2  vmovaps xmm1, [rsp+0x90]
00007dd8c99d5bfb  por xmm15, xmm1
00007dd8c99d5c00  mov rax, [rsp+0x80]
00007dd8c99d5c08  lea r14, [rax+0xA0]
00007dd8c99d5c0f  movups xmm1, [r13+r14*1]
00007dd8c99d5c15  lea r14, [rax+0xB0]
00007dd8c99d5c1c  vmovaps [rsp+0x80], xmm1
00007dd8c99d5c25  movups xmm1, [r13+r14*1]
00007dd8c99d5c2b  vmovaps [rsp+0x90], xmm1
00007dd8c99d5c34  vmovaps [rsp+0xF0], xmm15
00007dd8c99d5c3d  vmovaps xmm15, [rsp+0xB0]
00007dd8c99d5c46  vmovaps [rsp+0xB0], xmm14
00007dd8c99d5c4f  movaps xmm1, xmm6
00007dd8c99d5c52  addpd xmm1, xmm15
00007dd8c99d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd8c99d5c5c  ptest xmm14, xmm14
00007dd8c99d5c62  jnz 0x00007DD8C99D7323
00007dd8c99d5c68  lea r14, [rax+0xF0]
00007dd8c99d5c6f  movups xmm15, [r13+r14*1]
00007dd8c99d5c75  movaps xmm14, xmm4
00007dd8c99d5c79  addpd xmm14, xmm3
00007dd8c99d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007dd8c99d5c84  ptest xmm6, xmm6
00007dd8c99d5c89  jnz 0x00007DD8C99D746E
00007dd8c99d5c8f  movaps xmm6, xmm9
00007dd8c99d5c93  addpd xmm6, xmm7
00007dd8c99d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007dd8c99d5c9c  ptest xmm4, xmm4
00007dd8c99d5ca1  jnz 0x00007DD8C99D75B0
00007dd8c99d5ca7  vmovaps xmm9, [rsp+0x70]
00007dd8c99d5cad  vpermilpd xmm9, xmm9, 0x00
00007dd8c99d5cb3  vmovaps xmm4, [rsp+0x90]
00007dd8c99d5cbc  movaps xmm7, xmm4
00007dd8c99d5cbf  mulpd xmm7, xmm9
00007dd8c99d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007dd8c99d5cc9  ptest xmm3, xmm3
00007dd8c99d5cce  jnz 0x00007DD8C99D76F1
00007dd8c99d5cd4  vmovaps xmm9, [rsp+0x50]
00007dd8c99d5cda  vpermilpd xmm9, xmm9, 0x00
00007dd8c99d5ce0  movaps xmm4, xmm15
00007dd8c99d5ce4  mulpd xmm4, xmm9
00007dd8c99d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007dd8c99d5cee  ptest xmm3, xmm3
00007dd8c99d5cf3  jnz 0x00007DD8C99D7832
00007dd8c99d5cf9  lea r14, [rax+0xE0]
00007dd8c99d5d00  movups xmm15, [r13+r14*1]
00007dd8c99d5d06  vmovaps xmm9, [rsp+0x70]
00007dd8c99d5d0c  vpermilpd xmm9, xmm9, 0x00
00007dd8c99d5d12  vmovaps [rsp+0x70], xmm1
00007dd8c99d5d18  vmovaps xmm1, [rsp+0x80]
00007dd8c99d5d21  vmovaps [rsp+0x80], xmm15
00007dd8c99d5d2a  movaps xmm3, xmm1
00007dd8c99d5d2d  mulpd xmm3, xmm9
00007dd8c99d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007dd8c99d5d37  ptest xmm15, xmm15
00007dd8c99d5d3d  jnz 0x00007DD8C99D797E
00007dd8c99d5d43  vmovaps xmm1, [rsp+0xF0]
00007dd8c99d5d4c  vmovaps xmm15, [rsp+0xF0]
00007dd8c99d5d55  por xmm1, xmm15
00007dd8c99d5d5a  movaps [r15+0x300], xmm1
00007dd8c99d5d62  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d5d6b  vmovaps xmm9, [rsp+0xE0]
00007dd8c99d5d74  por xmm15, xmm9
00007dd8c99d5d79  movaps [r15+0x190], xmm15
00007dd8c99d5d81  vmovaps xmm9, [rsp+0x50]
00007dd8c99d5d87  vpermilpd xmm9, xmm9, 0x00
00007dd8c99d5d8d  vmovaps [rsp+0x90], xmm1
00007dd8c99d5d96  vmovaps [rsp+0xE0], xmm15
00007dd8c99d5d9f  vmovaps xmm15, [rsp+0x80]
00007dd8c99d5da8  vmovaps [rsp+0x80], xmm14
00007dd8c99d5db1  movaps xmm1, xmm15
00007dd8c99d5db5  mulpd xmm1, xmm9
00007dd8c99d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd8c99d5dbf  ptest xmm14, xmm14
00007dd8c99d5dc5  jnz 0x00007DD8C99D7ABF
00007dd8c99d5dcb  lea r14, [rax+0x90]
00007dd8c99d5dd2  movups xmm15, [r13+r14*1]
00007dd8c99d5dd8  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d5de1  vmovaps xmm9, [rsp+0xD0]
00007dd8c99d5dea  por xmm14, xmm9
00007dd8c99d5def  movaps [r15+0x1C0], xmm14
00007dd8c99d5df7  vmovaps xmm9, [rsp+0xC0]
00007dd8c99d5e00  vmovaps [rsp+0xD0], xmm1
00007dd8c99d5e09  vmovaps xmm1, [rsp+0xC0]
00007dd8c99d5e12  por xmm9, xmm1
00007dd8c99d5e17  movaps [r15+0x200], xmm9
00007dd8c99d5e1f  vmovaps [rsp+0xC0], xmm2
00007dd8c99d5e28  vmovaps xmm1, [rsp+0xC0]
00007dd8c99d5e31  por xmm2, xmm1
00007dd8c99d5e35  movaps [r15+0x2D0], xmm2
00007dd8c99d5e3d  vmovaps [rsp+0xC0], xmm8
00007dd8c99d5e46  vmovaps xmm1, [rsp+0xC0]
00007dd8c99d5e4f  por xmm8, xmm1
00007dd8c99d5e54  movaps [r15+0x2E0], xmm8
00007dd8c99d5e5c  vmovaps [rsp+0xC0], xmm15
00007dd8c99d5e65  movaps xmm1, xmm5
00007dd8c99d5e68  addpd xmm1, xmm7
00007dd8c99d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd8c99d5e71  ptest xmm15, xmm15
00007dd8c99d5e77  jnz 0x00007DD8C99D7C0B
00007dd8c99d5e7d  vmovaps xmm15, [rsp+0x50]
00007dd8c99d5e83  vpermilpd xmm15, xmm15, 0x00
00007dd8c99d5e89  vmovaps xmm5, [rsp+0xC0]
00007dd8c99d5e92  vmovaps [rsp+0xC0], xmm1
00007dd8c99d5e9b  movaps xmm7, xmm5
00007dd8c99d5e9e  mulpd xmm7, xmm15
00007dd8c99d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007dd8c99d5ea8  ptest xmm1, xmm1
00007dd8c99d5ead  jnz 0x00007DD8C99D7D4B
00007dd8c99d5eb3  lea r14, [rax+0x80]
00007dd8c99d5eba  movups xmm1, [r13+r14*1]
00007dd8c99d5ec0  vmovaps xmm5, [rsp+0x70]
00007dd8c99d5ec6  vmovaps [rsp+0x70], xmm1
00007dd8c99d5ecc  movaps xmm15, xmm5
00007dd8c99d5ed0  addpd xmm15, xmm3
00007dd8c99d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8c99d5edb  ptest xmm1, xmm1
00007dd8c99d5ee0  jnz 0x00007DD8C99D7E96
00007dd8c99d5ee6  vmovaps xmm5, [rsp+0x80]
00007dd8c99d5eef  movaps xmm1, xmm5
00007dd8c99d5ef2  addpd xmm1, xmm4
00007dd8c99d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007dd8c99d5efb  ptest xmm3, xmm3
00007dd8c99d5f00  jnz 0x00007DD8C99D7FD8
00007dd8c99d5f06  vmovaps [rsp+0x80], xmm10
00007dd8c99d5f0f  vmovaps xmm5, [rsp+0x80]
00007dd8c99d5f18  por xmm10, xmm5
00007dd8c99d5f1d  movaps [r15+0x2F0], xmm10
00007dd8c99d5f25  vmovaps xmm5, [rsp+0x50]
00007dd8c99d5f2b  vpermilpd xmm5, xmm5, 0x00
00007dd8c99d5f31  vmovaps xmm3, [rsp+0x70]
00007dd8c99d5f37  vmovaps [rsp+0x50], xmm1
00007dd8c99d5f3d  movaps xmm4, xmm3
00007dd8c99d5f40  mulpd xmm4, xmm5
00007dd8c99d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007dd8c99d5f49  ptest xmm1, xmm1
00007dd8c99d5f4e  jnz 0x00007DD8C99D8118
00007dd8c99d5f54  lea r14, [rax+0xD0]
00007dd8c99d5f5b  movups xmm1, [r13+r14*1]
00007dd8c99d5f61  vmovaps xmm3, [rsp+0xD0]
00007dd8c99d5f6a  vmovaps [rsp+0x70], xmm1
00007dd8c99d5f70  movaps xmm5, xmm6
00007dd8c99d5f73  addpd xmm5, xmm3
00007dd8c99d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007dd8c99d5f7c  ptest xmm1, xmm1
00007dd8c99d5f81  jnz 0x00007DD8C99D8262
00007dd8c99d5f87  vmovaps xmm1, [rsp+0x60]
00007dd8c99d5f8d  vpermilpd xmm1, xmm1, 0x00
00007dd8c99d5f93  movaps xmm6, xmm9
00007dd8c99d5f97  mulpd xmm6, xmm1
00007dd8c99d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007dd8c99d5fa0  ptest xmm3, xmm3
00007dd8c99d5fa5  jnz 0x00007DD8C99D83A2
00007dd8c99d5fab  movaps [r15+0x260], xmm6
00007dd8c99d5fb3  vxorps xmm1, xmm1, xmm1
00007dd8c99d5fb7  vpbroadcastq xmm1, xmm1
00007dd8c99d5fbc  movaps [r15+0x1B0], xmm1
00007dd8c99d5fc4  vmovaps xmm1, [rsp+0x60]
00007dd8c99d5fca  vpermilpd xmm1, xmm1, 0x00
00007dd8c99d5fd0  vmovaps xmm3, [rsp+0x70]
00007dd8c99d5fd6  vmovaps [rsp+0x70], xmm15
00007dd8c99d5fdc  movaps xmm9, xmm3
00007dd8c99d5fe0  mulpd xmm9, xmm1
00007dd8c99d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007dd8c99d5feb  ptest xmm15, xmm15
00007dd8c99d5ff1  jnz 0x00007DD8C99D84E3
00007dd8c99d5ff7  lea r14, [rax+0xC0]
00007dd8c99d5ffe  movups xmm1, [r13+r14*1]
00007dd8c99d6004  vmovaps xmm3, [rsp+0xC0]
00007dd8c99d600d  vmovaps [rsp+0x80], xmm1
00007dd8c99d6016  movaps xmm15, xmm3
00007dd8c99d601a  addpd xmm15, xmm7
00007dd8c99d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8c99d6025  ptest xmm1, xmm1
00007dd8c99d602a  jnz 0x00007DD8C99D862F
00007dd8c99d6030  vmovaps [rsp+0xC0], xmm13
00007dd8c99d6039  vmovaps xmm1, [rsp+0xC0]
00007dd8c99d6042  por xmm13, xmm1
00007dd8c99d6047  movaps [r15+0x270], xmm13
00007dd8c99d604f  vmovaps xmm1, [rsp+0xB0]
00007dd8c99d6058  vmovaps xmm7, [rsp+0xB0]
00007dd8c99d6061  por xmm1, xmm7
00007dd8c99d6065  movaps [r15+0x1A0], xmm1
00007dd8c99d606d  vmovaps xmm1, [rsp+0x60]
00007dd8c99d6073  vpermilpd xmm1, xmm1, 0x00
00007dd8c99d6079  vmovaps [rsp+0xB0], xmm1
00007dd8c99d6082  vmovaps xmm1, [rsp+0x80]
00007dd8c99d608b  vmovaps [rsp+0x80], xmm15
00007dd8c99d6094  vmovaps xmm15, [rsp+0xB0]
00007dd8c99d609d  vmovaps [rsp+0xB0], xmm14
00007dd8c99d60a6  movaps xmm3, xmm1
00007dd8c99d60a9  mulpd xmm3, xmm15
00007dd8c99d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007dd8c99d60b3  ptest xmm14, xmm14
00007dd8c99d60b9  jnz 0x00007DD8C99D8771
00007dd8c99d60bf  lea r14, [rax+0x20]
00007dd8c99d60c3  movups xmm1, [r13+r14*1]
00007dd8c99d60c9  movaps [r15+0x110], xmm1
00007dd8c99d60d1  vmovaps xmm14, [rsp+0x70]
00007dd8c99d60d7  vmovaps [rsp+0x70], xmm1
00007dd8c99d60dd  movaps xmm15, xmm14
00007dd8c99d60e1  addpd xmm15, xmm4
00007dd8c99d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8c99d60ec  ptest xmm1, xmm1
00007dd8c99d60f1  jnz 0x00007DD8C99D88BC
00007dd8c99d60f7  vmovaps xmm1, [rsp+0x60]
00007dd8c99d60fd  vpermilpd xmm1, xmm1, 0x00
00007dd8c99d6103  movaps xmm14, xmm2
00007dd8c99d6107  mulpd xmm14, xmm1
00007dd8c99d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007dd8c99d6112  ptest xmm4, xmm4
00007dd8c99d6117  jnz 0x00007DD8C99D89FF
00007dd8c99d611d  vmovaps xmm4, [rsp+0x50]
00007dd8c99d6123  movaps xmm1, xmm4
00007dd8c99d6126  addpd xmm1, xmm9
00007dd8c99d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd8c99d6130  ptest xmm2, xmm2
00007dd8c99d6135  jnz 0x00007DD8C99D8B41
00007dd8c99d613b  vmovaps xmm9, [rsp+0x30]
00007dd8c99d6141  vpermilpd xmm9, xmm9, 0x00
00007dd8c99d6147  vmovaps xmm2, [rsp+0x70]
00007dd8c99d614d  vmovaps [rsp+0x50], xmm1
00007dd8c99d6153  movaps xmm4, xmm2
00007dd8c99d6156  mulpd xmm4, xmm9
00007dd8c99d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007dd8c99d6160  ptest xmm1, xmm1
00007dd8c99d6165  jnz 0x00007DD8C99D8C82
00007dd8c99d616b  vmovaps xmm1, [rsp+0x30]
00007dd8c99d6171  vpermilpd xmm1, xmm1, 0x00
00007dd8c99d6177  vmovaps xmm2, [rsp+0x90]
00007dd8c99d6180  vmovaps [rsp+0x60], xmm15
00007dd8c99d6186  movaps xmm9, xmm2
00007dd8c99d618a  mulpd xmm9, xmm1
00007dd8c99d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007dd8c99d6195  ptest xmm15, xmm15
00007dd8c99d619b  jnz 0x00007DD8C99D8DC3
00007dd8c99d61a1  vmovaps xmm15, [rsp+0x80]
00007dd8c99d61aa  movaps xmm1, xmm15
00007dd8c99d61ae  addpd xmm1, xmm6
00007dd8c99d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd8c99d61b7  ptest xmm2, xmm2
00007dd8c99d61bc  jnz 0x00007DD8C99D8F05
00007dd8c99d61c2  movaps xmm15, xmm5
00007dd8c99d61c6  addpd xmm15, xmm3
00007dd8c99d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007dd8c99d61d1  ptest xmm6, xmm6
00007dd8c99d61d6  jnz 0x00007DD8C99D9046
00007dd8c99d61dc  vmovaps xmm6, [rsp+0x30]
00007dd8c99d61e2  vpermilpd xmm6, xmm6, 0x00
00007dd8c99d61e8  movaps xmm5, xmm8
00007dd8c99d61ec  mulpd xmm5, xmm6
00007dd8c99d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007dd8c99d61f5  ptest xmm3, xmm3
00007dd8c99d61fa  jnz 0x00007DD8C99D9188
00007dd8c99d6200  vmovaps xmm8, [rsp+0x30]
00007dd8c99d6206  vpermilpd xmm8, xmm8, 0x00
00007dd8c99d620c  movaps xmm6, xmm10
00007dd8c99d6210  mulpd xmm6, xmm8
00007dd8c99d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007dd8c99d621a  ptest xmm3, xmm3
00007dd8c99d621f  jnz 0x00007DD8C99D92C9
00007dd8c99d6225  vmovaps xmm8, [rsp+0x60]
00007dd8c99d622b  movaps xmm10, xmm8
00007dd8c99d622f  addpd xmm10, xmm14
00007dd8c99d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007dd8c99d623a  ptest xmm3, xmm3
00007dd8c99d623f  jnz 0x00007DD8C99D940B
00007dd8c99d6245  vmovaps xmm8, [rsp+0x50]
00007dd8c99d624b  movaps xmm14, xmm8
00007dd8c99d624f  addpd xmm14, xmm4
00007dd8c99d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007dd8c99d625a  ptest xmm3, xmm3
00007dd8c99d625f  jnz 0x00007DD8C99D954F
00007dd8c99d6265  vmovaps xmm8, [rsp+0x40]
00007dd8c99d626b  vpermilpd xmm8, xmm8, 0x00
00007dd8c99d6271  movaps xmm4, xmm13
00007dd8c99d6275  mulpd xmm4, xmm8
00007dd8c99d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007dd8c99d627f  ptest xmm3, xmm3
00007dd8c99d6284  jnz 0x00007DD8C99D9692
00007dd8c99d628a  movaps xmm13, xmm15
00007dd8c99d628e  addpd xmm13, xmm9
00007dd8c99d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007dd8c99d6299  ptest xmm8, xmm8
00007dd8c99d629f  jnz 0x00007DD8C99D97D4
00007dd8c99d62a5  movaps xmm15, xmm1
00007dd8c99d62a9  addpd xmm15, xmm5
00007dd8c99d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007dd8c99d62b4  ptest xmm9, xmm9
00007dd8c99d62ba  jnz 0x00007DD8C99D9918
00007dd8c99d62c0  vmovaps [rsp+0x30], xmm11
00007dd8c99d62c6  vmovaps xmm1, [rsp+0x30]
00007dd8c99d62cc  por xmm11, xmm1
00007dd8c99d62d1  movaps [r15+0x250], xmm11
00007dd8c99d62d9  vmovaps [rsp+0x30], xmm12
00007dd8c99d62df  vmovaps xmm1, [rsp+0x30]
00007dd8c99d62e5  por xmm12, xmm1
00007dd8c99d62ea  movaps [r15+0x2A0], xmm12
00007dd8c99d62f2  vmovaps xmm1, [rsp+0xA0]
00007dd8c99d62fb  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d6304  por xmm1, xmm11
00007dd8c99d6309  movaps [r15+0x1D0], xmm1
00007dd8c99d6311  lea r14, [rax+0x40]
00007dd8c99d6315  movups xmm1, [r13+r14*1]
00007dd8c99d631b  movaps [r15+0x2C0], xmm1
00007dd8c99d6323  vmovaps xmm11, [rsp+0x40]
00007dd8c99d6329  vpermilpd xmm11, xmm11, 0x00
00007dd8c99d632f  vmovaps xmm8, [rsp+0xE0]
00007dd8c99d6338  movaps xmm9, xmm8
00007dd8c99d633c  mulpd xmm9, xmm11
00007dd8c99d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007dd8c99d6347  ptest xmm5, xmm5
00007dd8c99d634c  jnz 0x00007DD8C99D9A64
00007dd8c99d6352  movaps xmm11, xmm10
00007dd8c99d6356  addpd xmm11, xmm6
00007dd8c99d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007dd8c99d6361  ptest xmm8, xmm8
00007dd8c99d6367  jnz 0x00007DD8C99D9BA8
00007dd8c99d636d  movaps xmm10, xmm14
00007dd8c99d6371  addpd xmm10, xmm4
00007dd8c99d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007dd8c99d637c  ptest xmm8, xmm8
00007dd8c99d6382  jnz 0x00007DD8C99D9CEB
00007dd8c99d6388  vmovaps xmm14, [rsp+0x40]
00007dd8c99d638e  vpermilpd xmm14, xmm14, 0x00
00007dd8c99d6394  movaps xmm8, xmm1
00007dd8c99d6398  mulpd xmm8, xmm14
00007dd8c99d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd8c99d63a3  ptest xmm6, xmm6
00007dd8c99d63a8  jnz 0x00007DD8C99D9E2E
00007dd8c99d63ae  movaps xmm1, [r15+0x2B0]
00007dd8c99d63b6  vmovaps xmm14, [rsp+0x40]
00007dd8c99d63bc  vpermilpd xmm14, xmm14, 0x00
00007dd8c99d63c2  movaps xmm6, xmm1
00007dd8c99d63c5  mulpd xmm6, xmm14
00007dd8c99d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd8c99d63cf  ptest xmm5, xmm5
00007dd8c99d63d4  jnz 0x00007DD8C99D9F71
00007dd8c99d63da  vmovaps xmm1, [rsp+0x10]
00007dd8c99d63e0  vpermilpd xmm1, xmm1, 0x00
00007dd8c99d63e6  movaps xmm14, xmm12
00007dd8c99d63ea  mulpd xmm14, xmm1
00007dd8c99d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007dd8c99d63f5  ptest xmm5, xmm5
00007dd8c99d63fa  jnz 0x00007DD8C99DA0B2
00007dd8c99d6400  movaps xmm1, xmm13
00007dd8c99d6404  addpd xmm1, xmm9
00007dd8c99d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd8c99d640e  ptest xmm12, xmm12
00007dd8c99d6414  jnz 0x00007DD8C99DA1F5
00007dd8c99d641a  vmovaps xmm13, [rsp+0x10]
00007dd8c99d6420  vpermilpd xmm13, xmm13, 0x00
00007dd8c99d6426  movaps xmm12, xmm7
00007dd8c99d642a  mulpd xmm12, xmm13
00007dd8c99d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007dd8c99d6435  ptest xmm9, xmm9
00007dd8c99d643b  jnz 0x00007DD8C99DA337
00007dd8c99d6441  movaps xmm13, xmm15
00007dd8c99d6445  addpd xmm13, xmm8
00007dd8c99d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007dd8c99d6450  ptest xmm9, xmm9
00007dd8c99d6456  jnz 0x00007DD8C99DA47A
00007dd8c99d645c  movaps xmm15, [r15+0x290]
00007dd8c99d6464  vmovaps xmm9, [rsp+0x10]
00007dd8c99d646a  vpermilpd xmm9, xmm9, 0x00
00007dd8c99d6470  movaps xmm8, xmm15
00007dd8c99d6474  mulpd xmm8, xmm9
00007dd8c99d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd8c99d647f  ptest xmm7, xmm7
00007dd8c99d6484  jnz 0x00007DD8C99DA5BE
00007dd8c99d648a  movaps xmm15, xmm11
00007dd8c99d648e  addpd xmm15, xmm6
00007dd8c99d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007dd8c99d6499  ptest xmm9, xmm9
00007dd8c99d649f  jnz 0x00007DD8C99DA702
00007dd8c99d64a5  movaps xmm11, [r15+0x1E0]
00007dd8c99d64ad  vmovaps xmm9, [rsp+0x10]
00007dd8c99d64b3  vpermilpd xmm9, xmm9, 0x00
00007dd8c99d64b9  movaps xmm7, xmm11
00007dd8c99d64bd  mulpd xmm7, xmm9
00007dd8c99d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8c99d64c7  ptest xmm6, xmm6
00007dd8c99d64cc  jnz 0x00007DD8C99DA845
00007dd8c99d64d2  movaps xmm11, xmm10
00007dd8c99d64d6  addpd xmm11, xmm14
00007dd8c99d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007dd8c99d64e1  ptest xmm9, xmm9
00007dd8c99d64e7  jnz 0x00007DD8C99DA987
00007dd8c99d64ed  lea r14, [rax+0x70]
00007dd8c99d64f1  movups xmm14, [r13+r14*1]
00007dd8c99d64f7  movaps [r15+0x240], xmm14
00007dd8c99d64ff  movaps xmm10, xmm1
00007dd8c99d6503  addpd xmm10, xmm12
00007dd8c99d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007dd8c99d650e  ptest xmm9, xmm9
00007dd8c99d6514  jnz 0x00007DD8C99DAAD5
00007dd8c99d651a  movaps [r15+0x170], xmm10
00007dd8c99d6522  vmovaps xmm1, [rsp+0x20]
00007dd8c99d6528  vpermilpd xmm1, xmm1, 0x00
00007dd8c99d652e  movaps xmm12, xmm14
00007dd8c99d6532  mulpd xmm12, xmm1
00007dd8c99d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007dd8c99d653d  ptest xmm9, xmm9
00007dd8c99d6543  jnz 0x00007DD8C99DAC18
00007dd8c99d6549  vmovaps xmm1, [rsp+0x20]
00007dd8c99d654f  vpermilpd xmm1, xmm1, 0x00
00007dd8c99d6555  vmovaps xmm9, [rsp+0xB0]
00007dd8c99d655e  movaps xmm14, xmm9
00007dd8c99d6562  mulpd xmm14, xmm1
00007dd8c99d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007dd8c99d656d  ptest xmm6, xmm6
00007dd8c99d6572  jnz 0x00007DD8C99DAD5B
00007dd8c99d6578  movaps [r15+0x180], xmm14
00007dd8c99d6580  movaps xmm1, xmm13
00007dd8c99d6584  addpd xmm1, xmm8
00007dd8c99d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007dd8c99d658e  ptest xmm9, xmm9
00007dd8c99d6594  jnz 0x00007DD8C99DAE9E
00007dd8c99d659a  movaps [r15+0x210], xmm1
00007dd8c99d65a2  movups xmm13, [r13+rax*1]
00007dd8c99d65a8  lea r14, [rax+0x10]
00007dd8c99d65ac  movups xmm9, [r13+r14*1]
00007dd8c99d65b2  movaps [r15+0x230], xmm9
00007dd8c99d65ba  movaps xmm8, xmm15
00007dd8c99d65be  addpd xmm8, xmm7
00007dd8c99d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd8c99d65c9  ptest xmm6, xmm6
00007dd8c99d65ce  jnz 0x00007DD8C99DAFF4
00007dd8c99d65d4  movaps [r15+0x130], xmm8
00007dd8c99d65dc  vmovaps xmm15, [rsp+0x20]
00007dd8c99d65e2  vpermilpd xmm15, xmm15, 0x00
00007dd8c99d65e8  movaps xmm7, xmm9
00007dd8c99d65ec  mulpd xmm7, xmm15
00007dd8c99d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8c99d65f6  ptest xmm6, xmm6
00007dd8c99d65fb  jnz 0x00007DD8C99DB137
00007dd8c99d6601  movaps [r15+0x220], xmm7
00007dd8c99d6609  vmovaps xmm15, [rsp+0x20]
00007dd8c99d660f  vpermilpd xmm15, xmm15, 0x00
00007dd8c99d6615  movaps xmm9, xmm13
00007dd8c99d6619  mulpd xmm9, xmm15
00007dd8c99d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd8c99d6624  ptest xmm6, xmm6
00007dd8c99d6629  jnz 0x00007DD8C99DB279
00007dd8c99d662f  movaps xmm15, xmm11
00007dd8c99d6633  addpd xmm15, xmm12
00007dd8c99d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007dd8c99d663e  ptest xmm13, xmm13
00007dd8c99d6644  jnz 0x00007DD8C99DB3BD
00007dd8c99d664a  movaps [r15+0x140], xmm15
00007dd8c99d6652  movaps xmm13, xmm10
00007dd8c99d6656  addpd xmm13, xmm14
00007dd8c99d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007dd8c99d6661  ptest xmm12, xmm12
00007dd8c99d6667  jnz 0x00007DD8C99DB501
00007dd8c99d666d  movaps [r15+0x150], xmm13
00007dd8c99d6675  movaps xmm14, xmm1
00007dd8c99d6679  addpd xmm14, xmm7
00007dd8c99d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007dd8c99d6684  ptest xmm12, xmm12
00007dd8c99d668a  jnz 0x00007DD8C99DB645
00007dd8c99d6690  movaps [r15+0x160], xmm14
00007dd8c99d6698  movaps xmm1, xmm8
00007dd8c99d669c  addpd xmm1, xmm9
00007dd8c99d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd8c99d66a6  ptest xmm12, xmm12
00007dd8c99d66ac  jnz 0x00007DD8C99DB787
00007dd8c99d66b2  movaps [r15+0x120], xmm1
00007dd8c99d66ba  movups [r13+r11*1], xmm15
00007dd8c99d66c0  lea rax, [r11+0x10]
00007dd8c99d66c4  movups [r13+rax*1], xmm13
00007dd8c99d66ca  lea rax, [r11+0x20]
00007dd8c99d66ce  movups [r13+rax*1], xmm14
00007dd8c99d66d4  lea rax, [r11+0x30]
00007dd8c99d66d8  movups [r13+rax*1], xmm1
00007dd8c99d66de  mov eax, [r15+0x108]
00007dd8c99d66e5  sahf
00007dd8c99d66e6  jnz 0x00007DD8C99D6718
00007dd8c99d66e8  cmp dword ptr [r15+0x318], 0x00
00007dd8c99d66f0  jz 0x00007DD8C99DB900
00007dd8c99d66f6  nop [rax+rax*1], ax
00007dd8c99d66ff  nop [rax+rax*1], eax
00007dd8c99d6707  mov eax, 0x410444
00007dd8c99d670c  mov [r15+0x100], rax
00007dd8c99d6713  jmp 0x00007DD8C97FE110
00007dd8c99d6718  cmp dword ptr [r15+0x318], 0x00
00007dd8c99d6720  jz 0x00007DD8C99D57E0
00007dd8c99d6726  nop [rax+rax*1], ax
00007dd8c99d672f  nop [rax+rax*1], eax
00007dd8c99d6737  mov eax, 0x410278
00007dd8c99d673c  mov [r15+0x100], rax
00007dd8c99d6743  jmp 0x00007DD8C97FE110
00007dd8c99d6748  int3
00007dd8c99d6749  call 0x00007DD8C980A4B0
00007dd8c99d674e  jmp 0x00007DD8C99D5828
00007dd8c99d6753  call 0x00007DD8C9809240
00007dd8c99d6758  jmp 0x00007DD8C99D5832
00007dd8c99d675d  call 0x00007DD8C980A4B0
00007dd8c99d6762  jmp 0x00007DD8C99D588F
00007dd8c99d6767  call 0x00007DD8C9809240
00007dd8c99d676c  jmp 0x00007DD8C99D5899
00007dd8c99d6771  call 0x00007DD8C980A4B0
00007dd8c99d6776  jmp 0x00007DD8C99D58DD
00007dd8c99d677b  call 0x00007DD8C9809240
00007dd8c99d6780  jmp 0x00007DD8C99D58E7
00007dd8c99d6785  call 0x00007DD8C98B47C0
00007dd8c99d678a  jmp 0x00007DD8C99D5926
00007dd8c99d678f  call 0x00007DD8C980B720
00007dd8c99d6794  jmp 0x00007DD8C99D593A
00007dd8c99d6799  call 0x00007DD8C98BFC30
00007dd8c99d679e  jmp 0x00007DD8C99D5958
00007dd8c99d67a3  call 0x00007DD8C98BE9C0
00007dd8c99d67a8  jmp 0x00007DD8C99D5962
00007dd8c99d67ad  call 0x00007DD8C98BD750
00007dd8c99d67b2  jmp 0x00007DD8C99D596C
00007dd8c99d67b7  sub rsp, 0x08
00007dd8c99d67bb  push rax
00007dd8c99d67bc  push rcx
00007dd8c99d67bd  push rdx
00007dd8c99d67be  push rdi
00007dd8c99d67bf  push rsi
00007dd8c99d67c0  push r8
00007dd8c99d67c2  push r9
00007dd8c99d67c4  push r10
00007dd8c99d67c6  push r11
00007dd8c99d67c8  sub rsp, 0xF0
00007dd8c99d67cf  vmovaps [rsp], xmm0
00007dd8c99d67d4  vmovaps [rsp+0x10], xmm1
00007dd8c99d67da  vmovaps [rsp+0x20], xmm2
00007dd8c99d67e0  vmovaps [rsp+0x30], xmm3
00007dd8c99d67e6  vmovaps [rsp+0x40], xmm4
00007dd8c99d67ec  vmovaps [rsp+0x50], xmm5
00007dd8c99d67f2  vmovaps [rsp+0x60], xmm6
00007dd8c99d67f8  vmovaps [rsp+0x70], xmm7
00007dd8c99d67fe  vmovaps [rsp+0x80], xmm9
00007dd8c99d6807  vmovaps [rsp+0x90], xmm10
00007dd8c99d6810  vmovaps [rsp+0xA0], xmm11
00007dd8c99d6819  vmovaps [rsp+0xB0], xmm12
00007dd8c99d6822  vmovaps [rsp+0xC0], xmm13
00007dd8c99d682b  vmovaps [rsp+0xD0], xmm14
00007dd8c99d6834  vmovaps [rsp+0xE0], xmm15
00007dd8c99d683d  sub rsp, 0x30
00007dd8c99d6841  movaps [rsp], xmm8
00007dd8c99d6846  movaps [rsp+0x10], xmm12
00007dd8c99d684c  movaps [rsp+0x20], xmm15
00007dd8c99d6852  lea rdi, [rsp]
00007dd8c99d6856  mov esi, 0x00
00007dd8c99d685b  mov rax, 0x55FEBBDB5530
00007dd8c99d6865  call rax
00007dd8c99d6867  movaps xmm8, [rsp]
00007dd8c99d686c  add rsp, 0x30
00007dd8c99d6870  vmovaps xmm0, [rsp]
00007dd8c99d6875  vmovaps xmm1, [rsp+0x10]
00007dd8c99d687b  vmovaps xmm2, [rsp+0x20]
00007dd8c99d6881  vmovaps xmm3, [rsp+0x30]
00007dd8c99d6887  vmovaps xmm4, [rsp+0x40]
00007dd8c99d688d  vmovaps xmm5, [rsp+0x50]
00007dd8c99d6893  vmovaps xmm6, [rsp+0x60]
00007dd8c99d6899  vmovaps xmm7, [rsp+0x70]
00007dd8c99d689f  vmovaps xmm9, [rsp+0x80]
00007dd8c99d68a8  vmovaps xmm10, [rsp+0x90]
00007dd8c99d68b1  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d68ba  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d68c3  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d68cc  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d68d5  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d68de  add rsp, 0xF0
00007dd8c99d68e5  pop r11
00007dd8c99d68e7  pop r10
00007dd8c99d68e9  pop r9
00007dd8c99d68eb  pop r8
00007dd8c99d68ed  pop rsi
00007dd8c99d68ee  pop rdi
00007dd8c99d68ef  pop rdx
00007dd8c99d68f0  pop rcx
00007dd8c99d68f1  pop rax
00007dd8c99d68f2  add rsp, 0x08
00007dd8c99d68f6  jmp 0x00007DD8C99D599A
00007dd8c99d68fb  sub rsp, 0x08
00007dd8c99d68ff  push rax
00007dd8c99d6900  push rcx
00007dd8c99d6901  push rdx
00007dd8c99d6902  push rdi
00007dd8c99d6903  push rsi
00007dd8c99d6904  push r8
00007dd8c99d6906  push r9
00007dd8c99d6908  push r10
00007dd8c99d690a  push r11
00007dd8c99d690c  sub rsp, 0xF0
00007dd8c99d6913  vmovaps [rsp], xmm0
00007dd8c99d6918  vmovaps [rsp+0x10], xmm1
00007dd8c99d691e  vmovaps [rsp+0x20], xmm2
00007dd8c99d6924  vmovaps [rsp+0x30], xmm3
00007dd8c99d692a  vmovaps [rsp+0x40], xmm4
00007dd8c99d6930  vmovaps [rsp+0x50], xmm5
00007dd8c99d6936  vmovaps [rsp+0x60], xmm6
00007dd8c99d693c  vmovaps [rsp+0x70], xmm8
00007dd8c99d6942  vmovaps [rsp+0x80], xmm9
00007dd8c99d694b  vmovaps [rsp+0x90], xmm10
00007dd8c99d6954  vmovaps [rsp+0xA0], xmm11
00007dd8c99d695d  vmovaps [rsp+0xB0], xmm12
00007dd8c99d6966  vmovaps [rsp+0xC0], xmm13
00007dd8c99d696f  vmovaps [rsp+0xD0], xmm14
00007dd8c99d6978  vmovaps [rsp+0xE0], xmm15
00007dd8c99d6981  sub rsp, 0x30
00007dd8c99d6985  movaps [rsp], xmm7
00007dd8c99d6989  movaps [rsp+0x10], xmm9
00007dd8c99d698f  movaps [rsp+0x20], xmm15
00007dd8c99d6995  lea rdi, [rsp]
00007dd8c99d6999  mov esi, 0x00
00007dd8c99d699e  mov rax, 0x55FEBBDB5530
00007dd8c99d69a8  call rax
00007dd8c99d69aa  movaps xmm7, [rsp]
00007dd8c99d69ae  add rsp, 0x30
00007dd8c99d69b2  vmovaps xmm0, [rsp]
00007dd8c99d69b7  vmovaps xmm1, [rsp+0x10]
00007dd8c99d69bd  vmovaps xmm2, [rsp+0x20]
00007dd8c99d69c3  vmovaps xmm3, [rsp+0x30]
00007dd8c99d69c9  vmovaps xmm4, [rsp+0x40]
00007dd8c99d69cf  vmovaps xmm5, [rsp+0x50]
00007dd8c99d69d5  vmovaps xmm6, [rsp+0x60]
00007dd8c99d69db  vmovaps xmm8, [rsp+0x70]
00007dd8c99d69e1  vmovaps xmm9, [rsp+0x80]
00007dd8c99d69ea  vmovaps xmm10, [rsp+0x90]
00007dd8c99d69f3  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d69fc  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d6a05  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d6a0e  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d6a17  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d6a20  add rsp, 0xF0
00007dd8c99d6a27  pop r11
00007dd8c99d6a29  pop r10
00007dd8c99d6a2b  pop r9
00007dd8c99d6a2d  pop r8
00007dd8c99d6a2f  pop rsi
00007dd8c99d6a30  pop rdi
00007dd8c99d6a31  pop rdx
00007dd8c99d6a32  pop rcx
00007dd8c99d6a33  pop rax
00007dd8c99d6a34  add rsp, 0x08
00007dd8c99d6a38  jmp 0x00007DD8C99D59C8
00007dd8c99d6a3d  sub rsp, 0x08
00007dd8c99d6a41  push rax
00007dd8c99d6a42  push rcx
00007dd8c99d6a43  push rdx
00007dd8c99d6a44  push rdi
00007dd8c99d6a45  push rsi
00007dd8c99d6a46  push r8
00007dd8c99d6a48  push r9
00007dd8c99d6a4a  push r10
00007dd8c99d6a4c  push r11
00007dd8c99d6a4e  sub rsp, 0xF0
00007dd8c99d6a55  vmovaps [rsp], xmm0
00007dd8c99d6a5a  vmovaps [rsp+0x10], xmm1
00007dd8c99d6a60  vmovaps [rsp+0x20], xmm2
00007dd8c99d6a66  vmovaps [rsp+0x30], xmm3
00007dd8c99d6a6c  vmovaps [rsp+0x40], xmm4
00007dd8c99d6a72  vmovaps [rsp+0x50], xmm5
00007dd8c99d6a78  vmovaps [rsp+0x60], xmm6
00007dd8c99d6a7e  vmovaps [rsp+0x70], xmm7
00007dd8c99d6a84  vmovaps [rsp+0x80], xmm8
00007dd8c99d6a8d  vmovaps [rsp+0x90], xmm10
00007dd8c99d6a96  vmovaps [rsp+0xA0], xmm11
00007dd8c99d6a9f  vmovaps [rsp+0xB0], xmm12
00007dd8c99d6aa8  vmovaps [rsp+0xC0], xmm13
00007dd8c99d6ab1  vmovaps [rsp+0xD0], xmm14
00007dd8c99d6aba  vmovaps [rsp+0xE0], xmm15
00007dd8c99d6ac3  sub rsp, 0x30
00007dd8c99d6ac7  movaps [rsp], xmm9
00007dd8c99d6acc  movaps [rsp+0x10], xmm12
00007dd8c99d6ad2  movaps [rsp+0x20], xmm10
00007dd8c99d6ad8  lea rdi, [rsp]
00007dd8c99d6adc  mov esi, 0x00
00007dd8c99d6ae1  mov rax, 0x55FEBBDB5530
00007dd8c99d6aeb  call rax
00007dd8c99d6aed  movaps xmm9, [rsp]
00007dd8c99d6af2  add rsp, 0x30
00007dd8c99d6af6  vmovaps xmm0, [rsp]
00007dd8c99d6afb  vmovaps xmm1, [rsp+0x10]
00007dd8c99d6b01  vmovaps xmm2, [rsp+0x20]
00007dd8c99d6b07  vmovaps xmm3, [rsp+0x30]
00007dd8c99d6b0d  vmovaps xmm4, [rsp+0x40]
00007dd8c99d6b13  vmovaps xmm5, [rsp+0x50]
00007dd8c99d6b19  vmovaps xmm6, [rsp+0x60]
00007dd8c99d6b1f  vmovaps xmm7, [rsp+0x70]
00007dd8c99d6b25  vmovaps xmm8, [rsp+0x80]
00007dd8c99d6b2e  vmovaps xmm10, [rsp+0x90]
00007dd8c99d6b37  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d6b40  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d6b49  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d6b52  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d6b5b  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d6b64  add rsp, 0xF0
00007dd8c99d6b6b  pop r11
00007dd8c99d6b6d  pop r10
00007dd8c99d6b6f  pop r9
00007dd8c99d6b71  pop r8
00007dd8c99d6b73  pop rsi
00007dd8c99d6b74  pop rdi
00007dd8c99d6b75  pop rdx
00007dd8c99d6b76  pop rcx
00007dd8c99d6b77  pop rax
00007dd8c99d6b78  add rsp, 0x08
00007dd8c99d6b7c  jmp 0x00007DD8C99D59EC
00007dd8c99d6b81  sub rsp, 0x08
00007dd8c99d6b85  push rax
00007dd8c99d6b86  push rcx
00007dd8c99d6b87  push rdx
00007dd8c99d6b88  push rdi
00007dd8c99d6b89  push rsi
00007dd8c99d6b8a  push r8
00007dd8c99d6b8c  push r9
00007dd8c99d6b8e  push r10
00007dd8c99d6b90  push r11
00007dd8c99d6b92  sub rsp, 0xF0
00007dd8c99d6b99  vmovaps [rsp], xmm0
00007dd8c99d6b9e  vmovaps [rsp+0x10], xmm1
00007dd8c99d6ba4  vmovaps [rsp+0x20], xmm2
00007dd8c99d6baa  vmovaps [rsp+0x30], xmm3
00007dd8c99d6bb0  vmovaps [rsp+0x40], xmm4
00007dd8c99d6bb6  vmovaps [rsp+0x50], xmm5
00007dd8c99d6bbc  vmovaps [rsp+0x60], xmm6
00007dd8c99d6bc2  vmovaps [rsp+0x70], xmm7
00007dd8c99d6bc8  vmovaps [rsp+0x80], xmm8
00007dd8c99d6bd1  vmovaps [rsp+0x90], xmm9
00007dd8c99d6bda  vmovaps [rsp+0xA0], xmm11
00007dd8c99d6be3  vmovaps [rsp+0xB0], xmm12
00007dd8c99d6bec  vmovaps [rsp+0xC0], xmm13
00007dd8c99d6bf5  vmovaps [rsp+0xD0], xmm14
00007dd8c99d6bfe  vmovaps [rsp+0xE0], xmm15
00007dd8c99d6c07  sub rsp, 0x30
00007dd8c99d6c0b  movaps [rsp], xmm10
00007dd8c99d6c10  movaps [rsp+0x10], xmm12
00007dd8c99d6c16  movaps [rsp+0x20], xmm11
00007dd8c99d6c1c  lea rdi, [rsp]
00007dd8c99d6c20  mov esi, 0x00
00007dd8c99d6c25  mov rax, 0x55FEBBDB5530
00007dd8c99d6c2f  call rax
00007dd8c99d6c31  movaps xmm10, [rsp]
00007dd8c99d6c36  add rsp, 0x30
00007dd8c99d6c3a  vmovaps xmm0, [rsp]
00007dd8c99d6c3f  vmovaps xmm1, [rsp+0x10]
00007dd8c99d6c45  vmovaps xmm2, [rsp+0x20]
00007dd8c99d6c4b  vmovaps xmm3, [rsp+0x30]
00007dd8c99d6c51  vmovaps xmm4, [rsp+0x40]
00007dd8c99d6c57  vmovaps xmm5, [rsp+0x50]
00007dd8c99d6c5d  vmovaps xmm6, [rsp+0x60]
00007dd8c99d6c63  vmovaps xmm7, [rsp+0x70]
00007dd8c99d6c69  vmovaps xmm8, [rsp+0x80]
00007dd8c99d6c72  vmovaps xmm9, [rsp+0x90]
00007dd8c99d6c7b  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d6c84  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d6c8d  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d6c96  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d6c9f  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d6ca8  add rsp, 0xF0
00007dd8c99d6caf  pop r11
00007dd8c99d6cb1  pop r10
00007dd8c99d6cb3  pop r9
00007dd8c99d6cb5  pop r8
00007dd8c99d6cb7  pop rsi
00007dd8c99d6cb8  pop rdi
00007dd8c99d6cb9  pop rdx
00007dd8c99d6cba  pop rcx
00007dd8c99d6cbb  pop rax
00007dd8c99d6cbc  add rsp, 0x08
00007dd8c99d6cc0  jmp 0x00007DD8C99D5A06
00007dd8c99d6cc5  sub rsp, 0x08
00007dd8c99d6cc9  push rax
00007dd8c99d6cca  push rcx
00007dd8c99d6ccb  push rdx
00007dd8c99d6ccc  push rdi
00007dd8c99d6ccd  push rsi
00007dd8c99d6cce  push r8
00007dd8c99d6cd0  push r9
00007dd8c99d6cd2  push r10
00007dd8c99d6cd4  push r11
00007dd8c99d6cd6  sub rsp, 0xF0
00007dd8c99d6cdd  vmovaps [rsp], xmm0
00007dd8c99d6ce2  vmovaps [rsp+0x10], xmm1
00007dd8c99d6ce8  vmovaps [rsp+0x20], xmm2
00007dd8c99d6cee  vmovaps [rsp+0x30], xmm3
00007dd8c99d6cf4  vmovaps [rsp+0x40], xmm4
00007dd8c99d6cfa  vmovaps [rsp+0x50], xmm5
00007dd8c99d6d00  vmovaps [rsp+0x60], xmm7
00007dd8c99d6d06  vmovaps [rsp+0x70], xmm8
00007dd8c99d6d0c  vmovaps [rsp+0x80], xmm9
00007dd8c99d6d15  vmovaps [rsp+0x90], xmm10
00007dd8c99d6d1e  vmovaps [rsp+0xA0], xmm11
00007dd8c99d6d27  vmovaps [rsp+0xB0], xmm12
00007dd8c99d6d30  vmovaps [rsp+0xC0], xmm13
00007dd8c99d6d39  vmovaps [rsp+0xD0], xmm14
00007dd8c99d6d42  vmovaps [rsp+0xE0], xmm15
00007dd8c99d6d4b  sub rsp, 0x30
00007dd8c99d6d4f  movaps [rsp], xmm6
00007dd8c99d6d53  movaps [rsp+0x10], xmm12
00007dd8c99d6d59  movaps [rsp+0x20], xmm11
00007dd8c99d6d5f  lea rdi, [rsp]
00007dd8c99d6d63  mov esi, 0x00
00007dd8c99d6d68  mov rax, 0x55FEBBDB5530
00007dd8c99d6d72  call rax
00007dd8c99d6d74  movaps xmm6, [rsp]
00007dd8c99d6d78  add rsp, 0x30
00007dd8c99d6d7c  vmovaps xmm0, [rsp]
00007dd8c99d6d81  vmovaps xmm1, [rsp+0x10]
00007dd8c99d6d87  vmovaps xmm2, [rsp+0x20]
00007dd8c99d6d8d  vmovaps xmm3, [rsp+0x30]
00007dd8c99d6d93  vmovaps xmm4, [rsp+0x40]
00007dd8c99d6d99  vmovaps xmm5, [rsp+0x50]
00007dd8c99d6d9f  vmovaps xmm7, [rsp+0x60]
00007dd8c99d6da5  vmovaps xmm8, [rsp+0x70]
00007dd8c99d6dab  vmovaps xmm9, [rsp+0x80]
00007dd8c99d6db4  vmovaps xmm10, [rsp+0x90]
00007dd8c99d6dbd  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d6dc6  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d6dcf  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d6dd8  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d6de1  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d6dea  add rsp, 0xF0
00007dd8c99d6df1  pop r11
00007dd8c99d6df3  pop r10
00007dd8c99d6df5  pop r9
00007dd8c99d6df7  pop r8
00007dd8c99d6df9  pop rsi
00007dd8c99d6dfa  pop rdi
00007dd8c99d6dfb  pop rdx
00007dd8c99d6dfc  pop rcx
00007dd8c99d6dfd  pop rax
00007dd8c99d6dfe  add rsp, 0x08
00007dd8c99d6e02  jmp 0x00007DD8C99D5A27
00007dd8c99d6e07  sub rsp, 0x08
00007dd8c99d6e0b  push rax
00007dd8c99d6e0c  push rcx
00007dd8c99d6e0d  push rdx
00007dd8c99d6e0e  push rdi
00007dd8c99d6e0f  push rsi
00007dd8c99d6e10  push r8
00007dd8c99d6e12  push r9
00007dd8c99d6e14  push r10
00007dd8c99d6e16  push r11
00007dd8c99d6e18  sub rsp, 0xF0
00007dd8c99d6e1f  vmovaps [rsp], xmm0
00007dd8c99d6e24  vmovaps [rsp+0x10], xmm1
00007dd8c99d6e2a  vmovaps [rsp+0x20], xmm2
00007dd8c99d6e30  vmovaps [rsp+0x30], xmm4
00007dd8c99d6e36  vmovaps [rsp+0x40], xmm5
00007dd8c99d6e3c  vmovaps [rsp+0x50], xmm6
00007dd8c99d6e42  vmovaps [rsp+0x60], xmm7
00007dd8c99d6e48  vmovaps [rsp+0x70], xmm8
00007dd8c99d6e4e  vmovaps [rsp+0x80], xmm9
00007dd8c99d6e57  vmovaps [rsp+0x90], xmm10
00007dd8c99d6e60  vmovaps [rsp+0xA0], xmm11
00007dd8c99d6e69  vmovaps [rsp+0xB0], xmm12
00007dd8c99d6e72  vmovaps [rsp+0xC0], xmm13
00007dd8c99d6e7b  vmovaps [rsp+0xD0], xmm14
00007dd8c99d6e84  vmovaps [rsp+0xE0], xmm15
00007dd8c99d6e8d  sub rsp, 0x30
00007dd8c99d6e91  movaps [rsp], xmm3
00007dd8c99d6e95  movaps [rsp+0x10], xmm5
00007dd8c99d6e9a  movaps [rsp+0x20], xmm4
00007dd8c99d6e9f  lea rdi, [rsp]
00007dd8c99d6ea3  mov esi, 0x00
00007dd8c99d6ea8  mov rax, 0x55FEBBDB5530
00007dd8c99d6eb2  call rax
00007dd8c99d6eb4  movaps xmm3, [rsp]
00007dd8c99d6eb8  add rsp, 0x30
00007dd8c99d6ebc  vmovaps xmm0, [rsp]
00007dd8c99d6ec1  vmovaps xmm1, [rsp+0x10]
00007dd8c99d6ec7  vmovaps xmm2, [rsp+0x20]
00007dd8c99d6ecd  vmovaps xmm4, [rsp+0x30]
00007dd8c99d6ed3  vmovaps xmm5, [rsp+0x40]
00007dd8c99d6ed9  vmovaps xmm6, [rsp+0x50]
00007dd8c99d6edf  vmovaps xmm7, [rsp+0x60]
00007dd8c99d6ee5  vmovaps xmm8, [rsp+0x70]
00007dd8c99d6eeb  vmovaps xmm9, [rsp+0x80]
00007dd8c99d6ef4  vmovaps xmm10, [rsp+0x90]
00007dd8c99d6efd  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d6f06  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d6f0f  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d6f18  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d6f21  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d6f2a  add rsp, 0xF0
00007dd8c99d6f31  pop r11
00007dd8c99d6f33  pop r10
00007dd8c99d6f35  pop r9
00007dd8c99d6f37  pop r8
00007dd8c99d6f39  pop rsi
00007dd8c99d6f3a  pop rdi
00007dd8c99d6f3b  pop rdx
00007dd8c99d6f3c  pop rcx
00007dd8c99d6f3d  pop rax
00007dd8c99d6f3e  add rsp, 0x08
00007dd8c99d6f42  jmp 0x00007DD8C99D5A88
00007dd8c99d6f47  sub rsp, 0x08
00007dd8c99d6f4b  push rax
00007dd8c99d6f4c  push rcx
00007dd8c99d6f4d  push rdx
00007dd8c99d6f4e  push rdi
00007dd8c99d6f4f  push rsi
00007dd8c99d6f50  push r8
00007dd8c99d6f52  push r9
00007dd8c99d6f54  push r10
00007dd8c99d6f56  push r11
00007dd8c99d6f58  sub rsp, 0xF0
00007dd8c99d6f5f  vmovaps [rsp], xmm0
00007dd8c99d6f64  vmovaps [rsp+0x10], xmm1
00007dd8c99d6f6a  vmovaps [rsp+0x20], xmm2
00007dd8c99d6f70  vmovaps [rsp+0x30], xmm3
00007dd8c99d6f76  vmovaps [rsp+0x40], xmm4
00007dd8c99d6f7c  vmovaps [rsp+0x50], xmm6
00007dd8c99d6f82  vmovaps [rsp+0x60], xmm7
00007dd8c99d6f88  vmovaps [rsp+0x70], xmm8
00007dd8c99d6f8e  vmovaps [rsp+0x80], xmm9
00007dd8c99d6f97  vmovaps [rsp+0x90], xmm10
00007dd8c99d6fa0  vmovaps [rsp+0xA0], xmm11
00007dd8c99d6fa9  vmovaps [rsp+0xB0], xmm12
00007dd8c99d6fb2  vmovaps [rsp+0xC0], xmm13
00007dd8c99d6fbb  vmovaps [rsp+0xD0], xmm14
00007dd8c99d6fc4  vmovaps [rsp+0xE0], xmm15
00007dd8c99d6fcd  sub rsp, 0x30
00007dd8c99d6fd1  movaps [rsp], xmm5
00007dd8c99d6fd5  movaps [rsp+0x10], xmm8
00007dd8c99d6fdb  movaps [rsp+0x20], xmm15
00007dd8c99d6fe1  lea rdi, [rsp]
00007dd8c99d6fe5  mov esi, 0x00
00007dd8c99d6fea  mov rax, 0x55FEBBDB5530
00007dd8c99d6ff4  call rax
00007dd8c99d6ff6  movaps xmm5, [rsp]
00007dd8c99d6ffa  add rsp, 0x30
00007dd8c99d6ffe  vmovaps xmm0, [rsp]
00007dd8c99d7003  vmovaps xmm1, [rsp+0x10]
00007dd8c99d7009  vmovaps xmm2, [rsp+0x20]
00007dd8c99d700f  vmovaps xmm3, [rsp+0x30]
00007dd8c99d7015  vmovaps xmm4, [rsp+0x40]
00007dd8c99d701b  vmovaps xmm6, [rsp+0x50]
00007dd8c99d7021  vmovaps xmm7, [rsp+0x60]
00007dd8c99d7027  vmovaps xmm8, [rsp+0x70]
00007dd8c99d702d  vmovaps xmm9, [rsp+0x80]
00007dd8c99d7036  vmovaps xmm10, [rsp+0x90]
00007dd8c99d703f  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d7048  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d7051  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d705a  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d7063  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d706c  add rsp, 0xF0
00007dd8c99d7073  pop r11
00007dd8c99d7075  pop r10
00007dd8c99d7077  pop r9
00007dd8c99d7079  pop r8
00007dd8c99d707b  pop rsi
00007dd8c99d707c  pop rdi
00007dd8c99d707d  pop rdx
00007dd8c99d707e  pop rcx
00007dd8c99d707f  pop rax
00007dd8c99d7080  add rsp, 0x08
00007dd8c99d7084  jmp 0x00007DD8C99D5AC0
00007dd8c99d7089  sub rsp, 0x08
00007dd8c99d708d  push rax
00007dd8c99d708e  push rcx
00007dd8c99d708f  push rdx
00007dd8c99d7090  push rdi
00007dd8c99d7091  push rsi
00007dd8c99d7092  push r8
00007dd8c99d7094  push r9
00007dd8c99d7096  push r10
00007dd8c99d7098  push r11
00007dd8c99d709a  sub rsp, 0xF0
00007dd8c99d70a1  vmovaps [rsp], xmm0
00007dd8c99d70a6  vmovaps [rsp+0x10], xmm1
00007dd8c99d70ac  vmovaps [rsp+0x20], xmm2
00007dd8c99d70b2  vmovaps [rsp+0x30], xmm3
00007dd8c99d70b8  vmovaps [rsp+0x40], xmm5
00007dd8c99d70be  vmovaps [rsp+0x50], xmm6
00007dd8c99d70c4  vmovaps [rsp+0x60], xmm7
00007dd8c99d70ca  vmovaps [rsp+0x70], xmm8
00007dd8c99d70d0  vmovaps [rsp+0x80], xmm9
00007dd8c99d70d9  vmovaps [rsp+0x90], xmm10
00007dd8c99d70e2  vmovaps [rsp+0xA0], xmm11
00007dd8c99d70eb  vmovaps [rsp+0xB0], xmm12
00007dd8c99d70f4  vmovaps [rsp+0xC0], xmm13
00007dd8c99d70fd  vmovaps [rsp+0xD0], xmm14
00007dd8c99d7106  vmovaps [rsp+0xE0], xmm15
00007dd8c99d710f  sub rsp, 0x30
00007dd8c99d7113  movaps [rsp], xmm4
00007dd8c99d7117  movaps [rsp+0x10], xmm9
00007dd8c99d711d  movaps [rsp+0x20], xmm8
00007dd8c99d7123  lea rdi, [rsp]
00007dd8c99d7127  mov esi, 0x00
00007dd8c99d712c  mov rax, 0x55FEBBDB5530
00007dd8c99d7136  call rax
00007dd8c99d7138  movaps xmm4, [rsp]
00007dd8c99d713c  add rsp, 0x30
00007dd8c99d7140  vmovaps xmm0, [rsp]
00007dd8c99d7145  vmovaps xmm1, [rsp+0x10]
00007dd8c99d714b  vmovaps xmm2, [rsp+0x20]
00007dd8c99d7151  vmovaps xmm3, [rsp+0x30]
00007dd8c99d7157  vmovaps xmm5, [rsp+0x40]
00007dd8c99d715d  vmovaps xmm6, [rsp+0x50]
00007dd8c99d7163  vmovaps xmm7, [rsp+0x60]
00007dd8c99d7169  vmovaps xmm8, [rsp+0x70]
00007dd8c99d716f  vmovaps xmm9, [rsp+0x80]
00007dd8c99d7178  vmovaps xmm10, [rsp+0x90]
00007dd8c99d7181  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d718a  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d7193  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d719c  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d71a5  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d71ae  add rsp, 0xF0
00007dd8c99d71b5  pop r11
00007dd8c99d71b7  pop r10
00007dd8c99d71b9  pop r9
00007dd8c99d71bb  pop r8
00007dd8c99d71bd  pop rsi
00007dd8c99d71be  pop rdi
00007dd8c99d71bf  pop rdx
00007dd8c99d71c0  pop rcx
00007dd8c99d71c1  pop rax
00007dd8c99d71c2  add rsp, 0x08
00007dd8c99d71c6  jmp 0x00007DD8C99D5AE1
00007dd8c99d71cb  sub rsp, 0x08
00007dd8c99d71cf  push rax
00007dd8c99d71d0  push rcx
00007dd8c99d71d1  push rdx
00007dd8c99d71d2  push rdi
00007dd8c99d71d3  push rsi
00007dd8c99d71d4  push r8
00007dd8c99d71d6  push r9
00007dd8c99d71d8  push r10
00007dd8c99d71da  push r11
00007dd8c99d71dc  sub rsp, 0xF0
00007dd8c99d71e3  vmovaps [rsp], xmm0
00007dd8c99d71e8  vmovaps [rsp+0x10], xmm1
00007dd8c99d71ee  vmovaps [rsp+0x20], xmm2
00007dd8c99d71f4  vmovaps [rsp+0x30], xmm3
00007dd8c99d71fa  vmovaps [rsp+0x40], xmm4
00007dd8c99d7200  vmovaps [rsp+0x50], xmm5
00007dd8c99d7206  vmovaps [rsp+0x60], xmm6
00007dd8c99d720c  vmovaps [rsp+0x70], xmm7
00007dd8c99d7212  vmovaps [rsp+0x80], xmm8
00007dd8c99d721b  vmovaps [rsp+0x90], xmm10
00007dd8c99d7224  vmovaps [rsp+0xA0], xmm11
00007dd8c99d722d  vmovaps [rsp+0xB0], xmm12
00007dd8c99d7236  vmovaps [rsp+0xC0], xmm13
00007dd8c99d723f  vmovaps [rsp+0xD0], xmm14
00007dd8c99d7248  vmovaps [rsp+0xE0], xmm15
00007dd8c99d7251  sub rsp, 0x30
00007dd8c99d7255  movaps [rsp], xmm9
00007dd8c99d725a  movaps [rsp+0x10], xmm10
00007dd8c99d7260  movaps [rsp+0x20], xmm8
00007dd8c99d7266  lea rdi, [rsp]
00007dd8c99d726a  mov esi, 0x00
00007dd8c99d726f  mov rax, 0x55FEBBDB5530
00007dd8c99d7279  call rax
00007dd8c99d727b  movaps xmm9, [rsp]
00007dd8c99d7280  add rsp, 0x30
00007dd8c99d7284  vmovaps xmm0, [rsp]
00007dd8c99d7289  vmovaps xmm1, [rsp+0x10]
00007dd8c99d728f  vmovaps xmm2, [rsp+0x20]
00007dd8c99d7295  vmovaps xmm3, [rsp+0x30]
00007dd8c99d729b  vmovaps xmm4, [rsp+0x40]
00007dd8c99d72a1  vmovaps xmm5, [rsp+0x50]
00007dd8c99d72a7  vmovaps xmm6, [rsp+0x60]
00007dd8c99d72ad  vmovaps xmm7, [rsp+0x70]
00007dd8c99d72b3  vmovaps xmm8, [rsp+0x80]
00007dd8c99d72bc  vmovaps xmm10, [rsp+0x90]
00007dd8c99d72c5  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d72ce  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d72d7  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d72e0  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d72e9  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d72f2  add rsp, 0xF0
00007dd8c99d72f9  pop r11
00007dd8c99d72fb  pop r10
00007dd8c99d72fd  pop r9
00007dd8c99d72ff  pop r8
00007dd8c99d7301  pop rsi
00007dd8c99d7302  pop rdi
00007dd8c99d7303  pop rdx
00007dd8c99d7304  pop rcx
00007dd8c99d7305  pop rax
00007dd8c99d7306  add rsp, 0x08
00007dd8c99d730a  jmp 0x00007DD8C99D5AFB
00007dd8c99d730f  call 0x00007DD8C98D64F0
00007dd8c99d7314  jmp 0x00007DD8C99D5C15
00007dd8c99d7319  call 0x00007DD8C98D64F0
00007dd8c99d731e  jmp 0x00007DD8C99D5C2B
00007dd8c99d7323  sub rsp, 0x08
00007dd8c99d7327  push rax
00007dd8c99d7328  push rcx
00007dd8c99d7329  push rdx
00007dd8c99d732a  push rdi
00007dd8c99d732b  push rsi
00007dd8c99d732c  push r8
00007dd8c99d732e  push r9
00007dd8c99d7330  push r10
00007dd8c99d7332  push r11
00007dd8c99d7334  sub rsp, 0xF0
00007dd8c99d733b  vmovaps [rsp], xmm0
00007dd8c99d7340  vmovaps [rsp+0x10], xmm2
00007dd8c99d7346  vmovaps [rsp+0x20], xmm3
00007dd8c99d734c  vmovaps [rsp+0x30], xmm4
00007dd8c99d7352  vmovaps [rsp+0x40], xmm5
00007dd8c99d7358  vmovaps [rsp+0x50], xmm6
00007dd8c99d735e  vmovaps [rsp+0x60], xmm7
00007dd8c99d7364  vmovaps [rsp+0x70], xmm8
00007dd8c99d736a  vmovaps [rsp+0x80], xmm9
00007dd8c99d7373  vmovaps [rsp+0x90], xmm10
00007dd8c99d737c  vmovaps [rsp+0xA0], xmm11
00007dd8c99d7385  vmovaps [rsp+0xB0], xmm12
00007dd8c99d738e  vmovaps [rsp+0xC0], xmm13
00007dd8c99d7397  vmovaps [rsp+0xD0], xmm14
00007dd8c99d73a0  vmovaps [rsp+0xE0], xmm15
00007dd8c99d73a9  sub rsp, 0x30
00007dd8c99d73ad  movaps [rsp], xmm1
00007dd8c99d73b1  movaps [rsp+0x10], xmm6
00007dd8c99d73b6  movaps [rsp+0x20], xmm15
00007dd8c99d73bc  lea rdi, [rsp]
00007dd8c99d73c0  mov esi, 0x00
00007dd8c99d73c5  mov rax, 0x55FEBBDB5530
00007dd8c99d73cf  call rax
00007dd8c99d73d1  movaps xmm1, [rsp]
00007dd8c99d73d5  add rsp, 0x30
00007dd8c99d73d9  vmovaps xmm0, [rsp]
00007dd8c99d73de  vmovaps xmm2, [rsp+0x10]
00007dd8c99d73e4  vmovaps xmm3, [rsp+0x20]
00007dd8c99d73ea  vmovaps xmm4, [rsp+0x30]
00007dd8c99d73f0  vmovaps xmm5, [rsp+0x40]
00007dd8c99d73f6  vmovaps xmm6, [rsp+0x50]
00007dd8c99d73fc  vmovaps xmm7, [rsp+0x60]
00007dd8c99d7402  vmovaps xmm8, [rsp+0x70]
00007dd8c99d7408  vmovaps xmm9, [rsp+0x80]
00007dd8c99d7411  vmovaps xmm10, [rsp+0x90]
00007dd8c99d741a  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d7423  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d742c  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d7435  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d743e  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d7447  add rsp, 0xF0
00007dd8c99d744e  pop r11
00007dd8c99d7450  pop r10
00007dd8c99d7452  pop r9
00007dd8c99d7454  pop r8
00007dd8c99d7456  pop rsi
00007dd8c99d7457  pop rdi
00007dd8c99d7458  pop rdx
00007dd8c99d7459  pop rcx
00007dd8c99d745a  pop rax
00007dd8c99d745b  add rsp, 0x08
00007dd8c99d745f  jmp 0x00007DD8C99D5C68
00007dd8c99d7464  call 0x00007DD8C98E5820
00007dd8c99d7469  jmp 0x00007DD8C99D5C75
00007dd8c99d746e  sub rsp, 0x08
00007dd8c99d7472  push rax
00007dd8c99d7473  push rcx
00007dd8c99d7474  push rdx
00007dd8c99d7475  push rdi
00007dd8c99d7476  push rsi
00007dd8c99d7477  push r8
00007dd8c99d7479  push r9
00007dd8c99d747b  push r10
00007dd8c99d747d  push r11
00007dd8c99d747f  sub rsp, 0xF0
00007dd8c99d7486  vmovaps [rsp], xmm0
00007dd8c99d748b  vmovaps [rsp+0x10], xmm1
00007dd8c99d7491  vmovaps [rsp+0x20], xmm2
00007dd8c99d7497  vmovaps [rsp+0x30], xmm3
00007dd8c99d749d  vmovaps [rsp+0x40], xmm4
00007dd8c99d74a3  vmovaps [rsp+0x50], xmm5
00007dd8c99d74a9  vmovaps [rsp+0x60], xmm6
00007dd8c99d74af  vmovaps [rsp+0x70], xmm7
00007dd8c99d74b5  vmovaps [rsp+0x80], xmm8
00007dd8c99d74be  vmovaps [rsp+0x90], xmm9
00007dd8c99d74c7  vmovaps [rsp+0xA0], xmm10
00007dd8c99d74d0  vmovaps [rsp+0xB0], xmm11
00007dd8c99d74d9  vmovaps [rsp+0xC0], xmm12
00007dd8c99d74e2  vmovaps [rsp+0xD0], xmm13
00007dd8c99d74eb  vmovaps [rsp+0xE0], xmm15
00007dd8c99d74f4  sub rsp, 0x30
00007dd8c99d74f8  movaps [rsp], xmm14
00007dd8c99d74fd  movaps [rsp+0x10], xmm4
00007dd8c99d7502  movaps [rsp+0x20], xmm3
00007dd8c99d7507  lea rdi, [rsp]
00007dd8c99d750b  mov esi, 0x00
00007dd8c99d7510  mov rax, 0x55FEBBDB5530
00007dd8c99d751a  call rax
00007dd8c99d751c  movaps xmm14, [rsp]
00007dd8c99d7521  add rsp, 0x30
00007dd8c99d7525  vmovaps xmm0, [rsp]
00007dd8c99d752a  vmovaps xmm1, [rsp+0x10]
00007dd8c99d7530  vmovaps xmm2, [rsp+0x20]
00007dd8c99d7536  vmovaps xmm3, [rsp+0x30]
00007dd8c99d753c  vmovaps xmm4, [rsp+0x40]
00007dd8c99d7542  vmovaps xmm5, [rsp+0x50]
00007dd8c99d7548  vmovaps xmm6, [rsp+0x60]
00007dd8c99d754e  vmovaps xmm7, [rsp+0x70]
00007dd8c99d7554  vmovaps xmm8, [rsp+0x80]
00007dd8c99d755d  vmovaps xmm9, [rsp+0x90]
00007dd8c99d7566  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d756f  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d7578  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d7581  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d758a  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d7593  add rsp, 0xF0
00007dd8c99d759a  pop r11
00007dd8c99d759c  pop r10
00007dd8c99d759e  pop r9
00007dd8c99d75a0  pop r8
00007dd8c99d75a2  pop rsi
00007dd8c99d75a3  pop rdi
00007dd8c99d75a4  pop rdx
00007dd8c99d75a5  pop rcx
00007dd8c99d75a6  pop rax
00007dd8c99d75a7  add rsp, 0x08
00007dd8c99d75ab  jmp 0x00007DD8C99D5C8F
00007dd8c99d75b0  sub rsp, 0x08
00007dd8c99d75b4  push rax
00007dd8c99d75b5  push rcx
00007dd8c99d75b6  push rdx
00007dd8c99d75b7  push rdi
00007dd8c99d75b8  push rsi
00007dd8c99d75b9  push r8
00007dd8c99d75bb  push r9
00007dd8c99d75bd  push r10
00007dd8c99d75bf  push r11
00007dd8c99d75c1  sub rsp, 0xF0
00007dd8c99d75c8  vmovaps [rsp], xmm0
00007dd8c99d75cd  vmovaps [rsp+0x10], xmm1
00007dd8c99d75d3  vmovaps [rsp+0x20], xmm2
00007dd8c99d75d9  vmovaps [rsp+0x30], xmm3
00007dd8c99d75df  vmovaps [rsp+0x40], xmm4
00007dd8c99d75e5  vmovaps [rsp+0x50], xmm5
00007dd8c99d75eb  vmovaps [rsp+0x60], xmm7
00007dd8c99d75f1  vmovaps [rsp+0x70], xmm8
00007dd8c99d75f7  vmovaps [rsp+0x80], xmm9
00007dd8c99d7600  vmovaps [rsp+0x90], xmm10
00007dd8c99d7609  vmovaps [rsp+0xA0], xmm11
00007dd8c99d7612  vmovaps [rsp+0xB0], xmm12
00007dd8c99d761b  vmovaps [rsp+0xC0], xmm13
00007dd8c99d7624  vmovaps [rsp+0xD0], xmm14
00007dd8c99d762d  vmovaps [rsp+0xE0], xmm15
00007dd8c99d7636  sub rsp, 0x30
00007dd8c99d763a  movaps [rsp], xmm6
00007dd8c99d763e  movaps [rsp+0x10], xmm9
00007dd8c99d7644  movaps [rsp+0x20], xmm7
00007dd8c99d7649  lea rdi, [rsp]
00007dd8c99d764d  mov esi, 0x00
00007dd8c99d7652  mov rax, 0x55FEBBDB5530
00007dd8c99d765c  call rax
00007dd8c99d765e  movaps xmm6, [rsp]
00007dd8c99d7662  add rsp, 0x30
00007dd8c99d7666  vmovaps xmm0, [rsp]
00007dd8c99d766b  vmovaps xmm1, [rsp+0x10]
00007dd8c99d7671  vmovaps xmm2, [rsp+0x20]
00007dd8c99d7677  vmovaps xmm3, [rsp+0x30]
00007dd8c99d767d  vmovaps xmm4, [rsp+0x40]
00007dd8c99d7683  vmovaps xmm5, [rsp+0x50]
00007dd8c99d7689  vmovaps xmm7, [rsp+0x60]
00007dd8c99d768f  vmovaps xmm8, [rsp+0x70]
00007dd8c99d7695  vmovaps xmm9, [rsp+0x80]
00007dd8c99d769e  vmovaps xmm10, [rsp+0x90]
00007dd8c99d76a7  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d76b0  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d76b9  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d76c2  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d76cb  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d76d4  add rsp, 0xF0
00007dd8c99d76db  pop r11
00007dd8c99d76dd  pop r10
00007dd8c99d76df  pop r9
00007dd8c99d76e1  pop r8
00007dd8c99d76e3  pop rsi
00007dd8c99d76e4  pop rdi
00007dd8c99d76e5  pop rdx
00007dd8c99d76e6  pop rcx
00007dd8c99d76e7  pop rax
00007dd8c99d76e8  add rsp, 0x08
00007dd8c99d76ec  jmp 0x00007DD8C99D5CA7
00007dd8c99d76f1  sub rsp, 0x08
00007dd8c99d76f5  push rax
00007dd8c99d76f6  push rcx
00007dd8c99d76f7  push rdx
00007dd8c99d76f8  push rdi
00007dd8c99d76f9  push rsi
00007dd8c99d76fa  push r8
00007dd8c99d76fc  push r9
00007dd8c99d76fe  push r10
00007dd8c99d7700  push r11
00007dd8c99d7702  sub rsp, 0xF0
00007dd8c99d7709  vmovaps [rsp], xmm0
00007dd8c99d770e  vmovaps [rsp+0x10], xmm1
00007dd8c99d7714  vmovaps [rsp+0x20], xmm2
00007dd8c99d771a  vmovaps [rsp+0x30], xmm3
00007dd8c99d7720  vmovaps [rsp+0x40], xmm4
00007dd8c99d7726  vmovaps [rsp+0x50], xmm5
00007dd8c99d772c  vmovaps [rsp+0x60], xmm6
00007dd8c99d7732  vmovaps [rsp+0x70], xmm8
00007dd8c99d7738  vmovaps [rsp+0x80], xmm9
00007dd8c99d7741  vmovaps [rsp+0x90], xmm10
00007dd8c99d774a  vmovaps [rsp+0xA0], xmm11
00007dd8c99d7753  vmovaps [rsp+0xB0], xmm12
00007dd8c99d775c  vmovaps [rsp+0xC0], xmm13
00007dd8c99d7765  vmovaps [rsp+0xD0], xmm14
00007dd8c99d776e  vmovaps [rsp+0xE0], xmm15
00007dd8c99d7777  sub rsp, 0x30
00007dd8c99d777b  movaps [rsp], xmm7
00007dd8c99d777f  movaps [rsp+0x10], xmm4
00007dd8c99d7784  movaps [rsp+0x20], xmm9
00007dd8c99d778a  lea rdi, [rsp]
00007dd8c99d778e  mov esi, 0x00
00007dd8c99d7793  mov rax, 0x55FEBBDB5530
00007dd8c99d779d  call rax
00007dd8c99d779f  movaps xmm7, [rsp]
00007dd8c99d77a3  add rsp, 0x30
00007dd8c99d77a7  vmovaps xmm0, [rsp]
00007dd8c99d77ac  vmovaps xmm1, [rsp+0x10]
00007dd8c99d77b2  vmovaps xmm2, [rsp+0x20]
00007dd8c99d77b8  vmovaps xmm3, [rsp+0x30]
00007dd8c99d77be  vmovaps xmm4, [rsp+0x40]
00007dd8c99d77c4  vmovaps xmm5, [rsp+0x50]
00007dd8c99d77ca  vmovaps xmm6, [rsp+0x60]
00007dd8c99d77d0  vmovaps xmm8, [rsp+0x70]
00007dd8c99d77d6  vmovaps xmm9, [rsp+0x80]
00007dd8c99d77df  vmovaps xmm10, [rsp+0x90]
00007dd8c99d77e8  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d77f1  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d77fa  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d7803  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d780c  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d7815  add rsp, 0xF0
00007dd8c99d781c  pop r11
00007dd8c99d781e  pop r10
00007dd8c99d7820  pop r9
00007dd8c99d7822  pop r8
00007dd8c99d7824  pop rsi
00007dd8c99d7825  pop rdi
00007dd8c99d7826  pop rdx
00007dd8c99d7827  pop rcx
00007dd8c99d7828  pop rax
00007dd8c99d7829  add rsp, 0x08
00007dd8c99d782d  jmp 0x00007DD8C99D5CD4
00007dd8c99d7832  sub rsp, 0x08
00007dd8c99d7836  push rax
00007dd8c99d7837  push rcx
00007dd8c99d7838  push rdx
00007dd8c99d7839  push rdi
00007dd8c99d783a  push rsi
00007dd8c99d783b  push r8
00007dd8c99d783d  push r9
00007dd8c99d783f  push r10
00007dd8c99d7841  push r11
00007dd8c99d7843  sub rsp, 0xF0
00007dd8c99d784a  vmovaps [rsp], xmm0
00007dd8c99d784f  vmovaps [rsp+0x10], xmm1
00007dd8c99d7855  vmovaps [rsp+0x20], xmm2
00007dd8c99d785b  vmovaps [rsp+0x30], xmm3
00007dd8c99d7861  vmovaps [rsp+0x40], xmm5
00007dd8c99d7867  vmovaps [rsp+0x50], xmm6
00007dd8c99d786d  vmovaps [rsp+0x60], xmm7
00007dd8c99d7873  vmovaps [rsp+0x70], xmm8
00007dd8c99d7879  vmovaps [rsp+0x80], xmm9
00007dd8c99d7882  vmovaps [rsp+0x90], xmm10
00007dd8c99d788b  vmovaps [rsp+0xA0], xmm11
00007dd8c99d7894  vmovaps [rsp+0xB0], xmm12
00007dd8c99d789d  vmovaps [rsp+0xC0], xmm13
00007dd8c99d78a6  vmovaps [rsp+0xD0], xmm14
00007dd8c99d78af  vmovaps [rsp+0xE0], xmm15
00007dd8c99d78b8  sub rsp, 0x30
00007dd8c99d78bc  movaps [rsp], xmm4
00007dd8c99d78c0  movaps [rsp+0x10], xmm15
00007dd8c99d78c6  movaps [rsp+0x20], xmm9
00007dd8c99d78cc  lea rdi, [rsp]
00007dd8c99d78d0  mov esi, 0x00
00007dd8c99d78d5  mov rax, 0x55FEBBDB5530
00007dd8c99d78df  call rax
00007dd8c99d78e1  movaps xmm4, [rsp]
00007dd8c99d78e5  add rsp, 0x30
00007dd8c99d78e9  vmovaps xmm0, [rsp]
00007dd8c99d78ee  vmovaps xmm1, [rsp+0x10]
00007dd8c99d78f4  vmovaps xmm2, [rsp+0x20]
00007dd8c99d78fa  vmovaps xmm3, [rsp+0x30]
00007dd8c99d7900  vmovaps xmm5, [rsp+0x40]
00007dd8c99d7906  vmovaps xmm6, [rsp+0x50]
00007dd8c99d790c  vmovaps xmm7, [rsp+0x60]
00007dd8c99d7912  vmovaps xmm8, [rsp+0x70]
00007dd8c99d7918  vmovaps xmm9, [rsp+0x80]
00007dd8c99d7921  vmovaps xmm10, [rsp+0x90]
00007dd8c99d792a  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d7933  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d793c  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d7945  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d794e  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d7957  add rsp, 0xF0
00007dd8c99d795e  pop r11
00007dd8c99d7960  pop r10
00007dd8c99d7962  pop r9
00007dd8c99d7964  pop r8
00007dd8c99d7966  pop rsi
00007dd8c99d7967  pop rdi
00007dd8c99d7968  pop rdx
00007dd8c99d7969  pop rcx
00007dd8c99d796a  pop rax
00007dd8c99d796b  add rsp, 0x08
00007dd8c99d796f  jmp 0x00007DD8C99D5CF9
00007dd8c99d7974  call 0x00007DD8C98E5820
00007dd8c99d7979  jmp 0x00007DD8C99D5D06
00007dd8c99d797e  sub rsp, 0x08
00007dd8c99d7982  push rax
00007dd8c99d7983  push rcx
00007dd8c99d7984  push rdx
00007dd8c99d7985  push rdi
00007dd8c99d7986  push rsi
00007dd8c99d7987  push r8
00007dd8c99d7989  push r9
00007dd8c99d798b  push r10
00007dd8c99d798d  push r11
00007dd8c99d798f  sub rsp, 0xF0
00007dd8c99d7996  vmovaps [rsp], xmm0
00007dd8c99d799b  vmovaps [rsp+0x10], xmm1
00007dd8c99d79a1  vmovaps [rsp+0x20], xmm2
00007dd8c99d79a7  vmovaps [rsp+0x30], xmm4
00007dd8c99d79ad  vmovaps [rsp+0x40], xmm5
00007dd8c99d79b3  vmovaps [rsp+0x50], xmm6
00007dd8c99d79b9  vmovaps [rsp+0x60], xmm7
00007dd8c99d79bf  vmovaps [rsp+0x70], xmm8
00007dd8c99d79c5  vmovaps [rsp+0x80], xmm9
00007dd8c99d79ce  vmovaps [rsp+0x90], xmm10
00007dd8c99d79d7  vmovaps [rsp+0xA0], xmm11
00007dd8c99d79e0  vmovaps [rsp+0xB0], xmm12
00007dd8c99d79e9  vmovaps [rsp+0xC0], xmm13
00007dd8c99d79f2  vmovaps [rsp+0xD0], xmm14
00007dd8c99d79fb  vmovaps [rsp+0xE0], xmm15
00007dd8c99d7a04  sub rsp, 0x30
00007dd8c99d7a08  movaps [rsp], xmm3
00007dd8c99d7a0c  movaps [rsp+0x10], xmm1
00007dd8c99d7a11  movaps [rsp+0x20], xmm9
00007dd8c99d7a17  lea rdi, [rsp]
00007dd8c99d7a1b  mov esi, 0x00
00007dd8c99d7a20  mov rax, 0x55FEBBDB5530
00007dd8c99d7a2a  call rax
00007dd8c99d7a2c  movaps xmm3, [rsp]
00007dd8c99d7a30  add rsp, 0x30
00007dd8c99d7a34  vmovaps xmm0, [rsp]
00007dd8c99d7a39  vmovaps xmm1, [rsp+0x10]
00007dd8c99d7a3f  vmovaps xmm2, [rsp+0x20]
00007dd8c99d7a45  vmovaps xmm4, [rsp+0x30]
00007dd8c99d7a4b  vmovaps xmm5, [rsp+0x40]
00007dd8c99d7a51  vmovaps xmm6, [rsp+0x50]
00007dd8c99d7a57  vmovaps xmm7, [rsp+0x60]
00007dd8c99d7a5d  vmovaps xmm8, [rsp+0x70]
00007dd8c99d7a63  vmovaps xmm9, [rsp+0x80]
00007dd8c99d7a6c  vmovaps xmm10, [rsp+0x90]
00007dd8c99d7a75  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d7a7e  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d7a87  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d7a90  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d7a99  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d7aa2  add rsp, 0xF0
00007dd8c99d7aa9  pop r11
00007dd8c99d7aab  pop r10
00007dd8c99d7aad  pop r9
00007dd8c99d7aaf  pop r8
00007dd8c99d7ab1  pop rsi
00007dd8c99d7ab2  pop rdi
00007dd8c99d7ab3  pop rdx
00007dd8c99d7ab4  pop rcx
00007dd8c99d7ab5  pop rax
00007dd8c99d7ab6  add rsp, 0x08
00007dd8c99d7aba  jmp 0x00007DD8C99D5D43
00007dd8c99d7abf  sub rsp, 0x08
00007dd8c99d7ac3  push rax
00007dd8c99d7ac4  push rcx
00007dd8c99d7ac5  push rdx
00007dd8c99d7ac6  push rdi
00007dd8c99d7ac7  push rsi
00007dd8c99d7ac8  push r8
00007dd8c99d7aca  push r9
00007dd8c99d7acc  push r10
00007dd8c99d7ace  push r11
00007dd8c99d7ad0  sub rsp, 0xF0
00007dd8c99d7ad7  vmovaps [rsp], xmm0
00007dd8c99d7adc  vmovaps [rsp+0x10], xmm2
00007dd8c99d7ae2  vmovaps [rsp+0x20], xmm3
00007dd8c99d7ae8  vmovaps [rsp+0x30], xmm4
00007dd8c99d7aee  vmovaps [rsp+0x40], xmm5
00007dd8c99d7af4  vmovaps [rsp+0x50], xmm6
00007dd8c99d7afa  vmovaps [rsp+0x60], xmm7
00007dd8c99d7b00  vmovaps [rsp+0x70], xmm8
00007dd8c99d7b06  vmovaps [rsp+0x80], xmm9
00007dd8c99d7b0f  vmovaps [rsp+0x90], xmm10
00007dd8c99d7b18  vmovaps [rsp+0xA0], xmm11
00007dd8c99d7b21  vmovaps [rsp+0xB0], xmm12
00007dd8c99d7b2a  vmovaps [rsp+0xC0], xmm13
00007dd8c99d7b33  vmovaps [rsp+0xD0], xmm14
00007dd8c99d7b3c  vmovaps [rsp+0xE0], xmm15
00007dd8c99d7b45  sub rsp, 0x30
00007dd8c99d7b49  movaps [rsp], xmm1
00007dd8c99d7b4d  movaps [rsp+0x10], xmm15
00007dd8c99d7b53  movaps [rsp+0x20], xmm9
00007dd8c99d7b59  lea rdi, [rsp]
00007dd8c99d7b5d  mov esi, 0x00
00007dd8c99d7b62  mov rax, 0x55FEBBDB5530
00007dd8c99d7b6c  call rax
00007dd8c99d7b6e  movaps xmm1, [rsp]
00007dd8c99d7b72  add rsp, 0x30
00007dd8c99d7b76  vmovaps xmm0, [rsp]
00007dd8c99d7b7b  vmovaps xmm2, [rsp+0x10]
00007dd8c99d7b81  vmovaps xmm3, [rsp+0x20]
00007dd8c99d7b87  vmovaps xmm4, [rsp+0x30]
00007dd8c99d7b8d  vmovaps xmm5, [rsp+0x40]
00007dd8c99d7b93  vmovaps xmm6, [rsp+0x50]
00007dd8c99d7b99  vmovaps xmm7, [rsp+0x60]
00007dd8c99d7b9f  vmovaps xmm8, [rsp+0x70]
00007dd8c99d7ba5  vmovaps xmm9, [rsp+0x80]
00007dd8c99d7bae  vmovaps xmm10, [rsp+0x90]
00007dd8c99d7bb7  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d7bc0  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d7bc9  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d7bd2  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d7bdb  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d7be4  add rsp, 0xF0
00007dd8c99d7beb  pop r11
00007dd8c99d7bed  pop r10
00007dd8c99d7bef  pop r9
00007dd8c99d7bf1  pop r8
00007dd8c99d7bf3  pop rsi
00007dd8c99d7bf4  pop rdi
00007dd8c99d7bf5  pop rdx
00007dd8c99d7bf6  pop rcx
00007dd8c99d7bf7  pop rax
00007dd8c99d7bf8  add rsp, 0x08
00007dd8c99d7bfc  jmp 0x00007DD8C99D5DCB
00007dd8c99d7c01  call 0x00007DD8C98E5820
00007dd8c99d7c06  jmp 0x00007DD8C99D5DD8
00007dd8c99d7c0b  sub rsp, 0x08
00007dd8c99d7c0f  push rax
00007dd8c99d7c10  push rcx
00007dd8c99d7c11  push rdx
00007dd8c99d7c12  push rdi
00007dd8c99d7c13  push rsi
00007dd8c99d7c14  push r8
00007dd8c99d7c16  push r9
00007dd8c99d7c18  push r10
00007dd8c99d7c1a  push r11
00007dd8c99d7c1c  sub rsp, 0xF0
00007dd8c99d7c23  vmovaps [rsp], xmm0
00007dd8c99d7c28  vmovaps [rsp+0x10], xmm2
00007dd8c99d7c2e  vmovaps [rsp+0x20], xmm3
00007dd8c99d7c34  vmovaps [rsp+0x30], xmm4
00007dd8c99d7c3a  vmovaps [rsp+0x40], xmm5
00007dd8c99d7c40  vmovaps [rsp+0x50], xmm6
00007dd8c99d7c46  vmovaps [rsp+0x60], xmm7
00007dd8c99d7c4c  vmovaps [rsp+0x70], xmm8
00007dd8c99d7c52  vmovaps [rsp+0x80], xmm9
00007dd8c99d7c5b  vmovaps [rsp+0x90], xmm10
00007dd8c99d7c64  vmovaps [rsp+0xA0], xmm11
00007dd8c99d7c6d  vmovaps [rsp+0xB0], xmm12
00007dd8c99d7c76  vmovaps [rsp+0xC0], xmm13
00007dd8c99d7c7f  vmovaps [rsp+0xD0], xmm14
00007dd8c99d7c88  vmovaps [rsp+0xE0], xmm15
00007dd8c99d7c91  sub rsp, 0x30
00007dd8c99d7c95  movaps [rsp], xmm1
00007dd8c99d7c99  movaps [rsp+0x10], xmm5
00007dd8c99d7c9e  movaps [rsp+0x20], xmm7
00007dd8c99d7ca3  lea rdi, [rsp]
00007dd8c99d7ca7  mov esi, 0x00
00007dd8c99d7cac  mov rax, 0x55FEBBDB5530
00007dd8c99d7cb6  call rax
00007dd8c99d7cb8  movaps xmm1, [rsp]
00007dd8c99d7cbc  add rsp, 0x30
00007dd8c99d7cc0  vmovaps xmm0, [rsp]
00007dd8c99d7cc5  vmovaps xmm2, [rsp+0x10]
00007dd8c99d7ccb  vmovaps xmm3, [rsp+0x20]
00007dd8c99d7cd1  vmovaps xmm4, [rsp+0x30]
00007dd8c99d7cd7  vmovaps xmm5, [rsp+0x40]
00007dd8c99d7cdd  vmovaps xmm6, [rsp+0x50]
00007dd8c99d7ce3  vmovaps xmm7, [rsp+0x60]
00007dd8c99d7ce9  vmovaps xmm8, [rsp+0x70]
00007dd8c99d7cef  vmovaps xmm9, [rsp+0x80]
00007dd8c99d7cf8  vmovaps xmm10, [rsp+0x90]
00007dd8c99d7d01  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d7d0a  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d7d13  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d7d1c  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d7d25  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d7d2e  add rsp, 0xF0
00007dd8c99d7d35  pop r11
00007dd8c99d7d37  pop r10
00007dd8c99d7d39  pop r9
00007dd8c99d7d3b  pop r8
00007dd8c99d7d3d  pop rsi
00007dd8c99d7d3e  pop rdi
00007dd8c99d7d3f  pop rdx
00007dd8c99d7d40  pop rcx
00007dd8c99d7d41  pop rax
00007dd8c99d7d42  add rsp, 0x08
00007dd8c99d7d46  jmp 0x00007DD8C99D5E7D
00007dd8c99d7d4b  sub rsp, 0x08
00007dd8c99d7d4f  push rax
00007dd8c99d7d50  push rcx
00007dd8c99d7d51  push rdx
00007dd8c99d7d52  push rdi
00007dd8c99d7d53  push rsi
00007dd8c99d7d54  push r8
00007dd8c99d7d56  push r9
00007dd8c99d7d58  push r10
00007dd8c99d7d5a  push r11
00007dd8c99d7d5c  sub rsp, 0xF0
00007dd8c99d7d63  vmovaps [rsp], xmm0
00007dd8c99d7d68  vmovaps [rsp+0x10], xmm1
00007dd8c99d7d6e  vmovaps [rsp+0x20], xmm2
00007dd8c99d7d74  vmovaps [rsp+0x30], xmm3
00007dd8c99d7d7a  vmovaps [rsp+0x40], xmm4
00007dd8c99d7d80  vmovaps [rsp+0x50], xmm5
00007dd8c99d7d86  vmovaps [rsp+0x60], xmm6
00007dd8c99d7d8c  vmovaps [rsp+0x70], xmm8
00007dd8c99d7d92  vmovaps [rsp+0x80], xmm9
00007dd8c99d7d9b  vmovaps [rsp+0x90], xmm10
00007dd8c99d7da4  vmovaps [rsp+0xA0], xmm11
00007dd8c99d7dad  vmovaps [rsp+0xB0], xmm12
00007dd8c99d7db6  vmovaps [rsp+0xC0], xmm13
00007dd8c99d7dbf  vmovaps [rsp+0xD0], xmm14
00007dd8c99d7dc8  vmovaps [rsp+0xE0], xmm15
00007dd8c99d7dd1  sub rsp, 0x30
00007dd8c99d7dd5  movaps [rsp], xmm7
00007dd8c99d7dd9  movaps [rsp+0x10], xmm5
00007dd8c99d7dde  movaps [rsp+0x20], xmm15
00007dd8c99d7de4  lea rdi, [rsp]
00007dd8c99d7de8  mov esi, 0x00
00007dd8c99d7ded  mov rax, 0x55FEBBDB5530
00007dd8c99d7df7  call rax
00007dd8c99d7df9  movaps xmm7, [rsp]
00007dd8c99d7dfd  add rsp, 0x30
00007dd8c99d7e01  vmovaps xmm0, [rsp]
00007dd8c99d7e06  vmovaps xmm1, [rsp+0x10]
00007dd8c99d7e0c  vmovaps xmm2, [rsp+0x20]
00007dd8c99d7e12  vmovaps xmm3, [rsp+0x30]
00007dd8c99d7e18  vmovaps xmm4, [rsp+0x40]
00007dd8c99d7e1e  vmovaps xmm5, [rsp+0x50]
00007dd8c99d7e24  vmovaps xmm6, [rsp+0x60]
00007dd8c99d7e2a  vmovaps xmm8, [rsp+0x70]
00007dd8c99d7e30  vmovaps xmm9, [rsp+0x80]
00007dd8c99d7e39  vmovaps xmm10, [rsp+0x90]
00007dd8c99d7e42  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d7e4b  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d7e54  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d7e5d  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d7e66  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d7e6f  add rsp, 0xF0
00007dd8c99d7e76  pop r11
00007dd8c99d7e78  pop r10
00007dd8c99d7e7a  pop r9
00007dd8c99d7e7c  pop r8
00007dd8c99d7e7e  pop rsi
00007dd8c99d7e7f  pop rdi
00007dd8c99d7e80  pop rdx
00007dd8c99d7e81  pop rcx
00007dd8c99d7e82  pop rax
00007dd8c99d7e83  add rsp, 0x08
00007dd8c99d7e87  jmp 0x00007DD8C99D5EB3
00007dd8c99d7e8c  call 0x00007DD8C98D64F0
00007dd8c99d7e91  jmp 0x00007DD8C99D5EC0
00007dd8c99d7e96  sub rsp, 0x08
00007dd8c99d7e9a  push rax
00007dd8c99d7e9b  push rcx
00007dd8c99d7e9c  push rdx
00007dd8c99d7e9d  push rdi
00007dd8c99d7e9e  push rsi
00007dd8c99d7e9f  push r8
00007dd8c99d7ea1  push r9
00007dd8c99d7ea3  push r10
00007dd8c99d7ea5  push r11
00007dd8c99d7ea7  sub rsp, 0xF0
00007dd8c99d7eae  vmovaps [rsp], xmm0
00007dd8c99d7eb3  vmovaps [rsp+0x10], xmm1
00007dd8c99d7eb9  vmovaps [rsp+0x20], xmm2
00007dd8c99d7ebf  vmovaps [rsp+0x30], xmm3
00007dd8c99d7ec5  vmovaps [rsp+0x40], xmm4
00007dd8c99d7ecb  vmovaps [rsp+0x50], xmm5
00007dd8c99d7ed1  vmovaps [rsp+0x60], xmm6
00007dd8c99d7ed7  vmovaps [rsp+0x70], xmm7
00007dd8c99d7edd  vmovaps [rsp+0x80], xmm8
00007dd8c99d7ee6  vmovaps [rsp+0x90], xmm9
00007dd8c99d7eef  vmovaps [rsp+0xA0], xmm10
00007dd8c99d7ef8  vmovaps [rsp+0xB0], xmm11
00007dd8c99d7f01  vmovaps [rsp+0xC0], xmm12
00007dd8c99d7f0a  vmovaps [rsp+0xD0], xmm13
00007dd8c99d7f13  vmovaps [rsp+0xE0], xmm14
00007dd8c99d7f1c  sub rsp, 0x30
00007dd8c99d7f20  movaps [rsp], xmm15
00007dd8c99d7f25  movaps [rsp+0x10], xmm5
00007dd8c99d7f2a  movaps [rsp+0x20], xmm3
00007dd8c99d7f2f  lea rdi, [rsp]
00007dd8c99d7f33  mov esi, 0x00
00007dd8c99d7f38  mov rax, 0x55FEBBDB5530
00007dd8c99d7f42  call rax
00007dd8c99d7f44  movaps xmm15, [rsp]
00007dd8c99d7f49  add rsp, 0x30
00007dd8c99d7f4d  vmovaps xmm0, [rsp]
00007dd8c99d7f52  vmovaps xmm1, [rsp+0x10]
00007dd8c99d7f58  vmovaps xmm2, [rsp+0x20]
00007dd8c99d7f5e  vmovaps xmm3, [rsp+0x30]
00007dd8c99d7f64  vmovaps xmm4, [rsp+0x40]
00007dd8c99d7f6a  vmovaps xmm5, [rsp+0x50]
00007dd8c99d7f70  vmovaps xmm6, [rsp+0x60]
00007dd8c99d7f76  vmovaps xmm7, [rsp+0x70]
00007dd8c99d7f7c  vmovaps xmm8, [rsp+0x80]
00007dd8c99d7f85  vmovaps xmm9, [rsp+0x90]
00007dd8c99d7f8e  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d7f97  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d7fa0  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d7fa9  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d7fb2  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d7fbb  add rsp, 0xF0
00007dd8c99d7fc2  pop r11
00007dd8c99d7fc4  pop r10
00007dd8c99d7fc6  pop r9
00007dd8c99d7fc8  pop r8
00007dd8c99d7fca  pop rsi
00007dd8c99d7fcb  pop rdi
00007dd8c99d7fcc  pop rdx
00007dd8c99d7fcd  pop rcx
00007dd8c99d7fce  pop rax
00007dd8c99d7fcf  add rsp, 0x08
00007dd8c99d7fd3  jmp 0x00007DD8C99D5EE6
00007dd8c99d7fd8  sub rsp, 0x08
00007dd8c99d7fdc  push rax
00007dd8c99d7fdd  push rcx
00007dd8c99d7fde  push rdx
00007dd8c99d7fdf  push rdi
00007dd8c99d7fe0  push rsi
00007dd8c99d7fe1  push r8
00007dd8c99d7fe3  push r9
00007dd8c99d7fe5  push r10
00007dd8c99d7fe7  push r11
00007dd8c99d7fe9  sub rsp, 0xF0
00007dd8c99d7ff0  vmovaps [rsp], xmm0
00007dd8c99d7ff5  vmovaps [rsp+0x10], xmm2
00007dd8c99d7ffb  vmovaps [rsp+0x20], xmm3
00007dd8c99d8001  vmovaps [rsp+0x30], xmm4
00007dd8c99d8007  vmovaps [rsp+0x40], xmm5
00007dd8c99d800d  vmovaps [rsp+0x50], xmm6
00007dd8c99d8013  vmovaps [rsp+0x60], xmm7
00007dd8c99d8019  vmovaps [rsp+0x70], xmm8
00007dd8c99d801f  vmovaps [rsp+0x80], xmm9
00007dd8c99d8028  vmovaps [rsp+0x90], xmm10
00007dd8c99d8031  vmovaps [rsp+0xA0], xmm11
00007dd8c99d803a  vmovaps [rsp+0xB0], xmm12
00007dd8c99d8043  vmovaps [rsp+0xC0], xmm13
00007dd8c99d804c  vmovaps [rsp+0xD0], xmm14
00007dd8c99d8055  vmovaps [rsp+0xE0], xmm15
00007dd8c99d805e  sub rsp, 0x30
00007dd8c99d8062  movaps [rsp], xmm1
00007dd8c99d8066  movaps [rsp+0x10], xmm5
00007dd8c99d806b  movaps [rsp+0x20], xmm4
00007dd8c99d8070  lea rdi, [rsp]
00007dd8c99d8074  mov esi, 0x00
00007dd8c99d8079  mov rax, 0x55FEBBDB5530
00007dd8c99d8083  call rax
00007dd8c99d8085  movaps xmm1, [rsp]
00007dd8c99d8089  add rsp, 0x30
00007dd8c99d808d  vmovaps xmm0, [rsp]
00007dd8c99d8092  vmovaps xmm2, [rsp+0x10]
00007dd8c99d8098  vmovaps xmm3, [rsp+0x20]
00007dd8c99d809e  vmovaps xmm4, [rsp+0x30]
00007dd8c99d80a4  vmovaps xmm5, [rsp+0x40]
00007dd8c99d80aa  vmovaps xmm6, [rsp+0x50]
00007dd8c99d80b0  vmovaps xmm7, [rsp+0x60]
00007dd8c99d80b6  vmovaps xmm8, [rsp+0x70]
00007dd8c99d80bc  vmovaps xmm9, [rsp+0x80]
00007dd8c99d80c5  vmovaps xmm10, [rsp+0x90]
00007dd8c99d80ce  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d80d7  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d80e0  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d80e9  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d80f2  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d80fb  add rsp, 0xF0
00007dd8c99d8102  pop r11
00007dd8c99d8104  pop r10
00007dd8c99d8106  pop r9
00007dd8c99d8108  pop r8
00007dd8c99d810a  pop rsi
00007dd8c99d810b  pop rdi
00007dd8c99d810c  pop rdx
00007dd8c99d810d  pop rcx
00007dd8c99d810e  pop rax
00007dd8c99d810f  add rsp, 0x08
00007dd8c99d8113  jmp 0x00007DD8C99D5F06
00007dd8c99d8118  sub rsp, 0x08
00007dd8c99d811c  push rax
00007dd8c99d811d  push rcx
00007dd8c99d811e  push rdx
00007dd8c99d811f  push rdi
00007dd8c99d8120  push rsi
00007dd8c99d8121  push r8
00007dd8c99d8123  push r9
00007dd8c99d8125  push r10
00007dd8c99d8127  push r11
00007dd8c99d8129  sub rsp, 0xF0
00007dd8c99d8130  vmovaps [rsp], xmm0
00007dd8c99d8135  vmovaps [rsp+0x10], xmm1
00007dd8c99d813b  vmovaps [rsp+0x20], xmm2
00007dd8c99d8141  vmovaps [rsp+0x30], xmm3
00007dd8c99d8147  vmovaps [rsp+0x40], xmm5
00007dd8c99d814d  vmovaps [rsp+0x50], xmm6
00007dd8c99d8153  vmovaps [rsp+0x60], xmm7
00007dd8c99d8159  vmovaps [rsp+0x70], xmm8
00007dd8c99d815f  vmovaps [rsp+0x80], xmm9
00007dd8c99d8168  vmovaps [rsp+0x90], xmm10
00007dd8c99d8171  vmovaps [rsp+0xA0], xmm11
00007dd8c99d817a  vmovaps [rsp+0xB0], xmm12
00007dd8c99d8183  vmovaps [rsp+0xC0], xmm13
00007dd8c99d818c  vmovaps [rsp+0xD0], xmm14
00007dd8c99d8195  vmovaps [rsp+0xE0], xmm15
00007dd8c99d819e  sub rsp, 0x30
00007dd8c99d81a2  movaps [rsp], xmm4
00007dd8c99d81a6  movaps [rsp+0x10], xmm3
00007dd8c99d81ab  movaps [rsp+0x20], xmm5
00007dd8c99d81b0  lea rdi, [rsp]
00007dd8c99d81b4  mov esi, 0x00
00007dd8c99d81b9  mov rax, 0x55FEBBDB5530
00007dd8c99d81c3  call rax
00007dd8c99d81c5  movaps xmm4, [rsp]
00007dd8c99d81c9  add rsp, 0x30
00007dd8c99d81cd  vmovaps xmm0, [rsp]
00007dd8c99d81d2  vmovaps xmm1, [rsp+0x10]
00007dd8c99d81d8  vmovaps xmm2, [rsp+0x20]
00007dd8c99d81de  vmovaps xmm3, [rsp+0x30]
00007dd8c99d81e4  vmovaps xmm5, [rsp+0x40]
00007dd8c99d81ea  vmovaps xmm6, [rsp+0x50]
00007dd8c99d81f0  vmovaps xmm7, [rsp+0x60]
00007dd8c99d81f6  vmovaps xmm8, [rsp+0x70]
00007dd8c99d81fc  vmovaps xmm9, [rsp+0x80]
00007dd8c99d8205  vmovaps xmm10, [rsp+0x90]
00007dd8c99d820e  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d8217  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d8220  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d8229  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d8232  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d823b  add rsp, 0xF0
00007dd8c99d8242  pop r11
00007dd8c99d8244  pop r10
00007dd8c99d8246  pop r9
00007dd8c99d8248  pop r8
00007dd8c99d824a  pop rsi
00007dd8c99d824b  pop rdi
00007dd8c99d824c  pop rdx
00007dd8c99d824d  pop rcx
00007dd8c99d824e  pop rax
00007dd8c99d824f  add rsp, 0x08
00007dd8c99d8253  jmp 0x00007DD8C99D5F54
00007dd8c99d8258  call 0x00007DD8C98D64F0
00007dd8c99d825d  jmp 0x00007DD8C99D5F61
00007dd8c99d8262  sub rsp, 0x08
00007dd8c99d8266  push rax
00007dd8c99d8267  push rcx
00007dd8c99d8268  push rdx
00007dd8c99d8269  push rdi
00007dd8c99d826a  push rsi
00007dd8c99d826b  push r8
00007dd8c99d826d  push r9
00007dd8c99d826f  push r10
00007dd8c99d8271  push r11
00007dd8c99d8273  sub rsp, 0xF0
00007dd8c99d827a  vmovaps [rsp], xmm0
00007dd8c99d827f  vmovaps [rsp+0x10], xmm1
00007dd8c99d8285  vmovaps [rsp+0x20], xmm2
00007dd8c99d828b  vmovaps [rsp+0x30], xmm3
00007dd8c99d8291  vmovaps [rsp+0x40], xmm4
00007dd8c99d8297  vmovaps [rsp+0x50], xmm6
00007dd8c99d829d  vmovaps [rsp+0x60], xmm7
00007dd8c99d82a3  vmovaps [rsp+0x70], xmm8
00007dd8c99d82a9  vmovaps [rsp+0x80], xmm9
00007dd8c99d82b2  vmovaps [rsp+0x90], xmm10
00007dd8c99d82bb  vmovaps [rsp+0xA0], xmm11
00007dd8c99d82c4  vmovaps [rsp+0xB0], xmm12
00007dd8c99d82cd  vmovaps [rsp+0xC0], xmm13
00007dd8c99d82d6  vmovaps [rsp+0xD0], xmm14
00007dd8c99d82df  vmovaps [rsp+0xE0], xmm15
00007dd8c99d82e8  sub rsp, 0x30
00007dd8c99d82ec  movaps [rsp], xmm5
00007dd8c99d82f0  movaps [rsp+0x10], xmm6
00007dd8c99d82f5  movaps [rsp+0x20], xmm3
00007dd8c99d82fa  lea rdi, [rsp]
00007dd8c99d82fe  mov esi, 0x00
00007dd8c99d8303  mov rax, 0x55FEBBDB5530
00007dd8c99d830d  call rax
00007dd8c99d830f  movaps xmm5, [rsp]
00007dd8c99d8313  add rsp, 0x30
00007dd8c99d8317  vmovaps xmm0, [rsp]
00007dd8c99d831c  vmovaps xmm1, [rsp+0x10]
00007dd8c99d8322  vmovaps xmm2, [rsp+0x20]
00007dd8c99d8328  vmovaps xmm3, [rsp+0x30]
00007dd8c99d832e  vmovaps xmm4, [rsp+0x40]
00007dd8c99d8334  vmovaps xmm6, [rsp+0x50]
00007dd8c99d833a  vmovaps xmm7, [rsp+0x60]
00007dd8c99d8340  vmovaps xmm8, [rsp+0x70]
00007dd8c99d8346  vmovaps xmm9, [rsp+0x80]
00007dd8c99d834f  vmovaps xmm10, [rsp+0x90]
00007dd8c99d8358  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d8361  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d836a  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d8373  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d837c  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d8385  add rsp, 0xF0
00007dd8c99d838c  pop r11
00007dd8c99d838e  pop r10
00007dd8c99d8390  pop r9
00007dd8c99d8392  pop r8
00007dd8c99d8394  pop rsi
00007dd8c99d8395  pop rdi
00007dd8c99d8396  pop rdx
00007dd8c99d8397  pop rcx
00007dd8c99d8398  pop rax
00007dd8c99d8399  add rsp, 0x08
00007dd8c99d839d  jmp 0x00007DD8C99D5F87
00007dd8c99d83a2  sub rsp, 0x08
00007dd8c99d83a6  push rax
00007dd8c99d83a7  push rcx
00007dd8c99d83a8  push rdx
00007dd8c99d83a9  push rdi
00007dd8c99d83aa  push rsi
00007dd8c99d83ab  push r8
00007dd8c99d83ad  push r9
00007dd8c99d83af  push r10
00007dd8c99d83b1  push r11
00007dd8c99d83b3  sub rsp, 0xF0
00007dd8c99d83ba  vmovaps [rsp], xmm0
00007dd8c99d83bf  vmovaps [rsp+0x10], xmm1
00007dd8c99d83c5  vmovaps [rsp+0x20], xmm2
00007dd8c99d83cb  vmovaps [rsp+0x30], xmm3
00007dd8c99d83d1  vmovaps [rsp+0x40], xmm4
00007dd8c99d83d7  vmovaps [rsp+0x50], xmm5
00007dd8c99d83dd  vmovaps [rsp+0x60], xmm7
00007dd8c99d83e3  vmovaps [rsp+0x70], xmm8
00007dd8c99d83e9  vmovaps [rsp+0x80], xmm9
00007dd8c99d83f2  vmovaps [rsp+0x90], xmm10
00007dd8c99d83fb  vmovaps [rsp+0xA0], xmm11
00007dd8c99d8404  vmovaps [rsp+0xB0], xmm12
00007dd8c99d840d  vmovaps [rsp+0xC0], xmm13
00007dd8c99d8416  vmovaps [rsp+0xD0], xmm14
00007dd8c99d841f  vmovaps [rsp+0xE0], xmm15
00007dd8c99d8428  sub rsp, 0x30
00007dd8c99d842c  movaps [rsp], xmm6
00007dd8c99d8430  movaps [rsp+0x10], xmm9
00007dd8c99d8436  movaps [rsp+0x20], xmm1
00007dd8c99d843b  lea rdi, [rsp]
00007dd8c99d843f  mov esi, 0x00
00007dd8c99d8444  mov rax, 0x55FEBBDB5530
00007dd8c99d844e  call rax
00007dd8c99d8450  movaps xmm6, [rsp]
00007dd8c99d8454  add rsp, 0x30
00007dd8c99d8458  vmovaps xmm0, [rsp]
00007dd8c99d845d  vmovaps xmm1, [rsp+0x10]
00007dd8c99d8463  vmovaps xmm2, [rsp+0x20]
00007dd8c99d8469  vmovaps xmm3, [rsp+0x30]
00007dd8c99d846f  vmovaps xmm4, [rsp+0x40]
00007dd8c99d8475  vmovaps xmm5, [rsp+0x50]
00007dd8c99d847b  vmovaps xmm7, [rsp+0x60]
00007dd8c99d8481  vmovaps xmm8, [rsp+0x70]
00007dd8c99d8487  vmovaps xmm9, [rsp+0x80]
00007dd8c99d8490  vmovaps xmm10, [rsp+0x90]
00007dd8c99d8499  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d84a2  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d84ab  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d84b4  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d84bd  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d84c6  add rsp, 0xF0
00007dd8c99d84cd  pop r11
00007dd8c99d84cf  pop r10
00007dd8c99d84d1  pop r9
00007dd8c99d84d3  pop r8
00007dd8c99d84d5  pop rsi
00007dd8c99d84d6  pop rdi
00007dd8c99d84d7  pop rdx
00007dd8c99d84d8  pop rcx
00007dd8c99d84d9  pop rax
00007dd8c99d84da  add rsp, 0x08
00007dd8c99d84de  jmp 0x00007DD8C99D5FAB
00007dd8c99d84e3  sub rsp, 0x08
00007dd8c99d84e7  push rax
00007dd8c99d84e8  push rcx
00007dd8c99d84e9  push rdx
00007dd8c99d84ea  push rdi
00007dd8c99d84eb  push rsi
00007dd8c99d84ec  push r8
00007dd8c99d84ee  push r9
00007dd8c99d84f0  push r10
00007dd8c99d84f2  push r11
00007dd8c99d84f4  sub rsp, 0xF0
00007dd8c99d84fb  vmovaps [rsp], xmm0
00007dd8c99d8500  vmovaps [rsp+0x10], xmm1
00007dd8c99d8506  vmovaps [rsp+0x20], xmm2
00007dd8c99d850c  vmovaps [rsp+0x30], xmm3
00007dd8c99d8512  vmovaps [rsp+0x40], xmm4
00007dd8c99d8518  vmovaps [rsp+0x50], xmm5
00007dd8c99d851e  vmovaps [rsp+0x60], xmm6
00007dd8c99d8524  vmovaps [rsp+0x70], xmm7
00007dd8c99d852a  vmovaps [rsp+0x80], xmm8
00007dd8c99d8533  vmovaps [rsp+0x90], xmm10
00007dd8c99d853c  vmovaps [rsp+0xA0], xmm11
00007dd8c99d8545  vmovaps [rsp+0xB0], xmm12
00007dd8c99d854e  vmovaps [rsp+0xC0], xmm13
00007dd8c99d8557  vmovaps [rsp+0xD0], xmm14
00007dd8c99d8560  vmovaps [rsp+0xE0], xmm15
00007dd8c99d8569  sub rsp, 0x30
00007dd8c99d856d  movaps [rsp], xmm9
00007dd8c99d8572  movaps [rsp+0x10], xmm3
00007dd8c99d8577  movaps [rsp+0x20], xmm1
00007dd8c99d857c  lea rdi, [rsp]
00007dd8c99d8580  mov esi, 0x00
00007dd8c99d8585  mov rax, 0x55FEBBDB5530
00007dd8c99d858f  call rax
00007dd8c99d8591  movaps xmm9, [rsp]
00007dd8c99d8596  add rsp, 0x30
00007dd8c99d859a  vmovaps xmm0, [rsp]
00007dd8c99d859f  vmovaps xmm1, [rsp+0x10]
00007dd8c99d85a5  vmovaps xmm2, [rsp+0x20]
00007dd8c99d85ab  vmovaps xmm3, [rsp+0x30]
00007dd8c99d85b1  vmovaps xmm4, [rsp+0x40]
00007dd8c99d85b7  vmovaps xmm5, [rsp+0x50]
00007dd8c99d85bd  vmovaps xmm6, [rsp+0x60]
00007dd8c99d85c3  vmovaps xmm7, [rsp+0x70]
00007dd8c99d85c9  vmovaps xmm8, [rsp+0x80]
00007dd8c99d85d2  vmovaps xmm10, [rsp+0x90]
00007dd8c99d85db  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d85e4  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d85ed  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d85f6  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d85ff  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d8608  add rsp, 0xF0
00007dd8c99d860f  pop r11
00007dd8c99d8611  pop r10
00007dd8c99d8613  pop r9
00007dd8c99d8615  pop r8
00007dd8c99d8617  pop rsi
00007dd8c99d8618  pop rdi
00007dd8c99d8619  pop rdx
00007dd8c99d861a  pop rcx
00007dd8c99d861b  pop rax
00007dd8c99d861c  add rsp, 0x08
00007dd8c99d8620  jmp 0x00007DD8C99D5FF7
00007dd8c99d8625  call 0x00007DD8C98D64F0
00007dd8c99d862a  jmp 0x00007DD8C99D6004
00007dd8c99d862f  sub rsp, 0x08
00007dd8c99d8633  push rax
00007dd8c99d8634  push rcx
00007dd8c99d8635  push rdx
00007dd8c99d8636  push rdi
00007dd8c99d8637  push rsi
00007dd8c99d8638  push r8
00007dd8c99d863a  push r9
00007dd8c99d863c  push r10
00007dd8c99d863e  push r11
00007dd8c99d8640  sub rsp, 0xF0
00007dd8c99d8647  vmovaps [rsp], xmm0
00007dd8c99d864c  vmovaps [rsp+0x10], xmm1
00007dd8c99d8652  vmovaps [rsp+0x20], xmm2
00007dd8c99d8658  vmovaps [rsp+0x30], xmm3
00007dd8c99d865e  vmovaps [rsp+0x40], xmm4
00007dd8c99d8664  vmovaps [rsp+0x50], xmm5
00007dd8c99d866a  vmovaps [rsp+0x60], xmm6
00007dd8c99d8670  vmovaps [rsp+0x70], xmm7
00007dd8c99d8676  vmovaps [rsp+0x80], xmm8
00007dd8c99d867f  vmovaps [rsp+0x90], xmm9
00007dd8c99d8688  vmovaps [rsp+0xA0], xmm10
00007dd8c99d8691  vmovaps [rsp+0xB0], xmm11
00007dd8c99d869a  vmovaps [rsp+0xC0], xmm12
00007dd8c99d86a3  vmovaps [rsp+0xD0], xmm13
00007dd8c99d86ac  vmovaps [rsp+0xE0], xmm14
00007dd8c99d86b5  sub rsp, 0x30
00007dd8c99d86b9  movaps [rsp], xmm15
00007dd8c99d86be  movaps [rsp+0x10], xmm3
00007dd8c99d86c3  movaps [rsp+0x20], xmm7
00007dd8c99d86c8  lea rdi, [rsp]
00007dd8c99d86cc  mov esi, 0x00
00007dd8c99d86d1  mov rax, 0x55FEBBDB5530
00007dd8c99d86db  call rax
00007dd8c99d86dd  movaps xmm15, [rsp]
00007dd8c99d86e2  add rsp, 0x30
00007dd8c99d86e6  vmovaps xmm0, [rsp]
00007dd8c99d86eb  vmovaps xmm1, [rsp+0x10]
00007dd8c99d86f1  vmovaps xmm2, [rsp+0x20]
00007dd8c99d86f7  vmovaps xmm3, [rsp+0x30]
00007dd8c99d86fd  vmovaps xmm4, [rsp+0x40]
00007dd8c99d8703  vmovaps xmm5, [rsp+0x50]
00007dd8c99d8709  vmovaps xmm6, [rsp+0x60]
00007dd8c99d870f  vmovaps xmm7, [rsp+0x70]
00007dd8c99d8715  vmovaps xmm8, [rsp+0x80]
00007dd8c99d871e  vmovaps xmm9, [rsp+0x90]
00007dd8c99d8727  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d8730  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d8739  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d8742  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d874b  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d8754  add rsp, 0xF0
00007dd8c99d875b  pop r11
00007dd8c99d875d  pop r10
00007dd8c99d875f  pop r9
00007dd8c99d8761  pop r8
00007dd8c99d8763  pop rsi
00007dd8c99d8764  pop rdi
00007dd8c99d8765  pop rdx
00007dd8c99d8766  pop rcx
00007dd8c99d8767  pop rax
00007dd8c99d8768  add rsp, 0x08
00007dd8c99d876c  jmp 0x00007DD8C99D6030
00007dd8c99d8771  sub rsp, 0x08
00007dd8c99d8775  push rax
00007dd8c99d8776  push rcx
00007dd8c99d8777  push rdx
00007dd8c99d8778  push rdi
00007dd8c99d8779  push rsi
00007dd8c99d877a  push r8
00007dd8c99d877c  push r9
00007dd8c99d877e  push r10
00007dd8c99d8780  push r11
00007dd8c99d8782  sub rsp, 0xF0
00007dd8c99d8789  vmovaps [rsp], xmm0
00007dd8c99d878e  vmovaps [rsp+0x10], xmm1
00007dd8c99d8794  vmovaps [rsp+0x20], xmm2
00007dd8c99d879a  vmovaps [rsp+0x30], xmm4
00007dd8c99d87a0  vmovaps [rsp+0x40], xmm5
00007dd8c99d87a6  vmovaps [rsp+0x50], xmm6
00007dd8c99d87ac  vmovaps [rsp+0x60], xmm7
00007dd8c99d87b2  vmovaps [rsp+0x70], xmm8
00007dd8c99d87b8  vmovaps [rsp+0x80], xmm9
00007dd8c99d87c1  vmovaps [rsp+0x90], xmm10
00007dd8c99d87ca  vmovaps [rsp+0xA0], xmm11
00007dd8c99d87d3  vmovaps [rsp+0xB0], xmm12
00007dd8c99d87dc  vmovaps [rsp+0xC0], xmm13
00007dd8c99d87e5  vmovaps [rsp+0xD0], xmm14
00007dd8c99d87ee  vmovaps [rsp+0xE0], xmm15
00007dd8c99d87f7  sub rsp, 0x30
00007dd8c99d87fb  movaps [rsp], xmm3
00007dd8c99d87ff  movaps [rsp+0x10], xmm1
00007dd8c99d8804  movaps [rsp+0x20], xmm15
00007dd8c99d880a  lea rdi, [rsp]
00007dd8c99d880e  mov esi, 0x00
00007dd8c99d8813  mov rax, 0x55FEBBDB5530
00007dd8c99d881d  call rax
00007dd8c99d881f  movaps xmm3, [rsp]
00007dd8c99d8823  add rsp, 0x30
00007dd8c99d8827  vmovaps xmm0, [rsp]
00007dd8c99d882c  vmovaps xmm1, [rsp+0x10]
00007dd8c99d8832  vmovaps xmm2, [rsp+0x20]
00007dd8c99d8838  vmovaps xmm4, [rsp+0x30]
00007dd8c99d883e  vmovaps xmm5, [rsp+0x40]
00007dd8c99d8844  vmovaps xmm6, [rsp+0x50]
00007dd8c99d884a  vmovaps xmm7, [rsp+0x60]
00007dd8c99d8850  vmovaps xmm8, [rsp+0x70]
00007dd8c99d8856  vmovaps xmm9, [rsp+0x80]
00007dd8c99d885f  vmovaps xmm10, [rsp+0x90]
00007dd8c99d8868  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d8871  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d887a  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d8883  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d888c  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d8895  add rsp, 0xF0
00007dd8c99d889c  pop r11
00007dd8c99d889e  pop r10
00007dd8c99d88a0  pop r9
00007dd8c99d88a2  pop r8
00007dd8c99d88a4  pop rsi
00007dd8c99d88a5  pop rdi
00007dd8c99d88a6  pop rdx
00007dd8c99d88a7  pop rcx
00007dd8c99d88a8  pop rax
00007dd8c99d88a9  add rsp, 0x08
00007dd8c99d88ad  jmp 0x00007DD8C99D60BF
00007dd8c99d88b2  call 0x00007DD8C98D64F0
00007dd8c99d88b7  jmp 0x00007DD8C99D60C9
00007dd8c99d88bc  sub rsp, 0x08
00007dd8c99d88c0  push rax
00007dd8c99d88c1  push rcx
00007dd8c99d88c2  push rdx
00007dd8c99d88c3  push rdi
00007dd8c99d88c4  push rsi
00007dd8c99d88c5  push r8
00007dd8c99d88c7  push r9
00007dd8c99d88c9  push r10
00007dd8c99d88cb  push r11
00007dd8c99d88cd  sub rsp, 0xF0
00007dd8c99d88d4  vmovaps [rsp], xmm0
00007dd8c99d88d9  vmovaps [rsp+0x10], xmm1
00007dd8c99d88df  vmovaps [rsp+0x20], xmm2
00007dd8c99d88e5  vmovaps [rsp+0x30], xmm3
00007dd8c99d88eb  vmovaps [rsp+0x40], xmm4
00007dd8c99d88f1  vmovaps [rsp+0x50], xmm5
00007dd8c99d88f7  vmovaps [rsp+0x60], xmm6
00007dd8c99d88fd  vmovaps [rsp+0x70], xmm7
00007dd8c99d8903  vmovaps [rsp+0x80], xmm8
00007dd8c99d890c  vmovaps [rsp+0x90], xmm9
00007dd8c99d8915  vmovaps [rsp+0xA0], xmm10
00007dd8c99d891e  vmovaps [rsp+0xB0], xmm11
00007dd8c99d8927  vmovaps [rsp+0xC0], xmm12
00007dd8c99d8930  vmovaps [rsp+0xD0], xmm13
00007dd8c99d8939  vmovaps [rsp+0xE0], xmm14
00007dd8c99d8942  sub rsp, 0x30
00007dd8c99d8946  movaps [rsp], xmm15
00007dd8c99d894b  movaps [rsp+0x10], xmm14
00007dd8c99d8951  movaps [rsp+0x20], xmm4
00007dd8c99d8956  lea rdi, [rsp]
00007dd8c99d895a  mov esi, 0x00
00007dd8c99d895f  mov rax, 0x55FEBBDB5530
00007dd8c99d8969  call rax
00007dd8c99d896b  movaps xmm15, [rsp]
00007dd8c99d8970  add rsp, 0x30
00007dd8c99d8974  vmovaps xmm0, [rsp]
00007dd8c99d8979  vmovaps xmm1, [rsp+0x10]
00007dd8c99d897f  vmovaps xmm2, [rsp+0x20]
00007dd8c99d8985  vmovaps xmm3, [rsp+0x30]
00007dd8c99d898b  vmovaps xmm4, [rsp+0x40]
00007dd8c99d8991  vmovaps xmm5, [rsp+0x50]
00007dd8c99d8997  vmovaps xmm6, [rsp+0x60]
00007dd8c99d899d  vmovaps xmm7, [rsp+0x70]
00007dd8c99d89a3  vmovaps xmm8, [rsp+0x80]
00007dd8c99d89ac  vmovaps xmm9, [rsp+0x90]
00007dd8c99d89b5  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d89be  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d89c7  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d89d0  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d89d9  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d89e2  add rsp, 0xF0
00007dd8c99d89e9  pop r11
00007dd8c99d89eb  pop r10
00007dd8c99d89ed  pop r9
00007dd8c99d89ef  pop r8
00007dd8c99d89f1  pop rsi
00007dd8c99d89f2  pop rdi
00007dd8c99d89f3  pop rdx
00007dd8c99d89f4  pop rcx
00007dd8c99d89f5  pop rax
00007dd8c99d89f6  add rsp, 0x08
00007dd8c99d89fa  jmp 0x00007DD8C99D60F7
00007dd8c99d89ff  sub rsp, 0x08
00007dd8c99d8a03  push rax
00007dd8c99d8a04  push rcx
00007dd8c99d8a05  push rdx
00007dd8c99d8a06  push rdi
00007dd8c99d8a07  push rsi
00007dd8c99d8a08  push r8
00007dd8c99d8a0a  push r9
00007dd8c99d8a0c  push r10
00007dd8c99d8a0e  push r11
00007dd8c99d8a10  sub rsp, 0xF0
00007dd8c99d8a17  vmovaps [rsp], xmm0
00007dd8c99d8a1c  vmovaps [rsp+0x10], xmm1
00007dd8c99d8a22  vmovaps [rsp+0x20], xmm2
00007dd8c99d8a28  vmovaps [rsp+0x30], xmm3
00007dd8c99d8a2e  vmovaps [rsp+0x40], xmm4
00007dd8c99d8a34  vmovaps [rsp+0x50], xmm5
00007dd8c99d8a3a  vmovaps [rsp+0x60], xmm6
00007dd8c99d8a40  vmovaps [rsp+0x70], xmm7
00007dd8c99d8a46  vmovaps [rsp+0x80], xmm8
00007dd8c99d8a4f  vmovaps [rsp+0x90], xmm9
00007dd8c99d8a58  vmovaps [rsp+0xA0], xmm10
00007dd8c99d8a61  vmovaps [rsp+0xB0], xmm11
00007dd8c99d8a6a  vmovaps [rsp+0xC0], xmm12
00007dd8c99d8a73  vmovaps [rsp+0xD0], xmm13
00007dd8c99d8a7c  vmovaps [rsp+0xE0], xmm15
00007dd8c99d8a85  sub rsp, 0x30
00007dd8c99d8a89  movaps [rsp], xmm14
00007dd8c99d8a8e  movaps [rsp+0x10], xmm2
00007dd8c99d8a93  movaps [rsp+0x20], xmm1
00007dd8c99d8a98  lea rdi, [rsp]
00007dd8c99d8a9c  mov esi, 0x00
00007dd8c99d8aa1  mov rax, 0x55FEBBDB5530
00007dd8c99d8aab  call rax
00007dd8c99d8aad  movaps xmm14, [rsp]
00007dd8c99d8ab2  add rsp, 0x30
00007dd8c99d8ab6  vmovaps xmm0, [rsp]
00007dd8c99d8abb  vmovaps xmm1, [rsp+0x10]
00007dd8c99d8ac1  vmovaps xmm2, [rsp+0x20]
00007dd8c99d8ac7  vmovaps xmm3, [rsp+0x30]
00007dd8c99d8acd  vmovaps xmm4, [rsp+0x40]
00007dd8c99d8ad3  vmovaps xmm5, [rsp+0x50]
00007dd8c99d8ad9  vmovaps xmm6, [rsp+0x60]
00007dd8c99d8adf  vmovaps xmm7, [rsp+0x70]
00007dd8c99d8ae5  vmovaps xmm8, [rsp+0x80]
00007dd8c99d8aee  vmovaps xmm9, [rsp+0x90]
00007dd8c99d8af7  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d8b00  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d8b09  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d8b12  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d8b1b  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d8b24  add rsp, 0xF0
00007dd8c99d8b2b  pop r11
00007dd8c99d8b2d  pop r10
00007dd8c99d8b2f  pop r9
00007dd8c99d8b31  pop r8
00007dd8c99d8b33  pop rsi
00007dd8c99d8b34  pop rdi
00007dd8c99d8b35  pop rdx
00007dd8c99d8b36  pop rcx
00007dd8c99d8b37  pop rax
00007dd8c99d8b38  add rsp, 0x08
00007dd8c99d8b3c  jmp 0x00007DD8C99D611D
00007dd8c99d8b41  sub rsp, 0x08
00007dd8c99d8b45  push rax
00007dd8c99d8b46  push rcx
00007dd8c99d8b47  push rdx
00007dd8c99d8b48  push rdi
00007dd8c99d8b49  push rsi
00007dd8c99d8b4a  push r8
00007dd8c99d8b4c  push r9
00007dd8c99d8b4e  push r10
00007dd8c99d8b50  push r11
00007dd8c99d8b52  sub rsp, 0xF0
00007dd8c99d8b59  vmovaps [rsp], xmm0
00007dd8c99d8b5e  vmovaps [rsp+0x10], xmm2
00007dd8c99d8b64  vmovaps [rsp+0x20], xmm3
00007dd8c99d8b6a  vmovaps [rsp+0x30], xmm4
00007dd8c99d8b70  vmovaps [rsp+0x40], xmm5
00007dd8c99d8b76  vmovaps [rsp+0x50], xmm6
00007dd8c99d8b7c  vmovaps [rsp+0x60], xmm7
00007dd8c99d8b82  vmovaps [rsp+0x70], xmm8
00007dd8c99d8b88  vmovaps [rsp+0x80], xmm9
00007dd8c99d8b91  vmovaps [rsp+0x90], xmm10
00007dd8c99d8b9a  vmovaps [rsp+0xA0], xmm11
00007dd8c99d8ba3  vmovaps [rsp+0xB0], xmm12
00007dd8c99d8bac  vmovaps [rsp+0xC0], xmm13
00007dd8c99d8bb5  vmovaps [rsp+0xD0], xmm14
00007dd8c99d8bbe  vmovaps [rsp+0xE0], xmm15
00007dd8c99d8bc7  sub rsp, 0x30
00007dd8c99d8bcb  movaps [rsp], xmm1
00007dd8c99d8bcf  movaps [rsp+0x10], xmm4
00007dd8c99d8bd4  movaps [rsp+0x20], xmm9
00007dd8c99d8bda  lea rdi, [rsp]
00007dd8c99d8bde  mov esi, 0x00
00007dd8c99d8be3  mov rax, 0x55FEBBDB5530
00007dd8c99d8bed  call rax
00007dd8c99d8bef  movaps xmm1, [rsp]
00007dd8c99d8bf3  add rsp, 0x30
00007dd8c99d8bf7  vmovaps xmm0, [rsp]
00007dd8c99d8bfc  vmovaps xmm2, [rsp+0x10]
00007dd8c99d8c02  vmovaps xmm3, [rsp+0x20]
00007dd8c99d8c08  vmovaps xmm4, [rsp+0x30]
00007dd8c99d8c0e  vmovaps xmm5, [rsp+0x40]
00007dd8c99d8c14  vmovaps xmm6, [rsp+0x50]
00007dd8c99d8c1a  vmovaps xmm7, [rsp+0x60]
00007dd8c99d8c20  vmovaps xmm8, [rsp+0x70]
00007dd8c99d8c26  vmovaps xmm9, [rsp+0x80]
00007dd8c99d8c2f  vmovaps xmm10, [rsp+0x90]
00007dd8c99d8c38  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d8c41  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d8c4a  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d8c53  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d8c5c  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d8c65  add rsp, 0xF0
00007dd8c99d8c6c  pop r11
00007dd8c99d8c6e  pop r10
00007dd8c99d8c70  pop r9
00007dd8c99d8c72  pop r8
00007dd8c99d8c74  pop rsi
00007dd8c99d8c75  pop rdi
00007dd8c99d8c76  pop rdx
00007dd8c99d8c77  pop rcx
00007dd8c99d8c78  pop rax
00007dd8c99d8c79  add rsp, 0x08
00007dd8c99d8c7d  jmp 0x00007DD8C99D613B
00007dd8c99d8c82  sub rsp, 0x08
00007dd8c99d8c86  push rax
00007dd8c99d8c87  push rcx
00007dd8c99d8c88  push rdx
00007dd8c99d8c89  push rdi
00007dd8c99d8c8a  push rsi
00007dd8c99d8c8b  push r8
00007dd8c99d8c8d  push r9
00007dd8c99d8c8f  push r10
00007dd8c99d8c91  push r11
00007dd8c99d8c93  sub rsp, 0xF0
00007dd8c99d8c9a  vmovaps [rsp], xmm0
00007dd8c99d8c9f  vmovaps [rsp+0x10], xmm1
00007dd8c99d8ca5  vmovaps [rsp+0x20], xmm2
00007dd8c99d8cab  vmovaps [rsp+0x30], xmm3
00007dd8c99d8cb1  vmovaps [rsp+0x40], xmm5
00007dd8c99d8cb7  vmovaps [rsp+0x50], xmm6
00007dd8c99d8cbd  vmovaps [rsp+0x60], xmm7
00007dd8c99d8cc3  vmovaps [rsp+0x70], xmm8
00007dd8c99d8cc9  vmovaps [rsp+0x80], xmm9
00007dd8c99d8cd2  vmovaps [rsp+0x90], xmm10
00007dd8c99d8cdb  vmovaps [rsp+0xA0], xmm11
00007dd8c99d8ce4  vmovaps [rsp+0xB0], xmm12
00007dd8c99d8ced  vmovaps [rsp+0xC0], xmm13
00007dd8c99d8cf6  vmovaps [rsp+0xD0], xmm14
00007dd8c99d8cff  vmovaps [rsp+0xE0], xmm15
00007dd8c99d8d08  sub rsp, 0x30
00007dd8c99d8d0c  movaps [rsp], xmm4
00007dd8c99d8d10  movaps [rsp+0x10], xmm2
00007dd8c99d8d15  movaps [rsp+0x20], xmm9
00007dd8c99d8d1b  lea rdi, [rsp]
00007dd8c99d8d1f  mov esi, 0x00
00007dd8c99d8d24  mov rax, 0x55FEBBDB5530
00007dd8c99d8d2e  call rax
00007dd8c99d8d30  movaps xmm4, [rsp]
00007dd8c99d8d34  add rsp, 0x30
00007dd8c99d8d38  vmovaps xmm0, [rsp]
00007dd8c99d8d3d  vmovaps xmm1, [rsp+0x10]
00007dd8c99d8d43  vmovaps xmm2, [rsp+0x20]
00007dd8c99d8d49  vmovaps xmm3, [rsp+0x30]
00007dd8c99d8d4f  vmovaps xmm5, [rsp+0x40]
00007dd8c99d8d55  vmovaps xmm6, [rsp+0x50]
00007dd8c99d8d5b  vmovaps xmm7, [rsp+0x60]
00007dd8c99d8d61  vmovaps xmm8, [rsp+0x70]
00007dd8c99d8d67  vmovaps xmm9, [rsp+0x80]
00007dd8c99d8d70  vmovaps xmm10, [rsp+0x90]
00007dd8c99d8d79  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d8d82  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d8d8b  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d8d94  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d8d9d  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d8da6  add rsp, 0xF0
00007dd8c99d8dad  pop r11
00007dd8c99d8daf  pop r10
00007dd8c99d8db1  pop r9
00007dd8c99d8db3  pop r8
00007dd8c99d8db5  pop rsi
00007dd8c99d8db6  pop rdi
00007dd8c99d8db7  pop rdx
00007dd8c99d8db8  pop rcx
00007dd8c99d8db9  pop rax
00007dd8c99d8dba  add rsp, 0x08
00007dd8c99d8dbe  jmp 0x00007DD8C99D616B
00007dd8c99d8dc3  sub rsp, 0x08
00007dd8c99d8dc7  push rax
00007dd8c99d8dc8  push rcx
00007dd8c99d8dc9  push rdx
00007dd8c99d8dca  push rdi
00007dd8c99d8dcb  push rsi
00007dd8c99d8dcc  push r8
00007dd8c99d8dce  push r9
00007dd8c99d8dd0  push r10
00007dd8c99d8dd2  push r11
00007dd8c99d8dd4  sub rsp, 0xF0
00007dd8c99d8ddb  vmovaps [rsp], xmm0
00007dd8c99d8de0  vmovaps [rsp+0x10], xmm1
00007dd8c99d8de6  vmovaps [rsp+0x20], xmm2
00007dd8c99d8dec  vmovaps [rsp+0x30], xmm3
00007dd8c99d8df2  vmovaps [rsp+0x40], xmm4
00007dd8c99d8df8  vmovaps [rsp+0x50], xmm5
00007dd8c99d8dfe  vmovaps [rsp+0x60], xmm6
00007dd8c99d8e04  vmovaps [rsp+0x70], xmm7
00007dd8c99d8e0a  vmovaps [rsp+0x80], xmm8
00007dd8c99d8e13  vmovaps [rsp+0x90], xmm10
00007dd8c99d8e1c  vmovaps [rsp+0xA0], xmm11
00007dd8c99d8e25  vmovaps [rsp+0xB0], xmm12
00007dd8c99d8e2e  vmovaps [rsp+0xC0], xmm13
00007dd8c99d8e37  vmovaps [rsp+0xD0], xmm14
00007dd8c99d8e40  vmovaps [rsp+0xE0], xmm15
00007dd8c99d8e49  sub rsp, 0x30
00007dd8c99d8e4d  movaps [rsp], xmm9
00007dd8c99d8e52  movaps [rsp+0x10], xmm2
00007dd8c99d8e57  movaps [rsp+0x20], xmm1
00007dd8c99d8e5c  lea rdi, [rsp]
00007dd8c99d8e60  mov esi, 0x00
00007dd8c99d8e65  mov rax, 0x55FEBBDB5530
00007dd8c99d8e6f  call rax
00007dd8c99d8e71  movaps xmm9, [rsp]
00007dd8c99d8e76  add rsp, 0x30
00007dd8c99d8e7a  vmovaps xmm0, [rsp]
00007dd8c99d8e7f  vmovaps xmm1, [rsp+0x10]
00007dd8c99d8e85  vmovaps xmm2, [rsp+0x20]
00007dd8c99d8e8b  vmovaps xmm3, [rsp+0x30]
00007dd8c99d8e91  vmovaps xmm4, [rsp+0x40]
00007dd8c99d8e97  vmovaps xmm5, [rsp+0x50]
00007dd8c99d8e9d  vmovaps xmm6, [rsp+0x60]
00007dd8c99d8ea3  vmovaps xmm7, [rsp+0x70]
00007dd8c99d8ea9  vmovaps xmm8, [rsp+0x80]
00007dd8c99d8eb2  vmovaps xmm10, [rsp+0x90]
00007dd8c99d8ebb  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d8ec4  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d8ecd  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d8ed6  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d8edf  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d8ee8  add rsp, 0xF0
00007dd8c99d8eef  pop r11
00007dd8c99d8ef1  pop r10
00007dd8c99d8ef3  pop r9
00007dd8c99d8ef5  pop r8
00007dd8c99d8ef7  pop rsi
00007dd8c99d8ef8  pop rdi
00007dd8c99d8ef9  pop rdx
00007dd8c99d8efa  pop rcx
00007dd8c99d8efb  pop rax
00007dd8c99d8efc  add rsp, 0x08
00007dd8c99d8f00  jmp 0x00007DD8C99D61A1
00007dd8c99d8f05  sub rsp, 0x08
00007dd8c99d8f09  push rax
00007dd8c99d8f0a  push rcx
00007dd8c99d8f0b  push rdx
00007dd8c99d8f0c  push rdi
00007dd8c99d8f0d  push rsi
00007dd8c99d8f0e  push r8
00007dd8c99d8f10  push r9
00007dd8c99d8f12  push r10
00007dd8c99d8f14  push r11
00007dd8c99d8f16  sub rsp, 0xF0
00007dd8c99d8f1d  vmovaps [rsp], xmm0
00007dd8c99d8f22  vmovaps [rsp+0x10], xmm2
00007dd8c99d8f28  vmovaps [rsp+0x20], xmm3
00007dd8c99d8f2e  vmovaps [rsp+0x30], xmm4
00007dd8c99d8f34  vmovaps [rsp+0x40], xmm5
00007dd8c99d8f3a  vmovaps [rsp+0x50], xmm6
00007dd8c99d8f40  vmovaps [rsp+0x60], xmm7
00007dd8c99d8f46  vmovaps [rsp+0x70], xmm8
00007dd8c99d8f4c  vmovaps [rsp+0x80], xmm9
00007dd8c99d8f55  vmovaps [rsp+0x90], xmm10
00007dd8c99d8f5e  vmovaps [rsp+0xA0], xmm11
00007dd8c99d8f67  vmovaps [rsp+0xB0], xmm12
00007dd8c99d8f70  vmovaps [rsp+0xC0], xmm13
00007dd8c99d8f79  vmovaps [rsp+0xD0], xmm14
00007dd8c99d8f82  vmovaps [rsp+0xE0], xmm15
00007dd8c99d8f8b  sub rsp, 0x30
00007dd8c99d8f8f  movaps [rsp], xmm1
00007dd8c99d8f93  movaps [rsp+0x10], xmm15
00007dd8c99d8f99  movaps [rsp+0x20], xmm6
00007dd8c99d8f9e  lea rdi, [rsp]
00007dd8c99d8fa2  mov esi, 0x00
00007dd8c99d8fa7  mov rax, 0x55FEBBDB5530
00007dd8c99d8fb1  call rax
00007dd8c99d8fb3  movaps xmm1, [rsp]
00007dd8c99d8fb7  add rsp, 0x30
00007dd8c99d8fbb  vmovaps xmm0, [rsp]
00007dd8c99d8fc0  vmovaps xmm2, [rsp+0x10]
00007dd8c99d8fc6  vmovaps xmm3, [rsp+0x20]
00007dd8c99d8fcc  vmovaps xmm4, [rsp+0x30]
00007dd8c99d8fd2  vmovaps xmm5, [rsp+0x40]
00007dd8c99d8fd8  vmovaps xmm6, [rsp+0x50]
00007dd8c99d8fde  vmovaps xmm7, [rsp+0x60]
00007dd8c99d8fe4  vmovaps xmm8, [rsp+0x70]
00007dd8c99d8fea  vmovaps xmm9, [rsp+0x80]
00007dd8c99d8ff3  vmovaps xmm10, [rsp+0x90]
00007dd8c99d8ffc  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d9005  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d900e  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d9017  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d9020  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d9029  add rsp, 0xF0
00007dd8c99d9030  pop r11
00007dd8c99d9032  pop r10
00007dd8c99d9034  pop r9
00007dd8c99d9036  pop r8
00007dd8c99d9038  pop rsi
00007dd8c99d9039  pop rdi
00007dd8c99d903a  pop rdx
00007dd8c99d903b  pop rcx
00007dd8c99d903c  pop rax
00007dd8c99d903d  add rsp, 0x08
00007dd8c99d9041  jmp 0x00007DD8C99D61C2
00007dd8c99d9046  sub rsp, 0x08
00007dd8c99d904a  push rax
00007dd8c99d904b  push rcx
00007dd8c99d904c  push rdx
00007dd8c99d904d  push rdi
00007dd8c99d904e  push rsi
00007dd8c99d904f  push r8
00007dd8c99d9051  push r9
00007dd8c99d9053  push r10
00007dd8c99d9055  push r11
00007dd8c99d9057  sub rsp, 0xF0
00007dd8c99d905e  vmovaps [rsp], xmm0
00007dd8c99d9063  vmovaps [rsp+0x10], xmm1
00007dd8c99d9069  vmovaps [rsp+0x20], xmm2
00007dd8c99d906f  vmovaps [rsp+0x30], xmm3
00007dd8c99d9075  vmovaps [rsp+0x40], xmm4
00007dd8c99d907b  vmovaps [rsp+0x50], xmm5
00007dd8c99d9081  vmovaps [rsp+0x60], xmm6
00007dd8c99d9087  vmovaps [rsp+0x70], xmm7
00007dd8c99d908d  vmovaps [rsp+0x80], xmm8
00007dd8c99d9096  vmovaps [rsp+0x90], xmm9
00007dd8c99d909f  vmovaps [rsp+0xA0], xmm10
00007dd8c99d90a8  vmovaps [rsp+0xB0], xmm11
00007dd8c99d90b1  vmovaps [rsp+0xC0], xmm12
00007dd8c99d90ba  vmovaps [rsp+0xD0], xmm13
00007dd8c99d90c3  vmovaps [rsp+0xE0], xmm14
00007dd8c99d90cc  sub rsp, 0x30
00007dd8c99d90d0  movaps [rsp], xmm15
00007dd8c99d90d5  movaps [rsp+0x10], xmm5
00007dd8c99d90da  movaps [rsp+0x20], xmm3
00007dd8c99d90df  lea rdi, [rsp]
00007dd8c99d90e3  mov esi, 0x00
00007dd8c99d90e8  mov rax, 0x55FEBBDB5530
00007dd8c99d90f2  call rax
00007dd8c99d90f4  movaps xmm15, [rsp]
00007dd8c99d90f9  add rsp, 0x30
00007dd8c99d90fd  vmovaps xmm0, [rsp]
00007dd8c99d9102  vmovaps xmm1, [rsp+0x10]
00007dd8c99d9108  vmovaps xmm2, [rsp+0x20]
00007dd8c99d910e  vmovaps xmm3, [rsp+0x30]
00007dd8c99d9114  vmovaps xmm4, [rsp+0x40]
00007dd8c99d911a  vmovaps xmm5, [rsp+0x50]
00007dd8c99d9120  vmovaps xmm6, [rsp+0x60]
00007dd8c99d9126  vmovaps xmm7, [rsp+0x70]
00007dd8c99d912c  vmovaps xmm8, [rsp+0x80]
00007dd8c99d9135  vmovaps xmm9, [rsp+0x90]
00007dd8c99d913e  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d9147  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d9150  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d9159  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d9162  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d916b  add rsp, 0xF0
00007dd8c99d9172  pop r11
00007dd8c99d9174  pop r10
00007dd8c99d9176  pop r9
00007dd8c99d9178  pop r8
00007dd8c99d917a  pop rsi
00007dd8c99d917b  pop rdi
00007dd8c99d917c  pop rdx
00007dd8c99d917d  pop rcx
00007dd8c99d917e  pop rax
00007dd8c99d917f  add rsp, 0x08
00007dd8c99d9183  jmp 0x00007DD8C99D61DC
00007dd8c99d9188  sub rsp, 0x08
00007dd8c99d918c  push rax
00007dd8c99d918d  push rcx
00007dd8c99d918e  push rdx
00007dd8c99d918f  push rdi
00007dd8c99d9190  push rsi
00007dd8c99d9191  push r8
00007dd8c99d9193  push r9
00007dd8c99d9195  push r10
00007dd8c99d9197  push r11
00007dd8c99d9199  sub rsp, 0xF0
00007dd8c99d91a0  vmovaps [rsp], xmm0
00007dd8c99d91a5  vmovaps [rsp+0x10], xmm1
00007dd8c99d91ab  vmovaps [rsp+0x20], xmm2
00007dd8c99d91b1  vmovaps [rsp+0x30], xmm3
00007dd8c99d91b7  vmovaps [rsp+0x40], xmm4
00007dd8c99d91bd  vmovaps [rsp+0x50], xmm6
00007dd8c99d91c3  vmovaps [rsp+0x60], xmm7
00007dd8c99d91c9  vmovaps [rsp+0x70], xmm8
00007dd8c99d91cf  vmovaps [rsp+0x80], xmm9
00007dd8c99d91d8  vmovaps [rsp+0x90], xmm10
00007dd8c99d91e1  vmovaps [rsp+0xA0], xmm11
00007dd8c99d91ea  vmovaps [rsp+0xB0], xmm12
00007dd8c99d91f3  vmovaps [rsp+0xC0], xmm13
00007dd8c99d91fc  vmovaps [rsp+0xD0], xmm14
00007dd8c99d9205  vmovaps [rsp+0xE0], xmm15
00007dd8c99d920e  sub rsp, 0x30
00007dd8c99d9212  movaps [rsp], xmm5
00007dd8c99d9216  movaps [rsp+0x10], xmm8
00007dd8c99d921c  movaps [rsp+0x20], xmm6
00007dd8c99d9221  lea rdi, [rsp]
00007dd8c99d9225  mov esi, 0x00
00007dd8c99d922a  mov rax, 0x55FEBBDB5530
00007dd8c99d9234  call rax
00007dd8c99d9236  movaps xmm5, [rsp]
00007dd8c99d923a  add rsp, 0x30
00007dd8c99d923e  vmovaps xmm0, [rsp]
00007dd8c99d9243  vmovaps xmm1, [rsp+0x10]
00007dd8c99d9249  vmovaps xmm2, [rsp+0x20]
00007dd8c99d924f  vmovaps xmm3, [rsp+0x30]
00007dd8c99d9255  vmovaps xmm4, [rsp+0x40]
00007dd8c99d925b  vmovaps xmm6, [rsp+0x50]
00007dd8c99d9261  vmovaps xmm7, [rsp+0x60]
00007dd8c99d9267  vmovaps xmm8, [rsp+0x70]
00007dd8c99d926d  vmovaps xmm9, [rsp+0x80]
00007dd8c99d9276  vmovaps xmm10, [rsp+0x90]
00007dd8c99d927f  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d9288  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d9291  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d929a  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d92a3  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d92ac  add rsp, 0xF0
00007dd8c99d92b3  pop r11
00007dd8c99d92b5  pop r10
00007dd8c99d92b7  pop r9
00007dd8c99d92b9  pop r8
00007dd8c99d92bb  pop rsi
00007dd8c99d92bc  pop rdi
00007dd8c99d92bd  pop rdx
00007dd8c99d92be  pop rcx
00007dd8c99d92bf  pop rax
00007dd8c99d92c0  add rsp, 0x08
00007dd8c99d92c4  jmp 0x00007DD8C99D6200
00007dd8c99d92c9  sub rsp, 0x08
00007dd8c99d92cd  push rax
00007dd8c99d92ce  push rcx
00007dd8c99d92cf  push rdx
00007dd8c99d92d0  push rdi
00007dd8c99d92d1  push rsi
00007dd8c99d92d2  push r8
00007dd8c99d92d4  push r9
00007dd8c99d92d6  push r10
00007dd8c99d92d8  push r11
00007dd8c99d92da  sub rsp, 0xF0
00007dd8c99d92e1  vmovaps [rsp], xmm0
00007dd8c99d92e6  vmovaps [rsp+0x10], xmm1
00007dd8c99d92ec  vmovaps [rsp+0x20], xmm2
00007dd8c99d92f2  vmovaps [rsp+0x30], xmm3
00007dd8c99d92f8  vmovaps [rsp+0x40], xmm4
00007dd8c99d92fe  vmovaps [rsp+0x50], xmm5
00007dd8c99d9304  vmovaps [rsp+0x60], xmm7
00007dd8c99d930a  vmovaps [rsp+0x70], xmm8
00007dd8c99d9310  vmovaps [rsp+0x80], xmm9
00007dd8c99d9319  vmovaps [rsp+0x90], xmm10
00007dd8c99d9322  vmovaps [rsp+0xA0], xmm11
00007dd8c99d932b  vmovaps [rsp+0xB0], xmm12
00007dd8c99d9334  vmovaps [rsp+0xC0], xmm13
00007dd8c99d933d  vmovaps [rsp+0xD0], xmm14
00007dd8c99d9346  vmovaps [rsp+0xE0], xmm15
00007dd8c99d934f  sub rsp, 0x30
00007dd8c99d9353  movaps [rsp], xmm6
00007dd8c99d9357  movaps [rsp+0x10], xmm10
00007dd8c99d935d  movaps [rsp+0x20], xmm8
00007dd8c99d9363  lea rdi, [rsp]
00007dd8c99d9367  mov esi, 0x00
00007dd8c99d936c  mov rax, 0x55FEBBDB5530
00007dd8c99d9376  call rax
00007dd8c99d9378  movaps xmm6, [rsp]
00007dd8c99d937c  add rsp, 0x30
00007dd8c99d9380  vmovaps xmm0, [rsp]
00007dd8c99d9385  vmovaps xmm1, [rsp+0x10]
00007dd8c99d938b  vmovaps xmm2, [rsp+0x20]
00007dd8c99d9391  vmovaps xmm3, [rsp+0x30]
00007dd8c99d9397  vmovaps xmm4, [rsp+0x40]
00007dd8c99d939d  vmovaps xmm5, [rsp+0x50]
00007dd8c99d93a3  vmovaps xmm7, [rsp+0x60]
00007dd8c99d93a9  vmovaps xmm8, [rsp+0x70]
00007dd8c99d93af  vmovaps xmm9, [rsp+0x80]
00007dd8c99d93b8  vmovaps xmm10, [rsp+0x90]
00007dd8c99d93c1  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d93ca  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d93d3  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d93dc  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d93e5  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d93ee  add rsp, 0xF0
00007dd8c99d93f5  pop r11
00007dd8c99d93f7  pop r10
00007dd8c99d93f9  pop r9
00007dd8c99d93fb  pop r8
00007dd8c99d93fd  pop rsi
00007dd8c99d93fe  pop rdi
00007dd8c99d93ff  pop rdx
00007dd8c99d9400  pop rcx
00007dd8c99d9401  pop rax
00007dd8c99d9402  add rsp, 0x08
00007dd8c99d9406  jmp 0x00007DD8C99D6225
00007dd8c99d940b  sub rsp, 0x08
00007dd8c99d940f  push rax
00007dd8c99d9410  push rcx
00007dd8c99d9411  push rdx
00007dd8c99d9412  push rdi
00007dd8c99d9413  push rsi
00007dd8c99d9414  push r8
00007dd8c99d9416  push r9
00007dd8c99d9418  push r10
00007dd8c99d941a  push r11
00007dd8c99d941c  sub rsp, 0xF0
00007dd8c99d9423  vmovaps [rsp], xmm0
00007dd8c99d9428  vmovaps [rsp+0x10], xmm1
00007dd8c99d942e  vmovaps [rsp+0x20], xmm2
00007dd8c99d9434  vmovaps [rsp+0x30], xmm3
00007dd8c99d943a  vmovaps [rsp+0x40], xmm4
00007dd8c99d9440  vmovaps [rsp+0x50], xmm5
00007dd8c99d9446  vmovaps [rsp+0x60], xmm6
00007dd8c99d944c  vmovaps [rsp+0x70], xmm7
00007dd8c99d9452  vmovaps [rsp+0x80], xmm8
00007dd8c99d945b  vmovaps [rsp+0x90], xmm9
00007dd8c99d9464  vmovaps [rsp+0xA0], xmm11
00007dd8c99d946d  vmovaps [rsp+0xB0], xmm12
00007dd8c99d9476  vmovaps [rsp+0xC0], xmm13
00007dd8c99d947f  vmovaps [rsp+0xD0], xmm14
00007dd8c99d9488  vmovaps [rsp+0xE0], xmm15
00007dd8c99d9491  sub rsp, 0x30
00007dd8c99d9495  movaps [rsp], xmm10
00007dd8c99d949a  movaps [rsp+0x10], xmm8
00007dd8c99d94a0  movaps [rsp+0x20], xmm14
00007dd8c99d94a6  lea rdi, [rsp]
00007dd8c99d94aa  mov esi, 0x00
00007dd8c99d94af  mov rax, 0x55FEBBDB5530
00007dd8c99d94b9  call rax
00007dd8c99d94bb  movaps xmm10, [rsp]
00007dd8c99d94c0  add rsp, 0x30
00007dd8c99d94c4  vmovaps xmm0, [rsp]
00007dd8c99d94c9  vmovaps xmm1, [rsp+0x10]
00007dd8c99d94cf  vmovaps xmm2, [rsp+0x20]
00007dd8c99d94d5  vmovaps xmm3, [rsp+0x30]
00007dd8c99d94db  vmovaps xmm4, [rsp+0x40]
00007dd8c99d94e1  vmovaps xmm5, [rsp+0x50]
00007dd8c99d94e7  vmovaps xmm6, [rsp+0x60]
00007dd8c99d94ed  vmovaps xmm7, [rsp+0x70]
00007dd8c99d94f3  vmovaps xmm8, [rsp+0x80]
00007dd8c99d94fc  vmovaps xmm9, [rsp+0x90]
00007dd8c99d9505  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d950e  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d9517  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d9520  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d9529  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d9532  add rsp, 0xF0
00007dd8c99d9539  pop r11
00007dd8c99d953b  pop r10
00007dd8c99d953d  pop r9
00007dd8c99d953f  pop r8
00007dd8c99d9541  pop rsi
00007dd8c99d9542  pop rdi
00007dd8c99d9543  pop rdx
00007dd8c99d9544  pop rcx
00007dd8c99d9545  pop rax
00007dd8c99d9546  add rsp, 0x08
00007dd8c99d954a  jmp 0x00007DD8C99D6245
00007dd8c99d954f  sub rsp, 0x08
00007dd8c99d9553  push rax
00007dd8c99d9554  push rcx
00007dd8c99d9555  push rdx
00007dd8c99d9556  push rdi
00007dd8c99d9557  push rsi
00007dd8c99d9558  push r8
00007dd8c99d955a  push r9
00007dd8c99d955c  push r10
00007dd8c99d955e  push r11
00007dd8c99d9560  sub rsp, 0xF0
00007dd8c99d9567  vmovaps [rsp], xmm0
00007dd8c99d956c  vmovaps [rsp+0x10], xmm1
00007dd8c99d9572  vmovaps [rsp+0x20], xmm2
00007dd8c99d9578  vmovaps [rsp+0x30], xmm3
00007dd8c99d957e  vmovaps [rsp+0x40], xmm4
00007dd8c99d9584  vmovaps [rsp+0x50], xmm5
00007dd8c99d958a  vmovaps [rsp+0x60], xmm6
00007dd8c99d9590  vmovaps [rsp+0x70], xmm7
00007dd8c99d9596  vmovaps [rsp+0x80], xmm8
00007dd8c99d959f  vmovaps [rsp+0x90], xmm9
00007dd8c99d95a8  vmovaps [rsp+0xA0], xmm10
00007dd8c99d95b1  vmovaps [rsp+0xB0], xmm11
00007dd8c99d95ba  vmovaps [rsp+0xC0], xmm12
00007dd8c99d95c3  vmovaps [rsp+0xD0], xmm13
00007dd8c99d95cc  vmovaps [rsp+0xE0], xmm15
00007dd8c99d95d5  sub rsp, 0x30
00007dd8c99d95d9  movaps [rsp], xmm14
00007dd8c99d95de  movaps [rsp+0x10], xmm8
00007dd8c99d95e4  movaps [rsp+0x20], xmm4
00007dd8c99d95e9  lea rdi, [rsp]
00007dd8c99d95ed  mov esi, 0x00
00007dd8c99d95f2  mov rax, 0x55FEBBDB5530
00007dd8c99d95fc  call rax
00007dd8c99d95fe  movaps xmm14, [rsp]
00007dd8c99d9603  add rsp, 0x30
00007dd8c99d9607  vmovaps xmm0, [rsp]
00007dd8c99d960c  vmovaps xmm1, [rsp+0x10]
00007dd8c99d9612  vmovaps xmm2, [rsp+0x20]
00007dd8c99d9618  vmovaps xmm3, [rsp+0x30]
00007dd8c99d961e  vmovaps xmm4, [rsp+0x40]
00007dd8c99d9624  vmovaps xmm5, [rsp+0x50]
00007dd8c99d962a  vmovaps xmm6, [rsp+0x60]
00007dd8c99d9630  vmovaps xmm7, [rsp+0x70]
00007dd8c99d9636  vmovaps xmm8, [rsp+0x80]
00007dd8c99d963f  vmovaps xmm9, [rsp+0x90]
00007dd8c99d9648  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d9651  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d965a  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d9663  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d966c  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d9675  add rsp, 0xF0
00007dd8c99d967c  pop r11
00007dd8c99d967e  pop r10
00007dd8c99d9680  pop r9
00007dd8c99d9682  pop r8
00007dd8c99d9684  pop rsi
00007dd8c99d9685  pop rdi
00007dd8c99d9686  pop rdx
00007dd8c99d9687  pop rcx
00007dd8c99d9688  pop rax
00007dd8c99d9689  add rsp, 0x08
00007dd8c99d968d  jmp 0x00007DD8C99D6265
00007dd8c99d9692  sub rsp, 0x08
00007dd8c99d9696  push rax
00007dd8c99d9697  push rcx
00007dd8c99d9698  push rdx
00007dd8c99d9699  push rdi
00007dd8c99d969a  push rsi
00007dd8c99d969b  push r8
00007dd8c99d969d  push r9
00007dd8c99d969f  push r10
00007dd8c99d96a1  push r11
00007dd8c99d96a3  sub rsp, 0xF0
00007dd8c99d96aa  vmovaps [rsp], xmm0
00007dd8c99d96af  vmovaps [rsp+0x10], xmm1
00007dd8c99d96b5  vmovaps [rsp+0x20], xmm2
00007dd8c99d96bb  vmovaps [rsp+0x30], xmm3
00007dd8c99d96c1  vmovaps [rsp+0x40], xmm5
00007dd8c99d96c7  vmovaps [rsp+0x50], xmm6
00007dd8c99d96cd  vmovaps [rsp+0x60], xmm7
00007dd8c99d96d3  vmovaps [rsp+0x70], xmm8
00007dd8c99d96d9  vmovaps [rsp+0x80], xmm9
00007dd8c99d96e2  vmovaps [rsp+0x90], xmm10
00007dd8c99d96eb  vmovaps [rsp+0xA0], xmm11
00007dd8c99d96f4  vmovaps [rsp+0xB0], xmm12
00007dd8c99d96fd  vmovaps [rsp+0xC0], xmm13
00007dd8c99d9706  vmovaps [rsp+0xD0], xmm14
00007dd8c99d970f  vmovaps [rsp+0xE0], xmm15
00007dd8c99d9718  sub rsp, 0x30
00007dd8c99d971c  movaps [rsp], xmm4
00007dd8c99d9720  movaps [rsp+0x10], xmm13
00007dd8c99d9726  movaps [rsp+0x20], xmm8
00007dd8c99d972c  lea rdi, [rsp]
00007dd8c99d9730  mov esi, 0x00
00007dd8c99d9735  mov rax, 0x55FEBBDB5530
00007dd8c99d973f  call rax
00007dd8c99d9741  movaps xmm4, [rsp]
00007dd8c99d9745  add rsp, 0x30
00007dd8c99d9749  vmovaps xmm0, [rsp]
00007dd8c99d974e  vmovaps xmm1, [rsp+0x10]
00007dd8c99d9754  vmovaps xmm2, [rsp+0x20]
00007dd8c99d975a  vmovaps xmm3, [rsp+0x30]
00007dd8c99d9760  vmovaps xmm5, [rsp+0x40]
00007dd8c99d9766  vmovaps xmm6, [rsp+0x50]
00007dd8c99d976c  vmovaps xmm7, [rsp+0x60]
00007dd8c99d9772  vmovaps xmm8, [rsp+0x70]
00007dd8c99d9778  vmovaps xmm9, [rsp+0x80]
00007dd8c99d9781  vmovaps xmm10, [rsp+0x90]
00007dd8c99d978a  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d9793  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d979c  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d97a5  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d97ae  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d97b7  add rsp, 0xF0
00007dd8c99d97be  pop r11
00007dd8c99d97c0  pop r10
00007dd8c99d97c2  pop r9
00007dd8c99d97c4  pop r8
00007dd8c99d97c6  pop rsi
00007dd8c99d97c7  pop rdi
00007dd8c99d97c8  pop rdx
00007dd8c99d97c9  pop rcx
00007dd8c99d97ca  pop rax
00007dd8c99d97cb  add rsp, 0x08
00007dd8c99d97cf  jmp 0x00007DD8C99D628A
00007dd8c99d97d4  sub rsp, 0x08
00007dd8c99d97d8  push rax
00007dd8c99d97d9  push rcx
00007dd8c99d97da  push rdx
00007dd8c99d97db  push rdi
00007dd8c99d97dc  push rsi
00007dd8c99d97dd  push r8
00007dd8c99d97df  push r9
00007dd8c99d97e1  push r10
00007dd8c99d97e3  push r11
00007dd8c99d97e5  sub rsp, 0xF0
00007dd8c99d97ec  vmovaps [rsp], xmm0
00007dd8c99d97f1  vmovaps [rsp+0x10], xmm1
00007dd8c99d97f7  vmovaps [rsp+0x20], xmm2
00007dd8c99d97fd  vmovaps [rsp+0x30], xmm3
00007dd8c99d9803  vmovaps [rsp+0x40], xmm4
00007dd8c99d9809  vmovaps [rsp+0x50], xmm5
00007dd8c99d980f  vmovaps [rsp+0x60], xmm6
00007dd8c99d9815  vmovaps [rsp+0x70], xmm7
00007dd8c99d981b  vmovaps [rsp+0x80], xmm8
00007dd8c99d9824  vmovaps [rsp+0x90], xmm9
00007dd8c99d982d  vmovaps [rsp+0xA0], xmm10
00007dd8c99d9836  vmovaps [rsp+0xB0], xmm11
00007dd8c99d983f  vmovaps [rsp+0xC0], xmm12
00007dd8c99d9848  vmovaps [rsp+0xD0], xmm14
00007dd8c99d9851  vmovaps [rsp+0xE0], xmm15
00007dd8c99d985a  sub rsp, 0x30
00007dd8c99d985e  movaps [rsp], xmm13
00007dd8c99d9863  movaps [rsp+0x10], xmm15
00007dd8c99d9869  movaps [rsp+0x20], xmm9
00007dd8c99d986f  lea rdi, [rsp]
00007dd8c99d9873  mov esi, 0x00
00007dd8c99d9878  mov rax, 0x55FEBBDB5530
00007dd8c99d9882  call rax
00007dd8c99d9884  movaps xmm13, [rsp]
00007dd8c99d9889  add rsp, 0x30
00007dd8c99d988d  vmovaps xmm0, [rsp]
00007dd8c99d9892  vmovaps xmm1, [rsp+0x10]
00007dd8c99d9898  vmovaps xmm2, [rsp+0x20]
00007dd8c99d989e  vmovaps xmm3, [rsp+0x30]
00007dd8c99d98a4  vmovaps xmm4, [rsp+0x40]
00007dd8c99d98aa  vmovaps xmm5, [rsp+0x50]
00007dd8c99d98b0  vmovaps xmm6, [rsp+0x60]
00007dd8c99d98b6  vmovaps xmm7, [rsp+0x70]
00007dd8c99d98bc  vmovaps xmm8, [rsp+0x80]
00007dd8c99d98c5  vmovaps xmm9, [rsp+0x90]
00007dd8c99d98ce  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d98d7  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d98e0  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d98e9  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d98f2  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d98fb  add rsp, 0xF0
00007dd8c99d9902  pop r11
00007dd8c99d9904  pop r10
00007dd8c99d9906  pop r9
00007dd8c99d9908  pop r8
00007dd8c99d990a  pop rsi
00007dd8c99d990b  pop rdi
00007dd8c99d990c  pop rdx
00007dd8c99d990d  pop rcx
00007dd8c99d990e  pop rax
00007dd8c99d990f  add rsp, 0x08
00007dd8c99d9913  jmp 0x00007DD8C99D62A5
00007dd8c99d9918  sub rsp, 0x08
00007dd8c99d991c  push rax
00007dd8c99d991d  push rcx
00007dd8c99d991e  push rdx
00007dd8c99d991f  push rdi
00007dd8c99d9920  push rsi
00007dd8c99d9921  push r8
00007dd8c99d9923  push r9
00007dd8c99d9925  push r10
00007dd8c99d9927  push r11
00007dd8c99d9929  sub rsp, 0xF0
00007dd8c99d9930  vmovaps [rsp], xmm0
00007dd8c99d9935  vmovaps [rsp+0x10], xmm1
00007dd8c99d993b  vmovaps [rsp+0x20], xmm2
00007dd8c99d9941  vmovaps [rsp+0x30], xmm3
00007dd8c99d9947  vmovaps [rsp+0x40], xmm4
00007dd8c99d994d  vmovaps [rsp+0x50], xmm5
00007dd8c99d9953  vmovaps [rsp+0x60], xmm6
00007dd8c99d9959  vmovaps [rsp+0x70], xmm7
00007dd8c99d995f  vmovaps [rsp+0x80], xmm8
00007dd8c99d9968  vmovaps [rsp+0x90], xmm9
00007dd8c99d9971  vmovaps [rsp+0xA0], xmm10
00007dd8c99d997a  vmovaps [rsp+0xB0], xmm11
00007dd8c99d9983  vmovaps [rsp+0xC0], xmm12
00007dd8c99d998c  vmovaps [rsp+0xD0], xmm13
00007dd8c99d9995  vmovaps [rsp+0xE0], xmm14
00007dd8c99d999e  sub rsp, 0x30
00007dd8c99d99a2  movaps [rsp], xmm15
00007dd8c99d99a7  movaps [rsp+0x10], xmm1
00007dd8c99d99ac  movaps [rsp+0x20], xmm5
00007dd8c99d99b1  lea rdi, [rsp]
00007dd8c99d99b5  mov esi, 0x00
00007dd8c99d99ba  mov rax, 0x55FEBBDB5530
00007dd8c99d99c4  call rax
00007dd8c99d99c6  movaps xmm15, [rsp]
00007dd8c99d99cb  add rsp, 0x30
00007dd8c99d99cf  vmovaps xmm0, [rsp]
00007dd8c99d99d4  vmovaps xmm1, [rsp+0x10]
00007dd8c99d99da  vmovaps xmm2, [rsp+0x20]
00007dd8c99d99e0  vmovaps xmm3, [rsp+0x30]
00007dd8c99d99e6  vmovaps xmm4, [rsp+0x40]
00007dd8c99d99ec  vmovaps xmm5, [rsp+0x50]
00007dd8c99d99f2  vmovaps xmm6, [rsp+0x60]
00007dd8c99d99f8  vmovaps xmm7, [rsp+0x70]
00007dd8c99d99fe  vmovaps xmm8, [rsp+0x80]
00007dd8c99d9a07  vmovaps xmm9, [rsp+0x90]
00007dd8c99d9a10  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d9a19  vmovaps xmm11, [rsp+0xB0]
00007dd8c99d9a22  vmovaps xmm12, [rsp+0xC0]
00007dd8c99d9a2b  vmovaps xmm13, [rsp+0xD0]
00007dd8c99d9a34  vmovaps xmm14, [rsp+0xE0]
00007dd8c99d9a3d  add rsp, 0xF0
00007dd8c99d9a44  pop r11
00007dd8c99d9a46  pop r10
00007dd8c99d9a48  pop r9
00007dd8c99d9a4a  pop r8
00007dd8c99d9a4c  pop rsi
00007dd8c99d9a4d  pop rdi
00007dd8c99d9a4e  pop rdx
00007dd8c99d9a4f  pop rcx
00007dd8c99d9a50  pop rax
00007dd8c99d9a51  add rsp, 0x08
00007dd8c99d9a55  jmp 0x00007DD8C99D62C0
00007dd8c99d9a5a  call 0x00007DD8C98D64F0
00007dd8c99d9a5f  jmp 0x00007DD8C99D631B
00007dd8c99d9a64  sub rsp, 0x08
00007dd8c99d9a68  push rax
00007dd8c99d9a69  push rcx
00007dd8c99d9a6a  push rdx
00007dd8c99d9a6b  push rdi
00007dd8c99d9a6c  push rsi
00007dd8c99d9a6d  push r8
00007dd8c99d9a6f  push r9
00007dd8c99d9a71  push r10
00007dd8c99d9a73  push r11
00007dd8c99d9a75  sub rsp, 0xF0
00007dd8c99d9a7c  vmovaps [rsp], xmm0
00007dd8c99d9a81  vmovaps [rsp+0x10], xmm1
00007dd8c99d9a87  vmovaps [rsp+0x20], xmm2
00007dd8c99d9a8d  vmovaps [rsp+0x30], xmm3
00007dd8c99d9a93  vmovaps [rsp+0x40], xmm4
00007dd8c99d9a99  vmovaps [rsp+0x50], xmm5
00007dd8c99d9a9f  vmovaps [rsp+0x60], xmm6
00007dd8c99d9aa5  vmovaps [rsp+0x70], xmm7
00007dd8c99d9aab  vmovaps [rsp+0x80], xmm8
00007dd8c99d9ab4  vmovaps [rsp+0x90], xmm10
00007dd8c99d9abd  vmovaps [rsp+0xA0], xmm11
00007dd8c99d9ac6  vmovaps [rsp+0xB0], xmm12
00007dd8c99d9acf  vmovaps [rsp+0xC0], xmm13
00007dd8c99d9ad8  vmovaps [rsp+0xD0], xmm14
00007dd8c99d9ae1  vmovaps [rsp+0xE0], xmm15
00007dd8c99d9aea  sub rsp, 0x30
00007dd8c99d9aee  movaps [rsp], xmm9
00007dd8c99d9af3  movaps [rsp+0x10], xmm8
00007dd8c99d9af9  movaps [rsp+0x20], xmm11
00007dd8c99d9aff  lea rdi, [rsp]
00007dd8c99d9b03  mov esi, 0x00
00007dd8c99d9b08  mov rax, 0x55FEBBDB5530
00007dd8c99d9b12  call rax
00007dd8c99d9b14  movaps xmm9, [rsp]
00007dd8c99d9b19  add rsp, 0x30
00007dd8c99d9b1d  vmovaps xmm0, [rsp]
00007dd8c99d9b22  vmovaps xmm1, [rsp+0x10]
00007dd8c99d9b28  vmovaps xmm2, [rsp+0x20]
00007dd8c99d9b2e  vmovaps xmm3, [rsp+0x30]
00007dd8c99d9b34  vmovaps xmm4, [rsp+0x40]
00007dd8c99d9b3a  vmovaps xmm5, [rsp+0x50]
00007dd8c99d9b40  vmovaps xmm6, [rsp+0x60]
00007dd8c99d9b46  vmovaps xmm7, [rsp+0x70]
00007dd8c99d9b4c  vmovaps xmm8, [rsp+0x80]
00007dd8c99d9b55  vmovaps xmm10, [rsp+0x90]
00007dd8c99d9b5e  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d9b67  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d9b70  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d9b79  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d9b82  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d9b8b  add rsp, 0xF0
00007dd8c99d9b92  pop r11
00007dd8c99d9b94  pop r10
00007dd8c99d9b96  pop r9
00007dd8c99d9b98  pop r8
00007dd8c99d9b9a  pop rsi
00007dd8c99d9b9b  pop rdi
00007dd8c99d9b9c  pop rdx
00007dd8c99d9b9d  pop rcx
00007dd8c99d9b9e  pop rax
00007dd8c99d9b9f  add rsp, 0x08
00007dd8c99d9ba3  jmp 0x00007DD8C99D6352
00007dd8c99d9ba8  sub rsp, 0x08
00007dd8c99d9bac  push rax
00007dd8c99d9bad  push rcx
00007dd8c99d9bae  push rdx
00007dd8c99d9baf  push rdi
00007dd8c99d9bb0  push rsi
00007dd8c99d9bb1  push r8
00007dd8c99d9bb3  push r9
00007dd8c99d9bb5  push r10
00007dd8c99d9bb7  push r11
00007dd8c99d9bb9  sub rsp, 0xF0
00007dd8c99d9bc0  vmovaps [rsp], xmm0
00007dd8c99d9bc5  vmovaps [rsp+0x10], xmm1
00007dd8c99d9bcb  vmovaps [rsp+0x20], xmm2
00007dd8c99d9bd1  vmovaps [rsp+0x30], xmm3
00007dd8c99d9bd7  vmovaps [rsp+0x40], xmm4
00007dd8c99d9bdd  vmovaps [rsp+0x50], xmm5
00007dd8c99d9be3  vmovaps [rsp+0x60], xmm6
00007dd8c99d9be9  vmovaps [rsp+0x70], xmm7
00007dd8c99d9bef  vmovaps [rsp+0x80], xmm8
00007dd8c99d9bf8  vmovaps [rsp+0x90], xmm9
00007dd8c99d9c01  vmovaps [rsp+0xA0], xmm10
00007dd8c99d9c0a  vmovaps [rsp+0xB0], xmm12
00007dd8c99d9c13  vmovaps [rsp+0xC0], xmm13
00007dd8c99d9c1c  vmovaps [rsp+0xD0], xmm14
00007dd8c99d9c25  vmovaps [rsp+0xE0], xmm15
00007dd8c99d9c2e  sub rsp, 0x30
00007dd8c99d9c32  movaps [rsp], xmm11
00007dd8c99d9c37  movaps [rsp+0x10], xmm10
00007dd8c99d9c3d  movaps [rsp+0x20], xmm6
00007dd8c99d9c42  lea rdi, [rsp]
00007dd8c99d9c46  mov esi, 0x00
00007dd8c99d9c4b  mov rax, 0x55FEBBDB5530
00007dd8c99d9c55  call rax
00007dd8c99d9c57  movaps xmm11, [rsp]
00007dd8c99d9c5c  add rsp, 0x30
00007dd8c99d9c60  vmovaps xmm0, [rsp]
00007dd8c99d9c65  vmovaps xmm1, [rsp+0x10]
00007dd8c99d9c6b  vmovaps xmm2, [rsp+0x20]
00007dd8c99d9c71  vmovaps xmm3, [rsp+0x30]
00007dd8c99d9c77  vmovaps xmm4, [rsp+0x40]
00007dd8c99d9c7d  vmovaps xmm5, [rsp+0x50]
00007dd8c99d9c83  vmovaps xmm6, [rsp+0x60]
00007dd8c99d9c89  vmovaps xmm7, [rsp+0x70]
00007dd8c99d9c8f  vmovaps xmm8, [rsp+0x80]
00007dd8c99d9c98  vmovaps xmm9, [rsp+0x90]
00007dd8c99d9ca1  vmovaps xmm10, [rsp+0xA0]
00007dd8c99d9caa  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d9cb3  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d9cbc  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d9cc5  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d9cce  add rsp, 0xF0
00007dd8c99d9cd5  pop r11
00007dd8c99d9cd7  pop r10
00007dd8c99d9cd9  pop r9
00007dd8c99d9cdb  pop r8
00007dd8c99d9cdd  pop rsi
00007dd8c99d9cde  pop rdi
00007dd8c99d9cdf  pop rdx
00007dd8c99d9ce0  pop rcx
00007dd8c99d9ce1  pop rax
00007dd8c99d9ce2  add rsp, 0x08
00007dd8c99d9ce6  jmp 0x00007DD8C99D636D
00007dd8c99d9ceb  sub rsp, 0x08
00007dd8c99d9cef  push rax
00007dd8c99d9cf0  push rcx
00007dd8c99d9cf1  push rdx
00007dd8c99d9cf2  push rdi
00007dd8c99d9cf3  push rsi
00007dd8c99d9cf4  push r8
00007dd8c99d9cf6  push r9
00007dd8c99d9cf8  push r10
00007dd8c99d9cfa  push r11
00007dd8c99d9cfc  sub rsp, 0xF0
00007dd8c99d9d03  vmovaps [rsp], xmm0
00007dd8c99d9d08  vmovaps [rsp+0x10], xmm1
00007dd8c99d9d0e  vmovaps [rsp+0x20], xmm2
00007dd8c99d9d14  vmovaps [rsp+0x30], xmm3
00007dd8c99d9d1a  vmovaps [rsp+0x40], xmm4
00007dd8c99d9d20  vmovaps [rsp+0x50], xmm5
00007dd8c99d9d26  vmovaps [rsp+0x60], xmm6
00007dd8c99d9d2c  vmovaps [rsp+0x70], xmm7
00007dd8c99d9d32  vmovaps [rsp+0x80], xmm8
00007dd8c99d9d3b  vmovaps [rsp+0x90], xmm9
00007dd8c99d9d44  vmovaps [rsp+0xA0], xmm11
00007dd8c99d9d4d  vmovaps [rsp+0xB0], xmm12
00007dd8c99d9d56  vmovaps [rsp+0xC0], xmm13
00007dd8c99d9d5f  vmovaps [rsp+0xD0], xmm14
00007dd8c99d9d68  vmovaps [rsp+0xE0], xmm15
00007dd8c99d9d71  sub rsp, 0x30
00007dd8c99d9d75  movaps [rsp], xmm10
00007dd8c99d9d7a  movaps [rsp+0x10], xmm14
00007dd8c99d9d80  movaps [rsp+0x20], xmm4
00007dd8c99d9d85  lea rdi, [rsp]
00007dd8c99d9d89  mov esi, 0x00
00007dd8c99d9d8e  mov rax, 0x55FEBBDB5530
00007dd8c99d9d98  call rax
00007dd8c99d9d9a  movaps xmm10, [rsp]
00007dd8c99d9d9f  add rsp, 0x30
00007dd8c99d9da3  vmovaps xmm0, [rsp]
00007dd8c99d9da8  vmovaps xmm1, [rsp+0x10]
00007dd8c99d9dae  vmovaps xmm2, [rsp+0x20]
00007dd8c99d9db4  vmovaps xmm3, [rsp+0x30]
00007dd8c99d9dba  vmovaps xmm4, [rsp+0x40]
00007dd8c99d9dc0  vmovaps xmm5, [rsp+0x50]
00007dd8c99d9dc6  vmovaps xmm6, [rsp+0x60]
00007dd8c99d9dcc  vmovaps xmm7, [rsp+0x70]
00007dd8c99d9dd2  vmovaps xmm8, [rsp+0x80]
00007dd8c99d9ddb  vmovaps xmm9, [rsp+0x90]
00007dd8c99d9de4  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d9ded  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d9df6  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d9dff  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d9e08  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d9e11  add rsp, 0xF0
00007dd8c99d9e18  pop r11
00007dd8c99d9e1a  pop r10
00007dd8c99d9e1c  pop r9
00007dd8c99d9e1e  pop r8
00007dd8c99d9e20  pop rsi
00007dd8c99d9e21  pop rdi
00007dd8c99d9e22  pop rdx
00007dd8c99d9e23  pop rcx
00007dd8c99d9e24  pop rax
00007dd8c99d9e25  add rsp, 0x08
00007dd8c99d9e29  jmp 0x00007DD8C99D6388
00007dd8c99d9e2e  sub rsp, 0x08
00007dd8c99d9e32  push rax
00007dd8c99d9e33  push rcx
00007dd8c99d9e34  push rdx
00007dd8c99d9e35  push rdi
00007dd8c99d9e36  push rsi
00007dd8c99d9e37  push r8
00007dd8c99d9e39  push r9
00007dd8c99d9e3b  push r10
00007dd8c99d9e3d  push r11
00007dd8c99d9e3f  sub rsp, 0xF0
00007dd8c99d9e46  vmovaps [rsp], xmm0
00007dd8c99d9e4b  vmovaps [rsp+0x10], xmm1
00007dd8c99d9e51  vmovaps [rsp+0x20], xmm2
00007dd8c99d9e57  vmovaps [rsp+0x30], xmm3
00007dd8c99d9e5d  vmovaps [rsp+0x40], xmm4
00007dd8c99d9e63  vmovaps [rsp+0x50], xmm5
00007dd8c99d9e69  vmovaps [rsp+0x60], xmm6
00007dd8c99d9e6f  vmovaps [rsp+0x70], xmm7
00007dd8c99d9e75  vmovaps [rsp+0x80], xmm9
00007dd8c99d9e7e  vmovaps [rsp+0x90], xmm10
00007dd8c99d9e87  vmovaps [rsp+0xA0], xmm11
00007dd8c99d9e90  vmovaps [rsp+0xB0], xmm12
00007dd8c99d9e99  vmovaps [rsp+0xC0], xmm13
00007dd8c99d9ea2  vmovaps [rsp+0xD0], xmm14
00007dd8c99d9eab  vmovaps [rsp+0xE0], xmm15
00007dd8c99d9eb4  sub rsp, 0x30
00007dd8c99d9eb8  movaps [rsp], xmm8
00007dd8c99d9ebd  movaps [rsp+0x10], xmm1
00007dd8c99d9ec2  movaps [rsp+0x20], xmm14
00007dd8c99d9ec8  lea rdi, [rsp]
00007dd8c99d9ecc  mov esi, 0x00
00007dd8c99d9ed1  mov rax, 0x55FEBBDB5530
00007dd8c99d9edb  call rax
00007dd8c99d9edd  movaps xmm8, [rsp]
00007dd8c99d9ee2  add rsp, 0x30
00007dd8c99d9ee6  vmovaps xmm0, [rsp]
00007dd8c99d9eeb  vmovaps xmm1, [rsp+0x10]
00007dd8c99d9ef1  vmovaps xmm2, [rsp+0x20]
00007dd8c99d9ef7  vmovaps xmm3, [rsp+0x30]
00007dd8c99d9efd  vmovaps xmm4, [rsp+0x40]
00007dd8c99d9f03  vmovaps xmm5, [rsp+0x50]
00007dd8c99d9f09  vmovaps xmm6, [rsp+0x60]
00007dd8c99d9f0f  vmovaps xmm7, [rsp+0x70]
00007dd8c99d9f15  vmovaps xmm9, [rsp+0x80]
00007dd8c99d9f1e  vmovaps xmm10, [rsp+0x90]
00007dd8c99d9f27  vmovaps xmm11, [rsp+0xA0]
00007dd8c99d9f30  vmovaps xmm12, [rsp+0xB0]
00007dd8c99d9f39  vmovaps xmm13, [rsp+0xC0]
00007dd8c99d9f42  vmovaps xmm14, [rsp+0xD0]
00007dd8c99d9f4b  vmovaps xmm15, [rsp+0xE0]
00007dd8c99d9f54  add rsp, 0xF0
00007dd8c99d9f5b  pop r11
00007dd8c99d9f5d  pop r10
00007dd8c99d9f5f  pop r9
00007dd8c99d9f61  pop r8
00007dd8c99d9f63  pop rsi
00007dd8c99d9f64  pop rdi
00007dd8c99d9f65  pop rdx
00007dd8c99d9f66  pop rcx
00007dd8c99d9f67  pop rax
00007dd8c99d9f68  add rsp, 0x08
00007dd8c99d9f6c  jmp 0x00007DD8C99D63AE
00007dd8c99d9f71  sub rsp, 0x08
00007dd8c99d9f75  push rax
00007dd8c99d9f76  push rcx
00007dd8c99d9f77  push rdx
00007dd8c99d9f78  push rdi
00007dd8c99d9f79  push rsi
00007dd8c99d9f7a  push r8
00007dd8c99d9f7c  push r9
00007dd8c99d9f7e  push r10
00007dd8c99d9f80  push r11
00007dd8c99d9f82  sub rsp, 0xF0
00007dd8c99d9f89  vmovaps [rsp], xmm0
00007dd8c99d9f8e  vmovaps [rsp+0x10], xmm1
00007dd8c99d9f94  vmovaps [rsp+0x20], xmm2
00007dd8c99d9f9a  vmovaps [rsp+0x30], xmm3
00007dd8c99d9fa0  vmovaps [rsp+0x40], xmm4
00007dd8c99d9fa6  vmovaps [rsp+0x50], xmm5
00007dd8c99d9fac  vmovaps [rsp+0x60], xmm7
00007dd8c99d9fb2  vmovaps [rsp+0x70], xmm8
00007dd8c99d9fb8  vmovaps [rsp+0x80], xmm9
00007dd8c99d9fc1  vmovaps [rsp+0x90], xmm10
00007dd8c99d9fca  vmovaps [rsp+0xA0], xmm11
00007dd8c99d9fd3  vmovaps [rsp+0xB0], xmm12
00007dd8c99d9fdc  vmovaps [rsp+0xC0], xmm13
00007dd8c99d9fe5  vmovaps [rsp+0xD0], xmm14
00007dd8c99d9fee  vmovaps [rsp+0xE0], xmm15
00007dd8c99d9ff7  sub rsp, 0x30
00007dd8c99d9ffb  movaps [rsp], xmm6
00007dd8c99d9fff  movaps [rsp+0x10], xmm1
00007dd8c99da004  movaps [rsp+0x20], xmm14
00007dd8c99da00a  lea rdi, [rsp]
00007dd8c99da00e  mov esi, 0x00
00007dd8c99da013  mov rax, 0x55FEBBDB5530
00007dd8c99da01d  call rax
00007dd8c99da01f  movaps xmm6, [rsp]
00007dd8c99da023  add rsp, 0x30
00007dd8c99da027  vmovaps xmm0, [rsp]
00007dd8c99da02c  vmovaps xmm1, [rsp+0x10]
00007dd8c99da032  vmovaps xmm2, [rsp+0x20]
00007dd8c99da038  vmovaps xmm3, [rsp+0x30]
00007dd8c99da03e  vmovaps xmm4, [rsp+0x40]
00007dd8c99da044  vmovaps xmm5, [rsp+0x50]
00007dd8c99da04a  vmovaps xmm7, [rsp+0x60]
00007dd8c99da050  vmovaps xmm8, [rsp+0x70]
00007dd8c99da056  vmovaps xmm9, [rsp+0x80]
00007dd8c99da05f  vmovaps xmm10, [rsp+0x90]
00007dd8c99da068  vmovaps xmm11, [rsp+0xA0]
00007dd8c99da071  vmovaps xmm12, [rsp+0xB0]
00007dd8c99da07a  vmovaps xmm13, [rsp+0xC0]
00007dd8c99da083  vmovaps xmm14, [rsp+0xD0]
00007dd8c99da08c  vmovaps xmm15, [rsp+0xE0]
00007dd8c99da095  add rsp, 0xF0
00007dd8c99da09c  pop r11
00007dd8c99da09e  pop r10
00007dd8c99da0a0  pop r9
00007dd8c99da0a2  pop r8
00007dd8c99da0a4  pop rsi
00007dd8c99da0a5  pop rdi
00007dd8c99da0a6  pop rdx
00007dd8c99da0a7  pop rcx
00007dd8c99da0a8  pop rax
00007dd8c99da0a9  add rsp, 0x08
00007dd8c99da0ad  jmp 0x00007DD8C99D63DA
00007dd8c99da0b2  sub rsp, 0x08
00007dd8c99da0b6  push rax
00007dd8c99da0b7  push rcx
00007dd8c99da0b8  push rdx
00007dd8c99da0b9  push rdi
00007dd8c99da0ba  push rsi
00007dd8c99da0bb  push r8
00007dd8c99da0bd  push r9
00007dd8c99da0bf  push r10
00007dd8c99da0c1  push r11
00007dd8c99da0c3  sub rsp, 0xF0
00007dd8c99da0ca  vmovaps [rsp], xmm0
00007dd8c99da0cf  vmovaps [rsp+0x10], xmm1
00007dd8c99da0d5  vmovaps [rsp+0x20], xmm2
00007dd8c99da0db  vmovaps [rsp+0x30], xmm3
00007dd8c99da0e1  vmovaps [rsp+0x40], xmm4
00007dd8c99da0e7  vmovaps [rsp+0x50], xmm5
00007dd8c99da0ed  vmovaps [rsp+0x60], xmm6
00007dd8c99da0f3  vmovaps [rsp+0x70], xmm7
00007dd8c99da0f9  vmovaps [rsp+0x80], xmm8
00007dd8c99da102  vmovaps [rsp+0x90], xmm9
00007dd8c99da10b  vmovaps [rsp+0xA0], xmm10
00007dd8c99da114  vmovaps [rsp+0xB0], xmm11
00007dd8c99da11d  vmovaps [rsp+0xC0], xmm12
00007dd8c99da126  vmovaps [rsp+0xD0], xmm13
00007dd8c99da12f  vmovaps [rsp+0xE0], xmm15
00007dd8c99da138  sub rsp, 0x30
00007dd8c99da13c  movaps [rsp], xmm14
00007dd8c99da141  movaps [rsp+0x10], xmm12
00007dd8c99da147  movaps [rsp+0x20], xmm1
00007dd8c99da14c  lea rdi, [rsp]
00007dd8c99da150  mov esi, 0x00
00007dd8c99da155  mov rax, 0x55FEBBDB5530
00007dd8c99da15f  call rax
00007dd8c99da161  movaps xmm14, [rsp]
00007dd8c99da166  add rsp, 0x30
00007dd8c99da16a  vmovaps xmm0, [rsp]
00007dd8c99da16f  vmovaps xmm1, [rsp+0x10]
00007dd8c99da175  vmovaps xmm2, [rsp+0x20]
00007dd8c99da17b  vmovaps xmm3, [rsp+0x30]
00007dd8c99da181  vmovaps xmm4, [rsp+0x40]
00007dd8c99da187  vmovaps xmm5, [rsp+0x50]
00007dd8c99da18d  vmovaps xmm6, [rsp+0x60]
00007dd8c99da193  vmovaps xmm7, [rsp+0x70]
00007dd8c99da199  vmovaps xmm8, [rsp+0x80]
00007dd8c99da1a2  vmovaps xmm9, [rsp+0x90]
00007dd8c99da1ab  vmovaps xmm10, [rsp+0xA0]
00007dd8c99da1b4  vmovaps xmm11, [rsp+0xB0]
00007dd8c99da1bd  vmovaps xmm12, [rsp+0xC0]
00007dd8c99da1c6  vmovaps xmm13, [rsp+0xD0]
00007dd8c99da1cf  vmovaps xmm15, [rsp+0xE0]
00007dd8c99da1d8  add rsp, 0xF0
00007dd8c99da1df  pop r11
00007dd8c99da1e1  pop r10
00007dd8c99da1e3  pop r9
00007dd8c99da1e5  pop r8
00007dd8c99da1e7  pop rsi
00007dd8c99da1e8  pop rdi
00007dd8c99da1e9  pop rdx
00007dd8c99da1ea  pop rcx
00007dd8c99da1eb  pop rax
00007dd8c99da1ec  add rsp, 0x08
00007dd8c99da1f0  jmp 0x00007DD8C99D6400
00007dd8c99da1f5  sub rsp, 0x08
00007dd8c99da1f9  push rax
00007dd8c99da1fa  push rcx
00007dd8c99da1fb  push rdx
00007dd8c99da1fc  push rdi
00007dd8c99da1fd  push rsi
00007dd8c99da1fe  push r8
00007dd8c99da200  push r9
00007dd8c99da202  push r10
00007dd8c99da204  push r11
00007dd8c99da206  sub rsp, 0xF0
00007dd8c99da20d  vmovaps [rsp], xmm0
00007dd8c99da212  vmovaps [rsp+0x10], xmm2
00007dd8c99da218  vmovaps [rsp+0x20], xmm3
00007dd8c99da21e  vmovaps [rsp+0x30], xmm4
00007dd8c99da224  vmovaps [rsp+0x40], xmm5
00007dd8c99da22a  vmovaps [rsp+0x50], xmm6
00007dd8c99da230  vmovaps [rsp+0x60], xmm7
00007dd8c99da236  vmovaps [rsp+0x70], xmm8
00007dd8c99da23c  vmovaps [rsp+0x80], xmm9
00007dd8c99da245  vmovaps [rsp+0x90], xmm10
00007dd8c99da24e  vmovaps [rsp+0xA0], xmm11
00007dd8c99da257  vmovaps [rsp+0xB0], xmm12
00007dd8c99da260  vmovaps [rsp+0xC0], xmm13
00007dd8c99da269  vmovaps [rsp+0xD0], xmm14
00007dd8c99da272  vmovaps [rsp+0xE0], xmm15
00007dd8c99da27b  sub rsp, 0x30
00007dd8c99da27f  movaps [rsp], xmm1
00007dd8c99da283  movaps [rsp+0x10], xmm13
00007dd8c99da289  movaps [rsp+0x20], xmm9
00007dd8c99da28f  lea rdi, [rsp]
00007dd8c99da293  mov esi, 0x00
00007dd8c99da298  mov rax, 0x55FEBBDB5530
00007dd8c99da2a2  call rax
00007dd8c99da2a4  movaps xmm1, [rsp]
00007dd8c99da2a8  add rsp, 0x30
00007dd8c99da2ac  vmovaps xmm0, [rsp]
00007dd8c99da2b1  vmovaps xmm2, [rsp+0x10]
00007dd8c99da2b7  vmovaps xmm3, [rsp+0x20]
00007dd8c99da2bd  vmovaps xmm4, [rsp+0x30]
00007dd8c99da2c3  vmovaps xmm5, [rsp+0x40]
00007dd8c99da2c9  vmovaps xmm6, [rsp+0x50]
00007dd8c99da2cf  vmovaps xmm7, [rsp+0x60]
00007dd8c99da2d5  vmovaps xmm8, [rsp+0x70]
00007dd8c99da2db  vmovaps xmm9, [rsp+0x80]
00007dd8c99da2e4  vmovaps xmm10, [rsp+0x90]
00007dd8c99da2ed  vmovaps xmm11, [rsp+0xA0]
00007dd8c99da2f6  vmovaps xmm12, [rsp+0xB0]
00007dd8c99da2ff  vmovaps xmm13, [rsp+0xC0]
00007dd8c99da308  vmovaps xmm14, [rsp+0xD0]
00007dd8c99da311  vmovaps xmm15, [rsp+0xE0]
00007dd8c99da31a  add rsp, 0xF0
00007dd8c99da321  pop r11
00007dd8c99da323  pop r10
00007dd8c99da325  pop r9
00007dd8c99da327  pop r8
00007dd8c99da329  pop rsi
00007dd8c99da32a  pop rdi
00007dd8c99da32b  pop rdx
00007dd8c99da32c  pop rcx
00007dd8c99da32d  pop rax
00007dd8c99da32e  add rsp, 0x08
00007dd8c99da332  jmp 0x00007DD8C99D641A
00007dd8c99da337  sub rsp, 0x08
00007dd8c99da33b  push rax
00007dd8c99da33c  push rcx
00007dd8c99da33d  push rdx
00007dd8c99da33e  push rdi
00007dd8c99da33f  push rsi
00007dd8c99da340  push r8
00007dd8c99da342  push r9
00007dd8c99da344  push r10
00007dd8c99da346  push r11
00007dd8c99da348  sub rsp, 0xF0
00007dd8c99da34f  vmovaps [rsp], xmm0
00007dd8c99da354  vmovaps [rsp+0x10], xmm1
00007dd8c99da35a  vmovaps [rsp+0x20], xmm2
00007dd8c99da360  vmovaps [rsp+0x30], xmm3
00007dd8c99da366  vmovaps [rsp+0x40], xmm4
00007dd8c99da36c  vmovaps [rsp+0x50], xmm5
00007dd8c99da372  vmovaps [rsp+0x60], xmm6
00007dd8c99da378  vmovaps [rsp+0x70], xmm7
00007dd8c99da37e  vmovaps [rsp+0x80], xmm8
00007dd8c99da387  vmovaps [rsp+0x90], xmm9
00007dd8c99da390  vmovaps [rsp+0xA0], xmm10
00007dd8c99da399  vmovaps [rsp+0xB0], xmm11
00007dd8c99da3a2  vmovaps [rsp+0xC0], xmm13
00007dd8c99da3ab  vmovaps [rsp+0xD0], xmm14
00007dd8c99da3b4  vmovaps [rsp+0xE0], xmm15
00007dd8c99da3bd  sub rsp, 0x30
00007dd8c99da3c1  movaps [rsp], xmm12
00007dd8c99da3c6  movaps [rsp+0x10], xmm7
00007dd8c99da3cb  movaps [rsp+0x20], xmm13
00007dd8c99da3d1  lea rdi, [rsp]
00007dd8c99da3d5  mov esi, 0x00
00007dd8c99da3da  mov rax, 0x55FEBBDB5530
00007dd8c99da3e4  call rax
00007dd8c99da3e6  movaps xmm12, [rsp]
00007dd8c99da3eb  add rsp, 0x30
00007dd8c99da3ef  vmovaps xmm0, [rsp]
00007dd8c99da3f4  vmovaps xmm1, [rsp+0x10]
00007dd8c99da3fa  vmovaps xmm2, [rsp+0x20]
00007dd8c99da400  vmovaps xmm3, [rsp+0x30]
00007dd8c99da406  vmovaps xmm4, [rsp+0x40]
00007dd8c99da40c  vmovaps xmm5, [rsp+0x50]
00007dd8c99da412  vmovaps xmm6, [rsp+0x60]
00007dd8c99da418  vmovaps xmm7, [rsp+0x70]
00007dd8c99da41e  vmovaps xmm8, [rsp+0x80]
00007dd8c99da427  vmovaps xmm9, [rsp+0x90]
00007dd8c99da430  vmovaps xmm10, [rsp+0xA0]
00007dd8c99da439  vmovaps xmm11, [rsp+0xB0]
00007dd8c99da442  vmovaps xmm13, [rsp+0xC0]
00007dd8c99da44b  vmovaps xmm14, [rsp+0xD0]
00007dd8c99da454  vmovaps xmm15, [rsp+0xE0]
00007dd8c99da45d  add rsp, 0xF0
00007dd8c99da464  pop r11
00007dd8c99da466  pop r10
00007dd8c99da468  pop r9
00007dd8c99da46a  pop r8
00007dd8c99da46c  pop rsi
00007dd8c99da46d  pop rdi
00007dd8c99da46e  pop rdx
00007dd8c99da46f  pop rcx
00007dd8c99da470  pop rax
00007dd8c99da471  add rsp, 0x08
00007dd8c99da475  jmp 0x00007DD8C99D6441
00007dd8c99da47a  sub rsp, 0x08
00007dd8c99da47e  push rax
00007dd8c99da47f  push rcx
00007dd8c99da480  push rdx
00007dd8c99da481  push rdi
00007dd8c99da482  push rsi
00007dd8c99da483  push r8
00007dd8c99da485  push r9
00007dd8c99da487  push r10
00007dd8c99da489  push r11
00007dd8c99da48b  sub rsp, 0xF0
00007dd8c99da492  vmovaps [rsp], xmm0
00007dd8c99da497  vmovaps [rsp+0x10], xmm1
00007dd8c99da49d  vmovaps [rsp+0x20], xmm2
00007dd8c99da4a3  vmovaps [rsp+0x30], xmm3
00007dd8c99da4a9  vmovaps [rsp+0x40], xmm4
00007dd8c99da4af  vmovaps [rsp+0x50], xmm5
00007dd8c99da4b5  vmovaps [rsp+0x60], xmm6
00007dd8c99da4bb  vmovaps [rsp+0x70], xmm7
00007dd8c99da4c1  vmovaps [rsp+0x80], xmm8
00007dd8c99da4ca  vmovaps [rsp+0x90], xmm9
00007dd8c99da4d3  vmovaps [rsp+0xA0], xmm10
00007dd8c99da4dc  vmovaps [rsp+0xB0], xmm11
00007dd8c99da4e5  vmovaps [rsp+0xC0], xmm12
00007dd8c99da4ee  vmovaps [rsp+0xD0], xmm14
00007dd8c99da4f7  vmovaps [rsp+0xE0], xmm15
00007dd8c99da500  sub rsp, 0x30
00007dd8c99da504  movaps [rsp], xmm13
00007dd8c99da509  movaps [rsp+0x10], xmm15
00007dd8c99da50f  movaps [rsp+0x20], xmm8
00007dd8c99da515  lea rdi, [rsp]
00007dd8c99da519  mov esi, 0x00
00007dd8c99da51e  mov rax, 0x55FEBBDB5530
00007dd8c99da528  call rax
00007dd8c99da52a  movaps xmm13, [rsp]
00007dd8c99da52f  add rsp, 0x30
00007dd8c99da533  vmovaps xmm0, [rsp]
00007dd8c99da538  vmovaps xmm1, [rsp+0x10]
00007dd8c99da53e  vmovaps xmm2, [rsp+0x20]
00007dd8c99da544  vmovaps xmm3, [rsp+0x30]
00007dd8c99da54a  vmovaps xmm4, [rsp+0x40]
00007dd8c99da550  vmovaps xmm5, [rsp+0x50]
00007dd8c99da556  vmovaps xmm6, [rsp+0x60]
00007dd8c99da55c  vmovaps xmm7, [rsp+0x70]
00007dd8c99da562  vmovaps xmm8, [rsp+0x80]
00007dd8c99da56b  vmovaps xmm9, [rsp+0x90]
00007dd8c99da574  vmovaps xmm10, [rsp+0xA0]
00007dd8c99da57d  vmovaps xmm11, [rsp+0xB0]
00007dd8c99da586  vmovaps xmm12, [rsp+0xC0]
00007dd8c99da58f  vmovaps xmm14, [rsp+0xD0]
00007dd8c99da598  vmovaps xmm15, [rsp+0xE0]
00007dd8c99da5a1  add rsp, 0xF0
00007dd8c99da5a8  pop r11
00007dd8c99da5aa  pop r10
00007dd8c99da5ac  pop r9
00007dd8c99da5ae  pop r8
00007dd8c99da5b0  pop rsi
00007dd8c99da5b1  pop rdi
00007dd8c99da5b2  pop rdx
00007dd8c99da5b3  pop rcx
00007dd8c99da5b4  pop rax
00007dd8c99da5b5  add rsp, 0x08
00007dd8c99da5b9  jmp 0x00007DD8C99D645C
00007dd8c99da5be  sub rsp, 0x08
00007dd8c99da5c2  push rax
00007dd8c99da5c3  push rcx
00007dd8c99da5c4  push rdx
00007dd8c99da5c5  push rdi
00007dd8c99da5c6  push rsi
00007dd8c99da5c7  push r8
00007dd8c99da5c9  push r9
00007dd8c99da5cb  push r10
00007dd8c99da5cd  push r11
00007dd8c99da5cf  sub rsp, 0xF0
00007dd8c99da5d6  vmovaps [rsp], xmm0
00007dd8c99da5db  vmovaps [rsp+0x10], xmm1
00007dd8c99da5e1  vmovaps [rsp+0x20], xmm2
00007dd8c99da5e7  vmovaps [rsp+0x30], xmm3
00007dd8c99da5ed  vmovaps [rsp+0x40], xmm4
00007dd8c99da5f3  vmovaps [rsp+0x50], xmm5
00007dd8c99da5f9  vmovaps [rsp+0x60], xmm6
00007dd8c99da5ff  vmovaps [rsp+0x70], xmm7
00007dd8c99da605  vmovaps [rsp+0x80], xmm9
00007dd8c99da60e  vmovaps [rsp+0x90], xmm10
00007dd8c99da617  vmovaps [rsp+0xA0], xmm11
00007dd8c99da620  vmovaps [rsp+0xB0], xmm12
00007dd8c99da629  vmovaps [rsp+0xC0], xmm13
00007dd8c99da632  vmovaps [rsp+0xD0], xmm14
00007dd8c99da63b  vmovaps [rsp+0xE0], xmm15
00007dd8c99da644  sub rsp, 0x30
00007dd8c99da648  movaps [rsp], xmm8
00007dd8c99da64d  movaps [rsp+0x10], xmm15
00007dd8c99da653  movaps [rsp+0x20], xmm9
00007dd8c99da659  lea rdi, [rsp]
00007dd8c99da65d  mov esi, 0x00
00007dd8c99da662  mov rax, 0x55FEBBDB5530
00007dd8c99da66c  call rax
00007dd8c99da66e  movaps xmm8, [rsp]
00007dd8c99da673  add rsp, 0x30
00007dd8c99da677  vmovaps xmm0, [rsp]
00007dd8c99da67c  vmovaps xmm1, [rsp+0x10]
00007dd8c99da682  vmovaps xmm2, [rsp+0x20]
00007dd8c99da688  vmovaps xmm3, [rsp+0x30]
00007dd8c99da68e  vmovaps xmm4, [rsp+0x40]
00007dd8c99da694  vmovaps xmm5, [rsp+0x50]
00007dd8c99da69a  vmovaps xmm6, [rsp+0x60]
00007dd8c99da6a0  vmovaps xmm7, [rsp+0x70]
00007dd8c99da6a6  vmovaps xmm9, [rsp+0x80]
00007dd8c99da6af  vmovaps xmm10, [rsp+0x90]
00007dd8c99da6b8  vmovaps xmm11, [rsp+0xA0]
00007dd8c99da6c1  vmovaps xmm12, [rsp+0xB0]
00007dd8c99da6ca  vmovaps xmm13, [rsp+0xC0]
00007dd8c99da6d3  vmovaps xmm14, [rsp+0xD0]
00007dd8c99da6dc  vmovaps xmm15, [rsp+0xE0]
00007dd8c99da6e5  add rsp, 0xF0
00007dd8c99da6ec  pop r11
00007dd8c99da6ee  pop r10
00007dd8c99da6f0  pop r9
00007dd8c99da6f2  pop r8
00007dd8c99da6f4  pop rsi
00007dd8c99da6f5  pop rdi
00007dd8c99da6f6  pop rdx
00007dd8c99da6f7  pop rcx
00007dd8c99da6f8  pop rax
00007dd8c99da6f9  add rsp, 0x08
00007dd8c99da6fd  jmp 0x00007DD8C99D648A
00007dd8c99da702  sub rsp, 0x08
00007dd8c99da706  push rax
00007dd8c99da707  push rcx
00007dd8c99da708  push rdx
00007dd8c99da709  push rdi
00007dd8c99da70a  push rsi
00007dd8c99da70b  push r8
00007dd8c99da70d  push r9
00007dd8c99da70f  push r10
00007dd8c99da711  push r11
00007dd8c99da713  sub rsp, 0xF0
00007dd8c99da71a  vmovaps [rsp], xmm0
00007dd8c99da71f  vmovaps [rsp+0x10], xmm1
00007dd8c99da725  vmovaps [rsp+0x20], xmm2
00007dd8c99da72b  vmovaps [rsp+0x30], xmm3
00007dd8c99da731  vmovaps [rsp+0x40], xmm4
00007dd8c99da737  vmovaps [rsp+0x50], xmm5
00007dd8c99da73d  vmovaps [rsp+0x60], xmm6
00007dd8c99da743  vmovaps [rsp+0x70], xmm7
00007dd8c99da749  vmovaps [rsp+0x80], xmm8
00007dd8c99da752  vmovaps [rsp+0x90], xmm9
00007dd8c99da75b  vmovaps [rsp+0xA0], xmm10
00007dd8c99da764  vmovaps [rsp+0xB0], xmm11
00007dd8c99da76d  vmovaps [rsp+0xC0], xmm12
00007dd8c99da776  vmovaps [rsp+0xD0], xmm13
00007dd8c99da77f  vmovaps [rsp+0xE0], xmm14
00007dd8c99da788  sub rsp, 0x30
00007dd8c99da78c  movaps [rsp], xmm15
00007dd8c99da791  movaps [rsp+0x10], xmm11
00007dd8c99da797  movaps [rsp+0x20], xmm6
00007dd8c99da79c  lea rdi, [rsp]
00007dd8c99da7a0  mov esi, 0x00
00007dd8c99da7a5  mov rax, 0x55FEBBDB5530
00007dd8c99da7af  call rax
00007dd8c99da7b1  movaps xmm15, [rsp]
00007dd8c99da7b6  add rsp, 0x30
00007dd8c99da7ba  vmovaps xmm0, [rsp]
00007dd8c99da7bf  vmovaps xmm1, [rsp+0x10]
00007dd8c99da7c5  vmovaps xmm2, [rsp+0x20]
00007dd8c99da7cb  vmovaps xmm3, [rsp+0x30]
00007dd8c99da7d1  vmovaps xmm4, [rsp+0x40]
00007dd8c99da7d7  vmovaps xmm5, [rsp+0x50]
00007dd8c99da7dd  vmovaps xmm6, [rsp+0x60]
00007dd8c99da7e3  vmovaps xmm7, [rsp+0x70]
00007dd8c99da7e9  vmovaps xmm8, [rsp+0x80]
00007dd8c99da7f2  vmovaps xmm9, [rsp+0x90]
00007dd8c99da7fb  vmovaps xmm10, [rsp+0xA0]
00007dd8c99da804  vmovaps xmm11, [rsp+0xB0]
00007dd8c99da80d  vmovaps xmm12, [rsp+0xC0]
00007dd8c99da816  vmovaps xmm13, [rsp+0xD0]
00007dd8c99da81f  vmovaps xmm14, [rsp+0xE0]
00007dd8c99da828  add rsp, 0xF0
00007dd8c99da82f  pop r11
00007dd8c99da831  pop r10
00007dd8c99da833  pop r9
00007dd8c99da835  pop r8
00007dd8c99da837  pop rsi
00007dd8c99da838  pop rdi
00007dd8c99da839  pop rdx
00007dd8c99da83a  pop rcx
00007dd8c99da83b  pop rax
00007dd8c99da83c  add rsp, 0x08
00007dd8c99da840  jmp 0x00007DD8C99D64A5
00007dd8c99da845  sub rsp, 0x08
00007dd8c99da849  push rax
00007dd8c99da84a  push rcx
00007dd8c99da84b  push rdx
00007dd8c99da84c  push rdi
00007dd8c99da84d  push rsi
00007dd8c99da84e  push r8
00007dd8c99da850  push r9
00007dd8c99da852  push r10
00007dd8c99da854  push r11
00007dd8c99da856  sub rsp, 0xF0
00007dd8c99da85d  vmovaps [rsp], xmm0
00007dd8c99da862  vmovaps [rsp+0x10], xmm1
00007dd8c99da868  vmovaps [rsp+0x20], xmm2
00007dd8c99da86e  vmovaps [rsp+0x30], xmm3
00007dd8c99da874  vmovaps [rsp+0x40], xmm4
00007dd8c99da87a  vmovaps [rsp+0x50], xmm5
00007dd8c99da880  vmovaps [rsp+0x60], xmm6
00007dd8c99da886  vmovaps [rsp+0x70], xmm8
00007dd8c99da88c  vmovaps [rsp+0x80], xmm9
00007dd8c99da895  vmovaps [rsp+0x90], xmm10
00007dd8c99da89e  vmovaps [rsp+0xA0], xmm11
00007dd8c99da8a7  vmovaps [rsp+0xB0], xmm12
00007dd8c99da8b0  vmovaps [rsp+0xC0], xmm13
00007dd8c99da8b9  vmovaps [rsp+0xD0], xmm14
00007dd8c99da8c2  vmovaps [rsp+0xE0], xmm15
00007dd8c99da8cb  sub rsp, 0x30
00007dd8c99da8cf  movaps [rsp], xmm7
00007dd8c99da8d3  movaps [rsp+0x10], xmm11
00007dd8c99da8d9  movaps [rsp+0x20], xmm9
00007dd8c99da8df  lea rdi, [rsp]
00007dd8c99da8e3  mov esi, 0x00
00007dd8c99da8e8  mov rax, 0x55FEBBDB5530
00007dd8c99da8f2  call rax
00007dd8c99da8f4  movaps xmm7, [rsp]
00007dd8c99da8f8  add rsp, 0x30
00007dd8c99da8fc  vmovaps xmm0, [rsp]
00007dd8c99da901  vmovaps xmm1, [rsp+0x10]
00007dd8c99da907  vmovaps xmm2, [rsp+0x20]
00007dd8c99da90d  vmovaps xmm3, [rsp+0x30]
00007dd8c99da913  vmovaps xmm4, [rsp+0x40]
00007dd8c99da919  vmovaps xmm5, [rsp+0x50]
00007dd8c99da91f  vmovaps xmm6, [rsp+0x60]
00007dd8c99da925  vmovaps xmm8, [rsp+0x70]
00007dd8c99da92b  vmovaps xmm9, [rsp+0x80]
00007dd8c99da934  vmovaps xmm10, [rsp+0x90]
00007dd8c99da93d  vmovaps xmm11, [rsp+0xA0]
00007dd8c99da946  vmovaps xmm12, [rsp+0xB0]
00007dd8c99da94f  vmovaps xmm13, [rsp+0xC0]
00007dd8c99da958  vmovaps xmm14, [rsp+0xD0]
00007dd8c99da961  vmovaps xmm15, [rsp+0xE0]
00007dd8c99da96a  add rsp, 0xF0
00007dd8c99da971  pop r11
00007dd8c99da973  pop r10
00007dd8c99da975  pop r9
00007dd8c99da977  pop r8
00007dd8c99da979  pop rsi
00007dd8c99da97a  pop rdi
00007dd8c99da97b  pop rdx
00007dd8c99da97c  pop rcx
00007dd8c99da97d  pop rax
00007dd8c99da97e  add rsp, 0x08
00007dd8c99da982  jmp 0x00007DD8C99D64D2
00007dd8c99da987  sub rsp, 0x08
00007dd8c99da98b  push rax
00007dd8c99da98c  push rcx
00007dd8c99da98d  push rdx
00007dd8c99da98e  push rdi
00007dd8c99da98f  push rsi
00007dd8c99da990  push r8
00007dd8c99da992  push r9
00007dd8c99da994  push r10
00007dd8c99da996  push r11
00007dd8c99da998  sub rsp, 0xF0
00007dd8c99da99f  vmovaps [rsp], xmm0
00007dd8c99da9a4  vmovaps [rsp+0x10], xmm1
00007dd8c99da9aa  vmovaps [rsp+0x20], xmm2
00007dd8c99da9b0  vmovaps [rsp+0x30], xmm3
00007dd8c99da9b6  vmovaps [rsp+0x40], xmm4
00007dd8c99da9bc  vmovaps [rsp+0x50], xmm5
00007dd8c99da9c2  vmovaps [rsp+0x60], xmm6
00007dd8c99da9c8  vmovaps [rsp+0x70], xmm7
00007dd8c99da9ce  vmovaps [rsp+0x80], xmm8
00007dd8c99da9d7  vmovaps [rsp+0x90], xmm9
00007dd8c99da9e0  vmovaps [rsp+0xA0], xmm10
00007dd8c99da9e9  vmovaps [rsp+0xB0], xmm12
00007dd8c99da9f2  vmovaps [rsp+0xC0], xmm13
00007dd8c99da9fb  vmovaps [rsp+0xD0], xmm14
00007dd8c99daa04  vmovaps [rsp+0xE0], xmm15
00007dd8c99daa0d  sub rsp, 0x30
00007dd8c99daa11  movaps [rsp], xmm11
00007dd8c99daa16  movaps [rsp+0x10], xmm10
00007dd8c99daa1c  movaps [rsp+0x20], xmm14
00007dd8c99daa22  lea rdi, [rsp]
00007dd8c99daa26  mov esi, 0x00
00007dd8c99daa2b  mov rax, 0x55FEBBDB5530
00007dd8c99daa35  call rax
00007dd8c99daa37  movaps xmm11, [rsp]
00007dd8c99daa3c  add rsp, 0x30
00007dd8c99daa40  vmovaps xmm0, [rsp]
00007dd8c99daa45  vmovaps xmm1, [rsp+0x10]
00007dd8c99daa4b  vmovaps xmm2, [rsp+0x20]
00007dd8c99daa51  vmovaps xmm3, [rsp+0x30]
00007dd8c99daa57  vmovaps xmm4, [rsp+0x40]
00007dd8c99daa5d  vmovaps xmm5, [rsp+0x50]
00007dd8c99daa63  vmovaps xmm6, [rsp+0x60]
00007dd8c99daa69  vmovaps xmm7, [rsp+0x70]
00007dd8c99daa6f  vmovaps xmm8, [rsp+0x80]
00007dd8c99daa78  vmovaps xmm9, [rsp+0x90]
00007dd8c99daa81  vmovaps xmm10, [rsp+0xA0]
00007dd8c99daa8a  vmovaps xmm12, [rsp+0xB0]
00007dd8c99daa93  vmovaps xmm13, [rsp+0xC0]
00007dd8c99daa9c  vmovaps xmm14, [rsp+0xD0]
00007dd8c99daaa5  vmovaps xmm15, [rsp+0xE0]
00007dd8c99daaae  add rsp, 0xF0
00007dd8c99daab5  pop r11
00007dd8c99daab7  pop r10
00007dd8c99daab9  pop r9
00007dd8c99daabb  pop r8
00007dd8c99daabd  pop rsi
00007dd8c99daabe  pop rdi
00007dd8c99daabf  pop rdx
00007dd8c99daac0  pop rcx
00007dd8c99daac1  pop rax
00007dd8c99daac2  add rsp, 0x08
00007dd8c99daac6  jmp 0x00007DD8C99D64ED
00007dd8c99daacb  call 0x00007DD8C98E45A0
00007dd8c99daad0  jmp 0x00007DD8C99D64F7
00007dd8c99daad5  sub rsp, 0x08
00007dd8c99daad9  push rax
00007dd8c99daada  push rcx
00007dd8c99daadb  push rdx
00007dd8c99daadc  push rdi
00007dd8c99daadd  push rsi
00007dd8c99daade  push r8
00007dd8c99daae0  push r9
00007dd8c99daae2  push r10
00007dd8c99daae4  push r11
00007dd8c99daae6  sub rsp, 0xF0
00007dd8c99daaed  vmovaps [rsp], xmm0
00007dd8c99daaf2  vmovaps [rsp+0x10], xmm1
00007dd8c99daaf8  vmovaps [rsp+0x20], xmm2
00007dd8c99daafe  vmovaps [rsp+0x30], xmm3
00007dd8c99dab04  vmovaps [rsp+0x40], xmm4
00007dd8c99dab0a  vmovaps [rsp+0x50], xmm5
00007dd8c99dab10  vmovaps [rsp+0x60], xmm6
00007dd8c99dab16  vmovaps [rsp+0x70], xmm7
00007dd8c99dab1c  vmovaps [rsp+0x80], xmm8
00007dd8c99dab25  vmovaps [rsp+0x90], xmm9
00007dd8c99dab2e  vmovaps [rsp+0xA0], xmm11
00007dd8c99dab37  vmovaps [rsp+0xB0], xmm12
00007dd8c99dab40  vmovaps [rsp+0xC0], xmm13
00007dd8c99dab49  vmovaps [rsp+0xD0], xmm14
00007dd8c99dab52  vmovaps [rsp+0xE0], xmm15
00007dd8c99dab5b  sub rsp, 0x30
00007dd8c99dab5f  movaps [rsp], xmm10
00007dd8c99dab64  movaps [rsp+0x10], xmm1
00007dd8c99dab69  movaps [rsp+0x20], xmm12
00007dd8c99dab6f  lea rdi, [rsp]
00007dd8c99dab73  mov esi, 0x00
00007dd8c99dab78  mov rax, 0x55FEBBDB5530
00007dd8c99dab82  call rax
00007dd8c99dab84  movaps xmm10, [rsp]
00007dd8c99dab89  add rsp, 0x30
00007dd8c99dab8d  vmovaps xmm0, [rsp]
00007dd8c99dab92  vmovaps xmm1, [rsp+0x10]
00007dd8c99dab98  vmovaps xmm2, [rsp+0x20]
00007dd8c99dab9e  vmovaps xmm3, [rsp+0x30]
00007dd8c99daba4  vmovaps xmm4, [rsp+0x40]
00007dd8c99dabaa  vmovaps xmm5, [rsp+0x50]
00007dd8c99dabb0  vmovaps xmm6, [rsp+0x60]
00007dd8c99dabb6  vmovaps xmm7, [rsp+0x70]
00007dd8c99dabbc  vmovaps xmm8, [rsp+0x80]
00007dd8c99dabc5  vmovaps xmm9, [rsp+0x90]
00007dd8c99dabce  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dabd7  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dabe0  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dabe9  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dabf2  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dabfb  add rsp, 0xF0
00007dd8c99dac02  pop r11
00007dd8c99dac04  pop r10
00007dd8c99dac06  pop r9
00007dd8c99dac08  pop r8
00007dd8c99dac0a  pop rsi
00007dd8c99dac0b  pop rdi
00007dd8c99dac0c  pop rdx
00007dd8c99dac0d  pop rcx
00007dd8c99dac0e  pop rax
00007dd8c99dac0f  add rsp, 0x08
00007dd8c99dac13  jmp 0x00007DD8C99D651A
00007dd8c99dac18  sub rsp, 0x08
00007dd8c99dac1c  push rax
00007dd8c99dac1d  push rcx
00007dd8c99dac1e  push rdx
00007dd8c99dac1f  push rdi
00007dd8c99dac20  push rsi
00007dd8c99dac21  push r8
00007dd8c99dac23  push r9
00007dd8c99dac25  push r10
00007dd8c99dac27  push r11
00007dd8c99dac29  sub rsp, 0xF0
00007dd8c99dac30  vmovaps [rsp], xmm0
00007dd8c99dac35  vmovaps [rsp+0x10], xmm1
00007dd8c99dac3b  vmovaps [rsp+0x20], xmm2
00007dd8c99dac41  vmovaps [rsp+0x30], xmm3
00007dd8c99dac47  vmovaps [rsp+0x40], xmm4
00007dd8c99dac4d  vmovaps [rsp+0x50], xmm5
00007dd8c99dac53  vmovaps [rsp+0x60], xmm6
00007dd8c99dac59  vmovaps [rsp+0x70], xmm7
00007dd8c99dac5f  vmovaps [rsp+0x80], xmm8
00007dd8c99dac68  vmovaps [rsp+0x90], xmm9
00007dd8c99dac71  vmovaps [rsp+0xA0], xmm10
00007dd8c99dac7a  vmovaps [rsp+0xB0], xmm11
00007dd8c99dac83  vmovaps [rsp+0xC0], xmm13
00007dd8c99dac8c  vmovaps [rsp+0xD0], xmm14
00007dd8c99dac95  vmovaps [rsp+0xE0], xmm15
00007dd8c99dac9e  sub rsp, 0x30
00007dd8c99daca2  movaps [rsp], xmm12
00007dd8c99daca7  movaps [rsp+0x10], xmm14
00007dd8c99dacad  movaps [rsp+0x20], xmm1
00007dd8c99dacb2  lea rdi, [rsp]
00007dd8c99dacb6  mov esi, 0x00
00007dd8c99dacbb  mov rax, 0x55FEBBDB5530
00007dd8c99dacc5  call rax
00007dd8c99dacc7  movaps xmm12, [rsp]
00007dd8c99daccc  add rsp, 0x30
00007dd8c99dacd0  vmovaps xmm0, [rsp]
00007dd8c99dacd5  vmovaps xmm1, [rsp+0x10]
00007dd8c99dacdb  vmovaps xmm2, [rsp+0x20]
00007dd8c99dace1  vmovaps xmm3, [rsp+0x30]
00007dd8c99dace7  vmovaps xmm4, [rsp+0x40]
00007dd8c99daced  vmovaps xmm5, [rsp+0x50]
00007dd8c99dacf3  vmovaps xmm6, [rsp+0x60]
00007dd8c99dacf9  vmovaps xmm7, [rsp+0x70]
00007dd8c99dacff  vmovaps xmm8, [rsp+0x80]
00007dd8c99dad08  vmovaps xmm9, [rsp+0x90]
00007dd8c99dad11  vmovaps xmm10, [rsp+0xA0]
00007dd8c99dad1a  vmovaps xmm11, [rsp+0xB0]
00007dd8c99dad23  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dad2c  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dad35  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dad3e  add rsp, 0xF0
00007dd8c99dad45  pop r11
00007dd8c99dad47  pop r10
00007dd8c99dad49  pop r9
00007dd8c99dad4b  pop r8
00007dd8c99dad4d  pop rsi
00007dd8c99dad4e  pop rdi
00007dd8c99dad4f  pop rdx
00007dd8c99dad50  pop rcx
00007dd8c99dad51  pop rax
00007dd8c99dad52  add rsp, 0x08
00007dd8c99dad56  jmp 0x00007DD8C99D6549
00007dd8c99dad5b  sub rsp, 0x08
00007dd8c99dad5f  push rax
00007dd8c99dad60  push rcx
00007dd8c99dad61  push rdx
00007dd8c99dad62  push rdi
00007dd8c99dad63  push rsi
00007dd8c99dad64  push r8
00007dd8c99dad66  push r9
00007dd8c99dad68  push r10
00007dd8c99dad6a  push r11
00007dd8c99dad6c  sub rsp, 0xF0
00007dd8c99dad73  vmovaps [rsp], xmm0
00007dd8c99dad78  vmovaps [rsp+0x10], xmm1
00007dd8c99dad7e  vmovaps [rsp+0x20], xmm2
00007dd8c99dad84  vmovaps [rsp+0x30], xmm3
00007dd8c99dad8a  vmovaps [rsp+0x40], xmm4
00007dd8c99dad90  vmovaps [rsp+0x50], xmm5
00007dd8c99dad96  vmovaps [rsp+0x60], xmm6
00007dd8c99dad9c  vmovaps [rsp+0x70], xmm7
00007dd8c99dada2  vmovaps [rsp+0x80], xmm8
00007dd8c99dadab  vmovaps [rsp+0x90], xmm9
00007dd8c99dadb4  vmovaps [rsp+0xA0], xmm10
00007dd8c99dadbd  vmovaps [rsp+0xB0], xmm11
00007dd8c99dadc6  vmovaps [rsp+0xC0], xmm12
00007dd8c99dadcf  vmovaps [rsp+0xD0], xmm13
00007dd8c99dadd8  vmovaps [rsp+0xE0], xmm15
00007dd8c99dade1  sub rsp, 0x30
00007dd8c99dade5  movaps [rsp], xmm14
00007dd8c99dadea  movaps [rsp+0x10], xmm9
00007dd8c99dadf0  movaps [rsp+0x20], xmm1
00007dd8c99dadf5  lea rdi, [rsp]
00007dd8c99dadf9  mov esi, 0x00
00007dd8c99dadfe  mov rax, 0x55FEBBDB5530
00007dd8c99dae08  call rax
00007dd8c99dae0a  movaps xmm14, [rsp]
00007dd8c99dae0f  add rsp, 0x30
00007dd8c99dae13  vmovaps xmm0, [rsp]
00007dd8c99dae18  vmovaps xmm1, [rsp+0x10]
00007dd8c99dae1e  vmovaps xmm2, [rsp+0x20]
00007dd8c99dae24  vmovaps xmm3, [rsp+0x30]
00007dd8c99dae2a  vmovaps xmm4, [rsp+0x40]
00007dd8c99dae30  vmovaps xmm5, [rsp+0x50]
00007dd8c99dae36  vmovaps xmm6, [rsp+0x60]
00007dd8c99dae3c  vmovaps xmm7, [rsp+0x70]
00007dd8c99dae42  vmovaps xmm8, [rsp+0x80]
00007dd8c99dae4b  vmovaps xmm9, [rsp+0x90]
00007dd8c99dae54  vmovaps xmm10, [rsp+0xA0]
00007dd8c99dae5d  vmovaps xmm11, [rsp+0xB0]
00007dd8c99dae66  vmovaps xmm12, [rsp+0xC0]
00007dd8c99dae6f  vmovaps xmm13, [rsp+0xD0]
00007dd8c99dae78  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dae81  add rsp, 0xF0
00007dd8c99dae88  pop r11
00007dd8c99dae8a  pop r10
00007dd8c99dae8c  pop r9
00007dd8c99dae8e  pop r8
00007dd8c99dae90  pop rsi
00007dd8c99dae91  pop rdi
00007dd8c99dae92  pop rdx
00007dd8c99dae93  pop rcx
00007dd8c99dae94  pop rax
00007dd8c99dae95  add rsp, 0x08
00007dd8c99dae99  jmp 0x00007DD8C99D6578
00007dd8c99dae9e  sub rsp, 0x08
00007dd8c99daea2  push rax
00007dd8c99daea3  push rcx
00007dd8c99daea4  push rdx
00007dd8c99daea5  push rdi
00007dd8c99daea6  push rsi
00007dd8c99daea7  push r8
00007dd8c99daea9  push r9
00007dd8c99daeab  push r10
00007dd8c99daead  push r11
00007dd8c99daeaf  sub rsp, 0xF0
00007dd8c99daeb6  vmovaps [rsp], xmm0
00007dd8c99daebb  vmovaps [rsp+0x10], xmm2
00007dd8c99daec1  vmovaps [rsp+0x20], xmm3
00007dd8c99daec7  vmovaps [rsp+0x30], xmm4
00007dd8c99daecd  vmovaps [rsp+0x40], xmm5
00007dd8c99daed3  vmovaps [rsp+0x50], xmm6
00007dd8c99daed9  vmovaps [rsp+0x60], xmm7
00007dd8c99daedf  vmovaps [rsp+0x70], xmm8
00007dd8c99daee5  vmovaps [rsp+0x80], xmm9
00007dd8c99daeee  vmovaps [rsp+0x90], xmm10
00007dd8c99daef7  vmovaps [rsp+0xA0], xmm11
00007dd8c99daf00  vmovaps [rsp+0xB0], xmm12
00007dd8c99daf09  vmovaps [rsp+0xC0], xmm13
00007dd8c99daf12  vmovaps [rsp+0xD0], xmm14
00007dd8c99daf1b  vmovaps [rsp+0xE0], xmm15
00007dd8c99daf24  sub rsp, 0x30
00007dd8c99daf28  movaps [rsp], xmm1
00007dd8c99daf2c  movaps [rsp+0x10], xmm13
00007dd8c99daf32  movaps [rsp+0x20], xmm8
00007dd8c99daf38  lea rdi, [rsp]
00007dd8c99daf3c  mov esi, 0x00
00007dd8c99daf41  mov rax, 0x55FEBBDB5530
00007dd8c99daf4b  call rax
00007dd8c99daf4d  movaps xmm1, [rsp]
00007dd8c99daf51  add rsp, 0x30
00007dd8c99daf55  vmovaps xmm0, [rsp]
00007dd8c99daf5a  vmovaps xmm2, [rsp+0x10]
00007dd8c99daf60  vmovaps xmm3, [rsp+0x20]
00007dd8c99daf66  vmovaps xmm4, [rsp+0x30]
00007dd8c99daf6c  vmovaps xmm5, [rsp+0x40]
00007dd8c99daf72  vmovaps xmm6, [rsp+0x50]
00007dd8c99daf78  vmovaps xmm7, [rsp+0x60]
00007dd8c99daf7e  vmovaps xmm8, [rsp+0x70]
00007dd8c99daf84  vmovaps xmm9, [rsp+0x80]
00007dd8c99daf8d  vmovaps xmm10, [rsp+0x90]
00007dd8c99daf96  vmovaps xmm11, [rsp+0xA0]
00007dd8c99daf9f  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dafa8  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dafb1  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dafba  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dafc3  add rsp, 0xF0
00007dd8c99dafca  pop r11
00007dd8c99dafcc  pop r10
00007dd8c99dafce  pop r9
00007dd8c99dafd0  pop r8
00007dd8c99dafd2  pop rsi
00007dd8c99dafd3  pop rdi
00007dd8c99dafd4  pop rdx
00007dd8c99dafd5  pop rcx
00007dd8c99dafd6  pop rax
00007dd8c99dafd7  add rsp, 0x08
00007dd8c99dafdb  jmp 0x00007DD8C99D659A
00007dd8c99dafe0  call 0x00007DD8C980C260
00007dd8c99dafe5  jmp 0x00007DD8C99D65A8
00007dd8c99dafea  call 0x00007DD8C98DE950
00007dd8c99dafef  jmp 0x00007DD8C99D65B2
00007dd8c99daff4  sub rsp, 0x08
00007dd8c99daff8  push rax
00007dd8c99daff9  push rcx
00007dd8c99daffa  push rdx
00007dd8c99daffb  push rdi
00007dd8c99daffc  push rsi
00007dd8c99daffd  push r8
00007dd8c99dafff  push r9
00007dd8c99db001  push r10
00007dd8c99db003  push r11
00007dd8c99db005  sub rsp, 0xF0
00007dd8c99db00c  vmovaps [rsp], xmm0
00007dd8c99db011  vmovaps [rsp+0x10], xmm1
00007dd8c99db017  vmovaps [rsp+0x20], xmm2
00007dd8c99db01d  vmovaps [rsp+0x30], xmm3
00007dd8c99db023  vmovaps [rsp+0x40], xmm4
00007dd8c99db029  vmovaps [rsp+0x50], xmm5
00007dd8c99db02f  vmovaps [rsp+0x60], xmm6
00007dd8c99db035  vmovaps [rsp+0x70], xmm7
00007dd8c99db03b  vmovaps [rsp+0x80], xmm9
00007dd8c99db044  vmovaps [rsp+0x90], xmm10
00007dd8c99db04d  vmovaps [rsp+0xA0], xmm11
00007dd8c99db056  vmovaps [rsp+0xB0], xmm12
00007dd8c99db05f  vmovaps [rsp+0xC0], xmm13
00007dd8c99db068  vmovaps [rsp+0xD0], xmm14
00007dd8c99db071  vmovaps [rsp+0xE0], xmm15
00007dd8c99db07a  sub rsp, 0x30
00007dd8c99db07e  movaps [rsp], xmm8
00007dd8c99db083  movaps [rsp+0x10], xmm15
00007dd8c99db089  movaps [rsp+0x20], xmm7
00007dd8c99db08e  lea rdi, [rsp]
00007dd8c99db092  mov esi, 0x00
00007dd8c99db097  mov rax, 0x55FEBBDB5530
00007dd8c99db0a1  call rax
00007dd8c99db0a3  movaps xmm8, [rsp]
00007dd8c99db0a8  add rsp, 0x30
00007dd8c99db0ac  vmovaps xmm0, [rsp]
00007dd8c99db0b1  vmovaps xmm1, [rsp+0x10]
00007dd8c99db0b7  vmovaps xmm2, [rsp+0x20]
00007dd8c99db0bd  vmovaps xmm3, [rsp+0x30]
00007dd8c99db0c3  vmovaps xmm4, [rsp+0x40]
00007dd8c99db0c9  vmovaps xmm5, [rsp+0x50]
00007dd8c99db0cf  vmovaps xmm6, [rsp+0x60]
00007dd8c99db0d5  vmovaps xmm7, [rsp+0x70]
00007dd8c99db0db  vmovaps xmm9, [rsp+0x80]
00007dd8c99db0e4  vmovaps xmm10, [rsp+0x90]
00007dd8c99db0ed  vmovaps xmm11, [rsp+0xA0]
00007dd8c99db0f6  vmovaps xmm12, [rsp+0xB0]
00007dd8c99db0ff  vmovaps xmm13, [rsp+0xC0]
00007dd8c99db108  vmovaps xmm14, [rsp+0xD0]
00007dd8c99db111  vmovaps xmm15, [rsp+0xE0]
00007dd8c99db11a  add rsp, 0xF0
00007dd8c99db121  pop r11
00007dd8c99db123  pop r10
00007dd8c99db125  pop r9
00007dd8c99db127  pop r8
00007dd8c99db129  pop rsi
00007dd8c99db12a  pop rdi
00007dd8c99db12b  pop rdx
00007dd8c99db12c  pop rcx
00007dd8c99db12d  pop rax
00007dd8c99db12e  add rsp, 0x08
00007dd8c99db132  jmp 0x00007DD8C99D65D4
00007dd8c99db137  sub rsp, 0x08
00007dd8c99db13b  push rax
00007dd8c99db13c  push rcx
00007dd8c99db13d  push rdx
00007dd8c99db13e  push rdi
00007dd8c99db13f  push rsi
00007dd8c99db140  push r8
00007dd8c99db142  push r9
00007dd8c99db144  push r10
00007dd8c99db146  push r11
00007dd8c99db148  sub rsp, 0xF0
00007dd8c99db14f  vmovaps [rsp], xmm0
00007dd8c99db154  vmovaps [rsp+0x10], xmm1
00007dd8c99db15a  vmovaps [rsp+0x20], xmm2
00007dd8c99db160  vmovaps [rsp+0x30], xmm3
00007dd8c99db166  vmovaps [rsp+0x40], xmm4
00007dd8c99db16c  vmovaps [rsp+0x50], xmm5
00007dd8c99db172  vmovaps [rsp+0x60], xmm6
00007dd8c99db178  vmovaps [rsp+0x70], xmm8
00007dd8c99db17e  vmovaps [rsp+0x80], xmm9
00007dd8c99db187  vmovaps [rsp+0x90], xmm10
00007dd8c99db190  vmovaps [rsp+0xA0], xmm11
00007dd8c99db199  vmovaps [rsp+0xB0], xmm12
00007dd8c99db1a2  vmovaps [rsp+0xC0], xmm13
00007dd8c99db1ab  vmovaps [rsp+0xD0], xmm14
00007dd8c99db1b4  vmovaps [rsp+0xE0], xmm15
00007dd8c99db1bd  sub rsp, 0x30
00007dd8c99db1c1  movaps [rsp], xmm7
00007dd8c99db1c5  movaps [rsp+0x10], xmm9
00007dd8c99db1cb  movaps [rsp+0x20], xmm15
00007dd8c99db1d1  lea rdi, [rsp]
00007dd8c99db1d5  mov esi, 0x00
00007dd8c99db1da  mov rax, 0x55FEBBDB5530
00007dd8c99db1e4  call rax
00007dd8c99db1e6  movaps xmm7, [rsp]
00007dd8c99db1ea  add rsp, 0x30
00007dd8c99db1ee  vmovaps xmm0, [rsp]
00007dd8c99db1f3  vmovaps xmm1, [rsp+0x10]
00007dd8c99db1f9  vmovaps xmm2, [rsp+0x20]
00007dd8c99db1ff  vmovaps xmm3, [rsp+0x30]
00007dd8c99db205  vmovaps xmm4, [rsp+0x40]
00007dd8c99db20b  vmovaps xmm5, [rsp+0x50]
00007dd8c99db211  vmovaps xmm6, [rsp+0x60]
00007dd8c99db217  vmovaps xmm8, [rsp+0x70]
00007dd8c99db21d  vmovaps xmm9, [rsp+0x80]
00007dd8c99db226  vmovaps xmm10, [rsp+0x90]
00007dd8c99db22f  vmovaps xmm11, [rsp+0xA0]
00007dd8c99db238  vmovaps xmm12, [rsp+0xB0]
00007dd8c99db241  vmovaps xmm13, [rsp+0xC0]
00007dd8c99db24a  vmovaps xmm14, [rsp+0xD0]
00007dd8c99db253  vmovaps xmm15, [rsp+0xE0]
00007dd8c99db25c  add rsp, 0xF0
00007dd8c99db263  pop r11
00007dd8c99db265  pop r10
00007dd8c99db267  pop r9
00007dd8c99db269  pop r8
00007dd8c99db26b  pop rsi
00007dd8c99db26c  pop rdi
00007dd8c99db26d  pop rdx
00007dd8c99db26e  pop rcx
00007dd8c99db26f  pop rax
00007dd8c99db270  add rsp, 0x08
00007dd8c99db274  jmp 0x00007DD8C99D6601
00007dd8c99db279  sub rsp, 0x08
00007dd8c99db27d  push rax
00007dd8c99db27e  push rcx
00007dd8c99db27f  push rdx
00007dd8c99db280  push rdi
00007dd8c99db281  push rsi
00007dd8c99db282  push r8
00007dd8c99db284  push r9
00007dd8c99db286  push r10
00007dd8c99db288  push r11
00007dd8c99db28a  sub rsp, 0xF0
00007dd8c99db291  vmovaps [rsp], xmm0
00007dd8c99db296  vmovaps [rsp+0x10], xmm1
00007dd8c99db29c  vmovaps [rsp+0x20], xmm2
00007dd8c99db2a2  vmovaps [rsp+0x30], xmm3
00007dd8c99db2a8  vmovaps [rsp+0x40], xmm4
00007dd8c99db2ae  vmovaps [rsp+0x50], xmm5
00007dd8c99db2b4  vmovaps [rsp+0x60], xmm6
00007dd8c99db2ba  vmovaps [rsp+0x70], xmm7
00007dd8c99db2c0  vmovaps [rsp+0x80], xmm8
00007dd8c99db2c9  vmovaps [rsp+0x90], xmm10
00007dd8c99db2d2  vmovaps [rsp+0xA0], xmm11
00007dd8c99db2db  vmovaps [rsp+0xB0], xmm12
00007dd8c99db2e4  vmovaps [rsp+0xC0], xmm13
00007dd8c99db2ed  vmovaps [rsp+0xD0], xmm14
00007dd8c99db2f6  vmovaps [rsp+0xE0], xmm15
00007dd8c99db2ff  sub rsp, 0x30
00007dd8c99db303  movaps [rsp], xmm9
00007dd8c99db308  movaps [rsp+0x10], xmm13
00007dd8c99db30e  movaps [rsp+0x20], xmm15
00007dd8c99db314  lea rdi, [rsp]
00007dd8c99db318  mov esi, 0x00
00007dd8c99db31d  mov rax, 0x55FEBBDB5530
00007dd8c99db327  call rax
00007dd8c99db329  movaps xmm9, [rsp]
00007dd8c99db32e  add rsp, 0x30
00007dd8c99db332  vmovaps xmm0, [rsp]
00007dd8c99db337  vmovaps xmm1, [rsp+0x10]
00007dd8c99db33d  vmovaps xmm2, [rsp+0x20]
00007dd8c99db343  vmovaps xmm3, [rsp+0x30]
00007dd8c99db349  vmovaps xmm4, [rsp+0x40]
00007dd8c99db34f  vmovaps xmm5, [rsp+0x50]
00007dd8c99db355  vmovaps xmm6, [rsp+0x60]
00007dd8c99db35b  vmovaps xmm7, [rsp+0x70]
00007dd8c99db361  vmovaps xmm8, [rsp+0x80]
00007dd8c99db36a  vmovaps xmm10, [rsp+0x90]
00007dd8c99db373  vmovaps xmm11, [rsp+0xA0]
00007dd8c99db37c  vmovaps xmm12, [rsp+0xB0]
00007dd8c99db385  vmovaps xmm13, [rsp+0xC0]
00007dd8c99db38e  vmovaps xmm14, [rsp+0xD0]
00007dd8c99db397  vmovaps xmm15, [rsp+0xE0]
00007dd8c99db3a0  add rsp, 0xF0
00007dd8c99db3a7  pop r11
00007dd8c99db3a9  pop r10
00007dd8c99db3ab  pop r9
00007dd8c99db3ad  pop r8
00007dd8c99db3af  pop rsi
00007dd8c99db3b0  pop rdi
00007dd8c99db3b1  pop rdx
00007dd8c99db3b2  pop rcx
00007dd8c99db3b3  pop rax
00007dd8c99db3b4  add rsp, 0x08
00007dd8c99db3b8  jmp 0x00007DD8C99D662F
00007dd8c99db3bd  sub rsp, 0x08
00007dd8c99db3c1  push rax
00007dd8c99db3c2  push rcx
00007dd8c99db3c3  push rdx
00007dd8c99db3c4  push rdi
00007dd8c99db3c5  push rsi
00007dd8c99db3c6  push r8
00007dd8c99db3c8  push r9
00007dd8c99db3ca  push r10
00007dd8c99db3cc  push r11
00007dd8c99db3ce  sub rsp, 0xF0
00007dd8c99db3d5  vmovaps [rsp], xmm0
00007dd8c99db3da  vmovaps [rsp+0x10], xmm1
00007dd8c99db3e0  vmovaps [rsp+0x20], xmm2
00007dd8c99db3e6  vmovaps [rsp+0x30], xmm3
00007dd8c99db3ec  vmovaps [rsp+0x40], xmm4
00007dd8c99db3f2  vmovaps [rsp+0x50], xmm5
00007dd8c99db3f8  vmovaps [rsp+0x60], xmm6
00007dd8c99db3fe  vmovaps [rsp+0x70], xmm7
00007dd8c99db404  vmovaps [rsp+0x80], xmm8
00007dd8c99db40d  vmovaps [rsp+0x90], xmm9
00007dd8c99db416  vmovaps [rsp+0xA0], xmm10
00007dd8c99db41f  vmovaps [rsp+0xB0], xmm11
00007dd8c99db428  vmovaps [rsp+0xC0], xmm12
00007dd8c99db431  vmovaps [rsp+0xD0], xmm13
00007dd8c99db43a  vmovaps [rsp+0xE0], xmm14
00007dd8c99db443  sub rsp, 0x30
00007dd8c99db447  movaps [rsp], xmm15
00007dd8c99db44c  movaps [rsp+0x10], xmm11
00007dd8c99db452  movaps [rsp+0x20], xmm12
00007dd8c99db458  lea rdi, [rsp]
00007dd8c99db45c  mov esi, 0x00
00007dd8c99db461  mov rax, 0x55FEBBDB5530
00007dd8c99db46b  call rax
00007dd8c99db46d  movaps xmm15, [rsp]
00007dd8c99db472  add rsp, 0x30
00007dd8c99db476  vmovaps xmm0, [rsp]
00007dd8c99db47b  vmovaps xmm1, [rsp+0x10]
00007dd8c99db481  vmovaps xmm2, [rsp+0x20]
00007dd8c99db487  vmovaps xmm3, [rsp+0x30]
00007dd8c99db48d  vmovaps xmm4, [rsp+0x40]
00007dd8c99db493  vmovaps xmm5, [rsp+0x50]
00007dd8c99db499  vmovaps xmm6, [rsp+0x60]
00007dd8c99db49f  vmovaps xmm7, [rsp+0x70]
00007dd8c99db4a5  vmovaps xmm8, [rsp+0x80]
00007dd8c99db4ae  vmovaps xmm9, [rsp+0x90]
00007dd8c99db4b7  vmovaps xmm10, [rsp+0xA0]
00007dd8c99db4c0  vmovaps xmm11, [rsp+0xB0]
00007dd8c99db4c9  vmovaps xmm12, [rsp+0xC0]
00007dd8c99db4d2  vmovaps xmm13, [rsp+0xD0]
00007dd8c99db4db  vmovaps xmm14, [rsp+0xE0]
00007dd8c99db4e4  add rsp, 0xF0
00007dd8c99db4eb  pop r11
00007dd8c99db4ed  pop r10
00007dd8c99db4ef  pop r9
00007dd8c99db4f1  pop r8
00007dd8c99db4f3  pop rsi
00007dd8c99db4f4  pop rdi
00007dd8c99db4f5  pop rdx
00007dd8c99db4f6  pop rcx
00007dd8c99db4f7  pop rax
00007dd8c99db4f8  add rsp, 0x08
00007dd8c99db4fc  jmp 0x00007DD8C99D664A
00007dd8c99db501  sub rsp, 0x08
00007dd8c99db505  push rax
00007dd8c99db506  push rcx
00007dd8c99db507  push rdx
00007dd8c99db508  push rdi
00007dd8c99db509  push rsi
00007dd8c99db50a  push r8
00007dd8c99db50c  push r9
00007dd8c99db50e  push r10
00007dd8c99db510  push r11
00007dd8c99db512  sub rsp, 0xF0
00007dd8c99db519  vmovaps [rsp], xmm0
00007dd8c99db51e  vmovaps [rsp+0x10], xmm1
00007dd8c99db524  vmovaps [rsp+0x20], xmm2
00007dd8c99db52a  vmovaps [rsp+0x30], xmm3
00007dd8c99db530  vmovaps [rsp+0x40], xmm4
00007dd8c99db536  vmovaps [rsp+0x50], xmm5
00007dd8c99db53c  vmovaps [rsp+0x60], xmm6
00007dd8c99db542  vmovaps [rsp+0x70], xmm7
00007dd8c99db548  vmovaps [rsp+0x80], xmm8
00007dd8c99db551  vmovaps [rsp+0x90], xmm9
00007dd8c99db55a  vmovaps [rsp+0xA0], xmm10
00007dd8c99db563  vmovaps [rsp+0xB0], xmm11
00007dd8c99db56c  vmovaps [rsp+0xC0], xmm12
00007dd8c99db575  vmovaps [rsp+0xD0], xmm14
00007dd8c99db57e  vmovaps [rsp+0xE0], xmm15
00007dd8c99db587  sub rsp, 0x30
00007dd8c99db58b  movaps [rsp], xmm13
00007dd8c99db590  movaps [rsp+0x10], xmm10
00007dd8c99db596  movaps [rsp+0x20], xmm14
00007dd8c99db59c  lea rdi, [rsp]
00007dd8c99db5a0  mov esi, 0x00
00007dd8c99db5a5  mov rax, 0x55FEBBDB5530
00007dd8c99db5af  call rax
00007dd8c99db5b1  movaps xmm13, [rsp]
00007dd8c99db5b6  add rsp, 0x30
00007dd8c99db5ba  vmovaps xmm0, [rsp]
00007dd8c99db5bf  vmovaps xmm1, [rsp+0x10]
00007dd8c99db5c5  vmovaps xmm2, [rsp+0x20]
00007dd8c99db5cb  vmovaps xmm3, [rsp+0x30]
00007dd8c99db5d1  vmovaps xmm4, [rsp+0x40]
00007dd8c99db5d7  vmovaps xmm5, [rsp+0x50]
00007dd8c99db5dd  vmovaps xmm6, [rsp+0x60]
00007dd8c99db5e3  vmovaps xmm7, [rsp+0x70]
00007dd8c99db5e9  vmovaps xmm8, [rsp+0x80]
00007dd8c99db5f2  vmovaps xmm9, [rsp+0x90]
00007dd8c99db5fb  vmovaps xmm10, [rsp+0xA0]
00007dd8c99db604  vmovaps xmm11, [rsp+0xB0]
00007dd8c99db60d  vmovaps xmm12, [rsp+0xC0]
00007dd8c99db616  vmovaps xmm14, [rsp+0xD0]
00007dd8c99db61f  vmovaps xmm15, [rsp+0xE0]
00007dd8c99db628  add rsp, 0xF0
00007dd8c99db62f  pop r11
00007dd8c99db631  pop r10
00007dd8c99db633  pop r9
00007dd8c99db635  pop r8
00007dd8c99db637  pop rsi
00007dd8c99db638  pop rdi
00007dd8c99db639  pop rdx
00007dd8c99db63a  pop rcx
00007dd8c99db63b  pop rax
00007dd8c99db63c  add rsp, 0x08
00007dd8c99db640  jmp 0x00007DD8C99D666D
00007dd8c99db645  sub rsp, 0x08
00007dd8c99db649  push rax
00007dd8c99db64a  push rcx
00007dd8c99db64b  push rdx
00007dd8c99db64c  push rdi
00007dd8c99db64d  push rsi
00007dd8c99db64e  push r8
00007dd8c99db650  push r9
00007dd8c99db652  push r10
00007dd8c99db654  push r11
00007dd8c99db656  sub rsp, 0xF0
00007dd8c99db65d  vmovaps [rsp], xmm0
00007dd8c99db662  vmovaps [rsp+0x10], xmm1
00007dd8c99db668  vmovaps [rsp+0x20], xmm2
00007dd8c99db66e  vmovaps [rsp+0x30], xmm3
00007dd8c99db674  vmovaps [rsp+0x40], xmm4
00007dd8c99db67a  vmovaps [rsp+0x50], xmm5
00007dd8c99db680  vmovaps [rsp+0x60], xmm6
00007dd8c99db686  vmovaps [rsp+0x70], xmm7
00007dd8c99db68c  vmovaps [rsp+0x80], xmm8
00007dd8c99db695  vmovaps [rsp+0x90], xmm9
00007dd8c99db69e  vmovaps [rsp+0xA0], xmm10
00007dd8c99db6a7  vmovaps [rsp+0xB0], xmm11
00007dd8c99db6b0  vmovaps [rsp+0xC0], xmm12
00007dd8c99db6b9  vmovaps [rsp+0xD0], xmm13
00007dd8c99db6c2  vmovaps [rsp+0xE0], xmm15
00007dd8c99db6cb  sub rsp, 0x30
00007dd8c99db6cf  movaps [rsp], xmm14
00007dd8c99db6d4  movaps [rsp+0x10], xmm1
00007dd8c99db6d9  movaps [rsp+0x20], xmm7
00007dd8c99db6de  lea rdi, [rsp]
00007dd8c99db6e2  mov esi, 0x00
00007dd8c99db6e7  mov rax, 0x55FEBBDB5530
00007dd8c99db6f1  call rax
00007dd8c99db6f3  movaps xmm14, [rsp]
00007dd8c99db6f8  add rsp, 0x30
00007dd8c99db6fc  vmovaps xmm0, [rsp]
00007dd8c99db701  vmovaps xmm1, [rsp+0x10]
00007dd8c99db707  vmovaps xmm2, [rsp+0x20]
00007dd8c99db70d  vmovaps xmm3, [rsp+0x30]
00007dd8c99db713  vmovaps xmm4, [rsp+0x40]
00007dd8c99db719  vmovaps xmm5, [rsp+0x50]
00007dd8c99db71f  vmovaps xmm6, [rsp+0x60]
00007dd8c99db725  vmovaps xmm7, [rsp+0x70]
00007dd8c99db72b  vmovaps xmm8, [rsp+0x80]
00007dd8c99db734  vmovaps xmm9, [rsp+0x90]
00007dd8c99db73d  vmovaps xmm10, [rsp+0xA0]
00007dd8c99db746  vmovaps xmm11, [rsp+0xB0]
00007dd8c99db74f  vmovaps xmm12, [rsp+0xC0]
00007dd8c99db758  vmovaps xmm13, [rsp+0xD0]
00007dd8c99db761  vmovaps xmm15, [rsp+0xE0]
00007dd8c99db76a  add rsp, 0xF0
00007dd8c99db771  pop r11
00007dd8c99db773  pop r10
00007dd8c99db775  pop r9
00007dd8c99db777  pop r8
00007dd8c99db779  pop rsi
00007dd8c99db77a  pop rdi
00007dd8c99db77b  pop rdx
00007dd8c99db77c  pop rcx
00007dd8c99db77d  pop rax
00007dd8c99db77e  add rsp, 0x08
00007dd8c99db782  jmp 0x00007DD8C99D6690
00007dd8c99db787  sub rsp, 0x08
00007dd8c99db78b  push rax
00007dd8c99db78c  push rcx
00007dd8c99db78d  push rdx
00007dd8c99db78e  push rdi
00007dd8c99db78f  push rsi
00007dd8c99db790  push r8
00007dd8c99db792  push r9
00007dd8c99db794  push r10
00007dd8c99db796  push r11
00007dd8c99db798  sub rsp, 0xF0
00007dd8c99db79f  vmovaps [rsp], xmm0
00007dd8c99db7a4  vmovaps [rsp+0x10], xmm2
00007dd8c99db7aa  vmovaps [rsp+0x20], xmm3
00007dd8c99db7b0  vmovaps [rsp+0x30], xmm4
00007dd8c99db7b6  vmovaps [rsp+0x40], xmm5
00007dd8c99db7bc  vmovaps [rsp+0x50], xmm6
00007dd8c99db7c2  vmovaps [rsp+0x60], xmm7
00007dd8c99db7c8  vmovaps [rsp+0x70], xmm8
00007dd8c99db7ce  vmovaps [rsp+0x80], xmm9
00007dd8c99db7d7  vmovaps [rsp+0x90], xmm10
00007dd8c99db7e0  vmovaps [rsp+0xA0], xmm11
00007dd8c99db7e9  vmovaps [rsp+0xB0], xmm12
00007dd8c99db7f2  vmovaps [rsp+0xC0], xmm13
00007dd8c99db7fb  vmovaps [rsp+0xD0], xmm14
00007dd8c99db804  vmovaps [rsp+0xE0], xmm15
00007dd8c99db80d  sub rsp, 0x30
00007dd8c99db811  movaps [rsp], xmm1
00007dd8c99db815  movaps [rsp+0x10], xmm8
00007dd8c99db81b  movaps [rsp+0x20], xmm9
00007dd8c99db821  lea rdi, [rsp]
00007dd8c99db825  mov esi, 0x00
00007dd8c99db82a  mov rax, 0x55FEBBDB5530
00007dd8c99db834  call rax
00007dd8c99db836  movaps xmm1, [rsp]
00007dd8c99db83a  add rsp, 0x30
00007dd8c99db83e  vmovaps xmm0, [rsp]
00007dd8c99db843  vmovaps xmm2, [rsp+0x10]
00007dd8c99db849  vmovaps xmm3, [rsp+0x20]
00007dd8c99db84f  vmovaps xmm4, [rsp+0x30]
00007dd8c99db855  vmovaps xmm5, [rsp+0x40]
00007dd8c99db85b  vmovaps xmm6, [rsp+0x50]
00007dd8c99db861  vmovaps xmm7, [rsp+0x60]
00007dd8c99db867  vmovaps xmm8, [rsp+0x70]
00007dd8c99db86d  vmovaps xmm9, [rsp+0x80]
00007dd8c99db876  vmovaps xmm10, [rsp+0x90]
00007dd8c99db87f  vmovaps xmm11, [rsp+0xA0]
00007dd8c99db888  vmovaps xmm12, [rsp+0xB0]
00007dd8c99db891  vmovaps xmm13, [rsp+0xC0]
00007dd8c99db89a  vmovaps xmm14, [rsp+0xD0]
00007dd8c99db8a3  vmovaps xmm15, [rsp+0xE0]
00007dd8c99db8ac  add rsp, 0xF0
00007dd8c99db8b3  pop r11
00007dd8c99db8b5  pop r10
00007dd8c99db8b7  pop r9
00007dd8c99db8b9  pop r8
00007dd8c99db8bb  pop rsi
00007dd8c99db8bc  pop rdi
00007dd8c99db8bd  pop rdx
00007dd8c99db8be  pop rcx
00007dd8c99db8bf  pop rax
00007dd8c99db8c0  add rsp, 0x08
00007dd8c99db8c4  jmp 0x00007DD8C99D66B2
00007dd8c99db8c9  call 0x00007DD8C98B3E40
00007dd8c99db8ce  jmp 0x00007DD8C99D66C0
00007dd8c99db8d3  call 0x00007DD8C980C380
00007dd8c99db8d8  jmp 0x00007DD8C99D66CA
00007dd8c99db8dd  call 0x00007DD8C980D600
00007dd8c99db8e2  jmp 0x00007DD8C99D66D4
00007dd8c99db8e7  call 0x00007DD8C97FF540
00007dd8c99db8ec  jmp 0x00007DD8C99D66DE
00007dd8c99db8f1  int3
00007dd8c99db8f2  nop [rax+rax*1], ax
00007dd8c99db8fb  nop [rax+rax*1], eax
00007dd8c99db900  mov eax, [r15+0x48]
00007dd8c99db904  lea r14d, [eax+0x01]
00007dd8c99db909  mov [rsp+0x10], r14d
00007dd8c99db90e  mov r14d, r14d
00007dd8c99db911  mov [r15+0x48], r14
00007dd8c99db915  xor eax, eax
00007dd8c99db917  mov r14d, [rsp+0x10]
00007dd8c99db91c  cmp r14d, 0x1F4
00007dd8c99db923  cmc
00007dd8c99db924  lahf
00007dd8c99db925  seto al
00007dd8c99db928  mov [r15+0x108], eax
00007dd8c99db92f  mov eax, [r15+0x108]
00007dd8c99db936  sahf
00007dd8c99db937  jnz 0x00007DD8C99DB969
00007dd8c99db939  cmp dword ptr [r15+0x318], 0x00
00007dd8c99db941  jz 0x00007DD8C99E1AB0
00007dd8c99db947  nop [rax+rax*1], ax
00007dd8c99db950  nop [rax+rax*1], eax
00007dd8c99db958  mov eax, 0x410450
00007dd8c99db95d  mov [r15+0x100], rax
00007dd8c99db964  jmp 0x00007DD8C97FE110
00007dd8c99db969  cmp dword ptr [r15+0x318], 0x00
00007dd8c99db971  jz 0x00007DD8C99DB9A0
00007dd8c99db977  nop [rax+rax*1], ax
00007dd8c99db980  nop [rax+rax*1], eax
00007dd8c99db988  mov eax, 0x410274
00007dd8c99db98d  mov [r15+0x100], rax
00007dd8c99db994  jmp 0x00007DD8C97FE110
00007dd8c99db999  int3
00007dd8c99db99a  int3
00007dd8c99db99b  nop [rax+rax*1], eax
00007dd8c99db9a0  mov rax, [r15+0x40]
00007dd8c99db9a4  movaps xmm1, [r15+0x1D0]
00007dd8c99db9ac  vmovaps [rsp+0x10], xmm1
00007dd8c99db9b2  vmovaps xmm15, [rsp+0x10]
00007dd8c99db9b8  por xmm1, xmm15
00007dd8c99db9bd  movaps xmm14, [r15+0x1A0]
00007dd8c99db9c5  vmovaps [rsp+0x10], xmm14
00007dd8c99db9cb  vmovaps xmm13, [rsp+0x10]
00007dd8c99db9d1  por xmm14, xmm13
00007dd8c99db9d6  lea r14, [rax+0x30]
00007dd8c99db9da  mov r12, [r13+r14*1]
00007dd8c99db9df  lea r14, [rax+0x38]
00007dd8c99db9e3  mov r11, [r13+r14*1]
00007dd8c99db9e8  movq xmm13, r12
00007dd8c99db9ed  movq xmm12, r11
00007dd8c99db9f2  movq xmm13, xmm13
00007dd8c99db9f7  vmovaps [rsp+0x10], xmm13
00007dd8c99db9fd  movq xmm13, xmm13
00007dd8c99dba02  movaps [r15+0x130], xmm13
00007dd8c99dba0a  movq xmm12, xmm12
00007dd8c99dba0f  vmovaps [rsp+0x20], xmm12
00007dd8c99dba15  movq xmm12, xmm12
00007dd8c99dba1a  movaps [r15+0x280], xmm12
00007dd8c99dba22  movaps xmm13, [r15+0x270]
00007dd8c99dba2a  vmovaps [rsp+0x30], xmm13
00007dd8c99dba30  vmovaps xmm12, [rsp+0x30]
00007dd8c99dba36  por xmm13, xmm12
00007dd8c99dba3b  lea r14, [rax+0x20]
00007dd8c99dba3f  mov r12, [r13+r14*1]
00007dd8c99dba44  lea r14, [rax+0x28]
00007dd8c99dba48  mov r11, [r13+r14*1]
00007dd8c99dba4d  movq xmm12, r12
00007dd8c99dba52  movq xmm11, r11
00007dd8c99dba57  movq xmm12, xmm12
00007dd8c99dba5c  vmovaps [rsp+0x30], xmm12
00007dd8c99dba62  movq xmm12, xmm12
00007dd8c99dba67  movaps [r15+0x150], xmm12
00007dd8c99dba6f  movq xmm11, xmm11
00007dd8c99dba74  vmovaps [rsp+0x40], xmm11
00007dd8c99dba7a  movq xmm11, xmm11
00007dd8c99dba7f  movaps [r15+0x140], xmm11
00007dd8c99dba87  lea r14, [rax+0x10]
00007dd8c99dba8b  mov r12, [r13+r14*1]
00007dd8c99dba90  lea r14, [rax+0x18]
00007dd8c99dba94  mov r11, [r13+r14*1]
00007dd8c99dba99  movq xmm12, r12
00007dd8c99dba9e  movq xmm11, r11
00007dd8c99dbaa3  movq xmm12, xmm12
00007dd8c99dbaa8  vmovaps [rsp+0x50], xmm12
00007dd8c99dbaae  movq xmm12, xmm12
00007dd8c99dbab3  movaps [r15+0x170], xmm12
00007dd8c99dbabb  movq xmm11, xmm11
00007dd8c99dbac0  vmovaps [rsp+0x60], xmm11
00007dd8c99dbac6  movq xmm11, xmm11
00007dd8c99dbacb  movaps [r15+0x160], xmm11
00007dd8c99dbad3  mov r14, [r13+rax*1]
00007dd8c99dbad8  vmovq xmm12, r14
00007dd8c99dbadd  vpbroadcastq xmm12, xmm12
00007dd8c99dbae2  lea r14, [rax+0x08]
00007dd8c99dbae6  mov rax, [r13+r14*1]
00007dd8c99dbaeb  movq xmm11, rax
00007dd8c99dbaf0  movaps [r15+0x230], xmm11
00007dd8c99dbaf8  mov rax, [r15+0xF8]
00007dd8c99dbaff  lea r14, [rax+0x50]
00007dd8c99dbb03  movups xmm11, [r13+r14*1]
00007dd8c99dbb09  lea r14, [rax+0x60]
00007dd8c99dbb0d  movups xmm10, [r13+r14*1]
00007dd8c99dbb13  lea r14, [rax+0x30]
00007dd8c99dbb17  movups xmm9, [r13+r14*1]
00007dd8c99dbb1d  mov r14, [r15+0x50]
00007dd8c99dbb21  mov [r15+0x60], r14
00007dd8c99dbb25  mov qword ptr [r15+0x58], 0x40
00007dd8c99dbb2d  movaps xmm8, xmm12
00007dd8c99dbb31  mulpd xmm8, xmm15
00007dd8c99dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd8c99dbb3c  ptest xmm7, xmm7
00007dd8c99dbb41  jnz 0x00007DD8C99DC96A
00007dd8c99dbb47  movq xmm15, qword ptr [r15+0x230]
00007dd8c99dbb50  vmovaps [rsp+0x70], xmm15
00007dd8c99dbb56  vpermilpd xmm15, xmm15, 0x00
00007dd8c99dbb5c  movaps xmm7, xmm9
00007dd8c99dbb60  mulpd xmm7, xmm15
00007dd8c99dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8c99dbb6a  ptest xmm6, xmm6
00007dd8c99dbb6f  jnz 0x00007DD8C99DCAAE
00007dd8c99dbb75  vxorps xmm15, xmm15, xmm15
00007dd8c99dbb7a  vpbroadcastq xmm15, xmm15
00007dd8c99dbb7f  movaps xmm9, xmm12
00007dd8c99dbb83  mulpd xmm9, xmm10
00007dd8c99dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd8c99dbb8e  ptest xmm6, xmm6
00007dd8c99dbb93  jnz 0x00007DD8C99DCBF0
00007dd8c99dbb99  movaps xmm10, xmm12
00007dd8c99dbb9d  mulpd xmm10, xmm11
00007dd8c99dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007dd8c99dbba8  ptest xmm6, xmm6
00007dd8c99dbbad  jnz 0x00007DD8C99DCD34
00007dd8c99dbbb3  movaps xmm11, [r15+0x1F0]
00007dd8c99dbbbb  movaps xmm6, xmm12
00007dd8c99dbbbf  mulpd xmm6, xmm11
00007dd8c99dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd8c99dbbc9  ptest xmm5, xmm5
00007dd8c99dbbce  jnz 0x00007DD8C99DCE78
00007dd8c99dbbd4  movaps xmm12, [r15+0x2A0]
00007dd8c99dbbdc  vmovaps [rsp+0x80], xmm12
00007dd8c99dbbe5  vmovaps xmm11, [rsp+0x80]
00007dd8c99dbbee  por xmm12, xmm11
00007dd8c99dbbf3  movaps xmm11, [r15+0x250]
00007dd8c99dbbfb  vmovaps [rsp+0x80], xmm11
00007dd8c99dbc04  vmovaps xmm5, [rsp+0x80]
00007dd8c99dbc0d  por xmm11, xmm5
00007dd8c99dbc12  vmovaps xmm4, [rsp+0x70]
00007dd8c99dbc18  vpermilpd xmm4, xmm4, 0x00
00007dd8c99dbc1e  movaps xmm3, xmm5
00007dd8c99dbc21  mulpd xmm3, xmm4
00007dd8c99dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007dd8c99dbc2a  ptest xmm2, xmm2
00007dd8c99dbc2f  jnz 0x00007DD8C99DCFBA
00007dd8c99dbc35  mov [rsp+0x80], rax
00007dd8c99dbc3d  xor eax, eax
00007dd8c99dbc3f  mov r12d, 0x40
00007dd8c99dbc45  mov r11d, 0x200
00007dd8c99dbc4b  cmp r12, r11
00007dd8c99dbc4e  cmc
00007dd8c99dbc4f  lahf
00007dd8c99dbc50  seto al
00007dd8c99dbc53  mov [r15+0x108], eax
00007dd8c99dbc5a  movaps xmm5, xmm8
00007dd8c99dbc5e  addpd xmm5, xmm15
00007dd8c99dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007dd8c99dbc68  ptest xmm4, xmm4
00007dd8c99dbc6d  jnz 0x00007DD8C99DD0FA
00007dd8c99dbc73  movaps xmm8, [r15+0x1B0]
00007dd8c99dbc7b  movaps xmm4, xmm9
00007dd8c99dbc7f  addpd xmm4, xmm8
00007dd8c99dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007dd8c99dbc89  ptest xmm2, xmm2
00007dd8c99dbc8e  jnz 0x00007DD8C99DD23C
00007dd8c99dbc94  movaps xmm9, xmm10
00007dd8c99dbc98  addpd xmm9, xmm8
00007dd8c99dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007dd8c99dbca3  ptest xmm2, xmm2
00007dd8c99dbca8  jnz 0x00007DD8C99DD37E
00007dd8c99dbcae  movaps xmm10, [r15+0x2F0]
00007dd8c99dbcb6  vmovaps [rsp+0x90], xmm10
00007dd8c99dbcbf  vmovaps xmm8, [rsp+0x90]
00007dd8c99dbcc8  por xmm10, xmm8
00007dd8c99dbccd  movaps xmm8, [r15+0x2E0]
00007dd8c99dbcd5  vmovaps [rsp+0x90], xmm8
00007dd8c99dbcde  vmovaps xmm2, [rsp+0x90]
00007dd8c99dbce7  por xmm8, xmm2
00007dd8c99dbcec  movaps xmm2, [r15+0x2D0]
00007dd8c99dbcf4  vmovaps [rsp+0x90], xmm2
00007dd8c99dbcfd  vmovaps [rsp+0xA0], xmm1
00007dd8c99dbd06  vmovaps xmm1, [rsp+0x90]
00007dd8c99dbd0f  por xmm2, xmm1
00007dd8c99dbd13  movaps xmm1, [r15+0x200]
00007dd8c99dbd1b  vmovaps [rsp+0x90], xmm1
00007dd8c99dbd24  vmovaps [rsp+0xB0], xmm15
00007dd8c99dbd2d  vmovaps xmm15, [rsp+0x90]
00007dd8c99dbd36  por xmm1, xmm15
00007dd8c99dbd3b  movaps xmm15, [r15+0x1C0]
00007dd8c99dbd43  vmovaps [rsp+0x90], xmm15
00007dd8c99dbd4c  vmovaps [rsp+0xC0], xmm1
00007dd8c99dbd55  vmovaps xmm1, [rsp+0x90]
00007dd8c99dbd5e  por xmm15, xmm1
00007dd8c99dbd63  movaps xmm1, [r15+0x190]
00007dd8c99dbd6b  vmovaps [rsp+0x90], xmm1
00007dd8c99dbd74  vmovaps [rsp+0xD0], xmm15
00007dd8c99dbd7d  vmovaps xmm15, [rsp+0x90]
00007dd8c99dbd86  por xmm1, xmm15
00007dd8c99dbd8b  movaps xmm15, [r15+0x300]
00007dd8c99dbd93  vmovaps [rsp+0x90], xmm15
00007dd8c99dbd9c  vmovaps [rsp+0xE0], xmm1
00007dd8c99dbda5  vmovaps xmm1, [rsp+0x90]
00007dd8c99dbdae  por xmm15, xmm1
00007dd8c99dbdb3  mov rax, [rsp+0x80]
00007dd8c99dbdbb  lea r12, [rax+0xA0]
00007dd8c99dbdc2  movups xmm1, [r13+r12*1]
00007dd8c99dbdc8  lea r12, [rax+0xB0]
00007dd8c99dbdcf  vmovaps [rsp+0x80], xmm1
00007dd8c99dbdd8  movups xmm1, [r13+r12*1]
00007dd8c99dbdde  vmovaps [rsp+0x90], xmm1
00007dd8c99dbde7  vmovaps [rsp+0xF0], xmm15
00007dd8c99dbdf0  vmovaps xmm15, [rsp+0xB0]
00007dd8c99dbdf9  vmovaps [rsp+0xB0], xmm14
00007dd8c99dbe02  movaps xmm1, xmm6
00007dd8c99dbe05  addpd xmm1, xmm15
00007dd8c99dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd8c99dbe0f  ptest xmm14, xmm14
00007dd8c99dbe15  jnz 0x00007DD8C99DD4D6
00007dd8c99dbe1b  lea r12, [rax+0xF0]
00007dd8c99dbe22  movups xmm15, [r13+r12*1]
00007dd8c99dbe28  movaps xmm14, xmm4
00007dd8c99dbe2c  addpd xmm14, xmm3
00007dd8c99dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007dd8c99dbe37  ptest xmm6, xmm6
00007dd8c99dbe3c  jnz 0x00007DD8C99DD621
00007dd8c99dbe42  movaps xmm6, xmm9
00007dd8c99dbe46  addpd xmm6, xmm7
00007dd8c99dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007dd8c99dbe4f  ptest xmm4, xmm4
00007dd8c99dbe54  jnz 0x00007DD8C99DD763
00007dd8c99dbe5a  vmovaps xmm9, [rsp+0x70]
00007dd8c99dbe60  vpermilpd xmm9, xmm9, 0x00
00007dd8c99dbe66  vmovaps xmm4, [rsp+0x90]
00007dd8c99dbe6f  movaps xmm7, xmm4
00007dd8c99dbe72  mulpd xmm7, xmm9
00007dd8c99dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007dd8c99dbe7c  ptest xmm3, xmm3
00007dd8c99dbe81  jnz 0x00007DD8C99DD8A4
00007dd8c99dbe87  vmovaps xmm9, [rsp+0x50]
00007dd8c99dbe8d  vpermilpd xmm9, xmm9, 0x00
00007dd8c99dbe93  movaps xmm4, xmm15
00007dd8c99dbe97  mulpd xmm4, xmm9
00007dd8c99dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007dd8c99dbea1  ptest xmm3, xmm3
00007dd8c99dbea6  jnz 0x00007DD8C99DD9E5
00007dd8c99dbeac  lea r12, [rax+0xE0]
00007dd8c99dbeb3  movups xmm15, [r13+r12*1]
00007dd8c99dbeb9  vmovaps xmm9, [rsp+0x70]
00007dd8c99dbebf  vpermilpd xmm9, xmm9, 0x00
00007dd8c99dbec5  vmovaps [rsp+0x70], xmm1
00007dd8c99dbecb  vmovaps xmm1, [rsp+0x80]
00007dd8c99dbed4  vmovaps [rsp+0x80], xmm15
00007dd8c99dbedd  movaps xmm3, xmm1
00007dd8c99dbee0  mulpd xmm3, xmm9
00007dd8c99dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007dd8c99dbeea  ptest xmm15, xmm15
00007dd8c99dbef0  jnz 0x00007DD8C99DDB31
00007dd8c99dbef6  vmovaps xmm1, [rsp+0xF0]
00007dd8c99dbeff  vmovaps xmm15, [rsp+0xF0]
00007dd8c99dbf08  por xmm1, xmm15
00007dd8c99dbf0d  movaps [r15+0x300], xmm1
00007dd8c99dbf15  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dbf1e  vmovaps xmm9, [rsp+0xE0]
00007dd8c99dbf27  por xmm15, xmm9
00007dd8c99dbf2c  movaps [r15+0x190], xmm15
00007dd8c99dbf34  vmovaps xmm9, [rsp+0x50]
00007dd8c99dbf3a  vpermilpd xmm9, xmm9, 0x00
00007dd8c99dbf40  vmovaps [rsp+0x90], xmm1
00007dd8c99dbf49  vmovaps [rsp+0xE0], xmm15
00007dd8c99dbf52  vmovaps xmm15, [rsp+0x80]
00007dd8c99dbf5b  vmovaps [rsp+0x80], xmm14
00007dd8c99dbf64  movaps xmm1, xmm15
00007dd8c99dbf68  mulpd xmm1, xmm9
00007dd8c99dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd8c99dbf72  ptest xmm14, xmm14
00007dd8c99dbf78  jnz 0x00007DD8C99DDC72
00007dd8c99dbf7e  lea r12, [rax+0x90]
00007dd8c99dbf85  movups xmm15, [r13+r12*1]
00007dd8c99dbf8b  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dbf94  vmovaps xmm9, [rsp+0xD0]
00007dd8c99dbf9d  por xmm14, xmm9
00007dd8c99dbfa2  movaps [r15+0x1C0], xmm14
00007dd8c99dbfaa  vmovaps xmm9, [rsp+0xC0]
00007dd8c99dbfb3  vmovaps [rsp+0xD0], xmm1
00007dd8c99dbfbc  vmovaps xmm1, [rsp+0xC0]
00007dd8c99dbfc5  por xmm9, xmm1
00007dd8c99dbfca  movaps [r15+0x200], xmm9
00007dd8c99dbfd2  vmovaps [rsp+0xC0], xmm2
00007dd8c99dbfdb  vmovaps xmm1, [rsp+0xC0]
00007dd8c99dbfe4  por xmm2, xmm1
00007dd8c99dbfe8  movaps [r15+0x2D0], xmm2
00007dd8c99dbff0  vmovaps [rsp+0xC0], xmm8
00007dd8c99dbff9  vmovaps xmm1, [rsp+0xC0]
00007dd8c99dc002  por xmm8, xmm1
00007dd8c99dc007  movaps [r15+0x2E0], xmm8
00007dd8c99dc00f  vmovaps [rsp+0xC0], xmm15
00007dd8c99dc018  movaps xmm1, xmm5
00007dd8c99dc01b  addpd xmm1, xmm7
00007dd8c99dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd8c99dc024  ptest xmm15, xmm15
00007dd8c99dc02a  jnz 0x00007DD8C99DDDBE
00007dd8c99dc030  vmovaps xmm15, [rsp+0x50]
00007dd8c99dc036  vpermilpd xmm15, xmm15, 0x00
00007dd8c99dc03c  vmovaps xmm5, [rsp+0xC0]
00007dd8c99dc045  vmovaps [rsp+0xC0], xmm1
00007dd8c99dc04e  movaps xmm7, xmm5
00007dd8c99dc051  mulpd xmm7, xmm15
00007dd8c99dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007dd8c99dc05b  ptest xmm1, xmm1
00007dd8c99dc060  jnz 0x00007DD8C99DDEFE
00007dd8c99dc066  lea r12, [rax+0x80]
00007dd8c99dc06d  movups xmm1, [r13+r12*1]
00007dd8c99dc073  vmovaps xmm5, [rsp+0x70]
00007dd8c99dc079  vmovaps [rsp+0x70], xmm1
00007dd8c99dc07f  movaps xmm15, xmm5
00007dd8c99dc083  addpd xmm15, xmm3
00007dd8c99dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8c99dc08e  ptest xmm1, xmm1
00007dd8c99dc093  jnz 0x00007DD8C99DE049
00007dd8c99dc099  vmovaps xmm5, [rsp+0x80]
00007dd8c99dc0a2  movaps xmm1, xmm5
00007dd8c99dc0a5  addpd xmm1, xmm4
00007dd8c99dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007dd8c99dc0ae  ptest xmm3, xmm3
00007dd8c99dc0b3  jnz 0x00007DD8C99DE18B
00007dd8c99dc0b9  vmovaps [rsp+0x80], xmm10
00007dd8c99dc0c2  vmovaps xmm5, [rsp+0x80]
00007dd8c99dc0cb  por xmm10, xmm5
00007dd8c99dc0d0  movaps [r15+0x2F0], xmm10
00007dd8c99dc0d8  vmovaps xmm5, [rsp+0x50]
00007dd8c99dc0de  vpermilpd xmm5, xmm5, 0x00
00007dd8c99dc0e4  vmovaps xmm3, [rsp+0x70]
00007dd8c99dc0ea  vmovaps [rsp+0x50], xmm1
00007dd8c99dc0f0  movaps xmm4, xmm3
00007dd8c99dc0f3  mulpd xmm4, xmm5
00007dd8c99dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007dd8c99dc0fc  ptest xmm1, xmm1
00007dd8c99dc101  jnz 0x00007DD8C99DE2CB
00007dd8c99dc107  lea r12, [rax+0xD0]
00007dd8c99dc10e  movups xmm1, [r13+r12*1]
00007dd8c99dc114  vmovaps xmm3, [rsp+0xD0]
00007dd8c99dc11d  vmovaps [rsp+0x70], xmm1
00007dd8c99dc123  movaps xmm5, xmm6
00007dd8c99dc126  addpd xmm5, xmm3
00007dd8c99dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007dd8c99dc12f  ptest xmm1, xmm1
00007dd8c99dc134  jnz 0x00007DD8C99DE415
00007dd8c99dc13a  vmovaps xmm1, [rsp+0x60]
00007dd8c99dc140  vpermilpd xmm1, xmm1, 0x00
00007dd8c99dc146  movaps xmm6, xmm9
00007dd8c99dc14a  mulpd xmm6, xmm1
00007dd8c99dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007dd8c99dc153  ptest xmm3, xmm3
00007dd8c99dc158  jnz 0x00007DD8C99DE555
00007dd8c99dc15e  movaps [r15+0x260], xmm6
00007dd8c99dc166  vxorps xmm1, xmm1, xmm1
00007dd8c99dc16a  vpbroadcastq xmm1, xmm1
00007dd8c99dc16f  movaps [r15+0x1B0], xmm1
00007dd8c99dc177  vmovaps xmm1, [rsp+0x60]
00007dd8c99dc17d  vpermilpd xmm1, xmm1, 0x00
00007dd8c99dc183  vmovaps xmm3, [rsp+0x70]
00007dd8c99dc189  vmovaps [rsp+0x70], xmm15
00007dd8c99dc18f  movaps xmm9, xmm3
00007dd8c99dc193  mulpd xmm9, xmm1
00007dd8c99dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007dd8c99dc19e  ptest xmm15, xmm15
00007dd8c99dc1a4  jnz 0x00007DD8C99DE696
00007dd8c99dc1aa  lea r12, [rax+0xC0]
00007dd8c99dc1b1  movups xmm1, [r13+r12*1]
00007dd8c99dc1b7  vmovaps xmm3, [rsp+0xC0]
00007dd8c99dc1c0  vmovaps [rsp+0x80], xmm1
00007dd8c99dc1c9  movaps xmm15, xmm3
00007dd8c99dc1cd  addpd xmm15, xmm7
00007dd8c99dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8c99dc1d8  ptest xmm1, xmm1
00007dd8c99dc1dd  jnz 0x00007DD8C99DE7E2
00007dd8c99dc1e3  vmovaps [rsp+0xC0], xmm13
00007dd8c99dc1ec  vmovaps xmm1, [rsp+0xC0]
00007dd8c99dc1f5  por xmm13, xmm1
00007dd8c99dc1fa  movaps [r15+0x270], xmm13
00007dd8c99dc202  vmovaps xmm1, [rsp+0xB0]
00007dd8c99dc20b  vmovaps xmm7, [rsp+0xB0]
00007dd8c99dc214  por xmm1, xmm7
00007dd8c99dc218  movaps [r15+0x1A0], xmm1
00007dd8c99dc220  vmovaps xmm1, [rsp+0x60]
00007dd8c99dc226  vpermilpd xmm1, xmm1, 0x00
00007dd8c99dc22c  vmovaps [rsp+0xB0], xmm1
00007dd8c99dc235  vmovaps xmm1, [rsp+0x80]
00007dd8c99dc23e  vmovaps [rsp+0x80], xmm15
00007dd8c99dc247  vmovaps xmm15, [rsp+0xB0]
00007dd8c99dc250  vmovaps [rsp+0xB0], xmm14
00007dd8c99dc259  movaps xmm3, xmm1
00007dd8c99dc25c  mulpd xmm3, xmm15
00007dd8c99dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007dd8c99dc266  ptest xmm14, xmm14
00007dd8c99dc26c  jnz 0x00007DD8C99DE924
00007dd8c99dc272  lea r12, [rax+0x20]
00007dd8c99dc276  movups xmm1, [r13+r12*1]
00007dd8c99dc27c  movaps [r15+0x110], xmm1
00007dd8c99dc284  vmovaps xmm14, [rsp+0x70]
00007dd8c99dc28a  vmovaps [rsp+0x70], xmm1
00007dd8c99dc290  movaps xmm15, xmm14
00007dd8c99dc294  addpd xmm15, xmm4
00007dd8c99dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8c99dc29f  ptest xmm1, xmm1
00007dd8c99dc2a4  jnz 0x00007DD8C99DEA6F
00007dd8c99dc2aa  vmovaps xmm1, [rsp+0x60]
00007dd8c99dc2b0  vpermilpd xmm1, xmm1, 0x00
00007dd8c99dc2b6  movaps xmm14, xmm2
00007dd8c99dc2ba  mulpd xmm14, xmm1
00007dd8c99dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007dd8c99dc2c5  ptest xmm4, xmm4
00007dd8c99dc2ca  jnz 0x00007DD8C99DEBB2
00007dd8c99dc2d0  vmovaps xmm4, [rsp+0x50]
00007dd8c99dc2d6  movaps xmm1, xmm4
00007dd8c99dc2d9  addpd xmm1, xmm9
00007dd8c99dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd8c99dc2e3  ptest xmm2, xmm2
00007dd8c99dc2e8  jnz 0x00007DD8C99DECF4
00007dd8c99dc2ee  vmovaps xmm9, [rsp+0x30]
00007dd8c99dc2f4  vpermilpd xmm9, xmm9, 0x00
00007dd8c99dc2fa  vmovaps xmm2, [rsp+0x70]
00007dd8c99dc300  vmovaps [rsp+0x50], xmm1
00007dd8c99dc306  movaps xmm4, xmm2
00007dd8c99dc309  mulpd xmm4, xmm9
00007dd8c99dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007dd8c99dc313  ptest xmm1, xmm1
00007dd8c99dc318  jnz 0x00007DD8C99DEE35
00007dd8c99dc31e  vmovaps xmm1, [rsp+0x30]
00007dd8c99dc324  vpermilpd xmm1, xmm1, 0x00
00007dd8c99dc32a  vmovaps xmm2, [rsp+0x90]
00007dd8c99dc333  vmovaps [rsp+0x60], xmm15
00007dd8c99dc339  movaps xmm9, xmm2
00007dd8c99dc33d  mulpd xmm9, xmm1
00007dd8c99dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007dd8c99dc348  ptest xmm15, xmm15
00007dd8c99dc34e  jnz 0x00007DD8C99DEF76
00007dd8c99dc354  vmovaps xmm15, [rsp+0x80]
00007dd8c99dc35d  movaps xmm1, xmm15
00007dd8c99dc361  addpd xmm1, xmm6
00007dd8c99dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd8c99dc36a  ptest xmm2, xmm2
00007dd8c99dc36f  jnz 0x00007DD8C99DF0B8
00007dd8c99dc375  movaps xmm15, xmm5
00007dd8c99dc379  addpd xmm15, xmm3
00007dd8c99dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007dd8c99dc384  ptest xmm6, xmm6
00007dd8c99dc389  jnz 0x00007DD8C99DF1F9
00007dd8c99dc38f  vmovaps xmm6, [rsp+0x30]
00007dd8c99dc395  vpermilpd xmm6, xmm6, 0x00
00007dd8c99dc39b  movaps xmm5, xmm8
00007dd8c99dc39f  mulpd xmm5, xmm6
00007dd8c99dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007dd8c99dc3a8  ptest xmm3, xmm3
00007dd8c99dc3ad  jnz 0x00007DD8C99DF33B
00007dd8c99dc3b3  vmovaps xmm8, [rsp+0x30]
00007dd8c99dc3b9  vpermilpd xmm8, xmm8, 0x00
00007dd8c99dc3bf  movaps xmm6, xmm10
00007dd8c99dc3c3  mulpd xmm6, xmm8
00007dd8c99dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007dd8c99dc3cd  ptest xmm3, xmm3
00007dd8c99dc3d2  jnz 0x00007DD8C99DF47C
00007dd8c99dc3d8  vmovaps xmm8, [rsp+0x60]
00007dd8c99dc3de  movaps xmm10, xmm8
00007dd8c99dc3e2  addpd xmm10, xmm14
00007dd8c99dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007dd8c99dc3ed  ptest xmm3, xmm3
00007dd8c99dc3f2  jnz 0x00007DD8C99DF5BE
00007dd8c99dc3f8  vmovaps xmm8, [rsp+0x50]
00007dd8c99dc3fe  movaps xmm14, xmm8
00007dd8c99dc402  addpd xmm14, xmm4
00007dd8c99dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007dd8c99dc40d  ptest xmm3, xmm3
00007dd8c99dc412  jnz 0x00007DD8C99DF702
00007dd8c99dc418  vmovaps xmm8, [rsp+0x40]
00007dd8c99dc41e  vpermilpd xmm8, xmm8, 0x00
00007dd8c99dc424  movaps xmm4, xmm13
00007dd8c99dc428  mulpd xmm4, xmm8
00007dd8c99dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007dd8c99dc432  ptest xmm3, xmm3
00007dd8c99dc437  jnz 0x00007DD8C99DF845
00007dd8c99dc43d  movaps xmm13, xmm15
00007dd8c99dc441  addpd xmm13, xmm9
00007dd8c99dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007dd8c99dc44c  ptest xmm8, xmm8
00007dd8c99dc452  jnz 0x00007DD8C99DF987
00007dd8c99dc458  movaps xmm15, xmm1
00007dd8c99dc45c  addpd xmm15, xmm5
00007dd8c99dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007dd8c99dc467  ptest xmm9, xmm9
00007dd8c99dc46d  jnz 0x00007DD8C99DFACB
00007dd8c99dc473  vmovaps [rsp+0x30], xmm11
00007dd8c99dc479  vmovaps xmm1, [rsp+0x30]
00007dd8c99dc47f  por xmm11, xmm1
00007dd8c99dc484  movaps [r15+0x250], xmm11
00007dd8c99dc48c  vmovaps [rsp+0x30], xmm12
00007dd8c99dc492  vmovaps xmm1, [rsp+0x30]
00007dd8c99dc498  por xmm12, xmm1
00007dd8c99dc49d  movaps [r15+0x2A0], xmm12
00007dd8c99dc4a5  vmovaps xmm1, [rsp+0xA0]
00007dd8c99dc4ae  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dc4b7  por xmm1, xmm11
00007dd8c99dc4bc  movaps [r15+0x1D0], xmm1
00007dd8c99dc4c4  lea r12, [rax+0x40]
00007dd8c99dc4c8  movups xmm1, [r13+r12*1]
00007dd8c99dc4ce  movaps [r15+0x2C0], xmm1
00007dd8c99dc4d6  vmovaps xmm11, [rsp+0x40]
00007dd8c99dc4dc  vpermilpd xmm11, xmm11, 0x00
00007dd8c99dc4e2  vmovaps xmm8, [rsp+0xE0]
00007dd8c99dc4eb  movaps xmm9, xmm8
00007dd8c99dc4ef  mulpd xmm9, xmm11
00007dd8c99dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007dd8c99dc4fa  ptest xmm5, xmm5
00007dd8c99dc4ff  jnz 0x00007DD8C99DFC17
00007dd8c99dc505  movaps xmm11, xmm10
00007dd8c99dc509  addpd xmm11, xmm6
00007dd8c99dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007dd8c99dc514  ptest xmm8, xmm8
00007dd8c99dc51a  jnz 0x00007DD8C99DFD5B
00007dd8c99dc520  movaps xmm10, xmm14
00007dd8c99dc524  addpd xmm10, xmm4
00007dd8c99dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007dd8c99dc52f  ptest xmm8, xmm8
00007dd8c99dc535  jnz 0x00007DD8C99DFE9E
00007dd8c99dc53b  vmovaps xmm14, [rsp+0x40]
00007dd8c99dc541  vpermilpd xmm14, xmm14, 0x00
00007dd8c99dc547  movaps xmm8, xmm1
00007dd8c99dc54b  mulpd xmm8, xmm14
00007dd8c99dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd8c99dc556  ptest xmm6, xmm6
00007dd8c99dc55b  jnz 0x00007DD8C99DFFE1
00007dd8c99dc561  movaps xmm1, [r15+0x2B0]
00007dd8c99dc569  vmovaps xmm14, [rsp+0x40]
00007dd8c99dc56f  vpermilpd xmm14, xmm14, 0x00
00007dd8c99dc575  movaps xmm6, xmm1
00007dd8c99dc578  mulpd xmm6, xmm14
00007dd8c99dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd8c99dc582  ptest xmm5, xmm5
00007dd8c99dc587  jnz 0x00007DD8C99E0124
00007dd8c99dc58d  vmovaps xmm1, [rsp+0x10]
00007dd8c99dc593  vpermilpd xmm1, xmm1, 0x00
00007dd8c99dc599  movaps xmm14, xmm12
00007dd8c99dc59d  mulpd xmm14, xmm1
00007dd8c99dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007dd8c99dc5a8  ptest xmm5, xmm5
00007dd8c99dc5ad  jnz 0x00007DD8C99E0265
00007dd8c99dc5b3  movaps xmm1, xmm13
00007dd8c99dc5b7  addpd xmm1, xmm9
00007dd8c99dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd8c99dc5c1  ptest xmm12, xmm12
00007dd8c99dc5c7  jnz 0x00007DD8C99E03A8
00007dd8c99dc5cd  vmovaps xmm13, [rsp+0x10]
00007dd8c99dc5d3  vpermilpd xmm13, xmm13, 0x00
00007dd8c99dc5d9  movaps xmm12, xmm7
00007dd8c99dc5dd  mulpd xmm12, xmm13
00007dd8c99dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007dd8c99dc5e8  ptest xmm9, xmm9
00007dd8c99dc5ee  jnz 0x00007DD8C99E04EA
00007dd8c99dc5f4  movaps xmm13, xmm15
00007dd8c99dc5f8  addpd xmm13, xmm8
00007dd8c99dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007dd8c99dc603  ptest xmm9, xmm9
00007dd8c99dc609  jnz 0x00007DD8C99E062D
00007dd8c99dc60f  movaps xmm15, [r15+0x290]
00007dd8c99dc617  vmovaps xmm9, [rsp+0x10]
00007dd8c99dc61d  vpermilpd xmm9, xmm9, 0x00
00007dd8c99dc623  movaps xmm8, xmm15
00007dd8c99dc627  mulpd xmm8, xmm9
00007dd8c99dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd8c99dc632  ptest xmm7, xmm7
00007dd8c99dc637  jnz 0x00007DD8C99E0771
00007dd8c99dc63d  movaps xmm15, xmm11
00007dd8c99dc641  addpd xmm15, xmm6
00007dd8c99dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007dd8c99dc64c  ptest xmm9, xmm9
00007dd8c99dc652  jnz 0x00007DD8C99E08B5
00007dd8c99dc658  movaps xmm11, [r15+0x1E0]
00007dd8c99dc660  vmovaps xmm9, [rsp+0x10]
00007dd8c99dc666  vpermilpd xmm9, xmm9, 0x00
00007dd8c99dc66c  movaps xmm7, xmm11
00007dd8c99dc670  mulpd xmm7, xmm9
00007dd8c99dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8c99dc67a  ptest xmm6, xmm6
00007dd8c99dc67f  jnz 0x00007DD8C99E09F8
00007dd8c99dc685  movaps xmm11, xmm10
00007dd8c99dc689  addpd xmm11, xmm14
00007dd8c99dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007dd8c99dc694  ptest xmm9, xmm9
00007dd8c99dc69a  jnz 0x00007DD8C99E0B3A
00007dd8c99dc6a0  lea r12, [rax+0x70]
00007dd8c99dc6a4  movups xmm14, [r13+r12*1]
00007dd8c99dc6aa  movaps [r15+0x240], xmm14
00007dd8c99dc6b2  movaps xmm10, xmm1
00007dd8c99dc6b6  addpd xmm10, xmm12
00007dd8c99dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007dd8c99dc6c1  ptest xmm9, xmm9
00007dd8c99dc6c7  jnz 0x00007DD8C99E0C88
00007dd8c99dc6cd  movaps [r15+0x170], xmm10
00007dd8c99dc6d5  vmovaps xmm1, [rsp+0x20]
00007dd8c99dc6db  vpermilpd xmm1, xmm1, 0x00
00007dd8c99dc6e1  movaps xmm12, xmm14
00007dd8c99dc6e5  mulpd xmm12, xmm1
00007dd8c99dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007dd8c99dc6f0  ptest xmm9, xmm9
00007dd8c99dc6f6  jnz 0x00007DD8C99E0DCB
00007dd8c99dc6fc  vmovaps xmm1, [rsp+0x20]
00007dd8c99dc702  vpermilpd xmm1, xmm1, 0x00
00007dd8c99dc708  vmovaps xmm9, [rsp+0xB0]
00007dd8c99dc711  movaps xmm14, xmm9
00007dd8c99dc715  mulpd xmm14, xmm1
00007dd8c99dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007dd8c99dc720  ptest xmm6, xmm6
00007dd8c99dc725  jnz 0x00007DD8C99E0F0E
00007dd8c99dc72b  movaps [r15+0x180], xmm14
00007dd8c99dc733  movaps xmm1, xmm13
00007dd8c99dc737  addpd xmm1, xmm8
00007dd8c99dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007dd8c99dc741  ptest xmm9, xmm9
00007dd8c99dc747  jnz 0x00007DD8C99E1051
00007dd8c99dc74d  movaps [r15+0x210], xmm1
00007dd8c99dc755  movups xmm13, [r13+rax*1]
00007dd8c99dc75b  lea r12, [rax+0x10]
00007dd8c99dc75f  movups xmm9, [r13+r12*1]
00007dd8c99dc765  movaps [r15+0x230], xmm9
00007dd8c99dc76d  movaps xmm8, xmm15
00007dd8c99dc771  addpd xmm8, xmm7
00007dd8c99dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd8c99dc77c  ptest xmm6, xmm6
00007dd8c99dc781  jnz 0x00007DD8C99E11A7
00007dd8c99dc787  movaps [r15+0x130], xmm8
00007dd8c99dc78f  vmovaps xmm15, [rsp+0x20]
00007dd8c99dc795  vpermilpd xmm15, xmm15, 0x00
00007dd8c99dc79b  movaps xmm7, xmm9
00007dd8c99dc79f  mulpd xmm7, xmm15
00007dd8c99dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8c99dc7a9  ptest xmm6, xmm6
00007dd8c99dc7ae  jnz 0x00007DD8C99E12EA
00007dd8c99dc7b4  movaps [r15+0x220], xmm7
00007dd8c99dc7bc  vmovaps xmm15, [rsp+0x20]
00007dd8c99dc7c2  vpermilpd xmm15, xmm15, 0x00
00007dd8c99dc7c8  movaps xmm9, xmm13
00007dd8c99dc7cc  mulpd xmm9, xmm15
00007dd8c99dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd8c99dc7d7  ptest xmm6, xmm6
00007dd8c99dc7dc  jnz 0x00007DD8C99E142C
00007dd8c99dc7e2  movaps xmm15, xmm11
00007dd8c99dc7e6  addpd xmm15, xmm12
00007dd8c99dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007dd8c99dc7f1  ptest xmm13, xmm13
00007dd8c99dc7f7  jnz 0x00007DD8C99E1570
00007dd8c99dc7fd  movaps [r15+0x140], xmm15
00007dd8c99dc805  movaps xmm13, xmm10
00007dd8c99dc809  addpd xmm13, xmm14
00007dd8c99dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007dd8c99dc814  ptest xmm12, xmm12
00007dd8c99dc81a  jnz 0x00007DD8C99E16B4
00007dd8c99dc820  movaps [r15+0x150], xmm13
00007dd8c99dc828  movaps xmm14, xmm1
00007dd8c99dc82c  addpd xmm14, xmm7
00007dd8c99dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007dd8c99dc837  ptest xmm12, xmm12
00007dd8c99dc83d  jnz 0x00007DD8C99E17F8
00007dd8c99dc843  movaps [r15+0x160], xmm14
00007dd8c99dc84b  movaps xmm1, xmm8
00007dd8c99dc84f  addpd xmm1, xmm9
00007dd8c99dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd8c99dc859  ptest xmm12, xmm12
00007dd8c99dc85f  jnz 0x00007DD8C99E193A
00007dd8c99dc865  movaps [r15+0x120], xmm1
00007dd8c99dc86d  movups [r13+r14*1], xmm15
00007dd8c99dc873  lea rax, [r14+0x10]
00007dd8c99dc877  movups [r13+rax*1], xmm13
00007dd8c99dc87d  lea rax, [r14+0x20]
00007dd8c99dc881  movups [r13+rax*1], xmm14
00007dd8c99dc887  lea rax, [r14+0x30]
00007dd8c99dc88b  movups [r13+rax*1], xmm1
00007dd8c99dc891  mov eax, [r15+0x108]
00007dd8c99dc898  sahf
00007dd8c99dc899  jnz 0x00007DD8C99DC8CB
00007dd8c99dc89b  cmp dword ptr [r15+0x318], 0x00
00007dd8c99dc8a3  jz 0x00007DD8C99DB900
00007dd8c99dc8a9  nop [rax+rax*1], ax
00007dd8c99dc8b2  nop [rax+rax*1], eax
00007dd8c99dc8ba  mov eax, 0x410444
00007dd8c99dc8bf  mov [r15+0x100], rax
00007dd8c99dc8c6  jmp 0x00007DD8C97FE110
00007dd8c99dc8cb  cmp dword ptr [r15+0x318], 0x00
00007dd8c99dc8d3  jz 0x00007DD8C99D57E0
00007dd8c99dc8d9  nop [rax+rax*1], ax
00007dd8c99dc8e2  nop [rax+rax*1], eax
00007dd8c99dc8ea  mov eax, 0x410278
00007dd8c99dc8ef  mov [r15+0x100], rax
00007dd8c99dc8f6  jmp 0x00007DD8C97FE110
00007dd8c99dc8fb  int3
00007dd8c99dc8fc  call 0x00007DD8C98E27E0
00007dd8c99dc901  jmp 0x00007DD8C99DB9DF
00007dd8c99dc906  call 0x00007DD8C98E1570
00007dd8c99dc90b  jmp 0x00007DD8C99DB9E8
00007dd8c99dc910  call 0x00007DD8C98E27E0
00007dd8c99dc915  jmp 0x00007DD8C99DBA44
00007dd8c99dc91a  call 0x00007DD8C98E1570
00007dd8c99dc91f  jmp 0x00007DD8C99DBA4D
00007dd8c99dc924  call 0x00007DD8C98E27E0
00007dd8c99dc929  jmp 0x00007DD8C99DBA90
00007dd8c99dc92e  call 0x00007DD8C98E1570
00007dd8c99dc933  jmp 0x00007DD8C99DBA99
00007dd8c99dc938  call 0x00007DD8C980DC20
00007dd8c99dc93d  jmp 0x00007DD8C99DBAD8
00007dd8c99dc942  call 0x00007DD8C98D59C0
00007dd8c99dc947  jmp 0x00007DD8C99DBAEB
00007dd8c99dc94c  call 0x00007DD8C98E0E30
00007dd8c99dc951  jmp 0x00007DD8C99DBB09
00007dd8c99dc956  call 0x00007DD8C98DFBC0
00007dd8c99dc95b  jmp 0x00007DD8C99DBB13
00007dd8c99dc960  call 0x00007DD8C98DE950
00007dd8c99dc965  jmp 0x00007DD8C99DBB1D
00007dd8c99dc96a  sub rsp, 0x08
00007dd8c99dc96e  push rax
00007dd8c99dc96f  push rcx
00007dd8c99dc970  push rdx
00007dd8c99dc971  push rdi
00007dd8c99dc972  push rsi
00007dd8c99dc973  push r8
00007dd8c99dc975  push r9
00007dd8c99dc977  push r10
00007dd8c99dc979  push r11
00007dd8c99dc97b  sub rsp, 0xF0
00007dd8c99dc982  vmovaps [rsp], xmm0
00007dd8c99dc987  vmovaps [rsp+0x10], xmm1
00007dd8c99dc98d  vmovaps [rsp+0x20], xmm2
00007dd8c99dc993  vmovaps [rsp+0x30], xmm3
00007dd8c99dc999  vmovaps [rsp+0x40], xmm4
00007dd8c99dc99f  vmovaps [rsp+0x50], xmm5
00007dd8c99dc9a5  vmovaps [rsp+0x60], xmm6
00007dd8c99dc9ab  vmovaps [rsp+0x70], xmm7
00007dd8c99dc9b1  vmovaps [rsp+0x80], xmm9
00007dd8c99dc9ba  vmovaps [rsp+0x90], xmm10
00007dd8c99dc9c3  vmovaps [rsp+0xA0], xmm11
00007dd8c99dc9cc  vmovaps [rsp+0xB0], xmm12
00007dd8c99dc9d5  vmovaps [rsp+0xC0], xmm13
00007dd8c99dc9de  vmovaps [rsp+0xD0], xmm14
00007dd8c99dc9e7  vmovaps [rsp+0xE0], xmm15
00007dd8c99dc9f0  sub rsp, 0x30
00007dd8c99dc9f4  movaps [rsp], xmm8
00007dd8c99dc9f9  movaps [rsp+0x10], xmm12
00007dd8c99dc9ff  movaps [rsp+0x20], xmm15
00007dd8c99dca05  lea rdi, [rsp]
00007dd8c99dca09  mov esi, 0x00
00007dd8c99dca0e  mov rax, 0x55FEBBDB5530
00007dd8c99dca18  call rax
00007dd8c99dca1a  movaps xmm8, [rsp]
00007dd8c99dca1f  add rsp, 0x30
00007dd8c99dca23  vmovaps xmm0, [rsp]
00007dd8c99dca28  vmovaps xmm1, [rsp+0x10]
00007dd8c99dca2e  vmovaps xmm2, [rsp+0x20]
00007dd8c99dca34  vmovaps xmm3, [rsp+0x30]
00007dd8c99dca3a  vmovaps xmm4, [rsp+0x40]
00007dd8c99dca40  vmovaps xmm5, [rsp+0x50]
00007dd8c99dca46  vmovaps xmm6, [rsp+0x60]
00007dd8c99dca4c  vmovaps xmm7, [rsp+0x70]
00007dd8c99dca52  vmovaps xmm9, [rsp+0x80]
00007dd8c99dca5b  vmovaps xmm10, [rsp+0x90]
00007dd8c99dca64  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dca6d  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dca76  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dca7f  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dca88  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dca91  add rsp, 0xF0
00007dd8c99dca98  pop r11
00007dd8c99dca9a  pop r10
00007dd8c99dca9c  pop r9
00007dd8c99dca9e  pop r8
00007dd8c99dcaa0  pop rsi
00007dd8c99dcaa1  pop rdi
00007dd8c99dcaa2  pop rdx
00007dd8c99dcaa3  pop rcx
00007dd8c99dcaa4  pop rax
00007dd8c99dcaa5  add rsp, 0x08
00007dd8c99dcaa9  jmp 0x00007DD8C99DBB47
00007dd8c99dcaae  sub rsp, 0x08
00007dd8c99dcab2  push rax
00007dd8c99dcab3  push rcx
00007dd8c99dcab4  push rdx
00007dd8c99dcab5  push rdi
00007dd8c99dcab6  push rsi
00007dd8c99dcab7  push r8
00007dd8c99dcab9  push r9
00007dd8c99dcabb  push r10
00007dd8c99dcabd  push r11
00007dd8c99dcabf  sub rsp, 0xF0
00007dd8c99dcac6  vmovaps [rsp], xmm0
00007dd8c99dcacb  vmovaps [rsp+0x10], xmm1
00007dd8c99dcad1  vmovaps [rsp+0x20], xmm2
00007dd8c99dcad7  vmovaps [rsp+0x30], xmm3
00007dd8c99dcadd  vmovaps [rsp+0x40], xmm4
00007dd8c99dcae3  vmovaps [rsp+0x50], xmm5
00007dd8c99dcae9  vmovaps [rsp+0x60], xmm6
00007dd8c99dcaef  vmovaps [rsp+0x70], xmm8
00007dd8c99dcaf5  vmovaps [rsp+0x80], xmm9
00007dd8c99dcafe  vmovaps [rsp+0x90], xmm10
00007dd8c99dcb07  vmovaps [rsp+0xA0], xmm11
00007dd8c99dcb10  vmovaps [rsp+0xB0], xmm12
00007dd8c99dcb19  vmovaps [rsp+0xC0], xmm13
00007dd8c99dcb22  vmovaps [rsp+0xD0], xmm14
00007dd8c99dcb2b  vmovaps [rsp+0xE0], xmm15
00007dd8c99dcb34  sub rsp, 0x30
00007dd8c99dcb38  movaps [rsp], xmm7
00007dd8c99dcb3c  movaps [rsp+0x10], xmm9
00007dd8c99dcb42  movaps [rsp+0x20], xmm15
00007dd8c99dcb48  lea rdi, [rsp]
00007dd8c99dcb4c  mov esi, 0x00
00007dd8c99dcb51  mov rax, 0x55FEBBDB5530
00007dd8c99dcb5b  call rax
00007dd8c99dcb5d  movaps xmm7, [rsp]
00007dd8c99dcb61  add rsp, 0x30
00007dd8c99dcb65  vmovaps xmm0, [rsp]
00007dd8c99dcb6a  vmovaps xmm1, [rsp+0x10]
00007dd8c99dcb70  vmovaps xmm2, [rsp+0x20]
00007dd8c99dcb76  vmovaps xmm3, [rsp+0x30]
00007dd8c99dcb7c  vmovaps xmm4, [rsp+0x40]
00007dd8c99dcb82  vmovaps xmm5, [rsp+0x50]
00007dd8c99dcb88  vmovaps xmm6, [rsp+0x60]
00007dd8c99dcb8e  vmovaps xmm8, [rsp+0x70]
00007dd8c99dcb94  vmovaps xmm9, [rsp+0x80]
00007dd8c99dcb9d  vmovaps xmm10, [rsp+0x90]
00007dd8c99dcba6  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dcbaf  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dcbb8  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dcbc1  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dcbca  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dcbd3  add rsp, 0xF0
00007dd8c99dcbda  pop r11
00007dd8c99dcbdc  pop r10
00007dd8c99dcbde  pop r9
00007dd8c99dcbe0  pop r8
00007dd8c99dcbe2  pop rsi
00007dd8c99dcbe3  pop rdi
00007dd8c99dcbe4  pop rdx
00007dd8c99dcbe5  pop rcx
00007dd8c99dcbe6  pop rax
00007dd8c99dcbe7  add rsp, 0x08
00007dd8c99dcbeb  jmp 0x00007DD8C99DBB75
00007dd8c99dcbf0  sub rsp, 0x08
00007dd8c99dcbf4  push rax
00007dd8c99dcbf5  push rcx
00007dd8c99dcbf6  push rdx
00007dd8c99dcbf7  push rdi
00007dd8c99dcbf8  push rsi
00007dd8c99dcbf9  push r8
00007dd8c99dcbfb  push r9
00007dd8c99dcbfd  push r10
00007dd8c99dcbff  push r11
00007dd8c99dcc01  sub rsp, 0xF0
00007dd8c99dcc08  vmovaps [rsp], xmm0
00007dd8c99dcc0d  vmovaps [rsp+0x10], xmm1
00007dd8c99dcc13  vmovaps [rsp+0x20], xmm2
00007dd8c99dcc19  vmovaps [rsp+0x30], xmm3
00007dd8c99dcc1f  vmovaps [rsp+0x40], xmm4
00007dd8c99dcc25  vmovaps [rsp+0x50], xmm5
00007dd8c99dcc2b  vmovaps [rsp+0x60], xmm6
00007dd8c99dcc31  vmovaps [rsp+0x70], xmm7
00007dd8c99dcc37  vmovaps [rsp+0x80], xmm8
00007dd8c99dcc40  vmovaps [rsp+0x90], xmm10
00007dd8c99dcc49  vmovaps [rsp+0xA0], xmm11
00007dd8c99dcc52  vmovaps [rsp+0xB0], xmm12
00007dd8c99dcc5b  vmovaps [rsp+0xC0], xmm13
00007dd8c99dcc64  vmovaps [rsp+0xD0], xmm14
00007dd8c99dcc6d  vmovaps [rsp+0xE0], xmm15
00007dd8c99dcc76  sub rsp, 0x30
00007dd8c99dcc7a  movaps [rsp], xmm9
00007dd8c99dcc7f  movaps [rsp+0x10], xmm12
00007dd8c99dcc85  movaps [rsp+0x20], xmm10
00007dd8c99dcc8b  lea rdi, [rsp]
00007dd8c99dcc8f  mov esi, 0x00
00007dd8c99dcc94  mov rax, 0x55FEBBDB5530
00007dd8c99dcc9e  call rax
00007dd8c99dcca0  movaps xmm9, [rsp]
00007dd8c99dcca5  add rsp, 0x30
00007dd8c99dcca9  vmovaps xmm0, [rsp]
00007dd8c99dccae  vmovaps xmm1, [rsp+0x10]
00007dd8c99dccb4  vmovaps xmm2, [rsp+0x20]
00007dd8c99dccba  vmovaps xmm3, [rsp+0x30]
00007dd8c99dccc0  vmovaps xmm4, [rsp+0x40]
00007dd8c99dccc6  vmovaps xmm5, [rsp+0x50]
00007dd8c99dcccc  vmovaps xmm6, [rsp+0x60]
00007dd8c99dccd2  vmovaps xmm7, [rsp+0x70]
00007dd8c99dccd8  vmovaps xmm8, [rsp+0x80]
00007dd8c99dcce1  vmovaps xmm10, [rsp+0x90]
00007dd8c99dccea  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dccf3  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dccfc  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dcd05  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dcd0e  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dcd17  add rsp, 0xF0
00007dd8c99dcd1e  pop r11
00007dd8c99dcd20  pop r10
00007dd8c99dcd22  pop r9
00007dd8c99dcd24  pop r8
00007dd8c99dcd26  pop rsi
00007dd8c99dcd27  pop rdi
00007dd8c99dcd28  pop rdx
00007dd8c99dcd29  pop rcx
00007dd8c99dcd2a  pop rax
00007dd8c99dcd2b  add rsp, 0x08
00007dd8c99dcd2f  jmp 0x00007DD8C99DBB99
00007dd8c99dcd34  sub rsp, 0x08
00007dd8c99dcd38  push rax
00007dd8c99dcd39  push rcx
00007dd8c99dcd3a  push rdx
00007dd8c99dcd3b  push rdi
00007dd8c99dcd3c  push rsi
00007dd8c99dcd3d  push r8
00007dd8c99dcd3f  push r9
00007dd8c99dcd41  push r10
00007dd8c99dcd43  push r11
00007dd8c99dcd45  sub rsp, 0xF0
00007dd8c99dcd4c  vmovaps [rsp], xmm0
00007dd8c99dcd51  vmovaps [rsp+0x10], xmm1
00007dd8c99dcd57  vmovaps [rsp+0x20], xmm2
00007dd8c99dcd5d  vmovaps [rsp+0x30], xmm3
00007dd8c99dcd63  vmovaps [rsp+0x40], xmm4
00007dd8c99dcd69  vmovaps [rsp+0x50], xmm5
00007dd8c99dcd6f  vmovaps [rsp+0x60], xmm6
00007dd8c99dcd75  vmovaps [rsp+0x70], xmm7
00007dd8c99dcd7b  vmovaps [rsp+0x80], xmm8
00007dd8c99dcd84  vmovaps [rsp+0x90], xmm9
00007dd8c99dcd8d  vmovaps [rsp+0xA0], xmm11
00007dd8c99dcd96  vmovaps [rsp+0xB0], xmm12
00007dd8c99dcd9f  vmovaps [rsp+0xC0], xmm13
00007dd8c99dcda8  vmovaps [rsp+0xD0], xmm14
00007dd8c99dcdb1  vmovaps [rsp+0xE0], xmm15
00007dd8c99dcdba  sub rsp, 0x30
00007dd8c99dcdbe  movaps [rsp], xmm10
00007dd8c99dcdc3  movaps [rsp+0x10], xmm12
00007dd8c99dcdc9  movaps [rsp+0x20], xmm11
00007dd8c99dcdcf  lea rdi, [rsp]
00007dd8c99dcdd3  mov esi, 0x00
00007dd8c99dcdd8  mov rax, 0x55FEBBDB5530
00007dd8c99dcde2  call rax
00007dd8c99dcde4  movaps xmm10, [rsp]
00007dd8c99dcde9  add rsp, 0x30
00007dd8c99dcded  vmovaps xmm0, [rsp]
00007dd8c99dcdf2  vmovaps xmm1, [rsp+0x10]
00007dd8c99dcdf8  vmovaps xmm2, [rsp+0x20]
00007dd8c99dcdfe  vmovaps xmm3, [rsp+0x30]
00007dd8c99dce04  vmovaps xmm4, [rsp+0x40]
00007dd8c99dce0a  vmovaps xmm5, [rsp+0x50]
00007dd8c99dce10  vmovaps xmm6, [rsp+0x60]
00007dd8c99dce16  vmovaps xmm7, [rsp+0x70]
00007dd8c99dce1c  vmovaps xmm8, [rsp+0x80]
00007dd8c99dce25  vmovaps xmm9, [rsp+0x90]
00007dd8c99dce2e  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dce37  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dce40  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dce49  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dce52  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dce5b  add rsp, 0xF0
00007dd8c99dce62  pop r11
00007dd8c99dce64  pop r10
00007dd8c99dce66  pop r9
00007dd8c99dce68  pop r8
00007dd8c99dce6a  pop rsi
00007dd8c99dce6b  pop rdi
00007dd8c99dce6c  pop rdx
00007dd8c99dce6d  pop rcx
00007dd8c99dce6e  pop rax
00007dd8c99dce6f  add rsp, 0x08
00007dd8c99dce73  jmp 0x00007DD8C99DBBB3
00007dd8c99dce78  sub rsp, 0x08
00007dd8c99dce7c  push rax
00007dd8c99dce7d  push rcx
00007dd8c99dce7e  push rdx
00007dd8c99dce7f  push rdi
00007dd8c99dce80  push rsi
00007dd8c99dce81  push r8
00007dd8c99dce83  push r9
00007dd8c99dce85  push r10
00007dd8c99dce87  push r11
00007dd8c99dce89  sub rsp, 0xF0
00007dd8c99dce90  vmovaps [rsp], xmm0
00007dd8c99dce95  vmovaps [rsp+0x10], xmm1
00007dd8c99dce9b  vmovaps [rsp+0x20], xmm2
00007dd8c99dcea1  vmovaps [rsp+0x30], xmm3
00007dd8c99dcea7  vmovaps [rsp+0x40], xmm4
00007dd8c99dcead  vmovaps [rsp+0x50], xmm5
00007dd8c99dceb3  vmovaps [rsp+0x60], xmm7
00007dd8c99dceb9  vmovaps [rsp+0x70], xmm8
00007dd8c99dcebf  vmovaps [rsp+0x80], xmm9
00007dd8c99dcec8  vmovaps [rsp+0x90], xmm10
00007dd8c99dced1  vmovaps [rsp+0xA0], xmm11
00007dd8c99dceda  vmovaps [rsp+0xB0], xmm12
00007dd8c99dcee3  vmovaps [rsp+0xC0], xmm13
00007dd8c99dceec  vmovaps [rsp+0xD0], xmm14
00007dd8c99dcef5  vmovaps [rsp+0xE0], xmm15
00007dd8c99dcefe  sub rsp, 0x30
00007dd8c99dcf02  movaps [rsp], xmm6
00007dd8c99dcf06  movaps [rsp+0x10], xmm12
00007dd8c99dcf0c  movaps [rsp+0x20], xmm11
00007dd8c99dcf12  lea rdi, [rsp]
00007dd8c99dcf16  mov esi, 0x00
00007dd8c99dcf1b  mov rax, 0x55FEBBDB5530
00007dd8c99dcf25  call rax
00007dd8c99dcf27  movaps xmm6, [rsp]
00007dd8c99dcf2b  add rsp, 0x30
00007dd8c99dcf2f  vmovaps xmm0, [rsp]
00007dd8c99dcf34  vmovaps xmm1, [rsp+0x10]
00007dd8c99dcf3a  vmovaps xmm2, [rsp+0x20]
00007dd8c99dcf40  vmovaps xmm3, [rsp+0x30]
00007dd8c99dcf46  vmovaps xmm4, [rsp+0x40]
00007dd8c99dcf4c  vmovaps xmm5, [rsp+0x50]
00007dd8c99dcf52  vmovaps xmm7, [rsp+0x60]
00007dd8c99dcf58  vmovaps xmm8, [rsp+0x70]
00007dd8c99dcf5e  vmovaps xmm9, [rsp+0x80]
00007dd8c99dcf67  vmovaps xmm10, [rsp+0x90]
00007dd8c99dcf70  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dcf79  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dcf82  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dcf8b  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dcf94  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dcf9d  add rsp, 0xF0
00007dd8c99dcfa4  pop r11
00007dd8c99dcfa6  pop r10
00007dd8c99dcfa8  pop r9
00007dd8c99dcfaa  pop r8
00007dd8c99dcfac  pop rsi
00007dd8c99dcfad  pop rdi
00007dd8c99dcfae  pop rdx
00007dd8c99dcfaf  pop rcx
00007dd8c99dcfb0  pop rax
00007dd8c99dcfb1  add rsp, 0x08
00007dd8c99dcfb5  jmp 0x00007DD8C99DBBD4
00007dd8c99dcfba  sub rsp, 0x08
00007dd8c99dcfbe  push rax
00007dd8c99dcfbf  push rcx
00007dd8c99dcfc0  push rdx
00007dd8c99dcfc1  push rdi
00007dd8c99dcfc2  push rsi
00007dd8c99dcfc3  push r8
00007dd8c99dcfc5  push r9
00007dd8c99dcfc7  push r10
00007dd8c99dcfc9  push r11
00007dd8c99dcfcb  sub rsp, 0xF0
00007dd8c99dcfd2  vmovaps [rsp], xmm0
00007dd8c99dcfd7  vmovaps [rsp+0x10], xmm1
00007dd8c99dcfdd  vmovaps [rsp+0x20], xmm2
00007dd8c99dcfe3  vmovaps [rsp+0x30], xmm4
00007dd8c99dcfe9  vmovaps [rsp+0x40], xmm5
00007dd8c99dcfef  vmovaps [rsp+0x50], xmm6
00007dd8c99dcff5  vmovaps [rsp+0x60], xmm7
00007dd8c99dcffb  vmovaps [rsp+0x70], xmm8
00007dd8c99dd001  vmovaps [rsp+0x80], xmm9
00007dd8c99dd00a  vmovaps [rsp+0x90], xmm10
00007dd8c99dd013  vmovaps [rsp+0xA0], xmm11
00007dd8c99dd01c  vmovaps [rsp+0xB0], xmm12
00007dd8c99dd025  vmovaps [rsp+0xC0], xmm13
00007dd8c99dd02e  vmovaps [rsp+0xD0], xmm14
00007dd8c99dd037  vmovaps [rsp+0xE0], xmm15
00007dd8c99dd040  sub rsp, 0x30
00007dd8c99dd044  movaps [rsp], xmm3
00007dd8c99dd048  movaps [rsp+0x10], xmm5
00007dd8c99dd04d  movaps [rsp+0x20], xmm4
00007dd8c99dd052  lea rdi, [rsp]
00007dd8c99dd056  mov esi, 0x00
00007dd8c99dd05b  mov rax, 0x55FEBBDB5530
00007dd8c99dd065  call rax
00007dd8c99dd067  movaps xmm3, [rsp]
00007dd8c99dd06b  add rsp, 0x30
00007dd8c99dd06f  vmovaps xmm0, [rsp]
00007dd8c99dd074  vmovaps xmm1, [rsp+0x10]
00007dd8c99dd07a  vmovaps xmm2, [rsp+0x20]
00007dd8c99dd080  vmovaps xmm4, [rsp+0x30]
00007dd8c99dd086  vmovaps xmm5, [rsp+0x40]
00007dd8c99dd08c  vmovaps xmm6, [rsp+0x50]
00007dd8c99dd092  vmovaps xmm7, [rsp+0x60]
00007dd8c99dd098  vmovaps xmm8, [rsp+0x70]
00007dd8c99dd09e  vmovaps xmm9, [rsp+0x80]
00007dd8c99dd0a7  vmovaps xmm10, [rsp+0x90]
00007dd8c99dd0b0  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dd0b9  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dd0c2  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dd0cb  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dd0d4  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dd0dd  add rsp, 0xF0
00007dd8c99dd0e4  pop r11
00007dd8c99dd0e6  pop r10
00007dd8c99dd0e8  pop r9
00007dd8c99dd0ea  pop r8
00007dd8c99dd0ec  pop rsi
00007dd8c99dd0ed  pop rdi
00007dd8c99dd0ee  pop rdx
00007dd8c99dd0ef  pop rcx
00007dd8c99dd0f0  pop rax
00007dd8c99dd0f1  add rsp, 0x08
00007dd8c99dd0f5  jmp 0x00007DD8C99DBC35
00007dd8c99dd0fa  sub rsp, 0x08
00007dd8c99dd0fe  push rax
00007dd8c99dd0ff  push rcx
00007dd8c99dd100  push rdx
00007dd8c99dd101  push rdi
00007dd8c99dd102  push rsi
00007dd8c99dd103  push r8
00007dd8c99dd105  push r9
00007dd8c99dd107  push r10
00007dd8c99dd109  push r11
00007dd8c99dd10b  sub rsp, 0xF0
00007dd8c99dd112  vmovaps [rsp], xmm0
00007dd8c99dd117  vmovaps [rsp+0x10], xmm1
00007dd8c99dd11d  vmovaps [rsp+0x20], xmm2
00007dd8c99dd123  vmovaps [rsp+0x30], xmm3
00007dd8c99dd129  vmovaps [rsp+0x40], xmm4
00007dd8c99dd12f  vmovaps [rsp+0x50], xmm6
00007dd8c99dd135  vmovaps [rsp+0x60], xmm7
00007dd8c99dd13b  vmovaps [rsp+0x70], xmm8
00007dd8c99dd141  vmovaps [rsp+0x80], xmm9
00007dd8c99dd14a  vmovaps [rsp+0x90], xmm10
00007dd8c99dd153  vmovaps [rsp+0xA0], xmm11
00007dd8c99dd15c  vmovaps [rsp+0xB0], xmm12
00007dd8c99dd165  vmovaps [rsp+0xC0], xmm13
00007dd8c99dd16e  vmovaps [rsp+0xD0], xmm14
00007dd8c99dd177  vmovaps [rsp+0xE0], xmm15
00007dd8c99dd180  sub rsp, 0x30
00007dd8c99dd184  movaps [rsp], xmm5
00007dd8c99dd188  movaps [rsp+0x10], xmm8
00007dd8c99dd18e  movaps [rsp+0x20], xmm15
00007dd8c99dd194  lea rdi, [rsp]
00007dd8c99dd198  mov esi, 0x00
00007dd8c99dd19d  mov rax, 0x55FEBBDB5530
00007dd8c99dd1a7  call rax
00007dd8c99dd1a9  movaps xmm5, [rsp]
00007dd8c99dd1ad  add rsp, 0x30
00007dd8c99dd1b1  vmovaps xmm0, [rsp]
00007dd8c99dd1b6  vmovaps xmm1, [rsp+0x10]
00007dd8c99dd1bc  vmovaps xmm2, [rsp+0x20]
00007dd8c99dd1c2  vmovaps xmm3, [rsp+0x30]
00007dd8c99dd1c8  vmovaps xmm4, [rsp+0x40]
00007dd8c99dd1ce  vmovaps xmm6, [rsp+0x50]
00007dd8c99dd1d4  vmovaps xmm7, [rsp+0x60]
00007dd8c99dd1da  vmovaps xmm8, [rsp+0x70]
00007dd8c99dd1e0  vmovaps xmm9, [rsp+0x80]
00007dd8c99dd1e9  vmovaps xmm10, [rsp+0x90]
00007dd8c99dd1f2  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dd1fb  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dd204  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dd20d  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dd216  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dd21f  add rsp, 0xF0
00007dd8c99dd226  pop r11
00007dd8c99dd228  pop r10
00007dd8c99dd22a  pop r9
00007dd8c99dd22c  pop r8
00007dd8c99dd22e  pop rsi
00007dd8c99dd22f  pop rdi
00007dd8c99dd230  pop rdx
00007dd8c99dd231  pop rcx
00007dd8c99dd232  pop rax
00007dd8c99dd233  add rsp, 0x08
00007dd8c99dd237  jmp 0x00007DD8C99DBC73
00007dd8c99dd23c  sub rsp, 0x08
00007dd8c99dd240  push rax
00007dd8c99dd241  push rcx
00007dd8c99dd242  push rdx
00007dd8c99dd243  push rdi
00007dd8c99dd244  push rsi
00007dd8c99dd245  push r8
00007dd8c99dd247  push r9
00007dd8c99dd249  push r10
00007dd8c99dd24b  push r11
00007dd8c99dd24d  sub rsp, 0xF0
00007dd8c99dd254  vmovaps [rsp], xmm0
00007dd8c99dd259  vmovaps [rsp+0x10], xmm1
00007dd8c99dd25f  vmovaps [rsp+0x20], xmm2
00007dd8c99dd265  vmovaps [rsp+0x30], xmm3
00007dd8c99dd26b  vmovaps [rsp+0x40], xmm5
00007dd8c99dd271  vmovaps [rsp+0x50], xmm6
00007dd8c99dd277  vmovaps [rsp+0x60], xmm7
00007dd8c99dd27d  vmovaps [rsp+0x70], xmm8
00007dd8c99dd283  vmovaps [rsp+0x80], xmm9
00007dd8c99dd28c  vmovaps [rsp+0x90], xmm10
00007dd8c99dd295  vmovaps [rsp+0xA0], xmm11
00007dd8c99dd29e  vmovaps [rsp+0xB0], xmm12
00007dd8c99dd2a7  vmovaps [rsp+0xC0], xmm13
00007dd8c99dd2b0  vmovaps [rsp+0xD0], xmm14
00007dd8c99dd2b9  vmovaps [rsp+0xE0], xmm15
00007dd8c99dd2c2  sub rsp, 0x30
00007dd8c99dd2c6  movaps [rsp], xmm4
00007dd8c99dd2ca  movaps [rsp+0x10], xmm9
00007dd8c99dd2d0  movaps [rsp+0x20], xmm8
00007dd8c99dd2d6  lea rdi, [rsp]
00007dd8c99dd2da  mov esi, 0x00
00007dd8c99dd2df  mov rax, 0x55FEBBDB5530
00007dd8c99dd2e9  call rax
00007dd8c99dd2eb  movaps xmm4, [rsp]
00007dd8c99dd2ef  add rsp, 0x30
00007dd8c99dd2f3  vmovaps xmm0, [rsp]
00007dd8c99dd2f8  vmovaps xmm1, [rsp+0x10]
00007dd8c99dd2fe  vmovaps xmm2, [rsp+0x20]
00007dd8c99dd304  vmovaps xmm3, [rsp+0x30]
00007dd8c99dd30a  vmovaps xmm5, [rsp+0x40]
00007dd8c99dd310  vmovaps xmm6, [rsp+0x50]
00007dd8c99dd316  vmovaps xmm7, [rsp+0x60]
00007dd8c99dd31c  vmovaps xmm8, [rsp+0x70]
00007dd8c99dd322  vmovaps xmm9, [rsp+0x80]
00007dd8c99dd32b  vmovaps xmm10, [rsp+0x90]
00007dd8c99dd334  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dd33d  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dd346  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dd34f  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dd358  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dd361  add rsp, 0xF0
00007dd8c99dd368  pop r11
00007dd8c99dd36a  pop r10
00007dd8c99dd36c  pop r9
00007dd8c99dd36e  pop r8
00007dd8c99dd370  pop rsi
00007dd8c99dd371  pop rdi
00007dd8c99dd372  pop rdx
00007dd8c99dd373  pop rcx
00007dd8c99dd374  pop rax
00007dd8c99dd375  add rsp, 0x08
00007dd8c99dd379  jmp 0x00007DD8C99DBC94
00007dd8c99dd37e  sub rsp, 0x08
00007dd8c99dd382  push rax
00007dd8c99dd383  push rcx
00007dd8c99dd384  push rdx
00007dd8c99dd385  push rdi
00007dd8c99dd386  push rsi
00007dd8c99dd387  push r8
00007dd8c99dd389  push r9
00007dd8c99dd38b  push r10
00007dd8c99dd38d  push r11
00007dd8c99dd38f  sub rsp, 0xF0
00007dd8c99dd396  vmovaps [rsp], xmm0
00007dd8c99dd39b  vmovaps [rsp+0x10], xmm1
00007dd8c99dd3a1  vmovaps [rsp+0x20], xmm2
00007dd8c99dd3a7  vmovaps [rsp+0x30], xmm3
00007dd8c99dd3ad  vmovaps [rsp+0x40], xmm4
00007dd8c99dd3b3  vmovaps [rsp+0x50], xmm5
00007dd8c99dd3b9  vmovaps [rsp+0x60], xmm6
00007dd8c99dd3bf  vmovaps [rsp+0x70], xmm7
00007dd8c99dd3c5  vmovaps [rsp+0x80], xmm8
00007dd8c99dd3ce  vmovaps [rsp+0x90], xmm10
00007dd8c99dd3d7  vmovaps [rsp+0xA0], xmm11
00007dd8c99dd3e0  vmovaps [rsp+0xB0], xmm12
00007dd8c99dd3e9  vmovaps [rsp+0xC0], xmm13
00007dd8c99dd3f2  vmovaps [rsp+0xD0], xmm14
00007dd8c99dd3fb  vmovaps [rsp+0xE0], xmm15
00007dd8c99dd404  sub rsp, 0x30
00007dd8c99dd408  movaps [rsp], xmm9
00007dd8c99dd40d  movaps [rsp+0x10], xmm10
00007dd8c99dd413  movaps [rsp+0x20], xmm8
00007dd8c99dd419  lea rdi, [rsp]
00007dd8c99dd41d  mov esi, 0x00
00007dd8c99dd422  mov rax, 0x55FEBBDB5530
00007dd8c99dd42c  call rax
00007dd8c99dd42e  movaps xmm9, [rsp]
00007dd8c99dd433  add rsp, 0x30
00007dd8c99dd437  vmovaps xmm0, [rsp]
00007dd8c99dd43c  vmovaps xmm1, [rsp+0x10]
00007dd8c99dd442  vmovaps xmm2, [rsp+0x20]
00007dd8c99dd448  vmovaps xmm3, [rsp+0x30]
00007dd8c99dd44e  vmovaps xmm4, [rsp+0x40]
00007dd8c99dd454  vmovaps xmm5, [rsp+0x50]
00007dd8c99dd45a  vmovaps xmm6, [rsp+0x60]
00007dd8c99dd460  vmovaps xmm7, [rsp+0x70]
00007dd8c99dd466  vmovaps xmm8, [rsp+0x80]
00007dd8c99dd46f  vmovaps xmm10, [rsp+0x90]
00007dd8c99dd478  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dd481  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dd48a  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dd493  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dd49c  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dd4a5  add rsp, 0xF0
00007dd8c99dd4ac  pop r11
00007dd8c99dd4ae  pop r10
00007dd8c99dd4b0  pop r9
00007dd8c99dd4b2  pop r8
00007dd8c99dd4b4  pop rsi
00007dd8c99dd4b5  pop rdi
00007dd8c99dd4b6  pop rdx
00007dd8c99dd4b7  pop rcx
00007dd8c99dd4b8  pop rax
00007dd8c99dd4b9  add rsp, 0x08
00007dd8c99dd4bd  jmp 0x00007DD8C99DBCAE
00007dd8c99dd4c2  call 0x00007DD8C98B52F0
00007dd8c99dd4c7  jmp 0x00007DD8C99DBDC8
00007dd8c99dd4cc  call 0x00007DD8C98B52F0
00007dd8c99dd4d1  jmp 0x00007DD8C99DBDDE
00007dd8c99dd4d6  sub rsp, 0x08
00007dd8c99dd4da  push rax
00007dd8c99dd4db  push rcx
00007dd8c99dd4dc  push rdx
00007dd8c99dd4dd  push rdi
00007dd8c99dd4de  push rsi
00007dd8c99dd4df  push r8
00007dd8c99dd4e1  push r9
00007dd8c99dd4e3  push r10
00007dd8c99dd4e5  push r11
00007dd8c99dd4e7  sub rsp, 0xF0
00007dd8c99dd4ee  vmovaps [rsp], xmm0
00007dd8c99dd4f3  vmovaps [rsp+0x10], xmm2
00007dd8c99dd4f9  vmovaps [rsp+0x20], xmm3
00007dd8c99dd4ff  vmovaps [rsp+0x30], xmm4
00007dd8c99dd505  vmovaps [rsp+0x40], xmm5
00007dd8c99dd50b  vmovaps [rsp+0x50], xmm6
00007dd8c99dd511  vmovaps [rsp+0x60], xmm7
00007dd8c99dd517  vmovaps [rsp+0x70], xmm8
00007dd8c99dd51d  vmovaps [rsp+0x80], xmm9
00007dd8c99dd526  vmovaps [rsp+0x90], xmm10
00007dd8c99dd52f  vmovaps [rsp+0xA0], xmm11
00007dd8c99dd538  vmovaps [rsp+0xB0], xmm12
00007dd8c99dd541  vmovaps [rsp+0xC0], xmm13
00007dd8c99dd54a  vmovaps [rsp+0xD0], xmm14
00007dd8c99dd553  vmovaps [rsp+0xE0], xmm15
00007dd8c99dd55c  sub rsp, 0x30
00007dd8c99dd560  movaps [rsp], xmm1
00007dd8c99dd564  movaps [rsp+0x10], xmm6
00007dd8c99dd569  movaps [rsp+0x20], xmm15
00007dd8c99dd56f  lea rdi, [rsp]
00007dd8c99dd573  mov esi, 0x00
00007dd8c99dd578  mov rax, 0x55FEBBDB5530
00007dd8c99dd582  call rax
00007dd8c99dd584  movaps xmm1, [rsp]
00007dd8c99dd588  add rsp, 0x30
00007dd8c99dd58c  vmovaps xmm0, [rsp]
00007dd8c99dd591  vmovaps xmm2, [rsp+0x10]
00007dd8c99dd597  vmovaps xmm3, [rsp+0x20]
00007dd8c99dd59d  vmovaps xmm4, [rsp+0x30]
00007dd8c99dd5a3  vmovaps xmm5, [rsp+0x40]
00007dd8c99dd5a9  vmovaps xmm6, [rsp+0x50]
00007dd8c99dd5af  vmovaps xmm7, [rsp+0x60]
00007dd8c99dd5b5  vmovaps xmm8, [rsp+0x70]
00007dd8c99dd5bb  vmovaps xmm9, [rsp+0x80]
00007dd8c99dd5c4  vmovaps xmm10, [rsp+0x90]
00007dd8c99dd5cd  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dd5d6  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dd5df  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dd5e8  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dd5f1  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dd5fa  add rsp, 0xF0
00007dd8c99dd601  pop r11
00007dd8c99dd603  pop r10
00007dd8c99dd605  pop r9
00007dd8c99dd607  pop r8
00007dd8c99dd609  pop rsi
00007dd8c99dd60a  pop rdi
00007dd8c99dd60b  pop rdx
00007dd8c99dd60c  pop rcx
00007dd8c99dd60d  pop rax
00007dd8c99dd60e  add rsp, 0x08
00007dd8c99dd612  jmp 0x00007DD8C99DBE1B
00007dd8c99dd617  call 0x00007DD8C98C4620
00007dd8c99dd61c  jmp 0x00007DD8C99DBE28
00007dd8c99dd621  sub rsp, 0x08
00007dd8c99dd625  push rax
00007dd8c99dd626  push rcx
00007dd8c99dd627  push rdx
00007dd8c99dd628  push rdi
00007dd8c99dd629  push rsi
00007dd8c99dd62a  push r8
00007dd8c99dd62c  push r9
00007dd8c99dd62e  push r10
00007dd8c99dd630  push r11
00007dd8c99dd632  sub rsp, 0xF0
00007dd8c99dd639  vmovaps [rsp], xmm0
00007dd8c99dd63e  vmovaps [rsp+0x10], xmm1
00007dd8c99dd644  vmovaps [rsp+0x20], xmm2
00007dd8c99dd64a  vmovaps [rsp+0x30], xmm3
00007dd8c99dd650  vmovaps [rsp+0x40], xmm4
00007dd8c99dd656  vmovaps [rsp+0x50], xmm5
00007dd8c99dd65c  vmovaps [rsp+0x60], xmm6
00007dd8c99dd662  vmovaps [rsp+0x70], xmm7
00007dd8c99dd668  vmovaps [rsp+0x80], xmm8
00007dd8c99dd671  vmovaps [rsp+0x90], xmm9
00007dd8c99dd67a  vmovaps [rsp+0xA0], xmm10
00007dd8c99dd683  vmovaps [rsp+0xB0], xmm11
00007dd8c99dd68c  vmovaps [rsp+0xC0], xmm12
00007dd8c99dd695  vmovaps [rsp+0xD0], xmm13
00007dd8c99dd69e  vmovaps [rsp+0xE0], xmm15
00007dd8c99dd6a7  sub rsp, 0x30
00007dd8c99dd6ab  movaps [rsp], xmm14
00007dd8c99dd6b0  movaps [rsp+0x10], xmm4
00007dd8c99dd6b5  movaps [rsp+0x20], xmm3
00007dd8c99dd6ba  lea rdi, [rsp]
00007dd8c99dd6be  mov esi, 0x00
00007dd8c99dd6c3  mov rax, 0x55FEBBDB5530
00007dd8c99dd6cd  call rax
00007dd8c99dd6cf  movaps xmm14, [rsp]
00007dd8c99dd6d4  add rsp, 0x30
00007dd8c99dd6d8  vmovaps xmm0, [rsp]
00007dd8c99dd6dd  vmovaps xmm1, [rsp+0x10]
00007dd8c99dd6e3  vmovaps xmm2, [rsp+0x20]
00007dd8c99dd6e9  vmovaps xmm3, [rsp+0x30]
00007dd8c99dd6ef  vmovaps xmm4, [rsp+0x40]
00007dd8c99dd6f5  vmovaps xmm5, [rsp+0x50]
00007dd8c99dd6fb  vmovaps xmm6, [rsp+0x60]
00007dd8c99dd701  vmovaps xmm7, [rsp+0x70]
00007dd8c99dd707  vmovaps xmm8, [rsp+0x80]
00007dd8c99dd710  vmovaps xmm9, [rsp+0x90]
00007dd8c99dd719  vmovaps xmm10, [rsp+0xA0]
00007dd8c99dd722  vmovaps xmm11, [rsp+0xB0]
00007dd8c99dd72b  vmovaps xmm12, [rsp+0xC0]
00007dd8c99dd734  vmovaps xmm13, [rsp+0xD0]
00007dd8c99dd73d  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dd746  add rsp, 0xF0
00007dd8c99dd74d  pop r11
00007dd8c99dd74f  pop r10
00007dd8c99dd751  pop r9
00007dd8c99dd753  pop r8
00007dd8c99dd755  pop rsi
00007dd8c99dd756  pop rdi
00007dd8c99dd757  pop rdx
00007dd8c99dd758  pop rcx
00007dd8c99dd759  pop rax
00007dd8c99dd75a  add rsp, 0x08
00007dd8c99dd75e  jmp 0x00007DD8C99DBE42
00007dd8c99dd763  sub rsp, 0x08
00007dd8c99dd767  push rax
00007dd8c99dd768  push rcx
00007dd8c99dd769  push rdx
00007dd8c99dd76a  push rdi
00007dd8c99dd76b  push rsi
00007dd8c99dd76c  push r8
00007dd8c99dd76e  push r9
00007dd8c99dd770  push r10
00007dd8c99dd772  push r11
00007dd8c99dd774  sub rsp, 0xF0
00007dd8c99dd77b  vmovaps [rsp], xmm0
00007dd8c99dd780  vmovaps [rsp+0x10], xmm1
00007dd8c99dd786  vmovaps [rsp+0x20], xmm2
00007dd8c99dd78c  vmovaps [rsp+0x30], xmm3
00007dd8c99dd792  vmovaps [rsp+0x40], xmm4
00007dd8c99dd798  vmovaps [rsp+0x50], xmm5
00007dd8c99dd79e  vmovaps [rsp+0x60], xmm7
00007dd8c99dd7a4  vmovaps [rsp+0x70], xmm8
00007dd8c99dd7aa  vmovaps [rsp+0x80], xmm9
00007dd8c99dd7b3  vmovaps [rsp+0x90], xmm10
00007dd8c99dd7bc  vmovaps [rsp+0xA0], xmm11
00007dd8c99dd7c5  vmovaps [rsp+0xB0], xmm12
00007dd8c99dd7ce  vmovaps [rsp+0xC0], xmm13
00007dd8c99dd7d7  vmovaps [rsp+0xD0], xmm14
00007dd8c99dd7e0  vmovaps [rsp+0xE0], xmm15
00007dd8c99dd7e9  sub rsp, 0x30
00007dd8c99dd7ed  movaps [rsp], xmm6
00007dd8c99dd7f1  movaps [rsp+0x10], xmm9
00007dd8c99dd7f7  movaps [rsp+0x20], xmm7
00007dd8c99dd7fc  lea rdi, [rsp]
00007dd8c99dd800  mov esi, 0x00
00007dd8c99dd805  mov rax, 0x55FEBBDB5530
00007dd8c99dd80f  call rax
00007dd8c99dd811  movaps xmm6, [rsp]
00007dd8c99dd815  add rsp, 0x30
00007dd8c99dd819  vmovaps xmm0, [rsp]
00007dd8c99dd81e  vmovaps xmm1, [rsp+0x10]
00007dd8c99dd824  vmovaps xmm2, [rsp+0x20]
00007dd8c99dd82a  vmovaps xmm3, [rsp+0x30]
00007dd8c99dd830  vmovaps xmm4, [rsp+0x40]
00007dd8c99dd836  vmovaps xmm5, [rsp+0x50]
00007dd8c99dd83c  vmovaps xmm7, [rsp+0x60]
00007dd8c99dd842  vmovaps xmm8, [rsp+0x70]
00007dd8c99dd848  vmovaps xmm9, [rsp+0x80]
00007dd8c99dd851  vmovaps xmm10, [rsp+0x90]
00007dd8c99dd85a  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dd863  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dd86c  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dd875  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dd87e  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dd887  add rsp, 0xF0
00007dd8c99dd88e  pop r11
00007dd8c99dd890  pop r10
00007dd8c99dd892  pop r9
00007dd8c99dd894  pop r8
00007dd8c99dd896  pop rsi
00007dd8c99dd897  pop rdi
00007dd8c99dd898  pop rdx
00007dd8c99dd899  pop rcx
00007dd8c99dd89a  pop rax
00007dd8c99dd89b  add rsp, 0x08
00007dd8c99dd89f  jmp 0x00007DD8C99DBE5A
00007dd8c99dd8a4  sub rsp, 0x08
00007dd8c99dd8a8  push rax
00007dd8c99dd8a9  push rcx
00007dd8c99dd8aa  push rdx
00007dd8c99dd8ab  push rdi
00007dd8c99dd8ac  push rsi
00007dd8c99dd8ad  push r8
00007dd8c99dd8af  push r9
00007dd8c99dd8b1  push r10
00007dd8c99dd8b3  push r11
00007dd8c99dd8b5  sub rsp, 0xF0
00007dd8c99dd8bc  vmovaps [rsp], xmm0
00007dd8c99dd8c1  vmovaps [rsp+0x10], xmm1
00007dd8c99dd8c7  vmovaps [rsp+0x20], xmm2
00007dd8c99dd8cd  vmovaps [rsp+0x30], xmm3
00007dd8c99dd8d3  vmovaps [rsp+0x40], xmm4
00007dd8c99dd8d9  vmovaps [rsp+0x50], xmm5
00007dd8c99dd8df  vmovaps [rsp+0x60], xmm6
00007dd8c99dd8e5  vmovaps [rsp+0x70], xmm8
00007dd8c99dd8eb  vmovaps [rsp+0x80], xmm9
00007dd8c99dd8f4  vmovaps [rsp+0x90], xmm10
00007dd8c99dd8fd  vmovaps [rsp+0xA0], xmm11
00007dd8c99dd906  vmovaps [rsp+0xB0], xmm12
00007dd8c99dd90f  vmovaps [rsp+0xC0], xmm13
00007dd8c99dd918  vmovaps [rsp+0xD0], xmm14
00007dd8c99dd921  vmovaps [rsp+0xE0], xmm15
00007dd8c99dd92a  sub rsp, 0x30
00007dd8c99dd92e  movaps [rsp], xmm7
00007dd8c99dd932  movaps [rsp+0x10], xmm4
00007dd8c99dd937  movaps [rsp+0x20], xmm9
00007dd8c99dd93d  lea rdi, [rsp]
00007dd8c99dd941  mov esi, 0x00
00007dd8c99dd946  mov rax, 0x55FEBBDB5530
00007dd8c99dd950  call rax
00007dd8c99dd952  movaps xmm7, [rsp]
00007dd8c99dd956  add rsp, 0x30
00007dd8c99dd95a  vmovaps xmm0, [rsp]
00007dd8c99dd95f  vmovaps xmm1, [rsp+0x10]
00007dd8c99dd965  vmovaps xmm2, [rsp+0x20]
00007dd8c99dd96b  vmovaps xmm3, [rsp+0x30]
00007dd8c99dd971  vmovaps xmm4, [rsp+0x40]
00007dd8c99dd977  vmovaps xmm5, [rsp+0x50]
00007dd8c99dd97d  vmovaps xmm6, [rsp+0x60]
00007dd8c99dd983  vmovaps xmm8, [rsp+0x70]
00007dd8c99dd989  vmovaps xmm9, [rsp+0x80]
00007dd8c99dd992  vmovaps xmm10, [rsp+0x90]
00007dd8c99dd99b  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dd9a4  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dd9ad  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dd9b6  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dd9bf  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dd9c8  add rsp, 0xF0
00007dd8c99dd9cf  pop r11
00007dd8c99dd9d1  pop r10
00007dd8c99dd9d3  pop r9
00007dd8c99dd9d5  pop r8
00007dd8c99dd9d7  pop rsi
00007dd8c99dd9d8  pop rdi
00007dd8c99dd9d9  pop rdx
00007dd8c99dd9da  pop rcx
00007dd8c99dd9db  pop rax
00007dd8c99dd9dc  add rsp, 0x08
00007dd8c99dd9e0  jmp 0x00007DD8C99DBE87
00007dd8c99dd9e5  sub rsp, 0x08
00007dd8c99dd9e9  push rax
00007dd8c99dd9ea  push rcx
00007dd8c99dd9eb  push rdx
00007dd8c99dd9ec  push rdi
00007dd8c99dd9ed  push rsi
00007dd8c99dd9ee  push r8
00007dd8c99dd9f0  push r9
00007dd8c99dd9f2  push r10
00007dd8c99dd9f4  push r11
00007dd8c99dd9f6  sub rsp, 0xF0
00007dd8c99dd9fd  vmovaps [rsp], xmm0
00007dd8c99dda02  vmovaps [rsp+0x10], xmm1
00007dd8c99dda08  vmovaps [rsp+0x20], xmm2
00007dd8c99dda0e  vmovaps [rsp+0x30], xmm3
00007dd8c99dda14  vmovaps [rsp+0x40], xmm5
00007dd8c99dda1a  vmovaps [rsp+0x50], xmm6
00007dd8c99dda20  vmovaps [rsp+0x60], xmm7
00007dd8c99dda26  vmovaps [rsp+0x70], xmm8
00007dd8c99dda2c  vmovaps [rsp+0x80], xmm9
00007dd8c99dda35  vmovaps [rsp+0x90], xmm10
00007dd8c99dda3e  vmovaps [rsp+0xA0], xmm11
00007dd8c99dda47  vmovaps [rsp+0xB0], xmm12
00007dd8c99dda50  vmovaps [rsp+0xC0], xmm13
00007dd8c99dda59  vmovaps [rsp+0xD0], xmm14
00007dd8c99dda62  vmovaps [rsp+0xE0], xmm15
00007dd8c99dda6b  sub rsp, 0x30
00007dd8c99dda6f  movaps [rsp], xmm4
00007dd8c99dda73  movaps [rsp+0x10], xmm15
00007dd8c99dda79  movaps [rsp+0x20], xmm9
00007dd8c99dda7f  lea rdi, [rsp]
00007dd8c99dda83  mov esi, 0x00
00007dd8c99dda88  mov rax, 0x55FEBBDB5530
00007dd8c99dda92  call rax
00007dd8c99dda94  movaps xmm4, [rsp]
00007dd8c99dda98  add rsp, 0x30
00007dd8c99dda9c  vmovaps xmm0, [rsp]
00007dd8c99ddaa1  vmovaps xmm1, [rsp+0x10]
00007dd8c99ddaa7  vmovaps xmm2, [rsp+0x20]
00007dd8c99ddaad  vmovaps xmm3, [rsp+0x30]
00007dd8c99ddab3  vmovaps xmm5, [rsp+0x40]
00007dd8c99ddab9  vmovaps xmm6, [rsp+0x50]
00007dd8c99ddabf  vmovaps xmm7, [rsp+0x60]
00007dd8c99ddac5  vmovaps xmm8, [rsp+0x70]
00007dd8c99ddacb  vmovaps xmm9, [rsp+0x80]
00007dd8c99ddad4  vmovaps xmm10, [rsp+0x90]
00007dd8c99ddadd  vmovaps xmm11, [rsp+0xA0]
00007dd8c99ddae6  vmovaps xmm12, [rsp+0xB0]
00007dd8c99ddaef  vmovaps xmm13, [rsp+0xC0]
00007dd8c99ddaf8  vmovaps xmm14, [rsp+0xD0]
00007dd8c99ddb01  vmovaps xmm15, [rsp+0xE0]
00007dd8c99ddb0a  add rsp, 0xF0
00007dd8c99ddb11  pop r11
00007dd8c99ddb13  pop r10
00007dd8c99ddb15  pop r9
00007dd8c99ddb17  pop r8
00007dd8c99ddb19  pop rsi
00007dd8c99ddb1a  pop rdi
00007dd8c99ddb1b  pop rdx
00007dd8c99ddb1c  pop rcx
00007dd8c99ddb1d  pop rax
00007dd8c99ddb1e  add rsp, 0x08
00007dd8c99ddb22  jmp 0x00007DD8C99DBEAC
00007dd8c99ddb27  call 0x00007DD8C98C4620
00007dd8c99ddb2c  jmp 0x00007DD8C99DBEB9
00007dd8c99ddb31  sub rsp, 0x08
00007dd8c99ddb35  push rax
00007dd8c99ddb36  push rcx
00007dd8c99ddb37  push rdx
00007dd8c99ddb38  push rdi
00007dd8c99ddb39  push rsi
00007dd8c99ddb3a  push r8
00007dd8c99ddb3c  push r9
00007dd8c99ddb3e  push r10
00007dd8c99ddb40  push r11
00007dd8c99ddb42  sub rsp, 0xF0
00007dd8c99ddb49  vmovaps [rsp], xmm0
00007dd8c99ddb4e  vmovaps [rsp+0x10], xmm1
00007dd8c99ddb54  vmovaps [rsp+0x20], xmm2
00007dd8c99ddb5a  vmovaps [rsp+0x30], xmm4
00007dd8c99ddb60  vmovaps [rsp+0x40], xmm5
00007dd8c99ddb66  vmovaps [rsp+0x50], xmm6
00007dd8c99ddb6c  vmovaps [rsp+0x60], xmm7
00007dd8c99ddb72  vmovaps [rsp+0x70], xmm8
00007dd8c99ddb78  vmovaps [rsp+0x80], xmm9
00007dd8c99ddb81  vmovaps [rsp+0x90], xmm10
00007dd8c99ddb8a  vmovaps [rsp+0xA0], xmm11
00007dd8c99ddb93  vmovaps [rsp+0xB0], xmm12
00007dd8c99ddb9c  vmovaps [rsp+0xC0], xmm13
00007dd8c99ddba5  vmovaps [rsp+0xD0], xmm14
00007dd8c99ddbae  vmovaps [rsp+0xE0], xmm15
00007dd8c99ddbb7  sub rsp, 0x30
00007dd8c99ddbbb  movaps [rsp], xmm3
00007dd8c99ddbbf  movaps [rsp+0x10], xmm1
00007dd8c99ddbc4  movaps [rsp+0x20], xmm9
00007dd8c99ddbca  lea rdi, [rsp]
00007dd8c99ddbce  mov esi, 0x00
00007dd8c99ddbd3  mov rax, 0x55FEBBDB5530
00007dd8c99ddbdd  call rax
00007dd8c99ddbdf  movaps xmm3, [rsp]
00007dd8c99ddbe3  add rsp, 0x30
00007dd8c99ddbe7  vmovaps xmm0, [rsp]
00007dd8c99ddbec  vmovaps xmm1, [rsp+0x10]
00007dd8c99ddbf2  vmovaps xmm2, [rsp+0x20]
00007dd8c99ddbf8  vmovaps xmm4, [rsp+0x30]
00007dd8c99ddbfe  vmovaps xmm5, [rsp+0x40]
00007dd8c99ddc04  vmovaps xmm6, [rsp+0x50]
00007dd8c99ddc0a  vmovaps xmm7, [rsp+0x60]
00007dd8c99ddc10  vmovaps xmm8, [rsp+0x70]
00007dd8c99ddc16  vmovaps xmm9, [rsp+0x80]
00007dd8c99ddc1f  vmovaps xmm10, [rsp+0x90]
00007dd8c99ddc28  vmovaps xmm11, [rsp+0xA0]
00007dd8c99ddc31  vmovaps xmm12, [rsp+0xB0]
00007dd8c99ddc3a  vmovaps xmm13, [rsp+0xC0]
00007dd8c99ddc43  vmovaps xmm14, [rsp+0xD0]
00007dd8c99ddc4c  vmovaps xmm15, [rsp+0xE0]
00007dd8c99ddc55  add rsp, 0xF0
00007dd8c99ddc5c  pop r11
00007dd8c99ddc5e  pop r10
00007dd8c99ddc60  pop r9
00007dd8c99ddc62  pop r8
00007dd8c99ddc64  pop rsi
00007dd8c99ddc65  pop rdi
00007dd8c99ddc66  pop rdx
00007dd8c99ddc67  pop rcx
00007dd8c99ddc68  pop rax
00007dd8c99ddc69  add rsp, 0x08
00007dd8c99ddc6d  jmp 0x00007DD8C99DBEF6
00007dd8c99ddc72  sub rsp, 0x08
00007dd8c99ddc76  push rax
00007dd8c99ddc77  push rcx
00007dd8c99ddc78  push rdx
00007dd8c99ddc79  push rdi
00007dd8c99ddc7a  push rsi
00007dd8c99ddc7b  push r8
00007dd8c99ddc7d  push r9
00007dd8c99ddc7f  push r10
00007dd8c99ddc81  push r11
00007dd8c99ddc83  sub rsp, 0xF0
00007dd8c99ddc8a  vmovaps [rsp], xmm0
00007dd8c99ddc8f  vmovaps [rsp+0x10], xmm2
00007dd8c99ddc95  vmovaps [rsp+0x20], xmm3
00007dd8c99ddc9b  vmovaps [rsp+0x30], xmm4
00007dd8c99ddca1  vmovaps [rsp+0x40], xmm5
00007dd8c99ddca7  vmovaps [rsp+0x50], xmm6
00007dd8c99ddcad  vmovaps [rsp+0x60], xmm7
00007dd8c99ddcb3  vmovaps [rsp+0x70], xmm8
00007dd8c99ddcb9  vmovaps [rsp+0x80], xmm9
00007dd8c99ddcc2  vmovaps [rsp+0x90], xmm10
00007dd8c99ddccb  vmovaps [rsp+0xA0], xmm11
00007dd8c99ddcd4  vmovaps [rsp+0xB0], xmm12
00007dd8c99ddcdd  vmovaps [rsp+0xC0], xmm13
00007dd8c99ddce6  vmovaps [rsp+0xD0], xmm14
00007dd8c99ddcef  vmovaps [rsp+0xE0], xmm15
00007dd8c99ddcf8  sub rsp, 0x30
00007dd8c99ddcfc  movaps [rsp], xmm1
00007dd8c99ddd00  movaps [rsp+0x10], xmm15
00007dd8c99ddd06  movaps [rsp+0x20], xmm9
00007dd8c99ddd0c  lea rdi, [rsp]
00007dd8c99ddd10  mov esi, 0x00
00007dd8c99ddd15  mov rax, 0x55FEBBDB5530
00007dd8c99ddd1f  call rax
00007dd8c99ddd21  movaps xmm1, [rsp]
00007dd8c99ddd25  add rsp, 0x30
00007dd8c99ddd29  vmovaps xmm0, [rsp]
00007dd8c99ddd2e  vmovaps xmm2, [rsp+0x10]
00007dd8c99ddd34  vmovaps xmm3, [rsp+0x20]
00007dd8c99ddd3a  vmovaps xmm4, [rsp+0x30]
00007dd8c99ddd40  vmovaps xmm5, [rsp+0x40]
00007dd8c99ddd46  vmovaps xmm6, [rsp+0x50]
00007dd8c99ddd4c  vmovaps xmm7, [rsp+0x60]
00007dd8c99ddd52  vmovaps xmm8, [rsp+0x70]
00007dd8c99ddd58  vmovaps xmm9, [rsp+0x80]
00007dd8c99ddd61  vmovaps xmm10, [rsp+0x90]
00007dd8c99ddd6a  vmovaps xmm11, [rsp+0xA0]
00007dd8c99ddd73  vmovaps xmm12, [rsp+0xB0]
00007dd8c99ddd7c  vmovaps xmm13, [rsp+0xC0]
00007dd8c99ddd85  vmovaps xmm14, [rsp+0xD0]
00007dd8c99ddd8e  vmovaps xmm15, [rsp+0xE0]
00007dd8c99ddd97  add rsp, 0xF0
00007dd8c99ddd9e  pop r11
00007dd8c99ddda0  pop r10
00007dd8c99ddda2  pop r9
00007dd8c99ddda4  pop r8
00007dd8c99ddda6  pop rsi
00007dd8c99ddda7  pop rdi
00007dd8c99ddda8  pop rdx
00007dd8c99ddda9  pop rcx
00007dd8c99dddaa  pop rax
00007dd8c99dddab  add rsp, 0x08
00007dd8c99dddaf  jmp 0x00007DD8C99DBF7E
00007dd8c99dddb4  call 0x00007DD8C98C4620
00007dd8c99dddb9  jmp 0x00007DD8C99DBF8B
00007dd8c99dddbe  sub rsp, 0x08
00007dd8c99dddc2  push rax
00007dd8c99dddc3  push rcx
00007dd8c99dddc4  push rdx
00007dd8c99dddc5  push rdi
00007dd8c99dddc6  push rsi
00007dd8c99dddc7  push r8
00007dd8c99dddc9  push r9
00007dd8c99dddcb  push r10
00007dd8c99dddcd  push r11
00007dd8c99dddcf  sub rsp, 0xF0
00007dd8c99dddd6  vmovaps [rsp], xmm0
00007dd8c99ddddb  vmovaps [rsp+0x10], xmm2
00007dd8c99ddde1  vmovaps [rsp+0x20], xmm3
00007dd8c99ddde7  vmovaps [rsp+0x30], xmm4
00007dd8c99ddded  vmovaps [rsp+0x40], xmm5
00007dd8c99dddf3  vmovaps [rsp+0x50], xmm6
00007dd8c99dddf9  vmovaps [rsp+0x60], xmm7
00007dd8c99dddff  vmovaps [rsp+0x70], xmm8
00007dd8c99dde05  vmovaps [rsp+0x80], xmm9
00007dd8c99dde0e  vmovaps [rsp+0x90], xmm10
00007dd8c99dde17  vmovaps [rsp+0xA0], xmm11
00007dd8c99dde20  vmovaps [rsp+0xB0], xmm12
00007dd8c99dde29  vmovaps [rsp+0xC0], xmm13
00007dd8c99dde32  vmovaps [rsp+0xD0], xmm14
00007dd8c99dde3b  vmovaps [rsp+0xE0], xmm15
00007dd8c99dde44  sub rsp, 0x30
00007dd8c99dde48  movaps [rsp], xmm1
00007dd8c99dde4c  movaps [rsp+0x10], xmm5
00007dd8c99dde51  movaps [rsp+0x20], xmm7
00007dd8c99dde56  lea rdi, [rsp]
00007dd8c99dde5a  mov esi, 0x00
00007dd8c99dde5f  mov rax, 0x55FEBBDB5530
00007dd8c99dde69  call rax
00007dd8c99dde6b  movaps xmm1, [rsp]
00007dd8c99dde6f  add rsp, 0x30
00007dd8c99dde73  vmovaps xmm0, [rsp]
00007dd8c99dde78  vmovaps xmm2, [rsp+0x10]
00007dd8c99dde7e  vmovaps xmm3, [rsp+0x20]
00007dd8c99dde84  vmovaps xmm4, [rsp+0x30]
00007dd8c99dde8a  vmovaps xmm5, [rsp+0x40]
00007dd8c99dde90  vmovaps xmm6, [rsp+0x50]
00007dd8c99dde96  vmovaps xmm7, [rsp+0x60]
00007dd8c99dde9c  vmovaps xmm8, [rsp+0x70]
00007dd8c99ddea2  vmovaps xmm9, [rsp+0x80]
00007dd8c99ddeab  vmovaps xmm10, [rsp+0x90]
00007dd8c99ddeb4  vmovaps xmm11, [rsp+0xA0]
00007dd8c99ddebd  vmovaps xmm12, [rsp+0xB0]
00007dd8c99ddec6  vmovaps xmm13, [rsp+0xC0]
00007dd8c99ddecf  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dded8  vmovaps xmm15, [rsp+0xE0]
00007dd8c99ddee1  add rsp, 0xF0
00007dd8c99ddee8  pop r11
00007dd8c99ddeea  pop r10
00007dd8c99ddeec  pop r9
00007dd8c99ddeee  pop r8
00007dd8c99ddef0  pop rsi
00007dd8c99ddef1  pop rdi
00007dd8c99ddef2  pop rdx
00007dd8c99ddef3  pop rcx
00007dd8c99ddef4  pop rax
00007dd8c99ddef5  add rsp, 0x08
00007dd8c99ddef9  jmp 0x00007DD8C99DC030
00007dd8c99ddefe  sub rsp, 0x08
00007dd8c99ddf02  push rax
00007dd8c99ddf03  push rcx
00007dd8c99ddf04  push rdx
00007dd8c99ddf05  push rdi
00007dd8c99ddf06  push rsi
00007dd8c99ddf07  push r8
00007dd8c99ddf09  push r9
00007dd8c99ddf0b  push r10
00007dd8c99ddf0d  push r11
00007dd8c99ddf0f  sub rsp, 0xF0
00007dd8c99ddf16  vmovaps [rsp], xmm0
00007dd8c99ddf1b  vmovaps [rsp+0x10], xmm1
00007dd8c99ddf21  vmovaps [rsp+0x20], xmm2
00007dd8c99ddf27  vmovaps [rsp+0x30], xmm3
00007dd8c99ddf2d  vmovaps [rsp+0x40], xmm4
00007dd8c99ddf33  vmovaps [rsp+0x50], xmm5
00007dd8c99ddf39  vmovaps [rsp+0x60], xmm6
00007dd8c99ddf3f  vmovaps [rsp+0x70], xmm8
00007dd8c99ddf45  vmovaps [rsp+0x80], xmm9
00007dd8c99ddf4e  vmovaps [rsp+0x90], xmm10
00007dd8c99ddf57  vmovaps [rsp+0xA0], xmm11
00007dd8c99ddf60  vmovaps [rsp+0xB0], xmm12
00007dd8c99ddf69  vmovaps [rsp+0xC0], xmm13
00007dd8c99ddf72  vmovaps [rsp+0xD0], xmm14
00007dd8c99ddf7b  vmovaps [rsp+0xE0], xmm15
00007dd8c99ddf84  sub rsp, 0x30
00007dd8c99ddf88  movaps [rsp], xmm7
00007dd8c99ddf8c  movaps [rsp+0x10], xmm5
00007dd8c99ddf91  movaps [rsp+0x20], xmm15
00007dd8c99ddf97  lea rdi, [rsp]
00007dd8c99ddf9b  mov esi, 0x00
00007dd8c99ddfa0  mov rax, 0x55FEBBDB5530
00007dd8c99ddfaa  call rax
00007dd8c99ddfac  movaps xmm7, [rsp]
00007dd8c99ddfb0  add rsp, 0x30
00007dd8c99ddfb4  vmovaps xmm0, [rsp]
00007dd8c99ddfb9  vmovaps xmm1, [rsp+0x10]
00007dd8c99ddfbf  vmovaps xmm2, [rsp+0x20]
00007dd8c99ddfc5  vmovaps xmm3, [rsp+0x30]
00007dd8c99ddfcb  vmovaps xmm4, [rsp+0x40]
00007dd8c99ddfd1  vmovaps xmm5, [rsp+0x50]
00007dd8c99ddfd7  vmovaps xmm6, [rsp+0x60]
00007dd8c99ddfdd  vmovaps xmm8, [rsp+0x70]
00007dd8c99ddfe3  vmovaps xmm9, [rsp+0x80]
00007dd8c99ddfec  vmovaps xmm10, [rsp+0x90]
00007dd8c99ddff5  vmovaps xmm11, [rsp+0xA0]
00007dd8c99ddffe  vmovaps xmm12, [rsp+0xB0]
00007dd8c99de007  vmovaps xmm13, [rsp+0xC0]
00007dd8c99de010  vmovaps xmm14, [rsp+0xD0]
00007dd8c99de019  vmovaps xmm15, [rsp+0xE0]
00007dd8c99de022  add rsp, 0xF0
00007dd8c99de029  pop r11
00007dd8c99de02b  pop r10
00007dd8c99de02d  pop r9
00007dd8c99de02f  pop r8
00007dd8c99de031  pop rsi
00007dd8c99de032  pop rdi
00007dd8c99de033  pop rdx
00007dd8c99de034  pop rcx
00007dd8c99de035  pop rax
00007dd8c99de036  add rsp, 0x08
00007dd8c99de03a  jmp 0x00007DD8C99DC066
00007dd8c99de03f  call 0x00007DD8C98B52F0
00007dd8c99de044  jmp 0x00007DD8C99DC073
00007dd8c99de049  sub rsp, 0x08
00007dd8c99de04d  push rax
00007dd8c99de04e  push rcx
00007dd8c99de04f  push rdx
00007dd8c99de050  push rdi
00007dd8c99de051  push rsi
00007dd8c99de052  push r8
00007dd8c99de054  push r9
00007dd8c99de056  push r10
00007dd8c99de058  push r11
00007dd8c99de05a  sub rsp, 0xF0
00007dd8c99de061  vmovaps [rsp], xmm0
00007dd8c99de066  vmovaps [rsp+0x10], xmm1
00007dd8c99de06c  vmovaps [rsp+0x20], xmm2
00007dd8c99de072  vmovaps [rsp+0x30], xmm3
00007dd8c99de078  vmovaps [rsp+0x40], xmm4
00007dd8c99de07e  vmovaps [rsp+0x50], xmm5
00007dd8c99de084  vmovaps [rsp+0x60], xmm6
00007dd8c99de08a  vmovaps [rsp+0x70], xmm7
00007dd8c99de090  vmovaps [rsp+0x80], xmm8
00007dd8c99de099  vmovaps [rsp+0x90], xmm9
00007dd8c99de0a2  vmovaps [rsp+0xA0], xmm10
00007dd8c99de0ab  vmovaps [rsp+0xB0], xmm11
00007dd8c99de0b4  vmovaps [rsp+0xC0], xmm12
00007dd8c99de0bd  vmovaps [rsp+0xD0], xmm13
00007dd8c99de0c6  vmovaps [rsp+0xE0], xmm14
00007dd8c99de0cf  sub rsp, 0x30
00007dd8c99de0d3  movaps [rsp], xmm15
00007dd8c99de0d8  movaps [rsp+0x10], xmm5
00007dd8c99de0dd  movaps [rsp+0x20], xmm3
00007dd8c99de0e2  lea rdi, [rsp]
00007dd8c99de0e6  mov esi, 0x00
00007dd8c99de0eb  mov rax, 0x55FEBBDB5530
00007dd8c99de0f5  call rax
00007dd8c99de0f7  movaps xmm15, [rsp]
00007dd8c99de0fc  add rsp, 0x30
00007dd8c99de100  vmovaps xmm0, [rsp]
00007dd8c99de105  vmovaps xmm1, [rsp+0x10]
00007dd8c99de10b  vmovaps xmm2, [rsp+0x20]
00007dd8c99de111  vmovaps xmm3, [rsp+0x30]
00007dd8c99de117  vmovaps xmm4, [rsp+0x40]
00007dd8c99de11d  vmovaps xmm5, [rsp+0x50]
00007dd8c99de123  vmovaps xmm6, [rsp+0x60]
00007dd8c99de129  vmovaps xmm7, [rsp+0x70]
00007dd8c99de12f  vmovaps xmm8, [rsp+0x80]
00007dd8c99de138  vmovaps xmm9, [rsp+0x90]
00007dd8c99de141  vmovaps xmm10, [rsp+0xA0]
00007dd8c99de14a  vmovaps xmm11, [rsp+0xB0]
00007dd8c99de153  vmovaps xmm12, [rsp+0xC0]
00007dd8c99de15c  vmovaps xmm13, [rsp+0xD0]
00007dd8c99de165  vmovaps xmm14, [rsp+0xE0]
00007dd8c99de16e  add rsp, 0xF0
00007dd8c99de175  pop r11
00007dd8c99de177  pop r10
00007dd8c99de179  pop r9
00007dd8c99de17b  pop r8
00007dd8c99de17d  pop rsi
00007dd8c99de17e  pop rdi
00007dd8c99de17f  pop rdx
00007dd8c99de180  pop rcx
00007dd8c99de181  pop rax
00007dd8c99de182  add rsp, 0x08
00007dd8c99de186  jmp 0x00007DD8C99DC099
00007dd8c99de18b  sub rsp, 0x08
00007dd8c99de18f  push rax
00007dd8c99de190  push rcx
00007dd8c99de191  push rdx
00007dd8c99de192  push rdi
00007dd8c99de193  push rsi
00007dd8c99de194  push r8
00007dd8c99de196  push r9
00007dd8c99de198  push r10
00007dd8c99de19a  push r11
00007dd8c99de19c  sub rsp, 0xF0
00007dd8c99de1a3  vmovaps [rsp], xmm0
00007dd8c99de1a8  vmovaps [rsp+0x10], xmm2
00007dd8c99de1ae  vmovaps [rsp+0x20], xmm3
00007dd8c99de1b4  vmovaps [rsp+0x30], xmm4
00007dd8c99de1ba  vmovaps [rsp+0x40], xmm5
00007dd8c99de1c0  vmovaps [rsp+0x50], xmm6
00007dd8c99de1c6  vmovaps [rsp+0x60], xmm7
00007dd8c99de1cc  vmovaps [rsp+0x70], xmm8
00007dd8c99de1d2  vmovaps [rsp+0x80], xmm9
00007dd8c99de1db  vmovaps [rsp+0x90], xmm10
00007dd8c99de1e4  vmovaps [rsp+0xA0], xmm11
00007dd8c99de1ed  vmovaps [rsp+0xB0], xmm12
00007dd8c99de1f6  vmovaps [rsp+0xC0], xmm13
00007dd8c99de1ff  vmovaps [rsp+0xD0], xmm14
00007dd8c99de208  vmovaps [rsp+0xE0], xmm15
00007dd8c99de211  sub rsp, 0x30
00007dd8c99de215  movaps [rsp], xmm1
00007dd8c99de219  movaps [rsp+0x10], xmm5
00007dd8c99de21e  movaps [rsp+0x20], xmm4
00007dd8c99de223  lea rdi, [rsp]
00007dd8c99de227  mov esi, 0x00
00007dd8c99de22c  mov rax, 0x55FEBBDB5530
00007dd8c99de236  call rax
00007dd8c99de238  movaps xmm1, [rsp]
00007dd8c99de23c  add rsp, 0x30
00007dd8c99de240  vmovaps xmm0, [rsp]
00007dd8c99de245  vmovaps xmm2, [rsp+0x10]
00007dd8c99de24b  vmovaps xmm3, [rsp+0x20]
00007dd8c99de251  vmovaps xmm4, [rsp+0x30]
00007dd8c99de257  vmovaps xmm5, [rsp+0x40]
00007dd8c99de25d  vmovaps xmm6, [rsp+0x50]
00007dd8c99de263  vmovaps xmm7, [rsp+0x60]
00007dd8c99de269  vmovaps xmm8, [rsp+0x70]
00007dd8c99de26f  vmovaps xmm9, [rsp+0x80]
00007dd8c99de278  vmovaps xmm10, [rsp+0x90]
00007dd8c99de281  vmovaps xmm11, [rsp+0xA0]
00007dd8c99de28a  vmovaps xmm12, [rsp+0xB0]
00007dd8c99de293  vmovaps xmm13, [rsp+0xC0]
00007dd8c99de29c  vmovaps xmm14, [rsp+0xD0]
00007dd8c99de2a5  vmovaps xmm15, [rsp+0xE0]
00007dd8c99de2ae  add rsp, 0xF0
00007dd8c99de2b5  pop r11
00007dd8c99de2b7  pop r10
00007dd8c99de2b9  pop r9
00007dd8c99de2bb  pop r8
00007dd8c99de2bd  pop rsi
00007dd8c99de2be  pop rdi
00007dd8c99de2bf  pop rdx
00007dd8c99de2c0  pop rcx
00007dd8c99de2c1  pop rax
00007dd8c99de2c2  add rsp, 0x08
00007dd8c99de2c6  jmp 0x00007DD8C99DC0B9
00007dd8c99de2cb  sub rsp, 0x08
00007dd8c99de2cf  push rax
00007dd8c99de2d0  push rcx
00007dd8c99de2d1  push rdx
00007dd8c99de2d2  push rdi
00007dd8c99de2d3  push rsi
00007dd8c99de2d4  push r8
00007dd8c99de2d6  push r9
00007dd8c99de2d8  push r10
00007dd8c99de2da  push r11
00007dd8c99de2dc  sub rsp, 0xF0
00007dd8c99de2e3  vmovaps [rsp], xmm0
00007dd8c99de2e8  vmovaps [rsp+0x10], xmm1
00007dd8c99de2ee  vmovaps [rsp+0x20], xmm2
00007dd8c99de2f4  vmovaps [rsp+0x30], xmm3
00007dd8c99de2fa  vmovaps [rsp+0x40], xmm5
00007dd8c99de300  vmovaps [rsp+0x50], xmm6
00007dd8c99de306  vmovaps [rsp+0x60], xmm7
00007dd8c99de30c  vmovaps [rsp+0x70], xmm8
00007dd8c99de312  vmovaps [rsp+0x80], xmm9
00007dd8c99de31b  vmovaps [rsp+0x90], xmm10
00007dd8c99de324  vmovaps [rsp+0xA0], xmm11
00007dd8c99de32d  vmovaps [rsp+0xB0], xmm12
00007dd8c99de336  vmovaps [rsp+0xC0], xmm13
00007dd8c99de33f  vmovaps [rsp+0xD0], xmm14
00007dd8c99de348  vmovaps [rsp+0xE0], xmm15
00007dd8c99de351  sub rsp, 0x30
00007dd8c99de355  movaps [rsp], xmm4
00007dd8c99de359  movaps [rsp+0x10], xmm3
00007dd8c99de35e  movaps [rsp+0x20], xmm5
00007dd8c99de363  lea rdi, [rsp]
00007dd8c99de367  mov esi, 0x00
00007dd8c99de36c  mov rax, 0x55FEBBDB5530
00007dd8c99de376  call rax
00007dd8c99de378  movaps xmm4, [rsp]
00007dd8c99de37c  add rsp, 0x30
00007dd8c99de380  vmovaps xmm0, [rsp]
00007dd8c99de385  vmovaps xmm1, [rsp+0x10]
00007dd8c99de38b  vmovaps xmm2, [rsp+0x20]
00007dd8c99de391  vmovaps xmm3, [rsp+0x30]
00007dd8c99de397  vmovaps xmm5, [rsp+0x40]
00007dd8c99de39d  vmovaps xmm6, [rsp+0x50]
00007dd8c99de3a3  vmovaps xmm7, [rsp+0x60]
00007dd8c99de3a9  vmovaps xmm8, [rsp+0x70]
00007dd8c99de3af  vmovaps xmm9, [rsp+0x80]
00007dd8c99de3b8  vmovaps xmm10, [rsp+0x90]
00007dd8c99de3c1  vmovaps xmm11, [rsp+0xA0]
00007dd8c99de3ca  vmovaps xmm12, [rsp+0xB0]
00007dd8c99de3d3  vmovaps xmm13, [rsp+0xC0]
00007dd8c99de3dc  vmovaps xmm14, [rsp+0xD0]
00007dd8c99de3e5  vmovaps xmm15, [rsp+0xE0]
00007dd8c99de3ee  add rsp, 0xF0
00007dd8c99de3f5  pop r11
00007dd8c99de3f7  pop r10
00007dd8c99de3f9  pop r9
00007dd8c99de3fb  pop r8
00007dd8c99de3fd  pop rsi
00007dd8c99de3fe  pop rdi
00007dd8c99de3ff  pop rdx
00007dd8c99de400  pop rcx
00007dd8c99de401  pop rax
00007dd8c99de402  add rsp, 0x08
00007dd8c99de406  jmp 0x00007DD8C99DC107
00007dd8c99de40b  call 0x00007DD8C98B52F0
00007dd8c99de410  jmp 0x00007DD8C99DC114
00007dd8c99de415  sub rsp, 0x08
00007dd8c99de419  push rax
00007dd8c99de41a  push rcx
00007dd8c99de41b  push rdx
00007dd8c99de41c  push rdi
00007dd8c99de41d  push rsi
00007dd8c99de41e  push r8
00007dd8c99de420  push r9
00007dd8c99de422  push r10
00007dd8c99de424  push r11
00007dd8c99de426  sub rsp, 0xF0
00007dd8c99de42d  vmovaps [rsp], xmm0
00007dd8c99de432  vmovaps [rsp+0x10], xmm1
00007dd8c99de438  vmovaps [rsp+0x20], xmm2
00007dd8c99de43e  vmovaps [rsp+0x30], xmm3
00007dd8c99de444  vmovaps [rsp+0x40], xmm4
00007dd8c99de44a  vmovaps [rsp+0x50], xmm6
00007dd8c99de450  vmovaps [rsp+0x60], xmm7
00007dd8c99de456  vmovaps [rsp+0x70], xmm8
00007dd8c99de45c  vmovaps [rsp+0x80], xmm9
00007dd8c99de465  vmovaps [rsp+0x90], xmm10
00007dd8c99de46e  vmovaps [rsp+0xA0], xmm11
00007dd8c99de477  vmovaps [rsp+0xB0], xmm12
00007dd8c99de480  vmovaps [rsp+0xC0], xmm13
00007dd8c99de489  vmovaps [rsp+0xD0], xmm14
00007dd8c99de492  vmovaps [rsp+0xE0], xmm15
00007dd8c99de49b  sub rsp, 0x30
00007dd8c99de49f  movaps [rsp], xmm5
00007dd8c99de4a3  movaps [rsp+0x10], xmm6
00007dd8c99de4a8  movaps [rsp+0x20], xmm3
00007dd8c99de4ad  lea rdi, [rsp]
00007dd8c99de4b1  mov esi, 0x00
00007dd8c99de4b6  mov rax, 0x55FEBBDB5530
00007dd8c99de4c0  call rax
00007dd8c99de4c2  movaps xmm5, [rsp]
00007dd8c99de4c6  add rsp, 0x30
00007dd8c99de4ca  vmovaps xmm0, [rsp]
00007dd8c99de4cf  vmovaps xmm1, [rsp+0x10]
00007dd8c99de4d5  vmovaps xmm2, [rsp+0x20]
00007dd8c99de4db  vmovaps xmm3, [rsp+0x30]
00007dd8c99de4e1  vmovaps xmm4, [rsp+0x40]
00007dd8c99de4e7  vmovaps xmm6, [rsp+0x50]
00007dd8c99de4ed  vmovaps xmm7, [rsp+0x60]
00007dd8c99de4f3  vmovaps xmm8, [rsp+0x70]
00007dd8c99de4f9  vmovaps xmm9, [rsp+0x80]
00007dd8c99de502  vmovaps xmm10, [rsp+0x90]
00007dd8c99de50b  vmovaps xmm11, [rsp+0xA0]
00007dd8c99de514  vmovaps xmm12, [rsp+0xB0]
00007dd8c99de51d  vmovaps xmm13, [rsp+0xC0]
00007dd8c99de526  vmovaps xmm14, [rsp+0xD0]
00007dd8c99de52f  vmovaps xmm15, [rsp+0xE0]
00007dd8c99de538  add rsp, 0xF0
00007dd8c99de53f  pop r11
00007dd8c99de541  pop r10
00007dd8c99de543  pop r9
00007dd8c99de545  pop r8
00007dd8c99de547  pop rsi
00007dd8c99de548  pop rdi
00007dd8c99de549  pop rdx
00007dd8c99de54a  pop rcx
00007dd8c99de54b  pop rax
00007dd8c99de54c  add rsp, 0x08
00007dd8c99de550  jmp 0x00007DD8C99DC13A
00007dd8c99de555  sub rsp, 0x08
00007dd8c99de559  push rax
00007dd8c99de55a  push rcx
00007dd8c99de55b  push rdx
00007dd8c99de55c  push rdi
00007dd8c99de55d  push rsi
00007dd8c99de55e  push r8
00007dd8c99de560  push r9
00007dd8c99de562  push r10
00007dd8c99de564  push r11
00007dd8c99de566  sub rsp, 0xF0
00007dd8c99de56d  vmovaps [rsp], xmm0
00007dd8c99de572  vmovaps [rsp+0x10], xmm1
00007dd8c99de578  vmovaps [rsp+0x20], xmm2
00007dd8c99de57e  vmovaps [rsp+0x30], xmm3
00007dd8c99de584  vmovaps [rsp+0x40], xmm4
00007dd8c99de58a  vmovaps [rsp+0x50], xmm5
00007dd8c99de590  vmovaps [rsp+0x60], xmm7
00007dd8c99de596  vmovaps [rsp+0x70], xmm8
00007dd8c99de59c  vmovaps [rsp+0x80], xmm9
00007dd8c99de5a5  vmovaps [rsp+0x90], xmm10
00007dd8c99de5ae  vmovaps [rsp+0xA0], xmm11
00007dd8c99de5b7  vmovaps [rsp+0xB0], xmm12
00007dd8c99de5c0  vmovaps [rsp+0xC0], xmm13
00007dd8c99de5c9  vmovaps [rsp+0xD0], xmm14
00007dd8c99de5d2  vmovaps [rsp+0xE0], xmm15
00007dd8c99de5db  sub rsp, 0x30
00007dd8c99de5df  movaps [rsp], xmm6
00007dd8c99de5e3  movaps [rsp+0x10], xmm9
00007dd8c99de5e9  movaps [rsp+0x20], xmm1
00007dd8c99de5ee  lea rdi, [rsp]
00007dd8c99de5f2  mov esi, 0x00
00007dd8c99de5f7  mov rax, 0x55FEBBDB5530
00007dd8c99de601  call rax
00007dd8c99de603  movaps xmm6, [rsp]
00007dd8c99de607  add rsp, 0x30
00007dd8c99de60b  vmovaps xmm0, [rsp]
00007dd8c99de610  vmovaps xmm1, [rsp+0x10]
00007dd8c99de616  vmovaps xmm2, [rsp+0x20]
00007dd8c99de61c  vmovaps xmm3, [rsp+0x30]
00007dd8c99de622  vmovaps xmm4, [rsp+0x40]
00007dd8c99de628  vmovaps xmm5, [rsp+0x50]
00007dd8c99de62e  vmovaps xmm7, [rsp+0x60]
00007dd8c99de634  vmovaps xmm8, [rsp+0x70]
00007dd8c99de63a  vmovaps xmm9, [rsp+0x80]
00007dd8c99de643  vmovaps xmm10, [rsp+0x90]
00007dd8c99de64c  vmovaps xmm11, [rsp+0xA0]
00007dd8c99de655  vmovaps xmm12, [rsp+0xB0]
00007dd8c99de65e  vmovaps xmm13, [rsp+0xC0]
00007dd8c99de667  vmovaps xmm14, [rsp+0xD0]
00007dd8c99de670  vmovaps xmm15, [rsp+0xE0]
00007dd8c99de679  add rsp, 0xF0
00007dd8c99de680  pop r11
00007dd8c99de682  pop r10
00007dd8c99de684  pop r9
00007dd8c99de686  pop r8
00007dd8c99de688  pop rsi
00007dd8c99de689  pop rdi
00007dd8c99de68a  pop rdx
00007dd8c99de68b  pop rcx
00007dd8c99de68c  pop rax
00007dd8c99de68d  add rsp, 0x08
00007dd8c99de691  jmp 0x00007DD8C99DC15E
00007dd8c99de696  sub rsp, 0x08
00007dd8c99de69a  push rax
00007dd8c99de69b  push rcx
00007dd8c99de69c  push rdx
00007dd8c99de69d  push rdi
00007dd8c99de69e  push rsi
00007dd8c99de69f  push r8
00007dd8c99de6a1  push r9
00007dd8c99de6a3  push r10
00007dd8c99de6a5  push r11
00007dd8c99de6a7  sub rsp, 0xF0
00007dd8c99de6ae  vmovaps [rsp], xmm0
00007dd8c99de6b3  vmovaps [rsp+0x10], xmm1
00007dd8c99de6b9  vmovaps [rsp+0x20], xmm2
00007dd8c99de6bf  vmovaps [rsp+0x30], xmm3
00007dd8c99de6c5  vmovaps [rsp+0x40], xmm4
00007dd8c99de6cb  vmovaps [rsp+0x50], xmm5
00007dd8c99de6d1  vmovaps [rsp+0x60], xmm6
00007dd8c99de6d7  vmovaps [rsp+0x70], xmm7
00007dd8c99de6dd  vmovaps [rsp+0x80], xmm8
00007dd8c99de6e6  vmovaps [rsp+0x90], xmm10
00007dd8c99de6ef  vmovaps [rsp+0xA0], xmm11
00007dd8c99de6f8  vmovaps [rsp+0xB0], xmm12
00007dd8c99de701  vmovaps [rsp+0xC0], xmm13
00007dd8c99de70a  vmovaps [rsp+0xD0], xmm14
00007dd8c99de713  vmovaps [rsp+0xE0], xmm15
00007dd8c99de71c  sub rsp, 0x30
00007dd8c99de720  movaps [rsp], xmm9
00007dd8c99de725  movaps [rsp+0x10], xmm3
00007dd8c99de72a  movaps [rsp+0x20], xmm1
00007dd8c99de72f  lea rdi, [rsp]
00007dd8c99de733  mov esi, 0x00
00007dd8c99de738  mov rax, 0x55FEBBDB5530
00007dd8c99de742  call rax
00007dd8c99de744  movaps xmm9, [rsp]
00007dd8c99de749  add rsp, 0x30
00007dd8c99de74d  vmovaps xmm0, [rsp]
00007dd8c99de752  vmovaps xmm1, [rsp+0x10]
00007dd8c99de758  vmovaps xmm2, [rsp+0x20]
00007dd8c99de75e  vmovaps xmm3, [rsp+0x30]
00007dd8c99de764  vmovaps xmm4, [rsp+0x40]
00007dd8c99de76a  vmovaps xmm5, [rsp+0x50]
00007dd8c99de770  vmovaps xmm6, [rsp+0x60]
00007dd8c99de776  vmovaps xmm7, [rsp+0x70]
00007dd8c99de77c  vmovaps xmm8, [rsp+0x80]
00007dd8c99de785  vmovaps xmm10, [rsp+0x90]
00007dd8c99de78e  vmovaps xmm11, [rsp+0xA0]
00007dd8c99de797  vmovaps xmm12, [rsp+0xB0]
00007dd8c99de7a0  vmovaps xmm13, [rsp+0xC0]
00007dd8c99de7a9  vmovaps xmm14, [rsp+0xD0]
00007dd8c99de7b2  vmovaps xmm15, [rsp+0xE0]
00007dd8c99de7bb  add rsp, 0xF0
00007dd8c99de7c2  pop r11
00007dd8c99de7c4  pop r10
00007dd8c99de7c6  pop r9
00007dd8c99de7c8  pop r8
00007dd8c99de7ca  pop rsi
00007dd8c99de7cb  pop rdi
00007dd8c99de7cc  pop rdx
00007dd8c99de7cd  pop rcx
00007dd8c99de7ce  pop rax
00007dd8c99de7cf  add rsp, 0x08
00007dd8c99de7d3  jmp 0x00007DD8C99DC1AA
00007dd8c99de7d8  call 0x00007DD8C98B52F0
00007dd8c99de7dd  jmp 0x00007DD8C99DC1B7
00007dd8c99de7e2  sub rsp, 0x08
00007dd8c99de7e6  push rax
00007dd8c99de7e7  push rcx
00007dd8c99de7e8  push rdx
00007dd8c99de7e9  push rdi
00007dd8c99de7ea  push rsi
00007dd8c99de7eb  push r8
00007dd8c99de7ed  push r9
00007dd8c99de7ef  push r10
00007dd8c99de7f1  push r11
00007dd8c99de7f3  sub rsp, 0xF0
00007dd8c99de7fa  vmovaps [rsp], xmm0
00007dd8c99de7ff  vmovaps [rsp+0x10], xmm1
00007dd8c99de805  vmovaps [rsp+0x20], xmm2
00007dd8c99de80b  vmovaps [rsp+0x30], xmm3
00007dd8c99de811  vmovaps [rsp+0x40], xmm4
00007dd8c99de817  vmovaps [rsp+0x50], xmm5
00007dd8c99de81d  vmovaps [rsp+0x60], xmm6
00007dd8c99de823  vmovaps [rsp+0x70], xmm7
00007dd8c99de829  vmovaps [rsp+0x80], xmm8
00007dd8c99de832  vmovaps [rsp+0x90], xmm9
00007dd8c99de83b  vmovaps [rsp+0xA0], xmm10
00007dd8c99de844  vmovaps [rsp+0xB0], xmm11
00007dd8c99de84d  vmovaps [rsp+0xC0], xmm12
00007dd8c99de856  vmovaps [rsp+0xD0], xmm13
00007dd8c99de85f  vmovaps [rsp+0xE0], xmm14
00007dd8c99de868  sub rsp, 0x30
00007dd8c99de86c  movaps [rsp], xmm15
00007dd8c99de871  movaps [rsp+0x10], xmm3
00007dd8c99de876  movaps [rsp+0x20], xmm7
00007dd8c99de87b  lea rdi, [rsp]
00007dd8c99de87f  mov esi, 0x00
00007dd8c99de884  mov rax, 0x55FEBBDB5530
00007dd8c99de88e  call rax
00007dd8c99de890  movaps xmm15, [rsp]
00007dd8c99de895  add rsp, 0x30
00007dd8c99de899  vmovaps xmm0, [rsp]
00007dd8c99de89e  vmovaps xmm1, [rsp+0x10]
00007dd8c99de8a4  vmovaps xmm2, [rsp+0x20]
00007dd8c99de8aa  vmovaps xmm3, [rsp+0x30]
00007dd8c99de8b0  vmovaps xmm4, [rsp+0x40]
00007dd8c99de8b6  vmovaps xmm5, [rsp+0x50]
00007dd8c99de8bc  vmovaps xmm6, [rsp+0x60]
00007dd8c99de8c2  vmovaps xmm7, [rsp+0x70]
00007dd8c99de8c8  vmovaps xmm8, [rsp+0x80]
00007dd8c99de8d1  vmovaps xmm9, [rsp+0x90]
00007dd8c99de8da  vmovaps xmm10, [rsp+0xA0]
00007dd8c99de8e3  vmovaps xmm11, [rsp+0xB0]
00007dd8c99de8ec  vmovaps xmm12, [rsp+0xC0]
00007dd8c99de8f5  vmovaps xmm13, [rsp+0xD0]
00007dd8c99de8fe  vmovaps xmm14, [rsp+0xE0]
00007dd8c99de907  add rsp, 0xF0
00007dd8c99de90e  pop r11
00007dd8c99de910  pop r10
00007dd8c99de912  pop r9
00007dd8c99de914  pop r8
00007dd8c99de916  pop rsi
00007dd8c99de917  pop rdi
00007dd8c99de918  pop rdx
00007dd8c99de919  pop rcx
00007dd8c99de91a  pop rax
00007dd8c99de91b  add rsp, 0x08
00007dd8c99de91f  jmp 0x00007DD8C99DC1E3
00007dd8c99de924  sub rsp, 0x08
00007dd8c99de928  push rax
00007dd8c99de929  push rcx
00007dd8c99de92a  push rdx
00007dd8c99de92b  push rdi
00007dd8c99de92c  push rsi
00007dd8c99de92d  push r8
00007dd8c99de92f  push r9
00007dd8c99de931  push r10
00007dd8c99de933  push r11
00007dd8c99de935  sub rsp, 0xF0
00007dd8c99de93c  vmovaps [rsp], xmm0
00007dd8c99de941  vmovaps [rsp+0x10], xmm1
00007dd8c99de947  vmovaps [rsp+0x20], xmm2
00007dd8c99de94d  vmovaps [rsp+0x30], xmm4
00007dd8c99de953  vmovaps [rsp+0x40], xmm5
00007dd8c99de959  vmovaps [rsp+0x50], xmm6
00007dd8c99de95f  vmovaps [rsp+0x60], xmm7
00007dd8c99de965  vmovaps [rsp+0x70], xmm8
00007dd8c99de96b  vmovaps [rsp+0x80], xmm9
00007dd8c99de974  vmovaps [rsp+0x90], xmm10
00007dd8c99de97d  vmovaps [rsp+0xA0], xmm11
00007dd8c99de986  vmovaps [rsp+0xB0], xmm12
00007dd8c99de98f  vmovaps [rsp+0xC0], xmm13
00007dd8c99de998  vmovaps [rsp+0xD0], xmm14
00007dd8c99de9a1  vmovaps [rsp+0xE0], xmm15
00007dd8c99de9aa  sub rsp, 0x30
00007dd8c99de9ae  movaps [rsp], xmm3
00007dd8c99de9b2  movaps [rsp+0x10], xmm1
00007dd8c99de9b7  movaps [rsp+0x20], xmm15
00007dd8c99de9bd  lea rdi, [rsp]
00007dd8c99de9c1  mov esi, 0x00
00007dd8c99de9c6  mov rax, 0x55FEBBDB5530
00007dd8c99de9d0  call rax
00007dd8c99de9d2  movaps xmm3, [rsp]
00007dd8c99de9d6  add rsp, 0x30
00007dd8c99de9da  vmovaps xmm0, [rsp]
00007dd8c99de9df  vmovaps xmm1, [rsp+0x10]
00007dd8c99de9e5  vmovaps xmm2, [rsp+0x20]
00007dd8c99de9eb  vmovaps xmm4, [rsp+0x30]
00007dd8c99de9f1  vmovaps xmm5, [rsp+0x40]
00007dd8c99de9f7  vmovaps xmm6, [rsp+0x50]
00007dd8c99de9fd  vmovaps xmm7, [rsp+0x60]
00007dd8c99dea03  vmovaps xmm8, [rsp+0x70]
00007dd8c99dea09  vmovaps xmm9, [rsp+0x80]
00007dd8c99dea12  vmovaps xmm10, [rsp+0x90]
00007dd8c99dea1b  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dea24  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dea2d  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dea36  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dea3f  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dea48  add rsp, 0xF0
00007dd8c99dea4f  pop r11
00007dd8c99dea51  pop r10
00007dd8c99dea53  pop r9
00007dd8c99dea55  pop r8
00007dd8c99dea57  pop rsi
00007dd8c99dea58  pop rdi
00007dd8c99dea59  pop rdx
00007dd8c99dea5a  pop rcx
00007dd8c99dea5b  pop rax
00007dd8c99dea5c  add rsp, 0x08
00007dd8c99dea60  jmp 0x00007DD8C99DC272
00007dd8c99dea65  call 0x00007DD8C98B52F0
00007dd8c99dea6a  jmp 0x00007DD8C99DC27C
00007dd8c99dea6f  sub rsp, 0x08
00007dd8c99dea73  push rax
00007dd8c99dea74  push rcx
00007dd8c99dea75  push rdx
00007dd8c99dea76  push rdi
00007dd8c99dea77  push rsi
00007dd8c99dea78  push r8
00007dd8c99dea7a  push r9
00007dd8c99dea7c  push r10
00007dd8c99dea7e  push r11
00007dd8c99dea80  sub rsp, 0xF0
00007dd8c99dea87  vmovaps [rsp], xmm0
00007dd8c99dea8c  vmovaps [rsp+0x10], xmm1
00007dd8c99dea92  vmovaps [rsp+0x20], xmm2
00007dd8c99dea98  vmovaps [rsp+0x30], xmm3
00007dd8c99dea9e  vmovaps [rsp+0x40], xmm4
00007dd8c99deaa4  vmovaps [rsp+0x50], xmm5
00007dd8c99deaaa  vmovaps [rsp+0x60], xmm6
00007dd8c99deab0  vmovaps [rsp+0x70], xmm7
00007dd8c99deab6  vmovaps [rsp+0x80], xmm8
00007dd8c99deabf  vmovaps [rsp+0x90], xmm9
00007dd8c99deac8  vmovaps [rsp+0xA0], xmm10
00007dd8c99dead1  vmovaps [rsp+0xB0], xmm11
00007dd8c99deada  vmovaps [rsp+0xC0], xmm12
00007dd8c99deae3  vmovaps [rsp+0xD0], xmm13
00007dd8c99deaec  vmovaps [rsp+0xE0], xmm14
00007dd8c99deaf5  sub rsp, 0x30
00007dd8c99deaf9  movaps [rsp], xmm15
00007dd8c99deafe  movaps [rsp+0x10], xmm14
00007dd8c99deb04  movaps [rsp+0x20], xmm4
00007dd8c99deb09  lea rdi, [rsp]
00007dd8c99deb0d  mov esi, 0x00
00007dd8c99deb12  mov rax, 0x55FEBBDB5530
00007dd8c99deb1c  call rax
00007dd8c99deb1e  movaps xmm15, [rsp]
00007dd8c99deb23  add rsp, 0x30
00007dd8c99deb27  vmovaps xmm0, [rsp]
00007dd8c99deb2c  vmovaps xmm1, [rsp+0x10]
00007dd8c99deb32  vmovaps xmm2, [rsp+0x20]
00007dd8c99deb38  vmovaps xmm3, [rsp+0x30]
00007dd8c99deb3e  vmovaps xmm4, [rsp+0x40]
00007dd8c99deb44  vmovaps xmm5, [rsp+0x50]
00007dd8c99deb4a  vmovaps xmm6, [rsp+0x60]
00007dd8c99deb50  vmovaps xmm7, [rsp+0x70]
00007dd8c99deb56  vmovaps xmm8, [rsp+0x80]
00007dd8c99deb5f  vmovaps xmm9, [rsp+0x90]
00007dd8c99deb68  vmovaps xmm10, [rsp+0xA0]
00007dd8c99deb71  vmovaps xmm11, [rsp+0xB0]
00007dd8c99deb7a  vmovaps xmm12, [rsp+0xC0]
00007dd8c99deb83  vmovaps xmm13, [rsp+0xD0]
00007dd8c99deb8c  vmovaps xmm14, [rsp+0xE0]
00007dd8c99deb95  add rsp, 0xF0
00007dd8c99deb9c  pop r11
00007dd8c99deb9e  pop r10
00007dd8c99deba0  pop r9
00007dd8c99deba2  pop r8
00007dd8c99deba4  pop rsi
00007dd8c99deba5  pop rdi
00007dd8c99deba6  pop rdx
00007dd8c99deba7  pop rcx
00007dd8c99deba8  pop rax
00007dd8c99deba9  add rsp, 0x08
00007dd8c99debad  jmp 0x00007DD8C99DC2AA
00007dd8c99debb2  sub rsp, 0x08
00007dd8c99debb6  push rax
00007dd8c99debb7  push rcx
00007dd8c99debb8  push rdx
00007dd8c99debb9  push rdi
00007dd8c99debba  push rsi
00007dd8c99debbb  push r8
00007dd8c99debbd  push r9
00007dd8c99debbf  push r10
00007dd8c99debc1  push r11
00007dd8c99debc3  sub rsp, 0xF0
00007dd8c99debca  vmovaps [rsp], xmm0
00007dd8c99debcf  vmovaps [rsp+0x10], xmm1
00007dd8c99debd5  vmovaps [rsp+0x20], xmm2
00007dd8c99debdb  vmovaps [rsp+0x30], xmm3
00007dd8c99debe1  vmovaps [rsp+0x40], xmm4
00007dd8c99debe7  vmovaps [rsp+0x50], xmm5
00007dd8c99debed  vmovaps [rsp+0x60], xmm6
00007dd8c99debf3  vmovaps [rsp+0x70], xmm7
00007dd8c99debf9  vmovaps [rsp+0x80], xmm8
00007dd8c99dec02  vmovaps [rsp+0x90], xmm9
00007dd8c99dec0b  vmovaps [rsp+0xA0], xmm10
00007dd8c99dec14  vmovaps [rsp+0xB0], xmm11
00007dd8c99dec1d  vmovaps [rsp+0xC0], xmm12
00007dd8c99dec26  vmovaps [rsp+0xD0], xmm13
00007dd8c99dec2f  vmovaps [rsp+0xE0], xmm15
00007dd8c99dec38  sub rsp, 0x30
00007dd8c99dec3c  movaps [rsp], xmm14
00007dd8c99dec41  movaps [rsp+0x10], xmm2
00007dd8c99dec46  movaps [rsp+0x20], xmm1
00007dd8c99dec4b  lea rdi, [rsp]
00007dd8c99dec4f  mov esi, 0x00
00007dd8c99dec54  mov rax, 0x55FEBBDB5530
00007dd8c99dec5e  call rax
00007dd8c99dec60  movaps xmm14, [rsp]
00007dd8c99dec65  add rsp, 0x30
00007dd8c99dec69  vmovaps xmm0, [rsp]
00007dd8c99dec6e  vmovaps xmm1, [rsp+0x10]
00007dd8c99dec74  vmovaps xmm2, [rsp+0x20]
00007dd8c99dec7a  vmovaps xmm3, [rsp+0x30]
00007dd8c99dec80  vmovaps xmm4, [rsp+0x40]
00007dd8c99dec86  vmovaps xmm5, [rsp+0x50]
00007dd8c99dec8c  vmovaps xmm6, [rsp+0x60]
00007dd8c99dec92  vmovaps xmm7, [rsp+0x70]
00007dd8c99dec98  vmovaps xmm8, [rsp+0x80]
00007dd8c99deca1  vmovaps xmm9, [rsp+0x90]
00007dd8c99decaa  vmovaps xmm10, [rsp+0xA0]
00007dd8c99decb3  vmovaps xmm11, [rsp+0xB0]
00007dd8c99decbc  vmovaps xmm12, [rsp+0xC0]
00007dd8c99decc5  vmovaps xmm13, [rsp+0xD0]
00007dd8c99decce  vmovaps xmm15, [rsp+0xE0]
00007dd8c99decd7  add rsp, 0xF0
00007dd8c99decde  pop r11
00007dd8c99dece0  pop r10
00007dd8c99dece2  pop r9
00007dd8c99dece4  pop r8
00007dd8c99dece6  pop rsi
00007dd8c99dece7  pop rdi
00007dd8c99dece8  pop rdx
00007dd8c99dece9  pop rcx
00007dd8c99decea  pop rax
00007dd8c99deceb  add rsp, 0x08
00007dd8c99decef  jmp 0x00007DD8C99DC2D0
00007dd8c99decf4  sub rsp, 0x08
00007dd8c99decf8  push rax
00007dd8c99decf9  push rcx
00007dd8c99decfa  push rdx
00007dd8c99decfb  push rdi
00007dd8c99decfc  push rsi
00007dd8c99decfd  push r8
00007dd8c99decff  push r9
00007dd8c99ded01  push r10
00007dd8c99ded03  push r11
00007dd8c99ded05  sub rsp, 0xF0
00007dd8c99ded0c  vmovaps [rsp], xmm0
00007dd8c99ded11  vmovaps [rsp+0x10], xmm2
00007dd8c99ded17  vmovaps [rsp+0x20], xmm3
00007dd8c99ded1d  vmovaps [rsp+0x30], xmm4
00007dd8c99ded23  vmovaps [rsp+0x40], xmm5
00007dd8c99ded29  vmovaps [rsp+0x50], xmm6
00007dd8c99ded2f  vmovaps [rsp+0x60], xmm7
00007dd8c99ded35  vmovaps [rsp+0x70], xmm8
00007dd8c99ded3b  vmovaps [rsp+0x80], xmm9
00007dd8c99ded44  vmovaps [rsp+0x90], xmm10
00007dd8c99ded4d  vmovaps [rsp+0xA0], xmm11
00007dd8c99ded56  vmovaps [rsp+0xB0], xmm12
00007dd8c99ded5f  vmovaps [rsp+0xC0], xmm13
00007dd8c99ded68  vmovaps [rsp+0xD0], xmm14
00007dd8c99ded71  vmovaps [rsp+0xE0], xmm15
00007dd8c99ded7a  sub rsp, 0x30
00007dd8c99ded7e  movaps [rsp], xmm1
00007dd8c99ded82  movaps [rsp+0x10], xmm4
00007dd8c99ded87  movaps [rsp+0x20], xmm9
00007dd8c99ded8d  lea rdi, [rsp]
00007dd8c99ded91  mov esi, 0x00
00007dd8c99ded96  mov rax, 0x55FEBBDB5530
00007dd8c99deda0  call rax
00007dd8c99deda2  movaps xmm1, [rsp]
00007dd8c99deda6  add rsp, 0x30
00007dd8c99dedaa  vmovaps xmm0, [rsp]
00007dd8c99dedaf  vmovaps xmm2, [rsp+0x10]
00007dd8c99dedb5  vmovaps xmm3, [rsp+0x20]
00007dd8c99dedbb  vmovaps xmm4, [rsp+0x30]
00007dd8c99dedc1  vmovaps xmm5, [rsp+0x40]
00007dd8c99dedc7  vmovaps xmm6, [rsp+0x50]
00007dd8c99dedcd  vmovaps xmm7, [rsp+0x60]
00007dd8c99dedd3  vmovaps xmm8, [rsp+0x70]
00007dd8c99dedd9  vmovaps xmm9, [rsp+0x80]
00007dd8c99dede2  vmovaps xmm10, [rsp+0x90]
00007dd8c99dedeb  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dedf4  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dedfd  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dee06  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dee0f  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dee18  add rsp, 0xF0
00007dd8c99dee1f  pop r11
00007dd8c99dee21  pop r10
00007dd8c99dee23  pop r9
00007dd8c99dee25  pop r8
00007dd8c99dee27  pop rsi
00007dd8c99dee28  pop rdi
00007dd8c99dee29  pop rdx
00007dd8c99dee2a  pop rcx
00007dd8c99dee2b  pop rax
00007dd8c99dee2c  add rsp, 0x08
00007dd8c99dee30  jmp 0x00007DD8C99DC2EE
00007dd8c99dee35  sub rsp, 0x08
00007dd8c99dee39  push rax
00007dd8c99dee3a  push rcx
00007dd8c99dee3b  push rdx
00007dd8c99dee3c  push rdi
00007dd8c99dee3d  push rsi
00007dd8c99dee3e  push r8
00007dd8c99dee40  push r9
00007dd8c99dee42  push r10
00007dd8c99dee44  push r11
00007dd8c99dee46  sub rsp, 0xF0
00007dd8c99dee4d  vmovaps [rsp], xmm0
00007dd8c99dee52  vmovaps [rsp+0x10], xmm1
00007dd8c99dee58  vmovaps [rsp+0x20], xmm2
00007dd8c99dee5e  vmovaps [rsp+0x30], xmm3
00007dd8c99dee64  vmovaps [rsp+0x40], xmm5
00007dd8c99dee6a  vmovaps [rsp+0x50], xmm6
00007dd8c99dee70  vmovaps [rsp+0x60], xmm7
00007dd8c99dee76  vmovaps [rsp+0x70], xmm8
00007dd8c99dee7c  vmovaps [rsp+0x80], xmm9
00007dd8c99dee85  vmovaps [rsp+0x90], xmm10
00007dd8c99dee8e  vmovaps [rsp+0xA0], xmm11
00007dd8c99dee97  vmovaps [rsp+0xB0], xmm12
00007dd8c99deea0  vmovaps [rsp+0xC0], xmm13
00007dd8c99deea9  vmovaps [rsp+0xD0], xmm14
00007dd8c99deeb2  vmovaps [rsp+0xE0], xmm15
00007dd8c99deebb  sub rsp, 0x30
00007dd8c99deebf  movaps [rsp], xmm4
00007dd8c99deec3  movaps [rsp+0x10], xmm2
00007dd8c99deec8  movaps [rsp+0x20], xmm9
00007dd8c99deece  lea rdi, [rsp]
00007dd8c99deed2  mov esi, 0x00
00007dd8c99deed7  mov rax, 0x55FEBBDB5530
00007dd8c99deee1  call rax
00007dd8c99deee3  movaps xmm4, [rsp]
00007dd8c99deee7  add rsp, 0x30
00007dd8c99deeeb  vmovaps xmm0, [rsp]
00007dd8c99deef0  vmovaps xmm1, [rsp+0x10]
00007dd8c99deef6  vmovaps xmm2, [rsp+0x20]
00007dd8c99deefc  vmovaps xmm3, [rsp+0x30]
00007dd8c99def02  vmovaps xmm5, [rsp+0x40]
00007dd8c99def08  vmovaps xmm6, [rsp+0x50]
00007dd8c99def0e  vmovaps xmm7, [rsp+0x60]
00007dd8c99def14  vmovaps xmm8, [rsp+0x70]
00007dd8c99def1a  vmovaps xmm9, [rsp+0x80]
00007dd8c99def23  vmovaps xmm10, [rsp+0x90]
00007dd8c99def2c  vmovaps xmm11, [rsp+0xA0]
00007dd8c99def35  vmovaps xmm12, [rsp+0xB0]
00007dd8c99def3e  vmovaps xmm13, [rsp+0xC0]
00007dd8c99def47  vmovaps xmm14, [rsp+0xD0]
00007dd8c99def50  vmovaps xmm15, [rsp+0xE0]
00007dd8c99def59  add rsp, 0xF0
00007dd8c99def60  pop r11
00007dd8c99def62  pop r10
00007dd8c99def64  pop r9
00007dd8c99def66  pop r8
00007dd8c99def68  pop rsi
00007dd8c99def69  pop rdi
00007dd8c99def6a  pop rdx
00007dd8c99def6b  pop rcx
00007dd8c99def6c  pop rax
00007dd8c99def6d  add rsp, 0x08
00007dd8c99def71  jmp 0x00007DD8C99DC31E
00007dd8c99def76  sub rsp, 0x08
00007dd8c99def7a  push rax
00007dd8c99def7b  push rcx
00007dd8c99def7c  push rdx
00007dd8c99def7d  push rdi
00007dd8c99def7e  push rsi
00007dd8c99def7f  push r8
00007dd8c99def81  push r9
00007dd8c99def83  push r10
00007dd8c99def85  push r11
00007dd8c99def87  sub rsp, 0xF0
00007dd8c99def8e  vmovaps [rsp], xmm0
00007dd8c99def93  vmovaps [rsp+0x10], xmm1
00007dd8c99def99  vmovaps [rsp+0x20], xmm2
00007dd8c99def9f  vmovaps [rsp+0x30], xmm3
00007dd8c99defa5  vmovaps [rsp+0x40], xmm4
00007dd8c99defab  vmovaps [rsp+0x50], xmm5
00007dd8c99defb1  vmovaps [rsp+0x60], xmm6
00007dd8c99defb7  vmovaps [rsp+0x70], xmm7
00007dd8c99defbd  vmovaps [rsp+0x80], xmm8
00007dd8c99defc6  vmovaps [rsp+0x90], xmm10
00007dd8c99defcf  vmovaps [rsp+0xA0], xmm11
00007dd8c99defd8  vmovaps [rsp+0xB0], xmm12
00007dd8c99defe1  vmovaps [rsp+0xC0], xmm13
00007dd8c99defea  vmovaps [rsp+0xD0], xmm14
00007dd8c99deff3  vmovaps [rsp+0xE0], xmm15
00007dd8c99deffc  sub rsp, 0x30
00007dd8c99df000  movaps [rsp], xmm9
00007dd8c99df005  movaps [rsp+0x10], xmm2
00007dd8c99df00a  movaps [rsp+0x20], xmm1
00007dd8c99df00f  lea rdi, [rsp]
00007dd8c99df013  mov esi, 0x00
00007dd8c99df018  mov rax, 0x55FEBBDB5530
00007dd8c99df022  call rax
00007dd8c99df024  movaps xmm9, [rsp]
00007dd8c99df029  add rsp, 0x30
00007dd8c99df02d  vmovaps xmm0, [rsp]
00007dd8c99df032  vmovaps xmm1, [rsp+0x10]
00007dd8c99df038  vmovaps xmm2, [rsp+0x20]
00007dd8c99df03e  vmovaps xmm3, [rsp+0x30]
00007dd8c99df044  vmovaps xmm4, [rsp+0x40]
00007dd8c99df04a  vmovaps xmm5, [rsp+0x50]
00007dd8c99df050  vmovaps xmm6, [rsp+0x60]
00007dd8c99df056  vmovaps xmm7, [rsp+0x70]
00007dd8c99df05c  vmovaps xmm8, [rsp+0x80]
00007dd8c99df065  vmovaps xmm10, [rsp+0x90]
00007dd8c99df06e  vmovaps xmm11, [rsp+0xA0]
00007dd8c99df077  vmovaps xmm12, [rsp+0xB0]
00007dd8c99df080  vmovaps xmm13, [rsp+0xC0]
00007dd8c99df089  vmovaps xmm14, [rsp+0xD0]
00007dd8c99df092  vmovaps xmm15, [rsp+0xE0]
00007dd8c99df09b  add rsp, 0xF0
00007dd8c99df0a2  pop r11
00007dd8c99df0a4  pop r10
00007dd8c99df0a6  pop r9
00007dd8c99df0a8  pop r8
00007dd8c99df0aa  pop rsi
00007dd8c99df0ab  pop rdi
00007dd8c99df0ac  pop rdx
00007dd8c99df0ad  pop rcx
00007dd8c99df0ae  pop rax
00007dd8c99df0af  add rsp, 0x08
00007dd8c99df0b3  jmp 0x00007DD8C99DC354
00007dd8c99df0b8  sub rsp, 0x08
00007dd8c99df0bc  push rax
00007dd8c99df0bd  push rcx
00007dd8c99df0be  push rdx
00007dd8c99df0bf  push rdi
00007dd8c99df0c0  push rsi
00007dd8c99df0c1  push r8
00007dd8c99df0c3  push r9
00007dd8c99df0c5  push r10
00007dd8c99df0c7  push r11
00007dd8c99df0c9  sub rsp, 0xF0
00007dd8c99df0d0  vmovaps [rsp], xmm0
00007dd8c99df0d5  vmovaps [rsp+0x10], xmm2
00007dd8c99df0db  vmovaps [rsp+0x20], xmm3
00007dd8c99df0e1  vmovaps [rsp+0x30], xmm4
00007dd8c99df0e7  vmovaps [rsp+0x40], xmm5
00007dd8c99df0ed  vmovaps [rsp+0x50], xmm6
00007dd8c99df0f3  vmovaps [rsp+0x60], xmm7
00007dd8c99df0f9  vmovaps [rsp+0x70], xmm8
00007dd8c99df0ff  vmovaps [rsp+0x80], xmm9
00007dd8c99df108  vmovaps [rsp+0x90], xmm10
00007dd8c99df111  vmovaps [rsp+0xA0], xmm11
00007dd8c99df11a  vmovaps [rsp+0xB0], xmm12
00007dd8c99df123  vmovaps [rsp+0xC0], xmm13
00007dd8c99df12c  vmovaps [rsp+0xD0], xmm14
00007dd8c99df135  vmovaps [rsp+0xE0], xmm15
00007dd8c99df13e  sub rsp, 0x30
00007dd8c99df142  movaps [rsp], xmm1
00007dd8c99df146  movaps [rsp+0x10], xmm15
00007dd8c99df14c  movaps [rsp+0x20], xmm6
00007dd8c99df151  lea rdi, [rsp]
00007dd8c99df155  mov esi, 0x00
00007dd8c99df15a  mov rax, 0x55FEBBDB5530
00007dd8c99df164  call rax
00007dd8c99df166  movaps xmm1, [rsp]
00007dd8c99df16a  add rsp, 0x30
00007dd8c99df16e  vmovaps xmm0, [rsp]
00007dd8c99df173  vmovaps xmm2, [rsp+0x10]
00007dd8c99df179  vmovaps xmm3, [rsp+0x20]
00007dd8c99df17f  vmovaps xmm4, [rsp+0x30]
00007dd8c99df185  vmovaps xmm5, [rsp+0x40]
00007dd8c99df18b  vmovaps xmm6, [rsp+0x50]
00007dd8c99df191  vmovaps xmm7, [rsp+0x60]
00007dd8c99df197  vmovaps xmm8, [rsp+0x70]
00007dd8c99df19d  vmovaps xmm9, [rsp+0x80]
00007dd8c99df1a6  vmovaps xmm10, [rsp+0x90]
00007dd8c99df1af  vmovaps xmm11, [rsp+0xA0]
00007dd8c99df1b8  vmovaps xmm12, [rsp+0xB0]
00007dd8c99df1c1  vmovaps xmm13, [rsp+0xC0]
00007dd8c99df1ca  vmovaps xmm14, [rsp+0xD0]
00007dd8c99df1d3  vmovaps xmm15, [rsp+0xE0]
00007dd8c99df1dc  add rsp, 0xF0
00007dd8c99df1e3  pop r11
00007dd8c99df1e5  pop r10
00007dd8c99df1e7  pop r9
00007dd8c99df1e9  pop r8
00007dd8c99df1eb  pop rsi
00007dd8c99df1ec  pop rdi
00007dd8c99df1ed  pop rdx
00007dd8c99df1ee  pop rcx
00007dd8c99df1ef  pop rax
00007dd8c99df1f0  add rsp, 0x08
00007dd8c99df1f4  jmp 0x00007DD8C99DC375
00007dd8c99df1f9  sub rsp, 0x08
00007dd8c99df1fd  push rax
00007dd8c99df1fe  push rcx
00007dd8c99df1ff  push rdx
00007dd8c99df200  push rdi
00007dd8c99df201  push rsi
00007dd8c99df202  push r8
00007dd8c99df204  push r9
00007dd8c99df206  push r10
00007dd8c99df208  push r11
00007dd8c99df20a  sub rsp, 0xF0
00007dd8c99df211  vmovaps [rsp], xmm0
00007dd8c99df216  vmovaps [rsp+0x10], xmm1
00007dd8c99df21c  vmovaps [rsp+0x20], xmm2
00007dd8c99df222  vmovaps [rsp+0x30], xmm3
00007dd8c99df228  vmovaps [rsp+0x40], xmm4
00007dd8c99df22e  vmovaps [rsp+0x50], xmm5
00007dd8c99df234  vmovaps [rsp+0x60], xmm6
00007dd8c99df23a  vmovaps [rsp+0x70], xmm7
00007dd8c99df240  vmovaps [rsp+0x80], xmm8
00007dd8c99df249  vmovaps [rsp+0x90], xmm9
00007dd8c99df252  vmovaps [rsp+0xA0], xmm10
00007dd8c99df25b  vmovaps [rsp+0xB0], xmm11
00007dd8c99df264  vmovaps [rsp+0xC0], xmm12
00007dd8c99df26d  vmovaps [rsp+0xD0], xmm13
00007dd8c99df276  vmovaps [rsp+0xE0], xmm14
00007dd8c99df27f  sub rsp, 0x30
00007dd8c99df283  movaps [rsp], xmm15
00007dd8c99df288  movaps [rsp+0x10], xmm5
00007dd8c99df28d  movaps [rsp+0x20], xmm3
00007dd8c99df292  lea rdi, [rsp]
00007dd8c99df296  mov esi, 0x00
00007dd8c99df29b  mov rax, 0x55FEBBDB5530
00007dd8c99df2a5  call rax
00007dd8c99df2a7  movaps xmm15, [rsp]
00007dd8c99df2ac  add rsp, 0x30
00007dd8c99df2b0  vmovaps xmm0, [rsp]
00007dd8c99df2b5  vmovaps xmm1, [rsp+0x10]
00007dd8c99df2bb  vmovaps xmm2, [rsp+0x20]
00007dd8c99df2c1  vmovaps xmm3, [rsp+0x30]
00007dd8c99df2c7  vmovaps xmm4, [rsp+0x40]
00007dd8c99df2cd  vmovaps xmm5, [rsp+0x50]
00007dd8c99df2d3  vmovaps xmm6, [rsp+0x60]
00007dd8c99df2d9  vmovaps xmm7, [rsp+0x70]
00007dd8c99df2df  vmovaps xmm8, [rsp+0x80]
00007dd8c99df2e8  vmovaps xmm9, [rsp+0x90]
00007dd8c99df2f1  vmovaps xmm10, [rsp+0xA0]
00007dd8c99df2fa  vmovaps xmm11, [rsp+0xB0]
00007dd8c99df303  vmovaps xmm12, [rsp+0xC0]
00007dd8c99df30c  vmovaps xmm13, [rsp+0xD0]
00007dd8c99df315  vmovaps xmm14, [rsp+0xE0]
00007dd8c99df31e  add rsp, 0xF0
00007dd8c99df325  pop r11
00007dd8c99df327  pop r10
00007dd8c99df329  pop r9
00007dd8c99df32b  pop r8
00007dd8c99df32d  pop rsi
00007dd8c99df32e  pop rdi
00007dd8c99df32f  pop rdx
00007dd8c99df330  pop rcx
00007dd8c99df331  pop rax
00007dd8c99df332  add rsp, 0x08
00007dd8c99df336  jmp 0x00007DD8C99DC38F
00007dd8c99df33b  sub rsp, 0x08
00007dd8c99df33f  push rax
00007dd8c99df340  push rcx
00007dd8c99df341  push rdx
00007dd8c99df342  push rdi
00007dd8c99df343  push rsi
00007dd8c99df344  push r8
00007dd8c99df346  push r9
00007dd8c99df348  push r10
00007dd8c99df34a  push r11
00007dd8c99df34c  sub rsp, 0xF0
00007dd8c99df353  vmovaps [rsp], xmm0
00007dd8c99df358  vmovaps [rsp+0x10], xmm1
00007dd8c99df35e  vmovaps [rsp+0x20], xmm2
00007dd8c99df364  vmovaps [rsp+0x30], xmm3
00007dd8c99df36a  vmovaps [rsp+0x40], xmm4
00007dd8c99df370  vmovaps [rsp+0x50], xmm6
00007dd8c99df376  vmovaps [rsp+0x60], xmm7
00007dd8c99df37c  vmovaps [rsp+0x70], xmm8
00007dd8c99df382  vmovaps [rsp+0x80], xmm9
00007dd8c99df38b  vmovaps [rsp+0x90], xmm10
00007dd8c99df394  vmovaps [rsp+0xA0], xmm11
00007dd8c99df39d  vmovaps [rsp+0xB0], xmm12
00007dd8c99df3a6  vmovaps [rsp+0xC0], xmm13
00007dd8c99df3af  vmovaps [rsp+0xD0], xmm14
00007dd8c99df3b8  vmovaps [rsp+0xE0], xmm15
00007dd8c99df3c1  sub rsp, 0x30
00007dd8c99df3c5  movaps [rsp], xmm5
00007dd8c99df3c9  movaps [rsp+0x10], xmm8
00007dd8c99df3cf  movaps [rsp+0x20], xmm6
00007dd8c99df3d4  lea rdi, [rsp]
00007dd8c99df3d8  mov esi, 0x00
00007dd8c99df3dd  mov rax, 0x55FEBBDB5530
00007dd8c99df3e7  call rax
00007dd8c99df3e9  movaps xmm5, [rsp]
00007dd8c99df3ed  add rsp, 0x30
00007dd8c99df3f1  vmovaps xmm0, [rsp]
00007dd8c99df3f6  vmovaps xmm1, [rsp+0x10]
00007dd8c99df3fc  vmovaps xmm2, [rsp+0x20]
00007dd8c99df402  vmovaps xmm3, [rsp+0x30]
00007dd8c99df408  vmovaps xmm4, [rsp+0x40]
00007dd8c99df40e  vmovaps xmm6, [rsp+0x50]
00007dd8c99df414  vmovaps xmm7, [rsp+0x60]
00007dd8c99df41a  vmovaps xmm8, [rsp+0x70]
00007dd8c99df420  vmovaps xmm9, [rsp+0x80]
00007dd8c99df429  vmovaps xmm10, [rsp+0x90]
00007dd8c99df432  vmovaps xmm11, [rsp+0xA0]
00007dd8c99df43b  vmovaps xmm12, [rsp+0xB0]
00007dd8c99df444  vmovaps xmm13, [rsp+0xC0]
00007dd8c99df44d  vmovaps xmm14, [rsp+0xD0]
00007dd8c99df456  vmovaps xmm15, [rsp+0xE0]
00007dd8c99df45f  add rsp, 0xF0
00007dd8c99df466  pop r11
00007dd8c99df468  pop r10
00007dd8c99df46a  pop r9
00007dd8c99df46c  pop r8
00007dd8c99df46e  pop rsi
00007dd8c99df46f  pop rdi
00007dd8c99df470  pop rdx
00007dd8c99df471  pop rcx
00007dd8c99df472  pop rax
00007dd8c99df473  add rsp, 0x08
00007dd8c99df477  jmp 0x00007DD8C99DC3B3
00007dd8c99df47c  sub rsp, 0x08
00007dd8c99df480  push rax
00007dd8c99df481  push rcx
00007dd8c99df482  push rdx
00007dd8c99df483  push rdi
00007dd8c99df484  push rsi
00007dd8c99df485  push r8
00007dd8c99df487  push r9
00007dd8c99df489  push r10
00007dd8c99df48b  push r11
00007dd8c99df48d  sub rsp, 0xF0
00007dd8c99df494  vmovaps [rsp], xmm0
00007dd8c99df499  vmovaps [rsp+0x10], xmm1
00007dd8c99df49f  vmovaps [rsp+0x20], xmm2
00007dd8c99df4a5  vmovaps [rsp+0x30], xmm3
00007dd8c99df4ab  vmovaps [rsp+0x40], xmm4
00007dd8c99df4b1  vmovaps [rsp+0x50], xmm5
00007dd8c99df4b7  vmovaps [rsp+0x60], xmm7
00007dd8c99df4bd  vmovaps [rsp+0x70], xmm8
00007dd8c99df4c3  vmovaps [rsp+0x80], xmm9
00007dd8c99df4cc  vmovaps [rsp+0x90], xmm10
00007dd8c99df4d5  vmovaps [rsp+0xA0], xmm11
00007dd8c99df4de  vmovaps [rsp+0xB0], xmm12
00007dd8c99df4e7  vmovaps [rsp+0xC0], xmm13
00007dd8c99df4f0  vmovaps [rsp+0xD0], xmm14
00007dd8c99df4f9  vmovaps [rsp+0xE0], xmm15
00007dd8c99df502  sub rsp, 0x30
00007dd8c99df506  movaps [rsp], xmm6
00007dd8c99df50a  movaps [rsp+0x10], xmm10
00007dd8c99df510  movaps [rsp+0x20], xmm8
00007dd8c99df516  lea rdi, [rsp]
00007dd8c99df51a  mov esi, 0x00
00007dd8c99df51f  mov rax, 0x55FEBBDB5530
00007dd8c99df529  call rax
00007dd8c99df52b  movaps xmm6, [rsp]
00007dd8c99df52f  add rsp, 0x30
00007dd8c99df533  vmovaps xmm0, [rsp]
00007dd8c99df538  vmovaps xmm1, [rsp+0x10]
00007dd8c99df53e  vmovaps xmm2, [rsp+0x20]
00007dd8c99df544  vmovaps xmm3, [rsp+0x30]
00007dd8c99df54a  vmovaps xmm4, [rsp+0x40]
00007dd8c99df550  vmovaps xmm5, [rsp+0x50]
00007dd8c99df556  vmovaps xmm7, [rsp+0x60]
00007dd8c99df55c  vmovaps xmm8, [rsp+0x70]
00007dd8c99df562  vmovaps xmm9, [rsp+0x80]
00007dd8c99df56b  vmovaps xmm10, [rsp+0x90]
00007dd8c99df574  vmovaps xmm11, [rsp+0xA0]
00007dd8c99df57d  vmovaps xmm12, [rsp+0xB0]
00007dd8c99df586  vmovaps xmm13, [rsp+0xC0]
00007dd8c99df58f  vmovaps xmm14, [rsp+0xD0]
00007dd8c99df598  vmovaps xmm15, [rsp+0xE0]
00007dd8c99df5a1  add rsp, 0xF0
00007dd8c99df5a8  pop r11
00007dd8c99df5aa  pop r10
00007dd8c99df5ac  pop r9
00007dd8c99df5ae  pop r8
00007dd8c99df5b0  pop rsi
00007dd8c99df5b1  pop rdi
00007dd8c99df5b2  pop rdx
00007dd8c99df5b3  pop rcx
00007dd8c99df5b4  pop rax
00007dd8c99df5b5  add rsp, 0x08
00007dd8c99df5b9  jmp 0x00007DD8C99DC3D8
00007dd8c99df5be  sub rsp, 0x08
00007dd8c99df5c2  push rax
00007dd8c99df5c3  push rcx
00007dd8c99df5c4  push rdx
00007dd8c99df5c5  push rdi
00007dd8c99df5c6  push rsi
00007dd8c99df5c7  push r8
00007dd8c99df5c9  push r9
00007dd8c99df5cb  push r10
00007dd8c99df5cd  push r11
00007dd8c99df5cf  sub rsp, 0xF0
00007dd8c99df5d6  vmovaps [rsp], xmm0
00007dd8c99df5db  vmovaps [rsp+0x10], xmm1
00007dd8c99df5e1  vmovaps [rsp+0x20], xmm2
00007dd8c99df5e7  vmovaps [rsp+0x30], xmm3
00007dd8c99df5ed  vmovaps [rsp+0x40], xmm4
00007dd8c99df5f3  vmovaps [rsp+0x50], xmm5
00007dd8c99df5f9  vmovaps [rsp+0x60], xmm6
00007dd8c99df5ff  vmovaps [rsp+0x70], xmm7
00007dd8c99df605  vmovaps [rsp+0x80], xmm8
00007dd8c99df60e  vmovaps [rsp+0x90], xmm9
00007dd8c99df617  vmovaps [rsp+0xA0], xmm11
00007dd8c99df620  vmovaps [rsp+0xB0], xmm12
00007dd8c99df629  vmovaps [rsp+0xC0], xmm13
00007dd8c99df632  vmovaps [rsp+0xD0], xmm14
00007dd8c99df63b  vmovaps [rsp+0xE0], xmm15
00007dd8c99df644  sub rsp, 0x30
00007dd8c99df648  movaps [rsp], xmm10
00007dd8c99df64d  movaps [rsp+0x10], xmm8
00007dd8c99df653  movaps [rsp+0x20], xmm14
00007dd8c99df659  lea rdi, [rsp]
00007dd8c99df65d  mov esi, 0x00
00007dd8c99df662  mov rax, 0x55FEBBDB5530
00007dd8c99df66c  call rax
00007dd8c99df66e  movaps xmm10, [rsp]
00007dd8c99df673  add rsp, 0x30
00007dd8c99df677  vmovaps xmm0, [rsp]
00007dd8c99df67c  vmovaps xmm1, [rsp+0x10]
00007dd8c99df682  vmovaps xmm2, [rsp+0x20]
00007dd8c99df688  vmovaps xmm3, [rsp+0x30]
00007dd8c99df68e  vmovaps xmm4, [rsp+0x40]
00007dd8c99df694  vmovaps xmm5, [rsp+0x50]
00007dd8c99df69a  vmovaps xmm6, [rsp+0x60]
00007dd8c99df6a0  vmovaps xmm7, [rsp+0x70]
00007dd8c99df6a6  vmovaps xmm8, [rsp+0x80]
00007dd8c99df6af  vmovaps xmm9, [rsp+0x90]
00007dd8c99df6b8  vmovaps xmm11, [rsp+0xA0]
00007dd8c99df6c1  vmovaps xmm12, [rsp+0xB0]
00007dd8c99df6ca  vmovaps xmm13, [rsp+0xC0]
00007dd8c99df6d3  vmovaps xmm14, [rsp+0xD0]
00007dd8c99df6dc  vmovaps xmm15, [rsp+0xE0]
00007dd8c99df6e5  add rsp, 0xF0
00007dd8c99df6ec  pop r11
00007dd8c99df6ee  pop r10
00007dd8c99df6f0  pop r9
00007dd8c99df6f2  pop r8
00007dd8c99df6f4  pop rsi
00007dd8c99df6f5  pop rdi
00007dd8c99df6f6  pop rdx
00007dd8c99df6f7  pop rcx
00007dd8c99df6f8  pop rax
00007dd8c99df6f9  add rsp, 0x08
00007dd8c99df6fd  jmp 0x00007DD8C99DC3F8
00007dd8c99df702  sub rsp, 0x08
00007dd8c99df706  push rax
00007dd8c99df707  push rcx
00007dd8c99df708  push rdx
00007dd8c99df709  push rdi
00007dd8c99df70a  push rsi
00007dd8c99df70b  push r8
00007dd8c99df70d  push r9
00007dd8c99df70f  push r10
00007dd8c99df711  push r11
00007dd8c99df713  sub rsp, 0xF0
00007dd8c99df71a  vmovaps [rsp], xmm0
00007dd8c99df71f  vmovaps [rsp+0x10], xmm1
00007dd8c99df725  vmovaps [rsp+0x20], xmm2
00007dd8c99df72b  vmovaps [rsp+0x30], xmm3
00007dd8c99df731  vmovaps [rsp+0x40], xmm4
00007dd8c99df737  vmovaps [rsp+0x50], xmm5
00007dd8c99df73d  vmovaps [rsp+0x60], xmm6
00007dd8c99df743  vmovaps [rsp+0x70], xmm7
00007dd8c99df749  vmovaps [rsp+0x80], xmm8
00007dd8c99df752  vmovaps [rsp+0x90], xmm9
00007dd8c99df75b  vmovaps [rsp+0xA0], xmm10
00007dd8c99df764  vmovaps [rsp+0xB0], xmm11
00007dd8c99df76d  vmovaps [rsp+0xC0], xmm12
00007dd8c99df776  vmovaps [rsp+0xD0], xmm13
00007dd8c99df77f  vmovaps [rsp+0xE0], xmm15
00007dd8c99df788  sub rsp, 0x30
00007dd8c99df78c  movaps [rsp], xmm14
00007dd8c99df791  movaps [rsp+0x10], xmm8
00007dd8c99df797  movaps [rsp+0x20], xmm4
00007dd8c99df79c  lea rdi, [rsp]
00007dd8c99df7a0  mov esi, 0x00
00007dd8c99df7a5  mov rax, 0x55FEBBDB5530
00007dd8c99df7af  call rax
00007dd8c99df7b1  movaps xmm14, [rsp]
00007dd8c99df7b6  add rsp, 0x30
00007dd8c99df7ba  vmovaps xmm0, [rsp]
00007dd8c99df7bf  vmovaps xmm1, [rsp+0x10]
00007dd8c99df7c5  vmovaps xmm2, [rsp+0x20]
00007dd8c99df7cb  vmovaps xmm3, [rsp+0x30]
00007dd8c99df7d1  vmovaps xmm4, [rsp+0x40]
00007dd8c99df7d7  vmovaps xmm5, [rsp+0x50]
00007dd8c99df7dd  vmovaps xmm6, [rsp+0x60]
00007dd8c99df7e3  vmovaps xmm7, [rsp+0x70]
00007dd8c99df7e9  vmovaps xmm8, [rsp+0x80]
00007dd8c99df7f2  vmovaps xmm9, [rsp+0x90]
00007dd8c99df7fb  vmovaps xmm10, [rsp+0xA0]
00007dd8c99df804  vmovaps xmm11, [rsp+0xB0]
00007dd8c99df80d  vmovaps xmm12, [rsp+0xC0]
00007dd8c99df816  vmovaps xmm13, [rsp+0xD0]
00007dd8c99df81f  vmovaps xmm15, [rsp+0xE0]
00007dd8c99df828  add rsp, 0xF0
00007dd8c99df82f  pop r11
00007dd8c99df831  pop r10
00007dd8c99df833  pop r9
00007dd8c99df835  pop r8
00007dd8c99df837  pop rsi
00007dd8c99df838  pop rdi
00007dd8c99df839  pop rdx
00007dd8c99df83a  pop rcx
00007dd8c99df83b  pop rax
00007dd8c99df83c  add rsp, 0x08
00007dd8c99df840  jmp 0x00007DD8C99DC418
00007dd8c99df845  sub rsp, 0x08
00007dd8c99df849  push rax
00007dd8c99df84a  push rcx
00007dd8c99df84b  push rdx
00007dd8c99df84c  push rdi
00007dd8c99df84d  push rsi
00007dd8c99df84e  push r8
00007dd8c99df850  push r9
00007dd8c99df852  push r10
00007dd8c99df854  push r11
00007dd8c99df856  sub rsp, 0xF0
00007dd8c99df85d  vmovaps [rsp], xmm0
00007dd8c99df862  vmovaps [rsp+0x10], xmm1
00007dd8c99df868  vmovaps [rsp+0x20], xmm2
00007dd8c99df86e  vmovaps [rsp+0x30], xmm3
00007dd8c99df874  vmovaps [rsp+0x40], xmm5
00007dd8c99df87a  vmovaps [rsp+0x50], xmm6
00007dd8c99df880  vmovaps [rsp+0x60], xmm7
00007dd8c99df886  vmovaps [rsp+0x70], xmm8
00007dd8c99df88c  vmovaps [rsp+0x80], xmm9
00007dd8c99df895  vmovaps [rsp+0x90], xmm10
00007dd8c99df89e  vmovaps [rsp+0xA0], xmm11
00007dd8c99df8a7  vmovaps [rsp+0xB0], xmm12
00007dd8c99df8b0  vmovaps [rsp+0xC0], xmm13
00007dd8c99df8b9  vmovaps [rsp+0xD0], xmm14
00007dd8c99df8c2  vmovaps [rsp+0xE0], xmm15
00007dd8c99df8cb  sub rsp, 0x30
00007dd8c99df8cf  movaps [rsp], xmm4
00007dd8c99df8d3  movaps [rsp+0x10], xmm13
00007dd8c99df8d9  movaps [rsp+0x20], xmm8
00007dd8c99df8df  lea rdi, [rsp]
00007dd8c99df8e3  mov esi, 0x00
00007dd8c99df8e8  mov rax, 0x55FEBBDB5530
00007dd8c99df8f2  call rax
00007dd8c99df8f4  movaps xmm4, [rsp]
00007dd8c99df8f8  add rsp, 0x30
00007dd8c99df8fc  vmovaps xmm0, [rsp]
00007dd8c99df901  vmovaps xmm1, [rsp+0x10]
00007dd8c99df907  vmovaps xmm2, [rsp+0x20]
00007dd8c99df90d  vmovaps xmm3, [rsp+0x30]
00007dd8c99df913  vmovaps xmm5, [rsp+0x40]
00007dd8c99df919  vmovaps xmm6, [rsp+0x50]
00007dd8c99df91f  vmovaps xmm7, [rsp+0x60]
00007dd8c99df925  vmovaps xmm8, [rsp+0x70]
00007dd8c99df92b  vmovaps xmm9, [rsp+0x80]
00007dd8c99df934  vmovaps xmm10, [rsp+0x90]
00007dd8c99df93d  vmovaps xmm11, [rsp+0xA0]
00007dd8c99df946  vmovaps xmm12, [rsp+0xB0]
00007dd8c99df94f  vmovaps xmm13, [rsp+0xC0]
00007dd8c99df958  vmovaps xmm14, [rsp+0xD0]
00007dd8c99df961  vmovaps xmm15, [rsp+0xE0]
00007dd8c99df96a  add rsp, 0xF0
00007dd8c99df971  pop r11
00007dd8c99df973  pop r10
00007dd8c99df975  pop r9
00007dd8c99df977  pop r8
00007dd8c99df979  pop rsi
00007dd8c99df97a  pop rdi
00007dd8c99df97b  pop rdx
00007dd8c99df97c  pop rcx
00007dd8c99df97d  pop rax
00007dd8c99df97e  add rsp, 0x08
00007dd8c99df982  jmp 0x00007DD8C99DC43D
00007dd8c99df987  sub rsp, 0x08
00007dd8c99df98b  push rax
00007dd8c99df98c  push rcx
00007dd8c99df98d  push rdx
00007dd8c99df98e  push rdi
00007dd8c99df98f  push rsi
00007dd8c99df990  push r8
00007dd8c99df992  push r9
00007dd8c99df994  push r10
00007dd8c99df996  push r11
00007dd8c99df998  sub rsp, 0xF0
00007dd8c99df99f  vmovaps [rsp], xmm0
00007dd8c99df9a4  vmovaps [rsp+0x10], xmm1
00007dd8c99df9aa  vmovaps [rsp+0x20], xmm2
00007dd8c99df9b0  vmovaps [rsp+0x30], xmm3
00007dd8c99df9b6  vmovaps [rsp+0x40], xmm4
00007dd8c99df9bc  vmovaps [rsp+0x50], xmm5
00007dd8c99df9c2  vmovaps [rsp+0x60], xmm6
00007dd8c99df9c8  vmovaps [rsp+0x70], xmm7
00007dd8c99df9ce  vmovaps [rsp+0x80], xmm8
00007dd8c99df9d7  vmovaps [rsp+0x90], xmm9
00007dd8c99df9e0  vmovaps [rsp+0xA0], xmm10
00007dd8c99df9e9  vmovaps [rsp+0xB0], xmm11
00007dd8c99df9f2  vmovaps [rsp+0xC0], xmm12
00007dd8c99df9fb  vmovaps [rsp+0xD0], xmm14
00007dd8c99dfa04  vmovaps [rsp+0xE0], xmm15
00007dd8c99dfa0d  sub rsp, 0x30
00007dd8c99dfa11  movaps [rsp], xmm13
00007dd8c99dfa16  movaps [rsp+0x10], xmm15
00007dd8c99dfa1c  movaps [rsp+0x20], xmm9
00007dd8c99dfa22  lea rdi, [rsp]
00007dd8c99dfa26  mov esi, 0x00
00007dd8c99dfa2b  mov rax, 0x55FEBBDB5530
00007dd8c99dfa35  call rax
00007dd8c99dfa37  movaps xmm13, [rsp]
00007dd8c99dfa3c  add rsp, 0x30
00007dd8c99dfa40  vmovaps xmm0, [rsp]
00007dd8c99dfa45  vmovaps xmm1, [rsp+0x10]
00007dd8c99dfa4b  vmovaps xmm2, [rsp+0x20]
00007dd8c99dfa51  vmovaps xmm3, [rsp+0x30]
00007dd8c99dfa57  vmovaps xmm4, [rsp+0x40]
00007dd8c99dfa5d  vmovaps xmm5, [rsp+0x50]
00007dd8c99dfa63  vmovaps xmm6, [rsp+0x60]
00007dd8c99dfa69  vmovaps xmm7, [rsp+0x70]
00007dd8c99dfa6f  vmovaps xmm8, [rsp+0x80]
00007dd8c99dfa78  vmovaps xmm9, [rsp+0x90]
00007dd8c99dfa81  vmovaps xmm10, [rsp+0xA0]
00007dd8c99dfa8a  vmovaps xmm11, [rsp+0xB0]
00007dd8c99dfa93  vmovaps xmm12, [rsp+0xC0]
00007dd8c99dfa9c  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dfaa5  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dfaae  add rsp, 0xF0
00007dd8c99dfab5  pop r11
00007dd8c99dfab7  pop r10
00007dd8c99dfab9  pop r9
00007dd8c99dfabb  pop r8
00007dd8c99dfabd  pop rsi
00007dd8c99dfabe  pop rdi
00007dd8c99dfabf  pop rdx
00007dd8c99dfac0  pop rcx
00007dd8c99dfac1  pop rax
00007dd8c99dfac2  add rsp, 0x08
00007dd8c99dfac6  jmp 0x00007DD8C99DC458
00007dd8c99dfacb  sub rsp, 0x08
00007dd8c99dfacf  push rax
00007dd8c99dfad0  push rcx
00007dd8c99dfad1  push rdx
00007dd8c99dfad2  push rdi
00007dd8c99dfad3  push rsi
00007dd8c99dfad4  push r8
00007dd8c99dfad6  push r9
00007dd8c99dfad8  push r10
00007dd8c99dfada  push r11
00007dd8c99dfadc  sub rsp, 0xF0
00007dd8c99dfae3  vmovaps [rsp], xmm0
00007dd8c99dfae8  vmovaps [rsp+0x10], xmm1
00007dd8c99dfaee  vmovaps [rsp+0x20], xmm2
00007dd8c99dfaf4  vmovaps [rsp+0x30], xmm3
00007dd8c99dfafa  vmovaps [rsp+0x40], xmm4
00007dd8c99dfb00  vmovaps [rsp+0x50], xmm5
00007dd8c99dfb06  vmovaps [rsp+0x60], xmm6
00007dd8c99dfb0c  vmovaps [rsp+0x70], xmm7
00007dd8c99dfb12  vmovaps [rsp+0x80], xmm8
00007dd8c99dfb1b  vmovaps [rsp+0x90], xmm9
00007dd8c99dfb24  vmovaps [rsp+0xA0], xmm10
00007dd8c99dfb2d  vmovaps [rsp+0xB0], xmm11
00007dd8c99dfb36  vmovaps [rsp+0xC0], xmm12
00007dd8c99dfb3f  vmovaps [rsp+0xD0], xmm13
00007dd8c99dfb48  vmovaps [rsp+0xE0], xmm14
00007dd8c99dfb51  sub rsp, 0x30
00007dd8c99dfb55  movaps [rsp], xmm15
00007dd8c99dfb5a  movaps [rsp+0x10], xmm1
00007dd8c99dfb5f  movaps [rsp+0x20], xmm5
00007dd8c99dfb64  lea rdi, [rsp]
00007dd8c99dfb68  mov esi, 0x00
00007dd8c99dfb6d  mov rax, 0x55FEBBDB5530
00007dd8c99dfb77  call rax
00007dd8c99dfb79  movaps xmm15, [rsp]
00007dd8c99dfb7e  add rsp, 0x30
00007dd8c99dfb82  vmovaps xmm0, [rsp]
00007dd8c99dfb87  vmovaps xmm1, [rsp+0x10]
00007dd8c99dfb8d  vmovaps xmm2, [rsp+0x20]
00007dd8c99dfb93  vmovaps xmm3, [rsp+0x30]
00007dd8c99dfb99  vmovaps xmm4, [rsp+0x40]
00007dd8c99dfb9f  vmovaps xmm5, [rsp+0x50]
00007dd8c99dfba5  vmovaps xmm6, [rsp+0x60]
00007dd8c99dfbab  vmovaps xmm7, [rsp+0x70]
00007dd8c99dfbb1  vmovaps xmm8, [rsp+0x80]
00007dd8c99dfbba  vmovaps xmm9, [rsp+0x90]
00007dd8c99dfbc3  vmovaps xmm10, [rsp+0xA0]
00007dd8c99dfbcc  vmovaps xmm11, [rsp+0xB0]
00007dd8c99dfbd5  vmovaps xmm12, [rsp+0xC0]
00007dd8c99dfbde  vmovaps xmm13, [rsp+0xD0]
00007dd8c99dfbe7  vmovaps xmm14, [rsp+0xE0]
00007dd8c99dfbf0  add rsp, 0xF0
00007dd8c99dfbf7  pop r11
00007dd8c99dfbf9  pop r10
00007dd8c99dfbfb  pop r9
00007dd8c99dfbfd  pop r8
00007dd8c99dfbff  pop rsi
00007dd8c99dfc00  pop rdi
00007dd8c99dfc01  pop rdx
00007dd8c99dfc02  pop rcx
00007dd8c99dfc03  pop rax
00007dd8c99dfc04  add rsp, 0x08
00007dd8c99dfc08  jmp 0x00007DD8C99DC473
00007dd8c99dfc0d  call 0x00007DD8C98B52F0
00007dd8c99dfc12  jmp 0x00007DD8C99DC4CE
00007dd8c99dfc17  sub rsp, 0x08
00007dd8c99dfc1b  push rax
00007dd8c99dfc1c  push rcx
00007dd8c99dfc1d  push rdx
00007dd8c99dfc1e  push rdi
00007dd8c99dfc1f  push rsi
00007dd8c99dfc20  push r8
00007dd8c99dfc22  push r9
00007dd8c99dfc24  push r10
00007dd8c99dfc26  push r11
00007dd8c99dfc28  sub rsp, 0xF0
00007dd8c99dfc2f  vmovaps [rsp], xmm0
00007dd8c99dfc34  vmovaps [rsp+0x10], xmm1
00007dd8c99dfc3a  vmovaps [rsp+0x20], xmm2
00007dd8c99dfc40  vmovaps [rsp+0x30], xmm3
00007dd8c99dfc46  vmovaps [rsp+0x40], xmm4
00007dd8c99dfc4c  vmovaps [rsp+0x50], xmm5
00007dd8c99dfc52  vmovaps [rsp+0x60], xmm6
00007dd8c99dfc58  vmovaps [rsp+0x70], xmm7
00007dd8c99dfc5e  vmovaps [rsp+0x80], xmm8
00007dd8c99dfc67  vmovaps [rsp+0x90], xmm10
00007dd8c99dfc70  vmovaps [rsp+0xA0], xmm11
00007dd8c99dfc79  vmovaps [rsp+0xB0], xmm12
00007dd8c99dfc82  vmovaps [rsp+0xC0], xmm13
00007dd8c99dfc8b  vmovaps [rsp+0xD0], xmm14
00007dd8c99dfc94  vmovaps [rsp+0xE0], xmm15
00007dd8c99dfc9d  sub rsp, 0x30
00007dd8c99dfca1  movaps [rsp], xmm9
00007dd8c99dfca6  movaps [rsp+0x10], xmm8
00007dd8c99dfcac  movaps [rsp+0x20], xmm11
00007dd8c99dfcb2  lea rdi, [rsp]
00007dd8c99dfcb6  mov esi, 0x00
00007dd8c99dfcbb  mov rax, 0x55FEBBDB5530
00007dd8c99dfcc5  call rax
00007dd8c99dfcc7  movaps xmm9, [rsp]
00007dd8c99dfccc  add rsp, 0x30
00007dd8c99dfcd0  vmovaps xmm0, [rsp]
00007dd8c99dfcd5  vmovaps xmm1, [rsp+0x10]
00007dd8c99dfcdb  vmovaps xmm2, [rsp+0x20]
00007dd8c99dfce1  vmovaps xmm3, [rsp+0x30]
00007dd8c99dfce7  vmovaps xmm4, [rsp+0x40]
00007dd8c99dfced  vmovaps xmm5, [rsp+0x50]
00007dd8c99dfcf3  vmovaps xmm6, [rsp+0x60]
00007dd8c99dfcf9  vmovaps xmm7, [rsp+0x70]
00007dd8c99dfcff  vmovaps xmm8, [rsp+0x80]
00007dd8c99dfd08  vmovaps xmm10, [rsp+0x90]
00007dd8c99dfd11  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dfd1a  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dfd23  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dfd2c  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dfd35  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dfd3e  add rsp, 0xF0
00007dd8c99dfd45  pop r11
00007dd8c99dfd47  pop r10
00007dd8c99dfd49  pop r9
00007dd8c99dfd4b  pop r8
00007dd8c99dfd4d  pop rsi
00007dd8c99dfd4e  pop rdi
00007dd8c99dfd4f  pop rdx
00007dd8c99dfd50  pop rcx
00007dd8c99dfd51  pop rax
00007dd8c99dfd52  add rsp, 0x08
00007dd8c99dfd56  jmp 0x00007DD8C99DC505
00007dd8c99dfd5b  sub rsp, 0x08
00007dd8c99dfd5f  push rax
00007dd8c99dfd60  push rcx
00007dd8c99dfd61  push rdx
00007dd8c99dfd62  push rdi
00007dd8c99dfd63  push rsi
00007dd8c99dfd64  push r8
00007dd8c99dfd66  push r9
00007dd8c99dfd68  push r10
00007dd8c99dfd6a  push r11
00007dd8c99dfd6c  sub rsp, 0xF0
00007dd8c99dfd73  vmovaps [rsp], xmm0
00007dd8c99dfd78  vmovaps [rsp+0x10], xmm1
00007dd8c99dfd7e  vmovaps [rsp+0x20], xmm2
00007dd8c99dfd84  vmovaps [rsp+0x30], xmm3
00007dd8c99dfd8a  vmovaps [rsp+0x40], xmm4
00007dd8c99dfd90  vmovaps [rsp+0x50], xmm5
00007dd8c99dfd96  vmovaps [rsp+0x60], xmm6
00007dd8c99dfd9c  vmovaps [rsp+0x70], xmm7
00007dd8c99dfda2  vmovaps [rsp+0x80], xmm8
00007dd8c99dfdab  vmovaps [rsp+0x90], xmm9
00007dd8c99dfdb4  vmovaps [rsp+0xA0], xmm10
00007dd8c99dfdbd  vmovaps [rsp+0xB0], xmm12
00007dd8c99dfdc6  vmovaps [rsp+0xC0], xmm13
00007dd8c99dfdcf  vmovaps [rsp+0xD0], xmm14
00007dd8c99dfdd8  vmovaps [rsp+0xE0], xmm15
00007dd8c99dfde1  sub rsp, 0x30
00007dd8c99dfde5  movaps [rsp], xmm11
00007dd8c99dfdea  movaps [rsp+0x10], xmm10
00007dd8c99dfdf0  movaps [rsp+0x20], xmm6
00007dd8c99dfdf5  lea rdi, [rsp]
00007dd8c99dfdf9  mov esi, 0x00
00007dd8c99dfdfe  mov rax, 0x55FEBBDB5530
00007dd8c99dfe08  call rax
00007dd8c99dfe0a  movaps xmm11, [rsp]
00007dd8c99dfe0f  add rsp, 0x30
00007dd8c99dfe13  vmovaps xmm0, [rsp]
00007dd8c99dfe18  vmovaps xmm1, [rsp+0x10]
00007dd8c99dfe1e  vmovaps xmm2, [rsp+0x20]
00007dd8c99dfe24  vmovaps xmm3, [rsp+0x30]
00007dd8c99dfe2a  vmovaps xmm4, [rsp+0x40]
00007dd8c99dfe30  vmovaps xmm5, [rsp+0x50]
00007dd8c99dfe36  vmovaps xmm6, [rsp+0x60]
00007dd8c99dfe3c  vmovaps xmm7, [rsp+0x70]
00007dd8c99dfe42  vmovaps xmm8, [rsp+0x80]
00007dd8c99dfe4b  vmovaps xmm9, [rsp+0x90]
00007dd8c99dfe54  vmovaps xmm10, [rsp+0xA0]
00007dd8c99dfe5d  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dfe66  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dfe6f  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dfe78  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dfe81  add rsp, 0xF0
00007dd8c99dfe88  pop r11
00007dd8c99dfe8a  pop r10
00007dd8c99dfe8c  pop r9
00007dd8c99dfe8e  pop r8
00007dd8c99dfe90  pop rsi
00007dd8c99dfe91  pop rdi
00007dd8c99dfe92  pop rdx
00007dd8c99dfe93  pop rcx
00007dd8c99dfe94  pop rax
00007dd8c99dfe95  add rsp, 0x08
00007dd8c99dfe99  jmp 0x00007DD8C99DC520
00007dd8c99dfe9e  sub rsp, 0x08
00007dd8c99dfea2  push rax
00007dd8c99dfea3  push rcx
00007dd8c99dfea4  push rdx
00007dd8c99dfea5  push rdi
00007dd8c99dfea6  push rsi
00007dd8c99dfea7  push r8
00007dd8c99dfea9  push r9
00007dd8c99dfeab  push r10
00007dd8c99dfead  push r11
00007dd8c99dfeaf  sub rsp, 0xF0
00007dd8c99dfeb6  vmovaps [rsp], xmm0
00007dd8c99dfebb  vmovaps [rsp+0x10], xmm1
00007dd8c99dfec1  vmovaps [rsp+0x20], xmm2
00007dd8c99dfec7  vmovaps [rsp+0x30], xmm3
00007dd8c99dfecd  vmovaps [rsp+0x40], xmm4
00007dd8c99dfed3  vmovaps [rsp+0x50], xmm5
00007dd8c99dfed9  vmovaps [rsp+0x60], xmm6
00007dd8c99dfedf  vmovaps [rsp+0x70], xmm7
00007dd8c99dfee5  vmovaps [rsp+0x80], xmm8
00007dd8c99dfeee  vmovaps [rsp+0x90], xmm9
00007dd8c99dfef7  vmovaps [rsp+0xA0], xmm11
00007dd8c99dff00  vmovaps [rsp+0xB0], xmm12
00007dd8c99dff09  vmovaps [rsp+0xC0], xmm13
00007dd8c99dff12  vmovaps [rsp+0xD0], xmm14
00007dd8c99dff1b  vmovaps [rsp+0xE0], xmm15
00007dd8c99dff24  sub rsp, 0x30
00007dd8c99dff28  movaps [rsp], xmm10
00007dd8c99dff2d  movaps [rsp+0x10], xmm14
00007dd8c99dff33  movaps [rsp+0x20], xmm4
00007dd8c99dff38  lea rdi, [rsp]
00007dd8c99dff3c  mov esi, 0x00
00007dd8c99dff41  mov rax, 0x55FEBBDB5530
00007dd8c99dff4b  call rax
00007dd8c99dff4d  movaps xmm10, [rsp]
00007dd8c99dff52  add rsp, 0x30
00007dd8c99dff56  vmovaps xmm0, [rsp]
00007dd8c99dff5b  vmovaps xmm1, [rsp+0x10]
00007dd8c99dff61  vmovaps xmm2, [rsp+0x20]
00007dd8c99dff67  vmovaps xmm3, [rsp+0x30]
00007dd8c99dff6d  vmovaps xmm4, [rsp+0x40]
00007dd8c99dff73  vmovaps xmm5, [rsp+0x50]
00007dd8c99dff79  vmovaps xmm6, [rsp+0x60]
00007dd8c99dff7f  vmovaps xmm7, [rsp+0x70]
00007dd8c99dff85  vmovaps xmm8, [rsp+0x80]
00007dd8c99dff8e  vmovaps xmm9, [rsp+0x90]
00007dd8c99dff97  vmovaps xmm11, [rsp+0xA0]
00007dd8c99dffa0  vmovaps xmm12, [rsp+0xB0]
00007dd8c99dffa9  vmovaps xmm13, [rsp+0xC0]
00007dd8c99dffb2  vmovaps xmm14, [rsp+0xD0]
00007dd8c99dffbb  vmovaps xmm15, [rsp+0xE0]
00007dd8c99dffc4  add rsp, 0xF0
00007dd8c99dffcb  pop r11
00007dd8c99dffcd  pop r10
00007dd8c99dffcf  pop r9
00007dd8c99dffd1  pop r8
00007dd8c99dffd3  pop rsi
00007dd8c99dffd4  pop rdi
00007dd8c99dffd5  pop rdx
00007dd8c99dffd6  pop rcx
00007dd8c99dffd7  pop rax
00007dd8c99dffd8  add rsp, 0x08
00007dd8c99dffdc  jmp 0x00007DD8C99DC53B
00007dd8c99dffe1  sub rsp, 0x08
00007dd8c99dffe5  push rax
00007dd8c99dffe6  push rcx
00007dd8c99dffe7  push rdx
00007dd8c99dffe8  push rdi
00007dd8c99dffe9  push rsi
00007dd8c99dffea  push r8
00007dd8c99dffec  push r9
00007dd8c99dffee  push r10
00007dd8c99dfff0  push r11
00007dd8c99dfff2  sub rsp, 0xF0
00007dd8c99dfff9  vmovaps [rsp], xmm0
00007dd8c99dfffe  vmovaps [rsp+0x10], xmm1
00007dd8c99e0004  vmovaps [rsp+0x20], xmm2
00007dd8c99e000a  vmovaps [rsp+0x30], xmm3
00007dd8c99e0010  vmovaps [rsp+0x40], xmm4
00007dd8c99e0016  vmovaps [rsp+0x50], xmm5
00007dd8c99e001c  vmovaps [rsp+0x60], xmm6
00007dd8c99e0022  vmovaps [rsp+0x70], xmm7
00007dd8c99e0028  vmovaps [rsp+0x80], xmm9
00007dd8c99e0031  vmovaps [rsp+0x90], xmm10
00007dd8c99e003a  vmovaps [rsp+0xA0], xmm11
00007dd8c99e0043  vmovaps [rsp+0xB0], xmm12
00007dd8c99e004c  vmovaps [rsp+0xC0], xmm13
00007dd8c99e0055  vmovaps [rsp+0xD0], xmm14
00007dd8c99e005e  vmovaps [rsp+0xE0], xmm15
00007dd8c99e0067  sub rsp, 0x30
00007dd8c99e006b  movaps [rsp], xmm8
00007dd8c99e0070  movaps [rsp+0x10], xmm1
00007dd8c99e0075  movaps [rsp+0x20], xmm14
00007dd8c99e007b  lea rdi, [rsp]
00007dd8c99e007f  mov esi, 0x00
00007dd8c99e0084  mov rax, 0x55FEBBDB5530
00007dd8c99e008e  call rax
00007dd8c99e0090  movaps xmm8, [rsp]
00007dd8c99e0095  add rsp, 0x30
00007dd8c99e0099  vmovaps xmm0, [rsp]
00007dd8c99e009e  vmovaps xmm1, [rsp+0x10]
00007dd8c99e00a4  vmovaps xmm2, [rsp+0x20]
00007dd8c99e00aa  vmovaps xmm3, [rsp+0x30]
00007dd8c99e00b0  vmovaps xmm4, [rsp+0x40]
00007dd8c99e00b6  vmovaps xmm5, [rsp+0x50]
00007dd8c99e00bc  vmovaps xmm6, [rsp+0x60]
00007dd8c99e00c2  vmovaps xmm7, [rsp+0x70]
00007dd8c99e00c8  vmovaps xmm9, [rsp+0x80]
00007dd8c99e00d1  vmovaps xmm10, [rsp+0x90]
00007dd8c99e00da  vmovaps xmm11, [rsp+0xA0]
00007dd8c99e00e3  vmovaps xmm12, [rsp+0xB0]
00007dd8c99e00ec  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e00f5  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e00fe  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e0107  add rsp, 0xF0
00007dd8c99e010e  pop r11
00007dd8c99e0110  pop r10
00007dd8c99e0112  pop r9
00007dd8c99e0114  pop r8
00007dd8c99e0116  pop rsi
00007dd8c99e0117  pop rdi
00007dd8c99e0118  pop rdx
00007dd8c99e0119  pop rcx
00007dd8c99e011a  pop rax
00007dd8c99e011b  add rsp, 0x08
00007dd8c99e011f  jmp 0x00007DD8C99DC561
00007dd8c99e0124  sub rsp, 0x08
00007dd8c99e0128  push rax
00007dd8c99e0129  push rcx
00007dd8c99e012a  push rdx
00007dd8c99e012b  push rdi
00007dd8c99e012c  push rsi
00007dd8c99e012d  push r8
00007dd8c99e012f  push r9
00007dd8c99e0131  push r10
00007dd8c99e0133  push r11
00007dd8c99e0135  sub rsp, 0xF0
00007dd8c99e013c  vmovaps [rsp], xmm0
00007dd8c99e0141  vmovaps [rsp+0x10], xmm1
00007dd8c99e0147  vmovaps [rsp+0x20], xmm2
00007dd8c99e014d  vmovaps [rsp+0x30], xmm3
00007dd8c99e0153  vmovaps [rsp+0x40], xmm4
00007dd8c99e0159  vmovaps [rsp+0x50], xmm5
00007dd8c99e015f  vmovaps [rsp+0x60], xmm7
00007dd8c99e0165  vmovaps [rsp+0x70], xmm8
00007dd8c99e016b  vmovaps [rsp+0x80], xmm9
00007dd8c99e0174  vmovaps [rsp+0x90], xmm10
00007dd8c99e017d  vmovaps [rsp+0xA0], xmm11
00007dd8c99e0186  vmovaps [rsp+0xB0], xmm12
00007dd8c99e018f  vmovaps [rsp+0xC0], xmm13
00007dd8c99e0198  vmovaps [rsp+0xD0], xmm14
00007dd8c99e01a1  vmovaps [rsp+0xE0], xmm15
00007dd8c99e01aa  sub rsp, 0x30
00007dd8c99e01ae  movaps [rsp], xmm6
00007dd8c99e01b2  movaps [rsp+0x10], xmm1
00007dd8c99e01b7  movaps [rsp+0x20], xmm14
00007dd8c99e01bd  lea rdi, [rsp]
00007dd8c99e01c1  mov esi, 0x00
00007dd8c99e01c6  mov rax, 0x55FEBBDB5530
00007dd8c99e01d0  call rax
00007dd8c99e01d2  movaps xmm6, [rsp]
00007dd8c99e01d6  add rsp, 0x30
00007dd8c99e01da  vmovaps xmm0, [rsp]
00007dd8c99e01df  vmovaps xmm1, [rsp+0x10]
00007dd8c99e01e5  vmovaps xmm2, [rsp+0x20]
00007dd8c99e01eb  vmovaps xmm3, [rsp+0x30]
00007dd8c99e01f1  vmovaps xmm4, [rsp+0x40]
00007dd8c99e01f7  vmovaps xmm5, [rsp+0x50]
00007dd8c99e01fd  vmovaps xmm7, [rsp+0x60]
00007dd8c99e0203  vmovaps xmm8, [rsp+0x70]
00007dd8c99e0209  vmovaps xmm9, [rsp+0x80]
00007dd8c99e0212  vmovaps xmm10, [rsp+0x90]
00007dd8c99e021b  vmovaps xmm11, [rsp+0xA0]
00007dd8c99e0224  vmovaps xmm12, [rsp+0xB0]
00007dd8c99e022d  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e0236  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e023f  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e0248  add rsp, 0xF0
00007dd8c99e024f  pop r11
00007dd8c99e0251  pop r10
00007dd8c99e0253  pop r9
00007dd8c99e0255  pop r8
00007dd8c99e0257  pop rsi
00007dd8c99e0258  pop rdi
00007dd8c99e0259  pop rdx
00007dd8c99e025a  pop rcx
00007dd8c99e025b  pop rax
00007dd8c99e025c  add rsp, 0x08
00007dd8c99e0260  jmp 0x00007DD8C99DC58D
00007dd8c99e0265  sub rsp, 0x08
00007dd8c99e0269  push rax
00007dd8c99e026a  push rcx
00007dd8c99e026b  push rdx
00007dd8c99e026c  push rdi
00007dd8c99e026d  push rsi
00007dd8c99e026e  push r8
00007dd8c99e0270  push r9
00007dd8c99e0272  push r10
00007dd8c99e0274  push r11
00007dd8c99e0276  sub rsp, 0xF0
00007dd8c99e027d  vmovaps [rsp], xmm0
00007dd8c99e0282  vmovaps [rsp+0x10], xmm1
00007dd8c99e0288  vmovaps [rsp+0x20], xmm2
00007dd8c99e028e  vmovaps [rsp+0x30], xmm3
00007dd8c99e0294  vmovaps [rsp+0x40], xmm4
00007dd8c99e029a  vmovaps [rsp+0x50], xmm5
00007dd8c99e02a0  vmovaps [rsp+0x60], xmm6
00007dd8c99e02a6  vmovaps [rsp+0x70], xmm7
00007dd8c99e02ac  vmovaps [rsp+0x80], xmm8
00007dd8c99e02b5  vmovaps [rsp+0x90], xmm9
00007dd8c99e02be  vmovaps [rsp+0xA0], xmm10
00007dd8c99e02c7  vmovaps [rsp+0xB0], xmm11
00007dd8c99e02d0  vmovaps [rsp+0xC0], xmm12
00007dd8c99e02d9  vmovaps [rsp+0xD0], xmm13
00007dd8c99e02e2  vmovaps [rsp+0xE0], xmm15
00007dd8c99e02eb  sub rsp, 0x30
00007dd8c99e02ef  movaps [rsp], xmm14
00007dd8c99e02f4  movaps [rsp+0x10], xmm12
00007dd8c99e02fa  movaps [rsp+0x20], xmm1
00007dd8c99e02ff  lea rdi, [rsp]
00007dd8c99e0303  mov esi, 0x00
00007dd8c99e0308  mov rax, 0x55FEBBDB5530
00007dd8c99e0312  call rax
00007dd8c99e0314  movaps xmm14, [rsp]
00007dd8c99e0319  add rsp, 0x30
00007dd8c99e031d  vmovaps xmm0, [rsp]
00007dd8c99e0322  vmovaps xmm1, [rsp+0x10]
00007dd8c99e0328  vmovaps xmm2, [rsp+0x20]
00007dd8c99e032e  vmovaps xmm3, [rsp+0x30]
00007dd8c99e0334  vmovaps xmm4, [rsp+0x40]
00007dd8c99e033a  vmovaps xmm5, [rsp+0x50]
00007dd8c99e0340  vmovaps xmm6, [rsp+0x60]
00007dd8c99e0346  vmovaps xmm7, [rsp+0x70]
00007dd8c99e034c  vmovaps xmm8, [rsp+0x80]
00007dd8c99e0355  vmovaps xmm9, [rsp+0x90]
00007dd8c99e035e  vmovaps xmm10, [rsp+0xA0]
00007dd8c99e0367  vmovaps xmm11, [rsp+0xB0]
00007dd8c99e0370  vmovaps xmm12, [rsp+0xC0]
00007dd8c99e0379  vmovaps xmm13, [rsp+0xD0]
00007dd8c99e0382  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e038b  add rsp, 0xF0
00007dd8c99e0392  pop r11
00007dd8c99e0394  pop r10
00007dd8c99e0396  pop r9
00007dd8c99e0398  pop r8
00007dd8c99e039a  pop rsi
00007dd8c99e039b  pop rdi
00007dd8c99e039c  pop rdx
00007dd8c99e039d  pop rcx
00007dd8c99e039e  pop rax
00007dd8c99e039f  add rsp, 0x08
00007dd8c99e03a3  jmp 0x00007DD8C99DC5B3
00007dd8c99e03a8  sub rsp, 0x08
00007dd8c99e03ac  push rax
00007dd8c99e03ad  push rcx
00007dd8c99e03ae  push rdx
00007dd8c99e03af  push rdi
00007dd8c99e03b0  push rsi
00007dd8c99e03b1  push r8
00007dd8c99e03b3  push r9
00007dd8c99e03b5  push r10
00007dd8c99e03b7  push r11
00007dd8c99e03b9  sub rsp, 0xF0
00007dd8c99e03c0  vmovaps [rsp], xmm0
00007dd8c99e03c5  vmovaps [rsp+0x10], xmm2
00007dd8c99e03cb  vmovaps [rsp+0x20], xmm3
00007dd8c99e03d1  vmovaps [rsp+0x30], xmm4
00007dd8c99e03d7  vmovaps [rsp+0x40], xmm5
00007dd8c99e03dd  vmovaps [rsp+0x50], xmm6
00007dd8c99e03e3  vmovaps [rsp+0x60], xmm7
00007dd8c99e03e9  vmovaps [rsp+0x70], xmm8
00007dd8c99e03ef  vmovaps [rsp+0x80], xmm9
00007dd8c99e03f8  vmovaps [rsp+0x90], xmm10
00007dd8c99e0401  vmovaps [rsp+0xA0], xmm11
00007dd8c99e040a  vmovaps [rsp+0xB0], xmm12
00007dd8c99e0413  vmovaps [rsp+0xC0], xmm13
00007dd8c99e041c  vmovaps [rsp+0xD0], xmm14
00007dd8c99e0425  vmovaps [rsp+0xE0], xmm15
00007dd8c99e042e  sub rsp, 0x30
00007dd8c99e0432  movaps [rsp], xmm1
00007dd8c99e0436  movaps [rsp+0x10], xmm13
00007dd8c99e043c  movaps [rsp+0x20], xmm9
00007dd8c99e0442  lea rdi, [rsp]
00007dd8c99e0446  mov esi, 0x00
00007dd8c99e044b  mov rax, 0x55FEBBDB5530
00007dd8c99e0455  call rax
00007dd8c99e0457  movaps xmm1, [rsp]
00007dd8c99e045b  add rsp, 0x30
00007dd8c99e045f  vmovaps xmm0, [rsp]
00007dd8c99e0464  vmovaps xmm2, [rsp+0x10]
00007dd8c99e046a  vmovaps xmm3, [rsp+0x20]
00007dd8c99e0470  vmovaps xmm4, [rsp+0x30]
00007dd8c99e0476  vmovaps xmm5, [rsp+0x40]
00007dd8c99e047c  vmovaps xmm6, [rsp+0x50]
00007dd8c99e0482  vmovaps xmm7, [rsp+0x60]
00007dd8c99e0488  vmovaps xmm8, [rsp+0x70]
00007dd8c99e048e  vmovaps xmm9, [rsp+0x80]
00007dd8c99e0497  vmovaps xmm10, [rsp+0x90]
00007dd8c99e04a0  vmovaps xmm11, [rsp+0xA0]
00007dd8c99e04a9  vmovaps xmm12, [rsp+0xB0]
00007dd8c99e04b2  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e04bb  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e04c4  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e04cd  add rsp, 0xF0
00007dd8c99e04d4  pop r11
00007dd8c99e04d6  pop r10
00007dd8c99e04d8  pop r9
00007dd8c99e04da  pop r8
00007dd8c99e04dc  pop rsi
00007dd8c99e04dd  pop rdi
00007dd8c99e04de  pop rdx
00007dd8c99e04df  pop rcx
00007dd8c99e04e0  pop rax
00007dd8c99e04e1  add rsp, 0x08
00007dd8c99e04e5  jmp 0x00007DD8C99DC5CD
00007dd8c99e04ea  sub rsp, 0x08
00007dd8c99e04ee  push rax
00007dd8c99e04ef  push rcx
00007dd8c99e04f0  push rdx
00007dd8c99e04f1  push rdi
00007dd8c99e04f2  push rsi
00007dd8c99e04f3  push r8
00007dd8c99e04f5  push r9
00007dd8c99e04f7  push r10
00007dd8c99e04f9  push r11
00007dd8c99e04fb  sub rsp, 0xF0
00007dd8c99e0502  vmovaps [rsp], xmm0
00007dd8c99e0507  vmovaps [rsp+0x10], xmm1
00007dd8c99e050d  vmovaps [rsp+0x20], xmm2
00007dd8c99e0513  vmovaps [rsp+0x30], xmm3
00007dd8c99e0519  vmovaps [rsp+0x40], xmm4
00007dd8c99e051f  vmovaps [rsp+0x50], xmm5
00007dd8c99e0525  vmovaps [rsp+0x60], xmm6
00007dd8c99e052b  vmovaps [rsp+0x70], xmm7
00007dd8c99e0531  vmovaps [rsp+0x80], xmm8
00007dd8c99e053a  vmovaps [rsp+0x90], xmm9
00007dd8c99e0543  vmovaps [rsp+0xA0], xmm10
00007dd8c99e054c  vmovaps [rsp+0xB0], xmm11
00007dd8c99e0555  vmovaps [rsp+0xC0], xmm13
00007dd8c99e055e  vmovaps [rsp+0xD0], xmm14
00007dd8c99e0567  vmovaps [rsp+0xE0], xmm15
00007dd8c99e0570  sub rsp, 0x30
00007dd8c99e0574  movaps [rsp], xmm12
00007dd8c99e0579  movaps [rsp+0x10], xmm7
00007dd8c99e057e  movaps [rsp+0x20], xmm13
00007dd8c99e0584  lea rdi, [rsp]
00007dd8c99e0588  mov esi, 0x00
00007dd8c99e058d  mov rax, 0x55FEBBDB5530
00007dd8c99e0597  call rax
00007dd8c99e0599  movaps xmm12, [rsp]
00007dd8c99e059e  add rsp, 0x30
00007dd8c99e05a2  vmovaps xmm0, [rsp]
00007dd8c99e05a7  vmovaps xmm1, [rsp+0x10]
00007dd8c99e05ad  vmovaps xmm2, [rsp+0x20]
00007dd8c99e05b3  vmovaps xmm3, [rsp+0x30]
00007dd8c99e05b9  vmovaps xmm4, [rsp+0x40]
00007dd8c99e05bf  vmovaps xmm5, [rsp+0x50]
00007dd8c99e05c5  vmovaps xmm6, [rsp+0x60]
00007dd8c99e05cb  vmovaps xmm7, [rsp+0x70]
00007dd8c99e05d1  vmovaps xmm8, [rsp+0x80]
00007dd8c99e05da  vmovaps xmm9, [rsp+0x90]
00007dd8c99e05e3  vmovaps xmm10, [rsp+0xA0]
00007dd8c99e05ec  vmovaps xmm11, [rsp+0xB0]
00007dd8c99e05f5  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e05fe  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e0607  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e0610  add rsp, 0xF0
00007dd8c99e0617  pop r11
00007dd8c99e0619  pop r10
00007dd8c99e061b  pop r9
00007dd8c99e061d  pop r8
00007dd8c99e061f  pop rsi
00007dd8c99e0620  pop rdi
00007dd8c99e0621  pop rdx
00007dd8c99e0622  pop rcx
00007dd8c99e0623  pop rax
00007dd8c99e0624  add rsp, 0x08
00007dd8c99e0628  jmp 0x00007DD8C99DC5F4
00007dd8c99e062d  sub rsp, 0x08
00007dd8c99e0631  push rax
00007dd8c99e0632  push rcx
00007dd8c99e0633  push rdx
00007dd8c99e0634  push rdi
00007dd8c99e0635  push rsi
00007dd8c99e0636  push r8
00007dd8c99e0638  push r9
00007dd8c99e063a  push r10
00007dd8c99e063c  push r11
00007dd8c99e063e  sub rsp, 0xF0
00007dd8c99e0645  vmovaps [rsp], xmm0
00007dd8c99e064a  vmovaps [rsp+0x10], xmm1
00007dd8c99e0650  vmovaps [rsp+0x20], xmm2
00007dd8c99e0656  vmovaps [rsp+0x30], xmm3
00007dd8c99e065c  vmovaps [rsp+0x40], xmm4
00007dd8c99e0662  vmovaps [rsp+0x50], xmm5
00007dd8c99e0668  vmovaps [rsp+0x60], xmm6
00007dd8c99e066e  vmovaps [rsp+0x70], xmm7
00007dd8c99e0674  vmovaps [rsp+0x80], xmm8
00007dd8c99e067d  vmovaps [rsp+0x90], xmm9
00007dd8c99e0686  vmovaps [rsp+0xA0], xmm10
00007dd8c99e068f  vmovaps [rsp+0xB0], xmm11
00007dd8c99e0698  vmovaps [rsp+0xC0], xmm12
00007dd8c99e06a1  vmovaps [rsp+0xD0], xmm14
00007dd8c99e06aa  vmovaps [rsp+0xE0], xmm15
00007dd8c99e06b3  sub rsp, 0x30
00007dd8c99e06b7  movaps [rsp], xmm13
00007dd8c99e06bc  movaps [rsp+0x10], xmm15
00007dd8c99e06c2  movaps [rsp+0x20], xmm8
00007dd8c99e06c8  lea rdi, [rsp]
00007dd8c99e06cc  mov esi, 0x00
00007dd8c99e06d1  mov rax, 0x55FEBBDB5530
00007dd8c99e06db  call rax
00007dd8c99e06dd  movaps xmm13, [rsp]
00007dd8c99e06e2  add rsp, 0x30
00007dd8c99e06e6  vmovaps xmm0, [rsp]
00007dd8c99e06eb  vmovaps xmm1, [rsp+0x10]
00007dd8c99e06f1  vmovaps xmm2, [rsp+0x20]
00007dd8c99e06f7  vmovaps xmm3, [rsp+0x30]
00007dd8c99e06fd  vmovaps xmm4, [rsp+0x40]
00007dd8c99e0703  vmovaps xmm5, [rsp+0x50]
00007dd8c99e0709  vmovaps xmm6, [rsp+0x60]
00007dd8c99e070f  vmovaps xmm7, [rsp+0x70]
00007dd8c99e0715  vmovaps xmm8, [rsp+0x80]
00007dd8c99e071e  vmovaps xmm9, [rsp+0x90]
00007dd8c99e0727  vmovaps xmm10, [rsp+0xA0]
00007dd8c99e0730  vmovaps xmm11, [rsp+0xB0]
00007dd8c99e0739  vmovaps xmm12, [rsp+0xC0]
00007dd8c99e0742  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e074b  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e0754  add rsp, 0xF0
00007dd8c99e075b  pop r11
00007dd8c99e075d  pop r10
00007dd8c99e075f  pop r9
00007dd8c99e0761  pop r8
00007dd8c99e0763  pop rsi
00007dd8c99e0764  pop rdi
00007dd8c99e0765  pop rdx
00007dd8c99e0766  pop rcx
00007dd8c99e0767  pop rax
00007dd8c99e0768  add rsp, 0x08
00007dd8c99e076c  jmp 0x00007DD8C99DC60F
00007dd8c99e0771  sub rsp, 0x08
00007dd8c99e0775  push rax
00007dd8c99e0776  push rcx
00007dd8c99e0777  push rdx
00007dd8c99e0778  push rdi
00007dd8c99e0779  push rsi
00007dd8c99e077a  push r8
00007dd8c99e077c  push r9
00007dd8c99e077e  push r10
00007dd8c99e0780  push r11
00007dd8c99e0782  sub rsp, 0xF0
00007dd8c99e0789  vmovaps [rsp], xmm0
00007dd8c99e078e  vmovaps [rsp+0x10], xmm1
00007dd8c99e0794  vmovaps [rsp+0x20], xmm2
00007dd8c99e079a  vmovaps [rsp+0x30], xmm3
00007dd8c99e07a0  vmovaps [rsp+0x40], xmm4
00007dd8c99e07a6  vmovaps [rsp+0x50], xmm5
00007dd8c99e07ac  vmovaps [rsp+0x60], xmm6
00007dd8c99e07b2  vmovaps [rsp+0x70], xmm7
00007dd8c99e07b8  vmovaps [rsp+0x80], xmm9
00007dd8c99e07c1  vmovaps [rsp+0x90], xmm10
00007dd8c99e07ca  vmovaps [rsp+0xA0], xmm11
00007dd8c99e07d3  vmovaps [rsp+0xB0], xmm12
00007dd8c99e07dc  vmovaps [rsp+0xC0], xmm13
00007dd8c99e07e5  vmovaps [rsp+0xD0], xmm14
00007dd8c99e07ee  vmovaps [rsp+0xE0], xmm15
00007dd8c99e07f7  sub rsp, 0x30
00007dd8c99e07fb  movaps [rsp], xmm8
00007dd8c99e0800  movaps [rsp+0x10], xmm15
00007dd8c99e0806  movaps [rsp+0x20], xmm9
00007dd8c99e080c  lea rdi, [rsp]
00007dd8c99e0810  mov esi, 0x00
00007dd8c99e0815  mov rax, 0x55FEBBDB5530
00007dd8c99e081f  call rax
00007dd8c99e0821  movaps xmm8, [rsp]
00007dd8c99e0826  add rsp, 0x30
00007dd8c99e082a  vmovaps xmm0, [rsp]
00007dd8c99e082f  vmovaps xmm1, [rsp+0x10]
00007dd8c99e0835  vmovaps xmm2, [rsp+0x20]
00007dd8c99e083b  vmovaps xmm3, [rsp+0x30]
00007dd8c99e0841  vmovaps xmm4, [rsp+0x40]
00007dd8c99e0847  vmovaps xmm5, [rsp+0x50]
00007dd8c99e084d  vmovaps xmm6, [rsp+0x60]
00007dd8c99e0853  vmovaps xmm7, [rsp+0x70]
00007dd8c99e0859  vmovaps xmm9, [rsp+0x80]
00007dd8c99e0862  vmovaps xmm10, [rsp+0x90]
00007dd8c99e086b  vmovaps xmm11, [rsp+0xA0]
00007dd8c99e0874  vmovaps xmm12, [rsp+0xB0]
00007dd8c99e087d  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e0886  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e088f  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e0898  add rsp, 0xF0
00007dd8c99e089f  pop r11
00007dd8c99e08a1  pop r10
00007dd8c99e08a3  pop r9
00007dd8c99e08a5  pop r8
00007dd8c99e08a7  pop rsi
00007dd8c99e08a8  pop rdi
00007dd8c99e08a9  pop rdx
00007dd8c99e08aa  pop rcx
00007dd8c99e08ab  pop rax
00007dd8c99e08ac  add rsp, 0x08
00007dd8c99e08b0  jmp 0x00007DD8C99DC63D
00007dd8c99e08b5  sub rsp, 0x08
00007dd8c99e08b9  push rax
00007dd8c99e08ba  push rcx
00007dd8c99e08bb  push rdx
00007dd8c99e08bc  push rdi
00007dd8c99e08bd  push rsi
00007dd8c99e08be  push r8
00007dd8c99e08c0  push r9
00007dd8c99e08c2  push r10
00007dd8c99e08c4  push r11
00007dd8c99e08c6  sub rsp, 0xF0
00007dd8c99e08cd  vmovaps [rsp], xmm0
00007dd8c99e08d2  vmovaps [rsp+0x10], xmm1
00007dd8c99e08d8  vmovaps [rsp+0x20], xmm2
00007dd8c99e08de  vmovaps [rsp+0x30], xmm3
00007dd8c99e08e4  vmovaps [rsp+0x40], xmm4
00007dd8c99e08ea  vmovaps [rsp+0x50], xmm5
00007dd8c99e08f0  vmovaps [rsp+0x60], xmm6
00007dd8c99e08f6  vmovaps [rsp+0x70], xmm7
00007dd8c99e08fc  vmovaps [rsp+0x80], xmm8
00007dd8c99e0905  vmovaps [rsp+0x90], xmm9
00007dd8c99e090e  vmovaps [rsp+0xA0], xmm10
00007dd8c99e0917  vmovaps [rsp+0xB0], xmm11
00007dd8c99e0920  vmovaps [rsp+0xC0], xmm12
00007dd8c99e0929  vmovaps [rsp+0xD0], xmm13
00007dd8c99e0932  vmovaps [rsp+0xE0], xmm14
00007dd8c99e093b  sub rsp, 0x30
00007dd8c99e093f  movaps [rsp], xmm15
00007dd8c99e0944  movaps [rsp+0x10], xmm11
00007dd8c99e094a  movaps [rsp+0x20], xmm6
00007dd8c99e094f  lea rdi, [rsp]
00007dd8c99e0953  mov esi, 0x00
00007dd8c99e0958  mov rax, 0x55FEBBDB5530
00007dd8c99e0962  call rax
00007dd8c99e0964  movaps xmm15, [rsp]
00007dd8c99e0969  add rsp, 0x30
00007dd8c99e096d  vmovaps xmm0, [rsp]
00007dd8c99e0972  vmovaps xmm1, [rsp+0x10]
00007dd8c99e0978  vmovaps xmm2, [rsp+0x20]
00007dd8c99e097e  vmovaps xmm3, [rsp+0x30]
00007dd8c99e0984  vmovaps xmm4, [rsp+0x40]
00007dd8c99e098a  vmovaps xmm5, [rsp+0x50]
00007dd8c99e0990  vmovaps xmm6, [rsp+0x60]
00007dd8c99e0996  vmovaps xmm7, [rsp+0x70]
00007dd8c99e099c  vmovaps xmm8, [rsp+0x80]
00007dd8c99e09a5  vmovaps xmm9, [rsp+0x90]
00007dd8c99e09ae  vmovaps xmm10, [rsp+0xA0]
00007dd8c99e09b7  vmovaps xmm11, [rsp+0xB0]
00007dd8c99e09c0  vmovaps xmm12, [rsp+0xC0]
00007dd8c99e09c9  vmovaps xmm13, [rsp+0xD0]
00007dd8c99e09d2  vmovaps xmm14, [rsp+0xE0]
00007dd8c99e09db  add rsp, 0xF0
00007dd8c99e09e2  pop r11
00007dd8c99e09e4  pop r10
00007dd8c99e09e6  pop r9
00007dd8c99e09e8  pop r8
00007dd8c99e09ea  pop rsi
00007dd8c99e09eb  pop rdi
00007dd8c99e09ec  pop rdx
00007dd8c99e09ed  pop rcx
00007dd8c99e09ee  pop rax
00007dd8c99e09ef  add rsp, 0x08
00007dd8c99e09f3  jmp 0x00007DD8C99DC658
00007dd8c99e09f8  sub rsp, 0x08
00007dd8c99e09fc  push rax
00007dd8c99e09fd  push rcx
00007dd8c99e09fe  push rdx
00007dd8c99e09ff  push rdi
00007dd8c99e0a00  push rsi
00007dd8c99e0a01  push r8
00007dd8c99e0a03  push r9
00007dd8c99e0a05  push r10
00007dd8c99e0a07  push r11
00007dd8c99e0a09  sub rsp, 0xF0
00007dd8c99e0a10  vmovaps [rsp], xmm0
00007dd8c99e0a15  vmovaps [rsp+0x10], xmm1
00007dd8c99e0a1b  vmovaps [rsp+0x20], xmm2
00007dd8c99e0a21  vmovaps [rsp+0x30], xmm3
00007dd8c99e0a27  vmovaps [rsp+0x40], xmm4
00007dd8c99e0a2d  vmovaps [rsp+0x50], xmm5
00007dd8c99e0a33  vmovaps [rsp+0x60], xmm6
00007dd8c99e0a39  vmovaps [rsp+0x70], xmm8
00007dd8c99e0a3f  vmovaps [rsp+0x80], xmm9
00007dd8c99e0a48  vmovaps [rsp+0x90], xmm10
00007dd8c99e0a51  vmovaps [rsp+0xA0], xmm11
00007dd8c99e0a5a  vmovaps [rsp+0xB0], xmm12
00007dd8c99e0a63  vmovaps [rsp+0xC0], xmm13
00007dd8c99e0a6c  vmovaps [rsp+0xD0], xmm14
00007dd8c99e0a75  vmovaps [rsp+0xE0], xmm15
00007dd8c99e0a7e  sub rsp, 0x30
00007dd8c99e0a82  movaps [rsp], xmm7
00007dd8c99e0a86  movaps [rsp+0x10], xmm11
00007dd8c99e0a8c  movaps [rsp+0x20], xmm9
00007dd8c99e0a92  lea rdi, [rsp]
00007dd8c99e0a96  mov esi, 0x00
00007dd8c99e0a9b  mov rax, 0x55FEBBDB5530
00007dd8c99e0aa5  call rax
00007dd8c99e0aa7  movaps xmm7, [rsp]
00007dd8c99e0aab  add rsp, 0x30
00007dd8c99e0aaf  vmovaps xmm0, [rsp]
00007dd8c99e0ab4  vmovaps xmm1, [rsp+0x10]
00007dd8c99e0aba  vmovaps xmm2, [rsp+0x20]
00007dd8c99e0ac0  vmovaps xmm3, [rsp+0x30]
00007dd8c99e0ac6  vmovaps xmm4, [rsp+0x40]
00007dd8c99e0acc  vmovaps xmm5, [rsp+0x50]
00007dd8c99e0ad2  vmovaps xmm6, [rsp+0x60]
00007dd8c99e0ad8  vmovaps xmm8, [rsp+0x70]
00007dd8c99e0ade  vmovaps xmm9, [rsp+0x80]
00007dd8c99e0ae7  vmovaps xmm10, [rsp+0x90]
00007dd8c99e0af0  vmovaps xmm11, [rsp+0xA0]
00007dd8c99e0af9  vmovaps xmm12, [rsp+0xB0]
00007dd8c99e0b02  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e0b0b  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e0b14  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e0b1d  add rsp, 0xF0
00007dd8c99e0b24  pop r11
00007dd8c99e0b26  pop r10
00007dd8c99e0b28  pop r9
00007dd8c99e0b2a  pop r8
00007dd8c99e0b2c  pop rsi
00007dd8c99e0b2d  pop rdi
00007dd8c99e0b2e  pop rdx
00007dd8c99e0b2f  pop rcx
00007dd8c99e0b30  pop rax
00007dd8c99e0b31  add rsp, 0x08
00007dd8c99e0b35  jmp 0x00007DD8C99DC685
00007dd8c99e0b3a  sub rsp, 0x08
00007dd8c99e0b3e  push rax
00007dd8c99e0b3f  push rcx
00007dd8c99e0b40  push rdx
00007dd8c99e0b41  push rdi
00007dd8c99e0b42  push rsi
00007dd8c99e0b43  push r8
00007dd8c99e0b45  push r9
00007dd8c99e0b47  push r10
00007dd8c99e0b49  push r11
00007dd8c99e0b4b  sub rsp, 0xF0
00007dd8c99e0b52  vmovaps [rsp], xmm0
00007dd8c99e0b57  vmovaps [rsp+0x10], xmm1
00007dd8c99e0b5d  vmovaps [rsp+0x20], xmm2
00007dd8c99e0b63  vmovaps [rsp+0x30], xmm3
00007dd8c99e0b69  vmovaps [rsp+0x40], xmm4
00007dd8c99e0b6f  vmovaps [rsp+0x50], xmm5
00007dd8c99e0b75  vmovaps [rsp+0x60], xmm6
00007dd8c99e0b7b  vmovaps [rsp+0x70], xmm7
00007dd8c99e0b81  vmovaps [rsp+0x80], xmm8
00007dd8c99e0b8a  vmovaps [rsp+0x90], xmm9
00007dd8c99e0b93  vmovaps [rsp+0xA0], xmm10
00007dd8c99e0b9c  vmovaps [rsp+0xB0], xmm12
00007dd8c99e0ba5  vmovaps [rsp+0xC0], xmm13
00007dd8c99e0bae  vmovaps [rsp+0xD0], xmm14
00007dd8c99e0bb7  vmovaps [rsp+0xE0], xmm15
00007dd8c99e0bc0  sub rsp, 0x30
00007dd8c99e0bc4  movaps [rsp], xmm11
00007dd8c99e0bc9  movaps [rsp+0x10], xmm10
00007dd8c99e0bcf  movaps [rsp+0x20], xmm14
00007dd8c99e0bd5  lea rdi, [rsp]
00007dd8c99e0bd9  mov esi, 0x00
00007dd8c99e0bde  mov rax, 0x55FEBBDB5530
00007dd8c99e0be8  call rax
00007dd8c99e0bea  movaps xmm11, [rsp]
00007dd8c99e0bef  add rsp, 0x30
00007dd8c99e0bf3  vmovaps xmm0, [rsp]
00007dd8c99e0bf8  vmovaps xmm1, [rsp+0x10]
00007dd8c99e0bfe  vmovaps xmm2, [rsp+0x20]
00007dd8c99e0c04  vmovaps xmm3, [rsp+0x30]
00007dd8c99e0c0a  vmovaps xmm4, [rsp+0x40]
00007dd8c99e0c10  vmovaps xmm5, [rsp+0x50]
00007dd8c99e0c16  vmovaps xmm6, [rsp+0x60]
00007dd8c99e0c1c  vmovaps xmm7, [rsp+0x70]
00007dd8c99e0c22  vmovaps xmm8, [rsp+0x80]
00007dd8c99e0c2b  vmovaps xmm9, [rsp+0x90]
00007dd8c99e0c34  vmovaps xmm10, [rsp+0xA0]
00007dd8c99e0c3d  vmovaps xmm12, [rsp+0xB0]
00007dd8c99e0c46  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e0c4f  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e0c58  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e0c61  add rsp, 0xF0
00007dd8c99e0c68  pop r11
00007dd8c99e0c6a  pop r10
00007dd8c99e0c6c  pop r9
00007dd8c99e0c6e  pop r8
00007dd8c99e0c70  pop rsi
00007dd8c99e0c71  pop rdi
00007dd8c99e0c72  pop rdx
00007dd8c99e0c73  pop rcx
00007dd8c99e0c74  pop rax
00007dd8c99e0c75  add rsp, 0x08
00007dd8c99e0c79  jmp 0x00007DD8C99DC6A0
00007dd8c99e0c7e  call 0x00007DD8C98C33A0
00007dd8c99e0c83  jmp 0x00007DD8C99DC6AA
00007dd8c99e0c88  sub rsp, 0x08
00007dd8c99e0c8c  push rax
00007dd8c99e0c8d  push rcx
00007dd8c99e0c8e  push rdx
00007dd8c99e0c8f  push rdi
00007dd8c99e0c90  push rsi
00007dd8c99e0c91  push r8
00007dd8c99e0c93  push r9
00007dd8c99e0c95  push r10
00007dd8c99e0c97  push r11
00007dd8c99e0c99  sub rsp, 0xF0
00007dd8c99e0ca0  vmovaps [rsp], xmm0
00007dd8c99e0ca5  vmovaps [rsp+0x10], xmm1
00007dd8c99e0cab  vmovaps [rsp+0x20], xmm2
00007dd8c99e0cb1  vmovaps [rsp+0x30], xmm3
00007dd8c99e0cb7  vmovaps [rsp+0x40], xmm4
00007dd8c99e0cbd  vmovaps [rsp+0x50], xmm5
00007dd8c99e0cc3  vmovaps [rsp+0x60], xmm6
00007dd8c99e0cc9  vmovaps [rsp+0x70], xmm7
00007dd8c99e0ccf  vmovaps [rsp+0x80], xmm8
00007dd8c99e0cd8  vmovaps [rsp+0x90], xmm9
00007dd8c99e0ce1  vmovaps [rsp+0xA0], xmm11
00007dd8c99e0cea  vmovaps [rsp+0xB0], xmm12
00007dd8c99e0cf3  vmovaps [rsp+0xC0], xmm13
00007dd8c99e0cfc  vmovaps [rsp+0xD0], xmm14
00007dd8c99e0d05  vmovaps [rsp+0xE0], xmm15
00007dd8c99e0d0e  sub rsp, 0x30
00007dd8c99e0d12  movaps [rsp], xmm10
00007dd8c99e0d17  movaps [rsp+0x10], xmm1
00007dd8c99e0d1c  movaps [rsp+0x20], xmm12
00007dd8c99e0d22  lea rdi, [rsp]
00007dd8c99e0d26  mov esi, 0x00
00007dd8c99e0d2b  mov rax, 0x55FEBBDB5530
00007dd8c99e0d35  call rax
00007dd8c99e0d37  movaps xmm10, [rsp]
00007dd8c99e0d3c  add rsp, 0x30
00007dd8c99e0d40  vmovaps xmm0, [rsp]
00007dd8c99e0d45  vmovaps xmm1, [rsp+0x10]
00007dd8c99e0d4b  vmovaps xmm2, [rsp+0x20]
00007dd8c99e0d51  vmovaps xmm3, [rsp+0x30]
00007dd8c99e0d57  vmovaps xmm4, [rsp+0x40]
00007dd8c99e0d5d  vmovaps xmm5, [rsp+0x50]
00007dd8c99e0d63  vmovaps xmm6, [rsp+0x60]
00007dd8c99e0d69  vmovaps xmm7, [rsp+0x70]
00007dd8c99e0d6f  vmovaps xmm8, [rsp+0x80]
00007dd8c99e0d78  vmovaps xmm9, [rsp+0x90]
00007dd8c99e0d81  vmovaps xmm11, [rsp+0xA0]
00007dd8c99e0d8a  vmovaps xmm12, [rsp+0xB0]
00007dd8c99e0d93  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e0d9c  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e0da5  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e0dae  add rsp, 0xF0
00007dd8c99e0db5  pop r11
00007dd8c99e0db7  pop r10
00007dd8c99e0db9  pop r9
00007dd8c99e0dbb  pop r8
00007dd8c99e0dbd  pop rsi
00007dd8c99e0dbe  pop rdi
00007dd8c99e0dbf  pop rdx
00007dd8c99e0dc0  pop rcx
00007dd8c99e0dc1  pop rax
00007dd8c99e0dc2  add rsp, 0x08
00007dd8c99e0dc6  jmp 0x00007DD8C99DC6CD
00007dd8c99e0dcb  sub rsp, 0x08
00007dd8c99e0dcf  push rax
00007dd8c99e0dd0  push rcx
00007dd8c99e0dd1  push rdx
00007dd8c99e0dd2  push rdi
00007dd8c99e0dd3  push rsi
00007dd8c99e0dd4  push r8
00007dd8c99e0dd6  push r9
00007dd8c99e0dd8  push r10
00007dd8c99e0dda  push r11
00007dd8c99e0ddc  sub rsp, 0xF0
00007dd8c99e0de3  vmovaps [rsp], xmm0
00007dd8c99e0de8  vmovaps [rsp+0x10], xmm1
00007dd8c99e0dee  vmovaps [rsp+0x20], xmm2
00007dd8c99e0df4  vmovaps [rsp+0x30], xmm3
00007dd8c99e0dfa  vmovaps [rsp+0x40], xmm4
00007dd8c99e0e00  vmovaps [rsp+0x50], xmm5
00007dd8c99e0e06  vmovaps [rsp+0x60], xmm6
00007dd8c99e0e0c  vmovaps [rsp+0x70], xmm7
00007dd8c99e0e12  vmovaps [rsp+0x80], xmm8
00007dd8c99e0e1b  vmovaps [rsp+0x90], xmm9
00007dd8c99e0e24  vmovaps [rsp+0xA0], xmm10
00007dd8c99e0e2d  vmovaps [rsp+0xB0], xmm11
00007dd8c99e0e36  vmovaps [rsp+0xC0], xmm13
00007dd8c99e0e3f  vmovaps [rsp+0xD0], xmm14
00007dd8c99e0e48  vmovaps [rsp+0xE0], xmm15
00007dd8c99e0e51  sub rsp, 0x30
00007dd8c99e0e55  movaps [rsp], xmm12
00007dd8c99e0e5a  movaps [rsp+0x10], xmm14
00007dd8c99e0e60  movaps [rsp+0x20], xmm1
00007dd8c99e0e65  lea rdi, [rsp]
00007dd8c99e0e69  mov esi, 0x00
00007dd8c99e0e6e  mov rax, 0x55FEBBDB5530
00007dd8c99e0e78  call rax
00007dd8c99e0e7a  movaps xmm12, [rsp]
00007dd8c99e0e7f  add rsp, 0x30
00007dd8c99e0e83  vmovaps xmm0, [rsp]
00007dd8c99e0e88  vmovaps xmm1, [rsp+0x10]
00007dd8c99e0e8e  vmovaps xmm2, [rsp+0x20]
00007dd8c99e0e94  vmovaps xmm3, [rsp+0x30]
00007dd8c99e0e9a  vmovaps xmm4, [rsp+0x40]
00007dd8c99e0ea0  vmovaps xmm5, [rsp+0x50]
00007dd8c99e0ea6  vmovaps xmm6, [rsp+0x60]
00007dd8c99e0eac  vmovaps xmm7, [rsp+0x70]
00007dd8c99e0eb2  vmovaps xmm8, [rsp+0x80]
00007dd8c99e0ebb  vmovaps xmm9, [rsp+0x90]
00007dd8c99e0ec4  vmovaps xmm10, [rsp+0xA0]
00007dd8c99e0ecd  vmovaps xmm11, [rsp+0xB0]
00007dd8c99e0ed6  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e0edf  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e0ee8  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e0ef1  add rsp, 0xF0
00007dd8c99e0ef8  pop r11
00007dd8c99e0efa  pop r10
00007dd8c99e0efc  pop r9
00007dd8c99e0efe  pop r8
00007dd8c99e0f00  pop rsi
00007dd8c99e0f01  pop rdi
00007dd8c99e0f02  pop rdx
00007dd8c99e0f03  pop rcx
00007dd8c99e0f04  pop rax
00007dd8c99e0f05  add rsp, 0x08
00007dd8c99e0f09  jmp 0x00007DD8C99DC6FC
00007dd8c99e0f0e  sub rsp, 0x08
00007dd8c99e0f12  push rax
00007dd8c99e0f13  push rcx
00007dd8c99e0f14  push rdx
00007dd8c99e0f15  push rdi
00007dd8c99e0f16  push rsi
00007dd8c99e0f17  push r8
00007dd8c99e0f19  push r9
00007dd8c99e0f1b  push r10
00007dd8c99e0f1d  push r11
00007dd8c99e0f1f  sub rsp, 0xF0
00007dd8c99e0f26  vmovaps [rsp], xmm0
00007dd8c99e0f2b  vmovaps [rsp+0x10], xmm1
00007dd8c99e0f31  vmovaps [rsp+0x20], xmm2
00007dd8c99e0f37  vmovaps [rsp+0x30], xmm3
00007dd8c99e0f3d  vmovaps [rsp+0x40], xmm4
00007dd8c99e0f43  vmovaps [rsp+0x50], xmm5
00007dd8c99e0f49  vmovaps [rsp+0x60], xmm6
00007dd8c99e0f4f  vmovaps [rsp+0x70], xmm7
00007dd8c99e0f55  vmovaps [rsp+0x80], xmm8
00007dd8c99e0f5e  vmovaps [rsp+0x90], xmm9
00007dd8c99e0f67  vmovaps [rsp+0xA0], xmm10
00007dd8c99e0f70  vmovaps [rsp+0xB0], xmm11
00007dd8c99e0f79  vmovaps [rsp+0xC0], xmm12
00007dd8c99e0f82  vmovaps [rsp+0xD0], xmm13
00007dd8c99e0f8b  vmovaps [rsp+0xE0], xmm15
00007dd8c99e0f94  sub rsp, 0x30
00007dd8c99e0f98  movaps [rsp], xmm14
00007dd8c99e0f9d  movaps [rsp+0x10], xmm9
00007dd8c99e0fa3  movaps [rsp+0x20], xmm1
00007dd8c99e0fa8  lea rdi, [rsp]
00007dd8c99e0fac  mov esi, 0x00
00007dd8c99e0fb1  mov rax, 0x55FEBBDB5530
00007dd8c99e0fbb  call rax
00007dd8c99e0fbd  movaps xmm14, [rsp]
00007dd8c99e0fc2  add rsp, 0x30
00007dd8c99e0fc6  vmovaps xmm0, [rsp]
00007dd8c99e0fcb  vmovaps xmm1, [rsp+0x10]
00007dd8c99e0fd1  vmovaps xmm2, [rsp+0x20]
00007dd8c99e0fd7  vmovaps xmm3, [rsp+0x30]
00007dd8c99e0fdd  vmovaps xmm4, [rsp+0x40]
00007dd8c99e0fe3  vmovaps xmm5, [rsp+0x50]
00007dd8c99e0fe9  vmovaps xmm6, [rsp+0x60]
00007dd8c99e0fef  vmovaps xmm7, [rsp+0x70]
00007dd8c99e0ff5  vmovaps xmm8, [rsp+0x80]
00007dd8c99e0ffe  vmovaps xmm9, [rsp+0x90]
00007dd8c99e1007  vmovaps xmm10, [rsp+0xA0]
00007dd8c99e1010  vmovaps xmm11, [rsp+0xB0]
00007dd8c99e1019  vmovaps xmm12, [rsp+0xC0]
00007dd8c99e1022  vmovaps xmm13, [rsp+0xD0]
00007dd8c99e102b  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e1034  add rsp, 0xF0
00007dd8c99e103b  pop r11
00007dd8c99e103d  pop r10
00007dd8c99e103f  pop r9
00007dd8c99e1041  pop r8
00007dd8c99e1043  pop rsi
00007dd8c99e1044  pop rdi
00007dd8c99e1045  pop rdx
00007dd8c99e1046  pop rcx
00007dd8c99e1047  pop rax
00007dd8c99e1048  add rsp, 0x08
00007dd8c99e104c  jmp 0x00007DD8C99DC72B
00007dd8c99e1051  sub rsp, 0x08
00007dd8c99e1055  push rax
00007dd8c99e1056  push rcx
00007dd8c99e1057  push rdx
00007dd8c99e1058  push rdi
00007dd8c99e1059  push rsi
00007dd8c99e105a  push r8
00007dd8c99e105c  push r9
00007dd8c99e105e  push r10
00007dd8c99e1060  push r11
00007dd8c99e1062  sub rsp, 0xF0
00007dd8c99e1069  vmovaps [rsp], xmm0
00007dd8c99e106e  vmovaps [rsp+0x10], xmm2
00007dd8c99e1074  vmovaps [rsp+0x20], xmm3
00007dd8c99e107a  vmovaps [rsp+0x30], xmm4
00007dd8c99e1080  vmovaps [rsp+0x40], xmm5
00007dd8c99e1086  vmovaps [rsp+0x50], xmm6
00007dd8c99e108c  vmovaps [rsp+0x60], xmm7
00007dd8c99e1092  vmovaps [rsp+0x70], xmm8
00007dd8c99e1098  vmovaps [rsp+0x80], xmm9
00007dd8c99e10a1  vmovaps [rsp+0x90], xmm10
00007dd8c99e10aa  vmovaps [rsp+0xA0], xmm11
00007dd8c99e10b3  vmovaps [rsp+0xB0], xmm12
00007dd8c99e10bc  vmovaps [rsp+0xC0], xmm13
00007dd8c99e10c5  vmovaps [rsp+0xD0], xmm14
00007dd8c99e10ce  vmovaps [rsp+0xE0], xmm15
00007dd8c99e10d7  sub rsp, 0x30
00007dd8c99e10db  movaps [rsp], xmm1
00007dd8c99e10df  movaps [rsp+0x10], xmm13
00007dd8c99e10e5  movaps [rsp+0x20], xmm8
00007dd8c99e10eb  lea rdi, [rsp]
00007dd8c99e10ef  mov esi, 0x00
00007dd8c99e10f4  mov rax, 0x55FEBBDB5530
00007dd8c99e10fe  call rax
00007dd8c99e1100  movaps xmm1, [rsp]
00007dd8c99e1104  add rsp, 0x30
00007dd8c99e1108  vmovaps xmm0, [rsp]
00007dd8c99e110d  vmovaps xmm2, [rsp+0x10]
00007dd8c99e1113  vmovaps xmm3, [rsp+0x20]
00007dd8c99e1119  vmovaps xmm4, [rsp+0x30]
00007dd8c99e111f  vmovaps xmm5, [rsp+0x40]
00007dd8c99e1125  vmovaps xmm6, [rsp+0x50]
00007dd8c99e112b  vmovaps xmm7, [rsp+0x60]
00007dd8c99e1131  vmovaps xmm8, [rsp+0x70]
00007dd8c99e1137  vmovaps xmm9, [rsp+0x80]
00007dd8c99e1140  vmovaps xmm10, [rsp+0x90]
00007dd8c99e1149  vmovaps xmm11, [rsp+0xA0]
00007dd8c99e1152  vmovaps xmm12, [rsp+0xB0]
00007dd8c99e115b  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e1164  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e116d  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e1176  add rsp, 0xF0
00007dd8c99e117d  pop r11
00007dd8c99e117f  pop r10
00007dd8c99e1181  pop r9
00007dd8c99e1183  pop r8
00007dd8c99e1185  pop rsi
00007dd8c99e1186  pop rdi
00007dd8c99e1187  pop rdx
00007dd8c99e1188  pop rcx
00007dd8c99e1189  pop rax
00007dd8c99e118a  add rsp, 0x08
00007dd8c99e118e  jmp 0x00007DD8C99DC74D
00007dd8c99e1193  call 0x00007DD8C980C260
00007dd8c99e1198  jmp 0x00007DD8C99DC75B
00007dd8c99e119d  call 0x00007DD8C98BD750
00007dd8c99e11a2  jmp 0x00007DD8C99DC765
00007dd8c99e11a7  sub rsp, 0x08
00007dd8c99e11ab  push rax
00007dd8c99e11ac  push rcx
00007dd8c99e11ad  push rdx
00007dd8c99e11ae  push rdi
00007dd8c99e11af  push rsi
00007dd8c99e11b0  push r8
00007dd8c99e11b2  push r9
00007dd8c99e11b4  push r10
00007dd8c99e11b6  push r11
00007dd8c99e11b8  sub rsp, 0xF0
00007dd8c99e11bf  vmovaps [rsp], xmm0
00007dd8c99e11c4  vmovaps [rsp+0x10], xmm1
00007dd8c99e11ca  vmovaps [rsp+0x20], xmm2
00007dd8c99e11d0  vmovaps [rsp+0x30], xmm3
00007dd8c99e11d6  vmovaps [rsp+0x40], xmm4
00007dd8c99e11dc  vmovaps [rsp+0x50], xmm5
00007dd8c99e11e2  vmovaps [rsp+0x60], xmm6
00007dd8c99e11e8  vmovaps [rsp+0x70], xmm7
00007dd8c99e11ee  vmovaps [rsp+0x80], xmm9
00007dd8c99e11f7  vmovaps [rsp+0x90], xmm10
00007dd8c99e1200  vmovaps [rsp+0xA0], xmm11
00007dd8c99e1209  vmovaps [rsp+0xB0], xmm12
00007dd8c99e1212  vmovaps [rsp+0xC0], xmm13
00007dd8c99e121b  vmovaps [rsp+0xD0], xmm14
00007dd8c99e1224  vmovaps [rsp+0xE0], xmm15
00007dd8c99e122d  sub rsp, 0x30
00007dd8c99e1231  movaps [rsp], xmm8
00007dd8c99e1236  movaps [rsp+0x10], xmm15
00007dd8c99e123c  movaps [rsp+0x20], xmm7
00007dd8c99e1241  lea rdi, [rsp]
00007dd8c99e1245  mov esi, 0x00
00007dd8c99e124a  mov rax, 0x55FEBBDB5530
00007dd8c99e1254  call rax
00007dd8c99e1256  movaps xmm8, [rsp]
00007dd8c99e125b  add rsp, 0x30
00007dd8c99e125f  vmovaps xmm0, [rsp]
00007dd8c99e1264  vmovaps xmm1, [rsp+0x10]
00007dd8c99e126a  vmovaps xmm2, [rsp+0x20]
00007dd8c99e1270  vmovaps xmm3, [rsp+0x30]
00007dd8c99e1276  vmovaps xmm4, [rsp+0x40]
00007dd8c99e127c  vmovaps xmm5, [rsp+0x50]
00007dd8c99e1282  vmovaps xmm6, [rsp+0x60]
00007dd8c99e1288  vmovaps xmm7, [rsp+0x70]
00007dd8c99e128e  vmovaps xmm9, [rsp+0x80]
00007dd8c99e1297  vmovaps xmm10, [rsp+0x90]
00007dd8c99e12a0  vmovaps xmm11, [rsp+0xA0]
00007dd8c99e12a9  vmovaps xmm12, [rsp+0xB0]
00007dd8c99e12b2  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e12bb  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e12c4  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e12cd  add rsp, 0xF0
00007dd8c99e12d4  pop r11
00007dd8c99e12d6  pop r10
00007dd8c99e12d8  pop r9
00007dd8c99e12da  pop r8
00007dd8c99e12dc  pop rsi
00007dd8c99e12dd  pop rdi
00007dd8c99e12de  pop rdx
00007dd8c99e12df  pop rcx
00007dd8c99e12e0  pop rax
00007dd8c99e12e1  add rsp, 0x08
00007dd8c99e12e5  jmp 0x00007DD8C99DC787
00007dd8c99e12ea  sub rsp, 0x08
00007dd8c99e12ee  push rax
00007dd8c99e12ef  push rcx
00007dd8c99e12f0  push rdx
00007dd8c99e12f1  push rdi
00007dd8c99e12f2  push rsi
00007dd8c99e12f3  push r8
00007dd8c99e12f5  push r9
00007dd8c99e12f7  push r10
00007dd8c99e12f9  push r11
00007dd8c99e12fb  sub rsp, 0xF0
00007dd8c99e1302  vmovaps [rsp], xmm0
00007dd8c99e1307  vmovaps [rsp+0x10], xmm1
00007dd8c99e130d  vmovaps [rsp+0x20], xmm2
00007dd8c99e1313  vmovaps [rsp+0x30], xmm3
00007dd8c99e1319  vmovaps [rsp+0x40], xmm4
00007dd8c99e131f  vmovaps [rsp+0x50], xmm5
00007dd8c99e1325  vmovaps [rsp+0x60], xmm6
00007dd8c99e132b  vmovaps [rsp+0x70], xmm8
00007dd8c99e1331  vmovaps [rsp+0x80], xmm9
00007dd8c99e133a  vmovaps [rsp+0x90], xmm10
00007dd8c99e1343  vmovaps [rsp+0xA0], xmm11
00007dd8c99e134c  vmovaps [rsp+0xB0], xmm12
00007dd8c99e1355  vmovaps [rsp+0xC0], xmm13
00007dd8c99e135e  vmovaps [rsp+0xD0], xmm14
00007dd8c99e1367  vmovaps [rsp+0xE0], xmm15
00007dd8c99e1370  sub rsp, 0x30
00007dd8c99e1374  movaps [rsp], xmm7
00007dd8c99e1378  movaps [rsp+0x10], xmm9
00007dd8c99e137e  movaps [rsp+0x20], xmm15
00007dd8c99e1384  lea rdi, [rsp]
00007dd8c99e1388  mov esi, 0x00
00007dd8c99e138d  mov rax, 0x55FEBBDB5530
00007dd8c99e1397  call rax
00007dd8c99e1399  movaps xmm7, [rsp]
00007dd8c99e139d  add rsp, 0x30
00007dd8c99e13a1  vmovaps xmm0, [rsp]
00007dd8c99e13a6  vmovaps xmm1, [rsp+0x10]
00007dd8c99e13ac  vmovaps xmm2, [rsp+0x20]
00007dd8c99e13b2  vmovaps xmm3, [rsp+0x30]
00007dd8c99e13b8  vmovaps xmm4, [rsp+0x40]
00007dd8c99e13be  vmovaps xmm5, [rsp+0x50]
00007dd8c99e13c4  vmovaps xmm6, [rsp+0x60]
00007dd8c99e13ca  vmovaps xmm8, [rsp+0x70]
00007dd8c99e13d0  vmovaps xmm9, [rsp+0x80]
00007dd8c99e13d9  vmovaps xmm10, [rsp+0x90]
00007dd8c99e13e2  vmovaps xmm11, [rsp+0xA0]
00007dd8c99e13eb  vmovaps xmm12, [rsp+0xB0]
00007dd8c99e13f4  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e13fd  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e1406  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e140f  add rsp, 0xF0
00007dd8c99e1416  pop r11
00007dd8c99e1418  pop r10
00007dd8c99e141a  pop r9
00007dd8c99e141c  pop r8
00007dd8c99e141e  pop rsi
00007dd8c99e141f  pop rdi
00007dd8c99e1420  pop rdx
00007dd8c99e1421  pop rcx
00007dd8c99e1422  pop rax
00007dd8c99e1423  add rsp, 0x08
00007dd8c99e1427  jmp 0x00007DD8C99DC7B4
00007dd8c99e142c  sub rsp, 0x08
00007dd8c99e1430  push rax
00007dd8c99e1431  push rcx
00007dd8c99e1432  push rdx
00007dd8c99e1433  push rdi
00007dd8c99e1434  push rsi
00007dd8c99e1435  push r8
00007dd8c99e1437  push r9
00007dd8c99e1439  push r10
00007dd8c99e143b  push r11
00007dd8c99e143d  sub rsp, 0xF0
00007dd8c99e1444  vmovaps [rsp], xmm0
00007dd8c99e1449  vmovaps [rsp+0x10], xmm1
00007dd8c99e144f  vmovaps [rsp+0x20], xmm2
00007dd8c99e1455  vmovaps [rsp+0x30], xmm3
00007dd8c99e145b  vmovaps [rsp+0x40], xmm4
00007dd8c99e1461  vmovaps [rsp+0x50], xmm5
00007dd8c99e1467  vmovaps [rsp+0x60], xmm6
00007dd8c99e146d  vmovaps [rsp+0x70], xmm7
00007dd8c99e1473  vmovaps [rsp+0x80], xmm8
00007dd8c99e147c  vmovaps [rsp+0x90], xmm10
00007dd8c99e1485  vmovaps [rsp+0xA0], xmm11
00007dd8c99e148e  vmovaps [rsp+0xB0], xmm12
00007dd8c99e1497  vmovaps [rsp+0xC0], xmm13
00007dd8c99e14a0  vmovaps [rsp+0xD0], xmm14
00007dd8c99e14a9  vmovaps [rsp+0xE0], xmm15
00007dd8c99e14b2  sub rsp, 0x30
00007dd8c99e14b6  movaps [rsp], xmm9
00007dd8c99e14bb  movaps [rsp+0x10], xmm13
00007dd8c99e14c1  movaps [rsp+0x20], xmm15
00007dd8c99e14c7  lea rdi, [rsp]
00007dd8c99e14cb  mov esi, 0x00
00007dd8c99e14d0  mov rax, 0x55FEBBDB5530
00007dd8c99e14da  call rax
00007dd8c99e14dc  movaps xmm9, [rsp]
00007dd8c99e14e1  add rsp, 0x30
00007dd8c99e14e5  vmovaps xmm0, [rsp]
00007dd8c99e14ea  vmovaps xmm1, [rsp+0x10]
00007dd8c99e14f0  vmovaps xmm2, [rsp+0x20]
00007dd8c99e14f6  vmovaps xmm3, [rsp+0x30]
00007dd8c99e14fc  vmovaps xmm4, [rsp+0x40]
00007dd8c99e1502  vmovaps xmm5, [rsp+0x50]
00007dd8c99e1508  vmovaps xmm6, [rsp+0x60]
00007dd8c99e150e  vmovaps xmm7, [rsp+0x70]
00007dd8c99e1514  vmovaps xmm8, [rsp+0x80]
00007dd8c99e151d  vmovaps xmm10, [rsp+0x90]
00007dd8c99e1526  vmovaps xmm11, [rsp+0xA0]
00007dd8c99e152f  vmovaps xmm12, [rsp+0xB0]
00007dd8c99e1538  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e1541  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e154a  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e1553  add rsp, 0xF0
00007dd8c99e155a  pop r11
00007dd8c99e155c  pop r10
00007dd8c99e155e  pop r9
00007dd8c99e1560  pop r8
00007dd8c99e1562  pop rsi
00007dd8c99e1563  pop rdi
00007dd8c99e1564  pop rdx
00007dd8c99e1565  pop rcx
00007dd8c99e1566  pop rax
00007dd8c99e1567  add rsp, 0x08
00007dd8c99e156b  jmp 0x00007DD8C99DC7E2
00007dd8c99e1570  sub rsp, 0x08
00007dd8c99e1574  push rax
00007dd8c99e1575  push rcx
00007dd8c99e1576  push rdx
00007dd8c99e1577  push rdi
00007dd8c99e1578  push rsi
00007dd8c99e1579  push r8
00007dd8c99e157b  push r9
00007dd8c99e157d  push r10
00007dd8c99e157f  push r11
00007dd8c99e1581  sub rsp, 0xF0
00007dd8c99e1588  vmovaps [rsp], xmm0
00007dd8c99e158d  vmovaps [rsp+0x10], xmm1
00007dd8c99e1593  vmovaps [rsp+0x20], xmm2
00007dd8c99e1599  vmovaps [rsp+0x30], xmm3
00007dd8c99e159f  vmovaps [rsp+0x40], xmm4
00007dd8c99e15a5  vmovaps [rsp+0x50], xmm5
00007dd8c99e15ab  vmovaps [rsp+0x60], xmm6
00007dd8c99e15b1  vmovaps [rsp+0x70], xmm7
00007dd8c99e15b7  vmovaps [rsp+0x80], xmm8
00007dd8c99e15c0  vmovaps [rsp+0x90], xmm9
00007dd8c99e15c9  vmovaps [rsp+0xA0], xmm10
00007dd8c99e15d2  vmovaps [rsp+0xB0], xmm11
00007dd8c99e15db  vmovaps [rsp+0xC0], xmm12
00007dd8c99e15e4  vmovaps [rsp+0xD0], xmm13
00007dd8c99e15ed  vmovaps [rsp+0xE0], xmm14
00007dd8c99e15f6  sub rsp, 0x30
00007dd8c99e15fa  movaps [rsp], xmm15
00007dd8c99e15ff  movaps [rsp+0x10], xmm11
00007dd8c99e1605  movaps [rsp+0x20], xmm12
00007dd8c99e160b  lea rdi, [rsp]
00007dd8c99e160f  mov esi, 0x00
00007dd8c99e1614  mov rax, 0x55FEBBDB5530
00007dd8c99e161e  call rax
00007dd8c99e1620  movaps xmm15, [rsp]
00007dd8c99e1625  add rsp, 0x30
00007dd8c99e1629  vmovaps xmm0, [rsp]
00007dd8c99e162e  vmovaps xmm1, [rsp+0x10]
00007dd8c99e1634  vmovaps xmm2, [rsp+0x20]
00007dd8c99e163a  vmovaps xmm3, [rsp+0x30]
00007dd8c99e1640  vmovaps xmm4, [rsp+0x40]
00007dd8c99e1646  vmovaps xmm5, [rsp+0x50]
00007dd8c99e164c  vmovaps xmm6, [rsp+0x60]
00007dd8c99e1652  vmovaps xmm7, [rsp+0x70]
00007dd8c99e1658  vmovaps xmm8, [rsp+0x80]
00007dd8c99e1661  vmovaps xmm9, [rsp+0x90]
00007dd8c99e166a  vmovaps xmm10, [rsp+0xA0]
00007dd8c99e1673  vmovaps xmm11, [rsp+0xB0]
00007dd8c99e167c  vmovaps xmm12, [rsp+0xC0]
00007dd8c99e1685  vmovaps xmm13, [rsp+0xD0]
00007dd8c99e168e  vmovaps xmm14, [rsp+0xE0]
00007dd8c99e1697  add rsp, 0xF0
00007dd8c99e169e  pop r11
00007dd8c99e16a0  pop r10
00007dd8c99e16a2  pop r9
00007dd8c99e16a4  pop r8
00007dd8c99e16a6  pop rsi
00007dd8c99e16a7  pop rdi
00007dd8c99e16a8  pop rdx
00007dd8c99e16a9  pop rcx
00007dd8c99e16aa  pop rax
00007dd8c99e16ab  add rsp, 0x08
00007dd8c99e16af  jmp 0x00007DD8C99DC7FD
00007dd8c99e16b4  sub rsp, 0x08
00007dd8c99e16b8  push rax
00007dd8c99e16b9  push rcx
00007dd8c99e16ba  push rdx
00007dd8c99e16bb  push rdi
00007dd8c99e16bc  push rsi
00007dd8c99e16bd  push r8
00007dd8c99e16bf  push r9
00007dd8c99e16c1  push r10
00007dd8c99e16c3  push r11
00007dd8c99e16c5  sub rsp, 0xF0
00007dd8c99e16cc  vmovaps [rsp], xmm0
00007dd8c99e16d1  vmovaps [rsp+0x10], xmm1
00007dd8c99e16d7  vmovaps [rsp+0x20], xmm2
00007dd8c99e16dd  vmovaps [rsp+0x30], xmm3
00007dd8c99e16e3  vmovaps [rsp+0x40], xmm4
00007dd8c99e16e9  vmovaps [rsp+0x50], xmm5
00007dd8c99e16ef  vmovaps [rsp+0x60], xmm6
00007dd8c99e16f5  vmovaps [rsp+0x70], xmm7
00007dd8c99e16fb  vmovaps [rsp+0x80], xmm8
00007dd8c99e1704  vmovaps [rsp+0x90], xmm9
00007dd8c99e170d  vmovaps [rsp+0xA0], xmm10
00007dd8c99e1716  vmovaps [rsp+0xB0], xmm11
00007dd8c99e171f  vmovaps [rsp+0xC0], xmm12
00007dd8c99e1728  vmovaps [rsp+0xD0], xmm14
00007dd8c99e1731  vmovaps [rsp+0xE0], xmm15
00007dd8c99e173a  sub rsp, 0x30
00007dd8c99e173e  movaps [rsp], xmm13
00007dd8c99e1743  movaps [rsp+0x10], xmm10
00007dd8c99e1749  movaps [rsp+0x20], xmm14
00007dd8c99e174f  lea rdi, [rsp]
00007dd8c99e1753  mov esi, 0x00
00007dd8c99e1758  mov rax, 0x55FEBBDB5530
00007dd8c99e1762  call rax
00007dd8c99e1764  movaps xmm13, [rsp]
00007dd8c99e1769  add rsp, 0x30
00007dd8c99e176d  vmovaps xmm0, [rsp]
00007dd8c99e1772  vmovaps xmm1, [rsp+0x10]
00007dd8c99e1778  vmovaps xmm2, [rsp+0x20]
00007dd8c99e177e  vmovaps xmm3, [rsp+0x30]
00007dd8c99e1784  vmovaps xmm4, [rsp+0x40]
00007dd8c99e178a  vmovaps xmm5, [rsp+0x50]
00007dd8c99e1790  vmovaps xmm6, [rsp+0x60]
00007dd8c99e1796  vmovaps xmm7, [rsp+0x70]
00007dd8c99e179c  vmovaps xmm8, [rsp+0x80]
00007dd8c99e17a5  vmovaps xmm9, [rsp+0x90]
00007dd8c99e17ae  vmovaps xmm10, [rsp+0xA0]
00007dd8c99e17b7  vmovaps xmm11, [rsp+0xB0]
00007dd8c99e17c0  vmovaps xmm12, [rsp+0xC0]
00007dd8c99e17c9  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e17d2  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e17db  add rsp, 0xF0
00007dd8c99e17e2  pop r11
00007dd8c99e17e4  pop r10
00007dd8c99e17e6  pop r9
00007dd8c99e17e8  pop r8
00007dd8c99e17ea  pop rsi
00007dd8c99e17eb  pop rdi
00007dd8c99e17ec  pop rdx
00007dd8c99e17ed  pop rcx
00007dd8c99e17ee  pop rax
00007dd8c99e17ef  add rsp, 0x08
00007dd8c99e17f3  jmp 0x00007DD8C99DC820
00007dd8c99e17f8  sub rsp, 0x08
00007dd8c99e17fc  push rax
00007dd8c99e17fd  push rcx
00007dd8c99e17fe  push rdx
00007dd8c99e17ff  push rdi
00007dd8c99e1800  push rsi
00007dd8c99e1801  push r8
00007dd8c99e1803  push r9
00007dd8c99e1805  push r10
00007dd8c99e1807  push r11
00007dd8c99e1809  sub rsp, 0xF0
00007dd8c99e1810  vmovaps [rsp], xmm0
00007dd8c99e1815  vmovaps [rsp+0x10], xmm1
00007dd8c99e181b  vmovaps [rsp+0x20], xmm2
00007dd8c99e1821  vmovaps [rsp+0x30], xmm3
00007dd8c99e1827  vmovaps [rsp+0x40], xmm4
00007dd8c99e182d  vmovaps [rsp+0x50], xmm5
00007dd8c99e1833  vmovaps [rsp+0x60], xmm6
00007dd8c99e1839  vmovaps [rsp+0x70], xmm7
00007dd8c99e183f  vmovaps [rsp+0x80], xmm8
00007dd8c99e1848  vmovaps [rsp+0x90], xmm9
00007dd8c99e1851  vmovaps [rsp+0xA0], xmm10
00007dd8c99e185a  vmovaps [rsp+0xB0], xmm11
00007dd8c99e1863  vmovaps [rsp+0xC0], xmm12
00007dd8c99e186c  vmovaps [rsp+0xD0], xmm13
00007dd8c99e1875  vmovaps [rsp+0xE0], xmm15
00007dd8c99e187e  sub rsp, 0x30
00007dd8c99e1882  movaps [rsp], xmm14
00007dd8c99e1887  movaps [rsp+0x10], xmm1
00007dd8c99e188c  movaps [rsp+0x20], xmm7
00007dd8c99e1891  lea rdi, [rsp]
00007dd8c99e1895  mov esi, 0x00
00007dd8c99e189a  mov rax, 0x55FEBBDB5530
00007dd8c99e18a4  call rax
00007dd8c99e18a6  movaps xmm14, [rsp]
00007dd8c99e18ab  add rsp, 0x30
00007dd8c99e18af  vmovaps xmm0, [rsp]
00007dd8c99e18b4  vmovaps xmm1, [rsp+0x10]
00007dd8c99e18ba  vmovaps xmm2, [rsp+0x20]
00007dd8c99e18c0  vmovaps xmm3, [rsp+0x30]
00007dd8c99e18c6  vmovaps xmm4, [rsp+0x40]
00007dd8c99e18cc  vmovaps xmm5, [rsp+0x50]
00007dd8c99e18d2  vmovaps xmm6, [rsp+0x60]
00007dd8c99e18d8  vmovaps xmm7, [rsp+0x70]
00007dd8c99e18de  vmovaps xmm8, [rsp+0x80]
00007dd8c99e18e7  vmovaps xmm9, [rsp+0x90]
00007dd8c99e18f0  vmovaps xmm10, [rsp+0xA0]
00007dd8c99e18f9  vmovaps xmm11, [rsp+0xB0]
00007dd8c99e1902  vmovaps xmm12, [rsp+0xC0]
00007dd8c99e190b  vmovaps xmm13, [rsp+0xD0]
00007dd8c99e1914  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e191d  add rsp, 0xF0
00007dd8c99e1924  pop r11
00007dd8c99e1926  pop r10
00007dd8c99e1928  pop r9
00007dd8c99e192a  pop r8
00007dd8c99e192c  pop rsi
00007dd8c99e192d  pop rdi
00007dd8c99e192e  pop rdx
00007dd8c99e192f  pop rcx
00007dd8c99e1930  pop rax
00007dd8c99e1931  add rsp, 0x08
00007dd8c99e1935  jmp 0x00007DD8C99DC843
00007dd8c99e193a  sub rsp, 0x08
00007dd8c99e193e  push rax
00007dd8c99e193f  push rcx
00007dd8c99e1940  push rdx
00007dd8c99e1941  push rdi
00007dd8c99e1942  push rsi
00007dd8c99e1943  push r8
00007dd8c99e1945  push r9
00007dd8c99e1947  push r10
00007dd8c99e1949  push r11
00007dd8c99e194b  sub rsp, 0xF0
00007dd8c99e1952  vmovaps [rsp], xmm0
00007dd8c99e1957  vmovaps [rsp+0x10], xmm2
00007dd8c99e195d  vmovaps [rsp+0x20], xmm3
00007dd8c99e1963  vmovaps [rsp+0x30], xmm4
00007dd8c99e1969  vmovaps [rsp+0x40], xmm5
00007dd8c99e196f  vmovaps [rsp+0x50], xmm6
00007dd8c99e1975  vmovaps [rsp+0x60], xmm7
00007dd8c99e197b  vmovaps [rsp+0x70], xmm8
00007dd8c99e1981  vmovaps [rsp+0x80], xmm9
00007dd8c99e198a  vmovaps [rsp+0x90], xmm10
00007dd8c99e1993  vmovaps [rsp+0xA0], xmm11
00007dd8c99e199c  vmovaps [rsp+0xB0], xmm12
00007dd8c99e19a5  vmovaps [rsp+0xC0], xmm13
00007dd8c99e19ae  vmovaps [rsp+0xD0], xmm14
00007dd8c99e19b7  vmovaps [rsp+0xE0], xmm15
00007dd8c99e19c0  sub rsp, 0x30
00007dd8c99e19c4  movaps [rsp], xmm1
00007dd8c99e19c8  movaps [rsp+0x10], xmm8
00007dd8c99e19ce  movaps [rsp+0x20], xmm9
00007dd8c99e19d4  lea rdi, [rsp]
00007dd8c99e19d8  mov esi, 0x00
00007dd8c99e19dd  mov rax, 0x55FEBBDB5530
00007dd8c99e19e7  call rax
00007dd8c99e19e9  movaps xmm1, [rsp]
00007dd8c99e19ed  add rsp, 0x30
00007dd8c99e19f1  vmovaps xmm0, [rsp]
00007dd8c99e19f6  vmovaps xmm2, [rsp+0x10]
00007dd8c99e19fc  vmovaps xmm3, [rsp+0x20]
00007dd8c99e1a02  vmovaps xmm4, [rsp+0x30]
00007dd8c99e1a08  vmovaps xmm5, [rsp+0x40]
00007dd8c99e1a0e  vmovaps xmm6, [rsp+0x50]
00007dd8c99e1a14  vmovaps xmm7, [rsp+0x60]
00007dd8c99e1a1a  vmovaps xmm8, [rsp+0x70]
00007dd8c99e1a20  vmovaps xmm9, [rsp+0x80]
00007dd8c99e1a29  vmovaps xmm10, [rsp+0x90]
00007dd8c99e1a32  vmovaps xmm11, [rsp+0xA0]
00007dd8c99e1a3b  vmovaps xmm12, [rsp+0xB0]
00007dd8c99e1a44  vmovaps xmm13, [rsp+0xC0]
00007dd8c99e1a4d  vmovaps xmm14, [rsp+0xD0]
00007dd8c99e1a56  vmovaps xmm15, [rsp+0xE0]
00007dd8c99e1a5f  add rsp, 0xF0
00007dd8c99e1a66  pop r11
00007dd8c99e1a68  pop r10
00007dd8c99e1a6a  pop r9
00007dd8c99e1a6c  pop r8
00007dd8c99e1a6e  pop rsi
00007dd8c99e1a6f  pop rdi
00007dd8c99e1a70  pop rdx
00007dd8c99e1a71  pop rcx
00007dd8c99e1a72  pop rax
00007dd8c99e1a73  add rsp, 0x08
00007dd8c99e1a77  jmp 0x00007DD8C99DC865
00007dd8c99e1a7c  call 0x00007DD8C98E5940
00007dd8c99e1a81  jmp 0x00007DD8C99DC873
00007dd8c99e1a86  call 0x00007DD8C980C380
00007dd8c99e1a8b  jmp 0x00007DD8C99DC87D
00007dd8c99e1a90  call 0x00007DD8C980D600
00007dd8c99e1a95  jmp 0x00007DD8C99DC887
00007dd8c99e1a9a  call 0x00007DD8C97FF540
00007dd8c99e1a9f  jmp 0x00007DD8C99DC891
00007dd8c99e1aa4  int3
00007dd8c99e1aa5  nop [rax+rax*1], ax
00007dd8c99e1aae  nop
00007dd8c99e1ab0  mov rax, [r15+0xF8]
00007dd8c99e1ab7  lea r14, [rax+0x140]
00007dd8c99e1abe  mov r12, [r13+r14*1]
00007dd8c99e1ac3  mov [r15+0xE8], r12
00007dd8c99e1aca  lea r14, [rax+0x130]
00007dd8c99e1ad1  mov r12, [r13+r14*1]
00007dd8c99e1ad6  lea r14, [rax+0x138]
00007dd8c99e1add  mov r11, [r13+r14*1]
00007dd8c99e1ae2  movq xmm1, r12
00007dd8c99e1ae7  movq xmm15, r11
00007dd8c99e1aec  movq xmm1, xmm1
00007dd8c99e1af0  movq xmm1, xmm1
00007dd8c99e1af4  movaps [r15+0x1A0], xmm1
00007dd8c99e1afc  movq xmm15, xmm15
00007dd8c99e1b01  movq xmm15, xmm15
00007dd8c99e1b06  movaps [r15+0x190], xmm15
00007dd8c99e1b0e  lea r14, [rax+0x120]
00007dd8c99e1b15  mov r12, [r13+r14*1]
00007dd8c99e1b1a  lea r14, [rax+0x128]
00007dd8c99e1b21  mov r11, [r13+r14*1]
00007dd8c99e1b26  movq xmm1, r12
00007dd8c99e1b2b  movq xmm15, r11
00007dd8c99e1b30  movq xmm1, xmm1
00007dd8c99e1b34  movq xmm1, xmm1
00007dd8c99e1b38  movaps [r15+0x1C0], xmm1
00007dd8c99e1b40  movq xmm15, xmm15
00007dd8c99e1b45  movq xmm15, xmm15
00007dd8c99e1b4a  movaps [r15+0x1B0], xmm15
00007dd8c99e1b52  lea r14, [rax+0x110]
00007dd8c99e1b59  mov r12, [r13+r14*1]
00007dd8c99e1b5e  lea r14, [rax+0x118]
00007dd8c99e1b65  mov r11, [r13+r14*1]
00007dd8c99e1b6a  movq xmm1, r12
00007dd8c99e1b6f  movq xmm15, r11
00007dd8c99e1b74  movq xmm1, xmm1
00007dd8c99e1b78  movq xmm1, xmm1
00007dd8c99e1b7c  movaps [r15+0x1E0], xmm1
00007dd8c99e1b84  movq xmm15, xmm15
00007dd8c99e1b89  movq xmm15, xmm15
00007dd8c99e1b8e  movaps [r15+0x1D0], xmm15
00007dd8c99e1b96  lea r14, [rax+0x100]
00007dd8c99e1b9d  mov r12, [r13+r14*1]
00007dd8c99e1ba2  lea r14, [rax+0x108]
00007dd8c99e1ba9  mov r11, [r13+r14*1]
00007dd8c99e1bae  movq xmm1, r12
00007dd8c99e1bb3  movq xmm15, r11
00007dd8c99e1bb8  movq xmm1, xmm1
00007dd8c99e1bbc  movq xmm1, xmm1
00007dd8c99e1bc0  movaps [r15+0x200], xmm1
00007dd8c99e1bc8  movq xmm15, xmm15
00007dd8c99e1bcd  movq xmm15, xmm15
00007dd8c99e1bd2  movaps [r15+0x1F0], xmm15
00007dd8c99e1bda  mov qword ptr [r15+0x40], 0x430000
00007dd8c99e1be2  mov r14d, 0x430510
00007dd8c99e1be8  mov r12, [r13+r14*1]
00007dd8c99e1bed  movq xmm1, r12
00007dd8c99e1bf2  lea r14, [rax+0x150]
00007dd8c99e1bf9  mov [r15+0xF8], r14
00007dd8c99e1c00  mov rax, [r15+0x50]
00007dd8c99e1c04  movups xmm15, [r13+rax*1]
00007dd8c99e1c0a  movaps [r15+0x120], xmm15
00007dd8c99e1c12  mov qword ptr [r15+0x48], 0x10
00007dd8c99e1c1a  xor eax, eax
00007dd8c99e1c1c  mov r14d, 0x10
00007dd8c99e1c22  mov r12d, 0x200
00007dd8c99e1c28  cmp r14, r12
00007dd8c99e1c2b  cmc
00007dd8c99e1c2c  lahf
00007dd8c99e1c2d  seto al
00007dd8c99e1c30  mov [r15+0x108], eax
00007dd8c99e1c37  pextrq rax, xmm15, 0x01
00007dd8c99e1c3e  movq xmm14, rax
00007dd8c99e1c43  movaps [r15+0x130], xmm14
00007dd8c99e1c4b  movq rax, xmm1
00007dd8c99e1c50  movq r14, xmm15
00007dd8c99e1c55  vmovq xmm1, rax
00007dd8c99e1c5a  vmovq xmm15, r14
00007dd8c99e1c5f  movaps xmm13, xmm1
00007dd8c99e1c63  addsd xmm13, xmm15
00007dd8c99e1c68  ucomisd xmm13, xmm13
00007dd8c99e1c6d  jp 0x00007DD8C99E1D86
00007dd8c99e1c73  movq xmm13, xmm13
00007dd8c99e1c78  movq rax, xmm13
00007dd8c99e1c7d  movq r14, xmm14
00007dd8c99e1c82  vmovq xmm1, rax
00007dd8c99e1c87  vmovq xmm15, r14
00007dd8c99e1c8c  movaps xmm14, xmm1
00007dd8c99e1c90  addsd xmm14, xmm15
00007dd8c99e1c95  ucomisd xmm14, xmm14
00007dd8c99e1c9a  jp 0x00007DD8C99E1DCE
00007dd8c99e1ca0  movq xmm14, xmm14
00007dd8c99e1ca5  movaps [r15+0x110], xmm14
00007dd8c99e1cad  mov eax, [r15+0x108]
00007dd8c99e1cb4  sahf
00007dd8c99e1cb5  jnz 0x00007DD8C99E1CE7
00007dd8c99e1cb7  cmp dword ptr [r15+0x318], 0x00
00007dd8c99e1cbf  jz 0x00007DD8C99E1FE0
00007dd8c99e1cc5  nop [rax+rax*1], ax
00007dd8c99e1cce  nop [rax+rax*1], eax
00007dd8c99e1cd6  mov eax, 0x410490
00007dd8c99e1cdb  mov [r15+0x100], rax
00007dd8c99e1ce2  jmp 0x00007DD8C97FE110
00007dd8c99e1ce7  cmp dword ptr [r15+0x318], 0x00
00007dd8c99e1cef  jz 0x00007DD8C99E1E20
00007dd8c99e1cf5  nop [rax+rax*1], ax
00007dd8c99e1cfe  nop [rax+rax*1], eax
00007dd8c99e1d06  mov eax, 0x410474
00007dd8c99e1d0b  mov [r15+0x100], rax
00007dd8c99e1d12  jmp 0x00007DD8C97FE110
00007dd8c99e1d17  int3
00007dd8c99e1d18  call 0x00007DD8C98E27E0
00007dd8c99e1d1d  jmp 0x00007DD8C99E1AC3
00007dd8c99e1d22  call 0x00007DD8C98E27E0
00007dd8c99e1d27  jmp 0x00007DD8C99E1AD6
00007dd8c99e1d2c  call 0x00007DD8C98E1570
00007dd8c99e1d31  jmp 0x00007DD8C99E1AE2
00007dd8c99e1d36  call 0x00007DD8C98E27E0
00007dd8c99e1d3b  jmp 0x00007DD8C99E1B1A
00007dd8c99e1d40  call 0x00007DD8C98E1570
00007dd8c99e1d45  jmp 0x00007DD8C99E1B26
00007dd8c99e1d4a  call 0x00007DD8C98E27E0
00007dd8c99e1d4f  jmp 0x00007DD8C99E1B5E
00007dd8c99e1d54  call 0x00007DD8C98E1570
00007dd8c99e1d59  jmp 0x00007DD8C99E1B6A
00007dd8c99e1d5e  call 0x00007DD8C98E27E0
00007dd8c99e1d63  jmp 0x00007DD8C99E1BA2
00007dd8c99e1d68  call 0x00007DD8C98E1570
00007dd8c99e1d6d  jmp 0x00007DD8C99E1BAE
00007dd8c99e1d72  call 0x00007DD8C98E27E0
00007dd8c99e1d77  jmp 0x00007DD8C99E1BED
00007dd8c99e1d7c  call 0x00007DD8C980E760
00007dd8c99e1d81  jmp 0x00007DD8C99E1C0A
00007dd8c99e1d86  ucomisd xmm1, xmm15
00007dd8c99e1d8b  jp 0x00007DD8C99E1D9A
00007dd8c99e1d8d  movaps xmm13, [0x00007DD8C95FE060]
00007dd8c99e1d95  jmp 0x00007DD8C99E1C73
00007dd8c99e1d9a  vxorps xmm0, xmm1, xmm15
00007dd8c99e1d9f  pextrw eax, xmm0, 0x03
00007dd8c99e1da4  and eax, 0x7FF8
00007dd8c99e1da9  cmp eax, 0x08
00007dd8c99e1dac  jnz 0x00007DD8C99E1C73
00007dd8c99e1db2  movq rax, xmm15
00007dd8c99e1db7  shl rax, 0x0D
00007dd8c99e1dbb  jbe 0x00007DD8C99E1C73
00007dd8c99e1dc1  vorps xmm13, xmm15, [0x00007DD8C95FE070]
00007dd8c99e1dc9  jmp 0x00007DD8C99E1C73
00007dd8c99e1dce  ucomisd xmm1, xmm15
00007dd8c99e1dd3  jp 0x00007DD8C99E1DE2
00007dd8c99e1dd5  movaps xmm14, [0x00007DD8C95FE060]
00007dd8c99e1ddd  jmp 0x00007DD8C99E1CA0
00007dd8c99e1de2  vxorps xmm0, xmm1, xmm15
00007dd8c99e1de7  pextrw eax, xmm0, 0x03
00007dd8c99e1dec  and eax, 0x7FF8
00007dd8c99e1df1  cmp eax, 0x08
00007dd8c99e1df4  jnz 0x00007DD8C99E1CA0
00007dd8c99e1dfa  movq rax, xmm15
00007dd8c99e1dff  shl rax, 0x0D
00007dd8c99e1e03  jbe 0x00007DD8C99E1CA0
00007dd8c99e1e09  vorps xmm14, xmm15, [0x00007DD8C95FE070]
00007dd8c99e1e11  jmp 0x00007DD8C99E1CA0
00007dd8c99e1e16  int3
00007dd8c99e1e17  nop [rax+rax*1], ax
00007dd8c99e1e20  mov rax, [r15+0x48]
00007dd8c99e1e24  mov r14, [r15+0x50]
00007dd8c99e1e28  lea r12, [r14+rax*1]
00007dd8c99e1e2c  movups xmm1, [r13+r12*1]
00007dd8c99e1e32  movaps [r15+0x120], xmm1
00007dd8c99e1e3a  lea r14, [rax+0x10]
00007dd8c99e1e3e  mov [r15+0x48], r14
00007dd8c99e1e42  xor eax, eax
00007dd8c99e1e44  mov r12d, 0x200
00007dd8c99e1e4a  cmp r14, r12
00007dd8c99e1e4d  cmc
00007dd8c99e1e4e  lahf
00007dd8c99e1e4f  seto al
00007dd8c99e1e52  mov [r15+0x108], eax
00007dd8c99e1e59  pextrq rax, xmm1, 0x01
00007dd8c99e1e60  movq xmm15, rax
00007dd8c99e1e65  movaps [r15+0x130], xmm15
00007dd8c99e1e6d  movaps xmm14, [r15+0x110]
00007dd8c99e1e75  movq rax, xmm14
00007dd8c99e1e7a  movq r14, xmm1
00007dd8c99e1e7f  vmovq xmm1, rax
00007dd8c99e1e84  vmovq xmm14, r14
00007dd8c99e1e89  movaps xmm13, xmm1
00007dd8c99e1e8d  addsd xmm13, xmm14
00007dd8c99e1e92  ucomisd xmm13, xmm13
00007dd8c99e1e97  jp 0x00007DD8C99E1F4C
00007dd8c99e1e9d  movq xmm13, xmm13
00007dd8c99e1ea2  movq rax, xmm13
00007dd8c99e1ea7  movq r14, xmm15
00007dd8c99e1eac  vmovq xmm1, rax
00007dd8c99e1eb1  vmovq xmm15, r14
00007dd8c99e1eb6  movaps xmm14, xmm1
00007dd8c99e1eba  addsd xmm14, xmm15
00007dd8c99e1ebf  ucomisd xmm14, xmm14
00007dd8c99e1ec4  jp 0x00007DD8C99E1F94
00007dd8c99e1eca  movq xmm14, xmm14
00007dd8c99e1ecf  movaps [r15+0x110], xmm14
00007dd8c99e1ed7  mov eax, [r15+0x108]
00007dd8c99e1ede  sahf
00007dd8c99e1edf  jnz 0x00007DD8C99E1F11
00007dd8c99e1ee1  cmp dword ptr [r15+0x318], 0x00
00007dd8c99e1ee9  jz 0x00007DD8C99E1FE0
00007dd8c99e1eef  nop [rax+rax*1], ax
00007dd8c99e1ef8  nop [rax+rax*1], eax
00007dd8c99e1f00  mov eax, 0x410490
00007dd8c99e1f05  mov [r15+0x100], rax
00007dd8c99e1f0c  jmp 0x00007DD8C97FE110
00007dd8c99e1f11  cmp dword ptr [r15+0x318], 0x00
00007dd8c99e1f19  jz 0x00007DD8C99E1E20
00007dd8c99e1f1f  nop [rax+rax*1], ax
00007dd8c99e1f28  nop [rax+rax*1], eax
00007dd8c99e1f30  mov eax, 0x410474
00007dd8c99e1f35  mov [r15+0x100], rax
00007dd8c99e1f3c  jmp 0x00007DD8C97FE110
00007dd8c99e1f41  int3
00007dd8c99e1f42  call 0x00007DD8C98B52F0
00007dd8c99e1f47  jmp 0x00007DD8C99E1E32
00007dd8c99e1f4c  ucomisd xmm1, xmm14
00007dd8c99e1f51  jp 0x00007DD8C99E1F60
00007dd8c99e1f53  movaps xmm13, [0x00007DD8C95FE060]
00007dd8c99e1f5b  jmp 0x00007DD8C99E1E9D
00007dd8c99e1f60  vxorps xmm0, xmm1, xmm14
00007dd8c99e1f65  pextrw eax, xmm0, 0x03
00007dd8c99e1f6a  and eax, 0x7FF8
00007dd8c99e1f6f  cmp eax, 0x08
00007dd8c99e1f72  jnz 0x00007DD8C99E1E9D
00007dd8c99e1f78  movq rax, xmm14
00007dd8c99e1f7d  shl rax, 0x0D
00007dd8c99e1f81  jbe 0x00007DD8C99E1E9D
00007dd8c99e1f87  vorps xmm13, xmm14, [0x00007DD8C95FE070]
00007dd8c99e1f8f  jmp 0x00007DD8C99E1E9D
00007dd8c99e1f94  ucomisd xmm1, xmm15
00007dd8c99e1f99  jp 0x00007DD8C99E1FA8
00007dd8c99e1f9b  movaps xmm14, [0x00007DD8C95FE060]
00007dd8c99e1fa3  jmp 0x00007DD8C99E1ECA
00007dd8c99e1fa8  vxorps xmm0, xmm1, xmm15
00007dd8c99e1fad  pextrw eax, xmm0, 0x03
00007dd8c99e1fb2  and eax, 0x7FF8
00007dd8c99e1fb7  cmp eax, 0x08
00007dd8c99e1fba  jnz 0x00007DD8C99E1ECA
00007dd8c99e1fc0  movq rax, xmm15
00007dd8c99e1fc5  shl rax, 0x0D
00007dd8c99e1fc9  jbe 0x00007DD8C99E1ECA
00007dd8c99e1fcf  vorps xmm14, xmm15, [0x00007DD8C95FE070]
00007dd8c99e1fd7  jmp 0x00007DD8C99E1ECA
00007dd8c99e1fdc  int3
00007dd8c99e1fdd  nop [rax], eax
00007dd8c99e1fe0  mov rax, [r15+0x40]
00007dd8c99e1fe4  lea r14, [rax+0x510]
00007dd8c99e1feb  movaps xmm1, [r15+0x110]
00007dd8c99e1ff3  movq rax, xmm1
00007dd8c99e1ff8  mov [r13+r14*1], rax
00007dd8c99e1ffd  mov rax, [r15+0xF0]
00007dd8c99e2004  mov [r15+0x100], rax
00007dd8c99e200b  jmp 0x00007DD8C99CE5C0
00007dd8c99e2010  int3
00007dd8c99e2011  call 0x00007DD8C98D5EB0
00007dd8c99e2016  jmp 0x00007DD8C99E1FFD
00007dd8c99e201b  int3
00007dd8c99e201c  nop [rax], eax
00007dd8c99e2020  mov qword ptr [r15+0x100], 0x04
00007dd8c99e202b  mov esi, 0x00
00007dd8c99e2030  mov edx, 0x09
00007dd8c99e2035  mov rdi, 0x7FFD989349F0
00007dd8c99e203f  mov rax, 0x55FEBBC48970
00007dd8c99e2049  call rax
00007dd8c99e204b  cmp dword ptr [r15+0x318], 0x00
00007dd8c99e2053  jnz 0x00007DD8C97FE110
00007dd8c99e2059  jmp 0x00007DD8C97FE0A0
00007dd8c99e205e  int3
00007dd8c99e205f  int3
