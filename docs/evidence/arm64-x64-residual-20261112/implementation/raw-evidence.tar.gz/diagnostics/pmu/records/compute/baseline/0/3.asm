
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute/baseline/0/3.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xf8]
  18:	mov    r14,r13
  1b:	add    r14,0x168
  22:	mov    r15,QWORD PTR [r14]
  25:	mov    QWORD PTR [r12+0x40],r15
  2a:	add    r13,0x178
  31:	mov    r14d,0x0
  37:	mov    BYTE PTR [r13+0x0],r14b
  3b:	mov    r13d,0x0
  41:	mov    DWORD PTR [r12+0x32c],r13d
  49:	sub    r15,0x38
  4d:	pushf
  4e:	pop    r11
  50:	mov    QWORD PTR [rsp],r11
  54:	je     0xed
  5a:	jmp    0x5f
  5f:	mov    r13,QWORD PTR [r12+0xf8]
  67:	mov    r14,r13
  6a:	add    r14,0x100
  71:	mov    QWORD PTR [r12],r14
  75:	add    r13,0x178
  7c:	mov    QWORD PTR [r12+0x8],r13
  81:	mov    r13d,0x1
  87:	mov    QWORD PTR [r12+0x10],r13
  8c:	mov    r13d,0x4102c8
  92:	mov    QWORD PTR [r12+0xf0],r13
  9a:	mov    r13d,0x410728
  a0:	mov    QWORD PTR [r12+0x100],r13
  a8:	mov    r11,QWORD PTR [rsp]
  ac:	mov    QWORD PTR [r12+0x398],r11
  b4:	mov    edi,0x410728
  b9:	mov    QWORD PTR [r12+0x100],rdi
  c1:	add    rsp,0x10
  c5:	nop    DWORD PTR [rax]
  c8:	jmp    QWORD PTR [rip+0x2]        # 0xd0
  ce:	xchg   ax,ax
  d0:	(bad)
  d1:	jmp    0x710da165
  d6:	add    BYTE PTR [rax],al
  d8:	rcr    BYTE PTR [rax],1
  da:	nop
  db:	movabs al,ds:0xe0a0bb490000710d
  e4:	retf
  e5:	or     edi,DWORD PTR [rax+0x57]
  e8:	add    BYTE PTR [rax],al
  ea:	jmp    r11
  ed:	mov    r13,QWORD PTR [r12+0x98]
  f5:	ror    r13,0x3d
  f9:	and    r13,0xfffffffffffffff8
  fd:	mov    r14,QWORD PTR [r12+0xf8]
 105:	mov    r15,r14
 108:	add    r15,0x100
 10f:	mov    QWORD PTR [r12],r15
 113:	mov    r15,r14
 116:	add    r15,0x170
 11d:	mov    QWORD PTR [r12+0x8],r15
 122:	mov    r15d,0x8
 128:	mov    QWORD PTR [r12+0x10],r15
 12d:	movabs rcx,0xff00ff00ff00ff
 137:	mov    r15,r13
 13a:	and    r15,rcx
 13d:	shl    r15,0x8
 141:	movabs rcx,0xff00ff00ff00ff00
 14b:	and    r13,rcx
 14e:	shr    r13,0x8
 152:	mov    rcx,r15
 155:	or     r13,rcx
 158:	movabs rcx,0xffff0000ffff
 162:	mov    r15,r13
 165:	and    r15,rcx
 168:	shl    r15,0x10
 16c:	movabs rcx,0xffff0000ffff0000
 176:	and    r13,rcx
 179:	shr    r13,0x10
 17d:	mov    rcx,r15
 180:	or     r13,rcx
 183:	mov    r15,r13
 186:	shl    r15,0x20
 18a:	shr    r13,0x20
 18e:	mov    rcx,r15
 191:	or     r13,rcx
 194:	mov    QWORD PTR [r12+0x40],r13
 199:	add    r14,0x170
 1a0:	mov    QWORD PTR [r14],r13
 1a3:	mov    r13d,0x0
 1a9:	mov    DWORD PTR [r12+0x32c],r13d
 1b1:	mov    r13d,0x4102f0
 1b7:	mov    QWORD PTR [r12+0xf0],r13
 1bf:	mov    r13d,0x410728
 1c5:	mov    QWORD PTR [r12+0x100],r13
 1cd:	mov    r11,QWORD PTR [rsp]
 1d1:	mov    QWORD PTR [r12+0x398],r11
 1d9:	mov    edi,0x410728
 1de:	mov    QWORD PTR [r12+0x100],rdi
 1e6:	add    rsp,0x10
 1ea:	nop    WORD PTR [rax+rax*1+0x0]
 1f0:	jmp    QWORD PTR [rip+0x2]        # 0x1f8
 1f6:	xchg   ax,ax
 1f8:	(bad)
 1f9:	jmp    0x710da28d
 1fe:	add    BYTE PTR [rax],al
 200:	clc
 201:	sbb    DWORD PTR [rax+0x710da0],edx
 207:	add    BYTE PTR [rcx-0x45],cl
 20a:	movabs al,ds:0x41000057780bcbe0
 213:	jmp    rbx
 215:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 220:	sub    rsp,0x10
 224:	mov    r11,QWORD PTR [r12+0x398]
 22c:	mov    QWORD PTR [rsp],r11
 230:	jmp    0x5f
 235:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 240:	sub    rsp,0x10
 244:	mov    r11,QWORD PTR [r12+0x398]
 24c:	mov    QWORD PTR [rsp],r11
 250:	jmp    0xed
 255:	nop
 256:	nop
 257:	nop
