
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-sha/candidate/0/4.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xf8]
  18:	add    r13,0x68
  1c:	mov    r14,QWORD PTR [r13+0x0]
  20:	mov    QWORD PTR [r12+0x40],r14
  25:	sub    r14,0x38
  29:	mov    rcx,QWORD PTR [r12+0x380]
  31:	jrcxz  0x38
  33:	jmp    0x105
  38:	jne    0x51
  3e:	mov    r11,rax
  41:	lahf
  42:	seto   al
  45:	mov    WORD PTR [rsp],ax
  49:	mov    rax,r11
  4c:	jmp    0x64
  51:	mov    r11,rax
  54:	lahf
  55:	seto   al
  58:	mov    WORD PTR [rsp],ax
  5c:	mov    rax,r11
  5f:	jmp    0xb5
  64:	mov    r13d,0x4102c4
  6a:	mov    QWORD PTR [r12+0x100],r13
  72:	mov    r11,QWORD PTR [rsp]
  76:	mov    QWORD PTR [r12+0x398],r11
  7e:	mov    edi,0x4102c4
  83:	mov    QWORD PTR [r12+0x100],rdi
  8b:	add    rsp,0x10
  8f:	nop
  90:	jmp    QWORD PTR [rip+0x2]        # 0x98
  96:	xchg   ax,ax
  98:	adc    BYTE PTR [rdi],cl
  9a:	lock sbb eax,0x7da1
  a0:	fmul   DWORD PTR [rdi]
  a2:	lock sbb eax,0x7da1
  a8:	movabs r11,0x580415130940
  b2:	jmp    r11
  b5:	mov    r13d,0x4102a8
  bb:	mov    QWORD PTR [r12+0x100],r13
  c3:	mov    r11,QWORD PTR [rsp]
  c7:	mov    QWORD PTR [r12+0x398],r11
  cf:	mov    edi,0x4102a8
  d4:	mov    QWORD PTR [r12+0x100],rdi
  dc:	add    rsp,0x10
  e0:	jmp    QWORD PTR [rip+0x2]        # 0xe8
  e6:	xchg   ax,ax
  e8:	lock (bad)
  ea:	lock sbb eax,0x7da1
  f0:	sub    BYTE PTR [rax],dl
  f2:	lock sbb eax,0x7da1
  f8:	movabs r11,0x580415130940
 102:	jmp    r11
 105:	mov    eax,0x4102c0
 10a:	mov    QWORD PTR [r12+0x100],rax
 112:	push   rdx
 113:	push   rsi
 114:	push   r10
 116:	push   r11
 118:	mov    r11,rax
 11b:	lahf
 11c:	seto   al
 11f:	mov    WORD PTR [rsp+0x20],ax
 124:	mov    rax,r11
 127:	mov    rdx,QWORD PTR [rsp+0x20]
 12c:	mov    r10d,edx
 12f:	and    r10d,0xc000
 136:	shl    r10d,0x10
 13a:	mov    r11d,edx
 13d:	and    r11d,0x100
 144:	shl    r11d,0x15
 148:	or     r10d,r11d
 14b:	and    edx,0x1
 14e:	shl    edx,0x1c
 151:	or     r10d,edx
 154:	btc    r10,0x1d
 159:	mov    r11d,0xf0000000
 15f:	and    r11,r10
 162:	movabs rsi,0xffffffff0fffffff
 16c:	and    rbx,rsi
 16f:	or     rbx,r11
 172:	pop    r11
 174:	pop    r10
 176:	pop    rsi
 177:	pop    rdx
 178:	mov    QWORD PTR [r12+0x108],rbx
 180:	add    rsp,0x10
 184:	mov    eax,0xc
 189:	movabs r11,0x580415130ca0
 193:	jmp    r11
 196:	nop
 197:	nop
