
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-sha/candidate/0/1.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	sub    rsp,0xc0
       7:	mov    r11,QWORD PTR [r12+0x398]
       f:	mov    QWORD PTR [rsp+0xb0],r11
      17:	mov    r13,QWORD PTR [r12]
      1b:	mov    r14,r13
      1e:	add    r14,0x20
      22:	mov    r15,QWORD PTR [r14]
      25:	mov    r14,QWORD PTR [r12+0x10]
      2a:	add    r15,r14
      2d:	mov    QWORD PTR [r12+0x40],r15
      32:	add    r13,0x20
      36:	mov    QWORD PTR [r13+0x0],r15
      3a:	mov    r13d,0x0
      40:	mov    DWORD PTR [r12+0x32c],r13d
      48:	mov    rax,r14
      4b:	test   rax,rax
      4e:	je     0x2155
      54:	jmp    0x59
      59:	mov    r13,QWORD PTR [r12+0xf8]
      61:	sub    r13,0x150
      68:	mov    QWORD PTR [r12+0xf8],r13
      70:	mov    r14,QWORD PTR [r12]
      74:	mov    r15,r14
      77:	add    r15,0x68
      7b:	mov    rbp,QWORD PTR [r15]
      7e:	mov    QWORD PTR [r12+0x88],rbp
      86:	add    r14,0x28
      8a:	mov    QWORD PTR [r12+0x40],r14
      8f:	mov    QWORD PTR [r12+0x48],r13
      94:	mov    r14d,0x420000
      9a:	add    r14,0x758
      a1:	mov    QWORD PTR [r12+0x50],r14
      a6:	mov    r14,r13
      a9:	add    r14,0x100
      b0:	mov    r15,r14
      b3:	add    r15,0x8
      b7:	mov    rbp,QWORD PTR [r12+0xe8]
      bf:	mov    r8,QWORD PTR [r12+0xd8]
      c7:	mov    QWORD PTR [r14],rbp
      ca:	mov    r14d,0x0
      d0:	mov    DWORD PTR [r12+0x32c],r14d
      d8:	mov    QWORD PTR [r15],r8
      db:	mov    r14,r13
      de:	add    r14,0x110
      e5:	mov    r15,r14
      e8:	add    r15,0x8
      ec:	mov    rbp,QWORD PTR [r12+0xd0]
      f4:	mov    r8,QWORD PTR [r12+0xc8]
      fc:	mov    QWORD PTR [r14],rbp
      ff:	mov    QWORD PTR [r15],r8
     102:	mov    r14,r13
     105:	add    r14,0x120
     10c:	mov    r15,r14
     10f:	add    r15,0x8
     113:	mov    rbp,QWORD PTR [r12+0xc0]
     11b:	mov    r8,QWORD PTR [r12+0xb8]
     123:	mov    QWORD PTR [r14],rbp
     126:	mov    QWORD PTR [r15],r8
     129:	mov    r14,r13
     12c:	add    r14,0x130
     133:	mov    r15,r14
     136:	add    r15,0x8
     13a:	mov    rbp,QWORD PTR [r12+0xb0]
     142:	mov    r8,QWORD PTR [r12+0xa8]
     14a:	mov    QWORD PTR [r14],rbp
     14d:	mov    QWORD PTR [r15],r8
     150:	add    r13,0x140
     157:	mov    r14,r13
     15a:	add    r14,0x8
     15e:	mov    r15,QWORD PTR [r12+0xa0]
     166:	mov    rbp,QWORD PTR [r12+0x98]
     16e:	mov    QWORD PTR [r13+0x0],r15
     172:	mov    QWORD PTR [r14],rbp
     175:	jmp    0x17a
     17a:	mov    r13,QWORD PTR [r12+0x8]
     17f:	mov    r14,r13
     182:	add    r14,0x1
     186:	movzx  r15d,BYTE PTR [r13+0x0]
     18b:	mov    QWORD PTR [r12+0x58],r15
     190:	mov    QWORD PTR [r12+0x8],r14
     195:	mov    r13,QWORD PTR [r12+0x88]
     19d:	mov    r14,r13
     1a0:	add    r14,0x1
     1a4:	mov    QWORD PTR [r12+0x60],r14
     1a9:	mov    r15,QWORD PTR [r12]
     1ad:	mov    rbp,r15
     1b0:	add    rbp,0x68
     1b4:	mov    QWORD PTR [rbp+0x0],r14
     1b8:	mov    r14d,0x0
     1be:	mov    DWORD PTR [r12+0x32c],r14d
     1c6:	mov    r14,r15
     1c9:	add    r14,r13
     1cc:	mov    QWORD PTR [r12+0x60],r14
     1d1:	add    r14,0x28
     1d5:	movzx  r13d,BYTE PTR [r12+0x58]
     1db:	mov    BYTE PTR [r14],r13b
     1de:	add    r15,0x68
     1e2:	mov    r13,QWORD PTR [r15]
     1e5:	mov    QWORD PTR [r12+0x88],r13
     1ed:	sub    r13,0x40
     1f1:	mov    rcx,QWORD PTR [r12+0x380]
     1f9:	jrcxz  0x200
     1fb:	jmp    0x21a0
     200:	jne    0x21d
     206:	mov    r11,rax
     209:	lahf
     20a:	seto   al
     20d:	mov    WORD PTR [rsp+0xb0],ax
     215:	mov    rax,r11
     218:	jmp    0x234
     21d:	mov    r11,rax
     220:	lahf
     221:	seto   al
     224:	mov    WORD PTR [rsp+0xb0],ax
     22c:	mov    rax,r11
     22f:	jmp    0x2057
     234:	mov    rax,QWORD PTR [r12+0x40]
     239:	mov    eax,0x0
     23e:	mov    QWORD PTR [rsp+0x18],rax
     243:	mov    eax,0x0
     248:	mov    QWORD PTR [rsp+0x10],rax
     24d:	mov    eax,0x0
     252:	mov    QWORD PTR [rsp+0x8],rax
     257:	mov    eax,0x0
     25c:	mov    QWORD PTR [rsp],rax
     260:	mov    rdi,QWORD PTR [r12+0x40]
     265:	movzx  r9d,BYTE PTR [rdi]
     269:	mov    r13,QWORD PTR [rsp+0x18]
     26e:	or     r13,r9
     271:	mov    r9,QWORD PTR [r12+0x40]
     276:	add    r9,0x1
     27a:	movzx  r8d,BYTE PTR [r9]
     27e:	mov    r9,QWORD PTR [rsp+0x10]
     283:	or     r9,r8
     286:	mov    r8,QWORD PTR [r12+0x40]
     28b:	add    r8,0x2
     28f:	movzx  ebp,BYTE PTR [r8]
     293:	mov    r8,QWORD PTR [rsp+0x8]
     298:	or     r8,rbp
     29b:	mov    rbp,QWORD PTR [r12+0x40]
     2a0:	add    rbp,0x3
     2a4:	movzx  r15d,BYTE PTR [rbp+0x0]
     2a9:	mov    rbp,QWORD PTR [rsp]
     2ad:	or     rbp,r15
     2b0:	mov    r15,QWORD PTR [r12+0x40]
     2b5:	add    r15,0x4
     2b9:	movzx  r14d,BYTE PTR [r15]
     2bd:	mov    r15,r14
     2c0:	shl    r15,0x8
     2c4:	or     r13,r15
     2c7:	mov    r14,QWORD PTR [r12+0x40]
     2cc:	add    r14,0x5
     2d0:	movzx  r15d,BYTE PTR [r14]
     2d4:	mov    r14,r15
     2d7:	shl    r14,0x8
     2db:	or     r9,r14
     2de:	mov    r14,QWORD PTR [r12+0x40]
     2e3:	add    r14,0x6
     2e7:	movzx  r15d,BYTE PTR [r14]
     2eb:	mov    r14,r15
     2ee:	shl    r14,0x8
     2f2:	or     r8,r14
     2f5:	mov    r14,QWORD PTR [r12+0x40]
     2fa:	add    r14,0x7
     2fe:	movzx  r15d,BYTE PTR [r14]
     302:	mov    r14,r15
     305:	shl    r14,0x8
     309:	or     rbp,r14
     30c:	mov    r14,QWORD PTR [r12+0x40]
     311:	add    r14,0x8
     315:	movzx  r15d,BYTE PTR [r14]
     319:	mov    r14,r15
     31c:	shl    r14,0x10
     320:	or     r13,r14
     323:	mov    r14,QWORD PTR [r12+0x40]
     328:	add    r14,0x9
     32c:	movzx  r15d,BYTE PTR [r14]
     330:	mov    r14,r15
     333:	shl    r14,0x10
     337:	or     r9,r14
     33a:	mov    r14,QWORD PTR [r12+0x40]
     33f:	add    r14,0xa
     343:	movzx  r15d,BYTE PTR [r14]
     347:	mov    r14,r15
     34a:	shl    r14,0x10
     34e:	or     r8,r14
     351:	mov    r14,QWORD PTR [r12+0x40]
     356:	add    r14,0xb
     35a:	movzx  r15d,BYTE PTR [r14]
     35e:	mov    r14,r15
     361:	shl    r14,0x10
     365:	or     rbp,r14
     368:	mov    r14,QWORD PTR [r12+0x40]
     36d:	add    r14,0xc
     371:	movzx  r15d,BYTE PTR [r14]
     375:	mov    r14,r15
     378:	shl    r14,0x18
     37c:	or     r13,r14
     37f:	mov    r14,QWORD PTR [r12+0x40]
     384:	add    r14,0xd
     388:	movzx  r15d,BYTE PTR [r14]
     38c:	mov    r14,r15
     38f:	shl    r14,0x18
     393:	or     r9,r14
     396:	mov    r14,QWORD PTR [r12+0x40]
     39b:	add    r14,0xe
     39f:	movzx  r15d,BYTE PTR [r14]
     3a3:	mov    r14,r15
     3a6:	shl    r14,0x18
     3aa:	or     r8,r14
     3ad:	mov    r14,QWORD PTR [r12+0x40]
     3b2:	add    r14,0xf
     3b6:	movzx  r15d,BYTE PTR [r14]
     3ba:	mov    r14,r15
     3bd:	shl    r14,0x18
     3c1:	or     rbp,r14
     3c4:	mov    r14,QWORD PTR [r12+0x40]
     3c9:	add    r14,0x10
     3cd:	movzx  r15d,BYTE PTR [r14]
     3d1:	mov    r14,r15
     3d4:	shl    r14,0x20
     3d8:	or     r13,r14
     3db:	mov    r14,QWORD PTR [r12+0x40]
     3e0:	add    r14,0x11
     3e4:	movzx  r15d,BYTE PTR [r14]
     3e8:	mov    r14,r15
     3eb:	shl    r14,0x20
     3ef:	or     r9,r14
     3f2:	mov    r14,QWORD PTR [r12+0x40]
     3f7:	add    r14,0x12
     3fb:	movzx  r15d,BYTE PTR [r14]
     3ff:	mov    r14,r15
     402:	shl    r14,0x20
     406:	or     r8,r14
     409:	mov    r14,QWORD PTR [r12+0x40]
     40e:	add    r14,0x13
     412:	movzx  r15d,BYTE PTR [r14]
     416:	mov    r14,r15
     419:	shl    r14,0x20
     41d:	or     rbp,r14
     420:	mov    r14,QWORD PTR [r12+0x40]
     425:	add    r14,0x14
     429:	movzx  r15d,BYTE PTR [r14]
     42d:	mov    r14,r15
     430:	shl    r14,0x28
     434:	or     r13,r14
     437:	mov    r14,QWORD PTR [r12+0x40]
     43c:	add    r14,0x15
     440:	movzx  r15d,BYTE PTR [r14]
     444:	mov    r14,r15
     447:	shl    r14,0x28
     44b:	or     r9,r14
     44e:	mov    r14,QWORD PTR [r12+0x40]
     453:	add    r14,0x16
     457:	movzx  r15d,BYTE PTR [r14]
     45b:	mov    r14,r15
     45e:	shl    r14,0x28
     462:	or     r8,r14
     465:	mov    r14,QWORD PTR [r12+0x40]
     46a:	add    r14,0x17
     46e:	movzx  r15d,BYTE PTR [r14]
     472:	mov    r14,r15
     475:	shl    r14,0x28
     479:	or     rbp,r14
     47c:	mov    r14,QWORD PTR [r12+0x40]
     481:	add    r14,0x18
     485:	movzx  r15d,BYTE PTR [r14]
     489:	mov    r14,r15
     48c:	shl    r14,0x30
     490:	or     r13,r14
     493:	mov    r14,QWORD PTR [r12+0x40]
     498:	add    r14,0x19
     49c:	movzx  r15d,BYTE PTR [r14]
     4a0:	mov    r14,r15
     4a3:	shl    r14,0x30
     4a7:	or     r9,r14
     4aa:	mov    r14,QWORD PTR [r12+0x40]
     4af:	add    r14,0x1a
     4b3:	movzx  r15d,BYTE PTR [r14]
     4b7:	mov    r14,r15
     4ba:	shl    r14,0x30
     4be:	or     r8,r14
     4c1:	mov    r14,QWORD PTR [r12+0x40]
     4c6:	add    r14,0x1b
     4ca:	movzx  r15d,BYTE PTR [r14]
     4ce:	mov    r14,r15
     4d1:	shl    r14,0x30
     4d5:	or     rbp,r14
     4d8:	mov    r14,QWORD PTR [r12+0x40]
     4dd:	add    r14,0x1c
     4e1:	movzx  r15d,BYTE PTR [r14]
     4e5:	mov    r14,r15
     4e8:	shl    r14,0x38
     4ec:	mov    rax,r13
     4ef:	or     rax,r14
     4f2:	mov    QWORD PTR [rsp+0x28],rax
     4f7:	mov    r14,QWORD PTR [r12+0x40]
     4fc:	add    r14,0x1d
     500:	movzx  r15d,BYTE PTR [r14]
     504:	mov    r14,r15
     507:	shl    r14,0x38
     50b:	mov    rax,r9
     50e:	or     rax,r14
     511:	mov    QWORD PTR [rsp+0x38],rax
     516:	mov    r14,QWORD PTR [r12+0x40]
     51b:	add    r14,0x1e
     51f:	movzx  r15d,BYTE PTR [r14]
     523:	mov    r14,r15
     526:	shl    r14,0x38
     52a:	mov    rax,r8
     52d:	or     rax,r14
     530:	mov    QWORD PTR [rsp+0x30],rax
     535:	mov    r14,QWORD PTR [r12+0x40]
     53a:	add    r14,0x1f
     53e:	movzx  r15d,BYTE PTR [r14]
     542:	mov    r14,r15
     545:	shl    r14,0x38
     549:	mov    rax,rbp
     54c:	or     rax,r14
     54f:	mov    QWORD PTR [rsp+0x20],rax
     554:	mov    r14,QWORD PTR [r12+0x40]
     559:	add    r14,0x20
     55d:	movzx  r15d,BYTE PTR [r14]
     561:	mov    r14,QWORD PTR [rsp+0x18]
     566:	or     r14,r15
     569:	mov    r15,QWORD PTR [r12+0x40]
     56e:	add    r15,0x21
     572:	movzx  ebp,BYTE PTR [r15]
     576:	mov    r15,QWORD PTR [rsp+0x10]
     57b:	or     r15,rbp
     57e:	mov    rbp,QWORD PTR [r12+0x40]
     583:	add    rbp,0x22
     587:	movzx  r13d,BYTE PTR [rbp+0x0]
     58c:	mov    rbp,QWORD PTR [rsp+0x8]
     591:	or     rbp,r13
     594:	mov    r13,QWORD PTR [r12+0x40]
     599:	add    r13,0x23
     59d:	movzx  r8d,BYTE PTR [r13+0x0]
     5a2:	mov    r13,QWORD PTR [rsp]
     5a6:	or     r13,r8
     5a9:	mov    r8,QWORD PTR [r12+0x40]
     5ae:	add    r8,0x24
     5b2:	movzx  r9d,BYTE PTR [r8]
     5b6:	mov    r8,r9
     5b9:	shl    r8,0x8
     5bd:	or     r14,r8
     5c0:	mov    r8,QWORD PTR [r12+0x40]
     5c5:	add    r8,0x25
     5c9:	movzx  r9d,BYTE PTR [r8]
     5cd:	mov    r8,r9
     5d0:	shl    r8,0x8
     5d4:	or     r15,r8
     5d7:	mov    r8,QWORD PTR [r12+0x40]
     5dc:	add    r8,0x26
     5e0:	movzx  r9d,BYTE PTR [r8]
     5e4:	mov    r8,r9
     5e7:	shl    r8,0x8
     5eb:	or     rbp,r8
     5ee:	mov    r8,QWORD PTR [r12+0x40]
     5f3:	add    r8,0x27
     5f7:	movzx  r9d,BYTE PTR [r8]
     5fb:	mov    r8,r9
     5fe:	shl    r8,0x8
     602:	or     r13,r8
     605:	mov    r8,QWORD PTR [r12+0x40]
     60a:	add    r8,0x28
     60e:	movzx  r9d,BYTE PTR [r8]
     612:	mov    r8,r9
     615:	shl    r8,0x10
     619:	or     r14,r8
     61c:	mov    r8,QWORD PTR [r12+0x40]
     621:	add    r8,0x29
     625:	movzx  r9d,BYTE PTR [r8]
     629:	mov    r8,r9
     62c:	shl    r8,0x10
     630:	or     r15,r8
     633:	mov    r8,QWORD PTR [r12+0x40]
     638:	add    r8,0x2a
     63c:	movzx  r9d,BYTE PTR [r8]
     640:	mov    r8,r9
     643:	shl    r8,0x10
     647:	or     rbp,r8
     64a:	mov    r8,QWORD PTR [r12+0x40]
     64f:	add    r8,0x2b
     653:	movzx  r9d,BYTE PTR [r8]
     657:	mov    r8,r9
     65a:	shl    r8,0x10
     65e:	or     r13,r8
     661:	mov    r8,QWORD PTR [r12+0x40]
     666:	add    r8,0x2c
     66a:	movzx  r9d,BYTE PTR [r8]
     66e:	mov    r8,r9
     671:	shl    r8,0x18
     675:	or     r14,r8
     678:	mov    r8,QWORD PTR [r12+0x40]
     67d:	add    r8,0x2d
     681:	movzx  r9d,BYTE PTR [r8]
     685:	mov    r8,r9
     688:	shl    r8,0x18
     68c:	or     r15,r8
     68f:	mov    r8,QWORD PTR [r12+0x40]
     694:	add    r8,0x2e
     698:	movzx  r9d,BYTE PTR [r8]
     69c:	mov    r8,r9
     69f:	shl    r8,0x18
     6a3:	or     rbp,r8
     6a6:	mov    r8,QWORD PTR [r12+0x40]
     6ab:	add    r8,0x2f
     6af:	movzx  r9d,BYTE PTR [r8]
     6b3:	mov    r8,r9
     6b6:	shl    r8,0x18
     6ba:	or     r13,r8
     6bd:	mov    r8,QWORD PTR [r12+0x40]
     6c2:	add    r8,0x30
     6c6:	movzx  r9d,BYTE PTR [r8]
     6ca:	mov    r8,r9
     6cd:	shl    r8,0x20
     6d1:	or     r14,r8
     6d4:	mov    r8,QWORD PTR [r12+0x40]
     6d9:	add    r8,0x31
     6dd:	movzx  r9d,BYTE PTR [r8]
     6e1:	mov    r8,r9
     6e4:	shl    r8,0x20
     6e8:	or     r15,r8
     6eb:	mov    r8,QWORD PTR [r12+0x40]
     6f0:	add    r8,0x32
     6f4:	movzx  r9d,BYTE PTR [r8]
     6f8:	mov    r8,r9
     6fb:	shl    r8,0x20
     6ff:	or     rbp,r8
     702:	mov    r8,QWORD PTR [r12+0x40]
     707:	add    r8,0x33
     70b:	movzx  r9d,BYTE PTR [r8]
     70f:	mov    r8,r9
     712:	shl    r8,0x20
     716:	or     r13,r8
     719:	mov    r8,QWORD PTR [r12+0x40]
     71e:	add    r8,0x34
     722:	movzx  r9d,BYTE PTR [r8]
     726:	mov    r8,r9
     729:	shl    r8,0x28
     72d:	or     r14,r8
     730:	mov    r8,QWORD PTR [r12+0x40]
     735:	add    r8,0x35
     739:	movzx  r9d,BYTE PTR [r8]
     73d:	mov    r8,r9
     740:	shl    r8,0x28
     744:	or     r15,r8
     747:	mov    r8,QWORD PTR [r12+0x40]
     74c:	add    r8,0x36
     750:	movzx  r9d,BYTE PTR [r8]
     754:	mov    r8,r9
     757:	shl    r8,0x28
     75b:	or     rbp,r8
     75e:	mov    r8,QWORD PTR [r12+0x40]
     763:	add    r8,0x37
     767:	movzx  r9d,BYTE PTR [r8]
     76b:	mov    r8,r9
     76e:	shl    r8,0x28
     772:	or     r13,r8
     775:	mov    r8,QWORD PTR [r12+0x40]
     77a:	add    r8,0x38
     77e:	movzx  r9d,BYTE PTR [r8]
     782:	mov    r8,r9
     785:	shl    r8,0x30
     789:	or     r14,r8
     78c:	mov    r8,QWORD PTR [r12+0x40]
     791:	add    r8,0x39
     795:	movzx  r9d,BYTE PTR [r8]
     799:	mov    r8,r9
     79c:	shl    r8,0x30
     7a0:	or     r15,r8
     7a3:	mov    r8,QWORD PTR [r12+0x40]
     7a8:	add    r8,0x3a
     7ac:	movzx  r9d,BYTE PTR [r8]
     7b0:	mov    r8,r9
     7b3:	shl    r8,0x30
     7b7:	or     rbp,r8
     7ba:	mov    r8,QWORD PTR [r12+0x40]
     7bf:	add    r8,0x3b
     7c3:	movzx  r9d,BYTE PTR [r8]
     7c7:	mov    r8,r9
     7ca:	shl    r8,0x30
     7ce:	or     r13,r8
     7d1:	mov    r8,QWORD PTR [r12+0x40]
     7d6:	add    r8,0x3c
     7da:	movzx  r9d,BYTE PTR [r8]
     7de:	mov    r8,r9
     7e1:	shl    r8,0x38
     7e5:	or     r14,r8
     7e8:	mov    r8,QWORD PTR [r12+0x40]
     7ed:	add    r8,0x3d
     7f1:	movzx  r9d,BYTE PTR [r8]
     7f5:	mov    r8,r9
     7f8:	shl    r8,0x38
     7fc:	or     r15,r8
     7ff:	mov    r8,QWORD PTR [r12+0x40]
     804:	add    r8,0x3e
     808:	movzx  r9d,BYTE PTR [r8]
     80c:	mov    r8,r9
     80f:	shl    r8,0x38
     813:	or     rbp,r8
     816:	mov    r8,QWORD PTR [r12+0x40]
     81b:	add    r8,0x3f
     81f:	movzx  r9d,BYTE PTR [r8]
     823:	mov    r8,r9
     826:	shl    r8,0x38
     82a:	mov    rax,r13
     82d:	or     rax,r8
     830:	mov    QWORD PTR [rsp+0x40],rax
     835:	mov    r8d,0x0
     83b:	mov    QWORD PTR [r12+0x58],r8
     840:	mov    r8d,0x0
     846:	mov    r9,QWORD PTR [rsp+0x38]
     84b:	and    r9,0xff
     852:	and    r9,0xffff
     859:	mov    r13,r8
     85c:	or     r13,r9
     85f:	mov    r9,QWORD PTR [rsp+0x38]
     864:	shr    r9,0x8
     868:	and    r9,0xff
     86f:	and    r9,0xffff
     876:	shl    r9,0x10
     87a:	or     r13,r9
     87d:	mov    r9,QWORD PTR [rsp+0x38]
     882:	shr    r9,0x10
     886:	and    r9,0xff
     88d:	and    r9,0xffff
     894:	shl    r9,0x20
     898:	or     r13,r9
     89b:	mov    r9,QWORD PTR [rsp+0x38]
     8a0:	shr    r9,0x18
     8a4:	and    r9,0xff
     8ab:	and    r9,0xffff
     8b2:	shl    r9,0x30
     8b6:	or     r13,r9
     8b9:	mov    r9,QWORD PTR [rsp+0x38]
     8be:	shr    r9,0x20
     8c2:	and    r9,0xff
     8c9:	and    r9,0xffff
     8d0:	or     r8,r9
     8d3:	mov    r9,QWORD PTR [rsp+0x38]
     8d8:	shr    r9,0x28
     8dc:	and    r9,0xff
     8e3:	and    r9,0xffff
     8ea:	shl    r9,0x10
     8ee:	or     r8,r9
     8f1:	mov    r9,QWORD PTR [rsp+0x38]
     8f6:	shr    r9,0x30
     8fa:	and    r9,0xff
     901:	and    r9,0xffff
     908:	shl    r9,0x20
     90c:	or     r8,r9
     90f:	mov    r9,QWORD PTR [rsp+0x38]
     914:	shr    r9,0x38
     918:	and    r9,0xff
     91f:	and    r9,0xffff
     926:	shl    r9,0x30
     92a:	or     r8,r9
     92d:	mov    QWORD PTR [r12+0x150],r13
     935:	mov    QWORD PTR [r12+0x158],r8
     93d:	mov    r13d,0x0
     943:	mov    r8,QWORD PTR [rsp+0x30]
     948:	and    r8,0xff
     94f:	and    r8,0xffff
     956:	mov    r9,r13
     959:	or     r9,r8
     95c:	mov    r8,QWORD PTR [rsp+0x30]
     961:	shr    r8,0x8
     965:	and    r8,0xff
     96c:	and    r8,0xffff
     973:	shl    r8,0x10
     977:	or     r9,r8
     97a:	mov    r8,QWORD PTR [rsp+0x30]
     97f:	shr    r8,0x10
     983:	and    r8,0xff
     98a:	and    r8,0xffff
     991:	shl    r8,0x20
     995:	or     r9,r8
     998:	mov    r8,QWORD PTR [rsp+0x30]
     99d:	shr    r8,0x18
     9a1:	and    r8,0xff
     9a8:	and    r8,0xffff
     9af:	shl    r8,0x30
     9b3:	mov    rax,r9
     9b6:	or     rax,r8
     9b9:	mov    QWORD PTR [rsp+0x50],rax
     9be:	mov    r8,QWORD PTR [rsp+0x30]
     9c3:	shr    r8,0x20
     9c7:	and    r8,0xff
     9ce:	and    r8,0xffff
     9d5:	or     r13,r8
     9d8:	mov    r8,QWORD PTR [rsp+0x30]
     9dd:	shr    r8,0x28
     9e1:	and    r8,0xff
     9e8:	and    r8,0xffff
     9ef:	shl    r8,0x10
     9f3:	or     r13,r8
     9f6:	mov    r8,QWORD PTR [rsp+0x30]
     9fb:	shr    r8,0x30
     9ff:	and    r8,0xff
     a06:	and    r8,0xffff
     a0d:	shl    r8,0x20
     a11:	or     r13,r8
     a14:	mov    r8,QWORD PTR [rsp+0x30]
     a19:	shr    r8,0x38
     a1d:	and    r8,0xff
     a24:	and    r8,0xffff
     a2b:	shl    r8,0x30
     a2f:	mov    rax,r13
     a32:	or     rax,r8
     a35:	mov    QWORD PTR [rsp+0x48],rax
     a3a:	mov    r8d,0x0
     a40:	mov    r13,QWORD PTR [rsp+0x28]
     a45:	and    r13,0xff
     a4c:	and    r13,0xffff
     a53:	mov    r9,r8
     a56:	or     r9,r13
     a59:	mov    r13,QWORD PTR [rsp+0x28]
     a5e:	shr    r13,0x8
     a62:	and    r13,0xff
     a69:	and    r13,0xffff
     a70:	shl    r13,0x10
     a74:	or     r9,r13
     a77:	mov    r13,QWORD PTR [rsp+0x28]
     a7c:	shr    r13,0x10
     a80:	and    r13,0xff
     a87:	and    r13,0xffff
     a8e:	shl    r13,0x20
     a92:	or     r9,r13
     a95:	mov    r13,QWORD PTR [rsp+0x28]
     a9a:	shr    r13,0x18
     a9e:	and    r13,0xff
     aa5:	and    r13,0xffff
     aac:	shl    r13,0x30
     ab0:	mov    rax,r9
     ab3:	or     rax,r13
     ab6:	mov    QWORD PTR [rsp+0x58],rax
     abb:	mov    r13,QWORD PTR [rsp+0x28]
     ac0:	shr    r13,0x20
     ac4:	and    r13,0xff
     acb:	and    r13,0xffff
     ad2:	or     r8,r13
     ad5:	mov    r13,QWORD PTR [rsp+0x28]
     ada:	shr    r13,0x28
     ade:	and    r13,0xff
     ae5:	and    r13,0xffff
     aec:	shl    r13,0x10
     af0:	or     r8,r13
     af3:	mov    r13,QWORD PTR [rsp+0x28]
     af8:	shr    r13,0x30
     afc:	and    r13,0xff
     b03:	and    r13,0xffff
     b0a:	shl    r13,0x20
     b0e:	or     r8,r13
     b11:	mov    r13,QWORD PTR [rsp+0x28]
     b16:	shr    r13,0x38
     b1a:	and    r13,0xff
     b21:	and    r13,0xffff
     b28:	shl    r13,0x30
     b2c:	mov    rax,r8
     b2f:	or     rax,r13
     b32:	mov    QWORD PTR [rsp+0x60],rax
     b37:	mov    r13d,0x0
     b3d:	mov    r9,r14
     b40:	and    r9,0xff
     b47:	and    r9,0xffff
     b4e:	mov    r8,r13
     b51:	or     r8,r9
     b54:	mov    r9,r14
     b57:	shr    r9,0x8
     b5b:	and    r9,0xff
     b62:	and    r9,0xffff
     b69:	shl    r9,0x10
     b6d:	or     r8,r9
     b70:	mov    r9,r14
     b73:	shr    r9,0x10
     b77:	and    r9,0xff
     b7e:	and    r9,0xffff
     b85:	shl    r9,0x20
     b89:	or     r8,r9
     b8c:	mov    r9,r14
     b8f:	shr    r9,0x18
     b93:	and    r9,0xff
     b9a:	and    r9,0xffff
     ba1:	shl    r9,0x30
     ba5:	mov    rax,r8
     ba8:	or     rax,r9
     bab:	mov    QWORD PTR [rsp+0x68],rax
     bb0:	mov    r9,r14
     bb3:	shr    r9,0x20
     bb7:	and    r9,0xff
     bbe:	and    r9,0xffff
     bc5:	or     r13,r9
     bc8:	mov    r9,r14
     bcb:	shr    r9,0x28
     bcf:	and    r9,0xff
     bd6:	and    r9,0xffff
     bdd:	shl    r9,0x10
     be1:	or     r13,r9
     be4:	mov    r9,r14
     be7:	shr    r9,0x30
     beb:	and    r9,0xff
     bf2:	and    r9,0xffff
     bf9:	shl    r9,0x20
     bfd:	or     r13,r9
     c00:	shr    r14,0x38
     c04:	and    r14,0xff
     c0b:	and    r14,0xffff
     c12:	shl    r14,0x30
     c16:	or     r13,r14
     c19:	mov    r14d,0x0
     c1f:	mov    r9,r15
     c22:	and    r9,0xff
     c29:	and    r9,0xffff
     c30:	mov    r8,r14
     c33:	or     r8,r9
     c36:	mov    r9,r15
     c39:	shr    r9,0x8
     c3d:	and    r9,0xff
     c44:	and    r9,0xffff
     c4b:	shl    r9,0x10
     c4f:	or     r8,r9
     c52:	mov    r9,r15
     c55:	shr    r9,0x10
     c59:	and    r9,0xff
     c60:	and    r9,0xffff
     c67:	shl    r9,0x20
     c6b:	or     r8,r9
     c6e:	mov    r9,r15
     c71:	shr    r9,0x18
     c75:	and    r9,0xff
     c7c:	and    r9,0xffff
     c83:	shl    r9,0x30
     c87:	or     r8,r9
     c8a:	mov    r9,r15
     c8d:	shr    r9,0x20
     c91:	and    r9,0xff
     c98:	and    r9,0xffff
     c9f:	or     r14,r9
     ca2:	mov    r9,r15
     ca5:	shr    r9,0x28
     ca9:	and    r9,0xff
     cb0:	and    r9,0xffff
     cb7:	shl    r9,0x10
     cbb:	or     r14,r9
     cbe:	mov    r9,r15
     cc1:	shr    r9,0x30
     cc5:	and    r9,0xff
     ccc:	and    r9,0xffff
     cd3:	shl    r9,0x20
     cd7:	or     r14,r9
     cda:	shr    r15,0x38
     cde:	and    r15,0xff
     ce5:	and    r15,0xffff
     cec:	shl    r15,0x30
     cf0:	or     r14,r15
     cf3:	mov    QWORD PTR [r12+0x210],r8
     cfb:	mov    QWORD PTR [r12+0x218],r14
     d03:	mov    r14d,0x0
     d09:	mov    r15,rbp
     d0c:	and    r15,0xff
     d13:	and    r15,0xffff
     d1a:	mov    r8,r14
     d1d:	or     r8,r15
     d20:	mov    r15,rbp
     d23:	shr    r15,0x8
     d27:	and    r15,0xff
     d2e:	and    r15,0xffff
     d35:	shl    r15,0x10
     d39:	or     r8,r15
     d3c:	mov    r15,rbp
     d3f:	shr    r15,0x10
     d43:	and    r15,0xff
     d4a:	and    r15,0xffff
     d51:	shl    r15,0x20
     d55:	or     r8,r15
     d58:	mov    r15,rbp
     d5b:	shr    r15,0x18
     d5f:	and    r15,0xff
     d66:	and    r15,0xffff
     d6d:	shl    r15,0x30
     d71:	or     r8,r15
     d74:	mov    r15,rbp
     d77:	shr    r15,0x20
     d7b:	and    r15,0xff
     d82:	and    r15,0xffff
     d89:	or     r14,r15
     d8c:	mov    r15,rbp
     d8f:	shr    r15,0x28
     d93:	and    r15,0xff
     d9a:	and    r15,0xffff
     da1:	shl    r15,0x10
     da5:	or     r14,r15
     da8:	mov    r15,rbp
     dab:	shr    r15,0x30
     daf:	and    r15,0xff
     db6:	and    r15,0xffff
     dbd:	shl    r15,0x20
     dc1:	or     r14,r15
     dc4:	shr    rbp,0x38
     dc8:	and    rbp,0xff
     dcf:	and    rbp,0xffff
     dd6:	shl    rbp,0x30
     dda:	or     r14,rbp
     ddd:	mov    r15d,0x0
     de3:	mov    rbp,QWORD PTR [rsp+0x20]
     de8:	and    rbp,0xff
     def:	and    rbp,0xffff
     df6:	mov    r9,r15
     df9:	or     r9,rbp
     dfc:	mov    rbp,QWORD PTR [rsp+0x20]
     e01:	shr    rbp,0x8
     e05:	and    rbp,0xff
     e0c:	and    rbp,0xffff
     e13:	shl    rbp,0x10
     e17:	or     r9,rbp
     e1a:	mov    rbp,QWORD PTR [rsp+0x20]
     e1f:	shr    rbp,0x10
     e23:	and    rbp,0xff
     e2a:	and    rbp,0xffff
     e31:	shl    rbp,0x20
     e35:	or     r9,rbp
     e38:	mov    rbp,QWORD PTR [rsp+0x20]
     e3d:	shr    rbp,0x18
     e41:	and    rbp,0xff
     e48:	and    rbp,0xffff
     e4f:	shl    rbp,0x30
     e53:	mov    rax,r9
     e56:	or     rax,rbp
     e59:	mov    QWORD PTR [rsp+0x78],rax
     e5e:	mov    rbp,QWORD PTR [rsp+0x20]
     e63:	shr    rbp,0x20
     e67:	and    rbp,0xff
     e6e:	and    rbp,0xffff
     e75:	or     r15,rbp
     e78:	mov    rbp,QWORD PTR [rsp+0x20]
     e7d:	shr    rbp,0x28
     e81:	and    rbp,0xff
     e88:	and    rbp,0xffff
     e8f:	shl    rbp,0x10
     e93:	or     r15,rbp
     e96:	mov    rbp,QWORD PTR [rsp+0x20]
     e9b:	shr    rbp,0x30
     e9f:	and    rbp,0xff
     ea6:	and    rbp,0xffff
     ead:	shl    rbp,0x20
     eb1:	or     r15,rbp
     eb4:	mov    rbp,QWORD PTR [rsp+0x20]
     eb9:	shr    rbp,0x38
     ebd:	and    rbp,0xff
     ec4:	and    rbp,0xffff
     ecb:	shl    rbp,0x30
     ecf:	mov    rax,r15
     ed2:	or     rax,rbp
     ed5:	mov    QWORD PTR [rsp+0x70],rax
     eda:	mov    rax,QWORD PTR [rsp+0x78]
     edf:	mov    QWORD PTR [r12+0x250],rax
     ee7:	mov    rax,QWORD PTR [rsp+0x70]
     eec:	mov    QWORD PTR [r12+0x258],rax
     ef4:	mov    ebp,0x0
     ef9:	mov    r15,QWORD PTR [rsp+0x40]
     efe:	and    r15,0xff
     f05:	and    r15,0xffff
     f0c:	mov    r9,rbp
     f0f:	or     r9,r15
     f12:	mov    r15,QWORD PTR [rsp+0x40]
     f17:	shr    r15,0x8
     f1b:	and    r15,0xff
     f22:	and    r15,0xffff
     f29:	shl    r15,0x10
     f2d:	or     r9,r15
     f30:	mov    r15,QWORD PTR [rsp+0x40]
     f35:	shr    r15,0x10
     f39:	and    r15,0xff
     f40:	and    r15,0xffff
     f47:	shl    r15,0x20
     f4b:	or     r9,r15
     f4e:	mov    r15,QWORD PTR [rsp+0x40]
     f53:	shr    r15,0x18
     f57:	and    r15,0xff
     f5e:	and    r15,0xffff
     f65:	shl    r15,0x30
     f69:	mov    rax,r9
     f6c:	or     rax,r15
     f6f:	mov    QWORD PTR [rsp+0x80],rax
     f77:	mov    r15,QWORD PTR [rsp+0x40]
     f7c:	shr    r15,0x20
     f80:	and    r15,0xff
     f87:	and    r15,0xffff
     f8e:	or     rbp,r15
     f91:	mov    r15,QWORD PTR [rsp+0x40]
     f96:	shr    r15,0x28
     f9a:	and    r15,0xff
     fa1:	and    r15,0xffff
     fa8:	shl    r15,0x10
     fac:	or     rbp,r15
     faf:	mov    r15,QWORD PTR [rsp+0x40]
     fb4:	shr    r15,0x30
     fb8:	and    r15,0xff
     fbf:	and    r15,0xffff
     fc6:	shl    r15,0x20
     fca:	or     rbp,r15
     fcd:	mov    r15,QWORD PTR [rsp+0x40]
     fd2:	shr    r15,0x38
     fd6:	and    r15,0xff
     fdd:	and    r15,0xffff
     fe4:	shl    r15,0x30
     fe8:	mov    rax,rbp
     feb:	or     rax,r15
     fee:	mov    QWORD PTR [rsp+0x88],rax
     ff6:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    1000:	pxor   xmm0,xmm0
    1004:	movdqa xmm3,xmm0
    1008:	movdqa xmm0,xmm2
    100c:	movdqa xmm1,xmm3
    1010:	punpcklwd xmm0,xmm1
    1014:	movdqa xmm4,xmm0
    1018:	movdqa xmm0,xmm4
    101c:	pslld  xmm0,0x10
    1021:	movdqa xmm3,xmm0
    1025:	mov    r15d,0x0
    102b:	mov    r9,QWORD PTR [rsp+0x50]
    1030:	and    r9,0xffff
    1037:	shl    r9,0x8
    103b:	mov    ecx,0xffffffff
    1040:	and    r9,rcx
    1043:	mov    rbp,r15
    1046:	or     rbp,r9
    1049:	mov    r9,QWORD PTR [rsp+0x50]
    104e:	shr    r9,0x10
    1052:	and    r9,0xffff
    1059:	shl    r9,0x8
    105d:	mov    ecx,0xffffffff
    1062:	and    r9,rcx
    1065:	shl    r9,0x20
    1069:	or     rbp,r9
    106c:	mov    r9,QWORD PTR [rsp+0x50]
    1071:	shr    r9,0x20
    1075:	and    r9,0xffff
    107c:	shl    r9,0x8
    1080:	mov    ecx,0xffffffff
    1085:	and    r9,rcx
    1088:	or     r15,r9
    108b:	mov    r9,QWORD PTR [rsp+0x50]
    1090:	shr    r9,0x30
    1094:	and    r9,0xffff
    109b:	shl    r9,0x8
    109f:	mov    ecx,0xffffffff
    10a4:	and    r9,rcx
    10a7:	shl    r9,0x20
    10ab:	or     r15,r9
    10ae:	mov    QWORD PTR [r12+0x240],rbp
    10b6:	mov    QWORD PTR [r12+0x248],r15
    10be:	mov    r15d,0x0
    10c4:	mov    rbp,QWORD PTR [rsp+0x60]
    10c9:	and    rbp,0xffff
    10d0:	mov    ecx,0xffffffff
    10d5:	and    rbp,rcx
    10d8:	mov    r9,r15
    10db:	or     r9,rbp
    10de:	mov    rbp,QWORD PTR [rsp+0x60]
    10e3:	shr    rbp,0x10
    10e7:	and    rbp,0xffff
    10ee:	mov    ecx,0xffffffff
    10f3:	and    rbp,rcx
    10f6:	shl    rbp,0x20
    10fa:	or     r9,rbp
    10fd:	mov    rbp,QWORD PTR [rsp+0x60]
    1102:	shr    rbp,0x20
    1106:	and    rbp,0xffff
    110d:	mov    ecx,0xffffffff
    1112:	and    rbp,rcx
    1115:	or     r15,rbp
    1118:	mov    rbp,QWORD PTR [rsp+0x60]
    111d:	shr    rbp,0x30
    1121:	and    rbp,0xffff
    1128:	mov    ecx,0xffffffff
    112d:	and    rbp,rcx
    1130:	shl    rbp,0x20
    1134:	or     r15,rbp
    1137:	mov    QWORD PTR [r12+0x260],r9
    113f:	mov    QWORD PTR [r12+0x268],r15
    1147:	mov    r15d,0x0
    114d:	mov    rbp,r13
    1150:	and    rbp,0xffff
    1157:	mov    ecx,0xffffffff
    115c:	and    rbp,rcx
    115f:	mov    r9,r15
    1162:	or     r9,rbp
    1165:	mov    rbp,r13
    1168:	shr    rbp,0x10
    116c:	and    rbp,0xffff
    1173:	mov    ecx,0xffffffff
    1178:	and    rbp,rcx
    117b:	shl    rbp,0x20
    117f:	or     r9,rbp
    1182:	mov    rbp,r13
    1185:	shr    rbp,0x20
    1189:	and    rbp,0xffff
    1190:	mov    ecx,0xffffffff
    1195:	and    rbp,rcx
    1198:	or     r15,rbp
    119b:	shr    r13,0x30
    119f:	and    r13,0xffff
    11a6:	mov    ecx,0xffffffff
    11ab:	and    r13,rcx
    11ae:	shl    r13,0x20
    11b2:	or     r15,r13
    11b5:	mov    QWORD PTR [r12+0x270],r9
    11bd:	mov    QWORD PTR [r12+0x278],r15
    11c5:	mov    r13d,0x0
    11cb:	mov    r15,QWORD PTR [rsp+0x58]
    11d0:	and    r15,0xffff
    11d7:	mov    ecx,0xffffffff
    11dc:	and    r15,rcx
    11df:	mov    rbp,r13
    11e2:	or     rbp,r15
    11e5:	mov    r15,QWORD PTR [rsp+0x58]
    11ea:	shr    r15,0x10
    11ee:	and    r15,0xffff
    11f5:	mov    ecx,0xffffffff
    11fa:	and    r15,rcx
    11fd:	shl    r15,0x20
    1201:	or     rbp,r15
    1204:	mov    r15,QWORD PTR [rsp+0x58]
    1209:	shr    r15,0x20
    120d:	and    r15,0xffff
    1214:	mov    ecx,0xffffffff
    1219:	and    r15,rcx
    121c:	or     r13,r15
    121f:	mov    r15,QWORD PTR [rsp+0x58]
    1224:	shr    r15,0x30
    1228:	and    r15,0xffff
    122f:	mov    ecx,0xffffffff
    1234:	and    r15,rcx
    1237:	shl    r15,0x20
    123b:	or     r13,r15
    123e:	mov    QWORD PTR [r12+0x170],rbp
    1246:	mov    QWORD PTR [r12+0x178],r13
    124e:	movdqu xmm4,XMMWORD PTR [r12+0x210]
    1258:	pxor   xmm0,xmm0
    125c:	movdqa xmm5,xmm0
    1260:	movdqa xmm0,xmm4
    1264:	movdqa xmm1,xmm5
    1268:	punpckhwd xmm0,xmm1
    126c:	movdqa xmm6,xmm0
    1270:	movdqa xmm0,xmm6
    1274:	pslld  xmm0,0x10
    1279:	movdqa xmm5,xmm0
    127d:	movdqu XMMWORD PTR [r12+0x280],xmm5
    1287:	mov    r13d,0x0
    128d:	mov    r15,QWORD PTR [rsp+0x68]
    1292:	and    r15,0xffff
    1299:	mov    ecx,0xffffffff
    129e:	and    r15,rcx
    12a1:	mov    rbp,r13
    12a4:	or     rbp,r15
    12a7:	mov    r15,QWORD PTR [rsp+0x68]
    12ac:	shr    r15,0x10
    12b0:	and    r15,0xffff
    12b7:	mov    ecx,0xffffffff
    12bc:	and    r15,rcx
    12bf:	shl    r15,0x20
    12c3:	or     rbp,r15
    12c6:	mov    r15,QWORD PTR [rsp+0x68]
    12cb:	shr    r15,0x20
    12cf:	and    r15,0xffff
    12d6:	mov    ecx,0xffffffff
    12db:	and    r15,rcx
    12de:	or     r13,r15
    12e1:	mov    r15,QWORD PTR [rsp+0x68]
    12e6:	shr    r15,0x30
    12ea:	and    r15,0xffff
    12f1:	mov    ecx,0xffffffff
    12f6:	and    r15,rcx
    12f9:	shl    r15,0x20
    12fd:	or     r13,r15
    1300:	mov    QWORD PTR [r12+0x180],rbp
    1308:	mov    QWORD PTR [r12+0x188],r13
    1310:	pxor   xmm0,xmm0
    1314:	movdqa xmm6,xmm0
    1318:	movdqa xmm0,xmm4
    131c:	movdqa xmm1,xmm6
    1320:	punpcklwd xmm0,xmm1
    1324:	movdqa xmm7,xmm0
    1328:	movdqa xmm0,xmm7
    132c:	pslld  xmm0,0x10
    1331:	movdqa xmm4,xmm0
    1335:	pxor   xmm0,xmm0
    1339:	movdqa xmm6,xmm0
    133d:	movdqa xmm0,xmm2
    1341:	movdqa xmm1,xmm6
    1345:	punpckhwd xmm0,xmm1
    1349:	movdqa xmm7,xmm0
    134d:	movdqa xmm0,xmm7
    1351:	pslld  xmm0,0x10
    1356:	movdqa xmm2,xmm0
    135a:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    1364:	movdqa xmm1,xmm6
    1368:	por    xmm3,xmm1
    136c:	movdqu XMMWORD PTR [r12+0x230],xmm3
    1376:	mov    r13d,0x0
    137c:	mov    r15,r14
    137f:	and    r15,0xffff
    1386:	shl    r15,0x8
    138a:	mov    ecx,0xffffffff
    138f:	and    r15,rcx
    1392:	mov    rbp,r13
    1395:	or     rbp,r15
    1398:	mov    r15,r14
    139b:	shr    r15,0x10
    139f:	and    r15,0xffff
    13a6:	shl    r15,0x8
    13aa:	mov    ecx,0xffffffff
    13af:	and    r15,rcx
    13b2:	shl    r15,0x20
    13b6:	or     rbp,r15
    13b9:	mov    r15,r14
    13bc:	shr    r15,0x20
    13c0:	and    r15,0xffff
    13c7:	shl    r15,0x8
    13cb:	mov    ecx,0xffffffff
    13d0:	and    r15,rcx
    13d3:	or     r13,r15
    13d6:	shr    r14,0x30
    13da:	and    r14,0xffff
    13e1:	shl    r14,0x8
    13e5:	mov    ecx,0xffffffff
    13ea:	and    r14,rcx
    13ed:	shl    r14,0x20
    13f1:	or     r13,r14
    13f4:	mov    QWORD PTR [r12+0x240],rbp
    13fc:	mov    QWORD PTR [r12+0x248],r13
    1404:	mov    r13d,0x0
    140a:	mov    r14,r8
    140d:	and    r14,0xffff
    1414:	shl    r14,0x8
    1418:	mov    ecx,0xffffffff
    141d:	and    r14,rcx
    1420:	mov    r15,r13
    1423:	or     r15,r14
    1426:	mov    r14,r8
    1429:	shr    r14,0x10
    142d:	and    r14,0xffff
    1434:	shl    r14,0x8
    1438:	mov    ecx,0xffffffff
    143d:	and    r14,rcx
    1440:	shl    r14,0x20
    1444:	or     r15,r14
    1447:	mov    r14,r8
    144a:	shr    r14,0x20
    144e:	and    r14,0xffff
    1455:	shl    r14,0x8
    1459:	mov    ecx,0xffffffff
    145e:	and    r14,rcx
    1461:	or     r13,r14
    1464:	shr    r8,0x30
    1468:	and    r8,0xffff
    146f:	shl    r8,0x8
    1473:	mov    ecx,0xffffffff
    1478:	and    r8,rcx
    147b:	shl    r8,0x20
    147f:	or     r13,r8
    1482:	mov    QWORD PTR [r12+0x220],r15
    148a:	mov    QWORD PTR [r12+0x228],r13
    1492:	mov    r13d,0x0
    1498:	mov    r14,QWORD PTR [rsp+0x48]
    149d:	and    r14,0xffff
    14a4:	shl    r14,0x8
    14a8:	mov    ecx,0xffffffff
    14ad:	and    r14,rcx
    14b0:	mov    r15,r13
    14b3:	or     r15,r14
    14b6:	mov    r14,QWORD PTR [rsp+0x48]
    14bb:	shr    r14,0x10
    14bf:	and    r14,0xffff
    14c6:	shl    r14,0x8
    14ca:	mov    ecx,0xffffffff
    14cf:	and    r14,rcx
    14d2:	shl    r14,0x20
    14d6:	or     r15,r14
    14d9:	mov    r14,QWORD PTR [rsp+0x48]
    14de:	shr    r14,0x20
    14e2:	and    r14,0xffff
    14e9:	shl    r14,0x8
    14ed:	mov    ecx,0xffffffff
    14f2:	and    r14,rcx
    14f5:	or     r13,r14
    14f8:	mov    r14,QWORD PTR [rsp+0x48]
    14fd:	shr    r14,0x30
    1501:	and    r14,0xffff
    1508:	shl    r14,0x8
    150c:	mov    ecx,0xffffffff
    1511:	and    r14,rcx
    1514:	shl    r14,0x20
    1518:	or     r13,r14
    151b:	mov    QWORD PTR [r12+0x160],r15
    1523:	mov    QWORD PTR [r12+0x168],r13
    152b:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    1535:	movdqa xmm0,xmm6
    1539:	pslld  xmm0,0x18
    153e:	movdqa xmm7,xmm0
    1542:	movdqu XMMWORD PTR [r12+0x170],xmm7
    154c:	movdqu xmm6,XMMWORD PTR [r12+0x270]
    1556:	movdqa xmm0,xmm6
    155a:	pslld  xmm0,0x18
    155f:	movdqa xmm8,xmm0
    1564:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    156e:	movdqa xmm0,xmm6
    1572:	pslld  xmm0,0x18
    1577:	movdqa xmm9,xmm0
    157c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    1586:	mov    r13d,0x0
    158c:	mov    r14,QWORD PTR [rsp+0x78]
    1591:	and    r14,0xffff
    1598:	mov    ecx,0xffffffff
    159d:	and    r14,rcx
    15a0:	mov    r15,r13
    15a3:	or     r15,r14
    15a6:	mov    r14,QWORD PTR [rsp+0x78]
    15ab:	shr    r14,0x10
    15af:	and    r14,0xffff
    15b6:	mov    ecx,0xffffffff
    15bb:	and    r14,rcx
    15be:	shl    r14,0x20
    15c2:	or     r15,r14
    15c5:	mov    r14,QWORD PTR [rsp+0x78]
    15ca:	shr    r14,0x20
    15ce:	and    r14,0xffff
    15d5:	mov    ecx,0xffffffff
    15da:	and    r14,rcx
    15dd:	or     r13,r14
    15e0:	mov    r14,QWORD PTR [rsp+0x78]
    15e5:	shr    r14,0x30
    15e9:	and    r14,0xffff
    15f0:	mov    ecx,0xffffffff
    15f5:	and    r14,rcx
    15f8:	shl    r14,0x20
    15fc:	or     r13,r14
    15ff:	mov    QWORD PTR [r12+0x140],r15
    1607:	mov    QWORD PTR [r12+0x148],r13
    160f:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    1619:	movdqa xmm1,xmm6
    161d:	por    xmm5,xmm1
    1621:	movdqu xmm6,XMMWORD PTR [r12+0x220]
    162b:	movdqa xmm1,xmm6
    162f:	por    xmm4,xmm1
    1633:	movdqu XMMWORD PTR [r12+0x210],xmm4
    163d:	movdqu xmm6,XMMWORD PTR [r12+0x260]
    1647:	movdqa xmm0,xmm6
    164b:	pslld  xmm0,0x18
    1650:	movdqa xmm10,xmm0
    1655:	movdqu XMMWORD PTR [r12+0x220],xmm10
    165f:	movdqu xmm6,XMMWORD PTR [r12+0x160]
    1669:	movdqa xmm1,xmm6
    166d:	por    xmm2,xmm1
    1671:	movdqa xmm1,xmm7
    1675:	por    xmm3,xmm1
    1679:	movdqu XMMWORD PTR [r12+0x160],xmm3
    1683:	mov    r13d,0x0
    1689:	mov    r14,QWORD PTR [rsp+0x88]
    1691:	and    r14,0xffff
    1698:	mov    ecx,0xffffffff
    169d:	and    r14,rcx
    16a0:	mov    r15,r13
    16a3:	or     r15,r14
    16a6:	mov    r14,QWORD PTR [rsp+0x88]
    16ae:	shr    r14,0x10
    16b2:	and    r14,0xffff
    16b9:	mov    ecx,0xffffffff
    16be:	and    r14,rcx
    16c1:	shl    r14,0x20
    16c5:	or     r15,r14
    16c8:	mov    r14,QWORD PTR [rsp+0x88]
    16d0:	shr    r14,0x20
    16d4:	and    r14,0xffff
    16db:	mov    ecx,0xffffffff
    16e0:	and    r14,rcx
    16e3:	or     r13,r14
    16e6:	mov    r14,QWORD PTR [rsp+0x88]
    16ee:	shr    r14,0x30
    16f2:	and    r14,0xffff
    16f9:	mov    ecx,0xffffffff
    16fe:	and    r14,rcx
    1701:	shl    r14,0x20
    1705:	or     r13,r14
    1708:	mov    QWORD PTR [r12+0x170],r15
    1710:	mov    QWORD PTR [r12+0x178],r13
    1718:	mov    r13d,0x0
    171e:	mov    r14,QWORD PTR [rsp+0x80]
    1726:	and    r14,0xffff
    172d:	mov    ecx,0xffffffff
    1732:	and    r14,rcx
    1735:	mov    r15,r13
    1738:	or     r15,r14
    173b:	mov    r14,QWORD PTR [rsp+0x80]
    1743:	shr    r14,0x10
    1747:	and    r14,0xffff
    174e:	mov    ecx,0xffffffff
    1753:	and    r14,rcx
    1756:	shl    r14,0x20
    175a:	or     r15,r14
    175d:	mov    r14,QWORD PTR [rsp+0x80]
    1765:	shr    r14,0x20
    1769:	and    r14,0xffff
    1770:	mov    ecx,0xffffffff
    1775:	and    r14,rcx
    1778:	or     r13,r14
    177b:	mov    r14,QWORD PTR [rsp+0x80]
    1783:	shr    r14,0x30
    1787:	and    r14,0xffff
    178e:	mov    ecx,0xffffffff
    1793:	and    r14,rcx
    1796:	shl    r14,0x20
    179a:	or     r13,r14
    179d:	mov    QWORD PTR [r12+0x110],r15
    17a5:	mov    QWORD PTR [r12+0x118],r13
    17ad:	movdqa xmm1,xmm8
    17b2:	por    xmm5,xmm1
    17b6:	movdqa xmm1,xmm9
    17bb:	por    xmm4,xmm1
    17bf:	mov    r13d,0x0
    17c5:	mov    r14,QWORD PTR [rsp+0x70]
    17ca:	and    r14,0xffff
    17d1:	mov    ecx,0xffffffff
    17d6:	and    r14,rcx
    17d9:	mov    r15,r13
    17dc:	or     r15,r14
    17df:	mov    r14,QWORD PTR [rsp+0x70]
    17e4:	shr    r14,0x10
    17e8:	and    r14,0xffff
    17ef:	mov    ecx,0xffffffff
    17f4:	and    r14,rcx
    17f7:	shl    r14,0x20
    17fb:	or     r15,r14
    17fe:	mov    r14,QWORD PTR [rsp+0x70]
    1803:	shr    r14,0x20
    1807:	and    r14,0xffff
    180e:	mov    ecx,0xffffffff
    1813:	and    r14,rcx
    1816:	or     r13,r14
    1819:	mov    r14,QWORD PTR [rsp+0x70]
    181e:	shr    r14,0x30
    1822:	and    r14,0xffff
    1829:	mov    ecx,0xffffffff
    182e:	and    r14,rcx
    1831:	shl    r14,0x20
    1835:	or     r13,r14
    1838:	mov    QWORD PTR [r12+0x180],r15
    1840:	mov    QWORD PTR [r12+0x188],r13
    1848:	movdqa xmm1,xmm10
    184d:	por    xmm2,xmm1
    1851:	movdqu XMMWORD PTR [r12+0x150],xmm2
    185b:	movdqu xmm6,XMMWORD PTR [r12+0x140]
    1865:	movdqa xmm1,xmm6
    1869:	por    xmm3,xmm1
    186d:	movdqu XMMWORD PTR [r12+0x140],xmm3
    1877:	movdqu xmm6,XMMWORD PTR [r12+0x110]
    1881:	movdqa xmm1,xmm6
    1885:	por    xmm4,xmm1
    1889:	movdqu XMMWORD PTR [r12+0x110],xmm4
    1893:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    189d:	movdqa xmm1,xmm6
    18a1:	por    xmm5,xmm1
    18a5:	movdqu XMMWORD PTR [r12+0x120],xmm5
    18af:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    18b9:	movdqa xmm1,xmm6
    18bd:	por    xmm2,xmm1
    18c1:	movdqu XMMWORD PTR [r12+0x130],xmm2
    18cb:	mov    r13,QWORD PTR [r12+0xf8]
    18d3:	mov    r14,r13
    18d6:	add    r14,0x20
    18da:	mov    r15,r14
    18dd:	add    r15,0x10
    18e1:	movdqu XMMWORD PTR [r14],xmm4
    18e6:	mov    r14d,0x0
    18ec:	mov    DWORD PTR [r12+0x32c],r14d
    18f4:	movdqu XMMWORD PTR [r15],xmm5
    18f9:	mov    r14,r13
    18fc:	add    r14,0x10
    1900:	movdqu XMMWORD PTR [r13+0x0],xmm3
    1906:	movdqu XMMWORD PTR [r14],xmm2
    190b:	mov    r14d,DWORD PTR [r13+0x0]
    190f:	mov    QWORD PTR [r12+0x60],r14
    1914:	jmp    0x1919
    1919:	mov    r13,QWORD PTR [r12+0x58]
    191e:	mov    r14,QWORD PTR [r12+0x48]
    1923:	add    r14,r13
    1926:	mov    QWORD PTR [r12+0x68],r14
    192b:	add    r13,0x4
    192f:	mov    QWORD PTR [r12+0x58],r13
    1934:	mov    r15,r14
    1937:	add    r15,0x4
    193b:	mov    eax,DWORD PTR [r15]
    193e:	mov    QWORD PTR [r12+0x70],rax
    1943:	mov    r15,r14
    1946:	add    r15,0x38
    194a:	mov    r8d,DWORD PTR [r15]
    194d:	mov    QWORD PTR [r12+0x78],r8
    1952:	mov    r15,r14
    1955:	add    r15,0x24
    1959:	mov    r9d,DWORD PTR [r15]
    195c:	mov    QWORD PTR [r12+0x90],r9
    1964:	sub    r13,0xc0
    196b:	setne  BYTE PTR [rsp+0xb8]
    1973:	mov    r11,rax
    1976:	lahf
    1977:	seto   al
    197a:	mov    WORD PTR [rsp+0xb0],ax
    1982:	mov    rax,r11
    1985:	mov    r13d,DWORD PTR [r12+0x70]
    198a:	mov    r13d,r13d
    198d:	mov    r13d,r13d
    1990:	ror    r13d,0x7
    1994:	mov    QWORD PTR [r12+0x80],r13
    199c:	mov    r15d,r8d
    199f:	mov    r15d,r15d
    19a2:	ror    r15d,0x11
    19a6:	mov    QWORD PTR [r12+0x88],r15
    19ae:	mov    ebp,DWORD PTR [r12+0x60]
    19b3:	add    r9d,ebp
    19b6:	mov    QWORD PTR [r12+0x60],r9
    19bb:	mov    ebp,DWORD PTR [r12+0x70]
    19c0:	mov    ebp,ebp
    19c2:	mov    ebp,ebp
    19c4:	ror    ebp,0x12
    19c7:	xor    r13d,ebp
    19ca:	mov    QWORD PTR [r12+0x80],r13
    19d2:	mov    ebp,r8d
    19d5:	mov    ebp,ebp
    19d7:	ror    ebp,0x13
    19da:	xor    r15d,ebp
    19dd:	mov    QWORD PTR [r12+0x88],r15
    19e5:	mov    ebp,DWORD PTR [r12+0x70]
    19ea:	mov    ebp,ebp
    19ec:	mov    ebp,ebp
    19ee:	shr    ebp,0x3
    19f1:	xor    r13d,ebp
    19f4:	mov    QWORD PTR [r12+0x80],r13
    19fc:	mov    r8d,r8d
    19ff:	shr    r8d,0xa
    1a03:	xor    r15d,r8d
    1a06:	mov    QWORD PTR [r12+0x78],r15
    1a0b:	add    r9d,r13d
    1a0e:	mov    QWORD PTR [r12+0x60],r9
    1a13:	add    r9d,r15d
    1a16:	mov    QWORD PTR [r12+0x60],r9
    1a1b:	add    r14,0x40
    1a1f:	mov    DWORD PTR [r14],r9d
    1a22:	mov    r13d,0x0
    1a28:	mov    DWORD PTR [r12+0x32c],r13d
    1a30:	mov    r13d,0x0
    1a36:	mov    ecx,DWORD PTR [r12+0x70]
    1a3b:	mov    ecx,ecx
    1a3d:	mov    r14d,r13d
    1a40:	or     r14d,ecx
    1a43:	mov    QWORD PTR [r12+0x60],r14
    1a48:	mov    rcx,QWORD PTR [r12+0x380]
    1a50:	jrcxz  0x1a57
    1a52:	jmp    0x223a
    1a57:	cmp    BYTE PTR [rsp+0xb8],0x0
    1a5f:	jne    0x1919
    1a65:	jmp    0x1a6a
    1a6a:	mov    r13,QWORD PTR [r12]
    1a6e:	mov    r14,r13
    1a71:	add    r14,0x4
    1a75:	mov    r15d,DWORD PTR [r13+0x0]
    1a79:	mov    ebp,DWORD PTR [r14]
    1a7c:	mov    QWORD PTR [r12+0x78],r15
    1a81:	mov    QWORD PTR [r12+0x80],rbp
    1a89:	mov    r14,r13
    1a8c:	add    r14,0x8
    1a90:	mov    r8,r14
    1a93:	add    r8,0x4
    1a97:	mov    r9d,DWORD PTR [r14]
    1a9a:	mov    eax,DWORD PTR [r8]
    1a9d:	mov    QWORD PTR [rsp+0x90],rax
    1aa5:	mov    QWORD PTR [r12+0x70],r9
    1aaa:	mov    rax,QWORD PTR [rsp+0x90]
    1ab2:	mov    QWORD PTR [r12+0x68],rax
    1ab7:	mov    r8,r13
    1aba:	add    r8,0x18
    1abe:	mov    r14,r8
    1ac1:	add    r14,0x4
    1ac5:	mov    eax,DWORD PTR [r8]
    1ac8:	mov    QWORD PTR [rsp+0x98],rax
    1ad0:	mov    r8d,DWORD PTR [r14]
    1ad3:	mov    rax,QWORD PTR [rsp+0x98]
    1adb:	mov    QWORD PTR [r12+0x58],rax
    1ae0:	mov    QWORD PTR [r12+0x60],r8
    1ae5:	add    r13,0x10
    1ae9:	mov    r14,r13
    1aec:	add    r14,0x4
    1af0:	mov    eax,DWORD PTR [r13+0x0]
    1af4:	mov    QWORD PTR [rsp+0xa0],rax
    1afc:	mov    eax,DWORD PTR [r14]
    1aff:	mov    QWORD PTR [rsp+0xa8],rax
    1b07:	mov    rax,QWORD PTR [rsp+0xa0]
    1b0f:	mov    QWORD PTR [r12+0x18],rax
    1b14:	mov    rax,QWORD PTR [rsp+0xa8]
    1b1c:	mov    QWORD PTR [r12+0x90],rax
    1b24:	mov    r14d,0x0
    1b2a:	mov    QWORD PTR [r12+0x88],r14
    1b32:	mov    r14d,0x0
    1b38:	mov    r13d,r14d
    1b3b:	or     r13d,r15d
    1b3e:	mov    QWORD PTR [r12+0xa8],r13
    1b46:	mov    r13d,0x0
    1b4c:	mov    r14d,r13d
    1b4f:	or     r14d,ebp
    1b52:	mov    QWORD PTR [r12+0x38],r14
    1b57:	mov    r13d,0x0
    1b5d:	mov    r14d,r13d
    1b60:	or     r14d,r9d
    1b63:	mov    QWORD PTR [r12+0x98],r14
    1b6b:	mov    r13d,0x0
    1b71:	mov    ecx,DWORD PTR [rsp+0x90]
    1b78:	mov    r14d,r13d
    1b7b:	or     r14d,ecx
    1b7e:	mov    QWORD PTR [r12+0x28],r14
    1b83:	mov    r13d,0x0
    1b89:	mov    r14d,r13d
    1b8c:	or     r14d,r8d
    1b8f:	mov    QWORD PTR [r12+0xb0],r14
    1b97:	mov    r13d,0x0
    1b9d:	mov    ecx,DWORD PTR [rsp+0x98]
    1ba4:	mov    r14d,r13d
    1ba7:	or     r14d,ecx
    1baa:	mov    QWORD PTR [r12+0xc0],r14
    1bb2:	mov    r13d,0x0
    1bb8:	mov    ecx,DWORD PTR [rsp+0xa8]
    1bbf:	mov    r14d,r13d
    1bc2:	or     r14d,ecx
    1bc5:	mov    QWORD PTR [r12+0xc8],r14
    1bcd:	mov    r13d,0x0
    1bd3:	mov    ecx,DWORD PTR [rsp+0xa0]
    1bda:	mov    r14d,r13d
    1bdd:	or     r14d,ecx
    1be0:	mov    QWORD PTR [r12+0xb8],r14
    1be8:	jmp    0x1bed
    1bed:	mov    r13d,0x0
    1bf3:	mov    r14d,DWORD PTR [r12+0xb8]
    1bfb:	mov    eax,r13d
    1bfe:	or     eax,r14d
    1c01:	mov    QWORD PTR [r12+0x30],rax
    1c06:	mov    r13d,0x0
    1c0c:	mov    ebp,DWORD PTR [r12+0xc0]
    1c14:	mov    eax,r13d
    1c17:	or     eax,ebp
    1c19:	mov    QWORD PTR [r12+0xa0],rax
    1c21:	mov    r13d,0x0
    1c27:	mov    ebp,DWORD PTR [r12+0x28]
    1c2c:	mov    eax,r13d
    1c2f:	or     eax,ebp
    1c31:	mov    QWORD PTR [r12+0xc0],rax
    1c39:	mov    r13d,0x0
    1c3f:	mov    ebp,DWORD PTR [r12+0x98]
    1c47:	mov    eax,r13d
    1c4a:	or     eax,ebp
    1c4c:	mov    QWORD PTR [r12+0x28],rax
    1c51:	mov    r13d,0x0
    1c57:	mov    ebp,DWORD PTR [r12+0x38]
    1c5c:	mov    eax,r13d
    1c5f:	or     eax,ebp
    1c61:	mov    QWORD PTR [r12+0x98],rax
    1c69:	mov    r13d,0x0
    1c6f:	mov    ebp,DWORD PTR [r12+0xa8]
    1c77:	mov    eax,r13d
    1c7a:	or     eax,ebp
    1c7c:	mov    QWORD PTR [r12+0x38],rax
    1c81:	mov    r14d,r14d
    1c84:	ror    r14d,0x6
    1c88:	mov    QWORD PTR [r12+0xb8],r14
    1c90:	mov    r13d,DWORD PTR [r12+0xc8]
    1c98:	mov    ebp,DWORD PTR [r12+0x30]
    1c9d:	mov    ebp,ebp
    1c9f:	and    ebp,r13d
    1ca2:	mov    QWORD PTR [r12+0xa8],rbp
    1caa:	mov    r9d,DWORD PTR [r12+0x38]
    1caf:	mov    r9d,r9d
    1cb2:	mov    r9d,r9d
    1cb5:	ror    r9d,0x2
    1cb9:	mov    QWORD PTR [r12+0xd0],r9
    1cc1:	mov    r15d,0x0
    1cc7:	mov    eax,r15d
    1cca:	or     eax,r13d
    1ccd:	mov    QWORD PTR [r12+0x20],rax
    1cd2:	mov    rax,QWORD PTR [r12+0x88]
    1cda:	mov    r15,QWORD PTR [r12+0x50]
    1cdf:	mov    rcx,QWORD PTR [r12+0x88]
    1ce7:	add    r15,rcx
    1cea:	mov    r13d,DWORD PTR [r15]
    1ced:	mov    QWORD PTR [r12+0xc8],r13
    1cf5:	mov    ecx,DWORD PTR [r12+0x30]
    1cfa:	mov    ecx,ecx
    1cfc:	mov    r15d,DWORD PTR [r12+0xa0]
    1d04:	mov    r15d,r15d
    1d07:	not    rcx
    1d0a:	and    r15d,ecx
    1d0d:	mov    QWORD PTR [r12+0xd8],r15
    1d15:	mov    r8d,DWORD PTR [r12+0xb0]
    1d1d:	add    ebp,r8d
    1d20:	mov    QWORD PTR [r12+0xa8],rbp
    1d28:	mov    r8d,DWORD PTR [r12+0x30]
    1d2d:	mov    r8d,r8d
    1d30:	mov    r8d,r8d
    1d33:	ror    r8d,0xb
    1d37:	xor    r14d,r8d
    1d3a:	mov    QWORD PTR [r12+0xb0],r14
    1d42:	mov    r8d,DWORD PTR [r12+0x38]
    1d47:	mov    r8d,r8d
    1d4a:	mov    r8d,r8d
    1d4d:	ror    r8d,0xd
    1d51:	xor    r9d,r8d
    1d54:	mov    QWORD PTR [r12+0xd0],r9
    1d5c:	add    ebp,r15d
    1d5f:	mov    QWORD PTR [r12+0xa8],rbp
    1d67:	mov    r15,QWORD PTR [r12+0x48]
    1d6c:	mov    rcx,QWORD PTR [r12+0x88]
    1d74:	add    r15,rcx
    1d77:	mov    r8d,DWORD PTR [r15]
    1d7a:	mov    QWORD PTR [r12+0xb8],r8
    1d82:	mov    ecx,DWORD PTR [r12+0x98]
    1d8a:	mov    ecx,ecx
    1d8c:	mov    eax,DWORD PTR [r12+0x28]
    1d91:	mov    eax,eax
    1d93:	and    eax,ecx
    1d95:	mov    QWORD PTR [r12+0xd8],rax
    1d9d:	add    ebp,r13d
    1da0:	mov    QWORD PTR [r12+0xa8],rbp
    1da8:	mov    ecx,DWORD PTR [r12+0x98]
    1db0:	mov    ecx,ecx
    1db2:	mov    r13d,DWORD PTR [r12+0x28]
    1db7:	mov    r13d,r13d
    1dba:	xor    r13d,ecx
    1dbd:	mov    QWORD PTR [r12+0xc8],r13
    1dc5:	mov    r15d,DWORD PTR [r12+0x30]
    1dca:	mov    r15d,r15d
    1dcd:	mov    r15d,r15d
    1dd0:	ror    r15d,0x19
    1dd4:	xor    r14d,r15d
    1dd7:	mov    QWORD PTR [r12+0xb0],r14
    1ddf:	mov    ecx,DWORD PTR [r12+0x38]
    1de4:	mov    ecx,ecx
    1de6:	and    r13d,ecx
    1de9:	mov    QWORD PTR [r12+0xc8],r13
    1df1:	mov    r15d,DWORD PTR [r12+0x38]
    1df6:	mov    r15d,r15d
    1df9:	mov    r15d,r15d
    1dfc:	ror    r15d,0x16
    1e00:	xor    r9d,r15d
    1e03:	mov    QWORD PTR [r12+0xd0],r9
    1e0b:	add    ebp,r8d
    1e0e:	mov    QWORD PTR [r12+0xa8],rbp
    1e16:	mov    ecx,DWORD PTR [r12+0xd8]
    1e1e:	mov    ecx,ecx
    1e20:	xor    r13d,ecx
    1e23:	mov    QWORD PTR [r12+0xb8],r13
    1e2b:	add    ebp,r14d
    1e2e:	mov    QWORD PTR [r12+0xa8],rbp
    1e36:	mov    r14,QWORD PTR [r12+0x88]
    1e3e:	add    r14,0x4
    1e42:	mov    QWORD PTR [r12+0x88],r14
    1e4a:	add    r13d,r9d
    1e4d:	mov    QWORD PTR [r12+0xb0],r13
    1e55:	mov    ecx,DWORD PTR [r12+0xc0]
    1e5d:	mov    ecx,ecx
    1e5f:	mov    r15d,ebp
    1e62:	add    r15d,ecx
    1e65:	mov    QWORD PTR [r12+0xb8],r15
    1e6d:	sub    r14,0x100
    1e74:	setne  BYTE PTR [rsp+0xb8]
    1e7c:	mov    r11,rax
    1e7f:	lahf
    1e80:	seto   al
    1e83:	mov    WORD PTR [rsp+0xb0],ax
    1e8b:	mov    rax,r11
    1e8e:	add    r13d,ebp
    1e91:	mov    QWORD PTR [r12+0xa8],r13
    1e99:	mov    r13d,0x0
    1e9f:	mov    ecx,DWORD PTR [r12+0xa0]
    1ea7:	mov    ecx,ecx
    1ea9:	mov    r14d,r13d
    1eac:	or     r14d,ecx
    1eaf:	mov    QWORD PTR [r12+0xb0],r14
    1eb7:	mov    r13d,0x0
    1ebd:	mov    ecx,DWORD PTR [r12+0x20]
    1ec2:	mov    ecx,ecx
    1ec4:	mov    r14d,r13d
    1ec7:	or     r14d,ecx
    1eca:	mov    QWORD PTR [r12+0xc0],r14
    1ed2:	mov    r13d,0x0
    1ed8:	mov    ecx,DWORD PTR [r12+0x30]
    1edd:	mov    ecx,ecx
    1edf:	mov    r14d,r13d
    1ee2:	or     r14d,ecx
    1ee5:	mov    QWORD PTR [r12+0xc8],r14
    1eed:	mov    rcx,QWORD PTR [r12+0x380]
    1ef5:	jrcxz  0x1efc
    1ef7:	jmp    0x22c2
    1efc:	cmp    BYTE PTR [rsp+0xb8],0x0
    1f04:	jne    0x1bed
    1f0a:	jmp    0x1f0f
    1f0f:	mov    r13d,DWORD PTR [r12+0x70]
    1f14:	mov    r14d,DWORD PTR [r12+0x98]
    1f1c:	add    r14d,r13d
    1f1f:	mov    QWORD PTR [r12+0x70],r14
    1f24:	mov    r13d,DWORD PTR [r12+0x68]
    1f29:	mov    r15d,DWORD PTR [r12+0x28]
    1f2e:	add    r15d,r13d
    1f31:	mov    QWORD PTR [r12+0x68],r15
    1f36:	mov    r13d,0x0
    1f3c:	mov    QWORD PTR [r12+0x88],r13
    1f44:	mov    r13d,DWORD PTR [r12+0x78]
    1f49:	mov    ebp,DWORD PTR [r12+0xa8]
    1f51:	add    ebp,r13d
    1f54:	mov    QWORD PTR [r12+0x78],rbp
    1f59:	mov    r13d,DWORD PTR [r12+0x80]
    1f61:	mov    r8d,DWORD PTR [r12+0x38]
    1f66:	add    r8d,r13d
    1f69:	mov    QWORD PTR [r12+0x80],r8
    1f71:	mov    rax,QWORD PTR [r12]
    1f75:	mov    r9,QWORD PTR [r12]
    1f79:	add    r9,0x8
    1f7d:	mov    r13,r9
    1f80:	add    r13,0x4
    1f84:	mov    DWORD PTR [r9],r14d
    1f87:	mov    r14d,0x0
    1f8d:	mov    DWORD PTR [r12+0x32c],r14d
    1f95:	mov    DWORD PTR [r13+0x0],r15d
    1f99:	mov    r13d,DWORD PTR [r12+0x18]
    1f9e:	mov    r14d,DWORD PTR [r12+0xb8]
    1fa6:	add    r14d,r13d
    1fa9:	mov    QWORD PTR [r12+0x68],r14
    1fae:	mov    r13d,DWORD PTR [r12+0x90]
    1fb6:	mov    r15d,DWORD PTR [r12+0x30]
    1fbb:	add    r15d,r13d
    1fbe:	mov    QWORD PTR [r12+0x70],r15
    1fc3:	mov    r13d,DWORD PTR [r12+0x58]
    1fc8:	mov    r9d,DWORD PTR [r12+0x20]
    1fcd:	mov    eax,r9d
    1fd0:	add    eax,r13d
    1fd3:	mov    QWORD PTR [r12+0x58],rax
    1fd8:	mov    r13d,DWORD PTR [r12+0x60]
    1fdd:	mov    r9d,DWORD PTR [r12+0xa0]
    1fe5:	add    r9d,r13d
    1fe8:	mov    QWORD PTR [r12+0x60],r9
    1fed:	mov    r13,QWORD PTR [r12]
    1ff1:	add    r13,0x4
    1ff5:	mov    rdi,QWORD PTR [r12]
    1ff9:	mov    DWORD PTR [rdi],ebp
    1ffb:	mov    DWORD PTR [r13+0x0],r8d
    1fff:	mov    r13,QWORD PTR [r12]
    2003:	add    r13,0x10
    2007:	mov    rbp,r13
    200a:	add    rbp,0x4
    200e:	mov    DWORD PTR [r13+0x0],r14d
    2012:	mov    DWORD PTR [rbp+0x0],r15d
    2016:	mov    r13,QWORD PTR [r12]
    201a:	add    r13,0x18
    201e:	mov    r14,r13
    2021:	add    r14,0x4
    2025:	mov    eax,DWORD PTR [r12+0x58]
    202a:	mov    DWORD PTR [r13+0x0],eax
    202e:	mov    DWORD PTR [r14],r9d
    2031:	mov    r13,QWORD PTR [r12]
    2035:	add    r13,0x68
    2039:	mov    r14d,0x0
    203f:	mov    QWORD PTR [r13+0x0],r14
    2043:	mov    rcx,QWORD PTR [r12+0x380]
    204b:	jrcxz  0x2052
    204d:	jmp    0x234a
    2052:	jmp    0x2057
    2057:	mov    r13,QWORD PTR [r12+0x10]
    205c:	sub    r13,0x1
    2060:	mov    QWORD PTR [r12+0x10],r13
    2065:	mov    rax,r13
    2068:	test   rax,rax
    206b:	je     0x2076
    2071:	jmp    0x17a
    2076:	mov    r13,QWORD PTR [r12+0xf8]
    207e:	mov    r14,r13
    2081:	add    r14,0x140
    2088:	mov    r15,r14
    208b:	add    r15,0x8
    208f:	mov    rbp,QWORD PTR [r14]
    2092:	mov    r14,QWORD PTR [r15]
    2095:	mov    QWORD PTR [r12+0xa0],rbp
    209d:	mov    QWORD PTR [r12+0x98],r14
    20a5:	mov    r14,r13
    20a8:	add    r14,0x130
    20af:	mov    r15,r14
    20b2:	add    r15,0x8
    20b6:	mov    rbp,QWORD PTR [r14]
    20b9:	mov    r14,QWORD PTR [r15]
    20bc:	mov    QWORD PTR [r12+0xb0],rbp
    20c4:	mov    QWORD PTR [r12+0xa8],r14
    20cc:	mov    r14,r13
    20cf:	add    r14,0x120
    20d6:	mov    r15,r14
    20d9:	add    r15,0x8
    20dd:	mov    rbp,QWORD PTR [r14]
    20e0:	mov    r14,QWORD PTR [r15]
    20e3:	mov    QWORD PTR [r12+0xc0],rbp
    20eb:	mov    QWORD PTR [r12+0xb8],r14
    20f3:	mov    r14,r13
    20f6:	add    r14,0x110
    20fd:	mov    r15,r14
    2100:	add    r15,0x8
    2104:	mov    rbp,QWORD PTR [r14]
    2107:	mov    r14,QWORD PTR [r15]
    210a:	mov    QWORD PTR [r12+0xd0],rbp
    2112:	mov    QWORD PTR [r12+0xc8],r14
    211a:	mov    r14,r13
    211d:	add    r14,0x100
    2124:	mov    r15,r14
    2127:	add    r15,0x8
    212b:	mov    rbp,QWORD PTR [r14]
    212e:	mov    r14,QWORD PTR [r15]
    2131:	mov    QWORD PTR [r12+0xe8],rbp
    2139:	mov    QWORD PTR [r12+0xd8],r14
    2141:	add    r13,0x150
    2148:	mov    QWORD PTR [r12+0xf8],r13
    2150:	jmp    0x2155
    2155:	mov    rcx,QWORD PTR [r12+0x380]
    215d:	jrcxz  0x2164
    215f:	jmp    0x23d2
    2164:	mov    r13,QWORD PTR [r12+0xf0]
    216c:	mov    QWORD PTR [r12+0x100],r13
    2174:	mov    r11,QWORD PTR [rsp+0xb0]
    217c:	mov    QWORD PTR [r12+0x398],r11
    2184:	mov    rdi,QWORD PTR [r12+0x100]
    218c:	add    rsp,0xc0
    2193:	movabs r11,0x580415130940
    219d:	jmp    r11
    21a0:	mov    eax,0x41039c
    21a5:	mov    QWORD PTR [r12+0x100],rax
    21ad:	push   rdx
    21ae:	push   rsi
    21af:	push   r10
    21b1:	push   r11
    21b3:	mov    r11,rax
    21b6:	lahf
    21b7:	seto   al
    21ba:	mov    WORD PTR [rsp+0xd0],ax
    21c2:	mov    rax,r11
    21c5:	mov    rdx,QWORD PTR [rsp+0xd0]
    21cd:	mov    r10d,edx
    21d0:	and    r10d,0xc000
    21d7:	shl    r10d,0x10
    21db:	mov    r11d,edx
    21de:	and    r11d,0x100
    21e5:	shl    r11d,0x15
    21e9:	or     r10d,r11d
    21ec:	and    edx,0x1
    21ef:	shl    edx,0x1c
    21f2:	or     r10d,edx
    21f5:	btc    r10,0x1d
    21fa:	mov    r11d,0xf0000000
    2200:	and    r11,r10
    2203:	movabs rsi,0xffffffff0fffffff
    220d:	and    rbx,rsi
    2210:	or     rbx,r11
    2213:	pop    r11
    2215:	pop    r10
    2217:	pop    rsi
    2218:	pop    rdx
    2219:	mov    QWORD PTR [r12+0x108],rbx
    2221:	add    rsp,0xc0
    2228:	mov    eax,0xc
    222d:	movabs r11,0x580415130ca0
    2237:	jmp    r11
    223a:	mov    eax,0x410498
    223f:	mov    QWORD PTR [r12+0x100],rax
    2247:	push   rdx
    2248:	push   rsi
    2249:	push   r10
    224b:	push   r11
    224d:	mov    rdx,QWORD PTR [rsp+0xd0]
    2255:	mov    r10d,edx
    2258:	and    r10d,0xc000
    225f:	shl    r10d,0x10
    2263:	mov    r11d,edx
    2266:	and    r11d,0x100
    226d:	shl    r11d,0x15
    2271:	or     r10d,r11d
    2274:	and    edx,0x1
    2277:	shl    edx,0x1c
    227a:	or     r10d,edx
    227d:	btc    r10,0x1d
    2282:	mov    r11d,0xf0000000
    2288:	and    r11,r10
    228b:	movabs rsi,0xffffffff0fffffff
    2295:	and    rbx,rsi
    2298:	or     rbx,r11
    229b:	pop    r11
    229d:	pop    r10
    229f:	pop    rsi
    22a0:	pop    rdx
    22a1:	mov    QWORD PTR [r12+0x108],rbx
    22a9:	add    rsp,0xc0
    22b0:	mov    eax,0xc
    22b5:	movabs r11,0x580415130ca0
    22bf:	jmp    r11
    22c2:	mov    eax,0x410558
    22c7:	mov    QWORD PTR [r12+0x100],rax
    22cf:	push   rdx
    22d0:	push   rsi
    22d1:	push   r10
    22d3:	push   r11
    22d5:	mov    rdx,QWORD PTR [rsp+0xd0]
    22dd:	mov    r10d,edx
    22e0:	and    r10d,0xc000
    22e7:	shl    r10d,0x10
    22eb:	mov    r11d,edx
    22ee:	and    r11d,0x100
    22f5:	shl    r11d,0x15
    22f9:	or     r10d,r11d
    22fc:	and    edx,0x1
    22ff:	shl    edx,0x1c
    2302:	or     r10d,edx
    2305:	btc    r10,0x1d
    230a:	mov    r11d,0xf0000000
    2310:	and    r11,r10
    2313:	movabs rsi,0xffffffff0fffffff
    231d:	and    rbx,rsi
    2320:	or     rbx,r11
    2323:	pop    r11
    2325:	pop    r10
    2327:	pop    rsi
    2328:	pop    rdx
    2329:	mov    QWORD PTR [r12+0x108],rbx
    2331:	add    rsp,0xc0
    2338:	mov    eax,0xc
    233d:	movabs r11,0x580415130ca0
    2347:	jmp    r11
    234a:	mov    eax,0x410594
    234f:	mov    QWORD PTR [r12+0x100],rax
    2357:	push   rdx
    2358:	push   rsi
    2359:	push   r10
    235b:	push   r11
    235d:	mov    rdx,QWORD PTR [rsp+0xd0]
    2365:	mov    r10d,edx
    2368:	and    r10d,0xc000
    236f:	shl    r10d,0x10
    2373:	mov    r11d,edx
    2376:	and    r11d,0x100
    237d:	shl    r11d,0x15
    2381:	or     r10d,r11d
    2384:	and    edx,0x1
    2387:	shl    edx,0x1c
    238a:	or     r10d,edx
    238d:	btc    r10,0x1d
    2392:	mov    r11d,0xf0000000
    2398:	and    r11,r10
    239b:	movabs rsi,0xffffffff0fffffff
    23a5:	and    rbx,rsi
    23a8:	or     rbx,r11
    23ab:	pop    r11
    23ad:	pop    r10
    23af:	pop    rsi
    23b0:	pop    rdx
    23b1:	mov    QWORD PTR [r12+0x108],rbx
    23b9:	add    rsp,0xc0
    23c0:	mov    eax,0xc
    23c5:	movabs r11,0x580415130ca0
    23cf:	jmp    r11
    23d2:	mov    eax,0x4105b0
    23d7:	mov    QWORD PTR [r12+0x100],rax
    23df:	push   rdx
    23e0:	push   rsi
    23e1:	push   r10
    23e3:	push   r11
    23e5:	mov    rdx,QWORD PTR [rsp+0xd0]
    23ed:	mov    r10d,edx
    23f0:	and    r10d,0xc000
    23f7:	shl    r10d,0x10
    23fb:	mov    r11d,edx
    23fe:	and    r11d,0x100
    2405:	shl    r11d,0x15
    2409:	or     r10d,r11d
    240c:	and    edx,0x1
    240f:	shl    edx,0x1c
    2412:	or     r10d,edx
    2415:	btc    r10,0x1d
    241a:	mov    r11d,0xf0000000
    2420:	and    r11,r10
    2423:	movabs rsi,0xffffffff0fffffff
    242d:	and    rbx,rsi
    2430:	or     rbx,r11
    2433:	pop    r11
    2435:	pop    r10
    2437:	pop    rsi
    2438:	pop    rdx
    2439:	mov    QWORD PTR [r12+0x108],rbx
    2441:	add    rsp,0xc0
    2448:	mov    eax,0xc
    244d:	movabs r11,0x580415130ca0
    2457:	jmp    r11
    245a:	nop    WORD PTR [rax+rax*1+0x0]
    2460:	sub    rsp,0xc0
    2467:	mov    r11,QWORD PTR [r12+0x398]
    246f:	mov    QWORD PTR [rsp+0xb0],r11
    2477:	jmp    0x59
    247c:	nop    DWORD PTR [rax+0x0]
    2480:	sub    rsp,0xc0
    2487:	mov    r11,QWORD PTR [r12+0x398]
    248f:	mov    QWORD PTR [rsp+0xb0],r11
    2497:	jmp    0x17a
    249c:	nop    DWORD PTR [rax+0x0]
    24a0:	sub    rsp,0xc0
    24a7:	mov    r11,QWORD PTR [r12+0x398]
    24af:	mov    QWORD PTR [rsp+0xb0],r11
    24b7:	jmp    0x234
    24bc:	nop    DWORD PTR [rax+0x0]
    24c0:	sub    rsp,0xc0
    24c7:	mov    r11,QWORD PTR [r12+0x398]
    24cf:	mov    QWORD PTR [rsp+0xb0],r11
    24d7:	jmp    0x1919
    24dc:	nop    DWORD PTR [rax+0x0]
    24e0:	sub    rsp,0xc0
    24e7:	mov    r11,QWORD PTR [r12+0x398]
    24ef:	mov    QWORD PTR [rsp+0xb0],r11
    24f7:	jmp    0x1a6a
    24fc:	nop    DWORD PTR [rax+0x0]
    2500:	sub    rsp,0xc0
    2507:	mov    r11,QWORD PTR [r12+0x398]
    250f:	mov    QWORD PTR [rsp+0xb0],r11
    2517:	jmp    0x1bed
    251c:	nop    DWORD PTR [rax+0x0]
    2520:	sub    rsp,0xc0
    2527:	mov    r11,QWORD PTR [r12+0x398]
    252f:	mov    QWORD PTR [rsp+0xb0],r11
    2537:	jmp    0x1f0f
    253c:	nop    DWORD PTR [rax+0x0]
    2540:	sub    rsp,0xc0
    2547:	mov    r11,QWORD PTR [r12+0x398]
    254f:	mov    QWORD PTR [rsp+0xb0],r11
    2557:	jmp    0x2057
    255c:	nop    DWORD PTR [rax+0x0]
    2560:	sub    rsp,0xc0
    2567:	mov    r11,QWORD PTR [r12+0x398]
    256f:	mov    QWORD PTR [rsp+0xb0],r11
    2577:	jmp    0x2076
    257c:	nop    DWORD PTR [rax+0x0]
    2580:	sub    rsp,0xc0
    2587:	mov    r11,QWORD PTR [r12+0x398]
    258f:	mov    QWORD PTR [rsp+0xb0],r11
    2597:	jmp    0x2155
