00007d248dbce69b  nop [rax+rax*1], eax
00007d248dbce6a0  vmovaps xmm1, [0x00007D248D7FE010]
00007d248dbce6a8  movq xmm1, xmm1
00007d248dbce6ac  movaps [r15+0x110], xmm1
00007d248dbce6b4  vmovaps xmm1, [0x00007D248D7FE020]
00007d248dbce6bc  movq xmm1, xmm1
00007d248dbce6c0  movaps [r15+0x120], xmm1
00007d248dbce6c8  mov eax, 0x4204C0
00007d248dbce6cd  mov r14, [r13+rax*1]
00007d248dbce6d2  movq xmm1, r14
00007d248dbce6d7  movaps [r15+0x130], xmm1
00007d248dbce6df  vmovaps xmm1, [0x00007D248D7FE030]
00007d248dbce6e7  vpbroadcastq xmm1, xmm1
00007d248dbce6ec  movaps [r15+0x140], xmm1
00007d248dbce6f4  mov qword ptr [r15+0x40], 0x02
00007d248dbce6fc  vmovaps xmm15, [0x00007D248D7FE040]
00007d248dbce704  movq xmm15, xmm15
00007d248dbce709  movaps [r15+0x150], xmm15
00007d248dbce711  mov qword ptr [r15+0x58], 0x420000
00007d248dbce719  vmovaps xmm15, [0x00007D248D7FE050]
00007d248dbce721  vpbroadcastq xmm15, xmm15
00007d248dbce726  movaps [r15+0x160], xmm15
00007d248dbce72e  mov rax, [r15+0x40]
00007d248dbce732  vmovq xmm14, rax
00007d248dbce737  vpbroadcastq xmm14, xmm14
00007d248dbce73c  movaps [r15+0x170], xmm14
00007d248dbce744  mov eax, 0x4204D0
00007d248dbce749  movups xmm13, [r13+rax*1]
00007d248dbce74f  mov qword ptr [r15+0x40], 0x430518
00007d248dbce757  mov qword ptr [r15+0x50], 0x430720
00007d248dbce75f  vpmovqd xmm12, xmm13
00007d248dbce765  pxor xmm11, xmm11
00007d248dbce76a  punpcklqdq xmm12, xmm11
00007d248dbce76f  movaps [r15+0x210], xmm12
00007d248dbce777  movq xmm12, qword ptr [r15+0x120]
00007d248dbce780  movq xmm11, qword ptr [r15+0x130]
00007d248dbce789  psubd xmm12, xmm11
00007d248dbce78e  movq xmm12, xmm12
00007d248dbce793  paddq xmm13, xmm14
00007d248dbce798  movaps [r15+0x180], xmm13
00007d248dbce7a0  movq xmm14, qword ptr [r15+0x150]
00007d248dbce7a9  paddd xmm11, xmm14
00007d248dbce7ae  movq xmm11, xmm11
00007d248dbce7b3  movq xmm11, xmm11
00007d248dbce7b8  movaps [r15+0x130], xmm11
00007d248dbce7c0  pmovzxdq xmm12, xmm12
00007d248dbce7c6  psllq xmm12, 0x00
00007d248dbce7cc  movq xmm14, qword ptr [r15+0x210]
00007d248dbce7d5  movq xmm13, qword ptr [r15+0x110]
00007d248dbce7de  paddd xmm14, xmm13
00007d248dbce7e3  movq xmm14, xmm14
00007d248dbce7e8  vcvtuqq2pd xmm12, xmm12
00007d248dbce7ee  pmovzxdq xmm14, xmm14
00007d248dbce7f4  psllq xmm14, 0x00
00007d248dbce7fa  vcvtuqq2pd xmm14, xmm14
00007d248dbce800  movaps xmm13, xmm12
00007d248dbce804  mulpd xmm13, xmm1
00007d248dbce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007d248dbce80f  ptest xmm11, xmm11
00007d248dbce815  jnz 0x00007D248DBCE8FF
00007d248dbce81b  movaps [r15+0x220], xmm13
00007d248dbce823  mov eax, 0x430720
00007d248dbce828  movups [r13+rax*1], xmm13
00007d248dbce82e  movaps xmm1, xmm14
00007d248dbce832  mulpd xmm1, xmm15
00007d248dbce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007d248dbce83c  ptest xmm13, xmm13
00007d248dbce842  jnz 0x00007D248DBCEA4C
00007d248dbce848  movaps [r15+0x210], xmm1
00007d248dbce850  mov eax, 0x430518
00007d248dbce855  movups [r13+rax*1], xmm1
00007d248dbce85b  mov qword ptr [r15+0x48], 0x10
00007d248dbce863  xor eax, eax
00007d248dbce865  mov r14d, 0x10
00007d248dbce86b  mov r12d, 0x200
00007d248dbce871  cmp r14, r12
00007d248dbce874  cmc
00007d248dbce875  lahf
00007d248dbce876  seto al
00007d248dbce879  mov [r15+0x108], eax
00007d248dbce880  mov eax, [r15+0x108]
00007d248dbce887  sahf
00007d248dbce888  jnz 0x00007D248DBCE8BA
00007d248dbce88a  cmp dword ptr [r15+0x318], 0x00
00007d248dbce892  jz 0x00007D248DBCEFF0
00007d248dbce898  nop [rax+rax*1], ax
00007d248dbce8a1  nop [rax+rax*1], eax
00007d248dbce8a9  mov eax, 0x4101EC
00007d248dbce8ae  mov [r15+0x100], rax
00007d248dbce8b5  jmp 0x00007D248D9FE110
00007d248dbce8ba  cmp dword ptr [r15+0x318], 0x00
00007d248dbce8c2  jz 0x00007D248DBCEBA0
00007d248dbce8c8  nop [rax+rax*1], ax
00007d248dbce8d1  nop [rax+rax*1], eax
00007d248dbce8d9  mov eax, 0x4101AC
00007d248dbce8de  mov [r15+0x100], rax
00007d248dbce8e5  jmp 0x00007D248D9FE110
00007d248dbce8ea  int3
00007d248dbce8eb  call 0x00007D248DA0DC20
00007d248dbce8f0  jmp 0x00007D248DBCE6D2
00007d248dbce8f5  call 0x00007D248DA0C260
00007d248dbce8fa  jmp 0x00007D248DBCE74F
00007d248dbce8ff  sub rsp, 0x08
00007d248dbce903  push rax
00007d248dbce904  push rcx
00007d248dbce905  push rdx
00007d248dbce906  push rdi
00007d248dbce907  push rsi
00007d248dbce908  push r8
00007d248dbce90a  push r9
00007d248dbce90c  push r10
00007d248dbce90e  push r11
00007d248dbce910  sub rsp, 0xF0
00007d248dbce917  vmovaps [rsp], xmm0
00007d248dbce91c  vmovaps [rsp+0x10], xmm1
00007d248dbce922  vmovaps [rsp+0x20], xmm2
00007d248dbce928  vmovaps [rsp+0x30], xmm3
00007d248dbce92e  vmovaps [rsp+0x40], xmm4
00007d248dbce934  vmovaps [rsp+0x50], xmm5
00007d248dbce93a  vmovaps [rsp+0x60], xmm6
00007d248dbce940  vmovaps [rsp+0x70], xmm7
00007d248dbce946  vmovaps [rsp+0x80], xmm8
00007d248dbce94f  vmovaps [rsp+0x90], xmm9
00007d248dbce958  vmovaps [rsp+0xA0], xmm10
00007d248dbce961  vmovaps [rsp+0xB0], xmm11
00007d248dbce96a  vmovaps [rsp+0xC0], xmm12
00007d248dbce973  vmovaps [rsp+0xD0], xmm14
00007d248dbce97c  vmovaps [rsp+0xE0], xmm15
00007d248dbce985  sub rsp, 0x30
00007d248dbce989  movaps [rsp], xmm13
00007d248dbce98e  movaps [rsp+0x10], xmm12
00007d248dbce994  movaps [rsp+0x20], xmm1
00007d248dbce999  lea rdi, [rsp]
00007d248dbce99d  mov esi, 0x00
00007d248dbce9a2  mov rax, 0x5BCEEF236530
00007d248dbce9ac  call rax
00007d248dbce9ae  movaps xmm13, [rsp]
00007d248dbce9b3  add rsp, 0x30
00007d248dbce9b7  vmovaps xmm0, [rsp]
00007d248dbce9bc  vmovaps xmm1, [rsp+0x10]
00007d248dbce9c2  vmovaps xmm2, [rsp+0x20]
00007d248dbce9c8  vmovaps xmm3, [rsp+0x30]
00007d248dbce9ce  vmovaps xmm4, [rsp+0x40]
00007d248dbce9d4  vmovaps xmm5, [rsp+0x50]
00007d248dbce9da  vmovaps xmm6, [rsp+0x60]
00007d248dbce9e0  vmovaps xmm7, [rsp+0x70]
00007d248dbce9e6  vmovaps xmm8, [rsp+0x80]
00007d248dbce9ef  vmovaps xmm9, [rsp+0x90]
00007d248dbce9f8  vmovaps xmm10, [rsp+0xA0]
00007d248dbcea01  vmovaps xmm11, [rsp+0xB0]
00007d248dbcea0a  vmovaps xmm12, [rsp+0xC0]
00007d248dbcea13  vmovaps xmm14, [rsp+0xD0]
00007d248dbcea1c  vmovaps xmm15, [rsp+0xE0]
00007d248dbcea25  add rsp, 0xF0
00007d248dbcea2c  pop r11
00007d248dbcea2e  pop r10
00007d248dbcea30  pop r9
00007d248dbcea32  pop r8
00007d248dbcea34  pop rsi
00007d248dbcea35  pop rdi
00007d248dbcea36  pop rdx
00007d248dbcea37  pop rcx
00007d248dbcea38  pop rax
00007d248dbcea39  add rsp, 0x08
00007d248dbcea3d  jmp 0x00007D248DBCE81B
00007d248dbcea42  call 0x00007D248DA0C380
00007d248dbcea47  jmp 0x00007D248DBCE82E
00007d248dbcea4c  sub rsp, 0x08
00007d248dbcea50  push rax
00007d248dbcea51  push rcx
00007d248dbcea52  push rdx
00007d248dbcea53  push rdi
00007d248dbcea54  push rsi
00007d248dbcea55  push r8
00007d248dbcea57  push r9
00007d248dbcea59  push r10
00007d248dbcea5b  push r11
00007d248dbcea5d  sub rsp, 0xF0
00007d248dbcea64  vmovaps [rsp], xmm0
00007d248dbcea69  vmovaps [rsp+0x10], xmm2
00007d248dbcea6f  vmovaps [rsp+0x20], xmm3
00007d248dbcea75  vmovaps [rsp+0x30], xmm4
00007d248dbcea7b  vmovaps [rsp+0x40], xmm5
00007d248dbcea81  vmovaps [rsp+0x50], xmm6
00007d248dbcea87  vmovaps [rsp+0x60], xmm7
00007d248dbcea8d  vmovaps [rsp+0x70], xmm8
00007d248dbcea93  vmovaps [rsp+0x80], xmm9
00007d248dbcea9c  vmovaps [rsp+0x90], xmm10
00007d248dbceaa5  vmovaps [rsp+0xA0], xmm11
00007d248dbceaae  vmovaps [rsp+0xB0], xmm12
00007d248dbceab7  vmovaps [rsp+0xC0], xmm13
00007d248dbceac0  vmovaps [rsp+0xD0], xmm14
00007d248dbceac9  vmovaps [rsp+0xE0], xmm15
00007d248dbcead2  sub rsp, 0x30
00007d248dbcead6  movaps [rsp], xmm1
00007d248dbceada  movaps [rsp+0x10], xmm14
00007d248dbceae0  movaps [rsp+0x20], xmm15
00007d248dbceae6  lea rdi, [rsp]
00007d248dbceaea  mov esi, 0x00
00007d248dbceaef  mov rax, 0x5BCEEF236530
00007d248dbceaf9  call rax
00007d248dbceafb  movaps xmm1, [rsp]
00007d248dbceaff  add rsp, 0x30
00007d248dbceb03  vmovaps xmm0, [rsp]
00007d248dbceb08  vmovaps xmm2, [rsp+0x10]
00007d248dbceb0e  vmovaps xmm3, [rsp+0x20]
00007d248dbceb14  vmovaps xmm4, [rsp+0x30]
00007d248dbceb1a  vmovaps xmm5, [rsp+0x40]
00007d248dbceb20  vmovaps xmm6, [rsp+0x50]
00007d248dbceb26  vmovaps xmm7, [rsp+0x60]
00007d248dbceb2c  vmovaps xmm8, [rsp+0x70]
00007d248dbceb32  vmovaps xmm9, [rsp+0x80]
00007d248dbceb3b  vmovaps xmm10, [rsp+0x90]
00007d248dbceb44  vmovaps xmm11, [rsp+0xA0]
00007d248dbceb4d  vmovaps xmm12, [rsp+0xB0]
00007d248dbceb56  vmovaps xmm13, [rsp+0xC0]
00007d248dbceb5f  vmovaps xmm14, [rsp+0xD0]
00007d248dbceb68  vmovaps xmm15, [rsp+0xE0]
00007d248dbceb71  add rsp, 0xF0
00007d248dbceb78  pop r11
00007d248dbceb7a  pop r10
00007d248dbceb7c  pop r9
00007d248dbceb7e  pop r8
00007d248dbceb80  pop rsi
00007d248dbceb81  pop rdi
00007d248dbceb82  pop rdx
00007d248dbceb83  pop rcx
00007d248dbceb84  pop rax
00007d248dbceb85  add rsp, 0x08
00007d248dbceb89  jmp 0x00007D248DBCE848
00007d248dbceb8e  call 0x00007D248D9FF540
00007d248dbceb93  jmp 0x00007D248DBCE85B
00007d248dbceb98  int3
00007d248dbceb99  nop [rax], eax
00007d248dbceba0  movaps xmm1, [r15+0x180]
00007d248dbceba8  vpmovqd xmm15, xmm1
00007d248dbcebae  pxor xmm14, xmm14
00007d248dbcebb3  punpcklqdq xmm15, xmm14
00007d248dbcebb8  movaps [r15+0x210], xmm15
00007d248dbcebc0  movq xmm15, qword ptr [r15+0x120]
00007d248dbcebc9  movq xmm14, qword ptr [r15+0x130]
00007d248dbcebd2  psubd xmm15, xmm14
00007d248dbcebd7  movq xmm15, xmm15
00007d248dbcebdc  movaps xmm13, [r15+0x170]
00007d248dbcebe4  paddq xmm1, xmm13
00007d248dbcebe9  movaps [r15+0x180], xmm1
00007d248dbcebf1  movq xmm1, qword ptr [r15+0x150]
00007d248dbcebfa  paddd xmm14, xmm1
00007d248dbcebff  movq xmm14, xmm14
00007d248dbcec04  movq xmm14, xmm14
00007d248dbcec09  movaps [r15+0x130], xmm14
00007d248dbcec11  pmovzxdq xmm15, xmm15
00007d248dbcec17  psllq xmm15, 0x00
00007d248dbcec1d  movq xmm1, qword ptr [r15+0x210]
00007d248dbcec26  movq xmm14, qword ptr [r15+0x110]
00007d248dbcec2f  paddd xmm1, xmm14
00007d248dbcec34  movq xmm1, xmm1
00007d248dbcec38  vcvtuqq2pd xmm15, xmm15
00007d248dbcec3e  pmovzxdq xmm1, xmm1
00007d248dbcec43  psllq xmm1, 0x00
00007d248dbcec48  vcvtuqq2pd xmm1, xmm1
00007d248dbcec4e  movaps xmm14, [r15+0x140]
00007d248dbcec56  movaps xmm13, xmm15
00007d248dbcec5a  mulpd xmm13, xmm14
00007d248dbcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007d248dbcec65  ptest xmm12, xmm12
00007d248dbcec6b  jnz 0x00007D248DBCED4E
00007d248dbcec71  movaps [r15+0x220], xmm13
00007d248dbcec79  mov rax, [r15+0x48]
00007d248dbcec7d  mov r14, [r15+0x50]
00007d248dbcec81  lea r12, [r14+rax*1]
00007d248dbcec85  movups [r13+r12*1], xmm13
00007d248dbcec8b  movaps xmm15, [r15+0x160]
00007d248dbcec93  movaps xmm14, xmm1
00007d248dbcec97  mulpd xmm14, xmm15
00007d248dbcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007d248dbceca2  ptest xmm13, xmm13
00007d248dbceca8  jnz 0x00007D248DBCEE9C
00007d248dbcecae  movaps [r15+0x210], xmm14
00007d248dbcecb6  mov r14, [r15+0x40]
00007d248dbcecba  lea r12, [r14+rax*1]
00007d248dbcecbe  movups [r13+r12*1], xmm14
00007d248dbcecc4  lea r14, [rax+0x10]
00007d248dbcecc8  mov [r15+0x48], r14
00007d248dbceccc  xor eax, eax
00007d248dbcecce  mov r12d, 0x200
00007d248dbcecd4  cmp r14, r12
00007d248dbcecd7  cmc
00007d248dbcecd8  lahf
00007d248dbcecd9  seto al
00007d248dbcecdc  mov [r15+0x108], eax
00007d248dbcece3  mov eax, [r15+0x108]
00007d248dbcecea  sahf
00007d248dbceceb  jnz 0x00007D248DBCED1D
00007d248dbceced  cmp dword ptr [r15+0x318], 0x00
00007d248dbcecf5  jz 0x00007D248DBCEFF0
00007d248dbcecfb  nop [rax+rax*1], ax
00007d248dbced04  nop [rax+rax*1], eax
00007d248dbced0c  mov eax, 0x4101EC
00007d248dbced11  mov [r15+0x100], rax
00007d248dbced18  jmp 0x00007D248D9FE110
00007d248dbced1d  cmp dword ptr [r15+0x318], 0x00
00007d248dbced25  jz 0x00007D248DBCEBA0
00007d248dbced2b  nop [rax+rax*1], ax
00007d248dbced34  nop [rax+rax*1], eax
00007d248dbced3c  mov eax, 0x4101AC
00007d248dbced41  mov [r15+0x100], rax
00007d248dbced48  jmp 0x00007D248D9FE110
00007d248dbced4d  int3
00007d248dbced4e  sub rsp, 0x08
00007d248dbced52  push rax
00007d248dbced53  push rcx
00007d248dbced54  push rdx
00007d248dbced55  push rdi
00007d248dbced56  push rsi
00007d248dbced57  push r8
00007d248dbced59  push r9
00007d248dbced5b  push r10
00007d248dbced5d  push r11
00007d248dbced5f  sub rsp, 0xF0
00007d248dbced66  vmovaps [rsp], xmm0
00007d248dbced6b  vmovaps [rsp+0x10], xmm1
00007d248dbced71  vmovaps [rsp+0x20], xmm2
00007d248dbced77  vmovaps [rsp+0x30], xmm3
00007d248dbced7d  vmovaps [rsp+0x40], xmm4
00007d248dbced83  vmovaps [rsp+0x50], xmm5
00007d248dbced89  vmovaps [rsp+0x60], xmm6
00007d248dbced8f  vmovaps [rsp+0x70], xmm7
00007d248dbced95  vmovaps [rsp+0x80], xmm8
00007d248dbced9e  vmovaps [rsp+0x90], xmm9
00007d248dbceda7  vmovaps [rsp+0xA0], xmm10
00007d248dbcedb0  vmovaps [rsp+0xB0], xmm11
00007d248dbcedb9  vmovaps [rsp+0xC0], xmm12
00007d248dbcedc2  vmovaps [rsp+0xD0], xmm14
00007d248dbcedcb  vmovaps [rsp+0xE0], xmm15
00007d248dbcedd4  sub rsp, 0x30
00007d248dbcedd8  movaps [rsp], xmm13
00007d248dbceddd  movaps [rsp+0x10], xmm15
00007d248dbcede3  movaps [rsp+0x20], xmm14
00007d248dbcede9  lea rdi, [rsp]
00007d248dbceded  mov esi, 0x00
00007d248dbcedf2  mov rax, 0x5BCEEF236530
00007d248dbcedfc  call rax
00007d248dbcedfe  movaps xmm13, [rsp]
00007d248dbcee03  add rsp, 0x30
00007d248dbcee07  vmovaps xmm0, [rsp]
00007d248dbcee0c  vmovaps xmm1, [rsp+0x10]
00007d248dbcee12  vmovaps xmm2, [rsp+0x20]
00007d248dbcee18  vmovaps xmm3, [rsp+0x30]
00007d248dbcee1e  vmovaps xmm4, [rsp+0x40]
00007d248dbcee24  vmovaps xmm5, [rsp+0x50]
00007d248dbcee2a  vmovaps xmm6, [rsp+0x60]
00007d248dbcee30  vmovaps xmm7, [rsp+0x70]
00007d248dbcee36  vmovaps xmm8, [rsp+0x80]
00007d248dbcee3f  vmovaps xmm9, [rsp+0x90]
00007d248dbcee48  vmovaps xmm10, [rsp+0xA0]
00007d248dbcee51  vmovaps xmm11, [rsp+0xB0]
00007d248dbcee5a  vmovaps xmm12, [rsp+0xC0]
00007d248dbcee63  vmovaps xmm14, [rsp+0xD0]
00007d248dbcee6c  vmovaps xmm15, [rsp+0xE0]
00007d248dbcee75  add rsp, 0xF0
00007d248dbcee7c  pop r11
00007d248dbcee7e  pop r10
00007d248dbcee80  pop r9
00007d248dbcee82  pop r8
00007d248dbcee84  pop rsi
00007d248dbcee85  pop rdi
00007d248dbcee86  pop rdx
00007d248dbcee87  pop rcx
00007d248dbcee88  pop rax
00007d248dbcee89  add rsp, 0x08
00007d248dbcee8d  jmp 0x00007D248DBCEC71
00007d248dbcee92  call 0x00007D248DAC2240
00007d248dbcee97  jmp 0x00007D248DBCEC8B
00007d248dbcee9c  sub rsp, 0x08
00007d248dbceea0  push rax
00007d248dbceea1  push rcx
00007d248dbceea2  push rdx
00007d248dbceea3  push rdi
00007d248dbceea4  push rsi
00007d248dbceea5  push r8
00007d248dbceea7  push r9
00007d248dbceea9  push r10
00007d248dbceeab  push r11
00007d248dbceead  sub rsp, 0xF0
00007d248dbceeb4  vmovaps [rsp], xmm0
00007d248dbceeb9  vmovaps [rsp+0x10], xmm1
00007d248dbceebf  vmovaps [rsp+0x20], xmm2
00007d248dbceec5  vmovaps [rsp+0x30], xmm3
00007d248dbceecb  vmovaps [rsp+0x40], xmm4
00007d248dbceed1  vmovaps [rsp+0x50], xmm5
00007d248dbceed7  vmovaps [rsp+0x60], xmm6
00007d248dbceedd  vmovaps [rsp+0x70], xmm7
00007d248dbceee3  vmovaps [rsp+0x80], xmm8
00007d248dbceeec  vmovaps [rsp+0x90], xmm9
00007d248dbceef5  vmovaps [rsp+0xA0], xmm10
00007d248dbceefe  vmovaps [rsp+0xB0], xmm11
00007d248dbcef07  vmovaps [rsp+0xC0], xmm12
00007d248dbcef10  vmovaps [rsp+0xD0], xmm13
00007d248dbcef19  vmovaps [rsp+0xE0], xmm15
00007d248dbcef22  sub rsp, 0x30
00007d248dbcef26  movaps [rsp], xmm14
00007d248dbcef2b  movaps [rsp+0x10], xmm1
00007d248dbcef30  movaps [rsp+0x20], xmm15
00007d248dbcef36  lea rdi, [rsp]
00007d248dbcef3a  mov esi, 0x00
00007d248dbcef3f  mov rax, 0x5BCEEF236530
00007d248dbcef49  call rax
00007d248dbcef4b  movaps xmm14, [rsp]
00007d248dbcef50  add rsp, 0x30
00007d248dbcef54  vmovaps xmm0, [rsp]
00007d248dbcef59  vmovaps xmm1, [rsp+0x10]
00007d248dbcef5f  vmovaps xmm2, [rsp+0x20]
00007d248dbcef65  vmovaps xmm3, [rsp+0x30]
00007d248dbcef6b  vmovaps xmm4, [rsp+0x40]
00007d248dbcef71  vmovaps xmm5, [rsp+0x50]
00007d248dbcef77  vmovaps xmm6, [rsp+0x60]
00007d248dbcef7d  vmovaps xmm7, [rsp+0x70]
00007d248dbcef83  vmovaps xmm8, [rsp+0x80]
00007d248dbcef8c  vmovaps xmm9, [rsp+0x90]
00007d248dbcef95  vmovaps xmm10, [rsp+0xA0]
00007d248dbcef9e  vmovaps xmm11, [rsp+0xB0]
00007d248dbcefa7  vmovaps xmm12, [rsp+0xC0]
00007d248dbcefb0  vmovaps xmm13, [rsp+0xD0]
00007d248dbcefb9  vmovaps xmm15, [rsp+0xE0]
00007d248dbcefc2  add rsp, 0xF0
00007d248dbcefc9  pop r11
00007d248dbcefcb  pop r10
00007d248dbcefcd  pop r9
00007d248dbcefcf  pop r8
00007d248dbcefd1  pop rsi
00007d248dbcefd2  pop rdi
00007d248dbcefd3  pop rdx
00007d248dbcefd4  pop rcx
00007d248dbcefd5  pop rax
00007d248dbcefd6  add rsp, 0x08
00007d248dbcefda  jmp 0x00007D248DBCECAE
00007d248dbcefdf  call 0x00007D248DAC34C0
00007d248dbcefe4  jmp 0x00007D248DBCECC4
00007d248dbcefe9  int3
00007d248dbcefea  nop [rax+rax*1], ax
00007d248dbceff0  mov rax, [r15+0xF8]
00007d248dbceff7  lea r14, [rax-0x150]
00007d248dbceffe  mov [r15+0xF8], r14
00007d248dbcf005  mov rax, [r15+0x50]
00007d248dbcf009  lea r12, [rax+0x80]
00007d248dbcf010  movups xmm1, [r13+r12*1]
00007d248dbcf016  lea r12, [rax+0x90]
00007d248dbcf01d  movups xmm15, [r13+r12*1]
00007d248dbcf023  mov qword ptr [r15+0x48], 0x00
00007d248dbcf02b  lea r12, [rax+0x40]
00007d248dbcf02f  movups xmm14, [r13+r12*1]
00007d248dbcf035  lea r12, [rax+0x50]
00007d248dbcf039  movups xmm13, [r13+r12*1]
00007d248dbcf03f  lea r12, [r14+0x120]
00007d248dbcf046  movq xmm12, qword ptr [r15+0x1C0]
00007d248dbcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007d248dbcf058  movq r11, xmm12
00007d248dbcf05d  movq r10, xmm11
00007d248dbcf062  mov [r13+r12*1], r11
00007d248dbcf067  lea r12, [r14+0x128]
00007d248dbcf06e  mov [r13+r12*1], r10
00007d248dbcf073  vxorps xmm12, xmm12, xmm12
00007d248dbcf078  vpbroadcastq xmm12, xmm12
00007d248dbcf07d  lea r12, [r14+0x100]
00007d248dbcf084  movq xmm11, qword ptr [r15+0x200]
00007d248dbcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007d248dbcf096  movq r11, xmm11
00007d248dbcf09b  movq r10, xmm10
00007d248dbcf0a0  mov [r13+r12*1], r11
00007d248dbcf0a5  lea r12, [r14+0x108]
00007d248dbcf0ac  mov [r13+r12*1], r10
00007d248dbcf0b1  lea r12, [r14+0xE0]
00007d248dbcf0b8  movups [r13+r12*1], xmm15
00007d248dbcf0be  lea r12, [r14+0xF0]
00007d248dbcf0c5  movups [r13+r12*1], xmm1
00007d248dbcf0cb  lea r12, [rax+0xC0]
00007d248dbcf0d2  movups xmm1, [r13+r12*1]
00007d248dbcf0d8  lea r12, [rax+0xD0]
00007d248dbcf0df  movups xmm15, [r13+r12*1]
00007d248dbcf0e5  lea r12, [r14+0x110]
00007d248dbcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007d248dbcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007d248dbcf0fe  movq r11, xmm11
00007d248dbcf103  movq r10, xmm10
00007d248dbcf108  mov [r13+r12*1], r11
00007d248dbcf10d  lea r12, [r14+0x118]
00007d248dbcf114  mov [r13+r12*1], r10
00007d248dbcf119  movups xmm11, [r13+rax*1]
00007d248dbcf11f  lea r12, [rax+0x10]
00007d248dbcf123  movups xmm10, [r13+r12*1]
00007d248dbcf129  lea r12, [r14+0x130]
00007d248dbcf130  movq xmm9, qword ptr [r15+0x1A0]
00007d248dbcf139  movq xmm8, qword ptr [r15+0x190]
00007d248dbcf142  movq r11, xmm9
00007d248dbcf147  movq r10, xmm8
00007d248dbcf14c  mov [r13+r12*1], r11
00007d248dbcf151  lea r12, [r14+0x138]
00007d248dbcf158  mov [r13+r12*1], r10
00007d248dbcf15d  lea r12, [rax+0x140]
00007d248dbcf164  movups xmm9, [r13+r12*1]
00007d248dbcf16a  lea r12, [rax+0x150]
00007d248dbcf171  movups xmm8, [r13+r12*1]
00007d248dbcf177  lea r12, [r14+0xC0]
00007d248dbcf17e  movups [r13+r12*1], xmm15
00007d248dbcf184  lea r12, [r14+0xD0]
00007d248dbcf18b  movups [r13+r12*1], xmm1
00007d248dbcf191  lea r12, [rax+0x100]
00007d248dbcf198  movups xmm1, [r13+r12*1]
00007d248dbcf19e  lea r12, [rax+0x110]
00007d248dbcf1a5  movups xmm15, [r13+r12*1]
00007d248dbcf1ab  lea r12, [r14+0x140]
00007d248dbcf1b2  mov r11, [r15+0xE8]
00007d248dbcf1b9  mov [r13+r12*1], r11
00007d248dbcf1be  lea r12, [rax+0x180]
00007d248dbcf1c5  movups xmm7, [r13+r12*1]
00007d248dbcf1cb  lea r12, [rax+0x190]
00007d248dbcf1d2  movups xmm6, [r13+r12*1]
00007d248dbcf1d8  lea r12, [rax+0x1C0]
00007d248dbcf1df  movups xmm5, [r13+r12*1]
00007d248dbcf1e5  lea r12, [rax+0x1D0]
00007d248dbcf1ec  movups xmm4, [r13+r12*1]
00007d248dbcf1f2  lea r12, [r14+0x20]
00007d248dbcf1f6  movups [r13+r12*1], xmm1
00007d248dbcf1fc  lea r12, [r14+0x30]
00007d248dbcf200  movups [r13+r12*1], xmm13
00007d248dbcf206  lea r12, [rax+0x60]
00007d248dbcf20a  movups xmm1, [r13+r12*1]
00007d248dbcf210  lea r12, [rax+0x70]
00007d248dbcf214  movups xmm13, [r13+r12*1]
00007d248dbcf21a  lea r12, [rax+0x20]
00007d248dbcf21e  movups xmm3, [r13+r12*1]
00007d248dbcf224  lea r12, [rax+0x30]
00007d248dbcf228  movups xmm2, [r13+r12*1]
00007d248dbcf22e  movaps [r15+0x1F0], xmm2
00007d248dbcf236  lea r12, [r14+0x60]
00007d248dbcf23a  movups [r13+r12*1], xmm11
00007d248dbcf240  lea r12, [r14+0x70]
00007d248dbcf244  movups [r13+r12*1], xmm5
00007d248dbcf24a  lea r12, [rax+0xE0]
00007d248dbcf251  movups xmm11, [r13+r12*1]
00007d248dbcf257  lea r12, [rax+0xF0]
00007d248dbcf25e  movups xmm5, [r13+r12*1]
00007d248dbcf264  lea r12, [r14+0xA0]
00007d248dbcf26b  movups [r13+r12*1], xmm13
00007d248dbcf271  lea r12, [r14+0xB0]
00007d248dbcf278  movups [r13+r12*1], xmm1
00007d248dbcf27e  lea r12, [rax+0xA0]
00007d248dbcf285  movups xmm1, [r13+r12*1]
00007d248dbcf28b  lea r12, [rax+0xB0]
00007d248dbcf292  movups xmm13, [r13+r12*1]
00007d248dbcf298  lea r12, [rax+0x120]
00007d248dbcf29f  vmovaps [rsp+0x10], xmm1
00007d248dbcf2a5  movups xmm1, [r13+r12*1]
00007d248dbcf2ab  lea r12, [rax+0x130]
00007d248dbcf2b2  vmovaps [rsp+0x20], xmm1
00007d248dbcf2b8  movups xmm1, [r13+r12*1]
00007d248dbcf2be  lea r12, [rax+0x160]
00007d248dbcf2c5  vmovaps [rsp+0x30], xmm1
00007d248dbcf2cb  movups xmm1, [r13+r12*1]
00007d248dbcf2d1  lea r12, [rax+0x170]
00007d248dbcf2d8  vmovaps [rsp+0x40], xmm1
00007d248dbcf2de  movups xmm1, [r13+r12*1]
00007d248dbcf2e4  movaps [r15+0x2B0], xmm1
00007d248dbcf2ec  lea r12, [r14+0x80]
00007d248dbcf2f3  movups [r13+r12*1], xmm13
00007d248dbcf2f9  lea r12, [r14+0x90]
00007d248dbcf300  vmovaps xmm13, [rsp+0x10]
00007d248dbcf306  movups [r13+r12*1], xmm13
00007d248dbcf30c  lea r12, [rax+0x1A0]
00007d248dbcf313  movups xmm13, [r13+r12*1]
00007d248dbcf319  lea r12, [rax+0x1B0]
00007d248dbcf320  vmovaps [rsp+0x10], xmm1
00007d248dbcf326  movups xmm1, [r13+r12*1]
00007d248dbcf32c  movaps [r15+0x290], xmm13
00007d248dbcf334  movaps [r15+0x1E0], xmm1
00007d248dbcf33c  lea r12, [rax+0x1E0]
00007d248dbcf343  vmovaps [rsp+0x50], xmm1
00007d248dbcf349  movups xmm1, [r13+r12*1]
00007d248dbcf34f  lea r12, [rax+0x1F0]
00007d248dbcf356  vmovaps [rsp+0x60], xmm1
00007d248dbcf35c  movups xmm1, [r13+r12*1]
00007d248dbcf362  mov qword ptr [r15+0x50], 0x430920
00007d248dbcf36a  lea rax, [r14+0x40]
00007d248dbcf36e  vmovaps [rsp+0x70], xmm1
00007d248dbcf374  vmovaps xmm1, [rsp+0x40]
00007d248dbcf37a  movups [r13+rax*1], xmm1
00007d248dbcf380  lea rax, [r14+0x50]
00007d248dbcf384  movups [r13+rax*1], xmm10
00007d248dbcf38a  vmovaps xmm1, [rsp+0x70]
00007d248dbcf390  movups [r13+r14*1], xmm1
00007d248dbcf396  lea rax, [r14+0x10]
00007d248dbcf39a  vmovaps xmm1, [rsp+0x60]
00007d248dbcf3a0  movups [r13+rax*1], xmm1
00007d248dbcf3a6  mov rax, [r15+0x40]
00007d248dbcf3aa  vmovaps [rsp+0x40], xmm3
00007d248dbcf3b0  vmovaps xmm1, [rsp+0x40]
00007d248dbcf3b6  por xmm3, xmm1
00007d248dbcf3ba  vmovaps [rsp+0x40], xmm6
00007d248dbcf3c0  vmovaps xmm10, [rsp+0x40]
00007d248dbcf3c6  por xmm6, xmm10
00007d248dbcf3cb  lea r12, [rax+0x30]
00007d248dbcf3cf  mov r11, [r13+r12*1]
00007d248dbcf3d4  lea r12, [rax+0x38]
00007d248dbcf3d8  mov r10, [r13+r12*1]
00007d248dbcf3dd  movq xmm10, r11
00007d248dbcf3e2  vmovaps [rsp+0x40], xmm1
00007d248dbcf3e8  movq xmm1, r10
00007d248dbcf3ed  movq xmm10, xmm10
00007d248dbcf3f2  vmovaps [rsp+0x60], xmm10
00007d248dbcf3f8  movq xmm10, xmm10
00007d248dbcf3fd  movaps [r15+0x130], xmm10
00007d248dbcf405  movq xmm1, xmm1
00007d248dbcf409  vmovaps [rsp+0x70], xmm1
00007d248dbcf40f  movq xmm1, xmm1
00007d248dbcf413  movaps [r15+0x280], xmm1
00007d248dbcf41b  vmovaps [rsp+0x80], xmm9
00007d248dbcf424  vmovaps xmm1, [rsp+0x80]
00007d248dbcf42d  por xmm9, xmm1
00007d248dbcf432  lea r12, [rax+0x20]
00007d248dbcf436  mov r11, [r13+r12*1]
00007d248dbcf43b  lea r12, [rax+0x28]
00007d248dbcf43f  mov r10, [r13+r12*1]
00007d248dbcf444  movq xmm1, r11
00007d248dbcf449  movq xmm10, r10
00007d248dbcf44e  movq xmm1, xmm1
00007d248dbcf452  vmovaps [rsp+0x80], xmm1
00007d248dbcf45b  movq xmm1, xmm1
00007d248dbcf45f  movaps [r15+0x150], xmm1
00007d248dbcf467  movq xmm10, xmm10
00007d248dbcf46c  vmovaps [rsp+0x90], xmm10
00007d248dbcf475  movq xmm10, xmm10
00007d248dbcf47a  movaps [r15+0x140], xmm10
00007d248dbcf482  lea r12, [rax+0x10]
00007d248dbcf486  mov r11, [r13+r12*1]
00007d248dbcf48b  lea r12, [rax+0x18]
00007d248dbcf48f  mov r10, [r13+r12*1]
00007d248dbcf494  movq xmm1, r11
00007d248dbcf499  movq xmm10, r10
00007d248dbcf49e  movq xmm1, xmm1
00007d248dbcf4a2  vmovaps [rsp+0xA0], xmm1
00007d248dbcf4ab  movq xmm1, xmm1
00007d248dbcf4af  movaps [r15+0x170], xmm1
00007d248dbcf4b7  movq xmm10, xmm10
00007d248dbcf4bc  vmovaps [rsp+0xB0], xmm10
00007d248dbcf4c5  movq xmm10, xmm10
00007d248dbcf4ca  movaps [r15+0x160], xmm10
00007d248dbcf4d2  mov r12, [r13+rax*1]
00007d248dbcf4d7  vmovq xmm1, r12
00007d248dbcf4dc  vpbroadcastq xmm1, xmm1
00007d248dbcf4e1  lea r12, [rax+0x08]
00007d248dbcf4e5  mov rax, [r13+r12*1]
00007d248dbcf4ea  movq xmm10, rax
00007d248dbcf4ef  movaps [r15+0x230], xmm10
00007d248dbcf4f7  lea rax, [r14+0x50]
00007d248dbcf4fb  movups xmm10, [r13+rax*1]
00007d248dbcf501  lea rax, [r14+0x60]
00007d248dbcf505  vmovaps [rsp+0xC0], xmm1
00007d248dbcf50e  movups xmm1, [r13+rax*1]
00007d248dbcf514  lea rax, [r14+0x30]
00007d248dbcf518  vmovaps [rsp+0xD0], xmm1
00007d248dbcf521  movups xmm1, [r13+rax*1]
00007d248dbcf527  mov qword ptr [r15+0x60], 0x430920
00007d248dbcf52f  mov qword ptr [r15+0x58], 0x40
00007d248dbcf537  vmovaps [rsp+0xE0], xmm1
00007d248dbcf540  vmovaps [rsp+0xF0], xmm15
00007d248dbcf549  vmovaps xmm15, [rsp+0xC0]
00007d248dbcf552  vmovaps [rsp+0xC0], xmm14
00007d248dbcf55b  vmovaps xmm14, [rsp+0x40]
00007d248dbcf561  vmovaps [rsp+0x40], xmm13
00007d248dbcf567  movaps xmm1, xmm15
00007d248dbcf56b  mulpd xmm1, xmm14
00007d248dbcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007d248dbcf575  ptest xmm13, xmm13
00007d248dbcf57b  jnz 0x00007D248DBD0682
00007d248dbcf581  movq xmm14, qword ptr [r15+0x230]
00007d248dbcf58a  vmovaps [rsp+0x100], xmm14
00007d248dbcf593  vpermilpd xmm14, xmm14, 0x00
00007d248dbcf599  vmovaps [rsp+0x110], xmm1
00007d248dbcf5a2  vmovaps xmm1, [rsp+0xE0]
00007d248dbcf5ab  vmovaps [rsp+0xE0], xmm15
00007d248dbcf5b4  movaps xmm13, xmm1
00007d248dbcf5b8  mulpd xmm13, xmm14
00007d248dbcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007d248dbcf5c3  ptest xmm15, xmm15
00007d248dbcf5c9  jnz 0x00007D248DBD07C4
00007d248dbcf5cf  vxorps xmm1, xmm1, xmm1
00007d248dbcf5d3  vpbroadcastq xmm1, xmm1
00007d248dbcf5d8  vmovaps xmm14, [rsp+0xE0]
00007d248dbcf5e1  vmovaps [rsp+0xE0], xmm1
00007d248dbcf5ea  vmovaps xmm1, [rsp+0xD0]
00007d248dbcf5f3  vmovaps [rsp+0xD0], xmm13
00007d248dbcf5fc  movaps xmm15, xmm14
00007d248dbcf600  mulpd xmm15, xmm1
00007d248dbcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007d248dbcf60b  ptest xmm13, xmm13
00007d248dbcf611  jnz 0x00007D248DBD0907
00007d248dbcf617  movaps xmm1, xmm14
00007d248dbcf61b  mulpd xmm1, xmm10
00007d248dbcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007d248dbcf625  ptest xmm13, xmm13
00007d248dbcf62b  jnz 0x00007D248DBD0A4A
00007d248dbcf631  movaps xmm13, xmm14
00007d248dbcf635  mulpd xmm13, xmm2
00007d248dbcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007d248dbcf640  ptest xmm10, xmm10
00007d248dbcf646  jnz 0x00007D248DBD0B8C
00007d248dbcf64c  vmovaps [rsp+0x120], xmm7
00007d248dbcf655  vmovaps xmm14, [rsp+0x120]
00007d248dbcf65e  por xmm7, xmm14
00007d248dbcf663  vmovaps xmm14, [rsp+0xC0]
00007d248dbcf66c  vmovaps xmm10, [rsp+0xC0]
00007d248dbcf675  por xmm14, xmm10
00007d248dbcf67a  vmovaps xmm2, [rsp+0x100]
00007d248dbcf683  vpermilpd xmm2, xmm2, 0x00
00007d248dbcf689  vmovaps [rsp+0xC0], xmm1
00007d248dbcf692  vmovaps [rsp+0x120], xmm15
00007d248dbcf69b  movaps xmm1, xmm10
00007d248dbcf69f  mulpd xmm1, xmm2
00007d248dbcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007d248dbcf6a8  ptest xmm15, xmm15
00007d248dbcf6ae  jnz 0x00007D248DBD0CCF
00007d248dbcf6b4  xor eax, eax
00007d248dbcf6b6  mov r12d, 0x40
00007d248dbcf6bc  mov r11d, 0x200
00007d248dbcf6c2  cmp r12, r11
00007d248dbcf6c5  cmc
00007d248dbcf6c6  lahf
00007d248dbcf6c7  seto al
00007d248dbcf6ca  mov [r15+0x108], eax
00007d248dbcf6d1  vmovaps xmm10, [rsp+0x110]
00007d248dbcf6da  vmovaps xmm2, [rsp+0xE0]
00007d248dbcf6e3  vmovaps [rsp+0xE0], xmm1
00007d248dbcf6ec  movaps xmm15, xmm10
00007d248dbcf6f0  addpd xmm15, xmm2
00007d248dbcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d248dbcf6fb  ptest xmm1, xmm1
00007d248dbcf700  jnz 0x00007D248DBD0E10
00007d248dbcf706  vmovaps xmm10, [rsp+0x120]
00007d248dbcf70f  vmovaps [rsp+0x110], xmm15
00007d248dbcf718  movaps xmm1, xmm10
00007d248dbcf71c  addpd xmm1, xmm12
00007d248dbcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007d248dbcf726  ptest xmm15, xmm15
00007d248dbcf72c  jnz 0x00007D248DBD0F53
00007d248dbcf732  vmovaps xmm10, [rsp+0xC0]
00007d248dbcf73b  vmovaps [rsp+0xC0], xmm1
00007d248dbcf744  movaps xmm15, xmm10
00007d248dbcf748  addpd xmm15, xmm12
00007d248dbcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007d248dbcf753  ptest xmm1, xmm1
00007d248dbcf758  jnz 0x00007D248DBD1095
00007d248dbcf75e  vmovaps xmm1, [rsp+0x30]
00007d248dbcf764  vmovaps xmm12, [rsp+0x30]
00007d248dbcf76a  por xmm1, xmm12
00007d248dbcf76f  vmovaps xmm12, [rsp+0x20]
00007d248dbcf775  vmovaps xmm10, [rsp+0x20]
00007d248dbcf77b  por xmm12, xmm10
00007d248dbcf780  vmovaps [rsp+0x20], xmm5
00007d248dbcf786  vmovaps xmm10, [rsp+0x20]
00007d248dbcf78c  por xmm5, xmm10
00007d248dbcf791  vmovaps [rsp+0x20], xmm11
00007d248dbcf797  vmovaps xmm10, [rsp+0x20]
00007d248dbcf79d  por xmm11, xmm10
00007d248dbcf7a2  vmovaps [rsp+0x20], xmm4
00007d248dbcf7a8  vmovaps xmm10, [rsp+0x20]
00007d248dbcf7ae  por xmm4, xmm10
00007d248dbcf7b3  vmovaps [rsp+0x20], xmm8
00007d248dbcf7b9  vmovaps xmm10, [rsp+0x20]
00007d248dbcf7bf  por xmm8, xmm10
00007d248dbcf7c4  vmovaps xmm10, [rsp+0xF0]
00007d248dbcf7cd  vmovaps [rsp+0x20], xmm1
00007d248dbcf7d3  vmovaps xmm1, [rsp+0xF0]
00007d248dbcf7dc  por xmm10, xmm1
00007d248dbcf7e1  lea rax, [r14+0xA0]
00007d248dbcf7e8  movups xmm1, [r13+rax*1]
00007d248dbcf7ee  lea rax, [r14+0xB0]
00007d248dbcf7f5  vmovaps [rsp+0x30], xmm1
00007d248dbcf7fb  movups xmm1, [r13+rax*1]
00007d248dbcf801  vmovaps [rsp+0xF0], xmm1
00007d248dbcf80a  vmovaps [rsp+0x120], xmm15
00007d248dbcf813  movaps xmm1, xmm13
00007d248dbcf817  addpd xmm1, xmm2
00007d248dbcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007d248dbcf820  ptest xmm15, xmm15
00007d248dbcf826  jnz 0x00007D248DBD11ED
00007d248dbcf82c  lea rax, [r14+0xF0]
00007d248dbcf833  movups xmm15, [r13+rax*1]
00007d248dbcf839  vmovaps xmm2, [rsp+0xC0]
00007d248dbcf842  vmovaps [rsp+0xC0], xmm1
00007d248dbcf84b  vmovaps xmm1, [rsp+0xE0]
00007d248dbcf854  vmovaps [rsp+0xE0], xmm15
00007d248dbcf85d  movaps xmm13, xmm2
00007d248dbcf861  addpd xmm13, xmm1
00007d248dbcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007d248dbcf86c  ptest xmm15, xmm15
00007d248dbcf872  jnz 0x00007D248DBD1338
00007d248dbcf878  vmovaps xmm15, [rsp+0x120]
00007d248dbcf881  vmovaps xmm2, [rsp+0xD0]
00007d248dbcf88a  vmovaps [rsp+0xD0], xmm14
00007d248dbcf893  movaps xmm1, xmm15
00007d248dbcf897  addpd xmm1, xmm2
00007d248dbcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007d248dbcf8a0  ptest xmm14, xmm14
00007d248dbcf8a6  jnz 0x00007D248DBD147A
00007d248dbcf8ac  vmovaps xmm15, [rsp+0x100]
00007d248dbcf8b5  vpermilpd xmm15, xmm15, 0x00
00007d248dbcf8bb  vmovaps xmm2, [rsp+0xF0]
00007d248dbcf8c4  vmovaps [rsp+0xF0], xmm1
00007d248dbcf8cd  movaps xmm14, xmm2
00007d248dbcf8d1  mulpd xmm14, xmm15
00007d248dbcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007d248dbcf8dc  ptest xmm1, xmm1
00007d248dbcf8e1  jnz 0x00007D248DBD15BB
00007d248dbcf8e7  vmovaps xmm1, [rsp+0xA0]
00007d248dbcf8f0  vpermilpd xmm1, xmm1, 0x00
00007d248dbcf8f6  vmovaps xmm2, [rsp+0xE0]
00007d248dbcf8ff  vmovaps [rsp+0xE0], xmm14
00007d248dbcf908  movaps xmm15, xmm2
00007d248dbcf90c  mulpd xmm15, xmm1
00007d248dbcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007d248dbcf917  ptest xmm14, xmm14
00007d248dbcf91d  jnz 0x00007D248DBD16FE
00007d248dbcf923  lea rax, [r14+0xE0]
00007d248dbcf92a  movups xmm1, [r13+rax*1]
00007d248dbcf930  vmovaps xmm14, [rsp+0x100]
00007d248dbcf939  vpermilpd xmm14, xmm14, 0x00
00007d248dbcf93f  vmovaps [rsp+0x100], xmm1
00007d248dbcf948  vmovaps xmm1, [rsp+0x30]
00007d248dbcf94e  vmovaps [rsp+0x30], xmm15
00007d248dbcf954  movaps xmm2, xmm1
00007d248dbcf957  mulpd xmm2, xmm14
00007d248dbcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007d248dbcf961  ptest xmm15, xmm15
00007d248dbcf967  jnz 0x00007D248DBD184A
00007d248dbcf96d  vmovaps [rsp+0x120], xmm10
00007d248dbcf976  vmovaps xmm1, [rsp+0x120]
00007d248dbcf97f  por xmm10, xmm1
00007d248dbcf984  movaps [r15+0x300], xmm10
00007d248dbcf98c  vmovaps [rsp+0x120], xmm8
00007d248dbcf995  vmovaps xmm1, [rsp+0x120]
00007d248dbcf99e  por xmm8, xmm1
00007d248dbcf9a3  movaps [r15+0x190], xmm8
00007d248dbcf9ab  vmovaps xmm1, [rsp+0xA0]
00007d248dbcf9b4  vpermilpd xmm1, xmm1, 0x00
00007d248dbcf9ba  vmovaps xmm14, [rsp+0x100]
00007d248dbcf9c3  vmovaps [rsp+0x100], xmm13
00007d248dbcf9cc  movaps xmm15, xmm14
00007d248dbcf9d0  mulpd xmm15, xmm1
00007d248dbcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007d248dbcf9db  ptest xmm13, xmm13
00007d248dbcf9e1  jnz 0x00007D248DBD198B
00007d248dbcf9e7  lea rax, [r14+0x90]
00007d248dbcf9ee  movups xmm1, [r13+rax*1]
00007d248dbcf9f4  vmovaps [rsp+0x120], xmm4
00007d248dbcf9fd  vmovaps xmm14, [rsp+0x120]
00007d248dbcfa06  por xmm4, xmm14
00007d248dbcfa0b  movaps [r15+0x1C0], xmm4
00007d248dbcfa13  vmovaps [rsp+0x120], xmm11
00007d248dbcfa1c  vmovaps xmm14, [rsp+0x120]
00007d248dbcfa25  por xmm11, xmm14
00007d248dbcfa2a  movaps [r15+0x200], xmm11
00007d248dbcfa32  vmovaps [rsp+0x120], xmm5
00007d248dbcfa3b  vmovaps xmm14, [rsp+0x120]
00007d248dbcfa44  por xmm5, xmm14
00007d248dbcfa49  movaps [r15+0x2D0], xmm5
00007d248dbcfa51  vmovaps [rsp+0x120], xmm12
00007d248dbcfa5a  vmovaps xmm14, [rsp+0x120]
00007d248dbcfa63  por xmm12, xmm14
00007d248dbcfa68  movaps [r15+0x2E0], xmm12
00007d248dbcfa70  vmovaps xmm13, [rsp+0x110]
00007d248dbcfa79  vmovaps [rsp+0x110], xmm1
00007d248dbcfa82  vmovaps xmm1, [rsp+0xE0]
00007d248dbcfa8b  vmovaps [rsp+0xE0], xmm15
00007d248dbcfa94  movaps xmm14, xmm13
00007d248dbcfa98  addpd xmm14, xmm1
00007d248dbcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007d248dbcfaa3  ptest xmm15, xmm15
00007d248dbcfaa9  jnz 0x00007D248DBD1AD8
00007d248dbcfaaf  vmovaps xmm1, [rsp+0xA0]
00007d248dbcfab8  vpermilpd xmm1, xmm1, 0x00
00007d248dbcfabe  vmovaps xmm13, [rsp+0x110]
00007d248dbcfac7  vmovaps [rsp+0x110], xmm14
00007d248dbcfad0  movaps xmm15, xmm13
00007d248dbcfad4  mulpd xmm15, xmm1
00007d248dbcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007d248dbcfadf  ptest xmm14, xmm14
00007d248dbcfae5  jnz 0x00007D248DBD1C1B
00007d248dbcfaeb  lea rax, [r14+0x80]
00007d248dbcfaf2  movups xmm1, [r13+rax*1]
00007d248dbcfaf8  vmovaps xmm13, [rsp+0xC0]
00007d248dbcfb01  vmovaps [rsp+0xC0], xmm1
00007d248dbcfb0a  movaps xmm14, xmm13
00007d248dbcfb0e  addpd xmm14, xmm2
00007d248dbcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007d248dbcfb19  ptest xmm1, xmm1
00007d248dbcfb1e  jnz 0x00007D248DBD1D68
00007d248dbcfb24  vmovaps xmm13, [rsp+0x100]
00007d248dbcfb2d  vmovaps xmm2, [rsp+0x30]
00007d248dbcfb33  vmovaps [rsp+0x30], xmm15
00007d248dbcfb39  movaps xmm1, xmm13
00007d248dbcfb3d  addpd xmm1, xmm2
00007d248dbcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007d248dbcfb46  ptest xmm15, xmm15
00007d248dbcfb4c  jnz 0x00007D248DBD1EAB
00007d248dbcfb52  vmovaps xmm15, [rsp+0x20]
00007d248dbcfb58  vmovaps xmm13, [rsp+0x20]
00007d248dbcfb5e  por xmm15, xmm13
00007d248dbcfb63  movaps [r15+0x2F0], xmm15
00007d248dbcfb6b  vmovaps xmm13, [rsp+0xA0]
00007d248dbcfb74  vpermilpd xmm13, xmm13, 0x00
00007d248dbcfb7a  vmovaps [rsp+0x20], xmm1
00007d248dbcfb80  vmovaps xmm1, [rsp+0xC0]
00007d248dbcfb89  vmovaps [rsp+0xA0], xmm15
00007d248dbcfb92  movaps xmm2, xmm1
00007d248dbcfb95  mulpd xmm2, xmm13
00007d248dbcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007d248dbcfb9f  ptest xmm15, xmm15
00007d248dbcfba5  jnz 0x00007D248DBD1FEC
00007d248dbcfbab  lea rax, [r14+0xD0]
00007d248dbcfbb2  movups xmm1, [r13+rax*1]
00007d248dbcfbb8  vmovaps xmm13, [rsp+0xF0]
00007d248dbcfbc1  vmovaps [rsp+0xC0], xmm1
00007d248dbcfbca  vmovaps xmm1, [rsp+0xE0]
00007d248dbcfbd3  vmovaps [rsp+0xE0], xmm14
00007d248dbcfbdc  movaps xmm15, xmm13
00007d248dbcfbe0  addpd xmm15, xmm1
00007d248dbcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007d248dbcfbeb  ptest xmm14, xmm14
00007d248dbcfbf1  jnz 0x00007D248DBD2137
00007d248dbcfbf7  vmovaps xmm1, [rsp+0xB0]
00007d248dbcfc00  vpermilpd xmm1, xmm1, 0x00
00007d248dbcfc06  movaps xmm14, xmm11
00007d248dbcfc0a  mulpd xmm14, xmm1
00007d248dbcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007d248dbcfc15  ptest xmm13, xmm13
00007d248dbcfc1b  jnz 0x00007D248DBD227A
00007d248dbcfc21  movaps [r15+0x260], xmm14
00007d248dbcfc29  vxorps xmm1, xmm1, xmm1
00007d248dbcfc2d  vpbroadcastq xmm1, xmm1
00007d248dbcfc32  movaps [r15+0x1B0], xmm1
00007d248dbcfc3a  vmovaps xmm1, [rsp+0xB0]
00007d248dbcfc43  vpermilpd xmm1, xmm1, 0x00
00007d248dbcfc49  vmovaps xmm11, [rsp+0xC0]
00007d248dbcfc52  vmovaps [rsp+0xC0], xmm15
00007d248dbcfc5b  movaps xmm13, xmm11
00007d248dbcfc5f  mulpd xmm13, xmm1
00007d248dbcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007d248dbcfc6a  ptest xmm15, xmm15
00007d248dbcfc70  jnz 0x00007D248DBD23BD
00007d248dbcfc76  lea rax, [r14+0xC0]
00007d248dbcfc7d  movups xmm1, [r13+rax*1]
00007d248dbcfc83  vmovaps xmm11, [rsp+0x110]
00007d248dbcfc8c  vmovaps [rsp+0xF0], xmm1
00007d248dbcfc95  vmovaps xmm1, [rsp+0x30]
00007d248dbcfc9b  vmovaps [rsp+0x30], xmm14
00007d248dbcfca1  movaps xmm15, xmm11
00007d248dbcfca5  addpd xmm15, xmm1
00007d248dbcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007d248dbcfcb0  ptest xmm14, xmm14
00007d248dbcfcb6  jnz 0x00007D248DBD250A
00007d248dbcfcbc  vmovaps [rsp+0x100], xmm9
00007d248dbcfcc5  vmovaps xmm1, [rsp+0x100]
00007d248dbcfcce  por xmm9, xmm1
00007d248dbcfcd3  movaps [r15+0x270], xmm9
00007d248dbcfcdb  vmovaps [rsp+0x100], xmm6
00007d248dbcfce4  vmovaps xmm1, [rsp+0x100]
00007d248dbcfced  por xmm6, xmm1
00007d248dbcfcf1  movaps [r15+0x1A0], xmm6
00007d248dbcfcf9  vmovaps xmm14, [rsp+0xB0]
00007d248dbcfd02  vpermilpd xmm14, xmm14, 0x00
00007d248dbcfd08  vmovaps xmm6, [rsp+0xF0]
00007d248dbcfd11  vmovaps [rsp+0xF0], xmm1
00007d248dbcfd1a  movaps xmm11, xmm6
00007d248dbcfd1e  mulpd xmm11, xmm14
00007d248dbcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007d248dbcfd29  ptest xmm1, xmm1
00007d248dbcfd2e  jnz 0x00007D248DBD264D
00007d248dbcfd34  lea rax, [r14+0x20]
00007d248dbcfd38  movups xmm1, [r13+rax*1]
00007d248dbcfd3e  movaps [r15+0x110], xmm1
00007d248dbcfd46  vmovaps xmm6, [rsp+0xE0]
00007d248dbcfd4f  vmovaps [rsp+0xE0], xmm1
00007d248dbcfd58  movaps xmm14, xmm6
00007d248dbcfd5c  addpd xmm14, xmm2
00007d248dbcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007d248dbcfd67  ptest xmm1, xmm1
00007d248dbcfd6c  jnz 0x00007D248DBD279A
00007d248dbcfd72  vmovaps xmm1, [rsp+0xB0]
00007d248dbcfd7b  vpermilpd xmm1, xmm1, 0x00
00007d248dbcfd81  movaps xmm6, xmm5
00007d248dbcfd84  mulpd xmm6, xmm1
00007d248dbcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007d248dbcfd8d  ptest xmm2, xmm2
00007d248dbcfd92  jnz 0x00007D248DBD28DC
00007d248dbcfd98  vmovaps xmm5, [rsp+0x20]
00007d248dbcfd9e  movaps xmm1, xmm5
00007d248dbcfda1  addpd xmm1, xmm13
00007d248dbcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007d248dbcfdab  ptest xmm2, xmm2
00007d248dbcfdb0  jnz 0x00007D248DBD2A1C
00007d248dbcfdb6  vmovaps xmm13, [rsp+0x80]
00007d248dbcfdbf  vpermilpd xmm13, xmm13, 0x00
00007d248dbcfdc5  vmovaps xmm2, [rsp+0xE0]
00007d248dbcfdce  vmovaps [rsp+0x20], xmm1
00007d248dbcfdd4  movaps xmm5, xmm2
00007d248dbcfdd7  mulpd xmm5, xmm13
00007d248dbcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007d248dbcfde1  ptest xmm1, xmm1
00007d248dbcfde6  jnz 0x00007D248DBD2B5D
00007d248dbcfdec  vmovaps xmm1, [rsp+0x80]
00007d248dbcfdf5  vpermilpd xmm1, xmm1, 0x00
00007d248dbcfdfb  movaps xmm13, xmm10
00007d248dbcfdff  mulpd xmm13, xmm1
00007d248dbcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007d248dbcfe0a  ptest xmm2, xmm2
00007d248dbcfe0f  jnz 0x00007D248DBD2C9E
00007d248dbcfe15  vmovaps xmm10, [rsp+0x30]
00007d248dbcfe1b  movaps xmm1, xmm15
00007d248dbcfe1f  addpd xmm1, xmm10
00007d248dbcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007d248dbcfe29  ptest xmm2, xmm2
00007d248dbcfe2e  jnz 0x00007D248DBD2DE1
00007d248dbcfe34  vmovaps xmm10, [rsp+0xC0]
00007d248dbcfe3d  movaps xmm15, xmm10
00007d248dbcfe41  addpd xmm15, xmm11
00007d248dbcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007d248dbcfe4c  ptest xmm2, xmm2
00007d248dbcfe51  jnz 0x00007D248DBD2F23
00007d248dbcfe57  vmovaps xmm11, [rsp+0x80]
00007d248dbcfe60  vpermilpd xmm11, xmm11, 0x00
00007d248dbcfe66  movaps xmm10, xmm12
00007d248dbcfe6a  mulpd xmm10, xmm11
00007d248dbcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007d248dbcfe75  ptest xmm2, xmm2
00007d248dbcfe7a  jnz 0x00007D248DBD3067
00007d248dbcfe80  vmovaps xmm12, [rsp+0x80]
00007d248dbcfe89  vpermilpd xmm12, xmm12, 0x00
00007d248dbcfe8f  vmovaps xmm2, [rsp+0xA0]
00007d248dbcfe98  vmovaps [rsp+0x30], xmm1
00007d248dbcfe9e  movaps xmm11, xmm2
00007d248dbcfea2  mulpd xmm11, xmm12
00007d248dbcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007d248dbcfead  ptest xmm1, xmm1
00007d248dbcfeb2  jnz 0x00007D248DBD31AB
00007d248dbcfeb8  movaps xmm1, xmm14
00007d248dbcfebc  addpd xmm1, xmm6
00007d248dbcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007d248dbcfec5  ptest xmm12, xmm12
00007d248dbcfecb  jnz 0x00007D248DBD32EE
00007d248dbcfed1  vmovaps xmm12, [rsp+0x20]
00007d248dbcfed7  movaps xmm14, xmm12
00007d248dbcfedb  addpd xmm14, xmm5
00007d248dbcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007d248dbcfee6  ptest xmm6, xmm6
00007d248dbcfeeb  jnz 0x00007D248DBD342F
00007d248dbcfef1  vmovaps xmm12, [rsp+0x90]
00007d248dbcfefa  vpermilpd xmm12, xmm12, 0x00
00007d248dbcff00  movaps xmm6, xmm9
00007d248dbcff04  mulpd xmm6, xmm12
00007d248dbcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007d248dbcff0e  ptest xmm5, xmm5
00007d248dbcff13  jnz 0x00007D248DBD3572
00007d248dbcff19  movaps xmm12, xmm15
00007d248dbcff1d  addpd xmm12, xmm13
00007d248dbcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007d248dbcff28  ptest xmm9, xmm9
00007d248dbcff2e  jnz 0x00007D248DBD36B4
00007d248dbcff34  vmovaps xmm13, [rsp+0x30]
00007d248dbcff3a  movaps xmm15, xmm13
00007d248dbcff3e  addpd xmm15, xmm10
00007d248dbcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007d248dbcff49  ptest xmm9, xmm9
00007d248dbcff4f  jnz 0x00007D248DBD37F8
00007d248dbcff55  vmovaps xmm13, [rsp+0xD0]
00007d248dbcff5e  vmovaps xmm10, [rsp+0xD0]
00007d248dbcff67  por xmm13, xmm10
00007d248dbcff6c  movaps [r15+0x250], xmm13
00007d248dbcff74  vmovaps [rsp+0x20], xmm7
00007d248dbcff7a  vmovaps xmm13, [rsp+0x20]
00007d248dbcff80  por xmm7, xmm13
00007d248dbcff85  movaps [r15+0x2A0], xmm7
00007d248dbcff8d  vmovaps [rsp+0x20], xmm3
00007d248dbcff93  vmovaps xmm13, [rsp+0x20]
00007d248dbcff99  por xmm3, xmm13
00007d248dbcff9e  movaps [r15+0x1D0], xmm3
00007d248dbcffa6  lea rax, [r14+0x40]
00007d248dbcffaa  movups xmm13, [r13+rax*1]
00007d248dbcffb0  movaps [r15+0x2C0], xmm13
00007d248dbcffb8  vmovaps xmm10, [rsp+0x90]
00007d248dbcffc1  vpermilpd xmm10, xmm10, 0x00
00007d248dbcffc7  movaps xmm9, xmm8
00007d248dbcffcb  mulpd xmm9, xmm10
00007d248dbcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007d248dbcffd6  ptest xmm5, xmm5
00007d248dbcffdb  jnz 0x00007D248DBD3946
00007d248dbcffe1  movaps xmm10, xmm1
00007d248dbcffe5  addpd xmm10, xmm11
00007d248dbcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007d248dbcfff0  ptest xmm8, xmm8
00007d248dbcfff6  jnz 0x00007D248DBD3A8A
00007d248dbcfffc  movaps xmm1, xmm14
00007d248dbd0000  addpd xmm1, xmm6
00007d248dbd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007d248dbd0009  ptest xmm11, xmm11
00007d248dbd000f  jnz 0x00007D248DBD3BCD
00007d248dbd0015  vmovaps xmm14, [rsp+0x90]
00007d248dbd001e  vpermilpd xmm14, xmm14, 0x00
00007d248dbd0024  movaps xmm11, xmm13
00007d248dbd0028  mulpd xmm11, xmm14
00007d248dbd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007d248dbd0033  ptest xmm8, xmm8
00007d248dbd0039  jnz 0x00007D248DBD3D0E
00007d248dbd003f  vmovaps xmm14, [rsp+0x90]
00007d248dbd0048  vpermilpd xmm14, xmm14, 0x00
00007d248dbd004e  vmovaps xmm8, [rsp+0x10]
00007d248dbd0054  movaps xmm13, xmm8
00007d248dbd0058  mulpd xmm13, xmm14
00007d248dbd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007d248dbd0063  ptest xmm6, xmm6
00007d248dbd0068  jnz 0x00007D248DBD3E52
00007d248dbd006e  vmovaps xmm14, [rsp+0x60]
00007d248dbd0074  vpermilpd xmm14, xmm14, 0x00
00007d248dbd007a  movaps xmm8, xmm7
00007d248dbd007e  mulpd xmm8, xmm14
00007d248dbd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007d248dbd0089  ptest xmm6, xmm6
00007d248dbd008e  jnz 0x00007D248DBD3F96
00007d248dbd0094  movaps xmm14, xmm12
00007d248dbd0098  addpd xmm14, xmm9
00007d248dbd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007d248dbd00a3  ptest xmm7, xmm7
00007d248dbd00a8  jnz 0x00007D248DBD40D9
00007d248dbd00ae  vmovaps xmm12, [rsp+0x60]
00007d248dbd00b4  vpermilpd xmm12, xmm12, 0x00
00007d248dbd00ba  vmovaps xmm7, [rsp+0xF0]
00007d248dbd00c3  movaps xmm9, xmm7
00007d248dbd00c7  mulpd xmm9, xmm12
00007d248dbd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007d248dbd00d2  ptest xmm6, xmm6
00007d248dbd00d7  jnz 0x00007D248DBD421D
00007d248dbd00dd  movaps xmm12, xmm15
00007d248dbd00e1  addpd xmm12, xmm11
00007d248dbd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007d248dbd00ec  ptest xmm7, xmm7
00007d248dbd00f1  jnz 0x00007D248DBD4360
00007d248dbd00f7  vmovaps xmm15, [rsp+0x60]
00007d248dbd00fd  vpermilpd xmm15, xmm15, 0x00
00007d248dbd0103  vmovaps xmm7, [rsp+0x40]
00007d248dbd0109  movaps xmm11, xmm7
00007d248dbd010d  mulpd xmm11, xmm15
00007d248dbd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007d248dbd0118  ptest xmm6, xmm6
00007d248dbd011d  jnz 0x00007D248DBD44A4
00007d248dbd0123  movaps xmm15, xmm10
00007d248dbd0127  addpd xmm15, xmm13
00007d248dbd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007d248dbd0132  ptest xmm7, xmm7
00007d248dbd0137  jnz 0x00007D248DBD45E7
00007d248dbd013d  vmovaps xmm13, [rsp+0x60]
00007d248dbd0143  vpermilpd xmm13, xmm13, 0x00
00007d248dbd0149  vmovaps xmm7, [rsp+0x50]
00007d248dbd014f  movaps xmm10, xmm7
00007d248dbd0153  mulpd xmm10, xmm13
00007d248dbd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007d248dbd015e  ptest xmm6, xmm6
00007d248dbd0163  jnz 0x00007D248DBD472B
00007d248dbd0169  movaps xmm13, xmm1
00007d248dbd016d  addpd xmm13, xmm8
00007d248dbd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007d248dbd0178  ptest xmm7, xmm7
00007d248dbd017d  jnz 0x00007D248DBD486E
00007d248dbd0183  lea rax, [r14+0x70]
00007d248dbd0187  movups xmm1, [r13+rax*1]
00007d248dbd018d  movaps [r15+0x240], xmm1
00007d248dbd0195  movaps xmm8, xmm14
00007d248dbd0199  addpd xmm8, xmm9
00007d248dbd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007d248dbd01a4  ptest xmm7, xmm7
00007d248dbd01a9  jnz 0x00007D248DBD49BB
00007d248dbd01af  movaps [r15+0x170], xmm8
00007d248dbd01b7  vmovaps xmm14, [rsp+0x70]
00007d248dbd01bd  vpermilpd xmm14, xmm14, 0x00
00007d248dbd01c3  movaps xmm9, xmm1
00007d248dbd01c7  mulpd xmm9, xmm14
00007d248dbd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007d248dbd01d2  ptest xmm7, xmm7
00007d248dbd01d7  jnz 0x00007D248DBD4AFF
00007d248dbd01dd  vmovaps xmm1, [rsp+0x70]
00007d248dbd01e3  vpermilpd xmm1, xmm1, 0x00
00007d248dbd01e9  movaps xmm14, xmm4
00007d248dbd01ed  mulpd xmm14, xmm1
00007d248dbd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007d248dbd01f8  ptest xmm7, xmm7
00007d248dbd01fd  jnz 0x00007D248DBD4C42
00007d248dbd0203  movaps [r15+0x180], xmm14
00007d248dbd020b  movaps xmm1, xmm12
00007d248dbd020f  addpd xmm1, xmm11
00007d248dbd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007d248dbd0219  ptest xmm7, xmm7
00007d248dbd021e  jnz 0x00007D248DBD4D84
00007d248dbd0224  movaps [r15+0x210], xmm1
00007d248dbd022c  movups xmm12, [r13+r14*1]
00007d248dbd0232  lea rax, [r14+0x10]
00007d248dbd0236  movups xmm11, [r13+rax*1]
00007d248dbd023c  movaps [r15+0x230], xmm11
00007d248dbd0244  movaps xmm7, xmm15
00007d248dbd0248  addpd xmm7, xmm10
00007d248dbd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007d248dbd0252  ptest xmm6, xmm6
00007d248dbd0257  jnz 0x00007D248DBD4EDA
00007d248dbd025d  movaps [r15+0x130], xmm7
00007d248dbd0265  vmovaps xmm15, [rsp+0x70]
00007d248dbd026b  vpermilpd xmm15, xmm15, 0x00
00007d248dbd0271  movaps xmm10, xmm11
00007d248dbd0275  mulpd xmm10, xmm15
00007d248dbd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007d248dbd0280  ptest xmm6, xmm6
00007d248dbd0285  jnz 0x00007D248DBD501C
00007d248dbd028b  movaps [r15+0x220], xmm10
00007d248dbd0293  vmovaps xmm15, [rsp+0x70]
00007d248dbd0299  vpermilpd xmm15, xmm15, 0x00
00007d248dbd029f  movaps xmm11, xmm12
00007d248dbd02a3  mulpd xmm11, xmm15
00007d248dbd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007d248dbd02ae  ptest xmm6, xmm6
00007d248dbd02b3  jnz 0x00007D248DBD5160
00007d248dbd02b9  movaps xmm15, xmm13
00007d248dbd02bd  addpd xmm15, xmm9
00007d248dbd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007d248dbd02c8  ptest xmm12, xmm12
00007d248dbd02ce  jnz 0x00007D248DBD52A4
00007d248dbd02d4  movaps [r15+0x140], xmm15
00007d248dbd02dc  movaps xmm13, xmm8
00007d248dbd02e0  addpd xmm13, xmm14
00007d248dbd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007d248dbd02eb  ptest xmm12, xmm12
00007d248dbd02f1  jnz 0x00007D248DBD53E8
00007d248dbd02f7  movaps [r15+0x150], xmm13
00007d248dbd02ff  movaps xmm14, xmm1
00007d248dbd0303  addpd xmm14, xmm10
00007d248dbd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007d248dbd030e  ptest xmm12, xmm12
00007d248dbd0314  jnz 0x00007D248DBD552C
00007d248dbd031a  movaps [r15+0x160], xmm14
00007d248dbd0322  movaps xmm1, xmm7
00007d248dbd0325  addpd xmm1, xmm11
00007d248dbd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007d248dbd032f  ptest xmm12, xmm12
00007d248dbd0335  jnz 0x00007D248DBD566F
00007d248dbd033b  movaps [r15+0x120], xmm1
00007d248dbd0343  mov eax, 0x430920
00007d248dbd0348  movups [r13+rax*1], xmm15
00007d248dbd034e  mov eax, 0x430930
00007d248dbd0353  movups [r13+rax*1], xmm13
00007d248dbd0359  mov eax, 0x430940
00007d248dbd035e  movups [r13+rax*1], xmm14
00007d248dbd0364  mov eax, 0x430950
00007d248dbd0369  movups [r13+rax*1], xmm1
00007d248dbd036f  mov eax, [r15+0x108]
00007d248dbd0376  sahf
00007d248dbd0377  jnz 0x00007D248DBD03A9
00007d248dbd0379  cmp dword ptr [r15+0x318], 0x00
00007d248dbd0381  jz 0x00007D248DBDB900
00007d248dbd0387  nop [rax+rax*1], ax
00007d248dbd0390  nop [rax+rax*1], eax
00007d248dbd0398  mov eax, 0x410444
00007d248dbd039d  mov [r15+0x100], rax
00007d248dbd03a4  jmp 0x00007D248D9FE110
00007d248dbd03a9  cmp dword ptr [r15+0x318], 0x00
00007d248dbd03b1  jz 0x00007D248DBD57E0
00007d248dbd03b7  nop [rax+rax*1], ax
00007d248dbd03c0  nop [rax+rax*1], eax
00007d248dbd03c8  mov eax, 0x410278
00007d248dbd03cd  mov [r15+0x100], rax
00007d248dbd03d4  jmp 0x00007D248D9FE110
00007d248dbd03d9  int3
00007d248dbd03da  call 0x00007D248DAB52F0
00007d248dbd03df  jmp 0x00007D248DBCF016
00007d248dbd03e4  call 0x00007D248DAC4620
00007d248dbd03e9  jmp 0x00007D248DBCF023
00007d248dbd03ee  call 0x00007D248DAC33A0
00007d248dbd03f3  jmp 0x00007D248DBCF035
00007d248dbd03f8  call 0x00007D248DAC2120
00007d248dbd03fd  jmp 0x00007D248DBCF03F
00007d248dbd0402  call 0x00007D248DAC0860
00007d248dbd0407  jmp 0x00007D248DBCF067
00007d248dbd040c  call 0x00007D248DABF5F0
00007d248dbd0411  jmp 0x00007D248DBCF073
00007d248dbd0416  call 0x00007D248DAC0860
00007d248dbd041b  jmp 0x00007D248DBCF0A5
00007d248dbd0420  call 0x00007D248DABF5F0
00007d248dbd0425  jmp 0x00007D248DBCF0B1
00007d248dbd042a  call 0x00007D248DAC4740
00007d248dbd042f  jmp 0x00007D248DBCF0BE
00007d248dbd0434  call 0x00007D248DAB5400
00007d248dbd0439  jmp 0x00007D248DBCF0CB
00007d248dbd043e  call 0x00007D248DAB52F0
00007d248dbd0443  jmp 0x00007D248DBCF0D8
00007d248dbd0448  call 0x00007D248DAC4620
00007d248dbd044d  jmp 0x00007D248DBCF0E5
00007d248dbd0452  call 0x00007D248DAC0860
00007d248dbd0457  jmp 0x00007D248DBCF10D
00007d248dbd045c  call 0x00007D248DABF5F0
00007d248dbd0461  jmp 0x00007D248DBCF119
00007d248dbd0466  call 0x00007D248DA09D70
00007d248dbd046b  jmp 0x00007D248DBCF11F
00007d248dbd0470  call 0x00007D248DABE9C0
00007d248dbd0475  jmp 0x00007D248DBCF129
00007d248dbd047a  call 0x00007D248DAC0860
00007d248dbd047f  jmp 0x00007D248DBCF151
00007d248dbd0484  call 0x00007D248DABF5F0
00007d248dbd0489  jmp 0x00007D248DBCF15D
00007d248dbd048e  call 0x00007D248DABD750
00007d248dbd0493  jmp 0x00007D248DBCF16A
00007d248dbd0498  call 0x00007D248DABC4E0
00007d248dbd049d  jmp 0x00007D248DBCF177
00007d248dbd04a2  call 0x00007D248DAC4740
00007d248dbd04a7  jmp 0x00007D248DBCF184
00007d248dbd04ac  call 0x00007D248DAB5400
00007d248dbd04b1  jmp 0x00007D248DBCF191
00007d248dbd04b6  call 0x00007D248DAB52F0
00007d248dbd04bb  jmp 0x00007D248DBCF19E
00007d248dbd04c0  call 0x00007D248DAC4620
00007d248dbd04c5  jmp 0x00007D248DBCF1AB
00007d248dbd04ca  call 0x00007D248DAC0860
00007d248dbd04cf  jmp 0x00007D248DBCF1BE
00007d248dbd04d4  call 0x00007D248DABB270
00007d248dbd04d9  jmp 0x00007D248DBCF1CB
00007d248dbd04de  call 0x00007D248DABA000
00007d248dbd04e3  jmp 0x00007D248DBCF1D8
00007d248dbd04e8  call 0x00007D248DAB8D90
00007d248dbd04ed  jmp 0x00007D248DBCF1E5
00007d248dbd04f2  call 0x00007D248DAB8A20
00007d248dbd04f7  jmp 0x00007D248DBCF1F2
00007d248dbd04fc  call 0x00007D248DAB5400
00007d248dbd0501  jmp 0x00007D248DBCF1FC
00007d248dbd0506  call 0x00007D248DAC2240
00007d248dbd050b  jmp 0x00007D248DBCF206
00007d248dbd0510  call 0x00007D248DAB52F0
00007d248dbd0515  jmp 0x00007D248DBCF210
00007d248dbd051a  call 0x00007D248DAC2120
00007d248dbd051f  jmp 0x00007D248DBCF21A
00007d248dbd0524  call 0x00007D248DAB77B0
00007d248dbd0529  jmp 0x00007D248DBCF224
00007d248dbd052e  call 0x00007D248DAB6550
00007d248dbd0533  jmp 0x00007D248DBCF22E
00007d248dbd0538  call 0x00007D248DABFD50
00007d248dbd053d  jmp 0x00007D248DBCF240
00007d248dbd0542  call 0x00007D248DAB8EA0
00007d248dbd0547  jmp 0x00007D248DBCF24A
00007d248dbd054c  call 0x00007D248DABFC30
00007d248dbd0551  jmp 0x00007D248DBCF257
00007d248dbd0556  call 0x00007D248DAB8D90
00007d248dbd055b  jmp 0x00007D248DBCF264
00007d248dbd0560  call 0x00007D248DAC2240
00007d248dbd0565  jmp 0x00007D248DBCF271
00007d248dbd056a  call 0x00007D248DAB5400
00007d248dbd056f  jmp 0x00007D248DBCF27E
00007d248dbd0574  call 0x00007D248DAB52F0
00007d248dbd0579  jmp 0x00007D248DBCF28B
00007d248dbd057e  call 0x00007D248DAC2120
00007d248dbd0583  jmp 0x00007D248DBCF298
00007d248dbd0588  call 0x00007D248DAB52F0
00007d248dbd058d  jmp 0x00007D248DBCF2AB
00007d248dbd0592  call 0x00007D248DAB52F0
00007d248dbd0597  jmp 0x00007D248DBCF2BE
00007d248dbd059c  call 0x00007D248DAB52F0
00007d248dbd05a1  jmp 0x00007D248DBCF2D1
00007d248dbd05a6  call 0x00007D248DAB52F0
00007d248dbd05ab  jmp 0x00007D248DBCF2E4
00007d248dbd05b0  call 0x00007D248DAC2240
00007d248dbd05b5  jmp 0x00007D248DBCF2F9
00007d248dbd05ba  call 0x00007D248DAC2240
00007d248dbd05bf  jmp 0x00007D248DBCF30C
00007d248dbd05c4  call 0x00007D248DAC2120
00007d248dbd05c9  jmp 0x00007D248DBCF319
00007d248dbd05ce  call 0x00007D248DAB52F0
00007d248dbd05d3  jmp 0x00007D248DBCF32C
00007d248dbd05d8  call 0x00007D248DAB52F0
00007d248dbd05dd  jmp 0x00007D248DBCF34F
00007d248dbd05e2  call 0x00007D248DAB52F0
00007d248dbd05e7  jmp 0x00007D248DBCF362
00007d248dbd05ec  call 0x00007D248D9FF540
00007d248dbd05f1  jmp 0x00007D248DBCF380
00007d248dbd05f6  call 0x00007D248DA08C20
00007d248dbd05fb  jmp 0x00007D248DBCF38A
00007d248dbd0600  call 0x00007D248DAD6600
00007d248dbd0605  jmp 0x00007D248DBCF396
00007d248dbd060a  call 0x00007D248D9FF540
00007d248dbd060f  jmp 0x00007D248DBCF3A6
00007d248dbd0614  call 0x00007D248DAC0370
00007d248dbd0619  jmp 0x00007D248DBCF3D4
00007d248dbd061e  call 0x00007D248DABF100
00007d248dbd0623  jmp 0x00007D248DBCF3DD
00007d248dbd0628  call 0x00007D248DAC0370
00007d248dbd062d  jmp 0x00007D248DBCF43B
00007d248dbd0632  call 0x00007D248DABF100
00007d248dbd0637  jmp 0x00007D248DBCF444
00007d248dbd063c  call 0x00007D248DAC0370
00007d248dbd0641  jmp 0x00007D248DBCF48B
00007d248dbd0646  call 0x00007D248DABF100
00007d248dbd064b  jmp 0x00007D248DBCF494
00007d248dbd0650  call 0x00007D248DA0B720
00007d248dbd0655  jmp 0x00007D248DBCF4D7
00007d248dbd065a  call 0x00007D248DAB47C0
00007d248dbd065f  jmp 0x00007D248DBCF4EA
00007d248dbd0664  call 0x00007D248DA08B00
00007d248dbd0669  jmp 0x00007D248DBCF501
00007d248dbd066e  call 0x00007D248D9FF430
00007d248dbd0673  jmp 0x00007D248DBCF514
00007d248dbd0678  call 0x00007D248D9FF430
00007d248dbd067d  jmp 0x00007D248DBCF527
00007d248dbd0682  sub rsp, 0x08
00007d248dbd0686  push rax
00007d248dbd0687  push rcx
00007d248dbd0688  push rdx
00007d248dbd0689  push rdi
00007d248dbd068a  push rsi
00007d248dbd068b  push r8
00007d248dbd068d  push r9
00007d248dbd068f  push r10
00007d248dbd0691  push r11
00007d248dbd0693  sub rsp, 0xF0
00007d248dbd069a  vmovaps [rsp], xmm0
00007d248dbd069f  vmovaps [rsp+0x10], xmm2
00007d248dbd06a5  vmovaps [rsp+0x20], xmm3
00007d248dbd06ab  vmovaps [rsp+0x30], xmm4
00007d248dbd06b1  vmovaps [rsp+0x40], xmm5
00007d248dbd06b7  vmovaps [rsp+0x50], xmm6
00007d248dbd06bd  vmovaps [rsp+0x60], xmm7
00007d248dbd06c3  vmovaps [rsp+0x70], xmm8
00007d248dbd06c9  vmovaps [rsp+0x80], xmm9
00007d248dbd06d2  vmovaps [rsp+0x90], xmm10
00007d248dbd06db  vmovaps [rsp+0xA0], xmm11
00007d248dbd06e4  vmovaps [rsp+0xB0], xmm12
00007d248dbd06ed  vmovaps [rsp+0xC0], xmm13
00007d248dbd06f6  vmovaps [rsp+0xD0], xmm14
00007d248dbd06ff  vmovaps [rsp+0xE0], xmm15
00007d248dbd0708  sub rsp, 0x30
00007d248dbd070c  movaps [rsp], xmm1
00007d248dbd0710  movaps [rsp+0x10], xmm15
00007d248dbd0716  movaps [rsp+0x20], xmm14
00007d248dbd071c  lea rdi, [rsp]
00007d248dbd0720  mov esi, 0x00
00007d248dbd0725  mov rax, 0x5BCEEF236530
00007d248dbd072f  call rax
00007d248dbd0731  movaps xmm1, [rsp]
00007d248dbd0735  add rsp, 0x30
00007d248dbd0739  vmovaps xmm0, [rsp]
00007d248dbd073e  vmovaps xmm2, [rsp+0x10]
00007d248dbd0744  vmovaps xmm3, [rsp+0x20]
00007d248dbd074a  vmovaps xmm4, [rsp+0x30]
00007d248dbd0750  vmovaps xmm5, [rsp+0x40]
00007d248dbd0756  vmovaps xmm6, [rsp+0x50]
00007d248dbd075c  vmovaps xmm7, [rsp+0x60]
00007d248dbd0762  vmovaps xmm8, [rsp+0x70]
00007d248dbd0768  vmovaps xmm9, [rsp+0x80]
00007d248dbd0771  vmovaps xmm10, [rsp+0x90]
00007d248dbd077a  vmovaps xmm11, [rsp+0xA0]
00007d248dbd0783  vmovaps xmm12, [rsp+0xB0]
00007d248dbd078c  vmovaps xmm13, [rsp+0xC0]
00007d248dbd0795  vmovaps xmm14, [rsp+0xD0]
00007d248dbd079e  vmovaps xmm15, [rsp+0xE0]
00007d248dbd07a7  add rsp, 0xF0
00007d248dbd07ae  pop r11
00007d248dbd07b0  pop r10
00007d248dbd07b2  pop r9
00007d248dbd07b4  pop r8
00007d248dbd07b6  pop rsi
00007d248dbd07b7  pop rdi
00007d248dbd07b8  pop rdx
00007d248dbd07b9  pop rcx
00007d248dbd07ba  pop rax
00007d248dbd07bb  add rsp, 0x08
00007d248dbd07bf  jmp 0x00007D248DBCF581
00007d248dbd07c4  sub rsp, 0x08
00007d248dbd07c8  push rax
00007d248dbd07c9  push rcx
00007d248dbd07ca  push rdx
00007d248dbd07cb  push rdi
00007d248dbd07cc  push rsi
00007d248dbd07cd  push r8
00007d248dbd07cf  push r9
00007d248dbd07d1  push r10
00007d248dbd07d3  push r11
00007d248dbd07d5  sub rsp, 0xF0
00007d248dbd07dc  vmovaps [rsp], xmm0
00007d248dbd07e1  vmovaps [rsp+0x10], xmm1
00007d248dbd07e7  vmovaps [rsp+0x20], xmm2
00007d248dbd07ed  vmovaps [rsp+0x30], xmm3
00007d248dbd07f3  vmovaps [rsp+0x40], xmm4
00007d248dbd07f9  vmovaps [rsp+0x50], xmm5
00007d248dbd07ff  vmovaps [rsp+0x60], xmm6
00007d248dbd0805  vmovaps [rsp+0x70], xmm7
00007d248dbd080b  vmovaps [rsp+0x80], xmm8
00007d248dbd0814  vmovaps [rsp+0x90], xmm9
00007d248dbd081d  vmovaps [rsp+0xA0], xmm10
00007d248dbd0826  vmovaps [rsp+0xB0], xmm11
00007d248dbd082f  vmovaps [rsp+0xC0], xmm12
00007d248dbd0838  vmovaps [rsp+0xD0], xmm14
00007d248dbd0841  vmovaps [rsp+0xE0], xmm15
00007d248dbd084a  sub rsp, 0x30
00007d248dbd084e  movaps [rsp], xmm13
00007d248dbd0853  movaps [rsp+0x10], xmm1
00007d248dbd0858  movaps [rsp+0x20], xmm14
00007d248dbd085e  lea rdi, [rsp]
00007d248dbd0862  mov esi, 0x00
00007d248dbd0867  mov rax, 0x5BCEEF236530
00007d248dbd0871  call rax
00007d248dbd0873  movaps xmm13, [rsp]
00007d248dbd0878  add rsp, 0x30
00007d248dbd087c  vmovaps xmm0, [rsp]
00007d248dbd0881  vmovaps xmm1, [rsp+0x10]
00007d248dbd0887  vmovaps xmm2, [rsp+0x20]
00007d248dbd088d  vmovaps xmm3, [rsp+0x30]
00007d248dbd0893  vmovaps xmm4, [rsp+0x40]
00007d248dbd0899  vmovaps xmm5, [rsp+0x50]
00007d248dbd089f  vmovaps xmm6, [rsp+0x60]
00007d248dbd08a5  vmovaps xmm7, [rsp+0x70]
00007d248dbd08ab  vmovaps xmm8, [rsp+0x80]
00007d248dbd08b4  vmovaps xmm9, [rsp+0x90]
00007d248dbd08bd  vmovaps xmm10, [rsp+0xA0]
00007d248dbd08c6  vmovaps xmm11, [rsp+0xB0]
00007d248dbd08cf  vmovaps xmm12, [rsp+0xC0]
00007d248dbd08d8  vmovaps xmm14, [rsp+0xD0]
00007d248dbd08e1  vmovaps xmm15, [rsp+0xE0]
00007d248dbd08ea  add rsp, 0xF0
00007d248dbd08f1  pop r11
00007d248dbd08f3  pop r10
00007d248dbd08f5  pop r9
00007d248dbd08f7  pop r8
00007d248dbd08f9  pop rsi
00007d248dbd08fa  pop rdi
00007d248dbd08fb  pop rdx
00007d248dbd08fc  pop rcx
00007d248dbd08fd  pop rax
00007d248dbd08fe  add rsp, 0x08
00007d248dbd0902  jmp 0x00007D248DBCF5CF
00007d248dbd0907  sub rsp, 0x08
00007d248dbd090b  push rax
00007d248dbd090c  push rcx
00007d248dbd090d  push rdx
00007d248dbd090e  push rdi
00007d248dbd090f  push rsi
00007d248dbd0910  push r8
00007d248dbd0912  push r9
00007d248dbd0914  push r10
00007d248dbd0916  push r11
00007d248dbd0918  sub rsp, 0xF0
00007d248dbd091f  vmovaps [rsp], xmm0
00007d248dbd0924  vmovaps [rsp+0x10], xmm1
00007d248dbd092a  vmovaps [rsp+0x20], xmm2
00007d248dbd0930  vmovaps [rsp+0x30], xmm3
00007d248dbd0936  vmovaps [rsp+0x40], xmm4
00007d248dbd093c  vmovaps [rsp+0x50], xmm5
00007d248dbd0942  vmovaps [rsp+0x60], xmm6
00007d248dbd0948  vmovaps [rsp+0x70], xmm7
00007d248dbd094e  vmovaps [rsp+0x80], xmm8
00007d248dbd0957  vmovaps [rsp+0x90], xmm9
00007d248dbd0960  vmovaps [rsp+0xA0], xmm10
00007d248dbd0969  vmovaps [rsp+0xB0], xmm11
00007d248dbd0972  vmovaps [rsp+0xC0], xmm12
00007d248dbd097b  vmovaps [rsp+0xD0], xmm13
00007d248dbd0984  vmovaps [rsp+0xE0], xmm14
00007d248dbd098d  sub rsp, 0x30
00007d248dbd0991  movaps [rsp], xmm15
00007d248dbd0996  movaps [rsp+0x10], xmm14
00007d248dbd099c  movaps [rsp+0x20], xmm1
00007d248dbd09a1  lea rdi, [rsp]
00007d248dbd09a5  mov esi, 0x00
00007d248dbd09aa  mov rax, 0x5BCEEF236530
00007d248dbd09b4  call rax
00007d248dbd09b6  movaps xmm15, [rsp]
00007d248dbd09bb  add rsp, 0x30
00007d248dbd09bf  vmovaps xmm0, [rsp]
00007d248dbd09c4  vmovaps xmm1, [rsp+0x10]
00007d248dbd09ca  vmovaps xmm2, [rsp+0x20]
00007d248dbd09d0  vmovaps xmm3, [rsp+0x30]
00007d248dbd09d6  vmovaps xmm4, [rsp+0x40]
00007d248dbd09dc  vmovaps xmm5, [rsp+0x50]
00007d248dbd09e2  vmovaps xmm6, [rsp+0x60]
00007d248dbd09e8  vmovaps xmm7, [rsp+0x70]
00007d248dbd09ee  vmovaps xmm8, [rsp+0x80]
00007d248dbd09f7  vmovaps xmm9, [rsp+0x90]
00007d248dbd0a00  vmovaps xmm10, [rsp+0xA0]
00007d248dbd0a09  vmovaps xmm11, [rsp+0xB0]
00007d248dbd0a12  vmovaps xmm12, [rsp+0xC0]
00007d248dbd0a1b  vmovaps xmm13, [rsp+0xD0]
00007d248dbd0a24  vmovaps xmm14, [rsp+0xE0]
00007d248dbd0a2d  add rsp, 0xF0
00007d248dbd0a34  pop r11
00007d248dbd0a36  pop r10
00007d248dbd0a38  pop r9
00007d248dbd0a3a  pop r8
00007d248dbd0a3c  pop rsi
00007d248dbd0a3d  pop rdi
00007d248dbd0a3e  pop rdx
00007d248dbd0a3f  pop rcx
00007d248dbd0a40  pop rax
00007d248dbd0a41  add rsp, 0x08
00007d248dbd0a45  jmp 0x00007D248DBCF617
00007d248dbd0a4a  sub rsp, 0x08
00007d248dbd0a4e  push rax
00007d248dbd0a4f  push rcx
00007d248dbd0a50  push rdx
00007d248dbd0a51  push rdi
00007d248dbd0a52  push rsi
00007d248dbd0a53  push r8
00007d248dbd0a55  push r9
00007d248dbd0a57  push r10
00007d248dbd0a59  push r11
00007d248dbd0a5b  sub rsp, 0xF0
00007d248dbd0a62  vmovaps [rsp], xmm0
00007d248dbd0a67  vmovaps [rsp+0x10], xmm2
00007d248dbd0a6d  vmovaps [rsp+0x20], xmm3
00007d248dbd0a73  vmovaps [rsp+0x30], xmm4
00007d248dbd0a79  vmovaps [rsp+0x40], xmm5
00007d248dbd0a7f  vmovaps [rsp+0x50], xmm6
00007d248dbd0a85  vmovaps [rsp+0x60], xmm7
00007d248dbd0a8b  vmovaps [rsp+0x70], xmm8
00007d248dbd0a91  vmovaps [rsp+0x80], xmm9
00007d248dbd0a9a  vmovaps [rsp+0x90], xmm10
00007d248dbd0aa3  vmovaps [rsp+0xA0], xmm11
00007d248dbd0aac  vmovaps [rsp+0xB0], xmm12
00007d248dbd0ab5  vmovaps [rsp+0xC0], xmm13
00007d248dbd0abe  vmovaps [rsp+0xD0], xmm14
00007d248dbd0ac7  vmovaps [rsp+0xE0], xmm15
00007d248dbd0ad0  sub rsp, 0x30
00007d248dbd0ad4  movaps [rsp], xmm1
00007d248dbd0ad8  movaps [rsp+0x10], xmm14
00007d248dbd0ade  movaps [rsp+0x20], xmm10
00007d248dbd0ae4  lea rdi, [rsp]
00007d248dbd0ae8  mov esi, 0x00
00007d248dbd0aed  mov rax, 0x5BCEEF236530
00007d248dbd0af7  call rax
00007d248dbd0af9  movaps xmm1, [rsp]
00007d248dbd0afd  add rsp, 0x30
00007d248dbd0b01  vmovaps xmm0, [rsp]
00007d248dbd0b06  vmovaps xmm2, [rsp+0x10]
00007d248dbd0b0c  vmovaps xmm3, [rsp+0x20]
00007d248dbd0b12  vmovaps xmm4, [rsp+0x30]
00007d248dbd0b18  vmovaps xmm5, [rsp+0x40]
00007d248dbd0b1e  vmovaps xmm6, [rsp+0x50]
00007d248dbd0b24  vmovaps xmm7, [rsp+0x60]
00007d248dbd0b2a  vmovaps xmm8, [rsp+0x70]
00007d248dbd0b30  vmovaps xmm9, [rsp+0x80]
00007d248dbd0b39  vmovaps xmm10, [rsp+0x90]
00007d248dbd0b42  vmovaps xmm11, [rsp+0xA0]
00007d248dbd0b4b  vmovaps xmm12, [rsp+0xB0]
00007d248dbd0b54  vmovaps xmm13, [rsp+0xC0]
00007d248dbd0b5d  vmovaps xmm14, [rsp+0xD0]
00007d248dbd0b66  vmovaps xmm15, [rsp+0xE0]
00007d248dbd0b6f  add rsp, 0xF0
00007d248dbd0b76  pop r11
00007d248dbd0b78  pop r10
00007d248dbd0b7a  pop r9
00007d248dbd0b7c  pop r8
00007d248dbd0b7e  pop rsi
00007d248dbd0b7f  pop rdi
00007d248dbd0b80  pop rdx
00007d248dbd0b81  pop rcx
00007d248dbd0b82  pop rax
00007d248dbd0b83  add rsp, 0x08
00007d248dbd0b87  jmp 0x00007D248DBCF631
00007d248dbd0b8c  sub rsp, 0x08
00007d248dbd0b90  push rax
00007d248dbd0b91  push rcx
00007d248dbd0b92  push rdx
00007d248dbd0b93  push rdi
00007d248dbd0b94  push rsi
00007d248dbd0b95  push r8
00007d248dbd0b97  push r9
00007d248dbd0b99  push r10
00007d248dbd0b9b  push r11
00007d248dbd0b9d  sub rsp, 0xF0
00007d248dbd0ba4  vmovaps [rsp], xmm0
00007d248dbd0ba9  vmovaps [rsp+0x10], xmm1
00007d248dbd0baf  vmovaps [rsp+0x20], xmm2
00007d248dbd0bb5  vmovaps [rsp+0x30], xmm3
00007d248dbd0bbb  vmovaps [rsp+0x40], xmm4
00007d248dbd0bc1  vmovaps [rsp+0x50], xmm5
00007d248dbd0bc7  vmovaps [rsp+0x60], xmm6
00007d248dbd0bcd  vmovaps [rsp+0x70], xmm7
00007d248dbd0bd3  vmovaps [rsp+0x80], xmm8
00007d248dbd0bdc  vmovaps [rsp+0x90], xmm9
00007d248dbd0be5  vmovaps [rsp+0xA0], xmm10
00007d248dbd0bee  vmovaps [rsp+0xB0], xmm11
00007d248dbd0bf7  vmovaps [rsp+0xC0], xmm12
00007d248dbd0c00  vmovaps [rsp+0xD0], xmm14
00007d248dbd0c09  vmovaps [rsp+0xE0], xmm15
00007d248dbd0c12  sub rsp, 0x30
00007d248dbd0c16  movaps [rsp], xmm13
00007d248dbd0c1b  movaps [rsp+0x10], xmm14
00007d248dbd0c21  movaps [rsp+0x20], xmm2
00007d248dbd0c26  lea rdi, [rsp]
00007d248dbd0c2a  mov esi, 0x00
00007d248dbd0c2f  mov rax, 0x5BCEEF236530
00007d248dbd0c39  call rax
00007d248dbd0c3b  movaps xmm13, [rsp]
00007d248dbd0c40  add rsp, 0x30
00007d248dbd0c44  vmovaps xmm0, [rsp]
00007d248dbd0c49  vmovaps xmm1, [rsp+0x10]
00007d248dbd0c4f  vmovaps xmm2, [rsp+0x20]
00007d248dbd0c55  vmovaps xmm3, [rsp+0x30]
00007d248dbd0c5b  vmovaps xmm4, [rsp+0x40]
00007d248dbd0c61  vmovaps xmm5, [rsp+0x50]
00007d248dbd0c67  vmovaps xmm6, [rsp+0x60]
00007d248dbd0c6d  vmovaps xmm7, [rsp+0x70]
00007d248dbd0c73  vmovaps xmm8, [rsp+0x80]
00007d248dbd0c7c  vmovaps xmm9, [rsp+0x90]
00007d248dbd0c85  vmovaps xmm10, [rsp+0xA0]
00007d248dbd0c8e  vmovaps xmm11, [rsp+0xB0]
00007d248dbd0c97  vmovaps xmm12, [rsp+0xC0]
00007d248dbd0ca0  vmovaps xmm14, [rsp+0xD0]
00007d248dbd0ca9  vmovaps xmm15, [rsp+0xE0]
00007d248dbd0cb2  add rsp, 0xF0
00007d248dbd0cb9  pop r11
00007d248dbd0cbb  pop r10
00007d248dbd0cbd  pop r9
00007d248dbd0cbf  pop r8
00007d248dbd0cc1  pop rsi
00007d248dbd0cc2  pop rdi
00007d248dbd0cc3  pop rdx
00007d248dbd0cc4  pop rcx
00007d248dbd0cc5  pop rax
00007d248dbd0cc6  add rsp, 0x08
00007d248dbd0cca  jmp 0x00007D248DBCF64C
00007d248dbd0ccf  sub rsp, 0x08
00007d248dbd0cd3  push rax
00007d248dbd0cd4  push rcx
00007d248dbd0cd5  push rdx
00007d248dbd0cd6  push rdi
00007d248dbd0cd7  push rsi
00007d248dbd0cd8  push r8
00007d248dbd0cda  push r9
00007d248dbd0cdc  push r10
00007d248dbd0cde  push r11
00007d248dbd0ce0  sub rsp, 0xF0
00007d248dbd0ce7  vmovaps [rsp], xmm0
00007d248dbd0cec  vmovaps [rsp+0x10], xmm2
00007d248dbd0cf2  vmovaps [rsp+0x20], xmm3
00007d248dbd0cf8  vmovaps [rsp+0x30], xmm4
00007d248dbd0cfe  vmovaps [rsp+0x40], xmm5
00007d248dbd0d04  vmovaps [rsp+0x50], xmm6
00007d248dbd0d0a  vmovaps [rsp+0x60], xmm7
00007d248dbd0d10  vmovaps [rsp+0x70], xmm8
00007d248dbd0d16  vmovaps [rsp+0x80], xmm9
00007d248dbd0d1f  vmovaps [rsp+0x90], xmm10
00007d248dbd0d28  vmovaps [rsp+0xA0], xmm11
00007d248dbd0d31  vmovaps [rsp+0xB0], xmm12
00007d248dbd0d3a  vmovaps [rsp+0xC0], xmm13
00007d248dbd0d43  vmovaps [rsp+0xD0], xmm14
00007d248dbd0d4c  vmovaps [rsp+0xE0], xmm15
00007d248dbd0d55  sub rsp, 0x30
00007d248dbd0d59  movaps [rsp], xmm1
00007d248dbd0d5d  movaps [rsp+0x10], xmm10
00007d248dbd0d63  movaps [rsp+0x20], xmm2
00007d248dbd0d68  lea rdi, [rsp]
00007d248dbd0d6c  mov esi, 0x00
00007d248dbd0d71  mov rax, 0x5BCEEF236530
00007d248dbd0d7b  call rax
00007d248dbd0d7d  movaps xmm1, [rsp]
00007d248dbd0d81  add rsp, 0x30
00007d248dbd0d85  vmovaps xmm0, [rsp]
00007d248dbd0d8a  vmovaps xmm2, [rsp+0x10]
00007d248dbd0d90  vmovaps xmm3, [rsp+0x20]
00007d248dbd0d96  vmovaps xmm4, [rsp+0x30]
00007d248dbd0d9c  vmovaps xmm5, [rsp+0x40]
00007d248dbd0da2  vmovaps xmm6, [rsp+0x50]
00007d248dbd0da8  vmovaps xmm7, [rsp+0x60]
00007d248dbd0dae  vmovaps xmm8, [rsp+0x70]
00007d248dbd0db4  vmovaps xmm9, [rsp+0x80]
00007d248dbd0dbd  vmovaps xmm10, [rsp+0x90]
00007d248dbd0dc6  vmovaps xmm11, [rsp+0xA0]
00007d248dbd0dcf  vmovaps xmm12, [rsp+0xB0]
00007d248dbd0dd8  vmovaps xmm13, [rsp+0xC0]
00007d248dbd0de1  vmovaps xmm14, [rsp+0xD0]
00007d248dbd0dea  vmovaps xmm15, [rsp+0xE0]
00007d248dbd0df3  add rsp, 0xF0
00007d248dbd0dfa  pop r11
00007d248dbd0dfc  pop r10
00007d248dbd0dfe  pop r9
00007d248dbd0e00  pop r8
00007d248dbd0e02  pop rsi
00007d248dbd0e03  pop rdi
00007d248dbd0e04  pop rdx
00007d248dbd0e05  pop rcx
00007d248dbd0e06  pop rax
00007d248dbd0e07  add rsp, 0x08
00007d248dbd0e0b  jmp 0x00007D248DBCF6B4
00007d248dbd0e10  sub rsp, 0x08
00007d248dbd0e14  push rax
00007d248dbd0e15  push rcx
00007d248dbd0e16  push rdx
00007d248dbd0e17  push rdi
00007d248dbd0e18  push rsi
00007d248dbd0e19  push r8
00007d248dbd0e1b  push r9
00007d248dbd0e1d  push r10
00007d248dbd0e1f  push r11
00007d248dbd0e21  sub rsp, 0xF0
00007d248dbd0e28  vmovaps [rsp], xmm0
00007d248dbd0e2d  vmovaps [rsp+0x10], xmm1
00007d248dbd0e33  vmovaps [rsp+0x20], xmm2
00007d248dbd0e39  vmovaps [rsp+0x30], xmm3
00007d248dbd0e3f  vmovaps [rsp+0x40], xmm4
00007d248dbd0e45  vmovaps [rsp+0x50], xmm5
00007d248dbd0e4b  vmovaps [rsp+0x60], xmm6
00007d248dbd0e51  vmovaps [rsp+0x70], xmm7
00007d248dbd0e57  vmovaps [rsp+0x80], xmm8
00007d248dbd0e60  vmovaps [rsp+0x90], xmm9
00007d248dbd0e69  vmovaps [rsp+0xA0], xmm10
00007d248dbd0e72  vmovaps [rsp+0xB0], xmm11
00007d248dbd0e7b  vmovaps [rsp+0xC0], xmm12
00007d248dbd0e84  vmovaps [rsp+0xD0], xmm13
00007d248dbd0e8d  vmovaps [rsp+0xE0], xmm14
00007d248dbd0e96  sub rsp, 0x30
00007d248dbd0e9a  movaps [rsp], xmm15
00007d248dbd0e9f  movaps [rsp+0x10], xmm10
00007d248dbd0ea5  movaps [rsp+0x20], xmm2
00007d248dbd0eaa  lea rdi, [rsp]
00007d248dbd0eae  mov esi, 0x00
00007d248dbd0eb3  mov rax, 0x5BCEEF236530
00007d248dbd0ebd  call rax
00007d248dbd0ebf  movaps xmm15, [rsp]
00007d248dbd0ec4  add rsp, 0x30
00007d248dbd0ec8  vmovaps xmm0, [rsp]
00007d248dbd0ecd  vmovaps xmm1, [rsp+0x10]
00007d248dbd0ed3  vmovaps xmm2, [rsp+0x20]
00007d248dbd0ed9  vmovaps xmm3, [rsp+0x30]
00007d248dbd0edf  vmovaps xmm4, [rsp+0x40]
00007d248dbd0ee5  vmovaps xmm5, [rsp+0x50]
00007d248dbd0eeb  vmovaps xmm6, [rsp+0x60]
00007d248dbd0ef1  vmovaps xmm7, [rsp+0x70]
00007d248dbd0ef7  vmovaps xmm8, [rsp+0x80]
00007d248dbd0f00  vmovaps xmm9, [rsp+0x90]
00007d248dbd0f09  vmovaps xmm10, [rsp+0xA0]
00007d248dbd0f12  vmovaps xmm11, [rsp+0xB0]
00007d248dbd0f1b  vmovaps xmm12, [rsp+0xC0]
00007d248dbd0f24  vmovaps xmm13, [rsp+0xD0]
00007d248dbd0f2d  vmovaps xmm14, [rsp+0xE0]
00007d248dbd0f36  add rsp, 0xF0
00007d248dbd0f3d  pop r11
00007d248dbd0f3f  pop r10
00007d248dbd0f41  pop r9
00007d248dbd0f43  pop r8
00007d248dbd0f45  pop rsi
00007d248dbd0f46  pop rdi
00007d248dbd0f47  pop rdx
00007d248dbd0f48  pop rcx
00007d248dbd0f49  pop rax
00007d248dbd0f4a  add rsp, 0x08
00007d248dbd0f4e  jmp 0x00007D248DBCF706
00007d248dbd0f53  sub rsp, 0x08
00007d248dbd0f57  push rax
00007d248dbd0f58  push rcx
00007d248dbd0f59  push rdx
00007d248dbd0f5a  push rdi
00007d248dbd0f5b  push rsi
00007d248dbd0f5c  push r8
00007d248dbd0f5e  push r9
00007d248dbd0f60  push r10
00007d248dbd0f62  push r11
00007d248dbd0f64  sub rsp, 0xF0
00007d248dbd0f6b  vmovaps [rsp], xmm0
00007d248dbd0f70  vmovaps [rsp+0x10], xmm2
00007d248dbd0f76  vmovaps [rsp+0x20], xmm3
00007d248dbd0f7c  vmovaps [rsp+0x30], xmm4
00007d248dbd0f82  vmovaps [rsp+0x40], xmm5
00007d248dbd0f88  vmovaps [rsp+0x50], xmm6
00007d248dbd0f8e  vmovaps [rsp+0x60], xmm7
00007d248dbd0f94  vmovaps [rsp+0x70], xmm8
00007d248dbd0f9a  vmovaps [rsp+0x80], xmm9
00007d248dbd0fa3  vmovaps [rsp+0x90], xmm10
00007d248dbd0fac  vmovaps [rsp+0xA0], xmm11
00007d248dbd0fb5  vmovaps [rsp+0xB0], xmm12
00007d248dbd0fbe  vmovaps [rsp+0xC0], xmm13
00007d248dbd0fc7  vmovaps [rsp+0xD0], xmm14
00007d248dbd0fd0  vmovaps [rsp+0xE0], xmm15
00007d248dbd0fd9  sub rsp, 0x30
00007d248dbd0fdd  movaps [rsp], xmm1
00007d248dbd0fe1  movaps [rsp+0x10], xmm10
00007d248dbd0fe7  movaps [rsp+0x20], xmm12
00007d248dbd0fed  lea rdi, [rsp]
00007d248dbd0ff1  mov esi, 0x00
00007d248dbd0ff6  mov rax, 0x5BCEEF236530
00007d248dbd1000  call rax
00007d248dbd1002  movaps xmm1, [rsp]
00007d248dbd1006  add rsp, 0x30
00007d248dbd100a  vmovaps xmm0, [rsp]
00007d248dbd100f  vmovaps xmm2, [rsp+0x10]
00007d248dbd1015  vmovaps xmm3, [rsp+0x20]
00007d248dbd101b  vmovaps xmm4, [rsp+0x30]
00007d248dbd1021  vmovaps xmm5, [rsp+0x40]
00007d248dbd1027  vmovaps xmm6, [rsp+0x50]
00007d248dbd102d  vmovaps xmm7, [rsp+0x60]
00007d248dbd1033  vmovaps xmm8, [rsp+0x70]
00007d248dbd1039  vmovaps xmm9, [rsp+0x80]
00007d248dbd1042  vmovaps xmm10, [rsp+0x90]
00007d248dbd104b  vmovaps xmm11, [rsp+0xA0]
00007d248dbd1054  vmovaps xmm12, [rsp+0xB0]
00007d248dbd105d  vmovaps xmm13, [rsp+0xC0]
00007d248dbd1066  vmovaps xmm14, [rsp+0xD0]
00007d248dbd106f  vmovaps xmm15, [rsp+0xE0]
00007d248dbd1078  add rsp, 0xF0
00007d248dbd107f  pop r11
00007d248dbd1081  pop r10
00007d248dbd1083  pop r9
00007d248dbd1085  pop r8
00007d248dbd1087  pop rsi
00007d248dbd1088  pop rdi
00007d248dbd1089  pop rdx
00007d248dbd108a  pop rcx
00007d248dbd108b  pop rax
00007d248dbd108c  add rsp, 0x08
00007d248dbd1090  jmp 0x00007D248DBCF732
00007d248dbd1095  sub rsp, 0x08
00007d248dbd1099  push rax
00007d248dbd109a  push rcx
00007d248dbd109b  push rdx
00007d248dbd109c  push rdi
00007d248dbd109d  push rsi
00007d248dbd109e  push r8
00007d248dbd10a0  push r9
00007d248dbd10a2  push r10
00007d248dbd10a4  push r11
00007d248dbd10a6  sub rsp, 0xF0
00007d248dbd10ad  vmovaps [rsp], xmm0
00007d248dbd10b2  vmovaps [rsp+0x10], xmm1
00007d248dbd10b8  vmovaps [rsp+0x20], xmm2
00007d248dbd10be  vmovaps [rsp+0x30], xmm3
00007d248dbd10c4  vmovaps [rsp+0x40], xmm4
00007d248dbd10ca  vmovaps [rsp+0x50], xmm5
00007d248dbd10d0  vmovaps [rsp+0x60], xmm6
00007d248dbd10d6  vmovaps [rsp+0x70], xmm7
00007d248dbd10dc  vmovaps [rsp+0x80], xmm8
00007d248dbd10e5  vmovaps [rsp+0x90], xmm9
00007d248dbd10ee  vmovaps [rsp+0xA0], xmm10
00007d248dbd10f7  vmovaps [rsp+0xB0], xmm11
00007d248dbd1100  vmovaps [rsp+0xC0], xmm12
00007d248dbd1109  vmovaps [rsp+0xD0], xmm13
00007d248dbd1112  vmovaps [rsp+0xE0], xmm14
00007d248dbd111b  sub rsp, 0x30
00007d248dbd111f  movaps [rsp], xmm15
00007d248dbd1124  movaps [rsp+0x10], xmm10
00007d248dbd112a  movaps [rsp+0x20], xmm12
00007d248dbd1130  lea rdi, [rsp]
00007d248dbd1134  mov esi, 0x00
00007d248dbd1139  mov rax, 0x5BCEEF236530
00007d248dbd1143  call rax
00007d248dbd1145  movaps xmm15, [rsp]
00007d248dbd114a  add rsp, 0x30
00007d248dbd114e  vmovaps xmm0, [rsp]
00007d248dbd1153  vmovaps xmm1, [rsp+0x10]
00007d248dbd1159  vmovaps xmm2, [rsp+0x20]
00007d248dbd115f  vmovaps xmm3, [rsp+0x30]
00007d248dbd1165  vmovaps xmm4, [rsp+0x40]
00007d248dbd116b  vmovaps xmm5, [rsp+0x50]
00007d248dbd1171  vmovaps xmm6, [rsp+0x60]
00007d248dbd1177  vmovaps xmm7, [rsp+0x70]
00007d248dbd117d  vmovaps xmm8, [rsp+0x80]
00007d248dbd1186  vmovaps xmm9, [rsp+0x90]
00007d248dbd118f  vmovaps xmm10, [rsp+0xA0]
00007d248dbd1198  vmovaps xmm11, [rsp+0xB0]
00007d248dbd11a1  vmovaps xmm12, [rsp+0xC0]
00007d248dbd11aa  vmovaps xmm13, [rsp+0xD0]
00007d248dbd11b3  vmovaps xmm14, [rsp+0xE0]
00007d248dbd11bc  add rsp, 0xF0
00007d248dbd11c3  pop r11
00007d248dbd11c5  pop r10
00007d248dbd11c7  pop r9
00007d248dbd11c9  pop r8
00007d248dbd11cb  pop rsi
00007d248dbd11cc  pop rdi
00007d248dbd11cd  pop rdx
00007d248dbd11ce  pop rcx
00007d248dbd11cf  pop rax
00007d248dbd11d0  add rsp, 0x08
00007d248dbd11d4  jmp 0x00007D248DBCF75E
00007d248dbd11d9  call 0x00007D248D9FF430
00007d248dbd11de  jmp 0x00007D248DBCF7EE
00007d248dbd11e3  call 0x00007D248D9FF430
00007d248dbd11e8  jmp 0x00007D248DBCF801
00007d248dbd11ed  sub rsp, 0x08
00007d248dbd11f1  push rax
00007d248dbd11f2  push rcx
00007d248dbd11f3  push rdx
00007d248dbd11f4  push rdi
00007d248dbd11f5  push rsi
00007d248dbd11f6  push r8
00007d248dbd11f8  push r9
00007d248dbd11fa  push r10
00007d248dbd11fc  push r11
00007d248dbd11fe  sub rsp, 0xF0
00007d248dbd1205  vmovaps [rsp], xmm0
00007d248dbd120a  vmovaps [rsp+0x10], xmm2
00007d248dbd1210  vmovaps [rsp+0x20], xmm3
00007d248dbd1216  vmovaps [rsp+0x30], xmm4
00007d248dbd121c  vmovaps [rsp+0x40], xmm5
00007d248dbd1222  vmovaps [rsp+0x50], xmm6
00007d248dbd1228  vmovaps [rsp+0x60], xmm7
00007d248dbd122e  vmovaps [rsp+0x70], xmm8
00007d248dbd1234  vmovaps [rsp+0x80], xmm9
00007d248dbd123d  vmovaps [rsp+0x90], xmm10
00007d248dbd1246  vmovaps [rsp+0xA0], xmm11
00007d248dbd124f  vmovaps [rsp+0xB0], xmm12
00007d248dbd1258  vmovaps [rsp+0xC0], xmm13
00007d248dbd1261  vmovaps [rsp+0xD0], xmm14
00007d248dbd126a  vmovaps [rsp+0xE0], xmm15
00007d248dbd1273  sub rsp, 0x30
00007d248dbd1277  movaps [rsp], xmm1
00007d248dbd127b  movaps [rsp+0x10], xmm13
00007d248dbd1281  movaps [rsp+0x20], xmm2
00007d248dbd1286  lea rdi, [rsp]
00007d248dbd128a  mov esi, 0x00
00007d248dbd128f  mov rax, 0x5BCEEF236530
00007d248dbd1299  call rax
00007d248dbd129b  movaps xmm1, [rsp]
00007d248dbd129f  add rsp, 0x30
00007d248dbd12a3  vmovaps xmm0, [rsp]
00007d248dbd12a8  vmovaps xmm2, [rsp+0x10]
00007d248dbd12ae  vmovaps xmm3, [rsp+0x20]
00007d248dbd12b4  vmovaps xmm4, [rsp+0x30]
00007d248dbd12ba  vmovaps xmm5, [rsp+0x40]
00007d248dbd12c0  vmovaps xmm6, [rsp+0x50]
00007d248dbd12c6  vmovaps xmm7, [rsp+0x60]
00007d248dbd12cc  vmovaps xmm8, [rsp+0x70]
00007d248dbd12d2  vmovaps xmm9, [rsp+0x80]
00007d248dbd12db  vmovaps xmm10, [rsp+0x90]
00007d248dbd12e4  vmovaps xmm11, [rsp+0xA0]
00007d248dbd12ed  vmovaps xmm12, [rsp+0xB0]
00007d248dbd12f6  vmovaps xmm13, [rsp+0xC0]
00007d248dbd12ff  vmovaps xmm14, [rsp+0xD0]
00007d248dbd1308  vmovaps xmm15, [rsp+0xE0]
00007d248dbd1311  add rsp, 0xF0
00007d248dbd1318  pop r11
00007d248dbd131a  pop r10
00007d248dbd131c  pop r9
00007d248dbd131e  pop r8
00007d248dbd1320  pop rsi
00007d248dbd1321  pop rdi
00007d248dbd1322  pop rdx
00007d248dbd1323  pop rcx
00007d248dbd1324  pop rax
00007d248dbd1325  add rsp, 0x08
00007d248dbd1329  jmp 0x00007D248DBCF82C
00007d248dbd132e  call 0x00007D248DA0E760
00007d248dbd1333  jmp 0x00007D248DBCF839
00007d248dbd1338  sub rsp, 0x08
00007d248dbd133c  push rax
00007d248dbd133d  push rcx
00007d248dbd133e  push rdx
00007d248dbd133f  push rdi
00007d248dbd1340  push rsi
00007d248dbd1341  push r8
00007d248dbd1343  push r9
00007d248dbd1345  push r10
00007d248dbd1347  push r11
00007d248dbd1349  sub rsp, 0xF0
00007d248dbd1350  vmovaps [rsp], xmm0
00007d248dbd1355  vmovaps [rsp+0x10], xmm1
00007d248dbd135b  vmovaps [rsp+0x20], xmm2
00007d248dbd1361  vmovaps [rsp+0x30], xmm3
00007d248dbd1367  vmovaps [rsp+0x40], xmm4
00007d248dbd136d  vmovaps [rsp+0x50], xmm5
00007d248dbd1373  vmovaps [rsp+0x60], xmm6
00007d248dbd1379  vmovaps [rsp+0x70], xmm7
00007d248dbd137f  vmovaps [rsp+0x80], xmm8
00007d248dbd1388  vmovaps [rsp+0x90], xmm9
00007d248dbd1391  vmovaps [rsp+0xA0], xmm10
00007d248dbd139a  vmovaps [rsp+0xB0], xmm11
00007d248dbd13a3  vmovaps [rsp+0xC0], xmm12
00007d248dbd13ac  vmovaps [rsp+0xD0], xmm14
00007d248dbd13b5  vmovaps [rsp+0xE0], xmm15
00007d248dbd13be  sub rsp, 0x30
00007d248dbd13c2  movaps [rsp], xmm13
00007d248dbd13c7  movaps [rsp+0x10], xmm2
00007d248dbd13cc  movaps [rsp+0x20], xmm1
00007d248dbd13d1  lea rdi, [rsp]
00007d248dbd13d5  mov esi, 0x00
00007d248dbd13da  mov rax, 0x5BCEEF236530
00007d248dbd13e4  call rax
00007d248dbd13e6  movaps xmm13, [rsp]
00007d248dbd13eb  add rsp, 0x30
00007d248dbd13ef  vmovaps xmm0, [rsp]
00007d248dbd13f4  vmovaps xmm1, [rsp+0x10]
00007d248dbd13fa  vmovaps xmm2, [rsp+0x20]
00007d248dbd1400  vmovaps xmm3, [rsp+0x30]
00007d248dbd1406  vmovaps xmm4, [rsp+0x40]
00007d248dbd140c  vmovaps xmm5, [rsp+0x50]
00007d248dbd1412  vmovaps xmm6, [rsp+0x60]
00007d248dbd1418  vmovaps xmm7, [rsp+0x70]
00007d248dbd141e  vmovaps xmm8, [rsp+0x80]
00007d248dbd1427  vmovaps xmm9, [rsp+0x90]
00007d248dbd1430  vmovaps xmm10, [rsp+0xA0]
00007d248dbd1439  vmovaps xmm11, [rsp+0xB0]
00007d248dbd1442  vmovaps xmm12, [rsp+0xC0]
00007d248dbd144b  vmovaps xmm14, [rsp+0xD0]
00007d248dbd1454  vmovaps xmm15, [rsp+0xE0]
00007d248dbd145d  add rsp, 0xF0
00007d248dbd1464  pop r11
00007d248dbd1466  pop r10
00007d248dbd1468  pop r9
00007d248dbd146a  pop r8
00007d248dbd146c  pop rsi
00007d248dbd146d  pop rdi
00007d248dbd146e  pop rdx
00007d248dbd146f  pop rcx
00007d248dbd1470  pop rax
00007d248dbd1471  add rsp, 0x08
00007d248dbd1475  jmp 0x00007D248DBCF878
00007d248dbd147a  sub rsp, 0x08
00007d248dbd147e  push rax
00007d248dbd147f  push rcx
00007d248dbd1480  push rdx
00007d248dbd1481  push rdi
00007d248dbd1482  push rsi
00007d248dbd1483  push r8
00007d248dbd1485  push r9
00007d248dbd1487  push r10
00007d248dbd1489  push r11
00007d248dbd148b  sub rsp, 0xF0
00007d248dbd1492  vmovaps [rsp], xmm0
00007d248dbd1497  vmovaps [rsp+0x10], xmm2
00007d248dbd149d  vmovaps [rsp+0x20], xmm3
00007d248dbd14a3  vmovaps [rsp+0x30], xmm4
00007d248dbd14a9  vmovaps [rsp+0x40], xmm5
00007d248dbd14af  vmovaps [rsp+0x50], xmm6
00007d248dbd14b5  vmovaps [rsp+0x60], xmm7
00007d248dbd14bb  vmovaps [rsp+0x70], xmm8
00007d248dbd14c1  vmovaps [rsp+0x80], xmm9
00007d248dbd14ca  vmovaps [rsp+0x90], xmm10
00007d248dbd14d3  vmovaps [rsp+0xA0], xmm11
00007d248dbd14dc  vmovaps [rsp+0xB0], xmm12
00007d248dbd14e5  vmovaps [rsp+0xC0], xmm13
00007d248dbd14ee  vmovaps [rsp+0xD0], xmm14
00007d248dbd14f7  vmovaps [rsp+0xE0], xmm15
00007d248dbd1500  sub rsp, 0x30
00007d248dbd1504  movaps [rsp], xmm1
00007d248dbd1508  movaps [rsp+0x10], xmm15
00007d248dbd150e  movaps [rsp+0x20], xmm2
00007d248dbd1513  lea rdi, [rsp]
00007d248dbd1517  mov esi, 0x00
00007d248dbd151c  mov rax, 0x5BCEEF236530
00007d248dbd1526  call rax
00007d248dbd1528  movaps xmm1, [rsp]
00007d248dbd152c  add rsp, 0x30
00007d248dbd1530  vmovaps xmm0, [rsp]
00007d248dbd1535  vmovaps xmm2, [rsp+0x10]
00007d248dbd153b  vmovaps xmm3, [rsp+0x20]
00007d248dbd1541  vmovaps xmm4, [rsp+0x30]
00007d248dbd1547  vmovaps xmm5, [rsp+0x40]
00007d248dbd154d  vmovaps xmm6, [rsp+0x50]
00007d248dbd1553  vmovaps xmm7, [rsp+0x60]
00007d248dbd1559  vmovaps xmm8, [rsp+0x70]
00007d248dbd155f  vmovaps xmm9, [rsp+0x80]
00007d248dbd1568  vmovaps xmm10, [rsp+0x90]
00007d248dbd1571  vmovaps xmm11, [rsp+0xA0]
00007d248dbd157a  vmovaps xmm12, [rsp+0xB0]
00007d248dbd1583  vmovaps xmm13, [rsp+0xC0]
00007d248dbd158c  vmovaps xmm14, [rsp+0xD0]
00007d248dbd1595  vmovaps xmm15, [rsp+0xE0]
00007d248dbd159e  add rsp, 0xF0
00007d248dbd15a5  pop r11
00007d248dbd15a7  pop r10
00007d248dbd15a9  pop r9
00007d248dbd15ab  pop r8
00007d248dbd15ad  pop rsi
00007d248dbd15ae  pop rdi
00007d248dbd15af  pop rdx
00007d248dbd15b0  pop rcx
00007d248dbd15b1  pop rax
00007d248dbd15b2  add rsp, 0x08
00007d248dbd15b6  jmp 0x00007D248DBCF8AC
00007d248dbd15bb  sub rsp, 0x08
00007d248dbd15bf  push rax
00007d248dbd15c0  push rcx
00007d248dbd15c1  push rdx
00007d248dbd15c2  push rdi
00007d248dbd15c3  push rsi
00007d248dbd15c4  push r8
00007d248dbd15c6  push r9
00007d248dbd15c8  push r10
00007d248dbd15ca  push r11
00007d248dbd15cc  sub rsp, 0xF0
00007d248dbd15d3  vmovaps [rsp], xmm0
00007d248dbd15d8  vmovaps [rsp+0x10], xmm1
00007d248dbd15de  vmovaps [rsp+0x20], xmm2
00007d248dbd15e4  vmovaps [rsp+0x30], xmm3
00007d248dbd15ea  vmovaps [rsp+0x40], xmm4
00007d248dbd15f0  vmovaps [rsp+0x50], xmm5
00007d248dbd15f6  vmovaps [rsp+0x60], xmm6
00007d248dbd15fc  vmovaps [rsp+0x70], xmm7
00007d248dbd1602  vmovaps [rsp+0x80], xmm8
00007d248dbd160b  vmovaps [rsp+0x90], xmm9
00007d248dbd1614  vmovaps [rsp+0xA0], xmm10
00007d248dbd161d  vmovaps [rsp+0xB0], xmm11
00007d248dbd1626  vmovaps [rsp+0xC0], xmm12
00007d248dbd162f  vmovaps [rsp+0xD0], xmm13
00007d248dbd1638  vmovaps [rsp+0xE0], xmm15
00007d248dbd1641  sub rsp, 0x30
00007d248dbd1645  movaps [rsp], xmm14
00007d248dbd164a  movaps [rsp+0x10], xmm2
00007d248dbd164f  movaps [rsp+0x20], xmm15
00007d248dbd1655  lea rdi, [rsp]
00007d248dbd1659  mov esi, 0x00
00007d248dbd165e  mov rax, 0x5BCEEF236530
00007d248dbd1668  call rax
00007d248dbd166a  movaps xmm14, [rsp]
00007d248dbd166f  add rsp, 0x30
00007d248dbd1673  vmovaps xmm0, [rsp]
00007d248dbd1678  vmovaps xmm1, [rsp+0x10]
00007d248dbd167e  vmovaps xmm2, [rsp+0x20]
00007d248dbd1684  vmovaps xmm3, [rsp+0x30]
00007d248dbd168a  vmovaps xmm4, [rsp+0x40]
00007d248dbd1690  vmovaps xmm5, [rsp+0x50]
00007d248dbd1696  vmovaps xmm6, [rsp+0x60]
00007d248dbd169c  vmovaps xmm7, [rsp+0x70]
00007d248dbd16a2  vmovaps xmm8, [rsp+0x80]
00007d248dbd16ab  vmovaps xmm9, [rsp+0x90]
00007d248dbd16b4  vmovaps xmm10, [rsp+0xA0]
00007d248dbd16bd  vmovaps xmm11, [rsp+0xB0]
00007d248dbd16c6  vmovaps xmm12, [rsp+0xC0]
00007d248dbd16cf  vmovaps xmm13, [rsp+0xD0]
00007d248dbd16d8  vmovaps xmm15, [rsp+0xE0]
00007d248dbd16e1  add rsp, 0xF0
00007d248dbd16e8  pop r11
00007d248dbd16ea  pop r10
00007d248dbd16ec  pop r9
00007d248dbd16ee  pop r8
00007d248dbd16f0  pop rsi
00007d248dbd16f1  pop rdi
00007d248dbd16f2  pop rdx
00007d248dbd16f3  pop rcx
00007d248dbd16f4  pop rax
00007d248dbd16f5  add rsp, 0x08
00007d248dbd16f9  jmp 0x00007D248DBCF8E7
00007d248dbd16fe  sub rsp, 0x08
00007d248dbd1702  push rax
00007d248dbd1703  push rcx
00007d248dbd1704  push rdx
00007d248dbd1705  push rdi
00007d248dbd1706  push rsi
00007d248dbd1707  push r8
00007d248dbd1709  push r9
00007d248dbd170b  push r10
00007d248dbd170d  push r11
00007d248dbd170f  sub rsp, 0xF0
00007d248dbd1716  vmovaps [rsp], xmm0
00007d248dbd171b  vmovaps [rsp+0x10], xmm1
00007d248dbd1721  vmovaps [rsp+0x20], xmm2
00007d248dbd1727  vmovaps [rsp+0x30], xmm3
00007d248dbd172d  vmovaps [rsp+0x40], xmm4
00007d248dbd1733  vmovaps [rsp+0x50], xmm5
00007d248dbd1739  vmovaps [rsp+0x60], xmm6
00007d248dbd173f  vmovaps [rsp+0x70], xmm7
00007d248dbd1745  vmovaps [rsp+0x80], xmm8
00007d248dbd174e  vmovaps [rsp+0x90], xmm9
00007d248dbd1757  vmovaps [rsp+0xA0], xmm10
00007d248dbd1760  vmovaps [rsp+0xB0], xmm11
00007d248dbd1769  vmovaps [rsp+0xC0], xmm12
00007d248dbd1772  vmovaps [rsp+0xD0], xmm13
00007d248dbd177b  vmovaps [rsp+0xE0], xmm14
00007d248dbd1784  sub rsp, 0x30
00007d248dbd1788  movaps [rsp], xmm15
00007d248dbd178d  movaps [rsp+0x10], xmm2
00007d248dbd1792  movaps [rsp+0x20], xmm1
00007d248dbd1797  lea rdi, [rsp]
00007d248dbd179b  mov esi, 0x00
00007d248dbd17a0  mov rax, 0x5BCEEF236530
00007d248dbd17aa  call rax
00007d248dbd17ac  movaps xmm15, [rsp]
00007d248dbd17b1  add rsp, 0x30
00007d248dbd17b5  vmovaps xmm0, [rsp]
00007d248dbd17ba  vmovaps xmm1, [rsp+0x10]
00007d248dbd17c0  vmovaps xmm2, [rsp+0x20]
00007d248dbd17c6  vmovaps xmm3, [rsp+0x30]
00007d248dbd17cc  vmovaps xmm4, [rsp+0x40]
00007d248dbd17d2  vmovaps xmm5, [rsp+0x50]
00007d248dbd17d8  vmovaps xmm6, [rsp+0x60]
00007d248dbd17de  vmovaps xmm7, [rsp+0x70]
00007d248dbd17e4  vmovaps xmm8, [rsp+0x80]
00007d248dbd17ed  vmovaps xmm9, [rsp+0x90]
00007d248dbd17f6  vmovaps xmm10, [rsp+0xA0]
00007d248dbd17ff  vmovaps xmm11, [rsp+0xB0]
00007d248dbd1808  vmovaps xmm12, [rsp+0xC0]
00007d248dbd1811  vmovaps xmm13, [rsp+0xD0]
00007d248dbd181a  vmovaps xmm14, [rsp+0xE0]
00007d248dbd1823  add rsp, 0xF0
00007d248dbd182a  pop r11
00007d248dbd182c  pop r10
00007d248dbd182e  pop r9
00007d248dbd1830  pop r8
00007d248dbd1832  pop rsi
00007d248dbd1833  pop rdi
00007d248dbd1834  pop rdx
00007d248dbd1835  pop rcx
00007d248dbd1836  pop rax
00007d248dbd1837  add rsp, 0x08
00007d248dbd183b  jmp 0x00007D248DBCF923
00007d248dbd1840  call 0x00007D248D9FF430
00007d248dbd1845  jmp 0x00007D248DBCF930
00007d248dbd184a  sub rsp, 0x08
00007d248dbd184e  push rax
00007d248dbd184f  push rcx
00007d248dbd1850  push rdx
00007d248dbd1851  push rdi
00007d248dbd1852  push rsi
00007d248dbd1853  push r8
00007d248dbd1855  push r9
00007d248dbd1857  push r10
00007d248dbd1859  push r11
00007d248dbd185b  sub rsp, 0xF0
00007d248dbd1862  vmovaps [rsp], xmm0
00007d248dbd1867  vmovaps [rsp+0x10], xmm1
00007d248dbd186d  vmovaps [rsp+0x20], xmm3
00007d248dbd1873  vmovaps [rsp+0x30], xmm4
00007d248dbd1879  vmovaps [rsp+0x40], xmm5
00007d248dbd187f  vmovaps [rsp+0x50], xmm6
00007d248dbd1885  vmovaps [rsp+0x60], xmm7
00007d248dbd188b  vmovaps [rsp+0x70], xmm8
00007d248dbd1891  vmovaps [rsp+0x80], xmm9
00007d248dbd189a  vmovaps [rsp+0x90], xmm10
00007d248dbd18a3  vmovaps [rsp+0xA0], xmm11
00007d248dbd18ac  vmovaps [rsp+0xB0], xmm12
00007d248dbd18b5  vmovaps [rsp+0xC0], xmm13
00007d248dbd18be  vmovaps [rsp+0xD0], xmm14
00007d248dbd18c7  vmovaps [rsp+0xE0], xmm15
00007d248dbd18d0  sub rsp, 0x30
00007d248dbd18d4  movaps [rsp], xmm2
00007d248dbd18d8  movaps [rsp+0x10], xmm1
00007d248dbd18dd  movaps [rsp+0x20], xmm14
00007d248dbd18e3  lea rdi, [rsp]
00007d248dbd18e7  mov esi, 0x00
00007d248dbd18ec  mov rax, 0x5BCEEF236530
00007d248dbd18f6  call rax
00007d248dbd18f8  movaps xmm2, [rsp]
00007d248dbd18fc  add rsp, 0x30
00007d248dbd1900  vmovaps xmm0, [rsp]
00007d248dbd1905  vmovaps xmm1, [rsp+0x10]
00007d248dbd190b  vmovaps xmm3, [rsp+0x20]
00007d248dbd1911  vmovaps xmm4, [rsp+0x30]
00007d248dbd1917  vmovaps xmm5, [rsp+0x40]
00007d248dbd191d  vmovaps xmm6, [rsp+0x50]
00007d248dbd1923  vmovaps xmm7, [rsp+0x60]
00007d248dbd1929  vmovaps xmm8, [rsp+0x70]
00007d248dbd192f  vmovaps xmm9, [rsp+0x80]
00007d248dbd1938  vmovaps xmm10, [rsp+0x90]
00007d248dbd1941  vmovaps xmm11, [rsp+0xA0]
00007d248dbd194a  vmovaps xmm12, [rsp+0xB0]
00007d248dbd1953  vmovaps xmm13, [rsp+0xC0]
00007d248dbd195c  vmovaps xmm14, [rsp+0xD0]
00007d248dbd1965  vmovaps xmm15, [rsp+0xE0]
00007d248dbd196e  add rsp, 0xF0
00007d248dbd1975  pop r11
00007d248dbd1977  pop r10
00007d248dbd1979  pop r9
00007d248dbd197b  pop r8
00007d248dbd197d  pop rsi
00007d248dbd197e  pop rdi
00007d248dbd197f  pop rdx
00007d248dbd1980  pop rcx
00007d248dbd1981  pop rax
00007d248dbd1982  add rsp, 0x08
00007d248dbd1986  jmp 0x00007D248DBCF96D
00007d248dbd198b  sub rsp, 0x08
00007d248dbd198f  push rax
00007d248dbd1990  push rcx
00007d248dbd1991  push rdx
00007d248dbd1992  push rdi
00007d248dbd1993  push rsi
00007d248dbd1994  push r8
00007d248dbd1996  push r9
00007d248dbd1998  push r10
00007d248dbd199a  push r11
00007d248dbd199c  sub rsp, 0xF0
00007d248dbd19a3  vmovaps [rsp], xmm0
00007d248dbd19a8  vmovaps [rsp+0x10], xmm1
00007d248dbd19ae  vmovaps [rsp+0x20], xmm2
00007d248dbd19b4  vmovaps [rsp+0x30], xmm3
00007d248dbd19ba  vmovaps [rsp+0x40], xmm4
00007d248dbd19c0  vmovaps [rsp+0x50], xmm5
00007d248dbd19c6  vmovaps [rsp+0x60], xmm6
00007d248dbd19cc  vmovaps [rsp+0x70], xmm7
00007d248dbd19d2  vmovaps [rsp+0x80], xmm8
00007d248dbd19db  vmovaps [rsp+0x90], xmm9
00007d248dbd19e4  vmovaps [rsp+0xA0], xmm10
00007d248dbd19ed  vmovaps [rsp+0xB0], xmm11
00007d248dbd19f6  vmovaps [rsp+0xC0], xmm12
00007d248dbd19ff  vmovaps [rsp+0xD0], xmm13
00007d248dbd1a08  vmovaps [rsp+0xE0], xmm14
00007d248dbd1a11  sub rsp, 0x30
00007d248dbd1a15  movaps [rsp], xmm15
00007d248dbd1a1a  movaps [rsp+0x10], xmm14
00007d248dbd1a20  movaps [rsp+0x20], xmm1
00007d248dbd1a25  lea rdi, [rsp]
00007d248dbd1a29  mov esi, 0x00
00007d248dbd1a2e  mov rax, 0x5BCEEF236530
00007d248dbd1a38  call rax
00007d248dbd1a3a  movaps xmm15, [rsp]
00007d248dbd1a3f  add rsp, 0x30
00007d248dbd1a43  vmovaps xmm0, [rsp]
00007d248dbd1a48  vmovaps xmm1, [rsp+0x10]
00007d248dbd1a4e  vmovaps xmm2, [rsp+0x20]
00007d248dbd1a54  vmovaps xmm3, [rsp+0x30]
00007d248dbd1a5a  vmovaps xmm4, [rsp+0x40]
00007d248dbd1a60  vmovaps xmm5, [rsp+0x50]
00007d248dbd1a66  vmovaps xmm6, [rsp+0x60]
00007d248dbd1a6c  vmovaps xmm7, [rsp+0x70]
00007d248dbd1a72  vmovaps xmm8, [rsp+0x80]
00007d248dbd1a7b  vmovaps xmm9, [rsp+0x90]
00007d248dbd1a84  vmovaps xmm10, [rsp+0xA0]
00007d248dbd1a8d  vmovaps xmm11, [rsp+0xB0]
00007d248dbd1a96  vmovaps xmm12, [rsp+0xC0]
00007d248dbd1a9f  vmovaps xmm13, [rsp+0xD0]
00007d248dbd1aa8  vmovaps xmm14, [rsp+0xE0]
00007d248dbd1ab1  add rsp, 0xF0
00007d248dbd1ab8  pop r11
00007d248dbd1aba  pop r10
00007d248dbd1abc  pop r9
00007d248dbd1abe  pop r8
00007d248dbd1ac0  pop rsi
00007d248dbd1ac1  pop rdi
00007d248dbd1ac2  pop rdx
00007d248dbd1ac3  pop rcx
00007d248dbd1ac4  pop rax
00007d248dbd1ac5  add rsp, 0x08
00007d248dbd1ac9  jmp 0x00007D248DBCF9E7
00007d248dbd1ace  call 0x00007D248D9FF430
00007d248dbd1ad3  jmp 0x00007D248DBCF9F4
00007d248dbd1ad8  sub rsp, 0x08
00007d248dbd1adc  push rax
00007d248dbd1add  push rcx
00007d248dbd1ade  push rdx
00007d248dbd1adf  push rdi
00007d248dbd1ae0  push rsi
00007d248dbd1ae1  push r8
00007d248dbd1ae3  push r9
00007d248dbd1ae5  push r10
00007d248dbd1ae7  push r11
00007d248dbd1ae9  sub rsp, 0xF0
00007d248dbd1af0  vmovaps [rsp], xmm0
00007d248dbd1af5  vmovaps [rsp+0x10], xmm1
00007d248dbd1afb  vmovaps [rsp+0x20], xmm2
00007d248dbd1b01  vmovaps [rsp+0x30], xmm3
00007d248dbd1b07  vmovaps [rsp+0x40], xmm4
00007d248dbd1b0d  vmovaps [rsp+0x50], xmm5
00007d248dbd1b13  vmovaps [rsp+0x60], xmm6
00007d248dbd1b19  vmovaps [rsp+0x70], xmm7
00007d248dbd1b1f  vmovaps [rsp+0x80], xmm8
00007d248dbd1b28  vmovaps [rsp+0x90], xmm9
00007d248dbd1b31  vmovaps [rsp+0xA0], xmm10
00007d248dbd1b3a  vmovaps [rsp+0xB0], xmm11
00007d248dbd1b43  vmovaps [rsp+0xC0], xmm12
00007d248dbd1b4c  vmovaps [rsp+0xD0], xmm13
00007d248dbd1b55  vmovaps [rsp+0xE0], xmm15
00007d248dbd1b5e  sub rsp, 0x30
00007d248dbd1b62  movaps [rsp], xmm14
00007d248dbd1b67  movaps [rsp+0x10], xmm13
00007d248dbd1b6d  movaps [rsp+0x20], xmm1
00007d248dbd1b72  lea rdi, [rsp]
00007d248dbd1b76  mov esi, 0x00
00007d248dbd1b7b  mov rax, 0x5BCEEF236530
00007d248dbd1b85  call rax
00007d248dbd1b87  movaps xmm14, [rsp]
00007d248dbd1b8c  add rsp, 0x30
00007d248dbd1b90  vmovaps xmm0, [rsp]
00007d248dbd1b95  vmovaps xmm1, [rsp+0x10]
00007d248dbd1b9b  vmovaps xmm2, [rsp+0x20]
00007d248dbd1ba1  vmovaps xmm3, [rsp+0x30]
00007d248dbd1ba7  vmovaps xmm4, [rsp+0x40]
00007d248dbd1bad  vmovaps xmm5, [rsp+0x50]
00007d248dbd1bb3  vmovaps xmm6, [rsp+0x60]
00007d248dbd1bb9  vmovaps xmm7, [rsp+0x70]
00007d248dbd1bbf  vmovaps xmm8, [rsp+0x80]
00007d248dbd1bc8  vmovaps xmm9, [rsp+0x90]
00007d248dbd1bd1  vmovaps xmm10, [rsp+0xA0]
00007d248dbd1bda  vmovaps xmm11, [rsp+0xB0]
00007d248dbd1be3  vmovaps xmm12, [rsp+0xC0]
00007d248dbd1bec  vmovaps xmm13, [rsp+0xD0]
00007d248dbd1bf5  vmovaps xmm15, [rsp+0xE0]
00007d248dbd1bfe  add rsp, 0xF0
00007d248dbd1c05  pop r11
00007d248dbd1c07  pop r10
00007d248dbd1c09  pop r9
00007d248dbd1c0b  pop r8
00007d248dbd1c0d  pop rsi
00007d248dbd1c0e  pop rdi
00007d248dbd1c0f  pop rdx
00007d248dbd1c10  pop rcx
00007d248dbd1c11  pop rax
00007d248dbd1c12  add rsp, 0x08
00007d248dbd1c16  jmp 0x00007D248DBCFAAF
00007d248dbd1c1b  sub rsp, 0x08
00007d248dbd1c1f  push rax
00007d248dbd1c20  push rcx
00007d248dbd1c21  push rdx
00007d248dbd1c22  push rdi
00007d248dbd1c23  push rsi
00007d248dbd1c24  push r8
00007d248dbd1c26  push r9
00007d248dbd1c28  push r10
00007d248dbd1c2a  push r11
00007d248dbd1c2c  sub rsp, 0xF0
00007d248dbd1c33  vmovaps [rsp], xmm0
00007d248dbd1c38  vmovaps [rsp+0x10], xmm1
00007d248dbd1c3e  vmovaps [rsp+0x20], xmm2
00007d248dbd1c44  vmovaps [rsp+0x30], xmm3
00007d248dbd1c4a  vmovaps [rsp+0x40], xmm4
00007d248dbd1c50  vmovaps [rsp+0x50], xmm5
00007d248dbd1c56  vmovaps [rsp+0x60], xmm6
00007d248dbd1c5c  vmovaps [rsp+0x70], xmm7
00007d248dbd1c62  vmovaps [rsp+0x80], xmm8
00007d248dbd1c6b  vmovaps [rsp+0x90], xmm9
00007d248dbd1c74  vmovaps [rsp+0xA0], xmm10
00007d248dbd1c7d  vmovaps [rsp+0xB0], xmm11
00007d248dbd1c86  vmovaps [rsp+0xC0], xmm12
00007d248dbd1c8f  vmovaps [rsp+0xD0], xmm13
00007d248dbd1c98  vmovaps [rsp+0xE0], xmm14
00007d248dbd1ca1  sub rsp, 0x30
00007d248dbd1ca5  movaps [rsp], xmm15
00007d248dbd1caa  movaps [rsp+0x10], xmm13
00007d248dbd1cb0  movaps [rsp+0x20], xmm1
00007d248dbd1cb5  lea rdi, [rsp]
00007d248dbd1cb9  mov esi, 0x00
00007d248dbd1cbe  mov rax, 0x5BCEEF236530
00007d248dbd1cc8  call rax
00007d248dbd1cca  movaps xmm15, [rsp]
00007d248dbd1ccf  add rsp, 0x30
00007d248dbd1cd3  vmovaps xmm0, [rsp]
00007d248dbd1cd8  vmovaps xmm1, [rsp+0x10]
00007d248dbd1cde  vmovaps xmm2, [rsp+0x20]
00007d248dbd1ce4  vmovaps xmm3, [rsp+0x30]
00007d248dbd1cea  vmovaps xmm4, [rsp+0x40]
00007d248dbd1cf0  vmovaps xmm5, [rsp+0x50]
00007d248dbd1cf6  vmovaps xmm6, [rsp+0x60]
00007d248dbd1cfc  vmovaps xmm7, [rsp+0x70]
00007d248dbd1d02  vmovaps xmm8, [rsp+0x80]
00007d248dbd1d0b  vmovaps xmm9, [rsp+0x90]
00007d248dbd1d14  vmovaps xmm10, [rsp+0xA0]
00007d248dbd1d1d  vmovaps xmm11, [rsp+0xB0]
00007d248dbd1d26  vmovaps xmm12, [rsp+0xC0]
00007d248dbd1d2f  vmovaps xmm13, [rsp+0xD0]
00007d248dbd1d38  vmovaps xmm14, [rsp+0xE0]
00007d248dbd1d41  add rsp, 0xF0
00007d248dbd1d48  pop r11
00007d248dbd1d4a  pop r10
00007d248dbd1d4c  pop r9
00007d248dbd1d4e  pop r8
00007d248dbd1d50  pop rsi
00007d248dbd1d51  pop rdi
00007d248dbd1d52  pop rdx
00007d248dbd1d53  pop rcx
00007d248dbd1d54  pop rax
00007d248dbd1d55  add rsp, 0x08
00007d248dbd1d59  jmp 0x00007D248DBCFAEB
00007d248dbd1d5e  call 0x00007D248D9FF430
00007d248dbd1d63  jmp 0x00007D248DBCFAF8
00007d248dbd1d68  sub rsp, 0x08
00007d248dbd1d6c  push rax
00007d248dbd1d6d  push rcx
00007d248dbd1d6e  push rdx
00007d248dbd1d6f  push rdi
00007d248dbd1d70  push rsi
00007d248dbd1d71  push r8
00007d248dbd1d73  push r9
00007d248dbd1d75  push r10
00007d248dbd1d77  push r11
00007d248dbd1d79  sub rsp, 0xF0
00007d248dbd1d80  vmovaps [rsp], xmm0
00007d248dbd1d85  vmovaps [rsp+0x10], xmm1
00007d248dbd1d8b  vmovaps [rsp+0x20], xmm2
00007d248dbd1d91  vmovaps [rsp+0x30], xmm3
00007d248dbd1d97  vmovaps [rsp+0x40], xmm4
00007d248dbd1d9d  vmovaps [rsp+0x50], xmm5
00007d248dbd1da3  vmovaps [rsp+0x60], xmm6
00007d248dbd1da9  vmovaps [rsp+0x70], xmm7
00007d248dbd1daf  vmovaps [rsp+0x80], xmm8
00007d248dbd1db8  vmovaps [rsp+0x90], xmm9
00007d248dbd1dc1  vmovaps [rsp+0xA0], xmm10
00007d248dbd1dca  vmovaps [rsp+0xB0], xmm11
00007d248dbd1dd3  vmovaps [rsp+0xC0], xmm12
00007d248dbd1ddc  vmovaps [rsp+0xD0], xmm13
00007d248dbd1de5  vmovaps [rsp+0xE0], xmm15
00007d248dbd1dee  sub rsp, 0x30
00007d248dbd1df2  movaps [rsp], xmm14
00007d248dbd1df7  movaps [rsp+0x10], xmm13
00007d248dbd1dfd  movaps [rsp+0x20], xmm2
00007d248dbd1e02  lea rdi, [rsp]
00007d248dbd1e06  mov esi, 0x00
00007d248dbd1e0b  mov rax, 0x5BCEEF236530
00007d248dbd1e15  call rax
00007d248dbd1e17  movaps xmm14, [rsp]
00007d248dbd1e1c  add rsp, 0x30
00007d248dbd1e20  vmovaps xmm0, [rsp]
00007d248dbd1e25  vmovaps xmm1, [rsp+0x10]
00007d248dbd1e2b  vmovaps xmm2, [rsp+0x20]
00007d248dbd1e31  vmovaps xmm3, [rsp+0x30]
00007d248dbd1e37  vmovaps xmm4, [rsp+0x40]
00007d248dbd1e3d  vmovaps xmm5, [rsp+0x50]
00007d248dbd1e43  vmovaps xmm6, [rsp+0x60]
00007d248dbd1e49  vmovaps xmm7, [rsp+0x70]
00007d248dbd1e4f  vmovaps xmm8, [rsp+0x80]
00007d248dbd1e58  vmovaps xmm9, [rsp+0x90]
00007d248dbd1e61  vmovaps xmm10, [rsp+0xA0]
00007d248dbd1e6a  vmovaps xmm11, [rsp+0xB0]
00007d248dbd1e73  vmovaps xmm12, [rsp+0xC0]
00007d248dbd1e7c  vmovaps xmm13, [rsp+0xD0]
00007d248dbd1e85  vmovaps xmm15, [rsp+0xE0]
00007d248dbd1e8e  add rsp, 0xF0
00007d248dbd1e95  pop r11
00007d248dbd1e97  pop r10
00007d248dbd1e99  pop r9
00007d248dbd1e9b  pop r8
00007d248dbd1e9d  pop rsi
00007d248dbd1e9e  pop rdi
00007d248dbd1e9f  pop rdx
00007d248dbd1ea0  pop rcx
00007d248dbd1ea1  pop rax
00007d248dbd1ea2  add rsp, 0x08
00007d248dbd1ea6  jmp 0x00007D248DBCFB24
00007d248dbd1eab  sub rsp, 0x08
00007d248dbd1eaf  push rax
00007d248dbd1eb0  push rcx
00007d248dbd1eb1  push rdx
00007d248dbd1eb2  push rdi
00007d248dbd1eb3  push rsi
00007d248dbd1eb4  push r8
00007d248dbd1eb6  push r9
00007d248dbd1eb8  push r10
00007d248dbd1eba  push r11
00007d248dbd1ebc  sub rsp, 0xF0
00007d248dbd1ec3  vmovaps [rsp], xmm0
00007d248dbd1ec8  vmovaps [rsp+0x10], xmm2
00007d248dbd1ece  vmovaps [rsp+0x20], xmm3
00007d248dbd1ed4  vmovaps [rsp+0x30], xmm4
00007d248dbd1eda  vmovaps [rsp+0x40], xmm5
00007d248dbd1ee0  vmovaps [rsp+0x50], xmm6
00007d248dbd1ee6  vmovaps [rsp+0x60], xmm7
00007d248dbd1eec  vmovaps [rsp+0x70], xmm8
00007d248dbd1ef2  vmovaps [rsp+0x80], xmm9
00007d248dbd1efb  vmovaps [rsp+0x90], xmm10
00007d248dbd1f04  vmovaps [rsp+0xA0], xmm11
00007d248dbd1f0d  vmovaps [rsp+0xB0], xmm12
00007d248dbd1f16  vmovaps [rsp+0xC0], xmm13
00007d248dbd1f1f  vmovaps [rsp+0xD0], xmm14
00007d248dbd1f28  vmovaps [rsp+0xE0], xmm15
00007d248dbd1f31  sub rsp, 0x30
00007d248dbd1f35  movaps [rsp], xmm1
00007d248dbd1f39  movaps [rsp+0x10], xmm13
00007d248dbd1f3f  movaps [rsp+0x20], xmm2
00007d248dbd1f44  lea rdi, [rsp]
00007d248dbd1f48  mov esi, 0x00
00007d248dbd1f4d  mov rax, 0x5BCEEF236530
00007d248dbd1f57  call rax
00007d248dbd1f59  movaps xmm1, [rsp]
00007d248dbd1f5d  add rsp, 0x30
00007d248dbd1f61  vmovaps xmm0, [rsp]
00007d248dbd1f66  vmovaps xmm2, [rsp+0x10]
00007d248dbd1f6c  vmovaps xmm3, [rsp+0x20]
00007d248dbd1f72  vmovaps xmm4, [rsp+0x30]
00007d248dbd1f78  vmovaps xmm5, [rsp+0x40]
00007d248dbd1f7e  vmovaps xmm6, [rsp+0x50]
00007d248dbd1f84  vmovaps xmm7, [rsp+0x60]
00007d248dbd1f8a  vmovaps xmm8, [rsp+0x70]
00007d248dbd1f90  vmovaps xmm9, [rsp+0x80]
00007d248dbd1f99  vmovaps xmm10, [rsp+0x90]
00007d248dbd1fa2  vmovaps xmm11, [rsp+0xA0]
00007d248dbd1fab  vmovaps xmm12, [rsp+0xB0]
00007d248dbd1fb4  vmovaps xmm13, [rsp+0xC0]
00007d248dbd1fbd  vmovaps xmm14, [rsp+0xD0]
00007d248dbd1fc6  vmovaps xmm15, [rsp+0xE0]
00007d248dbd1fcf  add rsp, 0xF0
00007d248dbd1fd6  pop r11
00007d248dbd1fd8  pop r10
00007d248dbd1fda  pop r9
00007d248dbd1fdc  pop r8
00007d248dbd1fde  pop rsi
00007d248dbd1fdf  pop rdi
00007d248dbd1fe0  pop rdx
00007d248dbd1fe1  pop rcx
00007d248dbd1fe2  pop rax
00007d248dbd1fe3  add rsp, 0x08
00007d248dbd1fe7  jmp 0x00007D248DBCFB52
00007d248dbd1fec  sub rsp, 0x08
00007d248dbd1ff0  push rax
00007d248dbd1ff1  push rcx
00007d248dbd1ff2  push rdx
00007d248dbd1ff3  push rdi
00007d248dbd1ff4  push rsi
00007d248dbd1ff5  push r8
00007d248dbd1ff7  push r9
00007d248dbd1ff9  push r10
00007d248dbd1ffb  push r11
00007d248dbd1ffd  sub rsp, 0xF0
00007d248dbd2004  vmovaps [rsp], xmm0
00007d248dbd2009  vmovaps [rsp+0x10], xmm1
00007d248dbd200f  vmovaps [rsp+0x20], xmm3
00007d248dbd2015  vmovaps [rsp+0x30], xmm4
00007d248dbd201b  vmovaps [rsp+0x40], xmm5
00007d248dbd2021  vmovaps [rsp+0x50], xmm6
00007d248dbd2027  vmovaps [rsp+0x60], xmm7
00007d248dbd202d  vmovaps [rsp+0x70], xmm8
00007d248dbd2033  vmovaps [rsp+0x80], xmm9
00007d248dbd203c  vmovaps [rsp+0x90], xmm10
00007d248dbd2045  vmovaps [rsp+0xA0], xmm11
00007d248dbd204e  vmovaps [rsp+0xB0], xmm12
00007d248dbd2057  vmovaps [rsp+0xC0], xmm13
00007d248dbd2060  vmovaps [rsp+0xD0], xmm14
00007d248dbd2069  vmovaps [rsp+0xE0], xmm15
00007d248dbd2072  sub rsp, 0x30
00007d248dbd2076  movaps [rsp], xmm2
00007d248dbd207a  movaps [rsp+0x10], xmm1
00007d248dbd207f  movaps [rsp+0x20], xmm13
00007d248dbd2085  lea rdi, [rsp]
00007d248dbd2089  mov esi, 0x00
00007d248dbd208e  mov rax, 0x5BCEEF236530
00007d248dbd2098  call rax
00007d248dbd209a  movaps xmm2, [rsp]
00007d248dbd209e  add rsp, 0x30
00007d248dbd20a2  vmovaps xmm0, [rsp]
00007d248dbd20a7  vmovaps xmm1, [rsp+0x10]
00007d248dbd20ad  vmovaps xmm3, [rsp+0x20]
00007d248dbd20b3  vmovaps xmm4, [rsp+0x30]
00007d248dbd20b9  vmovaps xmm5, [rsp+0x40]
00007d248dbd20bf  vmovaps xmm6, [rsp+0x50]
00007d248dbd20c5  vmovaps xmm7, [rsp+0x60]
00007d248dbd20cb  vmovaps xmm8, [rsp+0x70]
00007d248dbd20d1  vmovaps xmm9, [rsp+0x80]
00007d248dbd20da  vmovaps xmm10, [rsp+0x90]
00007d248dbd20e3  vmovaps xmm11, [rsp+0xA0]
00007d248dbd20ec  vmovaps xmm12, [rsp+0xB0]
00007d248dbd20f5  vmovaps xmm13, [rsp+0xC0]
00007d248dbd20fe  vmovaps xmm14, [rsp+0xD0]
00007d248dbd2107  vmovaps xmm15, [rsp+0xE0]
00007d248dbd2110  add rsp, 0xF0
00007d248dbd2117  pop r11
00007d248dbd2119  pop r10
00007d248dbd211b  pop r9
00007d248dbd211d  pop r8
00007d248dbd211f  pop rsi
00007d248dbd2120  pop rdi
00007d248dbd2121  pop rdx
00007d248dbd2122  pop rcx
00007d248dbd2123  pop rax
00007d248dbd2124  add rsp, 0x08
00007d248dbd2128  jmp 0x00007D248DBCFBAB
00007d248dbd212d  call 0x00007D248D9FF430
00007d248dbd2132  jmp 0x00007D248DBCFBB8
00007d248dbd2137  sub rsp, 0x08
00007d248dbd213b  push rax
00007d248dbd213c  push rcx
00007d248dbd213d  push rdx
00007d248dbd213e  push rdi
00007d248dbd213f  push rsi
00007d248dbd2140  push r8
00007d248dbd2142  push r9
00007d248dbd2144  push r10
00007d248dbd2146  push r11
00007d248dbd2148  sub rsp, 0xF0
00007d248dbd214f  vmovaps [rsp], xmm0
00007d248dbd2154  vmovaps [rsp+0x10], xmm1
00007d248dbd215a  vmovaps [rsp+0x20], xmm2
00007d248dbd2160  vmovaps [rsp+0x30], xmm3
00007d248dbd2166  vmovaps [rsp+0x40], xmm4
00007d248dbd216c  vmovaps [rsp+0x50], xmm5
00007d248dbd2172  vmovaps [rsp+0x60], xmm6
00007d248dbd2178  vmovaps [rsp+0x70], xmm7
00007d248dbd217e  vmovaps [rsp+0x80], xmm8
00007d248dbd2187  vmovaps [rsp+0x90], xmm9
00007d248dbd2190  vmovaps [rsp+0xA0], xmm10
00007d248dbd2199  vmovaps [rsp+0xB0], xmm11
00007d248dbd21a2  vmovaps [rsp+0xC0], xmm12
00007d248dbd21ab  vmovaps [rsp+0xD0], xmm13
00007d248dbd21b4  vmovaps [rsp+0xE0], xmm14
00007d248dbd21bd  sub rsp, 0x30
00007d248dbd21c1  movaps [rsp], xmm15
00007d248dbd21c6  movaps [rsp+0x10], xmm13
00007d248dbd21cc  movaps [rsp+0x20], xmm1
00007d248dbd21d1  lea rdi, [rsp]
00007d248dbd21d5  mov esi, 0x00
00007d248dbd21da  mov rax, 0x5BCEEF236530
00007d248dbd21e4  call rax
00007d248dbd21e6  movaps xmm15, [rsp]
00007d248dbd21eb  add rsp, 0x30
00007d248dbd21ef  vmovaps xmm0, [rsp]
00007d248dbd21f4  vmovaps xmm1, [rsp+0x10]
00007d248dbd21fa  vmovaps xmm2, [rsp+0x20]
00007d248dbd2200  vmovaps xmm3, [rsp+0x30]
00007d248dbd2206  vmovaps xmm4, [rsp+0x40]
00007d248dbd220c  vmovaps xmm5, [rsp+0x50]
00007d248dbd2212  vmovaps xmm6, [rsp+0x60]
00007d248dbd2218  vmovaps xmm7, [rsp+0x70]
00007d248dbd221e  vmovaps xmm8, [rsp+0x80]
00007d248dbd2227  vmovaps xmm9, [rsp+0x90]
00007d248dbd2230  vmovaps xmm10, [rsp+0xA0]
00007d248dbd2239  vmovaps xmm11, [rsp+0xB0]
00007d248dbd2242  vmovaps xmm12, [rsp+0xC0]
00007d248dbd224b  vmovaps xmm13, [rsp+0xD0]
00007d248dbd2254  vmovaps xmm14, [rsp+0xE0]
00007d248dbd225d  add rsp, 0xF0
00007d248dbd2264  pop r11
00007d248dbd2266  pop r10
00007d248dbd2268  pop r9
00007d248dbd226a  pop r8
00007d248dbd226c  pop rsi
00007d248dbd226d  pop rdi
00007d248dbd226e  pop rdx
00007d248dbd226f  pop rcx
00007d248dbd2270  pop rax
00007d248dbd2271  add rsp, 0x08
00007d248dbd2275  jmp 0x00007D248DBCFBF7
00007d248dbd227a  sub rsp, 0x08
00007d248dbd227e  push rax
00007d248dbd227f  push rcx
00007d248dbd2280  push rdx
00007d248dbd2281  push rdi
00007d248dbd2282  push rsi
00007d248dbd2283  push r8
00007d248dbd2285  push r9
00007d248dbd2287  push r10
00007d248dbd2289  push r11
00007d248dbd228b  sub rsp, 0xF0
00007d248dbd2292  vmovaps [rsp], xmm0
00007d248dbd2297  vmovaps [rsp+0x10], xmm1
00007d248dbd229d  vmovaps [rsp+0x20], xmm2
00007d248dbd22a3  vmovaps [rsp+0x30], xmm3
00007d248dbd22a9  vmovaps [rsp+0x40], xmm4
00007d248dbd22af  vmovaps [rsp+0x50], xmm5
00007d248dbd22b5  vmovaps [rsp+0x60], xmm6
00007d248dbd22bb  vmovaps [rsp+0x70], xmm7
00007d248dbd22c1  vmovaps [rsp+0x80], xmm8
00007d248dbd22ca  vmovaps [rsp+0x90], xmm9
00007d248dbd22d3  vmovaps [rsp+0xA0], xmm10
00007d248dbd22dc  vmovaps [rsp+0xB0], xmm11
00007d248dbd22e5  vmovaps [rsp+0xC0], xmm12
00007d248dbd22ee  vmovaps [rsp+0xD0], xmm13
00007d248dbd22f7  vmovaps [rsp+0xE0], xmm15
00007d248dbd2300  sub rsp, 0x30
00007d248dbd2304  movaps [rsp], xmm14
00007d248dbd2309  movaps [rsp+0x10], xmm11
00007d248dbd230f  movaps [rsp+0x20], xmm1
00007d248dbd2314  lea rdi, [rsp]
00007d248dbd2318  mov esi, 0x00
00007d248dbd231d  mov rax, 0x5BCEEF236530
00007d248dbd2327  call rax
00007d248dbd2329  movaps xmm14, [rsp]
00007d248dbd232e  add rsp, 0x30
00007d248dbd2332  vmovaps xmm0, [rsp]
00007d248dbd2337  vmovaps xmm1, [rsp+0x10]
00007d248dbd233d  vmovaps xmm2, [rsp+0x20]
00007d248dbd2343  vmovaps xmm3, [rsp+0x30]
00007d248dbd2349  vmovaps xmm4, [rsp+0x40]
00007d248dbd234f  vmovaps xmm5, [rsp+0x50]
00007d248dbd2355  vmovaps xmm6, [rsp+0x60]
00007d248dbd235b  vmovaps xmm7, [rsp+0x70]
00007d248dbd2361  vmovaps xmm8, [rsp+0x80]
00007d248dbd236a  vmovaps xmm9, [rsp+0x90]
00007d248dbd2373  vmovaps xmm10, [rsp+0xA0]
00007d248dbd237c  vmovaps xmm11, [rsp+0xB0]
00007d248dbd2385  vmovaps xmm12, [rsp+0xC0]
00007d248dbd238e  vmovaps xmm13, [rsp+0xD0]
00007d248dbd2397  vmovaps xmm15, [rsp+0xE0]
00007d248dbd23a0  add rsp, 0xF0
00007d248dbd23a7  pop r11
00007d248dbd23a9  pop r10
00007d248dbd23ab  pop r9
00007d248dbd23ad  pop r8
00007d248dbd23af  pop rsi
00007d248dbd23b0  pop rdi
00007d248dbd23b1  pop rdx
00007d248dbd23b2  pop rcx
00007d248dbd23b3  pop rax
00007d248dbd23b4  add rsp, 0x08
00007d248dbd23b8  jmp 0x00007D248DBCFC21
00007d248dbd23bd  sub rsp, 0x08
00007d248dbd23c1  push rax
00007d248dbd23c2  push rcx
00007d248dbd23c3  push rdx
00007d248dbd23c4  push rdi
00007d248dbd23c5  push rsi
00007d248dbd23c6  push r8
00007d248dbd23c8  push r9
00007d248dbd23ca  push r10
00007d248dbd23cc  push r11
00007d248dbd23ce  sub rsp, 0xF0
00007d248dbd23d5  vmovaps [rsp], xmm0
00007d248dbd23da  vmovaps [rsp+0x10], xmm1
00007d248dbd23e0  vmovaps [rsp+0x20], xmm2
00007d248dbd23e6  vmovaps [rsp+0x30], xmm3
00007d248dbd23ec  vmovaps [rsp+0x40], xmm4
00007d248dbd23f2  vmovaps [rsp+0x50], xmm5
00007d248dbd23f8  vmovaps [rsp+0x60], xmm6
00007d248dbd23fe  vmovaps [rsp+0x70], xmm7
00007d248dbd2404  vmovaps [rsp+0x80], xmm8
00007d248dbd240d  vmovaps [rsp+0x90], xmm9
00007d248dbd2416  vmovaps [rsp+0xA0], xmm10
00007d248dbd241f  vmovaps [rsp+0xB0], xmm11
00007d248dbd2428  vmovaps [rsp+0xC0], xmm12
00007d248dbd2431  vmovaps [rsp+0xD0], xmm14
00007d248dbd243a  vmovaps [rsp+0xE0], xmm15
00007d248dbd2443  sub rsp, 0x30
00007d248dbd2447  movaps [rsp], xmm13
00007d248dbd244c  movaps [rsp+0x10], xmm11
00007d248dbd2452  movaps [rsp+0x20], xmm1
00007d248dbd2457  lea rdi, [rsp]
00007d248dbd245b  mov esi, 0x00
00007d248dbd2460  mov rax, 0x5BCEEF236530
00007d248dbd246a  call rax
00007d248dbd246c  movaps xmm13, [rsp]
00007d248dbd2471  add rsp, 0x30
00007d248dbd2475  vmovaps xmm0, [rsp]
00007d248dbd247a  vmovaps xmm1, [rsp+0x10]
00007d248dbd2480  vmovaps xmm2, [rsp+0x20]
00007d248dbd2486  vmovaps xmm3, [rsp+0x30]
00007d248dbd248c  vmovaps xmm4, [rsp+0x40]
00007d248dbd2492  vmovaps xmm5, [rsp+0x50]
00007d248dbd2498  vmovaps xmm6, [rsp+0x60]
00007d248dbd249e  vmovaps xmm7, [rsp+0x70]
00007d248dbd24a4  vmovaps xmm8, [rsp+0x80]
00007d248dbd24ad  vmovaps xmm9, [rsp+0x90]
00007d248dbd24b6  vmovaps xmm10, [rsp+0xA0]
00007d248dbd24bf  vmovaps xmm11, [rsp+0xB0]
00007d248dbd24c8  vmovaps xmm12, [rsp+0xC0]
00007d248dbd24d1  vmovaps xmm14, [rsp+0xD0]
00007d248dbd24da  vmovaps xmm15, [rsp+0xE0]
00007d248dbd24e3  add rsp, 0xF0
00007d248dbd24ea  pop r11
00007d248dbd24ec  pop r10
00007d248dbd24ee  pop r9
00007d248dbd24f0  pop r8
00007d248dbd24f2  pop rsi
00007d248dbd24f3  pop rdi
00007d248dbd24f4  pop rdx
00007d248dbd24f5  pop rcx
00007d248dbd24f6  pop rax
00007d248dbd24f7  add rsp, 0x08
00007d248dbd24fb  jmp 0x00007D248DBCFC76
00007d248dbd2500  call 0x00007D248D9FF430
00007d248dbd2505  jmp 0x00007D248DBCFC83
00007d248dbd250a  sub rsp, 0x08
00007d248dbd250e  push rax
00007d248dbd250f  push rcx
00007d248dbd2510  push rdx
00007d248dbd2511  push rdi
00007d248dbd2512  push rsi
00007d248dbd2513  push r8
00007d248dbd2515  push r9
00007d248dbd2517  push r10
00007d248dbd2519  push r11
00007d248dbd251b  sub rsp, 0xF0
00007d248dbd2522  vmovaps [rsp], xmm0
00007d248dbd2527  vmovaps [rsp+0x10], xmm1
00007d248dbd252d  vmovaps [rsp+0x20], xmm2
00007d248dbd2533  vmovaps [rsp+0x30], xmm3
00007d248dbd2539  vmovaps [rsp+0x40], xmm4
00007d248dbd253f  vmovaps [rsp+0x50], xmm5
00007d248dbd2545  vmovaps [rsp+0x60], xmm6
00007d248dbd254b  vmovaps [rsp+0x70], xmm7
00007d248dbd2551  vmovaps [rsp+0x80], xmm8
00007d248dbd255a  vmovaps [rsp+0x90], xmm9
00007d248dbd2563  vmovaps [rsp+0xA0], xmm10
00007d248dbd256c  vmovaps [rsp+0xB0], xmm11
00007d248dbd2575  vmovaps [rsp+0xC0], xmm12
00007d248dbd257e  vmovaps [rsp+0xD0], xmm13
00007d248dbd2587  vmovaps [rsp+0xE0], xmm14
00007d248dbd2590  sub rsp, 0x30
00007d248dbd2594  movaps [rsp], xmm15
00007d248dbd2599  movaps [rsp+0x10], xmm11
00007d248dbd259f  movaps [rsp+0x20], xmm1
00007d248dbd25a4  lea rdi, [rsp]
00007d248dbd25a8  mov esi, 0x00
00007d248dbd25ad  mov rax, 0x5BCEEF236530
00007d248dbd25b7  call rax
00007d248dbd25b9  movaps xmm15, [rsp]
00007d248dbd25be  add rsp, 0x30
00007d248dbd25c2  vmovaps xmm0, [rsp]
00007d248dbd25c7  vmovaps xmm1, [rsp+0x10]
00007d248dbd25cd  vmovaps xmm2, [rsp+0x20]
00007d248dbd25d3  vmovaps xmm3, [rsp+0x30]
00007d248dbd25d9  vmovaps xmm4, [rsp+0x40]
00007d248dbd25df  vmovaps xmm5, [rsp+0x50]
00007d248dbd25e5  vmovaps xmm6, [rsp+0x60]
00007d248dbd25eb  vmovaps xmm7, [rsp+0x70]
00007d248dbd25f1  vmovaps xmm8, [rsp+0x80]
00007d248dbd25fa  vmovaps xmm9, [rsp+0x90]
00007d248dbd2603  vmovaps xmm10, [rsp+0xA0]
00007d248dbd260c  vmovaps xmm11, [rsp+0xB0]
00007d248dbd2615  vmovaps xmm12, [rsp+0xC0]
00007d248dbd261e  vmovaps xmm13, [rsp+0xD0]
00007d248dbd2627  vmovaps xmm14, [rsp+0xE0]
00007d248dbd2630  add rsp, 0xF0
00007d248dbd2637  pop r11
00007d248dbd2639  pop r10
00007d248dbd263b  pop r9
00007d248dbd263d  pop r8
00007d248dbd263f  pop rsi
00007d248dbd2640  pop rdi
00007d248dbd2641  pop rdx
00007d248dbd2642  pop rcx
00007d248dbd2643  pop rax
00007d248dbd2644  add rsp, 0x08
00007d248dbd2648  jmp 0x00007D248DBCFCBC
00007d248dbd264d  sub rsp, 0x08
00007d248dbd2651  push rax
00007d248dbd2652  push rcx
00007d248dbd2653  push rdx
00007d248dbd2654  push rdi
00007d248dbd2655  push rsi
00007d248dbd2656  push r8
00007d248dbd2658  push r9
00007d248dbd265a  push r10
00007d248dbd265c  push r11
00007d248dbd265e  sub rsp, 0xF0
00007d248dbd2665  vmovaps [rsp], xmm0
00007d248dbd266a  vmovaps [rsp+0x10], xmm1
00007d248dbd2670  vmovaps [rsp+0x20], xmm2
00007d248dbd2676  vmovaps [rsp+0x30], xmm3
00007d248dbd267c  vmovaps [rsp+0x40], xmm4
00007d248dbd2682  vmovaps [rsp+0x50], xmm5
00007d248dbd2688  vmovaps [rsp+0x60], xmm6
00007d248dbd268e  vmovaps [rsp+0x70], xmm7
00007d248dbd2694  vmovaps [rsp+0x80], xmm8
00007d248dbd269d  vmovaps [rsp+0x90], xmm9
00007d248dbd26a6  vmovaps [rsp+0xA0], xmm10
00007d248dbd26af  vmovaps [rsp+0xB0], xmm12
00007d248dbd26b8  vmovaps [rsp+0xC0], xmm13
00007d248dbd26c1  vmovaps [rsp+0xD0], xmm14
00007d248dbd26ca  vmovaps [rsp+0xE0], xmm15
00007d248dbd26d3  sub rsp, 0x30
00007d248dbd26d7  movaps [rsp], xmm11
00007d248dbd26dc  movaps [rsp+0x10], xmm6
00007d248dbd26e1  movaps [rsp+0x20], xmm14
00007d248dbd26e7  lea rdi, [rsp]
00007d248dbd26eb  mov esi, 0x00
00007d248dbd26f0  mov rax, 0x5BCEEF236530
00007d248dbd26fa  call rax
00007d248dbd26fc  movaps xmm11, [rsp]
00007d248dbd2701  add rsp, 0x30
00007d248dbd2705  vmovaps xmm0, [rsp]
00007d248dbd270a  vmovaps xmm1, [rsp+0x10]
00007d248dbd2710  vmovaps xmm2, [rsp+0x20]
00007d248dbd2716  vmovaps xmm3, [rsp+0x30]
00007d248dbd271c  vmovaps xmm4, [rsp+0x40]
00007d248dbd2722  vmovaps xmm5, [rsp+0x50]
00007d248dbd2728  vmovaps xmm6, [rsp+0x60]
00007d248dbd272e  vmovaps xmm7, [rsp+0x70]
00007d248dbd2734  vmovaps xmm8, [rsp+0x80]
00007d248dbd273d  vmovaps xmm9, [rsp+0x90]
00007d248dbd2746  vmovaps xmm10, [rsp+0xA0]
00007d248dbd274f  vmovaps xmm12, [rsp+0xB0]
00007d248dbd2758  vmovaps xmm13, [rsp+0xC0]
00007d248dbd2761  vmovaps xmm14, [rsp+0xD0]
00007d248dbd276a  vmovaps xmm15, [rsp+0xE0]
00007d248dbd2773  add rsp, 0xF0
00007d248dbd277a  pop r11
00007d248dbd277c  pop r10
00007d248dbd277e  pop r9
00007d248dbd2780  pop r8
00007d248dbd2782  pop rsi
00007d248dbd2783  pop rdi
00007d248dbd2784  pop rdx
00007d248dbd2785  pop rcx
00007d248dbd2786  pop rax
00007d248dbd2787  add rsp, 0x08
00007d248dbd278b  jmp 0x00007D248DBCFD34
00007d248dbd2790  call 0x00007D248D9FF430
00007d248dbd2795  jmp 0x00007D248DBCFD3E
00007d248dbd279a  sub rsp, 0x08
00007d248dbd279e  push rax
00007d248dbd279f  push rcx
00007d248dbd27a0  push rdx
00007d248dbd27a1  push rdi
00007d248dbd27a2  push rsi
00007d248dbd27a3  push r8
00007d248dbd27a5  push r9
00007d248dbd27a7  push r10
00007d248dbd27a9  push r11
00007d248dbd27ab  sub rsp, 0xF0
00007d248dbd27b2  vmovaps [rsp], xmm0
00007d248dbd27b7  vmovaps [rsp+0x10], xmm1
00007d248dbd27bd  vmovaps [rsp+0x20], xmm2
00007d248dbd27c3  vmovaps [rsp+0x30], xmm3
00007d248dbd27c9  vmovaps [rsp+0x40], xmm4
00007d248dbd27cf  vmovaps [rsp+0x50], xmm5
00007d248dbd27d5  vmovaps [rsp+0x60], xmm6
00007d248dbd27db  vmovaps [rsp+0x70], xmm7
00007d248dbd27e1  vmovaps [rsp+0x80], xmm8
00007d248dbd27ea  vmovaps [rsp+0x90], xmm9
00007d248dbd27f3  vmovaps [rsp+0xA0], xmm10
00007d248dbd27fc  vmovaps [rsp+0xB0], xmm11
00007d248dbd2805  vmovaps [rsp+0xC0], xmm12
00007d248dbd280e  vmovaps [rsp+0xD0], xmm13
00007d248dbd2817  vmovaps [rsp+0xE0], xmm15
00007d248dbd2820  sub rsp, 0x30
00007d248dbd2824  movaps [rsp], xmm14
00007d248dbd2829  movaps [rsp+0x10], xmm6
00007d248dbd282e  movaps [rsp+0x20], xmm2
00007d248dbd2833  lea rdi, [rsp]
00007d248dbd2837  mov esi, 0x00
00007d248dbd283c  mov rax, 0x5BCEEF236530
00007d248dbd2846  call rax
00007d248dbd2848  movaps xmm14, [rsp]
00007d248dbd284d  add rsp, 0x30
00007d248dbd2851  vmovaps xmm0, [rsp]
00007d248dbd2856  vmovaps xmm1, [rsp+0x10]
00007d248dbd285c  vmovaps xmm2, [rsp+0x20]
00007d248dbd2862  vmovaps xmm3, [rsp+0x30]
00007d248dbd2868  vmovaps xmm4, [rsp+0x40]
00007d248dbd286e  vmovaps xmm5, [rsp+0x50]
00007d248dbd2874  vmovaps xmm6, [rsp+0x60]
00007d248dbd287a  vmovaps xmm7, [rsp+0x70]
00007d248dbd2880  vmovaps xmm8, [rsp+0x80]
00007d248dbd2889  vmovaps xmm9, [rsp+0x90]
00007d248dbd2892  vmovaps xmm10, [rsp+0xA0]
00007d248dbd289b  vmovaps xmm11, [rsp+0xB0]
00007d248dbd28a4  vmovaps xmm12, [rsp+0xC0]
00007d248dbd28ad  vmovaps xmm13, [rsp+0xD0]
00007d248dbd28b6  vmovaps xmm15, [rsp+0xE0]
00007d248dbd28bf  add rsp, 0xF0
00007d248dbd28c6  pop r11
00007d248dbd28c8  pop r10
00007d248dbd28ca  pop r9
00007d248dbd28cc  pop r8
00007d248dbd28ce  pop rsi
00007d248dbd28cf  pop rdi
00007d248dbd28d0  pop rdx
00007d248dbd28d1  pop rcx
00007d248dbd28d2  pop rax
00007d248dbd28d3  add rsp, 0x08
00007d248dbd28d7  jmp 0x00007D248DBCFD72
00007d248dbd28dc  sub rsp, 0x08
00007d248dbd28e0  push rax
00007d248dbd28e1  push rcx
00007d248dbd28e2  push rdx
00007d248dbd28e3  push rdi
00007d248dbd28e4  push rsi
00007d248dbd28e5  push r8
00007d248dbd28e7  push r9
00007d248dbd28e9  push r10
00007d248dbd28eb  push r11
00007d248dbd28ed  sub rsp, 0xF0
00007d248dbd28f4  vmovaps [rsp], xmm0
00007d248dbd28f9  vmovaps [rsp+0x10], xmm1
00007d248dbd28ff  vmovaps [rsp+0x20], xmm2
00007d248dbd2905  vmovaps [rsp+0x30], xmm3
00007d248dbd290b  vmovaps [rsp+0x40], xmm4
00007d248dbd2911  vmovaps [rsp+0x50], xmm5
00007d248dbd2917  vmovaps [rsp+0x60], xmm7
00007d248dbd291d  vmovaps [rsp+0x70], xmm8
00007d248dbd2923  vmovaps [rsp+0x80], xmm9
00007d248dbd292c  vmovaps [rsp+0x90], xmm10
00007d248dbd2935  vmovaps [rsp+0xA0], xmm11
00007d248dbd293e  vmovaps [rsp+0xB0], xmm12
00007d248dbd2947  vmovaps [rsp+0xC0], xmm13
00007d248dbd2950  vmovaps [rsp+0xD0], xmm14
00007d248dbd2959  vmovaps [rsp+0xE0], xmm15
00007d248dbd2962  sub rsp, 0x30
00007d248dbd2966  movaps [rsp], xmm6
00007d248dbd296a  movaps [rsp+0x10], xmm5
00007d248dbd296f  movaps [rsp+0x20], xmm1
00007d248dbd2974  lea rdi, [rsp]
00007d248dbd2978  mov esi, 0x00
00007d248dbd297d  mov rax, 0x5BCEEF236530
00007d248dbd2987  call rax
00007d248dbd2989  movaps xmm6, [rsp]
00007d248dbd298d  add rsp, 0x30
00007d248dbd2991  vmovaps xmm0, [rsp]
00007d248dbd2996  vmovaps xmm1, [rsp+0x10]
00007d248dbd299c  vmovaps xmm2, [rsp+0x20]
00007d248dbd29a2  vmovaps xmm3, [rsp+0x30]
00007d248dbd29a8  vmovaps xmm4, [rsp+0x40]
00007d248dbd29ae  vmovaps xmm5, [rsp+0x50]
00007d248dbd29b4  vmovaps xmm7, [rsp+0x60]
00007d248dbd29ba  vmovaps xmm8, [rsp+0x70]
00007d248dbd29c0  vmovaps xmm9, [rsp+0x80]
00007d248dbd29c9  vmovaps xmm10, [rsp+0x90]
00007d248dbd29d2  vmovaps xmm11, [rsp+0xA0]
00007d248dbd29db  vmovaps xmm12, [rsp+0xB0]
00007d248dbd29e4  vmovaps xmm13, [rsp+0xC0]
00007d248dbd29ed  vmovaps xmm14, [rsp+0xD0]
00007d248dbd29f6  vmovaps xmm15, [rsp+0xE0]
00007d248dbd29ff  add rsp, 0xF0
00007d248dbd2a06  pop r11
00007d248dbd2a08  pop r10
00007d248dbd2a0a  pop r9
00007d248dbd2a0c  pop r8
00007d248dbd2a0e  pop rsi
00007d248dbd2a0f  pop rdi
00007d248dbd2a10  pop rdx
00007d248dbd2a11  pop rcx
00007d248dbd2a12  pop rax
00007d248dbd2a13  add rsp, 0x08
00007d248dbd2a17  jmp 0x00007D248DBCFD98
00007d248dbd2a1c  sub rsp, 0x08
00007d248dbd2a20  push rax
00007d248dbd2a21  push rcx
00007d248dbd2a22  push rdx
00007d248dbd2a23  push rdi
00007d248dbd2a24  push rsi
00007d248dbd2a25  push r8
00007d248dbd2a27  push r9
00007d248dbd2a29  push r10
00007d248dbd2a2b  push r11
00007d248dbd2a2d  sub rsp, 0xF0
00007d248dbd2a34  vmovaps [rsp], xmm0
00007d248dbd2a39  vmovaps [rsp+0x10], xmm2
00007d248dbd2a3f  vmovaps [rsp+0x20], xmm3
00007d248dbd2a45  vmovaps [rsp+0x30], xmm4
00007d248dbd2a4b  vmovaps [rsp+0x40], xmm5
00007d248dbd2a51  vmovaps [rsp+0x50], xmm6
00007d248dbd2a57  vmovaps [rsp+0x60], xmm7
00007d248dbd2a5d  vmovaps [rsp+0x70], xmm8
00007d248dbd2a63  vmovaps [rsp+0x80], xmm9
00007d248dbd2a6c  vmovaps [rsp+0x90], xmm10
00007d248dbd2a75  vmovaps [rsp+0xA0], xmm11
00007d248dbd2a7e  vmovaps [rsp+0xB0], xmm12
00007d248dbd2a87  vmovaps [rsp+0xC0], xmm13
00007d248dbd2a90  vmovaps [rsp+0xD0], xmm14
00007d248dbd2a99  vmovaps [rsp+0xE0], xmm15
00007d248dbd2aa2  sub rsp, 0x30
00007d248dbd2aa6  movaps [rsp], xmm1
00007d248dbd2aaa  movaps [rsp+0x10], xmm5
00007d248dbd2aaf  movaps [rsp+0x20], xmm13
00007d248dbd2ab5  lea rdi, [rsp]
00007d248dbd2ab9  mov esi, 0x00
00007d248dbd2abe  mov rax, 0x5BCEEF236530
00007d248dbd2ac8  call rax
00007d248dbd2aca  movaps xmm1, [rsp]
00007d248dbd2ace  add rsp, 0x30
00007d248dbd2ad2  vmovaps xmm0, [rsp]
00007d248dbd2ad7  vmovaps xmm2, [rsp+0x10]
00007d248dbd2add  vmovaps xmm3, [rsp+0x20]
00007d248dbd2ae3  vmovaps xmm4, [rsp+0x30]
00007d248dbd2ae9  vmovaps xmm5, [rsp+0x40]
00007d248dbd2aef  vmovaps xmm6, [rsp+0x50]
00007d248dbd2af5  vmovaps xmm7, [rsp+0x60]
00007d248dbd2afb  vmovaps xmm8, [rsp+0x70]
00007d248dbd2b01  vmovaps xmm9, [rsp+0x80]
00007d248dbd2b0a  vmovaps xmm10, [rsp+0x90]
00007d248dbd2b13  vmovaps xmm11, [rsp+0xA0]
00007d248dbd2b1c  vmovaps xmm12, [rsp+0xB0]
00007d248dbd2b25  vmovaps xmm13, [rsp+0xC0]
00007d248dbd2b2e  vmovaps xmm14, [rsp+0xD0]
00007d248dbd2b37  vmovaps xmm15, [rsp+0xE0]
00007d248dbd2b40  add rsp, 0xF0
00007d248dbd2b47  pop r11
00007d248dbd2b49  pop r10
00007d248dbd2b4b  pop r9
00007d248dbd2b4d  pop r8
00007d248dbd2b4f  pop rsi
00007d248dbd2b50  pop rdi
00007d248dbd2b51  pop rdx
00007d248dbd2b52  pop rcx
00007d248dbd2b53  pop rax
00007d248dbd2b54  add rsp, 0x08
00007d248dbd2b58  jmp 0x00007D248DBCFDB6
00007d248dbd2b5d  sub rsp, 0x08
00007d248dbd2b61  push rax
00007d248dbd2b62  push rcx
00007d248dbd2b63  push rdx
00007d248dbd2b64  push rdi
00007d248dbd2b65  push rsi
00007d248dbd2b66  push r8
00007d248dbd2b68  push r9
00007d248dbd2b6a  push r10
00007d248dbd2b6c  push r11
00007d248dbd2b6e  sub rsp, 0xF0
00007d248dbd2b75  vmovaps [rsp], xmm0
00007d248dbd2b7a  vmovaps [rsp+0x10], xmm1
00007d248dbd2b80  vmovaps [rsp+0x20], xmm2
00007d248dbd2b86  vmovaps [rsp+0x30], xmm3
00007d248dbd2b8c  vmovaps [rsp+0x40], xmm4
00007d248dbd2b92  vmovaps [rsp+0x50], xmm6
00007d248dbd2b98  vmovaps [rsp+0x60], xmm7
00007d248dbd2b9e  vmovaps [rsp+0x70], xmm8
00007d248dbd2ba4  vmovaps [rsp+0x80], xmm9
00007d248dbd2bad  vmovaps [rsp+0x90], xmm10
00007d248dbd2bb6  vmovaps [rsp+0xA0], xmm11
00007d248dbd2bbf  vmovaps [rsp+0xB0], xmm12
00007d248dbd2bc8  vmovaps [rsp+0xC0], xmm13
00007d248dbd2bd1  vmovaps [rsp+0xD0], xmm14
00007d248dbd2bda  vmovaps [rsp+0xE0], xmm15
00007d248dbd2be3  sub rsp, 0x30
00007d248dbd2be7  movaps [rsp], xmm5
00007d248dbd2beb  movaps [rsp+0x10], xmm2
00007d248dbd2bf0  movaps [rsp+0x20], xmm13
00007d248dbd2bf6  lea rdi, [rsp]
00007d248dbd2bfa  mov esi, 0x00
00007d248dbd2bff  mov rax, 0x5BCEEF236530
00007d248dbd2c09  call rax
00007d248dbd2c0b  movaps xmm5, [rsp]
00007d248dbd2c0f  add rsp, 0x30
00007d248dbd2c13  vmovaps xmm0, [rsp]
00007d248dbd2c18  vmovaps xmm1, [rsp+0x10]
00007d248dbd2c1e  vmovaps xmm2, [rsp+0x20]
00007d248dbd2c24  vmovaps xmm3, [rsp+0x30]
00007d248dbd2c2a  vmovaps xmm4, [rsp+0x40]
00007d248dbd2c30  vmovaps xmm6, [rsp+0x50]
00007d248dbd2c36  vmovaps xmm7, [rsp+0x60]
00007d248dbd2c3c  vmovaps xmm8, [rsp+0x70]
00007d248dbd2c42  vmovaps xmm9, [rsp+0x80]
00007d248dbd2c4b  vmovaps xmm10, [rsp+0x90]
00007d248dbd2c54  vmovaps xmm11, [rsp+0xA0]
00007d248dbd2c5d  vmovaps xmm12, [rsp+0xB0]
00007d248dbd2c66  vmovaps xmm13, [rsp+0xC0]
00007d248dbd2c6f  vmovaps xmm14, [rsp+0xD0]
00007d248dbd2c78  vmovaps xmm15, [rsp+0xE0]
00007d248dbd2c81  add rsp, 0xF0
00007d248dbd2c88  pop r11
00007d248dbd2c8a  pop r10
00007d248dbd2c8c  pop r9
00007d248dbd2c8e  pop r8
00007d248dbd2c90  pop rsi
00007d248dbd2c91  pop rdi
00007d248dbd2c92  pop rdx
00007d248dbd2c93  pop rcx
00007d248dbd2c94  pop rax
00007d248dbd2c95  add rsp, 0x08
00007d248dbd2c99  jmp 0x00007D248DBCFDEC
00007d248dbd2c9e  sub rsp, 0x08
00007d248dbd2ca2  push rax
00007d248dbd2ca3  push rcx
00007d248dbd2ca4  push rdx
00007d248dbd2ca5  push rdi
00007d248dbd2ca6  push rsi
00007d248dbd2ca7  push r8
00007d248dbd2ca9  push r9
00007d248dbd2cab  push r10
00007d248dbd2cad  push r11
00007d248dbd2caf  sub rsp, 0xF0
00007d248dbd2cb6  vmovaps [rsp], xmm0
00007d248dbd2cbb  vmovaps [rsp+0x10], xmm1
00007d248dbd2cc1  vmovaps [rsp+0x20], xmm2
00007d248dbd2cc7  vmovaps [rsp+0x30], xmm3
00007d248dbd2ccd  vmovaps [rsp+0x40], xmm4
00007d248dbd2cd3  vmovaps [rsp+0x50], xmm5
00007d248dbd2cd9  vmovaps [rsp+0x60], xmm6
00007d248dbd2cdf  vmovaps [rsp+0x70], xmm7
00007d248dbd2ce5  vmovaps [rsp+0x80], xmm8
00007d248dbd2cee  vmovaps [rsp+0x90], xmm9
00007d248dbd2cf7  vmovaps [rsp+0xA0], xmm10
00007d248dbd2d00  vmovaps [rsp+0xB0], xmm11
00007d248dbd2d09  vmovaps [rsp+0xC0], xmm12
00007d248dbd2d12  vmovaps [rsp+0xD0], xmm14
00007d248dbd2d1b  vmovaps [rsp+0xE0], xmm15
00007d248dbd2d24  sub rsp, 0x30
00007d248dbd2d28  movaps [rsp], xmm13
00007d248dbd2d2d  movaps [rsp+0x10], xmm10
00007d248dbd2d33  movaps [rsp+0x20], xmm1
00007d248dbd2d38  lea rdi, [rsp]
00007d248dbd2d3c  mov esi, 0x00
00007d248dbd2d41  mov rax, 0x5BCEEF236530
00007d248dbd2d4b  call rax
00007d248dbd2d4d  movaps xmm13, [rsp]
00007d248dbd2d52  add rsp, 0x30
00007d248dbd2d56  vmovaps xmm0, [rsp]
00007d248dbd2d5b  vmovaps xmm1, [rsp+0x10]
00007d248dbd2d61  vmovaps xmm2, [rsp+0x20]
00007d248dbd2d67  vmovaps xmm3, [rsp+0x30]
00007d248dbd2d6d  vmovaps xmm4, [rsp+0x40]
00007d248dbd2d73  vmovaps xmm5, [rsp+0x50]
00007d248dbd2d79  vmovaps xmm6, [rsp+0x60]
00007d248dbd2d7f  vmovaps xmm7, [rsp+0x70]
00007d248dbd2d85  vmovaps xmm8, [rsp+0x80]
00007d248dbd2d8e  vmovaps xmm9, [rsp+0x90]
00007d248dbd2d97  vmovaps xmm10, [rsp+0xA0]
00007d248dbd2da0  vmovaps xmm11, [rsp+0xB0]
00007d248dbd2da9  vmovaps xmm12, [rsp+0xC0]
00007d248dbd2db2  vmovaps xmm14, [rsp+0xD0]
00007d248dbd2dbb  vmovaps xmm15, [rsp+0xE0]
00007d248dbd2dc4  add rsp, 0xF0
00007d248dbd2dcb  pop r11
00007d248dbd2dcd  pop r10
00007d248dbd2dcf  pop r9
00007d248dbd2dd1  pop r8
00007d248dbd2dd3  pop rsi
00007d248dbd2dd4  pop rdi
00007d248dbd2dd5  pop rdx
00007d248dbd2dd6  pop rcx
00007d248dbd2dd7  pop rax
00007d248dbd2dd8  add rsp, 0x08
00007d248dbd2ddc  jmp 0x00007D248DBCFE15
00007d248dbd2de1  sub rsp, 0x08
00007d248dbd2de5  push rax
00007d248dbd2de6  push rcx
00007d248dbd2de7  push rdx
00007d248dbd2de8  push rdi
00007d248dbd2de9  push rsi
00007d248dbd2dea  push r8
00007d248dbd2dec  push r9
00007d248dbd2dee  push r10
00007d248dbd2df0  push r11
00007d248dbd2df2  sub rsp, 0xF0
00007d248dbd2df9  vmovaps [rsp], xmm0
00007d248dbd2dfe  vmovaps [rsp+0x10], xmm2
00007d248dbd2e04  vmovaps [rsp+0x20], xmm3
00007d248dbd2e0a  vmovaps [rsp+0x30], xmm4
00007d248dbd2e10  vmovaps [rsp+0x40], xmm5
00007d248dbd2e16  vmovaps [rsp+0x50], xmm6
00007d248dbd2e1c  vmovaps [rsp+0x60], xmm7
00007d248dbd2e22  vmovaps [rsp+0x70], xmm8
00007d248dbd2e28  vmovaps [rsp+0x80], xmm9
00007d248dbd2e31  vmovaps [rsp+0x90], xmm10
00007d248dbd2e3a  vmovaps [rsp+0xA0], xmm11
00007d248dbd2e43  vmovaps [rsp+0xB0], xmm12
00007d248dbd2e4c  vmovaps [rsp+0xC0], xmm13
00007d248dbd2e55  vmovaps [rsp+0xD0], xmm14
00007d248dbd2e5e  vmovaps [rsp+0xE0], xmm15
00007d248dbd2e67  sub rsp, 0x30
00007d248dbd2e6b  movaps [rsp], xmm1
00007d248dbd2e6f  movaps [rsp+0x10], xmm15
00007d248dbd2e75  movaps [rsp+0x20], xmm10
00007d248dbd2e7b  lea rdi, [rsp]
00007d248dbd2e7f  mov esi, 0x00
00007d248dbd2e84  mov rax, 0x5BCEEF236530
00007d248dbd2e8e  call rax
00007d248dbd2e90  movaps xmm1, [rsp]
00007d248dbd2e94  add rsp, 0x30
00007d248dbd2e98  vmovaps xmm0, [rsp]
00007d248dbd2e9d  vmovaps xmm2, [rsp+0x10]
00007d248dbd2ea3  vmovaps xmm3, [rsp+0x20]
00007d248dbd2ea9  vmovaps xmm4, [rsp+0x30]
00007d248dbd2eaf  vmovaps xmm5, [rsp+0x40]
00007d248dbd2eb5  vmovaps xmm6, [rsp+0x50]
00007d248dbd2ebb  vmovaps xmm7, [rsp+0x60]
00007d248dbd2ec1  vmovaps xmm8, [rsp+0x70]
00007d248dbd2ec7  vmovaps xmm9, [rsp+0x80]
00007d248dbd2ed0  vmovaps xmm10, [rsp+0x90]
00007d248dbd2ed9  vmovaps xmm11, [rsp+0xA0]
00007d248dbd2ee2  vmovaps xmm12, [rsp+0xB0]
00007d248dbd2eeb  vmovaps xmm13, [rsp+0xC0]
00007d248dbd2ef4  vmovaps xmm14, [rsp+0xD0]
00007d248dbd2efd  vmovaps xmm15, [rsp+0xE0]
00007d248dbd2f06  add rsp, 0xF0
00007d248dbd2f0d  pop r11
00007d248dbd2f0f  pop r10
00007d248dbd2f11  pop r9
00007d248dbd2f13  pop r8
00007d248dbd2f15  pop rsi
00007d248dbd2f16  pop rdi
00007d248dbd2f17  pop rdx
00007d248dbd2f18  pop rcx
00007d248dbd2f19  pop rax
00007d248dbd2f1a  add rsp, 0x08
00007d248dbd2f1e  jmp 0x00007D248DBCFE34
00007d248dbd2f23  sub rsp, 0x08
00007d248dbd2f27  push rax
00007d248dbd2f28  push rcx
00007d248dbd2f29  push rdx
00007d248dbd2f2a  push rdi
00007d248dbd2f2b  push rsi
00007d248dbd2f2c  push r8
00007d248dbd2f2e  push r9
00007d248dbd2f30  push r10
00007d248dbd2f32  push r11
00007d248dbd2f34  sub rsp, 0xF0
00007d248dbd2f3b  vmovaps [rsp], xmm0
00007d248dbd2f40  vmovaps [rsp+0x10], xmm1
00007d248dbd2f46  vmovaps [rsp+0x20], xmm2
00007d248dbd2f4c  vmovaps [rsp+0x30], xmm3
00007d248dbd2f52  vmovaps [rsp+0x40], xmm4
00007d248dbd2f58  vmovaps [rsp+0x50], xmm5
00007d248dbd2f5e  vmovaps [rsp+0x60], xmm6
00007d248dbd2f64  vmovaps [rsp+0x70], xmm7
00007d248dbd2f6a  vmovaps [rsp+0x80], xmm8
00007d248dbd2f73  vmovaps [rsp+0x90], xmm9
00007d248dbd2f7c  vmovaps [rsp+0xA0], xmm10
00007d248dbd2f85  vmovaps [rsp+0xB0], xmm11
00007d248dbd2f8e  vmovaps [rsp+0xC0], xmm12
00007d248dbd2f97  vmovaps [rsp+0xD0], xmm13
00007d248dbd2fa0  vmovaps [rsp+0xE0], xmm14
00007d248dbd2fa9  sub rsp, 0x30
00007d248dbd2fad  movaps [rsp], xmm15
00007d248dbd2fb2  movaps [rsp+0x10], xmm10
00007d248dbd2fb8  movaps [rsp+0x20], xmm11
00007d248dbd2fbe  lea rdi, [rsp]
00007d248dbd2fc2  mov esi, 0x00
00007d248dbd2fc7  mov rax, 0x5BCEEF236530
00007d248dbd2fd1  call rax
00007d248dbd2fd3  movaps xmm15, [rsp]
00007d248dbd2fd8  add rsp, 0x30
00007d248dbd2fdc  vmovaps xmm0, [rsp]
00007d248dbd2fe1  vmovaps xmm1, [rsp+0x10]
00007d248dbd2fe7  vmovaps xmm2, [rsp+0x20]
00007d248dbd2fed  vmovaps xmm3, [rsp+0x30]
00007d248dbd2ff3  vmovaps xmm4, [rsp+0x40]
00007d248dbd2ff9  vmovaps xmm5, [rsp+0x50]
00007d248dbd2fff  vmovaps xmm6, [rsp+0x60]
00007d248dbd3005  vmovaps xmm7, [rsp+0x70]
00007d248dbd300b  vmovaps xmm8, [rsp+0x80]
00007d248dbd3014  vmovaps xmm9, [rsp+0x90]
00007d248dbd301d  vmovaps xmm10, [rsp+0xA0]
00007d248dbd3026  vmovaps xmm11, [rsp+0xB0]
00007d248dbd302f  vmovaps xmm12, [rsp+0xC0]
00007d248dbd3038  vmovaps xmm13, [rsp+0xD0]
00007d248dbd3041  vmovaps xmm14, [rsp+0xE0]
00007d248dbd304a  add rsp, 0xF0
00007d248dbd3051  pop r11
00007d248dbd3053  pop r10
00007d248dbd3055  pop r9
00007d248dbd3057  pop r8
00007d248dbd3059  pop rsi
00007d248dbd305a  pop rdi
00007d248dbd305b  pop rdx
00007d248dbd305c  pop rcx
00007d248dbd305d  pop rax
00007d248dbd305e  add rsp, 0x08
00007d248dbd3062  jmp 0x00007D248DBCFE57
00007d248dbd3067  sub rsp, 0x08
00007d248dbd306b  push rax
00007d248dbd306c  push rcx
00007d248dbd306d  push rdx
00007d248dbd306e  push rdi
00007d248dbd306f  push rsi
00007d248dbd3070  push r8
00007d248dbd3072  push r9
00007d248dbd3074  push r10
00007d248dbd3076  push r11
00007d248dbd3078  sub rsp, 0xF0
00007d248dbd307f  vmovaps [rsp], xmm0
00007d248dbd3084  vmovaps [rsp+0x10], xmm1
00007d248dbd308a  vmovaps [rsp+0x20], xmm2
00007d248dbd3090  vmovaps [rsp+0x30], xmm3
00007d248dbd3096  vmovaps [rsp+0x40], xmm4
00007d248dbd309c  vmovaps [rsp+0x50], xmm5
00007d248dbd30a2  vmovaps [rsp+0x60], xmm6
00007d248dbd30a8  vmovaps [rsp+0x70], xmm7
00007d248dbd30ae  vmovaps [rsp+0x80], xmm8
00007d248dbd30b7  vmovaps [rsp+0x90], xmm9
00007d248dbd30c0  vmovaps [rsp+0xA0], xmm11
00007d248dbd30c9  vmovaps [rsp+0xB0], xmm12
00007d248dbd30d2  vmovaps [rsp+0xC0], xmm13
00007d248dbd30db  vmovaps [rsp+0xD0], xmm14
00007d248dbd30e4  vmovaps [rsp+0xE0], xmm15
00007d248dbd30ed  sub rsp, 0x30
00007d248dbd30f1  movaps [rsp], xmm10
00007d248dbd30f6  movaps [rsp+0x10], xmm12
00007d248dbd30fc  movaps [rsp+0x20], xmm11
00007d248dbd3102  lea rdi, [rsp]
00007d248dbd3106  mov esi, 0x00
00007d248dbd310b  mov rax, 0x5BCEEF236530
00007d248dbd3115  call rax
00007d248dbd3117  movaps xmm10, [rsp]
00007d248dbd311c  add rsp, 0x30
00007d248dbd3120  vmovaps xmm0, [rsp]
00007d248dbd3125  vmovaps xmm1, [rsp+0x10]
00007d248dbd312b  vmovaps xmm2, [rsp+0x20]
00007d248dbd3131  vmovaps xmm3, [rsp+0x30]
00007d248dbd3137  vmovaps xmm4, [rsp+0x40]
00007d248dbd313d  vmovaps xmm5, [rsp+0x50]
00007d248dbd3143  vmovaps xmm6, [rsp+0x60]
00007d248dbd3149  vmovaps xmm7, [rsp+0x70]
00007d248dbd314f  vmovaps xmm8, [rsp+0x80]
00007d248dbd3158  vmovaps xmm9, [rsp+0x90]
00007d248dbd3161  vmovaps xmm11, [rsp+0xA0]
00007d248dbd316a  vmovaps xmm12, [rsp+0xB0]
00007d248dbd3173  vmovaps xmm13, [rsp+0xC0]
00007d248dbd317c  vmovaps xmm14, [rsp+0xD0]
00007d248dbd3185  vmovaps xmm15, [rsp+0xE0]
00007d248dbd318e  add rsp, 0xF0
00007d248dbd3195  pop r11
00007d248dbd3197  pop r10
00007d248dbd3199  pop r9
00007d248dbd319b  pop r8
00007d248dbd319d  pop rsi
00007d248dbd319e  pop rdi
00007d248dbd319f  pop rdx
00007d248dbd31a0  pop rcx
00007d248dbd31a1  pop rax
00007d248dbd31a2  add rsp, 0x08
00007d248dbd31a6  jmp 0x00007D248DBCFE80
00007d248dbd31ab  sub rsp, 0x08
00007d248dbd31af  push rax
00007d248dbd31b0  push rcx
00007d248dbd31b1  push rdx
00007d248dbd31b2  push rdi
00007d248dbd31b3  push rsi
00007d248dbd31b4  push r8
00007d248dbd31b6  push r9
00007d248dbd31b8  push r10
00007d248dbd31ba  push r11
00007d248dbd31bc  sub rsp, 0xF0
00007d248dbd31c3  vmovaps [rsp], xmm0
00007d248dbd31c8  vmovaps [rsp+0x10], xmm1
00007d248dbd31ce  vmovaps [rsp+0x20], xmm2
00007d248dbd31d4  vmovaps [rsp+0x30], xmm3
00007d248dbd31da  vmovaps [rsp+0x40], xmm4
00007d248dbd31e0  vmovaps [rsp+0x50], xmm5
00007d248dbd31e6  vmovaps [rsp+0x60], xmm6
00007d248dbd31ec  vmovaps [rsp+0x70], xmm7
00007d248dbd31f2  vmovaps [rsp+0x80], xmm8
00007d248dbd31fb  vmovaps [rsp+0x90], xmm9
00007d248dbd3204  vmovaps [rsp+0xA0], xmm10
00007d248dbd320d  vmovaps [rsp+0xB0], xmm12
00007d248dbd3216  vmovaps [rsp+0xC0], xmm13
00007d248dbd321f  vmovaps [rsp+0xD0], xmm14
00007d248dbd3228  vmovaps [rsp+0xE0], xmm15
00007d248dbd3231  sub rsp, 0x30
00007d248dbd3235  movaps [rsp], xmm11
00007d248dbd323a  movaps [rsp+0x10], xmm2
00007d248dbd323f  movaps [rsp+0x20], xmm12
00007d248dbd3245  lea rdi, [rsp]
00007d248dbd3249  mov esi, 0x00
00007d248dbd324e  mov rax, 0x5BCEEF236530
00007d248dbd3258  call rax
00007d248dbd325a  movaps xmm11, [rsp]
00007d248dbd325f  add rsp, 0x30
00007d248dbd3263  vmovaps xmm0, [rsp]
00007d248dbd3268  vmovaps xmm1, [rsp+0x10]
00007d248dbd326e  vmovaps xmm2, [rsp+0x20]
00007d248dbd3274  vmovaps xmm3, [rsp+0x30]
00007d248dbd327a  vmovaps xmm4, [rsp+0x40]
00007d248dbd3280  vmovaps xmm5, [rsp+0x50]
00007d248dbd3286  vmovaps xmm6, [rsp+0x60]
00007d248dbd328c  vmovaps xmm7, [rsp+0x70]
00007d248dbd3292  vmovaps xmm8, [rsp+0x80]
00007d248dbd329b  vmovaps xmm9, [rsp+0x90]
00007d248dbd32a4  vmovaps xmm10, [rsp+0xA0]
00007d248dbd32ad  vmovaps xmm12, [rsp+0xB0]
00007d248dbd32b6  vmovaps xmm13, [rsp+0xC0]
00007d248dbd32bf  vmovaps xmm14, [rsp+0xD0]
00007d248dbd32c8  vmovaps xmm15, [rsp+0xE0]
00007d248dbd32d1  add rsp, 0xF0
00007d248dbd32d8  pop r11
00007d248dbd32da  pop r10
00007d248dbd32dc  pop r9
00007d248dbd32de  pop r8
00007d248dbd32e0  pop rsi
00007d248dbd32e1  pop rdi
00007d248dbd32e2  pop rdx
00007d248dbd32e3  pop rcx
00007d248dbd32e4  pop rax
00007d248dbd32e5  add rsp, 0x08
00007d248dbd32e9  jmp 0x00007D248DBCFEB8
00007d248dbd32ee  sub rsp, 0x08
00007d248dbd32f2  push rax
00007d248dbd32f3  push rcx
00007d248dbd32f4  push rdx
00007d248dbd32f5  push rdi
00007d248dbd32f6  push rsi
00007d248dbd32f7  push r8
00007d248dbd32f9  push r9
00007d248dbd32fb  push r10
00007d248dbd32fd  push r11
00007d248dbd32ff  sub rsp, 0xF0
00007d248dbd3306  vmovaps [rsp], xmm0
00007d248dbd330b  vmovaps [rsp+0x10], xmm2
00007d248dbd3311  vmovaps [rsp+0x20], xmm3
00007d248dbd3317  vmovaps [rsp+0x30], xmm4
00007d248dbd331d  vmovaps [rsp+0x40], xmm5
00007d248dbd3323  vmovaps [rsp+0x50], xmm6
00007d248dbd3329  vmovaps [rsp+0x60], xmm7
00007d248dbd332f  vmovaps [rsp+0x70], xmm8
00007d248dbd3335  vmovaps [rsp+0x80], xmm9
00007d248dbd333e  vmovaps [rsp+0x90], xmm10
00007d248dbd3347  vmovaps [rsp+0xA0], xmm11
00007d248dbd3350  vmovaps [rsp+0xB0], xmm12
00007d248dbd3359  vmovaps [rsp+0xC0], xmm13
00007d248dbd3362  vmovaps [rsp+0xD0], xmm14
00007d248dbd336b  vmovaps [rsp+0xE0], xmm15
00007d248dbd3374  sub rsp, 0x30
00007d248dbd3378  movaps [rsp], xmm1
00007d248dbd337c  movaps [rsp+0x10], xmm14
00007d248dbd3382  movaps [rsp+0x20], xmm6
00007d248dbd3387  lea rdi, [rsp]
00007d248dbd338b  mov esi, 0x00
00007d248dbd3390  mov rax, 0x5BCEEF236530
00007d248dbd339a  call rax
00007d248dbd339c  movaps xmm1, [rsp]
00007d248dbd33a0  add rsp, 0x30
00007d248dbd33a4  vmovaps xmm0, [rsp]
00007d248dbd33a9  vmovaps xmm2, [rsp+0x10]
00007d248dbd33af  vmovaps xmm3, [rsp+0x20]
00007d248dbd33b5  vmovaps xmm4, [rsp+0x30]
00007d248dbd33bb  vmovaps xmm5, [rsp+0x40]
00007d248dbd33c1  vmovaps xmm6, [rsp+0x50]
00007d248dbd33c7  vmovaps xmm7, [rsp+0x60]
00007d248dbd33cd  vmovaps xmm8, [rsp+0x70]
00007d248dbd33d3  vmovaps xmm9, [rsp+0x80]
00007d248dbd33dc  vmovaps xmm10, [rsp+0x90]
00007d248dbd33e5  vmovaps xmm11, [rsp+0xA0]
00007d248dbd33ee  vmovaps xmm12, [rsp+0xB0]
00007d248dbd33f7  vmovaps xmm13, [rsp+0xC0]
00007d248dbd3400  vmovaps xmm14, [rsp+0xD0]
00007d248dbd3409  vmovaps xmm15, [rsp+0xE0]
00007d248dbd3412  add rsp, 0xF0
00007d248dbd3419  pop r11
00007d248dbd341b  pop r10
00007d248dbd341d  pop r9
00007d248dbd341f  pop r8
00007d248dbd3421  pop rsi
00007d248dbd3422  pop rdi
00007d248dbd3423  pop rdx
00007d248dbd3424  pop rcx
00007d248dbd3425  pop rax
00007d248dbd3426  add rsp, 0x08
00007d248dbd342a  jmp 0x00007D248DBCFED1
00007d248dbd342f  sub rsp, 0x08
00007d248dbd3433  push rax
00007d248dbd3434  push rcx
00007d248dbd3435  push rdx
00007d248dbd3436  push rdi
00007d248dbd3437  push rsi
00007d248dbd3438  push r8
00007d248dbd343a  push r9
00007d248dbd343c  push r10
00007d248dbd343e  push r11
00007d248dbd3440  sub rsp, 0xF0
00007d248dbd3447  vmovaps [rsp], xmm0
00007d248dbd344c  vmovaps [rsp+0x10], xmm1
00007d248dbd3452  vmovaps [rsp+0x20], xmm2
00007d248dbd3458  vmovaps [rsp+0x30], xmm3
00007d248dbd345e  vmovaps [rsp+0x40], xmm4
00007d248dbd3464  vmovaps [rsp+0x50], xmm5
00007d248dbd346a  vmovaps [rsp+0x60], xmm6
00007d248dbd3470  vmovaps [rsp+0x70], xmm7
00007d248dbd3476  vmovaps [rsp+0x80], xmm8
00007d248dbd347f  vmovaps [rsp+0x90], xmm9
00007d248dbd3488  vmovaps [rsp+0xA0], xmm10
00007d248dbd3491  vmovaps [rsp+0xB0], xmm11
00007d248dbd349a  vmovaps [rsp+0xC0], xmm12
00007d248dbd34a3  vmovaps [rsp+0xD0], xmm13
00007d248dbd34ac  vmovaps [rsp+0xE0], xmm15
00007d248dbd34b5  sub rsp, 0x30
00007d248dbd34b9  movaps [rsp], xmm14
00007d248dbd34be  movaps [rsp+0x10], xmm12
00007d248dbd34c4  movaps [rsp+0x20], xmm5
00007d248dbd34c9  lea rdi, [rsp]
00007d248dbd34cd  mov esi, 0x00
00007d248dbd34d2  mov rax, 0x5BCEEF236530
00007d248dbd34dc  call rax
00007d248dbd34de  movaps xmm14, [rsp]
00007d248dbd34e3  add rsp, 0x30
00007d248dbd34e7  vmovaps xmm0, [rsp]
00007d248dbd34ec  vmovaps xmm1, [rsp+0x10]
00007d248dbd34f2  vmovaps xmm2, [rsp+0x20]
00007d248dbd34f8  vmovaps xmm3, [rsp+0x30]
00007d248dbd34fe  vmovaps xmm4, [rsp+0x40]
00007d248dbd3504  vmovaps xmm5, [rsp+0x50]
00007d248dbd350a  vmovaps xmm6, [rsp+0x60]
00007d248dbd3510  vmovaps xmm7, [rsp+0x70]
00007d248dbd3516  vmovaps xmm8, [rsp+0x80]
00007d248dbd351f  vmovaps xmm9, [rsp+0x90]
00007d248dbd3528  vmovaps xmm10, [rsp+0xA0]
00007d248dbd3531  vmovaps xmm11, [rsp+0xB0]
00007d248dbd353a  vmovaps xmm12, [rsp+0xC0]
00007d248dbd3543  vmovaps xmm13, [rsp+0xD0]
00007d248dbd354c  vmovaps xmm15, [rsp+0xE0]
00007d248dbd3555  add rsp, 0xF0
00007d248dbd355c  pop r11
00007d248dbd355e  pop r10
00007d248dbd3560  pop r9
00007d248dbd3562  pop r8
00007d248dbd3564  pop rsi
00007d248dbd3565  pop rdi
00007d248dbd3566  pop rdx
00007d248dbd3567  pop rcx
00007d248dbd3568  pop rax
00007d248dbd3569  add rsp, 0x08
00007d248dbd356d  jmp 0x00007D248DBCFEF1
00007d248dbd3572  sub rsp, 0x08
00007d248dbd3576  push rax
00007d248dbd3577  push rcx
00007d248dbd3578  push rdx
00007d248dbd3579  push rdi
00007d248dbd357a  push rsi
00007d248dbd357b  push r8
00007d248dbd357d  push r9
00007d248dbd357f  push r10
00007d248dbd3581  push r11
00007d248dbd3583  sub rsp, 0xF0
00007d248dbd358a  vmovaps [rsp], xmm0
00007d248dbd358f  vmovaps [rsp+0x10], xmm1
00007d248dbd3595  vmovaps [rsp+0x20], xmm2
00007d248dbd359b  vmovaps [rsp+0x30], xmm3
00007d248dbd35a1  vmovaps [rsp+0x40], xmm4
00007d248dbd35a7  vmovaps [rsp+0x50], xmm5
00007d248dbd35ad  vmovaps [rsp+0x60], xmm7
00007d248dbd35b3  vmovaps [rsp+0x70], xmm8
00007d248dbd35b9  vmovaps [rsp+0x80], xmm9
00007d248dbd35c2  vmovaps [rsp+0x90], xmm10
00007d248dbd35cb  vmovaps [rsp+0xA0], xmm11
00007d248dbd35d4  vmovaps [rsp+0xB0], xmm12
00007d248dbd35dd  vmovaps [rsp+0xC0], xmm13
00007d248dbd35e6  vmovaps [rsp+0xD0], xmm14
00007d248dbd35ef  vmovaps [rsp+0xE0], xmm15
00007d248dbd35f8  sub rsp, 0x30
00007d248dbd35fc  movaps [rsp], xmm6
00007d248dbd3600  movaps [rsp+0x10], xmm9
00007d248dbd3606  movaps [rsp+0x20], xmm12
00007d248dbd360c  lea rdi, [rsp]
00007d248dbd3610  mov esi, 0x00
00007d248dbd3615  mov rax, 0x5BCEEF236530
00007d248dbd361f  call rax
00007d248dbd3621  movaps xmm6, [rsp]
00007d248dbd3625  add rsp, 0x30
00007d248dbd3629  vmovaps xmm0, [rsp]
00007d248dbd362e  vmovaps xmm1, [rsp+0x10]
00007d248dbd3634  vmovaps xmm2, [rsp+0x20]
00007d248dbd363a  vmovaps xmm3, [rsp+0x30]
00007d248dbd3640  vmovaps xmm4, [rsp+0x40]
00007d248dbd3646  vmovaps xmm5, [rsp+0x50]
00007d248dbd364c  vmovaps xmm7, [rsp+0x60]
00007d248dbd3652  vmovaps xmm8, [rsp+0x70]
00007d248dbd3658  vmovaps xmm9, [rsp+0x80]
00007d248dbd3661  vmovaps xmm10, [rsp+0x90]
00007d248dbd366a  vmovaps xmm11, [rsp+0xA0]
00007d248dbd3673  vmovaps xmm12, [rsp+0xB0]
00007d248dbd367c  vmovaps xmm13, [rsp+0xC0]
00007d248dbd3685  vmovaps xmm14, [rsp+0xD0]
00007d248dbd368e  vmovaps xmm15, [rsp+0xE0]
00007d248dbd3697  add rsp, 0xF0
00007d248dbd369e  pop r11
00007d248dbd36a0  pop r10
00007d248dbd36a2  pop r9
00007d248dbd36a4  pop r8
00007d248dbd36a6  pop rsi
00007d248dbd36a7  pop rdi
00007d248dbd36a8  pop rdx
00007d248dbd36a9  pop rcx
00007d248dbd36aa  pop rax
00007d248dbd36ab  add rsp, 0x08
00007d248dbd36af  jmp 0x00007D248DBCFF19
00007d248dbd36b4  sub rsp, 0x08
00007d248dbd36b8  push rax
00007d248dbd36b9  push rcx
00007d248dbd36ba  push rdx
00007d248dbd36bb  push rdi
00007d248dbd36bc  push rsi
00007d248dbd36bd  push r8
00007d248dbd36bf  push r9
00007d248dbd36c1  push r10
00007d248dbd36c3  push r11
00007d248dbd36c5  sub rsp, 0xF0
00007d248dbd36cc  vmovaps [rsp], xmm0
00007d248dbd36d1  vmovaps [rsp+0x10], xmm1
00007d248dbd36d7  vmovaps [rsp+0x20], xmm2
00007d248dbd36dd  vmovaps [rsp+0x30], xmm3
00007d248dbd36e3  vmovaps [rsp+0x40], xmm4
00007d248dbd36e9  vmovaps [rsp+0x50], xmm5
00007d248dbd36ef  vmovaps [rsp+0x60], xmm6
00007d248dbd36f5  vmovaps [rsp+0x70], xmm7
00007d248dbd36fb  vmovaps [rsp+0x80], xmm8
00007d248dbd3704  vmovaps [rsp+0x90], xmm9
00007d248dbd370d  vmovaps [rsp+0xA0], xmm10
00007d248dbd3716  vmovaps [rsp+0xB0], xmm11
00007d248dbd371f  vmovaps [rsp+0xC0], xmm13
00007d248dbd3728  vmovaps [rsp+0xD0], xmm14
00007d248dbd3731  vmovaps [rsp+0xE0], xmm15
00007d248dbd373a  sub rsp, 0x30
00007d248dbd373e  movaps [rsp], xmm12
00007d248dbd3743  movaps [rsp+0x10], xmm15
00007d248dbd3749  movaps [rsp+0x20], xmm13
00007d248dbd374f  lea rdi, [rsp]
00007d248dbd3753  mov esi, 0x00
00007d248dbd3758  mov rax, 0x5BCEEF236530
00007d248dbd3762  call rax
00007d248dbd3764  movaps xmm12, [rsp]
00007d248dbd3769  add rsp, 0x30
00007d248dbd376d  vmovaps xmm0, [rsp]
00007d248dbd3772  vmovaps xmm1, [rsp+0x10]
00007d248dbd3778  vmovaps xmm2, [rsp+0x20]
00007d248dbd377e  vmovaps xmm3, [rsp+0x30]
00007d248dbd3784  vmovaps xmm4, [rsp+0x40]
00007d248dbd378a  vmovaps xmm5, [rsp+0x50]
00007d248dbd3790  vmovaps xmm6, [rsp+0x60]
00007d248dbd3796  vmovaps xmm7, [rsp+0x70]
00007d248dbd379c  vmovaps xmm8, [rsp+0x80]
00007d248dbd37a5  vmovaps xmm9, [rsp+0x90]
00007d248dbd37ae  vmovaps xmm10, [rsp+0xA0]
00007d248dbd37b7  vmovaps xmm11, [rsp+0xB0]
00007d248dbd37c0  vmovaps xmm13, [rsp+0xC0]
00007d248dbd37c9  vmovaps xmm14, [rsp+0xD0]
00007d248dbd37d2  vmovaps xmm15, [rsp+0xE0]
00007d248dbd37db  add rsp, 0xF0
00007d248dbd37e2  pop r11
00007d248dbd37e4  pop r10
00007d248dbd37e6  pop r9
00007d248dbd37e8  pop r8
00007d248dbd37ea  pop rsi
00007d248dbd37eb  pop rdi
00007d248dbd37ec  pop rdx
00007d248dbd37ed  pop rcx
00007d248dbd37ee  pop rax
00007d248dbd37ef  add rsp, 0x08
00007d248dbd37f3  jmp 0x00007D248DBCFF34
00007d248dbd37f8  sub rsp, 0x08
00007d248dbd37fc  push rax
00007d248dbd37fd  push rcx
00007d248dbd37fe  push rdx
00007d248dbd37ff  push rdi
00007d248dbd3800  push rsi
00007d248dbd3801  push r8
00007d248dbd3803  push r9
00007d248dbd3805  push r10
00007d248dbd3807  push r11
00007d248dbd3809  sub rsp, 0xF0
00007d248dbd3810  vmovaps [rsp], xmm0
00007d248dbd3815  vmovaps [rsp+0x10], xmm1
00007d248dbd381b  vmovaps [rsp+0x20], xmm2
00007d248dbd3821  vmovaps [rsp+0x30], xmm3
00007d248dbd3827  vmovaps [rsp+0x40], xmm4
00007d248dbd382d  vmovaps [rsp+0x50], xmm5
00007d248dbd3833  vmovaps [rsp+0x60], xmm6
00007d248dbd3839  vmovaps [rsp+0x70], xmm7
00007d248dbd383f  vmovaps [rsp+0x80], xmm8
00007d248dbd3848  vmovaps [rsp+0x90], xmm9
00007d248dbd3851  vmovaps [rsp+0xA0], xmm10
00007d248dbd385a  vmovaps [rsp+0xB0], xmm11
00007d248dbd3863  vmovaps [rsp+0xC0], xmm12
00007d248dbd386c  vmovaps [rsp+0xD0], xmm13
00007d248dbd3875  vmovaps [rsp+0xE0], xmm14
00007d248dbd387e  sub rsp, 0x30
00007d248dbd3882  movaps [rsp], xmm15
00007d248dbd3887  movaps [rsp+0x10], xmm13
00007d248dbd388d  movaps [rsp+0x20], xmm10
00007d248dbd3893  lea rdi, [rsp]
00007d248dbd3897  mov esi, 0x00
00007d248dbd389c  mov rax, 0x5BCEEF236530
00007d248dbd38a6  call rax
00007d248dbd38a8  movaps xmm15, [rsp]
00007d248dbd38ad  add rsp, 0x30
00007d248dbd38b1  vmovaps xmm0, [rsp]
00007d248dbd38b6  vmovaps xmm1, [rsp+0x10]
00007d248dbd38bc  vmovaps xmm2, [rsp+0x20]
00007d248dbd38c2  vmovaps xmm3, [rsp+0x30]
00007d248dbd38c8  vmovaps xmm4, [rsp+0x40]
00007d248dbd38ce  vmovaps xmm5, [rsp+0x50]
00007d248dbd38d4  vmovaps xmm6, [rsp+0x60]
00007d248dbd38da  vmovaps xmm7, [rsp+0x70]
00007d248dbd38e0  vmovaps xmm8, [rsp+0x80]
00007d248dbd38e9  vmovaps xmm9, [rsp+0x90]
00007d248dbd38f2  vmovaps xmm10, [rsp+0xA0]
00007d248dbd38fb  vmovaps xmm11, [rsp+0xB0]
00007d248dbd3904  vmovaps xmm12, [rsp+0xC0]
00007d248dbd390d  vmovaps xmm13, [rsp+0xD0]
00007d248dbd3916  vmovaps xmm14, [rsp+0xE0]
00007d248dbd391f  add rsp, 0xF0
00007d248dbd3926  pop r11
00007d248dbd3928  pop r10
00007d248dbd392a  pop r9
00007d248dbd392c  pop r8
00007d248dbd392e  pop rsi
00007d248dbd392f  pop rdi
00007d248dbd3930  pop rdx
00007d248dbd3931  pop rcx
00007d248dbd3932  pop rax
00007d248dbd3933  add rsp, 0x08
00007d248dbd3937  jmp 0x00007D248DBCFF55
00007d248dbd393c  call 0x00007D248DA0C260
00007d248dbd3941  jmp 0x00007D248DBCFFB0
00007d248dbd3946  sub rsp, 0x08
00007d248dbd394a  push rax
00007d248dbd394b  push rcx
00007d248dbd394c  push rdx
00007d248dbd394d  push rdi
00007d248dbd394e  push rsi
00007d248dbd394f  push r8
00007d248dbd3951  push r9
00007d248dbd3953  push r10
00007d248dbd3955  push r11
00007d248dbd3957  sub rsp, 0xF0
00007d248dbd395e  vmovaps [rsp], xmm0
00007d248dbd3963  vmovaps [rsp+0x10], xmm1
00007d248dbd3969  vmovaps [rsp+0x20], xmm2
00007d248dbd396f  vmovaps [rsp+0x30], xmm3
00007d248dbd3975  vmovaps [rsp+0x40], xmm4
00007d248dbd397b  vmovaps [rsp+0x50], xmm5
00007d248dbd3981  vmovaps [rsp+0x60], xmm6
00007d248dbd3987  vmovaps [rsp+0x70], xmm7
00007d248dbd398d  vmovaps [rsp+0x80], xmm8
00007d248dbd3996  vmovaps [rsp+0x90], xmm10
00007d248dbd399f  vmovaps [rsp+0xA0], xmm11
00007d248dbd39a8  vmovaps [rsp+0xB0], xmm12
00007d248dbd39b1  vmovaps [rsp+0xC0], xmm13
00007d248dbd39ba  vmovaps [rsp+0xD0], xmm14
00007d248dbd39c3  vmovaps [rsp+0xE0], xmm15
00007d248dbd39cc  sub rsp, 0x30
00007d248dbd39d0  movaps [rsp], xmm9
00007d248dbd39d5  movaps [rsp+0x10], xmm8
00007d248dbd39db  movaps [rsp+0x20], xmm10
00007d248dbd39e1  lea rdi, [rsp]
00007d248dbd39e5  mov esi, 0x00
00007d248dbd39ea  mov rax, 0x5BCEEF236530
00007d248dbd39f4  call rax
00007d248dbd39f6  movaps xmm9, [rsp]
00007d248dbd39fb  add rsp, 0x30
00007d248dbd39ff  vmovaps xmm0, [rsp]
00007d248dbd3a04  vmovaps xmm1, [rsp+0x10]
00007d248dbd3a0a  vmovaps xmm2, [rsp+0x20]
00007d248dbd3a10  vmovaps xmm3, [rsp+0x30]
00007d248dbd3a16  vmovaps xmm4, [rsp+0x40]
00007d248dbd3a1c  vmovaps xmm5, [rsp+0x50]
00007d248dbd3a22  vmovaps xmm6, [rsp+0x60]
00007d248dbd3a28  vmovaps xmm7, [rsp+0x70]
00007d248dbd3a2e  vmovaps xmm8, [rsp+0x80]
00007d248dbd3a37  vmovaps xmm10, [rsp+0x90]
00007d248dbd3a40  vmovaps xmm11, [rsp+0xA0]
00007d248dbd3a49  vmovaps xmm12, [rsp+0xB0]
00007d248dbd3a52  vmovaps xmm13, [rsp+0xC0]
00007d248dbd3a5b  vmovaps xmm14, [rsp+0xD0]
00007d248dbd3a64  vmovaps xmm15, [rsp+0xE0]
00007d248dbd3a6d  add rsp, 0xF0
00007d248dbd3a74  pop r11
00007d248dbd3a76  pop r10
00007d248dbd3a78  pop r9
00007d248dbd3a7a  pop r8
00007d248dbd3a7c  pop rsi
00007d248dbd3a7d  pop rdi
00007d248dbd3a7e  pop rdx
00007d248dbd3a7f  pop rcx
00007d248dbd3a80  pop rax
00007d248dbd3a81  add rsp, 0x08
00007d248dbd3a85  jmp 0x00007D248DBCFFE1
00007d248dbd3a8a  sub rsp, 0x08
00007d248dbd3a8e  push rax
00007d248dbd3a8f  push rcx
00007d248dbd3a90  push rdx
00007d248dbd3a91  push rdi
00007d248dbd3a92  push rsi
00007d248dbd3a93  push r8
00007d248dbd3a95  push r9
00007d248dbd3a97  push r10
00007d248dbd3a99  push r11
00007d248dbd3a9b  sub rsp, 0xF0
00007d248dbd3aa2  vmovaps [rsp], xmm0
00007d248dbd3aa7  vmovaps [rsp+0x10], xmm1
00007d248dbd3aad  vmovaps [rsp+0x20], xmm2
00007d248dbd3ab3  vmovaps [rsp+0x30], xmm3
00007d248dbd3ab9  vmovaps [rsp+0x40], xmm4
00007d248dbd3abf  vmovaps [rsp+0x50], xmm5
00007d248dbd3ac5  vmovaps [rsp+0x60], xmm6
00007d248dbd3acb  vmovaps [rsp+0x70], xmm7
00007d248dbd3ad1  vmovaps [rsp+0x80], xmm8
00007d248dbd3ada  vmovaps [rsp+0x90], xmm9
00007d248dbd3ae3  vmovaps [rsp+0xA0], xmm11
00007d248dbd3aec  vmovaps [rsp+0xB0], xmm12
00007d248dbd3af5  vmovaps [rsp+0xC0], xmm13
00007d248dbd3afe  vmovaps [rsp+0xD0], xmm14
00007d248dbd3b07  vmovaps [rsp+0xE0], xmm15
00007d248dbd3b10  sub rsp, 0x30
00007d248dbd3b14  movaps [rsp], xmm10
00007d248dbd3b19  movaps [rsp+0x10], xmm1
00007d248dbd3b1e  movaps [rsp+0x20], xmm11
00007d248dbd3b24  lea rdi, [rsp]
00007d248dbd3b28  mov esi, 0x00
00007d248dbd3b2d  mov rax, 0x5BCEEF236530
00007d248dbd3b37  call rax
00007d248dbd3b39  movaps xmm10, [rsp]
00007d248dbd3b3e  add rsp, 0x30
00007d248dbd3b42  vmovaps xmm0, [rsp]
00007d248dbd3b47  vmovaps xmm1, [rsp+0x10]
00007d248dbd3b4d  vmovaps xmm2, [rsp+0x20]
00007d248dbd3b53  vmovaps xmm3, [rsp+0x30]
00007d248dbd3b59  vmovaps xmm4, [rsp+0x40]
00007d248dbd3b5f  vmovaps xmm5, [rsp+0x50]
00007d248dbd3b65  vmovaps xmm6, [rsp+0x60]
00007d248dbd3b6b  vmovaps xmm7, [rsp+0x70]
00007d248dbd3b71  vmovaps xmm8, [rsp+0x80]
00007d248dbd3b7a  vmovaps xmm9, [rsp+0x90]
00007d248dbd3b83  vmovaps xmm11, [rsp+0xA0]
00007d248dbd3b8c  vmovaps xmm12, [rsp+0xB0]
00007d248dbd3b95  vmovaps xmm13, [rsp+0xC0]
00007d248dbd3b9e  vmovaps xmm14, [rsp+0xD0]
00007d248dbd3ba7  vmovaps xmm15, [rsp+0xE0]
00007d248dbd3bb0  add rsp, 0xF0
00007d248dbd3bb7  pop r11
00007d248dbd3bb9  pop r10
00007d248dbd3bbb  pop r9
00007d248dbd3bbd  pop r8
00007d248dbd3bbf  pop rsi
00007d248dbd3bc0  pop rdi
00007d248dbd3bc1  pop rdx
00007d248dbd3bc2  pop rcx
00007d248dbd3bc3  pop rax
00007d248dbd3bc4  add rsp, 0x08
00007d248dbd3bc8  jmp 0x00007D248DBCFFFC
00007d248dbd3bcd  sub rsp, 0x08
00007d248dbd3bd1  push rax
00007d248dbd3bd2  push rcx
00007d248dbd3bd3  push rdx
00007d248dbd3bd4  push rdi
00007d248dbd3bd5  push rsi
00007d248dbd3bd6  push r8
00007d248dbd3bd8  push r9
00007d248dbd3bda  push r10
00007d248dbd3bdc  push r11
00007d248dbd3bde  sub rsp, 0xF0
00007d248dbd3be5  vmovaps [rsp], xmm0
00007d248dbd3bea  vmovaps [rsp+0x10], xmm2
00007d248dbd3bf0  vmovaps [rsp+0x20], xmm3
00007d248dbd3bf6  vmovaps [rsp+0x30], xmm4
00007d248dbd3bfc  vmovaps [rsp+0x40], xmm5
00007d248dbd3c02  vmovaps [rsp+0x50], xmm6
00007d248dbd3c08  vmovaps [rsp+0x60], xmm7
00007d248dbd3c0e  vmovaps [rsp+0x70], xmm8
00007d248dbd3c14  vmovaps [rsp+0x80], xmm9
00007d248dbd3c1d  vmovaps [rsp+0x90], xmm10
00007d248dbd3c26  vmovaps [rsp+0xA0], xmm11
00007d248dbd3c2f  vmovaps [rsp+0xB0], xmm12
00007d248dbd3c38  vmovaps [rsp+0xC0], xmm13
00007d248dbd3c41  vmovaps [rsp+0xD0], xmm14
00007d248dbd3c4a  vmovaps [rsp+0xE0], xmm15
00007d248dbd3c53  sub rsp, 0x30
00007d248dbd3c57  movaps [rsp], xmm1
00007d248dbd3c5b  movaps [rsp+0x10], xmm14
00007d248dbd3c61  movaps [rsp+0x20], xmm6
00007d248dbd3c66  lea rdi, [rsp]
00007d248dbd3c6a  mov esi, 0x00
00007d248dbd3c6f  mov rax, 0x5BCEEF236530
00007d248dbd3c79  call rax
00007d248dbd3c7b  movaps xmm1, [rsp]
00007d248dbd3c7f  add rsp, 0x30
00007d248dbd3c83  vmovaps xmm0, [rsp]
00007d248dbd3c88  vmovaps xmm2, [rsp+0x10]
00007d248dbd3c8e  vmovaps xmm3, [rsp+0x20]
00007d248dbd3c94  vmovaps xmm4, [rsp+0x30]
00007d248dbd3c9a  vmovaps xmm5, [rsp+0x40]
00007d248dbd3ca0  vmovaps xmm6, [rsp+0x50]
00007d248dbd3ca6  vmovaps xmm7, [rsp+0x60]
00007d248dbd3cac  vmovaps xmm8, [rsp+0x70]
00007d248dbd3cb2  vmovaps xmm9, [rsp+0x80]
00007d248dbd3cbb  vmovaps xmm10, [rsp+0x90]
00007d248dbd3cc4  vmovaps xmm11, [rsp+0xA0]
00007d248dbd3ccd  vmovaps xmm12, [rsp+0xB0]
00007d248dbd3cd6  vmovaps xmm13, [rsp+0xC0]
00007d248dbd3cdf  vmovaps xmm14, [rsp+0xD0]
00007d248dbd3ce8  vmovaps xmm15, [rsp+0xE0]
00007d248dbd3cf1  add rsp, 0xF0
00007d248dbd3cf8  pop r11
00007d248dbd3cfa  pop r10
00007d248dbd3cfc  pop r9
00007d248dbd3cfe  pop r8
00007d248dbd3d00  pop rsi
00007d248dbd3d01  pop rdi
00007d248dbd3d02  pop rdx
00007d248dbd3d03  pop rcx
00007d248dbd3d04  pop rax
00007d248dbd3d05  add rsp, 0x08
00007d248dbd3d09  jmp 0x00007D248DBD0015
00007d248dbd3d0e  sub rsp, 0x08
00007d248dbd3d12  push rax
00007d248dbd3d13  push rcx
00007d248dbd3d14  push rdx
00007d248dbd3d15  push rdi
00007d248dbd3d16  push rsi
00007d248dbd3d17  push r8
00007d248dbd3d19  push r9
00007d248dbd3d1b  push r10
00007d248dbd3d1d  push r11
00007d248dbd3d1f  sub rsp, 0xF0
00007d248dbd3d26  vmovaps [rsp], xmm0
00007d248dbd3d2b  vmovaps [rsp+0x10], xmm1
00007d248dbd3d31  vmovaps [rsp+0x20], xmm2
00007d248dbd3d37  vmovaps [rsp+0x30], xmm3
00007d248dbd3d3d  vmovaps [rsp+0x40], xmm4
00007d248dbd3d43  vmovaps [rsp+0x50], xmm5
00007d248dbd3d49  vmovaps [rsp+0x60], xmm6
00007d248dbd3d4f  vmovaps [rsp+0x70], xmm7
00007d248dbd3d55  vmovaps [rsp+0x80], xmm8
00007d248dbd3d5e  vmovaps [rsp+0x90], xmm9
00007d248dbd3d67  vmovaps [rsp+0xA0], xmm10
00007d248dbd3d70  vmovaps [rsp+0xB0], xmm12
00007d248dbd3d79  vmovaps [rsp+0xC0], xmm13
00007d248dbd3d82  vmovaps [rsp+0xD0], xmm14
00007d248dbd3d8b  vmovaps [rsp+0xE0], xmm15
00007d248dbd3d94  sub rsp, 0x30
00007d248dbd3d98  movaps [rsp], xmm11
00007d248dbd3d9d  movaps [rsp+0x10], xmm13
00007d248dbd3da3  movaps [rsp+0x20], xmm14
00007d248dbd3da9  lea rdi, [rsp]
00007d248dbd3dad  mov esi, 0x00
00007d248dbd3db2  mov rax, 0x5BCEEF236530
00007d248dbd3dbc  call rax
00007d248dbd3dbe  movaps xmm11, [rsp]
00007d248dbd3dc3  add rsp, 0x30
00007d248dbd3dc7  vmovaps xmm0, [rsp]
00007d248dbd3dcc  vmovaps xmm1, [rsp+0x10]
00007d248dbd3dd2  vmovaps xmm2, [rsp+0x20]
00007d248dbd3dd8  vmovaps xmm3, [rsp+0x30]
00007d248dbd3dde  vmovaps xmm4, [rsp+0x40]
00007d248dbd3de4  vmovaps xmm5, [rsp+0x50]
00007d248dbd3dea  vmovaps xmm6, [rsp+0x60]
00007d248dbd3df0  vmovaps xmm7, [rsp+0x70]
00007d248dbd3df6  vmovaps xmm8, [rsp+0x80]
00007d248dbd3dff  vmovaps xmm9, [rsp+0x90]
00007d248dbd3e08  vmovaps xmm10, [rsp+0xA0]
00007d248dbd3e11  vmovaps xmm12, [rsp+0xB0]
00007d248dbd3e1a  vmovaps xmm13, [rsp+0xC0]
00007d248dbd3e23  vmovaps xmm14, [rsp+0xD0]
00007d248dbd3e2c  vmovaps xmm15, [rsp+0xE0]
00007d248dbd3e35  add rsp, 0xF0
00007d248dbd3e3c  pop r11
00007d248dbd3e3e  pop r10
00007d248dbd3e40  pop r9
00007d248dbd3e42  pop r8
00007d248dbd3e44  pop rsi
00007d248dbd3e45  pop rdi
00007d248dbd3e46  pop rdx
00007d248dbd3e47  pop rcx
00007d248dbd3e48  pop rax
00007d248dbd3e49  add rsp, 0x08
00007d248dbd3e4d  jmp 0x00007D248DBD003F
00007d248dbd3e52  sub rsp, 0x08
00007d248dbd3e56  push rax
00007d248dbd3e57  push rcx
00007d248dbd3e58  push rdx
00007d248dbd3e59  push rdi
00007d248dbd3e5a  push rsi
00007d248dbd3e5b  push r8
00007d248dbd3e5d  push r9
00007d248dbd3e5f  push r10
00007d248dbd3e61  push r11
00007d248dbd3e63  sub rsp, 0xF0
00007d248dbd3e6a  vmovaps [rsp], xmm0
00007d248dbd3e6f  vmovaps [rsp+0x10], xmm1
00007d248dbd3e75  vmovaps [rsp+0x20], xmm2
00007d248dbd3e7b  vmovaps [rsp+0x30], xmm3
00007d248dbd3e81  vmovaps [rsp+0x40], xmm4
00007d248dbd3e87  vmovaps [rsp+0x50], xmm5
00007d248dbd3e8d  vmovaps [rsp+0x60], xmm6
00007d248dbd3e93  vmovaps [rsp+0x70], xmm7
00007d248dbd3e99  vmovaps [rsp+0x80], xmm8
00007d248dbd3ea2  vmovaps [rsp+0x90], xmm9
00007d248dbd3eab  vmovaps [rsp+0xA0], xmm10
00007d248dbd3eb4  vmovaps [rsp+0xB0], xmm11
00007d248dbd3ebd  vmovaps [rsp+0xC0], xmm12
00007d248dbd3ec6  vmovaps [rsp+0xD0], xmm14
00007d248dbd3ecf  vmovaps [rsp+0xE0], xmm15
00007d248dbd3ed8  sub rsp, 0x30
00007d248dbd3edc  movaps [rsp], xmm13
00007d248dbd3ee1  movaps [rsp+0x10], xmm8
00007d248dbd3ee7  movaps [rsp+0x20], xmm14
00007d248dbd3eed  lea rdi, [rsp]
00007d248dbd3ef1  mov esi, 0x00
00007d248dbd3ef6  mov rax, 0x5BCEEF236530
00007d248dbd3f00  call rax
00007d248dbd3f02  movaps xmm13, [rsp]
00007d248dbd3f07  add rsp, 0x30
00007d248dbd3f0b  vmovaps xmm0, [rsp]
00007d248dbd3f10  vmovaps xmm1, [rsp+0x10]
00007d248dbd3f16  vmovaps xmm2, [rsp+0x20]
00007d248dbd3f1c  vmovaps xmm3, [rsp+0x30]
00007d248dbd3f22  vmovaps xmm4, [rsp+0x40]
00007d248dbd3f28  vmovaps xmm5, [rsp+0x50]
00007d248dbd3f2e  vmovaps xmm6, [rsp+0x60]
00007d248dbd3f34  vmovaps xmm7, [rsp+0x70]
00007d248dbd3f3a  vmovaps xmm8, [rsp+0x80]
00007d248dbd3f43  vmovaps xmm9, [rsp+0x90]
00007d248dbd3f4c  vmovaps xmm10, [rsp+0xA0]
00007d248dbd3f55  vmovaps xmm11, [rsp+0xB0]
00007d248dbd3f5e  vmovaps xmm12, [rsp+0xC0]
00007d248dbd3f67  vmovaps xmm14, [rsp+0xD0]
00007d248dbd3f70  vmovaps xmm15, [rsp+0xE0]
00007d248dbd3f79  add rsp, 0xF0
00007d248dbd3f80  pop r11
00007d248dbd3f82  pop r10
00007d248dbd3f84  pop r9
00007d248dbd3f86  pop r8
00007d248dbd3f88  pop rsi
00007d248dbd3f89  pop rdi
00007d248dbd3f8a  pop rdx
00007d248dbd3f8b  pop rcx
00007d248dbd3f8c  pop rax
00007d248dbd3f8d  add rsp, 0x08
00007d248dbd3f91  jmp 0x00007D248DBD006E
00007d248dbd3f96  sub rsp, 0x08
00007d248dbd3f9a  push rax
00007d248dbd3f9b  push rcx
00007d248dbd3f9c  push rdx
00007d248dbd3f9d  push rdi
00007d248dbd3f9e  push rsi
00007d248dbd3f9f  push r8
00007d248dbd3fa1  push r9
00007d248dbd3fa3  push r10
00007d248dbd3fa5  push r11
00007d248dbd3fa7  sub rsp, 0xF0
00007d248dbd3fae  vmovaps [rsp], xmm0
00007d248dbd3fb3  vmovaps [rsp+0x10], xmm1
00007d248dbd3fb9  vmovaps [rsp+0x20], xmm2
00007d248dbd3fbf  vmovaps [rsp+0x30], xmm3
00007d248dbd3fc5  vmovaps [rsp+0x40], xmm4
00007d248dbd3fcb  vmovaps [rsp+0x50], xmm5
00007d248dbd3fd1  vmovaps [rsp+0x60], xmm6
00007d248dbd3fd7  vmovaps [rsp+0x70], xmm7
00007d248dbd3fdd  vmovaps [rsp+0x80], xmm9
00007d248dbd3fe6  vmovaps [rsp+0x90], xmm10
00007d248dbd3fef  vmovaps [rsp+0xA0], xmm11
00007d248dbd3ff8  vmovaps [rsp+0xB0], xmm12
00007d248dbd4001  vmovaps [rsp+0xC0], xmm13
00007d248dbd400a  vmovaps [rsp+0xD0], xmm14
00007d248dbd4013  vmovaps [rsp+0xE0], xmm15
00007d248dbd401c  sub rsp, 0x30
00007d248dbd4020  movaps [rsp], xmm8
00007d248dbd4025  movaps [rsp+0x10], xmm7
00007d248dbd402a  movaps [rsp+0x20], xmm14
00007d248dbd4030  lea rdi, [rsp]
00007d248dbd4034  mov esi, 0x00
00007d248dbd4039  mov rax, 0x5BCEEF236530
00007d248dbd4043  call rax
00007d248dbd4045  movaps xmm8, [rsp]
00007d248dbd404a  add rsp, 0x30
00007d248dbd404e  vmovaps xmm0, [rsp]
00007d248dbd4053  vmovaps xmm1, [rsp+0x10]
00007d248dbd4059  vmovaps xmm2, [rsp+0x20]
00007d248dbd405f  vmovaps xmm3, [rsp+0x30]
00007d248dbd4065  vmovaps xmm4, [rsp+0x40]
00007d248dbd406b  vmovaps xmm5, [rsp+0x50]
00007d248dbd4071  vmovaps xmm6, [rsp+0x60]
00007d248dbd4077  vmovaps xmm7, [rsp+0x70]
00007d248dbd407d  vmovaps xmm9, [rsp+0x80]
00007d248dbd4086  vmovaps xmm10, [rsp+0x90]
00007d248dbd408f  vmovaps xmm11, [rsp+0xA0]
00007d248dbd4098  vmovaps xmm12, [rsp+0xB0]
00007d248dbd40a1  vmovaps xmm13, [rsp+0xC0]
00007d248dbd40aa  vmovaps xmm14, [rsp+0xD0]
00007d248dbd40b3  vmovaps xmm15, [rsp+0xE0]
00007d248dbd40bc  add rsp, 0xF0
00007d248dbd40c3  pop r11
00007d248dbd40c5  pop r10
00007d248dbd40c7  pop r9
00007d248dbd40c9  pop r8
00007d248dbd40cb  pop rsi
00007d248dbd40cc  pop rdi
00007d248dbd40cd  pop rdx
00007d248dbd40ce  pop rcx
00007d248dbd40cf  pop rax
00007d248dbd40d0  add rsp, 0x08
00007d248dbd40d4  jmp 0x00007D248DBD0094
00007d248dbd40d9  sub rsp, 0x08
00007d248dbd40dd  push rax
00007d248dbd40de  push rcx
00007d248dbd40df  push rdx
00007d248dbd40e0  push rdi
00007d248dbd40e1  push rsi
00007d248dbd40e2  push r8
00007d248dbd40e4  push r9
00007d248dbd40e6  push r10
00007d248dbd40e8  push r11
00007d248dbd40ea  sub rsp, 0xF0
00007d248dbd40f1  vmovaps [rsp], xmm0
00007d248dbd40f6  vmovaps [rsp+0x10], xmm1
00007d248dbd40fc  vmovaps [rsp+0x20], xmm2
00007d248dbd4102  vmovaps [rsp+0x30], xmm3
00007d248dbd4108  vmovaps [rsp+0x40], xmm4
00007d248dbd410e  vmovaps [rsp+0x50], xmm5
00007d248dbd4114  vmovaps [rsp+0x60], xmm6
00007d248dbd411a  vmovaps [rsp+0x70], xmm7
00007d248dbd4120  vmovaps [rsp+0x80], xmm8
00007d248dbd4129  vmovaps [rsp+0x90], xmm9
00007d248dbd4132  vmovaps [rsp+0xA0], xmm10
00007d248dbd413b  vmovaps [rsp+0xB0], xmm11
00007d248dbd4144  vmovaps [rsp+0xC0], xmm12
00007d248dbd414d  vmovaps [rsp+0xD0], xmm13
00007d248dbd4156  vmovaps [rsp+0xE0], xmm15
00007d248dbd415f  sub rsp, 0x30
00007d248dbd4163  movaps [rsp], xmm14
00007d248dbd4168  movaps [rsp+0x10], xmm12
00007d248dbd416e  movaps [rsp+0x20], xmm9
00007d248dbd4174  lea rdi, [rsp]
00007d248dbd4178  mov esi, 0x00
00007d248dbd417d  mov rax, 0x5BCEEF236530
00007d248dbd4187  call rax
00007d248dbd4189  movaps xmm14, [rsp]
00007d248dbd418e  add rsp, 0x30
00007d248dbd4192  vmovaps xmm0, [rsp]
00007d248dbd4197  vmovaps xmm1, [rsp+0x10]
00007d248dbd419d  vmovaps xmm2, [rsp+0x20]
00007d248dbd41a3  vmovaps xmm3, [rsp+0x30]
00007d248dbd41a9  vmovaps xmm4, [rsp+0x40]
00007d248dbd41af  vmovaps xmm5, [rsp+0x50]
00007d248dbd41b5  vmovaps xmm6, [rsp+0x60]
00007d248dbd41bb  vmovaps xmm7, [rsp+0x70]
00007d248dbd41c1  vmovaps xmm8, [rsp+0x80]
00007d248dbd41ca  vmovaps xmm9, [rsp+0x90]
00007d248dbd41d3  vmovaps xmm10, [rsp+0xA0]
00007d248dbd41dc  vmovaps xmm11, [rsp+0xB0]
00007d248dbd41e5  vmovaps xmm12, [rsp+0xC0]
00007d248dbd41ee  vmovaps xmm13, [rsp+0xD0]
00007d248dbd41f7  vmovaps xmm15, [rsp+0xE0]
00007d248dbd4200  add rsp, 0xF0
00007d248dbd4207  pop r11
00007d248dbd4209  pop r10
00007d248dbd420b  pop r9
00007d248dbd420d  pop r8
00007d248dbd420f  pop rsi
00007d248dbd4210  pop rdi
00007d248dbd4211  pop rdx
00007d248dbd4212  pop rcx
00007d248dbd4213  pop rax
00007d248dbd4214  add rsp, 0x08
00007d248dbd4218  jmp 0x00007D248DBD00AE
00007d248dbd421d  sub rsp, 0x08
00007d248dbd4221  push rax
00007d248dbd4222  push rcx
00007d248dbd4223  push rdx
00007d248dbd4224  push rdi
00007d248dbd4225  push rsi
00007d248dbd4226  push r8
00007d248dbd4228  push r9
00007d248dbd422a  push r10
00007d248dbd422c  push r11
00007d248dbd422e  sub rsp, 0xF0
00007d248dbd4235  vmovaps [rsp], xmm0
00007d248dbd423a  vmovaps [rsp+0x10], xmm1
00007d248dbd4240  vmovaps [rsp+0x20], xmm2
00007d248dbd4246  vmovaps [rsp+0x30], xmm3
00007d248dbd424c  vmovaps [rsp+0x40], xmm4
00007d248dbd4252  vmovaps [rsp+0x50], xmm5
00007d248dbd4258  vmovaps [rsp+0x60], xmm6
00007d248dbd425e  vmovaps [rsp+0x70], xmm7
00007d248dbd4264  vmovaps [rsp+0x80], xmm8
00007d248dbd426d  vmovaps [rsp+0x90], xmm10
00007d248dbd4276  vmovaps [rsp+0xA0], xmm11
00007d248dbd427f  vmovaps [rsp+0xB0], xmm12
00007d248dbd4288  vmovaps [rsp+0xC0], xmm13
00007d248dbd4291  vmovaps [rsp+0xD0], xmm14
00007d248dbd429a  vmovaps [rsp+0xE0], xmm15
00007d248dbd42a3  sub rsp, 0x30
00007d248dbd42a7  movaps [rsp], xmm9
00007d248dbd42ac  movaps [rsp+0x10], xmm7
00007d248dbd42b1  movaps [rsp+0x20], xmm12
00007d248dbd42b7  lea rdi, [rsp]
00007d248dbd42bb  mov esi, 0x00
00007d248dbd42c0  mov rax, 0x5BCEEF236530
00007d248dbd42ca  call rax
00007d248dbd42cc  movaps xmm9, [rsp]
00007d248dbd42d1  add rsp, 0x30
00007d248dbd42d5  vmovaps xmm0, [rsp]
00007d248dbd42da  vmovaps xmm1, [rsp+0x10]
00007d248dbd42e0  vmovaps xmm2, [rsp+0x20]
00007d248dbd42e6  vmovaps xmm3, [rsp+0x30]
00007d248dbd42ec  vmovaps xmm4, [rsp+0x40]
00007d248dbd42f2  vmovaps xmm5, [rsp+0x50]
00007d248dbd42f8  vmovaps xmm6, [rsp+0x60]
00007d248dbd42fe  vmovaps xmm7, [rsp+0x70]
00007d248dbd4304  vmovaps xmm8, [rsp+0x80]
00007d248dbd430d  vmovaps xmm10, [rsp+0x90]
00007d248dbd4316  vmovaps xmm11, [rsp+0xA0]
00007d248dbd431f  vmovaps xmm12, [rsp+0xB0]
00007d248dbd4328  vmovaps xmm13, [rsp+0xC0]
00007d248dbd4331  vmovaps xmm14, [rsp+0xD0]
00007d248dbd433a  vmovaps xmm15, [rsp+0xE0]
00007d248dbd4343  add rsp, 0xF0
00007d248dbd434a  pop r11
00007d248dbd434c  pop r10
00007d248dbd434e  pop r9
00007d248dbd4350  pop r8
00007d248dbd4352  pop rsi
00007d248dbd4353  pop rdi
00007d248dbd4354  pop rdx
00007d248dbd4355  pop rcx
00007d248dbd4356  pop rax
00007d248dbd4357  add rsp, 0x08
00007d248dbd435b  jmp 0x00007D248DBD00DD
00007d248dbd4360  sub rsp, 0x08
00007d248dbd4364  push rax
00007d248dbd4365  push rcx
00007d248dbd4366  push rdx
00007d248dbd4367  push rdi
00007d248dbd4368  push rsi
00007d248dbd4369  push r8
00007d248dbd436b  push r9
00007d248dbd436d  push r10
00007d248dbd436f  push r11
00007d248dbd4371  sub rsp, 0xF0
00007d248dbd4378  vmovaps [rsp], xmm0
00007d248dbd437d  vmovaps [rsp+0x10], xmm1
00007d248dbd4383  vmovaps [rsp+0x20], xmm2
00007d248dbd4389  vmovaps [rsp+0x30], xmm3
00007d248dbd438f  vmovaps [rsp+0x40], xmm4
00007d248dbd4395  vmovaps [rsp+0x50], xmm5
00007d248dbd439b  vmovaps [rsp+0x60], xmm6
00007d248dbd43a1  vmovaps [rsp+0x70], xmm7
00007d248dbd43a7  vmovaps [rsp+0x80], xmm8
00007d248dbd43b0  vmovaps [rsp+0x90], xmm9
00007d248dbd43b9  vmovaps [rsp+0xA0], xmm10
00007d248dbd43c2  vmovaps [rsp+0xB0], xmm11
00007d248dbd43cb  vmovaps [rsp+0xC0], xmm13
00007d248dbd43d4  vmovaps [rsp+0xD0], xmm14
00007d248dbd43dd  vmovaps [rsp+0xE0], xmm15
00007d248dbd43e6  sub rsp, 0x30
00007d248dbd43ea  movaps [rsp], xmm12
00007d248dbd43ef  movaps [rsp+0x10], xmm15
00007d248dbd43f5  movaps [rsp+0x20], xmm11
00007d248dbd43fb  lea rdi, [rsp]
00007d248dbd43ff  mov esi, 0x00
00007d248dbd4404  mov rax, 0x5BCEEF236530
00007d248dbd440e  call rax
00007d248dbd4410  movaps xmm12, [rsp]
00007d248dbd4415  add rsp, 0x30
00007d248dbd4419  vmovaps xmm0, [rsp]
00007d248dbd441e  vmovaps xmm1, [rsp+0x10]
00007d248dbd4424  vmovaps xmm2, [rsp+0x20]
00007d248dbd442a  vmovaps xmm3, [rsp+0x30]
00007d248dbd4430  vmovaps xmm4, [rsp+0x40]
00007d248dbd4436  vmovaps xmm5, [rsp+0x50]
00007d248dbd443c  vmovaps xmm6, [rsp+0x60]
00007d248dbd4442  vmovaps xmm7, [rsp+0x70]
00007d248dbd4448  vmovaps xmm8, [rsp+0x80]
00007d248dbd4451  vmovaps xmm9, [rsp+0x90]
00007d248dbd445a  vmovaps xmm10, [rsp+0xA0]
00007d248dbd4463  vmovaps xmm11, [rsp+0xB0]
00007d248dbd446c  vmovaps xmm13, [rsp+0xC0]
00007d248dbd4475  vmovaps xmm14, [rsp+0xD0]
00007d248dbd447e  vmovaps xmm15, [rsp+0xE0]
00007d248dbd4487  add rsp, 0xF0
00007d248dbd448e  pop r11
00007d248dbd4490  pop r10
00007d248dbd4492  pop r9
00007d248dbd4494  pop r8
00007d248dbd4496  pop rsi
00007d248dbd4497  pop rdi
00007d248dbd4498  pop rdx
00007d248dbd4499  pop rcx
00007d248dbd449a  pop rax
00007d248dbd449b  add rsp, 0x08
00007d248dbd449f  jmp 0x00007D248DBD00F7
00007d248dbd44a4  sub rsp, 0x08
00007d248dbd44a8  push rax
00007d248dbd44a9  push rcx
00007d248dbd44aa  push rdx
00007d248dbd44ab  push rdi
00007d248dbd44ac  push rsi
00007d248dbd44ad  push r8
00007d248dbd44af  push r9
00007d248dbd44b1  push r10
00007d248dbd44b3  push r11
00007d248dbd44b5  sub rsp, 0xF0
00007d248dbd44bc  vmovaps [rsp], xmm0
00007d248dbd44c1  vmovaps [rsp+0x10], xmm1
00007d248dbd44c7  vmovaps [rsp+0x20], xmm2
00007d248dbd44cd  vmovaps [rsp+0x30], xmm3
00007d248dbd44d3  vmovaps [rsp+0x40], xmm4
00007d248dbd44d9  vmovaps [rsp+0x50], xmm5
00007d248dbd44df  vmovaps [rsp+0x60], xmm6
00007d248dbd44e5  vmovaps [rsp+0x70], xmm7
00007d248dbd44eb  vmovaps [rsp+0x80], xmm8
00007d248dbd44f4  vmovaps [rsp+0x90], xmm9
00007d248dbd44fd  vmovaps [rsp+0xA0], xmm10
00007d248dbd4506  vmovaps [rsp+0xB0], xmm12
00007d248dbd450f  vmovaps [rsp+0xC0], xmm13
00007d248dbd4518  vmovaps [rsp+0xD0], xmm14
00007d248dbd4521  vmovaps [rsp+0xE0], xmm15
00007d248dbd452a  sub rsp, 0x30
00007d248dbd452e  movaps [rsp], xmm11
00007d248dbd4533  movaps [rsp+0x10], xmm7
00007d248dbd4538  movaps [rsp+0x20], xmm15
00007d248dbd453e  lea rdi, [rsp]
00007d248dbd4542  mov esi, 0x00
00007d248dbd4547  mov rax, 0x5BCEEF236530
00007d248dbd4551  call rax
00007d248dbd4553  movaps xmm11, [rsp]
00007d248dbd4558  add rsp, 0x30
00007d248dbd455c  vmovaps xmm0, [rsp]
00007d248dbd4561  vmovaps xmm1, [rsp+0x10]
00007d248dbd4567  vmovaps xmm2, [rsp+0x20]
00007d248dbd456d  vmovaps xmm3, [rsp+0x30]
00007d248dbd4573  vmovaps xmm4, [rsp+0x40]
00007d248dbd4579  vmovaps xmm5, [rsp+0x50]
00007d248dbd457f  vmovaps xmm6, [rsp+0x60]
00007d248dbd4585  vmovaps xmm7, [rsp+0x70]
00007d248dbd458b  vmovaps xmm8, [rsp+0x80]
00007d248dbd4594  vmovaps xmm9, [rsp+0x90]
00007d248dbd459d  vmovaps xmm10, [rsp+0xA0]
00007d248dbd45a6  vmovaps xmm12, [rsp+0xB0]
00007d248dbd45af  vmovaps xmm13, [rsp+0xC0]
00007d248dbd45b8  vmovaps xmm14, [rsp+0xD0]
00007d248dbd45c1  vmovaps xmm15, [rsp+0xE0]
00007d248dbd45ca  add rsp, 0xF0
00007d248dbd45d1  pop r11
00007d248dbd45d3  pop r10
00007d248dbd45d5  pop r9
00007d248dbd45d7  pop r8
00007d248dbd45d9  pop rsi
00007d248dbd45da  pop rdi
00007d248dbd45db  pop rdx
00007d248dbd45dc  pop rcx
00007d248dbd45dd  pop rax
00007d248dbd45de  add rsp, 0x08
00007d248dbd45e2  jmp 0x00007D248DBD0123
00007d248dbd45e7  sub rsp, 0x08
00007d248dbd45eb  push rax
00007d248dbd45ec  push rcx
00007d248dbd45ed  push rdx
00007d248dbd45ee  push rdi
00007d248dbd45ef  push rsi
00007d248dbd45f0  push r8
00007d248dbd45f2  push r9
00007d248dbd45f4  push r10
00007d248dbd45f6  push r11
00007d248dbd45f8  sub rsp, 0xF0
00007d248dbd45ff  vmovaps [rsp], xmm0
00007d248dbd4604  vmovaps [rsp+0x10], xmm1
00007d248dbd460a  vmovaps [rsp+0x20], xmm2
00007d248dbd4610  vmovaps [rsp+0x30], xmm3
00007d248dbd4616  vmovaps [rsp+0x40], xmm4
00007d248dbd461c  vmovaps [rsp+0x50], xmm5
00007d248dbd4622  vmovaps [rsp+0x60], xmm6
00007d248dbd4628  vmovaps [rsp+0x70], xmm7
00007d248dbd462e  vmovaps [rsp+0x80], xmm8
00007d248dbd4637  vmovaps [rsp+0x90], xmm9
00007d248dbd4640  vmovaps [rsp+0xA0], xmm10
00007d248dbd4649  vmovaps [rsp+0xB0], xmm11
00007d248dbd4652  vmovaps [rsp+0xC0], xmm12
00007d248dbd465b  vmovaps [rsp+0xD0], xmm13
00007d248dbd4664  vmovaps [rsp+0xE0], xmm14
00007d248dbd466d  sub rsp, 0x30
00007d248dbd4671  movaps [rsp], xmm15
00007d248dbd4676  movaps [rsp+0x10], xmm10
00007d248dbd467c  movaps [rsp+0x20], xmm13
00007d248dbd4682  lea rdi, [rsp]
00007d248dbd4686  mov esi, 0x00
00007d248dbd468b  mov rax, 0x5BCEEF236530
00007d248dbd4695  call rax
00007d248dbd4697  movaps xmm15, [rsp]
00007d248dbd469c  add rsp, 0x30
00007d248dbd46a0  vmovaps xmm0, [rsp]
00007d248dbd46a5  vmovaps xmm1, [rsp+0x10]
00007d248dbd46ab  vmovaps xmm2, [rsp+0x20]
00007d248dbd46b1  vmovaps xmm3, [rsp+0x30]
00007d248dbd46b7  vmovaps xmm4, [rsp+0x40]
00007d248dbd46bd  vmovaps xmm5, [rsp+0x50]
00007d248dbd46c3  vmovaps xmm6, [rsp+0x60]
00007d248dbd46c9  vmovaps xmm7, [rsp+0x70]
00007d248dbd46cf  vmovaps xmm8, [rsp+0x80]
00007d248dbd46d8  vmovaps xmm9, [rsp+0x90]
00007d248dbd46e1  vmovaps xmm10, [rsp+0xA0]
00007d248dbd46ea  vmovaps xmm11, [rsp+0xB0]
00007d248dbd46f3  vmovaps xmm12, [rsp+0xC0]
00007d248dbd46fc  vmovaps xmm13, [rsp+0xD0]
00007d248dbd4705  vmovaps xmm14, [rsp+0xE0]
00007d248dbd470e  add rsp, 0xF0
00007d248dbd4715  pop r11
00007d248dbd4717  pop r10
00007d248dbd4719  pop r9
00007d248dbd471b  pop r8
00007d248dbd471d  pop rsi
00007d248dbd471e  pop rdi
00007d248dbd471f  pop rdx
00007d248dbd4720  pop rcx
00007d248dbd4721  pop rax
00007d248dbd4722  add rsp, 0x08
00007d248dbd4726  jmp 0x00007D248DBD013D
00007d248dbd472b  sub rsp, 0x08
00007d248dbd472f  push rax
00007d248dbd4730  push rcx
00007d248dbd4731  push rdx
00007d248dbd4732  push rdi
00007d248dbd4733  push rsi
00007d248dbd4734  push r8
00007d248dbd4736  push r9
00007d248dbd4738  push r10
00007d248dbd473a  push r11
00007d248dbd473c  sub rsp, 0xF0
00007d248dbd4743  vmovaps [rsp], xmm0
00007d248dbd4748  vmovaps [rsp+0x10], xmm1
00007d248dbd474e  vmovaps [rsp+0x20], xmm2
00007d248dbd4754  vmovaps [rsp+0x30], xmm3
00007d248dbd475a  vmovaps [rsp+0x40], xmm4
00007d248dbd4760  vmovaps [rsp+0x50], xmm5
00007d248dbd4766  vmovaps [rsp+0x60], xmm6
00007d248dbd476c  vmovaps [rsp+0x70], xmm7
00007d248dbd4772  vmovaps [rsp+0x80], xmm8
00007d248dbd477b  vmovaps [rsp+0x90], xmm9
00007d248dbd4784  vmovaps [rsp+0xA0], xmm11
00007d248dbd478d  vmovaps [rsp+0xB0], xmm12
00007d248dbd4796  vmovaps [rsp+0xC0], xmm13
00007d248dbd479f  vmovaps [rsp+0xD0], xmm14
00007d248dbd47a8  vmovaps [rsp+0xE0], xmm15
00007d248dbd47b1  sub rsp, 0x30
00007d248dbd47b5  movaps [rsp], xmm10
00007d248dbd47ba  movaps [rsp+0x10], xmm7
00007d248dbd47bf  movaps [rsp+0x20], xmm13
00007d248dbd47c5  lea rdi, [rsp]
00007d248dbd47c9  mov esi, 0x00
00007d248dbd47ce  mov rax, 0x5BCEEF236530
00007d248dbd47d8  call rax
00007d248dbd47da  movaps xmm10, [rsp]
00007d248dbd47df  add rsp, 0x30
00007d248dbd47e3  vmovaps xmm0, [rsp]
00007d248dbd47e8  vmovaps xmm1, [rsp+0x10]
00007d248dbd47ee  vmovaps xmm2, [rsp+0x20]
00007d248dbd47f4  vmovaps xmm3, [rsp+0x30]
00007d248dbd47fa  vmovaps xmm4, [rsp+0x40]
00007d248dbd4800  vmovaps xmm5, [rsp+0x50]
00007d248dbd4806  vmovaps xmm6, [rsp+0x60]
00007d248dbd480c  vmovaps xmm7, [rsp+0x70]
00007d248dbd4812  vmovaps xmm8, [rsp+0x80]
00007d248dbd481b  vmovaps xmm9, [rsp+0x90]
00007d248dbd4824  vmovaps xmm11, [rsp+0xA0]
00007d248dbd482d  vmovaps xmm12, [rsp+0xB0]
00007d248dbd4836  vmovaps xmm13, [rsp+0xC0]
00007d248dbd483f  vmovaps xmm14, [rsp+0xD0]
00007d248dbd4848  vmovaps xmm15, [rsp+0xE0]
00007d248dbd4851  add rsp, 0xF0
00007d248dbd4858  pop r11
00007d248dbd485a  pop r10
00007d248dbd485c  pop r9
00007d248dbd485e  pop r8
00007d248dbd4860  pop rsi
00007d248dbd4861  pop rdi
00007d248dbd4862  pop rdx
00007d248dbd4863  pop rcx
00007d248dbd4864  pop rax
00007d248dbd4865  add rsp, 0x08
00007d248dbd4869  jmp 0x00007D248DBD0169
00007d248dbd486e  sub rsp, 0x08
00007d248dbd4872  push rax
00007d248dbd4873  push rcx
00007d248dbd4874  push rdx
00007d248dbd4875  push rdi
00007d248dbd4876  push rsi
00007d248dbd4877  push r8
00007d248dbd4879  push r9
00007d248dbd487b  push r10
00007d248dbd487d  push r11
00007d248dbd487f  sub rsp, 0xF0
00007d248dbd4886  vmovaps [rsp], xmm0
00007d248dbd488b  vmovaps [rsp+0x10], xmm1
00007d248dbd4891  vmovaps [rsp+0x20], xmm2
00007d248dbd4897  vmovaps [rsp+0x30], xmm3
00007d248dbd489d  vmovaps [rsp+0x40], xmm4
00007d248dbd48a3  vmovaps [rsp+0x50], xmm5
00007d248dbd48a9  vmovaps [rsp+0x60], xmm6
00007d248dbd48af  vmovaps [rsp+0x70], xmm7
00007d248dbd48b5  vmovaps [rsp+0x80], xmm8
00007d248dbd48be  vmovaps [rsp+0x90], xmm9
00007d248dbd48c7  vmovaps [rsp+0xA0], xmm10
00007d248dbd48d0  vmovaps [rsp+0xB0], xmm11
00007d248dbd48d9  vmovaps [rsp+0xC0], xmm12
00007d248dbd48e2  vmovaps [rsp+0xD0], xmm14
00007d248dbd48eb  vmovaps [rsp+0xE0], xmm15
00007d248dbd48f4  sub rsp, 0x30
00007d248dbd48f8  movaps [rsp], xmm13
00007d248dbd48fd  movaps [rsp+0x10], xmm1
00007d248dbd4902  movaps [rsp+0x20], xmm8
00007d248dbd4908  lea rdi, [rsp]
00007d248dbd490c  mov esi, 0x00
00007d248dbd4911  mov rax, 0x5BCEEF236530
00007d248dbd491b  call rax
00007d248dbd491d  movaps xmm13, [rsp]
00007d248dbd4922  add rsp, 0x30
00007d248dbd4926  vmovaps xmm0, [rsp]
00007d248dbd492b  vmovaps xmm1, [rsp+0x10]
00007d248dbd4931  vmovaps xmm2, [rsp+0x20]
00007d248dbd4937  vmovaps xmm3, [rsp+0x30]
00007d248dbd493d  vmovaps xmm4, [rsp+0x40]
00007d248dbd4943  vmovaps xmm5, [rsp+0x50]
00007d248dbd4949  vmovaps xmm6, [rsp+0x60]
00007d248dbd494f  vmovaps xmm7, [rsp+0x70]
00007d248dbd4955  vmovaps xmm8, [rsp+0x80]
00007d248dbd495e  vmovaps xmm9, [rsp+0x90]
00007d248dbd4967  vmovaps xmm10, [rsp+0xA0]
00007d248dbd4970  vmovaps xmm11, [rsp+0xB0]
00007d248dbd4979  vmovaps xmm12, [rsp+0xC0]
00007d248dbd4982  vmovaps xmm14, [rsp+0xD0]
00007d248dbd498b  vmovaps xmm15, [rsp+0xE0]
00007d248dbd4994  add rsp, 0xF0
00007d248dbd499b  pop r11
00007d248dbd499d  pop r10
00007d248dbd499f  pop r9
00007d248dbd49a1  pop r8
00007d248dbd49a3  pop rsi
00007d248dbd49a4  pop rdi
00007d248dbd49a5  pop rdx
00007d248dbd49a6  pop rcx
00007d248dbd49a7  pop rax
00007d248dbd49a8  add rsp, 0x08
00007d248dbd49ac  jmp 0x00007D248DBD0183
00007d248dbd49b1  call 0x00007D248D9FF430
00007d248dbd49b6  jmp 0x00007D248DBD018D
00007d248dbd49bb  sub rsp, 0x08
00007d248dbd49bf  push rax
00007d248dbd49c0  push rcx
00007d248dbd49c1  push rdx
00007d248dbd49c2  push rdi
00007d248dbd49c3  push rsi
00007d248dbd49c4  push r8
00007d248dbd49c6  push r9
00007d248dbd49c8  push r10
00007d248dbd49ca  push r11
00007d248dbd49cc  sub rsp, 0xF0
00007d248dbd49d3  vmovaps [rsp], xmm0
00007d248dbd49d8  vmovaps [rsp+0x10], xmm1
00007d248dbd49de  vmovaps [rsp+0x20], xmm2
00007d248dbd49e4  vmovaps [rsp+0x30], xmm3
00007d248dbd49ea  vmovaps [rsp+0x40], xmm4
00007d248dbd49f0  vmovaps [rsp+0x50], xmm5
00007d248dbd49f6  vmovaps [rsp+0x60], xmm6
00007d248dbd49fc  vmovaps [rsp+0x70], xmm7
00007d248dbd4a02  vmovaps [rsp+0x80], xmm9
00007d248dbd4a0b  vmovaps [rsp+0x90], xmm10
00007d248dbd4a14  vmovaps [rsp+0xA0], xmm11
00007d248dbd4a1d  vmovaps [rsp+0xB0], xmm12
00007d248dbd4a26  vmovaps [rsp+0xC0], xmm13
00007d248dbd4a2f  vmovaps [rsp+0xD0], xmm14
00007d248dbd4a38  vmovaps [rsp+0xE0], xmm15
00007d248dbd4a41  sub rsp, 0x30
00007d248dbd4a45  movaps [rsp], xmm8
00007d248dbd4a4a  movaps [rsp+0x10], xmm14
00007d248dbd4a50  movaps [rsp+0x20], xmm9
00007d248dbd4a56  lea rdi, [rsp]
00007d248dbd4a5a  mov esi, 0x00
00007d248dbd4a5f  mov rax, 0x5BCEEF236530
00007d248dbd4a69  call rax
00007d248dbd4a6b  movaps xmm8, [rsp]
00007d248dbd4a70  add rsp, 0x30
00007d248dbd4a74  vmovaps xmm0, [rsp]
00007d248dbd4a79  vmovaps xmm1, [rsp+0x10]
00007d248dbd4a7f  vmovaps xmm2, [rsp+0x20]
00007d248dbd4a85  vmovaps xmm3, [rsp+0x30]
00007d248dbd4a8b  vmovaps xmm4, [rsp+0x40]
00007d248dbd4a91  vmovaps xmm5, [rsp+0x50]
00007d248dbd4a97  vmovaps xmm6, [rsp+0x60]
00007d248dbd4a9d  vmovaps xmm7, [rsp+0x70]
00007d248dbd4aa3  vmovaps xmm9, [rsp+0x80]
00007d248dbd4aac  vmovaps xmm10, [rsp+0x90]
00007d248dbd4ab5  vmovaps xmm11, [rsp+0xA0]
00007d248dbd4abe  vmovaps xmm12, [rsp+0xB0]
00007d248dbd4ac7  vmovaps xmm13, [rsp+0xC0]
00007d248dbd4ad0  vmovaps xmm14, [rsp+0xD0]
00007d248dbd4ad9  vmovaps xmm15, [rsp+0xE0]
00007d248dbd4ae2  add rsp, 0xF0
00007d248dbd4ae9  pop r11
00007d248dbd4aeb  pop r10
00007d248dbd4aed  pop r9
00007d248dbd4aef  pop r8
00007d248dbd4af1  pop rsi
00007d248dbd4af2  pop rdi
00007d248dbd4af3  pop rdx
00007d248dbd4af4  pop rcx
00007d248dbd4af5  pop rax
00007d248dbd4af6  add rsp, 0x08
00007d248dbd4afa  jmp 0x00007D248DBD01AF
00007d248dbd4aff  sub rsp, 0x08
00007d248dbd4b03  push rax
00007d248dbd4b04  push rcx
00007d248dbd4b05  push rdx
00007d248dbd4b06  push rdi
00007d248dbd4b07  push rsi
00007d248dbd4b08  push r8
00007d248dbd4b0a  push r9
00007d248dbd4b0c  push r10
00007d248dbd4b0e  push r11
00007d248dbd4b10  sub rsp, 0xF0
00007d248dbd4b17  vmovaps [rsp], xmm0
00007d248dbd4b1c  vmovaps [rsp+0x10], xmm1
00007d248dbd4b22  vmovaps [rsp+0x20], xmm2
00007d248dbd4b28  vmovaps [rsp+0x30], xmm3
00007d248dbd4b2e  vmovaps [rsp+0x40], xmm4
00007d248dbd4b34  vmovaps [rsp+0x50], xmm5
00007d248dbd4b3a  vmovaps [rsp+0x60], xmm6
00007d248dbd4b40  vmovaps [rsp+0x70], xmm7
00007d248dbd4b46  vmovaps [rsp+0x80], xmm8
00007d248dbd4b4f  vmovaps [rsp+0x90], xmm10
00007d248dbd4b58  vmovaps [rsp+0xA0], xmm11
00007d248dbd4b61  vmovaps [rsp+0xB0], xmm12
00007d248dbd4b6a  vmovaps [rsp+0xC0], xmm13
00007d248dbd4b73  vmovaps [rsp+0xD0], xmm14
00007d248dbd4b7c  vmovaps [rsp+0xE0], xmm15
00007d248dbd4b85  sub rsp, 0x30
00007d248dbd4b89  movaps [rsp], xmm9
00007d248dbd4b8e  movaps [rsp+0x10], xmm1
00007d248dbd4b93  movaps [rsp+0x20], xmm14
00007d248dbd4b99  lea rdi, [rsp]
00007d248dbd4b9d  mov esi, 0x00
00007d248dbd4ba2  mov rax, 0x5BCEEF236530
00007d248dbd4bac  call rax
00007d248dbd4bae  movaps xmm9, [rsp]
00007d248dbd4bb3  add rsp, 0x30
00007d248dbd4bb7  vmovaps xmm0, [rsp]
00007d248dbd4bbc  vmovaps xmm1, [rsp+0x10]
00007d248dbd4bc2  vmovaps xmm2, [rsp+0x20]
00007d248dbd4bc8  vmovaps xmm3, [rsp+0x30]
00007d248dbd4bce  vmovaps xmm4, [rsp+0x40]
00007d248dbd4bd4  vmovaps xmm5, [rsp+0x50]
00007d248dbd4bda  vmovaps xmm6, [rsp+0x60]
00007d248dbd4be0  vmovaps xmm7, [rsp+0x70]
00007d248dbd4be6  vmovaps xmm8, [rsp+0x80]
00007d248dbd4bef  vmovaps xmm10, [rsp+0x90]
00007d248dbd4bf8  vmovaps xmm11, [rsp+0xA0]
00007d248dbd4c01  vmovaps xmm12, [rsp+0xB0]
00007d248dbd4c0a  vmovaps xmm13, [rsp+0xC0]
00007d248dbd4c13  vmovaps xmm14, [rsp+0xD0]
00007d248dbd4c1c  vmovaps xmm15, [rsp+0xE0]
00007d248dbd4c25  add rsp, 0xF0
00007d248dbd4c2c  pop r11
00007d248dbd4c2e  pop r10
00007d248dbd4c30  pop r9
00007d248dbd4c32  pop r8
00007d248dbd4c34  pop rsi
00007d248dbd4c35  pop rdi
00007d248dbd4c36  pop rdx
00007d248dbd4c37  pop rcx
00007d248dbd4c38  pop rax
00007d248dbd4c39  add rsp, 0x08
00007d248dbd4c3d  jmp 0x00007D248DBD01DD
00007d248dbd4c42  sub rsp, 0x08
00007d248dbd4c46  push rax
00007d248dbd4c47  push rcx
00007d248dbd4c48  push rdx
00007d248dbd4c49  push rdi
00007d248dbd4c4a  push rsi
00007d248dbd4c4b  push r8
00007d248dbd4c4d  push r9
00007d248dbd4c4f  push r10
00007d248dbd4c51  push r11
00007d248dbd4c53  sub rsp, 0xF0
00007d248dbd4c5a  vmovaps [rsp], xmm0
00007d248dbd4c5f  vmovaps [rsp+0x10], xmm1
00007d248dbd4c65  vmovaps [rsp+0x20], xmm2
00007d248dbd4c6b  vmovaps [rsp+0x30], xmm3
00007d248dbd4c71  vmovaps [rsp+0x40], xmm4
00007d248dbd4c77  vmovaps [rsp+0x50], xmm5
00007d248dbd4c7d  vmovaps [rsp+0x60], xmm6
00007d248dbd4c83  vmovaps [rsp+0x70], xmm7
00007d248dbd4c89  vmovaps [rsp+0x80], xmm8
00007d248dbd4c92  vmovaps [rsp+0x90], xmm9
00007d248dbd4c9b  vmovaps [rsp+0xA0], xmm10
00007d248dbd4ca4  vmovaps [rsp+0xB0], xmm11
00007d248dbd4cad  vmovaps [rsp+0xC0], xmm12
00007d248dbd4cb6  vmovaps [rsp+0xD0], xmm13
00007d248dbd4cbf  vmovaps [rsp+0xE0], xmm15
00007d248dbd4cc8  sub rsp, 0x30
00007d248dbd4ccc  movaps [rsp], xmm14
00007d248dbd4cd1  movaps [rsp+0x10], xmm4
00007d248dbd4cd6  movaps [rsp+0x20], xmm1
00007d248dbd4cdb  lea rdi, [rsp]
00007d248dbd4cdf  mov esi, 0x00
00007d248dbd4ce4  mov rax, 0x5BCEEF236530
00007d248dbd4cee  call rax
00007d248dbd4cf0  movaps xmm14, [rsp]
00007d248dbd4cf5  add rsp, 0x30
00007d248dbd4cf9  vmovaps xmm0, [rsp]
00007d248dbd4cfe  vmovaps xmm1, [rsp+0x10]
00007d248dbd4d04  vmovaps xmm2, [rsp+0x20]
00007d248dbd4d0a  vmovaps xmm3, [rsp+0x30]
00007d248dbd4d10  vmovaps xmm4, [rsp+0x40]
00007d248dbd4d16  vmovaps xmm5, [rsp+0x50]
00007d248dbd4d1c  vmovaps xmm6, [rsp+0x60]
00007d248dbd4d22  vmovaps xmm7, [rsp+0x70]
00007d248dbd4d28  vmovaps xmm8, [rsp+0x80]
00007d248dbd4d31  vmovaps xmm9, [rsp+0x90]
00007d248dbd4d3a  vmovaps xmm10, [rsp+0xA0]
00007d248dbd4d43  vmovaps xmm11, [rsp+0xB0]
00007d248dbd4d4c  vmovaps xmm12, [rsp+0xC0]
00007d248dbd4d55  vmovaps xmm13, [rsp+0xD0]
00007d248dbd4d5e  vmovaps xmm15, [rsp+0xE0]
00007d248dbd4d67  add rsp, 0xF0
00007d248dbd4d6e  pop r11
00007d248dbd4d70  pop r10
00007d248dbd4d72  pop r9
00007d248dbd4d74  pop r8
00007d248dbd4d76  pop rsi
00007d248dbd4d77  pop rdi
00007d248dbd4d78  pop rdx
00007d248dbd4d79  pop rcx
00007d248dbd4d7a  pop rax
00007d248dbd4d7b  add rsp, 0x08
00007d248dbd4d7f  jmp 0x00007D248DBD0203
00007d248dbd4d84  sub rsp, 0x08
00007d248dbd4d88  push rax
00007d248dbd4d89  push rcx
00007d248dbd4d8a  push rdx
00007d248dbd4d8b  push rdi
00007d248dbd4d8c  push rsi
00007d248dbd4d8d  push r8
00007d248dbd4d8f  push r9
00007d248dbd4d91  push r10
00007d248dbd4d93  push r11
00007d248dbd4d95  sub rsp, 0xF0
00007d248dbd4d9c  vmovaps [rsp], xmm0
00007d248dbd4da1  vmovaps [rsp+0x10], xmm2
00007d248dbd4da7  vmovaps [rsp+0x20], xmm3
00007d248dbd4dad  vmovaps [rsp+0x30], xmm4
00007d248dbd4db3  vmovaps [rsp+0x40], xmm5
00007d248dbd4db9  vmovaps [rsp+0x50], xmm6
00007d248dbd4dbf  vmovaps [rsp+0x60], xmm7
00007d248dbd4dc5  vmovaps [rsp+0x70], xmm8
00007d248dbd4dcb  vmovaps [rsp+0x80], xmm9
00007d248dbd4dd4  vmovaps [rsp+0x90], xmm10
00007d248dbd4ddd  vmovaps [rsp+0xA0], xmm11
00007d248dbd4de6  vmovaps [rsp+0xB0], xmm12
00007d248dbd4def  vmovaps [rsp+0xC0], xmm13
00007d248dbd4df8  vmovaps [rsp+0xD0], xmm14
00007d248dbd4e01  vmovaps [rsp+0xE0], xmm15
00007d248dbd4e0a  sub rsp, 0x30
00007d248dbd4e0e  movaps [rsp], xmm1
00007d248dbd4e12  movaps [rsp+0x10], xmm12
00007d248dbd4e18  movaps [rsp+0x20], xmm11
00007d248dbd4e1e  lea rdi, [rsp]
00007d248dbd4e22  mov esi, 0x00
00007d248dbd4e27  mov rax, 0x5BCEEF236530
00007d248dbd4e31  call rax
00007d248dbd4e33  movaps xmm1, [rsp]
00007d248dbd4e37  add rsp, 0x30
00007d248dbd4e3b  vmovaps xmm0, [rsp]
00007d248dbd4e40  vmovaps xmm2, [rsp+0x10]
00007d248dbd4e46  vmovaps xmm3, [rsp+0x20]
00007d248dbd4e4c  vmovaps xmm4, [rsp+0x30]
00007d248dbd4e52  vmovaps xmm5, [rsp+0x40]
00007d248dbd4e58  vmovaps xmm6, [rsp+0x50]
00007d248dbd4e5e  vmovaps xmm7, [rsp+0x60]
00007d248dbd4e64  vmovaps xmm8, [rsp+0x70]
00007d248dbd4e6a  vmovaps xmm9, [rsp+0x80]
00007d248dbd4e73  vmovaps xmm10, [rsp+0x90]
00007d248dbd4e7c  vmovaps xmm11, [rsp+0xA0]
00007d248dbd4e85  vmovaps xmm12, [rsp+0xB0]
00007d248dbd4e8e  vmovaps xmm13, [rsp+0xC0]
00007d248dbd4e97  vmovaps xmm14, [rsp+0xD0]
00007d248dbd4ea0  vmovaps xmm15, [rsp+0xE0]
00007d248dbd4ea9  add rsp, 0xF0
00007d248dbd4eb0  pop r11
00007d248dbd4eb2  pop r10
00007d248dbd4eb4  pop r9
00007d248dbd4eb6  pop r8
00007d248dbd4eb8  pop rsi
00007d248dbd4eb9  pop rdi
00007d248dbd4eba  pop rdx
00007d248dbd4ebb  pop rcx
00007d248dbd4ebc  pop rax
00007d248dbd4ebd  add rsp, 0x08
00007d248dbd4ec1  jmp 0x00007D248DBD0224
00007d248dbd4ec6  call 0x00007D248DAE20A0
00007d248dbd4ecb  jmp 0x00007D248DBD0232
00007d248dbd4ed0  call 0x00007D248DA09D70
00007d248dbd4ed5  jmp 0x00007D248DBD023C
00007d248dbd4eda  sub rsp, 0x08
00007d248dbd4ede  push rax
00007d248dbd4edf  push rcx
00007d248dbd4ee0  push rdx
00007d248dbd4ee1  push rdi
00007d248dbd4ee2  push rsi
00007d248dbd4ee3  push r8
00007d248dbd4ee5  push r9
00007d248dbd4ee7  push r10
00007d248dbd4ee9  push r11
00007d248dbd4eeb  sub rsp, 0xF0
00007d248dbd4ef2  vmovaps [rsp], xmm0
00007d248dbd4ef7  vmovaps [rsp+0x10], xmm1
00007d248dbd4efd  vmovaps [rsp+0x20], xmm2
00007d248dbd4f03  vmovaps [rsp+0x30], xmm3
00007d248dbd4f09  vmovaps [rsp+0x40], xmm4
00007d248dbd4f0f  vmovaps [rsp+0x50], xmm5
00007d248dbd4f15  vmovaps [rsp+0x60], xmm6
00007d248dbd4f1b  vmovaps [rsp+0x70], xmm8
00007d248dbd4f21  vmovaps [rsp+0x80], xmm9
00007d248dbd4f2a  vmovaps [rsp+0x90], xmm10
00007d248dbd4f33  vmovaps [rsp+0xA0], xmm11
00007d248dbd4f3c  vmovaps [rsp+0xB0], xmm12
00007d248dbd4f45  vmovaps [rsp+0xC0], xmm13
00007d248dbd4f4e  vmovaps [rsp+0xD0], xmm14
00007d248dbd4f57  vmovaps [rsp+0xE0], xmm15
00007d248dbd4f60  sub rsp, 0x30
00007d248dbd4f64  movaps [rsp], xmm7
00007d248dbd4f68  movaps [rsp+0x10], xmm15
00007d248dbd4f6e  movaps [rsp+0x20], xmm10
00007d248dbd4f74  lea rdi, [rsp]
00007d248dbd4f78  mov esi, 0x00
00007d248dbd4f7d  mov rax, 0x5BCEEF236530
00007d248dbd4f87  call rax
00007d248dbd4f89  movaps xmm7, [rsp]
00007d248dbd4f8d  add rsp, 0x30
00007d248dbd4f91  vmovaps xmm0, [rsp]
00007d248dbd4f96  vmovaps xmm1, [rsp+0x10]
00007d248dbd4f9c  vmovaps xmm2, [rsp+0x20]
00007d248dbd4fa2  vmovaps xmm3, [rsp+0x30]
00007d248dbd4fa8  vmovaps xmm4, [rsp+0x40]
00007d248dbd4fae  vmovaps xmm5, [rsp+0x50]
00007d248dbd4fb4  vmovaps xmm6, [rsp+0x60]
00007d248dbd4fba  vmovaps xmm8, [rsp+0x70]
00007d248dbd4fc0  vmovaps xmm9, [rsp+0x80]
00007d248dbd4fc9  vmovaps xmm10, [rsp+0x90]
00007d248dbd4fd2  vmovaps xmm11, [rsp+0xA0]
00007d248dbd4fdb  vmovaps xmm12, [rsp+0xB0]
00007d248dbd4fe4  vmovaps xmm13, [rsp+0xC0]
00007d248dbd4fed  vmovaps xmm14, [rsp+0xD0]
00007d248dbd4ff6  vmovaps xmm15, [rsp+0xE0]
00007d248dbd4fff  add rsp, 0xF0
00007d248dbd5006  pop r11
00007d248dbd5008  pop r10
00007d248dbd500a  pop r9
00007d248dbd500c  pop r8
00007d248dbd500e  pop rsi
00007d248dbd500f  pop rdi
00007d248dbd5010  pop rdx
00007d248dbd5011  pop rcx
00007d248dbd5012  pop rax
00007d248dbd5013  add rsp, 0x08
00007d248dbd5017  jmp 0x00007D248DBD025D
00007d248dbd501c  sub rsp, 0x08
00007d248dbd5020  push rax
00007d248dbd5021  push rcx
00007d248dbd5022  push rdx
00007d248dbd5023  push rdi
00007d248dbd5024  push rsi
00007d248dbd5025  push r8
00007d248dbd5027  push r9
00007d248dbd5029  push r10
00007d248dbd502b  push r11
00007d248dbd502d  sub rsp, 0xF0
00007d248dbd5034  vmovaps [rsp], xmm0
00007d248dbd5039  vmovaps [rsp+0x10], xmm1
00007d248dbd503f  vmovaps [rsp+0x20], xmm2
00007d248dbd5045  vmovaps [rsp+0x30], xmm3
00007d248dbd504b  vmovaps [rsp+0x40], xmm4
00007d248dbd5051  vmovaps [rsp+0x50], xmm5
00007d248dbd5057  vmovaps [rsp+0x60], xmm6
00007d248dbd505d  vmovaps [rsp+0x70], xmm7
00007d248dbd5063  vmovaps [rsp+0x80], xmm8
00007d248dbd506c  vmovaps [rsp+0x90], xmm9
00007d248dbd5075  vmovaps [rsp+0xA0], xmm11
00007d248dbd507e  vmovaps [rsp+0xB0], xmm12
00007d248dbd5087  vmovaps [rsp+0xC0], xmm13
00007d248dbd5090  vmovaps [rsp+0xD0], xmm14
00007d248dbd5099  vmovaps [rsp+0xE0], xmm15
00007d248dbd50a2  sub rsp, 0x30
00007d248dbd50a6  movaps [rsp], xmm10
00007d248dbd50ab  movaps [rsp+0x10], xmm11
00007d248dbd50b1  movaps [rsp+0x20], xmm15
00007d248dbd50b7  lea rdi, [rsp]
00007d248dbd50bb  mov esi, 0x00
00007d248dbd50c0  mov rax, 0x5BCEEF236530
00007d248dbd50ca  call rax
00007d248dbd50cc  movaps xmm10, [rsp]
00007d248dbd50d1  add rsp, 0x30
00007d248dbd50d5  vmovaps xmm0, [rsp]
00007d248dbd50da  vmovaps xmm1, [rsp+0x10]
00007d248dbd50e0  vmovaps xmm2, [rsp+0x20]
00007d248dbd50e6  vmovaps xmm3, [rsp+0x30]
00007d248dbd50ec  vmovaps xmm4, [rsp+0x40]
00007d248dbd50f2  vmovaps xmm5, [rsp+0x50]
00007d248dbd50f8  vmovaps xmm6, [rsp+0x60]
00007d248dbd50fe  vmovaps xmm7, [rsp+0x70]
00007d248dbd5104  vmovaps xmm8, [rsp+0x80]
00007d248dbd510d  vmovaps xmm9, [rsp+0x90]
00007d248dbd5116  vmovaps xmm11, [rsp+0xA0]
00007d248dbd511f  vmovaps xmm12, [rsp+0xB0]
00007d248dbd5128  vmovaps xmm13, [rsp+0xC0]
00007d248dbd5131  vmovaps xmm14, [rsp+0xD0]
00007d248dbd513a  vmovaps xmm15, [rsp+0xE0]
00007d248dbd5143  add rsp, 0xF0
00007d248dbd514a  pop r11
00007d248dbd514c  pop r10
00007d248dbd514e  pop r9
00007d248dbd5150  pop r8
00007d248dbd5152  pop rsi
00007d248dbd5153  pop rdi
00007d248dbd5154  pop rdx
00007d248dbd5155  pop rcx
00007d248dbd5156  pop rax
00007d248dbd5157  add rsp, 0x08
00007d248dbd515b  jmp 0x00007D248DBD028B
00007d248dbd5160  sub rsp, 0x08
00007d248dbd5164  push rax
00007d248dbd5165  push rcx
00007d248dbd5166  push rdx
00007d248dbd5167  push rdi
00007d248dbd5168  push rsi
00007d248dbd5169  push r8
00007d248dbd516b  push r9
00007d248dbd516d  push r10
00007d248dbd516f  push r11
00007d248dbd5171  sub rsp, 0xF0
00007d248dbd5178  vmovaps [rsp], xmm0
00007d248dbd517d  vmovaps [rsp+0x10], xmm1
00007d248dbd5183  vmovaps [rsp+0x20], xmm2
00007d248dbd5189  vmovaps [rsp+0x30], xmm3
00007d248dbd518f  vmovaps [rsp+0x40], xmm4
00007d248dbd5195  vmovaps [rsp+0x50], xmm5
00007d248dbd519b  vmovaps [rsp+0x60], xmm6
00007d248dbd51a1  vmovaps [rsp+0x70], xmm7
00007d248dbd51a7  vmovaps [rsp+0x80], xmm8
00007d248dbd51b0  vmovaps [rsp+0x90], xmm9
00007d248dbd51b9  vmovaps [rsp+0xA0], xmm10
00007d248dbd51c2  vmovaps [rsp+0xB0], xmm12
00007d248dbd51cb  vmovaps [rsp+0xC0], xmm13
00007d248dbd51d4  vmovaps [rsp+0xD0], xmm14
00007d248dbd51dd  vmovaps [rsp+0xE0], xmm15
00007d248dbd51e6  sub rsp, 0x30
00007d248dbd51ea  movaps [rsp], xmm11
00007d248dbd51ef  movaps [rsp+0x10], xmm12
00007d248dbd51f5  movaps [rsp+0x20], xmm15
00007d248dbd51fb  lea rdi, [rsp]
00007d248dbd51ff  mov esi, 0x00
00007d248dbd5204  mov rax, 0x5BCEEF236530
00007d248dbd520e  call rax
00007d248dbd5210  movaps xmm11, [rsp]
00007d248dbd5215  add rsp, 0x30
00007d248dbd5219  vmovaps xmm0, [rsp]
00007d248dbd521e  vmovaps xmm1, [rsp+0x10]
00007d248dbd5224  vmovaps xmm2, [rsp+0x20]
00007d248dbd522a  vmovaps xmm3, [rsp+0x30]
00007d248dbd5230  vmovaps xmm4, [rsp+0x40]
00007d248dbd5236  vmovaps xmm5, [rsp+0x50]
00007d248dbd523c  vmovaps xmm6, [rsp+0x60]
00007d248dbd5242  vmovaps xmm7, [rsp+0x70]
00007d248dbd5248  vmovaps xmm8, [rsp+0x80]
00007d248dbd5251  vmovaps xmm9, [rsp+0x90]
00007d248dbd525a  vmovaps xmm10, [rsp+0xA0]
00007d248dbd5263  vmovaps xmm12, [rsp+0xB0]
00007d248dbd526c  vmovaps xmm13, [rsp+0xC0]
00007d248dbd5275  vmovaps xmm14, [rsp+0xD0]
00007d248dbd527e  vmovaps xmm15, [rsp+0xE0]
00007d248dbd5287  add rsp, 0xF0
00007d248dbd528e  pop r11
00007d248dbd5290  pop r10
00007d248dbd5292  pop r9
00007d248dbd5294  pop r8
00007d248dbd5296  pop rsi
00007d248dbd5297  pop rdi
00007d248dbd5298  pop rdx
00007d248dbd5299  pop rcx
00007d248dbd529a  pop rax
00007d248dbd529b  add rsp, 0x08
00007d248dbd529f  jmp 0x00007D248DBD02B9
00007d248dbd52a4  sub rsp, 0x08
00007d248dbd52a8  push rax
00007d248dbd52a9  push rcx
00007d248dbd52aa  push rdx
00007d248dbd52ab  push rdi
00007d248dbd52ac  push rsi
00007d248dbd52ad  push r8
00007d248dbd52af  push r9
00007d248dbd52b1  push r10
00007d248dbd52b3  push r11
00007d248dbd52b5  sub rsp, 0xF0
00007d248dbd52bc  vmovaps [rsp], xmm0
00007d248dbd52c1  vmovaps [rsp+0x10], xmm1
00007d248dbd52c7  vmovaps [rsp+0x20], xmm2
00007d248dbd52cd  vmovaps [rsp+0x30], xmm3
00007d248dbd52d3  vmovaps [rsp+0x40], xmm4
00007d248dbd52d9  vmovaps [rsp+0x50], xmm5
00007d248dbd52df  vmovaps [rsp+0x60], xmm6
00007d248dbd52e5  vmovaps [rsp+0x70], xmm7
00007d248dbd52eb  vmovaps [rsp+0x80], xmm8
00007d248dbd52f4  vmovaps [rsp+0x90], xmm9
00007d248dbd52fd  vmovaps [rsp+0xA0], xmm10
00007d248dbd5306  vmovaps [rsp+0xB0], xmm11
00007d248dbd530f  vmovaps [rsp+0xC0], xmm12
00007d248dbd5318  vmovaps [rsp+0xD0], xmm13
00007d248dbd5321  vmovaps [rsp+0xE0], xmm14
00007d248dbd532a  sub rsp, 0x30
00007d248dbd532e  movaps [rsp], xmm15
00007d248dbd5333  movaps [rsp+0x10], xmm13
00007d248dbd5339  movaps [rsp+0x20], xmm9
00007d248dbd533f  lea rdi, [rsp]
00007d248dbd5343  mov esi, 0x00
00007d248dbd5348  mov rax, 0x5BCEEF236530
00007d248dbd5352  call rax
00007d248dbd5354  movaps xmm15, [rsp]
00007d248dbd5359  add rsp, 0x30
00007d248dbd535d  vmovaps xmm0, [rsp]
00007d248dbd5362  vmovaps xmm1, [rsp+0x10]
00007d248dbd5368  vmovaps xmm2, [rsp+0x20]
00007d248dbd536e  vmovaps xmm3, [rsp+0x30]
00007d248dbd5374  vmovaps xmm4, [rsp+0x40]
00007d248dbd537a  vmovaps xmm5, [rsp+0x50]
00007d248dbd5380  vmovaps xmm6, [rsp+0x60]
00007d248dbd5386  vmovaps xmm7, [rsp+0x70]
00007d248dbd538c  vmovaps xmm8, [rsp+0x80]
00007d248dbd5395  vmovaps xmm9, [rsp+0x90]
00007d248dbd539e  vmovaps xmm10, [rsp+0xA0]
00007d248dbd53a7  vmovaps xmm11, [rsp+0xB0]
00007d248dbd53b0  vmovaps xmm12, [rsp+0xC0]
00007d248dbd53b9  vmovaps xmm13, [rsp+0xD0]
00007d248dbd53c2  vmovaps xmm14, [rsp+0xE0]
00007d248dbd53cb  add rsp, 0xF0
00007d248dbd53d2  pop r11
00007d248dbd53d4  pop r10
00007d248dbd53d6  pop r9
00007d248dbd53d8  pop r8
00007d248dbd53da  pop rsi
00007d248dbd53db  pop rdi
00007d248dbd53dc  pop rdx
00007d248dbd53dd  pop rcx
00007d248dbd53de  pop rax
00007d248dbd53df  add rsp, 0x08
00007d248dbd53e3  jmp 0x00007D248DBD02D4
00007d248dbd53e8  sub rsp, 0x08
00007d248dbd53ec  push rax
00007d248dbd53ed  push rcx
00007d248dbd53ee  push rdx
00007d248dbd53ef  push rdi
00007d248dbd53f0  push rsi
00007d248dbd53f1  push r8
00007d248dbd53f3  push r9
00007d248dbd53f5  push r10
00007d248dbd53f7  push r11
00007d248dbd53f9  sub rsp, 0xF0
00007d248dbd5400  vmovaps [rsp], xmm0
00007d248dbd5405  vmovaps [rsp+0x10], xmm1
00007d248dbd540b  vmovaps [rsp+0x20], xmm2
00007d248dbd5411  vmovaps [rsp+0x30], xmm3
00007d248dbd5417  vmovaps [rsp+0x40], xmm4
00007d248dbd541d  vmovaps [rsp+0x50], xmm5
00007d248dbd5423  vmovaps [rsp+0x60], xmm6
00007d248dbd5429  vmovaps [rsp+0x70], xmm7
00007d248dbd542f  vmovaps [rsp+0x80], xmm8
00007d248dbd5438  vmovaps [rsp+0x90], xmm9
00007d248dbd5441  vmovaps [rsp+0xA0], xmm10
00007d248dbd544a  vmovaps [rsp+0xB0], xmm11
00007d248dbd5453  vmovaps [rsp+0xC0], xmm12
00007d248dbd545c  vmovaps [rsp+0xD0], xmm14
00007d248dbd5465  vmovaps [rsp+0xE0], xmm15
00007d248dbd546e  sub rsp, 0x30
00007d248dbd5472  movaps [rsp], xmm13
00007d248dbd5477  movaps [rsp+0x10], xmm8
00007d248dbd547d  movaps [rsp+0x20], xmm14
00007d248dbd5483  lea rdi, [rsp]
00007d248dbd5487  mov esi, 0x00
00007d248dbd548c  mov rax, 0x5BCEEF236530
00007d248dbd5496  call rax
00007d248dbd5498  movaps xmm13, [rsp]
00007d248dbd549d  add rsp, 0x30
00007d248dbd54a1  vmovaps xmm0, [rsp]
00007d248dbd54a6  vmovaps xmm1, [rsp+0x10]
00007d248dbd54ac  vmovaps xmm2, [rsp+0x20]
00007d248dbd54b2  vmovaps xmm3, [rsp+0x30]
00007d248dbd54b8  vmovaps xmm4, [rsp+0x40]
00007d248dbd54be  vmovaps xmm5, [rsp+0x50]
00007d248dbd54c4  vmovaps xmm6, [rsp+0x60]
00007d248dbd54ca  vmovaps xmm7, [rsp+0x70]
00007d248dbd54d0  vmovaps xmm8, [rsp+0x80]
00007d248dbd54d9  vmovaps xmm9, [rsp+0x90]
00007d248dbd54e2  vmovaps xmm10, [rsp+0xA0]
00007d248dbd54eb  vmovaps xmm11, [rsp+0xB0]
00007d248dbd54f4  vmovaps xmm12, [rsp+0xC0]
00007d248dbd54fd  vmovaps xmm14, [rsp+0xD0]
00007d248dbd5506  vmovaps xmm15, [rsp+0xE0]
00007d248dbd550f  add rsp, 0xF0
00007d248dbd5516  pop r11
00007d248dbd5518  pop r10
00007d248dbd551a  pop r9
00007d248dbd551c  pop r8
00007d248dbd551e  pop rsi
00007d248dbd551f  pop rdi
00007d248dbd5520  pop rdx
00007d248dbd5521  pop rcx
00007d248dbd5522  pop rax
00007d248dbd5523  add rsp, 0x08
00007d248dbd5527  jmp 0x00007D248DBD02F7
00007d248dbd552c  sub rsp, 0x08
00007d248dbd5530  push rax
00007d248dbd5531  push rcx
00007d248dbd5532  push rdx
00007d248dbd5533  push rdi
00007d248dbd5534  push rsi
00007d248dbd5535  push r8
00007d248dbd5537  push r9
00007d248dbd5539  push r10
00007d248dbd553b  push r11
00007d248dbd553d  sub rsp, 0xF0
00007d248dbd5544  vmovaps [rsp], xmm0
00007d248dbd5549  vmovaps [rsp+0x10], xmm1
00007d248dbd554f  vmovaps [rsp+0x20], xmm2
00007d248dbd5555  vmovaps [rsp+0x30], xmm3
00007d248dbd555b  vmovaps [rsp+0x40], xmm4
00007d248dbd5561  vmovaps [rsp+0x50], xmm5
00007d248dbd5567  vmovaps [rsp+0x60], xmm6
00007d248dbd556d  vmovaps [rsp+0x70], xmm7
00007d248dbd5573  vmovaps [rsp+0x80], xmm8
00007d248dbd557c  vmovaps [rsp+0x90], xmm9
00007d248dbd5585  vmovaps [rsp+0xA0], xmm10
00007d248dbd558e  vmovaps [rsp+0xB0], xmm11
00007d248dbd5597  vmovaps [rsp+0xC0], xmm12
00007d248dbd55a0  vmovaps [rsp+0xD0], xmm13
00007d248dbd55a9  vmovaps [rsp+0xE0], xmm15
00007d248dbd55b2  sub rsp, 0x30
00007d248dbd55b6  movaps [rsp], xmm14
00007d248dbd55bb  movaps [rsp+0x10], xmm1
00007d248dbd55c0  movaps [rsp+0x20], xmm10
00007d248dbd55c6  lea rdi, [rsp]
00007d248dbd55ca  mov esi, 0x00
00007d248dbd55cf  mov rax, 0x5BCEEF236530
00007d248dbd55d9  call rax
00007d248dbd55db  movaps xmm14, [rsp]
00007d248dbd55e0  add rsp, 0x30
00007d248dbd55e4  vmovaps xmm0, [rsp]
00007d248dbd55e9  vmovaps xmm1, [rsp+0x10]
00007d248dbd55ef  vmovaps xmm2, [rsp+0x20]
00007d248dbd55f5  vmovaps xmm3, [rsp+0x30]
00007d248dbd55fb  vmovaps xmm4, [rsp+0x40]
00007d248dbd5601  vmovaps xmm5, [rsp+0x50]
00007d248dbd5607  vmovaps xmm6, [rsp+0x60]
00007d248dbd560d  vmovaps xmm7, [rsp+0x70]
00007d248dbd5613  vmovaps xmm8, [rsp+0x80]
00007d248dbd561c  vmovaps xmm9, [rsp+0x90]
00007d248dbd5625  vmovaps xmm10, [rsp+0xA0]
00007d248dbd562e  vmovaps xmm11, [rsp+0xB0]
00007d248dbd5637  vmovaps xmm12, [rsp+0xC0]
00007d248dbd5640  vmovaps xmm13, [rsp+0xD0]
00007d248dbd5649  vmovaps xmm15, [rsp+0xE0]
00007d248dbd5652  add rsp, 0xF0
00007d248dbd5659  pop r11
00007d248dbd565b  pop r10
00007d248dbd565d  pop r9
00007d248dbd565f  pop r8
00007d248dbd5661  pop rsi
00007d248dbd5662  pop rdi
00007d248dbd5663  pop rdx
00007d248dbd5664  pop rcx
00007d248dbd5665  pop rax
00007d248dbd5666  add rsp, 0x08
00007d248dbd566a  jmp 0x00007D248DBD031A
00007d248dbd566f  sub rsp, 0x08
00007d248dbd5673  push rax
00007d248dbd5674  push rcx
00007d248dbd5675  push rdx
00007d248dbd5676  push rdi
00007d248dbd5677  push rsi
00007d248dbd5678  push r8
00007d248dbd567a  push r9
00007d248dbd567c  push r10
00007d248dbd567e  push r11
00007d248dbd5680  sub rsp, 0xF0
00007d248dbd5687  vmovaps [rsp], xmm0
00007d248dbd568c  vmovaps [rsp+0x10], xmm2
00007d248dbd5692  vmovaps [rsp+0x20], xmm3
00007d248dbd5698  vmovaps [rsp+0x30], xmm4
00007d248dbd569e  vmovaps [rsp+0x40], xmm5
00007d248dbd56a4  vmovaps [rsp+0x50], xmm6
00007d248dbd56aa  vmovaps [rsp+0x60], xmm7
00007d248dbd56b0  vmovaps [rsp+0x70], xmm8
00007d248dbd56b6  vmovaps [rsp+0x80], xmm9
00007d248dbd56bf  vmovaps [rsp+0x90], xmm10
00007d248dbd56c8  vmovaps [rsp+0xA0], xmm11
00007d248dbd56d1  vmovaps [rsp+0xB0], xmm12
00007d248dbd56da  vmovaps [rsp+0xC0], xmm13
00007d248dbd56e3  vmovaps [rsp+0xD0], xmm14
00007d248dbd56ec  vmovaps [rsp+0xE0], xmm15
00007d248dbd56f5  sub rsp, 0x30
00007d248dbd56f9  movaps [rsp], xmm1
00007d248dbd56fd  movaps [rsp+0x10], xmm7
00007d248dbd5702  movaps [rsp+0x20], xmm11
00007d248dbd5708  lea rdi, [rsp]
00007d248dbd570c  mov esi, 0x00
00007d248dbd5711  mov rax, 0x5BCEEF236530
00007d248dbd571b  call rax
00007d248dbd571d  movaps xmm1, [rsp]
00007d248dbd5721  add rsp, 0x30
00007d248dbd5725  vmovaps xmm0, [rsp]
00007d248dbd572a  vmovaps xmm2, [rsp+0x10]
00007d248dbd5730  vmovaps xmm3, [rsp+0x20]
00007d248dbd5736  vmovaps xmm4, [rsp+0x30]
00007d248dbd573c  vmovaps xmm5, [rsp+0x40]
00007d248dbd5742  vmovaps xmm6, [rsp+0x50]
00007d248dbd5748  vmovaps xmm7, [rsp+0x60]
00007d248dbd574e  vmovaps xmm8, [rsp+0x70]
00007d248dbd5754  vmovaps xmm9, [rsp+0x80]
00007d248dbd575d  vmovaps xmm10, [rsp+0x90]
00007d248dbd5766  vmovaps xmm11, [rsp+0xA0]
00007d248dbd576f  vmovaps xmm12, [rsp+0xB0]
00007d248dbd5778  vmovaps xmm13, [rsp+0xC0]
00007d248dbd5781  vmovaps xmm14, [rsp+0xD0]
00007d248dbd578a  vmovaps xmm15, [rsp+0xE0]
00007d248dbd5793  add rsp, 0xF0
00007d248dbd579a  pop r11
00007d248dbd579c  pop r10
00007d248dbd579e  pop r9
00007d248dbd57a0  pop r8
00007d248dbd57a2  pop rsi
00007d248dbd57a3  pop rdi
00007d248dbd57a4  pop rdx
00007d248dbd57a5  pop rcx
00007d248dbd57a6  pop rax
00007d248dbd57a7  add rsp, 0x08
00007d248dbd57ab  jmp 0x00007D248DBD033B
00007d248dbd57b0  call 0x00007D248DA0E880
00007d248dbd57b5  jmp 0x00007D248DBD034E
00007d248dbd57ba  call 0x00007D248DA0C380
00007d248dbd57bf  jmp 0x00007D248DBD0359
00007d248dbd57c4  call 0x00007D248DA0D600
00007d248dbd57c9  jmp 0x00007D248DBD0364
00007d248dbd57ce  call 0x00007D248D9FF540
00007d248dbd57d3  jmp 0x00007D248DBD036F
00007d248dbd57d8  int3
00007d248dbd57d9  nop [rax], eax
00007d248dbd57e0  mov rax, [r15+0x40]
00007d248dbd57e4  mov r14, [r15+0x58]
00007d248dbd57e8  lea r12, [rax+r14*1]
00007d248dbd57ec  movaps xmm1, [r15+0x1D0]
00007d248dbd57f4  vmovaps [rsp+0x10], xmm1
00007d248dbd57fa  vmovaps xmm15, [rsp+0x10]
00007d248dbd5800  por xmm1, xmm15
00007d248dbd5805  movaps xmm14, [r15+0x1A0]
00007d248dbd580d  vmovaps [rsp+0x10], xmm14
00007d248dbd5813  vmovaps xmm13, [rsp+0x10]
00007d248dbd5819  por xmm14, xmm13
00007d248dbd581e  lea rax, [r12+0x30]
00007d248dbd5823  mov r11, [r13+rax*1]
00007d248dbd5828  lea rax, [r12+0x38]
00007d248dbd582d  mov r10, [r13+rax*1]
00007d248dbd5832  movq xmm13, r11
00007d248dbd5837  movq xmm12, r10
00007d248dbd583c  movq xmm13, xmm13
00007d248dbd5841  vmovaps [rsp+0x10], xmm13
00007d248dbd5847  movq xmm13, xmm13
00007d248dbd584c  movaps [r15+0x130], xmm13
00007d248dbd5854  movq xmm12, xmm12
00007d248dbd5859  vmovaps [rsp+0x20], xmm12
00007d248dbd585f  movq xmm12, xmm12
00007d248dbd5864  movaps [r15+0x280], xmm12
00007d248dbd586c  movaps xmm13, [r15+0x270]
00007d248dbd5874  vmovaps [rsp+0x30], xmm13
00007d248dbd587a  vmovaps xmm12, [rsp+0x30]
00007d248dbd5880  por xmm13, xmm12
00007d248dbd5885  lea rax, [r12+0x20]
00007d248dbd588a  mov r11, [r13+rax*1]
00007d248dbd588f  lea rax, [r12+0x28]
00007d248dbd5894  mov r10, [r13+rax*1]
00007d248dbd5899  movq xmm12, r11
00007d248dbd589e  movq xmm11, r10
00007d248dbd58a3  movq xmm12, xmm12
00007d248dbd58a8  vmovaps [rsp+0x30], xmm12
00007d248dbd58ae  movq xmm12, xmm12
00007d248dbd58b3  movaps [r15+0x150], xmm12
00007d248dbd58bb  movq xmm11, xmm11
00007d248dbd58c0  vmovaps [rsp+0x40], xmm11
00007d248dbd58c6  movq xmm11, xmm11
00007d248dbd58cb  movaps [r15+0x140], xmm11
00007d248dbd58d3  lea rax, [r12+0x10]
00007d248dbd58d8  mov r11, [r13+rax*1]
00007d248dbd58dd  lea rax, [r12+0x18]
00007d248dbd58e2  mov r10, [r13+rax*1]
00007d248dbd58e7  movq xmm12, r11
00007d248dbd58ec  movq xmm11, r10
00007d248dbd58f1  movq xmm12, xmm12
00007d248dbd58f6  vmovaps [rsp+0x50], xmm12
00007d248dbd58fc  movq xmm12, xmm12
00007d248dbd5901  movaps [r15+0x170], xmm12
00007d248dbd5909  movq xmm11, xmm11
00007d248dbd590e  vmovaps [rsp+0x60], xmm11
00007d248dbd5914  movq xmm11, xmm11
00007d248dbd5919  movaps [r15+0x160], xmm11
00007d248dbd5921  mov rax, [r13+r12*1]
00007d248dbd5926  vmovq xmm12, rax
00007d248dbd592b  vpbroadcastq xmm12, xmm12
00007d248dbd5930  lea rax, [r12+0x08]
00007d248dbd5935  mov r12, [r13+rax*1]
00007d248dbd593a  movq xmm11, r12
00007d248dbd593f  movaps [r15+0x230], xmm11
00007d248dbd5947  mov rax, [r15+0xF8]
00007d248dbd594e  lea r12, [rax+0x50]
00007d248dbd5952  movups xmm11, [r13+r12*1]
00007d248dbd5958  lea r12, [rax+0x60]
00007d248dbd595c  movups xmm10, [r13+r12*1]
00007d248dbd5962  lea r12, [rax+0x30]
00007d248dbd5966  movups xmm9, [r13+r12*1]
00007d248dbd596c  mov r12, [r15+0x50]
00007d248dbd5970  lea r11, [r12+r14*1]
00007d248dbd5974  mov [r15+0x60], r11
00007d248dbd5978  lea r12, [r14+0x40]
00007d248dbd597c  mov [r15+0x58], r12
00007d248dbd5980  movaps xmm8, xmm12
00007d248dbd5984  mulpd xmm8, xmm15
00007d248dbd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007d248dbd598f  ptest xmm7, xmm7
00007d248dbd5994  jnz 0x00007D248DBD67B7
00007d248dbd599a  movq xmm15, qword ptr [r15+0x230]
00007d248dbd59a3  vmovaps [rsp+0x70], xmm15
00007d248dbd59a9  vpermilpd xmm15, xmm15, 0x00
00007d248dbd59af  movaps xmm7, xmm9
00007d248dbd59b3  mulpd xmm7, xmm15
00007d248dbd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007d248dbd59bd  ptest xmm6, xmm6
00007d248dbd59c2  jnz 0x00007D248DBD68FB
00007d248dbd59c8  vxorps xmm15, xmm15, xmm15
00007d248dbd59cd  vpbroadcastq xmm15, xmm15
00007d248dbd59d2  movaps xmm9, xmm12
00007d248dbd59d6  mulpd xmm9, xmm10
00007d248dbd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007d248dbd59e1  ptest xmm6, xmm6
00007d248dbd59e6  jnz 0x00007D248DBD6A3D
00007d248dbd59ec  movaps xmm10, xmm12
00007d248dbd59f0  mulpd xmm10, xmm11
00007d248dbd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d248dbd59fb  ptest xmm6, xmm6
00007d248dbd5a00  jnz 0x00007D248DBD6B81
00007d248dbd5a06  movaps xmm11, [r15+0x1F0]
00007d248dbd5a0e  movaps xmm6, xmm12
00007d248dbd5a12  mulpd xmm6, xmm11
00007d248dbd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007d248dbd5a1c  ptest xmm5, xmm5
00007d248dbd5a21  jnz 0x00007D248DBD6CC5
00007d248dbd5a27  movaps xmm12, [r15+0x2A0]
00007d248dbd5a2f  vmovaps [rsp+0x80], xmm12
00007d248dbd5a38  vmovaps xmm11, [rsp+0x80]
00007d248dbd5a41  por xmm12, xmm11
00007d248dbd5a46  movaps xmm11, [r15+0x250]
00007d248dbd5a4e  vmovaps [rsp+0x80], xmm11
00007d248dbd5a57  vmovaps xmm5, [rsp+0x80]
00007d248dbd5a60  por xmm11, xmm5
00007d248dbd5a65  vmovaps xmm4, [rsp+0x70]
00007d248dbd5a6b  vpermilpd xmm4, xmm4, 0x00
00007d248dbd5a71  movaps xmm3, xmm5
00007d248dbd5a74  mulpd xmm3, xmm4
00007d248dbd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007d248dbd5a7d  ptest xmm2, xmm2
00007d248dbd5a82  jnz 0x00007D248DBD6E07
00007d248dbd5a88  mov [rsp+0x80], rax
00007d248dbd5a90  xor eax, eax
00007d248dbd5a92  mov r14d, 0x200
00007d248dbd5a98  cmp r12, r14
00007d248dbd5a9b  cmc
00007d248dbd5a9c  lahf
00007d248dbd5a9d  seto al
00007d248dbd5aa0  mov [r15+0x108], eax
00007d248dbd5aa7  movaps xmm5, xmm8
00007d248dbd5aab  addpd xmm5, xmm15
00007d248dbd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007d248dbd5ab5  ptest xmm4, xmm4
00007d248dbd5aba  jnz 0x00007D248DBD6F47
00007d248dbd5ac0  movaps xmm8, [r15+0x1B0]
00007d248dbd5ac8  movaps xmm4, xmm9
00007d248dbd5acc  addpd xmm4, xmm8
00007d248dbd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007d248dbd5ad6  ptest xmm2, xmm2
00007d248dbd5adb  jnz 0x00007D248DBD7089
00007d248dbd5ae1  movaps xmm9, xmm10
00007d248dbd5ae5  addpd xmm9, xmm8
00007d248dbd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007d248dbd5af0  ptest xmm2, xmm2
00007d248dbd5af5  jnz 0x00007D248DBD71CB
00007d248dbd5afb  movaps xmm10, [r15+0x2F0]
00007d248dbd5b03  vmovaps [rsp+0x90], xmm10
00007d248dbd5b0c  vmovaps xmm8, [rsp+0x90]
00007d248dbd5b15  por xmm10, xmm8
00007d248dbd5b1a  movaps xmm8, [r15+0x2E0]
00007d248dbd5b22  vmovaps [rsp+0x90], xmm8
00007d248dbd5b2b  vmovaps xmm2, [rsp+0x90]
00007d248dbd5b34  por xmm8, xmm2
00007d248dbd5b39  movaps xmm2, [r15+0x2D0]
00007d248dbd5b41  vmovaps [rsp+0x90], xmm2
00007d248dbd5b4a  vmovaps [rsp+0xA0], xmm1
00007d248dbd5b53  vmovaps xmm1, [rsp+0x90]
00007d248dbd5b5c  por xmm2, xmm1
00007d248dbd5b60  movaps xmm1, [r15+0x200]
00007d248dbd5b68  vmovaps [rsp+0x90], xmm1
00007d248dbd5b71  vmovaps [rsp+0xB0], xmm15
00007d248dbd5b7a  vmovaps xmm15, [rsp+0x90]
00007d248dbd5b83  por xmm1, xmm15
00007d248dbd5b88  movaps xmm15, [r15+0x1C0]
00007d248dbd5b90  vmovaps [rsp+0x90], xmm15
00007d248dbd5b99  vmovaps [rsp+0xC0], xmm1
00007d248dbd5ba2  vmovaps xmm1, [rsp+0x90]
00007d248dbd5bab  por xmm15, xmm1
00007d248dbd5bb0  movaps xmm1, [r15+0x190]
00007d248dbd5bb8  vmovaps [rsp+0x90], xmm1
00007d248dbd5bc1  vmovaps [rsp+0xD0], xmm15
00007d248dbd5bca  vmovaps xmm15, [rsp+0x90]
00007d248dbd5bd3  por xmm1, xmm15
00007d248dbd5bd8  movaps xmm15, [r15+0x300]
00007d248dbd5be0  vmovaps [rsp+0x90], xmm15
00007d248dbd5be9  vmovaps [rsp+0xE0], xmm1
00007d248dbd5bf2  vmovaps xmm1, [rsp+0x90]
00007d248dbd5bfb  por xmm15, xmm1
00007d248dbd5c00  mov rax, [rsp+0x80]
00007d248dbd5c08  lea r14, [rax+0xA0]
00007d248dbd5c0f  movups xmm1, [r13+r14*1]
00007d248dbd5c15  lea r14, [rax+0xB0]
00007d248dbd5c1c  vmovaps [rsp+0x80], xmm1
00007d248dbd5c25  movups xmm1, [r13+r14*1]
00007d248dbd5c2b  vmovaps [rsp+0x90], xmm1
00007d248dbd5c34  vmovaps [rsp+0xF0], xmm15
00007d248dbd5c3d  vmovaps xmm15, [rsp+0xB0]
00007d248dbd5c46  vmovaps [rsp+0xB0], xmm14
00007d248dbd5c4f  movaps xmm1, xmm6
00007d248dbd5c52  addpd xmm1, xmm15
00007d248dbd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007d248dbd5c5c  ptest xmm14, xmm14
00007d248dbd5c62  jnz 0x00007D248DBD7323
00007d248dbd5c68  lea r14, [rax+0xF0]
00007d248dbd5c6f  movups xmm15, [r13+r14*1]
00007d248dbd5c75  movaps xmm14, xmm4
00007d248dbd5c79  addpd xmm14, xmm3
00007d248dbd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007d248dbd5c84  ptest xmm6, xmm6
00007d248dbd5c89  jnz 0x00007D248DBD746E
00007d248dbd5c8f  movaps xmm6, xmm9
00007d248dbd5c93  addpd xmm6, xmm7
00007d248dbd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007d248dbd5c9c  ptest xmm4, xmm4
00007d248dbd5ca1  jnz 0x00007D248DBD75B0
00007d248dbd5ca7  vmovaps xmm9, [rsp+0x70]
00007d248dbd5cad  vpermilpd xmm9, xmm9, 0x00
00007d248dbd5cb3  vmovaps xmm4, [rsp+0x90]
00007d248dbd5cbc  movaps xmm7, xmm4
00007d248dbd5cbf  mulpd xmm7, xmm9
00007d248dbd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007d248dbd5cc9  ptest xmm3, xmm3
00007d248dbd5cce  jnz 0x00007D248DBD76F1
00007d248dbd5cd4  vmovaps xmm9, [rsp+0x50]
00007d248dbd5cda  vpermilpd xmm9, xmm9, 0x00
00007d248dbd5ce0  movaps xmm4, xmm15
00007d248dbd5ce4  mulpd xmm4, xmm9
00007d248dbd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007d248dbd5cee  ptest xmm3, xmm3
00007d248dbd5cf3  jnz 0x00007D248DBD7832
00007d248dbd5cf9  lea r14, [rax+0xE0]
00007d248dbd5d00  movups xmm15, [r13+r14*1]
00007d248dbd5d06  vmovaps xmm9, [rsp+0x70]
00007d248dbd5d0c  vpermilpd xmm9, xmm9, 0x00
00007d248dbd5d12  vmovaps [rsp+0x70], xmm1
00007d248dbd5d18  vmovaps xmm1, [rsp+0x80]
00007d248dbd5d21  vmovaps [rsp+0x80], xmm15
00007d248dbd5d2a  movaps xmm3, xmm1
00007d248dbd5d2d  mulpd xmm3, xmm9
00007d248dbd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007d248dbd5d37  ptest xmm15, xmm15
00007d248dbd5d3d  jnz 0x00007D248DBD797E
00007d248dbd5d43  vmovaps xmm1, [rsp+0xF0]
00007d248dbd5d4c  vmovaps xmm15, [rsp+0xF0]
00007d248dbd5d55  por xmm1, xmm15
00007d248dbd5d5a  movaps [r15+0x300], xmm1
00007d248dbd5d62  vmovaps xmm15, [rsp+0xE0]
00007d248dbd5d6b  vmovaps xmm9, [rsp+0xE0]
00007d248dbd5d74  por xmm15, xmm9
00007d248dbd5d79  movaps [r15+0x190], xmm15
00007d248dbd5d81  vmovaps xmm9, [rsp+0x50]
00007d248dbd5d87  vpermilpd xmm9, xmm9, 0x00
00007d248dbd5d8d  vmovaps [rsp+0x90], xmm1
00007d248dbd5d96  vmovaps [rsp+0xE0], xmm15
00007d248dbd5d9f  vmovaps xmm15, [rsp+0x80]
00007d248dbd5da8  vmovaps [rsp+0x80], xmm14
00007d248dbd5db1  movaps xmm1, xmm15
00007d248dbd5db5  mulpd xmm1, xmm9
00007d248dbd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007d248dbd5dbf  ptest xmm14, xmm14
00007d248dbd5dc5  jnz 0x00007D248DBD7ABF
00007d248dbd5dcb  lea r14, [rax+0x90]
00007d248dbd5dd2  movups xmm15, [r13+r14*1]
00007d248dbd5dd8  vmovaps xmm14, [rsp+0xD0]
00007d248dbd5de1  vmovaps xmm9, [rsp+0xD0]
00007d248dbd5dea  por xmm14, xmm9
00007d248dbd5def  movaps [r15+0x1C0], xmm14
00007d248dbd5df7  vmovaps xmm9, [rsp+0xC0]
00007d248dbd5e00  vmovaps [rsp+0xD0], xmm1
00007d248dbd5e09  vmovaps xmm1, [rsp+0xC0]
00007d248dbd5e12  por xmm9, xmm1
00007d248dbd5e17  movaps [r15+0x200], xmm9
00007d248dbd5e1f  vmovaps [rsp+0xC0], xmm2
00007d248dbd5e28  vmovaps xmm1, [rsp+0xC0]
00007d248dbd5e31  por xmm2, xmm1
00007d248dbd5e35  movaps [r15+0x2D0], xmm2
00007d248dbd5e3d  vmovaps [rsp+0xC0], xmm8
00007d248dbd5e46  vmovaps xmm1, [rsp+0xC0]
00007d248dbd5e4f  por xmm8, xmm1
00007d248dbd5e54  movaps [r15+0x2E0], xmm8
00007d248dbd5e5c  vmovaps [rsp+0xC0], xmm15
00007d248dbd5e65  movaps xmm1, xmm5
00007d248dbd5e68  addpd xmm1, xmm7
00007d248dbd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007d248dbd5e71  ptest xmm15, xmm15
00007d248dbd5e77  jnz 0x00007D248DBD7C0B
00007d248dbd5e7d  vmovaps xmm15, [rsp+0x50]
00007d248dbd5e83  vpermilpd xmm15, xmm15, 0x00
00007d248dbd5e89  vmovaps xmm5, [rsp+0xC0]
00007d248dbd5e92  vmovaps [rsp+0xC0], xmm1
00007d248dbd5e9b  movaps xmm7, xmm5
00007d248dbd5e9e  mulpd xmm7, xmm15
00007d248dbd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007d248dbd5ea8  ptest xmm1, xmm1
00007d248dbd5ead  jnz 0x00007D248DBD7D4B
00007d248dbd5eb3  lea r14, [rax+0x80]
00007d248dbd5eba  movups xmm1, [r13+r14*1]
00007d248dbd5ec0  vmovaps xmm5, [rsp+0x70]
00007d248dbd5ec6  vmovaps [rsp+0x70], xmm1
00007d248dbd5ecc  movaps xmm15, xmm5
00007d248dbd5ed0  addpd xmm15, xmm3
00007d248dbd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d248dbd5edb  ptest xmm1, xmm1
00007d248dbd5ee0  jnz 0x00007D248DBD7E96
00007d248dbd5ee6  vmovaps xmm5, [rsp+0x80]
00007d248dbd5eef  movaps xmm1, xmm5
00007d248dbd5ef2  addpd xmm1, xmm4
00007d248dbd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007d248dbd5efb  ptest xmm3, xmm3
00007d248dbd5f00  jnz 0x00007D248DBD7FD8
00007d248dbd5f06  vmovaps [rsp+0x80], xmm10
00007d248dbd5f0f  vmovaps xmm5, [rsp+0x80]
00007d248dbd5f18  por xmm10, xmm5
00007d248dbd5f1d  movaps [r15+0x2F0], xmm10
00007d248dbd5f25  vmovaps xmm5, [rsp+0x50]
00007d248dbd5f2b  vpermilpd xmm5, xmm5, 0x00
00007d248dbd5f31  vmovaps xmm3, [rsp+0x70]
00007d248dbd5f37  vmovaps [rsp+0x50], xmm1
00007d248dbd5f3d  movaps xmm4, xmm3
00007d248dbd5f40  mulpd xmm4, xmm5
00007d248dbd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007d248dbd5f49  ptest xmm1, xmm1
00007d248dbd5f4e  jnz 0x00007D248DBD8118
00007d248dbd5f54  lea r14, [rax+0xD0]
00007d248dbd5f5b  movups xmm1, [r13+r14*1]
00007d248dbd5f61  vmovaps xmm3, [rsp+0xD0]
00007d248dbd5f6a  vmovaps [rsp+0x70], xmm1
00007d248dbd5f70  movaps xmm5, xmm6
00007d248dbd5f73  addpd xmm5, xmm3
00007d248dbd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007d248dbd5f7c  ptest xmm1, xmm1
00007d248dbd5f81  jnz 0x00007D248DBD8262
00007d248dbd5f87  vmovaps xmm1, [rsp+0x60]
00007d248dbd5f8d  vpermilpd xmm1, xmm1, 0x00
00007d248dbd5f93  movaps xmm6, xmm9
00007d248dbd5f97  mulpd xmm6, xmm1
00007d248dbd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007d248dbd5fa0  ptest xmm3, xmm3
00007d248dbd5fa5  jnz 0x00007D248DBD83A2
00007d248dbd5fab  movaps [r15+0x260], xmm6
00007d248dbd5fb3  vxorps xmm1, xmm1, xmm1
00007d248dbd5fb7  vpbroadcastq xmm1, xmm1
00007d248dbd5fbc  movaps [r15+0x1B0], xmm1
00007d248dbd5fc4  vmovaps xmm1, [rsp+0x60]
00007d248dbd5fca  vpermilpd xmm1, xmm1, 0x00
00007d248dbd5fd0  vmovaps xmm3, [rsp+0x70]
00007d248dbd5fd6  vmovaps [rsp+0x70], xmm15
00007d248dbd5fdc  movaps xmm9, xmm3
00007d248dbd5fe0  mulpd xmm9, xmm1
00007d248dbd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007d248dbd5feb  ptest xmm15, xmm15
00007d248dbd5ff1  jnz 0x00007D248DBD84E3
00007d248dbd5ff7  lea r14, [rax+0xC0]
00007d248dbd5ffe  movups xmm1, [r13+r14*1]
00007d248dbd6004  vmovaps xmm3, [rsp+0xC0]
00007d248dbd600d  vmovaps [rsp+0x80], xmm1
00007d248dbd6016  movaps xmm15, xmm3
00007d248dbd601a  addpd xmm15, xmm7
00007d248dbd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007d248dbd6025  ptest xmm1, xmm1
00007d248dbd602a  jnz 0x00007D248DBD862F
00007d248dbd6030  vmovaps [rsp+0xC0], xmm13
00007d248dbd6039  vmovaps xmm1, [rsp+0xC0]
00007d248dbd6042  por xmm13, xmm1
00007d248dbd6047  movaps [r15+0x270], xmm13
00007d248dbd604f  vmovaps xmm1, [rsp+0xB0]
00007d248dbd6058  vmovaps xmm7, [rsp+0xB0]
00007d248dbd6061  por xmm1, xmm7
00007d248dbd6065  movaps [r15+0x1A0], xmm1
00007d248dbd606d  vmovaps xmm1, [rsp+0x60]
00007d248dbd6073  vpermilpd xmm1, xmm1, 0x00
00007d248dbd6079  vmovaps [rsp+0xB0], xmm1
00007d248dbd6082  vmovaps xmm1, [rsp+0x80]
00007d248dbd608b  vmovaps [rsp+0x80], xmm15
00007d248dbd6094  vmovaps xmm15, [rsp+0xB0]
00007d248dbd609d  vmovaps [rsp+0xB0], xmm14
00007d248dbd60a6  movaps xmm3, xmm1
00007d248dbd60a9  mulpd xmm3, xmm15
00007d248dbd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007d248dbd60b3  ptest xmm14, xmm14
00007d248dbd60b9  jnz 0x00007D248DBD8771
00007d248dbd60bf  lea r14, [rax+0x20]
00007d248dbd60c3  movups xmm1, [r13+r14*1]
00007d248dbd60c9  movaps [r15+0x110], xmm1
00007d248dbd60d1  vmovaps xmm14, [rsp+0x70]
00007d248dbd60d7  vmovaps [rsp+0x70], xmm1
00007d248dbd60dd  movaps xmm15, xmm14
00007d248dbd60e1  addpd xmm15, xmm4
00007d248dbd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007d248dbd60ec  ptest xmm1, xmm1
00007d248dbd60f1  jnz 0x00007D248DBD88BC
00007d248dbd60f7  vmovaps xmm1, [rsp+0x60]
00007d248dbd60fd  vpermilpd xmm1, xmm1, 0x00
00007d248dbd6103  movaps xmm14, xmm2
00007d248dbd6107  mulpd xmm14, xmm1
00007d248dbd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007d248dbd6112  ptest xmm4, xmm4
00007d248dbd6117  jnz 0x00007D248DBD89FF
00007d248dbd611d  vmovaps xmm4, [rsp+0x50]
00007d248dbd6123  movaps xmm1, xmm4
00007d248dbd6126  addpd xmm1, xmm9
00007d248dbd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d248dbd6130  ptest xmm2, xmm2
00007d248dbd6135  jnz 0x00007D248DBD8B41
00007d248dbd613b  vmovaps xmm9, [rsp+0x30]
00007d248dbd6141  vpermilpd xmm9, xmm9, 0x00
00007d248dbd6147  vmovaps xmm2, [rsp+0x70]
00007d248dbd614d  vmovaps [rsp+0x50], xmm1
00007d248dbd6153  movaps xmm4, xmm2
00007d248dbd6156  mulpd xmm4, xmm9
00007d248dbd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007d248dbd6160  ptest xmm1, xmm1
00007d248dbd6165  jnz 0x00007D248DBD8C82
00007d248dbd616b  vmovaps xmm1, [rsp+0x30]
00007d248dbd6171  vpermilpd xmm1, xmm1, 0x00
00007d248dbd6177  vmovaps xmm2, [rsp+0x90]
00007d248dbd6180  vmovaps [rsp+0x60], xmm15
00007d248dbd6186  movaps xmm9, xmm2
00007d248dbd618a  mulpd xmm9, xmm1
00007d248dbd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007d248dbd6195  ptest xmm15, xmm15
00007d248dbd619b  jnz 0x00007D248DBD8DC3
00007d248dbd61a1  vmovaps xmm15, [rsp+0x80]
00007d248dbd61aa  movaps xmm1, xmm15
00007d248dbd61ae  addpd xmm1, xmm6
00007d248dbd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007d248dbd61b7  ptest xmm2, xmm2
00007d248dbd61bc  jnz 0x00007D248DBD8F05
00007d248dbd61c2  movaps xmm15, xmm5
00007d248dbd61c6  addpd xmm15, xmm3
00007d248dbd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007d248dbd61d1  ptest xmm6, xmm6
00007d248dbd61d6  jnz 0x00007D248DBD9046
00007d248dbd61dc  vmovaps xmm6, [rsp+0x30]
00007d248dbd61e2  vpermilpd xmm6, xmm6, 0x00
00007d248dbd61e8  movaps xmm5, xmm8
00007d248dbd61ec  mulpd xmm5, xmm6
00007d248dbd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007d248dbd61f5  ptest xmm3, xmm3
00007d248dbd61fa  jnz 0x00007D248DBD9188
00007d248dbd6200  vmovaps xmm8, [rsp+0x30]
00007d248dbd6206  vpermilpd xmm8, xmm8, 0x00
00007d248dbd620c  movaps xmm6, xmm10
00007d248dbd6210  mulpd xmm6, xmm8
00007d248dbd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007d248dbd621a  ptest xmm3, xmm3
00007d248dbd621f  jnz 0x00007D248DBD92C9
00007d248dbd6225  vmovaps xmm8, [rsp+0x60]
00007d248dbd622b  movaps xmm10, xmm8
00007d248dbd622f  addpd xmm10, xmm14
00007d248dbd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007d248dbd623a  ptest xmm3, xmm3
00007d248dbd623f  jnz 0x00007D248DBD940B
00007d248dbd6245  vmovaps xmm8, [rsp+0x50]
00007d248dbd624b  movaps xmm14, xmm8
00007d248dbd624f  addpd xmm14, xmm4
00007d248dbd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007d248dbd625a  ptest xmm3, xmm3
00007d248dbd625f  jnz 0x00007D248DBD954F
00007d248dbd6265  vmovaps xmm8, [rsp+0x40]
00007d248dbd626b  vpermilpd xmm8, xmm8, 0x00
00007d248dbd6271  movaps xmm4, xmm13
00007d248dbd6275  mulpd xmm4, xmm8
00007d248dbd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007d248dbd627f  ptest xmm3, xmm3
00007d248dbd6284  jnz 0x00007D248DBD9692
00007d248dbd628a  movaps xmm13, xmm15
00007d248dbd628e  addpd xmm13, xmm9
00007d248dbd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007d248dbd6299  ptest xmm8, xmm8
00007d248dbd629f  jnz 0x00007D248DBD97D4
00007d248dbd62a5  movaps xmm15, xmm1
00007d248dbd62a9  addpd xmm15, xmm5
00007d248dbd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007d248dbd62b4  ptest xmm9, xmm9
00007d248dbd62ba  jnz 0x00007D248DBD9918
00007d248dbd62c0  vmovaps [rsp+0x30], xmm11
00007d248dbd62c6  vmovaps xmm1, [rsp+0x30]
00007d248dbd62cc  por xmm11, xmm1
00007d248dbd62d1  movaps [r15+0x250], xmm11
00007d248dbd62d9  vmovaps [rsp+0x30], xmm12
00007d248dbd62df  vmovaps xmm1, [rsp+0x30]
00007d248dbd62e5  por xmm12, xmm1
00007d248dbd62ea  movaps [r15+0x2A0], xmm12
00007d248dbd62f2  vmovaps xmm1, [rsp+0xA0]
00007d248dbd62fb  vmovaps xmm11, [rsp+0xA0]
00007d248dbd6304  por xmm1, xmm11
00007d248dbd6309  movaps [r15+0x1D0], xmm1
00007d248dbd6311  lea r14, [rax+0x40]
00007d248dbd6315  movups xmm1, [r13+r14*1]
00007d248dbd631b  movaps [r15+0x2C0], xmm1
00007d248dbd6323  vmovaps xmm11, [rsp+0x40]
00007d248dbd6329  vpermilpd xmm11, xmm11, 0x00
00007d248dbd632f  vmovaps xmm8, [rsp+0xE0]
00007d248dbd6338  movaps xmm9, xmm8
00007d248dbd633c  mulpd xmm9, xmm11
00007d248dbd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007d248dbd6347  ptest xmm5, xmm5
00007d248dbd634c  jnz 0x00007D248DBD9A64
00007d248dbd6352  movaps xmm11, xmm10
00007d248dbd6356  addpd xmm11, xmm6
00007d248dbd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007d248dbd6361  ptest xmm8, xmm8
00007d248dbd6367  jnz 0x00007D248DBD9BA8
00007d248dbd636d  movaps xmm10, xmm14
00007d248dbd6371  addpd xmm10, xmm4
00007d248dbd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007d248dbd637c  ptest xmm8, xmm8
00007d248dbd6382  jnz 0x00007D248DBD9CEB
00007d248dbd6388  vmovaps xmm14, [rsp+0x40]
00007d248dbd638e  vpermilpd xmm14, xmm14, 0x00
00007d248dbd6394  movaps xmm8, xmm1
00007d248dbd6398  mulpd xmm8, xmm14
00007d248dbd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007d248dbd63a3  ptest xmm6, xmm6
00007d248dbd63a8  jnz 0x00007D248DBD9E2E
00007d248dbd63ae  movaps xmm1, [r15+0x2B0]
00007d248dbd63b6  vmovaps xmm14, [rsp+0x40]
00007d248dbd63bc  vpermilpd xmm14, xmm14, 0x00
00007d248dbd63c2  movaps xmm6, xmm1
00007d248dbd63c5  mulpd xmm6, xmm14
00007d248dbd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007d248dbd63cf  ptest xmm5, xmm5
00007d248dbd63d4  jnz 0x00007D248DBD9F71
00007d248dbd63da  vmovaps xmm1, [rsp+0x10]
00007d248dbd63e0  vpermilpd xmm1, xmm1, 0x00
00007d248dbd63e6  movaps xmm14, xmm12
00007d248dbd63ea  mulpd xmm14, xmm1
00007d248dbd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007d248dbd63f5  ptest xmm5, xmm5
00007d248dbd63fa  jnz 0x00007D248DBDA0B2
00007d248dbd6400  movaps xmm1, xmm13
00007d248dbd6404  addpd xmm1, xmm9
00007d248dbd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007d248dbd640e  ptest xmm12, xmm12
00007d248dbd6414  jnz 0x00007D248DBDA1F5
00007d248dbd641a  vmovaps xmm13, [rsp+0x10]
00007d248dbd6420  vpermilpd xmm13, xmm13, 0x00
00007d248dbd6426  movaps xmm12, xmm7
00007d248dbd642a  mulpd xmm12, xmm13
00007d248dbd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007d248dbd6435  ptest xmm9, xmm9
00007d248dbd643b  jnz 0x00007D248DBDA337
00007d248dbd6441  movaps xmm13, xmm15
00007d248dbd6445  addpd xmm13, xmm8
00007d248dbd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007d248dbd6450  ptest xmm9, xmm9
00007d248dbd6456  jnz 0x00007D248DBDA47A
00007d248dbd645c  movaps xmm15, [r15+0x290]
00007d248dbd6464  vmovaps xmm9, [rsp+0x10]
00007d248dbd646a  vpermilpd xmm9, xmm9, 0x00
00007d248dbd6470  movaps xmm8, xmm15
00007d248dbd6474  mulpd xmm8, xmm9
00007d248dbd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007d248dbd647f  ptest xmm7, xmm7
00007d248dbd6484  jnz 0x00007D248DBDA5BE
00007d248dbd648a  movaps xmm15, xmm11
00007d248dbd648e  addpd xmm15, xmm6
00007d248dbd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007d248dbd6499  ptest xmm9, xmm9
00007d248dbd649f  jnz 0x00007D248DBDA702
00007d248dbd64a5  movaps xmm11, [r15+0x1E0]
00007d248dbd64ad  vmovaps xmm9, [rsp+0x10]
00007d248dbd64b3  vpermilpd xmm9, xmm9, 0x00
00007d248dbd64b9  movaps xmm7, xmm11
00007d248dbd64bd  mulpd xmm7, xmm9
00007d248dbd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007d248dbd64c7  ptest xmm6, xmm6
00007d248dbd64cc  jnz 0x00007D248DBDA845
00007d248dbd64d2  movaps xmm11, xmm10
00007d248dbd64d6  addpd xmm11, xmm14
00007d248dbd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007d248dbd64e1  ptest xmm9, xmm9
00007d248dbd64e7  jnz 0x00007D248DBDA987
00007d248dbd64ed  lea r14, [rax+0x70]
00007d248dbd64f1  movups xmm14, [r13+r14*1]
00007d248dbd64f7  movaps [r15+0x240], xmm14
00007d248dbd64ff  movaps xmm10, xmm1
00007d248dbd6503  addpd xmm10, xmm12
00007d248dbd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007d248dbd650e  ptest xmm9, xmm9
00007d248dbd6514  jnz 0x00007D248DBDAAD5
00007d248dbd651a  movaps [r15+0x170], xmm10
00007d248dbd6522  vmovaps xmm1, [rsp+0x20]
00007d248dbd6528  vpermilpd xmm1, xmm1, 0x00
00007d248dbd652e  movaps xmm12, xmm14
00007d248dbd6532  mulpd xmm12, xmm1
00007d248dbd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007d248dbd653d  ptest xmm9, xmm9
00007d248dbd6543  jnz 0x00007D248DBDAC18
00007d248dbd6549  vmovaps xmm1, [rsp+0x20]
00007d248dbd654f  vpermilpd xmm1, xmm1, 0x00
00007d248dbd6555  vmovaps xmm9, [rsp+0xB0]
00007d248dbd655e  movaps xmm14, xmm9
00007d248dbd6562  mulpd xmm14, xmm1
00007d248dbd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007d248dbd656d  ptest xmm6, xmm6
00007d248dbd6572  jnz 0x00007D248DBDAD5B
00007d248dbd6578  movaps [r15+0x180], xmm14
00007d248dbd6580  movaps xmm1, xmm13
00007d248dbd6584  addpd xmm1, xmm8
00007d248dbd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007d248dbd658e  ptest xmm9, xmm9
00007d248dbd6594  jnz 0x00007D248DBDAE9E
00007d248dbd659a  movaps [r15+0x210], xmm1
00007d248dbd65a2  movups xmm13, [r13+rax*1]
00007d248dbd65a8  lea r14, [rax+0x10]
00007d248dbd65ac  movups xmm9, [r13+r14*1]
00007d248dbd65b2  movaps [r15+0x230], xmm9
00007d248dbd65ba  movaps xmm8, xmm15
00007d248dbd65be  addpd xmm8, xmm7
00007d248dbd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007d248dbd65c9  ptest xmm6, xmm6
00007d248dbd65ce  jnz 0x00007D248DBDAFF4
00007d248dbd65d4  movaps [r15+0x130], xmm8
00007d248dbd65dc  vmovaps xmm15, [rsp+0x20]
00007d248dbd65e2  vpermilpd xmm15, xmm15, 0x00
00007d248dbd65e8  movaps xmm7, xmm9
00007d248dbd65ec  mulpd xmm7, xmm15
00007d248dbd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007d248dbd65f6  ptest xmm6, xmm6
00007d248dbd65fb  jnz 0x00007D248DBDB137
00007d248dbd6601  movaps [r15+0x220], xmm7
00007d248dbd6609  vmovaps xmm15, [rsp+0x20]
00007d248dbd660f  vpermilpd xmm15, xmm15, 0x00
00007d248dbd6615  movaps xmm9, xmm13
00007d248dbd6619  mulpd xmm9, xmm15
00007d248dbd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007d248dbd6624  ptest xmm6, xmm6
00007d248dbd6629  jnz 0x00007D248DBDB279
00007d248dbd662f  movaps xmm15, xmm11
00007d248dbd6633  addpd xmm15, xmm12
00007d248dbd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007d248dbd663e  ptest xmm13, xmm13
00007d248dbd6644  jnz 0x00007D248DBDB3BD
00007d248dbd664a  movaps [r15+0x140], xmm15
00007d248dbd6652  movaps xmm13, xmm10
00007d248dbd6656  addpd xmm13, xmm14
00007d248dbd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007d248dbd6661  ptest xmm12, xmm12
00007d248dbd6667  jnz 0x00007D248DBDB501
00007d248dbd666d  movaps [r15+0x150], xmm13
00007d248dbd6675  movaps xmm14, xmm1
00007d248dbd6679  addpd xmm14, xmm7
00007d248dbd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007d248dbd6684  ptest xmm12, xmm12
00007d248dbd668a  jnz 0x00007D248DBDB645
00007d248dbd6690  movaps [r15+0x160], xmm14
00007d248dbd6698  movaps xmm1, xmm8
00007d248dbd669c  addpd xmm1, xmm9
00007d248dbd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007d248dbd66a6  ptest xmm12, xmm12
00007d248dbd66ac  jnz 0x00007D248DBDB787
00007d248dbd66b2  movaps [r15+0x120], xmm1
00007d248dbd66ba  movups [r13+r11*1], xmm15
00007d248dbd66c0  lea rax, [r11+0x10]
00007d248dbd66c4  movups [r13+rax*1], xmm13
00007d248dbd66ca  lea rax, [r11+0x20]
00007d248dbd66ce  movups [r13+rax*1], xmm14
00007d248dbd66d4  lea rax, [r11+0x30]
00007d248dbd66d8  movups [r13+rax*1], xmm1
00007d248dbd66de  mov eax, [r15+0x108]
00007d248dbd66e5  sahf
00007d248dbd66e6  jnz 0x00007D248DBD6718
00007d248dbd66e8  cmp dword ptr [r15+0x318], 0x00
00007d248dbd66f0  jz 0x00007D248DBDB900
00007d248dbd66f6  nop [rax+rax*1], ax
00007d248dbd66ff  nop [rax+rax*1], eax
00007d248dbd6707  mov eax, 0x410444
00007d248dbd670c  mov [r15+0x100], rax
00007d248dbd6713  jmp 0x00007D248D9FE110
00007d248dbd6718  cmp dword ptr [r15+0x318], 0x00
00007d248dbd6720  jz 0x00007D248DBD57E0
00007d248dbd6726  nop [rax+rax*1], ax
00007d248dbd672f  nop [rax+rax*1], eax
00007d248dbd6737  mov eax, 0x410278
00007d248dbd673c  mov [r15+0x100], rax
00007d248dbd6743  jmp 0x00007D248D9FE110
00007d248dbd6748  int3
00007d248dbd6749  call 0x00007D248DA0A4B0
00007d248dbd674e  jmp 0x00007D248DBD5828
00007d248dbd6753  call 0x00007D248DA09240
00007d248dbd6758  jmp 0x00007D248DBD5832
00007d248dbd675d  call 0x00007D248DA0A4B0
00007d248dbd6762  jmp 0x00007D248DBD588F
00007d248dbd6767  call 0x00007D248DA09240
00007d248dbd676c  jmp 0x00007D248DBD5899
00007d248dbd6771  call 0x00007D248DA0A4B0
00007d248dbd6776  jmp 0x00007D248DBD58DD
00007d248dbd677b  call 0x00007D248DA09240
00007d248dbd6780  jmp 0x00007D248DBD58E7
00007d248dbd6785  call 0x00007D248DAB47C0
00007d248dbd678a  jmp 0x00007D248DBD5926
00007d248dbd678f  call 0x00007D248DA0B720
00007d248dbd6794  jmp 0x00007D248DBD593A
00007d248dbd6799  call 0x00007D248DABFC30
00007d248dbd679e  jmp 0x00007D248DBD5958
00007d248dbd67a3  call 0x00007D248DABE9C0
00007d248dbd67a8  jmp 0x00007D248DBD5962
00007d248dbd67ad  call 0x00007D248DABD750
00007d248dbd67b2  jmp 0x00007D248DBD596C
00007d248dbd67b7  sub rsp, 0x08
00007d248dbd67bb  push rax
00007d248dbd67bc  push rcx
00007d248dbd67bd  push rdx
00007d248dbd67be  push rdi
00007d248dbd67bf  push rsi
00007d248dbd67c0  push r8
00007d248dbd67c2  push r9
00007d248dbd67c4  push r10
00007d248dbd67c6  push r11
00007d248dbd67c8  sub rsp, 0xF0
00007d248dbd67cf  vmovaps [rsp], xmm0
00007d248dbd67d4  vmovaps [rsp+0x10], xmm1
00007d248dbd67da  vmovaps [rsp+0x20], xmm2
00007d248dbd67e0  vmovaps [rsp+0x30], xmm3
00007d248dbd67e6  vmovaps [rsp+0x40], xmm4
00007d248dbd67ec  vmovaps [rsp+0x50], xmm5
00007d248dbd67f2  vmovaps [rsp+0x60], xmm6
00007d248dbd67f8  vmovaps [rsp+0x70], xmm7
00007d248dbd67fe  vmovaps [rsp+0x80], xmm9
00007d248dbd6807  vmovaps [rsp+0x90], xmm10
00007d248dbd6810  vmovaps [rsp+0xA0], xmm11
00007d248dbd6819  vmovaps [rsp+0xB0], xmm12
00007d248dbd6822  vmovaps [rsp+0xC0], xmm13
00007d248dbd682b  vmovaps [rsp+0xD0], xmm14
00007d248dbd6834  vmovaps [rsp+0xE0], xmm15
00007d248dbd683d  sub rsp, 0x30
00007d248dbd6841  movaps [rsp], xmm8
00007d248dbd6846  movaps [rsp+0x10], xmm12
00007d248dbd684c  movaps [rsp+0x20], xmm15
00007d248dbd6852  lea rdi, [rsp]
00007d248dbd6856  mov esi, 0x00
00007d248dbd685b  mov rax, 0x5BCEEF236530
00007d248dbd6865  call rax
00007d248dbd6867  movaps xmm8, [rsp]
00007d248dbd686c  add rsp, 0x30
00007d248dbd6870  vmovaps xmm0, [rsp]
00007d248dbd6875  vmovaps xmm1, [rsp+0x10]
00007d248dbd687b  vmovaps xmm2, [rsp+0x20]
00007d248dbd6881  vmovaps xmm3, [rsp+0x30]
00007d248dbd6887  vmovaps xmm4, [rsp+0x40]
00007d248dbd688d  vmovaps xmm5, [rsp+0x50]
00007d248dbd6893  vmovaps xmm6, [rsp+0x60]
00007d248dbd6899  vmovaps xmm7, [rsp+0x70]
00007d248dbd689f  vmovaps xmm9, [rsp+0x80]
00007d248dbd68a8  vmovaps xmm10, [rsp+0x90]
00007d248dbd68b1  vmovaps xmm11, [rsp+0xA0]
00007d248dbd68ba  vmovaps xmm12, [rsp+0xB0]
00007d248dbd68c3  vmovaps xmm13, [rsp+0xC0]
00007d248dbd68cc  vmovaps xmm14, [rsp+0xD0]
00007d248dbd68d5  vmovaps xmm15, [rsp+0xE0]
00007d248dbd68de  add rsp, 0xF0
00007d248dbd68e5  pop r11
00007d248dbd68e7  pop r10
00007d248dbd68e9  pop r9
00007d248dbd68eb  pop r8
00007d248dbd68ed  pop rsi
00007d248dbd68ee  pop rdi
00007d248dbd68ef  pop rdx
00007d248dbd68f0  pop rcx
00007d248dbd68f1  pop rax
00007d248dbd68f2  add rsp, 0x08
00007d248dbd68f6  jmp 0x00007D248DBD599A
00007d248dbd68fb  sub rsp, 0x08
00007d248dbd68ff  push rax
00007d248dbd6900  push rcx
00007d248dbd6901  push rdx
00007d248dbd6902  push rdi
00007d248dbd6903  push rsi
00007d248dbd6904  push r8
00007d248dbd6906  push r9
00007d248dbd6908  push r10
00007d248dbd690a  push r11
00007d248dbd690c  sub rsp, 0xF0
00007d248dbd6913  vmovaps [rsp], xmm0
00007d248dbd6918  vmovaps [rsp+0x10], xmm1
00007d248dbd691e  vmovaps [rsp+0x20], xmm2
00007d248dbd6924  vmovaps [rsp+0x30], xmm3
00007d248dbd692a  vmovaps [rsp+0x40], xmm4
00007d248dbd6930  vmovaps [rsp+0x50], xmm5
00007d248dbd6936  vmovaps [rsp+0x60], xmm6
00007d248dbd693c  vmovaps [rsp+0x70], xmm8
00007d248dbd6942  vmovaps [rsp+0x80], xmm9
00007d248dbd694b  vmovaps [rsp+0x90], xmm10
00007d248dbd6954  vmovaps [rsp+0xA0], xmm11
00007d248dbd695d  vmovaps [rsp+0xB0], xmm12
00007d248dbd6966  vmovaps [rsp+0xC0], xmm13
00007d248dbd696f  vmovaps [rsp+0xD0], xmm14
00007d248dbd6978  vmovaps [rsp+0xE0], xmm15
00007d248dbd6981  sub rsp, 0x30
00007d248dbd6985  movaps [rsp], xmm7
00007d248dbd6989  movaps [rsp+0x10], xmm9
00007d248dbd698f  movaps [rsp+0x20], xmm15
00007d248dbd6995  lea rdi, [rsp]
00007d248dbd6999  mov esi, 0x00
00007d248dbd699e  mov rax, 0x5BCEEF236530
00007d248dbd69a8  call rax
00007d248dbd69aa  movaps xmm7, [rsp]
00007d248dbd69ae  add rsp, 0x30
00007d248dbd69b2  vmovaps xmm0, [rsp]
00007d248dbd69b7  vmovaps xmm1, [rsp+0x10]
00007d248dbd69bd  vmovaps xmm2, [rsp+0x20]
00007d248dbd69c3  vmovaps xmm3, [rsp+0x30]
00007d248dbd69c9  vmovaps xmm4, [rsp+0x40]
00007d248dbd69cf  vmovaps xmm5, [rsp+0x50]
00007d248dbd69d5  vmovaps xmm6, [rsp+0x60]
00007d248dbd69db  vmovaps xmm8, [rsp+0x70]
00007d248dbd69e1  vmovaps xmm9, [rsp+0x80]
00007d248dbd69ea  vmovaps xmm10, [rsp+0x90]
00007d248dbd69f3  vmovaps xmm11, [rsp+0xA0]
00007d248dbd69fc  vmovaps xmm12, [rsp+0xB0]
00007d248dbd6a05  vmovaps xmm13, [rsp+0xC0]
00007d248dbd6a0e  vmovaps xmm14, [rsp+0xD0]
00007d248dbd6a17  vmovaps xmm15, [rsp+0xE0]
00007d248dbd6a20  add rsp, 0xF0
00007d248dbd6a27  pop r11
00007d248dbd6a29  pop r10
00007d248dbd6a2b  pop r9
00007d248dbd6a2d  pop r8
00007d248dbd6a2f  pop rsi
00007d248dbd6a30  pop rdi
00007d248dbd6a31  pop rdx
00007d248dbd6a32  pop rcx
00007d248dbd6a33  pop rax
00007d248dbd6a34  add rsp, 0x08
00007d248dbd6a38  jmp 0x00007D248DBD59C8
00007d248dbd6a3d  sub rsp, 0x08
00007d248dbd6a41  push rax
00007d248dbd6a42  push rcx
00007d248dbd6a43  push rdx
00007d248dbd6a44  push rdi
00007d248dbd6a45  push rsi
00007d248dbd6a46  push r8
00007d248dbd6a48  push r9
00007d248dbd6a4a  push r10
00007d248dbd6a4c  push r11
00007d248dbd6a4e  sub rsp, 0xF0
00007d248dbd6a55  vmovaps [rsp], xmm0
00007d248dbd6a5a  vmovaps [rsp+0x10], xmm1
00007d248dbd6a60  vmovaps [rsp+0x20], xmm2
00007d248dbd6a66  vmovaps [rsp+0x30], xmm3
00007d248dbd6a6c  vmovaps [rsp+0x40], xmm4
00007d248dbd6a72  vmovaps [rsp+0x50], xmm5
00007d248dbd6a78  vmovaps [rsp+0x60], xmm6
00007d248dbd6a7e  vmovaps [rsp+0x70], xmm7
00007d248dbd6a84  vmovaps [rsp+0x80], xmm8
00007d248dbd6a8d  vmovaps [rsp+0x90], xmm10
00007d248dbd6a96  vmovaps [rsp+0xA0], xmm11
00007d248dbd6a9f  vmovaps [rsp+0xB0], xmm12
00007d248dbd6aa8  vmovaps [rsp+0xC0], xmm13
00007d248dbd6ab1  vmovaps [rsp+0xD0], xmm14
00007d248dbd6aba  vmovaps [rsp+0xE0], xmm15
00007d248dbd6ac3  sub rsp, 0x30
00007d248dbd6ac7  movaps [rsp], xmm9
00007d248dbd6acc  movaps [rsp+0x10], xmm12
00007d248dbd6ad2  movaps [rsp+0x20], xmm10
00007d248dbd6ad8  lea rdi, [rsp]
00007d248dbd6adc  mov esi, 0x00
00007d248dbd6ae1  mov rax, 0x5BCEEF236530
00007d248dbd6aeb  call rax
00007d248dbd6aed  movaps xmm9, [rsp]
00007d248dbd6af2  add rsp, 0x30
00007d248dbd6af6  vmovaps xmm0, [rsp]
00007d248dbd6afb  vmovaps xmm1, [rsp+0x10]
00007d248dbd6b01  vmovaps xmm2, [rsp+0x20]
00007d248dbd6b07  vmovaps xmm3, [rsp+0x30]
00007d248dbd6b0d  vmovaps xmm4, [rsp+0x40]
00007d248dbd6b13  vmovaps xmm5, [rsp+0x50]
00007d248dbd6b19  vmovaps xmm6, [rsp+0x60]
00007d248dbd6b1f  vmovaps xmm7, [rsp+0x70]
00007d248dbd6b25  vmovaps xmm8, [rsp+0x80]
00007d248dbd6b2e  vmovaps xmm10, [rsp+0x90]
00007d248dbd6b37  vmovaps xmm11, [rsp+0xA0]
00007d248dbd6b40  vmovaps xmm12, [rsp+0xB0]
00007d248dbd6b49  vmovaps xmm13, [rsp+0xC0]
00007d248dbd6b52  vmovaps xmm14, [rsp+0xD0]
00007d248dbd6b5b  vmovaps xmm15, [rsp+0xE0]
00007d248dbd6b64  add rsp, 0xF0
00007d248dbd6b6b  pop r11
00007d248dbd6b6d  pop r10
00007d248dbd6b6f  pop r9
00007d248dbd6b71  pop r8
00007d248dbd6b73  pop rsi
00007d248dbd6b74  pop rdi
00007d248dbd6b75  pop rdx
00007d248dbd6b76  pop rcx
00007d248dbd6b77  pop rax
00007d248dbd6b78  add rsp, 0x08
00007d248dbd6b7c  jmp 0x00007D248DBD59EC
00007d248dbd6b81  sub rsp, 0x08
00007d248dbd6b85  push rax
00007d248dbd6b86  push rcx
00007d248dbd6b87  push rdx
00007d248dbd6b88  push rdi
00007d248dbd6b89  push rsi
00007d248dbd6b8a  push r8
00007d248dbd6b8c  push r9
00007d248dbd6b8e  push r10
00007d248dbd6b90  push r11
00007d248dbd6b92  sub rsp, 0xF0
00007d248dbd6b99  vmovaps [rsp], xmm0
00007d248dbd6b9e  vmovaps [rsp+0x10], xmm1
00007d248dbd6ba4  vmovaps [rsp+0x20], xmm2
00007d248dbd6baa  vmovaps [rsp+0x30], xmm3
00007d248dbd6bb0  vmovaps [rsp+0x40], xmm4
00007d248dbd6bb6  vmovaps [rsp+0x50], xmm5
00007d248dbd6bbc  vmovaps [rsp+0x60], xmm6
00007d248dbd6bc2  vmovaps [rsp+0x70], xmm7
00007d248dbd6bc8  vmovaps [rsp+0x80], xmm8
00007d248dbd6bd1  vmovaps [rsp+0x90], xmm9
00007d248dbd6bda  vmovaps [rsp+0xA0], xmm11
00007d248dbd6be3  vmovaps [rsp+0xB0], xmm12
00007d248dbd6bec  vmovaps [rsp+0xC0], xmm13
00007d248dbd6bf5  vmovaps [rsp+0xD0], xmm14
00007d248dbd6bfe  vmovaps [rsp+0xE0], xmm15
00007d248dbd6c07  sub rsp, 0x30
00007d248dbd6c0b  movaps [rsp], xmm10
00007d248dbd6c10  movaps [rsp+0x10], xmm12
00007d248dbd6c16  movaps [rsp+0x20], xmm11
00007d248dbd6c1c  lea rdi, [rsp]
00007d248dbd6c20  mov esi, 0x00
00007d248dbd6c25  mov rax, 0x5BCEEF236530
00007d248dbd6c2f  call rax
00007d248dbd6c31  movaps xmm10, [rsp]
00007d248dbd6c36  add rsp, 0x30
00007d248dbd6c3a  vmovaps xmm0, [rsp]
00007d248dbd6c3f  vmovaps xmm1, [rsp+0x10]
00007d248dbd6c45  vmovaps xmm2, [rsp+0x20]
00007d248dbd6c4b  vmovaps xmm3, [rsp+0x30]
00007d248dbd6c51  vmovaps xmm4, [rsp+0x40]
00007d248dbd6c57  vmovaps xmm5, [rsp+0x50]
00007d248dbd6c5d  vmovaps xmm6, [rsp+0x60]
00007d248dbd6c63  vmovaps xmm7, [rsp+0x70]
00007d248dbd6c69  vmovaps xmm8, [rsp+0x80]
00007d248dbd6c72  vmovaps xmm9, [rsp+0x90]
00007d248dbd6c7b  vmovaps xmm11, [rsp+0xA0]
00007d248dbd6c84  vmovaps xmm12, [rsp+0xB0]
00007d248dbd6c8d  vmovaps xmm13, [rsp+0xC0]
00007d248dbd6c96  vmovaps xmm14, [rsp+0xD0]
00007d248dbd6c9f  vmovaps xmm15, [rsp+0xE0]
00007d248dbd6ca8  add rsp, 0xF0
00007d248dbd6caf  pop r11
00007d248dbd6cb1  pop r10
00007d248dbd6cb3  pop r9
00007d248dbd6cb5  pop r8
00007d248dbd6cb7  pop rsi
00007d248dbd6cb8  pop rdi
00007d248dbd6cb9  pop rdx
00007d248dbd6cba  pop rcx
00007d248dbd6cbb  pop rax
00007d248dbd6cbc  add rsp, 0x08
00007d248dbd6cc0  jmp 0x00007D248DBD5A06
00007d248dbd6cc5  sub rsp, 0x08
00007d248dbd6cc9  push rax
00007d248dbd6cca  push rcx
00007d248dbd6ccb  push rdx
00007d248dbd6ccc  push rdi
00007d248dbd6ccd  push rsi
00007d248dbd6cce  push r8
00007d248dbd6cd0  push r9
00007d248dbd6cd2  push r10
00007d248dbd6cd4  push r11
00007d248dbd6cd6  sub rsp, 0xF0
00007d248dbd6cdd  vmovaps [rsp], xmm0
00007d248dbd6ce2  vmovaps [rsp+0x10], xmm1
00007d248dbd6ce8  vmovaps [rsp+0x20], xmm2
00007d248dbd6cee  vmovaps [rsp+0x30], xmm3
00007d248dbd6cf4  vmovaps [rsp+0x40], xmm4
00007d248dbd6cfa  vmovaps [rsp+0x50], xmm5
00007d248dbd6d00  vmovaps [rsp+0x60], xmm7
00007d248dbd6d06  vmovaps [rsp+0x70], xmm8
00007d248dbd6d0c  vmovaps [rsp+0x80], xmm9
00007d248dbd6d15  vmovaps [rsp+0x90], xmm10
00007d248dbd6d1e  vmovaps [rsp+0xA0], xmm11
00007d248dbd6d27  vmovaps [rsp+0xB0], xmm12
00007d248dbd6d30  vmovaps [rsp+0xC0], xmm13
00007d248dbd6d39  vmovaps [rsp+0xD0], xmm14
00007d248dbd6d42  vmovaps [rsp+0xE0], xmm15
00007d248dbd6d4b  sub rsp, 0x30
00007d248dbd6d4f  movaps [rsp], xmm6
00007d248dbd6d53  movaps [rsp+0x10], xmm12
00007d248dbd6d59  movaps [rsp+0x20], xmm11
00007d248dbd6d5f  lea rdi, [rsp]
00007d248dbd6d63  mov esi, 0x00
00007d248dbd6d68  mov rax, 0x5BCEEF236530
00007d248dbd6d72  call rax
00007d248dbd6d74  movaps xmm6, [rsp]
00007d248dbd6d78  add rsp, 0x30
00007d248dbd6d7c  vmovaps xmm0, [rsp]
00007d248dbd6d81  vmovaps xmm1, [rsp+0x10]
00007d248dbd6d87  vmovaps xmm2, [rsp+0x20]
00007d248dbd6d8d  vmovaps xmm3, [rsp+0x30]
00007d248dbd6d93  vmovaps xmm4, [rsp+0x40]
00007d248dbd6d99  vmovaps xmm5, [rsp+0x50]
00007d248dbd6d9f  vmovaps xmm7, [rsp+0x60]
00007d248dbd6da5  vmovaps xmm8, [rsp+0x70]
00007d248dbd6dab  vmovaps xmm9, [rsp+0x80]
00007d248dbd6db4  vmovaps xmm10, [rsp+0x90]
00007d248dbd6dbd  vmovaps xmm11, [rsp+0xA0]
00007d248dbd6dc6  vmovaps xmm12, [rsp+0xB0]
00007d248dbd6dcf  vmovaps xmm13, [rsp+0xC0]
00007d248dbd6dd8  vmovaps xmm14, [rsp+0xD0]
00007d248dbd6de1  vmovaps xmm15, [rsp+0xE0]
00007d248dbd6dea  add rsp, 0xF0
00007d248dbd6df1  pop r11
00007d248dbd6df3  pop r10
00007d248dbd6df5  pop r9
00007d248dbd6df7  pop r8
00007d248dbd6df9  pop rsi
00007d248dbd6dfa  pop rdi
00007d248dbd6dfb  pop rdx
00007d248dbd6dfc  pop rcx
00007d248dbd6dfd  pop rax
00007d248dbd6dfe  add rsp, 0x08
00007d248dbd6e02  jmp 0x00007D248DBD5A27
00007d248dbd6e07  sub rsp, 0x08
00007d248dbd6e0b  push rax
00007d248dbd6e0c  push rcx
00007d248dbd6e0d  push rdx
00007d248dbd6e0e  push rdi
00007d248dbd6e0f  push rsi
00007d248dbd6e10  push r8
00007d248dbd6e12  push r9
00007d248dbd6e14  push r10
00007d248dbd6e16  push r11
00007d248dbd6e18  sub rsp, 0xF0
00007d248dbd6e1f  vmovaps [rsp], xmm0
00007d248dbd6e24  vmovaps [rsp+0x10], xmm1
00007d248dbd6e2a  vmovaps [rsp+0x20], xmm2
00007d248dbd6e30  vmovaps [rsp+0x30], xmm4
00007d248dbd6e36  vmovaps [rsp+0x40], xmm5
00007d248dbd6e3c  vmovaps [rsp+0x50], xmm6
00007d248dbd6e42  vmovaps [rsp+0x60], xmm7
00007d248dbd6e48  vmovaps [rsp+0x70], xmm8
00007d248dbd6e4e  vmovaps [rsp+0x80], xmm9
00007d248dbd6e57  vmovaps [rsp+0x90], xmm10
00007d248dbd6e60  vmovaps [rsp+0xA0], xmm11
00007d248dbd6e69  vmovaps [rsp+0xB0], xmm12
00007d248dbd6e72  vmovaps [rsp+0xC0], xmm13
00007d248dbd6e7b  vmovaps [rsp+0xD0], xmm14
00007d248dbd6e84  vmovaps [rsp+0xE0], xmm15
00007d248dbd6e8d  sub rsp, 0x30
00007d248dbd6e91  movaps [rsp], xmm3
00007d248dbd6e95  movaps [rsp+0x10], xmm5
00007d248dbd6e9a  movaps [rsp+0x20], xmm4
00007d248dbd6e9f  lea rdi, [rsp]
00007d248dbd6ea3  mov esi, 0x00
00007d248dbd6ea8  mov rax, 0x5BCEEF236530
00007d248dbd6eb2  call rax
00007d248dbd6eb4  movaps xmm3, [rsp]
00007d248dbd6eb8  add rsp, 0x30
00007d248dbd6ebc  vmovaps xmm0, [rsp]
00007d248dbd6ec1  vmovaps xmm1, [rsp+0x10]
00007d248dbd6ec7  vmovaps xmm2, [rsp+0x20]
00007d248dbd6ecd  vmovaps xmm4, [rsp+0x30]
00007d248dbd6ed3  vmovaps xmm5, [rsp+0x40]
00007d248dbd6ed9  vmovaps xmm6, [rsp+0x50]
00007d248dbd6edf  vmovaps xmm7, [rsp+0x60]
00007d248dbd6ee5  vmovaps xmm8, [rsp+0x70]
00007d248dbd6eeb  vmovaps xmm9, [rsp+0x80]
00007d248dbd6ef4  vmovaps xmm10, [rsp+0x90]
00007d248dbd6efd  vmovaps xmm11, [rsp+0xA0]
00007d248dbd6f06  vmovaps xmm12, [rsp+0xB0]
00007d248dbd6f0f  vmovaps xmm13, [rsp+0xC0]
00007d248dbd6f18  vmovaps xmm14, [rsp+0xD0]
00007d248dbd6f21  vmovaps xmm15, [rsp+0xE0]
00007d248dbd6f2a  add rsp, 0xF0
00007d248dbd6f31  pop r11
00007d248dbd6f33  pop r10
00007d248dbd6f35  pop r9
00007d248dbd6f37  pop r8
00007d248dbd6f39  pop rsi
00007d248dbd6f3a  pop rdi
00007d248dbd6f3b  pop rdx
00007d248dbd6f3c  pop rcx
00007d248dbd6f3d  pop rax
00007d248dbd6f3e  add rsp, 0x08
00007d248dbd6f42  jmp 0x00007D248DBD5A88
00007d248dbd6f47  sub rsp, 0x08
00007d248dbd6f4b  push rax
00007d248dbd6f4c  push rcx
00007d248dbd6f4d  push rdx
00007d248dbd6f4e  push rdi
00007d248dbd6f4f  push rsi
00007d248dbd6f50  push r8
00007d248dbd6f52  push r9
00007d248dbd6f54  push r10
00007d248dbd6f56  push r11
00007d248dbd6f58  sub rsp, 0xF0
00007d248dbd6f5f  vmovaps [rsp], xmm0
00007d248dbd6f64  vmovaps [rsp+0x10], xmm1
00007d248dbd6f6a  vmovaps [rsp+0x20], xmm2
00007d248dbd6f70  vmovaps [rsp+0x30], xmm3
00007d248dbd6f76  vmovaps [rsp+0x40], xmm4
00007d248dbd6f7c  vmovaps [rsp+0x50], xmm6
00007d248dbd6f82  vmovaps [rsp+0x60], xmm7
00007d248dbd6f88  vmovaps [rsp+0x70], xmm8
00007d248dbd6f8e  vmovaps [rsp+0x80], xmm9
00007d248dbd6f97  vmovaps [rsp+0x90], xmm10
00007d248dbd6fa0  vmovaps [rsp+0xA0], xmm11
00007d248dbd6fa9  vmovaps [rsp+0xB0], xmm12
00007d248dbd6fb2  vmovaps [rsp+0xC0], xmm13
00007d248dbd6fbb  vmovaps [rsp+0xD0], xmm14
00007d248dbd6fc4  vmovaps [rsp+0xE0], xmm15
00007d248dbd6fcd  sub rsp, 0x30
00007d248dbd6fd1  movaps [rsp], xmm5
00007d248dbd6fd5  movaps [rsp+0x10], xmm8
00007d248dbd6fdb  movaps [rsp+0x20], xmm15
00007d248dbd6fe1  lea rdi, [rsp]
00007d248dbd6fe5  mov esi, 0x00
00007d248dbd6fea  mov rax, 0x5BCEEF236530
00007d248dbd6ff4  call rax
00007d248dbd6ff6  movaps xmm5, [rsp]
00007d248dbd6ffa  add rsp, 0x30
00007d248dbd6ffe  vmovaps xmm0, [rsp]
00007d248dbd7003  vmovaps xmm1, [rsp+0x10]
00007d248dbd7009  vmovaps xmm2, [rsp+0x20]
00007d248dbd700f  vmovaps xmm3, [rsp+0x30]
00007d248dbd7015  vmovaps xmm4, [rsp+0x40]
00007d248dbd701b  vmovaps xmm6, [rsp+0x50]
00007d248dbd7021  vmovaps xmm7, [rsp+0x60]
00007d248dbd7027  vmovaps xmm8, [rsp+0x70]
00007d248dbd702d  vmovaps xmm9, [rsp+0x80]
00007d248dbd7036  vmovaps xmm10, [rsp+0x90]
00007d248dbd703f  vmovaps xmm11, [rsp+0xA0]
00007d248dbd7048  vmovaps xmm12, [rsp+0xB0]
00007d248dbd7051  vmovaps xmm13, [rsp+0xC0]
00007d248dbd705a  vmovaps xmm14, [rsp+0xD0]
00007d248dbd7063  vmovaps xmm15, [rsp+0xE0]
00007d248dbd706c  add rsp, 0xF0
00007d248dbd7073  pop r11
00007d248dbd7075  pop r10
00007d248dbd7077  pop r9
00007d248dbd7079  pop r8
00007d248dbd707b  pop rsi
00007d248dbd707c  pop rdi
00007d248dbd707d  pop rdx
00007d248dbd707e  pop rcx
00007d248dbd707f  pop rax
00007d248dbd7080  add rsp, 0x08
00007d248dbd7084  jmp 0x00007D248DBD5AC0
00007d248dbd7089  sub rsp, 0x08
00007d248dbd708d  push rax
00007d248dbd708e  push rcx
00007d248dbd708f  push rdx
00007d248dbd7090  push rdi
00007d248dbd7091  push rsi
00007d248dbd7092  push r8
00007d248dbd7094  push r9
00007d248dbd7096  push r10
00007d248dbd7098  push r11
00007d248dbd709a  sub rsp, 0xF0
00007d248dbd70a1  vmovaps [rsp], xmm0
00007d248dbd70a6  vmovaps [rsp+0x10], xmm1
00007d248dbd70ac  vmovaps [rsp+0x20], xmm2
00007d248dbd70b2  vmovaps [rsp+0x30], xmm3
00007d248dbd70b8  vmovaps [rsp+0x40], xmm5
00007d248dbd70be  vmovaps [rsp+0x50], xmm6
00007d248dbd70c4  vmovaps [rsp+0x60], xmm7
00007d248dbd70ca  vmovaps [rsp+0x70], xmm8
00007d248dbd70d0  vmovaps [rsp+0x80], xmm9
00007d248dbd70d9  vmovaps [rsp+0x90], xmm10
00007d248dbd70e2  vmovaps [rsp+0xA0], xmm11
00007d248dbd70eb  vmovaps [rsp+0xB0], xmm12
00007d248dbd70f4  vmovaps [rsp+0xC0], xmm13
00007d248dbd70fd  vmovaps [rsp+0xD0], xmm14
00007d248dbd7106  vmovaps [rsp+0xE0], xmm15
00007d248dbd710f  sub rsp, 0x30
00007d248dbd7113  movaps [rsp], xmm4
00007d248dbd7117  movaps [rsp+0x10], xmm9
00007d248dbd711d  movaps [rsp+0x20], xmm8
00007d248dbd7123  lea rdi, [rsp]
00007d248dbd7127  mov esi, 0x00
00007d248dbd712c  mov rax, 0x5BCEEF236530
00007d248dbd7136  call rax
00007d248dbd7138  movaps xmm4, [rsp]
00007d248dbd713c  add rsp, 0x30
00007d248dbd7140  vmovaps xmm0, [rsp]
00007d248dbd7145  vmovaps xmm1, [rsp+0x10]
00007d248dbd714b  vmovaps xmm2, [rsp+0x20]
00007d248dbd7151  vmovaps xmm3, [rsp+0x30]
00007d248dbd7157  vmovaps xmm5, [rsp+0x40]
00007d248dbd715d  vmovaps xmm6, [rsp+0x50]
00007d248dbd7163  vmovaps xmm7, [rsp+0x60]
00007d248dbd7169  vmovaps xmm8, [rsp+0x70]
00007d248dbd716f  vmovaps xmm9, [rsp+0x80]
00007d248dbd7178  vmovaps xmm10, [rsp+0x90]
00007d248dbd7181  vmovaps xmm11, [rsp+0xA0]
00007d248dbd718a  vmovaps xmm12, [rsp+0xB0]
00007d248dbd7193  vmovaps xmm13, [rsp+0xC0]
00007d248dbd719c  vmovaps xmm14, [rsp+0xD0]
00007d248dbd71a5  vmovaps xmm15, [rsp+0xE0]
00007d248dbd71ae  add rsp, 0xF0
00007d248dbd71b5  pop r11
00007d248dbd71b7  pop r10
00007d248dbd71b9  pop r9
00007d248dbd71bb  pop r8
00007d248dbd71bd  pop rsi
00007d248dbd71be  pop rdi
00007d248dbd71bf  pop rdx
00007d248dbd71c0  pop rcx
00007d248dbd71c1  pop rax
00007d248dbd71c2  add rsp, 0x08
00007d248dbd71c6  jmp 0x00007D248DBD5AE1
00007d248dbd71cb  sub rsp, 0x08
00007d248dbd71cf  push rax
00007d248dbd71d0  push rcx
00007d248dbd71d1  push rdx
00007d248dbd71d2  push rdi
00007d248dbd71d3  push rsi
00007d248dbd71d4  push r8
00007d248dbd71d6  push r9
00007d248dbd71d8  push r10
00007d248dbd71da  push r11
00007d248dbd71dc  sub rsp, 0xF0
00007d248dbd71e3  vmovaps [rsp], xmm0
00007d248dbd71e8  vmovaps [rsp+0x10], xmm1
00007d248dbd71ee  vmovaps [rsp+0x20], xmm2
00007d248dbd71f4  vmovaps [rsp+0x30], xmm3
00007d248dbd71fa  vmovaps [rsp+0x40], xmm4
00007d248dbd7200  vmovaps [rsp+0x50], xmm5
00007d248dbd7206  vmovaps [rsp+0x60], xmm6
00007d248dbd720c  vmovaps [rsp+0x70], xmm7
00007d248dbd7212  vmovaps [rsp+0x80], xmm8
00007d248dbd721b  vmovaps [rsp+0x90], xmm10
00007d248dbd7224  vmovaps [rsp+0xA0], xmm11
00007d248dbd722d  vmovaps [rsp+0xB0], xmm12
00007d248dbd7236  vmovaps [rsp+0xC0], xmm13
00007d248dbd723f  vmovaps [rsp+0xD0], xmm14
00007d248dbd7248  vmovaps [rsp+0xE0], xmm15
00007d248dbd7251  sub rsp, 0x30
00007d248dbd7255  movaps [rsp], xmm9
00007d248dbd725a  movaps [rsp+0x10], xmm10
00007d248dbd7260  movaps [rsp+0x20], xmm8
00007d248dbd7266  lea rdi, [rsp]
00007d248dbd726a  mov esi, 0x00
00007d248dbd726f  mov rax, 0x5BCEEF236530
00007d248dbd7279  call rax
00007d248dbd727b  movaps xmm9, [rsp]
00007d248dbd7280  add rsp, 0x30
00007d248dbd7284  vmovaps xmm0, [rsp]
00007d248dbd7289  vmovaps xmm1, [rsp+0x10]
00007d248dbd728f  vmovaps xmm2, [rsp+0x20]
00007d248dbd7295  vmovaps xmm3, [rsp+0x30]
00007d248dbd729b  vmovaps xmm4, [rsp+0x40]
00007d248dbd72a1  vmovaps xmm5, [rsp+0x50]
00007d248dbd72a7  vmovaps xmm6, [rsp+0x60]
00007d248dbd72ad  vmovaps xmm7, [rsp+0x70]
00007d248dbd72b3  vmovaps xmm8, [rsp+0x80]
00007d248dbd72bc  vmovaps xmm10, [rsp+0x90]
00007d248dbd72c5  vmovaps xmm11, [rsp+0xA0]
00007d248dbd72ce  vmovaps xmm12, [rsp+0xB0]
00007d248dbd72d7  vmovaps xmm13, [rsp+0xC0]
00007d248dbd72e0  vmovaps xmm14, [rsp+0xD0]
00007d248dbd72e9  vmovaps xmm15, [rsp+0xE0]
00007d248dbd72f2  add rsp, 0xF0
00007d248dbd72f9  pop r11
00007d248dbd72fb  pop r10
00007d248dbd72fd  pop r9
00007d248dbd72ff  pop r8
00007d248dbd7301  pop rsi
00007d248dbd7302  pop rdi
00007d248dbd7303  pop rdx
00007d248dbd7304  pop rcx
00007d248dbd7305  pop rax
00007d248dbd7306  add rsp, 0x08
00007d248dbd730a  jmp 0x00007D248DBD5AFB
00007d248dbd730f  call 0x00007D248DAD64F0
00007d248dbd7314  jmp 0x00007D248DBD5C15
00007d248dbd7319  call 0x00007D248DAD64F0
00007d248dbd731e  jmp 0x00007D248DBD5C2B
00007d248dbd7323  sub rsp, 0x08
00007d248dbd7327  push rax
00007d248dbd7328  push rcx
00007d248dbd7329  push rdx
00007d248dbd732a  push rdi
00007d248dbd732b  push rsi
00007d248dbd732c  push r8
00007d248dbd732e  push r9
00007d248dbd7330  push r10
00007d248dbd7332  push r11
00007d248dbd7334  sub rsp, 0xF0
00007d248dbd733b  vmovaps [rsp], xmm0
00007d248dbd7340  vmovaps [rsp+0x10], xmm2
00007d248dbd7346  vmovaps [rsp+0x20], xmm3
00007d248dbd734c  vmovaps [rsp+0x30], xmm4
00007d248dbd7352  vmovaps [rsp+0x40], xmm5
00007d248dbd7358  vmovaps [rsp+0x50], xmm6
00007d248dbd735e  vmovaps [rsp+0x60], xmm7
00007d248dbd7364  vmovaps [rsp+0x70], xmm8
00007d248dbd736a  vmovaps [rsp+0x80], xmm9
00007d248dbd7373  vmovaps [rsp+0x90], xmm10
00007d248dbd737c  vmovaps [rsp+0xA0], xmm11
00007d248dbd7385  vmovaps [rsp+0xB0], xmm12
00007d248dbd738e  vmovaps [rsp+0xC0], xmm13
00007d248dbd7397  vmovaps [rsp+0xD0], xmm14
00007d248dbd73a0  vmovaps [rsp+0xE0], xmm15
00007d248dbd73a9  sub rsp, 0x30
00007d248dbd73ad  movaps [rsp], xmm1
00007d248dbd73b1  movaps [rsp+0x10], xmm6
00007d248dbd73b6  movaps [rsp+0x20], xmm15
00007d248dbd73bc  lea rdi, [rsp]
00007d248dbd73c0  mov esi, 0x00
00007d248dbd73c5  mov rax, 0x5BCEEF236530
00007d248dbd73cf  call rax
00007d248dbd73d1  movaps xmm1, [rsp]
00007d248dbd73d5  add rsp, 0x30
00007d248dbd73d9  vmovaps xmm0, [rsp]
00007d248dbd73de  vmovaps xmm2, [rsp+0x10]
00007d248dbd73e4  vmovaps xmm3, [rsp+0x20]
00007d248dbd73ea  vmovaps xmm4, [rsp+0x30]
00007d248dbd73f0  vmovaps xmm5, [rsp+0x40]
00007d248dbd73f6  vmovaps xmm6, [rsp+0x50]
00007d248dbd73fc  vmovaps xmm7, [rsp+0x60]
00007d248dbd7402  vmovaps xmm8, [rsp+0x70]
00007d248dbd7408  vmovaps xmm9, [rsp+0x80]
00007d248dbd7411  vmovaps xmm10, [rsp+0x90]
00007d248dbd741a  vmovaps xmm11, [rsp+0xA0]
00007d248dbd7423  vmovaps xmm12, [rsp+0xB0]
00007d248dbd742c  vmovaps xmm13, [rsp+0xC0]
00007d248dbd7435  vmovaps xmm14, [rsp+0xD0]
00007d248dbd743e  vmovaps xmm15, [rsp+0xE0]
00007d248dbd7447  add rsp, 0xF0
00007d248dbd744e  pop r11
00007d248dbd7450  pop r10
00007d248dbd7452  pop r9
00007d248dbd7454  pop r8
00007d248dbd7456  pop rsi
00007d248dbd7457  pop rdi
00007d248dbd7458  pop rdx
00007d248dbd7459  pop rcx
00007d248dbd745a  pop rax
00007d248dbd745b  add rsp, 0x08
00007d248dbd745f  jmp 0x00007D248DBD5C68
00007d248dbd7464  call 0x00007D248DAE5820
00007d248dbd7469  jmp 0x00007D248DBD5C75
00007d248dbd746e  sub rsp, 0x08
00007d248dbd7472  push rax
00007d248dbd7473  push rcx
00007d248dbd7474  push rdx
00007d248dbd7475  push rdi
00007d248dbd7476  push rsi
00007d248dbd7477  push r8
00007d248dbd7479  push r9
00007d248dbd747b  push r10
00007d248dbd747d  push r11
00007d248dbd747f  sub rsp, 0xF0
00007d248dbd7486  vmovaps [rsp], xmm0
00007d248dbd748b  vmovaps [rsp+0x10], xmm1
00007d248dbd7491  vmovaps [rsp+0x20], xmm2
00007d248dbd7497  vmovaps [rsp+0x30], xmm3
00007d248dbd749d  vmovaps [rsp+0x40], xmm4
00007d248dbd74a3  vmovaps [rsp+0x50], xmm5
00007d248dbd74a9  vmovaps [rsp+0x60], xmm6
00007d248dbd74af  vmovaps [rsp+0x70], xmm7
00007d248dbd74b5  vmovaps [rsp+0x80], xmm8
00007d248dbd74be  vmovaps [rsp+0x90], xmm9
00007d248dbd74c7  vmovaps [rsp+0xA0], xmm10
00007d248dbd74d0  vmovaps [rsp+0xB0], xmm11
00007d248dbd74d9  vmovaps [rsp+0xC0], xmm12
00007d248dbd74e2  vmovaps [rsp+0xD0], xmm13
00007d248dbd74eb  vmovaps [rsp+0xE0], xmm15
00007d248dbd74f4  sub rsp, 0x30
00007d248dbd74f8  movaps [rsp], xmm14
00007d248dbd74fd  movaps [rsp+0x10], xmm4
00007d248dbd7502  movaps [rsp+0x20], xmm3
00007d248dbd7507  lea rdi, [rsp]
00007d248dbd750b  mov esi, 0x00
00007d248dbd7510  mov rax, 0x5BCEEF236530
00007d248dbd751a  call rax
00007d248dbd751c  movaps xmm14, [rsp]
00007d248dbd7521  add rsp, 0x30
00007d248dbd7525  vmovaps xmm0, [rsp]
00007d248dbd752a  vmovaps xmm1, [rsp+0x10]
00007d248dbd7530  vmovaps xmm2, [rsp+0x20]
00007d248dbd7536  vmovaps xmm3, [rsp+0x30]
00007d248dbd753c  vmovaps xmm4, [rsp+0x40]
00007d248dbd7542  vmovaps xmm5, [rsp+0x50]
00007d248dbd7548  vmovaps xmm6, [rsp+0x60]
00007d248dbd754e  vmovaps xmm7, [rsp+0x70]
00007d248dbd7554  vmovaps xmm8, [rsp+0x80]
00007d248dbd755d  vmovaps xmm9, [rsp+0x90]
00007d248dbd7566  vmovaps xmm10, [rsp+0xA0]
00007d248dbd756f  vmovaps xmm11, [rsp+0xB0]
00007d248dbd7578  vmovaps xmm12, [rsp+0xC0]
00007d248dbd7581  vmovaps xmm13, [rsp+0xD0]
00007d248dbd758a  vmovaps xmm15, [rsp+0xE0]
00007d248dbd7593  add rsp, 0xF0
00007d248dbd759a  pop r11
00007d248dbd759c  pop r10
00007d248dbd759e  pop r9
00007d248dbd75a0  pop r8
00007d248dbd75a2  pop rsi
00007d248dbd75a3  pop rdi
00007d248dbd75a4  pop rdx
00007d248dbd75a5  pop rcx
00007d248dbd75a6  pop rax
00007d248dbd75a7  add rsp, 0x08
00007d248dbd75ab  jmp 0x00007D248DBD5C8F
00007d248dbd75b0  sub rsp, 0x08
00007d248dbd75b4  push rax
00007d248dbd75b5  push rcx
00007d248dbd75b6  push rdx
00007d248dbd75b7  push rdi
00007d248dbd75b8  push rsi
00007d248dbd75b9  push r8
00007d248dbd75bb  push r9
00007d248dbd75bd  push r10
00007d248dbd75bf  push r11
00007d248dbd75c1  sub rsp, 0xF0
00007d248dbd75c8  vmovaps [rsp], xmm0
00007d248dbd75cd  vmovaps [rsp+0x10], xmm1
00007d248dbd75d3  vmovaps [rsp+0x20], xmm2
00007d248dbd75d9  vmovaps [rsp+0x30], xmm3
00007d248dbd75df  vmovaps [rsp+0x40], xmm4
00007d248dbd75e5  vmovaps [rsp+0x50], xmm5
00007d248dbd75eb  vmovaps [rsp+0x60], xmm7
00007d248dbd75f1  vmovaps [rsp+0x70], xmm8
00007d248dbd75f7  vmovaps [rsp+0x80], xmm9
00007d248dbd7600  vmovaps [rsp+0x90], xmm10
00007d248dbd7609  vmovaps [rsp+0xA0], xmm11
00007d248dbd7612  vmovaps [rsp+0xB0], xmm12
00007d248dbd761b  vmovaps [rsp+0xC0], xmm13
00007d248dbd7624  vmovaps [rsp+0xD0], xmm14
00007d248dbd762d  vmovaps [rsp+0xE0], xmm15
00007d248dbd7636  sub rsp, 0x30
00007d248dbd763a  movaps [rsp], xmm6
00007d248dbd763e  movaps [rsp+0x10], xmm9
00007d248dbd7644  movaps [rsp+0x20], xmm7
00007d248dbd7649  lea rdi, [rsp]
00007d248dbd764d  mov esi, 0x00
00007d248dbd7652  mov rax, 0x5BCEEF236530
00007d248dbd765c  call rax
00007d248dbd765e  movaps xmm6, [rsp]
00007d248dbd7662  add rsp, 0x30
00007d248dbd7666  vmovaps xmm0, [rsp]
00007d248dbd766b  vmovaps xmm1, [rsp+0x10]
00007d248dbd7671  vmovaps xmm2, [rsp+0x20]
00007d248dbd7677  vmovaps xmm3, [rsp+0x30]
00007d248dbd767d  vmovaps xmm4, [rsp+0x40]
00007d248dbd7683  vmovaps xmm5, [rsp+0x50]
00007d248dbd7689  vmovaps xmm7, [rsp+0x60]
00007d248dbd768f  vmovaps xmm8, [rsp+0x70]
00007d248dbd7695  vmovaps xmm9, [rsp+0x80]
00007d248dbd769e  vmovaps xmm10, [rsp+0x90]
00007d248dbd76a7  vmovaps xmm11, [rsp+0xA0]
00007d248dbd76b0  vmovaps xmm12, [rsp+0xB0]
00007d248dbd76b9  vmovaps xmm13, [rsp+0xC0]
00007d248dbd76c2  vmovaps xmm14, [rsp+0xD0]
00007d248dbd76cb  vmovaps xmm15, [rsp+0xE0]
00007d248dbd76d4  add rsp, 0xF0
00007d248dbd76db  pop r11
00007d248dbd76dd  pop r10
00007d248dbd76df  pop r9
00007d248dbd76e1  pop r8
00007d248dbd76e3  pop rsi
00007d248dbd76e4  pop rdi
00007d248dbd76e5  pop rdx
00007d248dbd76e6  pop rcx
00007d248dbd76e7  pop rax
00007d248dbd76e8  add rsp, 0x08
00007d248dbd76ec  jmp 0x00007D248DBD5CA7
00007d248dbd76f1  sub rsp, 0x08
00007d248dbd76f5  push rax
00007d248dbd76f6  push rcx
00007d248dbd76f7  push rdx
00007d248dbd76f8  push rdi
00007d248dbd76f9  push rsi
00007d248dbd76fa  push r8
00007d248dbd76fc  push r9
00007d248dbd76fe  push r10
00007d248dbd7700  push r11
00007d248dbd7702  sub rsp, 0xF0
00007d248dbd7709  vmovaps [rsp], xmm0
00007d248dbd770e  vmovaps [rsp+0x10], xmm1
00007d248dbd7714  vmovaps [rsp+0x20], xmm2
00007d248dbd771a  vmovaps [rsp+0x30], xmm3
00007d248dbd7720  vmovaps [rsp+0x40], xmm4
00007d248dbd7726  vmovaps [rsp+0x50], xmm5
00007d248dbd772c  vmovaps [rsp+0x60], xmm6
00007d248dbd7732  vmovaps [rsp+0x70], xmm8
00007d248dbd7738  vmovaps [rsp+0x80], xmm9
00007d248dbd7741  vmovaps [rsp+0x90], xmm10
00007d248dbd774a  vmovaps [rsp+0xA0], xmm11
00007d248dbd7753  vmovaps [rsp+0xB0], xmm12
00007d248dbd775c  vmovaps [rsp+0xC0], xmm13
00007d248dbd7765  vmovaps [rsp+0xD0], xmm14
00007d248dbd776e  vmovaps [rsp+0xE0], xmm15
00007d248dbd7777  sub rsp, 0x30
00007d248dbd777b  movaps [rsp], xmm7
00007d248dbd777f  movaps [rsp+0x10], xmm4
00007d248dbd7784  movaps [rsp+0x20], xmm9
00007d248dbd778a  lea rdi, [rsp]
00007d248dbd778e  mov esi, 0x00
00007d248dbd7793  mov rax, 0x5BCEEF236530
00007d248dbd779d  call rax
00007d248dbd779f  movaps xmm7, [rsp]
00007d248dbd77a3  add rsp, 0x30
00007d248dbd77a7  vmovaps xmm0, [rsp]
00007d248dbd77ac  vmovaps xmm1, [rsp+0x10]
00007d248dbd77b2  vmovaps xmm2, [rsp+0x20]
00007d248dbd77b8  vmovaps xmm3, [rsp+0x30]
00007d248dbd77be  vmovaps xmm4, [rsp+0x40]
00007d248dbd77c4  vmovaps xmm5, [rsp+0x50]
00007d248dbd77ca  vmovaps xmm6, [rsp+0x60]
00007d248dbd77d0  vmovaps xmm8, [rsp+0x70]
00007d248dbd77d6  vmovaps xmm9, [rsp+0x80]
00007d248dbd77df  vmovaps xmm10, [rsp+0x90]
00007d248dbd77e8  vmovaps xmm11, [rsp+0xA0]
00007d248dbd77f1  vmovaps xmm12, [rsp+0xB0]
00007d248dbd77fa  vmovaps xmm13, [rsp+0xC0]
00007d248dbd7803  vmovaps xmm14, [rsp+0xD0]
00007d248dbd780c  vmovaps xmm15, [rsp+0xE0]
00007d248dbd7815  add rsp, 0xF0
00007d248dbd781c  pop r11
00007d248dbd781e  pop r10
00007d248dbd7820  pop r9
00007d248dbd7822  pop r8
00007d248dbd7824  pop rsi
00007d248dbd7825  pop rdi
00007d248dbd7826  pop rdx
00007d248dbd7827  pop rcx
00007d248dbd7828  pop rax
00007d248dbd7829  add rsp, 0x08
00007d248dbd782d  jmp 0x00007D248DBD5CD4
00007d248dbd7832  sub rsp, 0x08
00007d248dbd7836  push rax
00007d248dbd7837  push rcx
00007d248dbd7838  push rdx
00007d248dbd7839  push rdi
00007d248dbd783a  push rsi
00007d248dbd783b  push r8
00007d248dbd783d  push r9
00007d248dbd783f  push r10
00007d248dbd7841  push r11
00007d248dbd7843  sub rsp, 0xF0
00007d248dbd784a  vmovaps [rsp], xmm0
00007d248dbd784f  vmovaps [rsp+0x10], xmm1
00007d248dbd7855  vmovaps [rsp+0x20], xmm2
00007d248dbd785b  vmovaps [rsp+0x30], xmm3
00007d248dbd7861  vmovaps [rsp+0x40], xmm5
00007d248dbd7867  vmovaps [rsp+0x50], xmm6
00007d248dbd786d  vmovaps [rsp+0x60], xmm7
00007d248dbd7873  vmovaps [rsp+0x70], xmm8
00007d248dbd7879  vmovaps [rsp+0x80], xmm9
00007d248dbd7882  vmovaps [rsp+0x90], xmm10
00007d248dbd788b  vmovaps [rsp+0xA0], xmm11
00007d248dbd7894  vmovaps [rsp+0xB0], xmm12
00007d248dbd789d  vmovaps [rsp+0xC0], xmm13
00007d248dbd78a6  vmovaps [rsp+0xD0], xmm14
00007d248dbd78af  vmovaps [rsp+0xE0], xmm15
00007d248dbd78b8  sub rsp, 0x30
00007d248dbd78bc  movaps [rsp], xmm4
00007d248dbd78c0  movaps [rsp+0x10], xmm15
00007d248dbd78c6  movaps [rsp+0x20], xmm9
00007d248dbd78cc  lea rdi, [rsp]
00007d248dbd78d0  mov esi, 0x00
00007d248dbd78d5  mov rax, 0x5BCEEF236530
00007d248dbd78df  call rax
00007d248dbd78e1  movaps xmm4, [rsp]
00007d248dbd78e5  add rsp, 0x30
00007d248dbd78e9  vmovaps xmm0, [rsp]
00007d248dbd78ee  vmovaps xmm1, [rsp+0x10]
00007d248dbd78f4  vmovaps xmm2, [rsp+0x20]
00007d248dbd78fa  vmovaps xmm3, [rsp+0x30]
00007d248dbd7900  vmovaps xmm5, [rsp+0x40]
00007d248dbd7906  vmovaps xmm6, [rsp+0x50]
00007d248dbd790c  vmovaps xmm7, [rsp+0x60]
00007d248dbd7912  vmovaps xmm8, [rsp+0x70]
00007d248dbd7918  vmovaps xmm9, [rsp+0x80]
00007d248dbd7921  vmovaps xmm10, [rsp+0x90]
00007d248dbd792a  vmovaps xmm11, [rsp+0xA0]
00007d248dbd7933  vmovaps xmm12, [rsp+0xB0]
00007d248dbd793c  vmovaps xmm13, [rsp+0xC0]
00007d248dbd7945  vmovaps xmm14, [rsp+0xD0]
00007d248dbd794e  vmovaps xmm15, [rsp+0xE0]
00007d248dbd7957  add rsp, 0xF0
00007d248dbd795e  pop r11
00007d248dbd7960  pop r10
00007d248dbd7962  pop r9
00007d248dbd7964  pop r8
00007d248dbd7966  pop rsi
00007d248dbd7967  pop rdi
00007d248dbd7968  pop rdx
00007d248dbd7969  pop rcx
00007d248dbd796a  pop rax
00007d248dbd796b  add rsp, 0x08
00007d248dbd796f  jmp 0x00007D248DBD5CF9
00007d248dbd7974  call 0x00007D248DAE5820
00007d248dbd7979  jmp 0x00007D248DBD5D06
00007d248dbd797e  sub rsp, 0x08
00007d248dbd7982  push rax
00007d248dbd7983  push rcx
00007d248dbd7984  push rdx
00007d248dbd7985  push rdi
00007d248dbd7986  push rsi
00007d248dbd7987  push r8
00007d248dbd7989  push r9
00007d248dbd798b  push r10
00007d248dbd798d  push r11
00007d248dbd798f  sub rsp, 0xF0
00007d248dbd7996  vmovaps [rsp], xmm0
00007d248dbd799b  vmovaps [rsp+0x10], xmm1
00007d248dbd79a1  vmovaps [rsp+0x20], xmm2
00007d248dbd79a7  vmovaps [rsp+0x30], xmm4
00007d248dbd79ad  vmovaps [rsp+0x40], xmm5
00007d248dbd79b3  vmovaps [rsp+0x50], xmm6
00007d248dbd79b9  vmovaps [rsp+0x60], xmm7
00007d248dbd79bf  vmovaps [rsp+0x70], xmm8
00007d248dbd79c5  vmovaps [rsp+0x80], xmm9
00007d248dbd79ce  vmovaps [rsp+0x90], xmm10
00007d248dbd79d7  vmovaps [rsp+0xA0], xmm11
00007d248dbd79e0  vmovaps [rsp+0xB0], xmm12
00007d248dbd79e9  vmovaps [rsp+0xC0], xmm13
00007d248dbd79f2  vmovaps [rsp+0xD0], xmm14
00007d248dbd79fb  vmovaps [rsp+0xE0], xmm15
00007d248dbd7a04  sub rsp, 0x30
00007d248dbd7a08  movaps [rsp], xmm3
00007d248dbd7a0c  movaps [rsp+0x10], xmm1
00007d248dbd7a11  movaps [rsp+0x20], xmm9
00007d248dbd7a17  lea rdi, [rsp]
00007d248dbd7a1b  mov esi, 0x00
00007d248dbd7a20  mov rax, 0x5BCEEF236530
00007d248dbd7a2a  call rax
00007d248dbd7a2c  movaps xmm3, [rsp]
00007d248dbd7a30  add rsp, 0x30
00007d248dbd7a34  vmovaps xmm0, [rsp]
00007d248dbd7a39  vmovaps xmm1, [rsp+0x10]
00007d248dbd7a3f  vmovaps xmm2, [rsp+0x20]
00007d248dbd7a45  vmovaps xmm4, [rsp+0x30]
00007d248dbd7a4b  vmovaps xmm5, [rsp+0x40]
00007d248dbd7a51  vmovaps xmm6, [rsp+0x50]
00007d248dbd7a57  vmovaps xmm7, [rsp+0x60]
00007d248dbd7a5d  vmovaps xmm8, [rsp+0x70]
00007d248dbd7a63  vmovaps xmm9, [rsp+0x80]
00007d248dbd7a6c  vmovaps xmm10, [rsp+0x90]
00007d248dbd7a75  vmovaps xmm11, [rsp+0xA0]
00007d248dbd7a7e  vmovaps xmm12, [rsp+0xB0]
00007d248dbd7a87  vmovaps xmm13, [rsp+0xC0]
00007d248dbd7a90  vmovaps xmm14, [rsp+0xD0]
00007d248dbd7a99  vmovaps xmm15, [rsp+0xE0]
00007d248dbd7aa2  add rsp, 0xF0
00007d248dbd7aa9  pop r11
00007d248dbd7aab  pop r10
00007d248dbd7aad  pop r9
00007d248dbd7aaf  pop r8
00007d248dbd7ab1  pop rsi
00007d248dbd7ab2  pop rdi
00007d248dbd7ab3  pop rdx
00007d248dbd7ab4  pop rcx
00007d248dbd7ab5  pop rax
00007d248dbd7ab6  add rsp, 0x08
00007d248dbd7aba  jmp 0x00007D248DBD5D43
00007d248dbd7abf  sub rsp, 0x08
00007d248dbd7ac3  push rax
00007d248dbd7ac4  push rcx
00007d248dbd7ac5  push rdx
00007d248dbd7ac6  push rdi
00007d248dbd7ac7  push rsi
00007d248dbd7ac8  push r8
00007d248dbd7aca  push r9
00007d248dbd7acc  push r10
00007d248dbd7ace  push r11
00007d248dbd7ad0  sub rsp, 0xF0
00007d248dbd7ad7  vmovaps [rsp], xmm0
00007d248dbd7adc  vmovaps [rsp+0x10], xmm2
00007d248dbd7ae2  vmovaps [rsp+0x20], xmm3
00007d248dbd7ae8  vmovaps [rsp+0x30], xmm4
00007d248dbd7aee  vmovaps [rsp+0x40], xmm5
00007d248dbd7af4  vmovaps [rsp+0x50], xmm6
00007d248dbd7afa  vmovaps [rsp+0x60], xmm7
00007d248dbd7b00  vmovaps [rsp+0x70], xmm8
00007d248dbd7b06  vmovaps [rsp+0x80], xmm9
00007d248dbd7b0f  vmovaps [rsp+0x90], xmm10
00007d248dbd7b18  vmovaps [rsp+0xA0], xmm11
00007d248dbd7b21  vmovaps [rsp+0xB0], xmm12
00007d248dbd7b2a  vmovaps [rsp+0xC0], xmm13
00007d248dbd7b33  vmovaps [rsp+0xD0], xmm14
00007d248dbd7b3c  vmovaps [rsp+0xE0], xmm15
00007d248dbd7b45  sub rsp, 0x30
00007d248dbd7b49  movaps [rsp], xmm1
00007d248dbd7b4d  movaps [rsp+0x10], xmm15
00007d248dbd7b53  movaps [rsp+0x20], xmm9
00007d248dbd7b59  lea rdi, [rsp]
00007d248dbd7b5d  mov esi, 0x00
00007d248dbd7b62  mov rax, 0x5BCEEF236530
00007d248dbd7b6c  call rax
00007d248dbd7b6e  movaps xmm1, [rsp]
00007d248dbd7b72  add rsp, 0x30
00007d248dbd7b76  vmovaps xmm0, [rsp]
00007d248dbd7b7b  vmovaps xmm2, [rsp+0x10]
00007d248dbd7b81  vmovaps xmm3, [rsp+0x20]
00007d248dbd7b87  vmovaps xmm4, [rsp+0x30]
00007d248dbd7b8d  vmovaps xmm5, [rsp+0x40]
00007d248dbd7b93  vmovaps xmm6, [rsp+0x50]
00007d248dbd7b99  vmovaps xmm7, [rsp+0x60]
00007d248dbd7b9f  vmovaps xmm8, [rsp+0x70]
00007d248dbd7ba5  vmovaps xmm9, [rsp+0x80]
00007d248dbd7bae  vmovaps xmm10, [rsp+0x90]
00007d248dbd7bb7  vmovaps xmm11, [rsp+0xA0]
00007d248dbd7bc0  vmovaps xmm12, [rsp+0xB0]
00007d248dbd7bc9  vmovaps xmm13, [rsp+0xC0]
00007d248dbd7bd2  vmovaps xmm14, [rsp+0xD0]
00007d248dbd7bdb  vmovaps xmm15, [rsp+0xE0]
00007d248dbd7be4  add rsp, 0xF0
00007d248dbd7beb  pop r11
00007d248dbd7bed  pop r10
00007d248dbd7bef  pop r9
00007d248dbd7bf1  pop r8
00007d248dbd7bf3  pop rsi
00007d248dbd7bf4  pop rdi
00007d248dbd7bf5  pop rdx
00007d248dbd7bf6  pop rcx
00007d248dbd7bf7  pop rax
00007d248dbd7bf8  add rsp, 0x08
00007d248dbd7bfc  jmp 0x00007D248DBD5DCB
00007d248dbd7c01  call 0x00007D248DAE5820
00007d248dbd7c06  jmp 0x00007D248DBD5DD8
00007d248dbd7c0b  sub rsp, 0x08
00007d248dbd7c0f  push rax
00007d248dbd7c10  push rcx
00007d248dbd7c11  push rdx
00007d248dbd7c12  push rdi
00007d248dbd7c13  push rsi
00007d248dbd7c14  push r8
00007d248dbd7c16  push r9
00007d248dbd7c18  push r10
00007d248dbd7c1a  push r11
00007d248dbd7c1c  sub rsp, 0xF0
00007d248dbd7c23  vmovaps [rsp], xmm0
00007d248dbd7c28  vmovaps [rsp+0x10], xmm2
00007d248dbd7c2e  vmovaps [rsp+0x20], xmm3
00007d248dbd7c34  vmovaps [rsp+0x30], xmm4
00007d248dbd7c3a  vmovaps [rsp+0x40], xmm5
00007d248dbd7c40  vmovaps [rsp+0x50], xmm6
00007d248dbd7c46  vmovaps [rsp+0x60], xmm7
00007d248dbd7c4c  vmovaps [rsp+0x70], xmm8
00007d248dbd7c52  vmovaps [rsp+0x80], xmm9
00007d248dbd7c5b  vmovaps [rsp+0x90], xmm10
00007d248dbd7c64  vmovaps [rsp+0xA0], xmm11
00007d248dbd7c6d  vmovaps [rsp+0xB0], xmm12
00007d248dbd7c76  vmovaps [rsp+0xC0], xmm13
00007d248dbd7c7f  vmovaps [rsp+0xD0], xmm14
00007d248dbd7c88  vmovaps [rsp+0xE0], xmm15
00007d248dbd7c91  sub rsp, 0x30
00007d248dbd7c95  movaps [rsp], xmm1
00007d248dbd7c99  movaps [rsp+0x10], xmm5
00007d248dbd7c9e  movaps [rsp+0x20], xmm7
00007d248dbd7ca3  lea rdi, [rsp]
00007d248dbd7ca7  mov esi, 0x00
00007d248dbd7cac  mov rax, 0x5BCEEF236530
00007d248dbd7cb6  call rax
00007d248dbd7cb8  movaps xmm1, [rsp]
00007d248dbd7cbc  add rsp, 0x30
00007d248dbd7cc0  vmovaps xmm0, [rsp]
00007d248dbd7cc5  vmovaps xmm2, [rsp+0x10]
00007d248dbd7ccb  vmovaps xmm3, [rsp+0x20]
00007d248dbd7cd1  vmovaps xmm4, [rsp+0x30]
00007d248dbd7cd7  vmovaps xmm5, [rsp+0x40]
00007d248dbd7cdd  vmovaps xmm6, [rsp+0x50]
00007d248dbd7ce3  vmovaps xmm7, [rsp+0x60]
00007d248dbd7ce9  vmovaps xmm8, [rsp+0x70]
00007d248dbd7cef  vmovaps xmm9, [rsp+0x80]
00007d248dbd7cf8  vmovaps xmm10, [rsp+0x90]
00007d248dbd7d01  vmovaps xmm11, [rsp+0xA0]
00007d248dbd7d0a  vmovaps xmm12, [rsp+0xB0]
00007d248dbd7d13  vmovaps xmm13, [rsp+0xC0]
00007d248dbd7d1c  vmovaps xmm14, [rsp+0xD0]
00007d248dbd7d25  vmovaps xmm15, [rsp+0xE0]
00007d248dbd7d2e  add rsp, 0xF0
00007d248dbd7d35  pop r11
00007d248dbd7d37  pop r10
00007d248dbd7d39  pop r9
00007d248dbd7d3b  pop r8
00007d248dbd7d3d  pop rsi
00007d248dbd7d3e  pop rdi
00007d248dbd7d3f  pop rdx
00007d248dbd7d40  pop rcx
00007d248dbd7d41  pop rax
00007d248dbd7d42  add rsp, 0x08
00007d248dbd7d46  jmp 0x00007D248DBD5E7D
00007d248dbd7d4b  sub rsp, 0x08
00007d248dbd7d4f  push rax
00007d248dbd7d50  push rcx
00007d248dbd7d51  push rdx
00007d248dbd7d52  push rdi
00007d248dbd7d53  push rsi
00007d248dbd7d54  push r8
00007d248dbd7d56  push r9
00007d248dbd7d58  push r10
00007d248dbd7d5a  push r11
00007d248dbd7d5c  sub rsp, 0xF0
00007d248dbd7d63  vmovaps [rsp], xmm0
00007d248dbd7d68  vmovaps [rsp+0x10], xmm1
00007d248dbd7d6e  vmovaps [rsp+0x20], xmm2
00007d248dbd7d74  vmovaps [rsp+0x30], xmm3
00007d248dbd7d7a  vmovaps [rsp+0x40], xmm4
00007d248dbd7d80  vmovaps [rsp+0x50], xmm5
00007d248dbd7d86  vmovaps [rsp+0x60], xmm6
00007d248dbd7d8c  vmovaps [rsp+0x70], xmm8
00007d248dbd7d92  vmovaps [rsp+0x80], xmm9
00007d248dbd7d9b  vmovaps [rsp+0x90], xmm10
00007d248dbd7da4  vmovaps [rsp+0xA0], xmm11
00007d248dbd7dad  vmovaps [rsp+0xB0], xmm12
00007d248dbd7db6  vmovaps [rsp+0xC0], xmm13
00007d248dbd7dbf  vmovaps [rsp+0xD0], xmm14
00007d248dbd7dc8  vmovaps [rsp+0xE0], xmm15
00007d248dbd7dd1  sub rsp, 0x30
00007d248dbd7dd5  movaps [rsp], xmm7
00007d248dbd7dd9  movaps [rsp+0x10], xmm5
00007d248dbd7dde  movaps [rsp+0x20], xmm15
00007d248dbd7de4  lea rdi, [rsp]
00007d248dbd7de8  mov esi, 0x00
00007d248dbd7ded  mov rax, 0x5BCEEF236530
00007d248dbd7df7  call rax
00007d248dbd7df9  movaps xmm7, [rsp]
00007d248dbd7dfd  add rsp, 0x30
00007d248dbd7e01  vmovaps xmm0, [rsp]
00007d248dbd7e06  vmovaps xmm1, [rsp+0x10]
00007d248dbd7e0c  vmovaps xmm2, [rsp+0x20]
00007d248dbd7e12  vmovaps xmm3, [rsp+0x30]
00007d248dbd7e18  vmovaps xmm4, [rsp+0x40]
00007d248dbd7e1e  vmovaps xmm5, [rsp+0x50]
00007d248dbd7e24  vmovaps xmm6, [rsp+0x60]
00007d248dbd7e2a  vmovaps xmm8, [rsp+0x70]
00007d248dbd7e30  vmovaps xmm9, [rsp+0x80]
00007d248dbd7e39  vmovaps xmm10, [rsp+0x90]
00007d248dbd7e42  vmovaps xmm11, [rsp+0xA0]
00007d248dbd7e4b  vmovaps xmm12, [rsp+0xB0]
00007d248dbd7e54  vmovaps xmm13, [rsp+0xC0]
00007d248dbd7e5d  vmovaps xmm14, [rsp+0xD0]
00007d248dbd7e66  vmovaps xmm15, [rsp+0xE0]
00007d248dbd7e6f  add rsp, 0xF0
00007d248dbd7e76  pop r11
00007d248dbd7e78  pop r10
00007d248dbd7e7a  pop r9
00007d248dbd7e7c  pop r8
00007d248dbd7e7e  pop rsi
00007d248dbd7e7f  pop rdi
00007d248dbd7e80  pop rdx
00007d248dbd7e81  pop rcx
00007d248dbd7e82  pop rax
00007d248dbd7e83  add rsp, 0x08
00007d248dbd7e87  jmp 0x00007D248DBD5EB3
00007d248dbd7e8c  call 0x00007D248DAD64F0
00007d248dbd7e91  jmp 0x00007D248DBD5EC0
00007d248dbd7e96  sub rsp, 0x08
00007d248dbd7e9a  push rax
00007d248dbd7e9b  push rcx
00007d248dbd7e9c  push rdx
00007d248dbd7e9d  push rdi
00007d248dbd7e9e  push rsi
00007d248dbd7e9f  push r8
00007d248dbd7ea1  push r9
00007d248dbd7ea3  push r10
00007d248dbd7ea5  push r11
00007d248dbd7ea7  sub rsp, 0xF0
00007d248dbd7eae  vmovaps [rsp], xmm0
00007d248dbd7eb3  vmovaps [rsp+0x10], xmm1
00007d248dbd7eb9  vmovaps [rsp+0x20], xmm2
00007d248dbd7ebf  vmovaps [rsp+0x30], xmm3
00007d248dbd7ec5  vmovaps [rsp+0x40], xmm4
00007d248dbd7ecb  vmovaps [rsp+0x50], xmm5
00007d248dbd7ed1  vmovaps [rsp+0x60], xmm6
00007d248dbd7ed7  vmovaps [rsp+0x70], xmm7
00007d248dbd7edd  vmovaps [rsp+0x80], xmm8
00007d248dbd7ee6  vmovaps [rsp+0x90], xmm9
00007d248dbd7eef  vmovaps [rsp+0xA0], xmm10
00007d248dbd7ef8  vmovaps [rsp+0xB0], xmm11
00007d248dbd7f01  vmovaps [rsp+0xC0], xmm12
00007d248dbd7f0a  vmovaps [rsp+0xD0], xmm13
00007d248dbd7f13  vmovaps [rsp+0xE0], xmm14
00007d248dbd7f1c  sub rsp, 0x30
00007d248dbd7f20  movaps [rsp], xmm15
00007d248dbd7f25  movaps [rsp+0x10], xmm5
00007d248dbd7f2a  movaps [rsp+0x20], xmm3
00007d248dbd7f2f  lea rdi, [rsp]
00007d248dbd7f33  mov esi, 0x00
00007d248dbd7f38  mov rax, 0x5BCEEF236530
00007d248dbd7f42  call rax
00007d248dbd7f44  movaps xmm15, [rsp]
00007d248dbd7f49  add rsp, 0x30
00007d248dbd7f4d  vmovaps xmm0, [rsp]
00007d248dbd7f52  vmovaps xmm1, [rsp+0x10]
00007d248dbd7f58  vmovaps xmm2, [rsp+0x20]
00007d248dbd7f5e  vmovaps xmm3, [rsp+0x30]
00007d248dbd7f64  vmovaps xmm4, [rsp+0x40]
00007d248dbd7f6a  vmovaps xmm5, [rsp+0x50]
00007d248dbd7f70  vmovaps xmm6, [rsp+0x60]
00007d248dbd7f76  vmovaps xmm7, [rsp+0x70]
00007d248dbd7f7c  vmovaps xmm8, [rsp+0x80]
00007d248dbd7f85  vmovaps xmm9, [rsp+0x90]
00007d248dbd7f8e  vmovaps xmm10, [rsp+0xA0]
00007d248dbd7f97  vmovaps xmm11, [rsp+0xB0]
00007d248dbd7fa0  vmovaps xmm12, [rsp+0xC0]
00007d248dbd7fa9  vmovaps xmm13, [rsp+0xD0]
00007d248dbd7fb2  vmovaps xmm14, [rsp+0xE0]
00007d248dbd7fbb  add rsp, 0xF0
00007d248dbd7fc2  pop r11
00007d248dbd7fc4  pop r10
00007d248dbd7fc6  pop r9
00007d248dbd7fc8  pop r8
00007d248dbd7fca  pop rsi
00007d248dbd7fcb  pop rdi
00007d248dbd7fcc  pop rdx
00007d248dbd7fcd  pop rcx
00007d248dbd7fce  pop rax
00007d248dbd7fcf  add rsp, 0x08
00007d248dbd7fd3  jmp 0x00007D248DBD5EE6
00007d248dbd7fd8  sub rsp, 0x08
00007d248dbd7fdc  push rax
00007d248dbd7fdd  push rcx
00007d248dbd7fde  push rdx
00007d248dbd7fdf  push rdi
00007d248dbd7fe0  push rsi
00007d248dbd7fe1  push r8
00007d248dbd7fe3  push r9
00007d248dbd7fe5  push r10
00007d248dbd7fe7  push r11
00007d248dbd7fe9  sub rsp, 0xF0
00007d248dbd7ff0  vmovaps [rsp], xmm0
00007d248dbd7ff5  vmovaps [rsp+0x10], xmm2
00007d248dbd7ffb  vmovaps [rsp+0x20], xmm3
00007d248dbd8001  vmovaps [rsp+0x30], xmm4
00007d248dbd8007  vmovaps [rsp+0x40], xmm5
00007d248dbd800d  vmovaps [rsp+0x50], xmm6
00007d248dbd8013  vmovaps [rsp+0x60], xmm7
00007d248dbd8019  vmovaps [rsp+0x70], xmm8
00007d248dbd801f  vmovaps [rsp+0x80], xmm9
00007d248dbd8028  vmovaps [rsp+0x90], xmm10
00007d248dbd8031  vmovaps [rsp+0xA0], xmm11
00007d248dbd803a  vmovaps [rsp+0xB0], xmm12
00007d248dbd8043  vmovaps [rsp+0xC0], xmm13
00007d248dbd804c  vmovaps [rsp+0xD0], xmm14
00007d248dbd8055  vmovaps [rsp+0xE0], xmm15
00007d248dbd805e  sub rsp, 0x30
00007d248dbd8062  movaps [rsp], xmm1
00007d248dbd8066  movaps [rsp+0x10], xmm5
00007d248dbd806b  movaps [rsp+0x20], xmm4
00007d248dbd8070  lea rdi, [rsp]
00007d248dbd8074  mov esi, 0x00
00007d248dbd8079  mov rax, 0x5BCEEF236530
00007d248dbd8083  call rax
00007d248dbd8085  movaps xmm1, [rsp]
00007d248dbd8089  add rsp, 0x30
00007d248dbd808d  vmovaps xmm0, [rsp]
00007d248dbd8092  vmovaps xmm2, [rsp+0x10]
00007d248dbd8098  vmovaps xmm3, [rsp+0x20]
00007d248dbd809e  vmovaps xmm4, [rsp+0x30]
00007d248dbd80a4  vmovaps xmm5, [rsp+0x40]
00007d248dbd80aa  vmovaps xmm6, [rsp+0x50]
00007d248dbd80b0  vmovaps xmm7, [rsp+0x60]
00007d248dbd80b6  vmovaps xmm8, [rsp+0x70]
00007d248dbd80bc  vmovaps xmm9, [rsp+0x80]
00007d248dbd80c5  vmovaps xmm10, [rsp+0x90]
00007d248dbd80ce  vmovaps xmm11, [rsp+0xA0]
00007d248dbd80d7  vmovaps xmm12, [rsp+0xB0]
00007d248dbd80e0  vmovaps xmm13, [rsp+0xC0]
00007d248dbd80e9  vmovaps xmm14, [rsp+0xD0]
00007d248dbd80f2  vmovaps xmm15, [rsp+0xE0]
00007d248dbd80fb  add rsp, 0xF0
00007d248dbd8102  pop r11
00007d248dbd8104  pop r10
00007d248dbd8106  pop r9
00007d248dbd8108  pop r8
00007d248dbd810a  pop rsi
00007d248dbd810b  pop rdi
00007d248dbd810c  pop rdx
00007d248dbd810d  pop rcx
00007d248dbd810e  pop rax
00007d248dbd810f  add rsp, 0x08
00007d248dbd8113  jmp 0x00007D248DBD5F06
00007d248dbd8118  sub rsp, 0x08
00007d248dbd811c  push rax
00007d248dbd811d  push rcx
00007d248dbd811e  push rdx
00007d248dbd811f  push rdi
00007d248dbd8120  push rsi
00007d248dbd8121  push r8
00007d248dbd8123  push r9
00007d248dbd8125  push r10
00007d248dbd8127  push r11
00007d248dbd8129  sub rsp, 0xF0
00007d248dbd8130  vmovaps [rsp], xmm0
00007d248dbd8135  vmovaps [rsp+0x10], xmm1
00007d248dbd813b  vmovaps [rsp+0x20], xmm2
00007d248dbd8141  vmovaps [rsp+0x30], xmm3
00007d248dbd8147  vmovaps [rsp+0x40], xmm5
00007d248dbd814d  vmovaps [rsp+0x50], xmm6
00007d248dbd8153  vmovaps [rsp+0x60], xmm7
00007d248dbd8159  vmovaps [rsp+0x70], xmm8
00007d248dbd815f  vmovaps [rsp+0x80], xmm9
00007d248dbd8168  vmovaps [rsp+0x90], xmm10
00007d248dbd8171  vmovaps [rsp+0xA0], xmm11
00007d248dbd817a  vmovaps [rsp+0xB0], xmm12
00007d248dbd8183  vmovaps [rsp+0xC0], xmm13
00007d248dbd818c  vmovaps [rsp+0xD0], xmm14
00007d248dbd8195  vmovaps [rsp+0xE0], xmm15
00007d248dbd819e  sub rsp, 0x30
00007d248dbd81a2  movaps [rsp], xmm4
00007d248dbd81a6  movaps [rsp+0x10], xmm3
00007d248dbd81ab  movaps [rsp+0x20], xmm5
00007d248dbd81b0  lea rdi, [rsp]
00007d248dbd81b4  mov esi, 0x00
00007d248dbd81b9  mov rax, 0x5BCEEF236530
00007d248dbd81c3  call rax
00007d248dbd81c5  movaps xmm4, [rsp]
00007d248dbd81c9  add rsp, 0x30
00007d248dbd81cd  vmovaps xmm0, [rsp]
00007d248dbd81d2  vmovaps xmm1, [rsp+0x10]
00007d248dbd81d8  vmovaps xmm2, [rsp+0x20]
00007d248dbd81de  vmovaps xmm3, [rsp+0x30]
00007d248dbd81e4  vmovaps xmm5, [rsp+0x40]
00007d248dbd81ea  vmovaps xmm6, [rsp+0x50]
00007d248dbd81f0  vmovaps xmm7, [rsp+0x60]
00007d248dbd81f6  vmovaps xmm8, [rsp+0x70]
00007d248dbd81fc  vmovaps xmm9, [rsp+0x80]
00007d248dbd8205  vmovaps xmm10, [rsp+0x90]
00007d248dbd820e  vmovaps xmm11, [rsp+0xA0]
00007d248dbd8217  vmovaps xmm12, [rsp+0xB0]
00007d248dbd8220  vmovaps xmm13, [rsp+0xC0]
00007d248dbd8229  vmovaps xmm14, [rsp+0xD0]
00007d248dbd8232  vmovaps xmm15, [rsp+0xE0]
00007d248dbd823b  add rsp, 0xF0
00007d248dbd8242  pop r11
00007d248dbd8244  pop r10
00007d248dbd8246  pop r9
00007d248dbd8248  pop r8
00007d248dbd824a  pop rsi
00007d248dbd824b  pop rdi
00007d248dbd824c  pop rdx
00007d248dbd824d  pop rcx
00007d248dbd824e  pop rax
00007d248dbd824f  add rsp, 0x08
00007d248dbd8253  jmp 0x00007D248DBD5F54
00007d248dbd8258  call 0x00007D248DAD64F0
00007d248dbd825d  jmp 0x00007D248DBD5F61
00007d248dbd8262  sub rsp, 0x08
00007d248dbd8266  push rax
00007d248dbd8267  push rcx
00007d248dbd8268  push rdx
00007d248dbd8269  push rdi
00007d248dbd826a  push rsi
00007d248dbd826b  push r8
00007d248dbd826d  push r9
00007d248dbd826f  push r10
00007d248dbd8271  push r11
00007d248dbd8273  sub rsp, 0xF0
00007d248dbd827a  vmovaps [rsp], xmm0
00007d248dbd827f  vmovaps [rsp+0x10], xmm1
00007d248dbd8285  vmovaps [rsp+0x20], xmm2
00007d248dbd828b  vmovaps [rsp+0x30], xmm3
00007d248dbd8291  vmovaps [rsp+0x40], xmm4
00007d248dbd8297  vmovaps [rsp+0x50], xmm6
00007d248dbd829d  vmovaps [rsp+0x60], xmm7
00007d248dbd82a3  vmovaps [rsp+0x70], xmm8
00007d248dbd82a9  vmovaps [rsp+0x80], xmm9
00007d248dbd82b2  vmovaps [rsp+0x90], xmm10
00007d248dbd82bb  vmovaps [rsp+0xA0], xmm11
00007d248dbd82c4  vmovaps [rsp+0xB0], xmm12
00007d248dbd82cd  vmovaps [rsp+0xC0], xmm13
00007d248dbd82d6  vmovaps [rsp+0xD0], xmm14
00007d248dbd82df  vmovaps [rsp+0xE0], xmm15
00007d248dbd82e8  sub rsp, 0x30
00007d248dbd82ec  movaps [rsp], xmm5
00007d248dbd82f0  movaps [rsp+0x10], xmm6
00007d248dbd82f5  movaps [rsp+0x20], xmm3
00007d248dbd82fa  lea rdi, [rsp]
00007d248dbd82fe  mov esi, 0x00
00007d248dbd8303  mov rax, 0x5BCEEF236530
00007d248dbd830d  call rax
00007d248dbd830f  movaps xmm5, [rsp]
00007d248dbd8313  add rsp, 0x30
00007d248dbd8317  vmovaps xmm0, [rsp]
00007d248dbd831c  vmovaps xmm1, [rsp+0x10]
00007d248dbd8322  vmovaps xmm2, [rsp+0x20]
00007d248dbd8328  vmovaps xmm3, [rsp+0x30]
00007d248dbd832e  vmovaps xmm4, [rsp+0x40]
00007d248dbd8334  vmovaps xmm6, [rsp+0x50]
00007d248dbd833a  vmovaps xmm7, [rsp+0x60]
00007d248dbd8340  vmovaps xmm8, [rsp+0x70]
00007d248dbd8346  vmovaps xmm9, [rsp+0x80]
00007d248dbd834f  vmovaps xmm10, [rsp+0x90]
00007d248dbd8358  vmovaps xmm11, [rsp+0xA0]
00007d248dbd8361  vmovaps xmm12, [rsp+0xB0]
00007d248dbd836a  vmovaps xmm13, [rsp+0xC0]
00007d248dbd8373  vmovaps xmm14, [rsp+0xD0]
00007d248dbd837c  vmovaps xmm15, [rsp+0xE0]
00007d248dbd8385  add rsp, 0xF0
00007d248dbd838c  pop r11
00007d248dbd838e  pop r10
00007d248dbd8390  pop r9
00007d248dbd8392  pop r8
00007d248dbd8394  pop rsi
00007d248dbd8395  pop rdi
00007d248dbd8396  pop rdx
00007d248dbd8397  pop rcx
00007d248dbd8398  pop rax
00007d248dbd8399  add rsp, 0x08
00007d248dbd839d  jmp 0x00007D248DBD5F87
00007d248dbd83a2  sub rsp, 0x08
00007d248dbd83a6  push rax
00007d248dbd83a7  push rcx
00007d248dbd83a8  push rdx
00007d248dbd83a9  push rdi
00007d248dbd83aa  push rsi
00007d248dbd83ab  push r8
00007d248dbd83ad  push r9
00007d248dbd83af  push r10
00007d248dbd83b1  push r11
00007d248dbd83b3  sub rsp, 0xF0
00007d248dbd83ba  vmovaps [rsp], xmm0
00007d248dbd83bf  vmovaps [rsp+0x10], xmm1
00007d248dbd83c5  vmovaps [rsp+0x20], xmm2
00007d248dbd83cb  vmovaps [rsp+0x30], xmm3
00007d248dbd83d1  vmovaps [rsp+0x40], xmm4
00007d248dbd83d7  vmovaps [rsp+0x50], xmm5
00007d248dbd83dd  vmovaps [rsp+0x60], xmm7
00007d248dbd83e3  vmovaps [rsp+0x70], xmm8
00007d248dbd83e9  vmovaps [rsp+0x80], xmm9
00007d248dbd83f2  vmovaps [rsp+0x90], xmm10
00007d248dbd83fb  vmovaps [rsp+0xA0], xmm11
00007d248dbd8404  vmovaps [rsp+0xB0], xmm12
00007d248dbd840d  vmovaps [rsp+0xC0], xmm13
00007d248dbd8416  vmovaps [rsp+0xD0], xmm14
00007d248dbd841f  vmovaps [rsp+0xE0], xmm15
00007d248dbd8428  sub rsp, 0x30
00007d248dbd842c  movaps [rsp], xmm6
00007d248dbd8430  movaps [rsp+0x10], xmm9
00007d248dbd8436  movaps [rsp+0x20], xmm1
00007d248dbd843b  lea rdi, [rsp]
00007d248dbd843f  mov esi, 0x00
00007d248dbd8444  mov rax, 0x5BCEEF236530
00007d248dbd844e  call rax
00007d248dbd8450  movaps xmm6, [rsp]
00007d248dbd8454  add rsp, 0x30
00007d248dbd8458  vmovaps xmm0, [rsp]
00007d248dbd845d  vmovaps xmm1, [rsp+0x10]
00007d248dbd8463  vmovaps xmm2, [rsp+0x20]
00007d248dbd8469  vmovaps xmm3, [rsp+0x30]
00007d248dbd846f  vmovaps xmm4, [rsp+0x40]
00007d248dbd8475  vmovaps xmm5, [rsp+0x50]
00007d248dbd847b  vmovaps xmm7, [rsp+0x60]
00007d248dbd8481  vmovaps xmm8, [rsp+0x70]
00007d248dbd8487  vmovaps xmm9, [rsp+0x80]
00007d248dbd8490  vmovaps xmm10, [rsp+0x90]
00007d248dbd8499  vmovaps xmm11, [rsp+0xA0]
00007d248dbd84a2  vmovaps xmm12, [rsp+0xB0]
00007d248dbd84ab  vmovaps xmm13, [rsp+0xC0]
00007d248dbd84b4  vmovaps xmm14, [rsp+0xD0]
00007d248dbd84bd  vmovaps xmm15, [rsp+0xE0]
00007d248dbd84c6  add rsp, 0xF0
00007d248dbd84cd  pop r11
00007d248dbd84cf  pop r10
00007d248dbd84d1  pop r9
00007d248dbd84d3  pop r8
00007d248dbd84d5  pop rsi
00007d248dbd84d6  pop rdi
00007d248dbd84d7  pop rdx
00007d248dbd84d8  pop rcx
00007d248dbd84d9  pop rax
00007d248dbd84da  add rsp, 0x08
00007d248dbd84de  jmp 0x00007D248DBD5FAB
00007d248dbd84e3  sub rsp, 0x08
00007d248dbd84e7  push rax
00007d248dbd84e8  push rcx
00007d248dbd84e9  push rdx
00007d248dbd84ea  push rdi
00007d248dbd84eb  push rsi
00007d248dbd84ec  push r8
00007d248dbd84ee  push r9
00007d248dbd84f0  push r10
00007d248dbd84f2  push r11
00007d248dbd84f4  sub rsp, 0xF0
00007d248dbd84fb  vmovaps [rsp], xmm0
00007d248dbd8500  vmovaps [rsp+0x10], xmm1
00007d248dbd8506  vmovaps [rsp+0x20], xmm2
00007d248dbd850c  vmovaps [rsp+0x30], xmm3
00007d248dbd8512  vmovaps [rsp+0x40], xmm4
00007d248dbd8518  vmovaps [rsp+0x50], xmm5
00007d248dbd851e  vmovaps [rsp+0x60], xmm6
00007d248dbd8524  vmovaps [rsp+0x70], xmm7
00007d248dbd852a  vmovaps [rsp+0x80], xmm8
00007d248dbd8533  vmovaps [rsp+0x90], xmm10
00007d248dbd853c  vmovaps [rsp+0xA0], xmm11
00007d248dbd8545  vmovaps [rsp+0xB0], xmm12
00007d248dbd854e  vmovaps [rsp+0xC0], xmm13
00007d248dbd8557  vmovaps [rsp+0xD0], xmm14
00007d248dbd8560  vmovaps [rsp+0xE0], xmm15
00007d248dbd8569  sub rsp, 0x30
00007d248dbd856d  movaps [rsp], xmm9
00007d248dbd8572  movaps [rsp+0x10], xmm3
00007d248dbd8577  movaps [rsp+0x20], xmm1
00007d248dbd857c  lea rdi, [rsp]
00007d248dbd8580  mov esi, 0x00
00007d248dbd8585  mov rax, 0x5BCEEF236530
00007d248dbd858f  call rax
00007d248dbd8591  movaps xmm9, [rsp]
00007d248dbd8596  add rsp, 0x30
00007d248dbd859a  vmovaps xmm0, [rsp]
00007d248dbd859f  vmovaps xmm1, [rsp+0x10]
00007d248dbd85a5  vmovaps xmm2, [rsp+0x20]
00007d248dbd85ab  vmovaps xmm3, [rsp+0x30]
00007d248dbd85b1  vmovaps xmm4, [rsp+0x40]
00007d248dbd85b7  vmovaps xmm5, [rsp+0x50]
00007d248dbd85bd  vmovaps xmm6, [rsp+0x60]
00007d248dbd85c3  vmovaps xmm7, [rsp+0x70]
00007d248dbd85c9  vmovaps xmm8, [rsp+0x80]
00007d248dbd85d2  vmovaps xmm10, [rsp+0x90]
00007d248dbd85db  vmovaps xmm11, [rsp+0xA0]
00007d248dbd85e4  vmovaps xmm12, [rsp+0xB0]
00007d248dbd85ed  vmovaps xmm13, [rsp+0xC0]
00007d248dbd85f6  vmovaps xmm14, [rsp+0xD0]
00007d248dbd85ff  vmovaps xmm15, [rsp+0xE0]
00007d248dbd8608  add rsp, 0xF0
00007d248dbd860f  pop r11
00007d248dbd8611  pop r10
00007d248dbd8613  pop r9
00007d248dbd8615  pop r8
00007d248dbd8617  pop rsi
00007d248dbd8618  pop rdi
00007d248dbd8619  pop rdx
00007d248dbd861a  pop rcx
00007d248dbd861b  pop rax
00007d248dbd861c  add rsp, 0x08
00007d248dbd8620  jmp 0x00007D248DBD5FF7
00007d248dbd8625  call 0x00007D248DAD64F0
00007d248dbd862a  jmp 0x00007D248DBD6004
00007d248dbd862f  sub rsp, 0x08
00007d248dbd8633  push rax
00007d248dbd8634  push rcx
00007d248dbd8635  push rdx
00007d248dbd8636  push rdi
00007d248dbd8637  push rsi
00007d248dbd8638  push r8
00007d248dbd863a  push r9
00007d248dbd863c  push r10
00007d248dbd863e  push r11
00007d248dbd8640  sub rsp, 0xF0
00007d248dbd8647  vmovaps [rsp], xmm0
00007d248dbd864c  vmovaps [rsp+0x10], xmm1
00007d248dbd8652  vmovaps [rsp+0x20], xmm2
00007d248dbd8658  vmovaps [rsp+0x30], xmm3
00007d248dbd865e  vmovaps [rsp+0x40], xmm4
00007d248dbd8664  vmovaps [rsp+0x50], xmm5
00007d248dbd866a  vmovaps [rsp+0x60], xmm6
00007d248dbd8670  vmovaps [rsp+0x70], xmm7
00007d248dbd8676  vmovaps [rsp+0x80], xmm8
00007d248dbd867f  vmovaps [rsp+0x90], xmm9
00007d248dbd8688  vmovaps [rsp+0xA0], xmm10
00007d248dbd8691  vmovaps [rsp+0xB0], xmm11
00007d248dbd869a  vmovaps [rsp+0xC0], xmm12
00007d248dbd86a3  vmovaps [rsp+0xD0], xmm13
00007d248dbd86ac  vmovaps [rsp+0xE0], xmm14
00007d248dbd86b5  sub rsp, 0x30
00007d248dbd86b9  movaps [rsp], xmm15
00007d248dbd86be  movaps [rsp+0x10], xmm3
00007d248dbd86c3  movaps [rsp+0x20], xmm7
00007d248dbd86c8  lea rdi, [rsp]
00007d248dbd86cc  mov esi, 0x00
00007d248dbd86d1  mov rax, 0x5BCEEF236530
00007d248dbd86db  call rax
00007d248dbd86dd  movaps xmm15, [rsp]
00007d248dbd86e2  add rsp, 0x30
00007d248dbd86e6  vmovaps xmm0, [rsp]
00007d248dbd86eb  vmovaps xmm1, [rsp+0x10]
00007d248dbd86f1  vmovaps xmm2, [rsp+0x20]
00007d248dbd86f7  vmovaps xmm3, [rsp+0x30]
00007d248dbd86fd  vmovaps xmm4, [rsp+0x40]
00007d248dbd8703  vmovaps xmm5, [rsp+0x50]
00007d248dbd8709  vmovaps xmm6, [rsp+0x60]
00007d248dbd870f  vmovaps xmm7, [rsp+0x70]
00007d248dbd8715  vmovaps xmm8, [rsp+0x80]
00007d248dbd871e  vmovaps xmm9, [rsp+0x90]
00007d248dbd8727  vmovaps xmm10, [rsp+0xA0]
00007d248dbd8730  vmovaps xmm11, [rsp+0xB0]
00007d248dbd8739  vmovaps xmm12, [rsp+0xC0]
00007d248dbd8742  vmovaps xmm13, [rsp+0xD0]
00007d248dbd874b  vmovaps xmm14, [rsp+0xE0]
00007d248dbd8754  add rsp, 0xF0
00007d248dbd875b  pop r11
00007d248dbd875d  pop r10
00007d248dbd875f  pop r9
00007d248dbd8761  pop r8
00007d248dbd8763  pop rsi
00007d248dbd8764  pop rdi
00007d248dbd8765  pop rdx
00007d248dbd8766  pop rcx
00007d248dbd8767  pop rax
00007d248dbd8768  add rsp, 0x08
00007d248dbd876c  jmp 0x00007D248DBD6030
00007d248dbd8771  sub rsp, 0x08
00007d248dbd8775  push rax
00007d248dbd8776  push rcx
00007d248dbd8777  push rdx
00007d248dbd8778  push rdi
00007d248dbd8779  push rsi
00007d248dbd877a  push r8
00007d248dbd877c  push r9
00007d248dbd877e  push r10
00007d248dbd8780  push r11
00007d248dbd8782  sub rsp, 0xF0
00007d248dbd8789  vmovaps [rsp], xmm0
00007d248dbd878e  vmovaps [rsp+0x10], xmm1
00007d248dbd8794  vmovaps [rsp+0x20], xmm2
00007d248dbd879a  vmovaps [rsp+0x30], xmm4
00007d248dbd87a0  vmovaps [rsp+0x40], xmm5
00007d248dbd87a6  vmovaps [rsp+0x50], xmm6
00007d248dbd87ac  vmovaps [rsp+0x60], xmm7
00007d248dbd87b2  vmovaps [rsp+0x70], xmm8
00007d248dbd87b8  vmovaps [rsp+0x80], xmm9
00007d248dbd87c1  vmovaps [rsp+0x90], xmm10
00007d248dbd87ca  vmovaps [rsp+0xA0], xmm11
00007d248dbd87d3  vmovaps [rsp+0xB0], xmm12
00007d248dbd87dc  vmovaps [rsp+0xC0], xmm13
00007d248dbd87e5  vmovaps [rsp+0xD0], xmm14
00007d248dbd87ee  vmovaps [rsp+0xE0], xmm15
00007d248dbd87f7  sub rsp, 0x30
00007d248dbd87fb  movaps [rsp], xmm3
00007d248dbd87ff  movaps [rsp+0x10], xmm1
00007d248dbd8804  movaps [rsp+0x20], xmm15
00007d248dbd880a  lea rdi, [rsp]
00007d248dbd880e  mov esi, 0x00
00007d248dbd8813  mov rax, 0x5BCEEF236530
00007d248dbd881d  call rax
00007d248dbd881f  movaps xmm3, [rsp]
00007d248dbd8823  add rsp, 0x30
00007d248dbd8827  vmovaps xmm0, [rsp]
00007d248dbd882c  vmovaps xmm1, [rsp+0x10]
00007d248dbd8832  vmovaps xmm2, [rsp+0x20]
00007d248dbd8838  vmovaps xmm4, [rsp+0x30]
00007d248dbd883e  vmovaps xmm5, [rsp+0x40]
00007d248dbd8844  vmovaps xmm6, [rsp+0x50]
00007d248dbd884a  vmovaps xmm7, [rsp+0x60]
00007d248dbd8850  vmovaps xmm8, [rsp+0x70]
00007d248dbd8856  vmovaps xmm9, [rsp+0x80]
00007d248dbd885f  vmovaps xmm10, [rsp+0x90]
00007d248dbd8868  vmovaps xmm11, [rsp+0xA0]
00007d248dbd8871  vmovaps xmm12, [rsp+0xB0]
00007d248dbd887a  vmovaps xmm13, [rsp+0xC0]
00007d248dbd8883  vmovaps xmm14, [rsp+0xD0]
00007d248dbd888c  vmovaps xmm15, [rsp+0xE0]
00007d248dbd8895  add rsp, 0xF0
00007d248dbd889c  pop r11
00007d248dbd889e  pop r10
00007d248dbd88a0  pop r9
00007d248dbd88a2  pop r8
00007d248dbd88a4  pop rsi
00007d248dbd88a5  pop rdi
00007d248dbd88a6  pop rdx
00007d248dbd88a7  pop rcx
00007d248dbd88a8  pop rax
00007d248dbd88a9  add rsp, 0x08
00007d248dbd88ad  jmp 0x00007D248DBD60BF
00007d248dbd88b2  call 0x00007D248DAD64F0
00007d248dbd88b7  jmp 0x00007D248DBD60C9
00007d248dbd88bc  sub rsp, 0x08
00007d248dbd88c0  push rax
00007d248dbd88c1  push rcx
00007d248dbd88c2  push rdx
00007d248dbd88c3  push rdi
00007d248dbd88c4  push rsi
00007d248dbd88c5  push r8
00007d248dbd88c7  push r9
00007d248dbd88c9  push r10
00007d248dbd88cb  push r11
00007d248dbd88cd  sub rsp, 0xF0
00007d248dbd88d4  vmovaps [rsp], xmm0
00007d248dbd88d9  vmovaps [rsp+0x10], xmm1
00007d248dbd88df  vmovaps [rsp+0x20], xmm2
00007d248dbd88e5  vmovaps [rsp+0x30], xmm3
00007d248dbd88eb  vmovaps [rsp+0x40], xmm4
00007d248dbd88f1  vmovaps [rsp+0x50], xmm5
00007d248dbd88f7  vmovaps [rsp+0x60], xmm6
00007d248dbd88fd  vmovaps [rsp+0x70], xmm7
00007d248dbd8903  vmovaps [rsp+0x80], xmm8
00007d248dbd890c  vmovaps [rsp+0x90], xmm9
00007d248dbd8915  vmovaps [rsp+0xA0], xmm10
00007d248dbd891e  vmovaps [rsp+0xB0], xmm11
00007d248dbd8927  vmovaps [rsp+0xC0], xmm12
00007d248dbd8930  vmovaps [rsp+0xD0], xmm13
00007d248dbd8939  vmovaps [rsp+0xE0], xmm14
00007d248dbd8942  sub rsp, 0x30
00007d248dbd8946  movaps [rsp], xmm15
00007d248dbd894b  movaps [rsp+0x10], xmm14
00007d248dbd8951  movaps [rsp+0x20], xmm4
00007d248dbd8956  lea rdi, [rsp]
00007d248dbd895a  mov esi, 0x00
00007d248dbd895f  mov rax, 0x5BCEEF236530
00007d248dbd8969  call rax
00007d248dbd896b  movaps xmm15, [rsp]
00007d248dbd8970  add rsp, 0x30
00007d248dbd8974  vmovaps xmm0, [rsp]
00007d248dbd8979  vmovaps xmm1, [rsp+0x10]
00007d248dbd897f  vmovaps xmm2, [rsp+0x20]
00007d248dbd8985  vmovaps xmm3, [rsp+0x30]
00007d248dbd898b  vmovaps xmm4, [rsp+0x40]
00007d248dbd8991  vmovaps xmm5, [rsp+0x50]
00007d248dbd8997  vmovaps xmm6, [rsp+0x60]
00007d248dbd899d  vmovaps xmm7, [rsp+0x70]
00007d248dbd89a3  vmovaps xmm8, [rsp+0x80]
00007d248dbd89ac  vmovaps xmm9, [rsp+0x90]
00007d248dbd89b5  vmovaps xmm10, [rsp+0xA0]
00007d248dbd89be  vmovaps xmm11, [rsp+0xB0]
00007d248dbd89c7  vmovaps xmm12, [rsp+0xC0]
00007d248dbd89d0  vmovaps xmm13, [rsp+0xD0]
00007d248dbd89d9  vmovaps xmm14, [rsp+0xE0]
00007d248dbd89e2  add rsp, 0xF0
00007d248dbd89e9  pop r11
00007d248dbd89eb  pop r10
00007d248dbd89ed  pop r9
00007d248dbd89ef  pop r8
00007d248dbd89f1  pop rsi
00007d248dbd89f2  pop rdi
00007d248dbd89f3  pop rdx
00007d248dbd89f4  pop rcx
00007d248dbd89f5  pop rax
00007d248dbd89f6  add rsp, 0x08
00007d248dbd89fa  jmp 0x00007D248DBD60F7
00007d248dbd89ff  sub rsp, 0x08
00007d248dbd8a03  push rax
00007d248dbd8a04  push rcx
00007d248dbd8a05  push rdx
00007d248dbd8a06  push rdi
00007d248dbd8a07  push rsi
00007d248dbd8a08  push r8
00007d248dbd8a0a  push r9
00007d248dbd8a0c  push r10
00007d248dbd8a0e  push r11
00007d248dbd8a10  sub rsp, 0xF0
00007d248dbd8a17  vmovaps [rsp], xmm0
00007d248dbd8a1c  vmovaps [rsp+0x10], xmm1
00007d248dbd8a22  vmovaps [rsp+0x20], xmm2
00007d248dbd8a28  vmovaps [rsp+0x30], xmm3
00007d248dbd8a2e  vmovaps [rsp+0x40], xmm4
00007d248dbd8a34  vmovaps [rsp+0x50], xmm5
00007d248dbd8a3a  vmovaps [rsp+0x60], xmm6
00007d248dbd8a40  vmovaps [rsp+0x70], xmm7
00007d248dbd8a46  vmovaps [rsp+0x80], xmm8
00007d248dbd8a4f  vmovaps [rsp+0x90], xmm9
00007d248dbd8a58  vmovaps [rsp+0xA0], xmm10
00007d248dbd8a61  vmovaps [rsp+0xB0], xmm11
00007d248dbd8a6a  vmovaps [rsp+0xC0], xmm12
00007d248dbd8a73  vmovaps [rsp+0xD0], xmm13
00007d248dbd8a7c  vmovaps [rsp+0xE0], xmm15
00007d248dbd8a85  sub rsp, 0x30
00007d248dbd8a89  movaps [rsp], xmm14
00007d248dbd8a8e  movaps [rsp+0x10], xmm2
00007d248dbd8a93  movaps [rsp+0x20], xmm1
00007d248dbd8a98  lea rdi, [rsp]
00007d248dbd8a9c  mov esi, 0x00
00007d248dbd8aa1  mov rax, 0x5BCEEF236530
00007d248dbd8aab  call rax
00007d248dbd8aad  movaps xmm14, [rsp]
00007d248dbd8ab2  add rsp, 0x30
00007d248dbd8ab6  vmovaps xmm0, [rsp]
00007d248dbd8abb  vmovaps xmm1, [rsp+0x10]
00007d248dbd8ac1  vmovaps xmm2, [rsp+0x20]
00007d248dbd8ac7  vmovaps xmm3, [rsp+0x30]
00007d248dbd8acd  vmovaps xmm4, [rsp+0x40]
00007d248dbd8ad3  vmovaps xmm5, [rsp+0x50]
00007d248dbd8ad9  vmovaps xmm6, [rsp+0x60]
00007d248dbd8adf  vmovaps xmm7, [rsp+0x70]
00007d248dbd8ae5  vmovaps xmm8, [rsp+0x80]
00007d248dbd8aee  vmovaps xmm9, [rsp+0x90]
00007d248dbd8af7  vmovaps xmm10, [rsp+0xA0]
00007d248dbd8b00  vmovaps xmm11, [rsp+0xB0]
00007d248dbd8b09  vmovaps xmm12, [rsp+0xC0]
00007d248dbd8b12  vmovaps xmm13, [rsp+0xD0]
00007d248dbd8b1b  vmovaps xmm15, [rsp+0xE0]
00007d248dbd8b24  add rsp, 0xF0
00007d248dbd8b2b  pop r11
00007d248dbd8b2d  pop r10
00007d248dbd8b2f  pop r9
00007d248dbd8b31  pop r8
00007d248dbd8b33  pop rsi
00007d248dbd8b34  pop rdi
00007d248dbd8b35  pop rdx
00007d248dbd8b36  pop rcx
00007d248dbd8b37  pop rax
00007d248dbd8b38  add rsp, 0x08
00007d248dbd8b3c  jmp 0x00007D248DBD611D
00007d248dbd8b41  sub rsp, 0x08
00007d248dbd8b45  push rax
00007d248dbd8b46  push rcx
00007d248dbd8b47  push rdx
00007d248dbd8b48  push rdi
00007d248dbd8b49  push rsi
00007d248dbd8b4a  push r8
00007d248dbd8b4c  push r9
00007d248dbd8b4e  push r10
00007d248dbd8b50  push r11
00007d248dbd8b52  sub rsp, 0xF0
00007d248dbd8b59  vmovaps [rsp], xmm0
00007d248dbd8b5e  vmovaps [rsp+0x10], xmm2
00007d248dbd8b64  vmovaps [rsp+0x20], xmm3
00007d248dbd8b6a  vmovaps [rsp+0x30], xmm4
00007d248dbd8b70  vmovaps [rsp+0x40], xmm5
00007d248dbd8b76  vmovaps [rsp+0x50], xmm6
00007d248dbd8b7c  vmovaps [rsp+0x60], xmm7
00007d248dbd8b82  vmovaps [rsp+0x70], xmm8
00007d248dbd8b88  vmovaps [rsp+0x80], xmm9
00007d248dbd8b91  vmovaps [rsp+0x90], xmm10
00007d248dbd8b9a  vmovaps [rsp+0xA0], xmm11
00007d248dbd8ba3  vmovaps [rsp+0xB0], xmm12
00007d248dbd8bac  vmovaps [rsp+0xC0], xmm13
00007d248dbd8bb5  vmovaps [rsp+0xD0], xmm14
00007d248dbd8bbe  vmovaps [rsp+0xE0], xmm15
00007d248dbd8bc7  sub rsp, 0x30
00007d248dbd8bcb  movaps [rsp], xmm1
00007d248dbd8bcf  movaps [rsp+0x10], xmm4
00007d248dbd8bd4  movaps [rsp+0x20], xmm9
00007d248dbd8bda  lea rdi, [rsp]
00007d248dbd8bde  mov esi, 0x00
00007d248dbd8be3  mov rax, 0x5BCEEF236530
00007d248dbd8bed  call rax
00007d248dbd8bef  movaps xmm1, [rsp]
00007d248dbd8bf3  add rsp, 0x30
00007d248dbd8bf7  vmovaps xmm0, [rsp]
00007d248dbd8bfc  vmovaps xmm2, [rsp+0x10]
00007d248dbd8c02  vmovaps xmm3, [rsp+0x20]
00007d248dbd8c08  vmovaps xmm4, [rsp+0x30]
00007d248dbd8c0e  vmovaps xmm5, [rsp+0x40]
00007d248dbd8c14  vmovaps xmm6, [rsp+0x50]
00007d248dbd8c1a  vmovaps xmm7, [rsp+0x60]
00007d248dbd8c20  vmovaps xmm8, [rsp+0x70]
00007d248dbd8c26  vmovaps xmm9, [rsp+0x80]
00007d248dbd8c2f  vmovaps xmm10, [rsp+0x90]
00007d248dbd8c38  vmovaps xmm11, [rsp+0xA0]
00007d248dbd8c41  vmovaps xmm12, [rsp+0xB0]
00007d248dbd8c4a  vmovaps xmm13, [rsp+0xC0]
00007d248dbd8c53  vmovaps xmm14, [rsp+0xD0]
00007d248dbd8c5c  vmovaps xmm15, [rsp+0xE0]
00007d248dbd8c65  add rsp, 0xF0
00007d248dbd8c6c  pop r11
00007d248dbd8c6e  pop r10
00007d248dbd8c70  pop r9
00007d248dbd8c72  pop r8
00007d248dbd8c74  pop rsi
00007d248dbd8c75  pop rdi
00007d248dbd8c76  pop rdx
00007d248dbd8c77  pop rcx
00007d248dbd8c78  pop rax
00007d248dbd8c79  add rsp, 0x08
00007d248dbd8c7d  jmp 0x00007D248DBD613B
00007d248dbd8c82  sub rsp, 0x08
00007d248dbd8c86  push rax
00007d248dbd8c87  push rcx
00007d248dbd8c88  push rdx
00007d248dbd8c89  push rdi
00007d248dbd8c8a  push rsi
00007d248dbd8c8b  push r8
00007d248dbd8c8d  push r9
00007d248dbd8c8f  push r10
00007d248dbd8c91  push r11
00007d248dbd8c93  sub rsp, 0xF0
00007d248dbd8c9a  vmovaps [rsp], xmm0
00007d248dbd8c9f  vmovaps [rsp+0x10], xmm1
00007d248dbd8ca5  vmovaps [rsp+0x20], xmm2
00007d248dbd8cab  vmovaps [rsp+0x30], xmm3
00007d248dbd8cb1  vmovaps [rsp+0x40], xmm5
00007d248dbd8cb7  vmovaps [rsp+0x50], xmm6
00007d248dbd8cbd  vmovaps [rsp+0x60], xmm7
00007d248dbd8cc3  vmovaps [rsp+0x70], xmm8
00007d248dbd8cc9  vmovaps [rsp+0x80], xmm9
00007d248dbd8cd2  vmovaps [rsp+0x90], xmm10
00007d248dbd8cdb  vmovaps [rsp+0xA0], xmm11
00007d248dbd8ce4  vmovaps [rsp+0xB0], xmm12
00007d248dbd8ced  vmovaps [rsp+0xC0], xmm13
00007d248dbd8cf6  vmovaps [rsp+0xD0], xmm14
00007d248dbd8cff  vmovaps [rsp+0xE0], xmm15
00007d248dbd8d08  sub rsp, 0x30
00007d248dbd8d0c  movaps [rsp], xmm4
00007d248dbd8d10  movaps [rsp+0x10], xmm2
00007d248dbd8d15  movaps [rsp+0x20], xmm9
00007d248dbd8d1b  lea rdi, [rsp]
00007d248dbd8d1f  mov esi, 0x00
00007d248dbd8d24  mov rax, 0x5BCEEF236530
00007d248dbd8d2e  call rax
00007d248dbd8d30  movaps xmm4, [rsp]
00007d248dbd8d34  add rsp, 0x30
00007d248dbd8d38  vmovaps xmm0, [rsp]
00007d248dbd8d3d  vmovaps xmm1, [rsp+0x10]
00007d248dbd8d43  vmovaps xmm2, [rsp+0x20]
00007d248dbd8d49  vmovaps xmm3, [rsp+0x30]
00007d248dbd8d4f  vmovaps xmm5, [rsp+0x40]
00007d248dbd8d55  vmovaps xmm6, [rsp+0x50]
00007d248dbd8d5b  vmovaps xmm7, [rsp+0x60]
00007d248dbd8d61  vmovaps xmm8, [rsp+0x70]
00007d248dbd8d67  vmovaps xmm9, [rsp+0x80]
00007d248dbd8d70  vmovaps xmm10, [rsp+0x90]
00007d248dbd8d79  vmovaps xmm11, [rsp+0xA0]
00007d248dbd8d82  vmovaps xmm12, [rsp+0xB0]
00007d248dbd8d8b  vmovaps xmm13, [rsp+0xC0]
00007d248dbd8d94  vmovaps xmm14, [rsp+0xD0]
00007d248dbd8d9d  vmovaps xmm15, [rsp+0xE0]
00007d248dbd8da6  add rsp, 0xF0
00007d248dbd8dad  pop r11
00007d248dbd8daf  pop r10
00007d248dbd8db1  pop r9
00007d248dbd8db3  pop r8
00007d248dbd8db5  pop rsi
00007d248dbd8db6  pop rdi
00007d248dbd8db7  pop rdx
00007d248dbd8db8  pop rcx
00007d248dbd8db9  pop rax
00007d248dbd8dba  add rsp, 0x08
00007d248dbd8dbe  jmp 0x00007D248DBD616B
00007d248dbd8dc3  sub rsp, 0x08
00007d248dbd8dc7  push rax
00007d248dbd8dc8  push rcx
00007d248dbd8dc9  push rdx
00007d248dbd8dca  push rdi
00007d248dbd8dcb  push rsi
00007d248dbd8dcc  push r8
00007d248dbd8dce  push r9
00007d248dbd8dd0  push r10
00007d248dbd8dd2  push r11
00007d248dbd8dd4  sub rsp, 0xF0
00007d248dbd8ddb  vmovaps [rsp], xmm0
00007d248dbd8de0  vmovaps [rsp+0x10], xmm1
00007d248dbd8de6  vmovaps [rsp+0x20], xmm2
00007d248dbd8dec  vmovaps [rsp+0x30], xmm3
00007d248dbd8df2  vmovaps [rsp+0x40], xmm4
00007d248dbd8df8  vmovaps [rsp+0x50], xmm5
00007d248dbd8dfe  vmovaps [rsp+0x60], xmm6
00007d248dbd8e04  vmovaps [rsp+0x70], xmm7
00007d248dbd8e0a  vmovaps [rsp+0x80], xmm8
00007d248dbd8e13  vmovaps [rsp+0x90], xmm10
00007d248dbd8e1c  vmovaps [rsp+0xA0], xmm11
00007d248dbd8e25  vmovaps [rsp+0xB0], xmm12
00007d248dbd8e2e  vmovaps [rsp+0xC0], xmm13
00007d248dbd8e37  vmovaps [rsp+0xD0], xmm14
00007d248dbd8e40  vmovaps [rsp+0xE0], xmm15
00007d248dbd8e49  sub rsp, 0x30
00007d248dbd8e4d  movaps [rsp], xmm9
00007d248dbd8e52  movaps [rsp+0x10], xmm2
00007d248dbd8e57  movaps [rsp+0x20], xmm1
00007d248dbd8e5c  lea rdi, [rsp]
00007d248dbd8e60  mov esi, 0x00
00007d248dbd8e65  mov rax, 0x5BCEEF236530
00007d248dbd8e6f  call rax
00007d248dbd8e71  movaps xmm9, [rsp]
00007d248dbd8e76  add rsp, 0x30
00007d248dbd8e7a  vmovaps xmm0, [rsp]
00007d248dbd8e7f  vmovaps xmm1, [rsp+0x10]
00007d248dbd8e85  vmovaps xmm2, [rsp+0x20]
00007d248dbd8e8b  vmovaps xmm3, [rsp+0x30]
00007d248dbd8e91  vmovaps xmm4, [rsp+0x40]
00007d248dbd8e97  vmovaps xmm5, [rsp+0x50]
00007d248dbd8e9d  vmovaps xmm6, [rsp+0x60]
00007d248dbd8ea3  vmovaps xmm7, [rsp+0x70]
00007d248dbd8ea9  vmovaps xmm8, [rsp+0x80]
00007d248dbd8eb2  vmovaps xmm10, [rsp+0x90]
00007d248dbd8ebb  vmovaps xmm11, [rsp+0xA0]
00007d248dbd8ec4  vmovaps xmm12, [rsp+0xB0]
00007d248dbd8ecd  vmovaps xmm13, [rsp+0xC0]
00007d248dbd8ed6  vmovaps xmm14, [rsp+0xD0]
00007d248dbd8edf  vmovaps xmm15, [rsp+0xE0]
00007d248dbd8ee8  add rsp, 0xF0
00007d248dbd8eef  pop r11
00007d248dbd8ef1  pop r10
00007d248dbd8ef3  pop r9
00007d248dbd8ef5  pop r8
00007d248dbd8ef7  pop rsi
00007d248dbd8ef8  pop rdi
00007d248dbd8ef9  pop rdx
00007d248dbd8efa  pop rcx
00007d248dbd8efb  pop rax
00007d248dbd8efc  add rsp, 0x08
00007d248dbd8f00  jmp 0x00007D248DBD61A1
00007d248dbd8f05  sub rsp, 0x08
00007d248dbd8f09  push rax
00007d248dbd8f0a  push rcx
00007d248dbd8f0b  push rdx
00007d248dbd8f0c  push rdi
00007d248dbd8f0d  push rsi
00007d248dbd8f0e  push r8
00007d248dbd8f10  push r9
00007d248dbd8f12  push r10
00007d248dbd8f14  push r11
00007d248dbd8f16  sub rsp, 0xF0
00007d248dbd8f1d  vmovaps [rsp], xmm0
00007d248dbd8f22  vmovaps [rsp+0x10], xmm2
00007d248dbd8f28  vmovaps [rsp+0x20], xmm3
00007d248dbd8f2e  vmovaps [rsp+0x30], xmm4
00007d248dbd8f34  vmovaps [rsp+0x40], xmm5
00007d248dbd8f3a  vmovaps [rsp+0x50], xmm6
00007d248dbd8f40  vmovaps [rsp+0x60], xmm7
00007d248dbd8f46  vmovaps [rsp+0x70], xmm8
00007d248dbd8f4c  vmovaps [rsp+0x80], xmm9
00007d248dbd8f55  vmovaps [rsp+0x90], xmm10
00007d248dbd8f5e  vmovaps [rsp+0xA0], xmm11
00007d248dbd8f67  vmovaps [rsp+0xB0], xmm12
00007d248dbd8f70  vmovaps [rsp+0xC0], xmm13
00007d248dbd8f79  vmovaps [rsp+0xD0], xmm14
00007d248dbd8f82  vmovaps [rsp+0xE0], xmm15
00007d248dbd8f8b  sub rsp, 0x30
00007d248dbd8f8f  movaps [rsp], xmm1
00007d248dbd8f93  movaps [rsp+0x10], xmm15
00007d248dbd8f99  movaps [rsp+0x20], xmm6
00007d248dbd8f9e  lea rdi, [rsp]
00007d248dbd8fa2  mov esi, 0x00
00007d248dbd8fa7  mov rax, 0x5BCEEF236530
00007d248dbd8fb1  call rax
00007d248dbd8fb3  movaps xmm1, [rsp]
00007d248dbd8fb7  add rsp, 0x30
00007d248dbd8fbb  vmovaps xmm0, [rsp]
00007d248dbd8fc0  vmovaps xmm2, [rsp+0x10]
00007d248dbd8fc6  vmovaps xmm3, [rsp+0x20]
00007d248dbd8fcc  vmovaps xmm4, [rsp+0x30]
00007d248dbd8fd2  vmovaps xmm5, [rsp+0x40]
00007d248dbd8fd8  vmovaps xmm6, [rsp+0x50]
00007d248dbd8fde  vmovaps xmm7, [rsp+0x60]
00007d248dbd8fe4  vmovaps xmm8, [rsp+0x70]
00007d248dbd8fea  vmovaps xmm9, [rsp+0x80]
00007d248dbd8ff3  vmovaps xmm10, [rsp+0x90]
00007d248dbd8ffc  vmovaps xmm11, [rsp+0xA0]
00007d248dbd9005  vmovaps xmm12, [rsp+0xB0]
00007d248dbd900e  vmovaps xmm13, [rsp+0xC0]
00007d248dbd9017  vmovaps xmm14, [rsp+0xD0]
00007d248dbd9020  vmovaps xmm15, [rsp+0xE0]
00007d248dbd9029  add rsp, 0xF0
00007d248dbd9030  pop r11
00007d248dbd9032  pop r10
00007d248dbd9034  pop r9
00007d248dbd9036  pop r8
00007d248dbd9038  pop rsi
00007d248dbd9039  pop rdi
00007d248dbd903a  pop rdx
00007d248dbd903b  pop rcx
00007d248dbd903c  pop rax
00007d248dbd903d  add rsp, 0x08
00007d248dbd9041  jmp 0x00007D248DBD61C2
00007d248dbd9046  sub rsp, 0x08
00007d248dbd904a  push rax
00007d248dbd904b  push rcx
00007d248dbd904c  push rdx
00007d248dbd904d  push rdi
00007d248dbd904e  push rsi
00007d248dbd904f  push r8
00007d248dbd9051  push r9
00007d248dbd9053  push r10
00007d248dbd9055  push r11
00007d248dbd9057  sub rsp, 0xF0
00007d248dbd905e  vmovaps [rsp], xmm0
00007d248dbd9063  vmovaps [rsp+0x10], xmm1
00007d248dbd9069  vmovaps [rsp+0x20], xmm2
00007d248dbd906f  vmovaps [rsp+0x30], xmm3
00007d248dbd9075  vmovaps [rsp+0x40], xmm4
00007d248dbd907b  vmovaps [rsp+0x50], xmm5
00007d248dbd9081  vmovaps [rsp+0x60], xmm6
00007d248dbd9087  vmovaps [rsp+0x70], xmm7
00007d248dbd908d  vmovaps [rsp+0x80], xmm8
00007d248dbd9096  vmovaps [rsp+0x90], xmm9
00007d248dbd909f  vmovaps [rsp+0xA0], xmm10
00007d248dbd90a8  vmovaps [rsp+0xB0], xmm11
00007d248dbd90b1  vmovaps [rsp+0xC0], xmm12
00007d248dbd90ba  vmovaps [rsp+0xD0], xmm13
00007d248dbd90c3  vmovaps [rsp+0xE0], xmm14
00007d248dbd90cc  sub rsp, 0x30
00007d248dbd90d0  movaps [rsp], xmm15
00007d248dbd90d5  movaps [rsp+0x10], xmm5
00007d248dbd90da  movaps [rsp+0x20], xmm3
00007d248dbd90df  lea rdi, [rsp]
00007d248dbd90e3  mov esi, 0x00
00007d248dbd90e8  mov rax, 0x5BCEEF236530
00007d248dbd90f2  call rax
00007d248dbd90f4  movaps xmm15, [rsp]
00007d248dbd90f9  add rsp, 0x30
00007d248dbd90fd  vmovaps xmm0, [rsp]
00007d248dbd9102  vmovaps xmm1, [rsp+0x10]
00007d248dbd9108  vmovaps xmm2, [rsp+0x20]
00007d248dbd910e  vmovaps xmm3, [rsp+0x30]
00007d248dbd9114  vmovaps xmm4, [rsp+0x40]
00007d248dbd911a  vmovaps xmm5, [rsp+0x50]
00007d248dbd9120  vmovaps xmm6, [rsp+0x60]
00007d248dbd9126  vmovaps xmm7, [rsp+0x70]
00007d248dbd912c  vmovaps xmm8, [rsp+0x80]
00007d248dbd9135  vmovaps xmm9, [rsp+0x90]
00007d248dbd913e  vmovaps xmm10, [rsp+0xA0]
00007d248dbd9147  vmovaps xmm11, [rsp+0xB0]
00007d248dbd9150  vmovaps xmm12, [rsp+0xC0]
00007d248dbd9159  vmovaps xmm13, [rsp+0xD0]
00007d248dbd9162  vmovaps xmm14, [rsp+0xE0]
00007d248dbd916b  add rsp, 0xF0
00007d248dbd9172  pop r11
00007d248dbd9174  pop r10
00007d248dbd9176  pop r9
00007d248dbd9178  pop r8
00007d248dbd917a  pop rsi
00007d248dbd917b  pop rdi
00007d248dbd917c  pop rdx
00007d248dbd917d  pop rcx
00007d248dbd917e  pop rax
00007d248dbd917f  add rsp, 0x08
00007d248dbd9183  jmp 0x00007D248DBD61DC
00007d248dbd9188  sub rsp, 0x08
00007d248dbd918c  push rax
00007d248dbd918d  push rcx
00007d248dbd918e  push rdx
00007d248dbd918f  push rdi
00007d248dbd9190  push rsi
00007d248dbd9191  push r8
00007d248dbd9193  push r9
00007d248dbd9195  push r10
00007d248dbd9197  push r11
00007d248dbd9199  sub rsp, 0xF0
00007d248dbd91a0  vmovaps [rsp], xmm0
00007d248dbd91a5  vmovaps [rsp+0x10], xmm1
00007d248dbd91ab  vmovaps [rsp+0x20], xmm2
00007d248dbd91b1  vmovaps [rsp+0x30], xmm3
00007d248dbd91b7  vmovaps [rsp+0x40], xmm4
00007d248dbd91bd  vmovaps [rsp+0x50], xmm6
00007d248dbd91c3  vmovaps [rsp+0x60], xmm7
00007d248dbd91c9  vmovaps [rsp+0x70], xmm8
00007d248dbd91cf  vmovaps [rsp+0x80], xmm9
00007d248dbd91d8  vmovaps [rsp+0x90], xmm10
00007d248dbd91e1  vmovaps [rsp+0xA0], xmm11
00007d248dbd91ea  vmovaps [rsp+0xB0], xmm12
00007d248dbd91f3  vmovaps [rsp+0xC0], xmm13
00007d248dbd91fc  vmovaps [rsp+0xD0], xmm14
00007d248dbd9205  vmovaps [rsp+0xE0], xmm15
00007d248dbd920e  sub rsp, 0x30
00007d248dbd9212  movaps [rsp], xmm5
00007d248dbd9216  movaps [rsp+0x10], xmm8
00007d248dbd921c  movaps [rsp+0x20], xmm6
00007d248dbd9221  lea rdi, [rsp]
00007d248dbd9225  mov esi, 0x00
00007d248dbd922a  mov rax, 0x5BCEEF236530
00007d248dbd9234  call rax
00007d248dbd9236  movaps xmm5, [rsp]
00007d248dbd923a  add rsp, 0x30
00007d248dbd923e  vmovaps xmm0, [rsp]
00007d248dbd9243  vmovaps xmm1, [rsp+0x10]
00007d248dbd9249  vmovaps xmm2, [rsp+0x20]
00007d248dbd924f  vmovaps xmm3, [rsp+0x30]
00007d248dbd9255  vmovaps xmm4, [rsp+0x40]
00007d248dbd925b  vmovaps xmm6, [rsp+0x50]
00007d248dbd9261  vmovaps xmm7, [rsp+0x60]
00007d248dbd9267  vmovaps xmm8, [rsp+0x70]
00007d248dbd926d  vmovaps xmm9, [rsp+0x80]
00007d248dbd9276  vmovaps xmm10, [rsp+0x90]
00007d248dbd927f  vmovaps xmm11, [rsp+0xA0]
00007d248dbd9288  vmovaps xmm12, [rsp+0xB0]
00007d248dbd9291  vmovaps xmm13, [rsp+0xC0]
00007d248dbd929a  vmovaps xmm14, [rsp+0xD0]
00007d248dbd92a3  vmovaps xmm15, [rsp+0xE0]
00007d248dbd92ac  add rsp, 0xF0
00007d248dbd92b3  pop r11
00007d248dbd92b5  pop r10
00007d248dbd92b7  pop r9
00007d248dbd92b9  pop r8
00007d248dbd92bb  pop rsi
00007d248dbd92bc  pop rdi
00007d248dbd92bd  pop rdx
00007d248dbd92be  pop rcx
00007d248dbd92bf  pop rax
00007d248dbd92c0  add rsp, 0x08
00007d248dbd92c4  jmp 0x00007D248DBD6200
00007d248dbd92c9  sub rsp, 0x08
00007d248dbd92cd  push rax
00007d248dbd92ce  push rcx
00007d248dbd92cf  push rdx
00007d248dbd92d0  push rdi
00007d248dbd92d1  push rsi
00007d248dbd92d2  push r8
00007d248dbd92d4  push r9
00007d248dbd92d6  push r10
00007d248dbd92d8  push r11
00007d248dbd92da  sub rsp, 0xF0
00007d248dbd92e1  vmovaps [rsp], xmm0
00007d248dbd92e6  vmovaps [rsp+0x10], xmm1
00007d248dbd92ec  vmovaps [rsp+0x20], xmm2
00007d248dbd92f2  vmovaps [rsp+0x30], xmm3
00007d248dbd92f8  vmovaps [rsp+0x40], xmm4
00007d248dbd92fe  vmovaps [rsp+0x50], xmm5
00007d248dbd9304  vmovaps [rsp+0x60], xmm7
00007d248dbd930a  vmovaps [rsp+0x70], xmm8
00007d248dbd9310  vmovaps [rsp+0x80], xmm9
00007d248dbd9319  vmovaps [rsp+0x90], xmm10
00007d248dbd9322  vmovaps [rsp+0xA0], xmm11
00007d248dbd932b  vmovaps [rsp+0xB0], xmm12
00007d248dbd9334  vmovaps [rsp+0xC0], xmm13
00007d248dbd933d  vmovaps [rsp+0xD0], xmm14
00007d248dbd9346  vmovaps [rsp+0xE0], xmm15
00007d248dbd934f  sub rsp, 0x30
00007d248dbd9353  movaps [rsp], xmm6
00007d248dbd9357  movaps [rsp+0x10], xmm10
00007d248dbd935d  movaps [rsp+0x20], xmm8
00007d248dbd9363  lea rdi, [rsp]
00007d248dbd9367  mov esi, 0x00
00007d248dbd936c  mov rax, 0x5BCEEF236530
00007d248dbd9376  call rax
00007d248dbd9378  movaps xmm6, [rsp]
00007d248dbd937c  add rsp, 0x30
00007d248dbd9380  vmovaps xmm0, [rsp]
00007d248dbd9385  vmovaps xmm1, [rsp+0x10]
00007d248dbd938b  vmovaps xmm2, [rsp+0x20]
00007d248dbd9391  vmovaps xmm3, [rsp+0x30]
00007d248dbd9397  vmovaps xmm4, [rsp+0x40]
00007d248dbd939d  vmovaps xmm5, [rsp+0x50]
00007d248dbd93a3  vmovaps xmm7, [rsp+0x60]
00007d248dbd93a9  vmovaps xmm8, [rsp+0x70]
00007d248dbd93af  vmovaps xmm9, [rsp+0x80]
00007d248dbd93b8  vmovaps xmm10, [rsp+0x90]
00007d248dbd93c1  vmovaps xmm11, [rsp+0xA0]
00007d248dbd93ca  vmovaps xmm12, [rsp+0xB0]
00007d248dbd93d3  vmovaps xmm13, [rsp+0xC0]
00007d248dbd93dc  vmovaps xmm14, [rsp+0xD0]
00007d248dbd93e5  vmovaps xmm15, [rsp+0xE0]
00007d248dbd93ee  add rsp, 0xF0
00007d248dbd93f5  pop r11
00007d248dbd93f7  pop r10
00007d248dbd93f9  pop r9
00007d248dbd93fb  pop r8
00007d248dbd93fd  pop rsi
00007d248dbd93fe  pop rdi
00007d248dbd93ff  pop rdx
00007d248dbd9400  pop rcx
00007d248dbd9401  pop rax
00007d248dbd9402  add rsp, 0x08
00007d248dbd9406  jmp 0x00007D248DBD6225
00007d248dbd940b  sub rsp, 0x08
00007d248dbd940f  push rax
00007d248dbd9410  push rcx
00007d248dbd9411  push rdx
00007d248dbd9412  push rdi
00007d248dbd9413  push rsi
00007d248dbd9414  push r8
00007d248dbd9416  push r9
00007d248dbd9418  push r10
00007d248dbd941a  push r11
00007d248dbd941c  sub rsp, 0xF0
00007d248dbd9423  vmovaps [rsp], xmm0
00007d248dbd9428  vmovaps [rsp+0x10], xmm1
00007d248dbd942e  vmovaps [rsp+0x20], xmm2
00007d248dbd9434  vmovaps [rsp+0x30], xmm3
00007d248dbd943a  vmovaps [rsp+0x40], xmm4
00007d248dbd9440  vmovaps [rsp+0x50], xmm5
00007d248dbd9446  vmovaps [rsp+0x60], xmm6
00007d248dbd944c  vmovaps [rsp+0x70], xmm7
00007d248dbd9452  vmovaps [rsp+0x80], xmm8
00007d248dbd945b  vmovaps [rsp+0x90], xmm9
00007d248dbd9464  vmovaps [rsp+0xA0], xmm11
00007d248dbd946d  vmovaps [rsp+0xB0], xmm12
00007d248dbd9476  vmovaps [rsp+0xC0], xmm13
00007d248dbd947f  vmovaps [rsp+0xD0], xmm14
00007d248dbd9488  vmovaps [rsp+0xE0], xmm15
00007d248dbd9491  sub rsp, 0x30
00007d248dbd9495  movaps [rsp], xmm10
00007d248dbd949a  movaps [rsp+0x10], xmm8
00007d248dbd94a0  movaps [rsp+0x20], xmm14
00007d248dbd94a6  lea rdi, [rsp]
00007d248dbd94aa  mov esi, 0x00
00007d248dbd94af  mov rax, 0x5BCEEF236530
00007d248dbd94b9  call rax
00007d248dbd94bb  movaps xmm10, [rsp]
00007d248dbd94c0  add rsp, 0x30
00007d248dbd94c4  vmovaps xmm0, [rsp]
00007d248dbd94c9  vmovaps xmm1, [rsp+0x10]
00007d248dbd94cf  vmovaps xmm2, [rsp+0x20]
00007d248dbd94d5  vmovaps xmm3, [rsp+0x30]
00007d248dbd94db  vmovaps xmm4, [rsp+0x40]
00007d248dbd94e1  vmovaps xmm5, [rsp+0x50]
00007d248dbd94e7  vmovaps xmm6, [rsp+0x60]
00007d248dbd94ed  vmovaps xmm7, [rsp+0x70]
00007d248dbd94f3  vmovaps xmm8, [rsp+0x80]
00007d248dbd94fc  vmovaps xmm9, [rsp+0x90]
00007d248dbd9505  vmovaps xmm11, [rsp+0xA0]
00007d248dbd950e  vmovaps xmm12, [rsp+0xB0]
00007d248dbd9517  vmovaps xmm13, [rsp+0xC0]
00007d248dbd9520  vmovaps xmm14, [rsp+0xD0]
00007d248dbd9529  vmovaps xmm15, [rsp+0xE0]
00007d248dbd9532  add rsp, 0xF0
00007d248dbd9539  pop r11
00007d248dbd953b  pop r10
00007d248dbd953d  pop r9
00007d248dbd953f  pop r8
00007d248dbd9541  pop rsi
00007d248dbd9542  pop rdi
00007d248dbd9543  pop rdx
00007d248dbd9544  pop rcx
00007d248dbd9545  pop rax
00007d248dbd9546  add rsp, 0x08
00007d248dbd954a  jmp 0x00007D248DBD6245
00007d248dbd954f  sub rsp, 0x08
00007d248dbd9553  push rax
00007d248dbd9554  push rcx
00007d248dbd9555  push rdx
00007d248dbd9556  push rdi
00007d248dbd9557  push rsi
00007d248dbd9558  push r8
00007d248dbd955a  push r9
00007d248dbd955c  push r10
00007d248dbd955e  push r11
00007d248dbd9560  sub rsp, 0xF0
00007d248dbd9567  vmovaps [rsp], xmm0
00007d248dbd956c  vmovaps [rsp+0x10], xmm1
00007d248dbd9572  vmovaps [rsp+0x20], xmm2
00007d248dbd9578  vmovaps [rsp+0x30], xmm3
00007d248dbd957e  vmovaps [rsp+0x40], xmm4
00007d248dbd9584  vmovaps [rsp+0x50], xmm5
00007d248dbd958a  vmovaps [rsp+0x60], xmm6
00007d248dbd9590  vmovaps [rsp+0x70], xmm7
00007d248dbd9596  vmovaps [rsp+0x80], xmm8
00007d248dbd959f  vmovaps [rsp+0x90], xmm9
00007d248dbd95a8  vmovaps [rsp+0xA0], xmm10
00007d248dbd95b1  vmovaps [rsp+0xB0], xmm11
00007d248dbd95ba  vmovaps [rsp+0xC0], xmm12
00007d248dbd95c3  vmovaps [rsp+0xD0], xmm13
00007d248dbd95cc  vmovaps [rsp+0xE0], xmm15
00007d248dbd95d5  sub rsp, 0x30
00007d248dbd95d9  movaps [rsp], xmm14
00007d248dbd95de  movaps [rsp+0x10], xmm8
00007d248dbd95e4  movaps [rsp+0x20], xmm4
00007d248dbd95e9  lea rdi, [rsp]
00007d248dbd95ed  mov esi, 0x00
00007d248dbd95f2  mov rax, 0x5BCEEF236530
00007d248dbd95fc  call rax
00007d248dbd95fe  movaps xmm14, [rsp]
00007d248dbd9603  add rsp, 0x30
00007d248dbd9607  vmovaps xmm0, [rsp]
00007d248dbd960c  vmovaps xmm1, [rsp+0x10]
00007d248dbd9612  vmovaps xmm2, [rsp+0x20]
00007d248dbd9618  vmovaps xmm3, [rsp+0x30]
00007d248dbd961e  vmovaps xmm4, [rsp+0x40]
00007d248dbd9624  vmovaps xmm5, [rsp+0x50]
00007d248dbd962a  vmovaps xmm6, [rsp+0x60]
00007d248dbd9630  vmovaps xmm7, [rsp+0x70]
00007d248dbd9636  vmovaps xmm8, [rsp+0x80]
00007d248dbd963f  vmovaps xmm9, [rsp+0x90]
00007d248dbd9648  vmovaps xmm10, [rsp+0xA0]
00007d248dbd9651  vmovaps xmm11, [rsp+0xB0]
00007d248dbd965a  vmovaps xmm12, [rsp+0xC0]
00007d248dbd9663  vmovaps xmm13, [rsp+0xD0]
00007d248dbd966c  vmovaps xmm15, [rsp+0xE0]
00007d248dbd9675  add rsp, 0xF0
00007d248dbd967c  pop r11
00007d248dbd967e  pop r10
00007d248dbd9680  pop r9
00007d248dbd9682  pop r8
00007d248dbd9684  pop rsi
00007d248dbd9685  pop rdi
00007d248dbd9686  pop rdx
00007d248dbd9687  pop rcx
00007d248dbd9688  pop rax
00007d248dbd9689  add rsp, 0x08
00007d248dbd968d  jmp 0x00007D248DBD6265
00007d248dbd9692  sub rsp, 0x08
00007d248dbd9696  push rax
00007d248dbd9697  push rcx
00007d248dbd9698  push rdx
00007d248dbd9699  push rdi
00007d248dbd969a  push rsi
00007d248dbd969b  push r8
00007d248dbd969d  push r9
00007d248dbd969f  push r10
00007d248dbd96a1  push r11
00007d248dbd96a3  sub rsp, 0xF0
00007d248dbd96aa  vmovaps [rsp], xmm0
00007d248dbd96af  vmovaps [rsp+0x10], xmm1
00007d248dbd96b5  vmovaps [rsp+0x20], xmm2
00007d248dbd96bb  vmovaps [rsp+0x30], xmm3
00007d248dbd96c1  vmovaps [rsp+0x40], xmm5
00007d248dbd96c7  vmovaps [rsp+0x50], xmm6
00007d248dbd96cd  vmovaps [rsp+0x60], xmm7
00007d248dbd96d3  vmovaps [rsp+0x70], xmm8
00007d248dbd96d9  vmovaps [rsp+0x80], xmm9
00007d248dbd96e2  vmovaps [rsp+0x90], xmm10
00007d248dbd96eb  vmovaps [rsp+0xA0], xmm11
00007d248dbd96f4  vmovaps [rsp+0xB0], xmm12
00007d248dbd96fd  vmovaps [rsp+0xC0], xmm13
00007d248dbd9706  vmovaps [rsp+0xD0], xmm14
00007d248dbd970f  vmovaps [rsp+0xE0], xmm15
00007d248dbd9718  sub rsp, 0x30
00007d248dbd971c  movaps [rsp], xmm4
00007d248dbd9720  movaps [rsp+0x10], xmm13
00007d248dbd9726  movaps [rsp+0x20], xmm8
00007d248dbd972c  lea rdi, [rsp]
00007d248dbd9730  mov esi, 0x00
00007d248dbd9735  mov rax, 0x5BCEEF236530
00007d248dbd973f  call rax
00007d248dbd9741  movaps xmm4, [rsp]
00007d248dbd9745  add rsp, 0x30
00007d248dbd9749  vmovaps xmm0, [rsp]
00007d248dbd974e  vmovaps xmm1, [rsp+0x10]
00007d248dbd9754  vmovaps xmm2, [rsp+0x20]
00007d248dbd975a  vmovaps xmm3, [rsp+0x30]
00007d248dbd9760  vmovaps xmm5, [rsp+0x40]
00007d248dbd9766  vmovaps xmm6, [rsp+0x50]
00007d248dbd976c  vmovaps xmm7, [rsp+0x60]
00007d248dbd9772  vmovaps xmm8, [rsp+0x70]
00007d248dbd9778  vmovaps xmm9, [rsp+0x80]
00007d248dbd9781  vmovaps xmm10, [rsp+0x90]
00007d248dbd978a  vmovaps xmm11, [rsp+0xA0]
00007d248dbd9793  vmovaps xmm12, [rsp+0xB0]
00007d248dbd979c  vmovaps xmm13, [rsp+0xC0]
00007d248dbd97a5  vmovaps xmm14, [rsp+0xD0]
00007d248dbd97ae  vmovaps xmm15, [rsp+0xE0]
00007d248dbd97b7  add rsp, 0xF0
00007d248dbd97be  pop r11
00007d248dbd97c0  pop r10
00007d248dbd97c2  pop r9
00007d248dbd97c4  pop r8
00007d248dbd97c6  pop rsi
00007d248dbd97c7  pop rdi
00007d248dbd97c8  pop rdx
00007d248dbd97c9  pop rcx
00007d248dbd97ca  pop rax
00007d248dbd97cb  add rsp, 0x08
00007d248dbd97cf  jmp 0x00007D248DBD628A
00007d248dbd97d4  sub rsp, 0x08
00007d248dbd97d8  push rax
00007d248dbd97d9  push rcx
00007d248dbd97da  push rdx
00007d248dbd97db  push rdi
00007d248dbd97dc  push rsi
00007d248dbd97dd  push r8
00007d248dbd97df  push r9
00007d248dbd97e1  push r10
00007d248dbd97e3  push r11
00007d248dbd97e5  sub rsp, 0xF0
00007d248dbd97ec  vmovaps [rsp], xmm0
00007d248dbd97f1  vmovaps [rsp+0x10], xmm1
00007d248dbd97f7  vmovaps [rsp+0x20], xmm2
00007d248dbd97fd  vmovaps [rsp+0x30], xmm3
00007d248dbd9803  vmovaps [rsp+0x40], xmm4
00007d248dbd9809  vmovaps [rsp+0x50], xmm5
00007d248dbd980f  vmovaps [rsp+0x60], xmm6
00007d248dbd9815  vmovaps [rsp+0x70], xmm7
00007d248dbd981b  vmovaps [rsp+0x80], xmm8
00007d248dbd9824  vmovaps [rsp+0x90], xmm9
00007d248dbd982d  vmovaps [rsp+0xA0], xmm10
00007d248dbd9836  vmovaps [rsp+0xB0], xmm11
00007d248dbd983f  vmovaps [rsp+0xC0], xmm12
00007d248dbd9848  vmovaps [rsp+0xD0], xmm14
00007d248dbd9851  vmovaps [rsp+0xE0], xmm15
00007d248dbd985a  sub rsp, 0x30
00007d248dbd985e  movaps [rsp], xmm13
00007d248dbd9863  movaps [rsp+0x10], xmm15
00007d248dbd9869  movaps [rsp+0x20], xmm9
00007d248dbd986f  lea rdi, [rsp]
00007d248dbd9873  mov esi, 0x00
00007d248dbd9878  mov rax, 0x5BCEEF236530
00007d248dbd9882  call rax
00007d248dbd9884  movaps xmm13, [rsp]
00007d248dbd9889  add rsp, 0x30
00007d248dbd988d  vmovaps xmm0, [rsp]
00007d248dbd9892  vmovaps xmm1, [rsp+0x10]
00007d248dbd9898  vmovaps xmm2, [rsp+0x20]
00007d248dbd989e  vmovaps xmm3, [rsp+0x30]
00007d248dbd98a4  vmovaps xmm4, [rsp+0x40]
00007d248dbd98aa  vmovaps xmm5, [rsp+0x50]
00007d248dbd98b0  vmovaps xmm6, [rsp+0x60]
00007d248dbd98b6  vmovaps xmm7, [rsp+0x70]
00007d248dbd98bc  vmovaps xmm8, [rsp+0x80]
00007d248dbd98c5  vmovaps xmm9, [rsp+0x90]
00007d248dbd98ce  vmovaps xmm10, [rsp+0xA0]
00007d248dbd98d7  vmovaps xmm11, [rsp+0xB0]
00007d248dbd98e0  vmovaps xmm12, [rsp+0xC0]
00007d248dbd98e9  vmovaps xmm14, [rsp+0xD0]
00007d248dbd98f2  vmovaps xmm15, [rsp+0xE0]
00007d248dbd98fb  add rsp, 0xF0
00007d248dbd9902  pop r11
00007d248dbd9904  pop r10
00007d248dbd9906  pop r9
00007d248dbd9908  pop r8
00007d248dbd990a  pop rsi
00007d248dbd990b  pop rdi
00007d248dbd990c  pop rdx
00007d248dbd990d  pop rcx
00007d248dbd990e  pop rax
00007d248dbd990f  add rsp, 0x08
00007d248dbd9913  jmp 0x00007D248DBD62A5
00007d248dbd9918  sub rsp, 0x08
00007d248dbd991c  push rax
00007d248dbd991d  push rcx
00007d248dbd991e  push rdx
00007d248dbd991f  push rdi
00007d248dbd9920  push rsi
00007d248dbd9921  push r8
00007d248dbd9923  push r9
00007d248dbd9925  push r10
00007d248dbd9927  push r11
00007d248dbd9929  sub rsp, 0xF0
00007d248dbd9930  vmovaps [rsp], xmm0
00007d248dbd9935  vmovaps [rsp+0x10], xmm1
00007d248dbd993b  vmovaps [rsp+0x20], xmm2
00007d248dbd9941  vmovaps [rsp+0x30], xmm3
00007d248dbd9947  vmovaps [rsp+0x40], xmm4
00007d248dbd994d  vmovaps [rsp+0x50], xmm5
00007d248dbd9953  vmovaps [rsp+0x60], xmm6
00007d248dbd9959  vmovaps [rsp+0x70], xmm7
00007d248dbd995f  vmovaps [rsp+0x80], xmm8
00007d248dbd9968  vmovaps [rsp+0x90], xmm9
00007d248dbd9971  vmovaps [rsp+0xA0], xmm10
00007d248dbd997a  vmovaps [rsp+0xB0], xmm11
00007d248dbd9983  vmovaps [rsp+0xC0], xmm12
00007d248dbd998c  vmovaps [rsp+0xD0], xmm13
00007d248dbd9995  vmovaps [rsp+0xE0], xmm14
00007d248dbd999e  sub rsp, 0x30
00007d248dbd99a2  movaps [rsp], xmm15
00007d248dbd99a7  movaps [rsp+0x10], xmm1
00007d248dbd99ac  movaps [rsp+0x20], xmm5
00007d248dbd99b1  lea rdi, [rsp]
00007d248dbd99b5  mov esi, 0x00
00007d248dbd99ba  mov rax, 0x5BCEEF236530
00007d248dbd99c4  call rax
00007d248dbd99c6  movaps xmm15, [rsp]
00007d248dbd99cb  add rsp, 0x30
00007d248dbd99cf  vmovaps xmm0, [rsp]
00007d248dbd99d4  vmovaps xmm1, [rsp+0x10]
00007d248dbd99da  vmovaps xmm2, [rsp+0x20]
00007d248dbd99e0  vmovaps xmm3, [rsp+0x30]
00007d248dbd99e6  vmovaps xmm4, [rsp+0x40]
00007d248dbd99ec  vmovaps xmm5, [rsp+0x50]
00007d248dbd99f2  vmovaps xmm6, [rsp+0x60]
00007d248dbd99f8  vmovaps xmm7, [rsp+0x70]
00007d248dbd99fe  vmovaps xmm8, [rsp+0x80]
00007d248dbd9a07  vmovaps xmm9, [rsp+0x90]
00007d248dbd9a10  vmovaps xmm10, [rsp+0xA0]
00007d248dbd9a19  vmovaps xmm11, [rsp+0xB0]
00007d248dbd9a22  vmovaps xmm12, [rsp+0xC0]
00007d248dbd9a2b  vmovaps xmm13, [rsp+0xD0]
00007d248dbd9a34  vmovaps xmm14, [rsp+0xE0]
00007d248dbd9a3d  add rsp, 0xF0
00007d248dbd9a44  pop r11
00007d248dbd9a46  pop r10
00007d248dbd9a48  pop r9
00007d248dbd9a4a  pop r8
00007d248dbd9a4c  pop rsi
00007d248dbd9a4d  pop rdi
00007d248dbd9a4e  pop rdx
00007d248dbd9a4f  pop rcx
00007d248dbd9a50  pop rax
00007d248dbd9a51  add rsp, 0x08
00007d248dbd9a55  jmp 0x00007D248DBD62C0
00007d248dbd9a5a  call 0x00007D248DAD64F0
00007d248dbd9a5f  jmp 0x00007D248DBD631B
00007d248dbd9a64  sub rsp, 0x08
00007d248dbd9a68  push rax
00007d248dbd9a69  push rcx
00007d248dbd9a6a  push rdx
00007d248dbd9a6b  push rdi
00007d248dbd9a6c  push rsi
00007d248dbd9a6d  push r8
00007d248dbd9a6f  push r9
00007d248dbd9a71  push r10
00007d248dbd9a73  push r11
00007d248dbd9a75  sub rsp, 0xF0
00007d248dbd9a7c  vmovaps [rsp], xmm0
00007d248dbd9a81  vmovaps [rsp+0x10], xmm1
00007d248dbd9a87  vmovaps [rsp+0x20], xmm2
00007d248dbd9a8d  vmovaps [rsp+0x30], xmm3
00007d248dbd9a93  vmovaps [rsp+0x40], xmm4
00007d248dbd9a99  vmovaps [rsp+0x50], xmm5
00007d248dbd9a9f  vmovaps [rsp+0x60], xmm6
00007d248dbd9aa5  vmovaps [rsp+0x70], xmm7
00007d248dbd9aab  vmovaps [rsp+0x80], xmm8
00007d248dbd9ab4  vmovaps [rsp+0x90], xmm10
00007d248dbd9abd  vmovaps [rsp+0xA0], xmm11
00007d248dbd9ac6  vmovaps [rsp+0xB0], xmm12
00007d248dbd9acf  vmovaps [rsp+0xC0], xmm13
00007d248dbd9ad8  vmovaps [rsp+0xD0], xmm14
00007d248dbd9ae1  vmovaps [rsp+0xE0], xmm15
00007d248dbd9aea  sub rsp, 0x30
00007d248dbd9aee  movaps [rsp], xmm9
00007d248dbd9af3  movaps [rsp+0x10], xmm8
00007d248dbd9af9  movaps [rsp+0x20], xmm11
00007d248dbd9aff  lea rdi, [rsp]
00007d248dbd9b03  mov esi, 0x00
00007d248dbd9b08  mov rax, 0x5BCEEF236530
00007d248dbd9b12  call rax
00007d248dbd9b14  movaps xmm9, [rsp]
00007d248dbd9b19  add rsp, 0x30
00007d248dbd9b1d  vmovaps xmm0, [rsp]
00007d248dbd9b22  vmovaps xmm1, [rsp+0x10]
00007d248dbd9b28  vmovaps xmm2, [rsp+0x20]
00007d248dbd9b2e  vmovaps xmm3, [rsp+0x30]
00007d248dbd9b34  vmovaps xmm4, [rsp+0x40]
00007d248dbd9b3a  vmovaps xmm5, [rsp+0x50]
00007d248dbd9b40  vmovaps xmm6, [rsp+0x60]
00007d248dbd9b46  vmovaps xmm7, [rsp+0x70]
00007d248dbd9b4c  vmovaps xmm8, [rsp+0x80]
00007d248dbd9b55  vmovaps xmm10, [rsp+0x90]
00007d248dbd9b5e  vmovaps xmm11, [rsp+0xA0]
00007d248dbd9b67  vmovaps xmm12, [rsp+0xB0]
00007d248dbd9b70  vmovaps xmm13, [rsp+0xC0]
00007d248dbd9b79  vmovaps xmm14, [rsp+0xD0]
00007d248dbd9b82  vmovaps xmm15, [rsp+0xE0]
00007d248dbd9b8b  add rsp, 0xF0
00007d248dbd9b92  pop r11
00007d248dbd9b94  pop r10
00007d248dbd9b96  pop r9
00007d248dbd9b98  pop r8
00007d248dbd9b9a  pop rsi
00007d248dbd9b9b  pop rdi
00007d248dbd9b9c  pop rdx
00007d248dbd9b9d  pop rcx
00007d248dbd9b9e  pop rax
00007d248dbd9b9f  add rsp, 0x08
00007d248dbd9ba3  jmp 0x00007D248DBD6352
00007d248dbd9ba8  sub rsp, 0x08
00007d248dbd9bac  push rax
00007d248dbd9bad  push rcx
00007d248dbd9bae  push rdx
00007d248dbd9baf  push rdi
00007d248dbd9bb0  push rsi
00007d248dbd9bb1  push r8
00007d248dbd9bb3  push r9
00007d248dbd9bb5  push r10
00007d248dbd9bb7  push r11
00007d248dbd9bb9  sub rsp, 0xF0
00007d248dbd9bc0  vmovaps [rsp], xmm0
00007d248dbd9bc5  vmovaps [rsp+0x10], xmm1
00007d248dbd9bcb  vmovaps [rsp+0x20], xmm2
00007d248dbd9bd1  vmovaps [rsp+0x30], xmm3
00007d248dbd9bd7  vmovaps [rsp+0x40], xmm4
00007d248dbd9bdd  vmovaps [rsp+0x50], xmm5
00007d248dbd9be3  vmovaps [rsp+0x60], xmm6
00007d248dbd9be9  vmovaps [rsp+0x70], xmm7
00007d248dbd9bef  vmovaps [rsp+0x80], xmm8
00007d248dbd9bf8  vmovaps [rsp+0x90], xmm9
00007d248dbd9c01  vmovaps [rsp+0xA0], xmm10
00007d248dbd9c0a  vmovaps [rsp+0xB0], xmm12
00007d248dbd9c13  vmovaps [rsp+0xC0], xmm13
00007d248dbd9c1c  vmovaps [rsp+0xD0], xmm14
00007d248dbd9c25  vmovaps [rsp+0xE0], xmm15
00007d248dbd9c2e  sub rsp, 0x30
00007d248dbd9c32  movaps [rsp], xmm11
00007d248dbd9c37  movaps [rsp+0x10], xmm10
00007d248dbd9c3d  movaps [rsp+0x20], xmm6
00007d248dbd9c42  lea rdi, [rsp]
00007d248dbd9c46  mov esi, 0x00
00007d248dbd9c4b  mov rax, 0x5BCEEF236530
00007d248dbd9c55  call rax
00007d248dbd9c57  movaps xmm11, [rsp]
00007d248dbd9c5c  add rsp, 0x30
00007d248dbd9c60  vmovaps xmm0, [rsp]
00007d248dbd9c65  vmovaps xmm1, [rsp+0x10]
00007d248dbd9c6b  vmovaps xmm2, [rsp+0x20]
00007d248dbd9c71  vmovaps xmm3, [rsp+0x30]
00007d248dbd9c77  vmovaps xmm4, [rsp+0x40]
00007d248dbd9c7d  vmovaps xmm5, [rsp+0x50]
00007d248dbd9c83  vmovaps xmm6, [rsp+0x60]
00007d248dbd9c89  vmovaps xmm7, [rsp+0x70]
00007d248dbd9c8f  vmovaps xmm8, [rsp+0x80]
00007d248dbd9c98  vmovaps xmm9, [rsp+0x90]
00007d248dbd9ca1  vmovaps xmm10, [rsp+0xA0]
00007d248dbd9caa  vmovaps xmm12, [rsp+0xB0]
00007d248dbd9cb3  vmovaps xmm13, [rsp+0xC0]
00007d248dbd9cbc  vmovaps xmm14, [rsp+0xD0]
00007d248dbd9cc5  vmovaps xmm15, [rsp+0xE0]
00007d248dbd9cce  add rsp, 0xF0
00007d248dbd9cd5  pop r11
00007d248dbd9cd7  pop r10
00007d248dbd9cd9  pop r9
00007d248dbd9cdb  pop r8
00007d248dbd9cdd  pop rsi
00007d248dbd9cde  pop rdi
00007d248dbd9cdf  pop rdx
00007d248dbd9ce0  pop rcx
00007d248dbd9ce1  pop rax
00007d248dbd9ce2  add rsp, 0x08
00007d248dbd9ce6  jmp 0x00007D248DBD636D
00007d248dbd9ceb  sub rsp, 0x08
00007d248dbd9cef  push rax
00007d248dbd9cf0  push rcx
00007d248dbd9cf1  push rdx
00007d248dbd9cf2  push rdi
00007d248dbd9cf3  push rsi
00007d248dbd9cf4  push r8
00007d248dbd9cf6  push r9
00007d248dbd9cf8  push r10
00007d248dbd9cfa  push r11
00007d248dbd9cfc  sub rsp, 0xF0
00007d248dbd9d03  vmovaps [rsp], xmm0
00007d248dbd9d08  vmovaps [rsp+0x10], xmm1
00007d248dbd9d0e  vmovaps [rsp+0x20], xmm2
00007d248dbd9d14  vmovaps [rsp+0x30], xmm3
00007d248dbd9d1a  vmovaps [rsp+0x40], xmm4
00007d248dbd9d20  vmovaps [rsp+0x50], xmm5
00007d248dbd9d26  vmovaps [rsp+0x60], xmm6
00007d248dbd9d2c  vmovaps [rsp+0x70], xmm7
00007d248dbd9d32  vmovaps [rsp+0x80], xmm8
00007d248dbd9d3b  vmovaps [rsp+0x90], xmm9
00007d248dbd9d44  vmovaps [rsp+0xA0], xmm11
00007d248dbd9d4d  vmovaps [rsp+0xB0], xmm12
00007d248dbd9d56  vmovaps [rsp+0xC0], xmm13
00007d248dbd9d5f  vmovaps [rsp+0xD0], xmm14
00007d248dbd9d68  vmovaps [rsp+0xE0], xmm15
00007d248dbd9d71  sub rsp, 0x30
00007d248dbd9d75  movaps [rsp], xmm10
00007d248dbd9d7a  movaps [rsp+0x10], xmm14
00007d248dbd9d80  movaps [rsp+0x20], xmm4
00007d248dbd9d85  lea rdi, [rsp]
00007d248dbd9d89  mov esi, 0x00
00007d248dbd9d8e  mov rax, 0x5BCEEF236530
00007d248dbd9d98  call rax
00007d248dbd9d9a  movaps xmm10, [rsp]
00007d248dbd9d9f  add rsp, 0x30
00007d248dbd9da3  vmovaps xmm0, [rsp]
00007d248dbd9da8  vmovaps xmm1, [rsp+0x10]
00007d248dbd9dae  vmovaps xmm2, [rsp+0x20]
00007d248dbd9db4  vmovaps xmm3, [rsp+0x30]
00007d248dbd9dba  vmovaps xmm4, [rsp+0x40]
00007d248dbd9dc0  vmovaps xmm5, [rsp+0x50]
00007d248dbd9dc6  vmovaps xmm6, [rsp+0x60]
00007d248dbd9dcc  vmovaps xmm7, [rsp+0x70]
00007d248dbd9dd2  vmovaps xmm8, [rsp+0x80]
00007d248dbd9ddb  vmovaps xmm9, [rsp+0x90]
00007d248dbd9de4  vmovaps xmm11, [rsp+0xA0]
00007d248dbd9ded  vmovaps xmm12, [rsp+0xB0]
00007d248dbd9df6  vmovaps xmm13, [rsp+0xC0]
00007d248dbd9dff  vmovaps xmm14, [rsp+0xD0]
00007d248dbd9e08  vmovaps xmm15, [rsp+0xE0]
00007d248dbd9e11  add rsp, 0xF0
00007d248dbd9e18  pop r11
00007d248dbd9e1a  pop r10
00007d248dbd9e1c  pop r9
00007d248dbd9e1e  pop r8
00007d248dbd9e20  pop rsi
00007d248dbd9e21  pop rdi
00007d248dbd9e22  pop rdx
00007d248dbd9e23  pop rcx
00007d248dbd9e24  pop rax
00007d248dbd9e25  add rsp, 0x08
00007d248dbd9e29  jmp 0x00007D248DBD6388
00007d248dbd9e2e  sub rsp, 0x08
00007d248dbd9e32  push rax
00007d248dbd9e33  push rcx
00007d248dbd9e34  push rdx
00007d248dbd9e35  push rdi
00007d248dbd9e36  push rsi
00007d248dbd9e37  push r8
00007d248dbd9e39  push r9
00007d248dbd9e3b  push r10
00007d248dbd9e3d  push r11
00007d248dbd9e3f  sub rsp, 0xF0
00007d248dbd9e46  vmovaps [rsp], xmm0
00007d248dbd9e4b  vmovaps [rsp+0x10], xmm1
00007d248dbd9e51  vmovaps [rsp+0x20], xmm2
00007d248dbd9e57  vmovaps [rsp+0x30], xmm3
00007d248dbd9e5d  vmovaps [rsp+0x40], xmm4
00007d248dbd9e63  vmovaps [rsp+0x50], xmm5
00007d248dbd9e69  vmovaps [rsp+0x60], xmm6
00007d248dbd9e6f  vmovaps [rsp+0x70], xmm7
00007d248dbd9e75  vmovaps [rsp+0x80], xmm9
00007d248dbd9e7e  vmovaps [rsp+0x90], xmm10
00007d248dbd9e87  vmovaps [rsp+0xA0], xmm11
00007d248dbd9e90  vmovaps [rsp+0xB0], xmm12
00007d248dbd9e99  vmovaps [rsp+0xC0], xmm13
00007d248dbd9ea2  vmovaps [rsp+0xD0], xmm14
00007d248dbd9eab  vmovaps [rsp+0xE0], xmm15
00007d248dbd9eb4  sub rsp, 0x30
00007d248dbd9eb8  movaps [rsp], xmm8
00007d248dbd9ebd  movaps [rsp+0x10], xmm1
00007d248dbd9ec2  movaps [rsp+0x20], xmm14
00007d248dbd9ec8  lea rdi, [rsp]
00007d248dbd9ecc  mov esi, 0x00
00007d248dbd9ed1  mov rax, 0x5BCEEF236530
00007d248dbd9edb  call rax
00007d248dbd9edd  movaps xmm8, [rsp]
00007d248dbd9ee2  add rsp, 0x30
00007d248dbd9ee6  vmovaps xmm0, [rsp]
00007d248dbd9eeb  vmovaps xmm1, [rsp+0x10]
00007d248dbd9ef1  vmovaps xmm2, [rsp+0x20]
00007d248dbd9ef7  vmovaps xmm3, [rsp+0x30]
00007d248dbd9efd  vmovaps xmm4, [rsp+0x40]
00007d248dbd9f03  vmovaps xmm5, [rsp+0x50]
00007d248dbd9f09  vmovaps xmm6, [rsp+0x60]
00007d248dbd9f0f  vmovaps xmm7, [rsp+0x70]
00007d248dbd9f15  vmovaps xmm9, [rsp+0x80]
00007d248dbd9f1e  vmovaps xmm10, [rsp+0x90]
00007d248dbd9f27  vmovaps xmm11, [rsp+0xA0]
00007d248dbd9f30  vmovaps xmm12, [rsp+0xB0]
00007d248dbd9f39  vmovaps xmm13, [rsp+0xC0]
00007d248dbd9f42  vmovaps xmm14, [rsp+0xD0]
00007d248dbd9f4b  vmovaps xmm15, [rsp+0xE0]
00007d248dbd9f54  add rsp, 0xF0
00007d248dbd9f5b  pop r11
00007d248dbd9f5d  pop r10
00007d248dbd9f5f  pop r9
00007d248dbd9f61  pop r8
00007d248dbd9f63  pop rsi
00007d248dbd9f64  pop rdi
00007d248dbd9f65  pop rdx
00007d248dbd9f66  pop rcx
00007d248dbd9f67  pop rax
00007d248dbd9f68  add rsp, 0x08
00007d248dbd9f6c  jmp 0x00007D248DBD63AE
00007d248dbd9f71  sub rsp, 0x08
00007d248dbd9f75  push rax
00007d248dbd9f76  push rcx
00007d248dbd9f77  push rdx
00007d248dbd9f78  push rdi
00007d248dbd9f79  push rsi
00007d248dbd9f7a  push r8
00007d248dbd9f7c  push r9
00007d248dbd9f7e  push r10
00007d248dbd9f80  push r11
00007d248dbd9f82  sub rsp, 0xF0
00007d248dbd9f89  vmovaps [rsp], xmm0
00007d248dbd9f8e  vmovaps [rsp+0x10], xmm1
00007d248dbd9f94  vmovaps [rsp+0x20], xmm2
00007d248dbd9f9a  vmovaps [rsp+0x30], xmm3
00007d248dbd9fa0  vmovaps [rsp+0x40], xmm4
00007d248dbd9fa6  vmovaps [rsp+0x50], xmm5
00007d248dbd9fac  vmovaps [rsp+0x60], xmm7
00007d248dbd9fb2  vmovaps [rsp+0x70], xmm8
00007d248dbd9fb8  vmovaps [rsp+0x80], xmm9
00007d248dbd9fc1  vmovaps [rsp+0x90], xmm10
00007d248dbd9fca  vmovaps [rsp+0xA0], xmm11
00007d248dbd9fd3  vmovaps [rsp+0xB0], xmm12
00007d248dbd9fdc  vmovaps [rsp+0xC0], xmm13
00007d248dbd9fe5  vmovaps [rsp+0xD0], xmm14
00007d248dbd9fee  vmovaps [rsp+0xE0], xmm15
00007d248dbd9ff7  sub rsp, 0x30
00007d248dbd9ffb  movaps [rsp], xmm6
00007d248dbd9fff  movaps [rsp+0x10], xmm1
00007d248dbda004  movaps [rsp+0x20], xmm14
00007d248dbda00a  lea rdi, [rsp]
00007d248dbda00e  mov esi, 0x00
00007d248dbda013  mov rax, 0x5BCEEF236530
00007d248dbda01d  call rax
00007d248dbda01f  movaps xmm6, [rsp]
00007d248dbda023  add rsp, 0x30
00007d248dbda027  vmovaps xmm0, [rsp]
00007d248dbda02c  vmovaps xmm1, [rsp+0x10]
00007d248dbda032  vmovaps xmm2, [rsp+0x20]
00007d248dbda038  vmovaps xmm3, [rsp+0x30]
00007d248dbda03e  vmovaps xmm4, [rsp+0x40]
00007d248dbda044  vmovaps xmm5, [rsp+0x50]
00007d248dbda04a  vmovaps xmm7, [rsp+0x60]
00007d248dbda050  vmovaps xmm8, [rsp+0x70]
00007d248dbda056  vmovaps xmm9, [rsp+0x80]
00007d248dbda05f  vmovaps xmm10, [rsp+0x90]
00007d248dbda068  vmovaps xmm11, [rsp+0xA0]
00007d248dbda071  vmovaps xmm12, [rsp+0xB0]
00007d248dbda07a  vmovaps xmm13, [rsp+0xC0]
00007d248dbda083  vmovaps xmm14, [rsp+0xD0]
00007d248dbda08c  vmovaps xmm15, [rsp+0xE0]
00007d248dbda095  add rsp, 0xF0
00007d248dbda09c  pop r11
00007d248dbda09e  pop r10
00007d248dbda0a0  pop r9
00007d248dbda0a2  pop r8
00007d248dbda0a4  pop rsi
00007d248dbda0a5  pop rdi
00007d248dbda0a6  pop rdx
00007d248dbda0a7  pop rcx
00007d248dbda0a8  pop rax
00007d248dbda0a9  add rsp, 0x08
00007d248dbda0ad  jmp 0x00007D248DBD63DA
00007d248dbda0b2  sub rsp, 0x08
00007d248dbda0b6  push rax
00007d248dbda0b7  push rcx
00007d248dbda0b8  push rdx
00007d248dbda0b9  push rdi
00007d248dbda0ba  push rsi
00007d248dbda0bb  push r8
00007d248dbda0bd  push r9
00007d248dbda0bf  push r10
00007d248dbda0c1  push r11
00007d248dbda0c3  sub rsp, 0xF0
00007d248dbda0ca  vmovaps [rsp], xmm0
00007d248dbda0cf  vmovaps [rsp+0x10], xmm1
00007d248dbda0d5  vmovaps [rsp+0x20], xmm2
00007d248dbda0db  vmovaps [rsp+0x30], xmm3
00007d248dbda0e1  vmovaps [rsp+0x40], xmm4
00007d248dbda0e7  vmovaps [rsp+0x50], xmm5
00007d248dbda0ed  vmovaps [rsp+0x60], xmm6
00007d248dbda0f3  vmovaps [rsp+0x70], xmm7
00007d248dbda0f9  vmovaps [rsp+0x80], xmm8
00007d248dbda102  vmovaps [rsp+0x90], xmm9
00007d248dbda10b  vmovaps [rsp+0xA0], xmm10
00007d248dbda114  vmovaps [rsp+0xB0], xmm11
00007d248dbda11d  vmovaps [rsp+0xC0], xmm12
00007d248dbda126  vmovaps [rsp+0xD0], xmm13
00007d248dbda12f  vmovaps [rsp+0xE0], xmm15
00007d248dbda138  sub rsp, 0x30
00007d248dbda13c  movaps [rsp], xmm14
00007d248dbda141  movaps [rsp+0x10], xmm12
00007d248dbda147  movaps [rsp+0x20], xmm1
00007d248dbda14c  lea rdi, [rsp]
00007d248dbda150  mov esi, 0x00
00007d248dbda155  mov rax, 0x5BCEEF236530
00007d248dbda15f  call rax
00007d248dbda161  movaps xmm14, [rsp]
00007d248dbda166  add rsp, 0x30
00007d248dbda16a  vmovaps xmm0, [rsp]
00007d248dbda16f  vmovaps xmm1, [rsp+0x10]
00007d248dbda175  vmovaps xmm2, [rsp+0x20]
00007d248dbda17b  vmovaps xmm3, [rsp+0x30]
00007d248dbda181  vmovaps xmm4, [rsp+0x40]
00007d248dbda187  vmovaps xmm5, [rsp+0x50]
00007d248dbda18d  vmovaps xmm6, [rsp+0x60]
00007d248dbda193  vmovaps xmm7, [rsp+0x70]
00007d248dbda199  vmovaps xmm8, [rsp+0x80]
00007d248dbda1a2  vmovaps xmm9, [rsp+0x90]
00007d248dbda1ab  vmovaps xmm10, [rsp+0xA0]
00007d248dbda1b4  vmovaps xmm11, [rsp+0xB0]
00007d248dbda1bd  vmovaps xmm12, [rsp+0xC0]
00007d248dbda1c6  vmovaps xmm13, [rsp+0xD0]
00007d248dbda1cf  vmovaps xmm15, [rsp+0xE0]
00007d248dbda1d8  add rsp, 0xF0
00007d248dbda1df  pop r11
00007d248dbda1e1  pop r10
00007d248dbda1e3  pop r9
00007d248dbda1e5  pop r8
00007d248dbda1e7  pop rsi
00007d248dbda1e8  pop rdi
00007d248dbda1e9  pop rdx
00007d248dbda1ea  pop rcx
00007d248dbda1eb  pop rax
00007d248dbda1ec  add rsp, 0x08
00007d248dbda1f0  jmp 0x00007D248DBD6400
00007d248dbda1f5  sub rsp, 0x08
00007d248dbda1f9  push rax
00007d248dbda1fa  push rcx
00007d248dbda1fb  push rdx
00007d248dbda1fc  push rdi
00007d248dbda1fd  push rsi
00007d248dbda1fe  push r8
00007d248dbda200  push r9
00007d248dbda202  push r10
00007d248dbda204  push r11
00007d248dbda206  sub rsp, 0xF0
00007d248dbda20d  vmovaps [rsp], xmm0
00007d248dbda212  vmovaps [rsp+0x10], xmm2
00007d248dbda218  vmovaps [rsp+0x20], xmm3
00007d248dbda21e  vmovaps [rsp+0x30], xmm4
00007d248dbda224  vmovaps [rsp+0x40], xmm5
00007d248dbda22a  vmovaps [rsp+0x50], xmm6
00007d248dbda230  vmovaps [rsp+0x60], xmm7
00007d248dbda236  vmovaps [rsp+0x70], xmm8
00007d248dbda23c  vmovaps [rsp+0x80], xmm9
00007d248dbda245  vmovaps [rsp+0x90], xmm10
00007d248dbda24e  vmovaps [rsp+0xA0], xmm11
00007d248dbda257  vmovaps [rsp+0xB0], xmm12
00007d248dbda260  vmovaps [rsp+0xC0], xmm13
00007d248dbda269  vmovaps [rsp+0xD0], xmm14
00007d248dbda272  vmovaps [rsp+0xE0], xmm15
00007d248dbda27b  sub rsp, 0x30
00007d248dbda27f  movaps [rsp], xmm1
00007d248dbda283  movaps [rsp+0x10], xmm13
00007d248dbda289  movaps [rsp+0x20], xmm9
00007d248dbda28f  lea rdi, [rsp]
00007d248dbda293  mov esi, 0x00
00007d248dbda298  mov rax, 0x5BCEEF236530
00007d248dbda2a2  call rax
00007d248dbda2a4  movaps xmm1, [rsp]
00007d248dbda2a8  add rsp, 0x30
00007d248dbda2ac  vmovaps xmm0, [rsp]
00007d248dbda2b1  vmovaps xmm2, [rsp+0x10]
00007d248dbda2b7  vmovaps xmm3, [rsp+0x20]
00007d248dbda2bd  vmovaps xmm4, [rsp+0x30]
00007d248dbda2c3  vmovaps xmm5, [rsp+0x40]
00007d248dbda2c9  vmovaps xmm6, [rsp+0x50]
00007d248dbda2cf  vmovaps xmm7, [rsp+0x60]
00007d248dbda2d5  vmovaps xmm8, [rsp+0x70]
00007d248dbda2db  vmovaps xmm9, [rsp+0x80]
00007d248dbda2e4  vmovaps xmm10, [rsp+0x90]
00007d248dbda2ed  vmovaps xmm11, [rsp+0xA0]
00007d248dbda2f6  vmovaps xmm12, [rsp+0xB0]
00007d248dbda2ff  vmovaps xmm13, [rsp+0xC0]
00007d248dbda308  vmovaps xmm14, [rsp+0xD0]
00007d248dbda311  vmovaps xmm15, [rsp+0xE0]
00007d248dbda31a  add rsp, 0xF0
00007d248dbda321  pop r11
00007d248dbda323  pop r10
00007d248dbda325  pop r9
00007d248dbda327  pop r8
00007d248dbda329  pop rsi
00007d248dbda32a  pop rdi
00007d248dbda32b  pop rdx
00007d248dbda32c  pop rcx
00007d248dbda32d  pop rax
00007d248dbda32e  add rsp, 0x08
00007d248dbda332  jmp 0x00007D248DBD641A
00007d248dbda337  sub rsp, 0x08
00007d248dbda33b  push rax
00007d248dbda33c  push rcx
00007d248dbda33d  push rdx
00007d248dbda33e  push rdi
00007d248dbda33f  push rsi
00007d248dbda340  push r8
00007d248dbda342  push r9
00007d248dbda344  push r10
00007d248dbda346  push r11
00007d248dbda348  sub rsp, 0xF0
00007d248dbda34f  vmovaps [rsp], xmm0
00007d248dbda354  vmovaps [rsp+0x10], xmm1
00007d248dbda35a  vmovaps [rsp+0x20], xmm2
00007d248dbda360  vmovaps [rsp+0x30], xmm3
00007d248dbda366  vmovaps [rsp+0x40], xmm4
00007d248dbda36c  vmovaps [rsp+0x50], xmm5
00007d248dbda372  vmovaps [rsp+0x60], xmm6
00007d248dbda378  vmovaps [rsp+0x70], xmm7
00007d248dbda37e  vmovaps [rsp+0x80], xmm8
00007d248dbda387  vmovaps [rsp+0x90], xmm9
00007d248dbda390  vmovaps [rsp+0xA0], xmm10
00007d248dbda399  vmovaps [rsp+0xB0], xmm11
00007d248dbda3a2  vmovaps [rsp+0xC0], xmm13
00007d248dbda3ab  vmovaps [rsp+0xD0], xmm14
00007d248dbda3b4  vmovaps [rsp+0xE0], xmm15
00007d248dbda3bd  sub rsp, 0x30
00007d248dbda3c1  movaps [rsp], xmm12
00007d248dbda3c6  movaps [rsp+0x10], xmm7
00007d248dbda3cb  movaps [rsp+0x20], xmm13
00007d248dbda3d1  lea rdi, [rsp]
00007d248dbda3d5  mov esi, 0x00
00007d248dbda3da  mov rax, 0x5BCEEF236530
00007d248dbda3e4  call rax
00007d248dbda3e6  movaps xmm12, [rsp]
00007d248dbda3eb  add rsp, 0x30
00007d248dbda3ef  vmovaps xmm0, [rsp]
00007d248dbda3f4  vmovaps xmm1, [rsp+0x10]
00007d248dbda3fa  vmovaps xmm2, [rsp+0x20]
00007d248dbda400  vmovaps xmm3, [rsp+0x30]
00007d248dbda406  vmovaps xmm4, [rsp+0x40]
00007d248dbda40c  vmovaps xmm5, [rsp+0x50]
00007d248dbda412  vmovaps xmm6, [rsp+0x60]
00007d248dbda418  vmovaps xmm7, [rsp+0x70]
00007d248dbda41e  vmovaps xmm8, [rsp+0x80]
00007d248dbda427  vmovaps xmm9, [rsp+0x90]
00007d248dbda430  vmovaps xmm10, [rsp+0xA0]
00007d248dbda439  vmovaps xmm11, [rsp+0xB0]
00007d248dbda442  vmovaps xmm13, [rsp+0xC0]
00007d248dbda44b  vmovaps xmm14, [rsp+0xD0]
00007d248dbda454  vmovaps xmm15, [rsp+0xE0]
00007d248dbda45d  add rsp, 0xF0
00007d248dbda464  pop r11
00007d248dbda466  pop r10
00007d248dbda468  pop r9
00007d248dbda46a  pop r8
00007d248dbda46c  pop rsi
00007d248dbda46d  pop rdi
00007d248dbda46e  pop rdx
00007d248dbda46f  pop rcx
00007d248dbda470  pop rax
00007d248dbda471  add rsp, 0x08
00007d248dbda475  jmp 0x00007D248DBD6441
00007d248dbda47a  sub rsp, 0x08
00007d248dbda47e  push rax
00007d248dbda47f  push rcx
00007d248dbda480  push rdx
00007d248dbda481  push rdi
00007d248dbda482  push rsi
00007d248dbda483  push r8
00007d248dbda485  push r9
00007d248dbda487  push r10
00007d248dbda489  push r11
00007d248dbda48b  sub rsp, 0xF0
00007d248dbda492  vmovaps [rsp], xmm0
00007d248dbda497  vmovaps [rsp+0x10], xmm1
00007d248dbda49d  vmovaps [rsp+0x20], xmm2
00007d248dbda4a3  vmovaps [rsp+0x30], xmm3
00007d248dbda4a9  vmovaps [rsp+0x40], xmm4
00007d248dbda4af  vmovaps [rsp+0x50], xmm5
00007d248dbda4b5  vmovaps [rsp+0x60], xmm6
00007d248dbda4bb  vmovaps [rsp+0x70], xmm7
00007d248dbda4c1  vmovaps [rsp+0x80], xmm8
00007d248dbda4ca  vmovaps [rsp+0x90], xmm9
00007d248dbda4d3  vmovaps [rsp+0xA0], xmm10
00007d248dbda4dc  vmovaps [rsp+0xB0], xmm11
00007d248dbda4e5  vmovaps [rsp+0xC0], xmm12
00007d248dbda4ee  vmovaps [rsp+0xD0], xmm14
00007d248dbda4f7  vmovaps [rsp+0xE0], xmm15
00007d248dbda500  sub rsp, 0x30
00007d248dbda504  movaps [rsp], xmm13
00007d248dbda509  movaps [rsp+0x10], xmm15
00007d248dbda50f  movaps [rsp+0x20], xmm8
00007d248dbda515  lea rdi, [rsp]
00007d248dbda519  mov esi, 0x00
00007d248dbda51e  mov rax, 0x5BCEEF236530
00007d248dbda528  call rax
00007d248dbda52a  movaps xmm13, [rsp]
00007d248dbda52f  add rsp, 0x30
00007d248dbda533  vmovaps xmm0, [rsp]
00007d248dbda538  vmovaps xmm1, [rsp+0x10]
00007d248dbda53e  vmovaps xmm2, [rsp+0x20]
00007d248dbda544  vmovaps xmm3, [rsp+0x30]
00007d248dbda54a  vmovaps xmm4, [rsp+0x40]
00007d248dbda550  vmovaps xmm5, [rsp+0x50]
00007d248dbda556  vmovaps xmm6, [rsp+0x60]
00007d248dbda55c  vmovaps xmm7, [rsp+0x70]
00007d248dbda562  vmovaps xmm8, [rsp+0x80]
00007d248dbda56b  vmovaps xmm9, [rsp+0x90]
00007d248dbda574  vmovaps xmm10, [rsp+0xA0]
00007d248dbda57d  vmovaps xmm11, [rsp+0xB0]
00007d248dbda586  vmovaps xmm12, [rsp+0xC0]
00007d248dbda58f  vmovaps xmm14, [rsp+0xD0]
00007d248dbda598  vmovaps xmm15, [rsp+0xE0]
00007d248dbda5a1  add rsp, 0xF0
00007d248dbda5a8  pop r11
00007d248dbda5aa  pop r10
00007d248dbda5ac  pop r9
00007d248dbda5ae  pop r8
00007d248dbda5b0  pop rsi
00007d248dbda5b1  pop rdi
00007d248dbda5b2  pop rdx
00007d248dbda5b3  pop rcx
00007d248dbda5b4  pop rax
00007d248dbda5b5  add rsp, 0x08
00007d248dbda5b9  jmp 0x00007D248DBD645C
00007d248dbda5be  sub rsp, 0x08
00007d248dbda5c2  push rax
00007d248dbda5c3  push rcx
00007d248dbda5c4  push rdx
00007d248dbda5c5  push rdi
00007d248dbda5c6  push rsi
00007d248dbda5c7  push r8
00007d248dbda5c9  push r9
00007d248dbda5cb  push r10
00007d248dbda5cd  push r11
00007d248dbda5cf  sub rsp, 0xF0
00007d248dbda5d6  vmovaps [rsp], xmm0
00007d248dbda5db  vmovaps [rsp+0x10], xmm1
00007d248dbda5e1  vmovaps [rsp+0x20], xmm2
00007d248dbda5e7  vmovaps [rsp+0x30], xmm3
00007d248dbda5ed  vmovaps [rsp+0x40], xmm4
00007d248dbda5f3  vmovaps [rsp+0x50], xmm5
00007d248dbda5f9  vmovaps [rsp+0x60], xmm6
00007d248dbda5ff  vmovaps [rsp+0x70], xmm7
00007d248dbda605  vmovaps [rsp+0x80], xmm9
00007d248dbda60e  vmovaps [rsp+0x90], xmm10
00007d248dbda617  vmovaps [rsp+0xA0], xmm11
00007d248dbda620  vmovaps [rsp+0xB0], xmm12
00007d248dbda629  vmovaps [rsp+0xC0], xmm13
00007d248dbda632  vmovaps [rsp+0xD0], xmm14
00007d248dbda63b  vmovaps [rsp+0xE0], xmm15
00007d248dbda644  sub rsp, 0x30
00007d248dbda648  movaps [rsp], xmm8
00007d248dbda64d  movaps [rsp+0x10], xmm15
00007d248dbda653  movaps [rsp+0x20], xmm9
00007d248dbda659  lea rdi, [rsp]
00007d248dbda65d  mov esi, 0x00
00007d248dbda662  mov rax, 0x5BCEEF236530
00007d248dbda66c  call rax
00007d248dbda66e  movaps xmm8, [rsp]
00007d248dbda673  add rsp, 0x30
00007d248dbda677  vmovaps xmm0, [rsp]
00007d248dbda67c  vmovaps xmm1, [rsp+0x10]
00007d248dbda682  vmovaps xmm2, [rsp+0x20]
00007d248dbda688  vmovaps xmm3, [rsp+0x30]
00007d248dbda68e  vmovaps xmm4, [rsp+0x40]
00007d248dbda694  vmovaps xmm5, [rsp+0x50]
00007d248dbda69a  vmovaps xmm6, [rsp+0x60]
00007d248dbda6a0  vmovaps xmm7, [rsp+0x70]
00007d248dbda6a6  vmovaps xmm9, [rsp+0x80]
00007d248dbda6af  vmovaps xmm10, [rsp+0x90]
00007d248dbda6b8  vmovaps xmm11, [rsp+0xA0]
00007d248dbda6c1  vmovaps xmm12, [rsp+0xB0]
00007d248dbda6ca  vmovaps xmm13, [rsp+0xC0]
00007d248dbda6d3  vmovaps xmm14, [rsp+0xD0]
00007d248dbda6dc  vmovaps xmm15, [rsp+0xE0]
00007d248dbda6e5  add rsp, 0xF0
00007d248dbda6ec  pop r11
00007d248dbda6ee  pop r10
00007d248dbda6f0  pop r9
00007d248dbda6f2  pop r8
00007d248dbda6f4  pop rsi
00007d248dbda6f5  pop rdi
00007d248dbda6f6  pop rdx
00007d248dbda6f7  pop rcx
00007d248dbda6f8  pop rax
00007d248dbda6f9  add rsp, 0x08
00007d248dbda6fd  jmp 0x00007D248DBD648A
00007d248dbda702  sub rsp, 0x08
00007d248dbda706  push rax
00007d248dbda707  push rcx
00007d248dbda708  push rdx
00007d248dbda709  push rdi
00007d248dbda70a  push rsi
00007d248dbda70b  push r8
00007d248dbda70d  push r9
00007d248dbda70f  push r10
00007d248dbda711  push r11
00007d248dbda713  sub rsp, 0xF0
00007d248dbda71a  vmovaps [rsp], xmm0
00007d248dbda71f  vmovaps [rsp+0x10], xmm1
00007d248dbda725  vmovaps [rsp+0x20], xmm2
00007d248dbda72b  vmovaps [rsp+0x30], xmm3
00007d248dbda731  vmovaps [rsp+0x40], xmm4
00007d248dbda737  vmovaps [rsp+0x50], xmm5
00007d248dbda73d  vmovaps [rsp+0x60], xmm6
00007d248dbda743  vmovaps [rsp+0x70], xmm7
00007d248dbda749  vmovaps [rsp+0x80], xmm8
00007d248dbda752  vmovaps [rsp+0x90], xmm9
00007d248dbda75b  vmovaps [rsp+0xA0], xmm10
00007d248dbda764  vmovaps [rsp+0xB0], xmm11
00007d248dbda76d  vmovaps [rsp+0xC0], xmm12
00007d248dbda776  vmovaps [rsp+0xD0], xmm13
00007d248dbda77f  vmovaps [rsp+0xE0], xmm14
00007d248dbda788  sub rsp, 0x30
00007d248dbda78c  movaps [rsp], xmm15
00007d248dbda791  movaps [rsp+0x10], xmm11
00007d248dbda797  movaps [rsp+0x20], xmm6
00007d248dbda79c  lea rdi, [rsp]
00007d248dbda7a0  mov esi, 0x00
00007d248dbda7a5  mov rax, 0x5BCEEF236530
00007d248dbda7af  call rax
00007d248dbda7b1  movaps xmm15, [rsp]
00007d248dbda7b6  add rsp, 0x30
00007d248dbda7ba  vmovaps xmm0, [rsp]
00007d248dbda7bf  vmovaps xmm1, [rsp+0x10]
00007d248dbda7c5  vmovaps xmm2, [rsp+0x20]
00007d248dbda7cb  vmovaps xmm3, [rsp+0x30]
00007d248dbda7d1  vmovaps xmm4, [rsp+0x40]
00007d248dbda7d7  vmovaps xmm5, [rsp+0x50]
00007d248dbda7dd  vmovaps xmm6, [rsp+0x60]
00007d248dbda7e3  vmovaps xmm7, [rsp+0x70]
00007d248dbda7e9  vmovaps xmm8, [rsp+0x80]
00007d248dbda7f2  vmovaps xmm9, [rsp+0x90]
00007d248dbda7fb  vmovaps xmm10, [rsp+0xA0]
00007d248dbda804  vmovaps xmm11, [rsp+0xB0]
00007d248dbda80d  vmovaps xmm12, [rsp+0xC0]
00007d248dbda816  vmovaps xmm13, [rsp+0xD0]
00007d248dbda81f  vmovaps xmm14, [rsp+0xE0]
00007d248dbda828  add rsp, 0xF0
00007d248dbda82f  pop r11
00007d248dbda831  pop r10
00007d248dbda833  pop r9
00007d248dbda835  pop r8
00007d248dbda837  pop rsi
00007d248dbda838  pop rdi
00007d248dbda839  pop rdx
00007d248dbda83a  pop rcx
00007d248dbda83b  pop rax
00007d248dbda83c  add rsp, 0x08
00007d248dbda840  jmp 0x00007D248DBD64A5
00007d248dbda845  sub rsp, 0x08
00007d248dbda849  push rax
00007d248dbda84a  push rcx
00007d248dbda84b  push rdx
00007d248dbda84c  push rdi
00007d248dbda84d  push rsi
00007d248dbda84e  push r8
00007d248dbda850  push r9
00007d248dbda852  push r10
00007d248dbda854  push r11
00007d248dbda856  sub rsp, 0xF0
00007d248dbda85d  vmovaps [rsp], xmm0
00007d248dbda862  vmovaps [rsp+0x10], xmm1
00007d248dbda868  vmovaps [rsp+0x20], xmm2
00007d248dbda86e  vmovaps [rsp+0x30], xmm3
00007d248dbda874  vmovaps [rsp+0x40], xmm4
00007d248dbda87a  vmovaps [rsp+0x50], xmm5
00007d248dbda880  vmovaps [rsp+0x60], xmm6
00007d248dbda886  vmovaps [rsp+0x70], xmm8
00007d248dbda88c  vmovaps [rsp+0x80], xmm9
00007d248dbda895  vmovaps [rsp+0x90], xmm10
00007d248dbda89e  vmovaps [rsp+0xA0], xmm11
00007d248dbda8a7  vmovaps [rsp+0xB0], xmm12
00007d248dbda8b0  vmovaps [rsp+0xC0], xmm13
00007d248dbda8b9  vmovaps [rsp+0xD0], xmm14
00007d248dbda8c2  vmovaps [rsp+0xE0], xmm15
00007d248dbda8cb  sub rsp, 0x30
00007d248dbda8cf  movaps [rsp], xmm7
00007d248dbda8d3  movaps [rsp+0x10], xmm11
00007d248dbda8d9  movaps [rsp+0x20], xmm9
00007d248dbda8df  lea rdi, [rsp]
00007d248dbda8e3  mov esi, 0x00
00007d248dbda8e8  mov rax, 0x5BCEEF236530
00007d248dbda8f2  call rax
00007d248dbda8f4  movaps xmm7, [rsp]
00007d248dbda8f8  add rsp, 0x30
00007d248dbda8fc  vmovaps xmm0, [rsp]
00007d248dbda901  vmovaps xmm1, [rsp+0x10]
00007d248dbda907  vmovaps xmm2, [rsp+0x20]
00007d248dbda90d  vmovaps xmm3, [rsp+0x30]
00007d248dbda913  vmovaps xmm4, [rsp+0x40]
00007d248dbda919  vmovaps xmm5, [rsp+0x50]
00007d248dbda91f  vmovaps xmm6, [rsp+0x60]
00007d248dbda925  vmovaps xmm8, [rsp+0x70]
00007d248dbda92b  vmovaps xmm9, [rsp+0x80]
00007d248dbda934  vmovaps xmm10, [rsp+0x90]
00007d248dbda93d  vmovaps xmm11, [rsp+0xA0]
00007d248dbda946  vmovaps xmm12, [rsp+0xB0]
00007d248dbda94f  vmovaps xmm13, [rsp+0xC0]
00007d248dbda958  vmovaps xmm14, [rsp+0xD0]
00007d248dbda961  vmovaps xmm15, [rsp+0xE0]
00007d248dbda96a  add rsp, 0xF0
00007d248dbda971  pop r11
00007d248dbda973  pop r10
00007d248dbda975  pop r9
00007d248dbda977  pop r8
00007d248dbda979  pop rsi
00007d248dbda97a  pop rdi
00007d248dbda97b  pop rdx
00007d248dbda97c  pop rcx
00007d248dbda97d  pop rax
00007d248dbda97e  add rsp, 0x08
00007d248dbda982  jmp 0x00007D248DBD64D2
00007d248dbda987  sub rsp, 0x08
00007d248dbda98b  push rax
00007d248dbda98c  push rcx
00007d248dbda98d  push rdx
00007d248dbda98e  push rdi
00007d248dbda98f  push rsi
00007d248dbda990  push r8
00007d248dbda992  push r9
00007d248dbda994  push r10
00007d248dbda996  push r11
00007d248dbda998  sub rsp, 0xF0
00007d248dbda99f  vmovaps [rsp], xmm0
00007d248dbda9a4  vmovaps [rsp+0x10], xmm1
00007d248dbda9aa  vmovaps [rsp+0x20], xmm2
00007d248dbda9b0  vmovaps [rsp+0x30], xmm3
00007d248dbda9b6  vmovaps [rsp+0x40], xmm4
00007d248dbda9bc  vmovaps [rsp+0x50], xmm5
00007d248dbda9c2  vmovaps [rsp+0x60], xmm6
00007d248dbda9c8  vmovaps [rsp+0x70], xmm7
00007d248dbda9ce  vmovaps [rsp+0x80], xmm8
00007d248dbda9d7  vmovaps [rsp+0x90], xmm9
00007d248dbda9e0  vmovaps [rsp+0xA0], xmm10
00007d248dbda9e9  vmovaps [rsp+0xB0], xmm12
00007d248dbda9f2  vmovaps [rsp+0xC0], xmm13
00007d248dbda9fb  vmovaps [rsp+0xD0], xmm14
00007d248dbdaa04  vmovaps [rsp+0xE0], xmm15
00007d248dbdaa0d  sub rsp, 0x30
00007d248dbdaa11  movaps [rsp], xmm11
00007d248dbdaa16  movaps [rsp+0x10], xmm10
00007d248dbdaa1c  movaps [rsp+0x20], xmm14
00007d248dbdaa22  lea rdi, [rsp]
00007d248dbdaa26  mov esi, 0x00
00007d248dbdaa2b  mov rax, 0x5BCEEF236530
00007d248dbdaa35  call rax
00007d248dbdaa37  movaps xmm11, [rsp]
00007d248dbdaa3c  add rsp, 0x30
00007d248dbdaa40  vmovaps xmm0, [rsp]
00007d248dbdaa45  vmovaps xmm1, [rsp+0x10]
00007d248dbdaa4b  vmovaps xmm2, [rsp+0x20]
00007d248dbdaa51  vmovaps xmm3, [rsp+0x30]
00007d248dbdaa57  vmovaps xmm4, [rsp+0x40]
00007d248dbdaa5d  vmovaps xmm5, [rsp+0x50]
00007d248dbdaa63  vmovaps xmm6, [rsp+0x60]
00007d248dbdaa69  vmovaps xmm7, [rsp+0x70]
00007d248dbdaa6f  vmovaps xmm8, [rsp+0x80]
00007d248dbdaa78  vmovaps xmm9, [rsp+0x90]
00007d248dbdaa81  vmovaps xmm10, [rsp+0xA0]
00007d248dbdaa8a  vmovaps xmm12, [rsp+0xB0]
00007d248dbdaa93  vmovaps xmm13, [rsp+0xC0]
00007d248dbdaa9c  vmovaps xmm14, [rsp+0xD0]
00007d248dbdaaa5  vmovaps xmm15, [rsp+0xE0]
00007d248dbdaaae  add rsp, 0xF0
00007d248dbdaab5  pop r11
00007d248dbdaab7  pop r10
00007d248dbdaab9  pop r9
00007d248dbdaabb  pop r8
00007d248dbdaabd  pop rsi
00007d248dbdaabe  pop rdi
00007d248dbdaabf  pop rdx
00007d248dbdaac0  pop rcx
00007d248dbdaac1  pop rax
00007d248dbdaac2  add rsp, 0x08
00007d248dbdaac6  jmp 0x00007D248DBD64ED
00007d248dbdaacb  call 0x00007D248DAE45A0
00007d248dbdaad0  jmp 0x00007D248DBD64F7
00007d248dbdaad5  sub rsp, 0x08
00007d248dbdaad9  push rax
00007d248dbdaada  push rcx
00007d248dbdaadb  push rdx
00007d248dbdaadc  push rdi
00007d248dbdaadd  push rsi
00007d248dbdaade  push r8
00007d248dbdaae0  push r9
00007d248dbdaae2  push r10
00007d248dbdaae4  push r11
00007d248dbdaae6  sub rsp, 0xF0
00007d248dbdaaed  vmovaps [rsp], xmm0
00007d248dbdaaf2  vmovaps [rsp+0x10], xmm1
00007d248dbdaaf8  vmovaps [rsp+0x20], xmm2
00007d248dbdaafe  vmovaps [rsp+0x30], xmm3
00007d248dbdab04  vmovaps [rsp+0x40], xmm4
00007d248dbdab0a  vmovaps [rsp+0x50], xmm5
00007d248dbdab10  vmovaps [rsp+0x60], xmm6
00007d248dbdab16  vmovaps [rsp+0x70], xmm7
00007d248dbdab1c  vmovaps [rsp+0x80], xmm8
00007d248dbdab25  vmovaps [rsp+0x90], xmm9
00007d248dbdab2e  vmovaps [rsp+0xA0], xmm11
00007d248dbdab37  vmovaps [rsp+0xB0], xmm12
00007d248dbdab40  vmovaps [rsp+0xC0], xmm13
00007d248dbdab49  vmovaps [rsp+0xD0], xmm14
00007d248dbdab52  vmovaps [rsp+0xE0], xmm15
00007d248dbdab5b  sub rsp, 0x30
00007d248dbdab5f  movaps [rsp], xmm10
00007d248dbdab64  movaps [rsp+0x10], xmm1
00007d248dbdab69  movaps [rsp+0x20], xmm12
00007d248dbdab6f  lea rdi, [rsp]
00007d248dbdab73  mov esi, 0x00
00007d248dbdab78  mov rax, 0x5BCEEF236530
00007d248dbdab82  call rax
00007d248dbdab84  movaps xmm10, [rsp]
00007d248dbdab89  add rsp, 0x30
00007d248dbdab8d  vmovaps xmm0, [rsp]
00007d248dbdab92  vmovaps xmm1, [rsp+0x10]
00007d248dbdab98  vmovaps xmm2, [rsp+0x20]
00007d248dbdab9e  vmovaps xmm3, [rsp+0x30]
00007d248dbdaba4  vmovaps xmm4, [rsp+0x40]
00007d248dbdabaa  vmovaps xmm5, [rsp+0x50]
00007d248dbdabb0  vmovaps xmm6, [rsp+0x60]
00007d248dbdabb6  vmovaps xmm7, [rsp+0x70]
00007d248dbdabbc  vmovaps xmm8, [rsp+0x80]
00007d248dbdabc5  vmovaps xmm9, [rsp+0x90]
00007d248dbdabce  vmovaps xmm11, [rsp+0xA0]
00007d248dbdabd7  vmovaps xmm12, [rsp+0xB0]
00007d248dbdabe0  vmovaps xmm13, [rsp+0xC0]
00007d248dbdabe9  vmovaps xmm14, [rsp+0xD0]
00007d248dbdabf2  vmovaps xmm15, [rsp+0xE0]
00007d248dbdabfb  add rsp, 0xF0
00007d248dbdac02  pop r11
00007d248dbdac04  pop r10
00007d248dbdac06  pop r9
00007d248dbdac08  pop r8
00007d248dbdac0a  pop rsi
00007d248dbdac0b  pop rdi
00007d248dbdac0c  pop rdx
00007d248dbdac0d  pop rcx
00007d248dbdac0e  pop rax
00007d248dbdac0f  add rsp, 0x08
00007d248dbdac13  jmp 0x00007D248DBD651A
00007d248dbdac18  sub rsp, 0x08
00007d248dbdac1c  push rax
00007d248dbdac1d  push rcx
00007d248dbdac1e  push rdx
00007d248dbdac1f  push rdi
00007d248dbdac20  push rsi
00007d248dbdac21  push r8
00007d248dbdac23  push r9
00007d248dbdac25  push r10
00007d248dbdac27  push r11
00007d248dbdac29  sub rsp, 0xF0
00007d248dbdac30  vmovaps [rsp], xmm0
00007d248dbdac35  vmovaps [rsp+0x10], xmm1
00007d248dbdac3b  vmovaps [rsp+0x20], xmm2
00007d248dbdac41  vmovaps [rsp+0x30], xmm3
00007d248dbdac47  vmovaps [rsp+0x40], xmm4
00007d248dbdac4d  vmovaps [rsp+0x50], xmm5
00007d248dbdac53  vmovaps [rsp+0x60], xmm6
00007d248dbdac59  vmovaps [rsp+0x70], xmm7
00007d248dbdac5f  vmovaps [rsp+0x80], xmm8
00007d248dbdac68  vmovaps [rsp+0x90], xmm9
00007d248dbdac71  vmovaps [rsp+0xA0], xmm10
00007d248dbdac7a  vmovaps [rsp+0xB0], xmm11
00007d248dbdac83  vmovaps [rsp+0xC0], xmm13
00007d248dbdac8c  vmovaps [rsp+0xD0], xmm14
00007d248dbdac95  vmovaps [rsp+0xE0], xmm15
00007d248dbdac9e  sub rsp, 0x30
00007d248dbdaca2  movaps [rsp], xmm12
00007d248dbdaca7  movaps [rsp+0x10], xmm14
00007d248dbdacad  movaps [rsp+0x20], xmm1
00007d248dbdacb2  lea rdi, [rsp]
00007d248dbdacb6  mov esi, 0x00
00007d248dbdacbb  mov rax, 0x5BCEEF236530
00007d248dbdacc5  call rax
00007d248dbdacc7  movaps xmm12, [rsp]
00007d248dbdaccc  add rsp, 0x30
00007d248dbdacd0  vmovaps xmm0, [rsp]
00007d248dbdacd5  vmovaps xmm1, [rsp+0x10]
00007d248dbdacdb  vmovaps xmm2, [rsp+0x20]
00007d248dbdace1  vmovaps xmm3, [rsp+0x30]
00007d248dbdace7  vmovaps xmm4, [rsp+0x40]
00007d248dbdaced  vmovaps xmm5, [rsp+0x50]
00007d248dbdacf3  vmovaps xmm6, [rsp+0x60]
00007d248dbdacf9  vmovaps xmm7, [rsp+0x70]
00007d248dbdacff  vmovaps xmm8, [rsp+0x80]
00007d248dbdad08  vmovaps xmm9, [rsp+0x90]
00007d248dbdad11  vmovaps xmm10, [rsp+0xA0]
00007d248dbdad1a  vmovaps xmm11, [rsp+0xB0]
00007d248dbdad23  vmovaps xmm13, [rsp+0xC0]
00007d248dbdad2c  vmovaps xmm14, [rsp+0xD0]
00007d248dbdad35  vmovaps xmm15, [rsp+0xE0]
00007d248dbdad3e  add rsp, 0xF0
00007d248dbdad45  pop r11
00007d248dbdad47  pop r10
00007d248dbdad49  pop r9
00007d248dbdad4b  pop r8
00007d248dbdad4d  pop rsi
00007d248dbdad4e  pop rdi
00007d248dbdad4f  pop rdx
00007d248dbdad50  pop rcx
00007d248dbdad51  pop rax
00007d248dbdad52  add rsp, 0x08
00007d248dbdad56  jmp 0x00007D248DBD6549
00007d248dbdad5b  sub rsp, 0x08
00007d248dbdad5f  push rax
00007d248dbdad60  push rcx
00007d248dbdad61  push rdx
00007d248dbdad62  push rdi
00007d248dbdad63  push rsi
00007d248dbdad64  push r8
00007d248dbdad66  push r9
00007d248dbdad68  push r10
00007d248dbdad6a  push r11
00007d248dbdad6c  sub rsp, 0xF0
00007d248dbdad73  vmovaps [rsp], xmm0
00007d248dbdad78  vmovaps [rsp+0x10], xmm1
00007d248dbdad7e  vmovaps [rsp+0x20], xmm2
00007d248dbdad84  vmovaps [rsp+0x30], xmm3
00007d248dbdad8a  vmovaps [rsp+0x40], xmm4
00007d248dbdad90  vmovaps [rsp+0x50], xmm5
00007d248dbdad96  vmovaps [rsp+0x60], xmm6
00007d248dbdad9c  vmovaps [rsp+0x70], xmm7
00007d248dbdada2  vmovaps [rsp+0x80], xmm8
00007d248dbdadab  vmovaps [rsp+0x90], xmm9
00007d248dbdadb4  vmovaps [rsp+0xA0], xmm10
00007d248dbdadbd  vmovaps [rsp+0xB0], xmm11
00007d248dbdadc6  vmovaps [rsp+0xC0], xmm12
00007d248dbdadcf  vmovaps [rsp+0xD0], xmm13
00007d248dbdadd8  vmovaps [rsp+0xE0], xmm15
00007d248dbdade1  sub rsp, 0x30
00007d248dbdade5  movaps [rsp], xmm14
00007d248dbdadea  movaps [rsp+0x10], xmm9
00007d248dbdadf0  movaps [rsp+0x20], xmm1
00007d248dbdadf5  lea rdi, [rsp]
00007d248dbdadf9  mov esi, 0x00
00007d248dbdadfe  mov rax, 0x5BCEEF236530
00007d248dbdae08  call rax
00007d248dbdae0a  movaps xmm14, [rsp]
00007d248dbdae0f  add rsp, 0x30
00007d248dbdae13  vmovaps xmm0, [rsp]
00007d248dbdae18  vmovaps xmm1, [rsp+0x10]
00007d248dbdae1e  vmovaps xmm2, [rsp+0x20]
00007d248dbdae24  vmovaps xmm3, [rsp+0x30]
00007d248dbdae2a  vmovaps xmm4, [rsp+0x40]
00007d248dbdae30  vmovaps xmm5, [rsp+0x50]
00007d248dbdae36  vmovaps xmm6, [rsp+0x60]
00007d248dbdae3c  vmovaps xmm7, [rsp+0x70]
00007d248dbdae42  vmovaps xmm8, [rsp+0x80]
00007d248dbdae4b  vmovaps xmm9, [rsp+0x90]
00007d248dbdae54  vmovaps xmm10, [rsp+0xA0]
00007d248dbdae5d  vmovaps xmm11, [rsp+0xB0]
00007d248dbdae66  vmovaps xmm12, [rsp+0xC0]
00007d248dbdae6f  vmovaps xmm13, [rsp+0xD0]
00007d248dbdae78  vmovaps xmm15, [rsp+0xE0]
00007d248dbdae81  add rsp, 0xF0
00007d248dbdae88  pop r11
00007d248dbdae8a  pop r10
00007d248dbdae8c  pop r9
00007d248dbdae8e  pop r8
00007d248dbdae90  pop rsi
00007d248dbdae91  pop rdi
00007d248dbdae92  pop rdx
00007d248dbdae93  pop rcx
00007d248dbdae94  pop rax
00007d248dbdae95  add rsp, 0x08
00007d248dbdae99  jmp 0x00007D248DBD6578
00007d248dbdae9e  sub rsp, 0x08
00007d248dbdaea2  push rax
00007d248dbdaea3  push rcx
00007d248dbdaea4  push rdx
00007d248dbdaea5  push rdi
00007d248dbdaea6  push rsi
00007d248dbdaea7  push r8
00007d248dbdaea9  push r9
00007d248dbdaeab  push r10
00007d248dbdaead  push r11
00007d248dbdaeaf  sub rsp, 0xF0
00007d248dbdaeb6  vmovaps [rsp], xmm0
00007d248dbdaebb  vmovaps [rsp+0x10], xmm2
00007d248dbdaec1  vmovaps [rsp+0x20], xmm3
00007d248dbdaec7  vmovaps [rsp+0x30], xmm4
00007d248dbdaecd  vmovaps [rsp+0x40], xmm5
00007d248dbdaed3  vmovaps [rsp+0x50], xmm6
00007d248dbdaed9  vmovaps [rsp+0x60], xmm7
00007d248dbdaedf  vmovaps [rsp+0x70], xmm8
00007d248dbdaee5  vmovaps [rsp+0x80], xmm9
00007d248dbdaeee  vmovaps [rsp+0x90], xmm10
00007d248dbdaef7  vmovaps [rsp+0xA0], xmm11
00007d248dbdaf00  vmovaps [rsp+0xB0], xmm12
00007d248dbdaf09  vmovaps [rsp+0xC0], xmm13
00007d248dbdaf12  vmovaps [rsp+0xD0], xmm14
00007d248dbdaf1b  vmovaps [rsp+0xE0], xmm15
00007d248dbdaf24  sub rsp, 0x30
00007d248dbdaf28  movaps [rsp], xmm1
00007d248dbdaf2c  movaps [rsp+0x10], xmm13
00007d248dbdaf32  movaps [rsp+0x20], xmm8
00007d248dbdaf38  lea rdi, [rsp]
00007d248dbdaf3c  mov esi, 0x00
00007d248dbdaf41  mov rax, 0x5BCEEF236530
00007d248dbdaf4b  call rax
00007d248dbdaf4d  movaps xmm1, [rsp]
00007d248dbdaf51  add rsp, 0x30
00007d248dbdaf55  vmovaps xmm0, [rsp]
00007d248dbdaf5a  vmovaps xmm2, [rsp+0x10]
00007d248dbdaf60  vmovaps xmm3, [rsp+0x20]
00007d248dbdaf66  vmovaps xmm4, [rsp+0x30]
00007d248dbdaf6c  vmovaps xmm5, [rsp+0x40]
00007d248dbdaf72  vmovaps xmm6, [rsp+0x50]
00007d248dbdaf78  vmovaps xmm7, [rsp+0x60]
00007d248dbdaf7e  vmovaps xmm8, [rsp+0x70]
00007d248dbdaf84  vmovaps xmm9, [rsp+0x80]
00007d248dbdaf8d  vmovaps xmm10, [rsp+0x90]
00007d248dbdaf96  vmovaps xmm11, [rsp+0xA0]
00007d248dbdaf9f  vmovaps xmm12, [rsp+0xB0]
00007d248dbdafa8  vmovaps xmm13, [rsp+0xC0]
00007d248dbdafb1  vmovaps xmm14, [rsp+0xD0]
00007d248dbdafba  vmovaps xmm15, [rsp+0xE0]
00007d248dbdafc3  add rsp, 0xF0
00007d248dbdafca  pop r11
00007d248dbdafcc  pop r10
00007d248dbdafce  pop r9
00007d248dbdafd0  pop r8
00007d248dbdafd2  pop rsi
00007d248dbdafd3  pop rdi
00007d248dbdafd4  pop rdx
00007d248dbdafd5  pop rcx
00007d248dbdafd6  pop rax
00007d248dbdafd7  add rsp, 0x08
00007d248dbdafdb  jmp 0x00007D248DBD659A
00007d248dbdafe0  call 0x00007D248DA0C260
00007d248dbdafe5  jmp 0x00007D248DBD65A8
00007d248dbdafea  call 0x00007D248DADE950
00007d248dbdafef  jmp 0x00007D248DBD65B2
00007d248dbdaff4  sub rsp, 0x08
00007d248dbdaff8  push rax
00007d248dbdaff9  push rcx
00007d248dbdaffa  push rdx
00007d248dbdaffb  push rdi
00007d248dbdaffc  push rsi
00007d248dbdaffd  push r8
00007d248dbdafff  push r9
00007d248dbdb001  push r10
00007d248dbdb003  push r11
00007d248dbdb005  sub rsp, 0xF0
00007d248dbdb00c  vmovaps [rsp], xmm0
00007d248dbdb011  vmovaps [rsp+0x10], xmm1
00007d248dbdb017  vmovaps [rsp+0x20], xmm2
00007d248dbdb01d  vmovaps [rsp+0x30], xmm3
00007d248dbdb023  vmovaps [rsp+0x40], xmm4
00007d248dbdb029  vmovaps [rsp+0x50], xmm5
00007d248dbdb02f  vmovaps [rsp+0x60], xmm6
00007d248dbdb035  vmovaps [rsp+0x70], xmm7
00007d248dbdb03b  vmovaps [rsp+0x80], xmm9
00007d248dbdb044  vmovaps [rsp+0x90], xmm10
00007d248dbdb04d  vmovaps [rsp+0xA0], xmm11
00007d248dbdb056  vmovaps [rsp+0xB0], xmm12
00007d248dbdb05f  vmovaps [rsp+0xC0], xmm13
00007d248dbdb068  vmovaps [rsp+0xD0], xmm14
00007d248dbdb071  vmovaps [rsp+0xE0], xmm15
00007d248dbdb07a  sub rsp, 0x30
00007d248dbdb07e  movaps [rsp], xmm8
00007d248dbdb083  movaps [rsp+0x10], xmm15
00007d248dbdb089  movaps [rsp+0x20], xmm7
00007d248dbdb08e  lea rdi, [rsp]
00007d248dbdb092  mov esi, 0x00
00007d248dbdb097  mov rax, 0x5BCEEF236530
00007d248dbdb0a1  call rax
00007d248dbdb0a3  movaps xmm8, [rsp]
00007d248dbdb0a8  add rsp, 0x30
00007d248dbdb0ac  vmovaps xmm0, [rsp]
00007d248dbdb0b1  vmovaps xmm1, [rsp+0x10]
00007d248dbdb0b7  vmovaps xmm2, [rsp+0x20]
00007d248dbdb0bd  vmovaps xmm3, [rsp+0x30]
00007d248dbdb0c3  vmovaps xmm4, [rsp+0x40]
00007d248dbdb0c9  vmovaps xmm5, [rsp+0x50]
00007d248dbdb0cf  vmovaps xmm6, [rsp+0x60]
00007d248dbdb0d5  vmovaps xmm7, [rsp+0x70]
00007d248dbdb0db  vmovaps xmm9, [rsp+0x80]
00007d248dbdb0e4  vmovaps xmm10, [rsp+0x90]
00007d248dbdb0ed  vmovaps xmm11, [rsp+0xA0]
00007d248dbdb0f6  vmovaps xmm12, [rsp+0xB0]
00007d248dbdb0ff  vmovaps xmm13, [rsp+0xC0]
00007d248dbdb108  vmovaps xmm14, [rsp+0xD0]
00007d248dbdb111  vmovaps xmm15, [rsp+0xE0]
00007d248dbdb11a  add rsp, 0xF0
00007d248dbdb121  pop r11
00007d248dbdb123  pop r10
00007d248dbdb125  pop r9
00007d248dbdb127  pop r8
00007d248dbdb129  pop rsi
00007d248dbdb12a  pop rdi
00007d248dbdb12b  pop rdx
00007d248dbdb12c  pop rcx
00007d248dbdb12d  pop rax
00007d248dbdb12e  add rsp, 0x08
00007d248dbdb132  jmp 0x00007D248DBD65D4
00007d248dbdb137  sub rsp, 0x08
00007d248dbdb13b  push rax
00007d248dbdb13c  push rcx
00007d248dbdb13d  push rdx
00007d248dbdb13e  push rdi
00007d248dbdb13f  push rsi
00007d248dbdb140  push r8
00007d248dbdb142  push r9
00007d248dbdb144  push r10
00007d248dbdb146  push r11
00007d248dbdb148  sub rsp, 0xF0
00007d248dbdb14f  vmovaps [rsp], xmm0
00007d248dbdb154  vmovaps [rsp+0x10], xmm1
00007d248dbdb15a  vmovaps [rsp+0x20], xmm2
00007d248dbdb160  vmovaps [rsp+0x30], xmm3
00007d248dbdb166  vmovaps [rsp+0x40], xmm4
00007d248dbdb16c  vmovaps [rsp+0x50], xmm5
00007d248dbdb172  vmovaps [rsp+0x60], xmm6
00007d248dbdb178  vmovaps [rsp+0x70], xmm8
00007d248dbdb17e  vmovaps [rsp+0x80], xmm9
00007d248dbdb187  vmovaps [rsp+0x90], xmm10
00007d248dbdb190  vmovaps [rsp+0xA0], xmm11
00007d248dbdb199  vmovaps [rsp+0xB0], xmm12
00007d248dbdb1a2  vmovaps [rsp+0xC0], xmm13
00007d248dbdb1ab  vmovaps [rsp+0xD0], xmm14
00007d248dbdb1b4  vmovaps [rsp+0xE0], xmm15
00007d248dbdb1bd  sub rsp, 0x30
00007d248dbdb1c1  movaps [rsp], xmm7
00007d248dbdb1c5  movaps [rsp+0x10], xmm9
00007d248dbdb1cb  movaps [rsp+0x20], xmm15
00007d248dbdb1d1  lea rdi, [rsp]
00007d248dbdb1d5  mov esi, 0x00
00007d248dbdb1da  mov rax, 0x5BCEEF236530
00007d248dbdb1e4  call rax
00007d248dbdb1e6  movaps xmm7, [rsp]
00007d248dbdb1ea  add rsp, 0x30
00007d248dbdb1ee  vmovaps xmm0, [rsp]
00007d248dbdb1f3  vmovaps xmm1, [rsp+0x10]
00007d248dbdb1f9  vmovaps xmm2, [rsp+0x20]
00007d248dbdb1ff  vmovaps xmm3, [rsp+0x30]
00007d248dbdb205  vmovaps xmm4, [rsp+0x40]
00007d248dbdb20b  vmovaps xmm5, [rsp+0x50]
00007d248dbdb211  vmovaps xmm6, [rsp+0x60]
00007d248dbdb217  vmovaps xmm8, [rsp+0x70]
00007d248dbdb21d  vmovaps xmm9, [rsp+0x80]
00007d248dbdb226  vmovaps xmm10, [rsp+0x90]
00007d248dbdb22f  vmovaps xmm11, [rsp+0xA0]
00007d248dbdb238  vmovaps xmm12, [rsp+0xB0]
00007d248dbdb241  vmovaps xmm13, [rsp+0xC0]
00007d248dbdb24a  vmovaps xmm14, [rsp+0xD0]
00007d248dbdb253  vmovaps xmm15, [rsp+0xE0]
00007d248dbdb25c  add rsp, 0xF0
00007d248dbdb263  pop r11
00007d248dbdb265  pop r10
00007d248dbdb267  pop r9
00007d248dbdb269  pop r8
00007d248dbdb26b  pop rsi
00007d248dbdb26c  pop rdi
00007d248dbdb26d  pop rdx
00007d248dbdb26e  pop rcx
00007d248dbdb26f  pop rax
00007d248dbdb270  add rsp, 0x08
00007d248dbdb274  jmp 0x00007D248DBD6601
00007d248dbdb279  sub rsp, 0x08
00007d248dbdb27d  push rax
00007d248dbdb27e  push rcx
00007d248dbdb27f  push rdx
00007d248dbdb280  push rdi
00007d248dbdb281  push rsi
00007d248dbdb282  push r8
00007d248dbdb284  push r9
00007d248dbdb286  push r10
00007d248dbdb288  push r11
00007d248dbdb28a  sub rsp, 0xF0
00007d248dbdb291  vmovaps [rsp], xmm0
00007d248dbdb296  vmovaps [rsp+0x10], xmm1
00007d248dbdb29c  vmovaps [rsp+0x20], xmm2
00007d248dbdb2a2  vmovaps [rsp+0x30], xmm3
00007d248dbdb2a8  vmovaps [rsp+0x40], xmm4
00007d248dbdb2ae  vmovaps [rsp+0x50], xmm5
00007d248dbdb2b4  vmovaps [rsp+0x60], xmm6
00007d248dbdb2ba  vmovaps [rsp+0x70], xmm7
00007d248dbdb2c0  vmovaps [rsp+0x80], xmm8
00007d248dbdb2c9  vmovaps [rsp+0x90], xmm10
00007d248dbdb2d2  vmovaps [rsp+0xA0], xmm11
00007d248dbdb2db  vmovaps [rsp+0xB0], xmm12
00007d248dbdb2e4  vmovaps [rsp+0xC0], xmm13
00007d248dbdb2ed  vmovaps [rsp+0xD0], xmm14
00007d248dbdb2f6  vmovaps [rsp+0xE0], xmm15
00007d248dbdb2ff  sub rsp, 0x30
00007d248dbdb303  movaps [rsp], xmm9
00007d248dbdb308  movaps [rsp+0x10], xmm13
00007d248dbdb30e  movaps [rsp+0x20], xmm15
00007d248dbdb314  lea rdi, [rsp]
00007d248dbdb318  mov esi, 0x00
00007d248dbdb31d  mov rax, 0x5BCEEF236530
00007d248dbdb327  call rax
00007d248dbdb329  movaps xmm9, [rsp]
00007d248dbdb32e  add rsp, 0x30
00007d248dbdb332  vmovaps xmm0, [rsp]
00007d248dbdb337  vmovaps xmm1, [rsp+0x10]
00007d248dbdb33d  vmovaps xmm2, [rsp+0x20]
00007d248dbdb343  vmovaps xmm3, [rsp+0x30]
00007d248dbdb349  vmovaps xmm4, [rsp+0x40]
00007d248dbdb34f  vmovaps xmm5, [rsp+0x50]
00007d248dbdb355  vmovaps xmm6, [rsp+0x60]
00007d248dbdb35b  vmovaps xmm7, [rsp+0x70]
00007d248dbdb361  vmovaps xmm8, [rsp+0x80]
00007d248dbdb36a  vmovaps xmm10, [rsp+0x90]
00007d248dbdb373  vmovaps xmm11, [rsp+0xA0]
00007d248dbdb37c  vmovaps xmm12, [rsp+0xB0]
00007d248dbdb385  vmovaps xmm13, [rsp+0xC0]
00007d248dbdb38e  vmovaps xmm14, [rsp+0xD0]
00007d248dbdb397  vmovaps xmm15, [rsp+0xE0]
00007d248dbdb3a0  add rsp, 0xF0
00007d248dbdb3a7  pop r11
00007d248dbdb3a9  pop r10
00007d248dbdb3ab  pop r9
00007d248dbdb3ad  pop r8
00007d248dbdb3af  pop rsi
00007d248dbdb3b0  pop rdi
00007d248dbdb3b1  pop rdx
00007d248dbdb3b2  pop rcx
00007d248dbdb3b3  pop rax
00007d248dbdb3b4  add rsp, 0x08
00007d248dbdb3b8  jmp 0x00007D248DBD662F
00007d248dbdb3bd  sub rsp, 0x08
00007d248dbdb3c1  push rax
00007d248dbdb3c2  push rcx
00007d248dbdb3c3  push rdx
00007d248dbdb3c4  push rdi
00007d248dbdb3c5  push rsi
00007d248dbdb3c6  push r8
00007d248dbdb3c8  push r9
00007d248dbdb3ca  push r10
00007d248dbdb3cc  push r11
00007d248dbdb3ce  sub rsp, 0xF0
00007d248dbdb3d5  vmovaps [rsp], xmm0
00007d248dbdb3da  vmovaps [rsp+0x10], xmm1
00007d248dbdb3e0  vmovaps [rsp+0x20], xmm2
00007d248dbdb3e6  vmovaps [rsp+0x30], xmm3
00007d248dbdb3ec  vmovaps [rsp+0x40], xmm4
00007d248dbdb3f2  vmovaps [rsp+0x50], xmm5
00007d248dbdb3f8  vmovaps [rsp+0x60], xmm6
00007d248dbdb3fe  vmovaps [rsp+0x70], xmm7
00007d248dbdb404  vmovaps [rsp+0x80], xmm8
00007d248dbdb40d  vmovaps [rsp+0x90], xmm9
00007d248dbdb416  vmovaps [rsp+0xA0], xmm10
00007d248dbdb41f  vmovaps [rsp+0xB0], xmm11
00007d248dbdb428  vmovaps [rsp+0xC0], xmm12
00007d248dbdb431  vmovaps [rsp+0xD0], xmm13
00007d248dbdb43a  vmovaps [rsp+0xE0], xmm14
00007d248dbdb443  sub rsp, 0x30
00007d248dbdb447  movaps [rsp], xmm15
00007d248dbdb44c  movaps [rsp+0x10], xmm11
00007d248dbdb452  movaps [rsp+0x20], xmm12
00007d248dbdb458  lea rdi, [rsp]
00007d248dbdb45c  mov esi, 0x00
00007d248dbdb461  mov rax, 0x5BCEEF236530
00007d248dbdb46b  call rax
00007d248dbdb46d  movaps xmm15, [rsp]
00007d248dbdb472  add rsp, 0x30
00007d248dbdb476  vmovaps xmm0, [rsp]
00007d248dbdb47b  vmovaps xmm1, [rsp+0x10]
00007d248dbdb481  vmovaps xmm2, [rsp+0x20]
00007d248dbdb487  vmovaps xmm3, [rsp+0x30]
00007d248dbdb48d  vmovaps xmm4, [rsp+0x40]
00007d248dbdb493  vmovaps xmm5, [rsp+0x50]
00007d248dbdb499  vmovaps xmm6, [rsp+0x60]
00007d248dbdb49f  vmovaps xmm7, [rsp+0x70]
00007d248dbdb4a5  vmovaps xmm8, [rsp+0x80]
00007d248dbdb4ae  vmovaps xmm9, [rsp+0x90]
00007d248dbdb4b7  vmovaps xmm10, [rsp+0xA0]
00007d248dbdb4c0  vmovaps xmm11, [rsp+0xB0]
00007d248dbdb4c9  vmovaps xmm12, [rsp+0xC0]
00007d248dbdb4d2  vmovaps xmm13, [rsp+0xD0]
00007d248dbdb4db  vmovaps xmm14, [rsp+0xE0]
00007d248dbdb4e4  add rsp, 0xF0
00007d248dbdb4eb  pop r11
00007d248dbdb4ed  pop r10
00007d248dbdb4ef  pop r9
00007d248dbdb4f1  pop r8
00007d248dbdb4f3  pop rsi
00007d248dbdb4f4  pop rdi
00007d248dbdb4f5  pop rdx
00007d248dbdb4f6  pop rcx
00007d248dbdb4f7  pop rax
00007d248dbdb4f8  add rsp, 0x08
00007d248dbdb4fc  jmp 0x00007D248DBD664A
00007d248dbdb501  sub rsp, 0x08
00007d248dbdb505  push rax
00007d248dbdb506  push rcx
00007d248dbdb507  push rdx
00007d248dbdb508  push rdi
00007d248dbdb509  push rsi
00007d248dbdb50a  push r8
00007d248dbdb50c  push r9
00007d248dbdb50e  push r10
00007d248dbdb510  push r11
00007d248dbdb512  sub rsp, 0xF0
00007d248dbdb519  vmovaps [rsp], xmm0
00007d248dbdb51e  vmovaps [rsp+0x10], xmm1
00007d248dbdb524  vmovaps [rsp+0x20], xmm2
00007d248dbdb52a  vmovaps [rsp+0x30], xmm3
00007d248dbdb530  vmovaps [rsp+0x40], xmm4
00007d248dbdb536  vmovaps [rsp+0x50], xmm5
00007d248dbdb53c  vmovaps [rsp+0x60], xmm6
00007d248dbdb542  vmovaps [rsp+0x70], xmm7
00007d248dbdb548  vmovaps [rsp+0x80], xmm8
00007d248dbdb551  vmovaps [rsp+0x90], xmm9
00007d248dbdb55a  vmovaps [rsp+0xA0], xmm10
00007d248dbdb563  vmovaps [rsp+0xB0], xmm11
00007d248dbdb56c  vmovaps [rsp+0xC0], xmm12
00007d248dbdb575  vmovaps [rsp+0xD0], xmm14
00007d248dbdb57e  vmovaps [rsp+0xE0], xmm15
00007d248dbdb587  sub rsp, 0x30
00007d248dbdb58b  movaps [rsp], xmm13
00007d248dbdb590  movaps [rsp+0x10], xmm10
00007d248dbdb596  movaps [rsp+0x20], xmm14
00007d248dbdb59c  lea rdi, [rsp]
00007d248dbdb5a0  mov esi, 0x00
00007d248dbdb5a5  mov rax, 0x5BCEEF236530
00007d248dbdb5af  call rax
00007d248dbdb5b1  movaps xmm13, [rsp]
00007d248dbdb5b6  add rsp, 0x30
00007d248dbdb5ba  vmovaps xmm0, [rsp]
00007d248dbdb5bf  vmovaps xmm1, [rsp+0x10]
00007d248dbdb5c5  vmovaps xmm2, [rsp+0x20]
00007d248dbdb5cb  vmovaps xmm3, [rsp+0x30]
00007d248dbdb5d1  vmovaps xmm4, [rsp+0x40]
00007d248dbdb5d7  vmovaps xmm5, [rsp+0x50]
00007d248dbdb5dd  vmovaps xmm6, [rsp+0x60]
00007d248dbdb5e3  vmovaps xmm7, [rsp+0x70]
00007d248dbdb5e9  vmovaps xmm8, [rsp+0x80]
00007d248dbdb5f2  vmovaps xmm9, [rsp+0x90]
00007d248dbdb5fb  vmovaps xmm10, [rsp+0xA0]
00007d248dbdb604  vmovaps xmm11, [rsp+0xB0]
00007d248dbdb60d  vmovaps xmm12, [rsp+0xC0]
00007d248dbdb616  vmovaps xmm14, [rsp+0xD0]
00007d248dbdb61f  vmovaps xmm15, [rsp+0xE0]
00007d248dbdb628  add rsp, 0xF0
00007d248dbdb62f  pop r11
00007d248dbdb631  pop r10
00007d248dbdb633  pop r9
00007d248dbdb635  pop r8
00007d248dbdb637  pop rsi
00007d248dbdb638  pop rdi
00007d248dbdb639  pop rdx
00007d248dbdb63a  pop rcx
00007d248dbdb63b  pop rax
00007d248dbdb63c  add rsp, 0x08
00007d248dbdb640  jmp 0x00007D248DBD666D
00007d248dbdb645  sub rsp, 0x08
00007d248dbdb649  push rax
00007d248dbdb64a  push rcx
00007d248dbdb64b  push rdx
00007d248dbdb64c  push rdi
00007d248dbdb64d  push rsi
00007d248dbdb64e  push r8
00007d248dbdb650  push r9
00007d248dbdb652  push r10
00007d248dbdb654  push r11
00007d248dbdb656  sub rsp, 0xF0
00007d248dbdb65d  vmovaps [rsp], xmm0
00007d248dbdb662  vmovaps [rsp+0x10], xmm1
00007d248dbdb668  vmovaps [rsp+0x20], xmm2
00007d248dbdb66e  vmovaps [rsp+0x30], xmm3
00007d248dbdb674  vmovaps [rsp+0x40], xmm4
00007d248dbdb67a  vmovaps [rsp+0x50], xmm5
00007d248dbdb680  vmovaps [rsp+0x60], xmm6
00007d248dbdb686  vmovaps [rsp+0x70], xmm7
00007d248dbdb68c  vmovaps [rsp+0x80], xmm8
00007d248dbdb695  vmovaps [rsp+0x90], xmm9
00007d248dbdb69e  vmovaps [rsp+0xA0], xmm10
00007d248dbdb6a7  vmovaps [rsp+0xB0], xmm11
00007d248dbdb6b0  vmovaps [rsp+0xC0], xmm12
00007d248dbdb6b9  vmovaps [rsp+0xD0], xmm13
00007d248dbdb6c2  vmovaps [rsp+0xE0], xmm15
00007d248dbdb6cb  sub rsp, 0x30
00007d248dbdb6cf  movaps [rsp], xmm14
00007d248dbdb6d4  movaps [rsp+0x10], xmm1
00007d248dbdb6d9  movaps [rsp+0x20], xmm7
00007d248dbdb6de  lea rdi, [rsp]
00007d248dbdb6e2  mov esi, 0x00
00007d248dbdb6e7  mov rax, 0x5BCEEF236530
00007d248dbdb6f1  call rax
00007d248dbdb6f3  movaps xmm14, [rsp]
00007d248dbdb6f8  add rsp, 0x30
00007d248dbdb6fc  vmovaps xmm0, [rsp]
00007d248dbdb701  vmovaps xmm1, [rsp+0x10]
00007d248dbdb707  vmovaps xmm2, [rsp+0x20]
00007d248dbdb70d  vmovaps xmm3, [rsp+0x30]
00007d248dbdb713  vmovaps xmm4, [rsp+0x40]
00007d248dbdb719  vmovaps xmm5, [rsp+0x50]
00007d248dbdb71f  vmovaps xmm6, [rsp+0x60]
00007d248dbdb725  vmovaps xmm7, [rsp+0x70]
00007d248dbdb72b  vmovaps xmm8, [rsp+0x80]
00007d248dbdb734  vmovaps xmm9, [rsp+0x90]
00007d248dbdb73d  vmovaps xmm10, [rsp+0xA0]
00007d248dbdb746  vmovaps xmm11, [rsp+0xB0]
00007d248dbdb74f  vmovaps xmm12, [rsp+0xC0]
00007d248dbdb758  vmovaps xmm13, [rsp+0xD0]
00007d248dbdb761  vmovaps xmm15, [rsp+0xE0]
00007d248dbdb76a  add rsp, 0xF0
00007d248dbdb771  pop r11
00007d248dbdb773  pop r10
00007d248dbdb775  pop r9
00007d248dbdb777  pop r8
00007d248dbdb779  pop rsi
00007d248dbdb77a  pop rdi
00007d248dbdb77b  pop rdx
00007d248dbdb77c  pop rcx
00007d248dbdb77d  pop rax
00007d248dbdb77e  add rsp, 0x08
00007d248dbdb782  jmp 0x00007D248DBD6690
00007d248dbdb787  sub rsp, 0x08
00007d248dbdb78b  push rax
00007d248dbdb78c  push rcx
00007d248dbdb78d  push rdx
00007d248dbdb78e  push rdi
00007d248dbdb78f  push rsi
00007d248dbdb790  push r8
00007d248dbdb792  push r9
00007d248dbdb794  push r10
00007d248dbdb796  push r11
00007d248dbdb798  sub rsp, 0xF0
00007d248dbdb79f  vmovaps [rsp], xmm0
00007d248dbdb7a4  vmovaps [rsp+0x10], xmm2
00007d248dbdb7aa  vmovaps [rsp+0x20], xmm3
00007d248dbdb7b0  vmovaps [rsp+0x30], xmm4
00007d248dbdb7b6  vmovaps [rsp+0x40], xmm5
00007d248dbdb7bc  vmovaps [rsp+0x50], xmm6
00007d248dbdb7c2  vmovaps [rsp+0x60], xmm7
00007d248dbdb7c8  vmovaps [rsp+0x70], xmm8
00007d248dbdb7ce  vmovaps [rsp+0x80], xmm9
00007d248dbdb7d7  vmovaps [rsp+0x90], xmm10
00007d248dbdb7e0  vmovaps [rsp+0xA0], xmm11
00007d248dbdb7e9  vmovaps [rsp+0xB0], xmm12
00007d248dbdb7f2  vmovaps [rsp+0xC0], xmm13
00007d248dbdb7fb  vmovaps [rsp+0xD0], xmm14
00007d248dbdb804  vmovaps [rsp+0xE0], xmm15
00007d248dbdb80d  sub rsp, 0x30
00007d248dbdb811  movaps [rsp], xmm1
00007d248dbdb815  movaps [rsp+0x10], xmm8
00007d248dbdb81b  movaps [rsp+0x20], xmm9
00007d248dbdb821  lea rdi, [rsp]
00007d248dbdb825  mov esi, 0x00
00007d248dbdb82a  mov rax, 0x5BCEEF236530
00007d248dbdb834  call rax
00007d248dbdb836  movaps xmm1, [rsp]
00007d248dbdb83a  add rsp, 0x30
00007d248dbdb83e  vmovaps xmm0, [rsp]
00007d248dbdb843  vmovaps xmm2, [rsp+0x10]
00007d248dbdb849  vmovaps xmm3, [rsp+0x20]
00007d248dbdb84f  vmovaps xmm4, [rsp+0x30]
00007d248dbdb855  vmovaps xmm5, [rsp+0x40]
00007d248dbdb85b  vmovaps xmm6, [rsp+0x50]
00007d248dbdb861  vmovaps xmm7, [rsp+0x60]
00007d248dbdb867  vmovaps xmm8, [rsp+0x70]
00007d248dbdb86d  vmovaps xmm9, [rsp+0x80]
00007d248dbdb876  vmovaps xmm10, [rsp+0x90]
00007d248dbdb87f  vmovaps xmm11, [rsp+0xA0]
00007d248dbdb888  vmovaps xmm12, [rsp+0xB0]
00007d248dbdb891  vmovaps xmm13, [rsp+0xC0]
00007d248dbdb89a  vmovaps xmm14, [rsp+0xD0]
00007d248dbdb8a3  vmovaps xmm15, [rsp+0xE0]
00007d248dbdb8ac  add rsp, 0xF0
00007d248dbdb8b3  pop r11
00007d248dbdb8b5  pop r10
00007d248dbdb8b7  pop r9
00007d248dbdb8b9  pop r8
00007d248dbdb8bb  pop rsi
00007d248dbdb8bc  pop rdi
00007d248dbdb8bd  pop rdx
00007d248dbdb8be  pop rcx
00007d248dbdb8bf  pop rax
00007d248dbdb8c0  add rsp, 0x08
00007d248dbdb8c4  jmp 0x00007D248DBD66B2
00007d248dbdb8c9  call 0x00007D248DAB3E40
00007d248dbdb8ce  jmp 0x00007D248DBD66C0
00007d248dbdb8d3  call 0x00007D248DA0C380
00007d248dbdb8d8  jmp 0x00007D248DBD66CA
00007d248dbdb8dd  call 0x00007D248DA0D600
00007d248dbdb8e2  jmp 0x00007D248DBD66D4
00007d248dbdb8e7  call 0x00007D248D9FF540
00007d248dbdb8ec  jmp 0x00007D248DBD66DE
00007d248dbdb8f1  int3
00007d248dbdb8f2  nop [rax+rax*1], ax
00007d248dbdb8fb  nop [rax+rax*1], eax
00007d248dbdb900  mov eax, [r15+0x48]
00007d248dbdb904  lea r14d, [eax+0x01]
00007d248dbdb909  mov [rsp+0x10], r14d
00007d248dbdb90e  mov r14d, r14d
00007d248dbdb911  mov [r15+0x48], r14
00007d248dbdb915  xor eax, eax
00007d248dbdb917  mov r14d, [rsp+0x10]
00007d248dbdb91c  cmp r14d, 0x1F4
00007d248dbdb923  cmc
00007d248dbdb924  lahf
00007d248dbdb925  seto al
00007d248dbdb928  mov [r15+0x108], eax
00007d248dbdb92f  mov eax, [r15+0x108]
00007d248dbdb936  sahf
00007d248dbdb937  jnz 0x00007D248DBDB969
00007d248dbdb939  cmp dword ptr [r15+0x318], 0x00
00007d248dbdb941  jz 0x00007D248DBE1AB0
00007d248dbdb947  nop [rax+rax*1], ax
00007d248dbdb950  nop [rax+rax*1], eax
00007d248dbdb958  mov eax, 0x410450
00007d248dbdb95d  mov [r15+0x100], rax
00007d248dbdb964  jmp 0x00007D248D9FE110
00007d248dbdb969  cmp dword ptr [r15+0x318], 0x00
00007d248dbdb971  jz 0x00007D248DBDB9A0
00007d248dbdb977  nop [rax+rax*1], ax
00007d248dbdb980  nop [rax+rax*1], eax
00007d248dbdb988  mov eax, 0x410274
00007d248dbdb98d  mov [r15+0x100], rax
00007d248dbdb994  jmp 0x00007D248D9FE110
00007d248dbdb999  int3
00007d248dbdb99a  int3
00007d248dbdb99b  nop [rax+rax*1], eax
00007d248dbdb9a0  mov rax, [r15+0x40]
00007d248dbdb9a4  movaps xmm1, [r15+0x1D0]
00007d248dbdb9ac  vmovaps [rsp+0x10], xmm1
00007d248dbdb9b2  vmovaps xmm15, [rsp+0x10]
00007d248dbdb9b8  por xmm1, xmm15
00007d248dbdb9bd  movaps xmm14, [r15+0x1A0]
00007d248dbdb9c5  vmovaps [rsp+0x10], xmm14
00007d248dbdb9cb  vmovaps xmm13, [rsp+0x10]
00007d248dbdb9d1  por xmm14, xmm13
00007d248dbdb9d6  lea r14, [rax+0x30]
00007d248dbdb9da  mov r12, [r13+r14*1]
00007d248dbdb9df  lea r14, [rax+0x38]
00007d248dbdb9e3  mov r11, [r13+r14*1]
00007d248dbdb9e8  movq xmm13, r12
00007d248dbdb9ed  movq xmm12, r11
00007d248dbdb9f2  movq xmm13, xmm13
00007d248dbdb9f7  vmovaps [rsp+0x10], xmm13
00007d248dbdb9fd  movq xmm13, xmm13
00007d248dbdba02  movaps [r15+0x130], xmm13
00007d248dbdba0a  movq xmm12, xmm12
00007d248dbdba0f  vmovaps [rsp+0x20], xmm12
00007d248dbdba15  movq xmm12, xmm12
00007d248dbdba1a  movaps [r15+0x280], xmm12
00007d248dbdba22  movaps xmm13, [r15+0x270]
00007d248dbdba2a  vmovaps [rsp+0x30], xmm13
00007d248dbdba30  vmovaps xmm12, [rsp+0x30]
00007d248dbdba36  por xmm13, xmm12
00007d248dbdba3b  lea r14, [rax+0x20]
00007d248dbdba3f  mov r12, [r13+r14*1]
00007d248dbdba44  lea r14, [rax+0x28]
00007d248dbdba48  mov r11, [r13+r14*1]
00007d248dbdba4d  movq xmm12, r12
00007d248dbdba52  movq xmm11, r11
00007d248dbdba57  movq xmm12, xmm12
00007d248dbdba5c  vmovaps [rsp+0x30], xmm12
00007d248dbdba62  movq xmm12, xmm12
00007d248dbdba67  movaps [r15+0x150], xmm12
00007d248dbdba6f  movq xmm11, xmm11
00007d248dbdba74  vmovaps [rsp+0x40], xmm11
00007d248dbdba7a  movq xmm11, xmm11
00007d248dbdba7f  movaps [r15+0x140], xmm11
00007d248dbdba87  lea r14, [rax+0x10]
00007d248dbdba8b  mov r12, [r13+r14*1]
00007d248dbdba90  lea r14, [rax+0x18]
00007d248dbdba94  mov r11, [r13+r14*1]
00007d248dbdba99  movq xmm12, r12
00007d248dbdba9e  movq xmm11, r11
00007d248dbdbaa3  movq xmm12, xmm12
00007d248dbdbaa8  vmovaps [rsp+0x50], xmm12
00007d248dbdbaae  movq xmm12, xmm12
00007d248dbdbab3  movaps [r15+0x170], xmm12
00007d248dbdbabb  movq xmm11, xmm11
00007d248dbdbac0  vmovaps [rsp+0x60], xmm11
00007d248dbdbac6  movq xmm11, xmm11
00007d248dbdbacb  movaps [r15+0x160], xmm11
00007d248dbdbad3  mov r14, [r13+rax*1]
00007d248dbdbad8  vmovq xmm12, r14
00007d248dbdbadd  vpbroadcastq xmm12, xmm12
00007d248dbdbae2  lea r14, [rax+0x08]
00007d248dbdbae6  mov rax, [r13+r14*1]
00007d248dbdbaeb  movq xmm11, rax
00007d248dbdbaf0  movaps [r15+0x230], xmm11
00007d248dbdbaf8  mov rax, [r15+0xF8]
00007d248dbdbaff  lea r14, [rax+0x50]
00007d248dbdbb03  movups xmm11, [r13+r14*1]
00007d248dbdbb09  lea r14, [rax+0x60]
00007d248dbdbb0d  movups xmm10, [r13+r14*1]
00007d248dbdbb13  lea r14, [rax+0x30]
00007d248dbdbb17  movups xmm9, [r13+r14*1]
00007d248dbdbb1d  mov r14, [r15+0x50]
00007d248dbdbb21  mov [r15+0x60], r14
00007d248dbdbb25  mov qword ptr [r15+0x58], 0x40
00007d248dbdbb2d  movaps xmm8, xmm12
00007d248dbdbb31  mulpd xmm8, xmm15
00007d248dbdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007d248dbdbb3c  ptest xmm7, xmm7
00007d248dbdbb41  jnz 0x00007D248DBDC96A
00007d248dbdbb47  movq xmm15, qword ptr [r15+0x230]
00007d248dbdbb50  vmovaps [rsp+0x70], xmm15
00007d248dbdbb56  vpermilpd xmm15, xmm15, 0x00
00007d248dbdbb5c  movaps xmm7, xmm9
00007d248dbdbb60  mulpd xmm7, xmm15
00007d248dbdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007d248dbdbb6a  ptest xmm6, xmm6
00007d248dbdbb6f  jnz 0x00007D248DBDCAAE
00007d248dbdbb75  vxorps xmm15, xmm15, xmm15
00007d248dbdbb7a  vpbroadcastq xmm15, xmm15
00007d248dbdbb7f  movaps xmm9, xmm12
00007d248dbdbb83  mulpd xmm9, xmm10
00007d248dbdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007d248dbdbb8e  ptest xmm6, xmm6
00007d248dbdbb93  jnz 0x00007D248DBDCBF0
00007d248dbdbb99  movaps xmm10, xmm12
00007d248dbdbb9d  mulpd xmm10, xmm11
00007d248dbdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007d248dbdbba8  ptest xmm6, xmm6
00007d248dbdbbad  jnz 0x00007D248DBDCD34
00007d248dbdbbb3  movaps xmm11, [r15+0x1F0]
00007d248dbdbbbb  movaps xmm6, xmm12
00007d248dbdbbbf  mulpd xmm6, xmm11
00007d248dbdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007d248dbdbbc9  ptest xmm5, xmm5
00007d248dbdbbce  jnz 0x00007D248DBDCE78
00007d248dbdbbd4  movaps xmm12, [r15+0x2A0]
00007d248dbdbbdc  vmovaps [rsp+0x80], xmm12
00007d248dbdbbe5  vmovaps xmm11, [rsp+0x80]
00007d248dbdbbee  por xmm12, xmm11
00007d248dbdbbf3  movaps xmm11, [r15+0x250]
00007d248dbdbbfb  vmovaps [rsp+0x80], xmm11
00007d248dbdbc04  vmovaps xmm5, [rsp+0x80]
00007d248dbdbc0d  por xmm11, xmm5
00007d248dbdbc12  vmovaps xmm4, [rsp+0x70]
00007d248dbdbc18  vpermilpd xmm4, xmm4, 0x00
00007d248dbdbc1e  movaps xmm3, xmm5
00007d248dbdbc21  mulpd xmm3, xmm4
00007d248dbdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007d248dbdbc2a  ptest xmm2, xmm2
00007d248dbdbc2f  jnz 0x00007D248DBDCFBA
00007d248dbdbc35  mov [rsp+0x80], rax
00007d248dbdbc3d  xor eax, eax
00007d248dbdbc3f  mov r12d, 0x40
00007d248dbdbc45  mov r11d, 0x200
00007d248dbdbc4b  cmp r12, r11
00007d248dbdbc4e  cmc
00007d248dbdbc4f  lahf
00007d248dbdbc50  seto al
00007d248dbdbc53  mov [r15+0x108], eax
00007d248dbdbc5a  movaps xmm5, xmm8
00007d248dbdbc5e  addpd xmm5, xmm15
00007d248dbdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007d248dbdbc68  ptest xmm4, xmm4
00007d248dbdbc6d  jnz 0x00007D248DBDD0FA
00007d248dbdbc73  movaps xmm8, [r15+0x1B0]
00007d248dbdbc7b  movaps xmm4, xmm9
00007d248dbdbc7f  addpd xmm4, xmm8
00007d248dbdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007d248dbdbc89  ptest xmm2, xmm2
00007d248dbdbc8e  jnz 0x00007D248DBDD23C
00007d248dbdbc94  movaps xmm9, xmm10
00007d248dbdbc98  addpd xmm9, xmm8
00007d248dbdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007d248dbdbca3  ptest xmm2, xmm2
00007d248dbdbca8  jnz 0x00007D248DBDD37E
00007d248dbdbcae  movaps xmm10, [r15+0x2F0]
00007d248dbdbcb6  vmovaps [rsp+0x90], xmm10
00007d248dbdbcbf  vmovaps xmm8, [rsp+0x90]
00007d248dbdbcc8  por xmm10, xmm8
00007d248dbdbccd  movaps xmm8, [r15+0x2E0]
00007d248dbdbcd5  vmovaps [rsp+0x90], xmm8
00007d248dbdbcde  vmovaps xmm2, [rsp+0x90]
00007d248dbdbce7  por xmm8, xmm2
00007d248dbdbcec  movaps xmm2, [r15+0x2D0]
00007d248dbdbcf4  vmovaps [rsp+0x90], xmm2
00007d248dbdbcfd  vmovaps [rsp+0xA0], xmm1
00007d248dbdbd06  vmovaps xmm1, [rsp+0x90]
00007d248dbdbd0f  por xmm2, xmm1
00007d248dbdbd13  movaps xmm1, [r15+0x200]
00007d248dbdbd1b  vmovaps [rsp+0x90], xmm1
00007d248dbdbd24  vmovaps [rsp+0xB0], xmm15
00007d248dbdbd2d  vmovaps xmm15, [rsp+0x90]
00007d248dbdbd36  por xmm1, xmm15
00007d248dbdbd3b  movaps xmm15, [r15+0x1C0]
00007d248dbdbd43  vmovaps [rsp+0x90], xmm15
00007d248dbdbd4c  vmovaps [rsp+0xC0], xmm1
00007d248dbdbd55  vmovaps xmm1, [rsp+0x90]
00007d248dbdbd5e  por xmm15, xmm1
00007d248dbdbd63  movaps xmm1, [r15+0x190]
00007d248dbdbd6b  vmovaps [rsp+0x90], xmm1
00007d248dbdbd74  vmovaps [rsp+0xD0], xmm15
00007d248dbdbd7d  vmovaps xmm15, [rsp+0x90]
00007d248dbdbd86  por xmm1, xmm15
00007d248dbdbd8b  movaps xmm15, [r15+0x300]
00007d248dbdbd93  vmovaps [rsp+0x90], xmm15
00007d248dbdbd9c  vmovaps [rsp+0xE0], xmm1
00007d248dbdbda5  vmovaps xmm1, [rsp+0x90]
00007d248dbdbdae  por xmm15, xmm1
00007d248dbdbdb3  mov rax, [rsp+0x80]
00007d248dbdbdbb  lea r12, [rax+0xA0]
00007d248dbdbdc2  movups xmm1, [r13+r12*1]
00007d248dbdbdc8  lea r12, [rax+0xB0]
00007d248dbdbdcf  vmovaps [rsp+0x80], xmm1
00007d248dbdbdd8  movups xmm1, [r13+r12*1]
00007d248dbdbdde  vmovaps [rsp+0x90], xmm1
00007d248dbdbde7  vmovaps [rsp+0xF0], xmm15
00007d248dbdbdf0  vmovaps xmm15, [rsp+0xB0]
00007d248dbdbdf9  vmovaps [rsp+0xB0], xmm14
00007d248dbdbe02  movaps xmm1, xmm6
00007d248dbdbe05  addpd xmm1, xmm15
00007d248dbdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007d248dbdbe0f  ptest xmm14, xmm14
00007d248dbdbe15  jnz 0x00007D248DBDD4D6
00007d248dbdbe1b  lea r12, [rax+0xF0]
00007d248dbdbe22  movups xmm15, [r13+r12*1]
00007d248dbdbe28  movaps xmm14, xmm4
00007d248dbdbe2c  addpd xmm14, xmm3
00007d248dbdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007d248dbdbe37  ptest xmm6, xmm6
00007d248dbdbe3c  jnz 0x00007D248DBDD621
00007d248dbdbe42  movaps xmm6, xmm9
00007d248dbdbe46  addpd xmm6, xmm7
00007d248dbdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007d248dbdbe4f  ptest xmm4, xmm4
00007d248dbdbe54  jnz 0x00007D248DBDD763
00007d248dbdbe5a  vmovaps xmm9, [rsp+0x70]
00007d248dbdbe60  vpermilpd xmm9, xmm9, 0x00
00007d248dbdbe66  vmovaps xmm4, [rsp+0x90]
00007d248dbdbe6f  movaps xmm7, xmm4
00007d248dbdbe72  mulpd xmm7, xmm9
00007d248dbdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007d248dbdbe7c  ptest xmm3, xmm3
00007d248dbdbe81  jnz 0x00007D248DBDD8A4
00007d248dbdbe87  vmovaps xmm9, [rsp+0x50]
00007d248dbdbe8d  vpermilpd xmm9, xmm9, 0x00
00007d248dbdbe93  movaps xmm4, xmm15
00007d248dbdbe97  mulpd xmm4, xmm9
00007d248dbdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007d248dbdbea1  ptest xmm3, xmm3
00007d248dbdbea6  jnz 0x00007D248DBDD9E5
00007d248dbdbeac  lea r12, [rax+0xE0]
00007d248dbdbeb3  movups xmm15, [r13+r12*1]
00007d248dbdbeb9  vmovaps xmm9, [rsp+0x70]
00007d248dbdbebf  vpermilpd xmm9, xmm9, 0x00
00007d248dbdbec5  vmovaps [rsp+0x70], xmm1
00007d248dbdbecb  vmovaps xmm1, [rsp+0x80]
00007d248dbdbed4  vmovaps [rsp+0x80], xmm15
00007d248dbdbedd  movaps xmm3, xmm1
00007d248dbdbee0  mulpd xmm3, xmm9
00007d248dbdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007d248dbdbeea  ptest xmm15, xmm15
00007d248dbdbef0  jnz 0x00007D248DBDDB31
00007d248dbdbef6  vmovaps xmm1, [rsp+0xF0]
00007d248dbdbeff  vmovaps xmm15, [rsp+0xF0]
00007d248dbdbf08  por xmm1, xmm15
00007d248dbdbf0d  movaps [r15+0x300], xmm1
00007d248dbdbf15  vmovaps xmm15, [rsp+0xE0]
00007d248dbdbf1e  vmovaps xmm9, [rsp+0xE0]
00007d248dbdbf27  por xmm15, xmm9
00007d248dbdbf2c  movaps [r15+0x190], xmm15
00007d248dbdbf34  vmovaps xmm9, [rsp+0x50]
00007d248dbdbf3a  vpermilpd xmm9, xmm9, 0x00
00007d248dbdbf40  vmovaps [rsp+0x90], xmm1
00007d248dbdbf49  vmovaps [rsp+0xE0], xmm15
00007d248dbdbf52  vmovaps xmm15, [rsp+0x80]
00007d248dbdbf5b  vmovaps [rsp+0x80], xmm14
00007d248dbdbf64  movaps xmm1, xmm15
00007d248dbdbf68  mulpd xmm1, xmm9
00007d248dbdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007d248dbdbf72  ptest xmm14, xmm14
00007d248dbdbf78  jnz 0x00007D248DBDDC72
00007d248dbdbf7e  lea r12, [rax+0x90]
00007d248dbdbf85  movups xmm15, [r13+r12*1]
00007d248dbdbf8b  vmovaps xmm14, [rsp+0xD0]
00007d248dbdbf94  vmovaps xmm9, [rsp+0xD0]
00007d248dbdbf9d  por xmm14, xmm9
00007d248dbdbfa2  movaps [r15+0x1C0], xmm14
00007d248dbdbfaa  vmovaps xmm9, [rsp+0xC0]
00007d248dbdbfb3  vmovaps [rsp+0xD0], xmm1
00007d248dbdbfbc  vmovaps xmm1, [rsp+0xC0]
00007d248dbdbfc5  por xmm9, xmm1
00007d248dbdbfca  movaps [r15+0x200], xmm9
00007d248dbdbfd2  vmovaps [rsp+0xC0], xmm2
00007d248dbdbfdb  vmovaps xmm1, [rsp+0xC0]
00007d248dbdbfe4  por xmm2, xmm1
00007d248dbdbfe8  movaps [r15+0x2D0], xmm2
00007d248dbdbff0  vmovaps [rsp+0xC0], xmm8
00007d248dbdbff9  vmovaps xmm1, [rsp+0xC0]
00007d248dbdc002  por xmm8, xmm1
00007d248dbdc007  movaps [r15+0x2E0], xmm8
00007d248dbdc00f  vmovaps [rsp+0xC0], xmm15
00007d248dbdc018  movaps xmm1, xmm5
00007d248dbdc01b  addpd xmm1, xmm7
00007d248dbdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007d248dbdc024  ptest xmm15, xmm15
00007d248dbdc02a  jnz 0x00007D248DBDDDBE
00007d248dbdc030  vmovaps xmm15, [rsp+0x50]
00007d248dbdc036  vpermilpd xmm15, xmm15, 0x00
00007d248dbdc03c  vmovaps xmm5, [rsp+0xC0]
00007d248dbdc045  vmovaps [rsp+0xC0], xmm1
00007d248dbdc04e  movaps xmm7, xmm5
00007d248dbdc051  mulpd xmm7, xmm15
00007d248dbdc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007d248dbdc05b  ptest xmm1, xmm1
00007d248dbdc060  jnz 0x00007D248DBDDEFE
00007d248dbdc066  lea r12, [rax+0x80]
00007d248dbdc06d  movups xmm1, [r13+r12*1]
00007d248dbdc073  vmovaps xmm5, [rsp+0x70]
00007d248dbdc079  vmovaps [rsp+0x70], xmm1
00007d248dbdc07f  movaps xmm15, xmm5
00007d248dbdc083  addpd xmm15, xmm3
00007d248dbdc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007d248dbdc08e  ptest xmm1, xmm1
00007d248dbdc093  jnz 0x00007D248DBDE049
00007d248dbdc099  vmovaps xmm5, [rsp+0x80]
00007d248dbdc0a2  movaps xmm1, xmm5
00007d248dbdc0a5  addpd xmm1, xmm4
00007d248dbdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007d248dbdc0ae  ptest xmm3, xmm3
00007d248dbdc0b3  jnz 0x00007D248DBDE18B
00007d248dbdc0b9  vmovaps [rsp+0x80], xmm10
00007d248dbdc0c2  vmovaps xmm5, [rsp+0x80]
00007d248dbdc0cb  por xmm10, xmm5
00007d248dbdc0d0  movaps [r15+0x2F0], xmm10
00007d248dbdc0d8  vmovaps xmm5, [rsp+0x50]
00007d248dbdc0de  vpermilpd xmm5, xmm5, 0x00
00007d248dbdc0e4  vmovaps xmm3, [rsp+0x70]
00007d248dbdc0ea  vmovaps [rsp+0x50], xmm1
00007d248dbdc0f0  movaps xmm4, xmm3
00007d248dbdc0f3  mulpd xmm4, xmm5
00007d248dbdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007d248dbdc0fc  ptest xmm1, xmm1
00007d248dbdc101  jnz 0x00007D248DBDE2CB
00007d248dbdc107  lea r12, [rax+0xD0]
00007d248dbdc10e  movups xmm1, [r13+r12*1]
00007d248dbdc114  vmovaps xmm3, [rsp+0xD0]
00007d248dbdc11d  vmovaps [rsp+0x70], xmm1
00007d248dbdc123  movaps xmm5, xmm6
00007d248dbdc126  addpd xmm5, xmm3
00007d248dbdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007d248dbdc12f  ptest xmm1, xmm1
00007d248dbdc134  jnz 0x00007D248DBDE415
00007d248dbdc13a  vmovaps xmm1, [rsp+0x60]
00007d248dbdc140  vpermilpd xmm1, xmm1, 0x00
00007d248dbdc146  movaps xmm6, xmm9
00007d248dbdc14a  mulpd xmm6, xmm1
00007d248dbdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007d248dbdc153  ptest xmm3, xmm3
00007d248dbdc158  jnz 0x00007D248DBDE555
00007d248dbdc15e  movaps [r15+0x260], xmm6
00007d248dbdc166  vxorps xmm1, xmm1, xmm1
00007d248dbdc16a  vpbroadcastq xmm1, xmm1
00007d248dbdc16f  movaps [r15+0x1B0], xmm1
00007d248dbdc177  vmovaps xmm1, [rsp+0x60]
00007d248dbdc17d  vpermilpd xmm1, xmm1, 0x00
00007d248dbdc183  vmovaps xmm3, [rsp+0x70]
00007d248dbdc189  vmovaps [rsp+0x70], xmm15
00007d248dbdc18f  movaps xmm9, xmm3
00007d248dbdc193  mulpd xmm9, xmm1
00007d248dbdc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007d248dbdc19e  ptest xmm15, xmm15
00007d248dbdc1a4  jnz 0x00007D248DBDE696
00007d248dbdc1aa  lea r12, [rax+0xC0]
00007d248dbdc1b1  movups xmm1, [r13+r12*1]
00007d248dbdc1b7  vmovaps xmm3, [rsp+0xC0]
00007d248dbdc1c0  vmovaps [rsp+0x80], xmm1
00007d248dbdc1c9  movaps xmm15, xmm3
00007d248dbdc1cd  addpd xmm15, xmm7
00007d248dbdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007d248dbdc1d8  ptest xmm1, xmm1
00007d248dbdc1dd  jnz 0x00007D248DBDE7E2
00007d248dbdc1e3  vmovaps [rsp+0xC0], xmm13
00007d248dbdc1ec  vmovaps xmm1, [rsp+0xC0]
00007d248dbdc1f5  por xmm13, xmm1
00007d248dbdc1fa  movaps [r15+0x270], xmm13
00007d248dbdc202  vmovaps xmm1, [rsp+0xB0]
00007d248dbdc20b  vmovaps xmm7, [rsp+0xB0]
00007d248dbdc214  por xmm1, xmm7
00007d248dbdc218  movaps [r15+0x1A0], xmm1
00007d248dbdc220  vmovaps xmm1, [rsp+0x60]
00007d248dbdc226  vpermilpd xmm1, xmm1, 0x00
00007d248dbdc22c  vmovaps [rsp+0xB0], xmm1
00007d248dbdc235  vmovaps xmm1, [rsp+0x80]
00007d248dbdc23e  vmovaps [rsp+0x80], xmm15
00007d248dbdc247  vmovaps xmm15, [rsp+0xB0]
00007d248dbdc250  vmovaps [rsp+0xB0], xmm14
00007d248dbdc259  movaps xmm3, xmm1
00007d248dbdc25c  mulpd xmm3, xmm15
00007d248dbdc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007d248dbdc266  ptest xmm14, xmm14
00007d248dbdc26c  jnz 0x00007D248DBDE924
00007d248dbdc272  lea r12, [rax+0x20]
00007d248dbdc276  movups xmm1, [r13+r12*1]
00007d248dbdc27c  movaps [r15+0x110], xmm1
00007d248dbdc284  vmovaps xmm14, [rsp+0x70]
00007d248dbdc28a  vmovaps [rsp+0x70], xmm1
00007d248dbdc290  movaps xmm15, xmm14
00007d248dbdc294  addpd xmm15, xmm4
00007d248dbdc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007d248dbdc29f  ptest xmm1, xmm1
00007d248dbdc2a4  jnz 0x00007D248DBDEA6F
00007d248dbdc2aa  vmovaps xmm1, [rsp+0x60]
00007d248dbdc2b0  vpermilpd xmm1, xmm1, 0x00
00007d248dbdc2b6  movaps xmm14, xmm2
00007d248dbdc2ba  mulpd xmm14, xmm1
00007d248dbdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007d248dbdc2c5  ptest xmm4, xmm4
00007d248dbdc2ca  jnz 0x00007D248DBDEBB2
00007d248dbdc2d0  vmovaps xmm4, [rsp+0x50]
00007d248dbdc2d6  movaps xmm1, xmm4
00007d248dbdc2d9  addpd xmm1, xmm9
00007d248dbdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007d248dbdc2e3  ptest xmm2, xmm2
00007d248dbdc2e8  jnz 0x00007D248DBDECF4
00007d248dbdc2ee  vmovaps xmm9, [rsp+0x30]
00007d248dbdc2f4  vpermilpd xmm9, xmm9, 0x00
00007d248dbdc2fa  vmovaps xmm2, [rsp+0x70]
00007d248dbdc300  vmovaps [rsp+0x50], xmm1
00007d248dbdc306  movaps xmm4, xmm2
00007d248dbdc309  mulpd xmm4, xmm9
00007d248dbdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007d248dbdc313  ptest xmm1, xmm1
00007d248dbdc318  jnz 0x00007D248DBDEE35
00007d248dbdc31e  vmovaps xmm1, [rsp+0x30]
00007d248dbdc324  vpermilpd xmm1, xmm1, 0x00
00007d248dbdc32a  vmovaps xmm2, [rsp+0x90]
00007d248dbdc333  vmovaps [rsp+0x60], xmm15
00007d248dbdc339  movaps xmm9, xmm2
00007d248dbdc33d  mulpd xmm9, xmm1
00007d248dbdc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007d248dbdc348  ptest xmm15, xmm15
00007d248dbdc34e  jnz 0x00007D248DBDEF76
00007d248dbdc354  vmovaps xmm15, [rsp+0x80]
00007d248dbdc35d  movaps xmm1, xmm15
00007d248dbdc361  addpd xmm1, xmm6
00007d248dbdc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007d248dbdc36a  ptest xmm2, xmm2
00007d248dbdc36f  jnz 0x00007D248DBDF0B8
00007d248dbdc375  movaps xmm15, xmm5
00007d248dbdc379  addpd xmm15, xmm3
00007d248dbdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007d248dbdc384  ptest xmm6, xmm6
00007d248dbdc389  jnz 0x00007D248DBDF1F9
00007d248dbdc38f  vmovaps xmm6, [rsp+0x30]
00007d248dbdc395  vpermilpd xmm6, xmm6, 0x00
00007d248dbdc39b  movaps xmm5, xmm8
00007d248dbdc39f  mulpd xmm5, xmm6
00007d248dbdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007d248dbdc3a8  ptest xmm3, xmm3
00007d248dbdc3ad  jnz 0x00007D248DBDF33B
00007d248dbdc3b3  vmovaps xmm8, [rsp+0x30]
00007d248dbdc3b9  vpermilpd xmm8, xmm8, 0x00
00007d248dbdc3bf  movaps xmm6, xmm10
00007d248dbdc3c3  mulpd xmm6, xmm8
00007d248dbdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007d248dbdc3cd  ptest xmm3, xmm3
00007d248dbdc3d2  jnz 0x00007D248DBDF47C
00007d248dbdc3d8  vmovaps xmm8, [rsp+0x60]
00007d248dbdc3de  movaps xmm10, xmm8
00007d248dbdc3e2  addpd xmm10, xmm14
00007d248dbdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007d248dbdc3ed  ptest xmm3, xmm3
00007d248dbdc3f2  jnz 0x00007D248DBDF5BE
00007d248dbdc3f8  vmovaps xmm8, [rsp+0x50]
00007d248dbdc3fe  movaps xmm14, xmm8
00007d248dbdc402  addpd xmm14, xmm4
00007d248dbdc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007d248dbdc40d  ptest xmm3, xmm3
00007d248dbdc412  jnz 0x00007D248DBDF702
00007d248dbdc418  vmovaps xmm8, [rsp+0x40]
00007d248dbdc41e  vpermilpd xmm8, xmm8, 0x00
00007d248dbdc424  movaps xmm4, xmm13
00007d248dbdc428  mulpd xmm4, xmm8
00007d248dbdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007d248dbdc432  ptest xmm3, xmm3
00007d248dbdc437  jnz 0x00007D248DBDF845
00007d248dbdc43d  movaps xmm13, xmm15
00007d248dbdc441  addpd xmm13, xmm9
00007d248dbdc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007d248dbdc44c  ptest xmm8, xmm8
00007d248dbdc452  jnz 0x00007D248DBDF987
00007d248dbdc458  movaps xmm15, xmm1
00007d248dbdc45c  addpd xmm15, xmm5
00007d248dbdc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007d248dbdc467  ptest xmm9, xmm9
00007d248dbdc46d  jnz 0x00007D248DBDFACB
00007d248dbdc473  vmovaps [rsp+0x30], xmm11
00007d248dbdc479  vmovaps xmm1, [rsp+0x30]
00007d248dbdc47f  por xmm11, xmm1
00007d248dbdc484  movaps [r15+0x250], xmm11
00007d248dbdc48c  vmovaps [rsp+0x30], xmm12
00007d248dbdc492  vmovaps xmm1, [rsp+0x30]
00007d248dbdc498  por xmm12, xmm1
00007d248dbdc49d  movaps [r15+0x2A0], xmm12
00007d248dbdc4a5  vmovaps xmm1, [rsp+0xA0]
00007d248dbdc4ae  vmovaps xmm11, [rsp+0xA0]
00007d248dbdc4b7  por xmm1, xmm11
00007d248dbdc4bc  movaps [r15+0x1D0], xmm1
00007d248dbdc4c4  lea r12, [rax+0x40]
00007d248dbdc4c8  movups xmm1, [r13+r12*1]
00007d248dbdc4ce  movaps [r15+0x2C0], xmm1
00007d248dbdc4d6  vmovaps xmm11, [rsp+0x40]
00007d248dbdc4dc  vpermilpd xmm11, xmm11, 0x00
00007d248dbdc4e2  vmovaps xmm8, [rsp+0xE0]
00007d248dbdc4eb  movaps xmm9, xmm8
00007d248dbdc4ef  mulpd xmm9, xmm11
00007d248dbdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007d248dbdc4fa  ptest xmm5, xmm5
00007d248dbdc4ff  jnz 0x00007D248DBDFC17
00007d248dbdc505  movaps xmm11, xmm10
00007d248dbdc509  addpd xmm11, xmm6
00007d248dbdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007d248dbdc514  ptest xmm8, xmm8
00007d248dbdc51a  jnz 0x00007D248DBDFD5B
00007d248dbdc520  movaps xmm10, xmm14
00007d248dbdc524  addpd xmm10, xmm4
00007d248dbdc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007d248dbdc52f  ptest xmm8, xmm8
00007d248dbdc535  jnz 0x00007D248DBDFE9E
00007d248dbdc53b  vmovaps xmm14, [rsp+0x40]
00007d248dbdc541  vpermilpd xmm14, xmm14, 0x00
00007d248dbdc547  movaps xmm8, xmm1
00007d248dbdc54b  mulpd xmm8, xmm14
00007d248dbdc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007d248dbdc556  ptest xmm6, xmm6
00007d248dbdc55b  jnz 0x00007D248DBDFFE1
00007d248dbdc561  movaps xmm1, [r15+0x2B0]
00007d248dbdc569  vmovaps xmm14, [rsp+0x40]
00007d248dbdc56f  vpermilpd xmm14, xmm14, 0x00
00007d248dbdc575  movaps xmm6, xmm1
00007d248dbdc578  mulpd xmm6, xmm14
00007d248dbdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007d248dbdc582  ptest xmm5, xmm5
00007d248dbdc587  jnz 0x00007D248DBE0124
00007d248dbdc58d  vmovaps xmm1, [rsp+0x10]
00007d248dbdc593  vpermilpd xmm1, xmm1, 0x00
00007d248dbdc599  movaps xmm14, xmm12
00007d248dbdc59d  mulpd xmm14, xmm1
00007d248dbdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007d248dbdc5a8  ptest xmm5, xmm5
00007d248dbdc5ad  jnz 0x00007D248DBE0265
00007d248dbdc5b3  movaps xmm1, xmm13
00007d248dbdc5b7  addpd xmm1, xmm9
00007d248dbdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007d248dbdc5c1  ptest xmm12, xmm12
00007d248dbdc5c7  jnz 0x00007D248DBE03A8
00007d248dbdc5cd  vmovaps xmm13, [rsp+0x10]
00007d248dbdc5d3  vpermilpd xmm13, xmm13, 0x00
00007d248dbdc5d9  movaps xmm12, xmm7
00007d248dbdc5dd  mulpd xmm12, xmm13
00007d248dbdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007d248dbdc5e8  ptest xmm9, xmm9
00007d248dbdc5ee  jnz 0x00007D248DBE04EA
00007d248dbdc5f4  movaps xmm13, xmm15
00007d248dbdc5f8  addpd xmm13, xmm8
00007d248dbdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007d248dbdc603  ptest xmm9, xmm9
00007d248dbdc609  jnz 0x00007D248DBE062D
00007d248dbdc60f  movaps xmm15, [r15+0x290]
00007d248dbdc617  vmovaps xmm9, [rsp+0x10]
00007d248dbdc61d  vpermilpd xmm9, xmm9, 0x00
00007d248dbdc623  movaps xmm8, xmm15
00007d248dbdc627  mulpd xmm8, xmm9
00007d248dbdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007d248dbdc632  ptest xmm7, xmm7
00007d248dbdc637  jnz 0x00007D248DBE0771
00007d248dbdc63d  movaps xmm15, xmm11
00007d248dbdc641  addpd xmm15, xmm6
00007d248dbdc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007d248dbdc64c  ptest xmm9, xmm9
00007d248dbdc652  jnz 0x00007D248DBE08B5
00007d248dbdc658  movaps xmm11, [r15+0x1E0]
00007d248dbdc660  vmovaps xmm9, [rsp+0x10]
00007d248dbdc666  vpermilpd xmm9, xmm9, 0x00
00007d248dbdc66c  movaps xmm7, xmm11
00007d248dbdc670  mulpd xmm7, xmm9
00007d248dbdc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007d248dbdc67a  ptest xmm6, xmm6
00007d248dbdc67f  jnz 0x00007D248DBE09F8
00007d248dbdc685  movaps xmm11, xmm10
00007d248dbdc689  addpd xmm11, xmm14
00007d248dbdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007d248dbdc694  ptest xmm9, xmm9
00007d248dbdc69a  jnz 0x00007D248DBE0B3A
00007d248dbdc6a0  lea r12, [rax+0x70]
00007d248dbdc6a4  movups xmm14, [r13+r12*1]
00007d248dbdc6aa  movaps [r15+0x240], xmm14
00007d248dbdc6b2  movaps xmm10, xmm1
00007d248dbdc6b6  addpd xmm10, xmm12
00007d248dbdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007d248dbdc6c1  ptest xmm9, xmm9
00007d248dbdc6c7  jnz 0x00007D248DBE0C88
00007d248dbdc6cd  movaps [r15+0x170], xmm10
00007d248dbdc6d5  vmovaps xmm1, [rsp+0x20]
00007d248dbdc6db  vpermilpd xmm1, xmm1, 0x00
00007d248dbdc6e1  movaps xmm12, xmm14
00007d248dbdc6e5  mulpd xmm12, xmm1
00007d248dbdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007d248dbdc6f0  ptest xmm9, xmm9
00007d248dbdc6f6  jnz 0x00007D248DBE0DCB
00007d248dbdc6fc  vmovaps xmm1, [rsp+0x20]
00007d248dbdc702  vpermilpd xmm1, xmm1, 0x00
00007d248dbdc708  vmovaps xmm9, [rsp+0xB0]
00007d248dbdc711  movaps xmm14, xmm9
00007d248dbdc715  mulpd xmm14, xmm1
00007d248dbdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007d248dbdc720  ptest xmm6, xmm6
00007d248dbdc725  jnz 0x00007D248DBE0F0E
00007d248dbdc72b  movaps [r15+0x180], xmm14
00007d248dbdc733  movaps xmm1, xmm13
00007d248dbdc737  addpd xmm1, xmm8
00007d248dbdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007d248dbdc741  ptest xmm9, xmm9
00007d248dbdc747  jnz 0x00007D248DBE1051
00007d248dbdc74d  movaps [r15+0x210], xmm1
00007d248dbdc755  movups xmm13, [r13+rax*1]
00007d248dbdc75b  lea r12, [rax+0x10]
00007d248dbdc75f  movups xmm9, [r13+r12*1]
00007d248dbdc765  movaps [r15+0x230], xmm9
00007d248dbdc76d  movaps xmm8, xmm15
00007d248dbdc771  addpd xmm8, xmm7
00007d248dbdc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007d248dbdc77c  ptest xmm6, xmm6
00007d248dbdc781  jnz 0x00007D248DBE11A7
00007d248dbdc787  movaps [r15+0x130], xmm8
00007d248dbdc78f  vmovaps xmm15, [rsp+0x20]
00007d248dbdc795  vpermilpd xmm15, xmm15, 0x00
00007d248dbdc79b  movaps xmm7, xmm9
00007d248dbdc79f  mulpd xmm7, xmm15
00007d248dbdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007d248dbdc7a9  ptest xmm6, xmm6
00007d248dbdc7ae  jnz 0x00007D248DBE12EA
00007d248dbdc7b4  movaps [r15+0x220], xmm7
00007d248dbdc7bc  vmovaps xmm15, [rsp+0x20]
00007d248dbdc7c2  vpermilpd xmm15, xmm15, 0x00
00007d248dbdc7c8  movaps xmm9, xmm13
00007d248dbdc7cc  mulpd xmm9, xmm15
00007d248dbdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007d248dbdc7d7  ptest xmm6, xmm6
00007d248dbdc7dc  jnz 0x00007D248DBE142C
00007d248dbdc7e2  movaps xmm15, xmm11
00007d248dbdc7e6  addpd xmm15, xmm12
00007d248dbdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007d248dbdc7f1  ptest xmm13, xmm13
00007d248dbdc7f7  jnz 0x00007D248DBE1570
00007d248dbdc7fd  movaps [r15+0x140], xmm15
00007d248dbdc805  movaps xmm13, xmm10
00007d248dbdc809  addpd xmm13, xmm14
00007d248dbdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007d248dbdc814  ptest xmm12, xmm12
00007d248dbdc81a  jnz 0x00007D248DBE16B4
00007d248dbdc820  movaps [r15+0x150], xmm13
00007d248dbdc828  movaps xmm14, xmm1
00007d248dbdc82c  addpd xmm14, xmm7
00007d248dbdc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007d248dbdc837  ptest xmm12, xmm12
00007d248dbdc83d  jnz 0x00007D248DBE17F8
00007d248dbdc843  movaps [r15+0x160], xmm14
00007d248dbdc84b  movaps xmm1, xmm8
00007d248dbdc84f  addpd xmm1, xmm9
00007d248dbdc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007d248dbdc859  ptest xmm12, xmm12
00007d248dbdc85f  jnz 0x00007D248DBE193A
00007d248dbdc865  movaps [r15+0x120], xmm1
00007d248dbdc86d  movups [r13+r14*1], xmm15
00007d248dbdc873  lea rax, [r14+0x10]
00007d248dbdc877  movups [r13+rax*1], xmm13
00007d248dbdc87d  lea rax, [r14+0x20]
00007d248dbdc881  movups [r13+rax*1], xmm14
00007d248dbdc887  lea rax, [r14+0x30]
00007d248dbdc88b  movups [r13+rax*1], xmm1
00007d248dbdc891  mov eax, [r15+0x108]
00007d248dbdc898  sahf
00007d248dbdc899  jnz 0x00007D248DBDC8CB
00007d248dbdc89b  cmp dword ptr [r15+0x318], 0x00
00007d248dbdc8a3  jz 0x00007D248DBDB900
00007d248dbdc8a9  nop [rax+rax*1], ax
00007d248dbdc8b2  nop [rax+rax*1], eax
00007d248dbdc8ba  mov eax, 0x410444
00007d248dbdc8bf  mov [r15+0x100], rax
00007d248dbdc8c6  jmp 0x00007D248D9FE110
00007d248dbdc8cb  cmp dword ptr [r15+0x318], 0x00
00007d248dbdc8d3  jz 0x00007D248DBD57E0
00007d248dbdc8d9  nop [rax+rax*1], ax
00007d248dbdc8e2  nop [rax+rax*1], eax
00007d248dbdc8ea  mov eax, 0x410278
00007d248dbdc8ef  mov [r15+0x100], rax
00007d248dbdc8f6  jmp 0x00007D248D9FE110
00007d248dbdc8fb  int3
00007d248dbdc8fc  call 0x00007D248DAE27E0
00007d248dbdc901  jmp 0x00007D248DBDB9DF
00007d248dbdc906  call 0x00007D248DAE1570
00007d248dbdc90b  jmp 0x00007D248DBDB9E8
00007d248dbdc910  call 0x00007D248DAE27E0
00007d248dbdc915  jmp 0x00007D248DBDBA44
00007d248dbdc91a  call 0x00007D248DAE1570
00007d248dbdc91f  jmp 0x00007D248DBDBA4D
00007d248dbdc924  call 0x00007D248DAE27E0
00007d248dbdc929  jmp 0x00007D248DBDBA90
00007d248dbdc92e  call 0x00007D248DAE1570
00007d248dbdc933  jmp 0x00007D248DBDBA99
00007d248dbdc938  call 0x00007D248DA0DC20
00007d248dbdc93d  jmp 0x00007D248DBDBAD8
00007d248dbdc942  call 0x00007D248DAD59C0
00007d248dbdc947  jmp 0x00007D248DBDBAEB
00007d248dbdc94c  call 0x00007D248DAE0E30
00007d248dbdc951  jmp 0x00007D248DBDBB09
00007d248dbdc956  call 0x00007D248DADFBC0
00007d248dbdc95b  jmp 0x00007D248DBDBB13
00007d248dbdc960  call 0x00007D248DADE950
00007d248dbdc965  jmp 0x00007D248DBDBB1D
00007d248dbdc96a  sub rsp, 0x08
00007d248dbdc96e  push rax
00007d248dbdc96f  push rcx
00007d248dbdc970  push rdx
00007d248dbdc971  push rdi
00007d248dbdc972  push rsi
00007d248dbdc973  push r8
00007d248dbdc975  push r9
00007d248dbdc977  push r10
00007d248dbdc979  push r11
00007d248dbdc97b  sub rsp, 0xF0
00007d248dbdc982  vmovaps [rsp], xmm0
00007d248dbdc987  vmovaps [rsp+0x10], xmm1
00007d248dbdc98d  vmovaps [rsp+0x20], xmm2
00007d248dbdc993  vmovaps [rsp+0x30], xmm3
00007d248dbdc999  vmovaps [rsp+0x40], xmm4
00007d248dbdc99f  vmovaps [rsp+0x50], xmm5
00007d248dbdc9a5  vmovaps [rsp+0x60], xmm6
00007d248dbdc9ab  vmovaps [rsp+0x70], xmm7
00007d248dbdc9b1  vmovaps [rsp+0x80], xmm9
00007d248dbdc9ba  vmovaps [rsp+0x90], xmm10
00007d248dbdc9c3  vmovaps [rsp+0xA0], xmm11
00007d248dbdc9cc  vmovaps [rsp+0xB0], xmm12
00007d248dbdc9d5  vmovaps [rsp+0xC0], xmm13
00007d248dbdc9de  vmovaps [rsp+0xD0], xmm14
00007d248dbdc9e7  vmovaps [rsp+0xE0], xmm15
00007d248dbdc9f0  sub rsp, 0x30
00007d248dbdc9f4  movaps [rsp], xmm8
00007d248dbdc9f9  movaps [rsp+0x10], xmm12
00007d248dbdc9ff  movaps [rsp+0x20], xmm15
00007d248dbdca05  lea rdi, [rsp]
00007d248dbdca09  mov esi, 0x00
00007d248dbdca0e  mov rax, 0x5BCEEF236530
00007d248dbdca18  call rax
00007d248dbdca1a  movaps xmm8, [rsp]
00007d248dbdca1f  add rsp, 0x30
00007d248dbdca23  vmovaps xmm0, [rsp]
00007d248dbdca28  vmovaps xmm1, [rsp+0x10]
00007d248dbdca2e  vmovaps xmm2, [rsp+0x20]
00007d248dbdca34  vmovaps xmm3, [rsp+0x30]
00007d248dbdca3a  vmovaps xmm4, [rsp+0x40]
00007d248dbdca40  vmovaps xmm5, [rsp+0x50]
00007d248dbdca46  vmovaps xmm6, [rsp+0x60]
00007d248dbdca4c  vmovaps xmm7, [rsp+0x70]
00007d248dbdca52  vmovaps xmm9, [rsp+0x80]
00007d248dbdca5b  vmovaps xmm10, [rsp+0x90]
00007d248dbdca64  vmovaps xmm11, [rsp+0xA0]
00007d248dbdca6d  vmovaps xmm12, [rsp+0xB0]
00007d248dbdca76  vmovaps xmm13, [rsp+0xC0]
00007d248dbdca7f  vmovaps xmm14, [rsp+0xD0]
00007d248dbdca88  vmovaps xmm15, [rsp+0xE0]
00007d248dbdca91  add rsp, 0xF0
00007d248dbdca98  pop r11
00007d248dbdca9a  pop r10
00007d248dbdca9c  pop r9
00007d248dbdca9e  pop r8
00007d248dbdcaa0  pop rsi
00007d248dbdcaa1  pop rdi
00007d248dbdcaa2  pop rdx
00007d248dbdcaa3  pop rcx
00007d248dbdcaa4  pop rax
00007d248dbdcaa5  add rsp, 0x08
00007d248dbdcaa9  jmp 0x00007D248DBDBB47
00007d248dbdcaae  sub rsp, 0x08
00007d248dbdcab2  push rax
00007d248dbdcab3  push rcx
00007d248dbdcab4  push rdx
00007d248dbdcab5  push rdi
00007d248dbdcab6  push rsi
00007d248dbdcab7  push r8
00007d248dbdcab9  push r9
00007d248dbdcabb  push r10
00007d248dbdcabd  push r11
00007d248dbdcabf  sub rsp, 0xF0
00007d248dbdcac6  vmovaps [rsp], xmm0
00007d248dbdcacb  vmovaps [rsp+0x10], xmm1
00007d248dbdcad1  vmovaps [rsp+0x20], xmm2
00007d248dbdcad7  vmovaps [rsp+0x30], xmm3
00007d248dbdcadd  vmovaps [rsp+0x40], xmm4
00007d248dbdcae3  vmovaps [rsp+0x50], xmm5
00007d248dbdcae9  vmovaps [rsp+0x60], xmm6
00007d248dbdcaef  vmovaps [rsp+0x70], xmm8
00007d248dbdcaf5  vmovaps [rsp+0x80], xmm9
00007d248dbdcafe  vmovaps [rsp+0x90], xmm10
00007d248dbdcb07  vmovaps [rsp+0xA0], xmm11
00007d248dbdcb10  vmovaps [rsp+0xB0], xmm12
00007d248dbdcb19  vmovaps [rsp+0xC0], xmm13
00007d248dbdcb22  vmovaps [rsp+0xD0], xmm14
00007d248dbdcb2b  vmovaps [rsp+0xE0], xmm15
00007d248dbdcb34  sub rsp, 0x30
00007d248dbdcb38  movaps [rsp], xmm7
00007d248dbdcb3c  movaps [rsp+0x10], xmm9
00007d248dbdcb42  movaps [rsp+0x20], xmm15
00007d248dbdcb48  lea rdi, [rsp]
00007d248dbdcb4c  mov esi, 0x00
00007d248dbdcb51  mov rax, 0x5BCEEF236530
00007d248dbdcb5b  call rax
00007d248dbdcb5d  movaps xmm7, [rsp]
00007d248dbdcb61  add rsp, 0x30
00007d248dbdcb65  vmovaps xmm0, [rsp]
00007d248dbdcb6a  vmovaps xmm1, [rsp+0x10]
00007d248dbdcb70  vmovaps xmm2, [rsp+0x20]
00007d248dbdcb76  vmovaps xmm3, [rsp+0x30]
00007d248dbdcb7c  vmovaps xmm4, [rsp+0x40]
00007d248dbdcb82  vmovaps xmm5, [rsp+0x50]
00007d248dbdcb88  vmovaps xmm6, [rsp+0x60]
00007d248dbdcb8e  vmovaps xmm8, [rsp+0x70]
00007d248dbdcb94  vmovaps xmm9, [rsp+0x80]
00007d248dbdcb9d  vmovaps xmm10, [rsp+0x90]
00007d248dbdcba6  vmovaps xmm11, [rsp+0xA0]
00007d248dbdcbaf  vmovaps xmm12, [rsp+0xB0]
00007d248dbdcbb8  vmovaps xmm13, [rsp+0xC0]
00007d248dbdcbc1  vmovaps xmm14, [rsp+0xD0]
00007d248dbdcbca  vmovaps xmm15, [rsp+0xE0]
00007d248dbdcbd3  add rsp, 0xF0
00007d248dbdcbda  pop r11
00007d248dbdcbdc  pop r10
00007d248dbdcbde  pop r9
00007d248dbdcbe0  pop r8
00007d248dbdcbe2  pop rsi
00007d248dbdcbe3  pop rdi
00007d248dbdcbe4  pop rdx
00007d248dbdcbe5  pop rcx
00007d248dbdcbe6  pop rax
00007d248dbdcbe7  add rsp, 0x08
00007d248dbdcbeb  jmp 0x00007D248DBDBB75
00007d248dbdcbf0  sub rsp, 0x08
00007d248dbdcbf4  push rax
00007d248dbdcbf5  push rcx
00007d248dbdcbf6  push rdx
00007d248dbdcbf7  push rdi
00007d248dbdcbf8  push rsi
00007d248dbdcbf9  push r8
00007d248dbdcbfb  push r9
00007d248dbdcbfd  push r10
00007d248dbdcbff  push r11
00007d248dbdcc01  sub rsp, 0xF0
00007d248dbdcc08  vmovaps [rsp], xmm0
00007d248dbdcc0d  vmovaps [rsp+0x10], xmm1
00007d248dbdcc13  vmovaps [rsp+0x20], xmm2
00007d248dbdcc19  vmovaps [rsp+0x30], xmm3
00007d248dbdcc1f  vmovaps [rsp+0x40], xmm4
00007d248dbdcc25  vmovaps [rsp+0x50], xmm5
00007d248dbdcc2b  vmovaps [rsp+0x60], xmm6
00007d248dbdcc31  vmovaps [rsp+0x70], xmm7
00007d248dbdcc37  vmovaps [rsp+0x80], xmm8
00007d248dbdcc40  vmovaps [rsp+0x90], xmm10
00007d248dbdcc49  vmovaps [rsp+0xA0], xmm11
00007d248dbdcc52  vmovaps [rsp+0xB0], xmm12
00007d248dbdcc5b  vmovaps [rsp+0xC0], xmm13
00007d248dbdcc64  vmovaps [rsp+0xD0], xmm14
00007d248dbdcc6d  vmovaps [rsp+0xE0], xmm15
00007d248dbdcc76  sub rsp, 0x30
00007d248dbdcc7a  movaps [rsp], xmm9
00007d248dbdcc7f  movaps [rsp+0x10], xmm12
00007d248dbdcc85  movaps [rsp+0x20], xmm10
00007d248dbdcc8b  lea rdi, [rsp]
00007d248dbdcc8f  mov esi, 0x00
00007d248dbdcc94  mov rax, 0x5BCEEF236530
00007d248dbdcc9e  call rax
00007d248dbdcca0  movaps xmm9, [rsp]
00007d248dbdcca5  add rsp, 0x30
00007d248dbdcca9  vmovaps xmm0, [rsp]
00007d248dbdccae  vmovaps xmm1, [rsp+0x10]
00007d248dbdccb4  vmovaps xmm2, [rsp+0x20]
00007d248dbdccba  vmovaps xmm3, [rsp+0x30]
00007d248dbdccc0  vmovaps xmm4, [rsp+0x40]
00007d248dbdccc6  vmovaps xmm5, [rsp+0x50]
00007d248dbdcccc  vmovaps xmm6, [rsp+0x60]
00007d248dbdccd2  vmovaps xmm7, [rsp+0x70]
00007d248dbdccd8  vmovaps xmm8, [rsp+0x80]
00007d248dbdcce1  vmovaps xmm10, [rsp+0x90]
00007d248dbdccea  vmovaps xmm11, [rsp+0xA0]
00007d248dbdccf3  vmovaps xmm12, [rsp+0xB0]
00007d248dbdccfc  vmovaps xmm13, [rsp+0xC0]
00007d248dbdcd05  vmovaps xmm14, [rsp+0xD0]
00007d248dbdcd0e  vmovaps xmm15, [rsp+0xE0]
00007d248dbdcd17  add rsp, 0xF0
00007d248dbdcd1e  pop r11
00007d248dbdcd20  pop r10
00007d248dbdcd22  pop r9
00007d248dbdcd24  pop r8
00007d248dbdcd26  pop rsi
00007d248dbdcd27  pop rdi
00007d248dbdcd28  pop rdx
00007d248dbdcd29  pop rcx
00007d248dbdcd2a  pop rax
00007d248dbdcd2b  add rsp, 0x08
00007d248dbdcd2f  jmp 0x00007D248DBDBB99
00007d248dbdcd34  sub rsp, 0x08
00007d248dbdcd38  push rax
00007d248dbdcd39  push rcx
00007d248dbdcd3a  push rdx
00007d248dbdcd3b  push rdi
00007d248dbdcd3c  push rsi
00007d248dbdcd3d  push r8
00007d248dbdcd3f  push r9
00007d248dbdcd41  push r10
00007d248dbdcd43  push r11
00007d248dbdcd45  sub rsp, 0xF0
00007d248dbdcd4c  vmovaps [rsp], xmm0
00007d248dbdcd51  vmovaps [rsp+0x10], xmm1
00007d248dbdcd57  vmovaps [rsp+0x20], xmm2
00007d248dbdcd5d  vmovaps [rsp+0x30], xmm3
00007d248dbdcd63  vmovaps [rsp+0x40], xmm4
00007d248dbdcd69  vmovaps [rsp+0x50], xmm5
00007d248dbdcd6f  vmovaps [rsp+0x60], xmm6
00007d248dbdcd75  vmovaps [rsp+0x70], xmm7
00007d248dbdcd7b  vmovaps [rsp+0x80], xmm8
00007d248dbdcd84  vmovaps [rsp+0x90], xmm9
00007d248dbdcd8d  vmovaps [rsp+0xA0], xmm11
00007d248dbdcd96  vmovaps [rsp+0xB0], xmm12
00007d248dbdcd9f  vmovaps [rsp+0xC0], xmm13
00007d248dbdcda8  vmovaps [rsp+0xD0], xmm14
00007d248dbdcdb1  vmovaps [rsp+0xE0], xmm15
00007d248dbdcdba  sub rsp, 0x30
00007d248dbdcdbe  movaps [rsp], xmm10
00007d248dbdcdc3  movaps [rsp+0x10], xmm12
00007d248dbdcdc9  movaps [rsp+0x20], xmm11
00007d248dbdcdcf  lea rdi, [rsp]
00007d248dbdcdd3  mov esi, 0x00
00007d248dbdcdd8  mov rax, 0x5BCEEF236530
00007d248dbdcde2  call rax
00007d248dbdcde4  movaps xmm10, [rsp]
00007d248dbdcde9  add rsp, 0x30
00007d248dbdcded  vmovaps xmm0, [rsp]
00007d248dbdcdf2  vmovaps xmm1, [rsp+0x10]
00007d248dbdcdf8  vmovaps xmm2, [rsp+0x20]
00007d248dbdcdfe  vmovaps xmm3, [rsp+0x30]
00007d248dbdce04  vmovaps xmm4, [rsp+0x40]
00007d248dbdce0a  vmovaps xmm5, [rsp+0x50]
00007d248dbdce10  vmovaps xmm6, [rsp+0x60]
00007d248dbdce16  vmovaps xmm7, [rsp+0x70]
00007d248dbdce1c  vmovaps xmm8, [rsp+0x80]
00007d248dbdce25  vmovaps xmm9, [rsp+0x90]
00007d248dbdce2e  vmovaps xmm11, [rsp+0xA0]
00007d248dbdce37  vmovaps xmm12, [rsp+0xB0]
00007d248dbdce40  vmovaps xmm13, [rsp+0xC0]
00007d248dbdce49  vmovaps xmm14, [rsp+0xD0]
00007d248dbdce52  vmovaps xmm15, [rsp+0xE0]
00007d248dbdce5b  add rsp, 0xF0
00007d248dbdce62  pop r11
00007d248dbdce64  pop r10
00007d248dbdce66  pop r9
00007d248dbdce68  pop r8
00007d248dbdce6a  pop rsi
00007d248dbdce6b  pop rdi
00007d248dbdce6c  pop rdx
00007d248dbdce6d  pop rcx
00007d248dbdce6e  pop rax
00007d248dbdce6f  add rsp, 0x08
00007d248dbdce73  jmp 0x00007D248DBDBBB3
00007d248dbdce78  sub rsp, 0x08
00007d248dbdce7c  push rax
00007d248dbdce7d  push rcx
00007d248dbdce7e  push rdx
00007d248dbdce7f  push rdi
00007d248dbdce80  push rsi
00007d248dbdce81  push r8
00007d248dbdce83  push r9
00007d248dbdce85  push r10
00007d248dbdce87  push r11
00007d248dbdce89  sub rsp, 0xF0
00007d248dbdce90  vmovaps [rsp], xmm0
00007d248dbdce95  vmovaps [rsp+0x10], xmm1
00007d248dbdce9b  vmovaps [rsp+0x20], xmm2
00007d248dbdcea1  vmovaps [rsp+0x30], xmm3
00007d248dbdcea7  vmovaps [rsp+0x40], xmm4
00007d248dbdcead  vmovaps [rsp+0x50], xmm5
00007d248dbdceb3  vmovaps [rsp+0x60], xmm7
00007d248dbdceb9  vmovaps [rsp+0x70], xmm8
00007d248dbdcebf  vmovaps [rsp+0x80], xmm9
00007d248dbdcec8  vmovaps [rsp+0x90], xmm10
00007d248dbdced1  vmovaps [rsp+0xA0], xmm11
00007d248dbdceda  vmovaps [rsp+0xB0], xmm12
00007d248dbdcee3  vmovaps [rsp+0xC0], xmm13
00007d248dbdceec  vmovaps [rsp+0xD0], xmm14
00007d248dbdcef5  vmovaps [rsp+0xE0], xmm15
00007d248dbdcefe  sub rsp, 0x30
00007d248dbdcf02  movaps [rsp], xmm6
00007d248dbdcf06  movaps [rsp+0x10], xmm12
00007d248dbdcf0c  movaps [rsp+0x20], xmm11
00007d248dbdcf12  lea rdi, [rsp]
00007d248dbdcf16  mov esi, 0x00
00007d248dbdcf1b  mov rax, 0x5BCEEF236530
00007d248dbdcf25  call rax
00007d248dbdcf27  movaps xmm6, [rsp]
00007d248dbdcf2b  add rsp, 0x30
00007d248dbdcf2f  vmovaps xmm0, [rsp]
00007d248dbdcf34  vmovaps xmm1, [rsp+0x10]
00007d248dbdcf3a  vmovaps xmm2, [rsp+0x20]
00007d248dbdcf40  vmovaps xmm3, [rsp+0x30]
00007d248dbdcf46  vmovaps xmm4, [rsp+0x40]
00007d248dbdcf4c  vmovaps xmm5, [rsp+0x50]
00007d248dbdcf52  vmovaps xmm7, [rsp+0x60]
00007d248dbdcf58  vmovaps xmm8, [rsp+0x70]
00007d248dbdcf5e  vmovaps xmm9, [rsp+0x80]
00007d248dbdcf67  vmovaps xmm10, [rsp+0x90]
00007d248dbdcf70  vmovaps xmm11, [rsp+0xA0]
00007d248dbdcf79  vmovaps xmm12, [rsp+0xB0]
00007d248dbdcf82  vmovaps xmm13, [rsp+0xC0]
00007d248dbdcf8b  vmovaps xmm14, [rsp+0xD0]
00007d248dbdcf94  vmovaps xmm15, [rsp+0xE0]
00007d248dbdcf9d  add rsp, 0xF0
00007d248dbdcfa4  pop r11
00007d248dbdcfa6  pop r10
00007d248dbdcfa8  pop r9
00007d248dbdcfaa  pop r8
00007d248dbdcfac  pop rsi
00007d248dbdcfad  pop rdi
00007d248dbdcfae  pop rdx
00007d248dbdcfaf  pop rcx
00007d248dbdcfb0  pop rax
00007d248dbdcfb1  add rsp, 0x08
00007d248dbdcfb5  jmp 0x00007D248DBDBBD4
00007d248dbdcfba  sub rsp, 0x08
00007d248dbdcfbe  push rax
00007d248dbdcfbf  push rcx
00007d248dbdcfc0  push rdx
00007d248dbdcfc1  push rdi
00007d248dbdcfc2  push rsi
00007d248dbdcfc3  push r8
00007d248dbdcfc5  push r9
00007d248dbdcfc7  push r10
00007d248dbdcfc9  push r11
00007d248dbdcfcb  sub rsp, 0xF0
00007d248dbdcfd2  vmovaps [rsp], xmm0
00007d248dbdcfd7  vmovaps [rsp+0x10], xmm1
00007d248dbdcfdd  vmovaps [rsp+0x20], xmm2
00007d248dbdcfe3  vmovaps [rsp+0x30], xmm4
00007d248dbdcfe9  vmovaps [rsp+0x40], xmm5
00007d248dbdcfef  vmovaps [rsp+0x50], xmm6
00007d248dbdcff5  vmovaps [rsp+0x60], xmm7
00007d248dbdcffb  vmovaps [rsp+0x70], xmm8
00007d248dbdd001  vmovaps [rsp+0x80], xmm9
00007d248dbdd00a  vmovaps [rsp+0x90], xmm10
00007d248dbdd013  vmovaps [rsp+0xA0], xmm11
00007d248dbdd01c  vmovaps [rsp+0xB0], xmm12
00007d248dbdd025  vmovaps [rsp+0xC0], xmm13
00007d248dbdd02e  vmovaps [rsp+0xD0], xmm14
00007d248dbdd037  vmovaps [rsp+0xE0], xmm15
00007d248dbdd040  sub rsp, 0x30
00007d248dbdd044  movaps [rsp], xmm3
00007d248dbdd048  movaps [rsp+0x10], xmm5
00007d248dbdd04d  movaps [rsp+0x20], xmm4
00007d248dbdd052  lea rdi, [rsp]
00007d248dbdd056  mov esi, 0x00
00007d248dbdd05b  mov rax, 0x5BCEEF236530
00007d248dbdd065  call rax
00007d248dbdd067  movaps xmm3, [rsp]
00007d248dbdd06b  add rsp, 0x30
00007d248dbdd06f  vmovaps xmm0, [rsp]
00007d248dbdd074  vmovaps xmm1, [rsp+0x10]
00007d248dbdd07a  vmovaps xmm2, [rsp+0x20]
00007d248dbdd080  vmovaps xmm4, [rsp+0x30]
00007d248dbdd086  vmovaps xmm5, [rsp+0x40]
00007d248dbdd08c  vmovaps xmm6, [rsp+0x50]
00007d248dbdd092  vmovaps xmm7, [rsp+0x60]
00007d248dbdd098  vmovaps xmm8, [rsp+0x70]
00007d248dbdd09e  vmovaps xmm9, [rsp+0x80]
00007d248dbdd0a7  vmovaps xmm10, [rsp+0x90]
00007d248dbdd0b0  vmovaps xmm11, [rsp+0xA0]
00007d248dbdd0b9  vmovaps xmm12, [rsp+0xB0]
00007d248dbdd0c2  vmovaps xmm13, [rsp+0xC0]
00007d248dbdd0cb  vmovaps xmm14, [rsp+0xD0]
00007d248dbdd0d4  vmovaps xmm15, [rsp+0xE0]
00007d248dbdd0dd  add rsp, 0xF0
00007d248dbdd0e4  pop r11
00007d248dbdd0e6  pop r10
00007d248dbdd0e8  pop r9
00007d248dbdd0ea  pop r8
00007d248dbdd0ec  pop rsi
00007d248dbdd0ed  pop rdi
00007d248dbdd0ee  pop rdx
00007d248dbdd0ef  pop rcx
00007d248dbdd0f0  pop rax
00007d248dbdd0f1  add rsp, 0x08
00007d248dbdd0f5  jmp 0x00007D248DBDBC35
00007d248dbdd0fa  sub rsp, 0x08
00007d248dbdd0fe  push rax
00007d248dbdd0ff  push rcx
00007d248dbdd100  push rdx
00007d248dbdd101  push rdi
00007d248dbdd102  push rsi
00007d248dbdd103  push r8
00007d248dbdd105  push r9
00007d248dbdd107  push r10
00007d248dbdd109  push r11
00007d248dbdd10b  sub rsp, 0xF0
00007d248dbdd112  vmovaps [rsp], xmm0
00007d248dbdd117  vmovaps [rsp+0x10], xmm1
00007d248dbdd11d  vmovaps [rsp+0x20], xmm2
00007d248dbdd123  vmovaps [rsp+0x30], xmm3
00007d248dbdd129  vmovaps [rsp+0x40], xmm4
00007d248dbdd12f  vmovaps [rsp+0x50], xmm6
00007d248dbdd135  vmovaps [rsp+0x60], xmm7
00007d248dbdd13b  vmovaps [rsp+0x70], xmm8
00007d248dbdd141  vmovaps [rsp+0x80], xmm9
00007d248dbdd14a  vmovaps [rsp+0x90], xmm10
00007d248dbdd153  vmovaps [rsp+0xA0], xmm11
00007d248dbdd15c  vmovaps [rsp+0xB0], xmm12
00007d248dbdd165  vmovaps [rsp+0xC0], xmm13
00007d248dbdd16e  vmovaps [rsp+0xD0], xmm14
00007d248dbdd177  vmovaps [rsp+0xE0], xmm15
00007d248dbdd180  sub rsp, 0x30
00007d248dbdd184  movaps [rsp], xmm5
00007d248dbdd188  movaps [rsp+0x10], xmm8
00007d248dbdd18e  movaps [rsp+0x20], xmm15
00007d248dbdd194  lea rdi, [rsp]
00007d248dbdd198  mov esi, 0x00
00007d248dbdd19d  mov rax, 0x5BCEEF236530
00007d248dbdd1a7  call rax
00007d248dbdd1a9  movaps xmm5, [rsp]
00007d248dbdd1ad  add rsp, 0x30
00007d248dbdd1b1  vmovaps xmm0, [rsp]
00007d248dbdd1b6  vmovaps xmm1, [rsp+0x10]
00007d248dbdd1bc  vmovaps xmm2, [rsp+0x20]
00007d248dbdd1c2  vmovaps xmm3, [rsp+0x30]
00007d248dbdd1c8  vmovaps xmm4, [rsp+0x40]
00007d248dbdd1ce  vmovaps xmm6, [rsp+0x50]
00007d248dbdd1d4  vmovaps xmm7, [rsp+0x60]
00007d248dbdd1da  vmovaps xmm8, [rsp+0x70]
00007d248dbdd1e0  vmovaps xmm9, [rsp+0x80]
00007d248dbdd1e9  vmovaps xmm10, [rsp+0x90]
00007d248dbdd1f2  vmovaps xmm11, [rsp+0xA0]
00007d248dbdd1fb  vmovaps xmm12, [rsp+0xB0]
00007d248dbdd204  vmovaps xmm13, [rsp+0xC0]
00007d248dbdd20d  vmovaps xmm14, [rsp+0xD0]
00007d248dbdd216  vmovaps xmm15, [rsp+0xE0]
00007d248dbdd21f  add rsp, 0xF0
00007d248dbdd226  pop r11
00007d248dbdd228  pop r10
00007d248dbdd22a  pop r9
00007d248dbdd22c  pop r8
00007d248dbdd22e  pop rsi
00007d248dbdd22f  pop rdi
00007d248dbdd230  pop rdx
00007d248dbdd231  pop rcx
00007d248dbdd232  pop rax
00007d248dbdd233  add rsp, 0x08
00007d248dbdd237  jmp 0x00007D248DBDBC73
00007d248dbdd23c  sub rsp, 0x08
00007d248dbdd240  push rax
00007d248dbdd241  push rcx
00007d248dbdd242  push rdx
00007d248dbdd243  push rdi
00007d248dbdd244  push rsi
00007d248dbdd245  push r8
00007d248dbdd247  push r9
00007d248dbdd249  push r10
00007d248dbdd24b  push r11
00007d248dbdd24d  sub rsp, 0xF0
00007d248dbdd254  vmovaps [rsp], xmm0
00007d248dbdd259  vmovaps [rsp+0x10], xmm1
00007d248dbdd25f  vmovaps [rsp+0x20], xmm2
00007d248dbdd265  vmovaps [rsp+0x30], xmm3
00007d248dbdd26b  vmovaps [rsp+0x40], xmm5
00007d248dbdd271  vmovaps [rsp+0x50], xmm6
00007d248dbdd277  vmovaps [rsp+0x60], xmm7
00007d248dbdd27d  vmovaps [rsp+0x70], xmm8
00007d248dbdd283  vmovaps [rsp+0x80], xmm9
00007d248dbdd28c  vmovaps [rsp+0x90], xmm10
00007d248dbdd295  vmovaps [rsp+0xA0], xmm11
00007d248dbdd29e  vmovaps [rsp+0xB0], xmm12
00007d248dbdd2a7  vmovaps [rsp+0xC0], xmm13
00007d248dbdd2b0  vmovaps [rsp+0xD0], xmm14
00007d248dbdd2b9  vmovaps [rsp+0xE0], xmm15
00007d248dbdd2c2  sub rsp, 0x30
00007d248dbdd2c6  movaps [rsp], xmm4
00007d248dbdd2ca  movaps [rsp+0x10], xmm9
00007d248dbdd2d0  movaps [rsp+0x20], xmm8
00007d248dbdd2d6  lea rdi, [rsp]
00007d248dbdd2da  mov esi, 0x00
00007d248dbdd2df  mov rax, 0x5BCEEF236530
00007d248dbdd2e9  call rax
00007d248dbdd2eb  movaps xmm4, [rsp]
00007d248dbdd2ef  add rsp, 0x30
00007d248dbdd2f3  vmovaps xmm0, [rsp]
00007d248dbdd2f8  vmovaps xmm1, [rsp+0x10]
00007d248dbdd2fe  vmovaps xmm2, [rsp+0x20]
00007d248dbdd304  vmovaps xmm3, [rsp+0x30]
00007d248dbdd30a  vmovaps xmm5, [rsp+0x40]
00007d248dbdd310  vmovaps xmm6, [rsp+0x50]
00007d248dbdd316  vmovaps xmm7, [rsp+0x60]
00007d248dbdd31c  vmovaps xmm8, [rsp+0x70]
00007d248dbdd322  vmovaps xmm9, [rsp+0x80]
00007d248dbdd32b  vmovaps xmm10, [rsp+0x90]
00007d248dbdd334  vmovaps xmm11, [rsp+0xA0]
00007d248dbdd33d  vmovaps xmm12, [rsp+0xB0]
00007d248dbdd346  vmovaps xmm13, [rsp+0xC0]
00007d248dbdd34f  vmovaps xmm14, [rsp+0xD0]
00007d248dbdd358  vmovaps xmm15, [rsp+0xE0]
00007d248dbdd361  add rsp, 0xF0
00007d248dbdd368  pop r11
00007d248dbdd36a  pop r10
00007d248dbdd36c  pop r9
00007d248dbdd36e  pop r8
00007d248dbdd370  pop rsi
00007d248dbdd371  pop rdi
00007d248dbdd372  pop rdx
00007d248dbdd373  pop rcx
00007d248dbdd374  pop rax
00007d248dbdd375  add rsp, 0x08
00007d248dbdd379  jmp 0x00007D248DBDBC94
00007d248dbdd37e  sub rsp, 0x08
00007d248dbdd382  push rax
00007d248dbdd383  push rcx
00007d248dbdd384  push rdx
00007d248dbdd385  push rdi
00007d248dbdd386  push rsi
00007d248dbdd387  push r8
00007d248dbdd389  push r9
00007d248dbdd38b  push r10
00007d248dbdd38d  push r11
00007d248dbdd38f  sub rsp, 0xF0
00007d248dbdd396  vmovaps [rsp], xmm0
00007d248dbdd39b  vmovaps [rsp+0x10], xmm1
00007d248dbdd3a1  vmovaps [rsp+0x20], xmm2
00007d248dbdd3a7  vmovaps [rsp+0x30], xmm3
00007d248dbdd3ad  vmovaps [rsp+0x40], xmm4
00007d248dbdd3b3  vmovaps [rsp+0x50], xmm5
00007d248dbdd3b9  vmovaps [rsp+0x60], xmm6
00007d248dbdd3bf  vmovaps [rsp+0x70], xmm7
00007d248dbdd3c5  vmovaps [rsp+0x80], xmm8
00007d248dbdd3ce  vmovaps [rsp+0x90], xmm10
00007d248dbdd3d7  vmovaps [rsp+0xA0], xmm11
00007d248dbdd3e0  vmovaps [rsp+0xB0], xmm12
00007d248dbdd3e9  vmovaps [rsp+0xC0], xmm13
00007d248dbdd3f2  vmovaps [rsp+0xD0], xmm14
00007d248dbdd3fb  vmovaps [rsp+0xE0], xmm15
00007d248dbdd404  sub rsp, 0x30
00007d248dbdd408  movaps [rsp], xmm9
00007d248dbdd40d  movaps [rsp+0x10], xmm10
00007d248dbdd413  movaps [rsp+0x20], xmm8
00007d248dbdd419  lea rdi, [rsp]
00007d248dbdd41d  mov esi, 0x00
00007d248dbdd422  mov rax, 0x5BCEEF236530
00007d248dbdd42c  call rax
00007d248dbdd42e  movaps xmm9, [rsp]
00007d248dbdd433  add rsp, 0x30
00007d248dbdd437  vmovaps xmm0, [rsp]
00007d248dbdd43c  vmovaps xmm1, [rsp+0x10]
00007d248dbdd442  vmovaps xmm2, [rsp+0x20]
00007d248dbdd448  vmovaps xmm3, [rsp+0x30]
00007d248dbdd44e  vmovaps xmm4, [rsp+0x40]
00007d248dbdd454  vmovaps xmm5, [rsp+0x50]
00007d248dbdd45a  vmovaps xmm6, [rsp+0x60]
00007d248dbdd460  vmovaps xmm7, [rsp+0x70]
00007d248dbdd466  vmovaps xmm8, [rsp+0x80]
00007d248dbdd46f  vmovaps xmm10, [rsp+0x90]
00007d248dbdd478  vmovaps xmm11, [rsp+0xA0]
00007d248dbdd481  vmovaps xmm12, [rsp+0xB0]
00007d248dbdd48a  vmovaps xmm13, [rsp+0xC0]
00007d248dbdd493  vmovaps xmm14, [rsp+0xD0]
00007d248dbdd49c  vmovaps xmm15, [rsp+0xE0]
00007d248dbdd4a5  add rsp, 0xF0
00007d248dbdd4ac  pop r11
00007d248dbdd4ae  pop r10
00007d248dbdd4b0  pop r9
00007d248dbdd4b2  pop r8
00007d248dbdd4b4  pop rsi
00007d248dbdd4b5  pop rdi
00007d248dbdd4b6  pop rdx
00007d248dbdd4b7  pop rcx
00007d248dbdd4b8  pop rax
00007d248dbdd4b9  add rsp, 0x08
00007d248dbdd4bd  jmp 0x00007D248DBDBCAE
00007d248dbdd4c2  call 0x00007D248DAB52F0
00007d248dbdd4c7  jmp 0x00007D248DBDBDC8
00007d248dbdd4cc  call 0x00007D248DAB52F0
00007d248dbdd4d1  jmp 0x00007D248DBDBDDE
00007d248dbdd4d6  sub rsp, 0x08
00007d248dbdd4da  push rax
00007d248dbdd4db  push rcx
00007d248dbdd4dc  push rdx
00007d248dbdd4dd  push rdi
00007d248dbdd4de  push rsi
00007d248dbdd4df  push r8
00007d248dbdd4e1  push r9
00007d248dbdd4e3  push r10
00007d248dbdd4e5  push r11
00007d248dbdd4e7  sub rsp, 0xF0
00007d248dbdd4ee  vmovaps [rsp], xmm0
00007d248dbdd4f3  vmovaps [rsp+0x10], xmm2
00007d248dbdd4f9  vmovaps [rsp+0x20], xmm3
00007d248dbdd4ff  vmovaps [rsp+0x30], xmm4
00007d248dbdd505  vmovaps [rsp+0x40], xmm5
00007d248dbdd50b  vmovaps [rsp+0x50], xmm6
00007d248dbdd511  vmovaps [rsp+0x60], xmm7
00007d248dbdd517  vmovaps [rsp+0x70], xmm8
00007d248dbdd51d  vmovaps [rsp+0x80], xmm9
00007d248dbdd526  vmovaps [rsp+0x90], xmm10
00007d248dbdd52f  vmovaps [rsp+0xA0], xmm11
00007d248dbdd538  vmovaps [rsp+0xB0], xmm12
00007d248dbdd541  vmovaps [rsp+0xC0], xmm13
00007d248dbdd54a  vmovaps [rsp+0xD0], xmm14
00007d248dbdd553  vmovaps [rsp+0xE0], xmm15
00007d248dbdd55c  sub rsp, 0x30
00007d248dbdd560  movaps [rsp], xmm1
00007d248dbdd564  movaps [rsp+0x10], xmm6
00007d248dbdd569  movaps [rsp+0x20], xmm15
00007d248dbdd56f  lea rdi, [rsp]
00007d248dbdd573  mov esi, 0x00
00007d248dbdd578  mov rax, 0x5BCEEF236530
00007d248dbdd582  call rax
00007d248dbdd584  movaps xmm1, [rsp]
00007d248dbdd588  add rsp, 0x30
00007d248dbdd58c  vmovaps xmm0, [rsp]
00007d248dbdd591  vmovaps xmm2, [rsp+0x10]
00007d248dbdd597  vmovaps xmm3, [rsp+0x20]
00007d248dbdd59d  vmovaps xmm4, [rsp+0x30]
00007d248dbdd5a3  vmovaps xmm5, [rsp+0x40]
00007d248dbdd5a9  vmovaps xmm6, [rsp+0x50]
00007d248dbdd5af  vmovaps xmm7, [rsp+0x60]
00007d248dbdd5b5  vmovaps xmm8, [rsp+0x70]
00007d248dbdd5bb  vmovaps xmm9, [rsp+0x80]
00007d248dbdd5c4  vmovaps xmm10, [rsp+0x90]
00007d248dbdd5cd  vmovaps xmm11, [rsp+0xA0]
00007d248dbdd5d6  vmovaps xmm12, [rsp+0xB0]
00007d248dbdd5df  vmovaps xmm13, [rsp+0xC0]
00007d248dbdd5e8  vmovaps xmm14, [rsp+0xD0]
00007d248dbdd5f1  vmovaps xmm15, [rsp+0xE0]
00007d248dbdd5fa  add rsp, 0xF0
00007d248dbdd601  pop r11
00007d248dbdd603  pop r10
00007d248dbdd605  pop r9
00007d248dbdd607  pop r8
00007d248dbdd609  pop rsi
00007d248dbdd60a  pop rdi
00007d248dbdd60b  pop rdx
00007d248dbdd60c  pop rcx
00007d248dbdd60d  pop rax
00007d248dbdd60e  add rsp, 0x08
00007d248dbdd612  jmp 0x00007D248DBDBE1B
00007d248dbdd617  call 0x00007D248DAC4620
00007d248dbdd61c  jmp 0x00007D248DBDBE28
00007d248dbdd621  sub rsp, 0x08
00007d248dbdd625  push rax
00007d248dbdd626  push rcx
00007d248dbdd627  push rdx
00007d248dbdd628  push rdi
00007d248dbdd629  push rsi
00007d248dbdd62a  push r8
00007d248dbdd62c  push r9
00007d248dbdd62e  push r10
00007d248dbdd630  push r11
00007d248dbdd632  sub rsp, 0xF0
00007d248dbdd639  vmovaps [rsp], xmm0
00007d248dbdd63e  vmovaps [rsp+0x10], xmm1
00007d248dbdd644  vmovaps [rsp+0x20], xmm2
00007d248dbdd64a  vmovaps [rsp+0x30], xmm3
00007d248dbdd650  vmovaps [rsp+0x40], xmm4
00007d248dbdd656  vmovaps [rsp+0x50], xmm5
00007d248dbdd65c  vmovaps [rsp+0x60], xmm6
00007d248dbdd662  vmovaps [rsp+0x70], xmm7
00007d248dbdd668  vmovaps [rsp+0x80], xmm8
00007d248dbdd671  vmovaps [rsp+0x90], xmm9
00007d248dbdd67a  vmovaps [rsp+0xA0], xmm10
00007d248dbdd683  vmovaps [rsp+0xB0], xmm11
00007d248dbdd68c  vmovaps [rsp+0xC0], xmm12
00007d248dbdd695  vmovaps [rsp+0xD0], xmm13
00007d248dbdd69e  vmovaps [rsp+0xE0], xmm15
00007d248dbdd6a7  sub rsp, 0x30
00007d248dbdd6ab  movaps [rsp], xmm14
00007d248dbdd6b0  movaps [rsp+0x10], xmm4
00007d248dbdd6b5  movaps [rsp+0x20], xmm3
00007d248dbdd6ba  lea rdi, [rsp]
00007d248dbdd6be  mov esi, 0x00
00007d248dbdd6c3  mov rax, 0x5BCEEF236530
00007d248dbdd6cd  call rax
00007d248dbdd6cf  movaps xmm14, [rsp]
00007d248dbdd6d4  add rsp, 0x30
00007d248dbdd6d8  vmovaps xmm0, [rsp]
00007d248dbdd6dd  vmovaps xmm1, [rsp+0x10]
00007d248dbdd6e3  vmovaps xmm2, [rsp+0x20]
00007d248dbdd6e9  vmovaps xmm3, [rsp+0x30]
00007d248dbdd6ef  vmovaps xmm4, [rsp+0x40]
00007d248dbdd6f5  vmovaps xmm5, [rsp+0x50]
00007d248dbdd6fb  vmovaps xmm6, [rsp+0x60]
00007d248dbdd701  vmovaps xmm7, [rsp+0x70]
00007d248dbdd707  vmovaps xmm8, [rsp+0x80]
00007d248dbdd710  vmovaps xmm9, [rsp+0x90]
00007d248dbdd719  vmovaps xmm10, [rsp+0xA0]
00007d248dbdd722  vmovaps xmm11, [rsp+0xB0]
00007d248dbdd72b  vmovaps xmm12, [rsp+0xC0]
00007d248dbdd734  vmovaps xmm13, [rsp+0xD0]
00007d248dbdd73d  vmovaps xmm15, [rsp+0xE0]
00007d248dbdd746  add rsp, 0xF0
00007d248dbdd74d  pop r11
00007d248dbdd74f  pop r10
00007d248dbdd751  pop r9
00007d248dbdd753  pop r8
00007d248dbdd755  pop rsi
00007d248dbdd756  pop rdi
00007d248dbdd757  pop rdx
00007d248dbdd758  pop rcx
00007d248dbdd759  pop rax
00007d248dbdd75a  add rsp, 0x08
00007d248dbdd75e  jmp 0x00007D248DBDBE42
00007d248dbdd763  sub rsp, 0x08
00007d248dbdd767  push rax
00007d248dbdd768  push rcx
00007d248dbdd769  push rdx
00007d248dbdd76a  push rdi
00007d248dbdd76b  push rsi
00007d248dbdd76c  push r8
00007d248dbdd76e  push r9
00007d248dbdd770  push r10
00007d248dbdd772  push r11
00007d248dbdd774  sub rsp, 0xF0
00007d248dbdd77b  vmovaps [rsp], xmm0
00007d248dbdd780  vmovaps [rsp+0x10], xmm1
00007d248dbdd786  vmovaps [rsp+0x20], xmm2
00007d248dbdd78c  vmovaps [rsp+0x30], xmm3
00007d248dbdd792  vmovaps [rsp+0x40], xmm4
00007d248dbdd798  vmovaps [rsp+0x50], xmm5
00007d248dbdd79e  vmovaps [rsp+0x60], xmm7
00007d248dbdd7a4  vmovaps [rsp+0x70], xmm8
00007d248dbdd7aa  vmovaps [rsp+0x80], xmm9
00007d248dbdd7b3  vmovaps [rsp+0x90], xmm10
00007d248dbdd7bc  vmovaps [rsp+0xA0], xmm11
00007d248dbdd7c5  vmovaps [rsp+0xB0], xmm12
00007d248dbdd7ce  vmovaps [rsp+0xC0], xmm13
00007d248dbdd7d7  vmovaps [rsp+0xD0], xmm14
00007d248dbdd7e0  vmovaps [rsp+0xE0], xmm15
00007d248dbdd7e9  sub rsp, 0x30
00007d248dbdd7ed  movaps [rsp], xmm6
00007d248dbdd7f1  movaps [rsp+0x10], xmm9
00007d248dbdd7f7  movaps [rsp+0x20], xmm7
00007d248dbdd7fc  lea rdi, [rsp]
00007d248dbdd800  mov esi, 0x00
00007d248dbdd805  mov rax, 0x5BCEEF236530
00007d248dbdd80f  call rax
00007d248dbdd811  movaps xmm6, [rsp]
00007d248dbdd815  add rsp, 0x30
00007d248dbdd819  vmovaps xmm0, [rsp]
00007d248dbdd81e  vmovaps xmm1, [rsp+0x10]
00007d248dbdd824  vmovaps xmm2, [rsp+0x20]
00007d248dbdd82a  vmovaps xmm3, [rsp+0x30]
00007d248dbdd830  vmovaps xmm4, [rsp+0x40]
00007d248dbdd836  vmovaps xmm5, [rsp+0x50]
00007d248dbdd83c  vmovaps xmm7, [rsp+0x60]
00007d248dbdd842  vmovaps xmm8, [rsp+0x70]
00007d248dbdd848  vmovaps xmm9, [rsp+0x80]
00007d248dbdd851  vmovaps xmm10, [rsp+0x90]
00007d248dbdd85a  vmovaps xmm11, [rsp+0xA0]
00007d248dbdd863  vmovaps xmm12, [rsp+0xB0]
00007d248dbdd86c  vmovaps xmm13, [rsp+0xC0]
00007d248dbdd875  vmovaps xmm14, [rsp+0xD0]
00007d248dbdd87e  vmovaps xmm15, [rsp+0xE0]
00007d248dbdd887  add rsp, 0xF0
00007d248dbdd88e  pop r11
00007d248dbdd890  pop r10
00007d248dbdd892  pop r9
00007d248dbdd894  pop r8
00007d248dbdd896  pop rsi
00007d248dbdd897  pop rdi
00007d248dbdd898  pop rdx
00007d248dbdd899  pop rcx
00007d248dbdd89a  pop rax
00007d248dbdd89b  add rsp, 0x08
00007d248dbdd89f  jmp 0x00007D248DBDBE5A
00007d248dbdd8a4  sub rsp, 0x08
00007d248dbdd8a8  push rax
00007d248dbdd8a9  push rcx
00007d248dbdd8aa  push rdx
00007d248dbdd8ab  push rdi
00007d248dbdd8ac  push rsi
00007d248dbdd8ad  push r8
00007d248dbdd8af  push r9
00007d248dbdd8b1  push r10
00007d248dbdd8b3  push r11
00007d248dbdd8b5  sub rsp, 0xF0
00007d248dbdd8bc  vmovaps [rsp], xmm0
00007d248dbdd8c1  vmovaps [rsp+0x10], xmm1
00007d248dbdd8c7  vmovaps [rsp+0x20], xmm2
00007d248dbdd8cd  vmovaps [rsp+0x30], xmm3
00007d248dbdd8d3  vmovaps [rsp+0x40], xmm4
00007d248dbdd8d9  vmovaps [rsp+0x50], xmm5
00007d248dbdd8df  vmovaps [rsp+0x60], xmm6
00007d248dbdd8e5  vmovaps [rsp+0x70], xmm8
00007d248dbdd8eb  vmovaps [rsp+0x80], xmm9
00007d248dbdd8f4  vmovaps [rsp+0x90], xmm10
00007d248dbdd8fd  vmovaps [rsp+0xA0], xmm11
00007d248dbdd906  vmovaps [rsp+0xB0], xmm12
00007d248dbdd90f  vmovaps [rsp+0xC0], xmm13
00007d248dbdd918  vmovaps [rsp+0xD0], xmm14
00007d248dbdd921  vmovaps [rsp+0xE0], xmm15
00007d248dbdd92a  sub rsp, 0x30
00007d248dbdd92e  movaps [rsp], xmm7
00007d248dbdd932  movaps [rsp+0x10], xmm4
00007d248dbdd937  movaps [rsp+0x20], xmm9
00007d248dbdd93d  lea rdi, [rsp]
00007d248dbdd941  mov esi, 0x00
00007d248dbdd946  mov rax, 0x5BCEEF236530
00007d248dbdd950  call rax
00007d248dbdd952  movaps xmm7, [rsp]
00007d248dbdd956  add rsp, 0x30
00007d248dbdd95a  vmovaps xmm0, [rsp]
00007d248dbdd95f  vmovaps xmm1, [rsp+0x10]
00007d248dbdd965  vmovaps xmm2, [rsp+0x20]
00007d248dbdd96b  vmovaps xmm3, [rsp+0x30]
00007d248dbdd971  vmovaps xmm4, [rsp+0x40]
00007d248dbdd977  vmovaps xmm5, [rsp+0x50]
00007d248dbdd97d  vmovaps xmm6, [rsp+0x60]
00007d248dbdd983  vmovaps xmm8, [rsp+0x70]
00007d248dbdd989  vmovaps xmm9, [rsp+0x80]
00007d248dbdd992  vmovaps xmm10, [rsp+0x90]
00007d248dbdd99b  vmovaps xmm11, [rsp+0xA0]
00007d248dbdd9a4  vmovaps xmm12, [rsp+0xB0]
00007d248dbdd9ad  vmovaps xmm13, [rsp+0xC0]
00007d248dbdd9b6  vmovaps xmm14, [rsp+0xD0]
00007d248dbdd9bf  vmovaps xmm15, [rsp+0xE0]
00007d248dbdd9c8  add rsp, 0xF0
00007d248dbdd9cf  pop r11
00007d248dbdd9d1  pop r10
00007d248dbdd9d3  pop r9
00007d248dbdd9d5  pop r8
00007d248dbdd9d7  pop rsi
00007d248dbdd9d8  pop rdi
00007d248dbdd9d9  pop rdx
00007d248dbdd9da  pop rcx
00007d248dbdd9db  pop rax
00007d248dbdd9dc  add rsp, 0x08
00007d248dbdd9e0  jmp 0x00007D248DBDBE87
00007d248dbdd9e5  sub rsp, 0x08
00007d248dbdd9e9  push rax
00007d248dbdd9ea  push rcx
00007d248dbdd9eb  push rdx
00007d248dbdd9ec  push rdi
00007d248dbdd9ed  push rsi
00007d248dbdd9ee  push r8
00007d248dbdd9f0  push r9
00007d248dbdd9f2  push r10
00007d248dbdd9f4  push r11
00007d248dbdd9f6  sub rsp, 0xF0
00007d248dbdd9fd  vmovaps [rsp], xmm0
00007d248dbdda02  vmovaps [rsp+0x10], xmm1
00007d248dbdda08  vmovaps [rsp+0x20], xmm2
00007d248dbdda0e  vmovaps [rsp+0x30], xmm3
00007d248dbdda14  vmovaps [rsp+0x40], xmm5
00007d248dbdda1a  vmovaps [rsp+0x50], xmm6
00007d248dbdda20  vmovaps [rsp+0x60], xmm7
00007d248dbdda26  vmovaps [rsp+0x70], xmm8
00007d248dbdda2c  vmovaps [rsp+0x80], xmm9
00007d248dbdda35  vmovaps [rsp+0x90], xmm10
00007d248dbdda3e  vmovaps [rsp+0xA0], xmm11
00007d248dbdda47  vmovaps [rsp+0xB0], xmm12
00007d248dbdda50  vmovaps [rsp+0xC0], xmm13
00007d248dbdda59  vmovaps [rsp+0xD0], xmm14
00007d248dbdda62  vmovaps [rsp+0xE0], xmm15
00007d248dbdda6b  sub rsp, 0x30
00007d248dbdda6f  movaps [rsp], xmm4
00007d248dbdda73  movaps [rsp+0x10], xmm15
00007d248dbdda79  movaps [rsp+0x20], xmm9
00007d248dbdda7f  lea rdi, [rsp]
00007d248dbdda83  mov esi, 0x00
00007d248dbdda88  mov rax, 0x5BCEEF236530
00007d248dbdda92  call rax
00007d248dbdda94  movaps xmm4, [rsp]
00007d248dbdda98  add rsp, 0x30
00007d248dbdda9c  vmovaps xmm0, [rsp]
00007d248dbddaa1  vmovaps xmm1, [rsp+0x10]
00007d248dbddaa7  vmovaps xmm2, [rsp+0x20]
00007d248dbddaad  vmovaps xmm3, [rsp+0x30]
00007d248dbddab3  vmovaps xmm5, [rsp+0x40]
00007d248dbddab9  vmovaps xmm6, [rsp+0x50]
00007d248dbddabf  vmovaps xmm7, [rsp+0x60]
00007d248dbddac5  vmovaps xmm8, [rsp+0x70]
00007d248dbddacb  vmovaps xmm9, [rsp+0x80]
00007d248dbddad4  vmovaps xmm10, [rsp+0x90]
00007d248dbddadd  vmovaps xmm11, [rsp+0xA0]
00007d248dbddae6  vmovaps xmm12, [rsp+0xB0]
00007d248dbddaef  vmovaps xmm13, [rsp+0xC0]
00007d248dbddaf8  vmovaps xmm14, [rsp+0xD0]
00007d248dbddb01  vmovaps xmm15, [rsp+0xE0]
00007d248dbddb0a  add rsp, 0xF0
00007d248dbddb11  pop r11
00007d248dbddb13  pop r10
00007d248dbddb15  pop r9
00007d248dbddb17  pop r8
00007d248dbddb19  pop rsi
00007d248dbddb1a  pop rdi
00007d248dbddb1b  pop rdx
00007d248dbddb1c  pop rcx
00007d248dbddb1d  pop rax
00007d248dbddb1e  add rsp, 0x08
00007d248dbddb22  jmp 0x00007D248DBDBEAC
00007d248dbddb27  call 0x00007D248DAC4620
00007d248dbddb2c  jmp 0x00007D248DBDBEB9
00007d248dbddb31  sub rsp, 0x08
00007d248dbddb35  push rax
00007d248dbddb36  push rcx
00007d248dbddb37  push rdx
00007d248dbddb38  push rdi
00007d248dbddb39  push rsi
00007d248dbddb3a  push r8
00007d248dbddb3c  push r9
00007d248dbddb3e  push r10
00007d248dbddb40  push r11
00007d248dbddb42  sub rsp, 0xF0
00007d248dbddb49  vmovaps [rsp], xmm0
00007d248dbddb4e  vmovaps [rsp+0x10], xmm1
00007d248dbddb54  vmovaps [rsp+0x20], xmm2
00007d248dbddb5a  vmovaps [rsp+0x30], xmm4
00007d248dbddb60  vmovaps [rsp+0x40], xmm5
00007d248dbddb66  vmovaps [rsp+0x50], xmm6
00007d248dbddb6c  vmovaps [rsp+0x60], xmm7
00007d248dbddb72  vmovaps [rsp+0x70], xmm8
00007d248dbddb78  vmovaps [rsp+0x80], xmm9
00007d248dbddb81  vmovaps [rsp+0x90], xmm10
00007d248dbddb8a  vmovaps [rsp+0xA0], xmm11
00007d248dbddb93  vmovaps [rsp+0xB0], xmm12
00007d248dbddb9c  vmovaps [rsp+0xC0], xmm13
00007d248dbddba5  vmovaps [rsp+0xD0], xmm14
00007d248dbddbae  vmovaps [rsp+0xE0], xmm15
00007d248dbddbb7  sub rsp, 0x30
00007d248dbddbbb  movaps [rsp], xmm3
00007d248dbddbbf  movaps [rsp+0x10], xmm1
00007d248dbddbc4  movaps [rsp+0x20], xmm9
00007d248dbddbca  lea rdi, [rsp]
00007d248dbddbce  mov esi, 0x00
00007d248dbddbd3  mov rax, 0x5BCEEF236530
00007d248dbddbdd  call rax
00007d248dbddbdf  movaps xmm3, [rsp]
00007d248dbddbe3  add rsp, 0x30
00007d248dbddbe7  vmovaps xmm0, [rsp]
00007d248dbddbec  vmovaps xmm1, [rsp+0x10]
00007d248dbddbf2  vmovaps xmm2, [rsp+0x20]
00007d248dbddbf8  vmovaps xmm4, [rsp+0x30]
00007d248dbddbfe  vmovaps xmm5, [rsp+0x40]
00007d248dbddc04  vmovaps xmm6, [rsp+0x50]
00007d248dbddc0a  vmovaps xmm7, [rsp+0x60]
00007d248dbddc10  vmovaps xmm8, [rsp+0x70]
00007d248dbddc16  vmovaps xmm9, [rsp+0x80]
00007d248dbddc1f  vmovaps xmm10, [rsp+0x90]
00007d248dbddc28  vmovaps xmm11, [rsp+0xA0]
00007d248dbddc31  vmovaps xmm12, [rsp+0xB0]
00007d248dbddc3a  vmovaps xmm13, [rsp+0xC0]
00007d248dbddc43  vmovaps xmm14, [rsp+0xD0]
00007d248dbddc4c  vmovaps xmm15, [rsp+0xE0]
00007d248dbddc55  add rsp, 0xF0
00007d248dbddc5c  pop r11
00007d248dbddc5e  pop r10
00007d248dbddc60  pop r9
00007d248dbddc62  pop r8
00007d248dbddc64  pop rsi
00007d248dbddc65  pop rdi
00007d248dbddc66  pop rdx
00007d248dbddc67  pop rcx
00007d248dbddc68  pop rax
00007d248dbddc69  add rsp, 0x08
00007d248dbddc6d  jmp 0x00007D248DBDBEF6
00007d248dbddc72  sub rsp, 0x08
00007d248dbddc76  push rax
00007d248dbddc77  push rcx
00007d248dbddc78  push rdx
00007d248dbddc79  push rdi
00007d248dbddc7a  push rsi
00007d248dbddc7b  push r8
00007d248dbddc7d  push r9
00007d248dbddc7f  push r10
00007d248dbddc81  push r11
00007d248dbddc83  sub rsp, 0xF0
00007d248dbddc8a  vmovaps [rsp], xmm0
00007d248dbddc8f  vmovaps [rsp+0x10], xmm2
00007d248dbddc95  vmovaps [rsp+0x20], xmm3
00007d248dbddc9b  vmovaps [rsp+0x30], xmm4
00007d248dbddca1  vmovaps [rsp+0x40], xmm5
00007d248dbddca7  vmovaps [rsp+0x50], xmm6
00007d248dbddcad  vmovaps [rsp+0x60], xmm7
00007d248dbddcb3  vmovaps [rsp+0x70], xmm8
00007d248dbddcb9  vmovaps [rsp+0x80], xmm9
00007d248dbddcc2  vmovaps [rsp+0x90], xmm10
00007d248dbddccb  vmovaps [rsp+0xA0], xmm11
00007d248dbddcd4  vmovaps [rsp+0xB0], xmm12
00007d248dbddcdd  vmovaps [rsp+0xC0], xmm13
00007d248dbddce6  vmovaps [rsp+0xD0], xmm14
00007d248dbddcef  vmovaps [rsp+0xE0], xmm15
00007d248dbddcf8  sub rsp, 0x30
00007d248dbddcfc  movaps [rsp], xmm1
00007d248dbddd00  movaps [rsp+0x10], xmm15
00007d248dbddd06  movaps [rsp+0x20], xmm9
00007d248dbddd0c  lea rdi, [rsp]
00007d248dbddd10  mov esi, 0x00
00007d248dbddd15  mov rax, 0x5BCEEF236530
00007d248dbddd1f  call rax
00007d248dbddd21  movaps xmm1, [rsp]
00007d248dbddd25  add rsp, 0x30
00007d248dbddd29  vmovaps xmm0, [rsp]
00007d248dbddd2e  vmovaps xmm2, [rsp+0x10]
00007d248dbddd34  vmovaps xmm3, [rsp+0x20]
00007d248dbddd3a  vmovaps xmm4, [rsp+0x30]
00007d248dbddd40  vmovaps xmm5, [rsp+0x40]
00007d248dbddd46  vmovaps xmm6, [rsp+0x50]
00007d248dbddd4c  vmovaps xmm7, [rsp+0x60]
00007d248dbddd52  vmovaps xmm8, [rsp+0x70]
00007d248dbddd58  vmovaps xmm9, [rsp+0x80]
00007d248dbddd61  vmovaps xmm10, [rsp+0x90]
00007d248dbddd6a  vmovaps xmm11, [rsp+0xA0]
00007d248dbddd73  vmovaps xmm12, [rsp+0xB0]
00007d248dbddd7c  vmovaps xmm13, [rsp+0xC0]
00007d248dbddd85  vmovaps xmm14, [rsp+0xD0]
00007d248dbddd8e  vmovaps xmm15, [rsp+0xE0]
00007d248dbddd97  add rsp, 0xF0
00007d248dbddd9e  pop r11
00007d248dbddda0  pop r10
00007d248dbddda2  pop r9
00007d248dbddda4  pop r8
00007d248dbddda6  pop rsi
00007d248dbddda7  pop rdi
00007d248dbddda8  pop rdx
00007d248dbddda9  pop rcx
00007d248dbdddaa  pop rax
00007d248dbdddab  add rsp, 0x08
00007d248dbdddaf  jmp 0x00007D248DBDBF7E
00007d248dbdddb4  call 0x00007D248DAC4620
00007d248dbdddb9  jmp 0x00007D248DBDBF8B
00007d248dbdddbe  sub rsp, 0x08
00007d248dbdddc2  push rax
00007d248dbdddc3  push rcx
00007d248dbdddc4  push rdx
00007d248dbdddc5  push rdi
00007d248dbdddc6  push rsi
00007d248dbdddc7  push r8
00007d248dbdddc9  push r9
00007d248dbdddcb  push r10
00007d248dbdddcd  push r11
00007d248dbdddcf  sub rsp, 0xF0
00007d248dbdddd6  vmovaps [rsp], xmm0
00007d248dbddddb  vmovaps [rsp+0x10], xmm2
00007d248dbddde1  vmovaps [rsp+0x20], xmm3
00007d248dbddde7  vmovaps [rsp+0x30], xmm4
00007d248dbddded  vmovaps [rsp+0x40], xmm5
00007d248dbdddf3  vmovaps [rsp+0x50], xmm6
00007d248dbdddf9  vmovaps [rsp+0x60], xmm7
00007d248dbdddff  vmovaps [rsp+0x70], xmm8
00007d248dbdde05  vmovaps [rsp+0x80], xmm9
00007d248dbdde0e  vmovaps [rsp+0x90], xmm10
00007d248dbdde17  vmovaps [rsp+0xA0], xmm11
00007d248dbdde20  vmovaps [rsp+0xB0], xmm12
00007d248dbdde29  vmovaps [rsp+0xC0], xmm13
00007d248dbdde32  vmovaps [rsp+0xD0], xmm14
00007d248dbdde3b  vmovaps [rsp+0xE0], xmm15
00007d248dbdde44  sub rsp, 0x30
00007d248dbdde48  movaps [rsp], xmm1
00007d248dbdde4c  movaps [rsp+0x10], xmm5
00007d248dbdde51  movaps [rsp+0x20], xmm7
00007d248dbdde56  lea rdi, [rsp]
00007d248dbdde5a  mov esi, 0x00
00007d248dbdde5f  mov rax, 0x5BCEEF236530
00007d248dbdde69  call rax
00007d248dbdde6b  movaps xmm1, [rsp]
00007d248dbdde6f  add rsp, 0x30
00007d248dbdde73  vmovaps xmm0, [rsp]
00007d248dbdde78  vmovaps xmm2, [rsp+0x10]
00007d248dbdde7e  vmovaps xmm3, [rsp+0x20]
00007d248dbdde84  vmovaps xmm4, [rsp+0x30]
00007d248dbdde8a  vmovaps xmm5, [rsp+0x40]
00007d248dbdde90  vmovaps xmm6, [rsp+0x50]
00007d248dbdde96  vmovaps xmm7, [rsp+0x60]
00007d248dbdde9c  vmovaps xmm8, [rsp+0x70]
00007d248dbddea2  vmovaps xmm9, [rsp+0x80]
00007d248dbddeab  vmovaps xmm10, [rsp+0x90]
00007d248dbddeb4  vmovaps xmm11, [rsp+0xA0]
00007d248dbddebd  vmovaps xmm12, [rsp+0xB0]
00007d248dbddec6  vmovaps xmm13, [rsp+0xC0]
00007d248dbddecf  vmovaps xmm14, [rsp+0xD0]
00007d248dbdded8  vmovaps xmm15, [rsp+0xE0]
00007d248dbddee1  add rsp, 0xF0
00007d248dbddee8  pop r11
00007d248dbddeea  pop r10
00007d248dbddeec  pop r9
00007d248dbddeee  pop r8
00007d248dbddef0  pop rsi
00007d248dbddef1  pop rdi
00007d248dbddef2  pop rdx
00007d248dbddef3  pop rcx
00007d248dbddef4  pop rax
00007d248dbddef5  add rsp, 0x08
00007d248dbddef9  jmp 0x00007D248DBDC030
00007d248dbddefe  sub rsp, 0x08
00007d248dbddf02  push rax
00007d248dbddf03  push rcx
00007d248dbddf04  push rdx
00007d248dbddf05  push rdi
00007d248dbddf06  push rsi
00007d248dbddf07  push r8
00007d248dbddf09  push r9
00007d248dbddf0b  push r10
00007d248dbddf0d  push r11
00007d248dbddf0f  sub rsp, 0xF0
00007d248dbddf16  vmovaps [rsp], xmm0
00007d248dbddf1b  vmovaps [rsp+0x10], xmm1
00007d248dbddf21  vmovaps [rsp+0x20], xmm2
00007d248dbddf27  vmovaps [rsp+0x30], xmm3
00007d248dbddf2d  vmovaps [rsp+0x40], xmm4
00007d248dbddf33  vmovaps [rsp+0x50], xmm5
00007d248dbddf39  vmovaps [rsp+0x60], xmm6
00007d248dbddf3f  vmovaps [rsp+0x70], xmm8
00007d248dbddf45  vmovaps [rsp+0x80], xmm9
00007d248dbddf4e  vmovaps [rsp+0x90], xmm10
00007d248dbddf57  vmovaps [rsp+0xA0], xmm11
00007d248dbddf60  vmovaps [rsp+0xB0], xmm12
00007d248dbddf69  vmovaps [rsp+0xC0], xmm13
00007d248dbddf72  vmovaps [rsp+0xD0], xmm14
00007d248dbddf7b  vmovaps [rsp+0xE0], xmm15
00007d248dbddf84  sub rsp, 0x30
00007d248dbddf88  movaps [rsp], xmm7
00007d248dbddf8c  movaps [rsp+0x10], xmm5
00007d248dbddf91  movaps [rsp+0x20], xmm15
00007d248dbddf97  lea rdi, [rsp]
00007d248dbddf9b  mov esi, 0x00
00007d248dbddfa0  mov rax, 0x5BCEEF236530
00007d248dbddfaa  call rax
00007d248dbddfac  movaps xmm7, [rsp]
00007d248dbddfb0  add rsp, 0x30
00007d248dbddfb4  vmovaps xmm0, [rsp]
00007d248dbddfb9  vmovaps xmm1, [rsp+0x10]
00007d248dbddfbf  vmovaps xmm2, [rsp+0x20]
00007d248dbddfc5  vmovaps xmm3, [rsp+0x30]
00007d248dbddfcb  vmovaps xmm4, [rsp+0x40]
00007d248dbddfd1  vmovaps xmm5, [rsp+0x50]
00007d248dbddfd7  vmovaps xmm6, [rsp+0x60]
00007d248dbddfdd  vmovaps xmm8, [rsp+0x70]
00007d248dbddfe3  vmovaps xmm9, [rsp+0x80]
00007d248dbddfec  vmovaps xmm10, [rsp+0x90]
00007d248dbddff5  vmovaps xmm11, [rsp+0xA0]
00007d248dbddffe  vmovaps xmm12, [rsp+0xB0]
00007d248dbde007  vmovaps xmm13, [rsp+0xC0]
00007d248dbde010  vmovaps xmm14, [rsp+0xD0]
00007d248dbde019  vmovaps xmm15, [rsp+0xE0]
00007d248dbde022  add rsp, 0xF0
00007d248dbde029  pop r11
00007d248dbde02b  pop r10
00007d248dbde02d  pop r9
00007d248dbde02f  pop r8
00007d248dbde031  pop rsi
00007d248dbde032  pop rdi
00007d248dbde033  pop rdx
00007d248dbde034  pop rcx
00007d248dbde035  pop rax
00007d248dbde036  add rsp, 0x08
00007d248dbde03a  jmp 0x00007D248DBDC066
00007d248dbde03f  call 0x00007D248DAB52F0
00007d248dbde044  jmp 0x00007D248DBDC073
00007d248dbde049  sub rsp, 0x08
00007d248dbde04d  push rax
00007d248dbde04e  push rcx
00007d248dbde04f  push rdx
00007d248dbde050  push rdi
00007d248dbde051  push rsi
00007d248dbde052  push r8
00007d248dbde054  push r9
00007d248dbde056  push r10
00007d248dbde058  push r11
00007d248dbde05a  sub rsp, 0xF0
00007d248dbde061  vmovaps [rsp], xmm0
00007d248dbde066  vmovaps [rsp+0x10], xmm1
00007d248dbde06c  vmovaps [rsp+0x20], xmm2
00007d248dbde072  vmovaps [rsp+0x30], xmm3
00007d248dbde078  vmovaps [rsp+0x40], xmm4
00007d248dbde07e  vmovaps [rsp+0x50], xmm5
00007d248dbde084  vmovaps [rsp+0x60], xmm6
00007d248dbde08a  vmovaps [rsp+0x70], xmm7
00007d248dbde090  vmovaps [rsp+0x80], xmm8
00007d248dbde099  vmovaps [rsp+0x90], xmm9
00007d248dbde0a2  vmovaps [rsp+0xA0], xmm10
00007d248dbde0ab  vmovaps [rsp+0xB0], xmm11
00007d248dbde0b4  vmovaps [rsp+0xC0], xmm12
00007d248dbde0bd  vmovaps [rsp+0xD0], xmm13
00007d248dbde0c6  vmovaps [rsp+0xE0], xmm14
00007d248dbde0cf  sub rsp, 0x30
00007d248dbde0d3  movaps [rsp], xmm15
00007d248dbde0d8  movaps [rsp+0x10], xmm5
00007d248dbde0dd  movaps [rsp+0x20], xmm3
00007d248dbde0e2  lea rdi, [rsp]
00007d248dbde0e6  mov esi, 0x00
00007d248dbde0eb  mov rax, 0x5BCEEF236530
00007d248dbde0f5  call rax
00007d248dbde0f7  movaps xmm15, [rsp]
00007d248dbde0fc  add rsp, 0x30
00007d248dbde100  vmovaps xmm0, [rsp]
00007d248dbde105  vmovaps xmm1, [rsp+0x10]
00007d248dbde10b  vmovaps xmm2, [rsp+0x20]
00007d248dbde111  vmovaps xmm3, [rsp+0x30]
00007d248dbde117  vmovaps xmm4, [rsp+0x40]
00007d248dbde11d  vmovaps xmm5, [rsp+0x50]
00007d248dbde123  vmovaps xmm6, [rsp+0x60]
00007d248dbde129  vmovaps xmm7, [rsp+0x70]
00007d248dbde12f  vmovaps xmm8, [rsp+0x80]
00007d248dbde138  vmovaps xmm9, [rsp+0x90]
00007d248dbde141  vmovaps xmm10, [rsp+0xA0]
00007d248dbde14a  vmovaps xmm11, [rsp+0xB0]
00007d248dbde153  vmovaps xmm12, [rsp+0xC0]
00007d248dbde15c  vmovaps xmm13, [rsp+0xD0]
00007d248dbde165  vmovaps xmm14, [rsp+0xE0]
00007d248dbde16e  add rsp, 0xF0
00007d248dbde175  pop r11
00007d248dbde177  pop r10
00007d248dbde179  pop r9
00007d248dbde17b  pop r8
00007d248dbde17d  pop rsi
00007d248dbde17e  pop rdi
00007d248dbde17f  pop rdx
00007d248dbde180  pop rcx
00007d248dbde181  pop rax
00007d248dbde182  add rsp, 0x08
00007d248dbde186  jmp 0x00007D248DBDC099
00007d248dbde18b  sub rsp, 0x08
00007d248dbde18f  push rax
00007d248dbde190  push rcx
00007d248dbde191  push rdx
00007d248dbde192  push rdi
00007d248dbde193  push rsi
00007d248dbde194  push r8
00007d248dbde196  push r9
00007d248dbde198  push r10
00007d248dbde19a  push r11
00007d248dbde19c  sub rsp, 0xF0
00007d248dbde1a3  vmovaps [rsp], xmm0
00007d248dbde1a8  vmovaps [rsp+0x10], xmm2
00007d248dbde1ae  vmovaps [rsp+0x20], xmm3
00007d248dbde1b4  vmovaps [rsp+0x30], xmm4
00007d248dbde1ba  vmovaps [rsp+0x40], xmm5
00007d248dbde1c0  vmovaps [rsp+0x50], xmm6
00007d248dbde1c6  vmovaps [rsp+0x60], xmm7
00007d248dbde1cc  vmovaps [rsp+0x70], xmm8
00007d248dbde1d2  vmovaps [rsp+0x80], xmm9
00007d248dbde1db  vmovaps [rsp+0x90], xmm10
00007d248dbde1e4  vmovaps [rsp+0xA0], xmm11
00007d248dbde1ed  vmovaps [rsp+0xB0], xmm12
00007d248dbde1f6  vmovaps [rsp+0xC0], xmm13
00007d248dbde1ff  vmovaps [rsp+0xD0], xmm14
00007d248dbde208  vmovaps [rsp+0xE0], xmm15
00007d248dbde211  sub rsp, 0x30
00007d248dbde215  movaps [rsp], xmm1
00007d248dbde219  movaps [rsp+0x10], xmm5
00007d248dbde21e  movaps [rsp+0x20], xmm4
00007d248dbde223  lea rdi, [rsp]
00007d248dbde227  mov esi, 0x00
00007d248dbde22c  mov rax, 0x5BCEEF236530
00007d248dbde236  call rax
00007d248dbde238  movaps xmm1, [rsp]
00007d248dbde23c  add rsp, 0x30
00007d248dbde240  vmovaps xmm0, [rsp]
00007d248dbde245  vmovaps xmm2, [rsp+0x10]
00007d248dbde24b  vmovaps xmm3, [rsp+0x20]
00007d248dbde251  vmovaps xmm4, [rsp+0x30]
00007d248dbde257  vmovaps xmm5, [rsp+0x40]
00007d248dbde25d  vmovaps xmm6, [rsp+0x50]
00007d248dbde263  vmovaps xmm7, [rsp+0x60]
00007d248dbde269  vmovaps xmm8, [rsp+0x70]
00007d248dbde26f  vmovaps xmm9, [rsp+0x80]
00007d248dbde278  vmovaps xmm10, [rsp+0x90]
00007d248dbde281  vmovaps xmm11, [rsp+0xA0]
00007d248dbde28a  vmovaps xmm12, [rsp+0xB0]
00007d248dbde293  vmovaps xmm13, [rsp+0xC0]
00007d248dbde29c  vmovaps xmm14, [rsp+0xD0]
00007d248dbde2a5  vmovaps xmm15, [rsp+0xE0]
00007d248dbde2ae  add rsp, 0xF0
00007d248dbde2b5  pop r11
00007d248dbde2b7  pop r10
00007d248dbde2b9  pop r9
00007d248dbde2bb  pop r8
00007d248dbde2bd  pop rsi
00007d248dbde2be  pop rdi
00007d248dbde2bf  pop rdx
00007d248dbde2c0  pop rcx
00007d248dbde2c1  pop rax
00007d248dbde2c2  add rsp, 0x08
00007d248dbde2c6  jmp 0x00007D248DBDC0B9
00007d248dbde2cb  sub rsp, 0x08
00007d248dbde2cf  push rax
00007d248dbde2d0  push rcx
00007d248dbde2d1  push rdx
00007d248dbde2d2  push rdi
00007d248dbde2d3  push rsi
00007d248dbde2d4  push r8
00007d248dbde2d6  push r9
00007d248dbde2d8  push r10
00007d248dbde2da  push r11
00007d248dbde2dc  sub rsp, 0xF0
00007d248dbde2e3  vmovaps [rsp], xmm0
00007d248dbde2e8  vmovaps [rsp+0x10], xmm1
00007d248dbde2ee  vmovaps [rsp+0x20], xmm2
00007d248dbde2f4  vmovaps [rsp+0x30], xmm3
00007d248dbde2fa  vmovaps [rsp+0x40], xmm5
00007d248dbde300  vmovaps [rsp+0x50], xmm6
00007d248dbde306  vmovaps [rsp+0x60], xmm7
00007d248dbde30c  vmovaps [rsp+0x70], xmm8
00007d248dbde312  vmovaps [rsp+0x80], xmm9
00007d248dbde31b  vmovaps [rsp+0x90], xmm10
00007d248dbde324  vmovaps [rsp+0xA0], xmm11
00007d248dbde32d  vmovaps [rsp+0xB0], xmm12
00007d248dbde336  vmovaps [rsp+0xC0], xmm13
00007d248dbde33f  vmovaps [rsp+0xD0], xmm14
00007d248dbde348  vmovaps [rsp+0xE0], xmm15
00007d248dbde351  sub rsp, 0x30
00007d248dbde355  movaps [rsp], xmm4
00007d248dbde359  movaps [rsp+0x10], xmm3
00007d248dbde35e  movaps [rsp+0x20], xmm5
00007d248dbde363  lea rdi, [rsp]
00007d248dbde367  mov esi, 0x00
00007d248dbde36c  mov rax, 0x5BCEEF236530
00007d248dbde376  call rax
00007d248dbde378  movaps xmm4, [rsp]
00007d248dbde37c  add rsp, 0x30
00007d248dbde380  vmovaps xmm0, [rsp]
00007d248dbde385  vmovaps xmm1, [rsp+0x10]
00007d248dbde38b  vmovaps xmm2, [rsp+0x20]
00007d248dbde391  vmovaps xmm3, [rsp+0x30]
00007d248dbde397  vmovaps xmm5, [rsp+0x40]
00007d248dbde39d  vmovaps xmm6, [rsp+0x50]
00007d248dbde3a3  vmovaps xmm7, [rsp+0x60]
00007d248dbde3a9  vmovaps xmm8, [rsp+0x70]
00007d248dbde3af  vmovaps xmm9, [rsp+0x80]
00007d248dbde3b8  vmovaps xmm10, [rsp+0x90]
00007d248dbde3c1  vmovaps xmm11, [rsp+0xA0]
00007d248dbde3ca  vmovaps xmm12, [rsp+0xB0]
00007d248dbde3d3  vmovaps xmm13, [rsp+0xC0]
00007d248dbde3dc  vmovaps xmm14, [rsp+0xD0]
00007d248dbde3e5  vmovaps xmm15, [rsp+0xE0]
00007d248dbde3ee  add rsp, 0xF0
00007d248dbde3f5  pop r11
00007d248dbde3f7  pop r10
00007d248dbde3f9  pop r9
00007d248dbde3fb  pop r8
00007d248dbde3fd  pop rsi
00007d248dbde3fe  pop rdi
00007d248dbde3ff  pop rdx
00007d248dbde400  pop rcx
00007d248dbde401  pop rax
00007d248dbde402  add rsp, 0x08
00007d248dbde406  jmp 0x00007D248DBDC107
00007d248dbde40b  call 0x00007D248DAB52F0
00007d248dbde410  jmp 0x00007D248DBDC114
00007d248dbde415  sub rsp, 0x08
00007d248dbde419  push rax
00007d248dbde41a  push rcx
00007d248dbde41b  push rdx
00007d248dbde41c  push rdi
00007d248dbde41d  push rsi
00007d248dbde41e  push r8
00007d248dbde420  push r9
00007d248dbde422  push r10
00007d248dbde424  push r11
00007d248dbde426  sub rsp, 0xF0
00007d248dbde42d  vmovaps [rsp], xmm0
00007d248dbde432  vmovaps [rsp+0x10], xmm1
00007d248dbde438  vmovaps [rsp+0x20], xmm2
00007d248dbde43e  vmovaps [rsp+0x30], xmm3
00007d248dbde444  vmovaps [rsp+0x40], xmm4
00007d248dbde44a  vmovaps [rsp+0x50], xmm6
00007d248dbde450  vmovaps [rsp+0x60], xmm7
00007d248dbde456  vmovaps [rsp+0x70], xmm8
00007d248dbde45c  vmovaps [rsp+0x80], xmm9
00007d248dbde465  vmovaps [rsp+0x90], xmm10
00007d248dbde46e  vmovaps [rsp+0xA0], xmm11
00007d248dbde477  vmovaps [rsp+0xB0], xmm12
00007d248dbde480  vmovaps [rsp+0xC0], xmm13
00007d248dbde489  vmovaps [rsp+0xD0], xmm14
00007d248dbde492  vmovaps [rsp+0xE0], xmm15
00007d248dbde49b  sub rsp, 0x30
00007d248dbde49f  movaps [rsp], xmm5
00007d248dbde4a3  movaps [rsp+0x10], xmm6
00007d248dbde4a8  movaps [rsp+0x20], xmm3
00007d248dbde4ad  lea rdi, [rsp]
00007d248dbde4b1  mov esi, 0x00
00007d248dbde4b6  mov rax, 0x5BCEEF236530
00007d248dbde4c0  call rax
00007d248dbde4c2  movaps xmm5, [rsp]
00007d248dbde4c6  add rsp, 0x30
00007d248dbde4ca  vmovaps xmm0, [rsp]
00007d248dbde4cf  vmovaps xmm1, [rsp+0x10]
00007d248dbde4d5  vmovaps xmm2, [rsp+0x20]
00007d248dbde4db  vmovaps xmm3, [rsp+0x30]
00007d248dbde4e1  vmovaps xmm4, [rsp+0x40]
00007d248dbde4e7  vmovaps xmm6, [rsp+0x50]
00007d248dbde4ed  vmovaps xmm7, [rsp+0x60]
00007d248dbde4f3  vmovaps xmm8, [rsp+0x70]
00007d248dbde4f9  vmovaps xmm9, [rsp+0x80]
00007d248dbde502  vmovaps xmm10, [rsp+0x90]
00007d248dbde50b  vmovaps xmm11, [rsp+0xA0]
00007d248dbde514  vmovaps xmm12, [rsp+0xB0]
00007d248dbde51d  vmovaps xmm13, [rsp+0xC0]
00007d248dbde526  vmovaps xmm14, [rsp+0xD0]
00007d248dbde52f  vmovaps xmm15, [rsp+0xE0]
00007d248dbde538  add rsp, 0xF0
00007d248dbde53f  pop r11
00007d248dbde541  pop r10
00007d248dbde543  pop r9
00007d248dbde545  pop r8
00007d248dbde547  pop rsi
00007d248dbde548  pop rdi
00007d248dbde549  pop rdx
00007d248dbde54a  pop rcx
00007d248dbde54b  pop rax
00007d248dbde54c  add rsp, 0x08
00007d248dbde550  jmp 0x00007D248DBDC13A
00007d248dbde555  sub rsp, 0x08
00007d248dbde559  push rax
00007d248dbde55a  push rcx
00007d248dbde55b  push rdx
00007d248dbde55c  push rdi
00007d248dbde55d  push rsi
00007d248dbde55e  push r8
00007d248dbde560  push r9
00007d248dbde562  push r10
00007d248dbde564  push r11
00007d248dbde566  sub rsp, 0xF0
00007d248dbde56d  vmovaps [rsp], xmm0
00007d248dbde572  vmovaps [rsp+0x10], xmm1
00007d248dbde578  vmovaps [rsp+0x20], xmm2
00007d248dbde57e  vmovaps [rsp+0x30], xmm3
00007d248dbde584  vmovaps [rsp+0x40], xmm4
00007d248dbde58a  vmovaps [rsp+0x50], xmm5
00007d248dbde590  vmovaps [rsp+0x60], xmm7
00007d248dbde596  vmovaps [rsp+0x70], xmm8
00007d248dbde59c  vmovaps [rsp+0x80], xmm9
00007d248dbde5a5  vmovaps [rsp+0x90], xmm10
00007d248dbde5ae  vmovaps [rsp+0xA0], xmm11
00007d248dbde5b7  vmovaps [rsp+0xB0], xmm12
00007d248dbde5c0  vmovaps [rsp+0xC0], xmm13
00007d248dbde5c9  vmovaps [rsp+0xD0], xmm14
00007d248dbde5d2  vmovaps [rsp+0xE0], xmm15
00007d248dbde5db  sub rsp, 0x30
00007d248dbde5df  movaps [rsp], xmm6
00007d248dbde5e3  movaps [rsp+0x10], xmm9
00007d248dbde5e9  movaps [rsp+0x20], xmm1
00007d248dbde5ee  lea rdi, [rsp]
00007d248dbde5f2  mov esi, 0x00
00007d248dbde5f7  mov rax, 0x5BCEEF236530
00007d248dbde601  call rax
00007d248dbde603  movaps xmm6, [rsp]
00007d248dbde607  add rsp, 0x30
00007d248dbde60b  vmovaps xmm0, [rsp]
00007d248dbde610  vmovaps xmm1, [rsp+0x10]
00007d248dbde616  vmovaps xmm2, [rsp+0x20]
00007d248dbde61c  vmovaps xmm3, [rsp+0x30]
00007d248dbde622  vmovaps xmm4, [rsp+0x40]
00007d248dbde628  vmovaps xmm5, [rsp+0x50]
00007d248dbde62e  vmovaps xmm7, [rsp+0x60]
00007d248dbde634  vmovaps xmm8, [rsp+0x70]
00007d248dbde63a  vmovaps xmm9, [rsp+0x80]
00007d248dbde643  vmovaps xmm10, [rsp+0x90]
00007d248dbde64c  vmovaps xmm11, [rsp+0xA0]
00007d248dbde655  vmovaps xmm12, [rsp+0xB0]
00007d248dbde65e  vmovaps xmm13, [rsp+0xC0]
00007d248dbde667  vmovaps xmm14, [rsp+0xD0]
00007d248dbde670  vmovaps xmm15, [rsp+0xE0]
00007d248dbde679  add rsp, 0xF0
00007d248dbde680  pop r11
00007d248dbde682  pop r10
00007d248dbde684  pop r9
00007d248dbde686  pop r8
00007d248dbde688  pop rsi
00007d248dbde689  pop rdi
00007d248dbde68a  pop rdx
00007d248dbde68b  pop rcx
00007d248dbde68c  pop rax
00007d248dbde68d  add rsp, 0x08
00007d248dbde691  jmp 0x00007D248DBDC15E
00007d248dbde696  sub rsp, 0x08
00007d248dbde69a  push rax
00007d248dbde69b  push rcx
00007d248dbde69c  push rdx
00007d248dbde69d  push rdi
00007d248dbde69e  push rsi
00007d248dbde69f  push r8
00007d248dbde6a1  push r9
00007d248dbde6a3  push r10
00007d248dbde6a5  push r11
00007d248dbde6a7  sub rsp, 0xF0
00007d248dbde6ae  vmovaps [rsp], xmm0
00007d248dbde6b3  vmovaps [rsp+0x10], xmm1
00007d248dbde6b9  vmovaps [rsp+0x20], xmm2
00007d248dbde6bf  vmovaps [rsp+0x30], xmm3
00007d248dbde6c5  vmovaps [rsp+0x40], xmm4
00007d248dbde6cb  vmovaps [rsp+0x50], xmm5
00007d248dbde6d1  vmovaps [rsp+0x60], xmm6
00007d248dbde6d7  vmovaps [rsp+0x70], xmm7
00007d248dbde6dd  vmovaps [rsp+0x80], xmm8
00007d248dbde6e6  vmovaps [rsp+0x90], xmm10
00007d248dbde6ef  vmovaps [rsp+0xA0], xmm11
00007d248dbde6f8  vmovaps [rsp+0xB0], xmm12
00007d248dbde701  vmovaps [rsp+0xC0], xmm13
00007d248dbde70a  vmovaps [rsp+0xD0], xmm14
00007d248dbde713  vmovaps [rsp+0xE0], xmm15
00007d248dbde71c  sub rsp, 0x30
00007d248dbde720  movaps [rsp], xmm9
00007d248dbde725  movaps [rsp+0x10], xmm3
00007d248dbde72a  movaps [rsp+0x20], xmm1
00007d248dbde72f  lea rdi, [rsp]
00007d248dbde733  mov esi, 0x00
00007d248dbde738  mov rax, 0x5BCEEF236530
00007d248dbde742  call rax
00007d248dbde744  movaps xmm9, [rsp]
00007d248dbde749  add rsp, 0x30
00007d248dbde74d  vmovaps xmm0, [rsp]
00007d248dbde752  vmovaps xmm1, [rsp+0x10]
00007d248dbde758  vmovaps xmm2, [rsp+0x20]
00007d248dbde75e  vmovaps xmm3, [rsp+0x30]
00007d248dbde764  vmovaps xmm4, [rsp+0x40]
00007d248dbde76a  vmovaps xmm5, [rsp+0x50]
00007d248dbde770  vmovaps xmm6, [rsp+0x60]
00007d248dbde776  vmovaps xmm7, [rsp+0x70]
00007d248dbde77c  vmovaps xmm8, [rsp+0x80]
00007d248dbde785  vmovaps xmm10, [rsp+0x90]
00007d248dbde78e  vmovaps xmm11, [rsp+0xA0]
00007d248dbde797  vmovaps xmm12, [rsp+0xB0]
00007d248dbde7a0  vmovaps xmm13, [rsp+0xC0]
00007d248dbde7a9  vmovaps xmm14, [rsp+0xD0]
00007d248dbde7b2  vmovaps xmm15, [rsp+0xE0]
00007d248dbde7bb  add rsp, 0xF0
00007d248dbde7c2  pop r11
00007d248dbde7c4  pop r10
00007d248dbde7c6  pop r9
00007d248dbde7c8  pop r8
00007d248dbde7ca  pop rsi
00007d248dbde7cb  pop rdi
00007d248dbde7cc  pop rdx
00007d248dbde7cd  pop rcx
00007d248dbde7ce  pop rax
00007d248dbde7cf  add rsp, 0x08
00007d248dbde7d3  jmp 0x00007D248DBDC1AA
00007d248dbde7d8  call 0x00007D248DAB52F0
00007d248dbde7dd  jmp 0x00007D248DBDC1B7
00007d248dbde7e2  sub rsp, 0x08
00007d248dbde7e6  push rax
00007d248dbde7e7  push rcx
00007d248dbde7e8  push rdx
00007d248dbde7e9  push rdi
00007d248dbde7ea  push rsi
00007d248dbde7eb  push r8
00007d248dbde7ed  push r9
00007d248dbde7ef  push r10
00007d248dbde7f1  push r11
00007d248dbde7f3  sub rsp, 0xF0
00007d248dbde7fa  vmovaps [rsp], xmm0
00007d248dbde7ff  vmovaps [rsp+0x10], xmm1
00007d248dbde805  vmovaps [rsp+0x20], xmm2
00007d248dbde80b  vmovaps [rsp+0x30], xmm3
00007d248dbde811  vmovaps [rsp+0x40], xmm4
00007d248dbde817  vmovaps [rsp+0x50], xmm5
00007d248dbde81d  vmovaps [rsp+0x60], xmm6
00007d248dbde823  vmovaps [rsp+0x70], xmm7
00007d248dbde829  vmovaps [rsp+0x80], xmm8
00007d248dbde832  vmovaps [rsp+0x90], xmm9
00007d248dbde83b  vmovaps [rsp+0xA0], xmm10
00007d248dbde844  vmovaps [rsp+0xB0], xmm11
00007d248dbde84d  vmovaps [rsp+0xC0], xmm12
00007d248dbde856  vmovaps [rsp+0xD0], xmm13
00007d248dbde85f  vmovaps [rsp+0xE0], xmm14
00007d248dbde868  sub rsp, 0x30
00007d248dbde86c  movaps [rsp], xmm15
00007d248dbde871  movaps [rsp+0x10], xmm3
00007d248dbde876  movaps [rsp+0x20], xmm7
00007d248dbde87b  lea rdi, [rsp]
00007d248dbde87f  mov esi, 0x00
00007d248dbde884  mov rax, 0x5BCEEF236530
00007d248dbde88e  call rax
00007d248dbde890  movaps xmm15, [rsp]
00007d248dbde895  add rsp, 0x30
00007d248dbde899  vmovaps xmm0, [rsp]
00007d248dbde89e  vmovaps xmm1, [rsp+0x10]
00007d248dbde8a4  vmovaps xmm2, [rsp+0x20]
00007d248dbde8aa  vmovaps xmm3, [rsp+0x30]
00007d248dbde8b0  vmovaps xmm4, [rsp+0x40]
00007d248dbde8b6  vmovaps xmm5, [rsp+0x50]
00007d248dbde8bc  vmovaps xmm6, [rsp+0x60]
00007d248dbde8c2  vmovaps xmm7, [rsp+0x70]
00007d248dbde8c8  vmovaps xmm8, [rsp+0x80]
00007d248dbde8d1  vmovaps xmm9, [rsp+0x90]
00007d248dbde8da  vmovaps xmm10, [rsp+0xA0]
00007d248dbde8e3  vmovaps xmm11, [rsp+0xB0]
00007d248dbde8ec  vmovaps xmm12, [rsp+0xC0]
00007d248dbde8f5  vmovaps xmm13, [rsp+0xD0]
00007d248dbde8fe  vmovaps xmm14, [rsp+0xE0]
00007d248dbde907  add rsp, 0xF0
00007d248dbde90e  pop r11
00007d248dbde910  pop r10
00007d248dbde912  pop r9
00007d248dbde914  pop r8
00007d248dbde916  pop rsi
00007d248dbde917  pop rdi
00007d248dbde918  pop rdx
00007d248dbde919  pop rcx
00007d248dbde91a  pop rax
00007d248dbde91b  add rsp, 0x08
00007d248dbde91f  jmp 0x00007D248DBDC1E3
00007d248dbde924  sub rsp, 0x08
00007d248dbde928  push rax
00007d248dbde929  push rcx
00007d248dbde92a  push rdx
00007d248dbde92b  push rdi
00007d248dbde92c  push rsi
00007d248dbde92d  push r8
00007d248dbde92f  push r9
00007d248dbde931  push r10
00007d248dbde933  push r11
00007d248dbde935  sub rsp, 0xF0
00007d248dbde93c  vmovaps [rsp], xmm0
00007d248dbde941  vmovaps [rsp+0x10], xmm1
00007d248dbde947  vmovaps [rsp+0x20], xmm2
00007d248dbde94d  vmovaps [rsp+0x30], xmm4
00007d248dbde953  vmovaps [rsp+0x40], xmm5
00007d248dbde959  vmovaps [rsp+0x50], xmm6
00007d248dbde95f  vmovaps [rsp+0x60], xmm7
00007d248dbde965  vmovaps [rsp+0x70], xmm8
00007d248dbde96b  vmovaps [rsp+0x80], xmm9
00007d248dbde974  vmovaps [rsp+0x90], xmm10
00007d248dbde97d  vmovaps [rsp+0xA0], xmm11
00007d248dbde986  vmovaps [rsp+0xB0], xmm12
00007d248dbde98f  vmovaps [rsp+0xC0], xmm13
00007d248dbde998  vmovaps [rsp+0xD0], xmm14
00007d248dbde9a1  vmovaps [rsp+0xE0], xmm15
00007d248dbde9aa  sub rsp, 0x30
00007d248dbde9ae  movaps [rsp], xmm3
00007d248dbde9b2  movaps [rsp+0x10], xmm1
00007d248dbde9b7  movaps [rsp+0x20], xmm15
00007d248dbde9bd  lea rdi, [rsp]
00007d248dbde9c1  mov esi, 0x00
00007d248dbde9c6  mov rax, 0x5BCEEF236530
00007d248dbde9d0  call rax
00007d248dbde9d2  movaps xmm3, [rsp]
00007d248dbde9d6  add rsp, 0x30
00007d248dbde9da  vmovaps xmm0, [rsp]
00007d248dbde9df  vmovaps xmm1, [rsp+0x10]
00007d248dbde9e5  vmovaps xmm2, [rsp+0x20]
00007d248dbde9eb  vmovaps xmm4, [rsp+0x30]
00007d248dbde9f1  vmovaps xmm5, [rsp+0x40]
00007d248dbde9f7  vmovaps xmm6, [rsp+0x50]
00007d248dbde9fd  vmovaps xmm7, [rsp+0x60]
00007d248dbdea03  vmovaps xmm8, [rsp+0x70]
00007d248dbdea09  vmovaps xmm9, [rsp+0x80]
00007d248dbdea12  vmovaps xmm10, [rsp+0x90]
00007d248dbdea1b  vmovaps xmm11, [rsp+0xA0]
00007d248dbdea24  vmovaps xmm12, [rsp+0xB0]
00007d248dbdea2d  vmovaps xmm13, [rsp+0xC0]
00007d248dbdea36  vmovaps xmm14, [rsp+0xD0]
00007d248dbdea3f  vmovaps xmm15, [rsp+0xE0]
00007d248dbdea48  add rsp, 0xF0
00007d248dbdea4f  pop r11
00007d248dbdea51  pop r10
00007d248dbdea53  pop r9
00007d248dbdea55  pop r8
00007d248dbdea57  pop rsi
00007d248dbdea58  pop rdi
00007d248dbdea59  pop rdx
00007d248dbdea5a  pop rcx
00007d248dbdea5b  pop rax
00007d248dbdea5c  add rsp, 0x08
00007d248dbdea60  jmp 0x00007D248DBDC272
00007d248dbdea65  call 0x00007D248DAB52F0
00007d248dbdea6a  jmp 0x00007D248DBDC27C
00007d248dbdea6f  sub rsp, 0x08
00007d248dbdea73  push rax
00007d248dbdea74  push rcx
00007d248dbdea75  push rdx
00007d248dbdea76  push rdi
00007d248dbdea77  push rsi
00007d248dbdea78  push r8
00007d248dbdea7a  push r9
00007d248dbdea7c  push r10
00007d248dbdea7e  push r11
00007d248dbdea80  sub rsp, 0xF0
00007d248dbdea87  vmovaps [rsp], xmm0
00007d248dbdea8c  vmovaps [rsp+0x10], xmm1
00007d248dbdea92  vmovaps [rsp+0x20], xmm2
00007d248dbdea98  vmovaps [rsp+0x30], xmm3
00007d248dbdea9e  vmovaps [rsp+0x40], xmm4
00007d248dbdeaa4  vmovaps [rsp+0x50], xmm5
00007d248dbdeaaa  vmovaps [rsp+0x60], xmm6
00007d248dbdeab0  vmovaps [rsp+0x70], xmm7
00007d248dbdeab6  vmovaps [rsp+0x80], xmm8
00007d248dbdeabf  vmovaps [rsp+0x90], xmm9
00007d248dbdeac8  vmovaps [rsp+0xA0], xmm10
00007d248dbdead1  vmovaps [rsp+0xB0], xmm11
00007d248dbdeada  vmovaps [rsp+0xC0], xmm12
00007d248dbdeae3  vmovaps [rsp+0xD0], xmm13
00007d248dbdeaec  vmovaps [rsp+0xE0], xmm14
00007d248dbdeaf5  sub rsp, 0x30
00007d248dbdeaf9  movaps [rsp], xmm15
00007d248dbdeafe  movaps [rsp+0x10], xmm14
00007d248dbdeb04  movaps [rsp+0x20], xmm4
00007d248dbdeb09  lea rdi, [rsp]
00007d248dbdeb0d  mov esi, 0x00
00007d248dbdeb12  mov rax, 0x5BCEEF236530
00007d248dbdeb1c  call rax
00007d248dbdeb1e  movaps xmm15, [rsp]
00007d248dbdeb23  add rsp, 0x30
00007d248dbdeb27  vmovaps xmm0, [rsp]
00007d248dbdeb2c  vmovaps xmm1, [rsp+0x10]
00007d248dbdeb32  vmovaps xmm2, [rsp+0x20]
00007d248dbdeb38  vmovaps xmm3, [rsp+0x30]
00007d248dbdeb3e  vmovaps xmm4, [rsp+0x40]
00007d248dbdeb44  vmovaps xmm5, [rsp+0x50]
00007d248dbdeb4a  vmovaps xmm6, [rsp+0x60]
00007d248dbdeb50  vmovaps xmm7, [rsp+0x70]
00007d248dbdeb56  vmovaps xmm8, [rsp+0x80]
00007d248dbdeb5f  vmovaps xmm9, [rsp+0x90]
00007d248dbdeb68  vmovaps xmm10, [rsp+0xA0]
00007d248dbdeb71  vmovaps xmm11, [rsp+0xB0]
00007d248dbdeb7a  vmovaps xmm12, [rsp+0xC0]
00007d248dbdeb83  vmovaps xmm13, [rsp+0xD0]
00007d248dbdeb8c  vmovaps xmm14, [rsp+0xE0]
00007d248dbdeb95  add rsp, 0xF0
00007d248dbdeb9c  pop r11
00007d248dbdeb9e  pop r10
00007d248dbdeba0  pop r9
00007d248dbdeba2  pop r8
00007d248dbdeba4  pop rsi
00007d248dbdeba5  pop rdi
00007d248dbdeba6  pop rdx
00007d248dbdeba7  pop rcx
00007d248dbdeba8  pop rax
00007d248dbdeba9  add rsp, 0x08
00007d248dbdebad  jmp 0x00007D248DBDC2AA
00007d248dbdebb2  sub rsp, 0x08
00007d248dbdebb6  push rax
00007d248dbdebb7  push rcx
00007d248dbdebb8  push rdx
00007d248dbdebb9  push rdi
00007d248dbdebba  push rsi
00007d248dbdebbb  push r8
00007d248dbdebbd  push r9
00007d248dbdebbf  push r10
00007d248dbdebc1  push r11
00007d248dbdebc3  sub rsp, 0xF0
00007d248dbdebca  vmovaps [rsp], xmm0
00007d248dbdebcf  vmovaps [rsp+0x10], xmm1
00007d248dbdebd5  vmovaps [rsp+0x20], xmm2
00007d248dbdebdb  vmovaps [rsp+0x30], xmm3
00007d248dbdebe1  vmovaps [rsp+0x40], xmm4
00007d248dbdebe7  vmovaps [rsp+0x50], xmm5
00007d248dbdebed  vmovaps [rsp+0x60], xmm6
00007d248dbdebf3  vmovaps [rsp+0x70], xmm7
00007d248dbdebf9  vmovaps [rsp+0x80], xmm8
00007d248dbdec02  vmovaps [rsp+0x90], xmm9
00007d248dbdec0b  vmovaps [rsp+0xA0], xmm10
00007d248dbdec14  vmovaps [rsp+0xB0], xmm11
00007d248dbdec1d  vmovaps [rsp+0xC0], xmm12
00007d248dbdec26  vmovaps [rsp+0xD0], xmm13
00007d248dbdec2f  vmovaps [rsp+0xE0], xmm15
00007d248dbdec38  sub rsp, 0x30
00007d248dbdec3c  movaps [rsp], xmm14
00007d248dbdec41  movaps [rsp+0x10], xmm2
00007d248dbdec46  movaps [rsp+0x20], xmm1
00007d248dbdec4b  lea rdi, [rsp]
00007d248dbdec4f  mov esi, 0x00
00007d248dbdec54  mov rax, 0x5BCEEF236530
00007d248dbdec5e  call rax
00007d248dbdec60  movaps xmm14, [rsp]
00007d248dbdec65  add rsp, 0x30
00007d248dbdec69  vmovaps xmm0, [rsp]
00007d248dbdec6e  vmovaps xmm1, [rsp+0x10]
00007d248dbdec74  vmovaps xmm2, [rsp+0x20]
00007d248dbdec7a  vmovaps xmm3, [rsp+0x30]
00007d248dbdec80  vmovaps xmm4, [rsp+0x40]
00007d248dbdec86  vmovaps xmm5, [rsp+0x50]
00007d248dbdec8c  vmovaps xmm6, [rsp+0x60]
00007d248dbdec92  vmovaps xmm7, [rsp+0x70]
00007d248dbdec98  vmovaps xmm8, [rsp+0x80]
00007d248dbdeca1  vmovaps xmm9, [rsp+0x90]
00007d248dbdecaa  vmovaps xmm10, [rsp+0xA0]
00007d248dbdecb3  vmovaps xmm11, [rsp+0xB0]
00007d248dbdecbc  vmovaps xmm12, [rsp+0xC0]
00007d248dbdecc5  vmovaps xmm13, [rsp+0xD0]
00007d248dbdecce  vmovaps xmm15, [rsp+0xE0]
00007d248dbdecd7  add rsp, 0xF0
00007d248dbdecde  pop r11
00007d248dbdece0  pop r10
00007d248dbdece2  pop r9
00007d248dbdece4  pop r8
00007d248dbdece6  pop rsi
00007d248dbdece7  pop rdi
00007d248dbdece8  pop rdx
00007d248dbdece9  pop rcx
00007d248dbdecea  pop rax
00007d248dbdeceb  add rsp, 0x08
00007d248dbdecef  jmp 0x00007D248DBDC2D0
00007d248dbdecf4  sub rsp, 0x08
00007d248dbdecf8  push rax
00007d248dbdecf9  push rcx
00007d248dbdecfa  push rdx
00007d248dbdecfb  push rdi
00007d248dbdecfc  push rsi
00007d248dbdecfd  push r8
00007d248dbdecff  push r9
00007d248dbded01  push r10
00007d248dbded03  push r11
00007d248dbded05  sub rsp, 0xF0
00007d248dbded0c  vmovaps [rsp], xmm0
00007d248dbded11  vmovaps [rsp+0x10], xmm2
00007d248dbded17  vmovaps [rsp+0x20], xmm3
00007d248dbded1d  vmovaps [rsp+0x30], xmm4
00007d248dbded23  vmovaps [rsp+0x40], xmm5
00007d248dbded29  vmovaps [rsp+0x50], xmm6
00007d248dbded2f  vmovaps [rsp+0x60], xmm7
00007d248dbded35  vmovaps [rsp+0x70], xmm8
00007d248dbded3b  vmovaps [rsp+0x80], xmm9
00007d248dbded44  vmovaps [rsp+0x90], xmm10
00007d248dbded4d  vmovaps [rsp+0xA0], xmm11
00007d248dbded56  vmovaps [rsp+0xB0], xmm12
00007d248dbded5f  vmovaps [rsp+0xC0], xmm13
00007d248dbded68  vmovaps [rsp+0xD0], xmm14
00007d248dbded71  vmovaps [rsp+0xE0], xmm15
00007d248dbded7a  sub rsp, 0x30
00007d248dbded7e  movaps [rsp], xmm1
00007d248dbded82  movaps [rsp+0x10], xmm4
00007d248dbded87  movaps [rsp+0x20], xmm9
00007d248dbded8d  lea rdi, [rsp]
00007d248dbded91  mov esi, 0x00
00007d248dbded96  mov rax, 0x5BCEEF236530
00007d248dbdeda0  call rax
00007d248dbdeda2  movaps xmm1, [rsp]
00007d248dbdeda6  add rsp, 0x30
00007d248dbdedaa  vmovaps xmm0, [rsp]
00007d248dbdedaf  vmovaps xmm2, [rsp+0x10]
00007d248dbdedb5  vmovaps xmm3, [rsp+0x20]
00007d248dbdedbb  vmovaps xmm4, [rsp+0x30]
00007d248dbdedc1  vmovaps xmm5, [rsp+0x40]
00007d248dbdedc7  vmovaps xmm6, [rsp+0x50]
00007d248dbdedcd  vmovaps xmm7, [rsp+0x60]
00007d248dbdedd3  vmovaps xmm8, [rsp+0x70]
00007d248dbdedd9  vmovaps xmm9, [rsp+0x80]
00007d248dbdede2  vmovaps xmm10, [rsp+0x90]
00007d248dbdedeb  vmovaps xmm11, [rsp+0xA0]
00007d248dbdedf4  vmovaps xmm12, [rsp+0xB0]
00007d248dbdedfd  vmovaps xmm13, [rsp+0xC0]
00007d248dbdee06  vmovaps xmm14, [rsp+0xD0]
00007d248dbdee0f  vmovaps xmm15, [rsp+0xE0]
00007d248dbdee18  add rsp, 0xF0
00007d248dbdee1f  pop r11
00007d248dbdee21  pop r10
00007d248dbdee23  pop r9
00007d248dbdee25  pop r8
00007d248dbdee27  pop rsi
00007d248dbdee28  pop rdi
00007d248dbdee29  pop rdx
00007d248dbdee2a  pop rcx
00007d248dbdee2b  pop rax
00007d248dbdee2c  add rsp, 0x08
00007d248dbdee30  jmp 0x00007D248DBDC2EE
00007d248dbdee35  sub rsp, 0x08
00007d248dbdee39  push rax
00007d248dbdee3a  push rcx
00007d248dbdee3b  push rdx
00007d248dbdee3c  push rdi
00007d248dbdee3d  push rsi
00007d248dbdee3e  push r8
00007d248dbdee40  push r9
00007d248dbdee42  push r10
00007d248dbdee44  push r11
00007d248dbdee46  sub rsp, 0xF0
00007d248dbdee4d  vmovaps [rsp], xmm0
00007d248dbdee52  vmovaps [rsp+0x10], xmm1
00007d248dbdee58  vmovaps [rsp+0x20], xmm2
00007d248dbdee5e  vmovaps [rsp+0x30], xmm3
00007d248dbdee64  vmovaps [rsp+0x40], xmm5
00007d248dbdee6a  vmovaps [rsp+0x50], xmm6
00007d248dbdee70  vmovaps [rsp+0x60], xmm7
00007d248dbdee76  vmovaps [rsp+0x70], xmm8
00007d248dbdee7c  vmovaps [rsp+0x80], xmm9
00007d248dbdee85  vmovaps [rsp+0x90], xmm10
00007d248dbdee8e  vmovaps [rsp+0xA0], xmm11
00007d248dbdee97  vmovaps [rsp+0xB0], xmm12
00007d248dbdeea0  vmovaps [rsp+0xC0], xmm13
00007d248dbdeea9  vmovaps [rsp+0xD0], xmm14
00007d248dbdeeb2  vmovaps [rsp+0xE0], xmm15
00007d248dbdeebb  sub rsp, 0x30
00007d248dbdeebf  movaps [rsp], xmm4
00007d248dbdeec3  movaps [rsp+0x10], xmm2
00007d248dbdeec8  movaps [rsp+0x20], xmm9
00007d248dbdeece  lea rdi, [rsp]
00007d248dbdeed2  mov esi, 0x00
00007d248dbdeed7  mov rax, 0x5BCEEF236530
00007d248dbdeee1  call rax
00007d248dbdeee3  movaps xmm4, [rsp]
00007d248dbdeee7  add rsp, 0x30
00007d248dbdeeeb  vmovaps xmm0, [rsp]
00007d248dbdeef0  vmovaps xmm1, [rsp+0x10]
00007d248dbdeef6  vmovaps xmm2, [rsp+0x20]
00007d248dbdeefc  vmovaps xmm3, [rsp+0x30]
00007d248dbdef02  vmovaps xmm5, [rsp+0x40]
00007d248dbdef08  vmovaps xmm6, [rsp+0x50]
00007d248dbdef0e  vmovaps xmm7, [rsp+0x60]
00007d248dbdef14  vmovaps xmm8, [rsp+0x70]
00007d248dbdef1a  vmovaps xmm9, [rsp+0x80]
00007d248dbdef23  vmovaps xmm10, [rsp+0x90]
00007d248dbdef2c  vmovaps xmm11, [rsp+0xA0]
00007d248dbdef35  vmovaps xmm12, [rsp+0xB0]
00007d248dbdef3e  vmovaps xmm13, [rsp+0xC0]
00007d248dbdef47  vmovaps xmm14, [rsp+0xD0]
00007d248dbdef50  vmovaps xmm15, [rsp+0xE0]
00007d248dbdef59  add rsp, 0xF0
00007d248dbdef60  pop r11
00007d248dbdef62  pop r10
00007d248dbdef64  pop r9
00007d248dbdef66  pop r8
00007d248dbdef68  pop rsi
00007d248dbdef69  pop rdi
00007d248dbdef6a  pop rdx
00007d248dbdef6b  pop rcx
00007d248dbdef6c  pop rax
00007d248dbdef6d  add rsp, 0x08
00007d248dbdef71  jmp 0x00007D248DBDC31E
00007d248dbdef76  sub rsp, 0x08
00007d248dbdef7a  push rax
00007d248dbdef7b  push rcx
00007d248dbdef7c  push rdx
00007d248dbdef7d  push rdi
00007d248dbdef7e  push rsi
00007d248dbdef7f  push r8
00007d248dbdef81  push r9
00007d248dbdef83  push r10
00007d248dbdef85  push r11
00007d248dbdef87  sub rsp, 0xF0
00007d248dbdef8e  vmovaps [rsp], xmm0
00007d248dbdef93  vmovaps [rsp+0x10], xmm1
00007d248dbdef99  vmovaps [rsp+0x20], xmm2
00007d248dbdef9f  vmovaps [rsp+0x30], xmm3
00007d248dbdefa5  vmovaps [rsp+0x40], xmm4
00007d248dbdefab  vmovaps [rsp+0x50], xmm5
00007d248dbdefb1  vmovaps [rsp+0x60], xmm6
00007d248dbdefb7  vmovaps [rsp+0x70], xmm7
00007d248dbdefbd  vmovaps [rsp+0x80], xmm8
00007d248dbdefc6  vmovaps [rsp+0x90], xmm10
00007d248dbdefcf  vmovaps [rsp+0xA0], xmm11
00007d248dbdefd8  vmovaps [rsp+0xB0], xmm12
00007d248dbdefe1  vmovaps [rsp+0xC0], xmm13
00007d248dbdefea  vmovaps [rsp+0xD0], xmm14
00007d248dbdeff3  vmovaps [rsp+0xE0], xmm15
00007d248dbdeffc  sub rsp, 0x30
00007d248dbdf000  movaps [rsp], xmm9
00007d248dbdf005  movaps [rsp+0x10], xmm2
00007d248dbdf00a  movaps [rsp+0x20], xmm1
00007d248dbdf00f  lea rdi, [rsp]
00007d248dbdf013  mov esi, 0x00
00007d248dbdf018  mov rax, 0x5BCEEF236530
00007d248dbdf022  call rax
00007d248dbdf024  movaps xmm9, [rsp]
00007d248dbdf029  add rsp, 0x30
00007d248dbdf02d  vmovaps xmm0, [rsp]
00007d248dbdf032  vmovaps xmm1, [rsp+0x10]
00007d248dbdf038  vmovaps xmm2, [rsp+0x20]
00007d248dbdf03e  vmovaps xmm3, [rsp+0x30]
00007d248dbdf044  vmovaps xmm4, [rsp+0x40]
00007d248dbdf04a  vmovaps xmm5, [rsp+0x50]
00007d248dbdf050  vmovaps xmm6, [rsp+0x60]
00007d248dbdf056  vmovaps xmm7, [rsp+0x70]
00007d248dbdf05c  vmovaps xmm8, [rsp+0x80]
00007d248dbdf065  vmovaps xmm10, [rsp+0x90]
00007d248dbdf06e  vmovaps xmm11, [rsp+0xA0]
00007d248dbdf077  vmovaps xmm12, [rsp+0xB0]
00007d248dbdf080  vmovaps xmm13, [rsp+0xC0]
00007d248dbdf089  vmovaps xmm14, [rsp+0xD0]
00007d248dbdf092  vmovaps xmm15, [rsp+0xE0]
00007d248dbdf09b  add rsp, 0xF0
00007d248dbdf0a2  pop r11
00007d248dbdf0a4  pop r10
00007d248dbdf0a6  pop r9
00007d248dbdf0a8  pop r8
00007d248dbdf0aa  pop rsi
00007d248dbdf0ab  pop rdi
00007d248dbdf0ac  pop rdx
00007d248dbdf0ad  pop rcx
00007d248dbdf0ae  pop rax
00007d248dbdf0af  add rsp, 0x08
00007d248dbdf0b3  jmp 0x00007D248DBDC354
00007d248dbdf0b8  sub rsp, 0x08
00007d248dbdf0bc  push rax
00007d248dbdf0bd  push rcx
00007d248dbdf0be  push rdx
00007d248dbdf0bf  push rdi
00007d248dbdf0c0  push rsi
00007d248dbdf0c1  push r8
00007d248dbdf0c3  push r9
00007d248dbdf0c5  push r10
00007d248dbdf0c7  push r11
00007d248dbdf0c9  sub rsp, 0xF0
00007d248dbdf0d0  vmovaps [rsp], xmm0
00007d248dbdf0d5  vmovaps [rsp+0x10], xmm2
00007d248dbdf0db  vmovaps [rsp+0x20], xmm3
00007d248dbdf0e1  vmovaps [rsp+0x30], xmm4
00007d248dbdf0e7  vmovaps [rsp+0x40], xmm5
00007d248dbdf0ed  vmovaps [rsp+0x50], xmm6
00007d248dbdf0f3  vmovaps [rsp+0x60], xmm7
00007d248dbdf0f9  vmovaps [rsp+0x70], xmm8
00007d248dbdf0ff  vmovaps [rsp+0x80], xmm9
00007d248dbdf108  vmovaps [rsp+0x90], xmm10
00007d248dbdf111  vmovaps [rsp+0xA0], xmm11
00007d248dbdf11a  vmovaps [rsp+0xB0], xmm12
00007d248dbdf123  vmovaps [rsp+0xC0], xmm13
00007d248dbdf12c  vmovaps [rsp+0xD0], xmm14
00007d248dbdf135  vmovaps [rsp+0xE0], xmm15
00007d248dbdf13e  sub rsp, 0x30
00007d248dbdf142  movaps [rsp], xmm1
00007d248dbdf146  movaps [rsp+0x10], xmm15
00007d248dbdf14c  movaps [rsp+0x20], xmm6
00007d248dbdf151  lea rdi, [rsp]
00007d248dbdf155  mov esi, 0x00
00007d248dbdf15a  mov rax, 0x5BCEEF236530
00007d248dbdf164  call rax
00007d248dbdf166  movaps xmm1, [rsp]
00007d248dbdf16a  add rsp, 0x30
00007d248dbdf16e  vmovaps xmm0, [rsp]
00007d248dbdf173  vmovaps xmm2, [rsp+0x10]
00007d248dbdf179  vmovaps xmm3, [rsp+0x20]
00007d248dbdf17f  vmovaps xmm4, [rsp+0x30]
00007d248dbdf185  vmovaps xmm5, [rsp+0x40]
00007d248dbdf18b  vmovaps xmm6, [rsp+0x50]
00007d248dbdf191  vmovaps xmm7, [rsp+0x60]
00007d248dbdf197  vmovaps xmm8, [rsp+0x70]
00007d248dbdf19d  vmovaps xmm9, [rsp+0x80]
00007d248dbdf1a6  vmovaps xmm10, [rsp+0x90]
00007d248dbdf1af  vmovaps xmm11, [rsp+0xA0]
00007d248dbdf1b8  vmovaps xmm12, [rsp+0xB0]
00007d248dbdf1c1  vmovaps xmm13, [rsp+0xC0]
00007d248dbdf1ca  vmovaps xmm14, [rsp+0xD0]
00007d248dbdf1d3  vmovaps xmm15, [rsp+0xE0]
00007d248dbdf1dc  add rsp, 0xF0
00007d248dbdf1e3  pop r11
00007d248dbdf1e5  pop r10
00007d248dbdf1e7  pop r9
00007d248dbdf1e9  pop r8
00007d248dbdf1eb  pop rsi
00007d248dbdf1ec  pop rdi
00007d248dbdf1ed  pop rdx
00007d248dbdf1ee  pop rcx
00007d248dbdf1ef  pop rax
00007d248dbdf1f0  add rsp, 0x08
00007d248dbdf1f4  jmp 0x00007D248DBDC375
00007d248dbdf1f9  sub rsp, 0x08
00007d248dbdf1fd  push rax
00007d248dbdf1fe  push rcx
00007d248dbdf1ff  push rdx
00007d248dbdf200  push rdi
00007d248dbdf201  push rsi
00007d248dbdf202  push r8
00007d248dbdf204  push r9
00007d248dbdf206  push r10
00007d248dbdf208  push r11
00007d248dbdf20a  sub rsp, 0xF0
00007d248dbdf211  vmovaps [rsp], xmm0
00007d248dbdf216  vmovaps [rsp+0x10], xmm1
00007d248dbdf21c  vmovaps [rsp+0x20], xmm2
00007d248dbdf222  vmovaps [rsp+0x30], xmm3
00007d248dbdf228  vmovaps [rsp+0x40], xmm4
00007d248dbdf22e  vmovaps [rsp+0x50], xmm5
00007d248dbdf234  vmovaps [rsp+0x60], xmm6
00007d248dbdf23a  vmovaps [rsp+0x70], xmm7
00007d248dbdf240  vmovaps [rsp+0x80], xmm8
00007d248dbdf249  vmovaps [rsp+0x90], xmm9
00007d248dbdf252  vmovaps [rsp+0xA0], xmm10
00007d248dbdf25b  vmovaps [rsp+0xB0], xmm11
00007d248dbdf264  vmovaps [rsp+0xC0], xmm12
00007d248dbdf26d  vmovaps [rsp+0xD0], xmm13
00007d248dbdf276  vmovaps [rsp+0xE0], xmm14
00007d248dbdf27f  sub rsp, 0x30
00007d248dbdf283  movaps [rsp], xmm15
00007d248dbdf288  movaps [rsp+0x10], xmm5
00007d248dbdf28d  movaps [rsp+0x20], xmm3
00007d248dbdf292  lea rdi, [rsp]
00007d248dbdf296  mov esi, 0x00
00007d248dbdf29b  mov rax, 0x5BCEEF236530
00007d248dbdf2a5  call rax
00007d248dbdf2a7  movaps xmm15, [rsp]
00007d248dbdf2ac  add rsp, 0x30
00007d248dbdf2b0  vmovaps xmm0, [rsp]
00007d248dbdf2b5  vmovaps xmm1, [rsp+0x10]
00007d248dbdf2bb  vmovaps xmm2, [rsp+0x20]
00007d248dbdf2c1  vmovaps xmm3, [rsp+0x30]
00007d248dbdf2c7  vmovaps xmm4, [rsp+0x40]
00007d248dbdf2cd  vmovaps xmm5, [rsp+0x50]
00007d248dbdf2d3  vmovaps xmm6, [rsp+0x60]
00007d248dbdf2d9  vmovaps xmm7, [rsp+0x70]
00007d248dbdf2df  vmovaps xmm8, [rsp+0x80]
00007d248dbdf2e8  vmovaps xmm9, [rsp+0x90]
00007d248dbdf2f1  vmovaps xmm10, [rsp+0xA0]
00007d248dbdf2fa  vmovaps xmm11, [rsp+0xB0]
00007d248dbdf303  vmovaps xmm12, [rsp+0xC0]
00007d248dbdf30c  vmovaps xmm13, [rsp+0xD0]
00007d248dbdf315  vmovaps xmm14, [rsp+0xE0]
00007d248dbdf31e  add rsp, 0xF0
00007d248dbdf325  pop r11
00007d248dbdf327  pop r10
00007d248dbdf329  pop r9
00007d248dbdf32b  pop r8
00007d248dbdf32d  pop rsi
00007d248dbdf32e  pop rdi
00007d248dbdf32f  pop rdx
00007d248dbdf330  pop rcx
00007d248dbdf331  pop rax
00007d248dbdf332  add rsp, 0x08
00007d248dbdf336  jmp 0x00007D248DBDC38F
00007d248dbdf33b  sub rsp, 0x08
00007d248dbdf33f  push rax
00007d248dbdf340  push rcx
00007d248dbdf341  push rdx
00007d248dbdf342  push rdi
00007d248dbdf343  push rsi
00007d248dbdf344  push r8
00007d248dbdf346  push r9
00007d248dbdf348  push r10
00007d248dbdf34a  push r11
00007d248dbdf34c  sub rsp, 0xF0
00007d248dbdf353  vmovaps [rsp], xmm0
00007d248dbdf358  vmovaps [rsp+0x10], xmm1
00007d248dbdf35e  vmovaps [rsp+0x20], xmm2
00007d248dbdf364  vmovaps [rsp+0x30], xmm3
00007d248dbdf36a  vmovaps [rsp+0x40], xmm4
00007d248dbdf370  vmovaps [rsp+0x50], xmm6
00007d248dbdf376  vmovaps [rsp+0x60], xmm7
00007d248dbdf37c  vmovaps [rsp+0x70], xmm8
00007d248dbdf382  vmovaps [rsp+0x80], xmm9
00007d248dbdf38b  vmovaps [rsp+0x90], xmm10
00007d248dbdf394  vmovaps [rsp+0xA0], xmm11
00007d248dbdf39d  vmovaps [rsp+0xB0], xmm12
00007d248dbdf3a6  vmovaps [rsp+0xC0], xmm13
00007d248dbdf3af  vmovaps [rsp+0xD0], xmm14
00007d248dbdf3b8  vmovaps [rsp+0xE0], xmm15
00007d248dbdf3c1  sub rsp, 0x30
00007d248dbdf3c5  movaps [rsp], xmm5
00007d248dbdf3c9  movaps [rsp+0x10], xmm8
00007d248dbdf3cf  movaps [rsp+0x20], xmm6
00007d248dbdf3d4  lea rdi, [rsp]
00007d248dbdf3d8  mov esi, 0x00
00007d248dbdf3dd  mov rax, 0x5BCEEF236530
00007d248dbdf3e7  call rax
00007d248dbdf3e9  movaps xmm5, [rsp]
00007d248dbdf3ed  add rsp, 0x30
00007d248dbdf3f1  vmovaps xmm0, [rsp]
00007d248dbdf3f6  vmovaps xmm1, [rsp+0x10]
00007d248dbdf3fc  vmovaps xmm2, [rsp+0x20]
00007d248dbdf402  vmovaps xmm3, [rsp+0x30]
00007d248dbdf408  vmovaps xmm4, [rsp+0x40]
00007d248dbdf40e  vmovaps xmm6, [rsp+0x50]
00007d248dbdf414  vmovaps xmm7, [rsp+0x60]
00007d248dbdf41a  vmovaps xmm8, [rsp+0x70]
00007d248dbdf420  vmovaps xmm9, [rsp+0x80]
00007d248dbdf429  vmovaps xmm10, [rsp+0x90]
00007d248dbdf432  vmovaps xmm11, [rsp+0xA0]
00007d248dbdf43b  vmovaps xmm12, [rsp+0xB0]
00007d248dbdf444  vmovaps xmm13, [rsp+0xC0]
00007d248dbdf44d  vmovaps xmm14, [rsp+0xD0]
00007d248dbdf456  vmovaps xmm15, [rsp+0xE0]
00007d248dbdf45f  add rsp, 0xF0
00007d248dbdf466  pop r11
00007d248dbdf468  pop r10
00007d248dbdf46a  pop r9
00007d248dbdf46c  pop r8
00007d248dbdf46e  pop rsi
00007d248dbdf46f  pop rdi
00007d248dbdf470  pop rdx
00007d248dbdf471  pop rcx
00007d248dbdf472  pop rax
00007d248dbdf473  add rsp, 0x08
00007d248dbdf477  jmp 0x00007D248DBDC3B3
00007d248dbdf47c  sub rsp, 0x08
00007d248dbdf480  push rax
00007d248dbdf481  push rcx
00007d248dbdf482  push rdx
00007d248dbdf483  push rdi
00007d248dbdf484  push rsi
00007d248dbdf485  push r8
00007d248dbdf487  push r9
00007d248dbdf489  push r10
00007d248dbdf48b  push r11
00007d248dbdf48d  sub rsp, 0xF0
00007d248dbdf494  vmovaps [rsp], xmm0
00007d248dbdf499  vmovaps [rsp+0x10], xmm1
00007d248dbdf49f  vmovaps [rsp+0x20], xmm2
00007d248dbdf4a5  vmovaps [rsp+0x30], xmm3
00007d248dbdf4ab  vmovaps [rsp+0x40], xmm4
00007d248dbdf4b1  vmovaps [rsp+0x50], xmm5
00007d248dbdf4b7  vmovaps [rsp+0x60], xmm7
00007d248dbdf4bd  vmovaps [rsp+0x70], xmm8
00007d248dbdf4c3  vmovaps [rsp+0x80], xmm9
00007d248dbdf4cc  vmovaps [rsp+0x90], xmm10
00007d248dbdf4d5  vmovaps [rsp+0xA0], xmm11
00007d248dbdf4de  vmovaps [rsp+0xB0], xmm12
00007d248dbdf4e7  vmovaps [rsp+0xC0], xmm13
00007d248dbdf4f0  vmovaps [rsp+0xD0], xmm14
00007d248dbdf4f9  vmovaps [rsp+0xE0], xmm15
00007d248dbdf502  sub rsp, 0x30
00007d248dbdf506  movaps [rsp], xmm6
00007d248dbdf50a  movaps [rsp+0x10], xmm10
00007d248dbdf510  movaps [rsp+0x20], xmm8
00007d248dbdf516  lea rdi, [rsp]
00007d248dbdf51a  mov esi, 0x00
00007d248dbdf51f  mov rax, 0x5BCEEF236530
00007d248dbdf529  call rax
00007d248dbdf52b  movaps xmm6, [rsp]
00007d248dbdf52f  add rsp, 0x30
00007d248dbdf533  vmovaps xmm0, [rsp]
00007d248dbdf538  vmovaps xmm1, [rsp+0x10]
00007d248dbdf53e  vmovaps xmm2, [rsp+0x20]
00007d248dbdf544  vmovaps xmm3, [rsp+0x30]
00007d248dbdf54a  vmovaps xmm4, [rsp+0x40]
00007d248dbdf550  vmovaps xmm5, [rsp+0x50]
00007d248dbdf556  vmovaps xmm7, [rsp+0x60]
00007d248dbdf55c  vmovaps xmm8, [rsp+0x70]
00007d248dbdf562  vmovaps xmm9, [rsp+0x80]
00007d248dbdf56b  vmovaps xmm10, [rsp+0x90]
00007d248dbdf574  vmovaps xmm11, [rsp+0xA0]
00007d248dbdf57d  vmovaps xmm12, [rsp+0xB0]
00007d248dbdf586  vmovaps xmm13, [rsp+0xC0]
00007d248dbdf58f  vmovaps xmm14, [rsp+0xD0]
00007d248dbdf598  vmovaps xmm15, [rsp+0xE0]
00007d248dbdf5a1  add rsp, 0xF0
00007d248dbdf5a8  pop r11
00007d248dbdf5aa  pop r10
00007d248dbdf5ac  pop r9
00007d248dbdf5ae  pop r8
00007d248dbdf5b0  pop rsi
00007d248dbdf5b1  pop rdi
00007d248dbdf5b2  pop rdx
00007d248dbdf5b3  pop rcx
00007d248dbdf5b4  pop rax
00007d248dbdf5b5  add rsp, 0x08
00007d248dbdf5b9  jmp 0x00007D248DBDC3D8
00007d248dbdf5be  sub rsp, 0x08
00007d248dbdf5c2  push rax
00007d248dbdf5c3  push rcx
00007d248dbdf5c4  push rdx
00007d248dbdf5c5  push rdi
00007d248dbdf5c6  push rsi
00007d248dbdf5c7  push r8
00007d248dbdf5c9  push r9
00007d248dbdf5cb  push r10
00007d248dbdf5cd  push r11
00007d248dbdf5cf  sub rsp, 0xF0
00007d248dbdf5d6  vmovaps [rsp], xmm0
00007d248dbdf5db  vmovaps [rsp+0x10], xmm1
00007d248dbdf5e1  vmovaps [rsp+0x20], xmm2
00007d248dbdf5e7  vmovaps [rsp+0x30], xmm3
00007d248dbdf5ed  vmovaps [rsp+0x40], xmm4
00007d248dbdf5f3  vmovaps [rsp+0x50], xmm5
00007d248dbdf5f9  vmovaps [rsp+0x60], xmm6
00007d248dbdf5ff  vmovaps [rsp+0x70], xmm7
00007d248dbdf605  vmovaps [rsp+0x80], xmm8
00007d248dbdf60e  vmovaps [rsp+0x90], xmm9
00007d248dbdf617  vmovaps [rsp+0xA0], xmm11
00007d248dbdf620  vmovaps [rsp+0xB0], xmm12
00007d248dbdf629  vmovaps [rsp+0xC0], xmm13
00007d248dbdf632  vmovaps [rsp+0xD0], xmm14
00007d248dbdf63b  vmovaps [rsp+0xE0], xmm15
00007d248dbdf644  sub rsp, 0x30
00007d248dbdf648  movaps [rsp], xmm10
00007d248dbdf64d  movaps [rsp+0x10], xmm8
00007d248dbdf653  movaps [rsp+0x20], xmm14
00007d248dbdf659  lea rdi, [rsp]
00007d248dbdf65d  mov esi, 0x00
00007d248dbdf662  mov rax, 0x5BCEEF236530
00007d248dbdf66c  call rax
00007d248dbdf66e  movaps xmm10, [rsp]
00007d248dbdf673  add rsp, 0x30
00007d248dbdf677  vmovaps xmm0, [rsp]
00007d248dbdf67c  vmovaps xmm1, [rsp+0x10]
00007d248dbdf682  vmovaps xmm2, [rsp+0x20]
00007d248dbdf688  vmovaps xmm3, [rsp+0x30]
00007d248dbdf68e  vmovaps xmm4, [rsp+0x40]
00007d248dbdf694  vmovaps xmm5, [rsp+0x50]
00007d248dbdf69a  vmovaps xmm6, [rsp+0x60]
00007d248dbdf6a0  vmovaps xmm7, [rsp+0x70]
00007d248dbdf6a6  vmovaps xmm8, [rsp+0x80]
00007d248dbdf6af  vmovaps xmm9, [rsp+0x90]
00007d248dbdf6b8  vmovaps xmm11, [rsp+0xA0]
00007d248dbdf6c1  vmovaps xmm12, [rsp+0xB0]
00007d248dbdf6ca  vmovaps xmm13, [rsp+0xC0]
00007d248dbdf6d3  vmovaps xmm14, [rsp+0xD0]
00007d248dbdf6dc  vmovaps xmm15, [rsp+0xE0]
00007d248dbdf6e5  add rsp, 0xF0
00007d248dbdf6ec  pop r11
00007d248dbdf6ee  pop r10
00007d248dbdf6f0  pop r9
00007d248dbdf6f2  pop r8
00007d248dbdf6f4  pop rsi
00007d248dbdf6f5  pop rdi
00007d248dbdf6f6  pop rdx
00007d248dbdf6f7  pop rcx
00007d248dbdf6f8  pop rax
00007d248dbdf6f9  add rsp, 0x08
00007d248dbdf6fd  jmp 0x00007D248DBDC3F8
00007d248dbdf702  sub rsp, 0x08
00007d248dbdf706  push rax
00007d248dbdf707  push rcx
00007d248dbdf708  push rdx
00007d248dbdf709  push rdi
00007d248dbdf70a  push rsi
00007d248dbdf70b  push r8
00007d248dbdf70d  push r9
00007d248dbdf70f  push r10
00007d248dbdf711  push r11
00007d248dbdf713  sub rsp, 0xF0
00007d248dbdf71a  vmovaps [rsp], xmm0
00007d248dbdf71f  vmovaps [rsp+0x10], xmm1
00007d248dbdf725  vmovaps [rsp+0x20], xmm2
00007d248dbdf72b  vmovaps [rsp+0x30], xmm3
00007d248dbdf731  vmovaps [rsp+0x40], xmm4
00007d248dbdf737  vmovaps [rsp+0x50], xmm5
00007d248dbdf73d  vmovaps [rsp+0x60], xmm6
00007d248dbdf743  vmovaps [rsp+0x70], xmm7
00007d248dbdf749  vmovaps [rsp+0x80], xmm8
00007d248dbdf752  vmovaps [rsp+0x90], xmm9
00007d248dbdf75b  vmovaps [rsp+0xA0], xmm10
00007d248dbdf764  vmovaps [rsp+0xB0], xmm11
00007d248dbdf76d  vmovaps [rsp+0xC0], xmm12
00007d248dbdf776  vmovaps [rsp+0xD0], xmm13
00007d248dbdf77f  vmovaps [rsp+0xE0], xmm15
00007d248dbdf788  sub rsp, 0x30
00007d248dbdf78c  movaps [rsp], xmm14
00007d248dbdf791  movaps [rsp+0x10], xmm8
00007d248dbdf797  movaps [rsp+0x20], xmm4
00007d248dbdf79c  lea rdi, [rsp]
00007d248dbdf7a0  mov esi, 0x00
00007d248dbdf7a5  mov rax, 0x5BCEEF236530
00007d248dbdf7af  call rax
00007d248dbdf7b1  movaps xmm14, [rsp]
00007d248dbdf7b6  add rsp, 0x30
00007d248dbdf7ba  vmovaps xmm0, [rsp]
00007d248dbdf7bf  vmovaps xmm1, [rsp+0x10]
00007d248dbdf7c5  vmovaps xmm2, [rsp+0x20]
00007d248dbdf7cb  vmovaps xmm3, [rsp+0x30]
00007d248dbdf7d1  vmovaps xmm4, [rsp+0x40]
00007d248dbdf7d7  vmovaps xmm5, [rsp+0x50]
00007d248dbdf7dd  vmovaps xmm6, [rsp+0x60]
00007d248dbdf7e3  vmovaps xmm7, [rsp+0x70]
00007d248dbdf7e9  vmovaps xmm8, [rsp+0x80]
00007d248dbdf7f2  vmovaps xmm9, [rsp+0x90]
00007d248dbdf7fb  vmovaps xmm10, [rsp+0xA0]
00007d248dbdf804  vmovaps xmm11, [rsp+0xB0]
00007d248dbdf80d  vmovaps xmm12, [rsp+0xC0]
00007d248dbdf816  vmovaps xmm13, [rsp+0xD0]
00007d248dbdf81f  vmovaps xmm15, [rsp+0xE0]
00007d248dbdf828  add rsp, 0xF0
00007d248dbdf82f  pop r11
00007d248dbdf831  pop r10
00007d248dbdf833  pop r9
00007d248dbdf835  pop r8
00007d248dbdf837  pop rsi
00007d248dbdf838  pop rdi
00007d248dbdf839  pop rdx
00007d248dbdf83a  pop rcx
00007d248dbdf83b  pop rax
00007d248dbdf83c  add rsp, 0x08
00007d248dbdf840  jmp 0x00007D248DBDC418
00007d248dbdf845  sub rsp, 0x08
00007d248dbdf849  push rax
00007d248dbdf84a  push rcx
00007d248dbdf84b  push rdx
00007d248dbdf84c  push rdi
00007d248dbdf84d  push rsi
00007d248dbdf84e  push r8
00007d248dbdf850  push r9
00007d248dbdf852  push r10
00007d248dbdf854  push r11
00007d248dbdf856  sub rsp, 0xF0
00007d248dbdf85d  vmovaps [rsp], xmm0
00007d248dbdf862  vmovaps [rsp+0x10], xmm1
00007d248dbdf868  vmovaps [rsp+0x20], xmm2
00007d248dbdf86e  vmovaps [rsp+0x30], xmm3
00007d248dbdf874  vmovaps [rsp+0x40], xmm5
00007d248dbdf87a  vmovaps [rsp+0x50], xmm6
00007d248dbdf880  vmovaps [rsp+0x60], xmm7
00007d248dbdf886  vmovaps [rsp+0x70], xmm8
00007d248dbdf88c  vmovaps [rsp+0x80], xmm9
00007d248dbdf895  vmovaps [rsp+0x90], xmm10
00007d248dbdf89e  vmovaps [rsp+0xA0], xmm11
00007d248dbdf8a7  vmovaps [rsp+0xB0], xmm12
00007d248dbdf8b0  vmovaps [rsp+0xC0], xmm13
00007d248dbdf8b9  vmovaps [rsp+0xD0], xmm14
00007d248dbdf8c2  vmovaps [rsp+0xE0], xmm15
00007d248dbdf8cb  sub rsp, 0x30
00007d248dbdf8cf  movaps [rsp], xmm4
00007d248dbdf8d3  movaps [rsp+0x10], xmm13
00007d248dbdf8d9  movaps [rsp+0x20], xmm8
00007d248dbdf8df  lea rdi, [rsp]
00007d248dbdf8e3  mov esi, 0x00
00007d248dbdf8e8  mov rax, 0x5BCEEF236530
00007d248dbdf8f2  call rax
00007d248dbdf8f4  movaps xmm4, [rsp]
00007d248dbdf8f8  add rsp, 0x30
00007d248dbdf8fc  vmovaps xmm0, [rsp]
00007d248dbdf901  vmovaps xmm1, [rsp+0x10]
00007d248dbdf907  vmovaps xmm2, [rsp+0x20]
00007d248dbdf90d  vmovaps xmm3, [rsp+0x30]
00007d248dbdf913  vmovaps xmm5, [rsp+0x40]
00007d248dbdf919  vmovaps xmm6, [rsp+0x50]
00007d248dbdf91f  vmovaps xmm7, [rsp+0x60]
00007d248dbdf925  vmovaps xmm8, [rsp+0x70]
00007d248dbdf92b  vmovaps xmm9, [rsp+0x80]
00007d248dbdf934  vmovaps xmm10, [rsp+0x90]
00007d248dbdf93d  vmovaps xmm11, [rsp+0xA0]
00007d248dbdf946  vmovaps xmm12, [rsp+0xB0]
00007d248dbdf94f  vmovaps xmm13, [rsp+0xC0]
00007d248dbdf958  vmovaps xmm14, [rsp+0xD0]
00007d248dbdf961  vmovaps xmm15, [rsp+0xE0]
00007d248dbdf96a  add rsp, 0xF0
00007d248dbdf971  pop r11
00007d248dbdf973  pop r10
00007d248dbdf975  pop r9
00007d248dbdf977  pop r8
00007d248dbdf979  pop rsi
00007d248dbdf97a  pop rdi
00007d248dbdf97b  pop rdx
00007d248dbdf97c  pop rcx
00007d248dbdf97d  pop rax
00007d248dbdf97e  add rsp, 0x08
00007d248dbdf982  jmp 0x00007D248DBDC43D
00007d248dbdf987  sub rsp, 0x08
00007d248dbdf98b  push rax
00007d248dbdf98c  push rcx
00007d248dbdf98d  push rdx
00007d248dbdf98e  push rdi
00007d248dbdf98f  push rsi
00007d248dbdf990  push r8
00007d248dbdf992  push r9
00007d248dbdf994  push r10
00007d248dbdf996  push r11
00007d248dbdf998  sub rsp, 0xF0
00007d248dbdf99f  vmovaps [rsp], xmm0
00007d248dbdf9a4  vmovaps [rsp+0x10], xmm1
00007d248dbdf9aa  vmovaps [rsp+0x20], xmm2
00007d248dbdf9b0  vmovaps [rsp+0x30], xmm3
00007d248dbdf9b6  vmovaps [rsp+0x40], xmm4
00007d248dbdf9bc  vmovaps [rsp+0x50], xmm5
00007d248dbdf9c2  vmovaps [rsp+0x60], xmm6
00007d248dbdf9c8  vmovaps [rsp+0x70], xmm7
00007d248dbdf9ce  vmovaps [rsp+0x80], xmm8
00007d248dbdf9d7  vmovaps [rsp+0x90], xmm9
00007d248dbdf9e0  vmovaps [rsp+0xA0], xmm10
00007d248dbdf9e9  vmovaps [rsp+0xB0], xmm11
00007d248dbdf9f2  vmovaps [rsp+0xC0], xmm12
00007d248dbdf9fb  vmovaps [rsp+0xD0], xmm14
00007d248dbdfa04  vmovaps [rsp+0xE0], xmm15
00007d248dbdfa0d  sub rsp, 0x30
00007d248dbdfa11  movaps [rsp], xmm13
00007d248dbdfa16  movaps [rsp+0x10], xmm15
00007d248dbdfa1c  movaps [rsp+0x20], xmm9
00007d248dbdfa22  lea rdi, [rsp]
00007d248dbdfa26  mov esi, 0x00
00007d248dbdfa2b  mov rax, 0x5BCEEF236530
00007d248dbdfa35  call rax
00007d248dbdfa37  movaps xmm13, [rsp]
00007d248dbdfa3c  add rsp, 0x30
00007d248dbdfa40  vmovaps xmm0, [rsp]
00007d248dbdfa45  vmovaps xmm1, [rsp+0x10]
00007d248dbdfa4b  vmovaps xmm2, [rsp+0x20]
00007d248dbdfa51  vmovaps xmm3, [rsp+0x30]
00007d248dbdfa57  vmovaps xmm4, [rsp+0x40]
00007d248dbdfa5d  vmovaps xmm5, [rsp+0x50]
00007d248dbdfa63  vmovaps xmm6, [rsp+0x60]
00007d248dbdfa69  vmovaps xmm7, [rsp+0x70]
00007d248dbdfa6f  vmovaps xmm8, [rsp+0x80]
00007d248dbdfa78  vmovaps xmm9, [rsp+0x90]
00007d248dbdfa81  vmovaps xmm10, [rsp+0xA0]
00007d248dbdfa8a  vmovaps xmm11, [rsp+0xB0]
00007d248dbdfa93  vmovaps xmm12, [rsp+0xC0]
00007d248dbdfa9c  vmovaps xmm14, [rsp+0xD0]
00007d248dbdfaa5  vmovaps xmm15, [rsp+0xE0]
00007d248dbdfaae  add rsp, 0xF0
00007d248dbdfab5  pop r11
00007d248dbdfab7  pop r10
00007d248dbdfab9  pop r9
00007d248dbdfabb  pop r8
00007d248dbdfabd  pop rsi
00007d248dbdfabe  pop rdi
00007d248dbdfabf  pop rdx
00007d248dbdfac0  pop rcx
00007d248dbdfac1  pop rax
00007d248dbdfac2  add rsp, 0x08
00007d248dbdfac6  jmp 0x00007D248DBDC458
00007d248dbdfacb  sub rsp, 0x08
00007d248dbdfacf  push rax
00007d248dbdfad0  push rcx
00007d248dbdfad1  push rdx
00007d248dbdfad2  push rdi
00007d248dbdfad3  push rsi
00007d248dbdfad4  push r8
00007d248dbdfad6  push r9
00007d248dbdfad8  push r10
00007d248dbdfada  push r11
00007d248dbdfadc  sub rsp, 0xF0
00007d248dbdfae3  vmovaps [rsp], xmm0
00007d248dbdfae8  vmovaps [rsp+0x10], xmm1
00007d248dbdfaee  vmovaps [rsp+0x20], xmm2
00007d248dbdfaf4  vmovaps [rsp+0x30], xmm3
00007d248dbdfafa  vmovaps [rsp+0x40], xmm4
00007d248dbdfb00  vmovaps [rsp+0x50], xmm5
00007d248dbdfb06  vmovaps [rsp+0x60], xmm6
00007d248dbdfb0c  vmovaps [rsp+0x70], xmm7
00007d248dbdfb12  vmovaps [rsp+0x80], xmm8
00007d248dbdfb1b  vmovaps [rsp+0x90], xmm9
00007d248dbdfb24  vmovaps [rsp+0xA0], xmm10
00007d248dbdfb2d  vmovaps [rsp+0xB0], xmm11
00007d248dbdfb36  vmovaps [rsp+0xC0], xmm12
00007d248dbdfb3f  vmovaps [rsp+0xD0], xmm13
00007d248dbdfb48  vmovaps [rsp+0xE0], xmm14
00007d248dbdfb51  sub rsp, 0x30
00007d248dbdfb55  movaps [rsp], xmm15
00007d248dbdfb5a  movaps [rsp+0x10], xmm1
00007d248dbdfb5f  movaps [rsp+0x20], xmm5
00007d248dbdfb64  lea rdi, [rsp]
00007d248dbdfb68  mov esi, 0x00
00007d248dbdfb6d  mov rax, 0x5BCEEF236530
00007d248dbdfb77  call rax
00007d248dbdfb79  movaps xmm15, [rsp]
00007d248dbdfb7e  add rsp, 0x30
00007d248dbdfb82  vmovaps xmm0, [rsp]
00007d248dbdfb87  vmovaps xmm1, [rsp+0x10]
00007d248dbdfb8d  vmovaps xmm2, [rsp+0x20]
00007d248dbdfb93  vmovaps xmm3, [rsp+0x30]
00007d248dbdfb99  vmovaps xmm4, [rsp+0x40]
00007d248dbdfb9f  vmovaps xmm5, [rsp+0x50]
00007d248dbdfba5  vmovaps xmm6, [rsp+0x60]
00007d248dbdfbab  vmovaps xmm7, [rsp+0x70]
00007d248dbdfbb1  vmovaps xmm8, [rsp+0x80]
00007d248dbdfbba  vmovaps xmm9, [rsp+0x90]
00007d248dbdfbc3  vmovaps xmm10, [rsp+0xA0]
00007d248dbdfbcc  vmovaps xmm11, [rsp+0xB0]
00007d248dbdfbd5  vmovaps xmm12, [rsp+0xC0]
00007d248dbdfbde  vmovaps xmm13, [rsp+0xD0]
00007d248dbdfbe7  vmovaps xmm14, [rsp+0xE0]
00007d248dbdfbf0  add rsp, 0xF0
00007d248dbdfbf7  pop r11
00007d248dbdfbf9  pop r10
00007d248dbdfbfb  pop r9
00007d248dbdfbfd  pop r8
00007d248dbdfbff  pop rsi
00007d248dbdfc00  pop rdi
00007d248dbdfc01  pop rdx
00007d248dbdfc02  pop rcx
00007d248dbdfc03  pop rax
00007d248dbdfc04  add rsp, 0x08
00007d248dbdfc08  jmp 0x00007D248DBDC473
00007d248dbdfc0d  call 0x00007D248DAB52F0
00007d248dbdfc12  jmp 0x00007D248DBDC4CE
00007d248dbdfc17  sub rsp, 0x08
00007d248dbdfc1b  push rax
00007d248dbdfc1c  push rcx
00007d248dbdfc1d  push rdx
00007d248dbdfc1e  push rdi
00007d248dbdfc1f  push rsi
00007d248dbdfc20  push r8
00007d248dbdfc22  push r9
00007d248dbdfc24  push r10
00007d248dbdfc26  push r11
00007d248dbdfc28  sub rsp, 0xF0
00007d248dbdfc2f  vmovaps [rsp], xmm0
00007d248dbdfc34  vmovaps [rsp+0x10], xmm1
00007d248dbdfc3a  vmovaps [rsp+0x20], xmm2
00007d248dbdfc40  vmovaps [rsp+0x30], xmm3
00007d248dbdfc46  vmovaps [rsp+0x40], xmm4
00007d248dbdfc4c  vmovaps [rsp+0x50], xmm5
00007d248dbdfc52  vmovaps [rsp+0x60], xmm6
00007d248dbdfc58  vmovaps [rsp+0x70], xmm7
00007d248dbdfc5e  vmovaps [rsp+0x80], xmm8
00007d248dbdfc67  vmovaps [rsp+0x90], xmm10
00007d248dbdfc70  vmovaps [rsp+0xA0], xmm11
00007d248dbdfc79  vmovaps [rsp+0xB0], xmm12
00007d248dbdfc82  vmovaps [rsp+0xC0], xmm13
00007d248dbdfc8b  vmovaps [rsp+0xD0], xmm14
00007d248dbdfc94  vmovaps [rsp+0xE0], xmm15
00007d248dbdfc9d  sub rsp, 0x30
00007d248dbdfca1  movaps [rsp], xmm9
00007d248dbdfca6  movaps [rsp+0x10], xmm8
00007d248dbdfcac  movaps [rsp+0x20], xmm11
00007d248dbdfcb2  lea rdi, [rsp]
00007d248dbdfcb6  mov esi, 0x00
00007d248dbdfcbb  mov rax, 0x5BCEEF236530
00007d248dbdfcc5  call rax
00007d248dbdfcc7  movaps xmm9, [rsp]
00007d248dbdfccc  add rsp, 0x30
00007d248dbdfcd0  vmovaps xmm0, [rsp]
00007d248dbdfcd5  vmovaps xmm1, [rsp+0x10]
00007d248dbdfcdb  vmovaps xmm2, [rsp+0x20]
00007d248dbdfce1  vmovaps xmm3, [rsp+0x30]
00007d248dbdfce7  vmovaps xmm4, [rsp+0x40]
00007d248dbdfced  vmovaps xmm5, [rsp+0x50]
00007d248dbdfcf3  vmovaps xmm6, [rsp+0x60]
00007d248dbdfcf9  vmovaps xmm7, [rsp+0x70]
00007d248dbdfcff  vmovaps xmm8, [rsp+0x80]
00007d248dbdfd08  vmovaps xmm10, [rsp+0x90]
00007d248dbdfd11  vmovaps xmm11, [rsp+0xA0]
00007d248dbdfd1a  vmovaps xmm12, [rsp+0xB0]
00007d248dbdfd23  vmovaps xmm13, [rsp+0xC0]
00007d248dbdfd2c  vmovaps xmm14, [rsp+0xD0]
00007d248dbdfd35  vmovaps xmm15, [rsp+0xE0]
00007d248dbdfd3e  add rsp, 0xF0
00007d248dbdfd45  pop r11
00007d248dbdfd47  pop r10
00007d248dbdfd49  pop r9
00007d248dbdfd4b  pop r8
00007d248dbdfd4d  pop rsi
00007d248dbdfd4e  pop rdi
00007d248dbdfd4f  pop rdx
00007d248dbdfd50  pop rcx
00007d248dbdfd51  pop rax
00007d248dbdfd52  add rsp, 0x08
00007d248dbdfd56  jmp 0x00007D248DBDC505
00007d248dbdfd5b  sub rsp, 0x08
00007d248dbdfd5f  push rax
00007d248dbdfd60  push rcx
00007d248dbdfd61  push rdx
00007d248dbdfd62  push rdi
00007d248dbdfd63  push rsi
00007d248dbdfd64  push r8
00007d248dbdfd66  push r9
00007d248dbdfd68  push r10
00007d248dbdfd6a  push r11
00007d248dbdfd6c  sub rsp, 0xF0
00007d248dbdfd73  vmovaps [rsp], xmm0
00007d248dbdfd78  vmovaps [rsp+0x10], xmm1
00007d248dbdfd7e  vmovaps [rsp+0x20], xmm2
00007d248dbdfd84  vmovaps [rsp+0x30], xmm3
00007d248dbdfd8a  vmovaps [rsp+0x40], xmm4
00007d248dbdfd90  vmovaps [rsp+0x50], xmm5
00007d248dbdfd96  vmovaps [rsp+0x60], xmm6
00007d248dbdfd9c  vmovaps [rsp+0x70], xmm7
00007d248dbdfda2  vmovaps [rsp+0x80], xmm8
00007d248dbdfdab  vmovaps [rsp+0x90], xmm9
00007d248dbdfdb4  vmovaps [rsp+0xA0], xmm10
00007d248dbdfdbd  vmovaps [rsp+0xB0], xmm12
00007d248dbdfdc6  vmovaps [rsp+0xC0], xmm13
00007d248dbdfdcf  vmovaps [rsp+0xD0], xmm14
00007d248dbdfdd8  vmovaps [rsp+0xE0], xmm15
00007d248dbdfde1  sub rsp, 0x30
00007d248dbdfde5  movaps [rsp], xmm11
00007d248dbdfdea  movaps [rsp+0x10], xmm10
00007d248dbdfdf0  movaps [rsp+0x20], xmm6
00007d248dbdfdf5  lea rdi, [rsp]
00007d248dbdfdf9  mov esi, 0x00
00007d248dbdfdfe  mov rax, 0x5BCEEF236530
00007d248dbdfe08  call rax
00007d248dbdfe0a  movaps xmm11, [rsp]
00007d248dbdfe0f  add rsp, 0x30
00007d248dbdfe13  vmovaps xmm0, [rsp]
00007d248dbdfe18  vmovaps xmm1, [rsp+0x10]
00007d248dbdfe1e  vmovaps xmm2, [rsp+0x20]
00007d248dbdfe24  vmovaps xmm3, [rsp+0x30]
00007d248dbdfe2a  vmovaps xmm4, [rsp+0x40]
00007d248dbdfe30  vmovaps xmm5, [rsp+0x50]
00007d248dbdfe36  vmovaps xmm6, [rsp+0x60]
00007d248dbdfe3c  vmovaps xmm7, [rsp+0x70]
00007d248dbdfe42  vmovaps xmm8, [rsp+0x80]
00007d248dbdfe4b  vmovaps xmm9, [rsp+0x90]
00007d248dbdfe54  vmovaps xmm10, [rsp+0xA0]
00007d248dbdfe5d  vmovaps xmm12, [rsp+0xB0]
00007d248dbdfe66  vmovaps xmm13, [rsp+0xC0]
00007d248dbdfe6f  vmovaps xmm14, [rsp+0xD0]
00007d248dbdfe78  vmovaps xmm15, [rsp+0xE0]
00007d248dbdfe81  add rsp, 0xF0
00007d248dbdfe88  pop r11
00007d248dbdfe8a  pop r10
00007d248dbdfe8c  pop r9
00007d248dbdfe8e  pop r8
00007d248dbdfe90  pop rsi
00007d248dbdfe91  pop rdi
00007d248dbdfe92  pop rdx
00007d248dbdfe93  pop rcx
00007d248dbdfe94  pop rax
00007d248dbdfe95  add rsp, 0x08
00007d248dbdfe99  jmp 0x00007D248DBDC520
00007d248dbdfe9e  sub rsp, 0x08
00007d248dbdfea2  push rax
00007d248dbdfea3  push rcx
00007d248dbdfea4  push rdx
00007d248dbdfea5  push rdi
00007d248dbdfea6  push rsi
00007d248dbdfea7  push r8
00007d248dbdfea9  push r9
00007d248dbdfeab  push r10
00007d248dbdfead  push r11
00007d248dbdfeaf  sub rsp, 0xF0
00007d248dbdfeb6  vmovaps [rsp], xmm0
00007d248dbdfebb  vmovaps [rsp+0x10], xmm1
00007d248dbdfec1  vmovaps [rsp+0x20], xmm2
00007d248dbdfec7  vmovaps [rsp+0x30], xmm3
00007d248dbdfecd  vmovaps [rsp+0x40], xmm4
00007d248dbdfed3  vmovaps [rsp+0x50], xmm5
00007d248dbdfed9  vmovaps [rsp+0x60], xmm6
00007d248dbdfedf  vmovaps [rsp+0x70], xmm7
00007d248dbdfee5  vmovaps [rsp+0x80], xmm8
00007d248dbdfeee  vmovaps [rsp+0x90], xmm9
00007d248dbdfef7  vmovaps [rsp+0xA0], xmm11
00007d248dbdff00  vmovaps [rsp+0xB0], xmm12
00007d248dbdff09  vmovaps [rsp+0xC0], xmm13
00007d248dbdff12  vmovaps [rsp+0xD0], xmm14
00007d248dbdff1b  vmovaps [rsp+0xE0], xmm15
00007d248dbdff24  sub rsp, 0x30
00007d248dbdff28  movaps [rsp], xmm10
00007d248dbdff2d  movaps [rsp+0x10], xmm14
00007d248dbdff33  movaps [rsp+0x20], xmm4
00007d248dbdff38  lea rdi, [rsp]
00007d248dbdff3c  mov esi, 0x00
00007d248dbdff41  mov rax, 0x5BCEEF236530
00007d248dbdff4b  call rax
00007d248dbdff4d  movaps xmm10, [rsp]
00007d248dbdff52  add rsp, 0x30
00007d248dbdff56  vmovaps xmm0, [rsp]
00007d248dbdff5b  vmovaps xmm1, [rsp+0x10]
00007d248dbdff61  vmovaps xmm2, [rsp+0x20]
00007d248dbdff67  vmovaps xmm3, [rsp+0x30]
00007d248dbdff6d  vmovaps xmm4, [rsp+0x40]
00007d248dbdff73  vmovaps xmm5, [rsp+0x50]
00007d248dbdff79  vmovaps xmm6, [rsp+0x60]
00007d248dbdff7f  vmovaps xmm7, [rsp+0x70]
00007d248dbdff85  vmovaps xmm8, [rsp+0x80]
00007d248dbdff8e  vmovaps xmm9, [rsp+0x90]
00007d248dbdff97  vmovaps xmm11, [rsp+0xA0]
00007d248dbdffa0  vmovaps xmm12, [rsp+0xB0]
00007d248dbdffa9  vmovaps xmm13, [rsp+0xC0]
00007d248dbdffb2  vmovaps xmm14, [rsp+0xD0]
00007d248dbdffbb  vmovaps xmm15, [rsp+0xE0]
00007d248dbdffc4  add rsp, 0xF0
00007d248dbdffcb  pop r11
00007d248dbdffcd  pop r10
00007d248dbdffcf  pop r9
00007d248dbdffd1  pop r8
00007d248dbdffd3  pop rsi
00007d248dbdffd4  pop rdi
00007d248dbdffd5  pop rdx
00007d248dbdffd6  pop rcx
00007d248dbdffd7  pop rax
00007d248dbdffd8  add rsp, 0x08
00007d248dbdffdc  jmp 0x00007D248DBDC53B
00007d248dbdffe1  sub rsp, 0x08
00007d248dbdffe5  push rax
00007d248dbdffe6  push rcx
00007d248dbdffe7  push rdx
00007d248dbdffe8  push rdi
00007d248dbdffe9  push rsi
00007d248dbdffea  push r8
00007d248dbdffec  push r9
00007d248dbdffee  push r10
00007d248dbdfff0  push r11
00007d248dbdfff2  sub rsp, 0xF0
00007d248dbdfff9  vmovaps [rsp], xmm0
00007d248dbdfffe  vmovaps [rsp+0x10], xmm1
00007d248dbe0004  vmovaps [rsp+0x20], xmm2
00007d248dbe000a  vmovaps [rsp+0x30], xmm3
00007d248dbe0010  vmovaps [rsp+0x40], xmm4
00007d248dbe0016  vmovaps [rsp+0x50], xmm5
00007d248dbe001c  vmovaps [rsp+0x60], xmm6
00007d248dbe0022  vmovaps [rsp+0x70], xmm7
00007d248dbe0028  vmovaps [rsp+0x80], xmm9
00007d248dbe0031  vmovaps [rsp+0x90], xmm10
00007d248dbe003a  vmovaps [rsp+0xA0], xmm11
00007d248dbe0043  vmovaps [rsp+0xB0], xmm12
00007d248dbe004c  vmovaps [rsp+0xC0], xmm13
00007d248dbe0055  vmovaps [rsp+0xD0], xmm14
00007d248dbe005e  vmovaps [rsp+0xE0], xmm15
00007d248dbe0067  sub rsp, 0x30
00007d248dbe006b  movaps [rsp], xmm8
00007d248dbe0070  movaps [rsp+0x10], xmm1
00007d248dbe0075  movaps [rsp+0x20], xmm14
00007d248dbe007b  lea rdi, [rsp]
00007d248dbe007f  mov esi, 0x00
00007d248dbe0084  mov rax, 0x5BCEEF236530
00007d248dbe008e  call rax
00007d248dbe0090  movaps xmm8, [rsp]
00007d248dbe0095  add rsp, 0x30
00007d248dbe0099  vmovaps xmm0, [rsp]
00007d248dbe009e  vmovaps xmm1, [rsp+0x10]
00007d248dbe00a4  vmovaps xmm2, [rsp+0x20]
00007d248dbe00aa  vmovaps xmm3, [rsp+0x30]
00007d248dbe00b0  vmovaps xmm4, [rsp+0x40]
00007d248dbe00b6  vmovaps xmm5, [rsp+0x50]
00007d248dbe00bc  vmovaps xmm6, [rsp+0x60]
00007d248dbe00c2  vmovaps xmm7, [rsp+0x70]
00007d248dbe00c8  vmovaps xmm9, [rsp+0x80]
00007d248dbe00d1  vmovaps xmm10, [rsp+0x90]
00007d248dbe00da  vmovaps xmm11, [rsp+0xA0]
00007d248dbe00e3  vmovaps xmm12, [rsp+0xB0]
00007d248dbe00ec  vmovaps xmm13, [rsp+0xC0]
00007d248dbe00f5  vmovaps xmm14, [rsp+0xD0]
00007d248dbe00fe  vmovaps xmm15, [rsp+0xE0]
00007d248dbe0107  add rsp, 0xF0
00007d248dbe010e  pop r11
00007d248dbe0110  pop r10
00007d248dbe0112  pop r9
00007d248dbe0114  pop r8
00007d248dbe0116  pop rsi
00007d248dbe0117  pop rdi
00007d248dbe0118  pop rdx
00007d248dbe0119  pop rcx
00007d248dbe011a  pop rax
00007d248dbe011b  add rsp, 0x08
00007d248dbe011f  jmp 0x00007D248DBDC561
00007d248dbe0124  sub rsp, 0x08
00007d248dbe0128  push rax
00007d248dbe0129  push rcx
00007d248dbe012a  push rdx
00007d248dbe012b  push rdi
00007d248dbe012c  push rsi
00007d248dbe012d  push r8
00007d248dbe012f  push r9
00007d248dbe0131  push r10
00007d248dbe0133  push r11
00007d248dbe0135  sub rsp, 0xF0
00007d248dbe013c  vmovaps [rsp], xmm0
00007d248dbe0141  vmovaps [rsp+0x10], xmm1
00007d248dbe0147  vmovaps [rsp+0x20], xmm2
00007d248dbe014d  vmovaps [rsp+0x30], xmm3
00007d248dbe0153  vmovaps [rsp+0x40], xmm4
00007d248dbe0159  vmovaps [rsp+0x50], xmm5
00007d248dbe015f  vmovaps [rsp+0x60], xmm7
00007d248dbe0165  vmovaps [rsp+0x70], xmm8
00007d248dbe016b  vmovaps [rsp+0x80], xmm9
00007d248dbe0174  vmovaps [rsp+0x90], xmm10
00007d248dbe017d  vmovaps [rsp+0xA0], xmm11
00007d248dbe0186  vmovaps [rsp+0xB0], xmm12
00007d248dbe018f  vmovaps [rsp+0xC0], xmm13
00007d248dbe0198  vmovaps [rsp+0xD0], xmm14
00007d248dbe01a1  vmovaps [rsp+0xE0], xmm15
00007d248dbe01aa  sub rsp, 0x30
00007d248dbe01ae  movaps [rsp], xmm6
00007d248dbe01b2  movaps [rsp+0x10], xmm1
00007d248dbe01b7  movaps [rsp+0x20], xmm14
00007d248dbe01bd  lea rdi, [rsp]
00007d248dbe01c1  mov esi, 0x00
00007d248dbe01c6  mov rax, 0x5BCEEF236530
00007d248dbe01d0  call rax
00007d248dbe01d2  movaps xmm6, [rsp]
00007d248dbe01d6  add rsp, 0x30
00007d248dbe01da  vmovaps xmm0, [rsp]
00007d248dbe01df  vmovaps xmm1, [rsp+0x10]
00007d248dbe01e5  vmovaps xmm2, [rsp+0x20]
00007d248dbe01eb  vmovaps xmm3, [rsp+0x30]
00007d248dbe01f1  vmovaps xmm4, [rsp+0x40]
00007d248dbe01f7  vmovaps xmm5, [rsp+0x50]
00007d248dbe01fd  vmovaps xmm7, [rsp+0x60]
00007d248dbe0203  vmovaps xmm8, [rsp+0x70]
00007d248dbe0209  vmovaps xmm9, [rsp+0x80]
00007d248dbe0212  vmovaps xmm10, [rsp+0x90]
00007d248dbe021b  vmovaps xmm11, [rsp+0xA0]
00007d248dbe0224  vmovaps xmm12, [rsp+0xB0]
00007d248dbe022d  vmovaps xmm13, [rsp+0xC0]
00007d248dbe0236  vmovaps xmm14, [rsp+0xD0]
00007d248dbe023f  vmovaps xmm15, [rsp+0xE0]
00007d248dbe0248  add rsp, 0xF0
00007d248dbe024f  pop r11
00007d248dbe0251  pop r10
00007d248dbe0253  pop r9
00007d248dbe0255  pop r8
00007d248dbe0257  pop rsi
00007d248dbe0258  pop rdi
00007d248dbe0259  pop rdx
00007d248dbe025a  pop rcx
00007d248dbe025b  pop rax
00007d248dbe025c  add rsp, 0x08
00007d248dbe0260  jmp 0x00007D248DBDC58D
00007d248dbe0265  sub rsp, 0x08
00007d248dbe0269  push rax
00007d248dbe026a  push rcx
00007d248dbe026b  push rdx
00007d248dbe026c  push rdi
00007d248dbe026d  push rsi
00007d248dbe026e  push r8
00007d248dbe0270  push r9
00007d248dbe0272  push r10
00007d248dbe0274  push r11
00007d248dbe0276  sub rsp, 0xF0
00007d248dbe027d  vmovaps [rsp], xmm0
00007d248dbe0282  vmovaps [rsp+0x10], xmm1
00007d248dbe0288  vmovaps [rsp+0x20], xmm2
00007d248dbe028e  vmovaps [rsp+0x30], xmm3
00007d248dbe0294  vmovaps [rsp+0x40], xmm4
00007d248dbe029a  vmovaps [rsp+0x50], xmm5
00007d248dbe02a0  vmovaps [rsp+0x60], xmm6
00007d248dbe02a6  vmovaps [rsp+0x70], xmm7
00007d248dbe02ac  vmovaps [rsp+0x80], xmm8
00007d248dbe02b5  vmovaps [rsp+0x90], xmm9
00007d248dbe02be  vmovaps [rsp+0xA0], xmm10
00007d248dbe02c7  vmovaps [rsp+0xB0], xmm11
00007d248dbe02d0  vmovaps [rsp+0xC0], xmm12
00007d248dbe02d9  vmovaps [rsp+0xD0], xmm13
00007d248dbe02e2  vmovaps [rsp+0xE0], xmm15
00007d248dbe02eb  sub rsp, 0x30
00007d248dbe02ef  movaps [rsp], xmm14
00007d248dbe02f4  movaps [rsp+0x10], xmm12
00007d248dbe02fa  movaps [rsp+0x20], xmm1
00007d248dbe02ff  lea rdi, [rsp]
00007d248dbe0303  mov esi, 0x00
00007d248dbe0308  mov rax, 0x5BCEEF236530
00007d248dbe0312  call rax
00007d248dbe0314  movaps xmm14, [rsp]
00007d248dbe0319  add rsp, 0x30
00007d248dbe031d  vmovaps xmm0, [rsp]
00007d248dbe0322  vmovaps xmm1, [rsp+0x10]
00007d248dbe0328  vmovaps xmm2, [rsp+0x20]
00007d248dbe032e  vmovaps xmm3, [rsp+0x30]
00007d248dbe0334  vmovaps xmm4, [rsp+0x40]
00007d248dbe033a  vmovaps xmm5, [rsp+0x50]
00007d248dbe0340  vmovaps xmm6, [rsp+0x60]
00007d248dbe0346  vmovaps xmm7, [rsp+0x70]
00007d248dbe034c  vmovaps xmm8, [rsp+0x80]
00007d248dbe0355  vmovaps xmm9, [rsp+0x90]
00007d248dbe035e  vmovaps xmm10, [rsp+0xA0]
00007d248dbe0367  vmovaps xmm11, [rsp+0xB0]
00007d248dbe0370  vmovaps xmm12, [rsp+0xC0]
00007d248dbe0379  vmovaps xmm13, [rsp+0xD0]
00007d248dbe0382  vmovaps xmm15, [rsp+0xE0]
00007d248dbe038b  add rsp, 0xF0
00007d248dbe0392  pop r11
00007d248dbe0394  pop r10
00007d248dbe0396  pop r9
00007d248dbe0398  pop r8
00007d248dbe039a  pop rsi
00007d248dbe039b  pop rdi
00007d248dbe039c  pop rdx
00007d248dbe039d  pop rcx
00007d248dbe039e  pop rax
00007d248dbe039f  add rsp, 0x08
00007d248dbe03a3  jmp 0x00007D248DBDC5B3
00007d248dbe03a8  sub rsp, 0x08
00007d248dbe03ac  push rax
00007d248dbe03ad  push rcx
00007d248dbe03ae  push rdx
00007d248dbe03af  push rdi
00007d248dbe03b0  push rsi
00007d248dbe03b1  push r8
00007d248dbe03b3  push r9
00007d248dbe03b5  push r10
00007d248dbe03b7  push r11
00007d248dbe03b9  sub rsp, 0xF0
00007d248dbe03c0  vmovaps [rsp], xmm0
00007d248dbe03c5  vmovaps [rsp+0x10], xmm2
00007d248dbe03cb  vmovaps [rsp+0x20], xmm3
00007d248dbe03d1  vmovaps [rsp+0x30], xmm4
00007d248dbe03d7  vmovaps [rsp+0x40], xmm5
00007d248dbe03dd  vmovaps [rsp+0x50], xmm6
00007d248dbe03e3  vmovaps [rsp+0x60], xmm7
00007d248dbe03e9  vmovaps [rsp+0x70], xmm8
00007d248dbe03ef  vmovaps [rsp+0x80], xmm9
00007d248dbe03f8  vmovaps [rsp+0x90], xmm10
00007d248dbe0401  vmovaps [rsp+0xA0], xmm11
00007d248dbe040a  vmovaps [rsp+0xB0], xmm12
00007d248dbe0413  vmovaps [rsp+0xC0], xmm13
00007d248dbe041c  vmovaps [rsp+0xD0], xmm14
00007d248dbe0425  vmovaps [rsp+0xE0], xmm15
00007d248dbe042e  sub rsp, 0x30
00007d248dbe0432  movaps [rsp], xmm1
00007d248dbe0436  movaps [rsp+0x10], xmm13
00007d248dbe043c  movaps [rsp+0x20], xmm9
00007d248dbe0442  lea rdi, [rsp]
00007d248dbe0446  mov esi, 0x00
00007d248dbe044b  mov rax, 0x5BCEEF236530
00007d248dbe0455  call rax
00007d248dbe0457  movaps xmm1, [rsp]
00007d248dbe045b  add rsp, 0x30
00007d248dbe045f  vmovaps xmm0, [rsp]
00007d248dbe0464  vmovaps xmm2, [rsp+0x10]
00007d248dbe046a  vmovaps xmm3, [rsp+0x20]
00007d248dbe0470  vmovaps xmm4, [rsp+0x30]
00007d248dbe0476  vmovaps xmm5, [rsp+0x40]
00007d248dbe047c  vmovaps xmm6, [rsp+0x50]
00007d248dbe0482  vmovaps xmm7, [rsp+0x60]
00007d248dbe0488  vmovaps xmm8, [rsp+0x70]
00007d248dbe048e  vmovaps xmm9, [rsp+0x80]
00007d248dbe0497  vmovaps xmm10, [rsp+0x90]
00007d248dbe04a0  vmovaps xmm11, [rsp+0xA0]
00007d248dbe04a9  vmovaps xmm12, [rsp+0xB0]
00007d248dbe04b2  vmovaps xmm13, [rsp+0xC0]
00007d248dbe04bb  vmovaps xmm14, [rsp+0xD0]
00007d248dbe04c4  vmovaps xmm15, [rsp+0xE0]
00007d248dbe04cd  add rsp, 0xF0
00007d248dbe04d4  pop r11
00007d248dbe04d6  pop r10
00007d248dbe04d8  pop r9
00007d248dbe04da  pop r8
00007d248dbe04dc  pop rsi
00007d248dbe04dd  pop rdi
00007d248dbe04de  pop rdx
00007d248dbe04df  pop rcx
00007d248dbe04e0  pop rax
00007d248dbe04e1  add rsp, 0x08
00007d248dbe04e5  jmp 0x00007D248DBDC5CD
00007d248dbe04ea  sub rsp, 0x08
00007d248dbe04ee  push rax
00007d248dbe04ef  push rcx
00007d248dbe04f0  push rdx
00007d248dbe04f1  push rdi
00007d248dbe04f2  push rsi
00007d248dbe04f3  push r8
00007d248dbe04f5  push r9
00007d248dbe04f7  push r10
00007d248dbe04f9  push r11
00007d248dbe04fb  sub rsp, 0xF0
00007d248dbe0502  vmovaps [rsp], xmm0
00007d248dbe0507  vmovaps [rsp+0x10], xmm1
00007d248dbe050d  vmovaps [rsp+0x20], xmm2
00007d248dbe0513  vmovaps [rsp+0x30], xmm3
00007d248dbe0519  vmovaps [rsp+0x40], xmm4
00007d248dbe051f  vmovaps [rsp+0x50], xmm5
00007d248dbe0525  vmovaps [rsp+0x60], xmm6
00007d248dbe052b  vmovaps [rsp+0x70], xmm7
00007d248dbe0531  vmovaps [rsp+0x80], xmm8
00007d248dbe053a  vmovaps [rsp+0x90], xmm9
00007d248dbe0543  vmovaps [rsp+0xA0], xmm10
00007d248dbe054c  vmovaps [rsp+0xB0], xmm11
00007d248dbe0555  vmovaps [rsp+0xC0], xmm13
00007d248dbe055e  vmovaps [rsp+0xD0], xmm14
00007d248dbe0567  vmovaps [rsp+0xE0], xmm15
00007d248dbe0570  sub rsp, 0x30
00007d248dbe0574  movaps [rsp], xmm12
00007d248dbe0579  movaps [rsp+0x10], xmm7
00007d248dbe057e  movaps [rsp+0x20], xmm13
00007d248dbe0584  lea rdi, [rsp]
00007d248dbe0588  mov esi, 0x00
00007d248dbe058d  mov rax, 0x5BCEEF236530
00007d248dbe0597  call rax
00007d248dbe0599  movaps xmm12, [rsp]
00007d248dbe059e  add rsp, 0x30
00007d248dbe05a2  vmovaps xmm0, [rsp]
00007d248dbe05a7  vmovaps xmm1, [rsp+0x10]
00007d248dbe05ad  vmovaps xmm2, [rsp+0x20]
00007d248dbe05b3  vmovaps xmm3, [rsp+0x30]
00007d248dbe05b9  vmovaps xmm4, [rsp+0x40]
00007d248dbe05bf  vmovaps xmm5, [rsp+0x50]
00007d248dbe05c5  vmovaps xmm6, [rsp+0x60]
00007d248dbe05cb  vmovaps xmm7, [rsp+0x70]
00007d248dbe05d1  vmovaps xmm8, [rsp+0x80]
00007d248dbe05da  vmovaps xmm9, [rsp+0x90]
00007d248dbe05e3  vmovaps xmm10, [rsp+0xA0]
00007d248dbe05ec  vmovaps xmm11, [rsp+0xB0]
00007d248dbe05f5  vmovaps xmm13, [rsp+0xC0]
00007d248dbe05fe  vmovaps xmm14, [rsp+0xD0]
00007d248dbe0607  vmovaps xmm15, [rsp+0xE0]
00007d248dbe0610  add rsp, 0xF0
00007d248dbe0617  pop r11
00007d248dbe0619  pop r10
00007d248dbe061b  pop r9
00007d248dbe061d  pop r8
00007d248dbe061f  pop rsi
00007d248dbe0620  pop rdi
00007d248dbe0621  pop rdx
00007d248dbe0622  pop rcx
00007d248dbe0623  pop rax
00007d248dbe0624  add rsp, 0x08
00007d248dbe0628  jmp 0x00007D248DBDC5F4
00007d248dbe062d  sub rsp, 0x08
00007d248dbe0631  push rax
00007d248dbe0632  push rcx
00007d248dbe0633  push rdx
00007d248dbe0634  push rdi
00007d248dbe0635  push rsi
00007d248dbe0636  push r8
00007d248dbe0638  push r9
00007d248dbe063a  push r10
00007d248dbe063c  push r11
00007d248dbe063e  sub rsp, 0xF0
00007d248dbe0645  vmovaps [rsp], xmm0
00007d248dbe064a  vmovaps [rsp+0x10], xmm1
00007d248dbe0650  vmovaps [rsp+0x20], xmm2
00007d248dbe0656  vmovaps [rsp+0x30], xmm3
00007d248dbe065c  vmovaps [rsp+0x40], xmm4
00007d248dbe0662  vmovaps [rsp+0x50], xmm5
00007d248dbe0668  vmovaps [rsp+0x60], xmm6
00007d248dbe066e  vmovaps [rsp+0x70], xmm7
00007d248dbe0674  vmovaps [rsp+0x80], xmm8
00007d248dbe067d  vmovaps [rsp+0x90], xmm9
00007d248dbe0686  vmovaps [rsp+0xA0], xmm10
00007d248dbe068f  vmovaps [rsp+0xB0], xmm11
00007d248dbe0698  vmovaps [rsp+0xC0], xmm12
00007d248dbe06a1  vmovaps [rsp+0xD0], xmm14
00007d248dbe06aa  vmovaps [rsp+0xE0], xmm15
00007d248dbe06b3  sub rsp, 0x30
00007d248dbe06b7  movaps [rsp], xmm13
00007d248dbe06bc  movaps [rsp+0x10], xmm15
00007d248dbe06c2  movaps [rsp+0x20], xmm8
00007d248dbe06c8  lea rdi, [rsp]
00007d248dbe06cc  mov esi, 0x00
00007d248dbe06d1  mov rax, 0x5BCEEF236530
00007d248dbe06db  call rax
00007d248dbe06dd  movaps xmm13, [rsp]
00007d248dbe06e2  add rsp, 0x30
00007d248dbe06e6  vmovaps xmm0, [rsp]
00007d248dbe06eb  vmovaps xmm1, [rsp+0x10]
00007d248dbe06f1  vmovaps xmm2, [rsp+0x20]
00007d248dbe06f7  vmovaps xmm3, [rsp+0x30]
00007d248dbe06fd  vmovaps xmm4, [rsp+0x40]
00007d248dbe0703  vmovaps xmm5, [rsp+0x50]
00007d248dbe0709  vmovaps xmm6, [rsp+0x60]
00007d248dbe070f  vmovaps xmm7, [rsp+0x70]
00007d248dbe0715  vmovaps xmm8, [rsp+0x80]
00007d248dbe071e  vmovaps xmm9, [rsp+0x90]
00007d248dbe0727  vmovaps xmm10, [rsp+0xA0]
00007d248dbe0730  vmovaps xmm11, [rsp+0xB0]
00007d248dbe0739  vmovaps xmm12, [rsp+0xC0]
00007d248dbe0742  vmovaps xmm14, [rsp+0xD0]
00007d248dbe074b  vmovaps xmm15, [rsp+0xE0]
00007d248dbe0754  add rsp, 0xF0
00007d248dbe075b  pop r11
00007d248dbe075d  pop r10
00007d248dbe075f  pop r9
00007d248dbe0761  pop r8
00007d248dbe0763  pop rsi
00007d248dbe0764  pop rdi
00007d248dbe0765  pop rdx
00007d248dbe0766  pop rcx
00007d248dbe0767  pop rax
00007d248dbe0768  add rsp, 0x08
00007d248dbe076c  jmp 0x00007D248DBDC60F
00007d248dbe0771  sub rsp, 0x08
00007d248dbe0775  push rax
00007d248dbe0776  push rcx
00007d248dbe0777  push rdx
00007d248dbe0778  push rdi
00007d248dbe0779  push rsi
00007d248dbe077a  push r8
00007d248dbe077c  push r9
00007d248dbe077e  push r10
00007d248dbe0780  push r11
00007d248dbe0782  sub rsp, 0xF0
00007d248dbe0789  vmovaps [rsp], xmm0
00007d248dbe078e  vmovaps [rsp+0x10], xmm1
00007d248dbe0794  vmovaps [rsp+0x20], xmm2
00007d248dbe079a  vmovaps [rsp+0x30], xmm3
00007d248dbe07a0  vmovaps [rsp+0x40], xmm4
00007d248dbe07a6  vmovaps [rsp+0x50], xmm5
00007d248dbe07ac  vmovaps [rsp+0x60], xmm6
00007d248dbe07b2  vmovaps [rsp+0x70], xmm7
00007d248dbe07b8  vmovaps [rsp+0x80], xmm9
00007d248dbe07c1  vmovaps [rsp+0x90], xmm10
00007d248dbe07ca  vmovaps [rsp+0xA0], xmm11
00007d248dbe07d3  vmovaps [rsp+0xB0], xmm12
00007d248dbe07dc  vmovaps [rsp+0xC0], xmm13
00007d248dbe07e5  vmovaps [rsp+0xD0], xmm14
00007d248dbe07ee  vmovaps [rsp+0xE0], xmm15
00007d248dbe07f7  sub rsp, 0x30
00007d248dbe07fb  movaps [rsp], xmm8
00007d248dbe0800  movaps [rsp+0x10], xmm15
00007d248dbe0806  movaps [rsp+0x20], xmm9
00007d248dbe080c  lea rdi, [rsp]
00007d248dbe0810  mov esi, 0x00
00007d248dbe0815  mov rax, 0x5BCEEF236530
00007d248dbe081f  call rax
00007d248dbe0821  movaps xmm8, [rsp]
00007d248dbe0826  add rsp, 0x30
00007d248dbe082a  vmovaps xmm0, [rsp]
00007d248dbe082f  vmovaps xmm1, [rsp+0x10]
00007d248dbe0835  vmovaps xmm2, [rsp+0x20]
00007d248dbe083b  vmovaps xmm3, [rsp+0x30]
00007d248dbe0841  vmovaps xmm4, [rsp+0x40]
00007d248dbe0847  vmovaps xmm5, [rsp+0x50]
00007d248dbe084d  vmovaps xmm6, [rsp+0x60]
00007d248dbe0853  vmovaps xmm7, [rsp+0x70]
00007d248dbe0859  vmovaps xmm9, [rsp+0x80]
00007d248dbe0862  vmovaps xmm10, [rsp+0x90]
00007d248dbe086b  vmovaps xmm11, [rsp+0xA0]
00007d248dbe0874  vmovaps xmm12, [rsp+0xB0]
00007d248dbe087d  vmovaps xmm13, [rsp+0xC0]
00007d248dbe0886  vmovaps xmm14, [rsp+0xD0]
00007d248dbe088f  vmovaps xmm15, [rsp+0xE0]
00007d248dbe0898  add rsp, 0xF0
00007d248dbe089f  pop r11
00007d248dbe08a1  pop r10
00007d248dbe08a3  pop r9
00007d248dbe08a5  pop r8
00007d248dbe08a7  pop rsi
00007d248dbe08a8  pop rdi
00007d248dbe08a9  pop rdx
00007d248dbe08aa  pop rcx
00007d248dbe08ab  pop rax
00007d248dbe08ac  add rsp, 0x08
00007d248dbe08b0  jmp 0x00007D248DBDC63D
00007d248dbe08b5  sub rsp, 0x08
00007d248dbe08b9  push rax
00007d248dbe08ba  push rcx
00007d248dbe08bb  push rdx
00007d248dbe08bc  push rdi
00007d248dbe08bd  push rsi
00007d248dbe08be  push r8
00007d248dbe08c0  push r9
00007d248dbe08c2  push r10
00007d248dbe08c4  push r11
00007d248dbe08c6  sub rsp, 0xF0
00007d248dbe08cd  vmovaps [rsp], xmm0
00007d248dbe08d2  vmovaps [rsp+0x10], xmm1
00007d248dbe08d8  vmovaps [rsp+0x20], xmm2
00007d248dbe08de  vmovaps [rsp+0x30], xmm3
00007d248dbe08e4  vmovaps [rsp+0x40], xmm4
00007d248dbe08ea  vmovaps [rsp+0x50], xmm5
00007d248dbe08f0  vmovaps [rsp+0x60], xmm6
00007d248dbe08f6  vmovaps [rsp+0x70], xmm7
00007d248dbe08fc  vmovaps [rsp+0x80], xmm8
00007d248dbe0905  vmovaps [rsp+0x90], xmm9
00007d248dbe090e  vmovaps [rsp+0xA0], xmm10
00007d248dbe0917  vmovaps [rsp+0xB0], xmm11
00007d248dbe0920  vmovaps [rsp+0xC0], xmm12
00007d248dbe0929  vmovaps [rsp+0xD0], xmm13
00007d248dbe0932  vmovaps [rsp+0xE0], xmm14
00007d248dbe093b  sub rsp, 0x30
00007d248dbe093f  movaps [rsp], xmm15
00007d248dbe0944  movaps [rsp+0x10], xmm11
00007d248dbe094a  movaps [rsp+0x20], xmm6
00007d248dbe094f  lea rdi, [rsp]
00007d248dbe0953  mov esi, 0x00
00007d248dbe0958  mov rax, 0x5BCEEF236530
00007d248dbe0962  call rax
00007d248dbe0964  movaps xmm15, [rsp]
00007d248dbe0969  add rsp, 0x30
00007d248dbe096d  vmovaps xmm0, [rsp]
00007d248dbe0972  vmovaps xmm1, [rsp+0x10]
00007d248dbe0978  vmovaps xmm2, [rsp+0x20]
00007d248dbe097e  vmovaps xmm3, [rsp+0x30]
00007d248dbe0984  vmovaps xmm4, [rsp+0x40]
00007d248dbe098a  vmovaps xmm5, [rsp+0x50]
00007d248dbe0990  vmovaps xmm6, [rsp+0x60]
00007d248dbe0996  vmovaps xmm7, [rsp+0x70]
00007d248dbe099c  vmovaps xmm8, [rsp+0x80]
00007d248dbe09a5  vmovaps xmm9, [rsp+0x90]
00007d248dbe09ae  vmovaps xmm10, [rsp+0xA0]
00007d248dbe09b7  vmovaps xmm11, [rsp+0xB0]
00007d248dbe09c0  vmovaps xmm12, [rsp+0xC0]
00007d248dbe09c9  vmovaps xmm13, [rsp+0xD0]
00007d248dbe09d2  vmovaps xmm14, [rsp+0xE0]
00007d248dbe09db  add rsp, 0xF0
00007d248dbe09e2  pop r11
00007d248dbe09e4  pop r10
00007d248dbe09e6  pop r9
00007d248dbe09e8  pop r8
00007d248dbe09ea  pop rsi
00007d248dbe09eb  pop rdi
00007d248dbe09ec  pop rdx
00007d248dbe09ed  pop rcx
00007d248dbe09ee  pop rax
00007d248dbe09ef  add rsp, 0x08
00007d248dbe09f3  jmp 0x00007D248DBDC658
00007d248dbe09f8  sub rsp, 0x08
00007d248dbe09fc  push rax
00007d248dbe09fd  push rcx
00007d248dbe09fe  push rdx
00007d248dbe09ff  push rdi
00007d248dbe0a00  push rsi
00007d248dbe0a01  push r8
00007d248dbe0a03  push r9
00007d248dbe0a05  push r10
00007d248dbe0a07  push r11
00007d248dbe0a09  sub rsp, 0xF0
00007d248dbe0a10  vmovaps [rsp], xmm0
00007d248dbe0a15  vmovaps [rsp+0x10], xmm1
00007d248dbe0a1b  vmovaps [rsp+0x20], xmm2
00007d248dbe0a21  vmovaps [rsp+0x30], xmm3
00007d248dbe0a27  vmovaps [rsp+0x40], xmm4
00007d248dbe0a2d  vmovaps [rsp+0x50], xmm5
00007d248dbe0a33  vmovaps [rsp+0x60], xmm6
00007d248dbe0a39  vmovaps [rsp+0x70], xmm8
00007d248dbe0a3f  vmovaps [rsp+0x80], xmm9
00007d248dbe0a48  vmovaps [rsp+0x90], xmm10
00007d248dbe0a51  vmovaps [rsp+0xA0], xmm11
00007d248dbe0a5a  vmovaps [rsp+0xB0], xmm12
00007d248dbe0a63  vmovaps [rsp+0xC0], xmm13
00007d248dbe0a6c  vmovaps [rsp+0xD0], xmm14
00007d248dbe0a75  vmovaps [rsp+0xE0], xmm15
00007d248dbe0a7e  sub rsp, 0x30
00007d248dbe0a82  movaps [rsp], xmm7
00007d248dbe0a86  movaps [rsp+0x10], xmm11
00007d248dbe0a8c  movaps [rsp+0x20], xmm9
00007d248dbe0a92  lea rdi, [rsp]
00007d248dbe0a96  mov esi, 0x00
00007d248dbe0a9b  mov rax, 0x5BCEEF236530
00007d248dbe0aa5  call rax
00007d248dbe0aa7  movaps xmm7, [rsp]
00007d248dbe0aab  add rsp, 0x30
00007d248dbe0aaf  vmovaps xmm0, [rsp]
00007d248dbe0ab4  vmovaps xmm1, [rsp+0x10]
00007d248dbe0aba  vmovaps xmm2, [rsp+0x20]
00007d248dbe0ac0  vmovaps xmm3, [rsp+0x30]
00007d248dbe0ac6  vmovaps xmm4, [rsp+0x40]
00007d248dbe0acc  vmovaps xmm5, [rsp+0x50]
00007d248dbe0ad2  vmovaps xmm6, [rsp+0x60]
00007d248dbe0ad8  vmovaps xmm8, [rsp+0x70]
00007d248dbe0ade  vmovaps xmm9, [rsp+0x80]
00007d248dbe0ae7  vmovaps xmm10, [rsp+0x90]
00007d248dbe0af0  vmovaps xmm11, [rsp+0xA0]
00007d248dbe0af9  vmovaps xmm12, [rsp+0xB0]
00007d248dbe0b02  vmovaps xmm13, [rsp+0xC0]
00007d248dbe0b0b  vmovaps xmm14, [rsp+0xD0]
00007d248dbe0b14  vmovaps xmm15, [rsp+0xE0]
00007d248dbe0b1d  add rsp, 0xF0
00007d248dbe0b24  pop r11
00007d248dbe0b26  pop r10
00007d248dbe0b28  pop r9
00007d248dbe0b2a  pop r8
00007d248dbe0b2c  pop rsi
00007d248dbe0b2d  pop rdi
00007d248dbe0b2e  pop rdx
00007d248dbe0b2f  pop rcx
00007d248dbe0b30  pop rax
00007d248dbe0b31  add rsp, 0x08
00007d248dbe0b35  jmp 0x00007D248DBDC685
00007d248dbe0b3a  sub rsp, 0x08
00007d248dbe0b3e  push rax
00007d248dbe0b3f  push rcx
00007d248dbe0b40  push rdx
00007d248dbe0b41  push rdi
00007d248dbe0b42  push rsi
00007d248dbe0b43  push r8
00007d248dbe0b45  push r9
00007d248dbe0b47  push r10
00007d248dbe0b49  push r11
00007d248dbe0b4b  sub rsp, 0xF0
00007d248dbe0b52  vmovaps [rsp], xmm0
00007d248dbe0b57  vmovaps [rsp+0x10], xmm1
00007d248dbe0b5d  vmovaps [rsp+0x20], xmm2
00007d248dbe0b63  vmovaps [rsp+0x30], xmm3
00007d248dbe0b69  vmovaps [rsp+0x40], xmm4
00007d248dbe0b6f  vmovaps [rsp+0x50], xmm5
00007d248dbe0b75  vmovaps [rsp+0x60], xmm6
00007d248dbe0b7b  vmovaps [rsp+0x70], xmm7
00007d248dbe0b81  vmovaps [rsp+0x80], xmm8
00007d248dbe0b8a  vmovaps [rsp+0x90], xmm9
00007d248dbe0b93  vmovaps [rsp+0xA0], xmm10
00007d248dbe0b9c  vmovaps [rsp+0xB0], xmm12
00007d248dbe0ba5  vmovaps [rsp+0xC0], xmm13
00007d248dbe0bae  vmovaps [rsp+0xD0], xmm14
00007d248dbe0bb7  vmovaps [rsp+0xE0], xmm15
00007d248dbe0bc0  sub rsp, 0x30
00007d248dbe0bc4  movaps [rsp], xmm11
00007d248dbe0bc9  movaps [rsp+0x10], xmm10
00007d248dbe0bcf  movaps [rsp+0x20], xmm14
00007d248dbe0bd5  lea rdi, [rsp]
00007d248dbe0bd9  mov esi, 0x00
00007d248dbe0bde  mov rax, 0x5BCEEF236530
00007d248dbe0be8  call rax
00007d248dbe0bea  movaps xmm11, [rsp]
00007d248dbe0bef  add rsp, 0x30
00007d248dbe0bf3  vmovaps xmm0, [rsp]
00007d248dbe0bf8  vmovaps xmm1, [rsp+0x10]
00007d248dbe0bfe  vmovaps xmm2, [rsp+0x20]
00007d248dbe0c04  vmovaps xmm3, [rsp+0x30]
00007d248dbe0c0a  vmovaps xmm4, [rsp+0x40]
00007d248dbe0c10  vmovaps xmm5, [rsp+0x50]
00007d248dbe0c16  vmovaps xmm6, [rsp+0x60]
00007d248dbe0c1c  vmovaps xmm7, [rsp+0x70]
00007d248dbe0c22  vmovaps xmm8, [rsp+0x80]
00007d248dbe0c2b  vmovaps xmm9, [rsp+0x90]
00007d248dbe0c34  vmovaps xmm10, [rsp+0xA0]
00007d248dbe0c3d  vmovaps xmm12, [rsp+0xB0]
00007d248dbe0c46  vmovaps xmm13, [rsp+0xC0]
00007d248dbe0c4f  vmovaps xmm14, [rsp+0xD0]
00007d248dbe0c58  vmovaps xmm15, [rsp+0xE0]
00007d248dbe0c61  add rsp, 0xF0
00007d248dbe0c68  pop r11
00007d248dbe0c6a  pop r10
00007d248dbe0c6c  pop r9
00007d248dbe0c6e  pop r8
00007d248dbe0c70  pop rsi
00007d248dbe0c71  pop rdi
00007d248dbe0c72  pop rdx
00007d248dbe0c73  pop rcx
00007d248dbe0c74  pop rax
00007d248dbe0c75  add rsp, 0x08
00007d248dbe0c79  jmp 0x00007D248DBDC6A0
00007d248dbe0c7e  call 0x00007D248DAC33A0
00007d248dbe0c83  jmp 0x00007D248DBDC6AA
00007d248dbe0c88  sub rsp, 0x08
00007d248dbe0c8c  push rax
00007d248dbe0c8d  push rcx
00007d248dbe0c8e  push rdx
00007d248dbe0c8f  push rdi
00007d248dbe0c90  push rsi
00007d248dbe0c91  push r8
00007d248dbe0c93  push r9
00007d248dbe0c95  push r10
00007d248dbe0c97  push r11
00007d248dbe0c99  sub rsp, 0xF0
00007d248dbe0ca0  vmovaps [rsp], xmm0
00007d248dbe0ca5  vmovaps [rsp+0x10], xmm1
00007d248dbe0cab  vmovaps [rsp+0x20], xmm2
00007d248dbe0cb1  vmovaps [rsp+0x30], xmm3
00007d248dbe0cb7  vmovaps [rsp+0x40], xmm4
00007d248dbe0cbd  vmovaps [rsp+0x50], xmm5
00007d248dbe0cc3  vmovaps [rsp+0x60], xmm6
00007d248dbe0cc9  vmovaps [rsp+0x70], xmm7
00007d248dbe0ccf  vmovaps [rsp+0x80], xmm8
00007d248dbe0cd8  vmovaps [rsp+0x90], xmm9
00007d248dbe0ce1  vmovaps [rsp+0xA0], xmm11
00007d248dbe0cea  vmovaps [rsp+0xB0], xmm12
00007d248dbe0cf3  vmovaps [rsp+0xC0], xmm13
00007d248dbe0cfc  vmovaps [rsp+0xD0], xmm14
00007d248dbe0d05  vmovaps [rsp+0xE0], xmm15
00007d248dbe0d0e  sub rsp, 0x30
00007d248dbe0d12  movaps [rsp], xmm10
00007d248dbe0d17  movaps [rsp+0x10], xmm1
00007d248dbe0d1c  movaps [rsp+0x20], xmm12
00007d248dbe0d22  lea rdi, [rsp]
00007d248dbe0d26  mov esi, 0x00
00007d248dbe0d2b  mov rax, 0x5BCEEF236530
00007d248dbe0d35  call rax
00007d248dbe0d37  movaps xmm10, [rsp]
00007d248dbe0d3c  add rsp, 0x30
00007d248dbe0d40  vmovaps xmm0, [rsp]
00007d248dbe0d45  vmovaps xmm1, [rsp+0x10]
00007d248dbe0d4b  vmovaps xmm2, [rsp+0x20]
00007d248dbe0d51  vmovaps xmm3, [rsp+0x30]
00007d248dbe0d57  vmovaps xmm4, [rsp+0x40]
00007d248dbe0d5d  vmovaps xmm5, [rsp+0x50]
00007d248dbe0d63  vmovaps xmm6, [rsp+0x60]
00007d248dbe0d69  vmovaps xmm7, [rsp+0x70]
00007d248dbe0d6f  vmovaps xmm8, [rsp+0x80]
00007d248dbe0d78  vmovaps xmm9, [rsp+0x90]
00007d248dbe0d81  vmovaps xmm11, [rsp+0xA0]
00007d248dbe0d8a  vmovaps xmm12, [rsp+0xB0]
00007d248dbe0d93  vmovaps xmm13, [rsp+0xC0]
00007d248dbe0d9c  vmovaps xmm14, [rsp+0xD0]
00007d248dbe0da5  vmovaps xmm15, [rsp+0xE0]
00007d248dbe0dae  add rsp, 0xF0
00007d248dbe0db5  pop r11
00007d248dbe0db7  pop r10
00007d248dbe0db9  pop r9
00007d248dbe0dbb  pop r8
00007d248dbe0dbd  pop rsi
00007d248dbe0dbe  pop rdi
00007d248dbe0dbf  pop rdx
00007d248dbe0dc0  pop rcx
00007d248dbe0dc1  pop rax
00007d248dbe0dc2  add rsp, 0x08
00007d248dbe0dc6  jmp 0x00007D248DBDC6CD
00007d248dbe0dcb  sub rsp, 0x08
00007d248dbe0dcf  push rax
00007d248dbe0dd0  push rcx
00007d248dbe0dd1  push rdx
00007d248dbe0dd2  push rdi
00007d248dbe0dd3  push rsi
00007d248dbe0dd4  push r8
00007d248dbe0dd6  push r9
00007d248dbe0dd8  push r10
00007d248dbe0dda  push r11
00007d248dbe0ddc  sub rsp, 0xF0
00007d248dbe0de3  vmovaps [rsp], xmm0
00007d248dbe0de8  vmovaps [rsp+0x10], xmm1
00007d248dbe0dee  vmovaps [rsp+0x20], xmm2
00007d248dbe0df4  vmovaps [rsp+0x30], xmm3
00007d248dbe0dfa  vmovaps [rsp+0x40], xmm4
00007d248dbe0e00  vmovaps [rsp+0x50], xmm5
00007d248dbe0e06  vmovaps [rsp+0x60], xmm6
00007d248dbe0e0c  vmovaps [rsp+0x70], xmm7
00007d248dbe0e12  vmovaps [rsp+0x80], xmm8
00007d248dbe0e1b  vmovaps [rsp+0x90], xmm9
00007d248dbe0e24  vmovaps [rsp+0xA0], xmm10
00007d248dbe0e2d  vmovaps [rsp+0xB0], xmm11
00007d248dbe0e36  vmovaps [rsp+0xC0], xmm13
00007d248dbe0e3f  vmovaps [rsp+0xD0], xmm14
00007d248dbe0e48  vmovaps [rsp+0xE0], xmm15
00007d248dbe0e51  sub rsp, 0x30
00007d248dbe0e55  movaps [rsp], xmm12
00007d248dbe0e5a  movaps [rsp+0x10], xmm14
00007d248dbe0e60  movaps [rsp+0x20], xmm1
00007d248dbe0e65  lea rdi, [rsp]
00007d248dbe0e69  mov esi, 0x00
00007d248dbe0e6e  mov rax, 0x5BCEEF236530
00007d248dbe0e78  call rax
00007d248dbe0e7a  movaps xmm12, [rsp]
00007d248dbe0e7f  add rsp, 0x30
00007d248dbe0e83  vmovaps xmm0, [rsp]
00007d248dbe0e88  vmovaps xmm1, [rsp+0x10]
00007d248dbe0e8e  vmovaps xmm2, [rsp+0x20]
00007d248dbe0e94  vmovaps xmm3, [rsp+0x30]
00007d248dbe0e9a  vmovaps xmm4, [rsp+0x40]
00007d248dbe0ea0  vmovaps xmm5, [rsp+0x50]
00007d248dbe0ea6  vmovaps xmm6, [rsp+0x60]
00007d248dbe0eac  vmovaps xmm7, [rsp+0x70]
00007d248dbe0eb2  vmovaps xmm8, [rsp+0x80]
00007d248dbe0ebb  vmovaps xmm9, [rsp+0x90]
00007d248dbe0ec4  vmovaps xmm10, [rsp+0xA0]
00007d248dbe0ecd  vmovaps xmm11, [rsp+0xB0]
00007d248dbe0ed6  vmovaps xmm13, [rsp+0xC0]
00007d248dbe0edf  vmovaps xmm14, [rsp+0xD0]
00007d248dbe0ee8  vmovaps xmm15, [rsp+0xE0]
00007d248dbe0ef1  add rsp, 0xF0
00007d248dbe0ef8  pop r11
00007d248dbe0efa  pop r10
00007d248dbe0efc  pop r9
00007d248dbe0efe  pop r8
00007d248dbe0f00  pop rsi
00007d248dbe0f01  pop rdi
00007d248dbe0f02  pop rdx
00007d248dbe0f03  pop rcx
00007d248dbe0f04  pop rax
00007d248dbe0f05  add rsp, 0x08
00007d248dbe0f09  jmp 0x00007D248DBDC6FC
00007d248dbe0f0e  sub rsp, 0x08
00007d248dbe0f12  push rax
00007d248dbe0f13  push rcx
00007d248dbe0f14  push rdx
00007d248dbe0f15  push rdi
00007d248dbe0f16  push rsi
00007d248dbe0f17  push r8
00007d248dbe0f19  push r9
00007d248dbe0f1b  push r10
00007d248dbe0f1d  push r11
00007d248dbe0f1f  sub rsp, 0xF0
00007d248dbe0f26  vmovaps [rsp], xmm0
00007d248dbe0f2b  vmovaps [rsp+0x10], xmm1
00007d248dbe0f31  vmovaps [rsp+0x20], xmm2
00007d248dbe0f37  vmovaps [rsp+0x30], xmm3
00007d248dbe0f3d  vmovaps [rsp+0x40], xmm4
00007d248dbe0f43  vmovaps [rsp+0x50], xmm5
00007d248dbe0f49  vmovaps [rsp+0x60], xmm6
00007d248dbe0f4f  vmovaps [rsp+0x70], xmm7
00007d248dbe0f55  vmovaps [rsp+0x80], xmm8
00007d248dbe0f5e  vmovaps [rsp+0x90], xmm9
00007d248dbe0f67  vmovaps [rsp+0xA0], xmm10
00007d248dbe0f70  vmovaps [rsp+0xB0], xmm11
00007d248dbe0f79  vmovaps [rsp+0xC0], xmm12
00007d248dbe0f82  vmovaps [rsp+0xD0], xmm13
00007d248dbe0f8b  vmovaps [rsp+0xE0], xmm15
00007d248dbe0f94  sub rsp, 0x30
00007d248dbe0f98  movaps [rsp], xmm14
00007d248dbe0f9d  movaps [rsp+0x10], xmm9
00007d248dbe0fa3  movaps [rsp+0x20], xmm1
00007d248dbe0fa8  lea rdi, [rsp]
00007d248dbe0fac  mov esi, 0x00
00007d248dbe0fb1  mov rax, 0x5BCEEF236530
00007d248dbe0fbb  call rax
00007d248dbe0fbd  movaps xmm14, [rsp]
00007d248dbe0fc2  add rsp, 0x30
00007d248dbe0fc6  vmovaps xmm0, [rsp]
00007d248dbe0fcb  vmovaps xmm1, [rsp+0x10]
00007d248dbe0fd1  vmovaps xmm2, [rsp+0x20]
00007d248dbe0fd7  vmovaps xmm3, [rsp+0x30]
00007d248dbe0fdd  vmovaps xmm4, [rsp+0x40]
00007d248dbe0fe3  vmovaps xmm5, [rsp+0x50]
00007d248dbe0fe9  vmovaps xmm6, [rsp+0x60]
00007d248dbe0fef  vmovaps xmm7, [rsp+0x70]
00007d248dbe0ff5  vmovaps xmm8, [rsp+0x80]
00007d248dbe0ffe  vmovaps xmm9, [rsp+0x90]
00007d248dbe1007  vmovaps xmm10, [rsp+0xA0]
00007d248dbe1010  vmovaps xmm11, [rsp+0xB0]
00007d248dbe1019  vmovaps xmm12, [rsp+0xC0]
00007d248dbe1022  vmovaps xmm13, [rsp+0xD0]
00007d248dbe102b  vmovaps xmm15, [rsp+0xE0]
00007d248dbe1034  add rsp, 0xF0
00007d248dbe103b  pop r11
00007d248dbe103d  pop r10
00007d248dbe103f  pop r9
00007d248dbe1041  pop r8
00007d248dbe1043  pop rsi
00007d248dbe1044  pop rdi
00007d248dbe1045  pop rdx
00007d248dbe1046  pop rcx
00007d248dbe1047  pop rax
00007d248dbe1048  add rsp, 0x08
00007d248dbe104c  jmp 0x00007D248DBDC72B
00007d248dbe1051  sub rsp, 0x08
00007d248dbe1055  push rax
00007d248dbe1056  push rcx
00007d248dbe1057  push rdx
00007d248dbe1058  push rdi
00007d248dbe1059  push rsi
00007d248dbe105a  push r8
00007d248dbe105c  push r9
00007d248dbe105e  push r10
00007d248dbe1060  push r11
00007d248dbe1062  sub rsp, 0xF0
00007d248dbe1069  vmovaps [rsp], xmm0
00007d248dbe106e  vmovaps [rsp+0x10], xmm2
00007d248dbe1074  vmovaps [rsp+0x20], xmm3
00007d248dbe107a  vmovaps [rsp+0x30], xmm4
00007d248dbe1080  vmovaps [rsp+0x40], xmm5
00007d248dbe1086  vmovaps [rsp+0x50], xmm6
00007d248dbe108c  vmovaps [rsp+0x60], xmm7
00007d248dbe1092  vmovaps [rsp+0x70], xmm8
00007d248dbe1098  vmovaps [rsp+0x80], xmm9
00007d248dbe10a1  vmovaps [rsp+0x90], xmm10
00007d248dbe10aa  vmovaps [rsp+0xA0], xmm11
00007d248dbe10b3  vmovaps [rsp+0xB0], xmm12
00007d248dbe10bc  vmovaps [rsp+0xC0], xmm13
00007d248dbe10c5  vmovaps [rsp+0xD0], xmm14
00007d248dbe10ce  vmovaps [rsp+0xE0], xmm15
00007d248dbe10d7  sub rsp, 0x30
00007d248dbe10db  movaps [rsp], xmm1
00007d248dbe10df  movaps [rsp+0x10], xmm13
00007d248dbe10e5  movaps [rsp+0x20], xmm8
00007d248dbe10eb  lea rdi, [rsp]
00007d248dbe10ef  mov esi, 0x00
00007d248dbe10f4  mov rax, 0x5BCEEF236530
00007d248dbe10fe  call rax
00007d248dbe1100  movaps xmm1, [rsp]
00007d248dbe1104  add rsp, 0x30
00007d248dbe1108  vmovaps xmm0, [rsp]
00007d248dbe110d  vmovaps xmm2, [rsp+0x10]
00007d248dbe1113  vmovaps xmm3, [rsp+0x20]
00007d248dbe1119  vmovaps xmm4, [rsp+0x30]
00007d248dbe111f  vmovaps xmm5, [rsp+0x40]
00007d248dbe1125  vmovaps xmm6, [rsp+0x50]
00007d248dbe112b  vmovaps xmm7, [rsp+0x60]
00007d248dbe1131  vmovaps xmm8, [rsp+0x70]
00007d248dbe1137  vmovaps xmm9, [rsp+0x80]
00007d248dbe1140  vmovaps xmm10, [rsp+0x90]
00007d248dbe1149  vmovaps xmm11, [rsp+0xA0]
00007d248dbe1152  vmovaps xmm12, [rsp+0xB0]
00007d248dbe115b  vmovaps xmm13, [rsp+0xC0]
00007d248dbe1164  vmovaps xmm14, [rsp+0xD0]
00007d248dbe116d  vmovaps xmm15, [rsp+0xE0]
00007d248dbe1176  add rsp, 0xF0
00007d248dbe117d  pop r11
00007d248dbe117f  pop r10
00007d248dbe1181  pop r9
00007d248dbe1183  pop r8
00007d248dbe1185  pop rsi
00007d248dbe1186  pop rdi
00007d248dbe1187  pop rdx
00007d248dbe1188  pop rcx
00007d248dbe1189  pop rax
00007d248dbe118a  add rsp, 0x08
00007d248dbe118e  jmp 0x00007D248DBDC74D
00007d248dbe1193  call 0x00007D248DA0C260
00007d248dbe1198  jmp 0x00007D248DBDC75B
00007d248dbe119d  call 0x00007D248DABD750
00007d248dbe11a2  jmp 0x00007D248DBDC765
00007d248dbe11a7  sub rsp, 0x08
00007d248dbe11ab  push rax
00007d248dbe11ac  push rcx
00007d248dbe11ad  push rdx
00007d248dbe11ae  push rdi
00007d248dbe11af  push rsi
00007d248dbe11b0  push r8
00007d248dbe11b2  push r9
00007d248dbe11b4  push r10
00007d248dbe11b6  push r11
00007d248dbe11b8  sub rsp, 0xF0
00007d248dbe11bf  vmovaps [rsp], xmm0
00007d248dbe11c4  vmovaps [rsp+0x10], xmm1
00007d248dbe11ca  vmovaps [rsp+0x20], xmm2
00007d248dbe11d0  vmovaps [rsp+0x30], xmm3
00007d248dbe11d6  vmovaps [rsp+0x40], xmm4
00007d248dbe11dc  vmovaps [rsp+0x50], xmm5
00007d248dbe11e2  vmovaps [rsp+0x60], xmm6
00007d248dbe11e8  vmovaps [rsp+0x70], xmm7
00007d248dbe11ee  vmovaps [rsp+0x80], xmm9
00007d248dbe11f7  vmovaps [rsp+0x90], xmm10
00007d248dbe1200  vmovaps [rsp+0xA0], xmm11
00007d248dbe1209  vmovaps [rsp+0xB0], xmm12
00007d248dbe1212  vmovaps [rsp+0xC0], xmm13
00007d248dbe121b  vmovaps [rsp+0xD0], xmm14
00007d248dbe1224  vmovaps [rsp+0xE0], xmm15
00007d248dbe122d  sub rsp, 0x30
00007d248dbe1231  movaps [rsp], xmm8
00007d248dbe1236  movaps [rsp+0x10], xmm15
00007d248dbe123c  movaps [rsp+0x20], xmm7
00007d248dbe1241  lea rdi, [rsp]
00007d248dbe1245  mov esi, 0x00
00007d248dbe124a  mov rax, 0x5BCEEF236530
00007d248dbe1254  call rax
00007d248dbe1256  movaps xmm8, [rsp]
00007d248dbe125b  add rsp, 0x30
00007d248dbe125f  vmovaps xmm0, [rsp]
00007d248dbe1264  vmovaps xmm1, [rsp+0x10]
00007d248dbe126a  vmovaps xmm2, [rsp+0x20]
00007d248dbe1270  vmovaps xmm3, [rsp+0x30]
00007d248dbe1276  vmovaps xmm4, [rsp+0x40]
00007d248dbe127c  vmovaps xmm5, [rsp+0x50]
00007d248dbe1282  vmovaps xmm6, [rsp+0x60]
00007d248dbe1288  vmovaps xmm7, [rsp+0x70]
00007d248dbe128e  vmovaps xmm9, [rsp+0x80]
00007d248dbe1297  vmovaps xmm10, [rsp+0x90]
00007d248dbe12a0  vmovaps xmm11, [rsp+0xA0]
00007d248dbe12a9  vmovaps xmm12, [rsp+0xB0]
00007d248dbe12b2  vmovaps xmm13, [rsp+0xC0]
00007d248dbe12bb  vmovaps xmm14, [rsp+0xD0]
00007d248dbe12c4  vmovaps xmm15, [rsp+0xE0]
00007d248dbe12cd  add rsp, 0xF0
00007d248dbe12d4  pop r11
00007d248dbe12d6  pop r10
00007d248dbe12d8  pop r9
00007d248dbe12da  pop r8
00007d248dbe12dc  pop rsi
00007d248dbe12dd  pop rdi
00007d248dbe12de  pop rdx
00007d248dbe12df  pop rcx
00007d248dbe12e0  pop rax
00007d248dbe12e1  add rsp, 0x08
00007d248dbe12e5  jmp 0x00007D248DBDC787
00007d248dbe12ea  sub rsp, 0x08
00007d248dbe12ee  push rax
00007d248dbe12ef  push rcx
00007d248dbe12f0  push rdx
00007d248dbe12f1  push rdi
00007d248dbe12f2  push rsi
00007d248dbe12f3  push r8
00007d248dbe12f5  push r9
00007d248dbe12f7  push r10
00007d248dbe12f9  push r11
00007d248dbe12fb  sub rsp, 0xF0
00007d248dbe1302  vmovaps [rsp], xmm0
00007d248dbe1307  vmovaps [rsp+0x10], xmm1
00007d248dbe130d  vmovaps [rsp+0x20], xmm2
00007d248dbe1313  vmovaps [rsp+0x30], xmm3
00007d248dbe1319  vmovaps [rsp+0x40], xmm4
00007d248dbe131f  vmovaps [rsp+0x50], xmm5
00007d248dbe1325  vmovaps [rsp+0x60], xmm6
00007d248dbe132b  vmovaps [rsp+0x70], xmm8
00007d248dbe1331  vmovaps [rsp+0x80], xmm9
00007d248dbe133a  vmovaps [rsp+0x90], xmm10
00007d248dbe1343  vmovaps [rsp+0xA0], xmm11
00007d248dbe134c  vmovaps [rsp+0xB0], xmm12
00007d248dbe1355  vmovaps [rsp+0xC0], xmm13
00007d248dbe135e  vmovaps [rsp+0xD0], xmm14
00007d248dbe1367  vmovaps [rsp+0xE0], xmm15
00007d248dbe1370  sub rsp, 0x30
00007d248dbe1374  movaps [rsp], xmm7
00007d248dbe1378  movaps [rsp+0x10], xmm9
00007d248dbe137e  movaps [rsp+0x20], xmm15
00007d248dbe1384  lea rdi, [rsp]
00007d248dbe1388  mov esi, 0x00
00007d248dbe138d  mov rax, 0x5BCEEF236530
00007d248dbe1397  call rax
00007d248dbe1399  movaps xmm7, [rsp]
00007d248dbe139d  add rsp, 0x30
00007d248dbe13a1  vmovaps xmm0, [rsp]
00007d248dbe13a6  vmovaps xmm1, [rsp+0x10]
00007d248dbe13ac  vmovaps xmm2, [rsp+0x20]
00007d248dbe13b2  vmovaps xmm3, [rsp+0x30]
00007d248dbe13b8  vmovaps xmm4, [rsp+0x40]
00007d248dbe13be  vmovaps xmm5, [rsp+0x50]
00007d248dbe13c4  vmovaps xmm6, [rsp+0x60]
00007d248dbe13ca  vmovaps xmm8, [rsp+0x70]
00007d248dbe13d0  vmovaps xmm9, [rsp+0x80]
00007d248dbe13d9  vmovaps xmm10, [rsp+0x90]
00007d248dbe13e2  vmovaps xmm11, [rsp+0xA0]
00007d248dbe13eb  vmovaps xmm12, [rsp+0xB0]
00007d248dbe13f4  vmovaps xmm13, [rsp+0xC0]
00007d248dbe13fd  vmovaps xmm14, [rsp+0xD0]
00007d248dbe1406  vmovaps xmm15, [rsp+0xE0]
00007d248dbe140f  add rsp, 0xF0
00007d248dbe1416  pop r11
00007d248dbe1418  pop r10
00007d248dbe141a  pop r9
00007d248dbe141c  pop r8
00007d248dbe141e  pop rsi
00007d248dbe141f  pop rdi
00007d248dbe1420  pop rdx
00007d248dbe1421  pop rcx
00007d248dbe1422  pop rax
00007d248dbe1423  add rsp, 0x08
00007d248dbe1427  jmp 0x00007D248DBDC7B4
00007d248dbe142c  sub rsp, 0x08
00007d248dbe1430  push rax
00007d248dbe1431  push rcx
00007d248dbe1432  push rdx
00007d248dbe1433  push rdi
00007d248dbe1434  push rsi
00007d248dbe1435  push r8
00007d248dbe1437  push r9
00007d248dbe1439  push r10
00007d248dbe143b  push r11
00007d248dbe143d  sub rsp, 0xF0
00007d248dbe1444  vmovaps [rsp], xmm0
00007d248dbe1449  vmovaps [rsp+0x10], xmm1
00007d248dbe144f  vmovaps [rsp+0x20], xmm2
00007d248dbe1455  vmovaps [rsp+0x30], xmm3
00007d248dbe145b  vmovaps [rsp+0x40], xmm4
00007d248dbe1461  vmovaps [rsp+0x50], xmm5
00007d248dbe1467  vmovaps [rsp+0x60], xmm6
00007d248dbe146d  vmovaps [rsp+0x70], xmm7
00007d248dbe1473  vmovaps [rsp+0x80], xmm8
00007d248dbe147c  vmovaps [rsp+0x90], xmm10
00007d248dbe1485  vmovaps [rsp+0xA0], xmm11
00007d248dbe148e  vmovaps [rsp+0xB0], xmm12
00007d248dbe1497  vmovaps [rsp+0xC0], xmm13
00007d248dbe14a0  vmovaps [rsp+0xD0], xmm14
00007d248dbe14a9  vmovaps [rsp+0xE0], xmm15
00007d248dbe14b2  sub rsp, 0x30
00007d248dbe14b6  movaps [rsp], xmm9
00007d248dbe14bb  movaps [rsp+0x10], xmm13
00007d248dbe14c1  movaps [rsp+0x20], xmm15
00007d248dbe14c7  lea rdi, [rsp]
00007d248dbe14cb  mov esi, 0x00
00007d248dbe14d0  mov rax, 0x5BCEEF236530
00007d248dbe14da  call rax
00007d248dbe14dc  movaps xmm9, [rsp]
00007d248dbe14e1  add rsp, 0x30
00007d248dbe14e5  vmovaps xmm0, [rsp]
00007d248dbe14ea  vmovaps xmm1, [rsp+0x10]
00007d248dbe14f0  vmovaps xmm2, [rsp+0x20]
00007d248dbe14f6  vmovaps xmm3, [rsp+0x30]
00007d248dbe14fc  vmovaps xmm4, [rsp+0x40]
00007d248dbe1502  vmovaps xmm5, [rsp+0x50]
00007d248dbe1508  vmovaps xmm6, [rsp+0x60]
00007d248dbe150e  vmovaps xmm7, [rsp+0x70]
00007d248dbe1514  vmovaps xmm8, [rsp+0x80]
00007d248dbe151d  vmovaps xmm10, [rsp+0x90]
00007d248dbe1526  vmovaps xmm11, [rsp+0xA0]
00007d248dbe152f  vmovaps xmm12, [rsp+0xB0]
00007d248dbe1538  vmovaps xmm13, [rsp+0xC0]
00007d248dbe1541  vmovaps xmm14, [rsp+0xD0]
00007d248dbe154a  vmovaps xmm15, [rsp+0xE0]
00007d248dbe1553  add rsp, 0xF0
00007d248dbe155a  pop r11
00007d248dbe155c  pop r10
00007d248dbe155e  pop r9
00007d248dbe1560  pop r8
00007d248dbe1562  pop rsi
00007d248dbe1563  pop rdi
00007d248dbe1564  pop rdx
00007d248dbe1565  pop rcx
00007d248dbe1566  pop rax
00007d248dbe1567  add rsp, 0x08
00007d248dbe156b  jmp 0x00007D248DBDC7E2
00007d248dbe1570  sub rsp, 0x08
00007d248dbe1574  push rax
00007d248dbe1575  push rcx
00007d248dbe1576  push rdx
00007d248dbe1577  push rdi
00007d248dbe1578  push rsi
00007d248dbe1579  push r8
00007d248dbe157b  push r9
00007d248dbe157d  push r10
00007d248dbe157f  push r11
00007d248dbe1581  sub rsp, 0xF0
00007d248dbe1588  vmovaps [rsp], xmm0
00007d248dbe158d  vmovaps [rsp+0x10], xmm1
00007d248dbe1593  vmovaps [rsp+0x20], xmm2
00007d248dbe1599  vmovaps [rsp+0x30], xmm3
00007d248dbe159f  vmovaps [rsp+0x40], xmm4
00007d248dbe15a5  vmovaps [rsp+0x50], xmm5
00007d248dbe15ab  vmovaps [rsp+0x60], xmm6
00007d248dbe15b1  vmovaps [rsp+0x70], xmm7
00007d248dbe15b7  vmovaps [rsp+0x80], xmm8
00007d248dbe15c0  vmovaps [rsp+0x90], xmm9
00007d248dbe15c9  vmovaps [rsp+0xA0], xmm10
00007d248dbe15d2  vmovaps [rsp+0xB0], xmm11
00007d248dbe15db  vmovaps [rsp+0xC0], xmm12
00007d248dbe15e4  vmovaps [rsp+0xD0], xmm13
00007d248dbe15ed  vmovaps [rsp+0xE0], xmm14
00007d248dbe15f6  sub rsp, 0x30
00007d248dbe15fa  movaps [rsp], xmm15
00007d248dbe15ff  movaps [rsp+0x10], xmm11
00007d248dbe1605  movaps [rsp+0x20], xmm12
00007d248dbe160b  lea rdi, [rsp]
00007d248dbe160f  mov esi, 0x00
00007d248dbe1614  mov rax, 0x5BCEEF236530
00007d248dbe161e  call rax
00007d248dbe1620  movaps xmm15, [rsp]
00007d248dbe1625  add rsp, 0x30
00007d248dbe1629  vmovaps xmm0, [rsp]
00007d248dbe162e  vmovaps xmm1, [rsp+0x10]
00007d248dbe1634  vmovaps xmm2, [rsp+0x20]
00007d248dbe163a  vmovaps xmm3, [rsp+0x30]
00007d248dbe1640  vmovaps xmm4, [rsp+0x40]
00007d248dbe1646  vmovaps xmm5, [rsp+0x50]
00007d248dbe164c  vmovaps xmm6, [rsp+0x60]
00007d248dbe1652  vmovaps xmm7, [rsp+0x70]
00007d248dbe1658  vmovaps xmm8, [rsp+0x80]
00007d248dbe1661  vmovaps xmm9, [rsp+0x90]
00007d248dbe166a  vmovaps xmm10, [rsp+0xA0]
00007d248dbe1673  vmovaps xmm11, [rsp+0xB0]
00007d248dbe167c  vmovaps xmm12, [rsp+0xC0]
00007d248dbe1685  vmovaps xmm13, [rsp+0xD0]
00007d248dbe168e  vmovaps xmm14, [rsp+0xE0]
00007d248dbe1697  add rsp, 0xF0
00007d248dbe169e  pop r11
00007d248dbe16a0  pop r10
00007d248dbe16a2  pop r9
00007d248dbe16a4  pop r8
00007d248dbe16a6  pop rsi
00007d248dbe16a7  pop rdi
00007d248dbe16a8  pop rdx
00007d248dbe16a9  pop rcx
00007d248dbe16aa  pop rax
00007d248dbe16ab  add rsp, 0x08
00007d248dbe16af  jmp 0x00007D248DBDC7FD
00007d248dbe16b4  sub rsp, 0x08
00007d248dbe16b8  push rax
00007d248dbe16b9  push rcx
00007d248dbe16ba  push rdx
00007d248dbe16bb  push rdi
00007d248dbe16bc  push rsi
00007d248dbe16bd  push r8
00007d248dbe16bf  push r9
00007d248dbe16c1  push r10
00007d248dbe16c3  push r11
00007d248dbe16c5  sub rsp, 0xF0
00007d248dbe16cc  vmovaps [rsp], xmm0
00007d248dbe16d1  vmovaps [rsp+0x10], xmm1
00007d248dbe16d7  vmovaps [rsp+0x20], xmm2
00007d248dbe16dd  vmovaps [rsp+0x30], xmm3
00007d248dbe16e3  vmovaps [rsp+0x40], xmm4
00007d248dbe16e9  vmovaps [rsp+0x50], xmm5
00007d248dbe16ef  vmovaps [rsp+0x60], xmm6
00007d248dbe16f5  vmovaps [rsp+0x70], xmm7
00007d248dbe16fb  vmovaps [rsp+0x80], xmm8
00007d248dbe1704  vmovaps [rsp+0x90], xmm9
00007d248dbe170d  vmovaps [rsp+0xA0], xmm10
00007d248dbe1716  vmovaps [rsp+0xB0], xmm11
00007d248dbe171f  vmovaps [rsp+0xC0], xmm12
00007d248dbe1728  vmovaps [rsp+0xD0], xmm14
00007d248dbe1731  vmovaps [rsp+0xE0], xmm15
00007d248dbe173a  sub rsp, 0x30
00007d248dbe173e  movaps [rsp], xmm13
00007d248dbe1743  movaps [rsp+0x10], xmm10
00007d248dbe1749  movaps [rsp+0x20], xmm14
00007d248dbe174f  lea rdi, [rsp]
00007d248dbe1753  mov esi, 0x00
00007d248dbe1758  mov rax, 0x5BCEEF236530
00007d248dbe1762  call rax
00007d248dbe1764  movaps xmm13, [rsp]
00007d248dbe1769  add rsp, 0x30
00007d248dbe176d  vmovaps xmm0, [rsp]
00007d248dbe1772  vmovaps xmm1, [rsp+0x10]
00007d248dbe1778  vmovaps xmm2, [rsp+0x20]
00007d248dbe177e  vmovaps xmm3, [rsp+0x30]
00007d248dbe1784  vmovaps xmm4, [rsp+0x40]
00007d248dbe178a  vmovaps xmm5, [rsp+0x50]
00007d248dbe1790  vmovaps xmm6, [rsp+0x60]
00007d248dbe1796  vmovaps xmm7, [rsp+0x70]
00007d248dbe179c  vmovaps xmm8, [rsp+0x80]
00007d248dbe17a5  vmovaps xmm9, [rsp+0x90]
00007d248dbe17ae  vmovaps xmm10, [rsp+0xA0]
00007d248dbe17b7  vmovaps xmm11, [rsp+0xB0]
00007d248dbe17c0  vmovaps xmm12, [rsp+0xC0]
00007d248dbe17c9  vmovaps xmm14, [rsp+0xD0]
00007d248dbe17d2  vmovaps xmm15, [rsp+0xE0]
00007d248dbe17db  add rsp, 0xF0
00007d248dbe17e2  pop r11
00007d248dbe17e4  pop r10
00007d248dbe17e6  pop r9
00007d248dbe17e8  pop r8
00007d248dbe17ea  pop rsi
00007d248dbe17eb  pop rdi
00007d248dbe17ec  pop rdx
00007d248dbe17ed  pop rcx
00007d248dbe17ee  pop rax
00007d248dbe17ef  add rsp, 0x08
00007d248dbe17f3  jmp 0x00007D248DBDC820
00007d248dbe17f8  sub rsp, 0x08
00007d248dbe17fc  push rax
00007d248dbe17fd  push rcx
00007d248dbe17fe  push rdx
00007d248dbe17ff  push rdi
00007d248dbe1800  push rsi
00007d248dbe1801  push r8
00007d248dbe1803  push r9
00007d248dbe1805  push r10
00007d248dbe1807  push r11
00007d248dbe1809  sub rsp, 0xF0
00007d248dbe1810  vmovaps [rsp], xmm0
00007d248dbe1815  vmovaps [rsp+0x10], xmm1
00007d248dbe181b  vmovaps [rsp+0x20], xmm2
00007d248dbe1821  vmovaps [rsp+0x30], xmm3
00007d248dbe1827  vmovaps [rsp+0x40], xmm4
00007d248dbe182d  vmovaps [rsp+0x50], xmm5
00007d248dbe1833  vmovaps [rsp+0x60], xmm6
00007d248dbe1839  vmovaps [rsp+0x70], xmm7
00007d248dbe183f  vmovaps [rsp+0x80], xmm8
00007d248dbe1848  vmovaps [rsp+0x90], xmm9
00007d248dbe1851  vmovaps [rsp+0xA0], xmm10
00007d248dbe185a  vmovaps [rsp+0xB0], xmm11
00007d248dbe1863  vmovaps [rsp+0xC0], xmm12
00007d248dbe186c  vmovaps [rsp+0xD0], xmm13
00007d248dbe1875  vmovaps [rsp+0xE0], xmm15
00007d248dbe187e  sub rsp, 0x30
00007d248dbe1882  movaps [rsp], xmm14
00007d248dbe1887  movaps [rsp+0x10], xmm1
00007d248dbe188c  movaps [rsp+0x20], xmm7
00007d248dbe1891  lea rdi, [rsp]
00007d248dbe1895  mov esi, 0x00
00007d248dbe189a  mov rax, 0x5BCEEF236530
00007d248dbe18a4  call rax
00007d248dbe18a6  movaps xmm14, [rsp]
00007d248dbe18ab  add rsp, 0x30
00007d248dbe18af  vmovaps xmm0, [rsp]
00007d248dbe18b4  vmovaps xmm1, [rsp+0x10]
00007d248dbe18ba  vmovaps xmm2, [rsp+0x20]
00007d248dbe18c0  vmovaps xmm3, [rsp+0x30]
00007d248dbe18c6  vmovaps xmm4, [rsp+0x40]
00007d248dbe18cc  vmovaps xmm5, [rsp+0x50]
00007d248dbe18d2  vmovaps xmm6, [rsp+0x60]
00007d248dbe18d8  vmovaps xmm7, [rsp+0x70]
00007d248dbe18de  vmovaps xmm8, [rsp+0x80]
00007d248dbe18e7  vmovaps xmm9, [rsp+0x90]
00007d248dbe18f0  vmovaps xmm10, [rsp+0xA0]
00007d248dbe18f9  vmovaps xmm11, [rsp+0xB0]
00007d248dbe1902  vmovaps xmm12, [rsp+0xC0]
00007d248dbe190b  vmovaps xmm13, [rsp+0xD0]
00007d248dbe1914  vmovaps xmm15, [rsp+0xE0]
00007d248dbe191d  add rsp, 0xF0
00007d248dbe1924  pop r11
00007d248dbe1926  pop r10
00007d248dbe1928  pop r9
00007d248dbe192a  pop r8
00007d248dbe192c  pop rsi
00007d248dbe192d  pop rdi
00007d248dbe192e  pop rdx
00007d248dbe192f  pop rcx
00007d248dbe1930  pop rax
00007d248dbe1931  add rsp, 0x08
00007d248dbe1935  jmp 0x00007D248DBDC843
00007d248dbe193a  sub rsp, 0x08
00007d248dbe193e  push rax
00007d248dbe193f  push rcx
00007d248dbe1940  push rdx
00007d248dbe1941  push rdi
00007d248dbe1942  push rsi
00007d248dbe1943  push r8
00007d248dbe1945  push r9
00007d248dbe1947  push r10
00007d248dbe1949  push r11
00007d248dbe194b  sub rsp, 0xF0
00007d248dbe1952  vmovaps [rsp], xmm0
00007d248dbe1957  vmovaps [rsp+0x10], xmm2
00007d248dbe195d  vmovaps [rsp+0x20], xmm3
00007d248dbe1963  vmovaps [rsp+0x30], xmm4
00007d248dbe1969  vmovaps [rsp+0x40], xmm5
00007d248dbe196f  vmovaps [rsp+0x50], xmm6
00007d248dbe1975  vmovaps [rsp+0x60], xmm7
00007d248dbe197b  vmovaps [rsp+0x70], xmm8
00007d248dbe1981  vmovaps [rsp+0x80], xmm9
00007d248dbe198a  vmovaps [rsp+0x90], xmm10
00007d248dbe1993  vmovaps [rsp+0xA0], xmm11
00007d248dbe199c  vmovaps [rsp+0xB0], xmm12
00007d248dbe19a5  vmovaps [rsp+0xC0], xmm13
00007d248dbe19ae  vmovaps [rsp+0xD0], xmm14
00007d248dbe19b7  vmovaps [rsp+0xE0], xmm15
00007d248dbe19c0  sub rsp, 0x30
00007d248dbe19c4  movaps [rsp], xmm1
00007d248dbe19c8  movaps [rsp+0x10], xmm8
00007d248dbe19ce  movaps [rsp+0x20], xmm9
00007d248dbe19d4  lea rdi, [rsp]
00007d248dbe19d8  mov esi, 0x00
00007d248dbe19dd  mov rax, 0x5BCEEF236530
00007d248dbe19e7  call rax
00007d248dbe19e9  movaps xmm1, [rsp]
00007d248dbe19ed  add rsp, 0x30
00007d248dbe19f1  vmovaps xmm0, [rsp]
00007d248dbe19f6  vmovaps xmm2, [rsp+0x10]
00007d248dbe19fc  vmovaps xmm3, [rsp+0x20]
00007d248dbe1a02  vmovaps xmm4, [rsp+0x30]
00007d248dbe1a08  vmovaps xmm5, [rsp+0x40]
00007d248dbe1a0e  vmovaps xmm6, [rsp+0x50]
00007d248dbe1a14  vmovaps xmm7, [rsp+0x60]
00007d248dbe1a1a  vmovaps xmm8, [rsp+0x70]
00007d248dbe1a20  vmovaps xmm9, [rsp+0x80]
00007d248dbe1a29  vmovaps xmm10, [rsp+0x90]
00007d248dbe1a32  vmovaps xmm11, [rsp+0xA0]
00007d248dbe1a3b  vmovaps xmm12, [rsp+0xB0]
00007d248dbe1a44  vmovaps xmm13, [rsp+0xC0]
00007d248dbe1a4d  vmovaps xmm14, [rsp+0xD0]
00007d248dbe1a56  vmovaps xmm15, [rsp+0xE0]
00007d248dbe1a5f  add rsp, 0xF0
00007d248dbe1a66  pop r11
00007d248dbe1a68  pop r10
00007d248dbe1a6a  pop r9
00007d248dbe1a6c  pop r8
00007d248dbe1a6e  pop rsi
00007d248dbe1a6f  pop rdi
00007d248dbe1a70  pop rdx
00007d248dbe1a71  pop rcx
00007d248dbe1a72  pop rax
00007d248dbe1a73  add rsp, 0x08
00007d248dbe1a77  jmp 0x00007D248DBDC865
00007d248dbe1a7c  call 0x00007D248DAE5940
00007d248dbe1a81  jmp 0x00007D248DBDC873
00007d248dbe1a86  call 0x00007D248DA0C380
00007d248dbe1a8b  jmp 0x00007D248DBDC87D
00007d248dbe1a90  call 0x00007D248DA0D600
00007d248dbe1a95  jmp 0x00007D248DBDC887
00007d248dbe1a9a  call 0x00007D248D9FF540
00007d248dbe1a9f  jmp 0x00007D248DBDC891
00007d248dbe1aa4  int3
00007d248dbe1aa5  nop [rax+rax*1], ax
00007d248dbe1aae  nop
00007d248dbe1ab0  mov rax, [r15+0xF8]
00007d248dbe1ab7  lea r14, [rax+0x140]
00007d248dbe1abe  mov r12, [r13+r14*1]
00007d248dbe1ac3  mov [r15+0xE8], r12
00007d248dbe1aca  lea r14, [rax+0x130]
00007d248dbe1ad1  mov r12, [r13+r14*1]
00007d248dbe1ad6  lea r14, [rax+0x138]
00007d248dbe1add  mov r11, [r13+r14*1]
00007d248dbe1ae2  movq xmm1, r12
00007d248dbe1ae7  movq xmm15, r11
00007d248dbe1aec  movq xmm1, xmm1
00007d248dbe1af0  movq xmm1, xmm1
00007d248dbe1af4  movaps [r15+0x1A0], xmm1
00007d248dbe1afc  movq xmm15, xmm15
00007d248dbe1b01  movq xmm15, xmm15
00007d248dbe1b06  movaps [r15+0x190], xmm15
00007d248dbe1b0e  lea r14, [rax+0x120]
00007d248dbe1b15  mov r12, [r13+r14*1]
00007d248dbe1b1a  lea r14, [rax+0x128]
00007d248dbe1b21  mov r11, [r13+r14*1]
00007d248dbe1b26  movq xmm1, r12
00007d248dbe1b2b  movq xmm15, r11
00007d248dbe1b30  movq xmm1, xmm1
00007d248dbe1b34  movq xmm1, xmm1
00007d248dbe1b38  movaps [r15+0x1C0], xmm1
00007d248dbe1b40  movq xmm15, xmm15
00007d248dbe1b45  movq xmm15, xmm15
00007d248dbe1b4a  movaps [r15+0x1B0], xmm15
00007d248dbe1b52  lea r14, [rax+0x110]
00007d248dbe1b59  mov r12, [r13+r14*1]
00007d248dbe1b5e  lea r14, [rax+0x118]
00007d248dbe1b65  mov r11, [r13+r14*1]
00007d248dbe1b6a  movq xmm1, r12
00007d248dbe1b6f  movq xmm15, r11
00007d248dbe1b74  movq xmm1, xmm1
00007d248dbe1b78  movq xmm1, xmm1
00007d248dbe1b7c  movaps [r15+0x1E0], xmm1
00007d248dbe1b84  movq xmm15, xmm15
00007d248dbe1b89  movq xmm15, xmm15
00007d248dbe1b8e  movaps [r15+0x1D0], xmm15
00007d248dbe1b96  lea r14, [rax+0x100]
00007d248dbe1b9d  mov r12, [r13+r14*1]
00007d248dbe1ba2  lea r14, [rax+0x108]
00007d248dbe1ba9  mov r11, [r13+r14*1]
00007d248dbe1bae  movq xmm1, r12
00007d248dbe1bb3  movq xmm15, r11
00007d248dbe1bb8  movq xmm1, xmm1
00007d248dbe1bbc  movq xmm1, xmm1
00007d248dbe1bc0  movaps [r15+0x200], xmm1
00007d248dbe1bc8  movq xmm15, xmm15
00007d248dbe1bcd  movq xmm15, xmm15
00007d248dbe1bd2  movaps [r15+0x1F0], xmm15
00007d248dbe1bda  mov qword ptr [r15+0x40], 0x430000
00007d248dbe1be2  mov r14d, 0x430510
00007d248dbe1be8  mov r12, [r13+r14*1]
00007d248dbe1bed  movq xmm1, r12
00007d248dbe1bf2  lea r14, [rax+0x150]
00007d248dbe1bf9  mov [r15+0xF8], r14
00007d248dbe1c00  mov rax, [r15+0x50]
00007d248dbe1c04  movups xmm15, [r13+rax*1]
00007d248dbe1c0a  movaps [r15+0x120], xmm15
00007d248dbe1c12  mov qword ptr [r15+0x48], 0x10
00007d248dbe1c1a  xor eax, eax
00007d248dbe1c1c  mov r14d, 0x10
00007d248dbe1c22  mov r12d, 0x200
00007d248dbe1c28  cmp r14, r12
00007d248dbe1c2b  cmc
00007d248dbe1c2c  lahf
00007d248dbe1c2d  seto al
00007d248dbe1c30  mov [r15+0x108], eax
00007d248dbe1c37  pextrq rax, xmm15, 0x01
00007d248dbe1c3e  movq xmm14, rax
00007d248dbe1c43  movaps [r15+0x130], xmm14
00007d248dbe1c4b  movq rax, xmm1
00007d248dbe1c50  movq r14, xmm15
00007d248dbe1c55  vmovq xmm1, rax
00007d248dbe1c5a  vmovq xmm15, r14
00007d248dbe1c5f  movaps xmm13, xmm1
00007d248dbe1c63  addsd xmm13, xmm15
00007d248dbe1c68  ucomisd xmm13, xmm13
00007d248dbe1c6d  jp 0x00007D248DBE1D86
00007d248dbe1c73  movq xmm13, xmm13
00007d248dbe1c78  movq rax, xmm13
00007d248dbe1c7d  movq r14, xmm14
00007d248dbe1c82  vmovq xmm1, rax
00007d248dbe1c87  vmovq xmm15, r14
00007d248dbe1c8c  movaps xmm14, xmm1
00007d248dbe1c90  addsd xmm14, xmm15
00007d248dbe1c95  ucomisd xmm14, xmm14
00007d248dbe1c9a  jp 0x00007D248DBE1DCE
00007d248dbe1ca0  movq xmm14, xmm14
00007d248dbe1ca5  movaps [r15+0x110], xmm14
00007d248dbe1cad  mov eax, [r15+0x108]
00007d248dbe1cb4  sahf
00007d248dbe1cb5  jnz 0x00007D248DBE1CE7
00007d248dbe1cb7  cmp dword ptr [r15+0x318], 0x00
00007d248dbe1cbf  jz 0x00007D248DBE1FE0
00007d248dbe1cc5  nop [rax+rax*1], ax
00007d248dbe1cce  nop [rax+rax*1], eax
00007d248dbe1cd6  mov eax, 0x410490
00007d248dbe1cdb  mov [r15+0x100], rax
00007d248dbe1ce2  jmp 0x00007D248D9FE110
00007d248dbe1ce7  cmp dword ptr [r15+0x318], 0x00
00007d248dbe1cef  jz 0x00007D248DBE1E20
00007d248dbe1cf5  nop [rax+rax*1], ax
00007d248dbe1cfe  nop [rax+rax*1], eax
00007d248dbe1d06  mov eax, 0x410474
00007d248dbe1d0b  mov [r15+0x100], rax
00007d248dbe1d12  jmp 0x00007D248D9FE110
00007d248dbe1d17  int3
00007d248dbe1d18  call 0x00007D248DAE27E0
00007d248dbe1d1d  jmp 0x00007D248DBE1AC3
00007d248dbe1d22  call 0x00007D248DAE27E0
00007d248dbe1d27  jmp 0x00007D248DBE1AD6
00007d248dbe1d2c  call 0x00007D248DAE1570
00007d248dbe1d31  jmp 0x00007D248DBE1AE2
00007d248dbe1d36  call 0x00007D248DAE27E0
00007d248dbe1d3b  jmp 0x00007D248DBE1B1A
00007d248dbe1d40  call 0x00007D248DAE1570
00007d248dbe1d45  jmp 0x00007D248DBE1B26
00007d248dbe1d4a  call 0x00007D248DAE27E0
00007d248dbe1d4f  jmp 0x00007D248DBE1B5E
00007d248dbe1d54  call 0x00007D248DAE1570
00007d248dbe1d59  jmp 0x00007D248DBE1B6A
00007d248dbe1d5e  call 0x00007D248DAE27E0
00007d248dbe1d63  jmp 0x00007D248DBE1BA2
00007d248dbe1d68  call 0x00007D248DAE1570
00007d248dbe1d6d  jmp 0x00007D248DBE1BAE
00007d248dbe1d72  call 0x00007D248DAE27E0
00007d248dbe1d77  jmp 0x00007D248DBE1BED
00007d248dbe1d7c  call 0x00007D248DA0E760
00007d248dbe1d81  jmp 0x00007D248DBE1C0A
00007d248dbe1d86  ucomisd xmm1, xmm15
00007d248dbe1d8b  jp 0x00007D248DBE1D9A
00007d248dbe1d8d  movaps xmm13, [0x00007D248D7FE060]
00007d248dbe1d95  jmp 0x00007D248DBE1C73
00007d248dbe1d9a  vxorps xmm0, xmm1, xmm15
00007d248dbe1d9f  pextrw eax, xmm0, 0x03
00007d248dbe1da4  and eax, 0x7FF8
00007d248dbe1da9  cmp eax, 0x08
00007d248dbe1dac  jnz 0x00007D248DBE1C73
00007d248dbe1db2  movq rax, xmm15
00007d248dbe1db7  shl rax, 0x0D
00007d248dbe1dbb  jbe 0x00007D248DBE1C73
00007d248dbe1dc1  vorps xmm13, xmm15, [0x00007D248D7FE070]
00007d248dbe1dc9  jmp 0x00007D248DBE1C73
00007d248dbe1dce  ucomisd xmm1, xmm15
00007d248dbe1dd3  jp 0x00007D248DBE1DE2
00007d248dbe1dd5  movaps xmm14, [0x00007D248D7FE060]
00007d248dbe1ddd  jmp 0x00007D248DBE1CA0
00007d248dbe1de2  vxorps xmm0, xmm1, xmm15
00007d248dbe1de7  pextrw eax, xmm0, 0x03
00007d248dbe1dec  and eax, 0x7FF8
00007d248dbe1df1  cmp eax, 0x08
00007d248dbe1df4  jnz 0x00007D248DBE1CA0
00007d248dbe1dfa  movq rax, xmm15
00007d248dbe1dff  shl rax, 0x0D
00007d248dbe1e03  jbe 0x00007D248DBE1CA0
00007d248dbe1e09  vorps xmm14, xmm15, [0x00007D248D7FE070]
00007d248dbe1e11  jmp 0x00007D248DBE1CA0
00007d248dbe1e16  int3
00007d248dbe1e17  nop [rax+rax*1], ax
00007d248dbe1e20  mov rax, [r15+0x48]
00007d248dbe1e24  mov r14, [r15+0x50]
00007d248dbe1e28  lea r12, [r14+rax*1]
00007d248dbe1e2c  movups xmm1, [r13+r12*1]
00007d248dbe1e32  movaps [r15+0x120], xmm1
00007d248dbe1e3a  lea r14, [rax+0x10]
00007d248dbe1e3e  mov [r15+0x48], r14
00007d248dbe1e42  xor eax, eax
00007d248dbe1e44  mov r12d, 0x200
00007d248dbe1e4a  cmp r14, r12
00007d248dbe1e4d  cmc
00007d248dbe1e4e  lahf
00007d248dbe1e4f  seto al
00007d248dbe1e52  mov [r15+0x108], eax
00007d248dbe1e59  pextrq rax, xmm1, 0x01
00007d248dbe1e60  movq xmm15, rax
00007d248dbe1e65  movaps [r15+0x130], xmm15
00007d248dbe1e6d  movaps xmm14, [r15+0x110]
00007d248dbe1e75  movq rax, xmm14
00007d248dbe1e7a  movq r14, xmm1
00007d248dbe1e7f  vmovq xmm1, rax
00007d248dbe1e84  vmovq xmm14, r14
00007d248dbe1e89  movaps xmm13, xmm1
00007d248dbe1e8d  addsd xmm13, xmm14
00007d248dbe1e92  ucomisd xmm13, xmm13
00007d248dbe1e97  jp 0x00007D248DBE1F4C
00007d248dbe1e9d  movq xmm13, xmm13
00007d248dbe1ea2  movq rax, xmm13
00007d248dbe1ea7  movq r14, xmm15
00007d248dbe1eac  vmovq xmm1, rax
00007d248dbe1eb1  vmovq xmm15, r14
00007d248dbe1eb6  movaps xmm14, xmm1
00007d248dbe1eba  addsd xmm14, xmm15
00007d248dbe1ebf  ucomisd xmm14, xmm14
00007d248dbe1ec4  jp 0x00007D248DBE1F94
00007d248dbe1eca  movq xmm14, xmm14
00007d248dbe1ecf  movaps [r15+0x110], xmm14
00007d248dbe1ed7  mov eax, [r15+0x108]
00007d248dbe1ede  sahf
00007d248dbe1edf  jnz 0x00007D248DBE1F11
00007d248dbe1ee1  cmp dword ptr [r15+0x318], 0x00
00007d248dbe1ee9  jz 0x00007D248DBE1FE0
00007d248dbe1eef  nop [rax+rax*1], ax
00007d248dbe1ef8  nop [rax+rax*1], eax
00007d248dbe1f00  mov eax, 0x410490
00007d248dbe1f05  mov [r15+0x100], rax
00007d248dbe1f0c  jmp 0x00007D248D9FE110
00007d248dbe1f11  cmp dword ptr [r15+0x318], 0x00
00007d248dbe1f19  jz 0x00007D248DBE1E20
00007d248dbe1f1f  nop [rax+rax*1], ax
00007d248dbe1f28  nop [rax+rax*1], eax
00007d248dbe1f30  mov eax, 0x410474
00007d248dbe1f35  mov [r15+0x100], rax
00007d248dbe1f3c  jmp 0x00007D248D9FE110
00007d248dbe1f41  int3
00007d248dbe1f42  call 0x00007D248DAB52F0
00007d248dbe1f47  jmp 0x00007D248DBE1E32
00007d248dbe1f4c  ucomisd xmm1, xmm14
00007d248dbe1f51  jp 0x00007D248DBE1F60
00007d248dbe1f53  movaps xmm13, [0x00007D248D7FE060]
00007d248dbe1f5b  jmp 0x00007D248DBE1E9D
00007d248dbe1f60  vxorps xmm0, xmm1, xmm14
00007d248dbe1f65  pextrw eax, xmm0, 0x03
00007d248dbe1f6a  and eax, 0x7FF8
00007d248dbe1f6f  cmp eax, 0x08
00007d248dbe1f72  jnz 0x00007D248DBE1E9D
00007d248dbe1f78  movq rax, xmm14
00007d248dbe1f7d  shl rax, 0x0D
00007d248dbe1f81  jbe 0x00007D248DBE1E9D
00007d248dbe1f87  vorps xmm13, xmm14, [0x00007D248D7FE070]
00007d248dbe1f8f  jmp 0x00007D248DBE1E9D
00007d248dbe1f94  ucomisd xmm1, xmm15
00007d248dbe1f99  jp 0x00007D248DBE1FA8
00007d248dbe1f9b  movaps xmm14, [0x00007D248D7FE060]
00007d248dbe1fa3  jmp 0x00007D248DBE1ECA
00007d248dbe1fa8  vxorps xmm0, xmm1, xmm15
00007d248dbe1fad  pextrw eax, xmm0, 0x03
00007d248dbe1fb2  and eax, 0x7FF8
00007d248dbe1fb7  cmp eax, 0x08
00007d248dbe1fba  jnz 0x00007D248DBE1ECA
00007d248dbe1fc0  movq rax, xmm15
00007d248dbe1fc5  shl rax, 0x0D
00007d248dbe1fc9  jbe 0x00007D248DBE1ECA
00007d248dbe1fcf  vorps xmm14, xmm15, [0x00007D248D7FE070]
00007d248dbe1fd7  jmp 0x00007D248DBE1ECA
00007d248dbe1fdc  int3
00007d248dbe1fdd  nop [rax], eax
00007d248dbe1fe0  mov rax, [r15+0x40]
00007d248dbe1fe4  lea r14, [rax+0x510]
00007d248dbe1feb  movaps xmm1, [r15+0x110]
00007d248dbe1ff3  movq rax, xmm1
00007d248dbe1ff8  mov [r13+r14*1], rax
00007d248dbe1ffd  mov rax, [r15+0xF0]
00007d248dbe2004  mov [r15+0x100], rax
00007d248dbe200b  jmp 0x00007D248DBCE5C0
00007d248dbe2010  int3
00007d248dbe2011  call 0x00007D248DAD5EB0
00007d248dbe2016  jmp 0x00007D248DBE1FFD
00007d248dbe201b  int3
00007d248dbe201c  nop [rax], eax
00007d248dbe2020  mov qword ptr [r15+0x100], 0x04
00007d248dbe202b  mov esi, 0x00
00007d248dbe2030  mov edx, 0x09
00007d248dbe2035  mov rdi, 0x7FFFA7AF8BF0
00007d248dbe203f  mov rax, 0x5BCEEF0C9970
00007d248dbe2049  call rax
00007d248dbe204b  cmp dword ptr [r15+0x318], 0x00
00007d248dbe2053  jnz 0x00007D248D9FE110
00007d248dbe2059  jmp 0x00007D248D9FE0A0
00007d248dbe205e  int3
00007d248dbe205f  int3
