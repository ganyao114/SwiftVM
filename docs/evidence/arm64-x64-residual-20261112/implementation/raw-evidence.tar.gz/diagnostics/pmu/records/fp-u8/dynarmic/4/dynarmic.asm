00007eb13fdce69b  nop [rax+rax*1], eax
00007eb13fdce6a0  mov qword ptr [r15+0x20], 0x420080
00007eb13fdce6a8  mov qword ptr [r15], 0x00
00007eb13fdce6af  vmovaps xmm1, [0x00007EB13F9FE010]
00007eb13fdce6b7  movq xmm1, xmm1
00007eb13fdce6bb  vmovaps xmm15, [0x00007EB13F9FE020]
00007eb13fdce6c3  movq xmm15, xmm15
00007eb13fdce6c8  movaps [r15+0x120], xmm15
00007eb13fdce6d0  movq rax, xmm1
00007eb13fdce6d5  movq r14, xmm15
00007eb13fdce6da  vmovq xmm1, rax
00007eb13fdce6df  vmovq xmm14, r14
00007eb13fdce6e4  movaps xmm13, xmm1
00007eb13fdce6e8  addsd xmm13, xmm14
00007eb13fdce6ed  ucomisd xmm13, xmm13
00007eb13fdce6f2  jp 0x00007EB13FDCE8CC
00007eb13fdce6f8  movq xmm13, xmm13
00007eb13fdce6fd  movq rax, xmm13
00007eb13fdce702  movq r14, xmm15
00007eb13fdce707  vmovq xmm1, rax
00007eb13fdce70c  vmovq xmm14, r14
00007eb13fdce711  movaps xmm13, xmm1
00007eb13fdce715  addsd xmm13, xmm14
00007eb13fdce71a  ucomisd xmm13, xmm13
00007eb13fdce71f  jp 0x00007EB13FDCE914
00007eb13fdce725  movq xmm13, xmm13
00007eb13fdce72a  movq rax, xmm13
00007eb13fdce72f  movq r14, xmm15
00007eb13fdce734  vmovq xmm1, rax
00007eb13fdce739  vmovq xmm14, r14
00007eb13fdce73e  movaps xmm13, xmm1
00007eb13fdce742  addsd xmm13, xmm14
00007eb13fdce747  ucomisd xmm13, xmm13
00007eb13fdce74c  jp 0x00007EB13FDCE95C
00007eb13fdce752  movq xmm13, xmm13
00007eb13fdce757  movq rax, xmm13
00007eb13fdce75c  movq r14, xmm15
00007eb13fdce761  vmovq xmm1, rax
00007eb13fdce766  vmovq xmm14, r14
00007eb13fdce76b  movaps xmm13, xmm1
00007eb13fdce76f  addsd xmm13, xmm14
00007eb13fdce774  ucomisd xmm13, xmm13
00007eb13fdce779  jp 0x00007EB13FDCE9A4
00007eb13fdce77f  movq xmm13, xmm13
00007eb13fdce784  movq rax, xmm13
00007eb13fdce789  movq r14, xmm15
00007eb13fdce78e  vmovq xmm1, rax
00007eb13fdce793  vmovq xmm14, r14
00007eb13fdce798  movaps xmm13, xmm1
00007eb13fdce79c  addsd xmm13, xmm14
00007eb13fdce7a1  ucomisd xmm13, xmm13
00007eb13fdce7a6  jp 0x00007EB13FDCE9EC
00007eb13fdce7ac  movq xmm13, xmm13
00007eb13fdce7b1  movq rax, xmm13
00007eb13fdce7b6  movq r14, xmm15
00007eb13fdce7bb  vmovq xmm1, rax
00007eb13fdce7c0  vmovq xmm14, r14
00007eb13fdce7c5  movaps xmm13, xmm1
00007eb13fdce7c9  addsd xmm13, xmm14
00007eb13fdce7ce  ucomisd xmm13, xmm13
00007eb13fdce7d3  jp 0x00007EB13FDCEA34
00007eb13fdce7d9  movq xmm13, xmm13
00007eb13fdce7de  movq rax, xmm13
00007eb13fdce7e3  movq r14, xmm15
00007eb13fdce7e8  vmovq xmm1, rax
00007eb13fdce7ed  vmovq xmm14, r14
00007eb13fdce7f2  movaps xmm13, xmm1
00007eb13fdce7f6  addsd xmm13, xmm14
00007eb13fdce7fb  ucomisd xmm13, xmm13
00007eb13fdce800  jp 0x00007EB13FDCEA7C
00007eb13fdce806  movq xmm13, xmm13
00007eb13fdce80b  movq rax, xmm13
00007eb13fdce810  movq r14, xmm15
00007eb13fdce815  vmovq xmm1, rax
00007eb13fdce81a  vmovq xmm15, r14
00007eb13fdce81f  movaps xmm14, xmm1
00007eb13fdce823  addsd xmm14, xmm15
00007eb13fdce828  ucomisd xmm14, xmm14
00007eb13fdce82d  jp 0x00007EB13FDCEAC4
00007eb13fdce833  movq xmm14, xmm14
00007eb13fdce838  movaps [r15+0x110], xmm14
00007eb13fdce840  xor eax, eax
00007eb13fdce842  mov r14d, 0x1E848
00007eb13fdce848  mov r12d, 0x01
00007eb13fdce84e  sub r14, r12
00007eb13fdce851  cmc
00007eb13fdce852  lahf
00007eb13fdce853  seto al
00007eb13fdce856  mov [r15+0x108], eax
00007eb13fdce85d  mov [r15+0x08], r14
00007eb13fdce861  mov eax, [r15+0x108]
00007eb13fdce868  sahf
00007eb13fdce869  jnz 0x00007EB13FDCE89B
00007eb13fdce86b  cmp dword ptr [r15+0x318], 0x00
00007eb13fdce873  jz 0x00007EB13FDCEF70
00007eb13fdce879  nop [rax+rax*1], ax
00007eb13fdce882  nop [rax+rax*1], eax
00007eb13fdce88a  mov eax, 0x41006C
00007eb13fdce88f  mov [r15+0x100], rax
00007eb13fdce896  jmp 0x00007EB13FBFE110
00007eb13fdce89b  cmp dword ptr [r15+0x318], 0x00
00007eb13fdce8a3  jz 0x00007EB13FDCEB10
00007eb13fdce8a9  nop [rax+rax*1], ax
00007eb13fdce8b2  nop [rax+rax*1], eax
00007eb13fdce8ba  mov eax, 0x410044
00007eb13fdce8bf  mov [r15+0x100], rax
00007eb13fdce8c6  jmp 0x00007EB13FBFE110
00007eb13fdce8cb  int3
00007eb13fdce8cc  ucomisd xmm1, xmm14
00007eb13fdce8d1  jp 0x00007EB13FDCE8E0
00007eb13fdce8d3  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdce8db  jmp 0x00007EB13FDCE6F8
00007eb13fdce8e0  vxorps xmm0, xmm1, xmm14
00007eb13fdce8e5  pextrw eax, xmm0, 0x03
00007eb13fdce8ea  and eax, 0x7FF8
00007eb13fdce8ef  cmp eax, 0x08
00007eb13fdce8f2  jnz 0x00007EB13FDCE6F8
00007eb13fdce8f8  movq rax, xmm14
00007eb13fdce8fd  shl rax, 0x0D
00007eb13fdce901  jbe 0x00007EB13FDCE6F8
00007eb13fdce907  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdce90f  jmp 0x00007EB13FDCE6F8
00007eb13fdce914  ucomisd xmm1, xmm14
00007eb13fdce919  jp 0x00007EB13FDCE928
00007eb13fdce91b  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdce923  jmp 0x00007EB13FDCE725
00007eb13fdce928  vxorps xmm0, xmm1, xmm14
00007eb13fdce92d  pextrw eax, xmm0, 0x03
00007eb13fdce932  and eax, 0x7FF8
00007eb13fdce937  cmp eax, 0x08
00007eb13fdce93a  jnz 0x00007EB13FDCE725
00007eb13fdce940  movq rax, xmm14
00007eb13fdce945  shl rax, 0x0D
00007eb13fdce949  jbe 0x00007EB13FDCE725
00007eb13fdce94f  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdce957  jmp 0x00007EB13FDCE725
00007eb13fdce95c  ucomisd xmm1, xmm14
00007eb13fdce961  jp 0x00007EB13FDCE970
00007eb13fdce963  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdce96b  jmp 0x00007EB13FDCE752
00007eb13fdce970  vxorps xmm0, xmm1, xmm14
00007eb13fdce975  pextrw eax, xmm0, 0x03
00007eb13fdce97a  and eax, 0x7FF8
00007eb13fdce97f  cmp eax, 0x08
00007eb13fdce982  jnz 0x00007EB13FDCE752
00007eb13fdce988  movq rax, xmm14
00007eb13fdce98d  shl rax, 0x0D
00007eb13fdce991  jbe 0x00007EB13FDCE752
00007eb13fdce997  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdce99f  jmp 0x00007EB13FDCE752
00007eb13fdce9a4  ucomisd xmm1, xmm14
00007eb13fdce9a9  jp 0x00007EB13FDCE9B8
00007eb13fdce9ab  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdce9b3  jmp 0x00007EB13FDCE77F
00007eb13fdce9b8  vxorps xmm0, xmm1, xmm14
00007eb13fdce9bd  pextrw eax, xmm0, 0x03
00007eb13fdce9c2  and eax, 0x7FF8
00007eb13fdce9c7  cmp eax, 0x08
00007eb13fdce9ca  jnz 0x00007EB13FDCE77F
00007eb13fdce9d0  movq rax, xmm14
00007eb13fdce9d5  shl rax, 0x0D
00007eb13fdce9d9  jbe 0x00007EB13FDCE77F
00007eb13fdce9df  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdce9e7  jmp 0x00007EB13FDCE77F
00007eb13fdce9ec  ucomisd xmm1, xmm14
00007eb13fdce9f1  jp 0x00007EB13FDCEA00
00007eb13fdce9f3  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdce9fb  jmp 0x00007EB13FDCE7AC
00007eb13fdcea00  vxorps xmm0, xmm1, xmm14
00007eb13fdcea05  pextrw eax, xmm0, 0x03
00007eb13fdcea0a  and eax, 0x7FF8
00007eb13fdcea0f  cmp eax, 0x08
00007eb13fdcea12  jnz 0x00007EB13FDCE7AC
00007eb13fdcea18  movq rax, xmm14
00007eb13fdcea1d  shl rax, 0x0D
00007eb13fdcea21  jbe 0x00007EB13FDCE7AC
00007eb13fdcea27  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdcea2f  jmp 0x00007EB13FDCE7AC
00007eb13fdcea34  ucomisd xmm1, xmm14
00007eb13fdcea39  jp 0x00007EB13FDCEA48
00007eb13fdcea3b  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdcea43  jmp 0x00007EB13FDCE7D9
00007eb13fdcea48  vxorps xmm0, xmm1, xmm14
00007eb13fdcea4d  pextrw eax, xmm0, 0x03
00007eb13fdcea52  and eax, 0x7FF8
00007eb13fdcea57  cmp eax, 0x08
00007eb13fdcea5a  jnz 0x00007EB13FDCE7D9
00007eb13fdcea60  movq rax, xmm14
00007eb13fdcea65  shl rax, 0x0D
00007eb13fdcea69  jbe 0x00007EB13FDCE7D9
00007eb13fdcea6f  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdcea77  jmp 0x00007EB13FDCE7D9
00007eb13fdcea7c  ucomisd xmm1, xmm14
00007eb13fdcea81  jp 0x00007EB13FDCEA90
00007eb13fdcea83  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdcea8b  jmp 0x00007EB13FDCE806
00007eb13fdcea90  vxorps xmm0, xmm1, xmm14
00007eb13fdcea95  pextrw eax, xmm0, 0x03
00007eb13fdcea9a  and eax, 0x7FF8
00007eb13fdcea9f  cmp eax, 0x08
00007eb13fdceaa2  jnz 0x00007EB13FDCE806
00007eb13fdceaa8  movq rax, xmm14
00007eb13fdceaad  shl rax, 0x0D
00007eb13fdceab1  jbe 0x00007EB13FDCE806
00007eb13fdceab7  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdceabf  jmp 0x00007EB13FDCE806
00007eb13fdceac4  ucomisd xmm1, xmm15
00007eb13fdceac9  jp 0x00007EB13FDCEAD8
00007eb13fdceacb  movaps xmm14, [0x00007EB13F9FE030]
00007eb13fdcead3  jmp 0x00007EB13FDCE833
00007eb13fdcead8  vxorps xmm0, xmm1, xmm15
00007eb13fdceadd  pextrw eax, xmm0, 0x03
00007eb13fdceae2  and eax, 0x7FF8
00007eb13fdceae7  cmp eax, 0x08
00007eb13fdceaea  jnz 0x00007EB13FDCE833
00007eb13fdceaf0  movq rax, xmm15
00007eb13fdceaf5  shl rax, 0x0D
00007eb13fdceaf9  jbe 0x00007EB13FDCE833
00007eb13fdceaff  vorps xmm14, xmm15, [0x00007EB13F9FE040]
00007eb13fdceb07  jmp 0x00007EB13FDCE833
00007eb13fdceb0c  int3
00007eb13fdceb0d  nop [rax], eax
00007eb13fdceb10  movaps xmm1, [r15+0x110]
00007eb13fdceb18  movq rax, xmm1
00007eb13fdceb1d  movaps xmm1, [r15+0x120]
00007eb13fdceb25  movq r14, xmm1
00007eb13fdceb2a  vmovq xmm15, rax
00007eb13fdceb2f  vmovq xmm14, r14
00007eb13fdceb34  movaps xmm13, xmm15
00007eb13fdceb38  addsd xmm13, xmm14
00007eb13fdceb3d  ucomisd xmm13, xmm13
00007eb13fdceb42  jp 0x00007EB13FDCED24
00007eb13fdceb48  movq xmm13, xmm13
00007eb13fdceb4d  movq rax, xmm13
00007eb13fdceb52  movq r14, xmm1
00007eb13fdceb57  vmovq xmm15, rax
00007eb13fdceb5c  vmovq xmm14, r14
00007eb13fdceb61  movaps xmm13, xmm15
00007eb13fdceb65  addsd xmm13, xmm14
00007eb13fdceb6a  ucomisd xmm13, xmm13
00007eb13fdceb6f  jp 0x00007EB13FDCED6C
00007eb13fdceb75  movq xmm13, xmm13
00007eb13fdceb7a  movq rax, xmm13
00007eb13fdceb7f  movq r14, xmm1
00007eb13fdceb84  vmovq xmm15, rax
00007eb13fdceb89  vmovq xmm14, r14
00007eb13fdceb8e  movaps xmm13, xmm15
00007eb13fdceb92  addsd xmm13, xmm14
00007eb13fdceb97  ucomisd xmm13, xmm13
00007eb13fdceb9c  jp 0x00007EB13FDCEDB4
00007eb13fdceba2  movq xmm13, xmm13
00007eb13fdceba7  movq rax, xmm13
00007eb13fdcebac  movq r14, xmm1
00007eb13fdcebb1  vmovq xmm15, rax
00007eb13fdcebb6  vmovq xmm14, r14
00007eb13fdcebbb  movaps xmm13, xmm15
00007eb13fdcebbf  addsd xmm13, xmm14
00007eb13fdcebc4  ucomisd xmm13, xmm13
00007eb13fdcebc9  jp 0x00007EB13FDCEDFC
00007eb13fdcebcf  movq xmm13, xmm13
00007eb13fdcebd4  movq rax, xmm13
00007eb13fdcebd9  movq r14, xmm1
00007eb13fdcebde  vmovq xmm15, rax
00007eb13fdcebe3  vmovq xmm14, r14
00007eb13fdcebe8  movaps xmm13, xmm15
00007eb13fdcebec  addsd xmm13, xmm14
00007eb13fdcebf1  ucomisd xmm13, xmm13
00007eb13fdcebf6  jp 0x00007EB13FDCEE44
00007eb13fdcebfc  movq xmm13, xmm13
00007eb13fdcec01  movq rax, xmm13
00007eb13fdcec06  movq r14, xmm1
00007eb13fdcec0b  vmovq xmm15, rax
00007eb13fdcec10  vmovq xmm14, r14
00007eb13fdcec15  movaps xmm13, xmm15
00007eb13fdcec19  addsd xmm13, xmm14
00007eb13fdcec1e  ucomisd xmm13, xmm13
00007eb13fdcec23  jp 0x00007EB13FDCEE8C
00007eb13fdcec29  movq xmm13, xmm13
00007eb13fdcec2e  movq rax, xmm13
00007eb13fdcec33  movq r14, xmm1
00007eb13fdcec38  vmovq xmm15, rax
00007eb13fdcec3d  vmovq xmm14, r14
00007eb13fdcec42  movaps xmm13, xmm15
00007eb13fdcec46  addsd xmm13, xmm14
00007eb13fdcec4b  ucomisd xmm13, xmm13
00007eb13fdcec50  jp 0x00007EB13FDCEED4
00007eb13fdcec56  movq xmm13, xmm13
00007eb13fdcec5b  movq rax, xmm13
00007eb13fdcec60  movq r14, xmm1
00007eb13fdcec65  vmovq xmm1, rax
00007eb13fdcec6a  vmovq xmm15, r14
00007eb13fdcec6f  movaps xmm14, xmm1
00007eb13fdcec73  addsd xmm14, xmm15
00007eb13fdcec78  ucomisd xmm14, xmm14
00007eb13fdcec7d  jp 0x00007EB13FDCEF1C
00007eb13fdcec83  movq xmm14, xmm14
00007eb13fdcec88  movaps [r15+0x110], xmm14
00007eb13fdcec90  mov rax, [r15+0x08]
00007eb13fdcec94  mov [rsp+0x10], rax
00007eb13fdcec99  xor eax, eax
00007eb13fdcec9b  mov r14, [rsp+0x10]
00007eb13fdceca0  mov r12d, 0x01
00007eb13fdceca6  sub r14, r12
00007eb13fdceca9  cmc
00007eb13fdcecaa  lahf
00007eb13fdcecab  seto al
00007eb13fdcecae  mov [r15+0x108], eax
00007eb13fdcecb5  mov [r15+0x08], r14
00007eb13fdcecb9  mov eax, [r15+0x108]
00007eb13fdcecc0  sahf
00007eb13fdcecc1  jnz 0x00007EB13FDCECF3
00007eb13fdcecc3  cmp dword ptr [r15+0x318], 0x00
00007eb13fdceccb  jz 0x00007EB13FDCEF70
00007eb13fdcecd1  nop [rax+rax*1], ax
00007eb13fdcecda  nop [rax+rax*1], eax
00007eb13fdcece2  mov eax, 0x41006C
00007eb13fdcece7  mov [r15+0x100], rax
00007eb13fdcecee  jmp 0x00007EB13FBFE110
00007eb13fdcecf3  cmp dword ptr [r15+0x318], 0x00
00007eb13fdcecfb  jz 0x00007EB13FDCEB10
00007eb13fdced01  nop [rax+rax*1], ax
00007eb13fdced0a  nop [rax+rax*1], eax
00007eb13fdced12  mov eax, 0x410044
00007eb13fdced17  mov [r15+0x100], rax
00007eb13fdced1e  jmp 0x00007EB13FBFE110
00007eb13fdced23  int3
00007eb13fdced24  ucomisd xmm15, xmm14
00007eb13fdced29  jp 0x00007EB13FDCED38
00007eb13fdced2b  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdced33  jmp 0x00007EB13FDCEB48
00007eb13fdced38  vxorps xmm0, xmm15, xmm14
00007eb13fdced3d  pextrw eax, xmm0, 0x03
00007eb13fdced42  and eax, 0x7FF8
00007eb13fdced47  cmp eax, 0x08
00007eb13fdced4a  jnz 0x00007EB13FDCEB48
00007eb13fdced50  movq rax, xmm14
00007eb13fdced55  shl rax, 0x0D
00007eb13fdced59  jbe 0x00007EB13FDCEB48
00007eb13fdced5f  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdced67  jmp 0x00007EB13FDCEB48
00007eb13fdced6c  ucomisd xmm15, xmm14
00007eb13fdced71  jp 0x00007EB13FDCED80
00007eb13fdced73  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdced7b  jmp 0x00007EB13FDCEB75
00007eb13fdced80  vxorps xmm0, xmm15, xmm14
00007eb13fdced85  pextrw eax, xmm0, 0x03
00007eb13fdced8a  and eax, 0x7FF8
00007eb13fdced8f  cmp eax, 0x08
00007eb13fdced92  jnz 0x00007EB13FDCEB75
00007eb13fdced98  movq rax, xmm14
00007eb13fdced9d  shl rax, 0x0D
00007eb13fdceda1  jbe 0x00007EB13FDCEB75
00007eb13fdceda7  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdcedaf  jmp 0x00007EB13FDCEB75
00007eb13fdcedb4  ucomisd xmm15, xmm14
00007eb13fdcedb9  jp 0x00007EB13FDCEDC8
00007eb13fdcedbb  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdcedc3  jmp 0x00007EB13FDCEBA2
00007eb13fdcedc8  vxorps xmm0, xmm15, xmm14
00007eb13fdcedcd  pextrw eax, xmm0, 0x03
00007eb13fdcedd2  and eax, 0x7FF8
00007eb13fdcedd7  cmp eax, 0x08
00007eb13fdcedda  jnz 0x00007EB13FDCEBA2
00007eb13fdcede0  movq rax, xmm14
00007eb13fdcede5  shl rax, 0x0D
00007eb13fdcede9  jbe 0x00007EB13FDCEBA2
00007eb13fdcedef  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdcedf7  jmp 0x00007EB13FDCEBA2
00007eb13fdcedfc  ucomisd xmm15, xmm14
00007eb13fdcee01  jp 0x00007EB13FDCEE10
00007eb13fdcee03  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdcee0b  jmp 0x00007EB13FDCEBCF
00007eb13fdcee10  vxorps xmm0, xmm15, xmm14
00007eb13fdcee15  pextrw eax, xmm0, 0x03
00007eb13fdcee1a  and eax, 0x7FF8
00007eb13fdcee1f  cmp eax, 0x08
00007eb13fdcee22  jnz 0x00007EB13FDCEBCF
00007eb13fdcee28  movq rax, xmm14
00007eb13fdcee2d  shl rax, 0x0D
00007eb13fdcee31  jbe 0x00007EB13FDCEBCF
00007eb13fdcee37  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdcee3f  jmp 0x00007EB13FDCEBCF
00007eb13fdcee44  ucomisd xmm15, xmm14
00007eb13fdcee49  jp 0x00007EB13FDCEE58
00007eb13fdcee4b  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdcee53  jmp 0x00007EB13FDCEBFC
00007eb13fdcee58  vxorps xmm0, xmm15, xmm14
00007eb13fdcee5d  pextrw eax, xmm0, 0x03
00007eb13fdcee62  and eax, 0x7FF8
00007eb13fdcee67  cmp eax, 0x08
00007eb13fdcee6a  jnz 0x00007EB13FDCEBFC
00007eb13fdcee70  movq rax, xmm14
00007eb13fdcee75  shl rax, 0x0D
00007eb13fdcee79  jbe 0x00007EB13FDCEBFC
00007eb13fdcee7f  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdcee87  jmp 0x00007EB13FDCEBFC
00007eb13fdcee8c  ucomisd xmm15, xmm14
00007eb13fdcee91  jp 0x00007EB13FDCEEA0
00007eb13fdcee93  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdcee9b  jmp 0x00007EB13FDCEC29
00007eb13fdceea0  vxorps xmm0, xmm15, xmm14
00007eb13fdceea5  pextrw eax, xmm0, 0x03
00007eb13fdceeaa  and eax, 0x7FF8
00007eb13fdceeaf  cmp eax, 0x08
00007eb13fdceeb2  jnz 0x00007EB13FDCEC29
00007eb13fdceeb8  movq rax, xmm14
00007eb13fdceebd  shl rax, 0x0D
00007eb13fdceec1  jbe 0x00007EB13FDCEC29
00007eb13fdceec7  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdceecf  jmp 0x00007EB13FDCEC29
00007eb13fdceed4  ucomisd xmm15, xmm14
00007eb13fdceed9  jp 0x00007EB13FDCEEE8
00007eb13fdceedb  movaps xmm13, [0x00007EB13F9FE030]
00007eb13fdceee3  jmp 0x00007EB13FDCEC56
00007eb13fdceee8  vxorps xmm0, xmm15, xmm14
00007eb13fdceeed  pextrw eax, xmm0, 0x03
00007eb13fdceef2  and eax, 0x7FF8
00007eb13fdceef7  cmp eax, 0x08
00007eb13fdceefa  jnz 0x00007EB13FDCEC56
00007eb13fdcef00  movq rax, xmm14
00007eb13fdcef05  shl rax, 0x0D
00007eb13fdcef09  jbe 0x00007EB13FDCEC56
00007eb13fdcef0f  vorps xmm13, xmm14, [0x00007EB13F9FE040]
00007eb13fdcef17  jmp 0x00007EB13FDCEC56
00007eb13fdcef1c  ucomisd xmm1, xmm15
00007eb13fdcef21  jp 0x00007EB13FDCEF30
00007eb13fdcef23  movaps xmm14, [0x00007EB13F9FE030]
00007eb13fdcef2b  jmp 0x00007EB13FDCEC83
00007eb13fdcef30  vxorps xmm0, xmm1, xmm15
00007eb13fdcef35  pextrw eax, xmm0, 0x03
00007eb13fdcef3a  and eax, 0x7FF8
00007eb13fdcef3f  cmp eax, 0x08
00007eb13fdcef42  jnz 0x00007EB13FDCEC83
00007eb13fdcef48  movq rax, xmm15
00007eb13fdcef4d  shl rax, 0x0D
00007eb13fdcef51  jbe 0x00007EB13FDCEC83
00007eb13fdcef57  vorps xmm14, xmm15, [0x00007EB13F9FE040]
00007eb13fdcef5f  jmp 0x00007EB13FDCEC83
00007eb13fdcef64  int3
00007eb13fdcef65  nop [rax+rax*1], ax
00007eb13fdcef6e  nop
00007eb13fdcef70  mov rax, [r15+0x20]
00007eb13fdcef74  movaps xmm1, [r15+0x110]
00007eb13fdcef7c  movq r14, xmm1
00007eb13fdcef81  mov [r13+rax*1], r14
00007eb13fdcef86  mov rax, [r15+0xF0]
00007eb13fdcef8d  mov [r15+0x100], rax
00007eb13fdcef94  jmp 0x00007EB13FDCE5C0
00007eb13fdcef99  int3
00007eb13fdcef9a  call 0x00007EB13FC0E120
00007eb13fdcef9f  jmp 0x00007EB13FDCEF86
00007eb13fdcefa4  int3
00007eb13fdcefa5  nop [rax+rax*1], ax
00007eb13fdcefae  nop
00007eb13fdcefb0  mov qword ptr [r15+0x100], 0x04
00007eb13fdcefbb  mov esi, 0x00
00007eb13fdcefc0  mov edx, 0x09
00007eb13fdcefc5  mov rdi, 0x7FFD0BE86970
00007eb13fdcefcf  mov rax, 0x60C16742C970
00007eb13fdcefd9  call rax
00007eb13fdcefdb  cmp dword ptr [r15+0x318], 0x00
00007eb13fdcefe3  jnz 0x00007EB13FBFE110
00007eb13fdcefe9  jmp 0x00007EB13FBFE0A0
00007eb13fdcefee  int3
00007eb13fdcefef  int3
