000079cbf15ce69b  nop [rax+rax*1], eax
000079cbf15ce6a0  mov rax, [r15+0xF8]
000079cbf15ce6a7  lea r14, [rax-0xA0]
000079cbf15ce6ae  mov [r15+0xF8], r14
000079cbf15ce6b5  lea rax, [r14+0x90]
000079cbf15ce6bc  mov r12, [r15+0xA0]
000079cbf15ce6c3  mov r11, [r15+0x98]
000079cbf15ce6ca  mov [r13+rax*1], r12
000079cbf15ce6cf  lea rax, [r14+0x98]
000079cbf15ce6d6  mov [r13+rax*1], r11
000079cbf15ce6db  mov eax, 0x420670
000079cbf15ce6e0  movups xmm1, [r13+rax*1]
000079cbf15ce6e6  mov eax, 0x420610
000079cbf15ce6eb  movups xmm15, [r13+rax*1]
000079cbf15ce6f1  mov eax, 0x420690
000079cbf15ce6f6  movups xmm14, [r13+rax*1]
000079cbf15ce6fc  mov eax, 0x420630
000079cbf15ce701  movups xmm13, [r13+rax*1]
000079cbf15ce707  mov qword ptr [r15+0x98], 0x4308A0
000079cbf15ce712  mov eax, 0x4206A0
000079cbf15ce717  movups xmm12, [r13+rax*1]
000079cbf15ce71d  mov eax, 0x4308A0
000079cbf15ce722  movups [r13+rax*1], xmm1
000079cbf15ce728  mov eax, 0x4308B0
000079cbf15ce72d  movups [r13+rax*1], xmm15
000079cbf15ce733  mov eax, 0x4308C0
000079cbf15ce738  movups [r13+rax*1], xmm14
000079cbf15ce73e  mov eax, 0x4308D0
000079cbf15ce743  movups [r13+rax*1], xmm13
000079cbf15ce749  mov eax, 0x420600
000079cbf15ce74e  movups xmm14, [r13+rax*1]
000079cbf15ce754  mov eax, 0x4205F0
000079cbf15ce759  movups xmm13, [r13+rax*1]
000079cbf15ce75f  mov eax, 0x4309A0
000079cbf15ce764  movups [r13+rax*1], xmm1
000079cbf15ce76a  mov eax, 0x4309B0
000079cbf15ce76f  movups [r13+rax*1], xmm15
000079cbf15ce775  mov eax, 0x4308E0
000079cbf15ce77a  movups [r13+rax*1], xmm12
000079cbf15ce780  mov eax, 0x4308F0
000079cbf15ce785  movups [r13+rax*1], xmm14
000079cbf15ce78b  mov eax, 0x4205E0
000079cbf15ce790  movups xmm1, [r13+rax*1]
000079cbf15ce796  mov eax, 0x420640
000079cbf15ce79b  movups xmm15, [r13+rax*1]
000079cbf15ce7a1  mov eax, 0x430900
000079cbf15ce7a6  movups [r13+rax*1], xmm13
000079cbf15ce7ac  mov eax, 0x430910
000079cbf15ce7b1  movups [r13+rax*1], xmm1
000079cbf15ce7b7  mov eax, 0x420650
000079cbf15ce7bc  movups xmm1, [r13+rax*1]
000079cbf15ce7c2  mov eax, 0x420620
000079cbf15ce7c7  movups xmm14, [r13+rax*1]
000079cbf15ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000079cbf15ce7d5  mov eax, 0x430920
000079cbf15ce7da  movups [r13+rax*1], xmm15
000079cbf15ce7e0  mov eax, 0x430930
000079cbf15ce7e5  movups [r13+rax*1], xmm1
000079cbf15ce7eb  mov eax, 0x4206C0
000079cbf15ce7f0  movups xmm1, [r13+rax*1]
000079cbf15ce7f6  mov eax, 0x4206D0
000079cbf15ce7fb  movups xmm15, [r13+rax*1]
000079cbf15ce801  movaps [r15+0x150], xmm15
000079cbf15ce809  mov qword ptr [r15+0xA0], 0x3E8
000079cbf15ce814  mov eax, 0x430940
000079cbf15ce819  movups [r13+rax*1], xmm14
000079cbf15ce81f  mov eax, 0x430950
000079cbf15ce824  movups [r13+rax*1], xmm1
000079cbf15ce82a  mov eax, 0x4206B0
000079cbf15ce82f  movups xmm1, [r13+rax*1]
000079cbf15ce835  mov eax, 0x420660
000079cbf15ce83a  movups xmm14, [r13+rax*1]
000079cbf15ce840  movaps [r15+0x140], xmm14
000079cbf15ce848  lea rax, [r14+0x80]
000079cbf15ce84f  mov r12, [r15+0xF0]
000079cbf15ce856  mov [r13+rax*1], r12
000079cbf15ce85b  mov eax, 0x430960
000079cbf15ce860  movups [r13+rax*1], xmm15
000079cbf15ce866  mov eax, 0x430970
000079cbf15ce86b  movups [r13+rax*1], xmm1
000079cbf15ce871  mov eax, 0x420680
000079cbf15ce876  movups xmm1, [r13+rax*1]
000079cbf15ce87c  mov eax, 0x4206E0
000079cbf15ce881  mov r12, [r13+rax*1]
000079cbf15ce886  movq xmm15, r12
000079cbf15ce88b  mov qword ptr [r15+0x40], 0x4206E8
000079cbf15ce893  mov eax, 0x430980
000079cbf15ce898  movups [r13+rax*1], xmm14
000079cbf15ce89e  mov eax, 0x430990
000079cbf15ce8a3  movups [r13+rax*1], xmm1
000079cbf15ce8a9  mov eax, 0x420748
000079cbf15ce8ae  movups xmm1, [r13+rax*1]
000079cbf15ce8b4  movq rax, xmm15
000079cbf15ce8b9  mov r12d, 0x4309C0
000079cbf15ce8bf  mov [r13+r12*1], rax
000079cbf15ce8c4  mov eax, 0x420728
000079cbf15ce8c9  movups xmm15, [r13+rax*1]
000079cbf15ce8cf  mov eax, 0x420738
000079cbf15ce8d4  movups xmm14, [r13+rax*1]
000079cbf15ce8da  lea rax, [r14+0x60]
000079cbf15ce8de  movups [r13+rax*1], xmm1
000079cbf15ce8e4  mov eax, 0x4309C8
000079cbf15ce8e9  mov r12d, 0x421DF8D3
000079cbf15ce8ef  mov [r13+rax*1], r12d
000079cbf15ce8f4  lea rax, [r14+0x40]
000079cbf15ce8f8  movups [r13+rax*1], xmm15
000079cbf15ce8fe  lea rax, [r14+0x50]
000079cbf15ce902  movups [r13+rax*1], xmm14
000079cbf15ce908  mov eax, 0x4206E8
000079cbf15ce90d  movups xmm1, [r13+rax*1]
000079cbf15ce913  mov eax, 0x4206F8
000079cbf15ce918  movups xmm15, [r13+rax*1]
000079cbf15ce91e  movaps [r15+0x120], xmm15
000079cbf15ce926  movups [r13+r14*1], xmm1
000079cbf15ce92c  lea rax, [r14+0x10]
000079cbf15ce930  movups [r13+rax*1], xmm15
000079cbf15ce936  mov eax, 0x420708
000079cbf15ce93b  movups xmm1, [r13+rax*1]
000079cbf15ce941  mov eax, 0x420718
000079cbf15ce946  movups xmm15, [r13+rax*1]
000079cbf15ce94c  movaps [r15+0x110], xmm1
000079cbf15ce954  movaps [r15+0x130], xmm15
000079cbf15ce95c  lea rax, [r14+0x20]
000079cbf15ce960  movups [r13+rax*1], xmm1
000079cbf15ce966  lea rax, [r14+0x30]
000079cbf15ce96a  movups [r13+rax*1], xmm15
000079cbf15ce970  mov [r15], r14
000079cbf15ce973  mov qword ptr [r15+0x08], 0x4308A0
000079cbf15ce97b  mov qword ptr [r15+0x10], 0x12C
000079cbf15ce983  mov qword ptr [r15+0xF0], 0x410274
000079cbf15ce98e  mov r14d, [r15+0x320]
000079cbf15ce995  mov eax, 0x410274
000079cbf15ce99a  mov rcx, 0x79CBF15D0670
000079cbf15ce9a4  mov [r15+r14*8+0x328], rax
000079cbf15ce9ac  mov [r15+r14*8+0x368], rcx
000079cbf15ce9b4  add r14d, 0x01
000079cbf15ce9b8  and r14d, 0x07
000079cbf15ce9bc  mov [r15+0x320], r14d
000079cbf15ce9c3  cmp dword ptr [r15+0x318], 0x00
000079cbf15ce9cb  jz 0x000079CBF15CEC20
000079cbf15ce9d1  nop [rax+rax*1], ax
000079cbf15ce9da  nop [rax+rax*1], eax
000079cbf15ce9e2  mov eax, 0x410338
000079cbf15ce9e7  mov [r15+0x100], rax
000079cbf15ce9ee  jmp 0x000079CBF13FE110
000079cbf15ce9f3  int3
000079cbf15ce9f4  call 0x000079CBF140BC20
000079cbf15ce9f9  jmp 0x000079CBF15CE6CF
000079cbf15ce9fe  call 0x000079CBF140A9A0
000079cbf15cea03  jmp 0x000079CBF15CE6DB
000079cbf15cea08  call 0x000079CBF13FF430
000079cbf15cea0d  jmp 0x000079CBF15CE6E6
000079cbf15cea12  call 0x000079CBF140E760
000079cbf15cea17  jmp 0x000079CBF15CE6F1
000079cbf15cea1c  call 0x000079CBF140D4E0
000079cbf15cea21  jmp 0x000079CBF15CE6FC
000079cbf15cea26  call 0x000079CBF140C260
000079cbf15cea2b  jmp 0x000079CBF15CE707
000079cbf15cea30  call 0x000079CBF140AFE0
000079cbf15cea35  jmp 0x000079CBF15CE71D
000079cbf15cea3a  call 0x000079CBF13FF540
000079cbf15cea3f  jmp 0x000079CBF15CE728
000079cbf15cea44  call 0x000079CBF140E880
000079cbf15cea49  jmp 0x000079CBF15CE733
000079cbf15cea4e  call 0x000079CBF140D600
000079cbf15cea53  jmp 0x000079CBF15CE73E
000079cbf15cea58  call 0x000079CBF140C380
000079cbf15cea5d  jmp 0x000079CBF15CE749
000079cbf15cea62  call 0x000079CBF140D4E0
000079cbf15cea67  jmp 0x000079CBF15CE754
000079cbf15cea6c  call 0x000079CBF140C260
000079cbf15cea71  jmp 0x000079CBF15CE75F
000079cbf15cea76  call 0x000079CBF13FF540
000079cbf15cea7b  jmp 0x000079CBF15CE76A
000079cbf15cea80  call 0x000079CBF140E880
000079cbf15cea85  jmp 0x000079CBF15CE775
000079cbf15cea8a  call 0x000079CBF140B100
000079cbf15cea8f  jmp 0x000079CBF15CE780
000079cbf15cea94  call 0x000079CBF140D600
000079cbf15cea99  jmp 0x000079CBF15CE78B
000079cbf15cea9e  call 0x000079CBF13FF430
000079cbf15ceaa3  jmp 0x000079CBF15CE796
000079cbf15ceaa8  call 0x000079CBF140E760
000079cbf15ceaad  jmp 0x000079CBF15CE7A1
000079cbf15ceab2  call 0x000079CBF140C380
000079cbf15ceab7  jmp 0x000079CBF15CE7AC
000079cbf15ceabc  call 0x000079CBF13FF540
000079cbf15ceac1  jmp 0x000079CBF15CE7B7
000079cbf15ceac6  call 0x000079CBF13FF430
000079cbf15ceacb  jmp 0x000079CBF15CE7C2
000079cbf15cead0  call 0x000079CBF140D4E0
000079cbf15cead5  jmp 0x000079CBF15CE7CD
000079cbf15ceada  call 0x000079CBF140E880
000079cbf15ceadf  jmp 0x000079CBF15CE7E0
000079cbf15ceae4  call 0x000079CBF13FF540
000079cbf15ceae9  jmp 0x000079CBF15CE7EB
000079cbf15ceaee  call 0x000079CBF13FF430
000079cbf15ceaf3  jmp 0x000079CBF15CE7F6
000079cbf15ceaf8  call 0x000079CBF140E760
000079cbf15ceafd  jmp 0x000079CBF15CE801
000079cbf15ceb02  call 0x000079CBF140D600
000079cbf15ceb07  jmp 0x000079CBF15CE81F
000079cbf15ceb0c  call 0x000079CBF13FF540
000079cbf15ceb11  jmp 0x000079CBF15CE82A
000079cbf15ceb16  call 0x000079CBF13FF430
000079cbf15ceb1b  jmp 0x000079CBF15CE835
000079cbf15ceb20  call 0x000079CBF140D4E0
000079cbf15ceb25  jmp 0x000079CBF15CE840
000079cbf15ceb2a  call 0x000079CBF140BC20
000079cbf15ceb2f  jmp 0x000079CBF15CE85B
000079cbf15ceb34  call 0x000079CBF140E880
000079cbf15ceb39  jmp 0x000079CBF15CE866
000079cbf15ceb3e  call 0x000079CBF13FF540
000079cbf15ceb43  jmp 0x000079CBF15CE871
000079cbf15ceb48  call 0x000079CBF13FF430
000079cbf15ceb4d  jmp 0x000079CBF15CE87C
000079cbf15ceb52  call 0x000079CBF140B720
000079cbf15ceb57  jmp 0x000079CBF15CE886
000079cbf15ceb5c  call 0x000079CBF140D600
000079cbf15ceb61  jmp 0x000079CBF15CE89E
000079cbf15ceb66  call 0x000079CBF13FF540
000079cbf15ceb6b  jmp 0x000079CBF15CE8A9
000079cbf15ceb70  call 0x000079CBF13FF430
000079cbf15ceb75  jmp 0x000079CBF15CE8B4
000079cbf15ceb7a  call 0x000079CBF14B4CB0
000079cbf15ceb7f  jmp 0x000079CBF15CE8C4
000079cbf15ceb84  call 0x000079CBF140E760
000079cbf15ceb89  jmp 0x000079CBF15CE8CF
000079cbf15ceb8e  call 0x000079CBF140D4E0
000079cbf15ceb93  jmp 0x000079CBF15CE8DA
000079cbf15ceb98  call 0x000079CBF13FF540
000079cbf15ceb9d  jmp 0x000079CBF15CE8E4
000079cbf15ceba2  call 0x000079CBF140BAE0
000079cbf15ceba7  jmp 0x000079CBF15CE8F4
000079cbf15cebac  call 0x000079CBF140E880
000079cbf15cebb1  jmp 0x000079CBF15CE8FE
000079cbf15cebb6  call 0x000079CBF140D600
000079cbf15cebbb  jmp 0x000079CBF15CE908
000079cbf15cebc0  call 0x000079CBF13FF430
000079cbf15cebc5  jmp 0x000079CBF15CE913
000079cbf15cebca  call 0x000079CBF140E760
000079cbf15cebcf  jmp 0x000079CBF15CE91E
000079cbf15cebd4  call 0x000079CBF14D6600
000079cbf15cebd9  jmp 0x000079CBF15CE92C
000079cbf15cebde  call 0x000079CBF140E880
000079cbf15cebe3  jmp 0x000079CBF15CE936
000079cbf15cebe8  call 0x000079CBF13FF430
000079cbf15cebed  jmp 0x000079CBF15CE941
000079cbf15cebf2  call 0x000079CBF140E760
000079cbf15cebf7  jmp 0x000079CBF15CE94C
000079cbf15cebfc  call 0x000079CBF13FF540
000079cbf15cec01  jmp 0x000079CBF15CE966
000079cbf15cec06  call 0x000079CBF140E880
000079cbf15cec0b  jmp 0x000079CBF15CE970
000079cbf15cec10  int3
000079cbf15cec11  nop [rax+rax*1], ax
000079cbf15cec1a  nop [rax+rax*1], ax
000079cbf15cec20  mov rax, [r15]
000079cbf15cec23  lea r14, [rax+0x20]
000079cbf15cec27  mov r12, [r13+r14*1]
000079cbf15cec2c  mov r14, [r15+0x10]
000079cbf15cec30  lea r11, [r12+r14*1]
000079cbf15cec34  mov [r15+0x40], r11
000079cbf15cec38  lea r12, [rax+0x20]
000079cbf15cec3c  mov [r13+r12*1], r11
000079cbf15cec41  test r14, r14
000079cbf15cec44  setz r14b
000079cbf15cec48  movzx r14, r14b
000079cbf15cec4c  mov [rsp+0x414], r14b
000079cbf15cec54  cmp byte ptr [rsp+0x414], 0x00
000079cbf15cec5c  jz 0x000079CBF15CEC8E
000079cbf15cec5e  cmp dword ptr [r15+0x318], 0x00
000079cbf15cec66  mov eax, 0x4105B0
000079cbf15cec6b  mov [r15+0x100], rax
000079cbf15cec72  jz 0x000079CBF13FE0A0
000079cbf15cec78  nop [rax+rax*1], eax
000079cbf15cec7d  mov eax, 0x4105B0
000079cbf15cec82  mov [r15+0x100], rax
000079cbf15cec89  jmp 0x000079CBF13FE110
000079cbf15cec8e  cmp dword ptr [r15+0x318], 0x00
000079cbf15cec96  jz 0x000079CBF15CECE0
000079cbf15cec9c  nop [rax+rax*1], ax
000079cbf15ceca5  nop [rax+rax*1], eax
000079cbf15cecad  mov eax, 0x410348
000079cbf15cecb2  mov [r15+0x100], rax
000079cbf15cecb9  jmp 0x000079CBF13FE110
000079cbf15cecbe  int3
000079cbf15cecbf  call 0x000079CBF14E27E0
000079cbf15cecc4  jmp 0x000079CBF15CEC2C
000079cbf15cecc9  call 0x000079CBF14C0860
000079cbf15cecce  jmp 0x000079CBF15CEC41
000079cbf15cecd3  int3
000079cbf15cecd4  nop [rax+rax*1], ax
000079cbf15cecdd  nop [rax], eax
000079cbf15cece0  mov rax, [r15+0xF8]
000079cbf15cece7  lea r14, [rax-0x150]
000079cbf15cecee  mov [r15+0xF8], r14
000079cbf15cecf5  mov rax, [r15]
000079cbf15cecf8  lea r12, [rax+0x68]
000079cbf15cecfc  mov r11, [r13+r12*1]
000079cbf15ced01  mov [r15+0x88], r11
000079cbf15ced08  lea r12, [rax+0x28]
000079cbf15ced0c  mov [r15+0x40], r12
000079cbf15ced10  mov [r15+0x48], r14
000079cbf15ced14  mov qword ptr [r15+0x50], 0x420758
000079cbf15ced1c  lea rax, [r14+0x100]
000079cbf15ced23  mov r12, [r15+0xE8]
000079cbf15ced2a  mov r11, [r15+0xD8]
000079cbf15ced31  mov [r13+rax*1], r12
000079cbf15ced36  lea rax, [r14+0x108]
000079cbf15ced3d  mov [r13+rax*1], r11
000079cbf15ced42  lea rax, [r14+0x110]
000079cbf15ced49  mov r12, [r15+0xD0]
000079cbf15ced50  mov r11, [r15+0xC8]
000079cbf15ced57  mov [r13+rax*1], r12
000079cbf15ced5c  lea rax, [r14+0x118]
000079cbf15ced63  mov [r13+rax*1], r11
000079cbf15ced68  lea rax, [r14+0x120]
000079cbf15ced6f  mov r12, [r15+0xC0]
000079cbf15ced76  mov r11, [r15+0xB8]
000079cbf15ced7d  mov [r13+rax*1], r12
000079cbf15ced82  lea rax, [r14+0x128]
000079cbf15ced89  mov [r13+rax*1], r11
000079cbf15ced8e  lea rax, [r14+0x130]
000079cbf15ced95  mov r12, [r15+0xB0]
000079cbf15ced9c  mov r11, [r15+0xA8]
000079cbf15ceda3  mov [r13+rax*1], r12
000079cbf15ceda8  lea rax, [r14+0x138]
000079cbf15cedaf  mov [r13+rax*1], r11
000079cbf15cedb4  lea rax, [r14+0x140]
000079cbf15cedbb  mov r12, [r15+0xA0]
000079cbf15cedc2  mov r11, [r15+0x98]
000079cbf15cedc9  mov [r13+rax*1], r12
000079cbf15cedce  lea rax, [r14+0x148]
000079cbf15cedd5  mov [r13+rax*1], r11
000079cbf15cedda  cmp dword ptr [r15+0x318], 0x00
000079cbf15cede2  jz 0x000079CBF15CEE80
000079cbf15cede8  nop [rax+rax*1], ax
000079cbf15cedf1  nop [rax+rax*1], eax
000079cbf15cedf9  mov eax, 0x410380
000079cbf15cedfe  mov [r15+0x100], rax
000079cbf15cee05  jmp 0x000079CBF13FE110
000079cbf15cee0a  int3
000079cbf15cee0b  call 0x000079CBF14C0370
000079cbf15cee10  jmp 0x000079CBF15CED01
000079cbf15cee15  call 0x000079CBF140BC20
000079cbf15cee1a  jmp 0x000079CBF15CED36
000079cbf15cee1f  call 0x000079CBF140A9A0
000079cbf15cee24  jmp 0x000079CBF15CED42
000079cbf15cee29  call 0x000079CBF140BC20
000079cbf15cee2e  jmp 0x000079CBF15CED5C
000079cbf15cee33  call 0x000079CBF140A9A0
000079cbf15cee38  jmp 0x000079CBF15CED68
000079cbf15cee3d  call 0x000079CBF140BC20
000079cbf15cee42  jmp 0x000079CBF15CED82
000079cbf15cee47  call 0x000079CBF140A9A0
000079cbf15cee4c  jmp 0x000079CBF15CED8E
000079cbf15cee51  call 0x000079CBF140BC20
000079cbf15cee56  jmp 0x000079CBF15CEDA8
000079cbf15cee5b  call 0x000079CBF140A9A0
000079cbf15cee60  jmp 0x000079CBF15CEDB4
000079cbf15cee65  call 0x000079CBF140BC20
000079cbf15cee6a  jmp 0x000079CBF15CEDCE
000079cbf15cee6f  call 0x000079CBF140A9A0
000079cbf15cee74  jmp 0x000079CBF15CEDDA
000079cbf15cee79  int3
000079cbf15cee7a  nop [rax+rax*1], ax
000079cbf15cee80  mov rax, [r15+0x08]
000079cbf15cee84  movzx r14d, byte ptr [r13+rax*1]
000079cbf15cee8a  movzx r14d, r14b
000079cbf15cee8e  mov [rsp+0x10], r14d
000079cbf15cee93  mov r14d, r14d
000079cbf15cee96  mov [r15+0x58], r14
000079cbf15cee9a  lea r14, [rax+0x01]
000079cbf15cee9e  mov [r15+0x08], r14
000079cbf15ceea2  mov rax, [r15+0x88]
000079cbf15ceea9  lea r14, [rax+0x01]
000079cbf15ceead  mov r12, [r15]
000079cbf15ceeb0  lea r11, [r12+0x68]
000079cbf15ceeb5  mov [r13+r11*1], r14
000079cbf15ceeba  lea r14, [r12+rax*1]
000079cbf15ceebe  mov [r15+0x60], r14
000079cbf15ceec2  lea rax, [r14+0x28]
000079cbf15ceec6  mov r11d, [rsp+0x10]
000079cbf15ceecb  movzx r14d, r11b
000079cbf15ceecf  mov [r13+rax*1], r14b
000079cbf15ceed4  lea rax, [r12+0x68]
000079cbf15ceed9  mov r14, [r13+rax*1]
000079cbf15ceede  mov [r15+0x88], r14
000079cbf15ceee5  xor eax, eax
000079cbf15ceee7  mov r12d, 0x40
000079cbf15ceeed  cmp r14, r12
000079cbf15ceef0  cmc
000079cbf15ceef1  lahf
000079cbf15ceef2  seto al
000079cbf15ceef5  mov [r15+0x108], eax
000079cbf15ceefc  mov eax, [r15+0x108]
000079cbf15cef03  sahf
000079cbf15cef04  jnz 0x000079CBF15CEF36
000079cbf15cef06  cmp dword ptr [r15+0x318], 0x00
000079cbf15cef0e  jz 0x000079CBF15CF020
000079cbf15cef14  nop [rax+rax*1], ax
000079cbf15cef1d  nop [rax+rax*1], eax
000079cbf15cef25  mov eax, 0x4103A0
000079cbf15cef2a  mov [r15+0x100], rax
000079cbf15cef31  jmp 0x000079CBF13FE110
000079cbf15cef36  cmp dword ptr [r15+0x318], 0x00
000079cbf15cef3e  jz 0x000079CBF15CEF90
000079cbf15cef44  nop [rax+rax*1], ax
000079cbf15cef4d  nop [rax+rax*1], eax
000079cbf15cef55  mov eax, 0x410378
000079cbf15cef5a  mov [r15+0x100], rax
000079cbf15cef61  jmp 0x000079CBF13FE110
000079cbf15cef66  int3
000079cbf15cef67  call 0x000079CBF140D860
000079cbf15cef6c  jmp 0x000079CBF15CEE8A
000079cbf15cef71  call 0x000079CBF14B36E0
000079cbf15cef76  jmp 0x000079CBF15CEEBA
000079cbf15cef7b  call 0x000079CBF140DD60
000079cbf15cef80  jmp 0x000079CBF15CEED4
000079cbf15cef85  call 0x000079CBF140DC20
000079cbf15cef8a  jmp 0x000079CBF15CEEDE
000079cbf15cef8f  int3
000079cbf15cef90  mov rax, [r15+0x10]
000079cbf15cef94  lea r14, [rax-0x01]
000079cbf15cef98  mov [r15+0x10], r14
000079cbf15cef9c  test r14, r14
000079cbf15cef9f  setz r14b
000079cbf15cefa3  movzx r14, r14b
000079cbf15cefa7  mov [rsp+0x414], r14b
000079cbf15cefaf  cmp byte ptr [rsp+0x414], 0x00
000079cbf15cefb7  jz 0x000079CBF15CEFE9
000079cbf15cefb9  cmp dword ptr [r15+0x318], 0x00
000079cbf15cefc1  jz 0x000079CBF15D0520
000079cbf15cefc7  nop [rax+rax*1], ax
000079cbf15cefd0  nop [rax+rax*1], eax
000079cbf15cefd8  mov eax, 0x410598
000079cbf15cefdd  mov [r15+0x100], rax
000079cbf15cefe4  jmp 0x000079CBF13FE110
000079cbf15cefe9  cmp dword ptr [r15+0x318], 0x00
000079cbf15ceff1  jz 0x000079CBF15CEE80
000079cbf15ceff7  nop [rax+rax*1], ax
000079cbf15cf000  nop [rax+rax*1], eax
000079cbf15cf008  mov eax, 0x410380
000079cbf15cf00d  mov [r15+0x100], rax
000079cbf15cf014  jmp 0x000079CBF13FE110
000079cbf15cf019  int3
000079cbf15cf01a  int3
000079cbf15cf01b  nop [rax+rax*1], eax
000079cbf15cf020  mov rax, [r15+0x40]
000079cbf15cf024  movzx r14d, byte ptr [r13+rax*1]
000079cbf15cf02a  movaps xmm1, [r15+0x110]
000079cbf15cf032  pinsrb xmm1, r14d, 0x00
000079cbf15cf039  lea r14, [rax+0x01]
000079cbf15cf03d  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf043  movaps xmm15, [r15+0x120]
000079cbf15cf04b  pinsrb xmm15, r12d, 0x00
000079cbf15cf052  lea r14, [rax+0x02]
000079cbf15cf056  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf05c  movaps xmm14, [r15+0x130]
000079cbf15cf064  pinsrb xmm14, r12d, 0x00
000079cbf15cf06b  lea r14, [rax+0x03]
000079cbf15cf06f  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf075  movaps xmm13, [r15+0x140]
000079cbf15cf07d  pinsrb xmm13, r12d, 0x00
000079cbf15cf084  lea r14, [rax+0x04]
000079cbf15cf088  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf08e  pinsrb xmm1, r12d, 0x01
000079cbf15cf095  lea r14, [rax+0x05]
000079cbf15cf099  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf09f  pinsrb xmm15, r12d, 0x01
000079cbf15cf0a6  lea r14, [rax+0x06]
000079cbf15cf0aa  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf0b0  pinsrb xmm14, r12d, 0x01
000079cbf15cf0b7  lea r14, [rax+0x07]
000079cbf15cf0bb  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf0c1  pinsrb xmm13, r12d, 0x01
000079cbf15cf0c8  lea r14, [rax+0x08]
000079cbf15cf0cc  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf0d2  pinsrb xmm1, r12d, 0x02
000079cbf15cf0d9  lea r14, [rax+0x09]
000079cbf15cf0dd  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf0e3  pinsrb xmm15, r12d, 0x02
000079cbf15cf0ea  lea r14, [rax+0x0A]
000079cbf15cf0ee  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf0f4  pinsrb xmm14, r12d, 0x02
000079cbf15cf0fb  lea r14, [rax+0x0B]
000079cbf15cf0ff  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf105  pinsrb xmm13, r12d, 0x02
000079cbf15cf10c  lea r14, [rax+0x0C]
000079cbf15cf110  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf116  pinsrb xmm1, r12d, 0x03
000079cbf15cf11d  lea r14, [rax+0x0D]
000079cbf15cf121  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf127  pinsrb xmm15, r12d, 0x03
000079cbf15cf12e  lea r14, [rax+0x0E]
000079cbf15cf132  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf138  pinsrb xmm14, r12d, 0x03
000079cbf15cf13f  lea r14, [rax+0x0F]
000079cbf15cf143  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf149  pinsrb xmm13, r12d, 0x03
000079cbf15cf150  lea r14, [rax+0x10]
000079cbf15cf154  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf15a  pinsrb xmm1, r12d, 0x04
000079cbf15cf161  lea r14, [rax+0x11]
000079cbf15cf165  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf16b  pinsrb xmm15, r12d, 0x04
000079cbf15cf172  lea r14, [rax+0x12]
000079cbf15cf176  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf17c  pinsrb xmm14, r12d, 0x04
000079cbf15cf183  lea r14, [rax+0x13]
000079cbf15cf187  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf18d  pinsrb xmm13, r12d, 0x04
000079cbf15cf194  lea r14, [rax+0x14]
000079cbf15cf198  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf19e  pinsrb xmm1, r12d, 0x05
000079cbf15cf1a5  lea r14, [rax+0x15]
000079cbf15cf1a9  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf1af  pinsrb xmm15, r12d, 0x05
000079cbf15cf1b6  lea r14, [rax+0x16]
000079cbf15cf1ba  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf1c0  pinsrb xmm14, r12d, 0x05
000079cbf15cf1c7  lea r14, [rax+0x17]
000079cbf15cf1cb  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf1d1  pinsrb xmm13, r12d, 0x05
000079cbf15cf1d8  lea r14, [rax+0x18]
000079cbf15cf1dc  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf1e2  pinsrb xmm1, r12d, 0x06
000079cbf15cf1e9  lea r14, [rax+0x19]
000079cbf15cf1ed  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf1f3  pinsrb xmm15, r12d, 0x06
000079cbf15cf1fa  lea r14, [rax+0x1A]
000079cbf15cf1fe  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf204  pinsrb xmm14, r12d, 0x06
000079cbf15cf20b  lea r14, [rax+0x1B]
000079cbf15cf20f  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf215  pinsrb xmm13, r12d, 0x06
000079cbf15cf21c  lea r14, [rax+0x1C]
000079cbf15cf220  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf226  pinsrb xmm1, r12d, 0x07
000079cbf15cf22d  lea r14, [rax+0x1D]
000079cbf15cf231  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf237  pinsrb xmm15, r12d, 0x07
000079cbf15cf23e  lea r14, [rax+0x1E]
000079cbf15cf242  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf248  pinsrb xmm14, r12d, 0x07
000079cbf15cf24f  lea r14, [rax+0x1F]
000079cbf15cf253  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf259  pinsrb xmm13, r12d, 0x07
000079cbf15cf260  lea r14, [rax+0x20]
000079cbf15cf264  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf26a  pinsrb xmm1, r12d, 0x08
000079cbf15cf271  lea r14, [rax+0x21]
000079cbf15cf275  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf27b  pinsrb xmm15, r12d, 0x08
000079cbf15cf282  lea r14, [rax+0x22]
000079cbf15cf286  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf28c  pinsrb xmm14, r12d, 0x08
000079cbf15cf293  lea r14, [rax+0x23]
000079cbf15cf297  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf29d  pinsrb xmm13, r12d, 0x08
000079cbf15cf2a4  lea r14, [rax+0x24]
000079cbf15cf2a8  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf2ae  pinsrb xmm1, r12d, 0x09
000079cbf15cf2b5  lea r14, [rax+0x25]
000079cbf15cf2b9  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf2bf  pinsrb xmm15, r12d, 0x09
000079cbf15cf2c6  lea r14, [rax+0x26]
000079cbf15cf2ca  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf2d0  pinsrb xmm14, r12d, 0x09
000079cbf15cf2d7  lea r14, [rax+0x27]
000079cbf15cf2db  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf2e1  pinsrb xmm13, r12d, 0x09
000079cbf15cf2e8  lea r14, [rax+0x28]
000079cbf15cf2ec  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf2f2  pinsrb xmm1, r12d, 0x0A
000079cbf15cf2f9  lea r14, [rax+0x29]
000079cbf15cf2fd  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf303  pinsrb xmm15, r12d, 0x0A
000079cbf15cf30a  lea r14, [rax+0x2A]
000079cbf15cf30e  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf314  pinsrb xmm14, r12d, 0x0A
000079cbf15cf31b  lea r14, [rax+0x2B]
000079cbf15cf31f  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf325  pinsrb xmm13, r12d, 0x0A
000079cbf15cf32c  lea r14, [rax+0x2C]
000079cbf15cf330  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf336  pinsrb xmm1, r12d, 0x0B
000079cbf15cf33d  lea r14, [rax+0x2D]
000079cbf15cf341  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf347  pinsrb xmm15, r12d, 0x0B
000079cbf15cf34e  lea r14, [rax+0x2E]
000079cbf15cf352  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf358  pinsrb xmm14, r12d, 0x0B
000079cbf15cf35f  lea r14, [rax+0x2F]
000079cbf15cf363  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf369  pinsrb xmm13, r12d, 0x0B
000079cbf15cf370  lea r14, [rax+0x30]
000079cbf15cf374  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf37a  pinsrb xmm1, r12d, 0x0C
000079cbf15cf381  lea r14, [rax+0x31]
000079cbf15cf385  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf38b  pinsrb xmm15, r12d, 0x0C
000079cbf15cf392  lea r14, [rax+0x32]
000079cbf15cf396  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf39c  pinsrb xmm14, r12d, 0x0C
000079cbf15cf3a3  lea r14, [rax+0x33]
000079cbf15cf3a7  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf3ad  pinsrb xmm13, r12d, 0x0C
000079cbf15cf3b4  lea r14, [rax+0x34]
000079cbf15cf3b8  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf3be  pinsrb xmm1, r12d, 0x0D
000079cbf15cf3c5  lea r14, [rax+0x35]
000079cbf15cf3c9  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf3cf  pinsrb xmm15, r12d, 0x0D
000079cbf15cf3d6  lea r14, [rax+0x36]
000079cbf15cf3da  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf3e0  pinsrb xmm14, r12d, 0x0D
000079cbf15cf3e7  lea r14, [rax+0x37]
000079cbf15cf3eb  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf3f1  pinsrb xmm13, r12d, 0x0D
000079cbf15cf3f8  lea r14, [rax+0x38]
000079cbf15cf3fc  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf402  pinsrb xmm1, r12d, 0x0E
000079cbf15cf409  lea r14, [rax+0x39]
000079cbf15cf40d  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf413  pinsrb xmm15, r12d, 0x0E
000079cbf15cf41a  lea r14, [rax+0x3A]
000079cbf15cf41e  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf424  pinsrb xmm14, r12d, 0x0E
000079cbf15cf42b  lea r14, [rax+0x3B]
000079cbf15cf42f  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf435  pinsrb xmm13, r12d, 0x0E
000079cbf15cf43c  lea r14, [rax+0x3C]
000079cbf15cf440  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf446  pinsrb xmm1, r12d, 0x0F
000079cbf15cf44d  movaps [r15+0x110], xmm1
000079cbf15cf455  lea r14, [rax+0x3D]
000079cbf15cf459  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf45f  pinsrb xmm15, r12d, 0x0F
000079cbf15cf466  movaps [r15+0x120], xmm15
000079cbf15cf46e  lea r14, [rax+0x3E]
000079cbf15cf472  movzx r12d, byte ptr [r13+r14*1]
000079cbf15cf478  pinsrb xmm14, r12d, 0x0F
000079cbf15cf47f  movaps [r15+0x130], xmm14
000079cbf15cf487  lea r14, [rax+0x3F]
000079cbf15cf48b  movzx eax, byte ptr [r13+r14*1]
000079cbf15cf491  pinsrb xmm13, eax, 0x0F
000079cbf15cf498  movaps [r15+0x140], xmm13
000079cbf15cf4a0  movq xmm1, qword ptr [r15+0x120]
000079cbf15cf4a9  pmovzxbw xmm1, xmm1
000079cbf15cf4ae  psllw xmm1, 0x00
000079cbf15cf4b3  movaps [r15+0x150], xmm1
000079cbf15cf4bb  movq xmm1, qword ptr [r15+0x130]
000079cbf15cf4c4  pmovzxbw xmm1, xmm1
000079cbf15cf4c9  psllw xmm1, 0x00
000079cbf15cf4ce  movaps [r15+0x160], xmm1
000079cbf15cf4d6  movq xmm1, qword ptr [r15+0x110]
000079cbf15cf4df  pmovzxbw xmm1, xmm1
000079cbf15cf4e4  psllw xmm1, 0x00
000079cbf15cf4e9  movaps [r15+0x170], xmm1
000079cbf15cf4f1  movaps xmm15, [r15+0x110]
000079cbf15cf4f9  pextrq rax, xmm15, 0x01
000079cbf15cf500  movq xmm15, rax
000079cbf15cf505  pmovzxbw xmm15, xmm15
000079cbf15cf50b  psllw xmm15, 0x00
000079cbf15cf511  movaps [r15+0x180], xmm15
000079cbf15cf519  movaps xmm14, [r15+0x120]
000079cbf15cf521  pextrq rax, xmm14, 0x01
000079cbf15cf528  movq xmm14, rax
000079cbf15cf52d  pmovzxbw xmm14, xmm14
000079cbf15cf533  psllw xmm14, 0x00
000079cbf15cf539  movaps [r15+0x210], xmm14
000079cbf15cf541  movaps xmm13, [r15+0x130]
000079cbf15cf549  pextrq rax, xmm13, 0x01
000079cbf15cf550  movq xmm13, rax
000079cbf15cf555  pmovzxbw xmm13, xmm13
000079cbf15cf55b  psllw xmm13, 0x00
000079cbf15cf561  movaps [r15+0x220], xmm13
000079cbf15cf569  movq xmm12, qword ptr [r15+0x140]
000079cbf15cf572  pmovzxbw xmm12, xmm12
000079cbf15cf578  psllw xmm12, 0x00
000079cbf15cf57e  movaps [r15+0x250], xmm12
000079cbf15cf586  movaps xmm12, [r15+0x140]
000079cbf15cf58e  pextrq rax, xmm12, 0x01
000079cbf15cf595  movq xmm12, rax
000079cbf15cf59a  pmovzxbw xmm12, xmm12
000079cbf15cf5a0  psllw xmm12, 0x00
000079cbf15cf5a6  movaps [r15+0x110], xmm12
000079cbf15cf5ae  movq xmm11, qword ptr [r15+0x150]
000079cbf15cf5b7  pmovzxwd xmm11, xmm11
000079cbf15cf5bd  pslld xmm11, 0x10
000079cbf15cf5c3  movq xmm10, qword ptr [r15+0x160]
000079cbf15cf5cc  pmovzxwd xmm10, xmm10
000079cbf15cf5d2  pslld xmm10, 0x08
000079cbf15cf5d8  pextrq rax, xmm1, 0x01
000079cbf15cf5df  movq xmm1, rax
000079cbf15cf5e4  pmovzxwd xmm1, xmm1
000079cbf15cf5e9  pslld xmm1, 0x00
000079cbf15cf5ee  movaps [r15+0x260], xmm1
000079cbf15cf5f6  pextrq rax, xmm15, 0x01
000079cbf15cf5fd  movq xmm15, rax
000079cbf15cf602  pmovzxwd xmm15, xmm15
000079cbf15cf608  pslld xmm15, 0x00
000079cbf15cf60e  movaps [r15+0x270], xmm15
000079cbf15cf616  movq xmm9, qword ptr [r15+0x170]
000079cbf15cf61f  pmovzxwd xmm9, xmm9
000079cbf15cf625  pslld xmm9, 0x00
000079cbf15cf62b  pextrq rax, xmm14, 0x01
000079cbf15cf632  movq xmm14, rax
000079cbf15cf637  pmovzxwd xmm14, xmm14
000079cbf15cf63d  pslld xmm14, 0x10
000079cbf15cf643  movaps [r15+0x280], xmm14
000079cbf15cf64b  movq xmm8, qword ptr [r15+0x180]
000079cbf15cf654  pmovzxwd xmm8, xmm8
000079cbf15cf65a  pslld xmm8, 0x00
000079cbf15cf660  movq xmm7, qword ptr [r15+0x210]
000079cbf15cf669  pmovzxwd xmm7, xmm7
000079cbf15cf66e  pslld xmm7, 0x10
000079cbf15cf673  movaps xmm6, [r15+0x150]
000079cbf15cf67b  pextrq rax, xmm6, 0x01
000079cbf15cf682  movq xmm6, rax
000079cbf15cf687  pmovzxwd xmm6, xmm6
000079cbf15cf68c  pslld xmm6, 0x10
000079cbf15cf691  por xmm11, xmm10
000079cbf15cf696  movaps [r15+0x230], xmm11
000079cbf15cf69e  pextrq rax, xmm13, 0x01
000079cbf15cf6a5  movq xmm13, rax
000079cbf15cf6aa  pmovzxwd xmm13, xmm13
000079cbf15cf6b0  pslld xmm13, 0x08
000079cbf15cf6b6  movaps [r15+0x240], xmm13
000079cbf15cf6be  movq xmm10, qword ptr [r15+0x220]
000079cbf15cf6c7  pmovzxwd xmm10, xmm10
000079cbf15cf6cd  pslld xmm10, 0x08
000079cbf15cf6d3  movaps xmm5, [r15+0x160]
000079cbf15cf6db  pextrq rax, xmm5, 0x01
000079cbf15cf6e2  movq xmm5, rax
000079cbf15cf6e7  pmovzxwd xmm5, xmm5
000079cbf15cf6ec  pslld xmm5, 0x08
000079cbf15cf6f1  pslld xmm9, 0x18
000079cbf15cf6f7  pslld xmm15, 0x18
000079cbf15cf6fd  pslld xmm8, 0x18
000079cbf15cf703  movq xmm4, qword ptr [r15+0x250]
000079cbf15cf70c  pmovzxwd xmm4, xmm4
000079cbf15cf711  pslld xmm4, 0x00
000079cbf15cf716  por xmm14, xmm13
000079cbf15cf71b  por xmm7, xmm10
000079cbf15cf720  movaps [r15+0x210], xmm7
000079cbf15cf728  pslld xmm1, 0x18
000079cbf15cf72d  movaps [r15+0x220], xmm1
000079cbf15cf735  por xmm6, xmm5
000079cbf15cf739  por xmm11, xmm9
000079cbf15cf73e  movaps [r15+0x160], xmm11
000079cbf15cf746  pextrq rax, xmm12, 0x01
000079cbf15cf74d  movq xmm13, rax
000079cbf15cf752  pmovzxwd xmm13, xmm13
000079cbf15cf758  pslld xmm13, 0x00
000079cbf15cf75e  movaps [r15+0x170], xmm13
000079cbf15cf766  movq xmm12, qword ptr [r15+0x110]
000079cbf15cf76f  pmovzxwd xmm12, xmm12
000079cbf15cf775  pslld xmm12, 0x00
000079cbf15cf77b  por xmm14, xmm15
000079cbf15cf780  por xmm7, xmm8
000079cbf15cf785  movaps xmm15, [r15+0x250]
000079cbf15cf78d  pextrq rax, xmm15, 0x01
000079cbf15cf794  movq xmm15, rax
000079cbf15cf799  pmovzxwd xmm15, xmm15
000079cbf15cf79f  pslld xmm15, 0x00
000079cbf15cf7a5  movaps [r15+0x180], xmm15
000079cbf15cf7ad  por xmm6, xmm1
000079cbf15cf7b1  movaps [r15+0x150], xmm6
000079cbf15cf7b9  por xmm11, xmm4
000079cbf15cf7be  movaps [r15+0x140], xmm11
000079cbf15cf7c6  por xmm7, xmm12
000079cbf15cf7cb  movaps [r15+0x110], xmm7
000079cbf15cf7d3  por xmm14, xmm13
000079cbf15cf7d8  movaps [r15+0x120], xmm14
000079cbf15cf7e0  por xmm6, xmm15
000079cbf15cf7e5  movaps [r15+0x130], xmm6
000079cbf15cf7ed  mov rax, [r15+0xF8]
000079cbf15cf7f4  lea r14, [rax+0x20]
000079cbf15cf7f8  movups [r13+r14*1], xmm7
000079cbf15cf7fe  lea r14, [rax+0x30]
000079cbf15cf802  movups [r13+r14*1], xmm14
000079cbf15cf808  movups [r13+rax*1], xmm11
000079cbf15cf80e  lea r14, [rax+0x10]
000079cbf15cf812  movups [r13+r14*1], xmm6
000079cbf15cf818  mov r14d, [r13+rax*1]
000079cbf15cf81d  mov rax, [r15+0x48]
000079cbf15cf821  mov [r15+0x68], rax
000079cbf15cf825  mov qword ptr [r15+0x58], 0x04
000079cbf15cf82d  lea r12, [rax+0x04]
000079cbf15cf831  mov r11d, [r13+r12*1]
000079cbf15cf836  mov [rsp+0x10], r11d
000079cbf15cf83b  mov r11d, r11d
000079cbf15cf83e  mov [r15+0x70], r11
000079cbf15cf842  lea r12, [rax+0x38]
000079cbf15cf846  mov r11d, [r13+r12*1]
000079cbf15cf84b  lea r12, [rax+0x24]
000079cbf15cf84f  mov r10d, [r13+r12*1]
000079cbf15cf854  mov [rsp+0x20], r10d
000079cbf15cf859  mov r10d, r10d
000079cbf15cf85c  mov [r15+0x90], r10
000079cbf15cf863  mov [rsp+0x30], rax
000079cbf15cf868  xor eax, eax
000079cbf15cf86a  mov r12d, 0x04
000079cbf15cf870  mov r10d, 0xC0
000079cbf15cf876  cmp r12, r10
000079cbf15cf879  cmc
000079cbf15cf87a  lahf
000079cbf15cf87b  seto al
000079cbf15cf87e  mov [r15+0x108], eax
000079cbf15cf885  mov eax, [rsp+0x10]
000079cbf15cf889  mov r12d, [rsp+0x10]
000079cbf15cf88e  shrd eax, r12d, 0x07
000079cbf15cf893  mov [rsp+0x10], r11d
000079cbf15cf898  mov r10d, [rsp+0x10]
000079cbf15cf89d  shrd r11d, r10d, 0x11
000079cbf15cf8a2  mov r9d, [rsp+0x20]
000079cbf15cf8a7  lea r8d, [r9d+r14d*1]
000079cbf15cf8ac  rorx r14d, r12d, 0x12
000079cbf15cf8b2  xor eax, r14d
000079cbf15cf8b5  rorx r14d, r10d, 0x13
000079cbf15cf8bb  xor r11d, r14d
000079cbf15cf8be  mov [rsp+0x10], r11d
000079cbf15cf8c3  mov r11d, r11d
000079cbf15cf8c6  mov [r15+0x88], r11
000079cbf15cf8cd  mov [rsp+0x20], r12d
000079cbf15cf8d2  shr r12d, 0x03
000079cbf15cf8d6  xor eax, r12d
000079cbf15cf8d9  mov [rsp+0x40], eax
000079cbf15cf8dd  mov eax, eax
000079cbf15cf8df  mov [r15+0x80], rax
000079cbf15cf8e6  shr r10d, 0x0A
000079cbf15cf8ea  mov eax, [rsp+0x10]
000079cbf15cf8ee  xor eax, r10d
000079cbf15cf8f1  mov [rsp+0x10], eax
000079cbf15cf8f5  mov eax, eax
000079cbf15cf8f7  mov [r15+0x78], rax
000079cbf15cf8fb  mov eax, [rsp+0x40]
000079cbf15cf8ff  lea r14d, [r8d+eax*1]
000079cbf15cf904  mov eax, [rsp+0x10]
000079cbf15cf908  lea r12d, [r14d+eax*1]
000079cbf15cf90d  mov rax, [rsp+0x30]
000079cbf15cf912  lea r14, [rax+0x40]
000079cbf15cf916  mov [r13+r14*1], r12d
000079cbf15cf91b  mov eax, [rsp+0x20]
000079cbf15cf91f  mov eax, eax
000079cbf15cf921  mov [r15+0x60], rax
000079cbf15cf925  mov eax, [r15+0x108]
000079cbf15cf92c  sahf
000079cbf15cf92d  jnz 0x000079CBF15CF95F
000079cbf15cf92f  cmp dword ptr [r15+0x318], 0x00
000079cbf15cf937  jz 0x000079CBF15CFE20
000079cbf15cf93d  nop [rax+rax*1], ax
000079cbf15cf946  nop [rax+rax*1], eax
000079cbf15cf94e  mov eax, 0x41049C
000079cbf15cf953  mov [r15+0x100], rax
000079cbf15cf95a  jmp 0x000079CBF13FE110
000079cbf15cf95f  cmp dword ptr [r15+0x318], 0x00
000079cbf15cf967  jz 0x000079CBF15CFC70
000079cbf15cf96d  nop [rax+rax*1], ax
000079cbf15cf976  nop [rax+rax*1], eax
000079cbf15cf97e  mov eax, 0x410454
000079cbf15cf983  mov [r15+0x100], rax
000079cbf15cf98a  jmp 0x000079CBF13FE110
000079cbf15cf98f  int3
000079cbf15cf990  call 0x000079CBF140D860
000079cbf15cf995  jmp 0x000079CBF15CF02A
000079cbf15cf99a  call 0x000079CBF14E2420
000079cbf15cf99f  jmp 0x000079CBF15CF043
000079cbf15cf9a4  call 0x000079CBF14E2420
000079cbf15cf9a9  jmp 0x000079CBF15CF05C
000079cbf15cf9ae  call 0x000079CBF14E2420
000079cbf15cf9b3  jmp 0x000079CBF15CF075
000079cbf15cf9b8  call 0x000079CBF14E2420
000079cbf15cf9bd  jmp 0x000079CBF15CF08E
000079cbf15cf9c2  call 0x000079CBF14E2420
000079cbf15cf9c7  jmp 0x000079CBF15CF09F
000079cbf15cf9cc  call 0x000079CBF14E2420
000079cbf15cf9d1  jmp 0x000079CBF15CF0B0
000079cbf15cf9d6  call 0x000079CBF14E2420
000079cbf15cf9db  jmp 0x000079CBF15CF0C1
000079cbf15cf9e0  call 0x000079CBF14E2420
000079cbf15cf9e5  jmp 0x000079CBF15CF0D2
000079cbf15cf9ea  call 0x000079CBF14E2420
000079cbf15cf9ef  jmp 0x000079CBF15CF0E3
000079cbf15cf9f4  call 0x000079CBF14E2420
000079cbf15cf9f9  jmp 0x000079CBF15CF0F4
000079cbf15cf9fe  call 0x000079CBF14E2420
000079cbf15cfa03  jmp 0x000079CBF15CF105
000079cbf15cfa08  call 0x000079CBF14E2420
000079cbf15cfa0d  jmp 0x000079CBF15CF116
000079cbf15cfa12  call 0x000079CBF14E2420
000079cbf15cfa17  jmp 0x000079CBF15CF127
000079cbf15cfa1c  call 0x000079CBF14E2420
000079cbf15cfa21  jmp 0x000079CBF15CF138
000079cbf15cfa26  call 0x000079CBF14E2420
000079cbf15cfa2b  jmp 0x000079CBF15CF149
000079cbf15cfa30  call 0x000079CBF14E2420
000079cbf15cfa35  jmp 0x000079CBF15CF15A
000079cbf15cfa3a  call 0x000079CBF14E2420
000079cbf15cfa3f  jmp 0x000079CBF15CF16B
000079cbf15cfa44  call 0x000079CBF14E2420
000079cbf15cfa49  jmp 0x000079CBF15CF17C
000079cbf15cfa4e  call 0x000079CBF14E2420
000079cbf15cfa53  jmp 0x000079CBF15CF18D
000079cbf15cfa58  call 0x000079CBF14E2420
000079cbf15cfa5d  jmp 0x000079CBF15CF19E
000079cbf15cfa62  call 0x000079CBF14E2420
000079cbf15cfa67  jmp 0x000079CBF15CF1AF
000079cbf15cfa6c  call 0x000079CBF14E2420
000079cbf15cfa71  jmp 0x000079CBF15CF1C0
000079cbf15cfa76  call 0x000079CBF14E2420
000079cbf15cfa7b  jmp 0x000079CBF15CF1D1
000079cbf15cfa80  call 0x000079CBF14E2420
000079cbf15cfa85  jmp 0x000079CBF15CF1E2
000079cbf15cfa8a  call 0x000079CBF14E2420
000079cbf15cfa8f  jmp 0x000079CBF15CF1F3
000079cbf15cfa94  call 0x000079CBF14E2420
000079cbf15cfa99  jmp 0x000079CBF15CF204
000079cbf15cfa9e  call 0x000079CBF14E2420
000079cbf15cfaa3  jmp 0x000079CBF15CF215
000079cbf15cfaa8  call 0x000079CBF14E2420
000079cbf15cfaad  jmp 0x000079CBF15CF226
000079cbf15cfab2  call 0x000079CBF14E2420
000079cbf15cfab7  jmp 0x000079CBF15CF237
000079cbf15cfabc  call 0x000079CBF14E2420
000079cbf15cfac1  jmp 0x000079CBF15CF248
000079cbf15cfac6  call 0x000079CBF14E2420
000079cbf15cfacb  jmp 0x000079CBF15CF259
000079cbf15cfad0  call 0x000079CBF14E2420
000079cbf15cfad5  jmp 0x000079CBF15CF26A
000079cbf15cfada  call 0x000079CBF14E2420
000079cbf15cfadf  jmp 0x000079CBF15CF27B
000079cbf15cfae4  call 0x000079CBF14E2420
000079cbf15cfae9  jmp 0x000079CBF15CF28C
000079cbf15cfaee  call 0x000079CBF14E2420
000079cbf15cfaf3  jmp 0x000079CBF15CF29D
000079cbf15cfaf8  call 0x000079CBF14E2420
000079cbf15cfafd  jmp 0x000079CBF15CF2AE
000079cbf15cfb02  call 0x000079CBF14E2420
000079cbf15cfb07  jmp 0x000079CBF15CF2BF
000079cbf15cfb0c  call 0x000079CBF14E2420
000079cbf15cfb11  jmp 0x000079CBF15CF2D0
000079cbf15cfb16  call 0x000079CBF14E2420
000079cbf15cfb1b  jmp 0x000079CBF15CF2E1
000079cbf15cfb20  call 0x000079CBF14E2420
000079cbf15cfb25  jmp 0x000079CBF15CF2F2
000079cbf15cfb2a  call 0x000079CBF14E2420
000079cbf15cfb2f  jmp 0x000079CBF15CF303
000079cbf15cfb34  call 0x000079CBF14E2420
000079cbf15cfb39  jmp 0x000079CBF15CF314
000079cbf15cfb3e  call 0x000079CBF14E2420
000079cbf15cfb43  jmp 0x000079CBF15CF325
000079cbf15cfb48  call 0x000079CBF14E2420
000079cbf15cfb4d  jmp 0x000079CBF15CF336
000079cbf15cfb52  call 0x000079CBF14E2420
000079cbf15cfb57  jmp 0x000079CBF15CF347
000079cbf15cfb5c  call 0x000079CBF14E2420
000079cbf15cfb61  jmp 0x000079CBF15CF358
000079cbf15cfb66  call 0x000079CBF14E2420
000079cbf15cfb6b  jmp 0x000079CBF15CF369
000079cbf15cfb70  call 0x000079CBF14E2420
000079cbf15cfb75  jmp 0x000079CBF15CF37A
000079cbf15cfb7a  call 0x000079CBF14E2420
000079cbf15cfb7f  jmp 0x000079CBF15CF38B
000079cbf15cfb84  call 0x000079CBF14E2420
000079cbf15cfb89  jmp 0x000079CBF15CF39C
000079cbf15cfb8e  call 0x000079CBF14E2420
000079cbf15cfb93  jmp 0x000079CBF15CF3AD
000079cbf15cfb98  call 0x000079CBF14E2420
000079cbf15cfb9d  jmp 0x000079CBF15CF3BE
000079cbf15cfba2  call 0x000079CBF14E2420
000079cbf15cfba7  jmp 0x000079CBF15CF3CF
000079cbf15cfbac  call 0x000079CBF14E2420
000079cbf15cfbb1  jmp 0x000079CBF15CF3E0
000079cbf15cfbb6  call 0x000079CBF14E2420
000079cbf15cfbbb  jmp 0x000079CBF15CF3F1
000079cbf15cfbc0  call 0x000079CBF14E2420
000079cbf15cfbc5  jmp 0x000079CBF15CF402
000079cbf15cfbca  call 0x000079CBF14E2420
000079cbf15cfbcf  jmp 0x000079CBF15CF413
000079cbf15cfbd4  call 0x000079CBF14E2420
000079cbf15cfbd9  jmp 0x000079CBF15CF424
000079cbf15cfbde  call 0x000079CBF14E2420
000079cbf15cfbe3  jmp 0x000079CBF15CF435
000079cbf15cfbe8  call 0x000079CBF14E2420
000079cbf15cfbed  jmp 0x000079CBF15CF446
000079cbf15cfbf2  call 0x000079CBF14E2420
000079cbf15cfbf7  jmp 0x000079CBF15CF45F
000079cbf15cfbfc  call 0x000079CBF14E2420
000079cbf15cfc01  jmp 0x000079CBF15CF478
000079cbf15cfc06  call 0x000079CBF14D5610
000079cbf15cfc0b  jmp 0x000079CBF15CF491
000079cbf15cfc10  call 0x000079CBF14DC580
000079cbf15cfc15  jmp 0x000079CBF15CF7FE
000079cbf15cfc1a  call 0x000079CBF14E46C0
000079cbf15cfc1f  jmp 0x000079CBF15CF808
000079cbf15cfc24  call 0x000079CBF1409E90
000079cbf15cfc29  jmp 0x000079CBF15CF80E
000079cbf15cfc2e  call 0x000079CBF14DB310
000079cbf15cfc33  jmp 0x000079CBF15CF818
000079cbf15cfc38  call 0x000079CBF140DAE0
000079cbf15cfc3d  jmp 0x000079CBF15CF81D
000079cbf15cfc42  call 0x000079CBF14C0230
000079cbf15cfc47  jmp 0x000079CBF15CF836
000079cbf15cfc4c  call 0x000079CBF14C0230
000079cbf15cfc51  jmp 0x000079CBF15CF84B
000079cbf15cfc56  call 0x000079CBF14BEFC0
000079cbf15cfc5b  jmp 0x000079CBF15CF854
000079cbf15cfc60  call 0x000079CBF14E2BA0
000079cbf15cfc65  jmp 0x000079CBF15CF91B
000079cbf15cfc6a  int3
000079cbf15cfc6b  nop [rax+rax*1], eax
000079cbf15cfc70  mov rax, [r15+0x48]
000079cbf15cfc74  mov r14, [r15+0x58]
000079cbf15cfc78  lea r12, [rax+r14*1]
000079cbf15cfc7c  mov [r15+0x68], r12
000079cbf15cfc80  lea rax, [r14+0x04]
000079cbf15cfc84  mov [r15+0x58], rax
000079cbf15cfc88  lea r14, [r12+0x04]
000079cbf15cfc8d  mov r11d, [r13+r14*1]
000079cbf15cfc92  mov [rsp+0x10], r11d
000079cbf15cfc97  mov r11d, r11d
000079cbf15cfc9a  mov [r15+0x70], r11
000079cbf15cfc9e  lea r14, [r12+0x38]
000079cbf15cfca3  mov r11d, [r13+r14*1]
000079cbf15cfca8  lea r14, [r12+0x24]
000079cbf15cfcad  mov r10d, [r13+r14*1]
000079cbf15cfcb2  mov [rsp+0x20], r10d
000079cbf15cfcb7  mov r10d, r10d
000079cbf15cfcba  mov [r15+0x90], r10
000079cbf15cfcc1  mov [rsp+0x30], rax
000079cbf15cfcc6  xor eax, eax
000079cbf15cfcc8  mov r14, [rsp+0x30]
000079cbf15cfccd  mov r10d, 0xC0
000079cbf15cfcd3  cmp r14, r10
000079cbf15cfcd6  cmc
000079cbf15cfcd7  lahf
000079cbf15cfcd8  seto al
000079cbf15cfcdb  mov [r15+0x108], eax
000079cbf15cfce2  mov eax, [rsp+0x10]
000079cbf15cfce6  mov r14d, [rsp+0x10]
000079cbf15cfceb  shrd eax, r14d, 0x07
000079cbf15cfcf0  mov [rsp+0x10], r11d
000079cbf15cfcf5  mov r10d, [rsp+0x10]
000079cbf15cfcfa  shrd r11d, r10d, 0x11
000079cbf15cfcff  mov r9d, [r15+0x60]
000079cbf15cfd03  mov r8d, [rsp+0x20]
000079cbf15cfd08  lea ebp, [r8d+r9d*1]
000079cbf15cfd0d  rorx r9d, r14d, 0x12
000079cbf15cfd13  xor eax, r9d
000079cbf15cfd16  rorx r9d, r10d, 0x13
000079cbf15cfd1c  xor r11d, r9d
000079cbf15cfd1f  mov [rsp+0x10], r11d
000079cbf15cfd24  mov r11d, r11d
000079cbf15cfd27  mov [r15+0x88], r11
000079cbf15cfd2e  mov [rsp+0x20], r14d
000079cbf15cfd33  shr r14d, 0x03
000079cbf15cfd37  xor eax, r14d
000079cbf15cfd3a  mov [rsp+0x30], eax
000079cbf15cfd3e  mov eax, eax
000079cbf15cfd40  mov [r15+0x80], rax
000079cbf15cfd47  shr r10d, 0x0A
000079cbf15cfd4b  mov eax, [rsp+0x10]
000079cbf15cfd4f  xor eax, r10d
000079cbf15cfd52  mov [rsp+0x10], eax
000079cbf15cfd56  mov eax, eax
000079cbf15cfd58  mov [r15+0x78], rax
000079cbf15cfd5c  mov eax, [rsp+0x30]
000079cbf15cfd60  lea r14d, [ebp+eax*1]
000079cbf15cfd66  mov eax, [rsp+0x10]
000079cbf15cfd6a  lea r11d, [r14d+eax*1]
000079cbf15cfd6f  lea rax, [r12+0x40]
000079cbf15cfd74  mov [r13+rax*1], r11d
000079cbf15cfd79  mov eax, [rsp+0x20]
000079cbf15cfd7d  mov eax, eax
000079cbf15cfd7f  mov [r15+0x60], rax
000079cbf15cfd83  mov eax, [r15+0x108]
000079cbf15cfd8a  sahf
000079cbf15cfd8b  jnz 0x000079CBF15CFDBD
000079cbf15cfd8d  cmp dword ptr [r15+0x318], 0x00
000079cbf15cfd95  jz 0x000079CBF15CFE20
000079cbf15cfd9b  nop [rax+rax*1], ax
000079cbf15cfda4  nop [rax+rax*1], eax
000079cbf15cfdac  mov eax, 0x41049C
000079cbf15cfdb1  mov [r15+0x100], rax
000079cbf15cfdb8  jmp 0x000079CBF13FE110
000079cbf15cfdbd  cmp dword ptr [r15+0x318], 0x00
000079cbf15cfdc5  jz 0x000079CBF15CFC70
000079cbf15cfdcb  nop [rax+rax*1], ax
000079cbf15cfdd4  nop [rax+rax*1], eax
000079cbf15cfddc  mov eax, 0x410454
000079cbf15cfde1  mov [r15+0x100], rax
000079cbf15cfde8  jmp 0x000079CBF13FE110
000079cbf15cfded  int3
000079cbf15cfdee  call 0x000079CBF14E1430
000079cbf15cfdf3  jmp 0x000079CBF15CFC92
000079cbf15cfdf8  call 0x000079CBF14E1430
000079cbf15cfdfd  jmp 0x000079CBF15CFCA8
000079cbf15cfe02  call 0x000079CBF14E01C0
000079cbf15cfe07  jmp 0x000079CBF15CFCB2
000079cbf15cfe0c  call 0x000079CBF140A860
000079cbf15cfe11  jmp 0x000079CBF15CFD79
000079cbf15cfe16  int3
000079cbf15cfe17  nop [rax+rax*1], ax
000079cbf15cfe20  mov rax, [r15]
000079cbf15cfe23  mov r14d, [r13+rax*1]
000079cbf15cfe28  lea r12, [rax+0x04]
000079cbf15cfe2c  mov r11d, [r13+r12*1]
000079cbf15cfe31  mov [rsp+0x10], r14d
000079cbf15cfe36  mov r14d, r14d
000079cbf15cfe39  mov [r15+0x78], r14
000079cbf15cfe3d  mov [rsp+0x20], r11d
000079cbf15cfe42  mov r11d, r11d
000079cbf15cfe45  mov [r15+0x80], r11
000079cbf15cfe4c  lea r14, [rax+0x08]
000079cbf15cfe50  mov r12d, [r13+r14*1]
000079cbf15cfe55  lea r14, [rax+0x0C]
000079cbf15cfe59  mov r11d, [r13+r14*1]
000079cbf15cfe5e  mov [rsp+0x30], r12d
000079cbf15cfe63  mov r12d, r12d
000079cbf15cfe66  mov [r15+0x70], r12
000079cbf15cfe6a  mov [rsp+0x40], r11d
000079cbf15cfe6f  mov r11d, r11d
000079cbf15cfe72  mov [r15+0x68], r11
000079cbf15cfe76  lea r14, [rax+0x18]
000079cbf15cfe7a  mov r12d, [r13+r14*1]
000079cbf15cfe7f  lea r14, [rax+0x1C]
000079cbf15cfe83  mov r11d, [r13+r14*1]
000079cbf15cfe88  mov [rsp+0x50], r12d
000079cbf15cfe8d  mov r12d, r12d
000079cbf15cfe90  mov [r15+0x58], r12
000079cbf15cfe94  mov [rsp+0x60], r11d
000079cbf15cfe99  mov r11d, r11d
000079cbf15cfe9c  mov [r15+0x60], r11
000079cbf15cfea0  lea r14, [rax+0x10]
000079cbf15cfea4  mov r12d, [r13+r14*1]
000079cbf15cfea9  lea r14, [rax+0x14]
000079cbf15cfead  mov eax, [r13+r14*1]
000079cbf15cfeb2  mov [rsp+0x70], r12d
000079cbf15cfeb7  mov r12d, r12d
000079cbf15cfeba  mov [r15+0x18], r12
000079cbf15cfebe  mov [rsp+0x80], eax
000079cbf15cfec5  mov eax, eax
000079cbf15cfec7  mov [r15+0x90], rax
000079cbf15cfece  mov eax, [rsp+0x70]
000079cbf15cfed2  mov eax, eax
000079cbf15cfed4  mov [r15+0x30], rax
000079cbf15cfed8  mov eax, [rsp+0x50]
000079cbf15cfedc  mov eax, eax
000079cbf15cfede  mov [r15+0xA0], rax
000079cbf15cfee5  mov eax, [rsp+0x30]
000079cbf15cfee9  mov eax, eax
000079cbf15cfeeb  mov [r15+0x28], rax
000079cbf15cfeef  mov eax, [rsp+0x20]
000079cbf15cfef3  mov eax, eax
000079cbf15cfef5  mov [r15+0x98], rax
000079cbf15cfefc  mov eax, [rsp+0x10]
000079cbf15cff00  mov eax, eax
000079cbf15cff02  mov [r15+0x38], rax
000079cbf15cff06  mov eax, [rsp+0x70]
000079cbf15cff0a  mov r14d, [rsp+0x70]
000079cbf15cff0f  shrd eax, r14d, 0x06
000079cbf15cff14  mov [rsp+0x70], r14d
000079cbf15cff19  mov r12d, [rsp+0x80]
000079cbf15cff21  and r14d, r12d
000079cbf15cff24  mov r11d, [rsp+0x10]
000079cbf15cff29  mov r10d, [rsp+0x10]
000079cbf15cff2e  shrd r11d, r10d, 0x02
000079cbf15cff33  mov [rsp+0x10], r12d
000079cbf15cff38  mov r12d, r12d
000079cbf15cff3b  mov [r15+0x20], r12
000079cbf15cff3f  mov r12, [r15+0x50]
000079cbf15cff43  mov r9d, [r13+r12*1]
000079cbf15cff48  mov r12d, [rsp+0x50]
000079cbf15cff4d  mov r8d, [rsp+0x70]
000079cbf15cff52  andn ebp, r8d, r12d
000079cbf15cff57  mov edi, [rsp+0x60]
000079cbf15cff5b  lea esi, [r14d+edi*1]
000079cbf15cff60  rorx r14d, r8d, 0x0B
000079cbf15cff66  xor eax, r14d
000079cbf15cff69  rorx r14d, r10d, 0x0D
000079cbf15cff6f  xor r11d, r14d
000079cbf15cff72  lea edi, [esi+ebp*1]
000079cbf15cff76  mov r14, [r15+0x48]
000079cbf15cff7a  mov ebp, [r13+r14*1]
000079cbf15cff7f  mov r14d, [rsp+0x30]
000079cbf15cff84  mov esi, [rsp+0x20]
000079cbf15cff88  and r14d, esi
000079cbf15cff8b  mov [rsp+0x20], r14d
000079cbf15cff90  mov r14d, r14d
000079cbf15cff93  mov [r15+0xD8], r14
000079cbf15cff9a  lea r14d, [edi+r9d*1]
000079cbf15cff9f  mov r9d, [rsp+0x30]
000079cbf15cffa4  xor r9d, esi
000079cbf15cffa7  rorx edi, r8d, 0x19
000079cbf15cffad  xor eax, edi
000079cbf15cffaf  and r9d, r10d
000079cbf15cffb2  rorx edi, r10d, 0x16
000079cbf15cffb8  xor r11d, edi
000079cbf15cffbb  mov [rsp+0x30], r11d
000079cbf15cffc0  mov r11d, r11d
000079cbf15cffc3  mov [r15+0xD0], r11
000079cbf15cffca  lea r11d, [r14d+ebp*1]
000079cbf15cffcf  mov r10d, [rsp+0x20]
000079cbf15cffd4  xor r9d, r10d
000079cbf15cffd7  lea r14d, [r11d+eax*1]
000079cbf15cffdc  mov qword ptr [r15+0x88], 0x04
000079cbf15cffe7  mov eax, [rsp+0x30]
000079cbf15cffeb  lea r11d, [r9d+eax*1]
000079cbf15cfff0  mov eax, [rsp+0x40]
000079cbf15cfff4  lea r10d, [r14d+eax*1]
000079cbf15cfff9  mov r10d, r10d
000079cbf15cfffc  mov [r15+0xB8], r10
000079cbf15d0003  xor eax, eax
000079cbf15d0005  mov r10d, 0x04
000079cbf15d000b  mov r9d, 0x100
000079cbf15d0011  cmp r10, r9
000079cbf15d0014  cmc
000079cbf15d0015  lahf
000079cbf15d0016  seto al
000079cbf15d0019  mov [r15+0x108], eax
000079cbf15d0020  lea eax, [r11d+r14d*1]
000079cbf15d0025  mov eax, eax
000079cbf15d0027  mov [r15+0xA8], rax
000079cbf15d002e  mov r12d, r12d
000079cbf15d0031  mov [r15+0xB0], r12
000079cbf15d0038  mov eax, [rsp+0x10]
000079cbf15d003c  mov eax, eax
000079cbf15d003e  mov [r15+0xC0], rax
000079cbf15d0045  mov r8d, r8d
000079cbf15d0048  mov [r15+0xC8], r8
000079cbf15d004f  mov eax, [r15+0x108]
000079cbf15d0056  sahf
000079cbf15d0057  jnz 0x000079CBF15D0089
000079cbf15d0059  cmp dword ptr [r15+0x318], 0x00
000079cbf15d0061  jz 0x000079CBF15D0350
000079cbf15d0067  nop [rax+rax*1], ax
000079cbf15d0070  nop [rax+rax*1], eax
000079cbf15d0078  mov eax, 0x41055C
000079cbf15d007d  mov [r15+0x100], rax
000079cbf15d0084  jmp 0x000079CBF13FE110
000079cbf15d0089  cmp dword ptr [r15+0x318], 0x00
000079cbf15d0091  jz 0x000079CBF15D0120
000079cbf15d0097  nop [rax+rax*1], ax
000079cbf15d00a0  nop [rax+rax*1], eax
000079cbf15d00a8  mov eax, 0x4104D0
000079cbf15d00ad  mov [r15+0x100], rax
000079cbf15d00b4  jmp 0x000079CBF13FE110
000079cbf15d00b9  int3
000079cbf15d00ba  call 0x000079CBF140DAE0
000079cbf15d00bf  jmp 0x000079CBF15CFE28
000079cbf15d00c4  call 0x000079CBF14C0230
000079cbf15d00c9  jmp 0x000079CBF15CFE31
000079cbf15d00ce  call 0x000079CBF14E26A0
000079cbf15d00d3  jmp 0x000079CBF15CFE55
000079cbf15d00d8  call 0x000079CBF14E1430
000079cbf15d00dd  jmp 0x000079CBF15CFE5E
000079cbf15d00e2  call 0x000079CBF14E26A0
000079cbf15d00e7  jmp 0x000079CBF15CFE7F
000079cbf15d00ec  call 0x000079CBF14E1430
000079cbf15d00f1  jmp 0x000079CBF15CFE88
000079cbf15d00f6  call 0x000079CBF14E26A0
000079cbf15d00fb  jmp 0x000079CBF15CFEA9
000079cbf15d0100  call 0x000079CBF14D5890
000079cbf15d0105  jmp 0x000079CBF15CFEB2
000079cbf15d010a  call 0x000079CBF14BDD50
000079cbf15d010f  jmp 0x000079CBF15CFF48
000079cbf15d0114  call 0x000079CBF14DA580
000079cbf15d0119  jmp 0x000079CBF15CFF7F
000079cbf15d011e  int3
000079cbf15d011f  nop
000079cbf15d0120  mov eax, [r15+0xB8]
000079cbf15d0127  mov [rsp+0x10], eax
000079cbf15d012b  mov eax, eax
000079cbf15d012d  mov [r15+0x30], rax
000079cbf15d0131  mov eax, [r15+0xC0]
000079cbf15d0138  mov [rsp+0x20], eax
000079cbf15d013c  mov eax, eax
000079cbf15d013e  mov [r15+0xA0], rax
000079cbf15d0145  mov eax, [r15+0x28]
000079cbf15d0149  mov r14d, [r15+0x98]
000079cbf15d0150  mov [rsp+0x30], r14d
000079cbf15d0155  mov r14d, r14d
000079cbf15d0158  mov [r15+0x28], r14
000079cbf15d015c  mov r14d, [r15+0x38]
000079cbf15d0160  mov [rsp+0x40], r14d
000079cbf15d0165  mov r14d, r14d
000079cbf15d0168  mov [r15+0x98], r14
000079cbf15d016f  mov r14d, [r15+0xA8]
000079cbf15d0176  mov [rsp+0x50], r14d
000079cbf15d017b  mov r14d, r14d
000079cbf15d017e  mov [r15+0x38], r14
000079cbf15d0182  mov r14d, [rsp+0x10]
000079cbf15d0187  mov r12d, [rsp+0x10]
000079cbf15d018c  shrd r14d, r12d, 0x06
000079cbf15d0191  mov r11d, [r15+0xC8]
000079cbf15d0198  mov [rsp+0x10], r12d
000079cbf15d019d  and r12d, r11d
000079cbf15d01a0  mov r10d, [rsp+0x50]
000079cbf15d01a5  mov r9d, [rsp+0x50]
000079cbf15d01aa  shrd r10d, r9d, 0x02
000079cbf15d01af  mov [rsp+0x50], r11d
000079cbf15d01b4  mov r11d, r11d
000079cbf15d01b7  mov [r15+0x20], r11
000079cbf15d01bb  mov r11, [r15+0x88]
000079cbf15d01c2  mov r8, [r15+0x50]
000079cbf15d01c6  lea rbp, [r8+r11*1]
000079cbf15d01ca  mov r8d, [r13+rbp*1]
000079cbf15d01cf  mov ebp, [rsp+0x20]
000079cbf15d01d3  mov edi, [rsp+0x10]
000079cbf15d01d7  andn esi, edi, ebp
000079cbf15d01dc  mov edx, [r15+0xB0]
000079cbf15d01e3  lea ecx, [r12d+edx*1]
000079cbf15d01e8  rorx r12d, edi, 0x0B
000079cbf15d01ee  xor r14d, r12d
000079cbf15d01f1  rorx r12d, r9d, 0x0D
000079cbf15d01f7  xor r10d, r12d
000079cbf15d01fa  lea r12d, [ecx+esi*1]
000079cbf15d01ff  mov rsi, [r15+0x48]
000079cbf15d0203  lea rdx, [rsi+r11*1]
000079cbf15d0207  mov esi, [r13+rdx*1]
000079cbf15d020c  mov edx, [rsp+0x30]
000079cbf15d0210  mov ecx, [rsp+0x40]
000079cbf15d0214  and edx, ecx
000079cbf15d0216  mov [rsp+0x10], edx
000079cbf15d021a  mov edx, edx
000079cbf15d021c  mov [r15+0xD8], rdx
000079cbf15d0223  lea edx, [r12d+r8d*1]
000079cbf15d0228  mov r12d, [rsp+0x30]
000079cbf15d022d  xor r12d, ecx
000079cbf15d0230  rorx r8d, edi, 0x19
000079cbf15d0236  xor r14d, r8d
000079cbf15d0239  and r12d, r9d
000079cbf15d023c  rorx r8d, r9d, 0x16
000079cbf15d0242  xor r10d, r8d
000079cbf15d0245  mov [rsp+0x20], r10d
000079cbf15d024a  mov r10d, r10d
000079cbf15d024d  mov [r15+0xD0], r10
000079cbf15d0254  lea r10d, [edx+esi*1]
000079cbf15d0259  mov r9d, [rsp+0x10]
000079cbf15d025e  xor r12d, r9d
000079cbf15d0261  lea r9d, [r10d+r14d*1]
000079cbf15d0266  lea r14, [r11+0x04]
000079cbf15d026a  mov [r15+0x88], r14
000079cbf15d0271  mov r11d, [rsp+0x20]
000079cbf15d0276  lea r10d, [r12d+r11d*1]
000079cbf15d027b  lea r11d, [r9d+eax*1]
000079cbf15d0280  mov r11d, r11d
000079cbf15d0283  mov [r15+0xB8], r11
000079cbf15d028a  xor eax, eax
000079cbf15d028c  mov r12d, 0x100
000079cbf15d0292  cmp r14, r12
000079cbf15d0295  cmc
000079cbf15d0296  lahf
000079cbf15d0297  seto al
000079cbf15d029a  mov [r15+0x108], eax
000079cbf15d02a1  lea eax, [r10d+r9d*1]
000079cbf15d02a6  mov eax, eax
000079cbf15d02a8  mov [r15+0xA8], rax
000079cbf15d02af  mov ebp, ebp
000079cbf15d02b1  mov [r15+0xB0], rbp
000079cbf15d02b8  mov eax, [rsp+0x50]
000079cbf15d02bc  mov eax, eax
000079cbf15d02be  mov [r15+0xC0], rax
000079cbf15d02c5  mov edi, edi
000079cbf15d02c7  mov [r15+0xC8], rdi
000079cbf15d02ce  mov eax, [r15+0x108]
000079cbf15d02d5  sahf
000079cbf15d02d6  jnz 0x000079CBF15D0308
000079cbf15d02d8  cmp dword ptr [r15+0x318], 0x00
000079cbf15d02e0  jz 0x000079CBF15D0350
000079cbf15d02e6  nop [rax+rax*1], ax
000079cbf15d02ef  nop [rax+rax*1], eax
000079cbf15d02f7  mov eax, 0x41055C
000079cbf15d02fc  mov [r15+0x100], rax
000079cbf15d0303  jmp 0x000079CBF13FE110
000079cbf15d0308  cmp dword ptr [r15+0x318], 0x00
000079cbf15d0310  jz 0x000079CBF15D0120
000079cbf15d0316  nop [rax+rax*1], ax
000079cbf15d031f  nop [rax+rax*1], eax
000079cbf15d0327  mov eax, 0x4104D0
000079cbf15d032c  mov [r15+0x100], rax
000079cbf15d0333  jmp 0x000079CBF13FE110
000079cbf15d0338  int3
000079cbf15d0339  call 0x000079CBF1449010
000079cbf15d033e  jmp 0x000079CBF15D01CF
000079cbf15d0343  call 0x000079CBF1425930
000079cbf15d0348  jmp 0x000079CBF15D020C
000079cbf15d034d  int3
000079cbf15d034e  nop
000079cbf15d0350  mov eax, [r15+0x98]
000079cbf15d0357  mov r14d, [r15+0x70]
000079cbf15d035b  lea r12d, [eax+r14d*1]
000079cbf15d0360  mov eax, [r15+0x28]
000079cbf15d0364  mov r14d, [r15+0x68]
000079cbf15d0368  lea r11d, [eax+r14d*1]
000079cbf15d036d  mov qword ptr [r15+0x88], 0x00
000079cbf15d0378  mov eax, [r15+0xA8]
000079cbf15d037f  mov r14d, [r15+0x78]
000079cbf15d0383  lea r10d, [eax+r14d*1]
000079cbf15d0388  mov [rsp+0x10], r10d
000079cbf15d038d  mov r10d, r10d
000079cbf15d0390  mov [r15+0x78], r10
000079cbf15d0394  mov eax, [r15+0x38]
000079cbf15d0398  mov r14d, [r15+0x80]
000079cbf15d039f  lea r10d, [eax+r14d*1]
000079cbf15d03a4  mov [rsp+0x20], r10d
000079cbf15d03a9  mov r10d, r10d
000079cbf15d03ac  mov [r15+0x80], r10
000079cbf15d03b3  mov rax, [r15]
000079cbf15d03b6  lea r14, [rax+0x08]
000079cbf15d03ba  mov [r13+r14*1], r12d
000079cbf15d03bf  lea r14, [rax+0x0C]
000079cbf15d03c3  mov [r13+r14*1], r11d
000079cbf15d03c8  mov r14d, [r15+0xB8]
000079cbf15d03cf  mov r12d, [r15+0x18]
000079cbf15d03d3  lea r11d, [r14d+r12d*1]
000079cbf15d03d8  mov [rsp+0x30], r11d
000079cbf15d03dd  mov r11d, r11d
000079cbf15d03e0  mov [r15+0x68], r11
000079cbf15d03e4  mov r14d, [r15+0x30]
000079cbf15d03e8  mov r12d, [r15+0x90]
000079cbf15d03ef  lea r11d, [r14d+r12d*1]
000079cbf15d03f4  mov [rsp+0x40], r11d
000079cbf15d03f9  mov r11d, r11d
000079cbf15d03fc  mov [r15+0x70], r11
000079cbf15d0400  mov r14d, [r15+0x20]
000079cbf15d0404  mov r12d, [r15+0x58]
000079cbf15d0408  lea r11d, [r14d+r12d*1]
000079cbf15d040d  mov [rsp+0x50], r11d
000079cbf15d0412  mov r11d, r11d
000079cbf15d0415  mov [r15+0x58], r11
000079cbf15d0419  mov r14d, [r15+0xA0]
000079cbf15d0420  mov r12d, [r15+0x60]
000079cbf15d0424  lea r11d, [r14d+r12d*1]
000079cbf15d0429  mov [rsp+0x60], r11d
000079cbf15d042e  mov r11d, r11d
000079cbf15d0431  mov [r15+0x60], r11
000079cbf15d0435  mov r14d, [rsp+0x10]
000079cbf15d043a  mov [r13+rax*1], r14d
000079cbf15d043f  lea r14, [rax+0x04]
000079cbf15d0443  mov r12d, [rsp+0x20]
000079cbf15d0448  mov [r13+r14*1], r12d
000079cbf15d044d  lea r14, [rax+0x10]
000079cbf15d0451  mov r12d, [rsp+0x30]
000079cbf15d0456  mov [r13+r14*1], r12d
000079cbf15d045b  lea r14, [rax+0x14]
000079cbf15d045f  mov r12d, [rsp+0x40]
000079cbf15d0464  mov [r13+r14*1], r12d
000079cbf15d0469  lea r14, [rax+0x18]
000079cbf15d046d  mov r12d, [rsp+0x50]
000079cbf15d0472  mov [r13+r14*1], r12d
000079cbf15d0477  lea r14, [rax+0x1C]
000079cbf15d047b  mov r12d, [rsp+0x60]
000079cbf15d0480  mov [r13+r14*1], r12d
000079cbf15d0485  lea r14, [rax+0x68]
000079cbf15d0489  xor eax, eax
000079cbf15d048b  mov [r13+r14*1], rax
000079cbf15d0490  cmp dword ptr [r15+0x318], 0x00
000079cbf15d0498  jz 0x000079CBF15CEF90
000079cbf15d049e  nop [rax+rax*1], ax
000079cbf15d04a7  nop [rax+rax*1], eax
000079cbf15d04af  mov eax, 0x410378
000079cbf15d04b4  mov [r15+0x100], rax
000079cbf15d04bb  jmp 0x000079CBF13FE110
000079cbf15d04c0  int3
000079cbf15d04c1  call 0x000079CBF14E2BA0
000079cbf15d04c6  jmp 0x000079CBF15D03BF
000079cbf15d04cb  call 0x000079CBF14E1920
000079cbf15d04d0  jmp 0x000079CBF15D03C8
000079cbf15d04d5  call 0x000079CBF140DFE0
000079cbf15d04da  jmp 0x000079CBF15D043F
000079cbf15d04df  call 0x000079CBF14E2BA0
000079cbf15d04e4  jmp 0x000079CBF15D044D
000079cbf15d04e9  call 0x000079CBF14E2BA0
000079cbf15d04ee  jmp 0x000079CBF15D045B
000079cbf15d04f3  call 0x000079CBF14E2BA0
000079cbf15d04f8  jmp 0x000079CBF15D0469
000079cbf15d04fd  call 0x000079CBF14E2BA0
000079cbf15d0502  jmp 0x000079CBF15D0477
000079cbf15d0507  call 0x000079CBF14E2BA0
000079cbf15d050c  jmp 0x000079CBF15D0485
000079cbf15d0511  call 0x000079CBF14D5EB0
000079cbf15d0516  jmp 0x000079CBF15D0490
000079cbf15d051b  int3
000079cbf15d051c  nop [rax], eax
000079cbf15d0520  mov rax, [r15+0xF8]
000079cbf15d0527  lea r14, [rax+0x140]
000079cbf15d052e  mov r12, [r13+r14*1]
000079cbf15d0533  lea r14, [rax+0x148]
000079cbf15d053a  mov r11, [r13+r14*1]
000079cbf15d053f  mov [r15+0xA0], r12
000079cbf15d0546  mov [r15+0x98], r11
000079cbf15d054d  lea r14, [rax+0x130]
000079cbf15d0554  mov r12, [r13+r14*1]
000079cbf15d0559  lea r14, [rax+0x138]
000079cbf15d0560  mov r11, [r13+r14*1]
000079cbf15d0565  mov [r15+0xB0], r12
000079cbf15d056c  mov [r15+0xA8], r11
000079cbf15d0573  lea r14, [rax+0x120]
000079cbf15d057a  mov r12, [r13+r14*1]
000079cbf15d057f  lea r14, [rax+0x128]
000079cbf15d0586  mov r11, [r13+r14*1]
000079cbf15d058b  mov [r15+0xC0], r12
000079cbf15d0592  mov [r15+0xB8], r11
000079cbf15d0599  lea r14, [rax+0x110]
000079cbf15d05a0  mov r12, [r13+r14*1]
000079cbf15d05a5  lea r14, [rax+0x118]
000079cbf15d05ac  mov r11, [r13+r14*1]
000079cbf15d05b1  mov [r15+0xD0], r12
000079cbf15d05b8  mov [r15+0xC8], r11
000079cbf15d05bf  lea r14, [rax+0x100]
000079cbf15d05c6  mov r12, [r13+r14*1]
000079cbf15d05cb  lea r14, [rax+0x108]
000079cbf15d05d2  mov r11, [r13+r14*1]
000079cbf15d05d7  mov [r15+0xE8], r12
000079cbf15d05de  mov [r15+0xD8], r11
000079cbf15d05e5  lea r14, [rax+0x150]
000079cbf15d05ec  mov [r15+0xF8], r14
000079cbf15d05f3  mov rax, [r15+0xF0]
000079cbf15d05fa  mov [r15+0x100], rax
000079cbf15d0601  jmp 0x000079CBF15CE5C0
000079cbf15d0606  int3
000079cbf15d0607  call 0x000079CBF14E27E0
000079cbf15d060c  jmp 0x000079CBF15D0533
000079cbf15d0611  call 0x000079CBF14E1570
000079cbf15d0616  jmp 0x000079CBF15D053F
000079cbf15d061b  call 0x000079CBF14E27E0
000079cbf15d0620  jmp 0x000079CBF15D0559
000079cbf15d0625  call 0x000079CBF14E1570
000079cbf15d062a  jmp 0x000079CBF15D0565
000079cbf15d062f  call 0x000079CBF14E27E0
000079cbf15d0634  jmp 0x000079CBF15D057F
000079cbf15d0639  call 0x000079CBF14E1570
000079cbf15d063e  jmp 0x000079CBF15D058B
000079cbf15d0643  call 0x000079CBF14E27E0
000079cbf15d0648  jmp 0x000079CBF15D05A5
000079cbf15d064d  call 0x000079CBF14E1570
000079cbf15d0652  jmp 0x000079CBF15D05B1
000079cbf15d0657  call 0x000079CBF14E27E0
000079cbf15d065c  jmp 0x000079CBF15D05CB
000079cbf15d0661  call 0x000079CBF14E1570
000079cbf15d0666  jmp 0x000079CBF15D05D7
000079cbf15d066b  int3
000079cbf15d066c  nop [rax], eax
000079cbf15d0670  mov eax, [r15+0xA0]
000079cbf15d0677  mov [rsp+0x10], eax
000079cbf15d067b  xor eax, eax
000079cbf15d067d  mov r14d, [rsp+0x10]
000079cbf15d0682  sub r14d, 0x01
000079cbf15d0686  cmc
000079cbf15d0687  lahf
000079cbf15d0688  seto al
000079cbf15d068b  mov [r15+0x108], eax
000079cbf15d0692  mov r14d, r14d
000079cbf15d0695  mov [r15+0xA0], r14
000079cbf15d069c  mov eax, [r15+0x108]
000079cbf15d06a3  sahf
000079cbf15d06a4  jnz 0x000079CBF15D06D6
000079cbf15d06a6  cmp dword ptr [r15+0x318], 0x00
000079cbf15d06ae  jz 0x000079CBF15D07A0
000079cbf15d06b4  nop [rax+rax*1], ax
000079cbf15d06bd  nop [rax+rax*1], eax
000079cbf15d06c5  mov eax, 0x41027C
000079cbf15d06ca  mov [r15+0x100], rax
000079cbf15d06d1  jmp 0x000079CBF13FE110
000079cbf15d06d6  cmp dword ptr [r15+0x318], 0x00
000079cbf15d06de  jz 0x000079CBF15D0710
000079cbf15d06e4  nop [rax+rax*1], ax
000079cbf15d06ed  nop [rax+rax*1], eax
000079cbf15d06f5  mov eax, 0x410264
000079cbf15d06fa  mov [r15+0x100], rax
000079cbf15d0701  jmp 0x000079CBF13FE110
000079cbf15d0706  int3
000079cbf15d0707  int3
000079cbf15d0708  nop [rax+rax*1], eax
000079cbf15d0710  mov rax, [r15+0xF8]
000079cbf15d0717  mov [r15], rax
000079cbf15d071a  mov rax, [r15+0x98]
000079cbf15d0721  mov [r15+0x08], rax
000079cbf15d0725  mov qword ptr [r15+0x10], 0x12C
000079cbf15d072d  mov qword ptr [r15+0xF0], 0x410274
000079cbf15d0738  mov r14d, [r15+0x320]
000079cbf15d073f  mov eax, 0x410274
000079cbf15d0744  mov rcx, 0x79CBF15D0670
000079cbf15d074e  mov [r15+r14*8+0x328], rax
000079cbf15d0756  mov [r15+r14*8+0x368], rcx
000079cbf15d075e  add r14d, 0x01
000079cbf15d0762  and r14d, 0x07
000079cbf15d0766  mov [r15+0x320], r14d
000079cbf15d076d  cmp dword ptr [r15+0x318], 0x00
000079cbf15d0775  jz 0x000079CBF15CEC20
000079cbf15d077b  nop [rax+rax*1], ax
000079cbf15d0784  nop [rax+rax*1], eax
000079cbf15d078c  mov eax, 0x410338
000079cbf15d0791  mov [r15+0x100], rax
000079cbf15d0798  jmp 0x000079CBF13FE110
000079cbf15d079d  int3
000079cbf15d079e  int3
000079cbf15d079f  nop
000079cbf15d07a0  mov rax, [r15+0xF8]
000079cbf15d07a7  lea r14, [rax+0x20]
000079cbf15d07ab  mov r12, [r13+r14*1]
000079cbf15d07b0  mov [r15+0x98], r12
000079cbf15d07b7  mov qword ptr [r15+0x40], 0x80
000079cbf15d07bf  mov [r15], rax
000079cbf15d07c2  lea r14, [rax+0x8C]
000079cbf15d07c9  mov [r15+0x08], r14
000079cbf15d07cd  mov qword ptr [r15+0x10], 0x01
000079cbf15d07d5  lea r14, [rax+0x8C]
000079cbf15d07dc  mov eax, 0x80
000079cbf15d07e1  mov [r13+r14*1], al
000079cbf15d07e6  mov qword ptr [r15+0xF0], 0x410298
000079cbf15d07f1  mov r14d, [r15+0x320]
000079cbf15d07f8  mov eax, 0x410298
000079cbf15d07fd  mov rcx, 0x79CBF15D0870
000079cbf15d0807  mov [r15+r14*8+0x328], rax
000079cbf15d080f  mov [r15+r14*8+0x368], rcx
000079cbf15d0817  add r14d, 0x01
000079cbf15d081b  and r14d, 0x07
000079cbf15d081f  mov [r15+0x320], r14d
000079cbf15d0826  cmp dword ptr [r15+0x318], 0x00
000079cbf15d082e  jz 0x000079CBF15CEC20
000079cbf15d0834  nop [rax+rax*1], ax
000079cbf15d083d  nop [rax+rax*1], eax
000079cbf15d0845  mov eax, 0x410338
000079cbf15d084a  mov [r15+0x100], rax
000079cbf15d0851  jmp 0x000079CBF13FE110
000079cbf15d0856  int3
000079cbf15d0857  call 0x000079CBF14E27E0
000079cbf15d085c  jmp 0x000079CBF15D07B0
000079cbf15d0861  call 0x000079CBF14D5AF0
000079cbf15d0866  jmp 0x000079CBF15D07E6
000079cbf15d086b  int3
000079cbf15d086c  nop [rax], eax
000079cbf15d0870  mov rax, [r15+0xF8]
000079cbf15d0877  lea r14, [rax+0x68]
000079cbf15d087b  mov r12, [r13+r14*1]
000079cbf15d0880  mov [r15+0x40], r12
000079cbf15d0884  lea r14, [rax+0x88]
000079cbf15d088b  xor eax, eax
000079cbf15d088d  mov [r13+r14*1], al
000079cbf15d0892  xor eax, eax
000079cbf15d0894  mov r14d, 0x38
000079cbf15d089a  cmp r12, r14
000079cbf15d089d  cmc
000079cbf15d089e  lahf
000079cbf15d089f  seto al
000079cbf15d08a2  mov [r15+0x108], eax
000079cbf15d08a9  mov eax, [r15+0x108]
000079cbf15d08b0  sahf
000079cbf15d08b1  jz 0x000079CBF15D08E3
000079cbf15d08b3  cmp dword ptr [r15+0x318], 0x00
000079cbf15d08bb  jz 0x000079CBF15D0930
000079cbf15d08c1  nop [rax+rax*1], ax
000079cbf15d08ca  nop [rax+rax*1], eax
000079cbf15d08d2  mov eax, 0x4102A8
000079cbf15d08d7  mov [r15+0x100], rax
000079cbf15d08de  jmp 0x000079CBF13FE110
000079cbf15d08e3  cmp dword ptr [r15+0x318], 0x00
000079cbf15d08eb  jz 0x000079CBF15D0A70
000079cbf15d08f1  nop [rax+rax*1], ax
000079cbf15d08fa  nop [rax+rax*1], eax
000079cbf15d0902  mov eax, 0x4102C4
000079cbf15d0907  mov [r15+0x100], rax
000079cbf15d090e  jmp 0x000079CBF13FE110
000079cbf15d0913  int3
000079cbf15d0914  call 0x000079CBF14E27E0
000079cbf15d0919  jmp 0x000079CBF15D0880
000079cbf15d091e  call 0x000079CBF14D5AF0
000079cbf15d0923  jmp 0x000079CBF15D0892
000079cbf15d0928  int3
000079cbf15d0929  nop [rax], eax
000079cbf15d0930  mov rax, [r15+0xF8]
000079cbf15d0937  mov [r15], rax
000079cbf15d093a  lea r14, [rax+0x88]
000079cbf15d0941  mov [r15+0x08], r14
000079cbf15d0945  mov qword ptr [r15+0x10], 0x01
000079cbf15d094d  mov qword ptr [r15+0xF0], 0x4102B8
000079cbf15d0958  mov r14d, [r15+0x320]
000079cbf15d095f  mov eax, 0x4102B8
000079cbf15d0964  mov rcx, 0x79CBF15D09C0
000079cbf15d096e  mov [r15+r14*8+0x328], rax
000079cbf15d0976  mov [r15+r14*8+0x368], rcx
000079cbf15d097e  add r14d, 0x01
000079cbf15d0982  and r14d, 0x07
000079cbf15d0986  mov [r15+0x320], r14d
000079cbf15d098d  cmp dword ptr [r15+0x318], 0x00
000079cbf15d0995  jz 0x000079CBF15CEC20
000079cbf15d099b  nop [rax+rax*1], ax
000079cbf15d09a4  nop [rax+rax*1], eax
000079cbf15d09ac  mov eax, 0x410338
000079cbf15d09b1  mov [r15+0x100], rax
000079cbf15d09b8  jmp 0x000079CBF13FE110
000079cbf15d09bd  int3
000079cbf15d09be  int3
000079cbf15d09bf  nop
000079cbf15d09c0  mov rax, [r15+0xF8]
000079cbf15d09c7  lea r14, [rax+0x68]
000079cbf15d09cb  mov rax, [r13+r14*1]
000079cbf15d09d0  mov [r15+0x40], rax
000079cbf15d09d4  mov [rsp+0x10], rax
000079cbf15d09d9  xor eax, eax
000079cbf15d09db  mov r14, [rsp+0x10]
000079cbf15d09e0  mov r12d, 0x38
000079cbf15d09e6  cmp r14, r12
000079cbf15d09e9  cmc
000079cbf15d09ea  lahf
000079cbf15d09eb  seto al
000079cbf15d09ee  mov [r15+0x108], eax
000079cbf15d09f5  mov eax, [r15+0x108]
000079cbf15d09fc  sahf
000079cbf15d09fd  jnz 0x000079CBF15D0A2F
000079cbf15d09ff  cmp dword ptr [r15+0x318], 0x00
000079cbf15d0a07  jz 0x000079CBF15D0A70
000079cbf15d0a0d  nop [rax+rax*1], ax
000079cbf15d0a16  nop [rax+rax*1], eax
000079cbf15d0a1e  mov eax, 0x4102C4
000079cbf15d0a23  mov [r15+0x100], rax
000079cbf15d0a2a  jmp 0x000079CBF13FE110
000079cbf15d0a2f  cmp dword ptr [r15+0x318], 0x00
000079cbf15d0a37  jz 0x000079CBF15D0930
000079cbf15d0a3d  nop [rax+rax*1], ax
000079cbf15d0a46  nop [rax+rax*1], eax
000079cbf15d0a4e  mov eax, 0x4102A8
000079cbf15d0a53  mov [r15+0x100], rax
000079cbf15d0a5a  jmp 0x000079CBF13FE110
000079cbf15d0a5f  int3
000079cbf15d0a60  call 0x000079CBF14D59C0
000079cbf15d0a65  jmp 0x000079CBF15D09D0
000079cbf15d0a6a  int3
000079cbf15d0a6b  nop [rax+rax*1], eax
000079cbf15d0a70  mov rax, [r15+0x98]
000079cbf15d0a77  rorx r14, rax, 0x3D
000079cbf15d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
000079cbf15d0a81  mov rax, [r15+0xF8]
000079cbf15d0a88  mov [r15], rax
000079cbf15d0a8b  lea r12, [rax+0x78]
000079cbf15d0a8f  mov [r15+0x08], r12
000079cbf15d0a93  mov qword ptr [r15+0x10], 0x08
000079cbf15d0a9b  bswap r14
000079cbf15d0a9e  mov [r15+0x40], r14
000079cbf15d0aa2  lea r12, [rax+0x78]
000079cbf15d0aa6  mov [r13+r12*1], r14
000079cbf15d0aab  mov qword ptr [r15+0xF0], 0x4102E0
000079cbf15d0ab6  mov r14d, [r15+0x320]
000079cbf15d0abd  mov eax, 0x4102E0
000079cbf15d0ac2  mov rcx, 0x79CBF15D0B30
000079cbf15d0acc  mov [r15+r14*8+0x328], rax
000079cbf15d0ad4  mov [r15+r14*8+0x368], rcx
000079cbf15d0adc  add r14d, 0x01
000079cbf15d0ae0  and r14d, 0x07
000079cbf15d0ae4  mov [r15+0x320], r14d
000079cbf15d0aeb  cmp dword ptr [r15+0x318], 0x00
000079cbf15d0af3  jz 0x000079CBF15CEC20
000079cbf15d0af9  nop [rax+rax*1], ax
000079cbf15d0b02  nop [rax+rax*1], eax
000079cbf15d0b0a  mov eax, 0x410338
000079cbf15d0b0f  mov [r15+0x100], rax
000079cbf15d0b16  jmp 0x000079CBF13FE110
000079cbf15d0b1b  int3
000079cbf15d0b1c  call 0x000079CBF14C3FE0
000079cbf15d0b21  jmp 0x000079CBF15D0AAB
000079cbf15d0b26  int3
000079cbf15d0b27  nop [rax+rax*1], ax
000079cbf15d0b30  mov rax, [r15+0xF8]
000079cbf15d0b37  mov r14d, [r13+rax*1]
000079cbf15d0b3c  lea r12, [rax+0x04]
000079cbf15d0b40  mov r11d, [r13+r12*1]
000079cbf15d0b45  lea r12, [rax+0x08]
000079cbf15d0b49  mov r10d, [r13+r12*1]
000079cbf15d0b4e  lea r12, [rax+0x0C]
000079cbf15d0b52  mov r9d, [r13+r12*1]
000079cbf15d0b57  mov qword ptr [r15+0x48], 0x430860
000079cbf15d0b5f  lea r12, [rax+0x80]
000079cbf15d0b66  mov r8, [r13+r12*1]
000079cbf15d0b6b  mov [r15+0xF0], r8
000079cbf15d0b72  bswap r14d
000079cbf15d0b75  bswap r11d
000079cbf15d0b78  mov r12d, 0x430860
000079cbf15d0b7e  mov [r13+r12*1], r14d
000079cbf15d0b83  mov r14d, 0x430864
000079cbf15d0b89  mov [r13+r14*1], r11d
000079cbf15d0b8e  bswap r10d
000079cbf15d0b91  bswap r9d
000079cbf15d0b94  lea r14, [rax+0x10]
000079cbf15d0b98  mov r12d, [r13+r14*1]
000079cbf15d0b9d  lea r14, [rax+0x14]
000079cbf15d0ba1  mov r11d, [r13+r14*1]
000079cbf15d0ba6  mov r14d, 0x430868
000079cbf15d0bac  mov [r13+r14*1], r10d
000079cbf15d0bb1  mov r14d, 0x43086C
000079cbf15d0bb7  mov [r13+r14*1], r9d
000079cbf15d0bbc  lea r14, [rax+0x90]
000079cbf15d0bc3  mov r10, [r13+r14*1]
000079cbf15d0bc8  lea r14, [rax+0x98]
000079cbf15d0bcf  mov r9, [r13+r14*1]
000079cbf15d0bd4  mov [r15+0xA0], r10
000079cbf15d0bdb  mov [r15+0x98], r9
000079cbf15d0be2  bswap r12d
000079cbf15d0be5  bswap r11d
000079cbf15d0be8  mov [rsp+0x10], r11d
000079cbf15d0bed  mov r11d, r11d
000079cbf15d0bf0  mov [r15+0x58], r11
000079cbf15d0bf4  lea r14, [rax+0x18]
000079cbf15d0bf8  mov r11d, [r13+r14*1]
000079cbf15d0bfd  lea r14, [rax+0x1C]
000079cbf15d0c01  mov r10d, [r13+r14*1]
000079cbf15d0c06  mov [rsp+0x20], r10d
000079cbf15d0c0b  mov r10d, r10d
000079cbf15d0c0e  mov [r15+0x60], r10
000079cbf15d0c12  mov r14d, 0x430870
000079cbf15d0c18  mov [r13+r14*1], r12d
000079cbf15d0c1d  mov r14d, 0x430874
000079cbf15d0c23  mov r12d, [rsp+0x10]
000079cbf15d0c28  mov [r13+r14*1], r12d
000079cbf15d0c2d  bswap r11d
000079cbf15d0c30  mov [rsp+0x10], r11d
000079cbf15d0c35  mov r11d, r11d
000079cbf15d0c38  mov [r15+0x40], r11
000079cbf15d0c3c  mov r14d, [rsp+0x20]
000079cbf15d0c41  bswap r14d
000079cbf15d0c44  mov [rsp+0x20], r14d
000079cbf15d0c49  mov r14d, r14d
000079cbf15d0c4c  mov [r15+0x50], r14
000079cbf15d0c50  mov r14d, 0x430878
000079cbf15d0c56  mov r12d, [rsp+0x10]
000079cbf15d0c5b  mov [r13+r14*1], r12d
000079cbf15d0c60  mov r14d, 0x43087C
000079cbf15d0c66  mov r12d, [rsp+0x20]
000079cbf15d0c6b  mov [r13+r14*1], r12d
000079cbf15d0c70  lea r14, [rax+0xA0]
000079cbf15d0c77  mov [r15+0xF8], r14
000079cbf15d0c7e  mov [r15+0x100], r8
000079cbf15d0c85  jmp 0x000079CBF15CE5C0
000079cbf15d0c8a  int3
000079cbf15d0c8b  call 0x000079CBF140DAE0
000079cbf15d0c90  jmp 0x000079CBF15D0B3C
000079cbf15d0c95  call 0x000079CBF14C0230
000079cbf15d0c9a  jmp 0x000079CBF15D0B45
000079cbf15d0c9f  call 0x000079CBF14BEFC0
000079cbf15d0ca4  jmp 0x000079CBF15D0B4E
000079cbf15d0ca9  call 0x000079CBF14BDD50
000079cbf15d0cae  jmp 0x000079CBF15D0B57
000079cbf15d0cb3  call 0x000079CBF14BCC20
000079cbf15d0cb8  jmp 0x000079CBF15D0B6B
000079cbf15d0cbd  call 0x000079CBF14C3EA0
000079cbf15d0cc2  jmp 0x000079CBF15D0B83
000079cbf15d0cc7  call 0x000079CBF14E1920
000079cbf15d0ccc  jmp 0x000079CBF15D0B8E
000079cbf15d0cd1  call 0x000079CBF14E26A0
000079cbf15d0cd6  jmp 0x000079CBF15D0B9D
000079cbf15d0cdb  call 0x000079CBF14E1430
000079cbf15d0ce0  jmp 0x000079CBF15D0BA6
000079cbf15d0ce5  call 0x000079CBF14E06B0
000079cbf15d0cea  jmp 0x000079CBF15D0BB1
000079cbf15d0cef  call 0x000079CBF14DF440
000079cbf15d0cf4  jmp 0x000079CBF15D0BBC
000079cbf15d0cf9  call 0x000079CBF14E0300
000079cbf15d0cfe  jmp 0x000079CBF15D0BC8
000079cbf15d0d03  call 0x000079CBF14DF090
000079cbf15d0d08  jmp 0x000079CBF15D0BD4
000079cbf15d0d0d  call 0x000079CBF14E1430
000079cbf15d0d12  jmp 0x000079CBF15D0BFD
000079cbf15d0d17  call 0x000079CBF14E01C0
000079cbf15d0d1c  jmp 0x000079CBF15D0C06
000079cbf15d0d21  call 0x000079CBF14E2BA0
000079cbf15d0d26  jmp 0x000079CBF15D0C1D
000079cbf15d0d2b  call 0x000079CBF14E2BA0
000079cbf15d0d30  jmp 0x000079CBF15D0C2D
000079cbf15d0d35  call 0x000079CBF14E2BA0
000079cbf15d0d3a  jmp 0x000079CBF15D0C60
000079cbf15d0d3f  call 0x000079CBF14E2BA0
000079cbf15d0d44  jmp 0x000079CBF15D0C70
000079cbf15d0d49  int3
000079cbf15d0d4a  nop [rax+rax*1], ax
000079cbf15d0d50  mov qword ptr [r15+0x100], 0x04
000079cbf15d0d5b  mov esi, 0x00
000079cbf15d0d60  mov edx, 0x09
000079cbf15d0d65  mov rdi, 0x7FFD62A75730
000079cbf15d0d6f  mov rax, 0x589F77EFA970
000079cbf15d0d79  call rax
000079cbf15d0d7b  cmp dword ptr [r15+0x318], 0x00
000079cbf15d0d83  jnz 0x000079CBF13FE110
000079cbf15d0d89  jmp 0x000079CBF13FE0A0
000079cbf15d0d8e  int3
000079cbf15d0d8f  int3
