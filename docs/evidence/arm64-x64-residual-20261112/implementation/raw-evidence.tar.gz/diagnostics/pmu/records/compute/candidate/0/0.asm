
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute/candidate/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xf8]
  18:	sub    r13,0x1e0
  1f:	mov    QWORD PTR [r12+0xf8],r13
  27:	mov    r14d,0x420000
  2d:	mov    QWORD PTR [r12+0x40],r14
  32:	mov    r14d,0x420000
  38:	mov    QWORD PTR [r12+0x48],r14
  3d:	mov    r14,r13
  40:	add    r14,0x1d0
  47:	mov    r15,r14
  4a:	add    r15,0x8
  4e:	mov    rbp,QWORD PTR [r12+0xa0]
  56:	mov    r8,QWORD PTR [r12+0x98]
  5e:	mov    QWORD PTR [r14],rbp
  61:	mov    r14d,0x0
  67:	mov    DWORD PTR [r12+0x32c],r14d
  6f:	mov    QWORD PTR [r15],r8
  72:	mov    r14d,0x420aa0
  78:	movdqu xmm2,XMMWORD PTR [r14]
  7d:	movdqu XMMWORD PTR [r12+0x110],xmm2
  87:	mov    r14d,0x420a30
  8d:	movdqu xmm3,XMMWORD PTR [r14]
  92:	movdqu XMMWORD PTR [r12+0x120],xmm3
  9c:	mov    r14d,0x420ac0
  a2:	movdqu xmm4,XMMWORD PTR [r14]
  a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
  b1:	mov    r14d,0x420a60
  b7:	movdqu xmm5,XMMWORD PTR [r14]
  bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
  c6:	mov    r14d,0x430000
  cc:	mov    rax,r14
  cf:	add    rax,0xcd0
  d5:	mov    QWORD PTR [r12+0x98],rax
  dd:	mov    r15d,0x420ad0
  e3:	movdqu xmm6,XMMWORD PTR [r15]
  e8:	movdqu XMMWORD PTR [r12+0x150],xmm6
  f2:	mov    r15,QWORD PTR [r12+0x98]
  fa:	add    r15,0x10
  fe:	mov    rdi,QWORD PTR [r12+0x98]
 106:	movdqu XMMWORD PTR [rdi],xmm2
 10a:	movdqu XMMWORD PTR [r15],xmm3
 10f:	mov    r15,QWORD PTR [r12+0x98]
 117:	add    r15,0x20
 11b:	mov    rbp,r15
 11e:	add    rbp,0x10
 122:	movdqu XMMWORD PTR [r15],xmm4
 127:	movdqu XMMWORD PTR [rbp+0x0],xmm5
 12c:	mov    r15d,0x420a20
 132:	movdqu xmm4,XMMWORD PTR [r15]
 137:	movdqu XMMWORD PTR [r12+0x130],xmm4
 141:	mov    r15d,0x420a10
 147:	movdqu xmm5,XMMWORD PTR [r15]
 14c:	movdqu XMMWORD PTR [r12+0x140],xmm5
 156:	mov    r15,QWORD PTR [r12+0x98]
 15e:	add    r15,0x100
 165:	mov    rbp,r15
 168:	add    rbp,0x10
 16c:	movdqu XMMWORD PTR [r15],xmm2
 171:	movdqu XMMWORD PTR [rbp+0x0],xmm3
 176:	mov    r15,QWORD PTR [r12+0x98]
 17e:	add    r15,0x40
 182:	mov    rbp,r15
 185:	add    rbp,0x10
 189:	movdqu XMMWORD PTR [r15],xmm6
 18e:	movdqu XMMWORD PTR [rbp+0x0],xmm4
 193:	mov    r15d,0x420a00
 199:	movdqu xmm2,XMMWORD PTR [r15]
 19e:	movdqu XMMWORD PTR [r12+0x130],xmm2
 1a8:	mov    r15d,0x420a70
 1ae:	movdqu xmm3,XMMWORD PTR [r15]
 1b3:	movdqu XMMWORD PTR [r12+0x150],xmm3
 1bd:	mov    r15d,0xf8d3
 1c3:	mov    QWORD PTR [r12+0x48],r15
 1c8:	mov    r15,QWORD PTR [r12+0x98]
 1d0:	add    r15,0x60
 1d4:	mov    rbp,r15
 1d7:	add    rbp,0x10
 1db:	movdqu XMMWORD PTR [r15],xmm5
 1e0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
 1e5:	mov    r15d,0x420a80
 1eb:	movdqu xmm2,XMMWORD PTR [r15]
 1f0:	movdqu XMMWORD PTR [r12+0x130],xmm2
 1fa:	mov    r15d,0x420a50
 200:	movdqu xmm4,XMMWORD PTR [r15]
 205:	movdqu XMMWORD PTR [r12+0x140],xmm4
 20f:	mov    r15d,0xf8d3
 215:	mov    ebp,0x421d
 21a:	and    ebp,0xffff
 220:	mov    rax,r15
 223:	movabs rcx,0xffffffff0000ffff
 22d:	and    rax,rcx
 230:	mov    rdx,rbp
 233:	shl    rdx,0x10
 237:	mov    ecx,0xffff0000
 23c:	and    rdx,rcx
 23f:	or     rax,rdx
 242:	mov    r8d,eax
 245:	mov    QWORD PTR [r12+0x48],r8
 24a:	mov    r15,QWORD PTR [r12+0x98]
 252:	add    r15,0x80
 259:	mov    rbp,r15
 25c:	add    rbp,0x10
 260:	movdqu XMMWORD PTR [r15],xmm3
 265:	movdqu XMMWORD PTR [rbp+0x0],xmm2
 26a:	mov    r15d,0x420af0
 270:	movdqu xmm2,XMMWORD PTR [r15]
 275:	movdqu XMMWORD PTR [r12+0x130],xmm2
 27f:	mov    r15d,0x420b00
 285:	movdqu xmm3,XMMWORD PTR [r15]
 28a:	movdqu XMMWORD PTR [r12+0x150],xmm3
 294:	mov    r15d,0x3e8
 29a:	mov    QWORD PTR [r12+0xa0],r15
 2a2:	mov    r15,QWORD PTR [r12+0x98]
 2aa:	add    r15,0xa0
 2b1:	mov    rbp,r15
 2b4:	add    rbp,0x10
 2b8:	movdqu XMMWORD PTR [r15],xmm4
 2bd:	movdqu XMMWORD PTR [rbp+0x0],xmm2
 2c2:	mov    r15d,0x420ae0
 2c8:	movdqu xmm2,XMMWORD PTR [r15]
 2cd:	movdqu XMMWORD PTR [r12+0x130],xmm2
 2d7:	mov    r15d,0x420a90
 2dd:	movdqu xmm4,XMMWORD PTR [r15]
 2e2:	movdqu XMMWORD PTR [r12+0x140],xmm4
 2ec:	mov    r15,r13
 2ef:	add    r15,0x180
 2f6:	mov    rbp,r15
 2f9:	add    rbp,0x8
 2fd:	mov    r9,QWORD PTR [r12+0x200]
 305:	mov    r14,QWORD PTR [r12+0x1f0]
 30d:	mov    QWORD PTR [r15],r9
 310:	mov    QWORD PTR [rbp+0x0],r14
 314:	mov    r14,QWORD PTR [r12+0x98]
 31c:	add    r14,0xc0
 323:	mov    r15,r14
 326:	add    r15,0x10
 32a:	movdqu XMMWORD PTR [r14],xmm3
 32f:	movdqu XMMWORD PTR [r15],xmm2
 334:	mov    r14d,0x420ab0
 33a:	movdqu xmm2,XMMWORD PTR [r14]
 33f:	movdqu XMMWORD PTR [r12+0x130],xmm2
 349:	mov    r14d,0x420b18
 34f:	mov    r15,QWORD PTR [r14]
 352:	mov    r14d,0x0
 358:	mov    QWORD PTR [r12+0x110],r15
 360:	mov    QWORD PTR [r12+0x118],r14
 368:	mov    r14d,0x420b20
 36e:	mov    QWORD PTR [r12+0x40],r14
 373:	mov    r14,QWORD PTR [r12+0x98]
 37b:	add    r14,0xe0
 382:	mov    rbp,r14
 385:	add    rbp,0x10
 389:	movdqu XMMWORD PTR [r14],xmm4
 38e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
 393:	mov    r14d,0x420b80
 399:	movdqu xmm2,XMMWORD PTR [r14]
 39e:	movdqu XMMWORD PTR [r12+0x130],xmm2
 3a8:	mov    r14,QWORD PTR [r12+0x98]
 3b0:	add    r14,0x120
 3b7:	mov    QWORD PTR [r14],r15
 3ba:	mov    r14d,0x420b60
 3c0:	mov    r15d,0x420b70
 3c6:	movdqu xmm3,XMMWORD PTR [r14]
 3cb:	movdqu xmm4,XMMWORD PTR [r15]
 3d0:	movdqu XMMWORD PTR [r12+0x120],xmm3
 3da:	movdqu XMMWORD PTR [r12+0x110],xmm4
 3e4:	mov    r14,r13
 3e7:	add    r14,0x160
 3ee:	movdqu XMMWORD PTR [r14],xmm2
 3f3:	mov    r14,r13
 3f6:	add    r14,0x190
 3fd:	mov    r15,r14
 400:	add    r15,0x8
 404:	mov    rbp,QWORD PTR [r12+0x1e0]
 40c:	mov    r9,QWORD PTR [r12+0x1d0]
 414:	mov    QWORD PTR [r14],rbp
 417:	mov    QWORD PTR [r15],r9
 41a:	mov    r14,r13
 41d:	add    r14,0x140
 424:	mov    r15,r14
 427:	add    r15,0x10
 42b:	movdqu XMMWORD PTR [r14],xmm3
 430:	movdqu XMMWORD PTR [r15],xmm4
 435:	mov    r14d,0x420b20
 43b:	mov    r15d,0x420b30
 441:	movdqu xmm2,XMMWORD PTR [r14]
 446:	movdqu xmm3,XMMWORD PTR [r15]
 44b:	movdqu XMMWORD PTR [r12+0x110],xmm2
 455:	movdqu XMMWORD PTR [r12+0x120],xmm3
 45f:	mov    r14,r13
 462:	add    r14,0x1a0
 469:	mov    r15,r14
 46c:	add    r15,0x8
 470:	mov    rbp,QWORD PTR [r12+0x1c0]
 478:	mov    r9,QWORD PTR [r12+0x1b0]
 480:	mov    QWORD PTR [r14],rbp
 483:	mov    QWORD PTR [r15],r9
 486:	mov    r14,r13
 489:	add    r14,0x1b0
 490:	mov    r15,r14
 493:	add    r15,0x8
 497:	mov    rbp,QWORD PTR [r12+0x1a0]
 49f:	mov    r9,QWORD PTR [r12+0x190]
 4a7:	mov    QWORD PTR [r14],rbp
 4aa:	mov    QWORD PTR [r15],r9
 4ad:	mov    r14,r13
 4b0:	add    r14,0x100
 4b7:	mov    r15,r14
 4ba:	add    r15,0x10
 4be:	movdqu XMMWORD PTR [r14],xmm2
 4c3:	movdqu XMMWORD PTR [r15],xmm3
 4c8:	mov    r14d,0x420b40
 4ce:	mov    r15d,0x420b50
 4d4:	movdqu xmm2,XMMWORD PTR [r14]
 4d9:	movdqu xmm3,XMMWORD PTR [r15]
 4de:	movdqu XMMWORD PTR [r12+0x110],xmm2
 4e8:	movdqu XMMWORD PTR [r12+0x130],xmm3
 4f2:	mov    r14,r13
 4f5:	add    r14,0x1c0
 4fc:	mov    r15,r14
 4ff:	add    r15,0x8
 503:	mov    rbp,QWORD PTR [r12+0xe8]
 50b:	mov    r9,QWORD PTR [r12+0xf0]
 513:	mov    QWORD PTR [r14],rbp
 516:	mov    QWORD PTR [r15],r9
 519:	mov    r14,QWORD PTR [r12+0x98]
 521:	add    r14,0x128
 528:	mov    DWORD PTR [r14],r8d
 52b:	mov    r14,r13
 52e:	add    r14,0x120
 535:	mov    r15,r14
 538:	add    r15,0x10
 53c:	movdqu XMMWORD PTR [r14],xmm2
 541:	movdqu XMMWORD PTR [r15],xmm3
 546:	add    r13,0x100
 54d:	mov    QWORD PTR [r12],r13
 551:	mov    r13d,0x0
 557:	mov    rcx,QWORD PTR [r12+0x98]
 55f:	or     r13,rcx
 562:	mov    QWORD PTR [r12+0x8],r13
 567:	mov    r13d,0x12c
 56d:	mov    QWORD PTR [r12+0x10],r13
 572:	mov    r13d,0x410284
 578:	mov    QWORD PTR [r12+0xf0],r13
 580:	mov    r13d,0x410728
 586:	mov    QWORD PTR [r12+0x100],r13
 58e:	mov    r11,QWORD PTR [rsp]
 592:	mov    QWORD PTR [r12+0x398],r11
 59a:	mov    edi,0x410728
 59f:	mov    QWORD PTR [r12+0x100],rdi
 5a7:	add    rsp,0x10
 5ab:	nop    DWORD PTR [rax+rax*1+0x0]
 5b0:	jmp    QWORD PTR [rip+0x2]        # 0x5b8
 5b6:	xchg   ax,ax
 5b8:	loopne 0x59f
 5ba:	(bad)
 5bb:	ins    BYTE PTR es:[rdi],dx
 5bc:	or     BYTE PTR [rbx+0x0],bh
 5bf:	add    al,cl
 5c1:	in     eax,0x2f
 5c3:	ins    BYTE PTR es:[rdi],dx
 5c4:	or     BYTE PTR [rbx+0x0],bh
 5c7:	add    BYTE PTR [rcx-0x45],cl
 5ca:	rex stc
 5cc:	sub    BYTE PTR [rbp+0x590d],al
 5d2:	jmp    r11
 5d5:	nop
 5d6:	nop
 5d7:	nop
