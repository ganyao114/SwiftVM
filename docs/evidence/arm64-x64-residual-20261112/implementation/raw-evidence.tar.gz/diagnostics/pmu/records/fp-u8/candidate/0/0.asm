
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/fp-u8/candidate/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x150
   7:	mov    r11,QWORD PTR [r12+0x398]
   f:	mov    QWORD PTR [rsp],r11
  13:	cmp    DWORD PTR [r12+0x310],0x0
  1c:	je     0xa7
  22:	push   rdx
  23:	push   rsi
  24:	push   r10
  26:	push   r11
  28:	mov    rdx,QWORD PTR [rsp+0x20]
  2d:	mov    r10d,edx
  30:	and    r10d,0xc000
  37:	shl    r10d,0x10
  3b:	mov    r11d,edx
  3e:	and    r11d,0x100
  45:	shl    r11d,0x15
  49:	or     r10d,r11d
  4c:	and    edx,0x1
  4f:	shl    edx,0x1c
  52:	or     r10d,edx
  55:	btc    r10,0x1d
  5a:	mov    r11d,0xf0000000
  60:	and    r11,r10
  63:	movabs rsi,0xffffffff0fffffff
  6d:	and    rbx,rsi
  70:	or     rbx,r11
  73:	pop    r11
  75:	pop    r10
  77:	pop    rsi
  78:	pop    rdx
  79:	mov    QWORD PTR [r12+0x108],rbx
  81:	mov    eax,0x410028
  86:	mov    QWORD PTR [r12+0x100],rax
  8e:	add    rsp,0x150
  95:	mov    eax,0x3
  9a:	movabs r11,0x64a495d9eca0
  a4:	jmp    r11
  a7:	mov    r13d,0xe848
  ad:	mov    r14d,0x1
  b3:	and    r14d,0xffff
  ba:	mov    rax,r13
  bd:	movabs rcx,0xffffffff0000ffff
  c7:	and    rax,rcx
  ca:	mov    rdx,r14
  cd:	shl    rdx,0x10
  d1:	mov    ecx,0xffff0000
  d6:	and    rdx,rcx
  d9:	or     rax,rdx
  dc:	mov    r15,rax
  df:	mov    QWORD PTR [r12+0x8],r15
  e4:	mov    r13d,0x420080
  ea:	mov    QWORD PTR [r12+0x20],r13
  ef:	mov    r13d,0x0
  f5:	mov    QWORD PTR [r12],r13
  f9:	mov    r13d,0x0
  ff:	movabs r14,0x3ff0000000000000
 109:	mov    QWORD PTR [r12+0x110],r14
 111:	mov    QWORD PTR [r12+0x118],r13
 119:	mov    r13d,0x0
 11f:	movabs r14,0x3ff8000000000000
 129:	mov    QWORD PTR [r12+0x120],r14
 131:	mov    QWORD PTR [r12+0x128],r13
 139:	jmp    0x13e
 13e:	movdqu xmm2,XMMWORD PTR [r12+0x110]
 148:	movdqu xmm3,XMMWORD PTR [r12+0x120]
 152:	movdqa xmm0,xmm2
 156:	movdqa xmm1,xmm3
 15a:	movq   xmm0,xmm0
 15e:	movq   xmm1,xmm1
 162:	addsd  xmm0,xmm1
 166:	movdqa xmm14,xmm0
 16b:	movdqu xmm15,XMMWORD PTR [rip+0x87c]        # 0x9f0
 174:	pand   xmm14,xmm15
 179:	movdqu xmm15,XMMWORD PTR [rip+0x87e]        # 0xa00
 182:	pcmpeqq xmm14,xmm15
 188:	movdqa xmm15,xmm0
 18d:	cmpunordpd xmm15,xmm0
 193:	por    xmm14,xmm15
 198:	pmovmskb ecx,xmm14
 19d:	jrcxz  0x1a4
 19f:	jmp    0x4a8
 1a4:	movdqa xmm4,xmm0
 1a8:	movdqa xmm0,xmm4
 1ac:	movdqa xmm1,xmm3
 1b0:	movq   xmm0,xmm0
 1b4:	movq   xmm1,xmm1
 1b8:	addsd  xmm0,xmm1
 1bc:	movdqa xmm14,xmm0
 1c1:	movdqu xmm15,XMMWORD PTR [rip+0x826]        # 0x9f0
 1ca:	pand   xmm14,xmm15
 1cf:	movdqu xmm15,XMMWORD PTR [rip+0x828]        # 0xa00
 1d8:	pcmpeqq xmm14,xmm15
 1de:	movdqa xmm15,xmm0
 1e3:	cmpunordpd xmm15,xmm0
 1e9:	por    xmm14,xmm15
 1ee:	pmovmskb ecx,xmm14
 1f3:	jrcxz  0x1fa
 1f5:	jmp    0x4cc
 1fa:	movdqa xmm2,xmm0
 1fe:	movdqa xmm0,xmm2
 202:	movdqa xmm1,xmm3
 206:	movq   xmm0,xmm0
 20a:	movq   xmm1,xmm1
 20e:	addsd  xmm0,xmm1
 212:	movdqa xmm14,xmm0
 217:	movdqu xmm15,XMMWORD PTR [rip+0x7d0]        # 0x9f0
 220:	pand   xmm14,xmm15
 225:	movdqu xmm15,XMMWORD PTR [rip+0x7d2]        # 0xa00
 22e:	pcmpeqq xmm14,xmm15
 234:	movdqa xmm15,xmm0
 239:	cmpunordpd xmm15,xmm0
 23f:	por    xmm14,xmm15
 244:	pmovmskb ecx,xmm14
 249:	jrcxz  0x250
 24b:	jmp    0x4f0
 250:	movdqa xmm4,xmm0
 254:	movdqa xmm0,xmm4
 258:	movdqa xmm1,xmm3
 25c:	movq   xmm0,xmm0
 260:	movq   xmm1,xmm1
 264:	addsd  xmm0,xmm1
 268:	movdqa xmm14,xmm0
 26d:	movdqu xmm15,XMMWORD PTR [rip+0x77a]        # 0x9f0
 276:	pand   xmm14,xmm15
 27b:	movdqu xmm15,XMMWORD PTR [rip+0x77c]        # 0xa00
 284:	pcmpeqq xmm14,xmm15
 28a:	movdqa xmm15,xmm0
 28f:	cmpunordpd xmm15,xmm0
 295:	por    xmm14,xmm15
 29a:	pmovmskb ecx,xmm14
 29f:	jrcxz  0x2a6
 2a1:	jmp    0x514
 2a6:	movdqa xmm2,xmm0
 2aa:	movdqa xmm0,xmm2
 2ae:	movdqa xmm1,xmm3
 2b2:	movq   xmm0,xmm0
 2b6:	movq   xmm1,xmm1
 2ba:	addsd  xmm0,xmm1
 2be:	movdqa xmm14,xmm0
 2c3:	movdqu xmm15,XMMWORD PTR [rip+0x724]        # 0x9f0
 2cc:	pand   xmm14,xmm15
 2d1:	movdqu xmm15,XMMWORD PTR [rip+0x726]        # 0xa00
 2da:	pcmpeqq xmm14,xmm15
 2e0:	movdqa xmm15,xmm0
 2e5:	cmpunordpd xmm15,xmm0
 2eb:	por    xmm14,xmm15
 2f0:	pmovmskb ecx,xmm14
 2f5:	jrcxz  0x2fc
 2f7:	jmp    0x538
 2fc:	movdqa xmm4,xmm0
 300:	movdqa xmm0,xmm4
 304:	movdqa xmm1,xmm3
 308:	movq   xmm0,xmm0
 30c:	movq   xmm1,xmm1
 310:	addsd  xmm0,xmm1
 314:	movdqa xmm14,xmm0
 319:	movdqu xmm15,XMMWORD PTR [rip+0x6ce]        # 0x9f0
 322:	pand   xmm14,xmm15
 327:	movdqu xmm15,XMMWORD PTR [rip+0x6d0]        # 0xa00
 330:	pcmpeqq xmm14,xmm15
 336:	movdqa xmm15,xmm0
 33b:	cmpunordpd xmm15,xmm0
 341:	por    xmm14,xmm15
 346:	pmovmskb ecx,xmm14
 34b:	jrcxz  0x352
 34d:	jmp    0x55c
 352:	movdqa xmm2,xmm0
 356:	movdqa xmm0,xmm2
 35a:	movdqa xmm1,xmm3
 35e:	movq   xmm0,xmm0
 362:	movq   xmm1,xmm1
 366:	addsd  xmm0,xmm1
 36a:	movdqa xmm14,xmm0
 36f:	movdqu xmm15,XMMWORD PTR [rip+0x678]        # 0x9f0
 378:	pand   xmm14,xmm15
 37d:	movdqu xmm15,XMMWORD PTR [rip+0x67a]        # 0xa00
 386:	pcmpeqq xmm14,xmm15
 38c:	movdqa xmm15,xmm0
 391:	cmpunordpd xmm15,xmm0
 397:	por    xmm14,xmm15
 39c:	pmovmskb ecx,xmm14
 3a1:	jrcxz  0x3a8
 3a3:	jmp    0x580
 3a8:	movdqa xmm4,xmm0
 3ac:	movdqa xmm0,xmm4
 3b0:	movdqa xmm1,xmm3
 3b4:	movq   xmm0,xmm0
 3b8:	movq   xmm1,xmm1
 3bc:	addsd  xmm0,xmm1
 3c0:	movdqa xmm14,xmm0
 3c5:	movdqu xmm15,XMMWORD PTR [rip+0x622]        # 0x9f0
 3ce:	pand   xmm14,xmm15
 3d3:	movdqu xmm15,XMMWORD PTR [rip+0x624]        # 0xa00
 3dc:	pcmpeqq xmm14,xmm15
 3e2:	movdqa xmm15,xmm0
 3e7:	cmpunordpd xmm15,xmm0
 3ed:	por    xmm14,xmm15
 3f2:	pmovmskb ecx,xmm14
 3f7:	jrcxz  0x3fe
 3f9:	jmp    0x5a4
 3fe:	movdqa xmm2,xmm0
 402:	movdqu XMMWORD PTR [r12+0x110],xmm2
 40c:	mov    r13,QWORD PTR [r12+0x8]
 411:	sub    r13,0x1
 415:	mov    QWORD PTR [r12+0x8],r13
 41a:	mov    rcx,QWORD PTR [r12+0x380]
 422:	jrcxz  0x429
 424:	jmp    0x76d
 429:	jne    0x13e
 42f:	mov    r11,rax
 432:	lahf
 433:	seto   al
 436:	mov    WORD PTR [rsp],ax
 43a:	mov    rax,r11
 43d:	jmp    0x442
 442:	mov    r13,QWORD PTR [r12+0x20]
 447:	mov    r14,QWORD PTR [r12+0x110]
 44f:	mov    QWORD PTR [r13+0x0],r14
 453:	mov    r13d,0x0
 459:	mov    DWORD PTR [r12+0x32c],r13d
 461:	mov    rcx,QWORD PTR [r12+0x380]
 469:	jrcxz  0x470
 46b:	jmp    0x801
 470:	mov    r13,QWORD PTR [r12+0xf0]
 478:	mov    QWORD PTR [r12+0x100],r13
 480:	mov    r11,QWORD PTR [rsp]
 484:	mov    QWORD PTR [r12+0x398],r11
 48c:	mov    rdi,QWORD PTR [r12+0x100]
 494:	add    rsp,0x150
 49b:	movabs r11,0x64a495d9e940
 4a5:	jmp    r11
 4a8:	movdqa xmm0,xmm2
 4ac:	movdqa xmm1,xmm3
 4b0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 4b9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 4c2:	call   0x5d0
 4c7:	jmp    0x1a4
 4cc:	movdqa xmm0,xmm4
 4d0:	movdqa xmm1,xmm3
 4d4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 4dd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 4e6:	call   0x6a0
 4eb:	jmp    0x1fa
 4f0:	movdqa xmm0,xmm2
 4f4:	movdqa xmm1,xmm3
 4f8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 501:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 50a:	call   0x5d0
 50f:	jmp    0x250
 514:	movdqa xmm0,xmm4
 518:	movdqa xmm1,xmm3
 51c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 525:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 52e:	call   0x6a0
 533:	jmp    0x2a6
 538:	movdqa xmm0,xmm2
 53c:	movdqa xmm1,xmm3
 540:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 549:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 552:	call   0x5d0
 557:	jmp    0x2fc
 55c:	movdqa xmm0,xmm4
 560:	movdqa xmm1,xmm3
 564:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 56d:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 576:	call   0x6a0
 57b:	jmp    0x352
 580:	movdqa xmm0,xmm2
 584:	movdqa xmm1,xmm3
 588:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 591:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 59a:	call   0x5d0
 59f:	jmp    0x3a8
 5a4:	movdqa xmm0,xmm4
 5a8:	movdqa xmm1,xmm3
 5ac:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
 5b5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
 5be:	call   0x6a0
 5c3:	jmp    0x3fe
 5c8:	nop    DWORD PTR [rax+rax*1+0x0]
 5d0:	sub    rsp,0x8
 5d4:	mov    QWORD PTR [r12+0x378],0x3
 5e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
 5e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
 5ec:	mov    QWORD PTR [r12+0x108],rbx
 5f4:	stmxcsr DWORD PTR [r12-0x28]
 5fa:	mov    r10d,DWORD PTR [r12-0x28]
 5ff:	test   r10d,0x3f
 606:	je     0x62b
 60c:	mov    r11d,r10d
 60f:	shr    r10d,1
 612:	and    r10d,0x1e
 616:	and    r11d,0x1
 61a:	or     r10d,r11d
 61d:	or     DWORD PTR [r12+0x314],r10d
 625:	and    DWORD PTR [r12-0x28],0xffffffc0
 62b:	ldmxcsr DWORD PTR [r12-0x38]
 631:	lea    rdi,[rsp+0x110]
 639:	lea    rsi,[rsp+0xf0]
 641:	lea    rdx,[rsp+0x100]
 649:	mov    ecx,0xc
 64e:	mov    r8d,0x0
 654:	lea    r9,[r12+0x314]
 65c:	movabs r11,0x64a495c05650
 666:	call   r11
 669:	ldmxcsr DWORD PTR [r12-0x28]
 66f:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
 675:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
 67b:	mov    rbx,QWORD PTR [r12+0x108]
 683:	mov    QWORD PTR [r12+0x378],0x2
 68f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
 698:	add    rsp,0x8
 69c:	ret
 69d:	nop    DWORD PTR [rax]
 6a0:	sub    rsp,0x8
 6a4:	mov    QWORD PTR [r12+0x378],0x3
 6b0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
 6b6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
 6bc:	mov    QWORD PTR [r12+0x108],rbx
 6c4:	stmxcsr DWORD PTR [r12-0x28]
 6ca:	mov    r10d,DWORD PTR [r12-0x28]
 6cf:	test   r10d,0x3f
 6d6:	je     0x6fb
 6dc:	mov    r11d,r10d
 6df:	shr    r10d,1
 6e2:	and    r10d,0x1e
 6e6:	and    r11d,0x1
 6ea:	or     r10d,r11d
 6ed:	or     DWORD PTR [r12+0x314],r10d
 6f5:	and    DWORD PTR [r12-0x28],0xffffffc0
 6fb:	ldmxcsr DWORD PTR [r12-0x38]
 701:	lea    rdi,[rsp+0x110]
 709:	lea    rsi,[rsp+0xf0]
 711:	lea    rdx,[rsp+0x100]
 719:	mov    ecx,0xc
 71e:	mov    r8d,0x0
 724:	lea    r9,[r12+0x314]
 72c:	movabs r11,0x64a495c05650
 736:	call   r11
 739:	ldmxcsr DWORD PTR [r12-0x28]
 73f:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
 745:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
 74b:	mov    rbx,QWORD PTR [r12+0x108]
 753:	mov    QWORD PTR [r12+0x378],0x2
 75f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
 768:	add    rsp,0x8
 76c:	ret
 76d:	mov    eax,0x410068
 772:	mov    QWORD PTR [r12+0x100],rax
 77a:	push   rdx
 77b:	push   rsi
 77c:	push   r10
 77e:	push   r11
 780:	mov    r11,rax
 783:	lahf
 784:	seto   al
 787:	mov    WORD PTR [rsp+0x20],ax
 78c:	mov    rax,r11
 78f:	mov    rdx,QWORD PTR [rsp+0x20]
 794:	mov    r10d,edx
 797:	and    r10d,0xc000
 79e:	shl    r10d,0x10
 7a2:	mov    r11d,edx
 7a5:	and    r11d,0x100
 7ac:	shl    r11d,0x15
 7b0:	or     r10d,r11d
 7b3:	and    edx,0x1
 7b6:	shl    edx,0x1c
 7b9:	or     r10d,edx
 7bc:	btc    r10,0x1d
 7c1:	mov    r11d,0xf0000000
 7c7:	and    r11,r10
 7ca:	movabs rsi,0xffffffff0fffffff
 7d4:	and    rbx,rsi
 7d7:	or     rbx,r11
 7da:	pop    r11
 7dc:	pop    r10
 7de:	pop    rsi
 7df:	pop    rdx
 7e0:	mov    QWORD PTR [r12+0x108],rbx
 7e8:	add    rsp,0x150
 7ef:	mov    eax,0xc
 7f4:	movabs r11,0x64a495d9eca0
 7fe:	jmp    r11
 801:	mov    eax,0x410070
 806:	mov    QWORD PTR [r12+0x100],rax
 80e:	push   rdx
 80f:	push   rsi
 810:	push   r10
 812:	push   r11
 814:	mov    rdx,QWORD PTR [rsp+0x20]
 819:	mov    r10d,edx
 81c:	and    r10d,0xc000
 823:	shl    r10d,0x10
 827:	mov    r11d,edx
 82a:	and    r11d,0x100
 831:	shl    r11d,0x15
 835:	or     r10d,r11d
 838:	and    edx,0x1
 83b:	shl    edx,0x1c
 83e:	or     r10d,edx
 841:	btc    r10,0x1d
 846:	mov    r11d,0xf0000000
 84c:	and    r11,r10
 84f:	movabs rsi,0xffffffff0fffffff
 859:	and    rbx,rsi
 85c:	or     rbx,r11
 85f:	pop    r11
 861:	pop    r10
 863:	pop    rsi
 864:	pop    rdx
 865:	mov    QWORD PTR [r12+0x108],rbx
 86d:	add    rsp,0x150
 874:	mov    eax,0xc
 879:	movabs r11,0x64a495d9eca0
 883:	jmp    r11
 886:	data16 nop WORD PTR [rax+rax*1+0x0]
 890:	sub    rsp,0x150
 897:	mov    r11,QWORD PTR [r12+0x398]
 89f:	mov    QWORD PTR [rsp],r11
 8a3:	cmp    DWORD PTR [r12+0x310],0x0
 8ac:	je     0x937
 8b2:	push   rdx
 8b3:	push   rsi
 8b4:	push   r10
 8b6:	push   r11
 8b8:	mov    rdx,QWORD PTR [rsp+0x20]
 8bd:	mov    r10d,edx
 8c0:	and    r10d,0xc000
 8c7:	shl    r10d,0x10
 8cb:	mov    r11d,edx
 8ce:	and    r11d,0x100
 8d5:	shl    r11d,0x15
 8d9:	or     r10d,r11d
 8dc:	and    edx,0x1
 8df:	shl    edx,0x1c
 8e2:	or     r10d,edx
 8e5:	btc    r10,0x1d
 8ea:	mov    r11d,0xf0000000
 8f0:	and    r11,r10
 8f3:	movabs rsi,0xffffffff0fffffff
 8fd:	and    rbx,rsi
 900:	or     rbx,r11
 903:	pop    r11
 905:	pop    r10
 907:	pop    rsi
 908:	pop    rdx
 909:	mov    QWORD PTR [r12+0x108],rbx
 911:	mov    eax,0x410044
 916:	mov    QWORD PTR [r12+0x100],rax
 91e:	add    rsp,0x150
 925:	mov    eax,0x3
 92a:	movabs r11,0x64a495d9eca0
 934:	jmp    r11
 937:	jmp    0x13e
 93c:	nop    DWORD PTR [rax+0x0]
 940:	sub    rsp,0x150
 947:	mov    r11,QWORD PTR [r12+0x398]
 94f:	mov    QWORD PTR [rsp],r11
 953:	cmp    DWORD PTR [r12+0x310],0x0
 95c:	je     0x9e7
 962:	push   rdx
 963:	push   rsi
 964:	push   r10
 966:	push   r11
 968:	mov    rdx,QWORD PTR [rsp+0x20]
 96d:	mov    r10d,edx
 970:	and    r10d,0xc000
 977:	shl    r10d,0x10
 97b:	mov    r11d,edx
 97e:	and    r11d,0x100
 985:	shl    r11d,0x15
 989:	or     r10d,r11d
 98c:	and    edx,0x1
 98f:	shl    edx,0x1c
 992:	or     r10d,edx
 995:	btc    r10,0x1d
 99a:	mov    r11d,0xf0000000
 9a0:	and    r11,r10
 9a3:	movabs rsi,0xffffffff0fffffff
 9ad:	and    rbx,rsi
 9b0:	or     rbx,r11
 9b3:	pop    r11
 9b5:	pop    r10
 9b7:	pop    rsi
 9b8:	pop    rdx
 9b9:	mov    QWORD PTR [r12+0x108],rbx
 9c1:	mov    eax,0x41006c
 9c6:	mov    QWORD PTR [r12+0x100],rax
 9ce:	add    rsp,0x150
 9d5:	mov    eax,0x3
 9da:	movabs r11,0x64a495d9eca0
 9e4:	jmp    r11
 9e7:	jmp    0x442
 9ec:	nop    DWORD PTR [rax+0x0]
 9f0:	(bad)
 9f1:	(bad)
 9f2:	(bad)
 9f3:	(bad)
 9f4:	(bad)
 9f5:	(bad)
 9f6:	(bad)
 9f7:	jg     0x9f8
 9f9:	(bad)
 9fa:	(bad)
 9fb:	(bad)
 9fc:	(bad)
 9fd:	(bad)
 9fe:	(bad)
 9ff:	jg     0xa01
 a01:	add    BYTE PTR [rax],al
 a03:	add    BYTE PTR [rax],al
 a05:	add    BYTE PTR [rax],dl
 a07:	add    BYTE PTR [rax],al
 a09:	add    BYTE PTR [rax],al
 a0b:	add    BYTE PTR [rax],al
 a0d:	add    BYTE PTR [rax],dl
	...
