0000773cf8bce69b  nop [rax+rax*1], eax
0000773cf8bce6a0  mov qword ptr [r15+0x20], 0x420060
0000773cf8bce6a8  mov qword ptr [r15], 0x00
0000773cf8bce6af  vmovaps xmm1, [0x0000773CF87FE010]
0000773cf8bce6b7  movq xmm1, xmm1
0000773cf8bce6bb  vmovaps xmm15, [0x0000773CF87FE020]
0000773cf8bce6c3  movq xmm15, xmm15
0000773cf8bce6c8  movaps [r15+0x120], xmm15
0000773cf8bce6d0  movq rax, xmm1
0000773cf8bce6d5  movq r14, xmm15
0000773cf8bce6da  vmovq xmm1, rax
0000773cf8bce6df  vmovq xmm15, r14
0000773cf8bce6e4  movaps xmm14, xmm1
0000773cf8bce6e8  addsd xmm14, xmm15
0000773cf8bce6ed  ucomisd xmm14, xmm14
0000773cf8bce6f2  jp 0x0000773CF8BCE791
0000773cf8bce6f8  movq xmm14, xmm14
0000773cf8bce6fd  movaps [r15+0x110], xmm14
0000773cf8bce705  xor eax, eax
0000773cf8bce707  mov r14d, 0xF4240
0000773cf8bce70d  mov r12d, 0x01
0000773cf8bce713  sub r14, r12
0000773cf8bce716  cmc
0000773cf8bce717  lahf
0000773cf8bce718  seto al
0000773cf8bce71b  mov [r15+0x108], eax
0000773cf8bce722  mov [r15+0x08], r14
0000773cf8bce726  mov eax, [r15+0x108]
0000773cf8bce72d  sahf
0000773cf8bce72e  jnz 0x0000773CF8BCE760
0000773cf8bce730  cmp dword ptr [r15+0x318], 0x00
0000773cf8bce738  jz 0x0000773CF8BCE910
0000773cf8bce73e  nop [rax+rax*1], ax
0000773cf8bce747  nop [rax+rax*1], eax
0000773cf8bce74f  mov eax, 0x410050
0000773cf8bce754  mov [r15+0x100], rax
0000773cf8bce75b  jmp 0x0000773CF89FE110
0000773cf8bce760  cmp dword ptr [r15+0x318], 0x00
0000773cf8bce768  jz 0x0000773CF8BCE7E0
0000773cf8bce76e  nop [rax+rax*1], ax
0000773cf8bce777  nop [rax+rax*1], eax
0000773cf8bce77f  mov eax, 0x410044
0000773cf8bce784  mov [r15+0x100], rax
0000773cf8bce78b  jmp 0x0000773CF89FE110
0000773cf8bce790  int3
0000773cf8bce791  ucomisd xmm1, xmm15
0000773cf8bce796  jp 0x0000773CF8BCE7A5
0000773cf8bce798  movaps xmm14, [0x0000773CF87FE030]
0000773cf8bce7a0  jmp 0x0000773CF8BCE6F8
0000773cf8bce7a5  vxorps xmm0, xmm1, xmm15
0000773cf8bce7aa  pextrw eax, xmm0, 0x03
0000773cf8bce7af  and eax, 0x7FF8
0000773cf8bce7b4  cmp eax, 0x08
0000773cf8bce7b7  jnz 0x0000773CF8BCE6F8
0000773cf8bce7bd  movq rax, xmm15
0000773cf8bce7c2  shl rax, 0x0D
0000773cf8bce7c6  jbe 0x0000773CF8BCE6F8
0000773cf8bce7cc  vorps xmm14, xmm15, [0x0000773CF87FE040]
0000773cf8bce7d4  jmp 0x0000773CF8BCE6F8
0000773cf8bce7d9  int3
0000773cf8bce7da  nop [rax+rax*1], ax
0000773cf8bce7e0  movaps xmm1, [r15+0x110]
0000773cf8bce7e8  movq rax, xmm1
0000773cf8bce7ed  movaps xmm1, [r15+0x120]
0000773cf8bce7f5  movq r14, xmm1
0000773cf8bce7fa  vmovq xmm1, rax
0000773cf8bce7ff  vmovq xmm15, r14
0000773cf8bce804  movaps xmm14, xmm1
0000773cf8bce808  addsd xmm14, xmm15
0000773cf8bce80d  ucomisd xmm14, xmm14
0000773cf8bce812  jp 0x0000773CF8BCE8B9
0000773cf8bce818  movq xmm14, xmm14
0000773cf8bce81d  movaps [r15+0x110], xmm14
0000773cf8bce825  mov rax, [r15+0x08]
0000773cf8bce829  mov [rsp+0x10], rax
0000773cf8bce82e  xor eax, eax
0000773cf8bce830  mov r14, [rsp+0x10]
0000773cf8bce835  mov r12d, 0x01
0000773cf8bce83b  sub r14, r12
0000773cf8bce83e  cmc
0000773cf8bce83f  lahf
0000773cf8bce840  seto al
0000773cf8bce843  mov [r15+0x108], eax
0000773cf8bce84a  mov [r15+0x08], r14
0000773cf8bce84e  mov eax, [r15+0x108]
0000773cf8bce855  sahf
0000773cf8bce856  jnz 0x0000773CF8BCE888
0000773cf8bce858  cmp dword ptr [r15+0x318], 0x00
0000773cf8bce860  jz 0x0000773CF8BCE910
0000773cf8bce866  nop [rax+rax*1], ax
0000773cf8bce86f  nop [rax+rax*1], eax
0000773cf8bce877  mov eax, 0x410050
0000773cf8bce87c  mov [r15+0x100], rax
0000773cf8bce883  jmp 0x0000773CF89FE110
0000773cf8bce888  cmp dword ptr [r15+0x318], 0x00
0000773cf8bce890  jz 0x0000773CF8BCE7E0
0000773cf8bce896  nop [rax+rax*1], ax
0000773cf8bce89f  nop [rax+rax*1], eax
0000773cf8bce8a7  mov eax, 0x410044
0000773cf8bce8ac  mov [r15+0x100], rax
0000773cf8bce8b3  jmp 0x0000773CF89FE110
0000773cf8bce8b8  int3
0000773cf8bce8b9  ucomisd xmm1, xmm15
0000773cf8bce8be  jp 0x0000773CF8BCE8CD
0000773cf8bce8c0  movaps xmm14, [0x0000773CF87FE030]
0000773cf8bce8c8  jmp 0x0000773CF8BCE818
0000773cf8bce8cd  vxorps xmm0, xmm1, xmm15
0000773cf8bce8d2  pextrw eax, xmm0, 0x03
0000773cf8bce8d7  and eax, 0x7FF8
0000773cf8bce8dc  cmp eax, 0x08
0000773cf8bce8df  jnz 0x0000773CF8BCE818
0000773cf8bce8e5  movq rax, xmm15
0000773cf8bce8ea  shl rax, 0x0D
0000773cf8bce8ee  jbe 0x0000773CF8BCE818
0000773cf8bce8f4  vorps xmm14, xmm15, [0x0000773CF87FE040]
0000773cf8bce8fc  jmp 0x0000773CF8BCE818
0000773cf8bce901  int3
0000773cf8bce902  nop [rax+rax*1], ax
0000773cf8bce90b  nop [rax+rax*1], eax
0000773cf8bce910  mov rax, [r15+0x20]
0000773cf8bce914  movaps xmm1, [r15+0x110]
0000773cf8bce91c  movq r14, xmm1
0000773cf8bce921  mov [r13+rax*1], r14
0000773cf8bce926  mov rax, [r15+0xF0]
0000773cf8bce92d  mov [r15+0x100], rax
0000773cf8bce934  jmp 0x0000773CF8BCE5C0
0000773cf8bce939  int3
0000773cf8bce93a  call 0x0000773CF8A0E120
0000773cf8bce93f  jmp 0x0000773CF8BCE926
0000773cf8bce944  int3
0000773cf8bce945  nop [rax+rax*1], ax
0000773cf8bce94e  nop
0000773cf8bce950  mov qword ptr [r15+0x100], 0x04
0000773cf8bce95b  mov esi, 0x00
0000773cf8bce960  mov edx, 0x09
0000773cf8bce965  mov rdi, 0x7FFC4887E460
0000773cf8bce96f  mov rax, 0x64B362BE9970
0000773cf8bce979  call rax
0000773cf8bce97b  cmp dword ptr [r15+0x318], 0x00
0000773cf8bce983  jnz 0x0000773CF89FE110
0000773cf8bce989  jmp 0x0000773CF89FE0A0
0000773cf8bce98e  int3
0000773cf8bce98f  int3
