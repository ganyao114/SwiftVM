00007e95e7fce69b  nop [rax+rax*1], eax
00007e95e7fce6a0  mov qword ptr [r15+0x40], 0x4201C0
00007e95e7fce6a8  mov qword ptr [r15+0x48], 0x4203C0
00007e95e7fce6b0  mov qword ptr [r15+0x60], 0x01
00007e95e7fce6b8  xorps xmm1, xmm1
00007e95e7fce6bb  mov eax, 0x41
00007e95e7fce6c0  vcvtusi2sd xmm1, xmm1, eax
00007e95e7fce6c6  mulsd xmm1, [0x00007E95E7BFE010]
00007e95e7fce6ce  movq xmm1, xmm1
00007e95e7fce6d2  movaps [r15+0x120], xmm1
00007e95e7fce6da  mov eax, [r15+0x60]
00007e95e7fce6de  xorps xmm15, xmm15
00007e95e7fce6e2  vcvtusi2sd xmm15, xmm15, eax
00007e95e7fce6e8  mulsd xmm15, [0x00007E95E7BFE020]
00007e95e7fce6f1  movq xmm15, xmm15
00007e95e7fce6f6  movaps [r15+0x110], xmm15
00007e95e7fce6fe  mov rax, [r15+0x60]
00007e95e7fce702  mov [rsp+0x10], rax
00007e95e7fce707  xor eax, eax
00007e95e7fce709  mov r14, [rsp+0x10]
00007e95e7fce70e  mov r12d, 0x40
00007e95e7fce714  cmp r14, r12
00007e95e7fce717  cmc
00007e95e7fce718  lahf
00007e95e7fce719  seto al
00007e95e7fce71c  mov [r15+0x108], eax
00007e95e7fce723  mov qword ptr [r15+0x50], 0x40
00007e95e7fce72b  movq rax, xmm1
00007e95e7fce730  mov r12d, 0x4203C0
00007e95e7fce736  mov [r13+r12*1], rax
00007e95e7fce73b  movq rax, xmm15
00007e95e7fce740  mov r12d, 0x4201C0
00007e95e7fce746  mov [r13+r12*1], rax
00007e95e7fce74b  mov [r15+0x58], r14
00007e95e7fce74f  mov eax, [r15+0x108]
00007e95e7fce756  sahf
00007e95e7fce757  jnz 0x00007E95E7FCE789
00007e95e7fce759  cmp dword ptr [r15+0x318], 0x00
00007e95e7fce761  jz 0x00007E95E7FCE910
00007e95e7fce767  nop [rax+rax*1], ax
00007e95e7fce770  nop [rax+rax*1], eax
00007e95e7fce778  mov eax, 0x410074
00007e95e7fce77d  mov [r15+0x100], rax
00007e95e7fce784  jmp 0x00007E95E7DFE110
00007e95e7fce789  cmp dword ptr [r15+0x318], 0x00
00007e95e7fce791  jz 0x00007E95E7FCE7D0
00007e95e7fce797  nop [rax+rax*1], ax
00007e95e7fce7a0  nop [rax+rax*1], eax
00007e95e7fce7a8  mov eax, 0x41004C
00007e95e7fce7ad  mov [r15+0x100], rax
00007e95e7fce7b4  jmp 0x00007E95E7DFE110
00007e95e7fce7b9  int3
00007e95e7fce7ba  call 0x00007E95E7EB4CB0
00007e95e7fce7bf  jmp 0x00007E95E7FCE73B
00007e95e7fce7c4  call 0x00007E95E7EB4CB0
00007e95e7fce7c9  jmp 0x00007E95E7FCE74B
00007e95e7fce7ce  int3
00007e95e7fce7cf  nop
00007e95e7fce7d0  mov rax, [r15+0x58]
00007e95e7fce7d4  lea r14, [rax+0x01]
00007e95e7fce7d8  mov [r15+0x60], r14
00007e95e7fce7dc  mov r14d, [r15+0x50]
00007e95e7fce7e0  xorps xmm1, xmm1
00007e95e7fce7e3  vcvtusi2sd xmm1, xmm1, r14d
00007e95e7fce7e9  mulsd xmm1, [0x00007E95E7BFE010]
00007e95e7fce7f1  movq xmm1, xmm1
00007e95e7fce7f5  movaps [r15+0x120], xmm1
00007e95e7fce7fd  rorx r12, rax, 0x3D
00007e95e7fce803  and r12, 0xFFFFFFFFFFFFFFF8
00007e95e7fce807  mov eax, [r15+0x60]
00007e95e7fce80b  xorps xmm15, xmm15
00007e95e7fce80f  vcvtusi2sd xmm15, xmm15, eax
00007e95e7fce815  mulsd xmm15, [0x00007E95E7BFE020]
00007e95e7fce81e  movq xmm15, xmm15
00007e95e7fce823  movaps [r15+0x110], xmm15
00007e95e7fce82b  mov rax, [r15+0x60]
00007e95e7fce82f  mov [rsp+0x10], rax
00007e95e7fce834  xor eax, eax
00007e95e7fce836  mov r11, [rsp+0x10]
00007e95e7fce83b  mov r10d, 0x40
00007e95e7fce841  cmp r11, r10
00007e95e7fce844  cmc
00007e95e7fce845  lahf
00007e95e7fce846  seto al
00007e95e7fce849  mov [r15+0x108], eax
00007e95e7fce850  lea eax, [r14d-0x01]
00007e95e7fce855  mov eax, eax
00007e95e7fce857  mov [r15+0x50], rax
00007e95e7fce85b  mov rax, [r15+0x48]
00007e95e7fce85f  lea r14, [rax+r12*1]
00007e95e7fce863  movq rax, xmm1
00007e95e7fce868  mov [r13+r14*1], rax
00007e95e7fce86d  mov rax, [r15+0x40]
00007e95e7fce871  lea r14, [rax+r12*1]
00007e95e7fce875  movq rax, xmm15
00007e95e7fce87a  mov [r13+r14*1], rax
00007e95e7fce87f  mov [r15+0x58], r11
00007e95e7fce883  mov eax, [r15+0x108]
00007e95e7fce88a  sahf
00007e95e7fce88b  jnz 0x00007E95E7FCE8BD
00007e95e7fce88d  cmp dword ptr [r15+0x318], 0x00
00007e95e7fce895  jz 0x00007E95E7FCE910
00007e95e7fce89b  nop [rax+rax*1], ax
00007e95e7fce8a4  nop [rax+rax*1], eax
00007e95e7fce8ac  mov eax, 0x410074
00007e95e7fce8b1  mov [r15+0x100], rax
00007e95e7fce8b8  jmp 0x00007E95E7DFE110
00007e95e7fce8bd  cmp dword ptr [r15+0x318], 0x00
00007e95e7fce8c5  jz 0x00007E95E7FCE7D0
00007e95e7fce8cb  nop [rax+rax*1], ax
00007e95e7fce8d4  nop [rax+rax*1], eax
00007e95e7fce8dc  mov eax, 0x41004C
00007e95e7fce8e1  mov [r15+0x100], rax
00007e95e7fce8e8  jmp 0x00007E95E7DFE110
00007e95e7fce8ed  int3
00007e95e7fce8ee  call 0x00007E95E7ED5EB0
00007e95e7fce8f3  jmp 0x00007E95E7FCE86D
00007e95e7fce8f8  call 0x00007E95E7ED5EB0
00007e95e7fce8fd  jmp 0x00007E95E7FCE87F
00007e95e7fce902  int3
00007e95e7fce903  nop [rax+rax*1], ax
00007e95e7fce90c  nop [rax], eax
00007e95e7fce910  vxorps xmm1, xmm1, xmm1
00007e95e7fce914  movq xmm1, xmm1
00007e95e7fce918  movaps [r15+0x110], xmm1
00007e95e7fce920  mov qword ptr [r15+0x58], 0x00
00007e95e7fce928  mov qword ptr [r15+0x50], 0x4205C0
00007e95e7fce930  mov qword ptr [r15+0x60], 0x00
00007e95e7fce938  mov qword ptr [r15+0x68], 0x4205C0
00007e95e7fce940  mov rax, [r15+0x40]
00007e95e7fce944  mov r14, [r13+rax*1]
00007e95e7fce949  lea r12, [rax+0x08]
00007e95e7fce94d  mov r11, [r13+r12*1]
00007e95e7fce952  movq xmm15, r14
00007e95e7fce957  movq xmm14, r11
00007e95e7fce95c  movq xmm15, xmm15
00007e95e7fce961  movq xmm15, xmm15
00007e95e7fce966  movaps [r15+0x120], xmm15
00007e95e7fce96e  movq xmm14, xmm14
00007e95e7fce973  movq xmm14, xmm14
00007e95e7fce978  movaps [r15+0x130], xmm14
00007e95e7fce980  lea r14, [rax+0x10]
00007e95e7fce984  mov r12, [r13+r14*1]
00007e95e7fce989  lea r14, [rax+0x18]
00007e95e7fce98d  mov r11, [r13+r14*1]
00007e95e7fce992  movq xmm15, r12
00007e95e7fce997  movq xmm14, r11
00007e95e7fce99c  movq xmm15, xmm15
00007e95e7fce9a1  movq xmm15, xmm15
00007e95e7fce9a6  movaps [r15+0x140], xmm15
00007e95e7fce9ae  movq xmm14, xmm14
00007e95e7fce9b3  movq xmm14, xmm14
00007e95e7fce9b8  movaps [r15+0x150], xmm14
00007e95e7fce9c0  lea r14, [rax+0x20]
00007e95e7fce9c4  mov r12, [r13+r14*1]
00007e95e7fce9c9  lea r14, [rax+0x28]
00007e95e7fce9cd  mov r11, [r13+r14*1]
00007e95e7fce9d2  movq xmm15, r12
00007e95e7fce9d7  movq xmm14, r11
00007e95e7fce9dc  movq xmm15, xmm15
00007e95e7fce9e1  movq xmm15, xmm15
00007e95e7fce9e6  movaps [r15+0x160], xmm15
00007e95e7fce9ee  movq xmm14, xmm14
00007e95e7fce9f3  movq xmm14, xmm14
00007e95e7fce9f8  movaps [r15+0x170], xmm14
00007e95e7fcea00  lea r14, [rax+0x30]
00007e95e7fcea04  mov r12, [r13+r14*1]
00007e95e7fcea09  lea r14, [rax+0x38]
00007e95e7fcea0d  mov rax, [r13+r14*1]
00007e95e7fcea12  movq xmm15, r12
00007e95e7fcea17  movq xmm14, rax
00007e95e7fcea1c  movq xmm15, xmm15
00007e95e7fcea21  movq xmm15, xmm15
00007e95e7fcea26  movaps [r15+0x180], xmm15
00007e95e7fcea2e  movq xmm14, xmm14
00007e95e7fcea33  movq xmm14, xmm14
00007e95e7fcea38  movaps [r15+0x210], xmm14
00007e95e7fcea40  mov rax, [r15+0x48]
00007e95e7fcea44  mov [r15+0x78], rax
00007e95e7fcea48  mov r14, [r13+rax*1]
00007e95e7fcea4d  movq xmm15, r14
00007e95e7fcea52  lea r14, [rax+0x40]
00007e95e7fcea56  mov r12, [r13+r14*1]
00007e95e7fcea5b  movq xmm14, r12
00007e95e7fcea60  lea r14, [rax+0x80]
00007e95e7fcea67  mov r12, [r13+r14*1]
00007e95e7fcea6c  movq xmm13, r12
00007e95e7fcea71  movaps xmm12, [r15+0x120]
00007e95e7fcea79  movq r14, xmm12
00007e95e7fcea7e  movq r12, xmm15
00007e95e7fcea83  vmovq xmm15, r14
00007e95e7fcea88  vmovq xmm12, r12
00007e95e7fcea8d  movaps xmm11, xmm15
00007e95e7fcea91  mulsd xmm11, xmm12
00007e95e7fcea96  ucomisd xmm11, xmm11
00007e95e7fcea9b  jp 0x00007E95E7FCEEFC
00007e95e7fceaa1  movq xmm11, xmm11
00007e95e7fceaa6  movaps xmm15, [r15+0x130]
00007e95e7fceaae  movq r14, xmm15
00007e95e7fceab3  movq r12, xmm14
00007e95e7fceab8  vmovq xmm15, r14
00007e95e7fceabd  vmovq xmm14, r12
00007e95e7fceac2  movaps xmm12, xmm15
00007e95e7fceac6  mulsd xmm12, xmm14
00007e95e7fceacb  ucomisd xmm12, xmm12
00007e95e7fcead0  jp 0x00007E95E7FCEF48
00007e95e7fcead6  movq xmm12, xmm12
00007e95e7fceadb  movq r14, xmm11
00007e95e7fceae0  movq r12, xmm1
00007e95e7fceae5  vmovq xmm1, r14
00007e95e7fceaea  vmovq xmm15, r12
00007e95e7fceaef  movaps xmm14, xmm1
00007e95e7fceaf3  addsd xmm14, xmm15
00007e95e7fceaf8  ucomisd xmm14, xmm14
00007e95e7fceafd  jp 0x00007E95E7FCEF94
00007e95e7fceb03  movq xmm14, xmm14
00007e95e7fceb08  movq r14, xmm14
00007e95e7fceb0d  movq r12, xmm12
00007e95e7fceb12  vmovq xmm1, r14
00007e95e7fceb17  vmovq xmm15, r12
00007e95e7fceb1c  movaps xmm14, xmm1
00007e95e7fceb20  addsd xmm14, xmm15
00007e95e7fceb25  ucomisd xmm14, xmm14
00007e95e7fceb2a  jp 0x00007E95E7FCEFE0
00007e95e7fceb30  movq xmm14, xmm14
00007e95e7fceb35  movaps xmm1, [r15+0x140]
00007e95e7fceb3d  movq r14, xmm1
00007e95e7fceb42  movq r12, xmm13
00007e95e7fceb47  vmovq xmm1, r14
00007e95e7fceb4c  vmovq xmm15, r12
00007e95e7fceb51  movaps xmm13, xmm1
00007e95e7fceb55  mulsd xmm13, xmm15
00007e95e7fceb5a  ucomisd xmm13, xmm13
00007e95e7fceb5f  jp 0x00007E95E7FCF02C
00007e95e7fceb65  movq xmm13, xmm13
00007e95e7fceb6a  lea r14, [rax+0xC0]
00007e95e7fceb71  mov r12, [r13+r14*1]
00007e95e7fceb76  movq xmm1, r12
00007e95e7fceb7b  movq r14, xmm14
00007e95e7fceb80  movq r12, xmm13
00007e95e7fceb85  vmovq xmm15, r14
00007e95e7fceb8a  vmovq xmm14, r12
00007e95e7fceb8f  movaps xmm13, xmm15
00007e95e7fceb93  addsd xmm13, xmm14
00007e95e7fceb98  ucomisd xmm13, xmm13
00007e95e7fceb9d  jp 0x00007E95E7FCF082
00007e95e7fceba3  movq xmm13, xmm13
00007e95e7fceba8  movaps xmm15, [r15+0x150]
00007e95e7fcebb0  movq r14, xmm15
00007e95e7fcebb5  movq r12, xmm1
00007e95e7fcebba  vmovq xmm1, r14
00007e95e7fcebbf  vmovq xmm15, r12
00007e95e7fcebc4  movaps xmm14, xmm1
00007e95e7fcebc8  mulsd xmm14, xmm15
00007e95e7fcebcd  ucomisd xmm14, xmm14
00007e95e7fcebd2  jp 0x00007E95E7FCF0CE
00007e95e7fcebd8  movq xmm14, xmm14
00007e95e7fcebdd  lea r14, [rax+0x100]
00007e95e7fcebe4  mov r12, [r13+r14*1]
00007e95e7fcebe9  movq xmm1, r12
00007e95e7fcebee  movq r14, xmm13
00007e95e7fcebf3  movq r12, xmm14
00007e95e7fcebf8  vmovq xmm15, r14
00007e95e7fcebfd  vmovq xmm14, r12
00007e95e7fcec02  movaps xmm13, xmm15
00007e95e7fcec06  addsd xmm13, xmm14
00007e95e7fcec0b  ucomisd xmm13, xmm13
00007e95e7fcec10  jp 0x00007E95E7FCF124
00007e95e7fcec16  movq xmm13, xmm13
00007e95e7fcec1b  movaps xmm15, [r15+0x160]
00007e95e7fcec23  movq r14, xmm15
00007e95e7fcec28  movq r12, xmm1
00007e95e7fcec2d  vmovq xmm1, r14
00007e95e7fcec32  vmovq xmm15, r12
00007e95e7fcec37  movaps xmm14, xmm1
00007e95e7fcec3b  mulsd xmm14, xmm15
00007e95e7fcec40  ucomisd xmm14, xmm14
00007e95e7fcec45  jp 0x00007E95E7FCF170
00007e95e7fcec4b  movq xmm14, xmm14
00007e95e7fcec50  lea r14, [rax+0x140]
00007e95e7fcec57  mov r12, [r13+r14*1]
00007e95e7fcec5c  movq xmm1, r12
00007e95e7fcec61  movq r14, xmm13
00007e95e7fcec66  movq r12, xmm14
00007e95e7fcec6b  vmovq xmm15, r14
00007e95e7fcec70  vmovq xmm14, r12
00007e95e7fcec75  movaps xmm13, xmm15
00007e95e7fcec79  addsd xmm13, xmm14
00007e95e7fcec7e  ucomisd xmm13, xmm13
00007e95e7fcec83  jp 0x00007E95E7FCF1C6
00007e95e7fcec89  movq xmm13, xmm13
00007e95e7fcec8e  movaps xmm15, [r15+0x170]
00007e95e7fcec96  movq r14, xmm15
00007e95e7fcec9b  movq r12, xmm1
00007e95e7fceca0  vmovq xmm1, r14
00007e95e7fceca5  vmovq xmm15, r12
00007e95e7fcecaa  movaps xmm14, xmm1
00007e95e7fcecae  mulsd xmm14, xmm15
00007e95e7fcecb3  ucomisd xmm14, xmm14
00007e95e7fcecb8  jp 0x00007E95E7FCF212
00007e95e7fcecbe  movq xmm14, xmm14
00007e95e7fcecc3  lea r14, [rax+0x180]
00007e95e7fcecca  mov r12, [r13+r14*1]
00007e95e7fceccf  movq xmm1, r12
00007e95e7fcecd4  movq r14, xmm13
00007e95e7fcecd9  movq r12, xmm14
00007e95e7fcecde  vmovq xmm15, r14
00007e95e7fcece3  vmovq xmm14, r12
00007e95e7fcece8  movaps xmm13, xmm15
00007e95e7fcecec  addsd xmm13, xmm14
00007e95e7fcecf1  ucomisd xmm13, xmm13
00007e95e7fcecf6  jp 0x00007E95E7FCF268
00007e95e7fcecfc  movq xmm13, xmm13
00007e95e7fced01  movaps xmm15, [r15+0x180]
00007e95e7fced09  movq r14, xmm15
00007e95e7fced0e  movq r12, xmm1
00007e95e7fced13  vmovq xmm1, r14
00007e95e7fced18  vmovq xmm15, r12
00007e95e7fced1d  movaps xmm14, xmm1
00007e95e7fced21  mulsd xmm14, xmm15
00007e95e7fced26  ucomisd xmm14, xmm14
00007e95e7fced2b  jp 0x00007E95E7FCF2B4
00007e95e7fced31  movq xmm14, xmm14
00007e95e7fced36  lea r14, [rax+0x1C0]
00007e95e7fced3d  mov rax, [r13+r14*1]
00007e95e7fced42  movq xmm1, rax
00007e95e7fced47  movaps [r15+0x240], xmm1
00007e95e7fced4f  movq rax, xmm13
00007e95e7fced54  movq r14, xmm14
00007e95e7fced59  vmovq xmm15, rax
00007e95e7fced5e  vmovq xmm14, r14
00007e95e7fced63  movaps xmm13, xmm15
00007e95e7fced67  addsd xmm13, xmm14
00007e95e7fced6c  ucomisd xmm13, xmm13
00007e95e7fced71  jp 0x00007E95E7FCF30A
00007e95e7fced77  movq xmm13, xmm13
00007e95e7fced7c  movaps xmm15, [r15+0x210]
00007e95e7fced84  movq rax, xmm15
00007e95e7fced89  movq r14, xmm1
00007e95e7fced8e  vmovq xmm1, rax
00007e95e7fced93  vmovq xmm15, r14
00007e95e7fced98  movaps xmm14, xmm1
00007e95e7fced9c  mulsd xmm14, xmm15
00007e95e7fceda1  ucomisd xmm14, xmm14
00007e95e7fceda6  jp 0x00007E95E7FCF352
00007e95e7fcedac  movq xmm14, xmm14
00007e95e7fcedb1  movaps [r15+0x230], xmm14
00007e95e7fcedb9  movq rax, xmm13
00007e95e7fcedbe  movq r14, xmm14
00007e95e7fcedc3  vmovq xmm1, rax
00007e95e7fcedc8  vmovq xmm15, r14
00007e95e7fcedcd  movaps xmm14, xmm1
00007e95e7fcedd1  addsd xmm14, xmm15
00007e95e7fcedd6  ucomisd xmm14, xmm14
00007e95e7fceddb  jp 0x00007E95E7FCF39A
00007e95e7fcede1  movq xmm14, xmm14
00007e95e7fcede6  movaps [r15+0x220], xmm14
00007e95e7fcedee  movq rax, xmm14
00007e95e7fcedf3  mov r14d, 0x4205C0
00007e95e7fcedf9  mov [r13+r14*1], rax
00007e95e7fcedfe  mov qword ptr [r15+0x70], 0x08
00007e95e7fcee06  xor eax, eax
00007e95e7fcee08  mov r14d, 0x08
00007e95e7fcee0e  mov r12d, 0x40
00007e95e7fcee14  cmp r14, r12
00007e95e7fcee17  cmc
00007e95e7fcee18  lahf
00007e95e7fcee19  seto al
00007e95e7fcee1c  mov [r15+0x108], eax
00007e95e7fcee23  mov eax, [r15+0x108]
00007e95e7fcee2a  sahf
00007e95e7fcee2b  jnz 0x00007E95E7FCEE5D
00007e95e7fcee2d  cmp dword ptr [r15+0x318], 0x00
00007e95e7fcee35  jz 0x00007E95E7FCFD40
00007e95e7fcee3b  nop [rax+rax*1], ax
00007e95e7fcee44  nop [rax+rax*1], eax
00007e95e7fcee4c  mov eax, 0x410118
00007e95e7fcee51  mov [r15+0x100], rax
00007e95e7fcee58  jmp 0x00007E95E7DFE110
00007e95e7fcee5d  cmp dword ptr [r15+0x318], 0x00
00007e95e7fcee65  jz 0x00007E95E7FCF3F0
00007e95e7fcee6b  nop [rax+rax*1], ax
00007e95e7fcee74  nop [rax+rax*1], eax
00007e95e7fcee7c  mov eax, 0x4100A4
00007e95e7fcee81  mov [r15+0x100], rax
00007e95e7fcee88  jmp 0x00007E95E7DFE110
00007e95e7fcee8d  int3
00007e95e7fcee8e  call 0x00007E95E7E0DC20
00007e95e7fcee93  jmp 0x00007E95E7FCE949
00007e95e7fcee98  call 0x00007E95E7EC0370
00007e95e7fcee9d  jmp 0x00007E95E7FCE952
00007e95e7fceea2  call 0x00007E95E7EE27E0
00007e95e7fceea7  jmp 0x00007E95E7FCE989
00007e95e7fceeac  call 0x00007E95E7EE1570
00007e95e7fceeb1  jmp 0x00007E95E7FCE992
00007e95e7fceeb6  call 0x00007E95E7EE27E0
00007e95e7fceebb  jmp 0x00007E95E7FCE9C9
00007e95e7fceec0  call 0x00007E95E7EE1570
00007e95e7fceec5  jmp 0x00007E95E7FCE9D2
00007e95e7fceeca  call 0x00007E95E7EE27E0
00007e95e7fceecf  jmp 0x00007E95E7FCEA09
00007e95e7fceed4  call 0x00007E95E7ED59C0
00007e95e7fceed9  jmp 0x00007E95E7FCEA12
00007e95e7fceede  call 0x00007E95E7E0DC20
00007e95e7fceee3  jmp 0x00007E95E7FCEA4D
00007e95e7fceee8  call 0x00007E95E7EE27E0
00007e95e7fceeed  jmp 0x00007E95E7FCEA5B
00007e95e7fceef2  call 0x00007E95E7EE27E0
00007e95e7fceef7  jmp 0x00007E95E7FCEA6C
00007e95e7fceefc  ucomisd xmm15, xmm12
00007e95e7fcef01  jp 0x00007E95E7FCEF10
00007e95e7fcef03  movaps xmm11, [0x00007E95E7BFE030]
00007e95e7fcef0b  jmp 0x00007E95E7FCEAA1
00007e95e7fcef10  vxorps xmm0, xmm15, xmm12
00007e95e7fcef15  pextrw r14d, xmm0, 0x03
00007e95e7fcef1b  and r14d, 0x7FF8
00007e95e7fcef22  cmp r14d, 0x08
00007e95e7fcef26  jnz 0x00007E95E7FCEAA1
00007e95e7fcef2c  movq r14, xmm12
00007e95e7fcef31  shl r14, 0x0D
00007e95e7fcef35  jbe 0x00007E95E7FCEAA1
00007e95e7fcef3b  vorps xmm11, xmm12, [0x00007E95E7BFE040]
00007e95e7fcef43  jmp 0x00007E95E7FCEAA1
00007e95e7fcef48  ucomisd xmm15, xmm14
00007e95e7fcef4d  jp 0x00007E95E7FCEF5C
00007e95e7fcef4f  movaps xmm12, [0x00007E95E7BFE030]
00007e95e7fcef57  jmp 0x00007E95E7FCEAD6
00007e95e7fcef5c  vxorps xmm0, xmm15, xmm14
00007e95e7fcef61  pextrw r14d, xmm0, 0x03
00007e95e7fcef67  and r14d, 0x7FF8
00007e95e7fcef6e  cmp r14d, 0x08
00007e95e7fcef72  jnz 0x00007E95E7FCEAD6
00007e95e7fcef78  movq r14, xmm14
00007e95e7fcef7d  shl r14, 0x0D
00007e95e7fcef81  jbe 0x00007E95E7FCEAD6
00007e95e7fcef87  vorps xmm12, xmm14, [0x00007E95E7BFE040]
00007e95e7fcef8f  jmp 0x00007E95E7FCEAD6
00007e95e7fcef94  ucomisd xmm1, xmm15
00007e95e7fcef99  jp 0x00007E95E7FCEFA8
00007e95e7fcef9b  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcefa3  jmp 0x00007E95E7FCEB03
00007e95e7fcefa8  vxorps xmm0, xmm1, xmm15
00007e95e7fcefad  pextrw r14d, xmm0, 0x03
00007e95e7fcefb3  and r14d, 0x7FF8
00007e95e7fcefba  cmp r14d, 0x08
00007e95e7fcefbe  jnz 0x00007E95E7FCEB03
00007e95e7fcefc4  movq r14, xmm15
00007e95e7fcefc9  shl r14, 0x0D
00007e95e7fcefcd  jbe 0x00007E95E7FCEB03
00007e95e7fcefd3  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcefdb  jmp 0x00007E95E7FCEB03
00007e95e7fcefe0  ucomisd xmm1, xmm15
00007e95e7fcefe5  jp 0x00007E95E7FCEFF4
00007e95e7fcefe7  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcefef  jmp 0x00007E95E7FCEB30
00007e95e7fceff4  vxorps xmm0, xmm1, xmm15
00007e95e7fceff9  pextrw r14d, xmm0, 0x03
00007e95e7fcefff  and r14d, 0x7FF8
00007e95e7fcf006  cmp r14d, 0x08
00007e95e7fcf00a  jnz 0x00007E95E7FCEB30
00007e95e7fcf010  movq r14, xmm15
00007e95e7fcf015  shl r14, 0x0D
00007e95e7fcf019  jbe 0x00007E95E7FCEB30
00007e95e7fcf01f  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcf027  jmp 0x00007E95E7FCEB30
00007e95e7fcf02c  ucomisd xmm1, xmm15
00007e95e7fcf031  jp 0x00007E95E7FCF040
00007e95e7fcf033  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fcf03b  jmp 0x00007E95E7FCEB65
00007e95e7fcf040  vxorps xmm0, xmm1, xmm15
00007e95e7fcf045  pextrw r14d, xmm0, 0x03
00007e95e7fcf04b  and r14d, 0x7FF8
00007e95e7fcf052  cmp r14d, 0x08
00007e95e7fcf056  jnz 0x00007E95E7FCEB65
00007e95e7fcf05c  movq r14, xmm15
00007e95e7fcf061  shl r14, 0x0D
00007e95e7fcf065  jbe 0x00007E95E7FCEB65
00007e95e7fcf06b  vorps xmm13, xmm15, [0x00007E95E7BFE040]
00007e95e7fcf073  jmp 0x00007E95E7FCEB65
00007e95e7fcf078  call 0x00007E95E7EE27E0
00007e95e7fcf07d  jmp 0x00007E95E7FCEB76
00007e95e7fcf082  ucomisd xmm15, xmm14
00007e95e7fcf087  jp 0x00007E95E7FCF096
00007e95e7fcf089  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fcf091  jmp 0x00007E95E7FCEBA3
00007e95e7fcf096  vxorps xmm0, xmm15, xmm14
00007e95e7fcf09b  pextrw r14d, xmm0, 0x03
00007e95e7fcf0a1  and r14d, 0x7FF8
00007e95e7fcf0a8  cmp r14d, 0x08
00007e95e7fcf0ac  jnz 0x00007E95E7FCEBA3
00007e95e7fcf0b2  movq r14, xmm14
00007e95e7fcf0b7  shl r14, 0x0D
00007e95e7fcf0bb  jbe 0x00007E95E7FCEBA3
00007e95e7fcf0c1  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fcf0c9  jmp 0x00007E95E7FCEBA3
00007e95e7fcf0ce  ucomisd xmm1, xmm15
00007e95e7fcf0d3  jp 0x00007E95E7FCF0E2
00007e95e7fcf0d5  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcf0dd  jmp 0x00007E95E7FCEBD8
00007e95e7fcf0e2  vxorps xmm0, xmm1, xmm15
00007e95e7fcf0e7  pextrw r14d, xmm0, 0x03
00007e95e7fcf0ed  and r14d, 0x7FF8
00007e95e7fcf0f4  cmp r14d, 0x08
00007e95e7fcf0f8  jnz 0x00007E95E7FCEBD8
00007e95e7fcf0fe  movq r14, xmm15
00007e95e7fcf103  shl r14, 0x0D
00007e95e7fcf107  jbe 0x00007E95E7FCEBD8
00007e95e7fcf10d  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcf115  jmp 0x00007E95E7FCEBD8
00007e95e7fcf11a  call 0x00007E95E7EE27E0
00007e95e7fcf11f  jmp 0x00007E95E7FCEBE9
00007e95e7fcf124  ucomisd xmm15, xmm14
00007e95e7fcf129  jp 0x00007E95E7FCF138
00007e95e7fcf12b  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fcf133  jmp 0x00007E95E7FCEC16
00007e95e7fcf138  vxorps xmm0, xmm15, xmm14
00007e95e7fcf13d  pextrw r14d, xmm0, 0x03
00007e95e7fcf143  and r14d, 0x7FF8
00007e95e7fcf14a  cmp r14d, 0x08
00007e95e7fcf14e  jnz 0x00007E95E7FCEC16
00007e95e7fcf154  movq r14, xmm14
00007e95e7fcf159  shl r14, 0x0D
00007e95e7fcf15d  jbe 0x00007E95E7FCEC16
00007e95e7fcf163  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fcf16b  jmp 0x00007E95E7FCEC16
00007e95e7fcf170  ucomisd xmm1, xmm15
00007e95e7fcf175  jp 0x00007E95E7FCF184
00007e95e7fcf177  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcf17f  jmp 0x00007E95E7FCEC4B
00007e95e7fcf184  vxorps xmm0, xmm1, xmm15
00007e95e7fcf189  pextrw r14d, xmm0, 0x03
00007e95e7fcf18f  and r14d, 0x7FF8
00007e95e7fcf196  cmp r14d, 0x08
00007e95e7fcf19a  jnz 0x00007E95E7FCEC4B
00007e95e7fcf1a0  movq r14, xmm15
00007e95e7fcf1a5  shl r14, 0x0D
00007e95e7fcf1a9  jbe 0x00007E95E7FCEC4B
00007e95e7fcf1af  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcf1b7  jmp 0x00007E95E7FCEC4B
00007e95e7fcf1bc  call 0x00007E95E7EE27E0
00007e95e7fcf1c1  jmp 0x00007E95E7FCEC5C
00007e95e7fcf1c6  ucomisd xmm15, xmm14
00007e95e7fcf1cb  jp 0x00007E95E7FCF1DA
00007e95e7fcf1cd  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fcf1d5  jmp 0x00007E95E7FCEC89
00007e95e7fcf1da  vxorps xmm0, xmm15, xmm14
00007e95e7fcf1df  pextrw r14d, xmm0, 0x03
00007e95e7fcf1e5  and r14d, 0x7FF8
00007e95e7fcf1ec  cmp r14d, 0x08
00007e95e7fcf1f0  jnz 0x00007E95E7FCEC89
00007e95e7fcf1f6  movq r14, xmm14
00007e95e7fcf1fb  shl r14, 0x0D
00007e95e7fcf1ff  jbe 0x00007E95E7FCEC89
00007e95e7fcf205  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fcf20d  jmp 0x00007E95E7FCEC89
00007e95e7fcf212  ucomisd xmm1, xmm15
00007e95e7fcf217  jp 0x00007E95E7FCF226
00007e95e7fcf219  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcf221  jmp 0x00007E95E7FCECBE
00007e95e7fcf226  vxorps xmm0, xmm1, xmm15
00007e95e7fcf22b  pextrw r14d, xmm0, 0x03
00007e95e7fcf231  and r14d, 0x7FF8
00007e95e7fcf238  cmp r14d, 0x08
00007e95e7fcf23c  jnz 0x00007E95E7FCECBE
00007e95e7fcf242  movq r14, xmm15
00007e95e7fcf247  shl r14, 0x0D
00007e95e7fcf24b  jbe 0x00007E95E7FCECBE
00007e95e7fcf251  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcf259  jmp 0x00007E95E7FCECBE
00007e95e7fcf25e  call 0x00007E95E7EE27E0
00007e95e7fcf263  jmp 0x00007E95E7FCECCF
00007e95e7fcf268  ucomisd xmm15, xmm14
00007e95e7fcf26d  jp 0x00007E95E7FCF27C
00007e95e7fcf26f  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fcf277  jmp 0x00007E95E7FCECFC
00007e95e7fcf27c  vxorps xmm0, xmm15, xmm14
00007e95e7fcf281  pextrw r14d, xmm0, 0x03
00007e95e7fcf287  and r14d, 0x7FF8
00007e95e7fcf28e  cmp r14d, 0x08
00007e95e7fcf292  jnz 0x00007E95E7FCECFC
00007e95e7fcf298  movq r14, xmm14
00007e95e7fcf29d  shl r14, 0x0D
00007e95e7fcf2a1  jbe 0x00007E95E7FCECFC
00007e95e7fcf2a7  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fcf2af  jmp 0x00007E95E7FCECFC
00007e95e7fcf2b4  ucomisd xmm1, xmm15
00007e95e7fcf2b9  jp 0x00007E95E7FCF2C8
00007e95e7fcf2bb  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcf2c3  jmp 0x00007E95E7FCED31
00007e95e7fcf2c8  vxorps xmm0, xmm1, xmm15
00007e95e7fcf2cd  pextrw r14d, xmm0, 0x03
00007e95e7fcf2d3  and r14d, 0x7FF8
00007e95e7fcf2da  cmp r14d, 0x08
00007e95e7fcf2de  jnz 0x00007E95E7FCED31
00007e95e7fcf2e4  movq r14, xmm15
00007e95e7fcf2e9  shl r14, 0x0D
00007e95e7fcf2ed  jbe 0x00007E95E7FCED31
00007e95e7fcf2f3  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcf2fb  jmp 0x00007E95E7FCED31
00007e95e7fcf300  call 0x00007E95E7ED59C0
00007e95e7fcf305  jmp 0x00007E95E7FCED42
00007e95e7fcf30a  ucomisd xmm15, xmm14
00007e95e7fcf30f  jp 0x00007E95E7FCF31E
00007e95e7fcf311  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fcf319  jmp 0x00007E95E7FCED77
00007e95e7fcf31e  vxorps xmm0, xmm15, xmm14
00007e95e7fcf323  pextrw eax, xmm0, 0x03
00007e95e7fcf328  and eax, 0x7FF8
00007e95e7fcf32d  cmp eax, 0x08
00007e95e7fcf330  jnz 0x00007E95E7FCED77
00007e95e7fcf336  movq rax, xmm14
00007e95e7fcf33b  shl rax, 0x0D
00007e95e7fcf33f  jbe 0x00007E95E7FCED77
00007e95e7fcf345  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fcf34d  jmp 0x00007E95E7FCED77
00007e95e7fcf352  ucomisd xmm1, xmm15
00007e95e7fcf357  jp 0x00007E95E7FCF366
00007e95e7fcf359  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcf361  jmp 0x00007E95E7FCEDAC
00007e95e7fcf366  vxorps xmm0, xmm1, xmm15
00007e95e7fcf36b  pextrw eax, xmm0, 0x03
00007e95e7fcf370  and eax, 0x7FF8
00007e95e7fcf375  cmp eax, 0x08
00007e95e7fcf378  jnz 0x00007E95E7FCEDAC
00007e95e7fcf37e  movq rax, xmm15
00007e95e7fcf383  shl rax, 0x0D
00007e95e7fcf387  jbe 0x00007E95E7FCEDAC
00007e95e7fcf38d  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcf395  jmp 0x00007E95E7FCEDAC
00007e95e7fcf39a  ucomisd xmm1, xmm15
00007e95e7fcf39f  jp 0x00007E95E7FCF3AE
00007e95e7fcf3a1  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcf3a9  jmp 0x00007E95E7FCEDE1
00007e95e7fcf3ae  vxorps xmm0, xmm1, xmm15
00007e95e7fcf3b3  pextrw eax, xmm0, 0x03
00007e95e7fcf3b8  and eax, 0x7FF8
00007e95e7fcf3bd  cmp eax, 0x08
00007e95e7fcf3c0  jnz 0x00007E95E7FCEDE1
00007e95e7fcf3c6  movq rax, xmm15
00007e95e7fcf3cb  shl rax, 0x0D
00007e95e7fcf3cf  jbe 0x00007E95E7FCEDE1
00007e95e7fcf3d5  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcf3dd  jmp 0x00007E95E7FCEDE1
00007e95e7fcf3e2  call 0x00007E95E7ED5EB0
00007e95e7fcf3e7  jmp 0x00007E95E7FCEDFE
00007e95e7fcf3ec  int3
00007e95e7fcf3ed  nop [rax], eax
00007e95e7fcf3f0  mov rax, [r15+0x48]
00007e95e7fcf3f4  mov r14, [r15+0x70]
00007e95e7fcf3f8  lea r12, [rax+r14*1]
00007e95e7fcf3fc  mov [r15+0x78], r12
00007e95e7fcf400  mov rax, [r13+r12*1]
00007e95e7fcf405  movq xmm1, rax
00007e95e7fcf40a  lea rax, [r12+0x40]
00007e95e7fcf40f  mov r11, [r13+rax*1]
00007e95e7fcf414  movq xmm15, r11
00007e95e7fcf419  lea rax, [r12+0x80]
00007e95e7fcf421  mov r11, [r13+rax*1]
00007e95e7fcf426  movq xmm14, r11
00007e95e7fcf42b  movaps xmm13, [r15+0x120]
00007e95e7fcf433  movq rax, xmm13
00007e95e7fcf438  movq r11, xmm1
00007e95e7fcf43d  vmovq xmm1, rax
00007e95e7fcf442  vmovq xmm13, r11
00007e95e7fcf447  movaps xmm12, xmm1
00007e95e7fcf44b  mulsd xmm12, xmm13
00007e95e7fcf450  ucomisd xmm12, xmm12
00007e95e7fcf455  jp 0x00007E95E7FCF879
00007e95e7fcf45b  movq xmm12, xmm12
00007e95e7fcf460  movaps xmm1, [r15+0x130]
00007e95e7fcf468  movq rax, xmm1
00007e95e7fcf46d  movq r11, xmm15
00007e95e7fcf472  vmovq xmm1, rax
00007e95e7fcf477  vmovq xmm15, r11
00007e95e7fcf47c  movaps xmm13, xmm1
00007e95e7fcf480  mulsd xmm13, xmm15
00007e95e7fcf485  ucomisd xmm13, xmm13
00007e95e7fcf48a  jp 0x00007E95E7FCF8C1
00007e95e7fcf490  movq xmm13, xmm13
00007e95e7fcf495  movq rax, xmm12
00007e95e7fcf49a  movaps xmm1, [r15+0x110]
00007e95e7fcf4a2  movq r11, xmm1
00007e95e7fcf4a7  vmovq xmm1, rax
00007e95e7fcf4ac  vmovq xmm15, r11
00007e95e7fcf4b1  movaps xmm12, xmm1
00007e95e7fcf4b5  addsd xmm12, xmm15
00007e95e7fcf4ba  ucomisd xmm12, xmm12
00007e95e7fcf4bf  jp 0x00007E95E7FCF909
00007e95e7fcf4c5  movq xmm12, xmm12
00007e95e7fcf4ca  movq rax, xmm12
00007e95e7fcf4cf  movq r11, xmm13
00007e95e7fcf4d4  vmovq xmm1, rax
00007e95e7fcf4d9  vmovq xmm15, r11
00007e95e7fcf4de  movaps xmm13, xmm1
00007e95e7fcf4e2  addsd xmm13, xmm15
00007e95e7fcf4e7  ucomisd xmm13, xmm13
00007e95e7fcf4ec  jp 0x00007E95E7FCF951
00007e95e7fcf4f2  movq xmm13, xmm13
00007e95e7fcf4f7  movaps xmm1, [r15+0x140]
00007e95e7fcf4ff  movq rax, xmm1
00007e95e7fcf504  movq r11, xmm14
00007e95e7fcf509  vmovq xmm1, rax
00007e95e7fcf50e  vmovq xmm15, r11
00007e95e7fcf513  movaps xmm14, xmm1
00007e95e7fcf517  mulsd xmm14, xmm15
00007e95e7fcf51c  ucomisd xmm14, xmm14
00007e95e7fcf521  jp 0x00007E95E7FCF999
00007e95e7fcf527  movq xmm14, xmm14
00007e95e7fcf52c  lea rax, [r12+0xC0]
00007e95e7fcf534  mov r11, [r13+rax*1]
00007e95e7fcf539  movq xmm1, r11
00007e95e7fcf53e  movq rax, xmm13
00007e95e7fcf543  movq r11, xmm14
00007e95e7fcf548  vmovq xmm15, rax
00007e95e7fcf54d  vmovq xmm14, r11
00007e95e7fcf552  movaps xmm13, xmm15
00007e95e7fcf556  addsd xmm13, xmm14
00007e95e7fcf55b  ucomisd xmm13, xmm13
00007e95e7fcf560  jp 0x00007E95E7FCF9EB
00007e95e7fcf566  movq xmm13, xmm13
00007e95e7fcf56b  movaps xmm15, [r15+0x150]
00007e95e7fcf573  movq rax, xmm15
00007e95e7fcf578  movq r11, xmm1
00007e95e7fcf57d  vmovq xmm1, rax
00007e95e7fcf582  vmovq xmm15, r11
00007e95e7fcf587  movaps xmm14, xmm1
00007e95e7fcf58b  mulsd xmm14, xmm15
00007e95e7fcf590  ucomisd xmm14, xmm14
00007e95e7fcf595  jp 0x00007E95E7FCFA33
00007e95e7fcf59b  movq xmm14, xmm14
00007e95e7fcf5a0  lea rax, [r12+0x100]
00007e95e7fcf5a8  mov r11, [r13+rax*1]
00007e95e7fcf5ad  movq xmm1, r11
00007e95e7fcf5b2  movq rax, xmm13
00007e95e7fcf5b7  movq r11, xmm14
00007e95e7fcf5bc  vmovq xmm15, rax
00007e95e7fcf5c1  vmovq xmm14, r11
00007e95e7fcf5c6  movaps xmm13, xmm15
00007e95e7fcf5ca  addsd xmm13, xmm14
00007e95e7fcf5cf  ucomisd xmm13, xmm13
00007e95e7fcf5d4  jp 0x00007E95E7FCFA85
00007e95e7fcf5da  movq xmm13, xmm13
00007e95e7fcf5df  movaps xmm15, [r15+0x160]
00007e95e7fcf5e7  movq rax, xmm15
00007e95e7fcf5ec  movq r11, xmm1
00007e95e7fcf5f1  vmovq xmm1, rax
00007e95e7fcf5f6  vmovq xmm15, r11
00007e95e7fcf5fb  movaps xmm14, xmm1
00007e95e7fcf5ff  mulsd xmm14, xmm15
00007e95e7fcf604  ucomisd xmm14, xmm14
00007e95e7fcf609  jp 0x00007E95E7FCFACD
00007e95e7fcf60f  movq xmm14, xmm14
00007e95e7fcf614  lea rax, [r12+0x140]
00007e95e7fcf61c  mov r11, [r13+rax*1]
00007e95e7fcf621  movq xmm1, r11
00007e95e7fcf626  movq rax, xmm13
00007e95e7fcf62b  movq r11, xmm14
00007e95e7fcf630  vmovq xmm15, rax
00007e95e7fcf635  vmovq xmm14, r11
00007e95e7fcf63a  movaps xmm13, xmm15
00007e95e7fcf63e  addsd xmm13, xmm14
00007e95e7fcf643  ucomisd xmm13, xmm13
00007e95e7fcf648  jp 0x00007E95E7FCFB1F
00007e95e7fcf64e  movq xmm13, xmm13
00007e95e7fcf653  movaps xmm15, [r15+0x170]
00007e95e7fcf65b  movq rax, xmm15
00007e95e7fcf660  movq r11, xmm1
00007e95e7fcf665  vmovq xmm1, rax
00007e95e7fcf66a  vmovq xmm15, r11
00007e95e7fcf66f  movaps xmm14, xmm1
00007e95e7fcf673  mulsd xmm14, xmm15
00007e95e7fcf678  ucomisd xmm14, xmm14
00007e95e7fcf67d  jp 0x00007E95E7FCFB67
00007e95e7fcf683  movq xmm14, xmm14
00007e95e7fcf688  lea rax, [r12+0x180]
00007e95e7fcf690  mov r11, [r13+rax*1]
00007e95e7fcf695  movq xmm1, r11
00007e95e7fcf69a  movq rax, xmm13
00007e95e7fcf69f  movq r11, xmm14
00007e95e7fcf6a4  vmovq xmm15, rax
00007e95e7fcf6a9  vmovq xmm14, r11
00007e95e7fcf6ae  movaps xmm13, xmm15
00007e95e7fcf6b2  addsd xmm13, xmm14
00007e95e7fcf6b7  ucomisd xmm13, xmm13
00007e95e7fcf6bc  jp 0x00007E95E7FCFBB9
00007e95e7fcf6c2  movq xmm13, xmm13
00007e95e7fcf6c7  movaps xmm15, [r15+0x180]
00007e95e7fcf6cf  movq rax, xmm15
00007e95e7fcf6d4  movq r11, xmm1
00007e95e7fcf6d9  vmovq xmm1, rax
00007e95e7fcf6de  vmovq xmm15, r11
00007e95e7fcf6e3  movaps xmm14, xmm1
00007e95e7fcf6e7  mulsd xmm14, xmm15
00007e95e7fcf6ec  ucomisd xmm14, xmm14
00007e95e7fcf6f1  jp 0x00007E95E7FCFC01
00007e95e7fcf6f7  movq xmm14, xmm14
00007e95e7fcf6fc  lea rax, [r12+0x1C0]
00007e95e7fcf704  mov r12, [r13+rax*1]
00007e95e7fcf709  movq xmm1, r12
00007e95e7fcf70e  movaps [r15+0x240], xmm1
00007e95e7fcf716  movq rax, xmm13
00007e95e7fcf71b  movq r12, xmm14
00007e95e7fcf720  vmovq xmm15, rax
00007e95e7fcf725  vmovq xmm14, r12
00007e95e7fcf72a  movaps xmm13, xmm15
00007e95e7fcf72e  addsd xmm13, xmm14
00007e95e7fcf733  ucomisd xmm13, xmm13
00007e95e7fcf738  jp 0x00007E95E7FCFC53
00007e95e7fcf73e  movq xmm13, xmm13
00007e95e7fcf743  movaps xmm15, [r15+0x210]
00007e95e7fcf74b  movq rax, xmm15
00007e95e7fcf750  movq r12, xmm1
00007e95e7fcf755  vmovq xmm1, rax
00007e95e7fcf75a  vmovq xmm15, r12
00007e95e7fcf75f  movaps xmm14, xmm1
00007e95e7fcf763  mulsd xmm14, xmm15
00007e95e7fcf768  ucomisd xmm14, xmm14
00007e95e7fcf76d  jp 0x00007E95E7FCFC9B
00007e95e7fcf773  movq xmm14, xmm14
00007e95e7fcf778  movaps [r15+0x230], xmm14
00007e95e7fcf780  movq rax, xmm13
00007e95e7fcf785  movq r12, xmm14
00007e95e7fcf78a  vmovq xmm1, rax
00007e95e7fcf78f  vmovq xmm15, r12
00007e95e7fcf794  movaps xmm14, xmm1
00007e95e7fcf798  addsd xmm14, xmm15
00007e95e7fcf79d  ucomisd xmm14, xmm14
00007e95e7fcf7a2  jp 0x00007E95E7FCFCE3
00007e95e7fcf7a8  movq xmm14, xmm14
00007e95e7fcf7ad  movaps [r15+0x220], xmm14
00007e95e7fcf7b5  mov rax, [r15+0x68]
00007e95e7fcf7b9  lea r12, [rax+r14*1]
00007e95e7fcf7bd  movq rax, xmm14
00007e95e7fcf7c2  mov [r13+r12*1], rax
00007e95e7fcf7c7  lea rax, [r14+0x08]
00007e95e7fcf7cb  mov [r15+0x70], rax
00007e95e7fcf7cf  mov [rsp+0x10], rax
00007e95e7fcf7d4  xor eax, eax
00007e95e7fcf7d6  mov r14, [rsp+0x10]
00007e95e7fcf7db  mov r12d, 0x40
00007e95e7fcf7e1  cmp r14, r12
00007e95e7fcf7e4  cmc
00007e95e7fcf7e5  lahf
00007e95e7fcf7e6  seto al
00007e95e7fcf7e9  mov [r15+0x108], eax
00007e95e7fcf7f0  mov eax, [r15+0x108]
00007e95e7fcf7f7  sahf
00007e95e7fcf7f8  jnz 0x00007E95E7FCF82A
00007e95e7fcf7fa  cmp dword ptr [r15+0x318], 0x00
00007e95e7fcf802  jz 0x00007E95E7FCFD40
00007e95e7fcf808  nop [rax+rax*1], ax
00007e95e7fcf811  nop [rax+rax*1], eax
00007e95e7fcf819  mov eax, 0x410118
00007e95e7fcf81e  mov [r15+0x100], rax
00007e95e7fcf825  jmp 0x00007E95E7DFE110
00007e95e7fcf82a  cmp dword ptr [r15+0x318], 0x00
00007e95e7fcf832  jz 0x00007E95E7FCF3F0
00007e95e7fcf838  nop [rax+rax*1], ax
00007e95e7fcf841  nop [rax+rax*1], eax
00007e95e7fcf849  mov eax, 0x4100A4
00007e95e7fcf84e  mov [r15+0x100], rax
00007e95e7fcf855  jmp 0x00007E95E7DFE110
00007e95e7fcf85a  int3
00007e95e7fcf85b  call 0x00007E95E7EB47C0
00007e95e7fcf860  jmp 0x00007E95E7FCF405
00007e95e7fcf865  call 0x00007E95E7E0A4B0
00007e95e7fcf86a  jmp 0x00007E95E7FCF414
00007e95e7fcf86f  call 0x00007E95E7E0A4B0
00007e95e7fcf874  jmp 0x00007E95E7FCF426
00007e95e7fcf879  ucomisd xmm1, xmm13
00007e95e7fcf87e  jp 0x00007E95E7FCF88D
00007e95e7fcf880  movaps xmm12, [0x00007E95E7BFE030]
00007e95e7fcf888  jmp 0x00007E95E7FCF45B
00007e95e7fcf88d  vxorps xmm0, xmm1, xmm13
00007e95e7fcf892  pextrw eax, xmm0, 0x03
00007e95e7fcf897  and eax, 0x7FF8
00007e95e7fcf89c  cmp eax, 0x08
00007e95e7fcf89f  jnz 0x00007E95E7FCF45B
00007e95e7fcf8a5  movq rax, xmm13
00007e95e7fcf8aa  shl rax, 0x0D
00007e95e7fcf8ae  jbe 0x00007E95E7FCF45B
00007e95e7fcf8b4  vorps xmm12, xmm13, [0x00007E95E7BFE040]
00007e95e7fcf8bc  jmp 0x00007E95E7FCF45B
00007e95e7fcf8c1  ucomisd xmm1, xmm15
00007e95e7fcf8c6  jp 0x00007E95E7FCF8D5
00007e95e7fcf8c8  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fcf8d0  jmp 0x00007E95E7FCF490
00007e95e7fcf8d5  vxorps xmm0, xmm1, xmm15
00007e95e7fcf8da  pextrw eax, xmm0, 0x03
00007e95e7fcf8df  and eax, 0x7FF8
00007e95e7fcf8e4  cmp eax, 0x08
00007e95e7fcf8e7  jnz 0x00007E95E7FCF490
00007e95e7fcf8ed  movq rax, xmm15
00007e95e7fcf8f2  shl rax, 0x0D
00007e95e7fcf8f6  jbe 0x00007E95E7FCF490
00007e95e7fcf8fc  vorps xmm13, xmm15, [0x00007E95E7BFE040]
00007e95e7fcf904  jmp 0x00007E95E7FCF490
00007e95e7fcf909  ucomisd xmm1, xmm15
00007e95e7fcf90e  jp 0x00007E95E7FCF91D
00007e95e7fcf910  movaps xmm12, [0x00007E95E7BFE030]
00007e95e7fcf918  jmp 0x00007E95E7FCF4C5
00007e95e7fcf91d  vxorps xmm0, xmm1, xmm15
00007e95e7fcf922  pextrw eax, xmm0, 0x03
00007e95e7fcf927  and eax, 0x7FF8
00007e95e7fcf92c  cmp eax, 0x08
00007e95e7fcf92f  jnz 0x00007E95E7FCF4C5
00007e95e7fcf935  movq rax, xmm15
00007e95e7fcf93a  shl rax, 0x0D
00007e95e7fcf93e  jbe 0x00007E95E7FCF4C5
00007e95e7fcf944  vorps xmm12, xmm15, [0x00007E95E7BFE040]
00007e95e7fcf94c  jmp 0x00007E95E7FCF4C5
00007e95e7fcf951  ucomisd xmm1, xmm15
00007e95e7fcf956  jp 0x00007E95E7FCF965
00007e95e7fcf958  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fcf960  jmp 0x00007E95E7FCF4F2
00007e95e7fcf965  vxorps xmm0, xmm1, xmm15
00007e95e7fcf96a  pextrw eax, xmm0, 0x03
00007e95e7fcf96f  and eax, 0x7FF8
00007e95e7fcf974  cmp eax, 0x08
00007e95e7fcf977  jnz 0x00007E95E7FCF4F2
00007e95e7fcf97d  movq rax, xmm15
00007e95e7fcf982  shl rax, 0x0D
00007e95e7fcf986  jbe 0x00007E95E7FCF4F2
00007e95e7fcf98c  vorps xmm13, xmm15, [0x00007E95E7BFE040]
00007e95e7fcf994  jmp 0x00007E95E7FCF4F2
00007e95e7fcf999  ucomisd xmm1, xmm15
00007e95e7fcf99e  jp 0x00007E95E7FCF9AD
00007e95e7fcf9a0  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcf9a8  jmp 0x00007E95E7FCF527
00007e95e7fcf9ad  vxorps xmm0, xmm1, xmm15
00007e95e7fcf9b2  pextrw eax, xmm0, 0x03
00007e95e7fcf9b7  and eax, 0x7FF8
00007e95e7fcf9bc  cmp eax, 0x08
00007e95e7fcf9bf  jnz 0x00007E95E7FCF527
00007e95e7fcf9c5  movq rax, xmm15
00007e95e7fcf9ca  shl rax, 0x0D
00007e95e7fcf9ce  jbe 0x00007E95E7FCF527
00007e95e7fcf9d4  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcf9dc  jmp 0x00007E95E7FCF527
00007e95e7fcf9e1  call 0x00007E95E7E0A4B0
00007e95e7fcf9e6  jmp 0x00007E95E7FCF539
00007e95e7fcf9eb  ucomisd xmm15, xmm14
00007e95e7fcf9f0  jp 0x00007E95E7FCF9FF
00007e95e7fcf9f2  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fcf9fa  jmp 0x00007E95E7FCF566
00007e95e7fcf9ff  vxorps xmm0, xmm15, xmm14
00007e95e7fcfa04  pextrw eax, xmm0, 0x03
00007e95e7fcfa09  and eax, 0x7FF8
00007e95e7fcfa0e  cmp eax, 0x08
00007e95e7fcfa11  jnz 0x00007E95E7FCF566
00007e95e7fcfa17  movq rax, xmm14
00007e95e7fcfa1c  shl rax, 0x0D
00007e95e7fcfa20  jbe 0x00007E95E7FCF566
00007e95e7fcfa26  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fcfa2e  jmp 0x00007E95E7FCF566
00007e95e7fcfa33  ucomisd xmm1, xmm15
00007e95e7fcfa38  jp 0x00007E95E7FCFA47
00007e95e7fcfa3a  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcfa42  jmp 0x00007E95E7FCF59B
00007e95e7fcfa47  vxorps xmm0, xmm1, xmm15
00007e95e7fcfa4c  pextrw eax, xmm0, 0x03
00007e95e7fcfa51  and eax, 0x7FF8
00007e95e7fcfa56  cmp eax, 0x08
00007e95e7fcfa59  jnz 0x00007E95E7FCF59B
00007e95e7fcfa5f  movq rax, xmm15
00007e95e7fcfa64  shl rax, 0x0D
00007e95e7fcfa68  jbe 0x00007E95E7FCF59B
00007e95e7fcfa6e  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcfa76  jmp 0x00007E95E7FCF59B
00007e95e7fcfa7b  call 0x00007E95E7E0A4B0
00007e95e7fcfa80  jmp 0x00007E95E7FCF5AD
00007e95e7fcfa85  ucomisd xmm15, xmm14
00007e95e7fcfa8a  jp 0x00007E95E7FCFA99
00007e95e7fcfa8c  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fcfa94  jmp 0x00007E95E7FCF5DA
00007e95e7fcfa99  vxorps xmm0, xmm15, xmm14
00007e95e7fcfa9e  pextrw eax, xmm0, 0x03
00007e95e7fcfaa3  and eax, 0x7FF8
00007e95e7fcfaa8  cmp eax, 0x08
00007e95e7fcfaab  jnz 0x00007E95E7FCF5DA
00007e95e7fcfab1  movq rax, xmm14
00007e95e7fcfab6  shl rax, 0x0D
00007e95e7fcfaba  jbe 0x00007E95E7FCF5DA
00007e95e7fcfac0  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fcfac8  jmp 0x00007E95E7FCF5DA
00007e95e7fcfacd  ucomisd xmm1, xmm15
00007e95e7fcfad2  jp 0x00007E95E7FCFAE1
00007e95e7fcfad4  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcfadc  jmp 0x00007E95E7FCF60F
00007e95e7fcfae1  vxorps xmm0, xmm1, xmm15
00007e95e7fcfae6  pextrw eax, xmm0, 0x03
00007e95e7fcfaeb  and eax, 0x7FF8
00007e95e7fcfaf0  cmp eax, 0x08
00007e95e7fcfaf3  jnz 0x00007E95E7FCF60F
00007e95e7fcfaf9  movq rax, xmm15
00007e95e7fcfafe  shl rax, 0x0D
00007e95e7fcfb02  jbe 0x00007E95E7FCF60F
00007e95e7fcfb08  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcfb10  jmp 0x00007E95E7FCF60F
00007e95e7fcfb15  call 0x00007E95E7E0A4B0
00007e95e7fcfb1a  jmp 0x00007E95E7FCF621
00007e95e7fcfb1f  ucomisd xmm15, xmm14
00007e95e7fcfb24  jp 0x00007E95E7FCFB33
00007e95e7fcfb26  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fcfb2e  jmp 0x00007E95E7FCF64E
00007e95e7fcfb33  vxorps xmm0, xmm15, xmm14
00007e95e7fcfb38  pextrw eax, xmm0, 0x03
00007e95e7fcfb3d  and eax, 0x7FF8
00007e95e7fcfb42  cmp eax, 0x08
00007e95e7fcfb45  jnz 0x00007E95E7FCF64E
00007e95e7fcfb4b  movq rax, xmm14
00007e95e7fcfb50  shl rax, 0x0D
00007e95e7fcfb54  jbe 0x00007E95E7FCF64E
00007e95e7fcfb5a  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fcfb62  jmp 0x00007E95E7FCF64E
00007e95e7fcfb67  ucomisd xmm1, xmm15
00007e95e7fcfb6c  jp 0x00007E95E7FCFB7B
00007e95e7fcfb6e  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcfb76  jmp 0x00007E95E7FCF683
00007e95e7fcfb7b  vxorps xmm0, xmm1, xmm15
00007e95e7fcfb80  pextrw eax, xmm0, 0x03
00007e95e7fcfb85  and eax, 0x7FF8
00007e95e7fcfb8a  cmp eax, 0x08
00007e95e7fcfb8d  jnz 0x00007E95E7FCF683
00007e95e7fcfb93  movq rax, xmm15
00007e95e7fcfb98  shl rax, 0x0D
00007e95e7fcfb9c  jbe 0x00007E95E7FCF683
00007e95e7fcfba2  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcfbaa  jmp 0x00007E95E7FCF683
00007e95e7fcfbaf  call 0x00007E95E7E0A4B0
00007e95e7fcfbb4  jmp 0x00007E95E7FCF695
00007e95e7fcfbb9  ucomisd xmm15, xmm14
00007e95e7fcfbbe  jp 0x00007E95E7FCFBCD
00007e95e7fcfbc0  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fcfbc8  jmp 0x00007E95E7FCF6C2
00007e95e7fcfbcd  vxorps xmm0, xmm15, xmm14
00007e95e7fcfbd2  pextrw eax, xmm0, 0x03
00007e95e7fcfbd7  and eax, 0x7FF8
00007e95e7fcfbdc  cmp eax, 0x08
00007e95e7fcfbdf  jnz 0x00007E95E7FCF6C2
00007e95e7fcfbe5  movq rax, xmm14
00007e95e7fcfbea  shl rax, 0x0D
00007e95e7fcfbee  jbe 0x00007E95E7FCF6C2
00007e95e7fcfbf4  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fcfbfc  jmp 0x00007E95E7FCF6C2
00007e95e7fcfc01  ucomisd xmm1, xmm15
00007e95e7fcfc06  jp 0x00007E95E7FCFC15
00007e95e7fcfc08  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcfc10  jmp 0x00007E95E7FCF6F7
00007e95e7fcfc15  vxorps xmm0, xmm1, xmm15
00007e95e7fcfc1a  pextrw eax, xmm0, 0x03
00007e95e7fcfc1f  and eax, 0x7FF8
00007e95e7fcfc24  cmp eax, 0x08
00007e95e7fcfc27  jnz 0x00007E95E7FCF6F7
00007e95e7fcfc2d  movq rax, xmm15
00007e95e7fcfc32  shl rax, 0x0D
00007e95e7fcfc36  jbe 0x00007E95E7FCF6F7
00007e95e7fcfc3c  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcfc44  jmp 0x00007E95E7FCF6F7
00007e95e7fcfc49  call 0x00007E95E7E0B720
00007e95e7fcfc4e  jmp 0x00007E95E7FCF709
00007e95e7fcfc53  ucomisd xmm15, xmm14
00007e95e7fcfc58  jp 0x00007E95E7FCFC67
00007e95e7fcfc5a  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fcfc62  jmp 0x00007E95E7FCF73E
00007e95e7fcfc67  vxorps xmm0, xmm15, xmm14
00007e95e7fcfc6c  pextrw eax, xmm0, 0x03
00007e95e7fcfc71  and eax, 0x7FF8
00007e95e7fcfc76  cmp eax, 0x08
00007e95e7fcfc79  jnz 0x00007E95E7FCF73E
00007e95e7fcfc7f  movq rax, xmm14
00007e95e7fcfc84  shl rax, 0x0D
00007e95e7fcfc88  jbe 0x00007E95E7FCF73E
00007e95e7fcfc8e  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fcfc96  jmp 0x00007E95E7FCF73E
00007e95e7fcfc9b  ucomisd xmm1, xmm15
00007e95e7fcfca0  jp 0x00007E95E7FCFCAF
00007e95e7fcfca2  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcfcaa  jmp 0x00007E95E7FCF773
00007e95e7fcfcaf  vxorps xmm0, xmm1, xmm15
00007e95e7fcfcb4  pextrw eax, xmm0, 0x03
00007e95e7fcfcb9  and eax, 0x7FF8
00007e95e7fcfcbe  cmp eax, 0x08
00007e95e7fcfcc1  jnz 0x00007E95E7FCF773
00007e95e7fcfcc7  movq rax, xmm15
00007e95e7fcfccc  shl rax, 0x0D
00007e95e7fcfcd0  jbe 0x00007E95E7FCF773
00007e95e7fcfcd6  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcfcde  jmp 0x00007E95E7FCF773
00007e95e7fcfce3  ucomisd xmm1, xmm15
00007e95e7fcfce8  jp 0x00007E95E7FCFCF7
00007e95e7fcfcea  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fcfcf2  jmp 0x00007E95E7FCF7A8
00007e95e7fcfcf7  vxorps xmm0, xmm1, xmm15
00007e95e7fcfcfc  pextrw eax, xmm0, 0x03
00007e95e7fcfd01  and eax, 0x7FF8
00007e95e7fcfd06  cmp eax, 0x08
00007e95e7fcfd09  jnz 0x00007E95E7FCF7A8
00007e95e7fcfd0f  movq rax, xmm15
00007e95e7fcfd14  shl rax, 0x0D
00007e95e7fcfd18  jbe 0x00007E95E7FCF7A8
00007e95e7fcfd1e  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fcfd26  jmp 0x00007E95E7FCF7A8
00007e95e7fcfd2b  call 0x00007E95E7EB4CB0
00007e95e7fcfd30  jmp 0x00007E95E7FCF7C7
00007e95e7fcfd35  int3
00007e95e7fcfd36  nop [rax+rax*1], ax
00007e95e7fcfd3f  nop
00007e95e7fcfd40  mov rax, [r15+0x60]
00007e95e7fcfd44  lea r14, [rax+0x01]
00007e95e7fcfd48  mov [r15+0x60], r14
00007e95e7fcfd4c  mov rax, [r15+0x68]
00007e95e7fcfd50  lea r12, [rax+0x40]
00007e95e7fcfd54  mov [r15+0x68], r12
00007e95e7fcfd58  xor eax, eax
00007e95e7fcfd5a  mov r12d, 0x08
00007e95e7fcfd60  cmp r14, r12
00007e95e7fcfd63  cmc
00007e95e7fcfd64  lahf
00007e95e7fcfd65  seto al
00007e95e7fcfd68  mov [r15+0x108], eax
00007e95e7fcfd6f  mov eax, [r15+0x108]
00007e95e7fcfd76  sahf
00007e95e7fcfd77  jnz 0x00007E95E7FCFDA9
00007e95e7fcfd79  cmp dword ptr [r15+0x318], 0x00
00007e95e7fcfd81  jz 0x00007E95E7FD08A0
00007e95e7fcfd87  nop [rax+rax*1], ax
00007e95e7fcfd90  nop [rax+rax*1], eax
00007e95e7fcfd98  mov eax, 0x410128
00007e95e7fcfd9d  mov [r15+0x100], rax
00007e95e7fcfda4  jmp 0x00007E95E7DFE110
00007e95e7fcfda9  cmp dword ptr [r15+0x318], 0x00
00007e95e7fcfdb1  jz 0x00007E95E7FCFDE0
00007e95e7fcfdb7  nop [rax+rax*1], ax
00007e95e7fcfdc0  nop [rax+rax*1], eax
00007e95e7fcfdc8  mov eax, 0x41008C
00007e95e7fcfdcd  mov [r15+0x100], rax
00007e95e7fcfdd4  jmp 0x00007E95E7DFE110
00007e95e7fcfdd9  int3
00007e95e7fcfdda  int3
00007e95e7fcfddb  nop [rax+rax*1], eax
00007e95e7fcfde0  mov rax, [r15+0x40]
00007e95e7fcfde4  mov r14, [r15+0x60]
00007e95e7fcfde8  shl r14, 0x06
00007e95e7fcfdec  lea r12, [rax+r14*1]
00007e95e7fcfdf0  mov rax, [r13+r12*1]
00007e95e7fcfdf5  lea r14, [r12+0x08]
00007e95e7fcfdfa  mov r11, [r13+r14*1]
00007e95e7fcfdff  movq xmm1, rax
00007e95e7fcfe04  movq xmm15, r11
00007e95e7fcfe09  movq xmm1, xmm1
00007e95e7fcfe0d  movq xmm1, xmm1
00007e95e7fcfe11  movaps [r15+0x120], xmm1
00007e95e7fcfe19  movq xmm15, xmm15
00007e95e7fcfe1e  movq xmm15, xmm15
00007e95e7fcfe23  movaps [r15+0x130], xmm15
00007e95e7fcfe2b  lea rax, [r12+0x10]
00007e95e7fcfe30  mov r14, [r13+rax*1]
00007e95e7fcfe35  lea rax, [r12+0x18]
00007e95e7fcfe3a  mov r11, [r13+rax*1]
00007e95e7fcfe3f  movq xmm1, r14
00007e95e7fcfe44  movq xmm15, r11
00007e95e7fcfe49  movq xmm1, xmm1
00007e95e7fcfe4d  movq xmm1, xmm1
00007e95e7fcfe51  movaps [r15+0x140], xmm1
00007e95e7fcfe59  movq xmm15, xmm15
00007e95e7fcfe5e  movq xmm15, xmm15
00007e95e7fcfe63  movaps [r15+0x150], xmm15
00007e95e7fcfe6b  lea rax, [r12+0x20]
00007e95e7fcfe70  mov r14, [r13+rax*1]
00007e95e7fcfe75  lea rax, [r12+0x28]
00007e95e7fcfe7a  mov r11, [r13+rax*1]
00007e95e7fcfe7f  movq xmm1, r14
00007e95e7fcfe84  movq xmm15, r11
00007e95e7fcfe89  movq xmm1, xmm1
00007e95e7fcfe8d  movq xmm1, xmm1
00007e95e7fcfe91  movaps [r15+0x160], xmm1
00007e95e7fcfe99  movq xmm15, xmm15
00007e95e7fcfe9e  movq xmm15, xmm15
00007e95e7fcfea3  movaps [r15+0x170], xmm15
00007e95e7fcfeab  lea rax, [r12+0x30]
00007e95e7fcfeb0  mov r14, [r13+rax*1]
00007e95e7fcfeb5  lea rax, [r12+0x38]
00007e95e7fcfeba  mov r12, [r13+rax*1]
00007e95e7fcfebf  movq xmm1, r14
00007e95e7fcfec4  movq xmm15, r12
00007e95e7fcfec9  movq xmm1, xmm1
00007e95e7fcfecd  movq xmm1, xmm1
00007e95e7fcfed1  movaps [r15+0x180], xmm1
00007e95e7fcfed9  movq xmm15, xmm15
00007e95e7fcfede  movq xmm15, xmm15
00007e95e7fcfee3  movaps [r15+0x210], xmm15
00007e95e7fcfeeb  mov rax, [r15+0x48]
00007e95e7fcfeef  mov [r15+0x78], rax
00007e95e7fcfef3  mov r14, [r13+rax*1]
00007e95e7fcfef8  movq xmm1, r14
00007e95e7fcfefd  lea r14, [rax+0x40]
00007e95e7fcff01  mov r12, [r13+r14*1]
00007e95e7fcff06  movq xmm15, r12
00007e95e7fcff0b  lea r14, [rax+0x80]
00007e95e7fcff12  mov r12, [r13+r14*1]
00007e95e7fcff17  movq xmm14, r12
00007e95e7fcff1c  movaps xmm13, [r15+0x120]
00007e95e7fcff24  movq r14, xmm13
00007e95e7fcff29  movq r12, xmm1
00007e95e7fcff2e  vmovq xmm1, r14
00007e95e7fcff33  vmovq xmm13, r12
00007e95e7fcff38  movaps xmm12, xmm1
00007e95e7fcff3c  mulsd xmm12, xmm13
00007e95e7fcff41  ucomisd xmm12, xmm12
00007e95e7fcff46  jp 0x00007E95E7FD03AD
00007e95e7fcff4c  movq xmm12, xmm12
00007e95e7fcff51  movaps xmm1, [r15+0x130]
00007e95e7fcff59  movq r14, xmm1
00007e95e7fcff5e  movq r12, xmm15
00007e95e7fcff63  vmovq xmm1, r14
00007e95e7fcff68  vmovq xmm15, r12
00007e95e7fcff6d  movaps xmm13, xmm1
00007e95e7fcff71  mulsd xmm13, xmm15
00007e95e7fcff76  ucomisd xmm13, xmm13
00007e95e7fcff7b  jp 0x00007E95E7FD03F9
00007e95e7fcff81  movq xmm13, xmm13
00007e95e7fcff86  movq r14, xmm12
00007e95e7fcff8b  movaps xmm1, [r15+0x110]
00007e95e7fcff93  movq r12, xmm1
00007e95e7fcff98  vmovq xmm1, r14
00007e95e7fcff9d  vmovq xmm15, r12
00007e95e7fcffa2  movaps xmm12, xmm1
00007e95e7fcffa6  addsd xmm12, xmm15
00007e95e7fcffab  ucomisd xmm12, xmm12
00007e95e7fcffb0  jp 0x00007E95E7FD0445
00007e95e7fcffb6  movq xmm12, xmm12
00007e95e7fcffbb  movq r14, xmm12
00007e95e7fcffc0  movq r12, xmm13
00007e95e7fcffc5  vmovq xmm1, r14
00007e95e7fcffca  vmovq xmm15, r12
00007e95e7fcffcf  movaps xmm13, xmm1
00007e95e7fcffd3  addsd xmm13, xmm15
00007e95e7fcffd8  ucomisd xmm13, xmm13
00007e95e7fcffdd  jp 0x00007E95E7FD0491
00007e95e7fcffe3  movq xmm13, xmm13
00007e95e7fcffe8  movaps xmm1, [r15+0x140]
00007e95e7fcfff0  movq r14, xmm1
00007e95e7fcfff5  movq r12, xmm14
00007e95e7fcfffa  vmovq xmm1, r14
00007e95e7fcffff  vmovq xmm15, r12
00007e95e7fd0004  movaps xmm14, xmm1
00007e95e7fd0008  mulsd xmm14, xmm15
00007e95e7fd000d  ucomisd xmm14, xmm14
00007e95e7fd0012  jp 0x00007E95E7FD04DD
00007e95e7fd0018  movq xmm14, xmm14
00007e95e7fd001d  lea r14, [rax+0xC0]
00007e95e7fd0024  mov r12, [r13+r14*1]
00007e95e7fd0029  movq xmm1, r12
00007e95e7fd002e  movq r14, xmm13
00007e95e7fd0033  movq r12, xmm14
00007e95e7fd0038  vmovq xmm15, r14
00007e95e7fd003d  vmovq xmm14, r12
00007e95e7fd0042  movaps xmm13, xmm15
00007e95e7fd0046  addsd xmm13, xmm14
00007e95e7fd004b  ucomisd xmm13, xmm13
00007e95e7fd0050  jp 0x00007E95E7FD0533
00007e95e7fd0056  movq xmm13, xmm13
00007e95e7fd005b  movaps xmm15, [r15+0x150]
00007e95e7fd0063  movq r14, xmm15
00007e95e7fd0068  movq r12, xmm1
00007e95e7fd006d  vmovq xmm1, r14
00007e95e7fd0072  vmovq xmm15, r12
00007e95e7fd0077  movaps xmm14, xmm1
00007e95e7fd007b  mulsd xmm14, xmm15
00007e95e7fd0080  ucomisd xmm14, xmm14
00007e95e7fd0085  jp 0x00007E95E7FD057F
00007e95e7fd008b  movq xmm14, xmm14
00007e95e7fd0090  lea r14, [rax+0x100]
00007e95e7fd0097  mov r12, [r13+r14*1]
00007e95e7fd009c  movq xmm1, r12
00007e95e7fd00a1  movq r14, xmm13
00007e95e7fd00a6  movq r12, xmm14
00007e95e7fd00ab  vmovq xmm15, r14
00007e95e7fd00b0  vmovq xmm14, r12
00007e95e7fd00b5  movaps xmm13, xmm15
00007e95e7fd00b9  addsd xmm13, xmm14
00007e95e7fd00be  ucomisd xmm13, xmm13
00007e95e7fd00c3  jp 0x00007E95E7FD05D5
00007e95e7fd00c9  movq xmm13, xmm13
00007e95e7fd00ce  movaps xmm15, [r15+0x160]
00007e95e7fd00d6  movq r14, xmm15
00007e95e7fd00db  movq r12, xmm1
00007e95e7fd00e0  vmovq xmm1, r14
00007e95e7fd00e5  vmovq xmm15, r12
00007e95e7fd00ea  movaps xmm14, xmm1
00007e95e7fd00ee  mulsd xmm14, xmm15
00007e95e7fd00f3  ucomisd xmm14, xmm14
00007e95e7fd00f8  jp 0x00007E95E7FD0621
00007e95e7fd00fe  movq xmm14, xmm14
00007e95e7fd0103  lea r14, [rax+0x140]
00007e95e7fd010a  mov r12, [r13+r14*1]
00007e95e7fd010f  movq xmm1, r12
00007e95e7fd0114  movq r14, xmm13
00007e95e7fd0119  movq r12, xmm14
00007e95e7fd011e  vmovq xmm15, r14
00007e95e7fd0123  vmovq xmm14, r12
00007e95e7fd0128  movaps xmm13, xmm15
00007e95e7fd012c  addsd xmm13, xmm14
00007e95e7fd0131  ucomisd xmm13, xmm13
00007e95e7fd0136  jp 0x00007E95E7FD0677
00007e95e7fd013c  movq xmm13, xmm13
00007e95e7fd0141  movaps xmm15, [r15+0x170]
00007e95e7fd0149  movq r14, xmm15
00007e95e7fd014e  movq r12, xmm1
00007e95e7fd0153  vmovq xmm1, r14
00007e95e7fd0158  vmovq xmm15, r12
00007e95e7fd015d  movaps xmm14, xmm1
00007e95e7fd0161  mulsd xmm14, xmm15
00007e95e7fd0166  ucomisd xmm14, xmm14
00007e95e7fd016b  jp 0x00007E95E7FD06C3
00007e95e7fd0171  movq xmm14, xmm14
00007e95e7fd0176  lea r14, [rax+0x180]
00007e95e7fd017d  mov r12, [r13+r14*1]
00007e95e7fd0182  movq xmm1, r12
00007e95e7fd0187  movq r14, xmm13
00007e95e7fd018c  movq r12, xmm14
00007e95e7fd0191  vmovq xmm15, r14
00007e95e7fd0196  vmovq xmm14, r12
00007e95e7fd019b  movaps xmm13, xmm15
00007e95e7fd019f  addsd xmm13, xmm14
00007e95e7fd01a4  ucomisd xmm13, xmm13
00007e95e7fd01a9  jp 0x00007E95E7FD0719
00007e95e7fd01af  movq xmm13, xmm13
00007e95e7fd01b4  movaps xmm15, [r15+0x180]
00007e95e7fd01bc  movq r14, xmm15
00007e95e7fd01c1  movq r12, xmm1
00007e95e7fd01c6  vmovq xmm1, r14
00007e95e7fd01cb  vmovq xmm15, r12
00007e95e7fd01d0  movaps xmm14, xmm1
00007e95e7fd01d4  mulsd xmm14, xmm15
00007e95e7fd01d9  ucomisd xmm14, xmm14
00007e95e7fd01de  jp 0x00007E95E7FD0765
00007e95e7fd01e4  movq xmm14, xmm14
00007e95e7fd01e9  lea r14, [rax+0x1C0]
00007e95e7fd01f0  mov rax, [r13+r14*1]
00007e95e7fd01f5  movq xmm1, rax
00007e95e7fd01fa  movaps [r15+0x240], xmm1
00007e95e7fd0202  movq rax, xmm13
00007e95e7fd0207  movq r14, xmm14
00007e95e7fd020c  vmovq xmm15, rax
00007e95e7fd0211  vmovq xmm14, r14
00007e95e7fd0216  movaps xmm13, xmm15
00007e95e7fd021a  addsd xmm13, xmm14
00007e95e7fd021f  ucomisd xmm13, xmm13
00007e95e7fd0224  jp 0x00007E95E7FD07BB
00007e95e7fd022a  movq xmm13, xmm13
00007e95e7fd022f  movaps xmm15, [r15+0x210]
00007e95e7fd0237  movq rax, xmm15
00007e95e7fd023c  movq r14, xmm1
00007e95e7fd0241  vmovq xmm1, rax
00007e95e7fd0246  vmovq xmm15, r14
00007e95e7fd024b  movaps xmm14, xmm1
00007e95e7fd024f  mulsd xmm14, xmm15
00007e95e7fd0254  ucomisd xmm14, xmm14
00007e95e7fd0259  jp 0x00007E95E7FD0803
00007e95e7fd025f  movq xmm14, xmm14
00007e95e7fd0264  movaps [r15+0x230], xmm14
00007e95e7fd026c  movq rax, xmm13
00007e95e7fd0271  movq r14, xmm14
00007e95e7fd0276  vmovq xmm1, rax
00007e95e7fd027b  vmovq xmm15, r14
00007e95e7fd0280  movaps xmm14, xmm1
00007e95e7fd0284  addsd xmm14, xmm15
00007e95e7fd0289  ucomisd xmm14, xmm14
00007e95e7fd028e  jp 0x00007E95E7FD084B
00007e95e7fd0294  movq xmm14, xmm14
00007e95e7fd0299  movaps [r15+0x220], xmm14
00007e95e7fd02a1  mov rax, [r15+0x68]
00007e95e7fd02a5  movq r14, xmm14
00007e95e7fd02aa  mov [r13+rax*1], r14
00007e95e7fd02af  mov qword ptr [r15+0x70], 0x08
00007e95e7fd02b7  xor eax, eax
00007e95e7fd02b9  mov r14d, 0x08
00007e95e7fd02bf  mov r12d, 0x40
00007e95e7fd02c5  cmp r14, r12
00007e95e7fd02c8  cmc
00007e95e7fd02c9  lahf
00007e95e7fd02ca  seto al
00007e95e7fd02cd  mov [r15+0x108], eax
00007e95e7fd02d4  mov eax, [r15+0x108]
00007e95e7fd02db  sahf
00007e95e7fd02dc  jnz 0x00007E95E7FD030E
00007e95e7fd02de  cmp dword ptr [r15+0x318], 0x00
00007e95e7fd02e6  jz 0x00007E95E7FCFD40
00007e95e7fd02ec  nop [rax+rax*1], ax
00007e95e7fd02f5  nop [rax+rax*1], eax
00007e95e7fd02fd  mov eax, 0x410118
00007e95e7fd0302  mov [r15+0x100], rax
00007e95e7fd0309  jmp 0x00007E95E7DFE110
00007e95e7fd030e  cmp dword ptr [r15+0x318], 0x00
00007e95e7fd0316  jz 0x00007E95E7FCF3F0
00007e95e7fd031c  nop [rax+rax*1], ax
00007e95e7fd0325  nop [rax+rax*1], eax
00007e95e7fd032d  mov eax, 0x4100A4
00007e95e7fd0332  mov [r15+0x100], rax
00007e95e7fd0339  jmp 0x00007E95E7DFE110
00007e95e7fd033e  int3
00007e95e7fd033f  call 0x00007E95E7EB47C0
00007e95e7fd0344  jmp 0x00007E95E7FCFDF5
00007e95e7fd0349  call 0x00007E95E7EE1570
00007e95e7fd034e  jmp 0x00007E95E7FCFDFF
00007e95e7fd0353  call 0x00007E95E7E0DC20
00007e95e7fd0358  jmp 0x00007E95E7FCFE35
00007e95e7fd035d  call 0x00007E95E7E0A4B0
00007e95e7fd0362  jmp 0x00007E95E7FCFE3F
00007e95e7fd0367  call 0x00007E95E7E0DC20
00007e95e7fd036c  jmp 0x00007E95E7FCFE75
00007e95e7fd0371  call 0x00007E95E7E0A4B0
00007e95e7fd0376  jmp 0x00007E95E7FCFE7F
00007e95e7fd037b  call 0x00007E95E7E0DC20
00007e95e7fd0380  jmp 0x00007E95E7FCFEB5
00007e95e7fd0385  call 0x00007E95E7E0B720
00007e95e7fd038a  jmp 0x00007E95E7FCFEBF
00007e95e7fd038f  call 0x00007E95E7E0DC20
00007e95e7fd0394  jmp 0x00007E95E7FCFEF8
00007e95e7fd0399  call 0x00007E95E7EE27E0
00007e95e7fd039e  jmp 0x00007E95E7FCFF06
00007e95e7fd03a3  call 0x00007E95E7EE27E0
00007e95e7fd03a8  jmp 0x00007E95E7FCFF17
00007e95e7fd03ad  ucomisd xmm1, xmm13
00007e95e7fd03b2  jp 0x00007E95E7FD03C1
00007e95e7fd03b4  movaps xmm12, [0x00007E95E7BFE030]
00007e95e7fd03bc  jmp 0x00007E95E7FCFF4C
00007e95e7fd03c1  vxorps xmm0, xmm1, xmm13
00007e95e7fd03c6  pextrw r14d, xmm0, 0x03
00007e95e7fd03cc  and r14d, 0x7FF8
00007e95e7fd03d3  cmp r14d, 0x08
00007e95e7fd03d7  jnz 0x00007E95E7FCFF4C
00007e95e7fd03dd  movq r14, xmm13
00007e95e7fd03e2  shl r14, 0x0D
00007e95e7fd03e6  jbe 0x00007E95E7FCFF4C
00007e95e7fd03ec  vorps xmm12, xmm13, [0x00007E95E7BFE040]
00007e95e7fd03f4  jmp 0x00007E95E7FCFF4C
00007e95e7fd03f9  ucomisd xmm1, xmm15
00007e95e7fd03fe  jp 0x00007E95E7FD040D
00007e95e7fd0400  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd0408  jmp 0x00007E95E7FCFF81
00007e95e7fd040d  vxorps xmm0, xmm1, xmm15
00007e95e7fd0412  pextrw r14d, xmm0, 0x03
00007e95e7fd0418  and r14d, 0x7FF8
00007e95e7fd041f  cmp r14d, 0x08
00007e95e7fd0423  jnz 0x00007E95E7FCFF81
00007e95e7fd0429  movq r14, xmm15
00007e95e7fd042e  shl r14, 0x0D
00007e95e7fd0432  jbe 0x00007E95E7FCFF81
00007e95e7fd0438  vorps xmm13, xmm15, [0x00007E95E7BFE040]
00007e95e7fd0440  jmp 0x00007E95E7FCFF81
00007e95e7fd0445  ucomisd xmm1, xmm15
00007e95e7fd044a  jp 0x00007E95E7FD0459
00007e95e7fd044c  movaps xmm12, [0x00007E95E7BFE030]
00007e95e7fd0454  jmp 0x00007E95E7FCFFB6
00007e95e7fd0459  vxorps xmm0, xmm1, xmm15
00007e95e7fd045e  pextrw r14d, xmm0, 0x03
00007e95e7fd0464  and r14d, 0x7FF8
00007e95e7fd046b  cmp r14d, 0x08
00007e95e7fd046f  jnz 0x00007E95E7FCFFB6
00007e95e7fd0475  movq r14, xmm15
00007e95e7fd047a  shl r14, 0x0D
00007e95e7fd047e  jbe 0x00007E95E7FCFFB6
00007e95e7fd0484  vorps xmm12, xmm15, [0x00007E95E7BFE040]
00007e95e7fd048c  jmp 0x00007E95E7FCFFB6
00007e95e7fd0491  ucomisd xmm1, xmm15
00007e95e7fd0496  jp 0x00007E95E7FD04A5
00007e95e7fd0498  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd04a0  jmp 0x00007E95E7FCFFE3
00007e95e7fd04a5  vxorps xmm0, xmm1, xmm15
00007e95e7fd04aa  pextrw r14d, xmm0, 0x03
00007e95e7fd04b0  and r14d, 0x7FF8
00007e95e7fd04b7  cmp r14d, 0x08
00007e95e7fd04bb  jnz 0x00007E95E7FCFFE3
00007e95e7fd04c1  movq r14, xmm15
00007e95e7fd04c6  shl r14, 0x0D
00007e95e7fd04ca  jbe 0x00007E95E7FCFFE3
00007e95e7fd04d0  vorps xmm13, xmm15, [0x00007E95E7BFE040]
00007e95e7fd04d8  jmp 0x00007E95E7FCFFE3
00007e95e7fd04dd  ucomisd xmm1, xmm15
00007e95e7fd04e2  jp 0x00007E95E7FD04F1
00007e95e7fd04e4  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd04ec  jmp 0x00007E95E7FD0018
00007e95e7fd04f1  vxorps xmm0, xmm1, xmm15
00007e95e7fd04f6  pextrw r14d, xmm0, 0x03
00007e95e7fd04fc  and r14d, 0x7FF8
00007e95e7fd0503  cmp r14d, 0x08
00007e95e7fd0507  jnz 0x00007E95E7FD0018
00007e95e7fd050d  movq r14, xmm15
00007e95e7fd0512  shl r14, 0x0D
00007e95e7fd0516  jbe 0x00007E95E7FD0018
00007e95e7fd051c  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd0524  jmp 0x00007E95E7FD0018
00007e95e7fd0529  call 0x00007E95E7EE27E0
00007e95e7fd052e  jmp 0x00007E95E7FD0029
00007e95e7fd0533  ucomisd xmm15, xmm14
00007e95e7fd0538  jp 0x00007E95E7FD0547
00007e95e7fd053a  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd0542  jmp 0x00007E95E7FD0056
00007e95e7fd0547  vxorps xmm0, xmm15, xmm14
00007e95e7fd054c  pextrw r14d, xmm0, 0x03
00007e95e7fd0552  and r14d, 0x7FF8
00007e95e7fd0559  cmp r14d, 0x08
00007e95e7fd055d  jnz 0x00007E95E7FD0056
00007e95e7fd0563  movq r14, xmm14
00007e95e7fd0568  shl r14, 0x0D
00007e95e7fd056c  jbe 0x00007E95E7FD0056
00007e95e7fd0572  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fd057a  jmp 0x00007E95E7FD0056
00007e95e7fd057f  ucomisd xmm1, xmm15
00007e95e7fd0584  jp 0x00007E95E7FD0593
00007e95e7fd0586  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd058e  jmp 0x00007E95E7FD008B
00007e95e7fd0593  vxorps xmm0, xmm1, xmm15
00007e95e7fd0598  pextrw r14d, xmm0, 0x03
00007e95e7fd059e  and r14d, 0x7FF8
00007e95e7fd05a5  cmp r14d, 0x08
00007e95e7fd05a9  jnz 0x00007E95E7FD008B
00007e95e7fd05af  movq r14, xmm15
00007e95e7fd05b4  shl r14, 0x0D
00007e95e7fd05b8  jbe 0x00007E95E7FD008B
00007e95e7fd05be  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd05c6  jmp 0x00007E95E7FD008B
00007e95e7fd05cb  call 0x00007E95E7EE27E0
00007e95e7fd05d0  jmp 0x00007E95E7FD009C
00007e95e7fd05d5  ucomisd xmm15, xmm14
00007e95e7fd05da  jp 0x00007E95E7FD05E9
00007e95e7fd05dc  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd05e4  jmp 0x00007E95E7FD00C9
00007e95e7fd05e9  vxorps xmm0, xmm15, xmm14
00007e95e7fd05ee  pextrw r14d, xmm0, 0x03
00007e95e7fd05f4  and r14d, 0x7FF8
00007e95e7fd05fb  cmp r14d, 0x08
00007e95e7fd05ff  jnz 0x00007E95E7FD00C9
00007e95e7fd0605  movq r14, xmm14
00007e95e7fd060a  shl r14, 0x0D
00007e95e7fd060e  jbe 0x00007E95E7FD00C9
00007e95e7fd0614  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fd061c  jmp 0x00007E95E7FD00C9
00007e95e7fd0621  ucomisd xmm1, xmm15
00007e95e7fd0626  jp 0x00007E95E7FD0635
00007e95e7fd0628  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd0630  jmp 0x00007E95E7FD00FE
00007e95e7fd0635  vxorps xmm0, xmm1, xmm15
00007e95e7fd063a  pextrw r14d, xmm0, 0x03
00007e95e7fd0640  and r14d, 0x7FF8
00007e95e7fd0647  cmp r14d, 0x08
00007e95e7fd064b  jnz 0x00007E95E7FD00FE
00007e95e7fd0651  movq r14, xmm15
00007e95e7fd0656  shl r14, 0x0D
00007e95e7fd065a  jbe 0x00007E95E7FD00FE
00007e95e7fd0660  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd0668  jmp 0x00007E95E7FD00FE
00007e95e7fd066d  call 0x00007E95E7EE27E0
00007e95e7fd0672  jmp 0x00007E95E7FD010F
00007e95e7fd0677  ucomisd xmm15, xmm14
00007e95e7fd067c  jp 0x00007E95E7FD068B
00007e95e7fd067e  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd0686  jmp 0x00007E95E7FD013C
00007e95e7fd068b  vxorps xmm0, xmm15, xmm14
00007e95e7fd0690  pextrw r14d, xmm0, 0x03
00007e95e7fd0696  and r14d, 0x7FF8
00007e95e7fd069d  cmp r14d, 0x08
00007e95e7fd06a1  jnz 0x00007E95E7FD013C
00007e95e7fd06a7  movq r14, xmm14
00007e95e7fd06ac  shl r14, 0x0D
00007e95e7fd06b0  jbe 0x00007E95E7FD013C
00007e95e7fd06b6  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fd06be  jmp 0x00007E95E7FD013C
00007e95e7fd06c3  ucomisd xmm1, xmm15
00007e95e7fd06c8  jp 0x00007E95E7FD06D7
00007e95e7fd06ca  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd06d2  jmp 0x00007E95E7FD0171
00007e95e7fd06d7  vxorps xmm0, xmm1, xmm15
00007e95e7fd06dc  pextrw r14d, xmm0, 0x03
00007e95e7fd06e2  and r14d, 0x7FF8
00007e95e7fd06e9  cmp r14d, 0x08
00007e95e7fd06ed  jnz 0x00007E95E7FD0171
00007e95e7fd06f3  movq r14, xmm15
00007e95e7fd06f8  shl r14, 0x0D
00007e95e7fd06fc  jbe 0x00007E95E7FD0171
00007e95e7fd0702  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd070a  jmp 0x00007E95E7FD0171
00007e95e7fd070f  call 0x00007E95E7EE27E0
00007e95e7fd0714  jmp 0x00007E95E7FD0182
00007e95e7fd0719  ucomisd xmm15, xmm14
00007e95e7fd071e  jp 0x00007E95E7FD072D
00007e95e7fd0720  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd0728  jmp 0x00007E95E7FD01AF
00007e95e7fd072d  vxorps xmm0, xmm15, xmm14
00007e95e7fd0732  pextrw r14d, xmm0, 0x03
00007e95e7fd0738  and r14d, 0x7FF8
00007e95e7fd073f  cmp r14d, 0x08
00007e95e7fd0743  jnz 0x00007E95E7FD01AF
00007e95e7fd0749  movq r14, xmm14
00007e95e7fd074e  shl r14, 0x0D
00007e95e7fd0752  jbe 0x00007E95E7FD01AF
00007e95e7fd0758  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fd0760  jmp 0x00007E95E7FD01AF
00007e95e7fd0765  ucomisd xmm1, xmm15
00007e95e7fd076a  jp 0x00007E95E7FD0779
00007e95e7fd076c  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd0774  jmp 0x00007E95E7FD01E4
00007e95e7fd0779  vxorps xmm0, xmm1, xmm15
00007e95e7fd077e  pextrw r14d, xmm0, 0x03
00007e95e7fd0784  and r14d, 0x7FF8
00007e95e7fd078b  cmp r14d, 0x08
00007e95e7fd078f  jnz 0x00007E95E7FD01E4
00007e95e7fd0795  movq r14, xmm15
00007e95e7fd079a  shl r14, 0x0D
00007e95e7fd079e  jbe 0x00007E95E7FD01E4
00007e95e7fd07a4  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd07ac  jmp 0x00007E95E7FD01E4
00007e95e7fd07b1  call 0x00007E95E7ED59C0
00007e95e7fd07b6  jmp 0x00007E95E7FD01F5
00007e95e7fd07bb  ucomisd xmm15, xmm14
00007e95e7fd07c0  jp 0x00007E95E7FD07CF
00007e95e7fd07c2  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd07ca  jmp 0x00007E95E7FD022A
00007e95e7fd07cf  vxorps xmm0, xmm15, xmm14
00007e95e7fd07d4  pextrw eax, xmm0, 0x03
00007e95e7fd07d9  and eax, 0x7FF8
00007e95e7fd07de  cmp eax, 0x08
00007e95e7fd07e1  jnz 0x00007E95E7FD022A
00007e95e7fd07e7  movq rax, xmm14
00007e95e7fd07ec  shl rax, 0x0D
00007e95e7fd07f0  jbe 0x00007E95E7FD022A
00007e95e7fd07f6  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fd07fe  jmp 0x00007E95E7FD022A
00007e95e7fd0803  ucomisd xmm1, xmm15
00007e95e7fd0808  jp 0x00007E95E7FD0817
00007e95e7fd080a  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd0812  jmp 0x00007E95E7FD025F
00007e95e7fd0817  vxorps xmm0, xmm1, xmm15
00007e95e7fd081c  pextrw eax, xmm0, 0x03
00007e95e7fd0821  and eax, 0x7FF8
00007e95e7fd0826  cmp eax, 0x08
00007e95e7fd0829  jnz 0x00007E95E7FD025F
00007e95e7fd082f  movq rax, xmm15
00007e95e7fd0834  shl rax, 0x0D
00007e95e7fd0838  jbe 0x00007E95E7FD025F
00007e95e7fd083e  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd0846  jmp 0x00007E95E7FD025F
00007e95e7fd084b  ucomisd xmm1, xmm15
00007e95e7fd0850  jp 0x00007E95E7FD085F
00007e95e7fd0852  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd085a  jmp 0x00007E95E7FD0294
00007e95e7fd085f  vxorps xmm0, xmm1, xmm15
00007e95e7fd0864  pextrw eax, xmm0, 0x03
00007e95e7fd0869  and eax, 0x7FF8
00007e95e7fd086e  cmp eax, 0x08
00007e95e7fd0871  jnz 0x00007E95E7FD0294
00007e95e7fd0877  movq rax, xmm15
00007e95e7fd087c  shl rax, 0x0D
00007e95e7fd0880  jbe 0x00007E95E7FD0294
00007e95e7fd0886  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd088e  jmp 0x00007E95E7FD0294
00007e95e7fd0893  call 0x00007E95E7E0E120
00007e95e7fd0898  jmp 0x00007E95E7FD02AF
00007e95e7fd089d  int3
00007e95e7fd089e  nop
00007e95e7fd08a0  mov eax, [r15+0x58]
00007e95e7fd08a4  lea r14d, [eax+0x01]
00007e95e7fd08a9  mov [rsp+0x10], r14d
00007e95e7fd08ae  mov r14d, r14d
00007e95e7fd08b1  mov [r15+0x58], r14
00007e95e7fd08b5  xor eax, eax
00007e95e7fd08b7  mov r14d, [rsp+0x10]
00007e95e7fd08bc  cmp r14d, 0x1F4
00007e95e7fd08c3  cmc
00007e95e7fd08c4  lahf
00007e95e7fd08c5  seto al
00007e95e7fd08c8  mov [r15+0x108], eax
00007e95e7fd08cf  mov eax, [r15+0x108]
00007e95e7fd08d6  sahf
00007e95e7fd08d7  jnz 0x00007E95E7FD0909
00007e95e7fd08d9  cmp dword ptr [r15+0x318], 0x00
00007e95e7fd08e1  jz 0x00007E95E7FD1410
00007e95e7fd08e7  nop [rax+rax*1], ax
00007e95e7fd08f0  nop [rax+rax*1], eax
00007e95e7fd08f8  mov eax, 0x410134
00007e95e7fd08fd  mov [r15+0x100], rax
00007e95e7fd0904  jmp 0x00007E95E7DFE110
00007e95e7fd0909  cmp dword ptr [r15+0x318], 0x00
00007e95e7fd0911  jz 0x00007E95E7FD0940
00007e95e7fd0917  nop [rax+rax*1], ax
00007e95e7fd0920  nop [rax+rax*1], eax
00007e95e7fd0928  mov eax, 0x410084
00007e95e7fd092d  mov [r15+0x100], rax
00007e95e7fd0934  jmp 0x00007E95E7DFE110
00007e95e7fd0939  int3
00007e95e7fd093a  int3
00007e95e7fd093b  nop [rax+rax*1], eax
00007e95e7fd0940  mov qword ptr [r15+0x60], 0x00
00007e95e7fd0948  mov rax, [r15+0x50]
00007e95e7fd094c  mov [r15+0x68], rax
00007e95e7fd0950  mov r14, [r15+0x40]
00007e95e7fd0954  mov r12, [r13+r14*1]
00007e95e7fd0959  lea r11, [r14+0x08]
00007e95e7fd095d  mov r10, [r13+r11*1]
00007e95e7fd0962  movq xmm1, r12
00007e95e7fd0967  movq xmm15, r10
00007e95e7fd096c  movq xmm1, xmm1
00007e95e7fd0970  movq xmm1, xmm1
00007e95e7fd0974  movaps [r15+0x120], xmm1
00007e95e7fd097c  movq xmm15, xmm15
00007e95e7fd0981  movq xmm15, xmm15
00007e95e7fd0986  movaps [r15+0x130], xmm15
00007e95e7fd098e  lea r12, [r14+0x10]
00007e95e7fd0992  mov r11, [r13+r12*1]
00007e95e7fd0997  lea r12, [r14+0x18]
00007e95e7fd099b  mov r10, [r13+r12*1]
00007e95e7fd09a0  movq xmm1, r11
00007e95e7fd09a5  movq xmm15, r10
00007e95e7fd09aa  movq xmm1, xmm1
00007e95e7fd09ae  movq xmm1, xmm1
00007e95e7fd09b2  movaps [r15+0x140], xmm1
00007e95e7fd09ba  movq xmm15, xmm15
00007e95e7fd09bf  movq xmm15, xmm15
00007e95e7fd09c4  movaps [r15+0x150], xmm15
00007e95e7fd09cc  lea r12, [r14+0x20]
00007e95e7fd09d0  mov r11, [r13+r12*1]
00007e95e7fd09d5  lea r12, [r14+0x28]
00007e95e7fd09d9  mov r10, [r13+r12*1]
00007e95e7fd09de  movq xmm1, r11
00007e95e7fd09e3  movq xmm15, r10
00007e95e7fd09e8  movq xmm1, xmm1
00007e95e7fd09ec  movq xmm1, xmm1
00007e95e7fd09f0  movaps [r15+0x160], xmm1
00007e95e7fd09f8  movq xmm15, xmm15
00007e95e7fd09fd  movq xmm15, xmm15
00007e95e7fd0a02  movaps [r15+0x170], xmm15
00007e95e7fd0a0a  lea r12, [r14+0x30]
00007e95e7fd0a0e  mov r11, [r13+r12*1]
00007e95e7fd0a13  lea r12, [r14+0x38]
00007e95e7fd0a17  mov r14, [r13+r12*1]
00007e95e7fd0a1c  movq xmm1, r11
00007e95e7fd0a21  movq xmm15, r14
00007e95e7fd0a26  movq xmm1, xmm1
00007e95e7fd0a2a  movq xmm1, xmm1
00007e95e7fd0a2e  movaps [r15+0x180], xmm1
00007e95e7fd0a36  movq xmm15, xmm15
00007e95e7fd0a3b  movq xmm15, xmm15
00007e95e7fd0a40  movaps [r15+0x210], xmm15
00007e95e7fd0a48  mov r14, [r15+0x48]
00007e95e7fd0a4c  mov [r15+0x78], r14
00007e95e7fd0a50  mov r12, [r13+r14*1]
00007e95e7fd0a55  movq xmm1, r12
00007e95e7fd0a5a  lea r12, [r14+0x40]
00007e95e7fd0a5e  mov r11, [r13+r12*1]
00007e95e7fd0a63  movq xmm15, r11
00007e95e7fd0a68  lea r12, [r14+0x80]
00007e95e7fd0a6f  mov r11, [r13+r12*1]
00007e95e7fd0a74  movq xmm14, r11
00007e95e7fd0a79  movaps xmm13, [r15+0x120]
00007e95e7fd0a81  movq r12, xmm13
00007e95e7fd0a86  movq r11, xmm1
00007e95e7fd0a8b  vmovq xmm1, r12
00007e95e7fd0a90  vmovq xmm13, r11
00007e95e7fd0a95  movaps xmm12, xmm1
00007e95e7fd0a99  mulsd xmm12, xmm13
00007e95e7fd0a9e  ucomisd xmm12, xmm12
00007e95e7fd0aa3  jp 0x00007E95E7FD0F06
00007e95e7fd0aa9  movq xmm12, xmm12
00007e95e7fd0aae  movaps xmm1, [r15+0x130]
00007e95e7fd0ab6  movq r12, xmm1
00007e95e7fd0abb  movq r11, xmm15
00007e95e7fd0ac0  vmovq xmm1, r12
00007e95e7fd0ac5  vmovq xmm15, r11
00007e95e7fd0aca  movaps xmm13, xmm1
00007e95e7fd0ace  mulsd xmm13, xmm15
00007e95e7fd0ad3  ucomisd xmm13, xmm13
00007e95e7fd0ad8  jp 0x00007E95E7FD0F52
00007e95e7fd0ade  movq xmm13, xmm13
00007e95e7fd0ae3  movq r12, xmm12
00007e95e7fd0ae8  movaps xmm1, [r15+0x110]
00007e95e7fd0af0  movq r11, xmm1
00007e95e7fd0af5  vmovq xmm1, r12
00007e95e7fd0afa  vmovq xmm15, r11
00007e95e7fd0aff  movaps xmm12, xmm1
00007e95e7fd0b03  addsd xmm12, xmm15
00007e95e7fd0b08  ucomisd xmm12, xmm12
00007e95e7fd0b0d  jp 0x00007E95E7FD0F9E
00007e95e7fd0b13  movq xmm12, xmm12
00007e95e7fd0b18  movq r12, xmm12
00007e95e7fd0b1d  movq r11, xmm13
00007e95e7fd0b22  vmovq xmm1, r12
00007e95e7fd0b27  vmovq xmm15, r11
00007e95e7fd0b2c  movaps xmm13, xmm1
00007e95e7fd0b30  addsd xmm13, xmm15
00007e95e7fd0b35  ucomisd xmm13, xmm13
00007e95e7fd0b3a  jp 0x00007E95E7FD0FEA
00007e95e7fd0b40  movq xmm13, xmm13
00007e95e7fd0b45  movaps xmm1, [r15+0x140]
00007e95e7fd0b4d  movq r12, xmm1
00007e95e7fd0b52  movq r11, xmm14
00007e95e7fd0b57  vmovq xmm1, r12
00007e95e7fd0b5c  vmovq xmm15, r11
00007e95e7fd0b61  movaps xmm14, xmm1
00007e95e7fd0b65  mulsd xmm14, xmm15
00007e95e7fd0b6a  ucomisd xmm14, xmm14
00007e95e7fd0b6f  jp 0x00007E95E7FD1036
00007e95e7fd0b75  movq xmm14, xmm14
00007e95e7fd0b7a  lea r12, [r14+0xC0]
00007e95e7fd0b81  mov r11, [r13+r12*1]
00007e95e7fd0b86  movq xmm1, r11
00007e95e7fd0b8b  movq r12, xmm13
00007e95e7fd0b90  movq r11, xmm14
00007e95e7fd0b95  vmovq xmm15, r12
00007e95e7fd0b9a  vmovq xmm14, r11
00007e95e7fd0b9f  movaps xmm13, xmm15
00007e95e7fd0ba3  addsd xmm13, xmm14
00007e95e7fd0ba8  ucomisd xmm13, xmm13
00007e95e7fd0bad  jp 0x00007E95E7FD108C
00007e95e7fd0bb3  movq xmm13, xmm13
00007e95e7fd0bb8  movaps xmm15, [r15+0x150]
00007e95e7fd0bc0  movq r12, xmm15
00007e95e7fd0bc5  movq r11, xmm1
00007e95e7fd0bca  vmovq xmm1, r12
00007e95e7fd0bcf  vmovq xmm15, r11
00007e95e7fd0bd4  movaps xmm14, xmm1
00007e95e7fd0bd8  mulsd xmm14, xmm15
00007e95e7fd0bdd  ucomisd xmm14, xmm14
00007e95e7fd0be2  jp 0x00007E95E7FD10D8
00007e95e7fd0be8  movq xmm14, xmm14
00007e95e7fd0bed  lea r12, [r14+0x100]
00007e95e7fd0bf4  mov r11, [r13+r12*1]
00007e95e7fd0bf9  movq xmm1, r11
00007e95e7fd0bfe  movq r12, xmm13
00007e95e7fd0c03  movq r11, xmm14
00007e95e7fd0c08  vmovq xmm15, r12
00007e95e7fd0c0d  vmovq xmm14, r11
00007e95e7fd0c12  movaps xmm13, xmm15
00007e95e7fd0c16  addsd xmm13, xmm14
00007e95e7fd0c1b  ucomisd xmm13, xmm13
00007e95e7fd0c20  jp 0x00007E95E7FD112E
00007e95e7fd0c26  movq xmm13, xmm13
00007e95e7fd0c2b  movaps xmm15, [r15+0x160]
00007e95e7fd0c33  movq r12, xmm15
00007e95e7fd0c38  movq r11, xmm1
00007e95e7fd0c3d  vmovq xmm1, r12
00007e95e7fd0c42  vmovq xmm15, r11
00007e95e7fd0c47  movaps xmm14, xmm1
00007e95e7fd0c4b  mulsd xmm14, xmm15
00007e95e7fd0c50  ucomisd xmm14, xmm14
00007e95e7fd0c55  jp 0x00007E95E7FD117A
00007e95e7fd0c5b  movq xmm14, xmm14
00007e95e7fd0c60  lea r12, [r14+0x140]
00007e95e7fd0c67  mov r11, [r13+r12*1]
00007e95e7fd0c6c  movq xmm1, r11
00007e95e7fd0c71  movq r12, xmm13
00007e95e7fd0c76  movq r11, xmm14
00007e95e7fd0c7b  vmovq xmm15, r12
00007e95e7fd0c80  vmovq xmm14, r11
00007e95e7fd0c85  movaps xmm13, xmm15
00007e95e7fd0c89  addsd xmm13, xmm14
00007e95e7fd0c8e  ucomisd xmm13, xmm13
00007e95e7fd0c93  jp 0x00007E95E7FD11D0
00007e95e7fd0c99  movq xmm13, xmm13
00007e95e7fd0c9e  movaps xmm15, [r15+0x170]
00007e95e7fd0ca6  movq r12, xmm15
00007e95e7fd0cab  movq r11, xmm1
00007e95e7fd0cb0  vmovq xmm1, r12
00007e95e7fd0cb5  vmovq xmm15, r11
00007e95e7fd0cba  movaps xmm14, xmm1
00007e95e7fd0cbe  mulsd xmm14, xmm15
00007e95e7fd0cc3  ucomisd xmm14, xmm14
00007e95e7fd0cc8  jp 0x00007E95E7FD121C
00007e95e7fd0cce  movq xmm14, xmm14
00007e95e7fd0cd3  lea r12, [r14+0x180]
00007e95e7fd0cda  mov r11, [r13+r12*1]
00007e95e7fd0cdf  movq xmm1, r11
00007e95e7fd0ce4  movq r12, xmm13
00007e95e7fd0ce9  movq r11, xmm14
00007e95e7fd0cee  vmovq xmm15, r12
00007e95e7fd0cf3  vmovq xmm14, r11
00007e95e7fd0cf8  movaps xmm13, xmm15
00007e95e7fd0cfc  addsd xmm13, xmm14
00007e95e7fd0d01  ucomisd xmm13, xmm13
00007e95e7fd0d06  jp 0x00007E95E7FD1272
00007e95e7fd0d0c  movq xmm13, xmm13
00007e95e7fd0d11  movaps xmm15, [r15+0x180]
00007e95e7fd0d19  movq r12, xmm15
00007e95e7fd0d1e  movq r11, xmm1
00007e95e7fd0d23  vmovq xmm1, r12
00007e95e7fd0d28  vmovq xmm15, r11
00007e95e7fd0d2d  movaps xmm14, xmm1
00007e95e7fd0d31  mulsd xmm14, xmm15
00007e95e7fd0d36  ucomisd xmm14, xmm14
00007e95e7fd0d3b  jp 0x00007E95E7FD12BE
00007e95e7fd0d41  movq xmm14, xmm14
00007e95e7fd0d46  lea r12, [r14+0x1C0]
00007e95e7fd0d4d  mov r14, [r13+r12*1]
00007e95e7fd0d52  movq xmm1, r14
00007e95e7fd0d57  movaps [r15+0x240], xmm1
00007e95e7fd0d5f  movq r14, xmm13
00007e95e7fd0d64  movq r12, xmm14
00007e95e7fd0d69  vmovq xmm15, r14
00007e95e7fd0d6e  vmovq xmm14, r12
00007e95e7fd0d73  movaps xmm13, xmm15
00007e95e7fd0d77  addsd xmm13, xmm14
00007e95e7fd0d7c  ucomisd xmm13, xmm13
00007e95e7fd0d81  jp 0x00007E95E7FD1314
00007e95e7fd0d87  movq xmm13, xmm13
00007e95e7fd0d8c  movaps xmm15, [r15+0x210]
00007e95e7fd0d94  movq r14, xmm15
00007e95e7fd0d99  movq r12, xmm1
00007e95e7fd0d9e  vmovq xmm1, r14
00007e95e7fd0da3  vmovq xmm15, r12
00007e95e7fd0da8  movaps xmm14, xmm1
00007e95e7fd0dac  mulsd xmm14, xmm15
00007e95e7fd0db1  ucomisd xmm14, xmm14
00007e95e7fd0db6  jp 0x00007E95E7FD1360
00007e95e7fd0dbc  movq xmm14, xmm14
00007e95e7fd0dc1  movaps [r15+0x230], xmm14
00007e95e7fd0dc9  movq r14, xmm13
00007e95e7fd0dce  movq r12, xmm14
00007e95e7fd0dd3  vmovq xmm1, r14
00007e95e7fd0dd8  vmovq xmm15, r12
00007e95e7fd0ddd  movaps xmm14, xmm1
00007e95e7fd0de1  addsd xmm14, xmm15
00007e95e7fd0de6  ucomisd xmm14, xmm14
00007e95e7fd0deb  jp 0x00007E95E7FD13AC
00007e95e7fd0df1  movq xmm14, xmm14
00007e95e7fd0df6  movaps [r15+0x220], xmm14
00007e95e7fd0dfe  movq r14, xmm14
00007e95e7fd0e03  mov [r13+rax*1], r14
00007e95e7fd0e08  mov qword ptr [r15+0x70], 0x08
00007e95e7fd0e10  xor eax, eax
00007e95e7fd0e12  mov r14d, 0x08
00007e95e7fd0e18  mov r12d, 0x40
00007e95e7fd0e1e  cmp r14, r12
00007e95e7fd0e21  cmc
00007e95e7fd0e22  lahf
00007e95e7fd0e23  seto al
00007e95e7fd0e26  mov [r15+0x108], eax
00007e95e7fd0e2d  mov eax, [r15+0x108]
00007e95e7fd0e34  sahf
00007e95e7fd0e35  jnz 0x00007E95E7FD0E67
00007e95e7fd0e37  cmp dword ptr [r15+0x318], 0x00
00007e95e7fd0e3f  jz 0x00007E95E7FCFD40
00007e95e7fd0e45  nop [rax+rax*1], ax
00007e95e7fd0e4e  nop [rax+rax*1], eax
00007e95e7fd0e56  mov eax, 0x410118
00007e95e7fd0e5b  mov [r15+0x100], rax
00007e95e7fd0e62  jmp 0x00007E95E7DFE110
00007e95e7fd0e67  cmp dword ptr [r15+0x318], 0x00
00007e95e7fd0e6f  jz 0x00007E95E7FCF3F0
00007e95e7fd0e75  nop [rax+rax*1], ax
00007e95e7fd0e7e  nop [rax+rax*1], eax
00007e95e7fd0e86  mov eax, 0x4100A4
00007e95e7fd0e8b  mov [r15+0x100], rax
00007e95e7fd0e92  jmp 0x00007E95E7DFE110
00007e95e7fd0e97  int3
00007e95e7fd0e98  call 0x00007E95E7EE27E0
00007e95e7fd0e9d  jmp 0x00007E95E7FD0959
00007e95e7fd0ea2  call 0x00007E95E7EAE800
00007e95e7fd0ea7  jmp 0x00007E95E7FD0962
00007e95e7fd0eac  call 0x00007E95E7EC0370
00007e95e7fd0eb1  jmp 0x00007E95E7FD0997
00007e95e7fd0eb6  call 0x00007E95E7EBF100
00007e95e7fd0ebb  jmp 0x00007E95E7FD09A0
00007e95e7fd0ec0  call 0x00007E95E7EC0370
00007e95e7fd0ec5  jmp 0x00007E95E7FD09D5
00007e95e7fd0eca  call 0x00007E95E7EBF100
00007e95e7fd0ecf  jmp 0x00007E95E7FD09DE
00007e95e7fd0ed4  call 0x00007E95E7EC0370
00007e95e7fd0ed9  jmp 0x00007E95E7FD0A13
00007e95e7fd0ede  call 0x00007E95E7EC3AE0
00007e95e7fd0ee3  jmp 0x00007E95E7FD0A1C
00007e95e7fd0ee8  call 0x00007E95E7EE27E0
00007e95e7fd0eed  jmp 0x00007E95E7FD0A55
00007e95e7fd0ef2  call 0x00007E95E7EC0370
00007e95e7fd0ef7  jmp 0x00007E95E7FD0A63
00007e95e7fd0efc  call 0x00007E95E7EC0370
00007e95e7fd0f01  jmp 0x00007E95E7FD0A74
00007e95e7fd0f06  ucomisd xmm1, xmm13
00007e95e7fd0f0b  jp 0x00007E95E7FD0F1A
00007e95e7fd0f0d  movaps xmm12, [0x00007E95E7BFE030]
00007e95e7fd0f15  jmp 0x00007E95E7FD0AA9
00007e95e7fd0f1a  vxorps xmm0, xmm1, xmm13
00007e95e7fd0f1f  pextrw r12d, xmm0, 0x03
00007e95e7fd0f25  and r12d, 0x7FF8
00007e95e7fd0f2c  cmp r12d, 0x08
00007e95e7fd0f30  jnz 0x00007E95E7FD0AA9
00007e95e7fd0f36  movq r12, xmm13
00007e95e7fd0f3b  shl r12, 0x0D
00007e95e7fd0f3f  jbe 0x00007E95E7FD0AA9
00007e95e7fd0f45  vorps xmm12, xmm13, [0x00007E95E7BFE040]
00007e95e7fd0f4d  jmp 0x00007E95E7FD0AA9
00007e95e7fd0f52  ucomisd xmm1, xmm15
00007e95e7fd0f57  jp 0x00007E95E7FD0F66
00007e95e7fd0f59  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd0f61  jmp 0x00007E95E7FD0ADE
00007e95e7fd0f66  vxorps xmm0, xmm1, xmm15
00007e95e7fd0f6b  pextrw r12d, xmm0, 0x03
00007e95e7fd0f71  and r12d, 0x7FF8
00007e95e7fd0f78  cmp r12d, 0x08
00007e95e7fd0f7c  jnz 0x00007E95E7FD0ADE
00007e95e7fd0f82  movq r12, xmm15
00007e95e7fd0f87  shl r12, 0x0D
00007e95e7fd0f8b  jbe 0x00007E95E7FD0ADE
00007e95e7fd0f91  vorps xmm13, xmm15, [0x00007E95E7BFE040]
00007e95e7fd0f99  jmp 0x00007E95E7FD0ADE
00007e95e7fd0f9e  ucomisd xmm1, xmm15
00007e95e7fd0fa3  jp 0x00007E95E7FD0FB2
00007e95e7fd0fa5  movaps xmm12, [0x00007E95E7BFE030]
00007e95e7fd0fad  jmp 0x00007E95E7FD0B13
00007e95e7fd0fb2  vxorps xmm0, xmm1, xmm15
00007e95e7fd0fb7  pextrw r12d, xmm0, 0x03
00007e95e7fd0fbd  and r12d, 0x7FF8
00007e95e7fd0fc4  cmp r12d, 0x08
00007e95e7fd0fc8  jnz 0x00007E95E7FD0B13
00007e95e7fd0fce  movq r12, xmm15
00007e95e7fd0fd3  shl r12, 0x0D
00007e95e7fd0fd7  jbe 0x00007E95E7FD0B13
00007e95e7fd0fdd  vorps xmm12, xmm15, [0x00007E95E7BFE040]
00007e95e7fd0fe5  jmp 0x00007E95E7FD0B13
00007e95e7fd0fea  ucomisd xmm1, xmm15
00007e95e7fd0fef  jp 0x00007E95E7FD0FFE
00007e95e7fd0ff1  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd0ff9  jmp 0x00007E95E7FD0B40
00007e95e7fd0ffe  vxorps xmm0, xmm1, xmm15
00007e95e7fd1003  pextrw r12d, xmm0, 0x03
00007e95e7fd1009  and r12d, 0x7FF8
00007e95e7fd1010  cmp r12d, 0x08
00007e95e7fd1014  jnz 0x00007E95E7FD0B40
00007e95e7fd101a  movq r12, xmm15
00007e95e7fd101f  shl r12, 0x0D
00007e95e7fd1023  jbe 0x00007E95E7FD0B40
00007e95e7fd1029  vorps xmm13, xmm15, [0x00007E95E7BFE040]
00007e95e7fd1031  jmp 0x00007E95E7FD0B40
00007e95e7fd1036  ucomisd xmm1, xmm15
00007e95e7fd103b  jp 0x00007E95E7FD104A
00007e95e7fd103d  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd1045  jmp 0x00007E95E7FD0B75
00007e95e7fd104a  vxorps xmm0, xmm1, xmm15
00007e95e7fd104f  pextrw r12d, xmm0, 0x03
00007e95e7fd1055  and r12d, 0x7FF8
00007e95e7fd105c  cmp r12d, 0x08
00007e95e7fd1060  jnz 0x00007E95E7FD0B75
00007e95e7fd1066  movq r12, xmm15
00007e95e7fd106b  shl r12, 0x0D
00007e95e7fd106f  jbe 0x00007E95E7FD0B75
00007e95e7fd1075  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd107d  jmp 0x00007E95E7FD0B75
00007e95e7fd1082  call 0x00007E95E7EC0370
00007e95e7fd1087  jmp 0x00007E95E7FD0B86
00007e95e7fd108c  ucomisd xmm15, xmm14
00007e95e7fd1091  jp 0x00007E95E7FD10A0
00007e95e7fd1093  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd109b  jmp 0x00007E95E7FD0BB3
00007e95e7fd10a0  vxorps xmm0, xmm15, xmm14
00007e95e7fd10a5  pextrw r12d, xmm0, 0x03
00007e95e7fd10ab  and r12d, 0x7FF8
00007e95e7fd10b2  cmp r12d, 0x08
00007e95e7fd10b6  jnz 0x00007E95E7FD0BB3
00007e95e7fd10bc  movq r12, xmm14
00007e95e7fd10c1  shl r12, 0x0D
00007e95e7fd10c5  jbe 0x00007E95E7FD0BB3
00007e95e7fd10cb  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fd10d3  jmp 0x00007E95E7FD0BB3
00007e95e7fd10d8  ucomisd xmm1, xmm15
00007e95e7fd10dd  jp 0x00007E95E7FD10EC
00007e95e7fd10df  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd10e7  jmp 0x00007E95E7FD0BE8
00007e95e7fd10ec  vxorps xmm0, xmm1, xmm15
00007e95e7fd10f1  pextrw r12d, xmm0, 0x03
00007e95e7fd10f7  and r12d, 0x7FF8
00007e95e7fd10fe  cmp r12d, 0x08
00007e95e7fd1102  jnz 0x00007E95E7FD0BE8
00007e95e7fd1108  movq r12, xmm15
00007e95e7fd110d  shl r12, 0x0D
00007e95e7fd1111  jbe 0x00007E95E7FD0BE8
00007e95e7fd1117  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd111f  jmp 0x00007E95E7FD0BE8
00007e95e7fd1124  call 0x00007E95E7EC0370
00007e95e7fd1129  jmp 0x00007E95E7FD0BF9
00007e95e7fd112e  ucomisd xmm15, xmm14
00007e95e7fd1133  jp 0x00007E95E7FD1142
00007e95e7fd1135  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd113d  jmp 0x00007E95E7FD0C26
00007e95e7fd1142  vxorps xmm0, xmm15, xmm14
00007e95e7fd1147  pextrw r12d, xmm0, 0x03
00007e95e7fd114d  and r12d, 0x7FF8
00007e95e7fd1154  cmp r12d, 0x08
00007e95e7fd1158  jnz 0x00007E95E7FD0C26
00007e95e7fd115e  movq r12, xmm14
00007e95e7fd1163  shl r12, 0x0D
00007e95e7fd1167  jbe 0x00007E95E7FD0C26
00007e95e7fd116d  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fd1175  jmp 0x00007E95E7FD0C26
00007e95e7fd117a  ucomisd xmm1, xmm15
00007e95e7fd117f  jp 0x00007E95E7FD118E
00007e95e7fd1181  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd1189  jmp 0x00007E95E7FD0C5B
00007e95e7fd118e  vxorps xmm0, xmm1, xmm15
00007e95e7fd1193  pextrw r12d, xmm0, 0x03
00007e95e7fd1199  and r12d, 0x7FF8
00007e95e7fd11a0  cmp r12d, 0x08
00007e95e7fd11a4  jnz 0x00007E95E7FD0C5B
00007e95e7fd11aa  movq r12, xmm15
00007e95e7fd11af  shl r12, 0x0D
00007e95e7fd11b3  jbe 0x00007E95E7FD0C5B
00007e95e7fd11b9  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd11c1  jmp 0x00007E95E7FD0C5B
00007e95e7fd11c6  call 0x00007E95E7EC0370
00007e95e7fd11cb  jmp 0x00007E95E7FD0C6C
00007e95e7fd11d0  ucomisd xmm15, xmm14
00007e95e7fd11d5  jp 0x00007E95E7FD11E4
00007e95e7fd11d7  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd11df  jmp 0x00007E95E7FD0C99
00007e95e7fd11e4  vxorps xmm0, xmm15, xmm14
00007e95e7fd11e9  pextrw r12d, xmm0, 0x03
00007e95e7fd11ef  and r12d, 0x7FF8
00007e95e7fd11f6  cmp r12d, 0x08
00007e95e7fd11fa  jnz 0x00007E95E7FD0C99
00007e95e7fd1200  movq r12, xmm14
00007e95e7fd1205  shl r12, 0x0D
00007e95e7fd1209  jbe 0x00007E95E7FD0C99
00007e95e7fd120f  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fd1217  jmp 0x00007E95E7FD0C99
00007e95e7fd121c  ucomisd xmm1, xmm15
00007e95e7fd1221  jp 0x00007E95E7FD1230
00007e95e7fd1223  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd122b  jmp 0x00007E95E7FD0CCE
00007e95e7fd1230  vxorps xmm0, xmm1, xmm15
00007e95e7fd1235  pextrw r12d, xmm0, 0x03
00007e95e7fd123b  and r12d, 0x7FF8
00007e95e7fd1242  cmp r12d, 0x08
00007e95e7fd1246  jnz 0x00007E95E7FD0CCE
00007e95e7fd124c  movq r12, xmm15
00007e95e7fd1251  shl r12, 0x0D
00007e95e7fd1255  jbe 0x00007E95E7FD0CCE
00007e95e7fd125b  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd1263  jmp 0x00007E95E7FD0CCE
00007e95e7fd1268  call 0x00007E95E7EC0370
00007e95e7fd126d  jmp 0x00007E95E7FD0CDF
00007e95e7fd1272  ucomisd xmm15, xmm14
00007e95e7fd1277  jp 0x00007E95E7FD1286
00007e95e7fd1279  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd1281  jmp 0x00007E95E7FD0D0C
00007e95e7fd1286  vxorps xmm0, xmm15, xmm14
00007e95e7fd128b  pextrw r12d, xmm0, 0x03
00007e95e7fd1291  and r12d, 0x7FF8
00007e95e7fd1298  cmp r12d, 0x08
00007e95e7fd129c  jnz 0x00007E95E7FD0D0C
00007e95e7fd12a2  movq r12, xmm14
00007e95e7fd12a7  shl r12, 0x0D
00007e95e7fd12ab  jbe 0x00007E95E7FD0D0C
00007e95e7fd12b1  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fd12b9  jmp 0x00007E95E7FD0D0C
00007e95e7fd12be  ucomisd xmm1, xmm15
00007e95e7fd12c3  jp 0x00007E95E7FD12D2
00007e95e7fd12c5  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd12cd  jmp 0x00007E95E7FD0D41
00007e95e7fd12d2  vxorps xmm0, xmm1, xmm15
00007e95e7fd12d7  pextrw r12d, xmm0, 0x03
00007e95e7fd12dd  and r12d, 0x7FF8
00007e95e7fd12e4  cmp r12d, 0x08
00007e95e7fd12e8  jnz 0x00007E95E7FD0D41
00007e95e7fd12ee  movq r12, xmm15
00007e95e7fd12f3  shl r12, 0x0D
00007e95e7fd12f7  jbe 0x00007E95E7FD0D41
00007e95e7fd12fd  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd1305  jmp 0x00007E95E7FD0D41
00007e95e7fd130a  call 0x00007E95E7EC3AE0
00007e95e7fd130f  jmp 0x00007E95E7FD0D52
00007e95e7fd1314  ucomisd xmm15, xmm14
00007e95e7fd1319  jp 0x00007E95E7FD1328
00007e95e7fd131b  movaps xmm13, [0x00007E95E7BFE030]
00007e95e7fd1323  jmp 0x00007E95E7FD0D87
00007e95e7fd1328  vxorps xmm0, xmm15, xmm14
00007e95e7fd132d  pextrw r14d, xmm0, 0x03
00007e95e7fd1333  and r14d, 0x7FF8
00007e95e7fd133a  cmp r14d, 0x08
00007e95e7fd133e  jnz 0x00007E95E7FD0D87
00007e95e7fd1344  movq r14, xmm14
00007e95e7fd1349  shl r14, 0x0D
00007e95e7fd134d  jbe 0x00007E95E7FD0D87
00007e95e7fd1353  vorps xmm13, xmm14, [0x00007E95E7BFE040]
00007e95e7fd135b  jmp 0x00007E95E7FD0D87
00007e95e7fd1360  ucomisd xmm1, xmm15
00007e95e7fd1365  jp 0x00007E95E7FD1374
00007e95e7fd1367  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd136f  jmp 0x00007E95E7FD0DBC
00007e95e7fd1374  vxorps xmm0, xmm1, xmm15
00007e95e7fd1379  pextrw r14d, xmm0, 0x03
00007e95e7fd137f  and r14d, 0x7FF8
00007e95e7fd1386  cmp r14d, 0x08
00007e95e7fd138a  jnz 0x00007E95E7FD0DBC
00007e95e7fd1390  movq r14, xmm15
00007e95e7fd1395  shl r14, 0x0D
00007e95e7fd1399  jbe 0x00007E95E7FD0DBC
00007e95e7fd139f  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd13a7  jmp 0x00007E95E7FD0DBC
00007e95e7fd13ac  ucomisd xmm1, xmm15
00007e95e7fd13b1  jp 0x00007E95E7FD13C0
00007e95e7fd13b3  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd13bb  jmp 0x00007E95E7FD0DF1
00007e95e7fd13c0  vxorps xmm0, xmm1, xmm15
00007e95e7fd13c5  pextrw r14d, xmm0, 0x03
00007e95e7fd13cb  and r14d, 0x7FF8
00007e95e7fd13d2  cmp r14d, 0x08
00007e95e7fd13d6  jnz 0x00007E95E7FD0DF1
00007e95e7fd13dc  movq r14, xmm15
00007e95e7fd13e1  shl r14, 0x0D
00007e95e7fd13e5  jbe 0x00007E95E7FD0DF1
00007e95e7fd13eb  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd13f3  jmp 0x00007E95E7FD0DF1
00007e95e7fd13f8  call 0x00007E95E7E0E120
00007e95e7fd13fd  jmp 0x00007E95E7FD0E08
00007e95e7fd1402  int3
00007e95e7fd1403  nop [rax+rax*1], ax
00007e95e7fd140c  nop [rax], eax
00007e95e7fd1410  mov qword ptr [r15+0x40], 0x420000
00007e95e7fd1418  mov eax, 0x4201B8
00007e95e7fd141d  mov r14, [r13+rax*1]
00007e95e7fd1422  movq xmm1, r14
00007e95e7fd1427  mov rax, [r15+0x50]
00007e95e7fd142b  mov r14, [r13+rax*1]
00007e95e7fd1430  movq xmm15, r14
00007e95e7fd1435  movaps [r15+0x120], xmm15
00007e95e7fd143d  mov qword ptr [r15+0x48], 0x08
00007e95e7fd1445  xor eax, eax
00007e95e7fd1447  mov r14d, 0x08
00007e95e7fd144d  mov r12d, 0x200
00007e95e7fd1453  cmp r14, r12
00007e95e7fd1456  cmc
00007e95e7fd1457  lahf
00007e95e7fd1458  seto al
00007e95e7fd145b  mov [r15+0x108], eax
00007e95e7fd1462  movq rax, xmm1
00007e95e7fd1467  movq r14, xmm15
00007e95e7fd146c  vmovq xmm1, rax
00007e95e7fd1471  vmovq xmm15, r14
00007e95e7fd1476  movaps xmm14, xmm1
00007e95e7fd147a  addsd xmm14, xmm15
00007e95e7fd147f  ucomisd xmm14, xmm14
00007e95e7fd1484  jp 0x00007E95E7FD1516
00007e95e7fd148a  movq xmm14, xmm14
00007e95e7fd148f  movaps [r15+0x110], xmm14
00007e95e7fd1497  mov eax, [r15+0x108]
00007e95e7fd149e  sahf
00007e95e7fd149f  jnz 0x00007E95E7FD14D1
00007e95e7fd14a1  cmp dword ptr [r15+0x318], 0x00
00007e95e7fd14a9  jz 0x00007E95E7FD16A0
00007e95e7fd14af  nop [rax+rax*1], ax
00007e95e7fd14b8  nop [rax+rax*1], eax
00007e95e7fd14c0  mov eax, 0x410154
00007e95e7fd14c5  mov [r15+0x100], rax
00007e95e7fd14cc  jmp 0x00007E95E7DFE110
00007e95e7fd14d1  cmp dword ptr [r15+0x318], 0x00
00007e95e7fd14d9  jz 0x00007E95E7FD1560
00007e95e7fd14df  nop [rax+rax*1], ax
00007e95e7fd14e8  nop [rax+rax*1], eax
00007e95e7fd14f0  mov eax, 0x410140
00007e95e7fd14f5  mov [r15+0x100], rax
00007e95e7fd14fc  jmp 0x00007E95E7DFE110
00007e95e7fd1501  int3
00007e95e7fd1502  call 0x00007E95E7E0DC20
00007e95e7fd1507  jmp 0x00007E95E7FD1422
00007e95e7fd150c  call 0x00007E95E7E0DC20
00007e95e7fd1511  jmp 0x00007E95E7FD1430
00007e95e7fd1516  ucomisd xmm1, xmm15
00007e95e7fd151b  jp 0x00007E95E7FD152A
00007e95e7fd151d  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd1525  jmp 0x00007E95E7FD148A
00007e95e7fd152a  vxorps xmm0, xmm1, xmm15
00007e95e7fd152f  pextrw eax, xmm0, 0x03
00007e95e7fd1534  and eax, 0x7FF8
00007e95e7fd1539  cmp eax, 0x08
00007e95e7fd153c  jnz 0x00007E95E7FD148A
00007e95e7fd1542  movq rax, xmm15
00007e95e7fd1547  shl rax, 0x0D
00007e95e7fd154b  jbe 0x00007E95E7FD148A
00007e95e7fd1551  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd1559  jmp 0x00007E95E7FD148A
00007e95e7fd155e  int3
00007e95e7fd155f  nop
00007e95e7fd1560  mov rax, [r15+0x48]
00007e95e7fd1564  mov r14, [r15+0x50]
00007e95e7fd1568  lea r12, [r14+rax*1]
00007e95e7fd156c  mov r14, [r13+r12*1]
00007e95e7fd1571  movq xmm1, r14
00007e95e7fd1576  movaps [r15+0x120], xmm1
00007e95e7fd157e  lea r14, [rax+0x08]
00007e95e7fd1582  mov [r15+0x48], r14
00007e95e7fd1586  xor eax, eax
00007e95e7fd1588  mov r12d, 0x200
00007e95e7fd158e  cmp r14, r12
00007e95e7fd1591  cmc
00007e95e7fd1592  lahf
00007e95e7fd1593  seto al
00007e95e7fd1596  mov [r15+0x108], eax
00007e95e7fd159d  movaps xmm15, [r15+0x110]
00007e95e7fd15a5  movq rax, xmm15
00007e95e7fd15aa  movq r14, xmm1
00007e95e7fd15af  vmovq xmm1, rax
00007e95e7fd15b4  vmovq xmm15, r14
00007e95e7fd15b9  movaps xmm14, xmm1
00007e95e7fd15bd  addsd xmm14, xmm15
00007e95e7fd15c2  ucomisd xmm14, xmm14
00007e95e7fd15c7  jp 0x00007E95E7FD164F
00007e95e7fd15cd  movq xmm14, xmm14
00007e95e7fd15d2  movaps [r15+0x110], xmm14
00007e95e7fd15da  mov eax, [r15+0x108]
00007e95e7fd15e1  sahf
00007e95e7fd15e2  jnz 0x00007E95E7FD1614
00007e95e7fd15e4  cmp dword ptr [r15+0x318], 0x00
00007e95e7fd15ec  jz 0x00007E95E7FD16A0
00007e95e7fd15f2  nop [rax+rax*1], ax
00007e95e7fd15fb  nop [rax+rax*1], eax
00007e95e7fd1603  mov eax, 0x410154
00007e95e7fd1608  mov [r15+0x100], rax
00007e95e7fd160f  jmp 0x00007E95E7DFE110
00007e95e7fd1614  cmp dword ptr [r15+0x318], 0x00
00007e95e7fd161c  jz 0x00007E95E7FD1560
00007e95e7fd1622  nop [rax+rax*1], ax
00007e95e7fd162b  nop [rax+rax*1], eax
00007e95e7fd1633  mov eax, 0x410140
00007e95e7fd1638  mov [r15+0x100], rax
00007e95e7fd163f  jmp 0x00007E95E7DFE110
00007e95e7fd1644  int3
00007e95e7fd1645  call 0x00007E95E7EC3AE0
00007e95e7fd164a  jmp 0x00007E95E7FD1571
00007e95e7fd164f  ucomisd xmm1, xmm15
00007e95e7fd1654  jp 0x00007E95E7FD1663
00007e95e7fd1656  movaps xmm14, [0x00007E95E7BFE030]
00007e95e7fd165e  jmp 0x00007E95E7FD15CD
00007e95e7fd1663  vxorps xmm0, xmm1, xmm15
00007e95e7fd1668  pextrw eax, xmm0, 0x03
00007e95e7fd166d  and eax, 0x7FF8
00007e95e7fd1672  cmp eax, 0x08
00007e95e7fd1675  jnz 0x00007E95E7FD15CD
00007e95e7fd167b  movq rax, xmm15
00007e95e7fd1680  shl rax, 0x0D
00007e95e7fd1684  jbe 0x00007E95E7FD15CD
00007e95e7fd168a  vorps xmm14, xmm15, [0x00007E95E7BFE040]
00007e95e7fd1692  jmp 0x00007E95E7FD15CD
00007e95e7fd1697  int3
00007e95e7fd1698  nop [rax+rax*1], eax
00007e95e7fd16a0  mov rax, [r15+0x40]
00007e95e7fd16a4  lea r14, [rax+0x1B8]
00007e95e7fd16ab  movaps xmm1, [r15+0x110]
00007e95e7fd16b3  movq rax, xmm1
00007e95e7fd16b8  mov [r13+r14*1], rax
00007e95e7fd16bd  mov rax, [r15+0xF0]
00007e95e7fd16c4  mov [r15+0x100], rax
00007e95e7fd16cb  jmp 0x00007E95E7FCE5C0
00007e95e7fd16d0  int3
00007e95e7fd16d1  call 0x00007E95E7ED5EB0
00007e95e7fd16d6  jmp 0x00007E95E7FD16BD
00007e95e7fd16db  int3
00007e95e7fd16dc  nop [rax], eax
00007e95e7fd16e0  mov qword ptr [r15+0x100], 0x04
00007e95e7fd16eb  mov esi, 0x00
00007e95e7fd16f0  mov edx, 0x09
00007e95e7fd16f5  mov rdi, 0x7FFFDF473F90
00007e95e7fd16ff  mov rax, 0x5854A6128970
00007e95e7fd1709  call rax
00007e95e7fd170b  cmp dword ptr [r15+0x318], 0x00
00007e95e7fd1713  jnz 0x00007E95E7DFE110
00007e95e7fd1719  jmp 0x00007E95E7DFE0A0
00007e95e7fd171e  int3
00007e95e7fd171f  int3
