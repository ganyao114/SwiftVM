00007cef4ddce69b  nop [rax+rax*1], eax
00007cef4ddce6a0  mov rax, [r15+0xF8]
00007cef4ddce6a7  lea r14, [rax-0xA0]
00007cef4ddce6ae  mov [r15+0xF8], r14
00007cef4ddce6b5  lea rax, [r14+0x90]
00007cef4ddce6bc  mov r12, [r15+0xA0]
00007cef4ddce6c3  mov r11, [r15+0x98]
00007cef4ddce6ca  mov [r13+rax*1], r12
00007cef4ddce6cf  lea rax, [r14+0x98]
00007cef4ddce6d6  mov [r13+rax*1], r11
00007cef4ddce6db  mov eax, 0x420670
00007cef4ddce6e0  movups xmm1, [r13+rax*1]
00007cef4ddce6e6  mov eax, 0x420610
00007cef4ddce6eb  movups xmm15, [r13+rax*1]
00007cef4ddce6f1  mov eax, 0x420690
00007cef4ddce6f6  movups xmm14, [r13+rax*1]
00007cef4ddce6fc  mov eax, 0x420630
00007cef4ddce701  movups xmm13, [r13+rax*1]
00007cef4ddce707  mov qword ptr [r15+0x98], 0x4308A0
00007cef4ddce712  mov eax, 0x4206A0
00007cef4ddce717  movups xmm12, [r13+rax*1]
00007cef4ddce71d  mov eax, 0x4308A0
00007cef4ddce722  movups [r13+rax*1], xmm1
00007cef4ddce728  mov eax, 0x4308B0
00007cef4ddce72d  movups [r13+rax*1], xmm15
00007cef4ddce733  mov eax, 0x4308C0
00007cef4ddce738  movups [r13+rax*1], xmm14
00007cef4ddce73e  mov eax, 0x4308D0
00007cef4ddce743  movups [r13+rax*1], xmm13
00007cef4ddce749  mov eax, 0x420600
00007cef4ddce74e  movups xmm14, [r13+rax*1]
00007cef4ddce754  mov eax, 0x4205F0
00007cef4ddce759  movups xmm13, [r13+rax*1]
00007cef4ddce75f  mov eax, 0x4309A0
00007cef4ddce764  movups [r13+rax*1], xmm1
00007cef4ddce76a  mov eax, 0x4309B0
00007cef4ddce76f  movups [r13+rax*1], xmm15
00007cef4ddce775  mov eax, 0x4308E0
00007cef4ddce77a  movups [r13+rax*1], xmm12
00007cef4ddce780  mov eax, 0x4308F0
00007cef4ddce785  movups [r13+rax*1], xmm14
00007cef4ddce78b  mov eax, 0x4205E0
00007cef4ddce790  movups xmm1, [r13+rax*1]
00007cef4ddce796  mov eax, 0x420640
00007cef4ddce79b  movups xmm15, [r13+rax*1]
00007cef4ddce7a1  mov eax, 0x430900
00007cef4ddce7a6  movups [r13+rax*1], xmm13
00007cef4ddce7ac  mov eax, 0x430910
00007cef4ddce7b1  movups [r13+rax*1], xmm1
00007cef4ddce7b7  mov eax, 0x420650
00007cef4ddce7bc  movups xmm1, [r13+rax*1]
00007cef4ddce7c2  mov eax, 0x420620
00007cef4ddce7c7  movups xmm14, [r13+rax*1]
00007cef4ddce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007cef4ddce7d5  mov eax, 0x430920
00007cef4ddce7da  movups [r13+rax*1], xmm15
00007cef4ddce7e0  mov eax, 0x430930
00007cef4ddce7e5  movups [r13+rax*1], xmm1
00007cef4ddce7eb  mov eax, 0x4206C0
00007cef4ddce7f0  movups xmm1, [r13+rax*1]
00007cef4ddce7f6  mov eax, 0x4206D0
00007cef4ddce7fb  movups xmm15, [r13+rax*1]
00007cef4ddce801  movaps [r15+0x150], xmm15
00007cef4ddce809  mov qword ptr [r15+0xA0], 0x3E8
00007cef4ddce814  mov eax, 0x430940
00007cef4ddce819  movups [r13+rax*1], xmm14
00007cef4ddce81f  mov eax, 0x430950
00007cef4ddce824  movups [r13+rax*1], xmm1
00007cef4ddce82a  mov eax, 0x4206B0
00007cef4ddce82f  movups xmm1, [r13+rax*1]
00007cef4ddce835  mov eax, 0x420660
00007cef4ddce83a  movups xmm14, [r13+rax*1]
00007cef4ddce840  movaps [r15+0x140], xmm14
00007cef4ddce848  lea rax, [r14+0x80]
00007cef4ddce84f  mov r12, [r15+0xF0]
00007cef4ddce856  mov [r13+rax*1], r12
00007cef4ddce85b  mov eax, 0x430960
00007cef4ddce860  movups [r13+rax*1], xmm15
00007cef4ddce866  mov eax, 0x430970
00007cef4ddce86b  movups [r13+rax*1], xmm1
00007cef4ddce871  mov eax, 0x420680
00007cef4ddce876  movups xmm1, [r13+rax*1]
00007cef4ddce87c  mov eax, 0x4206E0
00007cef4ddce881  mov r12, [r13+rax*1]
00007cef4ddce886  movq xmm15, r12
00007cef4ddce88b  mov qword ptr [r15+0x40], 0x4206E8
00007cef4ddce893  mov eax, 0x430980
00007cef4ddce898  movups [r13+rax*1], xmm14
00007cef4ddce89e  mov eax, 0x430990
00007cef4ddce8a3  movups [r13+rax*1], xmm1
00007cef4ddce8a9  mov eax, 0x420748
00007cef4ddce8ae  movups xmm1, [r13+rax*1]
00007cef4ddce8b4  movq rax, xmm15
00007cef4ddce8b9  mov r12d, 0x4309C0
00007cef4ddce8bf  mov [r13+r12*1], rax
00007cef4ddce8c4  mov eax, 0x420728
00007cef4ddce8c9  movups xmm15, [r13+rax*1]
00007cef4ddce8cf  mov eax, 0x420738
00007cef4ddce8d4  movups xmm14, [r13+rax*1]
00007cef4ddce8da  lea rax, [r14+0x60]
00007cef4ddce8de  movups [r13+rax*1], xmm1
00007cef4ddce8e4  mov eax, 0x4309C8
00007cef4ddce8e9  mov r12d, 0x421DF8D3
00007cef4ddce8ef  mov [r13+rax*1], r12d
00007cef4ddce8f4  lea rax, [r14+0x40]
00007cef4ddce8f8  movups [r13+rax*1], xmm15
00007cef4ddce8fe  lea rax, [r14+0x50]
00007cef4ddce902  movups [r13+rax*1], xmm14
00007cef4ddce908  mov eax, 0x4206E8
00007cef4ddce90d  movups xmm1, [r13+rax*1]
00007cef4ddce913  mov eax, 0x4206F8
00007cef4ddce918  movups xmm15, [r13+rax*1]
00007cef4ddce91e  movaps [r15+0x120], xmm15
00007cef4ddce926  movups [r13+r14*1], xmm1
00007cef4ddce92c  lea rax, [r14+0x10]
00007cef4ddce930  movups [r13+rax*1], xmm15
00007cef4ddce936  mov eax, 0x420708
00007cef4ddce93b  movups xmm1, [r13+rax*1]
00007cef4ddce941  mov eax, 0x420718
00007cef4ddce946  movups xmm15, [r13+rax*1]
00007cef4ddce94c  movaps [r15+0x110], xmm1
00007cef4ddce954  movaps [r15+0x130], xmm15
00007cef4ddce95c  lea rax, [r14+0x20]
00007cef4ddce960  movups [r13+rax*1], xmm1
00007cef4ddce966  lea rax, [r14+0x30]
00007cef4ddce96a  movups [r13+rax*1], xmm15
00007cef4ddce970  mov [r15], r14
00007cef4ddce973  mov qword ptr [r15+0x08], 0x4308A0
00007cef4ddce97b  mov qword ptr [r15+0x10], 0x12C
00007cef4ddce983  mov qword ptr [r15+0xF0], 0x410274
00007cef4ddce98e  mov r14d, [r15+0x320]
00007cef4ddce995  mov eax, 0x410274
00007cef4ddce99a  mov rcx, 0x7CEF4DDD0670
00007cef4ddce9a4  mov [r15+r14*8+0x328], rax
00007cef4ddce9ac  mov [r15+r14*8+0x368], rcx
00007cef4ddce9b4  add r14d, 0x01
00007cef4ddce9b8  and r14d, 0x07
00007cef4ddce9bc  mov [r15+0x320], r14d
00007cef4ddce9c3  cmp dword ptr [r15+0x318], 0x00
00007cef4ddce9cb  jz 0x00007CEF4DDCEC20
00007cef4ddce9d1  nop [rax+rax*1], ax
00007cef4ddce9da  nop [rax+rax*1], eax
00007cef4ddce9e2  mov eax, 0x410338
00007cef4ddce9e7  mov [r15+0x100], rax
00007cef4ddce9ee  jmp 0x00007CEF4DBFE110
00007cef4ddce9f3  int3
00007cef4ddce9f4  call 0x00007CEF4DC0BC20
00007cef4ddce9f9  jmp 0x00007CEF4DDCE6CF
00007cef4ddce9fe  call 0x00007CEF4DC0A9A0
00007cef4ddcea03  jmp 0x00007CEF4DDCE6DB
00007cef4ddcea08  call 0x00007CEF4DBFF430
00007cef4ddcea0d  jmp 0x00007CEF4DDCE6E6
00007cef4ddcea12  call 0x00007CEF4DC0E760
00007cef4ddcea17  jmp 0x00007CEF4DDCE6F1
00007cef4ddcea1c  call 0x00007CEF4DC0D4E0
00007cef4ddcea21  jmp 0x00007CEF4DDCE6FC
00007cef4ddcea26  call 0x00007CEF4DC0C260
00007cef4ddcea2b  jmp 0x00007CEF4DDCE707
00007cef4ddcea30  call 0x00007CEF4DC0AFE0
00007cef4ddcea35  jmp 0x00007CEF4DDCE71D
00007cef4ddcea3a  call 0x00007CEF4DBFF540
00007cef4ddcea3f  jmp 0x00007CEF4DDCE728
00007cef4ddcea44  call 0x00007CEF4DC0E880
00007cef4ddcea49  jmp 0x00007CEF4DDCE733
00007cef4ddcea4e  call 0x00007CEF4DC0D600
00007cef4ddcea53  jmp 0x00007CEF4DDCE73E
00007cef4ddcea58  call 0x00007CEF4DC0C380
00007cef4ddcea5d  jmp 0x00007CEF4DDCE749
00007cef4ddcea62  call 0x00007CEF4DC0D4E0
00007cef4ddcea67  jmp 0x00007CEF4DDCE754
00007cef4ddcea6c  call 0x00007CEF4DC0C260
00007cef4ddcea71  jmp 0x00007CEF4DDCE75F
00007cef4ddcea76  call 0x00007CEF4DBFF540
00007cef4ddcea7b  jmp 0x00007CEF4DDCE76A
00007cef4ddcea80  call 0x00007CEF4DC0E880
00007cef4ddcea85  jmp 0x00007CEF4DDCE775
00007cef4ddcea8a  call 0x00007CEF4DC0B100
00007cef4ddcea8f  jmp 0x00007CEF4DDCE780
00007cef4ddcea94  call 0x00007CEF4DC0D600
00007cef4ddcea99  jmp 0x00007CEF4DDCE78B
00007cef4ddcea9e  call 0x00007CEF4DBFF430
00007cef4ddceaa3  jmp 0x00007CEF4DDCE796
00007cef4ddceaa8  call 0x00007CEF4DC0E760
00007cef4ddceaad  jmp 0x00007CEF4DDCE7A1
00007cef4ddceab2  call 0x00007CEF4DC0C380
00007cef4ddceab7  jmp 0x00007CEF4DDCE7AC
00007cef4ddceabc  call 0x00007CEF4DBFF540
00007cef4ddceac1  jmp 0x00007CEF4DDCE7B7
00007cef4ddceac6  call 0x00007CEF4DBFF430
00007cef4ddceacb  jmp 0x00007CEF4DDCE7C2
00007cef4ddcead0  call 0x00007CEF4DC0D4E0
00007cef4ddcead5  jmp 0x00007CEF4DDCE7CD
00007cef4ddceada  call 0x00007CEF4DC0E880
00007cef4ddceadf  jmp 0x00007CEF4DDCE7E0
00007cef4ddceae4  call 0x00007CEF4DBFF540
00007cef4ddceae9  jmp 0x00007CEF4DDCE7EB
00007cef4ddceaee  call 0x00007CEF4DBFF430
00007cef4ddceaf3  jmp 0x00007CEF4DDCE7F6
00007cef4ddceaf8  call 0x00007CEF4DC0E760
00007cef4ddceafd  jmp 0x00007CEF4DDCE801
00007cef4ddceb02  call 0x00007CEF4DC0D600
00007cef4ddceb07  jmp 0x00007CEF4DDCE81F
00007cef4ddceb0c  call 0x00007CEF4DBFF540
00007cef4ddceb11  jmp 0x00007CEF4DDCE82A
00007cef4ddceb16  call 0x00007CEF4DBFF430
00007cef4ddceb1b  jmp 0x00007CEF4DDCE835
00007cef4ddceb20  call 0x00007CEF4DC0D4E0
00007cef4ddceb25  jmp 0x00007CEF4DDCE840
00007cef4ddceb2a  call 0x00007CEF4DC0BC20
00007cef4ddceb2f  jmp 0x00007CEF4DDCE85B
00007cef4ddceb34  call 0x00007CEF4DC0E880
00007cef4ddceb39  jmp 0x00007CEF4DDCE866
00007cef4ddceb3e  call 0x00007CEF4DBFF540
00007cef4ddceb43  jmp 0x00007CEF4DDCE871
00007cef4ddceb48  call 0x00007CEF4DBFF430
00007cef4ddceb4d  jmp 0x00007CEF4DDCE87C
00007cef4ddceb52  call 0x00007CEF4DC0B720
00007cef4ddceb57  jmp 0x00007CEF4DDCE886
00007cef4ddceb5c  call 0x00007CEF4DC0D600
00007cef4ddceb61  jmp 0x00007CEF4DDCE89E
00007cef4ddceb66  call 0x00007CEF4DBFF540
00007cef4ddceb6b  jmp 0x00007CEF4DDCE8A9
00007cef4ddceb70  call 0x00007CEF4DBFF430
00007cef4ddceb75  jmp 0x00007CEF4DDCE8B4
00007cef4ddceb7a  call 0x00007CEF4DCB4CB0
00007cef4ddceb7f  jmp 0x00007CEF4DDCE8C4
00007cef4ddceb84  call 0x00007CEF4DC0E760
00007cef4ddceb89  jmp 0x00007CEF4DDCE8CF
00007cef4ddceb8e  call 0x00007CEF4DC0D4E0
00007cef4ddceb93  jmp 0x00007CEF4DDCE8DA
00007cef4ddceb98  call 0x00007CEF4DBFF540
00007cef4ddceb9d  jmp 0x00007CEF4DDCE8E4
00007cef4ddceba2  call 0x00007CEF4DC0BAE0
00007cef4ddceba7  jmp 0x00007CEF4DDCE8F4
00007cef4ddcebac  call 0x00007CEF4DC0E880
00007cef4ddcebb1  jmp 0x00007CEF4DDCE8FE
00007cef4ddcebb6  call 0x00007CEF4DC0D600
00007cef4ddcebbb  jmp 0x00007CEF4DDCE908
00007cef4ddcebc0  call 0x00007CEF4DBFF430
00007cef4ddcebc5  jmp 0x00007CEF4DDCE913
00007cef4ddcebca  call 0x00007CEF4DC0E760
00007cef4ddcebcf  jmp 0x00007CEF4DDCE91E
00007cef4ddcebd4  call 0x00007CEF4DCD6600
00007cef4ddcebd9  jmp 0x00007CEF4DDCE92C
00007cef4ddcebde  call 0x00007CEF4DC0E880
00007cef4ddcebe3  jmp 0x00007CEF4DDCE936
00007cef4ddcebe8  call 0x00007CEF4DBFF430
00007cef4ddcebed  jmp 0x00007CEF4DDCE941
00007cef4ddcebf2  call 0x00007CEF4DC0E760
00007cef4ddcebf7  jmp 0x00007CEF4DDCE94C
00007cef4ddcebfc  call 0x00007CEF4DBFF540
00007cef4ddcec01  jmp 0x00007CEF4DDCE966
00007cef4ddcec06  call 0x00007CEF4DC0E880
00007cef4ddcec0b  jmp 0x00007CEF4DDCE970
00007cef4ddcec10  int3
00007cef4ddcec11  nop [rax+rax*1], ax
00007cef4ddcec1a  nop [rax+rax*1], ax
00007cef4ddcec20  mov rax, [r15]
00007cef4ddcec23  lea r14, [rax+0x20]
00007cef4ddcec27  mov r12, [r13+r14*1]
00007cef4ddcec2c  mov r14, [r15+0x10]
00007cef4ddcec30  lea r11, [r12+r14*1]
00007cef4ddcec34  mov [r15+0x40], r11
00007cef4ddcec38  lea r12, [rax+0x20]
00007cef4ddcec3c  mov [r13+r12*1], r11
00007cef4ddcec41  test r14, r14
00007cef4ddcec44  setz r14b
00007cef4ddcec48  movzx r14, r14b
00007cef4ddcec4c  mov [rsp+0x414], r14b
00007cef4ddcec54  cmp byte ptr [rsp+0x414], 0x00
00007cef4ddcec5c  jz 0x00007CEF4DDCEC8E
00007cef4ddcec5e  cmp dword ptr [r15+0x318], 0x00
00007cef4ddcec66  mov eax, 0x4105B0
00007cef4ddcec6b  mov [r15+0x100], rax
00007cef4ddcec72  jz 0x00007CEF4DBFE0A0
00007cef4ddcec78  nop [rax+rax*1], eax
00007cef4ddcec7d  mov eax, 0x4105B0
00007cef4ddcec82  mov [r15+0x100], rax
00007cef4ddcec89  jmp 0x00007CEF4DBFE110
00007cef4ddcec8e  cmp dword ptr [r15+0x318], 0x00
00007cef4ddcec96  jz 0x00007CEF4DDCECE0
00007cef4ddcec9c  nop [rax+rax*1], ax
00007cef4ddceca5  nop [rax+rax*1], eax
00007cef4ddcecad  mov eax, 0x410348
00007cef4ddcecb2  mov [r15+0x100], rax
00007cef4ddcecb9  jmp 0x00007CEF4DBFE110
00007cef4ddcecbe  int3
00007cef4ddcecbf  call 0x00007CEF4DCE27E0
00007cef4ddcecc4  jmp 0x00007CEF4DDCEC2C
00007cef4ddcecc9  call 0x00007CEF4DCC0860
00007cef4ddcecce  jmp 0x00007CEF4DDCEC41
00007cef4ddcecd3  int3
00007cef4ddcecd4  nop [rax+rax*1], ax
00007cef4ddcecdd  nop [rax], eax
00007cef4ddcece0  mov rax, [r15+0xF8]
00007cef4ddcece7  lea r14, [rax-0x150]
00007cef4ddcecee  mov [r15+0xF8], r14
00007cef4ddcecf5  mov rax, [r15]
00007cef4ddcecf8  lea r12, [rax+0x68]
00007cef4ddcecfc  mov r11, [r13+r12*1]
00007cef4ddced01  mov [r15+0x88], r11
00007cef4ddced08  lea r12, [rax+0x28]
00007cef4ddced0c  mov [r15+0x40], r12
00007cef4ddced10  mov [r15+0x48], r14
00007cef4ddced14  mov qword ptr [r15+0x50], 0x420758
00007cef4ddced1c  lea rax, [r14+0x100]
00007cef4ddced23  mov r12, [r15+0xE8]
00007cef4ddced2a  mov r11, [r15+0xD8]
00007cef4ddced31  mov [r13+rax*1], r12
00007cef4ddced36  lea rax, [r14+0x108]
00007cef4ddced3d  mov [r13+rax*1], r11
00007cef4ddced42  lea rax, [r14+0x110]
00007cef4ddced49  mov r12, [r15+0xD0]
00007cef4ddced50  mov r11, [r15+0xC8]
00007cef4ddced57  mov [r13+rax*1], r12
00007cef4ddced5c  lea rax, [r14+0x118]
00007cef4ddced63  mov [r13+rax*1], r11
00007cef4ddced68  lea rax, [r14+0x120]
00007cef4ddced6f  mov r12, [r15+0xC0]
00007cef4ddced76  mov r11, [r15+0xB8]
00007cef4ddced7d  mov [r13+rax*1], r12
00007cef4ddced82  lea rax, [r14+0x128]
00007cef4ddced89  mov [r13+rax*1], r11
00007cef4ddced8e  lea rax, [r14+0x130]
00007cef4ddced95  mov r12, [r15+0xB0]
00007cef4ddced9c  mov r11, [r15+0xA8]
00007cef4ddceda3  mov [r13+rax*1], r12
00007cef4ddceda8  lea rax, [r14+0x138]
00007cef4ddcedaf  mov [r13+rax*1], r11
00007cef4ddcedb4  lea rax, [r14+0x140]
00007cef4ddcedbb  mov r12, [r15+0xA0]
00007cef4ddcedc2  mov r11, [r15+0x98]
00007cef4ddcedc9  mov [r13+rax*1], r12
00007cef4ddcedce  lea rax, [r14+0x148]
00007cef4ddcedd5  mov [r13+rax*1], r11
00007cef4ddcedda  cmp dword ptr [r15+0x318], 0x00
00007cef4ddcede2  jz 0x00007CEF4DDCEE80
00007cef4ddcede8  nop [rax+rax*1], ax
00007cef4ddcedf1  nop [rax+rax*1], eax
00007cef4ddcedf9  mov eax, 0x410380
00007cef4ddcedfe  mov [r15+0x100], rax
00007cef4ddcee05  jmp 0x00007CEF4DBFE110
00007cef4ddcee0a  int3
00007cef4ddcee0b  call 0x00007CEF4DCC0370
00007cef4ddcee10  jmp 0x00007CEF4DDCED01
00007cef4ddcee15  call 0x00007CEF4DC0BC20
00007cef4ddcee1a  jmp 0x00007CEF4DDCED36
00007cef4ddcee1f  call 0x00007CEF4DC0A9A0
00007cef4ddcee24  jmp 0x00007CEF4DDCED42
00007cef4ddcee29  call 0x00007CEF4DC0BC20
00007cef4ddcee2e  jmp 0x00007CEF4DDCED5C
00007cef4ddcee33  call 0x00007CEF4DC0A9A0
00007cef4ddcee38  jmp 0x00007CEF4DDCED68
00007cef4ddcee3d  call 0x00007CEF4DC0BC20
00007cef4ddcee42  jmp 0x00007CEF4DDCED82
00007cef4ddcee47  call 0x00007CEF4DC0A9A0
00007cef4ddcee4c  jmp 0x00007CEF4DDCED8E
00007cef4ddcee51  call 0x00007CEF4DC0BC20
00007cef4ddcee56  jmp 0x00007CEF4DDCEDA8
00007cef4ddcee5b  call 0x00007CEF4DC0A9A0
00007cef4ddcee60  jmp 0x00007CEF4DDCEDB4
00007cef4ddcee65  call 0x00007CEF4DC0BC20
00007cef4ddcee6a  jmp 0x00007CEF4DDCEDCE
00007cef4ddcee6f  call 0x00007CEF4DC0A9A0
00007cef4ddcee74  jmp 0x00007CEF4DDCEDDA
00007cef4ddcee79  int3
00007cef4ddcee7a  nop [rax+rax*1], ax
00007cef4ddcee80  mov rax, [r15+0x08]
00007cef4ddcee84  movzx r14d, byte ptr [r13+rax*1]
00007cef4ddcee8a  movzx r14d, r14b
00007cef4ddcee8e  mov [rsp+0x10], r14d
00007cef4ddcee93  mov r14d, r14d
00007cef4ddcee96  mov [r15+0x58], r14
00007cef4ddcee9a  lea r14, [rax+0x01]
00007cef4ddcee9e  mov [r15+0x08], r14
00007cef4ddceea2  mov rax, [r15+0x88]
00007cef4ddceea9  lea r14, [rax+0x01]
00007cef4ddceead  mov r12, [r15]
00007cef4ddceeb0  lea r11, [r12+0x68]
00007cef4ddceeb5  mov [r13+r11*1], r14
00007cef4ddceeba  lea r14, [r12+rax*1]
00007cef4ddceebe  mov [r15+0x60], r14
00007cef4ddceec2  lea rax, [r14+0x28]
00007cef4ddceec6  mov r11d, [rsp+0x10]
00007cef4ddceecb  movzx r14d, r11b
00007cef4ddceecf  mov [r13+rax*1], r14b
00007cef4ddceed4  lea rax, [r12+0x68]
00007cef4ddceed9  mov r14, [r13+rax*1]
00007cef4ddceede  mov [r15+0x88], r14
00007cef4ddceee5  xor eax, eax
00007cef4ddceee7  mov r12d, 0x40
00007cef4ddceeed  cmp r14, r12
00007cef4ddceef0  cmc
00007cef4ddceef1  lahf
00007cef4ddceef2  seto al
00007cef4ddceef5  mov [r15+0x108], eax
00007cef4ddceefc  mov eax, [r15+0x108]
00007cef4ddcef03  sahf
00007cef4ddcef04  jnz 0x00007CEF4DDCEF36
00007cef4ddcef06  cmp dword ptr [r15+0x318], 0x00
00007cef4ddcef0e  jz 0x00007CEF4DDCF020
00007cef4ddcef14  nop [rax+rax*1], ax
00007cef4ddcef1d  nop [rax+rax*1], eax
00007cef4ddcef25  mov eax, 0x4103A0
00007cef4ddcef2a  mov [r15+0x100], rax
00007cef4ddcef31  jmp 0x00007CEF4DBFE110
00007cef4ddcef36  cmp dword ptr [r15+0x318], 0x00
00007cef4ddcef3e  jz 0x00007CEF4DDCEF90
00007cef4ddcef44  nop [rax+rax*1], ax
00007cef4ddcef4d  nop [rax+rax*1], eax
00007cef4ddcef55  mov eax, 0x410378
00007cef4ddcef5a  mov [r15+0x100], rax
00007cef4ddcef61  jmp 0x00007CEF4DBFE110
00007cef4ddcef66  int3
00007cef4ddcef67  call 0x00007CEF4DC0D860
00007cef4ddcef6c  jmp 0x00007CEF4DDCEE8A
00007cef4ddcef71  call 0x00007CEF4DCB36E0
00007cef4ddcef76  jmp 0x00007CEF4DDCEEBA
00007cef4ddcef7b  call 0x00007CEF4DC0DD60
00007cef4ddcef80  jmp 0x00007CEF4DDCEED4
00007cef4ddcef85  call 0x00007CEF4DC0DC20
00007cef4ddcef8a  jmp 0x00007CEF4DDCEEDE
00007cef4ddcef8f  int3
00007cef4ddcef90  mov rax, [r15+0x10]
00007cef4ddcef94  lea r14, [rax-0x01]
00007cef4ddcef98  mov [r15+0x10], r14
00007cef4ddcef9c  test r14, r14
00007cef4ddcef9f  setz r14b
00007cef4ddcefa3  movzx r14, r14b
00007cef4ddcefa7  mov [rsp+0x414], r14b
00007cef4ddcefaf  cmp byte ptr [rsp+0x414], 0x00
00007cef4ddcefb7  jz 0x00007CEF4DDCEFE9
00007cef4ddcefb9  cmp dword ptr [r15+0x318], 0x00
00007cef4ddcefc1  jz 0x00007CEF4DDD0520
00007cef4ddcefc7  nop [rax+rax*1], ax
00007cef4ddcefd0  nop [rax+rax*1], eax
00007cef4ddcefd8  mov eax, 0x410598
00007cef4ddcefdd  mov [r15+0x100], rax
00007cef4ddcefe4  jmp 0x00007CEF4DBFE110
00007cef4ddcefe9  cmp dword ptr [r15+0x318], 0x00
00007cef4ddceff1  jz 0x00007CEF4DDCEE80
00007cef4ddceff7  nop [rax+rax*1], ax
00007cef4ddcf000  nop [rax+rax*1], eax
00007cef4ddcf008  mov eax, 0x410380
00007cef4ddcf00d  mov [r15+0x100], rax
00007cef4ddcf014  jmp 0x00007CEF4DBFE110
00007cef4ddcf019  int3
00007cef4ddcf01a  int3
00007cef4ddcf01b  nop [rax+rax*1], eax
00007cef4ddcf020  mov rax, [r15+0x40]
00007cef4ddcf024  movzx r14d, byte ptr [r13+rax*1]
00007cef4ddcf02a  movaps xmm1, [r15+0x110]
00007cef4ddcf032  pinsrb xmm1, r14d, 0x00
00007cef4ddcf039  lea r14, [rax+0x01]
00007cef4ddcf03d  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf043  movaps xmm15, [r15+0x120]
00007cef4ddcf04b  pinsrb xmm15, r12d, 0x00
00007cef4ddcf052  lea r14, [rax+0x02]
00007cef4ddcf056  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf05c  movaps xmm14, [r15+0x130]
00007cef4ddcf064  pinsrb xmm14, r12d, 0x00
00007cef4ddcf06b  lea r14, [rax+0x03]
00007cef4ddcf06f  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf075  movaps xmm13, [r15+0x140]
00007cef4ddcf07d  pinsrb xmm13, r12d, 0x00
00007cef4ddcf084  lea r14, [rax+0x04]
00007cef4ddcf088  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf08e  pinsrb xmm1, r12d, 0x01
00007cef4ddcf095  lea r14, [rax+0x05]
00007cef4ddcf099  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf09f  pinsrb xmm15, r12d, 0x01
00007cef4ddcf0a6  lea r14, [rax+0x06]
00007cef4ddcf0aa  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf0b0  pinsrb xmm14, r12d, 0x01
00007cef4ddcf0b7  lea r14, [rax+0x07]
00007cef4ddcf0bb  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf0c1  pinsrb xmm13, r12d, 0x01
00007cef4ddcf0c8  lea r14, [rax+0x08]
00007cef4ddcf0cc  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf0d2  pinsrb xmm1, r12d, 0x02
00007cef4ddcf0d9  lea r14, [rax+0x09]
00007cef4ddcf0dd  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf0e3  pinsrb xmm15, r12d, 0x02
00007cef4ddcf0ea  lea r14, [rax+0x0A]
00007cef4ddcf0ee  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf0f4  pinsrb xmm14, r12d, 0x02
00007cef4ddcf0fb  lea r14, [rax+0x0B]
00007cef4ddcf0ff  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf105  pinsrb xmm13, r12d, 0x02
00007cef4ddcf10c  lea r14, [rax+0x0C]
00007cef4ddcf110  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf116  pinsrb xmm1, r12d, 0x03
00007cef4ddcf11d  lea r14, [rax+0x0D]
00007cef4ddcf121  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf127  pinsrb xmm15, r12d, 0x03
00007cef4ddcf12e  lea r14, [rax+0x0E]
00007cef4ddcf132  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf138  pinsrb xmm14, r12d, 0x03
00007cef4ddcf13f  lea r14, [rax+0x0F]
00007cef4ddcf143  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf149  pinsrb xmm13, r12d, 0x03
00007cef4ddcf150  lea r14, [rax+0x10]
00007cef4ddcf154  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf15a  pinsrb xmm1, r12d, 0x04
00007cef4ddcf161  lea r14, [rax+0x11]
00007cef4ddcf165  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf16b  pinsrb xmm15, r12d, 0x04
00007cef4ddcf172  lea r14, [rax+0x12]
00007cef4ddcf176  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf17c  pinsrb xmm14, r12d, 0x04
00007cef4ddcf183  lea r14, [rax+0x13]
00007cef4ddcf187  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf18d  pinsrb xmm13, r12d, 0x04
00007cef4ddcf194  lea r14, [rax+0x14]
00007cef4ddcf198  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf19e  pinsrb xmm1, r12d, 0x05
00007cef4ddcf1a5  lea r14, [rax+0x15]
00007cef4ddcf1a9  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf1af  pinsrb xmm15, r12d, 0x05
00007cef4ddcf1b6  lea r14, [rax+0x16]
00007cef4ddcf1ba  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf1c0  pinsrb xmm14, r12d, 0x05
00007cef4ddcf1c7  lea r14, [rax+0x17]
00007cef4ddcf1cb  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf1d1  pinsrb xmm13, r12d, 0x05
00007cef4ddcf1d8  lea r14, [rax+0x18]
00007cef4ddcf1dc  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf1e2  pinsrb xmm1, r12d, 0x06
00007cef4ddcf1e9  lea r14, [rax+0x19]
00007cef4ddcf1ed  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf1f3  pinsrb xmm15, r12d, 0x06
00007cef4ddcf1fa  lea r14, [rax+0x1A]
00007cef4ddcf1fe  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf204  pinsrb xmm14, r12d, 0x06
00007cef4ddcf20b  lea r14, [rax+0x1B]
00007cef4ddcf20f  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf215  pinsrb xmm13, r12d, 0x06
00007cef4ddcf21c  lea r14, [rax+0x1C]
00007cef4ddcf220  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf226  pinsrb xmm1, r12d, 0x07
00007cef4ddcf22d  lea r14, [rax+0x1D]
00007cef4ddcf231  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf237  pinsrb xmm15, r12d, 0x07
00007cef4ddcf23e  lea r14, [rax+0x1E]
00007cef4ddcf242  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf248  pinsrb xmm14, r12d, 0x07
00007cef4ddcf24f  lea r14, [rax+0x1F]
00007cef4ddcf253  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf259  pinsrb xmm13, r12d, 0x07
00007cef4ddcf260  lea r14, [rax+0x20]
00007cef4ddcf264  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf26a  pinsrb xmm1, r12d, 0x08
00007cef4ddcf271  lea r14, [rax+0x21]
00007cef4ddcf275  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf27b  pinsrb xmm15, r12d, 0x08
00007cef4ddcf282  lea r14, [rax+0x22]
00007cef4ddcf286  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf28c  pinsrb xmm14, r12d, 0x08
00007cef4ddcf293  lea r14, [rax+0x23]
00007cef4ddcf297  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf29d  pinsrb xmm13, r12d, 0x08
00007cef4ddcf2a4  lea r14, [rax+0x24]
00007cef4ddcf2a8  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf2ae  pinsrb xmm1, r12d, 0x09
00007cef4ddcf2b5  lea r14, [rax+0x25]
00007cef4ddcf2b9  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf2bf  pinsrb xmm15, r12d, 0x09
00007cef4ddcf2c6  lea r14, [rax+0x26]
00007cef4ddcf2ca  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf2d0  pinsrb xmm14, r12d, 0x09
00007cef4ddcf2d7  lea r14, [rax+0x27]
00007cef4ddcf2db  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf2e1  pinsrb xmm13, r12d, 0x09
00007cef4ddcf2e8  lea r14, [rax+0x28]
00007cef4ddcf2ec  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf2f2  pinsrb xmm1, r12d, 0x0A
00007cef4ddcf2f9  lea r14, [rax+0x29]
00007cef4ddcf2fd  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf303  pinsrb xmm15, r12d, 0x0A
00007cef4ddcf30a  lea r14, [rax+0x2A]
00007cef4ddcf30e  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf314  pinsrb xmm14, r12d, 0x0A
00007cef4ddcf31b  lea r14, [rax+0x2B]
00007cef4ddcf31f  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf325  pinsrb xmm13, r12d, 0x0A
00007cef4ddcf32c  lea r14, [rax+0x2C]
00007cef4ddcf330  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf336  pinsrb xmm1, r12d, 0x0B
00007cef4ddcf33d  lea r14, [rax+0x2D]
00007cef4ddcf341  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf347  pinsrb xmm15, r12d, 0x0B
00007cef4ddcf34e  lea r14, [rax+0x2E]
00007cef4ddcf352  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf358  pinsrb xmm14, r12d, 0x0B
00007cef4ddcf35f  lea r14, [rax+0x2F]
00007cef4ddcf363  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf369  pinsrb xmm13, r12d, 0x0B
00007cef4ddcf370  lea r14, [rax+0x30]
00007cef4ddcf374  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf37a  pinsrb xmm1, r12d, 0x0C
00007cef4ddcf381  lea r14, [rax+0x31]
00007cef4ddcf385  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf38b  pinsrb xmm15, r12d, 0x0C
00007cef4ddcf392  lea r14, [rax+0x32]
00007cef4ddcf396  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf39c  pinsrb xmm14, r12d, 0x0C
00007cef4ddcf3a3  lea r14, [rax+0x33]
00007cef4ddcf3a7  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf3ad  pinsrb xmm13, r12d, 0x0C
00007cef4ddcf3b4  lea r14, [rax+0x34]
00007cef4ddcf3b8  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf3be  pinsrb xmm1, r12d, 0x0D
00007cef4ddcf3c5  lea r14, [rax+0x35]
00007cef4ddcf3c9  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf3cf  pinsrb xmm15, r12d, 0x0D
00007cef4ddcf3d6  lea r14, [rax+0x36]
00007cef4ddcf3da  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf3e0  pinsrb xmm14, r12d, 0x0D
00007cef4ddcf3e7  lea r14, [rax+0x37]
00007cef4ddcf3eb  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf3f1  pinsrb xmm13, r12d, 0x0D
00007cef4ddcf3f8  lea r14, [rax+0x38]
00007cef4ddcf3fc  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf402  pinsrb xmm1, r12d, 0x0E
00007cef4ddcf409  lea r14, [rax+0x39]
00007cef4ddcf40d  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf413  pinsrb xmm15, r12d, 0x0E
00007cef4ddcf41a  lea r14, [rax+0x3A]
00007cef4ddcf41e  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf424  pinsrb xmm14, r12d, 0x0E
00007cef4ddcf42b  lea r14, [rax+0x3B]
00007cef4ddcf42f  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf435  pinsrb xmm13, r12d, 0x0E
00007cef4ddcf43c  lea r14, [rax+0x3C]
00007cef4ddcf440  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf446  pinsrb xmm1, r12d, 0x0F
00007cef4ddcf44d  movaps [r15+0x110], xmm1
00007cef4ddcf455  lea r14, [rax+0x3D]
00007cef4ddcf459  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf45f  pinsrb xmm15, r12d, 0x0F
00007cef4ddcf466  movaps [r15+0x120], xmm15
00007cef4ddcf46e  lea r14, [rax+0x3E]
00007cef4ddcf472  movzx r12d, byte ptr [r13+r14*1]
00007cef4ddcf478  pinsrb xmm14, r12d, 0x0F
00007cef4ddcf47f  movaps [r15+0x130], xmm14
00007cef4ddcf487  lea r14, [rax+0x3F]
00007cef4ddcf48b  movzx eax, byte ptr [r13+r14*1]
00007cef4ddcf491  pinsrb xmm13, eax, 0x0F
00007cef4ddcf498  movaps [r15+0x140], xmm13
00007cef4ddcf4a0  movq xmm1, qword ptr [r15+0x120]
00007cef4ddcf4a9  pmovzxbw xmm1, xmm1
00007cef4ddcf4ae  psllw xmm1, 0x00
00007cef4ddcf4b3  movaps [r15+0x150], xmm1
00007cef4ddcf4bb  movq xmm1, qword ptr [r15+0x130]
00007cef4ddcf4c4  pmovzxbw xmm1, xmm1
00007cef4ddcf4c9  psllw xmm1, 0x00
00007cef4ddcf4ce  movaps [r15+0x160], xmm1
00007cef4ddcf4d6  movq xmm1, qword ptr [r15+0x110]
00007cef4ddcf4df  pmovzxbw xmm1, xmm1
00007cef4ddcf4e4  psllw xmm1, 0x00
00007cef4ddcf4e9  movaps [r15+0x170], xmm1
00007cef4ddcf4f1  movaps xmm15, [r15+0x110]
00007cef4ddcf4f9  pextrq rax, xmm15, 0x01
00007cef4ddcf500  movq xmm15, rax
00007cef4ddcf505  pmovzxbw xmm15, xmm15
00007cef4ddcf50b  psllw xmm15, 0x00
00007cef4ddcf511  movaps [r15+0x180], xmm15
00007cef4ddcf519  movaps xmm14, [r15+0x120]
00007cef4ddcf521  pextrq rax, xmm14, 0x01
00007cef4ddcf528  movq xmm14, rax
00007cef4ddcf52d  pmovzxbw xmm14, xmm14
00007cef4ddcf533  psllw xmm14, 0x00
00007cef4ddcf539  movaps [r15+0x210], xmm14
00007cef4ddcf541  movaps xmm13, [r15+0x130]
00007cef4ddcf549  pextrq rax, xmm13, 0x01
00007cef4ddcf550  movq xmm13, rax
00007cef4ddcf555  pmovzxbw xmm13, xmm13
00007cef4ddcf55b  psllw xmm13, 0x00
00007cef4ddcf561  movaps [r15+0x220], xmm13
00007cef4ddcf569  movq xmm12, qword ptr [r15+0x140]
00007cef4ddcf572  pmovzxbw xmm12, xmm12
00007cef4ddcf578  psllw xmm12, 0x00
00007cef4ddcf57e  movaps [r15+0x250], xmm12
00007cef4ddcf586  movaps xmm12, [r15+0x140]
00007cef4ddcf58e  pextrq rax, xmm12, 0x01
00007cef4ddcf595  movq xmm12, rax
00007cef4ddcf59a  pmovzxbw xmm12, xmm12
00007cef4ddcf5a0  psllw xmm12, 0x00
00007cef4ddcf5a6  movaps [r15+0x110], xmm12
00007cef4ddcf5ae  movq xmm11, qword ptr [r15+0x150]
00007cef4ddcf5b7  pmovzxwd xmm11, xmm11
00007cef4ddcf5bd  pslld xmm11, 0x10
00007cef4ddcf5c3  movq xmm10, qword ptr [r15+0x160]
00007cef4ddcf5cc  pmovzxwd xmm10, xmm10
00007cef4ddcf5d2  pslld xmm10, 0x08
00007cef4ddcf5d8  pextrq rax, xmm1, 0x01
00007cef4ddcf5df  movq xmm1, rax
00007cef4ddcf5e4  pmovzxwd xmm1, xmm1
00007cef4ddcf5e9  pslld xmm1, 0x00
00007cef4ddcf5ee  movaps [r15+0x260], xmm1
00007cef4ddcf5f6  pextrq rax, xmm15, 0x01
00007cef4ddcf5fd  movq xmm15, rax
00007cef4ddcf602  pmovzxwd xmm15, xmm15
00007cef4ddcf608  pslld xmm15, 0x00
00007cef4ddcf60e  movaps [r15+0x270], xmm15
00007cef4ddcf616  movq xmm9, qword ptr [r15+0x170]
00007cef4ddcf61f  pmovzxwd xmm9, xmm9
00007cef4ddcf625  pslld xmm9, 0x00
00007cef4ddcf62b  pextrq rax, xmm14, 0x01
00007cef4ddcf632  movq xmm14, rax
00007cef4ddcf637  pmovzxwd xmm14, xmm14
00007cef4ddcf63d  pslld xmm14, 0x10
00007cef4ddcf643  movaps [r15+0x280], xmm14
00007cef4ddcf64b  movq xmm8, qword ptr [r15+0x180]
00007cef4ddcf654  pmovzxwd xmm8, xmm8
00007cef4ddcf65a  pslld xmm8, 0x00
00007cef4ddcf660  movq xmm7, qword ptr [r15+0x210]
00007cef4ddcf669  pmovzxwd xmm7, xmm7
00007cef4ddcf66e  pslld xmm7, 0x10
00007cef4ddcf673  movaps xmm6, [r15+0x150]
00007cef4ddcf67b  pextrq rax, xmm6, 0x01
00007cef4ddcf682  movq xmm6, rax
00007cef4ddcf687  pmovzxwd xmm6, xmm6
00007cef4ddcf68c  pslld xmm6, 0x10
00007cef4ddcf691  por xmm11, xmm10
00007cef4ddcf696  movaps [r15+0x230], xmm11
00007cef4ddcf69e  pextrq rax, xmm13, 0x01
00007cef4ddcf6a5  movq xmm13, rax
00007cef4ddcf6aa  pmovzxwd xmm13, xmm13
00007cef4ddcf6b0  pslld xmm13, 0x08
00007cef4ddcf6b6  movaps [r15+0x240], xmm13
00007cef4ddcf6be  movq xmm10, qword ptr [r15+0x220]
00007cef4ddcf6c7  pmovzxwd xmm10, xmm10
00007cef4ddcf6cd  pslld xmm10, 0x08
00007cef4ddcf6d3  movaps xmm5, [r15+0x160]
00007cef4ddcf6db  pextrq rax, xmm5, 0x01
00007cef4ddcf6e2  movq xmm5, rax
00007cef4ddcf6e7  pmovzxwd xmm5, xmm5
00007cef4ddcf6ec  pslld xmm5, 0x08
00007cef4ddcf6f1  pslld xmm9, 0x18
00007cef4ddcf6f7  pslld xmm15, 0x18
00007cef4ddcf6fd  pslld xmm8, 0x18
00007cef4ddcf703  movq xmm4, qword ptr [r15+0x250]
00007cef4ddcf70c  pmovzxwd xmm4, xmm4
00007cef4ddcf711  pslld xmm4, 0x00
00007cef4ddcf716  por xmm14, xmm13
00007cef4ddcf71b  por xmm7, xmm10
00007cef4ddcf720  movaps [r15+0x210], xmm7
00007cef4ddcf728  pslld xmm1, 0x18
00007cef4ddcf72d  movaps [r15+0x220], xmm1
00007cef4ddcf735  por xmm6, xmm5
00007cef4ddcf739  por xmm11, xmm9
00007cef4ddcf73e  movaps [r15+0x160], xmm11
00007cef4ddcf746  pextrq rax, xmm12, 0x01
00007cef4ddcf74d  movq xmm13, rax
00007cef4ddcf752  pmovzxwd xmm13, xmm13
00007cef4ddcf758  pslld xmm13, 0x00
00007cef4ddcf75e  movaps [r15+0x170], xmm13
00007cef4ddcf766  movq xmm12, qword ptr [r15+0x110]
00007cef4ddcf76f  pmovzxwd xmm12, xmm12
00007cef4ddcf775  pslld xmm12, 0x00
00007cef4ddcf77b  por xmm14, xmm15
00007cef4ddcf780  por xmm7, xmm8
00007cef4ddcf785  movaps xmm15, [r15+0x250]
00007cef4ddcf78d  pextrq rax, xmm15, 0x01
00007cef4ddcf794  movq xmm15, rax
00007cef4ddcf799  pmovzxwd xmm15, xmm15
00007cef4ddcf79f  pslld xmm15, 0x00
00007cef4ddcf7a5  movaps [r15+0x180], xmm15
00007cef4ddcf7ad  por xmm6, xmm1
00007cef4ddcf7b1  movaps [r15+0x150], xmm6
00007cef4ddcf7b9  por xmm11, xmm4
00007cef4ddcf7be  movaps [r15+0x140], xmm11
00007cef4ddcf7c6  por xmm7, xmm12
00007cef4ddcf7cb  movaps [r15+0x110], xmm7
00007cef4ddcf7d3  por xmm14, xmm13
00007cef4ddcf7d8  movaps [r15+0x120], xmm14
00007cef4ddcf7e0  por xmm6, xmm15
00007cef4ddcf7e5  movaps [r15+0x130], xmm6
00007cef4ddcf7ed  mov rax, [r15+0xF8]
00007cef4ddcf7f4  lea r14, [rax+0x20]
00007cef4ddcf7f8  movups [r13+r14*1], xmm7
00007cef4ddcf7fe  lea r14, [rax+0x30]
00007cef4ddcf802  movups [r13+r14*1], xmm14
00007cef4ddcf808  movups [r13+rax*1], xmm11
00007cef4ddcf80e  lea r14, [rax+0x10]
00007cef4ddcf812  movups [r13+r14*1], xmm6
00007cef4ddcf818  mov r14d, [r13+rax*1]
00007cef4ddcf81d  mov rax, [r15+0x48]
00007cef4ddcf821  mov [r15+0x68], rax
00007cef4ddcf825  mov qword ptr [r15+0x58], 0x04
00007cef4ddcf82d  lea r12, [rax+0x04]
00007cef4ddcf831  mov r11d, [r13+r12*1]
00007cef4ddcf836  mov [rsp+0x10], r11d
00007cef4ddcf83b  mov r11d, r11d
00007cef4ddcf83e  mov [r15+0x70], r11
00007cef4ddcf842  lea r12, [rax+0x38]
00007cef4ddcf846  mov r11d, [r13+r12*1]
00007cef4ddcf84b  lea r12, [rax+0x24]
00007cef4ddcf84f  mov r10d, [r13+r12*1]
00007cef4ddcf854  mov [rsp+0x20], r10d
00007cef4ddcf859  mov r10d, r10d
00007cef4ddcf85c  mov [r15+0x90], r10
00007cef4ddcf863  mov [rsp+0x30], rax
00007cef4ddcf868  xor eax, eax
00007cef4ddcf86a  mov r12d, 0x04
00007cef4ddcf870  mov r10d, 0xC0
00007cef4ddcf876  cmp r12, r10
00007cef4ddcf879  cmc
00007cef4ddcf87a  lahf
00007cef4ddcf87b  seto al
00007cef4ddcf87e  mov [r15+0x108], eax
00007cef4ddcf885  mov eax, [rsp+0x10]
00007cef4ddcf889  mov r12d, [rsp+0x10]
00007cef4ddcf88e  shrd eax, r12d, 0x07
00007cef4ddcf893  mov [rsp+0x10], r11d
00007cef4ddcf898  mov r10d, [rsp+0x10]
00007cef4ddcf89d  shrd r11d, r10d, 0x11
00007cef4ddcf8a2  mov r9d, [rsp+0x20]
00007cef4ddcf8a7  lea r8d, [r9d+r14d*1]
00007cef4ddcf8ac  rorx r14d, r12d, 0x12
00007cef4ddcf8b2  xor eax, r14d
00007cef4ddcf8b5  rorx r14d, r10d, 0x13
00007cef4ddcf8bb  xor r11d, r14d
00007cef4ddcf8be  mov [rsp+0x10], r11d
00007cef4ddcf8c3  mov r11d, r11d
00007cef4ddcf8c6  mov [r15+0x88], r11
00007cef4ddcf8cd  mov [rsp+0x20], r12d
00007cef4ddcf8d2  shr r12d, 0x03
00007cef4ddcf8d6  xor eax, r12d
00007cef4ddcf8d9  mov [rsp+0x40], eax
00007cef4ddcf8dd  mov eax, eax
00007cef4ddcf8df  mov [r15+0x80], rax
00007cef4ddcf8e6  shr r10d, 0x0A
00007cef4ddcf8ea  mov eax, [rsp+0x10]
00007cef4ddcf8ee  xor eax, r10d
00007cef4ddcf8f1  mov [rsp+0x10], eax
00007cef4ddcf8f5  mov eax, eax
00007cef4ddcf8f7  mov [r15+0x78], rax
00007cef4ddcf8fb  mov eax, [rsp+0x40]
00007cef4ddcf8ff  lea r14d, [r8d+eax*1]
00007cef4ddcf904  mov eax, [rsp+0x10]
00007cef4ddcf908  lea r12d, [r14d+eax*1]
00007cef4ddcf90d  mov rax, [rsp+0x30]
00007cef4ddcf912  lea r14, [rax+0x40]
00007cef4ddcf916  mov [r13+r14*1], r12d
00007cef4ddcf91b  mov eax, [rsp+0x20]
00007cef4ddcf91f  mov eax, eax
00007cef4ddcf921  mov [r15+0x60], rax
00007cef4ddcf925  mov eax, [r15+0x108]
00007cef4ddcf92c  sahf
00007cef4ddcf92d  jnz 0x00007CEF4DDCF95F
00007cef4ddcf92f  cmp dword ptr [r15+0x318], 0x00
00007cef4ddcf937  jz 0x00007CEF4DDCFE20
00007cef4ddcf93d  nop [rax+rax*1], ax
00007cef4ddcf946  nop [rax+rax*1], eax
00007cef4ddcf94e  mov eax, 0x41049C
00007cef4ddcf953  mov [r15+0x100], rax
00007cef4ddcf95a  jmp 0x00007CEF4DBFE110
00007cef4ddcf95f  cmp dword ptr [r15+0x318], 0x00
00007cef4ddcf967  jz 0x00007CEF4DDCFC70
00007cef4ddcf96d  nop [rax+rax*1], ax
00007cef4ddcf976  nop [rax+rax*1], eax
00007cef4ddcf97e  mov eax, 0x410454
00007cef4ddcf983  mov [r15+0x100], rax
00007cef4ddcf98a  jmp 0x00007CEF4DBFE110
00007cef4ddcf98f  int3
00007cef4ddcf990  call 0x00007CEF4DC0D860
00007cef4ddcf995  jmp 0x00007CEF4DDCF02A
00007cef4ddcf99a  call 0x00007CEF4DCE2420
00007cef4ddcf99f  jmp 0x00007CEF4DDCF043
00007cef4ddcf9a4  call 0x00007CEF4DCE2420
00007cef4ddcf9a9  jmp 0x00007CEF4DDCF05C
00007cef4ddcf9ae  call 0x00007CEF4DCE2420
00007cef4ddcf9b3  jmp 0x00007CEF4DDCF075
00007cef4ddcf9b8  call 0x00007CEF4DCE2420
00007cef4ddcf9bd  jmp 0x00007CEF4DDCF08E
00007cef4ddcf9c2  call 0x00007CEF4DCE2420
00007cef4ddcf9c7  jmp 0x00007CEF4DDCF09F
00007cef4ddcf9cc  call 0x00007CEF4DCE2420
00007cef4ddcf9d1  jmp 0x00007CEF4DDCF0B0
00007cef4ddcf9d6  call 0x00007CEF4DCE2420
00007cef4ddcf9db  jmp 0x00007CEF4DDCF0C1
00007cef4ddcf9e0  call 0x00007CEF4DCE2420
00007cef4ddcf9e5  jmp 0x00007CEF4DDCF0D2
00007cef4ddcf9ea  call 0x00007CEF4DCE2420
00007cef4ddcf9ef  jmp 0x00007CEF4DDCF0E3
00007cef4ddcf9f4  call 0x00007CEF4DCE2420
00007cef4ddcf9f9  jmp 0x00007CEF4DDCF0F4
00007cef4ddcf9fe  call 0x00007CEF4DCE2420
00007cef4ddcfa03  jmp 0x00007CEF4DDCF105
00007cef4ddcfa08  call 0x00007CEF4DCE2420
00007cef4ddcfa0d  jmp 0x00007CEF4DDCF116
00007cef4ddcfa12  call 0x00007CEF4DCE2420
00007cef4ddcfa17  jmp 0x00007CEF4DDCF127
00007cef4ddcfa1c  call 0x00007CEF4DCE2420
00007cef4ddcfa21  jmp 0x00007CEF4DDCF138
00007cef4ddcfa26  call 0x00007CEF4DCE2420
00007cef4ddcfa2b  jmp 0x00007CEF4DDCF149
00007cef4ddcfa30  call 0x00007CEF4DCE2420
00007cef4ddcfa35  jmp 0x00007CEF4DDCF15A
00007cef4ddcfa3a  call 0x00007CEF4DCE2420
00007cef4ddcfa3f  jmp 0x00007CEF4DDCF16B
00007cef4ddcfa44  call 0x00007CEF4DCE2420
00007cef4ddcfa49  jmp 0x00007CEF4DDCF17C
00007cef4ddcfa4e  call 0x00007CEF4DCE2420
00007cef4ddcfa53  jmp 0x00007CEF4DDCF18D
00007cef4ddcfa58  call 0x00007CEF4DCE2420
00007cef4ddcfa5d  jmp 0x00007CEF4DDCF19E
00007cef4ddcfa62  call 0x00007CEF4DCE2420
00007cef4ddcfa67  jmp 0x00007CEF4DDCF1AF
00007cef4ddcfa6c  call 0x00007CEF4DCE2420
00007cef4ddcfa71  jmp 0x00007CEF4DDCF1C0
00007cef4ddcfa76  call 0x00007CEF4DCE2420
00007cef4ddcfa7b  jmp 0x00007CEF4DDCF1D1
00007cef4ddcfa80  call 0x00007CEF4DCE2420
00007cef4ddcfa85  jmp 0x00007CEF4DDCF1E2
00007cef4ddcfa8a  call 0x00007CEF4DCE2420
00007cef4ddcfa8f  jmp 0x00007CEF4DDCF1F3
00007cef4ddcfa94  call 0x00007CEF4DCE2420
00007cef4ddcfa99  jmp 0x00007CEF4DDCF204
00007cef4ddcfa9e  call 0x00007CEF4DCE2420
00007cef4ddcfaa3  jmp 0x00007CEF4DDCF215
00007cef4ddcfaa8  call 0x00007CEF4DCE2420
00007cef4ddcfaad  jmp 0x00007CEF4DDCF226
00007cef4ddcfab2  call 0x00007CEF4DCE2420
00007cef4ddcfab7  jmp 0x00007CEF4DDCF237
00007cef4ddcfabc  call 0x00007CEF4DCE2420
00007cef4ddcfac1  jmp 0x00007CEF4DDCF248
00007cef4ddcfac6  call 0x00007CEF4DCE2420
00007cef4ddcfacb  jmp 0x00007CEF4DDCF259
00007cef4ddcfad0  call 0x00007CEF4DCE2420
00007cef4ddcfad5  jmp 0x00007CEF4DDCF26A
00007cef4ddcfada  call 0x00007CEF4DCE2420
00007cef4ddcfadf  jmp 0x00007CEF4DDCF27B
00007cef4ddcfae4  call 0x00007CEF4DCE2420
00007cef4ddcfae9  jmp 0x00007CEF4DDCF28C
00007cef4ddcfaee  call 0x00007CEF4DCE2420
00007cef4ddcfaf3  jmp 0x00007CEF4DDCF29D
00007cef4ddcfaf8  call 0x00007CEF4DCE2420
00007cef4ddcfafd  jmp 0x00007CEF4DDCF2AE
00007cef4ddcfb02  call 0x00007CEF4DCE2420
00007cef4ddcfb07  jmp 0x00007CEF4DDCF2BF
00007cef4ddcfb0c  call 0x00007CEF4DCE2420
00007cef4ddcfb11  jmp 0x00007CEF4DDCF2D0
00007cef4ddcfb16  call 0x00007CEF4DCE2420
00007cef4ddcfb1b  jmp 0x00007CEF4DDCF2E1
00007cef4ddcfb20  call 0x00007CEF4DCE2420
00007cef4ddcfb25  jmp 0x00007CEF4DDCF2F2
00007cef4ddcfb2a  call 0x00007CEF4DCE2420
00007cef4ddcfb2f  jmp 0x00007CEF4DDCF303
00007cef4ddcfb34  call 0x00007CEF4DCE2420
00007cef4ddcfb39  jmp 0x00007CEF4DDCF314
00007cef4ddcfb3e  call 0x00007CEF4DCE2420
00007cef4ddcfb43  jmp 0x00007CEF4DDCF325
00007cef4ddcfb48  call 0x00007CEF4DCE2420
00007cef4ddcfb4d  jmp 0x00007CEF4DDCF336
00007cef4ddcfb52  call 0x00007CEF4DCE2420
00007cef4ddcfb57  jmp 0x00007CEF4DDCF347
00007cef4ddcfb5c  call 0x00007CEF4DCE2420
00007cef4ddcfb61  jmp 0x00007CEF4DDCF358
00007cef4ddcfb66  call 0x00007CEF4DCE2420
00007cef4ddcfb6b  jmp 0x00007CEF4DDCF369
00007cef4ddcfb70  call 0x00007CEF4DCE2420
00007cef4ddcfb75  jmp 0x00007CEF4DDCF37A
00007cef4ddcfb7a  call 0x00007CEF4DCE2420
00007cef4ddcfb7f  jmp 0x00007CEF4DDCF38B
00007cef4ddcfb84  call 0x00007CEF4DCE2420
00007cef4ddcfb89  jmp 0x00007CEF4DDCF39C
00007cef4ddcfb8e  call 0x00007CEF4DCE2420
00007cef4ddcfb93  jmp 0x00007CEF4DDCF3AD
00007cef4ddcfb98  call 0x00007CEF4DCE2420
00007cef4ddcfb9d  jmp 0x00007CEF4DDCF3BE
00007cef4ddcfba2  call 0x00007CEF4DCE2420
00007cef4ddcfba7  jmp 0x00007CEF4DDCF3CF
00007cef4ddcfbac  call 0x00007CEF4DCE2420
00007cef4ddcfbb1  jmp 0x00007CEF4DDCF3E0
00007cef4ddcfbb6  call 0x00007CEF4DCE2420
00007cef4ddcfbbb  jmp 0x00007CEF4DDCF3F1
00007cef4ddcfbc0  call 0x00007CEF4DCE2420
00007cef4ddcfbc5  jmp 0x00007CEF4DDCF402
00007cef4ddcfbca  call 0x00007CEF4DCE2420
00007cef4ddcfbcf  jmp 0x00007CEF4DDCF413
00007cef4ddcfbd4  call 0x00007CEF4DCE2420
00007cef4ddcfbd9  jmp 0x00007CEF4DDCF424
00007cef4ddcfbde  call 0x00007CEF4DCE2420
00007cef4ddcfbe3  jmp 0x00007CEF4DDCF435
00007cef4ddcfbe8  call 0x00007CEF4DCE2420
00007cef4ddcfbed  jmp 0x00007CEF4DDCF446
00007cef4ddcfbf2  call 0x00007CEF4DCE2420
00007cef4ddcfbf7  jmp 0x00007CEF4DDCF45F
00007cef4ddcfbfc  call 0x00007CEF4DCE2420
00007cef4ddcfc01  jmp 0x00007CEF4DDCF478
00007cef4ddcfc06  call 0x00007CEF4DCD5610
00007cef4ddcfc0b  jmp 0x00007CEF4DDCF491
00007cef4ddcfc10  call 0x00007CEF4DCDC580
00007cef4ddcfc15  jmp 0x00007CEF4DDCF7FE
00007cef4ddcfc1a  call 0x00007CEF4DCE46C0
00007cef4ddcfc1f  jmp 0x00007CEF4DDCF808
00007cef4ddcfc24  call 0x00007CEF4DC09E90
00007cef4ddcfc29  jmp 0x00007CEF4DDCF80E
00007cef4ddcfc2e  call 0x00007CEF4DCDB310
00007cef4ddcfc33  jmp 0x00007CEF4DDCF818
00007cef4ddcfc38  call 0x00007CEF4DC0DAE0
00007cef4ddcfc3d  jmp 0x00007CEF4DDCF81D
00007cef4ddcfc42  call 0x00007CEF4DCC0230
00007cef4ddcfc47  jmp 0x00007CEF4DDCF836
00007cef4ddcfc4c  call 0x00007CEF4DCC0230
00007cef4ddcfc51  jmp 0x00007CEF4DDCF84B
00007cef4ddcfc56  call 0x00007CEF4DCBEFC0
00007cef4ddcfc5b  jmp 0x00007CEF4DDCF854
00007cef4ddcfc60  call 0x00007CEF4DCE2BA0
00007cef4ddcfc65  jmp 0x00007CEF4DDCF91B
00007cef4ddcfc6a  int3
00007cef4ddcfc6b  nop [rax+rax*1], eax
00007cef4ddcfc70  mov rax, [r15+0x48]
00007cef4ddcfc74  mov r14, [r15+0x58]
00007cef4ddcfc78  lea r12, [rax+r14*1]
00007cef4ddcfc7c  mov [r15+0x68], r12
00007cef4ddcfc80  lea rax, [r14+0x04]
00007cef4ddcfc84  mov [r15+0x58], rax
00007cef4ddcfc88  lea r14, [r12+0x04]
00007cef4ddcfc8d  mov r11d, [r13+r14*1]
00007cef4ddcfc92  mov [rsp+0x10], r11d
00007cef4ddcfc97  mov r11d, r11d
00007cef4ddcfc9a  mov [r15+0x70], r11
00007cef4ddcfc9e  lea r14, [r12+0x38]
00007cef4ddcfca3  mov r11d, [r13+r14*1]
00007cef4ddcfca8  lea r14, [r12+0x24]
00007cef4ddcfcad  mov r10d, [r13+r14*1]
00007cef4ddcfcb2  mov [rsp+0x20], r10d
00007cef4ddcfcb7  mov r10d, r10d
00007cef4ddcfcba  mov [r15+0x90], r10
00007cef4ddcfcc1  mov [rsp+0x30], rax
00007cef4ddcfcc6  xor eax, eax
00007cef4ddcfcc8  mov r14, [rsp+0x30]
00007cef4ddcfccd  mov r10d, 0xC0
00007cef4ddcfcd3  cmp r14, r10
00007cef4ddcfcd6  cmc
00007cef4ddcfcd7  lahf
00007cef4ddcfcd8  seto al
00007cef4ddcfcdb  mov [r15+0x108], eax
00007cef4ddcfce2  mov eax, [rsp+0x10]
00007cef4ddcfce6  mov r14d, [rsp+0x10]
00007cef4ddcfceb  shrd eax, r14d, 0x07
00007cef4ddcfcf0  mov [rsp+0x10], r11d
00007cef4ddcfcf5  mov r10d, [rsp+0x10]
00007cef4ddcfcfa  shrd r11d, r10d, 0x11
00007cef4ddcfcff  mov r9d, [r15+0x60]
00007cef4ddcfd03  mov r8d, [rsp+0x20]
00007cef4ddcfd08  lea ebp, [r8d+r9d*1]
00007cef4ddcfd0d  rorx r9d, r14d, 0x12
00007cef4ddcfd13  xor eax, r9d
00007cef4ddcfd16  rorx r9d, r10d, 0x13
00007cef4ddcfd1c  xor r11d, r9d
00007cef4ddcfd1f  mov [rsp+0x10], r11d
00007cef4ddcfd24  mov r11d, r11d
00007cef4ddcfd27  mov [r15+0x88], r11
00007cef4ddcfd2e  mov [rsp+0x20], r14d
00007cef4ddcfd33  shr r14d, 0x03
00007cef4ddcfd37  xor eax, r14d
00007cef4ddcfd3a  mov [rsp+0x30], eax
00007cef4ddcfd3e  mov eax, eax
00007cef4ddcfd40  mov [r15+0x80], rax
00007cef4ddcfd47  shr r10d, 0x0A
00007cef4ddcfd4b  mov eax, [rsp+0x10]
00007cef4ddcfd4f  xor eax, r10d
00007cef4ddcfd52  mov [rsp+0x10], eax
00007cef4ddcfd56  mov eax, eax
00007cef4ddcfd58  mov [r15+0x78], rax
00007cef4ddcfd5c  mov eax, [rsp+0x30]
00007cef4ddcfd60  lea r14d, [ebp+eax*1]
00007cef4ddcfd66  mov eax, [rsp+0x10]
00007cef4ddcfd6a  lea r11d, [r14d+eax*1]
00007cef4ddcfd6f  lea rax, [r12+0x40]
00007cef4ddcfd74  mov [r13+rax*1], r11d
00007cef4ddcfd79  mov eax, [rsp+0x20]
00007cef4ddcfd7d  mov eax, eax
00007cef4ddcfd7f  mov [r15+0x60], rax
00007cef4ddcfd83  mov eax, [r15+0x108]
00007cef4ddcfd8a  sahf
00007cef4ddcfd8b  jnz 0x00007CEF4DDCFDBD
00007cef4ddcfd8d  cmp dword ptr [r15+0x318], 0x00
00007cef4ddcfd95  jz 0x00007CEF4DDCFE20
00007cef4ddcfd9b  nop [rax+rax*1], ax
00007cef4ddcfda4  nop [rax+rax*1], eax
00007cef4ddcfdac  mov eax, 0x41049C
00007cef4ddcfdb1  mov [r15+0x100], rax
00007cef4ddcfdb8  jmp 0x00007CEF4DBFE110
00007cef4ddcfdbd  cmp dword ptr [r15+0x318], 0x00
00007cef4ddcfdc5  jz 0x00007CEF4DDCFC70
00007cef4ddcfdcb  nop [rax+rax*1], ax
00007cef4ddcfdd4  nop [rax+rax*1], eax
00007cef4ddcfddc  mov eax, 0x410454
00007cef4ddcfde1  mov [r15+0x100], rax
00007cef4ddcfde8  jmp 0x00007CEF4DBFE110
00007cef4ddcfded  int3
00007cef4ddcfdee  call 0x00007CEF4DCE1430
00007cef4ddcfdf3  jmp 0x00007CEF4DDCFC92
00007cef4ddcfdf8  call 0x00007CEF4DCE1430
00007cef4ddcfdfd  jmp 0x00007CEF4DDCFCA8
00007cef4ddcfe02  call 0x00007CEF4DCE01C0
00007cef4ddcfe07  jmp 0x00007CEF4DDCFCB2
00007cef4ddcfe0c  call 0x00007CEF4DC0A860
00007cef4ddcfe11  jmp 0x00007CEF4DDCFD79
00007cef4ddcfe16  int3
00007cef4ddcfe17  nop [rax+rax*1], ax
00007cef4ddcfe20  mov rax, [r15]
00007cef4ddcfe23  mov r14d, [r13+rax*1]
00007cef4ddcfe28  lea r12, [rax+0x04]
00007cef4ddcfe2c  mov r11d, [r13+r12*1]
00007cef4ddcfe31  mov [rsp+0x10], r14d
00007cef4ddcfe36  mov r14d, r14d
00007cef4ddcfe39  mov [r15+0x78], r14
00007cef4ddcfe3d  mov [rsp+0x20], r11d
00007cef4ddcfe42  mov r11d, r11d
00007cef4ddcfe45  mov [r15+0x80], r11
00007cef4ddcfe4c  lea r14, [rax+0x08]
00007cef4ddcfe50  mov r12d, [r13+r14*1]
00007cef4ddcfe55  lea r14, [rax+0x0C]
00007cef4ddcfe59  mov r11d, [r13+r14*1]
00007cef4ddcfe5e  mov [rsp+0x30], r12d
00007cef4ddcfe63  mov r12d, r12d
00007cef4ddcfe66  mov [r15+0x70], r12
00007cef4ddcfe6a  mov [rsp+0x40], r11d
00007cef4ddcfe6f  mov r11d, r11d
00007cef4ddcfe72  mov [r15+0x68], r11
00007cef4ddcfe76  lea r14, [rax+0x18]
00007cef4ddcfe7a  mov r12d, [r13+r14*1]
00007cef4ddcfe7f  lea r14, [rax+0x1C]
00007cef4ddcfe83  mov r11d, [r13+r14*1]
00007cef4ddcfe88  mov [rsp+0x50], r12d
00007cef4ddcfe8d  mov r12d, r12d
00007cef4ddcfe90  mov [r15+0x58], r12
00007cef4ddcfe94  mov [rsp+0x60], r11d
00007cef4ddcfe99  mov r11d, r11d
00007cef4ddcfe9c  mov [r15+0x60], r11
00007cef4ddcfea0  lea r14, [rax+0x10]
00007cef4ddcfea4  mov r12d, [r13+r14*1]
00007cef4ddcfea9  lea r14, [rax+0x14]
00007cef4ddcfead  mov eax, [r13+r14*1]
00007cef4ddcfeb2  mov [rsp+0x70], r12d
00007cef4ddcfeb7  mov r12d, r12d
00007cef4ddcfeba  mov [r15+0x18], r12
00007cef4ddcfebe  mov [rsp+0x80], eax
00007cef4ddcfec5  mov eax, eax
00007cef4ddcfec7  mov [r15+0x90], rax
00007cef4ddcfece  mov eax, [rsp+0x70]
00007cef4ddcfed2  mov eax, eax
00007cef4ddcfed4  mov [r15+0x30], rax
00007cef4ddcfed8  mov eax, [rsp+0x50]
00007cef4ddcfedc  mov eax, eax
00007cef4ddcfede  mov [r15+0xA0], rax
00007cef4ddcfee5  mov eax, [rsp+0x30]
00007cef4ddcfee9  mov eax, eax
00007cef4ddcfeeb  mov [r15+0x28], rax
00007cef4ddcfeef  mov eax, [rsp+0x20]
00007cef4ddcfef3  mov eax, eax
00007cef4ddcfef5  mov [r15+0x98], rax
00007cef4ddcfefc  mov eax, [rsp+0x10]
00007cef4ddcff00  mov eax, eax
00007cef4ddcff02  mov [r15+0x38], rax
00007cef4ddcff06  mov eax, [rsp+0x70]
00007cef4ddcff0a  mov r14d, [rsp+0x70]
00007cef4ddcff0f  shrd eax, r14d, 0x06
00007cef4ddcff14  mov [rsp+0x70], r14d
00007cef4ddcff19  mov r12d, [rsp+0x80]
00007cef4ddcff21  and r14d, r12d
00007cef4ddcff24  mov r11d, [rsp+0x10]
00007cef4ddcff29  mov r10d, [rsp+0x10]
00007cef4ddcff2e  shrd r11d, r10d, 0x02
00007cef4ddcff33  mov [rsp+0x10], r12d
00007cef4ddcff38  mov r12d, r12d
00007cef4ddcff3b  mov [r15+0x20], r12
00007cef4ddcff3f  mov r12, [r15+0x50]
00007cef4ddcff43  mov r9d, [r13+r12*1]
00007cef4ddcff48  mov r12d, [rsp+0x50]
00007cef4ddcff4d  mov r8d, [rsp+0x70]
00007cef4ddcff52  andn ebp, r8d, r12d
00007cef4ddcff57  mov edi, [rsp+0x60]
00007cef4ddcff5b  lea esi, [r14d+edi*1]
00007cef4ddcff60  rorx r14d, r8d, 0x0B
00007cef4ddcff66  xor eax, r14d
00007cef4ddcff69  rorx r14d, r10d, 0x0D
00007cef4ddcff6f  xor r11d, r14d
00007cef4ddcff72  lea edi, [esi+ebp*1]
00007cef4ddcff76  mov r14, [r15+0x48]
00007cef4ddcff7a  mov ebp, [r13+r14*1]
00007cef4ddcff7f  mov r14d, [rsp+0x30]
00007cef4ddcff84  mov esi, [rsp+0x20]
00007cef4ddcff88  and r14d, esi
00007cef4ddcff8b  mov [rsp+0x20], r14d
00007cef4ddcff90  mov r14d, r14d
00007cef4ddcff93  mov [r15+0xD8], r14
00007cef4ddcff9a  lea r14d, [edi+r9d*1]
00007cef4ddcff9f  mov r9d, [rsp+0x30]
00007cef4ddcffa4  xor r9d, esi
00007cef4ddcffa7  rorx edi, r8d, 0x19
00007cef4ddcffad  xor eax, edi
00007cef4ddcffaf  and r9d, r10d
00007cef4ddcffb2  rorx edi, r10d, 0x16
00007cef4ddcffb8  xor r11d, edi
00007cef4ddcffbb  mov [rsp+0x30], r11d
00007cef4ddcffc0  mov r11d, r11d
00007cef4ddcffc3  mov [r15+0xD0], r11
00007cef4ddcffca  lea r11d, [r14d+ebp*1]
00007cef4ddcffcf  mov r10d, [rsp+0x20]
00007cef4ddcffd4  xor r9d, r10d
00007cef4ddcffd7  lea r14d, [r11d+eax*1]
00007cef4ddcffdc  mov qword ptr [r15+0x88], 0x04
00007cef4ddcffe7  mov eax, [rsp+0x30]
00007cef4ddcffeb  lea r11d, [r9d+eax*1]
00007cef4ddcfff0  mov eax, [rsp+0x40]
00007cef4ddcfff4  lea r10d, [r14d+eax*1]
00007cef4ddcfff9  mov r10d, r10d
00007cef4ddcfffc  mov [r15+0xB8], r10
00007cef4ddd0003  xor eax, eax
00007cef4ddd0005  mov r10d, 0x04
00007cef4ddd000b  mov r9d, 0x100
00007cef4ddd0011  cmp r10, r9
00007cef4ddd0014  cmc
00007cef4ddd0015  lahf
00007cef4ddd0016  seto al
00007cef4ddd0019  mov [r15+0x108], eax
00007cef4ddd0020  lea eax, [r11d+r14d*1]
00007cef4ddd0025  mov eax, eax
00007cef4ddd0027  mov [r15+0xA8], rax
00007cef4ddd002e  mov r12d, r12d
00007cef4ddd0031  mov [r15+0xB0], r12
00007cef4ddd0038  mov eax, [rsp+0x10]
00007cef4ddd003c  mov eax, eax
00007cef4ddd003e  mov [r15+0xC0], rax
00007cef4ddd0045  mov r8d, r8d
00007cef4ddd0048  mov [r15+0xC8], r8
00007cef4ddd004f  mov eax, [r15+0x108]
00007cef4ddd0056  sahf
00007cef4ddd0057  jnz 0x00007CEF4DDD0089
00007cef4ddd0059  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd0061  jz 0x00007CEF4DDD0350
00007cef4ddd0067  nop [rax+rax*1], ax
00007cef4ddd0070  nop [rax+rax*1], eax
00007cef4ddd0078  mov eax, 0x41055C
00007cef4ddd007d  mov [r15+0x100], rax
00007cef4ddd0084  jmp 0x00007CEF4DBFE110
00007cef4ddd0089  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd0091  jz 0x00007CEF4DDD0120
00007cef4ddd0097  nop [rax+rax*1], ax
00007cef4ddd00a0  nop [rax+rax*1], eax
00007cef4ddd00a8  mov eax, 0x4104D0
00007cef4ddd00ad  mov [r15+0x100], rax
00007cef4ddd00b4  jmp 0x00007CEF4DBFE110
00007cef4ddd00b9  int3
00007cef4ddd00ba  call 0x00007CEF4DC0DAE0
00007cef4ddd00bf  jmp 0x00007CEF4DDCFE28
00007cef4ddd00c4  call 0x00007CEF4DCC0230
00007cef4ddd00c9  jmp 0x00007CEF4DDCFE31
00007cef4ddd00ce  call 0x00007CEF4DCE26A0
00007cef4ddd00d3  jmp 0x00007CEF4DDCFE55
00007cef4ddd00d8  call 0x00007CEF4DCE1430
00007cef4ddd00dd  jmp 0x00007CEF4DDCFE5E
00007cef4ddd00e2  call 0x00007CEF4DCE26A0
00007cef4ddd00e7  jmp 0x00007CEF4DDCFE7F
00007cef4ddd00ec  call 0x00007CEF4DCE1430
00007cef4ddd00f1  jmp 0x00007CEF4DDCFE88
00007cef4ddd00f6  call 0x00007CEF4DCE26A0
00007cef4ddd00fb  jmp 0x00007CEF4DDCFEA9
00007cef4ddd0100  call 0x00007CEF4DCD5890
00007cef4ddd0105  jmp 0x00007CEF4DDCFEB2
00007cef4ddd010a  call 0x00007CEF4DCBDD50
00007cef4ddd010f  jmp 0x00007CEF4DDCFF48
00007cef4ddd0114  call 0x00007CEF4DCDA580
00007cef4ddd0119  jmp 0x00007CEF4DDCFF7F
00007cef4ddd011e  int3
00007cef4ddd011f  nop
00007cef4ddd0120  mov eax, [r15+0xB8]
00007cef4ddd0127  mov [rsp+0x10], eax
00007cef4ddd012b  mov eax, eax
00007cef4ddd012d  mov [r15+0x30], rax
00007cef4ddd0131  mov eax, [r15+0xC0]
00007cef4ddd0138  mov [rsp+0x20], eax
00007cef4ddd013c  mov eax, eax
00007cef4ddd013e  mov [r15+0xA0], rax
00007cef4ddd0145  mov eax, [r15+0x28]
00007cef4ddd0149  mov r14d, [r15+0x98]
00007cef4ddd0150  mov [rsp+0x30], r14d
00007cef4ddd0155  mov r14d, r14d
00007cef4ddd0158  mov [r15+0x28], r14
00007cef4ddd015c  mov r14d, [r15+0x38]
00007cef4ddd0160  mov [rsp+0x40], r14d
00007cef4ddd0165  mov r14d, r14d
00007cef4ddd0168  mov [r15+0x98], r14
00007cef4ddd016f  mov r14d, [r15+0xA8]
00007cef4ddd0176  mov [rsp+0x50], r14d
00007cef4ddd017b  mov r14d, r14d
00007cef4ddd017e  mov [r15+0x38], r14
00007cef4ddd0182  mov r14d, [rsp+0x10]
00007cef4ddd0187  mov r12d, [rsp+0x10]
00007cef4ddd018c  shrd r14d, r12d, 0x06
00007cef4ddd0191  mov r11d, [r15+0xC8]
00007cef4ddd0198  mov [rsp+0x10], r12d
00007cef4ddd019d  and r12d, r11d
00007cef4ddd01a0  mov r10d, [rsp+0x50]
00007cef4ddd01a5  mov r9d, [rsp+0x50]
00007cef4ddd01aa  shrd r10d, r9d, 0x02
00007cef4ddd01af  mov [rsp+0x50], r11d
00007cef4ddd01b4  mov r11d, r11d
00007cef4ddd01b7  mov [r15+0x20], r11
00007cef4ddd01bb  mov r11, [r15+0x88]
00007cef4ddd01c2  mov r8, [r15+0x50]
00007cef4ddd01c6  lea rbp, [r8+r11*1]
00007cef4ddd01ca  mov r8d, [r13+rbp*1]
00007cef4ddd01cf  mov ebp, [rsp+0x20]
00007cef4ddd01d3  mov edi, [rsp+0x10]
00007cef4ddd01d7  andn esi, edi, ebp
00007cef4ddd01dc  mov edx, [r15+0xB0]
00007cef4ddd01e3  lea ecx, [r12d+edx*1]
00007cef4ddd01e8  rorx r12d, edi, 0x0B
00007cef4ddd01ee  xor r14d, r12d
00007cef4ddd01f1  rorx r12d, r9d, 0x0D
00007cef4ddd01f7  xor r10d, r12d
00007cef4ddd01fa  lea r12d, [ecx+esi*1]
00007cef4ddd01ff  mov rsi, [r15+0x48]
00007cef4ddd0203  lea rdx, [rsi+r11*1]
00007cef4ddd0207  mov esi, [r13+rdx*1]
00007cef4ddd020c  mov edx, [rsp+0x30]
00007cef4ddd0210  mov ecx, [rsp+0x40]
00007cef4ddd0214  and edx, ecx
00007cef4ddd0216  mov [rsp+0x10], edx
00007cef4ddd021a  mov edx, edx
00007cef4ddd021c  mov [r15+0xD8], rdx
00007cef4ddd0223  lea edx, [r12d+r8d*1]
00007cef4ddd0228  mov r12d, [rsp+0x30]
00007cef4ddd022d  xor r12d, ecx
00007cef4ddd0230  rorx r8d, edi, 0x19
00007cef4ddd0236  xor r14d, r8d
00007cef4ddd0239  and r12d, r9d
00007cef4ddd023c  rorx r8d, r9d, 0x16
00007cef4ddd0242  xor r10d, r8d
00007cef4ddd0245  mov [rsp+0x20], r10d
00007cef4ddd024a  mov r10d, r10d
00007cef4ddd024d  mov [r15+0xD0], r10
00007cef4ddd0254  lea r10d, [edx+esi*1]
00007cef4ddd0259  mov r9d, [rsp+0x10]
00007cef4ddd025e  xor r12d, r9d
00007cef4ddd0261  lea r9d, [r10d+r14d*1]
00007cef4ddd0266  lea r14, [r11+0x04]
00007cef4ddd026a  mov [r15+0x88], r14
00007cef4ddd0271  mov r11d, [rsp+0x20]
00007cef4ddd0276  lea r10d, [r12d+r11d*1]
00007cef4ddd027b  lea r11d, [r9d+eax*1]
00007cef4ddd0280  mov r11d, r11d
00007cef4ddd0283  mov [r15+0xB8], r11
00007cef4ddd028a  xor eax, eax
00007cef4ddd028c  mov r12d, 0x100
00007cef4ddd0292  cmp r14, r12
00007cef4ddd0295  cmc
00007cef4ddd0296  lahf
00007cef4ddd0297  seto al
00007cef4ddd029a  mov [r15+0x108], eax
00007cef4ddd02a1  lea eax, [r10d+r9d*1]
00007cef4ddd02a6  mov eax, eax
00007cef4ddd02a8  mov [r15+0xA8], rax
00007cef4ddd02af  mov ebp, ebp
00007cef4ddd02b1  mov [r15+0xB0], rbp
00007cef4ddd02b8  mov eax, [rsp+0x50]
00007cef4ddd02bc  mov eax, eax
00007cef4ddd02be  mov [r15+0xC0], rax
00007cef4ddd02c5  mov edi, edi
00007cef4ddd02c7  mov [r15+0xC8], rdi
00007cef4ddd02ce  mov eax, [r15+0x108]
00007cef4ddd02d5  sahf
00007cef4ddd02d6  jnz 0x00007CEF4DDD0308
00007cef4ddd02d8  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd02e0  jz 0x00007CEF4DDD0350
00007cef4ddd02e6  nop [rax+rax*1], ax
00007cef4ddd02ef  nop [rax+rax*1], eax
00007cef4ddd02f7  mov eax, 0x41055C
00007cef4ddd02fc  mov [r15+0x100], rax
00007cef4ddd0303  jmp 0x00007CEF4DBFE110
00007cef4ddd0308  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd0310  jz 0x00007CEF4DDD0120
00007cef4ddd0316  nop [rax+rax*1], ax
00007cef4ddd031f  nop [rax+rax*1], eax
00007cef4ddd0327  mov eax, 0x4104D0
00007cef4ddd032c  mov [r15+0x100], rax
00007cef4ddd0333  jmp 0x00007CEF4DBFE110
00007cef4ddd0338  int3
00007cef4ddd0339  call 0x00007CEF4DC49010
00007cef4ddd033e  jmp 0x00007CEF4DDD01CF
00007cef4ddd0343  call 0x00007CEF4DC25930
00007cef4ddd0348  jmp 0x00007CEF4DDD020C
00007cef4ddd034d  int3
00007cef4ddd034e  nop
00007cef4ddd0350  mov eax, [r15+0x98]
00007cef4ddd0357  mov r14d, [r15+0x70]
00007cef4ddd035b  lea r12d, [eax+r14d*1]
00007cef4ddd0360  mov eax, [r15+0x28]
00007cef4ddd0364  mov r14d, [r15+0x68]
00007cef4ddd0368  lea r11d, [eax+r14d*1]
00007cef4ddd036d  mov qword ptr [r15+0x88], 0x00
00007cef4ddd0378  mov eax, [r15+0xA8]
00007cef4ddd037f  mov r14d, [r15+0x78]
00007cef4ddd0383  lea r10d, [eax+r14d*1]
00007cef4ddd0388  mov [rsp+0x10], r10d
00007cef4ddd038d  mov r10d, r10d
00007cef4ddd0390  mov [r15+0x78], r10
00007cef4ddd0394  mov eax, [r15+0x38]
00007cef4ddd0398  mov r14d, [r15+0x80]
00007cef4ddd039f  lea r10d, [eax+r14d*1]
00007cef4ddd03a4  mov [rsp+0x20], r10d
00007cef4ddd03a9  mov r10d, r10d
00007cef4ddd03ac  mov [r15+0x80], r10
00007cef4ddd03b3  mov rax, [r15]
00007cef4ddd03b6  lea r14, [rax+0x08]
00007cef4ddd03ba  mov [r13+r14*1], r12d
00007cef4ddd03bf  lea r14, [rax+0x0C]
00007cef4ddd03c3  mov [r13+r14*1], r11d
00007cef4ddd03c8  mov r14d, [r15+0xB8]
00007cef4ddd03cf  mov r12d, [r15+0x18]
00007cef4ddd03d3  lea r11d, [r14d+r12d*1]
00007cef4ddd03d8  mov [rsp+0x30], r11d
00007cef4ddd03dd  mov r11d, r11d
00007cef4ddd03e0  mov [r15+0x68], r11
00007cef4ddd03e4  mov r14d, [r15+0x30]
00007cef4ddd03e8  mov r12d, [r15+0x90]
00007cef4ddd03ef  lea r11d, [r14d+r12d*1]
00007cef4ddd03f4  mov [rsp+0x40], r11d
00007cef4ddd03f9  mov r11d, r11d
00007cef4ddd03fc  mov [r15+0x70], r11
00007cef4ddd0400  mov r14d, [r15+0x20]
00007cef4ddd0404  mov r12d, [r15+0x58]
00007cef4ddd0408  lea r11d, [r14d+r12d*1]
00007cef4ddd040d  mov [rsp+0x50], r11d
00007cef4ddd0412  mov r11d, r11d
00007cef4ddd0415  mov [r15+0x58], r11
00007cef4ddd0419  mov r14d, [r15+0xA0]
00007cef4ddd0420  mov r12d, [r15+0x60]
00007cef4ddd0424  lea r11d, [r14d+r12d*1]
00007cef4ddd0429  mov [rsp+0x60], r11d
00007cef4ddd042e  mov r11d, r11d
00007cef4ddd0431  mov [r15+0x60], r11
00007cef4ddd0435  mov r14d, [rsp+0x10]
00007cef4ddd043a  mov [r13+rax*1], r14d
00007cef4ddd043f  lea r14, [rax+0x04]
00007cef4ddd0443  mov r12d, [rsp+0x20]
00007cef4ddd0448  mov [r13+r14*1], r12d
00007cef4ddd044d  lea r14, [rax+0x10]
00007cef4ddd0451  mov r12d, [rsp+0x30]
00007cef4ddd0456  mov [r13+r14*1], r12d
00007cef4ddd045b  lea r14, [rax+0x14]
00007cef4ddd045f  mov r12d, [rsp+0x40]
00007cef4ddd0464  mov [r13+r14*1], r12d
00007cef4ddd0469  lea r14, [rax+0x18]
00007cef4ddd046d  mov r12d, [rsp+0x50]
00007cef4ddd0472  mov [r13+r14*1], r12d
00007cef4ddd0477  lea r14, [rax+0x1C]
00007cef4ddd047b  mov r12d, [rsp+0x60]
00007cef4ddd0480  mov [r13+r14*1], r12d
00007cef4ddd0485  lea r14, [rax+0x68]
00007cef4ddd0489  xor eax, eax
00007cef4ddd048b  mov [r13+r14*1], rax
00007cef4ddd0490  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd0498  jz 0x00007CEF4DDCEF90
00007cef4ddd049e  nop [rax+rax*1], ax
00007cef4ddd04a7  nop [rax+rax*1], eax
00007cef4ddd04af  mov eax, 0x410378
00007cef4ddd04b4  mov [r15+0x100], rax
00007cef4ddd04bb  jmp 0x00007CEF4DBFE110
00007cef4ddd04c0  int3
00007cef4ddd04c1  call 0x00007CEF4DCE2BA0
00007cef4ddd04c6  jmp 0x00007CEF4DDD03BF
00007cef4ddd04cb  call 0x00007CEF4DCE1920
00007cef4ddd04d0  jmp 0x00007CEF4DDD03C8
00007cef4ddd04d5  call 0x00007CEF4DC0DFE0
00007cef4ddd04da  jmp 0x00007CEF4DDD043F
00007cef4ddd04df  call 0x00007CEF4DCE2BA0
00007cef4ddd04e4  jmp 0x00007CEF4DDD044D
00007cef4ddd04e9  call 0x00007CEF4DCE2BA0
00007cef4ddd04ee  jmp 0x00007CEF4DDD045B
00007cef4ddd04f3  call 0x00007CEF4DCE2BA0
00007cef4ddd04f8  jmp 0x00007CEF4DDD0469
00007cef4ddd04fd  call 0x00007CEF4DCE2BA0
00007cef4ddd0502  jmp 0x00007CEF4DDD0477
00007cef4ddd0507  call 0x00007CEF4DCE2BA0
00007cef4ddd050c  jmp 0x00007CEF4DDD0485
00007cef4ddd0511  call 0x00007CEF4DCD5EB0
00007cef4ddd0516  jmp 0x00007CEF4DDD0490
00007cef4ddd051b  int3
00007cef4ddd051c  nop [rax], eax
00007cef4ddd0520  mov rax, [r15+0xF8]
00007cef4ddd0527  lea r14, [rax+0x140]
00007cef4ddd052e  mov r12, [r13+r14*1]
00007cef4ddd0533  lea r14, [rax+0x148]
00007cef4ddd053a  mov r11, [r13+r14*1]
00007cef4ddd053f  mov [r15+0xA0], r12
00007cef4ddd0546  mov [r15+0x98], r11
00007cef4ddd054d  lea r14, [rax+0x130]
00007cef4ddd0554  mov r12, [r13+r14*1]
00007cef4ddd0559  lea r14, [rax+0x138]
00007cef4ddd0560  mov r11, [r13+r14*1]
00007cef4ddd0565  mov [r15+0xB0], r12
00007cef4ddd056c  mov [r15+0xA8], r11
00007cef4ddd0573  lea r14, [rax+0x120]
00007cef4ddd057a  mov r12, [r13+r14*1]
00007cef4ddd057f  lea r14, [rax+0x128]
00007cef4ddd0586  mov r11, [r13+r14*1]
00007cef4ddd058b  mov [r15+0xC0], r12
00007cef4ddd0592  mov [r15+0xB8], r11
00007cef4ddd0599  lea r14, [rax+0x110]
00007cef4ddd05a0  mov r12, [r13+r14*1]
00007cef4ddd05a5  lea r14, [rax+0x118]
00007cef4ddd05ac  mov r11, [r13+r14*1]
00007cef4ddd05b1  mov [r15+0xD0], r12
00007cef4ddd05b8  mov [r15+0xC8], r11
00007cef4ddd05bf  lea r14, [rax+0x100]
00007cef4ddd05c6  mov r12, [r13+r14*1]
00007cef4ddd05cb  lea r14, [rax+0x108]
00007cef4ddd05d2  mov r11, [r13+r14*1]
00007cef4ddd05d7  mov [r15+0xE8], r12
00007cef4ddd05de  mov [r15+0xD8], r11
00007cef4ddd05e5  lea r14, [rax+0x150]
00007cef4ddd05ec  mov [r15+0xF8], r14
00007cef4ddd05f3  mov rax, [r15+0xF0]
00007cef4ddd05fa  mov [r15+0x100], rax
00007cef4ddd0601  jmp 0x00007CEF4DDCE5C0
00007cef4ddd0606  int3
00007cef4ddd0607  call 0x00007CEF4DCE27E0
00007cef4ddd060c  jmp 0x00007CEF4DDD0533
00007cef4ddd0611  call 0x00007CEF4DCE1570
00007cef4ddd0616  jmp 0x00007CEF4DDD053F
00007cef4ddd061b  call 0x00007CEF4DCE27E0
00007cef4ddd0620  jmp 0x00007CEF4DDD0559
00007cef4ddd0625  call 0x00007CEF4DCE1570
00007cef4ddd062a  jmp 0x00007CEF4DDD0565
00007cef4ddd062f  call 0x00007CEF4DCE27E0
00007cef4ddd0634  jmp 0x00007CEF4DDD057F
00007cef4ddd0639  call 0x00007CEF4DCE1570
00007cef4ddd063e  jmp 0x00007CEF4DDD058B
00007cef4ddd0643  call 0x00007CEF4DCE27E0
00007cef4ddd0648  jmp 0x00007CEF4DDD05A5
00007cef4ddd064d  call 0x00007CEF4DCE1570
00007cef4ddd0652  jmp 0x00007CEF4DDD05B1
00007cef4ddd0657  call 0x00007CEF4DCE27E0
00007cef4ddd065c  jmp 0x00007CEF4DDD05CB
00007cef4ddd0661  call 0x00007CEF4DCE1570
00007cef4ddd0666  jmp 0x00007CEF4DDD05D7
00007cef4ddd066b  int3
00007cef4ddd066c  nop [rax], eax
00007cef4ddd0670  mov eax, [r15+0xA0]
00007cef4ddd0677  mov [rsp+0x10], eax
00007cef4ddd067b  xor eax, eax
00007cef4ddd067d  mov r14d, [rsp+0x10]
00007cef4ddd0682  sub r14d, 0x01
00007cef4ddd0686  cmc
00007cef4ddd0687  lahf
00007cef4ddd0688  seto al
00007cef4ddd068b  mov [r15+0x108], eax
00007cef4ddd0692  mov r14d, r14d
00007cef4ddd0695  mov [r15+0xA0], r14
00007cef4ddd069c  mov eax, [r15+0x108]
00007cef4ddd06a3  sahf
00007cef4ddd06a4  jnz 0x00007CEF4DDD06D6
00007cef4ddd06a6  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd06ae  jz 0x00007CEF4DDD07A0
00007cef4ddd06b4  nop [rax+rax*1], ax
00007cef4ddd06bd  nop [rax+rax*1], eax
00007cef4ddd06c5  mov eax, 0x41027C
00007cef4ddd06ca  mov [r15+0x100], rax
00007cef4ddd06d1  jmp 0x00007CEF4DBFE110
00007cef4ddd06d6  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd06de  jz 0x00007CEF4DDD0710
00007cef4ddd06e4  nop [rax+rax*1], ax
00007cef4ddd06ed  nop [rax+rax*1], eax
00007cef4ddd06f5  mov eax, 0x410264
00007cef4ddd06fa  mov [r15+0x100], rax
00007cef4ddd0701  jmp 0x00007CEF4DBFE110
00007cef4ddd0706  int3
00007cef4ddd0707  int3
00007cef4ddd0708  nop [rax+rax*1], eax
00007cef4ddd0710  mov rax, [r15+0xF8]
00007cef4ddd0717  mov [r15], rax
00007cef4ddd071a  mov rax, [r15+0x98]
00007cef4ddd0721  mov [r15+0x08], rax
00007cef4ddd0725  mov qword ptr [r15+0x10], 0x12C
00007cef4ddd072d  mov qword ptr [r15+0xF0], 0x410274
00007cef4ddd0738  mov r14d, [r15+0x320]
00007cef4ddd073f  mov eax, 0x410274
00007cef4ddd0744  mov rcx, 0x7CEF4DDD0670
00007cef4ddd074e  mov [r15+r14*8+0x328], rax
00007cef4ddd0756  mov [r15+r14*8+0x368], rcx
00007cef4ddd075e  add r14d, 0x01
00007cef4ddd0762  and r14d, 0x07
00007cef4ddd0766  mov [r15+0x320], r14d
00007cef4ddd076d  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd0775  jz 0x00007CEF4DDCEC20
00007cef4ddd077b  nop [rax+rax*1], ax
00007cef4ddd0784  nop [rax+rax*1], eax
00007cef4ddd078c  mov eax, 0x410338
00007cef4ddd0791  mov [r15+0x100], rax
00007cef4ddd0798  jmp 0x00007CEF4DBFE110
00007cef4ddd079d  int3
00007cef4ddd079e  int3
00007cef4ddd079f  nop
00007cef4ddd07a0  mov rax, [r15+0xF8]
00007cef4ddd07a7  lea r14, [rax+0x20]
00007cef4ddd07ab  mov r12, [r13+r14*1]
00007cef4ddd07b0  mov [r15+0x98], r12
00007cef4ddd07b7  mov qword ptr [r15+0x40], 0x80
00007cef4ddd07bf  mov [r15], rax
00007cef4ddd07c2  lea r14, [rax+0x8C]
00007cef4ddd07c9  mov [r15+0x08], r14
00007cef4ddd07cd  mov qword ptr [r15+0x10], 0x01
00007cef4ddd07d5  lea r14, [rax+0x8C]
00007cef4ddd07dc  mov eax, 0x80
00007cef4ddd07e1  mov [r13+r14*1], al
00007cef4ddd07e6  mov qword ptr [r15+0xF0], 0x410298
00007cef4ddd07f1  mov r14d, [r15+0x320]
00007cef4ddd07f8  mov eax, 0x410298
00007cef4ddd07fd  mov rcx, 0x7CEF4DDD0870
00007cef4ddd0807  mov [r15+r14*8+0x328], rax
00007cef4ddd080f  mov [r15+r14*8+0x368], rcx
00007cef4ddd0817  add r14d, 0x01
00007cef4ddd081b  and r14d, 0x07
00007cef4ddd081f  mov [r15+0x320], r14d
00007cef4ddd0826  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd082e  jz 0x00007CEF4DDCEC20
00007cef4ddd0834  nop [rax+rax*1], ax
00007cef4ddd083d  nop [rax+rax*1], eax
00007cef4ddd0845  mov eax, 0x410338
00007cef4ddd084a  mov [r15+0x100], rax
00007cef4ddd0851  jmp 0x00007CEF4DBFE110
00007cef4ddd0856  int3
00007cef4ddd0857  call 0x00007CEF4DCE27E0
00007cef4ddd085c  jmp 0x00007CEF4DDD07B0
00007cef4ddd0861  call 0x00007CEF4DCD5AF0
00007cef4ddd0866  jmp 0x00007CEF4DDD07E6
00007cef4ddd086b  int3
00007cef4ddd086c  nop [rax], eax
00007cef4ddd0870  mov rax, [r15+0xF8]
00007cef4ddd0877  lea r14, [rax+0x68]
00007cef4ddd087b  mov r12, [r13+r14*1]
00007cef4ddd0880  mov [r15+0x40], r12
00007cef4ddd0884  lea r14, [rax+0x88]
00007cef4ddd088b  xor eax, eax
00007cef4ddd088d  mov [r13+r14*1], al
00007cef4ddd0892  xor eax, eax
00007cef4ddd0894  mov r14d, 0x38
00007cef4ddd089a  cmp r12, r14
00007cef4ddd089d  cmc
00007cef4ddd089e  lahf
00007cef4ddd089f  seto al
00007cef4ddd08a2  mov [r15+0x108], eax
00007cef4ddd08a9  mov eax, [r15+0x108]
00007cef4ddd08b0  sahf
00007cef4ddd08b1  jz 0x00007CEF4DDD08E3
00007cef4ddd08b3  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd08bb  jz 0x00007CEF4DDD0930
00007cef4ddd08c1  nop [rax+rax*1], ax
00007cef4ddd08ca  nop [rax+rax*1], eax
00007cef4ddd08d2  mov eax, 0x4102A8
00007cef4ddd08d7  mov [r15+0x100], rax
00007cef4ddd08de  jmp 0x00007CEF4DBFE110
00007cef4ddd08e3  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd08eb  jz 0x00007CEF4DDD0A70
00007cef4ddd08f1  nop [rax+rax*1], ax
00007cef4ddd08fa  nop [rax+rax*1], eax
00007cef4ddd0902  mov eax, 0x4102C4
00007cef4ddd0907  mov [r15+0x100], rax
00007cef4ddd090e  jmp 0x00007CEF4DBFE110
00007cef4ddd0913  int3
00007cef4ddd0914  call 0x00007CEF4DCE27E0
00007cef4ddd0919  jmp 0x00007CEF4DDD0880
00007cef4ddd091e  call 0x00007CEF4DCD5AF0
00007cef4ddd0923  jmp 0x00007CEF4DDD0892
00007cef4ddd0928  int3
00007cef4ddd0929  nop [rax], eax
00007cef4ddd0930  mov rax, [r15+0xF8]
00007cef4ddd0937  mov [r15], rax
00007cef4ddd093a  lea r14, [rax+0x88]
00007cef4ddd0941  mov [r15+0x08], r14
00007cef4ddd0945  mov qword ptr [r15+0x10], 0x01
00007cef4ddd094d  mov qword ptr [r15+0xF0], 0x4102B8
00007cef4ddd0958  mov r14d, [r15+0x320]
00007cef4ddd095f  mov eax, 0x4102B8
00007cef4ddd0964  mov rcx, 0x7CEF4DDD09C0
00007cef4ddd096e  mov [r15+r14*8+0x328], rax
00007cef4ddd0976  mov [r15+r14*8+0x368], rcx
00007cef4ddd097e  add r14d, 0x01
00007cef4ddd0982  and r14d, 0x07
00007cef4ddd0986  mov [r15+0x320], r14d
00007cef4ddd098d  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd0995  jz 0x00007CEF4DDCEC20
00007cef4ddd099b  nop [rax+rax*1], ax
00007cef4ddd09a4  nop [rax+rax*1], eax
00007cef4ddd09ac  mov eax, 0x410338
00007cef4ddd09b1  mov [r15+0x100], rax
00007cef4ddd09b8  jmp 0x00007CEF4DBFE110
00007cef4ddd09bd  int3
00007cef4ddd09be  int3
00007cef4ddd09bf  nop
00007cef4ddd09c0  mov rax, [r15+0xF8]
00007cef4ddd09c7  lea r14, [rax+0x68]
00007cef4ddd09cb  mov rax, [r13+r14*1]
00007cef4ddd09d0  mov [r15+0x40], rax
00007cef4ddd09d4  mov [rsp+0x10], rax
00007cef4ddd09d9  xor eax, eax
00007cef4ddd09db  mov r14, [rsp+0x10]
00007cef4ddd09e0  mov r12d, 0x38
00007cef4ddd09e6  cmp r14, r12
00007cef4ddd09e9  cmc
00007cef4ddd09ea  lahf
00007cef4ddd09eb  seto al
00007cef4ddd09ee  mov [r15+0x108], eax
00007cef4ddd09f5  mov eax, [r15+0x108]
00007cef4ddd09fc  sahf
00007cef4ddd09fd  jnz 0x00007CEF4DDD0A2F
00007cef4ddd09ff  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd0a07  jz 0x00007CEF4DDD0A70
00007cef4ddd0a0d  nop [rax+rax*1], ax
00007cef4ddd0a16  nop [rax+rax*1], eax
00007cef4ddd0a1e  mov eax, 0x4102C4
00007cef4ddd0a23  mov [r15+0x100], rax
00007cef4ddd0a2a  jmp 0x00007CEF4DBFE110
00007cef4ddd0a2f  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd0a37  jz 0x00007CEF4DDD0930
00007cef4ddd0a3d  nop [rax+rax*1], ax
00007cef4ddd0a46  nop [rax+rax*1], eax
00007cef4ddd0a4e  mov eax, 0x4102A8
00007cef4ddd0a53  mov [r15+0x100], rax
00007cef4ddd0a5a  jmp 0x00007CEF4DBFE110
00007cef4ddd0a5f  int3
00007cef4ddd0a60  call 0x00007CEF4DCD59C0
00007cef4ddd0a65  jmp 0x00007CEF4DDD09D0
00007cef4ddd0a6a  int3
00007cef4ddd0a6b  nop [rax+rax*1], eax
00007cef4ddd0a70  mov rax, [r15+0x98]
00007cef4ddd0a77  rorx r14, rax, 0x3D
00007cef4ddd0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007cef4ddd0a81  mov rax, [r15+0xF8]
00007cef4ddd0a88  mov [r15], rax
00007cef4ddd0a8b  lea r12, [rax+0x78]
00007cef4ddd0a8f  mov [r15+0x08], r12
00007cef4ddd0a93  mov qword ptr [r15+0x10], 0x08
00007cef4ddd0a9b  bswap r14
00007cef4ddd0a9e  mov [r15+0x40], r14
00007cef4ddd0aa2  lea r12, [rax+0x78]
00007cef4ddd0aa6  mov [r13+r12*1], r14
00007cef4ddd0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007cef4ddd0ab6  mov r14d, [r15+0x320]
00007cef4ddd0abd  mov eax, 0x4102E0
00007cef4ddd0ac2  mov rcx, 0x7CEF4DDD0B30
00007cef4ddd0acc  mov [r15+r14*8+0x328], rax
00007cef4ddd0ad4  mov [r15+r14*8+0x368], rcx
00007cef4ddd0adc  add r14d, 0x01
00007cef4ddd0ae0  and r14d, 0x07
00007cef4ddd0ae4  mov [r15+0x320], r14d
00007cef4ddd0aeb  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd0af3  jz 0x00007CEF4DDCEC20
00007cef4ddd0af9  nop [rax+rax*1], ax
00007cef4ddd0b02  nop [rax+rax*1], eax
00007cef4ddd0b0a  mov eax, 0x410338
00007cef4ddd0b0f  mov [r15+0x100], rax
00007cef4ddd0b16  jmp 0x00007CEF4DBFE110
00007cef4ddd0b1b  int3
00007cef4ddd0b1c  call 0x00007CEF4DCC3FE0
00007cef4ddd0b21  jmp 0x00007CEF4DDD0AAB
00007cef4ddd0b26  int3
00007cef4ddd0b27  nop [rax+rax*1], ax
00007cef4ddd0b30  mov rax, [r15+0xF8]
00007cef4ddd0b37  mov r14d, [r13+rax*1]
00007cef4ddd0b3c  lea r12, [rax+0x04]
00007cef4ddd0b40  mov r11d, [r13+r12*1]
00007cef4ddd0b45  lea r12, [rax+0x08]
00007cef4ddd0b49  mov r10d, [r13+r12*1]
00007cef4ddd0b4e  lea r12, [rax+0x0C]
00007cef4ddd0b52  mov r9d, [r13+r12*1]
00007cef4ddd0b57  mov qword ptr [r15+0x48], 0x430860
00007cef4ddd0b5f  lea r12, [rax+0x80]
00007cef4ddd0b66  mov r8, [r13+r12*1]
00007cef4ddd0b6b  mov [r15+0xF0], r8
00007cef4ddd0b72  bswap r14d
00007cef4ddd0b75  bswap r11d
00007cef4ddd0b78  mov r12d, 0x430860
00007cef4ddd0b7e  mov [r13+r12*1], r14d
00007cef4ddd0b83  mov r14d, 0x430864
00007cef4ddd0b89  mov [r13+r14*1], r11d
00007cef4ddd0b8e  bswap r10d
00007cef4ddd0b91  bswap r9d
00007cef4ddd0b94  lea r14, [rax+0x10]
00007cef4ddd0b98  mov r12d, [r13+r14*1]
00007cef4ddd0b9d  lea r14, [rax+0x14]
00007cef4ddd0ba1  mov r11d, [r13+r14*1]
00007cef4ddd0ba6  mov r14d, 0x430868
00007cef4ddd0bac  mov [r13+r14*1], r10d
00007cef4ddd0bb1  mov r14d, 0x43086C
00007cef4ddd0bb7  mov [r13+r14*1], r9d
00007cef4ddd0bbc  lea r14, [rax+0x90]
00007cef4ddd0bc3  mov r10, [r13+r14*1]
00007cef4ddd0bc8  lea r14, [rax+0x98]
00007cef4ddd0bcf  mov r9, [r13+r14*1]
00007cef4ddd0bd4  mov [r15+0xA0], r10
00007cef4ddd0bdb  mov [r15+0x98], r9
00007cef4ddd0be2  bswap r12d
00007cef4ddd0be5  bswap r11d
00007cef4ddd0be8  mov [rsp+0x10], r11d
00007cef4ddd0bed  mov r11d, r11d
00007cef4ddd0bf0  mov [r15+0x58], r11
00007cef4ddd0bf4  lea r14, [rax+0x18]
00007cef4ddd0bf8  mov r11d, [r13+r14*1]
00007cef4ddd0bfd  lea r14, [rax+0x1C]
00007cef4ddd0c01  mov r10d, [r13+r14*1]
00007cef4ddd0c06  mov [rsp+0x20], r10d
00007cef4ddd0c0b  mov r10d, r10d
00007cef4ddd0c0e  mov [r15+0x60], r10
00007cef4ddd0c12  mov r14d, 0x430870
00007cef4ddd0c18  mov [r13+r14*1], r12d
00007cef4ddd0c1d  mov r14d, 0x430874
00007cef4ddd0c23  mov r12d, [rsp+0x10]
00007cef4ddd0c28  mov [r13+r14*1], r12d
00007cef4ddd0c2d  bswap r11d
00007cef4ddd0c30  mov [rsp+0x10], r11d
00007cef4ddd0c35  mov r11d, r11d
00007cef4ddd0c38  mov [r15+0x40], r11
00007cef4ddd0c3c  mov r14d, [rsp+0x20]
00007cef4ddd0c41  bswap r14d
00007cef4ddd0c44  mov [rsp+0x20], r14d
00007cef4ddd0c49  mov r14d, r14d
00007cef4ddd0c4c  mov [r15+0x50], r14
00007cef4ddd0c50  mov r14d, 0x430878
00007cef4ddd0c56  mov r12d, [rsp+0x10]
00007cef4ddd0c5b  mov [r13+r14*1], r12d
00007cef4ddd0c60  mov r14d, 0x43087C
00007cef4ddd0c66  mov r12d, [rsp+0x20]
00007cef4ddd0c6b  mov [r13+r14*1], r12d
00007cef4ddd0c70  lea r14, [rax+0xA0]
00007cef4ddd0c77  mov [r15+0xF8], r14
00007cef4ddd0c7e  mov [r15+0x100], r8
00007cef4ddd0c85  jmp 0x00007CEF4DDCE5C0
00007cef4ddd0c8a  int3
00007cef4ddd0c8b  call 0x00007CEF4DC0DAE0
00007cef4ddd0c90  jmp 0x00007CEF4DDD0B3C
00007cef4ddd0c95  call 0x00007CEF4DCC0230
00007cef4ddd0c9a  jmp 0x00007CEF4DDD0B45
00007cef4ddd0c9f  call 0x00007CEF4DCBEFC0
00007cef4ddd0ca4  jmp 0x00007CEF4DDD0B4E
00007cef4ddd0ca9  call 0x00007CEF4DCBDD50
00007cef4ddd0cae  jmp 0x00007CEF4DDD0B57
00007cef4ddd0cb3  call 0x00007CEF4DCBCC20
00007cef4ddd0cb8  jmp 0x00007CEF4DDD0B6B
00007cef4ddd0cbd  call 0x00007CEF4DCC3EA0
00007cef4ddd0cc2  jmp 0x00007CEF4DDD0B83
00007cef4ddd0cc7  call 0x00007CEF4DCE1920
00007cef4ddd0ccc  jmp 0x00007CEF4DDD0B8E
00007cef4ddd0cd1  call 0x00007CEF4DCE26A0
00007cef4ddd0cd6  jmp 0x00007CEF4DDD0B9D
00007cef4ddd0cdb  call 0x00007CEF4DCE1430
00007cef4ddd0ce0  jmp 0x00007CEF4DDD0BA6
00007cef4ddd0ce5  call 0x00007CEF4DCE06B0
00007cef4ddd0cea  jmp 0x00007CEF4DDD0BB1
00007cef4ddd0cef  call 0x00007CEF4DCDF440
00007cef4ddd0cf4  jmp 0x00007CEF4DDD0BBC
00007cef4ddd0cf9  call 0x00007CEF4DCE0300
00007cef4ddd0cfe  jmp 0x00007CEF4DDD0BC8
00007cef4ddd0d03  call 0x00007CEF4DCDF090
00007cef4ddd0d08  jmp 0x00007CEF4DDD0BD4
00007cef4ddd0d0d  call 0x00007CEF4DCE1430
00007cef4ddd0d12  jmp 0x00007CEF4DDD0BFD
00007cef4ddd0d17  call 0x00007CEF4DCE01C0
00007cef4ddd0d1c  jmp 0x00007CEF4DDD0C06
00007cef4ddd0d21  call 0x00007CEF4DCE2BA0
00007cef4ddd0d26  jmp 0x00007CEF4DDD0C1D
00007cef4ddd0d2b  call 0x00007CEF4DCE2BA0
00007cef4ddd0d30  jmp 0x00007CEF4DDD0C2D
00007cef4ddd0d35  call 0x00007CEF4DCE2BA0
00007cef4ddd0d3a  jmp 0x00007CEF4DDD0C60
00007cef4ddd0d3f  call 0x00007CEF4DCE2BA0
00007cef4ddd0d44  jmp 0x00007CEF4DDD0C70
00007cef4ddd0d49  int3
00007cef4ddd0d4a  nop [rax+rax*1], ax
00007cef4ddd0d50  mov qword ptr [r15+0x100], 0x04
00007cef4ddd0d5b  mov esi, 0x00
00007cef4ddd0d60  mov edx, 0x09
00007cef4ddd0d65  mov rdi, 0x7FFDA06ECA20
00007cef4ddd0d6f  mov rax, 0x5EB339D81970
00007cef4ddd0d79  call rax
00007cef4ddd0d7b  cmp dword ptr [r15+0x318], 0x00
00007cef4ddd0d83  jnz 0x00007CEF4DBFE110
00007cef4ddd0d89  jmp 0x00007CEF4DBFE0A0
00007cef4ddd0d8e  int3
00007cef4ddd0d8f  int3
