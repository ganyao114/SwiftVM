00007b0c5c7ce69b  nop [rax+rax*1], eax
00007b0c5c7ce6a0  mov qword ptr [r15+0x20], 0x420060
00007b0c5c7ce6a8  mov qword ptr [r15], 0x03
00007b0c5c7ce6af  xor eax, eax
00007b0c5c7ce6b1  mov r14d, 0xB71B00
00007b0c5c7ce6b7  mov r12d, 0x01
00007b0c5c7ce6bd  sub r14, r12
00007b0c5c7ce6c0  cmc
00007b0c5c7ce6c1  lahf
00007b0c5c7ce6c2  seto al
00007b0c5c7ce6c5  mov [r15+0x108], eax
00007b0c5c7ce6cc  mov [r15+0x08], r14
00007b0c5c7ce6d0  mov eax, [r15+0x108]
00007b0c5c7ce6d7  sahf
00007b0c5c7ce6d8  jnz 0x00007B0C5C7CE70A
00007b0c5c7ce6da  cmp dword ptr [r15+0x318], 0x00
00007b0c5c7ce6e2  jz 0x00007B0C5C7CE7F0
00007b0c5c7ce6e8  nop [rax+rax*1], ax
00007b0c5c7ce6f1  nop [rax+rax*1], eax
00007b0c5c7ce6f9  mov eax, 0x41004C
00007b0c5c7ce6fe  mov [r15+0x100], rax
00007b0c5c7ce705  jmp 0x00007B0C5C5FE110
00007b0c5c7ce70a  cmp dword ptr [r15+0x318], 0x00
00007b0c5c7ce712  jz 0x00007B0C5C7CE740
00007b0c5c7ce718  nop [rax+rax*1], ax
00007b0c5c7ce721  nop [rax+rax*1], eax
00007b0c5c7ce729  mov eax, 0x41003C
00007b0c5c7ce72e  mov [r15+0x100], rax
00007b0c5c7ce735  jmp 0x00007B0C5C5FE110
00007b0c5c7ce73a  int3
00007b0c5c7ce73b  int3
00007b0c5c7ce73c  nop [rax], eax
00007b0c5c7ce740  mov rax, [r15]
00007b0c5c7ce743  lea r14, [rax+0x03]
00007b0c5c7ce747  mov [rsp+0x10], r14
00007b0c5c7ce74c  shr r14, 0x07
00007b0c5c7ce750  mov rax, [rsp+0x10]
00007b0c5c7ce755  xor rax, r14
00007b0c5c7ce758  mov [r15], rax
00007b0c5c7ce75b  mov rax, [r15+0x08]
00007b0c5c7ce75f  mov [rsp+0x10], rax
00007b0c5c7ce764  xor eax, eax
00007b0c5c7ce766  mov r14, [rsp+0x10]
00007b0c5c7ce76b  mov r12d, 0x01
00007b0c5c7ce771  sub r14, r12
00007b0c5c7ce774  cmc
00007b0c5c7ce775  lahf
00007b0c5c7ce776  seto al
00007b0c5c7ce779  mov [r15+0x108], eax
00007b0c5c7ce780  mov [r15+0x08], r14
00007b0c5c7ce784  mov eax, [r15+0x108]
00007b0c5c7ce78b  sahf
00007b0c5c7ce78c  jnz 0x00007B0C5C7CE7BE
00007b0c5c7ce78e  cmp dword ptr [r15+0x318], 0x00
00007b0c5c7ce796  jz 0x00007B0C5C7CE7F0
00007b0c5c7ce79c  nop [rax+rax*1], ax
00007b0c5c7ce7a5  nop [rax+rax*1], eax
00007b0c5c7ce7ad  mov eax, 0x41004C
00007b0c5c7ce7b2  mov [r15+0x100], rax
00007b0c5c7ce7b9  jmp 0x00007B0C5C5FE110
00007b0c5c7ce7be  cmp dword ptr [r15+0x318], 0x00
00007b0c5c7ce7c6  jz 0x00007B0C5C7CE740
00007b0c5c7ce7cc  nop [rax+rax*1], ax
00007b0c5c7ce7d5  nop [rax+rax*1], eax
00007b0c5c7ce7dd  mov eax, 0x41003C
00007b0c5c7ce7e2  mov [r15+0x100], rax
00007b0c5c7ce7e9  jmp 0x00007B0C5C5FE110
00007b0c5c7ce7ee  int3
00007b0c5c7ce7ef  int3
00007b0c5c7ce7f0  mov rax, [r15+0x20]
00007b0c5c7ce7f4  mov r14, [r15]
00007b0c5c7ce7f7  mov [r13+rax*1], r14
00007b0c5c7ce7fc  mov rax, [r15+0xF0]
00007b0c5c7ce803  mov [r15+0x100], rax
00007b0c5c7ce80a  jmp 0x00007B0C5C7CE5C0
00007b0c5c7ce80f  int3
00007b0c5c7ce810  call 0x00007B0C5C60E120
00007b0c5c7ce815  jmp 0x00007B0C5C7CE7FC
00007b0c5c7ce81a  int3
00007b0c5c7ce81b  nop [rax+rax*1], eax
00007b0c5c7ce820  mov qword ptr [r15+0x100], 0x04
00007b0c5c7ce82b  mov esi, 0x00
00007b0c5c7ce830  mov edx, 0x09
00007b0c5c7ce835  mov rdi, 0x7FFFB9609E80
00007b0c5c7ce83f  mov rax, 0x57EEED082970
00007b0c5c7ce849  call rax
00007b0c5c7ce84b  cmp dword ptr [r15+0x318], 0x00
00007b0c5c7ce853  jnz 0x00007B0C5C5FE110
00007b0c5c7ce859  jmp 0x00007B0C5C5FE0A0
00007b0c5c7ce85e  int3
00007b0c5c7ce85f  int3
