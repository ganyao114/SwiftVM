00007cdee2bce69b  nop [rax+rax*1], eax
00007cdee2bce6a0  mov qword ptr [r15+0x20], 0x420060
00007cdee2bce6a8  mov eax, 0x420060
00007cdee2bce6ad  xor r14d, r14d
00007cdee2bce6b0  mov [r13+rax*1], r14
00007cdee2bce6b5  mov eax, 0x420060
00007cdee2bce6ba  mov r14, [r13+rax*1]
00007cdee2bce6bf  mov [r15+0x18], r14
00007cdee2bce6c3  lea rax, [r14+0x03]
00007cdee2bce6c7  mov [r15], rax
00007cdee2bce6ca  xor eax, eax
00007cdee2bce6cc  mov r14d, 0xB71B00
00007cdee2bce6d2  mov r12d, 0x01
00007cdee2bce6d8  sub r14, r12
00007cdee2bce6db  cmc
00007cdee2bce6dc  lahf
00007cdee2bce6dd  seto al
00007cdee2bce6e0  mov [r15+0x108], eax
00007cdee2bce6e7  mov [r15+0x08], r14
00007cdee2bce6eb  mov eax, [r15+0x108]
00007cdee2bce6f2  sahf
00007cdee2bce6f3  jnz 0x00007CDEE2BCE725
00007cdee2bce6f5  cmp dword ptr [r15+0x318], 0x00
00007cdee2bce6fd  jz 0x00007CDEE2BCE840
00007cdee2bce703  nop [rax+rax*1], ax
00007cdee2bce70c  nop [rax+rax*1], eax
00007cdee2bce714  mov eax, 0x410050
00007cdee2bce719  mov [r15+0x100], rax
00007cdee2bce720  jmp 0x00007CDEE29FE110
00007cdee2bce725  cmp dword ptr [r15+0x318], 0x00
00007cdee2bce72d  jz 0x00007CDEE2BCE770
00007cdee2bce733  nop [rax+rax*1], ax
00007cdee2bce73c  nop [rax+rax*1], eax
00007cdee2bce744  mov eax, 0x41003C
00007cdee2bce749  mov [r15+0x100], rax
00007cdee2bce750  jmp 0x00007CDEE29FE110
00007cdee2bce755  int3
00007cdee2bce756  call 0x00007CDEE2A0E120
00007cdee2bce75b  jmp 0x00007CDEE2BCE6B5
00007cdee2bce760  call 0x00007CDEE2A0DC20
00007cdee2bce765  jmp 0x00007CDEE2BCE6BF
00007cdee2bce76a  int3
00007cdee2bce76b  nop [rax+rax*1], eax
00007cdee2bce770  mov rax, [r15+0x20]
00007cdee2bce774  mov r14, [r15]
00007cdee2bce777  mov [r13+rax*1], r14
00007cdee2bce77c  mov r14, [r13+rax*1]
00007cdee2bce781  mov [r15+0x18], r14
00007cdee2bce785  lea rax, [r14+0x03]
00007cdee2bce789  mov [r15], rax
00007cdee2bce78c  mov rax, [r15+0x08]
00007cdee2bce790  mov [rsp+0x10], rax
00007cdee2bce795  xor eax, eax
00007cdee2bce797  mov r14, [rsp+0x10]
00007cdee2bce79c  mov r12d, 0x01
00007cdee2bce7a2  sub r14, r12
00007cdee2bce7a5  cmc
00007cdee2bce7a6  lahf
00007cdee2bce7a7  seto al
00007cdee2bce7aa  mov [r15+0x108], eax
00007cdee2bce7b1  mov [r15+0x08], r14
00007cdee2bce7b5  mov eax, [r15+0x108]
00007cdee2bce7bc  sahf
00007cdee2bce7bd  jnz 0x00007CDEE2BCE7EF
00007cdee2bce7bf  cmp dword ptr [r15+0x318], 0x00
00007cdee2bce7c7  jz 0x00007CDEE2BCE840
00007cdee2bce7cd  nop [rax+rax*1], ax
00007cdee2bce7d6  nop [rax+rax*1], eax
00007cdee2bce7de  mov eax, 0x410050
00007cdee2bce7e3  mov [r15+0x100], rax
00007cdee2bce7ea  jmp 0x00007CDEE29FE110
00007cdee2bce7ef  cmp dword ptr [r15+0x318], 0x00
00007cdee2bce7f7  jz 0x00007CDEE2BCE770
00007cdee2bce7fd  nop [rax+rax*1], ax
00007cdee2bce806  nop [rax+rax*1], eax
00007cdee2bce80e  mov eax, 0x41003C
00007cdee2bce813  mov [r15+0x100], rax
00007cdee2bce81a  jmp 0x00007CDEE29FE110
00007cdee2bce81f  int3
00007cdee2bce820  call 0x00007CDEE2A0E120
00007cdee2bce825  jmp 0x00007CDEE2BCE77C
00007cdee2bce82a  call 0x00007CDEE2A0DC20
00007cdee2bce82f  jmp 0x00007CDEE2BCE781
00007cdee2bce834  int3
00007cdee2bce835  nop [rax+rax*1], ax
00007cdee2bce83e  nop
00007cdee2bce840  mov rax, [r15+0x20]
00007cdee2bce844  mov r14, [r15]
00007cdee2bce847  mov [r13+rax*1], r14
00007cdee2bce84c  mov rax, [r15+0xF0]
00007cdee2bce853  mov [r15+0x100], rax
00007cdee2bce85a  jmp 0x00007CDEE2BCE5C0
00007cdee2bce85f  int3
00007cdee2bce860  call 0x00007CDEE2A0E120
00007cdee2bce865  jmp 0x00007CDEE2BCE84C
00007cdee2bce86a  int3
00007cdee2bce86b  nop [rax+rax*1], eax
00007cdee2bce870  mov qword ptr [r15+0x100], 0x04
00007cdee2bce87b  mov esi, 0x00
00007cdee2bce880  mov edx, 0x09
00007cdee2bce885  mov rdi, 0x7FFCA33593E0
00007cdee2bce88f  mov rax, 0x58D424C0F970
00007cdee2bce899  call rax
00007cdee2bce89b  cmp dword ptr [r15+0x318], 0x00
00007cdee2bce8a3  jnz 0x00007CDEE29FE110
00007cdee2bce8a9  jmp 0x00007CDEE29FE0A0
00007cdee2bce8ae  int3
00007cdee2bce8af  int3
