
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute/candidate/0/4.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xf8]
  18:	add    r13,0x168
  1f:	mov    r14,QWORD PTR [r13+0x0]
  23:	mov    QWORD PTR [r12+0x40],r14
  28:	sub    r14,0x38
  2c:	mov    rcx,QWORD PTR [r12+0x380]
  34:	jrcxz  0x3b
  36:	jmp    0x10d
  3b:	jne    0x54
  41:	mov    r11,rax
  44:	lahf
  45:	seto   al
  48:	mov    WORD PTR [rsp],ax
  4c:	mov    rax,r11
  4f:	jmp    0x67
  54:	mov    r11,rax
  57:	lahf
  58:	seto   al
  5b:	mov    WORD PTR [rsp],ax
  5f:	mov    rax,r11
  62:	jmp    0xbd
  67:	mov    r13d,0x4102d4
  6d:	mov    QWORD PTR [r12+0x100],r13
  75:	mov    r11,QWORD PTR [rsp]
  79:	mov    QWORD PTR [r12+0x398],r11
  81:	mov    edi,0x4102d4
  86:	mov    QWORD PTR [r12+0x100],rdi
  8e:	add    rsp,0x10
  92:	nop    WORD PTR [rax+rax*1+0x0]
  98:	jmp    QWORD PTR [rip+0x2]        # 0xa0
  9e:	xchg   ax,ax
  a0:	(bad)
  a1:	adc    BYTE PTR [rax],dh
  a3:	ins    BYTE PTR es:[rdi],dx
  a4:	or     BYTE PTR [rbx+0x0],bh
  a7:	add    BYTE PTR [rax],dh
  a9:	adc    DWORD PTR [rax],esi
  ab:	ins    BYTE PTR es:[rdi],dx
  ac:	or     BYTE PTR [rbx+0x0],bh
  af:	add    BYTE PTR [rcx-0x45],cl
  b2:	rex stc
  b4:	sub    BYTE PTR [rbp+0x590d],al
  ba:	jmp    r11
  bd:	mov    r13d,0x4102b8
  c3:	mov    QWORD PTR [r12+0x100],r13
  cb:	mov    r11,QWORD PTR [rsp]
  cf:	mov    QWORD PTR [r12+0x398],r11
  d7:	mov    edi,0x4102b8
  dc:	mov    QWORD PTR [r12+0x100],rdi
  e4:	add    rsp,0x10
  e8:	jmp    QWORD PTR [rip+0x2]        # 0xf0
  ee:	xchg   ax,ax
  f0:	adc    BYTE PTR [rax],sil
  f3:	ins    BYTE PTR es:[rdi],dx
  f4:	or     BYTE PTR [rbx+0x0],bh
  f7:	add    BYTE PTR [rax+0x86c3011],al
  fd:	jnp    0xff
  ff:	add    BYTE PTR [rcx-0x45],cl
 102:	rex stc
 104:	sub    BYTE PTR [rbp+0x590d],al
 10a:	jmp    r11
 10d:	mov    eax,0x4102d0
 112:	mov    QWORD PTR [r12+0x100],rax
 11a:	push   rdx
 11b:	push   rsi
 11c:	push   r10
 11e:	push   r11
 120:	mov    r11,rax
 123:	lahf
 124:	seto   al
 127:	mov    WORD PTR [rsp+0x20],ax
 12c:	mov    rax,r11
 12f:	mov    rdx,QWORD PTR [rsp+0x20]
 134:	mov    r10d,edx
 137:	and    r10d,0xc000
 13e:	shl    r10d,0x10
 142:	mov    r11d,edx
 145:	and    r11d,0x100
 14c:	shl    r11d,0x15
 150:	or     r10d,r11d
 153:	and    edx,0x1
 156:	shl    edx,0x1c
 159:	or     r10d,edx
 15c:	btc    r10,0x1d
 161:	mov    r11d,0xf0000000
 167:	and    r11,r10
 16a:	movabs rsi,0xffffffff0fffffff
 174:	and    rbx,rsi
 177:	or     rbx,r11
 17a:	pop    r11
 17c:	pop    r10
 17e:	pop    rsi
 17f:	pop    rdx
 180:	mov    QWORD PTR [r12+0x108],rbx
 188:	add    rsp,0x10
 18c:	mov    eax,0xc
 191:	movabs r11,0x590d8528fca0
 19b:	jmp    r11
 19e:	nop
 19f:	nop
