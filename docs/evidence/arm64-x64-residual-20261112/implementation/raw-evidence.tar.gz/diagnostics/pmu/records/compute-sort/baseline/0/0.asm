
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-sort/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xf8]
  18:	sub    r13,0x20
  1c:	mov    r14,QWORD PTR [r12+0xf0]
  24:	mov    QWORD PTR [r13+0x0],r14
  28:	mov    r14d,0x0
  2e:	mov    DWORD PTR [r12+0x32c],r14d
  36:	mov    QWORD PTR [r12+0xf8],r13
  3e:	add    r13,0x10
  42:	mov    r14,r13
  45:	add    r14,0x8
  49:	mov    r15,QWORD PTR [r12+0xa0]
  51:	mov    rbp,QWORD PTR [r12+0x98]
  59:	mov    QWORD PTR [r13+0x0],r15
  5d:	mov    r13d,0x0
  63:	mov    DWORD PTR [r12+0x32c],r13d
  6b:	mov    QWORD PTR [r14],rbp
  6e:	mov    r13d,0x0
  74:	mov    DWORD PTR [r12+0x32c],r13d
  7c:	mov    r13d,0x0
  82:	mov    QWORD PTR [r12+0xa0],r13
  8a:	mov    r13d,0x420000
  90:	add    r13,0x2a0
  97:	mov    QWORD PTR [r12+0x98],r13
  9f:	mov    r13d,0x11
  a5:	mov    QWORD PTR [r12],r13
  a9:	mov    r13d,0x410184
  af:	mov    QWORD PTR [r12+0xf0],r13
  b7:	mov    r13d,0x41021c
  bd:	mov    QWORD PTR [r12+0x100],r13
  c5:	mov    r11,QWORD PTR [rsp]
  c9:	mov    QWORD PTR [r12+0x398],r11
  d1:	mov    edi,0x41021c
  d6:	mov    QWORD PTR [r12+0x100],rdi
  de:	add    rsp,0x10
  e2:	nop    WORD PTR [rax+rax*1+0x0]
  e8:	jmp    QWORD PTR [rip+0x2]        # 0xf0
  ee:	xchg   ax,ax
  f0:	adc    cl,ah
  f2:	scas   eax,DWORD PTR es:[rdi]
  f3:	rex.WRXB jbe 0x171
  f6:	add    BYTE PTR [rax],al
  f8:	add    cl,ah
  fa:	scas   eax,DWORD PTR es:[rdi]
  fb:	rex.WRXB jbe 0x179
  fe:	add    BYTE PTR [rax],al
 100:	movabs r11,0x5f6324da90a0
 10a:	jmp    r11
 10d:	nop
 10e:	nop
 10f:	nop
