
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute/candidate/0/6.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13d,DWORD PTR [r12]
  14:	mov    r14d,r13d
  17:	mov    r14d,r14d
  1a:	shr    r14d,0x10
  1e:	xor    r13d,r14d
  21:	mov    QWORD PTR [r12+0x40],r13
  26:	mov    r14d,0x352d
  2c:	mov    QWORD PTR [r12+0x48],r14
  31:	mov    r14d,0x352d
  37:	mov    r15d,0x7feb
  3d:	and    r15d,0xffff
  44:	mov    rax,r14
  47:	movabs rcx,0xffffffff0000ffff
  51:	and    rax,rcx
  54:	mov    rdx,r15
  57:	shl    rdx,0x10
  5b:	mov    ecx,0xffff0000
  60:	and    rdx,rcx
  63:	or     rax,rdx
  66:	mov    ebp,eax
  68:	mov    QWORD PTR [r12+0x48],rbp
  6d:	mov    r14d,0x0
  73:	imul   r13d,ebp
  77:	mov    r15d,r14d
  7a:	add    r15d,r13d
  7d:	mov    QWORD PTR [r12+0x40],r15
  82:	mov    r13d,0xa68b
  88:	mov    QWORD PTR [r12+0x48],r13
  8d:	mov    r13d,0xa68b
  93:	mov    r14d,0x846c
  99:	and    r14d,0xffff
  a0:	mov    rax,r13
  a3:	movabs rcx,0xffffffff0000ffff
  ad:	and    rax,rcx
  b0:	mov    rdx,r14
  b3:	shl    rdx,0x10
  b7:	mov    ecx,0xffff0000
  bc:	and    rdx,rcx
  bf:	or     rax,rdx
  c2:	mov    ebp,eax
  c4:	mov    QWORD PTR [r12+0x48],rbp
  c9:	mov    r13d,r15d
  cc:	mov    r13d,r13d
  cf:	shr    r13d,0xf
  d3:	xor    r15d,r13d
  d6:	mov    QWORD PTR [r12+0x40],r15
  db:	mov    r13d,0x0
  e1:	imul   r15d,ebp
  e5:	mov    r14d,r13d
  e8:	add    r14d,r15d
  eb:	mov    QWORD PTR [r12+0x40],r14
  f0:	mov    r13d,r14d
  f3:	mov    r13d,r13d
  f6:	shr    r13d,0x10
  fa:	xor    r14d,r13d
  fd:	mov    QWORD PTR [r12],r14
 101:	mov    rcx,QWORD PTR [r12+0x380]
 109:	jrcxz  0x110
 10b:	jmp    0x145
 110:	mov    r13,QWORD PTR [r12+0xf0]
 118:	mov    QWORD PTR [r12+0x100],r13
 120:	mov    r11,QWORD PTR [rsp]
 124:	mov    QWORD PTR [r12+0x398],r11
 12c:	mov    rdi,QWORD PTR [r12+0x100]
 134:	add    rsp,0x10
 138:	movabs r11,0x590d8528f940
 142:	jmp    r11
 145:	mov    eax,0x4109c8
 14a:	mov    QWORD PTR [r12+0x100],rax
 152:	push   rdx
 153:	push   rsi
 154:	push   r10
 156:	push   r11
 158:	mov    rdx,QWORD PTR [rsp+0x20]
 15d:	mov    r10d,edx
 160:	and    r10d,0xc000
 167:	shl    r10d,0x10
 16b:	mov    r11d,edx
 16e:	and    r11d,0x100
 175:	shl    r11d,0x15
 179:	or     r10d,r11d
 17c:	and    edx,0x1
 17f:	shl    edx,0x1c
 182:	or     r10d,edx
 185:	btc    r10,0x1d
 18a:	mov    r11d,0xf0000000
 190:	and    r11,r10
 193:	movabs rsi,0xffffffff0fffffff
 19d:	and    rbx,rsi
 1a0:	or     rbx,r11
 1a3:	pop    r11
 1a5:	pop    r10
 1a7:	pop    rsi
 1a8:	pop    rdx
 1a9:	mov    QWORD PTR [r12+0x108],rbx
 1b1:	add    rsp,0x10
 1b5:	mov    eax,0xc
 1ba:	movabs r11,0x590d8528fca0
 1c4:	jmp    r11
 1c7:	nop
