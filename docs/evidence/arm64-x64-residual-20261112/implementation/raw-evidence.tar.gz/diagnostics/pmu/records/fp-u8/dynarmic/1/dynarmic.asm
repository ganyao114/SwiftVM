0000748c59dce69b  nop [rax+rax*1], eax
0000748c59dce6a0  mov qword ptr [r15+0x20], 0x420080
0000748c59dce6a8  mov qword ptr [r15], 0x00
0000748c59dce6af  vmovaps xmm1, [0x0000748C599FE010]
0000748c59dce6b7  movq xmm1, xmm1
0000748c59dce6bb  vmovaps xmm15, [0x0000748C599FE020]
0000748c59dce6c3  movq xmm15, xmm15
0000748c59dce6c8  movaps [r15+0x120], xmm15
0000748c59dce6d0  movq rax, xmm1
0000748c59dce6d5  movq r14, xmm15
0000748c59dce6da  vmovq xmm1, rax
0000748c59dce6df  vmovq xmm14, r14
0000748c59dce6e4  movaps xmm13, xmm1
0000748c59dce6e8  addsd xmm13, xmm14
0000748c59dce6ed  ucomisd xmm13, xmm13
0000748c59dce6f2  jp 0x0000748C59DCE8CC
0000748c59dce6f8  movq xmm13, xmm13
0000748c59dce6fd  movq rax, xmm13
0000748c59dce702  movq r14, xmm15
0000748c59dce707  vmovq xmm1, rax
0000748c59dce70c  vmovq xmm14, r14
0000748c59dce711  movaps xmm13, xmm1
0000748c59dce715  addsd xmm13, xmm14
0000748c59dce71a  ucomisd xmm13, xmm13
0000748c59dce71f  jp 0x0000748C59DCE914
0000748c59dce725  movq xmm13, xmm13
0000748c59dce72a  movq rax, xmm13
0000748c59dce72f  movq r14, xmm15
0000748c59dce734  vmovq xmm1, rax
0000748c59dce739  vmovq xmm14, r14
0000748c59dce73e  movaps xmm13, xmm1
0000748c59dce742  addsd xmm13, xmm14
0000748c59dce747  ucomisd xmm13, xmm13
0000748c59dce74c  jp 0x0000748C59DCE95C
0000748c59dce752  movq xmm13, xmm13
0000748c59dce757  movq rax, xmm13
0000748c59dce75c  movq r14, xmm15
0000748c59dce761  vmovq xmm1, rax
0000748c59dce766  vmovq xmm14, r14
0000748c59dce76b  movaps xmm13, xmm1
0000748c59dce76f  addsd xmm13, xmm14
0000748c59dce774  ucomisd xmm13, xmm13
0000748c59dce779  jp 0x0000748C59DCE9A4
0000748c59dce77f  movq xmm13, xmm13
0000748c59dce784  movq rax, xmm13
0000748c59dce789  movq r14, xmm15
0000748c59dce78e  vmovq xmm1, rax
0000748c59dce793  vmovq xmm14, r14
0000748c59dce798  movaps xmm13, xmm1
0000748c59dce79c  addsd xmm13, xmm14
0000748c59dce7a1  ucomisd xmm13, xmm13
0000748c59dce7a6  jp 0x0000748C59DCE9EC
0000748c59dce7ac  movq xmm13, xmm13
0000748c59dce7b1  movq rax, xmm13
0000748c59dce7b6  movq r14, xmm15
0000748c59dce7bb  vmovq xmm1, rax
0000748c59dce7c0  vmovq xmm14, r14
0000748c59dce7c5  movaps xmm13, xmm1
0000748c59dce7c9  addsd xmm13, xmm14
0000748c59dce7ce  ucomisd xmm13, xmm13
0000748c59dce7d3  jp 0x0000748C59DCEA34
0000748c59dce7d9  movq xmm13, xmm13
0000748c59dce7de  movq rax, xmm13
0000748c59dce7e3  movq r14, xmm15
0000748c59dce7e8  vmovq xmm1, rax
0000748c59dce7ed  vmovq xmm14, r14
0000748c59dce7f2  movaps xmm13, xmm1
0000748c59dce7f6  addsd xmm13, xmm14
0000748c59dce7fb  ucomisd xmm13, xmm13
0000748c59dce800  jp 0x0000748C59DCEA7C
0000748c59dce806  movq xmm13, xmm13
0000748c59dce80b  movq rax, xmm13
0000748c59dce810  movq r14, xmm15
0000748c59dce815  vmovq xmm1, rax
0000748c59dce81a  vmovq xmm15, r14
0000748c59dce81f  movaps xmm14, xmm1
0000748c59dce823  addsd xmm14, xmm15
0000748c59dce828  ucomisd xmm14, xmm14
0000748c59dce82d  jp 0x0000748C59DCEAC4
0000748c59dce833  movq xmm14, xmm14
0000748c59dce838  movaps [r15+0x110], xmm14
0000748c59dce840  xor eax, eax
0000748c59dce842  mov r14d, 0x1E848
0000748c59dce848  mov r12d, 0x01
0000748c59dce84e  sub r14, r12
0000748c59dce851  cmc
0000748c59dce852  lahf
0000748c59dce853  seto al
0000748c59dce856  mov [r15+0x108], eax
0000748c59dce85d  mov [r15+0x08], r14
0000748c59dce861  mov eax, [r15+0x108]
0000748c59dce868  sahf
0000748c59dce869  jnz 0x0000748C59DCE89B
0000748c59dce86b  cmp dword ptr [r15+0x318], 0x00
0000748c59dce873  jz 0x0000748C59DCEF70
0000748c59dce879  nop [rax+rax*1], ax
0000748c59dce882  nop [rax+rax*1], eax
0000748c59dce88a  mov eax, 0x41006C
0000748c59dce88f  mov [r15+0x100], rax
0000748c59dce896  jmp 0x0000748C59BFE110
0000748c59dce89b  cmp dword ptr [r15+0x318], 0x00
0000748c59dce8a3  jz 0x0000748C59DCEB10
0000748c59dce8a9  nop [rax+rax*1], ax
0000748c59dce8b2  nop [rax+rax*1], eax
0000748c59dce8ba  mov eax, 0x410044
0000748c59dce8bf  mov [r15+0x100], rax
0000748c59dce8c6  jmp 0x0000748C59BFE110
0000748c59dce8cb  int3
0000748c59dce8cc  ucomisd xmm1, xmm14
0000748c59dce8d1  jp 0x0000748C59DCE8E0
0000748c59dce8d3  movaps xmm13, [0x0000748C599FE030]
0000748c59dce8db  jmp 0x0000748C59DCE6F8
0000748c59dce8e0  vxorps xmm0, xmm1, xmm14
0000748c59dce8e5  pextrw eax, xmm0, 0x03
0000748c59dce8ea  and eax, 0x7FF8
0000748c59dce8ef  cmp eax, 0x08
0000748c59dce8f2  jnz 0x0000748C59DCE6F8
0000748c59dce8f8  movq rax, xmm14
0000748c59dce8fd  shl rax, 0x0D
0000748c59dce901  jbe 0x0000748C59DCE6F8
0000748c59dce907  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dce90f  jmp 0x0000748C59DCE6F8
0000748c59dce914  ucomisd xmm1, xmm14
0000748c59dce919  jp 0x0000748C59DCE928
0000748c59dce91b  movaps xmm13, [0x0000748C599FE030]
0000748c59dce923  jmp 0x0000748C59DCE725
0000748c59dce928  vxorps xmm0, xmm1, xmm14
0000748c59dce92d  pextrw eax, xmm0, 0x03
0000748c59dce932  and eax, 0x7FF8
0000748c59dce937  cmp eax, 0x08
0000748c59dce93a  jnz 0x0000748C59DCE725
0000748c59dce940  movq rax, xmm14
0000748c59dce945  shl rax, 0x0D
0000748c59dce949  jbe 0x0000748C59DCE725
0000748c59dce94f  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dce957  jmp 0x0000748C59DCE725
0000748c59dce95c  ucomisd xmm1, xmm14
0000748c59dce961  jp 0x0000748C59DCE970
0000748c59dce963  movaps xmm13, [0x0000748C599FE030]
0000748c59dce96b  jmp 0x0000748C59DCE752
0000748c59dce970  vxorps xmm0, xmm1, xmm14
0000748c59dce975  pextrw eax, xmm0, 0x03
0000748c59dce97a  and eax, 0x7FF8
0000748c59dce97f  cmp eax, 0x08
0000748c59dce982  jnz 0x0000748C59DCE752
0000748c59dce988  movq rax, xmm14
0000748c59dce98d  shl rax, 0x0D
0000748c59dce991  jbe 0x0000748C59DCE752
0000748c59dce997  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dce99f  jmp 0x0000748C59DCE752
0000748c59dce9a4  ucomisd xmm1, xmm14
0000748c59dce9a9  jp 0x0000748C59DCE9B8
0000748c59dce9ab  movaps xmm13, [0x0000748C599FE030]
0000748c59dce9b3  jmp 0x0000748C59DCE77F
0000748c59dce9b8  vxorps xmm0, xmm1, xmm14
0000748c59dce9bd  pextrw eax, xmm0, 0x03
0000748c59dce9c2  and eax, 0x7FF8
0000748c59dce9c7  cmp eax, 0x08
0000748c59dce9ca  jnz 0x0000748C59DCE77F
0000748c59dce9d0  movq rax, xmm14
0000748c59dce9d5  shl rax, 0x0D
0000748c59dce9d9  jbe 0x0000748C59DCE77F
0000748c59dce9df  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dce9e7  jmp 0x0000748C59DCE77F
0000748c59dce9ec  ucomisd xmm1, xmm14
0000748c59dce9f1  jp 0x0000748C59DCEA00
0000748c59dce9f3  movaps xmm13, [0x0000748C599FE030]
0000748c59dce9fb  jmp 0x0000748C59DCE7AC
0000748c59dcea00  vxorps xmm0, xmm1, xmm14
0000748c59dcea05  pextrw eax, xmm0, 0x03
0000748c59dcea0a  and eax, 0x7FF8
0000748c59dcea0f  cmp eax, 0x08
0000748c59dcea12  jnz 0x0000748C59DCE7AC
0000748c59dcea18  movq rax, xmm14
0000748c59dcea1d  shl rax, 0x0D
0000748c59dcea21  jbe 0x0000748C59DCE7AC
0000748c59dcea27  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dcea2f  jmp 0x0000748C59DCE7AC
0000748c59dcea34  ucomisd xmm1, xmm14
0000748c59dcea39  jp 0x0000748C59DCEA48
0000748c59dcea3b  movaps xmm13, [0x0000748C599FE030]
0000748c59dcea43  jmp 0x0000748C59DCE7D9
0000748c59dcea48  vxorps xmm0, xmm1, xmm14
0000748c59dcea4d  pextrw eax, xmm0, 0x03
0000748c59dcea52  and eax, 0x7FF8
0000748c59dcea57  cmp eax, 0x08
0000748c59dcea5a  jnz 0x0000748C59DCE7D9
0000748c59dcea60  movq rax, xmm14
0000748c59dcea65  shl rax, 0x0D
0000748c59dcea69  jbe 0x0000748C59DCE7D9
0000748c59dcea6f  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dcea77  jmp 0x0000748C59DCE7D9
0000748c59dcea7c  ucomisd xmm1, xmm14
0000748c59dcea81  jp 0x0000748C59DCEA90
0000748c59dcea83  movaps xmm13, [0x0000748C599FE030]
0000748c59dcea8b  jmp 0x0000748C59DCE806
0000748c59dcea90  vxorps xmm0, xmm1, xmm14
0000748c59dcea95  pextrw eax, xmm0, 0x03
0000748c59dcea9a  and eax, 0x7FF8
0000748c59dcea9f  cmp eax, 0x08
0000748c59dceaa2  jnz 0x0000748C59DCE806
0000748c59dceaa8  movq rax, xmm14
0000748c59dceaad  shl rax, 0x0D
0000748c59dceab1  jbe 0x0000748C59DCE806
0000748c59dceab7  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dceabf  jmp 0x0000748C59DCE806
0000748c59dceac4  ucomisd xmm1, xmm15
0000748c59dceac9  jp 0x0000748C59DCEAD8
0000748c59dceacb  movaps xmm14, [0x0000748C599FE030]
0000748c59dcead3  jmp 0x0000748C59DCE833
0000748c59dcead8  vxorps xmm0, xmm1, xmm15
0000748c59dceadd  pextrw eax, xmm0, 0x03
0000748c59dceae2  and eax, 0x7FF8
0000748c59dceae7  cmp eax, 0x08
0000748c59dceaea  jnz 0x0000748C59DCE833
0000748c59dceaf0  movq rax, xmm15
0000748c59dceaf5  shl rax, 0x0D
0000748c59dceaf9  jbe 0x0000748C59DCE833
0000748c59dceaff  vorps xmm14, xmm15, [0x0000748C599FE040]
0000748c59dceb07  jmp 0x0000748C59DCE833
0000748c59dceb0c  int3
0000748c59dceb0d  nop [rax], eax
0000748c59dceb10  movaps xmm1, [r15+0x110]
0000748c59dceb18  movq rax, xmm1
0000748c59dceb1d  movaps xmm1, [r15+0x120]
0000748c59dceb25  movq r14, xmm1
0000748c59dceb2a  vmovq xmm15, rax
0000748c59dceb2f  vmovq xmm14, r14
0000748c59dceb34  movaps xmm13, xmm15
0000748c59dceb38  addsd xmm13, xmm14
0000748c59dceb3d  ucomisd xmm13, xmm13
0000748c59dceb42  jp 0x0000748C59DCED24
0000748c59dceb48  movq xmm13, xmm13
0000748c59dceb4d  movq rax, xmm13
0000748c59dceb52  movq r14, xmm1
0000748c59dceb57  vmovq xmm15, rax
0000748c59dceb5c  vmovq xmm14, r14
0000748c59dceb61  movaps xmm13, xmm15
0000748c59dceb65  addsd xmm13, xmm14
0000748c59dceb6a  ucomisd xmm13, xmm13
0000748c59dceb6f  jp 0x0000748C59DCED6C
0000748c59dceb75  movq xmm13, xmm13
0000748c59dceb7a  movq rax, xmm13
0000748c59dceb7f  movq r14, xmm1
0000748c59dceb84  vmovq xmm15, rax
0000748c59dceb89  vmovq xmm14, r14
0000748c59dceb8e  movaps xmm13, xmm15
0000748c59dceb92  addsd xmm13, xmm14
0000748c59dceb97  ucomisd xmm13, xmm13
0000748c59dceb9c  jp 0x0000748C59DCEDB4
0000748c59dceba2  movq xmm13, xmm13
0000748c59dceba7  movq rax, xmm13
0000748c59dcebac  movq r14, xmm1
0000748c59dcebb1  vmovq xmm15, rax
0000748c59dcebb6  vmovq xmm14, r14
0000748c59dcebbb  movaps xmm13, xmm15
0000748c59dcebbf  addsd xmm13, xmm14
0000748c59dcebc4  ucomisd xmm13, xmm13
0000748c59dcebc9  jp 0x0000748C59DCEDFC
0000748c59dcebcf  movq xmm13, xmm13
0000748c59dcebd4  movq rax, xmm13
0000748c59dcebd9  movq r14, xmm1
0000748c59dcebde  vmovq xmm15, rax
0000748c59dcebe3  vmovq xmm14, r14
0000748c59dcebe8  movaps xmm13, xmm15
0000748c59dcebec  addsd xmm13, xmm14
0000748c59dcebf1  ucomisd xmm13, xmm13
0000748c59dcebf6  jp 0x0000748C59DCEE44
0000748c59dcebfc  movq xmm13, xmm13
0000748c59dcec01  movq rax, xmm13
0000748c59dcec06  movq r14, xmm1
0000748c59dcec0b  vmovq xmm15, rax
0000748c59dcec10  vmovq xmm14, r14
0000748c59dcec15  movaps xmm13, xmm15
0000748c59dcec19  addsd xmm13, xmm14
0000748c59dcec1e  ucomisd xmm13, xmm13
0000748c59dcec23  jp 0x0000748C59DCEE8C
0000748c59dcec29  movq xmm13, xmm13
0000748c59dcec2e  movq rax, xmm13
0000748c59dcec33  movq r14, xmm1
0000748c59dcec38  vmovq xmm15, rax
0000748c59dcec3d  vmovq xmm14, r14
0000748c59dcec42  movaps xmm13, xmm15
0000748c59dcec46  addsd xmm13, xmm14
0000748c59dcec4b  ucomisd xmm13, xmm13
0000748c59dcec50  jp 0x0000748C59DCEED4
0000748c59dcec56  movq xmm13, xmm13
0000748c59dcec5b  movq rax, xmm13
0000748c59dcec60  movq r14, xmm1
0000748c59dcec65  vmovq xmm1, rax
0000748c59dcec6a  vmovq xmm15, r14
0000748c59dcec6f  movaps xmm14, xmm1
0000748c59dcec73  addsd xmm14, xmm15
0000748c59dcec78  ucomisd xmm14, xmm14
0000748c59dcec7d  jp 0x0000748C59DCEF1C
0000748c59dcec83  movq xmm14, xmm14
0000748c59dcec88  movaps [r15+0x110], xmm14
0000748c59dcec90  mov rax, [r15+0x08]
0000748c59dcec94  mov [rsp+0x10], rax
0000748c59dcec99  xor eax, eax
0000748c59dcec9b  mov r14, [rsp+0x10]
0000748c59dceca0  mov r12d, 0x01
0000748c59dceca6  sub r14, r12
0000748c59dceca9  cmc
0000748c59dcecaa  lahf
0000748c59dcecab  seto al
0000748c59dcecae  mov [r15+0x108], eax
0000748c59dcecb5  mov [r15+0x08], r14
0000748c59dcecb9  mov eax, [r15+0x108]
0000748c59dcecc0  sahf
0000748c59dcecc1  jnz 0x0000748C59DCECF3
0000748c59dcecc3  cmp dword ptr [r15+0x318], 0x00
0000748c59dceccb  jz 0x0000748C59DCEF70
0000748c59dcecd1  nop [rax+rax*1], ax
0000748c59dcecda  nop [rax+rax*1], eax
0000748c59dcece2  mov eax, 0x41006C
0000748c59dcece7  mov [r15+0x100], rax
0000748c59dcecee  jmp 0x0000748C59BFE110
0000748c59dcecf3  cmp dword ptr [r15+0x318], 0x00
0000748c59dcecfb  jz 0x0000748C59DCEB10
0000748c59dced01  nop [rax+rax*1], ax
0000748c59dced0a  nop [rax+rax*1], eax
0000748c59dced12  mov eax, 0x410044
0000748c59dced17  mov [r15+0x100], rax
0000748c59dced1e  jmp 0x0000748C59BFE110
0000748c59dced23  int3
0000748c59dced24  ucomisd xmm15, xmm14
0000748c59dced29  jp 0x0000748C59DCED38
0000748c59dced2b  movaps xmm13, [0x0000748C599FE030]
0000748c59dced33  jmp 0x0000748C59DCEB48
0000748c59dced38  vxorps xmm0, xmm15, xmm14
0000748c59dced3d  pextrw eax, xmm0, 0x03
0000748c59dced42  and eax, 0x7FF8
0000748c59dced47  cmp eax, 0x08
0000748c59dced4a  jnz 0x0000748C59DCEB48
0000748c59dced50  movq rax, xmm14
0000748c59dced55  shl rax, 0x0D
0000748c59dced59  jbe 0x0000748C59DCEB48
0000748c59dced5f  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dced67  jmp 0x0000748C59DCEB48
0000748c59dced6c  ucomisd xmm15, xmm14
0000748c59dced71  jp 0x0000748C59DCED80
0000748c59dced73  movaps xmm13, [0x0000748C599FE030]
0000748c59dced7b  jmp 0x0000748C59DCEB75
0000748c59dced80  vxorps xmm0, xmm15, xmm14
0000748c59dced85  pextrw eax, xmm0, 0x03
0000748c59dced8a  and eax, 0x7FF8
0000748c59dced8f  cmp eax, 0x08
0000748c59dced92  jnz 0x0000748C59DCEB75
0000748c59dced98  movq rax, xmm14
0000748c59dced9d  shl rax, 0x0D
0000748c59dceda1  jbe 0x0000748C59DCEB75
0000748c59dceda7  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dcedaf  jmp 0x0000748C59DCEB75
0000748c59dcedb4  ucomisd xmm15, xmm14
0000748c59dcedb9  jp 0x0000748C59DCEDC8
0000748c59dcedbb  movaps xmm13, [0x0000748C599FE030]
0000748c59dcedc3  jmp 0x0000748C59DCEBA2
0000748c59dcedc8  vxorps xmm0, xmm15, xmm14
0000748c59dcedcd  pextrw eax, xmm0, 0x03
0000748c59dcedd2  and eax, 0x7FF8
0000748c59dcedd7  cmp eax, 0x08
0000748c59dcedda  jnz 0x0000748C59DCEBA2
0000748c59dcede0  movq rax, xmm14
0000748c59dcede5  shl rax, 0x0D
0000748c59dcede9  jbe 0x0000748C59DCEBA2
0000748c59dcedef  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dcedf7  jmp 0x0000748C59DCEBA2
0000748c59dcedfc  ucomisd xmm15, xmm14
0000748c59dcee01  jp 0x0000748C59DCEE10
0000748c59dcee03  movaps xmm13, [0x0000748C599FE030]
0000748c59dcee0b  jmp 0x0000748C59DCEBCF
0000748c59dcee10  vxorps xmm0, xmm15, xmm14
0000748c59dcee15  pextrw eax, xmm0, 0x03
0000748c59dcee1a  and eax, 0x7FF8
0000748c59dcee1f  cmp eax, 0x08
0000748c59dcee22  jnz 0x0000748C59DCEBCF
0000748c59dcee28  movq rax, xmm14
0000748c59dcee2d  shl rax, 0x0D
0000748c59dcee31  jbe 0x0000748C59DCEBCF
0000748c59dcee37  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dcee3f  jmp 0x0000748C59DCEBCF
0000748c59dcee44  ucomisd xmm15, xmm14
0000748c59dcee49  jp 0x0000748C59DCEE58
0000748c59dcee4b  movaps xmm13, [0x0000748C599FE030]
0000748c59dcee53  jmp 0x0000748C59DCEBFC
0000748c59dcee58  vxorps xmm0, xmm15, xmm14
0000748c59dcee5d  pextrw eax, xmm0, 0x03
0000748c59dcee62  and eax, 0x7FF8
0000748c59dcee67  cmp eax, 0x08
0000748c59dcee6a  jnz 0x0000748C59DCEBFC
0000748c59dcee70  movq rax, xmm14
0000748c59dcee75  shl rax, 0x0D
0000748c59dcee79  jbe 0x0000748C59DCEBFC
0000748c59dcee7f  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dcee87  jmp 0x0000748C59DCEBFC
0000748c59dcee8c  ucomisd xmm15, xmm14
0000748c59dcee91  jp 0x0000748C59DCEEA0
0000748c59dcee93  movaps xmm13, [0x0000748C599FE030]
0000748c59dcee9b  jmp 0x0000748C59DCEC29
0000748c59dceea0  vxorps xmm0, xmm15, xmm14
0000748c59dceea5  pextrw eax, xmm0, 0x03
0000748c59dceeaa  and eax, 0x7FF8
0000748c59dceeaf  cmp eax, 0x08
0000748c59dceeb2  jnz 0x0000748C59DCEC29
0000748c59dceeb8  movq rax, xmm14
0000748c59dceebd  shl rax, 0x0D
0000748c59dceec1  jbe 0x0000748C59DCEC29
0000748c59dceec7  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dceecf  jmp 0x0000748C59DCEC29
0000748c59dceed4  ucomisd xmm15, xmm14
0000748c59dceed9  jp 0x0000748C59DCEEE8
0000748c59dceedb  movaps xmm13, [0x0000748C599FE030]
0000748c59dceee3  jmp 0x0000748C59DCEC56
0000748c59dceee8  vxorps xmm0, xmm15, xmm14
0000748c59dceeed  pextrw eax, xmm0, 0x03
0000748c59dceef2  and eax, 0x7FF8
0000748c59dceef7  cmp eax, 0x08
0000748c59dceefa  jnz 0x0000748C59DCEC56
0000748c59dcef00  movq rax, xmm14
0000748c59dcef05  shl rax, 0x0D
0000748c59dcef09  jbe 0x0000748C59DCEC56
0000748c59dcef0f  vorps xmm13, xmm14, [0x0000748C599FE040]
0000748c59dcef17  jmp 0x0000748C59DCEC56
0000748c59dcef1c  ucomisd xmm1, xmm15
0000748c59dcef21  jp 0x0000748C59DCEF30
0000748c59dcef23  movaps xmm14, [0x0000748C599FE030]
0000748c59dcef2b  jmp 0x0000748C59DCEC83
0000748c59dcef30  vxorps xmm0, xmm1, xmm15
0000748c59dcef35  pextrw eax, xmm0, 0x03
0000748c59dcef3a  and eax, 0x7FF8
0000748c59dcef3f  cmp eax, 0x08
0000748c59dcef42  jnz 0x0000748C59DCEC83
0000748c59dcef48  movq rax, xmm15
0000748c59dcef4d  shl rax, 0x0D
0000748c59dcef51  jbe 0x0000748C59DCEC83
0000748c59dcef57  vorps xmm14, xmm15, [0x0000748C599FE040]
0000748c59dcef5f  jmp 0x0000748C59DCEC83
0000748c59dcef64  int3
0000748c59dcef65  nop [rax+rax*1], ax
0000748c59dcef6e  nop
0000748c59dcef70  mov rax, [r15+0x20]
0000748c59dcef74  movaps xmm1, [r15+0x110]
0000748c59dcef7c  movq r14, xmm1
0000748c59dcef81  mov [r13+rax*1], r14
0000748c59dcef86  mov rax, [r15+0xF0]
0000748c59dcef8d  mov [r15+0x100], rax
0000748c59dcef94  jmp 0x0000748C59DCE5C0
0000748c59dcef99  int3
0000748c59dcef9a  call 0x0000748C59C0E120
0000748c59dcef9f  jmp 0x0000748C59DCEF86
0000748c59dcefa4  int3
0000748c59dcefa5  nop [rax+rax*1], ax
0000748c59dcefae  nop
0000748c59dcefb0  mov qword ptr [r15+0x100], 0x04
0000748c59dcefbb  mov esi, 0x00
0000748c59dcefc0  mov edx, 0x09
0000748c59dcefc5  mov rdi, 0x7FFE5A4ED040
0000748c59dcefcf  mov rax, 0x5DFD73962970
0000748c59dcefd9  call rax
0000748c59dcefdb  cmp dword ptr [r15+0x318], 0x00
0000748c59dcefe3  jnz 0x0000748C59BFE110
0000748c59dcefe9  jmp 0x0000748C59BFE0A0
0000748c59dcefee  int3
0000748c59dcefef  int3
