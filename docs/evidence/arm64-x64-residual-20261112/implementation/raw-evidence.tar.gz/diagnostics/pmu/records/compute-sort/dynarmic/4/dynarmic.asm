000076844abce69b  nop [rax+rax*1], eax
000076844abce6a0  mov rax, [r15+0xF8]
000076844abce6a7  lea r14, [rax-0x20]
000076844abce6ab  mov r12, [r15+0xF0]
000076844abce6b2  mov [r13+r14*1], r12
000076844abce6b7  mov [r15+0xF8], r14
000076844abce6be  lea r14, [rax-0x10]
000076844abce6c2  mov r12, [r15+0xA0]
000076844abce6c9  mov r11, [r15+0x98]
000076844abce6d0  mov [r13+r14*1], r12
000076844abce6d5  lea r14, [rax-0x08]
000076844abce6d9  mov [r13+r14*1], r11
000076844abce6de  mov qword ptr [r15+0xA0], 0x00
000076844abce6e9  mov qword ptr [r15+0x98], 0x4202A0
000076844abce6f4  mov eax, [r15+0xA0]
000076844abce6fb  lea r14d, [eax+0x11]
000076844abce700  mov r14d, r14d
000076844abce703  mov [r15], r14
000076844abce706  mov qword ptr [r15+0xF0], 0x410184
000076844abce711  mov r14d, [r15+0x320]
000076844abce718  mov eax, 0x410184
000076844abce71d  mov rcx, 0x76844ABCE800
000076844abce727  mov [r15+r14*8+0x328], rax
000076844abce72f  mov [r15+r14*8+0x368], rcx
000076844abce737  add r14d, 0x01
000076844abce73b  and r14d, 0x07
000076844abce73f  mov [r15+0x320], r14d
000076844abce746  cmp dword ptr [r15+0x318], 0x00
000076844abce74e  jz 0x000076844ABCE7A0
000076844abce754  nop [rax+rax*1], ax
000076844abce75d  nop [rax+rax*1], eax
000076844abce765  mov eax, 0x41021C
000076844abce76a  mov [r15+0x100], rax
000076844abce771  jmp 0x000076844A9FE110
000076844abce776  int3
000076844abce777  call 0x000076844AAE2CE0
000076844abce77c  jmp 0x000076844ABCE6B7
000076844abce781  call 0x000076844AAE2CE0
000076844abce786  jmp 0x000076844ABCE6D5
000076844abce78b  call 0x000076844AAE1A60
000076844abce790  jmp 0x000076844ABCE6DE
000076844abce795  int3
000076844abce796  nop [rax+rax*1], ax
000076844abce79f  nop
000076844abce7a0  mov eax, 0x846CA68B
000076844abce7a5  mov eax, eax
000076844abce7a7  mov [r15+0x48], rax
000076844abce7ab  mov eax, [r15]
000076844abce7ae  imul eax, eax, 0x7FEB352D
000076844abce7b4  mov [rsp+0x10], eax
000076844abce7b8  shr eax, 0x0F
000076844abce7bb  mov r14d, [rsp+0x10]
000076844abce7c0  xor r14d, eax
000076844abce7c3  imul r14d, r14d, 0x846CA68B
000076844abce7ca  mov [rsp+0x10], r14d
000076844abce7cf  mov r14d, r14d
000076844abce7d2  mov [r15+0x40], r14
000076844abce7d6  mov eax, [rsp+0x10]
000076844abce7da  shr eax, 0x10
000076844abce7dd  mov r14d, [rsp+0x10]
000076844abce7e2  xor r14d, eax
000076844abce7e5  mov r14d, r14d
000076844abce7e8  mov [r15], r14
000076844abce7eb  mov rax, [r15+0xF0]
000076844abce7f2  mov [r15+0x100], rax
000076844abce7f9  jmp 0x000076844ABCE5C0
000076844abce7fe  int3
000076844abce7ff  int3
000076844abce800  mov rax, [r15+0xA0]
000076844abce807  mov [rsp+0x10], rax
000076844abce80c  shl rax, 0x02
000076844abce810  mov r14, [r15+0x98]
000076844abce817  lea r12, [r14+rax*1]
000076844abce81b  mov eax, [r15]
000076844abce81e  mov [r13+r12*1], eax
000076844abce823  mov rax, [rsp+0x10]
000076844abce828  lea r14, [rax+0x01]
000076844abce82c  mov [r15+0xA0], r14
000076844abce833  xor eax, eax
000076844abce835  mov r12d, 0x400
000076844abce83b  cmp r14, r12
000076844abce83e  cmc
000076844abce83f  lahf
000076844abce840  seto al
000076844abce843  mov [r15+0x108], eax
000076844abce84a  mov eax, [r15+0x108]
000076844abce851  sahf
000076844abce852  jnz 0x000076844ABCE884
000076844abce854  cmp dword ptr [r15+0x318], 0x00
000076844abce85c  jz 0x000076844ABCE950
000076844abce862  nop [rax+rax*1], ax
000076844abce86b  nop [rax+rax*1], eax
000076844abce873  mov eax, 0x410194
000076844abce878  mov [r15+0x100], rax
000076844abce87f  jmp 0x000076844A9FE110
000076844abce884  cmp dword ptr [r15+0x318], 0x00
000076844abce88c  jz 0x000076844ABCE8C0
000076844abce892  nop [rax+rax*1], ax
000076844abce89b  nop [rax+rax*1], eax
000076844abce8a3  mov eax, 0x41017C
000076844abce8a8  mov [r15+0x100], rax
000076844abce8af  jmp 0x000076844A9FE110
000076844abce8b4  int3
000076844abce8b5  call 0x000076844AAB4B70
000076844abce8ba  jmp 0x000076844ABCE823
000076844abce8bf  int3
000076844abce8c0  mov eax, [r15+0xA0]
000076844abce8c7  lea r14d, [eax+0x11]
000076844abce8cc  mov r14d, r14d
000076844abce8cf  mov [r15], r14
000076844abce8d2  mov qword ptr [r15+0xF0], 0x410184
000076844abce8dd  mov r14d, [r15+0x320]
000076844abce8e4  mov eax, 0x410184
000076844abce8e9  mov rcx, 0x76844ABCE800
000076844abce8f3  mov [r15+r14*8+0x328], rax
000076844abce8fb  mov [r15+r14*8+0x368], rcx
000076844abce903  add r14d, 0x01
000076844abce907  and r14d, 0x07
000076844abce90b  mov [r15+0x320], r14d
000076844abce912  cmp dword ptr [r15+0x318], 0x00
000076844abce91a  jz 0x000076844ABCE7A0
000076844abce920  nop [rax+rax*1], ax
000076844abce929  nop [rax+rax*1], eax
000076844abce931  mov eax, 0x41021C
000076844abce936  mov [r15+0x100], rax
000076844abce93d  jmp 0x000076844A9FE110
000076844abce942  int3
000076844abce943  int3
000076844abce944  nop [rax+rax*1], ax
000076844abce94d  nop [rax], eax
000076844abce950  mov qword ptr [r15+0x40], 0x01
000076844abce958  cmp dword ptr [r15+0x318], 0x00
000076844abce960  jz 0x000076844ABCE990
000076844abce966  nop [rax+rax*1], ax
000076844abce96f  nop [rax+rax*1], eax
000076844abce977  mov eax, 0x4101B0
000076844abce97c  mov [r15+0x100], rax
000076844abce983  jmp 0x000076844A9FE110
000076844abce988  int3
000076844abce989  int3
000076844abce98a  nop [rax+rax*1], ax
000076844abce990  mov rax, [r15+0x40]
000076844abce994  mov [rsp+0x10], rax
000076844abce999  shl rax, 0x02
000076844abce99d  mov r14, [r15+0x98]
000076844abce9a4  lea r12, [r14+rax*1]
000076844abce9a8  mov eax, [r13+r12*1]
000076844abce9ad  mov [rsp+0x20], eax
000076844abce9b1  mov eax, eax
000076844abce9b3  mov [r15+0x48], rax
000076844abce9b7  mov rax, [rsp+0x10]
000076844abce9bc  mov [r15+0x50], rax
000076844abce9c0  mov eax, [r15+0x50]
000076844abce9c4  lea r12d, [eax-0x01]
000076844abce9c9  mov r12d, r12d
000076844abce9cc  mov [r15+0x58], r12
000076844abce9d0  mov rax, [r15+0x58]
000076844abce9d4  mov r12d, eax
000076844abce9d7  mov r12d, r12d
000076844abce9da  shl r12, 0x02
000076844abce9de  lea rax, [r14+r12*1]
000076844abce9e2  mov r14d, [r13+rax*1]
000076844abce9e7  mov [rsp+0x10], r14d
000076844abce9ec  mov r14d, r14d
000076844abce9ef  mov [r15+0x60], r14
000076844abce9f3  xor eax, eax
000076844abce9f5  mov r14d, [rsp+0x10]
000076844abce9fa  mov r12d, [rsp+0x20]
000076844abce9ff  cmp r14d, r12d
000076844abcea02  cmc
000076844abcea03  lahf
000076844abcea04  seto al
000076844abcea07  mov [r15+0x108], eax
000076844abcea0e  mov eax, [r15+0x108]
000076844abcea15  sahf
000076844abcea16  cmc
000076844abcea17  jbe 0x000076844ABCEA49
000076844abcea19  cmp dword ptr [r15+0x318], 0x00
000076844abcea21  jz 0x000076844ABCEA90
000076844abcea27  nop [rax+rax*1], ax
000076844abcea30  nop [rax+rax*1], eax
000076844abcea38  mov eax, 0x4101C8
000076844abcea3d  mov [r15+0x100], rax
000076844abcea44  jmp 0x000076844A9FE110
000076844abcea49  cmp dword ptr [r15+0x318], 0x00
000076844abcea51  jz 0x000076844ABCED30
000076844abcea57  nop [rax+rax*1], ax
000076844abcea60  nop [rax+rax*1], eax
000076844abcea68  mov eax, 0x4101A0
000076844abcea6d  mov [r15+0x100], rax
000076844abcea74  jmp 0x000076844A9FE110
000076844abcea79  int3
000076844abcea7a  call 0x000076844AAB4690
000076844abcea7f  jmp 0x000076844ABCE9AD
000076844abcea84  call 0x000076844AA0DAE0
000076844abcea89  jmp 0x000076844ABCE9E7
000076844abcea8e  int3
000076844abcea8f  nop
000076844abcea90  mov rax, [r15+0x50]
000076844abcea94  mov [rsp+0x10], rax
000076844abcea99  shl rax, 0x02
000076844abcea9d  mov r14, [r15+0x98]
000076844abceaa4  lea r12, [r14+rax*1]
000076844abceaa8  mov eax, [r15+0x60]
000076844abceaac  mov [r13+r12*1], eax
000076844abceab1  mov rax, [rsp+0x10]
000076844abceab6  lea r14, [rax-0x01]
000076844abceaba  mov [r15+0x50], r14
000076844abceabe  mov rax, [r15+0x58]
000076844abceac2  test rax, rax
000076844abceac5  setz al
000076844abceac8  movzx rax, al
000076844abceacc  mov [rsp+0x414], al
000076844abcead3  cmp byte ptr [rsp+0x414], 0x00
000076844abceadb  jz 0x000076844ABCEB0D
000076844abceadd  cmp dword ptr [r15+0x318], 0x00
000076844abceae5  jz 0x000076844ABCEB50
000076844abceaeb  nop [rax+rax*1], ax
000076844abceaf4  nop [rax+rax*1], eax
000076844abceafc  mov eax, 0x4101D4
000076844abceb01  mov [r15+0x100], rax
000076844abceb08  jmp 0x000076844A9FE110
000076844abceb0d  cmp dword ptr [r15+0x318], 0x00
000076844abceb15  jz 0x000076844ABCEC50
000076844abceb1b  nop [rax+rax*1], ax
000076844abceb24  nop [rax+rax*1], eax
000076844abceb2c  mov eax, 0x4101B8
000076844abceb31  mov [r15+0x100], rax
000076844abceb38  jmp 0x000076844A9FE110
000076844abceb3d  int3
000076844abceb3e  call 0x000076844AAB4B70
000076844abceb43  jmp 0x000076844ABCEAB1
000076844abceb48  int3
000076844abceb49  nop [rax], eax
000076844abceb50  cmp dword ptr [r15+0x318], 0x00
000076844abceb58  jz 0x000076844ABCEB90
000076844abceb5e  nop [rax+rax*1], ax
000076844abceb67  nop [rax+rax*1], eax
000076844abceb6f  mov eax, 0x41019C
000076844abceb74  mov [r15+0x100], rax
000076844abceb7b  jmp 0x000076844A9FE110
000076844abceb80  int3
000076844abceb81  int3
000076844abceb82  nop [rax+rax*1], ax
000076844abceb8b  nop [rax+rax*1], eax
000076844abceb90  mov qword ptr [r15+0x50], 0x00
000076844abceb98  mov rax, [r15+0x40]
000076844abceb9c  lea r14, [rax+0x01]
000076844abceba0  mov [r15+0x40], r14
000076844abceba4  mov rax, [r15+0x98]
000076844abcebab  mov r12d, [r15+0x48]
000076844abcebaf  mov [r13+rax*1], r12d
000076844abcebb4  xor eax, eax
000076844abcebb6  mov r12d, 0x400
000076844abcebbc  cmp r14, r12
000076844abcebbf  cmc
000076844abcebc0  lahf
000076844abcebc1  seto al
000076844abcebc4  mov [r15+0x108], eax
000076844abcebcb  mov eax, [r15+0x108]
000076844abcebd2  sahf
000076844abcebd3  jz 0x000076844ABCEC05
000076844abcebd5  cmp dword ptr [r15+0x318], 0x00
000076844abcebdd  jz 0x000076844ABCE990
000076844abcebe3  nop [rax+rax*1], ax
000076844abcebec  nop [rax+rax*1], eax
000076844abcebf4  mov eax, 0x4101B0
000076844abcebf9  mov [r15+0x100], rax
000076844abcec00  jmp 0x000076844A9FE110
000076844abcec05  cmp dword ptr [r15+0x318], 0x00
000076844abcec0d  jz 0x000076844ABCEDF0
000076844abcec13  nop [rax+rax*1], ax
000076844abcec1c  nop [rax+rax*1], eax
000076844abcec24  mov eax, 0x4101D8
000076844abcec29  mov [r15+0x100], rax
000076844abcec30  jmp 0x000076844A9FE110
000076844abcec35  int3
000076844abcec36  call 0x000076844AA0BAE0
000076844abcec3b  jmp 0x000076844ABCEBB4
000076844abcec40  int3
000076844abcec41  nop [rax+rax*1], ax
000076844abcec4a  nop [rax+rax*1], ax
000076844abcec50  mov eax, [r15+0x50]
000076844abcec54  lea r14d, [eax-0x01]
000076844abcec59  mov r14d, r14d
000076844abcec5c  mov [r15+0x58], r14
000076844abcec60  mov rax, [r15+0x58]
000076844abcec64  mov r14d, eax
000076844abcec67  mov r14d, r14d
000076844abcec6a  shl r14, 0x02
000076844abcec6e  mov rax, [r15+0x98]
000076844abcec75  lea r12, [rax+r14*1]
000076844abcec79  mov eax, [r13+r12*1]
000076844abcec7e  mov [rsp+0x10], eax
000076844abcec82  mov eax, eax
000076844abcec84  mov [r15+0x60], rax
000076844abcec88  mov eax, [r15+0x48]
000076844abcec8c  mov [rsp+0x20], eax
000076844abcec90  xor eax, eax
000076844abcec92  mov r14d, [rsp+0x10]
000076844abcec97  mov r12d, [rsp+0x20]
000076844abcec9c  cmp r14d, r12d
000076844abcec9f  cmc
000076844abceca0  lahf
000076844abceca1  seto al
000076844abceca4  mov [r15+0x108], eax
000076844abcecab  mov eax, [r15+0x108]
000076844abcecb2  sahf
000076844abcecb3  cmc
000076844abcecb4  jbe 0x000076844ABCECE6
000076844abcecb6  cmp dword ptr [r15+0x318], 0x00
000076844abcecbe  jz 0x000076844ABCEA90
000076844abcecc4  nop [rax+rax*1], ax
000076844abceccd  nop [rax+rax*1], eax
000076844abcecd5  mov eax, 0x4101C8
000076844abcecda  mov [r15+0x100], rax
000076844abcece1  jmp 0x000076844A9FE110
000076844abcece6  cmp dword ptr [r15+0x318], 0x00
000076844abcecee  jz 0x000076844ABCED30
000076844abcecf4  nop [rax+rax*1], ax
000076844abcecfd  nop [rax+rax*1], eax
000076844abced05  mov eax, 0x4101A0
000076844abced0a  mov [r15+0x100], rax
000076844abced11  jmp 0x000076844A9FE110
000076844abced16  int3
000076844abced17  call 0x000076844AAB4690
000076844abced1c  jmp 0x000076844ABCEC7E
000076844abced21  int3
000076844abced22  nop [rax+rax*1], ax
000076844abced2b  nop [rax+rax*1], eax
000076844abced30  mov rax, [r15+0x40]
000076844abced34  lea r14, [rax+0x01]
000076844abced38  mov [r15+0x40], r14
000076844abced3c  mov rax, [r15+0x50]
000076844abced40  mov r12d, eax
000076844abced43  mov r12d, r12d
000076844abced46  shl r12, 0x02
000076844abced4a  mov rax, [r15+0x98]
000076844abced51  lea r11, [rax+r12*1]
000076844abced55  mov eax, [r15+0x48]
000076844abced59  mov [r13+r11*1], eax
000076844abced5e  xor eax, eax
000076844abced60  mov r12d, 0x400
000076844abced66  cmp r14, r12
000076844abced69  cmc
000076844abced6a  lahf
000076844abced6b  seto al
000076844abced6e  mov [r15+0x108], eax
000076844abced75  mov eax, [r15+0x108]
000076844abced7c  sahf
000076844abced7d  jz 0x000076844ABCEDAF
000076844abced7f  cmp dword ptr [r15+0x318], 0x00
000076844abced87  jz 0x000076844ABCE990
000076844abced8d  nop [rax+rax*1], ax
000076844abced96  nop [rax+rax*1], eax
000076844abced9e  mov eax, 0x4101B0
000076844abceda3  mov [r15+0x100], rax
000076844abcedaa  jmp 0x000076844A9FE110
000076844abcedaf  cmp dword ptr [r15+0x318], 0x00
000076844abcedb7  jz 0x000076844ABCEDF0
000076844abcedbd  nop [rax+rax*1], ax
000076844abcedc6  nop [rax+rax*1], eax
000076844abcedce  mov eax, 0x4101D8
000076844abcedd3  mov [r15+0x100], rax
000076844abcedda  jmp 0x000076844A9FE110
000076844abceddf  int3
000076844abcede0  call 0x000076844AAA4270
000076844abcede5  jmp 0x000076844ABCED5E
000076844abcedea  int3
000076844abcedeb  nop [rax+rax*1], eax
000076844abcedf0  mov qword ptr [r15+0x40], 0x420000
000076844abcedf8  mov eax, 0x420288
000076844abcedfd  mov r14, [r13+rax*1]
000076844abcee02  mov rax, [r15+0x98]
000076844abcee09  mov r12d, [r13+rax*1]
000076844abcee0e  lea r11, [rax+0x04]
000076844abcee12  mov eax, [r13+r11*1]
000076844abcee17  mov r12d, r12d
000076844abcee1a  mov [r15+0x68], r12
000076844abcee1e  mov eax, eax
000076844abcee20  mov [r15+0x60], rax
000076844abcee24  mov rax, [r15+0x68]
000076844abcee28  mov [r15+0x68], rax
000076844abcee2c  mov qword ptr [r15+0x58], 0x02
000076844abcee34  mov [rsp+0x10], rax
000076844abcee39  xor eax, eax
000076844abcee3b  mov r12d, 0x02
000076844abcee41  mov r11d, 0x400
000076844abcee47  cmp r12, r11
000076844abcee4a  cmc
000076844abcee4b  lahf
000076844abcee4c  seto al
000076844abcee4f  mov [r15+0x108], eax
000076844abcee56  mov rax, [r15+0x60]
000076844abcee5a  mov r12d, 0x02
000076844abcee60  imul rax, r12
000076844abcee64  mov [r15+0x50], rax
000076844abcee68  mov rax, [rsp+0x10]
000076844abcee6d  lea r12, [rax+r14*1]
000076844abcee71  mov [r15+0x48], r12
000076844abcee75  mov eax, [r15+0x108]
000076844abcee7c  sahf
000076844abcee7d  jnz 0x000076844ABCEEAF
000076844abcee7f  cmp dword ptr [r15+0x318], 0x00
000076844abcee87  jz 0x000076844ABCF020
000076844abcee8d  nop [rax+rax*1], ax
000076844abcee96  nop [rax+rax*1], eax
000076844abcee9e  mov eax, 0x410208
000076844abceea3  mov [r15+0x100], rax
000076844abceeaa  jmp 0x000076844A9FE110
000076844abceeaf  cmp dword ptr [r15+0x318], 0x00
000076844abceeb7  jz 0x000076844ABCEF00
000076844abceebd  nop [rax+rax*1], ax
000076844abceec6  nop [rax+rax*1], eax
000076844abceece  mov eax, 0x4101E8
000076844abceed3  mov [r15+0x100], rax
000076844abceeda  jmp 0x000076844A9FE110
000076844abceedf  int3
000076844abceee0  call 0x000076844AA0DC20
000076844abceee5  jmp 0x000076844ABCEE02
000076844abceeea  call 0x000076844AA0B5E0
000076844abceeef  jmp 0x000076844ABCEE0E
000076844abceef4  call 0x000076844AAA3D90
000076844abceef9  jmp 0x000076844ABCEE17
000076844abceefe  int3
000076844abceeff  nop
000076844abcef00  mov rax, [r15+0x98]
000076844abcef07  mov r14, [r15+0x58]
000076844abcef0b  mov [rsp+0x10], r14
000076844abcef10  shl r14, 0x02
000076844abcef14  lea r12, [rax+r14*1]
000076844abcef18  mov eax, [r13+r12*1]
000076844abcef1d  lea r14, [r12+0x04]
000076844abcef22  mov r12d, [r13+r14*1]
000076844abcef27  mov eax, eax
000076844abcef29  mov [r15+0x68], rax
000076844abcef2d  mov r12d, r12d
000076844abcef30  mov [r15+0x60], r12
000076844abcef34  mov rax, [r15+0x68]
000076844abcef38  mov [rsp+0x20], rax
000076844abcef3d  mov r14, [rsp+0x10]
000076844abcef42  imul rax, r14
000076844abcef46  mov r12, [rsp+0x20]
000076844abcef4b  lea r11, [r12+rax*1]
000076844abcef4f  mov [r15+0x68], r11
000076844abcef53  lea rax, [r14+0x02]
000076844abcef57  mov [r15+0x58], rax
000076844abcef5b  mov [rsp+0x10], rax
000076844abcef60  xor eax, eax
000076844abcef62  mov r14, [rsp+0x10]
000076844abcef67  mov r12d, 0x400
000076844abcef6d  cmp r14, r12
000076844abcef70  cmc
000076844abcef71  lahf
000076844abcef72  seto al
000076844abcef75  mov [r15+0x108], eax
000076844abcef7c  mov rax, [r15+0x50]
000076844abcef80  mov r12, [r15+0x60]
000076844abcef84  imul r14, r12
000076844abcef88  lea r12, [rax+r14*1]
000076844abcef8c  mov [r15+0x50], r12
000076844abcef90  mov rax, [r15+0x48]
000076844abcef94  lea r14, [r11+rax*1]
000076844abcef98  mov [r15+0x48], r14
000076844abcef9c  mov eax, [r15+0x108]
000076844abcefa3  sahf
000076844abcefa4  jnz 0x000076844ABCEFD6
000076844abcefa6  cmp dword ptr [r15+0x318], 0x00
000076844abcefae  jz 0x000076844ABCF020
000076844abcefb4  nop [rax+rax*1], ax
000076844abcefbd  nop [rax+rax*1], eax
000076844abcefc5  mov eax, 0x410208
000076844abcefca  mov [r15+0x100], rax
000076844abcefd1  jmp 0x000076844A9FE110
000076844abcefd6  cmp dword ptr [r15+0x318], 0x00
000076844abcefde  jz 0x000076844ABCEF00
000076844abcefe4  nop [rax+rax*1], ax
000076844abcefed  nop [rax+rax*1], eax
000076844abceff5  mov eax, 0x4101E8
000076844abceffa  mov [r15+0x100], rax
000076844abcf001  jmp 0x000076844A9FE110
000076844abcf006  int3
000076844abcf007  call 0x000076844AAB4690
000076844abcf00c  jmp 0x000076844ABCEF1D
000076844abcf011  call 0x000076844AAE26A0
000076844abcf016  jmp 0x000076844ABCEF27
000076844abcf01b  int3
000076844abcf01c  nop [rax], eax
000076844abcf020  mov rax, [r15+0xF8]
000076844abcf027  lea r14, [rax+0x10]
000076844abcf02b  mov r12, [r13+r14*1]
000076844abcf030  lea r14, [rax+0x18]
000076844abcf034  mov r11, [r13+r14*1]
000076844abcf039  mov [r15+0xA0], r12
000076844abcf040  mov [r15+0x98], r11
000076844abcf047  mov r14, [r15+0x50]
000076844abcf04b  mov r12, [r15+0x48]
000076844abcf04f  lea r11, [r14+r12*1]
000076844abcf053  mov [r15+0x48], r11
000076844abcf057  mov r14, [r15+0x40]
000076844abcf05b  lea r12, [r14+0x288]
000076844abcf062  mov [r13+r12*1], r11
000076844abcf067  mov r14, [r13+rax*1]
000076844abcf06c  mov [r15+0xF0], r14
000076844abcf073  lea r12, [rax+0x20]
000076844abcf077  mov [r15+0xF8], r12
000076844abcf07e  mov [r15+0x100], r14
000076844abcf085  jmp 0x000076844ABCE5C0
000076844abcf08a  int3
000076844abcf08b  call 0x000076844AAE27E0
000076844abcf090  jmp 0x000076844ABCF030
000076844abcf095  call 0x000076844AAE1570
000076844abcf09a  jmp 0x000076844ABCF039
000076844abcf09f  call 0x000076844AAC0860
000076844abcf0a4  jmp 0x000076844ABCF067
000076844abcf0a9  call 0x000076844AA0DC20
000076844abcf0ae  jmp 0x000076844ABCF06C
000076844abcf0b3  int3
000076844abcf0b4  nop [rax+rax*1], ax
000076844abcf0bd  nop [rax], eax
000076844abcf0c0  mov qword ptr [r15+0x100], 0x04
000076844abcf0cb  mov esi, 0x00
000076844abcf0d0  mov edx, 0x09
000076844abcf0d5  mov rdi, 0x7FFDE541AC10
000076844abcf0df  mov rax, 0x5BF23FC0B970
000076844abcf0e9  call rax
000076844abcf0eb  cmp dword ptr [r15+0x318], 0x00
000076844abcf0f3  jnz 0x000076844A9FE110
000076844abcf0f9  jmp 0x000076844A9FE0A0
000076844abcf0fe  int3
000076844abcf0ff  int3
