00007ea2b75ce69b  nop [rax+rax*1], eax
00007ea2b75ce6a0  mov rax, [r15+0xF8]
00007ea2b75ce6a7  lea r14, [rax-0x20]
00007ea2b75ce6ab  mov r12, [r15+0xF0]
00007ea2b75ce6b2  mov [r13+r14*1], r12
00007ea2b75ce6b7  mov [r15+0xF8], r14
00007ea2b75ce6be  lea r14, [rax-0x10]
00007ea2b75ce6c2  mov r12, [r15+0xA0]
00007ea2b75ce6c9  mov r11, [r15+0x98]
00007ea2b75ce6d0  mov [r13+r14*1], r12
00007ea2b75ce6d5  lea r14, [rax-0x08]
00007ea2b75ce6d9  mov [r13+r14*1], r11
00007ea2b75ce6de  mov qword ptr [r15+0xA0], 0x00
00007ea2b75ce6e9  mov qword ptr [r15+0x98], 0x4202A0
00007ea2b75ce6f4  mov eax, [r15+0xA0]
00007ea2b75ce6fb  lea r14d, [eax+0x11]
00007ea2b75ce700  mov r14d, r14d
00007ea2b75ce703  mov [r15], r14
00007ea2b75ce706  mov qword ptr [r15+0xF0], 0x410184
00007ea2b75ce711  mov r14d, [r15+0x320]
00007ea2b75ce718  mov eax, 0x410184
00007ea2b75ce71d  mov rcx, 0x7EA2B75CE800
00007ea2b75ce727  mov [r15+r14*8+0x328], rax
00007ea2b75ce72f  mov [r15+r14*8+0x368], rcx
00007ea2b75ce737  add r14d, 0x01
00007ea2b75ce73b  and r14d, 0x07
00007ea2b75ce73f  mov [r15+0x320], r14d
00007ea2b75ce746  cmp dword ptr [r15+0x318], 0x00
00007ea2b75ce74e  jz 0x00007EA2B75CE7A0
00007ea2b75ce754  nop [rax+rax*1], ax
00007ea2b75ce75d  nop [rax+rax*1], eax
00007ea2b75ce765  mov eax, 0x41021C
00007ea2b75ce76a  mov [r15+0x100], rax
00007ea2b75ce771  jmp 0x00007EA2B73FE110
00007ea2b75ce776  int3
00007ea2b75ce777  call 0x00007EA2B74E2CE0
00007ea2b75ce77c  jmp 0x00007EA2B75CE6B7
00007ea2b75ce781  call 0x00007EA2B74E2CE0
00007ea2b75ce786  jmp 0x00007EA2B75CE6D5
00007ea2b75ce78b  call 0x00007EA2B74E1A60
00007ea2b75ce790  jmp 0x00007EA2B75CE6DE
00007ea2b75ce795  int3
00007ea2b75ce796  nop [rax+rax*1], ax
00007ea2b75ce79f  nop
00007ea2b75ce7a0  mov eax, 0x846CA68B
00007ea2b75ce7a5  mov eax, eax
00007ea2b75ce7a7  mov [r15+0x48], rax
00007ea2b75ce7ab  mov eax, [r15]
00007ea2b75ce7ae  imul eax, eax, 0x7FEB352D
00007ea2b75ce7b4  mov [rsp+0x10], eax
00007ea2b75ce7b8  shr eax, 0x0F
00007ea2b75ce7bb  mov r14d, [rsp+0x10]
00007ea2b75ce7c0  xor r14d, eax
00007ea2b75ce7c3  imul r14d, r14d, 0x846CA68B
00007ea2b75ce7ca  mov [rsp+0x10], r14d
00007ea2b75ce7cf  mov r14d, r14d
00007ea2b75ce7d2  mov [r15+0x40], r14
00007ea2b75ce7d6  mov eax, [rsp+0x10]
00007ea2b75ce7da  shr eax, 0x10
00007ea2b75ce7dd  mov r14d, [rsp+0x10]
00007ea2b75ce7e2  xor r14d, eax
00007ea2b75ce7e5  mov r14d, r14d
00007ea2b75ce7e8  mov [r15], r14
00007ea2b75ce7eb  mov rax, [r15+0xF0]
00007ea2b75ce7f2  mov [r15+0x100], rax
00007ea2b75ce7f9  jmp 0x00007EA2B75CE5C0
00007ea2b75ce7fe  int3
00007ea2b75ce7ff  int3
00007ea2b75ce800  mov rax, [r15+0xA0]
00007ea2b75ce807  mov [rsp+0x10], rax
00007ea2b75ce80c  shl rax, 0x02
00007ea2b75ce810  mov r14, [r15+0x98]
00007ea2b75ce817  lea r12, [r14+rax*1]
00007ea2b75ce81b  mov eax, [r15]
00007ea2b75ce81e  mov [r13+r12*1], eax
00007ea2b75ce823  mov rax, [rsp+0x10]
00007ea2b75ce828  lea r14, [rax+0x01]
00007ea2b75ce82c  mov [r15+0xA0], r14
00007ea2b75ce833  xor eax, eax
00007ea2b75ce835  mov r12d, 0x400
00007ea2b75ce83b  cmp r14, r12
00007ea2b75ce83e  cmc
00007ea2b75ce83f  lahf
00007ea2b75ce840  seto al
00007ea2b75ce843  mov [r15+0x108], eax
00007ea2b75ce84a  mov eax, [r15+0x108]
00007ea2b75ce851  sahf
00007ea2b75ce852  jnz 0x00007EA2B75CE884
00007ea2b75ce854  cmp dword ptr [r15+0x318], 0x00
00007ea2b75ce85c  jz 0x00007EA2B75CE950
00007ea2b75ce862  nop [rax+rax*1], ax
00007ea2b75ce86b  nop [rax+rax*1], eax
00007ea2b75ce873  mov eax, 0x410194
00007ea2b75ce878  mov [r15+0x100], rax
00007ea2b75ce87f  jmp 0x00007EA2B73FE110
00007ea2b75ce884  cmp dword ptr [r15+0x318], 0x00
00007ea2b75ce88c  jz 0x00007EA2B75CE8C0
00007ea2b75ce892  nop [rax+rax*1], ax
00007ea2b75ce89b  nop [rax+rax*1], eax
00007ea2b75ce8a3  mov eax, 0x41017C
00007ea2b75ce8a8  mov [r15+0x100], rax
00007ea2b75ce8af  jmp 0x00007EA2B73FE110
00007ea2b75ce8b4  int3
00007ea2b75ce8b5  call 0x00007EA2B74B4B70
00007ea2b75ce8ba  jmp 0x00007EA2B75CE823
00007ea2b75ce8bf  int3
00007ea2b75ce8c0  mov eax, [r15+0xA0]
00007ea2b75ce8c7  lea r14d, [eax+0x11]
00007ea2b75ce8cc  mov r14d, r14d
00007ea2b75ce8cf  mov [r15], r14
00007ea2b75ce8d2  mov qword ptr [r15+0xF0], 0x410184
00007ea2b75ce8dd  mov r14d, [r15+0x320]
00007ea2b75ce8e4  mov eax, 0x410184
00007ea2b75ce8e9  mov rcx, 0x7EA2B75CE800
00007ea2b75ce8f3  mov [r15+r14*8+0x328], rax
00007ea2b75ce8fb  mov [r15+r14*8+0x368], rcx
00007ea2b75ce903  add r14d, 0x01
00007ea2b75ce907  and r14d, 0x07
00007ea2b75ce90b  mov [r15+0x320], r14d
00007ea2b75ce912  cmp dword ptr [r15+0x318], 0x00
00007ea2b75ce91a  jz 0x00007EA2B75CE7A0
00007ea2b75ce920  nop [rax+rax*1], ax
00007ea2b75ce929  nop [rax+rax*1], eax
00007ea2b75ce931  mov eax, 0x41021C
00007ea2b75ce936  mov [r15+0x100], rax
00007ea2b75ce93d  jmp 0x00007EA2B73FE110
00007ea2b75ce942  int3
00007ea2b75ce943  int3
00007ea2b75ce944  nop [rax+rax*1], ax
00007ea2b75ce94d  nop [rax], eax
00007ea2b75ce950  mov qword ptr [r15+0x40], 0x01
00007ea2b75ce958  cmp dword ptr [r15+0x318], 0x00
00007ea2b75ce960  jz 0x00007EA2B75CE990
00007ea2b75ce966  nop [rax+rax*1], ax
00007ea2b75ce96f  nop [rax+rax*1], eax
00007ea2b75ce977  mov eax, 0x4101B0
00007ea2b75ce97c  mov [r15+0x100], rax
00007ea2b75ce983  jmp 0x00007EA2B73FE110
00007ea2b75ce988  int3
00007ea2b75ce989  int3
00007ea2b75ce98a  nop [rax+rax*1], ax
00007ea2b75ce990  mov rax, [r15+0x40]
00007ea2b75ce994  mov [rsp+0x10], rax
00007ea2b75ce999  shl rax, 0x02
00007ea2b75ce99d  mov r14, [r15+0x98]
00007ea2b75ce9a4  lea r12, [r14+rax*1]
00007ea2b75ce9a8  mov eax, [r13+r12*1]
00007ea2b75ce9ad  mov [rsp+0x20], eax
00007ea2b75ce9b1  mov eax, eax
00007ea2b75ce9b3  mov [r15+0x48], rax
00007ea2b75ce9b7  mov rax, [rsp+0x10]
00007ea2b75ce9bc  mov [r15+0x50], rax
00007ea2b75ce9c0  mov eax, [r15+0x50]
00007ea2b75ce9c4  lea r12d, [eax-0x01]
00007ea2b75ce9c9  mov r12d, r12d
00007ea2b75ce9cc  mov [r15+0x58], r12
00007ea2b75ce9d0  mov rax, [r15+0x58]
00007ea2b75ce9d4  mov r12d, eax
00007ea2b75ce9d7  mov r12d, r12d
00007ea2b75ce9da  shl r12, 0x02
00007ea2b75ce9de  lea rax, [r14+r12*1]
00007ea2b75ce9e2  mov r14d, [r13+rax*1]
00007ea2b75ce9e7  mov [rsp+0x10], r14d
00007ea2b75ce9ec  mov r14d, r14d
00007ea2b75ce9ef  mov [r15+0x60], r14
00007ea2b75ce9f3  xor eax, eax
00007ea2b75ce9f5  mov r14d, [rsp+0x10]
00007ea2b75ce9fa  mov r12d, [rsp+0x20]
00007ea2b75ce9ff  cmp r14d, r12d
00007ea2b75cea02  cmc
00007ea2b75cea03  lahf
00007ea2b75cea04  seto al
00007ea2b75cea07  mov [r15+0x108], eax
00007ea2b75cea0e  mov eax, [r15+0x108]
00007ea2b75cea15  sahf
00007ea2b75cea16  cmc
00007ea2b75cea17  jbe 0x00007EA2B75CEA49
00007ea2b75cea19  cmp dword ptr [r15+0x318], 0x00
00007ea2b75cea21  jz 0x00007EA2B75CEA90
00007ea2b75cea27  nop [rax+rax*1], ax
00007ea2b75cea30  nop [rax+rax*1], eax
00007ea2b75cea38  mov eax, 0x4101C8
00007ea2b75cea3d  mov [r15+0x100], rax
00007ea2b75cea44  jmp 0x00007EA2B73FE110
00007ea2b75cea49  cmp dword ptr [r15+0x318], 0x00
00007ea2b75cea51  jz 0x00007EA2B75CED30
00007ea2b75cea57  nop [rax+rax*1], ax
00007ea2b75cea60  nop [rax+rax*1], eax
00007ea2b75cea68  mov eax, 0x4101A0
00007ea2b75cea6d  mov [r15+0x100], rax
00007ea2b75cea74  jmp 0x00007EA2B73FE110
00007ea2b75cea79  int3
00007ea2b75cea7a  call 0x00007EA2B74B4690
00007ea2b75cea7f  jmp 0x00007EA2B75CE9AD
00007ea2b75cea84  call 0x00007EA2B740DAE0
00007ea2b75cea89  jmp 0x00007EA2B75CE9E7
00007ea2b75cea8e  int3
00007ea2b75cea8f  nop
00007ea2b75cea90  mov rax, [r15+0x50]
00007ea2b75cea94  mov [rsp+0x10], rax
00007ea2b75cea99  shl rax, 0x02
00007ea2b75cea9d  mov r14, [r15+0x98]
00007ea2b75ceaa4  lea r12, [r14+rax*1]
00007ea2b75ceaa8  mov eax, [r15+0x60]
00007ea2b75ceaac  mov [r13+r12*1], eax
00007ea2b75ceab1  mov rax, [rsp+0x10]
00007ea2b75ceab6  lea r14, [rax-0x01]
00007ea2b75ceaba  mov [r15+0x50], r14
00007ea2b75ceabe  mov rax, [r15+0x58]
00007ea2b75ceac2  test rax, rax
00007ea2b75ceac5  setz al
00007ea2b75ceac8  movzx rax, al
00007ea2b75ceacc  mov [rsp+0x414], al
00007ea2b75cead3  cmp byte ptr [rsp+0x414], 0x00
00007ea2b75ceadb  jz 0x00007EA2B75CEB0D
00007ea2b75ceadd  cmp dword ptr [r15+0x318], 0x00
00007ea2b75ceae5  jz 0x00007EA2B75CEB50
00007ea2b75ceaeb  nop [rax+rax*1], ax
00007ea2b75ceaf4  nop [rax+rax*1], eax
00007ea2b75ceafc  mov eax, 0x4101D4
00007ea2b75ceb01  mov [r15+0x100], rax
00007ea2b75ceb08  jmp 0x00007EA2B73FE110
00007ea2b75ceb0d  cmp dword ptr [r15+0x318], 0x00
00007ea2b75ceb15  jz 0x00007EA2B75CEC50
00007ea2b75ceb1b  nop [rax+rax*1], ax
00007ea2b75ceb24  nop [rax+rax*1], eax
00007ea2b75ceb2c  mov eax, 0x4101B8
00007ea2b75ceb31  mov [r15+0x100], rax
00007ea2b75ceb38  jmp 0x00007EA2B73FE110
00007ea2b75ceb3d  int3
00007ea2b75ceb3e  call 0x00007EA2B74B4B70
00007ea2b75ceb43  jmp 0x00007EA2B75CEAB1
00007ea2b75ceb48  int3
00007ea2b75ceb49  nop [rax], eax
00007ea2b75ceb50  cmp dword ptr [r15+0x318], 0x00
00007ea2b75ceb58  jz 0x00007EA2B75CEB90
00007ea2b75ceb5e  nop [rax+rax*1], ax
00007ea2b75ceb67  nop [rax+rax*1], eax
00007ea2b75ceb6f  mov eax, 0x41019C
00007ea2b75ceb74  mov [r15+0x100], rax
00007ea2b75ceb7b  jmp 0x00007EA2B73FE110
00007ea2b75ceb80  int3
00007ea2b75ceb81  int3
00007ea2b75ceb82  nop [rax+rax*1], ax
00007ea2b75ceb8b  nop [rax+rax*1], eax
00007ea2b75ceb90  mov qword ptr [r15+0x50], 0x00
00007ea2b75ceb98  mov rax, [r15+0x40]
00007ea2b75ceb9c  lea r14, [rax+0x01]
00007ea2b75ceba0  mov [r15+0x40], r14
00007ea2b75ceba4  mov rax, [r15+0x98]
00007ea2b75cebab  mov r12d, [r15+0x48]
00007ea2b75cebaf  mov [r13+rax*1], r12d
00007ea2b75cebb4  xor eax, eax
00007ea2b75cebb6  mov r12d, 0x400
00007ea2b75cebbc  cmp r14, r12
00007ea2b75cebbf  cmc
00007ea2b75cebc0  lahf
00007ea2b75cebc1  seto al
00007ea2b75cebc4  mov [r15+0x108], eax
00007ea2b75cebcb  mov eax, [r15+0x108]
00007ea2b75cebd2  sahf
00007ea2b75cebd3  jz 0x00007EA2B75CEC05
00007ea2b75cebd5  cmp dword ptr [r15+0x318], 0x00
00007ea2b75cebdd  jz 0x00007EA2B75CE990
00007ea2b75cebe3  nop [rax+rax*1], ax
00007ea2b75cebec  nop [rax+rax*1], eax
00007ea2b75cebf4  mov eax, 0x4101B0
00007ea2b75cebf9  mov [r15+0x100], rax
00007ea2b75cec00  jmp 0x00007EA2B73FE110
00007ea2b75cec05  cmp dword ptr [r15+0x318], 0x00
00007ea2b75cec0d  jz 0x00007EA2B75CEDF0
00007ea2b75cec13  nop [rax+rax*1], ax
00007ea2b75cec1c  nop [rax+rax*1], eax
00007ea2b75cec24  mov eax, 0x4101D8
00007ea2b75cec29  mov [r15+0x100], rax
00007ea2b75cec30  jmp 0x00007EA2B73FE110
00007ea2b75cec35  int3
00007ea2b75cec36  call 0x00007EA2B740BAE0
00007ea2b75cec3b  jmp 0x00007EA2B75CEBB4
00007ea2b75cec40  int3
00007ea2b75cec41  nop [rax+rax*1], ax
00007ea2b75cec4a  nop [rax+rax*1], ax
00007ea2b75cec50  mov eax, [r15+0x50]
00007ea2b75cec54  lea r14d, [eax-0x01]
00007ea2b75cec59  mov r14d, r14d
00007ea2b75cec5c  mov [r15+0x58], r14
00007ea2b75cec60  mov rax, [r15+0x58]
00007ea2b75cec64  mov r14d, eax
00007ea2b75cec67  mov r14d, r14d
00007ea2b75cec6a  shl r14, 0x02
00007ea2b75cec6e  mov rax, [r15+0x98]
00007ea2b75cec75  lea r12, [rax+r14*1]
00007ea2b75cec79  mov eax, [r13+r12*1]
00007ea2b75cec7e  mov [rsp+0x10], eax
00007ea2b75cec82  mov eax, eax
00007ea2b75cec84  mov [r15+0x60], rax
00007ea2b75cec88  mov eax, [r15+0x48]
00007ea2b75cec8c  mov [rsp+0x20], eax
00007ea2b75cec90  xor eax, eax
00007ea2b75cec92  mov r14d, [rsp+0x10]
00007ea2b75cec97  mov r12d, [rsp+0x20]
00007ea2b75cec9c  cmp r14d, r12d
00007ea2b75cec9f  cmc
00007ea2b75ceca0  lahf
00007ea2b75ceca1  seto al
00007ea2b75ceca4  mov [r15+0x108], eax
00007ea2b75cecab  mov eax, [r15+0x108]
00007ea2b75cecb2  sahf
00007ea2b75cecb3  cmc
00007ea2b75cecb4  jbe 0x00007EA2B75CECE6
00007ea2b75cecb6  cmp dword ptr [r15+0x318], 0x00
00007ea2b75cecbe  jz 0x00007EA2B75CEA90
00007ea2b75cecc4  nop [rax+rax*1], ax
00007ea2b75ceccd  nop [rax+rax*1], eax
00007ea2b75cecd5  mov eax, 0x4101C8
00007ea2b75cecda  mov [r15+0x100], rax
00007ea2b75cece1  jmp 0x00007EA2B73FE110
00007ea2b75cece6  cmp dword ptr [r15+0x318], 0x00
00007ea2b75cecee  jz 0x00007EA2B75CED30
00007ea2b75cecf4  nop [rax+rax*1], ax
00007ea2b75cecfd  nop [rax+rax*1], eax
00007ea2b75ced05  mov eax, 0x4101A0
00007ea2b75ced0a  mov [r15+0x100], rax
00007ea2b75ced11  jmp 0x00007EA2B73FE110
00007ea2b75ced16  int3
00007ea2b75ced17  call 0x00007EA2B74B4690
00007ea2b75ced1c  jmp 0x00007EA2B75CEC7E
00007ea2b75ced21  int3
00007ea2b75ced22  nop [rax+rax*1], ax
00007ea2b75ced2b  nop [rax+rax*1], eax
00007ea2b75ced30  mov rax, [r15+0x40]
00007ea2b75ced34  lea r14, [rax+0x01]
00007ea2b75ced38  mov [r15+0x40], r14
00007ea2b75ced3c  mov rax, [r15+0x50]
00007ea2b75ced40  mov r12d, eax
00007ea2b75ced43  mov r12d, r12d
00007ea2b75ced46  shl r12, 0x02
00007ea2b75ced4a  mov rax, [r15+0x98]
00007ea2b75ced51  lea r11, [rax+r12*1]
00007ea2b75ced55  mov eax, [r15+0x48]
00007ea2b75ced59  mov [r13+r11*1], eax
00007ea2b75ced5e  xor eax, eax
00007ea2b75ced60  mov r12d, 0x400
00007ea2b75ced66  cmp r14, r12
00007ea2b75ced69  cmc
00007ea2b75ced6a  lahf
00007ea2b75ced6b  seto al
00007ea2b75ced6e  mov [r15+0x108], eax
00007ea2b75ced75  mov eax, [r15+0x108]
00007ea2b75ced7c  sahf
00007ea2b75ced7d  jz 0x00007EA2B75CEDAF
00007ea2b75ced7f  cmp dword ptr [r15+0x318], 0x00
00007ea2b75ced87  jz 0x00007EA2B75CE990
00007ea2b75ced8d  nop [rax+rax*1], ax
00007ea2b75ced96  nop [rax+rax*1], eax
00007ea2b75ced9e  mov eax, 0x4101B0
00007ea2b75ceda3  mov [r15+0x100], rax
00007ea2b75cedaa  jmp 0x00007EA2B73FE110
00007ea2b75cedaf  cmp dword ptr [r15+0x318], 0x00
00007ea2b75cedb7  jz 0x00007EA2B75CEDF0
00007ea2b75cedbd  nop [rax+rax*1], ax
00007ea2b75cedc6  nop [rax+rax*1], eax
00007ea2b75cedce  mov eax, 0x4101D8
00007ea2b75cedd3  mov [r15+0x100], rax
00007ea2b75cedda  jmp 0x00007EA2B73FE110
00007ea2b75ceddf  int3
00007ea2b75cede0  call 0x00007EA2B74A4270
00007ea2b75cede5  jmp 0x00007EA2B75CED5E
00007ea2b75cedea  int3
00007ea2b75cedeb  nop [rax+rax*1], eax
00007ea2b75cedf0  mov qword ptr [r15+0x40], 0x420000
00007ea2b75cedf8  mov eax, 0x420288
00007ea2b75cedfd  mov r14, [r13+rax*1]
00007ea2b75cee02  mov rax, [r15+0x98]
00007ea2b75cee09  mov r12d, [r13+rax*1]
00007ea2b75cee0e  lea r11, [rax+0x04]
00007ea2b75cee12  mov eax, [r13+r11*1]
00007ea2b75cee17  mov r12d, r12d
00007ea2b75cee1a  mov [r15+0x68], r12
00007ea2b75cee1e  mov eax, eax
00007ea2b75cee20  mov [r15+0x60], rax
00007ea2b75cee24  mov rax, [r15+0x68]
00007ea2b75cee28  mov [r15+0x68], rax
00007ea2b75cee2c  mov qword ptr [r15+0x58], 0x02
00007ea2b75cee34  mov [rsp+0x10], rax
00007ea2b75cee39  xor eax, eax
00007ea2b75cee3b  mov r12d, 0x02
00007ea2b75cee41  mov r11d, 0x400
00007ea2b75cee47  cmp r12, r11
00007ea2b75cee4a  cmc
00007ea2b75cee4b  lahf
00007ea2b75cee4c  seto al
00007ea2b75cee4f  mov [r15+0x108], eax
00007ea2b75cee56  mov rax, [r15+0x60]
00007ea2b75cee5a  mov r12d, 0x02
00007ea2b75cee60  imul rax, r12
00007ea2b75cee64  mov [r15+0x50], rax
00007ea2b75cee68  mov rax, [rsp+0x10]
00007ea2b75cee6d  lea r12, [rax+r14*1]
00007ea2b75cee71  mov [r15+0x48], r12
00007ea2b75cee75  mov eax, [r15+0x108]
00007ea2b75cee7c  sahf
00007ea2b75cee7d  jnz 0x00007EA2B75CEEAF
00007ea2b75cee7f  cmp dword ptr [r15+0x318], 0x00
00007ea2b75cee87  jz 0x00007EA2B75CF020
00007ea2b75cee8d  nop [rax+rax*1], ax
00007ea2b75cee96  nop [rax+rax*1], eax
00007ea2b75cee9e  mov eax, 0x410208
00007ea2b75ceea3  mov [r15+0x100], rax
00007ea2b75ceeaa  jmp 0x00007EA2B73FE110
00007ea2b75ceeaf  cmp dword ptr [r15+0x318], 0x00
00007ea2b75ceeb7  jz 0x00007EA2B75CEF00
00007ea2b75ceebd  nop [rax+rax*1], ax
00007ea2b75ceec6  nop [rax+rax*1], eax
00007ea2b75ceece  mov eax, 0x4101E8
00007ea2b75ceed3  mov [r15+0x100], rax
00007ea2b75ceeda  jmp 0x00007EA2B73FE110
00007ea2b75ceedf  int3
00007ea2b75ceee0  call 0x00007EA2B740DC20
00007ea2b75ceee5  jmp 0x00007EA2B75CEE02
00007ea2b75ceeea  call 0x00007EA2B740B5E0
00007ea2b75ceeef  jmp 0x00007EA2B75CEE0E
00007ea2b75ceef4  call 0x00007EA2B74A3D90
00007ea2b75ceef9  jmp 0x00007EA2B75CEE17
00007ea2b75ceefe  int3
00007ea2b75ceeff  nop
00007ea2b75cef00  mov rax, [r15+0x98]
00007ea2b75cef07  mov r14, [r15+0x58]
00007ea2b75cef0b  mov [rsp+0x10], r14
00007ea2b75cef10  shl r14, 0x02
00007ea2b75cef14  lea r12, [rax+r14*1]
00007ea2b75cef18  mov eax, [r13+r12*1]
00007ea2b75cef1d  lea r14, [r12+0x04]
00007ea2b75cef22  mov r12d, [r13+r14*1]
00007ea2b75cef27  mov eax, eax
00007ea2b75cef29  mov [r15+0x68], rax
00007ea2b75cef2d  mov r12d, r12d
00007ea2b75cef30  mov [r15+0x60], r12
00007ea2b75cef34  mov rax, [r15+0x68]
00007ea2b75cef38  mov [rsp+0x20], rax
00007ea2b75cef3d  mov r14, [rsp+0x10]
00007ea2b75cef42  imul rax, r14
00007ea2b75cef46  mov r12, [rsp+0x20]
00007ea2b75cef4b  lea r11, [r12+rax*1]
00007ea2b75cef4f  mov [r15+0x68], r11
00007ea2b75cef53  lea rax, [r14+0x02]
00007ea2b75cef57  mov [r15+0x58], rax
00007ea2b75cef5b  mov [rsp+0x10], rax
00007ea2b75cef60  xor eax, eax
00007ea2b75cef62  mov r14, [rsp+0x10]
00007ea2b75cef67  mov r12d, 0x400
00007ea2b75cef6d  cmp r14, r12
00007ea2b75cef70  cmc
00007ea2b75cef71  lahf
00007ea2b75cef72  seto al
00007ea2b75cef75  mov [r15+0x108], eax
00007ea2b75cef7c  mov rax, [r15+0x50]
00007ea2b75cef80  mov r12, [r15+0x60]
00007ea2b75cef84  imul r14, r12
00007ea2b75cef88  lea r12, [rax+r14*1]
00007ea2b75cef8c  mov [r15+0x50], r12
00007ea2b75cef90  mov rax, [r15+0x48]
00007ea2b75cef94  lea r14, [r11+rax*1]
00007ea2b75cef98  mov [r15+0x48], r14
00007ea2b75cef9c  mov eax, [r15+0x108]
00007ea2b75cefa3  sahf
00007ea2b75cefa4  jnz 0x00007EA2B75CEFD6
00007ea2b75cefa6  cmp dword ptr [r15+0x318], 0x00
00007ea2b75cefae  jz 0x00007EA2B75CF020
00007ea2b75cefb4  nop [rax+rax*1], ax
00007ea2b75cefbd  nop [rax+rax*1], eax
00007ea2b75cefc5  mov eax, 0x410208
00007ea2b75cefca  mov [r15+0x100], rax
00007ea2b75cefd1  jmp 0x00007EA2B73FE110
00007ea2b75cefd6  cmp dword ptr [r15+0x318], 0x00
00007ea2b75cefde  jz 0x00007EA2B75CEF00
00007ea2b75cefe4  nop [rax+rax*1], ax
00007ea2b75cefed  nop [rax+rax*1], eax
00007ea2b75ceff5  mov eax, 0x4101E8
00007ea2b75ceffa  mov [r15+0x100], rax
00007ea2b75cf001  jmp 0x00007EA2B73FE110
00007ea2b75cf006  int3
00007ea2b75cf007  call 0x00007EA2B74B4690
00007ea2b75cf00c  jmp 0x00007EA2B75CEF1D
00007ea2b75cf011  call 0x00007EA2B74E26A0
00007ea2b75cf016  jmp 0x00007EA2B75CEF27
00007ea2b75cf01b  int3
00007ea2b75cf01c  nop [rax], eax
00007ea2b75cf020  mov rax, [r15+0xF8]
00007ea2b75cf027  lea r14, [rax+0x10]
00007ea2b75cf02b  mov r12, [r13+r14*1]
00007ea2b75cf030  lea r14, [rax+0x18]
00007ea2b75cf034  mov r11, [r13+r14*1]
00007ea2b75cf039  mov [r15+0xA0], r12
00007ea2b75cf040  mov [r15+0x98], r11
00007ea2b75cf047  mov r14, [r15+0x50]
00007ea2b75cf04b  mov r12, [r15+0x48]
00007ea2b75cf04f  lea r11, [r14+r12*1]
00007ea2b75cf053  mov [r15+0x48], r11
00007ea2b75cf057  mov r14, [r15+0x40]
00007ea2b75cf05b  lea r12, [r14+0x288]
00007ea2b75cf062  mov [r13+r12*1], r11
00007ea2b75cf067  mov r14, [r13+rax*1]
00007ea2b75cf06c  mov [r15+0xF0], r14
00007ea2b75cf073  lea r12, [rax+0x20]
00007ea2b75cf077  mov [r15+0xF8], r12
00007ea2b75cf07e  mov [r15+0x100], r14
00007ea2b75cf085  jmp 0x00007EA2B75CE5C0
00007ea2b75cf08a  int3
00007ea2b75cf08b  call 0x00007EA2B74E27E0
00007ea2b75cf090  jmp 0x00007EA2B75CF030
00007ea2b75cf095  call 0x00007EA2B74E1570
00007ea2b75cf09a  jmp 0x00007EA2B75CF039
00007ea2b75cf09f  call 0x00007EA2B74C0860
00007ea2b75cf0a4  jmp 0x00007EA2B75CF067
00007ea2b75cf0a9  call 0x00007EA2B740DC20
00007ea2b75cf0ae  jmp 0x00007EA2B75CF06C
00007ea2b75cf0b3  int3
00007ea2b75cf0b4  nop [rax+rax*1], ax
00007ea2b75cf0bd  nop [rax], eax
00007ea2b75cf0c0  mov qword ptr [r15+0x100], 0x04
00007ea2b75cf0cb  mov esi, 0x00
00007ea2b75cf0d0  mov edx, 0x09
00007ea2b75cf0d5  mov rdi, 0x7FFFCA6E4E90
00007ea2b75cf0df  mov rax, 0x5F14F3D0B970
00007ea2b75cf0e9  call rax
00007ea2b75cf0eb  cmp dword ptr [r15+0x318], 0x00
00007ea2b75cf0f3  jnz 0x00007EA2B73FE110
00007ea2b75cf0f9  jmp 0x00007EA2B73FE0A0
00007ea2b75cf0fe  int3
00007ea2b75cf0ff  int3
