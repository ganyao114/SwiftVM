000078aa2d3ce69b  nop [rax+rax*1], eax
000078aa2d3ce6a0  mov qword ptr [r15+0x20], 0x420060
000078aa2d3ce6a8  mov qword ptr [r15], 0x03
000078aa2d3ce6af  xor eax, eax
000078aa2d3ce6b1  mov r14d, 0xB71B00
000078aa2d3ce6b7  mov r12d, 0x01
000078aa2d3ce6bd  sub r14, r12
000078aa2d3ce6c0  cmc
000078aa2d3ce6c1  lahf
000078aa2d3ce6c2  seto al
000078aa2d3ce6c5  mov [r15+0x108], eax
000078aa2d3ce6cc  mov [r15+0x08], r14
000078aa2d3ce6d0  mov eax, [r15+0x108]
000078aa2d3ce6d7  sahf
000078aa2d3ce6d8  jnz 0x000078AA2D3CE70A
000078aa2d3ce6da  cmp dword ptr [r15+0x318], 0x00
000078aa2d3ce6e2  jz 0x000078AA2D3CE7F0
000078aa2d3ce6e8  nop [rax+rax*1], ax
000078aa2d3ce6f1  nop [rax+rax*1], eax
000078aa2d3ce6f9  mov eax, 0x41004C
000078aa2d3ce6fe  mov [r15+0x100], rax
000078aa2d3ce705  jmp 0x000078AA2D1FE110
000078aa2d3ce70a  cmp dword ptr [r15+0x318], 0x00
000078aa2d3ce712  jz 0x000078AA2D3CE740
000078aa2d3ce718  nop [rax+rax*1], ax
000078aa2d3ce721  nop [rax+rax*1], eax
000078aa2d3ce729  mov eax, 0x41003C
000078aa2d3ce72e  mov [r15+0x100], rax
000078aa2d3ce735  jmp 0x000078AA2D1FE110
000078aa2d3ce73a  int3
000078aa2d3ce73b  int3
000078aa2d3ce73c  nop [rax], eax
000078aa2d3ce740  mov rax, [r15]
000078aa2d3ce743  lea r14, [rax+0x03]
000078aa2d3ce747  mov [rsp+0x10], r14
000078aa2d3ce74c  shr r14, 0x07
000078aa2d3ce750  mov rax, [rsp+0x10]
000078aa2d3ce755  xor rax, r14
000078aa2d3ce758  mov [r15], rax
000078aa2d3ce75b  mov rax, [r15+0x08]
000078aa2d3ce75f  mov [rsp+0x10], rax
000078aa2d3ce764  xor eax, eax
000078aa2d3ce766  mov r14, [rsp+0x10]
000078aa2d3ce76b  mov r12d, 0x01
000078aa2d3ce771  sub r14, r12
000078aa2d3ce774  cmc
000078aa2d3ce775  lahf
000078aa2d3ce776  seto al
000078aa2d3ce779  mov [r15+0x108], eax
000078aa2d3ce780  mov [r15+0x08], r14
000078aa2d3ce784  mov eax, [r15+0x108]
000078aa2d3ce78b  sahf
000078aa2d3ce78c  jnz 0x000078AA2D3CE7BE
000078aa2d3ce78e  cmp dword ptr [r15+0x318], 0x00
000078aa2d3ce796  jz 0x000078AA2D3CE7F0
000078aa2d3ce79c  nop [rax+rax*1], ax
000078aa2d3ce7a5  nop [rax+rax*1], eax
000078aa2d3ce7ad  mov eax, 0x41004C
000078aa2d3ce7b2  mov [r15+0x100], rax
000078aa2d3ce7b9  jmp 0x000078AA2D1FE110
000078aa2d3ce7be  cmp dword ptr [r15+0x318], 0x00
000078aa2d3ce7c6  jz 0x000078AA2D3CE740
000078aa2d3ce7cc  nop [rax+rax*1], ax
000078aa2d3ce7d5  nop [rax+rax*1], eax
000078aa2d3ce7dd  mov eax, 0x41003C
000078aa2d3ce7e2  mov [r15+0x100], rax
000078aa2d3ce7e9  jmp 0x000078AA2D1FE110
000078aa2d3ce7ee  int3
000078aa2d3ce7ef  int3
000078aa2d3ce7f0  mov rax, [r15+0x20]
000078aa2d3ce7f4  mov r14, [r15]
000078aa2d3ce7f7  mov [r13+rax*1], r14
000078aa2d3ce7fc  mov rax, [r15+0xF0]
000078aa2d3ce803  mov [r15+0x100], rax
000078aa2d3ce80a  jmp 0x000078AA2D3CE5C0
000078aa2d3ce80f  int3
000078aa2d3ce810  call 0x000078AA2D20E120
000078aa2d3ce815  jmp 0x000078AA2D3CE7FC
000078aa2d3ce81a  int3
000078aa2d3ce81b  nop [rax+rax*1], eax
000078aa2d3ce820  mov qword ptr [r15+0x100], 0x04
000078aa2d3ce82b  mov esi, 0x00
000078aa2d3ce830  mov edx, 0x09
000078aa2d3ce835  mov rdi, 0x7FFE0BDB03D0
000078aa2d3ce83f  mov rax, 0x5FE0AF7FA970
000078aa2d3ce849  call rax
000078aa2d3ce84b  cmp dword ptr [r15+0x318], 0x00
000078aa2d3ce853  jnz 0x000078AA2D1FE110
000078aa2d3ce859  jmp 0x000078AA2D1FE0A0
000078aa2d3ce85e  int3
000078aa2d3ce85f  int3
