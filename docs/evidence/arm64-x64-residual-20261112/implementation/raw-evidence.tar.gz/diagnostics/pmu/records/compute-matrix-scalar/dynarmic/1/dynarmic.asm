0000703dbfbce69b  nop [rax+rax*1], eax
0000703dbfbce6a0  mov qword ptr [r15+0x40], 0x4201C0
0000703dbfbce6a8  mov qword ptr [r15+0x48], 0x4203C0
0000703dbfbce6b0  mov qword ptr [r15+0x60], 0x01
0000703dbfbce6b8  xorps xmm1, xmm1
0000703dbfbce6bb  mov eax, 0x41
0000703dbfbce6c0  vcvtusi2sd xmm1, xmm1, eax
0000703dbfbce6c6  mulsd xmm1, [0x0000703DBF7FE010]
0000703dbfbce6ce  movq xmm1, xmm1
0000703dbfbce6d2  movaps [r15+0x120], xmm1
0000703dbfbce6da  mov eax, [r15+0x60]
0000703dbfbce6de  xorps xmm15, xmm15
0000703dbfbce6e2  vcvtusi2sd xmm15, xmm15, eax
0000703dbfbce6e8  mulsd xmm15, [0x0000703DBF7FE020]
0000703dbfbce6f1  movq xmm15, xmm15
0000703dbfbce6f6  movaps [r15+0x110], xmm15
0000703dbfbce6fe  mov rax, [r15+0x60]
0000703dbfbce702  mov [rsp+0x10], rax
0000703dbfbce707  xor eax, eax
0000703dbfbce709  mov r14, [rsp+0x10]
0000703dbfbce70e  mov r12d, 0x40
0000703dbfbce714  cmp r14, r12
0000703dbfbce717  cmc
0000703dbfbce718  lahf
0000703dbfbce719  seto al
0000703dbfbce71c  mov [r15+0x108], eax
0000703dbfbce723  mov qword ptr [r15+0x50], 0x40
0000703dbfbce72b  movq rax, xmm1
0000703dbfbce730  mov r12d, 0x4203C0
0000703dbfbce736  mov [r13+r12*1], rax
0000703dbfbce73b  movq rax, xmm15
0000703dbfbce740  mov r12d, 0x4201C0
0000703dbfbce746  mov [r13+r12*1], rax
0000703dbfbce74b  mov [r15+0x58], r14
0000703dbfbce74f  mov eax, [r15+0x108]
0000703dbfbce756  sahf
0000703dbfbce757  jnz 0x0000703DBFBCE789
0000703dbfbce759  cmp dword ptr [r15+0x318], 0x00
0000703dbfbce761  jz 0x0000703DBFBCE910
0000703dbfbce767  nop [rax+rax*1], ax
0000703dbfbce770  nop [rax+rax*1], eax
0000703dbfbce778  mov eax, 0x410074
0000703dbfbce77d  mov [r15+0x100], rax
0000703dbfbce784  jmp 0x0000703DBF9FE110
0000703dbfbce789  cmp dword ptr [r15+0x318], 0x00
0000703dbfbce791  jz 0x0000703DBFBCE7D0
0000703dbfbce797  nop [rax+rax*1], ax
0000703dbfbce7a0  nop [rax+rax*1], eax
0000703dbfbce7a8  mov eax, 0x41004C
0000703dbfbce7ad  mov [r15+0x100], rax
0000703dbfbce7b4  jmp 0x0000703DBF9FE110
0000703dbfbce7b9  int3
0000703dbfbce7ba  call 0x0000703DBFAB4CB0
0000703dbfbce7bf  jmp 0x0000703DBFBCE73B
0000703dbfbce7c4  call 0x0000703DBFAB4CB0
0000703dbfbce7c9  jmp 0x0000703DBFBCE74B
0000703dbfbce7ce  int3
0000703dbfbce7cf  nop
0000703dbfbce7d0  mov rax, [r15+0x58]
0000703dbfbce7d4  lea r14, [rax+0x01]
0000703dbfbce7d8  mov [r15+0x60], r14
0000703dbfbce7dc  mov r14d, [r15+0x50]
0000703dbfbce7e0  xorps xmm1, xmm1
0000703dbfbce7e3  vcvtusi2sd xmm1, xmm1, r14d
0000703dbfbce7e9  mulsd xmm1, [0x0000703DBF7FE010]
0000703dbfbce7f1  movq xmm1, xmm1
0000703dbfbce7f5  movaps [r15+0x120], xmm1
0000703dbfbce7fd  rorx r12, rax, 0x3D
0000703dbfbce803  and r12, 0xFFFFFFFFFFFFFFF8
0000703dbfbce807  mov eax, [r15+0x60]
0000703dbfbce80b  xorps xmm15, xmm15
0000703dbfbce80f  vcvtusi2sd xmm15, xmm15, eax
0000703dbfbce815  mulsd xmm15, [0x0000703DBF7FE020]
0000703dbfbce81e  movq xmm15, xmm15
0000703dbfbce823  movaps [r15+0x110], xmm15
0000703dbfbce82b  mov rax, [r15+0x60]
0000703dbfbce82f  mov [rsp+0x10], rax
0000703dbfbce834  xor eax, eax
0000703dbfbce836  mov r11, [rsp+0x10]
0000703dbfbce83b  mov r10d, 0x40
0000703dbfbce841  cmp r11, r10
0000703dbfbce844  cmc
0000703dbfbce845  lahf
0000703dbfbce846  seto al
0000703dbfbce849  mov [r15+0x108], eax
0000703dbfbce850  lea eax, [r14d-0x01]
0000703dbfbce855  mov eax, eax
0000703dbfbce857  mov [r15+0x50], rax
0000703dbfbce85b  mov rax, [r15+0x48]
0000703dbfbce85f  lea r14, [rax+r12*1]
0000703dbfbce863  movq rax, xmm1
0000703dbfbce868  mov [r13+r14*1], rax
0000703dbfbce86d  mov rax, [r15+0x40]
0000703dbfbce871  lea r14, [rax+r12*1]
0000703dbfbce875  movq rax, xmm15
0000703dbfbce87a  mov [r13+r14*1], rax
0000703dbfbce87f  mov [r15+0x58], r11
0000703dbfbce883  mov eax, [r15+0x108]
0000703dbfbce88a  sahf
0000703dbfbce88b  jnz 0x0000703DBFBCE8BD
0000703dbfbce88d  cmp dword ptr [r15+0x318], 0x00
0000703dbfbce895  jz 0x0000703DBFBCE910
0000703dbfbce89b  nop [rax+rax*1], ax
0000703dbfbce8a4  nop [rax+rax*1], eax
0000703dbfbce8ac  mov eax, 0x410074
0000703dbfbce8b1  mov [r15+0x100], rax
0000703dbfbce8b8  jmp 0x0000703DBF9FE110
0000703dbfbce8bd  cmp dword ptr [r15+0x318], 0x00
0000703dbfbce8c5  jz 0x0000703DBFBCE7D0
0000703dbfbce8cb  nop [rax+rax*1], ax
0000703dbfbce8d4  nop [rax+rax*1], eax
0000703dbfbce8dc  mov eax, 0x41004C
0000703dbfbce8e1  mov [r15+0x100], rax
0000703dbfbce8e8  jmp 0x0000703DBF9FE110
0000703dbfbce8ed  int3
0000703dbfbce8ee  call 0x0000703DBFAD5EB0
0000703dbfbce8f3  jmp 0x0000703DBFBCE86D
0000703dbfbce8f8  call 0x0000703DBFAD5EB0
0000703dbfbce8fd  jmp 0x0000703DBFBCE87F
0000703dbfbce902  int3
0000703dbfbce903  nop [rax+rax*1], ax
0000703dbfbce90c  nop [rax], eax
0000703dbfbce910  vxorps xmm1, xmm1, xmm1
0000703dbfbce914  movq xmm1, xmm1
0000703dbfbce918  movaps [r15+0x110], xmm1
0000703dbfbce920  mov qword ptr [r15+0x58], 0x00
0000703dbfbce928  mov qword ptr [r15+0x50], 0x4205C0
0000703dbfbce930  mov qword ptr [r15+0x60], 0x00
0000703dbfbce938  mov qword ptr [r15+0x68], 0x4205C0
0000703dbfbce940  mov rax, [r15+0x40]
0000703dbfbce944  mov r14, [r13+rax*1]
0000703dbfbce949  lea r12, [rax+0x08]
0000703dbfbce94d  mov r11, [r13+r12*1]
0000703dbfbce952  movq xmm15, r14
0000703dbfbce957  movq xmm14, r11
0000703dbfbce95c  movq xmm15, xmm15
0000703dbfbce961  movq xmm15, xmm15
0000703dbfbce966  movaps [r15+0x120], xmm15
0000703dbfbce96e  movq xmm14, xmm14
0000703dbfbce973  movq xmm14, xmm14
0000703dbfbce978  movaps [r15+0x130], xmm14
0000703dbfbce980  lea r14, [rax+0x10]
0000703dbfbce984  mov r12, [r13+r14*1]
0000703dbfbce989  lea r14, [rax+0x18]
0000703dbfbce98d  mov r11, [r13+r14*1]
0000703dbfbce992  movq xmm15, r12
0000703dbfbce997  movq xmm14, r11
0000703dbfbce99c  movq xmm15, xmm15
0000703dbfbce9a1  movq xmm15, xmm15
0000703dbfbce9a6  movaps [r15+0x140], xmm15
0000703dbfbce9ae  movq xmm14, xmm14
0000703dbfbce9b3  movq xmm14, xmm14
0000703dbfbce9b8  movaps [r15+0x150], xmm14
0000703dbfbce9c0  lea r14, [rax+0x20]
0000703dbfbce9c4  mov r12, [r13+r14*1]
0000703dbfbce9c9  lea r14, [rax+0x28]
0000703dbfbce9cd  mov r11, [r13+r14*1]
0000703dbfbce9d2  movq xmm15, r12
0000703dbfbce9d7  movq xmm14, r11
0000703dbfbce9dc  movq xmm15, xmm15
0000703dbfbce9e1  movq xmm15, xmm15
0000703dbfbce9e6  movaps [r15+0x160], xmm15
0000703dbfbce9ee  movq xmm14, xmm14
0000703dbfbce9f3  movq xmm14, xmm14
0000703dbfbce9f8  movaps [r15+0x170], xmm14
0000703dbfbcea00  lea r14, [rax+0x30]
0000703dbfbcea04  mov r12, [r13+r14*1]
0000703dbfbcea09  lea r14, [rax+0x38]
0000703dbfbcea0d  mov rax, [r13+r14*1]
0000703dbfbcea12  movq xmm15, r12
0000703dbfbcea17  movq xmm14, rax
0000703dbfbcea1c  movq xmm15, xmm15
0000703dbfbcea21  movq xmm15, xmm15
0000703dbfbcea26  movaps [r15+0x180], xmm15
0000703dbfbcea2e  movq xmm14, xmm14
0000703dbfbcea33  movq xmm14, xmm14
0000703dbfbcea38  movaps [r15+0x210], xmm14
0000703dbfbcea40  mov rax, [r15+0x48]
0000703dbfbcea44  mov [r15+0x78], rax
0000703dbfbcea48  mov r14, [r13+rax*1]
0000703dbfbcea4d  movq xmm15, r14
0000703dbfbcea52  lea r14, [rax+0x40]
0000703dbfbcea56  mov r12, [r13+r14*1]
0000703dbfbcea5b  movq xmm14, r12
0000703dbfbcea60  lea r14, [rax+0x80]
0000703dbfbcea67  mov r12, [r13+r14*1]
0000703dbfbcea6c  movq xmm13, r12
0000703dbfbcea71  movaps xmm12, [r15+0x120]
0000703dbfbcea79  movq r14, xmm12
0000703dbfbcea7e  movq r12, xmm15
0000703dbfbcea83  vmovq xmm15, r14
0000703dbfbcea88  vmovq xmm12, r12
0000703dbfbcea8d  movaps xmm11, xmm15
0000703dbfbcea91  mulsd xmm11, xmm12
0000703dbfbcea96  ucomisd xmm11, xmm11
0000703dbfbcea9b  jp 0x0000703DBFBCEEFC
0000703dbfbceaa1  movq xmm11, xmm11
0000703dbfbceaa6  movaps xmm15, [r15+0x130]
0000703dbfbceaae  movq r14, xmm15
0000703dbfbceab3  movq r12, xmm14
0000703dbfbceab8  vmovq xmm15, r14
0000703dbfbceabd  vmovq xmm14, r12
0000703dbfbceac2  movaps xmm12, xmm15
0000703dbfbceac6  mulsd xmm12, xmm14
0000703dbfbceacb  ucomisd xmm12, xmm12
0000703dbfbcead0  jp 0x0000703DBFBCEF48
0000703dbfbcead6  movq xmm12, xmm12
0000703dbfbceadb  movq r14, xmm11
0000703dbfbceae0  movq r12, xmm1
0000703dbfbceae5  vmovq xmm1, r14
0000703dbfbceaea  vmovq xmm15, r12
0000703dbfbceaef  movaps xmm14, xmm1
0000703dbfbceaf3  addsd xmm14, xmm15
0000703dbfbceaf8  ucomisd xmm14, xmm14
0000703dbfbceafd  jp 0x0000703DBFBCEF94
0000703dbfbceb03  movq xmm14, xmm14
0000703dbfbceb08  movq r14, xmm14
0000703dbfbceb0d  movq r12, xmm12
0000703dbfbceb12  vmovq xmm1, r14
0000703dbfbceb17  vmovq xmm15, r12
0000703dbfbceb1c  movaps xmm14, xmm1
0000703dbfbceb20  addsd xmm14, xmm15
0000703dbfbceb25  ucomisd xmm14, xmm14
0000703dbfbceb2a  jp 0x0000703DBFBCEFE0
0000703dbfbceb30  movq xmm14, xmm14
0000703dbfbceb35  movaps xmm1, [r15+0x140]
0000703dbfbceb3d  movq r14, xmm1
0000703dbfbceb42  movq r12, xmm13
0000703dbfbceb47  vmovq xmm1, r14
0000703dbfbceb4c  vmovq xmm15, r12
0000703dbfbceb51  movaps xmm13, xmm1
0000703dbfbceb55  mulsd xmm13, xmm15
0000703dbfbceb5a  ucomisd xmm13, xmm13
0000703dbfbceb5f  jp 0x0000703DBFBCF02C
0000703dbfbceb65  movq xmm13, xmm13
0000703dbfbceb6a  lea r14, [rax+0xC0]
0000703dbfbceb71  mov r12, [r13+r14*1]
0000703dbfbceb76  movq xmm1, r12
0000703dbfbceb7b  movq r14, xmm14
0000703dbfbceb80  movq r12, xmm13
0000703dbfbceb85  vmovq xmm15, r14
0000703dbfbceb8a  vmovq xmm14, r12
0000703dbfbceb8f  movaps xmm13, xmm15
0000703dbfbceb93  addsd xmm13, xmm14
0000703dbfbceb98  ucomisd xmm13, xmm13
0000703dbfbceb9d  jp 0x0000703DBFBCF082
0000703dbfbceba3  movq xmm13, xmm13
0000703dbfbceba8  movaps xmm15, [r15+0x150]
0000703dbfbcebb0  movq r14, xmm15
0000703dbfbcebb5  movq r12, xmm1
0000703dbfbcebba  vmovq xmm1, r14
0000703dbfbcebbf  vmovq xmm15, r12
0000703dbfbcebc4  movaps xmm14, xmm1
0000703dbfbcebc8  mulsd xmm14, xmm15
0000703dbfbcebcd  ucomisd xmm14, xmm14
0000703dbfbcebd2  jp 0x0000703DBFBCF0CE
0000703dbfbcebd8  movq xmm14, xmm14
0000703dbfbcebdd  lea r14, [rax+0x100]
0000703dbfbcebe4  mov r12, [r13+r14*1]
0000703dbfbcebe9  movq xmm1, r12
0000703dbfbcebee  movq r14, xmm13
0000703dbfbcebf3  movq r12, xmm14
0000703dbfbcebf8  vmovq xmm15, r14
0000703dbfbcebfd  vmovq xmm14, r12
0000703dbfbcec02  movaps xmm13, xmm15
0000703dbfbcec06  addsd xmm13, xmm14
0000703dbfbcec0b  ucomisd xmm13, xmm13
0000703dbfbcec10  jp 0x0000703DBFBCF124
0000703dbfbcec16  movq xmm13, xmm13
0000703dbfbcec1b  movaps xmm15, [r15+0x160]
0000703dbfbcec23  movq r14, xmm15
0000703dbfbcec28  movq r12, xmm1
0000703dbfbcec2d  vmovq xmm1, r14
0000703dbfbcec32  vmovq xmm15, r12
0000703dbfbcec37  movaps xmm14, xmm1
0000703dbfbcec3b  mulsd xmm14, xmm15
0000703dbfbcec40  ucomisd xmm14, xmm14
0000703dbfbcec45  jp 0x0000703DBFBCF170
0000703dbfbcec4b  movq xmm14, xmm14
0000703dbfbcec50  lea r14, [rax+0x140]
0000703dbfbcec57  mov r12, [r13+r14*1]
0000703dbfbcec5c  movq xmm1, r12
0000703dbfbcec61  movq r14, xmm13
0000703dbfbcec66  movq r12, xmm14
0000703dbfbcec6b  vmovq xmm15, r14
0000703dbfbcec70  vmovq xmm14, r12
0000703dbfbcec75  movaps xmm13, xmm15
0000703dbfbcec79  addsd xmm13, xmm14
0000703dbfbcec7e  ucomisd xmm13, xmm13
0000703dbfbcec83  jp 0x0000703DBFBCF1C6
0000703dbfbcec89  movq xmm13, xmm13
0000703dbfbcec8e  movaps xmm15, [r15+0x170]
0000703dbfbcec96  movq r14, xmm15
0000703dbfbcec9b  movq r12, xmm1
0000703dbfbceca0  vmovq xmm1, r14
0000703dbfbceca5  vmovq xmm15, r12
0000703dbfbcecaa  movaps xmm14, xmm1
0000703dbfbcecae  mulsd xmm14, xmm15
0000703dbfbcecb3  ucomisd xmm14, xmm14
0000703dbfbcecb8  jp 0x0000703DBFBCF212
0000703dbfbcecbe  movq xmm14, xmm14
0000703dbfbcecc3  lea r14, [rax+0x180]
0000703dbfbcecca  mov r12, [r13+r14*1]
0000703dbfbceccf  movq xmm1, r12
0000703dbfbcecd4  movq r14, xmm13
0000703dbfbcecd9  movq r12, xmm14
0000703dbfbcecde  vmovq xmm15, r14
0000703dbfbcece3  vmovq xmm14, r12
0000703dbfbcece8  movaps xmm13, xmm15
0000703dbfbcecec  addsd xmm13, xmm14
0000703dbfbcecf1  ucomisd xmm13, xmm13
0000703dbfbcecf6  jp 0x0000703DBFBCF268
0000703dbfbcecfc  movq xmm13, xmm13
0000703dbfbced01  movaps xmm15, [r15+0x180]
0000703dbfbced09  movq r14, xmm15
0000703dbfbced0e  movq r12, xmm1
0000703dbfbced13  vmovq xmm1, r14
0000703dbfbced18  vmovq xmm15, r12
0000703dbfbced1d  movaps xmm14, xmm1
0000703dbfbced21  mulsd xmm14, xmm15
0000703dbfbced26  ucomisd xmm14, xmm14
0000703dbfbced2b  jp 0x0000703DBFBCF2B4
0000703dbfbced31  movq xmm14, xmm14
0000703dbfbced36  lea r14, [rax+0x1C0]
0000703dbfbced3d  mov rax, [r13+r14*1]
0000703dbfbced42  movq xmm1, rax
0000703dbfbced47  movaps [r15+0x240], xmm1
0000703dbfbced4f  movq rax, xmm13
0000703dbfbced54  movq r14, xmm14
0000703dbfbced59  vmovq xmm15, rax
0000703dbfbced5e  vmovq xmm14, r14
0000703dbfbced63  movaps xmm13, xmm15
0000703dbfbced67  addsd xmm13, xmm14
0000703dbfbced6c  ucomisd xmm13, xmm13
0000703dbfbced71  jp 0x0000703DBFBCF30A
0000703dbfbced77  movq xmm13, xmm13
0000703dbfbced7c  movaps xmm15, [r15+0x210]
0000703dbfbced84  movq rax, xmm15
0000703dbfbced89  movq r14, xmm1
0000703dbfbced8e  vmovq xmm1, rax
0000703dbfbced93  vmovq xmm15, r14
0000703dbfbced98  movaps xmm14, xmm1
0000703dbfbced9c  mulsd xmm14, xmm15
0000703dbfbceda1  ucomisd xmm14, xmm14
0000703dbfbceda6  jp 0x0000703DBFBCF352
0000703dbfbcedac  movq xmm14, xmm14
0000703dbfbcedb1  movaps [r15+0x230], xmm14
0000703dbfbcedb9  movq rax, xmm13
0000703dbfbcedbe  movq r14, xmm14
0000703dbfbcedc3  vmovq xmm1, rax
0000703dbfbcedc8  vmovq xmm15, r14
0000703dbfbcedcd  movaps xmm14, xmm1
0000703dbfbcedd1  addsd xmm14, xmm15
0000703dbfbcedd6  ucomisd xmm14, xmm14
0000703dbfbceddb  jp 0x0000703DBFBCF39A
0000703dbfbcede1  movq xmm14, xmm14
0000703dbfbcede6  movaps [r15+0x220], xmm14
0000703dbfbcedee  movq rax, xmm14
0000703dbfbcedf3  mov r14d, 0x4205C0
0000703dbfbcedf9  mov [r13+r14*1], rax
0000703dbfbcedfe  mov qword ptr [r15+0x70], 0x08
0000703dbfbcee06  xor eax, eax
0000703dbfbcee08  mov r14d, 0x08
0000703dbfbcee0e  mov r12d, 0x40
0000703dbfbcee14  cmp r14, r12
0000703dbfbcee17  cmc
0000703dbfbcee18  lahf
0000703dbfbcee19  seto al
0000703dbfbcee1c  mov [r15+0x108], eax
0000703dbfbcee23  mov eax, [r15+0x108]
0000703dbfbcee2a  sahf
0000703dbfbcee2b  jnz 0x0000703DBFBCEE5D
0000703dbfbcee2d  cmp dword ptr [r15+0x318], 0x00
0000703dbfbcee35  jz 0x0000703DBFBCFD40
0000703dbfbcee3b  nop [rax+rax*1], ax
0000703dbfbcee44  nop [rax+rax*1], eax
0000703dbfbcee4c  mov eax, 0x410118
0000703dbfbcee51  mov [r15+0x100], rax
0000703dbfbcee58  jmp 0x0000703DBF9FE110
0000703dbfbcee5d  cmp dword ptr [r15+0x318], 0x00
0000703dbfbcee65  jz 0x0000703DBFBCF3F0
0000703dbfbcee6b  nop [rax+rax*1], ax
0000703dbfbcee74  nop [rax+rax*1], eax
0000703dbfbcee7c  mov eax, 0x4100A4
0000703dbfbcee81  mov [r15+0x100], rax
0000703dbfbcee88  jmp 0x0000703DBF9FE110
0000703dbfbcee8d  int3
0000703dbfbcee8e  call 0x0000703DBFA0DC20
0000703dbfbcee93  jmp 0x0000703DBFBCE949
0000703dbfbcee98  call 0x0000703DBFAC0370
0000703dbfbcee9d  jmp 0x0000703DBFBCE952
0000703dbfbceea2  call 0x0000703DBFAE27E0
0000703dbfbceea7  jmp 0x0000703DBFBCE989
0000703dbfbceeac  call 0x0000703DBFAE1570
0000703dbfbceeb1  jmp 0x0000703DBFBCE992
0000703dbfbceeb6  call 0x0000703DBFAE27E0
0000703dbfbceebb  jmp 0x0000703DBFBCE9C9
0000703dbfbceec0  call 0x0000703DBFAE1570
0000703dbfbceec5  jmp 0x0000703DBFBCE9D2
0000703dbfbceeca  call 0x0000703DBFAE27E0
0000703dbfbceecf  jmp 0x0000703DBFBCEA09
0000703dbfbceed4  call 0x0000703DBFAD59C0
0000703dbfbceed9  jmp 0x0000703DBFBCEA12
0000703dbfbceede  call 0x0000703DBFA0DC20
0000703dbfbceee3  jmp 0x0000703DBFBCEA4D
0000703dbfbceee8  call 0x0000703DBFAE27E0
0000703dbfbceeed  jmp 0x0000703DBFBCEA5B
0000703dbfbceef2  call 0x0000703DBFAE27E0
0000703dbfbceef7  jmp 0x0000703DBFBCEA6C
0000703dbfbceefc  ucomisd xmm15, xmm12
0000703dbfbcef01  jp 0x0000703DBFBCEF10
0000703dbfbcef03  movaps xmm11, [0x0000703DBF7FE030]
0000703dbfbcef0b  jmp 0x0000703DBFBCEAA1
0000703dbfbcef10  vxorps xmm0, xmm15, xmm12
0000703dbfbcef15  pextrw r14d, xmm0, 0x03
0000703dbfbcef1b  and r14d, 0x7FF8
0000703dbfbcef22  cmp r14d, 0x08
0000703dbfbcef26  jnz 0x0000703DBFBCEAA1
0000703dbfbcef2c  movq r14, xmm12
0000703dbfbcef31  shl r14, 0x0D
0000703dbfbcef35  jbe 0x0000703DBFBCEAA1
0000703dbfbcef3b  vorps xmm11, xmm12, [0x0000703DBF7FE040]
0000703dbfbcef43  jmp 0x0000703DBFBCEAA1
0000703dbfbcef48  ucomisd xmm15, xmm14
0000703dbfbcef4d  jp 0x0000703DBFBCEF5C
0000703dbfbcef4f  movaps xmm12, [0x0000703DBF7FE030]
0000703dbfbcef57  jmp 0x0000703DBFBCEAD6
0000703dbfbcef5c  vxorps xmm0, xmm15, xmm14
0000703dbfbcef61  pextrw r14d, xmm0, 0x03
0000703dbfbcef67  and r14d, 0x7FF8
0000703dbfbcef6e  cmp r14d, 0x08
0000703dbfbcef72  jnz 0x0000703DBFBCEAD6
0000703dbfbcef78  movq r14, xmm14
0000703dbfbcef7d  shl r14, 0x0D
0000703dbfbcef81  jbe 0x0000703DBFBCEAD6
0000703dbfbcef87  vorps xmm12, xmm14, [0x0000703DBF7FE040]
0000703dbfbcef8f  jmp 0x0000703DBFBCEAD6
0000703dbfbcef94  ucomisd xmm1, xmm15
0000703dbfbcef99  jp 0x0000703DBFBCEFA8
0000703dbfbcef9b  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcefa3  jmp 0x0000703DBFBCEB03
0000703dbfbcefa8  vxorps xmm0, xmm1, xmm15
0000703dbfbcefad  pextrw r14d, xmm0, 0x03
0000703dbfbcefb3  and r14d, 0x7FF8
0000703dbfbcefba  cmp r14d, 0x08
0000703dbfbcefbe  jnz 0x0000703DBFBCEB03
0000703dbfbcefc4  movq r14, xmm15
0000703dbfbcefc9  shl r14, 0x0D
0000703dbfbcefcd  jbe 0x0000703DBFBCEB03
0000703dbfbcefd3  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcefdb  jmp 0x0000703DBFBCEB03
0000703dbfbcefe0  ucomisd xmm1, xmm15
0000703dbfbcefe5  jp 0x0000703DBFBCEFF4
0000703dbfbcefe7  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcefef  jmp 0x0000703DBFBCEB30
0000703dbfbceff4  vxorps xmm0, xmm1, xmm15
0000703dbfbceff9  pextrw r14d, xmm0, 0x03
0000703dbfbcefff  and r14d, 0x7FF8
0000703dbfbcf006  cmp r14d, 0x08
0000703dbfbcf00a  jnz 0x0000703DBFBCEB30
0000703dbfbcf010  movq r14, xmm15
0000703dbfbcf015  shl r14, 0x0D
0000703dbfbcf019  jbe 0x0000703DBFBCEB30
0000703dbfbcf01f  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcf027  jmp 0x0000703DBFBCEB30
0000703dbfbcf02c  ucomisd xmm1, xmm15
0000703dbfbcf031  jp 0x0000703DBFBCF040
0000703dbfbcf033  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbcf03b  jmp 0x0000703DBFBCEB65
0000703dbfbcf040  vxorps xmm0, xmm1, xmm15
0000703dbfbcf045  pextrw r14d, xmm0, 0x03
0000703dbfbcf04b  and r14d, 0x7FF8
0000703dbfbcf052  cmp r14d, 0x08
0000703dbfbcf056  jnz 0x0000703DBFBCEB65
0000703dbfbcf05c  movq r14, xmm15
0000703dbfbcf061  shl r14, 0x0D
0000703dbfbcf065  jbe 0x0000703DBFBCEB65
0000703dbfbcf06b  vorps xmm13, xmm15, [0x0000703DBF7FE040]
0000703dbfbcf073  jmp 0x0000703DBFBCEB65
0000703dbfbcf078  call 0x0000703DBFAE27E0
0000703dbfbcf07d  jmp 0x0000703DBFBCEB76
0000703dbfbcf082  ucomisd xmm15, xmm14
0000703dbfbcf087  jp 0x0000703DBFBCF096
0000703dbfbcf089  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbcf091  jmp 0x0000703DBFBCEBA3
0000703dbfbcf096  vxorps xmm0, xmm15, xmm14
0000703dbfbcf09b  pextrw r14d, xmm0, 0x03
0000703dbfbcf0a1  and r14d, 0x7FF8
0000703dbfbcf0a8  cmp r14d, 0x08
0000703dbfbcf0ac  jnz 0x0000703DBFBCEBA3
0000703dbfbcf0b2  movq r14, xmm14
0000703dbfbcf0b7  shl r14, 0x0D
0000703dbfbcf0bb  jbe 0x0000703DBFBCEBA3
0000703dbfbcf0c1  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbcf0c9  jmp 0x0000703DBFBCEBA3
0000703dbfbcf0ce  ucomisd xmm1, xmm15
0000703dbfbcf0d3  jp 0x0000703DBFBCF0E2
0000703dbfbcf0d5  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcf0dd  jmp 0x0000703DBFBCEBD8
0000703dbfbcf0e2  vxorps xmm0, xmm1, xmm15
0000703dbfbcf0e7  pextrw r14d, xmm0, 0x03
0000703dbfbcf0ed  and r14d, 0x7FF8
0000703dbfbcf0f4  cmp r14d, 0x08
0000703dbfbcf0f8  jnz 0x0000703DBFBCEBD8
0000703dbfbcf0fe  movq r14, xmm15
0000703dbfbcf103  shl r14, 0x0D
0000703dbfbcf107  jbe 0x0000703DBFBCEBD8
0000703dbfbcf10d  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcf115  jmp 0x0000703DBFBCEBD8
0000703dbfbcf11a  call 0x0000703DBFAE27E0
0000703dbfbcf11f  jmp 0x0000703DBFBCEBE9
0000703dbfbcf124  ucomisd xmm15, xmm14
0000703dbfbcf129  jp 0x0000703DBFBCF138
0000703dbfbcf12b  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbcf133  jmp 0x0000703DBFBCEC16
0000703dbfbcf138  vxorps xmm0, xmm15, xmm14
0000703dbfbcf13d  pextrw r14d, xmm0, 0x03
0000703dbfbcf143  and r14d, 0x7FF8
0000703dbfbcf14a  cmp r14d, 0x08
0000703dbfbcf14e  jnz 0x0000703DBFBCEC16
0000703dbfbcf154  movq r14, xmm14
0000703dbfbcf159  shl r14, 0x0D
0000703dbfbcf15d  jbe 0x0000703DBFBCEC16
0000703dbfbcf163  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbcf16b  jmp 0x0000703DBFBCEC16
0000703dbfbcf170  ucomisd xmm1, xmm15
0000703dbfbcf175  jp 0x0000703DBFBCF184
0000703dbfbcf177  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcf17f  jmp 0x0000703DBFBCEC4B
0000703dbfbcf184  vxorps xmm0, xmm1, xmm15
0000703dbfbcf189  pextrw r14d, xmm0, 0x03
0000703dbfbcf18f  and r14d, 0x7FF8
0000703dbfbcf196  cmp r14d, 0x08
0000703dbfbcf19a  jnz 0x0000703DBFBCEC4B
0000703dbfbcf1a0  movq r14, xmm15
0000703dbfbcf1a5  shl r14, 0x0D
0000703dbfbcf1a9  jbe 0x0000703DBFBCEC4B
0000703dbfbcf1af  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcf1b7  jmp 0x0000703DBFBCEC4B
0000703dbfbcf1bc  call 0x0000703DBFAE27E0
0000703dbfbcf1c1  jmp 0x0000703DBFBCEC5C
0000703dbfbcf1c6  ucomisd xmm15, xmm14
0000703dbfbcf1cb  jp 0x0000703DBFBCF1DA
0000703dbfbcf1cd  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbcf1d5  jmp 0x0000703DBFBCEC89
0000703dbfbcf1da  vxorps xmm0, xmm15, xmm14
0000703dbfbcf1df  pextrw r14d, xmm0, 0x03
0000703dbfbcf1e5  and r14d, 0x7FF8
0000703dbfbcf1ec  cmp r14d, 0x08
0000703dbfbcf1f0  jnz 0x0000703DBFBCEC89
0000703dbfbcf1f6  movq r14, xmm14
0000703dbfbcf1fb  shl r14, 0x0D
0000703dbfbcf1ff  jbe 0x0000703DBFBCEC89
0000703dbfbcf205  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbcf20d  jmp 0x0000703DBFBCEC89
0000703dbfbcf212  ucomisd xmm1, xmm15
0000703dbfbcf217  jp 0x0000703DBFBCF226
0000703dbfbcf219  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcf221  jmp 0x0000703DBFBCECBE
0000703dbfbcf226  vxorps xmm0, xmm1, xmm15
0000703dbfbcf22b  pextrw r14d, xmm0, 0x03
0000703dbfbcf231  and r14d, 0x7FF8
0000703dbfbcf238  cmp r14d, 0x08
0000703dbfbcf23c  jnz 0x0000703DBFBCECBE
0000703dbfbcf242  movq r14, xmm15
0000703dbfbcf247  shl r14, 0x0D
0000703dbfbcf24b  jbe 0x0000703DBFBCECBE
0000703dbfbcf251  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcf259  jmp 0x0000703DBFBCECBE
0000703dbfbcf25e  call 0x0000703DBFAE27E0
0000703dbfbcf263  jmp 0x0000703DBFBCECCF
0000703dbfbcf268  ucomisd xmm15, xmm14
0000703dbfbcf26d  jp 0x0000703DBFBCF27C
0000703dbfbcf26f  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbcf277  jmp 0x0000703DBFBCECFC
0000703dbfbcf27c  vxorps xmm0, xmm15, xmm14
0000703dbfbcf281  pextrw r14d, xmm0, 0x03
0000703dbfbcf287  and r14d, 0x7FF8
0000703dbfbcf28e  cmp r14d, 0x08
0000703dbfbcf292  jnz 0x0000703DBFBCECFC
0000703dbfbcf298  movq r14, xmm14
0000703dbfbcf29d  shl r14, 0x0D
0000703dbfbcf2a1  jbe 0x0000703DBFBCECFC
0000703dbfbcf2a7  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbcf2af  jmp 0x0000703DBFBCECFC
0000703dbfbcf2b4  ucomisd xmm1, xmm15
0000703dbfbcf2b9  jp 0x0000703DBFBCF2C8
0000703dbfbcf2bb  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcf2c3  jmp 0x0000703DBFBCED31
0000703dbfbcf2c8  vxorps xmm0, xmm1, xmm15
0000703dbfbcf2cd  pextrw r14d, xmm0, 0x03
0000703dbfbcf2d3  and r14d, 0x7FF8
0000703dbfbcf2da  cmp r14d, 0x08
0000703dbfbcf2de  jnz 0x0000703DBFBCED31
0000703dbfbcf2e4  movq r14, xmm15
0000703dbfbcf2e9  shl r14, 0x0D
0000703dbfbcf2ed  jbe 0x0000703DBFBCED31
0000703dbfbcf2f3  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcf2fb  jmp 0x0000703DBFBCED31
0000703dbfbcf300  call 0x0000703DBFAD59C0
0000703dbfbcf305  jmp 0x0000703DBFBCED42
0000703dbfbcf30a  ucomisd xmm15, xmm14
0000703dbfbcf30f  jp 0x0000703DBFBCF31E
0000703dbfbcf311  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbcf319  jmp 0x0000703DBFBCED77
0000703dbfbcf31e  vxorps xmm0, xmm15, xmm14
0000703dbfbcf323  pextrw eax, xmm0, 0x03
0000703dbfbcf328  and eax, 0x7FF8
0000703dbfbcf32d  cmp eax, 0x08
0000703dbfbcf330  jnz 0x0000703DBFBCED77
0000703dbfbcf336  movq rax, xmm14
0000703dbfbcf33b  shl rax, 0x0D
0000703dbfbcf33f  jbe 0x0000703DBFBCED77
0000703dbfbcf345  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbcf34d  jmp 0x0000703DBFBCED77
0000703dbfbcf352  ucomisd xmm1, xmm15
0000703dbfbcf357  jp 0x0000703DBFBCF366
0000703dbfbcf359  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcf361  jmp 0x0000703DBFBCEDAC
0000703dbfbcf366  vxorps xmm0, xmm1, xmm15
0000703dbfbcf36b  pextrw eax, xmm0, 0x03
0000703dbfbcf370  and eax, 0x7FF8
0000703dbfbcf375  cmp eax, 0x08
0000703dbfbcf378  jnz 0x0000703DBFBCEDAC
0000703dbfbcf37e  movq rax, xmm15
0000703dbfbcf383  shl rax, 0x0D
0000703dbfbcf387  jbe 0x0000703DBFBCEDAC
0000703dbfbcf38d  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcf395  jmp 0x0000703DBFBCEDAC
0000703dbfbcf39a  ucomisd xmm1, xmm15
0000703dbfbcf39f  jp 0x0000703DBFBCF3AE
0000703dbfbcf3a1  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcf3a9  jmp 0x0000703DBFBCEDE1
0000703dbfbcf3ae  vxorps xmm0, xmm1, xmm15
0000703dbfbcf3b3  pextrw eax, xmm0, 0x03
0000703dbfbcf3b8  and eax, 0x7FF8
0000703dbfbcf3bd  cmp eax, 0x08
0000703dbfbcf3c0  jnz 0x0000703DBFBCEDE1
0000703dbfbcf3c6  movq rax, xmm15
0000703dbfbcf3cb  shl rax, 0x0D
0000703dbfbcf3cf  jbe 0x0000703DBFBCEDE1
0000703dbfbcf3d5  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcf3dd  jmp 0x0000703DBFBCEDE1
0000703dbfbcf3e2  call 0x0000703DBFAD5EB0
0000703dbfbcf3e7  jmp 0x0000703DBFBCEDFE
0000703dbfbcf3ec  int3
0000703dbfbcf3ed  nop [rax], eax
0000703dbfbcf3f0  mov rax, [r15+0x48]
0000703dbfbcf3f4  mov r14, [r15+0x70]
0000703dbfbcf3f8  lea r12, [rax+r14*1]
0000703dbfbcf3fc  mov [r15+0x78], r12
0000703dbfbcf400  mov rax, [r13+r12*1]
0000703dbfbcf405  movq xmm1, rax
0000703dbfbcf40a  lea rax, [r12+0x40]
0000703dbfbcf40f  mov r11, [r13+rax*1]
0000703dbfbcf414  movq xmm15, r11
0000703dbfbcf419  lea rax, [r12+0x80]
0000703dbfbcf421  mov r11, [r13+rax*1]
0000703dbfbcf426  movq xmm14, r11
0000703dbfbcf42b  movaps xmm13, [r15+0x120]
0000703dbfbcf433  movq rax, xmm13
0000703dbfbcf438  movq r11, xmm1
0000703dbfbcf43d  vmovq xmm1, rax
0000703dbfbcf442  vmovq xmm13, r11
0000703dbfbcf447  movaps xmm12, xmm1
0000703dbfbcf44b  mulsd xmm12, xmm13
0000703dbfbcf450  ucomisd xmm12, xmm12
0000703dbfbcf455  jp 0x0000703DBFBCF879
0000703dbfbcf45b  movq xmm12, xmm12
0000703dbfbcf460  movaps xmm1, [r15+0x130]
0000703dbfbcf468  movq rax, xmm1
0000703dbfbcf46d  movq r11, xmm15
0000703dbfbcf472  vmovq xmm1, rax
0000703dbfbcf477  vmovq xmm15, r11
0000703dbfbcf47c  movaps xmm13, xmm1
0000703dbfbcf480  mulsd xmm13, xmm15
0000703dbfbcf485  ucomisd xmm13, xmm13
0000703dbfbcf48a  jp 0x0000703DBFBCF8C1
0000703dbfbcf490  movq xmm13, xmm13
0000703dbfbcf495  movq rax, xmm12
0000703dbfbcf49a  movaps xmm1, [r15+0x110]
0000703dbfbcf4a2  movq r11, xmm1
0000703dbfbcf4a7  vmovq xmm1, rax
0000703dbfbcf4ac  vmovq xmm15, r11
0000703dbfbcf4b1  movaps xmm12, xmm1
0000703dbfbcf4b5  addsd xmm12, xmm15
0000703dbfbcf4ba  ucomisd xmm12, xmm12
0000703dbfbcf4bf  jp 0x0000703DBFBCF909
0000703dbfbcf4c5  movq xmm12, xmm12
0000703dbfbcf4ca  movq rax, xmm12
0000703dbfbcf4cf  movq r11, xmm13
0000703dbfbcf4d4  vmovq xmm1, rax
0000703dbfbcf4d9  vmovq xmm15, r11
0000703dbfbcf4de  movaps xmm13, xmm1
0000703dbfbcf4e2  addsd xmm13, xmm15
0000703dbfbcf4e7  ucomisd xmm13, xmm13
0000703dbfbcf4ec  jp 0x0000703DBFBCF951
0000703dbfbcf4f2  movq xmm13, xmm13
0000703dbfbcf4f7  movaps xmm1, [r15+0x140]
0000703dbfbcf4ff  movq rax, xmm1
0000703dbfbcf504  movq r11, xmm14
0000703dbfbcf509  vmovq xmm1, rax
0000703dbfbcf50e  vmovq xmm15, r11
0000703dbfbcf513  movaps xmm14, xmm1
0000703dbfbcf517  mulsd xmm14, xmm15
0000703dbfbcf51c  ucomisd xmm14, xmm14
0000703dbfbcf521  jp 0x0000703DBFBCF999
0000703dbfbcf527  movq xmm14, xmm14
0000703dbfbcf52c  lea rax, [r12+0xC0]
0000703dbfbcf534  mov r11, [r13+rax*1]
0000703dbfbcf539  movq xmm1, r11
0000703dbfbcf53e  movq rax, xmm13
0000703dbfbcf543  movq r11, xmm14
0000703dbfbcf548  vmovq xmm15, rax
0000703dbfbcf54d  vmovq xmm14, r11
0000703dbfbcf552  movaps xmm13, xmm15
0000703dbfbcf556  addsd xmm13, xmm14
0000703dbfbcf55b  ucomisd xmm13, xmm13
0000703dbfbcf560  jp 0x0000703DBFBCF9EB
0000703dbfbcf566  movq xmm13, xmm13
0000703dbfbcf56b  movaps xmm15, [r15+0x150]
0000703dbfbcf573  movq rax, xmm15
0000703dbfbcf578  movq r11, xmm1
0000703dbfbcf57d  vmovq xmm1, rax
0000703dbfbcf582  vmovq xmm15, r11
0000703dbfbcf587  movaps xmm14, xmm1
0000703dbfbcf58b  mulsd xmm14, xmm15
0000703dbfbcf590  ucomisd xmm14, xmm14
0000703dbfbcf595  jp 0x0000703DBFBCFA33
0000703dbfbcf59b  movq xmm14, xmm14
0000703dbfbcf5a0  lea rax, [r12+0x100]
0000703dbfbcf5a8  mov r11, [r13+rax*1]
0000703dbfbcf5ad  movq xmm1, r11
0000703dbfbcf5b2  movq rax, xmm13
0000703dbfbcf5b7  movq r11, xmm14
0000703dbfbcf5bc  vmovq xmm15, rax
0000703dbfbcf5c1  vmovq xmm14, r11
0000703dbfbcf5c6  movaps xmm13, xmm15
0000703dbfbcf5ca  addsd xmm13, xmm14
0000703dbfbcf5cf  ucomisd xmm13, xmm13
0000703dbfbcf5d4  jp 0x0000703DBFBCFA85
0000703dbfbcf5da  movq xmm13, xmm13
0000703dbfbcf5df  movaps xmm15, [r15+0x160]
0000703dbfbcf5e7  movq rax, xmm15
0000703dbfbcf5ec  movq r11, xmm1
0000703dbfbcf5f1  vmovq xmm1, rax
0000703dbfbcf5f6  vmovq xmm15, r11
0000703dbfbcf5fb  movaps xmm14, xmm1
0000703dbfbcf5ff  mulsd xmm14, xmm15
0000703dbfbcf604  ucomisd xmm14, xmm14
0000703dbfbcf609  jp 0x0000703DBFBCFACD
0000703dbfbcf60f  movq xmm14, xmm14
0000703dbfbcf614  lea rax, [r12+0x140]
0000703dbfbcf61c  mov r11, [r13+rax*1]
0000703dbfbcf621  movq xmm1, r11
0000703dbfbcf626  movq rax, xmm13
0000703dbfbcf62b  movq r11, xmm14
0000703dbfbcf630  vmovq xmm15, rax
0000703dbfbcf635  vmovq xmm14, r11
0000703dbfbcf63a  movaps xmm13, xmm15
0000703dbfbcf63e  addsd xmm13, xmm14
0000703dbfbcf643  ucomisd xmm13, xmm13
0000703dbfbcf648  jp 0x0000703DBFBCFB1F
0000703dbfbcf64e  movq xmm13, xmm13
0000703dbfbcf653  movaps xmm15, [r15+0x170]
0000703dbfbcf65b  movq rax, xmm15
0000703dbfbcf660  movq r11, xmm1
0000703dbfbcf665  vmovq xmm1, rax
0000703dbfbcf66a  vmovq xmm15, r11
0000703dbfbcf66f  movaps xmm14, xmm1
0000703dbfbcf673  mulsd xmm14, xmm15
0000703dbfbcf678  ucomisd xmm14, xmm14
0000703dbfbcf67d  jp 0x0000703DBFBCFB67
0000703dbfbcf683  movq xmm14, xmm14
0000703dbfbcf688  lea rax, [r12+0x180]
0000703dbfbcf690  mov r11, [r13+rax*1]
0000703dbfbcf695  movq xmm1, r11
0000703dbfbcf69a  movq rax, xmm13
0000703dbfbcf69f  movq r11, xmm14
0000703dbfbcf6a4  vmovq xmm15, rax
0000703dbfbcf6a9  vmovq xmm14, r11
0000703dbfbcf6ae  movaps xmm13, xmm15
0000703dbfbcf6b2  addsd xmm13, xmm14
0000703dbfbcf6b7  ucomisd xmm13, xmm13
0000703dbfbcf6bc  jp 0x0000703DBFBCFBB9
0000703dbfbcf6c2  movq xmm13, xmm13
0000703dbfbcf6c7  movaps xmm15, [r15+0x180]
0000703dbfbcf6cf  movq rax, xmm15
0000703dbfbcf6d4  movq r11, xmm1
0000703dbfbcf6d9  vmovq xmm1, rax
0000703dbfbcf6de  vmovq xmm15, r11
0000703dbfbcf6e3  movaps xmm14, xmm1
0000703dbfbcf6e7  mulsd xmm14, xmm15
0000703dbfbcf6ec  ucomisd xmm14, xmm14
0000703dbfbcf6f1  jp 0x0000703DBFBCFC01
0000703dbfbcf6f7  movq xmm14, xmm14
0000703dbfbcf6fc  lea rax, [r12+0x1C0]
0000703dbfbcf704  mov r12, [r13+rax*1]
0000703dbfbcf709  movq xmm1, r12
0000703dbfbcf70e  movaps [r15+0x240], xmm1
0000703dbfbcf716  movq rax, xmm13
0000703dbfbcf71b  movq r12, xmm14
0000703dbfbcf720  vmovq xmm15, rax
0000703dbfbcf725  vmovq xmm14, r12
0000703dbfbcf72a  movaps xmm13, xmm15
0000703dbfbcf72e  addsd xmm13, xmm14
0000703dbfbcf733  ucomisd xmm13, xmm13
0000703dbfbcf738  jp 0x0000703DBFBCFC53
0000703dbfbcf73e  movq xmm13, xmm13
0000703dbfbcf743  movaps xmm15, [r15+0x210]
0000703dbfbcf74b  movq rax, xmm15
0000703dbfbcf750  movq r12, xmm1
0000703dbfbcf755  vmovq xmm1, rax
0000703dbfbcf75a  vmovq xmm15, r12
0000703dbfbcf75f  movaps xmm14, xmm1
0000703dbfbcf763  mulsd xmm14, xmm15
0000703dbfbcf768  ucomisd xmm14, xmm14
0000703dbfbcf76d  jp 0x0000703DBFBCFC9B
0000703dbfbcf773  movq xmm14, xmm14
0000703dbfbcf778  movaps [r15+0x230], xmm14
0000703dbfbcf780  movq rax, xmm13
0000703dbfbcf785  movq r12, xmm14
0000703dbfbcf78a  vmovq xmm1, rax
0000703dbfbcf78f  vmovq xmm15, r12
0000703dbfbcf794  movaps xmm14, xmm1
0000703dbfbcf798  addsd xmm14, xmm15
0000703dbfbcf79d  ucomisd xmm14, xmm14
0000703dbfbcf7a2  jp 0x0000703DBFBCFCE3
0000703dbfbcf7a8  movq xmm14, xmm14
0000703dbfbcf7ad  movaps [r15+0x220], xmm14
0000703dbfbcf7b5  mov rax, [r15+0x68]
0000703dbfbcf7b9  lea r12, [rax+r14*1]
0000703dbfbcf7bd  movq rax, xmm14
0000703dbfbcf7c2  mov [r13+r12*1], rax
0000703dbfbcf7c7  lea rax, [r14+0x08]
0000703dbfbcf7cb  mov [r15+0x70], rax
0000703dbfbcf7cf  mov [rsp+0x10], rax
0000703dbfbcf7d4  xor eax, eax
0000703dbfbcf7d6  mov r14, [rsp+0x10]
0000703dbfbcf7db  mov r12d, 0x40
0000703dbfbcf7e1  cmp r14, r12
0000703dbfbcf7e4  cmc
0000703dbfbcf7e5  lahf
0000703dbfbcf7e6  seto al
0000703dbfbcf7e9  mov [r15+0x108], eax
0000703dbfbcf7f0  mov eax, [r15+0x108]
0000703dbfbcf7f7  sahf
0000703dbfbcf7f8  jnz 0x0000703DBFBCF82A
0000703dbfbcf7fa  cmp dword ptr [r15+0x318], 0x00
0000703dbfbcf802  jz 0x0000703DBFBCFD40
0000703dbfbcf808  nop [rax+rax*1], ax
0000703dbfbcf811  nop [rax+rax*1], eax
0000703dbfbcf819  mov eax, 0x410118
0000703dbfbcf81e  mov [r15+0x100], rax
0000703dbfbcf825  jmp 0x0000703DBF9FE110
0000703dbfbcf82a  cmp dword ptr [r15+0x318], 0x00
0000703dbfbcf832  jz 0x0000703DBFBCF3F0
0000703dbfbcf838  nop [rax+rax*1], ax
0000703dbfbcf841  nop [rax+rax*1], eax
0000703dbfbcf849  mov eax, 0x4100A4
0000703dbfbcf84e  mov [r15+0x100], rax
0000703dbfbcf855  jmp 0x0000703DBF9FE110
0000703dbfbcf85a  int3
0000703dbfbcf85b  call 0x0000703DBFAB47C0
0000703dbfbcf860  jmp 0x0000703DBFBCF405
0000703dbfbcf865  call 0x0000703DBFA0A4B0
0000703dbfbcf86a  jmp 0x0000703DBFBCF414
0000703dbfbcf86f  call 0x0000703DBFA0A4B0
0000703dbfbcf874  jmp 0x0000703DBFBCF426
0000703dbfbcf879  ucomisd xmm1, xmm13
0000703dbfbcf87e  jp 0x0000703DBFBCF88D
0000703dbfbcf880  movaps xmm12, [0x0000703DBF7FE030]
0000703dbfbcf888  jmp 0x0000703DBFBCF45B
0000703dbfbcf88d  vxorps xmm0, xmm1, xmm13
0000703dbfbcf892  pextrw eax, xmm0, 0x03
0000703dbfbcf897  and eax, 0x7FF8
0000703dbfbcf89c  cmp eax, 0x08
0000703dbfbcf89f  jnz 0x0000703DBFBCF45B
0000703dbfbcf8a5  movq rax, xmm13
0000703dbfbcf8aa  shl rax, 0x0D
0000703dbfbcf8ae  jbe 0x0000703DBFBCF45B
0000703dbfbcf8b4  vorps xmm12, xmm13, [0x0000703DBF7FE040]
0000703dbfbcf8bc  jmp 0x0000703DBFBCF45B
0000703dbfbcf8c1  ucomisd xmm1, xmm15
0000703dbfbcf8c6  jp 0x0000703DBFBCF8D5
0000703dbfbcf8c8  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbcf8d0  jmp 0x0000703DBFBCF490
0000703dbfbcf8d5  vxorps xmm0, xmm1, xmm15
0000703dbfbcf8da  pextrw eax, xmm0, 0x03
0000703dbfbcf8df  and eax, 0x7FF8
0000703dbfbcf8e4  cmp eax, 0x08
0000703dbfbcf8e7  jnz 0x0000703DBFBCF490
0000703dbfbcf8ed  movq rax, xmm15
0000703dbfbcf8f2  shl rax, 0x0D
0000703dbfbcf8f6  jbe 0x0000703DBFBCF490
0000703dbfbcf8fc  vorps xmm13, xmm15, [0x0000703DBF7FE040]
0000703dbfbcf904  jmp 0x0000703DBFBCF490
0000703dbfbcf909  ucomisd xmm1, xmm15
0000703dbfbcf90e  jp 0x0000703DBFBCF91D
0000703dbfbcf910  movaps xmm12, [0x0000703DBF7FE030]
0000703dbfbcf918  jmp 0x0000703DBFBCF4C5
0000703dbfbcf91d  vxorps xmm0, xmm1, xmm15
0000703dbfbcf922  pextrw eax, xmm0, 0x03
0000703dbfbcf927  and eax, 0x7FF8
0000703dbfbcf92c  cmp eax, 0x08
0000703dbfbcf92f  jnz 0x0000703DBFBCF4C5
0000703dbfbcf935  movq rax, xmm15
0000703dbfbcf93a  shl rax, 0x0D
0000703dbfbcf93e  jbe 0x0000703DBFBCF4C5
0000703dbfbcf944  vorps xmm12, xmm15, [0x0000703DBF7FE040]
0000703dbfbcf94c  jmp 0x0000703DBFBCF4C5
0000703dbfbcf951  ucomisd xmm1, xmm15
0000703dbfbcf956  jp 0x0000703DBFBCF965
0000703dbfbcf958  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbcf960  jmp 0x0000703DBFBCF4F2
0000703dbfbcf965  vxorps xmm0, xmm1, xmm15
0000703dbfbcf96a  pextrw eax, xmm0, 0x03
0000703dbfbcf96f  and eax, 0x7FF8
0000703dbfbcf974  cmp eax, 0x08
0000703dbfbcf977  jnz 0x0000703DBFBCF4F2
0000703dbfbcf97d  movq rax, xmm15
0000703dbfbcf982  shl rax, 0x0D
0000703dbfbcf986  jbe 0x0000703DBFBCF4F2
0000703dbfbcf98c  vorps xmm13, xmm15, [0x0000703DBF7FE040]
0000703dbfbcf994  jmp 0x0000703DBFBCF4F2
0000703dbfbcf999  ucomisd xmm1, xmm15
0000703dbfbcf99e  jp 0x0000703DBFBCF9AD
0000703dbfbcf9a0  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcf9a8  jmp 0x0000703DBFBCF527
0000703dbfbcf9ad  vxorps xmm0, xmm1, xmm15
0000703dbfbcf9b2  pextrw eax, xmm0, 0x03
0000703dbfbcf9b7  and eax, 0x7FF8
0000703dbfbcf9bc  cmp eax, 0x08
0000703dbfbcf9bf  jnz 0x0000703DBFBCF527
0000703dbfbcf9c5  movq rax, xmm15
0000703dbfbcf9ca  shl rax, 0x0D
0000703dbfbcf9ce  jbe 0x0000703DBFBCF527
0000703dbfbcf9d4  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcf9dc  jmp 0x0000703DBFBCF527
0000703dbfbcf9e1  call 0x0000703DBFA0A4B0
0000703dbfbcf9e6  jmp 0x0000703DBFBCF539
0000703dbfbcf9eb  ucomisd xmm15, xmm14
0000703dbfbcf9f0  jp 0x0000703DBFBCF9FF
0000703dbfbcf9f2  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbcf9fa  jmp 0x0000703DBFBCF566
0000703dbfbcf9ff  vxorps xmm0, xmm15, xmm14
0000703dbfbcfa04  pextrw eax, xmm0, 0x03
0000703dbfbcfa09  and eax, 0x7FF8
0000703dbfbcfa0e  cmp eax, 0x08
0000703dbfbcfa11  jnz 0x0000703DBFBCF566
0000703dbfbcfa17  movq rax, xmm14
0000703dbfbcfa1c  shl rax, 0x0D
0000703dbfbcfa20  jbe 0x0000703DBFBCF566
0000703dbfbcfa26  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbcfa2e  jmp 0x0000703DBFBCF566
0000703dbfbcfa33  ucomisd xmm1, xmm15
0000703dbfbcfa38  jp 0x0000703DBFBCFA47
0000703dbfbcfa3a  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcfa42  jmp 0x0000703DBFBCF59B
0000703dbfbcfa47  vxorps xmm0, xmm1, xmm15
0000703dbfbcfa4c  pextrw eax, xmm0, 0x03
0000703dbfbcfa51  and eax, 0x7FF8
0000703dbfbcfa56  cmp eax, 0x08
0000703dbfbcfa59  jnz 0x0000703DBFBCF59B
0000703dbfbcfa5f  movq rax, xmm15
0000703dbfbcfa64  shl rax, 0x0D
0000703dbfbcfa68  jbe 0x0000703DBFBCF59B
0000703dbfbcfa6e  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcfa76  jmp 0x0000703DBFBCF59B
0000703dbfbcfa7b  call 0x0000703DBFA0A4B0
0000703dbfbcfa80  jmp 0x0000703DBFBCF5AD
0000703dbfbcfa85  ucomisd xmm15, xmm14
0000703dbfbcfa8a  jp 0x0000703DBFBCFA99
0000703dbfbcfa8c  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbcfa94  jmp 0x0000703DBFBCF5DA
0000703dbfbcfa99  vxorps xmm0, xmm15, xmm14
0000703dbfbcfa9e  pextrw eax, xmm0, 0x03
0000703dbfbcfaa3  and eax, 0x7FF8
0000703dbfbcfaa8  cmp eax, 0x08
0000703dbfbcfaab  jnz 0x0000703DBFBCF5DA
0000703dbfbcfab1  movq rax, xmm14
0000703dbfbcfab6  shl rax, 0x0D
0000703dbfbcfaba  jbe 0x0000703DBFBCF5DA
0000703dbfbcfac0  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbcfac8  jmp 0x0000703DBFBCF5DA
0000703dbfbcfacd  ucomisd xmm1, xmm15
0000703dbfbcfad2  jp 0x0000703DBFBCFAE1
0000703dbfbcfad4  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcfadc  jmp 0x0000703DBFBCF60F
0000703dbfbcfae1  vxorps xmm0, xmm1, xmm15
0000703dbfbcfae6  pextrw eax, xmm0, 0x03
0000703dbfbcfaeb  and eax, 0x7FF8
0000703dbfbcfaf0  cmp eax, 0x08
0000703dbfbcfaf3  jnz 0x0000703DBFBCF60F
0000703dbfbcfaf9  movq rax, xmm15
0000703dbfbcfafe  shl rax, 0x0D
0000703dbfbcfb02  jbe 0x0000703DBFBCF60F
0000703dbfbcfb08  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcfb10  jmp 0x0000703DBFBCF60F
0000703dbfbcfb15  call 0x0000703DBFA0A4B0
0000703dbfbcfb1a  jmp 0x0000703DBFBCF621
0000703dbfbcfb1f  ucomisd xmm15, xmm14
0000703dbfbcfb24  jp 0x0000703DBFBCFB33
0000703dbfbcfb26  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbcfb2e  jmp 0x0000703DBFBCF64E
0000703dbfbcfb33  vxorps xmm0, xmm15, xmm14
0000703dbfbcfb38  pextrw eax, xmm0, 0x03
0000703dbfbcfb3d  and eax, 0x7FF8
0000703dbfbcfb42  cmp eax, 0x08
0000703dbfbcfb45  jnz 0x0000703DBFBCF64E
0000703dbfbcfb4b  movq rax, xmm14
0000703dbfbcfb50  shl rax, 0x0D
0000703dbfbcfb54  jbe 0x0000703DBFBCF64E
0000703dbfbcfb5a  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbcfb62  jmp 0x0000703DBFBCF64E
0000703dbfbcfb67  ucomisd xmm1, xmm15
0000703dbfbcfb6c  jp 0x0000703DBFBCFB7B
0000703dbfbcfb6e  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcfb76  jmp 0x0000703DBFBCF683
0000703dbfbcfb7b  vxorps xmm0, xmm1, xmm15
0000703dbfbcfb80  pextrw eax, xmm0, 0x03
0000703dbfbcfb85  and eax, 0x7FF8
0000703dbfbcfb8a  cmp eax, 0x08
0000703dbfbcfb8d  jnz 0x0000703DBFBCF683
0000703dbfbcfb93  movq rax, xmm15
0000703dbfbcfb98  shl rax, 0x0D
0000703dbfbcfb9c  jbe 0x0000703DBFBCF683
0000703dbfbcfba2  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcfbaa  jmp 0x0000703DBFBCF683
0000703dbfbcfbaf  call 0x0000703DBFA0A4B0
0000703dbfbcfbb4  jmp 0x0000703DBFBCF695
0000703dbfbcfbb9  ucomisd xmm15, xmm14
0000703dbfbcfbbe  jp 0x0000703DBFBCFBCD
0000703dbfbcfbc0  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbcfbc8  jmp 0x0000703DBFBCF6C2
0000703dbfbcfbcd  vxorps xmm0, xmm15, xmm14
0000703dbfbcfbd2  pextrw eax, xmm0, 0x03
0000703dbfbcfbd7  and eax, 0x7FF8
0000703dbfbcfbdc  cmp eax, 0x08
0000703dbfbcfbdf  jnz 0x0000703DBFBCF6C2
0000703dbfbcfbe5  movq rax, xmm14
0000703dbfbcfbea  shl rax, 0x0D
0000703dbfbcfbee  jbe 0x0000703DBFBCF6C2
0000703dbfbcfbf4  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbcfbfc  jmp 0x0000703DBFBCF6C2
0000703dbfbcfc01  ucomisd xmm1, xmm15
0000703dbfbcfc06  jp 0x0000703DBFBCFC15
0000703dbfbcfc08  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcfc10  jmp 0x0000703DBFBCF6F7
0000703dbfbcfc15  vxorps xmm0, xmm1, xmm15
0000703dbfbcfc1a  pextrw eax, xmm0, 0x03
0000703dbfbcfc1f  and eax, 0x7FF8
0000703dbfbcfc24  cmp eax, 0x08
0000703dbfbcfc27  jnz 0x0000703DBFBCF6F7
0000703dbfbcfc2d  movq rax, xmm15
0000703dbfbcfc32  shl rax, 0x0D
0000703dbfbcfc36  jbe 0x0000703DBFBCF6F7
0000703dbfbcfc3c  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcfc44  jmp 0x0000703DBFBCF6F7
0000703dbfbcfc49  call 0x0000703DBFA0B720
0000703dbfbcfc4e  jmp 0x0000703DBFBCF709
0000703dbfbcfc53  ucomisd xmm15, xmm14
0000703dbfbcfc58  jp 0x0000703DBFBCFC67
0000703dbfbcfc5a  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbcfc62  jmp 0x0000703DBFBCF73E
0000703dbfbcfc67  vxorps xmm0, xmm15, xmm14
0000703dbfbcfc6c  pextrw eax, xmm0, 0x03
0000703dbfbcfc71  and eax, 0x7FF8
0000703dbfbcfc76  cmp eax, 0x08
0000703dbfbcfc79  jnz 0x0000703DBFBCF73E
0000703dbfbcfc7f  movq rax, xmm14
0000703dbfbcfc84  shl rax, 0x0D
0000703dbfbcfc88  jbe 0x0000703DBFBCF73E
0000703dbfbcfc8e  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbcfc96  jmp 0x0000703DBFBCF73E
0000703dbfbcfc9b  ucomisd xmm1, xmm15
0000703dbfbcfca0  jp 0x0000703DBFBCFCAF
0000703dbfbcfca2  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcfcaa  jmp 0x0000703DBFBCF773
0000703dbfbcfcaf  vxorps xmm0, xmm1, xmm15
0000703dbfbcfcb4  pextrw eax, xmm0, 0x03
0000703dbfbcfcb9  and eax, 0x7FF8
0000703dbfbcfcbe  cmp eax, 0x08
0000703dbfbcfcc1  jnz 0x0000703DBFBCF773
0000703dbfbcfcc7  movq rax, xmm15
0000703dbfbcfccc  shl rax, 0x0D
0000703dbfbcfcd0  jbe 0x0000703DBFBCF773
0000703dbfbcfcd6  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcfcde  jmp 0x0000703DBFBCF773
0000703dbfbcfce3  ucomisd xmm1, xmm15
0000703dbfbcfce8  jp 0x0000703DBFBCFCF7
0000703dbfbcfcea  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbcfcf2  jmp 0x0000703DBFBCF7A8
0000703dbfbcfcf7  vxorps xmm0, xmm1, xmm15
0000703dbfbcfcfc  pextrw eax, xmm0, 0x03
0000703dbfbcfd01  and eax, 0x7FF8
0000703dbfbcfd06  cmp eax, 0x08
0000703dbfbcfd09  jnz 0x0000703DBFBCF7A8
0000703dbfbcfd0f  movq rax, xmm15
0000703dbfbcfd14  shl rax, 0x0D
0000703dbfbcfd18  jbe 0x0000703DBFBCF7A8
0000703dbfbcfd1e  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbcfd26  jmp 0x0000703DBFBCF7A8
0000703dbfbcfd2b  call 0x0000703DBFAB4CB0
0000703dbfbcfd30  jmp 0x0000703DBFBCF7C7
0000703dbfbcfd35  int3
0000703dbfbcfd36  nop [rax+rax*1], ax
0000703dbfbcfd3f  nop
0000703dbfbcfd40  mov rax, [r15+0x60]
0000703dbfbcfd44  lea r14, [rax+0x01]
0000703dbfbcfd48  mov [r15+0x60], r14
0000703dbfbcfd4c  mov rax, [r15+0x68]
0000703dbfbcfd50  lea r12, [rax+0x40]
0000703dbfbcfd54  mov [r15+0x68], r12
0000703dbfbcfd58  xor eax, eax
0000703dbfbcfd5a  mov r12d, 0x08
0000703dbfbcfd60  cmp r14, r12
0000703dbfbcfd63  cmc
0000703dbfbcfd64  lahf
0000703dbfbcfd65  seto al
0000703dbfbcfd68  mov [r15+0x108], eax
0000703dbfbcfd6f  mov eax, [r15+0x108]
0000703dbfbcfd76  sahf
0000703dbfbcfd77  jnz 0x0000703DBFBCFDA9
0000703dbfbcfd79  cmp dword ptr [r15+0x318], 0x00
0000703dbfbcfd81  jz 0x0000703DBFBD08A0
0000703dbfbcfd87  nop [rax+rax*1], ax
0000703dbfbcfd90  nop [rax+rax*1], eax
0000703dbfbcfd98  mov eax, 0x410128
0000703dbfbcfd9d  mov [r15+0x100], rax
0000703dbfbcfda4  jmp 0x0000703DBF9FE110
0000703dbfbcfda9  cmp dword ptr [r15+0x318], 0x00
0000703dbfbcfdb1  jz 0x0000703DBFBCFDE0
0000703dbfbcfdb7  nop [rax+rax*1], ax
0000703dbfbcfdc0  nop [rax+rax*1], eax
0000703dbfbcfdc8  mov eax, 0x41008C
0000703dbfbcfdcd  mov [r15+0x100], rax
0000703dbfbcfdd4  jmp 0x0000703DBF9FE110
0000703dbfbcfdd9  int3
0000703dbfbcfdda  int3
0000703dbfbcfddb  nop [rax+rax*1], eax
0000703dbfbcfde0  mov rax, [r15+0x40]
0000703dbfbcfde4  mov r14, [r15+0x60]
0000703dbfbcfde8  shl r14, 0x06
0000703dbfbcfdec  lea r12, [rax+r14*1]
0000703dbfbcfdf0  mov rax, [r13+r12*1]
0000703dbfbcfdf5  lea r14, [r12+0x08]
0000703dbfbcfdfa  mov r11, [r13+r14*1]
0000703dbfbcfdff  movq xmm1, rax
0000703dbfbcfe04  movq xmm15, r11
0000703dbfbcfe09  movq xmm1, xmm1
0000703dbfbcfe0d  movq xmm1, xmm1
0000703dbfbcfe11  movaps [r15+0x120], xmm1
0000703dbfbcfe19  movq xmm15, xmm15
0000703dbfbcfe1e  movq xmm15, xmm15
0000703dbfbcfe23  movaps [r15+0x130], xmm15
0000703dbfbcfe2b  lea rax, [r12+0x10]
0000703dbfbcfe30  mov r14, [r13+rax*1]
0000703dbfbcfe35  lea rax, [r12+0x18]
0000703dbfbcfe3a  mov r11, [r13+rax*1]
0000703dbfbcfe3f  movq xmm1, r14
0000703dbfbcfe44  movq xmm15, r11
0000703dbfbcfe49  movq xmm1, xmm1
0000703dbfbcfe4d  movq xmm1, xmm1
0000703dbfbcfe51  movaps [r15+0x140], xmm1
0000703dbfbcfe59  movq xmm15, xmm15
0000703dbfbcfe5e  movq xmm15, xmm15
0000703dbfbcfe63  movaps [r15+0x150], xmm15
0000703dbfbcfe6b  lea rax, [r12+0x20]
0000703dbfbcfe70  mov r14, [r13+rax*1]
0000703dbfbcfe75  lea rax, [r12+0x28]
0000703dbfbcfe7a  mov r11, [r13+rax*1]
0000703dbfbcfe7f  movq xmm1, r14
0000703dbfbcfe84  movq xmm15, r11
0000703dbfbcfe89  movq xmm1, xmm1
0000703dbfbcfe8d  movq xmm1, xmm1
0000703dbfbcfe91  movaps [r15+0x160], xmm1
0000703dbfbcfe99  movq xmm15, xmm15
0000703dbfbcfe9e  movq xmm15, xmm15
0000703dbfbcfea3  movaps [r15+0x170], xmm15
0000703dbfbcfeab  lea rax, [r12+0x30]
0000703dbfbcfeb0  mov r14, [r13+rax*1]
0000703dbfbcfeb5  lea rax, [r12+0x38]
0000703dbfbcfeba  mov r12, [r13+rax*1]
0000703dbfbcfebf  movq xmm1, r14
0000703dbfbcfec4  movq xmm15, r12
0000703dbfbcfec9  movq xmm1, xmm1
0000703dbfbcfecd  movq xmm1, xmm1
0000703dbfbcfed1  movaps [r15+0x180], xmm1
0000703dbfbcfed9  movq xmm15, xmm15
0000703dbfbcfede  movq xmm15, xmm15
0000703dbfbcfee3  movaps [r15+0x210], xmm15
0000703dbfbcfeeb  mov rax, [r15+0x48]
0000703dbfbcfeef  mov [r15+0x78], rax
0000703dbfbcfef3  mov r14, [r13+rax*1]
0000703dbfbcfef8  movq xmm1, r14
0000703dbfbcfefd  lea r14, [rax+0x40]
0000703dbfbcff01  mov r12, [r13+r14*1]
0000703dbfbcff06  movq xmm15, r12
0000703dbfbcff0b  lea r14, [rax+0x80]
0000703dbfbcff12  mov r12, [r13+r14*1]
0000703dbfbcff17  movq xmm14, r12
0000703dbfbcff1c  movaps xmm13, [r15+0x120]
0000703dbfbcff24  movq r14, xmm13
0000703dbfbcff29  movq r12, xmm1
0000703dbfbcff2e  vmovq xmm1, r14
0000703dbfbcff33  vmovq xmm13, r12
0000703dbfbcff38  movaps xmm12, xmm1
0000703dbfbcff3c  mulsd xmm12, xmm13
0000703dbfbcff41  ucomisd xmm12, xmm12
0000703dbfbcff46  jp 0x0000703DBFBD03AD
0000703dbfbcff4c  movq xmm12, xmm12
0000703dbfbcff51  movaps xmm1, [r15+0x130]
0000703dbfbcff59  movq r14, xmm1
0000703dbfbcff5e  movq r12, xmm15
0000703dbfbcff63  vmovq xmm1, r14
0000703dbfbcff68  vmovq xmm15, r12
0000703dbfbcff6d  movaps xmm13, xmm1
0000703dbfbcff71  mulsd xmm13, xmm15
0000703dbfbcff76  ucomisd xmm13, xmm13
0000703dbfbcff7b  jp 0x0000703DBFBD03F9
0000703dbfbcff81  movq xmm13, xmm13
0000703dbfbcff86  movq r14, xmm12
0000703dbfbcff8b  movaps xmm1, [r15+0x110]
0000703dbfbcff93  movq r12, xmm1
0000703dbfbcff98  vmovq xmm1, r14
0000703dbfbcff9d  vmovq xmm15, r12
0000703dbfbcffa2  movaps xmm12, xmm1
0000703dbfbcffa6  addsd xmm12, xmm15
0000703dbfbcffab  ucomisd xmm12, xmm12
0000703dbfbcffb0  jp 0x0000703DBFBD0445
0000703dbfbcffb6  movq xmm12, xmm12
0000703dbfbcffbb  movq r14, xmm12
0000703dbfbcffc0  movq r12, xmm13
0000703dbfbcffc5  vmovq xmm1, r14
0000703dbfbcffca  vmovq xmm15, r12
0000703dbfbcffcf  movaps xmm13, xmm1
0000703dbfbcffd3  addsd xmm13, xmm15
0000703dbfbcffd8  ucomisd xmm13, xmm13
0000703dbfbcffdd  jp 0x0000703DBFBD0491
0000703dbfbcffe3  movq xmm13, xmm13
0000703dbfbcffe8  movaps xmm1, [r15+0x140]
0000703dbfbcfff0  movq r14, xmm1
0000703dbfbcfff5  movq r12, xmm14
0000703dbfbcfffa  vmovq xmm1, r14
0000703dbfbcffff  vmovq xmm15, r12
0000703dbfbd0004  movaps xmm14, xmm1
0000703dbfbd0008  mulsd xmm14, xmm15
0000703dbfbd000d  ucomisd xmm14, xmm14
0000703dbfbd0012  jp 0x0000703DBFBD04DD
0000703dbfbd0018  movq xmm14, xmm14
0000703dbfbd001d  lea r14, [rax+0xC0]
0000703dbfbd0024  mov r12, [r13+r14*1]
0000703dbfbd0029  movq xmm1, r12
0000703dbfbd002e  movq r14, xmm13
0000703dbfbd0033  movq r12, xmm14
0000703dbfbd0038  vmovq xmm15, r14
0000703dbfbd003d  vmovq xmm14, r12
0000703dbfbd0042  movaps xmm13, xmm15
0000703dbfbd0046  addsd xmm13, xmm14
0000703dbfbd004b  ucomisd xmm13, xmm13
0000703dbfbd0050  jp 0x0000703DBFBD0533
0000703dbfbd0056  movq xmm13, xmm13
0000703dbfbd005b  movaps xmm15, [r15+0x150]
0000703dbfbd0063  movq r14, xmm15
0000703dbfbd0068  movq r12, xmm1
0000703dbfbd006d  vmovq xmm1, r14
0000703dbfbd0072  vmovq xmm15, r12
0000703dbfbd0077  movaps xmm14, xmm1
0000703dbfbd007b  mulsd xmm14, xmm15
0000703dbfbd0080  ucomisd xmm14, xmm14
0000703dbfbd0085  jp 0x0000703DBFBD057F
0000703dbfbd008b  movq xmm14, xmm14
0000703dbfbd0090  lea r14, [rax+0x100]
0000703dbfbd0097  mov r12, [r13+r14*1]
0000703dbfbd009c  movq xmm1, r12
0000703dbfbd00a1  movq r14, xmm13
0000703dbfbd00a6  movq r12, xmm14
0000703dbfbd00ab  vmovq xmm15, r14
0000703dbfbd00b0  vmovq xmm14, r12
0000703dbfbd00b5  movaps xmm13, xmm15
0000703dbfbd00b9  addsd xmm13, xmm14
0000703dbfbd00be  ucomisd xmm13, xmm13
0000703dbfbd00c3  jp 0x0000703DBFBD05D5
0000703dbfbd00c9  movq xmm13, xmm13
0000703dbfbd00ce  movaps xmm15, [r15+0x160]
0000703dbfbd00d6  movq r14, xmm15
0000703dbfbd00db  movq r12, xmm1
0000703dbfbd00e0  vmovq xmm1, r14
0000703dbfbd00e5  vmovq xmm15, r12
0000703dbfbd00ea  movaps xmm14, xmm1
0000703dbfbd00ee  mulsd xmm14, xmm15
0000703dbfbd00f3  ucomisd xmm14, xmm14
0000703dbfbd00f8  jp 0x0000703DBFBD0621
0000703dbfbd00fe  movq xmm14, xmm14
0000703dbfbd0103  lea r14, [rax+0x140]
0000703dbfbd010a  mov r12, [r13+r14*1]
0000703dbfbd010f  movq xmm1, r12
0000703dbfbd0114  movq r14, xmm13
0000703dbfbd0119  movq r12, xmm14
0000703dbfbd011e  vmovq xmm15, r14
0000703dbfbd0123  vmovq xmm14, r12
0000703dbfbd0128  movaps xmm13, xmm15
0000703dbfbd012c  addsd xmm13, xmm14
0000703dbfbd0131  ucomisd xmm13, xmm13
0000703dbfbd0136  jp 0x0000703DBFBD0677
0000703dbfbd013c  movq xmm13, xmm13
0000703dbfbd0141  movaps xmm15, [r15+0x170]
0000703dbfbd0149  movq r14, xmm15
0000703dbfbd014e  movq r12, xmm1
0000703dbfbd0153  vmovq xmm1, r14
0000703dbfbd0158  vmovq xmm15, r12
0000703dbfbd015d  movaps xmm14, xmm1
0000703dbfbd0161  mulsd xmm14, xmm15
0000703dbfbd0166  ucomisd xmm14, xmm14
0000703dbfbd016b  jp 0x0000703DBFBD06C3
0000703dbfbd0171  movq xmm14, xmm14
0000703dbfbd0176  lea r14, [rax+0x180]
0000703dbfbd017d  mov r12, [r13+r14*1]
0000703dbfbd0182  movq xmm1, r12
0000703dbfbd0187  movq r14, xmm13
0000703dbfbd018c  movq r12, xmm14
0000703dbfbd0191  vmovq xmm15, r14
0000703dbfbd0196  vmovq xmm14, r12
0000703dbfbd019b  movaps xmm13, xmm15
0000703dbfbd019f  addsd xmm13, xmm14
0000703dbfbd01a4  ucomisd xmm13, xmm13
0000703dbfbd01a9  jp 0x0000703DBFBD0719
0000703dbfbd01af  movq xmm13, xmm13
0000703dbfbd01b4  movaps xmm15, [r15+0x180]
0000703dbfbd01bc  movq r14, xmm15
0000703dbfbd01c1  movq r12, xmm1
0000703dbfbd01c6  vmovq xmm1, r14
0000703dbfbd01cb  vmovq xmm15, r12
0000703dbfbd01d0  movaps xmm14, xmm1
0000703dbfbd01d4  mulsd xmm14, xmm15
0000703dbfbd01d9  ucomisd xmm14, xmm14
0000703dbfbd01de  jp 0x0000703DBFBD0765
0000703dbfbd01e4  movq xmm14, xmm14
0000703dbfbd01e9  lea r14, [rax+0x1C0]
0000703dbfbd01f0  mov rax, [r13+r14*1]
0000703dbfbd01f5  movq xmm1, rax
0000703dbfbd01fa  movaps [r15+0x240], xmm1
0000703dbfbd0202  movq rax, xmm13
0000703dbfbd0207  movq r14, xmm14
0000703dbfbd020c  vmovq xmm15, rax
0000703dbfbd0211  vmovq xmm14, r14
0000703dbfbd0216  movaps xmm13, xmm15
0000703dbfbd021a  addsd xmm13, xmm14
0000703dbfbd021f  ucomisd xmm13, xmm13
0000703dbfbd0224  jp 0x0000703DBFBD07BB
0000703dbfbd022a  movq xmm13, xmm13
0000703dbfbd022f  movaps xmm15, [r15+0x210]
0000703dbfbd0237  movq rax, xmm15
0000703dbfbd023c  movq r14, xmm1
0000703dbfbd0241  vmovq xmm1, rax
0000703dbfbd0246  vmovq xmm15, r14
0000703dbfbd024b  movaps xmm14, xmm1
0000703dbfbd024f  mulsd xmm14, xmm15
0000703dbfbd0254  ucomisd xmm14, xmm14
0000703dbfbd0259  jp 0x0000703DBFBD0803
0000703dbfbd025f  movq xmm14, xmm14
0000703dbfbd0264  movaps [r15+0x230], xmm14
0000703dbfbd026c  movq rax, xmm13
0000703dbfbd0271  movq r14, xmm14
0000703dbfbd0276  vmovq xmm1, rax
0000703dbfbd027b  vmovq xmm15, r14
0000703dbfbd0280  movaps xmm14, xmm1
0000703dbfbd0284  addsd xmm14, xmm15
0000703dbfbd0289  ucomisd xmm14, xmm14
0000703dbfbd028e  jp 0x0000703DBFBD084B
0000703dbfbd0294  movq xmm14, xmm14
0000703dbfbd0299  movaps [r15+0x220], xmm14
0000703dbfbd02a1  mov rax, [r15+0x68]
0000703dbfbd02a5  movq r14, xmm14
0000703dbfbd02aa  mov [r13+rax*1], r14
0000703dbfbd02af  mov qword ptr [r15+0x70], 0x08
0000703dbfbd02b7  xor eax, eax
0000703dbfbd02b9  mov r14d, 0x08
0000703dbfbd02bf  mov r12d, 0x40
0000703dbfbd02c5  cmp r14, r12
0000703dbfbd02c8  cmc
0000703dbfbd02c9  lahf
0000703dbfbd02ca  seto al
0000703dbfbd02cd  mov [r15+0x108], eax
0000703dbfbd02d4  mov eax, [r15+0x108]
0000703dbfbd02db  sahf
0000703dbfbd02dc  jnz 0x0000703DBFBD030E
0000703dbfbd02de  cmp dword ptr [r15+0x318], 0x00
0000703dbfbd02e6  jz 0x0000703DBFBCFD40
0000703dbfbd02ec  nop [rax+rax*1], ax
0000703dbfbd02f5  nop [rax+rax*1], eax
0000703dbfbd02fd  mov eax, 0x410118
0000703dbfbd0302  mov [r15+0x100], rax
0000703dbfbd0309  jmp 0x0000703DBF9FE110
0000703dbfbd030e  cmp dword ptr [r15+0x318], 0x00
0000703dbfbd0316  jz 0x0000703DBFBCF3F0
0000703dbfbd031c  nop [rax+rax*1], ax
0000703dbfbd0325  nop [rax+rax*1], eax
0000703dbfbd032d  mov eax, 0x4100A4
0000703dbfbd0332  mov [r15+0x100], rax
0000703dbfbd0339  jmp 0x0000703DBF9FE110
0000703dbfbd033e  int3
0000703dbfbd033f  call 0x0000703DBFAB47C0
0000703dbfbd0344  jmp 0x0000703DBFBCFDF5
0000703dbfbd0349  call 0x0000703DBFAE1570
0000703dbfbd034e  jmp 0x0000703DBFBCFDFF
0000703dbfbd0353  call 0x0000703DBFA0DC20
0000703dbfbd0358  jmp 0x0000703DBFBCFE35
0000703dbfbd035d  call 0x0000703DBFA0A4B0
0000703dbfbd0362  jmp 0x0000703DBFBCFE3F
0000703dbfbd0367  call 0x0000703DBFA0DC20
0000703dbfbd036c  jmp 0x0000703DBFBCFE75
0000703dbfbd0371  call 0x0000703DBFA0A4B0
0000703dbfbd0376  jmp 0x0000703DBFBCFE7F
0000703dbfbd037b  call 0x0000703DBFA0DC20
0000703dbfbd0380  jmp 0x0000703DBFBCFEB5
0000703dbfbd0385  call 0x0000703DBFA0B720
0000703dbfbd038a  jmp 0x0000703DBFBCFEBF
0000703dbfbd038f  call 0x0000703DBFA0DC20
0000703dbfbd0394  jmp 0x0000703DBFBCFEF8
0000703dbfbd0399  call 0x0000703DBFAE27E0
0000703dbfbd039e  jmp 0x0000703DBFBCFF06
0000703dbfbd03a3  call 0x0000703DBFAE27E0
0000703dbfbd03a8  jmp 0x0000703DBFBCFF17
0000703dbfbd03ad  ucomisd xmm1, xmm13
0000703dbfbd03b2  jp 0x0000703DBFBD03C1
0000703dbfbd03b4  movaps xmm12, [0x0000703DBF7FE030]
0000703dbfbd03bc  jmp 0x0000703DBFBCFF4C
0000703dbfbd03c1  vxorps xmm0, xmm1, xmm13
0000703dbfbd03c6  pextrw r14d, xmm0, 0x03
0000703dbfbd03cc  and r14d, 0x7FF8
0000703dbfbd03d3  cmp r14d, 0x08
0000703dbfbd03d7  jnz 0x0000703DBFBCFF4C
0000703dbfbd03dd  movq r14, xmm13
0000703dbfbd03e2  shl r14, 0x0D
0000703dbfbd03e6  jbe 0x0000703DBFBCFF4C
0000703dbfbd03ec  vorps xmm12, xmm13, [0x0000703DBF7FE040]
0000703dbfbd03f4  jmp 0x0000703DBFBCFF4C
0000703dbfbd03f9  ucomisd xmm1, xmm15
0000703dbfbd03fe  jp 0x0000703DBFBD040D
0000703dbfbd0400  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd0408  jmp 0x0000703DBFBCFF81
0000703dbfbd040d  vxorps xmm0, xmm1, xmm15
0000703dbfbd0412  pextrw r14d, xmm0, 0x03
0000703dbfbd0418  and r14d, 0x7FF8
0000703dbfbd041f  cmp r14d, 0x08
0000703dbfbd0423  jnz 0x0000703DBFBCFF81
0000703dbfbd0429  movq r14, xmm15
0000703dbfbd042e  shl r14, 0x0D
0000703dbfbd0432  jbe 0x0000703DBFBCFF81
0000703dbfbd0438  vorps xmm13, xmm15, [0x0000703DBF7FE040]
0000703dbfbd0440  jmp 0x0000703DBFBCFF81
0000703dbfbd0445  ucomisd xmm1, xmm15
0000703dbfbd044a  jp 0x0000703DBFBD0459
0000703dbfbd044c  movaps xmm12, [0x0000703DBF7FE030]
0000703dbfbd0454  jmp 0x0000703DBFBCFFB6
0000703dbfbd0459  vxorps xmm0, xmm1, xmm15
0000703dbfbd045e  pextrw r14d, xmm0, 0x03
0000703dbfbd0464  and r14d, 0x7FF8
0000703dbfbd046b  cmp r14d, 0x08
0000703dbfbd046f  jnz 0x0000703DBFBCFFB6
0000703dbfbd0475  movq r14, xmm15
0000703dbfbd047a  shl r14, 0x0D
0000703dbfbd047e  jbe 0x0000703DBFBCFFB6
0000703dbfbd0484  vorps xmm12, xmm15, [0x0000703DBF7FE040]
0000703dbfbd048c  jmp 0x0000703DBFBCFFB6
0000703dbfbd0491  ucomisd xmm1, xmm15
0000703dbfbd0496  jp 0x0000703DBFBD04A5
0000703dbfbd0498  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd04a0  jmp 0x0000703DBFBCFFE3
0000703dbfbd04a5  vxorps xmm0, xmm1, xmm15
0000703dbfbd04aa  pextrw r14d, xmm0, 0x03
0000703dbfbd04b0  and r14d, 0x7FF8
0000703dbfbd04b7  cmp r14d, 0x08
0000703dbfbd04bb  jnz 0x0000703DBFBCFFE3
0000703dbfbd04c1  movq r14, xmm15
0000703dbfbd04c6  shl r14, 0x0D
0000703dbfbd04ca  jbe 0x0000703DBFBCFFE3
0000703dbfbd04d0  vorps xmm13, xmm15, [0x0000703DBF7FE040]
0000703dbfbd04d8  jmp 0x0000703DBFBCFFE3
0000703dbfbd04dd  ucomisd xmm1, xmm15
0000703dbfbd04e2  jp 0x0000703DBFBD04F1
0000703dbfbd04e4  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd04ec  jmp 0x0000703DBFBD0018
0000703dbfbd04f1  vxorps xmm0, xmm1, xmm15
0000703dbfbd04f6  pextrw r14d, xmm0, 0x03
0000703dbfbd04fc  and r14d, 0x7FF8
0000703dbfbd0503  cmp r14d, 0x08
0000703dbfbd0507  jnz 0x0000703DBFBD0018
0000703dbfbd050d  movq r14, xmm15
0000703dbfbd0512  shl r14, 0x0D
0000703dbfbd0516  jbe 0x0000703DBFBD0018
0000703dbfbd051c  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd0524  jmp 0x0000703DBFBD0018
0000703dbfbd0529  call 0x0000703DBFAE27E0
0000703dbfbd052e  jmp 0x0000703DBFBD0029
0000703dbfbd0533  ucomisd xmm15, xmm14
0000703dbfbd0538  jp 0x0000703DBFBD0547
0000703dbfbd053a  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd0542  jmp 0x0000703DBFBD0056
0000703dbfbd0547  vxorps xmm0, xmm15, xmm14
0000703dbfbd054c  pextrw r14d, xmm0, 0x03
0000703dbfbd0552  and r14d, 0x7FF8
0000703dbfbd0559  cmp r14d, 0x08
0000703dbfbd055d  jnz 0x0000703DBFBD0056
0000703dbfbd0563  movq r14, xmm14
0000703dbfbd0568  shl r14, 0x0D
0000703dbfbd056c  jbe 0x0000703DBFBD0056
0000703dbfbd0572  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbd057a  jmp 0x0000703DBFBD0056
0000703dbfbd057f  ucomisd xmm1, xmm15
0000703dbfbd0584  jp 0x0000703DBFBD0593
0000703dbfbd0586  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd058e  jmp 0x0000703DBFBD008B
0000703dbfbd0593  vxorps xmm0, xmm1, xmm15
0000703dbfbd0598  pextrw r14d, xmm0, 0x03
0000703dbfbd059e  and r14d, 0x7FF8
0000703dbfbd05a5  cmp r14d, 0x08
0000703dbfbd05a9  jnz 0x0000703DBFBD008B
0000703dbfbd05af  movq r14, xmm15
0000703dbfbd05b4  shl r14, 0x0D
0000703dbfbd05b8  jbe 0x0000703DBFBD008B
0000703dbfbd05be  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd05c6  jmp 0x0000703DBFBD008B
0000703dbfbd05cb  call 0x0000703DBFAE27E0
0000703dbfbd05d0  jmp 0x0000703DBFBD009C
0000703dbfbd05d5  ucomisd xmm15, xmm14
0000703dbfbd05da  jp 0x0000703DBFBD05E9
0000703dbfbd05dc  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd05e4  jmp 0x0000703DBFBD00C9
0000703dbfbd05e9  vxorps xmm0, xmm15, xmm14
0000703dbfbd05ee  pextrw r14d, xmm0, 0x03
0000703dbfbd05f4  and r14d, 0x7FF8
0000703dbfbd05fb  cmp r14d, 0x08
0000703dbfbd05ff  jnz 0x0000703DBFBD00C9
0000703dbfbd0605  movq r14, xmm14
0000703dbfbd060a  shl r14, 0x0D
0000703dbfbd060e  jbe 0x0000703DBFBD00C9
0000703dbfbd0614  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbd061c  jmp 0x0000703DBFBD00C9
0000703dbfbd0621  ucomisd xmm1, xmm15
0000703dbfbd0626  jp 0x0000703DBFBD0635
0000703dbfbd0628  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd0630  jmp 0x0000703DBFBD00FE
0000703dbfbd0635  vxorps xmm0, xmm1, xmm15
0000703dbfbd063a  pextrw r14d, xmm0, 0x03
0000703dbfbd0640  and r14d, 0x7FF8
0000703dbfbd0647  cmp r14d, 0x08
0000703dbfbd064b  jnz 0x0000703DBFBD00FE
0000703dbfbd0651  movq r14, xmm15
0000703dbfbd0656  shl r14, 0x0D
0000703dbfbd065a  jbe 0x0000703DBFBD00FE
0000703dbfbd0660  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd0668  jmp 0x0000703DBFBD00FE
0000703dbfbd066d  call 0x0000703DBFAE27E0
0000703dbfbd0672  jmp 0x0000703DBFBD010F
0000703dbfbd0677  ucomisd xmm15, xmm14
0000703dbfbd067c  jp 0x0000703DBFBD068B
0000703dbfbd067e  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd0686  jmp 0x0000703DBFBD013C
0000703dbfbd068b  vxorps xmm0, xmm15, xmm14
0000703dbfbd0690  pextrw r14d, xmm0, 0x03
0000703dbfbd0696  and r14d, 0x7FF8
0000703dbfbd069d  cmp r14d, 0x08
0000703dbfbd06a1  jnz 0x0000703DBFBD013C
0000703dbfbd06a7  movq r14, xmm14
0000703dbfbd06ac  shl r14, 0x0D
0000703dbfbd06b0  jbe 0x0000703DBFBD013C
0000703dbfbd06b6  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbd06be  jmp 0x0000703DBFBD013C
0000703dbfbd06c3  ucomisd xmm1, xmm15
0000703dbfbd06c8  jp 0x0000703DBFBD06D7
0000703dbfbd06ca  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd06d2  jmp 0x0000703DBFBD0171
0000703dbfbd06d7  vxorps xmm0, xmm1, xmm15
0000703dbfbd06dc  pextrw r14d, xmm0, 0x03
0000703dbfbd06e2  and r14d, 0x7FF8
0000703dbfbd06e9  cmp r14d, 0x08
0000703dbfbd06ed  jnz 0x0000703DBFBD0171
0000703dbfbd06f3  movq r14, xmm15
0000703dbfbd06f8  shl r14, 0x0D
0000703dbfbd06fc  jbe 0x0000703DBFBD0171
0000703dbfbd0702  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd070a  jmp 0x0000703DBFBD0171
0000703dbfbd070f  call 0x0000703DBFAE27E0
0000703dbfbd0714  jmp 0x0000703DBFBD0182
0000703dbfbd0719  ucomisd xmm15, xmm14
0000703dbfbd071e  jp 0x0000703DBFBD072D
0000703dbfbd0720  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd0728  jmp 0x0000703DBFBD01AF
0000703dbfbd072d  vxorps xmm0, xmm15, xmm14
0000703dbfbd0732  pextrw r14d, xmm0, 0x03
0000703dbfbd0738  and r14d, 0x7FF8
0000703dbfbd073f  cmp r14d, 0x08
0000703dbfbd0743  jnz 0x0000703DBFBD01AF
0000703dbfbd0749  movq r14, xmm14
0000703dbfbd074e  shl r14, 0x0D
0000703dbfbd0752  jbe 0x0000703DBFBD01AF
0000703dbfbd0758  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbd0760  jmp 0x0000703DBFBD01AF
0000703dbfbd0765  ucomisd xmm1, xmm15
0000703dbfbd076a  jp 0x0000703DBFBD0779
0000703dbfbd076c  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd0774  jmp 0x0000703DBFBD01E4
0000703dbfbd0779  vxorps xmm0, xmm1, xmm15
0000703dbfbd077e  pextrw r14d, xmm0, 0x03
0000703dbfbd0784  and r14d, 0x7FF8
0000703dbfbd078b  cmp r14d, 0x08
0000703dbfbd078f  jnz 0x0000703DBFBD01E4
0000703dbfbd0795  movq r14, xmm15
0000703dbfbd079a  shl r14, 0x0D
0000703dbfbd079e  jbe 0x0000703DBFBD01E4
0000703dbfbd07a4  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd07ac  jmp 0x0000703DBFBD01E4
0000703dbfbd07b1  call 0x0000703DBFAD59C0
0000703dbfbd07b6  jmp 0x0000703DBFBD01F5
0000703dbfbd07bb  ucomisd xmm15, xmm14
0000703dbfbd07c0  jp 0x0000703DBFBD07CF
0000703dbfbd07c2  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd07ca  jmp 0x0000703DBFBD022A
0000703dbfbd07cf  vxorps xmm0, xmm15, xmm14
0000703dbfbd07d4  pextrw eax, xmm0, 0x03
0000703dbfbd07d9  and eax, 0x7FF8
0000703dbfbd07de  cmp eax, 0x08
0000703dbfbd07e1  jnz 0x0000703DBFBD022A
0000703dbfbd07e7  movq rax, xmm14
0000703dbfbd07ec  shl rax, 0x0D
0000703dbfbd07f0  jbe 0x0000703DBFBD022A
0000703dbfbd07f6  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbd07fe  jmp 0x0000703DBFBD022A
0000703dbfbd0803  ucomisd xmm1, xmm15
0000703dbfbd0808  jp 0x0000703DBFBD0817
0000703dbfbd080a  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd0812  jmp 0x0000703DBFBD025F
0000703dbfbd0817  vxorps xmm0, xmm1, xmm15
0000703dbfbd081c  pextrw eax, xmm0, 0x03
0000703dbfbd0821  and eax, 0x7FF8
0000703dbfbd0826  cmp eax, 0x08
0000703dbfbd0829  jnz 0x0000703DBFBD025F
0000703dbfbd082f  movq rax, xmm15
0000703dbfbd0834  shl rax, 0x0D
0000703dbfbd0838  jbe 0x0000703DBFBD025F
0000703dbfbd083e  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd0846  jmp 0x0000703DBFBD025F
0000703dbfbd084b  ucomisd xmm1, xmm15
0000703dbfbd0850  jp 0x0000703DBFBD085F
0000703dbfbd0852  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd085a  jmp 0x0000703DBFBD0294
0000703dbfbd085f  vxorps xmm0, xmm1, xmm15
0000703dbfbd0864  pextrw eax, xmm0, 0x03
0000703dbfbd0869  and eax, 0x7FF8
0000703dbfbd086e  cmp eax, 0x08
0000703dbfbd0871  jnz 0x0000703DBFBD0294
0000703dbfbd0877  movq rax, xmm15
0000703dbfbd087c  shl rax, 0x0D
0000703dbfbd0880  jbe 0x0000703DBFBD0294
0000703dbfbd0886  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd088e  jmp 0x0000703DBFBD0294
0000703dbfbd0893  call 0x0000703DBFA0E120
0000703dbfbd0898  jmp 0x0000703DBFBD02AF
0000703dbfbd089d  int3
0000703dbfbd089e  nop
0000703dbfbd08a0  mov eax, [r15+0x58]
0000703dbfbd08a4  lea r14d, [eax+0x01]
0000703dbfbd08a9  mov [rsp+0x10], r14d
0000703dbfbd08ae  mov r14d, r14d
0000703dbfbd08b1  mov [r15+0x58], r14
0000703dbfbd08b5  xor eax, eax
0000703dbfbd08b7  mov r14d, [rsp+0x10]
0000703dbfbd08bc  cmp r14d, 0x1F4
0000703dbfbd08c3  cmc
0000703dbfbd08c4  lahf
0000703dbfbd08c5  seto al
0000703dbfbd08c8  mov [r15+0x108], eax
0000703dbfbd08cf  mov eax, [r15+0x108]
0000703dbfbd08d6  sahf
0000703dbfbd08d7  jnz 0x0000703DBFBD0909
0000703dbfbd08d9  cmp dword ptr [r15+0x318], 0x00
0000703dbfbd08e1  jz 0x0000703DBFBD1410
0000703dbfbd08e7  nop [rax+rax*1], ax
0000703dbfbd08f0  nop [rax+rax*1], eax
0000703dbfbd08f8  mov eax, 0x410134
0000703dbfbd08fd  mov [r15+0x100], rax
0000703dbfbd0904  jmp 0x0000703DBF9FE110
0000703dbfbd0909  cmp dword ptr [r15+0x318], 0x00
0000703dbfbd0911  jz 0x0000703DBFBD0940
0000703dbfbd0917  nop [rax+rax*1], ax
0000703dbfbd0920  nop [rax+rax*1], eax
0000703dbfbd0928  mov eax, 0x410084
0000703dbfbd092d  mov [r15+0x100], rax
0000703dbfbd0934  jmp 0x0000703DBF9FE110
0000703dbfbd0939  int3
0000703dbfbd093a  int3
0000703dbfbd093b  nop [rax+rax*1], eax
0000703dbfbd0940  mov qword ptr [r15+0x60], 0x00
0000703dbfbd0948  mov rax, [r15+0x50]
0000703dbfbd094c  mov [r15+0x68], rax
0000703dbfbd0950  mov r14, [r15+0x40]
0000703dbfbd0954  mov r12, [r13+r14*1]
0000703dbfbd0959  lea r11, [r14+0x08]
0000703dbfbd095d  mov r10, [r13+r11*1]
0000703dbfbd0962  movq xmm1, r12
0000703dbfbd0967  movq xmm15, r10
0000703dbfbd096c  movq xmm1, xmm1
0000703dbfbd0970  movq xmm1, xmm1
0000703dbfbd0974  movaps [r15+0x120], xmm1
0000703dbfbd097c  movq xmm15, xmm15
0000703dbfbd0981  movq xmm15, xmm15
0000703dbfbd0986  movaps [r15+0x130], xmm15
0000703dbfbd098e  lea r12, [r14+0x10]
0000703dbfbd0992  mov r11, [r13+r12*1]
0000703dbfbd0997  lea r12, [r14+0x18]
0000703dbfbd099b  mov r10, [r13+r12*1]
0000703dbfbd09a0  movq xmm1, r11
0000703dbfbd09a5  movq xmm15, r10
0000703dbfbd09aa  movq xmm1, xmm1
0000703dbfbd09ae  movq xmm1, xmm1
0000703dbfbd09b2  movaps [r15+0x140], xmm1
0000703dbfbd09ba  movq xmm15, xmm15
0000703dbfbd09bf  movq xmm15, xmm15
0000703dbfbd09c4  movaps [r15+0x150], xmm15
0000703dbfbd09cc  lea r12, [r14+0x20]
0000703dbfbd09d0  mov r11, [r13+r12*1]
0000703dbfbd09d5  lea r12, [r14+0x28]
0000703dbfbd09d9  mov r10, [r13+r12*1]
0000703dbfbd09de  movq xmm1, r11
0000703dbfbd09e3  movq xmm15, r10
0000703dbfbd09e8  movq xmm1, xmm1
0000703dbfbd09ec  movq xmm1, xmm1
0000703dbfbd09f0  movaps [r15+0x160], xmm1
0000703dbfbd09f8  movq xmm15, xmm15
0000703dbfbd09fd  movq xmm15, xmm15
0000703dbfbd0a02  movaps [r15+0x170], xmm15
0000703dbfbd0a0a  lea r12, [r14+0x30]
0000703dbfbd0a0e  mov r11, [r13+r12*1]
0000703dbfbd0a13  lea r12, [r14+0x38]
0000703dbfbd0a17  mov r14, [r13+r12*1]
0000703dbfbd0a1c  movq xmm1, r11
0000703dbfbd0a21  movq xmm15, r14
0000703dbfbd0a26  movq xmm1, xmm1
0000703dbfbd0a2a  movq xmm1, xmm1
0000703dbfbd0a2e  movaps [r15+0x180], xmm1
0000703dbfbd0a36  movq xmm15, xmm15
0000703dbfbd0a3b  movq xmm15, xmm15
0000703dbfbd0a40  movaps [r15+0x210], xmm15
0000703dbfbd0a48  mov r14, [r15+0x48]
0000703dbfbd0a4c  mov [r15+0x78], r14
0000703dbfbd0a50  mov r12, [r13+r14*1]
0000703dbfbd0a55  movq xmm1, r12
0000703dbfbd0a5a  lea r12, [r14+0x40]
0000703dbfbd0a5e  mov r11, [r13+r12*1]
0000703dbfbd0a63  movq xmm15, r11
0000703dbfbd0a68  lea r12, [r14+0x80]
0000703dbfbd0a6f  mov r11, [r13+r12*1]
0000703dbfbd0a74  movq xmm14, r11
0000703dbfbd0a79  movaps xmm13, [r15+0x120]
0000703dbfbd0a81  movq r12, xmm13
0000703dbfbd0a86  movq r11, xmm1
0000703dbfbd0a8b  vmovq xmm1, r12
0000703dbfbd0a90  vmovq xmm13, r11
0000703dbfbd0a95  movaps xmm12, xmm1
0000703dbfbd0a99  mulsd xmm12, xmm13
0000703dbfbd0a9e  ucomisd xmm12, xmm12
0000703dbfbd0aa3  jp 0x0000703DBFBD0F06
0000703dbfbd0aa9  movq xmm12, xmm12
0000703dbfbd0aae  movaps xmm1, [r15+0x130]
0000703dbfbd0ab6  movq r12, xmm1
0000703dbfbd0abb  movq r11, xmm15
0000703dbfbd0ac0  vmovq xmm1, r12
0000703dbfbd0ac5  vmovq xmm15, r11
0000703dbfbd0aca  movaps xmm13, xmm1
0000703dbfbd0ace  mulsd xmm13, xmm15
0000703dbfbd0ad3  ucomisd xmm13, xmm13
0000703dbfbd0ad8  jp 0x0000703DBFBD0F52
0000703dbfbd0ade  movq xmm13, xmm13
0000703dbfbd0ae3  movq r12, xmm12
0000703dbfbd0ae8  movaps xmm1, [r15+0x110]
0000703dbfbd0af0  movq r11, xmm1
0000703dbfbd0af5  vmovq xmm1, r12
0000703dbfbd0afa  vmovq xmm15, r11
0000703dbfbd0aff  movaps xmm12, xmm1
0000703dbfbd0b03  addsd xmm12, xmm15
0000703dbfbd0b08  ucomisd xmm12, xmm12
0000703dbfbd0b0d  jp 0x0000703DBFBD0F9E
0000703dbfbd0b13  movq xmm12, xmm12
0000703dbfbd0b18  movq r12, xmm12
0000703dbfbd0b1d  movq r11, xmm13
0000703dbfbd0b22  vmovq xmm1, r12
0000703dbfbd0b27  vmovq xmm15, r11
0000703dbfbd0b2c  movaps xmm13, xmm1
0000703dbfbd0b30  addsd xmm13, xmm15
0000703dbfbd0b35  ucomisd xmm13, xmm13
0000703dbfbd0b3a  jp 0x0000703DBFBD0FEA
0000703dbfbd0b40  movq xmm13, xmm13
0000703dbfbd0b45  movaps xmm1, [r15+0x140]
0000703dbfbd0b4d  movq r12, xmm1
0000703dbfbd0b52  movq r11, xmm14
0000703dbfbd0b57  vmovq xmm1, r12
0000703dbfbd0b5c  vmovq xmm15, r11
0000703dbfbd0b61  movaps xmm14, xmm1
0000703dbfbd0b65  mulsd xmm14, xmm15
0000703dbfbd0b6a  ucomisd xmm14, xmm14
0000703dbfbd0b6f  jp 0x0000703DBFBD1036
0000703dbfbd0b75  movq xmm14, xmm14
0000703dbfbd0b7a  lea r12, [r14+0xC0]
0000703dbfbd0b81  mov r11, [r13+r12*1]
0000703dbfbd0b86  movq xmm1, r11
0000703dbfbd0b8b  movq r12, xmm13
0000703dbfbd0b90  movq r11, xmm14
0000703dbfbd0b95  vmovq xmm15, r12
0000703dbfbd0b9a  vmovq xmm14, r11
0000703dbfbd0b9f  movaps xmm13, xmm15
0000703dbfbd0ba3  addsd xmm13, xmm14
0000703dbfbd0ba8  ucomisd xmm13, xmm13
0000703dbfbd0bad  jp 0x0000703DBFBD108C
0000703dbfbd0bb3  movq xmm13, xmm13
0000703dbfbd0bb8  movaps xmm15, [r15+0x150]
0000703dbfbd0bc0  movq r12, xmm15
0000703dbfbd0bc5  movq r11, xmm1
0000703dbfbd0bca  vmovq xmm1, r12
0000703dbfbd0bcf  vmovq xmm15, r11
0000703dbfbd0bd4  movaps xmm14, xmm1
0000703dbfbd0bd8  mulsd xmm14, xmm15
0000703dbfbd0bdd  ucomisd xmm14, xmm14
0000703dbfbd0be2  jp 0x0000703DBFBD10D8
0000703dbfbd0be8  movq xmm14, xmm14
0000703dbfbd0bed  lea r12, [r14+0x100]
0000703dbfbd0bf4  mov r11, [r13+r12*1]
0000703dbfbd0bf9  movq xmm1, r11
0000703dbfbd0bfe  movq r12, xmm13
0000703dbfbd0c03  movq r11, xmm14
0000703dbfbd0c08  vmovq xmm15, r12
0000703dbfbd0c0d  vmovq xmm14, r11
0000703dbfbd0c12  movaps xmm13, xmm15
0000703dbfbd0c16  addsd xmm13, xmm14
0000703dbfbd0c1b  ucomisd xmm13, xmm13
0000703dbfbd0c20  jp 0x0000703DBFBD112E
0000703dbfbd0c26  movq xmm13, xmm13
0000703dbfbd0c2b  movaps xmm15, [r15+0x160]
0000703dbfbd0c33  movq r12, xmm15
0000703dbfbd0c38  movq r11, xmm1
0000703dbfbd0c3d  vmovq xmm1, r12
0000703dbfbd0c42  vmovq xmm15, r11
0000703dbfbd0c47  movaps xmm14, xmm1
0000703dbfbd0c4b  mulsd xmm14, xmm15
0000703dbfbd0c50  ucomisd xmm14, xmm14
0000703dbfbd0c55  jp 0x0000703DBFBD117A
0000703dbfbd0c5b  movq xmm14, xmm14
0000703dbfbd0c60  lea r12, [r14+0x140]
0000703dbfbd0c67  mov r11, [r13+r12*1]
0000703dbfbd0c6c  movq xmm1, r11
0000703dbfbd0c71  movq r12, xmm13
0000703dbfbd0c76  movq r11, xmm14
0000703dbfbd0c7b  vmovq xmm15, r12
0000703dbfbd0c80  vmovq xmm14, r11
0000703dbfbd0c85  movaps xmm13, xmm15
0000703dbfbd0c89  addsd xmm13, xmm14
0000703dbfbd0c8e  ucomisd xmm13, xmm13
0000703dbfbd0c93  jp 0x0000703DBFBD11D0
0000703dbfbd0c99  movq xmm13, xmm13
0000703dbfbd0c9e  movaps xmm15, [r15+0x170]
0000703dbfbd0ca6  movq r12, xmm15
0000703dbfbd0cab  movq r11, xmm1
0000703dbfbd0cb0  vmovq xmm1, r12
0000703dbfbd0cb5  vmovq xmm15, r11
0000703dbfbd0cba  movaps xmm14, xmm1
0000703dbfbd0cbe  mulsd xmm14, xmm15
0000703dbfbd0cc3  ucomisd xmm14, xmm14
0000703dbfbd0cc8  jp 0x0000703DBFBD121C
0000703dbfbd0cce  movq xmm14, xmm14
0000703dbfbd0cd3  lea r12, [r14+0x180]
0000703dbfbd0cda  mov r11, [r13+r12*1]
0000703dbfbd0cdf  movq xmm1, r11
0000703dbfbd0ce4  movq r12, xmm13
0000703dbfbd0ce9  movq r11, xmm14
0000703dbfbd0cee  vmovq xmm15, r12
0000703dbfbd0cf3  vmovq xmm14, r11
0000703dbfbd0cf8  movaps xmm13, xmm15
0000703dbfbd0cfc  addsd xmm13, xmm14
0000703dbfbd0d01  ucomisd xmm13, xmm13
0000703dbfbd0d06  jp 0x0000703DBFBD1272
0000703dbfbd0d0c  movq xmm13, xmm13
0000703dbfbd0d11  movaps xmm15, [r15+0x180]
0000703dbfbd0d19  movq r12, xmm15
0000703dbfbd0d1e  movq r11, xmm1
0000703dbfbd0d23  vmovq xmm1, r12
0000703dbfbd0d28  vmovq xmm15, r11
0000703dbfbd0d2d  movaps xmm14, xmm1
0000703dbfbd0d31  mulsd xmm14, xmm15
0000703dbfbd0d36  ucomisd xmm14, xmm14
0000703dbfbd0d3b  jp 0x0000703DBFBD12BE
0000703dbfbd0d41  movq xmm14, xmm14
0000703dbfbd0d46  lea r12, [r14+0x1C0]
0000703dbfbd0d4d  mov r14, [r13+r12*1]
0000703dbfbd0d52  movq xmm1, r14
0000703dbfbd0d57  movaps [r15+0x240], xmm1
0000703dbfbd0d5f  movq r14, xmm13
0000703dbfbd0d64  movq r12, xmm14
0000703dbfbd0d69  vmovq xmm15, r14
0000703dbfbd0d6e  vmovq xmm14, r12
0000703dbfbd0d73  movaps xmm13, xmm15
0000703dbfbd0d77  addsd xmm13, xmm14
0000703dbfbd0d7c  ucomisd xmm13, xmm13
0000703dbfbd0d81  jp 0x0000703DBFBD1314
0000703dbfbd0d87  movq xmm13, xmm13
0000703dbfbd0d8c  movaps xmm15, [r15+0x210]
0000703dbfbd0d94  movq r14, xmm15
0000703dbfbd0d99  movq r12, xmm1
0000703dbfbd0d9e  vmovq xmm1, r14
0000703dbfbd0da3  vmovq xmm15, r12
0000703dbfbd0da8  movaps xmm14, xmm1
0000703dbfbd0dac  mulsd xmm14, xmm15
0000703dbfbd0db1  ucomisd xmm14, xmm14
0000703dbfbd0db6  jp 0x0000703DBFBD1360
0000703dbfbd0dbc  movq xmm14, xmm14
0000703dbfbd0dc1  movaps [r15+0x230], xmm14
0000703dbfbd0dc9  movq r14, xmm13
0000703dbfbd0dce  movq r12, xmm14
0000703dbfbd0dd3  vmovq xmm1, r14
0000703dbfbd0dd8  vmovq xmm15, r12
0000703dbfbd0ddd  movaps xmm14, xmm1
0000703dbfbd0de1  addsd xmm14, xmm15
0000703dbfbd0de6  ucomisd xmm14, xmm14
0000703dbfbd0deb  jp 0x0000703DBFBD13AC
0000703dbfbd0df1  movq xmm14, xmm14
0000703dbfbd0df6  movaps [r15+0x220], xmm14
0000703dbfbd0dfe  movq r14, xmm14
0000703dbfbd0e03  mov [r13+rax*1], r14
0000703dbfbd0e08  mov qword ptr [r15+0x70], 0x08
0000703dbfbd0e10  xor eax, eax
0000703dbfbd0e12  mov r14d, 0x08
0000703dbfbd0e18  mov r12d, 0x40
0000703dbfbd0e1e  cmp r14, r12
0000703dbfbd0e21  cmc
0000703dbfbd0e22  lahf
0000703dbfbd0e23  seto al
0000703dbfbd0e26  mov [r15+0x108], eax
0000703dbfbd0e2d  mov eax, [r15+0x108]
0000703dbfbd0e34  sahf
0000703dbfbd0e35  jnz 0x0000703DBFBD0E67
0000703dbfbd0e37  cmp dword ptr [r15+0x318], 0x00
0000703dbfbd0e3f  jz 0x0000703DBFBCFD40
0000703dbfbd0e45  nop [rax+rax*1], ax
0000703dbfbd0e4e  nop [rax+rax*1], eax
0000703dbfbd0e56  mov eax, 0x410118
0000703dbfbd0e5b  mov [r15+0x100], rax
0000703dbfbd0e62  jmp 0x0000703DBF9FE110
0000703dbfbd0e67  cmp dword ptr [r15+0x318], 0x00
0000703dbfbd0e6f  jz 0x0000703DBFBCF3F0
0000703dbfbd0e75  nop [rax+rax*1], ax
0000703dbfbd0e7e  nop [rax+rax*1], eax
0000703dbfbd0e86  mov eax, 0x4100A4
0000703dbfbd0e8b  mov [r15+0x100], rax
0000703dbfbd0e92  jmp 0x0000703DBF9FE110
0000703dbfbd0e97  int3
0000703dbfbd0e98  call 0x0000703DBFAE27E0
0000703dbfbd0e9d  jmp 0x0000703DBFBD0959
0000703dbfbd0ea2  call 0x0000703DBFAAE800
0000703dbfbd0ea7  jmp 0x0000703DBFBD0962
0000703dbfbd0eac  call 0x0000703DBFAC0370
0000703dbfbd0eb1  jmp 0x0000703DBFBD0997
0000703dbfbd0eb6  call 0x0000703DBFABF100
0000703dbfbd0ebb  jmp 0x0000703DBFBD09A0
0000703dbfbd0ec0  call 0x0000703DBFAC0370
0000703dbfbd0ec5  jmp 0x0000703DBFBD09D5
0000703dbfbd0eca  call 0x0000703DBFABF100
0000703dbfbd0ecf  jmp 0x0000703DBFBD09DE
0000703dbfbd0ed4  call 0x0000703DBFAC0370
0000703dbfbd0ed9  jmp 0x0000703DBFBD0A13
0000703dbfbd0ede  call 0x0000703DBFAC3AE0
0000703dbfbd0ee3  jmp 0x0000703DBFBD0A1C
0000703dbfbd0ee8  call 0x0000703DBFAE27E0
0000703dbfbd0eed  jmp 0x0000703DBFBD0A55
0000703dbfbd0ef2  call 0x0000703DBFAC0370
0000703dbfbd0ef7  jmp 0x0000703DBFBD0A63
0000703dbfbd0efc  call 0x0000703DBFAC0370
0000703dbfbd0f01  jmp 0x0000703DBFBD0A74
0000703dbfbd0f06  ucomisd xmm1, xmm13
0000703dbfbd0f0b  jp 0x0000703DBFBD0F1A
0000703dbfbd0f0d  movaps xmm12, [0x0000703DBF7FE030]
0000703dbfbd0f15  jmp 0x0000703DBFBD0AA9
0000703dbfbd0f1a  vxorps xmm0, xmm1, xmm13
0000703dbfbd0f1f  pextrw r12d, xmm0, 0x03
0000703dbfbd0f25  and r12d, 0x7FF8
0000703dbfbd0f2c  cmp r12d, 0x08
0000703dbfbd0f30  jnz 0x0000703DBFBD0AA9
0000703dbfbd0f36  movq r12, xmm13
0000703dbfbd0f3b  shl r12, 0x0D
0000703dbfbd0f3f  jbe 0x0000703DBFBD0AA9
0000703dbfbd0f45  vorps xmm12, xmm13, [0x0000703DBF7FE040]
0000703dbfbd0f4d  jmp 0x0000703DBFBD0AA9
0000703dbfbd0f52  ucomisd xmm1, xmm15
0000703dbfbd0f57  jp 0x0000703DBFBD0F66
0000703dbfbd0f59  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd0f61  jmp 0x0000703DBFBD0ADE
0000703dbfbd0f66  vxorps xmm0, xmm1, xmm15
0000703dbfbd0f6b  pextrw r12d, xmm0, 0x03
0000703dbfbd0f71  and r12d, 0x7FF8
0000703dbfbd0f78  cmp r12d, 0x08
0000703dbfbd0f7c  jnz 0x0000703DBFBD0ADE
0000703dbfbd0f82  movq r12, xmm15
0000703dbfbd0f87  shl r12, 0x0D
0000703dbfbd0f8b  jbe 0x0000703DBFBD0ADE
0000703dbfbd0f91  vorps xmm13, xmm15, [0x0000703DBF7FE040]
0000703dbfbd0f99  jmp 0x0000703DBFBD0ADE
0000703dbfbd0f9e  ucomisd xmm1, xmm15
0000703dbfbd0fa3  jp 0x0000703DBFBD0FB2
0000703dbfbd0fa5  movaps xmm12, [0x0000703DBF7FE030]
0000703dbfbd0fad  jmp 0x0000703DBFBD0B13
0000703dbfbd0fb2  vxorps xmm0, xmm1, xmm15
0000703dbfbd0fb7  pextrw r12d, xmm0, 0x03
0000703dbfbd0fbd  and r12d, 0x7FF8
0000703dbfbd0fc4  cmp r12d, 0x08
0000703dbfbd0fc8  jnz 0x0000703DBFBD0B13
0000703dbfbd0fce  movq r12, xmm15
0000703dbfbd0fd3  shl r12, 0x0D
0000703dbfbd0fd7  jbe 0x0000703DBFBD0B13
0000703dbfbd0fdd  vorps xmm12, xmm15, [0x0000703DBF7FE040]
0000703dbfbd0fe5  jmp 0x0000703DBFBD0B13
0000703dbfbd0fea  ucomisd xmm1, xmm15
0000703dbfbd0fef  jp 0x0000703DBFBD0FFE
0000703dbfbd0ff1  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd0ff9  jmp 0x0000703DBFBD0B40
0000703dbfbd0ffe  vxorps xmm0, xmm1, xmm15
0000703dbfbd1003  pextrw r12d, xmm0, 0x03
0000703dbfbd1009  and r12d, 0x7FF8
0000703dbfbd1010  cmp r12d, 0x08
0000703dbfbd1014  jnz 0x0000703DBFBD0B40
0000703dbfbd101a  movq r12, xmm15
0000703dbfbd101f  shl r12, 0x0D
0000703dbfbd1023  jbe 0x0000703DBFBD0B40
0000703dbfbd1029  vorps xmm13, xmm15, [0x0000703DBF7FE040]
0000703dbfbd1031  jmp 0x0000703DBFBD0B40
0000703dbfbd1036  ucomisd xmm1, xmm15
0000703dbfbd103b  jp 0x0000703DBFBD104A
0000703dbfbd103d  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd1045  jmp 0x0000703DBFBD0B75
0000703dbfbd104a  vxorps xmm0, xmm1, xmm15
0000703dbfbd104f  pextrw r12d, xmm0, 0x03
0000703dbfbd1055  and r12d, 0x7FF8
0000703dbfbd105c  cmp r12d, 0x08
0000703dbfbd1060  jnz 0x0000703DBFBD0B75
0000703dbfbd1066  movq r12, xmm15
0000703dbfbd106b  shl r12, 0x0D
0000703dbfbd106f  jbe 0x0000703DBFBD0B75
0000703dbfbd1075  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd107d  jmp 0x0000703DBFBD0B75
0000703dbfbd1082  call 0x0000703DBFAC0370
0000703dbfbd1087  jmp 0x0000703DBFBD0B86
0000703dbfbd108c  ucomisd xmm15, xmm14
0000703dbfbd1091  jp 0x0000703DBFBD10A0
0000703dbfbd1093  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd109b  jmp 0x0000703DBFBD0BB3
0000703dbfbd10a0  vxorps xmm0, xmm15, xmm14
0000703dbfbd10a5  pextrw r12d, xmm0, 0x03
0000703dbfbd10ab  and r12d, 0x7FF8
0000703dbfbd10b2  cmp r12d, 0x08
0000703dbfbd10b6  jnz 0x0000703DBFBD0BB3
0000703dbfbd10bc  movq r12, xmm14
0000703dbfbd10c1  shl r12, 0x0D
0000703dbfbd10c5  jbe 0x0000703DBFBD0BB3
0000703dbfbd10cb  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbd10d3  jmp 0x0000703DBFBD0BB3
0000703dbfbd10d8  ucomisd xmm1, xmm15
0000703dbfbd10dd  jp 0x0000703DBFBD10EC
0000703dbfbd10df  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd10e7  jmp 0x0000703DBFBD0BE8
0000703dbfbd10ec  vxorps xmm0, xmm1, xmm15
0000703dbfbd10f1  pextrw r12d, xmm0, 0x03
0000703dbfbd10f7  and r12d, 0x7FF8
0000703dbfbd10fe  cmp r12d, 0x08
0000703dbfbd1102  jnz 0x0000703DBFBD0BE8
0000703dbfbd1108  movq r12, xmm15
0000703dbfbd110d  shl r12, 0x0D
0000703dbfbd1111  jbe 0x0000703DBFBD0BE8
0000703dbfbd1117  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd111f  jmp 0x0000703DBFBD0BE8
0000703dbfbd1124  call 0x0000703DBFAC0370
0000703dbfbd1129  jmp 0x0000703DBFBD0BF9
0000703dbfbd112e  ucomisd xmm15, xmm14
0000703dbfbd1133  jp 0x0000703DBFBD1142
0000703dbfbd1135  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd113d  jmp 0x0000703DBFBD0C26
0000703dbfbd1142  vxorps xmm0, xmm15, xmm14
0000703dbfbd1147  pextrw r12d, xmm0, 0x03
0000703dbfbd114d  and r12d, 0x7FF8
0000703dbfbd1154  cmp r12d, 0x08
0000703dbfbd1158  jnz 0x0000703DBFBD0C26
0000703dbfbd115e  movq r12, xmm14
0000703dbfbd1163  shl r12, 0x0D
0000703dbfbd1167  jbe 0x0000703DBFBD0C26
0000703dbfbd116d  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbd1175  jmp 0x0000703DBFBD0C26
0000703dbfbd117a  ucomisd xmm1, xmm15
0000703dbfbd117f  jp 0x0000703DBFBD118E
0000703dbfbd1181  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd1189  jmp 0x0000703DBFBD0C5B
0000703dbfbd118e  vxorps xmm0, xmm1, xmm15
0000703dbfbd1193  pextrw r12d, xmm0, 0x03
0000703dbfbd1199  and r12d, 0x7FF8
0000703dbfbd11a0  cmp r12d, 0x08
0000703dbfbd11a4  jnz 0x0000703DBFBD0C5B
0000703dbfbd11aa  movq r12, xmm15
0000703dbfbd11af  shl r12, 0x0D
0000703dbfbd11b3  jbe 0x0000703DBFBD0C5B
0000703dbfbd11b9  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd11c1  jmp 0x0000703DBFBD0C5B
0000703dbfbd11c6  call 0x0000703DBFAC0370
0000703dbfbd11cb  jmp 0x0000703DBFBD0C6C
0000703dbfbd11d0  ucomisd xmm15, xmm14
0000703dbfbd11d5  jp 0x0000703DBFBD11E4
0000703dbfbd11d7  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd11df  jmp 0x0000703DBFBD0C99
0000703dbfbd11e4  vxorps xmm0, xmm15, xmm14
0000703dbfbd11e9  pextrw r12d, xmm0, 0x03
0000703dbfbd11ef  and r12d, 0x7FF8
0000703dbfbd11f6  cmp r12d, 0x08
0000703dbfbd11fa  jnz 0x0000703DBFBD0C99
0000703dbfbd1200  movq r12, xmm14
0000703dbfbd1205  shl r12, 0x0D
0000703dbfbd1209  jbe 0x0000703DBFBD0C99
0000703dbfbd120f  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbd1217  jmp 0x0000703DBFBD0C99
0000703dbfbd121c  ucomisd xmm1, xmm15
0000703dbfbd1221  jp 0x0000703DBFBD1230
0000703dbfbd1223  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd122b  jmp 0x0000703DBFBD0CCE
0000703dbfbd1230  vxorps xmm0, xmm1, xmm15
0000703dbfbd1235  pextrw r12d, xmm0, 0x03
0000703dbfbd123b  and r12d, 0x7FF8
0000703dbfbd1242  cmp r12d, 0x08
0000703dbfbd1246  jnz 0x0000703DBFBD0CCE
0000703dbfbd124c  movq r12, xmm15
0000703dbfbd1251  shl r12, 0x0D
0000703dbfbd1255  jbe 0x0000703DBFBD0CCE
0000703dbfbd125b  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd1263  jmp 0x0000703DBFBD0CCE
0000703dbfbd1268  call 0x0000703DBFAC0370
0000703dbfbd126d  jmp 0x0000703DBFBD0CDF
0000703dbfbd1272  ucomisd xmm15, xmm14
0000703dbfbd1277  jp 0x0000703DBFBD1286
0000703dbfbd1279  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd1281  jmp 0x0000703DBFBD0D0C
0000703dbfbd1286  vxorps xmm0, xmm15, xmm14
0000703dbfbd128b  pextrw r12d, xmm0, 0x03
0000703dbfbd1291  and r12d, 0x7FF8
0000703dbfbd1298  cmp r12d, 0x08
0000703dbfbd129c  jnz 0x0000703DBFBD0D0C
0000703dbfbd12a2  movq r12, xmm14
0000703dbfbd12a7  shl r12, 0x0D
0000703dbfbd12ab  jbe 0x0000703DBFBD0D0C
0000703dbfbd12b1  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbd12b9  jmp 0x0000703DBFBD0D0C
0000703dbfbd12be  ucomisd xmm1, xmm15
0000703dbfbd12c3  jp 0x0000703DBFBD12D2
0000703dbfbd12c5  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd12cd  jmp 0x0000703DBFBD0D41
0000703dbfbd12d2  vxorps xmm0, xmm1, xmm15
0000703dbfbd12d7  pextrw r12d, xmm0, 0x03
0000703dbfbd12dd  and r12d, 0x7FF8
0000703dbfbd12e4  cmp r12d, 0x08
0000703dbfbd12e8  jnz 0x0000703DBFBD0D41
0000703dbfbd12ee  movq r12, xmm15
0000703dbfbd12f3  shl r12, 0x0D
0000703dbfbd12f7  jbe 0x0000703DBFBD0D41
0000703dbfbd12fd  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd1305  jmp 0x0000703DBFBD0D41
0000703dbfbd130a  call 0x0000703DBFAC3AE0
0000703dbfbd130f  jmp 0x0000703DBFBD0D52
0000703dbfbd1314  ucomisd xmm15, xmm14
0000703dbfbd1319  jp 0x0000703DBFBD1328
0000703dbfbd131b  movaps xmm13, [0x0000703DBF7FE030]
0000703dbfbd1323  jmp 0x0000703DBFBD0D87
0000703dbfbd1328  vxorps xmm0, xmm15, xmm14
0000703dbfbd132d  pextrw r14d, xmm0, 0x03
0000703dbfbd1333  and r14d, 0x7FF8
0000703dbfbd133a  cmp r14d, 0x08
0000703dbfbd133e  jnz 0x0000703DBFBD0D87
0000703dbfbd1344  movq r14, xmm14
0000703dbfbd1349  shl r14, 0x0D
0000703dbfbd134d  jbe 0x0000703DBFBD0D87
0000703dbfbd1353  vorps xmm13, xmm14, [0x0000703DBF7FE040]
0000703dbfbd135b  jmp 0x0000703DBFBD0D87
0000703dbfbd1360  ucomisd xmm1, xmm15
0000703dbfbd1365  jp 0x0000703DBFBD1374
0000703dbfbd1367  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd136f  jmp 0x0000703DBFBD0DBC
0000703dbfbd1374  vxorps xmm0, xmm1, xmm15
0000703dbfbd1379  pextrw r14d, xmm0, 0x03
0000703dbfbd137f  and r14d, 0x7FF8
0000703dbfbd1386  cmp r14d, 0x08
0000703dbfbd138a  jnz 0x0000703DBFBD0DBC
0000703dbfbd1390  movq r14, xmm15
0000703dbfbd1395  shl r14, 0x0D
0000703dbfbd1399  jbe 0x0000703DBFBD0DBC
0000703dbfbd139f  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd13a7  jmp 0x0000703DBFBD0DBC
0000703dbfbd13ac  ucomisd xmm1, xmm15
0000703dbfbd13b1  jp 0x0000703DBFBD13C0
0000703dbfbd13b3  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd13bb  jmp 0x0000703DBFBD0DF1
0000703dbfbd13c0  vxorps xmm0, xmm1, xmm15
0000703dbfbd13c5  pextrw r14d, xmm0, 0x03
0000703dbfbd13cb  and r14d, 0x7FF8
0000703dbfbd13d2  cmp r14d, 0x08
0000703dbfbd13d6  jnz 0x0000703DBFBD0DF1
0000703dbfbd13dc  movq r14, xmm15
0000703dbfbd13e1  shl r14, 0x0D
0000703dbfbd13e5  jbe 0x0000703DBFBD0DF1
0000703dbfbd13eb  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd13f3  jmp 0x0000703DBFBD0DF1
0000703dbfbd13f8  call 0x0000703DBFA0E120
0000703dbfbd13fd  jmp 0x0000703DBFBD0E08
0000703dbfbd1402  int3
0000703dbfbd1403  nop [rax+rax*1], ax
0000703dbfbd140c  nop [rax], eax
0000703dbfbd1410  mov qword ptr [r15+0x40], 0x420000
0000703dbfbd1418  mov eax, 0x4201B8
0000703dbfbd141d  mov r14, [r13+rax*1]
0000703dbfbd1422  movq xmm1, r14
0000703dbfbd1427  mov rax, [r15+0x50]
0000703dbfbd142b  mov r14, [r13+rax*1]
0000703dbfbd1430  movq xmm15, r14
0000703dbfbd1435  movaps [r15+0x120], xmm15
0000703dbfbd143d  mov qword ptr [r15+0x48], 0x08
0000703dbfbd1445  xor eax, eax
0000703dbfbd1447  mov r14d, 0x08
0000703dbfbd144d  mov r12d, 0x200
0000703dbfbd1453  cmp r14, r12
0000703dbfbd1456  cmc
0000703dbfbd1457  lahf
0000703dbfbd1458  seto al
0000703dbfbd145b  mov [r15+0x108], eax
0000703dbfbd1462  movq rax, xmm1
0000703dbfbd1467  movq r14, xmm15
0000703dbfbd146c  vmovq xmm1, rax
0000703dbfbd1471  vmovq xmm15, r14
0000703dbfbd1476  movaps xmm14, xmm1
0000703dbfbd147a  addsd xmm14, xmm15
0000703dbfbd147f  ucomisd xmm14, xmm14
0000703dbfbd1484  jp 0x0000703DBFBD1516
0000703dbfbd148a  movq xmm14, xmm14
0000703dbfbd148f  movaps [r15+0x110], xmm14
0000703dbfbd1497  mov eax, [r15+0x108]
0000703dbfbd149e  sahf
0000703dbfbd149f  jnz 0x0000703DBFBD14D1
0000703dbfbd14a1  cmp dword ptr [r15+0x318], 0x00
0000703dbfbd14a9  jz 0x0000703DBFBD16A0
0000703dbfbd14af  nop [rax+rax*1], ax
0000703dbfbd14b8  nop [rax+rax*1], eax
0000703dbfbd14c0  mov eax, 0x410154
0000703dbfbd14c5  mov [r15+0x100], rax
0000703dbfbd14cc  jmp 0x0000703DBF9FE110
0000703dbfbd14d1  cmp dword ptr [r15+0x318], 0x00
0000703dbfbd14d9  jz 0x0000703DBFBD1560
0000703dbfbd14df  nop [rax+rax*1], ax
0000703dbfbd14e8  nop [rax+rax*1], eax
0000703dbfbd14f0  mov eax, 0x410140
0000703dbfbd14f5  mov [r15+0x100], rax
0000703dbfbd14fc  jmp 0x0000703DBF9FE110
0000703dbfbd1501  int3
0000703dbfbd1502  call 0x0000703DBFA0DC20
0000703dbfbd1507  jmp 0x0000703DBFBD1422
0000703dbfbd150c  call 0x0000703DBFA0DC20
0000703dbfbd1511  jmp 0x0000703DBFBD1430
0000703dbfbd1516  ucomisd xmm1, xmm15
0000703dbfbd151b  jp 0x0000703DBFBD152A
0000703dbfbd151d  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd1525  jmp 0x0000703DBFBD148A
0000703dbfbd152a  vxorps xmm0, xmm1, xmm15
0000703dbfbd152f  pextrw eax, xmm0, 0x03
0000703dbfbd1534  and eax, 0x7FF8
0000703dbfbd1539  cmp eax, 0x08
0000703dbfbd153c  jnz 0x0000703DBFBD148A
0000703dbfbd1542  movq rax, xmm15
0000703dbfbd1547  shl rax, 0x0D
0000703dbfbd154b  jbe 0x0000703DBFBD148A
0000703dbfbd1551  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd1559  jmp 0x0000703DBFBD148A
0000703dbfbd155e  int3
0000703dbfbd155f  nop
0000703dbfbd1560  mov rax, [r15+0x48]
0000703dbfbd1564  mov r14, [r15+0x50]
0000703dbfbd1568  lea r12, [r14+rax*1]
0000703dbfbd156c  mov r14, [r13+r12*1]
0000703dbfbd1571  movq xmm1, r14
0000703dbfbd1576  movaps [r15+0x120], xmm1
0000703dbfbd157e  lea r14, [rax+0x08]
0000703dbfbd1582  mov [r15+0x48], r14
0000703dbfbd1586  xor eax, eax
0000703dbfbd1588  mov r12d, 0x200
0000703dbfbd158e  cmp r14, r12
0000703dbfbd1591  cmc
0000703dbfbd1592  lahf
0000703dbfbd1593  seto al
0000703dbfbd1596  mov [r15+0x108], eax
0000703dbfbd159d  movaps xmm15, [r15+0x110]
0000703dbfbd15a5  movq rax, xmm15
0000703dbfbd15aa  movq r14, xmm1
0000703dbfbd15af  vmovq xmm1, rax
0000703dbfbd15b4  vmovq xmm15, r14
0000703dbfbd15b9  movaps xmm14, xmm1
0000703dbfbd15bd  addsd xmm14, xmm15
0000703dbfbd15c2  ucomisd xmm14, xmm14
0000703dbfbd15c7  jp 0x0000703DBFBD164F
0000703dbfbd15cd  movq xmm14, xmm14
0000703dbfbd15d2  movaps [r15+0x110], xmm14
0000703dbfbd15da  mov eax, [r15+0x108]
0000703dbfbd15e1  sahf
0000703dbfbd15e2  jnz 0x0000703DBFBD1614
0000703dbfbd15e4  cmp dword ptr [r15+0x318], 0x00
0000703dbfbd15ec  jz 0x0000703DBFBD16A0
0000703dbfbd15f2  nop [rax+rax*1], ax
0000703dbfbd15fb  nop [rax+rax*1], eax
0000703dbfbd1603  mov eax, 0x410154
0000703dbfbd1608  mov [r15+0x100], rax
0000703dbfbd160f  jmp 0x0000703DBF9FE110
0000703dbfbd1614  cmp dword ptr [r15+0x318], 0x00
0000703dbfbd161c  jz 0x0000703DBFBD1560
0000703dbfbd1622  nop [rax+rax*1], ax
0000703dbfbd162b  nop [rax+rax*1], eax
0000703dbfbd1633  mov eax, 0x410140
0000703dbfbd1638  mov [r15+0x100], rax
0000703dbfbd163f  jmp 0x0000703DBF9FE110
0000703dbfbd1644  int3
0000703dbfbd1645  call 0x0000703DBFAC3AE0
0000703dbfbd164a  jmp 0x0000703DBFBD1571
0000703dbfbd164f  ucomisd xmm1, xmm15
0000703dbfbd1654  jp 0x0000703DBFBD1663
0000703dbfbd1656  movaps xmm14, [0x0000703DBF7FE030]
0000703dbfbd165e  jmp 0x0000703DBFBD15CD
0000703dbfbd1663  vxorps xmm0, xmm1, xmm15
0000703dbfbd1668  pextrw eax, xmm0, 0x03
0000703dbfbd166d  and eax, 0x7FF8
0000703dbfbd1672  cmp eax, 0x08
0000703dbfbd1675  jnz 0x0000703DBFBD15CD
0000703dbfbd167b  movq rax, xmm15
0000703dbfbd1680  shl rax, 0x0D
0000703dbfbd1684  jbe 0x0000703DBFBD15CD
0000703dbfbd168a  vorps xmm14, xmm15, [0x0000703DBF7FE040]
0000703dbfbd1692  jmp 0x0000703DBFBD15CD
0000703dbfbd1697  int3
0000703dbfbd1698  nop [rax+rax*1], eax
0000703dbfbd16a0  mov rax, [r15+0x40]
0000703dbfbd16a4  lea r14, [rax+0x1B8]
0000703dbfbd16ab  movaps xmm1, [r15+0x110]
0000703dbfbd16b3  movq rax, xmm1
0000703dbfbd16b8  mov [r13+r14*1], rax
0000703dbfbd16bd  mov rax, [r15+0xF0]
0000703dbfbd16c4  mov [r15+0x100], rax
0000703dbfbd16cb  jmp 0x0000703DBFBCE5C0
0000703dbfbd16d0  int3
0000703dbfbd16d1  call 0x0000703DBFAD5EB0
0000703dbfbd16d6  jmp 0x0000703DBFBD16BD
0000703dbfbd16db  int3
0000703dbfbd16dc  nop [rax], eax
0000703dbfbd16e0  mov qword ptr [r15+0x100], 0x04
0000703dbfbd16eb  mov esi, 0x00
0000703dbfbd16f0  mov edx, 0x09
0000703dbfbd16f5  mov rdi, 0x7FFE703B6580
0000703dbfbd16ff  mov rax, 0x5A592FE70970
0000703dbfbd1709  call rax
0000703dbfbd170b  cmp dword ptr [r15+0x318], 0x00
0000703dbfbd1713  jnz 0x0000703DBF9FE110
0000703dbfbd1719  jmp 0x0000703DBF9FE0A0
0000703dbfbd171e  int3
0000703dbfbd171f  int3
