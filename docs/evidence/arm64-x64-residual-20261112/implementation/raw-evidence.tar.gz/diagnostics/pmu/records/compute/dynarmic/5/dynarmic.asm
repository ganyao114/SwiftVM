000073baab9ce69b  nop [rax+rax*1], eax
000073baab9ce6a0  mov rax, [r15+0xF8]
000073baab9ce6a7  lea r14, [rax-0x1E0]
000073baab9ce6ae  mov [r15+0xF8], r14
000073baab9ce6b5  lea rax, [r14+0x1D0]
000073baab9ce6bc  mov r12, [r15+0xA0]
000073baab9ce6c3  mov r11, [r15+0x98]
000073baab9ce6ca  mov [r13+rax*1], r12
000073baab9ce6cf  lea rax, [r14+0x1D8]
000073baab9ce6d6  mov [r13+rax*1], r11
000073baab9ce6db  mov eax, 0x420AA0
000073baab9ce6e0  movups xmm1, [r13+rax*1]
000073baab9ce6e6  mov eax, 0x420A30
000073baab9ce6eb  movups xmm15, [r13+rax*1]
000073baab9ce6f1  mov eax, 0x420AC0
000073baab9ce6f6  movups xmm14, [r13+rax*1]
000073baab9ce6fc  mov eax, 0x420A60
000073baab9ce701  movups xmm13, [r13+rax*1]
000073baab9ce707  mov qword ptr [r15+0x98], 0x430CD0
000073baab9ce712  mov eax, 0x420AD0
000073baab9ce717  movups xmm12, [r13+rax*1]
000073baab9ce71d  mov eax, 0x430CD0
000073baab9ce722  movups [r13+rax*1], xmm1
000073baab9ce728  mov eax, 0x430CE0
000073baab9ce72d  movups [r13+rax*1], xmm15
000073baab9ce733  mov eax, 0x430CF0
000073baab9ce738  movups [r13+rax*1], xmm14
000073baab9ce73e  mov eax, 0x430D00
000073baab9ce743  movups [r13+rax*1], xmm13
000073baab9ce749  mov eax, 0x420A20
000073baab9ce74e  movups xmm14, [r13+rax*1]
000073baab9ce754  mov eax, 0x420A10
000073baab9ce759  movups xmm13, [r13+rax*1]
000073baab9ce75f  mov eax, 0x430DD0
000073baab9ce764  movups [r13+rax*1], xmm1
000073baab9ce76a  mov eax, 0x430DE0
000073baab9ce76f  movups [r13+rax*1], xmm15
000073baab9ce775  mov eax, 0x430D10
000073baab9ce77a  movups [r13+rax*1], xmm12
000073baab9ce780  mov eax, 0x430D20
000073baab9ce785  movups [r13+rax*1], xmm14
000073baab9ce78b  mov eax, 0x420A00
000073baab9ce790  movups xmm1, [r13+rax*1]
000073baab9ce796  mov eax, 0x420A70
000073baab9ce79b  movups xmm15, [r13+rax*1]
000073baab9ce7a1  mov eax, 0x430D30
000073baab9ce7a6  movups [r13+rax*1], xmm13
000073baab9ce7ac  mov eax, 0x430D40
000073baab9ce7b1  movups [r13+rax*1], xmm1
000073baab9ce7b7  mov eax, 0x420A80
000073baab9ce7bc  movups xmm1, [r13+rax*1]
000073baab9ce7c2  mov eax, 0x420A50
000073baab9ce7c7  movups xmm14, [r13+rax*1]
000073baab9ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000073baab9ce7d5  mov eax, 0x430D50
000073baab9ce7da  movups [r13+rax*1], xmm15
000073baab9ce7e0  mov eax, 0x430D60
000073baab9ce7e5  movups [r13+rax*1], xmm1
000073baab9ce7eb  mov eax, 0x420AF0
000073baab9ce7f0  movups xmm1, [r13+rax*1]
000073baab9ce7f6  mov eax, 0x420B00
000073baab9ce7fb  movups xmm15, [r13+rax*1]
000073baab9ce801  movaps [r15+0x150], xmm15
000073baab9ce809  mov qword ptr [r15+0xA0], 0x3E8
000073baab9ce814  mov eax, 0x430D70
000073baab9ce819  movups [r13+rax*1], xmm14
000073baab9ce81f  mov eax, 0x430D80
000073baab9ce824  movups [r13+rax*1], xmm1
000073baab9ce82a  mov eax, 0x420AE0
000073baab9ce82f  movups xmm1, [r13+rax*1]
000073baab9ce835  mov eax, 0x420A90
000073baab9ce83a  movups xmm14, [r13+rax*1]
000073baab9ce840  movaps [r15+0x140], xmm14
000073baab9ce848  lea rax, [r14+0x180]
000073baab9ce84f  movq xmm13, qword ptr [r15+0x200]
000073baab9ce858  movq xmm12, qword ptr [r15+0x1F0]
000073baab9ce861  movq r12, xmm13
000073baab9ce866  movq r11, xmm12
000073baab9ce86b  mov [r13+rax*1], r12
000073baab9ce870  lea rax, [r14+0x188]
000073baab9ce877  mov [r13+rax*1], r11
000073baab9ce87c  mov eax, 0x430D90
000073baab9ce881  movups [r13+rax*1], xmm15
000073baab9ce887  mov eax, 0x430DA0
000073baab9ce88c  movups [r13+rax*1], xmm1
000073baab9ce892  mov eax, 0x420AB0
000073baab9ce897  movups xmm1, [r13+rax*1]
000073baab9ce89d  mov eax, 0x420B18
000073baab9ce8a2  mov r12, [r13+rax*1]
000073baab9ce8a7  movq xmm15, r12
000073baab9ce8ac  mov qword ptr [r15+0x40], 0x420B20
000073baab9ce8b4  mov eax, 0x430DB0
000073baab9ce8b9  movups [r13+rax*1], xmm14
000073baab9ce8bf  mov eax, 0x430DC0
000073baab9ce8c4  movups [r13+rax*1], xmm1
000073baab9ce8ca  mov eax, 0x420B80
000073baab9ce8cf  movups xmm1, [r13+rax*1]
000073baab9ce8d5  movq rax, xmm15
000073baab9ce8da  mov r12d, 0x430DF0
000073baab9ce8e0  mov [r13+r12*1], rax
000073baab9ce8e5  mov eax, 0x420B60
000073baab9ce8ea  movups xmm15, [r13+rax*1]
000073baab9ce8f0  mov eax, 0x420B70
000073baab9ce8f5  movups xmm14, [r13+rax*1]
000073baab9ce8fb  lea rax, [r14+0x160]
000073baab9ce902  movups [r13+rax*1], xmm1
000073baab9ce908  lea rax, [r14+0x190]
000073baab9ce90f  movq xmm1, qword ptr [r15+0x1E0]
000073baab9ce918  movq xmm13, qword ptr [r15+0x1D0]
000073baab9ce921  movq r12, xmm1
000073baab9ce926  movq r11, xmm13
000073baab9ce92b  mov [r13+rax*1], r12
000073baab9ce930  lea rax, [r14+0x198]
000073baab9ce937  mov [r13+rax*1], r11
000073baab9ce93c  lea rax, [r14+0x140]
000073baab9ce943  movups [r13+rax*1], xmm15
000073baab9ce949  lea rax, [r14+0x150]
000073baab9ce950  movups [r13+rax*1], xmm14
000073baab9ce956  mov eax, 0x420B20
000073baab9ce95b  movups xmm1, [r13+rax*1]
000073baab9ce961  mov eax, 0x420B30
000073baab9ce966  movups xmm15, [r13+rax*1]
000073baab9ce96c  movaps [r15+0x120], xmm15
000073baab9ce974  lea rax, [r14+0x1A0]
000073baab9ce97b  movq xmm14, qword ptr [r15+0x1C0]
000073baab9ce984  movq xmm13, qword ptr [r15+0x1B0]
000073baab9ce98d  movq r12, xmm14
000073baab9ce992  movq r11, xmm13
000073baab9ce997  mov [r13+rax*1], r12
000073baab9ce99c  lea rax, [r14+0x1A8]
000073baab9ce9a3  mov [r13+rax*1], r11
000073baab9ce9a8  lea rax, [r14+0x1B0]
000073baab9ce9af  movq xmm14, qword ptr [r15+0x1A0]
000073baab9ce9b8  movq xmm13, qword ptr [r15+0x190]
000073baab9ce9c1  movq r12, xmm14
000073baab9ce9c6  movq r11, xmm13
000073baab9ce9cb  mov [r13+rax*1], r12
000073baab9ce9d0  lea rax, [r14+0x1B8]
000073baab9ce9d7  mov [r13+rax*1], r11
000073baab9ce9dc  lea rax, [r14+0x100]
000073baab9ce9e3  movups [r13+rax*1], xmm1
000073baab9ce9e9  lea rax, [r14+0x110]
000073baab9ce9f0  movups [r13+rax*1], xmm15
000073baab9ce9f6  mov eax, 0x420B40
000073baab9ce9fb  movups xmm1, [r13+rax*1]
000073baab9cea01  mov eax, 0x420B50
000073baab9cea06  movups xmm15, [r13+rax*1]
000073baab9cea0c  movaps [r15+0x110], xmm1
000073baab9cea14  movaps [r15+0x130], xmm15
000073baab9cea1c  lea rax, [r14+0x1C0]
000073baab9cea23  mov r12, [r15+0xE8]
000073baab9cea2a  mov r11, [r15+0xF0]
000073baab9cea31  mov [r13+rax*1], r12
000073baab9cea36  lea rax, [r14+0x1C8]
000073baab9cea3d  mov [r13+rax*1], r11
000073baab9cea42  mov eax, 0x430DF8
000073baab9cea47  mov r12d, 0x421DF8D3
000073baab9cea4d  mov [r13+rax*1], r12d
000073baab9cea52  lea rax, [r14+0x120]
000073baab9cea59  movups [r13+rax*1], xmm1
000073baab9cea5f  lea rax, [r14+0x130]
000073baab9cea66  movups [r13+rax*1], xmm15
000073baab9cea6c  lea rax, [r14+0x100]
000073baab9cea73  mov [r15], rax
000073baab9cea76  mov qword ptr [r15+0x08], 0x430CD0
000073baab9cea7e  mov qword ptr [r15+0x10], 0x12C
000073baab9cea86  mov qword ptr [r15+0xF0], 0x410284
000073baab9cea91  mov r14d, [r15+0x320]
000073baab9cea98  mov eax, 0x410284
000073baab9cea9d  mov rcx, 0x73BAAB9D07C0
000073baab9ceaa7  mov [r15+r14*8+0x328], rax
000073baab9ceaaf  mov [r15+r14*8+0x368], rcx
000073baab9ceab7  add r14d, 0x01
000073baab9ceabb  and r14d, 0x07
000073baab9ceabf  mov [r15+0x320], r14d
000073baab9ceac6  cmp dword ptr [r15+0x318], 0x00
000073baab9ceace  jz 0x000073BAAB9CED70
000073baab9cead4  nop [rax+rax*1], ax
000073baab9ceadd  nop [rax+rax*1], eax
000073baab9ceae5  mov eax, 0x410728
000073baab9ceaea  mov [r15+0x100], rax
000073baab9ceaf1  jmp 0x000073BAAB7FE110
000073baab9ceaf6  int3
000073baab9ceaf7  call 0x000073BAAB80BC20
000073baab9ceafc  jmp 0x000073BAAB9CE6CF
000073baab9ceb01  call 0x000073BAAB80A9A0
000073baab9ceb06  jmp 0x000073BAAB9CE6DB
000073baab9ceb0b  call 0x000073BAAB7FF430
000073baab9ceb10  jmp 0x000073BAAB9CE6E6
000073baab9ceb15  call 0x000073BAAB80E760
000073baab9ceb1a  jmp 0x000073BAAB9CE6F1
000073baab9ceb1f  call 0x000073BAAB80D4E0
000073baab9ceb24  jmp 0x000073BAAB9CE6FC
000073baab9ceb29  call 0x000073BAAB80C260
000073baab9ceb2e  jmp 0x000073BAAB9CE707
000073baab9ceb33  call 0x000073BAAB80AFE0
000073baab9ceb38  jmp 0x000073BAAB9CE71D
000073baab9ceb3d  call 0x000073BAAB7FF540
000073baab9ceb42  jmp 0x000073BAAB9CE728
000073baab9ceb47  call 0x000073BAAB80E880
000073baab9ceb4c  jmp 0x000073BAAB9CE733
000073baab9ceb51  call 0x000073BAAB80D600
000073baab9ceb56  jmp 0x000073BAAB9CE73E
000073baab9ceb5b  call 0x000073BAAB80C380
000073baab9ceb60  jmp 0x000073BAAB9CE749
000073baab9ceb65  call 0x000073BAAB80D4E0
000073baab9ceb6a  jmp 0x000073BAAB9CE754
000073baab9ceb6f  call 0x000073BAAB80C260
000073baab9ceb74  jmp 0x000073BAAB9CE75F
000073baab9ceb79  call 0x000073BAAB7FF540
000073baab9ceb7e  jmp 0x000073BAAB9CE76A
000073baab9ceb83  call 0x000073BAAB80E880
000073baab9ceb88  jmp 0x000073BAAB9CE775
000073baab9ceb8d  call 0x000073BAAB80B100
000073baab9ceb92  jmp 0x000073BAAB9CE780
000073baab9ceb97  call 0x000073BAAB80D600
000073baab9ceb9c  jmp 0x000073BAAB9CE78B
000073baab9ceba1  call 0x000073BAAB7FF430
000073baab9ceba6  jmp 0x000073BAAB9CE796
000073baab9cebab  call 0x000073BAAB80E760
000073baab9cebb0  jmp 0x000073BAAB9CE7A1
000073baab9cebb5  call 0x000073BAAB80C380
000073baab9cebba  jmp 0x000073BAAB9CE7AC
000073baab9cebbf  call 0x000073BAAB7FF540
000073baab9cebc4  jmp 0x000073BAAB9CE7B7
000073baab9cebc9  call 0x000073BAAB7FF430
000073baab9cebce  jmp 0x000073BAAB9CE7C2
000073baab9cebd3  call 0x000073BAAB80D4E0
000073baab9cebd8  jmp 0x000073BAAB9CE7CD
000073baab9cebdd  call 0x000073BAAB80E880
000073baab9cebe2  jmp 0x000073BAAB9CE7E0
000073baab9cebe7  call 0x000073BAAB7FF540
000073baab9cebec  jmp 0x000073BAAB9CE7EB
000073baab9cebf1  call 0x000073BAAB7FF430
000073baab9cebf6  jmp 0x000073BAAB9CE7F6
000073baab9cebfb  call 0x000073BAAB80E760
000073baab9cec00  jmp 0x000073BAAB9CE801
000073baab9cec05  call 0x000073BAAB80D600
000073baab9cec0a  jmp 0x000073BAAB9CE81F
000073baab9cec0f  call 0x000073BAAB7FF540
000073baab9cec14  jmp 0x000073BAAB9CE82A
000073baab9cec19  call 0x000073BAAB7FF430
000073baab9cec1e  jmp 0x000073BAAB9CE835
000073baab9cec23  call 0x000073BAAB80D4E0
000073baab9cec28  jmp 0x000073BAAB9CE840
000073baab9cec2d  call 0x000073BAAB80BC20
000073baab9cec32  jmp 0x000073BAAB9CE870
000073baab9cec37  call 0x000073BAAB80A9A0
000073baab9cec3c  jmp 0x000073BAAB9CE87C
000073baab9cec41  call 0x000073BAAB80E880
000073baab9cec46  jmp 0x000073BAAB9CE887
000073baab9cec4b  call 0x000073BAAB7FF540
000073baab9cec50  jmp 0x000073BAAB9CE892
000073baab9cec55  call 0x000073BAAB7FF430
000073baab9cec5a  jmp 0x000073BAAB9CE89D
000073baab9cec5f  call 0x000073BAAB80B720
000073baab9cec64  jmp 0x000073BAAB9CE8A7
000073baab9cec69  call 0x000073BAAB80D600
000073baab9cec6e  jmp 0x000073BAAB9CE8BF
000073baab9cec73  call 0x000073BAAB7FF540
000073baab9cec78  jmp 0x000073BAAB9CE8CA
000073baab9cec7d  call 0x000073BAAB7FF430
000073baab9cec82  jmp 0x000073BAAB9CE8D5
000073baab9cec87  call 0x000073BAAB8B4CB0
000073baab9cec8c  jmp 0x000073BAAB9CE8E5
000073baab9cec91  call 0x000073BAAB80E760
000073baab9cec96  jmp 0x000073BAAB9CE8F0
000073baab9cec9b  call 0x000073BAAB80D4E0
000073baab9ceca0  jmp 0x000073BAAB9CE8FB
000073baab9ceca5  call 0x000073BAAB7FF540
000073baab9cecaa  jmp 0x000073BAAB9CE908
000073baab9cecaf  call 0x000073BAAB80BC20
000073baab9cecb4  jmp 0x000073BAAB9CE930
000073baab9cecb9  call 0x000073BAAB80A9A0
000073baab9cecbe  jmp 0x000073BAAB9CE93C
000073baab9cecc3  call 0x000073BAAB80E880
000073baab9cecc8  jmp 0x000073BAAB9CE949
000073baab9ceccd  call 0x000073BAAB80D600
000073baab9cecd2  jmp 0x000073BAAB9CE956
000073baab9cecd7  call 0x000073BAAB7FF430
000073baab9cecdc  jmp 0x000073BAAB9CE961
000073baab9cece1  call 0x000073BAAB80E760
000073baab9cece6  jmp 0x000073BAAB9CE96C
000073baab9ceceb  call 0x000073BAAB80BC20
000073baab9cecf0  jmp 0x000073BAAB9CE99C
000073baab9cecf5  call 0x000073BAAB80A9A0
000073baab9cecfa  jmp 0x000073BAAB9CE9A8
000073baab9cecff  call 0x000073BAAB80BC20
000073baab9ced04  jmp 0x000073BAAB9CE9D0
000073baab9ced09  call 0x000073BAAB80A9A0
000073baab9ced0e  jmp 0x000073BAAB9CE9DC
000073baab9ced13  call 0x000073BAAB7FF540
000073baab9ced18  jmp 0x000073BAAB9CE9E9
000073baab9ced1d  call 0x000073BAAB80E880
000073baab9ced22  jmp 0x000073BAAB9CE9F6
000073baab9ced27  call 0x000073BAAB7FF430
000073baab9ced2c  jmp 0x000073BAAB9CEA01
000073baab9ced31  call 0x000073BAAB80E760
000073baab9ced36  jmp 0x000073BAAB9CEA0C
000073baab9ced3b  call 0x000073BAAB80BC20
000073baab9ced40  jmp 0x000073BAAB9CEA36
000073baab9ced45  call 0x000073BAAB80A9A0
000073baab9ced4a  jmp 0x000073BAAB9CEA42
000073baab9ced4f  call 0x000073BAAB80BAE0
000073baab9ced54  jmp 0x000073BAAB9CEA52
000073baab9ced59  call 0x000073BAAB7FF540
000073baab9ced5e  jmp 0x000073BAAB9CEA5F
000073baab9ced63  call 0x000073BAAB80E880
000073baab9ced68  jmp 0x000073BAAB9CEA6C
000073baab9ced6d  int3
000073baab9ced6e  nop
000073baab9ced70  mov rax, [r15]
000073baab9ced73  lea r14, [rax+0x20]
000073baab9ced77  mov r12, [r13+r14*1]
000073baab9ced7c  mov r14, [r15+0x10]
000073baab9ced80  lea r11, [r12+r14*1]
000073baab9ced84  mov [r15+0x40], r11
000073baab9ced88  lea r12, [rax+0x20]
000073baab9ced8c  mov [r13+r12*1], r11
000073baab9ced91  test r14, r14
000073baab9ced94  setz r14b
000073baab9ced98  movzx r14, r14b
000073baab9ced9c  mov [rsp+0x414], r14b
000073baab9ceda4  cmp byte ptr [rsp+0x414], 0x00
000073baab9cedac  jz 0x000073BAAB9CEDDE
000073baab9cedae  cmp dword ptr [r15+0x318], 0x00
000073baab9cedb6  mov eax, 0x4109A0
000073baab9cedbb  mov [r15+0x100], rax
000073baab9cedc2  jz 0x000073BAAB7FE0A0
000073baab9cedc8  nop [rax+rax*1], eax
000073baab9cedcd  mov eax, 0x4109A0
000073baab9cedd2  mov [r15+0x100], rax
000073baab9cedd9  jmp 0x000073BAAB7FE110
000073baab9cedde  cmp dword ptr [r15+0x318], 0x00
000073baab9cede6  jz 0x000073BAAB9CEE30
000073baab9cedec  nop [rax+rax*1], ax
000073baab9cedf5  nop [rax+rax*1], eax
000073baab9cedfd  mov eax, 0x410738
000073baab9cee02  mov [r15+0x100], rax
000073baab9cee09  jmp 0x000073BAAB7FE110
000073baab9cee0e  int3
000073baab9cee0f  call 0x000073BAAB8E27E0
000073baab9cee14  jmp 0x000073BAAB9CED7C
000073baab9cee19  call 0x000073BAAB8C0860
000073baab9cee1e  jmp 0x000073BAAB9CED91
000073baab9cee23  int3
000073baab9cee24  nop [rax+rax*1], ax
000073baab9cee2d  nop [rax], eax
000073baab9cee30  mov rax, [r15+0xF8]
000073baab9cee37  lea r14, [rax-0x150]
000073baab9cee3e  mov [r15+0xF8], r14
000073baab9cee45  mov rax, [r15]
000073baab9cee48  lea r12, [rax+0x68]
000073baab9cee4c  mov r11, [r13+r12*1]
000073baab9cee51  mov [r15+0x88], r11
000073baab9cee58  lea r12, [rax+0x28]
000073baab9cee5c  mov [r15+0x40], r12
000073baab9cee60  mov [r15+0x48], r14
000073baab9cee64  mov qword ptr [r15+0x50], 0x420B90
000073baab9cee6c  lea rax, [r14+0x100]
000073baab9cee73  mov r12, [r15+0xE8]
000073baab9cee7a  mov r11, [r15+0xD8]
000073baab9cee81  mov [r13+rax*1], r12
000073baab9cee86  lea rax, [r14+0x108]
000073baab9cee8d  mov [r13+rax*1], r11
000073baab9cee92  lea rax, [r14+0x110]
000073baab9cee99  mov r12, [r15+0xD0]
000073baab9ceea0  mov r11, [r15+0xC8]
000073baab9ceea7  mov [r13+rax*1], r12
000073baab9ceeac  lea rax, [r14+0x118]
000073baab9ceeb3  mov [r13+rax*1], r11
000073baab9ceeb8  lea rax, [r14+0x120]
000073baab9ceebf  mov r12, [r15+0xC0]
000073baab9ceec6  mov r11, [r15+0xB8]
000073baab9ceecd  mov [r13+rax*1], r12
000073baab9ceed2  lea rax, [r14+0x128]
000073baab9ceed9  mov [r13+rax*1], r11
000073baab9ceede  lea rax, [r14+0x130]
000073baab9ceee5  mov r12, [r15+0xB0]
000073baab9ceeec  mov r11, [r15+0xA8]
000073baab9ceef3  mov [r13+rax*1], r12
000073baab9ceef8  lea rax, [r14+0x138]
000073baab9ceeff  mov [r13+rax*1], r11
000073baab9cef04  lea rax, [r14+0x140]
000073baab9cef0b  mov r12, [r15+0xA0]
000073baab9cef12  mov r11, [r15+0x98]
000073baab9cef19  mov [r13+rax*1], r12
000073baab9cef1e  lea rax, [r14+0x148]
000073baab9cef25  mov [r13+rax*1], r11
000073baab9cef2a  cmp dword ptr [r15+0x318], 0x00
000073baab9cef32  jz 0x000073BAAB9CEFD0
000073baab9cef38  nop [rax+rax*1], ax
000073baab9cef41  nop [rax+rax*1], eax
000073baab9cef49  mov eax, 0x410770
000073baab9cef4e  mov [r15+0x100], rax
000073baab9cef55  jmp 0x000073BAAB7FE110
000073baab9cef5a  int3
000073baab9cef5b  call 0x000073BAAB8C0370
000073baab9cef60  jmp 0x000073BAAB9CEE51
000073baab9cef65  call 0x000073BAAB80BC20
000073baab9cef6a  jmp 0x000073BAAB9CEE86
000073baab9cef6f  call 0x000073BAAB80A9A0
000073baab9cef74  jmp 0x000073BAAB9CEE92
000073baab9cef79  call 0x000073BAAB80BC20
000073baab9cef7e  jmp 0x000073BAAB9CEEAC
000073baab9cef83  call 0x000073BAAB80A9A0
000073baab9cef88  jmp 0x000073BAAB9CEEB8
000073baab9cef8d  call 0x000073BAAB80BC20
000073baab9cef92  jmp 0x000073BAAB9CEED2
000073baab9cef97  call 0x000073BAAB80A9A0
000073baab9cef9c  jmp 0x000073BAAB9CEEDE
000073baab9cefa1  call 0x000073BAAB80BC20
000073baab9cefa6  jmp 0x000073BAAB9CEEF8
000073baab9cefab  call 0x000073BAAB80A9A0
000073baab9cefb0  jmp 0x000073BAAB9CEF04
000073baab9cefb5  call 0x000073BAAB80BC20
000073baab9cefba  jmp 0x000073BAAB9CEF1E
000073baab9cefbf  call 0x000073BAAB80A9A0
000073baab9cefc4  jmp 0x000073BAAB9CEF2A
000073baab9cefc9  int3
000073baab9cefca  nop [rax+rax*1], ax
000073baab9cefd0  mov rax, [r15+0x08]
000073baab9cefd4  movzx r14d, byte ptr [r13+rax*1]
000073baab9cefda  movzx r14d, r14b
000073baab9cefde  mov [rsp+0x10], r14d
000073baab9cefe3  mov r14d, r14d
000073baab9cefe6  mov [r15+0x58], r14
000073baab9cefea  lea r14, [rax+0x01]
000073baab9cefee  mov [r15+0x08], r14
000073baab9ceff2  mov rax, [r15+0x88]
000073baab9ceff9  lea r14, [rax+0x01]
000073baab9ceffd  mov r12, [r15]
000073baab9cf000  lea r11, [r12+0x68]
000073baab9cf005  mov [r13+r11*1], r14
000073baab9cf00a  lea r14, [r12+rax*1]
000073baab9cf00e  mov [r15+0x60], r14
000073baab9cf012  lea rax, [r14+0x28]
000073baab9cf016  mov r11d, [rsp+0x10]
000073baab9cf01b  movzx r14d, r11b
000073baab9cf01f  mov [r13+rax*1], r14b
000073baab9cf024  lea rax, [r12+0x68]
000073baab9cf029  mov r14, [r13+rax*1]
000073baab9cf02e  mov [r15+0x88], r14
000073baab9cf035  xor eax, eax
000073baab9cf037  mov r12d, 0x40
000073baab9cf03d  cmp r14, r12
000073baab9cf040  cmc
000073baab9cf041  lahf
000073baab9cf042  seto al
000073baab9cf045  mov [r15+0x108], eax
000073baab9cf04c  mov eax, [r15+0x108]
000073baab9cf053  sahf
000073baab9cf054  jnz 0x000073BAAB9CF086
000073baab9cf056  cmp dword ptr [r15+0x318], 0x00
000073baab9cf05e  jz 0x000073BAAB9CF170
000073baab9cf064  nop [rax+rax*1], ax
000073baab9cf06d  nop [rax+rax*1], eax
000073baab9cf075  mov eax, 0x410790
000073baab9cf07a  mov [r15+0x100], rax
000073baab9cf081  jmp 0x000073BAAB7FE110
000073baab9cf086  cmp dword ptr [r15+0x318], 0x00
000073baab9cf08e  jz 0x000073BAAB9CF0E0
000073baab9cf094  nop [rax+rax*1], ax
000073baab9cf09d  nop [rax+rax*1], eax
000073baab9cf0a5  mov eax, 0x410768
000073baab9cf0aa  mov [r15+0x100], rax
000073baab9cf0b1  jmp 0x000073BAAB7FE110
000073baab9cf0b6  int3
000073baab9cf0b7  call 0x000073BAAB80D860
000073baab9cf0bc  jmp 0x000073BAAB9CEFDA
000073baab9cf0c1  call 0x000073BAAB8B36E0
000073baab9cf0c6  jmp 0x000073BAAB9CF00A
000073baab9cf0cb  call 0x000073BAAB80DD60
000073baab9cf0d0  jmp 0x000073BAAB9CF024
000073baab9cf0d5  call 0x000073BAAB80DC20
000073baab9cf0da  jmp 0x000073BAAB9CF02E
000073baab9cf0df  int3
000073baab9cf0e0  mov rax, [r15+0x10]
000073baab9cf0e4  lea r14, [rax-0x01]
000073baab9cf0e8  mov [r15+0x10], r14
000073baab9cf0ec  test r14, r14
000073baab9cf0ef  setz r14b
000073baab9cf0f3  movzx r14, r14b
000073baab9cf0f7  mov [rsp+0x414], r14b
000073baab9cf0ff  cmp byte ptr [rsp+0x414], 0x00
000073baab9cf107  jz 0x000073BAAB9CF139
000073baab9cf109  cmp dword ptr [r15+0x318], 0x00
000073baab9cf111  jz 0x000073BAAB9D0670
000073baab9cf117  nop [rax+rax*1], ax
000073baab9cf120  nop [rax+rax*1], eax
000073baab9cf128  mov eax, 0x410988
000073baab9cf12d  mov [r15+0x100], rax
000073baab9cf134  jmp 0x000073BAAB7FE110
000073baab9cf139  cmp dword ptr [r15+0x318], 0x00
000073baab9cf141  jz 0x000073BAAB9CEFD0
000073baab9cf147  nop [rax+rax*1], ax
000073baab9cf150  nop [rax+rax*1], eax
000073baab9cf158  mov eax, 0x410770
000073baab9cf15d  mov [r15+0x100], rax
000073baab9cf164  jmp 0x000073BAAB7FE110
000073baab9cf169  int3
000073baab9cf16a  int3
000073baab9cf16b  nop [rax+rax*1], eax
000073baab9cf170  mov rax, [r15+0x40]
000073baab9cf174  movzx r14d, byte ptr [r13+rax*1]
000073baab9cf17a  movaps xmm1, [r15+0x110]
000073baab9cf182  pinsrb xmm1, r14d, 0x00
000073baab9cf189  lea r14, [rax+0x01]
000073baab9cf18d  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf193  movaps xmm15, [r15+0x120]
000073baab9cf19b  pinsrb xmm15, r12d, 0x00
000073baab9cf1a2  lea r14, [rax+0x02]
000073baab9cf1a6  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf1ac  movaps xmm14, [r15+0x130]
000073baab9cf1b4  pinsrb xmm14, r12d, 0x00
000073baab9cf1bb  lea r14, [rax+0x03]
000073baab9cf1bf  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf1c5  movaps xmm13, [r15+0x140]
000073baab9cf1cd  pinsrb xmm13, r12d, 0x00
000073baab9cf1d4  lea r14, [rax+0x04]
000073baab9cf1d8  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf1de  pinsrb xmm1, r12d, 0x01
000073baab9cf1e5  lea r14, [rax+0x05]
000073baab9cf1e9  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf1ef  pinsrb xmm15, r12d, 0x01
000073baab9cf1f6  lea r14, [rax+0x06]
000073baab9cf1fa  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf200  pinsrb xmm14, r12d, 0x01
000073baab9cf207  lea r14, [rax+0x07]
000073baab9cf20b  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf211  pinsrb xmm13, r12d, 0x01
000073baab9cf218  lea r14, [rax+0x08]
000073baab9cf21c  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf222  pinsrb xmm1, r12d, 0x02
000073baab9cf229  lea r14, [rax+0x09]
000073baab9cf22d  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf233  pinsrb xmm15, r12d, 0x02
000073baab9cf23a  lea r14, [rax+0x0A]
000073baab9cf23e  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf244  pinsrb xmm14, r12d, 0x02
000073baab9cf24b  lea r14, [rax+0x0B]
000073baab9cf24f  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf255  pinsrb xmm13, r12d, 0x02
000073baab9cf25c  lea r14, [rax+0x0C]
000073baab9cf260  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf266  pinsrb xmm1, r12d, 0x03
000073baab9cf26d  lea r14, [rax+0x0D]
000073baab9cf271  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf277  pinsrb xmm15, r12d, 0x03
000073baab9cf27e  lea r14, [rax+0x0E]
000073baab9cf282  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf288  pinsrb xmm14, r12d, 0x03
000073baab9cf28f  lea r14, [rax+0x0F]
000073baab9cf293  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf299  pinsrb xmm13, r12d, 0x03
000073baab9cf2a0  lea r14, [rax+0x10]
000073baab9cf2a4  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf2aa  pinsrb xmm1, r12d, 0x04
000073baab9cf2b1  lea r14, [rax+0x11]
000073baab9cf2b5  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf2bb  pinsrb xmm15, r12d, 0x04
000073baab9cf2c2  lea r14, [rax+0x12]
000073baab9cf2c6  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf2cc  pinsrb xmm14, r12d, 0x04
000073baab9cf2d3  lea r14, [rax+0x13]
000073baab9cf2d7  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf2dd  pinsrb xmm13, r12d, 0x04
000073baab9cf2e4  lea r14, [rax+0x14]
000073baab9cf2e8  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf2ee  pinsrb xmm1, r12d, 0x05
000073baab9cf2f5  lea r14, [rax+0x15]
000073baab9cf2f9  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf2ff  pinsrb xmm15, r12d, 0x05
000073baab9cf306  lea r14, [rax+0x16]
000073baab9cf30a  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf310  pinsrb xmm14, r12d, 0x05
000073baab9cf317  lea r14, [rax+0x17]
000073baab9cf31b  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf321  pinsrb xmm13, r12d, 0x05
000073baab9cf328  lea r14, [rax+0x18]
000073baab9cf32c  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf332  pinsrb xmm1, r12d, 0x06
000073baab9cf339  lea r14, [rax+0x19]
000073baab9cf33d  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf343  pinsrb xmm15, r12d, 0x06
000073baab9cf34a  lea r14, [rax+0x1A]
000073baab9cf34e  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf354  pinsrb xmm14, r12d, 0x06
000073baab9cf35b  lea r14, [rax+0x1B]
000073baab9cf35f  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf365  pinsrb xmm13, r12d, 0x06
000073baab9cf36c  lea r14, [rax+0x1C]
000073baab9cf370  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf376  pinsrb xmm1, r12d, 0x07
000073baab9cf37d  lea r14, [rax+0x1D]
000073baab9cf381  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf387  pinsrb xmm15, r12d, 0x07
000073baab9cf38e  lea r14, [rax+0x1E]
000073baab9cf392  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf398  pinsrb xmm14, r12d, 0x07
000073baab9cf39f  lea r14, [rax+0x1F]
000073baab9cf3a3  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf3a9  pinsrb xmm13, r12d, 0x07
000073baab9cf3b0  lea r14, [rax+0x20]
000073baab9cf3b4  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf3ba  pinsrb xmm1, r12d, 0x08
000073baab9cf3c1  lea r14, [rax+0x21]
000073baab9cf3c5  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf3cb  pinsrb xmm15, r12d, 0x08
000073baab9cf3d2  lea r14, [rax+0x22]
000073baab9cf3d6  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf3dc  pinsrb xmm14, r12d, 0x08
000073baab9cf3e3  lea r14, [rax+0x23]
000073baab9cf3e7  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf3ed  pinsrb xmm13, r12d, 0x08
000073baab9cf3f4  lea r14, [rax+0x24]
000073baab9cf3f8  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf3fe  pinsrb xmm1, r12d, 0x09
000073baab9cf405  lea r14, [rax+0x25]
000073baab9cf409  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf40f  pinsrb xmm15, r12d, 0x09
000073baab9cf416  lea r14, [rax+0x26]
000073baab9cf41a  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf420  pinsrb xmm14, r12d, 0x09
000073baab9cf427  lea r14, [rax+0x27]
000073baab9cf42b  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf431  pinsrb xmm13, r12d, 0x09
000073baab9cf438  lea r14, [rax+0x28]
000073baab9cf43c  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf442  pinsrb xmm1, r12d, 0x0A
000073baab9cf449  lea r14, [rax+0x29]
000073baab9cf44d  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf453  pinsrb xmm15, r12d, 0x0A
000073baab9cf45a  lea r14, [rax+0x2A]
000073baab9cf45e  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf464  pinsrb xmm14, r12d, 0x0A
000073baab9cf46b  lea r14, [rax+0x2B]
000073baab9cf46f  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf475  pinsrb xmm13, r12d, 0x0A
000073baab9cf47c  lea r14, [rax+0x2C]
000073baab9cf480  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf486  pinsrb xmm1, r12d, 0x0B
000073baab9cf48d  lea r14, [rax+0x2D]
000073baab9cf491  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf497  pinsrb xmm15, r12d, 0x0B
000073baab9cf49e  lea r14, [rax+0x2E]
000073baab9cf4a2  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf4a8  pinsrb xmm14, r12d, 0x0B
000073baab9cf4af  lea r14, [rax+0x2F]
000073baab9cf4b3  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf4b9  pinsrb xmm13, r12d, 0x0B
000073baab9cf4c0  lea r14, [rax+0x30]
000073baab9cf4c4  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf4ca  pinsrb xmm1, r12d, 0x0C
000073baab9cf4d1  lea r14, [rax+0x31]
000073baab9cf4d5  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf4db  pinsrb xmm15, r12d, 0x0C
000073baab9cf4e2  lea r14, [rax+0x32]
000073baab9cf4e6  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf4ec  pinsrb xmm14, r12d, 0x0C
000073baab9cf4f3  lea r14, [rax+0x33]
000073baab9cf4f7  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf4fd  pinsrb xmm13, r12d, 0x0C
000073baab9cf504  lea r14, [rax+0x34]
000073baab9cf508  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf50e  pinsrb xmm1, r12d, 0x0D
000073baab9cf515  lea r14, [rax+0x35]
000073baab9cf519  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf51f  pinsrb xmm15, r12d, 0x0D
000073baab9cf526  lea r14, [rax+0x36]
000073baab9cf52a  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf530  pinsrb xmm14, r12d, 0x0D
000073baab9cf537  lea r14, [rax+0x37]
000073baab9cf53b  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf541  pinsrb xmm13, r12d, 0x0D
000073baab9cf548  lea r14, [rax+0x38]
000073baab9cf54c  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf552  pinsrb xmm1, r12d, 0x0E
000073baab9cf559  lea r14, [rax+0x39]
000073baab9cf55d  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf563  pinsrb xmm15, r12d, 0x0E
000073baab9cf56a  lea r14, [rax+0x3A]
000073baab9cf56e  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf574  pinsrb xmm14, r12d, 0x0E
000073baab9cf57b  lea r14, [rax+0x3B]
000073baab9cf57f  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf585  pinsrb xmm13, r12d, 0x0E
000073baab9cf58c  lea r14, [rax+0x3C]
000073baab9cf590  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf596  pinsrb xmm1, r12d, 0x0F
000073baab9cf59d  movaps [r15+0x110], xmm1
000073baab9cf5a5  lea r14, [rax+0x3D]
000073baab9cf5a9  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf5af  pinsrb xmm15, r12d, 0x0F
000073baab9cf5b6  movaps [r15+0x120], xmm15
000073baab9cf5be  lea r14, [rax+0x3E]
000073baab9cf5c2  movzx r12d, byte ptr [r13+r14*1]
000073baab9cf5c8  pinsrb xmm14, r12d, 0x0F
000073baab9cf5cf  movaps [r15+0x130], xmm14
000073baab9cf5d7  lea r14, [rax+0x3F]
000073baab9cf5db  movzx eax, byte ptr [r13+r14*1]
000073baab9cf5e1  pinsrb xmm13, eax, 0x0F
000073baab9cf5e8  movaps [r15+0x140], xmm13
000073baab9cf5f0  movq xmm1, qword ptr [r15+0x120]
000073baab9cf5f9  pmovzxbw xmm1, xmm1
000073baab9cf5fe  psllw xmm1, 0x00
000073baab9cf603  movaps [r15+0x150], xmm1
000073baab9cf60b  movq xmm1, qword ptr [r15+0x130]
000073baab9cf614  pmovzxbw xmm1, xmm1
000073baab9cf619  psllw xmm1, 0x00
000073baab9cf61e  movaps [r15+0x160], xmm1
000073baab9cf626  movq xmm1, qword ptr [r15+0x110]
000073baab9cf62f  pmovzxbw xmm1, xmm1
000073baab9cf634  psllw xmm1, 0x00
000073baab9cf639  movaps [r15+0x170], xmm1
000073baab9cf641  movaps xmm15, [r15+0x110]
000073baab9cf649  pextrq rax, xmm15, 0x01
000073baab9cf650  movq xmm15, rax
000073baab9cf655  pmovzxbw xmm15, xmm15
000073baab9cf65b  psllw xmm15, 0x00
000073baab9cf661  movaps [r15+0x180], xmm15
000073baab9cf669  movaps xmm14, [r15+0x120]
000073baab9cf671  pextrq rax, xmm14, 0x01
000073baab9cf678  movq xmm14, rax
000073baab9cf67d  pmovzxbw xmm14, xmm14
000073baab9cf683  psllw xmm14, 0x00
000073baab9cf689  movaps [r15+0x210], xmm14
000073baab9cf691  movaps xmm13, [r15+0x130]
000073baab9cf699  pextrq rax, xmm13, 0x01
000073baab9cf6a0  movq xmm13, rax
000073baab9cf6a5  pmovzxbw xmm13, xmm13
000073baab9cf6ab  psllw xmm13, 0x00
000073baab9cf6b1  movaps [r15+0x220], xmm13
000073baab9cf6b9  movq xmm12, qword ptr [r15+0x140]
000073baab9cf6c2  pmovzxbw xmm12, xmm12
000073baab9cf6c8  psllw xmm12, 0x00
000073baab9cf6ce  movaps [r15+0x250], xmm12
000073baab9cf6d6  movaps xmm12, [r15+0x140]
000073baab9cf6de  pextrq rax, xmm12, 0x01
000073baab9cf6e5  movq xmm12, rax
000073baab9cf6ea  pmovzxbw xmm12, xmm12
000073baab9cf6f0  psllw xmm12, 0x00
000073baab9cf6f6  movaps [r15+0x110], xmm12
000073baab9cf6fe  movq xmm11, qword ptr [r15+0x150]
000073baab9cf707  pmovzxwd xmm11, xmm11
000073baab9cf70d  pslld xmm11, 0x10
000073baab9cf713  movq xmm10, qword ptr [r15+0x160]
000073baab9cf71c  pmovzxwd xmm10, xmm10
000073baab9cf722  pslld xmm10, 0x08
000073baab9cf728  pextrq rax, xmm1, 0x01
000073baab9cf72f  movq xmm1, rax
000073baab9cf734  pmovzxwd xmm1, xmm1
000073baab9cf739  pslld xmm1, 0x00
000073baab9cf73e  movaps [r15+0x260], xmm1
000073baab9cf746  pextrq rax, xmm15, 0x01
000073baab9cf74d  movq xmm15, rax
000073baab9cf752  pmovzxwd xmm15, xmm15
000073baab9cf758  pslld xmm15, 0x00
000073baab9cf75e  movaps [r15+0x270], xmm15
000073baab9cf766  movq xmm9, qword ptr [r15+0x170]
000073baab9cf76f  pmovzxwd xmm9, xmm9
000073baab9cf775  pslld xmm9, 0x00
000073baab9cf77b  pextrq rax, xmm14, 0x01
000073baab9cf782  movq xmm14, rax
000073baab9cf787  pmovzxwd xmm14, xmm14
000073baab9cf78d  pslld xmm14, 0x10
000073baab9cf793  movaps [r15+0x280], xmm14
000073baab9cf79b  movq xmm8, qword ptr [r15+0x180]
000073baab9cf7a4  pmovzxwd xmm8, xmm8
000073baab9cf7aa  pslld xmm8, 0x00
000073baab9cf7b0  movq xmm7, qword ptr [r15+0x210]
000073baab9cf7b9  pmovzxwd xmm7, xmm7
000073baab9cf7be  pslld xmm7, 0x10
000073baab9cf7c3  movaps xmm6, [r15+0x150]
000073baab9cf7cb  pextrq rax, xmm6, 0x01
000073baab9cf7d2  movq xmm6, rax
000073baab9cf7d7  pmovzxwd xmm6, xmm6
000073baab9cf7dc  pslld xmm6, 0x10
000073baab9cf7e1  por xmm11, xmm10
000073baab9cf7e6  movaps [r15+0x230], xmm11
000073baab9cf7ee  pextrq rax, xmm13, 0x01
000073baab9cf7f5  movq xmm13, rax
000073baab9cf7fa  pmovzxwd xmm13, xmm13
000073baab9cf800  pslld xmm13, 0x08
000073baab9cf806  movaps [r15+0x240], xmm13
000073baab9cf80e  movq xmm10, qword ptr [r15+0x220]
000073baab9cf817  pmovzxwd xmm10, xmm10
000073baab9cf81d  pslld xmm10, 0x08
000073baab9cf823  movaps xmm5, [r15+0x160]
000073baab9cf82b  pextrq rax, xmm5, 0x01
000073baab9cf832  movq xmm5, rax
000073baab9cf837  pmovzxwd xmm5, xmm5
000073baab9cf83c  pslld xmm5, 0x08
000073baab9cf841  pslld xmm9, 0x18
000073baab9cf847  pslld xmm15, 0x18
000073baab9cf84d  pslld xmm8, 0x18
000073baab9cf853  movq xmm4, qword ptr [r15+0x250]
000073baab9cf85c  pmovzxwd xmm4, xmm4
000073baab9cf861  pslld xmm4, 0x00
000073baab9cf866  por xmm14, xmm13
000073baab9cf86b  por xmm7, xmm10
000073baab9cf870  movaps [r15+0x210], xmm7
000073baab9cf878  pslld xmm1, 0x18
000073baab9cf87d  movaps [r15+0x220], xmm1
000073baab9cf885  por xmm6, xmm5
000073baab9cf889  por xmm11, xmm9
000073baab9cf88e  movaps [r15+0x160], xmm11
000073baab9cf896  pextrq rax, xmm12, 0x01
000073baab9cf89d  movq xmm13, rax
000073baab9cf8a2  pmovzxwd xmm13, xmm13
000073baab9cf8a8  pslld xmm13, 0x00
000073baab9cf8ae  movaps [r15+0x170], xmm13
000073baab9cf8b6  movq xmm12, qword ptr [r15+0x110]
000073baab9cf8bf  pmovzxwd xmm12, xmm12
000073baab9cf8c5  pslld xmm12, 0x00
000073baab9cf8cb  por xmm14, xmm15
000073baab9cf8d0  por xmm7, xmm8
000073baab9cf8d5  movaps xmm15, [r15+0x250]
000073baab9cf8dd  pextrq rax, xmm15, 0x01
000073baab9cf8e4  movq xmm15, rax
000073baab9cf8e9  pmovzxwd xmm15, xmm15
000073baab9cf8ef  pslld xmm15, 0x00
000073baab9cf8f5  movaps [r15+0x180], xmm15
000073baab9cf8fd  por xmm6, xmm1
000073baab9cf901  movaps [r15+0x150], xmm6
000073baab9cf909  por xmm11, xmm4
000073baab9cf90e  movaps [r15+0x140], xmm11
000073baab9cf916  por xmm7, xmm12
000073baab9cf91b  movaps [r15+0x110], xmm7
000073baab9cf923  por xmm14, xmm13
000073baab9cf928  movaps [r15+0x120], xmm14
000073baab9cf930  por xmm6, xmm15
000073baab9cf935  movaps [r15+0x130], xmm6
000073baab9cf93d  mov rax, [r15+0xF8]
000073baab9cf944  lea r14, [rax+0x20]
000073baab9cf948  movups [r13+r14*1], xmm7
000073baab9cf94e  lea r14, [rax+0x30]
000073baab9cf952  movups [r13+r14*1], xmm14
000073baab9cf958  movups [r13+rax*1], xmm11
000073baab9cf95e  lea r14, [rax+0x10]
000073baab9cf962  movups [r13+r14*1], xmm6
000073baab9cf968  mov r14d, [r13+rax*1]
000073baab9cf96d  mov rax, [r15+0x48]
000073baab9cf971  mov [r15+0x68], rax
000073baab9cf975  mov qword ptr [r15+0x58], 0x04
000073baab9cf97d  lea r12, [rax+0x04]
000073baab9cf981  mov r11d, [r13+r12*1]
000073baab9cf986  mov [rsp+0x10], r11d
000073baab9cf98b  mov r11d, r11d
000073baab9cf98e  mov [r15+0x70], r11
000073baab9cf992  lea r12, [rax+0x38]
000073baab9cf996  mov r11d, [r13+r12*1]
000073baab9cf99b  lea r12, [rax+0x24]
000073baab9cf99f  mov r10d, [r13+r12*1]
000073baab9cf9a4  mov [rsp+0x20], r10d
000073baab9cf9a9  mov r10d, r10d
000073baab9cf9ac  mov [r15+0x90], r10
000073baab9cf9b3  mov [rsp+0x30], rax
000073baab9cf9b8  xor eax, eax
000073baab9cf9ba  mov r12d, 0x04
000073baab9cf9c0  mov r10d, 0xC0
000073baab9cf9c6  cmp r12, r10
000073baab9cf9c9  cmc
000073baab9cf9ca  lahf
000073baab9cf9cb  seto al
000073baab9cf9ce  mov [r15+0x108], eax
000073baab9cf9d5  mov eax, [rsp+0x10]
000073baab9cf9d9  mov r12d, [rsp+0x10]
000073baab9cf9de  shrd eax, r12d, 0x07
000073baab9cf9e3  mov [rsp+0x10], r11d
000073baab9cf9e8  mov r10d, [rsp+0x10]
000073baab9cf9ed  shrd r11d, r10d, 0x11
000073baab9cf9f2  mov r9d, [rsp+0x20]
000073baab9cf9f7  lea r8d, [r9d+r14d*1]
000073baab9cf9fc  rorx r14d, r12d, 0x12
000073baab9cfa02  xor eax, r14d
000073baab9cfa05  rorx r14d, r10d, 0x13
000073baab9cfa0b  xor r11d, r14d
000073baab9cfa0e  mov [rsp+0x10], r11d
000073baab9cfa13  mov r11d, r11d
000073baab9cfa16  mov [r15+0x88], r11
000073baab9cfa1d  mov [rsp+0x20], r12d
000073baab9cfa22  shr r12d, 0x03
000073baab9cfa26  xor eax, r12d
000073baab9cfa29  mov [rsp+0x40], eax
000073baab9cfa2d  mov eax, eax
000073baab9cfa2f  mov [r15+0x80], rax
000073baab9cfa36  shr r10d, 0x0A
000073baab9cfa3a  mov eax, [rsp+0x10]
000073baab9cfa3e  xor eax, r10d
000073baab9cfa41  mov [rsp+0x10], eax
000073baab9cfa45  mov eax, eax
000073baab9cfa47  mov [r15+0x78], rax
000073baab9cfa4b  mov eax, [rsp+0x40]
000073baab9cfa4f  lea r14d, [r8d+eax*1]
000073baab9cfa54  mov eax, [rsp+0x10]
000073baab9cfa58  lea r12d, [r14d+eax*1]
000073baab9cfa5d  mov rax, [rsp+0x30]
000073baab9cfa62  lea r14, [rax+0x40]
000073baab9cfa66  mov [r13+r14*1], r12d
000073baab9cfa6b  mov eax, [rsp+0x20]
000073baab9cfa6f  mov eax, eax
000073baab9cfa71  mov [r15+0x60], rax
000073baab9cfa75  mov eax, [r15+0x108]
000073baab9cfa7c  sahf
000073baab9cfa7d  jnz 0x000073BAAB9CFAAF
000073baab9cfa7f  cmp dword ptr [r15+0x318], 0x00
000073baab9cfa87  jz 0x000073BAAB9CFF70
000073baab9cfa8d  nop [rax+rax*1], ax
000073baab9cfa96  nop [rax+rax*1], eax
000073baab9cfa9e  mov eax, 0x41088C
000073baab9cfaa3  mov [r15+0x100], rax
000073baab9cfaaa  jmp 0x000073BAAB7FE110
000073baab9cfaaf  cmp dword ptr [r15+0x318], 0x00
000073baab9cfab7  jz 0x000073BAAB9CFDC0
000073baab9cfabd  nop [rax+rax*1], ax
000073baab9cfac6  nop [rax+rax*1], eax
000073baab9cface  mov eax, 0x410844
000073baab9cfad3  mov [r15+0x100], rax
000073baab9cfada  jmp 0x000073BAAB7FE110
000073baab9cfadf  int3
000073baab9cfae0  call 0x000073BAAB80D860
000073baab9cfae5  jmp 0x000073BAAB9CF17A
000073baab9cfaea  call 0x000073BAAB8E2420
000073baab9cfaef  jmp 0x000073BAAB9CF193
000073baab9cfaf4  call 0x000073BAAB8E2420
000073baab9cfaf9  jmp 0x000073BAAB9CF1AC
000073baab9cfafe  call 0x000073BAAB8E2420
000073baab9cfb03  jmp 0x000073BAAB9CF1C5
000073baab9cfb08  call 0x000073BAAB8E2420
000073baab9cfb0d  jmp 0x000073BAAB9CF1DE
000073baab9cfb12  call 0x000073BAAB8E2420
000073baab9cfb17  jmp 0x000073BAAB9CF1EF
000073baab9cfb1c  call 0x000073BAAB8E2420
000073baab9cfb21  jmp 0x000073BAAB9CF200
000073baab9cfb26  call 0x000073BAAB8E2420
000073baab9cfb2b  jmp 0x000073BAAB9CF211
000073baab9cfb30  call 0x000073BAAB8E2420
000073baab9cfb35  jmp 0x000073BAAB9CF222
000073baab9cfb3a  call 0x000073BAAB8E2420
000073baab9cfb3f  jmp 0x000073BAAB9CF233
000073baab9cfb44  call 0x000073BAAB8E2420
000073baab9cfb49  jmp 0x000073BAAB9CF244
000073baab9cfb4e  call 0x000073BAAB8E2420
000073baab9cfb53  jmp 0x000073BAAB9CF255
000073baab9cfb58  call 0x000073BAAB8E2420
000073baab9cfb5d  jmp 0x000073BAAB9CF266
000073baab9cfb62  call 0x000073BAAB8E2420
000073baab9cfb67  jmp 0x000073BAAB9CF277
000073baab9cfb6c  call 0x000073BAAB8E2420
000073baab9cfb71  jmp 0x000073BAAB9CF288
000073baab9cfb76  call 0x000073BAAB8E2420
000073baab9cfb7b  jmp 0x000073BAAB9CF299
000073baab9cfb80  call 0x000073BAAB8E2420
000073baab9cfb85  jmp 0x000073BAAB9CF2AA
000073baab9cfb8a  call 0x000073BAAB8E2420
000073baab9cfb8f  jmp 0x000073BAAB9CF2BB
000073baab9cfb94  call 0x000073BAAB8E2420
000073baab9cfb99  jmp 0x000073BAAB9CF2CC
000073baab9cfb9e  call 0x000073BAAB8E2420
000073baab9cfba3  jmp 0x000073BAAB9CF2DD
000073baab9cfba8  call 0x000073BAAB8E2420
000073baab9cfbad  jmp 0x000073BAAB9CF2EE
000073baab9cfbb2  call 0x000073BAAB8E2420
000073baab9cfbb7  jmp 0x000073BAAB9CF2FF
000073baab9cfbbc  call 0x000073BAAB8E2420
000073baab9cfbc1  jmp 0x000073BAAB9CF310
000073baab9cfbc6  call 0x000073BAAB8E2420
000073baab9cfbcb  jmp 0x000073BAAB9CF321
000073baab9cfbd0  call 0x000073BAAB8E2420
000073baab9cfbd5  jmp 0x000073BAAB9CF332
000073baab9cfbda  call 0x000073BAAB8E2420
000073baab9cfbdf  jmp 0x000073BAAB9CF343
000073baab9cfbe4  call 0x000073BAAB8E2420
000073baab9cfbe9  jmp 0x000073BAAB9CF354
000073baab9cfbee  call 0x000073BAAB8E2420
000073baab9cfbf3  jmp 0x000073BAAB9CF365
000073baab9cfbf8  call 0x000073BAAB8E2420
000073baab9cfbfd  jmp 0x000073BAAB9CF376
000073baab9cfc02  call 0x000073BAAB8E2420
000073baab9cfc07  jmp 0x000073BAAB9CF387
000073baab9cfc0c  call 0x000073BAAB8E2420
000073baab9cfc11  jmp 0x000073BAAB9CF398
000073baab9cfc16  call 0x000073BAAB8E2420
000073baab9cfc1b  jmp 0x000073BAAB9CF3A9
000073baab9cfc20  call 0x000073BAAB8E2420
000073baab9cfc25  jmp 0x000073BAAB9CF3BA
000073baab9cfc2a  call 0x000073BAAB8E2420
000073baab9cfc2f  jmp 0x000073BAAB9CF3CB
000073baab9cfc34  call 0x000073BAAB8E2420
000073baab9cfc39  jmp 0x000073BAAB9CF3DC
000073baab9cfc3e  call 0x000073BAAB8E2420
000073baab9cfc43  jmp 0x000073BAAB9CF3ED
000073baab9cfc48  call 0x000073BAAB8E2420
000073baab9cfc4d  jmp 0x000073BAAB9CF3FE
000073baab9cfc52  call 0x000073BAAB8E2420
000073baab9cfc57  jmp 0x000073BAAB9CF40F
000073baab9cfc5c  call 0x000073BAAB8E2420
000073baab9cfc61  jmp 0x000073BAAB9CF420
000073baab9cfc66  call 0x000073BAAB8E2420
000073baab9cfc6b  jmp 0x000073BAAB9CF431
000073baab9cfc70  call 0x000073BAAB8E2420
000073baab9cfc75  jmp 0x000073BAAB9CF442
000073baab9cfc7a  call 0x000073BAAB8E2420
000073baab9cfc7f  jmp 0x000073BAAB9CF453
000073baab9cfc84  call 0x000073BAAB8E2420
000073baab9cfc89  jmp 0x000073BAAB9CF464
000073baab9cfc8e  call 0x000073BAAB8E2420
000073baab9cfc93  jmp 0x000073BAAB9CF475
000073baab9cfc98  call 0x000073BAAB8E2420
000073baab9cfc9d  jmp 0x000073BAAB9CF486
000073baab9cfca2  call 0x000073BAAB8E2420
000073baab9cfca7  jmp 0x000073BAAB9CF497
000073baab9cfcac  call 0x000073BAAB8E2420
000073baab9cfcb1  jmp 0x000073BAAB9CF4A8
000073baab9cfcb6  call 0x000073BAAB8E2420
000073baab9cfcbb  jmp 0x000073BAAB9CF4B9
000073baab9cfcc0  call 0x000073BAAB8E2420
000073baab9cfcc5  jmp 0x000073BAAB9CF4CA
000073baab9cfcca  call 0x000073BAAB8E2420
000073baab9cfccf  jmp 0x000073BAAB9CF4DB
000073baab9cfcd4  call 0x000073BAAB8E2420
000073baab9cfcd9  jmp 0x000073BAAB9CF4EC
000073baab9cfcde  call 0x000073BAAB8E2420
000073baab9cfce3  jmp 0x000073BAAB9CF4FD
000073baab9cfce8  call 0x000073BAAB8E2420
000073baab9cfced  jmp 0x000073BAAB9CF50E
000073baab9cfcf2  call 0x000073BAAB8E2420
000073baab9cfcf7  jmp 0x000073BAAB9CF51F
000073baab9cfcfc  call 0x000073BAAB8E2420
000073baab9cfd01  jmp 0x000073BAAB9CF530
000073baab9cfd06  call 0x000073BAAB8E2420
000073baab9cfd0b  jmp 0x000073BAAB9CF541
000073baab9cfd10  call 0x000073BAAB8E2420
000073baab9cfd15  jmp 0x000073BAAB9CF552
000073baab9cfd1a  call 0x000073BAAB8E2420
000073baab9cfd1f  jmp 0x000073BAAB9CF563
000073baab9cfd24  call 0x000073BAAB8E2420
000073baab9cfd29  jmp 0x000073BAAB9CF574
000073baab9cfd2e  call 0x000073BAAB8E2420
000073baab9cfd33  jmp 0x000073BAAB9CF585
000073baab9cfd38  call 0x000073BAAB8E2420
000073baab9cfd3d  jmp 0x000073BAAB9CF596
000073baab9cfd42  call 0x000073BAAB8E2420
000073baab9cfd47  jmp 0x000073BAAB9CF5AF
000073baab9cfd4c  call 0x000073BAAB8E2420
000073baab9cfd51  jmp 0x000073BAAB9CF5C8
000073baab9cfd56  call 0x000073BAAB8D5610
000073baab9cfd5b  jmp 0x000073BAAB9CF5E1
000073baab9cfd60  call 0x000073BAAB8DC580
000073baab9cfd65  jmp 0x000073BAAB9CF94E
000073baab9cfd6a  call 0x000073BAAB8E46C0
000073baab9cfd6f  jmp 0x000073BAAB9CF958
000073baab9cfd74  call 0x000073BAAB809E90
000073baab9cfd79  jmp 0x000073BAAB9CF95E
000073baab9cfd7e  call 0x000073BAAB8DB310
000073baab9cfd83  jmp 0x000073BAAB9CF968
000073baab9cfd88  call 0x000073BAAB80DAE0
000073baab9cfd8d  jmp 0x000073BAAB9CF96D
000073baab9cfd92  call 0x000073BAAB8C0230
000073baab9cfd97  jmp 0x000073BAAB9CF986
000073baab9cfd9c  call 0x000073BAAB8C0230
000073baab9cfda1  jmp 0x000073BAAB9CF99B
000073baab9cfda6  call 0x000073BAAB8BEFC0
000073baab9cfdab  jmp 0x000073BAAB9CF9A4
000073baab9cfdb0  call 0x000073BAAB8E2BA0
000073baab9cfdb5  jmp 0x000073BAAB9CFA6B
000073baab9cfdba  int3
000073baab9cfdbb  nop [rax+rax*1], eax
000073baab9cfdc0  mov rax, [r15+0x48]
000073baab9cfdc4  mov r14, [r15+0x58]
000073baab9cfdc8  lea r12, [rax+r14*1]
000073baab9cfdcc  mov [r15+0x68], r12
000073baab9cfdd0  lea rax, [r14+0x04]
000073baab9cfdd4  mov [r15+0x58], rax
000073baab9cfdd8  lea r14, [r12+0x04]
000073baab9cfddd  mov r11d, [r13+r14*1]
000073baab9cfde2  mov [rsp+0x10], r11d
000073baab9cfde7  mov r11d, r11d
000073baab9cfdea  mov [r15+0x70], r11
000073baab9cfdee  lea r14, [r12+0x38]
000073baab9cfdf3  mov r11d, [r13+r14*1]
000073baab9cfdf8  lea r14, [r12+0x24]
000073baab9cfdfd  mov r10d, [r13+r14*1]
000073baab9cfe02  mov [rsp+0x20], r10d
000073baab9cfe07  mov r10d, r10d
000073baab9cfe0a  mov [r15+0x90], r10
000073baab9cfe11  mov [rsp+0x30], rax
000073baab9cfe16  xor eax, eax
000073baab9cfe18  mov r14, [rsp+0x30]
000073baab9cfe1d  mov r10d, 0xC0
000073baab9cfe23  cmp r14, r10
000073baab9cfe26  cmc
000073baab9cfe27  lahf
000073baab9cfe28  seto al
000073baab9cfe2b  mov [r15+0x108], eax
000073baab9cfe32  mov eax, [rsp+0x10]
000073baab9cfe36  mov r14d, [rsp+0x10]
000073baab9cfe3b  shrd eax, r14d, 0x07
000073baab9cfe40  mov [rsp+0x10], r11d
000073baab9cfe45  mov r10d, [rsp+0x10]
000073baab9cfe4a  shrd r11d, r10d, 0x11
000073baab9cfe4f  mov r9d, [r15+0x60]
000073baab9cfe53  mov r8d, [rsp+0x20]
000073baab9cfe58  lea ebp, [r8d+r9d*1]
000073baab9cfe5d  rorx r9d, r14d, 0x12
000073baab9cfe63  xor eax, r9d
000073baab9cfe66  rorx r9d, r10d, 0x13
000073baab9cfe6c  xor r11d, r9d
000073baab9cfe6f  mov [rsp+0x10], r11d
000073baab9cfe74  mov r11d, r11d
000073baab9cfe77  mov [r15+0x88], r11
000073baab9cfe7e  mov [rsp+0x20], r14d
000073baab9cfe83  shr r14d, 0x03
000073baab9cfe87  xor eax, r14d
000073baab9cfe8a  mov [rsp+0x30], eax
000073baab9cfe8e  mov eax, eax
000073baab9cfe90  mov [r15+0x80], rax
000073baab9cfe97  shr r10d, 0x0A
000073baab9cfe9b  mov eax, [rsp+0x10]
000073baab9cfe9f  xor eax, r10d
000073baab9cfea2  mov [rsp+0x10], eax
000073baab9cfea6  mov eax, eax
000073baab9cfea8  mov [r15+0x78], rax
000073baab9cfeac  mov eax, [rsp+0x30]
000073baab9cfeb0  lea r14d, [ebp+eax*1]
000073baab9cfeb6  mov eax, [rsp+0x10]
000073baab9cfeba  lea r11d, [r14d+eax*1]
000073baab9cfebf  lea rax, [r12+0x40]
000073baab9cfec4  mov [r13+rax*1], r11d
000073baab9cfec9  mov eax, [rsp+0x20]
000073baab9cfecd  mov eax, eax
000073baab9cfecf  mov [r15+0x60], rax
000073baab9cfed3  mov eax, [r15+0x108]
000073baab9cfeda  sahf
000073baab9cfedb  jnz 0x000073BAAB9CFF0D
000073baab9cfedd  cmp dword ptr [r15+0x318], 0x00
000073baab9cfee5  jz 0x000073BAAB9CFF70
000073baab9cfeeb  nop [rax+rax*1], ax
000073baab9cfef4  nop [rax+rax*1], eax
000073baab9cfefc  mov eax, 0x41088C
000073baab9cff01  mov [r15+0x100], rax
000073baab9cff08  jmp 0x000073BAAB7FE110
000073baab9cff0d  cmp dword ptr [r15+0x318], 0x00
000073baab9cff15  jz 0x000073BAAB9CFDC0
000073baab9cff1b  nop [rax+rax*1], ax
000073baab9cff24  nop [rax+rax*1], eax
000073baab9cff2c  mov eax, 0x410844
000073baab9cff31  mov [r15+0x100], rax
000073baab9cff38  jmp 0x000073BAAB7FE110
000073baab9cff3d  int3
000073baab9cff3e  call 0x000073BAAB8E1430
000073baab9cff43  jmp 0x000073BAAB9CFDE2
000073baab9cff48  call 0x000073BAAB8E1430
000073baab9cff4d  jmp 0x000073BAAB9CFDF8
000073baab9cff52  call 0x000073BAAB8E01C0
000073baab9cff57  jmp 0x000073BAAB9CFE02
000073baab9cff5c  call 0x000073BAAB80A860
000073baab9cff61  jmp 0x000073BAAB9CFEC9
000073baab9cff66  int3
000073baab9cff67  nop [rax+rax*1], ax
000073baab9cff70  mov rax, [r15]
000073baab9cff73  mov r14d, [r13+rax*1]
000073baab9cff78  lea r12, [rax+0x04]
000073baab9cff7c  mov r11d, [r13+r12*1]
000073baab9cff81  mov [rsp+0x10], r14d
000073baab9cff86  mov r14d, r14d
000073baab9cff89  mov [r15+0x78], r14
000073baab9cff8d  mov [rsp+0x20], r11d
000073baab9cff92  mov r11d, r11d
000073baab9cff95  mov [r15+0x80], r11
000073baab9cff9c  lea r14, [rax+0x08]
000073baab9cffa0  mov r12d, [r13+r14*1]
000073baab9cffa5  lea r14, [rax+0x0C]
000073baab9cffa9  mov r11d, [r13+r14*1]
000073baab9cffae  mov [rsp+0x30], r12d
000073baab9cffb3  mov r12d, r12d
000073baab9cffb6  mov [r15+0x70], r12
000073baab9cffba  mov [rsp+0x40], r11d
000073baab9cffbf  mov r11d, r11d
000073baab9cffc2  mov [r15+0x68], r11
000073baab9cffc6  lea r14, [rax+0x18]
000073baab9cffca  mov r12d, [r13+r14*1]
000073baab9cffcf  lea r14, [rax+0x1C]
000073baab9cffd3  mov r11d, [r13+r14*1]
000073baab9cffd8  mov [rsp+0x50], r12d
000073baab9cffdd  mov r12d, r12d
000073baab9cffe0  mov [r15+0x58], r12
000073baab9cffe4  mov [rsp+0x60], r11d
000073baab9cffe9  mov r11d, r11d
000073baab9cffec  mov [r15+0x60], r11
000073baab9cfff0  lea r14, [rax+0x10]
000073baab9cfff4  mov r12d, [r13+r14*1]
000073baab9cfff9  lea r14, [rax+0x14]
000073baab9cfffd  mov eax, [r13+r14*1]
000073baab9d0002  mov [rsp+0x70], r12d
000073baab9d0007  mov r12d, r12d
000073baab9d000a  mov [r15+0x18], r12
000073baab9d000e  mov [rsp+0x80], eax
000073baab9d0015  mov eax, eax
000073baab9d0017  mov [r15+0x90], rax
000073baab9d001e  mov eax, [rsp+0x70]
000073baab9d0022  mov eax, eax
000073baab9d0024  mov [r15+0x30], rax
000073baab9d0028  mov eax, [rsp+0x50]
000073baab9d002c  mov eax, eax
000073baab9d002e  mov [r15+0xA0], rax
000073baab9d0035  mov eax, [rsp+0x30]
000073baab9d0039  mov eax, eax
000073baab9d003b  mov [r15+0x28], rax
000073baab9d003f  mov eax, [rsp+0x20]
000073baab9d0043  mov eax, eax
000073baab9d0045  mov [r15+0x98], rax
000073baab9d004c  mov eax, [rsp+0x10]
000073baab9d0050  mov eax, eax
000073baab9d0052  mov [r15+0x38], rax
000073baab9d0056  mov eax, [rsp+0x70]
000073baab9d005a  mov r14d, [rsp+0x70]
000073baab9d005f  shrd eax, r14d, 0x06
000073baab9d0064  mov [rsp+0x70], r14d
000073baab9d0069  mov r12d, [rsp+0x80]
000073baab9d0071  and r14d, r12d
000073baab9d0074  mov r11d, [rsp+0x10]
000073baab9d0079  mov r10d, [rsp+0x10]
000073baab9d007e  shrd r11d, r10d, 0x02
000073baab9d0083  mov [rsp+0x10], r12d
000073baab9d0088  mov r12d, r12d
000073baab9d008b  mov [r15+0x20], r12
000073baab9d008f  mov r12, [r15+0x50]
000073baab9d0093  mov r9d, [r13+r12*1]
000073baab9d0098  mov r12d, [rsp+0x50]
000073baab9d009d  mov r8d, [rsp+0x70]
000073baab9d00a2  andn ebp, r8d, r12d
000073baab9d00a7  mov edi, [rsp+0x60]
000073baab9d00ab  lea esi, [r14d+edi*1]
000073baab9d00b0  rorx r14d, r8d, 0x0B
000073baab9d00b6  xor eax, r14d
000073baab9d00b9  rorx r14d, r10d, 0x0D
000073baab9d00bf  xor r11d, r14d
000073baab9d00c2  lea edi, [esi+ebp*1]
000073baab9d00c6  mov r14, [r15+0x48]
000073baab9d00ca  mov ebp, [r13+r14*1]
000073baab9d00cf  mov r14d, [rsp+0x30]
000073baab9d00d4  mov esi, [rsp+0x20]
000073baab9d00d8  and r14d, esi
000073baab9d00db  mov [rsp+0x20], r14d
000073baab9d00e0  mov r14d, r14d
000073baab9d00e3  mov [r15+0xD8], r14
000073baab9d00ea  lea r14d, [edi+r9d*1]
000073baab9d00ef  mov r9d, [rsp+0x30]
000073baab9d00f4  xor r9d, esi
000073baab9d00f7  rorx edi, r8d, 0x19
000073baab9d00fd  xor eax, edi
000073baab9d00ff  and r9d, r10d
000073baab9d0102  rorx edi, r10d, 0x16
000073baab9d0108  xor r11d, edi
000073baab9d010b  mov [rsp+0x30], r11d
000073baab9d0110  mov r11d, r11d
000073baab9d0113  mov [r15+0xD0], r11
000073baab9d011a  lea r11d, [r14d+ebp*1]
000073baab9d011f  mov r10d, [rsp+0x20]
000073baab9d0124  xor r9d, r10d
000073baab9d0127  lea r14d, [r11d+eax*1]
000073baab9d012c  mov qword ptr [r15+0x88], 0x04
000073baab9d0137  mov eax, [rsp+0x30]
000073baab9d013b  lea r11d, [r9d+eax*1]
000073baab9d0140  mov eax, [rsp+0x40]
000073baab9d0144  lea r10d, [r14d+eax*1]
000073baab9d0149  mov r10d, r10d
000073baab9d014c  mov [r15+0xB8], r10
000073baab9d0153  xor eax, eax
000073baab9d0155  mov r10d, 0x04
000073baab9d015b  mov r9d, 0x100
000073baab9d0161  cmp r10, r9
000073baab9d0164  cmc
000073baab9d0165  lahf
000073baab9d0166  seto al
000073baab9d0169  mov [r15+0x108], eax
000073baab9d0170  lea eax, [r11d+r14d*1]
000073baab9d0175  mov eax, eax
000073baab9d0177  mov [r15+0xA8], rax
000073baab9d017e  mov r12d, r12d
000073baab9d0181  mov [r15+0xB0], r12
000073baab9d0188  mov eax, [rsp+0x10]
000073baab9d018c  mov eax, eax
000073baab9d018e  mov [r15+0xC0], rax
000073baab9d0195  mov r8d, r8d
000073baab9d0198  mov [r15+0xC8], r8
000073baab9d019f  mov eax, [r15+0x108]
000073baab9d01a6  sahf
000073baab9d01a7  jnz 0x000073BAAB9D01D9
000073baab9d01a9  cmp dword ptr [r15+0x318], 0x00
000073baab9d01b1  jz 0x000073BAAB9D04A0
000073baab9d01b7  nop [rax+rax*1], ax
000073baab9d01c0  nop [rax+rax*1], eax
000073baab9d01c8  mov eax, 0x41094C
000073baab9d01cd  mov [r15+0x100], rax
000073baab9d01d4  jmp 0x000073BAAB7FE110
000073baab9d01d9  cmp dword ptr [r15+0x318], 0x00
000073baab9d01e1  jz 0x000073BAAB9D0270
000073baab9d01e7  nop [rax+rax*1], ax
000073baab9d01f0  nop [rax+rax*1], eax
000073baab9d01f8  mov eax, 0x4108C0
000073baab9d01fd  mov [r15+0x100], rax
000073baab9d0204  jmp 0x000073BAAB7FE110
000073baab9d0209  int3
000073baab9d020a  call 0x000073BAAB80DAE0
000073baab9d020f  jmp 0x000073BAAB9CFF78
000073baab9d0214  call 0x000073BAAB8C0230
000073baab9d0219  jmp 0x000073BAAB9CFF81
000073baab9d021e  call 0x000073BAAB8E26A0
000073baab9d0223  jmp 0x000073BAAB9CFFA5
000073baab9d0228  call 0x000073BAAB8E1430
000073baab9d022d  jmp 0x000073BAAB9CFFAE
000073baab9d0232  call 0x000073BAAB8E26A0
000073baab9d0237  jmp 0x000073BAAB9CFFCF
000073baab9d023c  call 0x000073BAAB8E1430
000073baab9d0241  jmp 0x000073BAAB9CFFD8
000073baab9d0246  call 0x000073BAAB8E26A0
000073baab9d024b  jmp 0x000073BAAB9CFFF9
000073baab9d0250  call 0x000073BAAB8D5890
000073baab9d0255  jmp 0x000073BAAB9D0002
000073baab9d025a  call 0x000073BAAB8BDD50
000073baab9d025f  jmp 0x000073BAAB9D0098
000073baab9d0264  call 0x000073BAAB8DA580
000073baab9d0269  jmp 0x000073BAAB9D00CF
000073baab9d026e  int3
000073baab9d026f  nop
000073baab9d0270  mov eax, [r15+0xB8]
000073baab9d0277  mov [rsp+0x10], eax
000073baab9d027b  mov eax, eax
000073baab9d027d  mov [r15+0x30], rax
000073baab9d0281  mov eax, [r15+0xC0]
000073baab9d0288  mov [rsp+0x20], eax
000073baab9d028c  mov eax, eax
000073baab9d028e  mov [r15+0xA0], rax
000073baab9d0295  mov eax, [r15+0x28]
000073baab9d0299  mov r14d, [r15+0x98]
000073baab9d02a0  mov [rsp+0x30], r14d
000073baab9d02a5  mov r14d, r14d
000073baab9d02a8  mov [r15+0x28], r14
000073baab9d02ac  mov r14d, [r15+0x38]
000073baab9d02b0  mov [rsp+0x40], r14d
000073baab9d02b5  mov r14d, r14d
000073baab9d02b8  mov [r15+0x98], r14
000073baab9d02bf  mov r14d, [r15+0xA8]
000073baab9d02c6  mov [rsp+0x50], r14d
000073baab9d02cb  mov r14d, r14d
000073baab9d02ce  mov [r15+0x38], r14
000073baab9d02d2  mov r14d, [rsp+0x10]
000073baab9d02d7  mov r12d, [rsp+0x10]
000073baab9d02dc  shrd r14d, r12d, 0x06
000073baab9d02e1  mov r11d, [r15+0xC8]
000073baab9d02e8  mov [rsp+0x10], r12d
000073baab9d02ed  and r12d, r11d
000073baab9d02f0  mov r10d, [rsp+0x50]
000073baab9d02f5  mov r9d, [rsp+0x50]
000073baab9d02fa  shrd r10d, r9d, 0x02
000073baab9d02ff  mov [rsp+0x50], r11d
000073baab9d0304  mov r11d, r11d
000073baab9d0307  mov [r15+0x20], r11
000073baab9d030b  mov r11, [r15+0x88]
000073baab9d0312  mov r8, [r15+0x50]
000073baab9d0316  lea rbp, [r8+r11*1]
000073baab9d031a  mov r8d, [r13+rbp*1]
000073baab9d031f  mov ebp, [rsp+0x20]
000073baab9d0323  mov edi, [rsp+0x10]
000073baab9d0327  andn esi, edi, ebp
000073baab9d032c  mov edx, [r15+0xB0]
000073baab9d0333  lea ecx, [r12d+edx*1]
000073baab9d0338  rorx r12d, edi, 0x0B
000073baab9d033e  xor r14d, r12d
000073baab9d0341  rorx r12d, r9d, 0x0D
000073baab9d0347  xor r10d, r12d
000073baab9d034a  lea r12d, [ecx+esi*1]
000073baab9d034f  mov rsi, [r15+0x48]
000073baab9d0353  lea rdx, [rsi+r11*1]
000073baab9d0357  mov esi, [r13+rdx*1]
000073baab9d035c  mov edx, [rsp+0x30]
000073baab9d0360  mov ecx, [rsp+0x40]
000073baab9d0364  and edx, ecx
000073baab9d0366  mov [rsp+0x10], edx
000073baab9d036a  mov edx, edx
000073baab9d036c  mov [r15+0xD8], rdx
000073baab9d0373  lea edx, [r12d+r8d*1]
000073baab9d0378  mov r12d, [rsp+0x30]
000073baab9d037d  xor r12d, ecx
000073baab9d0380  rorx r8d, edi, 0x19
000073baab9d0386  xor r14d, r8d
000073baab9d0389  and r12d, r9d
000073baab9d038c  rorx r8d, r9d, 0x16
000073baab9d0392  xor r10d, r8d
000073baab9d0395  mov [rsp+0x20], r10d
000073baab9d039a  mov r10d, r10d
000073baab9d039d  mov [r15+0xD0], r10
000073baab9d03a4  lea r10d, [edx+esi*1]
000073baab9d03a9  mov r9d, [rsp+0x10]
000073baab9d03ae  xor r12d, r9d
000073baab9d03b1  lea r9d, [r10d+r14d*1]
000073baab9d03b6  lea r14, [r11+0x04]
000073baab9d03ba  mov [r15+0x88], r14
000073baab9d03c1  mov r11d, [rsp+0x20]
000073baab9d03c6  lea r10d, [r12d+r11d*1]
000073baab9d03cb  lea r11d, [r9d+eax*1]
000073baab9d03d0  mov r11d, r11d
000073baab9d03d3  mov [r15+0xB8], r11
000073baab9d03da  xor eax, eax
000073baab9d03dc  mov r12d, 0x100
000073baab9d03e2  cmp r14, r12
000073baab9d03e5  cmc
000073baab9d03e6  lahf
000073baab9d03e7  seto al
000073baab9d03ea  mov [r15+0x108], eax
000073baab9d03f1  lea eax, [r10d+r9d*1]
000073baab9d03f6  mov eax, eax
000073baab9d03f8  mov [r15+0xA8], rax
000073baab9d03ff  mov ebp, ebp
000073baab9d0401  mov [r15+0xB0], rbp
000073baab9d0408  mov eax, [rsp+0x50]
000073baab9d040c  mov eax, eax
000073baab9d040e  mov [r15+0xC0], rax
000073baab9d0415  mov edi, edi
000073baab9d0417  mov [r15+0xC8], rdi
000073baab9d041e  mov eax, [r15+0x108]
000073baab9d0425  sahf
000073baab9d0426  jnz 0x000073BAAB9D0458
000073baab9d0428  cmp dword ptr [r15+0x318], 0x00
000073baab9d0430  jz 0x000073BAAB9D04A0
000073baab9d0436  nop [rax+rax*1], ax
000073baab9d043f  nop [rax+rax*1], eax
000073baab9d0447  mov eax, 0x41094C
000073baab9d044c  mov [r15+0x100], rax
000073baab9d0453  jmp 0x000073BAAB7FE110
000073baab9d0458  cmp dword ptr [r15+0x318], 0x00
000073baab9d0460  jz 0x000073BAAB9D0270
000073baab9d0466  nop [rax+rax*1], ax
000073baab9d046f  nop [rax+rax*1], eax
000073baab9d0477  mov eax, 0x4108C0
000073baab9d047c  mov [r15+0x100], rax
000073baab9d0483  jmp 0x000073BAAB7FE110
000073baab9d0488  int3
000073baab9d0489  call 0x000073BAAB849010
000073baab9d048e  jmp 0x000073BAAB9D031F
000073baab9d0493  call 0x000073BAAB825930
000073baab9d0498  jmp 0x000073BAAB9D035C
000073baab9d049d  int3
000073baab9d049e  nop
000073baab9d04a0  mov eax, [r15+0x98]
000073baab9d04a7  mov r14d, [r15+0x70]
000073baab9d04ab  lea r12d, [eax+r14d*1]
000073baab9d04b0  mov eax, [r15+0x28]
000073baab9d04b4  mov r14d, [r15+0x68]
000073baab9d04b8  lea r11d, [eax+r14d*1]
000073baab9d04bd  mov qword ptr [r15+0x88], 0x00
000073baab9d04c8  mov eax, [r15+0xA8]
000073baab9d04cf  mov r14d, [r15+0x78]
000073baab9d04d3  lea r10d, [eax+r14d*1]
000073baab9d04d8  mov [rsp+0x10], r10d
000073baab9d04dd  mov r10d, r10d
000073baab9d04e0  mov [r15+0x78], r10
000073baab9d04e4  mov eax, [r15+0x38]
000073baab9d04e8  mov r14d, [r15+0x80]
000073baab9d04ef  lea r10d, [eax+r14d*1]
000073baab9d04f4  mov [rsp+0x20], r10d
000073baab9d04f9  mov r10d, r10d
000073baab9d04fc  mov [r15+0x80], r10
000073baab9d0503  mov rax, [r15]
000073baab9d0506  lea r14, [rax+0x08]
000073baab9d050a  mov [r13+r14*1], r12d
000073baab9d050f  lea r14, [rax+0x0C]
000073baab9d0513  mov [r13+r14*1], r11d
000073baab9d0518  mov r14d, [r15+0xB8]
000073baab9d051f  mov r12d, [r15+0x18]
000073baab9d0523  lea r11d, [r14d+r12d*1]
000073baab9d0528  mov [rsp+0x30], r11d
000073baab9d052d  mov r11d, r11d
000073baab9d0530  mov [r15+0x68], r11
000073baab9d0534  mov r14d, [r15+0x30]
000073baab9d0538  mov r12d, [r15+0x90]
000073baab9d053f  lea r11d, [r14d+r12d*1]
000073baab9d0544  mov [rsp+0x40], r11d
000073baab9d0549  mov r11d, r11d
000073baab9d054c  mov [r15+0x70], r11
000073baab9d0550  mov r14d, [r15+0x20]
000073baab9d0554  mov r12d, [r15+0x58]
000073baab9d0558  lea r11d, [r14d+r12d*1]
000073baab9d055d  mov [rsp+0x50], r11d
000073baab9d0562  mov r11d, r11d
000073baab9d0565  mov [r15+0x58], r11
000073baab9d0569  mov r14d, [r15+0xA0]
000073baab9d0570  mov r12d, [r15+0x60]
000073baab9d0574  lea r11d, [r14d+r12d*1]
000073baab9d0579  mov [rsp+0x60], r11d
000073baab9d057e  mov r11d, r11d
000073baab9d0581  mov [r15+0x60], r11
000073baab9d0585  mov r14d, [rsp+0x10]
000073baab9d058a  mov [r13+rax*1], r14d
000073baab9d058f  lea r14, [rax+0x04]
000073baab9d0593  mov r12d, [rsp+0x20]
000073baab9d0598  mov [r13+r14*1], r12d
000073baab9d059d  lea r14, [rax+0x10]
000073baab9d05a1  mov r12d, [rsp+0x30]
000073baab9d05a6  mov [r13+r14*1], r12d
000073baab9d05ab  lea r14, [rax+0x14]
000073baab9d05af  mov r12d, [rsp+0x40]
000073baab9d05b4  mov [r13+r14*1], r12d
000073baab9d05b9  lea r14, [rax+0x18]
000073baab9d05bd  mov r12d, [rsp+0x50]
000073baab9d05c2  mov [r13+r14*1], r12d
000073baab9d05c7  lea r14, [rax+0x1C]
000073baab9d05cb  mov r12d, [rsp+0x60]
000073baab9d05d0  mov [r13+r14*1], r12d
000073baab9d05d5  lea r14, [rax+0x68]
000073baab9d05d9  xor eax, eax
000073baab9d05db  mov [r13+r14*1], rax
000073baab9d05e0  cmp dword ptr [r15+0x318], 0x00
000073baab9d05e8  jz 0x000073BAAB9CF0E0
000073baab9d05ee  nop [rax+rax*1], ax
000073baab9d05f7  nop [rax+rax*1], eax
000073baab9d05ff  mov eax, 0x410768
000073baab9d0604  mov [r15+0x100], rax
000073baab9d060b  jmp 0x000073BAAB7FE110
000073baab9d0610  int3
000073baab9d0611  call 0x000073BAAB8E2BA0
000073baab9d0616  jmp 0x000073BAAB9D050F
000073baab9d061b  call 0x000073BAAB8E1920
000073baab9d0620  jmp 0x000073BAAB9D0518
000073baab9d0625  call 0x000073BAAB80DFE0
000073baab9d062a  jmp 0x000073BAAB9D058F
000073baab9d062f  call 0x000073BAAB8E2BA0
000073baab9d0634  jmp 0x000073BAAB9D059D
000073baab9d0639  call 0x000073BAAB8E2BA0
000073baab9d063e  jmp 0x000073BAAB9D05AB
000073baab9d0643  call 0x000073BAAB8E2BA0
000073baab9d0648  jmp 0x000073BAAB9D05B9
000073baab9d064d  call 0x000073BAAB8E2BA0
000073baab9d0652  jmp 0x000073BAAB9D05C7
000073baab9d0657  call 0x000073BAAB8E2BA0
000073baab9d065c  jmp 0x000073BAAB9D05D5
000073baab9d0661  call 0x000073BAAB8D5EB0
000073baab9d0666  jmp 0x000073BAAB9D05E0
000073baab9d066b  int3
000073baab9d066c  nop [rax], eax
000073baab9d0670  mov rax, [r15+0xF8]
000073baab9d0677  lea r14, [rax+0x140]
000073baab9d067e  mov r12, [r13+r14*1]
000073baab9d0683  lea r14, [rax+0x148]
000073baab9d068a  mov r11, [r13+r14*1]
000073baab9d068f  mov [r15+0xA0], r12
000073baab9d0696  mov [r15+0x98], r11
000073baab9d069d  lea r14, [rax+0x130]
000073baab9d06a4  mov r12, [r13+r14*1]
000073baab9d06a9  lea r14, [rax+0x138]
000073baab9d06b0  mov r11, [r13+r14*1]
000073baab9d06b5  mov [r15+0xB0], r12
000073baab9d06bc  mov [r15+0xA8], r11
000073baab9d06c3  lea r14, [rax+0x120]
000073baab9d06ca  mov r12, [r13+r14*1]
000073baab9d06cf  lea r14, [rax+0x128]
000073baab9d06d6  mov r11, [r13+r14*1]
000073baab9d06db  mov [r15+0xC0], r12
000073baab9d06e2  mov [r15+0xB8], r11
000073baab9d06e9  lea r14, [rax+0x110]
000073baab9d06f0  mov r12, [r13+r14*1]
000073baab9d06f5  lea r14, [rax+0x118]
000073baab9d06fc  mov r11, [r13+r14*1]
000073baab9d0701  mov [r15+0xD0], r12
000073baab9d0708  mov [r15+0xC8], r11
000073baab9d070f  lea r14, [rax+0x100]
000073baab9d0716  mov r12, [r13+r14*1]
000073baab9d071b  lea r14, [rax+0x108]
000073baab9d0722  mov r11, [r13+r14*1]
000073baab9d0727  mov [r15+0xE8], r12
000073baab9d072e  mov [r15+0xD8], r11
000073baab9d0735  lea r14, [rax+0x150]
000073baab9d073c  mov [r15+0xF8], r14
000073baab9d0743  mov rax, [r15+0xF0]
000073baab9d074a  mov [r15+0x100], rax
000073baab9d0751  jmp 0x000073BAAB9CE5C0
000073baab9d0756  int3
000073baab9d0757  call 0x000073BAAB8E27E0
000073baab9d075c  jmp 0x000073BAAB9D0683
000073baab9d0761  call 0x000073BAAB8E1570
000073baab9d0766  jmp 0x000073BAAB9D068F
000073baab9d076b  call 0x000073BAAB8E27E0
000073baab9d0770  jmp 0x000073BAAB9D06A9
000073baab9d0775  call 0x000073BAAB8E1570
000073baab9d077a  jmp 0x000073BAAB9D06B5
000073baab9d077f  call 0x000073BAAB8E27E0
000073baab9d0784  jmp 0x000073BAAB9D06CF
000073baab9d0789  call 0x000073BAAB8E1570
000073baab9d078e  jmp 0x000073BAAB9D06DB
000073baab9d0793  call 0x000073BAAB8E27E0
000073baab9d0798  jmp 0x000073BAAB9D06F5
000073baab9d079d  call 0x000073BAAB8E1570
000073baab9d07a2  jmp 0x000073BAAB9D0701
000073baab9d07a7  call 0x000073BAAB8E27E0
000073baab9d07ac  jmp 0x000073BAAB9D071B
000073baab9d07b1  call 0x000073BAAB8E1570
000073baab9d07b6  jmp 0x000073BAAB9D0727
000073baab9d07bb  int3
000073baab9d07bc  nop [rax], eax
000073baab9d07c0  mov eax, [r15+0xA0]
000073baab9d07c7  mov [rsp+0x10], eax
000073baab9d07cb  xor eax, eax
000073baab9d07cd  mov r14d, [rsp+0x10]
000073baab9d07d2  sub r14d, 0x01
000073baab9d07d6  cmc
000073baab9d07d7  lahf
000073baab9d07d8  seto al
000073baab9d07db  mov [r15+0x108], eax
000073baab9d07e2  mov r14d, r14d
000073baab9d07e5  mov [r15+0xA0], r14
000073baab9d07ec  mov eax, [r15+0x108]
000073baab9d07f3  sahf
000073baab9d07f4  jnz 0x000073BAAB9D0826
000073baab9d07f6  cmp dword ptr [r15+0x318], 0x00
000073baab9d07fe  jz 0x000073BAAB9D0900
000073baab9d0804  nop [rax+rax*1], ax
000073baab9d080d  nop [rax+rax*1], eax
000073baab9d0815  mov eax, 0x41028C
000073baab9d081a  mov [r15+0x100], rax
000073baab9d0821  jmp 0x000073BAAB7FE110
000073baab9d0826  cmp dword ptr [r15+0x318], 0x00
000073baab9d082e  jz 0x000073BAAB9D0860
000073baab9d0834  nop [rax+rax*1], ax
000073baab9d083d  nop [rax+rax*1], eax
000073baab9d0845  mov eax, 0x410274
000073baab9d084a  mov [r15+0x100], rax
000073baab9d0851  jmp 0x000073BAAB7FE110
000073baab9d0856  int3
000073baab9d0857  int3
000073baab9d0858  nop [rax+rax*1], eax
000073baab9d0860  mov rax, [r15+0xF8]
000073baab9d0867  lea r14, [rax+0x100]
000073baab9d086e  mov [r15], r14
000073baab9d0871  mov rax, [r15+0x98]
000073baab9d0878  mov [r15+0x08], rax
000073baab9d087c  mov qword ptr [r15+0x10], 0x12C
000073baab9d0884  mov qword ptr [r15+0xF0], 0x410284
000073baab9d088f  mov r14d, [r15+0x320]
000073baab9d0896  mov eax, 0x410284
000073baab9d089b  mov rcx, 0x73BAAB9D07C0
000073baab9d08a5  mov [r15+r14*8+0x328], rax
000073baab9d08ad  mov [r15+r14*8+0x368], rcx
000073baab9d08b5  add r14d, 0x01
000073baab9d08b9  and r14d, 0x07
000073baab9d08bd  mov [r15+0x320], r14d
000073baab9d08c4  cmp dword ptr [r15+0x318], 0x00
000073baab9d08cc  jz 0x000073BAAB9CED70
000073baab9d08d2  nop [rax+rax*1], ax
000073baab9d08db  nop [rax+rax*1], eax
000073baab9d08e3  mov eax, 0x410728
000073baab9d08e8  mov [r15+0x100], rax
000073baab9d08ef  jmp 0x000073BAAB7FE110
000073baab9d08f4  int3
000073baab9d08f5  int3
000073baab9d08f6  nop [rax+rax*1], ax
000073baab9d08ff  nop
000073baab9d0900  mov rax, [r15+0xF8]
000073baab9d0907  lea r14, [rax+0x120]
000073baab9d090e  mov r12, [r13+r14*1]
000073baab9d0913  mov [r15+0x98], r12
000073baab9d091a  mov qword ptr [r15+0x40], 0x80
000073baab9d0922  lea r14, [rax+0x100]
000073baab9d0929  mov [r15], r14
000073baab9d092c  lea r14, [rax+0x17C]
000073baab9d0933  mov [r15+0x08], r14
000073baab9d0937  mov qword ptr [r15+0x10], 0x01
000073baab9d093f  lea r14, [rax+0x17C]
000073baab9d0946  mov eax, 0x80
000073baab9d094b  mov [r13+r14*1], al
000073baab9d0950  mov qword ptr [r15+0xF0], 0x4102A8
000073baab9d095b  mov r14d, [r15+0x320]
000073baab9d0962  mov eax, 0x4102A8
000073baab9d0967  mov rcx, 0x73BAAB9D09E0
000073baab9d0971  mov [r15+r14*8+0x328], rax
000073baab9d0979  mov [r15+r14*8+0x368], rcx
000073baab9d0981  add r14d, 0x01
000073baab9d0985  and r14d, 0x07
000073baab9d0989  mov [r15+0x320], r14d
000073baab9d0990  cmp dword ptr [r15+0x318], 0x00
000073baab9d0998  jz 0x000073BAAB9CED70
000073baab9d099e  nop [rax+rax*1], ax
000073baab9d09a7  nop [rax+rax*1], eax
000073baab9d09af  mov eax, 0x410728
000073baab9d09b4  mov [r15+0x100], rax
000073baab9d09bb  jmp 0x000073BAAB7FE110
000073baab9d09c0  int3
000073baab9d09c1  call 0x000073BAAB8E27E0
000073baab9d09c6  jmp 0x000073BAAB9D0913
000073baab9d09cb  call 0x000073BAAB8D5AF0
000073baab9d09d0  jmp 0x000073BAAB9D0950
000073baab9d09d5  int3
000073baab9d09d6  nop [rax+rax*1], ax
000073baab9d09df  nop
000073baab9d09e0  mov rax, [r15+0xF8]
000073baab9d09e7  lea r14, [rax+0x168]
000073baab9d09ee  mov r12, [r13+r14*1]
000073baab9d09f3  mov [r15+0x40], r12
000073baab9d09f7  lea r14, [rax+0x178]
000073baab9d09fe  xor eax, eax
000073baab9d0a00  mov [r13+r14*1], al
000073baab9d0a05  xor eax, eax
000073baab9d0a07  mov r14d, 0x38
000073baab9d0a0d  cmp r12, r14
000073baab9d0a10  cmc
000073baab9d0a11  lahf
000073baab9d0a12  seto al
000073baab9d0a15  mov [r15+0x108], eax
000073baab9d0a1c  mov eax, [r15+0x108]
000073baab9d0a23  sahf
000073baab9d0a24  jz 0x000073BAAB9D0A56
000073baab9d0a26  cmp dword ptr [r15+0x318], 0x00
000073baab9d0a2e  jz 0x000073BAAB9D0AA0
000073baab9d0a34  nop [rax+rax*1], ax
000073baab9d0a3d  nop [rax+rax*1], eax
000073baab9d0a45  mov eax, 0x4102B8
000073baab9d0a4a  mov [r15+0x100], rax
000073baab9d0a51  jmp 0x000073BAAB7FE110
000073baab9d0a56  cmp dword ptr [r15+0x318], 0x00
000073baab9d0a5e  jz 0x000073BAAB9D0BF0
000073baab9d0a64  nop [rax+rax*1], ax
000073baab9d0a6d  nop [rax+rax*1], eax
000073baab9d0a75  mov eax, 0x4102D4
000073baab9d0a7a  mov [r15+0x100], rax
000073baab9d0a81  jmp 0x000073BAAB7FE110
000073baab9d0a86  int3
000073baab9d0a87  call 0x000073BAAB8E27E0
000073baab9d0a8c  jmp 0x000073BAAB9D09F3
000073baab9d0a91  call 0x000073BAAB8D5AF0
000073baab9d0a96  jmp 0x000073BAAB9D0A05
000073baab9d0a9b  int3
000073baab9d0a9c  nop [rax], eax
000073baab9d0aa0  mov rax, [r15+0xF8]
000073baab9d0aa7  lea r14, [rax+0x100]
000073baab9d0aae  mov [r15], r14
000073baab9d0ab1  lea r14, [rax+0x178]
000073baab9d0ab8  mov [r15+0x08], r14
000073baab9d0abc  mov qword ptr [r15+0x10], 0x01
000073baab9d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000073baab9d0acf  mov r14d, [r15+0x320]
000073baab9d0ad6  mov eax, 0x4102C8
000073baab9d0adb  mov rcx, 0x73BAAB9D0B40
000073baab9d0ae5  mov [r15+r14*8+0x328], rax
000073baab9d0aed  mov [r15+r14*8+0x368], rcx
000073baab9d0af5  add r14d, 0x01
000073baab9d0af9  and r14d, 0x07
000073baab9d0afd  mov [r15+0x320], r14d
000073baab9d0b04  cmp dword ptr [r15+0x318], 0x00
000073baab9d0b0c  jz 0x000073BAAB9CED70
000073baab9d0b12  nop [rax+rax*1], ax
000073baab9d0b1b  nop [rax+rax*1], eax
000073baab9d0b23  mov eax, 0x410728
000073baab9d0b28  mov [r15+0x100], rax
000073baab9d0b2f  jmp 0x000073BAAB7FE110
000073baab9d0b34  int3
000073baab9d0b35  int3
000073baab9d0b36  nop [rax+rax*1], ax
000073baab9d0b3f  nop
000073baab9d0b40  mov rax, [r15+0xF8]
000073baab9d0b47  lea r14, [rax+0x168]
000073baab9d0b4e  mov rax, [r13+r14*1]
000073baab9d0b53  mov [r15+0x40], rax
000073baab9d0b57  mov [rsp+0x10], rax
000073baab9d0b5c  xor eax, eax
000073baab9d0b5e  mov r14, [rsp+0x10]
000073baab9d0b63  mov r12d, 0x38
000073baab9d0b69  cmp r14, r12
000073baab9d0b6c  cmc
000073baab9d0b6d  lahf
000073baab9d0b6e  seto al
000073baab9d0b71  mov [r15+0x108], eax
000073baab9d0b78  mov eax, [r15+0x108]
000073baab9d0b7f  sahf
000073baab9d0b80  jnz 0x000073BAAB9D0BB2
000073baab9d0b82  cmp dword ptr [r15+0x318], 0x00
000073baab9d0b8a  jz 0x000073BAAB9D0BF0
000073baab9d0b90  nop [rax+rax*1], ax
000073baab9d0b99  nop [rax+rax*1], eax
000073baab9d0ba1  mov eax, 0x4102D4
000073baab9d0ba6  mov [r15+0x100], rax
000073baab9d0bad  jmp 0x000073BAAB7FE110
000073baab9d0bb2  cmp dword ptr [r15+0x318], 0x00
000073baab9d0bba  jz 0x000073BAAB9D0AA0
000073baab9d0bc0  nop [rax+rax*1], ax
000073baab9d0bc9  nop [rax+rax*1], eax
000073baab9d0bd1  mov eax, 0x4102B8
000073baab9d0bd6  mov [r15+0x100], rax
000073baab9d0bdd  jmp 0x000073BAAB7FE110
000073baab9d0be2  int3
000073baab9d0be3  call 0x000073BAAB8D59C0
000073baab9d0be8  jmp 0x000073BAAB9D0B53
000073baab9d0bed  int3
000073baab9d0bee  nop
000073baab9d0bf0  mov rax, [r15+0x98]
000073baab9d0bf7  rorx r14, rax, 0x3D
000073baab9d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000073baab9d0c01  mov rax, [r15+0xF8]
000073baab9d0c08  lea r12, [rax+0x100]
000073baab9d0c0f  mov [r15], r12
000073baab9d0c12  lea r12, [rax+0x170]
000073baab9d0c19  mov [r15+0x08], r12
000073baab9d0c1d  mov qword ptr [r15+0x10], 0x08
000073baab9d0c25  bswap r14
000073baab9d0c28  mov [r15+0x40], r14
000073baab9d0c2c  lea r12, [rax+0x170]
000073baab9d0c33  mov [r13+r12*1], r14
000073baab9d0c38  mov qword ptr [r15+0xF0], 0x4102F0
000073baab9d0c43  mov r14d, [r15+0x320]
000073baab9d0c4a  mov eax, 0x4102F0
000073baab9d0c4f  mov rcx, 0x73BAAB9D0CC0
000073baab9d0c59  mov [r15+r14*8+0x328], rax
000073baab9d0c61  mov [r15+r14*8+0x368], rcx
000073baab9d0c69  add r14d, 0x01
000073baab9d0c6d  and r14d, 0x07
000073baab9d0c71  mov [r15+0x320], r14d
000073baab9d0c78  cmp dword ptr [r15+0x318], 0x00
000073baab9d0c80  jz 0x000073BAAB9CED70
000073baab9d0c86  nop [rax+rax*1], ax
000073baab9d0c8f  nop [rax+rax*1], eax
000073baab9d0c97  mov eax, 0x410728
000073baab9d0c9c  mov [r15+0x100], rax
000073baab9d0ca3  jmp 0x000073BAAB7FE110
000073baab9d0ca8  int3
000073baab9d0ca9  call 0x000073BAAB8C3FE0
000073baab9d0cae  jmp 0x000073BAAB9D0C38
000073baab9d0cb3  int3
000073baab9d0cb4  nop [rax+rax*1], ax
000073baab9d0cbd  nop [rax], eax
000073baab9d0cc0  mov rax, [r15+0xF8]
000073baab9d0cc7  lea r14, [rax+0x100]
000073baab9d0cce  mov r12d, [r13+r14*1]
000073baab9d0cd3  lea r14, [rax+0x104]
000073baab9d0cda  mov r11d, [r13+r14*1]
000073baab9d0cdf  mov qword ptr [r15+0x48], 0x430C90
000073baab9d0ce7  lea r14, [rax+0x108]
000073baab9d0cee  mov r10d, [r13+r14*1]
000073baab9d0cf3  lea r14, [rax+0x10C]
000073baab9d0cfa  mov r9d, [r13+r14*1]
000073baab9d0cff  bswap r12d
000073baab9d0d02  bswap r11d
000073baab9d0d05  mov qword ptr [r15+0xA0], 0x00
000073baab9d0d10  mov r14d, 0x430C90
000073baab9d0d16  mov [r13+r14*1], r12d
000073baab9d0d1b  mov r14d, 0x430C94
000073baab9d0d21  mov [r13+r14*1], r11d
000073baab9d0d26  bswap r10d
000073baab9d0d29  lea r14, [rax+0x110]
000073baab9d0d30  mov r12d, [r13+r14*1]
000073baab9d0d35  bswap r9d
000073baab9d0d38  lea r14, [rax+0x114]
000073baab9d0d3f  mov r11d, [r13+r14*1]
000073baab9d0d44  mov qword ptr [r15+0x98], 0x430DFC
000073baab9d0d4f  mov r14d, 0x430C98
000073baab9d0d55  mov [r13+r14*1], r10d
000073baab9d0d5a  mov r14d, 0x430C9C
000073baab9d0d60  mov [r13+r14*1], r9d
000073baab9d0d65  bswap r12d
000073baab9d0d68  lea r14, [rax+0x118]
000073baab9d0d6f  mov r10d, [r13+r14*1]
000073baab9d0d74  bswap r11d
000073baab9d0d77  mov [rsp+0x10], r11d
000073baab9d0d7c  mov r11d, r11d
000073baab9d0d7f  mov [r15+0x58], r11
000073baab9d0d83  lea r14, [rax+0x11C]
000073baab9d0d8a  mov eax, [r13+r14*1]
000073baab9d0d8f  mov [rsp+0x20], eax
000073baab9d0d93  mov eax, eax
000073baab9d0d95  mov [r15+0x60], rax
000073baab9d0d99  mov eax, 0x430CA0
000073baab9d0d9e  mov [r13+rax*1], r12d
000073baab9d0da3  mov eax, 0x430CA4
000073baab9d0da8  mov r14d, [rsp+0x10]
000073baab9d0dad  mov [r13+rax*1], r14d
000073baab9d0db2  bswap r10d
000073baab9d0db5  mov [rsp+0x10], r10d
000073baab9d0dba  mov r10d, r10d
000073baab9d0dbd  mov [r15+0x40], r10
000073baab9d0dc1  mov eax, [rsp+0x20]
000073baab9d0dc5  bswap eax
000073baab9d0dc7  mov [rsp+0x20], eax
000073baab9d0dcb  mov eax, eax
000073baab9d0dcd  mov [r15+0x50], rax
000073baab9d0dd1  mov eax, 0x430CA8
000073baab9d0dd6  mov r14d, [rsp+0x10]
000073baab9d0ddb  mov [r13+rax*1], r14d
000073baab9d0de0  mov eax, 0x430CAC
000073baab9d0de5  mov r14d, [rsp+0x20]
000073baab9d0dea  mov [r13+rax*1], r14d
000073baab9d0def  mov eax, [r15+0xA0]
000073baab9d0df6  lea r14d, [eax+0x11]
000073baab9d0dfb  mov r14d, r14d
000073baab9d0dfe  mov [r15], r14
000073baab9d0e01  mov qword ptr [r15+0xF0], 0x41035C
000073baab9d0e0c  mov r14d, [r15+0x320]
000073baab9d0e13  mov eax, 0x41035C
000073baab9d0e18  mov rcx, 0x73BAAB9D0F90
000073baab9d0e22  mov [r15+r14*8+0x328], rax
000073baab9d0e2a  mov [r15+r14*8+0x368], rcx
000073baab9d0e32  add r14d, 0x01
000073baab9d0e36  and r14d, 0x07
000073baab9d0e3a  mov [r15+0x320], r14d
000073baab9d0e41  cmp dword ptr [r15+0x318], 0x00
000073baab9d0e49  jz 0x000073BAAB9D0F20
000073baab9d0e4f  nop [rax+rax*1], ax
000073baab9d0e58  nop [rax+rax*1], eax
000073baab9d0e60  mov eax, 0x4109A4
000073baab9d0e65  mov [r15+0x100], rax
000073baab9d0e6c  jmp 0x000073BAAB7FE110
000073baab9d0e71  int3
000073baab9d0e72  call 0x000073BAAB8E26A0
000073baab9d0e77  jmp 0x000073BAAB9D0CD3
000073baab9d0e7c  call 0x000073BAAB8E1430
000073baab9d0e81  jmp 0x000073BAAB9D0CDF
000073baab9d0e86  call 0x000073BAAB8E01C0
000073baab9d0e8b  jmp 0x000073BAAB9D0CF3
000073baab9d0e90  call 0x000073BAAB8DEF50
000073baab9d0e95  jmp 0x000073BAAB9D0CFF
000073baab9d0e9a  call 0x000073BAAB8E2BA0
000073baab9d0e9f  jmp 0x000073BAAB9D0D1B
000073baab9d0ea4  call 0x000073BAAB8E1920
000073baab9d0ea9  jmp 0x000073BAAB9D0D26
000073baab9d0eae  call 0x000073BAAB8E26A0
000073baab9d0eb3  jmp 0x000073BAAB9D0D35
000073baab9d0eb8  call 0x000073BAAB8E1430
000073baab9d0ebd  jmp 0x000073BAAB9D0D44
000073baab9d0ec2  call 0x000073BAAB8E06B0
000073baab9d0ec7  jmp 0x000073BAAB9D0D5A
000073baab9d0ecc  call 0x000073BAAB8DF440
000073baab9d0ed1  jmp 0x000073BAAB9D0D65
000073baab9d0ed6  call 0x000073BAAB8E01C0
000073baab9d0edb  jmp 0x000073BAAB9D0D74
000073baab9d0ee0  call 0x000073BAAB8D5890
000073baab9d0ee5  jmp 0x000073BAAB9D0D8F
000073baab9d0eea  call 0x000073BAAB80BAE0
000073baab9d0eef  jmp 0x000073BAAB9D0DA3
000073baab9d0ef4  call 0x000073BAAB80DFE0
000073baab9d0ef9  jmp 0x000073BAAB9D0DB2
000073baab9d0efe  call 0x000073BAAB80DFE0
000073baab9d0f03  jmp 0x000073BAAB9D0DE0
000073baab9d0f08  call 0x000073BAAB80DFE0
000073baab9d0f0d  jmp 0x000073BAAB9D0DEF
000073baab9d0f12  int3
000073baab9d0f13  nop [rax+rax*1], ax
000073baab9d0f1c  nop [rax], eax
000073baab9d0f20  mov eax, [r15]
000073baab9d0f23  mov [rsp+0x10], eax
000073baab9d0f27  shr eax, 0x10
000073baab9d0f2a  mov r14d, [rsp+0x10]
000073baab9d0f2f  xor r14d, eax
000073baab9d0f32  imul r14d, r14d, 0x7FEB352D
000073baab9d0f39  mov eax, 0x846CA68B
000073baab9d0f3e  mov eax, eax
000073baab9d0f40  mov [r15+0x48], rax
000073baab9d0f44  mov [rsp+0x10], r14d
000073baab9d0f49  shr r14d, 0x0F
000073baab9d0f4d  mov eax, [rsp+0x10]
000073baab9d0f51  xor eax, r14d
000073baab9d0f54  imul eax, eax, 0x846CA68B
000073baab9d0f5a  mov [rsp+0x10], eax
000073baab9d0f5e  mov eax, eax
000073baab9d0f60  mov [r15+0x40], rax
000073baab9d0f64  mov eax, [rsp+0x10]
000073baab9d0f68  shr eax, 0x10
000073baab9d0f6b  mov r14d, [rsp+0x10]
000073baab9d0f70  xor r14d, eax
000073baab9d0f73  mov r14d, r14d
000073baab9d0f76  mov [r15], r14
000073baab9d0f79  mov rax, [r15+0xF0]
000073baab9d0f80  mov [r15+0x100], rax
000073baab9d0f87  jmp 0x000073BAAB9CE5C0
000073baab9d0f8c  int3
000073baab9d0f8d  int3
000073baab9d0f8e  nop
000073baab9d0f90  mov rax, [r15+0xA0]
000073baab9d0f97  mov [rsp+0x10], rax
000073baab9d0f9c  shl rax, 0x02
000073baab9d0fa0  mov r14, [r15+0x98]
000073baab9d0fa7  lea r12, [r14+rax*1]
000073baab9d0fab  mov eax, [r15]
000073baab9d0fae  mov [r13+r12*1], eax
000073baab9d0fb3  mov rax, [rsp+0x10]
000073baab9d0fb8  lea r14, [rax+0x01]
000073baab9d0fbc  mov [r15+0xA0], r14
000073baab9d0fc3  xor eax, eax
000073baab9d0fc5  mov r12d, 0x400
000073baab9d0fcb  cmp r14, r12
000073baab9d0fce  cmc
000073baab9d0fcf  lahf
000073baab9d0fd0  seto al
000073baab9d0fd3  mov [r15+0x108], eax
000073baab9d0fda  mov eax, [r15+0x108]
000073baab9d0fe1  sahf
000073baab9d0fe2  jnz 0x000073BAAB9D1014
000073baab9d0fe4  cmp dword ptr [r15+0x318], 0x00
000073baab9d0fec  jz 0x000073BAAB9D10E0
000073baab9d0ff2  nop [rax+rax*1], ax
000073baab9d0ffb  nop [rax+rax*1], eax
000073baab9d1003  mov eax, 0x41036C
000073baab9d1008  mov [r15+0x100], rax
000073baab9d100f  jmp 0x000073BAAB7FE110
000073baab9d1014  cmp dword ptr [r15+0x318], 0x00
000073baab9d101c  jz 0x000073BAAB9D1050
000073baab9d1022  nop [rax+rax*1], ax
000073baab9d102b  nop [rax+rax*1], eax
000073baab9d1033  mov eax, 0x410354
000073baab9d1038  mov [r15+0x100], rax
000073baab9d103f  jmp 0x000073BAAB7FE110
000073baab9d1044  int3
000073baab9d1045  call 0x000073BAAB8B4B70
000073baab9d104a  jmp 0x000073BAAB9D0FB3
000073baab9d104f  int3
000073baab9d1050  mov eax, [r15+0xA0]
000073baab9d1057  lea r14d, [eax+0x11]
000073baab9d105c  mov r14d, r14d
000073baab9d105f  mov [r15], r14
000073baab9d1062  mov qword ptr [r15+0xF0], 0x41035C
000073baab9d106d  mov r14d, [r15+0x320]
000073baab9d1074  mov eax, 0x41035C
000073baab9d1079  mov rcx, 0x73BAAB9D0F90
000073baab9d1083  mov [r15+r14*8+0x328], rax
000073baab9d108b  mov [r15+r14*8+0x368], rcx
000073baab9d1093  add r14d, 0x01
000073baab9d1097  and r14d, 0x07
000073baab9d109b  mov [r15+0x320], r14d
000073baab9d10a2  cmp dword ptr [r15+0x318], 0x00
000073baab9d10aa  jz 0x000073BAAB9D0F20
000073baab9d10b0  nop [rax+rax*1], ax
000073baab9d10b9  nop [rax+rax*1], eax
000073baab9d10c1  mov eax, 0x4109A4
000073baab9d10c6  mov [r15+0x100], rax
000073baab9d10cd  jmp 0x000073BAAB7FE110
000073baab9d10d2  int3
000073baab9d10d3  int3
000073baab9d10d4  nop [rax+rax*1], ax
000073baab9d10dd  nop [rax], eax
000073baab9d10e0  mov qword ptr [r15+0x40], 0x01
000073baab9d10e8  cmp dword ptr [r15+0x318], 0x00
000073baab9d10f0  jz 0x000073BAAB9D1120
000073baab9d10f6  nop [rax+rax*1], ax
000073baab9d10ff  nop [rax+rax*1], eax
000073baab9d1107  mov eax, 0x410388
000073baab9d110c  mov [r15+0x100], rax
000073baab9d1113  jmp 0x000073BAAB7FE110
000073baab9d1118  int3
000073baab9d1119  int3
000073baab9d111a  nop [rax+rax*1], ax
000073baab9d1120  mov rax, [r15+0x40]
000073baab9d1124  mov [rsp+0x10], rax
000073baab9d1129  shl rax, 0x02
000073baab9d112d  mov r14, [r15+0x98]
000073baab9d1134  lea r12, [r14+rax*1]
000073baab9d1138  mov eax, [r13+r12*1]
000073baab9d113d  mov [rsp+0x20], eax
000073baab9d1141  mov eax, eax
000073baab9d1143  mov [r15+0x48], rax
000073baab9d1147  mov rax, [rsp+0x10]
000073baab9d114c  mov [r15+0x50], rax
000073baab9d1150  mov eax, [r15+0x50]
000073baab9d1154  lea r12d, [eax-0x01]
000073baab9d1159  mov r12d, r12d
000073baab9d115c  mov [r15+0x58], r12
000073baab9d1160  mov rax, [r15+0x58]
000073baab9d1164  mov r12d, eax
000073baab9d1167  mov r12d, r12d
000073baab9d116a  shl r12, 0x02
000073baab9d116e  lea rax, [r14+r12*1]
000073baab9d1172  mov r14d, [r13+rax*1]
000073baab9d1177  mov [rsp+0x10], r14d
000073baab9d117c  mov r14d, r14d
000073baab9d117f  mov [r15+0x60], r14
000073baab9d1183  xor eax, eax
000073baab9d1185  mov r14d, [rsp+0x10]
000073baab9d118a  mov r12d, [rsp+0x20]
000073baab9d118f  cmp r14d, r12d
000073baab9d1192  cmc
000073baab9d1193  lahf
000073baab9d1194  seto al
000073baab9d1197  mov [r15+0x108], eax
000073baab9d119e  mov eax, [r15+0x108]
000073baab9d11a5  sahf
000073baab9d11a6  cmc
000073baab9d11a7  jbe 0x000073BAAB9D11D9
000073baab9d11a9  cmp dword ptr [r15+0x318], 0x00
000073baab9d11b1  jz 0x000073BAAB9D1220
000073baab9d11b7  nop [rax+rax*1], ax
000073baab9d11c0  nop [rax+rax*1], eax
000073baab9d11c8  mov eax, 0x4103A0
000073baab9d11cd  mov [r15+0x100], rax
000073baab9d11d4  jmp 0x000073BAAB7FE110
000073baab9d11d9  cmp dword ptr [r15+0x318], 0x00
000073baab9d11e1  jz 0x000073BAAB9D14C0
000073baab9d11e7  nop [rax+rax*1], ax
000073baab9d11f0  nop [rax+rax*1], eax
000073baab9d11f8  mov eax, 0x410378
000073baab9d11fd  mov [r15+0x100], rax
000073baab9d1204  jmp 0x000073BAAB7FE110
000073baab9d1209  int3
000073baab9d120a  call 0x000073BAAB8B4690
000073baab9d120f  jmp 0x000073BAAB9D113D
000073baab9d1214  call 0x000073BAAB80DAE0
000073baab9d1219  jmp 0x000073BAAB9D1177
000073baab9d121e  int3
000073baab9d121f  nop
000073baab9d1220  mov rax, [r15+0x50]
000073baab9d1224  mov [rsp+0x10], rax
000073baab9d1229  shl rax, 0x02
000073baab9d122d  mov r14, [r15+0x98]
000073baab9d1234  lea r12, [r14+rax*1]
000073baab9d1238  mov eax, [r15+0x60]
000073baab9d123c  mov [r13+r12*1], eax
000073baab9d1241  mov rax, [rsp+0x10]
000073baab9d1246  lea r14, [rax-0x01]
000073baab9d124a  mov [r15+0x50], r14
000073baab9d124e  mov rax, [r15+0x58]
000073baab9d1252  test rax, rax
000073baab9d1255  setz al
000073baab9d1258  movzx rax, al
000073baab9d125c  mov [rsp+0x414], al
000073baab9d1263  cmp byte ptr [rsp+0x414], 0x00
000073baab9d126b  jz 0x000073BAAB9D129D
000073baab9d126d  cmp dword ptr [r15+0x318], 0x00
000073baab9d1275  jz 0x000073BAAB9D12E0
000073baab9d127b  nop [rax+rax*1], ax
000073baab9d1284  nop [rax+rax*1], eax
000073baab9d128c  mov eax, 0x4103AC
000073baab9d1291  mov [r15+0x100], rax
000073baab9d1298  jmp 0x000073BAAB7FE110
000073baab9d129d  cmp dword ptr [r15+0x318], 0x00
000073baab9d12a5  jz 0x000073BAAB9D13E0
000073baab9d12ab  nop [rax+rax*1], ax
000073baab9d12b4  nop [rax+rax*1], eax
000073baab9d12bc  mov eax, 0x410390
000073baab9d12c1  mov [r15+0x100], rax
000073baab9d12c8  jmp 0x000073BAAB7FE110
000073baab9d12cd  int3
000073baab9d12ce  call 0x000073BAAB8B4B70
000073baab9d12d3  jmp 0x000073BAAB9D1241
000073baab9d12d8  int3
000073baab9d12d9  nop [rax], eax
000073baab9d12e0  cmp dword ptr [r15+0x318], 0x00
000073baab9d12e8  jz 0x000073BAAB9D1320
000073baab9d12ee  nop [rax+rax*1], ax
000073baab9d12f7  nop [rax+rax*1], eax
000073baab9d12ff  mov eax, 0x410374
000073baab9d1304  mov [r15+0x100], rax
000073baab9d130b  jmp 0x000073BAAB7FE110
000073baab9d1310  int3
000073baab9d1311  int3
000073baab9d1312  nop [rax+rax*1], ax
000073baab9d131b  nop [rax+rax*1], eax
000073baab9d1320  mov qword ptr [r15+0x50], 0x00
000073baab9d1328  mov rax, [r15+0x40]
000073baab9d132c  lea r14, [rax+0x01]
000073baab9d1330  mov [r15+0x40], r14
000073baab9d1334  mov rax, [r15+0x98]
000073baab9d133b  mov r12d, [r15+0x48]
000073baab9d133f  mov [r13+rax*1], r12d
000073baab9d1344  xor eax, eax
000073baab9d1346  mov r12d, 0x400
000073baab9d134c  cmp r14, r12
000073baab9d134f  cmc
000073baab9d1350  lahf
000073baab9d1351  seto al
000073baab9d1354  mov [r15+0x108], eax
000073baab9d135b  mov eax, [r15+0x108]
000073baab9d1362  sahf
000073baab9d1363  jz 0x000073BAAB9D1395
000073baab9d1365  cmp dword ptr [r15+0x318], 0x00
000073baab9d136d  jz 0x000073BAAB9D1120
000073baab9d1373  nop [rax+rax*1], ax
000073baab9d137c  nop [rax+rax*1], eax
000073baab9d1384  mov eax, 0x410388
000073baab9d1389  mov [r15+0x100], rax
000073baab9d1390  jmp 0x000073BAAB7FE110
000073baab9d1395  cmp dword ptr [r15+0x318], 0x00
000073baab9d139d  jz 0x000073BAAB9D1580
000073baab9d13a3  nop [rax+rax*1], ax
000073baab9d13ac  nop [rax+rax*1], eax
000073baab9d13b4  mov eax, 0x4103B0
000073baab9d13b9  mov [r15+0x100], rax
000073baab9d13c0  jmp 0x000073BAAB7FE110
000073baab9d13c5  int3
000073baab9d13c6  call 0x000073BAAB80BAE0
000073baab9d13cb  jmp 0x000073BAAB9D1344
000073baab9d13d0  int3
000073baab9d13d1  nop [rax+rax*1], ax
000073baab9d13da  nop [rax+rax*1], ax
000073baab9d13e0  mov eax, [r15+0x50]
000073baab9d13e4  lea r14d, [eax-0x01]
000073baab9d13e9  mov r14d, r14d
000073baab9d13ec  mov [r15+0x58], r14
000073baab9d13f0  mov rax, [r15+0x58]
000073baab9d13f4  mov r14d, eax
000073baab9d13f7  mov r14d, r14d
000073baab9d13fa  shl r14, 0x02
000073baab9d13fe  mov rax, [r15+0x98]
000073baab9d1405  lea r12, [rax+r14*1]
000073baab9d1409  mov eax, [r13+r12*1]
000073baab9d140e  mov [rsp+0x10], eax
000073baab9d1412  mov eax, eax
000073baab9d1414  mov [r15+0x60], rax
000073baab9d1418  mov eax, [r15+0x48]
000073baab9d141c  mov [rsp+0x20], eax
000073baab9d1420  xor eax, eax
000073baab9d1422  mov r14d, [rsp+0x10]
000073baab9d1427  mov r12d, [rsp+0x20]
000073baab9d142c  cmp r14d, r12d
000073baab9d142f  cmc
000073baab9d1430  lahf
000073baab9d1431  seto al
000073baab9d1434  mov [r15+0x108], eax
000073baab9d143b  mov eax, [r15+0x108]
000073baab9d1442  sahf
000073baab9d1443  cmc
000073baab9d1444  jbe 0x000073BAAB9D1476
000073baab9d1446  cmp dword ptr [r15+0x318], 0x00
000073baab9d144e  jz 0x000073BAAB9D1220
000073baab9d1454  nop [rax+rax*1], ax
000073baab9d145d  nop [rax+rax*1], eax
000073baab9d1465  mov eax, 0x4103A0
000073baab9d146a  mov [r15+0x100], rax
000073baab9d1471  jmp 0x000073BAAB7FE110
000073baab9d1476  cmp dword ptr [r15+0x318], 0x00
000073baab9d147e  jz 0x000073BAAB9D14C0
000073baab9d1484  nop [rax+rax*1], ax
000073baab9d148d  nop [rax+rax*1], eax
000073baab9d1495  mov eax, 0x410378
000073baab9d149a  mov [r15+0x100], rax
000073baab9d14a1  jmp 0x000073BAAB7FE110
000073baab9d14a6  int3
000073baab9d14a7  call 0x000073BAAB8B4690
000073baab9d14ac  jmp 0x000073BAAB9D140E
000073baab9d14b1  int3
000073baab9d14b2  nop [rax+rax*1], ax
000073baab9d14bb  nop [rax+rax*1], eax
000073baab9d14c0  mov rax, [r15+0x40]
000073baab9d14c4  lea r14, [rax+0x01]
000073baab9d14c8  mov [r15+0x40], r14
000073baab9d14cc  mov rax, [r15+0x50]
000073baab9d14d0  mov r12d, eax
000073baab9d14d3  mov r12d, r12d
000073baab9d14d6  shl r12, 0x02
000073baab9d14da  mov rax, [r15+0x98]
000073baab9d14e1  lea r11, [rax+r12*1]
000073baab9d14e5  mov eax, [r15+0x48]
000073baab9d14e9  mov [r13+r11*1], eax
000073baab9d14ee  xor eax, eax
000073baab9d14f0  mov r12d, 0x400
000073baab9d14f6  cmp r14, r12
000073baab9d14f9  cmc
000073baab9d14fa  lahf
000073baab9d14fb  seto al
000073baab9d14fe  mov [r15+0x108], eax
000073baab9d1505  mov eax, [r15+0x108]
000073baab9d150c  sahf
000073baab9d150d  jz 0x000073BAAB9D153F
000073baab9d150f  cmp dword ptr [r15+0x318], 0x00
000073baab9d1517  jz 0x000073BAAB9D1120
000073baab9d151d  nop [rax+rax*1], ax
000073baab9d1526  nop [rax+rax*1], eax
000073baab9d152e  mov eax, 0x410388
000073baab9d1533  mov [r15+0x100], rax
000073baab9d153a  jmp 0x000073BAAB7FE110
000073baab9d153f  cmp dword ptr [r15+0x318], 0x00
000073baab9d1547  jz 0x000073BAAB9D1580
000073baab9d154d  nop [rax+rax*1], ax
000073baab9d1556  nop [rax+rax*1], eax
000073baab9d155e  mov eax, 0x4103B0
000073baab9d1563  mov [r15+0x100], rax
000073baab9d156a  jmp 0x000073BAAB7FE110
000073baab9d156f  int3
000073baab9d1570  call 0x000073BAAB8A4270
000073baab9d1575  jmp 0x000073BAAB9D14EE
000073baab9d157a  int3
000073baab9d157b  nop [rax+rax*1], eax
000073baab9d1580  mov qword ptr [r15+0x40], 0x430000
000073baab9d1588  mov eax, 0x430CB0
000073baab9d158d  mov r14, [r13+rax*1]
000073baab9d1592  mov rax, [r15+0x98]
000073baab9d1599  mov r12d, [r13+rax*1]
000073baab9d159e  lea r11, [rax+0x04]
000073baab9d15a2  mov eax, [r13+r11*1]
000073baab9d15a7  mov r12d, r12d
000073baab9d15aa  mov [r15+0x68], r12
000073baab9d15ae  mov eax, eax
000073baab9d15b0  mov [r15+0x60], rax
000073baab9d15b4  mov rax, [r15+0x68]
000073baab9d15b8  mov [r15+0x68], rax
000073baab9d15bc  mov qword ptr [r15+0x58], 0x02
000073baab9d15c4  mov [rsp+0x10], rax
000073baab9d15c9  xor eax, eax
000073baab9d15cb  mov r12d, 0x02
000073baab9d15d1  mov r11d, 0x400
000073baab9d15d7  cmp r12, r11
000073baab9d15da  cmc
000073baab9d15db  lahf
000073baab9d15dc  seto al
000073baab9d15df  mov [r15+0x108], eax
000073baab9d15e6  mov rax, [r15+0x60]
000073baab9d15ea  mov r12d, 0x02
000073baab9d15f0  imul rax, r12
000073baab9d15f4  mov [r15+0x50], rax
000073baab9d15f8  mov rax, [rsp+0x10]
000073baab9d15fd  lea r12, [rax+r14*1]
000073baab9d1601  mov [r15+0x48], r12
000073baab9d1605  mov eax, [r15+0x108]
000073baab9d160c  sahf
000073baab9d160d  jnz 0x000073BAAB9D163F
000073baab9d160f  cmp dword ptr [r15+0x318], 0x00
000073baab9d1617  jz 0x000073BAAB9D17B0
000073baab9d161d  nop [rax+rax*1], ax
000073baab9d1626  nop [rax+rax*1], eax
000073baab9d162e  mov eax, 0x4103E0
000073baab9d1633  mov [r15+0x100], rax
000073baab9d163a  jmp 0x000073BAAB7FE110
000073baab9d163f  cmp dword ptr [r15+0x318], 0x00
000073baab9d1647  jz 0x000073BAAB9D1690
000073baab9d164d  nop [rax+rax*1], ax
000073baab9d1656  nop [rax+rax*1], eax
000073baab9d165e  mov eax, 0x4103C0
000073baab9d1663  mov [r15+0x100], rax
000073baab9d166a  jmp 0x000073BAAB7FE110
000073baab9d166f  int3
000073baab9d1670  call 0x000073BAAB80DC20
000073baab9d1675  jmp 0x000073BAAB9D1592
000073baab9d167a  call 0x000073BAAB80B5E0
000073baab9d167f  jmp 0x000073BAAB9D159E
000073baab9d1684  call 0x000073BAAB8A3D90
000073baab9d1689  jmp 0x000073BAAB9D15A7
000073baab9d168e  int3
000073baab9d168f  nop
000073baab9d1690  mov rax, [r15+0x98]
000073baab9d1697  mov r14, [r15+0x58]
000073baab9d169b  mov [rsp+0x10], r14
000073baab9d16a0  shl r14, 0x02
000073baab9d16a4  lea r12, [rax+r14*1]
000073baab9d16a8  mov eax, [r13+r12*1]
000073baab9d16ad  lea r14, [r12+0x04]
000073baab9d16b2  mov r12d, [r13+r14*1]
000073baab9d16b7  mov eax, eax
000073baab9d16b9  mov [r15+0x68], rax
000073baab9d16bd  mov r12d, r12d
000073baab9d16c0  mov [r15+0x60], r12
000073baab9d16c4  mov rax, [r15+0x68]
000073baab9d16c8  mov [rsp+0x20], rax
000073baab9d16cd  mov r14, [rsp+0x10]
000073baab9d16d2  imul rax, r14
000073baab9d16d6  mov r12, [rsp+0x20]
000073baab9d16db  lea r11, [r12+rax*1]
000073baab9d16df  mov [r15+0x68], r11
000073baab9d16e3  lea rax, [r14+0x02]
000073baab9d16e7  mov [r15+0x58], rax
000073baab9d16eb  mov [rsp+0x10], rax
000073baab9d16f0  xor eax, eax
000073baab9d16f2  mov r14, [rsp+0x10]
000073baab9d16f7  mov r12d, 0x400
000073baab9d16fd  cmp r14, r12
000073baab9d1700  cmc
000073baab9d1701  lahf
000073baab9d1702  seto al
000073baab9d1705  mov [r15+0x108], eax
000073baab9d170c  mov rax, [r15+0x50]
000073baab9d1710  mov r12, [r15+0x60]
000073baab9d1714  imul r14, r12
000073baab9d1718  lea r12, [rax+r14*1]
000073baab9d171c  mov [r15+0x50], r12
000073baab9d1720  mov rax, [r15+0x48]
000073baab9d1724  lea r14, [r11+rax*1]
000073baab9d1728  mov [r15+0x48], r14
000073baab9d172c  mov eax, [r15+0x108]
000073baab9d1733  sahf
000073baab9d1734  jnz 0x000073BAAB9D1766
000073baab9d1736  cmp dword ptr [r15+0x318], 0x00
000073baab9d173e  jz 0x000073BAAB9D17B0
000073baab9d1744  nop [rax+rax*1], ax
000073baab9d174d  nop [rax+rax*1], eax
000073baab9d1755  mov eax, 0x4103E0
000073baab9d175a  mov [r15+0x100], rax
000073baab9d1761  jmp 0x000073BAAB7FE110
000073baab9d1766  cmp dword ptr [r15+0x318], 0x00
000073baab9d176e  jz 0x000073BAAB9D1690
000073baab9d1774  nop [rax+rax*1], ax
000073baab9d177d  nop [rax+rax*1], eax
000073baab9d1785  mov eax, 0x4103C0
000073baab9d178a  mov [r15+0x100], rax
000073baab9d1791  jmp 0x000073BAAB7FE110
000073baab9d1796  int3
000073baab9d1797  call 0x000073BAAB8B4690
000073baab9d179c  jmp 0x000073BAAB9D16AD
000073baab9d17a1  call 0x000073BAAB8E26A0
000073baab9d17a6  jmp 0x000073BAAB9D16B7
000073baab9d17ab  int3
000073baab9d17ac  nop [rax], eax
000073baab9d17b0  mov qword ptr [r15+0x98], 0x00
000073baab9d17bb  mov rax, [r15+0x50]
000073baab9d17bf  mov r14, [r15+0x48]
000073baab9d17c3  lea r12, [rax+r14*1]
000073baab9d17c7  mov [r15+0x48], r12
000073baab9d17cb  mov rax, [r15+0x40]
000073baab9d17cf  lea r14, [rax+0xCB0]
000073baab9d17d6  mov [r13+r14*1], r12
000073baab9d17db  mov qword ptr [r15], 0x01
000073baab9d17e2  mov qword ptr [r15+0xF0], 0x4103F8
000073baab9d17ed  mov r14d, [r15+0x320]
000073baab9d17f4  mov eax, 0x4103F8
000073baab9d17f9  mov rcx, 0x73BAAB9D1860
000073baab9d1803  mov [r15+r14*8+0x328], rax
000073baab9d180b  mov [r15+r14*8+0x368], rcx
000073baab9d1813  add r14d, 0x01
000073baab9d1817  and r14d, 0x07
000073baab9d181b  mov [r15+0x320], r14d
000073baab9d1822  cmp dword ptr [r15+0x318], 0x00
000073baab9d182a  jz 0x000073BAAB9D0F20
000073baab9d1830  nop [rax+rax*1], ax
000073baab9d1839  nop [rax+rax*1], eax
000073baab9d1841  mov eax, 0x4109A4
000073baab9d1846  mov [r15+0x100], rax
000073baab9d184d  jmp 0x000073BAAB7FE110
000073baab9d1852  int3
000073baab9d1853  call 0x000073BAAB8E2CE0
000073baab9d1858  jmp 0x000073BAAB9D17DB
000073baab9d185d  int3
000073baab9d185e  nop
000073baab9d1860  mov eax, [r15+0x98]
000073baab9d1867  lea r14d, [eax+0x01]
000073baab9d186c  mov [rsp+0x10], r14d
000073baab9d1871  mov r14d, r14d
000073baab9d1874  mov [r15+0x98], r14
000073baab9d187b  xor eax, eax
000073baab9d187d  mov r14d, [rsp+0x10]
000073baab9d1882  cmp r14d, 0x10000
000073baab9d1889  cmc
000073baab9d188a  lahf
000073baab9d188b  seto al
000073baab9d188e  mov [r15+0x108], eax
000073baab9d1895  mov eax, [r15+0x108]
000073baab9d189c  sahf
000073baab9d189d  jnz 0x000073BAAB9D18CF
000073baab9d189f  cmp dword ptr [r15+0x318], 0x00
000073baab9d18a7  jz 0x000073BAAB9D19A0
000073baab9d18ad  nop [rax+rax*1], ax
000073baab9d18b6  nop [rax+rax*1], eax
000073baab9d18be  mov eax, 0x410404
000073baab9d18c3  mov [r15+0x100], rax
000073baab9d18ca  jmp 0x000073BAAB7FE110
000073baab9d18cf  cmp dword ptr [r15+0x318], 0x00
000073baab9d18d7  jz 0x000073BAAB9D1910
000073baab9d18dd  nop [rax+rax*1], ax
000073baab9d18e6  nop [rax+rax*1], eax
000073baab9d18ee  mov eax, 0x4103F0
000073baab9d18f3  mov [r15+0x100], rax
000073baab9d18fa  jmp 0x000073BAAB7FE110
000073baab9d18ff  int3
000073baab9d1900  int3
000073baab9d1901  nop [rax+rax*1], ax
000073baab9d190a  nop [rax+rax*1], ax
000073baab9d1910  mov eax, [r15]
000073baab9d1913  mov r14d, [r15+0x98]
000073baab9d191a  lea r12d, [eax+r14d*1]
000073baab9d191f  mov r12d, r12d
000073baab9d1922  mov [r15], r12
000073baab9d1925  mov qword ptr [r15+0xF0], 0x4103F8
000073baab9d1930  mov r14d, [r15+0x320]
000073baab9d1937  mov eax, 0x4103F8
000073baab9d193c  mov rcx, 0x73BAAB9D1860
000073baab9d1946  mov [r15+r14*8+0x328], rax
000073baab9d194e  mov [r15+r14*8+0x368], rcx
000073baab9d1956  add r14d, 0x01
000073baab9d195a  and r14d, 0x07
000073baab9d195e  mov [r15+0x320], r14d
000073baab9d1965  cmp dword ptr [r15+0x318], 0x00
000073baab9d196d  jz 0x000073BAAB9D0F20
000073baab9d1973  nop [rax+rax*1], ax
000073baab9d197c  nop [rax+rax*1], eax
000073baab9d1984  mov eax, 0x4109A4
000073baab9d1989  mov [r15+0x100], rax
000073baab9d1990  jmp 0x000073BAAB7FE110
000073baab9d1995  int3
000073baab9d1996  int3
000073baab9d1997  nop [rax+rax*1], ax
000073baab9d19a0  vmovaps xmm1, [0x000073BAAB5FE010]
000073baab9d19a8  movq xmm1, xmm1
000073baab9d19ac  movaps [r15+0x110], xmm1
000073baab9d19b4  mov eax, 0x420B10
000073baab9d19b9  mov r14, [r13+rax*1]
000073baab9d19be  movq xmm1, r14
000073baab9d19c3  movaps [r15+0x120], xmm1
000073baab9d19cb  vmovaps xmm1, [0x000073BAAB5FE020]
000073baab9d19d3  movq xmm1, xmm1
000073baab9d19d7  movaps [r15+0x140], xmm1
000073baab9d19df  vmovaps xmm1, [0x000073BAAB5FE030]
000073baab9d19e7  vpbroadcastq xmm1, xmm1
000073baab9d19ec  movaps [r15+0x150], xmm1
000073baab9d19f4  mov qword ptr [r15+0x40], 0x02
000073baab9d19fc  vmovaps xmm15, [0x000073BAAB5FE040]
000073baab9d1a04  movq xmm15, xmm15
000073baab9d1a09  movaps [r15+0x160], xmm15
000073baab9d1a11  vmovaps xmm15, [0x000073BAAB5FE050]
000073baab9d1a19  vpbroadcastq xmm15, xmm15
000073baab9d1a1e  movaps [r15+0x130], xmm15
000073baab9d1a26  mov rax, [r15+0x40]
000073baab9d1a2a  vmovq xmm14, rax
000073baab9d1a2f  vpbroadcastq xmm14, xmm14
000073baab9d1a34  movaps [r15+0x170], xmm14
000073baab9d1a3c  mov eax, 0x420A40
000073baab9d1a41  movups xmm13, [r13+rax*1]
000073baab9d1a47  mov qword ptr [r15+0x40], 0x431E00
000073baab9d1a4f  mov eax, [r15]
000073baab9d1a52  mov r14d, 0x430CB8
000073baab9d1a58  mov [r13+r14*1], eax
000073baab9d1a5d  mov qword ptr [r15+0x50], 0x432000
000073baab9d1a65  vpmovqd xmm12, xmm13
000073baab9d1a6b  pxor xmm11, xmm11
000073baab9d1a70  punpcklqdq xmm12, xmm11
000073baab9d1a75  movaps [r15+0x210], xmm12
000073baab9d1a7d  movq xmm12, qword ptr [r15+0x140]
000073baab9d1a86  movq xmm11, qword ptr [r15+0x120]
000073baab9d1a8f  psubd xmm12, xmm11
000073baab9d1a94  movq xmm12, xmm12
000073baab9d1a99  paddq xmm13, xmm14
000073baab9d1a9e  movaps [r15+0x180], xmm13
000073baab9d1aa6  movq xmm14, qword ptr [r15+0x160]
000073baab9d1aaf  paddd xmm11, xmm14
000073baab9d1ab4  movq xmm11, xmm11
000073baab9d1ab9  movq xmm11, xmm11
000073baab9d1abe  movaps [r15+0x120], xmm11
000073baab9d1ac6  pmovzxdq xmm12, xmm12
000073baab9d1acc  psllq xmm12, 0x00
000073baab9d1ad2  movq xmm14, qword ptr [r15+0x210]
000073baab9d1adb  movq xmm13, qword ptr [r15+0x110]
000073baab9d1ae4  paddd xmm14, xmm13
000073baab9d1ae9  movq xmm14, xmm14
000073baab9d1aee  vcvtuqq2pd xmm12, xmm12
000073baab9d1af4  pmovzxdq xmm14, xmm14
000073baab9d1afa  psllq xmm14, 0x00
000073baab9d1b00  vcvtuqq2pd xmm14, xmm14
000073baab9d1b06  movaps xmm13, xmm12
000073baab9d1b0a  mulpd xmm13, xmm1
000073baab9d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000073baab9d1b15  ptest xmm11, xmm11
000073baab9d1b1b  jnz 0x000073BAAB9D1C0F
000073baab9d1b21  movaps [r15+0x220], xmm13
000073baab9d1b29  mov eax, 0x432000
000073baab9d1b2e  movups [r13+rax*1], xmm13
000073baab9d1b34  movaps xmm1, xmm14
000073baab9d1b38  mulpd xmm1, xmm15
000073baab9d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000073baab9d1b42  ptest xmm13, xmm13
000073baab9d1b48  jnz 0x000073BAAB9D1D5C
000073baab9d1b4e  movaps [r15+0x210], xmm1
000073baab9d1b56  mov eax, 0x431E00
000073baab9d1b5b  movups [r13+rax*1], xmm1
000073baab9d1b61  mov qword ptr [r15+0x48], 0x10
000073baab9d1b69  xor eax, eax
000073baab9d1b6b  mov r14d, 0x10
000073baab9d1b71  mov r12d, 0x200
000073baab9d1b77  cmp r14, r12
000073baab9d1b7a  cmc
000073baab9d1b7b  lahf
000073baab9d1b7c  seto al
000073baab9d1b7f  mov [r15+0x108], eax
000073baab9d1b86  mov eax, [r15+0x108]
000073baab9d1b8d  sahf
000073baab9d1b8e  jnz 0x000073BAAB9D1BC0
000073baab9d1b90  cmp dword ptr [r15+0x318], 0x00
000073baab9d1b98  jz 0x000073BAAB9D2300
000073baab9d1b9e  nop [rax+rax*1], ax
000073baab9d1ba7  nop [rax+rax*1], eax
000073baab9d1baf  mov eax, 0x410490
000073baab9d1bb4  mov [r15+0x100], rax
000073baab9d1bbb  jmp 0x000073BAAB7FE110
000073baab9d1bc0  cmp dword ptr [r15+0x318], 0x00
000073baab9d1bc8  jz 0x000073BAAB9D1EB0
000073baab9d1bce  nop [rax+rax*1], ax
000073baab9d1bd7  nop [rax+rax*1], eax
000073baab9d1bdf  mov eax, 0x410450
000073baab9d1be4  mov [r15+0x100], rax
000073baab9d1beb  jmp 0x000073BAAB7FE110
000073baab9d1bf0  int3
000073baab9d1bf1  call 0x000073BAAB80DC20
000073baab9d1bf6  jmp 0x000073BAAB9D19BE
000073baab9d1bfb  call 0x000073BAAB80C260
000073baab9d1c00  jmp 0x000073BAAB9D1A47
000073baab9d1c05  call 0x000073BAAB8D5D70
000073baab9d1c0a  jmp 0x000073BAAB9D1A5D
000073baab9d1c0f  sub rsp, 0x08
000073baab9d1c13  push rax
000073baab9d1c14  push rcx
000073baab9d1c15  push rdx
000073baab9d1c16  push rdi
000073baab9d1c17  push rsi
000073baab9d1c18  push r8
000073baab9d1c1a  push r9
000073baab9d1c1c  push r10
000073baab9d1c1e  push r11
000073baab9d1c20  sub rsp, 0xF0
000073baab9d1c27  vmovaps [rsp], xmm0
000073baab9d1c2c  vmovaps [rsp+0x10], xmm1
000073baab9d1c32  vmovaps [rsp+0x20], xmm2
000073baab9d1c38  vmovaps [rsp+0x30], xmm3
000073baab9d1c3e  vmovaps [rsp+0x40], xmm4
000073baab9d1c44  vmovaps [rsp+0x50], xmm5
000073baab9d1c4a  vmovaps [rsp+0x60], xmm6
000073baab9d1c50  vmovaps [rsp+0x70], xmm7
000073baab9d1c56  vmovaps [rsp+0x80], xmm8
000073baab9d1c5f  vmovaps [rsp+0x90], xmm9
000073baab9d1c68  vmovaps [rsp+0xA0], xmm10
000073baab9d1c71  vmovaps [rsp+0xB0], xmm11
000073baab9d1c7a  vmovaps [rsp+0xC0], xmm12
000073baab9d1c83  vmovaps [rsp+0xD0], xmm14
000073baab9d1c8c  vmovaps [rsp+0xE0], xmm15
000073baab9d1c95  sub rsp, 0x30
000073baab9d1c99  movaps [rsp], xmm13
000073baab9d1c9e  movaps [rsp+0x10], xmm12
000073baab9d1ca4  movaps [rsp+0x20], xmm1
000073baab9d1ca9  lea rdi, [rsp]
000073baab9d1cad  mov esi, 0x00
000073baab9d1cb2  mov rax, 0x5F3F1062D530
000073baab9d1cbc  call rax
000073baab9d1cbe  movaps xmm13, [rsp]
000073baab9d1cc3  add rsp, 0x30
000073baab9d1cc7  vmovaps xmm0, [rsp]
000073baab9d1ccc  vmovaps xmm1, [rsp+0x10]
000073baab9d1cd2  vmovaps xmm2, [rsp+0x20]
000073baab9d1cd8  vmovaps xmm3, [rsp+0x30]
000073baab9d1cde  vmovaps xmm4, [rsp+0x40]
000073baab9d1ce4  vmovaps xmm5, [rsp+0x50]
000073baab9d1cea  vmovaps xmm6, [rsp+0x60]
000073baab9d1cf0  vmovaps xmm7, [rsp+0x70]
000073baab9d1cf6  vmovaps xmm8, [rsp+0x80]
000073baab9d1cff  vmovaps xmm9, [rsp+0x90]
000073baab9d1d08  vmovaps xmm10, [rsp+0xA0]
000073baab9d1d11  vmovaps xmm11, [rsp+0xB0]
000073baab9d1d1a  vmovaps xmm12, [rsp+0xC0]
000073baab9d1d23  vmovaps xmm14, [rsp+0xD0]
000073baab9d1d2c  vmovaps xmm15, [rsp+0xE0]
000073baab9d1d35  add rsp, 0xF0
000073baab9d1d3c  pop r11
000073baab9d1d3e  pop r10
000073baab9d1d40  pop r9
000073baab9d1d42  pop r8
000073baab9d1d44  pop rsi
000073baab9d1d45  pop rdi
000073baab9d1d46  pop rdx
000073baab9d1d47  pop rcx
000073baab9d1d48  pop rax
000073baab9d1d49  add rsp, 0x08
000073baab9d1d4d  jmp 0x000073BAAB9D1B21
000073baab9d1d52  call 0x000073BAAB80C380
000073baab9d1d57  jmp 0x000073BAAB9D1B34
000073baab9d1d5c  sub rsp, 0x08
000073baab9d1d60  push rax
000073baab9d1d61  push rcx
000073baab9d1d62  push rdx
000073baab9d1d63  push rdi
000073baab9d1d64  push rsi
000073baab9d1d65  push r8
000073baab9d1d67  push r9
000073baab9d1d69  push r10
000073baab9d1d6b  push r11
000073baab9d1d6d  sub rsp, 0xF0
000073baab9d1d74  vmovaps [rsp], xmm0
000073baab9d1d79  vmovaps [rsp+0x10], xmm2
000073baab9d1d7f  vmovaps [rsp+0x20], xmm3
000073baab9d1d85  vmovaps [rsp+0x30], xmm4
000073baab9d1d8b  vmovaps [rsp+0x40], xmm5
000073baab9d1d91  vmovaps [rsp+0x50], xmm6
000073baab9d1d97  vmovaps [rsp+0x60], xmm7
000073baab9d1d9d  vmovaps [rsp+0x70], xmm8
000073baab9d1da3  vmovaps [rsp+0x80], xmm9
000073baab9d1dac  vmovaps [rsp+0x90], xmm10
000073baab9d1db5  vmovaps [rsp+0xA0], xmm11
000073baab9d1dbe  vmovaps [rsp+0xB0], xmm12
000073baab9d1dc7  vmovaps [rsp+0xC0], xmm13
000073baab9d1dd0  vmovaps [rsp+0xD0], xmm14
000073baab9d1dd9  vmovaps [rsp+0xE0], xmm15
000073baab9d1de2  sub rsp, 0x30
000073baab9d1de6  movaps [rsp], xmm1
000073baab9d1dea  movaps [rsp+0x10], xmm14
000073baab9d1df0  movaps [rsp+0x20], xmm15
000073baab9d1df6  lea rdi, [rsp]
000073baab9d1dfa  mov esi, 0x00
000073baab9d1dff  mov rax, 0x5F3F1062D530
000073baab9d1e09  call rax
000073baab9d1e0b  movaps xmm1, [rsp]
000073baab9d1e0f  add rsp, 0x30
000073baab9d1e13  vmovaps xmm0, [rsp]
000073baab9d1e18  vmovaps xmm2, [rsp+0x10]
000073baab9d1e1e  vmovaps xmm3, [rsp+0x20]
000073baab9d1e24  vmovaps xmm4, [rsp+0x30]
000073baab9d1e2a  vmovaps xmm5, [rsp+0x40]
000073baab9d1e30  vmovaps xmm6, [rsp+0x50]
000073baab9d1e36  vmovaps xmm7, [rsp+0x60]
000073baab9d1e3c  vmovaps xmm8, [rsp+0x70]
000073baab9d1e42  vmovaps xmm9, [rsp+0x80]
000073baab9d1e4b  vmovaps xmm10, [rsp+0x90]
000073baab9d1e54  vmovaps xmm11, [rsp+0xA0]
000073baab9d1e5d  vmovaps xmm12, [rsp+0xB0]
000073baab9d1e66  vmovaps xmm13, [rsp+0xC0]
000073baab9d1e6f  vmovaps xmm14, [rsp+0xD0]
000073baab9d1e78  vmovaps xmm15, [rsp+0xE0]
000073baab9d1e81  add rsp, 0xF0
000073baab9d1e88  pop r11
000073baab9d1e8a  pop r10
000073baab9d1e8c  pop r9
000073baab9d1e8e  pop r8
000073baab9d1e90  pop rsi
000073baab9d1e91  pop rdi
000073baab9d1e92  pop rdx
000073baab9d1e93  pop rcx
000073baab9d1e94  pop rax
000073baab9d1e95  add rsp, 0x08
000073baab9d1e99  jmp 0x000073BAAB9D1B4E
000073baab9d1e9e  call 0x000073BAAB7FF540
000073baab9d1ea3  jmp 0x000073BAAB9D1B61
000073baab9d1ea8  int3
000073baab9d1ea9  nop [rax], eax
000073baab9d1eb0  movaps xmm1, [r15+0x180]
000073baab9d1eb8  vpmovqd xmm15, xmm1
000073baab9d1ebe  pxor xmm14, xmm14
000073baab9d1ec3  punpcklqdq xmm15, xmm14
000073baab9d1ec8  movaps [r15+0x210], xmm15
000073baab9d1ed0  movq xmm15, qword ptr [r15+0x140]
000073baab9d1ed9  movq xmm14, qword ptr [r15+0x120]
000073baab9d1ee2  psubd xmm15, xmm14
000073baab9d1ee7  movq xmm15, xmm15
000073baab9d1eec  movaps xmm13, [r15+0x170]
000073baab9d1ef4  paddq xmm1, xmm13
000073baab9d1ef9  movaps [r15+0x180], xmm1
000073baab9d1f01  movq xmm1, qword ptr [r15+0x160]
000073baab9d1f0a  paddd xmm14, xmm1
000073baab9d1f0f  movq xmm14, xmm14
000073baab9d1f14  movq xmm14, xmm14
000073baab9d1f19  movaps [r15+0x120], xmm14
000073baab9d1f21  pmovzxdq xmm15, xmm15
000073baab9d1f27  psllq xmm15, 0x00
000073baab9d1f2d  movq xmm1, qword ptr [r15+0x210]
000073baab9d1f36  movq xmm14, qword ptr [r15+0x110]
000073baab9d1f3f  paddd xmm1, xmm14
000073baab9d1f44  movq xmm1, xmm1
000073baab9d1f48  vcvtuqq2pd xmm15, xmm15
000073baab9d1f4e  pmovzxdq xmm1, xmm1
000073baab9d1f53  psllq xmm1, 0x00
000073baab9d1f58  vcvtuqq2pd xmm1, xmm1
000073baab9d1f5e  movaps xmm14, [r15+0x150]
000073baab9d1f66  movaps xmm13, xmm15
000073baab9d1f6a  mulpd xmm13, xmm14
000073baab9d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000073baab9d1f75  ptest xmm12, xmm12
000073baab9d1f7b  jnz 0x000073BAAB9D205E
000073baab9d1f81  movaps [r15+0x220], xmm13
000073baab9d1f89  mov rax, [r15+0x48]
000073baab9d1f8d  mov r14, [r15+0x50]
000073baab9d1f91  lea r12, [r14+rax*1]
000073baab9d1f95  movups [r13+r12*1], xmm13
000073baab9d1f9b  movaps xmm15, [r15+0x130]
000073baab9d1fa3  movaps xmm14, xmm1
000073baab9d1fa7  mulpd xmm14, xmm15
000073baab9d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000073baab9d1fb2  ptest xmm13, xmm13
000073baab9d1fb8  jnz 0x000073BAAB9D21AC
000073baab9d1fbe  movaps [r15+0x210], xmm14
000073baab9d1fc6  mov r14, [r15+0x40]
000073baab9d1fca  lea r12, [r14+rax*1]
000073baab9d1fce  movups [r13+r12*1], xmm14
000073baab9d1fd4  lea r14, [rax+0x10]
000073baab9d1fd8  mov [r15+0x48], r14
000073baab9d1fdc  xor eax, eax
000073baab9d1fde  mov r12d, 0x200
000073baab9d1fe4  cmp r14, r12
000073baab9d1fe7  cmc
000073baab9d1fe8  lahf
000073baab9d1fe9  seto al
000073baab9d1fec  mov [r15+0x108], eax
000073baab9d1ff3  mov eax, [r15+0x108]
000073baab9d1ffa  sahf
000073baab9d1ffb  jnz 0x000073BAAB9D202D
000073baab9d1ffd  cmp dword ptr [r15+0x318], 0x00
000073baab9d2005  jz 0x000073BAAB9D2300
000073baab9d200b  nop [rax+rax*1], ax
000073baab9d2014  nop [rax+rax*1], eax
000073baab9d201c  mov eax, 0x410490
000073baab9d2021  mov [r15+0x100], rax
000073baab9d2028  jmp 0x000073BAAB7FE110
000073baab9d202d  cmp dword ptr [r15+0x318], 0x00
000073baab9d2035  jz 0x000073BAAB9D1EB0
000073baab9d203b  nop [rax+rax*1], ax
000073baab9d2044  nop [rax+rax*1], eax
000073baab9d204c  mov eax, 0x410450
000073baab9d2051  mov [r15+0x100], rax
000073baab9d2058  jmp 0x000073BAAB7FE110
000073baab9d205d  int3
000073baab9d205e  sub rsp, 0x08
000073baab9d2062  push rax
000073baab9d2063  push rcx
000073baab9d2064  push rdx
000073baab9d2065  push rdi
000073baab9d2066  push rsi
000073baab9d2067  push r8
000073baab9d2069  push r9
000073baab9d206b  push r10
000073baab9d206d  push r11
000073baab9d206f  sub rsp, 0xF0
000073baab9d2076  vmovaps [rsp], xmm0
000073baab9d207b  vmovaps [rsp+0x10], xmm1
000073baab9d2081  vmovaps [rsp+0x20], xmm2
000073baab9d2087  vmovaps [rsp+0x30], xmm3
000073baab9d208d  vmovaps [rsp+0x40], xmm4
000073baab9d2093  vmovaps [rsp+0x50], xmm5
000073baab9d2099  vmovaps [rsp+0x60], xmm6
000073baab9d209f  vmovaps [rsp+0x70], xmm7
000073baab9d20a5  vmovaps [rsp+0x80], xmm8
000073baab9d20ae  vmovaps [rsp+0x90], xmm9
000073baab9d20b7  vmovaps [rsp+0xA0], xmm10
000073baab9d20c0  vmovaps [rsp+0xB0], xmm11
000073baab9d20c9  vmovaps [rsp+0xC0], xmm12
000073baab9d20d2  vmovaps [rsp+0xD0], xmm14
000073baab9d20db  vmovaps [rsp+0xE0], xmm15
000073baab9d20e4  sub rsp, 0x30
000073baab9d20e8  movaps [rsp], xmm13
000073baab9d20ed  movaps [rsp+0x10], xmm15
000073baab9d20f3  movaps [rsp+0x20], xmm14
000073baab9d20f9  lea rdi, [rsp]
000073baab9d20fd  mov esi, 0x00
000073baab9d2102  mov rax, 0x5F3F1062D530
000073baab9d210c  call rax
000073baab9d210e  movaps xmm13, [rsp]
000073baab9d2113  add rsp, 0x30
000073baab9d2117  vmovaps xmm0, [rsp]
000073baab9d211c  vmovaps xmm1, [rsp+0x10]
000073baab9d2122  vmovaps xmm2, [rsp+0x20]
000073baab9d2128  vmovaps xmm3, [rsp+0x30]
000073baab9d212e  vmovaps xmm4, [rsp+0x40]
000073baab9d2134  vmovaps xmm5, [rsp+0x50]
000073baab9d213a  vmovaps xmm6, [rsp+0x60]
000073baab9d2140  vmovaps xmm7, [rsp+0x70]
000073baab9d2146  vmovaps xmm8, [rsp+0x80]
000073baab9d214f  vmovaps xmm9, [rsp+0x90]
000073baab9d2158  vmovaps xmm10, [rsp+0xA0]
000073baab9d2161  vmovaps xmm11, [rsp+0xB0]
000073baab9d216a  vmovaps xmm12, [rsp+0xC0]
000073baab9d2173  vmovaps xmm14, [rsp+0xD0]
000073baab9d217c  vmovaps xmm15, [rsp+0xE0]
000073baab9d2185  add rsp, 0xF0
000073baab9d218c  pop r11
000073baab9d218e  pop r10
000073baab9d2190  pop r9
000073baab9d2192  pop r8
000073baab9d2194  pop rsi
000073baab9d2195  pop rdi
000073baab9d2196  pop rdx
000073baab9d2197  pop rcx
000073baab9d2198  pop rax
000073baab9d2199  add rsp, 0x08
000073baab9d219d  jmp 0x000073BAAB9D1F81
000073baab9d21a2  call 0x000073BAAB8C2240
000073baab9d21a7  jmp 0x000073BAAB9D1F9B
000073baab9d21ac  sub rsp, 0x08
000073baab9d21b0  push rax
000073baab9d21b1  push rcx
000073baab9d21b2  push rdx
000073baab9d21b3  push rdi
000073baab9d21b4  push rsi
000073baab9d21b5  push r8
000073baab9d21b7  push r9
000073baab9d21b9  push r10
000073baab9d21bb  push r11
000073baab9d21bd  sub rsp, 0xF0
000073baab9d21c4  vmovaps [rsp], xmm0
000073baab9d21c9  vmovaps [rsp+0x10], xmm1
000073baab9d21cf  vmovaps [rsp+0x20], xmm2
000073baab9d21d5  vmovaps [rsp+0x30], xmm3
000073baab9d21db  vmovaps [rsp+0x40], xmm4
000073baab9d21e1  vmovaps [rsp+0x50], xmm5
000073baab9d21e7  vmovaps [rsp+0x60], xmm6
000073baab9d21ed  vmovaps [rsp+0x70], xmm7
000073baab9d21f3  vmovaps [rsp+0x80], xmm8
000073baab9d21fc  vmovaps [rsp+0x90], xmm9
000073baab9d2205  vmovaps [rsp+0xA0], xmm10
000073baab9d220e  vmovaps [rsp+0xB0], xmm11
000073baab9d2217  vmovaps [rsp+0xC0], xmm12
000073baab9d2220  vmovaps [rsp+0xD0], xmm13
000073baab9d2229  vmovaps [rsp+0xE0], xmm15
000073baab9d2232  sub rsp, 0x30
000073baab9d2236  movaps [rsp], xmm14
000073baab9d223b  movaps [rsp+0x10], xmm1
000073baab9d2240  movaps [rsp+0x20], xmm15
000073baab9d2246  lea rdi, [rsp]
000073baab9d224a  mov esi, 0x00
000073baab9d224f  mov rax, 0x5F3F1062D530
000073baab9d2259  call rax
000073baab9d225b  movaps xmm14, [rsp]
000073baab9d2260  add rsp, 0x30
000073baab9d2264  vmovaps xmm0, [rsp]
000073baab9d2269  vmovaps xmm1, [rsp+0x10]
000073baab9d226f  vmovaps xmm2, [rsp+0x20]
000073baab9d2275  vmovaps xmm3, [rsp+0x30]
000073baab9d227b  vmovaps xmm4, [rsp+0x40]
000073baab9d2281  vmovaps xmm5, [rsp+0x50]
000073baab9d2287  vmovaps xmm6, [rsp+0x60]
000073baab9d228d  vmovaps xmm7, [rsp+0x70]
000073baab9d2293  vmovaps xmm8, [rsp+0x80]
000073baab9d229c  vmovaps xmm9, [rsp+0x90]
000073baab9d22a5  vmovaps xmm10, [rsp+0xA0]
000073baab9d22ae  vmovaps xmm11, [rsp+0xB0]
000073baab9d22b7  vmovaps xmm12, [rsp+0xC0]
000073baab9d22c0  vmovaps xmm13, [rsp+0xD0]
000073baab9d22c9  vmovaps xmm15, [rsp+0xE0]
000073baab9d22d2  add rsp, 0xF0
000073baab9d22d9  pop r11
000073baab9d22db  pop r10
000073baab9d22dd  pop r9
000073baab9d22df  pop r8
000073baab9d22e1  pop rsi
000073baab9d22e2  pop rdi
000073baab9d22e3  pop rdx
000073baab9d22e4  pop rcx
000073baab9d22e5  pop rax
000073baab9d22e6  add rsp, 0x08
000073baab9d22ea  jmp 0x000073BAAB9D1FBE
000073baab9d22ef  call 0x000073BAAB8C34C0
000073baab9d22f4  jmp 0x000073BAAB9D1FD4
000073baab9d22f9  int3
000073baab9d22fa  nop [rax+rax*1], ax
000073baab9d2300  mov rax, [r15+0x50]
000073baab9d2304  lea r14, [rax+0x80]
000073baab9d230b  movups xmm1, [r13+r14*1]
000073baab9d2311  lea r14, [rax+0x90]
000073baab9d2318  movups xmm15, [r13+r14*1]
000073baab9d231e  vxorps xmm14, xmm14, xmm14
000073baab9d2323  vpbroadcastq xmm14, xmm14
000073baab9d2328  lea r14, [rax+0x40]
000073baab9d232c  movups xmm13, [r13+r14*1]
000073baab9d2332  lea r14, [rax+0x50]
000073baab9d2336  movups xmm12, [r13+r14*1]
000073baab9d233c  mov qword ptr [r15+0x48], 0x00
000073baab9d2344  movups xmm11, [r13+rax*1]
000073baab9d234a  lea r14, [rax+0x10]
000073baab9d234e  movups xmm10, [r13+r14*1]
000073baab9d2354  mov r14, [r15+0xF8]
000073baab9d235b  lea r12, [r14+0xE0]
000073baab9d2362  movups [r13+r12*1], xmm15
000073baab9d2368  lea r12, [r14+0xF0]
000073baab9d236f  movups [r13+r12*1], xmm1
000073baab9d2375  lea r12, [rax+0xC0]
000073baab9d237c  movups xmm1, [r13+r12*1]
000073baab9d2382  lea r12, [rax+0xD0]
000073baab9d2389  movups xmm15, [r13+r12*1]
000073baab9d238f  lea r12, [rax+0x140]
000073baab9d2396  movups xmm9, [r13+r12*1]
000073baab9d239c  lea r12, [rax+0x150]
000073baab9d23a3  movups xmm8, [r13+r12*1]
000073baab9d23a9  lea r12, [rax+0x180]
000073baab9d23b0  movups xmm7, [r13+r12*1]
000073baab9d23b6  lea r12, [rax+0x190]
000073baab9d23bd  movups xmm6, [r13+r12*1]
000073baab9d23c3  lea r12, [r14+0xC0]
000073baab9d23ca  movups [r13+r12*1], xmm15
000073baab9d23d0  lea r12, [r14+0xD0]
000073baab9d23d7  movups [r13+r12*1], xmm1
000073baab9d23dd  lea r12, [rax+0x100]
000073baab9d23e4  movups xmm1, [r13+r12*1]
000073baab9d23ea  lea r12, [rax+0x110]
000073baab9d23f1  movups xmm15, [r13+r12*1]
000073baab9d23f7  lea r12, [rax+0x1C0]
000073baab9d23fe  movups xmm5, [r13+r12*1]
000073baab9d2404  lea r12, [rax+0x1D0]
000073baab9d240b  movups xmm4, [r13+r12*1]
000073baab9d2411  lea r12, [rax+0x20]
000073baab9d2415  movups xmm3, [r13+r12*1]
000073baab9d241b  lea r12, [rax+0x30]
000073baab9d241f  movups xmm2, [r13+r12*1]
000073baab9d2425  movaps [r15+0x1F0], xmm2
000073baab9d242d  lea r12, [r14+0x20]
000073baab9d2431  movups [r13+r12*1], xmm1
000073baab9d2437  lea r12, [r14+0x30]
000073baab9d243b  movups [r13+r12*1], xmm12
000073baab9d2441  lea r12, [rax+0x60]
000073baab9d2445  movups xmm1, [r13+r12*1]
000073baab9d244b  lea r12, [rax+0x70]
000073baab9d244f  movups xmm12, [r13+r12*1]
000073baab9d2455  lea r12, [r14+0x60]
000073baab9d2459  movups [r13+r12*1], xmm11
000073baab9d245f  lea r12, [r14+0x70]
000073baab9d2463  movups [r13+r12*1], xmm5
000073baab9d2469  lea r12, [rax+0xE0]
000073baab9d2470  movups xmm11, [r13+r12*1]
000073baab9d2476  lea r12, [rax+0xF0]
000073baab9d247d  movups xmm5, [r13+r12*1]
000073baab9d2483  lea r12, [rax+0x120]
000073baab9d248a  vmovaps [rsp+0x10], xmm1
000073baab9d2490  movups xmm1, [r13+r12*1]
000073baab9d2496  lea r12, [rax+0x130]
000073baab9d249d  vmovaps [rsp+0x20], xmm1
000073baab9d24a3  movups xmm1, [r13+r12*1]
000073baab9d24a9  lea r12, [r14+0xA0]
000073baab9d24b0  movups [r13+r12*1], xmm12
000073baab9d24b6  lea r12, [r14+0xB0]
000073baab9d24bd  vmovaps xmm12, [rsp+0x10]
000073baab9d24c3  movups [r13+r12*1], xmm12
000073baab9d24c9  lea r12, [rax+0xA0]
000073baab9d24d0  movups xmm12, [r13+r12*1]
000073baab9d24d6  lea r12, [rax+0xB0]
000073baab9d24dd  vmovaps [rsp+0x10], xmm1
000073baab9d24e3  movups xmm1, [r13+r12*1]
000073baab9d24e9  lea r12, [rax+0x160]
000073baab9d24f0  vmovaps [rsp+0x30], xmm1
000073baab9d24f6  movups xmm1, [r13+r12*1]
000073baab9d24fc  lea r12, [rax+0x170]
000073baab9d2503  vmovaps [rsp+0x40], xmm1
000073baab9d2509  movups xmm1, [r13+r12*1]
000073baab9d250f  movaps [r15+0x2B0], xmm1
000073baab9d2517  lea r12, [rax+0x1A0]
000073baab9d251e  vmovaps [rsp+0x50], xmm1
000073baab9d2524  movups xmm1, [r13+r12*1]
000073baab9d252a  lea r12, [rax+0x1B0]
000073baab9d2531  vmovaps [rsp+0x60], xmm1
000073baab9d2537  movups xmm1, [r13+r12*1]
000073baab9d253d  vmovaps [rsp+0x70], xmm1
000073baab9d2543  vmovaps xmm1, [rsp+0x60]
000073baab9d2549  movaps [r15+0x290], xmm1
000073baab9d2551  vmovaps [rsp+0x60], xmm1
000073baab9d2557  vmovaps xmm1, [rsp+0x70]
000073baab9d255d  movaps [r15+0x1E0], xmm1
000073baab9d2565  lea r12, [r14+0x80]
000073baab9d256c  vmovaps [rsp+0x70], xmm1
000073baab9d2572  vmovaps xmm1, [rsp+0x30]
000073baab9d2578  movups [r13+r12*1], xmm1
000073baab9d257e  lea r12, [r14+0x90]
000073baab9d2585  movups [r13+r12*1], xmm12
000073baab9d258b  lea r12, [rax+0x1E0]
000073baab9d2592  movups xmm1, [r13+r12*1]
000073baab9d2598  lea r12, [rax+0x1F0]
000073baab9d259f  movups xmm12, [r13+r12*1]
000073baab9d25a5  mov qword ptr [r15+0x50], 0x432200
000073baab9d25ad  lea rax, [r14+0x40]
000073baab9d25b1  vmovaps [rsp+0x30], xmm1
000073baab9d25b7  vmovaps xmm1, [rsp+0x40]
000073baab9d25bd  movups [r13+rax*1], xmm1
000073baab9d25c3  lea rax, [r14+0x50]
000073baab9d25c7  movups [r13+rax*1], xmm10
000073baab9d25cd  movups [r13+r14*1], xmm12
000073baab9d25d3  lea rax, [r14+0x10]
000073baab9d25d7  vmovaps xmm1, [rsp+0x30]
000073baab9d25dd  movups [r13+rax*1], xmm1
000073baab9d25e3  mov rax, [r15+0x40]
000073baab9d25e7  vmovaps [rsp+0x30], xmm3
000073baab9d25ed  vmovaps xmm1, [rsp+0x30]
000073baab9d25f3  por xmm3, xmm1
000073baab9d25f7  vmovaps [rsp+0x30], xmm6
000073baab9d25fd  vmovaps xmm12, [rsp+0x30]
000073baab9d2603  por xmm6, xmm12
000073baab9d2608  lea r12, [rax+0x30]
000073baab9d260c  mov r11, [r13+r12*1]
000073baab9d2611  lea r12, [rax+0x38]
000073baab9d2615  mov r10, [r13+r12*1]
000073baab9d261a  movq xmm12, r11
000073baab9d261f  movq xmm10, r10
000073baab9d2624  movq xmm12, xmm12
000073baab9d2629  vmovaps [rsp+0x30], xmm12
000073baab9d262f  movq xmm12, xmm12
000073baab9d2634  movaps [r15+0x130], xmm12
000073baab9d263c  movq xmm10, xmm10
000073baab9d2641  vmovaps [rsp+0x40], xmm10
000073baab9d2647  movq xmm10, xmm10
000073baab9d264c  movaps [r15+0x280], xmm10
000073baab9d2654  vmovaps [rsp+0x80], xmm9
000073baab9d265d  vmovaps xmm12, [rsp+0x80]
000073baab9d2666  por xmm9, xmm12
000073baab9d266b  lea r12, [rax+0x20]
000073baab9d266f  mov r11, [r13+r12*1]
000073baab9d2674  lea r12, [rax+0x28]
000073baab9d2678  mov r10, [r13+r12*1]
000073baab9d267d  movq xmm12, r11
000073baab9d2682  movq xmm10, r10
000073baab9d2687  movq xmm12, xmm12
000073baab9d268c  vmovaps [rsp+0x80], xmm12
000073baab9d2695  movq xmm12, xmm12
000073baab9d269a  movaps [r15+0x150], xmm12
000073baab9d26a2  movq xmm10, xmm10
000073baab9d26a7  vmovaps [rsp+0x90], xmm10
000073baab9d26b0  movq xmm10, xmm10
000073baab9d26b5  movaps [r15+0x140], xmm10
000073baab9d26bd  lea r12, [rax+0x10]
000073baab9d26c1  mov r11, [r13+r12*1]
000073baab9d26c6  lea r12, [rax+0x18]
000073baab9d26ca  mov r10, [r13+r12*1]
000073baab9d26cf  movq xmm12, r11
000073baab9d26d4  movq xmm10, r10
000073baab9d26d9  movq xmm12, xmm12
000073baab9d26de  vmovaps [rsp+0xA0], xmm12
000073baab9d26e7  movq xmm12, xmm12
000073baab9d26ec  movaps [r15+0x170], xmm12
000073baab9d26f4  movq xmm10, xmm10
000073baab9d26f9  vmovaps [rsp+0xB0], xmm10
000073baab9d2702  movq xmm10, xmm10
000073baab9d2707  movaps [r15+0x160], xmm10
000073baab9d270f  mov r12, [r13+rax*1]
000073baab9d2714  vmovq xmm12, r12
000073baab9d2719  vpbroadcastq xmm12, xmm12
000073baab9d271e  lea r12, [rax+0x08]
000073baab9d2722  mov rax, [r13+r12*1]
000073baab9d2727  movq xmm10, rax
000073baab9d272c  movaps [r15+0x230], xmm10
000073baab9d2734  lea rax, [r14+0x50]
000073baab9d2738  movups xmm10, [r13+rax*1]
000073baab9d273e  lea rax, [r14+0x60]
000073baab9d2742  vmovaps [rsp+0xC0], xmm1
000073baab9d274b  movups xmm1, [r13+rax*1]
000073baab9d2751  lea rax, [r14+0x30]
000073baab9d2755  vmovaps [rsp+0xD0], xmm1
000073baab9d275e  movups xmm1, [r13+rax*1]
000073baab9d2764  mov qword ptr [r15+0x60], 0x432200
000073baab9d276c  mov qword ptr [r15+0x58], 0x40
000073baab9d2774  vmovaps [rsp+0xE0], xmm1
000073baab9d277d  vmovaps [rsp+0xF0], xmm15
000073baab9d2786  vmovaps xmm15, [rsp+0xC0]
000073baab9d278f  vmovaps [rsp+0xC0], xmm14
000073baab9d2798  movaps xmm1, xmm12
000073baab9d279c  mulpd xmm1, xmm15
000073baab9d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
000073baab9d27a6  ptest xmm14, xmm14
000073baab9d27ac  jnz 0x000073BAAB9D3863
000073baab9d27b2  movq xmm15, qword ptr [r15+0x230]
000073baab9d27bb  vmovaps [rsp+0x100], xmm15
000073baab9d27c4  vpermilpd xmm15, xmm15, 0x00
000073baab9d27ca  vmovaps [rsp+0x110], xmm1
000073baab9d27d3  vmovaps xmm1, [rsp+0xE0]
000073baab9d27dc  vmovaps [rsp+0xE0], xmm13
000073baab9d27e5  movaps xmm14, xmm1
000073baab9d27e9  mulpd xmm14, xmm15
000073baab9d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
000073baab9d27f4  ptest xmm13, xmm13
000073baab9d27fa  jnz 0x000073BAAB9D39A5
000073baab9d2800  vxorps xmm1, xmm1, xmm1
000073baab9d2804  vpbroadcastq xmm1, xmm1
000073baab9d2809  vmovaps xmm13, [rsp+0xD0]
000073baab9d2812  vmovaps [rsp+0xD0], xmm1
000073baab9d281b  movaps xmm15, xmm12
000073baab9d281f  mulpd xmm15, xmm13
000073baab9d2824  vcmppd xmm1, xmm15, xmm15, 0x03
000073baab9d282a  ptest xmm1, xmm1
000073baab9d282f  jnz 0x000073BAAB9D3AE8
000073baab9d2835  movaps xmm1, xmm12
000073baab9d2839  mulpd xmm1, xmm10
000073baab9d283e  vcmppd xmm13, xmm1, xmm1, 0x03
000073baab9d2843  ptest xmm13, xmm13
000073baab9d2849  jnz 0x000073BAAB9D3C2C
000073baab9d284f  movaps xmm13, xmm12
000073baab9d2853  mulpd xmm13, xmm2
000073baab9d2858  vcmppd xmm10, xmm13, xmm13, 0x03
000073baab9d285e  ptest xmm10, xmm10
000073baab9d2864  jnz 0x000073BAAB9D3D6E
000073baab9d286a  vmovaps [rsp+0x120], xmm7
000073baab9d2873  vmovaps xmm12, [rsp+0x120]
000073baab9d287c  por xmm7, xmm12
000073baab9d2881  vmovaps xmm12, [rsp+0xE0]
000073baab9d288a  vmovaps xmm10, [rsp+0xE0]
000073baab9d2893  por xmm12, xmm10
000073baab9d2898  vmovaps xmm2, [rsp+0x100]
000073baab9d28a1  vpermilpd xmm2, xmm2, 0x00
000073baab9d28a7  vmovaps [rsp+0xE0], xmm1
000073baab9d28b0  vmovaps [rsp+0x120], xmm15
000073baab9d28b9  movaps xmm1, xmm10
000073baab9d28bd  mulpd xmm1, xmm2
000073baab9d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
000073baab9d28c6  ptest xmm15, xmm15
000073baab9d28cc  jnz 0x000073BAAB9D3EB1
000073baab9d28d2  xor eax, eax
000073baab9d28d4  mov r12d, 0x40
000073baab9d28da  mov r11d, 0x200
000073baab9d28e0  cmp r12, r11
000073baab9d28e3  cmc
000073baab9d28e4  lahf
000073baab9d28e5  seto al
000073baab9d28e8  mov [r15+0x108], eax
000073baab9d28ef  vmovaps xmm10, [rsp+0x110]
000073baab9d28f8  vmovaps xmm2, [rsp+0xD0]
000073baab9d2901  vmovaps [rsp+0xD0], xmm1
000073baab9d290a  movaps xmm15, xmm10
000073baab9d290e  addpd xmm15, xmm2
000073baab9d2913  vcmppd xmm1, xmm15, xmm15, 0x03
000073baab9d2919  ptest xmm1, xmm1
000073baab9d291e  jnz 0x000073BAAB9D3FF2
000073baab9d2924  vmovaps xmm10, [rsp+0x120]
000073baab9d292d  vmovaps [rsp+0x110], xmm15
000073baab9d2936  vmovaps xmm15, [rsp+0xC0]
000073baab9d293f  vmovaps [rsp+0xC0], xmm14
000073baab9d2948  movaps xmm1, xmm10
000073baab9d294c  addpd xmm1, xmm15
000073baab9d2951  vcmppd xmm14, xmm1, xmm1, 0x03
000073baab9d2956  ptest xmm14, xmm14
000073baab9d295c  jnz 0x000073BAAB9D4135
000073baab9d2962  vmovaps xmm10, [rsp+0xE0]
000073baab9d296b  vmovaps [rsp+0xE0], xmm1
000073baab9d2974  movaps xmm14, xmm10
000073baab9d2978  addpd xmm14, xmm15
000073baab9d297d  vcmppd xmm1, xmm14, xmm14, 0x03
000073baab9d2983  ptest xmm1, xmm1
000073baab9d2988  jnz 0x000073BAAB9D4277
000073baab9d298e  vmovaps xmm1, [rsp+0x10]
000073baab9d2994  vmovaps xmm15, [rsp+0x10]
000073baab9d299a  por xmm1, xmm15
000073baab9d299f  vmovaps xmm15, [rsp+0x20]
000073baab9d29a5  vmovaps xmm10, [rsp+0x20]
000073baab9d29ab  por xmm15, xmm10
000073baab9d29b0  vmovaps [rsp+0x10], xmm5
000073baab9d29b6  vmovaps xmm10, [rsp+0x10]
000073baab9d29bc  por xmm5, xmm10
000073baab9d29c1  vmovaps [rsp+0x10], xmm11
000073baab9d29c7  vmovaps xmm10, [rsp+0x10]
000073baab9d29cd  por xmm11, xmm10
000073baab9d29d2  vmovaps [rsp+0x10], xmm4
000073baab9d29d8  vmovaps xmm10, [rsp+0x10]
000073baab9d29de  por xmm4, xmm10
000073baab9d29e3  vmovaps [rsp+0x10], xmm8
000073baab9d29e9  vmovaps xmm10, [rsp+0x10]
000073baab9d29ef  por xmm8, xmm10
000073baab9d29f4  vmovaps xmm10, [rsp+0xF0]
000073baab9d29fd  vmovaps [rsp+0x10], xmm1
000073baab9d2a03  vmovaps xmm1, [rsp+0xF0]
000073baab9d2a0c  por xmm10, xmm1
000073baab9d2a11  lea rax, [r14+0xA0]
000073baab9d2a18  movups xmm1, [r13+rax*1]
000073baab9d2a1e  lea rax, [r14+0xB0]
000073baab9d2a25  vmovaps [rsp+0x20], xmm1
000073baab9d2a2b  movups xmm1, [r13+rax*1]
000073baab9d2a31  vmovaps [rsp+0xF0], xmm1
000073baab9d2a3a  vmovaps [rsp+0x120], xmm15
000073baab9d2a43  movaps xmm1, xmm13
000073baab9d2a47  addpd xmm1, xmm2
000073baab9d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
000073baab9d2a50  ptest xmm15, xmm15
000073baab9d2a56  jnz 0x000073BAAB9D43CF
000073baab9d2a5c  lea rax, [r14+0xF0]
000073baab9d2a63  movups xmm15, [r13+rax*1]
000073baab9d2a69  vmovaps xmm2, [rsp+0xE0]
000073baab9d2a72  vmovaps [rsp+0xE0], xmm1
000073baab9d2a7b  vmovaps xmm1, [rsp+0xD0]
000073baab9d2a84  vmovaps [rsp+0xD0], xmm15
000073baab9d2a8d  movaps xmm13, xmm2
000073baab9d2a91  addpd xmm13, xmm1
000073baab9d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
000073baab9d2a9c  ptest xmm15, xmm15
000073baab9d2aa2  jnz 0x000073BAAB9D451A
000073baab9d2aa8  vmovaps xmm15, [rsp+0xC0]
000073baab9d2ab1  movaps xmm1, xmm14
000073baab9d2ab5  addpd xmm1, xmm15
000073baab9d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
000073baab9d2abf  ptest xmm2, xmm2
000073baab9d2ac4  jnz 0x000073BAAB9D465C
000073baab9d2aca  vmovaps xmm15, [rsp+0x100]
000073baab9d2ad3  vpermilpd xmm15, xmm15, 0x00
000073baab9d2ad9  vmovaps xmm2, [rsp+0xF0]
000073baab9d2ae2  vmovaps [rsp+0xC0], xmm1
000073baab9d2aeb  movaps xmm14, xmm2
000073baab9d2aef  mulpd xmm14, xmm15
000073baab9d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
000073baab9d2afa  ptest xmm1, xmm1
000073baab9d2aff  jnz 0x000073BAAB9D479E
000073baab9d2b05  vmovaps xmm1, [rsp+0xA0]
000073baab9d2b0e  vpermilpd xmm1, xmm1, 0x00
000073baab9d2b14  vmovaps xmm2, [rsp+0xD0]
000073baab9d2b1d  vmovaps [rsp+0xD0], xmm14
000073baab9d2b26  movaps xmm15, xmm2
000073baab9d2b2a  mulpd xmm15, xmm1
000073baab9d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
000073baab9d2b35  ptest xmm14, xmm14
000073baab9d2b3b  jnz 0x000073BAAB9D48E1
000073baab9d2b41  lea rax, [r14+0xE0]
000073baab9d2b48  movups xmm1, [r13+rax*1]
000073baab9d2b4e  vmovaps xmm14, [rsp+0x100]
000073baab9d2b57  vpermilpd xmm14, xmm14, 0x00
000073baab9d2b5d  vmovaps [rsp+0xF0], xmm1
000073baab9d2b66  vmovaps xmm1, [rsp+0x20]
000073baab9d2b6c  vmovaps [rsp+0x20], xmm15
000073baab9d2b72  movaps xmm2, xmm1
000073baab9d2b75  mulpd xmm2, xmm14
000073baab9d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
000073baab9d2b7f  ptest xmm15, xmm15
000073baab9d2b85  jnz 0x000073BAAB9D4A2D
000073baab9d2b8b  vmovaps [rsp+0x100], xmm10
000073baab9d2b94  vmovaps xmm1, [rsp+0x100]
000073baab9d2b9d  por xmm10, xmm1
000073baab9d2ba2  movaps [r15+0x300], xmm10
000073baab9d2baa  vmovaps [rsp+0x100], xmm8
000073baab9d2bb3  vmovaps xmm1, [rsp+0x100]
000073baab9d2bbc  por xmm8, xmm1
000073baab9d2bc1  movaps [r15+0x190], xmm8
000073baab9d2bc9  vmovaps xmm1, [rsp+0xA0]
000073baab9d2bd2  vpermilpd xmm1, xmm1, 0x00
000073baab9d2bd8  vmovaps xmm14, [rsp+0xF0]
000073baab9d2be1  vmovaps [rsp+0xF0], xmm13
000073baab9d2bea  movaps xmm15, xmm14
000073baab9d2bee  mulpd xmm15, xmm1
000073baab9d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
000073baab9d2bf9  ptest xmm13, xmm13
000073baab9d2bff  jnz 0x000073BAAB9D4B6E
000073baab9d2c05  lea rax, [r14+0x90]
000073baab9d2c0c  movups xmm1, [r13+rax*1]
000073baab9d2c12  vmovaps [rsp+0x100], xmm4
000073baab9d2c1b  vmovaps xmm14, [rsp+0x100]
000073baab9d2c24  por xmm4, xmm14
000073baab9d2c29  movaps [r15+0x1C0], xmm4
000073baab9d2c31  vmovaps [rsp+0x100], xmm11
000073baab9d2c3a  vmovaps xmm14, [rsp+0x100]
000073baab9d2c43  por xmm11, xmm14
000073baab9d2c48  movaps [r15+0x200], xmm11
000073baab9d2c50  vmovaps [rsp+0x100], xmm5
000073baab9d2c59  vmovaps xmm14, [rsp+0x100]
000073baab9d2c62  por xmm5, xmm14
000073baab9d2c67  movaps [r15+0x2D0], xmm5
000073baab9d2c6f  vmovaps xmm14, [rsp+0x120]
000073baab9d2c78  vmovaps xmm13, [rsp+0x120]
000073baab9d2c81  por xmm14, xmm13
000073baab9d2c86  movaps [r15+0x2E0], xmm14
000073baab9d2c8e  vmovaps [rsp+0x100], xmm1
000073baab9d2c97  vmovaps xmm1, [rsp+0x110]
000073baab9d2ca0  vmovaps [rsp+0x110], xmm15
000073baab9d2ca9  vmovaps xmm15, [rsp+0xD0]
000073baab9d2cb2  vmovaps [rsp+0xD0], xmm14
000073baab9d2cbb  movaps xmm13, xmm1
000073baab9d2cbf  addpd xmm13, xmm15
000073baab9d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
000073baab9d2cca  ptest xmm14, xmm14
000073baab9d2cd0  jnz 0x000073BAAB9D4CBB
000073baab9d2cd6  vmovaps xmm1, [rsp+0xA0]
000073baab9d2cdf  vpermilpd xmm1, xmm1, 0x00
000073baab9d2ce5  vmovaps xmm14, [rsp+0x100]
000073baab9d2cee  vmovaps [rsp+0x100], xmm13
000073baab9d2cf7  movaps xmm15, xmm14
000073baab9d2cfb  mulpd xmm15, xmm1
000073baab9d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
000073baab9d2d06  ptest xmm13, xmm13
000073baab9d2d0c  jnz 0x000073BAAB9D4DFE
000073baab9d2d12  lea rax, [r14+0x80]
000073baab9d2d19  movups xmm1, [r13+rax*1]
000073baab9d2d1f  vmovaps xmm13, [rsp+0xE0]
000073baab9d2d28  vmovaps [rsp+0xE0], xmm1
000073baab9d2d31  movaps xmm14, xmm13
000073baab9d2d35  addpd xmm14, xmm2
000073baab9d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
000073baab9d2d40  ptest xmm1, xmm1
000073baab9d2d45  jnz 0x000073BAAB9D4F4B
000073baab9d2d4b  vmovaps xmm13, [rsp+0xF0]
000073baab9d2d54  vmovaps xmm2, [rsp+0x20]
000073baab9d2d5a  vmovaps [rsp+0x20], xmm15
000073baab9d2d60  movaps xmm1, xmm13
000073baab9d2d64  addpd xmm1, xmm2
000073baab9d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
000073baab9d2d6d  ptest xmm15, xmm15
000073baab9d2d73  jnz 0x000073BAAB9D508E
000073baab9d2d79  vmovaps xmm15, [rsp+0x10]
000073baab9d2d7f  vmovaps xmm13, [rsp+0x10]
000073baab9d2d85  por xmm15, xmm13
000073baab9d2d8a  movaps [r15+0x2F0], xmm15
000073baab9d2d92  vmovaps xmm13, [rsp+0xA0]
000073baab9d2d9b  vpermilpd xmm13, xmm13, 0x00
000073baab9d2da1  vmovaps [rsp+0x10], xmm1
000073baab9d2da7  vmovaps xmm1, [rsp+0xE0]
000073baab9d2db0  vmovaps [rsp+0xA0], xmm15
000073baab9d2db9  movaps xmm2, xmm1
000073baab9d2dbc  mulpd xmm2, xmm13
000073baab9d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
000073baab9d2dc6  ptest xmm15, xmm15
000073baab9d2dcc  jnz 0x000073BAAB9D51CF
000073baab9d2dd2  lea rax, [r14+0xD0]
000073baab9d2dd9  movups xmm1, [r13+rax*1]
000073baab9d2ddf  vmovaps xmm13, [rsp+0xC0]
000073baab9d2de8  vmovaps [rsp+0xC0], xmm1
000073baab9d2df1  vmovaps xmm1, [rsp+0x110]
000073baab9d2dfa  vmovaps [rsp+0xE0], xmm14
000073baab9d2e03  movaps xmm15, xmm13
000073baab9d2e07  addpd xmm15, xmm1
000073baab9d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
000073baab9d2e12  ptest xmm14, xmm14
000073baab9d2e18  jnz 0x000073BAAB9D531A
000073baab9d2e1e  vmovaps xmm1, [rsp+0xB0]
000073baab9d2e27  vpermilpd xmm1, xmm1, 0x00
000073baab9d2e2d  movaps xmm14, xmm11
000073baab9d2e31  mulpd xmm14, xmm1
000073baab9d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
000073baab9d2e3c  ptest xmm13, xmm13
000073baab9d2e42  jnz 0x000073BAAB9D545D
000073baab9d2e48  movaps [r15+0x260], xmm14
000073baab9d2e50  vxorps xmm1, xmm1, xmm1
000073baab9d2e54  vpbroadcastq xmm1, xmm1
000073baab9d2e59  movaps [r15+0x1B0], xmm1
000073baab9d2e61  vmovaps xmm1, [rsp+0xB0]
000073baab9d2e6a  vpermilpd xmm1, xmm1, 0x00
000073baab9d2e70  vmovaps xmm11, [rsp+0xC0]
000073baab9d2e79  vmovaps [rsp+0xC0], xmm15
000073baab9d2e82  movaps xmm13, xmm11
000073baab9d2e86  mulpd xmm13, xmm1
000073baab9d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
000073baab9d2e91  ptest xmm15, xmm15
000073baab9d2e97  jnz 0x000073BAAB9D55A0
000073baab9d2e9d  lea rax, [r14+0xC0]
000073baab9d2ea4  movups xmm1, [r13+rax*1]
000073baab9d2eaa  vmovaps xmm11, [rsp+0x100]
000073baab9d2eb3  vmovaps [rsp+0xF0], xmm1
000073baab9d2ebc  vmovaps xmm1, [rsp+0x20]
000073baab9d2ec2  vmovaps [rsp+0x20], xmm14
000073baab9d2ec8  movaps xmm15, xmm11
000073baab9d2ecc  addpd xmm15, xmm1
000073baab9d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
000073baab9d2ed7  ptest xmm14, xmm14
000073baab9d2edd  jnz 0x000073BAAB9D56ED
000073baab9d2ee3  vmovaps [rsp+0x100], xmm9
000073baab9d2eec  vmovaps xmm1, [rsp+0x100]
000073baab9d2ef5  por xmm9, xmm1
000073baab9d2efa  movaps [r15+0x270], xmm9
000073baab9d2f02  vmovaps [rsp+0x100], xmm6
000073baab9d2f0b  vmovaps xmm1, [rsp+0x100]
000073baab9d2f14  por xmm6, xmm1
000073baab9d2f18  movaps [r15+0x1A0], xmm6
000073baab9d2f20  vmovaps xmm14, [rsp+0xB0]
000073baab9d2f29  vpermilpd xmm14, xmm14, 0x00
000073baab9d2f2f  vmovaps xmm6, [rsp+0xF0]
000073baab9d2f38  vmovaps [rsp+0xF0], xmm1
000073baab9d2f41  movaps xmm11, xmm6
000073baab9d2f45  mulpd xmm11, xmm14
000073baab9d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
000073baab9d2f50  ptest xmm1, xmm1
000073baab9d2f55  jnz 0x000073BAAB9D5830
000073baab9d2f5b  lea rax, [r14+0x20]
000073baab9d2f5f  movups xmm1, [r13+rax*1]
000073baab9d2f65  movaps [r15+0x110], xmm1
000073baab9d2f6d  vmovaps xmm6, [rsp+0xE0]
000073baab9d2f76  vmovaps [rsp+0xE0], xmm1
000073baab9d2f7f  movaps xmm14, xmm6
000073baab9d2f83  addpd xmm14, xmm2
000073baab9d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
000073baab9d2f8e  ptest xmm1, xmm1
000073baab9d2f93  jnz 0x000073BAAB9D597D
000073baab9d2f99  vmovaps xmm1, [rsp+0xB0]
000073baab9d2fa2  vpermilpd xmm1, xmm1, 0x00
000073baab9d2fa8  movaps xmm6, xmm5
000073baab9d2fab  mulpd xmm6, xmm1
000073baab9d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
000073baab9d2fb4  ptest xmm2, xmm2
000073baab9d2fb9  jnz 0x000073BAAB9D5ABF
000073baab9d2fbf  vmovaps xmm5, [rsp+0x10]
000073baab9d2fc5  movaps xmm1, xmm5
000073baab9d2fc8  addpd xmm1, xmm13
000073baab9d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
000073baab9d2fd2  ptest xmm2, xmm2
000073baab9d2fd7  jnz 0x000073BAAB9D5BFF
000073baab9d2fdd  vmovaps xmm13, [rsp+0x80]
000073baab9d2fe6  vpermilpd xmm13, xmm13, 0x00
000073baab9d2fec  vmovaps xmm2, [rsp+0xE0]
000073baab9d2ff5  vmovaps [rsp+0x10], xmm1
000073baab9d2ffb  movaps xmm5, xmm2
000073baab9d2ffe  mulpd xmm5, xmm13
000073baab9d3003  vcmppd xmm1, xmm5, xmm5, 0x03
000073baab9d3008  ptest xmm1, xmm1
000073baab9d300d  jnz 0x000073BAAB9D5D40
000073baab9d3013  vmovaps xmm1, [rsp+0x80]
000073baab9d301c  vpermilpd xmm1, xmm1, 0x00
000073baab9d3022  movaps xmm13, xmm10
000073baab9d3026  mulpd xmm13, xmm1
000073baab9d302b  vcmppd xmm2, xmm13, xmm13, 0x03
000073baab9d3031  ptest xmm2, xmm2
000073baab9d3036  jnz 0x000073BAAB9D5E81
000073baab9d303c  vmovaps xmm10, [rsp+0x20]
000073baab9d3042  movaps xmm1, xmm15
000073baab9d3046  addpd xmm1, xmm10
000073baab9d304b  vcmppd xmm2, xmm1, xmm1, 0x03
000073baab9d3050  ptest xmm2, xmm2
000073baab9d3055  jnz 0x000073BAAB9D5FC4
000073baab9d305b  vmovaps xmm10, [rsp+0xC0]
000073baab9d3064  movaps xmm15, xmm10
000073baab9d3068  addpd xmm15, xmm11
000073baab9d306d  vcmppd xmm2, xmm15, xmm15, 0x03
000073baab9d3073  ptest xmm2, xmm2
000073baab9d3078  jnz 0x000073BAAB9D6106
000073baab9d307e  vmovaps xmm11, [rsp+0x80]
000073baab9d3087  vpermilpd xmm11, xmm11, 0x00
000073baab9d308d  vmovaps xmm2, [rsp+0xD0]
000073baab9d3096  vmovaps [rsp+0x20], xmm1
000073baab9d309c  movaps xmm10, xmm2
000073baab9d30a0  mulpd xmm10, xmm11
000073baab9d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
000073baab9d30ab  ptest xmm1, xmm1
000073baab9d30b0  jnz 0x000073BAAB9D624A
000073baab9d30b6  vmovaps xmm1, [rsp+0x80]
000073baab9d30bf  vpermilpd xmm1, xmm1, 0x00
000073baab9d30c5  vmovaps xmm2, [rsp+0xA0]
000073baab9d30ce  vmovaps [rsp+0x80], xmm15
000073baab9d30d7  movaps xmm11, xmm2
000073baab9d30db  mulpd xmm11, xmm1
000073baab9d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
000073baab9d30e6  ptest xmm15, xmm15
000073baab9d30ec  jnz 0x000073BAAB9D638D
000073baab9d30f2  movaps xmm1, xmm14
000073baab9d30f6  addpd xmm1, xmm6
000073baab9d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
000073baab9d30ff  ptest xmm15, xmm15
000073baab9d3105  jnz 0x000073BAAB9D64CF
000073baab9d310b  vmovaps xmm14, [rsp+0x10]
000073baab9d3111  movaps xmm15, xmm14
000073baab9d3115  addpd xmm15, xmm5
000073baab9d311a  vcmppd xmm6, xmm15, xmm15, 0x03
000073baab9d3120  ptest xmm6, xmm6
000073baab9d3125  jnz 0x000073BAAB9D6610
000073baab9d312b  vmovaps xmm14, [rsp+0x90]
000073baab9d3134  vpermilpd xmm14, xmm14, 0x00
000073baab9d313a  movaps xmm6, xmm9
000073baab9d313e  mulpd xmm6, xmm14
000073baab9d3143  vcmppd xmm5, xmm6, xmm6, 0x03
000073baab9d3148  ptest xmm5, xmm5
000073baab9d314d  jnz 0x000073BAAB9D6753
000073baab9d3153  vmovaps xmm9, [rsp+0x80]
000073baab9d315c  movaps xmm14, xmm9
000073baab9d3160  addpd xmm14, xmm13
000073baab9d3165  vcmppd xmm5, xmm14, xmm14, 0x03
000073baab9d316b  ptest xmm5, xmm5
000073baab9d3170  jnz 0x000073BAAB9D6895
000073baab9d3176  vmovaps xmm9, [rsp+0x20]
000073baab9d317c  movaps xmm13, xmm9
000073baab9d3180  addpd xmm13, xmm10
000073baab9d3185  vcmppd xmm5, xmm13, xmm13, 0x03
000073baab9d318b  ptest xmm5, xmm5
000073baab9d3190  jnz 0x000073BAAB9D69D9
000073baab9d3196  vmovaps [rsp+0x10], xmm12
000073baab9d319c  vmovaps xmm10, [rsp+0x10]
000073baab9d31a2  por xmm12, xmm10
000073baab9d31a7  movaps [r15+0x250], xmm12
000073baab9d31af  vmovaps [rsp+0x10], xmm7
000073baab9d31b5  vmovaps xmm12, [rsp+0x10]
000073baab9d31bb  por xmm7, xmm12
000073baab9d31c0  movaps [r15+0x2A0], xmm7
000073baab9d31c8  vmovaps [rsp+0x10], xmm3
000073baab9d31ce  vmovaps xmm12, [rsp+0x10]
000073baab9d31d4  por xmm3, xmm12
000073baab9d31d9  movaps [r15+0x1D0], xmm3
000073baab9d31e1  lea rax, [r14+0x40]
000073baab9d31e5  movups xmm12, [r13+rax*1]
000073baab9d31eb  movaps [r15+0x2C0], xmm12
000073baab9d31f3  vmovaps xmm10, [rsp+0x90]
000073baab9d31fc  vpermilpd xmm10, xmm10, 0x00
000073baab9d3202  movaps xmm9, xmm8
000073baab9d3206  mulpd xmm9, xmm10
000073baab9d320b  vcmppd xmm5, xmm9, xmm9, 0x03
000073baab9d3211  ptest xmm5, xmm5
000073baab9d3216  jnz 0x000073BAAB9D6B27
000073baab9d321c  movaps xmm10, xmm1
000073baab9d3220  addpd xmm10, xmm11
000073baab9d3225  vcmppd xmm8, xmm10, xmm10, 0x03
000073baab9d322b  ptest xmm8, xmm8
000073baab9d3231  jnz 0x000073BAAB9D6C6B
000073baab9d3237  movaps xmm1, xmm15
000073baab9d323b  addpd xmm1, xmm6
000073baab9d323f  vcmppd xmm11, xmm1, xmm1, 0x03
000073baab9d3244  ptest xmm11, xmm11
000073baab9d324a  jnz 0x000073BAAB9D6DAE
000073baab9d3250  vmovaps xmm15, [rsp+0x90]
000073baab9d3259  vpermilpd xmm15, xmm15, 0x00
000073baab9d325f  movaps xmm11, xmm12
000073baab9d3263  mulpd xmm11, xmm15
000073baab9d3268  vcmppd xmm8, xmm11, xmm11, 0x03
000073baab9d326e  ptest xmm8, xmm8
000073baab9d3274  jnz 0x000073BAAB9D6EEF
000073baab9d327a  vmovaps xmm15, [rsp+0x90]
000073baab9d3283  vpermilpd xmm15, xmm15, 0x00
000073baab9d3289  vmovaps xmm8, [rsp+0x50]
000073baab9d328f  movaps xmm12, xmm8
000073baab9d3293  mulpd xmm12, xmm15
000073baab9d3298  vcmppd xmm6, xmm12, xmm12, 0x03
000073baab9d329e  ptest xmm6, xmm6
000073baab9d32a3  jnz 0x000073BAAB9D7033
000073baab9d32a9  vmovaps xmm15, [rsp+0x30]
000073baab9d32af  vpermilpd xmm15, xmm15, 0x00
000073baab9d32b5  movaps xmm8, xmm7
000073baab9d32b9  mulpd xmm8, xmm15
000073baab9d32be  vcmppd xmm6, xmm8, xmm8, 0x03
000073baab9d32c4  ptest xmm6, xmm6
000073baab9d32c9  jnz 0x000073BAAB9D7177
000073baab9d32cf  movaps xmm15, xmm14
000073baab9d32d3  addpd xmm15, xmm9
000073baab9d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
000073baab9d32de  ptest xmm7, xmm7
000073baab9d32e3  jnz 0x000073BAAB9D72BA
000073baab9d32e9  vmovaps xmm14, [rsp+0x30]
000073baab9d32ef  vpermilpd xmm14, xmm14, 0x00
000073baab9d32f5  vmovaps xmm7, [rsp+0xF0]
000073baab9d32fe  movaps xmm9, xmm7
000073baab9d3302  mulpd xmm9, xmm14
000073baab9d3307  vcmppd xmm6, xmm9, xmm9, 0x03
000073baab9d330d  ptest xmm6, xmm6
000073baab9d3312  jnz 0x000073BAAB9D73FE
000073baab9d3318  movaps xmm14, xmm13
000073baab9d331c  addpd xmm14, xmm11
000073baab9d3321  vcmppd xmm7, xmm14, xmm14, 0x03
000073baab9d3327  ptest xmm7, xmm7
000073baab9d332c  jnz 0x000073BAAB9D7541
000073baab9d3332  vmovaps xmm13, [rsp+0x30]
000073baab9d3338  vpermilpd xmm13, xmm13, 0x00
000073baab9d333e  vmovaps xmm7, [rsp+0x60]
000073baab9d3344  movaps xmm11, xmm7
000073baab9d3348  mulpd xmm11, xmm13
000073baab9d334d  vcmppd xmm6, xmm11, xmm11, 0x03
000073baab9d3353  ptest xmm6, xmm6
000073baab9d3358  jnz 0x000073BAAB9D7685
000073baab9d335e  movaps xmm13, xmm10
000073baab9d3362  addpd xmm13, xmm12
000073baab9d3367  vcmppd xmm7, xmm13, xmm13, 0x03
000073baab9d336d  ptest xmm7, xmm7
000073baab9d3372  jnz 0x000073BAAB9D77C8
000073baab9d3378  vmovaps xmm12, [rsp+0x30]
000073baab9d337e  vpermilpd xmm12, xmm12, 0x00
000073baab9d3384  vmovaps xmm7, [rsp+0x70]
000073baab9d338a  movaps xmm10, xmm7
000073baab9d338e  mulpd xmm10, xmm12
000073baab9d3393  vcmppd xmm6, xmm10, xmm10, 0x03
000073baab9d3399  ptest xmm6, xmm6
000073baab9d339e  jnz 0x000073BAAB9D790C
000073baab9d33a4  movaps xmm12, xmm1
000073baab9d33a8  addpd xmm12, xmm8
000073baab9d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
000073baab9d33b3  ptest xmm7, xmm7
000073baab9d33b8  jnz 0x000073BAAB9D7A4F
000073baab9d33be  lea rax, [r14+0x70]
000073baab9d33c2  movups xmm1, [r13+rax*1]
000073baab9d33c8  movaps [r15+0x240], xmm1
000073baab9d33d0  movaps xmm8, xmm15
000073baab9d33d4  addpd xmm8, xmm9
000073baab9d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
000073baab9d33df  ptest xmm7, xmm7
000073baab9d33e4  jnz 0x000073BAAB9D7B9C
000073baab9d33ea  movaps [r15+0x170], xmm8
000073baab9d33f2  vmovaps xmm15, [rsp+0x40]
000073baab9d33f8  vpermilpd xmm15, xmm15, 0x00
000073baab9d33fe  movaps xmm9, xmm1
000073baab9d3402  mulpd xmm9, xmm15
000073baab9d3407  vcmppd xmm7, xmm9, xmm9, 0x03
000073baab9d340d  ptest xmm7, xmm7
000073baab9d3412  jnz 0x000073BAAB9D7CE0
000073baab9d3418  vmovaps xmm1, [rsp+0x40]
000073baab9d341e  vpermilpd xmm1, xmm1, 0x00
000073baab9d3424  movaps xmm15, xmm4
000073baab9d3428  mulpd xmm15, xmm1
000073baab9d342d  vcmppd xmm7, xmm15, xmm15, 0x03
000073baab9d3433  ptest xmm7, xmm7
000073baab9d3438  jnz 0x000073BAAB9D7E23
000073baab9d343e  movaps [r15+0x180], xmm15
000073baab9d3446  movaps xmm1, xmm14
000073baab9d344a  addpd xmm1, xmm11
000073baab9d344f  vcmppd xmm7, xmm1, xmm1, 0x03
000073baab9d3454  ptest xmm7, xmm7
000073baab9d3459  jnz 0x000073BAAB9D7F65
000073baab9d345f  movaps [r15+0x210], xmm1
000073baab9d3467  movups xmm14, [r13+r14*1]
000073baab9d346d  lea rax, [r14+0x10]
000073baab9d3471  movups xmm11, [r13+rax*1]
000073baab9d3477  movaps [r15+0x230], xmm11
000073baab9d347f  movaps xmm7, xmm13
000073baab9d3483  addpd xmm7, xmm10
000073baab9d3488  vcmppd xmm6, xmm7, xmm7, 0x03
000073baab9d348d  ptest xmm6, xmm6
000073baab9d3492  jnz 0x000073BAAB9D80BB
000073baab9d3498  movaps [r15+0x130], xmm7
000073baab9d34a0  vmovaps xmm13, [rsp+0x40]
000073baab9d34a6  vpermilpd xmm13, xmm13, 0x00
000073baab9d34ac  movaps xmm10, xmm11
000073baab9d34b0  mulpd xmm10, xmm13
000073baab9d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
000073baab9d34bb  ptest xmm6, xmm6
000073baab9d34c0  jnz 0x000073BAAB9D81FD
000073baab9d34c6  movaps [r15+0x220], xmm10
000073baab9d34ce  vmovaps xmm13, [rsp+0x40]
000073baab9d34d4  vpermilpd xmm13, xmm13, 0x00
000073baab9d34da  movaps xmm11, xmm14
000073baab9d34de  mulpd xmm11, xmm13
000073baab9d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
000073baab9d34e9  ptest xmm6, xmm6
000073baab9d34ee  jnz 0x000073BAAB9D8341
000073baab9d34f4  movaps xmm14, xmm12
000073baab9d34f8  addpd xmm14, xmm9
000073baab9d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
000073baab9d3503  ptest xmm13, xmm13
000073baab9d3509  jnz 0x000073BAAB9D8485
000073baab9d350f  movaps [r15+0x140], xmm14
000073baab9d3517  movaps xmm13, xmm8
000073baab9d351b  addpd xmm13, xmm15
000073baab9d3520  vcmppd xmm12, xmm13, xmm13, 0x03
000073baab9d3526  ptest xmm12, xmm12
000073baab9d352c  jnz 0x000073BAAB9D85C9
000073baab9d3532  movaps [r15+0x150], xmm13
000073baab9d353a  movaps xmm15, xmm1
000073baab9d353e  addpd xmm15, xmm10
000073baab9d3543  vcmppd xmm12, xmm15, xmm15, 0x03
000073baab9d3549  ptest xmm12, xmm12
000073baab9d354f  jnz 0x000073BAAB9D870D
000073baab9d3555  movaps [r15+0x160], xmm15
000073baab9d355d  movaps xmm1, xmm7
000073baab9d3560  addpd xmm1, xmm11
000073baab9d3565  vcmppd xmm12, xmm1, xmm1, 0x03
000073baab9d356a  ptest xmm12, xmm12
000073baab9d3570  jnz 0x000073BAAB9D8850
000073baab9d3576  movaps [r15+0x120], xmm1
000073baab9d357e  mov eax, 0x432200
000073baab9d3583  movups [r13+rax*1], xmm14
000073baab9d3589  mov eax, 0x432210
000073baab9d358e  movups [r13+rax*1], xmm13
000073baab9d3594  mov eax, 0x432220
000073baab9d3599  movups [r13+rax*1], xmm15
000073baab9d359f  mov eax, 0x432230
000073baab9d35a4  movups [r13+rax*1], xmm1
000073baab9d35aa  mov eax, [r15+0x108]
000073baab9d35b1  sahf
000073baab9d35b2  jnz 0x000073BAAB9D35E4
000073baab9d35b4  cmp dword ptr [r15+0x318], 0x00
000073baab9d35bc  jz 0x000073BAAB9DEAE0
000073baab9d35c2  nop [rax+rax*1], ax
000073baab9d35cb  nop [rax+rax*1], eax
000073baab9d35d3  mov eax, 0x4106D0
000073baab9d35d8  mov [r15+0x100], rax
000073baab9d35df  jmp 0x000073BAAB7FE110
000073baab9d35e4  cmp dword ptr [r15+0x318], 0x00
000073baab9d35ec  jz 0x000073BAAB9D89C0
000073baab9d35f2  nop [rax+rax*1], ax
000073baab9d35fb  nop [rax+rax*1], eax
000073baab9d3603  mov eax, 0x410504
000073baab9d3608  mov [r15+0x100], rax
000073baab9d360f  jmp 0x000073BAAB7FE110
000073baab9d3614  int3
000073baab9d3615  call 0x000073BAAB8D64F0
000073baab9d361a  jmp 0x000073BAAB9D2311
000073baab9d361f  call 0x000073BAAB8E5820
000073baab9d3624  jmp 0x000073BAAB9D231E
000073baab9d3629  call 0x000073BAAB8E3320
000073baab9d362e  jmp 0x000073BAAB9D2332
000073baab9d3633  call 0x000073BAAB8E20A0
000073baab9d3638  jmp 0x000073BAAB9D233C
000073baab9d363d  call 0x000073BAAB809D70
000073baab9d3642  jmp 0x000073BAAB9D234A
000073baab9d3647  call 0x000073BAAB8DFBC0
000073baab9d364c  jmp 0x000073BAAB9D2354
000073baab9d3651  call 0x000073BAAB8C4740
000073baab9d3656  jmp 0x000073BAAB9D2368
000073baab9d365b  call 0x000073BAAB8B5400
000073baab9d3660  jmp 0x000073BAAB9D2375
000073baab9d3665  call 0x000073BAAB8B52F0
000073baab9d366a  jmp 0x000073BAAB9D2382
000073baab9d366f  call 0x000073BAAB8C4620
000073baab9d3674  jmp 0x000073BAAB9D238F
000073baab9d3679  call 0x000073BAAB8BD750
000073baab9d367e  jmp 0x000073BAAB9D239C
000073baab9d3683  call 0x000073BAAB8BC4E0
000073baab9d3688  jmp 0x000073BAAB9D23A9
000073baab9d368d  call 0x000073BAAB8BB270
000073baab9d3692  jmp 0x000073BAAB9D23B6
000073baab9d3697  call 0x000073BAAB8BA000
000073baab9d369c  jmp 0x000073BAAB9D23C3
000073baab9d36a1  call 0x000073BAAB8C4740
000073baab9d36a6  jmp 0x000073BAAB9D23D0
000073baab9d36ab  call 0x000073BAAB8B5400
000073baab9d36b0  jmp 0x000073BAAB9D23DD
000073baab9d36b5  call 0x000073BAAB8B52F0
000073baab9d36ba  jmp 0x000073BAAB9D23EA
000073baab9d36bf  call 0x000073BAAB8C4620
000073baab9d36c4  jmp 0x000073BAAB9D23F7
000073baab9d36c9  call 0x000073BAAB8B8D90
000073baab9d36ce  jmp 0x000073BAAB9D2404
000073baab9d36d3  call 0x000073BAAB8B8A20
000073baab9d36d8  jmp 0x000073BAAB9D2411
000073baab9d36dd  call 0x000073BAAB8B77B0
000073baab9d36e2  jmp 0x000073BAAB9D241B
000073baab9d36e7  call 0x000073BAAB8B6550
000073baab9d36ec  jmp 0x000073BAAB9D2425
000073baab9d36f1  call 0x000073BAAB8B5400
000073baab9d36f6  jmp 0x000073BAAB9D2437
000073baab9d36fb  call 0x000073BAAB8C0FC0
000073baab9d3700  jmp 0x000073BAAB9D2441
000073baab9d3705  call 0x000073BAAB8B52F0
000073baab9d370a  jmp 0x000073BAAB9D244B
000073baab9d370f  call 0x000073BAAB8C0EA0
000073baab9d3714  jmp 0x000073BAAB9D2455
000073baab9d3719  call 0x000073BAAB8BFD50
000073baab9d371e  jmp 0x000073BAAB9D245F
000073baab9d3723  call 0x000073BAAB8B8EA0
000073baab9d3728  jmp 0x000073BAAB9D2469
000073baab9d372d  call 0x000073BAAB8BFC30
000073baab9d3732  jmp 0x000073BAAB9D2476
000073baab9d3737  call 0x000073BAAB8B8D90
000073baab9d373c  jmp 0x000073BAAB9D2483
000073baab9d3741  call 0x000073BAAB8B52F0
000073baab9d3746  jmp 0x000073BAAB9D2496
000073baab9d374b  call 0x000073BAAB8B52F0
000073baab9d3750  jmp 0x000073BAAB9D24A9
000073baab9d3755  call 0x000073BAAB8C0FC0
000073baab9d375a  jmp 0x000073BAAB9D24B6
000073baab9d375f  call 0x000073BAAB8C0FC0
000073baab9d3764  jmp 0x000073BAAB9D24C9
000073baab9d3769  call 0x000073BAAB8C0EA0
000073baab9d376e  jmp 0x000073BAAB9D24D6
000073baab9d3773  call 0x000073BAAB8B52F0
000073baab9d3778  jmp 0x000073BAAB9D24E9
000073baab9d377d  call 0x000073BAAB8B52F0
000073baab9d3782  jmp 0x000073BAAB9D24FC
000073baab9d3787  call 0x000073BAAB8B52F0
000073baab9d378c  jmp 0x000073BAAB9D250F
000073baab9d3791  call 0x000073BAAB8B52F0
000073baab9d3796  jmp 0x000073BAAB9D252A
000073baab9d379b  call 0x000073BAAB8B52F0
000073baab9d37a0  jmp 0x000073BAAB9D253D
000073baab9d37a5  call 0x000073BAAB8B5400
000073baab9d37aa  jmp 0x000073BAAB9D257E
000073baab9d37af  call 0x000073BAAB8C0FC0
000073baab9d37b4  jmp 0x000073BAAB9D258B
000073baab9d37b9  call 0x000073BAAB8B52F0
000073baab9d37be  jmp 0x000073BAAB9D2598
000073baab9d37c3  call 0x000073BAAB8C0EA0
000073baab9d37c8  jmp 0x000073BAAB9D25A5
000073baab9d37cd  call 0x000073BAAB7FF540
000073baab9d37d2  jmp 0x000073BAAB9D25C3
000073baab9d37d7  call 0x000073BAAB808C20
000073baab9d37dc  jmp 0x000073BAAB9D25CD
000073baab9d37e1  call 0x000073BAAB8E21C0
000073baab9d37e6  jmp 0x000073BAAB9D25D3
000073baab9d37eb  call 0x000073BAAB7FF540
000073baab9d37f0  jmp 0x000073BAAB9D25E3
000073baab9d37f5  call 0x000073BAAB8C0370
000073baab9d37fa  jmp 0x000073BAAB9D2611
000073baab9d37ff  call 0x000073BAAB8BF100
000073baab9d3804  jmp 0x000073BAAB9D261A
000073baab9d3809  call 0x000073BAAB8C0370
000073baab9d380e  jmp 0x000073BAAB9D2674
000073baab9d3813  call 0x000073BAAB8BF100
000073baab9d3818  jmp 0x000073BAAB9D267D
000073baab9d381d  call 0x000073BAAB8C0370
000073baab9d3822  jmp 0x000073BAAB9D26C6
000073baab9d3827  call 0x000073BAAB8BF100
000073baab9d382c  jmp 0x000073BAAB9D26CF
000073baab9d3831  call 0x000073BAAB80B720
000073baab9d3836  jmp 0x000073BAAB9D2714
000073baab9d383b  call 0x000073BAAB8B47C0
000073baab9d3840  jmp 0x000073BAAB9D2727
000073baab9d3845  call 0x000073BAAB808B00
000073baab9d384a  jmp 0x000073BAAB9D273E
000073baab9d384f  call 0x000073BAAB7FF430
000073baab9d3854  jmp 0x000073BAAB9D2751
000073baab9d3859  call 0x000073BAAB7FF430
000073baab9d385e  jmp 0x000073BAAB9D2764
000073baab9d3863  sub rsp, 0x08
000073baab9d3867  push rax
000073baab9d3868  push rcx
000073baab9d3869  push rdx
000073baab9d386a  push rdi
000073baab9d386b  push rsi
000073baab9d386c  push r8
000073baab9d386e  push r9
000073baab9d3870  push r10
000073baab9d3872  push r11
000073baab9d3874  sub rsp, 0xF0
000073baab9d387b  vmovaps [rsp], xmm0
000073baab9d3880  vmovaps [rsp+0x10], xmm2
000073baab9d3886  vmovaps [rsp+0x20], xmm3
000073baab9d388c  vmovaps [rsp+0x30], xmm4
000073baab9d3892  vmovaps [rsp+0x40], xmm5
000073baab9d3898  vmovaps [rsp+0x50], xmm6
000073baab9d389e  vmovaps [rsp+0x60], xmm7
000073baab9d38a4  vmovaps [rsp+0x70], xmm8
000073baab9d38aa  vmovaps [rsp+0x80], xmm9
000073baab9d38b3  vmovaps [rsp+0x90], xmm10
000073baab9d38bc  vmovaps [rsp+0xA0], xmm11
000073baab9d38c5  vmovaps [rsp+0xB0], xmm12
000073baab9d38ce  vmovaps [rsp+0xC0], xmm13
000073baab9d38d7  vmovaps [rsp+0xD0], xmm14
000073baab9d38e0  vmovaps [rsp+0xE0], xmm15
000073baab9d38e9  sub rsp, 0x30
000073baab9d38ed  movaps [rsp], xmm1
000073baab9d38f1  movaps [rsp+0x10], xmm12
000073baab9d38f7  movaps [rsp+0x20], xmm15
000073baab9d38fd  lea rdi, [rsp]
000073baab9d3901  mov esi, 0x00
000073baab9d3906  mov rax, 0x5F3F1062D530
000073baab9d3910  call rax
000073baab9d3912  movaps xmm1, [rsp]
000073baab9d3916  add rsp, 0x30
000073baab9d391a  vmovaps xmm0, [rsp]
000073baab9d391f  vmovaps xmm2, [rsp+0x10]
000073baab9d3925  vmovaps xmm3, [rsp+0x20]
000073baab9d392b  vmovaps xmm4, [rsp+0x30]
000073baab9d3931  vmovaps xmm5, [rsp+0x40]
000073baab9d3937  vmovaps xmm6, [rsp+0x50]
000073baab9d393d  vmovaps xmm7, [rsp+0x60]
000073baab9d3943  vmovaps xmm8, [rsp+0x70]
000073baab9d3949  vmovaps xmm9, [rsp+0x80]
000073baab9d3952  vmovaps xmm10, [rsp+0x90]
000073baab9d395b  vmovaps xmm11, [rsp+0xA0]
000073baab9d3964  vmovaps xmm12, [rsp+0xB0]
000073baab9d396d  vmovaps xmm13, [rsp+0xC0]
000073baab9d3976  vmovaps xmm14, [rsp+0xD0]
000073baab9d397f  vmovaps xmm15, [rsp+0xE0]
000073baab9d3988  add rsp, 0xF0
000073baab9d398f  pop r11
000073baab9d3991  pop r10
000073baab9d3993  pop r9
000073baab9d3995  pop r8
000073baab9d3997  pop rsi
000073baab9d3998  pop rdi
000073baab9d3999  pop rdx
000073baab9d399a  pop rcx
000073baab9d399b  pop rax
000073baab9d399c  add rsp, 0x08
000073baab9d39a0  jmp 0x000073BAAB9D27B2
000073baab9d39a5  sub rsp, 0x08
000073baab9d39a9  push rax
000073baab9d39aa  push rcx
000073baab9d39ab  push rdx
000073baab9d39ac  push rdi
000073baab9d39ad  push rsi
000073baab9d39ae  push r8
000073baab9d39b0  push r9
000073baab9d39b2  push r10
000073baab9d39b4  push r11
000073baab9d39b6  sub rsp, 0xF0
000073baab9d39bd  vmovaps [rsp], xmm0
000073baab9d39c2  vmovaps [rsp+0x10], xmm1
000073baab9d39c8  vmovaps [rsp+0x20], xmm2
000073baab9d39ce  vmovaps [rsp+0x30], xmm3
000073baab9d39d4  vmovaps [rsp+0x40], xmm4
000073baab9d39da  vmovaps [rsp+0x50], xmm5
000073baab9d39e0  vmovaps [rsp+0x60], xmm6
000073baab9d39e6  vmovaps [rsp+0x70], xmm7
000073baab9d39ec  vmovaps [rsp+0x80], xmm8
000073baab9d39f5  vmovaps [rsp+0x90], xmm9
000073baab9d39fe  vmovaps [rsp+0xA0], xmm10
000073baab9d3a07  vmovaps [rsp+0xB0], xmm11
000073baab9d3a10  vmovaps [rsp+0xC0], xmm12
000073baab9d3a19  vmovaps [rsp+0xD0], xmm13
000073baab9d3a22  vmovaps [rsp+0xE0], xmm15
000073baab9d3a2b  sub rsp, 0x30
000073baab9d3a2f  movaps [rsp], xmm14
000073baab9d3a34  movaps [rsp+0x10], xmm1
000073baab9d3a39  movaps [rsp+0x20], xmm15
000073baab9d3a3f  lea rdi, [rsp]
000073baab9d3a43  mov esi, 0x00
000073baab9d3a48  mov rax, 0x5F3F1062D530
000073baab9d3a52  call rax
000073baab9d3a54  movaps xmm14, [rsp]
000073baab9d3a59  add rsp, 0x30
000073baab9d3a5d  vmovaps xmm0, [rsp]
000073baab9d3a62  vmovaps xmm1, [rsp+0x10]
000073baab9d3a68  vmovaps xmm2, [rsp+0x20]
000073baab9d3a6e  vmovaps xmm3, [rsp+0x30]
000073baab9d3a74  vmovaps xmm4, [rsp+0x40]
000073baab9d3a7a  vmovaps xmm5, [rsp+0x50]
000073baab9d3a80  vmovaps xmm6, [rsp+0x60]
000073baab9d3a86  vmovaps xmm7, [rsp+0x70]
000073baab9d3a8c  vmovaps xmm8, [rsp+0x80]
000073baab9d3a95  vmovaps xmm9, [rsp+0x90]
000073baab9d3a9e  vmovaps xmm10, [rsp+0xA0]
000073baab9d3aa7  vmovaps xmm11, [rsp+0xB0]
000073baab9d3ab0  vmovaps xmm12, [rsp+0xC0]
000073baab9d3ab9  vmovaps xmm13, [rsp+0xD0]
000073baab9d3ac2  vmovaps xmm15, [rsp+0xE0]
000073baab9d3acb  add rsp, 0xF0
000073baab9d3ad2  pop r11
000073baab9d3ad4  pop r10
000073baab9d3ad6  pop r9
000073baab9d3ad8  pop r8
000073baab9d3ada  pop rsi
000073baab9d3adb  pop rdi
000073baab9d3adc  pop rdx
000073baab9d3add  pop rcx
000073baab9d3ade  pop rax
000073baab9d3adf  add rsp, 0x08
000073baab9d3ae3  jmp 0x000073BAAB9D2800
000073baab9d3ae8  sub rsp, 0x08
000073baab9d3aec  push rax
000073baab9d3aed  push rcx
000073baab9d3aee  push rdx
000073baab9d3aef  push rdi
000073baab9d3af0  push rsi
000073baab9d3af1  push r8
000073baab9d3af3  push r9
000073baab9d3af5  push r10
000073baab9d3af7  push r11
000073baab9d3af9  sub rsp, 0xF0
000073baab9d3b00  vmovaps [rsp], xmm0
000073baab9d3b05  vmovaps [rsp+0x10], xmm1
000073baab9d3b0b  vmovaps [rsp+0x20], xmm2
000073baab9d3b11  vmovaps [rsp+0x30], xmm3
000073baab9d3b17  vmovaps [rsp+0x40], xmm4
000073baab9d3b1d  vmovaps [rsp+0x50], xmm5
000073baab9d3b23  vmovaps [rsp+0x60], xmm6
000073baab9d3b29  vmovaps [rsp+0x70], xmm7
000073baab9d3b2f  vmovaps [rsp+0x80], xmm8
000073baab9d3b38  vmovaps [rsp+0x90], xmm9
000073baab9d3b41  vmovaps [rsp+0xA0], xmm10
000073baab9d3b4a  vmovaps [rsp+0xB0], xmm11
000073baab9d3b53  vmovaps [rsp+0xC0], xmm12
000073baab9d3b5c  vmovaps [rsp+0xD0], xmm13
000073baab9d3b65  vmovaps [rsp+0xE0], xmm14
000073baab9d3b6e  sub rsp, 0x30
000073baab9d3b72  movaps [rsp], xmm15
000073baab9d3b77  movaps [rsp+0x10], xmm12
000073baab9d3b7d  movaps [rsp+0x20], xmm13
000073baab9d3b83  lea rdi, [rsp]
000073baab9d3b87  mov esi, 0x00
000073baab9d3b8c  mov rax, 0x5F3F1062D530
000073baab9d3b96  call rax
000073baab9d3b98  movaps xmm15, [rsp]
000073baab9d3b9d  add rsp, 0x30
000073baab9d3ba1  vmovaps xmm0, [rsp]
000073baab9d3ba6  vmovaps xmm1, [rsp+0x10]
000073baab9d3bac  vmovaps xmm2, [rsp+0x20]
000073baab9d3bb2  vmovaps xmm3, [rsp+0x30]
000073baab9d3bb8  vmovaps xmm4, [rsp+0x40]
000073baab9d3bbe  vmovaps xmm5, [rsp+0x50]
000073baab9d3bc4  vmovaps xmm6, [rsp+0x60]
000073baab9d3bca  vmovaps xmm7, [rsp+0x70]
000073baab9d3bd0  vmovaps xmm8, [rsp+0x80]
000073baab9d3bd9  vmovaps xmm9, [rsp+0x90]
000073baab9d3be2  vmovaps xmm10, [rsp+0xA0]
000073baab9d3beb  vmovaps xmm11, [rsp+0xB0]
000073baab9d3bf4  vmovaps xmm12, [rsp+0xC0]
000073baab9d3bfd  vmovaps xmm13, [rsp+0xD0]
000073baab9d3c06  vmovaps xmm14, [rsp+0xE0]
000073baab9d3c0f  add rsp, 0xF0
000073baab9d3c16  pop r11
000073baab9d3c18  pop r10
000073baab9d3c1a  pop r9
000073baab9d3c1c  pop r8
000073baab9d3c1e  pop rsi
000073baab9d3c1f  pop rdi
000073baab9d3c20  pop rdx
000073baab9d3c21  pop rcx
000073baab9d3c22  pop rax
000073baab9d3c23  add rsp, 0x08
000073baab9d3c27  jmp 0x000073BAAB9D2835
000073baab9d3c2c  sub rsp, 0x08
000073baab9d3c30  push rax
000073baab9d3c31  push rcx
000073baab9d3c32  push rdx
000073baab9d3c33  push rdi
000073baab9d3c34  push rsi
000073baab9d3c35  push r8
000073baab9d3c37  push r9
000073baab9d3c39  push r10
000073baab9d3c3b  push r11
000073baab9d3c3d  sub rsp, 0xF0
000073baab9d3c44  vmovaps [rsp], xmm0
000073baab9d3c49  vmovaps [rsp+0x10], xmm2
000073baab9d3c4f  vmovaps [rsp+0x20], xmm3
000073baab9d3c55  vmovaps [rsp+0x30], xmm4
000073baab9d3c5b  vmovaps [rsp+0x40], xmm5
000073baab9d3c61  vmovaps [rsp+0x50], xmm6
000073baab9d3c67  vmovaps [rsp+0x60], xmm7
000073baab9d3c6d  vmovaps [rsp+0x70], xmm8
000073baab9d3c73  vmovaps [rsp+0x80], xmm9
000073baab9d3c7c  vmovaps [rsp+0x90], xmm10
000073baab9d3c85  vmovaps [rsp+0xA0], xmm11
000073baab9d3c8e  vmovaps [rsp+0xB0], xmm12
000073baab9d3c97  vmovaps [rsp+0xC0], xmm13
000073baab9d3ca0  vmovaps [rsp+0xD0], xmm14
000073baab9d3ca9  vmovaps [rsp+0xE0], xmm15
000073baab9d3cb2  sub rsp, 0x30
000073baab9d3cb6  movaps [rsp], xmm1
000073baab9d3cba  movaps [rsp+0x10], xmm12
000073baab9d3cc0  movaps [rsp+0x20], xmm10
000073baab9d3cc6  lea rdi, [rsp]
000073baab9d3cca  mov esi, 0x00
000073baab9d3ccf  mov rax, 0x5F3F1062D530
000073baab9d3cd9  call rax
000073baab9d3cdb  movaps xmm1, [rsp]
000073baab9d3cdf  add rsp, 0x30
000073baab9d3ce3  vmovaps xmm0, [rsp]
000073baab9d3ce8  vmovaps xmm2, [rsp+0x10]
000073baab9d3cee  vmovaps xmm3, [rsp+0x20]
000073baab9d3cf4  vmovaps xmm4, [rsp+0x30]
000073baab9d3cfa  vmovaps xmm5, [rsp+0x40]
000073baab9d3d00  vmovaps xmm6, [rsp+0x50]
000073baab9d3d06  vmovaps xmm7, [rsp+0x60]
000073baab9d3d0c  vmovaps xmm8, [rsp+0x70]
000073baab9d3d12  vmovaps xmm9, [rsp+0x80]
000073baab9d3d1b  vmovaps xmm10, [rsp+0x90]
000073baab9d3d24  vmovaps xmm11, [rsp+0xA0]
000073baab9d3d2d  vmovaps xmm12, [rsp+0xB0]
000073baab9d3d36  vmovaps xmm13, [rsp+0xC0]
000073baab9d3d3f  vmovaps xmm14, [rsp+0xD0]
000073baab9d3d48  vmovaps xmm15, [rsp+0xE0]
000073baab9d3d51  add rsp, 0xF0
000073baab9d3d58  pop r11
000073baab9d3d5a  pop r10
000073baab9d3d5c  pop r9
000073baab9d3d5e  pop r8
000073baab9d3d60  pop rsi
000073baab9d3d61  pop rdi
000073baab9d3d62  pop rdx
000073baab9d3d63  pop rcx
000073baab9d3d64  pop rax
000073baab9d3d65  add rsp, 0x08
000073baab9d3d69  jmp 0x000073BAAB9D284F
000073baab9d3d6e  sub rsp, 0x08
000073baab9d3d72  push rax
000073baab9d3d73  push rcx
000073baab9d3d74  push rdx
000073baab9d3d75  push rdi
000073baab9d3d76  push rsi
000073baab9d3d77  push r8
000073baab9d3d79  push r9
000073baab9d3d7b  push r10
000073baab9d3d7d  push r11
000073baab9d3d7f  sub rsp, 0xF0
000073baab9d3d86  vmovaps [rsp], xmm0
000073baab9d3d8b  vmovaps [rsp+0x10], xmm1
000073baab9d3d91  vmovaps [rsp+0x20], xmm2
000073baab9d3d97  vmovaps [rsp+0x30], xmm3
000073baab9d3d9d  vmovaps [rsp+0x40], xmm4
000073baab9d3da3  vmovaps [rsp+0x50], xmm5
000073baab9d3da9  vmovaps [rsp+0x60], xmm6
000073baab9d3daf  vmovaps [rsp+0x70], xmm7
000073baab9d3db5  vmovaps [rsp+0x80], xmm8
000073baab9d3dbe  vmovaps [rsp+0x90], xmm9
000073baab9d3dc7  vmovaps [rsp+0xA0], xmm10
000073baab9d3dd0  vmovaps [rsp+0xB0], xmm11
000073baab9d3dd9  vmovaps [rsp+0xC0], xmm12
000073baab9d3de2  vmovaps [rsp+0xD0], xmm14
000073baab9d3deb  vmovaps [rsp+0xE0], xmm15
000073baab9d3df4  sub rsp, 0x30
000073baab9d3df8  movaps [rsp], xmm13
000073baab9d3dfd  movaps [rsp+0x10], xmm12
000073baab9d3e03  movaps [rsp+0x20], xmm2
000073baab9d3e08  lea rdi, [rsp]
000073baab9d3e0c  mov esi, 0x00
000073baab9d3e11  mov rax, 0x5F3F1062D530
000073baab9d3e1b  call rax
000073baab9d3e1d  movaps xmm13, [rsp]
000073baab9d3e22  add rsp, 0x30
000073baab9d3e26  vmovaps xmm0, [rsp]
000073baab9d3e2b  vmovaps xmm1, [rsp+0x10]
000073baab9d3e31  vmovaps xmm2, [rsp+0x20]
000073baab9d3e37  vmovaps xmm3, [rsp+0x30]
000073baab9d3e3d  vmovaps xmm4, [rsp+0x40]
000073baab9d3e43  vmovaps xmm5, [rsp+0x50]
000073baab9d3e49  vmovaps xmm6, [rsp+0x60]
000073baab9d3e4f  vmovaps xmm7, [rsp+0x70]
000073baab9d3e55  vmovaps xmm8, [rsp+0x80]
000073baab9d3e5e  vmovaps xmm9, [rsp+0x90]
000073baab9d3e67  vmovaps xmm10, [rsp+0xA0]
000073baab9d3e70  vmovaps xmm11, [rsp+0xB0]
000073baab9d3e79  vmovaps xmm12, [rsp+0xC0]
000073baab9d3e82  vmovaps xmm14, [rsp+0xD0]
000073baab9d3e8b  vmovaps xmm15, [rsp+0xE0]
000073baab9d3e94  add rsp, 0xF0
000073baab9d3e9b  pop r11
000073baab9d3e9d  pop r10
000073baab9d3e9f  pop r9
000073baab9d3ea1  pop r8
000073baab9d3ea3  pop rsi
000073baab9d3ea4  pop rdi
000073baab9d3ea5  pop rdx
000073baab9d3ea6  pop rcx
000073baab9d3ea7  pop rax
000073baab9d3ea8  add rsp, 0x08
000073baab9d3eac  jmp 0x000073BAAB9D286A
000073baab9d3eb1  sub rsp, 0x08
000073baab9d3eb5  push rax
000073baab9d3eb6  push rcx
000073baab9d3eb7  push rdx
000073baab9d3eb8  push rdi
000073baab9d3eb9  push rsi
000073baab9d3eba  push r8
000073baab9d3ebc  push r9
000073baab9d3ebe  push r10
000073baab9d3ec0  push r11
000073baab9d3ec2  sub rsp, 0xF0
000073baab9d3ec9  vmovaps [rsp], xmm0
000073baab9d3ece  vmovaps [rsp+0x10], xmm2
000073baab9d3ed4  vmovaps [rsp+0x20], xmm3
000073baab9d3eda  vmovaps [rsp+0x30], xmm4
000073baab9d3ee0  vmovaps [rsp+0x40], xmm5
000073baab9d3ee6  vmovaps [rsp+0x50], xmm6
000073baab9d3eec  vmovaps [rsp+0x60], xmm7
000073baab9d3ef2  vmovaps [rsp+0x70], xmm8
000073baab9d3ef8  vmovaps [rsp+0x80], xmm9
000073baab9d3f01  vmovaps [rsp+0x90], xmm10
000073baab9d3f0a  vmovaps [rsp+0xA0], xmm11
000073baab9d3f13  vmovaps [rsp+0xB0], xmm12
000073baab9d3f1c  vmovaps [rsp+0xC0], xmm13
000073baab9d3f25  vmovaps [rsp+0xD0], xmm14
000073baab9d3f2e  vmovaps [rsp+0xE0], xmm15
000073baab9d3f37  sub rsp, 0x30
000073baab9d3f3b  movaps [rsp], xmm1
000073baab9d3f3f  movaps [rsp+0x10], xmm10
000073baab9d3f45  movaps [rsp+0x20], xmm2
000073baab9d3f4a  lea rdi, [rsp]
000073baab9d3f4e  mov esi, 0x00
000073baab9d3f53  mov rax, 0x5F3F1062D530
000073baab9d3f5d  call rax
000073baab9d3f5f  movaps xmm1, [rsp]
000073baab9d3f63  add rsp, 0x30
000073baab9d3f67  vmovaps xmm0, [rsp]
000073baab9d3f6c  vmovaps xmm2, [rsp+0x10]
000073baab9d3f72  vmovaps xmm3, [rsp+0x20]
000073baab9d3f78  vmovaps xmm4, [rsp+0x30]
000073baab9d3f7e  vmovaps xmm5, [rsp+0x40]
000073baab9d3f84  vmovaps xmm6, [rsp+0x50]
000073baab9d3f8a  vmovaps xmm7, [rsp+0x60]
000073baab9d3f90  vmovaps xmm8, [rsp+0x70]
000073baab9d3f96  vmovaps xmm9, [rsp+0x80]
000073baab9d3f9f  vmovaps xmm10, [rsp+0x90]
000073baab9d3fa8  vmovaps xmm11, [rsp+0xA0]
000073baab9d3fb1  vmovaps xmm12, [rsp+0xB0]
000073baab9d3fba  vmovaps xmm13, [rsp+0xC0]
000073baab9d3fc3  vmovaps xmm14, [rsp+0xD0]
000073baab9d3fcc  vmovaps xmm15, [rsp+0xE0]
000073baab9d3fd5  add rsp, 0xF0
000073baab9d3fdc  pop r11
000073baab9d3fde  pop r10
000073baab9d3fe0  pop r9
000073baab9d3fe2  pop r8
000073baab9d3fe4  pop rsi
000073baab9d3fe5  pop rdi
000073baab9d3fe6  pop rdx
000073baab9d3fe7  pop rcx
000073baab9d3fe8  pop rax
000073baab9d3fe9  add rsp, 0x08
000073baab9d3fed  jmp 0x000073BAAB9D28D2
000073baab9d3ff2  sub rsp, 0x08
000073baab9d3ff6  push rax
000073baab9d3ff7  push rcx
000073baab9d3ff8  push rdx
000073baab9d3ff9  push rdi
000073baab9d3ffa  push rsi
000073baab9d3ffb  push r8
000073baab9d3ffd  push r9
000073baab9d3fff  push r10
000073baab9d4001  push r11
000073baab9d4003  sub rsp, 0xF0
000073baab9d400a  vmovaps [rsp], xmm0
000073baab9d400f  vmovaps [rsp+0x10], xmm1
000073baab9d4015  vmovaps [rsp+0x20], xmm2
000073baab9d401b  vmovaps [rsp+0x30], xmm3
000073baab9d4021  vmovaps [rsp+0x40], xmm4
000073baab9d4027  vmovaps [rsp+0x50], xmm5
000073baab9d402d  vmovaps [rsp+0x60], xmm6
000073baab9d4033  vmovaps [rsp+0x70], xmm7
000073baab9d4039  vmovaps [rsp+0x80], xmm8
000073baab9d4042  vmovaps [rsp+0x90], xmm9
000073baab9d404b  vmovaps [rsp+0xA0], xmm10
000073baab9d4054  vmovaps [rsp+0xB0], xmm11
000073baab9d405d  vmovaps [rsp+0xC0], xmm12
000073baab9d4066  vmovaps [rsp+0xD0], xmm13
000073baab9d406f  vmovaps [rsp+0xE0], xmm14
000073baab9d4078  sub rsp, 0x30
000073baab9d407c  movaps [rsp], xmm15
000073baab9d4081  movaps [rsp+0x10], xmm10
000073baab9d4087  movaps [rsp+0x20], xmm2
000073baab9d408c  lea rdi, [rsp]
000073baab9d4090  mov esi, 0x00
000073baab9d4095  mov rax, 0x5F3F1062D530
000073baab9d409f  call rax
000073baab9d40a1  movaps xmm15, [rsp]
000073baab9d40a6  add rsp, 0x30
000073baab9d40aa  vmovaps xmm0, [rsp]
000073baab9d40af  vmovaps xmm1, [rsp+0x10]
000073baab9d40b5  vmovaps xmm2, [rsp+0x20]
000073baab9d40bb  vmovaps xmm3, [rsp+0x30]
000073baab9d40c1  vmovaps xmm4, [rsp+0x40]
000073baab9d40c7  vmovaps xmm5, [rsp+0x50]
000073baab9d40cd  vmovaps xmm6, [rsp+0x60]
000073baab9d40d3  vmovaps xmm7, [rsp+0x70]
000073baab9d40d9  vmovaps xmm8, [rsp+0x80]
000073baab9d40e2  vmovaps xmm9, [rsp+0x90]
000073baab9d40eb  vmovaps xmm10, [rsp+0xA0]
000073baab9d40f4  vmovaps xmm11, [rsp+0xB0]
000073baab9d40fd  vmovaps xmm12, [rsp+0xC0]
000073baab9d4106  vmovaps xmm13, [rsp+0xD0]
000073baab9d410f  vmovaps xmm14, [rsp+0xE0]
000073baab9d4118  add rsp, 0xF0
000073baab9d411f  pop r11
000073baab9d4121  pop r10
000073baab9d4123  pop r9
000073baab9d4125  pop r8
000073baab9d4127  pop rsi
000073baab9d4128  pop rdi
000073baab9d4129  pop rdx
000073baab9d412a  pop rcx
000073baab9d412b  pop rax
000073baab9d412c  add rsp, 0x08
000073baab9d4130  jmp 0x000073BAAB9D2924
000073baab9d4135  sub rsp, 0x08
000073baab9d4139  push rax
000073baab9d413a  push rcx
000073baab9d413b  push rdx
000073baab9d413c  push rdi
000073baab9d413d  push rsi
000073baab9d413e  push r8
000073baab9d4140  push r9
000073baab9d4142  push r10
000073baab9d4144  push r11
000073baab9d4146  sub rsp, 0xF0
000073baab9d414d  vmovaps [rsp], xmm0
000073baab9d4152  vmovaps [rsp+0x10], xmm2
000073baab9d4158  vmovaps [rsp+0x20], xmm3
000073baab9d415e  vmovaps [rsp+0x30], xmm4
000073baab9d4164  vmovaps [rsp+0x40], xmm5
000073baab9d416a  vmovaps [rsp+0x50], xmm6
000073baab9d4170  vmovaps [rsp+0x60], xmm7
000073baab9d4176  vmovaps [rsp+0x70], xmm8
000073baab9d417c  vmovaps [rsp+0x80], xmm9
000073baab9d4185  vmovaps [rsp+0x90], xmm10
000073baab9d418e  vmovaps [rsp+0xA0], xmm11
000073baab9d4197  vmovaps [rsp+0xB0], xmm12
000073baab9d41a0  vmovaps [rsp+0xC0], xmm13
000073baab9d41a9  vmovaps [rsp+0xD0], xmm14
000073baab9d41b2  vmovaps [rsp+0xE0], xmm15
000073baab9d41bb  sub rsp, 0x30
000073baab9d41bf  movaps [rsp], xmm1
000073baab9d41c3  movaps [rsp+0x10], xmm10
000073baab9d41c9  movaps [rsp+0x20], xmm15
000073baab9d41cf  lea rdi, [rsp]
000073baab9d41d3  mov esi, 0x00
000073baab9d41d8  mov rax, 0x5F3F1062D530
000073baab9d41e2  call rax
000073baab9d41e4  movaps xmm1, [rsp]
000073baab9d41e8  add rsp, 0x30
000073baab9d41ec  vmovaps xmm0, [rsp]
000073baab9d41f1  vmovaps xmm2, [rsp+0x10]
000073baab9d41f7  vmovaps xmm3, [rsp+0x20]
000073baab9d41fd  vmovaps xmm4, [rsp+0x30]
000073baab9d4203  vmovaps xmm5, [rsp+0x40]
000073baab9d4209  vmovaps xmm6, [rsp+0x50]
000073baab9d420f  vmovaps xmm7, [rsp+0x60]
000073baab9d4215  vmovaps xmm8, [rsp+0x70]
000073baab9d421b  vmovaps xmm9, [rsp+0x80]
000073baab9d4224  vmovaps xmm10, [rsp+0x90]
000073baab9d422d  vmovaps xmm11, [rsp+0xA0]
000073baab9d4236  vmovaps xmm12, [rsp+0xB0]
000073baab9d423f  vmovaps xmm13, [rsp+0xC0]
000073baab9d4248  vmovaps xmm14, [rsp+0xD0]
000073baab9d4251  vmovaps xmm15, [rsp+0xE0]
000073baab9d425a  add rsp, 0xF0
000073baab9d4261  pop r11
000073baab9d4263  pop r10
000073baab9d4265  pop r9
000073baab9d4267  pop r8
000073baab9d4269  pop rsi
000073baab9d426a  pop rdi
000073baab9d426b  pop rdx
000073baab9d426c  pop rcx
000073baab9d426d  pop rax
000073baab9d426e  add rsp, 0x08
000073baab9d4272  jmp 0x000073BAAB9D2962
000073baab9d4277  sub rsp, 0x08
000073baab9d427b  push rax
000073baab9d427c  push rcx
000073baab9d427d  push rdx
000073baab9d427e  push rdi
000073baab9d427f  push rsi
000073baab9d4280  push r8
000073baab9d4282  push r9
000073baab9d4284  push r10
000073baab9d4286  push r11
000073baab9d4288  sub rsp, 0xF0
000073baab9d428f  vmovaps [rsp], xmm0
000073baab9d4294  vmovaps [rsp+0x10], xmm1
000073baab9d429a  vmovaps [rsp+0x20], xmm2
000073baab9d42a0  vmovaps [rsp+0x30], xmm3
000073baab9d42a6  vmovaps [rsp+0x40], xmm4
000073baab9d42ac  vmovaps [rsp+0x50], xmm5
000073baab9d42b2  vmovaps [rsp+0x60], xmm6
000073baab9d42b8  vmovaps [rsp+0x70], xmm7
000073baab9d42be  vmovaps [rsp+0x80], xmm8
000073baab9d42c7  vmovaps [rsp+0x90], xmm9
000073baab9d42d0  vmovaps [rsp+0xA0], xmm10
000073baab9d42d9  vmovaps [rsp+0xB0], xmm11
000073baab9d42e2  vmovaps [rsp+0xC0], xmm12
000073baab9d42eb  vmovaps [rsp+0xD0], xmm13
000073baab9d42f4  vmovaps [rsp+0xE0], xmm15
000073baab9d42fd  sub rsp, 0x30
000073baab9d4301  movaps [rsp], xmm14
000073baab9d4306  movaps [rsp+0x10], xmm10
000073baab9d430c  movaps [rsp+0x20], xmm15
000073baab9d4312  lea rdi, [rsp]
000073baab9d4316  mov esi, 0x00
000073baab9d431b  mov rax, 0x5F3F1062D530
000073baab9d4325  call rax
000073baab9d4327  movaps xmm14, [rsp]
000073baab9d432c  add rsp, 0x30
000073baab9d4330  vmovaps xmm0, [rsp]
000073baab9d4335  vmovaps xmm1, [rsp+0x10]
000073baab9d433b  vmovaps xmm2, [rsp+0x20]
000073baab9d4341  vmovaps xmm3, [rsp+0x30]
000073baab9d4347  vmovaps xmm4, [rsp+0x40]
000073baab9d434d  vmovaps xmm5, [rsp+0x50]
000073baab9d4353  vmovaps xmm6, [rsp+0x60]
000073baab9d4359  vmovaps xmm7, [rsp+0x70]
000073baab9d435f  vmovaps xmm8, [rsp+0x80]
000073baab9d4368  vmovaps xmm9, [rsp+0x90]
000073baab9d4371  vmovaps xmm10, [rsp+0xA0]
000073baab9d437a  vmovaps xmm11, [rsp+0xB0]
000073baab9d4383  vmovaps xmm12, [rsp+0xC0]
000073baab9d438c  vmovaps xmm13, [rsp+0xD0]
000073baab9d4395  vmovaps xmm15, [rsp+0xE0]
000073baab9d439e  add rsp, 0xF0
000073baab9d43a5  pop r11
000073baab9d43a7  pop r10
000073baab9d43a9  pop r9
000073baab9d43ab  pop r8
000073baab9d43ad  pop rsi
000073baab9d43ae  pop rdi
000073baab9d43af  pop rdx
000073baab9d43b0  pop rcx
000073baab9d43b1  pop rax
000073baab9d43b2  add rsp, 0x08
000073baab9d43b6  jmp 0x000073BAAB9D298E
000073baab9d43bb  call 0x000073BAAB7FF430
000073baab9d43c0  jmp 0x000073BAAB9D2A1E
000073baab9d43c5  call 0x000073BAAB7FF430
000073baab9d43ca  jmp 0x000073BAAB9D2A31
000073baab9d43cf  sub rsp, 0x08
000073baab9d43d3  push rax
000073baab9d43d4  push rcx
000073baab9d43d5  push rdx
000073baab9d43d6  push rdi
000073baab9d43d7  push rsi
000073baab9d43d8  push r8
000073baab9d43da  push r9
000073baab9d43dc  push r10
000073baab9d43de  push r11
000073baab9d43e0  sub rsp, 0xF0
000073baab9d43e7  vmovaps [rsp], xmm0
000073baab9d43ec  vmovaps [rsp+0x10], xmm2
000073baab9d43f2  vmovaps [rsp+0x20], xmm3
000073baab9d43f8  vmovaps [rsp+0x30], xmm4
000073baab9d43fe  vmovaps [rsp+0x40], xmm5
000073baab9d4404  vmovaps [rsp+0x50], xmm6
000073baab9d440a  vmovaps [rsp+0x60], xmm7
000073baab9d4410  vmovaps [rsp+0x70], xmm8
000073baab9d4416  vmovaps [rsp+0x80], xmm9
000073baab9d441f  vmovaps [rsp+0x90], xmm10
000073baab9d4428  vmovaps [rsp+0xA0], xmm11
000073baab9d4431  vmovaps [rsp+0xB0], xmm12
000073baab9d443a  vmovaps [rsp+0xC0], xmm13
000073baab9d4443  vmovaps [rsp+0xD0], xmm14
000073baab9d444c  vmovaps [rsp+0xE0], xmm15
000073baab9d4455  sub rsp, 0x30
000073baab9d4459  movaps [rsp], xmm1
000073baab9d445d  movaps [rsp+0x10], xmm13
000073baab9d4463  movaps [rsp+0x20], xmm2
000073baab9d4468  lea rdi, [rsp]
000073baab9d446c  mov esi, 0x00
000073baab9d4471  mov rax, 0x5F3F1062D530
000073baab9d447b  call rax
000073baab9d447d  movaps xmm1, [rsp]
000073baab9d4481  add rsp, 0x30
000073baab9d4485  vmovaps xmm0, [rsp]
000073baab9d448a  vmovaps xmm2, [rsp+0x10]
000073baab9d4490  vmovaps xmm3, [rsp+0x20]
000073baab9d4496  vmovaps xmm4, [rsp+0x30]
000073baab9d449c  vmovaps xmm5, [rsp+0x40]
000073baab9d44a2  vmovaps xmm6, [rsp+0x50]
000073baab9d44a8  vmovaps xmm7, [rsp+0x60]
000073baab9d44ae  vmovaps xmm8, [rsp+0x70]
000073baab9d44b4  vmovaps xmm9, [rsp+0x80]
000073baab9d44bd  vmovaps xmm10, [rsp+0x90]
000073baab9d44c6  vmovaps xmm11, [rsp+0xA0]
000073baab9d44cf  vmovaps xmm12, [rsp+0xB0]
000073baab9d44d8  vmovaps xmm13, [rsp+0xC0]
000073baab9d44e1  vmovaps xmm14, [rsp+0xD0]
000073baab9d44ea  vmovaps xmm15, [rsp+0xE0]
000073baab9d44f3  add rsp, 0xF0
000073baab9d44fa  pop r11
000073baab9d44fc  pop r10
000073baab9d44fe  pop r9
000073baab9d4500  pop r8
000073baab9d4502  pop rsi
000073baab9d4503  pop rdi
000073baab9d4504  pop rdx
000073baab9d4505  pop rcx
000073baab9d4506  pop rax
000073baab9d4507  add rsp, 0x08
000073baab9d450b  jmp 0x000073BAAB9D2A5C
000073baab9d4510  call 0x000073BAAB80E760
000073baab9d4515  jmp 0x000073BAAB9D2A69
000073baab9d451a  sub rsp, 0x08
000073baab9d451e  push rax
000073baab9d451f  push rcx
000073baab9d4520  push rdx
000073baab9d4521  push rdi
000073baab9d4522  push rsi
000073baab9d4523  push r8
000073baab9d4525  push r9
000073baab9d4527  push r10
000073baab9d4529  push r11
000073baab9d452b  sub rsp, 0xF0
000073baab9d4532  vmovaps [rsp], xmm0
000073baab9d4537  vmovaps [rsp+0x10], xmm1
000073baab9d453d  vmovaps [rsp+0x20], xmm2
000073baab9d4543  vmovaps [rsp+0x30], xmm3
000073baab9d4549  vmovaps [rsp+0x40], xmm4
000073baab9d454f  vmovaps [rsp+0x50], xmm5
000073baab9d4555  vmovaps [rsp+0x60], xmm6
000073baab9d455b  vmovaps [rsp+0x70], xmm7
000073baab9d4561  vmovaps [rsp+0x80], xmm8
000073baab9d456a  vmovaps [rsp+0x90], xmm9
000073baab9d4573  vmovaps [rsp+0xA0], xmm10
000073baab9d457c  vmovaps [rsp+0xB0], xmm11
000073baab9d4585  vmovaps [rsp+0xC0], xmm12
000073baab9d458e  vmovaps [rsp+0xD0], xmm14
000073baab9d4597  vmovaps [rsp+0xE0], xmm15
000073baab9d45a0  sub rsp, 0x30
000073baab9d45a4  movaps [rsp], xmm13
000073baab9d45a9  movaps [rsp+0x10], xmm2
000073baab9d45ae  movaps [rsp+0x20], xmm1
000073baab9d45b3  lea rdi, [rsp]
000073baab9d45b7  mov esi, 0x00
000073baab9d45bc  mov rax, 0x5F3F1062D530
000073baab9d45c6  call rax
000073baab9d45c8  movaps xmm13, [rsp]
000073baab9d45cd  add rsp, 0x30
000073baab9d45d1  vmovaps xmm0, [rsp]
000073baab9d45d6  vmovaps xmm1, [rsp+0x10]
000073baab9d45dc  vmovaps xmm2, [rsp+0x20]
000073baab9d45e2  vmovaps xmm3, [rsp+0x30]
000073baab9d45e8  vmovaps xmm4, [rsp+0x40]
000073baab9d45ee  vmovaps xmm5, [rsp+0x50]
000073baab9d45f4  vmovaps xmm6, [rsp+0x60]
000073baab9d45fa  vmovaps xmm7, [rsp+0x70]
000073baab9d4600  vmovaps xmm8, [rsp+0x80]
000073baab9d4609  vmovaps xmm9, [rsp+0x90]
000073baab9d4612  vmovaps xmm10, [rsp+0xA0]
000073baab9d461b  vmovaps xmm11, [rsp+0xB0]
000073baab9d4624  vmovaps xmm12, [rsp+0xC0]
000073baab9d462d  vmovaps xmm14, [rsp+0xD0]
000073baab9d4636  vmovaps xmm15, [rsp+0xE0]
000073baab9d463f  add rsp, 0xF0
000073baab9d4646  pop r11
000073baab9d4648  pop r10
000073baab9d464a  pop r9
000073baab9d464c  pop r8
000073baab9d464e  pop rsi
000073baab9d464f  pop rdi
000073baab9d4650  pop rdx
000073baab9d4651  pop rcx
000073baab9d4652  pop rax
000073baab9d4653  add rsp, 0x08
000073baab9d4657  jmp 0x000073BAAB9D2AA8
000073baab9d465c  sub rsp, 0x08
000073baab9d4660  push rax
000073baab9d4661  push rcx
000073baab9d4662  push rdx
000073baab9d4663  push rdi
000073baab9d4664  push rsi
000073baab9d4665  push r8
000073baab9d4667  push r9
000073baab9d4669  push r10
000073baab9d466b  push r11
000073baab9d466d  sub rsp, 0xF0
000073baab9d4674  vmovaps [rsp], xmm0
000073baab9d4679  vmovaps [rsp+0x10], xmm2
000073baab9d467f  vmovaps [rsp+0x20], xmm3
000073baab9d4685  vmovaps [rsp+0x30], xmm4
000073baab9d468b  vmovaps [rsp+0x40], xmm5
000073baab9d4691  vmovaps [rsp+0x50], xmm6
000073baab9d4697  vmovaps [rsp+0x60], xmm7
000073baab9d469d  vmovaps [rsp+0x70], xmm8
000073baab9d46a3  vmovaps [rsp+0x80], xmm9
000073baab9d46ac  vmovaps [rsp+0x90], xmm10
000073baab9d46b5  vmovaps [rsp+0xA0], xmm11
000073baab9d46be  vmovaps [rsp+0xB0], xmm12
000073baab9d46c7  vmovaps [rsp+0xC0], xmm13
000073baab9d46d0  vmovaps [rsp+0xD0], xmm14
000073baab9d46d9  vmovaps [rsp+0xE0], xmm15
000073baab9d46e2  sub rsp, 0x30
000073baab9d46e6  movaps [rsp], xmm1
000073baab9d46ea  movaps [rsp+0x10], xmm14
000073baab9d46f0  movaps [rsp+0x20], xmm15
000073baab9d46f6  lea rdi, [rsp]
000073baab9d46fa  mov esi, 0x00
000073baab9d46ff  mov rax, 0x5F3F1062D530
000073baab9d4709  call rax
000073baab9d470b  movaps xmm1, [rsp]
000073baab9d470f  add rsp, 0x30
000073baab9d4713  vmovaps xmm0, [rsp]
000073baab9d4718  vmovaps xmm2, [rsp+0x10]
000073baab9d471e  vmovaps xmm3, [rsp+0x20]
000073baab9d4724  vmovaps xmm4, [rsp+0x30]
000073baab9d472a  vmovaps xmm5, [rsp+0x40]
000073baab9d4730  vmovaps xmm6, [rsp+0x50]
000073baab9d4736  vmovaps xmm7, [rsp+0x60]
000073baab9d473c  vmovaps xmm8, [rsp+0x70]
000073baab9d4742  vmovaps xmm9, [rsp+0x80]
000073baab9d474b  vmovaps xmm10, [rsp+0x90]
000073baab9d4754  vmovaps xmm11, [rsp+0xA0]
000073baab9d475d  vmovaps xmm12, [rsp+0xB0]
000073baab9d4766  vmovaps xmm13, [rsp+0xC0]
000073baab9d476f  vmovaps xmm14, [rsp+0xD0]
000073baab9d4778  vmovaps xmm15, [rsp+0xE0]
000073baab9d4781  add rsp, 0xF0
000073baab9d4788  pop r11
000073baab9d478a  pop r10
000073baab9d478c  pop r9
000073baab9d478e  pop r8
000073baab9d4790  pop rsi
000073baab9d4791  pop rdi
000073baab9d4792  pop rdx
000073baab9d4793  pop rcx
000073baab9d4794  pop rax
000073baab9d4795  add rsp, 0x08
000073baab9d4799  jmp 0x000073BAAB9D2ACA
000073baab9d479e  sub rsp, 0x08
000073baab9d47a2  push rax
000073baab9d47a3  push rcx
000073baab9d47a4  push rdx
000073baab9d47a5  push rdi
000073baab9d47a6  push rsi
000073baab9d47a7  push r8
000073baab9d47a9  push r9
000073baab9d47ab  push r10
000073baab9d47ad  push r11
000073baab9d47af  sub rsp, 0xF0
000073baab9d47b6  vmovaps [rsp], xmm0
000073baab9d47bb  vmovaps [rsp+0x10], xmm1
000073baab9d47c1  vmovaps [rsp+0x20], xmm2
000073baab9d47c7  vmovaps [rsp+0x30], xmm3
000073baab9d47cd  vmovaps [rsp+0x40], xmm4
000073baab9d47d3  vmovaps [rsp+0x50], xmm5
000073baab9d47d9  vmovaps [rsp+0x60], xmm6
000073baab9d47df  vmovaps [rsp+0x70], xmm7
000073baab9d47e5  vmovaps [rsp+0x80], xmm8
000073baab9d47ee  vmovaps [rsp+0x90], xmm9
000073baab9d47f7  vmovaps [rsp+0xA0], xmm10
000073baab9d4800  vmovaps [rsp+0xB0], xmm11
000073baab9d4809  vmovaps [rsp+0xC0], xmm12
000073baab9d4812  vmovaps [rsp+0xD0], xmm13
000073baab9d481b  vmovaps [rsp+0xE0], xmm15
000073baab9d4824  sub rsp, 0x30
000073baab9d4828  movaps [rsp], xmm14
000073baab9d482d  movaps [rsp+0x10], xmm2
000073baab9d4832  movaps [rsp+0x20], xmm15
000073baab9d4838  lea rdi, [rsp]
000073baab9d483c  mov esi, 0x00
000073baab9d4841  mov rax, 0x5F3F1062D530
000073baab9d484b  call rax
000073baab9d484d  movaps xmm14, [rsp]
000073baab9d4852  add rsp, 0x30
000073baab9d4856  vmovaps xmm0, [rsp]
000073baab9d485b  vmovaps xmm1, [rsp+0x10]
000073baab9d4861  vmovaps xmm2, [rsp+0x20]
000073baab9d4867  vmovaps xmm3, [rsp+0x30]
000073baab9d486d  vmovaps xmm4, [rsp+0x40]
000073baab9d4873  vmovaps xmm5, [rsp+0x50]
000073baab9d4879  vmovaps xmm6, [rsp+0x60]
000073baab9d487f  vmovaps xmm7, [rsp+0x70]
000073baab9d4885  vmovaps xmm8, [rsp+0x80]
000073baab9d488e  vmovaps xmm9, [rsp+0x90]
000073baab9d4897  vmovaps xmm10, [rsp+0xA0]
000073baab9d48a0  vmovaps xmm11, [rsp+0xB0]
000073baab9d48a9  vmovaps xmm12, [rsp+0xC0]
000073baab9d48b2  vmovaps xmm13, [rsp+0xD0]
000073baab9d48bb  vmovaps xmm15, [rsp+0xE0]
000073baab9d48c4  add rsp, 0xF0
000073baab9d48cb  pop r11
000073baab9d48cd  pop r10
000073baab9d48cf  pop r9
000073baab9d48d1  pop r8
000073baab9d48d3  pop rsi
000073baab9d48d4  pop rdi
000073baab9d48d5  pop rdx
000073baab9d48d6  pop rcx
000073baab9d48d7  pop rax
000073baab9d48d8  add rsp, 0x08
000073baab9d48dc  jmp 0x000073BAAB9D2B05
000073baab9d48e1  sub rsp, 0x08
000073baab9d48e5  push rax
000073baab9d48e6  push rcx
000073baab9d48e7  push rdx
000073baab9d48e8  push rdi
000073baab9d48e9  push rsi
000073baab9d48ea  push r8
000073baab9d48ec  push r9
000073baab9d48ee  push r10
000073baab9d48f0  push r11
000073baab9d48f2  sub rsp, 0xF0
000073baab9d48f9  vmovaps [rsp], xmm0
000073baab9d48fe  vmovaps [rsp+0x10], xmm1
000073baab9d4904  vmovaps [rsp+0x20], xmm2
000073baab9d490a  vmovaps [rsp+0x30], xmm3
000073baab9d4910  vmovaps [rsp+0x40], xmm4
000073baab9d4916  vmovaps [rsp+0x50], xmm5
000073baab9d491c  vmovaps [rsp+0x60], xmm6
000073baab9d4922  vmovaps [rsp+0x70], xmm7
000073baab9d4928  vmovaps [rsp+0x80], xmm8
000073baab9d4931  vmovaps [rsp+0x90], xmm9
000073baab9d493a  vmovaps [rsp+0xA0], xmm10
000073baab9d4943  vmovaps [rsp+0xB0], xmm11
000073baab9d494c  vmovaps [rsp+0xC0], xmm12
000073baab9d4955  vmovaps [rsp+0xD0], xmm13
000073baab9d495e  vmovaps [rsp+0xE0], xmm14
000073baab9d4967  sub rsp, 0x30
000073baab9d496b  movaps [rsp], xmm15
000073baab9d4970  movaps [rsp+0x10], xmm2
000073baab9d4975  movaps [rsp+0x20], xmm1
000073baab9d497a  lea rdi, [rsp]
000073baab9d497e  mov esi, 0x00
000073baab9d4983  mov rax, 0x5F3F1062D530
000073baab9d498d  call rax
000073baab9d498f  movaps xmm15, [rsp]
000073baab9d4994  add rsp, 0x30
000073baab9d4998  vmovaps xmm0, [rsp]
000073baab9d499d  vmovaps xmm1, [rsp+0x10]
000073baab9d49a3  vmovaps xmm2, [rsp+0x20]
000073baab9d49a9  vmovaps xmm3, [rsp+0x30]
000073baab9d49af  vmovaps xmm4, [rsp+0x40]
000073baab9d49b5  vmovaps xmm5, [rsp+0x50]
000073baab9d49bb  vmovaps xmm6, [rsp+0x60]
000073baab9d49c1  vmovaps xmm7, [rsp+0x70]
000073baab9d49c7  vmovaps xmm8, [rsp+0x80]
000073baab9d49d0  vmovaps xmm9, [rsp+0x90]
000073baab9d49d9  vmovaps xmm10, [rsp+0xA0]
000073baab9d49e2  vmovaps xmm11, [rsp+0xB0]
000073baab9d49eb  vmovaps xmm12, [rsp+0xC0]
000073baab9d49f4  vmovaps xmm13, [rsp+0xD0]
000073baab9d49fd  vmovaps xmm14, [rsp+0xE0]
000073baab9d4a06  add rsp, 0xF0
000073baab9d4a0d  pop r11
000073baab9d4a0f  pop r10
000073baab9d4a11  pop r9
000073baab9d4a13  pop r8
000073baab9d4a15  pop rsi
000073baab9d4a16  pop rdi
000073baab9d4a17  pop rdx
000073baab9d4a18  pop rcx
000073baab9d4a19  pop rax
000073baab9d4a1a  add rsp, 0x08
000073baab9d4a1e  jmp 0x000073BAAB9D2B41
000073baab9d4a23  call 0x000073BAAB7FF430
000073baab9d4a28  jmp 0x000073BAAB9D2B4E
000073baab9d4a2d  sub rsp, 0x08
000073baab9d4a31  push rax
000073baab9d4a32  push rcx
000073baab9d4a33  push rdx
000073baab9d4a34  push rdi
000073baab9d4a35  push rsi
000073baab9d4a36  push r8
000073baab9d4a38  push r9
000073baab9d4a3a  push r10
000073baab9d4a3c  push r11
000073baab9d4a3e  sub rsp, 0xF0
000073baab9d4a45  vmovaps [rsp], xmm0
000073baab9d4a4a  vmovaps [rsp+0x10], xmm1
000073baab9d4a50  vmovaps [rsp+0x20], xmm3
000073baab9d4a56  vmovaps [rsp+0x30], xmm4
000073baab9d4a5c  vmovaps [rsp+0x40], xmm5
000073baab9d4a62  vmovaps [rsp+0x50], xmm6
000073baab9d4a68  vmovaps [rsp+0x60], xmm7
000073baab9d4a6e  vmovaps [rsp+0x70], xmm8
000073baab9d4a74  vmovaps [rsp+0x80], xmm9
000073baab9d4a7d  vmovaps [rsp+0x90], xmm10
000073baab9d4a86  vmovaps [rsp+0xA0], xmm11
000073baab9d4a8f  vmovaps [rsp+0xB0], xmm12
000073baab9d4a98  vmovaps [rsp+0xC0], xmm13
000073baab9d4aa1  vmovaps [rsp+0xD0], xmm14
000073baab9d4aaa  vmovaps [rsp+0xE0], xmm15
000073baab9d4ab3  sub rsp, 0x30
000073baab9d4ab7  movaps [rsp], xmm2
000073baab9d4abb  movaps [rsp+0x10], xmm1
000073baab9d4ac0  movaps [rsp+0x20], xmm14
000073baab9d4ac6  lea rdi, [rsp]
000073baab9d4aca  mov esi, 0x00
000073baab9d4acf  mov rax, 0x5F3F1062D530
000073baab9d4ad9  call rax
000073baab9d4adb  movaps xmm2, [rsp]
000073baab9d4adf  add rsp, 0x30
000073baab9d4ae3  vmovaps xmm0, [rsp]
000073baab9d4ae8  vmovaps xmm1, [rsp+0x10]
000073baab9d4aee  vmovaps xmm3, [rsp+0x20]
000073baab9d4af4  vmovaps xmm4, [rsp+0x30]
000073baab9d4afa  vmovaps xmm5, [rsp+0x40]
000073baab9d4b00  vmovaps xmm6, [rsp+0x50]
000073baab9d4b06  vmovaps xmm7, [rsp+0x60]
000073baab9d4b0c  vmovaps xmm8, [rsp+0x70]
000073baab9d4b12  vmovaps xmm9, [rsp+0x80]
000073baab9d4b1b  vmovaps xmm10, [rsp+0x90]
000073baab9d4b24  vmovaps xmm11, [rsp+0xA0]
000073baab9d4b2d  vmovaps xmm12, [rsp+0xB0]
000073baab9d4b36  vmovaps xmm13, [rsp+0xC0]
000073baab9d4b3f  vmovaps xmm14, [rsp+0xD0]
000073baab9d4b48  vmovaps xmm15, [rsp+0xE0]
000073baab9d4b51  add rsp, 0xF0
000073baab9d4b58  pop r11
000073baab9d4b5a  pop r10
000073baab9d4b5c  pop r9
000073baab9d4b5e  pop r8
000073baab9d4b60  pop rsi
000073baab9d4b61  pop rdi
000073baab9d4b62  pop rdx
000073baab9d4b63  pop rcx
000073baab9d4b64  pop rax
000073baab9d4b65  add rsp, 0x08
000073baab9d4b69  jmp 0x000073BAAB9D2B8B
000073baab9d4b6e  sub rsp, 0x08
000073baab9d4b72  push rax
000073baab9d4b73  push rcx
000073baab9d4b74  push rdx
000073baab9d4b75  push rdi
000073baab9d4b76  push rsi
000073baab9d4b77  push r8
000073baab9d4b79  push r9
000073baab9d4b7b  push r10
000073baab9d4b7d  push r11
000073baab9d4b7f  sub rsp, 0xF0
000073baab9d4b86  vmovaps [rsp], xmm0
000073baab9d4b8b  vmovaps [rsp+0x10], xmm1
000073baab9d4b91  vmovaps [rsp+0x20], xmm2
000073baab9d4b97  vmovaps [rsp+0x30], xmm3
000073baab9d4b9d  vmovaps [rsp+0x40], xmm4
000073baab9d4ba3  vmovaps [rsp+0x50], xmm5
000073baab9d4ba9  vmovaps [rsp+0x60], xmm6
000073baab9d4baf  vmovaps [rsp+0x70], xmm7
000073baab9d4bb5  vmovaps [rsp+0x80], xmm8
000073baab9d4bbe  vmovaps [rsp+0x90], xmm9
000073baab9d4bc7  vmovaps [rsp+0xA0], xmm10
000073baab9d4bd0  vmovaps [rsp+0xB0], xmm11
000073baab9d4bd9  vmovaps [rsp+0xC0], xmm12
000073baab9d4be2  vmovaps [rsp+0xD0], xmm13
000073baab9d4beb  vmovaps [rsp+0xE0], xmm14
000073baab9d4bf4  sub rsp, 0x30
000073baab9d4bf8  movaps [rsp], xmm15
000073baab9d4bfd  movaps [rsp+0x10], xmm14
000073baab9d4c03  movaps [rsp+0x20], xmm1
000073baab9d4c08  lea rdi, [rsp]
000073baab9d4c0c  mov esi, 0x00
000073baab9d4c11  mov rax, 0x5F3F1062D530
000073baab9d4c1b  call rax
000073baab9d4c1d  movaps xmm15, [rsp]
000073baab9d4c22  add rsp, 0x30
000073baab9d4c26  vmovaps xmm0, [rsp]
000073baab9d4c2b  vmovaps xmm1, [rsp+0x10]
000073baab9d4c31  vmovaps xmm2, [rsp+0x20]
000073baab9d4c37  vmovaps xmm3, [rsp+0x30]
000073baab9d4c3d  vmovaps xmm4, [rsp+0x40]
000073baab9d4c43  vmovaps xmm5, [rsp+0x50]
000073baab9d4c49  vmovaps xmm6, [rsp+0x60]
000073baab9d4c4f  vmovaps xmm7, [rsp+0x70]
000073baab9d4c55  vmovaps xmm8, [rsp+0x80]
000073baab9d4c5e  vmovaps xmm9, [rsp+0x90]
000073baab9d4c67  vmovaps xmm10, [rsp+0xA0]
000073baab9d4c70  vmovaps xmm11, [rsp+0xB0]
000073baab9d4c79  vmovaps xmm12, [rsp+0xC0]
000073baab9d4c82  vmovaps xmm13, [rsp+0xD0]
000073baab9d4c8b  vmovaps xmm14, [rsp+0xE0]
000073baab9d4c94  add rsp, 0xF0
000073baab9d4c9b  pop r11
000073baab9d4c9d  pop r10
000073baab9d4c9f  pop r9
000073baab9d4ca1  pop r8
000073baab9d4ca3  pop rsi
000073baab9d4ca4  pop rdi
000073baab9d4ca5  pop rdx
000073baab9d4ca6  pop rcx
000073baab9d4ca7  pop rax
000073baab9d4ca8  add rsp, 0x08
000073baab9d4cac  jmp 0x000073BAAB9D2C05
000073baab9d4cb1  call 0x000073BAAB7FF430
000073baab9d4cb6  jmp 0x000073BAAB9D2C12
000073baab9d4cbb  sub rsp, 0x08
000073baab9d4cbf  push rax
000073baab9d4cc0  push rcx
000073baab9d4cc1  push rdx
000073baab9d4cc2  push rdi
000073baab9d4cc3  push rsi
000073baab9d4cc4  push r8
000073baab9d4cc6  push r9
000073baab9d4cc8  push r10
000073baab9d4cca  push r11
000073baab9d4ccc  sub rsp, 0xF0
000073baab9d4cd3  vmovaps [rsp], xmm0
000073baab9d4cd8  vmovaps [rsp+0x10], xmm1
000073baab9d4cde  vmovaps [rsp+0x20], xmm2
000073baab9d4ce4  vmovaps [rsp+0x30], xmm3
000073baab9d4cea  vmovaps [rsp+0x40], xmm4
000073baab9d4cf0  vmovaps [rsp+0x50], xmm5
000073baab9d4cf6  vmovaps [rsp+0x60], xmm6
000073baab9d4cfc  vmovaps [rsp+0x70], xmm7
000073baab9d4d02  vmovaps [rsp+0x80], xmm8
000073baab9d4d0b  vmovaps [rsp+0x90], xmm9
000073baab9d4d14  vmovaps [rsp+0xA0], xmm10
000073baab9d4d1d  vmovaps [rsp+0xB0], xmm11
000073baab9d4d26  vmovaps [rsp+0xC0], xmm12
000073baab9d4d2f  vmovaps [rsp+0xD0], xmm14
000073baab9d4d38  vmovaps [rsp+0xE0], xmm15
000073baab9d4d41  sub rsp, 0x30
000073baab9d4d45  movaps [rsp], xmm13
000073baab9d4d4a  movaps [rsp+0x10], xmm1
000073baab9d4d4f  movaps [rsp+0x20], xmm15
000073baab9d4d55  lea rdi, [rsp]
000073baab9d4d59  mov esi, 0x00
000073baab9d4d5e  mov rax, 0x5F3F1062D530
000073baab9d4d68  call rax
000073baab9d4d6a  movaps xmm13, [rsp]
000073baab9d4d6f  add rsp, 0x30
000073baab9d4d73  vmovaps xmm0, [rsp]
000073baab9d4d78  vmovaps xmm1, [rsp+0x10]
000073baab9d4d7e  vmovaps xmm2, [rsp+0x20]
000073baab9d4d84  vmovaps xmm3, [rsp+0x30]
000073baab9d4d8a  vmovaps xmm4, [rsp+0x40]
000073baab9d4d90  vmovaps xmm5, [rsp+0x50]
000073baab9d4d96  vmovaps xmm6, [rsp+0x60]
000073baab9d4d9c  vmovaps xmm7, [rsp+0x70]
000073baab9d4da2  vmovaps xmm8, [rsp+0x80]
000073baab9d4dab  vmovaps xmm9, [rsp+0x90]
000073baab9d4db4  vmovaps xmm10, [rsp+0xA0]
000073baab9d4dbd  vmovaps xmm11, [rsp+0xB0]
000073baab9d4dc6  vmovaps xmm12, [rsp+0xC0]
000073baab9d4dcf  vmovaps xmm14, [rsp+0xD0]
000073baab9d4dd8  vmovaps xmm15, [rsp+0xE0]
000073baab9d4de1  add rsp, 0xF0
000073baab9d4de8  pop r11
000073baab9d4dea  pop r10
000073baab9d4dec  pop r9
000073baab9d4dee  pop r8
000073baab9d4df0  pop rsi
000073baab9d4df1  pop rdi
000073baab9d4df2  pop rdx
000073baab9d4df3  pop rcx
000073baab9d4df4  pop rax
000073baab9d4df5  add rsp, 0x08
000073baab9d4df9  jmp 0x000073BAAB9D2CD6
000073baab9d4dfe  sub rsp, 0x08
000073baab9d4e02  push rax
000073baab9d4e03  push rcx
000073baab9d4e04  push rdx
000073baab9d4e05  push rdi
000073baab9d4e06  push rsi
000073baab9d4e07  push r8
000073baab9d4e09  push r9
000073baab9d4e0b  push r10
000073baab9d4e0d  push r11
000073baab9d4e0f  sub rsp, 0xF0
000073baab9d4e16  vmovaps [rsp], xmm0
000073baab9d4e1b  vmovaps [rsp+0x10], xmm1
000073baab9d4e21  vmovaps [rsp+0x20], xmm2
000073baab9d4e27  vmovaps [rsp+0x30], xmm3
000073baab9d4e2d  vmovaps [rsp+0x40], xmm4
000073baab9d4e33  vmovaps [rsp+0x50], xmm5
000073baab9d4e39  vmovaps [rsp+0x60], xmm6
000073baab9d4e3f  vmovaps [rsp+0x70], xmm7
000073baab9d4e45  vmovaps [rsp+0x80], xmm8
000073baab9d4e4e  vmovaps [rsp+0x90], xmm9
000073baab9d4e57  vmovaps [rsp+0xA0], xmm10
000073baab9d4e60  vmovaps [rsp+0xB0], xmm11
000073baab9d4e69  vmovaps [rsp+0xC0], xmm12
000073baab9d4e72  vmovaps [rsp+0xD0], xmm13
000073baab9d4e7b  vmovaps [rsp+0xE0], xmm14
000073baab9d4e84  sub rsp, 0x30
000073baab9d4e88  movaps [rsp], xmm15
000073baab9d4e8d  movaps [rsp+0x10], xmm14
000073baab9d4e93  movaps [rsp+0x20], xmm1
000073baab9d4e98  lea rdi, [rsp]
000073baab9d4e9c  mov esi, 0x00
000073baab9d4ea1  mov rax, 0x5F3F1062D530
000073baab9d4eab  call rax
000073baab9d4ead  movaps xmm15, [rsp]
000073baab9d4eb2  add rsp, 0x30
000073baab9d4eb6  vmovaps xmm0, [rsp]
000073baab9d4ebb  vmovaps xmm1, [rsp+0x10]
000073baab9d4ec1  vmovaps xmm2, [rsp+0x20]
000073baab9d4ec7  vmovaps xmm3, [rsp+0x30]
000073baab9d4ecd  vmovaps xmm4, [rsp+0x40]
000073baab9d4ed3  vmovaps xmm5, [rsp+0x50]
000073baab9d4ed9  vmovaps xmm6, [rsp+0x60]
000073baab9d4edf  vmovaps xmm7, [rsp+0x70]
000073baab9d4ee5  vmovaps xmm8, [rsp+0x80]
000073baab9d4eee  vmovaps xmm9, [rsp+0x90]
000073baab9d4ef7  vmovaps xmm10, [rsp+0xA0]
000073baab9d4f00  vmovaps xmm11, [rsp+0xB0]
000073baab9d4f09  vmovaps xmm12, [rsp+0xC0]
000073baab9d4f12  vmovaps xmm13, [rsp+0xD0]
000073baab9d4f1b  vmovaps xmm14, [rsp+0xE0]
000073baab9d4f24  add rsp, 0xF0
000073baab9d4f2b  pop r11
000073baab9d4f2d  pop r10
000073baab9d4f2f  pop r9
000073baab9d4f31  pop r8
000073baab9d4f33  pop rsi
000073baab9d4f34  pop rdi
000073baab9d4f35  pop rdx
000073baab9d4f36  pop rcx
000073baab9d4f37  pop rax
000073baab9d4f38  add rsp, 0x08
000073baab9d4f3c  jmp 0x000073BAAB9D2D12
000073baab9d4f41  call 0x000073BAAB7FF430
000073baab9d4f46  jmp 0x000073BAAB9D2D1F
000073baab9d4f4b  sub rsp, 0x08
000073baab9d4f4f  push rax
000073baab9d4f50  push rcx
000073baab9d4f51  push rdx
000073baab9d4f52  push rdi
000073baab9d4f53  push rsi
000073baab9d4f54  push r8
000073baab9d4f56  push r9
000073baab9d4f58  push r10
000073baab9d4f5a  push r11
000073baab9d4f5c  sub rsp, 0xF0
000073baab9d4f63  vmovaps [rsp], xmm0
000073baab9d4f68  vmovaps [rsp+0x10], xmm1
000073baab9d4f6e  vmovaps [rsp+0x20], xmm2
000073baab9d4f74  vmovaps [rsp+0x30], xmm3
000073baab9d4f7a  vmovaps [rsp+0x40], xmm4
000073baab9d4f80  vmovaps [rsp+0x50], xmm5
000073baab9d4f86  vmovaps [rsp+0x60], xmm6
000073baab9d4f8c  vmovaps [rsp+0x70], xmm7
000073baab9d4f92  vmovaps [rsp+0x80], xmm8
000073baab9d4f9b  vmovaps [rsp+0x90], xmm9
000073baab9d4fa4  vmovaps [rsp+0xA0], xmm10
000073baab9d4fad  vmovaps [rsp+0xB0], xmm11
000073baab9d4fb6  vmovaps [rsp+0xC0], xmm12
000073baab9d4fbf  vmovaps [rsp+0xD0], xmm13
000073baab9d4fc8  vmovaps [rsp+0xE0], xmm15
000073baab9d4fd1  sub rsp, 0x30
000073baab9d4fd5  movaps [rsp], xmm14
000073baab9d4fda  movaps [rsp+0x10], xmm13
000073baab9d4fe0  movaps [rsp+0x20], xmm2
000073baab9d4fe5  lea rdi, [rsp]
000073baab9d4fe9  mov esi, 0x00
000073baab9d4fee  mov rax, 0x5F3F1062D530
000073baab9d4ff8  call rax
000073baab9d4ffa  movaps xmm14, [rsp]
000073baab9d4fff  add rsp, 0x30
000073baab9d5003  vmovaps xmm0, [rsp]
000073baab9d5008  vmovaps xmm1, [rsp+0x10]
000073baab9d500e  vmovaps xmm2, [rsp+0x20]
000073baab9d5014  vmovaps xmm3, [rsp+0x30]
000073baab9d501a  vmovaps xmm4, [rsp+0x40]
000073baab9d5020  vmovaps xmm5, [rsp+0x50]
000073baab9d5026  vmovaps xmm6, [rsp+0x60]
000073baab9d502c  vmovaps xmm7, [rsp+0x70]
000073baab9d5032  vmovaps xmm8, [rsp+0x80]
000073baab9d503b  vmovaps xmm9, [rsp+0x90]
000073baab9d5044  vmovaps xmm10, [rsp+0xA0]
000073baab9d504d  vmovaps xmm11, [rsp+0xB0]
000073baab9d5056  vmovaps xmm12, [rsp+0xC0]
000073baab9d505f  vmovaps xmm13, [rsp+0xD0]
000073baab9d5068  vmovaps xmm15, [rsp+0xE0]
000073baab9d5071  add rsp, 0xF0
000073baab9d5078  pop r11
000073baab9d507a  pop r10
000073baab9d507c  pop r9
000073baab9d507e  pop r8
000073baab9d5080  pop rsi
000073baab9d5081  pop rdi
000073baab9d5082  pop rdx
000073baab9d5083  pop rcx
000073baab9d5084  pop rax
000073baab9d5085  add rsp, 0x08
000073baab9d5089  jmp 0x000073BAAB9D2D4B
000073baab9d508e  sub rsp, 0x08
000073baab9d5092  push rax
000073baab9d5093  push rcx
000073baab9d5094  push rdx
000073baab9d5095  push rdi
000073baab9d5096  push rsi
000073baab9d5097  push r8
000073baab9d5099  push r9
000073baab9d509b  push r10
000073baab9d509d  push r11
000073baab9d509f  sub rsp, 0xF0
000073baab9d50a6  vmovaps [rsp], xmm0
000073baab9d50ab  vmovaps [rsp+0x10], xmm2
000073baab9d50b1  vmovaps [rsp+0x20], xmm3
000073baab9d50b7  vmovaps [rsp+0x30], xmm4
000073baab9d50bd  vmovaps [rsp+0x40], xmm5
000073baab9d50c3  vmovaps [rsp+0x50], xmm6
000073baab9d50c9  vmovaps [rsp+0x60], xmm7
000073baab9d50cf  vmovaps [rsp+0x70], xmm8
000073baab9d50d5  vmovaps [rsp+0x80], xmm9
000073baab9d50de  vmovaps [rsp+0x90], xmm10
000073baab9d50e7  vmovaps [rsp+0xA0], xmm11
000073baab9d50f0  vmovaps [rsp+0xB0], xmm12
000073baab9d50f9  vmovaps [rsp+0xC0], xmm13
000073baab9d5102  vmovaps [rsp+0xD0], xmm14
000073baab9d510b  vmovaps [rsp+0xE0], xmm15
000073baab9d5114  sub rsp, 0x30
000073baab9d5118  movaps [rsp], xmm1
000073baab9d511c  movaps [rsp+0x10], xmm13
000073baab9d5122  movaps [rsp+0x20], xmm2
000073baab9d5127  lea rdi, [rsp]
000073baab9d512b  mov esi, 0x00
000073baab9d5130  mov rax, 0x5F3F1062D530
000073baab9d513a  call rax
000073baab9d513c  movaps xmm1, [rsp]
000073baab9d5140  add rsp, 0x30
000073baab9d5144  vmovaps xmm0, [rsp]
000073baab9d5149  vmovaps xmm2, [rsp+0x10]
000073baab9d514f  vmovaps xmm3, [rsp+0x20]
000073baab9d5155  vmovaps xmm4, [rsp+0x30]
000073baab9d515b  vmovaps xmm5, [rsp+0x40]
000073baab9d5161  vmovaps xmm6, [rsp+0x50]
000073baab9d5167  vmovaps xmm7, [rsp+0x60]
000073baab9d516d  vmovaps xmm8, [rsp+0x70]
000073baab9d5173  vmovaps xmm9, [rsp+0x80]
000073baab9d517c  vmovaps xmm10, [rsp+0x90]
000073baab9d5185  vmovaps xmm11, [rsp+0xA0]
000073baab9d518e  vmovaps xmm12, [rsp+0xB0]
000073baab9d5197  vmovaps xmm13, [rsp+0xC0]
000073baab9d51a0  vmovaps xmm14, [rsp+0xD0]
000073baab9d51a9  vmovaps xmm15, [rsp+0xE0]
000073baab9d51b2  add rsp, 0xF0
000073baab9d51b9  pop r11
000073baab9d51bb  pop r10
000073baab9d51bd  pop r9
000073baab9d51bf  pop r8
000073baab9d51c1  pop rsi
000073baab9d51c2  pop rdi
000073baab9d51c3  pop rdx
000073baab9d51c4  pop rcx
000073baab9d51c5  pop rax
000073baab9d51c6  add rsp, 0x08
000073baab9d51ca  jmp 0x000073BAAB9D2D79
000073baab9d51cf  sub rsp, 0x08
000073baab9d51d3  push rax
000073baab9d51d4  push rcx
000073baab9d51d5  push rdx
000073baab9d51d6  push rdi
000073baab9d51d7  push rsi
000073baab9d51d8  push r8
000073baab9d51da  push r9
000073baab9d51dc  push r10
000073baab9d51de  push r11
000073baab9d51e0  sub rsp, 0xF0
000073baab9d51e7  vmovaps [rsp], xmm0
000073baab9d51ec  vmovaps [rsp+0x10], xmm1
000073baab9d51f2  vmovaps [rsp+0x20], xmm3
000073baab9d51f8  vmovaps [rsp+0x30], xmm4
000073baab9d51fe  vmovaps [rsp+0x40], xmm5
000073baab9d5204  vmovaps [rsp+0x50], xmm6
000073baab9d520a  vmovaps [rsp+0x60], xmm7
000073baab9d5210  vmovaps [rsp+0x70], xmm8
000073baab9d5216  vmovaps [rsp+0x80], xmm9
000073baab9d521f  vmovaps [rsp+0x90], xmm10
000073baab9d5228  vmovaps [rsp+0xA0], xmm11
000073baab9d5231  vmovaps [rsp+0xB0], xmm12
000073baab9d523a  vmovaps [rsp+0xC0], xmm13
000073baab9d5243  vmovaps [rsp+0xD0], xmm14
000073baab9d524c  vmovaps [rsp+0xE0], xmm15
000073baab9d5255  sub rsp, 0x30
000073baab9d5259  movaps [rsp], xmm2
000073baab9d525d  movaps [rsp+0x10], xmm1
000073baab9d5262  movaps [rsp+0x20], xmm13
000073baab9d5268  lea rdi, [rsp]
000073baab9d526c  mov esi, 0x00
000073baab9d5271  mov rax, 0x5F3F1062D530
000073baab9d527b  call rax
000073baab9d527d  movaps xmm2, [rsp]
000073baab9d5281  add rsp, 0x30
000073baab9d5285  vmovaps xmm0, [rsp]
000073baab9d528a  vmovaps xmm1, [rsp+0x10]
000073baab9d5290  vmovaps xmm3, [rsp+0x20]
000073baab9d5296  vmovaps xmm4, [rsp+0x30]
000073baab9d529c  vmovaps xmm5, [rsp+0x40]
000073baab9d52a2  vmovaps xmm6, [rsp+0x50]
000073baab9d52a8  vmovaps xmm7, [rsp+0x60]
000073baab9d52ae  vmovaps xmm8, [rsp+0x70]
000073baab9d52b4  vmovaps xmm9, [rsp+0x80]
000073baab9d52bd  vmovaps xmm10, [rsp+0x90]
000073baab9d52c6  vmovaps xmm11, [rsp+0xA0]
000073baab9d52cf  vmovaps xmm12, [rsp+0xB0]
000073baab9d52d8  vmovaps xmm13, [rsp+0xC0]
000073baab9d52e1  vmovaps xmm14, [rsp+0xD0]
000073baab9d52ea  vmovaps xmm15, [rsp+0xE0]
000073baab9d52f3  add rsp, 0xF0
000073baab9d52fa  pop r11
000073baab9d52fc  pop r10
000073baab9d52fe  pop r9
000073baab9d5300  pop r8
000073baab9d5302  pop rsi
000073baab9d5303  pop rdi
000073baab9d5304  pop rdx
000073baab9d5305  pop rcx
000073baab9d5306  pop rax
000073baab9d5307  add rsp, 0x08
000073baab9d530b  jmp 0x000073BAAB9D2DD2
000073baab9d5310  call 0x000073BAAB7FF430
000073baab9d5315  jmp 0x000073BAAB9D2DDF
000073baab9d531a  sub rsp, 0x08
000073baab9d531e  push rax
000073baab9d531f  push rcx
000073baab9d5320  push rdx
000073baab9d5321  push rdi
000073baab9d5322  push rsi
000073baab9d5323  push r8
000073baab9d5325  push r9
000073baab9d5327  push r10
000073baab9d5329  push r11
000073baab9d532b  sub rsp, 0xF0
000073baab9d5332  vmovaps [rsp], xmm0
000073baab9d5337  vmovaps [rsp+0x10], xmm1
000073baab9d533d  vmovaps [rsp+0x20], xmm2
000073baab9d5343  vmovaps [rsp+0x30], xmm3
000073baab9d5349  vmovaps [rsp+0x40], xmm4
000073baab9d534f  vmovaps [rsp+0x50], xmm5
000073baab9d5355  vmovaps [rsp+0x60], xmm6
000073baab9d535b  vmovaps [rsp+0x70], xmm7
000073baab9d5361  vmovaps [rsp+0x80], xmm8
000073baab9d536a  vmovaps [rsp+0x90], xmm9
000073baab9d5373  vmovaps [rsp+0xA0], xmm10
000073baab9d537c  vmovaps [rsp+0xB0], xmm11
000073baab9d5385  vmovaps [rsp+0xC0], xmm12
000073baab9d538e  vmovaps [rsp+0xD0], xmm13
000073baab9d5397  vmovaps [rsp+0xE0], xmm14
000073baab9d53a0  sub rsp, 0x30
000073baab9d53a4  movaps [rsp], xmm15
000073baab9d53a9  movaps [rsp+0x10], xmm13
000073baab9d53af  movaps [rsp+0x20], xmm1
000073baab9d53b4  lea rdi, [rsp]
000073baab9d53b8  mov esi, 0x00
000073baab9d53bd  mov rax, 0x5F3F1062D530
000073baab9d53c7  call rax
000073baab9d53c9  movaps xmm15, [rsp]
000073baab9d53ce  add rsp, 0x30
000073baab9d53d2  vmovaps xmm0, [rsp]
000073baab9d53d7  vmovaps xmm1, [rsp+0x10]
000073baab9d53dd  vmovaps xmm2, [rsp+0x20]
000073baab9d53e3  vmovaps xmm3, [rsp+0x30]
000073baab9d53e9  vmovaps xmm4, [rsp+0x40]
000073baab9d53ef  vmovaps xmm5, [rsp+0x50]
000073baab9d53f5  vmovaps xmm6, [rsp+0x60]
000073baab9d53fb  vmovaps xmm7, [rsp+0x70]
000073baab9d5401  vmovaps xmm8, [rsp+0x80]
000073baab9d540a  vmovaps xmm9, [rsp+0x90]
000073baab9d5413  vmovaps xmm10, [rsp+0xA0]
000073baab9d541c  vmovaps xmm11, [rsp+0xB0]
000073baab9d5425  vmovaps xmm12, [rsp+0xC0]
000073baab9d542e  vmovaps xmm13, [rsp+0xD0]
000073baab9d5437  vmovaps xmm14, [rsp+0xE0]
000073baab9d5440  add rsp, 0xF0
000073baab9d5447  pop r11
000073baab9d5449  pop r10
000073baab9d544b  pop r9
000073baab9d544d  pop r8
000073baab9d544f  pop rsi
000073baab9d5450  pop rdi
000073baab9d5451  pop rdx
000073baab9d5452  pop rcx
000073baab9d5453  pop rax
000073baab9d5454  add rsp, 0x08
000073baab9d5458  jmp 0x000073BAAB9D2E1E
000073baab9d545d  sub rsp, 0x08
000073baab9d5461  push rax
000073baab9d5462  push rcx
000073baab9d5463  push rdx
000073baab9d5464  push rdi
000073baab9d5465  push rsi
000073baab9d5466  push r8
000073baab9d5468  push r9
000073baab9d546a  push r10
000073baab9d546c  push r11
000073baab9d546e  sub rsp, 0xF0
000073baab9d5475  vmovaps [rsp], xmm0
000073baab9d547a  vmovaps [rsp+0x10], xmm1
000073baab9d5480  vmovaps [rsp+0x20], xmm2
000073baab9d5486  vmovaps [rsp+0x30], xmm3
000073baab9d548c  vmovaps [rsp+0x40], xmm4
000073baab9d5492  vmovaps [rsp+0x50], xmm5
000073baab9d5498  vmovaps [rsp+0x60], xmm6
000073baab9d549e  vmovaps [rsp+0x70], xmm7
000073baab9d54a4  vmovaps [rsp+0x80], xmm8
000073baab9d54ad  vmovaps [rsp+0x90], xmm9
000073baab9d54b6  vmovaps [rsp+0xA0], xmm10
000073baab9d54bf  vmovaps [rsp+0xB0], xmm11
000073baab9d54c8  vmovaps [rsp+0xC0], xmm12
000073baab9d54d1  vmovaps [rsp+0xD0], xmm13
000073baab9d54da  vmovaps [rsp+0xE0], xmm15
000073baab9d54e3  sub rsp, 0x30
000073baab9d54e7  movaps [rsp], xmm14
000073baab9d54ec  movaps [rsp+0x10], xmm11
000073baab9d54f2  movaps [rsp+0x20], xmm1
000073baab9d54f7  lea rdi, [rsp]
000073baab9d54fb  mov esi, 0x00
000073baab9d5500  mov rax, 0x5F3F1062D530
000073baab9d550a  call rax
000073baab9d550c  movaps xmm14, [rsp]
000073baab9d5511  add rsp, 0x30
000073baab9d5515  vmovaps xmm0, [rsp]
000073baab9d551a  vmovaps xmm1, [rsp+0x10]
000073baab9d5520  vmovaps xmm2, [rsp+0x20]
000073baab9d5526  vmovaps xmm3, [rsp+0x30]
000073baab9d552c  vmovaps xmm4, [rsp+0x40]
000073baab9d5532  vmovaps xmm5, [rsp+0x50]
000073baab9d5538  vmovaps xmm6, [rsp+0x60]
000073baab9d553e  vmovaps xmm7, [rsp+0x70]
000073baab9d5544  vmovaps xmm8, [rsp+0x80]
000073baab9d554d  vmovaps xmm9, [rsp+0x90]
000073baab9d5556  vmovaps xmm10, [rsp+0xA0]
000073baab9d555f  vmovaps xmm11, [rsp+0xB0]
000073baab9d5568  vmovaps xmm12, [rsp+0xC0]
000073baab9d5571  vmovaps xmm13, [rsp+0xD0]
000073baab9d557a  vmovaps xmm15, [rsp+0xE0]
000073baab9d5583  add rsp, 0xF0
000073baab9d558a  pop r11
000073baab9d558c  pop r10
000073baab9d558e  pop r9
000073baab9d5590  pop r8
000073baab9d5592  pop rsi
000073baab9d5593  pop rdi
000073baab9d5594  pop rdx
000073baab9d5595  pop rcx
000073baab9d5596  pop rax
000073baab9d5597  add rsp, 0x08
000073baab9d559b  jmp 0x000073BAAB9D2E48
000073baab9d55a0  sub rsp, 0x08
000073baab9d55a4  push rax
000073baab9d55a5  push rcx
000073baab9d55a6  push rdx
000073baab9d55a7  push rdi
000073baab9d55a8  push rsi
000073baab9d55a9  push r8
000073baab9d55ab  push r9
000073baab9d55ad  push r10
000073baab9d55af  push r11
000073baab9d55b1  sub rsp, 0xF0
000073baab9d55b8  vmovaps [rsp], xmm0
000073baab9d55bd  vmovaps [rsp+0x10], xmm1
000073baab9d55c3  vmovaps [rsp+0x20], xmm2
000073baab9d55c9  vmovaps [rsp+0x30], xmm3
000073baab9d55cf  vmovaps [rsp+0x40], xmm4
000073baab9d55d5  vmovaps [rsp+0x50], xmm5
000073baab9d55db  vmovaps [rsp+0x60], xmm6
000073baab9d55e1  vmovaps [rsp+0x70], xmm7
000073baab9d55e7  vmovaps [rsp+0x80], xmm8
000073baab9d55f0  vmovaps [rsp+0x90], xmm9
000073baab9d55f9  vmovaps [rsp+0xA0], xmm10
000073baab9d5602  vmovaps [rsp+0xB0], xmm11
000073baab9d560b  vmovaps [rsp+0xC0], xmm12
000073baab9d5614  vmovaps [rsp+0xD0], xmm14
000073baab9d561d  vmovaps [rsp+0xE0], xmm15
000073baab9d5626  sub rsp, 0x30
000073baab9d562a  movaps [rsp], xmm13
000073baab9d562f  movaps [rsp+0x10], xmm11
000073baab9d5635  movaps [rsp+0x20], xmm1
000073baab9d563a  lea rdi, [rsp]
000073baab9d563e  mov esi, 0x00
000073baab9d5643  mov rax, 0x5F3F1062D530
000073baab9d564d  call rax
000073baab9d564f  movaps xmm13, [rsp]
000073baab9d5654  add rsp, 0x30
000073baab9d5658  vmovaps xmm0, [rsp]
000073baab9d565d  vmovaps xmm1, [rsp+0x10]
000073baab9d5663  vmovaps xmm2, [rsp+0x20]
000073baab9d5669  vmovaps xmm3, [rsp+0x30]
000073baab9d566f  vmovaps xmm4, [rsp+0x40]
000073baab9d5675  vmovaps xmm5, [rsp+0x50]
000073baab9d567b  vmovaps xmm6, [rsp+0x60]
000073baab9d5681  vmovaps xmm7, [rsp+0x70]
000073baab9d5687  vmovaps xmm8, [rsp+0x80]
000073baab9d5690  vmovaps xmm9, [rsp+0x90]
000073baab9d5699  vmovaps xmm10, [rsp+0xA0]
000073baab9d56a2  vmovaps xmm11, [rsp+0xB0]
000073baab9d56ab  vmovaps xmm12, [rsp+0xC0]
000073baab9d56b4  vmovaps xmm14, [rsp+0xD0]
000073baab9d56bd  vmovaps xmm15, [rsp+0xE0]
000073baab9d56c6  add rsp, 0xF0
000073baab9d56cd  pop r11
000073baab9d56cf  pop r10
000073baab9d56d1  pop r9
000073baab9d56d3  pop r8
000073baab9d56d5  pop rsi
000073baab9d56d6  pop rdi
000073baab9d56d7  pop rdx
000073baab9d56d8  pop rcx
000073baab9d56d9  pop rax
000073baab9d56da  add rsp, 0x08
000073baab9d56de  jmp 0x000073BAAB9D2E9D
000073baab9d56e3  call 0x000073BAAB7FF430
000073baab9d56e8  jmp 0x000073BAAB9D2EAA
000073baab9d56ed  sub rsp, 0x08
000073baab9d56f1  push rax
000073baab9d56f2  push rcx
000073baab9d56f3  push rdx
000073baab9d56f4  push rdi
000073baab9d56f5  push rsi
000073baab9d56f6  push r8
000073baab9d56f8  push r9
000073baab9d56fa  push r10
000073baab9d56fc  push r11
000073baab9d56fe  sub rsp, 0xF0
000073baab9d5705  vmovaps [rsp], xmm0
000073baab9d570a  vmovaps [rsp+0x10], xmm1
000073baab9d5710  vmovaps [rsp+0x20], xmm2
000073baab9d5716  vmovaps [rsp+0x30], xmm3
000073baab9d571c  vmovaps [rsp+0x40], xmm4
000073baab9d5722  vmovaps [rsp+0x50], xmm5
000073baab9d5728  vmovaps [rsp+0x60], xmm6
000073baab9d572e  vmovaps [rsp+0x70], xmm7
000073baab9d5734  vmovaps [rsp+0x80], xmm8
000073baab9d573d  vmovaps [rsp+0x90], xmm9
000073baab9d5746  vmovaps [rsp+0xA0], xmm10
000073baab9d574f  vmovaps [rsp+0xB0], xmm11
000073baab9d5758  vmovaps [rsp+0xC0], xmm12
000073baab9d5761  vmovaps [rsp+0xD0], xmm13
000073baab9d576a  vmovaps [rsp+0xE0], xmm14
000073baab9d5773  sub rsp, 0x30
000073baab9d5777  movaps [rsp], xmm15
000073baab9d577c  movaps [rsp+0x10], xmm11
000073baab9d5782  movaps [rsp+0x20], xmm1
000073baab9d5787  lea rdi, [rsp]
000073baab9d578b  mov esi, 0x00
000073baab9d5790  mov rax, 0x5F3F1062D530
000073baab9d579a  call rax
000073baab9d579c  movaps xmm15, [rsp]
000073baab9d57a1  add rsp, 0x30
000073baab9d57a5  vmovaps xmm0, [rsp]
000073baab9d57aa  vmovaps xmm1, [rsp+0x10]
000073baab9d57b0  vmovaps xmm2, [rsp+0x20]
000073baab9d57b6  vmovaps xmm3, [rsp+0x30]
000073baab9d57bc  vmovaps xmm4, [rsp+0x40]
000073baab9d57c2  vmovaps xmm5, [rsp+0x50]
000073baab9d57c8  vmovaps xmm6, [rsp+0x60]
000073baab9d57ce  vmovaps xmm7, [rsp+0x70]
000073baab9d57d4  vmovaps xmm8, [rsp+0x80]
000073baab9d57dd  vmovaps xmm9, [rsp+0x90]
000073baab9d57e6  vmovaps xmm10, [rsp+0xA0]
000073baab9d57ef  vmovaps xmm11, [rsp+0xB0]
000073baab9d57f8  vmovaps xmm12, [rsp+0xC0]
000073baab9d5801  vmovaps xmm13, [rsp+0xD0]
000073baab9d580a  vmovaps xmm14, [rsp+0xE0]
000073baab9d5813  add rsp, 0xF0
000073baab9d581a  pop r11
000073baab9d581c  pop r10
000073baab9d581e  pop r9
000073baab9d5820  pop r8
000073baab9d5822  pop rsi
000073baab9d5823  pop rdi
000073baab9d5824  pop rdx
000073baab9d5825  pop rcx
000073baab9d5826  pop rax
000073baab9d5827  add rsp, 0x08
000073baab9d582b  jmp 0x000073BAAB9D2EE3
000073baab9d5830  sub rsp, 0x08
000073baab9d5834  push rax
000073baab9d5835  push rcx
000073baab9d5836  push rdx
000073baab9d5837  push rdi
000073baab9d5838  push rsi
000073baab9d5839  push r8
000073baab9d583b  push r9
000073baab9d583d  push r10
000073baab9d583f  push r11
000073baab9d5841  sub rsp, 0xF0
000073baab9d5848  vmovaps [rsp], xmm0
000073baab9d584d  vmovaps [rsp+0x10], xmm1
000073baab9d5853  vmovaps [rsp+0x20], xmm2
000073baab9d5859  vmovaps [rsp+0x30], xmm3
000073baab9d585f  vmovaps [rsp+0x40], xmm4
000073baab9d5865  vmovaps [rsp+0x50], xmm5
000073baab9d586b  vmovaps [rsp+0x60], xmm6
000073baab9d5871  vmovaps [rsp+0x70], xmm7
000073baab9d5877  vmovaps [rsp+0x80], xmm8
000073baab9d5880  vmovaps [rsp+0x90], xmm9
000073baab9d5889  vmovaps [rsp+0xA0], xmm10
000073baab9d5892  vmovaps [rsp+0xB0], xmm12
000073baab9d589b  vmovaps [rsp+0xC0], xmm13
000073baab9d58a4  vmovaps [rsp+0xD0], xmm14
000073baab9d58ad  vmovaps [rsp+0xE0], xmm15
000073baab9d58b6  sub rsp, 0x30
000073baab9d58ba  movaps [rsp], xmm11
000073baab9d58bf  movaps [rsp+0x10], xmm6
000073baab9d58c4  movaps [rsp+0x20], xmm14
000073baab9d58ca  lea rdi, [rsp]
000073baab9d58ce  mov esi, 0x00
000073baab9d58d3  mov rax, 0x5F3F1062D530
000073baab9d58dd  call rax
000073baab9d58df  movaps xmm11, [rsp]
000073baab9d58e4  add rsp, 0x30
000073baab9d58e8  vmovaps xmm0, [rsp]
000073baab9d58ed  vmovaps xmm1, [rsp+0x10]
000073baab9d58f3  vmovaps xmm2, [rsp+0x20]
000073baab9d58f9  vmovaps xmm3, [rsp+0x30]
000073baab9d58ff  vmovaps xmm4, [rsp+0x40]
000073baab9d5905  vmovaps xmm5, [rsp+0x50]
000073baab9d590b  vmovaps xmm6, [rsp+0x60]
000073baab9d5911  vmovaps xmm7, [rsp+0x70]
000073baab9d5917  vmovaps xmm8, [rsp+0x80]
000073baab9d5920  vmovaps xmm9, [rsp+0x90]
000073baab9d5929  vmovaps xmm10, [rsp+0xA0]
000073baab9d5932  vmovaps xmm12, [rsp+0xB0]
000073baab9d593b  vmovaps xmm13, [rsp+0xC0]
000073baab9d5944  vmovaps xmm14, [rsp+0xD0]
000073baab9d594d  vmovaps xmm15, [rsp+0xE0]
000073baab9d5956  add rsp, 0xF0
000073baab9d595d  pop r11
000073baab9d595f  pop r10
000073baab9d5961  pop r9
000073baab9d5963  pop r8
000073baab9d5965  pop rsi
000073baab9d5966  pop rdi
000073baab9d5967  pop rdx
000073baab9d5968  pop rcx
000073baab9d5969  pop rax
000073baab9d596a  add rsp, 0x08
000073baab9d596e  jmp 0x000073BAAB9D2F5B
000073baab9d5973  call 0x000073BAAB7FF430
000073baab9d5978  jmp 0x000073BAAB9D2F65
000073baab9d597d  sub rsp, 0x08
000073baab9d5981  push rax
000073baab9d5982  push rcx
000073baab9d5983  push rdx
000073baab9d5984  push rdi
000073baab9d5985  push rsi
000073baab9d5986  push r8
000073baab9d5988  push r9
000073baab9d598a  push r10
000073baab9d598c  push r11
000073baab9d598e  sub rsp, 0xF0
000073baab9d5995  vmovaps [rsp], xmm0
000073baab9d599a  vmovaps [rsp+0x10], xmm1
000073baab9d59a0  vmovaps [rsp+0x20], xmm2
000073baab9d59a6  vmovaps [rsp+0x30], xmm3
000073baab9d59ac  vmovaps [rsp+0x40], xmm4
000073baab9d59b2  vmovaps [rsp+0x50], xmm5
000073baab9d59b8  vmovaps [rsp+0x60], xmm6
000073baab9d59be  vmovaps [rsp+0x70], xmm7
000073baab9d59c4  vmovaps [rsp+0x80], xmm8
000073baab9d59cd  vmovaps [rsp+0x90], xmm9
000073baab9d59d6  vmovaps [rsp+0xA0], xmm10
000073baab9d59df  vmovaps [rsp+0xB0], xmm11
000073baab9d59e8  vmovaps [rsp+0xC0], xmm12
000073baab9d59f1  vmovaps [rsp+0xD0], xmm13
000073baab9d59fa  vmovaps [rsp+0xE0], xmm15
000073baab9d5a03  sub rsp, 0x30
000073baab9d5a07  movaps [rsp], xmm14
000073baab9d5a0c  movaps [rsp+0x10], xmm6
000073baab9d5a11  movaps [rsp+0x20], xmm2
000073baab9d5a16  lea rdi, [rsp]
000073baab9d5a1a  mov esi, 0x00
000073baab9d5a1f  mov rax, 0x5F3F1062D530
000073baab9d5a29  call rax
000073baab9d5a2b  movaps xmm14, [rsp]
000073baab9d5a30  add rsp, 0x30
000073baab9d5a34  vmovaps xmm0, [rsp]
000073baab9d5a39  vmovaps xmm1, [rsp+0x10]
000073baab9d5a3f  vmovaps xmm2, [rsp+0x20]
000073baab9d5a45  vmovaps xmm3, [rsp+0x30]
000073baab9d5a4b  vmovaps xmm4, [rsp+0x40]
000073baab9d5a51  vmovaps xmm5, [rsp+0x50]
000073baab9d5a57  vmovaps xmm6, [rsp+0x60]
000073baab9d5a5d  vmovaps xmm7, [rsp+0x70]
000073baab9d5a63  vmovaps xmm8, [rsp+0x80]
000073baab9d5a6c  vmovaps xmm9, [rsp+0x90]
000073baab9d5a75  vmovaps xmm10, [rsp+0xA0]
000073baab9d5a7e  vmovaps xmm11, [rsp+0xB0]
000073baab9d5a87  vmovaps xmm12, [rsp+0xC0]
000073baab9d5a90  vmovaps xmm13, [rsp+0xD0]
000073baab9d5a99  vmovaps xmm15, [rsp+0xE0]
000073baab9d5aa2  add rsp, 0xF0
000073baab9d5aa9  pop r11
000073baab9d5aab  pop r10
000073baab9d5aad  pop r9
000073baab9d5aaf  pop r8
000073baab9d5ab1  pop rsi
000073baab9d5ab2  pop rdi
000073baab9d5ab3  pop rdx
000073baab9d5ab4  pop rcx
000073baab9d5ab5  pop rax
000073baab9d5ab6  add rsp, 0x08
000073baab9d5aba  jmp 0x000073BAAB9D2F99
000073baab9d5abf  sub rsp, 0x08
000073baab9d5ac3  push rax
000073baab9d5ac4  push rcx
000073baab9d5ac5  push rdx
000073baab9d5ac6  push rdi
000073baab9d5ac7  push rsi
000073baab9d5ac8  push r8
000073baab9d5aca  push r9
000073baab9d5acc  push r10
000073baab9d5ace  push r11
000073baab9d5ad0  sub rsp, 0xF0
000073baab9d5ad7  vmovaps [rsp], xmm0
000073baab9d5adc  vmovaps [rsp+0x10], xmm1
000073baab9d5ae2  vmovaps [rsp+0x20], xmm2
000073baab9d5ae8  vmovaps [rsp+0x30], xmm3
000073baab9d5aee  vmovaps [rsp+0x40], xmm4
000073baab9d5af4  vmovaps [rsp+0x50], xmm5
000073baab9d5afa  vmovaps [rsp+0x60], xmm7
000073baab9d5b00  vmovaps [rsp+0x70], xmm8
000073baab9d5b06  vmovaps [rsp+0x80], xmm9
000073baab9d5b0f  vmovaps [rsp+0x90], xmm10
000073baab9d5b18  vmovaps [rsp+0xA0], xmm11
000073baab9d5b21  vmovaps [rsp+0xB0], xmm12
000073baab9d5b2a  vmovaps [rsp+0xC0], xmm13
000073baab9d5b33  vmovaps [rsp+0xD0], xmm14
000073baab9d5b3c  vmovaps [rsp+0xE0], xmm15
000073baab9d5b45  sub rsp, 0x30
000073baab9d5b49  movaps [rsp], xmm6
000073baab9d5b4d  movaps [rsp+0x10], xmm5
000073baab9d5b52  movaps [rsp+0x20], xmm1
000073baab9d5b57  lea rdi, [rsp]
000073baab9d5b5b  mov esi, 0x00
000073baab9d5b60  mov rax, 0x5F3F1062D530
000073baab9d5b6a  call rax
000073baab9d5b6c  movaps xmm6, [rsp]
000073baab9d5b70  add rsp, 0x30
000073baab9d5b74  vmovaps xmm0, [rsp]
000073baab9d5b79  vmovaps xmm1, [rsp+0x10]
000073baab9d5b7f  vmovaps xmm2, [rsp+0x20]
000073baab9d5b85  vmovaps xmm3, [rsp+0x30]
000073baab9d5b8b  vmovaps xmm4, [rsp+0x40]
000073baab9d5b91  vmovaps xmm5, [rsp+0x50]
000073baab9d5b97  vmovaps xmm7, [rsp+0x60]
000073baab9d5b9d  vmovaps xmm8, [rsp+0x70]
000073baab9d5ba3  vmovaps xmm9, [rsp+0x80]
000073baab9d5bac  vmovaps xmm10, [rsp+0x90]
000073baab9d5bb5  vmovaps xmm11, [rsp+0xA0]
000073baab9d5bbe  vmovaps xmm12, [rsp+0xB0]
000073baab9d5bc7  vmovaps xmm13, [rsp+0xC0]
000073baab9d5bd0  vmovaps xmm14, [rsp+0xD0]
000073baab9d5bd9  vmovaps xmm15, [rsp+0xE0]
000073baab9d5be2  add rsp, 0xF0
000073baab9d5be9  pop r11
000073baab9d5beb  pop r10
000073baab9d5bed  pop r9
000073baab9d5bef  pop r8
000073baab9d5bf1  pop rsi
000073baab9d5bf2  pop rdi
000073baab9d5bf3  pop rdx
000073baab9d5bf4  pop rcx
000073baab9d5bf5  pop rax
000073baab9d5bf6  add rsp, 0x08
000073baab9d5bfa  jmp 0x000073BAAB9D2FBF
000073baab9d5bff  sub rsp, 0x08
000073baab9d5c03  push rax
000073baab9d5c04  push rcx
000073baab9d5c05  push rdx
000073baab9d5c06  push rdi
000073baab9d5c07  push rsi
000073baab9d5c08  push r8
000073baab9d5c0a  push r9
000073baab9d5c0c  push r10
000073baab9d5c0e  push r11
000073baab9d5c10  sub rsp, 0xF0
000073baab9d5c17  vmovaps [rsp], xmm0
000073baab9d5c1c  vmovaps [rsp+0x10], xmm2
000073baab9d5c22  vmovaps [rsp+0x20], xmm3
000073baab9d5c28  vmovaps [rsp+0x30], xmm4
000073baab9d5c2e  vmovaps [rsp+0x40], xmm5
000073baab9d5c34  vmovaps [rsp+0x50], xmm6
000073baab9d5c3a  vmovaps [rsp+0x60], xmm7
000073baab9d5c40  vmovaps [rsp+0x70], xmm8
000073baab9d5c46  vmovaps [rsp+0x80], xmm9
000073baab9d5c4f  vmovaps [rsp+0x90], xmm10
000073baab9d5c58  vmovaps [rsp+0xA0], xmm11
000073baab9d5c61  vmovaps [rsp+0xB0], xmm12
000073baab9d5c6a  vmovaps [rsp+0xC0], xmm13
000073baab9d5c73  vmovaps [rsp+0xD0], xmm14
000073baab9d5c7c  vmovaps [rsp+0xE0], xmm15
000073baab9d5c85  sub rsp, 0x30
000073baab9d5c89  movaps [rsp], xmm1
000073baab9d5c8d  movaps [rsp+0x10], xmm5
000073baab9d5c92  movaps [rsp+0x20], xmm13
000073baab9d5c98  lea rdi, [rsp]
000073baab9d5c9c  mov esi, 0x00
000073baab9d5ca1  mov rax, 0x5F3F1062D530
000073baab9d5cab  call rax
000073baab9d5cad  movaps xmm1, [rsp]
000073baab9d5cb1  add rsp, 0x30
000073baab9d5cb5  vmovaps xmm0, [rsp]
000073baab9d5cba  vmovaps xmm2, [rsp+0x10]
000073baab9d5cc0  vmovaps xmm3, [rsp+0x20]
000073baab9d5cc6  vmovaps xmm4, [rsp+0x30]
000073baab9d5ccc  vmovaps xmm5, [rsp+0x40]
000073baab9d5cd2  vmovaps xmm6, [rsp+0x50]
000073baab9d5cd8  vmovaps xmm7, [rsp+0x60]
000073baab9d5cde  vmovaps xmm8, [rsp+0x70]
000073baab9d5ce4  vmovaps xmm9, [rsp+0x80]
000073baab9d5ced  vmovaps xmm10, [rsp+0x90]
000073baab9d5cf6  vmovaps xmm11, [rsp+0xA0]
000073baab9d5cff  vmovaps xmm12, [rsp+0xB0]
000073baab9d5d08  vmovaps xmm13, [rsp+0xC0]
000073baab9d5d11  vmovaps xmm14, [rsp+0xD0]
000073baab9d5d1a  vmovaps xmm15, [rsp+0xE0]
000073baab9d5d23  add rsp, 0xF0
000073baab9d5d2a  pop r11
000073baab9d5d2c  pop r10
000073baab9d5d2e  pop r9
000073baab9d5d30  pop r8
000073baab9d5d32  pop rsi
000073baab9d5d33  pop rdi
000073baab9d5d34  pop rdx
000073baab9d5d35  pop rcx
000073baab9d5d36  pop rax
000073baab9d5d37  add rsp, 0x08
000073baab9d5d3b  jmp 0x000073BAAB9D2FDD
000073baab9d5d40  sub rsp, 0x08
000073baab9d5d44  push rax
000073baab9d5d45  push rcx
000073baab9d5d46  push rdx
000073baab9d5d47  push rdi
000073baab9d5d48  push rsi
000073baab9d5d49  push r8
000073baab9d5d4b  push r9
000073baab9d5d4d  push r10
000073baab9d5d4f  push r11
000073baab9d5d51  sub rsp, 0xF0
000073baab9d5d58  vmovaps [rsp], xmm0
000073baab9d5d5d  vmovaps [rsp+0x10], xmm1
000073baab9d5d63  vmovaps [rsp+0x20], xmm2
000073baab9d5d69  vmovaps [rsp+0x30], xmm3
000073baab9d5d6f  vmovaps [rsp+0x40], xmm4
000073baab9d5d75  vmovaps [rsp+0x50], xmm6
000073baab9d5d7b  vmovaps [rsp+0x60], xmm7
000073baab9d5d81  vmovaps [rsp+0x70], xmm8
000073baab9d5d87  vmovaps [rsp+0x80], xmm9
000073baab9d5d90  vmovaps [rsp+0x90], xmm10
000073baab9d5d99  vmovaps [rsp+0xA0], xmm11
000073baab9d5da2  vmovaps [rsp+0xB0], xmm12
000073baab9d5dab  vmovaps [rsp+0xC0], xmm13
000073baab9d5db4  vmovaps [rsp+0xD0], xmm14
000073baab9d5dbd  vmovaps [rsp+0xE0], xmm15
000073baab9d5dc6  sub rsp, 0x30
000073baab9d5dca  movaps [rsp], xmm5
000073baab9d5dce  movaps [rsp+0x10], xmm2
000073baab9d5dd3  movaps [rsp+0x20], xmm13
000073baab9d5dd9  lea rdi, [rsp]
000073baab9d5ddd  mov esi, 0x00
000073baab9d5de2  mov rax, 0x5F3F1062D530
000073baab9d5dec  call rax
000073baab9d5dee  movaps xmm5, [rsp]
000073baab9d5df2  add rsp, 0x30
000073baab9d5df6  vmovaps xmm0, [rsp]
000073baab9d5dfb  vmovaps xmm1, [rsp+0x10]
000073baab9d5e01  vmovaps xmm2, [rsp+0x20]
000073baab9d5e07  vmovaps xmm3, [rsp+0x30]
000073baab9d5e0d  vmovaps xmm4, [rsp+0x40]
000073baab9d5e13  vmovaps xmm6, [rsp+0x50]
000073baab9d5e19  vmovaps xmm7, [rsp+0x60]
000073baab9d5e1f  vmovaps xmm8, [rsp+0x70]
000073baab9d5e25  vmovaps xmm9, [rsp+0x80]
000073baab9d5e2e  vmovaps xmm10, [rsp+0x90]
000073baab9d5e37  vmovaps xmm11, [rsp+0xA0]
000073baab9d5e40  vmovaps xmm12, [rsp+0xB0]
000073baab9d5e49  vmovaps xmm13, [rsp+0xC0]
000073baab9d5e52  vmovaps xmm14, [rsp+0xD0]
000073baab9d5e5b  vmovaps xmm15, [rsp+0xE0]
000073baab9d5e64  add rsp, 0xF0
000073baab9d5e6b  pop r11
000073baab9d5e6d  pop r10
000073baab9d5e6f  pop r9
000073baab9d5e71  pop r8
000073baab9d5e73  pop rsi
000073baab9d5e74  pop rdi
000073baab9d5e75  pop rdx
000073baab9d5e76  pop rcx
000073baab9d5e77  pop rax
000073baab9d5e78  add rsp, 0x08
000073baab9d5e7c  jmp 0x000073BAAB9D3013
000073baab9d5e81  sub rsp, 0x08
000073baab9d5e85  push rax
000073baab9d5e86  push rcx
000073baab9d5e87  push rdx
000073baab9d5e88  push rdi
000073baab9d5e89  push rsi
000073baab9d5e8a  push r8
000073baab9d5e8c  push r9
000073baab9d5e8e  push r10
000073baab9d5e90  push r11
000073baab9d5e92  sub rsp, 0xF0
000073baab9d5e99  vmovaps [rsp], xmm0
000073baab9d5e9e  vmovaps [rsp+0x10], xmm1
000073baab9d5ea4  vmovaps [rsp+0x20], xmm2
000073baab9d5eaa  vmovaps [rsp+0x30], xmm3
000073baab9d5eb0  vmovaps [rsp+0x40], xmm4
000073baab9d5eb6  vmovaps [rsp+0x50], xmm5
000073baab9d5ebc  vmovaps [rsp+0x60], xmm6
000073baab9d5ec2  vmovaps [rsp+0x70], xmm7
000073baab9d5ec8  vmovaps [rsp+0x80], xmm8
000073baab9d5ed1  vmovaps [rsp+0x90], xmm9
000073baab9d5eda  vmovaps [rsp+0xA0], xmm10
000073baab9d5ee3  vmovaps [rsp+0xB0], xmm11
000073baab9d5eec  vmovaps [rsp+0xC0], xmm12
000073baab9d5ef5  vmovaps [rsp+0xD0], xmm14
000073baab9d5efe  vmovaps [rsp+0xE0], xmm15
000073baab9d5f07  sub rsp, 0x30
000073baab9d5f0b  movaps [rsp], xmm13
000073baab9d5f10  movaps [rsp+0x10], xmm10
000073baab9d5f16  movaps [rsp+0x20], xmm1
000073baab9d5f1b  lea rdi, [rsp]
000073baab9d5f1f  mov esi, 0x00
000073baab9d5f24  mov rax, 0x5F3F1062D530
000073baab9d5f2e  call rax
000073baab9d5f30  movaps xmm13, [rsp]
000073baab9d5f35  add rsp, 0x30
000073baab9d5f39  vmovaps xmm0, [rsp]
000073baab9d5f3e  vmovaps xmm1, [rsp+0x10]
000073baab9d5f44  vmovaps xmm2, [rsp+0x20]
000073baab9d5f4a  vmovaps xmm3, [rsp+0x30]
000073baab9d5f50  vmovaps xmm4, [rsp+0x40]
000073baab9d5f56  vmovaps xmm5, [rsp+0x50]
000073baab9d5f5c  vmovaps xmm6, [rsp+0x60]
000073baab9d5f62  vmovaps xmm7, [rsp+0x70]
000073baab9d5f68  vmovaps xmm8, [rsp+0x80]
000073baab9d5f71  vmovaps xmm9, [rsp+0x90]
000073baab9d5f7a  vmovaps xmm10, [rsp+0xA0]
000073baab9d5f83  vmovaps xmm11, [rsp+0xB0]
000073baab9d5f8c  vmovaps xmm12, [rsp+0xC0]
000073baab9d5f95  vmovaps xmm14, [rsp+0xD0]
000073baab9d5f9e  vmovaps xmm15, [rsp+0xE0]
000073baab9d5fa7  add rsp, 0xF0
000073baab9d5fae  pop r11
000073baab9d5fb0  pop r10
000073baab9d5fb2  pop r9
000073baab9d5fb4  pop r8
000073baab9d5fb6  pop rsi
000073baab9d5fb7  pop rdi
000073baab9d5fb8  pop rdx
000073baab9d5fb9  pop rcx
000073baab9d5fba  pop rax
000073baab9d5fbb  add rsp, 0x08
000073baab9d5fbf  jmp 0x000073BAAB9D303C
000073baab9d5fc4  sub rsp, 0x08
000073baab9d5fc8  push rax
000073baab9d5fc9  push rcx
000073baab9d5fca  push rdx
000073baab9d5fcb  push rdi
000073baab9d5fcc  push rsi
000073baab9d5fcd  push r8
000073baab9d5fcf  push r9
000073baab9d5fd1  push r10
000073baab9d5fd3  push r11
000073baab9d5fd5  sub rsp, 0xF0
000073baab9d5fdc  vmovaps [rsp], xmm0
000073baab9d5fe1  vmovaps [rsp+0x10], xmm2
000073baab9d5fe7  vmovaps [rsp+0x20], xmm3
000073baab9d5fed  vmovaps [rsp+0x30], xmm4
000073baab9d5ff3  vmovaps [rsp+0x40], xmm5
000073baab9d5ff9  vmovaps [rsp+0x50], xmm6
000073baab9d5fff  vmovaps [rsp+0x60], xmm7
000073baab9d6005  vmovaps [rsp+0x70], xmm8
000073baab9d600b  vmovaps [rsp+0x80], xmm9
000073baab9d6014  vmovaps [rsp+0x90], xmm10
000073baab9d601d  vmovaps [rsp+0xA0], xmm11
000073baab9d6026  vmovaps [rsp+0xB0], xmm12
000073baab9d602f  vmovaps [rsp+0xC0], xmm13
000073baab9d6038  vmovaps [rsp+0xD0], xmm14
000073baab9d6041  vmovaps [rsp+0xE0], xmm15
000073baab9d604a  sub rsp, 0x30
000073baab9d604e  movaps [rsp], xmm1
000073baab9d6052  movaps [rsp+0x10], xmm15
000073baab9d6058  movaps [rsp+0x20], xmm10
000073baab9d605e  lea rdi, [rsp]
000073baab9d6062  mov esi, 0x00
000073baab9d6067  mov rax, 0x5F3F1062D530
000073baab9d6071  call rax
000073baab9d6073  movaps xmm1, [rsp]
000073baab9d6077  add rsp, 0x30
000073baab9d607b  vmovaps xmm0, [rsp]
000073baab9d6080  vmovaps xmm2, [rsp+0x10]
000073baab9d6086  vmovaps xmm3, [rsp+0x20]
000073baab9d608c  vmovaps xmm4, [rsp+0x30]
000073baab9d6092  vmovaps xmm5, [rsp+0x40]
000073baab9d6098  vmovaps xmm6, [rsp+0x50]
000073baab9d609e  vmovaps xmm7, [rsp+0x60]
000073baab9d60a4  vmovaps xmm8, [rsp+0x70]
000073baab9d60aa  vmovaps xmm9, [rsp+0x80]
000073baab9d60b3  vmovaps xmm10, [rsp+0x90]
000073baab9d60bc  vmovaps xmm11, [rsp+0xA0]
000073baab9d60c5  vmovaps xmm12, [rsp+0xB0]
000073baab9d60ce  vmovaps xmm13, [rsp+0xC0]
000073baab9d60d7  vmovaps xmm14, [rsp+0xD0]
000073baab9d60e0  vmovaps xmm15, [rsp+0xE0]
000073baab9d60e9  add rsp, 0xF0
000073baab9d60f0  pop r11
000073baab9d60f2  pop r10
000073baab9d60f4  pop r9
000073baab9d60f6  pop r8
000073baab9d60f8  pop rsi
000073baab9d60f9  pop rdi
000073baab9d60fa  pop rdx
000073baab9d60fb  pop rcx
000073baab9d60fc  pop rax
000073baab9d60fd  add rsp, 0x08
000073baab9d6101  jmp 0x000073BAAB9D305B
000073baab9d6106  sub rsp, 0x08
000073baab9d610a  push rax
000073baab9d610b  push rcx
000073baab9d610c  push rdx
000073baab9d610d  push rdi
000073baab9d610e  push rsi
000073baab9d610f  push r8
000073baab9d6111  push r9
000073baab9d6113  push r10
000073baab9d6115  push r11
000073baab9d6117  sub rsp, 0xF0
000073baab9d611e  vmovaps [rsp], xmm0
000073baab9d6123  vmovaps [rsp+0x10], xmm1
000073baab9d6129  vmovaps [rsp+0x20], xmm2
000073baab9d612f  vmovaps [rsp+0x30], xmm3
000073baab9d6135  vmovaps [rsp+0x40], xmm4
000073baab9d613b  vmovaps [rsp+0x50], xmm5
000073baab9d6141  vmovaps [rsp+0x60], xmm6
000073baab9d6147  vmovaps [rsp+0x70], xmm7
000073baab9d614d  vmovaps [rsp+0x80], xmm8
000073baab9d6156  vmovaps [rsp+0x90], xmm9
000073baab9d615f  vmovaps [rsp+0xA0], xmm10
000073baab9d6168  vmovaps [rsp+0xB0], xmm11
000073baab9d6171  vmovaps [rsp+0xC0], xmm12
000073baab9d617a  vmovaps [rsp+0xD0], xmm13
000073baab9d6183  vmovaps [rsp+0xE0], xmm14
000073baab9d618c  sub rsp, 0x30
000073baab9d6190  movaps [rsp], xmm15
000073baab9d6195  movaps [rsp+0x10], xmm10
000073baab9d619b  movaps [rsp+0x20], xmm11
000073baab9d61a1  lea rdi, [rsp]
000073baab9d61a5  mov esi, 0x00
000073baab9d61aa  mov rax, 0x5F3F1062D530
000073baab9d61b4  call rax
000073baab9d61b6  movaps xmm15, [rsp]
000073baab9d61bb  add rsp, 0x30
000073baab9d61bf  vmovaps xmm0, [rsp]
000073baab9d61c4  vmovaps xmm1, [rsp+0x10]
000073baab9d61ca  vmovaps xmm2, [rsp+0x20]
000073baab9d61d0  vmovaps xmm3, [rsp+0x30]
000073baab9d61d6  vmovaps xmm4, [rsp+0x40]
000073baab9d61dc  vmovaps xmm5, [rsp+0x50]
000073baab9d61e2  vmovaps xmm6, [rsp+0x60]
000073baab9d61e8  vmovaps xmm7, [rsp+0x70]
000073baab9d61ee  vmovaps xmm8, [rsp+0x80]
000073baab9d61f7  vmovaps xmm9, [rsp+0x90]
000073baab9d6200  vmovaps xmm10, [rsp+0xA0]
000073baab9d6209  vmovaps xmm11, [rsp+0xB0]
000073baab9d6212  vmovaps xmm12, [rsp+0xC0]
000073baab9d621b  vmovaps xmm13, [rsp+0xD0]
000073baab9d6224  vmovaps xmm14, [rsp+0xE0]
000073baab9d622d  add rsp, 0xF0
000073baab9d6234  pop r11
000073baab9d6236  pop r10
000073baab9d6238  pop r9
000073baab9d623a  pop r8
000073baab9d623c  pop rsi
000073baab9d623d  pop rdi
000073baab9d623e  pop rdx
000073baab9d623f  pop rcx
000073baab9d6240  pop rax
000073baab9d6241  add rsp, 0x08
000073baab9d6245  jmp 0x000073BAAB9D307E
000073baab9d624a  sub rsp, 0x08
000073baab9d624e  push rax
000073baab9d624f  push rcx
000073baab9d6250  push rdx
000073baab9d6251  push rdi
000073baab9d6252  push rsi
000073baab9d6253  push r8
000073baab9d6255  push r9
000073baab9d6257  push r10
000073baab9d6259  push r11
000073baab9d625b  sub rsp, 0xF0
000073baab9d6262  vmovaps [rsp], xmm0
000073baab9d6267  vmovaps [rsp+0x10], xmm1
000073baab9d626d  vmovaps [rsp+0x20], xmm2
000073baab9d6273  vmovaps [rsp+0x30], xmm3
000073baab9d6279  vmovaps [rsp+0x40], xmm4
000073baab9d627f  vmovaps [rsp+0x50], xmm5
000073baab9d6285  vmovaps [rsp+0x60], xmm6
000073baab9d628b  vmovaps [rsp+0x70], xmm7
000073baab9d6291  vmovaps [rsp+0x80], xmm8
000073baab9d629a  vmovaps [rsp+0x90], xmm9
000073baab9d62a3  vmovaps [rsp+0xA0], xmm11
000073baab9d62ac  vmovaps [rsp+0xB0], xmm12
000073baab9d62b5  vmovaps [rsp+0xC0], xmm13
000073baab9d62be  vmovaps [rsp+0xD0], xmm14
000073baab9d62c7  vmovaps [rsp+0xE0], xmm15
000073baab9d62d0  sub rsp, 0x30
000073baab9d62d4  movaps [rsp], xmm10
000073baab9d62d9  movaps [rsp+0x10], xmm2
000073baab9d62de  movaps [rsp+0x20], xmm11
000073baab9d62e4  lea rdi, [rsp]
000073baab9d62e8  mov esi, 0x00
000073baab9d62ed  mov rax, 0x5F3F1062D530
000073baab9d62f7  call rax
000073baab9d62f9  movaps xmm10, [rsp]
000073baab9d62fe  add rsp, 0x30
000073baab9d6302  vmovaps xmm0, [rsp]
000073baab9d6307  vmovaps xmm1, [rsp+0x10]
000073baab9d630d  vmovaps xmm2, [rsp+0x20]
000073baab9d6313  vmovaps xmm3, [rsp+0x30]
000073baab9d6319  vmovaps xmm4, [rsp+0x40]
000073baab9d631f  vmovaps xmm5, [rsp+0x50]
000073baab9d6325  vmovaps xmm6, [rsp+0x60]
000073baab9d632b  vmovaps xmm7, [rsp+0x70]
000073baab9d6331  vmovaps xmm8, [rsp+0x80]
000073baab9d633a  vmovaps xmm9, [rsp+0x90]
000073baab9d6343  vmovaps xmm11, [rsp+0xA0]
000073baab9d634c  vmovaps xmm12, [rsp+0xB0]
000073baab9d6355  vmovaps xmm13, [rsp+0xC0]
000073baab9d635e  vmovaps xmm14, [rsp+0xD0]
000073baab9d6367  vmovaps xmm15, [rsp+0xE0]
000073baab9d6370  add rsp, 0xF0
000073baab9d6377  pop r11
000073baab9d6379  pop r10
000073baab9d637b  pop r9
000073baab9d637d  pop r8
000073baab9d637f  pop rsi
000073baab9d6380  pop rdi
000073baab9d6381  pop rdx
000073baab9d6382  pop rcx
000073baab9d6383  pop rax
000073baab9d6384  add rsp, 0x08
000073baab9d6388  jmp 0x000073BAAB9D30B6
000073baab9d638d  sub rsp, 0x08
000073baab9d6391  push rax
000073baab9d6392  push rcx
000073baab9d6393  push rdx
000073baab9d6394  push rdi
000073baab9d6395  push rsi
000073baab9d6396  push r8
000073baab9d6398  push r9
000073baab9d639a  push r10
000073baab9d639c  push r11
000073baab9d639e  sub rsp, 0xF0
000073baab9d63a5  vmovaps [rsp], xmm0
000073baab9d63aa  vmovaps [rsp+0x10], xmm1
000073baab9d63b0  vmovaps [rsp+0x20], xmm2
000073baab9d63b6  vmovaps [rsp+0x30], xmm3
000073baab9d63bc  vmovaps [rsp+0x40], xmm4
000073baab9d63c2  vmovaps [rsp+0x50], xmm5
000073baab9d63c8  vmovaps [rsp+0x60], xmm6
000073baab9d63ce  vmovaps [rsp+0x70], xmm7
000073baab9d63d4  vmovaps [rsp+0x80], xmm8
000073baab9d63dd  vmovaps [rsp+0x90], xmm9
000073baab9d63e6  vmovaps [rsp+0xA0], xmm10
000073baab9d63ef  vmovaps [rsp+0xB0], xmm12
000073baab9d63f8  vmovaps [rsp+0xC0], xmm13
000073baab9d6401  vmovaps [rsp+0xD0], xmm14
000073baab9d640a  vmovaps [rsp+0xE0], xmm15
000073baab9d6413  sub rsp, 0x30
000073baab9d6417  movaps [rsp], xmm11
000073baab9d641c  movaps [rsp+0x10], xmm2
000073baab9d6421  movaps [rsp+0x20], xmm1
000073baab9d6426  lea rdi, [rsp]
000073baab9d642a  mov esi, 0x00
000073baab9d642f  mov rax, 0x5F3F1062D530
000073baab9d6439  call rax
000073baab9d643b  movaps xmm11, [rsp]
000073baab9d6440  add rsp, 0x30
000073baab9d6444  vmovaps xmm0, [rsp]
000073baab9d6449  vmovaps xmm1, [rsp+0x10]
000073baab9d644f  vmovaps xmm2, [rsp+0x20]
000073baab9d6455  vmovaps xmm3, [rsp+0x30]
000073baab9d645b  vmovaps xmm4, [rsp+0x40]
000073baab9d6461  vmovaps xmm5, [rsp+0x50]
000073baab9d6467  vmovaps xmm6, [rsp+0x60]
000073baab9d646d  vmovaps xmm7, [rsp+0x70]
000073baab9d6473  vmovaps xmm8, [rsp+0x80]
000073baab9d647c  vmovaps xmm9, [rsp+0x90]
000073baab9d6485  vmovaps xmm10, [rsp+0xA0]
000073baab9d648e  vmovaps xmm12, [rsp+0xB0]
000073baab9d6497  vmovaps xmm13, [rsp+0xC0]
000073baab9d64a0  vmovaps xmm14, [rsp+0xD0]
000073baab9d64a9  vmovaps xmm15, [rsp+0xE0]
000073baab9d64b2  add rsp, 0xF0
000073baab9d64b9  pop r11
000073baab9d64bb  pop r10
000073baab9d64bd  pop r9
000073baab9d64bf  pop r8
000073baab9d64c1  pop rsi
000073baab9d64c2  pop rdi
000073baab9d64c3  pop rdx
000073baab9d64c4  pop rcx
000073baab9d64c5  pop rax
000073baab9d64c6  add rsp, 0x08
000073baab9d64ca  jmp 0x000073BAAB9D30F2
000073baab9d64cf  sub rsp, 0x08
000073baab9d64d3  push rax
000073baab9d64d4  push rcx
000073baab9d64d5  push rdx
000073baab9d64d6  push rdi
000073baab9d64d7  push rsi
000073baab9d64d8  push r8
000073baab9d64da  push r9
000073baab9d64dc  push r10
000073baab9d64de  push r11
000073baab9d64e0  sub rsp, 0xF0
000073baab9d64e7  vmovaps [rsp], xmm0
000073baab9d64ec  vmovaps [rsp+0x10], xmm2
000073baab9d64f2  vmovaps [rsp+0x20], xmm3
000073baab9d64f8  vmovaps [rsp+0x30], xmm4
000073baab9d64fe  vmovaps [rsp+0x40], xmm5
000073baab9d6504  vmovaps [rsp+0x50], xmm6
000073baab9d650a  vmovaps [rsp+0x60], xmm7
000073baab9d6510  vmovaps [rsp+0x70], xmm8
000073baab9d6516  vmovaps [rsp+0x80], xmm9
000073baab9d651f  vmovaps [rsp+0x90], xmm10
000073baab9d6528  vmovaps [rsp+0xA0], xmm11
000073baab9d6531  vmovaps [rsp+0xB0], xmm12
000073baab9d653a  vmovaps [rsp+0xC0], xmm13
000073baab9d6543  vmovaps [rsp+0xD0], xmm14
000073baab9d654c  vmovaps [rsp+0xE0], xmm15
000073baab9d6555  sub rsp, 0x30
000073baab9d6559  movaps [rsp], xmm1
000073baab9d655d  movaps [rsp+0x10], xmm14
000073baab9d6563  movaps [rsp+0x20], xmm6
000073baab9d6568  lea rdi, [rsp]
000073baab9d656c  mov esi, 0x00
000073baab9d6571  mov rax, 0x5F3F1062D530
000073baab9d657b  call rax
000073baab9d657d  movaps xmm1, [rsp]
000073baab9d6581  add rsp, 0x30
000073baab9d6585  vmovaps xmm0, [rsp]
000073baab9d658a  vmovaps xmm2, [rsp+0x10]
000073baab9d6590  vmovaps xmm3, [rsp+0x20]
000073baab9d6596  vmovaps xmm4, [rsp+0x30]
000073baab9d659c  vmovaps xmm5, [rsp+0x40]
000073baab9d65a2  vmovaps xmm6, [rsp+0x50]
000073baab9d65a8  vmovaps xmm7, [rsp+0x60]
000073baab9d65ae  vmovaps xmm8, [rsp+0x70]
000073baab9d65b4  vmovaps xmm9, [rsp+0x80]
000073baab9d65bd  vmovaps xmm10, [rsp+0x90]
000073baab9d65c6  vmovaps xmm11, [rsp+0xA0]
000073baab9d65cf  vmovaps xmm12, [rsp+0xB0]
000073baab9d65d8  vmovaps xmm13, [rsp+0xC0]
000073baab9d65e1  vmovaps xmm14, [rsp+0xD0]
000073baab9d65ea  vmovaps xmm15, [rsp+0xE0]
000073baab9d65f3  add rsp, 0xF0
000073baab9d65fa  pop r11
000073baab9d65fc  pop r10
000073baab9d65fe  pop r9
000073baab9d6600  pop r8
000073baab9d6602  pop rsi
000073baab9d6603  pop rdi
000073baab9d6604  pop rdx
000073baab9d6605  pop rcx
000073baab9d6606  pop rax
000073baab9d6607  add rsp, 0x08
000073baab9d660b  jmp 0x000073BAAB9D310B
000073baab9d6610  sub rsp, 0x08
000073baab9d6614  push rax
000073baab9d6615  push rcx
000073baab9d6616  push rdx
000073baab9d6617  push rdi
000073baab9d6618  push rsi
000073baab9d6619  push r8
000073baab9d661b  push r9
000073baab9d661d  push r10
000073baab9d661f  push r11
000073baab9d6621  sub rsp, 0xF0
000073baab9d6628  vmovaps [rsp], xmm0
000073baab9d662d  vmovaps [rsp+0x10], xmm1
000073baab9d6633  vmovaps [rsp+0x20], xmm2
000073baab9d6639  vmovaps [rsp+0x30], xmm3
000073baab9d663f  vmovaps [rsp+0x40], xmm4
000073baab9d6645  vmovaps [rsp+0x50], xmm5
000073baab9d664b  vmovaps [rsp+0x60], xmm6
000073baab9d6651  vmovaps [rsp+0x70], xmm7
000073baab9d6657  vmovaps [rsp+0x80], xmm8
000073baab9d6660  vmovaps [rsp+0x90], xmm9
000073baab9d6669  vmovaps [rsp+0xA0], xmm10
000073baab9d6672  vmovaps [rsp+0xB0], xmm11
000073baab9d667b  vmovaps [rsp+0xC0], xmm12
000073baab9d6684  vmovaps [rsp+0xD0], xmm13
000073baab9d668d  vmovaps [rsp+0xE0], xmm14
000073baab9d6696  sub rsp, 0x30
000073baab9d669a  movaps [rsp], xmm15
000073baab9d669f  movaps [rsp+0x10], xmm14
000073baab9d66a5  movaps [rsp+0x20], xmm5
000073baab9d66aa  lea rdi, [rsp]
000073baab9d66ae  mov esi, 0x00
000073baab9d66b3  mov rax, 0x5F3F1062D530
000073baab9d66bd  call rax
000073baab9d66bf  movaps xmm15, [rsp]
000073baab9d66c4  add rsp, 0x30
000073baab9d66c8  vmovaps xmm0, [rsp]
000073baab9d66cd  vmovaps xmm1, [rsp+0x10]
000073baab9d66d3  vmovaps xmm2, [rsp+0x20]
000073baab9d66d9  vmovaps xmm3, [rsp+0x30]
000073baab9d66df  vmovaps xmm4, [rsp+0x40]
000073baab9d66e5  vmovaps xmm5, [rsp+0x50]
000073baab9d66eb  vmovaps xmm6, [rsp+0x60]
000073baab9d66f1  vmovaps xmm7, [rsp+0x70]
000073baab9d66f7  vmovaps xmm8, [rsp+0x80]
000073baab9d6700  vmovaps xmm9, [rsp+0x90]
000073baab9d6709  vmovaps xmm10, [rsp+0xA0]
000073baab9d6712  vmovaps xmm11, [rsp+0xB0]
000073baab9d671b  vmovaps xmm12, [rsp+0xC0]
000073baab9d6724  vmovaps xmm13, [rsp+0xD0]
000073baab9d672d  vmovaps xmm14, [rsp+0xE0]
000073baab9d6736  add rsp, 0xF0
000073baab9d673d  pop r11
000073baab9d673f  pop r10
000073baab9d6741  pop r9
000073baab9d6743  pop r8
000073baab9d6745  pop rsi
000073baab9d6746  pop rdi
000073baab9d6747  pop rdx
000073baab9d6748  pop rcx
000073baab9d6749  pop rax
000073baab9d674a  add rsp, 0x08
000073baab9d674e  jmp 0x000073BAAB9D312B
000073baab9d6753  sub rsp, 0x08
000073baab9d6757  push rax
000073baab9d6758  push rcx
000073baab9d6759  push rdx
000073baab9d675a  push rdi
000073baab9d675b  push rsi
000073baab9d675c  push r8
000073baab9d675e  push r9
000073baab9d6760  push r10
000073baab9d6762  push r11
000073baab9d6764  sub rsp, 0xF0
000073baab9d676b  vmovaps [rsp], xmm0
000073baab9d6770  vmovaps [rsp+0x10], xmm1
000073baab9d6776  vmovaps [rsp+0x20], xmm2
000073baab9d677c  vmovaps [rsp+0x30], xmm3
000073baab9d6782  vmovaps [rsp+0x40], xmm4
000073baab9d6788  vmovaps [rsp+0x50], xmm5
000073baab9d678e  vmovaps [rsp+0x60], xmm7
000073baab9d6794  vmovaps [rsp+0x70], xmm8
000073baab9d679a  vmovaps [rsp+0x80], xmm9
000073baab9d67a3  vmovaps [rsp+0x90], xmm10
000073baab9d67ac  vmovaps [rsp+0xA0], xmm11
000073baab9d67b5  vmovaps [rsp+0xB0], xmm12
000073baab9d67be  vmovaps [rsp+0xC0], xmm13
000073baab9d67c7  vmovaps [rsp+0xD0], xmm14
000073baab9d67d0  vmovaps [rsp+0xE0], xmm15
000073baab9d67d9  sub rsp, 0x30
000073baab9d67dd  movaps [rsp], xmm6
000073baab9d67e1  movaps [rsp+0x10], xmm9
000073baab9d67e7  movaps [rsp+0x20], xmm14
000073baab9d67ed  lea rdi, [rsp]
000073baab9d67f1  mov esi, 0x00
000073baab9d67f6  mov rax, 0x5F3F1062D530
000073baab9d6800  call rax
000073baab9d6802  movaps xmm6, [rsp]
000073baab9d6806  add rsp, 0x30
000073baab9d680a  vmovaps xmm0, [rsp]
000073baab9d680f  vmovaps xmm1, [rsp+0x10]
000073baab9d6815  vmovaps xmm2, [rsp+0x20]
000073baab9d681b  vmovaps xmm3, [rsp+0x30]
000073baab9d6821  vmovaps xmm4, [rsp+0x40]
000073baab9d6827  vmovaps xmm5, [rsp+0x50]
000073baab9d682d  vmovaps xmm7, [rsp+0x60]
000073baab9d6833  vmovaps xmm8, [rsp+0x70]
000073baab9d6839  vmovaps xmm9, [rsp+0x80]
000073baab9d6842  vmovaps xmm10, [rsp+0x90]
000073baab9d684b  vmovaps xmm11, [rsp+0xA0]
000073baab9d6854  vmovaps xmm12, [rsp+0xB0]
000073baab9d685d  vmovaps xmm13, [rsp+0xC0]
000073baab9d6866  vmovaps xmm14, [rsp+0xD0]
000073baab9d686f  vmovaps xmm15, [rsp+0xE0]
000073baab9d6878  add rsp, 0xF0
000073baab9d687f  pop r11
000073baab9d6881  pop r10
000073baab9d6883  pop r9
000073baab9d6885  pop r8
000073baab9d6887  pop rsi
000073baab9d6888  pop rdi
000073baab9d6889  pop rdx
000073baab9d688a  pop rcx
000073baab9d688b  pop rax
000073baab9d688c  add rsp, 0x08
000073baab9d6890  jmp 0x000073BAAB9D3153
000073baab9d6895  sub rsp, 0x08
000073baab9d6899  push rax
000073baab9d689a  push rcx
000073baab9d689b  push rdx
000073baab9d689c  push rdi
000073baab9d689d  push rsi
000073baab9d689e  push r8
000073baab9d68a0  push r9
000073baab9d68a2  push r10
000073baab9d68a4  push r11
000073baab9d68a6  sub rsp, 0xF0
000073baab9d68ad  vmovaps [rsp], xmm0
000073baab9d68b2  vmovaps [rsp+0x10], xmm1
000073baab9d68b8  vmovaps [rsp+0x20], xmm2
000073baab9d68be  vmovaps [rsp+0x30], xmm3
000073baab9d68c4  vmovaps [rsp+0x40], xmm4
000073baab9d68ca  vmovaps [rsp+0x50], xmm5
000073baab9d68d0  vmovaps [rsp+0x60], xmm6
000073baab9d68d6  vmovaps [rsp+0x70], xmm7
000073baab9d68dc  vmovaps [rsp+0x80], xmm8
000073baab9d68e5  vmovaps [rsp+0x90], xmm9
000073baab9d68ee  vmovaps [rsp+0xA0], xmm10
000073baab9d68f7  vmovaps [rsp+0xB0], xmm11
000073baab9d6900  vmovaps [rsp+0xC0], xmm12
000073baab9d6909  vmovaps [rsp+0xD0], xmm13
000073baab9d6912  vmovaps [rsp+0xE0], xmm15
000073baab9d691b  sub rsp, 0x30
000073baab9d691f  movaps [rsp], xmm14
000073baab9d6924  movaps [rsp+0x10], xmm9
000073baab9d692a  movaps [rsp+0x20], xmm13
000073baab9d6930  lea rdi, [rsp]
000073baab9d6934  mov esi, 0x00
000073baab9d6939  mov rax, 0x5F3F1062D530
000073baab9d6943  call rax
000073baab9d6945  movaps xmm14, [rsp]
000073baab9d694a  add rsp, 0x30
000073baab9d694e  vmovaps xmm0, [rsp]
000073baab9d6953  vmovaps xmm1, [rsp+0x10]
000073baab9d6959  vmovaps xmm2, [rsp+0x20]
000073baab9d695f  vmovaps xmm3, [rsp+0x30]
000073baab9d6965  vmovaps xmm4, [rsp+0x40]
000073baab9d696b  vmovaps xmm5, [rsp+0x50]
000073baab9d6971  vmovaps xmm6, [rsp+0x60]
000073baab9d6977  vmovaps xmm7, [rsp+0x70]
000073baab9d697d  vmovaps xmm8, [rsp+0x80]
000073baab9d6986  vmovaps xmm9, [rsp+0x90]
000073baab9d698f  vmovaps xmm10, [rsp+0xA0]
000073baab9d6998  vmovaps xmm11, [rsp+0xB0]
000073baab9d69a1  vmovaps xmm12, [rsp+0xC0]
000073baab9d69aa  vmovaps xmm13, [rsp+0xD0]
000073baab9d69b3  vmovaps xmm15, [rsp+0xE0]
000073baab9d69bc  add rsp, 0xF0
000073baab9d69c3  pop r11
000073baab9d69c5  pop r10
000073baab9d69c7  pop r9
000073baab9d69c9  pop r8
000073baab9d69cb  pop rsi
000073baab9d69cc  pop rdi
000073baab9d69cd  pop rdx
000073baab9d69ce  pop rcx
000073baab9d69cf  pop rax
000073baab9d69d0  add rsp, 0x08
000073baab9d69d4  jmp 0x000073BAAB9D3176
000073baab9d69d9  sub rsp, 0x08
000073baab9d69dd  push rax
000073baab9d69de  push rcx
000073baab9d69df  push rdx
000073baab9d69e0  push rdi
000073baab9d69e1  push rsi
000073baab9d69e2  push r8
000073baab9d69e4  push r9
000073baab9d69e6  push r10
000073baab9d69e8  push r11
000073baab9d69ea  sub rsp, 0xF0
000073baab9d69f1  vmovaps [rsp], xmm0
000073baab9d69f6  vmovaps [rsp+0x10], xmm1
000073baab9d69fc  vmovaps [rsp+0x20], xmm2
000073baab9d6a02  vmovaps [rsp+0x30], xmm3
000073baab9d6a08  vmovaps [rsp+0x40], xmm4
000073baab9d6a0e  vmovaps [rsp+0x50], xmm5
000073baab9d6a14  vmovaps [rsp+0x60], xmm6
000073baab9d6a1a  vmovaps [rsp+0x70], xmm7
000073baab9d6a20  vmovaps [rsp+0x80], xmm8
000073baab9d6a29  vmovaps [rsp+0x90], xmm9
000073baab9d6a32  vmovaps [rsp+0xA0], xmm10
000073baab9d6a3b  vmovaps [rsp+0xB0], xmm11
000073baab9d6a44  vmovaps [rsp+0xC0], xmm12
000073baab9d6a4d  vmovaps [rsp+0xD0], xmm14
000073baab9d6a56  vmovaps [rsp+0xE0], xmm15
000073baab9d6a5f  sub rsp, 0x30
000073baab9d6a63  movaps [rsp], xmm13
000073baab9d6a68  movaps [rsp+0x10], xmm9
000073baab9d6a6e  movaps [rsp+0x20], xmm10
000073baab9d6a74  lea rdi, [rsp]
000073baab9d6a78  mov esi, 0x00
000073baab9d6a7d  mov rax, 0x5F3F1062D530
000073baab9d6a87  call rax
000073baab9d6a89  movaps xmm13, [rsp]
000073baab9d6a8e  add rsp, 0x30
000073baab9d6a92  vmovaps xmm0, [rsp]
000073baab9d6a97  vmovaps xmm1, [rsp+0x10]
000073baab9d6a9d  vmovaps xmm2, [rsp+0x20]
000073baab9d6aa3  vmovaps xmm3, [rsp+0x30]
000073baab9d6aa9  vmovaps xmm4, [rsp+0x40]
000073baab9d6aaf  vmovaps xmm5, [rsp+0x50]
000073baab9d6ab5  vmovaps xmm6, [rsp+0x60]
000073baab9d6abb  vmovaps xmm7, [rsp+0x70]
000073baab9d6ac1  vmovaps xmm8, [rsp+0x80]
000073baab9d6aca  vmovaps xmm9, [rsp+0x90]
000073baab9d6ad3  vmovaps xmm10, [rsp+0xA0]
000073baab9d6adc  vmovaps xmm11, [rsp+0xB0]
000073baab9d6ae5  vmovaps xmm12, [rsp+0xC0]
000073baab9d6aee  vmovaps xmm14, [rsp+0xD0]
000073baab9d6af7  vmovaps xmm15, [rsp+0xE0]
000073baab9d6b00  add rsp, 0xF0
000073baab9d6b07  pop r11
000073baab9d6b09  pop r10
000073baab9d6b0b  pop r9
000073baab9d6b0d  pop r8
000073baab9d6b0f  pop rsi
000073baab9d6b10  pop rdi
000073baab9d6b11  pop rdx
000073baab9d6b12  pop rcx
000073baab9d6b13  pop rax
000073baab9d6b14  add rsp, 0x08
000073baab9d6b18  jmp 0x000073BAAB9D3196
000073baab9d6b1d  call 0x000073BAAB80AFE0
000073baab9d6b22  jmp 0x000073BAAB9D31EB
000073baab9d6b27  sub rsp, 0x08
000073baab9d6b2b  push rax
000073baab9d6b2c  push rcx
000073baab9d6b2d  push rdx
000073baab9d6b2e  push rdi
000073baab9d6b2f  push rsi
000073baab9d6b30  push r8
000073baab9d6b32  push r9
000073baab9d6b34  push r10
000073baab9d6b36  push r11
000073baab9d6b38  sub rsp, 0xF0
000073baab9d6b3f  vmovaps [rsp], xmm0
000073baab9d6b44  vmovaps [rsp+0x10], xmm1
000073baab9d6b4a  vmovaps [rsp+0x20], xmm2
000073baab9d6b50  vmovaps [rsp+0x30], xmm3
000073baab9d6b56  vmovaps [rsp+0x40], xmm4
000073baab9d6b5c  vmovaps [rsp+0x50], xmm5
000073baab9d6b62  vmovaps [rsp+0x60], xmm6
000073baab9d6b68  vmovaps [rsp+0x70], xmm7
000073baab9d6b6e  vmovaps [rsp+0x80], xmm8
000073baab9d6b77  vmovaps [rsp+0x90], xmm10
000073baab9d6b80  vmovaps [rsp+0xA0], xmm11
000073baab9d6b89  vmovaps [rsp+0xB0], xmm12
000073baab9d6b92  vmovaps [rsp+0xC0], xmm13
000073baab9d6b9b  vmovaps [rsp+0xD0], xmm14
000073baab9d6ba4  vmovaps [rsp+0xE0], xmm15
000073baab9d6bad  sub rsp, 0x30
000073baab9d6bb1  movaps [rsp], xmm9
000073baab9d6bb6  movaps [rsp+0x10], xmm8
000073baab9d6bbc  movaps [rsp+0x20], xmm10
000073baab9d6bc2  lea rdi, [rsp]
000073baab9d6bc6  mov esi, 0x00
000073baab9d6bcb  mov rax, 0x5F3F1062D530
000073baab9d6bd5  call rax
000073baab9d6bd7  movaps xmm9, [rsp]
000073baab9d6bdc  add rsp, 0x30
000073baab9d6be0  vmovaps xmm0, [rsp]
000073baab9d6be5  vmovaps xmm1, [rsp+0x10]
000073baab9d6beb  vmovaps xmm2, [rsp+0x20]
000073baab9d6bf1  vmovaps xmm3, [rsp+0x30]
000073baab9d6bf7  vmovaps xmm4, [rsp+0x40]
000073baab9d6bfd  vmovaps xmm5, [rsp+0x50]
000073baab9d6c03  vmovaps xmm6, [rsp+0x60]
000073baab9d6c09  vmovaps xmm7, [rsp+0x70]
000073baab9d6c0f  vmovaps xmm8, [rsp+0x80]
000073baab9d6c18  vmovaps xmm10, [rsp+0x90]
000073baab9d6c21  vmovaps xmm11, [rsp+0xA0]
000073baab9d6c2a  vmovaps xmm12, [rsp+0xB0]
000073baab9d6c33  vmovaps xmm13, [rsp+0xC0]
000073baab9d6c3c  vmovaps xmm14, [rsp+0xD0]
000073baab9d6c45  vmovaps xmm15, [rsp+0xE0]
000073baab9d6c4e  add rsp, 0xF0
000073baab9d6c55  pop r11
000073baab9d6c57  pop r10
000073baab9d6c59  pop r9
000073baab9d6c5b  pop r8
000073baab9d6c5d  pop rsi
000073baab9d6c5e  pop rdi
000073baab9d6c5f  pop rdx
000073baab9d6c60  pop rcx
000073baab9d6c61  pop rax
000073baab9d6c62  add rsp, 0x08
000073baab9d6c66  jmp 0x000073BAAB9D321C
000073baab9d6c6b  sub rsp, 0x08
000073baab9d6c6f  push rax
000073baab9d6c70  push rcx
000073baab9d6c71  push rdx
000073baab9d6c72  push rdi
000073baab9d6c73  push rsi
000073baab9d6c74  push r8
000073baab9d6c76  push r9
000073baab9d6c78  push r10
000073baab9d6c7a  push r11
000073baab9d6c7c  sub rsp, 0xF0
000073baab9d6c83  vmovaps [rsp], xmm0
000073baab9d6c88  vmovaps [rsp+0x10], xmm1
000073baab9d6c8e  vmovaps [rsp+0x20], xmm2
000073baab9d6c94  vmovaps [rsp+0x30], xmm3
000073baab9d6c9a  vmovaps [rsp+0x40], xmm4
000073baab9d6ca0  vmovaps [rsp+0x50], xmm5
000073baab9d6ca6  vmovaps [rsp+0x60], xmm6
000073baab9d6cac  vmovaps [rsp+0x70], xmm7
000073baab9d6cb2  vmovaps [rsp+0x80], xmm8
000073baab9d6cbb  vmovaps [rsp+0x90], xmm9
000073baab9d6cc4  vmovaps [rsp+0xA0], xmm11
000073baab9d6ccd  vmovaps [rsp+0xB0], xmm12
000073baab9d6cd6  vmovaps [rsp+0xC0], xmm13
000073baab9d6cdf  vmovaps [rsp+0xD0], xmm14
000073baab9d6ce8  vmovaps [rsp+0xE0], xmm15
000073baab9d6cf1  sub rsp, 0x30
000073baab9d6cf5  movaps [rsp], xmm10
000073baab9d6cfa  movaps [rsp+0x10], xmm1
000073baab9d6cff  movaps [rsp+0x20], xmm11
000073baab9d6d05  lea rdi, [rsp]
000073baab9d6d09  mov esi, 0x00
000073baab9d6d0e  mov rax, 0x5F3F1062D530
000073baab9d6d18  call rax
000073baab9d6d1a  movaps xmm10, [rsp]
000073baab9d6d1f  add rsp, 0x30
000073baab9d6d23  vmovaps xmm0, [rsp]
000073baab9d6d28  vmovaps xmm1, [rsp+0x10]
000073baab9d6d2e  vmovaps xmm2, [rsp+0x20]
000073baab9d6d34  vmovaps xmm3, [rsp+0x30]
000073baab9d6d3a  vmovaps xmm4, [rsp+0x40]
000073baab9d6d40  vmovaps xmm5, [rsp+0x50]
000073baab9d6d46  vmovaps xmm6, [rsp+0x60]
000073baab9d6d4c  vmovaps xmm7, [rsp+0x70]
000073baab9d6d52  vmovaps xmm8, [rsp+0x80]
000073baab9d6d5b  vmovaps xmm9, [rsp+0x90]
000073baab9d6d64  vmovaps xmm11, [rsp+0xA0]
000073baab9d6d6d  vmovaps xmm12, [rsp+0xB0]
000073baab9d6d76  vmovaps xmm13, [rsp+0xC0]
000073baab9d6d7f  vmovaps xmm14, [rsp+0xD0]
000073baab9d6d88  vmovaps xmm15, [rsp+0xE0]
000073baab9d6d91  add rsp, 0xF0
000073baab9d6d98  pop r11
000073baab9d6d9a  pop r10
000073baab9d6d9c  pop r9
000073baab9d6d9e  pop r8
000073baab9d6da0  pop rsi
000073baab9d6da1  pop rdi
000073baab9d6da2  pop rdx
000073baab9d6da3  pop rcx
000073baab9d6da4  pop rax
000073baab9d6da5  add rsp, 0x08
000073baab9d6da9  jmp 0x000073BAAB9D3237
000073baab9d6dae  sub rsp, 0x08
000073baab9d6db2  push rax
000073baab9d6db3  push rcx
000073baab9d6db4  push rdx
000073baab9d6db5  push rdi
000073baab9d6db6  push rsi
000073baab9d6db7  push r8
000073baab9d6db9  push r9
000073baab9d6dbb  push r10
000073baab9d6dbd  push r11
000073baab9d6dbf  sub rsp, 0xF0
000073baab9d6dc6  vmovaps [rsp], xmm0
000073baab9d6dcb  vmovaps [rsp+0x10], xmm2
000073baab9d6dd1  vmovaps [rsp+0x20], xmm3
000073baab9d6dd7  vmovaps [rsp+0x30], xmm4
000073baab9d6ddd  vmovaps [rsp+0x40], xmm5
000073baab9d6de3  vmovaps [rsp+0x50], xmm6
000073baab9d6de9  vmovaps [rsp+0x60], xmm7
000073baab9d6def  vmovaps [rsp+0x70], xmm8
000073baab9d6df5  vmovaps [rsp+0x80], xmm9
000073baab9d6dfe  vmovaps [rsp+0x90], xmm10
000073baab9d6e07  vmovaps [rsp+0xA0], xmm11
000073baab9d6e10  vmovaps [rsp+0xB0], xmm12
000073baab9d6e19  vmovaps [rsp+0xC0], xmm13
000073baab9d6e22  vmovaps [rsp+0xD0], xmm14
000073baab9d6e2b  vmovaps [rsp+0xE0], xmm15
000073baab9d6e34  sub rsp, 0x30
000073baab9d6e38  movaps [rsp], xmm1
000073baab9d6e3c  movaps [rsp+0x10], xmm15
000073baab9d6e42  movaps [rsp+0x20], xmm6
000073baab9d6e47  lea rdi, [rsp]
000073baab9d6e4b  mov esi, 0x00
000073baab9d6e50  mov rax, 0x5F3F1062D530
000073baab9d6e5a  call rax
000073baab9d6e5c  movaps xmm1, [rsp]
000073baab9d6e60  add rsp, 0x30
000073baab9d6e64  vmovaps xmm0, [rsp]
000073baab9d6e69  vmovaps xmm2, [rsp+0x10]
000073baab9d6e6f  vmovaps xmm3, [rsp+0x20]
000073baab9d6e75  vmovaps xmm4, [rsp+0x30]
000073baab9d6e7b  vmovaps xmm5, [rsp+0x40]
000073baab9d6e81  vmovaps xmm6, [rsp+0x50]
000073baab9d6e87  vmovaps xmm7, [rsp+0x60]
000073baab9d6e8d  vmovaps xmm8, [rsp+0x70]
000073baab9d6e93  vmovaps xmm9, [rsp+0x80]
000073baab9d6e9c  vmovaps xmm10, [rsp+0x90]
000073baab9d6ea5  vmovaps xmm11, [rsp+0xA0]
000073baab9d6eae  vmovaps xmm12, [rsp+0xB0]
000073baab9d6eb7  vmovaps xmm13, [rsp+0xC0]
000073baab9d6ec0  vmovaps xmm14, [rsp+0xD0]
000073baab9d6ec9  vmovaps xmm15, [rsp+0xE0]
000073baab9d6ed2  add rsp, 0xF0
000073baab9d6ed9  pop r11
000073baab9d6edb  pop r10
000073baab9d6edd  pop r9
000073baab9d6edf  pop r8
000073baab9d6ee1  pop rsi
000073baab9d6ee2  pop rdi
000073baab9d6ee3  pop rdx
000073baab9d6ee4  pop rcx
000073baab9d6ee5  pop rax
000073baab9d6ee6  add rsp, 0x08
000073baab9d6eea  jmp 0x000073BAAB9D3250
000073baab9d6eef  sub rsp, 0x08
000073baab9d6ef3  push rax
000073baab9d6ef4  push rcx
000073baab9d6ef5  push rdx
000073baab9d6ef6  push rdi
000073baab9d6ef7  push rsi
000073baab9d6ef8  push r8
000073baab9d6efa  push r9
000073baab9d6efc  push r10
000073baab9d6efe  push r11
000073baab9d6f00  sub rsp, 0xF0
000073baab9d6f07  vmovaps [rsp], xmm0
000073baab9d6f0c  vmovaps [rsp+0x10], xmm1
000073baab9d6f12  vmovaps [rsp+0x20], xmm2
000073baab9d6f18  vmovaps [rsp+0x30], xmm3
000073baab9d6f1e  vmovaps [rsp+0x40], xmm4
000073baab9d6f24  vmovaps [rsp+0x50], xmm5
000073baab9d6f2a  vmovaps [rsp+0x60], xmm6
000073baab9d6f30  vmovaps [rsp+0x70], xmm7
000073baab9d6f36  vmovaps [rsp+0x80], xmm8
000073baab9d6f3f  vmovaps [rsp+0x90], xmm9
000073baab9d6f48  vmovaps [rsp+0xA0], xmm10
000073baab9d6f51  vmovaps [rsp+0xB0], xmm12
000073baab9d6f5a  vmovaps [rsp+0xC0], xmm13
000073baab9d6f63  vmovaps [rsp+0xD0], xmm14
000073baab9d6f6c  vmovaps [rsp+0xE0], xmm15
000073baab9d6f75  sub rsp, 0x30
000073baab9d6f79  movaps [rsp], xmm11
000073baab9d6f7e  movaps [rsp+0x10], xmm12
000073baab9d6f84  movaps [rsp+0x20], xmm15
000073baab9d6f8a  lea rdi, [rsp]
000073baab9d6f8e  mov esi, 0x00
000073baab9d6f93  mov rax, 0x5F3F1062D530
000073baab9d6f9d  call rax
000073baab9d6f9f  movaps xmm11, [rsp]
000073baab9d6fa4  add rsp, 0x30
000073baab9d6fa8  vmovaps xmm0, [rsp]
000073baab9d6fad  vmovaps xmm1, [rsp+0x10]
000073baab9d6fb3  vmovaps xmm2, [rsp+0x20]
000073baab9d6fb9  vmovaps xmm3, [rsp+0x30]
000073baab9d6fbf  vmovaps xmm4, [rsp+0x40]
000073baab9d6fc5  vmovaps xmm5, [rsp+0x50]
000073baab9d6fcb  vmovaps xmm6, [rsp+0x60]
000073baab9d6fd1  vmovaps xmm7, [rsp+0x70]
000073baab9d6fd7  vmovaps xmm8, [rsp+0x80]
000073baab9d6fe0  vmovaps xmm9, [rsp+0x90]
000073baab9d6fe9  vmovaps xmm10, [rsp+0xA0]
000073baab9d6ff2  vmovaps xmm12, [rsp+0xB0]
000073baab9d6ffb  vmovaps xmm13, [rsp+0xC0]
000073baab9d7004  vmovaps xmm14, [rsp+0xD0]
000073baab9d700d  vmovaps xmm15, [rsp+0xE0]
000073baab9d7016  add rsp, 0xF0
000073baab9d701d  pop r11
000073baab9d701f  pop r10
000073baab9d7021  pop r9
000073baab9d7023  pop r8
000073baab9d7025  pop rsi
000073baab9d7026  pop rdi
000073baab9d7027  pop rdx
000073baab9d7028  pop rcx
000073baab9d7029  pop rax
000073baab9d702a  add rsp, 0x08
000073baab9d702e  jmp 0x000073BAAB9D327A
000073baab9d7033  sub rsp, 0x08
000073baab9d7037  push rax
000073baab9d7038  push rcx
000073baab9d7039  push rdx
000073baab9d703a  push rdi
000073baab9d703b  push rsi
000073baab9d703c  push r8
000073baab9d703e  push r9
000073baab9d7040  push r10
000073baab9d7042  push r11
000073baab9d7044  sub rsp, 0xF0
000073baab9d704b  vmovaps [rsp], xmm0
000073baab9d7050  vmovaps [rsp+0x10], xmm1
000073baab9d7056  vmovaps [rsp+0x20], xmm2
000073baab9d705c  vmovaps [rsp+0x30], xmm3
000073baab9d7062  vmovaps [rsp+0x40], xmm4
000073baab9d7068  vmovaps [rsp+0x50], xmm5
000073baab9d706e  vmovaps [rsp+0x60], xmm6
000073baab9d7074  vmovaps [rsp+0x70], xmm7
000073baab9d707a  vmovaps [rsp+0x80], xmm8
000073baab9d7083  vmovaps [rsp+0x90], xmm9
000073baab9d708c  vmovaps [rsp+0xA0], xmm10
000073baab9d7095  vmovaps [rsp+0xB0], xmm11
000073baab9d709e  vmovaps [rsp+0xC0], xmm13
000073baab9d70a7  vmovaps [rsp+0xD0], xmm14
000073baab9d70b0  vmovaps [rsp+0xE0], xmm15
000073baab9d70b9  sub rsp, 0x30
000073baab9d70bd  movaps [rsp], xmm12
000073baab9d70c2  movaps [rsp+0x10], xmm8
000073baab9d70c8  movaps [rsp+0x20], xmm15
000073baab9d70ce  lea rdi, [rsp]
000073baab9d70d2  mov esi, 0x00
000073baab9d70d7  mov rax, 0x5F3F1062D530
000073baab9d70e1  call rax
000073baab9d70e3  movaps xmm12, [rsp]
000073baab9d70e8  add rsp, 0x30
000073baab9d70ec  vmovaps xmm0, [rsp]
000073baab9d70f1  vmovaps xmm1, [rsp+0x10]
000073baab9d70f7  vmovaps xmm2, [rsp+0x20]
000073baab9d70fd  vmovaps xmm3, [rsp+0x30]
000073baab9d7103  vmovaps xmm4, [rsp+0x40]
000073baab9d7109  vmovaps xmm5, [rsp+0x50]
000073baab9d710f  vmovaps xmm6, [rsp+0x60]
000073baab9d7115  vmovaps xmm7, [rsp+0x70]
000073baab9d711b  vmovaps xmm8, [rsp+0x80]
000073baab9d7124  vmovaps xmm9, [rsp+0x90]
000073baab9d712d  vmovaps xmm10, [rsp+0xA0]
000073baab9d7136  vmovaps xmm11, [rsp+0xB0]
000073baab9d713f  vmovaps xmm13, [rsp+0xC0]
000073baab9d7148  vmovaps xmm14, [rsp+0xD0]
000073baab9d7151  vmovaps xmm15, [rsp+0xE0]
000073baab9d715a  add rsp, 0xF0
000073baab9d7161  pop r11
000073baab9d7163  pop r10
000073baab9d7165  pop r9
000073baab9d7167  pop r8
000073baab9d7169  pop rsi
000073baab9d716a  pop rdi
000073baab9d716b  pop rdx
000073baab9d716c  pop rcx
000073baab9d716d  pop rax
000073baab9d716e  add rsp, 0x08
000073baab9d7172  jmp 0x000073BAAB9D32A9
000073baab9d7177  sub rsp, 0x08
000073baab9d717b  push rax
000073baab9d717c  push rcx
000073baab9d717d  push rdx
000073baab9d717e  push rdi
000073baab9d717f  push rsi
000073baab9d7180  push r8
000073baab9d7182  push r9
000073baab9d7184  push r10
000073baab9d7186  push r11
000073baab9d7188  sub rsp, 0xF0
000073baab9d718f  vmovaps [rsp], xmm0
000073baab9d7194  vmovaps [rsp+0x10], xmm1
000073baab9d719a  vmovaps [rsp+0x20], xmm2
000073baab9d71a0  vmovaps [rsp+0x30], xmm3
000073baab9d71a6  vmovaps [rsp+0x40], xmm4
000073baab9d71ac  vmovaps [rsp+0x50], xmm5
000073baab9d71b2  vmovaps [rsp+0x60], xmm6
000073baab9d71b8  vmovaps [rsp+0x70], xmm7
000073baab9d71be  vmovaps [rsp+0x80], xmm9
000073baab9d71c7  vmovaps [rsp+0x90], xmm10
000073baab9d71d0  vmovaps [rsp+0xA0], xmm11
000073baab9d71d9  vmovaps [rsp+0xB0], xmm12
000073baab9d71e2  vmovaps [rsp+0xC0], xmm13
000073baab9d71eb  vmovaps [rsp+0xD0], xmm14
000073baab9d71f4  vmovaps [rsp+0xE0], xmm15
000073baab9d71fd  sub rsp, 0x30
000073baab9d7201  movaps [rsp], xmm8
000073baab9d7206  movaps [rsp+0x10], xmm7
000073baab9d720b  movaps [rsp+0x20], xmm15
000073baab9d7211  lea rdi, [rsp]
000073baab9d7215  mov esi, 0x00
000073baab9d721a  mov rax, 0x5F3F1062D530
000073baab9d7224  call rax
000073baab9d7226  movaps xmm8, [rsp]
000073baab9d722b  add rsp, 0x30
000073baab9d722f  vmovaps xmm0, [rsp]
000073baab9d7234  vmovaps xmm1, [rsp+0x10]
000073baab9d723a  vmovaps xmm2, [rsp+0x20]
000073baab9d7240  vmovaps xmm3, [rsp+0x30]
000073baab9d7246  vmovaps xmm4, [rsp+0x40]
000073baab9d724c  vmovaps xmm5, [rsp+0x50]
000073baab9d7252  vmovaps xmm6, [rsp+0x60]
000073baab9d7258  vmovaps xmm7, [rsp+0x70]
000073baab9d725e  vmovaps xmm9, [rsp+0x80]
000073baab9d7267  vmovaps xmm10, [rsp+0x90]
000073baab9d7270  vmovaps xmm11, [rsp+0xA0]
000073baab9d7279  vmovaps xmm12, [rsp+0xB0]
000073baab9d7282  vmovaps xmm13, [rsp+0xC0]
000073baab9d728b  vmovaps xmm14, [rsp+0xD0]
000073baab9d7294  vmovaps xmm15, [rsp+0xE0]
000073baab9d729d  add rsp, 0xF0
000073baab9d72a4  pop r11
000073baab9d72a6  pop r10
000073baab9d72a8  pop r9
000073baab9d72aa  pop r8
000073baab9d72ac  pop rsi
000073baab9d72ad  pop rdi
000073baab9d72ae  pop rdx
000073baab9d72af  pop rcx
000073baab9d72b0  pop rax
000073baab9d72b1  add rsp, 0x08
000073baab9d72b5  jmp 0x000073BAAB9D32CF
000073baab9d72ba  sub rsp, 0x08
000073baab9d72be  push rax
000073baab9d72bf  push rcx
000073baab9d72c0  push rdx
000073baab9d72c1  push rdi
000073baab9d72c2  push rsi
000073baab9d72c3  push r8
000073baab9d72c5  push r9
000073baab9d72c7  push r10
000073baab9d72c9  push r11
000073baab9d72cb  sub rsp, 0xF0
000073baab9d72d2  vmovaps [rsp], xmm0
000073baab9d72d7  vmovaps [rsp+0x10], xmm1
000073baab9d72dd  vmovaps [rsp+0x20], xmm2
000073baab9d72e3  vmovaps [rsp+0x30], xmm3
000073baab9d72e9  vmovaps [rsp+0x40], xmm4
000073baab9d72ef  vmovaps [rsp+0x50], xmm5
000073baab9d72f5  vmovaps [rsp+0x60], xmm6
000073baab9d72fb  vmovaps [rsp+0x70], xmm7
000073baab9d7301  vmovaps [rsp+0x80], xmm8
000073baab9d730a  vmovaps [rsp+0x90], xmm9
000073baab9d7313  vmovaps [rsp+0xA0], xmm10
000073baab9d731c  vmovaps [rsp+0xB0], xmm11
000073baab9d7325  vmovaps [rsp+0xC0], xmm12
000073baab9d732e  vmovaps [rsp+0xD0], xmm13
000073baab9d7337  vmovaps [rsp+0xE0], xmm14
000073baab9d7340  sub rsp, 0x30
000073baab9d7344  movaps [rsp], xmm15
000073baab9d7349  movaps [rsp+0x10], xmm14
000073baab9d734f  movaps [rsp+0x20], xmm9
000073baab9d7355  lea rdi, [rsp]
000073baab9d7359  mov esi, 0x00
000073baab9d735e  mov rax, 0x5F3F1062D530
000073baab9d7368  call rax
000073baab9d736a  movaps xmm15, [rsp]
000073baab9d736f  add rsp, 0x30
000073baab9d7373  vmovaps xmm0, [rsp]
000073baab9d7378  vmovaps xmm1, [rsp+0x10]
000073baab9d737e  vmovaps xmm2, [rsp+0x20]
000073baab9d7384  vmovaps xmm3, [rsp+0x30]
000073baab9d738a  vmovaps xmm4, [rsp+0x40]
000073baab9d7390  vmovaps xmm5, [rsp+0x50]
000073baab9d7396  vmovaps xmm6, [rsp+0x60]
000073baab9d739c  vmovaps xmm7, [rsp+0x70]
000073baab9d73a2  vmovaps xmm8, [rsp+0x80]
000073baab9d73ab  vmovaps xmm9, [rsp+0x90]
000073baab9d73b4  vmovaps xmm10, [rsp+0xA0]
000073baab9d73bd  vmovaps xmm11, [rsp+0xB0]
000073baab9d73c6  vmovaps xmm12, [rsp+0xC0]
000073baab9d73cf  vmovaps xmm13, [rsp+0xD0]
000073baab9d73d8  vmovaps xmm14, [rsp+0xE0]
000073baab9d73e1  add rsp, 0xF0
000073baab9d73e8  pop r11
000073baab9d73ea  pop r10
000073baab9d73ec  pop r9
000073baab9d73ee  pop r8
000073baab9d73f0  pop rsi
000073baab9d73f1  pop rdi
000073baab9d73f2  pop rdx
000073baab9d73f3  pop rcx
000073baab9d73f4  pop rax
000073baab9d73f5  add rsp, 0x08
000073baab9d73f9  jmp 0x000073BAAB9D32E9
000073baab9d73fe  sub rsp, 0x08
000073baab9d7402  push rax
000073baab9d7403  push rcx
000073baab9d7404  push rdx
000073baab9d7405  push rdi
000073baab9d7406  push rsi
000073baab9d7407  push r8
000073baab9d7409  push r9
000073baab9d740b  push r10
000073baab9d740d  push r11
000073baab9d740f  sub rsp, 0xF0
000073baab9d7416  vmovaps [rsp], xmm0
000073baab9d741b  vmovaps [rsp+0x10], xmm1
000073baab9d7421  vmovaps [rsp+0x20], xmm2
000073baab9d7427  vmovaps [rsp+0x30], xmm3
000073baab9d742d  vmovaps [rsp+0x40], xmm4
000073baab9d7433  vmovaps [rsp+0x50], xmm5
000073baab9d7439  vmovaps [rsp+0x60], xmm6
000073baab9d743f  vmovaps [rsp+0x70], xmm7
000073baab9d7445  vmovaps [rsp+0x80], xmm8
000073baab9d744e  vmovaps [rsp+0x90], xmm10
000073baab9d7457  vmovaps [rsp+0xA0], xmm11
000073baab9d7460  vmovaps [rsp+0xB0], xmm12
000073baab9d7469  vmovaps [rsp+0xC0], xmm13
000073baab9d7472  vmovaps [rsp+0xD0], xmm14
000073baab9d747b  vmovaps [rsp+0xE0], xmm15
000073baab9d7484  sub rsp, 0x30
000073baab9d7488  movaps [rsp], xmm9
000073baab9d748d  movaps [rsp+0x10], xmm7
000073baab9d7492  movaps [rsp+0x20], xmm14
000073baab9d7498  lea rdi, [rsp]
000073baab9d749c  mov esi, 0x00
000073baab9d74a1  mov rax, 0x5F3F1062D530
000073baab9d74ab  call rax
000073baab9d74ad  movaps xmm9, [rsp]
000073baab9d74b2  add rsp, 0x30
000073baab9d74b6  vmovaps xmm0, [rsp]
000073baab9d74bb  vmovaps xmm1, [rsp+0x10]
000073baab9d74c1  vmovaps xmm2, [rsp+0x20]
000073baab9d74c7  vmovaps xmm3, [rsp+0x30]
000073baab9d74cd  vmovaps xmm4, [rsp+0x40]
000073baab9d74d3  vmovaps xmm5, [rsp+0x50]
000073baab9d74d9  vmovaps xmm6, [rsp+0x60]
000073baab9d74df  vmovaps xmm7, [rsp+0x70]
000073baab9d74e5  vmovaps xmm8, [rsp+0x80]
000073baab9d74ee  vmovaps xmm10, [rsp+0x90]
000073baab9d74f7  vmovaps xmm11, [rsp+0xA0]
000073baab9d7500  vmovaps xmm12, [rsp+0xB0]
000073baab9d7509  vmovaps xmm13, [rsp+0xC0]
000073baab9d7512  vmovaps xmm14, [rsp+0xD0]
000073baab9d751b  vmovaps xmm15, [rsp+0xE0]
000073baab9d7524  add rsp, 0xF0
000073baab9d752b  pop r11
000073baab9d752d  pop r10
000073baab9d752f  pop r9
000073baab9d7531  pop r8
000073baab9d7533  pop rsi
000073baab9d7534  pop rdi
000073baab9d7535  pop rdx
000073baab9d7536  pop rcx
000073baab9d7537  pop rax
000073baab9d7538  add rsp, 0x08
000073baab9d753c  jmp 0x000073BAAB9D3318
000073baab9d7541  sub rsp, 0x08
000073baab9d7545  push rax
000073baab9d7546  push rcx
000073baab9d7547  push rdx
000073baab9d7548  push rdi
000073baab9d7549  push rsi
000073baab9d754a  push r8
000073baab9d754c  push r9
000073baab9d754e  push r10
000073baab9d7550  push r11
000073baab9d7552  sub rsp, 0xF0
000073baab9d7559  vmovaps [rsp], xmm0
000073baab9d755e  vmovaps [rsp+0x10], xmm1
000073baab9d7564  vmovaps [rsp+0x20], xmm2
000073baab9d756a  vmovaps [rsp+0x30], xmm3
000073baab9d7570  vmovaps [rsp+0x40], xmm4
000073baab9d7576  vmovaps [rsp+0x50], xmm5
000073baab9d757c  vmovaps [rsp+0x60], xmm6
000073baab9d7582  vmovaps [rsp+0x70], xmm7
000073baab9d7588  vmovaps [rsp+0x80], xmm8
000073baab9d7591  vmovaps [rsp+0x90], xmm9
000073baab9d759a  vmovaps [rsp+0xA0], xmm10
000073baab9d75a3  vmovaps [rsp+0xB0], xmm11
000073baab9d75ac  vmovaps [rsp+0xC0], xmm12
000073baab9d75b5  vmovaps [rsp+0xD0], xmm13
000073baab9d75be  vmovaps [rsp+0xE0], xmm15
000073baab9d75c7  sub rsp, 0x30
000073baab9d75cb  movaps [rsp], xmm14
000073baab9d75d0  movaps [rsp+0x10], xmm13
000073baab9d75d6  movaps [rsp+0x20], xmm11
000073baab9d75dc  lea rdi, [rsp]
000073baab9d75e0  mov esi, 0x00
000073baab9d75e5  mov rax, 0x5F3F1062D530
000073baab9d75ef  call rax
000073baab9d75f1  movaps xmm14, [rsp]
000073baab9d75f6  add rsp, 0x30
000073baab9d75fa  vmovaps xmm0, [rsp]
000073baab9d75ff  vmovaps xmm1, [rsp+0x10]
000073baab9d7605  vmovaps xmm2, [rsp+0x20]
000073baab9d760b  vmovaps xmm3, [rsp+0x30]
000073baab9d7611  vmovaps xmm4, [rsp+0x40]
000073baab9d7617  vmovaps xmm5, [rsp+0x50]
000073baab9d761d  vmovaps xmm6, [rsp+0x60]
000073baab9d7623  vmovaps xmm7, [rsp+0x70]
000073baab9d7629  vmovaps xmm8, [rsp+0x80]
000073baab9d7632  vmovaps xmm9, [rsp+0x90]
000073baab9d763b  vmovaps xmm10, [rsp+0xA0]
000073baab9d7644  vmovaps xmm11, [rsp+0xB0]
000073baab9d764d  vmovaps xmm12, [rsp+0xC0]
000073baab9d7656  vmovaps xmm13, [rsp+0xD0]
000073baab9d765f  vmovaps xmm15, [rsp+0xE0]
000073baab9d7668  add rsp, 0xF0
000073baab9d766f  pop r11
000073baab9d7671  pop r10
000073baab9d7673  pop r9
000073baab9d7675  pop r8
000073baab9d7677  pop rsi
000073baab9d7678  pop rdi
000073baab9d7679  pop rdx
000073baab9d767a  pop rcx
000073baab9d767b  pop rax
000073baab9d767c  add rsp, 0x08
000073baab9d7680  jmp 0x000073BAAB9D3332
000073baab9d7685  sub rsp, 0x08
000073baab9d7689  push rax
000073baab9d768a  push rcx
000073baab9d768b  push rdx
000073baab9d768c  push rdi
000073baab9d768d  push rsi
000073baab9d768e  push r8
000073baab9d7690  push r9
000073baab9d7692  push r10
000073baab9d7694  push r11
000073baab9d7696  sub rsp, 0xF0
000073baab9d769d  vmovaps [rsp], xmm0
000073baab9d76a2  vmovaps [rsp+0x10], xmm1
000073baab9d76a8  vmovaps [rsp+0x20], xmm2
000073baab9d76ae  vmovaps [rsp+0x30], xmm3
000073baab9d76b4  vmovaps [rsp+0x40], xmm4
000073baab9d76ba  vmovaps [rsp+0x50], xmm5
000073baab9d76c0  vmovaps [rsp+0x60], xmm6
000073baab9d76c6  vmovaps [rsp+0x70], xmm7
000073baab9d76cc  vmovaps [rsp+0x80], xmm8
000073baab9d76d5  vmovaps [rsp+0x90], xmm9
000073baab9d76de  vmovaps [rsp+0xA0], xmm10
000073baab9d76e7  vmovaps [rsp+0xB0], xmm12
000073baab9d76f0  vmovaps [rsp+0xC0], xmm13
000073baab9d76f9  vmovaps [rsp+0xD0], xmm14
000073baab9d7702  vmovaps [rsp+0xE0], xmm15
000073baab9d770b  sub rsp, 0x30
000073baab9d770f  movaps [rsp], xmm11
000073baab9d7714  movaps [rsp+0x10], xmm7
000073baab9d7719  movaps [rsp+0x20], xmm13
000073baab9d771f  lea rdi, [rsp]
000073baab9d7723  mov esi, 0x00
000073baab9d7728  mov rax, 0x5F3F1062D530
000073baab9d7732  call rax
000073baab9d7734  movaps xmm11, [rsp]
000073baab9d7739  add rsp, 0x30
000073baab9d773d  vmovaps xmm0, [rsp]
000073baab9d7742  vmovaps xmm1, [rsp+0x10]
000073baab9d7748  vmovaps xmm2, [rsp+0x20]
000073baab9d774e  vmovaps xmm3, [rsp+0x30]
000073baab9d7754  vmovaps xmm4, [rsp+0x40]
000073baab9d775a  vmovaps xmm5, [rsp+0x50]
000073baab9d7760  vmovaps xmm6, [rsp+0x60]
000073baab9d7766  vmovaps xmm7, [rsp+0x70]
000073baab9d776c  vmovaps xmm8, [rsp+0x80]
000073baab9d7775  vmovaps xmm9, [rsp+0x90]
000073baab9d777e  vmovaps xmm10, [rsp+0xA0]
000073baab9d7787  vmovaps xmm12, [rsp+0xB0]
000073baab9d7790  vmovaps xmm13, [rsp+0xC0]
000073baab9d7799  vmovaps xmm14, [rsp+0xD0]
000073baab9d77a2  vmovaps xmm15, [rsp+0xE0]
000073baab9d77ab  add rsp, 0xF0
000073baab9d77b2  pop r11
000073baab9d77b4  pop r10
000073baab9d77b6  pop r9
000073baab9d77b8  pop r8
000073baab9d77ba  pop rsi
000073baab9d77bb  pop rdi
000073baab9d77bc  pop rdx
000073baab9d77bd  pop rcx
000073baab9d77be  pop rax
000073baab9d77bf  add rsp, 0x08
000073baab9d77c3  jmp 0x000073BAAB9D335E
000073baab9d77c8  sub rsp, 0x08
000073baab9d77cc  push rax
000073baab9d77cd  push rcx
000073baab9d77ce  push rdx
000073baab9d77cf  push rdi
000073baab9d77d0  push rsi
000073baab9d77d1  push r8
000073baab9d77d3  push r9
000073baab9d77d5  push r10
000073baab9d77d7  push r11
000073baab9d77d9  sub rsp, 0xF0
000073baab9d77e0  vmovaps [rsp], xmm0
000073baab9d77e5  vmovaps [rsp+0x10], xmm1
000073baab9d77eb  vmovaps [rsp+0x20], xmm2
000073baab9d77f1  vmovaps [rsp+0x30], xmm3
000073baab9d77f7  vmovaps [rsp+0x40], xmm4
000073baab9d77fd  vmovaps [rsp+0x50], xmm5
000073baab9d7803  vmovaps [rsp+0x60], xmm6
000073baab9d7809  vmovaps [rsp+0x70], xmm7
000073baab9d780f  vmovaps [rsp+0x80], xmm8
000073baab9d7818  vmovaps [rsp+0x90], xmm9
000073baab9d7821  vmovaps [rsp+0xA0], xmm10
000073baab9d782a  vmovaps [rsp+0xB0], xmm11
000073baab9d7833  vmovaps [rsp+0xC0], xmm12
000073baab9d783c  vmovaps [rsp+0xD0], xmm14
000073baab9d7845  vmovaps [rsp+0xE0], xmm15
000073baab9d784e  sub rsp, 0x30
000073baab9d7852  movaps [rsp], xmm13
000073baab9d7857  movaps [rsp+0x10], xmm10
000073baab9d785d  movaps [rsp+0x20], xmm12
000073baab9d7863  lea rdi, [rsp]
000073baab9d7867  mov esi, 0x00
000073baab9d786c  mov rax, 0x5F3F1062D530
000073baab9d7876  call rax
000073baab9d7878  movaps xmm13, [rsp]
000073baab9d787d  add rsp, 0x30
000073baab9d7881  vmovaps xmm0, [rsp]
000073baab9d7886  vmovaps xmm1, [rsp+0x10]
000073baab9d788c  vmovaps xmm2, [rsp+0x20]
000073baab9d7892  vmovaps xmm3, [rsp+0x30]
000073baab9d7898  vmovaps xmm4, [rsp+0x40]
000073baab9d789e  vmovaps xmm5, [rsp+0x50]
000073baab9d78a4  vmovaps xmm6, [rsp+0x60]
000073baab9d78aa  vmovaps xmm7, [rsp+0x70]
000073baab9d78b0  vmovaps xmm8, [rsp+0x80]
000073baab9d78b9  vmovaps xmm9, [rsp+0x90]
000073baab9d78c2  vmovaps xmm10, [rsp+0xA0]
000073baab9d78cb  vmovaps xmm11, [rsp+0xB0]
000073baab9d78d4  vmovaps xmm12, [rsp+0xC0]
000073baab9d78dd  vmovaps xmm14, [rsp+0xD0]
000073baab9d78e6  vmovaps xmm15, [rsp+0xE0]
000073baab9d78ef  add rsp, 0xF0
000073baab9d78f6  pop r11
000073baab9d78f8  pop r10
000073baab9d78fa  pop r9
000073baab9d78fc  pop r8
000073baab9d78fe  pop rsi
000073baab9d78ff  pop rdi
000073baab9d7900  pop rdx
000073baab9d7901  pop rcx
000073baab9d7902  pop rax
000073baab9d7903  add rsp, 0x08
000073baab9d7907  jmp 0x000073BAAB9D3378
000073baab9d790c  sub rsp, 0x08
000073baab9d7910  push rax
000073baab9d7911  push rcx
000073baab9d7912  push rdx
000073baab9d7913  push rdi
000073baab9d7914  push rsi
000073baab9d7915  push r8
000073baab9d7917  push r9
000073baab9d7919  push r10
000073baab9d791b  push r11
000073baab9d791d  sub rsp, 0xF0
000073baab9d7924  vmovaps [rsp], xmm0
000073baab9d7929  vmovaps [rsp+0x10], xmm1
000073baab9d792f  vmovaps [rsp+0x20], xmm2
000073baab9d7935  vmovaps [rsp+0x30], xmm3
000073baab9d793b  vmovaps [rsp+0x40], xmm4
000073baab9d7941  vmovaps [rsp+0x50], xmm5
000073baab9d7947  vmovaps [rsp+0x60], xmm6
000073baab9d794d  vmovaps [rsp+0x70], xmm7
000073baab9d7953  vmovaps [rsp+0x80], xmm8
000073baab9d795c  vmovaps [rsp+0x90], xmm9
000073baab9d7965  vmovaps [rsp+0xA0], xmm11
000073baab9d796e  vmovaps [rsp+0xB0], xmm12
000073baab9d7977  vmovaps [rsp+0xC0], xmm13
000073baab9d7980  vmovaps [rsp+0xD0], xmm14
000073baab9d7989  vmovaps [rsp+0xE0], xmm15
000073baab9d7992  sub rsp, 0x30
000073baab9d7996  movaps [rsp], xmm10
000073baab9d799b  movaps [rsp+0x10], xmm7
000073baab9d79a0  movaps [rsp+0x20], xmm12
000073baab9d79a6  lea rdi, [rsp]
000073baab9d79aa  mov esi, 0x00
000073baab9d79af  mov rax, 0x5F3F1062D530
000073baab9d79b9  call rax
000073baab9d79bb  movaps xmm10, [rsp]
000073baab9d79c0  add rsp, 0x30
000073baab9d79c4  vmovaps xmm0, [rsp]
000073baab9d79c9  vmovaps xmm1, [rsp+0x10]
000073baab9d79cf  vmovaps xmm2, [rsp+0x20]
000073baab9d79d5  vmovaps xmm3, [rsp+0x30]
000073baab9d79db  vmovaps xmm4, [rsp+0x40]
000073baab9d79e1  vmovaps xmm5, [rsp+0x50]
000073baab9d79e7  vmovaps xmm6, [rsp+0x60]
000073baab9d79ed  vmovaps xmm7, [rsp+0x70]
000073baab9d79f3  vmovaps xmm8, [rsp+0x80]
000073baab9d79fc  vmovaps xmm9, [rsp+0x90]
000073baab9d7a05  vmovaps xmm11, [rsp+0xA0]
000073baab9d7a0e  vmovaps xmm12, [rsp+0xB0]
000073baab9d7a17  vmovaps xmm13, [rsp+0xC0]
000073baab9d7a20  vmovaps xmm14, [rsp+0xD0]
000073baab9d7a29  vmovaps xmm15, [rsp+0xE0]
000073baab9d7a32  add rsp, 0xF0
000073baab9d7a39  pop r11
000073baab9d7a3b  pop r10
000073baab9d7a3d  pop r9
000073baab9d7a3f  pop r8
000073baab9d7a41  pop rsi
000073baab9d7a42  pop rdi
000073baab9d7a43  pop rdx
000073baab9d7a44  pop rcx
000073baab9d7a45  pop rax
000073baab9d7a46  add rsp, 0x08
000073baab9d7a4a  jmp 0x000073BAAB9D33A4
000073baab9d7a4f  sub rsp, 0x08
000073baab9d7a53  push rax
000073baab9d7a54  push rcx
000073baab9d7a55  push rdx
000073baab9d7a56  push rdi
000073baab9d7a57  push rsi
000073baab9d7a58  push r8
000073baab9d7a5a  push r9
000073baab9d7a5c  push r10
000073baab9d7a5e  push r11
000073baab9d7a60  sub rsp, 0xF0
000073baab9d7a67  vmovaps [rsp], xmm0
000073baab9d7a6c  vmovaps [rsp+0x10], xmm1
000073baab9d7a72  vmovaps [rsp+0x20], xmm2
000073baab9d7a78  vmovaps [rsp+0x30], xmm3
000073baab9d7a7e  vmovaps [rsp+0x40], xmm4
000073baab9d7a84  vmovaps [rsp+0x50], xmm5
000073baab9d7a8a  vmovaps [rsp+0x60], xmm6
000073baab9d7a90  vmovaps [rsp+0x70], xmm7
000073baab9d7a96  vmovaps [rsp+0x80], xmm8
000073baab9d7a9f  vmovaps [rsp+0x90], xmm9
000073baab9d7aa8  vmovaps [rsp+0xA0], xmm10
000073baab9d7ab1  vmovaps [rsp+0xB0], xmm11
000073baab9d7aba  vmovaps [rsp+0xC0], xmm13
000073baab9d7ac3  vmovaps [rsp+0xD0], xmm14
000073baab9d7acc  vmovaps [rsp+0xE0], xmm15
000073baab9d7ad5  sub rsp, 0x30
000073baab9d7ad9  movaps [rsp], xmm12
000073baab9d7ade  movaps [rsp+0x10], xmm1
000073baab9d7ae3  movaps [rsp+0x20], xmm8
000073baab9d7ae9  lea rdi, [rsp]
000073baab9d7aed  mov esi, 0x00
000073baab9d7af2  mov rax, 0x5F3F1062D530
000073baab9d7afc  call rax
000073baab9d7afe  movaps xmm12, [rsp]
000073baab9d7b03  add rsp, 0x30
000073baab9d7b07  vmovaps xmm0, [rsp]
000073baab9d7b0c  vmovaps xmm1, [rsp+0x10]
000073baab9d7b12  vmovaps xmm2, [rsp+0x20]
000073baab9d7b18  vmovaps xmm3, [rsp+0x30]
000073baab9d7b1e  vmovaps xmm4, [rsp+0x40]
000073baab9d7b24  vmovaps xmm5, [rsp+0x50]
000073baab9d7b2a  vmovaps xmm6, [rsp+0x60]
000073baab9d7b30  vmovaps xmm7, [rsp+0x70]
000073baab9d7b36  vmovaps xmm8, [rsp+0x80]
000073baab9d7b3f  vmovaps xmm9, [rsp+0x90]
000073baab9d7b48  vmovaps xmm10, [rsp+0xA0]
000073baab9d7b51  vmovaps xmm11, [rsp+0xB0]
000073baab9d7b5a  vmovaps xmm13, [rsp+0xC0]
000073baab9d7b63  vmovaps xmm14, [rsp+0xD0]
000073baab9d7b6c  vmovaps xmm15, [rsp+0xE0]
000073baab9d7b75  add rsp, 0xF0
000073baab9d7b7c  pop r11
000073baab9d7b7e  pop r10
000073baab9d7b80  pop r9
000073baab9d7b82  pop r8
000073baab9d7b84  pop rsi
000073baab9d7b85  pop rdi
000073baab9d7b86  pop rdx
000073baab9d7b87  pop rcx
000073baab9d7b88  pop rax
000073baab9d7b89  add rsp, 0x08
000073baab9d7b8d  jmp 0x000073BAAB9D33BE
000073baab9d7b92  call 0x000073BAAB7FF430
000073baab9d7b97  jmp 0x000073BAAB9D33C8
000073baab9d7b9c  sub rsp, 0x08
000073baab9d7ba0  push rax
000073baab9d7ba1  push rcx
000073baab9d7ba2  push rdx
000073baab9d7ba3  push rdi
000073baab9d7ba4  push rsi
000073baab9d7ba5  push r8
000073baab9d7ba7  push r9
000073baab9d7ba9  push r10
000073baab9d7bab  push r11
000073baab9d7bad  sub rsp, 0xF0
000073baab9d7bb4  vmovaps [rsp], xmm0
000073baab9d7bb9  vmovaps [rsp+0x10], xmm1
000073baab9d7bbf  vmovaps [rsp+0x20], xmm2
000073baab9d7bc5  vmovaps [rsp+0x30], xmm3
000073baab9d7bcb  vmovaps [rsp+0x40], xmm4
000073baab9d7bd1  vmovaps [rsp+0x50], xmm5
000073baab9d7bd7  vmovaps [rsp+0x60], xmm6
000073baab9d7bdd  vmovaps [rsp+0x70], xmm7
000073baab9d7be3  vmovaps [rsp+0x80], xmm9
000073baab9d7bec  vmovaps [rsp+0x90], xmm10
000073baab9d7bf5  vmovaps [rsp+0xA0], xmm11
000073baab9d7bfe  vmovaps [rsp+0xB0], xmm12
000073baab9d7c07  vmovaps [rsp+0xC0], xmm13
000073baab9d7c10  vmovaps [rsp+0xD0], xmm14
000073baab9d7c19  vmovaps [rsp+0xE0], xmm15
000073baab9d7c22  sub rsp, 0x30
000073baab9d7c26  movaps [rsp], xmm8
000073baab9d7c2b  movaps [rsp+0x10], xmm15
000073baab9d7c31  movaps [rsp+0x20], xmm9
000073baab9d7c37  lea rdi, [rsp]
000073baab9d7c3b  mov esi, 0x00
000073baab9d7c40  mov rax, 0x5F3F1062D530
000073baab9d7c4a  call rax
000073baab9d7c4c  movaps xmm8, [rsp]
000073baab9d7c51  add rsp, 0x30
000073baab9d7c55  vmovaps xmm0, [rsp]
000073baab9d7c5a  vmovaps xmm1, [rsp+0x10]
000073baab9d7c60  vmovaps xmm2, [rsp+0x20]
000073baab9d7c66  vmovaps xmm3, [rsp+0x30]
000073baab9d7c6c  vmovaps xmm4, [rsp+0x40]
000073baab9d7c72  vmovaps xmm5, [rsp+0x50]
000073baab9d7c78  vmovaps xmm6, [rsp+0x60]
000073baab9d7c7e  vmovaps xmm7, [rsp+0x70]
000073baab9d7c84  vmovaps xmm9, [rsp+0x80]
000073baab9d7c8d  vmovaps xmm10, [rsp+0x90]
000073baab9d7c96  vmovaps xmm11, [rsp+0xA0]
000073baab9d7c9f  vmovaps xmm12, [rsp+0xB0]
000073baab9d7ca8  vmovaps xmm13, [rsp+0xC0]
000073baab9d7cb1  vmovaps xmm14, [rsp+0xD0]
000073baab9d7cba  vmovaps xmm15, [rsp+0xE0]
000073baab9d7cc3  add rsp, 0xF0
000073baab9d7cca  pop r11
000073baab9d7ccc  pop r10
000073baab9d7cce  pop r9
000073baab9d7cd0  pop r8
000073baab9d7cd2  pop rsi
000073baab9d7cd3  pop rdi
000073baab9d7cd4  pop rdx
000073baab9d7cd5  pop rcx
000073baab9d7cd6  pop rax
000073baab9d7cd7  add rsp, 0x08
000073baab9d7cdb  jmp 0x000073BAAB9D33EA
000073baab9d7ce0  sub rsp, 0x08
000073baab9d7ce4  push rax
000073baab9d7ce5  push rcx
000073baab9d7ce6  push rdx
000073baab9d7ce7  push rdi
000073baab9d7ce8  push rsi
000073baab9d7ce9  push r8
000073baab9d7ceb  push r9
000073baab9d7ced  push r10
000073baab9d7cef  push r11
000073baab9d7cf1  sub rsp, 0xF0
000073baab9d7cf8  vmovaps [rsp], xmm0
000073baab9d7cfd  vmovaps [rsp+0x10], xmm1
000073baab9d7d03  vmovaps [rsp+0x20], xmm2
000073baab9d7d09  vmovaps [rsp+0x30], xmm3
000073baab9d7d0f  vmovaps [rsp+0x40], xmm4
000073baab9d7d15  vmovaps [rsp+0x50], xmm5
000073baab9d7d1b  vmovaps [rsp+0x60], xmm6
000073baab9d7d21  vmovaps [rsp+0x70], xmm7
000073baab9d7d27  vmovaps [rsp+0x80], xmm8
000073baab9d7d30  vmovaps [rsp+0x90], xmm10
000073baab9d7d39  vmovaps [rsp+0xA0], xmm11
000073baab9d7d42  vmovaps [rsp+0xB0], xmm12
000073baab9d7d4b  vmovaps [rsp+0xC0], xmm13
000073baab9d7d54  vmovaps [rsp+0xD0], xmm14
000073baab9d7d5d  vmovaps [rsp+0xE0], xmm15
000073baab9d7d66  sub rsp, 0x30
000073baab9d7d6a  movaps [rsp], xmm9
000073baab9d7d6f  movaps [rsp+0x10], xmm1
000073baab9d7d74  movaps [rsp+0x20], xmm15
000073baab9d7d7a  lea rdi, [rsp]
000073baab9d7d7e  mov esi, 0x00
000073baab9d7d83  mov rax, 0x5F3F1062D530
000073baab9d7d8d  call rax
000073baab9d7d8f  movaps xmm9, [rsp]
000073baab9d7d94  add rsp, 0x30
000073baab9d7d98  vmovaps xmm0, [rsp]
000073baab9d7d9d  vmovaps xmm1, [rsp+0x10]
000073baab9d7da3  vmovaps xmm2, [rsp+0x20]
000073baab9d7da9  vmovaps xmm3, [rsp+0x30]
000073baab9d7daf  vmovaps xmm4, [rsp+0x40]
000073baab9d7db5  vmovaps xmm5, [rsp+0x50]
000073baab9d7dbb  vmovaps xmm6, [rsp+0x60]
000073baab9d7dc1  vmovaps xmm7, [rsp+0x70]
000073baab9d7dc7  vmovaps xmm8, [rsp+0x80]
000073baab9d7dd0  vmovaps xmm10, [rsp+0x90]
000073baab9d7dd9  vmovaps xmm11, [rsp+0xA0]
000073baab9d7de2  vmovaps xmm12, [rsp+0xB0]
000073baab9d7deb  vmovaps xmm13, [rsp+0xC0]
000073baab9d7df4  vmovaps xmm14, [rsp+0xD0]
000073baab9d7dfd  vmovaps xmm15, [rsp+0xE0]
000073baab9d7e06  add rsp, 0xF0
000073baab9d7e0d  pop r11
000073baab9d7e0f  pop r10
000073baab9d7e11  pop r9
000073baab9d7e13  pop r8
000073baab9d7e15  pop rsi
000073baab9d7e16  pop rdi
000073baab9d7e17  pop rdx
000073baab9d7e18  pop rcx
000073baab9d7e19  pop rax
000073baab9d7e1a  add rsp, 0x08
000073baab9d7e1e  jmp 0x000073BAAB9D3418
000073baab9d7e23  sub rsp, 0x08
000073baab9d7e27  push rax
000073baab9d7e28  push rcx
000073baab9d7e29  push rdx
000073baab9d7e2a  push rdi
000073baab9d7e2b  push rsi
000073baab9d7e2c  push r8
000073baab9d7e2e  push r9
000073baab9d7e30  push r10
000073baab9d7e32  push r11
000073baab9d7e34  sub rsp, 0xF0
000073baab9d7e3b  vmovaps [rsp], xmm0
000073baab9d7e40  vmovaps [rsp+0x10], xmm1
000073baab9d7e46  vmovaps [rsp+0x20], xmm2
000073baab9d7e4c  vmovaps [rsp+0x30], xmm3
000073baab9d7e52  vmovaps [rsp+0x40], xmm4
000073baab9d7e58  vmovaps [rsp+0x50], xmm5
000073baab9d7e5e  vmovaps [rsp+0x60], xmm6
000073baab9d7e64  vmovaps [rsp+0x70], xmm7
000073baab9d7e6a  vmovaps [rsp+0x80], xmm8
000073baab9d7e73  vmovaps [rsp+0x90], xmm9
000073baab9d7e7c  vmovaps [rsp+0xA0], xmm10
000073baab9d7e85  vmovaps [rsp+0xB0], xmm11
000073baab9d7e8e  vmovaps [rsp+0xC0], xmm12
000073baab9d7e97  vmovaps [rsp+0xD0], xmm13
000073baab9d7ea0  vmovaps [rsp+0xE0], xmm14
000073baab9d7ea9  sub rsp, 0x30
000073baab9d7ead  movaps [rsp], xmm15
000073baab9d7eb2  movaps [rsp+0x10], xmm4
000073baab9d7eb7  movaps [rsp+0x20], xmm1
000073baab9d7ebc  lea rdi, [rsp]
000073baab9d7ec0  mov esi, 0x00
000073baab9d7ec5  mov rax, 0x5F3F1062D530
000073baab9d7ecf  call rax
000073baab9d7ed1  movaps xmm15, [rsp]
000073baab9d7ed6  add rsp, 0x30
000073baab9d7eda  vmovaps xmm0, [rsp]
000073baab9d7edf  vmovaps xmm1, [rsp+0x10]
000073baab9d7ee5  vmovaps xmm2, [rsp+0x20]
000073baab9d7eeb  vmovaps xmm3, [rsp+0x30]
000073baab9d7ef1  vmovaps xmm4, [rsp+0x40]
000073baab9d7ef7  vmovaps xmm5, [rsp+0x50]
000073baab9d7efd  vmovaps xmm6, [rsp+0x60]
000073baab9d7f03  vmovaps xmm7, [rsp+0x70]
000073baab9d7f09  vmovaps xmm8, [rsp+0x80]
000073baab9d7f12  vmovaps xmm9, [rsp+0x90]
000073baab9d7f1b  vmovaps xmm10, [rsp+0xA0]
000073baab9d7f24  vmovaps xmm11, [rsp+0xB0]
000073baab9d7f2d  vmovaps xmm12, [rsp+0xC0]
000073baab9d7f36  vmovaps xmm13, [rsp+0xD0]
000073baab9d7f3f  vmovaps xmm14, [rsp+0xE0]
000073baab9d7f48  add rsp, 0xF0
000073baab9d7f4f  pop r11
000073baab9d7f51  pop r10
000073baab9d7f53  pop r9
000073baab9d7f55  pop r8
000073baab9d7f57  pop rsi
000073baab9d7f58  pop rdi
000073baab9d7f59  pop rdx
000073baab9d7f5a  pop rcx
000073baab9d7f5b  pop rax
000073baab9d7f5c  add rsp, 0x08
000073baab9d7f60  jmp 0x000073BAAB9D343E
000073baab9d7f65  sub rsp, 0x08
000073baab9d7f69  push rax
000073baab9d7f6a  push rcx
000073baab9d7f6b  push rdx
000073baab9d7f6c  push rdi
000073baab9d7f6d  push rsi
000073baab9d7f6e  push r8
000073baab9d7f70  push r9
000073baab9d7f72  push r10
000073baab9d7f74  push r11
000073baab9d7f76  sub rsp, 0xF0
000073baab9d7f7d  vmovaps [rsp], xmm0
000073baab9d7f82  vmovaps [rsp+0x10], xmm2
000073baab9d7f88  vmovaps [rsp+0x20], xmm3
000073baab9d7f8e  vmovaps [rsp+0x30], xmm4
000073baab9d7f94  vmovaps [rsp+0x40], xmm5
000073baab9d7f9a  vmovaps [rsp+0x50], xmm6
000073baab9d7fa0  vmovaps [rsp+0x60], xmm7
000073baab9d7fa6  vmovaps [rsp+0x70], xmm8
000073baab9d7fac  vmovaps [rsp+0x80], xmm9
000073baab9d7fb5  vmovaps [rsp+0x90], xmm10
000073baab9d7fbe  vmovaps [rsp+0xA0], xmm11
000073baab9d7fc7  vmovaps [rsp+0xB0], xmm12
000073baab9d7fd0  vmovaps [rsp+0xC0], xmm13
000073baab9d7fd9  vmovaps [rsp+0xD0], xmm14
000073baab9d7fe2  vmovaps [rsp+0xE0], xmm15
000073baab9d7feb  sub rsp, 0x30
000073baab9d7fef  movaps [rsp], xmm1
000073baab9d7ff3  movaps [rsp+0x10], xmm14
000073baab9d7ff9  movaps [rsp+0x20], xmm11
000073baab9d7fff  lea rdi, [rsp]
000073baab9d8003  mov esi, 0x00
000073baab9d8008  mov rax, 0x5F3F1062D530
000073baab9d8012  call rax
000073baab9d8014  movaps xmm1, [rsp]
000073baab9d8018  add rsp, 0x30
000073baab9d801c  vmovaps xmm0, [rsp]
000073baab9d8021  vmovaps xmm2, [rsp+0x10]
000073baab9d8027  vmovaps xmm3, [rsp+0x20]
000073baab9d802d  vmovaps xmm4, [rsp+0x30]
000073baab9d8033  vmovaps xmm5, [rsp+0x40]
000073baab9d8039  vmovaps xmm6, [rsp+0x50]
000073baab9d803f  vmovaps xmm7, [rsp+0x60]
000073baab9d8045  vmovaps xmm8, [rsp+0x70]
000073baab9d804b  vmovaps xmm9, [rsp+0x80]
000073baab9d8054  vmovaps xmm10, [rsp+0x90]
000073baab9d805d  vmovaps xmm11, [rsp+0xA0]
000073baab9d8066  vmovaps xmm12, [rsp+0xB0]
000073baab9d806f  vmovaps xmm13, [rsp+0xC0]
000073baab9d8078  vmovaps xmm14, [rsp+0xD0]
000073baab9d8081  vmovaps xmm15, [rsp+0xE0]
000073baab9d808a  add rsp, 0xF0
000073baab9d8091  pop r11
000073baab9d8093  pop r10
000073baab9d8095  pop r9
000073baab9d8097  pop r8
000073baab9d8099  pop rsi
000073baab9d809a  pop rdi
000073baab9d809b  pop rdx
000073baab9d809c  pop rcx
000073baab9d809d  pop rax
000073baab9d809e  add rsp, 0x08
000073baab9d80a2  jmp 0x000073BAAB9D345F
000073baab9d80a7  call 0x000073BAAB8E45A0
000073baab9d80ac  jmp 0x000073BAAB9D346D
000073baab9d80b1  call 0x000073BAAB809D70
000073baab9d80b6  jmp 0x000073BAAB9D3477
000073baab9d80bb  sub rsp, 0x08
000073baab9d80bf  push rax
000073baab9d80c0  push rcx
000073baab9d80c1  push rdx
000073baab9d80c2  push rdi
000073baab9d80c3  push rsi
000073baab9d80c4  push r8
000073baab9d80c6  push r9
000073baab9d80c8  push r10
000073baab9d80ca  push r11
000073baab9d80cc  sub rsp, 0xF0
000073baab9d80d3  vmovaps [rsp], xmm0
000073baab9d80d8  vmovaps [rsp+0x10], xmm1
000073baab9d80de  vmovaps [rsp+0x20], xmm2
000073baab9d80e4  vmovaps [rsp+0x30], xmm3
000073baab9d80ea  vmovaps [rsp+0x40], xmm4
000073baab9d80f0  vmovaps [rsp+0x50], xmm5
000073baab9d80f6  vmovaps [rsp+0x60], xmm6
000073baab9d80fc  vmovaps [rsp+0x70], xmm8
000073baab9d8102  vmovaps [rsp+0x80], xmm9
000073baab9d810b  vmovaps [rsp+0x90], xmm10
000073baab9d8114  vmovaps [rsp+0xA0], xmm11
000073baab9d811d  vmovaps [rsp+0xB0], xmm12
000073baab9d8126  vmovaps [rsp+0xC0], xmm13
000073baab9d812f  vmovaps [rsp+0xD0], xmm14
000073baab9d8138  vmovaps [rsp+0xE0], xmm15
000073baab9d8141  sub rsp, 0x30
000073baab9d8145  movaps [rsp], xmm7
000073baab9d8149  movaps [rsp+0x10], xmm13
000073baab9d814f  movaps [rsp+0x20], xmm10
000073baab9d8155  lea rdi, [rsp]
000073baab9d8159  mov esi, 0x00
000073baab9d815e  mov rax, 0x5F3F1062D530
000073baab9d8168  call rax
000073baab9d816a  movaps xmm7, [rsp]
000073baab9d816e  add rsp, 0x30
000073baab9d8172  vmovaps xmm0, [rsp]
000073baab9d8177  vmovaps xmm1, [rsp+0x10]
000073baab9d817d  vmovaps xmm2, [rsp+0x20]
000073baab9d8183  vmovaps xmm3, [rsp+0x30]
000073baab9d8189  vmovaps xmm4, [rsp+0x40]
000073baab9d818f  vmovaps xmm5, [rsp+0x50]
000073baab9d8195  vmovaps xmm6, [rsp+0x60]
000073baab9d819b  vmovaps xmm8, [rsp+0x70]
000073baab9d81a1  vmovaps xmm9, [rsp+0x80]
000073baab9d81aa  vmovaps xmm10, [rsp+0x90]
000073baab9d81b3  vmovaps xmm11, [rsp+0xA0]
000073baab9d81bc  vmovaps xmm12, [rsp+0xB0]
000073baab9d81c5  vmovaps xmm13, [rsp+0xC0]
000073baab9d81ce  vmovaps xmm14, [rsp+0xD0]
000073baab9d81d7  vmovaps xmm15, [rsp+0xE0]
000073baab9d81e0  add rsp, 0xF0
000073baab9d81e7  pop r11
000073baab9d81e9  pop r10
000073baab9d81eb  pop r9
000073baab9d81ed  pop r8
000073baab9d81ef  pop rsi
000073baab9d81f0  pop rdi
000073baab9d81f1  pop rdx
000073baab9d81f2  pop rcx
000073baab9d81f3  pop rax
000073baab9d81f4  add rsp, 0x08
000073baab9d81f8  jmp 0x000073BAAB9D3498
000073baab9d81fd  sub rsp, 0x08
000073baab9d8201  push rax
000073baab9d8202  push rcx
000073baab9d8203  push rdx
000073baab9d8204  push rdi
000073baab9d8205  push rsi
000073baab9d8206  push r8
000073baab9d8208  push r9
000073baab9d820a  push r10
000073baab9d820c  push r11
000073baab9d820e  sub rsp, 0xF0
000073baab9d8215  vmovaps [rsp], xmm0
000073baab9d821a  vmovaps [rsp+0x10], xmm1
000073baab9d8220  vmovaps [rsp+0x20], xmm2
000073baab9d8226  vmovaps [rsp+0x30], xmm3
000073baab9d822c  vmovaps [rsp+0x40], xmm4
000073baab9d8232  vmovaps [rsp+0x50], xmm5
000073baab9d8238  vmovaps [rsp+0x60], xmm6
000073baab9d823e  vmovaps [rsp+0x70], xmm7
000073baab9d8244  vmovaps [rsp+0x80], xmm8
000073baab9d824d  vmovaps [rsp+0x90], xmm9
000073baab9d8256  vmovaps [rsp+0xA0], xmm11
000073baab9d825f  vmovaps [rsp+0xB0], xmm12
000073baab9d8268  vmovaps [rsp+0xC0], xmm13
000073baab9d8271  vmovaps [rsp+0xD0], xmm14
000073baab9d827a  vmovaps [rsp+0xE0], xmm15
000073baab9d8283  sub rsp, 0x30
000073baab9d8287  movaps [rsp], xmm10
000073baab9d828c  movaps [rsp+0x10], xmm11
000073baab9d8292  movaps [rsp+0x20], xmm13
000073baab9d8298  lea rdi, [rsp]
000073baab9d829c  mov esi, 0x00
000073baab9d82a1  mov rax, 0x5F3F1062D530
000073baab9d82ab  call rax
000073baab9d82ad  movaps xmm10, [rsp]
000073baab9d82b2  add rsp, 0x30
000073baab9d82b6  vmovaps xmm0, [rsp]
000073baab9d82bb  vmovaps xmm1, [rsp+0x10]
000073baab9d82c1  vmovaps xmm2, [rsp+0x20]
000073baab9d82c7  vmovaps xmm3, [rsp+0x30]
000073baab9d82cd  vmovaps xmm4, [rsp+0x40]
000073baab9d82d3  vmovaps xmm5, [rsp+0x50]
000073baab9d82d9  vmovaps xmm6, [rsp+0x60]
000073baab9d82df  vmovaps xmm7, [rsp+0x70]
000073baab9d82e5  vmovaps xmm8, [rsp+0x80]
000073baab9d82ee  vmovaps xmm9, [rsp+0x90]
000073baab9d82f7  vmovaps xmm11, [rsp+0xA0]
000073baab9d8300  vmovaps xmm12, [rsp+0xB0]
000073baab9d8309  vmovaps xmm13, [rsp+0xC0]
000073baab9d8312  vmovaps xmm14, [rsp+0xD0]
000073baab9d831b  vmovaps xmm15, [rsp+0xE0]
000073baab9d8324  add rsp, 0xF0
000073baab9d832b  pop r11
000073baab9d832d  pop r10
000073baab9d832f  pop r9
000073baab9d8331  pop r8
000073baab9d8333  pop rsi
000073baab9d8334  pop rdi
000073baab9d8335  pop rdx
000073baab9d8336  pop rcx
000073baab9d8337  pop rax
000073baab9d8338  add rsp, 0x08
000073baab9d833c  jmp 0x000073BAAB9D34C6
000073baab9d8341  sub rsp, 0x08
000073baab9d8345  push rax
000073baab9d8346  push rcx
000073baab9d8347  push rdx
000073baab9d8348  push rdi
000073baab9d8349  push rsi
000073baab9d834a  push r8
000073baab9d834c  push r9
000073baab9d834e  push r10
000073baab9d8350  push r11
000073baab9d8352  sub rsp, 0xF0
000073baab9d8359  vmovaps [rsp], xmm0
000073baab9d835e  vmovaps [rsp+0x10], xmm1
000073baab9d8364  vmovaps [rsp+0x20], xmm2
000073baab9d836a  vmovaps [rsp+0x30], xmm3
000073baab9d8370  vmovaps [rsp+0x40], xmm4
000073baab9d8376  vmovaps [rsp+0x50], xmm5
000073baab9d837c  vmovaps [rsp+0x60], xmm6
000073baab9d8382  vmovaps [rsp+0x70], xmm7
000073baab9d8388  vmovaps [rsp+0x80], xmm8
000073baab9d8391  vmovaps [rsp+0x90], xmm9
000073baab9d839a  vmovaps [rsp+0xA0], xmm10
000073baab9d83a3  vmovaps [rsp+0xB0], xmm12
000073baab9d83ac  vmovaps [rsp+0xC0], xmm13
000073baab9d83b5  vmovaps [rsp+0xD0], xmm14
000073baab9d83be  vmovaps [rsp+0xE0], xmm15
000073baab9d83c7  sub rsp, 0x30
000073baab9d83cb  movaps [rsp], xmm11
000073baab9d83d0  movaps [rsp+0x10], xmm14
000073baab9d83d6  movaps [rsp+0x20], xmm13
000073baab9d83dc  lea rdi, [rsp]
000073baab9d83e0  mov esi, 0x00
000073baab9d83e5  mov rax, 0x5F3F1062D530
000073baab9d83ef  call rax
000073baab9d83f1  movaps xmm11, [rsp]
000073baab9d83f6  add rsp, 0x30
000073baab9d83fa  vmovaps xmm0, [rsp]
000073baab9d83ff  vmovaps xmm1, [rsp+0x10]
000073baab9d8405  vmovaps xmm2, [rsp+0x20]
000073baab9d840b  vmovaps xmm3, [rsp+0x30]
000073baab9d8411  vmovaps xmm4, [rsp+0x40]
000073baab9d8417  vmovaps xmm5, [rsp+0x50]
000073baab9d841d  vmovaps xmm6, [rsp+0x60]
000073baab9d8423  vmovaps xmm7, [rsp+0x70]
000073baab9d8429  vmovaps xmm8, [rsp+0x80]
000073baab9d8432  vmovaps xmm9, [rsp+0x90]
000073baab9d843b  vmovaps xmm10, [rsp+0xA0]
000073baab9d8444  vmovaps xmm12, [rsp+0xB0]
000073baab9d844d  vmovaps xmm13, [rsp+0xC0]
000073baab9d8456  vmovaps xmm14, [rsp+0xD0]
000073baab9d845f  vmovaps xmm15, [rsp+0xE0]
000073baab9d8468  add rsp, 0xF0
000073baab9d846f  pop r11
000073baab9d8471  pop r10
000073baab9d8473  pop r9
000073baab9d8475  pop r8
000073baab9d8477  pop rsi
000073baab9d8478  pop rdi
000073baab9d8479  pop rdx
000073baab9d847a  pop rcx
000073baab9d847b  pop rax
000073baab9d847c  add rsp, 0x08
000073baab9d8480  jmp 0x000073BAAB9D34F4
000073baab9d8485  sub rsp, 0x08
000073baab9d8489  push rax
000073baab9d848a  push rcx
000073baab9d848b  push rdx
000073baab9d848c  push rdi
000073baab9d848d  push rsi
000073baab9d848e  push r8
000073baab9d8490  push r9
000073baab9d8492  push r10
000073baab9d8494  push r11
000073baab9d8496  sub rsp, 0xF0
000073baab9d849d  vmovaps [rsp], xmm0
000073baab9d84a2  vmovaps [rsp+0x10], xmm1
000073baab9d84a8  vmovaps [rsp+0x20], xmm2
000073baab9d84ae  vmovaps [rsp+0x30], xmm3
000073baab9d84b4  vmovaps [rsp+0x40], xmm4
000073baab9d84ba  vmovaps [rsp+0x50], xmm5
000073baab9d84c0  vmovaps [rsp+0x60], xmm6
000073baab9d84c6  vmovaps [rsp+0x70], xmm7
000073baab9d84cc  vmovaps [rsp+0x80], xmm8
000073baab9d84d5  vmovaps [rsp+0x90], xmm9
000073baab9d84de  vmovaps [rsp+0xA0], xmm10
000073baab9d84e7  vmovaps [rsp+0xB0], xmm11
000073baab9d84f0  vmovaps [rsp+0xC0], xmm12
000073baab9d84f9  vmovaps [rsp+0xD0], xmm13
000073baab9d8502  vmovaps [rsp+0xE0], xmm15
000073baab9d850b  sub rsp, 0x30
000073baab9d850f  movaps [rsp], xmm14
000073baab9d8514  movaps [rsp+0x10], xmm12
000073baab9d851a  movaps [rsp+0x20], xmm9
000073baab9d8520  lea rdi, [rsp]
000073baab9d8524  mov esi, 0x00
000073baab9d8529  mov rax, 0x5F3F1062D530
000073baab9d8533  call rax
000073baab9d8535  movaps xmm14, [rsp]
000073baab9d853a  add rsp, 0x30
000073baab9d853e  vmovaps xmm0, [rsp]
000073baab9d8543  vmovaps xmm1, [rsp+0x10]
000073baab9d8549  vmovaps xmm2, [rsp+0x20]
000073baab9d854f  vmovaps xmm3, [rsp+0x30]
000073baab9d8555  vmovaps xmm4, [rsp+0x40]
000073baab9d855b  vmovaps xmm5, [rsp+0x50]
000073baab9d8561  vmovaps xmm6, [rsp+0x60]
000073baab9d8567  vmovaps xmm7, [rsp+0x70]
000073baab9d856d  vmovaps xmm8, [rsp+0x80]
000073baab9d8576  vmovaps xmm9, [rsp+0x90]
000073baab9d857f  vmovaps xmm10, [rsp+0xA0]
000073baab9d8588  vmovaps xmm11, [rsp+0xB0]
000073baab9d8591  vmovaps xmm12, [rsp+0xC0]
000073baab9d859a  vmovaps xmm13, [rsp+0xD0]
000073baab9d85a3  vmovaps xmm15, [rsp+0xE0]
000073baab9d85ac  add rsp, 0xF0
000073baab9d85b3  pop r11
000073baab9d85b5  pop r10
000073baab9d85b7  pop r9
000073baab9d85b9  pop r8
000073baab9d85bb  pop rsi
000073baab9d85bc  pop rdi
000073baab9d85bd  pop rdx
000073baab9d85be  pop rcx
000073baab9d85bf  pop rax
000073baab9d85c0  add rsp, 0x08
000073baab9d85c4  jmp 0x000073BAAB9D350F
000073baab9d85c9  sub rsp, 0x08
000073baab9d85cd  push rax
000073baab9d85ce  push rcx
000073baab9d85cf  push rdx
000073baab9d85d0  push rdi
000073baab9d85d1  push rsi
000073baab9d85d2  push r8
000073baab9d85d4  push r9
000073baab9d85d6  push r10
000073baab9d85d8  push r11
000073baab9d85da  sub rsp, 0xF0
000073baab9d85e1  vmovaps [rsp], xmm0
000073baab9d85e6  vmovaps [rsp+0x10], xmm1
000073baab9d85ec  vmovaps [rsp+0x20], xmm2
000073baab9d85f2  vmovaps [rsp+0x30], xmm3
000073baab9d85f8  vmovaps [rsp+0x40], xmm4
000073baab9d85fe  vmovaps [rsp+0x50], xmm5
000073baab9d8604  vmovaps [rsp+0x60], xmm6
000073baab9d860a  vmovaps [rsp+0x70], xmm7
000073baab9d8610  vmovaps [rsp+0x80], xmm8
000073baab9d8619  vmovaps [rsp+0x90], xmm9
000073baab9d8622  vmovaps [rsp+0xA0], xmm10
000073baab9d862b  vmovaps [rsp+0xB0], xmm11
000073baab9d8634  vmovaps [rsp+0xC0], xmm12
000073baab9d863d  vmovaps [rsp+0xD0], xmm14
000073baab9d8646  vmovaps [rsp+0xE0], xmm15
000073baab9d864f  sub rsp, 0x30
000073baab9d8653  movaps [rsp], xmm13
000073baab9d8658  movaps [rsp+0x10], xmm8
000073baab9d865e  movaps [rsp+0x20], xmm15
000073baab9d8664  lea rdi, [rsp]
000073baab9d8668  mov esi, 0x00
000073baab9d866d  mov rax, 0x5F3F1062D530
000073baab9d8677  call rax
000073baab9d8679  movaps xmm13, [rsp]
000073baab9d867e  add rsp, 0x30
000073baab9d8682  vmovaps xmm0, [rsp]
000073baab9d8687  vmovaps xmm1, [rsp+0x10]
000073baab9d868d  vmovaps xmm2, [rsp+0x20]
000073baab9d8693  vmovaps xmm3, [rsp+0x30]
000073baab9d8699  vmovaps xmm4, [rsp+0x40]
000073baab9d869f  vmovaps xmm5, [rsp+0x50]
000073baab9d86a5  vmovaps xmm6, [rsp+0x60]
000073baab9d86ab  vmovaps xmm7, [rsp+0x70]
000073baab9d86b1  vmovaps xmm8, [rsp+0x80]
000073baab9d86ba  vmovaps xmm9, [rsp+0x90]
000073baab9d86c3  vmovaps xmm10, [rsp+0xA0]
000073baab9d86cc  vmovaps xmm11, [rsp+0xB0]
000073baab9d86d5  vmovaps xmm12, [rsp+0xC0]
000073baab9d86de  vmovaps xmm14, [rsp+0xD0]
000073baab9d86e7  vmovaps xmm15, [rsp+0xE0]
000073baab9d86f0  add rsp, 0xF0
000073baab9d86f7  pop r11
000073baab9d86f9  pop r10
000073baab9d86fb  pop r9
000073baab9d86fd  pop r8
000073baab9d86ff  pop rsi
000073baab9d8700  pop rdi
000073baab9d8701  pop rdx
000073baab9d8702  pop rcx
000073baab9d8703  pop rax
000073baab9d8704  add rsp, 0x08
000073baab9d8708  jmp 0x000073BAAB9D3532
000073baab9d870d  sub rsp, 0x08
000073baab9d8711  push rax
000073baab9d8712  push rcx
000073baab9d8713  push rdx
000073baab9d8714  push rdi
000073baab9d8715  push rsi
000073baab9d8716  push r8
000073baab9d8718  push r9
000073baab9d871a  push r10
000073baab9d871c  push r11
000073baab9d871e  sub rsp, 0xF0
000073baab9d8725  vmovaps [rsp], xmm0
000073baab9d872a  vmovaps [rsp+0x10], xmm1
000073baab9d8730  vmovaps [rsp+0x20], xmm2
000073baab9d8736  vmovaps [rsp+0x30], xmm3
000073baab9d873c  vmovaps [rsp+0x40], xmm4
000073baab9d8742  vmovaps [rsp+0x50], xmm5
000073baab9d8748  vmovaps [rsp+0x60], xmm6
000073baab9d874e  vmovaps [rsp+0x70], xmm7
000073baab9d8754  vmovaps [rsp+0x80], xmm8
000073baab9d875d  vmovaps [rsp+0x90], xmm9
000073baab9d8766  vmovaps [rsp+0xA0], xmm10
000073baab9d876f  vmovaps [rsp+0xB0], xmm11
000073baab9d8778  vmovaps [rsp+0xC0], xmm12
000073baab9d8781  vmovaps [rsp+0xD0], xmm13
000073baab9d878a  vmovaps [rsp+0xE0], xmm14
000073baab9d8793  sub rsp, 0x30
000073baab9d8797  movaps [rsp], xmm15
000073baab9d879c  movaps [rsp+0x10], xmm1
000073baab9d87a1  movaps [rsp+0x20], xmm10
000073baab9d87a7  lea rdi, [rsp]
000073baab9d87ab  mov esi, 0x00
000073baab9d87b0  mov rax, 0x5F3F1062D530
000073baab9d87ba  call rax
000073baab9d87bc  movaps xmm15, [rsp]
000073baab9d87c1  add rsp, 0x30
000073baab9d87c5  vmovaps xmm0, [rsp]
000073baab9d87ca  vmovaps xmm1, [rsp+0x10]
000073baab9d87d0  vmovaps xmm2, [rsp+0x20]
000073baab9d87d6  vmovaps xmm3, [rsp+0x30]
000073baab9d87dc  vmovaps xmm4, [rsp+0x40]
000073baab9d87e2  vmovaps xmm5, [rsp+0x50]
000073baab9d87e8  vmovaps xmm6, [rsp+0x60]
000073baab9d87ee  vmovaps xmm7, [rsp+0x70]
000073baab9d87f4  vmovaps xmm8, [rsp+0x80]
000073baab9d87fd  vmovaps xmm9, [rsp+0x90]
000073baab9d8806  vmovaps xmm10, [rsp+0xA0]
000073baab9d880f  vmovaps xmm11, [rsp+0xB0]
000073baab9d8818  vmovaps xmm12, [rsp+0xC0]
000073baab9d8821  vmovaps xmm13, [rsp+0xD0]
000073baab9d882a  vmovaps xmm14, [rsp+0xE0]
000073baab9d8833  add rsp, 0xF0
000073baab9d883a  pop r11
000073baab9d883c  pop r10
000073baab9d883e  pop r9
000073baab9d8840  pop r8
000073baab9d8842  pop rsi
000073baab9d8843  pop rdi
000073baab9d8844  pop rdx
000073baab9d8845  pop rcx
000073baab9d8846  pop rax
000073baab9d8847  add rsp, 0x08
000073baab9d884b  jmp 0x000073BAAB9D3555
000073baab9d8850  sub rsp, 0x08
000073baab9d8854  push rax
000073baab9d8855  push rcx
000073baab9d8856  push rdx
000073baab9d8857  push rdi
000073baab9d8858  push rsi
000073baab9d8859  push r8
000073baab9d885b  push r9
000073baab9d885d  push r10
000073baab9d885f  push r11
000073baab9d8861  sub rsp, 0xF0
000073baab9d8868  vmovaps [rsp], xmm0
000073baab9d886d  vmovaps [rsp+0x10], xmm2
000073baab9d8873  vmovaps [rsp+0x20], xmm3
000073baab9d8879  vmovaps [rsp+0x30], xmm4
000073baab9d887f  vmovaps [rsp+0x40], xmm5
000073baab9d8885  vmovaps [rsp+0x50], xmm6
000073baab9d888b  vmovaps [rsp+0x60], xmm7
000073baab9d8891  vmovaps [rsp+0x70], xmm8
000073baab9d8897  vmovaps [rsp+0x80], xmm9
000073baab9d88a0  vmovaps [rsp+0x90], xmm10
000073baab9d88a9  vmovaps [rsp+0xA0], xmm11
000073baab9d88b2  vmovaps [rsp+0xB0], xmm12
000073baab9d88bb  vmovaps [rsp+0xC0], xmm13
000073baab9d88c4  vmovaps [rsp+0xD0], xmm14
000073baab9d88cd  vmovaps [rsp+0xE0], xmm15
000073baab9d88d6  sub rsp, 0x30
000073baab9d88da  movaps [rsp], xmm1
000073baab9d88de  movaps [rsp+0x10], xmm7
000073baab9d88e3  movaps [rsp+0x20], xmm11
000073baab9d88e9  lea rdi, [rsp]
000073baab9d88ed  mov esi, 0x00
000073baab9d88f2  mov rax, 0x5F3F1062D530
000073baab9d88fc  call rax
000073baab9d88fe  movaps xmm1, [rsp]
000073baab9d8902  add rsp, 0x30
000073baab9d8906  vmovaps xmm0, [rsp]
000073baab9d890b  vmovaps xmm2, [rsp+0x10]
000073baab9d8911  vmovaps xmm3, [rsp+0x20]
000073baab9d8917  vmovaps xmm4, [rsp+0x30]
000073baab9d891d  vmovaps xmm5, [rsp+0x40]
000073baab9d8923  vmovaps xmm6, [rsp+0x50]
000073baab9d8929  vmovaps xmm7, [rsp+0x60]
000073baab9d892f  vmovaps xmm8, [rsp+0x70]
000073baab9d8935  vmovaps xmm9, [rsp+0x80]
000073baab9d893e  vmovaps xmm10, [rsp+0x90]
000073baab9d8947  vmovaps xmm11, [rsp+0xA0]
000073baab9d8950  vmovaps xmm12, [rsp+0xB0]
000073baab9d8959  vmovaps xmm13, [rsp+0xC0]
000073baab9d8962  vmovaps xmm14, [rsp+0xD0]
000073baab9d896b  vmovaps xmm15, [rsp+0xE0]
000073baab9d8974  add rsp, 0xF0
000073baab9d897b  pop r11
000073baab9d897d  pop r10
000073baab9d897f  pop r9
000073baab9d8981  pop r8
000073baab9d8983  pop rsi
000073baab9d8984  pop rdi
000073baab9d8985  pop rdx
000073baab9d8986  pop rcx
000073baab9d8987  pop rax
000073baab9d8988  add rsp, 0x08
000073baab9d898c  jmp 0x000073BAAB9D3576
000073baab9d8991  call 0x000073BAAB80D600
000073baab9d8996  jmp 0x000073BAAB9D3589
000073baab9d899b  call 0x000073BAAB80C380
000073baab9d89a0  jmp 0x000073BAAB9D3594
000073baab9d89a5  call 0x000073BAAB80E880
000073baab9d89aa  jmp 0x000073BAAB9D359F
000073baab9d89af  call 0x000073BAAB7FF540
000073baab9d89b4  jmp 0x000073BAAB9D35AA
000073baab9d89b9  int3
000073baab9d89ba  nop [rax+rax*1], ax
000073baab9d89c0  mov rax, [r15+0x40]
000073baab9d89c4  mov r14, [r15+0x58]
000073baab9d89c8  lea r12, [rax+r14*1]
000073baab9d89cc  movaps xmm1, [r15+0x1D0]
000073baab9d89d4  vmovaps [rsp+0x10], xmm1
000073baab9d89da  vmovaps xmm15, [rsp+0x10]
000073baab9d89e0  por xmm1, xmm15
000073baab9d89e5  movaps xmm14, [r15+0x1A0]
000073baab9d89ed  vmovaps [rsp+0x10], xmm14
000073baab9d89f3  vmovaps xmm13, [rsp+0x10]
000073baab9d89f9  por xmm14, xmm13
000073baab9d89fe  lea rax, [r12+0x30]
000073baab9d8a03  mov r11, [r13+rax*1]
000073baab9d8a08  lea rax, [r12+0x38]
000073baab9d8a0d  mov r10, [r13+rax*1]
000073baab9d8a12  movq xmm13, r11
000073baab9d8a17  movq xmm12, r10
000073baab9d8a1c  movq xmm13, xmm13
000073baab9d8a21  vmovaps [rsp+0x10], xmm13
000073baab9d8a27  movq xmm13, xmm13
000073baab9d8a2c  movaps [r15+0x130], xmm13
000073baab9d8a34  movq xmm12, xmm12
000073baab9d8a39  vmovaps [rsp+0x20], xmm12
000073baab9d8a3f  movq xmm12, xmm12
000073baab9d8a44  movaps [r15+0x280], xmm12
000073baab9d8a4c  movaps xmm13, [r15+0x270]
000073baab9d8a54  vmovaps [rsp+0x30], xmm13
000073baab9d8a5a  vmovaps xmm12, [rsp+0x30]
000073baab9d8a60  por xmm13, xmm12
000073baab9d8a65  lea rax, [r12+0x20]
000073baab9d8a6a  mov r11, [r13+rax*1]
000073baab9d8a6f  lea rax, [r12+0x28]
000073baab9d8a74  mov r10, [r13+rax*1]
000073baab9d8a79  movq xmm12, r11
000073baab9d8a7e  movq xmm11, r10
000073baab9d8a83  movq xmm12, xmm12
000073baab9d8a88  vmovaps [rsp+0x30], xmm12
000073baab9d8a8e  movq xmm12, xmm12
000073baab9d8a93  movaps [r15+0x150], xmm12
000073baab9d8a9b  movq xmm11, xmm11
000073baab9d8aa0  vmovaps [rsp+0x40], xmm11
000073baab9d8aa6  movq xmm11, xmm11
000073baab9d8aab  movaps [r15+0x140], xmm11
000073baab9d8ab3  lea rax, [r12+0x10]
000073baab9d8ab8  mov r11, [r13+rax*1]
000073baab9d8abd  lea rax, [r12+0x18]
000073baab9d8ac2  mov r10, [r13+rax*1]
000073baab9d8ac7  movq xmm12, r11
000073baab9d8acc  movq xmm11, r10
000073baab9d8ad1  movq xmm12, xmm12
000073baab9d8ad6  vmovaps [rsp+0x50], xmm12
000073baab9d8adc  movq xmm12, xmm12
000073baab9d8ae1  movaps [r15+0x170], xmm12
000073baab9d8ae9  movq xmm11, xmm11
000073baab9d8aee  vmovaps [rsp+0x60], xmm11
000073baab9d8af4  movq xmm11, xmm11
000073baab9d8af9  movaps [r15+0x160], xmm11
000073baab9d8b01  mov rax, [r13+r12*1]
000073baab9d8b06  vmovq xmm12, rax
000073baab9d8b0b  vpbroadcastq xmm12, xmm12
000073baab9d8b10  lea rax, [r12+0x08]
000073baab9d8b15  mov r12, [r13+rax*1]
000073baab9d8b1a  movq xmm11, r12
000073baab9d8b1f  movaps [r15+0x230], xmm11
000073baab9d8b27  mov rax, [r15+0xF8]
000073baab9d8b2e  lea r12, [rax+0x50]
000073baab9d8b32  movups xmm11, [r13+r12*1]
000073baab9d8b38  lea r12, [rax+0x60]
000073baab9d8b3c  movups xmm10, [r13+r12*1]
000073baab9d8b42  lea r12, [rax+0x30]
000073baab9d8b46  movups xmm9, [r13+r12*1]
000073baab9d8b4c  mov r12, [r15+0x50]
000073baab9d8b50  lea r11, [r12+r14*1]
000073baab9d8b54  mov [r15+0x60], r11
000073baab9d8b58  lea r12, [r14+0x40]
000073baab9d8b5c  mov [r15+0x58], r12
000073baab9d8b60  movaps xmm8, xmm12
000073baab9d8b64  mulpd xmm8, xmm15
000073baab9d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
000073baab9d8b6f  ptest xmm7, xmm7
000073baab9d8b74  jnz 0x000073BAAB9D9997
000073baab9d8b7a  movq xmm15, qword ptr [r15+0x230]
000073baab9d8b83  vmovaps [rsp+0x70], xmm15
000073baab9d8b89  vpermilpd xmm15, xmm15, 0x00
000073baab9d8b8f  movaps xmm7, xmm9
000073baab9d8b93  mulpd xmm7, xmm15
000073baab9d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
000073baab9d8b9d  ptest xmm6, xmm6
000073baab9d8ba2  jnz 0x000073BAAB9D9ADB
000073baab9d8ba8  vxorps xmm15, xmm15, xmm15
000073baab9d8bad  vpbroadcastq xmm15, xmm15
000073baab9d8bb2  movaps xmm9, xmm12
000073baab9d8bb6  mulpd xmm9, xmm10
000073baab9d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
000073baab9d8bc1  ptest xmm6, xmm6
000073baab9d8bc6  jnz 0x000073BAAB9D9C1D
000073baab9d8bcc  movaps xmm10, xmm12
000073baab9d8bd0  mulpd xmm10, xmm11
000073baab9d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
000073baab9d8bdb  ptest xmm6, xmm6
000073baab9d8be0  jnz 0x000073BAAB9D9D61
000073baab9d8be6  movaps xmm11, [r15+0x1F0]
000073baab9d8bee  movaps xmm6, xmm12
000073baab9d8bf2  mulpd xmm6, xmm11
000073baab9d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
000073baab9d8bfc  ptest xmm5, xmm5
000073baab9d8c01  jnz 0x000073BAAB9D9EA5
000073baab9d8c07  movaps xmm12, [r15+0x2A0]
000073baab9d8c0f  vmovaps [rsp+0x80], xmm12
000073baab9d8c18  vmovaps xmm11, [rsp+0x80]
000073baab9d8c21  por xmm12, xmm11
000073baab9d8c26  movaps xmm11, [r15+0x250]
000073baab9d8c2e  vmovaps [rsp+0x80], xmm11
000073baab9d8c37  vmovaps xmm5, [rsp+0x80]
000073baab9d8c40  por xmm11, xmm5
000073baab9d8c45  vmovaps xmm4, [rsp+0x70]
000073baab9d8c4b  vpermilpd xmm4, xmm4, 0x00
000073baab9d8c51  movaps xmm3, xmm5
000073baab9d8c54  mulpd xmm3, xmm4
000073baab9d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
000073baab9d8c5d  ptest xmm2, xmm2
000073baab9d8c62  jnz 0x000073BAAB9D9FE7
000073baab9d8c68  mov [rsp+0x80], rax
000073baab9d8c70  xor eax, eax
000073baab9d8c72  mov r14d, 0x200
000073baab9d8c78  cmp r12, r14
000073baab9d8c7b  cmc
000073baab9d8c7c  lahf
000073baab9d8c7d  seto al
000073baab9d8c80  mov [r15+0x108], eax
000073baab9d8c87  movaps xmm5, xmm8
000073baab9d8c8b  addpd xmm5, xmm15
000073baab9d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
000073baab9d8c95  ptest xmm4, xmm4
000073baab9d8c9a  jnz 0x000073BAAB9DA127
000073baab9d8ca0  movaps xmm8, [r15+0x1B0]
000073baab9d8ca8  movaps xmm4, xmm9
000073baab9d8cac  addpd xmm4, xmm8
000073baab9d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
000073baab9d8cb6  ptest xmm2, xmm2
000073baab9d8cbb  jnz 0x000073BAAB9DA269
000073baab9d8cc1  movaps xmm9, xmm10
000073baab9d8cc5  addpd xmm9, xmm8
000073baab9d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
000073baab9d8cd0  ptest xmm2, xmm2
000073baab9d8cd5  jnz 0x000073BAAB9DA3AB
000073baab9d8cdb  movaps xmm10, [r15+0x2F0]
000073baab9d8ce3  vmovaps [rsp+0x90], xmm10
000073baab9d8cec  vmovaps xmm8, [rsp+0x90]
000073baab9d8cf5  por xmm10, xmm8
000073baab9d8cfa  movaps xmm8, [r15+0x2E0]
000073baab9d8d02  vmovaps [rsp+0x90], xmm8
000073baab9d8d0b  vmovaps xmm2, [rsp+0x90]
000073baab9d8d14  por xmm8, xmm2
000073baab9d8d19  movaps xmm2, [r15+0x2D0]
000073baab9d8d21  vmovaps [rsp+0x90], xmm2
000073baab9d8d2a  vmovaps [rsp+0xA0], xmm1
000073baab9d8d33  vmovaps xmm1, [rsp+0x90]
000073baab9d8d3c  por xmm2, xmm1
000073baab9d8d40  movaps xmm1, [r15+0x200]
000073baab9d8d48  vmovaps [rsp+0x90], xmm1
000073baab9d8d51  vmovaps [rsp+0xB0], xmm15
000073baab9d8d5a  vmovaps xmm15, [rsp+0x90]
000073baab9d8d63  por xmm1, xmm15
000073baab9d8d68  movaps xmm15, [r15+0x1C0]
000073baab9d8d70  vmovaps [rsp+0x90], xmm15
000073baab9d8d79  vmovaps [rsp+0xC0], xmm1
000073baab9d8d82  vmovaps xmm1, [rsp+0x90]
000073baab9d8d8b  por xmm15, xmm1
000073baab9d8d90  movaps xmm1, [r15+0x190]
000073baab9d8d98  vmovaps [rsp+0x90], xmm1
000073baab9d8da1  vmovaps [rsp+0xD0], xmm15
000073baab9d8daa  vmovaps xmm15, [rsp+0x90]
000073baab9d8db3  por xmm1, xmm15
000073baab9d8db8  movaps xmm15, [r15+0x300]
000073baab9d8dc0  vmovaps [rsp+0x90], xmm15
000073baab9d8dc9  vmovaps [rsp+0xE0], xmm1
000073baab9d8dd2  vmovaps xmm1, [rsp+0x90]
000073baab9d8ddb  por xmm15, xmm1
000073baab9d8de0  mov rax, [rsp+0x80]
000073baab9d8de8  lea r14, [rax+0xA0]
000073baab9d8def  movups xmm1, [r13+r14*1]
000073baab9d8df5  lea r14, [rax+0xB0]
000073baab9d8dfc  vmovaps [rsp+0x80], xmm1
000073baab9d8e05  movups xmm1, [r13+r14*1]
000073baab9d8e0b  vmovaps [rsp+0x90], xmm1
000073baab9d8e14  vmovaps [rsp+0xF0], xmm15
000073baab9d8e1d  vmovaps xmm15, [rsp+0xB0]
000073baab9d8e26  vmovaps [rsp+0xB0], xmm14
000073baab9d8e2f  movaps xmm1, xmm6
000073baab9d8e32  addpd xmm1, xmm15
000073baab9d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
000073baab9d8e3c  ptest xmm14, xmm14
000073baab9d8e42  jnz 0x000073BAAB9DA503
000073baab9d8e48  lea r14, [rax+0xF0]
000073baab9d8e4f  movups xmm15, [r13+r14*1]
000073baab9d8e55  movaps xmm14, xmm4
000073baab9d8e59  addpd xmm14, xmm3
000073baab9d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
000073baab9d8e64  ptest xmm6, xmm6
000073baab9d8e69  jnz 0x000073BAAB9DA64E
000073baab9d8e6f  movaps xmm6, xmm9
000073baab9d8e73  addpd xmm6, xmm7
000073baab9d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
000073baab9d8e7c  ptest xmm4, xmm4
000073baab9d8e81  jnz 0x000073BAAB9DA790
000073baab9d8e87  vmovaps xmm9, [rsp+0x70]
000073baab9d8e8d  vpermilpd xmm9, xmm9, 0x00
000073baab9d8e93  vmovaps xmm4, [rsp+0x90]
000073baab9d8e9c  movaps xmm7, xmm4
000073baab9d8e9f  mulpd xmm7, xmm9
000073baab9d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
000073baab9d8ea9  ptest xmm3, xmm3
000073baab9d8eae  jnz 0x000073BAAB9DA8D1
000073baab9d8eb4  vmovaps xmm9, [rsp+0x50]
000073baab9d8eba  vpermilpd xmm9, xmm9, 0x00
000073baab9d8ec0  movaps xmm4, xmm15
000073baab9d8ec4  mulpd xmm4, xmm9
000073baab9d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
000073baab9d8ece  ptest xmm3, xmm3
000073baab9d8ed3  jnz 0x000073BAAB9DAA12
000073baab9d8ed9  lea r14, [rax+0xE0]
000073baab9d8ee0  movups xmm15, [r13+r14*1]
000073baab9d8ee6  vmovaps xmm9, [rsp+0x70]
000073baab9d8eec  vpermilpd xmm9, xmm9, 0x00
000073baab9d8ef2  vmovaps [rsp+0x70], xmm1
000073baab9d8ef8  vmovaps xmm1, [rsp+0x80]
000073baab9d8f01  vmovaps [rsp+0x80], xmm15
000073baab9d8f0a  movaps xmm3, xmm1
000073baab9d8f0d  mulpd xmm3, xmm9
000073baab9d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
000073baab9d8f17  ptest xmm15, xmm15
000073baab9d8f1d  jnz 0x000073BAAB9DAB5E
000073baab9d8f23  vmovaps xmm1, [rsp+0xF0]
000073baab9d8f2c  vmovaps xmm15, [rsp+0xF0]
000073baab9d8f35  por xmm1, xmm15
000073baab9d8f3a  movaps [r15+0x300], xmm1
000073baab9d8f42  vmovaps xmm15, [rsp+0xE0]
000073baab9d8f4b  vmovaps xmm9, [rsp+0xE0]
000073baab9d8f54  por xmm15, xmm9
000073baab9d8f59  movaps [r15+0x190], xmm15
000073baab9d8f61  vmovaps xmm9, [rsp+0x50]
000073baab9d8f67  vpermilpd xmm9, xmm9, 0x00
000073baab9d8f6d  vmovaps [rsp+0x90], xmm1
000073baab9d8f76  vmovaps [rsp+0xE0], xmm15
000073baab9d8f7f  vmovaps xmm15, [rsp+0x80]
000073baab9d8f88  vmovaps [rsp+0x80], xmm14
000073baab9d8f91  movaps xmm1, xmm15
000073baab9d8f95  mulpd xmm1, xmm9
000073baab9d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
000073baab9d8f9f  ptest xmm14, xmm14
000073baab9d8fa5  jnz 0x000073BAAB9DAC9F
000073baab9d8fab  lea r14, [rax+0x90]
000073baab9d8fb2  movups xmm15, [r13+r14*1]
000073baab9d8fb8  vmovaps xmm14, [rsp+0xD0]
000073baab9d8fc1  vmovaps xmm9, [rsp+0xD0]
000073baab9d8fca  por xmm14, xmm9
000073baab9d8fcf  movaps [r15+0x1C0], xmm14
000073baab9d8fd7  vmovaps xmm9, [rsp+0xC0]
000073baab9d8fe0  vmovaps [rsp+0xD0], xmm1
000073baab9d8fe9  vmovaps xmm1, [rsp+0xC0]
000073baab9d8ff2  por xmm9, xmm1
000073baab9d8ff7  movaps [r15+0x200], xmm9
000073baab9d8fff  vmovaps [rsp+0xC0], xmm2
000073baab9d9008  vmovaps xmm1, [rsp+0xC0]
000073baab9d9011  por xmm2, xmm1
000073baab9d9015  movaps [r15+0x2D0], xmm2
000073baab9d901d  vmovaps [rsp+0xC0], xmm8
000073baab9d9026  vmovaps xmm1, [rsp+0xC0]
000073baab9d902f  por xmm8, xmm1
000073baab9d9034  movaps [r15+0x2E0], xmm8
000073baab9d903c  vmovaps [rsp+0xC0], xmm15
000073baab9d9045  movaps xmm1, xmm5
000073baab9d9048  addpd xmm1, xmm7
000073baab9d904c  vcmppd xmm15, xmm1, xmm1, 0x03
000073baab9d9051  ptest xmm15, xmm15
000073baab9d9057  jnz 0x000073BAAB9DADEB
000073baab9d905d  vmovaps xmm15, [rsp+0x50]
000073baab9d9063  vpermilpd xmm15, xmm15, 0x00
000073baab9d9069  vmovaps xmm5, [rsp+0xC0]
000073baab9d9072  vmovaps [rsp+0xC0], xmm1
000073baab9d907b  movaps xmm7, xmm5
000073baab9d907e  mulpd xmm7, xmm15
000073baab9d9083  vcmppd xmm1, xmm7, xmm7, 0x03
000073baab9d9088  ptest xmm1, xmm1
000073baab9d908d  jnz 0x000073BAAB9DAF2B
000073baab9d9093  lea r14, [rax+0x80]
000073baab9d909a  movups xmm1, [r13+r14*1]
000073baab9d90a0  vmovaps xmm5, [rsp+0x70]
000073baab9d90a6  vmovaps [rsp+0x70], xmm1
000073baab9d90ac  movaps xmm15, xmm5
000073baab9d90b0  addpd xmm15, xmm3
000073baab9d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
000073baab9d90bb  ptest xmm1, xmm1
000073baab9d90c0  jnz 0x000073BAAB9DB076
000073baab9d90c6  vmovaps xmm5, [rsp+0x80]
000073baab9d90cf  movaps xmm1, xmm5
000073baab9d90d2  addpd xmm1, xmm4
000073baab9d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
000073baab9d90db  ptest xmm3, xmm3
000073baab9d90e0  jnz 0x000073BAAB9DB1B8
000073baab9d90e6  vmovaps [rsp+0x80], xmm10
000073baab9d90ef  vmovaps xmm5, [rsp+0x80]
000073baab9d90f8  por xmm10, xmm5
000073baab9d90fd  movaps [r15+0x2F0], xmm10
000073baab9d9105  vmovaps xmm5, [rsp+0x50]
000073baab9d910b  vpermilpd xmm5, xmm5, 0x00
000073baab9d9111  vmovaps xmm3, [rsp+0x70]
000073baab9d9117  vmovaps [rsp+0x50], xmm1
000073baab9d911d  movaps xmm4, xmm3
000073baab9d9120  mulpd xmm4, xmm5
000073baab9d9124  vcmppd xmm1, xmm4, xmm4, 0x03
000073baab9d9129  ptest xmm1, xmm1
000073baab9d912e  jnz 0x000073BAAB9DB2F8
000073baab9d9134  lea r14, [rax+0xD0]
000073baab9d913b  movups xmm1, [r13+r14*1]
000073baab9d9141  vmovaps xmm3, [rsp+0xD0]
000073baab9d914a  vmovaps [rsp+0x70], xmm1
000073baab9d9150  movaps xmm5, xmm6
000073baab9d9153  addpd xmm5, xmm3
000073baab9d9157  vcmppd xmm1, xmm5, xmm5, 0x03
000073baab9d915c  ptest xmm1, xmm1
000073baab9d9161  jnz 0x000073BAAB9DB442
000073baab9d9167  vmovaps xmm1, [rsp+0x60]
000073baab9d916d  vpermilpd xmm1, xmm1, 0x00
000073baab9d9173  movaps xmm6, xmm9
000073baab9d9177  mulpd xmm6, xmm1
000073baab9d917b  vcmppd xmm3, xmm6, xmm6, 0x03
000073baab9d9180  ptest xmm3, xmm3
000073baab9d9185  jnz 0x000073BAAB9DB582
000073baab9d918b  movaps [r15+0x260], xmm6
000073baab9d9193  vxorps xmm1, xmm1, xmm1
000073baab9d9197  vpbroadcastq xmm1, xmm1
000073baab9d919c  movaps [r15+0x1B0], xmm1
000073baab9d91a4  vmovaps xmm1, [rsp+0x60]
000073baab9d91aa  vpermilpd xmm1, xmm1, 0x00
000073baab9d91b0  vmovaps xmm3, [rsp+0x70]
000073baab9d91b6  vmovaps [rsp+0x70], xmm15
000073baab9d91bc  movaps xmm9, xmm3
000073baab9d91c0  mulpd xmm9, xmm1
000073baab9d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
000073baab9d91cb  ptest xmm15, xmm15
000073baab9d91d1  jnz 0x000073BAAB9DB6C3
000073baab9d91d7  lea r14, [rax+0xC0]
000073baab9d91de  movups xmm1, [r13+r14*1]
000073baab9d91e4  vmovaps xmm3, [rsp+0xC0]
000073baab9d91ed  vmovaps [rsp+0x80], xmm1
000073baab9d91f6  movaps xmm15, xmm3
000073baab9d91fa  addpd xmm15, xmm7
000073baab9d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
000073baab9d9205  ptest xmm1, xmm1
000073baab9d920a  jnz 0x000073BAAB9DB80F
000073baab9d9210  vmovaps [rsp+0xC0], xmm13
000073baab9d9219  vmovaps xmm1, [rsp+0xC0]
000073baab9d9222  por xmm13, xmm1
000073baab9d9227  movaps [r15+0x270], xmm13
000073baab9d922f  vmovaps xmm1, [rsp+0xB0]
000073baab9d9238  vmovaps xmm7, [rsp+0xB0]
000073baab9d9241  por xmm1, xmm7
000073baab9d9245  movaps [r15+0x1A0], xmm1
000073baab9d924d  vmovaps xmm1, [rsp+0x60]
000073baab9d9253  vpermilpd xmm1, xmm1, 0x00
000073baab9d9259  vmovaps [rsp+0xB0], xmm1
000073baab9d9262  vmovaps xmm1, [rsp+0x80]
000073baab9d926b  vmovaps [rsp+0x80], xmm15
000073baab9d9274  vmovaps xmm15, [rsp+0xB0]
000073baab9d927d  vmovaps [rsp+0xB0], xmm14
000073baab9d9286  movaps xmm3, xmm1
000073baab9d9289  mulpd xmm3, xmm15
000073baab9d928e  vcmppd xmm14, xmm3, xmm3, 0x03
000073baab9d9293  ptest xmm14, xmm14
000073baab9d9299  jnz 0x000073BAAB9DB951
000073baab9d929f  lea r14, [rax+0x20]
000073baab9d92a3  movups xmm1, [r13+r14*1]
000073baab9d92a9  movaps [r15+0x110], xmm1
000073baab9d92b1  vmovaps xmm14, [rsp+0x70]
000073baab9d92b7  vmovaps [rsp+0x70], xmm1
000073baab9d92bd  movaps xmm15, xmm14
000073baab9d92c1  addpd xmm15, xmm4
000073baab9d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
000073baab9d92cc  ptest xmm1, xmm1
000073baab9d92d1  jnz 0x000073BAAB9DBA9C
000073baab9d92d7  vmovaps xmm1, [rsp+0x60]
000073baab9d92dd  vpermilpd xmm1, xmm1, 0x00
000073baab9d92e3  movaps xmm14, xmm2
000073baab9d92e7  mulpd xmm14, xmm1
000073baab9d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
000073baab9d92f2  ptest xmm4, xmm4
000073baab9d92f7  jnz 0x000073BAAB9DBBDF
000073baab9d92fd  vmovaps xmm4, [rsp+0x50]
000073baab9d9303  movaps xmm1, xmm4
000073baab9d9306  addpd xmm1, xmm9
000073baab9d930b  vcmppd xmm2, xmm1, xmm1, 0x03
000073baab9d9310  ptest xmm2, xmm2
000073baab9d9315  jnz 0x000073BAAB9DBD21
000073baab9d931b  vmovaps xmm9, [rsp+0x30]
000073baab9d9321  vpermilpd xmm9, xmm9, 0x00
000073baab9d9327  vmovaps xmm2, [rsp+0x70]
000073baab9d932d  vmovaps [rsp+0x50], xmm1
000073baab9d9333  movaps xmm4, xmm2
000073baab9d9336  mulpd xmm4, xmm9
000073baab9d933b  vcmppd xmm1, xmm4, xmm4, 0x03
000073baab9d9340  ptest xmm1, xmm1
000073baab9d9345  jnz 0x000073BAAB9DBE62
000073baab9d934b  vmovaps xmm1, [rsp+0x30]
000073baab9d9351  vpermilpd xmm1, xmm1, 0x00
000073baab9d9357  vmovaps xmm2, [rsp+0x90]
000073baab9d9360  vmovaps [rsp+0x60], xmm15
000073baab9d9366  movaps xmm9, xmm2
000073baab9d936a  mulpd xmm9, xmm1
000073baab9d936f  vcmppd xmm15, xmm9, xmm9, 0x03
000073baab9d9375  ptest xmm15, xmm15
000073baab9d937b  jnz 0x000073BAAB9DBFA3
000073baab9d9381  vmovaps xmm15, [rsp+0x80]
000073baab9d938a  movaps xmm1, xmm15
000073baab9d938e  addpd xmm1, xmm6
000073baab9d9392  vcmppd xmm2, xmm1, xmm1, 0x03
000073baab9d9397  ptest xmm2, xmm2
000073baab9d939c  jnz 0x000073BAAB9DC0E5
000073baab9d93a2  movaps xmm15, xmm5
000073baab9d93a6  addpd xmm15, xmm3
000073baab9d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
000073baab9d93b1  ptest xmm6, xmm6
000073baab9d93b6  jnz 0x000073BAAB9DC226
000073baab9d93bc  vmovaps xmm6, [rsp+0x30]
000073baab9d93c2  vpermilpd xmm6, xmm6, 0x00
000073baab9d93c8  movaps xmm5, xmm8
000073baab9d93cc  mulpd xmm5, xmm6
000073baab9d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
000073baab9d93d5  ptest xmm3, xmm3
000073baab9d93da  jnz 0x000073BAAB9DC368
000073baab9d93e0  vmovaps xmm8, [rsp+0x30]
000073baab9d93e6  vpermilpd xmm8, xmm8, 0x00
000073baab9d93ec  movaps xmm6, xmm10
000073baab9d93f0  mulpd xmm6, xmm8
000073baab9d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
000073baab9d93fa  ptest xmm3, xmm3
000073baab9d93ff  jnz 0x000073BAAB9DC4A9
000073baab9d9405  vmovaps xmm8, [rsp+0x60]
000073baab9d940b  movaps xmm10, xmm8
000073baab9d940f  addpd xmm10, xmm14
000073baab9d9414  vcmppd xmm3, xmm10, xmm10, 0x03
000073baab9d941a  ptest xmm3, xmm3
000073baab9d941f  jnz 0x000073BAAB9DC5EB
000073baab9d9425  vmovaps xmm8, [rsp+0x50]
000073baab9d942b  movaps xmm14, xmm8
000073baab9d942f  addpd xmm14, xmm4
000073baab9d9434  vcmppd xmm3, xmm14, xmm14, 0x03
000073baab9d943a  ptest xmm3, xmm3
000073baab9d943f  jnz 0x000073BAAB9DC72F
000073baab9d9445  vmovaps xmm8, [rsp+0x40]
000073baab9d944b  vpermilpd xmm8, xmm8, 0x00
000073baab9d9451  movaps xmm4, xmm13
000073baab9d9455  mulpd xmm4, xmm8
000073baab9d945a  vcmppd xmm3, xmm4, xmm4, 0x03
000073baab9d945f  ptest xmm3, xmm3
000073baab9d9464  jnz 0x000073BAAB9DC872
000073baab9d946a  movaps xmm13, xmm15
000073baab9d946e  addpd xmm13, xmm9
000073baab9d9473  vcmppd xmm8, xmm13, xmm13, 0x03
000073baab9d9479  ptest xmm8, xmm8
000073baab9d947f  jnz 0x000073BAAB9DC9B4
000073baab9d9485  movaps xmm15, xmm1
000073baab9d9489  addpd xmm15, xmm5
000073baab9d948e  vcmppd xmm9, xmm15, xmm15, 0x03
000073baab9d9494  ptest xmm9, xmm9
000073baab9d949a  jnz 0x000073BAAB9DCAF8
000073baab9d94a0  vmovaps [rsp+0x30], xmm11
000073baab9d94a6  vmovaps xmm1, [rsp+0x30]
000073baab9d94ac  por xmm11, xmm1
000073baab9d94b1  movaps [r15+0x250], xmm11
000073baab9d94b9  vmovaps [rsp+0x30], xmm12
000073baab9d94bf  vmovaps xmm1, [rsp+0x30]
000073baab9d94c5  por xmm12, xmm1
000073baab9d94ca  movaps [r15+0x2A0], xmm12
000073baab9d94d2  vmovaps xmm1, [rsp+0xA0]
000073baab9d94db  vmovaps xmm11, [rsp+0xA0]
000073baab9d94e4  por xmm1, xmm11
000073baab9d94e9  movaps [r15+0x1D0], xmm1
000073baab9d94f1  lea r14, [rax+0x40]
000073baab9d94f5  movups xmm1, [r13+r14*1]
000073baab9d94fb  movaps [r15+0x2C0], xmm1
000073baab9d9503  vmovaps xmm11, [rsp+0x40]
000073baab9d9509  vpermilpd xmm11, xmm11, 0x00
000073baab9d950f  vmovaps xmm8, [rsp+0xE0]
000073baab9d9518  movaps xmm9, xmm8
000073baab9d951c  mulpd xmm9, xmm11
000073baab9d9521  vcmppd xmm5, xmm9, xmm9, 0x03
000073baab9d9527  ptest xmm5, xmm5
000073baab9d952c  jnz 0x000073BAAB9DCC44
000073baab9d9532  movaps xmm11, xmm10
000073baab9d9536  addpd xmm11, xmm6
000073baab9d953b  vcmppd xmm8, xmm11, xmm11, 0x03
000073baab9d9541  ptest xmm8, xmm8
000073baab9d9547  jnz 0x000073BAAB9DCD88
000073baab9d954d  movaps xmm10, xmm14
000073baab9d9551  addpd xmm10, xmm4
000073baab9d9556  vcmppd xmm8, xmm10, xmm10, 0x03
000073baab9d955c  ptest xmm8, xmm8
000073baab9d9562  jnz 0x000073BAAB9DCECB
000073baab9d9568  vmovaps xmm14, [rsp+0x40]
000073baab9d956e  vpermilpd xmm14, xmm14, 0x00
000073baab9d9574  movaps xmm8, xmm1
000073baab9d9578  mulpd xmm8, xmm14
000073baab9d957d  vcmppd xmm6, xmm8, xmm8, 0x03
000073baab9d9583  ptest xmm6, xmm6
000073baab9d9588  jnz 0x000073BAAB9DD00E
000073baab9d958e  movaps xmm1, [r15+0x2B0]
000073baab9d9596  vmovaps xmm14, [rsp+0x40]
000073baab9d959c  vpermilpd xmm14, xmm14, 0x00
000073baab9d95a2  movaps xmm6, xmm1
000073baab9d95a5  mulpd xmm6, xmm14
000073baab9d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
000073baab9d95af  ptest xmm5, xmm5
000073baab9d95b4  jnz 0x000073BAAB9DD151
000073baab9d95ba  vmovaps xmm1, [rsp+0x10]
000073baab9d95c0  vpermilpd xmm1, xmm1, 0x00
000073baab9d95c6  movaps xmm14, xmm12
000073baab9d95ca  mulpd xmm14, xmm1
000073baab9d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
000073baab9d95d5  ptest xmm5, xmm5
000073baab9d95da  jnz 0x000073BAAB9DD292
000073baab9d95e0  movaps xmm1, xmm13
000073baab9d95e4  addpd xmm1, xmm9
000073baab9d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
000073baab9d95ee  ptest xmm12, xmm12
000073baab9d95f4  jnz 0x000073BAAB9DD3D5
000073baab9d95fa  vmovaps xmm13, [rsp+0x10]
000073baab9d9600  vpermilpd xmm13, xmm13, 0x00
000073baab9d9606  movaps xmm12, xmm7
000073baab9d960a  mulpd xmm12, xmm13
000073baab9d960f  vcmppd xmm9, xmm12, xmm12, 0x03
000073baab9d9615  ptest xmm9, xmm9
000073baab9d961b  jnz 0x000073BAAB9DD517
000073baab9d9621  movaps xmm13, xmm15
000073baab9d9625  addpd xmm13, xmm8
000073baab9d962a  vcmppd xmm9, xmm13, xmm13, 0x03
000073baab9d9630  ptest xmm9, xmm9
000073baab9d9636  jnz 0x000073BAAB9DD65A
000073baab9d963c  movaps xmm15, [r15+0x290]
000073baab9d9644  vmovaps xmm9, [rsp+0x10]
000073baab9d964a  vpermilpd xmm9, xmm9, 0x00
000073baab9d9650  movaps xmm8, xmm15
000073baab9d9654  mulpd xmm8, xmm9
000073baab9d9659  vcmppd xmm7, xmm8, xmm8, 0x03
000073baab9d965f  ptest xmm7, xmm7
000073baab9d9664  jnz 0x000073BAAB9DD79E
000073baab9d966a  movaps xmm15, xmm11
000073baab9d966e  addpd xmm15, xmm6
000073baab9d9673  vcmppd xmm9, xmm15, xmm15, 0x03
000073baab9d9679  ptest xmm9, xmm9
000073baab9d967f  jnz 0x000073BAAB9DD8E2
000073baab9d9685  movaps xmm11, [r15+0x1E0]
000073baab9d968d  vmovaps xmm9, [rsp+0x10]
000073baab9d9693  vpermilpd xmm9, xmm9, 0x00
000073baab9d9699  movaps xmm7, xmm11
000073baab9d969d  mulpd xmm7, xmm9
000073baab9d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
000073baab9d96a7  ptest xmm6, xmm6
000073baab9d96ac  jnz 0x000073BAAB9DDA25
000073baab9d96b2  movaps xmm11, xmm10
000073baab9d96b6  addpd xmm11, xmm14
000073baab9d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
000073baab9d96c1  ptest xmm9, xmm9
000073baab9d96c7  jnz 0x000073BAAB9DDB67
000073baab9d96cd  lea r14, [rax+0x70]
000073baab9d96d1  movups xmm14, [r13+r14*1]
000073baab9d96d7  movaps [r15+0x240], xmm14
000073baab9d96df  movaps xmm10, xmm1
000073baab9d96e3  addpd xmm10, xmm12
000073baab9d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
000073baab9d96ee  ptest xmm9, xmm9
000073baab9d96f4  jnz 0x000073BAAB9DDCB5
000073baab9d96fa  movaps [r15+0x170], xmm10
000073baab9d9702  vmovaps xmm1, [rsp+0x20]
000073baab9d9708  vpermilpd xmm1, xmm1, 0x00
000073baab9d970e  movaps xmm12, xmm14
000073baab9d9712  mulpd xmm12, xmm1
000073baab9d9717  vcmppd xmm9, xmm12, xmm12, 0x03
000073baab9d971d  ptest xmm9, xmm9
000073baab9d9723  jnz 0x000073BAAB9DDDF8
000073baab9d9729  vmovaps xmm1, [rsp+0x20]
000073baab9d972f  vpermilpd xmm1, xmm1, 0x00
000073baab9d9735  vmovaps xmm9, [rsp+0xB0]
000073baab9d973e  movaps xmm14, xmm9
000073baab9d9742  mulpd xmm14, xmm1
000073baab9d9747  vcmppd xmm6, xmm14, xmm14, 0x03
000073baab9d974d  ptest xmm6, xmm6
000073baab9d9752  jnz 0x000073BAAB9DDF3B
000073baab9d9758  movaps [r15+0x180], xmm14
000073baab9d9760  movaps xmm1, xmm13
000073baab9d9764  addpd xmm1, xmm8
000073baab9d9769  vcmppd xmm9, xmm1, xmm1, 0x03
000073baab9d976e  ptest xmm9, xmm9
000073baab9d9774  jnz 0x000073BAAB9DE07E
000073baab9d977a  movaps [r15+0x210], xmm1
000073baab9d9782  movups xmm13, [r13+rax*1]
000073baab9d9788  lea r14, [rax+0x10]
000073baab9d978c  movups xmm9, [r13+r14*1]
000073baab9d9792  movaps [r15+0x230], xmm9
000073baab9d979a  movaps xmm8, xmm15
000073baab9d979e  addpd xmm8, xmm7
000073baab9d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
000073baab9d97a9  ptest xmm6, xmm6
000073baab9d97ae  jnz 0x000073BAAB9DE1D4
000073baab9d97b4  movaps [r15+0x130], xmm8
000073baab9d97bc  vmovaps xmm15, [rsp+0x20]
000073baab9d97c2  vpermilpd xmm15, xmm15, 0x00
000073baab9d97c8  movaps xmm7, xmm9
000073baab9d97cc  mulpd xmm7, xmm15
000073baab9d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
000073baab9d97d6  ptest xmm6, xmm6
000073baab9d97db  jnz 0x000073BAAB9DE317
000073baab9d97e1  movaps [r15+0x220], xmm7
000073baab9d97e9  vmovaps xmm15, [rsp+0x20]
000073baab9d97ef  vpermilpd xmm15, xmm15, 0x00
000073baab9d97f5  movaps xmm9, xmm13
000073baab9d97f9  mulpd xmm9, xmm15
000073baab9d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
000073baab9d9804  ptest xmm6, xmm6
000073baab9d9809  jnz 0x000073BAAB9DE459
000073baab9d980f  movaps xmm15, xmm11
000073baab9d9813  addpd xmm15, xmm12
000073baab9d9818  vcmppd xmm13, xmm15, xmm15, 0x03
000073baab9d981e  ptest xmm13, xmm13
000073baab9d9824  jnz 0x000073BAAB9DE59D
000073baab9d982a  movaps [r15+0x140], xmm15
000073baab9d9832  movaps xmm13, xmm10
000073baab9d9836  addpd xmm13, xmm14
000073baab9d983b  vcmppd xmm12, xmm13, xmm13, 0x03
000073baab9d9841  ptest xmm12, xmm12
000073baab9d9847  jnz 0x000073BAAB9DE6E1
000073baab9d984d  movaps [r15+0x150], xmm13
000073baab9d9855  movaps xmm14, xmm1
000073baab9d9859  addpd xmm14, xmm7
000073baab9d985e  vcmppd xmm12, xmm14, xmm14, 0x03
000073baab9d9864  ptest xmm12, xmm12
000073baab9d986a  jnz 0x000073BAAB9DE825
000073baab9d9870  movaps [r15+0x160], xmm14
000073baab9d9878  movaps xmm1, xmm8
000073baab9d987c  addpd xmm1, xmm9
000073baab9d9881  vcmppd xmm12, xmm1, xmm1, 0x03
000073baab9d9886  ptest xmm12, xmm12
000073baab9d988c  jnz 0x000073BAAB9DE967
000073baab9d9892  movaps [r15+0x120], xmm1
000073baab9d989a  movups [r13+r11*1], xmm15
000073baab9d98a0  lea rax, [r11+0x10]
000073baab9d98a4  movups [r13+rax*1], xmm13
000073baab9d98aa  lea rax, [r11+0x20]
000073baab9d98ae  movups [r13+rax*1], xmm14
000073baab9d98b4  lea rax, [r11+0x30]
000073baab9d98b8  movups [r13+rax*1], xmm1
000073baab9d98be  mov eax, [r15+0x108]
000073baab9d98c5  sahf
000073baab9d98c6  jnz 0x000073BAAB9D98F8
000073baab9d98c8  cmp dword ptr [r15+0x318], 0x00
000073baab9d98d0  jz 0x000073BAAB9DEAE0
000073baab9d98d6  nop [rax+rax*1], ax
000073baab9d98df  nop [rax+rax*1], eax
000073baab9d98e7  mov eax, 0x4106D0
000073baab9d98ec  mov [r15+0x100], rax
000073baab9d98f3  jmp 0x000073BAAB7FE110
000073baab9d98f8  cmp dword ptr [r15+0x318], 0x00
000073baab9d9900  jz 0x000073BAAB9D89C0
000073baab9d9906  nop [rax+rax*1], ax
000073baab9d990f  nop [rax+rax*1], eax
000073baab9d9917  mov eax, 0x410504
000073baab9d991c  mov [r15+0x100], rax
000073baab9d9923  jmp 0x000073BAAB7FE110
000073baab9d9928  int3
000073baab9d9929  call 0x000073BAAB80A4B0
000073baab9d992e  jmp 0x000073BAAB9D8A08
000073baab9d9933  call 0x000073BAAB809240
000073baab9d9938  jmp 0x000073BAAB9D8A12
000073baab9d993d  call 0x000073BAAB80A4B0
000073baab9d9942  jmp 0x000073BAAB9D8A6F
000073baab9d9947  call 0x000073BAAB809240
000073baab9d994c  jmp 0x000073BAAB9D8A79
000073baab9d9951  call 0x000073BAAB80A4B0
000073baab9d9956  jmp 0x000073BAAB9D8ABD
000073baab9d995b  call 0x000073BAAB809240
000073baab9d9960  jmp 0x000073BAAB9D8AC7
000073baab9d9965  call 0x000073BAAB8B47C0
000073baab9d996a  jmp 0x000073BAAB9D8B06
000073baab9d996f  call 0x000073BAAB80B720
000073baab9d9974  jmp 0x000073BAAB9D8B1A
000073baab9d9979  call 0x000073BAAB8BFC30
000073baab9d997e  jmp 0x000073BAAB9D8B38
000073baab9d9983  call 0x000073BAAB8BE9C0
000073baab9d9988  jmp 0x000073BAAB9D8B42
000073baab9d998d  call 0x000073BAAB8BD750
000073baab9d9992  jmp 0x000073BAAB9D8B4C
000073baab9d9997  sub rsp, 0x08
000073baab9d999b  push rax
000073baab9d999c  push rcx
000073baab9d999d  push rdx
000073baab9d999e  push rdi
000073baab9d999f  push rsi
000073baab9d99a0  push r8
000073baab9d99a2  push r9
000073baab9d99a4  push r10
000073baab9d99a6  push r11
000073baab9d99a8  sub rsp, 0xF0
000073baab9d99af  vmovaps [rsp], xmm0
000073baab9d99b4  vmovaps [rsp+0x10], xmm1
000073baab9d99ba  vmovaps [rsp+0x20], xmm2
000073baab9d99c0  vmovaps [rsp+0x30], xmm3
000073baab9d99c6  vmovaps [rsp+0x40], xmm4
000073baab9d99cc  vmovaps [rsp+0x50], xmm5
000073baab9d99d2  vmovaps [rsp+0x60], xmm6
000073baab9d99d8  vmovaps [rsp+0x70], xmm7
000073baab9d99de  vmovaps [rsp+0x80], xmm9
000073baab9d99e7  vmovaps [rsp+0x90], xmm10
000073baab9d99f0  vmovaps [rsp+0xA0], xmm11
000073baab9d99f9  vmovaps [rsp+0xB0], xmm12
000073baab9d9a02  vmovaps [rsp+0xC0], xmm13
000073baab9d9a0b  vmovaps [rsp+0xD0], xmm14
000073baab9d9a14  vmovaps [rsp+0xE0], xmm15
000073baab9d9a1d  sub rsp, 0x30
000073baab9d9a21  movaps [rsp], xmm8
000073baab9d9a26  movaps [rsp+0x10], xmm12
000073baab9d9a2c  movaps [rsp+0x20], xmm15
000073baab9d9a32  lea rdi, [rsp]
000073baab9d9a36  mov esi, 0x00
000073baab9d9a3b  mov rax, 0x5F3F1062D530
000073baab9d9a45  call rax
000073baab9d9a47  movaps xmm8, [rsp]
000073baab9d9a4c  add rsp, 0x30
000073baab9d9a50  vmovaps xmm0, [rsp]
000073baab9d9a55  vmovaps xmm1, [rsp+0x10]
000073baab9d9a5b  vmovaps xmm2, [rsp+0x20]
000073baab9d9a61  vmovaps xmm3, [rsp+0x30]
000073baab9d9a67  vmovaps xmm4, [rsp+0x40]
000073baab9d9a6d  vmovaps xmm5, [rsp+0x50]
000073baab9d9a73  vmovaps xmm6, [rsp+0x60]
000073baab9d9a79  vmovaps xmm7, [rsp+0x70]
000073baab9d9a7f  vmovaps xmm9, [rsp+0x80]
000073baab9d9a88  vmovaps xmm10, [rsp+0x90]
000073baab9d9a91  vmovaps xmm11, [rsp+0xA0]
000073baab9d9a9a  vmovaps xmm12, [rsp+0xB0]
000073baab9d9aa3  vmovaps xmm13, [rsp+0xC0]
000073baab9d9aac  vmovaps xmm14, [rsp+0xD0]
000073baab9d9ab5  vmovaps xmm15, [rsp+0xE0]
000073baab9d9abe  add rsp, 0xF0
000073baab9d9ac5  pop r11
000073baab9d9ac7  pop r10
000073baab9d9ac9  pop r9
000073baab9d9acb  pop r8
000073baab9d9acd  pop rsi
000073baab9d9ace  pop rdi
000073baab9d9acf  pop rdx
000073baab9d9ad0  pop rcx
000073baab9d9ad1  pop rax
000073baab9d9ad2  add rsp, 0x08
000073baab9d9ad6  jmp 0x000073BAAB9D8B7A
000073baab9d9adb  sub rsp, 0x08
000073baab9d9adf  push rax
000073baab9d9ae0  push rcx
000073baab9d9ae1  push rdx
000073baab9d9ae2  push rdi
000073baab9d9ae3  push rsi
000073baab9d9ae4  push r8
000073baab9d9ae6  push r9
000073baab9d9ae8  push r10
000073baab9d9aea  push r11
000073baab9d9aec  sub rsp, 0xF0
000073baab9d9af3  vmovaps [rsp], xmm0
000073baab9d9af8  vmovaps [rsp+0x10], xmm1
000073baab9d9afe  vmovaps [rsp+0x20], xmm2
000073baab9d9b04  vmovaps [rsp+0x30], xmm3
000073baab9d9b0a  vmovaps [rsp+0x40], xmm4
000073baab9d9b10  vmovaps [rsp+0x50], xmm5
000073baab9d9b16  vmovaps [rsp+0x60], xmm6
000073baab9d9b1c  vmovaps [rsp+0x70], xmm8
000073baab9d9b22  vmovaps [rsp+0x80], xmm9
000073baab9d9b2b  vmovaps [rsp+0x90], xmm10
000073baab9d9b34  vmovaps [rsp+0xA0], xmm11
000073baab9d9b3d  vmovaps [rsp+0xB0], xmm12
000073baab9d9b46  vmovaps [rsp+0xC0], xmm13
000073baab9d9b4f  vmovaps [rsp+0xD0], xmm14
000073baab9d9b58  vmovaps [rsp+0xE0], xmm15
000073baab9d9b61  sub rsp, 0x30
000073baab9d9b65  movaps [rsp], xmm7
000073baab9d9b69  movaps [rsp+0x10], xmm9
000073baab9d9b6f  movaps [rsp+0x20], xmm15
000073baab9d9b75  lea rdi, [rsp]
000073baab9d9b79  mov esi, 0x00
000073baab9d9b7e  mov rax, 0x5F3F1062D530
000073baab9d9b88  call rax
000073baab9d9b8a  movaps xmm7, [rsp]
000073baab9d9b8e  add rsp, 0x30
000073baab9d9b92  vmovaps xmm0, [rsp]
000073baab9d9b97  vmovaps xmm1, [rsp+0x10]
000073baab9d9b9d  vmovaps xmm2, [rsp+0x20]
000073baab9d9ba3  vmovaps xmm3, [rsp+0x30]
000073baab9d9ba9  vmovaps xmm4, [rsp+0x40]
000073baab9d9baf  vmovaps xmm5, [rsp+0x50]
000073baab9d9bb5  vmovaps xmm6, [rsp+0x60]
000073baab9d9bbb  vmovaps xmm8, [rsp+0x70]
000073baab9d9bc1  vmovaps xmm9, [rsp+0x80]
000073baab9d9bca  vmovaps xmm10, [rsp+0x90]
000073baab9d9bd3  vmovaps xmm11, [rsp+0xA0]
000073baab9d9bdc  vmovaps xmm12, [rsp+0xB0]
000073baab9d9be5  vmovaps xmm13, [rsp+0xC0]
000073baab9d9bee  vmovaps xmm14, [rsp+0xD0]
000073baab9d9bf7  vmovaps xmm15, [rsp+0xE0]
000073baab9d9c00  add rsp, 0xF0
000073baab9d9c07  pop r11
000073baab9d9c09  pop r10
000073baab9d9c0b  pop r9
000073baab9d9c0d  pop r8
000073baab9d9c0f  pop rsi
000073baab9d9c10  pop rdi
000073baab9d9c11  pop rdx
000073baab9d9c12  pop rcx
000073baab9d9c13  pop rax
000073baab9d9c14  add rsp, 0x08
000073baab9d9c18  jmp 0x000073BAAB9D8BA8
000073baab9d9c1d  sub rsp, 0x08
000073baab9d9c21  push rax
000073baab9d9c22  push rcx
000073baab9d9c23  push rdx
000073baab9d9c24  push rdi
000073baab9d9c25  push rsi
000073baab9d9c26  push r8
000073baab9d9c28  push r9
000073baab9d9c2a  push r10
000073baab9d9c2c  push r11
000073baab9d9c2e  sub rsp, 0xF0
000073baab9d9c35  vmovaps [rsp], xmm0
000073baab9d9c3a  vmovaps [rsp+0x10], xmm1
000073baab9d9c40  vmovaps [rsp+0x20], xmm2
000073baab9d9c46  vmovaps [rsp+0x30], xmm3
000073baab9d9c4c  vmovaps [rsp+0x40], xmm4
000073baab9d9c52  vmovaps [rsp+0x50], xmm5
000073baab9d9c58  vmovaps [rsp+0x60], xmm6
000073baab9d9c5e  vmovaps [rsp+0x70], xmm7
000073baab9d9c64  vmovaps [rsp+0x80], xmm8
000073baab9d9c6d  vmovaps [rsp+0x90], xmm10
000073baab9d9c76  vmovaps [rsp+0xA0], xmm11
000073baab9d9c7f  vmovaps [rsp+0xB0], xmm12
000073baab9d9c88  vmovaps [rsp+0xC0], xmm13
000073baab9d9c91  vmovaps [rsp+0xD0], xmm14
000073baab9d9c9a  vmovaps [rsp+0xE0], xmm15
000073baab9d9ca3  sub rsp, 0x30
000073baab9d9ca7  movaps [rsp], xmm9
000073baab9d9cac  movaps [rsp+0x10], xmm12
000073baab9d9cb2  movaps [rsp+0x20], xmm10
000073baab9d9cb8  lea rdi, [rsp]
000073baab9d9cbc  mov esi, 0x00
000073baab9d9cc1  mov rax, 0x5F3F1062D530
000073baab9d9ccb  call rax
000073baab9d9ccd  movaps xmm9, [rsp]
000073baab9d9cd2  add rsp, 0x30
000073baab9d9cd6  vmovaps xmm0, [rsp]
000073baab9d9cdb  vmovaps xmm1, [rsp+0x10]
000073baab9d9ce1  vmovaps xmm2, [rsp+0x20]
000073baab9d9ce7  vmovaps xmm3, [rsp+0x30]
000073baab9d9ced  vmovaps xmm4, [rsp+0x40]
000073baab9d9cf3  vmovaps xmm5, [rsp+0x50]
000073baab9d9cf9  vmovaps xmm6, [rsp+0x60]
000073baab9d9cff  vmovaps xmm7, [rsp+0x70]
000073baab9d9d05  vmovaps xmm8, [rsp+0x80]
000073baab9d9d0e  vmovaps xmm10, [rsp+0x90]
000073baab9d9d17  vmovaps xmm11, [rsp+0xA0]
000073baab9d9d20  vmovaps xmm12, [rsp+0xB0]
000073baab9d9d29  vmovaps xmm13, [rsp+0xC0]
000073baab9d9d32  vmovaps xmm14, [rsp+0xD0]
000073baab9d9d3b  vmovaps xmm15, [rsp+0xE0]
000073baab9d9d44  add rsp, 0xF0
000073baab9d9d4b  pop r11
000073baab9d9d4d  pop r10
000073baab9d9d4f  pop r9
000073baab9d9d51  pop r8
000073baab9d9d53  pop rsi
000073baab9d9d54  pop rdi
000073baab9d9d55  pop rdx
000073baab9d9d56  pop rcx
000073baab9d9d57  pop rax
000073baab9d9d58  add rsp, 0x08
000073baab9d9d5c  jmp 0x000073BAAB9D8BCC
000073baab9d9d61  sub rsp, 0x08
000073baab9d9d65  push rax
000073baab9d9d66  push rcx
000073baab9d9d67  push rdx
000073baab9d9d68  push rdi
000073baab9d9d69  push rsi
000073baab9d9d6a  push r8
000073baab9d9d6c  push r9
000073baab9d9d6e  push r10
000073baab9d9d70  push r11
000073baab9d9d72  sub rsp, 0xF0
000073baab9d9d79  vmovaps [rsp], xmm0
000073baab9d9d7e  vmovaps [rsp+0x10], xmm1
000073baab9d9d84  vmovaps [rsp+0x20], xmm2
000073baab9d9d8a  vmovaps [rsp+0x30], xmm3
000073baab9d9d90  vmovaps [rsp+0x40], xmm4
000073baab9d9d96  vmovaps [rsp+0x50], xmm5
000073baab9d9d9c  vmovaps [rsp+0x60], xmm6
000073baab9d9da2  vmovaps [rsp+0x70], xmm7
000073baab9d9da8  vmovaps [rsp+0x80], xmm8
000073baab9d9db1  vmovaps [rsp+0x90], xmm9
000073baab9d9dba  vmovaps [rsp+0xA0], xmm11
000073baab9d9dc3  vmovaps [rsp+0xB0], xmm12
000073baab9d9dcc  vmovaps [rsp+0xC0], xmm13
000073baab9d9dd5  vmovaps [rsp+0xD0], xmm14
000073baab9d9dde  vmovaps [rsp+0xE0], xmm15
000073baab9d9de7  sub rsp, 0x30
000073baab9d9deb  movaps [rsp], xmm10
000073baab9d9df0  movaps [rsp+0x10], xmm12
000073baab9d9df6  movaps [rsp+0x20], xmm11
000073baab9d9dfc  lea rdi, [rsp]
000073baab9d9e00  mov esi, 0x00
000073baab9d9e05  mov rax, 0x5F3F1062D530
000073baab9d9e0f  call rax
000073baab9d9e11  movaps xmm10, [rsp]
000073baab9d9e16  add rsp, 0x30
000073baab9d9e1a  vmovaps xmm0, [rsp]
000073baab9d9e1f  vmovaps xmm1, [rsp+0x10]
000073baab9d9e25  vmovaps xmm2, [rsp+0x20]
000073baab9d9e2b  vmovaps xmm3, [rsp+0x30]
000073baab9d9e31  vmovaps xmm4, [rsp+0x40]
000073baab9d9e37  vmovaps xmm5, [rsp+0x50]
000073baab9d9e3d  vmovaps xmm6, [rsp+0x60]
000073baab9d9e43  vmovaps xmm7, [rsp+0x70]
000073baab9d9e49  vmovaps xmm8, [rsp+0x80]
000073baab9d9e52  vmovaps xmm9, [rsp+0x90]
000073baab9d9e5b  vmovaps xmm11, [rsp+0xA0]
000073baab9d9e64  vmovaps xmm12, [rsp+0xB0]
000073baab9d9e6d  vmovaps xmm13, [rsp+0xC0]
000073baab9d9e76  vmovaps xmm14, [rsp+0xD0]
000073baab9d9e7f  vmovaps xmm15, [rsp+0xE0]
000073baab9d9e88  add rsp, 0xF0
000073baab9d9e8f  pop r11
000073baab9d9e91  pop r10
000073baab9d9e93  pop r9
000073baab9d9e95  pop r8
000073baab9d9e97  pop rsi
000073baab9d9e98  pop rdi
000073baab9d9e99  pop rdx
000073baab9d9e9a  pop rcx
000073baab9d9e9b  pop rax
000073baab9d9e9c  add rsp, 0x08
000073baab9d9ea0  jmp 0x000073BAAB9D8BE6
000073baab9d9ea5  sub rsp, 0x08
000073baab9d9ea9  push rax
000073baab9d9eaa  push rcx
000073baab9d9eab  push rdx
000073baab9d9eac  push rdi
000073baab9d9ead  push rsi
000073baab9d9eae  push r8
000073baab9d9eb0  push r9
000073baab9d9eb2  push r10
000073baab9d9eb4  push r11
000073baab9d9eb6  sub rsp, 0xF0
000073baab9d9ebd  vmovaps [rsp], xmm0
000073baab9d9ec2  vmovaps [rsp+0x10], xmm1
000073baab9d9ec8  vmovaps [rsp+0x20], xmm2
000073baab9d9ece  vmovaps [rsp+0x30], xmm3
000073baab9d9ed4  vmovaps [rsp+0x40], xmm4
000073baab9d9eda  vmovaps [rsp+0x50], xmm5
000073baab9d9ee0  vmovaps [rsp+0x60], xmm7
000073baab9d9ee6  vmovaps [rsp+0x70], xmm8
000073baab9d9eec  vmovaps [rsp+0x80], xmm9
000073baab9d9ef5  vmovaps [rsp+0x90], xmm10
000073baab9d9efe  vmovaps [rsp+0xA0], xmm11
000073baab9d9f07  vmovaps [rsp+0xB0], xmm12
000073baab9d9f10  vmovaps [rsp+0xC0], xmm13
000073baab9d9f19  vmovaps [rsp+0xD0], xmm14
000073baab9d9f22  vmovaps [rsp+0xE0], xmm15
000073baab9d9f2b  sub rsp, 0x30
000073baab9d9f2f  movaps [rsp], xmm6
000073baab9d9f33  movaps [rsp+0x10], xmm12
000073baab9d9f39  movaps [rsp+0x20], xmm11
000073baab9d9f3f  lea rdi, [rsp]
000073baab9d9f43  mov esi, 0x00
000073baab9d9f48  mov rax, 0x5F3F1062D530
000073baab9d9f52  call rax
000073baab9d9f54  movaps xmm6, [rsp]
000073baab9d9f58  add rsp, 0x30
000073baab9d9f5c  vmovaps xmm0, [rsp]
000073baab9d9f61  vmovaps xmm1, [rsp+0x10]
000073baab9d9f67  vmovaps xmm2, [rsp+0x20]
000073baab9d9f6d  vmovaps xmm3, [rsp+0x30]
000073baab9d9f73  vmovaps xmm4, [rsp+0x40]
000073baab9d9f79  vmovaps xmm5, [rsp+0x50]
000073baab9d9f7f  vmovaps xmm7, [rsp+0x60]
000073baab9d9f85  vmovaps xmm8, [rsp+0x70]
000073baab9d9f8b  vmovaps xmm9, [rsp+0x80]
000073baab9d9f94  vmovaps xmm10, [rsp+0x90]
000073baab9d9f9d  vmovaps xmm11, [rsp+0xA0]
000073baab9d9fa6  vmovaps xmm12, [rsp+0xB0]
000073baab9d9faf  vmovaps xmm13, [rsp+0xC0]
000073baab9d9fb8  vmovaps xmm14, [rsp+0xD0]
000073baab9d9fc1  vmovaps xmm15, [rsp+0xE0]
000073baab9d9fca  add rsp, 0xF0
000073baab9d9fd1  pop r11
000073baab9d9fd3  pop r10
000073baab9d9fd5  pop r9
000073baab9d9fd7  pop r8
000073baab9d9fd9  pop rsi
000073baab9d9fda  pop rdi
000073baab9d9fdb  pop rdx
000073baab9d9fdc  pop rcx
000073baab9d9fdd  pop rax
000073baab9d9fde  add rsp, 0x08
000073baab9d9fe2  jmp 0x000073BAAB9D8C07
000073baab9d9fe7  sub rsp, 0x08
000073baab9d9feb  push rax
000073baab9d9fec  push rcx
000073baab9d9fed  push rdx
000073baab9d9fee  push rdi
000073baab9d9fef  push rsi
000073baab9d9ff0  push r8
000073baab9d9ff2  push r9
000073baab9d9ff4  push r10
000073baab9d9ff6  push r11
000073baab9d9ff8  sub rsp, 0xF0
000073baab9d9fff  vmovaps [rsp], xmm0
000073baab9da004  vmovaps [rsp+0x10], xmm1
000073baab9da00a  vmovaps [rsp+0x20], xmm2
000073baab9da010  vmovaps [rsp+0x30], xmm4
000073baab9da016  vmovaps [rsp+0x40], xmm5
000073baab9da01c  vmovaps [rsp+0x50], xmm6
000073baab9da022  vmovaps [rsp+0x60], xmm7
000073baab9da028  vmovaps [rsp+0x70], xmm8
000073baab9da02e  vmovaps [rsp+0x80], xmm9
000073baab9da037  vmovaps [rsp+0x90], xmm10
000073baab9da040  vmovaps [rsp+0xA0], xmm11
000073baab9da049  vmovaps [rsp+0xB0], xmm12
000073baab9da052  vmovaps [rsp+0xC0], xmm13
000073baab9da05b  vmovaps [rsp+0xD0], xmm14
000073baab9da064  vmovaps [rsp+0xE0], xmm15
000073baab9da06d  sub rsp, 0x30
000073baab9da071  movaps [rsp], xmm3
000073baab9da075  movaps [rsp+0x10], xmm5
000073baab9da07a  movaps [rsp+0x20], xmm4
000073baab9da07f  lea rdi, [rsp]
000073baab9da083  mov esi, 0x00
000073baab9da088  mov rax, 0x5F3F1062D530
000073baab9da092  call rax
000073baab9da094  movaps xmm3, [rsp]
000073baab9da098  add rsp, 0x30
000073baab9da09c  vmovaps xmm0, [rsp]
000073baab9da0a1  vmovaps xmm1, [rsp+0x10]
000073baab9da0a7  vmovaps xmm2, [rsp+0x20]
000073baab9da0ad  vmovaps xmm4, [rsp+0x30]
000073baab9da0b3  vmovaps xmm5, [rsp+0x40]
000073baab9da0b9  vmovaps xmm6, [rsp+0x50]
000073baab9da0bf  vmovaps xmm7, [rsp+0x60]
000073baab9da0c5  vmovaps xmm8, [rsp+0x70]
000073baab9da0cb  vmovaps xmm9, [rsp+0x80]
000073baab9da0d4  vmovaps xmm10, [rsp+0x90]
000073baab9da0dd  vmovaps xmm11, [rsp+0xA0]
000073baab9da0e6  vmovaps xmm12, [rsp+0xB0]
000073baab9da0ef  vmovaps xmm13, [rsp+0xC0]
000073baab9da0f8  vmovaps xmm14, [rsp+0xD0]
000073baab9da101  vmovaps xmm15, [rsp+0xE0]
000073baab9da10a  add rsp, 0xF0
000073baab9da111  pop r11
000073baab9da113  pop r10
000073baab9da115  pop r9
000073baab9da117  pop r8
000073baab9da119  pop rsi
000073baab9da11a  pop rdi
000073baab9da11b  pop rdx
000073baab9da11c  pop rcx
000073baab9da11d  pop rax
000073baab9da11e  add rsp, 0x08
000073baab9da122  jmp 0x000073BAAB9D8C68
000073baab9da127  sub rsp, 0x08
000073baab9da12b  push rax
000073baab9da12c  push rcx
000073baab9da12d  push rdx
000073baab9da12e  push rdi
000073baab9da12f  push rsi
000073baab9da130  push r8
000073baab9da132  push r9
000073baab9da134  push r10
000073baab9da136  push r11
000073baab9da138  sub rsp, 0xF0
000073baab9da13f  vmovaps [rsp], xmm0
000073baab9da144  vmovaps [rsp+0x10], xmm1
000073baab9da14a  vmovaps [rsp+0x20], xmm2
000073baab9da150  vmovaps [rsp+0x30], xmm3
000073baab9da156  vmovaps [rsp+0x40], xmm4
000073baab9da15c  vmovaps [rsp+0x50], xmm6
000073baab9da162  vmovaps [rsp+0x60], xmm7
000073baab9da168  vmovaps [rsp+0x70], xmm8
000073baab9da16e  vmovaps [rsp+0x80], xmm9
000073baab9da177  vmovaps [rsp+0x90], xmm10
000073baab9da180  vmovaps [rsp+0xA0], xmm11
000073baab9da189  vmovaps [rsp+0xB0], xmm12
000073baab9da192  vmovaps [rsp+0xC0], xmm13
000073baab9da19b  vmovaps [rsp+0xD0], xmm14
000073baab9da1a4  vmovaps [rsp+0xE0], xmm15
000073baab9da1ad  sub rsp, 0x30
000073baab9da1b1  movaps [rsp], xmm5
000073baab9da1b5  movaps [rsp+0x10], xmm8
000073baab9da1bb  movaps [rsp+0x20], xmm15
000073baab9da1c1  lea rdi, [rsp]
000073baab9da1c5  mov esi, 0x00
000073baab9da1ca  mov rax, 0x5F3F1062D530
000073baab9da1d4  call rax
000073baab9da1d6  movaps xmm5, [rsp]
000073baab9da1da  add rsp, 0x30
000073baab9da1de  vmovaps xmm0, [rsp]
000073baab9da1e3  vmovaps xmm1, [rsp+0x10]
000073baab9da1e9  vmovaps xmm2, [rsp+0x20]
000073baab9da1ef  vmovaps xmm3, [rsp+0x30]
000073baab9da1f5  vmovaps xmm4, [rsp+0x40]
000073baab9da1fb  vmovaps xmm6, [rsp+0x50]
000073baab9da201  vmovaps xmm7, [rsp+0x60]
000073baab9da207  vmovaps xmm8, [rsp+0x70]
000073baab9da20d  vmovaps xmm9, [rsp+0x80]
000073baab9da216  vmovaps xmm10, [rsp+0x90]
000073baab9da21f  vmovaps xmm11, [rsp+0xA0]
000073baab9da228  vmovaps xmm12, [rsp+0xB0]
000073baab9da231  vmovaps xmm13, [rsp+0xC0]
000073baab9da23a  vmovaps xmm14, [rsp+0xD0]
000073baab9da243  vmovaps xmm15, [rsp+0xE0]
000073baab9da24c  add rsp, 0xF0
000073baab9da253  pop r11
000073baab9da255  pop r10
000073baab9da257  pop r9
000073baab9da259  pop r8
000073baab9da25b  pop rsi
000073baab9da25c  pop rdi
000073baab9da25d  pop rdx
000073baab9da25e  pop rcx
000073baab9da25f  pop rax
000073baab9da260  add rsp, 0x08
000073baab9da264  jmp 0x000073BAAB9D8CA0
000073baab9da269  sub rsp, 0x08
000073baab9da26d  push rax
000073baab9da26e  push rcx
000073baab9da26f  push rdx
000073baab9da270  push rdi
000073baab9da271  push rsi
000073baab9da272  push r8
000073baab9da274  push r9
000073baab9da276  push r10
000073baab9da278  push r11
000073baab9da27a  sub rsp, 0xF0
000073baab9da281  vmovaps [rsp], xmm0
000073baab9da286  vmovaps [rsp+0x10], xmm1
000073baab9da28c  vmovaps [rsp+0x20], xmm2
000073baab9da292  vmovaps [rsp+0x30], xmm3
000073baab9da298  vmovaps [rsp+0x40], xmm5
000073baab9da29e  vmovaps [rsp+0x50], xmm6
000073baab9da2a4  vmovaps [rsp+0x60], xmm7
000073baab9da2aa  vmovaps [rsp+0x70], xmm8
000073baab9da2b0  vmovaps [rsp+0x80], xmm9
000073baab9da2b9  vmovaps [rsp+0x90], xmm10
000073baab9da2c2  vmovaps [rsp+0xA0], xmm11
000073baab9da2cb  vmovaps [rsp+0xB0], xmm12
000073baab9da2d4  vmovaps [rsp+0xC0], xmm13
000073baab9da2dd  vmovaps [rsp+0xD0], xmm14
000073baab9da2e6  vmovaps [rsp+0xE0], xmm15
000073baab9da2ef  sub rsp, 0x30
000073baab9da2f3  movaps [rsp], xmm4
000073baab9da2f7  movaps [rsp+0x10], xmm9
000073baab9da2fd  movaps [rsp+0x20], xmm8
000073baab9da303  lea rdi, [rsp]
000073baab9da307  mov esi, 0x00
000073baab9da30c  mov rax, 0x5F3F1062D530
000073baab9da316  call rax
000073baab9da318  movaps xmm4, [rsp]
000073baab9da31c  add rsp, 0x30
000073baab9da320  vmovaps xmm0, [rsp]
000073baab9da325  vmovaps xmm1, [rsp+0x10]
000073baab9da32b  vmovaps xmm2, [rsp+0x20]
000073baab9da331  vmovaps xmm3, [rsp+0x30]
000073baab9da337  vmovaps xmm5, [rsp+0x40]
000073baab9da33d  vmovaps xmm6, [rsp+0x50]
000073baab9da343  vmovaps xmm7, [rsp+0x60]
000073baab9da349  vmovaps xmm8, [rsp+0x70]
000073baab9da34f  vmovaps xmm9, [rsp+0x80]
000073baab9da358  vmovaps xmm10, [rsp+0x90]
000073baab9da361  vmovaps xmm11, [rsp+0xA0]
000073baab9da36a  vmovaps xmm12, [rsp+0xB0]
000073baab9da373  vmovaps xmm13, [rsp+0xC0]
000073baab9da37c  vmovaps xmm14, [rsp+0xD0]
000073baab9da385  vmovaps xmm15, [rsp+0xE0]
000073baab9da38e  add rsp, 0xF0
000073baab9da395  pop r11
000073baab9da397  pop r10
000073baab9da399  pop r9
000073baab9da39b  pop r8
000073baab9da39d  pop rsi
000073baab9da39e  pop rdi
000073baab9da39f  pop rdx
000073baab9da3a0  pop rcx
000073baab9da3a1  pop rax
000073baab9da3a2  add rsp, 0x08
000073baab9da3a6  jmp 0x000073BAAB9D8CC1
000073baab9da3ab  sub rsp, 0x08
000073baab9da3af  push rax
000073baab9da3b0  push rcx
000073baab9da3b1  push rdx
000073baab9da3b2  push rdi
000073baab9da3b3  push rsi
000073baab9da3b4  push r8
000073baab9da3b6  push r9
000073baab9da3b8  push r10
000073baab9da3ba  push r11
000073baab9da3bc  sub rsp, 0xF0
000073baab9da3c3  vmovaps [rsp], xmm0
000073baab9da3c8  vmovaps [rsp+0x10], xmm1
000073baab9da3ce  vmovaps [rsp+0x20], xmm2
000073baab9da3d4  vmovaps [rsp+0x30], xmm3
000073baab9da3da  vmovaps [rsp+0x40], xmm4
000073baab9da3e0  vmovaps [rsp+0x50], xmm5
000073baab9da3e6  vmovaps [rsp+0x60], xmm6
000073baab9da3ec  vmovaps [rsp+0x70], xmm7
000073baab9da3f2  vmovaps [rsp+0x80], xmm8
000073baab9da3fb  vmovaps [rsp+0x90], xmm10
000073baab9da404  vmovaps [rsp+0xA0], xmm11
000073baab9da40d  vmovaps [rsp+0xB0], xmm12
000073baab9da416  vmovaps [rsp+0xC0], xmm13
000073baab9da41f  vmovaps [rsp+0xD0], xmm14
000073baab9da428  vmovaps [rsp+0xE0], xmm15
000073baab9da431  sub rsp, 0x30
000073baab9da435  movaps [rsp], xmm9
000073baab9da43a  movaps [rsp+0x10], xmm10
000073baab9da440  movaps [rsp+0x20], xmm8
000073baab9da446  lea rdi, [rsp]
000073baab9da44a  mov esi, 0x00
000073baab9da44f  mov rax, 0x5F3F1062D530
000073baab9da459  call rax
000073baab9da45b  movaps xmm9, [rsp]
000073baab9da460  add rsp, 0x30
000073baab9da464  vmovaps xmm0, [rsp]
000073baab9da469  vmovaps xmm1, [rsp+0x10]
000073baab9da46f  vmovaps xmm2, [rsp+0x20]
000073baab9da475  vmovaps xmm3, [rsp+0x30]
000073baab9da47b  vmovaps xmm4, [rsp+0x40]
000073baab9da481  vmovaps xmm5, [rsp+0x50]
000073baab9da487  vmovaps xmm6, [rsp+0x60]
000073baab9da48d  vmovaps xmm7, [rsp+0x70]
000073baab9da493  vmovaps xmm8, [rsp+0x80]
000073baab9da49c  vmovaps xmm10, [rsp+0x90]
000073baab9da4a5  vmovaps xmm11, [rsp+0xA0]
000073baab9da4ae  vmovaps xmm12, [rsp+0xB0]
000073baab9da4b7  vmovaps xmm13, [rsp+0xC0]
000073baab9da4c0  vmovaps xmm14, [rsp+0xD0]
000073baab9da4c9  vmovaps xmm15, [rsp+0xE0]
000073baab9da4d2  add rsp, 0xF0
000073baab9da4d9  pop r11
000073baab9da4db  pop r10
000073baab9da4dd  pop r9
000073baab9da4df  pop r8
000073baab9da4e1  pop rsi
000073baab9da4e2  pop rdi
000073baab9da4e3  pop rdx
000073baab9da4e4  pop rcx
000073baab9da4e5  pop rax
000073baab9da4e6  add rsp, 0x08
000073baab9da4ea  jmp 0x000073BAAB9D8CDB
000073baab9da4ef  call 0x000073BAAB8D64F0
000073baab9da4f4  jmp 0x000073BAAB9D8DF5
000073baab9da4f9  call 0x000073BAAB8D64F0
000073baab9da4fe  jmp 0x000073BAAB9D8E0B
000073baab9da503  sub rsp, 0x08
000073baab9da507  push rax
000073baab9da508  push rcx
000073baab9da509  push rdx
000073baab9da50a  push rdi
000073baab9da50b  push rsi
000073baab9da50c  push r8
000073baab9da50e  push r9
000073baab9da510  push r10
000073baab9da512  push r11
000073baab9da514  sub rsp, 0xF0
000073baab9da51b  vmovaps [rsp], xmm0
000073baab9da520  vmovaps [rsp+0x10], xmm2
000073baab9da526  vmovaps [rsp+0x20], xmm3
000073baab9da52c  vmovaps [rsp+0x30], xmm4
000073baab9da532  vmovaps [rsp+0x40], xmm5
000073baab9da538  vmovaps [rsp+0x50], xmm6
000073baab9da53e  vmovaps [rsp+0x60], xmm7
000073baab9da544  vmovaps [rsp+0x70], xmm8
000073baab9da54a  vmovaps [rsp+0x80], xmm9
000073baab9da553  vmovaps [rsp+0x90], xmm10
000073baab9da55c  vmovaps [rsp+0xA0], xmm11
000073baab9da565  vmovaps [rsp+0xB0], xmm12
000073baab9da56e  vmovaps [rsp+0xC0], xmm13
000073baab9da577  vmovaps [rsp+0xD0], xmm14
000073baab9da580  vmovaps [rsp+0xE0], xmm15
000073baab9da589  sub rsp, 0x30
000073baab9da58d  movaps [rsp], xmm1
000073baab9da591  movaps [rsp+0x10], xmm6
000073baab9da596  movaps [rsp+0x20], xmm15
000073baab9da59c  lea rdi, [rsp]
000073baab9da5a0  mov esi, 0x00
000073baab9da5a5  mov rax, 0x5F3F1062D530
000073baab9da5af  call rax
000073baab9da5b1  movaps xmm1, [rsp]
000073baab9da5b5  add rsp, 0x30
000073baab9da5b9  vmovaps xmm0, [rsp]
000073baab9da5be  vmovaps xmm2, [rsp+0x10]
000073baab9da5c4  vmovaps xmm3, [rsp+0x20]
000073baab9da5ca  vmovaps xmm4, [rsp+0x30]
000073baab9da5d0  vmovaps xmm5, [rsp+0x40]
000073baab9da5d6  vmovaps xmm6, [rsp+0x50]
000073baab9da5dc  vmovaps xmm7, [rsp+0x60]
000073baab9da5e2  vmovaps xmm8, [rsp+0x70]
000073baab9da5e8  vmovaps xmm9, [rsp+0x80]
000073baab9da5f1  vmovaps xmm10, [rsp+0x90]
000073baab9da5fa  vmovaps xmm11, [rsp+0xA0]
000073baab9da603  vmovaps xmm12, [rsp+0xB0]
000073baab9da60c  vmovaps xmm13, [rsp+0xC0]
000073baab9da615  vmovaps xmm14, [rsp+0xD0]
000073baab9da61e  vmovaps xmm15, [rsp+0xE0]
000073baab9da627  add rsp, 0xF0
000073baab9da62e  pop r11
000073baab9da630  pop r10
000073baab9da632  pop r9
000073baab9da634  pop r8
000073baab9da636  pop rsi
000073baab9da637  pop rdi
000073baab9da638  pop rdx
000073baab9da639  pop rcx
000073baab9da63a  pop rax
000073baab9da63b  add rsp, 0x08
000073baab9da63f  jmp 0x000073BAAB9D8E48
000073baab9da644  call 0x000073BAAB8E5820
000073baab9da649  jmp 0x000073BAAB9D8E55
000073baab9da64e  sub rsp, 0x08
000073baab9da652  push rax
000073baab9da653  push rcx
000073baab9da654  push rdx
000073baab9da655  push rdi
000073baab9da656  push rsi
000073baab9da657  push r8
000073baab9da659  push r9
000073baab9da65b  push r10
000073baab9da65d  push r11
000073baab9da65f  sub rsp, 0xF0
000073baab9da666  vmovaps [rsp], xmm0
000073baab9da66b  vmovaps [rsp+0x10], xmm1
000073baab9da671  vmovaps [rsp+0x20], xmm2
000073baab9da677  vmovaps [rsp+0x30], xmm3
000073baab9da67d  vmovaps [rsp+0x40], xmm4
000073baab9da683  vmovaps [rsp+0x50], xmm5
000073baab9da689  vmovaps [rsp+0x60], xmm6
000073baab9da68f  vmovaps [rsp+0x70], xmm7
000073baab9da695  vmovaps [rsp+0x80], xmm8
000073baab9da69e  vmovaps [rsp+0x90], xmm9
000073baab9da6a7  vmovaps [rsp+0xA0], xmm10
000073baab9da6b0  vmovaps [rsp+0xB0], xmm11
000073baab9da6b9  vmovaps [rsp+0xC0], xmm12
000073baab9da6c2  vmovaps [rsp+0xD0], xmm13
000073baab9da6cb  vmovaps [rsp+0xE0], xmm15
000073baab9da6d4  sub rsp, 0x30
000073baab9da6d8  movaps [rsp], xmm14
000073baab9da6dd  movaps [rsp+0x10], xmm4
000073baab9da6e2  movaps [rsp+0x20], xmm3
000073baab9da6e7  lea rdi, [rsp]
000073baab9da6eb  mov esi, 0x00
000073baab9da6f0  mov rax, 0x5F3F1062D530
000073baab9da6fa  call rax
000073baab9da6fc  movaps xmm14, [rsp]
000073baab9da701  add rsp, 0x30
000073baab9da705  vmovaps xmm0, [rsp]
000073baab9da70a  vmovaps xmm1, [rsp+0x10]
000073baab9da710  vmovaps xmm2, [rsp+0x20]
000073baab9da716  vmovaps xmm3, [rsp+0x30]
000073baab9da71c  vmovaps xmm4, [rsp+0x40]
000073baab9da722  vmovaps xmm5, [rsp+0x50]
000073baab9da728  vmovaps xmm6, [rsp+0x60]
000073baab9da72e  vmovaps xmm7, [rsp+0x70]
000073baab9da734  vmovaps xmm8, [rsp+0x80]
000073baab9da73d  vmovaps xmm9, [rsp+0x90]
000073baab9da746  vmovaps xmm10, [rsp+0xA0]
000073baab9da74f  vmovaps xmm11, [rsp+0xB0]
000073baab9da758  vmovaps xmm12, [rsp+0xC0]
000073baab9da761  vmovaps xmm13, [rsp+0xD0]
000073baab9da76a  vmovaps xmm15, [rsp+0xE0]
000073baab9da773  add rsp, 0xF0
000073baab9da77a  pop r11
000073baab9da77c  pop r10
000073baab9da77e  pop r9
000073baab9da780  pop r8
000073baab9da782  pop rsi
000073baab9da783  pop rdi
000073baab9da784  pop rdx
000073baab9da785  pop rcx
000073baab9da786  pop rax
000073baab9da787  add rsp, 0x08
000073baab9da78b  jmp 0x000073BAAB9D8E6F
000073baab9da790  sub rsp, 0x08
000073baab9da794  push rax
000073baab9da795  push rcx
000073baab9da796  push rdx
000073baab9da797  push rdi
000073baab9da798  push rsi
000073baab9da799  push r8
000073baab9da79b  push r9
000073baab9da79d  push r10
000073baab9da79f  push r11
000073baab9da7a1  sub rsp, 0xF0
000073baab9da7a8  vmovaps [rsp], xmm0
000073baab9da7ad  vmovaps [rsp+0x10], xmm1
000073baab9da7b3  vmovaps [rsp+0x20], xmm2
000073baab9da7b9  vmovaps [rsp+0x30], xmm3
000073baab9da7bf  vmovaps [rsp+0x40], xmm4
000073baab9da7c5  vmovaps [rsp+0x50], xmm5
000073baab9da7cb  vmovaps [rsp+0x60], xmm7
000073baab9da7d1  vmovaps [rsp+0x70], xmm8
000073baab9da7d7  vmovaps [rsp+0x80], xmm9
000073baab9da7e0  vmovaps [rsp+0x90], xmm10
000073baab9da7e9  vmovaps [rsp+0xA0], xmm11
000073baab9da7f2  vmovaps [rsp+0xB0], xmm12
000073baab9da7fb  vmovaps [rsp+0xC0], xmm13
000073baab9da804  vmovaps [rsp+0xD0], xmm14
000073baab9da80d  vmovaps [rsp+0xE0], xmm15
000073baab9da816  sub rsp, 0x30
000073baab9da81a  movaps [rsp], xmm6
000073baab9da81e  movaps [rsp+0x10], xmm9
000073baab9da824  movaps [rsp+0x20], xmm7
000073baab9da829  lea rdi, [rsp]
000073baab9da82d  mov esi, 0x00
000073baab9da832  mov rax, 0x5F3F1062D530
000073baab9da83c  call rax
000073baab9da83e  movaps xmm6, [rsp]
000073baab9da842  add rsp, 0x30
000073baab9da846  vmovaps xmm0, [rsp]
000073baab9da84b  vmovaps xmm1, [rsp+0x10]
000073baab9da851  vmovaps xmm2, [rsp+0x20]
000073baab9da857  vmovaps xmm3, [rsp+0x30]
000073baab9da85d  vmovaps xmm4, [rsp+0x40]
000073baab9da863  vmovaps xmm5, [rsp+0x50]
000073baab9da869  vmovaps xmm7, [rsp+0x60]
000073baab9da86f  vmovaps xmm8, [rsp+0x70]
000073baab9da875  vmovaps xmm9, [rsp+0x80]
000073baab9da87e  vmovaps xmm10, [rsp+0x90]
000073baab9da887  vmovaps xmm11, [rsp+0xA0]
000073baab9da890  vmovaps xmm12, [rsp+0xB0]
000073baab9da899  vmovaps xmm13, [rsp+0xC0]
000073baab9da8a2  vmovaps xmm14, [rsp+0xD0]
000073baab9da8ab  vmovaps xmm15, [rsp+0xE0]
000073baab9da8b4  add rsp, 0xF0
000073baab9da8bb  pop r11
000073baab9da8bd  pop r10
000073baab9da8bf  pop r9
000073baab9da8c1  pop r8
000073baab9da8c3  pop rsi
000073baab9da8c4  pop rdi
000073baab9da8c5  pop rdx
000073baab9da8c6  pop rcx
000073baab9da8c7  pop rax
000073baab9da8c8  add rsp, 0x08
000073baab9da8cc  jmp 0x000073BAAB9D8E87
000073baab9da8d1  sub rsp, 0x08
000073baab9da8d5  push rax
000073baab9da8d6  push rcx
000073baab9da8d7  push rdx
000073baab9da8d8  push rdi
000073baab9da8d9  push rsi
000073baab9da8da  push r8
000073baab9da8dc  push r9
000073baab9da8de  push r10
000073baab9da8e0  push r11
000073baab9da8e2  sub rsp, 0xF0
000073baab9da8e9  vmovaps [rsp], xmm0
000073baab9da8ee  vmovaps [rsp+0x10], xmm1
000073baab9da8f4  vmovaps [rsp+0x20], xmm2
000073baab9da8fa  vmovaps [rsp+0x30], xmm3
000073baab9da900  vmovaps [rsp+0x40], xmm4
000073baab9da906  vmovaps [rsp+0x50], xmm5
000073baab9da90c  vmovaps [rsp+0x60], xmm6
000073baab9da912  vmovaps [rsp+0x70], xmm8
000073baab9da918  vmovaps [rsp+0x80], xmm9
000073baab9da921  vmovaps [rsp+0x90], xmm10
000073baab9da92a  vmovaps [rsp+0xA0], xmm11
000073baab9da933  vmovaps [rsp+0xB0], xmm12
000073baab9da93c  vmovaps [rsp+0xC0], xmm13
000073baab9da945  vmovaps [rsp+0xD0], xmm14
000073baab9da94e  vmovaps [rsp+0xE0], xmm15
000073baab9da957  sub rsp, 0x30
000073baab9da95b  movaps [rsp], xmm7
000073baab9da95f  movaps [rsp+0x10], xmm4
000073baab9da964  movaps [rsp+0x20], xmm9
000073baab9da96a  lea rdi, [rsp]
000073baab9da96e  mov esi, 0x00
000073baab9da973  mov rax, 0x5F3F1062D530
000073baab9da97d  call rax
000073baab9da97f  movaps xmm7, [rsp]
000073baab9da983  add rsp, 0x30
000073baab9da987  vmovaps xmm0, [rsp]
000073baab9da98c  vmovaps xmm1, [rsp+0x10]
000073baab9da992  vmovaps xmm2, [rsp+0x20]
000073baab9da998  vmovaps xmm3, [rsp+0x30]
000073baab9da99e  vmovaps xmm4, [rsp+0x40]
000073baab9da9a4  vmovaps xmm5, [rsp+0x50]
000073baab9da9aa  vmovaps xmm6, [rsp+0x60]
000073baab9da9b0  vmovaps xmm8, [rsp+0x70]
000073baab9da9b6  vmovaps xmm9, [rsp+0x80]
000073baab9da9bf  vmovaps xmm10, [rsp+0x90]
000073baab9da9c8  vmovaps xmm11, [rsp+0xA0]
000073baab9da9d1  vmovaps xmm12, [rsp+0xB0]
000073baab9da9da  vmovaps xmm13, [rsp+0xC0]
000073baab9da9e3  vmovaps xmm14, [rsp+0xD0]
000073baab9da9ec  vmovaps xmm15, [rsp+0xE0]
000073baab9da9f5  add rsp, 0xF0
000073baab9da9fc  pop r11
000073baab9da9fe  pop r10
000073baab9daa00  pop r9
000073baab9daa02  pop r8
000073baab9daa04  pop rsi
000073baab9daa05  pop rdi
000073baab9daa06  pop rdx
000073baab9daa07  pop rcx
000073baab9daa08  pop rax
000073baab9daa09  add rsp, 0x08
000073baab9daa0d  jmp 0x000073BAAB9D8EB4
000073baab9daa12  sub rsp, 0x08
000073baab9daa16  push rax
000073baab9daa17  push rcx
000073baab9daa18  push rdx
000073baab9daa19  push rdi
000073baab9daa1a  push rsi
000073baab9daa1b  push r8
000073baab9daa1d  push r9
000073baab9daa1f  push r10
000073baab9daa21  push r11
000073baab9daa23  sub rsp, 0xF0
000073baab9daa2a  vmovaps [rsp], xmm0
000073baab9daa2f  vmovaps [rsp+0x10], xmm1
000073baab9daa35  vmovaps [rsp+0x20], xmm2
000073baab9daa3b  vmovaps [rsp+0x30], xmm3
000073baab9daa41  vmovaps [rsp+0x40], xmm5
000073baab9daa47  vmovaps [rsp+0x50], xmm6
000073baab9daa4d  vmovaps [rsp+0x60], xmm7
000073baab9daa53  vmovaps [rsp+0x70], xmm8
000073baab9daa59  vmovaps [rsp+0x80], xmm9
000073baab9daa62  vmovaps [rsp+0x90], xmm10
000073baab9daa6b  vmovaps [rsp+0xA0], xmm11
000073baab9daa74  vmovaps [rsp+0xB0], xmm12
000073baab9daa7d  vmovaps [rsp+0xC0], xmm13
000073baab9daa86  vmovaps [rsp+0xD0], xmm14
000073baab9daa8f  vmovaps [rsp+0xE0], xmm15
000073baab9daa98  sub rsp, 0x30
000073baab9daa9c  movaps [rsp], xmm4
000073baab9daaa0  movaps [rsp+0x10], xmm15
000073baab9daaa6  movaps [rsp+0x20], xmm9
000073baab9daaac  lea rdi, [rsp]
000073baab9daab0  mov esi, 0x00
000073baab9daab5  mov rax, 0x5F3F1062D530
000073baab9daabf  call rax
000073baab9daac1  movaps xmm4, [rsp]
000073baab9daac5  add rsp, 0x30
000073baab9daac9  vmovaps xmm0, [rsp]
000073baab9daace  vmovaps xmm1, [rsp+0x10]
000073baab9daad4  vmovaps xmm2, [rsp+0x20]
000073baab9daada  vmovaps xmm3, [rsp+0x30]
000073baab9daae0  vmovaps xmm5, [rsp+0x40]
000073baab9daae6  vmovaps xmm6, [rsp+0x50]
000073baab9daaec  vmovaps xmm7, [rsp+0x60]
000073baab9daaf2  vmovaps xmm8, [rsp+0x70]
000073baab9daaf8  vmovaps xmm9, [rsp+0x80]
000073baab9dab01  vmovaps xmm10, [rsp+0x90]
000073baab9dab0a  vmovaps xmm11, [rsp+0xA0]
000073baab9dab13  vmovaps xmm12, [rsp+0xB0]
000073baab9dab1c  vmovaps xmm13, [rsp+0xC0]
000073baab9dab25  vmovaps xmm14, [rsp+0xD0]
000073baab9dab2e  vmovaps xmm15, [rsp+0xE0]
000073baab9dab37  add rsp, 0xF0
000073baab9dab3e  pop r11
000073baab9dab40  pop r10
000073baab9dab42  pop r9
000073baab9dab44  pop r8
000073baab9dab46  pop rsi
000073baab9dab47  pop rdi
000073baab9dab48  pop rdx
000073baab9dab49  pop rcx
000073baab9dab4a  pop rax
000073baab9dab4b  add rsp, 0x08
000073baab9dab4f  jmp 0x000073BAAB9D8ED9
000073baab9dab54  call 0x000073BAAB8E5820
000073baab9dab59  jmp 0x000073BAAB9D8EE6
000073baab9dab5e  sub rsp, 0x08
000073baab9dab62  push rax
000073baab9dab63  push rcx
000073baab9dab64  push rdx
000073baab9dab65  push rdi
000073baab9dab66  push rsi
000073baab9dab67  push r8
000073baab9dab69  push r9
000073baab9dab6b  push r10
000073baab9dab6d  push r11
000073baab9dab6f  sub rsp, 0xF0
000073baab9dab76  vmovaps [rsp], xmm0
000073baab9dab7b  vmovaps [rsp+0x10], xmm1
000073baab9dab81  vmovaps [rsp+0x20], xmm2
000073baab9dab87  vmovaps [rsp+0x30], xmm4
000073baab9dab8d  vmovaps [rsp+0x40], xmm5
000073baab9dab93  vmovaps [rsp+0x50], xmm6
000073baab9dab99  vmovaps [rsp+0x60], xmm7
000073baab9dab9f  vmovaps [rsp+0x70], xmm8
000073baab9daba5  vmovaps [rsp+0x80], xmm9
000073baab9dabae  vmovaps [rsp+0x90], xmm10
000073baab9dabb7  vmovaps [rsp+0xA0], xmm11
000073baab9dabc0  vmovaps [rsp+0xB0], xmm12
000073baab9dabc9  vmovaps [rsp+0xC0], xmm13
000073baab9dabd2  vmovaps [rsp+0xD0], xmm14
000073baab9dabdb  vmovaps [rsp+0xE0], xmm15
000073baab9dabe4  sub rsp, 0x30
000073baab9dabe8  movaps [rsp], xmm3
000073baab9dabec  movaps [rsp+0x10], xmm1
000073baab9dabf1  movaps [rsp+0x20], xmm9
000073baab9dabf7  lea rdi, [rsp]
000073baab9dabfb  mov esi, 0x00
000073baab9dac00  mov rax, 0x5F3F1062D530
000073baab9dac0a  call rax
000073baab9dac0c  movaps xmm3, [rsp]
000073baab9dac10  add rsp, 0x30
000073baab9dac14  vmovaps xmm0, [rsp]
000073baab9dac19  vmovaps xmm1, [rsp+0x10]
000073baab9dac1f  vmovaps xmm2, [rsp+0x20]
000073baab9dac25  vmovaps xmm4, [rsp+0x30]
000073baab9dac2b  vmovaps xmm5, [rsp+0x40]
000073baab9dac31  vmovaps xmm6, [rsp+0x50]
000073baab9dac37  vmovaps xmm7, [rsp+0x60]
000073baab9dac3d  vmovaps xmm8, [rsp+0x70]
000073baab9dac43  vmovaps xmm9, [rsp+0x80]
000073baab9dac4c  vmovaps xmm10, [rsp+0x90]
000073baab9dac55  vmovaps xmm11, [rsp+0xA0]
000073baab9dac5e  vmovaps xmm12, [rsp+0xB0]
000073baab9dac67  vmovaps xmm13, [rsp+0xC0]
000073baab9dac70  vmovaps xmm14, [rsp+0xD0]
000073baab9dac79  vmovaps xmm15, [rsp+0xE0]
000073baab9dac82  add rsp, 0xF0
000073baab9dac89  pop r11
000073baab9dac8b  pop r10
000073baab9dac8d  pop r9
000073baab9dac8f  pop r8
000073baab9dac91  pop rsi
000073baab9dac92  pop rdi
000073baab9dac93  pop rdx
000073baab9dac94  pop rcx
000073baab9dac95  pop rax
000073baab9dac96  add rsp, 0x08
000073baab9dac9a  jmp 0x000073BAAB9D8F23
000073baab9dac9f  sub rsp, 0x08
000073baab9daca3  push rax
000073baab9daca4  push rcx
000073baab9daca5  push rdx
000073baab9daca6  push rdi
000073baab9daca7  push rsi
000073baab9daca8  push r8
000073baab9dacaa  push r9
000073baab9dacac  push r10
000073baab9dacae  push r11
000073baab9dacb0  sub rsp, 0xF0
000073baab9dacb7  vmovaps [rsp], xmm0
000073baab9dacbc  vmovaps [rsp+0x10], xmm2
000073baab9dacc2  vmovaps [rsp+0x20], xmm3
000073baab9dacc8  vmovaps [rsp+0x30], xmm4
000073baab9dacce  vmovaps [rsp+0x40], xmm5
000073baab9dacd4  vmovaps [rsp+0x50], xmm6
000073baab9dacda  vmovaps [rsp+0x60], xmm7
000073baab9dace0  vmovaps [rsp+0x70], xmm8
000073baab9dace6  vmovaps [rsp+0x80], xmm9
000073baab9dacef  vmovaps [rsp+0x90], xmm10
000073baab9dacf8  vmovaps [rsp+0xA0], xmm11
000073baab9dad01  vmovaps [rsp+0xB0], xmm12
000073baab9dad0a  vmovaps [rsp+0xC0], xmm13
000073baab9dad13  vmovaps [rsp+0xD0], xmm14
000073baab9dad1c  vmovaps [rsp+0xE0], xmm15
000073baab9dad25  sub rsp, 0x30
000073baab9dad29  movaps [rsp], xmm1
000073baab9dad2d  movaps [rsp+0x10], xmm15
000073baab9dad33  movaps [rsp+0x20], xmm9
000073baab9dad39  lea rdi, [rsp]
000073baab9dad3d  mov esi, 0x00
000073baab9dad42  mov rax, 0x5F3F1062D530
000073baab9dad4c  call rax
000073baab9dad4e  movaps xmm1, [rsp]
000073baab9dad52  add rsp, 0x30
000073baab9dad56  vmovaps xmm0, [rsp]
000073baab9dad5b  vmovaps xmm2, [rsp+0x10]
000073baab9dad61  vmovaps xmm3, [rsp+0x20]
000073baab9dad67  vmovaps xmm4, [rsp+0x30]
000073baab9dad6d  vmovaps xmm5, [rsp+0x40]
000073baab9dad73  vmovaps xmm6, [rsp+0x50]
000073baab9dad79  vmovaps xmm7, [rsp+0x60]
000073baab9dad7f  vmovaps xmm8, [rsp+0x70]
000073baab9dad85  vmovaps xmm9, [rsp+0x80]
000073baab9dad8e  vmovaps xmm10, [rsp+0x90]
000073baab9dad97  vmovaps xmm11, [rsp+0xA0]
000073baab9dada0  vmovaps xmm12, [rsp+0xB0]
000073baab9dada9  vmovaps xmm13, [rsp+0xC0]
000073baab9dadb2  vmovaps xmm14, [rsp+0xD0]
000073baab9dadbb  vmovaps xmm15, [rsp+0xE0]
000073baab9dadc4  add rsp, 0xF0
000073baab9dadcb  pop r11
000073baab9dadcd  pop r10
000073baab9dadcf  pop r9
000073baab9dadd1  pop r8
000073baab9dadd3  pop rsi
000073baab9dadd4  pop rdi
000073baab9dadd5  pop rdx
000073baab9dadd6  pop rcx
000073baab9dadd7  pop rax
000073baab9dadd8  add rsp, 0x08
000073baab9daddc  jmp 0x000073BAAB9D8FAB
000073baab9dade1  call 0x000073BAAB8E5820
000073baab9dade6  jmp 0x000073BAAB9D8FB8
000073baab9dadeb  sub rsp, 0x08
000073baab9dadef  push rax
000073baab9dadf0  push rcx
000073baab9dadf1  push rdx
000073baab9dadf2  push rdi
000073baab9dadf3  push rsi
000073baab9dadf4  push r8
000073baab9dadf6  push r9
000073baab9dadf8  push r10
000073baab9dadfa  push r11
000073baab9dadfc  sub rsp, 0xF0
000073baab9dae03  vmovaps [rsp], xmm0
000073baab9dae08  vmovaps [rsp+0x10], xmm2
000073baab9dae0e  vmovaps [rsp+0x20], xmm3
000073baab9dae14  vmovaps [rsp+0x30], xmm4
000073baab9dae1a  vmovaps [rsp+0x40], xmm5
000073baab9dae20  vmovaps [rsp+0x50], xmm6
000073baab9dae26  vmovaps [rsp+0x60], xmm7
000073baab9dae2c  vmovaps [rsp+0x70], xmm8
000073baab9dae32  vmovaps [rsp+0x80], xmm9
000073baab9dae3b  vmovaps [rsp+0x90], xmm10
000073baab9dae44  vmovaps [rsp+0xA0], xmm11
000073baab9dae4d  vmovaps [rsp+0xB0], xmm12
000073baab9dae56  vmovaps [rsp+0xC0], xmm13
000073baab9dae5f  vmovaps [rsp+0xD0], xmm14
000073baab9dae68  vmovaps [rsp+0xE0], xmm15
000073baab9dae71  sub rsp, 0x30
000073baab9dae75  movaps [rsp], xmm1
000073baab9dae79  movaps [rsp+0x10], xmm5
000073baab9dae7e  movaps [rsp+0x20], xmm7
000073baab9dae83  lea rdi, [rsp]
000073baab9dae87  mov esi, 0x00
000073baab9dae8c  mov rax, 0x5F3F1062D530
000073baab9dae96  call rax
000073baab9dae98  movaps xmm1, [rsp]
000073baab9dae9c  add rsp, 0x30
000073baab9daea0  vmovaps xmm0, [rsp]
000073baab9daea5  vmovaps xmm2, [rsp+0x10]
000073baab9daeab  vmovaps xmm3, [rsp+0x20]
000073baab9daeb1  vmovaps xmm4, [rsp+0x30]
000073baab9daeb7  vmovaps xmm5, [rsp+0x40]
000073baab9daebd  vmovaps xmm6, [rsp+0x50]
000073baab9daec3  vmovaps xmm7, [rsp+0x60]
000073baab9daec9  vmovaps xmm8, [rsp+0x70]
000073baab9daecf  vmovaps xmm9, [rsp+0x80]
000073baab9daed8  vmovaps xmm10, [rsp+0x90]
000073baab9daee1  vmovaps xmm11, [rsp+0xA0]
000073baab9daeea  vmovaps xmm12, [rsp+0xB0]
000073baab9daef3  vmovaps xmm13, [rsp+0xC0]
000073baab9daefc  vmovaps xmm14, [rsp+0xD0]
000073baab9daf05  vmovaps xmm15, [rsp+0xE0]
000073baab9daf0e  add rsp, 0xF0
000073baab9daf15  pop r11
000073baab9daf17  pop r10
000073baab9daf19  pop r9
000073baab9daf1b  pop r8
000073baab9daf1d  pop rsi
000073baab9daf1e  pop rdi
000073baab9daf1f  pop rdx
000073baab9daf20  pop rcx
000073baab9daf21  pop rax
000073baab9daf22  add rsp, 0x08
000073baab9daf26  jmp 0x000073BAAB9D905D
000073baab9daf2b  sub rsp, 0x08
000073baab9daf2f  push rax
000073baab9daf30  push rcx
000073baab9daf31  push rdx
000073baab9daf32  push rdi
000073baab9daf33  push rsi
000073baab9daf34  push r8
000073baab9daf36  push r9
000073baab9daf38  push r10
000073baab9daf3a  push r11
000073baab9daf3c  sub rsp, 0xF0
000073baab9daf43  vmovaps [rsp], xmm0
000073baab9daf48  vmovaps [rsp+0x10], xmm1
000073baab9daf4e  vmovaps [rsp+0x20], xmm2
000073baab9daf54  vmovaps [rsp+0x30], xmm3
000073baab9daf5a  vmovaps [rsp+0x40], xmm4
000073baab9daf60  vmovaps [rsp+0x50], xmm5
000073baab9daf66  vmovaps [rsp+0x60], xmm6
000073baab9daf6c  vmovaps [rsp+0x70], xmm8
000073baab9daf72  vmovaps [rsp+0x80], xmm9
000073baab9daf7b  vmovaps [rsp+0x90], xmm10
000073baab9daf84  vmovaps [rsp+0xA0], xmm11
000073baab9daf8d  vmovaps [rsp+0xB0], xmm12
000073baab9daf96  vmovaps [rsp+0xC0], xmm13
000073baab9daf9f  vmovaps [rsp+0xD0], xmm14
000073baab9dafa8  vmovaps [rsp+0xE0], xmm15
000073baab9dafb1  sub rsp, 0x30
000073baab9dafb5  movaps [rsp], xmm7
000073baab9dafb9  movaps [rsp+0x10], xmm5
000073baab9dafbe  movaps [rsp+0x20], xmm15
000073baab9dafc4  lea rdi, [rsp]
000073baab9dafc8  mov esi, 0x00
000073baab9dafcd  mov rax, 0x5F3F1062D530
000073baab9dafd7  call rax
000073baab9dafd9  movaps xmm7, [rsp]
000073baab9dafdd  add rsp, 0x30
000073baab9dafe1  vmovaps xmm0, [rsp]
000073baab9dafe6  vmovaps xmm1, [rsp+0x10]
000073baab9dafec  vmovaps xmm2, [rsp+0x20]
000073baab9daff2  vmovaps xmm3, [rsp+0x30]
000073baab9daff8  vmovaps xmm4, [rsp+0x40]
000073baab9daffe  vmovaps xmm5, [rsp+0x50]
000073baab9db004  vmovaps xmm6, [rsp+0x60]
000073baab9db00a  vmovaps xmm8, [rsp+0x70]
000073baab9db010  vmovaps xmm9, [rsp+0x80]
000073baab9db019  vmovaps xmm10, [rsp+0x90]
000073baab9db022  vmovaps xmm11, [rsp+0xA0]
000073baab9db02b  vmovaps xmm12, [rsp+0xB0]
000073baab9db034  vmovaps xmm13, [rsp+0xC0]
000073baab9db03d  vmovaps xmm14, [rsp+0xD0]
000073baab9db046  vmovaps xmm15, [rsp+0xE0]
000073baab9db04f  add rsp, 0xF0
000073baab9db056  pop r11
000073baab9db058  pop r10
000073baab9db05a  pop r9
000073baab9db05c  pop r8
000073baab9db05e  pop rsi
000073baab9db05f  pop rdi
000073baab9db060  pop rdx
000073baab9db061  pop rcx
000073baab9db062  pop rax
000073baab9db063  add rsp, 0x08
000073baab9db067  jmp 0x000073BAAB9D9093
000073baab9db06c  call 0x000073BAAB8D64F0
000073baab9db071  jmp 0x000073BAAB9D90A0
000073baab9db076  sub rsp, 0x08
000073baab9db07a  push rax
000073baab9db07b  push rcx
000073baab9db07c  push rdx
000073baab9db07d  push rdi
000073baab9db07e  push rsi
000073baab9db07f  push r8
000073baab9db081  push r9
000073baab9db083  push r10
000073baab9db085  push r11
000073baab9db087  sub rsp, 0xF0
000073baab9db08e  vmovaps [rsp], xmm0
000073baab9db093  vmovaps [rsp+0x10], xmm1
000073baab9db099  vmovaps [rsp+0x20], xmm2
000073baab9db09f  vmovaps [rsp+0x30], xmm3
000073baab9db0a5  vmovaps [rsp+0x40], xmm4
000073baab9db0ab  vmovaps [rsp+0x50], xmm5
000073baab9db0b1  vmovaps [rsp+0x60], xmm6
000073baab9db0b7  vmovaps [rsp+0x70], xmm7
000073baab9db0bd  vmovaps [rsp+0x80], xmm8
000073baab9db0c6  vmovaps [rsp+0x90], xmm9
000073baab9db0cf  vmovaps [rsp+0xA0], xmm10
000073baab9db0d8  vmovaps [rsp+0xB0], xmm11
000073baab9db0e1  vmovaps [rsp+0xC0], xmm12
000073baab9db0ea  vmovaps [rsp+0xD0], xmm13
000073baab9db0f3  vmovaps [rsp+0xE0], xmm14
000073baab9db0fc  sub rsp, 0x30
000073baab9db100  movaps [rsp], xmm15
000073baab9db105  movaps [rsp+0x10], xmm5
000073baab9db10a  movaps [rsp+0x20], xmm3
000073baab9db10f  lea rdi, [rsp]
000073baab9db113  mov esi, 0x00
000073baab9db118  mov rax, 0x5F3F1062D530
000073baab9db122  call rax
000073baab9db124  movaps xmm15, [rsp]
000073baab9db129  add rsp, 0x30
000073baab9db12d  vmovaps xmm0, [rsp]
000073baab9db132  vmovaps xmm1, [rsp+0x10]
000073baab9db138  vmovaps xmm2, [rsp+0x20]
000073baab9db13e  vmovaps xmm3, [rsp+0x30]
000073baab9db144  vmovaps xmm4, [rsp+0x40]
000073baab9db14a  vmovaps xmm5, [rsp+0x50]
000073baab9db150  vmovaps xmm6, [rsp+0x60]
000073baab9db156  vmovaps xmm7, [rsp+0x70]
000073baab9db15c  vmovaps xmm8, [rsp+0x80]
000073baab9db165  vmovaps xmm9, [rsp+0x90]
000073baab9db16e  vmovaps xmm10, [rsp+0xA0]
000073baab9db177  vmovaps xmm11, [rsp+0xB0]
000073baab9db180  vmovaps xmm12, [rsp+0xC0]
000073baab9db189  vmovaps xmm13, [rsp+0xD0]
000073baab9db192  vmovaps xmm14, [rsp+0xE0]
000073baab9db19b  add rsp, 0xF0
000073baab9db1a2  pop r11
000073baab9db1a4  pop r10
000073baab9db1a6  pop r9
000073baab9db1a8  pop r8
000073baab9db1aa  pop rsi
000073baab9db1ab  pop rdi
000073baab9db1ac  pop rdx
000073baab9db1ad  pop rcx
000073baab9db1ae  pop rax
000073baab9db1af  add rsp, 0x08
000073baab9db1b3  jmp 0x000073BAAB9D90C6
000073baab9db1b8  sub rsp, 0x08
000073baab9db1bc  push rax
000073baab9db1bd  push rcx
000073baab9db1be  push rdx
000073baab9db1bf  push rdi
000073baab9db1c0  push rsi
000073baab9db1c1  push r8
000073baab9db1c3  push r9
000073baab9db1c5  push r10
000073baab9db1c7  push r11
000073baab9db1c9  sub rsp, 0xF0
000073baab9db1d0  vmovaps [rsp], xmm0
000073baab9db1d5  vmovaps [rsp+0x10], xmm2
000073baab9db1db  vmovaps [rsp+0x20], xmm3
000073baab9db1e1  vmovaps [rsp+0x30], xmm4
000073baab9db1e7  vmovaps [rsp+0x40], xmm5
000073baab9db1ed  vmovaps [rsp+0x50], xmm6
000073baab9db1f3  vmovaps [rsp+0x60], xmm7
000073baab9db1f9  vmovaps [rsp+0x70], xmm8
000073baab9db1ff  vmovaps [rsp+0x80], xmm9
000073baab9db208  vmovaps [rsp+0x90], xmm10
000073baab9db211  vmovaps [rsp+0xA0], xmm11
000073baab9db21a  vmovaps [rsp+0xB0], xmm12
000073baab9db223  vmovaps [rsp+0xC0], xmm13
000073baab9db22c  vmovaps [rsp+0xD0], xmm14
000073baab9db235  vmovaps [rsp+0xE0], xmm15
000073baab9db23e  sub rsp, 0x30
000073baab9db242  movaps [rsp], xmm1
000073baab9db246  movaps [rsp+0x10], xmm5
000073baab9db24b  movaps [rsp+0x20], xmm4
000073baab9db250  lea rdi, [rsp]
000073baab9db254  mov esi, 0x00
000073baab9db259  mov rax, 0x5F3F1062D530
000073baab9db263  call rax
000073baab9db265  movaps xmm1, [rsp]
000073baab9db269  add rsp, 0x30
000073baab9db26d  vmovaps xmm0, [rsp]
000073baab9db272  vmovaps xmm2, [rsp+0x10]
000073baab9db278  vmovaps xmm3, [rsp+0x20]
000073baab9db27e  vmovaps xmm4, [rsp+0x30]
000073baab9db284  vmovaps xmm5, [rsp+0x40]
000073baab9db28a  vmovaps xmm6, [rsp+0x50]
000073baab9db290  vmovaps xmm7, [rsp+0x60]
000073baab9db296  vmovaps xmm8, [rsp+0x70]
000073baab9db29c  vmovaps xmm9, [rsp+0x80]
000073baab9db2a5  vmovaps xmm10, [rsp+0x90]
000073baab9db2ae  vmovaps xmm11, [rsp+0xA0]
000073baab9db2b7  vmovaps xmm12, [rsp+0xB0]
000073baab9db2c0  vmovaps xmm13, [rsp+0xC0]
000073baab9db2c9  vmovaps xmm14, [rsp+0xD0]
000073baab9db2d2  vmovaps xmm15, [rsp+0xE0]
000073baab9db2db  add rsp, 0xF0
000073baab9db2e2  pop r11
000073baab9db2e4  pop r10
000073baab9db2e6  pop r9
000073baab9db2e8  pop r8
000073baab9db2ea  pop rsi
000073baab9db2eb  pop rdi
000073baab9db2ec  pop rdx
000073baab9db2ed  pop rcx
000073baab9db2ee  pop rax
000073baab9db2ef  add rsp, 0x08
000073baab9db2f3  jmp 0x000073BAAB9D90E6
000073baab9db2f8  sub rsp, 0x08
000073baab9db2fc  push rax
000073baab9db2fd  push rcx
000073baab9db2fe  push rdx
000073baab9db2ff  push rdi
000073baab9db300  push rsi
000073baab9db301  push r8
000073baab9db303  push r9
000073baab9db305  push r10
000073baab9db307  push r11
000073baab9db309  sub rsp, 0xF0
000073baab9db310  vmovaps [rsp], xmm0
000073baab9db315  vmovaps [rsp+0x10], xmm1
000073baab9db31b  vmovaps [rsp+0x20], xmm2
000073baab9db321  vmovaps [rsp+0x30], xmm3
000073baab9db327  vmovaps [rsp+0x40], xmm5
000073baab9db32d  vmovaps [rsp+0x50], xmm6
000073baab9db333  vmovaps [rsp+0x60], xmm7
000073baab9db339  vmovaps [rsp+0x70], xmm8
000073baab9db33f  vmovaps [rsp+0x80], xmm9
000073baab9db348  vmovaps [rsp+0x90], xmm10
000073baab9db351  vmovaps [rsp+0xA0], xmm11
000073baab9db35a  vmovaps [rsp+0xB0], xmm12
000073baab9db363  vmovaps [rsp+0xC0], xmm13
000073baab9db36c  vmovaps [rsp+0xD0], xmm14
000073baab9db375  vmovaps [rsp+0xE0], xmm15
000073baab9db37e  sub rsp, 0x30
000073baab9db382  movaps [rsp], xmm4
000073baab9db386  movaps [rsp+0x10], xmm3
000073baab9db38b  movaps [rsp+0x20], xmm5
000073baab9db390  lea rdi, [rsp]
000073baab9db394  mov esi, 0x00
000073baab9db399  mov rax, 0x5F3F1062D530
000073baab9db3a3  call rax
000073baab9db3a5  movaps xmm4, [rsp]
000073baab9db3a9  add rsp, 0x30
000073baab9db3ad  vmovaps xmm0, [rsp]
000073baab9db3b2  vmovaps xmm1, [rsp+0x10]
000073baab9db3b8  vmovaps xmm2, [rsp+0x20]
000073baab9db3be  vmovaps xmm3, [rsp+0x30]
000073baab9db3c4  vmovaps xmm5, [rsp+0x40]
000073baab9db3ca  vmovaps xmm6, [rsp+0x50]
000073baab9db3d0  vmovaps xmm7, [rsp+0x60]
000073baab9db3d6  vmovaps xmm8, [rsp+0x70]
000073baab9db3dc  vmovaps xmm9, [rsp+0x80]
000073baab9db3e5  vmovaps xmm10, [rsp+0x90]
000073baab9db3ee  vmovaps xmm11, [rsp+0xA0]
000073baab9db3f7  vmovaps xmm12, [rsp+0xB0]
000073baab9db400  vmovaps xmm13, [rsp+0xC0]
000073baab9db409  vmovaps xmm14, [rsp+0xD0]
000073baab9db412  vmovaps xmm15, [rsp+0xE0]
000073baab9db41b  add rsp, 0xF0
000073baab9db422  pop r11
000073baab9db424  pop r10
000073baab9db426  pop r9
000073baab9db428  pop r8
000073baab9db42a  pop rsi
000073baab9db42b  pop rdi
000073baab9db42c  pop rdx
000073baab9db42d  pop rcx
000073baab9db42e  pop rax
000073baab9db42f  add rsp, 0x08
000073baab9db433  jmp 0x000073BAAB9D9134
000073baab9db438  call 0x000073BAAB8D64F0
000073baab9db43d  jmp 0x000073BAAB9D9141
000073baab9db442  sub rsp, 0x08
000073baab9db446  push rax
000073baab9db447  push rcx
000073baab9db448  push rdx
000073baab9db449  push rdi
000073baab9db44a  push rsi
000073baab9db44b  push r8
000073baab9db44d  push r9
000073baab9db44f  push r10
000073baab9db451  push r11
000073baab9db453  sub rsp, 0xF0
000073baab9db45a  vmovaps [rsp], xmm0
000073baab9db45f  vmovaps [rsp+0x10], xmm1
000073baab9db465  vmovaps [rsp+0x20], xmm2
000073baab9db46b  vmovaps [rsp+0x30], xmm3
000073baab9db471  vmovaps [rsp+0x40], xmm4
000073baab9db477  vmovaps [rsp+0x50], xmm6
000073baab9db47d  vmovaps [rsp+0x60], xmm7
000073baab9db483  vmovaps [rsp+0x70], xmm8
000073baab9db489  vmovaps [rsp+0x80], xmm9
000073baab9db492  vmovaps [rsp+0x90], xmm10
000073baab9db49b  vmovaps [rsp+0xA0], xmm11
000073baab9db4a4  vmovaps [rsp+0xB0], xmm12
000073baab9db4ad  vmovaps [rsp+0xC0], xmm13
000073baab9db4b6  vmovaps [rsp+0xD0], xmm14
000073baab9db4bf  vmovaps [rsp+0xE0], xmm15
000073baab9db4c8  sub rsp, 0x30
000073baab9db4cc  movaps [rsp], xmm5
000073baab9db4d0  movaps [rsp+0x10], xmm6
000073baab9db4d5  movaps [rsp+0x20], xmm3
000073baab9db4da  lea rdi, [rsp]
000073baab9db4de  mov esi, 0x00
000073baab9db4e3  mov rax, 0x5F3F1062D530
000073baab9db4ed  call rax
000073baab9db4ef  movaps xmm5, [rsp]
000073baab9db4f3  add rsp, 0x30
000073baab9db4f7  vmovaps xmm0, [rsp]
000073baab9db4fc  vmovaps xmm1, [rsp+0x10]
000073baab9db502  vmovaps xmm2, [rsp+0x20]
000073baab9db508  vmovaps xmm3, [rsp+0x30]
000073baab9db50e  vmovaps xmm4, [rsp+0x40]
000073baab9db514  vmovaps xmm6, [rsp+0x50]
000073baab9db51a  vmovaps xmm7, [rsp+0x60]
000073baab9db520  vmovaps xmm8, [rsp+0x70]
000073baab9db526  vmovaps xmm9, [rsp+0x80]
000073baab9db52f  vmovaps xmm10, [rsp+0x90]
000073baab9db538  vmovaps xmm11, [rsp+0xA0]
000073baab9db541  vmovaps xmm12, [rsp+0xB0]
000073baab9db54a  vmovaps xmm13, [rsp+0xC0]
000073baab9db553  vmovaps xmm14, [rsp+0xD0]
000073baab9db55c  vmovaps xmm15, [rsp+0xE0]
000073baab9db565  add rsp, 0xF0
000073baab9db56c  pop r11
000073baab9db56e  pop r10
000073baab9db570  pop r9
000073baab9db572  pop r8
000073baab9db574  pop rsi
000073baab9db575  pop rdi
000073baab9db576  pop rdx
000073baab9db577  pop rcx
000073baab9db578  pop rax
000073baab9db579  add rsp, 0x08
000073baab9db57d  jmp 0x000073BAAB9D9167
000073baab9db582  sub rsp, 0x08
000073baab9db586  push rax
000073baab9db587  push rcx
000073baab9db588  push rdx
000073baab9db589  push rdi
000073baab9db58a  push rsi
000073baab9db58b  push r8
000073baab9db58d  push r9
000073baab9db58f  push r10
000073baab9db591  push r11
000073baab9db593  sub rsp, 0xF0
000073baab9db59a  vmovaps [rsp], xmm0
000073baab9db59f  vmovaps [rsp+0x10], xmm1
000073baab9db5a5  vmovaps [rsp+0x20], xmm2
000073baab9db5ab  vmovaps [rsp+0x30], xmm3
000073baab9db5b1  vmovaps [rsp+0x40], xmm4
000073baab9db5b7  vmovaps [rsp+0x50], xmm5
000073baab9db5bd  vmovaps [rsp+0x60], xmm7
000073baab9db5c3  vmovaps [rsp+0x70], xmm8
000073baab9db5c9  vmovaps [rsp+0x80], xmm9
000073baab9db5d2  vmovaps [rsp+0x90], xmm10
000073baab9db5db  vmovaps [rsp+0xA0], xmm11
000073baab9db5e4  vmovaps [rsp+0xB0], xmm12
000073baab9db5ed  vmovaps [rsp+0xC0], xmm13
000073baab9db5f6  vmovaps [rsp+0xD0], xmm14
000073baab9db5ff  vmovaps [rsp+0xE0], xmm15
000073baab9db608  sub rsp, 0x30
000073baab9db60c  movaps [rsp], xmm6
000073baab9db610  movaps [rsp+0x10], xmm9
000073baab9db616  movaps [rsp+0x20], xmm1
000073baab9db61b  lea rdi, [rsp]
000073baab9db61f  mov esi, 0x00
000073baab9db624  mov rax, 0x5F3F1062D530
000073baab9db62e  call rax
000073baab9db630  movaps xmm6, [rsp]
000073baab9db634  add rsp, 0x30
000073baab9db638  vmovaps xmm0, [rsp]
000073baab9db63d  vmovaps xmm1, [rsp+0x10]
000073baab9db643  vmovaps xmm2, [rsp+0x20]
000073baab9db649  vmovaps xmm3, [rsp+0x30]
000073baab9db64f  vmovaps xmm4, [rsp+0x40]
000073baab9db655  vmovaps xmm5, [rsp+0x50]
000073baab9db65b  vmovaps xmm7, [rsp+0x60]
000073baab9db661  vmovaps xmm8, [rsp+0x70]
000073baab9db667  vmovaps xmm9, [rsp+0x80]
000073baab9db670  vmovaps xmm10, [rsp+0x90]
000073baab9db679  vmovaps xmm11, [rsp+0xA0]
000073baab9db682  vmovaps xmm12, [rsp+0xB0]
000073baab9db68b  vmovaps xmm13, [rsp+0xC0]
000073baab9db694  vmovaps xmm14, [rsp+0xD0]
000073baab9db69d  vmovaps xmm15, [rsp+0xE0]
000073baab9db6a6  add rsp, 0xF0
000073baab9db6ad  pop r11
000073baab9db6af  pop r10
000073baab9db6b1  pop r9
000073baab9db6b3  pop r8
000073baab9db6b5  pop rsi
000073baab9db6b6  pop rdi
000073baab9db6b7  pop rdx
000073baab9db6b8  pop rcx
000073baab9db6b9  pop rax
000073baab9db6ba  add rsp, 0x08
000073baab9db6be  jmp 0x000073BAAB9D918B
000073baab9db6c3  sub rsp, 0x08
000073baab9db6c7  push rax
000073baab9db6c8  push rcx
000073baab9db6c9  push rdx
000073baab9db6ca  push rdi
000073baab9db6cb  push rsi
000073baab9db6cc  push r8
000073baab9db6ce  push r9
000073baab9db6d0  push r10
000073baab9db6d2  push r11
000073baab9db6d4  sub rsp, 0xF0
000073baab9db6db  vmovaps [rsp], xmm0
000073baab9db6e0  vmovaps [rsp+0x10], xmm1
000073baab9db6e6  vmovaps [rsp+0x20], xmm2
000073baab9db6ec  vmovaps [rsp+0x30], xmm3
000073baab9db6f2  vmovaps [rsp+0x40], xmm4
000073baab9db6f8  vmovaps [rsp+0x50], xmm5
000073baab9db6fe  vmovaps [rsp+0x60], xmm6
000073baab9db704  vmovaps [rsp+0x70], xmm7
000073baab9db70a  vmovaps [rsp+0x80], xmm8
000073baab9db713  vmovaps [rsp+0x90], xmm10
000073baab9db71c  vmovaps [rsp+0xA0], xmm11
000073baab9db725  vmovaps [rsp+0xB0], xmm12
000073baab9db72e  vmovaps [rsp+0xC0], xmm13
000073baab9db737  vmovaps [rsp+0xD0], xmm14
000073baab9db740  vmovaps [rsp+0xE0], xmm15
000073baab9db749  sub rsp, 0x30
000073baab9db74d  movaps [rsp], xmm9
000073baab9db752  movaps [rsp+0x10], xmm3
000073baab9db757  movaps [rsp+0x20], xmm1
000073baab9db75c  lea rdi, [rsp]
000073baab9db760  mov esi, 0x00
000073baab9db765  mov rax, 0x5F3F1062D530
000073baab9db76f  call rax
000073baab9db771  movaps xmm9, [rsp]
000073baab9db776  add rsp, 0x30
000073baab9db77a  vmovaps xmm0, [rsp]
000073baab9db77f  vmovaps xmm1, [rsp+0x10]
000073baab9db785  vmovaps xmm2, [rsp+0x20]
000073baab9db78b  vmovaps xmm3, [rsp+0x30]
000073baab9db791  vmovaps xmm4, [rsp+0x40]
000073baab9db797  vmovaps xmm5, [rsp+0x50]
000073baab9db79d  vmovaps xmm6, [rsp+0x60]
000073baab9db7a3  vmovaps xmm7, [rsp+0x70]
000073baab9db7a9  vmovaps xmm8, [rsp+0x80]
000073baab9db7b2  vmovaps xmm10, [rsp+0x90]
000073baab9db7bb  vmovaps xmm11, [rsp+0xA0]
000073baab9db7c4  vmovaps xmm12, [rsp+0xB0]
000073baab9db7cd  vmovaps xmm13, [rsp+0xC0]
000073baab9db7d6  vmovaps xmm14, [rsp+0xD0]
000073baab9db7df  vmovaps xmm15, [rsp+0xE0]
000073baab9db7e8  add rsp, 0xF0
000073baab9db7ef  pop r11
000073baab9db7f1  pop r10
000073baab9db7f3  pop r9
000073baab9db7f5  pop r8
000073baab9db7f7  pop rsi
000073baab9db7f8  pop rdi
000073baab9db7f9  pop rdx
000073baab9db7fa  pop rcx
000073baab9db7fb  pop rax
000073baab9db7fc  add rsp, 0x08
000073baab9db800  jmp 0x000073BAAB9D91D7
000073baab9db805  call 0x000073BAAB8D64F0
000073baab9db80a  jmp 0x000073BAAB9D91E4
000073baab9db80f  sub rsp, 0x08
000073baab9db813  push rax
000073baab9db814  push rcx
000073baab9db815  push rdx
000073baab9db816  push rdi
000073baab9db817  push rsi
000073baab9db818  push r8
000073baab9db81a  push r9
000073baab9db81c  push r10
000073baab9db81e  push r11
000073baab9db820  sub rsp, 0xF0
000073baab9db827  vmovaps [rsp], xmm0
000073baab9db82c  vmovaps [rsp+0x10], xmm1
000073baab9db832  vmovaps [rsp+0x20], xmm2
000073baab9db838  vmovaps [rsp+0x30], xmm3
000073baab9db83e  vmovaps [rsp+0x40], xmm4
000073baab9db844  vmovaps [rsp+0x50], xmm5
000073baab9db84a  vmovaps [rsp+0x60], xmm6
000073baab9db850  vmovaps [rsp+0x70], xmm7
000073baab9db856  vmovaps [rsp+0x80], xmm8
000073baab9db85f  vmovaps [rsp+0x90], xmm9
000073baab9db868  vmovaps [rsp+0xA0], xmm10
000073baab9db871  vmovaps [rsp+0xB0], xmm11
000073baab9db87a  vmovaps [rsp+0xC0], xmm12
000073baab9db883  vmovaps [rsp+0xD0], xmm13
000073baab9db88c  vmovaps [rsp+0xE0], xmm14
000073baab9db895  sub rsp, 0x30
000073baab9db899  movaps [rsp], xmm15
000073baab9db89e  movaps [rsp+0x10], xmm3
000073baab9db8a3  movaps [rsp+0x20], xmm7
000073baab9db8a8  lea rdi, [rsp]
000073baab9db8ac  mov esi, 0x00
000073baab9db8b1  mov rax, 0x5F3F1062D530
000073baab9db8bb  call rax
000073baab9db8bd  movaps xmm15, [rsp]
000073baab9db8c2  add rsp, 0x30
000073baab9db8c6  vmovaps xmm0, [rsp]
000073baab9db8cb  vmovaps xmm1, [rsp+0x10]
000073baab9db8d1  vmovaps xmm2, [rsp+0x20]
000073baab9db8d7  vmovaps xmm3, [rsp+0x30]
000073baab9db8dd  vmovaps xmm4, [rsp+0x40]
000073baab9db8e3  vmovaps xmm5, [rsp+0x50]
000073baab9db8e9  vmovaps xmm6, [rsp+0x60]
000073baab9db8ef  vmovaps xmm7, [rsp+0x70]
000073baab9db8f5  vmovaps xmm8, [rsp+0x80]
000073baab9db8fe  vmovaps xmm9, [rsp+0x90]
000073baab9db907  vmovaps xmm10, [rsp+0xA0]
000073baab9db910  vmovaps xmm11, [rsp+0xB0]
000073baab9db919  vmovaps xmm12, [rsp+0xC0]
000073baab9db922  vmovaps xmm13, [rsp+0xD0]
000073baab9db92b  vmovaps xmm14, [rsp+0xE0]
000073baab9db934  add rsp, 0xF0
000073baab9db93b  pop r11
000073baab9db93d  pop r10
000073baab9db93f  pop r9
000073baab9db941  pop r8
000073baab9db943  pop rsi
000073baab9db944  pop rdi
000073baab9db945  pop rdx
000073baab9db946  pop rcx
000073baab9db947  pop rax
000073baab9db948  add rsp, 0x08
000073baab9db94c  jmp 0x000073BAAB9D9210
000073baab9db951  sub rsp, 0x08
000073baab9db955  push rax
000073baab9db956  push rcx
000073baab9db957  push rdx
000073baab9db958  push rdi
000073baab9db959  push rsi
000073baab9db95a  push r8
000073baab9db95c  push r9
000073baab9db95e  push r10
000073baab9db960  push r11
000073baab9db962  sub rsp, 0xF0
000073baab9db969  vmovaps [rsp], xmm0
000073baab9db96e  vmovaps [rsp+0x10], xmm1
000073baab9db974  vmovaps [rsp+0x20], xmm2
000073baab9db97a  vmovaps [rsp+0x30], xmm4
000073baab9db980  vmovaps [rsp+0x40], xmm5
000073baab9db986  vmovaps [rsp+0x50], xmm6
000073baab9db98c  vmovaps [rsp+0x60], xmm7
000073baab9db992  vmovaps [rsp+0x70], xmm8
000073baab9db998  vmovaps [rsp+0x80], xmm9
000073baab9db9a1  vmovaps [rsp+0x90], xmm10
000073baab9db9aa  vmovaps [rsp+0xA0], xmm11
000073baab9db9b3  vmovaps [rsp+0xB0], xmm12
000073baab9db9bc  vmovaps [rsp+0xC0], xmm13
000073baab9db9c5  vmovaps [rsp+0xD0], xmm14
000073baab9db9ce  vmovaps [rsp+0xE0], xmm15
000073baab9db9d7  sub rsp, 0x30
000073baab9db9db  movaps [rsp], xmm3
000073baab9db9df  movaps [rsp+0x10], xmm1
000073baab9db9e4  movaps [rsp+0x20], xmm15
000073baab9db9ea  lea rdi, [rsp]
000073baab9db9ee  mov esi, 0x00
000073baab9db9f3  mov rax, 0x5F3F1062D530
000073baab9db9fd  call rax
000073baab9db9ff  movaps xmm3, [rsp]
000073baab9dba03  add rsp, 0x30
000073baab9dba07  vmovaps xmm0, [rsp]
000073baab9dba0c  vmovaps xmm1, [rsp+0x10]
000073baab9dba12  vmovaps xmm2, [rsp+0x20]
000073baab9dba18  vmovaps xmm4, [rsp+0x30]
000073baab9dba1e  vmovaps xmm5, [rsp+0x40]
000073baab9dba24  vmovaps xmm6, [rsp+0x50]
000073baab9dba2a  vmovaps xmm7, [rsp+0x60]
000073baab9dba30  vmovaps xmm8, [rsp+0x70]
000073baab9dba36  vmovaps xmm9, [rsp+0x80]
000073baab9dba3f  vmovaps xmm10, [rsp+0x90]
000073baab9dba48  vmovaps xmm11, [rsp+0xA0]
000073baab9dba51  vmovaps xmm12, [rsp+0xB0]
000073baab9dba5a  vmovaps xmm13, [rsp+0xC0]
000073baab9dba63  vmovaps xmm14, [rsp+0xD0]
000073baab9dba6c  vmovaps xmm15, [rsp+0xE0]
000073baab9dba75  add rsp, 0xF0
000073baab9dba7c  pop r11
000073baab9dba7e  pop r10
000073baab9dba80  pop r9
000073baab9dba82  pop r8
000073baab9dba84  pop rsi
000073baab9dba85  pop rdi
000073baab9dba86  pop rdx
000073baab9dba87  pop rcx
000073baab9dba88  pop rax
000073baab9dba89  add rsp, 0x08
000073baab9dba8d  jmp 0x000073BAAB9D929F
000073baab9dba92  call 0x000073BAAB8D64F0
000073baab9dba97  jmp 0x000073BAAB9D92A9
000073baab9dba9c  sub rsp, 0x08
000073baab9dbaa0  push rax
000073baab9dbaa1  push rcx
000073baab9dbaa2  push rdx
000073baab9dbaa3  push rdi
000073baab9dbaa4  push rsi
000073baab9dbaa5  push r8
000073baab9dbaa7  push r9
000073baab9dbaa9  push r10
000073baab9dbaab  push r11
000073baab9dbaad  sub rsp, 0xF0
000073baab9dbab4  vmovaps [rsp], xmm0
000073baab9dbab9  vmovaps [rsp+0x10], xmm1
000073baab9dbabf  vmovaps [rsp+0x20], xmm2
000073baab9dbac5  vmovaps [rsp+0x30], xmm3
000073baab9dbacb  vmovaps [rsp+0x40], xmm4
000073baab9dbad1  vmovaps [rsp+0x50], xmm5
000073baab9dbad7  vmovaps [rsp+0x60], xmm6
000073baab9dbadd  vmovaps [rsp+0x70], xmm7
000073baab9dbae3  vmovaps [rsp+0x80], xmm8
000073baab9dbaec  vmovaps [rsp+0x90], xmm9
000073baab9dbaf5  vmovaps [rsp+0xA0], xmm10
000073baab9dbafe  vmovaps [rsp+0xB0], xmm11
000073baab9dbb07  vmovaps [rsp+0xC0], xmm12
000073baab9dbb10  vmovaps [rsp+0xD0], xmm13
000073baab9dbb19  vmovaps [rsp+0xE0], xmm14
000073baab9dbb22  sub rsp, 0x30
000073baab9dbb26  movaps [rsp], xmm15
000073baab9dbb2b  movaps [rsp+0x10], xmm14
000073baab9dbb31  movaps [rsp+0x20], xmm4
000073baab9dbb36  lea rdi, [rsp]
000073baab9dbb3a  mov esi, 0x00
000073baab9dbb3f  mov rax, 0x5F3F1062D530
000073baab9dbb49  call rax
000073baab9dbb4b  movaps xmm15, [rsp]
000073baab9dbb50  add rsp, 0x30
000073baab9dbb54  vmovaps xmm0, [rsp]
000073baab9dbb59  vmovaps xmm1, [rsp+0x10]
000073baab9dbb5f  vmovaps xmm2, [rsp+0x20]
000073baab9dbb65  vmovaps xmm3, [rsp+0x30]
000073baab9dbb6b  vmovaps xmm4, [rsp+0x40]
000073baab9dbb71  vmovaps xmm5, [rsp+0x50]
000073baab9dbb77  vmovaps xmm6, [rsp+0x60]
000073baab9dbb7d  vmovaps xmm7, [rsp+0x70]
000073baab9dbb83  vmovaps xmm8, [rsp+0x80]
000073baab9dbb8c  vmovaps xmm9, [rsp+0x90]
000073baab9dbb95  vmovaps xmm10, [rsp+0xA0]
000073baab9dbb9e  vmovaps xmm11, [rsp+0xB0]
000073baab9dbba7  vmovaps xmm12, [rsp+0xC0]
000073baab9dbbb0  vmovaps xmm13, [rsp+0xD0]
000073baab9dbbb9  vmovaps xmm14, [rsp+0xE0]
000073baab9dbbc2  add rsp, 0xF0
000073baab9dbbc9  pop r11
000073baab9dbbcb  pop r10
000073baab9dbbcd  pop r9
000073baab9dbbcf  pop r8
000073baab9dbbd1  pop rsi
000073baab9dbbd2  pop rdi
000073baab9dbbd3  pop rdx
000073baab9dbbd4  pop rcx
000073baab9dbbd5  pop rax
000073baab9dbbd6  add rsp, 0x08
000073baab9dbbda  jmp 0x000073BAAB9D92D7
000073baab9dbbdf  sub rsp, 0x08
000073baab9dbbe3  push rax
000073baab9dbbe4  push rcx
000073baab9dbbe5  push rdx
000073baab9dbbe6  push rdi
000073baab9dbbe7  push rsi
000073baab9dbbe8  push r8
000073baab9dbbea  push r9
000073baab9dbbec  push r10
000073baab9dbbee  push r11
000073baab9dbbf0  sub rsp, 0xF0
000073baab9dbbf7  vmovaps [rsp], xmm0
000073baab9dbbfc  vmovaps [rsp+0x10], xmm1
000073baab9dbc02  vmovaps [rsp+0x20], xmm2
000073baab9dbc08  vmovaps [rsp+0x30], xmm3
000073baab9dbc0e  vmovaps [rsp+0x40], xmm4
000073baab9dbc14  vmovaps [rsp+0x50], xmm5
000073baab9dbc1a  vmovaps [rsp+0x60], xmm6
000073baab9dbc20  vmovaps [rsp+0x70], xmm7
000073baab9dbc26  vmovaps [rsp+0x80], xmm8
000073baab9dbc2f  vmovaps [rsp+0x90], xmm9
000073baab9dbc38  vmovaps [rsp+0xA0], xmm10
000073baab9dbc41  vmovaps [rsp+0xB0], xmm11
000073baab9dbc4a  vmovaps [rsp+0xC0], xmm12
000073baab9dbc53  vmovaps [rsp+0xD0], xmm13
000073baab9dbc5c  vmovaps [rsp+0xE0], xmm15
000073baab9dbc65  sub rsp, 0x30
000073baab9dbc69  movaps [rsp], xmm14
000073baab9dbc6e  movaps [rsp+0x10], xmm2
000073baab9dbc73  movaps [rsp+0x20], xmm1
000073baab9dbc78  lea rdi, [rsp]
000073baab9dbc7c  mov esi, 0x00
000073baab9dbc81  mov rax, 0x5F3F1062D530
000073baab9dbc8b  call rax
000073baab9dbc8d  movaps xmm14, [rsp]
000073baab9dbc92  add rsp, 0x30
000073baab9dbc96  vmovaps xmm0, [rsp]
000073baab9dbc9b  vmovaps xmm1, [rsp+0x10]
000073baab9dbca1  vmovaps xmm2, [rsp+0x20]
000073baab9dbca7  vmovaps xmm3, [rsp+0x30]
000073baab9dbcad  vmovaps xmm4, [rsp+0x40]
000073baab9dbcb3  vmovaps xmm5, [rsp+0x50]
000073baab9dbcb9  vmovaps xmm6, [rsp+0x60]
000073baab9dbcbf  vmovaps xmm7, [rsp+0x70]
000073baab9dbcc5  vmovaps xmm8, [rsp+0x80]
000073baab9dbcce  vmovaps xmm9, [rsp+0x90]
000073baab9dbcd7  vmovaps xmm10, [rsp+0xA0]
000073baab9dbce0  vmovaps xmm11, [rsp+0xB0]
000073baab9dbce9  vmovaps xmm12, [rsp+0xC0]
000073baab9dbcf2  vmovaps xmm13, [rsp+0xD0]
000073baab9dbcfb  vmovaps xmm15, [rsp+0xE0]
000073baab9dbd04  add rsp, 0xF0
000073baab9dbd0b  pop r11
000073baab9dbd0d  pop r10
000073baab9dbd0f  pop r9
000073baab9dbd11  pop r8
000073baab9dbd13  pop rsi
000073baab9dbd14  pop rdi
000073baab9dbd15  pop rdx
000073baab9dbd16  pop rcx
000073baab9dbd17  pop rax
000073baab9dbd18  add rsp, 0x08
000073baab9dbd1c  jmp 0x000073BAAB9D92FD
000073baab9dbd21  sub rsp, 0x08
000073baab9dbd25  push rax
000073baab9dbd26  push rcx
000073baab9dbd27  push rdx
000073baab9dbd28  push rdi
000073baab9dbd29  push rsi
000073baab9dbd2a  push r8
000073baab9dbd2c  push r9
000073baab9dbd2e  push r10
000073baab9dbd30  push r11
000073baab9dbd32  sub rsp, 0xF0
000073baab9dbd39  vmovaps [rsp], xmm0
000073baab9dbd3e  vmovaps [rsp+0x10], xmm2
000073baab9dbd44  vmovaps [rsp+0x20], xmm3
000073baab9dbd4a  vmovaps [rsp+0x30], xmm4
000073baab9dbd50  vmovaps [rsp+0x40], xmm5
000073baab9dbd56  vmovaps [rsp+0x50], xmm6
000073baab9dbd5c  vmovaps [rsp+0x60], xmm7
000073baab9dbd62  vmovaps [rsp+0x70], xmm8
000073baab9dbd68  vmovaps [rsp+0x80], xmm9
000073baab9dbd71  vmovaps [rsp+0x90], xmm10
000073baab9dbd7a  vmovaps [rsp+0xA0], xmm11
000073baab9dbd83  vmovaps [rsp+0xB0], xmm12
000073baab9dbd8c  vmovaps [rsp+0xC0], xmm13
000073baab9dbd95  vmovaps [rsp+0xD0], xmm14
000073baab9dbd9e  vmovaps [rsp+0xE0], xmm15
000073baab9dbda7  sub rsp, 0x30
000073baab9dbdab  movaps [rsp], xmm1
000073baab9dbdaf  movaps [rsp+0x10], xmm4
000073baab9dbdb4  movaps [rsp+0x20], xmm9
000073baab9dbdba  lea rdi, [rsp]
000073baab9dbdbe  mov esi, 0x00
000073baab9dbdc3  mov rax, 0x5F3F1062D530
000073baab9dbdcd  call rax
000073baab9dbdcf  movaps xmm1, [rsp]
000073baab9dbdd3  add rsp, 0x30
000073baab9dbdd7  vmovaps xmm0, [rsp]
000073baab9dbddc  vmovaps xmm2, [rsp+0x10]
000073baab9dbde2  vmovaps xmm3, [rsp+0x20]
000073baab9dbde8  vmovaps xmm4, [rsp+0x30]
000073baab9dbdee  vmovaps xmm5, [rsp+0x40]
000073baab9dbdf4  vmovaps xmm6, [rsp+0x50]
000073baab9dbdfa  vmovaps xmm7, [rsp+0x60]
000073baab9dbe00  vmovaps xmm8, [rsp+0x70]
000073baab9dbe06  vmovaps xmm9, [rsp+0x80]
000073baab9dbe0f  vmovaps xmm10, [rsp+0x90]
000073baab9dbe18  vmovaps xmm11, [rsp+0xA0]
000073baab9dbe21  vmovaps xmm12, [rsp+0xB0]
000073baab9dbe2a  vmovaps xmm13, [rsp+0xC0]
000073baab9dbe33  vmovaps xmm14, [rsp+0xD0]
000073baab9dbe3c  vmovaps xmm15, [rsp+0xE0]
000073baab9dbe45  add rsp, 0xF0
000073baab9dbe4c  pop r11
000073baab9dbe4e  pop r10
000073baab9dbe50  pop r9
000073baab9dbe52  pop r8
000073baab9dbe54  pop rsi
000073baab9dbe55  pop rdi
000073baab9dbe56  pop rdx
000073baab9dbe57  pop rcx
000073baab9dbe58  pop rax
000073baab9dbe59  add rsp, 0x08
000073baab9dbe5d  jmp 0x000073BAAB9D931B
000073baab9dbe62  sub rsp, 0x08
000073baab9dbe66  push rax
000073baab9dbe67  push rcx
000073baab9dbe68  push rdx
000073baab9dbe69  push rdi
000073baab9dbe6a  push rsi
000073baab9dbe6b  push r8
000073baab9dbe6d  push r9
000073baab9dbe6f  push r10
000073baab9dbe71  push r11
000073baab9dbe73  sub rsp, 0xF0
000073baab9dbe7a  vmovaps [rsp], xmm0
000073baab9dbe7f  vmovaps [rsp+0x10], xmm1
000073baab9dbe85  vmovaps [rsp+0x20], xmm2
000073baab9dbe8b  vmovaps [rsp+0x30], xmm3
000073baab9dbe91  vmovaps [rsp+0x40], xmm5
000073baab9dbe97  vmovaps [rsp+0x50], xmm6
000073baab9dbe9d  vmovaps [rsp+0x60], xmm7
000073baab9dbea3  vmovaps [rsp+0x70], xmm8
000073baab9dbea9  vmovaps [rsp+0x80], xmm9
000073baab9dbeb2  vmovaps [rsp+0x90], xmm10
000073baab9dbebb  vmovaps [rsp+0xA0], xmm11
000073baab9dbec4  vmovaps [rsp+0xB0], xmm12
000073baab9dbecd  vmovaps [rsp+0xC0], xmm13
000073baab9dbed6  vmovaps [rsp+0xD0], xmm14
000073baab9dbedf  vmovaps [rsp+0xE0], xmm15
000073baab9dbee8  sub rsp, 0x30
000073baab9dbeec  movaps [rsp], xmm4
000073baab9dbef0  movaps [rsp+0x10], xmm2
000073baab9dbef5  movaps [rsp+0x20], xmm9
000073baab9dbefb  lea rdi, [rsp]
000073baab9dbeff  mov esi, 0x00
000073baab9dbf04  mov rax, 0x5F3F1062D530
000073baab9dbf0e  call rax
000073baab9dbf10  movaps xmm4, [rsp]
000073baab9dbf14  add rsp, 0x30
000073baab9dbf18  vmovaps xmm0, [rsp]
000073baab9dbf1d  vmovaps xmm1, [rsp+0x10]
000073baab9dbf23  vmovaps xmm2, [rsp+0x20]
000073baab9dbf29  vmovaps xmm3, [rsp+0x30]
000073baab9dbf2f  vmovaps xmm5, [rsp+0x40]
000073baab9dbf35  vmovaps xmm6, [rsp+0x50]
000073baab9dbf3b  vmovaps xmm7, [rsp+0x60]
000073baab9dbf41  vmovaps xmm8, [rsp+0x70]
000073baab9dbf47  vmovaps xmm9, [rsp+0x80]
000073baab9dbf50  vmovaps xmm10, [rsp+0x90]
000073baab9dbf59  vmovaps xmm11, [rsp+0xA0]
000073baab9dbf62  vmovaps xmm12, [rsp+0xB0]
000073baab9dbf6b  vmovaps xmm13, [rsp+0xC0]
000073baab9dbf74  vmovaps xmm14, [rsp+0xD0]
000073baab9dbf7d  vmovaps xmm15, [rsp+0xE0]
000073baab9dbf86  add rsp, 0xF0
000073baab9dbf8d  pop r11
000073baab9dbf8f  pop r10
000073baab9dbf91  pop r9
000073baab9dbf93  pop r8
000073baab9dbf95  pop rsi
000073baab9dbf96  pop rdi
000073baab9dbf97  pop rdx
000073baab9dbf98  pop rcx
000073baab9dbf99  pop rax
000073baab9dbf9a  add rsp, 0x08
000073baab9dbf9e  jmp 0x000073BAAB9D934B
000073baab9dbfa3  sub rsp, 0x08
000073baab9dbfa7  push rax
000073baab9dbfa8  push rcx
000073baab9dbfa9  push rdx
000073baab9dbfaa  push rdi
000073baab9dbfab  push rsi
000073baab9dbfac  push r8
000073baab9dbfae  push r9
000073baab9dbfb0  push r10
000073baab9dbfb2  push r11
000073baab9dbfb4  sub rsp, 0xF0
000073baab9dbfbb  vmovaps [rsp], xmm0
000073baab9dbfc0  vmovaps [rsp+0x10], xmm1
000073baab9dbfc6  vmovaps [rsp+0x20], xmm2
000073baab9dbfcc  vmovaps [rsp+0x30], xmm3
000073baab9dbfd2  vmovaps [rsp+0x40], xmm4
000073baab9dbfd8  vmovaps [rsp+0x50], xmm5
000073baab9dbfde  vmovaps [rsp+0x60], xmm6
000073baab9dbfe4  vmovaps [rsp+0x70], xmm7
000073baab9dbfea  vmovaps [rsp+0x80], xmm8
000073baab9dbff3  vmovaps [rsp+0x90], xmm10
000073baab9dbffc  vmovaps [rsp+0xA0], xmm11
000073baab9dc005  vmovaps [rsp+0xB0], xmm12
000073baab9dc00e  vmovaps [rsp+0xC0], xmm13
000073baab9dc017  vmovaps [rsp+0xD0], xmm14
000073baab9dc020  vmovaps [rsp+0xE0], xmm15
000073baab9dc029  sub rsp, 0x30
000073baab9dc02d  movaps [rsp], xmm9
000073baab9dc032  movaps [rsp+0x10], xmm2
000073baab9dc037  movaps [rsp+0x20], xmm1
000073baab9dc03c  lea rdi, [rsp]
000073baab9dc040  mov esi, 0x00
000073baab9dc045  mov rax, 0x5F3F1062D530
000073baab9dc04f  call rax
000073baab9dc051  movaps xmm9, [rsp]
000073baab9dc056  add rsp, 0x30
000073baab9dc05a  vmovaps xmm0, [rsp]
000073baab9dc05f  vmovaps xmm1, [rsp+0x10]
000073baab9dc065  vmovaps xmm2, [rsp+0x20]
000073baab9dc06b  vmovaps xmm3, [rsp+0x30]
000073baab9dc071  vmovaps xmm4, [rsp+0x40]
000073baab9dc077  vmovaps xmm5, [rsp+0x50]
000073baab9dc07d  vmovaps xmm6, [rsp+0x60]
000073baab9dc083  vmovaps xmm7, [rsp+0x70]
000073baab9dc089  vmovaps xmm8, [rsp+0x80]
000073baab9dc092  vmovaps xmm10, [rsp+0x90]
000073baab9dc09b  vmovaps xmm11, [rsp+0xA0]
000073baab9dc0a4  vmovaps xmm12, [rsp+0xB0]
000073baab9dc0ad  vmovaps xmm13, [rsp+0xC0]
000073baab9dc0b6  vmovaps xmm14, [rsp+0xD0]
000073baab9dc0bf  vmovaps xmm15, [rsp+0xE0]
000073baab9dc0c8  add rsp, 0xF0
000073baab9dc0cf  pop r11
000073baab9dc0d1  pop r10
000073baab9dc0d3  pop r9
000073baab9dc0d5  pop r8
000073baab9dc0d7  pop rsi
000073baab9dc0d8  pop rdi
000073baab9dc0d9  pop rdx
000073baab9dc0da  pop rcx
000073baab9dc0db  pop rax
000073baab9dc0dc  add rsp, 0x08
000073baab9dc0e0  jmp 0x000073BAAB9D9381
000073baab9dc0e5  sub rsp, 0x08
000073baab9dc0e9  push rax
000073baab9dc0ea  push rcx
000073baab9dc0eb  push rdx
000073baab9dc0ec  push rdi
000073baab9dc0ed  push rsi
000073baab9dc0ee  push r8
000073baab9dc0f0  push r9
000073baab9dc0f2  push r10
000073baab9dc0f4  push r11
000073baab9dc0f6  sub rsp, 0xF0
000073baab9dc0fd  vmovaps [rsp], xmm0
000073baab9dc102  vmovaps [rsp+0x10], xmm2
000073baab9dc108  vmovaps [rsp+0x20], xmm3
000073baab9dc10e  vmovaps [rsp+0x30], xmm4
000073baab9dc114  vmovaps [rsp+0x40], xmm5
000073baab9dc11a  vmovaps [rsp+0x50], xmm6
000073baab9dc120  vmovaps [rsp+0x60], xmm7
000073baab9dc126  vmovaps [rsp+0x70], xmm8
000073baab9dc12c  vmovaps [rsp+0x80], xmm9
000073baab9dc135  vmovaps [rsp+0x90], xmm10
000073baab9dc13e  vmovaps [rsp+0xA0], xmm11
000073baab9dc147  vmovaps [rsp+0xB0], xmm12
000073baab9dc150  vmovaps [rsp+0xC0], xmm13
000073baab9dc159  vmovaps [rsp+0xD0], xmm14
000073baab9dc162  vmovaps [rsp+0xE0], xmm15
000073baab9dc16b  sub rsp, 0x30
000073baab9dc16f  movaps [rsp], xmm1
000073baab9dc173  movaps [rsp+0x10], xmm15
000073baab9dc179  movaps [rsp+0x20], xmm6
000073baab9dc17e  lea rdi, [rsp]
000073baab9dc182  mov esi, 0x00
000073baab9dc187  mov rax, 0x5F3F1062D530
000073baab9dc191  call rax
000073baab9dc193  movaps xmm1, [rsp]
000073baab9dc197  add rsp, 0x30
000073baab9dc19b  vmovaps xmm0, [rsp]
000073baab9dc1a0  vmovaps xmm2, [rsp+0x10]
000073baab9dc1a6  vmovaps xmm3, [rsp+0x20]
000073baab9dc1ac  vmovaps xmm4, [rsp+0x30]
000073baab9dc1b2  vmovaps xmm5, [rsp+0x40]
000073baab9dc1b8  vmovaps xmm6, [rsp+0x50]
000073baab9dc1be  vmovaps xmm7, [rsp+0x60]
000073baab9dc1c4  vmovaps xmm8, [rsp+0x70]
000073baab9dc1ca  vmovaps xmm9, [rsp+0x80]
000073baab9dc1d3  vmovaps xmm10, [rsp+0x90]
000073baab9dc1dc  vmovaps xmm11, [rsp+0xA0]
000073baab9dc1e5  vmovaps xmm12, [rsp+0xB0]
000073baab9dc1ee  vmovaps xmm13, [rsp+0xC0]
000073baab9dc1f7  vmovaps xmm14, [rsp+0xD0]
000073baab9dc200  vmovaps xmm15, [rsp+0xE0]
000073baab9dc209  add rsp, 0xF0
000073baab9dc210  pop r11
000073baab9dc212  pop r10
000073baab9dc214  pop r9
000073baab9dc216  pop r8
000073baab9dc218  pop rsi
000073baab9dc219  pop rdi
000073baab9dc21a  pop rdx
000073baab9dc21b  pop rcx
000073baab9dc21c  pop rax
000073baab9dc21d  add rsp, 0x08
000073baab9dc221  jmp 0x000073BAAB9D93A2
000073baab9dc226  sub rsp, 0x08
000073baab9dc22a  push rax
000073baab9dc22b  push rcx
000073baab9dc22c  push rdx
000073baab9dc22d  push rdi
000073baab9dc22e  push rsi
000073baab9dc22f  push r8
000073baab9dc231  push r9
000073baab9dc233  push r10
000073baab9dc235  push r11
000073baab9dc237  sub rsp, 0xF0
000073baab9dc23e  vmovaps [rsp], xmm0
000073baab9dc243  vmovaps [rsp+0x10], xmm1
000073baab9dc249  vmovaps [rsp+0x20], xmm2
000073baab9dc24f  vmovaps [rsp+0x30], xmm3
000073baab9dc255  vmovaps [rsp+0x40], xmm4
000073baab9dc25b  vmovaps [rsp+0x50], xmm5
000073baab9dc261  vmovaps [rsp+0x60], xmm6
000073baab9dc267  vmovaps [rsp+0x70], xmm7
000073baab9dc26d  vmovaps [rsp+0x80], xmm8
000073baab9dc276  vmovaps [rsp+0x90], xmm9
000073baab9dc27f  vmovaps [rsp+0xA0], xmm10
000073baab9dc288  vmovaps [rsp+0xB0], xmm11
000073baab9dc291  vmovaps [rsp+0xC0], xmm12
000073baab9dc29a  vmovaps [rsp+0xD0], xmm13
000073baab9dc2a3  vmovaps [rsp+0xE0], xmm14
000073baab9dc2ac  sub rsp, 0x30
000073baab9dc2b0  movaps [rsp], xmm15
000073baab9dc2b5  movaps [rsp+0x10], xmm5
000073baab9dc2ba  movaps [rsp+0x20], xmm3
000073baab9dc2bf  lea rdi, [rsp]
000073baab9dc2c3  mov esi, 0x00
000073baab9dc2c8  mov rax, 0x5F3F1062D530
000073baab9dc2d2  call rax
000073baab9dc2d4  movaps xmm15, [rsp]
000073baab9dc2d9  add rsp, 0x30
000073baab9dc2dd  vmovaps xmm0, [rsp]
000073baab9dc2e2  vmovaps xmm1, [rsp+0x10]
000073baab9dc2e8  vmovaps xmm2, [rsp+0x20]
000073baab9dc2ee  vmovaps xmm3, [rsp+0x30]
000073baab9dc2f4  vmovaps xmm4, [rsp+0x40]
000073baab9dc2fa  vmovaps xmm5, [rsp+0x50]
000073baab9dc300  vmovaps xmm6, [rsp+0x60]
000073baab9dc306  vmovaps xmm7, [rsp+0x70]
000073baab9dc30c  vmovaps xmm8, [rsp+0x80]
000073baab9dc315  vmovaps xmm9, [rsp+0x90]
000073baab9dc31e  vmovaps xmm10, [rsp+0xA0]
000073baab9dc327  vmovaps xmm11, [rsp+0xB0]
000073baab9dc330  vmovaps xmm12, [rsp+0xC0]
000073baab9dc339  vmovaps xmm13, [rsp+0xD0]
000073baab9dc342  vmovaps xmm14, [rsp+0xE0]
000073baab9dc34b  add rsp, 0xF0
000073baab9dc352  pop r11
000073baab9dc354  pop r10
000073baab9dc356  pop r9
000073baab9dc358  pop r8
000073baab9dc35a  pop rsi
000073baab9dc35b  pop rdi
000073baab9dc35c  pop rdx
000073baab9dc35d  pop rcx
000073baab9dc35e  pop rax
000073baab9dc35f  add rsp, 0x08
000073baab9dc363  jmp 0x000073BAAB9D93BC
000073baab9dc368  sub rsp, 0x08
000073baab9dc36c  push rax
000073baab9dc36d  push rcx
000073baab9dc36e  push rdx
000073baab9dc36f  push rdi
000073baab9dc370  push rsi
000073baab9dc371  push r8
000073baab9dc373  push r9
000073baab9dc375  push r10
000073baab9dc377  push r11
000073baab9dc379  sub rsp, 0xF0
000073baab9dc380  vmovaps [rsp], xmm0
000073baab9dc385  vmovaps [rsp+0x10], xmm1
000073baab9dc38b  vmovaps [rsp+0x20], xmm2
000073baab9dc391  vmovaps [rsp+0x30], xmm3
000073baab9dc397  vmovaps [rsp+0x40], xmm4
000073baab9dc39d  vmovaps [rsp+0x50], xmm6
000073baab9dc3a3  vmovaps [rsp+0x60], xmm7
000073baab9dc3a9  vmovaps [rsp+0x70], xmm8
000073baab9dc3af  vmovaps [rsp+0x80], xmm9
000073baab9dc3b8  vmovaps [rsp+0x90], xmm10
000073baab9dc3c1  vmovaps [rsp+0xA0], xmm11
000073baab9dc3ca  vmovaps [rsp+0xB0], xmm12
000073baab9dc3d3  vmovaps [rsp+0xC0], xmm13
000073baab9dc3dc  vmovaps [rsp+0xD0], xmm14
000073baab9dc3e5  vmovaps [rsp+0xE0], xmm15
000073baab9dc3ee  sub rsp, 0x30
000073baab9dc3f2  movaps [rsp], xmm5
000073baab9dc3f6  movaps [rsp+0x10], xmm8
000073baab9dc3fc  movaps [rsp+0x20], xmm6
000073baab9dc401  lea rdi, [rsp]
000073baab9dc405  mov esi, 0x00
000073baab9dc40a  mov rax, 0x5F3F1062D530
000073baab9dc414  call rax
000073baab9dc416  movaps xmm5, [rsp]
000073baab9dc41a  add rsp, 0x30
000073baab9dc41e  vmovaps xmm0, [rsp]
000073baab9dc423  vmovaps xmm1, [rsp+0x10]
000073baab9dc429  vmovaps xmm2, [rsp+0x20]
000073baab9dc42f  vmovaps xmm3, [rsp+0x30]
000073baab9dc435  vmovaps xmm4, [rsp+0x40]
000073baab9dc43b  vmovaps xmm6, [rsp+0x50]
000073baab9dc441  vmovaps xmm7, [rsp+0x60]
000073baab9dc447  vmovaps xmm8, [rsp+0x70]
000073baab9dc44d  vmovaps xmm9, [rsp+0x80]
000073baab9dc456  vmovaps xmm10, [rsp+0x90]
000073baab9dc45f  vmovaps xmm11, [rsp+0xA0]
000073baab9dc468  vmovaps xmm12, [rsp+0xB0]
000073baab9dc471  vmovaps xmm13, [rsp+0xC0]
000073baab9dc47a  vmovaps xmm14, [rsp+0xD0]
000073baab9dc483  vmovaps xmm15, [rsp+0xE0]
000073baab9dc48c  add rsp, 0xF0
000073baab9dc493  pop r11
000073baab9dc495  pop r10
000073baab9dc497  pop r9
000073baab9dc499  pop r8
000073baab9dc49b  pop rsi
000073baab9dc49c  pop rdi
000073baab9dc49d  pop rdx
000073baab9dc49e  pop rcx
000073baab9dc49f  pop rax
000073baab9dc4a0  add rsp, 0x08
000073baab9dc4a4  jmp 0x000073BAAB9D93E0
000073baab9dc4a9  sub rsp, 0x08
000073baab9dc4ad  push rax
000073baab9dc4ae  push rcx
000073baab9dc4af  push rdx
000073baab9dc4b0  push rdi
000073baab9dc4b1  push rsi
000073baab9dc4b2  push r8
000073baab9dc4b4  push r9
000073baab9dc4b6  push r10
000073baab9dc4b8  push r11
000073baab9dc4ba  sub rsp, 0xF0
000073baab9dc4c1  vmovaps [rsp], xmm0
000073baab9dc4c6  vmovaps [rsp+0x10], xmm1
000073baab9dc4cc  vmovaps [rsp+0x20], xmm2
000073baab9dc4d2  vmovaps [rsp+0x30], xmm3
000073baab9dc4d8  vmovaps [rsp+0x40], xmm4
000073baab9dc4de  vmovaps [rsp+0x50], xmm5
000073baab9dc4e4  vmovaps [rsp+0x60], xmm7
000073baab9dc4ea  vmovaps [rsp+0x70], xmm8
000073baab9dc4f0  vmovaps [rsp+0x80], xmm9
000073baab9dc4f9  vmovaps [rsp+0x90], xmm10
000073baab9dc502  vmovaps [rsp+0xA0], xmm11
000073baab9dc50b  vmovaps [rsp+0xB0], xmm12
000073baab9dc514  vmovaps [rsp+0xC0], xmm13
000073baab9dc51d  vmovaps [rsp+0xD0], xmm14
000073baab9dc526  vmovaps [rsp+0xE0], xmm15
000073baab9dc52f  sub rsp, 0x30
000073baab9dc533  movaps [rsp], xmm6
000073baab9dc537  movaps [rsp+0x10], xmm10
000073baab9dc53d  movaps [rsp+0x20], xmm8
000073baab9dc543  lea rdi, [rsp]
000073baab9dc547  mov esi, 0x00
000073baab9dc54c  mov rax, 0x5F3F1062D530
000073baab9dc556  call rax
000073baab9dc558  movaps xmm6, [rsp]
000073baab9dc55c  add rsp, 0x30
000073baab9dc560  vmovaps xmm0, [rsp]
000073baab9dc565  vmovaps xmm1, [rsp+0x10]
000073baab9dc56b  vmovaps xmm2, [rsp+0x20]
000073baab9dc571  vmovaps xmm3, [rsp+0x30]
000073baab9dc577  vmovaps xmm4, [rsp+0x40]
000073baab9dc57d  vmovaps xmm5, [rsp+0x50]
000073baab9dc583  vmovaps xmm7, [rsp+0x60]
000073baab9dc589  vmovaps xmm8, [rsp+0x70]
000073baab9dc58f  vmovaps xmm9, [rsp+0x80]
000073baab9dc598  vmovaps xmm10, [rsp+0x90]
000073baab9dc5a1  vmovaps xmm11, [rsp+0xA0]
000073baab9dc5aa  vmovaps xmm12, [rsp+0xB0]
000073baab9dc5b3  vmovaps xmm13, [rsp+0xC0]
000073baab9dc5bc  vmovaps xmm14, [rsp+0xD0]
000073baab9dc5c5  vmovaps xmm15, [rsp+0xE0]
000073baab9dc5ce  add rsp, 0xF0
000073baab9dc5d5  pop r11
000073baab9dc5d7  pop r10
000073baab9dc5d9  pop r9
000073baab9dc5db  pop r8
000073baab9dc5dd  pop rsi
000073baab9dc5de  pop rdi
000073baab9dc5df  pop rdx
000073baab9dc5e0  pop rcx
000073baab9dc5e1  pop rax
000073baab9dc5e2  add rsp, 0x08
000073baab9dc5e6  jmp 0x000073BAAB9D9405
000073baab9dc5eb  sub rsp, 0x08
000073baab9dc5ef  push rax
000073baab9dc5f0  push rcx
000073baab9dc5f1  push rdx
000073baab9dc5f2  push rdi
000073baab9dc5f3  push rsi
000073baab9dc5f4  push r8
000073baab9dc5f6  push r9
000073baab9dc5f8  push r10
000073baab9dc5fa  push r11
000073baab9dc5fc  sub rsp, 0xF0
000073baab9dc603  vmovaps [rsp], xmm0
000073baab9dc608  vmovaps [rsp+0x10], xmm1
000073baab9dc60e  vmovaps [rsp+0x20], xmm2
000073baab9dc614  vmovaps [rsp+0x30], xmm3
000073baab9dc61a  vmovaps [rsp+0x40], xmm4
000073baab9dc620  vmovaps [rsp+0x50], xmm5
000073baab9dc626  vmovaps [rsp+0x60], xmm6
000073baab9dc62c  vmovaps [rsp+0x70], xmm7
000073baab9dc632  vmovaps [rsp+0x80], xmm8
000073baab9dc63b  vmovaps [rsp+0x90], xmm9
000073baab9dc644  vmovaps [rsp+0xA0], xmm11
000073baab9dc64d  vmovaps [rsp+0xB0], xmm12
000073baab9dc656  vmovaps [rsp+0xC0], xmm13
000073baab9dc65f  vmovaps [rsp+0xD0], xmm14
000073baab9dc668  vmovaps [rsp+0xE0], xmm15
000073baab9dc671  sub rsp, 0x30
000073baab9dc675  movaps [rsp], xmm10
000073baab9dc67a  movaps [rsp+0x10], xmm8
000073baab9dc680  movaps [rsp+0x20], xmm14
000073baab9dc686  lea rdi, [rsp]
000073baab9dc68a  mov esi, 0x00
000073baab9dc68f  mov rax, 0x5F3F1062D530
000073baab9dc699  call rax
000073baab9dc69b  movaps xmm10, [rsp]
000073baab9dc6a0  add rsp, 0x30
000073baab9dc6a4  vmovaps xmm0, [rsp]
000073baab9dc6a9  vmovaps xmm1, [rsp+0x10]
000073baab9dc6af  vmovaps xmm2, [rsp+0x20]
000073baab9dc6b5  vmovaps xmm3, [rsp+0x30]
000073baab9dc6bb  vmovaps xmm4, [rsp+0x40]
000073baab9dc6c1  vmovaps xmm5, [rsp+0x50]
000073baab9dc6c7  vmovaps xmm6, [rsp+0x60]
000073baab9dc6cd  vmovaps xmm7, [rsp+0x70]
000073baab9dc6d3  vmovaps xmm8, [rsp+0x80]
000073baab9dc6dc  vmovaps xmm9, [rsp+0x90]
000073baab9dc6e5  vmovaps xmm11, [rsp+0xA0]
000073baab9dc6ee  vmovaps xmm12, [rsp+0xB0]
000073baab9dc6f7  vmovaps xmm13, [rsp+0xC0]
000073baab9dc700  vmovaps xmm14, [rsp+0xD0]
000073baab9dc709  vmovaps xmm15, [rsp+0xE0]
000073baab9dc712  add rsp, 0xF0
000073baab9dc719  pop r11
000073baab9dc71b  pop r10
000073baab9dc71d  pop r9
000073baab9dc71f  pop r8
000073baab9dc721  pop rsi
000073baab9dc722  pop rdi
000073baab9dc723  pop rdx
000073baab9dc724  pop rcx
000073baab9dc725  pop rax
000073baab9dc726  add rsp, 0x08
000073baab9dc72a  jmp 0x000073BAAB9D9425
000073baab9dc72f  sub rsp, 0x08
000073baab9dc733  push rax
000073baab9dc734  push rcx
000073baab9dc735  push rdx
000073baab9dc736  push rdi
000073baab9dc737  push rsi
000073baab9dc738  push r8
000073baab9dc73a  push r9
000073baab9dc73c  push r10
000073baab9dc73e  push r11
000073baab9dc740  sub rsp, 0xF0
000073baab9dc747  vmovaps [rsp], xmm0
000073baab9dc74c  vmovaps [rsp+0x10], xmm1
000073baab9dc752  vmovaps [rsp+0x20], xmm2
000073baab9dc758  vmovaps [rsp+0x30], xmm3
000073baab9dc75e  vmovaps [rsp+0x40], xmm4
000073baab9dc764  vmovaps [rsp+0x50], xmm5
000073baab9dc76a  vmovaps [rsp+0x60], xmm6
000073baab9dc770  vmovaps [rsp+0x70], xmm7
000073baab9dc776  vmovaps [rsp+0x80], xmm8
000073baab9dc77f  vmovaps [rsp+0x90], xmm9
000073baab9dc788  vmovaps [rsp+0xA0], xmm10
000073baab9dc791  vmovaps [rsp+0xB0], xmm11
000073baab9dc79a  vmovaps [rsp+0xC0], xmm12
000073baab9dc7a3  vmovaps [rsp+0xD0], xmm13
000073baab9dc7ac  vmovaps [rsp+0xE0], xmm15
000073baab9dc7b5  sub rsp, 0x30
000073baab9dc7b9  movaps [rsp], xmm14
000073baab9dc7be  movaps [rsp+0x10], xmm8
000073baab9dc7c4  movaps [rsp+0x20], xmm4
000073baab9dc7c9  lea rdi, [rsp]
000073baab9dc7cd  mov esi, 0x00
000073baab9dc7d2  mov rax, 0x5F3F1062D530
000073baab9dc7dc  call rax
000073baab9dc7de  movaps xmm14, [rsp]
000073baab9dc7e3  add rsp, 0x30
000073baab9dc7e7  vmovaps xmm0, [rsp]
000073baab9dc7ec  vmovaps xmm1, [rsp+0x10]
000073baab9dc7f2  vmovaps xmm2, [rsp+0x20]
000073baab9dc7f8  vmovaps xmm3, [rsp+0x30]
000073baab9dc7fe  vmovaps xmm4, [rsp+0x40]
000073baab9dc804  vmovaps xmm5, [rsp+0x50]
000073baab9dc80a  vmovaps xmm6, [rsp+0x60]
000073baab9dc810  vmovaps xmm7, [rsp+0x70]
000073baab9dc816  vmovaps xmm8, [rsp+0x80]
000073baab9dc81f  vmovaps xmm9, [rsp+0x90]
000073baab9dc828  vmovaps xmm10, [rsp+0xA0]
000073baab9dc831  vmovaps xmm11, [rsp+0xB0]
000073baab9dc83a  vmovaps xmm12, [rsp+0xC0]
000073baab9dc843  vmovaps xmm13, [rsp+0xD0]
000073baab9dc84c  vmovaps xmm15, [rsp+0xE0]
000073baab9dc855  add rsp, 0xF0
000073baab9dc85c  pop r11
000073baab9dc85e  pop r10
000073baab9dc860  pop r9
000073baab9dc862  pop r8
000073baab9dc864  pop rsi
000073baab9dc865  pop rdi
000073baab9dc866  pop rdx
000073baab9dc867  pop rcx
000073baab9dc868  pop rax
000073baab9dc869  add rsp, 0x08
000073baab9dc86d  jmp 0x000073BAAB9D9445
000073baab9dc872  sub rsp, 0x08
000073baab9dc876  push rax
000073baab9dc877  push rcx
000073baab9dc878  push rdx
000073baab9dc879  push rdi
000073baab9dc87a  push rsi
000073baab9dc87b  push r8
000073baab9dc87d  push r9
000073baab9dc87f  push r10
000073baab9dc881  push r11
000073baab9dc883  sub rsp, 0xF0
000073baab9dc88a  vmovaps [rsp], xmm0
000073baab9dc88f  vmovaps [rsp+0x10], xmm1
000073baab9dc895  vmovaps [rsp+0x20], xmm2
000073baab9dc89b  vmovaps [rsp+0x30], xmm3
000073baab9dc8a1  vmovaps [rsp+0x40], xmm5
000073baab9dc8a7  vmovaps [rsp+0x50], xmm6
000073baab9dc8ad  vmovaps [rsp+0x60], xmm7
000073baab9dc8b3  vmovaps [rsp+0x70], xmm8
000073baab9dc8b9  vmovaps [rsp+0x80], xmm9
000073baab9dc8c2  vmovaps [rsp+0x90], xmm10
000073baab9dc8cb  vmovaps [rsp+0xA0], xmm11
000073baab9dc8d4  vmovaps [rsp+0xB0], xmm12
000073baab9dc8dd  vmovaps [rsp+0xC0], xmm13
000073baab9dc8e6  vmovaps [rsp+0xD0], xmm14
000073baab9dc8ef  vmovaps [rsp+0xE0], xmm15
000073baab9dc8f8  sub rsp, 0x30
000073baab9dc8fc  movaps [rsp], xmm4
000073baab9dc900  movaps [rsp+0x10], xmm13
000073baab9dc906  movaps [rsp+0x20], xmm8
000073baab9dc90c  lea rdi, [rsp]
000073baab9dc910  mov esi, 0x00
000073baab9dc915  mov rax, 0x5F3F1062D530
000073baab9dc91f  call rax
000073baab9dc921  movaps xmm4, [rsp]
000073baab9dc925  add rsp, 0x30
000073baab9dc929  vmovaps xmm0, [rsp]
000073baab9dc92e  vmovaps xmm1, [rsp+0x10]
000073baab9dc934  vmovaps xmm2, [rsp+0x20]
000073baab9dc93a  vmovaps xmm3, [rsp+0x30]
000073baab9dc940  vmovaps xmm5, [rsp+0x40]
000073baab9dc946  vmovaps xmm6, [rsp+0x50]
000073baab9dc94c  vmovaps xmm7, [rsp+0x60]
000073baab9dc952  vmovaps xmm8, [rsp+0x70]
000073baab9dc958  vmovaps xmm9, [rsp+0x80]
000073baab9dc961  vmovaps xmm10, [rsp+0x90]
000073baab9dc96a  vmovaps xmm11, [rsp+0xA0]
000073baab9dc973  vmovaps xmm12, [rsp+0xB0]
000073baab9dc97c  vmovaps xmm13, [rsp+0xC0]
000073baab9dc985  vmovaps xmm14, [rsp+0xD0]
000073baab9dc98e  vmovaps xmm15, [rsp+0xE0]
000073baab9dc997  add rsp, 0xF0
000073baab9dc99e  pop r11
000073baab9dc9a0  pop r10
000073baab9dc9a2  pop r9
000073baab9dc9a4  pop r8
000073baab9dc9a6  pop rsi
000073baab9dc9a7  pop rdi
000073baab9dc9a8  pop rdx
000073baab9dc9a9  pop rcx
000073baab9dc9aa  pop rax
000073baab9dc9ab  add rsp, 0x08
000073baab9dc9af  jmp 0x000073BAAB9D946A
000073baab9dc9b4  sub rsp, 0x08
000073baab9dc9b8  push rax
000073baab9dc9b9  push rcx
000073baab9dc9ba  push rdx
000073baab9dc9bb  push rdi
000073baab9dc9bc  push rsi
000073baab9dc9bd  push r8
000073baab9dc9bf  push r9
000073baab9dc9c1  push r10
000073baab9dc9c3  push r11
000073baab9dc9c5  sub rsp, 0xF0
000073baab9dc9cc  vmovaps [rsp], xmm0
000073baab9dc9d1  vmovaps [rsp+0x10], xmm1
000073baab9dc9d7  vmovaps [rsp+0x20], xmm2
000073baab9dc9dd  vmovaps [rsp+0x30], xmm3
000073baab9dc9e3  vmovaps [rsp+0x40], xmm4
000073baab9dc9e9  vmovaps [rsp+0x50], xmm5
000073baab9dc9ef  vmovaps [rsp+0x60], xmm6
000073baab9dc9f5  vmovaps [rsp+0x70], xmm7
000073baab9dc9fb  vmovaps [rsp+0x80], xmm8
000073baab9dca04  vmovaps [rsp+0x90], xmm9
000073baab9dca0d  vmovaps [rsp+0xA0], xmm10
000073baab9dca16  vmovaps [rsp+0xB0], xmm11
000073baab9dca1f  vmovaps [rsp+0xC0], xmm12
000073baab9dca28  vmovaps [rsp+0xD0], xmm14
000073baab9dca31  vmovaps [rsp+0xE0], xmm15
000073baab9dca3a  sub rsp, 0x30
000073baab9dca3e  movaps [rsp], xmm13
000073baab9dca43  movaps [rsp+0x10], xmm15
000073baab9dca49  movaps [rsp+0x20], xmm9
000073baab9dca4f  lea rdi, [rsp]
000073baab9dca53  mov esi, 0x00
000073baab9dca58  mov rax, 0x5F3F1062D530
000073baab9dca62  call rax
000073baab9dca64  movaps xmm13, [rsp]
000073baab9dca69  add rsp, 0x30
000073baab9dca6d  vmovaps xmm0, [rsp]
000073baab9dca72  vmovaps xmm1, [rsp+0x10]
000073baab9dca78  vmovaps xmm2, [rsp+0x20]
000073baab9dca7e  vmovaps xmm3, [rsp+0x30]
000073baab9dca84  vmovaps xmm4, [rsp+0x40]
000073baab9dca8a  vmovaps xmm5, [rsp+0x50]
000073baab9dca90  vmovaps xmm6, [rsp+0x60]
000073baab9dca96  vmovaps xmm7, [rsp+0x70]
000073baab9dca9c  vmovaps xmm8, [rsp+0x80]
000073baab9dcaa5  vmovaps xmm9, [rsp+0x90]
000073baab9dcaae  vmovaps xmm10, [rsp+0xA0]
000073baab9dcab7  vmovaps xmm11, [rsp+0xB0]
000073baab9dcac0  vmovaps xmm12, [rsp+0xC0]
000073baab9dcac9  vmovaps xmm14, [rsp+0xD0]
000073baab9dcad2  vmovaps xmm15, [rsp+0xE0]
000073baab9dcadb  add rsp, 0xF0
000073baab9dcae2  pop r11
000073baab9dcae4  pop r10
000073baab9dcae6  pop r9
000073baab9dcae8  pop r8
000073baab9dcaea  pop rsi
000073baab9dcaeb  pop rdi
000073baab9dcaec  pop rdx
000073baab9dcaed  pop rcx
000073baab9dcaee  pop rax
000073baab9dcaef  add rsp, 0x08
000073baab9dcaf3  jmp 0x000073BAAB9D9485
000073baab9dcaf8  sub rsp, 0x08
000073baab9dcafc  push rax
000073baab9dcafd  push rcx
000073baab9dcafe  push rdx
000073baab9dcaff  push rdi
000073baab9dcb00  push rsi
000073baab9dcb01  push r8
000073baab9dcb03  push r9
000073baab9dcb05  push r10
000073baab9dcb07  push r11
000073baab9dcb09  sub rsp, 0xF0
000073baab9dcb10  vmovaps [rsp], xmm0
000073baab9dcb15  vmovaps [rsp+0x10], xmm1
000073baab9dcb1b  vmovaps [rsp+0x20], xmm2
000073baab9dcb21  vmovaps [rsp+0x30], xmm3
000073baab9dcb27  vmovaps [rsp+0x40], xmm4
000073baab9dcb2d  vmovaps [rsp+0x50], xmm5
000073baab9dcb33  vmovaps [rsp+0x60], xmm6
000073baab9dcb39  vmovaps [rsp+0x70], xmm7
000073baab9dcb3f  vmovaps [rsp+0x80], xmm8
000073baab9dcb48  vmovaps [rsp+0x90], xmm9
000073baab9dcb51  vmovaps [rsp+0xA0], xmm10
000073baab9dcb5a  vmovaps [rsp+0xB0], xmm11
000073baab9dcb63  vmovaps [rsp+0xC0], xmm12
000073baab9dcb6c  vmovaps [rsp+0xD0], xmm13
000073baab9dcb75  vmovaps [rsp+0xE0], xmm14
000073baab9dcb7e  sub rsp, 0x30
000073baab9dcb82  movaps [rsp], xmm15
000073baab9dcb87  movaps [rsp+0x10], xmm1
000073baab9dcb8c  movaps [rsp+0x20], xmm5
000073baab9dcb91  lea rdi, [rsp]
000073baab9dcb95  mov esi, 0x00
000073baab9dcb9a  mov rax, 0x5F3F1062D530
000073baab9dcba4  call rax
000073baab9dcba6  movaps xmm15, [rsp]
000073baab9dcbab  add rsp, 0x30
000073baab9dcbaf  vmovaps xmm0, [rsp]
000073baab9dcbb4  vmovaps xmm1, [rsp+0x10]
000073baab9dcbba  vmovaps xmm2, [rsp+0x20]
000073baab9dcbc0  vmovaps xmm3, [rsp+0x30]
000073baab9dcbc6  vmovaps xmm4, [rsp+0x40]
000073baab9dcbcc  vmovaps xmm5, [rsp+0x50]
000073baab9dcbd2  vmovaps xmm6, [rsp+0x60]
000073baab9dcbd8  vmovaps xmm7, [rsp+0x70]
000073baab9dcbde  vmovaps xmm8, [rsp+0x80]
000073baab9dcbe7  vmovaps xmm9, [rsp+0x90]
000073baab9dcbf0  vmovaps xmm10, [rsp+0xA0]
000073baab9dcbf9  vmovaps xmm11, [rsp+0xB0]
000073baab9dcc02  vmovaps xmm12, [rsp+0xC0]
000073baab9dcc0b  vmovaps xmm13, [rsp+0xD0]
000073baab9dcc14  vmovaps xmm14, [rsp+0xE0]
000073baab9dcc1d  add rsp, 0xF0
000073baab9dcc24  pop r11
000073baab9dcc26  pop r10
000073baab9dcc28  pop r9
000073baab9dcc2a  pop r8
000073baab9dcc2c  pop rsi
000073baab9dcc2d  pop rdi
000073baab9dcc2e  pop rdx
000073baab9dcc2f  pop rcx
000073baab9dcc30  pop rax
000073baab9dcc31  add rsp, 0x08
000073baab9dcc35  jmp 0x000073BAAB9D94A0
000073baab9dcc3a  call 0x000073BAAB8D64F0
000073baab9dcc3f  jmp 0x000073BAAB9D94FB
000073baab9dcc44  sub rsp, 0x08
000073baab9dcc48  push rax
000073baab9dcc49  push rcx
000073baab9dcc4a  push rdx
000073baab9dcc4b  push rdi
000073baab9dcc4c  push rsi
000073baab9dcc4d  push r8
000073baab9dcc4f  push r9
000073baab9dcc51  push r10
000073baab9dcc53  push r11
000073baab9dcc55  sub rsp, 0xF0
000073baab9dcc5c  vmovaps [rsp], xmm0
000073baab9dcc61  vmovaps [rsp+0x10], xmm1
000073baab9dcc67  vmovaps [rsp+0x20], xmm2
000073baab9dcc6d  vmovaps [rsp+0x30], xmm3
000073baab9dcc73  vmovaps [rsp+0x40], xmm4
000073baab9dcc79  vmovaps [rsp+0x50], xmm5
000073baab9dcc7f  vmovaps [rsp+0x60], xmm6
000073baab9dcc85  vmovaps [rsp+0x70], xmm7
000073baab9dcc8b  vmovaps [rsp+0x80], xmm8
000073baab9dcc94  vmovaps [rsp+0x90], xmm10
000073baab9dcc9d  vmovaps [rsp+0xA0], xmm11
000073baab9dcca6  vmovaps [rsp+0xB0], xmm12
000073baab9dccaf  vmovaps [rsp+0xC0], xmm13
000073baab9dccb8  vmovaps [rsp+0xD0], xmm14
000073baab9dccc1  vmovaps [rsp+0xE0], xmm15
000073baab9dccca  sub rsp, 0x30
000073baab9dccce  movaps [rsp], xmm9
000073baab9dccd3  movaps [rsp+0x10], xmm8
000073baab9dccd9  movaps [rsp+0x20], xmm11
000073baab9dccdf  lea rdi, [rsp]
000073baab9dcce3  mov esi, 0x00
000073baab9dcce8  mov rax, 0x5F3F1062D530
000073baab9dccf2  call rax
000073baab9dccf4  movaps xmm9, [rsp]
000073baab9dccf9  add rsp, 0x30
000073baab9dccfd  vmovaps xmm0, [rsp]
000073baab9dcd02  vmovaps xmm1, [rsp+0x10]
000073baab9dcd08  vmovaps xmm2, [rsp+0x20]
000073baab9dcd0e  vmovaps xmm3, [rsp+0x30]
000073baab9dcd14  vmovaps xmm4, [rsp+0x40]
000073baab9dcd1a  vmovaps xmm5, [rsp+0x50]
000073baab9dcd20  vmovaps xmm6, [rsp+0x60]
000073baab9dcd26  vmovaps xmm7, [rsp+0x70]
000073baab9dcd2c  vmovaps xmm8, [rsp+0x80]
000073baab9dcd35  vmovaps xmm10, [rsp+0x90]
000073baab9dcd3e  vmovaps xmm11, [rsp+0xA0]
000073baab9dcd47  vmovaps xmm12, [rsp+0xB0]
000073baab9dcd50  vmovaps xmm13, [rsp+0xC0]
000073baab9dcd59  vmovaps xmm14, [rsp+0xD0]
000073baab9dcd62  vmovaps xmm15, [rsp+0xE0]
000073baab9dcd6b  add rsp, 0xF0
000073baab9dcd72  pop r11
000073baab9dcd74  pop r10
000073baab9dcd76  pop r9
000073baab9dcd78  pop r8
000073baab9dcd7a  pop rsi
000073baab9dcd7b  pop rdi
000073baab9dcd7c  pop rdx
000073baab9dcd7d  pop rcx
000073baab9dcd7e  pop rax
000073baab9dcd7f  add rsp, 0x08
000073baab9dcd83  jmp 0x000073BAAB9D9532
000073baab9dcd88  sub rsp, 0x08
000073baab9dcd8c  push rax
000073baab9dcd8d  push rcx
000073baab9dcd8e  push rdx
000073baab9dcd8f  push rdi
000073baab9dcd90  push rsi
000073baab9dcd91  push r8
000073baab9dcd93  push r9
000073baab9dcd95  push r10
000073baab9dcd97  push r11
000073baab9dcd99  sub rsp, 0xF0
000073baab9dcda0  vmovaps [rsp], xmm0
000073baab9dcda5  vmovaps [rsp+0x10], xmm1
000073baab9dcdab  vmovaps [rsp+0x20], xmm2
000073baab9dcdb1  vmovaps [rsp+0x30], xmm3
000073baab9dcdb7  vmovaps [rsp+0x40], xmm4
000073baab9dcdbd  vmovaps [rsp+0x50], xmm5
000073baab9dcdc3  vmovaps [rsp+0x60], xmm6
000073baab9dcdc9  vmovaps [rsp+0x70], xmm7
000073baab9dcdcf  vmovaps [rsp+0x80], xmm8
000073baab9dcdd8  vmovaps [rsp+0x90], xmm9
000073baab9dcde1  vmovaps [rsp+0xA0], xmm10
000073baab9dcdea  vmovaps [rsp+0xB0], xmm12
000073baab9dcdf3  vmovaps [rsp+0xC0], xmm13
000073baab9dcdfc  vmovaps [rsp+0xD0], xmm14
000073baab9dce05  vmovaps [rsp+0xE0], xmm15
000073baab9dce0e  sub rsp, 0x30
000073baab9dce12  movaps [rsp], xmm11
000073baab9dce17  movaps [rsp+0x10], xmm10
000073baab9dce1d  movaps [rsp+0x20], xmm6
000073baab9dce22  lea rdi, [rsp]
000073baab9dce26  mov esi, 0x00
000073baab9dce2b  mov rax, 0x5F3F1062D530
000073baab9dce35  call rax
000073baab9dce37  movaps xmm11, [rsp]
000073baab9dce3c  add rsp, 0x30
000073baab9dce40  vmovaps xmm0, [rsp]
000073baab9dce45  vmovaps xmm1, [rsp+0x10]
000073baab9dce4b  vmovaps xmm2, [rsp+0x20]
000073baab9dce51  vmovaps xmm3, [rsp+0x30]
000073baab9dce57  vmovaps xmm4, [rsp+0x40]
000073baab9dce5d  vmovaps xmm5, [rsp+0x50]
000073baab9dce63  vmovaps xmm6, [rsp+0x60]
000073baab9dce69  vmovaps xmm7, [rsp+0x70]
000073baab9dce6f  vmovaps xmm8, [rsp+0x80]
000073baab9dce78  vmovaps xmm9, [rsp+0x90]
000073baab9dce81  vmovaps xmm10, [rsp+0xA0]
000073baab9dce8a  vmovaps xmm12, [rsp+0xB0]
000073baab9dce93  vmovaps xmm13, [rsp+0xC0]
000073baab9dce9c  vmovaps xmm14, [rsp+0xD0]
000073baab9dcea5  vmovaps xmm15, [rsp+0xE0]
000073baab9dceae  add rsp, 0xF0
000073baab9dceb5  pop r11
000073baab9dceb7  pop r10
000073baab9dceb9  pop r9
000073baab9dcebb  pop r8
000073baab9dcebd  pop rsi
000073baab9dcebe  pop rdi
000073baab9dcebf  pop rdx
000073baab9dcec0  pop rcx
000073baab9dcec1  pop rax
000073baab9dcec2  add rsp, 0x08
000073baab9dcec6  jmp 0x000073BAAB9D954D
000073baab9dcecb  sub rsp, 0x08
000073baab9dcecf  push rax
000073baab9dced0  push rcx
000073baab9dced1  push rdx
000073baab9dced2  push rdi
000073baab9dced3  push rsi
000073baab9dced4  push r8
000073baab9dced6  push r9
000073baab9dced8  push r10
000073baab9dceda  push r11
000073baab9dcedc  sub rsp, 0xF0
000073baab9dcee3  vmovaps [rsp], xmm0
000073baab9dcee8  vmovaps [rsp+0x10], xmm1
000073baab9dceee  vmovaps [rsp+0x20], xmm2
000073baab9dcef4  vmovaps [rsp+0x30], xmm3
000073baab9dcefa  vmovaps [rsp+0x40], xmm4
000073baab9dcf00  vmovaps [rsp+0x50], xmm5
000073baab9dcf06  vmovaps [rsp+0x60], xmm6
000073baab9dcf0c  vmovaps [rsp+0x70], xmm7
000073baab9dcf12  vmovaps [rsp+0x80], xmm8
000073baab9dcf1b  vmovaps [rsp+0x90], xmm9
000073baab9dcf24  vmovaps [rsp+0xA0], xmm11
000073baab9dcf2d  vmovaps [rsp+0xB0], xmm12
000073baab9dcf36  vmovaps [rsp+0xC0], xmm13
000073baab9dcf3f  vmovaps [rsp+0xD0], xmm14
000073baab9dcf48  vmovaps [rsp+0xE0], xmm15
000073baab9dcf51  sub rsp, 0x30
000073baab9dcf55  movaps [rsp], xmm10
000073baab9dcf5a  movaps [rsp+0x10], xmm14
000073baab9dcf60  movaps [rsp+0x20], xmm4
000073baab9dcf65  lea rdi, [rsp]
000073baab9dcf69  mov esi, 0x00
000073baab9dcf6e  mov rax, 0x5F3F1062D530
000073baab9dcf78  call rax
000073baab9dcf7a  movaps xmm10, [rsp]
000073baab9dcf7f  add rsp, 0x30
000073baab9dcf83  vmovaps xmm0, [rsp]
000073baab9dcf88  vmovaps xmm1, [rsp+0x10]
000073baab9dcf8e  vmovaps xmm2, [rsp+0x20]
000073baab9dcf94  vmovaps xmm3, [rsp+0x30]
000073baab9dcf9a  vmovaps xmm4, [rsp+0x40]
000073baab9dcfa0  vmovaps xmm5, [rsp+0x50]
000073baab9dcfa6  vmovaps xmm6, [rsp+0x60]
000073baab9dcfac  vmovaps xmm7, [rsp+0x70]
000073baab9dcfb2  vmovaps xmm8, [rsp+0x80]
000073baab9dcfbb  vmovaps xmm9, [rsp+0x90]
000073baab9dcfc4  vmovaps xmm11, [rsp+0xA0]
000073baab9dcfcd  vmovaps xmm12, [rsp+0xB0]
000073baab9dcfd6  vmovaps xmm13, [rsp+0xC0]
000073baab9dcfdf  vmovaps xmm14, [rsp+0xD0]
000073baab9dcfe8  vmovaps xmm15, [rsp+0xE0]
000073baab9dcff1  add rsp, 0xF0
000073baab9dcff8  pop r11
000073baab9dcffa  pop r10
000073baab9dcffc  pop r9
000073baab9dcffe  pop r8
000073baab9dd000  pop rsi
000073baab9dd001  pop rdi
000073baab9dd002  pop rdx
000073baab9dd003  pop rcx
000073baab9dd004  pop rax
000073baab9dd005  add rsp, 0x08
000073baab9dd009  jmp 0x000073BAAB9D9568
000073baab9dd00e  sub rsp, 0x08
000073baab9dd012  push rax
000073baab9dd013  push rcx
000073baab9dd014  push rdx
000073baab9dd015  push rdi
000073baab9dd016  push rsi
000073baab9dd017  push r8
000073baab9dd019  push r9
000073baab9dd01b  push r10
000073baab9dd01d  push r11
000073baab9dd01f  sub rsp, 0xF0
000073baab9dd026  vmovaps [rsp], xmm0
000073baab9dd02b  vmovaps [rsp+0x10], xmm1
000073baab9dd031  vmovaps [rsp+0x20], xmm2
000073baab9dd037  vmovaps [rsp+0x30], xmm3
000073baab9dd03d  vmovaps [rsp+0x40], xmm4
000073baab9dd043  vmovaps [rsp+0x50], xmm5
000073baab9dd049  vmovaps [rsp+0x60], xmm6
000073baab9dd04f  vmovaps [rsp+0x70], xmm7
000073baab9dd055  vmovaps [rsp+0x80], xmm9
000073baab9dd05e  vmovaps [rsp+0x90], xmm10
000073baab9dd067  vmovaps [rsp+0xA0], xmm11
000073baab9dd070  vmovaps [rsp+0xB0], xmm12
000073baab9dd079  vmovaps [rsp+0xC0], xmm13
000073baab9dd082  vmovaps [rsp+0xD0], xmm14
000073baab9dd08b  vmovaps [rsp+0xE0], xmm15
000073baab9dd094  sub rsp, 0x30
000073baab9dd098  movaps [rsp], xmm8
000073baab9dd09d  movaps [rsp+0x10], xmm1
000073baab9dd0a2  movaps [rsp+0x20], xmm14
000073baab9dd0a8  lea rdi, [rsp]
000073baab9dd0ac  mov esi, 0x00
000073baab9dd0b1  mov rax, 0x5F3F1062D530
000073baab9dd0bb  call rax
000073baab9dd0bd  movaps xmm8, [rsp]
000073baab9dd0c2  add rsp, 0x30
000073baab9dd0c6  vmovaps xmm0, [rsp]
000073baab9dd0cb  vmovaps xmm1, [rsp+0x10]
000073baab9dd0d1  vmovaps xmm2, [rsp+0x20]
000073baab9dd0d7  vmovaps xmm3, [rsp+0x30]
000073baab9dd0dd  vmovaps xmm4, [rsp+0x40]
000073baab9dd0e3  vmovaps xmm5, [rsp+0x50]
000073baab9dd0e9  vmovaps xmm6, [rsp+0x60]
000073baab9dd0ef  vmovaps xmm7, [rsp+0x70]
000073baab9dd0f5  vmovaps xmm9, [rsp+0x80]
000073baab9dd0fe  vmovaps xmm10, [rsp+0x90]
000073baab9dd107  vmovaps xmm11, [rsp+0xA0]
000073baab9dd110  vmovaps xmm12, [rsp+0xB0]
000073baab9dd119  vmovaps xmm13, [rsp+0xC0]
000073baab9dd122  vmovaps xmm14, [rsp+0xD0]
000073baab9dd12b  vmovaps xmm15, [rsp+0xE0]
000073baab9dd134  add rsp, 0xF0
000073baab9dd13b  pop r11
000073baab9dd13d  pop r10
000073baab9dd13f  pop r9
000073baab9dd141  pop r8
000073baab9dd143  pop rsi
000073baab9dd144  pop rdi
000073baab9dd145  pop rdx
000073baab9dd146  pop rcx
000073baab9dd147  pop rax
000073baab9dd148  add rsp, 0x08
000073baab9dd14c  jmp 0x000073BAAB9D958E
000073baab9dd151  sub rsp, 0x08
000073baab9dd155  push rax
000073baab9dd156  push rcx
000073baab9dd157  push rdx
000073baab9dd158  push rdi
000073baab9dd159  push rsi
000073baab9dd15a  push r8
000073baab9dd15c  push r9
000073baab9dd15e  push r10
000073baab9dd160  push r11
000073baab9dd162  sub rsp, 0xF0
000073baab9dd169  vmovaps [rsp], xmm0
000073baab9dd16e  vmovaps [rsp+0x10], xmm1
000073baab9dd174  vmovaps [rsp+0x20], xmm2
000073baab9dd17a  vmovaps [rsp+0x30], xmm3
000073baab9dd180  vmovaps [rsp+0x40], xmm4
000073baab9dd186  vmovaps [rsp+0x50], xmm5
000073baab9dd18c  vmovaps [rsp+0x60], xmm7
000073baab9dd192  vmovaps [rsp+0x70], xmm8
000073baab9dd198  vmovaps [rsp+0x80], xmm9
000073baab9dd1a1  vmovaps [rsp+0x90], xmm10
000073baab9dd1aa  vmovaps [rsp+0xA0], xmm11
000073baab9dd1b3  vmovaps [rsp+0xB0], xmm12
000073baab9dd1bc  vmovaps [rsp+0xC0], xmm13
000073baab9dd1c5  vmovaps [rsp+0xD0], xmm14
000073baab9dd1ce  vmovaps [rsp+0xE0], xmm15
000073baab9dd1d7  sub rsp, 0x30
000073baab9dd1db  movaps [rsp], xmm6
000073baab9dd1df  movaps [rsp+0x10], xmm1
000073baab9dd1e4  movaps [rsp+0x20], xmm14
000073baab9dd1ea  lea rdi, [rsp]
000073baab9dd1ee  mov esi, 0x00
000073baab9dd1f3  mov rax, 0x5F3F1062D530
000073baab9dd1fd  call rax
000073baab9dd1ff  movaps xmm6, [rsp]
000073baab9dd203  add rsp, 0x30
000073baab9dd207  vmovaps xmm0, [rsp]
000073baab9dd20c  vmovaps xmm1, [rsp+0x10]
000073baab9dd212  vmovaps xmm2, [rsp+0x20]
000073baab9dd218  vmovaps xmm3, [rsp+0x30]
000073baab9dd21e  vmovaps xmm4, [rsp+0x40]
000073baab9dd224  vmovaps xmm5, [rsp+0x50]
000073baab9dd22a  vmovaps xmm7, [rsp+0x60]
000073baab9dd230  vmovaps xmm8, [rsp+0x70]
000073baab9dd236  vmovaps xmm9, [rsp+0x80]
000073baab9dd23f  vmovaps xmm10, [rsp+0x90]
000073baab9dd248  vmovaps xmm11, [rsp+0xA0]
000073baab9dd251  vmovaps xmm12, [rsp+0xB0]
000073baab9dd25a  vmovaps xmm13, [rsp+0xC0]
000073baab9dd263  vmovaps xmm14, [rsp+0xD0]
000073baab9dd26c  vmovaps xmm15, [rsp+0xE0]
000073baab9dd275  add rsp, 0xF0
000073baab9dd27c  pop r11
000073baab9dd27e  pop r10
000073baab9dd280  pop r9
000073baab9dd282  pop r8
000073baab9dd284  pop rsi
000073baab9dd285  pop rdi
000073baab9dd286  pop rdx
000073baab9dd287  pop rcx
000073baab9dd288  pop rax
000073baab9dd289  add rsp, 0x08
000073baab9dd28d  jmp 0x000073BAAB9D95BA
000073baab9dd292  sub rsp, 0x08
000073baab9dd296  push rax
000073baab9dd297  push rcx
000073baab9dd298  push rdx
000073baab9dd299  push rdi
000073baab9dd29a  push rsi
000073baab9dd29b  push r8
000073baab9dd29d  push r9
000073baab9dd29f  push r10
000073baab9dd2a1  push r11
000073baab9dd2a3  sub rsp, 0xF0
000073baab9dd2aa  vmovaps [rsp], xmm0
000073baab9dd2af  vmovaps [rsp+0x10], xmm1
000073baab9dd2b5  vmovaps [rsp+0x20], xmm2
000073baab9dd2bb  vmovaps [rsp+0x30], xmm3
000073baab9dd2c1  vmovaps [rsp+0x40], xmm4
000073baab9dd2c7  vmovaps [rsp+0x50], xmm5
000073baab9dd2cd  vmovaps [rsp+0x60], xmm6
000073baab9dd2d3  vmovaps [rsp+0x70], xmm7
000073baab9dd2d9  vmovaps [rsp+0x80], xmm8
000073baab9dd2e2  vmovaps [rsp+0x90], xmm9
000073baab9dd2eb  vmovaps [rsp+0xA0], xmm10
000073baab9dd2f4  vmovaps [rsp+0xB0], xmm11
000073baab9dd2fd  vmovaps [rsp+0xC0], xmm12
000073baab9dd306  vmovaps [rsp+0xD0], xmm13
000073baab9dd30f  vmovaps [rsp+0xE0], xmm15
000073baab9dd318  sub rsp, 0x30
000073baab9dd31c  movaps [rsp], xmm14
000073baab9dd321  movaps [rsp+0x10], xmm12
000073baab9dd327  movaps [rsp+0x20], xmm1
000073baab9dd32c  lea rdi, [rsp]
000073baab9dd330  mov esi, 0x00
000073baab9dd335  mov rax, 0x5F3F1062D530
000073baab9dd33f  call rax
000073baab9dd341  movaps xmm14, [rsp]
000073baab9dd346  add rsp, 0x30
000073baab9dd34a  vmovaps xmm0, [rsp]
000073baab9dd34f  vmovaps xmm1, [rsp+0x10]
000073baab9dd355  vmovaps xmm2, [rsp+0x20]
000073baab9dd35b  vmovaps xmm3, [rsp+0x30]
000073baab9dd361  vmovaps xmm4, [rsp+0x40]
000073baab9dd367  vmovaps xmm5, [rsp+0x50]
000073baab9dd36d  vmovaps xmm6, [rsp+0x60]
000073baab9dd373  vmovaps xmm7, [rsp+0x70]
000073baab9dd379  vmovaps xmm8, [rsp+0x80]
000073baab9dd382  vmovaps xmm9, [rsp+0x90]
000073baab9dd38b  vmovaps xmm10, [rsp+0xA0]
000073baab9dd394  vmovaps xmm11, [rsp+0xB0]
000073baab9dd39d  vmovaps xmm12, [rsp+0xC0]
000073baab9dd3a6  vmovaps xmm13, [rsp+0xD0]
000073baab9dd3af  vmovaps xmm15, [rsp+0xE0]
000073baab9dd3b8  add rsp, 0xF0
000073baab9dd3bf  pop r11
000073baab9dd3c1  pop r10
000073baab9dd3c3  pop r9
000073baab9dd3c5  pop r8
000073baab9dd3c7  pop rsi
000073baab9dd3c8  pop rdi
000073baab9dd3c9  pop rdx
000073baab9dd3ca  pop rcx
000073baab9dd3cb  pop rax
000073baab9dd3cc  add rsp, 0x08
000073baab9dd3d0  jmp 0x000073BAAB9D95E0
000073baab9dd3d5  sub rsp, 0x08
000073baab9dd3d9  push rax
000073baab9dd3da  push rcx
000073baab9dd3db  push rdx
000073baab9dd3dc  push rdi
000073baab9dd3dd  push rsi
000073baab9dd3de  push r8
000073baab9dd3e0  push r9
000073baab9dd3e2  push r10
000073baab9dd3e4  push r11
000073baab9dd3e6  sub rsp, 0xF0
000073baab9dd3ed  vmovaps [rsp], xmm0
000073baab9dd3f2  vmovaps [rsp+0x10], xmm2
000073baab9dd3f8  vmovaps [rsp+0x20], xmm3
000073baab9dd3fe  vmovaps [rsp+0x30], xmm4
000073baab9dd404  vmovaps [rsp+0x40], xmm5
000073baab9dd40a  vmovaps [rsp+0x50], xmm6
000073baab9dd410  vmovaps [rsp+0x60], xmm7
000073baab9dd416  vmovaps [rsp+0x70], xmm8
000073baab9dd41c  vmovaps [rsp+0x80], xmm9
000073baab9dd425  vmovaps [rsp+0x90], xmm10
000073baab9dd42e  vmovaps [rsp+0xA0], xmm11
000073baab9dd437  vmovaps [rsp+0xB0], xmm12
000073baab9dd440  vmovaps [rsp+0xC0], xmm13
000073baab9dd449  vmovaps [rsp+0xD0], xmm14
000073baab9dd452  vmovaps [rsp+0xE0], xmm15
000073baab9dd45b  sub rsp, 0x30
000073baab9dd45f  movaps [rsp], xmm1
000073baab9dd463  movaps [rsp+0x10], xmm13
000073baab9dd469  movaps [rsp+0x20], xmm9
000073baab9dd46f  lea rdi, [rsp]
000073baab9dd473  mov esi, 0x00
000073baab9dd478  mov rax, 0x5F3F1062D530
000073baab9dd482  call rax
000073baab9dd484  movaps xmm1, [rsp]
000073baab9dd488  add rsp, 0x30
000073baab9dd48c  vmovaps xmm0, [rsp]
000073baab9dd491  vmovaps xmm2, [rsp+0x10]
000073baab9dd497  vmovaps xmm3, [rsp+0x20]
000073baab9dd49d  vmovaps xmm4, [rsp+0x30]
000073baab9dd4a3  vmovaps xmm5, [rsp+0x40]
000073baab9dd4a9  vmovaps xmm6, [rsp+0x50]
000073baab9dd4af  vmovaps xmm7, [rsp+0x60]
000073baab9dd4b5  vmovaps xmm8, [rsp+0x70]
000073baab9dd4bb  vmovaps xmm9, [rsp+0x80]
000073baab9dd4c4  vmovaps xmm10, [rsp+0x90]
000073baab9dd4cd  vmovaps xmm11, [rsp+0xA0]
000073baab9dd4d6  vmovaps xmm12, [rsp+0xB0]
000073baab9dd4df  vmovaps xmm13, [rsp+0xC0]
000073baab9dd4e8  vmovaps xmm14, [rsp+0xD0]
000073baab9dd4f1  vmovaps xmm15, [rsp+0xE0]
000073baab9dd4fa  add rsp, 0xF0
000073baab9dd501  pop r11
000073baab9dd503  pop r10
000073baab9dd505  pop r9
000073baab9dd507  pop r8
000073baab9dd509  pop rsi
000073baab9dd50a  pop rdi
000073baab9dd50b  pop rdx
000073baab9dd50c  pop rcx
000073baab9dd50d  pop rax
000073baab9dd50e  add rsp, 0x08
000073baab9dd512  jmp 0x000073BAAB9D95FA
000073baab9dd517  sub rsp, 0x08
000073baab9dd51b  push rax
000073baab9dd51c  push rcx
000073baab9dd51d  push rdx
000073baab9dd51e  push rdi
000073baab9dd51f  push rsi
000073baab9dd520  push r8
000073baab9dd522  push r9
000073baab9dd524  push r10
000073baab9dd526  push r11
000073baab9dd528  sub rsp, 0xF0
000073baab9dd52f  vmovaps [rsp], xmm0
000073baab9dd534  vmovaps [rsp+0x10], xmm1
000073baab9dd53a  vmovaps [rsp+0x20], xmm2
000073baab9dd540  vmovaps [rsp+0x30], xmm3
000073baab9dd546  vmovaps [rsp+0x40], xmm4
000073baab9dd54c  vmovaps [rsp+0x50], xmm5
000073baab9dd552  vmovaps [rsp+0x60], xmm6
000073baab9dd558  vmovaps [rsp+0x70], xmm7
000073baab9dd55e  vmovaps [rsp+0x80], xmm8
000073baab9dd567  vmovaps [rsp+0x90], xmm9
000073baab9dd570  vmovaps [rsp+0xA0], xmm10
000073baab9dd579  vmovaps [rsp+0xB0], xmm11
000073baab9dd582  vmovaps [rsp+0xC0], xmm13
000073baab9dd58b  vmovaps [rsp+0xD0], xmm14
000073baab9dd594  vmovaps [rsp+0xE0], xmm15
000073baab9dd59d  sub rsp, 0x30
000073baab9dd5a1  movaps [rsp], xmm12
000073baab9dd5a6  movaps [rsp+0x10], xmm7
000073baab9dd5ab  movaps [rsp+0x20], xmm13
000073baab9dd5b1  lea rdi, [rsp]
000073baab9dd5b5  mov esi, 0x00
000073baab9dd5ba  mov rax, 0x5F3F1062D530
000073baab9dd5c4  call rax
000073baab9dd5c6  movaps xmm12, [rsp]
000073baab9dd5cb  add rsp, 0x30
000073baab9dd5cf  vmovaps xmm0, [rsp]
000073baab9dd5d4  vmovaps xmm1, [rsp+0x10]
000073baab9dd5da  vmovaps xmm2, [rsp+0x20]
000073baab9dd5e0  vmovaps xmm3, [rsp+0x30]
000073baab9dd5e6  vmovaps xmm4, [rsp+0x40]
000073baab9dd5ec  vmovaps xmm5, [rsp+0x50]
000073baab9dd5f2  vmovaps xmm6, [rsp+0x60]
000073baab9dd5f8  vmovaps xmm7, [rsp+0x70]
000073baab9dd5fe  vmovaps xmm8, [rsp+0x80]
000073baab9dd607  vmovaps xmm9, [rsp+0x90]
000073baab9dd610  vmovaps xmm10, [rsp+0xA0]
000073baab9dd619  vmovaps xmm11, [rsp+0xB0]
000073baab9dd622  vmovaps xmm13, [rsp+0xC0]
000073baab9dd62b  vmovaps xmm14, [rsp+0xD0]
000073baab9dd634  vmovaps xmm15, [rsp+0xE0]
000073baab9dd63d  add rsp, 0xF0
000073baab9dd644  pop r11
000073baab9dd646  pop r10
000073baab9dd648  pop r9
000073baab9dd64a  pop r8
000073baab9dd64c  pop rsi
000073baab9dd64d  pop rdi
000073baab9dd64e  pop rdx
000073baab9dd64f  pop rcx
000073baab9dd650  pop rax
000073baab9dd651  add rsp, 0x08
000073baab9dd655  jmp 0x000073BAAB9D9621
000073baab9dd65a  sub rsp, 0x08
000073baab9dd65e  push rax
000073baab9dd65f  push rcx
000073baab9dd660  push rdx
000073baab9dd661  push rdi
000073baab9dd662  push rsi
000073baab9dd663  push r8
000073baab9dd665  push r9
000073baab9dd667  push r10
000073baab9dd669  push r11
000073baab9dd66b  sub rsp, 0xF0
000073baab9dd672  vmovaps [rsp], xmm0
000073baab9dd677  vmovaps [rsp+0x10], xmm1
000073baab9dd67d  vmovaps [rsp+0x20], xmm2
000073baab9dd683  vmovaps [rsp+0x30], xmm3
000073baab9dd689  vmovaps [rsp+0x40], xmm4
000073baab9dd68f  vmovaps [rsp+0x50], xmm5
000073baab9dd695  vmovaps [rsp+0x60], xmm6
000073baab9dd69b  vmovaps [rsp+0x70], xmm7
000073baab9dd6a1  vmovaps [rsp+0x80], xmm8
000073baab9dd6aa  vmovaps [rsp+0x90], xmm9
000073baab9dd6b3  vmovaps [rsp+0xA0], xmm10
000073baab9dd6bc  vmovaps [rsp+0xB0], xmm11
000073baab9dd6c5  vmovaps [rsp+0xC0], xmm12
000073baab9dd6ce  vmovaps [rsp+0xD0], xmm14
000073baab9dd6d7  vmovaps [rsp+0xE0], xmm15
000073baab9dd6e0  sub rsp, 0x30
000073baab9dd6e4  movaps [rsp], xmm13
000073baab9dd6e9  movaps [rsp+0x10], xmm15
000073baab9dd6ef  movaps [rsp+0x20], xmm8
000073baab9dd6f5  lea rdi, [rsp]
000073baab9dd6f9  mov esi, 0x00
000073baab9dd6fe  mov rax, 0x5F3F1062D530
000073baab9dd708  call rax
000073baab9dd70a  movaps xmm13, [rsp]
000073baab9dd70f  add rsp, 0x30
000073baab9dd713  vmovaps xmm0, [rsp]
000073baab9dd718  vmovaps xmm1, [rsp+0x10]
000073baab9dd71e  vmovaps xmm2, [rsp+0x20]
000073baab9dd724  vmovaps xmm3, [rsp+0x30]
000073baab9dd72a  vmovaps xmm4, [rsp+0x40]
000073baab9dd730  vmovaps xmm5, [rsp+0x50]
000073baab9dd736  vmovaps xmm6, [rsp+0x60]
000073baab9dd73c  vmovaps xmm7, [rsp+0x70]
000073baab9dd742  vmovaps xmm8, [rsp+0x80]
000073baab9dd74b  vmovaps xmm9, [rsp+0x90]
000073baab9dd754  vmovaps xmm10, [rsp+0xA0]
000073baab9dd75d  vmovaps xmm11, [rsp+0xB0]
000073baab9dd766  vmovaps xmm12, [rsp+0xC0]
000073baab9dd76f  vmovaps xmm14, [rsp+0xD0]
000073baab9dd778  vmovaps xmm15, [rsp+0xE0]
000073baab9dd781  add rsp, 0xF0
000073baab9dd788  pop r11
000073baab9dd78a  pop r10
000073baab9dd78c  pop r9
000073baab9dd78e  pop r8
000073baab9dd790  pop rsi
000073baab9dd791  pop rdi
000073baab9dd792  pop rdx
000073baab9dd793  pop rcx
000073baab9dd794  pop rax
000073baab9dd795  add rsp, 0x08
000073baab9dd799  jmp 0x000073BAAB9D963C
000073baab9dd79e  sub rsp, 0x08
000073baab9dd7a2  push rax
000073baab9dd7a3  push rcx
000073baab9dd7a4  push rdx
000073baab9dd7a5  push rdi
000073baab9dd7a6  push rsi
000073baab9dd7a7  push r8
000073baab9dd7a9  push r9
000073baab9dd7ab  push r10
000073baab9dd7ad  push r11
000073baab9dd7af  sub rsp, 0xF0
000073baab9dd7b6  vmovaps [rsp], xmm0
000073baab9dd7bb  vmovaps [rsp+0x10], xmm1
000073baab9dd7c1  vmovaps [rsp+0x20], xmm2
000073baab9dd7c7  vmovaps [rsp+0x30], xmm3
000073baab9dd7cd  vmovaps [rsp+0x40], xmm4
000073baab9dd7d3  vmovaps [rsp+0x50], xmm5
000073baab9dd7d9  vmovaps [rsp+0x60], xmm6
000073baab9dd7df  vmovaps [rsp+0x70], xmm7
000073baab9dd7e5  vmovaps [rsp+0x80], xmm9
000073baab9dd7ee  vmovaps [rsp+0x90], xmm10
000073baab9dd7f7  vmovaps [rsp+0xA0], xmm11
000073baab9dd800  vmovaps [rsp+0xB0], xmm12
000073baab9dd809  vmovaps [rsp+0xC0], xmm13
000073baab9dd812  vmovaps [rsp+0xD0], xmm14
000073baab9dd81b  vmovaps [rsp+0xE0], xmm15
000073baab9dd824  sub rsp, 0x30
000073baab9dd828  movaps [rsp], xmm8
000073baab9dd82d  movaps [rsp+0x10], xmm15
000073baab9dd833  movaps [rsp+0x20], xmm9
000073baab9dd839  lea rdi, [rsp]
000073baab9dd83d  mov esi, 0x00
000073baab9dd842  mov rax, 0x5F3F1062D530
000073baab9dd84c  call rax
000073baab9dd84e  movaps xmm8, [rsp]
000073baab9dd853  add rsp, 0x30
000073baab9dd857  vmovaps xmm0, [rsp]
000073baab9dd85c  vmovaps xmm1, [rsp+0x10]
000073baab9dd862  vmovaps xmm2, [rsp+0x20]
000073baab9dd868  vmovaps xmm3, [rsp+0x30]
000073baab9dd86e  vmovaps xmm4, [rsp+0x40]
000073baab9dd874  vmovaps xmm5, [rsp+0x50]
000073baab9dd87a  vmovaps xmm6, [rsp+0x60]
000073baab9dd880  vmovaps xmm7, [rsp+0x70]
000073baab9dd886  vmovaps xmm9, [rsp+0x80]
000073baab9dd88f  vmovaps xmm10, [rsp+0x90]
000073baab9dd898  vmovaps xmm11, [rsp+0xA0]
000073baab9dd8a1  vmovaps xmm12, [rsp+0xB0]
000073baab9dd8aa  vmovaps xmm13, [rsp+0xC0]
000073baab9dd8b3  vmovaps xmm14, [rsp+0xD0]
000073baab9dd8bc  vmovaps xmm15, [rsp+0xE0]
000073baab9dd8c5  add rsp, 0xF0
000073baab9dd8cc  pop r11
000073baab9dd8ce  pop r10
000073baab9dd8d0  pop r9
000073baab9dd8d2  pop r8
000073baab9dd8d4  pop rsi
000073baab9dd8d5  pop rdi
000073baab9dd8d6  pop rdx
000073baab9dd8d7  pop rcx
000073baab9dd8d8  pop rax
000073baab9dd8d9  add rsp, 0x08
000073baab9dd8dd  jmp 0x000073BAAB9D966A
000073baab9dd8e2  sub rsp, 0x08
000073baab9dd8e6  push rax
000073baab9dd8e7  push rcx
000073baab9dd8e8  push rdx
000073baab9dd8e9  push rdi
000073baab9dd8ea  push rsi
000073baab9dd8eb  push r8
000073baab9dd8ed  push r9
000073baab9dd8ef  push r10
000073baab9dd8f1  push r11
000073baab9dd8f3  sub rsp, 0xF0
000073baab9dd8fa  vmovaps [rsp], xmm0
000073baab9dd8ff  vmovaps [rsp+0x10], xmm1
000073baab9dd905  vmovaps [rsp+0x20], xmm2
000073baab9dd90b  vmovaps [rsp+0x30], xmm3
000073baab9dd911  vmovaps [rsp+0x40], xmm4
000073baab9dd917  vmovaps [rsp+0x50], xmm5
000073baab9dd91d  vmovaps [rsp+0x60], xmm6
000073baab9dd923  vmovaps [rsp+0x70], xmm7
000073baab9dd929  vmovaps [rsp+0x80], xmm8
000073baab9dd932  vmovaps [rsp+0x90], xmm9
000073baab9dd93b  vmovaps [rsp+0xA0], xmm10
000073baab9dd944  vmovaps [rsp+0xB0], xmm11
000073baab9dd94d  vmovaps [rsp+0xC0], xmm12
000073baab9dd956  vmovaps [rsp+0xD0], xmm13
000073baab9dd95f  vmovaps [rsp+0xE0], xmm14
000073baab9dd968  sub rsp, 0x30
000073baab9dd96c  movaps [rsp], xmm15
000073baab9dd971  movaps [rsp+0x10], xmm11
000073baab9dd977  movaps [rsp+0x20], xmm6
000073baab9dd97c  lea rdi, [rsp]
000073baab9dd980  mov esi, 0x00
000073baab9dd985  mov rax, 0x5F3F1062D530
000073baab9dd98f  call rax
000073baab9dd991  movaps xmm15, [rsp]
000073baab9dd996  add rsp, 0x30
000073baab9dd99a  vmovaps xmm0, [rsp]
000073baab9dd99f  vmovaps xmm1, [rsp+0x10]
000073baab9dd9a5  vmovaps xmm2, [rsp+0x20]
000073baab9dd9ab  vmovaps xmm3, [rsp+0x30]
000073baab9dd9b1  vmovaps xmm4, [rsp+0x40]
000073baab9dd9b7  vmovaps xmm5, [rsp+0x50]
000073baab9dd9bd  vmovaps xmm6, [rsp+0x60]
000073baab9dd9c3  vmovaps xmm7, [rsp+0x70]
000073baab9dd9c9  vmovaps xmm8, [rsp+0x80]
000073baab9dd9d2  vmovaps xmm9, [rsp+0x90]
000073baab9dd9db  vmovaps xmm10, [rsp+0xA0]
000073baab9dd9e4  vmovaps xmm11, [rsp+0xB0]
000073baab9dd9ed  vmovaps xmm12, [rsp+0xC0]
000073baab9dd9f6  vmovaps xmm13, [rsp+0xD0]
000073baab9dd9ff  vmovaps xmm14, [rsp+0xE0]
000073baab9dda08  add rsp, 0xF0
000073baab9dda0f  pop r11
000073baab9dda11  pop r10
000073baab9dda13  pop r9
000073baab9dda15  pop r8
000073baab9dda17  pop rsi
000073baab9dda18  pop rdi
000073baab9dda19  pop rdx
000073baab9dda1a  pop rcx
000073baab9dda1b  pop rax
000073baab9dda1c  add rsp, 0x08
000073baab9dda20  jmp 0x000073BAAB9D9685
000073baab9dda25  sub rsp, 0x08
000073baab9dda29  push rax
000073baab9dda2a  push rcx
000073baab9dda2b  push rdx
000073baab9dda2c  push rdi
000073baab9dda2d  push rsi
000073baab9dda2e  push r8
000073baab9dda30  push r9
000073baab9dda32  push r10
000073baab9dda34  push r11
000073baab9dda36  sub rsp, 0xF0
000073baab9dda3d  vmovaps [rsp], xmm0
000073baab9dda42  vmovaps [rsp+0x10], xmm1
000073baab9dda48  vmovaps [rsp+0x20], xmm2
000073baab9dda4e  vmovaps [rsp+0x30], xmm3
000073baab9dda54  vmovaps [rsp+0x40], xmm4
000073baab9dda5a  vmovaps [rsp+0x50], xmm5
000073baab9dda60  vmovaps [rsp+0x60], xmm6
000073baab9dda66  vmovaps [rsp+0x70], xmm8
000073baab9dda6c  vmovaps [rsp+0x80], xmm9
000073baab9dda75  vmovaps [rsp+0x90], xmm10
000073baab9dda7e  vmovaps [rsp+0xA0], xmm11
000073baab9dda87  vmovaps [rsp+0xB0], xmm12
000073baab9dda90  vmovaps [rsp+0xC0], xmm13
000073baab9dda99  vmovaps [rsp+0xD0], xmm14
000073baab9ddaa2  vmovaps [rsp+0xE0], xmm15
000073baab9ddaab  sub rsp, 0x30
000073baab9ddaaf  movaps [rsp], xmm7
000073baab9ddab3  movaps [rsp+0x10], xmm11
000073baab9ddab9  movaps [rsp+0x20], xmm9
000073baab9ddabf  lea rdi, [rsp]
000073baab9ddac3  mov esi, 0x00
000073baab9ddac8  mov rax, 0x5F3F1062D530
000073baab9ddad2  call rax
000073baab9ddad4  movaps xmm7, [rsp]
000073baab9ddad8  add rsp, 0x30
000073baab9ddadc  vmovaps xmm0, [rsp]
000073baab9ddae1  vmovaps xmm1, [rsp+0x10]
000073baab9ddae7  vmovaps xmm2, [rsp+0x20]
000073baab9ddaed  vmovaps xmm3, [rsp+0x30]
000073baab9ddaf3  vmovaps xmm4, [rsp+0x40]
000073baab9ddaf9  vmovaps xmm5, [rsp+0x50]
000073baab9ddaff  vmovaps xmm6, [rsp+0x60]
000073baab9ddb05  vmovaps xmm8, [rsp+0x70]
000073baab9ddb0b  vmovaps xmm9, [rsp+0x80]
000073baab9ddb14  vmovaps xmm10, [rsp+0x90]
000073baab9ddb1d  vmovaps xmm11, [rsp+0xA0]
000073baab9ddb26  vmovaps xmm12, [rsp+0xB0]
000073baab9ddb2f  vmovaps xmm13, [rsp+0xC0]
000073baab9ddb38  vmovaps xmm14, [rsp+0xD0]
000073baab9ddb41  vmovaps xmm15, [rsp+0xE0]
000073baab9ddb4a  add rsp, 0xF0
000073baab9ddb51  pop r11
000073baab9ddb53  pop r10
000073baab9ddb55  pop r9
000073baab9ddb57  pop r8
000073baab9ddb59  pop rsi
000073baab9ddb5a  pop rdi
000073baab9ddb5b  pop rdx
000073baab9ddb5c  pop rcx
000073baab9ddb5d  pop rax
000073baab9ddb5e  add rsp, 0x08
000073baab9ddb62  jmp 0x000073BAAB9D96B2
000073baab9ddb67  sub rsp, 0x08
000073baab9ddb6b  push rax
000073baab9ddb6c  push rcx
000073baab9ddb6d  push rdx
000073baab9ddb6e  push rdi
000073baab9ddb6f  push rsi
000073baab9ddb70  push r8
000073baab9ddb72  push r9
000073baab9ddb74  push r10
000073baab9ddb76  push r11
000073baab9ddb78  sub rsp, 0xF0
000073baab9ddb7f  vmovaps [rsp], xmm0
000073baab9ddb84  vmovaps [rsp+0x10], xmm1
000073baab9ddb8a  vmovaps [rsp+0x20], xmm2
000073baab9ddb90  vmovaps [rsp+0x30], xmm3
000073baab9ddb96  vmovaps [rsp+0x40], xmm4
000073baab9ddb9c  vmovaps [rsp+0x50], xmm5
000073baab9ddba2  vmovaps [rsp+0x60], xmm6
000073baab9ddba8  vmovaps [rsp+0x70], xmm7
000073baab9ddbae  vmovaps [rsp+0x80], xmm8
000073baab9ddbb7  vmovaps [rsp+0x90], xmm9
000073baab9ddbc0  vmovaps [rsp+0xA0], xmm10
000073baab9ddbc9  vmovaps [rsp+0xB0], xmm12
000073baab9ddbd2  vmovaps [rsp+0xC0], xmm13
000073baab9ddbdb  vmovaps [rsp+0xD0], xmm14
000073baab9ddbe4  vmovaps [rsp+0xE0], xmm15
000073baab9ddbed  sub rsp, 0x30
000073baab9ddbf1  movaps [rsp], xmm11
000073baab9ddbf6  movaps [rsp+0x10], xmm10
000073baab9ddbfc  movaps [rsp+0x20], xmm14
000073baab9ddc02  lea rdi, [rsp]
000073baab9ddc06  mov esi, 0x00
000073baab9ddc0b  mov rax, 0x5F3F1062D530
000073baab9ddc15  call rax
000073baab9ddc17  movaps xmm11, [rsp]
000073baab9ddc1c  add rsp, 0x30
000073baab9ddc20  vmovaps xmm0, [rsp]
000073baab9ddc25  vmovaps xmm1, [rsp+0x10]
000073baab9ddc2b  vmovaps xmm2, [rsp+0x20]
000073baab9ddc31  vmovaps xmm3, [rsp+0x30]
000073baab9ddc37  vmovaps xmm4, [rsp+0x40]
000073baab9ddc3d  vmovaps xmm5, [rsp+0x50]
000073baab9ddc43  vmovaps xmm6, [rsp+0x60]
000073baab9ddc49  vmovaps xmm7, [rsp+0x70]
000073baab9ddc4f  vmovaps xmm8, [rsp+0x80]
000073baab9ddc58  vmovaps xmm9, [rsp+0x90]
000073baab9ddc61  vmovaps xmm10, [rsp+0xA0]
000073baab9ddc6a  vmovaps xmm12, [rsp+0xB0]
000073baab9ddc73  vmovaps xmm13, [rsp+0xC0]
000073baab9ddc7c  vmovaps xmm14, [rsp+0xD0]
000073baab9ddc85  vmovaps xmm15, [rsp+0xE0]
000073baab9ddc8e  add rsp, 0xF0
000073baab9ddc95  pop r11
000073baab9ddc97  pop r10
000073baab9ddc99  pop r9
000073baab9ddc9b  pop r8
000073baab9ddc9d  pop rsi
000073baab9ddc9e  pop rdi
000073baab9ddc9f  pop rdx
000073baab9ddca0  pop rcx
000073baab9ddca1  pop rax
000073baab9ddca2  add rsp, 0x08
000073baab9ddca6  jmp 0x000073BAAB9D96CD
000073baab9ddcab  call 0x000073BAAB8E45A0
000073baab9ddcb0  jmp 0x000073BAAB9D96D7
000073baab9ddcb5  sub rsp, 0x08
000073baab9ddcb9  push rax
000073baab9ddcba  push rcx
000073baab9ddcbb  push rdx
000073baab9ddcbc  push rdi
000073baab9ddcbd  push rsi
000073baab9ddcbe  push r8
000073baab9ddcc0  push r9
000073baab9ddcc2  push r10
000073baab9ddcc4  push r11
000073baab9ddcc6  sub rsp, 0xF0
000073baab9ddccd  vmovaps [rsp], xmm0
000073baab9ddcd2  vmovaps [rsp+0x10], xmm1
000073baab9ddcd8  vmovaps [rsp+0x20], xmm2
000073baab9ddcde  vmovaps [rsp+0x30], xmm3
000073baab9ddce4  vmovaps [rsp+0x40], xmm4
000073baab9ddcea  vmovaps [rsp+0x50], xmm5
000073baab9ddcf0  vmovaps [rsp+0x60], xmm6
000073baab9ddcf6  vmovaps [rsp+0x70], xmm7
000073baab9ddcfc  vmovaps [rsp+0x80], xmm8
000073baab9ddd05  vmovaps [rsp+0x90], xmm9
000073baab9ddd0e  vmovaps [rsp+0xA0], xmm11
000073baab9ddd17  vmovaps [rsp+0xB0], xmm12
000073baab9ddd20  vmovaps [rsp+0xC0], xmm13
000073baab9ddd29  vmovaps [rsp+0xD0], xmm14
000073baab9ddd32  vmovaps [rsp+0xE0], xmm15
000073baab9ddd3b  sub rsp, 0x30
000073baab9ddd3f  movaps [rsp], xmm10
000073baab9ddd44  movaps [rsp+0x10], xmm1
000073baab9ddd49  movaps [rsp+0x20], xmm12
000073baab9ddd4f  lea rdi, [rsp]
000073baab9ddd53  mov esi, 0x00
000073baab9ddd58  mov rax, 0x5F3F1062D530
000073baab9ddd62  call rax
000073baab9ddd64  movaps xmm10, [rsp]
000073baab9ddd69  add rsp, 0x30
000073baab9ddd6d  vmovaps xmm0, [rsp]
000073baab9ddd72  vmovaps xmm1, [rsp+0x10]
000073baab9ddd78  vmovaps xmm2, [rsp+0x20]
000073baab9ddd7e  vmovaps xmm3, [rsp+0x30]
000073baab9ddd84  vmovaps xmm4, [rsp+0x40]
000073baab9ddd8a  vmovaps xmm5, [rsp+0x50]
000073baab9ddd90  vmovaps xmm6, [rsp+0x60]
000073baab9ddd96  vmovaps xmm7, [rsp+0x70]
000073baab9ddd9c  vmovaps xmm8, [rsp+0x80]
000073baab9ddda5  vmovaps xmm9, [rsp+0x90]
000073baab9dddae  vmovaps xmm11, [rsp+0xA0]
000073baab9dddb7  vmovaps xmm12, [rsp+0xB0]
000073baab9dddc0  vmovaps xmm13, [rsp+0xC0]
000073baab9dddc9  vmovaps xmm14, [rsp+0xD0]
000073baab9dddd2  vmovaps xmm15, [rsp+0xE0]
000073baab9ddddb  add rsp, 0xF0
000073baab9ddde2  pop r11
000073baab9ddde4  pop r10
000073baab9ddde6  pop r9
000073baab9ddde8  pop r8
000073baab9dddea  pop rsi
000073baab9dddeb  pop rdi
000073baab9dddec  pop rdx
000073baab9ddded  pop rcx
000073baab9dddee  pop rax
000073baab9dddef  add rsp, 0x08
000073baab9dddf3  jmp 0x000073BAAB9D96FA
000073baab9dddf8  sub rsp, 0x08
000073baab9dddfc  push rax
000073baab9dddfd  push rcx
000073baab9dddfe  push rdx
000073baab9dddff  push rdi
000073baab9dde00  push rsi
000073baab9dde01  push r8
000073baab9dde03  push r9
000073baab9dde05  push r10
000073baab9dde07  push r11
000073baab9dde09  sub rsp, 0xF0
000073baab9dde10  vmovaps [rsp], xmm0
000073baab9dde15  vmovaps [rsp+0x10], xmm1
000073baab9dde1b  vmovaps [rsp+0x20], xmm2
000073baab9dde21  vmovaps [rsp+0x30], xmm3
000073baab9dde27  vmovaps [rsp+0x40], xmm4
000073baab9dde2d  vmovaps [rsp+0x50], xmm5
000073baab9dde33  vmovaps [rsp+0x60], xmm6
000073baab9dde39  vmovaps [rsp+0x70], xmm7
000073baab9dde3f  vmovaps [rsp+0x80], xmm8
000073baab9dde48  vmovaps [rsp+0x90], xmm9
000073baab9dde51  vmovaps [rsp+0xA0], xmm10
000073baab9dde5a  vmovaps [rsp+0xB0], xmm11
000073baab9dde63  vmovaps [rsp+0xC0], xmm13
000073baab9dde6c  vmovaps [rsp+0xD0], xmm14
000073baab9dde75  vmovaps [rsp+0xE0], xmm15
000073baab9dde7e  sub rsp, 0x30
000073baab9dde82  movaps [rsp], xmm12
000073baab9dde87  movaps [rsp+0x10], xmm14
000073baab9dde8d  movaps [rsp+0x20], xmm1
000073baab9dde92  lea rdi, [rsp]
000073baab9dde96  mov esi, 0x00
000073baab9dde9b  mov rax, 0x5F3F1062D530
000073baab9ddea5  call rax
000073baab9ddea7  movaps xmm12, [rsp]
000073baab9ddeac  add rsp, 0x30
000073baab9ddeb0  vmovaps xmm0, [rsp]
000073baab9ddeb5  vmovaps xmm1, [rsp+0x10]
000073baab9ddebb  vmovaps xmm2, [rsp+0x20]
000073baab9ddec1  vmovaps xmm3, [rsp+0x30]
000073baab9ddec7  vmovaps xmm4, [rsp+0x40]
000073baab9ddecd  vmovaps xmm5, [rsp+0x50]
000073baab9dded3  vmovaps xmm6, [rsp+0x60]
000073baab9dded9  vmovaps xmm7, [rsp+0x70]
000073baab9ddedf  vmovaps xmm8, [rsp+0x80]
000073baab9ddee8  vmovaps xmm9, [rsp+0x90]
000073baab9ddef1  vmovaps xmm10, [rsp+0xA0]
000073baab9ddefa  vmovaps xmm11, [rsp+0xB0]
000073baab9ddf03  vmovaps xmm13, [rsp+0xC0]
000073baab9ddf0c  vmovaps xmm14, [rsp+0xD0]
000073baab9ddf15  vmovaps xmm15, [rsp+0xE0]
000073baab9ddf1e  add rsp, 0xF0
000073baab9ddf25  pop r11
000073baab9ddf27  pop r10
000073baab9ddf29  pop r9
000073baab9ddf2b  pop r8
000073baab9ddf2d  pop rsi
000073baab9ddf2e  pop rdi
000073baab9ddf2f  pop rdx
000073baab9ddf30  pop rcx
000073baab9ddf31  pop rax
000073baab9ddf32  add rsp, 0x08
000073baab9ddf36  jmp 0x000073BAAB9D9729
000073baab9ddf3b  sub rsp, 0x08
000073baab9ddf3f  push rax
000073baab9ddf40  push rcx
000073baab9ddf41  push rdx
000073baab9ddf42  push rdi
000073baab9ddf43  push rsi
000073baab9ddf44  push r8
000073baab9ddf46  push r9
000073baab9ddf48  push r10
000073baab9ddf4a  push r11
000073baab9ddf4c  sub rsp, 0xF0
000073baab9ddf53  vmovaps [rsp], xmm0
000073baab9ddf58  vmovaps [rsp+0x10], xmm1
000073baab9ddf5e  vmovaps [rsp+0x20], xmm2
000073baab9ddf64  vmovaps [rsp+0x30], xmm3
000073baab9ddf6a  vmovaps [rsp+0x40], xmm4
000073baab9ddf70  vmovaps [rsp+0x50], xmm5
000073baab9ddf76  vmovaps [rsp+0x60], xmm6
000073baab9ddf7c  vmovaps [rsp+0x70], xmm7
000073baab9ddf82  vmovaps [rsp+0x80], xmm8
000073baab9ddf8b  vmovaps [rsp+0x90], xmm9
000073baab9ddf94  vmovaps [rsp+0xA0], xmm10
000073baab9ddf9d  vmovaps [rsp+0xB0], xmm11
000073baab9ddfa6  vmovaps [rsp+0xC0], xmm12
000073baab9ddfaf  vmovaps [rsp+0xD0], xmm13
000073baab9ddfb8  vmovaps [rsp+0xE0], xmm15
000073baab9ddfc1  sub rsp, 0x30
000073baab9ddfc5  movaps [rsp], xmm14
000073baab9ddfca  movaps [rsp+0x10], xmm9
000073baab9ddfd0  movaps [rsp+0x20], xmm1
000073baab9ddfd5  lea rdi, [rsp]
000073baab9ddfd9  mov esi, 0x00
000073baab9ddfde  mov rax, 0x5F3F1062D530
000073baab9ddfe8  call rax
000073baab9ddfea  movaps xmm14, [rsp]
000073baab9ddfef  add rsp, 0x30
000073baab9ddff3  vmovaps xmm0, [rsp]
000073baab9ddff8  vmovaps xmm1, [rsp+0x10]
000073baab9ddffe  vmovaps xmm2, [rsp+0x20]
000073baab9de004  vmovaps xmm3, [rsp+0x30]
000073baab9de00a  vmovaps xmm4, [rsp+0x40]
000073baab9de010  vmovaps xmm5, [rsp+0x50]
000073baab9de016  vmovaps xmm6, [rsp+0x60]
000073baab9de01c  vmovaps xmm7, [rsp+0x70]
000073baab9de022  vmovaps xmm8, [rsp+0x80]
000073baab9de02b  vmovaps xmm9, [rsp+0x90]
000073baab9de034  vmovaps xmm10, [rsp+0xA0]
000073baab9de03d  vmovaps xmm11, [rsp+0xB0]
000073baab9de046  vmovaps xmm12, [rsp+0xC0]
000073baab9de04f  vmovaps xmm13, [rsp+0xD0]
000073baab9de058  vmovaps xmm15, [rsp+0xE0]
000073baab9de061  add rsp, 0xF0
000073baab9de068  pop r11
000073baab9de06a  pop r10
000073baab9de06c  pop r9
000073baab9de06e  pop r8
000073baab9de070  pop rsi
000073baab9de071  pop rdi
000073baab9de072  pop rdx
000073baab9de073  pop rcx
000073baab9de074  pop rax
000073baab9de075  add rsp, 0x08
000073baab9de079  jmp 0x000073BAAB9D9758
000073baab9de07e  sub rsp, 0x08
000073baab9de082  push rax
000073baab9de083  push rcx
000073baab9de084  push rdx
000073baab9de085  push rdi
000073baab9de086  push rsi
000073baab9de087  push r8
000073baab9de089  push r9
000073baab9de08b  push r10
000073baab9de08d  push r11
000073baab9de08f  sub rsp, 0xF0
000073baab9de096  vmovaps [rsp], xmm0
000073baab9de09b  vmovaps [rsp+0x10], xmm2
000073baab9de0a1  vmovaps [rsp+0x20], xmm3
000073baab9de0a7  vmovaps [rsp+0x30], xmm4
000073baab9de0ad  vmovaps [rsp+0x40], xmm5
000073baab9de0b3  vmovaps [rsp+0x50], xmm6
000073baab9de0b9  vmovaps [rsp+0x60], xmm7
000073baab9de0bf  vmovaps [rsp+0x70], xmm8
000073baab9de0c5  vmovaps [rsp+0x80], xmm9
000073baab9de0ce  vmovaps [rsp+0x90], xmm10
000073baab9de0d7  vmovaps [rsp+0xA0], xmm11
000073baab9de0e0  vmovaps [rsp+0xB0], xmm12
000073baab9de0e9  vmovaps [rsp+0xC0], xmm13
000073baab9de0f2  vmovaps [rsp+0xD0], xmm14
000073baab9de0fb  vmovaps [rsp+0xE0], xmm15
000073baab9de104  sub rsp, 0x30
000073baab9de108  movaps [rsp], xmm1
000073baab9de10c  movaps [rsp+0x10], xmm13
000073baab9de112  movaps [rsp+0x20], xmm8
000073baab9de118  lea rdi, [rsp]
000073baab9de11c  mov esi, 0x00
000073baab9de121  mov rax, 0x5F3F1062D530
000073baab9de12b  call rax
000073baab9de12d  movaps xmm1, [rsp]
000073baab9de131  add rsp, 0x30
000073baab9de135  vmovaps xmm0, [rsp]
000073baab9de13a  vmovaps xmm2, [rsp+0x10]
000073baab9de140  vmovaps xmm3, [rsp+0x20]
000073baab9de146  vmovaps xmm4, [rsp+0x30]
000073baab9de14c  vmovaps xmm5, [rsp+0x40]
000073baab9de152  vmovaps xmm6, [rsp+0x50]
000073baab9de158  vmovaps xmm7, [rsp+0x60]
000073baab9de15e  vmovaps xmm8, [rsp+0x70]
000073baab9de164  vmovaps xmm9, [rsp+0x80]
000073baab9de16d  vmovaps xmm10, [rsp+0x90]
000073baab9de176  vmovaps xmm11, [rsp+0xA0]
000073baab9de17f  vmovaps xmm12, [rsp+0xB0]
000073baab9de188  vmovaps xmm13, [rsp+0xC0]
000073baab9de191  vmovaps xmm14, [rsp+0xD0]
000073baab9de19a  vmovaps xmm15, [rsp+0xE0]
000073baab9de1a3  add rsp, 0xF0
000073baab9de1aa  pop r11
000073baab9de1ac  pop r10
000073baab9de1ae  pop r9
000073baab9de1b0  pop r8
000073baab9de1b2  pop rsi
000073baab9de1b3  pop rdi
000073baab9de1b4  pop rdx
000073baab9de1b5  pop rcx
000073baab9de1b6  pop rax
000073baab9de1b7  add rsp, 0x08
000073baab9de1bb  jmp 0x000073BAAB9D977A
000073baab9de1c0  call 0x000073BAAB80C260
000073baab9de1c5  jmp 0x000073BAAB9D9788
000073baab9de1ca  call 0x000073BAAB8DE950
000073baab9de1cf  jmp 0x000073BAAB9D9792
000073baab9de1d4  sub rsp, 0x08
000073baab9de1d8  push rax
000073baab9de1d9  push rcx
000073baab9de1da  push rdx
000073baab9de1db  push rdi
000073baab9de1dc  push rsi
000073baab9de1dd  push r8
000073baab9de1df  push r9
000073baab9de1e1  push r10
000073baab9de1e3  push r11
000073baab9de1e5  sub rsp, 0xF0
000073baab9de1ec  vmovaps [rsp], xmm0
000073baab9de1f1  vmovaps [rsp+0x10], xmm1
000073baab9de1f7  vmovaps [rsp+0x20], xmm2
000073baab9de1fd  vmovaps [rsp+0x30], xmm3
000073baab9de203  vmovaps [rsp+0x40], xmm4
000073baab9de209  vmovaps [rsp+0x50], xmm5
000073baab9de20f  vmovaps [rsp+0x60], xmm6
000073baab9de215  vmovaps [rsp+0x70], xmm7
000073baab9de21b  vmovaps [rsp+0x80], xmm9
000073baab9de224  vmovaps [rsp+0x90], xmm10
000073baab9de22d  vmovaps [rsp+0xA0], xmm11
000073baab9de236  vmovaps [rsp+0xB0], xmm12
000073baab9de23f  vmovaps [rsp+0xC0], xmm13
000073baab9de248  vmovaps [rsp+0xD0], xmm14
000073baab9de251  vmovaps [rsp+0xE0], xmm15
000073baab9de25a  sub rsp, 0x30
000073baab9de25e  movaps [rsp], xmm8
000073baab9de263  movaps [rsp+0x10], xmm15
000073baab9de269  movaps [rsp+0x20], xmm7
000073baab9de26e  lea rdi, [rsp]
000073baab9de272  mov esi, 0x00
000073baab9de277  mov rax, 0x5F3F1062D530
000073baab9de281  call rax
000073baab9de283  movaps xmm8, [rsp]
000073baab9de288  add rsp, 0x30
000073baab9de28c  vmovaps xmm0, [rsp]
000073baab9de291  vmovaps xmm1, [rsp+0x10]
000073baab9de297  vmovaps xmm2, [rsp+0x20]
000073baab9de29d  vmovaps xmm3, [rsp+0x30]
000073baab9de2a3  vmovaps xmm4, [rsp+0x40]
000073baab9de2a9  vmovaps xmm5, [rsp+0x50]
000073baab9de2af  vmovaps xmm6, [rsp+0x60]
000073baab9de2b5  vmovaps xmm7, [rsp+0x70]
000073baab9de2bb  vmovaps xmm9, [rsp+0x80]
000073baab9de2c4  vmovaps xmm10, [rsp+0x90]
000073baab9de2cd  vmovaps xmm11, [rsp+0xA0]
000073baab9de2d6  vmovaps xmm12, [rsp+0xB0]
000073baab9de2df  vmovaps xmm13, [rsp+0xC0]
000073baab9de2e8  vmovaps xmm14, [rsp+0xD0]
000073baab9de2f1  vmovaps xmm15, [rsp+0xE0]
000073baab9de2fa  add rsp, 0xF0
000073baab9de301  pop r11
000073baab9de303  pop r10
000073baab9de305  pop r9
000073baab9de307  pop r8
000073baab9de309  pop rsi
000073baab9de30a  pop rdi
000073baab9de30b  pop rdx
000073baab9de30c  pop rcx
000073baab9de30d  pop rax
000073baab9de30e  add rsp, 0x08
000073baab9de312  jmp 0x000073BAAB9D97B4
000073baab9de317  sub rsp, 0x08
000073baab9de31b  push rax
000073baab9de31c  push rcx
000073baab9de31d  push rdx
000073baab9de31e  push rdi
000073baab9de31f  push rsi
000073baab9de320  push r8
000073baab9de322  push r9
000073baab9de324  push r10
000073baab9de326  push r11
000073baab9de328  sub rsp, 0xF0
000073baab9de32f  vmovaps [rsp], xmm0
000073baab9de334  vmovaps [rsp+0x10], xmm1
000073baab9de33a  vmovaps [rsp+0x20], xmm2
000073baab9de340  vmovaps [rsp+0x30], xmm3
000073baab9de346  vmovaps [rsp+0x40], xmm4
000073baab9de34c  vmovaps [rsp+0x50], xmm5
000073baab9de352  vmovaps [rsp+0x60], xmm6
000073baab9de358  vmovaps [rsp+0x70], xmm8
000073baab9de35e  vmovaps [rsp+0x80], xmm9
000073baab9de367  vmovaps [rsp+0x90], xmm10
000073baab9de370  vmovaps [rsp+0xA0], xmm11
000073baab9de379  vmovaps [rsp+0xB0], xmm12
000073baab9de382  vmovaps [rsp+0xC0], xmm13
000073baab9de38b  vmovaps [rsp+0xD0], xmm14
000073baab9de394  vmovaps [rsp+0xE0], xmm15
000073baab9de39d  sub rsp, 0x30
000073baab9de3a1  movaps [rsp], xmm7
000073baab9de3a5  movaps [rsp+0x10], xmm9
000073baab9de3ab  movaps [rsp+0x20], xmm15
000073baab9de3b1  lea rdi, [rsp]
000073baab9de3b5  mov esi, 0x00
000073baab9de3ba  mov rax, 0x5F3F1062D530
000073baab9de3c4  call rax
000073baab9de3c6  movaps xmm7, [rsp]
000073baab9de3ca  add rsp, 0x30
000073baab9de3ce  vmovaps xmm0, [rsp]
000073baab9de3d3  vmovaps xmm1, [rsp+0x10]
000073baab9de3d9  vmovaps xmm2, [rsp+0x20]
000073baab9de3df  vmovaps xmm3, [rsp+0x30]
000073baab9de3e5  vmovaps xmm4, [rsp+0x40]
000073baab9de3eb  vmovaps xmm5, [rsp+0x50]
000073baab9de3f1  vmovaps xmm6, [rsp+0x60]
000073baab9de3f7  vmovaps xmm8, [rsp+0x70]
000073baab9de3fd  vmovaps xmm9, [rsp+0x80]
000073baab9de406  vmovaps xmm10, [rsp+0x90]
000073baab9de40f  vmovaps xmm11, [rsp+0xA0]
000073baab9de418  vmovaps xmm12, [rsp+0xB0]
000073baab9de421  vmovaps xmm13, [rsp+0xC0]
000073baab9de42a  vmovaps xmm14, [rsp+0xD0]
000073baab9de433  vmovaps xmm15, [rsp+0xE0]
000073baab9de43c  add rsp, 0xF0
000073baab9de443  pop r11
000073baab9de445  pop r10
000073baab9de447  pop r9
000073baab9de449  pop r8
000073baab9de44b  pop rsi
000073baab9de44c  pop rdi
000073baab9de44d  pop rdx
000073baab9de44e  pop rcx
000073baab9de44f  pop rax
000073baab9de450  add rsp, 0x08
000073baab9de454  jmp 0x000073BAAB9D97E1
000073baab9de459  sub rsp, 0x08
000073baab9de45d  push rax
000073baab9de45e  push rcx
000073baab9de45f  push rdx
000073baab9de460  push rdi
000073baab9de461  push rsi
000073baab9de462  push r8
000073baab9de464  push r9
000073baab9de466  push r10
000073baab9de468  push r11
000073baab9de46a  sub rsp, 0xF0
000073baab9de471  vmovaps [rsp], xmm0
000073baab9de476  vmovaps [rsp+0x10], xmm1
000073baab9de47c  vmovaps [rsp+0x20], xmm2
000073baab9de482  vmovaps [rsp+0x30], xmm3
000073baab9de488  vmovaps [rsp+0x40], xmm4
000073baab9de48e  vmovaps [rsp+0x50], xmm5
000073baab9de494  vmovaps [rsp+0x60], xmm6
000073baab9de49a  vmovaps [rsp+0x70], xmm7
000073baab9de4a0  vmovaps [rsp+0x80], xmm8
000073baab9de4a9  vmovaps [rsp+0x90], xmm10
000073baab9de4b2  vmovaps [rsp+0xA0], xmm11
000073baab9de4bb  vmovaps [rsp+0xB0], xmm12
000073baab9de4c4  vmovaps [rsp+0xC0], xmm13
000073baab9de4cd  vmovaps [rsp+0xD0], xmm14
000073baab9de4d6  vmovaps [rsp+0xE0], xmm15
000073baab9de4df  sub rsp, 0x30
000073baab9de4e3  movaps [rsp], xmm9
000073baab9de4e8  movaps [rsp+0x10], xmm13
000073baab9de4ee  movaps [rsp+0x20], xmm15
000073baab9de4f4  lea rdi, [rsp]
000073baab9de4f8  mov esi, 0x00
000073baab9de4fd  mov rax, 0x5F3F1062D530
000073baab9de507  call rax
000073baab9de509  movaps xmm9, [rsp]
000073baab9de50e  add rsp, 0x30
000073baab9de512  vmovaps xmm0, [rsp]
000073baab9de517  vmovaps xmm1, [rsp+0x10]
000073baab9de51d  vmovaps xmm2, [rsp+0x20]
000073baab9de523  vmovaps xmm3, [rsp+0x30]
000073baab9de529  vmovaps xmm4, [rsp+0x40]
000073baab9de52f  vmovaps xmm5, [rsp+0x50]
000073baab9de535  vmovaps xmm6, [rsp+0x60]
000073baab9de53b  vmovaps xmm7, [rsp+0x70]
000073baab9de541  vmovaps xmm8, [rsp+0x80]
000073baab9de54a  vmovaps xmm10, [rsp+0x90]
000073baab9de553  vmovaps xmm11, [rsp+0xA0]
000073baab9de55c  vmovaps xmm12, [rsp+0xB0]
000073baab9de565  vmovaps xmm13, [rsp+0xC0]
000073baab9de56e  vmovaps xmm14, [rsp+0xD0]
000073baab9de577  vmovaps xmm15, [rsp+0xE0]
000073baab9de580  add rsp, 0xF0
000073baab9de587  pop r11
000073baab9de589  pop r10
000073baab9de58b  pop r9
000073baab9de58d  pop r8
000073baab9de58f  pop rsi
000073baab9de590  pop rdi
000073baab9de591  pop rdx
000073baab9de592  pop rcx
000073baab9de593  pop rax
000073baab9de594  add rsp, 0x08
000073baab9de598  jmp 0x000073BAAB9D980F
000073baab9de59d  sub rsp, 0x08
000073baab9de5a1  push rax
000073baab9de5a2  push rcx
000073baab9de5a3  push rdx
000073baab9de5a4  push rdi
000073baab9de5a5  push rsi
000073baab9de5a6  push r8
000073baab9de5a8  push r9
000073baab9de5aa  push r10
000073baab9de5ac  push r11
000073baab9de5ae  sub rsp, 0xF0
000073baab9de5b5  vmovaps [rsp], xmm0
000073baab9de5ba  vmovaps [rsp+0x10], xmm1
000073baab9de5c0  vmovaps [rsp+0x20], xmm2
000073baab9de5c6  vmovaps [rsp+0x30], xmm3
000073baab9de5cc  vmovaps [rsp+0x40], xmm4
000073baab9de5d2  vmovaps [rsp+0x50], xmm5
000073baab9de5d8  vmovaps [rsp+0x60], xmm6
000073baab9de5de  vmovaps [rsp+0x70], xmm7
000073baab9de5e4  vmovaps [rsp+0x80], xmm8
000073baab9de5ed  vmovaps [rsp+0x90], xmm9
000073baab9de5f6  vmovaps [rsp+0xA0], xmm10
000073baab9de5ff  vmovaps [rsp+0xB0], xmm11
000073baab9de608  vmovaps [rsp+0xC0], xmm12
000073baab9de611  vmovaps [rsp+0xD0], xmm13
000073baab9de61a  vmovaps [rsp+0xE0], xmm14
000073baab9de623  sub rsp, 0x30
000073baab9de627  movaps [rsp], xmm15
000073baab9de62c  movaps [rsp+0x10], xmm11
000073baab9de632  movaps [rsp+0x20], xmm12
000073baab9de638  lea rdi, [rsp]
000073baab9de63c  mov esi, 0x00
000073baab9de641  mov rax, 0x5F3F1062D530
000073baab9de64b  call rax
000073baab9de64d  movaps xmm15, [rsp]
000073baab9de652  add rsp, 0x30
000073baab9de656  vmovaps xmm0, [rsp]
000073baab9de65b  vmovaps xmm1, [rsp+0x10]
000073baab9de661  vmovaps xmm2, [rsp+0x20]
000073baab9de667  vmovaps xmm3, [rsp+0x30]
000073baab9de66d  vmovaps xmm4, [rsp+0x40]
000073baab9de673  vmovaps xmm5, [rsp+0x50]
000073baab9de679  vmovaps xmm6, [rsp+0x60]
000073baab9de67f  vmovaps xmm7, [rsp+0x70]
000073baab9de685  vmovaps xmm8, [rsp+0x80]
000073baab9de68e  vmovaps xmm9, [rsp+0x90]
000073baab9de697  vmovaps xmm10, [rsp+0xA0]
000073baab9de6a0  vmovaps xmm11, [rsp+0xB0]
000073baab9de6a9  vmovaps xmm12, [rsp+0xC0]
000073baab9de6b2  vmovaps xmm13, [rsp+0xD0]
000073baab9de6bb  vmovaps xmm14, [rsp+0xE0]
000073baab9de6c4  add rsp, 0xF0
000073baab9de6cb  pop r11
000073baab9de6cd  pop r10
000073baab9de6cf  pop r9
000073baab9de6d1  pop r8
000073baab9de6d3  pop rsi
000073baab9de6d4  pop rdi
000073baab9de6d5  pop rdx
000073baab9de6d6  pop rcx
000073baab9de6d7  pop rax
000073baab9de6d8  add rsp, 0x08
000073baab9de6dc  jmp 0x000073BAAB9D982A
000073baab9de6e1  sub rsp, 0x08
000073baab9de6e5  push rax
000073baab9de6e6  push rcx
000073baab9de6e7  push rdx
000073baab9de6e8  push rdi
000073baab9de6e9  push rsi
000073baab9de6ea  push r8
000073baab9de6ec  push r9
000073baab9de6ee  push r10
000073baab9de6f0  push r11
000073baab9de6f2  sub rsp, 0xF0
000073baab9de6f9  vmovaps [rsp], xmm0
000073baab9de6fe  vmovaps [rsp+0x10], xmm1
000073baab9de704  vmovaps [rsp+0x20], xmm2
000073baab9de70a  vmovaps [rsp+0x30], xmm3
000073baab9de710  vmovaps [rsp+0x40], xmm4
000073baab9de716  vmovaps [rsp+0x50], xmm5
000073baab9de71c  vmovaps [rsp+0x60], xmm6
000073baab9de722  vmovaps [rsp+0x70], xmm7
000073baab9de728  vmovaps [rsp+0x80], xmm8
000073baab9de731  vmovaps [rsp+0x90], xmm9
000073baab9de73a  vmovaps [rsp+0xA0], xmm10
000073baab9de743  vmovaps [rsp+0xB0], xmm11
000073baab9de74c  vmovaps [rsp+0xC0], xmm12
000073baab9de755  vmovaps [rsp+0xD0], xmm14
000073baab9de75e  vmovaps [rsp+0xE0], xmm15
000073baab9de767  sub rsp, 0x30
000073baab9de76b  movaps [rsp], xmm13
000073baab9de770  movaps [rsp+0x10], xmm10
000073baab9de776  movaps [rsp+0x20], xmm14
000073baab9de77c  lea rdi, [rsp]
000073baab9de780  mov esi, 0x00
000073baab9de785  mov rax, 0x5F3F1062D530
000073baab9de78f  call rax
000073baab9de791  movaps xmm13, [rsp]
000073baab9de796  add rsp, 0x30
000073baab9de79a  vmovaps xmm0, [rsp]
000073baab9de79f  vmovaps xmm1, [rsp+0x10]
000073baab9de7a5  vmovaps xmm2, [rsp+0x20]
000073baab9de7ab  vmovaps xmm3, [rsp+0x30]
000073baab9de7b1  vmovaps xmm4, [rsp+0x40]
000073baab9de7b7  vmovaps xmm5, [rsp+0x50]
000073baab9de7bd  vmovaps xmm6, [rsp+0x60]
000073baab9de7c3  vmovaps xmm7, [rsp+0x70]
000073baab9de7c9  vmovaps xmm8, [rsp+0x80]
000073baab9de7d2  vmovaps xmm9, [rsp+0x90]
000073baab9de7db  vmovaps xmm10, [rsp+0xA0]
000073baab9de7e4  vmovaps xmm11, [rsp+0xB0]
000073baab9de7ed  vmovaps xmm12, [rsp+0xC0]
000073baab9de7f6  vmovaps xmm14, [rsp+0xD0]
000073baab9de7ff  vmovaps xmm15, [rsp+0xE0]
000073baab9de808  add rsp, 0xF0
000073baab9de80f  pop r11
000073baab9de811  pop r10
000073baab9de813  pop r9
000073baab9de815  pop r8
000073baab9de817  pop rsi
000073baab9de818  pop rdi
000073baab9de819  pop rdx
000073baab9de81a  pop rcx
000073baab9de81b  pop rax
000073baab9de81c  add rsp, 0x08
000073baab9de820  jmp 0x000073BAAB9D984D
000073baab9de825  sub rsp, 0x08
000073baab9de829  push rax
000073baab9de82a  push rcx
000073baab9de82b  push rdx
000073baab9de82c  push rdi
000073baab9de82d  push rsi
000073baab9de82e  push r8
000073baab9de830  push r9
000073baab9de832  push r10
000073baab9de834  push r11
000073baab9de836  sub rsp, 0xF0
000073baab9de83d  vmovaps [rsp], xmm0
000073baab9de842  vmovaps [rsp+0x10], xmm1
000073baab9de848  vmovaps [rsp+0x20], xmm2
000073baab9de84e  vmovaps [rsp+0x30], xmm3
000073baab9de854  vmovaps [rsp+0x40], xmm4
000073baab9de85a  vmovaps [rsp+0x50], xmm5
000073baab9de860  vmovaps [rsp+0x60], xmm6
000073baab9de866  vmovaps [rsp+0x70], xmm7
000073baab9de86c  vmovaps [rsp+0x80], xmm8
000073baab9de875  vmovaps [rsp+0x90], xmm9
000073baab9de87e  vmovaps [rsp+0xA0], xmm10
000073baab9de887  vmovaps [rsp+0xB0], xmm11
000073baab9de890  vmovaps [rsp+0xC0], xmm12
000073baab9de899  vmovaps [rsp+0xD0], xmm13
000073baab9de8a2  vmovaps [rsp+0xE0], xmm15
000073baab9de8ab  sub rsp, 0x30
000073baab9de8af  movaps [rsp], xmm14
000073baab9de8b4  movaps [rsp+0x10], xmm1
000073baab9de8b9  movaps [rsp+0x20], xmm7
000073baab9de8be  lea rdi, [rsp]
000073baab9de8c2  mov esi, 0x00
000073baab9de8c7  mov rax, 0x5F3F1062D530
000073baab9de8d1  call rax
000073baab9de8d3  movaps xmm14, [rsp]
000073baab9de8d8  add rsp, 0x30
000073baab9de8dc  vmovaps xmm0, [rsp]
000073baab9de8e1  vmovaps xmm1, [rsp+0x10]
000073baab9de8e7  vmovaps xmm2, [rsp+0x20]
000073baab9de8ed  vmovaps xmm3, [rsp+0x30]
000073baab9de8f3  vmovaps xmm4, [rsp+0x40]
000073baab9de8f9  vmovaps xmm5, [rsp+0x50]
000073baab9de8ff  vmovaps xmm6, [rsp+0x60]
000073baab9de905  vmovaps xmm7, [rsp+0x70]
000073baab9de90b  vmovaps xmm8, [rsp+0x80]
000073baab9de914  vmovaps xmm9, [rsp+0x90]
000073baab9de91d  vmovaps xmm10, [rsp+0xA0]
000073baab9de926  vmovaps xmm11, [rsp+0xB0]
000073baab9de92f  vmovaps xmm12, [rsp+0xC0]
000073baab9de938  vmovaps xmm13, [rsp+0xD0]
000073baab9de941  vmovaps xmm15, [rsp+0xE0]
000073baab9de94a  add rsp, 0xF0
000073baab9de951  pop r11
000073baab9de953  pop r10
000073baab9de955  pop r9
000073baab9de957  pop r8
000073baab9de959  pop rsi
000073baab9de95a  pop rdi
000073baab9de95b  pop rdx
000073baab9de95c  pop rcx
000073baab9de95d  pop rax
000073baab9de95e  add rsp, 0x08
000073baab9de962  jmp 0x000073BAAB9D9870
000073baab9de967  sub rsp, 0x08
000073baab9de96b  push rax
000073baab9de96c  push rcx
000073baab9de96d  push rdx
000073baab9de96e  push rdi
000073baab9de96f  push rsi
000073baab9de970  push r8
000073baab9de972  push r9
000073baab9de974  push r10
000073baab9de976  push r11
000073baab9de978  sub rsp, 0xF0
000073baab9de97f  vmovaps [rsp], xmm0
000073baab9de984  vmovaps [rsp+0x10], xmm2
000073baab9de98a  vmovaps [rsp+0x20], xmm3
000073baab9de990  vmovaps [rsp+0x30], xmm4
000073baab9de996  vmovaps [rsp+0x40], xmm5
000073baab9de99c  vmovaps [rsp+0x50], xmm6
000073baab9de9a2  vmovaps [rsp+0x60], xmm7
000073baab9de9a8  vmovaps [rsp+0x70], xmm8
000073baab9de9ae  vmovaps [rsp+0x80], xmm9
000073baab9de9b7  vmovaps [rsp+0x90], xmm10
000073baab9de9c0  vmovaps [rsp+0xA0], xmm11
000073baab9de9c9  vmovaps [rsp+0xB0], xmm12
000073baab9de9d2  vmovaps [rsp+0xC0], xmm13
000073baab9de9db  vmovaps [rsp+0xD0], xmm14
000073baab9de9e4  vmovaps [rsp+0xE0], xmm15
000073baab9de9ed  sub rsp, 0x30
000073baab9de9f1  movaps [rsp], xmm1
000073baab9de9f5  movaps [rsp+0x10], xmm8
000073baab9de9fb  movaps [rsp+0x20], xmm9
000073baab9dea01  lea rdi, [rsp]
000073baab9dea05  mov esi, 0x00
000073baab9dea0a  mov rax, 0x5F3F1062D530
000073baab9dea14  call rax
000073baab9dea16  movaps xmm1, [rsp]
000073baab9dea1a  add rsp, 0x30
000073baab9dea1e  vmovaps xmm0, [rsp]
000073baab9dea23  vmovaps xmm2, [rsp+0x10]
000073baab9dea29  vmovaps xmm3, [rsp+0x20]
000073baab9dea2f  vmovaps xmm4, [rsp+0x30]
000073baab9dea35  vmovaps xmm5, [rsp+0x40]
000073baab9dea3b  vmovaps xmm6, [rsp+0x50]
000073baab9dea41  vmovaps xmm7, [rsp+0x60]
000073baab9dea47  vmovaps xmm8, [rsp+0x70]
000073baab9dea4d  vmovaps xmm9, [rsp+0x80]
000073baab9dea56  vmovaps xmm10, [rsp+0x90]
000073baab9dea5f  vmovaps xmm11, [rsp+0xA0]
000073baab9dea68  vmovaps xmm12, [rsp+0xB0]
000073baab9dea71  vmovaps xmm13, [rsp+0xC0]
000073baab9dea7a  vmovaps xmm14, [rsp+0xD0]
000073baab9dea83  vmovaps xmm15, [rsp+0xE0]
000073baab9dea8c  add rsp, 0xF0
000073baab9dea93  pop r11
000073baab9dea95  pop r10
000073baab9dea97  pop r9
000073baab9dea99  pop r8
000073baab9dea9b  pop rsi
000073baab9dea9c  pop rdi
000073baab9dea9d  pop rdx
000073baab9dea9e  pop rcx
000073baab9dea9f  pop rax
000073baab9deaa0  add rsp, 0x08
000073baab9deaa4  jmp 0x000073BAAB9D9892
000073baab9deaa9  call 0x000073BAAB8B3E40
000073baab9deaae  jmp 0x000073BAAB9D98A0
000073baab9deab3  call 0x000073BAAB80C380
000073baab9deab8  jmp 0x000073BAAB9D98AA
000073baab9deabd  call 0x000073BAAB80D600
000073baab9deac2  jmp 0x000073BAAB9D98B4
000073baab9deac7  call 0x000073BAAB7FF540
000073baab9deacc  jmp 0x000073BAAB9D98BE
000073baab9dead1  int3
000073baab9dead2  nop [rax+rax*1], ax
000073baab9deadb  nop [rax+rax*1], eax
000073baab9deae0  mov eax, [r15+0x48]
000073baab9deae4  lea r14d, [eax+0x01]
000073baab9deae9  mov [rsp+0x10], r14d
000073baab9deaee  mov r14d, r14d
000073baab9deaf1  mov [r15+0x48], r14
000073baab9deaf5  xor eax, eax
000073baab9deaf7  mov r14d, [rsp+0x10]
000073baab9deafc  cmp r14d, 0x1F4
000073baab9deb03  cmc
000073baab9deb04  lahf
000073baab9deb05  seto al
000073baab9deb08  mov [r15+0x108], eax
000073baab9deb0f  mov eax, [r15+0x108]
000073baab9deb16  sahf
000073baab9deb17  jnz 0x000073BAAB9DEB49
000073baab9deb19  cmp dword ptr [r15+0x318], 0x00
000073baab9deb21  jz 0x000073BAAB9E4C90
000073baab9deb27  nop [rax+rax*1], ax
000073baab9deb30  nop [rax+rax*1], eax
000073baab9deb38  mov eax, 0x4106DC
000073baab9deb3d  mov [r15+0x100], rax
000073baab9deb44  jmp 0x000073BAAB7FE110
000073baab9deb49  cmp dword ptr [r15+0x318], 0x00
000073baab9deb51  jz 0x000073BAAB9DEB80
000073baab9deb57  nop [rax+rax*1], ax
000073baab9deb60  nop [rax+rax*1], eax
000073baab9deb68  mov eax, 0x410500
000073baab9deb6d  mov [r15+0x100], rax
000073baab9deb74  jmp 0x000073BAAB7FE110
000073baab9deb79  int3
000073baab9deb7a  int3
000073baab9deb7b  nop [rax+rax*1], eax
000073baab9deb80  mov rax, [r15+0x40]
000073baab9deb84  movaps xmm1, [r15+0x1D0]
000073baab9deb8c  vmovaps [rsp+0x10], xmm1
000073baab9deb92  vmovaps xmm15, [rsp+0x10]
000073baab9deb98  por xmm1, xmm15
000073baab9deb9d  movaps xmm14, [r15+0x1A0]
000073baab9deba5  vmovaps [rsp+0x10], xmm14
000073baab9debab  vmovaps xmm13, [rsp+0x10]
000073baab9debb1  por xmm14, xmm13
000073baab9debb6  lea r14, [rax+0x30]
000073baab9debba  mov r12, [r13+r14*1]
000073baab9debbf  lea r14, [rax+0x38]
000073baab9debc3  mov r11, [r13+r14*1]
000073baab9debc8  movq xmm13, r12
000073baab9debcd  movq xmm12, r11
000073baab9debd2  movq xmm13, xmm13
000073baab9debd7  vmovaps [rsp+0x10], xmm13
000073baab9debdd  movq xmm13, xmm13
000073baab9debe2  movaps [r15+0x130], xmm13
000073baab9debea  movq xmm12, xmm12
000073baab9debef  vmovaps [rsp+0x20], xmm12
000073baab9debf5  movq xmm12, xmm12
000073baab9debfa  movaps [r15+0x280], xmm12
000073baab9dec02  movaps xmm13, [r15+0x270]
000073baab9dec0a  vmovaps [rsp+0x30], xmm13
000073baab9dec10  vmovaps xmm12, [rsp+0x30]
000073baab9dec16  por xmm13, xmm12
000073baab9dec1b  lea r14, [rax+0x20]
000073baab9dec1f  mov r12, [r13+r14*1]
000073baab9dec24  lea r14, [rax+0x28]
000073baab9dec28  mov r11, [r13+r14*1]
000073baab9dec2d  movq xmm12, r12
000073baab9dec32  movq xmm11, r11
000073baab9dec37  movq xmm12, xmm12
000073baab9dec3c  vmovaps [rsp+0x30], xmm12
000073baab9dec42  movq xmm12, xmm12
000073baab9dec47  movaps [r15+0x150], xmm12
000073baab9dec4f  movq xmm11, xmm11
000073baab9dec54  vmovaps [rsp+0x40], xmm11
000073baab9dec5a  movq xmm11, xmm11
000073baab9dec5f  movaps [r15+0x140], xmm11
000073baab9dec67  lea r14, [rax+0x10]
000073baab9dec6b  mov r12, [r13+r14*1]
000073baab9dec70  lea r14, [rax+0x18]
000073baab9dec74  mov r11, [r13+r14*1]
000073baab9dec79  movq xmm12, r12
000073baab9dec7e  movq xmm11, r11
000073baab9dec83  movq xmm12, xmm12
000073baab9dec88  vmovaps [rsp+0x50], xmm12
000073baab9dec8e  movq xmm12, xmm12
000073baab9dec93  movaps [r15+0x170], xmm12
000073baab9dec9b  movq xmm11, xmm11
000073baab9deca0  vmovaps [rsp+0x60], xmm11
000073baab9deca6  movq xmm11, xmm11
000073baab9decab  movaps [r15+0x160], xmm11
000073baab9decb3  mov r14, [r13+rax*1]
000073baab9decb8  vmovq xmm12, r14
000073baab9decbd  vpbroadcastq xmm12, xmm12
000073baab9decc2  lea r14, [rax+0x08]
000073baab9decc6  mov rax, [r13+r14*1]
000073baab9deccb  movq xmm11, rax
000073baab9decd0  movaps [r15+0x230], xmm11
000073baab9decd8  mov rax, [r15+0xF8]
000073baab9decdf  lea r14, [rax+0x50]
000073baab9dece3  movups xmm11, [r13+r14*1]
000073baab9dece9  lea r14, [rax+0x60]
000073baab9deced  movups xmm10, [r13+r14*1]
000073baab9decf3  lea r14, [rax+0x30]
000073baab9decf7  movups xmm9, [r13+r14*1]
000073baab9decfd  mov r14, [r15+0x50]
000073baab9ded01  mov [r15+0x60], r14
000073baab9ded05  mov qword ptr [r15+0x58], 0x40
000073baab9ded0d  movaps xmm8, xmm12
000073baab9ded11  mulpd xmm8, xmm15
000073baab9ded16  vcmppd xmm7, xmm8, xmm8, 0x03
000073baab9ded1c  ptest xmm7, xmm7
000073baab9ded21  jnz 0x000073BAAB9DFB4A
000073baab9ded27  movq xmm15, qword ptr [r15+0x230]
000073baab9ded30  vmovaps [rsp+0x70], xmm15
000073baab9ded36  vpermilpd xmm15, xmm15, 0x00
000073baab9ded3c  movaps xmm7, xmm9
000073baab9ded40  mulpd xmm7, xmm15
000073baab9ded45  vcmppd xmm6, xmm7, xmm7, 0x03
000073baab9ded4a  ptest xmm6, xmm6
000073baab9ded4f  jnz 0x000073BAAB9DFC8E
000073baab9ded55  vxorps xmm15, xmm15, xmm15
000073baab9ded5a  vpbroadcastq xmm15, xmm15
000073baab9ded5f  movaps xmm9, xmm12
000073baab9ded63  mulpd xmm9, xmm10
000073baab9ded68  vcmppd xmm6, xmm9, xmm9, 0x03
000073baab9ded6e  ptest xmm6, xmm6
000073baab9ded73  jnz 0x000073BAAB9DFDD0
000073baab9ded79  movaps xmm10, xmm12
000073baab9ded7d  mulpd xmm10, xmm11
000073baab9ded82  vcmppd xmm6, xmm10, xmm10, 0x03
000073baab9ded88  ptest xmm6, xmm6
000073baab9ded8d  jnz 0x000073BAAB9DFF14
000073baab9ded93  movaps xmm11, [r15+0x1F0]
000073baab9ded9b  movaps xmm6, xmm12
000073baab9ded9f  mulpd xmm6, xmm11
000073baab9deda4  vcmppd xmm5, xmm6, xmm6, 0x03
000073baab9deda9  ptest xmm5, xmm5
000073baab9dedae  jnz 0x000073BAAB9E0058
000073baab9dedb4  movaps xmm12, [r15+0x2A0]
000073baab9dedbc  vmovaps [rsp+0x80], xmm12
000073baab9dedc5  vmovaps xmm11, [rsp+0x80]
000073baab9dedce  por xmm12, xmm11
000073baab9dedd3  movaps xmm11, [r15+0x250]
000073baab9deddb  vmovaps [rsp+0x80], xmm11
000073baab9dede4  vmovaps xmm5, [rsp+0x80]
000073baab9deded  por xmm11, xmm5
000073baab9dedf2  vmovaps xmm4, [rsp+0x70]
000073baab9dedf8  vpermilpd xmm4, xmm4, 0x00
000073baab9dedfe  movaps xmm3, xmm5
000073baab9dee01  mulpd xmm3, xmm4
000073baab9dee05  vcmppd xmm2, xmm3, xmm3, 0x03
000073baab9dee0a  ptest xmm2, xmm2
000073baab9dee0f  jnz 0x000073BAAB9E019A
000073baab9dee15  mov [rsp+0x80], rax
000073baab9dee1d  xor eax, eax
000073baab9dee1f  mov r12d, 0x40
000073baab9dee25  mov r11d, 0x200
000073baab9dee2b  cmp r12, r11
000073baab9dee2e  cmc
000073baab9dee2f  lahf
000073baab9dee30  seto al
000073baab9dee33  mov [r15+0x108], eax
000073baab9dee3a  movaps xmm5, xmm8
000073baab9dee3e  addpd xmm5, xmm15
000073baab9dee43  vcmppd xmm4, xmm5, xmm5, 0x03
000073baab9dee48  ptest xmm4, xmm4
000073baab9dee4d  jnz 0x000073BAAB9E02DA
000073baab9dee53  movaps xmm8, [r15+0x1B0]
000073baab9dee5b  movaps xmm4, xmm9
000073baab9dee5f  addpd xmm4, xmm8
000073baab9dee64  vcmppd xmm2, xmm4, xmm4, 0x03
000073baab9dee69  ptest xmm2, xmm2
000073baab9dee6e  jnz 0x000073BAAB9E041C
000073baab9dee74  movaps xmm9, xmm10
000073baab9dee78  addpd xmm9, xmm8
000073baab9dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
000073baab9dee83  ptest xmm2, xmm2
000073baab9dee88  jnz 0x000073BAAB9E055E
000073baab9dee8e  movaps xmm10, [r15+0x2F0]
000073baab9dee96  vmovaps [rsp+0x90], xmm10
000073baab9dee9f  vmovaps xmm8, [rsp+0x90]
000073baab9deea8  por xmm10, xmm8
000073baab9deead  movaps xmm8, [r15+0x2E0]
000073baab9deeb5  vmovaps [rsp+0x90], xmm8
000073baab9deebe  vmovaps xmm2, [rsp+0x90]
000073baab9deec7  por xmm8, xmm2
000073baab9deecc  movaps xmm2, [r15+0x2D0]
000073baab9deed4  vmovaps [rsp+0x90], xmm2
000073baab9deedd  vmovaps [rsp+0xA0], xmm1
000073baab9deee6  vmovaps xmm1, [rsp+0x90]
000073baab9deeef  por xmm2, xmm1
000073baab9deef3  movaps xmm1, [r15+0x200]
000073baab9deefb  vmovaps [rsp+0x90], xmm1
000073baab9def04  vmovaps [rsp+0xB0], xmm15
000073baab9def0d  vmovaps xmm15, [rsp+0x90]
000073baab9def16  por xmm1, xmm15
000073baab9def1b  movaps xmm15, [r15+0x1C0]
000073baab9def23  vmovaps [rsp+0x90], xmm15
000073baab9def2c  vmovaps [rsp+0xC0], xmm1
000073baab9def35  vmovaps xmm1, [rsp+0x90]
000073baab9def3e  por xmm15, xmm1
000073baab9def43  movaps xmm1, [r15+0x190]
000073baab9def4b  vmovaps [rsp+0x90], xmm1
000073baab9def54  vmovaps [rsp+0xD0], xmm15
000073baab9def5d  vmovaps xmm15, [rsp+0x90]
000073baab9def66  por xmm1, xmm15
000073baab9def6b  movaps xmm15, [r15+0x300]
000073baab9def73  vmovaps [rsp+0x90], xmm15
000073baab9def7c  vmovaps [rsp+0xE0], xmm1
000073baab9def85  vmovaps xmm1, [rsp+0x90]
000073baab9def8e  por xmm15, xmm1
000073baab9def93  mov rax, [rsp+0x80]
000073baab9def9b  lea r12, [rax+0xA0]
000073baab9defa2  movups xmm1, [r13+r12*1]
000073baab9defa8  lea r12, [rax+0xB0]
000073baab9defaf  vmovaps [rsp+0x80], xmm1
000073baab9defb8  movups xmm1, [r13+r12*1]
000073baab9defbe  vmovaps [rsp+0x90], xmm1
000073baab9defc7  vmovaps [rsp+0xF0], xmm15
000073baab9defd0  vmovaps xmm15, [rsp+0xB0]
000073baab9defd9  vmovaps [rsp+0xB0], xmm14
000073baab9defe2  movaps xmm1, xmm6
000073baab9defe5  addpd xmm1, xmm15
000073baab9defea  vcmppd xmm14, xmm1, xmm1, 0x03
000073baab9defef  ptest xmm14, xmm14
000073baab9deff5  jnz 0x000073BAAB9E06B6
000073baab9deffb  lea r12, [rax+0xF0]
000073baab9df002  movups xmm15, [r13+r12*1]
000073baab9df008  movaps xmm14, xmm4
000073baab9df00c  addpd xmm14, xmm3
000073baab9df011  vcmppd xmm6, xmm14, xmm14, 0x03
000073baab9df017  ptest xmm6, xmm6
000073baab9df01c  jnz 0x000073BAAB9E0801
000073baab9df022  movaps xmm6, xmm9
000073baab9df026  addpd xmm6, xmm7
000073baab9df02a  vcmppd xmm4, xmm6, xmm6, 0x03
000073baab9df02f  ptest xmm4, xmm4
000073baab9df034  jnz 0x000073BAAB9E0943
000073baab9df03a  vmovaps xmm9, [rsp+0x70]
000073baab9df040  vpermilpd xmm9, xmm9, 0x00
000073baab9df046  vmovaps xmm4, [rsp+0x90]
000073baab9df04f  movaps xmm7, xmm4
000073baab9df052  mulpd xmm7, xmm9
000073baab9df057  vcmppd xmm3, xmm7, xmm7, 0x03
000073baab9df05c  ptest xmm3, xmm3
000073baab9df061  jnz 0x000073BAAB9E0A84
000073baab9df067  vmovaps xmm9, [rsp+0x50]
000073baab9df06d  vpermilpd xmm9, xmm9, 0x00
000073baab9df073  movaps xmm4, xmm15
000073baab9df077  mulpd xmm4, xmm9
000073baab9df07c  vcmppd xmm3, xmm4, xmm4, 0x03
000073baab9df081  ptest xmm3, xmm3
000073baab9df086  jnz 0x000073BAAB9E0BC5
000073baab9df08c  lea r12, [rax+0xE0]
000073baab9df093  movups xmm15, [r13+r12*1]
000073baab9df099  vmovaps xmm9, [rsp+0x70]
000073baab9df09f  vpermilpd xmm9, xmm9, 0x00
000073baab9df0a5  vmovaps [rsp+0x70], xmm1
000073baab9df0ab  vmovaps xmm1, [rsp+0x80]
000073baab9df0b4  vmovaps [rsp+0x80], xmm15
000073baab9df0bd  movaps xmm3, xmm1
000073baab9df0c0  mulpd xmm3, xmm9
000073baab9df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
000073baab9df0ca  ptest xmm15, xmm15
000073baab9df0d0  jnz 0x000073BAAB9E0D11
000073baab9df0d6  vmovaps xmm1, [rsp+0xF0]
000073baab9df0df  vmovaps xmm15, [rsp+0xF0]
000073baab9df0e8  por xmm1, xmm15
000073baab9df0ed  movaps [r15+0x300], xmm1
000073baab9df0f5  vmovaps xmm15, [rsp+0xE0]
000073baab9df0fe  vmovaps xmm9, [rsp+0xE0]
000073baab9df107  por xmm15, xmm9
000073baab9df10c  movaps [r15+0x190], xmm15
000073baab9df114  vmovaps xmm9, [rsp+0x50]
000073baab9df11a  vpermilpd xmm9, xmm9, 0x00
000073baab9df120  vmovaps [rsp+0x90], xmm1
000073baab9df129  vmovaps [rsp+0xE0], xmm15
000073baab9df132  vmovaps xmm15, [rsp+0x80]
000073baab9df13b  vmovaps [rsp+0x80], xmm14
000073baab9df144  movaps xmm1, xmm15
000073baab9df148  mulpd xmm1, xmm9
000073baab9df14d  vcmppd xmm14, xmm1, xmm1, 0x03
000073baab9df152  ptest xmm14, xmm14
000073baab9df158  jnz 0x000073BAAB9E0E52
000073baab9df15e  lea r12, [rax+0x90]
000073baab9df165  movups xmm15, [r13+r12*1]
000073baab9df16b  vmovaps xmm14, [rsp+0xD0]
000073baab9df174  vmovaps xmm9, [rsp+0xD0]
000073baab9df17d  por xmm14, xmm9
000073baab9df182  movaps [r15+0x1C0], xmm14
000073baab9df18a  vmovaps xmm9, [rsp+0xC0]
000073baab9df193  vmovaps [rsp+0xD0], xmm1
000073baab9df19c  vmovaps xmm1, [rsp+0xC0]
000073baab9df1a5  por xmm9, xmm1
000073baab9df1aa  movaps [r15+0x200], xmm9
000073baab9df1b2  vmovaps [rsp+0xC0], xmm2
000073baab9df1bb  vmovaps xmm1, [rsp+0xC0]
000073baab9df1c4  por xmm2, xmm1
000073baab9df1c8  movaps [r15+0x2D0], xmm2
000073baab9df1d0  vmovaps [rsp+0xC0], xmm8
000073baab9df1d9  vmovaps xmm1, [rsp+0xC0]
000073baab9df1e2  por xmm8, xmm1
000073baab9df1e7  movaps [r15+0x2E0], xmm8
000073baab9df1ef  vmovaps [rsp+0xC0], xmm15
000073baab9df1f8  movaps xmm1, xmm5
000073baab9df1fb  addpd xmm1, xmm7
000073baab9df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
000073baab9df204  ptest xmm15, xmm15
000073baab9df20a  jnz 0x000073BAAB9E0F9E
000073baab9df210  vmovaps xmm15, [rsp+0x50]
000073baab9df216  vpermilpd xmm15, xmm15, 0x00
000073baab9df21c  vmovaps xmm5, [rsp+0xC0]
000073baab9df225  vmovaps [rsp+0xC0], xmm1
000073baab9df22e  movaps xmm7, xmm5
000073baab9df231  mulpd xmm7, xmm15
000073baab9df236  vcmppd xmm1, xmm7, xmm7, 0x03
000073baab9df23b  ptest xmm1, xmm1
000073baab9df240  jnz 0x000073BAAB9E10DE
000073baab9df246  lea r12, [rax+0x80]
000073baab9df24d  movups xmm1, [r13+r12*1]
000073baab9df253  vmovaps xmm5, [rsp+0x70]
000073baab9df259  vmovaps [rsp+0x70], xmm1
000073baab9df25f  movaps xmm15, xmm5
000073baab9df263  addpd xmm15, xmm3
000073baab9df268  vcmppd xmm1, xmm15, xmm15, 0x03
000073baab9df26e  ptest xmm1, xmm1
000073baab9df273  jnz 0x000073BAAB9E1229
000073baab9df279  vmovaps xmm5, [rsp+0x80]
000073baab9df282  movaps xmm1, xmm5
000073baab9df285  addpd xmm1, xmm4
000073baab9df289  vcmppd xmm3, xmm1, xmm1, 0x03
000073baab9df28e  ptest xmm3, xmm3
000073baab9df293  jnz 0x000073BAAB9E136B
000073baab9df299  vmovaps [rsp+0x80], xmm10
000073baab9df2a2  vmovaps xmm5, [rsp+0x80]
000073baab9df2ab  por xmm10, xmm5
000073baab9df2b0  movaps [r15+0x2F0], xmm10
000073baab9df2b8  vmovaps xmm5, [rsp+0x50]
000073baab9df2be  vpermilpd xmm5, xmm5, 0x00
000073baab9df2c4  vmovaps xmm3, [rsp+0x70]
000073baab9df2ca  vmovaps [rsp+0x50], xmm1
000073baab9df2d0  movaps xmm4, xmm3
000073baab9df2d3  mulpd xmm4, xmm5
000073baab9df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
000073baab9df2dc  ptest xmm1, xmm1
000073baab9df2e1  jnz 0x000073BAAB9E14AB
000073baab9df2e7  lea r12, [rax+0xD0]
000073baab9df2ee  movups xmm1, [r13+r12*1]
000073baab9df2f4  vmovaps xmm3, [rsp+0xD0]
000073baab9df2fd  vmovaps [rsp+0x70], xmm1
000073baab9df303  movaps xmm5, xmm6
000073baab9df306  addpd xmm5, xmm3
000073baab9df30a  vcmppd xmm1, xmm5, xmm5, 0x03
000073baab9df30f  ptest xmm1, xmm1
000073baab9df314  jnz 0x000073BAAB9E15F5
000073baab9df31a  vmovaps xmm1, [rsp+0x60]
000073baab9df320  vpermilpd xmm1, xmm1, 0x00
000073baab9df326  movaps xmm6, xmm9
000073baab9df32a  mulpd xmm6, xmm1
000073baab9df32e  vcmppd xmm3, xmm6, xmm6, 0x03
000073baab9df333  ptest xmm3, xmm3
000073baab9df338  jnz 0x000073BAAB9E1735
000073baab9df33e  movaps [r15+0x260], xmm6
000073baab9df346  vxorps xmm1, xmm1, xmm1
000073baab9df34a  vpbroadcastq xmm1, xmm1
000073baab9df34f  movaps [r15+0x1B0], xmm1
000073baab9df357  vmovaps xmm1, [rsp+0x60]
000073baab9df35d  vpermilpd xmm1, xmm1, 0x00
000073baab9df363  vmovaps xmm3, [rsp+0x70]
000073baab9df369  vmovaps [rsp+0x70], xmm15
000073baab9df36f  movaps xmm9, xmm3
000073baab9df373  mulpd xmm9, xmm1
000073baab9df378  vcmppd xmm15, xmm9, xmm9, 0x03
000073baab9df37e  ptest xmm15, xmm15
000073baab9df384  jnz 0x000073BAAB9E1876
000073baab9df38a  lea r12, [rax+0xC0]
000073baab9df391  movups xmm1, [r13+r12*1]
000073baab9df397  vmovaps xmm3, [rsp+0xC0]
000073baab9df3a0  vmovaps [rsp+0x80], xmm1
000073baab9df3a9  movaps xmm15, xmm3
000073baab9df3ad  addpd xmm15, xmm7
000073baab9df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
000073baab9df3b8  ptest xmm1, xmm1
000073baab9df3bd  jnz 0x000073BAAB9E19C2
000073baab9df3c3  vmovaps [rsp+0xC0], xmm13
000073baab9df3cc  vmovaps xmm1, [rsp+0xC0]
000073baab9df3d5  por xmm13, xmm1
000073baab9df3da  movaps [r15+0x270], xmm13
000073baab9df3e2  vmovaps xmm1, [rsp+0xB0]
000073baab9df3eb  vmovaps xmm7, [rsp+0xB0]
000073baab9df3f4  por xmm1, xmm7
000073baab9df3f8  movaps [r15+0x1A0], xmm1
000073baab9df400  vmovaps xmm1, [rsp+0x60]
000073baab9df406  vpermilpd xmm1, xmm1, 0x00
000073baab9df40c  vmovaps [rsp+0xB0], xmm1
000073baab9df415  vmovaps xmm1, [rsp+0x80]
000073baab9df41e  vmovaps [rsp+0x80], xmm15
000073baab9df427  vmovaps xmm15, [rsp+0xB0]
000073baab9df430  vmovaps [rsp+0xB0], xmm14
000073baab9df439  movaps xmm3, xmm1
000073baab9df43c  mulpd xmm3, xmm15
000073baab9df441  vcmppd xmm14, xmm3, xmm3, 0x03
000073baab9df446  ptest xmm14, xmm14
000073baab9df44c  jnz 0x000073BAAB9E1B04
000073baab9df452  lea r12, [rax+0x20]
000073baab9df456  movups xmm1, [r13+r12*1]
000073baab9df45c  movaps [r15+0x110], xmm1
000073baab9df464  vmovaps xmm14, [rsp+0x70]
000073baab9df46a  vmovaps [rsp+0x70], xmm1
000073baab9df470  movaps xmm15, xmm14
000073baab9df474  addpd xmm15, xmm4
000073baab9df479  vcmppd xmm1, xmm15, xmm15, 0x03
000073baab9df47f  ptest xmm1, xmm1
000073baab9df484  jnz 0x000073BAAB9E1C4F
000073baab9df48a  vmovaps xmm1, [rsp+0x60]
000073baab9df490  vpermilpd xmm1, xmm1, 0x00
000073baab9df496  movaps xmm14, xmm2
000073baab9df49a  mulpd xmm14, xmm1
000073baab9df49f  vcmppd xmm4, xmm14, xmm14, 0x03
000073baab9df4a5  ptest xmm4, xmm4
000073baab9df4aa  jnz 0x000073BAAB9E1D92
000073baab9df4b0  vmovaps xmm4, [rsp+0x50]
000073baab9df4b6  movaps xmm1, xmm4
000073baab9df4b9  addpd xmm1, xmm9
000073baab9df4be  vcmppd xmm2, xmm1, xmm1, 0x03
000073baab9df4c3  ptest xmm2, xmm2
000073baab9df4c8  jnz 0x000073BAAB9E1ED4
000073baab9df4ce  vmovaps xmm9, [rsp+0x30]
000073baab9df4d4  vpermilpd xmm9, xmm9, 0x00
000073baab9df4da  vmovaps xmm2, [rsp+0x70]
000073baab9df4e0  vmovaps [rsp+0x50], xmm1
000073baab9df4e6  movaps xmm4, xmm2
000073baab9df4e9  mulpd xmm4, xmm9
000073baab9df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
000073baab9df4f3  ptest xmm1, xmm1
000073baab9df4f8  jnz 0x000073BAAB9E2015
000073baab9df4fe  vmovaps xmm1, [rsp+0x30]
000073baab9df504  vpermilpd xmm1, xmm1, 0x00
000073baab9df50a  vmovaps xmm2, [rsp+0x90]
000073baab9df513  vmovaps [rsp+0x60], xmm15
000073baab9df519  movaps xmm9, xmm2
000073baab9df51d  mulpd xmm9, xmm1
000073baab9df522  vcmppd xmm15, xmm9, xmm9, 0x03
000073baab9df528  ptest xmm15, xmm15
000073baab9df52e  jnz 0x000073BAAB9E2156
000073baab9df534  vmovaps xmm15, [rsp+0x80]
000073baab9df53d  movaps xmm1, xmm15
000073baab9df541  addpd xmm1, xmm6
000073baab9df545  vcmppd xmm2, xmm1, xmm1, 0x03
000073baab9df54a  ptest xmm2, xmm2
000073baab9df54f  jnz 0x000073BAAB9E2298
000073baab9df555  movaps xmm15, xmm5
000073baab9df559  addpd xmm15, xmm3
000073baab9df55e  vcmppd xmm6, xmm15, xmm15, 0x03
000073baab9df564  ptest xmm6, xmm6
000073baab9df569  jnz 0x000073BAAB9E23D9
000073baab9df56f  vmovaps xmm6, [rsp+0x30]
000073baab9df575  vpermilpd xmm6, xmm6, 0x00
000073baab9df57b  movaps xmm5, xmm8
000073baab9df57f  mulpd xmm5, xmm6
000073baab9df583  vcmppd xmm3, xmm5, xmm5, 0x03
000073baab9df588  ptest xmm3, xmm3
000073baab9df58d  jnz 0x000073BAAB9E251B
000073baab9df593  vmovaps xmm8, [rsp+0x30]
000073baab9df599  vpermilpd xmm8, xmm8, 0x00
000073baab9df59f  movaps xmm6, xmm10
000073baab9df5a3  mulpd xmm6, xmm8
000073baab9df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
000073baab9df5ad  ptest xmm3, xmm3
000073baab9df5b2  jnz 0x000073BAAB9E265C
000073baab9df5b8  vmovaps xmm8, [rsp+0x60]
000073baab9df5be  movaps xmm10, xmm8
000073baab9df5c2  addpd xmm10, xmm14
000073baab9df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
000073baab9df5cd  ptest xmm3, xmm3
000073baab9df5d2  jnz 0x000073BAAB9E279E
000073baab9df5d8  vmovaps xmm8, [rsp+0x50]
000073baab9df5de  movaps xmm14, xmm8
000073baab9df5e2  addpd xmm14, xmm4
000073baab9df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
000073baab9df5ed  ptest xmm3, xmm3
000073baab9df5f2  jnz 0x000073BAAB9E28E2
000073baab9df5f8  vmovaps xmm8, [rsp+0x40]
000073baab9df5fe  vpermilpd xmm8, xmm8, 0x00
000073baab9df604  movaps xmm4, xmm13
000073baab9df608  mulpd xmm4, xmm8
000073baab9df60d  vcmppd xmm3, xmm4, xmm4, 0x03
000073baab9df612  ptest xmm3, xmm3
000073baab9df617  jnz 0x000073BAAB9E2A25
000073baab9df61d  movaps xmm13, xmm15
000073baab9df621  addpd xmm13, xmm9
000073baab9df626  vcmppd xmm8, xmm13, xmm13, 0x03
000073baab9df62c  ptest xmm8, xmm8
000073baab9df632  jnz 0x000073BAAB9E2B67
000073baab9df638  movaps xmm15, xmm1
000073baab9df63c  addpd xmm15, xmm5
000073baab9df641  vcmppd xmm9, xmm15, xmm15, 0x03
000073baab9df647  ptest xmm9, xmm9
000073baab9df64d  jnz 0x000073BAAB9E2CAB
000073baab9df653  vmovaps [rsp+0x30], xmm11
000073baab9df659  vmovaps xmm1, [rsp+0x30]
000073baab9df65f  por xmm11, xmm1
000073baab9df664  movaps [r15+0x250], xmm11
000073baab9df66c  vmovaps [rsp+0x30], xmm12
000073baab9df672  vmovaps xmm1, [rsp+0x30]
000073baab9df678  por xmm12, xmm1
000073baab9df67d  movaps [r15+0x2A0], xmm12
000073baab9df685  vmovaps xmm1, [rsp+0xA0]
000073baab9df68e  vmovaps xmm11, [rsp+0xA0]
000073baab9df697  por xmm1, xmm11
000073baab9df69c  movaps [r15+0x1D0], xmm1
000073baab9df6a4  lea r12, [rax+0x40]
000073baab9df6a8  movups xmm1, [r13+r12*1]
000073baab9df6ae  movaps [r15+0x2C0], xmm1
000073baab9df6b6  vmovaps xmm11, [rsp+0x40]
000073baab9df6bc  vpermilpd xmm11, xmm11, 0x00
000073baab9df6c2  vmovaps xmm8, [rsp+0xE0]
000073baab9df6cb  movaps xmm9, xmm8
000073baab9df6cf  mulpd xmm9, xmm11
000073baab9df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
000073baab9df6da  ptest xmm5, xmm5
000073baab9df6df  jnz 0x000073BAAB9E2DF7
000073baab9df6e5  movaps xmm11, xmm10
000073baab9df6e9  addpd xmm11, xmm6
000073baab9df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
000073baab9df6f4  ptest xmm8, xmm8
000073baab9df6fa  jnz 0x000073BAAB9E2F3B
000073baab9df700  movaps xmm10, xmm14
000073baab9df704  addpd xmm10, xmm4
000073baab9df709  vcmppd xmm8, xmm10, xmm10, 0x03
000073baab9df70f  ptest xmm8, xmm8
000073baab9df715  jnz 0x000073BAAB9E307E
000073baab9df71b  vmovaps xmm14, [rsp+0x40]
000073baab9df721  vpermilpd xmm14, xmm14, 0x00
000073baab9df727  movaps xmm8, xmm1
000073baab9df72b  mulpd xmm8, xmm14
000073baab9df730  vcmppd xmm6, xmm8, xmm8, 0x03
000073baab9df736  ptest xmm6, xmm6
000073baab9df73b  jnz 0x000073BAAB9E31C1
000073baab9df741  movaps xmm1, [r15+0x2B0]
000073baab9df749  vmovaps xmm14, [rsp+0x40]
000073baab9df74f  vpermilpd xmm14, xmm14, 0x00
000073baab9df755  movaps xmm6, xmm1
000073baab9df758  mulpd xmm6, xmm14
000073baab9df75d  vcmppd xmm5, xmm6, xmm6, 0x03
000073baab9df762  ptest xmm5, xmm5
000073baab9df767  jnz 0x000073BAAB9E3304
000073baab9df76d  vmovaps xmm1, [rsp+0x10]
000073baab9df773  vpermilpd xmm1, xmm1, 0x00
000073baab9df779  movaps xmm14, xmm12
000073baab9df77d  mulpd xmm14, xmm1
000073baab9df782  vcmppd xmm5, xmm14, xmm14, 0x03
000073baab9df788  ptest xmm5, xmm5
000073baab9df78d  jnz 0x000073BAAB9E3445
000073baab9df793  movaps xmm1, xmm13
000073baab9df797  addpd xmm1, xmm9
000073baab9df79c  vcmppd xmm12, xmm1, xmm1, 0x03
000073baab9df7a1  ptest xmm12, xmm12
000073baab9df7a7  jnz 0x000073BAAB9E3588
000073baab9df7ad  vmovaps xmm13, [rsp+0x10]
000073baab9df7b3  vpermilpd xmm13, xmm13, 0x00
000073baab9df7b9  movaps xmm12, xmm7
000073baab9df7bd  mulpd xmm12, xmm13
000073baab9df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
000073baab9df7c8  ptest xmm9, xmm9
000073baab9df7ce  jnz 0x000073BAAB9E36CA
000073baab9df7d4  movaps xmm13, xmm15
000073baab9df7d8  addpd xmm13, xmm8
000073baab9df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
000073baab9df7e3  ptest xmm9, xmm9
000073baab9df7e9  jnz 0x000073BAAB9E380D
000073baab9df7ef  movaps xmm15, [r15+0x290]
000073baab9df7f7  vmovaps xmm9, [rsp+0x10]
000073baab9df7fd  vpermilpd xmm9, xmm9, 0x00
000073baab9df803  movaps xmm8, xmm15
000073baab9df807  mulpd xmm8, xmm9
000073baab9df80c  vcmppd xmm7, xmm8, xmm8, 0x03
000073baab9df812  ptest xmm7, xmm7
000073baab9df817  jnz 0x000073BAAB9E3951
000073baab9df81d  movaps xmm15, xmm11
000073baab9df821  addpd xmm15, xmm6
000073baab9df826  vcmppd xmm9, xmm15, xmm15, 0x03
000073baab9df82c  ptest xmm9, xmm9
000073baab9df832  jnz 0x000073BAAB9E3A95
000073baab9df838  movaps xmm11, [r15+0x1E0]
000073baab9df840  vmovaps xmm9, [rsp+0x10]
000073baab9df846  vpermilpd xmm9, xmm9, 0x00
000073baab9df84c  movaps xmm7, xmm11
000073baab9df850  mulpd xmm7, xmm9
000073baab9df855  vcmppd xmm6, xmm7, xmm7, 0x03
000073baab9df85a  ptest xmm6, xmm6
000073baab9df85f  jnz 0x000073BAAB9E3BD8
000073baab9df865  movaps xmm11, xmm10
000073baab9df869  addpd xmm11, xmm14
000073baab9df86e  vcmppd xmm9, xmm11, xmm11, 0x03
000073baab9df874  ptest xmm9, xmm9
000073baab9df87a  jnz 0x000073BAAB9E3D1A
000073baab9df880  lea r12, [rax+0x70]
000073baab9df884  movups xmm14, [r13+r12*1]
000073baab9df88a  movaps [r15+0x240], xmm14
000073baab9df892  movaps xmm10, xmm1
000073baab9df896  addpd xmm10, xmm12
000073baab9df89b  vcmppd xmm9, xmm10, xmm10, 0x03
000073baab9df8a1  ptest xmm9, xmm9
000073baab9df8a7  jnz 0x000073BAAB9E3E68
000073baab9df8ad  movaps [r15+0x170], xmm10
000073baab9df8b5  vmovaps xmm1, [rsp+0x20]
000073baab9df8bb  vpermilpd xmm1, xmm1, 0x00
000073baab9df8c1  movaps xmm12, xmm14
000073baab9df8c5  mulpd xmm12, xmm1
000073baab9df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
000073baab9df8d0  ptest xmm9, xmm9
000073baab9df8d6  jnz 0x000073BAAB9E3FAB
000073baab9df8dc  vmovaps xmm1, [rsp+0x20]
000073baab9df8e2  vpermilpd xmm1, xmm1, 0x00
000073baab9df8e8  vmovaps xmm9, [rsp+0xB0]
000073baab9df8f1  movaps xmm14, xmm9
000073baab9df8f5  mulpd xmm14, xmm1
000073baab9df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
000073baab9df900  ptest xmm6, xmm6
000073baab9df905  jnz 0x000073BAAB9E40EE
000073baab9df90b  movaps [r15+0x180], xmm14
000073baab9df913  movaps xmm1, xmm13
000073baab9df917  addpd xmm1, xmm8
000073baab9df91c  vcmppd xmm9, xmm1, xmm1, 0x03
000073baab9df921  ptest xmm9, xmm9
000073baab9df927  jnz 0x000073BAAB9E4231
000073baab9df92d  movaps [r15+0x210], xmm1
000073baab9df935  movups xmm13, [r13+rax*1]
000073baab9df93b  lea r12, [rax+0x10]
000073baab9df93f  movups xmm9, [r13+r12*1]
000073baab9df945  movaps [r15+0x230], xmm9
000073baab9df94d  movaps xmm8, xmm15
000073baab9df951  addpd xmm8, xmm7
000073baab9df956  vcmppd xmm6, xmm8, xmm8, 0x03
000073baab9df95c  ptest xmm6, xmm6
000073baab9df961  jnz 0x000073BAAB9E4387
000073baab9df967  movaps [r15+0x130], xmm8
000073baab9df96f  vmovaps xmm15, [rsp+0x20]
000073baab9df975  vpermilpd xmm15, xmm15, 0x00
000073baab9df97b  movaps xmm7, xmm9
000073baab9df97f  mulpd xmm7, xmm15
000073baab9df984  vcmppd xmm6, xmm7, xmm7, 0x03
000073baab9df989  ptest xmm6, xmm6
000073baab9df98e  jnz 0x000073BAAB9E44CA
000073baab9df994  movaps [r15+0x220], xmm7
000073baab9df99c  vmovaps xmm15, [rsp+0x20]
000073baab9df9a2  vpermilpd xmm15, xmm15, 0x00
000073baab9df9a8  movaps xmm9, xmm13
000073baab9df9ac  mulpd xmm9, xmm15
000073baab9df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
000073baab9df9b7  ptest xmm6, xmm6
000073baab9df9bc  jnz 0x000073BAAB9E460C
000073baab9df9c2  movaps xmm15, xmm11
000073baab9df9c6  addpd xmm15, xmm12
000073baab9df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
000073baab9df9d1  ptest xmm13, xmm13
000073baab9df9d7  jnz 0x000073BAAB9E4750
000073baab9df9dd  movaps [r15+0x140], xmm15
000073baab9df9e5  movaps xmm13, xmm10
000073baab9df9e9  addpd xmm13, xmm14
000073baab9df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
000073baab9df9f4  ptest xmm12, xmm12
000073baab9df9fa  jnz 0x000073BAAB9E4894
000073baab9dfa00  movaps [r15+0x150], xmm13
000073baab9dfa08  movaps xmm14, xmm1
000073baab9dfa0c  addpd xmm14, xmm7
000073baab9dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
000073baab9dfa17  ptest xmm12, xmm12
000073baab9dfa1d  jnz 0x000073BAAB9E49D8
000073baab9dfa23  movaps [r15+0x160], xmm14
000073baab9dfa2b  movaps xmm1, xmm8
000073baab9dfa2f  addpd xmm1, xmm9
000073baab9dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
000073baab9dfa39  ptest xmm12, xmm12
000073baab9dfa3f  jnz 0x000073BAAB9E4B1A
000073baab9dfa45  movaps [r15+0x120], xmm1
000073baab9dfa4d  movups [r13+r14*1], xmm15
000073baab9dfa53  lea rax, [r14+0x10]
000073baab9dfa57  movups [r13+rax*1], xmm13
000073baab9dfa5d  lea rax, [r14+0x20]
000073baab9dfa61  movups [r13+rax*1], xmm14
000073baab9dfa67  lea rax, [r14+0x30]
000073baab9dfa6b  movups [r13+rax*1], xmm1
000073baab9dfa71  mov eax, [r15+0x108]
000073baab9dfa78  sahf
000073baab9dfa79  jnz 0x000073BAAB9DFAAB
000073baab9dfa7b  cmp dword ptr [r15+0x318], 0x00
000073baab9dfa83  jz 0x000073BAAB9DEAE0
000073baab9dfa89  nop [rax+rax*1], ax
000073baab9dfa92  nop [rax+rax*1], eax
000073baab9dfa9a  mov eax, 0x4106D0
000073baab9dfa9f  mov [r15+0x100], rax
000073baab9dfaa6  jmp 0x000073BAAB7FE110
000073baab9dfaab  cmp dword ptr [r15+0x318], 0x00
000073baab9dfab3  jz 0x000073BAAB9D89C0
000073baab9dfab9  nop [rax+rax*1], ax
000073baab9dfac2  nop [rax+rax*1], eax
000073baab9dfaca  mov eax, 0x410504
000073baab9dfacf  mov [r15+0x100], rax
000073baab9dfad6  jmp 0x000073BAAB7FE110
000073baab9dfadb  int3
000073baab9dfadc  call 0x000073BAAB8E27E0
000073baab9dfae1  jmp 0x000073BAAB9DEBBF
000073baab9dfae6  call 0x000073BAAB8E1570
000073baab9dfaeb  jmp 0x000073BAAB9DEBC8
000073baab9dfaf0  call 0x000073BAAB8E27E0
000073baab9dfaf5  jmp 0x000073BAAB9DEC24
000073baab9dfafa  call 0x000073BAAB8E1570
000073baab9dfaff  jmp 0x000073BAAB9DEC2D
000073baab9dfb04  call 0x000073BAAB8E27E0
000073baab9dfb09  jmp 0x000073BAAB9DEC70
000073baab9dfb0e  call 0x000073BAAB8E1570
000073baab9dfb13  jmp 0x000073BAAB9DEC79
000073baab9dfb18  call 0x000073BAAB80DC20
000073baab9dfb1d  jmp 0x000073BAAB9DECB8
000073baab9dfb22  call 0x000073BAAB8D59C0
000073baab9dfb27  jmp 0x000073BAAB9DECCB
000073baab9dfb2c  call 0x000073BAAB8E0E30
000073baab9dfb31  jmp 0x000073BAAB9DECE9
000073baab9dfb36  call 0x000073BAAB8DFBC0
000073baab9dfb3b  jmp 0x000073BAAB9DECF3
000073baab9dfb40  call 0x000073BAAB8DE950
000073baab9dfb45  jmp 0x000073BAAB9DECFD
000073baab9dfb4a  sub rsp, 0x08
000073baab9dfb4e  push rax
000073baab9dfb4f  push rcx
000073baab9dfb50  push rdx
000073baab9dfb51  push rdi
000073baab9dfb52  push rsi
000073baab9dfb53  push r8
000073baab9dfb55  push r9
000073baab9dfb57  push r10
000073baab9dfb59  push r11
000073baab9dfb5b  sub rsp, 0xF0
000073baab9dfb62  vmovaps [rsp], xmm0
000073baab9dfb67  vmovaps [rsp+0x10], xmm1
000073baab9dfb6d  vmovaps [rsp+0x20], xmm2
000073baab9dfb73  vmovaps [rsp+0x30], xmm3
000073baab9dfb79  vmovaps [rsp+0x40], xmm4
000073baab9dfb7f  vmovaps [rsp+0x50], xmm5
000073baab9dfb85  vmovaps [rsp+0x60], xmm6
000073baab9dfb8b  vmovaps [rsp+0x70], xmm7
000073baab9dfb91  vmovaps [rsp+0x80], xmm9
000073baab9dfb9a  vmovaps [rsp+0x90], xmm10
000073baab9dfba3  vmovaps [rsp+0xA0], xmm11
000073baab9dfbac  vmovaps [rsp+0xB0], xmm12
000073baab9dfbb5  vmovaps [rsp+0xC0], xmm13
000073baab9dfbbe  vmovaps [rsp+0xD0], xmm14
000073baab9dfbc7  vmovaps [rsp+0xE0], xmm15
000073baab9dfbd0  sub rsp, 0x30
000073baab9dfbd4  movaps [rsp], xmm8
000073baab9dfbd9  movaps [rsp+0x10], xmm12
000073baab9dfbdf  movaps [rsp+0x20], xmm15
000073baab9dfbe5  lea rdi, [rsp]
000073baab9dfbe9  mov esi, 0x00
000073baab9dfbee  mov rax, 0x5F3F1062D530
000073baab9dfbf8  call rax
000073baab9dfbfa  movaps xmm8, [rsp]
000073baab9dfbff  add rsp, 0x30
000073baab9dfc03  vmovaps xmm0, [rsp]
000073baab9dfc08  vmovaps xmm1, [rsp+0x10]
000073baab9dfc0e  vmovaps xmm2, [rsp+0x20]
000073baab9dfc14  vmovaps xmm3, [rsp+0x30]
000073baab9dfc1a  vmovaps xmm4, [rsp+0x40]
000073baab9dfc20  vmovaps xmm5, [rsp+0x50]
000073baab9dfc26  vmovaps xmm6, [rsp+0x60]
000073baab9dfc2c  vmovaps xmm7, [rsp+0x70]
000073baab9dfc32  vmovaps xmm9, [rsp+0x80]
000073baab9dfc3b  vmovaps xmm10, [rsp+0x90]
000073baab9dfc44  vmovaps xmm11, [rsp+0xA0]
000073baab9dfc4d  vmovaps xmm12, [rsp+0xB0]
000073baab9dfc56  vmovaps xmm13, [rsp+0xC0]
000073baab9dfc5f  vmovaps xmm14, [rsp+0xD0]
000073baab9dfc68  vmovaps xmm15, [rsp+0xE0]
000073baab9dfc71  add rsp, 0xF0
000073baab9dfc78  pop r11
000073baab9dfc7a  pop r10
000073baab9dfc7c  pop r9
000073baab9dfc7e  pop r8
000073baab9dfc80  pop rsi
000073baab9dfc81  pop rdi
000073baab9dfc82  pop rdx
000073baab9dfc83  pop rcx
000073baab9dfc84  pop rax
000073baab9dfc85  add rsp, 0x08
000073baab9dfc89  jmp 0x000073BAAB9DED27
000073baab9dfc8e  sub rsp, 0x08
000073baab9dfc92  push rax
000073baab9dfc93  push rcx
000073baab9dfc94  push rdx
000073baab9dfc95  push rdi
000073baab9dfc96  push rsi
000073baab9dfc97  push r8
000073baab9dfc99  push r9
000073baab9dfc9b  push r10
000073baab9dfc9d  push r11
000073baab9dfc9f  sub rsp, 0xF0
000073baab9dfca6  vmovaps [rsp], xmm0
000073baab9dfcab  vmovaps [rsp+0x10], xmm1
000073baab9dfcb1  vmovaps [rsp+0x20], xmm2
000073baab9dfcb7  vmovaps [rsp+0x30], xmm3
000073baab9dfcbd  vmovaps [rsp+0x40], xmm4
000073baab9dfcc3  vmovaps [rsp+0x50], xmm5
000073baab9dfcc9  vmovaps [rsp+0x60], xmm6
000073baab9dfccf  vmovaps [rsp+0x70], xmm8
000073baab9dfcd5  vmovaps [rsp+0x80], xmm9
000073baab9dfcde  vmovaps [rsp+0x90], xmm10
000073baab9dfce7  vmovaps [rsp+0xA0], xmm11
000073baab9dfcf0  vmovaps [rsp+0xB0], xmm12
000073baab9dfcf9  vmovaps [rsp+0xC0], xmm13
000073baab9dfd02  vmovaps [rsp+0xD0], xmm14
000073baab9dfd0b  vmovaps [rsp+0xE0], xmm15
000073baab9dfd14  sub rsp, 0x30
000073baab9dfd18  movaps [rsp], xmm7
000073baab9dfd1c  movaps [rsp+0x10], xmm9
000073baab9dfd22  movaps [rsp+0x20], xmm15
000073baab9dfd28  lea rdi, [rsp]
000073baab9dfd2c  mov esi, 0x00
000073baab9dfd31  mov rax, 0x5F3F1062D530
000073baab9dfd3b  call rax
000073baab9dfd3d  movaps xmm7, [rsp]
000073baab9dfd41  add rsp, 0x30
000073baab9dfd45  vmovaps xmm0, [rsp]
000073baab9dfd4a  vmovaps xmm1, [rsp+0x10]
000073baab9dfd50  vmovaps xmm2, [rsp+0x20]
000073baab9dfd56  vmovaps xmm3, [rsp+0x30]
000073baab9dfd5c  vmovaps xmm4, [rsp+0x40]
000073baab9dfd62  vmovaps xmm5, [rsp+0x50]
000073baab9dfd68  vmovaps xmm6, [rsp+0x60]
000073baab9dfd6e  vmovaps xmm8, [rsp+0x70]
000073baab9dfd74  vmovaps xmm9, [rsp+0x80]
000073baab9dfd7d  vmovaps xmm10, [rsp+0x90]
000073baab9dfd86  vmovaps xmm11, [rsp+0xA0]
000073baab9dfd8f  vmovaps xmm12, [rsp+0xB0]
000073baab9dfd98  vmovaps xmm13, [rsp+0xC0]
000073baab9dfda1  vmovaps xmm14, [rsp+0xD0]
000073baab9dfdaa  vmovaps xmm15, [rsp+0xE0]
000073baab9dfdb3  add rsp, 0xF0
000073baab9dfdba  pop r11
000073baab9dfdbc  pop r10
000073baab9dfdbe  pop r9
000073baab9dfdc0  pop r8
000073baab9dfdc2  pop rsi
000073baab9dfdc3  pop rdi
000073baab9dfdc4  pop rdx
000073baab9dfdc5  pop rcx
000073baab9dfdc6  pop rax
000073baab9dfdc7  add rsp, 0x08
000073baab9dfdcb  jmp 0x000073BAAB9DED55
000073baab9dfdd0  sub rsp, 0x08
000073baab9dfdd4  push rax
000073baab9dfdd5  push rcx
000073baab9dfdd6  push rdx
000073baab9dfdd7  push rdi
000073baab9dfdd8  push rsi
000073baab9dfdd9  push r8
000073baab9dfddb  push r9
000073baab9dfddd  push r10
000073baab9dfddf  push r11
000073baab9dfde1  sub rsp, 0xF0
000073baab9dfde8  vmovaps [rsp], xmm0
000073baab9dfded  vmovaps [rsp+0x10], xmm1
000073baab9dfdf3  vmovaps [rsp+0x20], xmm2
000073baab9dfdf9  vmovaps [rsp+0x30], xmm3
000073baab9dfdff  vmovaps [rsp+0x40], xmm4
000073baab9dfe05  vmovaps [rsp+0x50], xmm5
000073baab9dfe0b  vmovaps [rsp+0x60], xmm6
000073baab9dfe11  vmovaps [rsp+0x70], xmm7
000073baab9dfe17  vmovaps [rsp+0x80], xmm8
000073baab9dfe20  vmovaps [rsp+0x90], xmm10
000073baab9dfe29  vmovaps [rsp+0xA0], xmm11
000073baab9dfe32  vmovaps [rsp+0xB0], xmm12
000073baab9dfe3b  vmovaps [rsp+0xC0], xmm13
000073baab9dfe44  vmovaps [rsp+0xD0], xmm14
000073baab9dfe4d  vmovaps [rsp+0xE0], xmm15
000073baab9dfe56  sub rsp, 0x30
000073baab9dfe5a  movaps [rsp], xmm9
000073baab9dfe5f  movaps [rsp+0x10], xmm12
000073baab9dfe65  movaps [rsp+0x20], xmm10
000073baab9dfe6b  lea rdi, [rsp]
000073baab9dfe6f  mov esi, 0x00
000073baab9dfe74  mov rax, 0x5F3F1062D530
000073baab9dfe7e  call rax
000073baab9dfe80  movaps xmm9, [rsp]
000073baab9dfe85  add rsp, 0x30
000073baab9dfe89  vmovaps xmm0, [rsp]
000073baab9dfe8e  vmovaps xmm1, [rsp+0x10]
000073baab9dfe94  vmovaps xmm2, [rsp+0x20]
000073baab9dfe9a  vmovaps xmm3, [rsp+0x30]
000073baab9dfea0  vmovaps xmm4, [rsp+0x40]
000073baab9dfea6  vmovaps xmm5, [rsp+0x50]
000073baab9dfeac  vmovaps xmm6, [rsp+0x60]
000073baab9dfeb2  vmovaps xmm7, [rsp+0x70]
000073baab9dfeb8  vmovaps xmm8, [rsp+0x80]
000073baab9dfec1  vmovaps xmm10, [rsp+0x90]
000073baab9dfeca  vmovaps xmm11, [rsp+0xA0]
000073baab9dfed3  vmovaps xmm12, [rsp+0xB0]
000073baab9dfedc  vmovaps xmm13, [rsp+0xC0]
000073baab9dfee5  vmovaps xmm14, [rsp+0xD0]
000073baab9dfeee  vmovaps xmm15, [rsp+0xE0]
000073baab9dfef7  add rsp, 0xF0
000073baab9dfefe  pop r11
000073baab9dff00  pop r10
000073baab9dff02  pop r9
000073baab9dff04  pop r8
000073baab9dff06  pop rsi
000073baab9dff07  pop rdi
000073baab9dff08  pop rdx
000073baab9dff09  pop rcx
000073baab9dff0a  pop rax
000073baab9dff0b  add rsp, 0x08
000073baab9dff0f  jmp 0x000073BAAB9DED79
000073baab9dff14  sub rsp, 0x08
000073baab9dff18  push rax
000073baab9dff19  push rcx
000073baab9dff1a  push rdx
000073baab9dff1b  push rdi
000073baab9dff1c  push rsi
000073baab9dff1d  push r8
000073baab9dff1f  push r9
000073baab9dff21  push r10
000073baab9dff23  push r11
000073baab9dff25  sub rsp, 0xF0
000073baab9dff2c  vmovaps [rsp], xmm0
000073baab9dff31  vmovaps [rsp+0x10], xmm1
000073baab9dff37  vmovaps [rsp+0x20], xmm2
000073baab9dff3d  vmovaps [rsp+0x30], xmm3
000073baab9dff43  vmovaps [rsp+0x40], xmm4
000073baab9dff49  vmovaps [rsp+0x50], xmm5
000073baab9dff4f  vmovaps [rsp+0x60], xmm6
000073baab9dff55  vmovaps [rsp+0x70], xmm7
000073baab9dff5b  vmovaps [rsp+0x80], xmm8
000073baab9dff64  vmovaps [rsp+0x90], xmm9
000073baab9dff6d  vmovaps [rsp+0xA0], xmm11
000073baab9dff76  vmovaps [rsp+0xB0], xmm12
000073baab9dff7f  vmovaps [rsp+0xC0], xmm13
000073baab9dff88  vmovaps [rsp+0xD0], xmm14
000073baab9dff91  vmovaps [rsp+0xE0], xmm15
000073baab9dff9a  sub rsp, 0x30
000073baab9dff9e  movaps [rsp], xmm10
000073baab9dffa3  movaps [rsp+0x10], xmm12
000073baab9dffa9  movaps [rsp+0x20], xmm11
000073baab9dffaf  lea rdi, [rsp]
000073baab9dffb3  mov esi, 0x00
000073baab9dffb8  mov rax, 0x5F3F1062D530
000073baab9dffc2  call rax
000073baab9dffc4  movaps xmm10, [rsp]
000073baab9dffc9  add rsp, 0x30
000073baab9dffcd  vmovaps xmm0, [rsp]
000073baab9dffd2  vmovaps xmm1, [rsp+0x10]
000073baab9dffd8  vmovaps xmm2, [rsp+0x20]
000073baab9dffde  vmovaps xmm3, [rsp+0x30]
000073baab9dffe4  vmovaps xmm4, [rsp+0x40]
000073baab9dffea  vmovaps xmm5, [rsp+0x50]
000073baab9dfff0  vmovaps xmm6, [rsp+0x60]
000073baab9dfff6  vmovaps xmm7, [rsp+0x70]
000073baab9dfffc  vmovaps xmm8, [rsp+0x80]
000073baab9e0005  vmovaps xmm9, [rsp+0x90]
000073baab9e000e  vmovaps xmm11, [rsp+0xA0]
000073baab9e0017  vmovaps xmm12, [rsp+0xB0]
000073baab9e0020  vmovaps xmm13, [rsp+0xC0]
000073baab9e0029  vmovaps xmm14, [rsp+0xD0]
000073baab9e0032  vmovaps xmm15, [rsp+0xE0]
000073baab9e003b  add rsp, 0xF0
000073baab9e0042  pop r11
000073baab9e0044  pop r10
000073baab9e0046  pop r9
000073baab9e0048  pop r8
000073baab9e004a  pop rsi
000073baab9e004b  pop rdi
000073baab9e004c  pop rdx
000073baab9e004d  pop rcx
000073baab9e004e  pop rax
000073baab9e004f  add rsp, 0x08
000073baab9e0053  jmp 0x000073BAAB9DED93
000073baab9e0058  sub rsp, 0x08
000073baab9e005c  push rax
000073baab9e005d  push rcx
000073baab9e005e  push rdx
000073baab9e005f  push rdi
000073baab9e0060  push rsi
000073baab9e0061  push r8
000073baab9e0063  push r9
000073baab9e0065  push r10
000073baab9e0067  push r11
000073baab9e0069  sub rsp, 0xF0
000073baab9e0070  vmovaps [rsp], xmm0
000073baab9e0075  vmovaps [rsp+0x10], xmm1
000073baab9e007b  vmovaps [rsp+0x20], xmm2
000073baab9e0081  vmovaps [rsp+0x30], xmm3
000073baab9e0087  vmovaps [rsp+0x40], xmm4
000073baab9e008d  vmovaps [rsp+0x50], xmm5
000073baab9e0093  vmovaps [rsp+0x60], xmm7
000073baab9e0099  vmovaps [rsp+0x70], xmm8
000073baab9e009f  vmovaps [rsp+0x80], xmm9
000073baab9e00a8  vmovaps [rsp+0x90], xmm10
000073baab9e00b1  vmovaps [rsp+0xA0], xmm11
000073baab9e00ba  vmovaps [rsp+0xB0], xmm12
000073baab9e00c3  vmovaps [rsp+0xC0], xmm13
000073baab9e00cc  vmovaps [rsp+0xD0], xmm14
000073baab9e00d5  vmovaps [rsp+0xE0], xmm15
000073baab9e00de  sub rsp, 0x30
000073baab9e00e2  movaps [rsp], xmm6
000073baab9e00e6  movaps [rsp+0x10], xmm12
000073baab9e00ec  movaps [rsp+0x20], xmm11
000073baab9e00f2  lea rdi, [rsp]
000073baab9e00f6  mov esi, 0x00
000073baab9e00fb  mov rax, 0x5F3F1062D530
000073baab9e0105  call rax
000073baab9e0107  movaps xmm6, [rsp]
000073baab9e010b  add rsp, 0x30
000073baab9e010f  vmovaps xmm0, [rsp]
000073baab9e0114  vmovaps xmm1, [rsp+0x10]
000073baab9e011a  vmovaps xmm2, [rsp+0x20]
000073baab9e0120  vmovaps xmm3, [rsp+0x30]
000073baab9e0126  vmovaps xmm4, [rsp+0x40]
000073baab9e012c  vmovaps xmm5, [rsp+0x50]
000073baab9e0132  vmovaps xmm7, [rsp+0x60]
000073baab9e0138  vmovaps xmm8, [rsp+0x70]
000073baab9e013e  vmovaps xmm9, [rsp+0x80]
000073baab9e0147  vmovaps xmm10, [rsp+0x90]
000073baab9e0150  vmovaps xmm11, [rsp+0xA0]
000073baab9e0159  vmovaps xmm12, [rsp+0xB0]
000073baab9e0162  vmovaps xmm13, [rsp+0xC0]
000073baab9e016b  vmovaps xmm14, [rsp+0xD0]
000073baab9e0174  vmovaps xmm15, [rsp+0xE0]
000073baab9e017d  add rsp, 0xF0
000073baab9e0184  pop r11
000073baab9e0186  pop r10
000073baab9e0188  pop r9
000073baab9e018a  pop r8
000073baab9e018c  pop rsi
000073baab9e018d  pop rdi
000073baab9e018e  pop rdx
000073baab9e018f  pop rcx
000073baab9e0190  pop rax
000073baab9e0191  add rsp, 0x08
000073baab9e0195  jmp 0x000073BAAB9DEDB4
000073baab9e019a  sub rsp, 0x08
000073baab9e019e  push rax
000073baab9e019f  push rcx
000073baab9e01a0  push rdx
000073baab9e01a1  push rdi
000073baab9e01a2  push rsi
000073baab9e01a3  push r8
000073baab9e01a5  push r9
000073baab9e01a7  push r10
000073baab9e01a9  push r11
000073baab9e01ab  sub rsp, 0xF0
000073baab9e01b2  vmovaps [rsp], xmm0
000073baab9e01b7  vmovaps [rsp+0x10], xmm1
000073baab9e01bd  vmovaps [rsp+0x20], xmm2
000073baab9e01c3  vmovaps [rsp+0x30], xmm4
000073baab9e01c9  vmovaps [rsp+0x40], xmm5
000073baab9e01cf  vmovaps [rsp+0x50], xmm6
000073baab9e01d5  vmovaps [rsp+0x60], xmm7
000073baab9e01db  vmovaps [rsp+0x70], xmm8
000073baab9e01e1  vmovaps [rsp+0x80], xmm9
000073baab9e01ea  vmovaps [rsp+0x90], xmm10
000073baab9e01f3  vmovaps [rsp+0xA0], xmm11
000073baab9e01fc  vmovaps [rsp+0xB0], xmm12
000073baab9e0205  vmovaps [rsp+0xC0], xmm13
000073baab9e020e  vmovaps [rsp+0xD0], xmm14
000073baab9e0217  vmovaps [rsp+0xE0], xmm15
000073baab9e0220  sub rsp, 0x30
000073baab9e0224  movaps [rsp], xmm3
000073baab9e0228  movaps [rsp+0x10], xmm5
000073baab9e022d  movaps [rsp+0x20], xmm4
000073baab9e0232  lea rdi, [rsp]
000073baab9e0236  mov esi, 0x00
000073baab9e023b  mov rax, 0x5F3F1062D530
000073baab9e0245  call rax
000073baab9e0247  movaps xmm3, [rsp]
000073baab9e024b  add rsp, 0x30
000073baab9e024f  vmovaps xmm0, [rsp]
000073baab9e0254  vmovaps xmm1, [rsp+0x10]
000073baab9e025a  vmovaps xmm2, [rsp+0x20]
000073baab9e0260  vmovaps xmm4, [rsp+0x30]
000073baab9e0266  vmovaps xmm5, [rsp+0x40]
000073baab9e026c  vmovaps xmm6, [rsp+0x50]
000073baab9e0272  vmovaps xmm7, [rsp+0x60]
000073baab9e0278  vmovaps xmm8, [rsp+0x70]
000073baab9e027e  vmovaps xmm9, [rsp+0x80]
000073baab9e0287  vmovaps xmm10, [rsp+0x90]
000073baab9e0290  vmovaps xmm11, [rsp+0xA0]
000073baab9e0299  vmovaps xmm12, [rsp+0xB0]
000073baab9e02a2  vmovaps xmm13, [rsp+0xC0]
000073baab9e02ab  vmovaps xmm14, [rsp+0xD0]
000073baab9e02b4  vmovaps xmm15, [rsp+0xE0]
000073baab9e02bd  add rsp, 0xF0
000073baab9e02c4  pop r11
000073baab9e02c6  pop r10
000073baab9e02c8  pop r9
000073baab9e02ca  pop r8
000073baab9e02cc  pop rsi
000073baab9e02cd  pop rdi
000073baab9e02ce  pop rdx
000073baab9e02cf  pop rcx
000073baab9e02d0  pop rax
000073baab9e02d1  add rsp, 0x08
000073baab9e02d5  jmp 0x000073BAAB9DEE15
000073baab9e02da  sub rsp, 0x08
000073baab9e02de  push rax
000073baab9e02df  push rcx
000073baab9e02e0  push rdx
000073baab9e02e1  push rdi
000073baab9e02e2  push rsi
000073baab9e02e3  push r8
000073baab9e02e5  push r9
000073baab9e02e7  push r10
000073baab9e02e9  push r11
000073baab9e02eb  sub rsp, 0xF0
000073baab9e02f2  vmovaps [rsp], xmm0
000073baab9e02f7  vmovaps [rsp+0x10], xmm1
000073baab9e02fd  vmovaps [rsp+0x20], xmm2
000073baab9e0303  vmovaps [rsp+0x30], xmm3
000073baab9e0309  vmovaps [rsp+0x40], xmm4
000073baab9e030f  vmovaps [rsp+0x50], xmm6
000073baab9e0315  vmovaps [rsp+0x60], xmm7
000073baab9e031b  vmovaps [rsp+0x70], xmm8
000073baab9e0321  vmovaps [rsp+0x80], xmm9
000073baab9e032a  vmovaps [rsp+0x90], xmm10
000073baab9e0333  vmovaps [rsp+0xA0], xmm11
000073baab9e033c  vmovaps [rsp+0xB0], xmm12
000073baab9e0345  vmovaps [rsp+0xC0], xmm13
000073baab9e034e  vmovaps [rsp+0xD0], xmm14
000073baab9e0357  vmovaps [rsp+0xE0], xmm15
000073baab9e0360  sub rsp, 0x30
000073baab9e0364  movaps [rsp], xmm5
000073baab9e0368  movaps [rsp+0x10], xmm8
000073baab9e036e  movaps [rsp+0x20], xmm15
000073baab9e0374  lea rdi, [rsp]
000073baab9e0378  mov esi, 0x00
000073baab9e037d  mov rax, 0x5F3F1062D530
000073baab9e0387  call rax
000073baab9e0389  movaps xmm5, [rsp]
000073baab9e038d  add rsp, 0x30
000073baab9e0391  vmovaps xmm0, [rsp]
000073baab9e0396  vmovaps xmm1, [rsp+0x10]
000073baab9e039c  vmovaps xmm2, [rsp+0x20]
000073baab9e03a2  vmovaps xmm3, [rsp+0x30]
000073baab9e03a8  vmovaps xmm4, [rsp+0x40]
000073baab9e03ae  vmovaps xmm6, [rsp+0x50]
000073baab9e03b4  vmovaps xmm7, [rsp+0x60]
000073baab9e03ba  vmovaps xmm8, [rsp+0x70]
000073baab9e03c0  vmovaps xmm9, [rsp+0x80]
000073baab9e03c9  vmovaps xmm10, [rsp+0x90]
000073baab9e03d2  vmovaps xmm11, [rsp+0xA0]
000073baab9e03db  vmovaps xmm12, [rsp+0xB0]
000073baab9e03e4  vmovaps xmm13, [rsp+0xC0]
000073baab9e03ed  vmovaps xmm14, [rsp+0xD0]
000073baab9e03f6  vmovaps xmm15, [rsp+0xE0]
000073baab9e03ff  add rsp, 0xF0
000073baab9e0406  pop r11
000073baab9e0408  pop r10
000073baab9e040a  pop r9
000073baab9e040c  pop r8
000073baab9e040e  pop rsi
000073baab9e040f  pop rdi
000073baab9e0410  pop rdx
000073baab9e0411  pop rcx
000073baab9e0412  pop rax
000073baab9e0413  add rsp, 0x08
000073baab9e0417  jmp 0x000073BAAB9DEE53
000073baab9e041c  sub rsp, 0x08
000073baab9e0420  push rax
000073baab9e0421  push rcx
000073baab9e0422  push rdx
000073baab9e0423  push rdi
000073baab9e0424  push rsi
000073baab9e0425  push r8
000073baab9e0427  push r9
000073baab9e0429  push r10
000073baab9e042b  push r11
000073baab9e042d  sub rsp, 0xF0
000073baab9e0434  vmovaps [rsp], xmm0
000073baab9e0439  vmovaps [rsp+0x10], xmm1
000073baab9e043f  vmovaps [rsp+0x20], xmm2
000073baab9e0445  vmovaps [rsp+0x30], xmm3
000073baab9e044b  vmovaps [rsp+0x40], xmm5
000073baab9e0451  vmovaps [rsp+0x50], xmm6
000073baab9e0457  vmovaps [rsp+0x60], xmm7
000073baab9e045d  vmovaps [rsp+0x70], xmm8
000073baab9e0463  vmovaps [rsp+0x80], xmm9
000073baab9e046c  vmovaps [rsp+0x90], xmm10
000073baab9e0475  vmovaps [rsp+0xA0], xmm11
000073baab9e047e  vmovaps [rsp+0xB0], xmm12
000073baab9e0487  vmovaps [rsp+0xC0], xmm13
000073baab9e0490  vmovaps [rsp+0xD0], xmm14
000073baab9e0499  vmovaps [rsp+0xE0], xmm15
000073baab9e04a2  sub rsp, 0x30
000073baab9e04a6  movaps [rsp], xmm4
000073baab9e04aa  movaps [rsp+0x10], xmm9
000073baab9e04b0  movaps [rsp+0x20], xmm8
000073baab9e04b6  lea rdi, [rsp]
000073baab9e04ba  mov esi, 0x00
000073baab9e04bf  mov rax, 0x5F3F1062D530
000073baab9e04c9  call rax
000073baab9e04cb  movaps xmm4, [rsp]
000073baab9e04cf  add rsp, 0x30
000073baab9e04d3  vmovaps xmm0, [rsp]
000073baab9e04d8  vmovaps xmm1, [rsp+0x10]
000073baab9e04de  vmovaps xmm2, [rsp+0x20]
000073baab9e04e4  vmovaps xmm3, [rsp+0x30]
000073baab9e04ea  vmovaps xmm5, [rsp+0x40]
000073baab9e04f0  vmovaps xmm6, [rsp+0x50]
000073baab9e04f6  vmovaps xmm7, [rsp+0x60]
000073baab9e04fc  vmovaps xmm8, [rsp+0x70]
000073baab9e0502  vmovaps xmm9, [rsp+0x80]
000073baab9e050b  vmovaps xmm10, [rsp+0x90]
000073baab9e0514  vmovaps xmm11, [rsp+0xA0]
000073baab9e051d  vmovaps xmm12, [rsp+0xB0]
000073baab9e0526  vmovaps xmm13, [rsp+0xC0]
000073baab9e052f  vmovaps xmm14, [rsp+0xD0]
000073baab9e0538  vmovaps xmm15, [rsp+0xE0]
000073baab9e0541  add rsp, 0xF0
000073baab9e0548  pop r11
000073baab9e054a  pop r10
000073baab9e054c  pop r9
000073baab9e054e  pop r8
000073baab9e0550  pop rsi
000073baab9e0551  pop rdi
000073baab9e0552  pop rdx
000073baab9e0553  pop rcx
000073baab9e0554  pop rax
000073baab9e0555  add rsp, 0x08
000073baab9e0559  jmp 0x000073BAAB9DEE74
000073baab9e055e  sub rsp, 0x08
000073baab9e0562  push rax
000073baab9e0563  push rcx
000073baab9e0564  push rdx
000073baab9e0565  push rdi
000073baab9e0566  push rsi
000073baab9e0567  push r8
000073baab9e0569  push r9
000073baab9e056b  push r10
000073baab9e056d  push r11
000073baab9e056f  sub rsp, 0xF0
000073baab9e0576  vmovaps [rsp], xmm0
000073baab9e057b  vmovaps [rsp+0x10], xmm1
000073baab9e0581  vmovaps [rsp+0x20], xmm2
000073baab9e0587  vmovaps [rsp+0x30], xmm3
000073baab9e058d  vmovaps [rsp+0x40], xmm4
000073baab9e0593  vmovaps [rsp+0x50], xmm5
000073baab9e0599  vmovaps [rsp+0x60], xmm6
000073baab9e059f  vmovaps [rsp+0x70], xmm7
000073baab9e05a5  vmovaps [rsp+0x80], xmm8
000073baab9e05ae  vmovaps [rsp+0x90], xmm10
000073baab9e05b7  vmovaps [rsp+0xA0], xmm11
000073baab9e05c0  vmovaps [rsp+0xB0], xmm12
000073baab9e05c9  vmovaps [rsp+0xC0], xmm13
000073baab9e05d2  vmovaps [rsp+0xD0], xmm14
000073baab9e05db  vmovaps [rsp+0xE0], xmm15
000073baab9e05e4  sub rsp, 0x30
000073baab9e05e8  movaps [rsp], xmm9
000073baab9e05ed  movaps [rsp+0x10], xmm10
000073baab9e05f3  movaps [rsp+0x20], xmm8
000073baab9e05f9  lea rdi, [rsp]
000073baab9e05fd  mov esi, 0x00
000073baab9e0602  mov rax, 0x5F3F1062D530
000073baab9e060c  call rax
000073baab9e060e  movaps xmm9, [rsp]
000073baab9e0613  add rsp, 0x30
000073baab9e0617  vmovaps xmm0, [rsp]
000073baab9e061c  vmovaps xmm1, [rsp+0x10]
000073baab9e0622  vmovaps xmm2, [rsp+0x20]
000073baab9e0628  vmovaps xmm3, [rsp+0x30]
000073baab9e062e  vmovaps xmm4, [rsp+0x40]
000073baab9e0634  vmovaps xmm5, [rsp+0x50]
000073baab9e063a  vmovaps xmm6, [rsp+0x60]
000073baab9e0640  vmovaps xmm7, [rsp+0x70]
000073baab9e0646  vmovaps xmm8, [rsp+0x80]
000073baab9e064f  vmovaps xmm10, [rsp+0x90]
000073baab9e0658  vmovaps xmm11, [rsp+0xA0]
000073baab9e0661  vmovaps xmm12, [rsp+0xB0]
000073baab9e066a  vmovaps xmm13, [rsp+0xC0]
000073baab9e0673  vmovaps xmm14, [rsp+0xD0]
000073baab9e067c  vmovaps xmm15, [rsp+0xE0]
000073baab9e0685  add rsp, 0xF0
000073baab9e068c  pop r11
000073baab9e068e  pop r10
000073baab9e0690  pop r9
000073baab9e0692  pop r8
000073baab9e0694  pop rsi
000073baab9e0695  pop rdi
000073baab9e0696  pop rdx
000073baab9e0697  pop rcx
000073baab9e0698  pop rax
000073baab9e0699  add rsp, 0x08
000073baab9e069d  jmp 0x000073BAAB9DEE8E
000073baab9e06a2  call 0x000073BAAB8B52F0
000073baab9e06a7  jmp 0x000073BAAB9DEFA8
000073baab9e06ac  call 0x000073BAAB8B52F0
000073baab9e06b1  jmp 0x000073BAAB9DEFBE
000073baab9e06b6  sub rsp, 0x08
000073baab9e06ba  push rax
000073baab9e06bb  push rcx
000073baab9e06bc  push rdx
000073baab9e06bd  push rdi
000073baab9e06be  push rsi
000073baab9e06bf  push r8
000073baab9e06c1  push r9
000073baab9e06c3  push r10
000073baab9e06c5  push r11
000073baab9e06c7  sub rsp, 0xF0
000073baab9e06ce  vmovaps [rsp], xmm0
000073baab9e06d3  vmovaps [rsp+0x10], xmm2
000073baab9e06d9  vmovaps [rsp+0x20], xmm3
000073baab9e06df  vmovaps [rsp+0x30], xmm4
000073baab9e06e5  vmovaps [rsp+0x40], xmm5
000073baab9e06eb  vmovaps [rsp+0x50], xmm6
000073baab9e06f1  vmovaps [rsp+0x60], xmm7
000073baab9e06f7  vmovaps [rsp+0x70], xmm8
000073baab9e06fd  vmovaps [rsp+0x80], xmm9
000073baab9e0706  vmovaps [rsp+0x90], xmm10
000073baab9e070f  vmovaps [rsp+0xA0], xmm11
000073baab9e0718  vmovaps [rsp+0xB0], xmm12
000073baab9e0721  vmovaps [rsp+0xC0], xmm13
000073baab9e072a  vmovaps [rsp+0xD0], xmm14
000073baab9e0733  vmovaps [rsp+0xE0], xmm15
000073baab9e073c  sub rsp, 0x30
000073baab9e0740  movaps [rsp], xmm1
000073baab9e0744  movaps [rsp+0x10], xmm6
000073baab9e0749  movaps [rsp+0x20], xmm15
000073baab9e074f  lea rdi, [rsp]
000073baab9e0753  mov esi, 0x00
000073baab9e0758  mov rax, 0x5F3F1062D530
000073baab9e0762  call rax
000073baab9e0764  movaps xmm1, [rsp]
000073baab9e0768  add rsp, 0x30
000073baab9e076c  vmovaps xmm0, [rsp]
000073baab9e0771  vmovaps xmm2, [rsp+0x10]
000073baab9e0777  vmovaps xmm3, [rsp+0x20]
000073baab9e077d  vmovaps xmm4, [rsp+0x30]
000073baab9e0783  vmovaps xmm5, [rsp+0x40]
000073baab9e0789  vmovaps xmm6, [rsp+0x50]
000073baab9e078f  vmovaps xmm7, [rsp+0x60]
000073baab9e0795  vmovaps xmm8, [rsp+0x70]
000073baab9e079b  vmovaps xmm9, [rsp+0x80]
000073baab9e07a4  vmovaps xmm10, [rsp+0x90]
000073baab9e07ad  vmovaps xmm11, [rsp+0xA0]
000073baab9e07b6  vmovaps xmm12, [rsp+0xB0]
000073baab9e07bf  vmovaps xmm13, [rsp+0xC0]
000073baab9e07c8  vmovaps xmm14, [rsp+0xD0]
000073baab9e07d1  vmovaps xmm15, [rsp+0xE0]
000073baab9e07da  add rsp, 0xF0
000073baab9e07e1  pop r11
000073baab9e07e3  pop r10
000073baab9e07e5  pop r9
000073baab9e07e7  pop r8
000073baab9e07e9  pop rsi
000073baab9e07ea  pop rdi
000073baab9e07eb  pop rdx
000073baab9e07ec  pop rcx
000073baab9e07ed  pop rax
000073baab9e07ee  add rsp, 0x08
000073baab9e07f2  jmp 0x000073BAAB9DEFFB
000073baab9e07f7  call 0x000073BAAB8C4620
000073baab9e07fc  jmp 0x000073BAAB9DF008
000073baab9e0801  sub rsp, 0x08
000073baab9e0805  push rax
000073baab9e0806  push rcx
000073baab9e0807  push rdx
000073baab9e0808  push rdi
000073baab9e0809  push rsi
000073baab9e080a  push r8
000073baab9e080c  push r9
000073baab9e080e  push r10
000073baab9e0810  push r11
000073baab9e0812  sub rsp, 0xF0
000073baab9e0819  vmovaps [rsp], xmm0
000073baab9e081e  vmovaps [rsp+0x10], xmm1
000073baab9e0824  vmovaps [rsp+0x20], xmm2
000073baab9e082a  vmovaps [rsp+0x30], xmm3
000073baab9e0830  vmovaps [rsp+0x40], xmm4
000073baab9e0836  vmovaps [rsp+0x50], xmm5
000073baab9e083c  vmovaps [rsp+0x60], xmm6
000073baab9e0842  vmovaps [rsp+0x70], xmm7
000073baab9e0848  vmovaps [rsp+0x80], xmm8
000073baab9e0851  vmovaps [rsp+0x90], xmm9
000073baab9e085a  vmovaps [rsp+0xA0], xmm10
000073baab9e0863  vmovaps [rsp+0xB0], xmm11
000073baab9e086c  vmovaps [rsp+0xC0], xmm12
000073baab9e0875  vmovaps [rsp+0xD0], xmm13
000073baab9e087e  vmovaps [rsp+0xE0], xmm15
000073baab9e0887  sub rsp, 0x30
000073baab9e088b  movaps [rsp], xmm14
000073baab9e0890  movaps [rsp+0x10], xmm4
000073baab9e0895  movaps [rsp+0x20], xmm3
000073baab9e089a  lea rdi, [rsp]
000073baab9e089e  mov esi, 0x00
000073baab9e08a3  mov rax, 0x5F3F1062D530
000073baab9e08ad  call rax
000073baab9e08af  movaps xmm14, [rsp]
000073baab9e08b4  add rsp, 0x30
000073baab9e08b8  vmovaps xmm0, [rsp]
000073baab9e08bd  vmovaps xmm1, [rsp+0x10]
000073baab9e08c3  vmovaps xmm2, [rsp+0x20]
000073baab9e08c9  vmovaps xmm3, [rsp+0x30]
000073baab9e08cf  vmovaps xmm4, [rsp+0x40]
000073baab9e08d5  vmovaps xmm5, [rsp+0x50]
000073baab9e08db  vmovaps xmm6, [rsp+0x60]
000073baab9e08e1  vmovaps xmm7, [rsp+0x70]
000073baab9e08e7  vmovaps xmm8, [rsp+0x80]
000073baab9e08f0  vmovaps xmm9, [rsp+0x90]
000073baab9e08f9  vmovaps xmm10, [rsp+0xA0]
000073baab9e0902  vmovaps xmm11, [rsp+0xB0]
000073baab9e090b  vmovaps xmm12, [rsp+0xC0]
000073baab9e0914  vmovaps xmm13, [rsp+0xD0]
000073baab9e091d  vmovaps xmm15, [rsp+0xE0]
000073baab9e0926  add rsp, 0xF0
000073baab9e092d  pop r11
000073baab9e092f  pop r10
000073baab9e0931  pop r9
000073baab9e0933  pop r8
000073baab9e0935  pop rsi
000073baab9e0936  pop rdi
000073baab9e0937  pop rdx
000073baab9e0938  pop rcx
000073baab9e0939  pop rax
000073baab9e093a  add rsp, 0x08
000073baab9e093e  jmp 0x000073BAAB9DF022
000073baab9e0943  sub rsp, 0x08
000073baab9e0947  push rax
000073baab9e0948  push rcx
000073baab9e0949  push rdx
000073baab9e094a  push rdi
000073baab9e094b  push rsi
000073baab9e094c  push r8
000073baab9e094e  push r9
000073baab9e0950  push r10
000073baab9e0952  push r11
000073baab9e0954  sub rsp, 0xF0
000073baab9e095b  vmovaps [rsp], xmm0
000073baab9e0960  vmovaps [rsp+0x10], xmm1
000073baab9e0966  vmovaps [rsp+0x20], xmm2
000073baab9e096c  vmovaps [rsp+0x30], xmm3
000073baab9e0972  vmovaps [rsp+0x40], xmm4
000073baab9e0978  vmovaps [rsp+0x50], xmm5
000073baab9e097e  vmovaps [rsp+0x60], xmm7
000073baab9e0984  vmovaps [rsp+0x70], xmm8
000073baab9e098a  vmovaps [rsp+0x80], xmm9
000073baab9e0993  vmovaps [rsp+0x90], xmm10
000073baab9e099c  vmovaps [rsp+0xA0], xmm11
000073baab9e09a5  vmovaps [rsp+0xB0], xmm12
000073baab9e09ae  vmovaps [rsp+0xC0], xmm13
000073baab9e09b7  vmovaps [rsp+0xD0], xmm14
000073baab9e09c0  vmovaps [rsp+0xE0], xmm15
000073baab9e09c9  sub rsp, 0x30
000073baab9e09cd  movaps [rsp], xmm6
000073baab9e09d1  movaps [rsp+0x10], xmm9
000073baab9e09d7  movaps [rsp+0x20], xmm7
000073baab9e09dc  lea rdi, [rsp]
000073baab9e09e0  mov esi, 0x00
000073baab9e09e5  mov rax, 0x5F3F1062D530
000073baab9e09ef  call rax
000073baab9e09f1  movaps xmm6, [rsp]
000073baab9e09f5  add rsp, 0x30
000073baab9e09f9  vmovaps xmm0, [rsp]
000073baab9e09fe  vmovaps xmm1, [rsp+0x10]
000073baab9e0a04  vmovaps xmm2, [rsp+0x20]
000073baab9e0a0a  vmovaps xmm3, [rsp+0x30]
000073baab9e0a10  vmovaps xmm4, [rsp+0x40]
000073baab9e0a16  vmovaps xmm5, [rsp+0x50]
000073baab9e0a1c  vmovaps xmm7, [rsp+0x60]
000073baab9e0a22  vmovaps xmm8, [rsp+0x70]
000073baab9e0a28  vmovaps xmm9, [rsp+0x80]
000073baab9e0a31  vmovaps xmm10, [rsp+0x90]
000073baab9e0a3a  vmovaps xmm11, [rsp+0xA0]
000073baab9e0a43  vmovaps xmm12, [rsp+0xB0]
000073baab9e0a4c  vmovaps xmm13, [rsp+0xC0]
000073baab9e0a55  vmovaps xmm14, [rsp+0xD0]
000073baab9e0a5e  vmovaps xmm15, [rsp+0xE0]
000073baab9e0a67  add rsp, 0xF0
000073baab9e0a6e  pop r11
000073baab9e0a70  pop r10
000073baab9e0a72  pop r9
000073baab9e0a74  pop r8
000073baab9e0a76  pop rsi
000073baab9e0a77  pop rdi
000073baab9e0a78  pop rdx
000073baab9e0a79  pop rcx
000073baab9e0a7a  pop rax
000073baab9e0a7b  add rsp, 0x08
000073baab9e0a7f  jmp 0x000073BAAB9DF03A
000073baab9e0a84  sub rsp, 0x08
000073baab9e0a88  push rax
000073baab9e0a89  push rcx
000073baab9e0a8a  push rdx
000073baab9e0a8b  push rdi
000073baab9e0a8c  push rsi
000073baab9e0a8d  push r8
000073baab9e0a8f  push r9
000073baab9e0a91  push r10
000073baab9e0a93  push r11
000073baab9e0a95  sub rsp, 0xF0
000073baab9e0a9c  vmovaps [rsp], xmm0
000073baab9e0aa1  vmovaps [rsp+0x10], xmm1
000073baab9e0aa7  vmovaps [rsp+0x20], xmm2
000073baab9e0aad  vmovaps [rsp+0x30], xmm3
000073baab9e0ab3  vmovaps [rsp+0x40], xmm4
000073baab9e0ab9  vmovaps [rsp+0x50], xmm5
000073baab9e0abf  vmovaps [rsp+0x60], xmm6
000073baab9e0ac5  vmovaps [rsp+0x70], xmm8
000073baab9e0acb  vmovaps [rsp+0x80], xmm9
000073baab9e0ad4  vmovaps [rsp+0x90], xmm10
000073baab9e0add  vmovaps [rsp+0xA0], xmm11
000073baab9e0ae6  vmovaps [rsp+0xB0], xmm12
000073baab9e0aef  vmovaps [rsp+0xC0], xmm13
000073baab9e0af8  vmovaps [rsp+0xD0], xmm14
000073baab9e0b01  vmovaps [rsp+0xE0], xmm15
000073baab9e0b0a  sub rsp, 0x30
000073baab9e0b0e  movaps [rsp], xmm7
000073baab9e0b12  movaps [rsp+0x10], xmm4
000073baab9e0b17  movaps [rsp+0x20], xmm9
000073baab9e0b1d  lea rdi, [rsp]
000073baab9e0b21  mov esi, 0x00
000073baab9e0b26  mov rax, 0x5F3F1062D530
000073baab9e0b30  call rax
000073baab9e0b32  movaps xmm7, [rsp]
000073baab9e0b36  add rsp, 0x30
000073baab9e0b3a  vmovaps xmm0, [rsp]
000073baab9e0b3f  vmovaps xmm1, [rsp+0x10]
000073baab9e0b45  vmovaps xmm2, [rsp+0x20]
000073baab9e0b4b  vmovaps xmm3, [rsp+0x30]
000073baab9e0b51  vmovaps xmm4, [rsp+0x40]
000073baab9e0b57  vmovaps xmm5, [rsp+0x50]
000073baab9e0b5d  vmovaps xmm6, [rsp+0x60]
000073baab9e0b63  vmovaps xmm8, [rsp+0x70]
000073baab9e0b69  vmovaps xmm9, [rsp+0x80]
000073baab9e0b72  vmovaps xmm10, [rsp+0x90]
000073baab9e0b7b  vmovaps xmm11, [rsp+0xA0]
000073baab9e0b84  vmovaps xmm12, [rsp+0xB0]
000073baab9e0b8d  vmovaps xmm13, [rsp+0xC0]
000073baab9e0b96  vmovaps xmm14, [rsp+0xD0]
000073baab9e0b9f  vmovaps xmm15, [rsp+0xE0]
000073baab9e0ba8  add rsp, 0xF0
000073baab9e0baf  pop r11
000073baab9e0bb1  pop r10
000073baab9e0bb3  pop r9
000073baab9e0bb5  pop r8
000073baab9e0bb7  pop rsi
000073baab9e0bb8  pop rdi
000073baab9e0bb9  pop rdx
000073baab9e0bba  pop rcx
000073baab9e0bbb  pop rax
000073baab9e0bbc  add rsp, 0x08
000073baab9e0bc0  jmp 0x000073BAAB9DF067
000073baab9e0bc5  sub rsp, 0x08
000073baab9e0bc9  push rax
000073baab9e0bca  push rcx
000073baab9e0bcb  push rdx
000073baab9e0bcc  push rdi
000073baab9e0bcd  push rsi
000073baab9e0bce  push r8
000073baab9e0bd0  push r9
000073baab9e0bd2  push r10
000073baab9e0bd4  push r11
000073baab9e0bd6  sub rsp, 0xF0
000073baab9e0bdd  vmovaps [rsp], xmm0
000073baab9e0be2  vmovaps [rsp+0x10], xmm1
000073baab9e0be8  vmovaps [rsp+0x20], xmm2
000073baab9e0bee  vmovaps [rsp+0x30], xmm3
000073baab9e0bf4  vmovaps [rsp+0x40], xmm5
000073baab9e0bfa  vmovaps [rsp+0x50], xmm6
000073baab9e0c00  vmovaps [rsp+0x60], xmm7
000073baab9e0c06  vmovaps [rsp+0x70], xmm8
000073baab9e0c0c  vmovaps [rsp+0x80], xmm9
000073baab9e0c15  vmovaps [rsp+0x90], xmm10
000073baab9e0c1e  vmovaps [rsp+0xA0], xmm11
000073baab9e0c27  vmovaps [rsp+0xB0], xmm12
000073baab9e0c30  vmovaps [rsp+0xC0], xmm13
000073baab9e0c39  vmovaps [rsp+0xD0], xmm14
000073baab9e0c42  vmovaps [rsp+0xE0], xmm15
000073baab9e0c4b  sub rsp, 0x30
000073baab9e0c4f  movaps [rsp], xmm4
000073baab9e0c53  movaps [rsp+0x10], xmm15
000073baab9e0c59  movaps [rsp+0x20], xmm9
000073baab9e0c5f  lea rdi, [rsp]
000073baab9e0c63  mov esi, 0x00
000073baab9e0c68  mov rax, 0x5F3F1062D530
000073baab9e0c72  call rax
000073baab9e0c74  movaps xmm4, [rsp]
000073baab9e0c78  add rsp, 0x30
000073baab9e0c7c  vmovaps xmm0, [rsp]
000073baab9e0c81  vmovaps xmm1, [rsp+0x10]
000073baab9e0c87  vmovaps xmm2, [rsp+0x20]
000073baab9e0c8d  vmovaps xmm3, [rsp+0x30]
000073baab9e0c93  vmovaps xmm5, [rsp+0x40]
000073baab9e0c99  vmovaps xmm6, [rsp+0x50]
000073baab9e0c9f  vmovaps xmm7, [rsp+0x60]
000073baab9e0ca5  vmovaps xmm8, [rsp+0x70]
000073baab9e0cab  vmovaps xmm9, [rsp+0x80]
000073baab9e0cb4  vmovaps xmm10, [rsp+0x90]
000073baab9e0cbd  vmovaps xmm11, [rsp+0xA0]
000073baab9e0cc6  vmovaps xmm12, [rsp+0xB0]
000073baab9e0ccf  vmovaps xmm13, [rsp+0xC0]
000073baab9e0cd8  vmovaps xmm14, [rsp+0xD0]
000073baab9e0ce1  vmovaps xmm15, [rsp+0xE0]
000073baab9e0cea  add rsp, 0xF0
000073baab9e0cf1  pop r11
000073baab9e0cf3  pop r10
000073baab9e0cf5  pop r9
000073baab9e0cf7  pop r8
000073baab9e0cf9  pop rsi
000073baab9e0cfa  pop rdi
000073baab9e0cfb  pop rdx
000073baab9e0cfc  pop rcx
000073baab9e0cfd  pop rax
000073baab9e0cfe  add rsp, 0x08
000073baab9e0d02  jmp 0x000073BAAB9DF08C
000073baab9e0d07  call 0x000073BAAB8C4620
000073baab9e0d0c  jmp 0x000073BAAB9DF099
000073baab9e0d11  sub rsp, 0x08
000073baab9e0d15  push rax
000073baab9e0d16  push rcx
000073baab9e0d17  push rdx
000073baab9e0d18  push rdi
000073baab9e0d19  push rsi
000073baab9e0d1a  push r8
000073baab9e0d1c  push r9
000073baab9e0d1e  push r10
000073baab9e0d20  push r11
000073baab9e0d22  sub rsp, 0xF0
000073baab9e0d29  vmovaps [rsp], xmm0
000073baab9e0d2e  vmovaps [rsp+0x10], xmm1
000073baab9e0d34  vmovaps [rsp+0x20], xmm2
000073baab9e0d3a  vmovaps [rsp+0x30], xmm4
000073baab9e0d40  vmovaps [rsp+0x40], xmm5
000073baab9e0d46  vmovaps [rsp+0x50], xmm6
000073baab9e0d4c  vmovaps [rsp+0x60], xmm7
000073baab9e0d52  vmovaps [rsp+0x70], xmm8
000073baab9e0d58  vmovaps [rsp+0x80], xmm9
000073baab9e0d61  vmovaps [rsp+0x90], xmm10
000073baab9e0d6a  vmovaps [rsp+0xA0], xmm11
000073baab9e0d73  vmovaps [rsp+0xB0], xmm12
000073baab9e0d7c  vmovaps [rsp+0xC0], xmm13
000073baab9e0d85  vmovaps [rsp+0xD0], xmm14
000073baab9e0d8e  vmovaps [rsp+0xE0], xmm15
000073baab9e0d97  sub rsp, 0x30
000073baab9e0d9b  movaps [rsp], xmm3
000073baab9e0d9f  movaps [rsp+0x10], xmm1
000073baab9e0da4  movaps [rsp+0x20], xmm9
000073baab9e0daa  lea rdi, [rsp]
000073baab9e0dae  mov esi, 0x00
000073baab9e0db3  mov rax, 0x5F3F1062D530
000073baab9e0dbd  call rax
000073baab9e0dbf  movaps xmm3, [rsp]
000073baab9e0dc3  add rsp, 0x30
000073baab9e0dc7  vmovaps xmm0, [rsp]
000073baab9e0dcc  vmovaps xmm1, [rsp+0x10]
000073baab9e0dd2  vmovaps xmm2, [rsp+0x20]
000073baab9e0dd8  vmovaps xmm4, [rsp+0x30]
000073baab9e0dde  vmovaps xmm5, [rsp+0x40]
000073baab9e0de4  vmovaps xmm6, [rsp+0x50]
000073baab9e0dea  vmovaps xmm7, [rsp+0x60]
000073baab9e0df0  vmovaps xmm8, [rsp+0x70]
000073baab9e0df6  vmovaps xmm9, [rsp+0x80]
000073baab9e0dff  vmovaps xmm10, [rsp+0x90]
000073baab9e0e08  vmovaps xmm11, [rsp+0xA0]
000073baab9e0e11  vmovaps xmm12, [rsp+0xB0]
000073baab9e0e1a  vmovaps xmm13, [rsp+0xC0]
000073baab9e0e23  vmovaps xmm14, [rsp+0xD0]
000073baab9e0e2c  vmovaps xmm15, [rsp+0xE0]
000073baab9e0e35  add rsp, 0xF0
000073baab9e0e3c  pop r11
000073baab9e0e3e  pop r10
000073baab9e0e40  pop r9
000073baab9e0e42  pop r8
000073baab9e0e44  pop rsi
000073baab9e0e45  pop rdi
000073baab9e0e46  pop rdx
000073baab9e0e47  pop rcx
000073baab9e0e48  pop rax
000073baab9e0e49  add rsp, 0x08
000073baab9e0e4d  jmp 0x000073BAAB9DF0D6
000073baab9e0e52  sub rsp, 0x08
000073baab9e0e56  push rax
000073baab9e0e57  push rcx
000073baab9e0e58  push rdx
000073baab9e0e59  push rdi
000073baab9e0e5a  push rsi
000073baab9e0e5b  push r8
000073baab9e0e5d  push r9
000073baab9e0e5f  push r10
000073baab9e0e61  push r11
000073baab9e0e63  sub rsp, 0xF0
000073baab9e0e6a  vmovaps [rsp], xmm0
000073baab9e0e6f  vmovaps [rsp+0x10], xmm2
000073baab9e0e75  vmovaps [rsp+0x20], xmm3
000073baab9e0e7b  vmovaps [rsp+0x30], xmm4
000073baab9e0e81  vmovaps [rsp+0x40], xmm5
000073baab9e0e87  vmovaps [rsp+0x50], xmm6
000073baab9e0e8d  vmovaps [rsp+0x60], xmm7
000073baab9e0e93  vmovaps [rsp+0x70], xmm8
000073baab9e0e99  vmovaps [rsp+0x80], xmm9
000073baab9e0ea2  vmovaps [rsp+0x90], xmm10
000073baab9e0eab  vmovaps [rsp+0xA0], xmm11
000073baab9e0eb4  vmovaps [rsp+0xB0], xmm12
000073baab9e0ebd  vmovaps [rsp+0xC0], xmm13
000073baab9e0ec6  vmovaps [rsp+0xD0], xmm14
000073baab9e0ecf  vmovaps [rsp+0xE0], xmm15
000073baab9e0ed8  sub rsp, 0x30
000073baab9e0edc  movaps [rsp], xmm1
000073baab9e0ee0  movaps [rsp+0x10], xmm15
000073baab9e0ee6  movaps [rsp+0x20], xmm9
000073baab9e0eec  lea rdi, [rsp]
000073baab9e0ef0  mov esi, 0x00
000073baab9e0ef5  mov rax, 0x5F3F1062D530
000073baab9e0eff  call rax
000073baab9e0f01  movaps xmm1, [rsp]
000073baab9e0f05  add rsp, 0x30
000073baab9e0f09  vmovaps xmm0, [rsp]
000073baab9e0f0e  vmovaps xmm2, [rsp+0x10]
000073baab9e0f14  vmovaps xmm3, [rsp+0x20]
000073baab9e0f1a  vmovaps xmm4, [rsp+0x30]
000073baab9e0f20  vmovaps xmm5, [rsp+0x40]
000073baab9e0f26  vmovaps xmm6, [rsp+0x50]
000073baab9e0f2c  vmovaps xmm7, [rsp+0x60]
000073baab9e0f32  vmovaps xmm8, [rsp+0x70]
000073baab9e0f38  vmovaps xmm9, [rsp+0x80]
000073baab9e0f41  vmovaps xmm10, [rsp+0x90]
000073baab9e0f4a  vmovaps xmm11, [rsp+0xA0]
000073baab9e0f53  vmovaps xmm12, [rsp+0xB0]
000073baab9e0f5c  vmovaps xmm13, [rsp+0xC0]
000073baab9e0f65  vmovaps xmm14, [rsp+0xD0]
000073baab9e0f6e  vmovaps xmm15, [rsp+0xE0]
000073baab9e0f77  add rsp, 0xF0
000073baab9e0f7e  pop r11
000073baab9e0f80  pop r10
000073baab9e0f82  pop r9
000073baab9e0f84  pop r8
000073baab9e0f86  pop rsi
000073baab9e0f87  pop rdi
000073baab9e0f88  pop rdx
000073baab9e0f89  pop rcx
000073baab9e0f8a  pop rax
000073baab9e0f8b  add rsp, 0x08
000073baab9e0f8f  jmp 0x000073BAAB9DF15E
000073baab9e0f94  call 0x000073BAAB8C4620
000073baab9e0f99  jmp 0x000073BAAB9DF16B
000073baab9e0f9e  sub rsp, 0x08
000073baab9e0fa2  push rax
000073baab9e0fa3  push rcx
000073baab9e0fa4  push rdx
000073baab9e0fa5  push rdi
000073baab9e0fa6  push rsi
000073baab9e0fa7  push r8
000073baab9e0fa9  push r9
000073baab9e0fab  push r10
000073baab9e0fad  push r11
000073baab9e0faf  sub rsp, 0xF0
000073baab9e0fb6  vmovaps [rsp], xmm0
000073baab9e0fbb  vmovaps [rsp+0x10], xmm2
000073baab9e0fc1  vmovaps [rsp+0x20], xmm3
000073baab9e0fc7  vmovaps [rsp+0x30], xmm4
000073baab9e0fcd  vmovaps [rsp+0x40], xmm5
000073baab9e0fd3  vmovaps [rsp+0x50], xmm6
000073baab9e0fd9  vmovaps [rsp+0x60], xmm7
000073baab9e0fdf  vmovaps [rsp+0x70], xmm8
000073baab9e0fe5  vmovaps [rsp+0x80], xmm9
000073baab9e0fee  vmovaps [rsp+0x90], xmm10
000073baab9e0ff7  vmovaps [rsp+0xA0], xmm11
000073baab9e1000  vmovaps [rsp+0xB0], xmm12
000073baab9e1009  vmovaps [rsp+0xC0], xmm13
000073baab9e1012  vmovaps [rsp+0xD0], xmm14
000073baab9e101b  vmovaps [rsp+0xE0], xmm15
000073baab9e1024  sub rsp, 0x30
000073baab9e1028  movaps [rsp], xmm1
000073baab9e102c  movaps [rsp+0x10], xmm5
000073baab9e1031  movaps [rsp+0x20], xmm7
000073baab9e1036  lea rdi, [rsp]
000073baab9e103a  mov esi, 0x00
000073baab9e103f  mov rax, 0x5F3F1062D530
000073baab9e1049  call rax
000073baab9e104b  movaps xmm1, [rsp]
000073baab9e104f  add rsp, 0x30
000073baab9e1053  vmovaps xmm0, [rsp]
000073baab9e1058  vmovaps xmm2, [rsp+0x10]
000073baab9e105e  vmovaps xmm3, [rsp+0x20]
000073baab9e1064  vmovaps xmm4, [rsp+0x30]
000073baab9e106a  vmovaps xmm5, [rsp+0x40]
000073baab9e1070  vmovaps xmm6, [rsp+0x50]
000073baab9e1076  vmovaps xmm7, [rsp+0x60]
000073baab9e107c  vmovaps xmm8, [rsp+0x70]
000073baab9e1082  vmovaps xmm9, [rsp+0x80]
000073baab9e108b  vmovaps xmm10, [rsp+0x90]
000073baab9e1094  vmovaps xmm11, [rsp+0xA0]
000073baab9e109d  vmovaps xmm12, [rsp+0xB0]
000073baab9e10a6  vmovaps xmm13, [rsp+0xC0]
000073baab9e10af  vmovaps xmm14, [rsp+0xD0]
000073baab9e10b8  vmovaps xmm15, [rsp+0xE0]
000073baab9e10c1  add rsp, 0xF0
000073baab9e10c8  pop r11
000073baab9e10ca  pop r10
000073baab9e10cc  pop r9
000073baab9e10ce  pop r8
000073baab9e10d0  pop rsi
000073baab9e10d1  pop rdi
000073baab9e10d2  pop rdx
000073baab9e10d3  pop rcx
000073baab9e10d4  pop rax
000073baab9e10d5  add rsp, 0x08
000073baab9e10d9  jmp 0x000073BAAB9DF210
000073baab9e10de  sub rsp, 0x08
000073baab9e10e2  push rax
000073baab9e10e3  push rcx
000073baab9e10e4  push rdx
000073baab9e10e5  push rdi
000073baab9e10e6  push rsi
000073baab9e10e7  push r8
000073baab9e10e9  push r9
000073baab9e10eb  push r10
000073baab9e10ed  push r11
000073baab9e10ef  sub rsp, 0xF0
000073baab9e10f6  vmovaps [rsp], xmm0
000073baab9e10fb  vmovaps [rsp+0x10], xmm1
000073baab9e1101  vmovaps [rsp+0x20], xmm2
000073baab9e1107  vmovaps [rsp+0x30], xmm3
000073baab9e110d  vmovaps [rsp+0x40], xmm4
000073baab9e1113  vmovaps [rsp+0x50], xmm5
000073baab9e1119  vmovaps [rsp+0x60], xmm6
000073baab9e111f  vmovaps [rsp+0x70], xmm8
000073baab9e1125  vmovaps [rsp+0x80], xmm9
000073baab9e112e  vmovaps [rsp+0x90], xmm10
000073baab9e1137  vmovaps [rsp+0xA0], xmm11
000073baab9e1140  vmovaps [rsp+0xB0], xmm12
000073baab9e1149  vmovaps [rsp+0xC0], xmm13
000073baab9e1152  vmovaps [rsp+0xD0], xmm14
000073baab9e115b  vmovaps [rsp+0xE0], xmm15
000073baab9e1164  sub rsp, 0x30
000073baab9e1168  movaps [rsp], xmm7
000073baab9e116c  movaps [rsp+0x10], xmm5
000073baab9e1171  movaps [rsp+0x20], xmm15
000073baab9e1177  lea rdi, [rsp]
000073baab9e117b  mov esi, 0x00
000073baab9e1180  mov rax, 0x5F3F1062D530
000073baab9e118a  call rax
000073baab9e118c  movaps xmm7, [rsp]
000073baab9e1190  add rsp, 0x30
000073baab9e1194  vmovaps xmm0, [rsp]
000073baab9e1199  vmovaps xmm1, [rsp+0x10]
000073baab9e119f  vmovaps xmm2, [rsp+0x20]
000073baab9e11a5  vmovaps xmm3, [rsp+0x30]
000073baab9e11ab  vmovaps xmm4, [rsp+0x40]
000073baab9e11b1  vmovaps xmm5, [rsp+0x50]
000073baab9e11b7  vmovaps xmm6, [rsp+0x60]
000073baab9e11bd  vmovaps xmm8, [rsp+0x70]
000073baab9e11c3  vmovaps xmm9, [rsp+0x80]
000073baab9e11cc  vmovaps xmm10, [rsp+0x90]
000073baab9e11d5  vmovaps xmm11, [rsp+0xA0]
000073baab9e11de  vmovaps xmm12, [rsp+0xB0]
000073baab9e11e7  vmovaps xmm13, [rsp+0xC0]
000073baab9e11f0  vmovaps xmm14, [rsp+0xD0]
000073baab9e11f9  vmovaps xmm15, [rsp+0xE0]
000073baab9e1202  add rsp, 0xF0
000073baab9e1209  pop r11
000073baab9e120b  pop r10
000073baab9e120d  pop r9
000073baab9e120f  pop r8
000073baab9e1211  pop rsi
000073baab9e1212  pop rdi
000073baab9e1213  pop rdx
000073baab9e1214  pop rcx
000073baab9e1215  pop rax
000073baab9e1216  add rsp, 0x08
000073baab9e121a  jmp 0x000073BAAB9DF246
000073baab9e121f  call 0x000073BAAB8B52F0
000073baab9e1224  jmp 0x000073BAAB9DF253
000073baab9e1229  sub rsp, 0x08
000073baab9e122d  push rax
000073baab9e122e  push rcx
000073baab9e122f  push rdx
000073baab9e1230  push rdi
000073baab9e1231  push rsi
000073baab9e1232  push r8
000073baab9e1234  push r9
000073baab9e1236  push r10
000073baab9e1238  push r11
000073baab9e123a  sub rsp, 0xF0
000073baab9e1241  vmovaps [rsp], xmm0
000073baab9e1246  vmovaps [rsp+0x10], xmm1
000073baab9e124c  vmovaps [rsp+0x20], xmm2
000073baab9e1252  vmovaps [rsp+0x30], xmm3
000073baab9e1258  vmovaps [rsp+0x40], xmm4
000073baab9e125e  vmovaps [rsp+0x50], xmm5
000073baab9e1264  vmovaps [rsp+0x60], xmm6
000073baab9e126a  vmovaps [rsp+0x70], xmm7
000073baab9e1270  vmovaps [rsp+0x80], xmm8
000073baab9e1279  vmovaps [rsp+0x90], xmm9
000073baab9e1282  vmovaps [rsp+0xA0], xmm10
000073baab9e128b  vmovaps [rsp+0xB0], xmm11
000073baab9e1294  vmovaps [rsp+0xC0], xmm12
000073baab9e129d  vmovaps [rsp+0xD0], xmm13
000073baab9e12a6  vmovaps [rsp+0xE0], xmm14
000073baab9e12af  sub rsp, 0x30
000073baab9e12b3  movaps [rsp], xmm15
000073baab9e12b8  movaps [rsp+0x10], xmm5
000073baab9e12bd  movaps [rsp+0x20], xmm3
000073baab9e12c2  lea rdi, [rsp]
000073baab9e12c6  mov esi, 0x00
000073baab9e12cb  mov rax, 0x5F3F1062D530
000073baab9e12d5  call rax
000073baab9e12d7  movaps xmm15, [rsp]
000073baab9e12dc  add rsp, 0x30
000073baab9e12e0  vmovaps xmm0, [rsp]
000073baab9e12e5  vmovaps xmm1, [rsp+0x10]
000073baab9e12eb  vmovaps xmm2, [rsp+0x20]
000073baab9e12f1  vmovaps xmm3, [rsp+0x30]
000073baab9e12f7  vmovaps xmm4, [rsp+0x40]
000073baab9e12fd  vmovaps xmm5, [rsp+0x50]
000073baab9e1303  vmovaps xmm6, [rsp+0x60]
000073baab9e1309  vmovaps xmm7, [rsp+0x70]
000073baab9e130f  vmovaps xmm8, [rsp+0x80]
000073baab9e1318  vmovaps xmm9, [rsp+0x90]
000073baab9e1321  vmovaps xmm10, [rsp+0xA0]
000073baab9e132a  vmovaps xmm11, [rsp+0xB0]
000073baab9e1333  vmovaps xmm12, [rsp+0xC0]
000073baab9e133c  vmovaps xmm13, [rsp+0xD0]
000073baab9e1345  vmovaps xmm14, [rsp+0xE0]
000073baab9e134e  add rsp, 0xF0
000073baab9e1355  pop r11
000073baab9e1357  pop r10
000073baab9e1359  pop r9
000073baab9e135b  pop r8
000073baab9e135d  pop rsi
000073baab9e135e  pop rdi
000073baab9e135f  pop rdx
000073baab9e1360  pop rcx
000073baab9e1361  pop rax
000073baab9e1362  add rsp, 0x08
000073baab9e1366  jmp 0x000073BAAB9DF279
000073baab9e136b  sub rsp, 0x08
000073baab9e136f  push rax
000073baab9e1370  push rcx
000073baab9e1371  push rdx
000073baab9e1372  push rdi
000073baab9e1373  push rsi
000073baab9e1374  push r8
000073baab9e1376  push r9
000073baab9e1378  push r10
000073baab9e137a  push r11
000073baab9e137c  sub rsp, 0xF0
000073baab9e1383  vmovaps [rsp], xmm0
000073baab9e1388  vmovaps [rsp+0x10], xmm2
000073baab9e138e  vmovaps [rsp+0x20], xmm3
000073baab9e1394  vmovaps [rsp+0x30], xmm4
000073baab9e139a  vmovaps [rsp+0x40], xmm5
000073baab9e13a0  vmovaps [rsp+0x50], xmm6
000073baab9e13a6  vmovaps [rsp+0x60], xmm7
000073baab9e13ac  vmovaps [rsp+0x70], xmm8
000073baab9e13b2  vmovaps [rsp+0x80], xmm9
000073baab9e13bb  vmovaps [rsp+0x90], xmm10
000073baab9e13c4  vmovaps [rsp+0xA0], xmm11
000073baab9e13cd  vmovaps [rsp+0xB0], xmm12
000073baab9e13d6  vmovaps [rsp+0xC0], xmm13
000073baab9e13df  vmovaps [rsp+0xD0], xmm14
000073baab9e13e8  vmovaps [rsp+0xE0], xmm15
000073baab9e13f1  sub rsp, 0x30
000073baab9e13f5  movaps [rsp], xmm1
000073baab9e13f9  movaps [rsp+0x10], xmm5
000073baab9e13fe  movaps [rsp+0x20], xmm4
000073baab9e1403  lea rdi, [rsp]
000073baab9e1407  mov esi, 0x00
000073baab9e140c  mov rax, 0x5F3F1062D530
000073baab9e1416  call rax
000073baab9e1418  movaps xmm1, [rsp]
000073baab9e141c  add rsp, 0x30
000073baab9e1420  vmovaps xmm0, [rsp]
000073baab9e1425  vmovaps xmm2, [rsp+0x10]
000073baab9e142b  vmovaps xmm3, [rsp+0x20]
000073baab9e1431  vmovaps xmm4, [rsp+0x30]
000073baab9e1437  vmovaps xmm5, [rsp+0x40]
000073baab9e143d  vmovaps xmm6, [rsp+0x50]
000073baab9e1443  vmovaps xmm7, [rsp+0x60]
000073baab9e1449  vmovaps xmm8, [rsp+0x70]
000073baab9e144f  vmovaps xmm9, [rsp+0x80]
000073baab9e1458  vmovaps xmm10, [rsp+0x90]
000073baab9e1461  vmovaps xmm11, [rsp+0xA0]
000073baab9e146a  vmovaps xmm12, [rsp+0xB0]
000073baab9e1473  vmovaps xmm13, [rsp+0xC0]
000073baab9e147c  vmovaps xmm14, [rsp+0xD0]
000073baab9e1485  vmovaps xmm15, [rsp+0xE0]
000073baab9e148e  add rsp, 0xF0
000073baab9e1495  pop r11
000073baab9e1497  pop r10
000073baab9e1499  pop r9
000073baab9e149b  pop r8
000073baab9e149d  pop rsi
000073baab9e149e  pop rdi
000073baab9e149f  pop rdx
000073baab9e14a0  pop rcx
000073baab9e14a1  pop rax
000073baab9e14a2  add rsp, 0x08
000073baab9e14a6  jmp 0x000073BAAB9DF299
000073baab9e14ab  sub rsp, 0x08
000073baab9e14af  push rax
000073baab9e14b0  push rcx
000073baab9e14b1  push rdx
000073baab9e14b2  push rdi
000073baab9e14b3  push rsi
000073baab9e14b4  push r8
000073baab9e14b6  push r9
000073baab9e14b8  push r10
000073baab9e14ba  push r11
000073baab9e14bc  sub rsp, 0xF0
000073baab9e14c3  vmovaps [rsp], xmm0
000073baab9e14c8  vmovaps [rsp+0x10], xmm1
000073baab9e14ce  vmovaps [rsp+0x20], xmm2
000073baab9e14d4  vmovaps [rsp+0x30], xmm3
000073baab9e14da  vmovaps [rsp+0x40], xmm5
000073baab9e14e0  vmovaps [rsp+0x50], xmm6
000073baab9e14e6  vmovaps [rsp+0x60], xmm7
000073baab9e14ec  vmovaps [rsp+0x70], xmm8
000073baab9e14f2  vmovaps [rsp+0x80], xmm9
000073baab9e14fb  vmovaps [rsp+0x90], xmm10
000073baab9e1504  vmovaps [rsp+0xA0], xmm11
000073baab9e150d  vmovaps [rsp+0xB0], xmm12
000073baab9e1516  vmovaps [rsp+0xC0], xmm13
000073baab9e151f  vmovaps [rsp+0xD0], xmm14
000073baab9e1528  vmovaps [rsp+0xE0], xmm15
000073baab9e1531  sub rsp, 0x30
000073baab9e1535  movaps [rsp], xmm4
000073baab9e1539  movaps [rsp+0x10], xmm3
000073baab9e153e  movaps [rsp+0x20], xmm5
000073baab9e1543  lea rdi, [rsp]
000073baab9e1547  mov esi, 0x00
000073baab9e154c  mov rax, 0x5F3F1062D530
000073baab9e1556  call rax
000073baab9e1558  movaps xmm4, [rsp]
000073baab9e155c  add rsp, 0x30
000073baab9e1560  vmovaps xmm0, [rsp]
000073baab9e1565  vmovaps xmm1, [rsp+0x10]
000073baab9e156b  vmovaps xmm2, [rsp+0x20]
000073baab9e1571  vmovaps xmm3, [rsp+0x30]
000073baab9e1577  vmovaps xmm5, [rsp+0x40]
000073baab9e157d  vmovaps xmm6, [rsp+0x50]
000073baab9e1583  vmovaps xmm7, [rsp+0x60]
000073baab9e1589  vmovaps xmm8, [rsp+0x70]
000073baab9e158f  vmovaps xmm9, [rsp+0x80]
000073baab9e1598  vmovaps xmm10, [rsp+0x90]
000073baab9e15a1  vmovaps xmm11, [rsp+0xA0]
000073baab9e15aa  vmovaps xmm12, [rsp+0xB0]
000073baab9e15b3  vmovaps xmm13, [rsp+0xC0]
000073baab9e15bc  vmovaps xmm14, [rsp+0xD0]
000073baab9e15c5  vmovaps xmm15, [rsp+0xE0]
000073baab9e15ce  add rsp, 0xF0
000073baab9e15d5  pop r11
000073baab9e15d7  pop r10
000073baab9e15d9  pop r9
000073baab9e15db  pop r8
000073baab9e15dd  pop rsi
000073baab9e15de  pop rdi
000073baab9e15df  pop rdx
000073baab9e15e0  pop rcx
000073baab9e15e1  pop rax
000073baab9e15e2  add rsp, 0x08
000073baab9e15e6  jmp 0x000073BAAB9DF2E7
000073baab9e15eb  call 0x000073BAAB8B52F0
000073baab9e15f0  jmp 0x000073BAAB9DF2F4
000073baab9e15f5  sub rsp, 0x08
000073baab9e15f9  push rax
000073baab9e15fa  push rcx
000073baab9e15fb  push rdx
000073baab9e15fc  push rdi
000073baab9e15fd  push rsi
000073baab9e15fe  push r8
000073baab9e1600  push r9
000073baab9e1602  push r10
000073baab9e1604  push r11
000073baab9e1606  sub rsp, 0xF0
000073baab9e160d  vmovaps [rsp], xmm0
000073baab9e1612  vmovaps [rsp+0x10], xmm1
000073baab9e1618  vmovaps [rsp+0x20], xmm2
000073baab9e161e  vmovaps [rsp+0x30], xmm3
000073baab9e1624  vmovaps [rsp+0x40], xmm4
000073baab9e162a  vmovaps [rsp+0x50], xmm6
000073baab9e1630  vmovaps [rsp+0x60], xmm7
000073baab9e1636  vmovaps [rsp+0x70], xmm8
000073baab9e163c  vmovaps [rsp+0x80], xmm9
000073baab9e1645  vmovaps [rsp+0x90], xmm10
000073baab9e164e  vmovaps [rsp+0xA0], xmm11
000073baab9e1657  vmovaps [rsp+0xB0], xmm12
000073baab9e1660  vmovaps [rsp+0xC0], xmm13
000073baab9e1669  vmovaps [rsp+0xD0], xmm14
000073baab9e1672  vmovaps [rsp+0xE0], xmm15
000073baab9e167b  sub rsp, 0x30
000073baab9e167f  movaps [rsp], xmm5
000073baab9e1683  movaps [rsp+0x10], xmm6
000073baab9e1688  movaps [rsp+0x20], xmm3
000073baab9e168d  lea rdi, [rsp]
000073baab9e1691  mov esi, 0x00
000073baab9e1696  mov rax, 0x5F3F1062D530
000073baab9e16a0  call rax
000073baab9e16a2  movaps xmm5, [rsp]
000073baab9e16a6  add rsp, 0x30
000073baab9e16aa  vmovaps xmm0, [rsp]
000073baab9e16af  vmovaps xmm1, [rsp+0x10]
000073baab9e16b5  vmovaps xmm2, [rsp+0x20]
000073baab9e16bb  vmovaps xmm3, [rsp+0x30]
000073baab9e16c1  vmovaps xmm4, [rsp+0x40]
000073baab9e16c7  vmovaps xmm6, [rsp+0x50]
000073baab9e16cd  vmovaps xmm7, [rsp+0x60]
000073baab9e16d3  vmovaps xmm8, [rsp+0x70]
000073baab9e16d9  vmovaps xmm9, [rsp+0x80]
000073baab9e16e2  vmovaps xmm10, [rsp+0x90]
000073baab9e16eb  vmovaps xmm11, [rsp+0xA0]
000073baab9e16f4  vmovaps xmm12, [rsp+0xB0]
000073baab9e16fd  vmovaps xmm13, [rsp+0xC0]
000073baab9e1706  vmovaps xmm14, [rsp+0xD0]
000073baab9e170f  vmovaps xmm15, [rsp+0xE0]
000073baab9e1718  add rsp, 0xF0
000073baab9e171f  pop r11
000073baab9e1721  pop r10
000073baab9e1723  pop r9
000073baab9e1725  pop r8
000073baab9e1727  pop rsi
000073baab9e1728  pop rdi
000073baab9e1729  pop rdx
000073baab9e172a  pop rcx
000073baab9e172b  pop rax
000073baab9e172c  add rsp, 0x08
000073baab9e1730  jmp 0x000073BAAB9DF31A
000073baab9e1735  sub rsp, 0x08
000073baab9e1739  push rax
000073baab9e173a  push rcx
000073baab9e173b  push rdx
000073baab9e173c  push rdi
000073baab9e173d  push rsi
000073baab9e173e  push r8
000073baab9e1740  push r9
000073baab9e1742  push r10
000073baab9e1744  push r11
000073baab9e1746  sub rsp, 0xF0
000073baab9e174d  vmovaps [rsp], xmm0
000073baab9e1752  vmovaps [rsp+0x10], xmm1
000073baab9e1758  vmovaps [rsp+0x20], xmm2
000073baab9e175e  vmovaps [rsp+0x30], xmm3
000073baab9e1764  vmovaps [rsp+0x40], xmm4
000073baab9e176a  vmovaps [rsp+0x50], xmm5
000073baab9e1770  vmovaps [rsp+0x60], xmm7
000073baab9e1776  vmovaps [rsp+0x70], xmm8
000073baab9e177c  vmovaps [rsp+0x80], xmm9
000073baab9e1785  vmovaps [rsp+0x90], xmm10
000073baab9e178e  vmovaps [rsp+0xA0], xmm11
000073baab9e1797  vmovaps [rsp+0xB0], xmm12
000073baab9e17a0  vmovaps [rsp+0xC0], xmm13
000073baab9e17a9  vmovaps [rsp+0xD0], xmm14
000073baab9e17b2  vmovaps [rsp+0xE0], xmm15
000073baab9e17bb  sub rsp, 0x30
000073baab9e17bf  movaps [rsp], xmm6
000073baab9e17c3  movaps [rsp+0x10], xmm9
000073baab9e17c9  movaps [rsp+0x20], xmm1
000073baab9e17ce  lea rdi, [rsp]
000073baab9e17d2  mov esi, 0x00
000073baab9e17d7  mov rax, 0x5F3F1062D530
000073baab9e17e1  call rax
000073baab9e17e3  movaps xmm6, [rsp]
000073baab9e17e7  add rsp, 0x30
000073baab9e17eb  vmovaps xmm0, [rsp]
000073baab9e17f0  vmovaps xmm1, [rsp+0x10]
000073baab9e17f6  vmovaps xmm2, [rsp+0x20]
000073baab9e17fc  vmovaps xmm3, [rsp+0x30]
000073baab9e1802  vmovaps xmm4, [rsp+0x40]
000073baab9e1808  vmovaps xmm5, [rsp+0x50]
000073baab9e180e  vmovaps xmm7, [rsp+0x60]
000073baab9e1814  vmovaps xmm8, [rsp+0x70]
000073baab9e181a  vmovaps xmm9, [rsp+0x80]
000073baab9e1823  vmovaps xmm10, [rsp+0x90]
000073baab9e182c  vmovaps xmm11, [rsp+0xA0]
000073baab9e1835  vmovaps xmm12, [rsp+0xB0]
000073baab9e183e  vmovaps xmm13, [rsp+0xC0]
000073baab9e1847  vmovaps xmm14, [rsp+0xD0]
000073baab9e1850  vmovaps xmm15, [rsp+0xE0]
000073baab9e1859  add rsp, 0xF0
000073baab9e1860  pop r11
000073baab9e1862  pop r10
000073baab9e1864  pop r9
000073baab9e1866  pop r8
000073baab9e1868  pop rsi
000073baab9e1869  pop rdi
000073baab9e186a  pop rdx
000073baab9e186b  pop rcx
000073baab9e186c  pop rax
000073baab9e186d  add rsp, 0x08
000073baab9e1871  jmp 0x000073BAAB9DF33E
000073baab9e1876  sub rsp, 0x08
000073baab9e187a  push rax
000073baab9e187b  push rcx
000073baab9e187c  push rdx
000073baab9e187d  push rdi
000073baab9e187e  push rsi
000073baab9e187f  push r8
000073baab9e1881  push r9
000073baab9e1883  push r10
000073baab9e1885  push r11
000073baab9e1887  sub rsp, 0xF0
000073baab9e188e  vmovaps [rsp], xmm0
000073baab9e1893  vmovaps [rsp+0x10], xmm1
000073baab9e1899  vmovaps [rsp+0x20], xmm2
000073baab9e189f  vmovaps [rsp+0x30], xmm3
000073baab9e18a5  vmovaps [rsp+0x40], xmm4
000073baab9e18ab  vmovaps [rsp+0x50], xmm5
000073baab9e18b1  vmovaps [rsp+0x60], xmm6
000073baab9e18b7  vmovaps [rsp+0x70], xmm7
000073baab9e18bd  vmovaps [rsp+0x80], xmm8
000073baab9e18c6  vmovaps [rsp+0x90], xmm10
000073baab9e18cf  vmovaps [rsp+0xA0], xmm11
000073baab9e18d8  vmovaps [rsp+0xB0], xmm12
000073baab9e18e1  vmovaps [rsp+0xC0], xmm13
000073baab9e18ea  vmovaps [rsp+0xD0], xmm14
000073baab9e18f3  vmovaps [rsp+0xE0], xmm15
000073baab9e18fc  sub rsp, 0x30
000073baab9e1900  movaps [rsp], xmm9
000073baab9e1905  movaps [rsp+0x10], xmm3
000073baab9e190a  movaps [rsp+0x20], xmm1
000073baab9e190f  lea rdi, [rsp]
000073baab9e1913  mov esi, 0x00
000073baab9e1918  mov rax, 0x5F3F1062D530
000073baab9e1922  call rax
000073baab9e1924  movaps xmm9, [rsp]
000073baab9e1929  add rsp, 0x30
000073baab9e192d  vmovaps xmm0, [rsp]
000073baab9e1932  vmovaps xmm1, [rsp+0x10]
000073baab9e1938  vmovaps xmm2, [rsp+0x20]
000073baab9e193e  vmovaps xmm3, [rsp+0x30]
000073baab9e1944  vmovaps xmm4, [rsp+0x40]
000073baab9e194a  vmovaps xmm5, [rsp+0x50]
000073baab9e1950  vmovaps xmm6, [rsp+0x60]
000073baab9e1956  vmovaps xmm7, [rsp+0x70]
000073baab9e195c  vmovaps xmm8, [rsp+0x80]
000073baab9e1965  vmovaps xmm10, [rsp+0x90]
000073baab9e196e  vmovaps xmm11, [rsp+0xA0]
000073baab9e1977  vmovaps xmm12, [rsp+0xB0]
000073baab9e1980  vmovaps xmm13, [rsp+0xC0]
000073baab9e1989  vmovaps xmm14, [rsp+0xD0]
000073baab9e1992  vmovaps xmm15, [rsp+0xE0]
000073baab9e199b  add rsp, 0xF0
000073baab9e19a2  pop r11
000073baab9e19a4  pop r10
000073baab9e19a6  pop r9
000073baab9e19a8  pop r8
000073baab9e19aa  pop rsi
000073baab9e19ab  pop rdi
000073baab9e19ac  pop rdx
000073baab9e19ad  pop rcx
000073baab9e19ae  pop rax
000073baab9e19af  add rsp, 0x08
000073baab9e19b3  jmp 0x000073BAAB9DF38A
000073baab9e19b8  call 0x000073BAAB8B52F0
000073baab9e19bd  jmp 0x000073BAAB9DF397
000073baab9e19c2  sub rsp, 0x08
000073baab9e19c6  push rax
000073baab9e19c7  push rcx
000073baab9e19c8  push rdx
000073baab9e19c9  push rdi
000073baab9e19ca  push rsi
000073baab9e19cb  push r8
000073baab9e19cd  push r9
000073baab9e19cf  push r10
000073baab9e19d1  push r11
000073baab9e19d3  sub rsp, 0xF0
000073baab9e19da  vmovaps [rsp], xmm0
000073baab9e19df  vmovaps [rsp+0x10], xmm1
000073baab9e19e5  vmovaps [rsp+0x20], xmm2
000073baab9e19eb  vmovaps [rsp+0x30], xmm3
000073baab9e19f1  vmovaps [rsp+0x40], xmm4
000073baab9e19f7  vmovaps [rsp+0x50], xmm5
000073baab9e19fd  vmovaps [rsp+0x60], xmm6
000073baab9e1a03  vmovaps [rsp+0x70], xmm7
000073baab9e1a09  vmovaps [rsp+0x80], xmm8
000073baab9e1a12  vmovaps [rsp+0x90], xmm9
000073baab9e1a1b  vmovaps [rsp+0xA0], xmm10
000073baab9e1a24  vmovaps [rsp+0xB0], xmm11
000073baab9e1a2d  vmovaps [rsp+0xC0], xmm12
000073baab9e1a36  vmovaps [rsp+0xD0], xmm13
000073baab9e1a3f  vmovaps [rsp+0xE0], xmm14
000073baab9e1a48  sub rsp, 0x30
000073baab9e1a4c  movaps [rsp], xmm15
000073baab9e1a51  movaps [rsp+0x10], xmm3
000073baab9e1a56  movaps [rsp+0x20], xmm7
000073baab9e1a5b  lea rdi, [rsp]
000073baab9e1a5f  mov esi, 0x00
000073baab9e1a64  mov rax, 0x5F3F1062D530
000073baab9e1a6e  call rax
000073baab9e1a70  movaps xmm15, [rsp]
000073baab9e1a75  add rsp, 0x30
000073baab9e1a79  vmovaps xmm0, [rsp]
000073baab9e1a7e  vmovaps xmm1, [rsp+0x10]
000073baab9e1a84  vmovaps xmm2, [rsp+0x20]
000073baab9e1a8a  vmovaps xmm3, [rsp+0x30]
000073baab9e1a90  vmovaps xmm4, [rsp+0x40]
000073baab9e1a96  vmovaps xmm5, [rsp+0x50]
000073baab9e1a9c  vmovaps xmm6, [rsp+0x60]
000073baab9e1aa2  vmovaps xmm7, [rsp+0x70]
000073baab9e1aa8  vmovaps xmm8, [rsp+0x80]
000073baab9e1ab1  vmovaps xmm9, [rsp+0x90]
000073baab9e1aba  vmovaps xmm10, [rsp+0xA0]
000073baab9e1ac3  vmovaps xmm11, [rsp+0xB0]
000073baab9e1acc  vmovaps xmm12, [rsp+0xC0]
000073baab9e1ad5  vmovaps xmm13, [rsp+0xD0]
000073baab9e1ade  vmovaps xmm14, [rsp+0xE0]
000073baab9e1ae7  add rsp, 0xF0
000073baab9e1aee  pop r11
000073baab9e1af0  pop r10
000073baab9e1af2  pop r9
000073baab9e1af4  pop r8
000073baab9e1af6  pop rsi
000073baab9e1af7  pop rdi
000073baab9e1af8  pop rdx
000073baab9e1af9  pop rcx
000073baab9e1afa  pop rax
000073baab9e1afb  add rsp, 0x08
000073baab9e1aff  jmp 0x000073BAAB9DF3C3
000073baab9e1b04  sub rsp, 0x08
000073baab9e1b08  push rax
000073baab9e1b09  push rcx
000073baab9e1b0a  push rdx
000073baab9e1b0b  push rdi
000073baab9e1b0c  push rsi
000073baab9e1b0d  push r8
000073baab9e1b0f  push r9
000073baab9e1b11  push r10
000073baab9e1b13  push r11
000073baab9e1b15  sub rsp, 0xF0
000073baab9e1b1c  vmovaps [rsp], xmm0
000073baab9e1b21  vmovaps [rsp+0x10], xmm1
000073baab9e1b27  vmovaps [rsp+0x20], xmm2
000073baab9e1b2d  vmovaps [rsp+0x30], xmm4
000073baab9e1b33  vmovaps [rsp+0x40], xmm5
000073baab9e1b39  vmovaps [rsp+0x50], xmm6
000073baab9e1b3f  vmovaps [rsp+0x60], xmm7
000073baab9e1b45  vmovaps [rsp+0x70], xmm8
000073baab9e1b4b  vmovaps [rsp+0x80], xmm9
000073baab9e1b54  vmovaps [rsp+0x90], xmm10
000073baab9e1b5d  vmovaps [rsp+0xA0], xmm11
000073baab9e1b66  vmovaps [rsp+0xB0], xmm12
000073baab9e1b6f  vmovaps [rsp+0xC0], xmm13
000073baab9e1b78  vmovaps [rsp+0xD0], xmm14
000073baab9e1b81  vmovaps [rsp+0xE0], xmm15
000073baab9e1b8a  sub rsp, 0x30
000073baab9e1b8e  movaps [rsp], xmm3
000073baab9e1b92  movaps [rsp+0x10], xmm1
000073baab9e1b97  movaps [rsp+0x20], xmm15
000073baab9e1b9d  lea rdi, [rsp]
000073baab9e1ba1  mov esi, 0x00
000073baab9e1ba6  mov rax, 0x5F3F1062D530
000073baab9e1bb0  call rax
000073baab9e1bb2  movaps xmm3, [rsp]
000073baab9e1bb6  add rsp, 0x30
000073baab9e1bba  vmovaps xmm0, [rsp]
000073baab9e1bbf  vmovaps xmm1, [rsp+0x10]
000073baab9e1bc5  vmovaps xmm2, [rsp+0x20]
000073baab9e1bcb  vmovaps xmm4, [rsp+0x30]
000073baab9e1bd1  vmovaps xmm5, [rsp+0x40]
000073baab9e1bd7  vmovaps xmm6, [rsp+0x50]
000073baab9e1bdd  vmovaps xmm7, [rsp+0x60]
000073baab9e1be3  vmovaps xmm8, [rsp+0x70]
000073baab9e1be9  vmovaps xmm9, [rsp+0x80]
000073baab9e1bf2  vmovaps xmm10, [rsp+0x90]
000073baab9e1bfb  vmovaps xmm11, [rsp+0xA0]
000073baab9e1c04  vmovaps xmm12, [rsp+0xB0]
000073baab9e1c0d  vmovaps xmm13, [rsp+0xC0]
000073baab9e1c16  vmovaps xmm14, [rsp+0xD0]
000073baab9e1c1f  vmovaps xmm15, [rsp+0xE0]
000073baab9e1c28  add rsp, 0xF0
000073baab9e1c2f  pop r11
000073baab9e1c31  pop r10
000073baab9e1c33  pop r9
000073baab9e1c35  pop r8
000073baab9e1c37  pop rsi
000073baab9e1c38  pop rdi
000073baab9e1c39  pop rdx
000073baab9e1c3a  pop rcx
000073baab9e1c3b  pop rax
000073baab9e1c3c  add rsp, 0x08
000073baab9e1c40  jmp 0x000073BAAB9DF452
000073baab9e1c45  call 0x000073BAAB8B52F0
000073baab9e1c4a  jmp 0x000073BAAB9DF45C
000073baab9e1c4f  sub rsp, 0x08
000073baab9e1c53  push rax
000073baab9e1c54  push rcx
000073baab9e1c55  push rdx
000073baab9e1c56  push rdi
000073baab9e1c57  push rsi
000073baab9e1c58  push r8
000073baab9e1c5a  push r9
000073baab9e1c5c  push r10
000073baab9e1c5e  push r11
000073baab9e1c60  sub rsp, 0xF0
000073baab9e1c67  vmovaps [rsp], xmm0
000073baab9e1c6c  vmovaps [rsp+0x10], xmm1
000073baab9e1c72  vmovaps [rsp+0x20], xmm2
000073baab9e1c78  vmovaps [rsp+0x30], xmm3
000073baab9e1c7e  vmovaps [rsp+0x40], xmm4
000073baab9e1c84  vmovaps [rsp+0x50], xmm5
000073baab9e1c8a  vmovaps [rsp+0x60], xmm6
000073baab9e1c90  vmovaps [rsp+0x70], xmm7
000073baab9e1c96  vmovaps [rsp+0x80], xmm8
000073baab9e1c9f  vmovaps [rsp+0x90], xmm9
000073baab9e1ca8  vmovaps [rsp+0xA0], xmm10
000073baab9e1cb1  vmovaps [rsp+0xB0], xmm11
000073baab9e1cba  vmovaps [rsp+0xC0], xmm12
000073baab9e1cc3  vmovaps [rsp+0xD0], xmm13
000073baab9e1ccc  vmovaps [rsp+0xE0], xmm14
000073baab9e1cd5  sub rsp, 0x30
000073baab9e1cd9  movaps [rsp], xmm15
000073baab9e1cde  movaps [rsp+0x10], xmm14
000073baab9e1ce4  movaps [rsp+0x20], xmm4
000073baab9e1ce9  lea rdi, [rsp]
000073baab9e1ced  mov esi, 0x00
000073baab9e1cf2  mov rax, 0x5F3F1062D530
000073baab9e1cfc  call rax
000073baab9e1cfe  movaps xmm15, [rsp]
000073baab9e1d03  add rsp, 0x30
000073baab9e1d07  vmovaps xmm0, [rsp]
000073baab9e1d0c  vmovaps xmm1, [rsp+0x10]
000073baab9e1d12  vmovaps xmm2, [rsp+0x20]
000073baab9e1d18  vmovaps xmm3, [rsp+0x30]
000073baab9e1d1e  vmovaps xmm4, [rsp+0x40]
000073baab9e1d24  vmovaps xmm5, [rsp+0x50]
000073baab9e1d2a  vmovaps xmm6, [rsp+0x60]
000073baab9e1d30  vmovaps xmm7, [rsp+0x70]
000073baab9e1d36  vmovaps xmm8, [rsp+0x80]
000073baab9e1d3f  vmovaps xmm9, [rsp+0x90]
000073baab9e1d48  vmovaps xmm10, [rsp+0xA0]
000073baab9e1d51  vmovaps xmm11, [rsp+0xB0]
000073baab9e1d5a  vmovaps xmm12, [rsp+0xC0]
000073baab9e1d63  vmovaps xmm13, [rsp+0xD0]
000073baab9e1d6c  vmovaps xmm14, [rsp+0xE0]
000073baab9e1d75  add rsp, 0xF0
000073baab9e1d7c  pop r11
000073baab9e1d7e  pop r10
000073baab9e1d80  pop r9
000073baab9e1d82  pop r8
000073baab9e1d84  pop rsi
000073baab9e1d85  pop rdi
000073baab9e1d86  pop rdx
000073baab9e1d87  pop rcx
000073baab9e1d88  pop rax
000073baab9e1d89  add rsp, 0x08
000073baab9e1d8d  jmp 0x000073BAAB9DF48A
000073baab9e1d92  sub rsp, 0x08
000073baab9e1d96  push rax
000073baab9e1d97  push rcx
000073baab9e1d98  push rdx
000073baab9e1d99  push rdi
000073baab9e1d9a  push rsi
000073baab9e1d9b  push r8
000073baab9e1d9d  push r9
000073baab9e1d9f  push r10
000073baab9e1da1  push r11
000073baab9e1da3  sub rsp, 0xF0
000073baab9e1daa  vmovaps [rsp], xmm0
000073baab9e1daf  vmovaps [rsp+0x10], xmm1
000073baab9e1db5  vmovaps [rsp+0x20], xmm2
000073baab9e1dbb  vmovaps [rsp+0x30], xmm3
000073baab9e1dc1  vmovaps [rsp+0x40], xmm4
000073baab9e1dc7  vmovaps [rsp+0x50], xmm5
000073baab9e1dcd  vmovaps [rsp+0x60], xmm6
000073baab9e1dd3  vmovaps [rsp+0x70], xmm7
000073baab9e1dd9  vmovaps [rsp+0x80], xmm8
000073baab9e1de2  vmovaps [rsp+0x90], xmm9
000073baab9e1deb  vmovaps [rsp+0xA0], xmm10
000073baab9e1df4  vmovaps [rsp+0xB0], xmm11
000073baab9e1dfd  vmovaps [rsp+0xC0], xmm12
000073baab9e1e06  vmovaps [rsp+0xD0], xmm13
000073baab9e1e0f  vmovaps [rsp+0xE0], xmm15
000073baab9e1e18  sub rsp, 0x30
000073baab9e1e1c  movaps [rsp], xmm14
000073baab9e1e21  movaps [rsp+0x10], xmm2
000073baab9e1e26  movaps [rsp+0x20], xmm1
000073baab9e1e2b  lea rdi, [rsp]
000073baab9e1e2f  mov esi, 0x00
000073baab9e1e34  mov rax, 0x5F3F1062D530
000073baab9e1e3e  call rax
000073baab9e1e40  movaps xmm14, [rsp]
000073baab9e1e45  add rsp, 0x30
000073baab9e1e49  vmovaps xmm0, [rsp]
000073baab9e1e4e  vmovaps xmm1, [rsp+0x10]
000073baab9e1e54  vmovaps xmm2, [rsp+0x20]
000073baab9e1e5a  vmovaps xmm3, [rsp+0x30]
000073baab9e1e60  vmovaps xmm4, [rsp+0x40]
000073baab9e1e66  vmovaps xmm5, [rsp+0x50]
000073baab9e1e6c  vmovaps xmm6, [rsp+0x60]
000073baab9e1e72  vmovaps xmm7, [rsp+0x70]
000073baab9e1e78  vmovaps xmm8, [rsp+0x80]
000073baab9e1e81  vmovaps xmm9, [rsp+0x90]
000073baab9e1e8a  vmovaps xmm10, [rsp+0xA0]
000073baab9e1e93  vmovaps xmm11, [rsp+0xB0]
000073baab9e1e9c  vmovaps xmm12, [rsp+0xC0]
000073baab9e1ea5  vmovaps xmm13, [rsp+0xD0]
000073baab9e1eae  vmovaps xmm15, [rsp+0xE0]
000073baab9e1eb7  add rsp, 0xF0
000073baab9e1ebe  pop r11
000073baab9e1ec0  pop r10
000073baab9e1ec2  pop r9
000073baab9e1ec4  pop r8
000073baab9e1ec6  pop rsi
000073baab9e1ec7  pop rdi
000073baab9e1ec8  pop rdx
000073baab9e1ec9  pop rcx
000073baab9e1eca  pop rax
000073baab9e1ecb  add rsp, 0x08
000073baab9e1ecf  jmp 0x000073BAAB9DF4B0
000073baab9e1ed4  sub rsp, 0x08
000073baab9e1ed8  push rax
000073baab9e1ed9  push rcx
000073baab9e1eda  push rdx
000073baab9e1edb  push rdi
000073baab9e1edc  push rsi
000073baab9e1edd  push r8
000073baab9e1edf  push r9
000073baab9e1ee1  push r10
000073baab9e1ee3  push r11
000073baab9e1ee5  sub rsp, 0xF0
000073baab9e1eec  vmovaps [rsp], xmm0
000073baab9e1ef1  vmovaps [rsp+0x10], xmm2
000073baab9e1ef7  vmovaps [rsp+0x20], xmm3
000073baab9e1efd  vmovaps [rsp+0x30], xmm4
000073baab9e1f03  vmovaps [rsp+0x40], xmm5
000073baab9e1f09  vmovaps [rsp+0x50], xmm6
000073baab9e1f0f  vmovaps [rsp+0x60], xmm7
000073baab9e1f15  vmovaps [rsp+0x70], xmm8
000073baab9e1f1b  vmovaps [rsp+0x80], xmm9
000073baab9e1f24  vmovaps [rsp+0x90], xmm10
000073baab9e1f2d  vmovaps [rsp+0xA0], xmm11
000073baab9e1f36  vmovaps [rsp+0xB0], xmm12
000073baab9e1f3f  vmovaps [rsp+0xC0], xmm13
000073baab9e1f48  vmovaps [rsp+0xD0], xmm14
000073baab9e1f51  vmovaps [rsp+0xE0], xmm15
000073baab9e1f5a  sub rsp, 0x30
000073baab9e1f5e  movaps [rsp], xmm1
000073baab9e1f62  movaps [rsp+0x10], xmm4
000073baab9e1f67  movaps [rsp+0x20], xmm9
000073baab9e1f6d  lea rdi, [rsp]
000073baab9e1f71  mov esi, 0x00
000073baab9e1f76  mov rax, 0x5F3F1062D530
000073baab9e1f80  call rax
000073baab9e1f82  movaps xmm1, [rsp]
000073baab9e1f86  add rsp, 0x30
000073baab9e1f8a  vmovaps xmm0, [rsp]
000073baab9e1f8f  vmovaps xmm2, [rsp+0x10]
000073baab9e1f95  vmovaps xmm3, [rsp+0x20]
000073baab9e1f9b  vmovaps xmm4, [rsp+0x30]
000073baab9e1fa1  vmovaps xmm5, [rsp+0x40]
000073baab9e1fa7  vmovaps xmm6, [rsp+0x50]
000073baab9e1fad  vmovaps xmm7, [rsp+0x60]
000073baab9e1fb3  vmovaps xmm8, [rsp+0x70]
000073baab9e1fb9  vmovaps xmm9, [rsp+0x80]
000073baab9e1fc2  vmovaps xmm10, [rsp+0x90]
000073baab9e1fcb  vmovaps xmm11, [rsp+0xA0]
000073baab9e1fd4  vmovaps xmm12, [rsp+0xB0]
000073baab9e1fdd  vmovaps xmm13, [rsp+0xC0]
000073baab9e1fe6  vmovaps xmm14, [rsp+0xD0]
000073baab9e1fef  vmovaps xmm15, [rsp+0xE0]
000073baab9e1ff8  add rsp, 0xF0
000073baab9e1fff  pop r11
000073baab9e2001  pop r10
000073baab9e2003  pop r9
000073baab9e2005  pop r8
000073baab9e2007  pop rsi
000073baab9e2008  pop rdi
000073baab9e2009  pop rdx
000073baab9e200a  pop rcx
000073baab9e200b  pop rax
000073baab9e200c  add rsp, 0x08
000073baab9e2010  jmp 0x000073BAAB9DF4CE
000073baab9e2015  sub rsp, 0x08
000073baab9e2019  push rax
000073baab9e201a  push rcx
000073baab9e201b  push rdx
000073baab9e201c  push rdi
000073baab9e201d  push rsi
000073baab9e201e  push r8
000073baab9e2020  push r9
000073baab9e2022  push r10
000073baab9e2024  push r11
000073baab9e2026  sub rsp, 0xF0
000073baab9e202d  vmovaps [rsp], xmm0
000073baab9e2032  vmovaps [rsp+0x10], xmm1
000073baab9e2038  vmovaps [rsp+0x20], xmm2
000073baab9e203e  vmovaps [rsp+0x30], xmm3
000073baab9e2044  vmovaps [rsp+0x40], xmm5
000073baab9e204a  vmovaps [rsp+0x50], xmm6
000073baab9e2050  vmovaps [rsp+0x60], xmm7
000073baab9e2056  vmovaps [rsp+0x70], xmm8
000073baab9e205c  vmovaps [rsp+0x80], xmm9
000073baab9e2065  vmovaps [rsp+0x90], xmm10
000073baab9e206e  vmovaps [rsp+0xA0], xmm11
000073baab9e2077  vmovaps [rsp+0xB0], xmm12
000073baab9e2080  vmovaps [rsp+0xC0], xmm13
000073baab9e2089  vmovaps [rsp+0xD0], xmm14
000073baab9e2092  vmovaps [rsp+0xE0], xmm15
000073baab9e209b  sub rsp, 0x30
000073baab9e209f  movaps [rsp], xmm4
000073baab9e20a3  movaps [rsp+0x10], xmm2
000073baab9e20a8  movaps [rsp+0x20], xmm9
000073baab9e20ae  lea rdi, [rsp]
000073baab9e20b2  mov esi, 0x00
000073baab9e20b7  mov rax, 0x5F3F1062D530
000073baab9e20c1  call rax
000073baab9e20c3  movaps xmm4, [rsp]
000073baab9e20c7  add rsp, 0x30
000073baab9e20cb  vmovaps xmm0, [rsp]
000073baab9e20d0  vmovaps xmm1, [rsp+0x10]
000073baab9e20d6  vmovaps xmm2, [rsp+0x20]
000073baab9e20dc  vmovaps xmm3, [rsp+0x30]
000073baab9e20e2  vmovaps xmm5, [rsp+0x40]
000073baab9e20e8  vmovaps xmm6, [rsp+0x50]
000073baab9e20ee  vmovaps xmm7, [rsp+0x60]
000073baab9e20f4  vmovaps xmm8, [rsp+0x70]
000073baab9e20fa  vmovaps xmm9, [rsp+0x80]
000073baab9e2103  vmovaps xmm10, [rsp+0x90]
000073baab9e210c  vmovaps xmm11, [rsp+0xA0]
000073baab9e2115  vmovaps xmm12, [rsp+0xB0]
000073baab9e211e  vmovaps xmm13, [rsp+0xC0]
000073baab9e2127  vmovaps xmm14, [rsp+0xD0]
000073baab9e2130  vmovaps xmm15, [rsp+0xE0]
000073baab9e2139  add rsp, 0xF0
000073baab9e2140  pop r11
000073baab9e2142  pop r10
000073baab9e2144  pop r9
000073baab9e2146  pop r8
000073baab9e2148  pop rsi
000073baab9e2149  pop rdi
000073baab9e214a  pop rdx
000073baab9e214b  pop rcx
000073baab9e214c  pop rax
000073baab9e214d  add rsp, 0x08
000073baab9e2151  jmp 0x000073BAAB9DF4FE
000073baab9e2156  sub rsp, 0x08
000073baab9e215a  push rax
000073baab9e215b  push rcx
000073baab9e215c  push rdx
000073baab9e215d  push rdi
000073baab9e215e  push rsi
000073baab9e215f  push r8
000073baab9e2161  push r9
000073baab9e2163  push r10
000073baab9e2165  push r11
000073baab9e2167  sub rsp, 0xF0
000073baab9e216e  vmovaps [rsp], xmm0
000073baab9e2173  vmovaps [rsp+0x10], xmm1
000073baab9e2179  vmovaps [rsp+0x20], xmm2
000073baab9e217f  vmovaps [rsp+0x30], xmm3
000073baab9e2185  vmovaps [rsp+0x40], xmm4
000073baab9e218b  vmovaps [rsp+0x50], xmm5
000073baab9e2191  vmovaps [rsp+0x60], xmm6
000073baab9e2197  vmovaps [rsp+0x70], xmm7
000073baab9e219d  vmovaps [rsp+0x80], xmm8
000073baab9e21a6  vmovaps [rsp+0x90], xmm10
000073baab9e21af  vmovaps [rsp+0xA0], xmm11
000073baab9e21b8  vmovaps [rsp+0xB0], xmm12
000073baab9e21c1  vmovaps [rsp+0xC0], xmm13
000073baab9e21ca  vmovaps [rsp+0xD0], xmm14
000073baab9e21d3  vmovaps [rsp+0xE0], xmm15
000073baab9e21dc  sub rsp, 0x30
000073baab9e21e0  movaps [rsp], xmm9
000073baab9e21e5  movaps [rsp+0x10], xmm2
000073baab9e21ea  movaps [rsp+0x20], xmm1
000073baab9e21ef  lea rdi, [rsp]
000073baab9e21f3  mov esi, 0x00
000073baab9e21f8  mov rax, 0x5F3F1062D530
000073baab9e2202  call rax
000073baab9e2204  movaps xmm9, [rsp]
000073baab9e2209  add rsp, 0x30
000073baab9e220d  vmovaps xmm0, [rsp]
000073baab9e2212  vmovaps xmm1, [rsp+0x10]
000073baab9e2218  vmovaps xmm2, [rsp+0x20]
000073baab9e221e  vmovaps xmm3, [rsp+0x30]
000073baab9e2224  vmovaps xmm4, [rsp+0x40]
000073baab9e222a  vmovaps xmm5, [rsp+0x50]
000073baab9e2230  vmovaps xmm6, [rsp+0x60]
000073baab9e2236  vmovaps xmm7, [rsp+0x70]
000073baab9e223c  vmovaps xmm8, [rsp+0x80]
000073baab9e2245  vmovaps xmm10, [rsp+0x90]
000073baab9e224e  vmovaps xmm11, [rsp+0xA0]
000073baab9e2257  vmovaps xmm12, [rsp+0xB0]
000073baab9e2260  vmovaps xmm13, [rsp+0xC0]
000073baab9e2269  vmovaps xmm14, [rsp+0xD0]
000073baab9e2272  vmovaps xmm15, [rsp+0xE0]
000073baab9e227b  add rsp, 0xF0
000073baab9e2282  pop r11
000073baab9e2284  pop r10
000073baab9e2286  pop r9
000073baab9e2288  pop r8
000073baab9e228a  pop rsi
000073baab9e228b  pop rdi
000073baab9e228c  pop rdx
000073baab9e228d  pop rcx
000073baab9e228e  pop rax
000073baab9e228f  add rsp, 0x08
000073baab9e2293  jmp 0x000073BAAB9DF534
000073baab9e2298  sub rsp, 0x08
000073baab9e229c  push rax
000073baab9e229d  push rcx
000073baab9e229e  push rdx
000073baab9e229f  push rdi
000073baab9e22a0  push rsi
000073baab9e22a1  push r8
000073baab9e22a3  push r9
000073baab9e22a5  push r10
000073baab9e22a7  push r11
000073baab9e22a9  sub rsp, 0xF0
000073baab9e22b0  vmovaps [rsp], xmm0
000073baab9e22b5  vmovaps [rsp+0x10], xmm2
000073baab9e22bb  vmovaps [rsp+0x20], xmm3
000073baab9e22c1  vmovaps [rsp+0x30], xmm4
000073baab9e22c7  vmovaps [rsp+0x40], xmm5
000073baab9e22cd  vmovaps [rsp+0x50], xmm6
000073baab9e22d3  vmovaps [rsp+0x60], xmm7
000073baab9e22d9  vmovaps [rsp+0x70], xmm8
000073baab9e22df  vmovaps [rsp+0x80], xmm9
000073baab9e22e8  vmovaps [rsp+0x90], xmm10
000073baab9e22f1  vmovaps [rsp+0xA0], xmm11
000073baab9e22fa  vmovaps [rsp+0xB0], xmm12
000073baab9e2303  vmovaps [rsp+0xC0], xmm13
000073baab9e230c  vmovaps [rsp+0xD0], xmm14
000073baab9e2315  vmovaps [rsp+0xE0], xmm15
000073baab9e231e  sub rsp, 0x30
000073baab9e2322  movaps [rsp], xmm1
000073baab9e2326  movaps [rsp+0x10], xmm15
000073baab9e232c  movaps [rsp+0x20], xmm6
000073baab9e2331  lea rdi, [rsp]
000073baab9e2335  mov esi, 0x00
000073baab9e233a  mov rax, 0x5F3F1062D530
000073baab9e2344  call rax
000073baab9e2346  movaps xmm1, [rsp]
000073baab9e234a  add rsp, 0x30
000073baab9e234e  vmovaps xmm0, [rsp]
000073baab9e2353  vmovaps xmm2, [rsp+0x10]
000073baab9e2359  vmovaps xmm3, [rsp+0x20]
000073baab9e235f  vmovaps xmm4, [rsp+0x30]
000073baab9e2365  vmovaps xmm5, [rsp+0x40]
000073baab9e236b  vmovaps xmm6, [rsp+0x50]
000073baab9e2371  vmovaps xmm7, [rsp+0x60]
000073baab9e2377  vmovaps xmm8, [rsp+0x70]
000073baab9e237d  vmovaps xmm9, [rsp+0x80]
000073baab9e2386  vmovaps xmm10, [rsp+0x90]
000073baab9e238f  vmovaps xmm11, [rsp+0xA0]
000073baab9e2398  vmovaps xmm12, [rsp+0xB0]
000073baab9e23a1  vmovaps xmm13, [rsp+0xC0]
000073baab9e23aa  vmovaps xmm14, [rsp+0xD0]
000073baab9e23b3  vmovaps xmm15, [rsp+0xE0]
000073baab9e23bc  add rsp, 0xF0
000073baab9e23c3  pop r11
000073baab9e23c5  pop r10
000073baab9e23c7  pop r9
000073baab9e23c9  pop r8
000073baab9e23cb  pop rsi
000073baab9e23cc  pop rdi
000073baab9e23cd  pop rdx
000073baab9e23ce  pop rcx
000073baab9e23cf  pop rax
000073baab9e23d0  add rsp, 0x08
000073baab9e23d4  jmp 0x000073BAAB9DF555
000073baab9e23d9  sub rsp, 0x08
000073baab9e23dd  push rax
000073baab9e23de  push rcx
000073baab9e23df  push rdx
000073baab9e23e0  push rdi
000073baab9e23e1  push rsi
000073baab9e23e2  push r8
000073baab9e23e4  push r9
000073baab9e23e6  push r10
000073baab9e23e8  push r11
000073baab9e23ea  sub rsp, 0xF0
000073baab9e23f1  vmovaps [rsp], xmm0
000073baab9e23f6  vmovaps [rsp+0x10], xmm1
000073baab9e23fc  vmovaps [rsp+0x20], xmm2
000073baab9e2402  vmovaps [rsp+0x30], xmm3
000073baab9e2408  vmovaps [rsp+0x40], xmm4
000073baab9e240e  vmovaps [rsp+0x50], xmm5
000073baab9e2414  vmovaps [rsp+0x60], xmm6
000073baab9e241a  vmovaps [rsp+0x70], xmm7
000073baab9e2420  vmovaps [rsp+0x80], xmm8
000073baab9e2429  vmovaps [rsp+0x90], xmm9
000073baab9e2432  vmovaps [rsp+0xA0], xmm10
000073baab9e243b  vmovaps [rsp+0xB0], xmm11
000073baab9e2444  vmovaps [rsp+0xC0], xmm12
000073baab9e244d  vmovaps [rsp+0xD0], xmm13
000073baab9e2456  vmovaps [rsp+0xE0], xmm14
000073baab9e245f  sub rsp, 0x30
000073baab9e2463  movaps [rsp], xmm15
000073baab9e2468  movaps [rsp+0x10], xmm5
000073baab9e246d  movaps [rsp+0x20], xmm3
000073baab9e2472  lea rdi, [rsp]
000073baab9e2476  mov esi, 0x00
000073baab9e247b  mov rax, 0x5F3F1062D530
000073baab9e2485  call rax
000073baab9e2487  movaps xmm15, [rsp]
000073baab9e248c  add rsp, 0x30
000073baab9e2490  vmovaps xmm0, [rsp]
000073baab9e2495  vmovaps xmm1, [rsp+0x10]
000073baab9e249b  vmovaps xmm2, [rsp+0x20]
000073baab9e24a1  vmovaps xmm3, [rsp+0x30]
000073baab9e24a7  vmovaps xmm4, [rsp+0x40]
000073baab9e24ad  vmovaps xmm5, [rsp+0x50]
000073baab9e24b3  vmovaps xmm6, [rsp+0x60]
000073baab9e24b9  vmovaps xmm7, [rsp+0x70]
000073baab9e24bf  vmovaps xmm8, [rsp+0x80]
000073baab9e24c8  vmovaps xmm9, [rsp+0x90]
000073baab9e24d1  vmovaps xmm10, [rsp+0xA0]
000073baab9e24da  vmovaps xmm11, [rsp+0xB0]
000073baab9e24e3  vmovaps xmm12, [rsp+0xC0]
000073baab9e24ec  vmovaps xmm13, [rsp+0xD0]
000073baab9e24f5  vmovaps xmm14, [rsp+0xE0]
000073baab9e24fe  add rsp, 0xF0
000073baab9e2505  pop r11
000073baab9e2507  pop r10
000073baab9e2509  pop r9
000073baab9e250b  pop r8
000073baab9e250d  pop rsi
000073baab9e250e  pop rdi
000073baab9e250f  pop rdx
000073baab9e2510  pop rcx
000073baab9e2511  pop rax
000073baab9e2512  add rsp, 0x08
000073baab9e2516  jmp 0x000073BAAB9DF56F
000073baab9e251b  sub rsp, 0x08
000073baab9e251f  push rax
000073baab9e2520  push rcx
000073baab9e2521  push rdx
000073baab9e2522  push rdi
000073baab9e2523  push rsi
000073baab9e2524  push r8
000073baab9e2526  push r9
000073baab9e2528  push r10
000073baab9e252a  push r11
000073baab9e252c  sub rsp, 0xF0
000073baab9e2533  vmovaps [rsp], xmm0
000073baab9e2538  vmovaps [rsp+0x10], xmm1
000073baab9e253e  vmovaps [rsp+0x20], xmm2
000073baab9e2544  vmovaps [rsp+0x30], xmm3
000073baab9e254a  vmovaps [rsp+0x40], xmm4
000073baab9e2550  vmovaps [rsp+0x50], xmm6
000073baab9e2556  vmovaps [rsp+0x60], xmm7
000073baab9e255c  vmovaps [rsp+0x70], xmm8
000073baab9e2562  vmovaps [rsp+0x80], xmm9
000073baab9e256b  vmovaps [rsp+0x90], xmm10
000073baab9e2574  vmovaps [rsp+0xA0], xmm11
000073baab9e257d  vmovaps [rsp+0xB0], xmm12
000073baab9e2586  vmovaps [rsp+0xC0], xmm13
000073baab9e258f  vmovaps [rsp+0xD0], xmm14
000073baab9e2598  vmovaps [rsp+0xE0], xmm15
000073baab9e25a1  sub rsp, 0x30
000073baab9e25a5  movaps [rsp], xmm5
000073baab9e25a9  movaps [rsp+0x10], xmm8
000073baab9e25af  movaps [rsp+0x20], xmm6
000073baab9e25b4  lea rdi, [rsp]
000073baab9e25b8  mov esi, 0x00
000073baab9e25bd  mov rax, 0x5F3F1062D530
000073baab9e25c7  call rax
000073baab9e25c9  movaps xmm5, [rsp]
000073baab9e25cd  add rsp, 0x30
000073baab9e25d1  vmovaps xmm0, [rsp]
000073baab9e25d6  vmovaps xmm1, [rsp+0x10]
000073baab9e25dc  vmovaps xmm2, [rsp+0x20]
000073baab9e25e2  vmovaps xmm3, [rsp+0x30]
000073baab9e25e8  vmovaps xmm4, [rsp+0x40]
000073baab9e25ee  vmovaps xmm6, [rsp+0x50]
000073baab9e25f4  vmovaps xmm7, [rsp+0x60]
000073baab9e25fa  vmovaps xmm8, [rsp+0x70]
000073baab9e2600  vmovaps xmm9, [rsp+0x80]
000073baab9e2609  vmovaps xmm10, [rsp+0x90]
000073baab9e2612  vmovaps xmm11, [rsp+0xA0]
000073baab9e261b  vmovaps xmm12, [rsp+0xB0]
000073baab9e2624  vmovaps xmm13, [rsp+0xC0]
000073baab9e262d  vmovaps xmm14, [rsp+0xD0]
000073baab9e2636  vmovaps xmm15, [rsp+0xE0]
000073baab9e263f  add rsp, 0xF0
000073baab9e2646  pop r11
000073baab9e2648  pop r10
000073baab9e264a  pop r9
000073baab9e264c  pop r8
000073baab9e264e  pop rsi
000073baab9e264f  pop rdi
000073baab9e2650  pop rdx
000073baab9e2651  pop rcx
000073baab9e2652  pop rax
000073baab9e2653  add rsp, 0x08
000073baab9e2657  jmp 0x000073BAAB9DF593
000073baab9e265c  sub rsp, 0x08
000073baab9e2660  push rax
000073baab9e2661  push rcx
000073baab9e2662  push rdx
000073baab9e2663  push rdi
000073baab9e2664  push rsi
000073baab9e2665  push r8
000073baab9e2667  push r9
000073baab9e2669  push r10
000073baab9e266b  push r11
000073baab9e266d  sub rsp, 0xF0
000073baab9e2674  vmovaps [rsp], xmm0
000073baab9e2679  vmovaps [rsp+0x10], xmm1
000073baab9e267f  vmovaps [rsp+0x20], xmm2
000073baab9e2685  vmovaps [rsp+0x30], xmm3
000073baab9e268b  vmovaps [rsp+0x40], xmm4
000073baab9e2691  vmovaps [rsp+0x50], xmm5
000073baab9e2697  vmovaps [rsp+0x60], xmm7
000073baab9e269d  vmovaps [rsp+0x70], xmm8
000073baab9e26a3  vmovaps [rsp+0x80], xmm9
000073baab9e26ac  vmovaps [rsp+0x90], xmm10
000073baab9e26b5  vmovaps [rsp+0xA0], xmm11
000073baab9e26be  vmovaps [rsp+0xB0], xmm12
000073baab9e26c7  vmovaps [rsp+0xC0], xmm13
000073baab9e26d0  vmovaps [rsp+0xD0], xmm14
000073baab9e26d9  vmovaps [rsp+0xE0], xmm15
000073baab9e26e2  sub rsp, 0x30
000073baab9e26e6  movaps [rsp], xmm6
000073baab9e26ea  movaps [rsp+0x10], xmm10
000073baab9e26f0  movaps [rsp+0x20], xmm8
000073baab9e26f6  lea rdi, [rsp]
000073baab9e26fa  mov esi, 0x00
000073baab9e26ff  mov rax, 0x5F3F1062D530
000073baab9e2709  call rax
000073baab9e270b  movaps xmm6, [rsp]
000073baab9e270f  add rsp, 0x30
000073baab9e2713  vmovaps xmm0, [rsp]
000073baab9e2718  vmovaps xmm1, [rsp+0x10]
000073baab9e271e  vmovaps xmm2, [rsp+0x20]
000073baab9e2724  vmovaps xmm3, [rsp+0x30]
000073baab9e272a  vmovaps xmm4, [rsp+0x40]
000073baab9e2730  vmovaps xmm5, [rsp+0x50]
000073baab9e2736  vmovaps xmm7, [rsp+0x60]
000073baab9e273c  vmovaps xmm8, [rsp+0x70]
000073baab9e2742  vmovaps xmm9, [rsp+0x80]
000073baab9e274b  vmovaps xmm10, [rsp+0x90]
000073baab9e2754  vmovaps xmm11, [rsp+0xA0]
000073baab9e275d  vmovaps xmm12, [rsp+0xB0]
000073baab9e2766  vmovaps xmm13, [rsp+0xC0]
000073baab9e276f  vmovaps xmm14, [rsp+0xD0]
000073baab9e2778  vmovaps xmm15, [rsp+0xE0]
000073baab9e2781  add rsp, 0xF0
000073baab9e2788  pop r11
000073baab9e278a  pop r10
000073baab9e278c  pop r9
000073baab9e278e  pop r8
000073baab9e2790  pop rsi
000073baab9e2791  pop rdi
000073baab9e2792  pop rdx
000073baab9e2793  pop rcx
000073baab9e2794  pop rax
000073baab9e2795  add rsp, 0x08
000073baab9e2799  jmp 0x000073BAAB9DF5B8
000073baab9e279e  sub rsp, 0x08
000073baab9e27a2  push rax
000073baab9e27a3  push rcx
000073baab9e27a4  push rdx
000073baab9e27a5  push rdi
000073baab9e27a6  push rsi
000073baab9e27a7  push r8
000073baab9e27a9  push r9
000073baab9e27ab  push r10
000073baab9e27ad  push r11
000073baab9e27af  sub rsp, 0xF0
000073baab9e27b6  vmovaps [rsp], xmm0
000073baab9e27bb  vmovaps [rsp+0x10], xmm1
000073baab9e27c1  vmovaps [rsp+0x20], xmm2
000073baab9e27c7  vmovaps [rsp+0x30], xmm3
000073baab9e27cd  vmovaps [rsp+0x40], xmm4
000073baab9e27d3  vmovaps [rsp+0x50], xmm5
000073baab9e27d9  vmovaps [rsp+0x60], xmm6
000073baab9e27df  vmovaps [rsp+0x70], xmm7
000073baab9e27e5  vmovaps [rsp+0x80], xmm8
000073baab9e27ee  vmovaps [rsp+0x90], xmm9
000073baab9e27f7  vmovaps [rsp+0xA0], xmm11
000073baab9e2800  vmovaps [rsp+0xB0], xmm12
000073baab9e2809  vmovaps [rsp+0xC0], xmm13
000073baab9e2812  vmovaps [rsp+0xD0], xmm14
000073baab9e281b  vmovaps [rsp+0xE0], xmm15
000073baab9e2824  sub rsp, 0x30
000073baab9e2828  movaps [rsp], xmm10
000073baab9e282d  movaps [rsp+0x10], xmm8
000073baab9e2833  movaps [rsp+0x20], xmm14
000073baab9e2839  lea rdi, [rsp]
000073baab9e283d  mov esi, 0x00
000073baab9e2842  mov rax, 0x5F3F1062D530
000073baab9e284c  call rax
000073baab9e284e  movaps xmm10, [rsp]
000073baab9e2853  add rsp, 0x30
000073baab9e2857  vmovaps xmm0, [rsp]
000073baab9e285c  vmovaps xmm1, [rsp+0x10]
000073baab9e2862  vmovaps xmm2, [rsp+0x20]
000073baab9e2868  vmovaps xmm3, [rsp+0x30]
000073baab9e286e  vmovaps xmm4, [rsp+0x40]
000073baab9e2874  vmovaps xmm5, [rsp+0x50]
000073baab9e287a  vmovaps xmm6, [rsp+0x60]
000073baab9e2880  vmovaps xmm7, [rsp+0x70]
000073baab9e2886  vmovaps xmm8, [rsp+0x80]
000073baab9e288f  vmovaps xmm9, [rsp+0x90]
000073baab9e2898  vmovaps xmm11, [rsp+0xA0]
000073baab9e28a1  vmovaps xmm12, [rsp+0xB0]
000073baab9e28aa  vmovaps xmm13, [rsp+0xC0]
000073baab9e28b3  vmovaps xmm14, [rsp+0xD0]
000073baab9e28bc  vmovaps xmm15, [rsp+0xE0]
000073baab9e28c5  add rsp, 0xF0
000073baab9e28cc  pop r11
000073baab9e28ce  pop r10
000073baab9e28d0  pop r9
000073baab9e28d2  pop r8
000073baab9e28d4  pop rsi
000073baab9e28d5  pop rdi
000073baab9e28d6  pop rdx
000073baab9e28d7  pop rcx
000073baab9e28d8  pop rax
000073baab9e28d9  add rsp, 0x08
000073baab9e28dd  jmp 0x000073BAAB9DF5D8
000073baab9e28e2  sub rsp, 0x08
000073baab9e28e6  push rax
000073baab9e28e7  push rcx
000073baab9e28e8  push rdx
000073baab9e28e9  push rdi
000073baab9e28ea  push rsi
000073baab9e28eb  push r8
000073baab9e28ed  push r9
000073baab9e28ef  push r10
000073baab9e28f1  push r11
000073baab9e28f3  sub rsp, 0xF0
000073baab9e28fa  vmovaps [rsp], xmm0
000073baab9e28ff  vmovaps [rsp+0x10], xmm1
000073baab9e2905  vmovaps [rsp+0x20], xmm2
000073baab9e290b  vmovaps [rsp+0x30], xmm3
000073baab9e2911  vmovaps [rsp+0x40], xmm4
000073baab9e2917  vmovaps [rsp+0x50], xmm5
000073baab9e291d  vmovaps [rsp+0x60], xmm6
000073baab9e2923  vmovaps [rsp+0x70], xmm7
000073baab9e2929  vmovaps [rsp+0x80], xmm8
000073baab9e2932  vmovaps [rsp+0x90], xmm9
000073baab9e293b  vmovaps [rsp+0xA0], xmm10
000073baab9e2944  vmovaps [rsp+0xB0], xmm11
000073baab9e294d  vmovaps [rsp+0xC0], xmm12
000073baab9e2956  vmovaps [rsp+0xD0], xmm13
000073baab9e295f  vmovaps [rsp+0xE0], xmm15
000073baab9e2968  sub rsp, 0x30
000073baab9e296c  movaps [rsp], xmm14
000073baab9e2971  movaps [rsp+0x10], xmm8
000073baab9e2977  movaps [rsp+0x20], xmm4
000073baab9e297c  lea rdi, [rsp]
000073baab9e2980  mov esi, 0x00
000073baab9e2985  mov rax, 0x5F3F1062D530
000073baab9e298f  call rax
000073baab9e2991  movaps xmm14, [rsp]
000073baab9e2996  add rsp, 0x30
000073baab9e299a  vmovaps xmm0, [rsp]
000073baab9e299f  vmovaps xmm1, [rsp+0x10]
000073baab9e29a5  vmovaps xmm2, [rsp+0x20]
000073baab9e29ab  vmovaps xmm3, [rsp+0x30]
000073baab9e29b1  vmovaps xmm4, [rsp+0x40]
000073baab9e29b7  vmovaps xmm5, [rsp+0x50]
000073baab9e29bd  vmovaps xmm6, [rsp+0x60]
000073baab9e29c3  vmovaps xmm7, [rsp+0x70]
000073baab9e29c9  vmovaps xmm8, [rsp+0x80]
000073baab9e29d2  vmovaps xmm9, [rsp+0x90]
000073baab9e29db  vmovaps xmm10, [rsp+0xA0]
000073baab9e29e4  vmovaps xmm11, [rsp+0xB0]
000073baab9e29ed  vmovaps xmm12, [rsp+0xC0]
000073baab9e29f6  vmovaps xmm13, [rsp+0xD0]
000073baab9e29ff  vmovaps xmm15, [rsp+0xE0]
000073baab9e2a08  add rsp, 0xF0
000073baab9e2a0f  pop r11
000073baab9e2a11  pop r10
000073baab9e2a13  pop r9
000073baab9e2a15  pop r8
000073baab9e2a17  pop rsi
000073baab9e2a18  pop rdi
000073baab9e2a19  pop rdx
000073baab9e2a1a  pop rcx
000073baab9e2a1b  pop rax
000073baab9e2a1c  add rsp, 0x08
000073baab9e2a20  jmp 0x000073BAAB9DF5F8
000073baab9e2a25  sub rsp, 0x08
000073baab9e2a29  push rax
000073baab9e2a2a  push rcx
000073baab9e2a2b  push rdx
000073baab9e2a2c  push rdi
000073baab9e2a2d  push rsi
000073baab9e2a2e  push r8
000073baab9e2a30  push r9
000073baab9e2a32  push r10
000073baab9e2a34  push r11
000073baab9e2a36  sub rsp, 0xF0
000073baab9e2a3d  vmovaps [rsp], xmm0
000073baab9e2a42  vmovaps [rsp+0x10], xmm1
000073baab9e2a48  vmovaps [rsp+0x20], xmm2
000073baab9e2a4e  vmovaps [rsp+0x30], xmm3
000073baab9e2a54  vmovaps [rsp+0x40], xmm5
000073baab9e2a5a  vmovaps [rsp+0x50], xmm6
000073baab9e2a60  vmovaps [rsp+0x60], xmm7
000073baab9e2a66  vmovaps [rsp+0x70], xmm8
000073baab9e2a6c  vmovaps [rsp+0x80], xmm9
000073baab9e2a75  vmovaps [rsp+0x90], xmm10
000073baab9e2a7e  vmovaps [rsp+0xA0], xmm11
000073baab9e2a87  vmovaps [rsp+0xB0], xmm12
000073baab9e2a90  vmovaps [rsp+0xC0], xmm13
000073baab9e2a99  vmovaps [rsp+0xD0], xmm14
000073baab9e2aa2  vmovaps [rsp+0xE0], xmm15
000073baab9e2aab  sub rsp, 0x30
000073baab9e2aaf  movaps [rsp], xmm4
000073baab9e2ab3  movaps [rsp+0x10], xmm13
000073baab9e2ab9  movaps [rsp+0x20], xmm8
000073baab9e2abf  lea rdi, [rsp]
000073baab9e2ac3  mov esi, 0x00
000073baab9e2ac8  mov rax, 0x5F3F1062D530
000073baab9e2ad2  call rax
000073baab9e2ad4  movaps xmm4, [rsp]
000073baab9e2ad8  add rsp, 0x30
000073baab9e2adc  vmovaps xmm0, [rsp]
000073baab9e2ae1  vmovaps xmm1, [rsp+0x10]
000073baab9e2ae7  vmovaps xmm2, [rsp+0x20]
000073baab9e2aed  vmovaps xmm3, [rsp+0x30]
000073baab9e2af3  vmovaps xmm5, [rsp+0x40]
000073baab9e2af9  vmovaps xmm6, [rsp+0x50]
000073baab9e2aff  vmovaps xmm7, [rsp+0x60]
000073baab9e2b05  vmovaps xmm8, [rsp+0x70]
000073baab9e2b0b  vmovaps xmm9, [rsp+0x80]
000073baab9e2b14  vmovaps xmm10, [rsp+0x90]
000073baab9e2b1d  vmovaps xmm11, [rsp+0xA0]
000073baab9e2b26  vmovaps xmm12, [rsp+0xB0]
000073baab9e2b2f  vmovaps xmm13, [rsp+0xC0]
000073baab9e2b38  vmovaps xmm14, [rsp+0xD0]
000073baab9e2b41  vmovaps xmm15, [rsp+0xE0]
000073baab9e2b4a  add rsp, 0xF0
000073baab9e2b51  pop r11
000073baab9e2b53  pop r10
000073baab9e2b55  pop r9
000073baab9e2b57  pop r8
000073baab9e2b59  pop rsi
000073baab9e2b5a  pop rdi
000073baab9e2b5b  pop rdx
000073baab9e2b5c  pop rcx
000073baab9e2b5d  pop rax
000073baab9e2b5e  add rsp, 0x08
000073baab9e2b62  jmp 0x000073BAAB9DF61D
000073baab9e2b67  sub rsp, 0x08
000073baab9e2b6b  push rax
000073baab9e2b6c  push rcx
000073baab9e2b6d  push rdx
000073baab9e2b6e  push rdi
000073baab9e2b6f  push rsi
000073baab9e2b70  push r8
000073baab9e2b72  push r9
000073baab9e2b74  push r10
000073baab9e2b76  push r11
000073baab9e2b78  sub rsp, 0xF0
000073baab9e2b7f  vmovaps [rsp], xmm0
000073baab9e2b84  vmovaps [rsp+0x10], xmm1
000073baab9e2b8a  vmovaps [rsp+0x20], xmm2
000073baab9e2b90  vmovaps [rsp+0x30], xmm3
000073baab9e2b96  vmovaps [rsp+0x40], xmm4
000073baab9e2b9c  vmovaps [rsp+0x50], xmm5
000073baab9e2ba2  vmovaps [rsp+0x60], xmm6
000073baab9e2ba8  vmovaps [rsp+0x70], xmm7
000073baab9e2bae  vmovaps [rsp+0x80], xmm8
000073baab9e2bb7  vmovaps [rsp+0x90], xmm9
000073baab9e2bc0  vmovaps [rsp+0xA0], xmm10
000073baab9e2bc9  vmovaps [rsp+0xB0], xmm11
000073baab9e2bd2  vmovaps [rsp+0xC0], xmm12
000073baab9e2bdb  vmovaps [rsp+0xD0], xmm14
000073baab9e2be4  vmovaps [rsp+0xE0], xmm15
000073baab9e2bed  sub rsp, 0x30
000073baab9e2bf1  movaps [rsp], xmm13
000073baab9e2bf6  movaps [rsp+0x10], xmm15
000073baab9e2bfc  movaps [rsp+0x20], xmm9
000073baab9e2c02  lea rdi, [rsp]
000073baab9e2c06  mov esi, 0x00
000073baab9e2c0b  mov rax, 0x5F3F1062D530
000073baab9e2c15  call rax
000073baab9e2c17  movaps xmm13, [rsp]
000073baab9e2c1c  add rsp, 0x30
000073baab9e2c20  vmovaps xmm0, [rsp]
000073baab9e2c25  vmovaps xmm1, [rsp+0x10]
000073baab9e2c2b  vmovaps xmm2, [rsp+0x20]
000073baab9e2c31  vmovaps xmm3, [rsp+0x30]
000073baab9e2c37  vmovaps xmm4, [rsp+0x40]
000073baab9e2c3d  vmovaps xmm5, [rsp+0x50]
000073baab9e2c43  vmovaps xmm6, [rsp+0x60]
000073baab9e2c49  vmovaps xmm7, [rsp+0x70]
000073baab9e2c4f  vmovaps xmm8, [rsp+0x80]
000073baab9e2c58  vmovaps xmm9, [rsp+0x90]
000073baab9e2c61  vmovaps xmm10, [rsp+0xA0]
000073baab9e2c6a  vmovaps xmm11, [rsp+0xB0]
000073baab9e2c73  vmovaps xmm12, [rsp+0xC0]
000073baab9e2c7c  vmovaps xmm14, [rsp+0xD0]
000073baab9e2c85  vmovaps xmm15, [rsp+0xE0]
000073baab9e2c8e  add rsp, 0xF0
000073baab9e2c95  pop r11
000073baab9e2c97  pop r10
000073baab9e2c99  pop r9
000073baab9e2c9b  pop r8
000073baab9e2c9d  pop rsi
000073baab9e2c9e  pop rdi
000073baab9e2c9f  pop rdx
000073baab9e2ca0  pop rcx
000073baab9e2ca1  pop rax
000073baab9e2ca2  add rsp, 0x08
000073baab9e2ca6  jmp 0x000073BAAB9DF638
000073baab9e2cab  sub rsp, 0x08
000073baab9e2caf  push rax
000073baab9e2cb0  push rcx
000073baab9e2cb1  push rdx
000073baab9e2cb2  push rdi
000073baab9e2cb3  push rsi
000073baab9e2cb4  push r8
000073baab9e2cb6  push r9
000073baab9e2cb8  push r10
000073baab9e2cba  push r11
000073baab9e2cbc  sub rsp, 0xF0
000073baab9e2cc3  vmovaps [rsp], xmm0
000073baab9e2cc8  vmovaps [rsp+0x10], xmm1
000073baab9e2cce  vmovaps [rsp+0x20], xmm2
000073baab9e2cd4  vmovaps [rsp+0x30], xmm3
000073baab9e2cda  vmovaps [rsp+0x40], xmm4
000073baab9e2ce0  vmovaps [rsp+0x50], xmm5
000073baab9e2ce6  vmovaps [rsp+0x60], xmm6
000073baab9e2cec  vmovaps [rsp+0x70], xmm7
000073baab9e2cf2  vmovaps [rsp+0x80], xmm8
000073baab9e2cfb  vmovaps [rsp+0x90], xmm9
000073baab9e2d04  vmovaps [rsp+0xA0], xmm10
000073baab9e2d0d  vmovaps [rsp+0xB0], xmm11
000073baab9e2d16  vmovaps [rsp+0xC0], xmm12
000073baab9e2d1f  vmovaps [rsp+0xD0], xmm13
000073baab9e2d28  vmovaps [rsp+0xE0], xmm14
000073baab9e2d31  sub rsp, 0x30
000073baab9e2d35  movaps [rsp], xmm15
000073baab9e2d3a  movaps [rsp+0x10], xmm1
000073baab9e2d3f  movaps [rsp+0x20], xmm5
000073baab9e2d44  lea rdi, [rsp]
000073baab9e2d48  mov esi, 0x00
000073baab9e2d4d  mov rax, 0x5F3F1062D530
000073baab9e2d57  call rax
000073baab9e2d59  movaps xmm15, [rsp]
000073baab9e2d5e  add rsp, 0x30
000073baab9e2d62  vmovaps xmm0, [rsp]
000073baab9e2d67  vmovaps xmm1, [rsp+0x10]
000073baab9e2d6d  vmovaps xmm2, [rsp+0x20]
000073baab9e2d73  vmovaps xmm3, [rsp+0x30]
000073baab9e2d79  vmovaps xmm4, [rsp+0x40]
000073baab9e2d7f  vmovaps xmm5, [rsp+0x50]
000073baab9e2d85  vmovaps xmm6, [rsp+0x60]
000073baab9e2d8b  vmovaps xmm7, [rsp+0x70]
000073baab9e2d91  vmovaps xmm8, [rsp+0x80]
000073baab9e2d9a  vmovaps xmm9, [rsp+0x90]
000073baab9e2da3  vmovaps xmm10, [rsp+0xA0]
000073baab9e2dac  vmovaps xmm11, [rsp+0xB0]
000073baab9e2db5  vmovaps xmm12, [rsp+0xC0]
000073baab9e2dbe  vmovaps xmm13, [rsp+0xD0]
000073baab9e2dc7  vmovaps xmm14, [rsp+0xE0]
000073baab9e2dd0  add rsp, 0xF0
000073baab9e2dd7  pop r11
000073baab9e2dd9  pop r10
000073baab9e2ddb  pop r9
000073baab9e2ddd  pop r8
000073baab9e2ddf  pop rsi
000073baab9e2de0  pop rdi
000073baab9e2de1  pop rdx
000073baab9e2de2  pop rcx
000073baab9e2de3  pop rax
000073baab9e2de4  add rsp, 0x08
000073baab9e2de8  jmp 0x000073BAAB9DF653
000073baab9e2ded  call 0x000073BAAB8B52F0
000073baab9e2df2  jmp 0x000073BAAB9DF6AE
000073baab9e2df7  sub rsp, 0x08
000073baab9e2dfb  push rax
000073baab9e2dfc  push rcx
000073baab9e2dfd  push rdx
000073baab9e2dfe  push rdi
000073baab9e2dff  push rsi
000073baab9e2e00  push r8
000073baab9e2e02  push r9
000073baab9e2e04  push r10
000073baab9e2e06  push r11
000073baab9e2e08  sub rsp, 0xF0
000073baab9e2e0f  vmovaps [rsp], xmm0
000073baab9e2e14  vmovaps [rsp+0x10], xmm1
000073baab9e2e1a  vmovaps [rsp+0x20], xmm2
000073baab9e2e20  vmovaps [rsp+0x30], xmm3
000073baab9e2e26  vmovaps [rsp+0x40], xmm4
000073baab9e2e2c  vmovaps [rsp+0x50], xmm5
000073baab9e2e32  vmovaps [rsp+0x60], xmm6
000073baab9e2e38  vmovaps [rsp+0x70], xmm7
000073baab9e2e3e  vmovaps [rsp+0x80], xmm8
000073baab9e2e47  vmovaps [rsp+0x90], xmm10
000073baab9e2e50  vmovaps [rsp+0xA0], xmm11
000073baab9e2e59  vmovaps [rsp+0xB0], xmm12
000073baab9e2e62  vmovaps [rsp+0xC0], xmm13
000073baab9e2e6b  vmovaps [rsp+0xD0], xmm14
000073baab9e2e74  vmovaps [rsp+0xE0], xmm15
000073baab9e2e7d  sub rsp, 0x30
000073baab9e2e81  movaps [rsp], xmm9
000073baab9e2e86  movaps [rsp+0x10], xmm8
000073baab9e2e8c  movaps [rsp+0x20], xmm11
000073baab9e2e92  lea rdi, [rsp]
000073baab9e2e96  mov esi, 0x00
000073baab9e2e9b  mov rax, 0x5F3F1062D530
000073baab9e2ea5  call rax
000073baab9e2ea7  movaps xmm9, [rsp]
000073baab9e2eac  add rsp, 0x30
000073baab9e2eb0  vmovaps xmm0, [rsp]
000073baab9e2eb5  vmovaps xmm1, [rsp+0x10]
000073baab9e2ebb  vmovaps xmm2, [rsp+0x20]
000073baab9e2ec1  vmovaps xmm3, [rsp+0x30]
000073baab9e2ec7  vmovaps xmm4, [rsp+0x40]
000073baab9e2ecd  vmovaps xmm5, [rsp+0x50]
000073baab9e2ed3  vmovaps xmm6, [rsp+0x60]
000073baab9e2ed9  vmovaps xmm7, [rsp+0x70]
000073baab9e2edf  vmovaps xmm8, [rsp+0x80]
000073baab9e2ee8  vmovaps xmm10, [rsp+0x90]
000073baab9e2ef1  vmovaps xmm11, [rsp+0xA0]
000073baab9e2efa  vmovaps xmm12, [rsp+0xB0]
000073baab9e2f03  vmovaps xmm13, [rsp+0xC0]
000073baab9e2f0c  vmovaps xmm14, [rsp+0xD0]
000073baab9e2f15  vmovaps xmm15, [rsp+0xE0]
000073baab9e2f1e  add rsp, 0xF0
000073baab9e2f25  pop r11
000073baab9e2f27  pop r10
000073baab9e2f29  pop r9
000073baab9e2f2b  pop r8
000073baab9e2f2d  pop rsi
000073baab9e2f2e  pop rdi
000073baab9e2f2f  pop rdx
000073baab9e2f30  pop rcx
000073baab9e2f31  pop rax
000073baab9e2f32  add rsp, 0x08
000073baab9e2f36  jmp 0x000073BAAB9DF6E5
000073baab9e2f3b  sub rsp, 0x08
000073baab9e2f3f  push rax
000073baab9e2f40  push rcx
000073baab9e2f41  push rdx
000073baab9e2f42  push rdi
000073baab9e2f43  push rsi
000073baab9e2f44  push r8
000073baab9e2f46  push r9
000073baab9e2f48  push r10
000073baab9e2f4a  push r11
000073baab9e2f4c  sub rsp, 0xF0
000073baab9e2f53  vmovaps [rsp], xmm0
000073baab9e2f58  vmovaps [rsp+0x10], xmm1
000073baab9e2f5e  vmovaps [rsp+0x20], xmm2
000073baab9e2f64  vmovaps [rsp+0x30], xmm3
000073baab9e2f6a  vmovaps [rsp+0x40], xmm4
000073baab9e2f70  vmovaps [rsp+0x50], xmm5
000073baab9e2f76  vmovaps [rsp+0x60], xmm6
000073baab9e2f7c  vmovaps [rsp+0x70], xmm7
000073baab9e2f82  vmovaps [rsp+0x80], xmm8
000073baab9e2f8b  vmovaps [rsp+0x90], xmm9
000073baab9e2f94  vmovaps [rsp+0xA0], xmm10
000073baab9e2f9d  vmovaps [rsp+0xB0], xmm12
000073baab9e2fa6  vmovaps [rsp+0xC0], xmm13
000073baab9e2faf  vmovaps [rsp+0xD0], xmm14
000073baab9e2fb8  vmovaps [rsp+0xE0], xmm15
000073baab9e2fc1  sub rsp, 0x30
000073baab9e2fc5  movaps [rsp], xmm11
000073baab9e2fca  movaps [rsp+0x10], xmm10
000073baab9e2fd0  movaps [rsp+0x20], xmm6
000073baab9e2fd5  lea rdi, [rsp]
000073baab9e2fd9  mov esi, 0x00
000073baab9e2fde  mov rax, 0x5F3F1062D530
000073baab9e2fe8  call rax
000073baab9e2fea  movaps xmm11, [rsp]
000073baab9e2fef  add rsp, 0x30
000073baab9e2ff3  vmovaps xmm0, [rsp]
000073baab9e2ff8  vmovaps xmm1, [rsp+0x10]
000073baab9e2ffe  vmovaps xmm2, [rsp+0x20]
000073baab9e3004  vmovaps xmm3, [rsp+0x30]
000073baab9e300a  vmovaps xmm4, [rsp+0x40]
000073baab9e3010  vmovaps xmm5, [rsp+0x50]
000073baab9e3016  vmovaps xmm6, [rsp+0x60]
000073baab9e301c  vmovaps xmm7, [rsp+0x70]
000073baab9e3022  vmovaps xmm8, [rsp+0x80]
000073baab9e302b  vmovaps xmm9, [rsp+0x90]
000073baab9e3034  vmovaps xmm10, [rsp+0xA0]
000073baab9e303d  vmovaps xmm12, [rsp+0xB0]
000073baab9e3046  vmovaps xmm13, [rsp+0xC0]
000073baab9e304f  vmovaps xmm14, [rsp+0xD0]
000073baab9e3058  vmovaps xmm15, [rsp+0xE0]
000073baab9e3061  add rsp, 0xF0
000073baab9e3068  pop r11
000073baab9e306a  pop r10
000073baab9e306c  pop r9
000073baab9e306e  pop r8
000073baab9e3070  pop rsi
000073baab9e3071  pop rdi
000073baab9e3072  pop rdx
000073baab9e3073  pop rcx
000073baab9e3074  pop rax
000073baab9e3075  add rsp, 0x08
000073baab9e3079  jmp 0x000073BAAB9DF700
000073baab9e307e  sub rsp, 0x08
000073baab9e3082  push rax
000073baab9e3083  push rcx
000073baab9e3084  push rdx
000073baab9e3085  push rdi
000073baab9e3086  push rsi
000073baab9e3087  push r8
000073baab9e3089  push r9
000073baab9e308b  push r10
000073baab9e308d  push r11
000073baab9e308f  sub rsp, 0xF0
000073baab9e3096  vmovaps [rsp], xmm0
000073baab9e309b  vmovaps [rsp+0x10], xmm1
000073baab9e30a1  vmovaps [rsp+0x20], xmm2
000073baab9e30a7  vmovaps [rsp+0x30], xmm3
000073baab9e30ad  vmovaps [rsp+0x40], xmm4
000073baab9e30b3  vmovaps [rsp+0x50], xmm5
000073baab9e30b9  vmovaps [rsp+0x60], xmm6
000073baab9e30bf  vmovaps [rsp+0x70], xmm7
000073baab9e30c5  vmovaps [rsp+0x80], xmm8
000073baab9e30ce  vmovaps [rsp+0x90], xmm9
000073baab9e30d7  vmovaps [rsp+0xA0], xmm11
000073baab9e30e0  vmovaps [rsp+0xB0], xmm12
000073baab9e30e9  vmovaps [rsp+0xC0], xmm13
000073baab9e30f2  vmovaps [rsp+0xD0], xmm14
000073baab9e30fb  vmovaps [rsp+0xE0], xmm15
000073baab9e3104  sub rsp, 0x30
000073baab9e3108  movaps [rsp], xmm10
000073baab9e310d  movaps [rsp+0x10], xmm14
000073baab9e3113  movaps [rsp+0x20], xmm4
000073baab9e3118  lea rdi, [rsp]
000073baab9e311c  mov esi, 0x00
000073baab9e3121  mov rax, 0x5F3F1062D530
000073baab9e312b  call rax
000073baab9e312d  movaps xmm10, [rsp]
000073baab9e3132  add rsp, 0x30
000073baab9e3136  vmovaps xmm0, [rsp]
000073baab9e313b  vmovaps xmm1, [rsp+0x10]
000073baab9e3141  vmovaps xmm2, [rsp+0x20]
000073baab9e3147  vmovaps xmm3, [rsp+0x30]
000073baab9e314d  vmovaps xmm4, [rsp+0x40]
000073baab9e3153  vmovaps xmm5, [rsp+0x50]
000073baab9e3159  vmovaps xmm6, [rsp+0x60]
000073baab9e315f  vmovaps xmm7, [rsp+0x70]
000073baab9e3165  vmovaps xmm8, [rsp+0x80]
000073baab9e316e  vmovaps xmm9, [rsp+0x90]
000073baab9e3177  vmovaps xmm11, [rsp+0xA0]
000073baab9e3180  vmovaps xmm12, [rsp+0xB0]
000073baab9e3189  vmovaps xmm13, [rsp+0xC0]
000073baab9e3192  vmovaps xmm14, [rsp+0xD0]
000073baab9e319b  vmovaps xmm15, [rsp+0xE0]
000073baab9e31a4  add rsp, 0xF0
000073baab9e31ab  pop r11
000073baab9e31ad  pop r10
000073baab9e31af  pop r9
000073baab9e31b1  pop r8
000073baab9e31b3  pop rsi
000073baab9e31b4  pop rdi
000073baab9e31b5  pop rdx
000073baab9e31b6  pop rcx
000073baab9e31b7  pop rax
000073baab9e31b8  add rsp, 0x08
000073baab9e31bc  jmp 0x000073BAAB9DF71B
000073baab9e31c1  sub rsp, 0x08
000073baab9e31c5  push rax
000073baab9e31c6  push rcx
000073baab9e31c7  push rdx
000073baab9e31c8  push rdi
000073baab9e31c9  push rsi
000073baab9e31ca  push r8
000073baab9e31cc  push r9
000073baab9e31ce  push r10
000073baab9e31d0  push r11
000073baab9e31d2  sub rsp, 0xF0
000073baab9e31d9  vmovaps [rsp], xmm0
000073baab9e31de  vmovaps [rsp+0x10], xmm1
000073baab9e31e4  vmovaps [rsp+0x20], xmm2
000073baab9e31ea  vmovaps [rsp+0x30], xmm3
000073baab9e31f0  vmovaps [rsp+0x40], xmm4
000073baab9e31f6  vmovaps [rsp+0x50], xmm5
000073baab9e31fc  vmovaps [rsp+0x60], xmm6
000073baab9e3202  vmovaps [rsp+0x70], xmm7
000073baab9e3208  vmovaps [rsp+0x80], xmm9
000073baab9e3211  vmovaps [rsp+0x90], xmm10
000073baab9e321a  vmovaps [rsp+0xA0], xmm11
000073baab9e3223  vmovaps [rsp+0xB0], xmm12
000073baab9e322c  vmovaps [rsp+0xC0], xmm13
000073baab9e3235  vmovaps [rsp+0xD0], xmm14
000073baab9e323e  vmovaps [rsp+0xE0], xmm15
000073baab9e3247  sub rsp, 0x30
000073baab9e324b  movaps [rsp], xmm8
000073baab9e3250  movaps [rsp+0x10], xmm1
000073baab9e3255  movaps [rsp+0x20], xmm14
000073baab9e325b  lea rdi, [rsp]
000073baab9e325f  mov esi, 0x00
000073baab9e3264  mov rax, 0x5F3F1062D530
000073baab9e326e  call rax
000073baab9e3270  movaps xmm8, [rsp]
000073baab9e3275  add rsp, 0x30
000073baab9e3279  vmovaps xmm0, [rsp]
000073baab9e327e  vmovaps xmm1, [rsp+0x10]
000073baab9e3284  vmovaps xmm2, [rsp+0x20]
000073baab9e328a  vmovaps xmm3, [rsp+0x30]
000073baab9e3290  vmovaps xmm4, [rsp+0x40]
000073baab9e3296  vmovaps xmm5, [rsp+0x50]
000073baab9e329c  vmovaps xmm6, [rsp+0x60]
000073baab9e32a2  vmovaps xmm7, [rsp+0x70]
000073baab9e32a8  vmovaps xmm9, [rsp+0x80]
000073baab9e32b1  vmovaps xmm10, [rsp+0x90]
000073baab9e32ba  vmovaps xmm11, [rsp+0xA0]
000073baab9e32c3  vmovaps xmm12, [rsp+0xB0]
000073baab9e32cc  vmovaps xmm13, [rsp+0xC0]
000073baab9e32d5  vmovaps xmm14, [rsp+0xD0]
000073baab9e32de  vmovaps xmm15, [rsp+0xE0]
000073baab9e32e7  add rsp, 0xF0
000073baab9e32ee  pop r11
000073baab9e32f0  pop r10
000073baab9e32f2  pop r9
000073baab9e32f4  pop r8
000073baab9e32f6  pop rsi
000073baab9e32f7  pop rdi
000073baab9e32f8  pop rdx
000073baab9e32f9  pop rcx
000073baab9e32fa  pop rax
000073baab9e32fb  add rsp, 0x08
000073baab9e32ff  jmp 0x000073BAAB9DF741
000073baab9e3304  sub rsp, 0x08
000073baab9e3308  push rax
000073baab9e3309  push rcx
000073baab9e330a  push rdx
000073baab9e330b  push rdi
000073baab9e330c  push rsi
000073baab9e330d  push r8
000073baab9e330f  push r9
000073baab9e3311  push r10
000073baab9e3313  push r11
000073baab9e3315  sub rsp, 0xF0
000073baab9e331c  vmovaps [rsp], xmm0
000073baab9e3321  vmovaps [rsp+0x10], xmm1
000073baab9e3327  vmovaps [rsp+0x20], xmm2
000073baab9e332d  vmovaps [rsp+0x30], xmm3
000073baab9e3333  vmovaps [rsp+0x40], xmm4
000073baab9e3339  vmovaps [rsp+0x50], xmm5
000073baab9e333f  vmovaps [rsp+0x60], xmm7
000073baab9e3345  vmovaps [rsp+0x70], xmm8
000073baab9e334b  vmovaps [rsp+0x80], xmm9
000073baab9e3354  vmovaps [rsp+0x90], xmm10
000073baab9e335d  vmovaps [rsp+0xA0], xmm11
000073baab9e3366  vmovaps [rsp+0xB0], xmm12
000073baab9e336f  vmovaps [rsp+0xC0], xmm13
000073baab9e3378  vmovaps [rsp+0xD0], xmm14
000073baab9e3381  vmovaps [rsp+0xE0], xmm15
000073baab9e338a  sub rsp, 0x30
000073baab9e338e  movaps [rsp], xmm6
000073baab9e3392  movaps [rsp+0x10], xmm1
000073baab9e3397  movaps [rsp+0x20], xmm14
000073baab9e339d  lea rdi, [rsp]
000073baab9e33a1  mov esi, 0x00
000073baab9e33a6  mov rax, 0x5F3F1062D530
000073baab9e33b0  call rax
000073baab9e33b2  movaps xmm6, [rsp]
000073baab9e33b6  add rsp, 0x30
000073baab9e33ba  vmovaps xmm0, [rsp]
000073baab9e33bf  vmovaps xmm1, [rsp+0x10]
000073baab9e33c5  vmovaps xmm2, [rsp+0x20]
000073baab9e33cb  vmovaps xmm3, [rsp+0x30]
000073baab9e33d1  vmovaps xmm4, [rsp+0x40]
000073baab9e33d7  vmovaps xmm5, [rsp+0x50]
000073baab9e33dd  vmovaps xmm7, [rsp+0x60]
000073baab9e33e3  vmovaps xmm8, [rsp+0x70]
000073baab9e33e9  vmovaps xmm9, [rsp+0x80]
000073baab9e33f2  vmovaps xmm10, [rsp+0x90]
000073baab9e33fb  vmovaps xmm11, [rsp+0xA0]
000073baab9e3404  vmovaps xmm12, [rsp+0xB0]
000073baab9e340d  vmovaps xmm13, [rsp+0xC0]
000073baab9e3416  vmovaps xmm14, [rsp+0xD0]
000073baab9e341f  vmovaps xmm15, [rsp+0xE0]
000073baab9e3428  add rsp, 0xF0
000073baab9e342f  pop r11
000073baab9e3431  pop r10
000073baab9e3433  pop r9
000073baab9e3435  pop r8
000073baab9e3437  pop rsi
000073baab9e3438  pop rdi
000073baab9e3439  pop rdx
000073baab9e343a  pop rcx
000073baab9e343b  pop rax
000073baab9e343c  add rsp, 0x08
000073baab9e3440  jmp 0x000073BAAB9DF76D
000073baab9e3445  sub rsp, 0x08
000073baab9e3449  push rax
000073baab9e344a  push rcx
000073baab9e344b  push rdx
000073baab9e344c  push rdi
000073baab9e344d  push rsi
000073baab9e344e  push r8
000073baab9e3450  push r9
000073baab9e3452  push r10
000073baab9e3454  push r11
000073baab9e3456  sub rsp, 0xF0
000073baab9e345d  vmovaps [rsp], xmm0
000073baab9e3462  vmovaps [rsp+0x10], xmm1
000073baab9e3468  vmovaps [rsp+0x20], xmm2
000073baab9e346e  vmovaps [rsp+0x30], xmm3
000073baab9e3474  vmovaps [rsp+0x40], xmm4
000073baab9e347a  vmovaps [rsp+0x50], xmm5
000073baab9e3480  vmovaps [rsp+0x60], xmm6
000073baab9e3486  vmovaps [rsp+0x70], xmm7
000073baab9e348c  vmovaps [rsp+0x80], xmm8
000073baab9e3495  vmovaps [rsp+0x90], xmm9
000073baab9e349e  vmovaps [rsp+0xA0], xmm10
000073baab9e34a7  vmovaps [rsp+0xB0], xmm11
000073baab9e34b0  vmovaps [rsp+0xC0], xmm12
000073baab9e34b9  vmovaps [rsp+0xD0], xmm13
000073baab9e34c2  vmovaps [rsp+0xE0], xmm15
000073baab9e34cb  sub rsp, 0x30
000073baab9e34cf  movaps [rsp], xmm14
000073baab9e34d4  movaps [rsp+0x10], xmm12
000073baab9e34da  movaps [rsp+0x20], xmm1
000073baab9e34df  lea rdi, [rsp]
000073baab9e34e3  mov esi, 0x00
000073baab9e34e8  mov rax, 0x5F3F1062D530
000073baab9e34f2  call rax
000073baab9e34f4  movaps xmm14, [rsp]
000073baab9e34f9  add rsp, 0x30
000073baab9e34fd  vmovaps xmm0, [rsp]
000073baab9e3502  vmovaps xmm1, [rsp+0x10]
000073baab9e3508  vmovaps xmm2, [rsp+0x20]
000073baab9e350e  vmovaps xmm3, [rsp+0x30]
000073baab9e3514  vmovaps xmm4, [rsp+0x40]
000073baab9e351a  vmovaps xmm5, [rsp+0x50]
000073baab9e3520  vmovaps xmm6, [rsp+0x60]
000073baab9e3526  vmovaps xmm7, [rsp+0x70]
000073baab9e352c  vmovaps xmm8, [rsp+0x80]
000073baab9e3535  vmovaps xmm9, [rsp+0x90]
000073baab9e353e  vmovaps xmm10, [rsp+0xA0]
000073baab9e3547  vmovaps xmm11, [rsp+0xB0]
000073baab9e3550  vmovaps xmm12, [rsp+0xC0]
000073baab9e3559  vmovaps xmm13, [rsp+0xD0]
000073baab9e3562  vmovaps xmm15, [rsp+0xE0]
000073baab9e356b  add rsp, 0xF0
000073baab9e3572  pop r11
000073baab9e3574  pop r10
000073baab9e3576  pop r9
000073baab9e3578  pop r8
000073baab9e357a  pop rsi
000073baab9e357b  pop rdi
000073baab9e357c  pop rdx
000073baab9e357d  pop rcx
000073baab9e357e  pop rax
000073baab9e357f  add rsp, 0x08
000073baab9e3583  jmp 0x000073BAAB9DF793
000073baab9e3588  sub rsp, 0x08
000073baab9e358c  push rax
000073baab9e358d  push rcx
000073baab9e358e  push rdx
000073baab9e358f  push rdi
000073baab9e3590  push rsi
000073baab9e3591  push r8
000073baab9e3593  push r9
000073baab9e3595  push r10
000073baab9e3597  push r11
000073baab9e3599  sub rsp, 0xF0
000073baab9e35a0  vmovaps [rsp], xmm0
000073baab9e35a5  vmovaps [rsp+0x10], xmm2
000073baab9e35ab  vmovaps [rsp+0x20], xmm3
000073baab9e35b1  vmovaps [rsp+0x30], xmm4
000073baab9e35b7  vmovaps [rsp+0x40], xmm5
000073baab9e35bd  vmovaps [rsp+0x50], xmm6
000073baab9e35c3  vmovaps [rsp+0x60], xmm7
000073baab9e35c9  vmovaps [rsp+0x70], xmm8
000073baab9e35cf  vmovaps [rsp+0x80], xmm9
000073baab9e35d8  vmovaps [rsp+0x90], xmm10
000073baab9e35e1  vmovaps [rsp+0xA0], xmm11
000073baab9e35ea  vmovaps [rsp+0xB0], xmm12
000073baab9e35f3  vmovaps [rsp+0xC0], xmm13
000073baab9e35fc  vmovaps [rsp+0xD0], xmm14
000073baab9e3605  vmovaps [rsp+0xE0], xmm15
000073baab9e360e  sub rsp, 0x30
000073baab9e3612  movaps [rsp], xmm1
000073baab9e3616  movaps [rsp+0x10], xmm13
000073baab9e361c  movaps [rsp+0x20], xmm9
000073baab9e3622  lea rdi, [rsp]
000073baab9e3626  mov esi, 0x00
000073baab9e362b  mov rax, 0x5F3F1062D530
000073baab9e3635  call rax
000073baab9e3637  movaps xmm1, [rsp]
000073baab9e363b  add rsp, 0x30
000073baab9e363f  vmovaps xmm0, [rsp]
000073baab9e3644  vmovaps xmm2, [rsp+0x10]
000073baab9e364a  vmovaps xmm3, [rsp+0x20]
000073baab9e3650  vmovaps xmm4, [rsp+0x30]
000073baab9e3656  vmovaps xmm5, [rsp+0x40]
000073baab9e365c  vmovaps xmm6, [rsp+0x50]
000073baab9e3662  vmovaps xmm7, [rsp+0x60]
000073baab9e3668  vmovaps xmm8, [rsp+0x70]
000073baab9e366e  vmovaps xmm9, [rsp+0x80]
000073baab9e3677  vmovaps xmm10, [rsp+0x90]
000073baab9e3680  vmovaps xmm11, [rsp+0xA0]
000073baab9e3689  vmovaps xmm12, [rsp+0xB0]
000073baab9e3692  vmovaps xmm13, [rsp+0xC0]
000073baab9e369b  vmovaps xmm14, [rsp+0xD0]
000073baab9e36a4  vmovaps xmm15, [rsp+0xE0]
000073baab9e36ad  add rsp, 0xF0
000073baab9e36b4  pop r11
000073baab9e36b6  pop r10
000073baab9e36b8  pop r9
000073baab9e36ba  pop r8
000073baab9e36bc  pop rsi
000073baab9e36bd  pop rdi
000073baab9e36be  pop rdx
000073baab9e36bf  pop rcx
000073baab9e36c0  pop rax
000073baab9e36c1  add rsp, 0x08
000073baab9e36c5  jmp 0x000073BAAB9DF7AD
000073baab9e36ca  sub rsp, 0x08
000073baab9e36ce  push rax
000073baab9e36cf  push rcx
000073baab9e36d0  push rdx
000073baab9e36d1  push rdi
000073baab9e36d2  push rsi
000073baab9e36d3  push r8
000073baab9e36d5  push r9
000073baab9e36d7  push r10
000073baab9e36d9  push r11
000073baab9e36db  sub rsp, 0xF0
000073baab9e36e2  vmovaps [rsp], xmm0
000073baab9e36e7  vmovaps [rsp+0x10], xmm1
000073baab9e36ed  vmovaps [rsp+0x20], xmm2
000073baab9e36f3  vmovaps [rsp+0x30], xmm3
000073baab9e36f9  vmovaps [rsp+0x40], xmm4
000073baab9e36ff  vmovaps [rsp+0x50], xmm5
000073baab9e3705  vmovaps [rsp+0x60], xmm6
000073baab9e370b  vmovaps [rsp+0x70], xmm7
000073baab9e3711  vmovaps [rsp+0x80], xmm8
000073baab9e371a  vmovaps [rsp+0x90], xmm9
000073baab9e3723  vmovaps [rsp+0xA0], xmm10
000073baab9e372c  vmovaps [rsp+0xB0], xmm11
000073baab9e3735  vmovaps [rsp+0xC0], xmm13
000073baab9e373e  vmovaps [rsp+0xD0], xmm14
000073baab9e3747  vmovaps [rsp+0xE0], xmm15
000073baab9e3750  sub rsp, 0x30
000073baab9e3754  movaps [rsp], xmm12
000073baab9e3759  movaps [rsp+0x10], xmm7
000073baab9e375e  movaps [rsp+0x20], xmm13
000073baab9e3764  lea rdi, [rsp]
000073baab9e3768  mov esi, 0x00
000073baab9e376d  mov rax, 0x5F3F1062D530
000073baab9e3777  call rax
000073baab9e3779  movaps xmm12, [rsp]
000073baab9e377e  add rsp, 0x30
000073baab9e3782  vmovaps xmm0, [rsp]
000073baab9e3787  vmovaps xmm1, [rsp+0x10]
000073baab9e378d  vmovaps xmm2, [rsp+0x20]
000073baab9e3793  vmovaps xmm3, [rsp+0x30]
000073baab9e3799  vmovaps xmm4, [rsp+0x40]
000073baab9e379f  vmovaps xmm5, [rsp+0x50]
000073baab9e37a5  vmovaps xmm6, [rsp+0x60]
000073baab9e37ab  vmovaps xmm7, [rsp+0x70]
000073baab9e37b1  vmovaps xmm8, [rsp+0x80]
000073baab9e37ba  vmovaps xmm9, [rsp+0x90]
000073baab9e37c3  vmovaps xmm10, [rsp+0xA0]
000073baab9e37cc  vmovaps xmm11, [rsp+0xB0]
000073baab9e37d5  vmovaps xmm13, [rsp+0xC0]
000073baab9e37de  vmovaps xmm14, [rsp+0xD0]
000073baab9e37e7  vmovaps xmm15, [rsp+0xE0]
000073baab9e37f0  add rsp, 0xF0
000073baab9e37f7  pop r11
000073baab9e37f9  pop r10
000073baab9e37fb  pop r9
000073baab9e37fd  pop r8
000073baab9e37ff  pop rsi
000073baab9e3800  pop rdi
000073baab9e3801  pop rdx
000073baab9e3802  pop rcx
000073baab9e3803  pop rax
000073baab9e3804  add rsp, 0x08
000073baab9e3808  jmp 0x000073BAAB9DF7D4
000073baab9e380d  sub rsp, 0x08
000073baab9e3811  push rax
000073baab9e3812  push rcx
000073baab9e3813  push rdx
000073baab9e3814  push rdi
000073baab9e3815  push rsi
000073baab9e3816  push r8
000073baab9e3818  push r9
000073baab9e381a  push r10
000073baab9e381c  push r11
000073baab9e381e  sub rsp, 0xF0
000073baab9e3825  vmovaps [rsp], xmm0
000073baab9e382a  vmovaps [rsp+0x10], xmm1
000073baab9e3830  vmovaps [rsp+0x20], xmm2
000073baab9e3836  vmovaps [rsp+0x30], xmm3
000073baab9e383c  vmovaps [rsp+0x40], xmm4
000073baab9e3842  vmovaps [rsp+0x50], xmm5
000073baab9e3848  vmovaps [rsp+0x60], xmm6
000073baab9e384e  vmovaps [rsp+0x70], xmm7
000073baab9e3854  vmovaps [rsp+0x80], xmm8
000073baab9e385d  vmovaps [rsp+0x90], xmm9
000073baab9e3866  vmovaps [rsp+0xA0], xmm10
000073baab9e386f  vmovaps [rsp+0xB0], xmm11
000073baab9e3878  vmovaps [rsp+0xC0], xmm12
000073baab9e3881  vmovaps [rsp+0xD0], xmm14
000073baab9e388a  vmovaps [rsp+0xE0], xmm15
000073baab9e3893  sub rsp, 0x30
000073baab9e3897  movaps [rsp], xmm13
000073baab9e389c  movaps [rsp+0x10], xmm15
000073baab9e38a2  movaps [rsp+0x20], xmm8
000073baab9e38a8  lea rdi, [rsp]
000073baab9e38ac  mov esi, 0x00
000073baab9e38b1  mov rax, 0x5F3F1062D530
000073baab9e38bb  call rax
000073baab9e38bd  movaps xmm13, [rsp]
000073baab9e38c2  add rsp, 0x30
000073baab9e38c6  vmovaps xmm0, [rsp]
000073baab9e38cb  vmovaps xmm1, [rsp+0x10]
000073baab9e38d1  vmovaps xmm2, [rsp+0x20]
000073baab9e38d7  vmovaps xmm3, [rsp+0x30]
000073baab9e38dd  vmovaps xmm4, [rsp+0x40]
000073baab9e38e3  vmovaps xmm5, [rsp+0x50]
000073baab9e38e9  vmovaps xmm6, [rsp+0x60]
000073baab9e38ef  vmovaps xmm7, [rsp+0x70]
000073baab9e38f5  vmovaps xmm8, [rsp+0x80]
000073baab9e38fe  vmovaps xmm9, [rsp+0x90]
000073baab9e3907  vmovaps xmm10, [rsp+0xA0]
000073baab9e3910  vmovaps xmm11, [rsp+0xB0]
000073baab9e3919  vmovaps xmm12, [rsp+0xC0]
000073baab9e3922  vmovaps xmm14, [rsp+0xD0]
000073baab9e392b  vmovaps xmm15, [rsp+0xE0]
000073baab9e3934  add rsp, 0xF0
000073baab9e393b  pop r11
000073baab9e393d  pop r10
000073baab9e393f  pop r9
000073baab9e3941  pop r8
000073baab9e3943  pop rsi
000073baab9e3944  pop rdi
000073baab9e3945  pop rdx
000073baab9e3946  pop rcx
000073baab9e3947  pop rax
000073baab9e3948  add rsp, 0x08
000073baab9e394c  jmp 0x000073BAAB9DF7EF
000073baab9e3951  sub rsp, 0x08
000073baab9e3955  push rax
000073baab9e3956  push rcx
000073baab9e3957  push rdx
000073baab9e3958  push rdi
000073baab9e3959  push rsi
000073baab9e395a  push r8
000073baab9e395c  push r9
000073baab9e395e  push r10
000073baab9e3960  push r11
000073baab9e3962  sub rsp, 0xF0
000073baab9e3969  vmovaps [rsp], xmm0
000073baab9e396e  vmovaps [rsp+0x10], xmm1
000073baab9e3974  vmovaps [rsp+0x20], xmm2
000073baab9e397a  vmovaps [rsp+0x30], xmm3
000073baab9e3980  vmovaps [rsp+0x40], xmm4
000073baab9e3986  vmovaps [rsp+0x50], xmm5
000073baab9e398c  vmovaps [rsp+0x60], xmm6
000073baab9e3992  vmovaps [rsp+0x70], xmm7
000073baab9e3998  vmovaps [rsp+0x80], xmm9
000073baab9e39a1  vmovaps [rsp+0x90], xmm10
000073baab9e39aa  vmovaps [rsp+0xA0], xmm11
000073baab9e39b3  vmovaps [rsp+0xB0], xmm12
000073baab9e39bc  vmovaps [rsp+0xC0], xmm13
000073baab9e39c5  vmovaps [rsp+0xD0], xmm14
000073baab9e39ce  vmovaps [rsp+0xE0], xmm15
000073baab9e39d7  sub rsp, 0x30
000073baab9e39db  movaps [rsp], xmm8
000073baab9e39e0  movaps [rsp+0x10], xmm15
000073baab9e39e6  movaps [rsp+0x20], xmm9
000073baab9e39ec  lea rdi, [rsp]
000073baab9e39f0  mov esi, 0x00
000073baab9e39f5  mov rax, 0x5F3F1062D530
000073baab9e39ff  call rax
000073baab9e3a01  movaps xmm8, [rsp]
000073baab9e3a06  add rsp, 0x30
000073baab9e3a0a  vmovaps xmm0, [rsp]
000073baab9e3a0f  vmovaps xmm1, [rsp+0x10]
000073baab9e3a15  vmovaps xmm2, [rsp+0x20]
000073baab9e3a1b  vmovaps xmm3, [rsp+0x30]
000073baab9e3a21  vmovaps xmm4, [rsp+0x40]
000073baab9e3a27  vmovaps xmm5, [rsp+0x50]
000073baab9e3a2d  vmovaps xmm6, [rsp+0x60]
000073baab9e3a33  vmovaps xmm7, [rsp+0x70]
000073baab9e3a39  vmovaps xmm9, [rsp+0x80]
000073baab9e3a42  vmovaps xmm10, [rsp+0x90]
000073baab9e3a4b  vmovaps xmm11, [rsp+0xA0]
000073baab9e3a54  vmovaps xmm12, [rsp+0xB0]
000073baab9e3a5d  vmovaps xmm13, [rsp+0xC0]
000073baab9e3a66  vmovaps xmm14, [rsp+0xD0]
000073baab9e3a6f  vmovaps xmm15, [rsp+0xE0]
000073baab9e3a78  add rsp, 0xF0
000073baab9e3a7f  pop r11
000073baab9e3a81  pop r10
000073baab9e3a83  pop r9
000073baab9e3a85  pop r8
000073baab9e3a87  pop rsi
000073baab9e3a88  pop rdi
000073baab9e3a89  pop rdx
000073baab9e3a8a  pop rcx
000073baab9e3a8b  pop rax
000073baab9e3a8c  add rsp, 0x08
000073baab9e3a90  jmp 0x000073BAAB9DF81D
000073baab9e3a95  sub rsp, 0x08
000073baab9e3a99  push rax
000073baab9e3a9a  push rcx
000073baab9e3a9b  push rdx
000073baab9e3a9c  push rdi
000073baab9e3a9d  push rsi
000073baab9e3a9e  push r8
000073baab9e3aa0  push r9
000073baab9e3aa2  push r10
000073baab9e3aa4  push r11
000073baab9e3aa6  sub rsp, 0xF0
000073baab9e3aad  vmovaps [rsp], xmm0
000073baab9e3ab2  vmovaps [rsp+0x10], xmm1
000073baab9e3ab8  vmovaps [rsp+0x20], xmm2
000073baab9e3abe  vmovaps [rsp+0x30], xmm3
000073baab9e3ac4  vmovaps [rsp+0x40], xmm4
000073baab9e3aca  vmovaps [rsp+0x50], xmm5
000073baab9e3ad0  vmovaps [rsp+0x60], xmm6
000073baab9e3ad6  vmovaps [rsp+0x70], xmm7
000073baab9e3adc  vmovaps [rsp+0x80], xmm8
000073baab9e3ae5  vmovaps [rsp+0x90], xmm9
000073baab9e3aee  vmovaps [rsp+0xA0], xmm10
000073baab9e3af7  vmovaps [rsp+0xB0], xmm11
000073baab9e3b00  vmovaps [rsp+0xC0], xmm12
000073baab9e3b09  vmovaps [rsp+0xD0], xmm13
000073baab9e3b12  vmovaps [rsp+0xE0], xmm14
000073baab9e3b1b  sub rsp, 0x30
000073baab9e3b1f  movaps [rsp], xmm15
000073baab9e3b24  movaps [rsp+0x10], xmm11
000073baab9e3b2a  movaps [rsp+0x20], xmm6
000073baab9e3b2f  lea rdi, [rsp]
000073baab9e3b33  mov esi, 0x00
000073baab9e3b38  mov rax, 0x5F3F1062D530
000073baab9e3b42  call rax
000073baab9e3b44  movaps xmm15, [rsp]
000073baab9e3b49  add rsp, 0x30
000073baab9e3b4d  vmovaps xmm0, [rsp]
000073baab9e3b52  vmovaps xmm1, [rsp+0x10]
000073baab9e3b58  vmovaps xmm2, [rsp+0x20]
000073baab9e3b5e  vmovaps xmm3, [rsp+0x30]
000073baab9e3b64  vmovaps xmm4, [rsp+0x40]
000073baab9e3b6a  vmovaps xmm5, [rsp+0x50]
000073baab9e3b70  vmovaps xmm6, [rsp+0x60]
000073baab9e3b76  vmovaps xmm7, [rsp+0x70]
000073baab9e3b7c  vmovaps xmm8, [rsp+0x80]
000073baab9e3b85  vmovaps xmm9, [rsp+0x90]
000073baab9e3b8e  vmovaps xmm10, [rsp+0xA0]
000073baab9e3b97  vmovaps xmm11, [rsp+0xB0]
000073baab9e3ba0  vmovaps xmm12, [rsp+0xC0]
000073baab9e3ba9  vmovaps xmm13, [rsp+0xD0]
000073baab9e3bb2  vmovaps xmm14, [rsp+0xE0]
000073baab9e3bbb  add rsp, 0xF0
000073baab9e3bc2  pop r11
000073baab9e3bc4  pop r10
000073baab9e3bc6  pop r9
000073baab9e3bc8  pop r8
000073baab9e3bca  pop rsi
000073baab9e3bcb  pop rdi
000073baab9e3bcc  pop rdx
000073baab9e3bcd  pop rcx
000073baab9e3bce  pop rax
000073baab9e3bcf  add rsp, 0x08
000073baab9e3bd3  jmp 0x000073BAAB9DF838
000073baab9e3bd8  sub rsp, 0x08
000073baab9e3bdc  push rax
000073baab9e3bdd  push rcx
000073baab9e3bde  push rdx
000073baab9e3bdf  push rdi
000073baab9e3be0  push rsi
000073baab9e3be1  push r8
000073baab9e3be3  push r9
000073baab9e3be5  push r10
000073baab9e3be7  push r11
000073baab9e3be9  sub rsp, 0xF0
000073baab9e3bf0  vmovaps [rsp], xmm0
000073baab9e3bf5  vmovaps [rsp+0x10], xmm1
000073baab9e3bfb  vmovaps [rsp+0x20], xmm2
000073baab9e3c01  vmovaps [rsp+0x30], xmm3
000073baab9e3c07  vmovaps [rsp+0x40], xmm4
000073baab9e3c0d  vmovaps [rsp+0x50], xmm5
000073baab9e3c13  vmovaps [rsp+0x60], xmm6
000073baab9e3c19  vmovaps [rsp+0x70], xmm8
000073baab9e3c1f  vmovaps [rsp+0x80], xmm9
000073baab9e3c28  vmovaps [rsp+0x90], xmm10
000073baab9e3c31  vmovaps [rsp+0xA0], xmm11
000073baab9e3c3a  vmovaps [rsp+0xB0], xmm12
000073baab9e3c43  vmovaps [rsp+0xC0], xmm13
000073baab9e3c4c  vmovaps [rsp+0xD0], xmm14
000073baab9e3c55  vmovaps [rsp+0xE0], xmm15
000073baab9e3c5e  sub rsp, 0x30
000073baab9e3c62  movaps [rsp], xmm7
000073baab9e3c66  movaps [rsp+0x10], xmm11
000073baab9e3c6c  movaps [rsp+0x20], xmm9
000073baab9e3c72  lea rdi, [rsp]
000073baab9e3c76  mov esi, 0x00
000073baab9e3c7b  mov rax, 0x5F3F1062D530
000073baab9e3c85  call rax
000073baab9e3c87  movaps xmm7, [rsp]
000073baab9e3c8b  add rsp, 0x30
000073baab9e3c8f  vmovaps xmm0, [rsp]
000073baab9e3c94  vmovaps xmm1, [rsp+0x10]
000073baab9e3c9a  vmovaps xmm2, [rsp+0x20]
000073baab9e3ca0  vmovaps xmm3, [rsp+0x30]
000073baab9e3ca6  vmovaps xmm4, [rsp+0x40]
000073baab9e3cac  vmovaps xmm5, [rsp+0x50]
000073baab9e3cb2  vmovaps xmm6, [rsp+0x60]
000073baab9e3cb8  vmovaps xmm8, [rsp+0x70]
000073baab9e3cbe  vmovaps xmm9, [rsp+0x80]
000073baab9e3cc7  vmovaps xmm10, [rsp+0x90]
000073baab9e3cd0  vmovaps xmm11, [rsp+0xA0]
000073baab9e3cd9  vmovaps xmm12, [rsp+0xB0]
000073baab9e3ce2  vmovaps xmm13, [rsp+0xC0]
000073baab9e3ceb  vmovaps xmm14, [rsp+0xD0]
000073baab9e3cf4  vmovaps xmm15, [rsp+0xE0]
000073baab9e3cfd  add rsp, 0xF0
000073baab9e3d04  pop r11
000073baab9e3d06  pop r10
000073baab9e3d08  pop r9
000073baab9e3d0a  pop r8
000073baab9e3d0c  pop rsi
000073baab9e3d0d  pop rdi
000073baab9e3d0e  pop rdx
000073baab9e3d0f  pop rcx
000073baab9e3d10  pop rax
000073baab9e3d11  add rsp, 0x08
000073baab9e3d15  jmp 0x000073BAAB9DF865
000073baab9e3d1a  sub rsp, 0x08
000073baab9e3d1e  push rax
000073baab9e3d1f  push rcx
000073baab9e3d20  push rdx
000073baab9e3d21  push rdi
000073baab9e3d22  push rsi
000073baab9e3d23  push r8
000073baab9e3d25  push r9
000073baab9e3d27  push r10
000073baab9e3d29  push r11
000073baab9e3d2b  sub rsp, 0xF0
000073baab9e3d32  vmovaps [rsp], xmm0
000073baab9e3d37  vmovaps [rsp+0x10], xmm1
000073baab9e3d3d  vmovaps [rsp+0x20], xmm2
000073baab9e3d43  vmovaps [rsp+0x30], xmm3
000073baab9e3d49  vmovaps [rsp+0x40], xmm4
000073baab9e3d4f  vmovaps [rsp+0x50], xmm5
000073baab9e3d55  vmovaps [rsp+0x60], xmm6
000073baab9e3d5b  vmovaps [rsp+0x70], xmm7
000073baab9e3d61  vmovaps [rsp+0x80], xmm8
000073baab9e3d6a  vmovaps [rsp+0x90], xmm9
000073baab9e3d73  vmovaps [rsp+0xA0], xmm10
000073baab9e3d7c  vmovaps [rsp+0xB0], xmm12
000073baab9e3d85  vmovaps [rsp+0xC0], xmm13
000073baab9e3d8e  vmovaps [rsp+0xD0], xmm14
000073baab9e3d97  vmovaps [rsp+0xE0], xmm15
000073baab9e3da0  sub rsp, 0x30
000073baab9e3da4  movaps [rsp], xmm11
000073baab9e3da9  movaps [rsp+0x10], xmm10
000073baab9e3daf  movaps [rsp+0x20], xmm14
000073baab9e3db5  lea rdi, [rsp]
000073baab9e3db9  mov esi, 0x00
000073baab9e3dbe  mov rax, 0x5F3F1062D530
000073baab9e3dc8  call rax
000073baab9e3dca  movaps xmm11, [rsp]
000073baab9e3dcf  add rsp, 0x30
000073baab9e3dd3  vmovaps xmm0, [rsp]
000073baab9e3dd8  vmovaps xmm1, [rsp+0x10]
000073baab9e3dde  vmovaps xmm2, [rsp+0x20]
000073baab9e3de4  vmovaps xmm3, [rsp+0x30]
000073baab9e3dea  vmovaps xmm4, [rsp+0x40]
000073baab9e3df0  vmovaps xmm5, [rsp+0x50]
000073baab9e3df6  vmovaps xmm6, [rsp+0x60]
000073baab9e3dfc  vmovaps xmm7, [rsp+0x70]
000073baab9e3e02  vmovaps xmm8, [rsp+0x80]
000073baab9e3e0b  vmovaps xmm9, [rsp+0x90]
000073baab9e3e14  vmovaps xmm10, [rsp+0xA0]
000073baab9e3e1d  vmovaps xmm12, [rsp+0xB0]
000073baab9e3e26  vmovaps xmm13, [rsp+0xC0]
000073baab9e3e2f  vmovaps xmm14, [rsp+0xD0]
000073baab9e3e38  vmovaps xmm15, [rsp+0xE0]
000073baab9e3e41  add rsp, 0xF0
000073baab9e3e48  pop r11
000073baab9e3e4a  pop r10
000073baab9e3e4c  pop r9
000073baab9e3e4e  pop r8
000073baab9e3e50  pop rsi
000073baab9e3e51  pop rdi
000073baab9e3e52  pop rdx
000073baab9e3e53  pop rcx
000073baab9e3e54  pop rax
000073baab9e3e55  add rsp, 0x08
000073baab9e3e59  jmp 0x000073BAAB9DF880
000073baab9e3e5e  call 0x000073BAAB8C33A0
000073baab9e3e63  jmp 0x000073BAAB9DF88A
000073baab9e3e68  sub rsp, 0x08
000073baab9e3e6c  push rax
000073baab9e3e6d  push rcx
000073baab9e3e6e  push rdx
000073baab9e3e6f  push rdi
000073baab9e3e70  push rsi
000073baab9e3e71  push r8
000073baab9e3e73  push r9
000073baab9e3e75  push r10
000073baab9e3e77  push r11
000073baab9e3e79  sub rsp, 0xF0
000073baab9e3e80  vmovaps [rsp], xmm0
000073baab9e3e85  vmovaps [rsp+0x10], xmm1
000073baab9e3e8b  vmovaps [rsp+0x20], xmm2
000073baab9e3e91  vmovaps [rsp+0x30], xmm3
000073baab9e3e97  vmovaps [rsp+0x40], xmm4
000073baab9e3e9d  vmovaps [rsp+0x50], xmm5
000073baab9e3ea3  vmovaps [rsp+0x60], xmm6
000073baab9e3ea9  vmovaps [rsp+0x70], xmm7
000073baab9e3eaf  vmovaps [rsp+0x80], xmm8
000073baab9e3eb8  vmovaps [rsp+0x90], xmm9
000073baab9e3ec1  vmovaps [rsp+0xA0], xmm11
000073baab9e3eca  vmovaps [rsp+0xB0], xmm12
000073baab9e3ed3  vmovaps [rsp+0xC0], xmm13
000073baab9e3edc  vmovaps [rsp+0xD0], xmm14
000073baab9e3ee5  vmovaps [rsp+0xE0], xmm15
000073baab9e3eee  sub rsp, 0x30
000073baab9e3ef2  movaps [rsp], xmm10
000073baab9e3ef7  movaps [rsp+0x10], xmm1
000073baab9e3efc  movaps [rsp+0x20], xmm12
000073baab9e3f02  lea rdi, [rsp]
000073baab9e3f06  mov esi, 0x00
000073baab9e3f0b  mov rax, 0x5F3F1062D530
000073baab9e3f15  call rax
000073baab9e3f17  movaps xmm10, [rsp]
000073baab9e3f1c  add rsp, 0x30
000073baab9e3f20  vmovaps xmm0, [rsp]
000073baab9e3f25  vmovaps xmm1, [rsp+0x10]
000073baab9e3f2b  vmovaps xmm2, [rsp+0x20]
000073baab9e3f31  vmovaps xmm3, [rsp+0x30]
000073baab9e3f37  vmovaps xmm4, [rsp+0x40]
000073baab9e3f3d  vmovaps xmm5, [rsp+0x50]
000073baab9e3f43  vmovaps xmm6, [rsp+0x60]
000073baab9e3f49  vmovaps xmm7, [rsp+0x70]
000073baab9e3f4f  vmovaps xmm8, [rsp+0x80]
000073baab9e3f58  vmovaps xmm9, [rsp+0x90]
000073baab9e3f61  vmovaps xmm11, [rsp+0xA0]
000073baab9e3f6a  vmovaps xmm12, [rsp+0xB0]
000073baab9e3f73  vmovaps xmm13, [rsp+0xC0]
000073baab9e3f7c  vmovaps xmm14, [rsp+0xD0]
000073baab9e3f85  vmovaps xmm15, [rsp+0xE0]
000073baab9e3f8e  add rsp, 0xF0
000073baab9e3f95  pop r11
000073baab9e3f97  pop r10
000073baab9e3f99  pop r9
000073baab9e3f9b  pop r8
000073baab9e3f9d  pop rsi
000073baab9e3f9e  pop rdi
000073baab9e3f9f  pop rdx
000073baab9e3fa0  pop rcx
000073baab9e3fa1  pop rax
000073baab9e3fa2  add rsp, 0x08
000073baab9e3fa6  jmp 0x000073BAAB9DF8AD
000073baab9e3fab  sub rsp, 0x08
000073baab9e3faf  push rax
000073baab9e3fb0  push rcx
000073baab9e3fb1  push rdx
000073baab9e3fb2  push rdi
000073baab9e3fb3  push rsi
000073baab9e3fb4  push r8
000073baab9e3fb6  push r9
000073baab9e3fb8  push r10
000073baab9e3fba  push r11
000073baab9e3fbc  sub rsp, 0xF0
000073baab9e3fc3  vmovaps [rsp], xmm0
000073baab9e3fc8  vmovaps [rsp+0x10], xmm1
000073baab9e3fce  vmovaps [rsp+0x20], xmm2
000073baab9e3fd4  vmovaps [rsp+0x30], xmm3
000073baab9e3fda  vmovaps [rsp+0x40], xmm4
000073baab9e3fe0  vmovaps [rsp+0x50], xmm5
000073baab9e3fe6  vmovaps [rsp+0x60], xmm6
000073baab9e3fec  vmovaps [rsp+0x70], xmm7
000073baab9e3ff2  vmovaps [rsp+0x80], xmm8
000073baab9e3ffb  vmovaps [rsp+0x90], xmm9
000073baab9e4004  vmovaps [rsp+0xA0], xmm10
000073baab9e400d  vmovaps [rsp+0xB0], xmm11
000073baab9e4016  vmovaps [rsp+0xC0], xmm13
000073baab9e401f  vmovaps [rsp+0xD0], xmm14
000073baab9e4028  vmovaps [rsp+0xE0], xmm15
000073baab9e4031  sub rsp, 0x30
000073baab9e4035  movaps [rsp], xmm12
000073baab9e403a  movaps [rsp+0x10], xmm14
000073baab9e4040  movaps [rsp+0x20], xmm1
000073baab9e4045  lea rdi, [rsp]
000073baab9e4049  mov esi, 0x00
000073baab9e404e  mov rax, 0x5F3F1062D530
000073baab9e4058  call rax
000073baab9e405a  movaps xmm12, [rsp]
000073baab9e405f  add rsp, 0x30
000073baab9e4063  vmovaps xmm0, [rsp]
000073baab9e4068  vmovaps xmm1, [rsp+0x10]
000073baab9e406e  vmovaps xmm2, [rsp+0x20]
000073baab9e4074  vmovaps xmm3, [rsp+0x30]
000073baab9e407a  vmovaps xmm4, [rsp+0x40]
000073baab9e4080  vmovaps xmm5, [rsp+0x50]
000073baab9e4086  vmovaps xmm6, [rsp+0x60]
000073baab9e408c  vmovaps xmm7, [rsp+0x70]
000073baab9e4092  vmovaps xmm8, [rsp+0x80]
000073baab9e409b  vmovaps xmm9, [rsp+0x90]
000073baab9e40a4  vmovaps xmm10, [rsp+0xA0]
000073baab9e40ad  vmovaps xmm11, [rsp+0xB0]
000073baab9e40b6  vmovaps xmm13, [rsp+0xC0]
000073baab9e40bf  vmovaps xmm14, [rsp+0xD0]
000073baab9e40c8  vmovaps xmm15, [rsp+0xE0]
000073baab9e40d1  add rsp, 0xF0
000073baab9e40d8  pop r11
000073baab9e40da  pop r10
000073baab9e40dc  pop r9
000073baab9e40de  pop r8
000073baab9e40e0  pop rsi
000073baab9e40e1  pop rdi
000073baab9e40e2  pop rdx
000073baab9e40e3  pop rcx
000073baab9e40e4  pop rax
000073baab9e40e5  add rsp, 0x08
000073baab9e40e9  jmp 0x000073BAAB9DF8DC
000073baab9e40ee  sub rsp, 0x08
000073baab9e40f2  push rax
000073baab9e40f3  push rcx
000073baab9e40f4  push rdx
000073baab9e40f5  push rdi
000073baab9e40f6  push rsi
000073baab9e40f7  push r8
000073baab9e40f9  push r9
000073baab9e40fb  push r10
000073baab9e40fd  push r11
000073baab9e40ff  sub rsp, 0xF0
000073baab9e4106  vmovaps [rsp], xmm0
000073baab9e410b  vmovaps [rsp+0x10], xmm1
000073baab9e4111  vmovaps [rsp+0x20], xmm2
000073baab9e4117  vmovaps [rsp+0x30], xmm3
000073baab9e411d  vmovaps [rsp+0x40], xmm4
000073baab9e4123  vmovaps [rsp+0x50], xmm5
000073baab9e4129  vmovaps [rsp+0x60], xmm6
000073baab9e412f  vmovaps [rsp+0x70], xmm7
000073baab9e4135  vmovaps [rsp+0x80], xmm8
000073baab9e413e  vmovaps [rsp+0x90], xmm9
000073baab9e4147  vmovaps [rsp+0xA0], xmm10
000073baab9e4150  vmovaps [rsp+0xB0], xmm11
000073baab9e4159  vmovaps [rsp+0xC0], xmm12
000073baab9e4162  vmovaps [rsp+0xD0], xmm13
000073baab9e416b  vmovaps [rsp+0xE0], xmm15
000073baab9e4174  sub rsp, 0x30
000073baab9e4178  movaps [rsp], xmm14
000073baab9e417d  movaps [rsp+0x10], xmm9
000073baab9e4183  movaps [rsp+0x20], xmm1
000073baab9e4188  lea rdi, [rsp]
000073baab9e418c  mov esi, 0x00
000073baab9e4191  mov rax, 0x5F3F1062D530
000073baab9e419b  call rax
000073baab9e419d  movaps xmm14, [rsp]
000073baab9e41a2  add rsp, 0x30
000073baab9e41a6  vmovaps xmm0, [rsp]
000073baab9e41ab  vmovaps xmm1, [rsp+0x10]
000073baab9e41b1  vmovaps xmm2, [rsp+0x20]
000073baab9e41b7  vmovaps xmm3, [rsp+0x30]
000073baab9e41bd  vmovaps xmm4, [rsp+0x40]
000073baab9e41c3  vmovaps xmm5, [rsp+0x50]
000073baab9e41c9  vmovaps xmm6, [rsp+0x60]
000073baab9e41cf  vmovaps xmm7, [rsp+0x70]
000073baab9e41d5  vmovaps xmm8, [rsp+0x80]
000073baab9e41de  vmovaps xmm9, [rsp+0x90]
000073baab9e41e7  vmovaps xmm10, [rsp+0xA0]
000073baab9e41f0  vmovaps xmm11, [rsp+0xB0]
000073baab9e41f9  vmovaps xmm12, [rsp+0xC0]
000073baab9e4202  vmovaps xmm13, [rsp+0xD0]
000073baab9e420b  vmovaps xmm15, [rsp+0xE0]
000073baab9e4214  add rsp, 0xF0
000073baab9e421b  pop r11
000073baab9e421d  pop r10
000073baab9e421f  pop r9
000073baab9e4221  pop r8
000073baab9e4223  pop rsi
000073baab9e4224  pop rdi
000073baab9e4225  pop rdx
000073baab9e4226  pop rcx
000073baab9e4227  pop rax
000073baab9e4228  add rsp, 0x08
000073baab9e422c  jmp 0x000073BAAB9DF90B
000073baab9e4231  sub rsp, 0x08
000073baab9e4235  push rax
000073baab9e4236  push rcx
000073baab9e4237  push rdx
000073baab9e4238  push rdi
000073baab9e4239  push rsi
000073baab9e423a  push r8
000073baab9e423c  push r9
000073baab9e423e  push r10
000073baab9e4240  push r11
000073baab9e4242  sub rsp, 0xF0
000073baab9e4249  vmovaps [rsp], xmm0
000073baab9e424e  vmovaps [rsp+0x10], xmm2
000073baab9e4254  vmovaps [rsp+0x20], xmm3
000073baab9e425a  vmovaps [rsp+0x30], xmm4
000073baab9e4260  vmovaps [rsp+0x40], xmm5
000073baab9e4266  vmovaps [rsp+0x50], xmm6
000073baab9e426c  vmovaps [rsp+0x60], xmm7
000073baab9e4272  vmovaps [rsp+0x70], xmm8
000073baab9e4278  vmovaps [rsp+0x80], xmm9
000073baab9e4281  vmovaps [rsp+0x90], xmm10
000073baab9e428a  vmovaps [rsp+0xA0], xmm11
000073baab9e4293  vmovaps [rsp+0xB0], xmm12
000073baab9e429c  vmovaps [rsp+0xC0], xmm13
000073baab9e42a5  vmovaps [rsp+0xD0], xmm14
000073baab9e42ae  vmovaps [rsp+0xE0], xmm15
000073baab9e42b7  sub rsp, 0x30
000073baab9e42bb  movaps [rsp], xmm1
000073baab9e42bf  movaps [rsp+0x10], xmm13
000073baab9e42c5  movaps [rsp+0x20], xmm8
000073baab9e42cb  lea rdi, [rsp]
000073baab9e42cf  mov esi, 0x00
000073baab9e42d4  mov rax, 0x5F3F1062D530
000073baab9e42de  call rax
000073baab9e42e0  movaps xmm1, [rsp]
000073baab9e42e4  add rsp, 0x30
000073baab9e42e8  vmovaps xmm0, [rsp]
000073baab9e42ed  vmovaps xmm2, [rsp+0x10]
000073baab9e42f3  vmovaps xmm3, [rsp+0x20]
000073baab9e42f9  vmovaps xmm4, [rsp+0x30]
000073baab9e42ff  vmovaps xmm5, [rsp+0x40]
000073baab9e4305  vmovaps xmm6, [rsp+0x50]
000073baab9e430b  vmovaps xmm7, [rsp+0x60]
000073baab9e4311  vmovaps xmm8, [rsp+0x70]
000073baab9e4317  vmovaps xmm9, [rsp+0x80]
000073baab9e4320  vmovaps xmm10, [rsp+0x90]
000073baab9e4329  vmovaps xmm11, [rsp+0xA0]
000073baab9e4332  vmovaps xmm12, [rsp+0xB0]
000073baab9e433b  vmovaps xmm13, [rsp+0xC0]
000073baab9e4344  vmovaps xmm14, [rsp+0xD0]
000073baab9e434d  vmovaps xmm15, [rsp+0xE0]
000073baab9e4356  add rsp, 0xF0
000073baab9e435d  pop r11
000073baab9e435f  pop r10
000073baab9e4361  pop r9
000073baab9e4363  pop r8
000073baab9e4365  pop rsi
000073baab9e4366  pop rdi
000073baab9e4367  pop rdx
000073baab9e4368  pop rcx
000073baab9e4369  pop rax
000073baab9e436a  add rsp, 0x08
000073baab9e436e  jmp 0x000073BAAB9DF92D
000073baab9e4373  call 0x000073BAAB80C260
000073baab9e4378  jmp 0x000073BAAB9DF93B
000073baab9e437d  call 0x000073BAAB8BD750
000073baab9e4382  jmp 0x000073BAAB9DF945
000073baab9e4387  sub rsp, 0x08
000073baab9e438b  push rax
000073baab9e438c  push rcx
000073baab9e438d  push rdx
000073baab9e438e  push rdi
000073baab9e438f  push rsi
000073baab9e4390  push r8
000073baab9e4392  push r9
000073baab9e4394  push r10
000073baab9e4396  push r11
000073baab9e4398  sub rsp, 0xF0
000073baab9e439f  vmovaps [rsp], xmm0
000073baab9e43a4  vmovaps [rsp+0x10], xmm1
000073baab9e43aa  vmovaps [rsp+0x20], xmm2
000073baab9e43b0  vmovaps [rsp+0x30], xmm3
000073baab9e43b6  vmovaps [rsp+0x40], xmm4
000073baab9e43bc  vmovaps [rsp+0x50], xmm5
000073baab9e43c2  vmovaps [rsp+0x60], xmm6
000073baab9e43c8  vmovaps [rsp+0x70], xmm7
000073baab9e43ce  vmovaps [rsp+0x80], xmm9
000073baab9e43d7  vmovaps [rsp+0x90], xmm10
000073baab9e43e0  vmovaps [rsp+0xA0], xmm11
000073baab9e43e9  vmovaps [rsp+0xB0], xmm12
000073baab9e43f2  vmovaps [rsp+0xC0], xmm13
000073baab9e43fb  vmovaps [rsp+0xD0], xmm14
000073baab9e4404  vmovaps [rsp+0xE0], xmm15
000073baab9e440d  sub rsp, 0x30
000073baab9e4411  movaps [rsp], xmm8
000073baab9e4416  movaps [rsp+0x10], xmm15
000073baab9e441c  movaps [rsp+0x20], xmm7
000073baab9e4421  lea rdi, [rsp]
000073baab9e4425  mov esi, 0x00
000073baab9e442a  mov rax, 0x5F3F1062D530
000073baab9e4434  call rax
000073baab9e4436  movaps xmm8, [rsp]
000073baab9e443b  add rsp, 0x30
000073baab9e443f  vmovaps xmm0, [rsp]
000073baab9e4444  vmovaps xmm1, [rsp+0x10]
000073baab9e444a  vmovaps xmm2, [rsp+0x20]
000073baab9e4450  vmovaps xmm3, [rsp+0x30]
000073baab9e4456  vmovaps xmm4, [rsp+0x40]
000073baab9e445c  vmovaps xmm5, [rsp+0x50]
000073baab9e4462  vmovaps xmm6, [rsp+0x60]
000073baab9e4468  vmovaps xmm7, [rsp+0x70]
000073baab9e446e  vmovaps xmm9, [rsp+0x80]
000073baab9e4477  vmovaps xmm10, [rsp+0x90]
000073baab9e4480  vmovaps xmm11, [rsp+0xA0]
000073baab9e4489  vmovaps xmm12, [rsp+0xB0]
000073baab9e4492  vmovaps xmm13, [rsp+0xC0]
000073baab9e449b  vmovaps xmm14, [rsp+0xD0]
000073baab9e44a4  vmovaps xmm15, [rsp+0xE0]
000073baab9e44ad  add rsp, 0xF0
000073baab9e44b4  pop r11
000073baab9e44b6  pop r10
000073baab9e44b8  pop r9
000073baab9e44ba  pop r8
000073baab9e44bc  pop rsi
000073baab9e44bd  pop rdi
000073baab9e44be  pop rdx
000073baab9e44bf  pop rcx
000073baab9e44c0  pop rax
000073baab9e44c1  add rsp, 0x08
000073baab9e44c5  jmp 0x000073BAAB9DF967
000073baab9e44ca  sub rsp, 0x08
000073baab9e44ce  push rax
000073baab9e44cf  push rcx
000073baab9e44d0  push rdx
000073baab9e44d1  push rdi
000073baab9e44d2  push rsi
000073baab9e44d3  push r8
000073baab9e44d5  push r9
000073baab9e44d7  push r10
000073baab9e44d9  push r11
000073baab9e44db  sub rsp, 0xF0
000073baab9e44e2  vmovaps [rsp], xmm0
000073baab9e44e7  vmovaps [rsp+0x10], xmm1
000073baab9e44ed  vmovaps [rsp+0x20], xmm2
000073baab9e44f3  vmovaps [rsp+0x30], xmm3
000073baab9e44f9  vmovaps [rsp+0x40], xmm4
000073baab9e44ff  vmovaps [rsp+0x50], xmm5
000073baab9e4505  vmovaps [rsp+0x60], xmm6
000073baab9e450b  vmovaps [rsp+0x70], xmm8
000073baab9e4511  vmovaps [rsp+0x80], xmm9
000073baab9e451a  vmovaps [rsp+0x90], xmm10
000073baab9e4523  vmovaps [rsp+0xA0], xmm11
000073baab9e452c  vmovaps [rsp+0xB0], xmm12
000073baab9e4535  vmovaps [rsp+0xC0], xmm13
000073baab9e453e  vmovaps [rsp+0xD0], xmm14
000073baab9e4547  vmovaps [rsp+0xE0], xmm15
000073baab9e4550  sub rsp, 0x30
000073baab9e4554  movaps [rsp], xmm7
000073baab9e4558  movaps [rsp+0x10], xmm9
000073baab9e455e  movaps [rsp+0x20], xmm15
000073baab9e4564  lea rdi, [rsp]
000073baab9e4568  mov esi, 0x00
000073baab9e456d  mov rax, 0x5F3F1062D530
000073baab9e4577  call rax
000073baab9e4579  movaps xmm7, [rsp]
000073baab9e457d  add rsp, 0x30
000073baab9e4581  vmovaps xmm0, [rsp]
000073baab9e4586  vmovaps xmm1, [rsp+0x10]
000073baab9e458c  vmovaps xmm2, [rsp+0x20]
000073baab9e4592  vmovaps xmm3, [rsp+0x30]
000073baab9e4598  vmovaps xmm4, [rsp+0x40]
000073baab9e459e  vmovaps xmm5, [rsp+0x50]
000073baab9e45a4  vmovaps xmm6, [rsp+0x60]
000073baab9e45aa  vmovaps xmm8, [rsp+0x70]
000073baab9e45b0  vmovaps xmm9, [rsp+0x80]
000073baab9e45b9  vmovaps xmm10, [rsp+0x90]
000073baab9e45c2  vmovaps xmm11, [rsp+0xA0]
000073baab9e45cb  vmovaps xmm12, [rsp+0xB0]
000073baab9e45d4  vmovaps xmm13, [rsp+0xC0]
000073baab9e45dd  vmovaps xmm14, [rsp+0xD0]
000073baab9e45e6  vmovaps xmm15, [rsp+0xE0]
000073baab9e45ef  add rsp, 0xF0
000073baab9e45f6  pop r11
000073baab9e45f8  pop r10
000073baab9e45fa  pop r9
000073baab9e45fc  pop r8
000073baab9e45fe  pop rsi
000073baab9e45ff  pop rdi
000073baab9e4600  pop rdx
000073baab9e4601  pop rcx
000073baab9e4602  pop rax
000073baab9e4603  add rsp, 0x08
000073baab9e4607  jmp 0x000073BAAB9DF994
000073baab9e460c  sub rsp, 0x08
000073baab9e4610  push rax
000073baab9e4611  push rcx
000073baab9e4612  push rdx
000073baab9e4613  push rdi
000073baab9e4614  push rsi
000073baab9e4615  push r8
000073baab9e4617  push r9
000073baab9e4619  push r10
000073baab9e461b  push r11
000073baab9e461d  sub rsp, 0xF0
000073baab9e4624  vmovaps [rsp], xmm0
000073baab9e4629  vmovaps [rsp+0x10], xmm1
000073baab9e462f  vmovaps [rsp+0x20], xmm2
000073baab9e4635  vmovaps [rsp+0x30], xmm3
000073baab9e463b  vmovaps [rsp+0x40], xmm4
000073baab9e4641  vmovaps [rsp+0x50], xmm5
000073baab9e4647  vmovaps [rsp+0x60], xmm6
000073baab9e464d  vmovaps [rsp+0x70], xmm7
000073baab9e4653  vmovaps [rsp+0x80], xmm8
000073baab9e465c  vmovaps [rsp+0x90], xmm10
000073baab9e4665  vmovaps [rsp+0xA0], xmm11
000073baab9e466e  vmovaps [rsp+0xB0], xmm12
000073baab9e4677  vmovaps [rsp+0xC0], xmm13
000073baab9e4680  vmovaps [rsp+0xD0], xmm14
000073baab9e4689  vmovaps [rsp+0xE0], xmm15
000073baab9e4692  sub rsp, 0x30
000073baab9e4696  movaps [rsp], xmm9
000073baab9e469b  movaps [rsp+0x10], xmm13
000073baab9e46a1  movaps [rsp+0x20], xmm15
000073baab9e46a7  lea rdi, [rsp]
000073baab9e46ab  mov esi, 0x00
000073baab9e46b0  mov rax, 0x5F3F1062D530
000073baab9e46ba  call rax
000073baab9e46bc  movaps xmm9, [rsp]
000073baab9e46c1  add rsp, 0x30
000073baab9e46c5  vmovaps xmm0, [rsp]
000073baab9e46ca  vmovaps xmm1, [rsp+0x10]
000073baab9e46d0  vmovaps xmm2, [rsp+0x20]
000073baab9e46d6  vmovaps xmm3, [rsp+0x30]
000073baab9e46dc  vmovaps xmm4, [rsp+0x40]
000073baab9e46e2  vmovaps xmm5, [rsp+0x50]
000073baab9e46e8  vmovaps xmm6, [rsp+0x60]
000073baab9e46ee  vmovaps xmm7, [rsp+0x70]
000073baab9e46f4  vmovaps xmm8, [rsp+0x80]
000073baab9e46fd  vmovaps xmm10, [rsp+0x90]
000073baab9e4706  vmovaps xmm11, [rsp+0xA0]
000073baab9e470f  vmovaps xmm12, [rsp+0xB0]
000073baab9e4718  vmovaps xmm13, [rsp+0xC0]
000073baab9e4721  vmovaps xmm14, [rsp+0xD0]
000073baab9e472a  vmovaps xmm15, [rsp+0xE0]
000073baab9e4733  add rsp, 0xF0
000073baab9e473a  pop r11
000073baab9e473c  pop r10
000073baab9e473e  pop r9
000073baab9e4740  pop r8
000073baab9e4742  pop rsi
000073baab9e4743  pop rdi
000073baab9e4744  pop rdx
000073baab9e4745  pop rcx
000073baab9e4746  pop rax
000073baab9e4747  add rsp, 0x08
000073baab9e474b  jmp 0x000073BAAB9DF9C2
000073baab9e4750  sub rsp, 0x08
000073baab9e4754  push rax
000073baab9e4755  push rcx
000073baab9e4756  push rdx
000073baab9e4757  push rdi
000073baab9e4758  push rsi
000073baab9e4759  push r8
000073baab9e475b  push r9
000073baab9e475d  push r10
000073baab9e475f  push r11
000073baab9e4761  sub rsp, 0xF0
000073baab9e4768  vmovaps [rsp], xmm0
000073baab9e476d  vmovaps [rsp+0x10], xmm1
000073baab9e4773  vmovaps [rsp+0x20], xmm2
000073baab9e4779  vmovaps [rsp+0x30], xmm3
000073baab9e477f  vmovaps [rsp+0x40], xmm4
000073baab9e4785  vmovaps [rsp+0x50], xmm5
000073baab9e478b  vmovaps [rsp+0x60], xmm6
000073baab9e4791  vmovaps [rsp+0x70], xmm7
000073baab9e4797  vmovaps [rsp+0x80], xmm8
000073baab9e47a0  vmovaps [rsp+0x90], xmm9
000073baab9e47a9  vmovaps [rsp+0xA0], xmm10
000073baab9e47b2  vmovaps [rsp+0xB0], xmm11
000073baab9e47bb  vmovaps [rsp+0xC0], xmm12
000073baab9e47c4  vmovaps [rsp+0xD0], xmm13
000073baab9e47cd  vmovaps [rsp+0xE0], xmm14
000073baab9e47d6  sub rsp, 0x30
000073baab9e47da  movaps [rsp], xmm15
000073baab9e47df  movaps [rsp+0x10], xmm11
000073baab9e47e5  movaps [rsp+0x20], xmm12
000073baab9e47eb  lea rdi, [rsp]
000073baab9e47ef  mov esi, 0x00
000073baab9e47f4  mov rax, 0x5F3F1062D530
000073baab9e47fe  call rax
000073baab9e4800  movaps xmm15, [rsp]
000073baab9e4805  add rsp, 0x30
000073baab9e4809  vmovaps xmm0, [rsp]
000073baab9e480e  vmovaps xmm1, [rsp+0x10]
000073baab9e4814  vmovaps xmm2, [rsp+0x20]
000073baab9e481a  vmovaps xmm3, [rsp+0x30]
000073baab9e4820  vmovaps xmm4, [rsp+0x40]
000073baab9e4826  vmovaps xmm5, [rsp+0x50]
000073baab9e482c  vmovaps xmm6, [rsp+0x60]
000073baab9e4832  vmovaps xmm7, [rsp+0x70]
000073baab9e4838  vmovaps xmm8, [rsp+0x80]
000073baab9e4841  vmovaps xmm9, [rsp+0x90]
000073baab9e484a  vmovaps xmm10, [rsp+0xA0]
000073baab9e4853  vmovaps xmm11, [rsp+0xB0]
000073baab9e485c  vmovaps xmm12, [rsp+0xC0]
000073baab9e4865  vmovaps xmm13, [rsp+0xD0]
000073baab9e486e  vmovaps xmm14, [rsp+0xE0]
000073baab9e4877  add rsp, 0xF0
000073baab9e487e  pop r11
000073baab9e4880  pop r10
000073baab9e4882  pop r9
000073baab9e4884  pop r8
000073baab9e4886  pop rsi
000073baab9e4887  pop rdi
000073baab9e4888  pop rdx
000073baab9e4889  pop rcx
000073baab9e488a  pop rax
000073baab9e488b  add rsp, 0x08
000073baab9e488f  jmp 0x000073BAAB9DF9DD
000073baab9e4894  sub rsp, 0x08
000073baab9e4898  push rax
000073baab9e4899  push rcx
000073baab9e489a  push rdx
000073baab9e489b  push rdi
000073baab9e489c  push rsi
000073baab9e489d  push r8
000073baab9e489f  push r9
000073baab9e48a1  push r10
000073baab9e48a3  push r11
000073baab9e48a5  sub rsp, 0xF0
000073baab9e48ac  vmovaps [rsp], xmm0
000073baab9e48b1  vmovaps [rsp+0x10], xmm1
000073baab9e48b7  vmovaps [rsp+0x20], xmm2
000073baab9e48bd  vmovaps [rsp+0x30], xmm3
000073baab9e48c3  vmovaps [rsp+0x40], xmm4
000073baab9e48c9  vmovaps [rsp+0x50], xmm5
000073baab9e48cf  vmovaps [rsp+0x60], xmm6
000073baab9e48d5  vmovaps [rsp+0x70], xmm7
000073baab9e48db  vmovaps [rsp+0x80], xmm8
000073baab9e48e4  vmovaps [rsp+0x90], xmm9
000073baab9e48ed  vmovaps [rsp+0xA0], xmm10
000073baab9e48f6  vmovaps [rsp+0xB0], xmm11
000073baab9e48ff  vmovaps [rsp+0xC0], xmm12
000073baab9e4908  vmovaps [rsp+0xD0], xmm14
000073baab9e4911  vmovaps [rsp+0xE0], xmm15
000073baab9e491a  sub rsp, 0x30
000073baab9e491e  movaps [rsp], xmm13
000073baab9e4923  movaps [rsp+0x10], xmm10
000073baab9e4929  movaps [rsp+0x20], xmm14
000073baab9e492f  lea rdi, [rsp]
000073baab9e4933  mov esi, 0x00
000073baab9e4938  mov rax, 0x5F3F1062D530
000073baab9e4942  call rax
000073baab9e4944  movaps xmm13, [rsp]
000073baab9e4949  add rsp, 0x30
000073baab9e494d  vmovaps xmm0, [rsp]
000073baab9e4952  vmovaps xmm1, [rsp+0x10]
000073baab9e4958  vmovaps xmm2, [rsp+0x20]
000073baab9e495e  vmovaps xmm3, [rsp+0x30]
000073baab9e4964  vmovaps xmm4, [rsp+0x40]
000073baab9e496a  vmovaps xmm5, [rsp+0x50]
000073baab9e4970  vmovaps xmm6, [rsp+0x60]
000073baab9e4976  vmovaps xmm7, [rsp+0x70]
000073baab9e497c  vmovaps xmm8, [rsp+0x80]
000073baab9e4985  vmovaps xmm9, [rsp+0x90]
000073baab9e498e  vmovaps xmm10, [rsp+0xA0]
000073baab9e4997  vmovaps xmm11, [rsp+0xB0]
000073baab9e49a0  vmovaps xmm12, [rsp+0xC0]
000073baab9e49a9  vmovaps xmm14, [rsp+0xD0]
000073baab9e49b2  vmovaps xmm15, [rsp+0xE0]
000073baab9e49bb  add rsp, 0xF0
000073baab9e49c2  pop r11
000073baab9e49c4  pop r10
000073baab9e49c6  pop r9
000073baab9e49c8  pop r8
000073baab9e49ca  pop rsi
000073baab9e49cb  pop rdi
000073baab9e49cc  pop rdx
000073baab9e49cd  pop rcx
000073baab9e49ce  pop rax
000073baab9e49cf  add rsp, 0x08
000073baab9e49d3  jmp 0x000073BAAB9DFA00
000073baab9e49d8  sub rsp, 0x08
000073baab9e49dc  push rax
000073baab9e49dd  push rcx
000073baab9e49de  push rdx
000073baab9e49df  push rdi
000073baab9e49e0  push rsi
000073baab9e49e1  push r8
000073baab9e49e3  push r9
000073baab9e49e5  push r10
000073baab9e49e7  push r11
000073baab9e49e9  sub rsp, 0xF0
000073baab9e49f0  vmovaps [rsp], xmm0
000073baab9e49f5  vmovaps [rsp+0x10], xmm1
000073baab9e49fb  vmovaps [rsp+0x20], xmm2
000073baab9e4a01  vmovaps [rsp+0x30], xmm3
000073baab9e4a07  vmovaps [rsp+0x40], xmm4
000073baab9e4a0d  vmovaps [rsp+0x50], xmm5
000073baab9e4a13  vmovaps [rsp+0x60], xmm6
000073baab9e4a19  vmovaps [rsp+0x70], xmm7
000073baab9e4a1f  vmovaps [rsp+0x80], xmm8
000073baab9e4a28  vmovaps [rsp+0x90], xmm9
000073baab9e4a31  vmovaps [rsp+0xA0], xmm10
000073baab9e4a3a  vmovaps [rsp+0xB0], xmm11
000073baab9e4a43  vmovaps [rsp+0xC0], xmm12
000073baab9e4a4c  vmovaps [rsp+0xD0], xmm13
000073baab9e4a55  vmovaps [rsp+0xE0], xmm15
000073baab9e4a5e  sub rsp, 0x30
000073baab9e4a62  movaps [rsp], xmm14
000073baab9e4a67  movaps [rsp+0x10], xmm1
000073baab9e4a6c  movaps [rsp+0x20], xmm7
000073baab9e4a71  lea rdi, [rsp]
000073baab9e4a75  mov esi, 0x00
000073baab9e4a7a  mov rax, 0x5F3F1062D530
000073baab9e4a84  call rax
000073baab9e4a86  movaps xmm14, [rsp]
000073baab9e4a8b  add rsp, 0x30
000073baab9e4a8f  vmovaps xmm0, [rsp]
000073baab9e4a94  vmovaps xmm1, [rsp+0x10]
000073baab9e4a9a  vmovaps xmm2, [rsp+0x20]
000073baab9e4aa0  vmovaps xmm3, [rsp+0x30]
000073baab9e4aa6  vmovaps xmm4, [rsp+0x40]
000073baab9e4aac  vmovaps xmm5, [rsp+0x50]
000073baab9e4ab2  vmovaps xmm6, [rsp+0x60]
000073baab9e4ab8  vmovaps xmm7, [rsp+0x70]
000073baab9e4abe  vmovaps xmm8, [rsp+0x80]
000073baab9e4ac7  vmovaps xmm9, [rsp+0x90]
000073baab9e4ad0  vmovaps xmm10, [rsp+0xA0]
000073baab9e4ad9  vmovaps xmm11, [rsp+0xB0]
000073baab9e4ae2  vmovaps xmm12, [rsp+0xC0]
000073baab9e4aeb  vmovaps xmm13, [rsp+0xD0]
000073baab9e4af4  vmovaps xmm15, [rsp+0xE0]
000073baab9e4afd  add rsp, 0xF0
000073baab9e4b04  pop r11
000073baab9e4b06  pop r10
000073baab9e4b08  pop r9
000073baab9e4b0a  pop r8
000073baab9e4b0c  pop rsi
000073baab9e4b0d  pop rdi
000073baab9e4b0e  pop rdx
000073baab9e4b0f  pop rcx
000073baab9e4b10  pop rax
000073baab9e4b11  add rsp, 0x08
000073baab9e4b15  jmp 0x000073BAAB9DFA23
000073baab9e4b1a  sub rsp, 0x08
000073baab9e4b1e  push rax
000073baab9e4b1f  push rcx
000073baab9e4b20  push rdx
000073baab9e4b21  push rdi
000073baab9e4b22  push rsi
000073baab9e4b23  push r8
000073baab9e4b25  push r9
000073baab9e4b27  push r10
000073baab9e4b29  push r11
000073baab9e4b2b  sub rsp, 0xF0
000073baab9e4b32  vmovaps [rsp], xmm0
000073baab9e4b37  vmovaps [rsp+0x10], xmm2
000073baab9e4b3d  vmovaps [rsp+0x20], xmm3
000073baab9e4b43  vmovaps [rsp+0x30], xmm4
000073baab9e4b49  vmovaps [rsp+0x40], xmm5
000073baab9e4b4f  vmovaps [rsp+0x50], xmm6
000073baab9e4b55  vmovaps [rsp+0x60], xmm7
000073baab9e4b5b  vmovaps [rsp+0x70], xmm8
000073baab9e4b61  vmovaps [rsp+0x80], xmm9
000073baab9e4b6a  vmovaps [rsp+0x90], xmm10
000073baab9e4b73  vmovaps [rsp+0xA0], xmm11
000073baab9e4b7c  vmovaps [rsp+0xB0], xmm12
000073baab9e4b85  vmovaps [rsp+0xC0], xmm13
000073baab9e4b8e  vmovaps [rsp+0xD0], xmm14
000073baab9e4b97  vmovaps [rsp+0xE0], xmm15
000073baab9e4ba0  sub rsp, 0x30
000073baab9e4ba4  movaps [rsp], xmm1
000073baab9e4ba8  movaps [rsp+0x10], xmm8
000073baab9e4bae  movaps [rsp+0x20], xmm9
000073baab9e4bb4  lea rdi, [rsp]
000073baab9e4bb8  mov esi, 0x00
000073baab9e4bbd  mov rax, 0x5F3F1062D530
000073baab9e4bc7  call rax
000073baab9e4bc9  movaps xmm1, [rsp]
000073baab9e4bcd  add rsp, 0x30
000073baab9e4bd1  vmovaps xmm0, [rsp]
000073baab9e4bd6  vmovaps xmm2, [rsp+0x10]
000073baab9e4bdc  vmovaps xmm3, [rsp+0x20]
000073baab9e4be2  vmovaps xmm4, [rsp+0x30]
000073baab9e4be8  vmovaps xmm5, [rsp+0x40]
000073baab9e4bee  vmovaps xmm6, [rsp+0x50]
000073baab9e4bf4  vmovaps xmm7, [rsp+0x60]
000073baab9e4bfa  vmovaps xmm8, [rsp+0x70]
000073baab9e4c00  vmovaps xmm9, [rsp+0x80]
000073baab9e4c09  vmovaps xmm10, [rsp+0x90]
000073baab9e4c12  vmovaps xmm11, [rsp+0xA0]
000073baab9e4c1b  vmovaps xmm12, [rsp+0xB0]
000073baab9e4c24  vmovaps xmm13, [rsp+0xC0]
000073baab9e4c2d  vmovaps xmm14, [rsp+0xD0]
000073baab9e4c36  vmovaps xmm15, [rsp+0xE0]
000073baab9e4c3f  add rsp, 0xF0
000073baab9e4c46  pop r11
000073baab9e4c48  pop r10
000073baab9e4c4a  pop r9
000073baab9e4c4c  pop r8
000073baab9e4c4e  pop rsi
000073baab9e4c4f  pop rdi
000073baab9e4c50  pop rdx
000073baab9e4c51  pop rcx
000073baab9e4c52  pop rax
000073baab9e4c53  add rsp, 0x08
000073baab9e4c57  jmp 0x000073BAAB9DFA45
000073baab9e4c5c  call 0x000073BAAB8E5940
000073baab9e4c61  jmp 0x000073BAAB9DFA53
000073baab9e4c66  call 0x000073BAAB80C380
000073baab9e4c6b  jmp 0x000073BAAB9DFA5D
000073baab9e4c70  call 0x000073BAAB80D600
000073baab9e4c75  jmp 0x000073BAAB9DFA67
000073baab9e4c7a  call 0x000073BAAB7FF540
000073baab9e4c7f  jmp 0x000073BAAB9DFA71
000073baab9e4c84  int3
000073baab9e4c85  nop [rax+rax*1], ax
000073baab9e4c8e  nop
000073baab9e4c90  mov qword ptr [r15+0x40], 0x430000
000073baab9e4c98  mov eax, 0x430CC0
000073baab9e4c9d  mov r14, [r13+rax*1]
000073baab9e4ca2  movq xmm1, r14
000073baab9e4ca7  mov rax, [r15+0x50]
000073baab9e4cab  movups xmm15, [r13+rax*1]
000073baab9e4cb1  movaps [r15+0x120], xmm15
000073baab9e4cb9  mov qword ptr [r15+0x48], 0x10
000073baab9e4cc1  xor eax, eax
000073baab9e4cc3  mov r14d, 0x10
000073baab9e4cc9  mov r12d, 0x200
000073baab9e4ccf  cmp r14, r12
000073baab9e4cd2  cmc
000073baab9e4cd3  lahf
000073baab9e4cd4  seto al
000073baab9e4cd7  mov [r15+0x108], eax
000073baab9e4cde  pextrq rax, xmm15, 0x01
000073baab9e4ce5  movq xmm14, rax
000073baab9e4cea  movaps [r15+0x130], xmm14
000073baab9e4cf2  movq rax, xmm1
000073baab9e4cf7  movq r14, xmm15
000073baab9e4cfc  vmovq xmm1, rax
000073baab9e4d01  vmovq xmm15, r14
000073baab9e4d06  movaps xmm13, xmm1
000073baab9e4d0a  addsd xmm13, xmm15
000073baab9e4d0f  ucomisd xmm13, xmm13
000073baab9e4d14  jp 0x000073BAAB9E4DD3
000073baab9e4d1a  movq xmm13, xmm13
000073baab9e4d1f  movq rax, xmm13
000073baab9e4d24  movq r14, xmm14
000073baab9e4d29  vmovq xmm1, rax
000073baab9e4d2e  vmovq xmm15, r14
000073baab9e4d33  movaps xmm14, xmm1
000073baab9e4d37  addsd xmm14, xmm15
000073baab9e4d3c  ucomisd xmm14, xmm14
000073baab9e4d41  jp 0x000073BAAB9E4E1B
000073baab9e4d47  movq xmm14, xmm14
000073baab9e4d4c  movaps [r15+0x110], xmm14
000073baab9e4d54  mov eax, [r15+0x108]
000073baab9e4d5b  sahf
000073baab9e4d5c  jnz 0x000073BAAB9E4D8E
000073baab9e4d5e  cmp dword ptr [r15+0x318], 0x00
000073baab9e4d66  jz 0x000073BAAB9E5030
000073baab9e4d6c  nop [rax+rax*1], ax
000073baab9e4d75  nop [rax+rax*1], eax
000073baab9e4d7d  mov eax, 0x410704
000073baab9e4d82  mov [r15+0x100], rax
000073baab9e4d89  jmp 0x000073BAAB7FE110
000073baab9e4d8e  cmp dword ptr [r15+0x318], 0x00
000073baab9e4d96  jz 0x000073BAAB9E4E70
000073baab9e4d9c  nop [rax+rax*1], ax
000073baab9e4da5  nop [rax+rax*1], eax
000073baab9e4dad  mov eax, 0x4106E8
000073baab9e4db2  mov [r15+0x100], rax
000073baab9e4db9  jmp 0x000073BAAB7FE110
000073baab9e4dbe  int3
000073baab9e4dbf  call 0x000073BAAB80DC20
000073baab9e4dc4  jmp 0x000073BAAB9E4CA2
000073baab9e4dc9  call 0x000073BAAB80E760
000073baab9e4dce  jmp 0x000073BAAB9E4CB1
000073baab9e4dd3  ucomisd xmm1, xmm15
000073baab9e4dd8  jp 0x000073BAAB9E4DE7
000073baab9e4dda  movaps xmm13, [0x000073BAAB5FE060]
000073baab9e4de2  jmp 0x000073BAAB9E4D1A
000073baab9e4de7  vxorps xmm0, xmm1, xmm15
000073baab9e4dec  pextrw eax, xmm0, 0x03
000073baab9e4df1  and eax, 0x7FF8
000073baab9e4df6  cmp eax, 0x08
000073baab9e4df9  jnz 0x000073BAAB9E4D1A
000073baab9e4dff  movq rax, xmm15
000073baab9e4e04  shl rax, 0x0D
000073baab9e4e08  jbe 0x000073BAAB9E4D1A
000073baab9e4e0e  vorps xmm13, xmm15, [0x000073BAAB5FE070]
000073baab9e4e16  jmp 0x000073BAAB9E4D1A
000073baab9e4e1b  ucomisd xmm1, xmm15
000073baab9e4e20  jp 0x000073BAAB9E4E2F
000073baab9e4e22  movaps xmm14, [0x000073BAAB5FE060]
000073baab9e4e2a  jmp 0x000073BAAB9E4D47
000073baab9e4e2f  vxorps xmm0, xmm1, xmm15
000073baab9e4e34  pextrw eax, xmm0, 0x03
000073baab9e4e39  and eax, 0x7FF8
000073baab9e4e3e  cmp eax, 0x08
000073baab9e4e41  jnz 0x000073BAAB9E4D47
000073baab9e4e47  movq rax, xmm15
000073baab9e4e4c  shl rax, 0x0D
000073baab9e4e50  jbe 0x000073BAAB9E4D47
000073baab9e4e56  vorps xmm14, xmm15, [0x000073BAAB5FE070]
000073baab9e4e5e  jmp 0x000073BAAB9E4D47
000073baab9e4e63  int3
000073baab9e4e64  nop [rax+rax*1], ax
000073baab9e4e6d  nop [rax], eax
000073baab9e4e70  mov rax, [r15+0x48]
000073baab9e4e74  mov r14, [r15+0x50]
000073baab9e4e78  lea r12, [r14+rax*1]
000073baab9e4e7c  movups xmm1, [r13+r12*1]
000073baab9e4e82  movaps [r15+0x120], xmm1
000073baab9e4e8a  lea r14, [rax+0x10]
000073baab9e4e8e  mov [r15+0x48], r14
000073baab9e4e92  xor eax, eax
000073baab9e4e94  mov r12d, 0x200
000073baab9e4e9a  cmp r14, r12
000073baab9e4e9d  cmc
000073baab9e4e9e  lahf
000073baab9e4e9f  seto al
000073baab9e4ea2  mov [r15+0x108], eax
000073baab9e4ea9  pextrq rax, xmm1, 0x01
000073baab9e4eb0  movq xmm15, rax
000073baab9e4eb5  movaps [r15+0x130], xmm15
000073baab9e4ebd  movaps xmm14, [r15+0x110]
000073baab9e4ec5  movq rax, xmm14
000073baab9e4eca  movq r14, xmm1
000073baab9e4ecf  vmovq xmm1, rax
000073baab9e4ed4  vmovq xmm14, r14
000073baab9e4ed9  movaps xmm13, xmm1
000073baab9e4edd  addsd xmm13, xmm14
000073baab9e4ee2  ucomisd xmm13, xmm13
000073baab9e4ee7  jp 0x000073BAAB9E4F9C
000073baab9e4eed  movq xmm13, xmm13
000073baab9e4ef2  movq rax, xmm13
000073baab9e4ef7  movq r14, xmm15
000073baab9e4efc  vmovq xmm1, rax
000073baab9e4f01  vmovq xmm15, r14
000073baab9e4f06  movaps xmm14, xmm1
000073baab9e4f0a  addsd xmm14, xmm15
000073baab9e4f0f  ucomisd xmm14, xmm14
000073baab9e4f14  jp 0x000073BAAB9E4FE4
000073baab9e4f1a  movq xmm14, xmm14
000073baab9e4f1f  movaps [r15+0x110], xmm14
000073baab9e4f27  mov eax, [r15+0x108]
000073baab9e4f2e  sahf
000073baab9e4f2f  jnz 0x000073BAAB9E4F61
000073baab9e4f31  cmp dword ptr [r15+0x318], 0x00
000073baab9e4f39  jz 0x000073BAAB9E5030
000073baab9e4f3f  nop [rax+rax*1], ax
000073baab9e4f48  nop [rax+rax*1], eax
000073baab9e4f50  mov eax, 0x410704
000073baab9e4f55  mov [r15+0x100], rax
000073baab9e4f5c  jmp 0x000073BAAB7FE110
000073baab9e4f61  cmp dword ptr [r15+0x318], 0x00
000073baab9e4f69  jz 0x000073BAAB9E4E70
000073baab9e4f6f  nop [rax+rax*1], ax
000073baab9e4f78  nop [rax+rax*1], eax
000073baab9e4f80  mov eax, 0x4106E8
000073baab9e4f85  mov [r15+0x100], rax
000073baab9e4f8c  jmp 0x000073BAAB7FE110
000073baab9e4f91  int3
000073baab9e4f92  call 0x000073BAAB8B52F0
000073baab9e4f97  jmp 0x000073BAAB9E4E82
000073baab9e4f9c  ucomisd xmm1, xmm14
000073baab9e4fa1  jp 0x000073BAAB9E4FB0
000073baab9e4fa3  movaps xmm13, [0x000073BAAB5FE060]
000073baab9e4fab  jmp 0x000073BAAB9E4EED
000073baab9e4fb0  vxorps xmm0, xmm1, xmm14
000073baab9e4fb5  pextrw eax, xmm0, 0x03
000073baab9e4fba  and eax, 0x7FF8
000073baab9e4fbf  cmp eax, 0x08
000073baab9e4fc2  jnz 0x000073BAAB9E4EED
000073baab9e4fc8  movq rax, xmm14
000073baab9e4fcd  shl rax, 0x0D
000073baab9e4fd1  jbe 0x000073BAAB9E4EED
000073baab9e4fd7  vorps xmm13, xmm14, [0x000073BAAB5FE070]
000073baab9e4fdf  jmp 0x000073BAAB9E4EED
000073baab9e4fe4  ucomisd xmm1, xmm15
000073baab9e4fe9  jp 0x000073BAAB9E4FF8
000073baab9e4feb  movaps xmm14, [0x000073BAAB5FE060]
000073baab9e4ff3  jmp 0x000073BAAB9E4F1A
000073baab9e4ff8  vxorps xmm0, xmm1, xmm15
000073baab9e4ffd  pextrw eax, xmm0, 0x03
000073baab9e5002  and eax, 0x7FF8
000073baab9e5007  cmp eax, 0x08
000073baab9e500a  jnz 0x000073BAAB9E4F1A
000073baab9e5010  movq rax, xmm15
000073baab9e5015  shl rax, 0x0D
000073baab9e5019  jbe 0x000073BAAB9E4F1A
000073baab9e501f  vorps xmm14, xmm15, [0x000073BAAB5FE070]
000073baab9e5027  jmp 0x000073BAAB9E4F1A
000073baab9e502c  int3
000073baab9e502d  nop [rax], eax
000073baab9e5030  mov rax, [r15+0xF8]
000073baab9e5037  lea r14, [rax+0x1D0]
000073baab9e503e  mov r12, [r13+r14*1]
000073baab9e5043  lea r14, [rax+0x1D8]
000073baab9e504a  mov r11, [r13+r14*1]
000073baab9e504f  mov [r15+0xA0], r12
000073baab9e5056  mov [r15+0x98], r11
000073baab9e505d  mov r14, [r15+0x40]
000073baab9e5061  lea r12, [r14+0xCC0]
000073baab9e5068  movaps xmm1, [r15+0x110]
000073baab9e5070  movq r14, xmm1
000073baab9e5075  mov [r13+r12*1], r14
000073baab9e507a  lea r14, [rax+0x1C0]
000073baab9e5081  mov r12, [r13+r14*1]
000073baab9e5086  lea r14, [rax+0x1C8]
000073baab9e508d  mov r11, [r13+r14*1]
000073baab9e5092  mov [r15+0xE8], r12
000073baab9e5099  mov [r15+0xF0], r11
000073baab9e50a0  lea r14, [rax+0x1B0]
000073baab9e50a7  mov r12, [r13+r14*1]
000073baab9e50ac  lea r14, [rax+0x1B8]
000073baab9e50b3  mov r10, [r13+r14*1]
000073baab9e50b8  movq xmm1, r12
000073baab9e50bd  movq xmm15, r10
000073baab9e50c2  movq xmm1, xmm1
000073baab9e50c6  movq xmm1, xmm1
000073baab9e50ca  movaps [r15+0x1A0], xmm1
000073baab9e50d2  movq xmm15, xmm15
000073baab9e50d7  movq xmm15, xmm15
000073baab9e50dc  movaps [r15+0x190], xmm15
000073baab9e50e4  lea r14, [rax+0x1A0]
000073baab9e50eb  mov r12, [r13+r14*1]
000073baab9e50f0  lea r14, [rax+0x1A8]
000073baab9e50f7  mov r10, [r13+r14*1]
000073baab9e50fc  movq xmm1, r12
000073baab9e5101  movq xmm15, r10
000073baab9e5106  movq xmm1, xmm1
000073baab9e510a  movq xmm1, xmm1
000073baab9e510e  movaps [r15+0x1C0], xmm1
000073baab9e5116  movq xmm15, xmm15
000073baab9e511b  movq xmm15, xmm15
000073baab9e5120  movaps [r15+0x1B0], xmm15
000073baab9e5128  lea r14, [rax+0x190]
000073baab9e512f  mov r12, [r13+r14*1]
000073baab9e5134  lea r14, [rax+0x198]
000073baab9e513b  mov r10, [r13+r14*1]
000073baab9e5140  movq xmm1, r12
000073baab9e5145  movq xmm15, r10
000073baab9e514a  movq xmm1, xmm1
000073baab9e514e  movq xmm1, xmm1
000073baab9e5152  movaps [r15+0x1E0], xmm1
000073baab9e515a  movq xmm15, xmm15
000073baab9e515f  movq xmm15, xmm15
000073baab9e5164  movaps [r15+0x1D0], xmm15
000073baab9e516c  lea r14, [rax+0x180]
000073baab9e5173  mov r12, [r13+r14*1]
000073baab9e5178  lea r14, [rax+0x188]
000073baab9e517f  mov r10, [r13+r14*1]
000073baab9e5184  movq xmm1, r12
000073baab9e5189  movq xmm15, r10
000073baab9e518e  movq xmm1, xmm1
000073baab9e5192  movq xmm1, xmm1
000073baab9e5196  movaps [r15+0x200], xmm1
000073baab9e519e  movq xmm15, xmm15
000073baab9e51a3  movq xmm15, xmm15
000073baab9e51a8  movaps [r15+0x1F0], xmm15
000073baab9e51b0  lea r14, [rax+0x1E0]
000073baab9e51b7  mov [r15+0xF8], r14
000073baab9e51be  mov [r15+0x100], r11
000073baab9e51c5  jmp 0x000073BAAB9CE5C0
000073baab9e51ca  int3
000073baab9e51cb  call 0x000073BAAB8E27E0
000073baab9e51d0  jmp 0x000073BAAB9E5043
000073baab9e51d5  call 0x000073BAAB8E1570
000073baab9e51da  jmp 0x000073BAAB9E504F
000073baab9e51df  call 0x000073BAAB8C3FE0
000073baab9e51e4  jmp 0x000073BAAB9E507A
000073baab9e51e9  call 0x000073BAAB8E27E0
000073baab9e51ee  jmp 0x000073BAAB9E5086
000073baab9e51f3  call 0x000073BAAB8E1570
000073baab9e51f8  jmp 0x000073BAAB9E5092
000073baab9e51fd  call 0x000073BAAB8E27E0
000073baab9e5202  jmp 0x000073BAAB9E50AC
000073baab9e5207  call 0x000073BAAB8E0300
000073baab9e520c  jmp 0x000073BAAB9E50B8
000073baab9e5211  call 0x000073BAAB8E27E0
000073baab9e5216  jmp 0x000073BAAB9E50F0
000073baab9e521b  call 0x000073BAAB8E0300
000073baab9e5220  jmp 0x000073BAAB9E50FC
000073baab9e5225  call 0x000073BAAB8E27E0
000073baab9e522a  jmp 0x000073BAAB9E5134
000073baab9e522f  call 0x000073BAAB8E0300
000073baab9e5234  jmp 0x000073BAAB9E5140
000073baab9e5239  call 0x000073BAAB8E27E0
000073baab9e523e  jmp 0x000073BAAB9E5178
000073baab9e5243  call 0x000073BAAB8E0300
000073baab9e5248  jmp 0x000073BAAB9E5184
000073baab9e524d  int3
000073baab9e524e  nop
000073baab9e5250  mov qword ptr [r15+0x100], 0x04
000073baab9e525b  mov esi, 0x00
000073baab9e5260  mov edx, 0x09
000073baab9e5265  mov rdi, 0x7FFFDCF0E510
000073baab9e526f  mov rax, 0x5F3F104C0970
000073baab9e5279  call rax
000073baab9e527b  cmp dword ptr [r15+0x318], 0x00
000073baab9e5283  jnz 0x000073BAAB7FE110
000073baab9e5289  jmp 0x000073BAAB7FE0A0
000073baab9e528e  int3
000073baab9e528f  int3
