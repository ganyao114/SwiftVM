
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-matrix/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	sub    rsp,0x150
       7:	mov    r11,QWORD PTR [r12+0x398]
       f:	mov    QWORD PTR [rsp],r11
      13:	cmp    DWORD PTR [r12+0x310],0x0
      1c:	je     0xac
      22:	push   rdx
      23:	push   rsi
      24:	push   r10
      26:	push   r11
      28:	mov    rdx,QWORD PTR [rsp+0x20]
      2d:	mov    r10d,edx
      30:	and    r10d,0xc0
      37:	shl    r10d,0x18
      3b:	mov    r11d,edx
      3e:	and    r11d,0x1
      42:	shl    r11d,0x1d
      46:	or     r10d,r11d
      49:	mov    r11d,edx
      4c:	and    r11d,0x800
      53:	shl    r11d,0x11
      57:	or     r10d,r11d
      5a:	btc    r10,0x1d
      5f:	mov    r11d,0xf0000000
      65:	and    r11,r10
      68:	movabs rsi,0xffffffff0fffffff
      72:	and    rbx,rsi
      75:	or     rbx,r11
      78:	pop    r11
      7a:	pop    r10
      7c:	pop    rsi
      7d:	pop    rdx
      7e:	mov    QWORD PTR [r12+0x108],rbx
      86:	mov    eax,0x410168
      8b:	mov    QWORD PTR [r12+0x100],rax
      93:	add    rsp,0x150
      9a:	mov    eax,0x3
      9f:	movabs r11,0x6478df27b390
      a9:	jmp    r11
      ac:	mov    r13d,0x420000
      b2:	mov    QWORD PTR [r12+0x40],r13
      b7:	movabs r13,0x100000001
      c1:	mov    r14d,0x0
      c7:	mov    QWORD PTR [r12+0x110],r13
      cf:	mov    QWORD PTR [r12+0x118],r14
      d7:	movabs r13,0x3fa0000000000000
      e1:	mov    QWORD PTR [r12+0x50],r13
      e6:	movabs r13,0x4100000041
      f0:	mov    r14d,0x0
      f6:	mov    QWORD PTR [r12+0x120],r13
      fe:	mov    QWORD PTR [r12+0x128],r14
     106:	mov    r13d,0x4204c0
     10c:	mov    r14,QWORD PTR [r13+0x0]
     110:	mov    r13d,0x0
     116:	mov    QWORD PTR [r12+0x130],r14
     11e:	mov    QWORD PTR [r12+0x138],r13
     126:	movabs r13,0x3fc0000000000000
     130:	movabs r14,0x3fc0000000000000
     13a:	mov    QWORD PTR [r12+0x140],r13
     142:	mov    QWORD PTR [r12+0x148],r14
     14a:	mov    r13d,0x2
     150:	mov    QWORD PTR [r12+0x40],r13
     155:	movabs r13,0x200000002
     15f:	mov    r14d,0x0
     165:	mov    QWORD PTR [r12+0x150],r13
     16d:	mov    QWORD PTR [r12+0x158],r14
     175:	mov    r13d,0x420000
     17b:	mov    QWORD PTR [r12+0x58],r13
     180:	mov    r13,QWORD PTR [r12+0x50]
     185:	and    r13,0xffffffffffffffff
     189:	mov    QWORD PTR [r12+0x160],r13
     191:	mov    QWORD PTR [r12+0x168],r13
     199:	mov    r13d,0x2
     19f:	mov    QWORD PTR [r12+0x170],r13
     1a7:	mov    QWORD PTR [r12+0x178],r13
     1af:	mov    r13d,0x4204d0
     1b5:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     1bb:	movdqa xmm0,xmm2
     1bf:	movdqu XMMWORD PTR [r12+0x180],xmm0
     1c9:	mov    r13d,0x0
     1cf:	mov    QWORD PTR [r12+0x48],r13
     1d4:	mov    r13d,0x430000
     1da:	add    r13,0x518
     1e1:	mov    QWORD PTR [r12+0x40],r13
     1e6:	mov    r13d,0x430000
     1ec:	add    r13,0x720
     1f3:	mov    QWORD PTR [r12+0x50],r13
     1f8:	jmp    0x1fd
     1fd:	mov    r13,QWORD PTR [r12+0x180]
     205:	mov    r14,QWORD PTR [r12+0x188]
     20d:	mov    r15d,0x0
     213:	and    r13,0xffffffffffffffff
     217:	mov    ecx,0xffffffff
     21c:	and    r13,rcx
     21f:	mov    rcx,r13
     222:	mov    rbp,r15
     225:	or     rbp,rcx
     228:	and    r14,0xffffffffffffffff
     22c:	mov    ecx,0xffffffff
     231:	and    r14,rcx
     234:	shl    r14,0x20
     238:	mov    rcx,r14
     23b:	or     rbp,rcx
     23e:	mov    QWORD PTR [r12+0x210],rbp
     246:	mov    QWORD PTR [r12+0x218],r15
     24e:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     258:	movdqa xmm2,xmm0
     25c:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     266:	movdqa xmm3,xmm0
     26a:	movdqa xmm1,xmm3
     26e:	psubd  xmm2,xmm1
     272:	movdqa xmm14,xmm2
     277:	movdqa xmm1,xmm14
     27c:	movq   rax,xmm1
     281:	mov    r13,rax
     284:	movdqu xmm0,XMMWORD PTR [r12+0x180]
     28e:	movdqa xmm2,xmm0
     292:	movdqu xmm0,XMMWORD PTR [r12+0x170]
     29c:	movdqa xmm4,xmm0
     2a0:	movdqa xmm1,xmm4
     2a4:	paddq  xmm2,xmm1
     2a8:	movdqa xmm0,xmm2
     2ac:	movdqu XMMWORD PTR [r12+0x180],xmm0
     2b6:	movdqu xmm0,XMMWORD PTR [r12+0x150]
     2c0:	movdqa xmm2,xmm0
     2c4:	movdqa xmm1,xmm2
     2c8:	paddd  xmm3,xmm1
     2cc:	movdqa xmm14,xmm3
     2d1:	movdqa xmm1,xmm14
     2d6:	movq   rax,xmm1
     2db:	mov    r14,rax
     2de:	mov    r15d,0x0
     2e4:	mov    QWORD PTR [r12+0x130],r14
     2ec:	mov    QWORD PTR [r12+0x138],r15
     2f4:	mov    r14d,0x0
     2fa:	mov    r15,r13
     2fd:	mov    ecx,0xffffffff
     302:	and    r15,rcx
     305:	and    r15,0xffffffffffffffff
     309:	mov    rcx,r15
     30c:	mov    rbp,r14
     30f:	or     rbp,rcx
     312:	shr    r13,0x20
     316:	mov    ecx,0xffffffff
     31b:	and    r13,rcx
     31e:	and    r13,0xffffffffffffffff
     322:	mov    rcx,r13
     325:	or     r14,rcx
     328:	mov    QWORD PTR [r12+0x220],rbp
     330:	mov    QWORD PTR [r12+0x228],r14
     338:	movdqu xmm0,XMMWORD PTR [r12+0x210]
     342:	movdqa xmm2,xmm0
     346:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     350:	movdqa xmm3,xmm0
     354:	movdqa xmm1,xmm3
     358:	paddd  xmm2,xmm1
     35c:	movdqa xmm14,xmm2
     361:	movdqa xmm1,xmm14
     366:	movq   rax,xmm1
     36b:	mov    r13,rax
     36e:	mov    r14d,0x0
     374:	mov    QWORD PTR [r12+0x210],r13
     37c:	mov    QWORD PTR [r12+0x218],r14
     384:	lea    r13,[r12]
     388:	movabs r14,0xb6e61da31
     392:	mov    r15d,0x4101c4
     398:	mov    rdx,QWORD PTR [rsp]
     39c:	mov    r10d,edx
     39f:	and    r10d,0xc0
     3a6:	shl    r10d,0x18
     3aa:	mov    r11d,edx
     3ad:	and    r11d,0x1
     3b1:	shl    r11d,0x1d
     3b5:	or     r10d,r11d
     3b8:	mov    r11d,edx
     3bb:	and    r11d,0x800
     3c2:	shl    r11d,0x11
     3c6:	or     r10d,r11d
     3c9:	btc    r10,0x1d
     3ce:	mov    r11d,0xf0000000
     3d4:	and    r11,r10
     3d7:	movabs rsi,0xffffffff0fffffff
     3e1:	and    rbx,rsi
     3e4:	or     rbx,r11
     3e7:	mov    QWORD PTR [r12+0x378],0x3
     3f3:	mov    QWORD PTR [r12+0x108],rbx
     3fb:	stmxcsr DWORD PTR [r12-0x28]
     401:	ldmxcsr DWORD PTR [r12-0x38]
     407:	movabs r11,0x6478df0e1dc0
     411:	mov    rdi,r13
     414:	mov    rsi,r14
     417:	mov    rdx,r15
     41a:	call   r11
     41d:	ldmxcsr DWORD PTR [r12-0x28]
     423:	mov    rbx,QWORD PTR [r12+0x108]
     42b:	mov    QWORD PTR [r12+0x378],0x2
     437:	mov    rbp,rax
     43a:	mov    r13,QWORD PTR [r12+0x210]
     442:	mov    r14d,0x0
     448:	mov    r15,r13
     44b:	mov    ecx,0xffffffff
     450:	and    r15,rcx
     453:	and    r15,0xffffffffffffffff
     457:	mov    rcx,r15
     45a:	mov    rbp,r14
     45d:	or     rbp,rcx
     460:	shr    r13,0x20
     464:	mov    ecx,0xffffffff
     469:	and    r13,rcx
     46c:	and    r13,0xffffffffffffffff
     470:	mov    rcx,r13
     473:	or     r14,rcx
     476:	mov    QWORD PTR [r12+0x210],rbp
     47e:	mov    QWORD PTR [r12+0x218],r14
     486:	lea    r13,[r12]
     48a:	movabs r14,0xb6e61da10
     494:	mov    r15d,0x4101cc
     49a:	mov    QWORD PTR [r12+0x378],0x3
     4a6:	mov    QWORD PTR [r12+0x108],rbx
     4ae:	stmxcsr DWORD PTR [r12-0x28]
     4b4:	ldmxcsr DWORD PTR [r12-0x38]
     4ba:	movabs r11,0x6478df0e1dc0
     4c4:	mov    rdi,r13
     4c7:	mov    rsi,r14
     4ca:	mov    rdx,r15
     4cd:	call   r11
     4d0:	ldmxcsr DWORD PTR [r12-0x28]
     4d6:	mov    rbx,QWORD PTR [r12+0x108]
     4de:	mov    QWORD PTR [r12+0x378],0x2
     4ea:	mov    rbp,rax
     4ed:	movdqu xmm0,XMMWORD PTR [r12+0x220]
     4f7:	movdqa xmm2,xmm0
     4fb:	movdqu xmm0,XMMWORD PTR [r12+0x140]
     505:	movdqa xmm3,xmm0
     509:	stmxcsr DWORD PTR [rsp+0x110]
     511:	mov    DWORD PTR [rsp+0x114],0x1f80
     51c:	ldmxcsr DWORD PTR [rsp+0x114]
     524:	movdqa xmm0,xmm2
     528:	movdqa xmm1,xmm3
     52c:	movq   rax,xmm0
     531:	add    rax,rax
     534:	je     0x54a
     536:	shr    rax,0x35
     53a:	sub    eax,0x201
     53f:	cmp    eax,0x3fc
     544:	ja     0x4e57
     54a:	movdqa xmm14,xmm0
     54f:	psrldq xmm14,0x8
     555:	movq   rax,xmm14
     55a:	add    rax,rax
     55d:	je     0x573
     55f:	shr    rax,0x35
     563:	sub    eax,0x201
     568:	cmp    eax,0x3fc
     56d:	ja     0x4e57
     573:	movq   rax,xmm1
     578:	add    rax,rax
     57b:	je     0x591
     57d:	shr    rax,0x35
     581:	sub    eax,0x201
     586:	cmp    eax,0x3fc
     58b:	ja     0x4e57
     591:	movdqa xmm14,xmm1
     596:	psrldq xmm14,0x8
     59c:	movq   rax,xmm14
     5a1:	add    rax,rax
     5a4:	je     0x5ba
     5a6:	shr    rax,0x35
     5aa:	sub    eax,0x201
     5af:	cmp    eax,0x3fc
     5b4:	ja     0x4e57
     5ba:	mulpd  xmm0,xmm1
     5be:	movdqa xmm4,xmm0
     5c2:	movdqa xmm0,xmm4
     5c6:	movdqu XMMWORD PTR [r12+0x220],xmm0
     5d0:	mov    r13,QWORD PTR [r12+0x48]
     5d5:	mov    r14,QWORD PTR [r12+0x50]
     5da:	mov    rcx,r13
     5dd:	add    r14,rcx
     5e0:	stmxcsr DWORD PTR [rsp+0x114]
     5e8:	ldmxcsr DWORD PTR [rsp+0x110]
     5f0:	mov    r11d,DWORD PTR [rsp+0x114]
     5f8:	shr    r11d,1
     5fb:	and    r11d,0x10
     5ff:	or     DWORD PTR [r12+0x314],r11d
     607:	movdqu XMMWORD PTR [r14],xmm4
     60c:	mov    r14d,0x0
     612:	mov    DWORD PTR [r12+0x32c],r14d
     61a:	movdqu xmm0,XMMWORD PTR [r12+0x210]
     624:	movdqa xmm2,xmm0
     628:	movdqu xmm0,XMMWORD PTR [r12+0x160]
     632:	movdqa xmm3,xmm0
     636:	stmxcsr DWORD PTR [rsp+0x110]
     63e:	mov    DWORD PTR [rsp+0x114],0x1f80
     649:	ldmxcsr DWORD PTR [rsp+0x114]
     651:	movdqa xmm0,xmm2
     655:	movdqa xmm1,xmm3
     659:	movq   rax,xmm0
     65e:	add    rax,rax
     661:	je     0x677
     663:	shr    rax,0x35
     667:	sub    eax,0x201
     66c:	cmp    eax,0x3fc
     671:	ja     0x4e7b
     677:	movdqa xmm14,xmm0
     67c:	psrldq xmm14,0x8
     682:	movq   rax,xmm14
     687:	add    rax,rax
     68a:	je     0x6a0
     68c:	shr    rax,0x35
     690:	sub    eax,0x201
     695:	cmp    eax,0x3fc
     69a:	ja     0x4e7b
     6a0:	movq   rax,xmm1
     6a5:	add    rax,rax
     6a8:	je     0x6be
     6aa:	shr    rax,0x35
     6ae:	sub    eax,0x201
     6b3:	cmp    eax,0x3fc
     6b8:	ja     0x4e7b
     6be:	movdqa xmm14,xmm1
     6c3:	psrldq xmm14,0x8
     6c9:	movq   rax,xmm14
     6ce:	add    rax,rax
     6d1:	je     0x6e7
     6d3:	shr    rax,0x35
     6d7:	sub    eax,0x201
     6dc:	cmp    eax,0x3fc
     6e1:	ja     0x4e7b
     6e7:	mulpd  xmm0,xmm1
     6eb:	movdqa xmm4,xmm0
     6ef:	movdqa xmm0,xmm4
     6f3:	movdqu XMMWORD PTR [r12+0x210],xmm0
     6fd:	mov    r14,QWORD PTR [r12+0x40]
     702:	mov    rcx,r13
     705:	add    r14,rcx
     708:	stmxcsr DWORD PTR [rsp+0x114]
     710:	ldmxcsr DWORD PTR [rsp+0x110]
     718:	mov    r11d,DWORD PTR [rsp+0x114]
     720:	shr    r11d,1
     723:	and    r11d,0x10
     727:	or     DWORD PTR [r12+0x314],r11d
     72f:	movdqu XMMWORD PTR [r14],xmm4
     734:	mov    r14d,0x0
     73a:	mov    DWORD PTR [r12+0x32c],r14d
     742:	add    r13,0x10
     746:	mov    QWORD PTR [r12+0x48],r13
     74b:	sub    r13,0x200
     752:	mov    rcx,QWORD PTR [r12+0x380]
     75a:	jrcxz  0x761
     75c:	jmp    0x6fd6
     761:	pushf
     762:	pop    r11
     764:	mov    QWORD PTR [rsp],r11
     768:	jne    0x1fd
     76e:	jmp    0x773
     773:	mov    r13,QWORD PTR [r12+0xf8]
     77b:	sub    r13,0x150
     782:	mov    QWORD PTR [r12+0xf8],r13
     78a:	mov    r14,QWORD PTR [r12+0x50]
     78f:	mov    r15,r14
     792:	add    r15,0x80
     799:	mov    rbp,r15
     79c:	add    rbp,0x10
     7a0:	movdqu xmm2,XMMWORD PTR [r15]
     7a5:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     7aa:	movdqa xmm0,xmm2
     7ae:	movdqu XMMWORD PTR [r12+0x130],xmm0
     7b8:	movdqa xmm0,xmm3
     7bc:	movdqu XMMWORD PTR [r12+0x110],xmm0
     7c6:	mov    r15d,0x0
     7cc:	mov    QWORD PTR [r12+0x48],r15
     7d1:	add    r14,0x40
     7d5:	mov    r15,r14
     7d8:	add    r15,0x10
     7dc:	movdqu xmm2,XMMWORD PTR [r14]
     7e1:	movdqu xmm3,XMMWORD PTR [r15]
     7e6:	movdqa xmm0,xmm2
     7ea:	movdqu XMMWORD PTR [r12+0x250],xmm0
     7f4:	movdqa xmm0,xmm3
     7f8:	movdqu XMMWORD PTR [r12+0x120],xmm0
     802:	add    r13,0x120
     809:	mov    r14,r13
     80c:	add    r14,0x8
     810:	mov    r15,QWORD PTR [r12+0x1c0]
     818:	mov    rbp,QWORD PTR [r12+0x1b0]
     820:	mov    QWORD PTR [r13+0x0],r15
     824:	mov    r13d,0x0
     82a:	mov    DWORD PTR [r12+0x32c],r13d
     832:	mov    QWORD PTR [r14],rbp
     835:	mov    r13d,0x0
     83b:	mov    DWORD PTR [r12+0x32c],r13d
     843:	mov    r13d,0x0
     849:	mov    r14d,0x0
     84f:	mov    QWORD PTR [r12+0x1b0],r13
     857:	mov    QWORD PTR [r12+0x1b8],r14
     85f:	mov    r13,QWORD PTR [r12+0xf8]
     867:	mov    r14,r13
     86a:	add    r14,0x100
     871:	mov    r15,r14
     874:	add    r15,0x8
     878:	mov    rbp,QWORD PTR [r12+0x200]
     880:	mov    r8,QWORD PTR [r12+0x1f0]
     888:	mov    QWORD PTR [r14],rbp
     88b:	mov    r14d,0x0
     891:	mov    DWORD PTR [r12+0x32c],r14d
     899:	mov    QWORD PTR [r15],r8
     89c:	mov    r14d,0x0
     8a2:	mov    DWORD PTR [r12+0x32c],r14d
     8aa:	mov    r14,r13
     8ad:	add    r14,0xe0
     8b4:	mov    r15,r14
     8b7:	add    r15,0x10
     8bb:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     8c5:	movdqa xmm2,xmm0
     8c9:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     8d3:	movdqa xmm3,xmm0
     8d7:	movdqu XMMWORD PTR [r14],xmm2
     8dc:	mov    r14d,0x0
     8e2:	mov    DWORD PTR [r12+0x32c],r14d
     8ea:	movdqu XMMWORD PTR [r15],xmm3
     8ef:	mov    r14d,0x0
     8f5:	mov    DWORD PTR [r12+0x32c],r14d
     8fd:	mov    r14,QWORD PTR [r12+0x50]
     902:	mov    r15,r14
     905:	add    r15,0xc0
     90c:	mov    rbp,r15
     90f:	add    rbp,0x10
     913:	movdqu xmm2,XMMWORD PTR [r15]
     918:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     91d:	movdqa xmm0,xmm2
     921:	movdqu XMMWORD PTR [r12+0x130],xmm0
     92b:	movdqa xmm0,xmm3
     92f:	movdqu XMMWORD PTR [r12+0x110],xmm0
     939:	add    r13,0x110
     940:	mov    r15,r13
     943:	add    r15,0x8
     947:	mov    rbp,QWORD PTR [r12+0x1e0]
     94f:	mov    r8,QWORD PTR [r12+0x1d0]
     957:	mov    QWORD PTR [r13+0x0],rbp
     95b:	mov    r13d,0x0
     961:	mov    DWORD PTR [r12+0x32c],r13d
     969:	mov    QWORD PTR [r15],r8
     96c:	mov    r13d,0x0
     972:	mov    DWORD PTR [r12+0x32c],r13d
     97a:	mov    r13,r14
     97d:	add    r13,0x10
     981:	movdqu xmm2,XMMWORD PTR [r14]
     986:	movdqu xmm3,XMMWORD PTR [r13+0x0]
     98c:	movdqa xmm0,xmm2
     990:	movdqu XMMWORD PTR [r12+0x170],xmm0
     99a:	movdqa xmm0,xmm3
     99e:	movdqu XMMWORD PTR [r12+0x180],xmm0
     9a8:	mov    r13,QWORD PTR [r12+0xf8]
     9b0:	mov    r14,r13
     9b3:	add    r14,0x130
     9ba:	mov    r15,r14
     9bd:	add    r15,0x8
     9c1:	mov    rbp,QWORD PTR [r12+0x1a0]
     9c9:	mov    r8,QWORD PTR [r12+0x190]
     9d1:	mov    QWORD PTR [r14],rbp
     9d4:	mov    r14d,0x0
     9da:	mov    DWORD PTR [r12+0x32c],r14d
     9e2:	mov    QWORD PTR [r15],r8
     9e5:	mov    r14d,0x0
     9eb:	mov    DWORD PTR [r12+0x32c],r14d
     9f3:	mov    r14,QWORD PTR [r12+0x50]
     9f8:	mov    r15,r14
     9fb:	add    r15,0x140
     a02:	mov    rbp,r15
     a05:	add    rbp,0x10
     a09:	movdqu xmm2,XMMWORD PTR [r15]
     a0e:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     a13:	movdqa xmm0,xmm2
     a17:	movdqu XMMWORD PTR [r12+0x270],xmm0
     a21:	movdqa xmm0,xmm3
     a25:	movdqu XMMWORD PTR [r12+0x190],xmm0
     a2f:	add    r13,0xc0
     a36:	mov    r15,r13
     a39:	add    r15,0x10
     a3d:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     a47:	movdqa xmm2,xmm0
     a4b:	movdqu xmm0,XMMWORD PTR [r12+0x130]
     a55:	movdqa xmm3,xmm0
     a59:	movdqu XMMWORD PTR [r13+0x0],xmm2
     a5f:	mov    r13d,0x0
     a65:	mov    DWORD PTR [r12+0x32c],r13d
     a6d:	movdqu XMMWORD PTR [r15],xmm3
     a72:	mov    r13d,0x0
     a78:	mov    DWORD PTR [r12+0x32c],r13d
     a80:	add    r14,0x100
     a87:	mov    r13,r14
     a8a:	add    r13,0x10
     a8e:	movdqu xmm2,XMMWORD PTR [r14]
     a93:	movdqu xmm3,XMMWORD PTR [r13+0x0]
     a99:	movdqa xmm0,xmm2
     a9d:	movdqu XMMWORD PTR [r12+0x110],xmm0
     aa7:	movdqa xmm0,xmm3
     aab:	movdqu XMMWORD PTR [r12+0x300],xmm0
     ab5:	mov    r13,QWORD PTR [r12+0xf8]
     abd:	mov    r14,r13
     ac0:	add    r14,0x140
     ac7:	mov    r15,QWORD PTR [r12+0xe8]
     acf:	mov    QWORD PTR [r14],r15
     ad2:	mov    r14d,0x0
     ad8:	mov    DWORD PTR [r12+0x32c],r14d
     ae0:	mov    r14,QWORD PTR [r12+0x50]
     ae5:	mov    r15,r14
     ae8:	add    r15,0x180
     aef:	mov    rbp,r15
     af2:	add    rbp,0x10
     af6:	movdqu xmm2,XMMWORD PTR [r15]
     afb:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     b00:	movdqa xmm0,xmm2
     b04:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
     b0e:	movdqa xmm0,xmm3
     b12:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
     b1c:	mov    r15,r14
     b1f:	add    r15,0x1c0
     b26:	mov    rbp,r15
     b29:	add    rbp,0x10
     b2d:	movdqu xmm2,XMMWORD PTR [r15]
     b32:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     b37:	movdqa xmm0,xmm2
     b3b:	movdqu XMMWORD PTR [r12+0x240],xmm0
     b45:	movdqa xmm0,xmm3
     b49:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
     b53:	add    r13,0x20
     b57:	mov    r15,r13
     b5a:	add    r15,0x10
     b5e:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     b68:	movdqa xmm2,xmm0
     b6c:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     b76:	movdqa xmm3,xmm0
     b7a:	movdqu XMMWORD PTR [r13+0x0],xmm2
     b80:	mov    r13d,0x0
     b86:	mov    DWORD PTR [r12+0x32c],r13d
     b8e:	movdqu XMMWORD PTR [r15],xmm3
     b93:	mov    r13d,0x0
     b99:	mov    DWORD PTR [r12+0x32c],r13d
     ba1:	mov    r13,r14
     ba4:	add    r13,0x60
     ba8:	mov    r15,r13
     bab:	add    r15,0x10
     baf:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     bb5:	movdqu xmm3,XMMWORD PTR [r15]
     bba:	movdqa xmm0,xmm2
     bbe:	movdqu XMMWORD PTR [r12+0x110],xmm0
     bc8:	movdqa xmm0,xmm3
     bcc:	movdqu XMMWORD PTR [r12+0x120],xmm0
     bd6:	add    r14,0x20
     bda:	mov    r13,r14
     bdd:	add    r13,0x10
     be1:	movdqu xmm2,XMMWORD PTR [r14]
     be6:	movdqu xmm3,XMMWORD PTR [r13+0x0]
     bec:	movdqa xmm0,xmm2
     bf0:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
     bfa:	movdqa xmm0,xmm3
     bfe:	movdqu XMMWORD PTR [r12+0x1f0],xmm0
     c08:	mov    r13,QWORD PTR [r12+0xf8]
     c10:	mov    r14,r13
     c13:	add    r14,0x60
     c17:	mov    r15,r14
     c1a:	add    r15,0x10
     c1e:	movdqu xmm0,XMMWORD PTR [r12+0x170]
     c28:	movdqa xmm2,xmm0
     c2c:	movdqu xmm0,XMMWORD PTR [r12+0x240]
     c36:	movdqa xmm3,xmm0
     c3a:	movdqu XMMWORD PTR [r14],xmm2
     c3f:	mov    r14d,0x0
     c45:	mov    DWORD PTR [r12+0x32c],r14d
     c4d:	movdqu XMMWORD PTR [r15],xmm3
     c52:	mov    r14d,0x0
     c58:	mov    DWORD PTR [r12+0x32c],r14d
     c60:	mov    r14,QWORD PTR [r12+0x50]
     c65:	mov    r15,r14
     c68:	add    r15,0xe0
     c6f:	mov    rbp,r15
     c72:	add    rbp,0x10
     c76:	movdqu xmm2,XMMWORD PTR [r15]
     c7b:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     c80:	movdqa xmm0,xmm2
     c84:	movdqu XMMWORD PTR [r12+0x200],xmm0
     c8e:	movdqa xmm0,xmm3
     c92:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
     c9c:	add    r13,0xa0
     ca3:	mov    r15,r13
     ca6:	add    r15,0x10
     caa:	movdqu xmm0,XMMWORD PTR [r12+0x120]
     cb4:	movdqa xmm2,xmm0
     cb8:	movdqu xmm0,XMMWORD PTR [r12+0x110]
     cc2:	movdqa xmm3,xmm0
     cc6:	movdqu XMMWORD PTR [r13+0x0],xmm2
     ccc:	mov    r13d,0x0
     cd2:	mov    DWORD PTR [r12+0x32c],r13d
     cda:	movdqu XMMWORD PTR [r15],xmm3
     cdf:	mov    r13d,0x0
     ce5:	mov    DWORD PTR [r12+0x32c],r13d
     ced:	mov    r13,r14
     cf0:	add    r13,0xa0
     cf7:	mov    r15,r13
     cfa:	add    r15,0x10
     cfe:	movdqu xmm2,XMMWORD PTR [r13+0x0]
     d04:	movdqu xmm3,XMMWORD PTR [r15]
     d09:	movdqa xmm0,xmm2
     d0d:	movdqu XMMWORD PTR [r12+0x110],xmm0
     d17:	movdqa xmm0,xmm3
     d1b:	movdqu XMMWORD PTR [r12+0x120],xmm0
     d25:	mov    r13,r14
     d28:	add    r13,0x120
     d2f:	mov    r15,r13
     d32:	add    r15,0x10
     d36:	movdqu xmm4,XMMWORD PTR [r13+0x0]
     d3c:	movdqu xmm5,XMMWORD PTR [r15]
     d41:	movdqa xmm0,xmm4
     d45:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
     d4f:	movdqa xmm0,xmm5
     d53:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
     d5d:	add    r14,0x160
     d64:	mov    r13,r14
     d67:	add    r13,0x10
     d6b:	movdqu xmm4,XMMWORD PTR [r14]
     d70:	movdqu xmm5,XMMWORD PTR [r13+0x0]
     d76:	movdqa xmm0,xmm4
     d7a:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
     d84:	movdqa xmm0,xmm5
     d88:	movdqu XMMWORD PTR [r12+0x2b0],xmm0
     d92:	mov    r13,QWORD PTR [r12+0xf8]
     d9a:	mov    r14,r13
     d9d:	add    r14,0x80
     da4:	mov    r15,r14
     da7:	add    r15,0x10
     dab:	movdqu XMMWORD PTR [r14],xmm3
     db0:	mov    r14d,0x0
     db6:	mov    DWORD PTR [r12+0x32c],r14d
     dbe:	movdqu XMMWORD PTR [r15],xmm2
     dc3:	mov    r14d,0x0
     dc9:	mov    DWORD PTR [r12+0x32c],r14d
     dd1:	mov    r14,QWORD PTR [r12+0x50]
     dd6:	mov    r15,r14
     dd9:	add    r15,0x1a0
     de0:	mov    rbp,r15
     de3:	add    rbp,0x10
     de7:	movdqu xmm2,XMMWORD PTR [r15]
     dec:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
     df1:	movdqa xmm0,xmm2
     df5:	movdqu XMMWORD PTR [r12+0x290],xmm0
     dff:	movdqa xmm0,xmm3
     e03:	movdqu XMMWORD PTR [r12+0x1e0],xmm0
     e0d:	add    r14,0x1e0
     e14:	mov    r15,r14
     e17:	add    r15,0x10
     e1b:	movdqu xmm2,XMMWORD PTR [r14]
     e20:	movdqu xmm3,XMMWORD PTR [r15]
     e25:	movdqa xmm0,xmm2
     e29:	movdqu XMMWORD PTR [r12+0x230],xmm0
     e33:	movdqa xmm0,xmm3
     e37:	movdqu XMMWORD PTR [r12+0x280],xmm0
     e41:	mov    r14d,0x430000
     e47:	add    r14,0x920
     e4e:	mov    QWORD PTR [r12+0x50],r14
     e53:	mov    r14,r13
     e56:	add    r14,0x40
     e5a:	mov    r15,r14
     e5d:	add    r15,0x10
     e61:	movdqu xmm0,XMMWORD PTR [r12+0x180]
     e6b:	movdqa xmm5,xmm0
     e6f:	movdqu XMMWORD PTR [r14],xmm4
     e74:	mov    r14d,0x0
     e7a:	mov    DWORD PTR [r12+0x32c],r14d
     e82:	movdqu XMMWORD PTR [r15],xmm5
     e87:	mov    r14d,0x0
     e8d:	mov    DWORD PTR [r12+0x32c],r14d
     e95:	mov    r14,r13
     e98:	add    r14,0x10
     e9c:	movdqu XMMWORD PTR [r13+0x0],xmm3
     ea2:	mov    r13d,0x0
     ea8:	mov    DWORD PTR [r12+0x32c],r13d
     eb0:	movdqu XMMWORD PTR [r14],xmm2
     eb5:	mov    r13d,0x0
     ebb:	mov    DWORD PTR [r12+0x32c],r13d
     ec3:	jmp    0xec8
     ec8:	mov    r13d,0x0
     ece:	mov    QWORD PTR [r12+0x58],r13
     ed3:	jmp    0xed8
     ed8:	mov    r13,QWORD PTR [r12+0x58]
     edd:	mov    r14,QWORD PTR [r12+0x40]
     ee2:	mov    rcx,r13
     ee5:	add    r14,rcx
     ee8:	mov    QWORD PTR [r12+0x60],r14
     eed:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
     ef7:	movdqa xmm2,xmm0
     efb:	movdqa xmm1,xmm2
     eff:	por    xmm2,xmm1
     f03:	movdqa xmm0,xmm2
     f07:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
     f11:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
     f1b:	movdqa xmm2,xmm0
     f1f:	movdqa xmm1,xmm2
     f23:	por    xmm2,xmm1
     f27:	movdqa xmm0,xmm2
     f2b:	movdqu XMMWORD PTR [r12+0x120],xmm0
     f35:	add    r14,0x30
     f39:	mov    r13,r14
     f3c:	add    r13,0x8
     f40:	mov    r15,QWORD PTR [r14]
     f43:	mov    r14,QWORD PTR [r13+0x0]
     f47:	mov    r13d,0x0
     f4d:	mov    QWORD PTR [r12+0x130],r15
     f55:	mov    QWORD PTR [r12+0x138],r13
     f5d:	mov    r13d,0x0
     f63:	mov    QWORD PTR [r12+0x280],r14
     f6b:	mov    QWORD PTR [r12+0x288],r13
     f73:	movdqu xmm0,XMMWORD PTR [r12+0x270]
     f7d:	movdqa xmm2,xmm0
     f81:	movdqa xmm1,xmm2
     f85:	por    xmm2,xmm1
     f89:	movdqa xmm0,xmm2
     f8d:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
     f97:	mov    r13,QWORD PTR [r12+0x60]
     f9c:	mov    r14,r13
     f9f:	add    r14,0x20
     fa3:	mov    r15,r14
     fa6:	add    r15,0x8
     faa:	mov    rbp,QWORD PTR [r14]
     fad:	mov    r14,QWORD PTR [r15]
     fb0:	mov    r15d,0x0
     fb6:	mov    QWORD PTR [r12+0x150],rbp
     fbe:	mov    QWORD PTR [r12+0x158],r15
     fc6:	mov    r15d,0x0
     fcc:	mov    QWORD PTR [r12+0x140],r14
     fd4:	mov    QWORD PTR [r12+0x148],r15
     fdc:	add    r13,0x10
     fe0:	mov    r14,r13
     fe3:	add    r14,0x8
     fe7:	mov    r15,QWORD PTR [r13+0x0]
     feb:	mov    r13,QWORD PTR [r14]
     fee:	mov    r14d,0x0
     ff4:	mov    QWORD PTR [r12+0x170],r15
     ffc:	mov    QWORD PTR [r12+0x178],r14
    1004:	mov    r14d,0x0
    100a:	mov    QWORD PTR [r12+0x160],r13
    1012:	mov    QWORD PTR [r12+0x168],r14
    101a:	mov    r13,QWORD PTR [r12+0x60]
    101f:	mov    r14d,0x8
    1025:	mov    r15,QWORD PTR [r13+0x0]
    1029:	mov    QWORD PTR [r12+0x180],r15
    1031:	mov    QWORD PTR [r12+0x188],r15
    1039:	mov    rcx,r14
    103c:	add    r13,rcx
    103f:	mov    QWORD PTR [r12+0x60],r13
    1044:	mov    r14,QWORD PTR [r13+0x0]
    1048:	mov    r13d,0x0
    104e:	mov    QWORD PTR [r12+0x230],r14
    1056:	mov    QWORD PTR [r12+0x238],r13
    105e:	mov    r13,QWORD PTR [r12+0xf8]
    1066:	mov    r14,r13
    1069:	add    r14,0x50
    106d:	mov    r15,r14
    1070:	add    r15,0x10
    1074:	movdqu xmm2,XMMWORD PTR [r14]
    1079:	movdqu xmm3,XMMWORD PTR [r15]
    107e:	movdqa xmm0,xmm2
    1082:	movdqu XMMWORD PTR [r12+0x220],xmm0
    108c:	movdqa xmm0,xmm3
    1090:	movdqu XMMWORD PTR [r12+0x210],xmm0
    109a:	add    r13,0x30
    109e:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    10a4:	movdqa xmm0,xmm2
    10a8:	movdqu XMMWORD PTR [r12+0x110],xmm0
    10b2:	mov    r13,QWORD PTR [r12+0x58]
    10b7:	mov    r14,QWORD PTR [r12+0x50]
    10bc:	mov    rcx,r13
    10bf:	add    r14,rcx
    10c2:	mov    QWORD PTR [r12+0x60],r14
    10c7:	add    r13,0x40
    10cb:	mov    QWORD PTR [r12+0x58],r13
    10d0:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    10da:	movdqa xmm3,xmm0
    10de:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    10e8:	movdqa xmm4,xmm0
    10ec:	stmxcsr DWORD PTR [rsp+0x110]
    10f4:	mov    DWORD PTR [rsp+0x114],0x1f80
    10ff:	ldmxcsr DWORD PTR [rsp+0x114]
    1107:	movdqa xmm0,xmm3
    110b:	movdqa xmm1,xmm4
    110f:	movq   rax,xmm0
    1114:	add    rax,rax
    1117:	je     0x112d
    1119:	shr    rax,0x35
    111d:	sub    eax,0x201
    1122:	cmp    eax,0x3fc
    1127:	ja     0x4e9f
    112d:	movdqa xmm14,xmm0
    1132:	psrldq xmm14,0x8
    1138:	movq   rax,xmm14
    113d:	add    rax,rax
    1140:	je     0x1156
    1142:	shr    rax,0x35
    1146:	sub    eax,0x201
    114b:	cmp    eax,0x3fc
    1150:	ja     0x4e9f
    1156:	movq   rax,xmm1
    115b:	add    rax,rax
    115e:	je     0x1174
    1160:	shr    rax,0x35
    1164:	sub    eax,0x201
    1169:	cmp    eax,0x3fc
    116e:	ja     0x4e9f
    1174:	movdqa xmm14,xmm1
    1179:	psrldq xmm14,0x8
    117f:	movq   rax,xmm14
    1184:	add    rax,rax
    1187:	je     0x119d
    1189:	shr    rax,0x35
    118d:	sub    eax,0x201
    1192:	cmp    eax,0x3fc
    1197:	ja     0x4e9f
    119d:	mulpd  xmm0,xmm1
    11a1:	movdqa xmm5,xmm0
    11a5:	movdqa xmm0,xmm5
    11a9:	movdqu XMMWORD PTR [r12+0x240],xmm0
    11b3:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    11bd:	movdqa xmm4,xmm0
    11c1:	movdqa xmm0,xmm2
    11c5:	movdqa xmm1,xmm4
    11c9:	pshufd xmm1,xmm1,0x44
    11ce:	movq   rax,xmm0
    11d3:	add    rax,rax
    11d6:	je     0x11ec
    11d8:	shr    rax,0x35
    11dc:	sub    eax,0x201
    11e1:	cmp    eax,0x3fc
    11e6:	ja     0x4ec3
    11ec:	movdqa xmm14,xmm0
    11f1:	psrldq xmm14,0x8
    11f7:	movq   rax,xmm14
    11fc:	add    rax,rax
    11ff:	je     0x1215
    1201:	shr    rax,0x35
    1205:	sub    eax,0x201
    120a:	cmp    eax,0x3fc
    120f:	ja     0x4ec3
    1215:	movq   rax,xmm1
    121a:	add    rax,rax
    121d:	je     0x1233
    121f:	shr    rax,0x35
    1223:	sub    eax,0x201
    1228:	cmp    eax,0x3fc
    122d:	ja     0x4ec3
    1233:	movdqa xmm14,xmm1
    1238:	psrldq xmm14,0x8
    123e:	movq   rax,xmm14
    1243:	add    rax,rax
    1246:	je     0x125c
    1248:	shr    rax,0x35
    124c:	sub    eax,0x201
    1251:	cmp    eax,0x3fc
    1256:	ja     0x4ec3
    125c:	mulpd  xmm0,xmm1
    1260:	movdqa xmm5,xmm0
    1264:	movdqa xmm0,xmm5
    1268:	movdqu XMMWORD PTR [r12+0x260],xmm0
    1272:	mov    r13d,0x0
    1278:	mov    r14d,0x0
    127e:	mov    QWORD PTR [r12+0x110],r13
    1286:	mov    QWORD PTR [r12+0x118],r14
    128e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    1298:	movdqa xmm2,xmm0
    129c:	movdqa xmm0,xmm3
    12a0:	movdqa xmm1,xmm2
    12a4:	movq   rax,xmm0
    12a9:	add    rax,rax
    12ac:	je     0x12c2
    12ae:	shr    rax,0x35
    12b2:	sub    eax,0x201
    12b7:	cmp    eax,0x3fc
    12bc:	ja     0x4ee7
    12c2:	movdqa xmm14,xmm0
    12c7:	psrldq xmm14,0x8
    12cd:	movq   rax,xmm14
    12d2:	add    rax,rax
    12d5:	je     0x12eb
    12d7:	shr    rax,0x35
    12db:	sub    eax,0x201
    12e0:	cmp    eax,0x3fc
    12e5:	ja     0x4ee7
    12eb:	movq   rax,xmm1
    12f0:	add    rax,rax
    12f3:	je     0x1309
    12f5:	shr    rax,0x35
    12f9:	sub    eax,0x201
    12fe:	cmp    eax,0x3fc
    1303:	ja     0x4ee7
    1309:	movdqa xmm14,xmm1
    130e:	psrldq xmm14,0x8
    1314:	movq   rax,xmm14
    1319:	add    rax,rax
    131c:	je     0x1332
    131e:	shr    rax,0x35
    1322:	sub    eax,0x201
    1327:	cmp    eax,0x3fc
    132c:	ja     0x4ee7
    1332:	mulpd  xmm0,xmm1
    1336:	movdqa xmm4,xmm0
    133a:	movdqa xmm0,xmm4
    133e:	movdqu XMMWORD PTR [r12+0x210],xmm0
    1348:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    1352:	movdqa xmm2,xmm0
    1356:	movdqa xmm0,xmm3
    135a:	movdqa xmm1,xmm2
    135e:	movq   rax,xmm0
    1363:	add    rax,rax
    1366:	je     0x137c
    1368:	shr    rax,0x35
    136c:	sub    eax,0x201
    1371:	cmp    eax,0x3fc
    1376:	ja     0x4f0b
    137c:	movdqa xmm14,xmm0
    1381:	psrldq xmm14,0x8
    1387:	movq   rax,xmm14
    138c:	add    rax,rax
    138f:	je     0x13a5
    1391:	shr    rax,0x35
    1395:	sub    eax,0x201
    139a:	cmp    eax,0x3fc
    139f:	ja     0x4f0b
    13a5:	movq   rax,xmm1
    13aa:	add    rax,rax
    13ad:	je     0x13c3
    13af:	shr    rax,0x35
    13b3:	sub    eax,0x201
    13b8:	cmp    eax,0x3fc
    13bd:	ja     0x4f0b
    13c3:	movdqa xmm14,xmm1
    13c8:	psrldq xmm14,0x8
    13ce:	movq   rax,xmm14
    13d3:	add    rax,rax
    13d6:	je     0x13ec
    13d8:	shr    rax,0x35
    13dc:	sub    eax,0x201
    13e1:	cmp    eax,0x3fc
    13e6:	ja     0x4f0b
    13ec:	mulpd  xmm0,xmm1
    13f0:	movdqa xmm4,xmm0
    13f4:	movdqa xmm0,xmm4
    13f8:	movdqu XMMWORD PTR [r12+0x220],xmm0
    1402:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    140c:	movdqa xmm2,xmm0
    1410:	movdqu xmm0,XMMWORD PTR [r12+0x1f0]
    141a:	movdqa xmm3,xmm0
    141e:	movdqa xmm0,xmm2
    1422:	movdqa xmm1,xmm3
    1426:	movq   rax,xmm0
    142b:	add    rax,rax
    142e:	je     0x1444
    1430:	shr    rax,0x35
    1434:	sub    eax,0x201
    1439:	cmp    eax,0x3fc
    143e:	ja     0x4f2f
    1444:	movdqa xmm14,xmm0
    1449:	psrldq xmm14,0x8
    144f:	movq   rax,xmm14
    1454:	add    rax,rax
    1457:	je     0x146d
    1459:	shr    rax,0x35
    145d:	sub    eax,0x201
    1462:	cmp    eax,0x3fc
    1467:	ja     0x4f2f
    146d:	movq   rax,xmm1
    1472:	add    rax,rax
    1475:	je     0x148b
    1477:	shr    rax,0x35
    147b:	sub    eax,0x201
    1480:	cmp    eax,0x3fc
    1485:	ja     0x4f2f
    148b:	movdqa xmm14,xmm1
    1490:	psrldq xmm14,0x8
    1496:	movq   rax,xmm14
    149b:	add    rax,rax
    149e:	je     0x14b4
    14a0:	shr    rax,0x35
    14a4:	sub    eax,0x201
    14a9:	cmp    eax,0x3fc
    14ae:	ja     0x4f2f
    14b4:	mulpd  xmm0,xmm1
    14b8:	movdqa xmm4,xmm0
    14bc:	movdqa xmm0,xmm4
    14c0:	movdqu XMMWORD PTR [r12+0x180],xmm0
    14ca:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    14d4:	movdqa xmm2,xmm0
    14d8:	movdqa xmm1,xmm2
    14dc:	por    xmm2,xmm1
    14e0:	movdqa xmm0,xmm2
    14e4:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    14ee:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    14f8:	movdqa xmm2,xmm0
    14fc:	movdqa xmm3,xmm2
    1500:	movdqa xmm1,xmm2
    1504:	por    xmm3,xmm1
    1508:	movdqa xmm0,xmm3
    150c:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    1516:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    1520:	movdqa xmm3,xmm0
    1524:	movdqa xmm0,xmm2
    1528:	movdqa xmm1,xmm3
    152c:	pshufd xmm1,xmm1,0x44
    1531:	movq   rax,xmm0
    1536:	add    rax,rax
    1539:	je     0x154f
    153b:	shr    rax,0x35
    153f:	sub    eax,0x201
    1544:	cmp    eax,0x3fc
    1549:	ja     0x4f53
    154f:	movdqa xmm14,xmm0
    1554:	psrldq xmm14,0x8
    155a:	movq   rax,xmm14
    155f:	add    rax,rax
    1562:	je     0x1578
    1564:	shr    rax,0x35
    1568:	sub    eax,0x201
    156d:	cmp    eax,0x3fc
    1572:	ja     0x4f53
    1578:	movq   rax,xmm1
    157d:	add    rax,rax
    1580:	je     0x1596
    1582:	shr    rax,0x35
    1586:	sub    eax,0x201
    158b:	cmp    eax,0x3fc
    1590:	ja     0x4f53
    1596:	movdqa xmm14,xmm1
    159b:	psrldq xmm14,0x8
    15a1:	movq   rax,xmm14
    15a6:	add    rax,rax
    15a9:	je     0x15bf
    15ab:	shr    rax,0x35
    15af:	sub    eax,0x201
    15b4:	cmp    eax,0x3fc
    15b9:	ja     0x4f53
    15bf:	mulpd  xmm0,xmm1
    15c3:	movdqa xmm4,xmm0
    15c7:	movdqa xmm0,xmm4
    15cb:	movdqu XMMWORD PTR [r12+0x250],xmm0
    15d5:	mov    r13,QWORD PTR [r12+0x58]
    15da:	stmxcsr DWORD PTR [rsp+0x114]
    15e2:	ldmxcsr DWORD PTR [rsp+0x110]
    15ea:	mov    r11d,DWORD PTR [rsp+0x114]
    15f2:	shr    r11d,1
    15f5:	and    r11d,0x10
    15f9:	or     DWORD PTR [r12+0x314],r11d
    1601:	sub    r13,0x200
    1608:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    1612:	movdqa xmm2,xmm0
    1616:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    1620:	movdqa xmm3,xmm0
    1624:	pushf
    1625:	pop    r11
    1627:	mov    QWORD PTR [rsp],r11
    162b:	stmxcsr DWORD PTR [rsp+0x110]
    1633:	mov    DWORD PTR [rsp+0x114],0x1f80
    163e:	ldmxcsr DWORD PTR [rsp+0x114]
    1646:	movdqa xmm0,xmm2
    164a:	movdqa xmm1,xmm3
    164e:	movq   rax,xmm0
    1653:	add    rax,rax
    1656:	je     0x166c
    1658:	shr    rax,0x35
    165c:	sub    eax,0x201
    1661:	cmp    eax,0x3fc
    1666:	ja     0x4f77
    166c:	movdqa xmm14,xmm0
    1671:	psrldq xmm14,0x8
    1677:	movq   rax,xmm14
    167c:	add    rax,rax
    167f:	je     0x1695
    1681:	shr    rax,0x35
    1685:	sub    eax,0x201
    168a:	cmp    eax,0x3fc
    168f:	ja     0x4f77
    1695:	movq   rax,xmm1
    169a:	add    rax,rax
    169d:	je     0x16b3
    169f:	shr    rax,0x35
    16a3:	sub    eax,0x201
    16a8:	cmp    eax,0x3fc
    16ad:	ja     0x4f77
    16b3:	movdqa xmm14,xmm1
    16b8:	psrldq xmm14,0x8
    16be:	movq   rax,xmm14
    16c3:	add    rax,rax
    16c6:	je     0x16dc
    16c8:	shr    rax,0x35
    16cc:	sub    eax,0x201
    16d1:	cmp    eax,0x3fc
    16d6:	ja     0x4f77
    16dc:	addpd  xmm0,xmm1
    16e0:	movdqa xmm4,xmm0
    16e4:	movdqa xmm0,xmm4
    16e8:	movdqu XMMWORD PTR [r12+0x240],xmm0
    16f2:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    16fc:	movdqa xmm2,xmm0
    1700:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    170a:	movdqa xmm3,xmm0
    170e:	movdqa xmm0,xmm2
    1712:	movdqa xmm1,xmm3
    1716:	movq   rax,xmm0
    171b:	add    rax,rax
    171e:	je     0x1734
    1720:	shr    rax,0x35
    1724:	sub    eax,0x201
    1729:	cmp    eax,0x3fc
    172e:	ja     0x4f9b
    1734:	movdqa xmm14,xmm0
    1739:	psrldq xmm14,0x8
    173f:	movq   rax,xmm14
    1744:	add    rax,rax
    1747:	je     0x175d
    1749:	shr    rax,0x35
    174d:	sub    eax,0x201
    1752:	cmp    eax,0x3fc
    1757:	ja     0x4f9b
    175d:	movq   rax,xmm1
    1762:	add    rax,rax
    1765:	je     0x177b
    1767:	shr    rax,0x35
    176b:	sub    eax,0x201
    1770:	cmp    eax,0x3fc
    1775:	ja     0x4f9b
    177b:	movdqa xmm14,xmm1
    1780:	psrldq xmm14,0x8
    1786:	movq   rax,xmm14
    178b:	add    rax,rax
    178e:	je     0x17a4
    1790:	shr    rax,0x35
    1794:	sub    eax,0x201
    1799:	cmp    eax,0x3fc
    179e:	ja     0x4f9b
    17a4:	addpd  xmm0,xmm1
    17a8:	movdqa xmm4,xmm0
    17ac:	movdqa xmm0,xmm4
    17b0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    17ba:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    17c4:	movdqa xmm2,xmm0
    17c8:	movdqa xmm0,xmm2
    17cc:	movdqa xmm1,xmm3
    17d0:	movq   rax,xmm0
    17d5:	add    rax,rax
    17d8:	je     0x17ee
    17da:	shr    rax,0x35
    17de:	sub    eax,0x201
    17e3:	cmp    eax,0x3fc
    17e8:	ja     0x4fbf
    17ee:	movdqa xmm14,xmm0
    17f3:	psrldq xmm14,0x8
    17f9:	movq   rax,xmm14
    17fe:	add    rax,rax
    1801:	je     0x1817
    1803:	shr    rax,0x35
    1807:	sub    eax,0x201
    180c:	cmp    eax,0x3fc
    1811:	ja     0x4fbf
    1817:	movq   rax,xmm1
    181c:	add    rax,rax
    181f:	je     0x1835
    1821:	shr    rax,0x35
    1825:	sub    eax,0x201
    182a:	cmp    eax,0x3fc
    182f:	ja     0x4fbf
    1835:	movdqa xmm14,xmm1
    183a:	psrldq xmm14,0x8
    1840:	movq   rax,xmm14
    1845:	add    rax,rax
    1848:	je     0x185e
    184a:	shr    rax,0x35
    184e:	sub    eax,0x201
    1853:	cmp    eax,0x3fc
    1858:	ja     0x4fbf
    185e:	addpd  xmm0,xmm1
    1862:	movdqa xmm4,xmm0
    1866:	movdqa xmm0,xmm4
    186a:	movdqu XMMWORD PTR [r12+0x220],xmm0
    1874:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    187e:	movdqa xmm2,xmm0
    1882:	movdqa xmm1,xmm2
    1886:	por    xmm2,xmm1
    188a:	movdqa xmm0,xmm2
    188e:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    1898:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    18a2:	movdqa xmm2,xmm0
    18a6:	movdqa xmm1,xmm2
    18aa:	por    xmm2,xmm1
    18ae:	movdqa xmm0,xmm2
    18b2:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    18bc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    18c6:	movdqa xmm2,xmm0
    18ca:	movdqa xmm1,xmm2
    18ce:	por    xmm2,xmm1
    18d2:	movdqa xmm0,xmm2
    18d6:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    18e0:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    18ea:	movdqa xmm2,xmm0
    18ee:	movdqa xmm1,xmm2
    18f2:	por    xmm2,xmm1
    18f6:	movdqa xmm0,xmm2
    18fa:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    1904:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    190e:	movdqa xmm2,xmm0
    1912:	movdqa xmm1,xmm2
    1916:	por    xmm2,xmm1
    191a:	movdqa xmm0,xmm2
    191e:	movdqu XMMWORD PTR [r12+0x200],xmm0
    1928:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    1932:	movdqa xmm2,xmm0
    1936:	movdqa xmm1,xmm2
    193a:	por    xmm2,xmm1
    193e:	movdqa xmm0,xmm2
    1942:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    194c:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    1956:	movdqa xmm2,xmm0
    195a:	movdqa xmm1,xmm2
    195e:	por    xmm2,xmm1
    1962:	movdqa xmm0,xmm2
    1966:	movdqu XMMWORD PTR [r12+0x190],xmm0
    1970:	mov    r13,QWORD PTR [r12+0xf8]
    1978:	mov    r14,r13
    197b:	add    r14,0xa0
    1982:	mov    r15,r14
    1985:	add    r15,0x10
    1989:	stmxcsr DWORD PTR [rsp+0x114]
    1991:	ldmxcsr DWORD PTR [rsp+0x110]
    1999:	mov    r11d,DWORD PTR [rsp+0x114]
    19a1:	shr    r11d,1
    19a4:	and    r11d,0x10
    19a8:	or     DWORD PTR [r12+0x314],r11d
    19b0:	movdqu xmm2,XMMWORD PTR [r14]
    19b5:	movdqu xmm3,XMMWORD PTR [r15]
    19ba:	movdqa xmm0,xmm2
    19be:	movdqu XMMWORD PTR [r12+0x300],xmm0
    19c8:	movdqa xmm0,xmm3
    19cc:	movdqu XMMWORD PTR [r12+0x270],xmm0
    19d6:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    19e0:	movdqa xmm2,xmm0
    19e4:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    19ee:	movdqa xmm4,xmm0
    19f2:	stmxcsr DWORD PTR [rsp+0x110]
    19fa:	mov    DWORD PTR [rsp+0x114],0x1f80
    1a05:	ldmxcsr DWORD PTR [rsp+0x114]
    1a0d:	movdqa xmm0,xmm2
    1a11:	movdqa xmm1,xmm4
    1a15:	movq   rax,xmm0
    1a1a:	add    rax,rax
    1a1d:	je     0x1a33
    1a1f:	shr    rax,0x35
    1a23:	sub    eax,0x201
    1a28:	cmp    eax,0x3fc
    1a2d:	ja     0x4fe3
    1a33:	movdqa xmm14,xmm0
    1a38:	psrldq xmm14,0x8
    1a3e:	movq   rax,xmm14
    1a43:	add    rax,rax
    1a46:	je     0x1a5c
    1a48:	shr    rax,0x35
    1a4c:	sub    eax,0x201
    1a51:	cmp    eax,0x3fc
    1a56:	ja     0x4fe3
    1a5c:	movq   rax,xmm1
    1a61:	add    rax,rax
    1a64:	je     0x1a7a
    1a66:	shr    rax,0x35
    1a6a:	sub    eax,0x201
    1a6f:	cmp    eax,0x3fc
    1a74:	ja     0x4fe3
    1a7a:	movdqa xmm14,xmm1
    1a7f:	psrldq xmm14,0x8
    1a85:	movq   rax,xmm14
    1a8a:	add    rax,rax
    1a8d:	je     0x1aa3
    1a8f:	shr    rax,0x35
    1a93:	sub    eax,0x201
    1a98:	cmp    eax,0x3fc
    1a9d:	ja     0x4fe3
    1aa3:	addpd  xmm0,xmm1
    1aa7:	movdqa xmm5,xmm0
    1aab:	movdqa xmm0,xmm5
    1aaf:	movdqu XMMWORD PTR [r12+0x180],xmm0
    1ab9:	add    r13,0xf0
    1ac0:	stmxcsr DWORD PTR [rsp+0x114]
    1ac8:	ldmxcsr DWORD PTR [rsp+0x110]
    1ad0:	mov    r11d,DWORD PTR [rsp+0x114]
    1ad8:	shr    r11d,1
    1adb:	and    r11d,0x10
    1adf:	or     DWORD PTR [r12+0x314],r11d
    1ae7:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    1aed:	movdqa xmm0,xmm2
    1af1:	movdqu XMMWORD PTR [r12+0x110],xmm0
    1afb:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    1b05:	movdqa xmm4,xmm0
    1b09:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    1b13:	movdqa xmm5,xmm0
    1b17:	stmxcsr DWORD PTR [rsp+0x110]
    1b1f:	mov    DWORD PTR [rsp+0x114],0x1f80
    1b2a:	ldmxcsr DWORD PTR [rsp+0x114]
    1b32:	movdqa xmm0,xmm4
    1b36:	movdqa xmm1,xmm5
    1b3a:	movq   rax,xmm0
    1b3f:	add    rax,rax
    1b42:	je     0x1b58
    1b44:	shr    rax,0x35
    1b48:	sub    eax,0x201
    1b4d:	cmp    eax,0x3fc
    1b52:	ja     0x5007
    1b58:	movdqa xmm14,xmm0
    1b5d:	psrldq xmm14,0x8
    1b63:	movq   rax,xmm14
    1b68:	add    rax,rax
    1b6b:	je     0x1b81
    1b6d:	shr    rax,0x35
    1b71:	sub    eax,0x201
    1b76:	cmp    eax,0x3fc
    1b7b:	ja     0x5007
    1b81:	movq   rax,xmm1
    1b86:	add    rax,rax
    1b89:	je     0x1b9f
    1b8b:	shr    rax,0x35
    1b8f:	sub    eax,0x201
    1b94:	cmp    eax,0x3fc
    1b99:	ja     0x5007
    1b9f:	movdqa xmm14,xmm1
    1ba4:	psrldq xmm14,0x8
    1baa:	movq   rax,xmm14
    1baf:	add    rax,rax
    1bb2:	je     0x1bc8
    1bb4:	shr    rax,0x35
    1bb8:	sub    eax,0x201
    1bbd:	cmp    eax,0x3fc
    1bc2:	ja     0x5007
    1bc8:	addpd  xmm0,xmm1
    1bcc:	movdqa xmm6,xmm0
    1bd0:	movdqa xmm0,xmm6
    1bd4:	movdqu XMMWORD PTR [r12+0x210],xmm0
    1bde:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    1be8:	movdqa xmm4,xmm0
    1bec:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    1bf6:	movdqa xmm5,xmm0
    1bfa:	movdqa xmm0,xmm4
    1bfe:	movdqa xmm1,xmm5
    1c02:	movq   rax,xmm0
    1c07:	add    rax,rax
    1c0a:	je     0x1c20
    1c0c:	shr    rax,0x35
    1c10:	sub    eax,0x201
    1c15:	cmp    eax,0x3fc
    1c1a:	ja     0x502b
    1c20:	movdqa xmm14,xmm0
    1c25:	psrldq xmm14,0x8
    1c2b:	movq   rax,xmm14
    1c30:	add    rax,rax
    1c33:	je     0x1c49
    1c35:	shr    rax,0x35
    1c39:	sub    eax,0x201
    1c3e:	cmp    eax,0x3fc
    1c43:	ja     0x502b
    1c49:	movq   rax,xmm1
    1c4e:	add    rax,rax
    1c51:	je     0x1c67
    1c53:	shr    rax,0x35
    1c57:	sub    eax,0x201
    1c5c:	cmp    eax,0x3fc
    1c61:	ja     0x502b
    1c67:	movdqa xmm14,xmm1
    1c6c:	psrldq xmm14,0x8
    1c72:	movq   rax,xmm14
    1c77:	add    rax,rax
    1c7a:	je     0x1c90
    1c7c:	shr    rax,0x35
    1c80:	sub    eax,0x201
    1c85:	cmp    eax,0x3fc
    1c8a:	ja     0x502b
    1c90:	addpd  xmm0,xmm1
    1c94:	movdqa xmm6,xmm0
    1c98:	movdqa xmm0,xmm6
    1c9c:	movdqu XMMWORD PTR [r12+0x220],xmm0
    1ca6:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    1cb0:	movdqa xmm4,xmm0
    1cb4:	movdqa xmm0,xmm3
    1cb8:	movdqa xmm1,xmm4
    1cbc:	pshufd xmm1,xmm1,0x44
    1cc1:	movq   rax,xmm0
    1cc6:	add    rax,rax
    1cc9:	je     0x1cdf
    1ccb:	shr    rax,0x35
    1ccf:	sub    eax,0x201
    1cd4:	cmp    eax,0x3fc
    1cd9:	ja     0x504f
    1cdf:	movdqa xmm14,xmm0
    1ce4:	psrldq xmm14,0x8
    1cea:	movq   rax,xmm14
    1cef:	add    rax,rax
    1cf2:	je     0x1d08
    1cf4:	shr    rax,0x35
    1cf8:	sub    eax,0x201
    1cfd:	cmp    eax,0x3fc
    1d02:	ja     0x504f
    1d08:	movq   rax,xmm1
    1d0d:	add    rax,rax
    1d10:	je     0x1d26
    1d12:	shr    rax,0x35
    1d16:	sub    eax,0x201
    1d1b:	cmp    eax,0x3fc
    1d20:	ja     0x504f
    1d26:	movdqa xmm14,xmm1
    1d2b:	psrldq xmm14,0x8
    1d31:	movq   rax,xmm14
    1d36:	add    rax,rax
    1d39:	je     0x1d4f
    1d3b:	shr    rax,0x35
    1d3f:	sub    eax,0x201
    1d44:	cmp    eax,0x3fc
    1d49:	ja     0x504f
    1d4f:	mulpd  xmm0,xmm1
    1d53:	movdqa xmm5,xmm0
    1d57:	movdqa xmm0,xmm5
    1d5b:	movdqu XMMWORD PTR [r12+0x270],xmm0
    1d65:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    1d6f:	movdqa xmm3,xmm0
    1d73:	movdqa xmm0,xmm2
    1d77:	movdqa xmm1,xmm3
    1d7b:	pshufd xmm1,xmm1,0x44
    1d80:	movq   rax,xmm0
    1d85:	add    rax,rax
    1d88:	je     0x1d9e
    1d8a:	shr    rax,0x35
    1d8e:	sub    eax,0x201
    1d93:	cmp    eax,0x3fc
    1d98:	ja     0x5073
    1d9e:	movdqa xmm14,xmm0
    1da3:	psrldq xmm14,0x8
    1da9:	movq   rax,xmm14
    1dae:	add    rax,rax
    1db1:	je     0x1dc7
    1db3:	shr    rax,0x35
    1db7:	sub    eax,0x201
    1dbc:	cmp    eax,0x3fc
    1dc1:	ja     0x5073
    1dc7:	movq   rax,xmm1
    1dcc:	add    rax,rax
    1dcf:	je     0x1de5
    1dd1:	shr    rax,0x35
    1dd5:	sub    eax,0x201
    1dda:	cmp    eax,0x3fc
    1ddf:	ja     0x5073
    1de5:	movdqa xmm14,xmm1
    1dea:	psrldq xmm14,0x8
    1df0:	movq   rax,xmm14
    1df5:	add    rax,rax
    1df8:	je     0x1e0e
    1dfa:	shr    rax,0x35
    1dfe:	sub    eax,0x201
    1e03:	cmp    eax,0x3fc
    1e08:	ja     0x5073
    1e0e:	mulpd  xmm0,xmm1
    1e12:	movdqa xmm5,xmm0
    1e16:	movdqa xmm0,xmm5
    1e1a:	movdqu XMMWORD PTR [r12+0x250],xmm0
    1e24:	mov    r13,QWORD PTR [r12+0xf8]
    1e2c:	mov    r14,r13
    1e2f:	add    r14,0xe0
    1e36:	stmxcsr DWORD PTR [rsp+0x114]
    1e3e:	ldmxcsr DWORD PTR [rsp+0x110]
    1e46:	mov    r11d,DWORD PTR [rsp+0x114]
    1e4e:	shr    r11d,1
    1e51:	and    r11d,0x10
    1e55:	or     DWORD PTR [r12+0x314],r11d
    1e5d:	movdqu xmm2,XMMWORD PTR [r14]
    1e62:	movdqa xmm0,xmm2
    1e66:	movdqu XMMWORD PTR [r12+0x110],xmm0
    1e70:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    1e7a:	movdqa xmm2,xmm0
    1e7e:	stmxcsr DWORD PTR [rsp+0x110]
    1e86:	mov    DWORD PTR [rsp+0x114],0x1f80
    1e91:	ldmxcsr DWORD PTR [rsp+0x114]
    1e99:	movdqa xmm0,xmm2
    1e9d:	movdqa xmm1,xmm4
    1ea1:	pshufd xmm1,xmm1,0x44
    1ea6:	movq   rax,xmm0
    1eab:	add    rax,rax
    1eae:	je     0x1ec4
    1eb0:	shr    rax,0x35
    1eb4:	sub    eax,0x201
    1eb9:	cmp    eax,0x3fc
    1ebe:	ja     0x5097
    1ec4:	movdqa xmm14,xmm0
    1ec9:	psrldq xmm14,0x8
    1ecf:	movq   rax,xmm14
    1ed4:	add    rax,rax
    1ed7:	je     0x1eed
    1ed9:	shr    rax,0x35
    1edd:	sub    eax,0x201
    1ee2:	cmp    eax,0x3fc
    1ee7:	ja     0x5097
    1eed:	movq   rax,xmm1
    1ef2:	add    rax,rax
    1ef5:	je     0x1f0b
    1ef7:	shr    rax,0x35
    1efb:	sub    eax,0x201
    1f00:	cmp    eax,0x3fc
    1f05:	ja     0x5097
    1f0b:	movdqa xmm14,xmm1
    1f10:	psrldq xmm14,0x8
    1f16:	movq   rax,xmm14
    1f1b:	add    rax,rax
    1f1e:	je     0x1f34
    1f20:	shr    rax,0x35
    1f24:	sub    eax,0x201
    1f29:	cmp    eax,0x3fc
    1f2e:	ja     0x5097
    1f34:	mulpd  xmm0,xmm1
    1f38:	movdqa xmm5,xmm0
    1f3c:	movdqa xmm0,xmm5
    1f40:	movdqu XMMWORD PTR [r12+0x230],xmm0
    1f4a:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    1f54:	movdqa xmm2,xmm0
    1f58:	movdqa xmm1,xmm2
    1f5c:	por    xmm2,xmm1
    1f60:	movdqa xmm0,xmm2
    1f64:	movdqu XMMWORD PTR [r12+0x300],xmm0
    1f6e:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    1f78:	movdqa xmm2,xmm0
    1f7c:	movdqa xmm1,xmm2
    1f80:	por    xmm2,xmm1
    1f84:	movdqa xmm0,xmm2
    1f88:	movdqu XMMWORD PTR [r12+0x190],xmm0
    1f92:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    1f9c:	movdqa xmm2,xmm0
    1fa0:	movdqa xmm0,xmm2
    1fa4:	movdqa xmm1,xmm3
    1fa8:	pshufd xmm1,xmm1,0x44
    1fad:	movq   rax,xmm0
    1fb2:	add    rax,rax
    1fb5:	je     0x1fcb
    1fb7:	shr    rax,0x35
    1fbb:	sub    eax,0x201
    1fc0:	cmp    eax,0x3fc
    1fc5:	ja     0x50bb
    1fcb:	movdqa xmm14,xmm0
    1fd0:	psrldq xmm14,0x8
    1fd6:	movq   rax,xmm14
    1fdb:	add    rax,rax
    1fde:	je     0x1ff4
    1fe0:	shr    rax,0x35
    1fe4:	sub    eax,0x201
    1fe9:	cmp    eax,0x3fc
    1fee:	ja     0x50bb
    1ff4:	movq   rax,xmm1
    1ff9:	add    rax,rax
    1ffc:	je     0x2012
    1ffe:	shr    rax,0x35
    2002:	sub    eax,0x201
    2007:	cmp    eax,0x3fc
    200c:	ja     0x50bb
    2012:	movdqa xmm14,xmm1
    2017:	psrldq xmm14,0x8
    201d:	movq   rax,xmm14
    2022:	add    rax,rax
    2025:	je     0x203b
    2027:	shr    rax,0x35
    202b:	sub    eax,0x201
    2030:	cmp    eax,0x3fc
    2035:	ja     0x50bb
    203b:	mulpd  xmm0,xmm1
    203f:	movdqa xmm4,xmm0
    2043:	movdqa xmm0,xmm4
    2047:	movdqu XMMWORD PTR [r12+0x260],xmm0
    2051:	add    r13,0x90
    2058:	stmxcsr DWORD PTR [rsp+0x114]
    2060:	ldmxcsr DWORD PTR [rsp+0x110]
    2068:	mov    r11d,DWORD PTR [rsp+0x114]
    2070:	shr    r11d,1
    2073:	and    r11d,0x10
    2077:	or     DWORD PTR [r12+0x314],r11d
    207f:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    2085:	movdqa xmm0,xmm2
    2089:	movdqu XMMWORD PTR [r12+0x110],xmm0
    2093:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    209d:	movdqa xmm3,xmm0
    20a1:	movdqa xmm1,xmm3
    20a5:	por    xmm3,xmm1
    20a9:	movdqa xmm0,xmm3
    20ad:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    20b7:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    20c1:	movdqa xmm3,xmm0
    20c5:	movdqa xmm1,xmm3
    20c9:	por    xmm3,xmm1
    20cd:	movdqa xmm0,xmm3
    20d1:	movdqu XMMWORD PTR [r12+0x200],xmm0
    20db:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    20e5:	movdqa xmm3,xmm0
    20e9:	movdqa xmm1,xmm3
    20ed:	por    xmm3,xmm1
    20f1:	movdqa xmm0,xmm3
    20f5:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    20ff:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    2109:	movdqa xmm3,xmm0
    210d:	movdqa xmm1,xmm3
    2111:	por    xmm3,xmm1
    2115:	movdqa xmm0,xmm3
    2119:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    2123:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    212d:	movdqa xmm3,xmm0
    2131:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    213b:	movdqa xmm4,xmm0
    213f:	stmxcsr DWORD PTR [rsp+0x110]
    2147:	mov    DWORD PTR [rsp+0x114],0x1f80
    2152:	ldmxcsr DWORD PTR [rsp+0x114]
    215a:	movdqa xmm0,xmm3
    215e:	movdqa xmm1,xmm4
    2162:	movq   rax,xmm0
    2167:	add    rax,rax
    216a:	je     0x2180
    216c:	shr    rax,0x35
    2170:	sub    eax,0x201
    2175:	cmp    eax,0x3fc
    217a:	ja     0x50df
    2180:	movdqa xmm14,xmm0
    2185:	psrldq xmm14,0x8
    218b:	movq   rax,xmm14
    2190:	add    rax,rax
    2193:	je     0x21a9
    2195:	shr    rax,0x35
    2199:	sub    eax,0x201
    219e:	cmp    eax,0x3fc
    21a3:	ja     0x50df
    21a9:	movq   rax,xmm1
    21ae:	add    rax,rax
    21b1:	je     0x21c7
    21b3:	shr    rax,0x35
    21b7:	sub    eax,0x201
    21bc:	cmp    eax,0x3fc
    21c1:	ja     0x50df
    21c7:	movdqa xmm14,xmm1
    21cc:	psrldq xmm14,0x8
    21d2:	movq   rax,xmm14
    21d7:	add    rax,rax
    21da:	je     0x21f0
    21dc:	shr    rax,0x35
    21e0:	sub    eax,0x201
    21e5:	cmp    eax,0x3fc
    21ea:	ja     0x50df
    21f0:	addpd  xmm0,xmm1
    21f4:	movdqa xmm5,xmm0
    21f8:	movdqa xmm0,xmm5
    21fc:	movdqu XMMWORD PTR [r12+0x240],xmm0
    2206:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    2210:	movdqa xmm3,xmm0
    2214:	movdqa xmm0,xmm2
    2218:	movdqa xmm1,xmm3
    221c:	pshufd xmm1,xmm1,0x44
    2221:	movq   rax,xmm0
    2226:	add    rax,rax
    2229:	je     0x223f
    222b:	shr    rax,0x35
    222f:	sub    eax,0x201
    2234:	cmp    eax,0x3fc
    2239:	ja     0x5103
    223f:	movdqa xmm14,xmm0
    2244:	psrldq xmm14,0x8
    224a:	movq   rax,xmm14
    224f:	add    rax,rax
    2252:	je     0x2268
    2254:	shr    rax,0x35
    2258:	sub    eax,0x201
    225d:	cmp    eax,0x3fc
    2262:	ja     0x5103
    2268:	movq   rax,xmm1
    226d:	add    rax,rax
    2270:	je     0x2286
    2272:	shr    rax,0x35
    2276:	sub    eax,0x201
    227b:	cmp    eax,0x3fc
    2280:	ja     0x5103
    2286:	movdqa xmm14,xmm1
    228b:	psrldq xmm14,0x8
    2291:	movq   rax,xmm14
    2296:	add    rax,rax
    2299:	je     0x22af
    229b:	shr    rax,0x35
    229f:	sub    eax,0x201
    22a4:	cmp    eax,0x3fc
    22a9:	ja     0x5103
    22af:	mulpd  xmm0,xmm1
    22b3:	movdqa xmm4,xmm0
    22b7:	movdqa xmm0,xmm4
    22bb:	movdqu XMMWORD PTR [r12+0x270],xmm0
    22c5:	mov    r13,QWORD PTR [r12+0xf8]
    22cd:	add    r13,0x80
    22d4:	stmxcsr DWORD PTR [rsp+0x114]
    22dc:	ldmxcsr DWORD PTR [rsp+0x110]
    22e4:	mov    r11d,DWORD PTR [rsp+0x114]
    22ec:	shr    r11d,1
    22ef:	and    r11d,0x10
    22f3:	or     DWORD PTR [r12+0x314],r11d
    22fb:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    2301:	movdqa xmm0,xmm2
    2305:	movdqu XMMWORD PTR [r12+0x110],xmm0
    230f:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    2319:	movdqa xmm3,xmm0
    231d:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    2327:	movdqa xmm4,xmm0
    232b:	stmxcsr DWORD PTR [rsp+0x110]
    2333:	mov    DWORD PTR [rsp+0x114],0x1f80
    233e:	ldmxcsr DWORD PTR [rsp+0x114]
    2346:	movdqa xmm0,xmm3
    234a:	movdqa xmm1,xmm4
    234e:	movq   rax,xmm0
    2353:	add    rax,rax
    2356:	je     0x236c
    2358:	shr    rax,0x35
    235c:	sub    eax,0x201
    2361:	cmp    eax,0x3fc
    2366:	ja     0x5127
    236c:	movdqa xmm14,xmm0
    2371:	psrldq xmm14,0x8
    2377:	movq   rax,xmm14
    237c:	add    rax,rax
    237f:	je     0x2395
    2381:	shr    rax,0x35
    2385:	sub    eax,0x201
    238a:	cmp    eax,0x3fc
    238f:	ja     0x5127
    2395:	movq   rax,xmm1
    239a:	add    rax,rax
    239d:	je     0x23b3
    239f:	shr    rax,0x35
    23a3:	sub    eax,0x201
    23a8:	cmp    eax,0x3fc
    23ad:	ja     0x5127
    23b3:	movdqa xmm14,xmm1
    23b8:	psrldq xmm14,0x8
    23be:	movq   rax,xmm14
    23c3:	add    rax,rax
    23c6:	je     0x23dc
    23c8:	shr    rax,0x35
    23cc:	sub    eax,0x201
    23d1:	cmp    eax,0x3fc
    23d6:	ja     0x5127
    23dc:	addpd  xmm0,xmm1
    23e0:	movdqa xmm5,xmm0
    23e4:	movdqa xmm0,xmm5
    23e8:	movdqu XMMWORD PTR [r12+0x180],xmm0
    23f2:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    23fc:	movdqa xmm3,xmm0
    2400:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    240a:	movdqa xmm4,xmm0
    240e:	movdqa xmm0,xmm3
    2412:	movdqa xmm1,xmm4
    2416:	movq   rax,xmm0
    241b:	add    rax,rax
    241e:	je     0x2434
    2420:	shr    rax,0x35
    2424:	sub    eax,0x201
    2429:	cmp    eax,0x3fc
    242e:	ja     0x514b
    2434:	movdqa xmm14,xmm0
    2439:	psrldq xmm14,0x8
    243f:	movq   rax,xmm14
    2444:	add    rax,rax
    2447:	je     0x245d
    2449:	shr    rax,0x35
    244d:	sub    eax,0x201
    2452:	cmp    eax,0x3fc
    2457:	ja     0x514b
    245d:	movq   rax,xmm1
    2462:	add    rax,rax
    2465:	je     0x247b
    2467:	shr    rax,0x35
    246b:	sub    eax,0x201
    2470:	cmp    eax,0x3fc
    2475:	ja     0x514b
    247b:	movdqa xmm14,xmm1
    2480:	psrldq xmm14,0x8
    2486:	movq   rax,xmm14
    248b:	add    rax,rax
    248e:	je     0x24a4
    2490:	shr    rax,0x35
    2494:	sub    eax,0x201
    2499:	cmp    eax,0x3fc
    249e:	ja     0x514b
    24a4:	addpd  xmm0,xmm1
    24a8:	movdqa xmm5,xmm0
    24ac:	movdqa xmm0,xmm5
    24b0:	movdqu XMMWORD PTR [r12+0x210],xmm0
    24ba:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    24c4:	movdqa xmm3,xmm0
    24c8:	movdqa xmm1,xmm3
    24cc:	por    xmm3,xmm1
    24d0:	movdqa xmm0,xmm3
    24d4:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    24de:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    24e8:	movdqa xmm3,xmm0
    24ec:	movdqa xmm0,xmm2
    24f0:	movdqa xmm1,xmm3
    24f4:	pshufd xmm1,xmm1,0x44
    24f9:	movq   rax,xmm0
    24fe:	add    rax,rax
    2501:	je     0x2517
    2503:	shr    rax,0x35
    2507:	sub    eax,0x201
    250c:	cmp    eax,0x3fc
    2511:	ja     0x516f
    2517:	movdqa xmm14,xmm0
    251c:	psrldq xmm14,0x8
    2522:	movq   rax,xmm14
    2527:	add    rax,rax
    252a:	je     0x2540
    252c:	shr    rax,0x35
    2530:	sub    eax,0x201
    2535:	cmp    eax,0x3fc
    253a:	ja     0x516f
    2540:	movq   rax,xmm1
    2545:	add    rax,rax
    2548:	je     0x255e
    254a:	shr    rax,0x35
    254e:	sub    eax,0x201
    2553:	cmp    eax,0x3fc
    2558:	ja     0x516f
    255e:	movdqa xmm14,xmm1
    2563:	psrldq xmm14,0x8
    2569:	movq   rax,xmm14
    256e:	add    rax,rax
    2571:	je     0x2587
    2573:	shr    rax,0x35
    2577:	sub    eax,0x201
    257c:	cmp    eax,0x3fc
    2581:	ja     0x516f
    2587:	mulpd  xmm0,xmm1
    258b:	movdqa xmm4,xmm0
    258f:	movdqa xmm0,xmm4
    2593:	movdqu XMMWORD PTR [r12+0x170],xmm0
    259d:	mov    r13,QWORD PTR [r12+0xf8]
    25a5:	add    r13,0xd0
    25ac:	stmxcsr DWORD PTR [rsp+0x114]
    25b4:	ldmxcsr DWORD PTR [rsp+0x110]
    25bc:	mov    r11d,DWORD PTR [rsp+0x114]
    25c4:	shr    r11d,1
    25c7:	and    r11d,0x10
    25cb:	or     DWORD PTR [r12+0x314],r11d
    25d3:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    25d9:	movdqa xmm0,xmm2
    25dd:	movdqu XMMWORD PTR [r12+0x110],xmm0
    25e7:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    25f1:	movdqa xmm3,xmm0
    25f5:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    25ff:	movdqa xmm4,xmm0
    2603:	stmxcsr DWORD PTR [rsp+0x110]
    260b:	mov    DWORD PTR [rsp+0x114],0x1f80
    2616:	ldmxcsr DWORD PTR [rsp+0x114]
    261e:	movdqa xmm0,xmm3
    2622:	movdqa xmm1,xmm4
    2626:	movq   rax,xmm0
    262b:	add    rax,rax
    262e:	je     0x2644
    2630:	shr    rax,0x35
    2634:	sub    eax,0x201
    2639:	cmp    eax,0x3fc
    263e:	ja     0x5193
    2644:	movdqa xmm14,xmm0
    2649:	psrldq xmm14,0x8
    264f:	movq   rax,xmm14
    2654:	add    rax,rax
    2657:	je     0x266d
    2659:	shr    rax,0x35
    265d:	sub    eax,0x201
    2662:	cmp    eax,0x3fc
    2667:	ja     0x5193
    266d:	movq   rax,xmm1
    2672:	add    rax,rax
    2675:	je     0x268b
    2677:	shr    rax,0x35
    267b:	sub    eax,0x201
    2680:	cmp    eax,0x3fc
    2685:	ja     0x5193
    268b:	movdqa xmm14,xmm1
    2690:	psrldq xmm14,0x8
    2696:	movq   rax,xmm14
    269b:	add    rax,rax
    269e:	je     0x26b4
    26a0:	shr    rax,0x35
    26a4:	sub    eax,0x201
    26a9:	cmp    eax,0x3fc
    26ae:	ja     0x5193
    26b4:	addpd  xmm0,xmm1
    26b8:	movdqa xmm5,xmm0
    26bc:	movdqa xmm0,xmm5
    26c0:	movdqu XMMWORD PTR [r12+0x220],xmm0
    26ca:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    26d4:	movdqa xmm3,xmm0
    26d8:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    26e2:	movdqa xmm4,xmm0
    26e6:	movdqa xmm0,xmm3
    26ea:	movdqa xmm1,xmm4
    26ee:	pshufd xmm1,xmm1,0x44
    26f3:	movq   rax,xmm0
    26f8:	add    rax,rax
    26fb:	je     0x2711
    26fd:	shr    rax,0x35
    2701:	sub    eax,0x201
    2706:	cmp    eax,0x3fc
    270b:	ja     0x51b7
    2711:	movdqa xmm14,xmm0
    2716:	psrldq xmm14,0x8
    271c:	movq   rax,xmm14
    2721:	add    rax,rax
    2724:	je     0x273a
    2726:	shr    rax,0x35
    272a:	sub    eax,0x201
    272f:	cmp    eax,0x3fc
    2734:	ja     0x51b7
    273a:	movq   rax,xmm1
    273f:	add    rax,rax
    2742:	je     0x2758
    2744:	shr    rax,0x35
    2748:	sub    eax,0x201
    274d:	cmp    eax,0x3fc
    2752:	ja     0x51b7
    2758:	movdqa xmm14,xmm1
    275d:	psrldq xmm14,0x8
    2763:	movq   rax,xmm14
    2768:	add    rax,rax
    276b:	je     0x2781
    276d:	shr    rax,0x35
    2771:	sub    eax,0x201
    2776:	cmp    eax,0x3fc
    277b:	ja     0x51b7
    2781:	mulpd  xmm0,xmm1
    2785:	movdqa xmm5,xmm0
    2789:	movdqa xmm0,xmm5
    278d:	movdqu XMMWORD PTR [r12+0x260],xmm0
    2797:	mov    r13d,0x0
    279d:	mov    r14d,0x0
    27a3:	mov    QWORD PTR [r12+0x1b0],r13
    27ab:	mov    QWORD PTR [r12+0x1b8],r14
    27b3:	movdqa xmm0,xmm2
    27b7:	movdqa xmm1,xmm4
    27bb:	pshufd xmm1,xmm1,0x44
    27c0:	movq   rax,xmm0
    27c5:	add    rax,rax
    27c8:	je     0x27de
    27ca:	shr    rax,0x35
    27ce:	sub    eax,0x201
    27d3:	cmp    eax,0x3fc
    27d8:	ja     0x51db
    27de:	movdqa xmm14,xmm0
    27e3:	psrldq xmm14,0x8
    27e9:	movq   rax,xmm14
    27ee:	add    rax,rax
    27f1:	je     0x2807
    27f3:	shr    rax,0x35
    27f7:	sub    eax,0x201
    27fc:	cmp    eax,0x3fc
    2801:	ja     0x51db
    2807:	movq   rax,xmm1
    280c:	add    rax,rax
    280f:	je     0x2825
    2811:	shr    rax,0x35
    2815:	sub    eax,0x201
    281a:	cmp    eax,0x3fc
    281f:	ja     0x51db
    2825:	movdqa xmm14,xmm1
    282a:	psrldq xmm14,0x8
    2830:	movq   rax,xmm14
    2835:	add    rax,rax
    2838:	je     0x284e
    283a:	shr    rax,0x35
    283e:	sub    eax,0x201
    2843:	cmp    eax,0x3fc
    2848:	ja     0x51db
    284e:	mulpd  xmm0,xmm1
    2852:	movdqa xmm3,xmm0
    2856:	movdqa xmm0,xmm3
    285a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    2864:	mov    r13,QWORD PTR [r12+0xf8]
    286c:	mov    r14,r13
    286f:	add    r14,0xc0
    2876:	stmxcsr DWORD PTR [rsp+0x114]
    287e:	ldmxcsr DWORD PTR [rsp+0x110]
    2886:	mov    r11d,DWORD PTR [rsp+0x114]
    288e:	shr    r11d,1
    2891:	and    r11d,0x10
    2895:	or     DWORD PTR [r12+0x314],r11d
    289d:	movdqu xmm2,XMMWORD PTR [r14]
    28a2:	movdqa xmm0,xmm2
    28a6:	movdqu XMMWORD PTR [r12+0x110],xmm0
    28b0:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    28ba:	movdqa xmm3,xmm0
    28be:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    28c8:	movdqa xmm4,xmm0
    28cc:	stmxcsr DWORD PTR [rsp+0x110]
    28d4:	mov    DWORD PTR [rsp+0x114],0x1f80
    28df:	ldmxcsr DWORD PTR [rsp+0x114]
    28e7:	movdqa xmm0,xmm3
    28eb:	movdqa xmm1,xmm4
    28ef:	movq   rax,xmm0
    28f4:	add    rax,rax
    28f7:	je     0x290d
    28f9:	shr    rax,0x35
    28fd:	sub    eax,0x201
    2902:	cmp    eax,0x3fc
    2907:	ja     0x51ff
    290d:	movdqa xmm14,xmm0
    2912:	psrldq xmm14,0x8
    2918:	movq   rax,xmm14
    291d:	add    rax,rax
    2920:	je     0x2936
    2922:	shr    rax,0x35
    2926:	sub    eax,0x201
    292b:	cmp    eax,0x3fc
    2930:	ja     0x51ff
    2936:	movq   rax,xmm1
    293b:	add    rax,rax
    293e:	je     0x2954
    2940:	shr    rax,0x35
    2944:	sub    eax,0x201
    2949:	cmp    eax,0x3fc
    294e:	ja     0x51ff
    2954:	movdqa xmm14,xmm1
    2959:	psrldq xmm14,0x8
    295f:	movq   rax,xmm14
    2964:	add    rax,rax
    2967:	je     0x297d
    2969:	shr    rax,0x35
    296d:	sub    eax,0x201
    2972:	cmp    eax,0x3fc
    2977:	ja     0x51ff
    297d:	addpd  xmm0,xmm1
    2981:	movdqa xmm5,xmm0
    2985:	movdqa xmm0,xmm5
    2989:	movdqu XMMWORD PTR [r12+0x240],xmm0
    2993:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    299d:	movdqa xmm3,xmm0
    29a1:	movdqa xmm1,xmm3
    29a5:	por    xmm3,xmm1
    29a9:	movdqa xmm0,xmm3
    29ad:	movdqu XMMWORD PTR [r12+0x270],xmm0
    29b7:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    29c1:	movdqa xmm3,xmm0
    29c5:	movdqa xmm1,xmm3
    29c9:	por    xmm3,xmm1
    29cd:	movdqa xmm0,xmm3
    29d1:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    29db:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    29e5:	movdqa xmm3,xmm0
    29e9:	movdqa xmm0,xmm2
    29ed:	movdqa xmm1,xmm3
    29f1:	pshufd xmm1,xmm1,0x44
    29f6:	movq   rax,xmm0
    29fb:	add    rax,rax
    29fe:	je     0x2a14
    2a00:	shr    rax,0x35
    2a04:	sub    eax,0x201
    2a09:	cmp    eax,0x3fc
    2a0e:	ja     0x5223
    2a14:	movdqa xmm14,xmm0
    2a19:	psrldq xmm14,0x8
    2a1f:	movq   rax,xmm14
    2a24:	add    rax,rax
    2a27:	je     0x2a3d
    2a29:	shr    rax,0x35
    2a2d:	sub    eax,0x201
    2a32:	cmp    eax,0x3fc
    2a37:	ja     0x5223
    2a3d:	movq   rax,xmm1
    2a42:	add    rax,rax
    2a45:	je     0x2a5b
    2a47:	shr    rax,0x35
    2a4b:	sub    eax,0x201
    2a50:	cmp    eax,0x3fc
    2a55:	ja     0x5223
    2a5b:	movdqa xmm14,xmm1
    2a60:	psrldq xmm14,0x8
    2a66:	movq   rax,xmm14
    2a6b:	add    rax,rax
    2a6e:	je     0x2a84
    2a70:	shr    rax,0x35
    2a74:	sub    eax,0x201
    2a79:	cmp    eax,0x3fc
    2a7e:	ja     0x5223
    2a84:	mulpd  xmm0,xmm1
    2a88:	movdqa xmm4,xmm0
    2a8c:	movdqa xmm0,xmm4
    2a90:	movdqu XMMWORD PTR [r12+0x250],xmm0
    2a9a:	add    r13,0x20
    2a9e:	stmxcsr DWORD PTR [rsp+0x114]
    2aa6:	ldmxcsr DWORD PTR [rsp+0x110]
    2aae:	mov    r11d,DWORD PTR [rsp+0x114]
    2ab6:	shr    r11d,1
    2ab9:	and    r11d,0x10
    2abd:	or     DWORD PTR [r12+0x314],r11d
    2ac5:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    2acb:	movdqa xmm0,xmm2
    2acf:	movdqu XMMWORD PTR [r12+0x110],xmm0
    2ad9:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    2ae3:	movdqa xmm2,xmm0
    2ae7:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    2af1:	movdqa xmm4,xmm0
    2af5:	stmxcsr DWORD PTR [rsp+0x110]
    2afd:	mov    DWORD PTR [rsp+0x114],0x1f80
    2b08:	ldmxcsr DWORD PTR [rsp+0x114]
    2b10:	movdqa xmm0,xmm2
    2b14:	movdqa xmm1,xmm4
    2b18:	movq   rax,xmm0
    2b1d:	add    rax,rax
    2b20:	je     0x2b36
    2b22:	shr    rax,0x35
    2b26:	sub    eax,0x201
    2b2b:	cmp    eax,0x3fc
    2b30:	ja     0x5247
    2b36:	movdqa xmm14,xmm0
    2b3b:	psrldq xmm14,0x8
    2b41:	movq   rax,xmm14
    2b46:	add    rax,rax
    2b49:	je     0x2b5f
    2b4b:	shr    rax,0x35
    2b4f:	sub    eax,0x201
    2b54:	cmp    eax,0x3fc
    2b59:	ja     0x5247
    2b5f:	movq   rax,xmm1
    2b64:	add    rax,rax
    2b67:	je     0x2b7d
    2b69:	shr    rax,0x35
    2b6d:	sub    eax,0x201
    2b72:	cmp    eax,0x3fc
    2b77:	ja     0x5247
    2b7d:	movdqa xmm14,xmm1
    2b82:	psrldq xmm14,0x8
    2b88:	movq   rax,xmm14
    2b8d:	add    rax,rax
    2b90:	je     0x2ba6
    2b92:	shr    rax,0x35
    2b96:	sub    eax,0x201
    2b9b:	cmp    eax,0x3fc
    2ba0:	ja     0x5247
    2ba6:	addpd  xmm0,xmm1
    2baa:	movdqa xmm5,xmm0
    2bae:	movdqa xmm0,xmm5
    2bb2:	movdqu XMMWORD PTR [r12+0x170],xmm0
    2bbc:	movdqu xmm0,XMMWORD PTR [r12+0x2d0]
    2bc6:	movdqa xmm2,xmm0
    2bca:	movdqa xmm0,xmm2
    2bce:	movdqa xmm1,xmm3
    2bd2:	pshufd xmm1,xmm1,0x44
    2bd7:	movq   rax,xmm0
    2bdc:	add    rax,rax
    2bdf:	je     0x2bf5
    2be1:	shr    rax,0x35
    2be5:	sub    eax,0x201
    2bea:	cmp    eax,0x3fc
    2bef:	ja     0x526b
    2bf5:	movdqa xmm14,xmm0
    2bfa:	psrldq xmm14,0x8
    2c00:	movq   rax,xmm14
    2c05:	add    rax,rax
    2c08:	je     0x2c1e
    2c0a:	shr    rax,0x35
    2c0e:	sub    eax,0x201
    2c13:	cmp    eax,0x3fc
    2c18:	ja     0x526b
    2c1e:	movq   rax,xmm1
    2c23:	add    rax,rax
    2c26:	je     0x2c3c
    2c28:	shr    rax,0x35
    2c2c:	sub    eax,0x201
    2c31:	cmp    eax,0x3fc
    2c36:	ja     0x526b
    2c3c:	movdqa xmm14,xmm1
    2c41:	psrldq xmm14,0x8
    2c47:	movq   rax,xmm14
    2c4c:	add    rax,rax
    2c4f:	je     0x2c65
    2c51:	shr    rax,0x35
    2c55:	sub    eax,0x201
    2c5a:	cmp    eax,0x3fc
    2c5f:	ja     0x526b
    2c65:	mulpd  xmm0,xmm1
    2c69:	movdqa xmm4,xmm0
    2c6d:	movdqa xmm0,xmm4
    2c71:	movdqu XMMWORD PTR [r12+0x160],xmm0
    2c7b:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    2c85:	movdqa xmm2,xmm0
    2c89:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    2c93:	movdqa xmm3,xmm0
    2c97:	movdqa xmm0,xmm2
    2c9b:	movdqa xmm1,xmm3
    2c9f:	movq   rax,xmm0
    2ca4:	add    rax,rax
    2ca7:	je     0x2cbd
    2ca9:	shr    rax,0x35
    2cad:	sub    eax,0x201
    2cb2:	cmp    eax,0x3fc
    2cb7:	ja     0x528f
    2cbd:	movdqa xmm14,xmm0
    2cc2:	psrldq xmm14,0x8
    2cc8:	movq   rax,xmm14
    2ccd:	add    rax,rax
    2cd0:	je     0x2ce6
    2cd2:	shr    rax,0x35
    2cd6:	sub    eax,0x201
    2cdb:	cmp    eax,0x3fc
    2ce0:	ja     0x528f
    2ce6:	movq   rax,xmm1
    2ceb:	add    rax,rax
    2cee:	je     0x2d04
    2cf0:	shr    rax,0x35
    2cf4:	sub    eax,0x201
    2cf9:	cmp    eax,0x3fc
    2cfe:	ja     0x528f
    2d04:	movdqa xmm14,xmm1
    2d09:	psrldq xmm14,0x8
    2d0f:	movq   rax,xmm14
    2d14:	add    rax,rax
    2d17:	je     0x2d2d
    2d19:	shr    rax,0x35
    2d1d:	sub    eax,0x201
    2d22:	cmp    eax,0x3fc
    2d27:	ja     0x528f
    2d2d:	addpd  xmm0,xmm1
    2d31:	movdqa xmm4,xmm0
    2d35:	movdqa xmm0,xmm4
    2d39:	movdqu XMMWORD PTR [r12+0x180],xmm0
    2d43:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    2d4d:	movdqa xmm2,xmm0
    2d51:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    2d5b:	movdqa xmm3,xmm0
    2d5f:	movdqa xmm0,xmm2
    2d63:	movdqa xmm1,xmm3
    2d67:	pshufd xmm1,xmm1,0x44
    2d6c:	movq   rax,xmm0
    2d71:	add    rax,rax
    2d74:	je     0x2d8a
    2d76:	shr    rax,0x35
    2d7a:	sub    eax,0x201
    2d7f:	cmp    eax,0x3fc
    2d84:	ja     0x52b3
    2d8a:	movdqa xmm14,xmm0
    2d8f:	psrldq xmm14,0x8
    2d95:	movq   rax,xmm14
    2d9a:	add    rax,rax
    2d9d:	je     0x2db3
    2d9f:	shr    rax,0x35
    2da3:	sub    eax,0x201
    2da8:	cmp    eax,0x3fc
    2dad:	ja     0x52b3
    2db3:	movq   rax,xmm1
    2db8:	add    rax,rax
    2dbb:	je     0x2dd1
    2dbd:	shr    rax,0x35
    2dc1:	sub    eax,0x201
    2dc6:	cmp    eax,0x3fc
    2dcb:	ja     0x52b3
    2dd1:	movdqa xmm14,xmm1
    2dd6:	psrldq xmm14,0x8
    2ddc:	movq   rax,xmm14
    2de1:	add    rax,rax
    2de4:	je     0x2dfa
    2de6:	shr    rax,0x35
    2dea:	sub    eax,0x201
    2def:	cmp    eax,0x3fc
    2df4:	ja     0x52b3
    2dfa:	mulpd  xmm0,xmm1
    2dfe:	movdqa xmm4,xmm0
    2e02:	movdqa xmm0,xmm4
    2e06:	movdqu XMMWORD PTR [r12+0x210],xmm0
    2e10:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    2e1a:	movdqa xmm2,xmm0
    2e1e:	movdqa xmm0,xmm2
    2e22:	movdqa xmm1,xmm3
    2e26:	pshufd xmm1,xmm1,0x44
    2e2b:	movq   rax,xmm0
    2e30:	add    rax,rax
    2e33:	je     0x2e49
    2e35:	shr    rax,0x35
    2e39:	sub    eax,0x201
    2e3e:	cmp    eax,0x3fc
    2e43:	ja     0x52d7
    2e49:	movdqa xmm14,xmm0
    2e4e:	psrldq xmm14,0x8
    2e54:	movq   rax,xmm14
    2e59:	add    rax,rax
    2e5c:	je     0x2e72
    2e5e:	shr    rax,0x35
    2e62:	sub    eax,0x201
    2e67:	cmp    eax,0x3fc
    2e6c:	ja     0x52d7
    2e72:	movq   rax,xmm1
    2e77:	add    rax,rax
    2e7a:	je     0x2e90
    2e7c:	shr    rax,0x35
    2e80:	sub    eax,0x201
    2e85:	cmp    eax,0x3fc
    2e8a:	ja     0x52d7
    2e90:	movdqa xmm14,xmm1
    2e95:	psrldq xmm14,0x8
    2e9b:	movq   rax,xmm14
    2ea0:	add    rax,rax
    2ea3:	je     0x2eb9
    2ea5:	shr    rax,0x35
    2ea9:	sub    eax,0x201
    2eae:	cmp    eax,0x3fc
    2eb3:	ja     0x52d7
    2eb9:	mulpd  xmm0,xmm1
    2ebd:	movdqa xmm4,xmm0
    2ec1:	movdqa xmm0,xmm4
    2ec5:	movdqu XMMWORD PTR [r12+0x230],xmm0
    2ecf:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    2ed9:	movdqa xmm2,xmm0
    2edd:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    2ee7:	movdqa xmm4,xmm0
    2eeb:	movdqa xmm0,xmm2
    2eef:	movdqa xmm1,xmm4
    2ef3:	movq   rax,xmm0
    2ef8:	add    rax,rax
    2efb:	je     0x2f11
    2efd:	shr    rax,0x35
    2f01:	sub    eax,0x201
    2f06:	cmp    eax,0x3fc
    2f0b:	ja     0x52fb
    2f11:	movdqa xmm14,xmm0
    2f16:	psrldq xmm14,0x8
    2f1c:	movq   rax,xmm14
    2f21:	add    rax,rax
    2f24:	je     0x2f3a
    2f26:	shr    rax,0x35
    2f2a:	sub    eax,0x201
    2f2f:	cmp    eax,0x3fc
    2f34:	ja     0x52fb
    2f3a:	movq   rax,xmm1
    2f3f:	add    rax,rax
    2f42:	je     0x2f58
    2f44:	shr    rax,0x35
    2f48:	sub    eax,0x201
    2f4d:	cmp    eax,0x3fc
    2f52:	ja     0x52fb
    2f58:	movdqa xmm14,xmm1
    2f5d:	psrldq xmm14,0x8
    2f63:	movq   rax,xmm14
    2f68:	add    rax,rax
    2f6b:	je     0x2f81
    2f6d:	shr    rax,0x35
    2f71:	sub    eax,0x201
    2f76:	cmp    eax,0x3fc
    2f7b:	ja     0x52fb
    2f81:	addpd  xmm0,xmm1
    2f85:	movdqa xmm5,xmm0
    2f89:	movdqa xmm0,xmm5
    2f8d:	movdqu XMMWORD PTR [r12+0x240],xmm0
    2f97:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    2fa1:	movdqa xmm2,xmm0
    2fa5:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    2faf:	movdqa xmm4,xmm0
    2fb3:	movdqa xmm0,xmm2
    2fb7:	movdqa xmm1,xmm4
    2fbb:	movq   rax,xmm0
    2fc0:	add    rax,rax
    2fc3:	je     0x2fd9
    2fc5:	shr    rax,0x35
    2fc9:	sub    eax,0x201
    2fce:	cmp    eax,0x3fc
    2fd3:	ja     0x531f
    2fd9:	movdqa xmm14,xmm0
    2fde:	psrldq xmm14,0x8
    2fe4:	movq   rax,xmm14
    2fe9:	add    rax,rax
    2fec:	je     0x3002
    2fee:	shr    rax,0x35
    2ff2:	sub    eax,0x201
    2ff7:	cmp    eax,0x3fc
    2ffc:	ja     0x531f
    3002:	movq   rax,xmm1
    3007:	add    rax,rax
    300a:	je     0x3020
    300c:	shr    rax,0x35
    3010:	sub    eax,0x201
    3015:	cmp    eax,0x3fc
    301a:	ja     0x531f
    3020:	movdqa xmm14,xmm1
    3025:	psrldq xmm14,0x8
    302b:	movq   rax,xmm14
    3030:	add    rax,rax
    3033:	je     0x3049
    3035:	shr    rax,0x35
    3039:	sub    eax,0x201
    303e:	cmp    eax,0x3fc
    3043:	ja     0x531f
    3049:	addpd  xmm0,xmm1
    304d:	movdqa xmm5,xmm0
    3051:	movdqa xmm0,xmm5
    3055:	movdqu XMMWORD PTR [r12+0x220],xmm0
    305f:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    3069:	movdqa xmm2,xmm0
    306d:	movdqa xmm0,xmm2
    3071:	movdqa xmm1,xmm3
    3075:	pshufd xmm1,xmm1,0x44
    307a:	movq   rax,xmm0
    307f:	add    rax,rax
    3082:	je     0x3098
    3084:	shr    rax,0x35
    3088:	sub    eax,0x201
    308d:	cmp    eax,0x3fc
    3092:	ja     0x5343
    3098:	movdqa xmm14,xmm0
    309d:	psrldq xmm14,0x8
    30a3:	movq   rax,xmm14
    30a8:	add    rax,rax
    30ab:	je     0x30c1
    30ad:	shr    rax,0x35
    30b1:	sub    eax,0x201
    30b6:	cmp    eax,0x3fc
    30bb:	ja     0x5343
    30c1:	movq   rax,xmm1
    30c6:	add    rax,rax
    30c9:	je     0x30df
    30cb:	shr    rax,0x35
    30cf:	sub    eax,0x201
    30d4:	cmp    eax,0x3fc
    30d9:	ja     0x5343
    30df:	movdqa xmm14,xmm1
    30e4:	psrldq xmm14,0x8
    30ea:	movq   rax,xmm14
    30ef:	add    rax,rax
    30f2:	je     0x3108
    30f4:	shr    rax,0x35
    30f8:	sub    eax,0x201
    30fd:	cmp    eax,0x3fc
    3102:	ja     0x5343
    3108:	mulpd  xmm0,xmm1
    310c:	movdqa xmm4,xmm0
    3110:	movdqa xmm0,xmm4
    3114:	movdqu XMMWORD PTR [r12+0x250],xmm0
    311e:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    3128:	movdqa xmm2,xmm0
    312c:	movdqa xmm0,xmm2
    3130:	movdqa xmm1,xmm3
    3134:	pshufd xmm1,xmm1,0x44
    3139:	movq   rax,xmm0
    313e:	add    rax,rax
    3141:	je     0x3157
    3143:	shr    rax,0x35
    3147:	sub    eax,0x201
    314c:	cmp    eax,0x3fc
    3151:	ja     0x5367
    3157:	movdqa xmm14,xmm0
    315c:	psrldq xmm14,0x8
    3162:	movq   rax,xmm14
    3167:	add    rax,rax
    316a:	je     0x3180
    316c:	shr    rax,0x35
    3170:	sub    eax,0x201
    3175:	cmp    eax,0x3fc
    317a:	ja     0x5367
    3180:	movq   rax,xmm1
    3185:	add    rax,rax
    3188:	je     0x319e
    318a:	shr    rax,0x35
    318e:	sub    eax,0x201
    3193:	cmp    eax,0x3fc
    3198:	ja     0x5367
    319e:	movdqa xmm14,xmm1
    31a3:	psrldq xmm14,0x8
    31a9:	movq   rax,xmm14
    31ae:	add    rax,rax
    31b1:	je     0x31c7
    31b3:	shr    rax,0x35
    31b7:	sub    eax,0x201
    31bc:	cmp    eax,0x3fc
    31c1:	ja     0x5367
    31c7:	mulpd  xmm0,xmm1
    31cb:	movdqa xmm4,xmm0
    31cf:	movdqa xmm0,xmm4
    31d3:	movdqu XMMWORD PTR [r12+0x150],xmm0
    31dd:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    31e7:	movdqa xmm2,xmm0
    31eb:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    31f5:	movdqa xmm3,xmm0
    31f9:	movdqa xmm0,xmm2
    31fd:	movdqa xmm1,xmm3
    3201:	movq   rax,xmm0
    3206:	add    rax,rax
    3209:	je     0x321f
    320b:	shr    rax,0x35
    320f:	sub    eax,0x201
    3214:	cmp    eax,0x3fc
    3219:	ja     0x538b
    321f:	movdqa xmm14,xmm0
    3224:	psrldq xmm14,0x8
    322a:	movq   rax,xmm14
    322f:	add    rax,rax
    3232:	je     0x3248
    3234:	shr    rax,0x35
    3238:	sub    eax,0x201
    323d:	cmp    eax,0x3fc
    3242:	ja     0x538b
    3248:	movq   rax,xmm1
    324d:	add    rax,rax
    3250:	je     0x3266
    3252:	shr    rax,0x35
    3256:	sub    eax,0x201
    325b:	cmp    eax,0x3fc
    3260:	ja     0x538b
    3266:	movdqa xmm14,xmm1
    326b:	psrldq xmm14,0x8
    3271:	movq   rax,xmm14
    3276:	add    rax,rax
    3279:	je     0x328f
    327b:	shr    rax,0x35
    327f:	sub    eax,0x201
    3284:	cmp    eax,0x3fc
    3289:	ja     0x538b
    328f:	addpd  xmm0,xmm1
    3293:	movdqa xmm4,xmm0
    3297:	movdqa xmm0,xmm4
    329b:	movdqu XMMWORD PTR [r12+0x160],xmm0
    32a5:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    32af:	movdqa xmm2,xmm0
    32b3:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    32bd:	movdqa xmm3,xmm0
    32c1:	movdqa xmm0,xmm2
    32c5:	movdqa xmm1,xmm3
    32c9:	movq   rax,xmm0
    32ce:	add    rax,rax
    32d1:	je     0x32e7
    32d3:	shr    rax,0x35
    32d7:	sub    eax,0x201
    32dc:	cmp    eax,0x3fc
    32e1:	ja     0x53af
    32e7:	movdqa xmm14,xmm0
    32ec:	psrldq xmm14,0x8
    32f2:	movq   rax,xmm14
    32f7:	add    rax,rax
    32fa:	je     0x3310
    32fc:	shr    rax,0x35
    3300:	sub    eax,0x201
    3305:	cmp    eax,0x3fc
    330a:	ja     0x53af
    3310:	movq   rax,xmm1
    3315:	add    rax,rax
    3318:	je     0x332e
    331a:	shr    rax,0x35
    331e:	sub    eax,0x201
    3323:	cmp    eax,0x3fc
    3328:	ja     0x53af
    332e:	movdqa xmm14,xmm1
    3333:	psrldq xmm14,0x8
    3339:	movq   rax,xmm14
    333e:	add    rax,rax
    3341:	je     0x3357
    3343:	shr    rax,0x35
    3347:	sub    eax,0x201
    334c:	cmp    eax,0x3fc
    3351:	ja     0x53af
    3357:	addpd  xmm0,xmm1
    335b:	movdqa xmm4,xmm0
    335f:	movdqa xmm0,xmm4
    3363:	movdqu XMMWORD PTR [r12+0x170],xmm0
    336d:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    3377:	movdqa xmm2,xmm0
    337b:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    3385:	movdqa xmm3,xmm0
    3389:	movdqa xmm0,xmm2
    338d:	movdqa xmm1,xmm3
    3391:	pshufd xmm1,xmm1,0x44
    3396:	movq   rax,xmm0
    339b:	add    rax,rax
    339e:	je     0x33b4
    33a0:	shr    rax,0x35
    33a4:	sub    eax,0x201
    33a9:	cmp    eax,0x3fc
    33ae:	ja     0x53d3
    33b4:	movdqa xmm14,xmm0
    33b9:	psrldq xmm14,0x8
    33bf:	movq   rax,xmm14
    33c4:	add    rax,rax
    33c7:	je     0x33dd
    33c9:	shr    rax,0x35
    33cd:	sub    eax,0x201
    33d2:	cmp    eax,0x3fc
    33d7:	ja     0x53d3
    33dd:	movq   rax,xmm1
    33e2:	add    rax,rax
    33e5:	je     0x33fb
    33e7:	shr    rax,0x35
    33eb:	sub    eax,0x201
    33f0:	cmp    eax,0x3fc
    33f5:	ja     0x53d3
    33fb:	movdqa xmm14,xmm1
    3400:	psrldq xmm14,0x8
    3406:	movq   rax,xmm14
    340b:	add    rax,rax
    340e:	je     0x3424
    3410:	shr    rax,0x35
    3414:	sub    eax,0x201
    3419:	cmp    eax,0x3fc
    341e:	ja     0x53d3
    3424:	mulpd  xmm0,xmm1
    3428:	movdqa xmm4,xmm0
    342c:	movdqa xmm0,xmm4
    3430:	movdqu XMMWORD PTR [r12+0x180],xmm0
    343a:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    3444:	movdqa xmm2,xmm0
    3448:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    3452:	movdqa xmm3,xmm0
    3456:	movdqa xmm0,xmm2
    345a:	movdqa xmm1,xmm3
    345e:	movq   rax,xmm0
    3463:	add    rax,rax
    3466:	je     0x347c
    3468:	shr    rax,0x35
    346c:	sub    eax,0x201
    3471:	cmp    eax,0x3fc
    3476:	ja     0x53f7
    347c:	movdqa xmm14,xmm0
    3481:	psrldq xmm14,0x8
    3487:	movq   rax,xmm14
    348c:	add    rax,rax
    348f:	je     0x34a5
    3491:	shr    rax,0x35
    3495:	sub    eax,0x201
    349a:	cmp    eax,0x3fc
    349f:	ja     0x53f7
    34a5:	movq   rax,xmm1
    34aa:	add    rax,rax
    34ad:	je     0x34c3
    34af:	shr    rax,0x35
    34b3:	sub    eax,0x201
    34b8:	cmp    eax,0x3fc
    34bd:	ja     0x53f7
    34c3:	movdqa xmm14,xmm1
    34c8:	psrldq xmm14,0x8
    34ce:	movq   rax,xmm14
    34d3:	add    rax,rax
    34d6:	je     0x34ec
    34d8:	shr    rax,0x35
    34dc:	sub    eax,0x201
    34e1:	cmp    eax,0x3fc
    34e6:	ja     0x53f7
    34ec:	addpd  xmm0,xmm1
    34f0:	movdqa xmm4,xmm0
    34f4:	movdqa xmm0,xmm4
    34f8:	movdqu XMMWORD PTR [r12+0x210],xmm0
    3502:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    350c:	movdqa xmm2,xmm0
    3510:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    351a:	movdqa xmm3,xmm0
    351e:	movdqa xmm0,xmm2
    3522:	movdqa xmm1,xmm3
    3526:	movq   rax,xmm0
    352b:	add    rax,rax
    352e:	je     0x3544
    3530:	shr    rax,0x35
    3534:	sub    eax,0x201
    3539:	cmp    eax,0x3fc
    353e:	ja     0x541b
    3544:	movdqa xmm14,xmm0
    3549:	psrldq xmm14,0x8
    354f:	movq   rax,xmm14
    3554:	add    rax,rax
    3557:	je     0x356d
    3559:	shr    rax,0x35
    355d:	sub    eax,0x201
    3562:	cmp    eax,0x3fc
    3567:	ja     0x541b
    356d:	movq   rax,xmm1
    3572:	add    rax,rax
    3575:	je     0x358b
    3577:	shr    rax,0x35
    357b:	sub    eax,0x201
    3580:	cmp    eax,0x3fc
    3585:	ja     0x541b
    358b:	movdqa xmm14,xmm1
    3590:	psrldq xmm14,0x8
    3596:	movq   rax,xmm14
    359b:	add    rax,rax
    359e:	je     0x35b4
    35a0:	shr    rax,0x35
    35a4:	sub    eax,0x201
    35a9:	cmp    eax,0x3fc
    35ae:	ja     0x541b
    35b4:	addpd  xmm0,xmm1
    35b8:	movdqa xmm4,xmm0
    35bc:	movdqa xmm0,xmm4
    35c0:	movdqu XMMWORD PTR [r12+0x230],xmm0
    35ca:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    35d4:	movdqa xmm2,xmm0
    35d8:	movdqa xmm1,xmm2
    35dc:	por    xmm2,xmm1
    35e0:	movdqa xmm0,xmm2
    35e4:	movdqu XMMWORD PTR [r12+0x250],xmm0
    35ee:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    35f8:	movdqa xmm2,xmm0
    35fc:	movdqa xmm1,xmm2
    3600:	por    xmm2,xmm1
    3604:	movdqa xmm0,xmm2
    3608:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    3612:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    361c:	movdqa xmm2,xmm0
    3620:	movdqa xmm1,xmm2
    3624:	por    xmm2,xmm1
    3628:	movdqa xmm0,xmm2
    362c:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    3636:	mov    r13,QWORD PTR [r12+0xf8]
    363e:	add    r13,0x40
    3642:	stmxcsr DWORD PTR [rsp+0x114]
    364a:	ldmxcsr DWORD PTR [rsp+0x110]
    3652:	mov    r11d,DWORD PTR [rsp+0x114]
    365a:	shr    r11d,1
    365d:	and    r11d,0x10
    3661:	or     DWORD PTR [r12+0x314],r11d
    3669:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    366f:	movdqa xmm0,xmm2
    3673:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    367d:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    3687:	movdqa xmm2,xmm0
    368b:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    3695:	movdqa xmm3,xmm0
    3699:	stmxcsr DWORD PTR [rsp+0x110]
    36a1:	mov    DWORD PTR [rsp+0x114],0x1f80
    36ac:	ldmxcsr DWORD PTR [rsp+0x114]
    36b4:	movdqa xmm0,xmm2
    36b8:	movdqa xmm1,xmm3
    36bc:	pshufd xmm1,xmm1,0x44
    36c1:	movq   rax,xmm0
    36c6:	add    rax,rax
    36c9:	je     0x36df
    36cb:	shr    rax,0x35
    36cf:	sub    eax,0x201
    36d4:	cmp    eax,0x3fc
    36d9:	ja     0x543f
    36df:	movdqa xmm14,xmm0
    36e4:	psrldq xmm14,0x8
    36ea:	movq   rax,xmm14
    36ef:	add    rax,rax
    36f2:	je     0x3708
    36f4:	shr    rax,0x35
    36f8:	sub    eax,0x201
    36fd:	cmp    eax,0x3fc
    3702:	ja     0x543f
    3708:	movq   rax,xmm1
    370d:	add    rax,rax
    3710:	je     0x3726
    3712:	shr    rax,0x35
    3716:	sub    eax,0x201
    371b:	cmp    eax,0x3fc
    3720:	ja     0x543f
    3726:	movdqa xmm14,xmm1
    372b:	psrldq xmm14,0x8
    3731:	movq   rax,xmm14
    3736:	add    rax,rax
    3739:	je     0x374f
    373b:	shr    rax,0x35
    373f:	sub    eax,0x201
    3744:	cmp    eax,0x3fc
    3749:	ja     0x543f
    374f:	mulpd  xmm0,xmm1
    3753:	movdqa xmm4,xmm0
    3757:	movdqa xmm0,xmm4
    375b:	movdqu XMMWORD PTR [r12+0x220],xmm0
    3765:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    376f:	movdqa xmm2,xmm0
    3773:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    377d:	movdqa xmm4,xmm0
    3781:	movdqa xmm0,xmm2
    3785:	movdqa xmm1,xmm4
    3789:	movq   rax,xmm0
    378e:	add    rax,rax
    3791:	je     0x37a7
    3793:	shr    rax,0x35
    3797:	sub    eax,0x201
    379c:	cmp    eax,0x3fc
    37a1:	ja     0x5463
    37a7:	movdqa xmm14,xmm0
    37ac:	psrldq xmm14,0x8
    37b2:	movq   rax,xmm14
    37b7:	add    rax,rax
    37ba:	je     0x37d0
    37bc:	shr    rax,0x35
    37c0:	sub    eax,0x201
    37c5:	cmp    eax,0x3fc
    37ca:	ja     0x5463
    37d0:	movq   rax,xmm1
    37d5:	add    rax,rax
    37d8:	je     0x37ee
    37da:	shr    rax,0x35
    37de:	sub    eax,0x201
    37e3:	cmp    eax,0x3fc
    37e8:	ja     0x5463
    37ee:	movdqa xmm14,xmm1
    37f3:	psrldq xmm14,0x8
    37f9:	movq   rax,xmm14
    37fe:	add    rax,rax
    3801:	je     0x3817
    3803:	shr    rax,0x35
    3807:	sub    eax,0x201
    380c:	cmp    eax,0x3fc
    3811:	ja     0x5463
    3817:	addpd  xmm0,xmm1
    381b:	movdqa xmm5,xmm0
    381f:	movdqa xmm0,xmm5
    3823:	movdqu XMMWORD PTR [r12+0x150],xmm0
    382d:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    3837:	movdqa xmm2,xmm0
    383b:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    3845:	movdqa xmm4,xmm0
    3849:	movdqa xmm0,xmm2
    384d:	movdqa xmm1,xmm4
    3851:	movq   rax,xmm0
    3856:	add    rax,rax
    3859:	je     0x386f
    385b:	shr    rax,0x35
    385f:	sub    eax,0x201
    3864:	cmp    eax,0x3fc
    3869:	ja     0x5487
    386f:	movdqa xmm14,xmm0
    3874:	psrldq xmm14,0x8
    387a:	movq   rax,xmm14
    387f:	add    rax,rax
    3882:	je     0x3898
    3884:	shr    rax,0x35
    3888:	sub    eax,0x201
    388d:	cmp    eax,0x3fc
    3892:	ja     0x5487
    3898:	movq   rax,xmm1
    389d:	add    rax,rax
    38a0:	je     0x38b6
    38a2:	shr    rax,0x35
    38a6:	sub    eax,0x201
    38ab:	cmp    eax,0x3fc
    38b0:	ja     0x5487
    38b6:	movdqa xmm14,xmm1
    38bb:	psrldq xmm14,0x8
    38c1:	movq   rax,xmm14
    38c6:	add    rax,rax
    38c9:	je     0x38df
    38cb:	shr    rax,0x35
    38cf:	sub    eax,0x201
    38d4:	cmp    eax,0x3fc
    38d9:	ja     0x5487
    38df:	addpd  xmm0,xmm1
    38e3:	movdqa xmm5,xmm0
    38e7:	movdqa xmm0,xmm5
    38eb:	movdqu XMMWORD PTR [r12+0x160],xmm0
    38f5:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    38ff:	movdqa xmm2,xmm0
    3903:	movdqa xmm0,xmm2
    3907:	movdqa xmm1,xmm3
    390b:	pshufd xmm1,xmm1,0x44
    3910:	movq   rax,xmm0
    3915:	add    rax,rax
    3918:	je     0x392e
    391a:	shr    rax,0x35
    391e:	sub    eax,0x201
    3923:	cmp    eax,0x3fc
    3928:	ja     0x54ab
    392e:	movdqa xmm14,xmm0
    3933:	psrldq xmm14,0x8
    3939:	movq   rax,xmm14
    393e:	add    rax,rax
    3941:	je     0x3957
    3943:	shr    rax,0x35
    3947:	sub    eax,0x201
    394c:	cmp    eax,0x3fc
    3951:	ja     0x54ab
    3957:	movq   rax,xmm1
    395c:	add    rax,rax
    395f:	je     0x3975
    3961:	shr    rax,0x35
    3965:	sub    eax,0x201
    396a:	cmp    eax,0x3fc
    396f:	ja     0x54ab
    3975:	movdqa xmm14,xmm1
    397a:	psrldq xmm14,0x8
    3980:	movq   rax,xmm14
    3985:	add    rax,rax
    3988:	je     0x399e
    398a:	shr    rax,0x35
    398e:	sub    eax,0x201
    3993:	cmp    eax,0x3fc
    3998:	ja     0x54ab
    399e:	mulpd  xmm0,xmm1
    39a2:	movdqa xmm4,xmm0
    39a6:	movdqa xmm0,xmm4
    39aa:	movdqu XMMWORD PTR [r12+0x240],xmm0
    39b4:	movdqu xmm0,XMMWORD PTR [r12+0x2b0]
    39be:	movdqa xmm2,xmm0
    39c2:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    39cc:	movdqa xmm3,xmm0
    39d0:	movdqa xmm0,xmm2
    39d4:	movdqa xmm1,xmm3
    39d8:	pshufd xmm1,xmm1,0x44
    39dd:	movq   rax,xmm0
    39e2:	add    rax,rax
    39e5:	je     0x39fb
    39e7:	shr    rax,0x35
    39eb:	sub    eax,0x201
    39f0:	cmp    eax,0x3fc
    39f5:	ja     0x54cf
    39fb:	movdqa xmm14,xmm0
    3a00:	psrldq xmm14,0x8
    3a06:	movq   rax,xmm14
    3a0b:	add    rax,rax
    3a0e:	je     0x3a24
    3a10:	shr    rax,0x35
    3a14:	sub    eax,0x201
    3a19:	cmp    eax,0x3fc
    3a1e:	ja     0x54cf
    3a24:	movq   rax,xmm1
    3a29:	add    rax,rax
    3a2c:	je     0x3a42
    3a2e:	shr    rax,0x35
    3a32:	sub    eax,0x201
    3a37:	cmp    eax,0x3fc
    3a3c:	ja     0x54cf
    3a42:	movdqa xmm14,xmm1
    3a47:	psrldq xmm14,0x8
    3a4d:	movq   rax,xmm14
    3a52:	add    rax,rax
    3a55:	je     0x3a6b
    3a57:	shr    rax,0x35
    3a5b:	sub    eax,0x201
    3a60:	cmp    eax,0x3fc
    3a65:	ja     0x54cf
    3a6b:	mulpd  xmm0,xmm1
    3a6f:	movdqa xmm4,xmm0
    3a73:	movdqa xmm0,xmm4
    3a77:	movdqu XMMWORD PTR [r12+0x140],xmm0
    3a81:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    3a8b:	movdqa xmm2,xmm0
    3a8f:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    3a99:	movdqa xmm3,xmm0
    3a9d:	movdqa xmm0,xmm2
    3aa1:	movdqa xmm1,xmm3
    3aa5:	pshufd xmm1,xmm1,0x44
    3aaa:	movq   rax,xmm0
    3aaf:	add    rax,rax
    3ab2:	je     0x3ac8
    3ab4:	shr    rax,0x35
    3ab8:	sub    eax,0x201
    3abd:	cmp    eax,0x3fc
    3ac2:	ja     0x54f3
    3ac8:	movdqa xmm14,xmm0
    3acd:	psrldq xmm14,0x8
    3ad3:	movq   rax,xmm14
    3ad8:	add    rax,rax
    3adb:	je     0x3af1
    3add:	shr    rax,0x35
    3ae1:	sub    eax,0x201
    3ae6:	cmp    eax,0x3fc
    3aeb:	ja     0x54f3
    3af1:	movq   rax,xmm1
    3af6:	add    rax,rax
    3af9:	je     0x3b0f
    3afb:	shr    rax,0x35
    3aff:	sub    eax,0x201
    3b04:	cmp    eax,0x3fc
    3b09:	ja     0x54f3
    3b0f:	movdqa xmm14,xmm1
    3b14:	psrldq xmm14,0x8
    3b1a:	movq   rax,xmm14
    3b1f:	add    rax,rax
    3b22:	je     0x3b38
    3b24:	shr    rax,0x35
    3b28:	sub    eax,0x201
    3b2d:	cmp    eax,0x3fc
    3b32:	ja     0x54f3
    3b38:	mulpd  xmm0,xmm1
    3b3c:	movdqa xmm4,xmm0
    3b40:	movdqa xmm0,xmm4
    3b44:	movdqu XMMWORD PTR [r12+0x170],xmm0
    3b4e:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    3b58:	movdqa xmm2,xmm0
    3b5c:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    3b66:	movdqa xmm4,xmm0
    3b6a:	movdqa xmm0,xmm2
    3b6e:	movdqa xmm1,xmm4
    3b72:	movq   rax,xmm0
    3b77:	add    rax,rax
    3b7a:	je     0x3b90
    3b7c:	shr    rax,0x35
    3b80:	sub    eax,0x201
    3b85:	cmp    eax,0x3fc
    3b8a:	ja     0x5517
    3b90:	movdqa xmm14,xmm0
    3b95:	psrldq xmm14,0x8
    3b9b:	movq   rax,xmm14
    3ba0:	add    rax,rax
    3ba3:	je     0x3bb9
    3ba5:	shr    rax,0x35
    3ba9:	sub    eax,0x201
    3bae:	cmp    eax,0x3fc
    3bb3:	ja     0x5517
    3bb9:	movq   rax,xmm1
    3bbe:	add    rax,rax
    3bc1:	je     0x3bd7
    3bc3:	shr    rax,0x35
    3bc7:	sub    eax,0x201
    3bcc:	cmp    eax,0x3fc
    3bd1:	ja     0x5517
    3bd7:	movdqa xmm14,xmm1
    3bdc:	psrldq xmm14,0x8
    3be2:	movq   rax,xmm14
    3be7:	add    rax,rax
    3bea:	je     0x3c00
    3bec:	shr    rax,0x35
    3bf0:	sub    eax,0x201
    3bf5:	cmp    eax,0x3fc
    3bfa:	ja     0x5517
    3c00:	addpd  xmm0,xmm1
    3c04:	movdqa xmm5,xmm0
    3c08:	movdqa xmm0,xmm5
    3c0c:	movdqu XMMWORD PTR [r12+0x180],xmm0
    3c16:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    3c20:	movdqa xmm2,xmm0
    3c24:	movdqa xmm0,xmm2
    3c28:	movdqa xmm1,xmm3
    3c2c:	pshufd xmm1,xmm1,0x44
    3c31:	movq   rax,xmm0
    3c36:	add    rax,rax
    3c39:	je     0x3c4f
    3c3b:	shr    rax,0x35
    3c3f:	sub    eax,0x201
    3c44:	cmp    eax,0x3fc
    3c49:	ja     0x553b
    3c4f:	movdqa xmm14,xmm0
    3c54:	psrldq xmm14,0x8
    3c5a:	movq   rax,xmm14
    3c5f:	add    rax,rax
    3c62:	je     0x3c78
    3c64:	shr    rax,0x35
    3c68:	sub    eax,0x201
    3c6d:	cmp    eax,0x3fc
    3c72:	ja     0x553b
    3c78:	movq   rax,xmm1
    3c7d:	add    rax,rax
    3c80:	je     0x3c96
    3c82:	shr    rax,0x35
    3c86:	sub    eax,0x201
    3c8b:	cmp    eax,0x3fc
    3c90:	ja     0x553b
    3c96:	movdqa xmm14,xmm1
    3c9b:	psrldq xmm14,0x8
    3ca1:	movq   rax,xmm14
    3ca6:	add    rax,rax
    3ca9:	je     0x3cbf
    3cab:	shr    rax,0x35
    3caf:	sub    eax,0x201
    3cb4:	cmp    eax,0x3fc
    3cb9:	ja     0x553b
    3cbf:	mulpd  xmm0,xmm1
    3cc3:	movdqa xmm4,xmm0
    3cc7:	movdqa xmm0,xmm4
    3ccb:	movdqu XMMWORD PTR [r12+0x210],xmm0
    3cd5:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    3cdf:	movdqa xmm2,xmm0
    3ce3:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    3ced:	movdqa xmm4,xmm0
    3cf1:	movdqa xmm0,xmm2
    3cf5:	movdqa xmm1,xmm4
    3cf9:	movq   rax,xmm0
    3cfe:	add    rax,rax
    3d01:	je     0x3d17
    3d03:	shr    rax,0x35
    3d07:	sub    eax,0x201
    3d0c:	cmp    eax,0x3fc
    3d11:	ja     0x555f
    3d17:	movdqa xmm14,xmm0
    3d1c:	psrldq xmm14,0x8
    3d22:	movq   rax,xmm14
    3d27:	add    rax,rax
    3d2a:	je     0x3d40
    3d2c:	shr    rax,0x35
    3d30:	sub    eax,0x201
    3d35:	cmp    eax,0x3fc
    3d3a:	ja     0x555f
    3d40:	movq   rax,xmm1
    3d45:	add    rax,rax
    3d48:	je     0x3d5e
    3d4a:	shr    rax,0x35
    3d4e:	sub    eax,0x201
    3d53:	cmp    eax,0x3fc
    3d58:	ja     0x555f
    3d5e:	movdqa xmm14,xmm1
    3d63:	psrldq xmm14,0x8
    3d69:	movq   rax,xmm14
    3d6e:	add    rax,rax
    3d71:	je     0x3d87
    3d73:	shr    rax,0x35
    3d77:	sub    eax,0x201
    3d7c:	cmp    eax,0x3fc
    3d81:	ja     0x555f
    3d87:	addpd  xmm0,xmm1
    3d8b:	movdqa xmm5,xmm0
    3d8f:	movdqa xmm0,xmm5
    3d93:	movdqu XMMWORD PTR [r12+0x220],xmm0
    3d9d:	movdqu xmm0,XMMWORD PTR [r12+0x290]
    3da7:	movdqa xmm2,xmm0
    3dab:	movdqa xmm0,xmm2
    3daf:	movdqa xmm1,xmm3
    3db3:	pshufd xmm1,xmm1,0x44
    3db8:	movq   rax,xmm0
    3dbd:	add    rax,rax
    3dc0:	je     0x3dd6
    3dc2:	shr    rax,0x35
    3dc6:	sub    eax,0x201
    3dcb:	cmp    eax,0x3fc
    3dd0:	ja     0x5583
    3dd6:	movdqa xmm14,xmm0
    3ddb:	psrldq xmm14,0x8
    3de1:	movq   rax,xmm14
    3de6:	add    rax,rax
    3de9:	je     0x3dff
    3deb:	shr    rax,0x35
    3def:	sub    eax,0x201
    3df4:	cmp    eax,0x3fc
    3df9:	ja     0x5583
    3dff:	movq   rax,xmm1
    3e04:	add    rax,rax
    3e07:	je     0x3e1d
    3e09:	shr    rax,0x35
    3e0d:	sub    eax,0x201
    3e12:	cmp    eax,0x3fc
    3e17:	ja     0x5583
    3e1d:	movdqa xmm14,xmm1
    3e22:	psrldq xmm14,0x8
    3e28:	movq   rax,xmm14
    3e2d:	add    rax,rax
    3e30:	je     0x3e46
    3e32:	shr    rax,0x35
    3e36:	sub    eax,0x201
    3e3b:	cmp    eax,0x3fc
    3e40:	ja     0x5583
    3e46:	mulpd  xmm0,xmm1
    3e4a:	movdqa xmm4,xmm0
    3e4e:	movdqa xmm0,xmm4
    3e52:	movdqu XMMWORD PTR [r12+0x230],xmm0
    3e5c:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    3e66:	movdqa xmm2,xmm0
    3e6a:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    3e74:	movdqa xmm3,xmm0
    3e78:	movdqa xmm0,xmm2
    3e7c:	movdqa xmm1,xmm3
    3e80:	movq   rax,xmm0
    3e85:	add    rax,rax
    3e88:	je     0x3e9e
    3e8a:	shr    rax,0x35
    3e8e:	sub    eax,0x201
    3e93:	cmp    eax,0x3fc
    3e98:	ja     0x55a7
    3e9e:	movdqa xmm14,xmm0
    3ea3:	psrldq xmm14,0x8
    3ea9:	movq   rax,xmm14
    3eae:	add    rax,rax
    3eb1:	je     0x3ec7
    3eb3:	shr    rax,0x35
    3eb7:	sub    eax,0x201
    3ebc:	cmp    eax,0x3fc
    3ec1:	ja     0x55a7
    3ec7:	movq   rax,xmm1
    3ecc:	add    rax,rax
    3ecf:	je     0x3ee5
    3ed1:	shr    rax,0x35
    3ed5:	sub    eax,0x201
    3eda:	cmp    eax,0x3fc
    3edf:	ja     0x55a7
    3ee5:	movdqa xmm14,xmm1
    3eea:	psrldq xmm14,0x8
    3ef0:	movq   rax,xmm14
    3ef5:	add    rax,rax
    3ef8:	je     0x3f0e
    3efa:	shr    rax,0x35
    3efe:	sub    eax,0x201
    3f03:	cmp    eax,0x3fc
    3f08:	ja     0x55a7
    3f0e:	addpd  xmm0,xmm1
    3f12:	movdqa xmm4,xmm0
    3f16:	movdqa xmm0,xmm4
    3f1a:	movdqu XMMWORD PTR [r12+0x140],xmm0
    3f24:	movdqu xmm0,XMMWORD PTR [r12+0x1e0]
    3f2e:	movdqa xmm2,xmm0
    3f32:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    3f3c:	movdqa xmm3,xmm0
    3f40:	movdqa xmm0,xmm2
    3f44:	movdqa xmm1,xmm3
    3f48:	pshufd xmm1,xmm1,0x44
    3f4d:	movq   rax,xmm0
    3f52:	add    rax,rax
    3f55:	je     0x3f6b
    3f57:	shr    rax,0x35
    3f5b:	sub    eax,0x201
    3f60:	cmp    eax,0x3fc
    3f65:	ja     0x55cb
    3f6b:	movdqa xmm14,xmm0
    3f70:	psrldq xmm14,0x8
    3f76:	movq   rax,xmm14
    3f7b:	add    rax,rax
    3f7e:	je     0x3f94
    3f80:	shr    rax,0x35
    3f84:	sub    eax,0x201
    3f89:	cmp    eax,0x3fc
    3f8e:	ja     0x55cb
    3f94:	movq   rax,xmm1
    3f99:	add    rax,rax
    3f9c:	je     0x3fb2
    3f9e:	shr    rax,0x35
    3fa2:	sub    eax,0x201
    3fa7:	cmp    eax,0x3fc
    3fac:	ja     0x55cb
    3fb2:	movdqa xmm14,xmm1
    3fb7:	psrldq xmm14,0x8
    3fbd:	movq   rax,xmm14
    3fc2:	add    rax,rax
    3fc5:	je     0x3fdb
    3fc7:	shr    rax,0x35
    3fcb:	sub    eax,0x201
    3fd0:	cmp    eax,0x3fc
    3fd5:	ja     0x55cb
    3fdb:	mulpd  xmm0,xmm1
    3fdf:	movdqa xmm4,xmm0
    3fe3:	movdqa xmm0,xmm4
    3fe7:	movdqu XMMWORD PTR [r12+0x130],xmm0
    3ff1:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    3ffb:	movdqa xmm2,xmm0
    3fff:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    4009:	movdqa xmm3,xmm0
    400d:	movdqa xmm0,xmm2
    4011:	movdqa xmm1,xmm3
    4015:	movq   rax,xmm0
    401a:	add    rax,rax
    401d:	je     0x4033
    401f:	shr    rax,0x35
    4023:	sub    eax,0x201
    4028:	cmp    eax,0x3fc
    402d:	ja     0x55ef
    4033:	movdqa xmm14,xmm0
    4038:	psrldq xmm14,0x8
    403e:	movq   rax,xmm14
    4043:	add    rax,rax
    4046:	je     0x405c
    4048:	shr    rax,0x35
    404c:	sub    eax,0x201
    4051:	cmp    eax,0x3fc
    4056:	ja     0x55ef
    405c:	movq   rax,xmm1
    4061:	add    rax,rax
    4064:	je     0x407a
    4066:	shr    rax,0x35
    406a:	sub    eax,0x201
    406f:	cmp    eax,0x3fc
    4074:	ja     0x55ef
    407a:	movdqa xmm14,xmm1
    407f:	psrldq xmm14,0x8
    4085:	movq   rax,xmm14
    408a:	add    rax,rax
    408d:	je     0x40a3
    408f:	shr    rax,0x35
    4093:	sub    eax,0x201
    4098:	cmp    eax,0x3fc
    409d:	ja     0x55ef
    40a3:	addpd  xmm0,xmm1
    40a7:	movdqa xmm4,xmm0
    40ab:	movdqa xmm0,xmm4
    40af:	movdqu XMMWORD PTR [r12+0x150],xmm0
    40b9:	mov    r13,QWORD PTR [r12+0xf8]
    40c1:	mov    r14,r13
    40c4:	add    r14,0x70
    40c8:	stmxcsr DWORD PTR [rsp+0x114]
    40d0:	ldmxcsr DWORD PTR [rsp+0x110]
    40d8:	mov    r11d,DWORD PTR [rsp+0x114]
    40e0:	shr    r11d,1
    40e3:	and    r11d,0x10
    40e7:	or     DWORD PTR [r12+0x314],r11d
    40ef:	movdqu xmm2,XMMWORD PTR [r14]
    40f4:	movdqa xmm0,xmm2
    40f8:	movdqu XMMWORD PTR [r12+0x240],xmm0
    4102:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    410c:	movdqa xmm3,xmm0
    4110:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    411a:	movdqa xmm4,xmm0
    411e:	stmxcsr DWORD PTR [rsp+0x110]
    4126:	mov    DWORD PTR [rsp+0x114],0x1f80
    4131:	ldmxcsr DWORD PTR [rsp+0x114]
    4139:	movdqa xmm0,xmm3
    413d:	movdqa xmm1,xmm4
    4141:	movq   rax,xmm0
    4146:	add    rax,rax
    4149:	je     0x415f
    414b:	shr    rax,0x35
    414f:	sub    eax,0x201
    4154:	cmp    eax,0x3fc
    4159:	ja     0x5613
    415f:	movdqa xmm14,xmm0
    4164:	psrldq xmm14,0x8
    416a:	movq   rax,xmm14
    416f:	add    rax,rax
    4172:	je     0x4188
    4174:	shr    rax,0x35
    4178:	sub    eax,0x201
    417d:	cmp    eax,0x3fc
    4182:	ja     0x5613
    4188:	movq   rax,xmm1
    418d:	add    rax,rax
    4190:	je     0x41a6
    4192:	shr    rax,0x35
    4196:	sub    eax,0x201
    419b:	cmp    eax,0x3fc
    41a0:	ja     0x5613
    41a6:	movdqa xmm14,xmm1
    41ab:	psrldq xmm14,0x8
    41b1:	movq   rax,xmm14
    41b6:	add    rax,rax
    41b9:	je     0x41cf
    41bb:	shr    rax,0x35
    41bf:	sub    eax,0x201
    41c4:	cmp    eax,0x3fc
    41c9:	ja     0x5613
    41cf:	addpd  xmm0,xmm1
    41d3:	movdqa xmm5,xmm0
    41d7:	movdqa xmm0,xmm5
    41db:	movdqu XMMWORD PTR [r12+0x170],xmm0
    41e5:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    41ef:	movdqa xmm3,xmm0
    41f3:	movdqa xmm0,xmm2
    41f7:	movdqa xmm1,xmm3
    41fb:	pshufd xmm1,xmm1,0x44
    4200:	movq   rax,xmm0
    4205:	add    rax,rax
    4208:	je     0x421e
    420a:	shr    rax,0x35
    420e:	sub    eax,0x201
    4213:	cmp    eax,0x3fc
    4218:	ja     0x5637
    421e:	movdqa xmm14,xmm0
    4223:	psrldq xmm14,0x8
    4229:	movq   rax,xmm14
    422e:	add    rax,rax
    4231:	je     0x4247
    4233:	shr    rax,0x35
    4237:	sub    eax,0x201
    423c:	cmp    eax,0x3fc
    4241:	ja     0x5637
    4247:	movq   rax,xmm1
    424c:	add    rax,rax
    424f:	je     0x4265
    4251:	shr    rax,0x35
    4255:	sub    eax,0x201
    425a:	cmp    eax,0x3fc
    425f:	ja     0x5637
    4265:	movdqa xmm14,xmm1
    426a:	psrldq xmm14,0x8
    4270:	movq   rax,xmm14
    4275:	add    rax,rax
    4278:	je     0x428e
    427a:	shr    rax,0x35
    427e:	sub    eax,0x201
    4283:	cmp    eax,0x3fc
    4288:	ja     0x5637
    428e:	mulpd  xmm0,xmm1
    4292:	movdqa xmm4,xmm0
    4296:	movdqa xmm0,xmm4
    429a:	movdqu XMMWORD PTR [r12+0x160],xmm0
    42a4:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    42ae:	movdqa xmm2,xmm0
    42b2:	movdqa xmm0,xmm2
    42b6:	movdqa xmm1,xmm3
    42ba:	pshufd xmm1,xmm1,0x44
    42bf:	movq   rax,xmm0
    42c4:	add    rax,rax
    42c7:	je     0x42dd
    42c9:	shr    rax,0x35
    42cd:	sub    eax,0x201
    42d2:	cmp    eax,0x3fc
    42d7:	ja     0x565b
    42dd:	movdqa xmm14,xmm0
    42e2:	psrldq xmm14,0x8
    42e8:	movq   rax,xmm14
    42ed:	add    rax,rax
    42f0:	je     0x4306
    42f2:	shr    rax,0x35
    42f6:	sub    eax,0x201
    42fb:	cmp    eax,0x3fc
    4300:	ja     0x565b
    4306:	movq   rax,xmm1
    430b:	add    rax,rax
    430e:	je     0x4324
    4310:	shr    rax,0x35
    4314:	sub    eax,0x201
    4319:	cmp    eax,0x3fc
    431e:	ja     0x565b
    4324:	movdqa xmm14,xmm1
    4329:	psrldq xmm14,0x8
    432f:	movq   rax,xmm14
    4334:	add    rax,rax
    4337:	je     0x434d
    4339:	shr    rax,0x35
    433d:	sub    eax,0x201
    4342:	cmp    eax,0x3fc
    4347:	ja     0x565b
    434d:	mulpd  xmm0,xmm1
    4351:	movdqa xmm4,xmm0
    4355:	movdqa xmm0,xmm4
    4359:	movdqu XMMWORD PTR [r12+0x180],xmm0
    4363:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    436d:	movdqa xmm2,xmm0
    4371:	movdqu xmm0,XMMWORD PTR [r12+0x230]
    437b:	movdqa xmm4,xmm0
    437f:	movdqa xmm0,xmm2
    4383:	movdqa xmm1,xmm4
    4387:	movq   rax,xmm0
    438c:	add    rax,rax
    438f:	je     0x43a5
    4391:	shr    rax,0x35
    4395:	sub    eax,0x201
    439a:	cmp    eax,0x3fc
    439f:	ja     0x567f
    43a5:	movdqa xmm14,xmm0
    43aa:	psrldq xmm14,0x8
    43b0:	movq   rax,xmm14
    43b5:	add    rax,rax
    43b8:	je     0x43ce
    43ba:	shr    rax,0x35
    43be:	sub    eax,0x201
    43c3:	cmp    eax,0x3fc
    43c8:	ja     0x567f
    43ce:	movq   rax,xmm1
    43d3:	add    rax,rax
    43d6:	je     0x43ec
    43d8:	shr    rax,0x35
    43dc:	sub    eax,0x201
    43e1:	cmp    eax,0x3fc
    43e6:	ja     0x567f
    43ec:	movdqa xmm14,xmm1
    43f1:	psrldq xmm14,0x8
    43f7:	movq   rax,xmm14
    43fc:	add    rax,rax
    43ff:	je     0x4415
    4401:	shr    rax,0x35
    4405:	sub    eax,0x201
    440a:	cmp    eax,0x3fc
    440f:	ja     0x567f
    4415:	addpd  xmm0,xmm1
    4419:	movdqa xmm5,xmm0
    441d:	movdqa xmm0,xmm5
    4421:	movdqu XMMWORD PTR [r12+0x210],xmm0
    442b:	mov    r14,r13
    442e:	add    r14,0x10
    4432:	stmxcsr DWORD PTR [rsp+0x114]
    443a:	ldmxcsr DWORD PTR [rsp+0x110]
    4442:	mov    r11d,DWORD PTR [rsp+0x114]
    444a:	shr    r11d,1
    444d:	and    r11d,0x10
    4451:	or     DWORD PTR [r12+0x314],r11d
    4459:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    445f:	movdqu xmm4,XMMWORD PTR [r14]
    4464:	movdqa xmm0,xmm4
    4468:	movdqu XMMWORD PTR [r12+0x230],xmm0
    4472:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    447c:	movdqa xmm5,xmm0
    4480:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    448a:	movdqa xmm6,xmm0
    448e:	stmxcsr DWORD PTR [rsp+0x110]
    4496:	mov    DWORD PTR [rsp+0x114],0x1f80
    44a1:	ldmxcsr DWORD PTR [rsp+0x114]
    44a9:	movdqa xmm0,xmm5
    44ad:	movdqa xmm1,xmm6
    44b1:	movq   rax,xmm0
    44b6:	add    rax,rax
    44b9:	je     0x44cf
    44bb:	shr    rax,0x35
    44bf:	sub    eax,0x201
    44c4:	cmp    eax,0x3fc
    44c9:	ja     0x56a3
    44cf:	movdqa xmm14,xmm0
    44d4:	psrldq xmm14,0x8
    44da:	movq   rax,xmm14
    44df:	add    rax,rax
    44e2:	je     0x44f8
    44e4:	shr    rax,0x35
    44e8:	sub    eax,0x201
    44ed:	cmp    eax,0x3fc
    44f2:	ja     0x56a3
    44f8:	movq   rax,xmm1
    44fd:	add    rax,rax
    4500:	je     0x4516
    4502:	shr    rax,0x35
    4506:	sub    eax,0x201
    450b:	cmp    eax,0x3fc
    4510:	ja     0x56a3
    4516:	movdqa xmm14,xmm1
    451b:	psrldq xmm14,0x8
    4521:	movq   rax,xmm14
    4526:	add    rax,rax
    4529:	je     0x453f
    452b:	shr    rax,0x35
    452f:	sub    eax,0x201
    4534:	cmp    eax,0x3fc
    4539:	ja     0x56a3
    453f:	addpd  xmm0,xmm1
    4543:	movdqa xmm7,xmm0
    4547:	movdqa xmm0,xmm7
    454b:	movdqu XMMWORD PTR [r12+0x130],xmm0
    4555:	movdqa xmm0,xmm4
    4559:	movdqa xmm1,xmm3
    455d:	pshufd xmm1,xmm1,0x44
    4562:	movq   rax,xmm0
    4567:	add    rax,rax
    456a:	je     0x4580
    456c:	shr    rax,0x35
    4570:	sub    eax,0x201
    4575:	cmp    eax,0x3fc
    457a:	ja     0x56c7
    4580:	movdqa xmm14,xmm0
    4585:	psrldq xmm14,0x8
    458b:	movq   rax,xmm14
    4590:	add    rax,rax
    4593:	je     0x45a9
    4595:	shr    rax,0x35
    4599:	sub    eax,0x201
    459e:	cmp    eax,0x3fc
    45a3:	ja     0x56c7
    45a9:	movq   rax,xmm1
    45ae:	add    rax,rax
    45b1:	je     0x45c7
    45b3:	shr    rax,0x35
    45b7:	sub    eax,0x201
    45bc:	cmp    eax,0x3fc
    45c1:	ja     0x56c7
    45c7:	movdqa xmm14,xmm1
    45cc:	psrldq xmm14,0x8
    45d2:	movq   rax,xmm14
    45d7:	add    rax,rax
    45da:	je     0x45f0
    45dc:	shr    rax,0x35
    45e0:	sub    eax,0x201
    45e5:	cmp    eax,0x3fc
    45ea:	ja     0x56c7
    45f0:	mulpd  xmm0,xmm1
    45f4:	movdqa xmm5,xmm0
    45f8:	movdqa xmm0,xmm5
    45fc:	movdqu XMMWORD PTR [r12+0x220],xmm0
    4606:	movdqa xmm0,xmm2
    460a:	movdqa xmm1,xmm3
    460e:	pshufd xmm1,xmm1,0x44
    4613:	movq   rax,xmm0
    4618:	add    rax,rax
    461b:	je     0x4631
    461d:	shr    rax,0x35
    4621:	sub    eax,0x201
    4626:	cmp    eax,0x3fc
    462b:	ja     0x56eb
    4631:	movdqa xmm14,xmm0
    4636:	psrldq xmm14,0x8
    463c:	movq   rax,xmm14
    4641:	add    rax,rax
    4644:	je     0x465a
    4646:	shr    rax,0x35
    464a:	sub    eax,0x201
    464f:	cmp    eax,0x3fc
    4654:	ja     0x56eb
    465a:	movq   rax,xmm1
    465f:	add    rax,rax
    4662:	je     0x4678
    4664:	shr    rax,0x35
    4668:	sub    eax,0x201
    466d:	cmp    eax,0x3fc
    4672:	ja     0x56eb
    4678:	movdqa xmm14,xmm1
    467d:	psrldq xmm14,0x8
    4683:	movq   rax,xmm14
    4688:	add    rax,rax
    468b:	je     0x46a1
    468d:	shr    rax,0x35
    4691:	sub    eax,0x201
    4696:	cmp    eax,0x3fc
    469b:	ja     0x56eb
    46a1:	mulpd  xmm0,xmm1
    46a5:	movdqa xmm4,xmm0
    46a9:	movdqa xmm0,xmm4
    46ad:	movdqu XMMWORD PTR [r12+0x120],xmm0
    46b7:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    46c1:	movdqa xmm2,xmm0
    46c5:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    46cf:	movdqa xmm3,xmm0
    46d3:	movdqa xmm0,xmm2
    46d7:	movdqa xmm1,xmm3
    46db:	movq   rax,xmm0
    46e0:	add    rax,rax
    46e3:	je     0x46f9
    46e5:	shr    rax,0x35
    46e9:	sub    eax,0x201
    46ee:	cmp    eax,0x3fc
    46f3:	ja     0x570f
    46f9:	movdqa xmm14,xmm0
    46fe:	psrldq xmm14,0x8
    4704:	movq   rax,xmm14
    4709:	add    rax,rax
    470c:	je     0x4722
    470e:	shr    rax,0x35
    4712:	sub    eax,0x201
    4717:	cmp    eax,0x3fc
    471c:	ja     0x570f
    4722:	movq   rax,xmm1
    4727:	add    rax,rax
    472a:	je     0x4740
    472c:	shr    rax,0x35
    4730:	sub    eax,0x201
    4735:	cmp    eax,0x3fc
    473a:	ja     0x570f
    4740:	movdqa xmm14,xmm1
    4745:	psrldq xmm14,0x8
    474b:	movq   rax,xmm14
    4750:	add    rax,rax
    4753:	je     0x4769
    4755:	shr    rax,0x35
    4759:	sub    eax,0x201
    475e:	cmp    eax,0x3fc
    4763:	ja     0x570f
    4769:	addpd  xmm0,xmm1
    476d:	movdqa xmm4,xmm0
    4771:	movdqa xmm0,xmm4
    4775:	movdqu XMMWORD PTR [r12+0x140],xmm0
    477f:	movdqu xmm0,XMMWORD PTR [r12+0x170]
    4789:	movdqa xmm2,xmm0
    478d:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    4797:	movdqa xmm3,xmm0
    479b:	movdqa xmm0,xmm2
    479f:	movdqa xmm1,xmm3
    47a3:	movq   rax,xmm0
    47a8:	add    rax,rax
    47ab:	je     0x47c1
    47ad:	shr    rax,0x35
    47b1:	sub    eax,0x201
    47b6:	cmp    eax,0x3fc
    47bb:	ja     0x5733
    47c1:	movdqa xmm14,xmm0
    47c6:	psrldq xmm14,0x8
    47cc:	movq   rax,xmm14
    47d1:	add    rax,rax
    47d4:	je     0x47ea
    47d6:	shr    rax,0x35
    47da:	sub    eax,0x201
    47df:	cmp    eax,0x3fc
    47e4:	ja     0x5733
    47ea:	movq   rax,xmm1
    47ef:	add    rax,rax
    47f2:	je     0x4808
    47f4:	shr    rax,0x35
    47f8:	sub    eax,0x201
    47fd:	cmp    eax,0x3fc
    4802:	ja     0x5733
    4808:	movdqa xmm14,xmm1
    480d:	psrldq xmm14,0x8
    4813:	movq   rax,xmm14
    4818:	add    rax,rax
    481b:	je     0x4831
    481d:	shr    rax,0x35
    4821:	sub    eax,0x201
    4826:	cmp    eax,0x3fc
    482b:	ja     0x5733
    4831:	addpd  xmm0,xmm1
    4835:	movdqa xmm4,xmm0
    4839:	movdqa xmm0,xmm4
    483d:	movdqu XMMWORD PTR [r12+0x150],xmm0
    4847:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    4851:	movdqa xmm2,xmm0
    4855:	movdqu xmm0,XMMWORD PTR [r12+0x220]
    485f:	movdqa xmm3,xmm0
    4863:	movdqa xmm0,xmm2
    4867:	movdqa xmm1,xmm3
    486b:	movq   rax,xmm0
    4870:	add    rax,rax
    4873:	je     0x4889
    4875:	shr    rax,0x35
    4879:	sub    eax,0x201
    487e:	cmp    eax,0x3fc
    4883:	ja     0x5757
    4889:	movdqa xmm14,xmm0
    488e:	psrldq xmm14,0x8
    4894:	movq   rax,xmm14
    4899:	add    rax,rax
    489c:	je     0x48b2
    489e:	shr    rax,0x35
    48a2:	sub    eax,0x201
    48a7:	cmp    eax,0x3fc
    48ac:	ja     0x5757
    48b2:	movq   rax,xmm1
    48b7:	add    rax,rax
    48ba:	je     0x48d0
    48bc:	shr    rax,0x35
    48c0:	sub    eax,0x201
    48c5:	cmp    eax,0x3fc
    48ca:	ja     0x5757
    48d0:	movdqa xmm14,xmm1
    48d5:	psrldq xmm14,0x8
    48db:	movq   rax,xmm14
    48e0:	add    rax,rax
    48e3:	je     0x48f9
    48e5:	shr    rax,0x35
    48e9:	sub    eax,0x201
    48ee:	cmp    eax,0x3fc
    48f3:	ja     0x5757
    48f9:	addpd  xmm0,xmm1
    48fd:	movdqa xmm4,xmm0
    4901:	movdqa xmm0,xmm4
    4905:	movdqu XMMWORD PTR [r12+0x160],xmm0
    490f:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    4919:	movdqa xmm2,xmm0
    491d:	movdqa xmm0,xmm7
    4921:	movdqa xmm1,xmm2
    4925:	movq   rax,xmm0
    492a:	add    rax,rax
    492d:	je     0x4943
    492f:	shr    rax,0x35
    4933:	sub    eax,0x201
    4938:	cmp    eax,0x3fc
    493d:	ja     0x577b
    4943:	movdqa xmm14,xmm0
    4948:	psrldq xmm14,0x8
    494e:	movq   rax,xmm14
    4953:	add    rax,rax
    4956:	je     0x496c
    4958:	shr    rax,0x35
    495c:	sub    eax,0x201
    4961:	cmp    eax,0x3fc
    4966:	ja     0x577b
    496c:	movq   rax,xmm1
    4971:	add    rax,rax
    4974:	je     0x498a
    4976:	shr    rax,0x35
    497a:	sub    eax,0x201
    497f:	cmp    eax,0x3fc
    4984:	ja     0x577b
    498a:	movdqa xmm14,xmm1
    498f:	psrldq xmm14,0x8
    4995:	movq   rax,xmm14
    499a:	add    rax,rax
    499d:	je     0x49b3
    499f:	shr    rax,0x35
    49a3:	sub    eax,0x201
    49a8:	cmp    eax,0x3fc
    49ad:	ja     0x577b
    49b3:	addpd  xmm0,xmm1
    49b7:	movdqa xmm3,xmm0
    49bb:	movdqa xmm0,xmm3
    49bf:	movdqu XMMWORD PTR [r12+0x120],xmm0
    49c9:	mov    r13,QWORD PTR [r12+0x60]
    49ce:	mov    r14,r13
    49d1:	add    r14,0x10
    49d5:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    49df:	movdqa xmm2,xmm0
    49e3:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    49ed:	movdqa xmm4,xmm0
    49f1:	stmxcsr DWORD PTR [rsp+0x114]
    49f9:	ldmxcsr DWORD PTR [rsp+0x110]
    4a01:	mov    r11d,DWORD PTR [rsp+0x114]
    4a09:	shr    r11d,1
    4a0c:	and    r11d,0x10
    4a10:	or     DWORD PTR [r12+0x314],r11d
    4a18:	movdqu XMMWORD PTR [r13+0x0],xmm2
    4a1e:	mov    r15d,0x0
    4a24:	mov    DWORD PTR [r12+0x32c],r15d
    4a2c:	movdqu XMMWORD PTR [r14],xmm4
    4a31:	mov    r14d,0x0
    4a37:	mov    DWORD PTR [r12+0x32c],r14d
    4a3f:	add    r13,0x20
    4a43:	mov    r14,r13
    4a46:	add    r14,0x10
    4a4a:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    4a54:	movdqa xmm2,xmm0
    4a58:	movdqu XMMWORD PTR [r13+0x0],xmm2
    4a5e:	mov    r13d,0x0
    4a64:	mov    DWORD PTR [r12+0x32c],r13d
    4a6c:	movdqu XMMWORD PTR [r14],xmm3
    4a71:	mov    r13d,0x0
    4a77:	mov    DWORD PTR [r12+0x32c],r13d
    4a7f:	mov    rcx,QWORD PTR [r12+0x380]
    4a87:	jrcxz  0x4a8e
    4a89:	jmp    0x7068
    4a8e:	push   QWORD PTR [rsp]
    4a91:	popf
    4a92:	je     0x4a9d
    4a98:	jmp    0xed8
    4a9d:	mov    r13d,DWORD PTR [r12+0x48]
    4aa2:	add    r13d,0x1
    4aa6:	mov    QWORD PTR [r12+0x48],r13
    4aab:	sub    r13d,0x1f4
    4ab2:	mov    rcx,QWORD PTR [r12+0x380]
    4aba:	jrcxz  0x4ac1
    4abc:	jmp    0x70f2
    4ac1:	pushf
    4ac2:	pop    r11
    4ac4:	mov    QWORD PTR [rsp],r11
    4ac8:	jne    0xec8
    4ace:	jmp    0x4ad3
    4ad3:	mov    r13d,0x0
    4ad9:	mov    QWORD PTR [r12+0x48],r13
    4ade:	mov    r13,QWORD PTR [r12+0xf8]
    4ae6:	mov    r14,r13
    4ae9:	add    r14,0x140
    4af0:	mov    r15,QWORD PTR [r14]
    4af3:	mov    QWORD PTR [r12+0xe8],r15
    4afb:	mov    r14,r13
    4afe:	add    r14,0x130
    4b05:	mov    r15,r14
    4b08:	add    r15,0x8
    4b0c:	mov    rbp,QWORD PTR [r14]
    4b0f:	mov    r14,QWORD PTR [r15]
    4b12:	mov    r15d,0x0
    4b18:	mov    QWORD PTR [r12+0x1a0],rbp
    4b20:	mov    QWORD PTR [r12+0x1a8],r15
    4b28:	mov    r15d,0x0
    4b2e:	mov    QWORD PTR [r12+0x190],r14
    4b36:	mov    QWORD PTR [r12+0x198],r15
    4b3e:	add    r13,0x120
    4b45:	mov    r14,r13
    4b48:	add    r14,0x8
    4b4c:	mov    r15,QWORD PTR [r13+0x0]
    4b50:	mov    r13,QWORD PTR [r14]
    4b53:	mov    r14d,0x0
    4b59:	mov    QWORD PTR [r12+0x1c0],r15
    4b61:	mov    QWORD PTR [r12+0x1c8],r14
    4b69:	mov    r14d,0x0
    4b6f:	mov    QWORD PTR [r12+0x1b0],r13
    4b77:	mov    QWORD PTR [r12+0x1b8],r14
    4b7f:	mov    r13,QWORD PTR [r12+0xf8]
    4b87:	mov    r14,r13
    4b8a:	add    r14,0x110
    4b91:	mov    r15,r14
    4b94:	add    r15,0x8
    4b98:	mov    rbp,QWORD PTR [r14]
    4b9b:	mov    r14,QWORD PTR [r15]
    4b9e:	mov    r15d,0x0
    4ba4:	mov    QWORD PTR [r12+0x1e0],rbp
    4bac:	mov    QWORD PTR [r12+0x1e8],r15
    4bb4:	mov    r15d,0x0
    4bba:	mov    QWORD PTR [r12+0x1d0],r14
    4bc2:	mov    QWORD PTR [r12+0x1d8],r15
    4bca:	add    r13,0x100
    4bd1:	mov    r14,r13
    4bd4:	add    r14,0x8
    4bd8:	mov    r15,QWORD PTR [r13+0x0]
    4bdc:	mov    r13,QWORD PTR [r14]
    4bdf:	mov    r14d,0x0
    4be5:	mov    QWORD PTR [r12+0x200],r15
    4bed:	mov    QWORD PTR [r12+0x208],r14
    4bf5:	mov    r14d,0x0
    4bfb:	mov    QWORD PTR [r12+0x1f0],r13
    4c03:	mov    QWORD PTR [r12+0x1f8],r14
    4c0b:	mov    r13d,0x430000
    4c11:	mov    QWORD PTR [r12+0x40],r13
    4c16:	mov    r13d,0x430510
    4c1c:	mov    r14,QWORD PTR [r13+0x0]
    4c20:	mov    r13d,0x0
    4c26:	mov    QWORD PTR [r12+0x110],r14
    4c2e:	mov    QWORD PTR [r12+0x118],r13
    4c36:	mov    r13,QWORD PTR [r12+0xf8]
    4c3e:	add    r13,0x150
    4c45:	mov    QWORD PTR [r12+0xf8],r13
    4c4d:	jmp    0x4c52
    4c52:	mov    r13,QWORD PTR [r12+0x48]
    4c57:	mov    r14,QWORD PTR [r12+0x50]
    4c5c:	mov    rcx,r13
    4c5f:	add    r14,rcx
    4c62:	movdqu xmm2,XMMWORD PTR [r14]
    4c67:	movdqa xmm0,xmm2
    4c6b:	movdqu XMMWORD PTR [r12+0x120],xmm0
    4c75:	add    r13,0x10
    4c79:	mov    QWORD PTR [r12+0x48],r13
    4c7e:	sub    r13,0x200
    4c85:	mov    r13,QWORD PTR [r12+0x128]
    4c8d:	mov    r14d,0x0
    4c93:	mov    QWORD PTR [r12+0x130],r13
    4c9b:	mov    QWORD PTR [r12+0x138],r14
    4ca3:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    4cad:	movdqa xmm2,xmm0
    4cb1:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    4cbb:	movdqa xmm3,xmm0
    4cbf:	pushf
    4cc0:	pop    r11
    4cc2:	mov    QWORD PTR [rsp],r11
    4cc6:	stmxcsr DWORD PTR [rsp+0x110]
    4cce:	mov    DWORD PTR [rsp+0x114],0x1f80
    4cd9:	ldmxcsr DWORD PTR [rsp+0x114]
    4ce1:	movdqa xmm0,xmm2
    4ce5:	movdqa xmm1,xmm3
    4ce9:	movq   rax,xmm0
    4cee:	add    rax,rax
    4cf1:	je     0x4d07
    4cf3:	shr    rax,0x35
    4cf7:	sub    eax,0x201
    4cfc:	cmp    eax,0x3fc
    4d01:	ja     0x579f
    4d07:	movq   rax,xmm1
    4d0c:	add    rax,rax
    4d0f:	je     0x4d25
    4d11:	shr    rax,0x35
    4d15:	sub    eax,0x201
    4d1a:	cmp    eax,0x3fc
    4d1f:	ja     0x579f
    4d25:	movq   xmm0,xmm0
    4d29:	movq   xmm1,xmm1
    4d2d:	addsd  xmm0,xmm1
    4d31:	movdqa xmm4,xmm0
    4d35:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    4d3f:	movdqa xmm2,xmm0
    4d43:	movdqa xmm0,xmm4
    4d47:	movdqa xmm1,xmm2
    4d4b:	movq   rax,xmm0
    4d50:	add    rax,rax
    4d53:	je     0x4d69
    4d55:	shr    rax,0x35
    4d59:	sub    eax,0x201
    4d5e:	cmp    eax,0x3fc
    4d63:	ja     0x57c3
    4d69:	movq   rax,xmm1
    4d6e:	add    rax,rax
    4d71:	je     0x4d87
    4d73:	shr    rax,0x35
    4d77:	sub    eax,0x201
    4d7c:	cmp    eax,0x3fc
    4d81:	ja     0x57c3
    4d87:	movq   xmm0,xmm0
    4d8b:	movq   xmm1,xmm1
    4d8f:	addsd  xmm0,xmm1
    4d93:	movdqa xmm3,xmm0
    4d97:	movdqa xmm0,xmm3
    4d9b:	movdqu XMMWORD PTR [r12+0x110],xmm0
    4da5:	stmxcsr DWORD PTR [rsp+0x114]
    4dad:	ldmxcsr DWORD PTR [rsp+0x110]
    4db5:	mov    r11d,DWORD PTR [rsp+0x114]
    4dbd:	shr    r11d,1
    4dc0:	and    r11d,0x10
    4dc4:	or     DWORD PTR [r12+0x314],r11d
    4dcc:	mov    rcx,QWORD PTR [r12+0x380]
    4dd4:	jrcxz  0x4ddb
    4dd6:	jmp    0x7184
    4ddb:	push   QWORD PTR [rsp]
    4dde:	popf
    4ddf:	jne    0x4c52
    4de5:	jmp    0x4dea
    4dea:	mov    r13,QWORD PTR [r12+0x40]
    4def:	add    r13,0x510
    4df6:	mov    r14,QWORD PTR [r12+0x110]
    4dfe:	mov    QWORD PTR [r13+0x0],r14
    4e02:	mov    r13d,0x0
    4e08:	mov    DWORD PTR [r12+0x32c],r13d
    4e10:	mov    rcx,QWORD PTR [r12+0x380]
    4e18:	jrcxz  0x4e1f
    4e1a:	jmp    0x720e
    4e1f:	mov    r13,QWORD PTR [r12+0xf0]
    4e27:	mov    QWORD PTR [r12+0x100],r13
    4e2f:	mov    r11,QWORD PTR [rsp]
    4e33:	mov    QWORD PTR [r12+0x398],r11
    4e3b:	mov    rdi,QWORD PTR [r12+0x100]
    4e43:	add    rsp,0x150
    4e4a:	movabs r11,0x6478df27b0a0
    4e54:	jmp    r11
    4e57:	movdqa xmm0,xmm2
    4e5b:	movdqa xmm1,xmm3
    4e5f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4e68:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4e71:	call   0x57f0
    4e76:	jmp    0x5be
    4e7b:	movdqa xmm0,xmm2
    4e7f:	movdqa xmm1,xmm3
    4e83:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4e8c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4e95:	call   0x57f0
    4e9a:	jmp    0x6eb
    4e9f:	movdqa xmm0,xmm3
    4ea3:	movdqa xmm1,xmm4
    4ea7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4eb0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4eb9:	call   0x58d0
    4ebe:	jmp    0x11a1
    4ec3:	movdqa xmm0,xmm2
    4ec7:	movdqa xmm1,xmm4
    4ecb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4ed4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4edd:	call   0x5a60
    4ee2:	jmp    0x1260
    4ee7:	movdqa xmm0,xmm3
    4eeb:	movdqa xmm1,xmm2
    4eef:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4ef8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4f01:	call   0x5bf0
    4f06:	jmp    0x1336
    4f0b:	movdqa xmm0,xmm3
    4f0f:	movdqa xmm1,xmm2
    4f13:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4f1c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4f25:	call   0x5bf0
    4f2a:	jmp    0x13f0
    4f2f:	movdqa xmm0,xmm2
    4f33:	movdqa xmm1,xmm3
    4f37:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4f40:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4f49:	call   0x5bf0
    4f4e:	jmp    0x14b8
    4f53:	movdqa xmm0,xmm2
    4f57:	movdqa xmm1,xmm3
    4f5b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4f64:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4f6d:	call   0x5d70
    4f72:	jmp    0x15c3
    4f77:	movdqa xmm0,xmm2
    4f7b:	movdqa xmm1,xmm3
    4f7f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4f88:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4f91:	call   0x5ef0
    4f96:	jmp    0x16e0
    4f9b:	movdqa xmm0,xmm2
    4f9f:	movdqa xmm1,xmm3
    4fa3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4fac:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4fb5:	call   0x5ef0
    4fba:	jmp    0x17a8
    4fbf:	movdqa xmm0,xmm2
    4fc3:	movdqa xmm1,xmm3
    4fc7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4fd0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4fd9:	call   0x5ef0
    4fde:	jmp    0x1862
    4fe3:	movdqa xmm0,xmm2
    4fe7:	movdqa xmm1,xmm4
    4feb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    4ff4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    4ffd:	call   0x6070
    5002:	jmp    0x1aa7
    5007:	movdqa xmm0,xmm4
    500b:	movdqa xmm1,xmm5
    500f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5018:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5021:	call   0x6200
    5026:	jmp    0x1bcc
    502b:	movdqa xmm0,xmm4
    502f:	movdqa xmm1,xmm5
    5033:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    503c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5045:	call   0x6200
    504a:	jmp    0x1c94
    504f:	movdqa xmm0,xmm3
    5053:	movdqa xmm1,xmm4
    5057:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5060:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5069:	call   0x5a60
    506e:	jmp    0x1d53
    5073:	movdqa xmm0,xmm2
    5077:	movdqa xmm1,xmm3
    507b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5084:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    508d:	call   0x5a60
    5092:	jmp    0x1e12
    5097:	movdqa xmm0,xmm2
    509b:	movdqa xmm1,xmm4
    509f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    50a8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    50b1:	call   0x5a60
    50b6:	jmp    0x1f38
    50bb:	movdqa xmm0,xmm2
    50bf:	movdqa xmm1,xmm3
    50c3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    50cc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    50d5:	call   0x5d70
    50da:	jmp    0x203f
    50df:	movdqa xmm0,xmm3
    50e3:	movdqa xmm1,xmm4
    50e7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    50f0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    50f9:	call   0x6070
    50fe:	jmp    0x21f4
    5103:	movdqa xmm0,xmm2
    5107:	movdqa xmm1,xmm3
    510b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5114:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    511d:	call   0x5d70
    5122:	jmp    0x22b3
    5127:	movdqa xmm0,xmm3
    512b:	movdqa xmm1,xmm4
    512f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5138:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5141:	call   0x6070
    5146:	jmp    0x23e0
    514b:	movdqa xmm0,xmm3
    514f:	movdqa xmm1,xmm4
    5153:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    515c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5165:	call   0x6070
    516a:	jmp    0x24a8
    516f:	movdqa xmm0,xmm2
    5173:	movdqa xmm1,xmm3
    5177:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5180:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5189:	call   0x5d70
    518e:	jmp    0x258b
    5193:	movdqa xmm0,xmm3
    5197:	movdqa xmm1,xmm4
    519b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    51a4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    51ad:	call   0x6070
    51b2:	jmp    0x26b8
    51b7:	movdqa xmm0,xmm3
    51bb:	movdqa xmm1,xmm4
    51bf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    51c8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    51d1:	call   0x5a60
    51d6:	jmp    0x2785
    51db:	movdqa xmm0,xmm2
    51df:	movdqa xmm1,xmm4
    51e3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    51ec:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    51f5:	call   0x6390
    51fa:	jmp    0x2852
    51ff:	movdqa xmm0,xmm3
    5203:	movdqa xmm1,xmm4
    5207:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5210:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5219:	call   0x6070
    521e:	jmp    0x2981
    5223:	movdqa xmm0,xmm2
    5227:	movdqa xmm1,xmm3
    522b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5234:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    523d:	call   0x5d70
    5242:	jmp    0x2a88
    5247:	movdqa xmm0,xmm2
    524b:	movdqa xmm1,xmm4
    524f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5258:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5261:	call   0x6070
    5266:	jmp    0x2baa
    526b:	movdqa xmm0,xmm2
    526f:	movdqa xmm1,xmm3
    5273:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    527c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5285:	call   0x5d70
    528a:	jmp    0x2c69
    528f:	movdqa xmm0,xmm2
    5293:	movdqa xmm1,xmm3
    5297:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    52a0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    52a9:	call   0x5ef0
    52ae:	jmp    0x2d31
    52b3:	movdqa xmm0,xmm2
    52b7:	movdqa xmm1,xmm3
    52bb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    52c4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    52cd:	call   0x5d70
    52d2:	jmp    0x2dfe
    52d7:	movdqa xmm0,xmm2
    52db:	movdqa xmm1,xmm3
    52df:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    52e8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    52f1:	call   0x5d70
    52f6:	jmp    0x2ebd
    52fb:	movdqa xmm0,xmm2
    52ff:	movdqa xmm1,xmm4
    5303:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    530c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5315:	call   0x6070
    531a:	jmp    0x2f85
    531f:	movdqa xmm0,xmm2
    5323:	movdqa xmm1,xmm4
    5327:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5330:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5339:	call   0x6070
    533e:	jmp    0x304d
    5343:	movdqa xmm0,xmm2
    5347:	movdqa xmm1,xmm3
    534b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5354:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    535d:	call   0x5d70
    5362:	jmp    0x310c
    5367:	movdqa xmm0,xmm2
    536b:	movdqa xmm1,xmm3
    536f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5378:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5381:	call   0x5d70
    5386:	jmp    0x31cb
    538b:	movdqa xmm0,xmm2
    538f:	movdqa xmm1,xmm3
    5393:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    539c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    53a5:	call   0x5ef0
    53aa:	jmp    0x3293
    53af:	movdqa xmm0,xmm2
    53b3:	movdqa xmm1,xmm3
    53b7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    53c0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    53c9:	call   0x5ef0
    53ce:	jmp    0x335b
    53d3:	movdqa xmm0,xmm2
    53d7:	movdqa xmm1,xmm3
    53db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    53e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    53ed:	call   0x5d70
    53f2:	jmp    0x3428
    53f7:	movdqa xmm0,xmm2
    53fb:	movdqa xmm1,xmm3
    53ff:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5408:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5411:	call   0x5ef0
    5416:	jmp    0x34f0
    541b:	movdqa xmm0,xmm2
    541f:	movdqa xmm1,xmm3
    5423:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    542c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5435:	call   0x5ef0
    543a:	jmp    0x35b8
    543f:	movdqa xmm0,xmm2
    5443:	movdqa xmm1,xmm3
    5447:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5450:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5459:	call   0x5d70
    545e:	jmp    0x3753
    5463:	movdqa xmm0,xmm2
    5467:	movdqa xmm1,xmm4
    546b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5474:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    547d:	call   0x6070
    5482:	jmp    0x381b
    5487:	movdqa xmm0,xmm2
    548b:	movdqa xmm1,xmm4
    548f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5498:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    54a1:	call   0x6070
    54a6:	jmp    0x38e3
    54ab:	movdqa xmm0,xmm2
    54af:	movdqa xmm1,xmm3
    54b3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    54bc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    54c5:	call   0x5d70
    54ca:	jmp    0x39a2
    54cf:	movdqa xmm0,xmm2
    54d3:	movdqa xmm1,xmm3
    54d7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    54e0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    54e9:	call   0x5d70
    54ee:	jmp    0x3a6f
    54f3:	movdqa xmm0,xmm2
    54f7:	movdqa xmm1,xmm3
    54fb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5504:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    550d:	call   0x5d70
    5512:	jmp    0x3b3c
    5517:	movdqa xmm0,xmm2
    551b:	movdqa xmm1,xmm4
    551f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5528:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5531:	call   0x6070
    5536:	jmp    0x3c04
    553b:	movdqa xmm0,xmm2
    553f:	movdqa xmm1,xmm3
    5543:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    554c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5555:	call   0x5d70
    555a:	jmp    0x3cc3
    555f:	movdqa xmm0,xmm2
    5563:	movdqa xmm1,xmm4
    5567:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5570:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5579:	call   0x6070
    557e:	jmp    0x3d8b
    5583:	movdqa xmm0,xmm2
    5587:	movdqa xmm1,xmm3
    558b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5594:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    559d:	call   0x5d70
    55a2:	jmp    0x3e4a
    55a7:	movdqa xmm0,xmm2
    55ab:	movdqa xmm1,xmm3
    55af:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    55b8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    55c1:	call   0x5ef0
    55c6:	jmp    0x3f12
    55cb:	movdqa xmm0,xmm2
    55cf:	movdqa xmm1,xmm3
    55d3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    55dc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    55e5:	call   0x5d70
    55ea:	jmp    0x3fdf
    55ef:	movdqa xmm0,xmm2
    55f3:	movdqa xmm1,xmm3
    55f7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5600:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5609:	call   0x5ef0
    560e:	jmp    0x40a7
    5613:	movdqa xmm0,xmm3
    5617:	movdqa xmm1,xmm4
    561b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5624:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    562d:	call   0x6070
    5632:	jmp    0x41d3
    5637:	movdqa xmm0,xmm2
    563b:	movdqa xmm1,xmm3
    563f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5648:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5651:	call   0x5d70
    5656:	jmp    0x4292
    565b:	movdqa xmm0,xmm2
    565f:	movdqa xmm1,xmm3
    5663:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    566c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5675:	call   0x5d70
    567a:	jmp    0x4351
    567f:	movdqa xmm0,xmm2
    5683:	movdqa xmm1,xmm4
    5687:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5690:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5699:	call   0x6070
    569e:	jmp    0x4419
    56a3:	movdqa xmm0,xmm5
    56a7:	movdqa xmm1,xmm6
    56ab:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    56b4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    56bd:	call   0x6510
    56c2:	jmp    0x4543
    56c7:	movdqa xmm0,xmm4
    56cb:	movdqa xmm1,xmm3
    56cf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    56d8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    56e1:	call   0x66b0
    56e6:	jmp    0x45f4
    56eb:	movdqa xmm0,xmm2
    56ef:	movdqa xmm1,xmm3
    56f3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    56fc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5705:	call   0x6840
    570a:	jmp    0x46a5
    570f:	movdqa xmm0,xmm2
    5713:	movdqa xmm1,xmm3
    5717:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5720:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5729:	call   0x69d0
    572e:	jmp    0x476d
    5733:	movdqa xmm0,xmm2
    5737:	movdqa xmm1,xmm3
    573b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5744:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    574d:	call   0x69d0
    5752:	jmp    0x4835
    5757:	movdqa xmm0,xmm2
    575b:	movdqa xmm1,xmm3
    575f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    5768:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5771:	call   0x69d0
    5776:	jmp    0x48fd
    577b:	movdqa xmm0,xmm7
    577f:	movdqa xmm1,xmm2
    5783:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    578c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    5795:	call   0x6b60
    579a:	jmp    0x49b7
    579f:	movdqa xmm0,xmm2
    57a3:	movdqa xmm1,xmm3
    57a7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    57b0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    57b9:	call   0x6ce0
    57be:	jmp    0x4d31
    57c3:	movdqa xmm0,xmm4
    57c7:	movdqa xmm1,xmm2
    57cb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    57d4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    57dd:	call   0x6e60
    57e2:	jmp    0x4d93
    57e7:	nop    WORD PTR [rax+rax*1+0x0]
    57f0:	sub    rsp,0x8
    57f4:	stmxcsr DWORD PTR [rsp+0x124]
    57fc:	ldmxcsr DWORD PTR [rsp+0x120]
    5804:	mov    r11d,DWORD PTR [rsp+0x124]
    580c:	shr    r11d,1
    580f:	and    r11d,0x10
    5813:	or     DWORD PTR [r12+0x314],r11d
    581b:	mov    QWORD PTR [r12+0x378],0x3
    5827:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    582d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5833:	mov    QWORD PTR [r12+0x108],rbx
    583b:	stmxcsr DWORD PTR [r12-0x28]
    5841:	ldmxcsr DWORD PTR [r12-0x38]
    5847:	lea    rdi,[rsp+0x110]
    584f:	lea    rsi,[rsp+0xf0]
    5857:	lea    rdx,[rsp+0x100]
    585f:	mov    ecx,0x16
    5864:	mov    r8d,0x0
    586a:	lea    r9,[r12+0x314]
    5872:	movabs r11,0x6478df0e61b0
    587c:	call   r11
    587f:	ldmxcsr DWORD PTR [r12-0x28]
    5885:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    588b:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5891:	mov    rbx,QWORD PTR [r12+0x108]
    5899:	mov    QWORD PTR [r12+0x378],0x2
    58a5:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    58ae:	stmxcsr DWORD PTR [rsp+0x120]
    58b6:	mov    DWORD PTR [rsp+0x124],0x1f80
    58c1:	ldmxcsr DWORD PTR [rsp+0x124]
    58c9:	add    rsp,0x8
    58cd:	ret
    58ce:	xchg   ax,ax
    58d0:	sub    rsp,0x8
    58d4:	stmxcsr DWORD PTR [rsp+0x124]
    58dc:	ldmxcsr DWORD PTR [rsp+0x120]
    58e4:	mov    r11d,DWORD PTR [rsp+0x124]
    58ec:	shr    r11d,1
    58ef:	and    r11d,0x10
    58f3:	or     DWORD PTR [r12+0x314],r11d
    58fb:	mov    QWORD PTR [r12+0x378],0x3
    5907:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    590d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5913:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    5919:	push   rdx
    591a:	push   rsi
    591b:	push   r10
    591d:	push   r11
    591f:	mov    rdx,QWORD PTR [rsp+0x30]
    5924:	mov    r10d,edx
    5927:	and    r10d,0xc0
    592e:	shl    r10d,0x18
    5932:	mov    r11d,edx
    5935:	and    r11d,0x1
    5939:	shl    r11d,0x1d
    593d:	or     r10d,r11d
    5940:	mov    r11d,edx
    5943:	and    r11d,0x800
    594a:	shl    r11d,0x11
    594e:	or     r10d,r11d
    5951:	btc    r10,0x1d
    5956:	mov    r11d,0xf0000000
    595c:	and    r11,r10
    595f:	movabs rsi,0xffffffff0fffffff
    5969:	and    rbx,rsi
    596c:	or     rbx,r11
    596f:	pop    r11
    5971:	pop    r10
    5973:	pop    rsi
    5974:	pop    rdx
    5975:	mov    QWORD PTR [r12+0x108],rbx
    597d:	stmxcsr DWORD PTR [r12-0x28]
    5983:	ldmxcsr DWORD PTR [r12-0x38]
    5989:	lea    rdi,[rsp+0x110]
    5991:	lea    rsi,[rsp+0xf0]
    5999:	lea    rdx,[rsp+0x100]
    59a1:	mov    ecx,0x16
    59a6:	mov    r8d,0x0
    59ac:	lea    r9,[r12+0x314]
    59b4:	movabs r11,0x6478df0e61b0
    59be:	call   r11
    59c1:	ldmxcsr DWORD PTR [r12-0x28]
    59c7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    59cd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    59d3:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    59d9:	mov    rbx,QWORD PTR [r12+0x108]
    59e1:	mov    QWORD PTR [r12+0x378],0x2
    59ed:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    59f6:	pushf
    59f7:	pop    rdx
    59f8:	and    rdx,0xfffffffffffff73e
    59ff:	mov    rax,rbx
    5a02:	shr    rax,0x18
    5a06:	and    eax,0xc0
    5a0b:	or     rdx,rax
    5a0e:	mov    rax,rbx
    5a11:	shr    rax,0x1d
    5a15:	and    eax,0x1
    5a18:	xor    eax,0x1
    5a1b:	or     rdx,rax
    5a1e:	mov    rax,rbx
    5a21:	shr    rax,0x11
    5a25:	and    eax,0x800
    5a2a:	or     rdx,rax
    5a2d:	mov    QWORD PTR [rsp+0x10],rdx
    5a32:	stmxcsr DWORD PTR [rsp+0x120]
    5a3a:	mov    DWORD PTR [rsp+0x124],0x1f80
    5a45:	ldmxcsr DWORD PTR [rsp+0x124]
    5a4d:	add    rsp,0x8
    5a51:	ret
    5a52:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    5a60:	sub    rsp,0x8
    5a64:	stmxcsr DWORD PTR [rsp+0x124]
    5a6c:	ldmxcsr DWORD PTR [rsp+0x120]
    5a74:	mov    r11d,DWORD PTR [rsp+0x124]
    5a7c:	shr    r11d,1
    5a7f:	and    r11d,0x10
    5a83:	or     DWORD PTR [r12+0x314],r11d
    5a8b:	mov    QWORD PTR [r12+0x378],0x3
    5a97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5a9d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5aa3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    5aa9:	push   rdx
    5aaa:	push   rsi
    5aab:	push   r10
    5aad:	push   r11
    5aaf:	mov    rdx,QWORD PTR [rsp+0x30]
    5ab4:	mov    r10d,edx
    5ab7:	and    r10d,0xc0
    5abe:	shl    r10d,0x18
    5ac2:	mov    r11d,edx
    5ac5:	and    r11d,0x1
    5ac9:	shl    r11d,0x1d
    5acd:	or     r10d,r11d
    5ad0:	mov    r11d,edx
    5ad3:	and    r11d,0x800
    5ada:	shl    r11d,0x11
    5ade:	or     r10d,r11d
    5ae1:	btc    r10,0x1d
    5ae6:	mov    r11d,0xf0000000
    5aec:	and    r11,r10
    5aef:	movabs rsi,0xffffffff0fffffff
    5af9:	and    rbx,rsi
    5afc:	or     rbx,r11
    5aff:	pop    r11
    5b01:	pop    r10
    5b03:	pop    rsi
    5b04:	pop    rdx
    5b05:	mov    QWORD PTR [r12+0x108],rbx
    5b0d:	stmxcsr DWORD PTR [r12-0x28]
    5b13:	ldmxcsr DWORD PTR [r12-0x38]
    5b19:	lea    rdi,[rsp+0x110]
    5b21:	lea    rsi,[rsp+0xf0]
    5b29:	lea    rdx,[rsp+0x100]
    5b31:	mov    ecx,0x56
    5b36:	mov    r8d,0x0
    5b3c:	lea    r9,[r12+0x314]
    5b44:	movabs r11,0x6478df0e61b0
    5b4e:	call   r11
    5b51:	ldmxcsr DWORD PTR [r12-0x28]
    5b57:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5b5d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5b63:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    5b69:	mov    rbx,QWORD PTR [r12+0x108]
    5b71:	mov    QWORD PTR [r12+0x378],0x2
    5b7d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5b86:	pushf
    5b87:	pop    rdx
    5b88:	and    rdx,0xfffffffffffff73e
    5b8f:	mov    rax,rbx
    5b92:	shr    rax,0x18
    5b96:	and    eax,0xc0
    5b9b:	or     rdx,rax
    5b9e:	mov    rax,rbx
    5ba1:	shr    rax,0x1d
    5ba5:	and    eax,0x1
    5ba8:	xor    eax,0x1
    5bab:	or     rdx,rax
    5bae:	mov    rax,rbx
    5bb1:	shr    rax,0x11
    5bb5:	and    eax,0x800
    5bba:	or     rdx,rax
    5bbd:	mov    QWORD PTR [rsp+0x10],rdx
    5bc2:	stmxcsr DWORD PTR [rsp+0x120]
    5bca:	mov    DWORD PTR [rsp+0x124],0x1f80
    5bd5:	ldmxcsr DWORD PTR [rsp+0x124]
    5bdd:	add    rsp,0x8
    5be1:	ret
    5be2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    5bf0:	sub    rsp,0x8
    5bf4:	stmxcsr DWORD PTR [rsp+0x124]
    5bfc:	ldmxcsr DWORD PTR [rsp+0x120]
    5c04:	mov    r11d,DWORD PTR [rsp+0x124]
    5c0c:	shr    r11d,1
    5c0f:	and    r11d,0x10
    5c13:	or     DWORD PTR [r12+0x314],r11d
    5c1b:	mov    QWORD PTR [r12+0x378],0x3
    5c27:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5c2d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5c33:	push   rdx
    5c34:	push   rsi
    5c35:	push   r10
    5c37:	push   r11
    5c39:	mov    rdx,QWORD PTR [rsp+0x30]
    5c3e:	mov    r10d,edx
    5c41:	and    r10d,0xc0
    5c48:	shl    r10d,0x18
    5c4c:	mov    r11d,edx
    5c4f:	and    r11d,0x1
    5c53:	shl    r11d,0x1d
    5c57:	or     r10d,r11d
    5c5a:	mov    r11d,edx
    5c5d:	and    r11d,0x800
    5c64:	shl    r11d,0x11
    5c68:	or     r10d,r11d
    5c6b:	btc    r10,0x1d
    5c70:	mov    r11d,0xf0000000
    5c76:	and    r11,r10
    5c79:	movabs rsi,0xffffffff0fffffff
    5c83:	and    rbx,rsi
    5c86:	or     rbx,r11
    5c89:	pop    r11
    5c8b:	pop    r10
    5c8d:	pop    rsi
    5c8e:	pop    rdx
    5c8f:	mov    QWORD PTR [r12+0x108],rbx
    5c97:	stmxcsr DWORD PTR [r12-0x28]
    5c9d:	ldmxcsr DWORD PTR [r12-0x38]
    5ca3:	lea    rdi,[rsp+0x110]
    5cab:	lea    rsi,[rsp+0xf0]
    5cb3:	lea    rdx,[rsp+0x100]
    5cbb:	mov    ecx,0x16
    5cc0:	mov    r8d,0x0
    5cc6:	lea    r9,[r12+0x314]
    5cce:	movabs r11,0x6478df0e61b0
    5cd8:	call   r11
    5cdb:	ldmxcsr DWORD PTR [r12-0x28]
    5ce1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5ce7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5ced:	mov    rbx,QWORD PTR [r12+0x108]
    5cf5:	mov    QWORD PTR [r12+0x378],0x2
    5d01:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5d0a:	pushf
    5d0b:	pop    rdx
    5d0c:	and    rdx,0xfffffffffffff73e
    5d13:	mov    rax,rbx
    5d16:	shr    rax,0x18
    5d1a:	and    eax,0xc0
    5d1f:	or     rdx,rax
    5d22:	mov    rax,rbx
    5d25:	shr    rax,0x1d
    5d29:	and    eax,0x1
    5d2c:	xor    eax,0x1
    5d2f:	or     rdx,rax
    5d32:	mov    rax,rbx
    5d35:	shr    rax,0x11
    5d39:	and    eax,0x800
    5d3e:	or     rdx,rax
    5d41:	mov    QWORD PTR [rsp+0x10],rdx
    5d46:	stmxcsr DWORD PTR [rsp+0x120]
    5d4e:	mov    DWORD PTR [rsp+0x124],0x1f80
    5d59:	ldmxcsr DWORD PTR [rsp+0x124]
    5d61:	add    rsp,0x8
    5d65:	ret
    5d66:	data16 nop WORD PTR [rax+rax*1+0x0]
    5d70:	sub    rsp,0x8
    5d74:	stmxcsr DWORD PTR [rsp+0x124]
    5d7c:	ldmxcsr DWORD PTR [rsp+0x120]
    5d84:	mov    r11d,DWORD PTR [rsp+0x124]
    5d8c:	shr    r11d,1
    5d8f:	and    r11d,0x10
    5d93:	or     DWORD PTR [r12+0x314],r11d
    5d9b:	mov    QWORD PTR [r12+0x378],0x3
    5da7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5dad:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5db3:	push   rdx
    5db4:	push   rsi
    5db5:	push   r10
    5db7:	push   r11
    5db9:	mov    rdx,QWORD PTR [rsp+0x30]
    5dbe:	mov    r10d,edx
    5dc1:	and    r10d,0xc0
    5dc8:	shl    r10d,0x18
    5dcc:	mov    r11d,edx
    5dcf:	and    r11d,0x1
    5dd3:	shl    r11d,0x1d
    5dd7:	or     r10d,r11d
    5dda:	mov    r11d,edx
    5ddd:	and    r11d,0x800
    5de4:	shl    r11d,0x11
    5de8:	or     r10d,r11d
    5deb:	btc    r10,0x1d
    5df0:	mov    r11d,0xf0000000
    5df6:	and    r11,r10
    5df9:	movabs rsi,0xffffffff0fffffff
    5e03:	and    rbx,rsi
    5e06:	or     rbx,r11
    5e09:	pop    r11
    5e0b:	pop    r10
    5e0d:	pop    rsi
    5e0e:	pop    rdx
    5e0f:	mov    QWORD PTR [r12+0x108],rbx
    5e17:	stmxcsr DWORD PTR [r12-0x28]
    5e1d:	ldmxcsr DWORD PTR [r12-0x38]
    5e23:	lea    rdi,[rsp+0x110]
    5e2b:	lea    rsi,[rsp+0xf0]
    5e33:	lea    rdx,[rsp+0x100]
    5e3b:	mov    ecx,0x56
    5e40:	mov    r8d,0x0
    5e46:	lea    r9,[r12+0x314]
    5e4e:	movabs r11,0x6478df0e61b0
    5e58:	call   r11
    5e5b:	ldmxcsr DWORD PTR [r12-0x28]
    5e61:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5e67:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5e6d:	mov    rbx,QWORD PTR [r12+0x108]
    5e75:	mov    QWORD PTR [r12+0x378],0x2
    5e81:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    5e8a:	pushf
    5e8b:	pop    rdx
    5e8c:	and    rdx,0xfffffffffffff73e
    5e93:	mov    rax,rbx
    5e96:	shr    rax,0x18
    5e9a:	and    eax,0xc0
    5e9f:	or     rdx,rax
    5ea2:	mov    rax,rbx
    5ea5:	shr    rax,0x1d
    5ea9:	and    eax,0x1
    5eac:	xor    eax,0x1
    5eaf:	or     rdx,rax
    5eb2:	mov    rax,rbx
    5eb5:	shr    rax,0x11
    5eb9:	and    eax,0x800
    5ebe:	or     rdx,rax
    5ec1:	mov    QWORD PTR [rsp+0x10],rdx
    5ec6:	stmxcsr DWORD PTR [rsp+0x120]
    5ece:	mov    DWORD PTR [rsp+0x124],0x1f80
    5ed9:	ldmxcsr DWORD PTR [rsp+0x124]
    5ee1:	add    rsp,0x8
    5ee5:	ret
    5ee6:	data16 nop WORD PTR [rax+rax*1+0x0]
    5ef0:	sub    rsp,0x8
    5ef4:	stmxcsr DWORD PTR [rsp+0x124]
    5efc:	ldmxcsr DWORD PTR [rsp+0x120]
    5f04:	mov    r11d,DWORD PTR [rsp+0x124]
    5f0c:	shr    r11d,1
    5f0f:	and    r11d,0x10
    5f13:	or     DWORD PTR [r12+0x314],r11d
    5f1b:	mov    QWORD PTR [r12+0x378],0x3
    5f27:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    5f2d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    5f33:	push   rdx
    5f34:	push   rsi
    5f35:	push   r10
    5f37:	push   r11
    5f39:	mov    rdx,QWORD PTR [rsp+0x30]
    5f3e:	mov    r10d,edx
    5f41:	and    r10d,0xc0
    5f48:	shl    r10d,0x18
    5f4c:	mov    r11d,edx
    5f4f:	and    r11d,0x1
    5f53:	shl    r11d,0x1d
    5f57:	or     r10d,r11d
    5f5a:	mov    r11d,edx
    5f5d:	and    r11d,0x800
    5f64:	shl    r11d,0x11
    5f68:	or     r10d,r11d
    5f6b:	btc    r10,0x1d
    5f70:	mov    r11d,0xf0000000
    5f76:	and    r11,r10
    5f79:	movabs rsi,0xffffffff0fffffff
    5f83:	and    rbx,rsi
    5f86:	or     rbx,r11
    5f89:	pop    r11
    5f8b:	pop    r10
    5f8d:	pop    rsi
    5f8e:	pop    rdx
    5f8f:	mov    QWORD PTR [r12+0x108],rbx
    5f97:	stmxcsr DWORD PTR [r12-0x28]
    5f9d:	ldmxcsr DWORD PTR [r12-0x38]
    5fa3:	lea    rdi,[rsp+0x110]
    5fab:	lea    rsi,[rsp+0xf0]
    5fb3:	lea    rdx,[rsp+0x100]
    5fbb:	mov    ecx,0x14
    5fc0:	mov    r8d,0x0
    5fc6:	lea    r9,[r12+0x314]
    5fce:	movabs r11,0x6478df0e61b0
    5fd8:	call   r11
    5fdb:	ldmxcsr DWORD PTR [r12-0x28]
    5fe1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    5fe7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    5fed:	mov    rbx,QWORD PTR [r12+0x108]
    5ff5:	mov    QWORD PTR [r12+0x378],0x2
    6001:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    600a:	pushf
    600b:	pop    rdx
    600c:	and    rdx,0xfffffffffffff73e
    6013:	mov    rax,rbx
    6016:	shr    rax,0x18
    601a:	and    eax,0xc0
    601f:	or     rdx,rax
    6022:	mov    rax,rbx
    6025:	shr    rax,0x1d
    6029:	and    eax,0x1
    602c:	xor    eax,0x1
    602f:	or     rdx,rax
    6032:	mov    rax,rbx
    6035:	shr    rax,0x11
    6039:	and    eax,0x800
    603e:	or     rdx,rax
    6041:	mov    QWORD PTR [rsp+0x10],rdx
    6046:	stmxcsr DWORD PTR [rsp+0x120]
    604e:	mov    DWORD PTR [rsp+0x124],0x1f80
    6059:	ldmxcsr DWORD PTR [rsp+0x124]
    6061:	add    rsp,0x8
    6065:	ret
    6066:	data16 nop WORD PTR [rax+rax*1+0x0]
    6070:	sub    rsp,0x8
    6074:	stmxcsr DWORD PTR [rsp+0x124]
    607c:	ldmxcsr DWORD PTR [rsp+0x120]
    6084:	mov    r11d,DWORD PTR [rsp+0x124]
    608c:	shr    r11d,1
    608f:	and    r11d,0x10
    6093:	or     DWORD PTR [r12+0x314],r11d
    609b:	mov    QWORD PTR [r12+0x378],0x3
    60a7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    60ad:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    60b3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    60b9:	push   rdx
    60ba:	push   rsi
    60bb:	push   r10
    60bd:	push   r11
    60bf:	mov    rdx,QWORD PTR [rsp+0x30]
    60c4:	mov    r10d,edx
    60c7:	and    r10d,0xc0
    60ce:	shl    r10d,0x18
    60d2:	mov    r11d,edx
    60d5:	and    r11d,0x1
    60d9:	shl    r11d,0x1d
    60dd:	or     r10d,r11d
    60e0:	mov    r11d,edx
    60e3:	and    r11d,0x800
    60ea:	shl    r11d,0x11
    60ee:	or     r10d,r11d
    60f1:	btc    r10,0x1d
    60f6:	mov    r11d,0xf0000000
    60fc:	and    r11,r10
    60ff:	movabs rsi,0xffffffff0fffffff
    6109:	and    rbx,rsi
    610c:	or     rbx,r11
    610f:	pop    r11
    6111:	pop    r10
    6113:	pop    rsi
    6114:	pop    rdx
    6115:	mov    QWORD PTR [r12+0x108],rbx
    611d:	stmxcsr DWORD PTR [r12-0x28]
    6123:	ldmxcsr DWORD PTR [r12-0x38]
    6129:	lea    rdi,[rsp+0x110]
    6131:	lea    rsi,[rsp+0xf0]
    6139:	lea    rdx,[rsp+0x100]
    6141:	mov    ecx,0x14
    6146:	mov    r8d,0x0
    614c:	lea    r9,[r12+0x314]
    6154:	movabs r11,0x6478df0e61b0
    615e:	call   r11
    6161:	ldmxcsr DWORD PTR [r12-0x28]
    6167:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    616d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6173:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6179:	mov    rbx,QWORD PTR [r12+0x108]
    6181:	mov    QWORD PTR [r12+0x378],0x2
    618d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6196:	pushf
    6197:	pop    rdx
    6198:	and    rdx,0xfffffffffffff73e
    619f:	mov    rax,rbx
    61a2:	shr    rax,0x18
    61a6:	and    eax,0xc0
    61ab:	or     rdx,rax
    61ae:	mov    rax,rbx
    61b1:	shr    rax,0x1d
    61b5:	and    eax,0x1
    61b8:	xor    eax,0x1
    61bb:	or     rdx,rax
    61be:	mov    rax,rbx
    61c1:	shr    rax,0x11
    61c5:	and    eax,0x800
    61ca:	or     rdx,rax
    61cd:	mov    QWORD PTR [rsp+0x10],rdx
    61d2:	stmxcsr DWORD PTR [rsp+0x120]
    61da:	mov    DWORD PTR [rsp+0x124],0x1f80
    61e5:	ldmxcsr DWORD PTR [rsp+0x124]
    61ed:	add    rsp,0x8
    61f1:	ret
    61f2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    6200:	sub    rsp,0x8
    6204:	stmxcsr DWORD PTR [rsp+0x124]
    620c:	ldmxcsr DWORD PTR [rsp+0x120]
    6214:	mov    r11d,DWORD PTR [rsp+0x124]
    621c:	shr    r11d,1
    621f:	and    r11d,0x10
    6223:	or     DWORD PTR [r12+0x314],r11d
    622b:	mov    QWORD PTR [r12+0x378],0x3
    6237:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    623d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6243:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6249:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    624f:	push   rdx
    6250:	push   rsi
    6251:	push   r10
    6253:	push   r11
    6255:	mov    rdx,QWORD PTR [rsp+0x30]
    625a:	mov    r10d,edx
    625d:	and    r10d,0xc0
    6264:	shl    r10d,0x18
    6268:	mov    r11d,edx
    626b:	and    r11d,0x1
    626f:	shl    r11d,0x1d
    6273:	or     r10d,r11d
    6276:	mov    r11d,edx
    6279:	and    r11d,0x800
    6280:	shl    r11d,0x11
    6284:	or     r10d,r11d
    6287:	btc    r10,0x1d
    628c:	mov    r11d,0xf0000000
    6292:	and    r11,r10
    6295:	movabs rsi,0xffffffff0fffffff
    629f:	and    rbx,rsi
    62a2:	or     rbx,r11
    62a5:	pop    r11
    62a7:	pop    r10
    62a9:	pop    rsi
    62aa:	pop    rdx
    62ab:	mov    QWORD PTR [r12+0x108],rbx
    62b3:	stmxcsr DWORD PTR [r12-0x28]
    62b9:	ldmxcsr DWORD PTR [r12-0x38]
    62bf:	lea    rdi,[rsp+0x110]
    62c7:	lea    rsi,[rsp+0xf0]
    62cf:	lea    rdx,[rsp+0x100]
    62d7:	mov    ecx,0x14
    62dc:	mov    r8d,0x0
    62e2:	lea    r9,[r12+0x314]
    62ea:	movabs r11,0x6478df0e61b0
    62f4:	call   r11
    62f7:	ldmxcsr DWORD PTR [r12-0x28]
    62fd:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6303:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6309:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    630f:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    6315:	mov    rbx,QWORD PTR [r12+0x108]
    631d:	mov    QWORD PTR [r12+0x378],0x2
    6329:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6332:	pushf
    6333:	pop    rdx
    6334:	and    rdx,0xfffffffffffff73e
    633b:	mov    rax,rbx
    633e:	shr    rax,0x18
    6342:	and    eax,0xc0
    6347:	or     rdx,rax
    634a:	mov    rax,rbx
    634d:	shr    rax,0x1d
    6351:	and    eax,0x1
    6354:	xor    eax,0x1
    6357:	or     rdx,rax
    635a:	mov    rax,rbx
    635d:	shr    rax,0x11
    6361:	and    eax,0x800
    6366:	or     rdx,rax
    6369:	mov    QWORD PTR [rsp+0x10],rdx
    636e:	stmxcsr DWORD PTR [rsp+0x120]
    6376:	mov    DWORD PTR [rsp+0x124],0x1f80
    6381:	ldmxcsr DWORD PTR [rsp+0x124]
    6389:	add    rsp,0x8
    638d:	ret
    638e:	xchg   ax,ax
    6390:	sub    rsp,0x8
    6394:	stmxcsr DWORD PTR [rsp+0x124]
    639c:	ldmxcsr DWORD PTR [rsp+0x120]
    63a4:	mov    r11d,DWORD PTR [rsp+0x124]
    63ac:	shr    r11d,1
    63af:	and    r11d,0x10
    63b3:	or     DWORD PTR [r12+0x314],r11d
    63bb:	mov    QWORD PTR [r12+0x378],0x3
    63c7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    63cd:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    63d3:	push   rdx
    63d4:	push   rsi
    63d5:	push   r10
    63d7:	push   r11
    63d9:	mov    rdx,QWORD PTR [rsp+0x30]
    63de:	mov    r10d,edx
    63e1:	and    r10d,0xc0
    63e8:	shl    r10d,0x18
    63ec:	mov    r11d,edx
    63ef:	and    r11d,0x1
    63f3:	shl    r11d,0x1d
    63f7:	or     r10d,r11d
    63fa:	mov    r11d,edx
    63fd:	and    r11d,0x800
    6404:	shl    r11d,0x11
    6408:	or     r10d,r11d
    640b:	btc    r10,0x1d
    6410:	mov    r11d,0xf0000000
    6416:	and    r11,r10
    6419:	movabs rsi,0xffffffff0fffffff
    6423:	and    rbx,rsi
    6426:	or     rbx,r11
    6429:	pop    r11
    642b:	pop    r10
    642d:	pop    rsi
    642e:	pop    rdx
    642f:	mov    QWORD PTR [r12+0x108],rbx
    6437:	stmxcsr DWORD PTR [r12-0x28]
    643d:	ldmxcsr DWORD PTR [r12-0x38]
    6443:	lea    rdi,[rsp+0x110]
    644b:	lea    rsi,[rsp+0xf0]
    6453:	lea    rdx,[rsp+0x100]
    645b:	mov    ecx,0x56
    6460:	mov    r8d,0x0
    6466:	lea    r9,[r12+0x314]
    646e:	movabs r11,0x6478df0e61b0
    6478:	call   r11
    647b:	ldmxcsr DWORD PTR [r12-0x28]
    6481:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6487:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    648d:	mov    rbx,QWORD PTR [r12+0x108]
    6495:	mov    QWORD PTR [r12+0x378],0x2
    64a1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    64aa:	pushf
    64ab:	pop    rdx
    64ac:	and    rdx,0xfffffffffffff73e
    64b3:	mov    rax,rbx
    64b6:	shr    rax,0x18
    64ba:	and    eax,0xc0
    64bf:	or     rdx,rax
    64c2:	mov    rax,rbx
    64c5:	shr    rax,0x1d
    64c9:	and    eax,0x1
    64cc:	xor    eax,0x1
    64cf:	or     rdx,rax
    64d2:	mov    rax,rbx
    64d5:	shr    rax,0x11
    64d9:	and    eax,0x800
    64de:	or     rdx,rax
    64e1:	mov    QWORD PTR [rsp+0x10],rdx
    64e6:	stmxcsr DWORD PTR [rsp+0x120]
    64ee:	mov    DWORD PTR [rsp+0x124],0x1f80
    64f9:	ldmxcsr DWORD PTR [rsp+0x124]
    6501:	add    rsp,0x8
    6505:	ret
    6506:	data16 nop WORD PTR [rax+rax*1+0x0]
    6510:	sub    rsp,0x8
    6514:	stmxcsr DWORD PTR [rsp+0x124]
    651c:	ldmxcsr DWORD PTR [rsp+0x120]
    6524:	mov    r11d,DWORD PTR [rsp+0x124]
    652c:	shr    r11d,1
    652f:	and    r11d,0x10
    6533:	or     DWORD PTR [r12+0x314],r11d
    653b:	mov    QWORD PTR [r12+0x378],0x3
    6547:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    654d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6553:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6559:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    655f:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    6565:	push   rdx
    6566:	push   rsi
    6567:	push   r10
    6569:	push   r11
    656b:	mov    rdx,QWORD PTR [rsp+0x30]
    6570:	mov    r10d,edx
    6573:	and    r10d,0xc0
    657a:	shl    r10d,0x18
    657e:	mov    r11d,edx
    6581:	and    r11d,0x1
    6585:	shl    r11d,0x1d
    6589:	or     r10d,r11d
    658c:	mov    r11d,edx
    658f:	and    r11d,0x800
    6596:	shl    r11d,0x11
    659a:	or     r10d,r11d
    659d:	btc    r10,0x1d
    65a2:	mov    r11d,0xf0000000
    65a8:	and    r11,r10
    65ab:	movabs rsi,0xffffffff0fffffff
    65b5:	and    rbx,rsi
    65b8:	or     rbx,r11
    65bb:	pop    r11
    65bd:	pop    r10
    65bf:	pop    rsi
    65c0:	pop    rdx
    65c1:	mov    QWORD PTR [r12+0x108],rbx
    65c9:	stmxcsr DWORD PTR [r12-0x28]
    65cf:	ldmxcsr DWORD PTR [r12-0x38]
    65d5:	lea    rdi,[rsp+0x110]
    65dd:	lea    rsi,[rsp+0xf0]
    65e5:	lea    rdx,[rsp+0x100]
    65ed:	mov    ecx,0x14
    65f2:	mov    r8d,0x0
    65f8:	lea    r9,[r12+0x314]
    6600:	movabs r11,0x6478df0e61b0
    660a:	call   r11
    660d:	ldmxcsr DWORD PTR [r12-0x28]
    6613:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6619:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    661f:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6625:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    662b:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    6631:	mov    rbx,QWORD PTR [r12+0x108]
    6639:	mov    QWORD PTR [r12+0x378],0x2
    6645:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    664e:	pushf
    664f:	pop    rdx
    6650:	and    rdx,0xfffffffffffff73e
    6657:	mov    rax,rbx
    665a:	shr    rax,0x18
    665e:	and    eax,0xc0
    6663:	or     rdx,rax
    6666:	mov    rax,rbx
    6669:	shr    rax,0x1d
    666d:	and    eax,0x1
    6670:	xor    eax,0x1
    6673:	or     rdx,rax
    6676:	mov    rax,rbx
    6679:	shr    rax,0x11
    667d:	and    eax,0x800
    6682:	or     rdx,rax
    6685:	mov    QWORD PTR [rsp+0x10],rdx
    668a:	stmxcsr DWORD PTR [rsp+0x120]
    6692:	mov    DWORD PTR [rsp+0x124],0x1f80
    669d:	ldmxcsr DWORD PTR [rsp+0x124]
    66a5:	add    rsp,0x8
    66a9:	ret
    66aa:	nop    WORD PTR [rax+rax*1+0x0]
    66b0:	sub    rsp,0x8
    66b4:	stmxcsr DWORD PTR [rsp+0x124]
    66bc:	ldmxcsr DWORD PTR [rsp+0x120]
    66c4:	mov    r11d,DWORD PTR [rsp+0x124]
    66cc:	shr    r11d,1
    66cf:	and    r11d,0x10
    66d3:	or     DWORD PTR [r12+0x314],r11d
    66db:	mov    QWORD PTR [r12+0x378],0x3
    66e7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    66ed:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    66f3:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    66f9:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    66ff:	push   rdx
    6700:	push   rsi
    6701:	push   r10
    6703:	push   r11
    6705:	mov    rdx,QWORD PTR [rsp+0x30]
    670a:	mov    r10d,edx
    670d:	and    r10d,0xc0
    6714:	shl    r10d,0x18
    6718:	mov    r11d,edx
    671b:	and    r11d,0x1
    671f:	shl    r11d,0x1d
    6723:	or     r10d,r11d
    6726:	mov    r11d,edx
    6729:	and    r11d,0x800
    6730:	shl    r11d,0x11
    6734:	or     r10d,r11d
    6737:	btc    r10,0x1d
    673c:	mov    r11d,0xf0000000
    6742:	and    r11,r10
    6745:	movabs rsi,0xffffffff0fffffff
    674f:	and    rbx,rsi
    6752:	or     rbx,r11
    6755:	pop    r11
    6757:	pop    r10
    6759:	pop    rsi
    675a:	pop    rdx
    675b:	mov    QWORD PTR [r12+0x108],rbx
    6763:	stmxcsr DWORD PTR [r12-0x28]
    6769:	ldmxcsr DWORD PTR [r12-0x38]
    676f:	lea    rdi,[rsp+0x110]
    6777:	lea    rsi,[rsp+0xf0]
    677f:	lea    rdx,[rsp+0x100]
    6787:	mov    ecx,0x56
    678c:	mov    r8d,0x0
    6792:	lea    r9,[r12+0x314]
    679a:	movabs r11,0x6478df0e61b0
    67a4:	call   r11
    67a7:	ldmxcsr DWORD PTR [r12-0x28]
    67ad:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    67b3:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    67b9:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    67bf:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    67c5:	mov    rbx,QWORD PTR [r12+0x108]
    67cd:	mov    QWORD PTR [r12+0x378],0x2
    67d9:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    67e2:	pushf
    67e3:	pop    rdx
    67e4:	and    rdx,0xfffffffffffff73e
    67eb:	mov    rax,rbx
    67ee:	shr    rax,0x18
    67f2:	and    eax,0xc0
    67f7:	or     rdx,rax
    67fa:	mov    rax,rbx
    67fd:	shr    rax,0x1d
    6801:	and    eax,0x1
    6804:	xor    eax,0x1
    6807:	or     rdx,rax
    680a:	mov    rax,rbx
    680d:	shr    rax,0x11
    6811:	and    eax,0x800
    6816:	or     rdx,rax
    6819:	mov    QWORD PTR [rsp+0x10],rdx
    681e:	stmxcsr DWORD PTR [rsp+0x120]
    6826:	mov    DWORD PTR [rsp+0x124],0x1f80
    6831:	ldmxcsr DWORD PTR [rsp+0x124]
    6839:	add    rsp,0x8
    683d:	ret
    683e:	xchg   ax,ax
    6840:	sub    rsp,0x8
    6844:	stmxcsr DWORD PTR [rsp+0x124]
    684c:	ldmxcsr DWORD PTR [rsp+0x120]
    6854:	mov    r11d,DWORD PTR [rsp+0x124]
    685c:	shr    r11d,1
    685f:	and    r11d,0x10
    6863:	or     DWORD PTR [r12+0x314],r11d
    686b:	mov    QWORD PTR [r12+0x378],0x3
    6877:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    687d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6883:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6889:	push   rdx
    688a:	push   rsi
    688b:	push   r10
    688d:	push   r11
    688f:	mov    rdx,QWORD PTR [rsp+0x30]
    6894:	mov    r10d,edx
    6897:	and    r10d,0xc0
    689e:	shl    r10d,0x18
    68a2:	mov    r11d,edx
    68a5:	and    r11d,0x1
    68a9:	shl    r11d,0x1d
    68ad:	or     r10d,r11d
    68b0:	mov    r11d,edx
    68b3:	and    r11d,0x800
    68ba:	shl    r11d,0x11
    68be:	or     r10d,r11d
    68c1:	btc    r10,0x1d
    68c6:	mov    r11d,0xf0000000
    68cc:	and    r11,r10
    68cf:	movabs rsi,0xffffffff0fffffff
    68d9:	and    rbx,rsi
    68dc:	or     rbx,r11
    68df:	pop    r11
    68e1:	pop    r10
    68e3:	pop    rsi
    68e4:	pop    rdx
    68e5:	mov    QWORD PTR [r12+0x108],rbx
    68ed:	stmxcsr DWORD PTR [r12-0x28]
    68f3:	ldmxcsr DWORD PTR [r12-0x38]
    68f9:	lea    rdi,[rsp+0x110]
    6901:	lea    rsi,[rsp+0xf0]
    6909:	lea    rdx,[rsp+0x100]
    6911:	mov    ecx,0x56
    6916:	mov    r8d,0x0
    691c:	lea    r9,[r12+0x314]
    6924:	movabs r11,0x6478df0e61b0
    692e:	call   r11
    6931:	ldmxcsr DWORD PTR [r12-0x28]
    6937:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    693d:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6943:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6949:	mov    rbx,QWORD PTR [r12+0x108]
    6951:	mov    QWORD PTR [r12+0x378],0x2
    695d:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6966:	pushf
    6967:	pop    rdx
    6968:	and    rdx,0xfffffffffffff73e
    696f:	mov    rax,rbx
    6972:	shr    rax,0x18
    6976:	and    eax,0xc0
    697b:	or     rdx,rax
    697e:	mov    rax,rbx
    6981:	shr    rax,0x1d
    6985:	and    eax,0x1
    6988:	xor    eax,0x1
    698b:	or     rdx,rax
    698e:	mov    rax,rbx
    6991:	shr    rax,0x11
    6995:	and    eax,0x800
    699a:	or     rdx,rax
    699d:	mov    QWORD PTR [rsp+0x10],rdx
    69a2:	stmxcsr DWORD PTR [rsp+0x120]
    69aa:	mov    DWORD PTR [rsp+0x124],0x1f80
    69b5:	ldmxcsr DWORD PTR [rsp+0x124]
    69bd:	add    rsp,0x8
    69c1:	ret
    69c2:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    69d0:	sub    rsp,0x8
    69d4:	stmxcsr DWORD PTR [rsp+0x124]
    69dc:	ldmxcsr DWORD PTR [rsp+0x120]
    69e4:	mov    r11d,DWORD PTR [rsp+0x124]
    69ec:	shr    r11d,1
    69ef:	and    r11d,0x10
    69f3:	or     DWORD PTR [r12+0x314],r11d
    69fb:	mov    QWORD PTR [r12+0x378],0x3
    6a07:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6a0d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6a13:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6a19:	push   rdx
    6a1a:	push   rsi
    6a1b:	push   r10
    6a1d:	push   r11
    6a1f:	mov    rdx,QWORD PTR [rsp+0x30]
    6a24:	mov    r10d,edx
    6a27:	and    r10d,0xc0
    6a2e:	shl    r10d,0x18
    6a32:	mov    r11d,edx
    6a35:	and    r11d,0x1
    6a39:	shl    r11d,0x1d
    6a3d:	or     r10d,r11d
    6a40:	mov    r11d,edx
    6a43:	and    r11d,0x800
    6a4a:	shl    r11d,0x11
    6a4e:	or     r10d,r11d
    6a51:	btc    r10,0x1d
    6a56:	mov    r11d,0xf0000000
    6a5c:	and    r11,r10
    6a5f:	movabs rsi,0xffffffff0fffffff
    6a69:	and    rbx,rsi
    6a6c:	or     rbx,r11
    6a6f:	pop    r11
    6a71:	pop    r10
    6a73:	pop    rsi
    6a74:	pop    rdx
    6a75:	mov    QWORD PTR [r12+0x108],rbx
    6a7d:	stmxcsr DWORD PTR [r12-0x28]
    6a83:	ldmxcsr DWORD PTR [r12-0x38]
    6a89:	lea    rdi,[rsp+0x110]
    6a91:	lea    rsi,[rsp+0xf0]
    6a99:	lea    rdx,[rsp+0x100]
    6aa1:	mov    ecx,0x14
    6aa6:	mov    r8d,0x0
    6aac:	lea    r9,[r12+0x314]
    6ab4:	movabs r11,0x6478df0e61b0
    6abe:	call   r11
    6ac1:	ldmxcsr DWORD PTR [r12-0x28]
    6ac7:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6acd:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6ad3:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6ad9:	mov    rbx,QWORD PTR [r12+0x108]
    6ae1:	mov    QWORD PTR [r12+0x378],0x2
    6aed:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6af6:	pushf
    6af7:	pop    rdx
    6af8:	and    rdx,0xfffffffffffff73e
    6aff:	mov    rax,rbx
    6b02:	shr    rax,0x18
    6b06:	and    eax,0xc0
    6b0b:	or     rdx,rax
    6b0e:	mov    rax,rbx
    6b11:	shr    rax,0x1d
    6b15:	and    eax,0x1
    6b18:	xor    eax,0x1
    6b1b:	or     rdx,rax
    6b1e:	mov    rax,rbx
    6b21:	shr    rax,0x11
    6b25:	and    eax,0x800
    6b2a:	or     rdx,rax
    6b2d:	mov    QWORD PTR [rsp+0x10],rdx
    6b32:	stmxcsr DWORD PTR [rsp+0x120]
    6b3a:	mov    DWORD PTR [rsp+0x124],0x1f80
    6b45:	ldmxcsr DWORD PTR [rsp+0x124]
    6b4d:	add    rsp,0x8
    6b51:	ret
    6b52:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    6b60:	sub    rsp,0x8
    6b64:	stmxcsr DWORD PTR [rsp+0x124]
    6b6c:	ldmxcsr DWORD PTR [rsp+0x120]
    6b74:	mov    r11d,DWORD PTR [rsp+0x124]
    6b7c:	shr    r11d,1
    6b7f:	and    r11d,0x10
    6b83:	or     DWORD PTR [r12+0x314],r11d
    6b8b:	mov    QWORD PTR [r12+0x378],0x3
    6b97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6b9d:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    6ba3:	push   rdx
    6ba4:	push   rsi
    6ba5:	push   r10
    6ba7:	push   r11
    6ba9:	mov    rdx,QWORD PTR [rsp+0x30]
    6bae:	mov    r10d,edx
    6bb1:	and    r10d,0xc0
    6bb8:	shl    r10d,0x18
    6bbc:	mov    r11d,edx
    6bbf:	and    r11d,0x1
    6bc3:	shl    r11d,0x1d
    6bc7:	or     r10d,r11d
    6bca:	mov    r11d,edx
    6bcd:	and    r11d,0x800
    6bd4:	shl    r11d,0x11
    6bd8:	or     r10d,r11d
    6bdb:	btc    r10,0x1d
    6be0:	mov    r11d,0xf0000000
    6be6:	and    r11,r10
    6be9:	movabs rsi,0xffffffff0fffffff
    6bf3:	and    rbx,rsi
    6bf6:	or     rbx,r11
    6bf9:	pop    r11
    6bfb:	pop    r10
    6bfd:	pop    rsi
    6bfe:	pop    rdx
    6bff:	mov    QWORD PTR [r12+0x108],rbx
    6c07:	stmxcsr DWORD PTR [r12-0x28]
    6c0d:	ldmxcsr DWORD PTR [r12-0x38]
    6c13:	lea    rdi,[rsp+0x110]
    6c1b:	lea    rsi,[rsp+0xf0]
    6c23:	lea    rdx,[rsp+0x100]
    6c2b:	mov    ecx,0x14
    6c30:	mov    r8d,0x0
    6c36:	lea    r9,[r12+0x314]
    6c3e:	movabs r11,0x6478df0e61b0
    6c48:	call   r11
    6c4b:	ldmxcsr DWORD PTR [r12-0x28]
    6c51:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6c57:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    6c5d:	mov    rbx,QWORD PTR [r12+0x108]
    6c65:	mov    QWORD PTR [r12+0x378],0x2
    6c71:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6c7a:	pushf
    6c7b:	pop    rdx
    6c7c:	and    rdx,0xfffffffffffff73e
    6c83:	mov    rax,rbx
    6c86:	shr    rax,0x18
    6c8a:	and    eax,0xc0
    6c8f:	or     rdx,rax
    6c92:	mov    rax,rbx
    6c95:	shr    rax,0x1d
    6c99:	and    eax,0x1
    6c9c:	xor    eax,0x1
    6c9f:	or     rdx,rax
    6ca2:	mov    rax,rbx
    6ca5:	shr    rax,0x11
    6ca9:	and    eax,0x800
    6cae:	or     rdx,rax
    6cb1:	mov    QWORD PTR [rsp+0x10],rdx
    6cb6:	stmxcsr DWORD PTR [rsp+0x120]
    6cbe:	mov    DWORD PTR [rsp+0x124],0x1f80
    6cc9:	ldmxcsr DWORD PTR [rsp+0x124]
    6cd1:	add    rsp,0x8
    6cd5:	ret
    6cd6:	data16 nop WORD PTR [rax+rax*1+0x0]
    6ce0:	sub    rsp,0x8
    6ce4:	stmxcsr DWORD PTR [rsp+0x124]
    6cec:	ldmxcsr DWORD PTR [rsp+0x120]
    6cf4:	mov    r11d,DWORD PTR [rsp+0x124]
    6cfc:	shr    r11d,1
    6cff:	and    r11d,0x10
    6d03:	or     DWORD PTR [r12+0x314],r11d
    6d0b:	mov    QWORD PTR [r12+0x378],0x3
    6d17:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6d1d:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    6d23:	push   rdx
    6d24:	push   rsi
    6d25:	push   r10
    6d27:	push   r11
    6d29:	mov    rdx,QWORD PTR [rsp+0x30]
    6d2e:	mov    r10d,edx
    6d31:	and    r10d,0xc0
    6d38:	shl    r10d,0x18
    6d3c:	mov    r11d,edx
    6d3f:	and    r11d,0x1
    6d43:	shl    r11d,0x1d
    6d47:	or     r10d,r11d
    6d4a:	mov    r11d,edx
    6d4d:	and    r11d,0x800
    6d54:	shl    r11d,0x11
    6d58:	or     r10d,r11d
    6d5b:	btc    r10,0x1d
    6d60:	mov    r11d,0xf0000000
    6d66:	and    r11,r10
    6d69:	movabs rsi,0xffffffff0fffffff
    6d73:	and    rbx,rsi
    6d76:	or     rbx,r11
    6d79:	pop    r11
    6d7b:	pop    r10
    6d7d:	pop    rsi
    6d7e:	pop    rdx
    6d7f:	mov    QWORD PTR [r12+0x108],rbx
    6d87:	stmxcsr DWORD PTR [r12-0x28]
    6d8d:	ldmxcsr DWORD PTR [r12-0x38]
    6d93:	lea    rdi,[rsp+0x110]
    6d9b:	lea    rsi,[rsp+0xf0]
    6da3:	lea    rdx,[rsp+0x100]
    6dab:	mov    ecx,0xc
    6db0:	mov    r8d,0x0
    6db6:	lea    r9,[r12+0x314]
    6dbe:	movabs r11,0x6478df0e61b0
    6dc8:	call   r11
    6dcb:	ldmxcsr DWORD PTR [r12-0x28]
    6dd1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6dd7:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    6ddd:	mov    rbx,QWORD PTR [r12+0x108]
    6de5:	mov    QWORD PTR [r12+0x378],0x2
    6df1:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6dfa:	pushf
    6dfb:	pop    rdx
    6dfc:	and    rdx,0xfffffffffffff73e
    6e03:	mov    rax,rbx
    6e06:	shr    rax,0x18
    6e0a:	and    eax,0xc0
    6e0f:	or     rdx,rax
    6e12:	mov    rax,rbx
    6e15:	shr    rax,0x1d
    6e19:	and    eax,0x1
    6e1c:	xor    eax,0x1
    6e1f:	or     rdx,rax
    6e22:	mov    rax,rbx
    6e25:	shr    rax,0x11
    6e29:	and    eax,0x800
    6e2e:	or     rdx,rax
    6e31:	mov    QWORD PTR [rsp+0x10],rdx
    6e36:	stmxcsr DWORD PTR [rsp+0x120]
    6e3e:	mov    DWORD PTR [rsp+0x124],0x1f80
    6e49:	ldmxcsr DWORD PTR [rsp+0x124]
    6e51:	add    rsp,0x8
    6e55:	ret
    6e56:	data16 nop WORD PTR [rax+rax*1+0x0]
    6e60:	sub    rsp,0x8
    6e64:	stmxcsr DWORD PTR [rsp+0x124]
    6e6c:	ldmxcsr DWORD PTR [rsp+0x120]
    6e74:	mov    r11d,DWORD PTR [rsp+0x124]
    6e7c:	shr    r11d,1
    6e7f:	and    r11d,0x10
    6e83:	or     DWORD PTR [r12+0x314],r11d
    6e8b:	mov    QWORD PTR [r12+0x378],0x3
    6e97:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    6e9d:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    6ea3:	push   rdx
    6ea4:	push   rsi
    6ea5:	push   r10
    6ea7:	push   r11
    6ea9:	mov    rdx,QWORD PTR [rsp+0x30]
    6eae:	mov    r10d,edx
    6eb1:	and    r10d,0xc0
    6eb8:	shl    r10d,0x18
    6ebc:	mov    r11d,edx
    6ebf:	and    r11d,0x1
    6ec3:	shl    r11d,0x1d
    6ec7:	or     r10d,r11d
    6eca:	mov    r11d,edx
    6ecd:	and    r11d,0x800
    6ed4:	shl    r11d,0x11
    6ed8:	or     r10d,r11d
    6edb:	btc    r10,0x1d
    6ee0:	mov    r11d,0xf0000000
    6ee6:	and    r11,r10
    6ee9:	movabs rsi,0xffffffff0fffffff
    6ef3:	and    rbx,rsi
    6ef6:	or     rbx,r11
    6ef9:	pop    r11
    6efb:	pop    r10
    6efd:	pop    rsi
    6efe:	pop    rdx
    6eff:	mov    QWORD PTR [r12+0x108],rbx
    6f07:	stmxcsr DWORD PTR [r12-0x28]
    6f0d:	ldmxcsr DWORD PTR [r12-0x38]
    6f13:	lea    rdi,[rsp+0x110]
    6f1b:	lea    rsi,[rsp+0xf0]
    6f23:	lea    rdx,[rsp+0x100]
    6f2b:	mov    ecx,0xc
    6f30:	mov    r8d,0x0
    6f36:	lea    r9,[r12+0x314]
    6f3e:	movabs r11,0x6478df0e61b0
    6f48:	call   r11
    6f4b:	ldmxcsr DWORD PTR [r12-0x28]
    6f51:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    6f57:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    6f5d:	mov    rbx,QWORD PTR [r12+0x108]
    6f65:	mov    QWORD PTR [r12+0x378],0x2
    6f71:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    6f7a:	pushf
    6f7b:	pop    rdx
    6f7c:	and    rdx,0xfffffffffffff73e
    6f83:	mov    rax,rbx
    6f86:	shr    rax,0x18
    6f8a:	and    eax,0xc0
    6f8f:	or     rdx,rax
    6f92:	mov    rax,rbx
    6f95:	shr    rax,0x1d
    6f99:	and    eax,0x1
    6f9c:	xor    eax,0x1
    6f9f:	or     rdx,rax
    6fa2:	mov    rax,rbx
    6fa5:	shr    rax,0x11
    6fa9:	and    eax,0x800
    6fae:	or     rdx,rax
    6fb1:	mov    QWORD PTR [rsp+0x10],rdx
    6fb6:	stmxcsr DWORD PTR [rsp+0x120]
    6fbe:	mov    DWORD PTR [rsp+0x124],0x1f80
    6fc9:	ldmxcsr DWORD PTR [rsp+0x124]
    6fd1:	add    rsp,0x8
    6fd5:	ret
    6fd6:	mov    eax,0x4101e8
    6fdb:	mov    QWORD PTR [r12+0x100],rax
    6fe3:	push   rdx
    6fe4:	push   rsi
    6fe5:	push   r10
    6fe7:	push   r11
    6fe9:	pushf
    6fea:	pop    r11
    6fec:	mov    QWORD PTR [rsp+0x20],r11
    6ff1:	mov    rdx,QWORD PTR [rsp+0x20]
    6ff6:	mov    r10d,edx
    6ff9:	and    r10d,0xc0
    7000:	shl    r10d,0x18
    7004:	mov    r11d,edx
    7007:	and    r11d,0x1
    700b:	shl    r11d,0x1d
    700f:	or     r10d,r11d
    7012:	mov    r11d,edx
    7015:	and    r11d,0x800
    701c:	shl    r11d,0x11
    7020:	or     r10d,r11d
    7023:	btc    r10,0x1d
    7028:	mov    r11d,0xf0000000
    702e:	and    r11,r10
    7031:	movabs rsi,0xffffffff0fffffff
    703b:	and    rbx,rsi
    703e:	or     rbx,r11
    7041:	pop    r11
    7043:	pop    r10
    7045:	pop    rsi
    7046:	pop    rdx
    7047:	mov    QWORD PTR [r12+0x108],rbx
    704f:	add    rsp,0x150
    7056:	mov    eax,0xc
    705b:	movabs r11,0x6478df27b390
    7065:	jmp    r11
    7068:	mov    eax,0x410440
    706d:	mov    QWORD PTR [r12+0x100],rax
    7075:	push   rdx
    7076:	push   rsi
    7077:	push   r10
    7079:	push   r11
    707b:	mov    rdx,QWORD PTR [rsp+0x20]
    7080:	mov    r10d,edx
    7083:	and    r10d,0xc0
    708a:	shl    r10d,0x18
    708e:	mov    r11d,edx
    7091:	and    r11d,0x1
    7095:	shl    r11d,0x1d
    7099:	or     r10d,r11d
    709c:	mov    r11d,edx
    709f:	and    r11d,0x800
    70a6:	shl    r11d,0x11
    70aa:	or     r10d,r11d
    70ad:	btc    r10,0x1d
    70b2:	mov    r11d,0xf0000000
    70b8:	and    r11,r10
    70bb:	movabs rsi,0xffffffff0fffffff
    70c5:	and    rbx,rsi
    70c8:	or     rbx,r11
    70cb:	pop    r11
    70cd:	pop    r10
    70cf:	pop    rsi
    70d0:	pop    rdx
    70d1:	mov    QWORD PTR [r12+0x108],rbx
    70d9:	add    rsp,0x150
    70e0:	mov    eax,0xc
    70e5:	movabs r11,0x6478df27b390
    70ef:	jmp    r11
    70f2:	mov    eax,0x41044c
    70f7:	mov    QWORD PTR [r12+0x100],rax
    70ff:	push   rdx
    7100:	push   rsi
    7101:	push   r10
    7103:	push   r11
    7105:	pushf
    7106:	pop    r11
    7108:	mov    QWORD PTR [rsp+0x20],r11
    710d:	mov    rdx,QWORD PTR [rsp+0x20]
    7112:	mov    r10d,edx
    7115:	and    r10d,0xc0
    711c:	shl    r10d,0x18
    7120:	mov    r11d,edx
    7123:	and    r11d,0x1
    7127:	shl    r11d,0x1d
    712b:	or     r10d,r11d
    712e:	mov    r11d,edx
    7131:	and    r11d,0x800
    7138:	shl    r11d,0x11
    713c:	or     r10d,r11d
    713f:	btc    r10,0x1d
    7144:	mov    r11d,0xf0000000
    714a:	and    r11,r10
    714d:	movabs rsi,0xffffffff0fffffff
    7157:	and    rbx,rsi
    715a:	or     rbx,r11
    715d:	pop    r11
    715f:	pop    r10
    7161:	pop    rsi
    7162:	pop    rdx
    7163:	mov    QWORD PTR [r12+0x108],rbx
    716b:	add    rsp,0x150
    7172:	mov    eax,0xc
    7177:	movabs r11,0x6478df27b390
    7181:	jmp    r11
    7184:	mov    eax,0x41048c
    7189:	mov    QWORD PTR [r12+0x100],rax
    7191:	push   rdx
    7192:	push   rsi
    7193:	push   r10
    7195:	push   r11
    7197:	mov    rdx,QWORD PTR [rsp+0x20]
    719c:	mov    r10d,edx
    719f:	and    r10d,0xc0
    71a6:	shl    r10d,0x18
    71aa:	mov    r11d,edx
    71ad:	and    r11d,0x1
    71b1:	shl    r11d,0x1d
    71b5:	or     r10d,r11d
    71b8:	mov    r11d,edx
    71bb:	and    r11d,0x800
    71c2:	shl    r11d,0x11
    71c6:	or     r10d,r11d
    71c9:	btc    r10,0x1d
    71ce:	mov    r11d,0xf0000000
    71d4:	and    r11,r10
    71d7:	movabs rsi,0xffffffff0fffffff
    71e1:	and    rbx,rsi
    71e4:	or     rbx,r11
    71e7:	pop    r11
    71e9:	pop    r10
    71eb:	pop    rsi
    71ec:	pop    rdx
    71ed:	mov    QWORD PTR [r12+0x108],rbx
    71f5:	add    rsp,0x150
    71fc:	mov    eax,0xc
    7201:	movabs r11,0x6478df27b390
    720b:	jmp    r11
    720e:	mov    eax,0x410494
    7213:	mov    QWORD PTR [r12+0x100],rax
    721b:	push   rdx
    721c:	push   rsi
    721d:	push   r10
    721f:	push   r11
    7221:	mov    rdx,QWORD PTR [rsp+0x20]
    7226:	mov    r10d,edx
    7229:	and    r10d,0xc0
    7230:	shl    r10d,0x18
    7234:	mov    r11d,edx
    7237:	and    r11d,0x1
    723b:	shl    r11d,0x1d
    723f:	or     r10d,r11d
    7242:	mov    r11d,edx
    7245:	and    r11d,0x800
    724c:	shl    r11d,0x11
    7250:	or     r10d,r11d
    7253:	btc    r10,0x1d
    7258:	mov    r11d,0xf0000000
    725e:	and    r11,r10
    7261:	movabs rsi,0xffffffff0fffffff
    726b:	and    rbx,rsi
    726e:	or     rbx,r11
    7271:	pop    r11
    7273:	pop    r10
    7275:	pop    rsi
    7276:	pop    rdx
    7277:	mov    QWORD PTR [r12+0x108],rbx
    727f:	add    rsp,0x150
    7286:	mov    eax,0xc
    728b:	movabs r11,0x6478df27b390
    7295:	jmp    r11
    7298:	nop    DWORD PTR [rax+rax*1+0x0]
    72a0:	sub    rsp,0x150
    72a7:	mov    r11,QWORD PTR [r12+0x398]
    72af:	mov    QWORD PTR [rsp],r11
    72b3:	cmp    DWORD PTR [r12+0x310],0x0
    72bc:	je     0x734c
    72c2:	push   rdx
    72c3:	push   rsi
    72c4:	push   r10
    72c6:	push   r11
    72c8:	mov    rdx,QWORD PTR [rsp+0x20]
    72cd:	mov    r10d,edx
    72d0:	and    r10d,0xc0
    72d7:	shl    r10d,0x18
    72db:	mov    r11d,edx
    72de:	and    r11d,0x1
    72e2:	shl    r11d,0x1d
    72e6:	or     r10d,r11d
    72e9:	mov    r11d,edx
    72ec:	and    r11d,0x800
    72f3:	shl    r11d,0x11
    72f7:	or     r10d,r11d
    72fa:	btc    r10,0x1d
    72ff:	mov    r11d,0xf0000000
    7305:	and    r11,r10
    7308:	movabs rsi,0xffffffff0fffffff
    7312:	and    rbx,rsi
    7315:	or     rbx,r11
    7318:	pop    r11
    731a:	pop    r10
    731c:	pop    rsi
    731d:	pop    rdx
    731e:	mov    QWORD PTR [r12+0x108],rbx
    7326:	mov    eax,0x4101ac
    732b:	mov    QWORD PTR [r12+0x100],rax
    7333:	add    rsp,0x150
    733a:	mov    eax,0x3
    733f:	movabs r11,0x6478df27b390
    7349:	jmp    r11
    734c:	jmp    0x1fd
    7351:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7360:	sub    rsp,0x150
    7367:	mov    r11,QWORD PTR [r12+0x398]
    736f:	mov    QWORD PTR [rsp],r11
    7373:	cmp    DWORD PTR [r12+0x310],0x0
    737c:	je     0x740c
    7382:	push   rdx
    7383:	push   rsi
    7384:	push   r10
    7386:	push   r11
    7388:	mov    rdx,QWORD PTR [rsp+0x20]
    738d:	mov    r10d,edx
    7390:	and    r10d,0xc0
    7397:	shl    r10d,0x18
    739b:	mov    r11d,edx
    739e:	and    r11d,0x1
    73a2:	shl    r11d,0x1d
    73a6:	or     r10d,r11d
    73a9:	mov    r11d,edx
    73ac:	and    r11d,0x800
    73b3:	shl    r11d,0x11
    73b7:	or     r10d,r11d
    73ba:	btc    r10,0x1d
    73bf:	mov    r11d,0xf0000000
    73c5:	and    r11,r10
    73c8:	movabs rsi,0xffffffff0fffffff
    73d2:	and    rbx,rsi
    73d5:	or     rbx,r11
    73d8:	pop    r11
    73da:	pop    r10
    73dc:	pop    rsi
    73dd:	pop    rdx
    73de:	mov    QWORD PTR [r12+0x108],rbx
    73e6:	mov    eax,0x4101ec
    73eb:	mov    QWORD PTR [r12+0x100],rax
    73f3:	add    rsp,0x150
    73fa:	mov    eax,0x3
    73ff:	movabs r11,0x6478df27b390
    7409:	jmp    r11
    740c:	jmp    0x773
    7411:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7420:	sub    rsp,0x150
    7427:	mov    r11,QWORD PTR [r12+0x398]
    742f:	mov    QWORD PTR [rsp],r11
    7433:	cmp    DWORD PTR [r12+0x310],0x0
    743c:	je     0x74cc
    7442:	push   rdx
    7443:	push   rsi
    7444:	push   r10
    7446:	push   r11
    7448:	mov    rdx,QWORD PTR [rsp+0x20]
    744d:	mov    r10d,edx
    7450:	and    r10d,0xc0
    7457:	shl    r10d,0x18
    745b:	mov    r11d,edx
    745e:	and    r11d,0x1
    7462:	shl    r11d,0x1d
    7466:	or     r10d,r11d
    7469:	mov    r11d,edx
    746c:	and    r11d,0x800
    7473:	shl    r11d,0x11
    7477:	or     r10d,r11d
    747a:	btc    r10,0x1d
    747f:	mov    r11d,0xf0000000
    7485:	and    r11,r10
    7488:	movabs rsi,0xffffffff0fffffff
    7492:	and    rbx,rsi
    7495:	or     rbx,r11
    7498:	pop    r11
    749a:	pop    r10
    749c:	pop    rsi
    749d:	pop    rdx
    749e:	mov    QWORD PTR [r12+0x108],rbx
    74a6:	mov    eax,0x410274
    74ab:	mov    QWORD PTR [r12+0x100],rax
    74b3:	add    rsp,0x150
    74ba:	mov    eax,0x3
    74bf:	movabs r11,0x6478df27b390
    74c9:	jmp    r11
    74cc:	jmp    0xec8
    74d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74e0:	sub    rsp,0x150
    74e7:	mov    r11,QWORD PTR [r12+0x398]
    74ef:	mov    QWORD PTR [rsp],r11
    74f3:	cmp    DWORD PTR [r12+0x310],0x0
    74fc:	je     0x758c
    7502:	push   rdx
    7503:	push   rsi
    7504:	push   r10
    7506:	push   r11
    7508:	mov    rdx,QWORD PTR [rsp+0x20]
    750d:	mov    r10d,edx
    7510:	and    r10d,0xc0
    7517:	shl    r10d,0x18
    751b:	mov    r11d,edx
    751e:	and    r11d,0x1
    7522:	shl    r11d,0x1d
    7526:	or     r10d,r11d
    7529:	mov    r11d,edx
    752c:	and    r11d,0x800
    7533:	shl    r11d,0x11
    7537:	or     r10d,r11d
    753a:	btc    r10,0x1d
    753f:	mov    r11d,0xf0000000
    7545:	and    r11,r10
    7548:	movabs rsi,0xffffffff0fffffff
    7552:	and    rbx,rsi
    7555:	or     rbx,r11
    7558:	pop    r11
    755a:	pop    r10
    755c:	pop    rsi
    755d:	pop    rdx
    755e:	mov    QWORD PTR [r12+0x108],rbx
    7566:	mov    eax,0x410278
    756b:	mov    QWORD PTR [r12+0x100],rax
    7573:	add    rsp,0x150
    757a:	mov    eax,0x3
    757f:	movabs r11,0x6478df27b390
    7589:	jmp    r11
    758c:	jmp    0xed8
    7591:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75a0:	sub    rsp,0x150
    75a7:	mov    r11,QWORD PTR [r12+0x398]
    75af:	mov    QWORD PTR [rsp],r11
    75b3:	cmp    DWORD PTR [r12+0x310],0x0
    75bc:	je     0x764c
    75c2:	push   rdx
    75c3:	push   rsi
    75c4:	push   r10
    75c6:	push   r11
    75c8:	mov    rdx,QWORD PTR [rsp+0x20]
    75cd:	mov    r10d,edx
    75d0:	and    r10d,0xc0
    75d7:	shl    r10d,0x18
    75db:	mov    r11d,edx
    75de:	and    r11d,0x1
    75e2:	shl    r11d,0x1d
    75e6:	or     r10d,r11d
    75e9:	mov    r11d,edx
    75ec:	and    r11d,0x800
    75f3:	shl    r11d,0x11
    75f7:	or     r10d,r11d
    75fa:	btc    r10,0x1d
    75ff:	mov    r11d,0xf0000000
    7605:	and    r11,r10
    7608:	movabs rsi,0xffffffff0fffffff
    7612:	and    rbx,rsi
    7615:	or     rbx,r11
    7618:	pop    r11
    761a:	pop    r10
    761c:	pop    rsi
    761d:	pop    rdx
    761e:	mov    QWORD PTR [r12+0x108],rbx
    7626:	mov    eax,0x410444
    762b:	mov    QWORD PTR [r12+0x100],rax
    7633:	add    rsp,0x150
    763a:	mov    eax,0x3
    763f:	movabs r11,0x6478df27b390
    7649:	jmp    r11
    764c:	jmp    0x4a9d
    7651:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7660:	sub    rsp,0x150
    7667:	mov    r11,QWORD PTR [r12+0x398]
    766f:	mov    QWORD PTR [rsp],r11
    7673:	cmp    DWORD PTR [r12+0x310],0x0
    767c:	je     0x770c
    7682:	push   rdx
    7683:	push   rsi
    7684:	push   r10
    7686:	push   r11
    7688:	mov    rdx,QWORD PTR [rsp+0x20]
    768d:	mov    r10d,edx
    7690:	and    r10d,0xc0
    7697:	shl    r10d,0x18
    769b:	mov    r11d,edx
    769e:	and    r11d,0x1
    76a2:	shl    r11d,0x1d
    76a6:	or     r10d,r11d
    76a9:	mov    r11d,edx
    76ac:	and    r11d,0x800
    76b3:	shl    r11d,0x11
    76b7:	or     r10d,r11d
    76ba:	btc    r10,0x1d
    76bf:	mov    r11d,0xf0000000
    76c5:	and    r11,r10
    76c8:	movabs rsi,0xffffffff0fffffff
    76d2:	and    rbx,rsi
    76d5:	or     rbx,r11
    76d8:	pop    r11
    76da:	pop    r10
    76dc:	pop    rsi
    76dd:	pop    rdx
    76de:	mov    QWORD PTR [r12+0x108],rbx
    76e6:	mov    eax,0x410450
    76eb:	mov    QWORD PTR [r12+0x100],rax
    76f3:	add    rsp,0x150
    76fa:	mov    eax,0x3
    76ff:	movabs r11,0x6478df27b390
    7709:	jmp    r11
    770c:	jmp    0x4ad3
    7711:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7720:	sub    rsp,0x150
    7727:	mov    r11,QWORD PTR [r12+0x398]
    772f:	mov    QWORD PTR [rsp],r11
    7733:	cmp    DWORD PTR [r12+0x310],0x0
    773c:	je     0x77cc
    7742:	push   rdx
    7743:	push   rsi
    7744:	push   r10
    7746:	push   r11
    7748:	mov    rdx,QWORD PTR [rsp+0x20]
    774d:	mov    r10d,edx
    7750:	and    r10d,0xc0
    7757:	shl    r10d,0x18
    775b:	mov    r11d,edx
    775e:	and    r11d,0x1
    7762:	shl    r11d,0x1d
    7766:	or     r10d,r11d
    7769:	mov    r11d,edx
    776c:	and    r11d,0x800
    7773:	shl    r11d,0x11
    7777:	or     r10d,r11d
    777a:	btc    r10,0x1d
    777f:	mov    r11d,0xf0000000
    7785:	and    r11,r10
    7788:	movabs rsi,0xffffffff0fffffff
    7792:	and    rbx,rsi
    7795:	or     rbx,r11
    7798:	pop    r11
    779a:	pop    r10
    779c:	pop    rsi
    779d:	pop    rdx
    779e:	mov    QWORD PTR [r12+0x108],rbx
    77a6:	mov    eax,0x410474
    77ab:	mov    QWORD PTR [r12+0x100],rax
    77b3:	add    rsp,0x150
    77ba:	mov    eax,0x3
    77bf:	movabs r11,0x6478df27b390
    77c9:	jmp    r11
    77cc:	jmp    0x4c52
    77d1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77e0:	sub    rsp,0x150
    77e7:	mov    r11,QWORD PTR [r12+0x398]
    77ef:	mov    QWORD PTR [rsp],r11
    77f3:	cmp    DWORD PTR [r12+0x310],0x0
    77fc:	je     0x788c
    7802:	push   rdx
    7803:	push   rsi
    7804:	push   r10
    7806:	push   r11
    7808:	mov    rdx,QWORD PTR [rsp+0x20]
    780d:	mov    r10d,edx
    7810:	and    r10d,0xc0
    7817:	shl    r10d,0x18
    781b:	mov    r11d,edx
    781e:	and    r11d,0x1
    7822:	shl    r11d,0x1d
    7826:	or     r10d,r11d
    7829:	mov    r11d,edx
    782c:	and    r11d,0x800
    7833:	shl    r11d,0x11
    7837:	or     r10d,r11d
    783a:	btc    r10,0x1d
    783f:	mov    r11d,0xf0000000
    7845:	and    r11,r10
    7848:	movabs rsi,0xffffffff0fffffff
    7852:	and    rbx,rsi
    7855:	or     rbx,r11
    7858:	pop    r11
    785a:	pop    r10
    785c:	pop    rsi
    785d:	pop    rdx
    785e:	mov    QWORD PTR [r12+0x108],rbx
    7866:	mov    eax,0x410490
    786b:	mov    QWORD PTR [r12+0x100],rax
    7873:	add    rsp,0x150
    787a:	mov    eax,0x3
    787f:	movabs r11,0x6478df27b390
    7889:	jmp    r11
    788c:	jmp    0x4dea
    7891:	nop
    7892:	nop
    7893:	nop
