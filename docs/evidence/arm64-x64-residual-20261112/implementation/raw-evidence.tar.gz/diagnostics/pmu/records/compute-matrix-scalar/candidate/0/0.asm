
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-pmu/records/compute-matrix-scalar/candidate/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	sub    rsp,0x150
       7:	mov    r11,QWORD PTR [r12+0x398]
       f:	mov    QWORD PTR [rsp],r11
      13:	cmp    DWORD PTR [r12+0x310],0x0
      1c:	je     0xa7
      22:	push   rdx
      23:	push   rsi
      24:	push   r10
      26:	push   r11
      28:	mov    rdx,QWORD PTR [rsp+0x20]
      2d:	mov    r10d,edx
      30:	and    r10d,0xc000
      37:	shl    r10d,0x10
      3b:	mov    r11d,edx
      3e:	and    r11d,0x100
      45:	shl    r11d,0x15
      49:	or     r10d,r11d
      4c:	and    edx,0x1
      4f:	shl    edx,0x1c
      52:	or     r10d,edx
      55:	btc    r10,0x1d
      5a:	mov    r11d,0xf0000000
      60:	and    r11,r10
      63:	movabs rsi,0xffffffff0fffffff
      6d:	and    rbx,rsi
      70:	or     rbx,r11
      73:	pop    r11
      75:	pop    r10
      77:	pop    rsi
      78:	pop    rdx
      79:	mov    QWORD PTR [r12+0x108],rbx
      81:	mov    eax,0x410034
      86:	mov    QWORD PTR [r12+0x100],rax
      8e:	add    rsp,0x150
      95:	mov    eax,0x3
      9a:	movabs r11,0x5b73ef33eca0
      a4:	jmp    r11
      a7:	mov    r13d,0x0
      ad:	mov    QWORD PTR [r12+0x58],r13
      b2:	mov    r13d,0x420000
      b8:	add    r13,0x1c0
      bf:	mov    QWORD PTR [r12+0x40],r13
      c4:	mov    r13d,0x41
      ca:	mov    QWORD PTR [r12+0x50],r13
      cf:	mov    r13d,0x420000
      d5:	add    r13,0x3c0
      dc:	mov    QWORD PTR [r12+0x48],r13
      e1:	jmp    0xe6
      e6:	mov    r13,QWORD PTR [r12+0x58]
      eb:	add    r13,0x1
      ef:	mov    QWORD PTR [r12+0x60],r13
      f4:	lea    r13,[r12]
      f8:	mov    r14d,0x1e43f541
      fe:	mov    r15d,0x410050
     104:	mov    rdx,QWORD PTR [rsp]
     108:	mov    r10d,edx
     10b:	and    r10d,0xc000
     112:	shl    r10d,0x10
     116:	mov    r11d,edx
     119:	and    r11d,0x100
     120:	shl    r11d,0x15
     124:	or     r10d,r11d
     127:	and    edx,0x1
     12a:	shl    edx,0x1c
     12d:	or     r10d,edx
     130:	btc    r10,0x1d
     135:	mov    r11d,0xf0000000
     13b:	and    r11,r10
     13e:	movabs rsi,0xffffffff0fffffff
     148:	and    rbx,rsi
     14b:	or     rbx,r11
     14e:	mov    QWORD PTR [r12+0x378],0x3
     15a:	mov    QWORD PTR [r12+0x108],rbx
     162:	stmxcsr DWORD PTR [r12-0x28]
     168:	mov    r10d,DWORD PTR [r12-0x28]
     16d:	test   r10d,0x3f
     174:	je     0x199
     17a:	mov    r11d,r10d
     17d:	shr    r10d,1
     180:	and    r10d,0x1e
     184:	and    r11d,0x1
     188:	or     r10d,r11d
     18b:	or     DWORD PTR [r12+0x314],r10d
     193:	and    DWORD PTR [r12-0x28],0xffffffc0
     199:	ldmxcsr DWORD PTR [r12-0x38]
     19f:	movabs r11,0x5b73ef1a05e0
     1a9:	mov    rdi,r13
     1ac:	mov    rsi,r14
     1af:	mov    rdx,r15
     1b2:	call   r11
     1b5:	ldmxcsr DWORD PTR [r12-0x28]
     1bb:	mov    rbx,QWORD PTR [r12+0x108]
     1c3:	mov    QWORD PTR [r12+0x378],0x2
     1cf:	mov    rbp,rax
     1d2:	mov    r13,QWORD PTR [r12+0x58]
     1d7:	ror    r13,0x3d
     1db:	and    r13,0xfffffffffffffff8
     1df:	mov    QWORD PTR [r12+0x58],r13
     1e4:	lea    r13,[r12]
     1e8:	mov    r14d,0x1e43ed80
     1ee:	mov    r15d,0x410058
     1f4:	mov    QWORD PTR [r12+0x378],0x3
     200:	mov    QWORD PTR [r12+0x108],rbx
     208:	stmxcsr DWORD PTR [r12-0x28]
     20e:	mov    r10d,DWORD PTR [r12-0x28]
     213:	test   r10d,0x3f
     21a:	je     0x23f
     220:	mov    r11d,r10d
     223:	shr    r10d,1
     226:	and    r10d,0x1e
     22a:	and    r11d,0x1
     22e:	or     r10d,r11d
     231:	or     DWORD PTR [r12+0x314],r10d
     239:	and    DWORD PTR [r12-0x28],0xffffffc0
     23f:	ldmxcsr DWORD PTR [r12-0x38]
     245:	movabs r11,0x5b73ef1a05e0
     24f:	mov    rdi,r13
     252:	mov    rsi,r14
     255:	mov    rdx,r15
     258:	call   r11
     25b:	ldmxcsr DWORD PTR [r12-0x28]
     261:	mov    rbx,QWORD PTR [r12+0x108]
     269:	mov    QWORD PTR [r12+0x378],0x2
     275:	mov    rbp,rax
     278:	mov    r13,QWORD PTR [r12+0x60]
     27d:	mov    r14,r13
     280:	sub    r14,0x40
     284:	mov    r14d,DWORD PTR [r12+0x50]
     289:	lea    r14d,[r14-0x1]
     28d:	mov    QWORD PTR [r12+0x50],r14
     292:	mov    r14,QWORD PTR [r12+0x58]
     297:	mov    r15,QWORD PTR [r12+0x48]
     29c:	setne  BYTE PTR [rsp+0x8]
     2a1:	mov    r11,rax
     2a4:	lahf
     2a5:	seto   al
     2a8:	mov    WORD PTR [rsp],ax
     2ac:	mov    rax,r11
     2af:	add    r15,r14
     2b2:	mov    rbp,QWORD PTR [r12+0x120]
     2ba:	mov    QWORD PTR [r15],rbp
     2bd:	mov    r15d,0x0
     2c3:	mov    DWORD PTR [r12+0x32c],r15d
     2cb:	mov    r15,QWORD PTR [r12+0x40]
     2d0:	add    r15,r14
     2d3:	mov    r14,QWORD PTR [r12+0x110]
     2db:	mov    QWORD PTR [r15],r14
     2de:	mov    r14d,0x0
     2e4:	or     r14,r13
     2e7:	mov    QWORD PTR [r12+0x58],r14
     2ec:	mov    rcx,QWORD PTR [r12+0x380]
     2f4:	jrcxz  0x2fb
     2f6:	jmp    0x19a5
     2fb:	cmp    BYTE PTR [rsp+0x8],0x0
     300:	jne    0xe6
     306:	jmp    0x30b
     30b:	mov    r13d,0x0
     311:	mov    r14d,0x0
     317:	mov    QWORD PTR [r12+0x110],r13
     31f:	mov    QWORD PTR [r12+0x118],r14
     327:	mov    r13d,0x0
     32d:	mov    QWORD PTR [r12+0x58],r13
     332:	mov    r13d,0x420000
     338:	add    r13,0x5c0
     33f:	mov    QWORD PTR [r12+0x50],r13
     344:	mov    r11,rax
     347:	movzx  eax,WORD PTR [rsp]
     34b:	add    al,0x7f
     34d:	sahf
     34e:	mov    rax,r11
     351:	jmp    0x356
     356:	mov    r13d,0x0
     35c:	mov    QWORD PTR [r12+0x60],r13
     361:	mov    r13d,0x0
     367:	mov    r14,QWORD PTR [r12+0x50]
     36c:	mov    r11,rax
     36f:	lahf
     370:	seto   al
     373:	mov    WORD PTR [rsp],ax
     377:	mov    rax,r11
     37a:	or     r13,r14
     37d:	mov    QWORD PTR [r12+0x68],r13
     382:	mov    r11,rax
     385:	movzx  eax,WORD PTR [rsp]
     389:	add    al,0x7f
     38b:	sahf
     38c:	mov    rax,r11
     38f:	jmp    0x394
     394:	mov    r13,QWORD PTR [r12+0x60]
     399:	mov    r11,rax
     39c:	lahf
     39d:	seto   al
     3a0:	mov    WORD PTR [rsp],ax
     3a4:	mov    rax,r11
     3a7:	shl    r13,0x6
     3ab:	mov    r14,QWORD PTR [r12+0x40]
     3b0:	add    r14,r13
     3b3:	mov    QWORD PTR [r12+0x70],r14
     3b8:	mov    r13,r14
     3bb:	add    r13,0x8
     3bf:	mov    r15,QWORD PTR [r14]
     3c2:	mov    rbp,QWORD PTR [r13+0x0]
     3c6:	mov    r13d,0x0
     3cc:	mov    QWORD PTR [r12+0x120],r15
     3d4:	mov    QWORD PTR [r12+0x128],r13
     3dc:	mov    r13d,0x0
     3e2:	mov    QWORD PTR [r12+0x130],rbp
     3ea:	mov    QWORD PTR [r12+0x138],r13
     3f2:	mov    r13,r14
     3f5:	add    r13,0x10
     3f9:	mov    r15,r13
     3fc:	add    r15,0x8
     400:	mov    rbp,QWORD PTR [r13+0x0]
     404:	mov    r13,QWORD PTR [r15]
     407:	mov    r15d,0x0
     40d:	mov    QWORD PTR [r12+0x140],rbp
     415:	mov    QWORD PTR [r12+0x148],r15
     41d:	mov    r15d,0x0
     423:	mov    QWORD PTR [r12+0x150],r13
     42b:	mov    QWORD PTR [r12+0x158],r15
     433:	mov    r13,r14
     436:	add    r13,0x20
     43a:	mov    r15,r13
     43d:	add    r15,0x8
     441:	mov    rbp,QWORD PTR [r13+0x0]
     445:	mov    r13,QWORD PTR [r15]
     448:	mov    r15d,0x0
     44e:	mov    QWORD PTR [r12+0x160],rbp
     456:	mov    QWORD PTR [r12+0x168],r15
     45e:	mov    r15d,0x0
     464:	mov    QWORD PTR [r12+0x170],r13
     46c:	mov    QWORD PTR [r12+0x178],r15
     474:	add    r14,0x30
     478:	mov    r13,r14
     47b:	add    r13,0x8
     47f:	mov    r15,QWORD PTR [r14]
     482:	mov    r14,QWORD PTR [r13+0x0]
     486:	mov    r13d,0x0
     48c:	mov    QWORD PTR [r12+0x180],r15
     494:	mov    QWORD PTR [r12+0x188],r13
     49c:	mov    r13d,0x0
     4a2:	mov    QWORD PTR [r12+0x210],r14
     4aa:	mov    QWORD PTR [r12+0x218],r13
     4b2:	mov    r13d,0x0
     4b8:	mov    QWORD PTR [r12+0x70],r13
     4bd:	mov    r11,rax
     4c0:	movzx  eax,WORD PTR [rsp]
     4c4:	add    al,0x7f
     4c6:	sahf
     4c7:	mov    rax,r11
     4ca:	jmp    0x4cf
     4cf:	mov    r13,QWORD PTR [r12+0x70]
     4d4:	mov    r14,QWORD PTR [r12+0x48]
     4d9:	mov    r11,rax
     4dc:	lahf
     4dd:	seto   al
     4e0:	mov    WORD PTR [rsp],ax
     4e4:	mov    rax,r11
     4e7:	add    r14,r13
     4ea:	mov    QWORD PTR [r12+0x78],r14
     4ef:	mov    r15,QWORD PTR [r14]
     4f2:	mov    ebp,0x0
     4f7:	mov    QWORD PTR [r12+0x220],r15
     4ff:	mov    QWORD PTR [r12+0x228],rbp
     507:	mov    r15,r14
     50a:	add    r15,0x40
     50e:	mov    rbp,QWORD PTR [r15]
     511:	mov    r15d,0x0
     517:	mov    QWORD PTR [r12+0x230],rbp
     51f:	mov    QWORD PTR [r12+0x238],r15
     527:	mov    r15,r14
     52a:	add    r15,0x80
     531:	mov    rbp,QWORD PTR [r15]
     534:	mov    r15d,0x0
     53a:	mov    QWORD PTR [r12+0x240],rbp
     542:	mov    QWORD PTR [r12+0x248],r15
     54a:	movdqu xmm2,XMMWORD PTR [r12+0x120]
     554:	movdqu xmm3,XMMWORD PTR [r12+0x220]
     55e:	movdqa xmm0,xmm2
     562:	movdqa xmm1,xmm3
     566:	movq   xmm0,xmm0
     56a:	movq   xmm1,xmm1
     56e:	mulsd  xmm0,xmm1
     572:	movdqa xmm14,xmm0
     577:	movdqu xmm15,XMMWORD PTR [rip+0x1e90]        # 0x2410
     580:	pand   xmm14,xmm15
     585:	movdqu xmm15,XMMWORD PTR [rip+0x1e92]        # 0x2420
     58e:	pcmpeqq xmm14,xmm15
     594:	movdqa xmm15,xmm0
     599:	cmpunordpd xmm15,xmm0
     59f:	por    xmm14,xmm15
     5a4:	pmovmskb ecx,xmm14
     5a9:	jrcxz  0x5b0
     5ab:	jmp    0xec4
     5b0:	movdqa xmm4,xmm0
     5b4:	movdqu xmm2,XMMWORD PTR [r12+0x130]
     5be:	movdqu xmm3,XMMWORD PTR [r12+0x230]
     5c8:	movdqa xmm0,xmm2
     5cc:	movdqa xmm1,xmm3
     5d0:	movq   xmm0,xmm0
     5d4:	movq   xmm1,xmm1
     5d8:	mulsd  xmm0,xmm1
     5dc:	movdqa xmm14,xmm0
     5e1:	movdqu xmm15,XMMWORD PTR [rip+0x1e26]        # 0x2410
     5ea:	pand   xmm14,xmm15
     5ef:	movdqu xmm15,XMMWORD PTR [rip+0x1e28]        # 0x2420
     5f8:	pcmpeqq xmm14,xmm15
     5fe:	movdqa xmm15,xmm0
     603:	cmpunordpd xmm15,xmm0
     609:	por    xmm14,xmm15
     60e:	pmovmskb ecx,xmm14
     613:	jrcxz  0x61a
     615:	jmp    0xee8
     61a:	movdqa xmm5,xmm0
     61e:	movdqu xmm2,XMMWORD PTR [r12+0x110]
     628:	movdqa xmm0,xmm4
     62c:	movdqa xmm1,xmm2
     630:	movq   xmm0,xmm0
     634:	movq   xmm1,xmm1
     638:	addsd  xmm0,xmm1
     63c:	movdqa xmm14,xmm0
     641:	movdqu xmm15,XMMWORD PTR [rip+0x1dc6]        # 0x2410
     64a:	pand   xmm14,xmm15
     64f:	movdqu xmm15,XMMWORD PTR [rip+0x1dc8]        # 0x2420
     658:	pcmpeqq xmm14,xmm15
     65e:	movdqa xmm15,xmm0
     663:	cmpunordpd xmm15,xmm0
     669:	por    xmm14,xmm15
     66e:	pmovmskb ecx,xmm14
     673:	jrcxz  0x67a
     675:	jmp    0xf0c
     67a:	movdqa xmm3,xmm0
     67e:	movdqa xmm0,xmm3
     682:	movdqa xmm1,xmm5
     686:	movq   xmm0,xmm0
     68a:	movq   xmm1,xmm1
     68e:	addsd  xmm0,xmm1
     692:	movdqa xmm14,xmm0
     697:	movdqu xmm15,XMMWORD PTR [rip+0x1d70]        # 0x2410
     6a0:	pand   xmm14,xmm15
     6a5:	movdqu xmm15,XMMWORD PTR [rip+0x1d72]        # 0x2420
     6ae:	pcmpeqq xmm14,xmm15
     6b4:	movdqa xmm15,xmm0
     6b9:	cmpunordpd xmm15,xmm0
     6bf:	por    xmm14,xmm15
     6c4:	pmovmskb ecx,xmm14
     6c9:	jrcxz  0x6d0
     6cb:	jmp    0xf30
     6d0:	movdqa xmm2,xmm0
     6d4:	movdqu XMMWORD PTR [r12+0x220],xmm2
     6de:	movdqu xmm3,XMMWORD PTR [r12+0x140]
     6e8:	movdqu xmm4,XMMWORD PTR [r12+0x240]
     6f2:	movdqa xmm0,xmm3
     6f6:	movdqa xmm1,xmm4
     6fa:	movq   xmm0,xmm0
     6fe:	movq   xmm1,xmm1
     702:	mulsd  xmm0,xmm1
     706:	movdqa xmm14,xmm0
     70b:	movdqu xmm15,XMMWORD PTR [rip+0x1cfc]        # 0x2410
     714:	pand   xmm14,xmm15
     719:	movdqu xmm15,XMMWORD PTR [rip+0x1cfe]        # 0x2420
     722:	pcmpeqq xmm14,xmm15
     728:	movdqa xmm15,xmm0
     72d:	cmpunordpd xmm15,xmm0
     733:	por    xmm14,xmm15
     738:	pmovmskb ecx,xmm14
     73d:	jrcxz  0x744
     73f:	jmp    0xf54
     744:	movdqa xmm5,xmm0
     748:	movdqu XMMWORD PTR [r12+0x230],xmm5
     752:	mov    r15,r14
     755:	add    r15,0xc0
     75c:	mov    rbp,QWORD PTR [r15]
     75f:	mov    r15d,0x0
     765:	mov    QWORD PTR [r12+0x240],rbp
     76d:	mov    QWORD PTR [r12+0x248],r15
     775:	movdqa xmm0,xmm2
     779:	movdqa xmm1,xmm5
     77d:	movq   xmm0,xmm0
     781:	movq   xmm1,xmm1
     785:	addsd  xmm0,xmm1
     789:	movdqa xmm14,xmm0
     78e:	movdqu xmm15,XMMWORD PTR [rip+0x1c79]        # 0x2410
     797:	pand   xmm14,xmm15
     79c:	movdqu xmm15,XMMWORD PTR [rip+0x1c7b]        # 0x2420
     7a5:	pcmpeqq xmm14,xmm15
     7ab:	movdqa xmm15,xmm0
     7b0:	cmpunordpd xmm15,xmm0
     7b6:	por    xmm14,xmm15
     7bb:	pmovmskb ecx,xmm14
     7c0:	jrcxz  0x7c7
     7c2:	jmp    0xf78
     7c7:	movdqa xmm3,xmm0
     7cb:	movdqu XMMWORD PTR [r12+0x220],xmm3
     7d5:	movdqu xmm2,XMMWORD PTR [r12+0x150]
     7df:	movdqu xmm4,XMMWORD PTR [r12+0x240]
     7e9:	movdqa xmm0,xmm2
     7ed:	movdqa xmm1,xmm4
     7f1:	movq   xmm0,xmm0
     7f5:	movq   xmm1,xmm1
     7f9:	mulsd  xmm0,xmm1
     7fd:	movdqa xmm14,xmm0
     802:	movdqu xmm15,XMMWORD PTR [rip+0x1c05]        # 0x2410
     80b:	pand   xmm14,xmm15
     810:	movdqu xmm15,XMMWORD PTR [rip+0x1c07]        # 0x2420
     819:	pcmpeqq xmm14,xmm15
     81f:	movdqa xmm15,xmm0
     824:	cmpunordpd xmm15,xmm0
     82a:	por    xmm14,xmm15
     82f:	pmovmskb ecx,xmm14
     834:	jrcxz  0x83b
     836:	jmp    0xf9c
     83b:	movdqa xmm5,xmm0
     83f:	movdqu XMMWORD PTR [r12+0x230],xmm5
     849:	mov    r15,r14
     84c:	add    r15,0x100
     853:	mov    rbp,QWORD PTR [r15]
     856:	mov    r15d,0x0
     85c:	mov    QWORD PTR [r12+0x240],rbp
     864:	mov    QWORD PTR [r12+0x248],r15
     86c:	movdqa xmm0,xmm3
     870:	movdqa xmm1,xmm5
     874:	movq   xmm0,xmm0
     878:	movq   xmm1,xmm1
     87c:	addsd  xmm0,xmm1
     880:	movdqa xmm14,xmm0
     885:	movdqu xmm15,XMMWORD PTR [rip+0x1b82]        # 0x2410
     88e:	pand   xmm14,xmm15
     893:	movdqu xmm15,XMMWORD PTR [rip+0x1b84]        # 0x2420
     89c:	pcmpeqq xmm14,xmm15
     8a2:	movdqa xmm15,xmm0
     8a7:	cmpunordpd xmm15,xmm0
     8ad:	por    xmm14,xmm15
     8b2:	pmovmskb ecx,xmm14
     8b7:	jrcxz  0x8be
     8b9:	jmp    0xfc0
     8be:	movdqa xmm2,xmm0
     8c2:	movdqu XMMWORD PTR [r12+0x220],xmm2
     8cc:	movdqu xmm3,XMMWORD PTR [r12+0x160]
     8d6:	movdqu xmm4,XMMWORD PTR [r12+0x240]
     8e0:	movdqa xmm0,xmm3
     8e4:	movdqa xmm1,xmm4
     8e8:	movq   xmm0,xmm0
     8ec:	movq   xmm1,xmm1
     8f0:	mulsd  xmm0,xmm1
     8f4:	movdqa xmm14,xmm0
     8f9:	movdqu xmm15,XMMWORD PTR [rip+0x1b0e]        # 0x2410
     902:	pand   xmm14,xmm15
     907:	movdqu xmm15,XMMWORD PTR [rip+0x1b10]        # 0x2420
     910:	pcmpeqq xmm14,xmm15
     916:	movdqa xmm15,xmm0
     91b:	cmpunordpd xmm15,xmm0
     921:	por    xmm14,xmm15
     926:	pmovmskb ecx,xmm14
     92b:	jrcxz  0x932
     92d:	jmp    0xfe4
     932:	movdqa xmm5,xmm0
     936:	movdqu XMMWORD PTR [r12+0x230],xmm5
     940:	mov    r15,r14
     943:	add    r15,0x140
     94a:	mov    rbp,QWORD PTR [r15]
     94d:	mov    r15d,0x0
     953:	mov    QWORD PTR [r12+0x240],rbp
     95b:	mov    QWORD PTR [r12+0x248],r15
     963:	movdqa xmm0,xmm2
     967:	movdqa xmm1,xmm5
     96b:	movq   xmm0,xmm0
     96f:	movq   xmm1,xmm1
     973:	addsd  xmm0,xmm1
     977:	movdqa xmm14,xmm0
     97c:	movdqu xmm15,XMMWORD PTR [rip+0x1a8b]        # 0x2410
     985:	pand   xmm14,xmm15
     98a:	movdqu xmm15,XMMWORD PTR [rip+0x1a8d]        # 0x2420
     993:	pcmpeqq xmm14,xmm15
     999:	movdqa xmm15,xmm0
     99e:	cmpunordpd xmm15,xmm0
     9a4:	por    xmm14,xmm15
     9a9:	pmovmskb ecx,xmm14
     9ae:	jrcxz  0x9b5
     9b0:	jmp    0x1008
     9b5:	movdqa xmm3,xmm0
     9b9:	movdqu XMMWORD PTR [r12+0x220],xmm3
     9c3:	movdqu xmm2,XMMWORD PTR [r12+0x170]
     9cd:	movdqu xmm4,XMMWORD PTR [r12+0x240]
     9d7:	movdqa xmm0,xmm2
     9db:	movdqa xmm1,xmm4
     9df:	movq   xmm0,xmm0
     9e3:	movq   xmm1,xmm1
     9e7:	mulsd  xmm0,xmm1
     9eb:	movdqa xmm14,xmm0
     9f0:	movdqu xmm15,XMMWORD PTR [rip+0x1a17]        # 0x2410
     9f9:	pand   xmm14,xmm15
     9fe:	movdqu xmm15,XMMWORD PTR [rip+0x1a19]        # 0x2420
     a07:	pcmpeqq xmm14,xmm15
     a0d:	movdqa xmm15,xmm0
     a12:	cmpunordpd xmm15,xmm0
     a18:	por    xmm14,xmm15
     a1d:	pmovmskb ecx,xmm14
     a22:	jrcxz  0xa29
     a24:	jmp    0x102c
     a29:	movdqa xmm5,xmm0
     a2d:	movdqu XMMWORD PTR [r12+0x230],xmm5
     a37:	mov    r15,r14
     a3a:	add    r15,0x180
     a41:	mov    rbp,QWORD PTR [r15]
     a44:	mov    r15d,0x0
     a4a:	mov    QWORD PTR [r12+0x240],rbp
     a52:	mov    QWORD PTR [r12+0x248],r15
     a5a:	movdqa xmm0,xmm3
     a5e:	movdqa xmm1,xmm5
     a62:	movq   xmm0,xmm0
     a66:	movq   xmm1,xmm1
     a6a:	addsd  xmm0,xmm1
     a6e:	movdqa xmm14,xmm0
     a73:	movdqu xmm15,XMMWORD PTR [rip+0x1994]        # 0x2410
     a7c:	pand   xmm14,xmm15
     a81:	movdqu xmm15,XMMWORD PTR [rip+0x1996]        # 0x2420
     a8a:	pcmpeqq xmm14,xmm15
     a90:	movdqa xmm15,xmm0
     a95:	cmpunordpd xmm15,xmm0
     a9b:	por    xmm14,xmm15
     aa0:	pmovmskb ecx,xmm14
     aa5:	jrcxz  0xaac
     aa7:	jmp    0x1050
     aac:	movdqa xmm2,xmm0
     ab0:	movdqu XMMWORD PTR [r12+0x220],xmm2
     aba:	movdqu xmm3,XMMWORD PTR [r12+0x180]
     ac4:	movdqu xmm4,XMMWORD PTR [r12+0x240]
     ace:	movdqa xmm0,xmm3
     ad2:	movdqa xmm1,xmm4
     ad6:	movq   xmm0,xmm0
     ada:	movq   xmm1,xmm1
     ade:	mulsd  xmm0,xmm1
     ae2:	movdqa xmm14,xmm0
     ae7:	movdqu xmm15,XMMWORD PTR [rip+0x1920]        # 0x2410
     af0:	pand   xmm14,xmm15
     af5:	movdqu xmm15,XMMWORD PTR [rip+0x1922]        # 0x2420
     afe:	pcmpeqq xmm14,xmm15
     b04:	movdqa xmm15,xmm0
     b09:	cmpunordpd xmm15,xmm0
     b0f:	por    xmm14,xmm15
     b14:	pmovmskb ecx,xmm14
     b19:	jrcxz  0xb20
     b1b:	jmp    0x1074
     b20:	movdqa xmm5,xmm0
     b24:	movdqu XMMWORD PTR [r12+0x230],xmm5
     b2e:	add    r14,0x1c0
     b35:	mov    r15,QWORD PTR [r14]
     b38:	mov    r14d,0x0
     b3e:	mov    QWORD PTR [r12+0x240],r15
     b46:	mov    QWORD PTR [r12+0x248],r14
     b4e:	movdqa xmm0,xmm2
     b52:	movdqa xmm1,xmm5
     b56:	movq   xmm0,xmm0
     b5a:	movq   xmm1,xmm1
     b5e:	addsd  xmm0,xmm1
     b62:	movdqa xmm14,xmm0
     b67:	movdqu xmm15,XMMWORD PTR [rip+0x18a0]        # 0x2410
     b70:	pand   xmm14,xmm15
     b75:	movdqu xmm15,XMMWORD PTR [rip+0x18a2]        # 0x2420
     b7e:	pcmpeqq xmm14,xmm15
     b84:	movdqa xmm15,xmm0
     b89:	cmpunordpd xmm15,xmm0
     b8f:	por    xmm14,xmm15
     b94:	pmovmskb ecx,xmm14
     b99:	jrcxz  0xba0
     b9b:	jmp    0x1098
     ba0:	movdqa xmm3,xmm0
     ba4:	movdqu xmm2,XMMWORD PTR [r12+0x210]
     bae:	movdqu xmm4,XMMWORD PTR [r12+0x240]
     bb8:	movdqa xmm0,xmm2
     bbc:	movdqa xmm1,xmm4
     bc0:	movq   xmm0,xmm0
     bc4:	movq   xmm1,xmm1
     bc8:	mulsd  xmm0,xmm1
     bcc:	movdqa xmm14,xmm0
     bd1:	movdqu xmm15,XMMWORD PTR [rip+0x1836]        # 0x2410
     bda:	pand   xmm14,xmm15
     bdf:	movdqu xmm15,XMMWORD PTR [rip+0x1838]        # 0x2420
     be8:	pcmpeqq xmm14,xmm15
     bee:	movdqa xmm15,xmm0
     bf3:	cmpunordpd xmm15,xmm0
     bf9:	por    xmm14,xmm15
     bfe:	pmovmskb ecx,xmm14
     c03:	jrcxz  0xc0a
     c05:	jmp    0x10bc
     c0a:	movdqa xmm5,xmm0
     c0e:	movdqu XMMWORD PTR [r12+0x230],xmm5
     c18:	movdqa xmm0,xmm3
     c1c:	movdqa xmm1,xmm5
     c20:	movq   xmm0,xmm0
     c24:	movq   xmm1,xmm1
     c28:	addsd  xmm0,xmm1
     c2c:	movdqa xmm14,xmm0
     c31:	movdqu xmm15,XMMWORD PTR [rip+0x17d6]        # 0x2410
     c3a:	pand   xmm14,xmm15
     c3f:	movdqu xmm15,XMMWORD PTR [rip+0x17d8]        # 0x2420
     c48:	pcmpeqq xmm14,xmm15
     c4e:	movdqa xmm15,xmm0
     c53:	cmpunordpd xmm15,xmm0
     c59:	por    xmm14,xmm15
     c5e:	pmovmskb ecx,xmm14
     c63:	jrcxz  0xc6a
     c65:	jmp    0x10e0
     c6a:	movdqa xmm2,xmm0
     c6e:	movdqu XMMWORD PTR [r12+0x220],xmm2
     c78:	mov    r14,QWORD PTR [r12+0x68]
     c7d:	add    r14,r13
     c80:	mov    r15,QWORD PTR [r12+0x220]
     c88:	mov    QWORD PTR [r14],r15
     c8b:	mov    r14d,0x0
     c91:	mov    DWORD PTR [r12+0x32c],r14d
     c99:	add    r13,0x8
     c9d:	mov    QWORD PTR [r12+0x70],r13
     ca2:	sub    r13,0x40
     ca6:	mov    rcx,QWORD PTR [r12+0x380]
     cae:	jrcxz  0xcb5
     cb0:	jmp    0x1a2a
     cb5:	jne    0x4cf
     cbb:	jmp    0xcc0
     cc0:	mov    r13,QWORD PTR [r12+0x60]
     cc5:	add    r13,0x1
     cc9:	mov    QWORD PTR [r12+0x60],r13
     cce:	mov    r14,QWORD PTR [r12+0x68]
     cd3:	add    r14,0x40
     cd7:	mov    QWORD PTR [r12+0x68],r14
     cdc:	sub    r13,0x8
     ce0:	mov    rcx,QWORD PTR [r12+0x380]
     ce8:	jrcxz  0xcef
     cea:	jmp    0x1abe
     cef:	jne    0x394
     cf5:	jmp    0xcfa
     cfa:	mov    r13d,DWORD PTR [r12+0x58]
     cff:	add    r13d,0x1
     d03:	mov    QWORD PTR [r12+0x58],r13
     d08:	sub    r13d,0x1f4
     d0f:	mov    rcx,QWORD PTR [r12+0x380]
     d17:	jrcxz  0xd1e
     d19:	jmp    0x1b52
     d1e:	jne    0x356
     d24:	mov    r11,rax
     d27:	lahf
     d28:	seto   al
     d2b:	mov    WORD PTR [rsp],ax
     d2f:	mov    rax,r11
     d32:	jmp    0xd37
     d37:	mov    r13d,0x420000
     d3d:	mov    QWORD PTR [r12+0x40],r13
     d42:	mov    r13d,0x0
     d48:	mov    QWORD PTR [r12+0x48],r13
     d4d:	mov    r13d,0x4201b8
     d53:	mov    r14,QWORD PTR [r13+0x0]
     d57:	mov    r13d,0x0
     d5d:	mov    QWORD PTR [r12+0x110],r14
     d65:	mov    QWORD PTR [r12+0x118],r13
     d6d:	jmp    0xd72
     d72:	mov    r13,QWORD PTR [r12+0x48]
     d77:	mov    r14,QWORD PTR [r12+0x50]
     d7c:	add    r14,r13
     d7f:	mov    r15,QWORD PTR [r14]
     d82:	mov    r14d,0x0
     d88:	mov    QWORD PTR [r12+0x120],r15
     d90:	mov    QWORD PTR [r12+0x128],r14
     d98:	add    r13,0x8
     d9c:	mov    QWORD PTR [r12+0x48],r13
     da1:	sub    r13,0x200
     da8:	movdqu xmm2,XMMWORD PTR [r12+0x110]
     db2:	movdqu xmm3,XMMWORD PTR [r12+0x120]
     dbc:	movdqa xmm0,xmm2
     dc0:	movdqa xmm1,xmm3
     dc4:	movq   xmm0,xmm0
     dc8:	movq   xmm1,xmm1
     dcc:	addsd  xmm0,xmm1
     dd0:	movdqa xmm14,xmm0
     dd5:	movdqu xmm15,XMMWORD PTR [rip+0x1632]        # 0x2410
     dde:	pand   xmm14,xmm15
     de3:	movdqu xmm15,XMMWORD PTR [rip+0x1634]        # 0x2420
     dec:	pcmpeqq xmm14,xmm15
     df2:	movdqa xmm15,xmm0
     df7:	cmpunordpd xmm15,xmm0
     dfd:	por    xmm14,xmm15
     e02:	pmovmskb ecx,xmm14
     e07:	jrcxz  0xe0e
     e09:	jmp    0x1104
     e0e:	movdqa xmm4,xmm0
     e12:	movdqu XMMWORD PTR [r12+0x110],xmm4
     e1c:	mov    rcx,QWORD PTR [r12+0x380]
     e24:	jrcxz  0xe2b
     e26:	jmp    0x1be6
     e2b:	jne    0xe44
     e31:	mov    r11,rax
     e34:	lahf
     e35:	seto   al
     e38:	mov    WORD PTR [rsp],ax
     e3c:	mov    rax,r11
     e3f:	jmp    0xe57
     e44:	mov    r11,rax
     e47:	lahf
     e48:	seto   al
     e4b:	mov    WORD PTR [rsp],ax
     e4f:	mov    rax,r11
     e52:	jmp    0xd72
     e57:	mov    r13,QWORD PTR [r12+0x40]
     e5c:	add    r13,0x1b8
     e63:	mov    r14,QWORD PTR [r12+0x110]
     e6b:	mov    QWORD PTR [r13+0x0],r14
     e6f:	mov    r13d,0x0
     e75:	mov    DWORD PTR [r12+0x32c],r13d
     e7d:	mov    rcx,QWORD PTR [r12+0x380]
     e85:	jrcxz  0xe8c
     e87:	jmp    0x1c7a
     e8c:	mov    r13,QWORD PTR [r12+0xf0]
     e94:	mov    QWORD PTR [r12+0x100],r13
     e9c:	mov    r11,QWORD PTR [rsp]
     ea0:	mov    QWORD PTR [r12+0x398],r11
     ea8:	mov    rdi,QWORD PTR [r12+0x100]
     eb0:	add    rsp,0x150
     eb7:	movabs r11,0x5b73ef33e940
     ec1:	jmp    r11
     ec4:	movdqa xmm0,xmm2
     ec8:	movdqa xmm1,xmm3
     ecc:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
     ed5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
     ede:	call   0x1150
     ee3:	jmp    0x5b0
     ee8:	movdqa xmm0,xmm2
     eec:	movdqa xmm1,xmm3
     ef0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
     ef9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
     f02:	call   0x12b0
     f07:	jmp    0x61a
     f0c:	movdqa xmm0,xmm4
     f10:	movdqa xmm1,xmm2
     f14:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
     f1d:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
     f26:	call   0x1420
     f2b:	jmp    0x67a
     f30:	movdqa xmm0,xmm3
     f34:	movdqa xmm1,xmm5
     f38:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
     f41:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
     f4a:	call   0x1590
     f4f:	jmp    0x6d0
     f54:	movdqa xmm0,xmm3
     f58:	movdqa xmm1,xmm4
     f5c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
     f65:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
     f6e:	call   0x12b0
     f73:	jmp    0x744
     f78:	movdqa xmm0,xmm2
     f7c:	movdqa xmm1,xmm5
     f80:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
     f89:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
     f92:	call   0x16f0
     f97:	jmp    0x7c7
     f9c:	movdqa xmm0,xmm2
     fa0:	movdqa xmm1,xmm4
     fa4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
     fad:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
     fb6:	call   0x12b0
     fbb:	jmp    0x83b
     fc0:	movdqa xmm0,xmm3
     fc4:	movdqa xmm1,xmm5
     fc8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
     fd1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
     fda:	call   0x1590
     fdf:	jmp    0x8be
     fe4:	movdqa xmm0,xmm3
     fe8:	movdqa xmm1,xmm4
     fec:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
     ff5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
     ffe:	call   0x12b0
    1003:	jmp    0x932
    1008:	movdqa xmm0,xmm2
    100c:	movdqa xmm1,xmm5
    1010:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    1019:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    1022:	call   0x16f0
    1027:	jmp    0x9b5
    102c:	movdqa xmm0,xmm2
    1030:	movdqa xmm1,xmm4
    1034:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    103d:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    1046:	call   0x12b0
    104b:	jmp    0xa29
    1050:	movdqa xmm0,xmm3
    1054:	movdqa xmm1,xmm5
    1058:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    1061:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    106a:	call   0x1590
    106f:	jmp    0xaac
    1074:	movdqa xmm0,xmm3
    1078:	movdqa xmm1,xmm4
    107c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    1085:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    108e:	call   0x12b0
    1093:	jmp    0xb20
    1098:	movdqa xmm0,xmm2
    109c:	movdqa xmm1,xmm5
    10a0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    10a9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    10b2:	call   0x16f0
    10b7:	jmp    0xba0
    10bc:	movdqa xmm0,xmm2
    10c0:	movdqa xmm1,xmm4
    10c4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    10cd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    10d6:	call   0x12b0
    10db:	jmp    0xc0a
    10e0:	movdqa xmm0,xmm3
    10e4:	movdqa xmm1,xmm5
    10e8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    10f1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    10fa:	call   0x1590
    10ff:	jmp    0xc6a
    1104:	mov    r11,rax
    1107:	lahf
    1108:	seto   al
    110b:	mov    WORD PTR [rsp],ax
    110f:	mov    rax,r11
    1112:	movdqa xmm0,xmm2
    1116:	movdqa xmm1,xmm3
    111a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    1123:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    112c:	call   0x1850
    1131:	mov    r11,rax
    1134:	movzx  eax,WORD PTR [rsp]
    1138:	add    al,0x7f
    113a:	sahf
    113b:	mov    rax,r11
    113e:	jmp    0xe0e
    1143:	data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    1150:	sub    rsp,0x8
    1154:	mov    QWORD PTR [r12+0x378],0x3
    1160:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    1166:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    116c:	push   rdx
    116d:	push   rsi
    116e:	push   r10
    1170:	push   r11
    1172:	mov    rdx,QWORD PTR [rsp+0x30]
    1177:	mov    r10d,edx
    117a:	and    r10d,0xc000
    1181:	shl    r10d,0x10
    1185:	mov    r11d,edx
    1188:	and    r11d,0x100
    118f:	shl    r11d,0x15
    1193:	or     r10d,r11d
    1196:	and    edx,0x1
    1199:	shl    edx,0x1c
    119c:	or     r10d,edx
    119f:	btc    r10,0x1d
    11a4:	mov    r11d,0xf0000000
    11aa:	and    r11,r10
    11ad:	movabs rsi,0xffffffff0fffffff
    11b7:	and    rbx,rsi
    11ba:	or     rbx,r11
    11bd:	pop    r11
    11bf:	pop    r10
    11c1:	pop    rsi
    11c2:	pop    rdx
    11c3:	mov    QWORD PTR [r12+0x108],rbx
    11cb:	stmxcsr DWORD PTR [r12-0x28]
    11d1:	mov    r10d,DWORD PTR [r12-0x28]
    11d6:	test   r10d,0x3f
    11dd:	je     0x1202
    11e3:	mov    r11d,r10d
    11e6:	shr    r10d,1
    11e9:	and    r10d,0x1e
    11ed:	and    r11d,0x1
    11f1:	or     r10d,r11d
    11f4:	or     DWORD PTR [r12+0x314],r10d
    11fc:	and    DWORD PTR [r12-0x28],0xffffffc0
    1202:	ldmxcsr DWORD PTR [r12-0x38]
    1208:	lea    rdi,[rsp+0x110]
    1210:	lea    rsi,[rsp+0xf0]
    1218:	lea    rdx,[rsp+0x100]
    1220:	mov    ecx,0xe
    1225:	mov    r8d,0x0
    122b:	lea    r9,[r12+0x314]
    1233:	movabs r11,0x5b73ef1a5650
    123d:	call   r11
    1240:	ldmxcsr DWORD PTR [r12-0x28]
    1246:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    124c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    1252:	mov    rbx,QWORD PTR [r12+0x108]
    125a:	mov    QWORD PTR [r12+0x378],0x2
    1266:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    126f:	mov    rdx,rbx
    1272:	shr    rdx,0x10
    1276:	and    edx,0xc000
    127c:	mov    rax,rbx
    127f:	shr    rax,0x15
    1283:	and    eax,0x100
    1288:	xor    eax,0x100
    128d:	or     edx,eax
    128f:	mov    rax,rbx
    1292:	shr    rax,0x1c
    1296:	and    eax,0x1
    1299:	or     edx,eax
    129b:	mov    QWORD PTR [rsp+0x10],rdx
    12a0:	add    rsp,0x8
    12a4:	ret
    12a5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    12b0:	sub    rsp,0x8
    12b4:	mov    QWORD PTR [r12+0x378],0x3
    12c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    12c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    12cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    12d2:	push   rdx
    12d3:	push   rsi
    12d4:	push   r10
    12d6:	push   r11
    12d8:	mov    rdx,QWORD PTR [rsp+0x30]
    12dd:	mov    r10d,edx
    12e0:	and    r10d,0xc000
    12e7:	shl    r10d,0x10
    12eb:	mov    r11d,edx
    12ee:	and    r11d,0x100
    12f5:	shl    r11d,0x15
    12f9:	or     r10d,r11d
    12fc:	and    edx,0x1
    12ff:	shl    edx,0x1c
    1302:	or     r10d,edx
    1305:	btc    r10,0x1d
    130a:	mov    r11d,0xf0000000
    1310:	and    r11,r10
    1313:	movabs rsi,0xffffffff0fffffff
    131d:	and    rbx,rsi
    1320:	or     rbx,r11
    1323:	pop    r11
    1325:	pop    r10
    1327:	pop    rsi
    1328:	pop    rdx
    1329:	mov    QWORD PTR [r12+0x108],rbx
    1331:	stmxcsr DWORD PTR [r12-0x28]
    1337:	mov    r10d,DWORD PTR [r12-0x28]
    133c:	test   r10d,0x3f
    1343:	je     0x1368
    1349:	mov    r11d,r10d
    134c:	shr    r10d,1
    134f:	and    r10d,0x1e
    1353:	and    r11d,0x1
    1357:	or     r10d,r11d
    135a:	or     DWORD PTR [r12+0x314],r10d
    1362:	and    DWORD PTR [r12-0x28],0xffffffc0
    1368:	ldmxcsr DWORD PTR [r12-0x38]
    136e:	lea    rdi,[rsp+0x110]
    1376:	lea    rsi,[rsp+0xf0]
    137e:	lea    rdx,[rsp+0x100]
    1386:	mov    ecx,0xe
    138b:	mov    r8d,0x0
    1391:	lea    r9,[r12+0x314]
    1399:	movabs r11,0x5b73ef1a5650
    13a3:	call   r11
    13a6:	ldmxcsr DWORD PTR [r12-0x28]
    13ac:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    13b2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    13b8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    13be:	mov    rbx,QWORD PTR [r12+0x108]
    13c6:	mov    QWORD PTR [r12+0x378],0x2
    13d2:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    13db:	mov    rdx,rbx
    13de:	shr    rdx,0x10
    13e2:	and    edx,0xc000
    13e8:	mov    rax,rbx
    13eb:	shr    rax,0x15
    13ef:	and    eax,0x100
    13f4:	xor    eax,0x100
    13f9:	or     edx,eax
    13fb:	mov    rax,rbx
    13fe:	shr    rax,0x1c
    1402:	and    eax,0x1
    1405:	or     edx,eax
    1407:	mov    QWORD PTR [rsp+0x10],rdx
    140c:	add    rsp,0x8
    1410:	ret
    1411:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    1420:	sub    rsp,0x8
    1424:	mov    QWORD PTR [r12+0x378],0x3
    1430:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    1436:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    143c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    1442:	push   rdx
    1443:	push   rsi
    1444:	push   r10
    1446:	push   r11
    1448:	mov    rdx,QWORD PTR [rsp+0x30]
    144d:	mov    r10d,edx
    1450:	and    r10d,0xc000
    1457:	shl    r10d,0x10
    145b:	mov    r11d,edx
    145e:	and    r11d,0x100
    1465:	shl    r11d,0x15
    1469:	or     r10d,r11d
    146c:	and    edx,0x1
    146f:	shl    edx,0x1c
    1472:	or     r10d,edx
    1475:	btc    r10,0x1d
    147a:	mov    r11d,0xf0000000
    1480:	and    r11,r10
    1483:	movabs rsi,0xffffffff0fffffff
    148d:	and    rbx,rsi
    1490:	or     rbx,r11
    1493:	pop    r11
    1495:	pop    r10
    1497:	pop    rsi
    1498:	pop    rdx
    1499:	mov    QWORD PTR [r12+0x108],rbx
    14a1:	stmxcsr DWORD PTR [r12-0x28]
    14a7:	mov    r10d,DWORD PTR [r12-0x28]
    14ac:	test   r10d,0x3f
    14b3:	je     0x14d8
    14b9:	mov    r11d,r10d
    14bc:	shr    r10d,1
    14bf:	and    r10d,0x1e
    14c3:	and    r11d,0x1
    14c7:	or     r10d,r11d
    14ca:	or     DWORD PTR [r12+0x314],r10d
    14d2:	and    DWORD PTR [r12-0x28],0xffffffc0
    14d8:	ldmxcsr DWORD PTR [r12-0x38]
    14de:	lea    rdi,[rsp+0x110]
    14e6:	lea    rsi,[rsp+0xf0]
    14ee:	lea    rdx,[rsp+0x100]
    14f6:	mov    ecx,0xc
    14fb:	mov    r8d,0x0
    1501:	lea    r9,[r12+0x314]
    1509:	movabs r11,0x5b73ef1a5650
    1513:	call   r11
    1516:	ldmxcsr DWORD PTR [r12-0x28]
    151c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    1522:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    1528:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    152e:	mov    rbx,QWORD PTR [r12+0x108]
    1536:	mov    QWORD PTR [r12+0x378],0x2
    1542:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    154b:	mov    rdx,rbx
    154e:	shr    rdx,0x10
    1552:	and    edx,0xc000
    1558:	mov    rax,rbx
    155b:	shr    rax,0x15
    155f:	and    eax,0x100
    1564:	xor    eax,0x100
    1569:	or     edx,eax
    156b:	mov    rax,rbx
    156e:	shr    rax,0x1c
    1572:	and    eax,0x1
    1575:	or     edx,eax
    1577:	mov    QWORD PTR [rsp+0x10],rdx
    157c:	add    rsp,0x8
    1580:	ret
    1581:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    1590:	sub    rsp,0x8
    1594:	mov    QWORD PTR [r12+0x378],0x3
    15a0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    15a6:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    15ac:	push   rdx
    15ad:	push   rsi
    15ae:	push   r10
    15b0:	push   r11
    15b2:	mov    rdx,QWORD PTR [rsp+0x30]
    15b7:	mov    r10d,edx
    15ba:	and    r10d,0xc000
    15c1:	shl    r10d,0x10
    15c5:	mov    r11d,edx
    15c8:	and    r11d,0x100
    15cf:	shl    r11d,0x15
    15d3:	or     r10d,r11d
    15d6:	and    edx,0x1
    15d9:	shl    edx,0x1c
    15dc:	or     r10d,edx
    15df:	btc    r10,0x1d
    15e4:	mov    r11d,0xf0000000
    15ea:	and    r11,r10
    15ed:	movabs rsi,0xffffffff0fffffff
    15f7:	and    rbx,rsi
    15fa:	or     rbx,r11
    15fd:	pop    r11
    15ff:	pop    r10
    1601:	pop    rsi
    1602:	pop    rdx
    1603:	mov    QWORD PTR [r12+0x108],rbx
    160b:	stmxcsr DWORD PTR [r12-0x28]
    1611:	mov    r10d,DWORD PTR [r12-0x28]
    1616:	test   r10d,0x3f
    161d:	je     0x1642
    1623:	mov    r11d,r10d
    1626:	shr    r10d,1
    1629:	and    r10d,0x1e
    162d:	and    r11d,0x1
    1631:	or     r10d,r11d
    1634:	or     DWORD PTR [r12+0x314],r10d
    163c:	and    DWORD PTR [r12-0x28],0xffffffc0
    1642:	ldmxcsr DWORD PTR [r12-0x38]
    1648:	lea    rdi,[rsp+0x110]
    1650:	lea    rsi,[rsp+0xf0]
    1658:	lea    rdx,[rsp+0x100]
    1660:	mov    ecx,0xc
    1665:	mov    r8d,0x0
    166b:	lea    r9,[r12+0x314]
    1673:	movabs r11,0x5b73ef1a5650
    167d:	call   r11
    1680:	ldmxcsr DWORD PTR [r12-0x28]
    1686:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    168c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    1692:	mov    rbx,QWORD PTR [r12+0x108]
    169a:	mov    QWORD PTR [r12+0x378],0x2
    16a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    16af:	mov    rdx,rbx
    16b2:	shr    rdx,0x10
    16b6:	and    edx,0xc000
    16bc:	mov    rax,rbx
    16bf:	shr    rax,0x15
    16c3:	and    eax,0x100
    16c8:	xor    eax,0x100
    16cd:	or     edx,eax
    16cf:	mov    rax,rbx
    16d2:	shr    rax,0x1c
    16d6:	and    eax,0x1
    16d9:	or     edx,eax
    16db:	mov    QWORD PTR [rsp+0x10],rdx
    16e0:	add    rsp,0x8
    16e4:	ret
    16e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    16f0:	sub    rsp,0x8
    16f4:	mov    QWORD PTR [r12+0x378],0x3
    1700:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    1706:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    170c:	push   rdx
    170d:	push   rsi
    170e:	push   r10
    1710:	push   r11
    1712:	mov    rdx,QWORD PTR [rsp+0x30]
    1717:	mov    r10d,edx
    171a:	and    r10d,0xc000
    1721:	shl    r10d,0x10
    1725:	mov    r11d,edx
    1728:	and    r11d,0x100
    172f:	shl    r11d,0x15
    1733:	or     r10d,r11d
    1736:	and    edx,0x1
    1739:	shl    edx,0x1c
    173c:	or     r10d,edx
    173f:	btc    r10,0x1d
    1744:	mov    r11d,0xf0000000
    174a:	and    r11,r10
    174d:	movabs rsi,0xffffffff0fffffff
    1757:	and    rbx,rsi
    175a:	or     rbx,r11
    175d:	pop    r11
    175f:	pop    r10
    1761:	pop    rsi
    1762:	pop    rdx
    1763:	mov    QWORD PTR [r12+0x108],rbx
    176b:	stmxcsr DWORD PTR [r12-0x28]
    1771:	mov    r10d,DWORD PTR [r12-0x28]
    1776:	test   r10d,0x3f
    177d:	je     0x17a2
    1783:	mov    r11d,r10d
    1786:	shr    r10d,1
    1789:	and    r10d,0x1e
    178d:	and    r11d,0x1
    1791:	or     r10d,r11d
    1794:	or     DWORD PTR [r12+0x314],r10d
    179c:	and    DWORD PTR [r12-0x28],0xffffffc0
    17a2:	ldmxcsr DWORD PTR [r12-0x38]
    17a8:	lea    rdi,[rsp+0x110]
    17b0:	lea    rsi,[rsp+0xf0]
    17b8:	lea    rdx,[rsp+0x100]
    17c0:	mov    ecx,0xc
    17c5:	mov    r8d,0x0
    17cb:	lea    r9,[r12+0x314]
    17d3:	movabs r11,0x5b73ef1a5650
    17dd:	call   r11
    17e0:	ldmxcsr DWORD PTR [r12-0x28]
    17e6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    17ec:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    17f2:	mov    rbx,QWORD PTR [r12+0x108]
    17fa:	mov    QWORD PTR [r12+0x378],0x2
    1806:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    180f:	mov    rdx,rbx
    1812:	shr    rdx,0x10
    1816:	and    edx,0xc000
    181c:	mov    rax,rbx
    181f:	shr    rax,0x15
    1823:	and    eax,0x100
    1828:	xor    eax,0x100
    182d:	or     edx,eax
    182f:	mov    rax,rbx
    1832:	shr    rax,0x1c
    1836:	and    eax,0x1
    1839:	or     edx,eax
    183b:	mov    QWORD PTR [rsp+0x10],rdx
    1840:	add    rsp,0x8
    1844:	ret
    1845:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    1850:	sub    rsp,0x8
    1854:	mov    QWORD PTR [r12+0x378],0x3
    1860:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    1866:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    186c:	push   rdx
    186d:	push   rsi
    186e:	push   r10
    1870:	push   r11
    1872:	mov    rdx,QWORD PTR [rsp+0x30]
    1877:	mov    r10d,edx
    187a:	and    r10d,0xc000
    1881:	shl    r10d,0x10
    1885:	mov    r11d,edx
    1888:	and    r11d,0x100
    188f:	shl    r11d,0x15
    1893:	or     r10d,r11d
    1896:	and    edx,0x1
    1899:	shl    edx,0x1c
    189c:	or     r10d,edx
    189f:	btc    r10,0x1d
    18a4:	mov    r11d,0xf0000000
    18aa:	and    r11,r10
    18ad:	movabs rsi,0xffffffff0fffffff
    18b7:	and    rbx,rsi
    18ba:	or     rbx,r11
    18bd:	pop    r11
    18bf:	pop    r10
    18c1:	pop    rsi
    18c2:	pop    rdx
    18c3:	mov    QWORD PTR [r12+0x108],rbx
    18cb:	stmxcsr DWORD PTR [r12-0x28]
    18d1:	mov    r10d,DWORD PTR [r12-0x28]
    18d6:	test   r10d,0x3f
    18dd:	je     0x1902
    18e3:	mov    r11d,r10d
    18e6:	shr    r10d,1
    18e9:	and    r10d,0x1e
    18ed:	and    r11d,0x1
    18f1:	or     r10d,r11d
    18f4:	or     DWORD PTR [r12+0x314],r10d
    18fc:	and    DWORD PTR [r12-0x28],0xffffffc0
    1902:	ldmxcsr DWORD PTR [r12-0x38]
    1908:	lea    rdi,[rsp+0x110]
    1910:	lea    rsi,[rsp+0xf0]
    1918:	lea    rdx,[rsp+0x100]
    1920:	mov    ecx,0xc
    1925:	mov    r8d,0x0
    192b:	lea    r9,[r12+0x314]
    1933:	movabs r11,0x5b73ef1a5650
    193d:	call   r11
    1940:	ldmxcsr DWORD PTR [r12-0x28]
    1946:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    194c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    1952:	mov    rbx,QWORD PTR [r12+0x108]
    195a:	mov    QWORD PTR [r12+0x378],0x2
    1966:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    196f:	mov    rdx,rbx
    1972:	shr    rdx,0x10
    1976:	and    edx,0xc000
    197c:	mov    rax,rbx
    197f:	shr    rax,0x15
    1983:	and    eax,0x100
    1988:	xor    eax,0x100
    198d:	or     edx,eax
    198f:	mov    rax,rbx
    1992:	shr    rax,0x1c
    1996:	and    eax,0x1
    1999:	or     edx,eax
    199b:	mov    QWORD PTR [rsp+0x10],rdx
    19a0:	add    rsp,0x8
    19a4:	ret
    19a5:	mov    eax,0x410070
    19aa:	mov    QWORD PTR [r12+0x100],rax
    19b2:	push   rdx
    19b3:	push   rsi
    19b4:	push   r10
    19b6:	push   r11
    19b8:	mov    rdx,QWORD PTR [rsp+0x20]
    19bd:	mov    r10d,edx
    19c0:	and    r10d,0xc000
    19c7:	shl    r10d,0x10
    19cb:	mov    r11d,edx
    19ce:	and    r11d,0x100
    19d5:	shl    r11d,0x15
    19d9:	or     r10d,r11d
    19dc:	and    edx,0x1
    19df:	shl    edx,0x1c
    19e2:	or     r10d,edx
    19e5:	btc    r10,0x1d
    19ea:	mov    r11d,0xf0000000
    19f0:	and    r11,r10
    19f3:	movabs rsi,0xffffffff0fffffff
    19fd:	and    rbx,rsi
    1a00:	or     rbx,r11
    1a03:	pop    r11
    1a05:	pop    r10
    1a07:	pop    rsi
    1a08:	pop    rdx
    1a09:	mov    QWORD PTR [r12+0x108],rbx
    1a11:	add    rsp,0x150
    1a18:	mov    eax,0xc
    1a1d:	movabs r11,0x5b73ef33eca0
    1a27:	jmp    r11
    1a2a:	mov    eax,0x410114
    1a2f:	mov    QWORD PTR [r12+0x100],rax
    1a37:	push   rdx
    1a38:	push   rsi
    1a39:	push   r10
    1a3b:	push   r11
    1a3d:	mov    r11,rax
    1a40:	lahf
    1a41:	seto   al
    1a44:	mov    WORD PTR [rsp+0x20],ax
    1a49:	mov    rax,r11
    1a4c:	mov    rdx,QWORD PTR [rsp+0x20]
    1a51:	mov    r10d,edx
    1a54:	and    r10d,0xc000
    1a5b:	shl    r10d,0x10
    1a5f:	mov    r11d,edx
    1a62:	and    r11d,0x100
    1a69:	shl    r11d,0x15
    1a6d:	or     r10d,r11d
    1a70:	and    edx,0x1
    1a73:	shl    edx,0x1c
    1a76:	or     r10d,edx
    1a79:	btc    r10,0x1d
    1a7e:	mov    r11d,0xf0000000
    1a84:	and    r11,r10
    1a87:	movabs rsi,0xffffffff0fffffff
    1a91:	and    rbx,rsi
    1a94:	or     rbx,r11
    1a97:	pop    r11
    1a99:	pop    r10
    1a9b:	pop    rsi
    1a9c:	pop    rdx
    1a9d:	mov    QWORD PTR [r12+0x108],rbx
    1aa5:	add    rsp,0x150
    1aac:	mov    eax,0xc
    1ab1:	movabs r11,0x5b73ef33eca0
    1abb:	jmp    r11
    1abe:	mov    eax,0x410124
    1ac3:	mov    QWORD PTR [r12+0x100],rax
    1acb:	push   rdx
    1acc:	push   rsi
    1acd:	push   r10
    1acf:	push   r11
    1ad1:	mov    r11,rax
    1ad4:	lahf
    1ad5:	seto   al
    1ad8:	mov    WORD PTR [rsp+0x20],ax
    1add:	mov    rax,r11
    1ae0:	mov    rdx,QWORD PTR [rsp+0x20]
    1ae5:	mov    r10d,edx
    1ae8:	and    r10d,0xc000
    1aef:	shl    r10d,0x10
    1af3:	mov    r11d,edx
    1af6:	and    r11d,0x100
    1afd:	shl    r11d,0x15
    1b01:	or     r10d,r11d
    1b04:	and    edx,0x1
    1b07:	shl    edx,0x1c
    1b0a:	or     r10d,edx
    1b0d:	btc    r10,0x1d
    1b12:	mov    r11d,0xf0000000
    1b18:	and    r11,r10
    1b1b:	movabs rsi,0xffffffff0fffffff
    1b25:	and    rbx,rsi
    1b28:	or     rbx,r11
    1b2b:	pop    r11
    1b2d:	pop    r10
    1b2f:	pop    rsi
    1b30:	pop    rdx
    1b31:	mov    QWORD PTR [r12+0x108],rbx
    1b39:	add    rsp,0x150
    1b40:	mov    eax,0xc
    1b45:	movabs r11,0x5b73ef33eca0
    1b4f:	jmp    r11
    1b52:	mov    eax,0x410130
    1b57:	mov    QWORD PTR [r12+0x100],rax
    1b5f:	push   rdx
    1b60:	push   rsi
    1b61:	push   r10
    1b63:	push   r11
    1b65:	mov    r11,rax
    1b68:	lahf
    1b69:	seto   al
    1b6c:	mov    WORD PTR [rsp+0x20],ax
    1b71:	mov    rax,r11
    1b74:	mov    rdx,QWORD PTR [rsp+0x20]
    1b79:	mov    r10d,edx
    1b7c:	and    r10d,0xc000
    1b83:	shl    r10d,0x10
    1b87:	mov    r11d,edx
    1b8a:	and    r11d,0x100
    1b91:	shl    r11d,0x15
    1b95:	or     r10d,r11d
    1b98:	and    edx,0x1
    1b9b:	shl    edx,0x1c
    1b9e:	or     r10d,edx
    1ba1:	btc    r10,0x1d
    1ba6:	mov    r11d,0xf0000000
    1bac:	and    r11,r10
    1baf:	movabs rsi,0xffffffff0fffffff
    1bb9:	and    rbx,rsi
    1bbc:	or     rbx,r11
    1bbf:	pop    r11
    1bc1:	pop    r10
    1bc3:	pop    rsi
    1bc4:	pop    rdx
    1bc5:	mov    QWORD PTR [r12+0x108],rbx
    1bcd:	add    rsp,0x150
    1bd4:	mov    eax,0xc
    1bd9:	movabs r11,0x5b73ef33eca0
    1be3:	jmp    r11
    1be6:	mov    eax,0x410150
    1beb:	mov    QWORD PTR [r12+0x100],rax
    1bf3:	push   rdx
    1bf4:	push   rsi
    1bf5:	push   r10
    1bf7:	push   r11
    1bf9:	mov    r11,rax
    1bfc:	lahf
    1bfd:	seto   al
    1c00:	mov    WORD PTR [rsp+0x20],ax
    1c05:	mov    rax,r11
    1c08:	mov    rdx,QWORD PTR [rsp+0x20]
    1c0d:	mov    r10d,edx
    1c10:	and    r10d,0xc000
    1c17:	shl    r10d,0x10
    1c1b:	mov    r11d,edx
    1c1e:	and    r11d,0x100
    1c25:	shl    r11d,0x15
    1c29:	or     r10d,r11d
    1c2c:	and    edx,0x1
    1c2f:	shl    edx,0x1c
    1c32:	or     r10d,edx
    1c35:	btc    r10,0x1d
    1c3a:	mov    r11d,0xf0000000
    1c40:	and    r11,r10
    1c43:	movabs rsi,0xffffffff0fffffff
    1c4d:	and    rbx,rsi
    1c50:	or     rbx,r11
    1c53:	pop    r11
    1c55:	pop    r10
    1c57:	pop    rsi
    1c58:	pop    rdx
    1c59:	mov    QWORD PTR [r12+0x108],rbx
    1c61:	add    rsp,0x150
    1c68:	mov    eax,0xc
    1c6d:	movabs r11,0x5b73ef33eca0
    1c77:	jmp    r11
    1c7a:	mov    eax,0x410158
    1c7f:	mov    QWORD PTR [r12+0x100],rax
    1c87:	push   rdx
    1c88:	push   rsi
    1c89:	push   r10
    1c8b:	push   r11
    1c8d:	mov    rdx,QWORD PTR [rsp+0x20]
    1c92:	mov    r10d,edx
    1c95:	and    r10d,0xc000
    1c9c:	shl    r10d,0x10
    1ca0:	mov    r11d,edx
    1ca3:	and    r11d,0x100
    1caa:	shl    r11d,0x15
    1cae:	or     r10d,r11d
    1cb1:	and    edx,0x1
    1cb4:	shl    edx,0x1c
    1cb7:	or     r10d,edx
    1cba:	btc    r10,0x1d
    1cbf:	mov    r11d,0xf0000000
    1cc5:	and    r11,r10
    1cc8:	movabs rsi,0xffffffff0fffffff
    1cd2:	and    rbx,rsi
    1cd5:	or     rbx,r11
    1cd8:	pop    r11
    1cda:	pop    r10
    1cdc:	pop    rsi
    1cdd:	pop    rdx
    1cde:	mov    QWORD PTR [r12+0x108],rbx
    1ce6:	add    rsp,0x150
    1ced:	mov    eax,0xc
    1cf2:	movabs r11,0x5b73ef33eca0
    1cfc:	jmp    r11
    1cff:	nop
    1d00:	sub    rsp,0x150
    1d07:	mov    r11,QWORD PTR [r12+0x398]
    1d0f:	mov    QWORD PTR [rsp],r11
    1d13:	cmp    DWORD PTR [r12+0x310],0x0
    1d1c:	je     0x1da7
    1d22:	push   rdx
    1d23:	push   rsi
    1d24:	push   r10
    1d26:	push   r11
    1d28:	mov    rdx,QWORD PTR [rsp+0x20]
    1d2d:	mov    r10d,edx
    1d30:	and    r10d,0xc000
    1d37:	shl    r10d,0x10
    1d3b:	mov    r11d,edx
    1d3e:	and    r11d,0x100
    1d45:	shl    r11d,0x15
    1d49:	or     r10d,r11d
    1d4c:	and    edx,0x1
    1d4f:	shl    edx,0x1c
    1d52:	or     r10d,edx
    1d55:	btc    r10,0x1d
    1d5a:	mov    r11d,0xf0000000
    1d60:	and    r11,r10
    1d63:	movabs rsi,0xffffffff0fffffff
    1d6d:	and    rbx,rsi
    1d70:	or     rbx,r11
    1d73:	pop    r11
    1d75:	pop    r10
    1d77:	pop    rsi
    1d78:	pop    rdx
    1d79:	mov    QWORD PTR [r12+0x108],rbx
    1d81:	mov    eax,0x41004c
    1d86:	mov    QWORD PTR [r12+0x100],rax
    1d8e:	add    rsp,0x150
    1d95:	mov    eax,0x3
    1d9a:	movabs r11,0x5b73ef33eca0
    1da4:	jmp    r11
    1da7:	jmp    0xe6
    1dac:	nop    DWORD PTR [rax+0x0]
    1db0:	sub    rsp,0x150
    1db7:	mov    r11,QWORD PTR [r12+0x398]
    1dbf:	mov    QWORD PTR [rsp],r11
    1dc3:	cmp    DWORD PTR [r12+0x310],0x0
    1dcc:	je     0x1e57
    1dd2:	push   rdx
    1dd3:	push   rsi
    1dd4:	push   r10
    1dd6:	push   r11
    1dd8:	mov    rdx,QWORD PTR [rsp+0x20]
    1ddd:	mov    r10d,edx
    1de0:	and    r10d,0xc000
    1de7:	shl    r10d,0x10
    1deb:	mov    r11d,edx
    1dee:	and    r11d,0x100
    1df5:	shl    r11d,0x15
    1df9:	or     r10d,r11d
    1dfc:	and    edx,0x1
    1dff:	shl    edx,0x1c
    1e02:	or     r10d,edx
    1e05:	btc    r10,0x1d
    1e0a:	mov    r11d,0xf0000000
    1e10:	and    r11,r10
    1e13:	movabs rsi,0xffffffff0fffffff
    1e1d:	and    rbx,rsi
    1e20:	or     rbx,r11
    1e23:	pop    r11
    1e25:	pop    r10
    1e27:	pop    rsi
    1e28:	pop    rdx
    1e29:	mov    QWORD PTR [r12+0x108],rbx
    1e31:	mov    eax,0x410074
    1e36:	mov    QWORD PTR [r12+0x100],rax
    1e3e:	add    rsp,0x150
    1e45:	mov    eax,0x3
    1e4a:	movabs r11,0x5b73ef33eca0
    1e54:	jmp    r11
    1e57:	jmp    0x30b
    1e5c:	nop    DWORD PTR [rax+0x0]
    1e60:	sub    rsp,0x150
    1e67:	mov    r11,QWORD PTR [r12+0x398]
    1e6f:	mov    QWORD PTR [rsp],r11
    1e73:	cmp    DWORD PTR [r12+0x310],0x0
    1e7c:	je     0x1f07
    1e82:	push   rdx
    1e83:	push   rsi
    1e84:	push   r10
    1e86:	push   r11
    1e88:	mov    rdx,QWORD PTR [rsp+0x20]
    1e8d:	mov    r10d,edx
    1e90:	and    r10d,0xc000
    1e97:	shl    r10d,0x10
    1e9b:	mov    r11d,edx
    1e9e:	and    r11d,0x100
    1ea5:	shl    r11d,0x15
    1ea9:	or     r10d,r11d
    1eac:	and    edx,0x1
    1eaf:	shl    edx,0x1c
    1eb2:	or     r10d,edx
    1eb5:	btc    r10,0x1d
    1eba:	mov    r11d,0xf0000000
    1ec0:	and    r11,r10
    1ec3:	movabs rsi,0xffffffff0fffffff
    1ecd:	and    rbx,rsi
    1ed0:	or     rbx,r11
    1ed3:	pop    r11
    1ed5:	pop    r10
    1ed7:	pop    rsi
    1ed8:	pop    rdx
    1ed9:	mov    QWORD PTR [r12+0x108],rbx
    1ee1:	mov    eax,0x410084
    1ee6:	mov    QWORD PTR [r12+0x100],rax
    1eee:	add    rsp,0x150
    1ef5:	mov    eax,0x3
    1efa:	movabs r11,0x5b73ef33eca0
    1f04:	jmp    r11
    1f07:	mov    r11,rax
    1f0a:	movzx  eax,WORD PTR [rsp]
    1f0e:	add    al,0x7f
    1f10:	sahf
    1f11:	mov    rax,r11
    1f14:	jmp    0x356
    1f19:	nop    DWORD PTR [rax+0x0]
    1f20:	sub    rsp,0x150
    1f27:	mov    r11,QWORD PTR [r12+0x398]
    1f2f:	mov    QWORD PTR [rsp],r11
    1f33:	cmp    DWORD PTR [r12+0x310],0x0
    1f3c:	je     0x1fc7
    1f42:	push   rdx
    1f43:	push   rsi
    1f44:	push   r10
    1f46:	push   r11
    1f48:	mov    rdx,QWORD PTR [rsp+0x20]
    1f4d:	mov    r10d,edx
    1f50:	and    r10d,0xc000
    1f57:	shl    r10d,0x10
    1f5b:	mov    r11d,edx
    1f5e:	and    r11d,0x100
    1f65:	shl    r11d,0x15
    1f69:	or     r10d,r11d
    1f6c:	and    edx,0x1
    1f6f:	shl    edx,0x1c
    1f72:	or     r10d,edx
    1f75:	btc    r10,0x1d
    1f7a:	mov    r11d,0xf0000000
    1f80:	and    r11,r10
    1f83:	movabs rsi,0xffffffff0fffffff
    1f8d:	and    rbx,rsi
    1f90:	or     rbx,r11
    1f93:	pop    r11
    1f95:	pop    r10
    1f97:	pop    rsi
    1f98:	pop    rdx
    1f99:	mov    QWORD PTR [r12+0x108],rbx
    1fa1:	mov    eax,0x41008c
    1fa6:	mov    QWORD PTR [r12+0x100],rax
    1fae:	add    rsp,0x150
    1fb5:	mov    eax,0x3
    1fba:	movabs r11,0x5b73ef33eca0
    1fc4:	jmp    r11
    1fc7:	mov    r11,rax
    1fca:	movzx  eax,WORD PTR [rsp]
    1fce:	add    al,0x7f
    1fd0:	sahf
    1fd1:	mov    rax,r11
    1fd4:	jmp    0x394
    1fd9:	nop    DWORD PTR [rax+0x0]
    1fe0:	sub    rsp,0x150
    1fe7:	mov    r11,QWORD PTR [r12+0x398]
    1fef:	mov    QWORD PTR [rsp],r11
    1ff3:	cmp    DWORD PTR [r12+0x310],0x0
    1ffc:	je     0x2087
    2002:	push   rdx
    2003:	push   rsi
    2004:	push   r10
    2006:	push   r11
    2008:	mov    rdx,QWORD PTR [rsp+0x20]
    200d:	mov    r10d,edx
    2010:	and    r10d,0xc000
    2017:	shl    r10d,0x10
    201b:	mov    r11d,edx
    201e:	and    r11d,0x100
    2025:	shl    r11d,0x15
    2029:	or     r10d,r11d
    202c:	and    edx,0x1
    202f:	shl    edx,0x1c
    2032:	or     r10d,edx
    2035:	btc    r10,0x1d
    203a:	mov    r11d,0xf0000000
    2040:	and    r11,r10
    2043:	movabs rsi,0xffffffff0fffffff
    204d:	and    rbx,rsi
    2050:	or     rbx,r11
    2053:	pop    r11
    2055:	pop    r10
    2057:	pop    rsi
    2058:	pop    rdx
    2059:	mov    QWORD PTR [r12+0x108],rbx
    2061:	mov    eax,0x4100a4
    2066:	mov    QWORD PTR [r12+0x100],rax
    206e:	add    rsp,0x150
    2075:	mov    eax,0x3
    207a:	movabs r11,0x5b73ef33eca0
    2084:	jmp    r11
    2087:	mov    r11,rax
    208a:	movzx  eax,WORD PTR [rsp]
    208e:	add    al,0x7f
    2090:	sahf
    2091:	mov    rax,r11
    2094:	jmp    0x4cf
    2099:	nop    DWORD PTR [rax+0x0]
    20a0:	sub    rsp,0x150
    20a7:	mov    r11,QWORD PTR [r12+0x398]
    20af:	mov    QWORD PTR [rsp],r11
    20b3:	cmp    DWORD PTR [r12+0x310],0x0
    20bc:	je     0x2147
    20c2:	push   rdx
    20c3:	push   rsi
    20c4:	push   r10
    20c6:	push   r11
    20c8:	mov    rdx,QWORD PTR [rsp+0x20]
    20cd:	mov    r10d,edx
    20d0:	and    r10d,0xc000
    20d7:	shl    r10d,0x10
    20db:	mov    r11d,edx
    20de:	and    r11d,0x100
    20e5:	shl    r11d,0x15
    20e9:	or     r10d,r11d
    20ec:	and    edx,0x1
    20ef:	shl    edx,0x1c
    20f2:	or     r10d,edx
    20f5:	btc    r10,0x1d
    20fa:	mov    r11d,0xf0000000
    2100:	and    r11,r10
    2103:	movabs rsi,0xffffffff0fffffff
    210d:	and    rbx,rsi
    2110:	or     rbx,r11
    2113:	pop    r11
    2115:	pop    r10
    2117:	pop    rsi
    2118:	pop    rdx
    2119:	mov    QWORD PTR [r12+0x108],rbx
    2121:	mov    eax,0x410118
    2126:	mov    QWORD PTR [r12+0x100],rax
    212e:	add    rsp,0x150
    2135:	mov    eax,0x3
    213a:	movabs r11,0x5b73ef33eca0
    2144:	jmp    r11
    2147:	jmp    0xcc0
    214c:	nop    DWORD PTR [rax+0x0]
    2150:	sub    rsp,0x150
    2157:	mov    r11,QWORD PTR [r12+0x398]
    215f:	mov    QWORD PTR [rsp],r11
    2163:	cmp    DWORD PTR [r12+0x310],0x0
    216c:	je     0x21f7
    2172:	push   rdx
    2173:	push   rsi
    2174:	push   r10
    2176:	push   r11
    2178:	mov    rdx,QWORD PTR [rsp+0x20]
    217d:	mov    r10d,edx
    2180:	and    r10d,0xc000
    2187:	shl    r10d,0x10
    218b:	mov    r11d,edx
    218e:	and    r11d,0x100
    2195:	shl    r11d,0x15
    2199:	or     r10d,r11d
    219c:	and    edx,0x1
    219f:	shl    edx,0x1c
    21a2:	or     r10d,edx
    21a5:	btc    r10,0x1d
    21aa:	mov    r11d,0xf0000000
    21b0:	and    r11,r10
    21b3:	movabs rsi,0xffffffff0fffffff
    21bd:	and    rbx,rsi
    21c0:	or     rbx,r11
    21c3:	pop    r11
    21c5:	pop    r10
    21c7:	pop    rsi
    21c8:	pop    rdx
    21c9:	mov    QWORD PTR [r12+0x108],rbx
    21d1:	mov    eax,0x410128
    21d6:	mov    QWORD PTR [r12+0x100],rax
    21de:	add    rsp,0x150
    21e5:	mov    eax,0x3
    21ea:	movabs r11,0x5b73ef33eca0
    21f4:	jmp    r11
    21f7:	jmp    0xcfa
    21fc:	nop    DWORD PTR [rax+0x0]
    2200:	sub    rsp,0x150
    2207:	mov    r11,QWORD PTR [r12+0x398]
    220f:	mov    QWORD PTR [rsp],r11
    2213:	cmp    DWORD PTR [r12+0x310],0x0
    221c:	je     0x22a7
    2222:	push   rdx
    2223:	push   rsi
    2224:	push   r10
    2226:	push   r11
    2228:	mov    rdx,QWORD PTR [rsp+0x20]
    222d:	mov    r10d,edx
    2230:	and    r10d,0xc000
    2237:	shl    r10d,0x10
    223b:	mov    r11d,edx
    223e:	and    r11d,0x100
    2245:	shl    r11d,0x15
    2249:	or     r10d,r11d
    224c:	and    edx,0x1
    224f:	shl    edx,0x1c
    2252:	or     r10d,edx
    2255:	btc    r10,0x1d
    225a:	mov    r11d,0xf0000000
    2260:	and    r11,r10
    2263:	movabs rsi,0xffffffff0fffffff
    226d:	and    rbx,rsi
    2270:	or     rbx,r11
    2273:	pop    r11
    2275:	pop    r10
    2277:	pop    rsi
    2278:	pop    rdx
    2279:	mov    QWORD PTR [r12+0x108],rbx
    2281:	mov    eax,0x410134
    2286:	mov    QWORD PTR [r12+0x100],rax
    228e:	add    rsp,0x150
    2295:	mov    eax,0x3
    229a:	movabs r11,0x5b73ef33eca0
    22a4:	jmp    r11
    22a7:	jmp    0xd37
    22ac:	nop    DWORD PTR [rax+0x0]
    22b0:	sub    rsp,0x150
    22b7:	mov    r11,QWORD PTR [r12+0x398]
    22bf:	mov    QWORD PTR [rsp],r11
    22c3:	cmp    DWORD PTR [r12+0x310],0x0
    22cc:	je     0x2357
    22d2:	push   rdx
    22d3:	push   rsi
    22d4:	push   r10
    22d6:	push   r11
    22d8:	mov    rdx,QWORD PTR [rsp+0x20]
    22dd:	mov    r10d,edx
    22e0:	and    r10d,0xc000
    22e7:	shl    r10d,0x10
    22eb:	mov    r11d,edx
    22ee:	and    r11d,0x100
    22f5:	shl    r11d,0x15
    22f9:	or     r10d,r11d
    22fc:	and    edx,0x1
    22ff:	shl    edx,0x1c
    2302:	or     r10d,edx
    2305:	btc    r10,0x1d
    230a:	mov    r11d,0xf0000000
    2310:	and    r11,r10
    2313:	movabs rsi,0xffffffff0fffffff
    231d:	and    rbx,rsi
    2320:	or     rbx,r11
    2323:	pop    r11
    2325:	pop    r10
    2327:	pop    rsi
    2328:	pop    rdx
    2329:	mov    QWORD PTR [r12+0x108],rbx
    2331:	mov    eax,0x410140
    2336:	mov    QWORD PTR [r12+0x100],rax
    233e:	add    rsp,0x150
    2345:	mov    eax,0x3
    234a:	movabs r11,0x5b73ef33eca0
    2354:	jmp    r11
    2357:	jmp    0xd72
    235c:	nop    DWORD PTR [rax+0x0]
    2360:	sub    rsp,0x150
    2367:	mov    r11,QWORD PTR [r12+0x398]
    236f:	mov    QWORD PTR [rsp],r11
    2373:	cmp    DWORD PTR [r12+0x310],0x0
    237c:	je     0x2407
    2382:	push   rdx
    2383:	push   rsi
    2384:	push   r10
    2386:	push   r11
    2388:	mov    rdx,QWORD PTR [rsp+0x20]
    238d:	mov    r10d,edx
    2390:	and    r10d,0xc000
    2397:	shl    r10d,0x10
    239b:	mov    r11d,edx
    239e:	and    r11d,0x100
    23a5:	shl    r11d,0x15
    23a9:	or     r10d,r11d
    23ac:	and    edx,0x1
    23af:	shl    edx,0x1c
    23b2:	or     r10d,edx
    23b5:	btc    r10,0x1d
    23ba:	mov    r11d,0xf0000000
    23c0:	and    r11,r10
    23c3:	movabs rsi,0xffffffff0fffffff
    23cd:	and    rbx,rsi
    23d0:	or     rbx,r11
    23d3:	pop    r11
    23d5:	pop    r10
    23d7:	pop    rsi
    23d8:	pop    rdx
    23d9:	mov    QWORD PTR [r12+0x108],rbx
    23e1:	mov    eax,0x410154
    23e6:	mov    QWORD PTR [r12+0x100],rax
    23ee:	add    rsp,0x150
    23f5:	mov    eax,0x3
    23fa:	movabs r11,0x5b73ef33eca0
    2404:	jmp    r11
    2407:	jmp    0xe57
    240c:	nop    DWORD PTR [rax+0x0]
    2410:	(bad)
    2411:	(bad)
    2412:	(bad)
    2413:	(bad)
    2414:	(bad)
    2415:	(bad)
    2416:	(bad)
    2417:	jg     0x2418
    2419:	(bad)
    241a:	(bad)
    241b:	(bad)
    241c:	(bad)
    241d:	(bad)
    241e:	(bad)
    241f:	jg     0x2421
    2421:	add    BYTE PTR [rax],al
    2423:	add    BYTE PTR [rax],al
    2425:	add    BYTE PTR [rax],dl
    2427:	add    BYTE PTR [rax],al
    2429:	add    BYTE PTR [rax],al
    242b:	add    BYTE PTR [rax],al
    242d:	add    BYTE PTR [rax],dl
	...
