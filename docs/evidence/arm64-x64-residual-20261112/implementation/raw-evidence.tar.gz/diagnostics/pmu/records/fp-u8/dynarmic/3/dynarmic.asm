00007f9bd71ce69b  nop [rax+rax*1], eax
00007f9bd71ce6a0  mov qword ptr [r15+0x20], 0x420080
00007f9bd71ce6a8  mov qword ptr [r15], 0x00
00007f9bd71ce6af  vmovaps xmm1, [0x00007F9BD6DFE010]
00007f9bd71ce6b7  movq xmm1, xmm1
00007f9bd71ce6bb  vmovaps xmm15, [0x00007F9BD6DFE020]
00007f9bd71ce6c3  movq xmm15, xmm15
00007f9bd71ce6c8  movaps [r15+0x120], xmm15
00007f9bd71ce6d0  movq rax, xmm1
00007f9bd71ce6d5  movq r14, xmm15
00007f9bd71ce6da  vmovq xmm1, rax
00007f9bd71ce6df  vmovq xmm14, r14
00007f9bd71ce6e4  movaps xmm13, xmm1
00007f9bd71ce6e8  addsd xmm13, xmm14
00007f9bd71ce6ed  ucomisd xmm13, xmm13
00007f9bd71ce6f2  jp 0x00007F9BD71CE8CC
00007f9bd71ce6f8  movq xmm13, xmm13
00007f9bd71ce6fd  movq rax, xmm13
00007f9bd71ce702  movq r14, xmm15
00007f9bd71ce707  vmovq xmm1, rax
00007f9bd71ce70c  vmovq xmm14, r14
00007f9bd71ce711  movaps xmm13, xmm1
00007f9bd71ce715  addsd xmm13, xmm14
00007f9bd71ce71a  ucomisd xmm13, xmm13
00007f9bd71ce71f  jp 0x00007F9BD71CE914
00007f9bd71ce725  movq xmm13, xmm13
00007f9bd71ce72a  movq rax, xmm13
00007f9bd71ce72f  movq r14, xmm15
00007f9bd71ce734  vmovq xmm1, rax
00007f9bd71ce739  vmovq xmm14, r14
00007f9bd71ce73e  movaps xmm13, xmm1
00007f9bd71ce742  addsd xmm13, xmm14
00007f9bd71ce747  ucomisd xmm13, xmm13
00007f9bd71ce74c  jp 0x00007F9BD71CE95C
00007f9bd71ce752  movq xmm13, xmm13
00007f9bd71ce757  movq rax, xmm13
00007f9bd71ce75c  movq r14, xmm15
00007f9bd71ce761  vmovq xmm1, rax
00007f9bd71ce766  vmovq xmm14, r14
00007f9bd71ce76b  movaps xmm13, xmm1
00007f9bd71ce76f  addsd xmm13, xmm14
00007f9bd71ce774  ucomisd xmm13, xmm13
00007f9bd71ce779  jp 0x00007F9BD71CE9A4
00007f9bd71ce77f  movq xmm13, xmm13
00007f9bd71ce784  movq rax, xmm13
00007f9bd71ce789  movq r14, xmm15
00007f9bd71ce78e  vmovq xmm1, rax
00007f9bd71ce793  vmovq xmm14, r14
00007f9bd71ce798  movaps xmm13, xmm1
00007f9bd71ce79c  addsd xmm13, xmm14
00007f9bd71ce7a1  ucomisd xmm13, xmm13
00007f9bd71ce7a6  jp 0x00007F9BD71CE9EC
00007f9bd71ce7ac  movq xmm13, xmm13
00007f9bd71ce7b1  movq rax, xmm13
00007f9bd71ce7b6  movq r14, xmm15
00007f9bd71ce7bb  vmovq xmm1, rax
00007f9bd71ce7c0  vmovq xmm14, r14
00007f9bd71ce7c5  movaps xmm13, xmm1
00007f9bd71ce7c9  addsd xmm13, xmm14
00007f9bd71ce7ce  ucomisd xmm13, xmm13
00007f9bd71ce7d3  jp 0x00007F9BD71CEA34
00007f9bd71ce7d9  movq xmm13, xmm13
00007f9bd71ce7de  movq rax, xmm13
00007f9bd71ce7e3  movq r14, xmm15
00007f9bd71ce7e8  vmovq xmm1, rax
00007f9bd71ce7ed  vmovq xmm14, r14
00007f9bd71ce7f2  movaps xmm13, xmm1
00007f9bd71ce7f6  addsd xmm13, xmm14
00007f9bd71ce7fb  ucomisd xmm13, xmm13
00007f9bd71ce800  jp 0x00007F9BD71CEA7C
00007f9bd71ce806  movq xmm13, xmm13
00007f9bd71ce80b  movq rax, xmm13
00007f9bd71ce810  movq r14, xmm15
00007f9bd71ce815  vmovq xmm1, rax
00007f9bd71ce81a  vmovq xmm15, r14
00007f9bd71ce81f  movaps xmm14, xmm1
00007f9bd71ce823  addsd xmm14, xmm15
00007f9bd71ce828  ucomisd xmm14, xmm14
00007f9bd71ce82d  jp 0x00007F9BD71CEAC4
00007f9bd71ce833  movq xmm14, xmm14
00007f9bd71ce838  movaps [r15+0x110], xmm14
00007f9bd71ce840  xor eax, eax
00007f9bd71ce842  mov r14d, 0x1E848
00007f9bd71ce848  mov r12d, 0x01
00007f9bd71ce84e  sub r14, r12
00007f9bd71ce851  cmc
00007f9bd71ce852  lahf
00007f9bd71ce853  seto al
00007f9bd71ce856  mov [r15+0x108], eax
00007f9bd71ce85d  mov [r15+0x08], r14
00007f9bd71ce861  mov eax, [r15+0x108]
00007f9bd71ce868  sahf
00007f9bd71ce869  jnz 0x00007F9BD71CE89B
00007f9bd71ce86b  cmp dword ptr [r15+0x318], 0x00
00007f9bd71ce873  jz 0x00007F9BD71CEF70
00007f9bd71ce879  nop [rax+rax*1], ax
00007f9bd71ce882  nop [rax+rax*1], eax
00007f9bd71ce88a  mov eax, 0x41006C
00007f9bd71ce88f  mov [r15+0x100], rax
00007f9bd71ce896  jmp 0x00007F9BD6FFE110
00007f9bd71ce89b  cmp dword ptr [r15+0x318], 0x00
00007f9bd71ce8a3  jz 0x00007F9BD71CEB10
00007f9bd71ce8a9  nop [rax+rax*1], ax
00007f9bd71ce8b2  nop [rax+rax*1], eax
00007f9bd71ce8ba  mov eax, 0x410044
00007f9bd71ce8bf  mov [r15+0x100], rax
00007f9bd71ce8c6  jmp 0x00007F9BD6FFE110
00007f9bd71ce8cb  int3
00007f9bd71ce8cc  ucomisd xmm1, xmm14
00007f9bd71ce8d1  jp 0x00007F9BD71CE8E0
00007f9bd71ce8d3  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71ce8db  jmp 0x00007F9BD71CE6F8
00007f9bd71ce8e0  vxorps xmm0, xmm1, xmm14
00007f9bd71ce8e5  pextrw eax, xmm0, 0x03
00007f9bd71ce8ea  and eax, 0x7FF8
00007f9bd71ce8ef  cmp eax, 0x08
00007f9bd71ce8f2  jnz 0x00007F9BD71CE6F8
00007f9bd71ce8f8  movq rax, xmm14
00007f9bd71ce8fd  shl rax, 0x0D
00007f9bd71ce901  jbe 0x00007F9BD71CE6F8
00007f9bd71ce907  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71ce90f  jmp 0x00007F9BD71CE6F8
00007f9bd71ce914  ucomisd xmm1, xmm14
00007f9bd71ce919  jp 0x00007F9BD71CE928
00007f9bd71ce91b  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71ce923  jmp 0x00007F9BD71CE725
00007f9bd71ce928  vxorps xmm0, xmm1, xmm14
00007f9bd71ce92d  pextrw eax, xmm0, 0x03
00007f9bd71ce932  and eax, 0x7FF8
00007f9bd71ce937  cmp eax, 0x08
00007f9bd71ce93a  jnz 0x00007F9BD71CE725
00007f9bd71ce940  movq rax, xmm14
00007f9bd71ce945  shl rax, 0x0D
00007f9bd71ce949  jbe 0x00007F9BD71CE725
00007f9bd71ce94f  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71ce957  jmp 0x00007F9BD71CE725
00007f9bd71ce95c  ucomisd xmm1, xmm14
00007f9bd71ce961  jp 0x00007F9BD71CE970
00007f9bd71ce963  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71ce96b  jmp 0x00007F9BD71CE752
00007f9bd71ce970  vxorps xmm0, xmm1, xmm14
00007f9bd71ce975  pextrw eax, xmm0, 0x03
00007f9bd71ce97a  and eax, 0x7FF8
00007f9bd71ce97f  cmp eax, 0x08
00007f9bd71ce982  jnz 0x00007F9BD71CE752
00007f9bd71ce988  movq rax, xmm14
00007f9bd71ce98d  shl rax, 0x0D
00007f9bd71ce991  jbe 0x00007F9BD71CE752
00007f9bd71ce997  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71ce99f  jmp 0x00007F9BD71CE752
00007f9bd71ce9a4  ucomisd xmm1, xmm14
00007f9bd71ce9a9  jp 0x00007F9BD71CE9B8
00007f9bd71ce9ab  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71ce9b3  jmp 0x00007F9BD71CE77F
00007f9bd71ce9b8  vxorps xmm0, xmm1, xmm14
00007f9bd71ce9bd  pextrw eax, xmm0, 0x03
00007f9bd71ce9c2  and eax, 0x7FF8
00007f9bd71ce9c7  cmp eax, 0x08
00007f9bd71ce9ca  jnz 0x00007F9BD71CE77F
00007f9bd71ce9d0  movq rax, xmm14
00007f9bd71ce9d5  shl rax, 0x0D
00007f9bd71ce9d9  jbe 0x00007F9BD71CE77F
00007f9bd71ce9df  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71ce9e7  jmp 0x00007F9BD71CE77F
00007f9bd71ce9ec  ucomisd xmm1, xmm14
00007f9bd71ce9f1  jp 0x00007F9BD71CEA00
00007f9bd71ce9f3  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71ce9fb  jmp 0x00007F9BD71CE7AC
00007f9bd71cea00  vxorps xmm0, xmm1, xmm14
00007f9bd71cea05  pextrw eax, xmm0, 0x03
00007f9bd71cea0a  and eax, 0x7FF8
00007f9bd71cea0f  cmp eax, 0x08
00007f9bd71cea12  jnz 0x00007F9BD71CE7AC
00007f9bd71cea18  movq rax, xmm14
00007f9bd71cea1d  shl rax, 0x0D
00007f9bd71cea21  jbe 0x00007F9BD71CE7AC
00007f9bd71cea27  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71cea2f  jmp 0x00007F9BD71CE7AC
00007f9bd71cea34  ucomisd xmm1, xmm14
00007f9bd71cea39  jp 0x00007F9BD71CEA48
00007f9bd71cea3b  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71cea43  jmp 0x00007F9BD71CE7D9
00007f9bd71cea48  vxorps xmm0, xmm1, xmm14
00007f9bd71cea4d  pextrw eax, xmm0, 0x03
00007f9bd71cea52  and eax, 0x7FF8
00007f9bd71cea57  cmp eax, 0x08
00007f9bd71cea5a  jnz 0x00007F9BD71CE7D9
00007f9bd71cea60  movq rax, xmm14
00007f9bd71cea65  shl rax, 0x0D
00007f9bd71cea69  jbe 0x00007F9BD71CE7D9
00007f9bd71cea6f  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71cea77  jmp 0x00007F9BD71CE7D9
00007f9bd71cea7c  ucomisd xmm1, xmm14
00007f9bd71cea81  jp 0x00007F9BD71CEA90
00007f9bd71cea83  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71cea8b  jmp 0x00007F9BD71CE806
00007f9bd71cea90  vxorps xmm0, xmm1, xmm14
00007f9bd71cea95  pextrw eax, xmm0, 0x03
00007f9bd71cea9a  and eax, 0x7FF8
00007f9bd71cea9f  cmp eax, 0x08
00007f9bd71ceaa2  jnz 0x00007F9BD71CE806
00007f9bd71ceaa8  movq rax, xmm14
00007f9bd71ceaad  shl rax, 0x0D
00007f9bd71ceab1  jbe 0x00007F9BD71CE806
00007f9bd71ceab7  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71ceabf  jmp 0x00007F9BD71CE806
00007f9bd71ceac4  ucomisd xmm1, xmm15
00007f9bd71ceac9  jp 0x00007F9BD71CEAD8
00007f9bd71ceacb  movaps xmm14, [0x00007F9BD6DFE030]
00007f9bd71cead3  jmp 0x00007F9BD71CE833
00007f9bd71cead8  vxorps xmm0, xmm1, xmm15
00007f9bd71ceadd  pextrw eax, xmm0, 0x03
00007f9bd71ceae2  and eax, 0x7FF8
00007f9bd71ceae7  cmp eax, 0x08
00007f9bd71ceaea  jnz 0x00007F9BD71CE833
00007f9bd71ceaf0  movq rax, xmm15
00007f9bd71ceaf5  shl rax, 0x0D
00007f9bd71ceaf9  jbe 0x00007F9BD71CE833
00007f9bd71ceaff  vorps xmm14, xmm15, [0x00007F9BD6DFE040]
00007f9bd71ceb07  jmp 0x00007F9BD71CE833
00007f9bd71ceb0c  int3
00007f9bd71ceb0d  nop [rax], eax
00007f9bd71ceb10  movaps xmm1, [r15+0x110]
00007f9bd71ceb18  movq rax, xmm1
00007f9bd71ceb1d  movaps xmm1, [r15+0x120]
00007f9bd71ceb25  movq r14, xmm1
00007f9bd71ceb2a  vmovq xmm15, rax
00007f9bd71ceb2f  vmovq xmm14, r14
00007f9bd71ceb34  movaps xmm13, xmm15
00007f9bd71ceb38  addsd xmm13, xmm14
00007f9bd71ceb3d  ucomisd xmm13, xmm13
00007f9bd71ceb42  jp 0x00007F9BD71CED24
00007f9bd71ceb48  movq xmm13, xmm13
00007f9bd71ceb4d  movq rax, xmm13
00007f9bd71ceb52  movq r14, xmm1
00007f9bd71ceb57  vmovq xmm15, rax
00007f9bd71ceb5c  vmovq xmm14, r14
00007f9bd71ceb61  movaps xmm13, xmm15
00007f9bd71ceb65  addsd xmm13, xmm14
00007f9bd71ceb6a  ucomisd xmm13, xmm13
00007f9bd71ceb6f  jp 0x00007F9BD71CED6C
00007f9bd71ceb75  movq xmm13, xmm13
00007f9bd71ceb7a  movq rax, xmm13
00007f9bd71ceb7f  movq r14, xmm1
00007f9bd71ceb84  vmovq xmm15, rax
00007f9bd71ceb89  vmovq xmm14, r14
00007f9bd71ceb8e  movaps xmm13, xmm15
00007f9bd71ceb92  addsd xmm13, xmm14
00007f9bd71ceb97  ucomisd xmm13, xmm13
00007f9bd71ceb9c  jp 0x00007F9BD71CEDB4
00007f9bd71ceba2  movq xmm13, xmm13
00007f9bd71ceba7  movq rax, xmm13
00007f9bd71cebac  movq r14, xmm1
00007f9bd71cebb1  vmovq xmm15, rax
00007f9bd71cebb6  vmovq xmm14, r14
00007f9bd71cebbb  movaps xmm13, xmm15
00007f9bd71cebbf  addsd xmm13, xmm14
00007f9bd71cebc4  ucomisd xmm13, xmm13
00007f9bd71cebc9  jp 0x00007F9BD71CEDFC
00007f9bd71cebcf  movq xmm13, xmm13
00007f9bd71cebd4  movq rax, xmm13
00007f9bd71cebd9  movq r14, xmm1
00007f9bd71cebde  vmovq xmm15, rax
00007f9bd71cebe3  vmovq xmm14, r14
00007f9bd71cebe8  movaps xmm13, xmm15
00007f9bd71cebec  addsd xmm13, xmm14
00007f9bd71cebf1  ucomisd xmm13, xmm13
00007f9bd71cebf6  jp 0x00007F9BD71CEE44
00007f9bd71cebfc  movq xmm13, xmm13
00007f9bd71cec01  movq rax, xmm13
00007f9bd71cec06  movq r14, xmm1
00007f9bd71cec0b  vmovq xmm15, rax
00007f9bd71cec10  vmovq xmm14, r14
00007f9bd71cec15  movaps xmm13, xmm15
00007f9bd71cec19  addsd xmm13, xmm14
00007f9bd71cec1e  ucomisd xmm13, xmm13
00007f9bd71cec23  jp 0x00007F9BD71CEE8C
00007f9bd71cec29  movq xmm13, xmm13
00007f9bd71cec2e  movq rax, xmm13
00007f9bd71cec33  movq r14, xmm1
00007f9bd71cec38  vmovq xmm15, rax
00007f9bd71cec3d  vmovq xmm14, r14
00007f9bd71cec42  movaps xmm13, xmm15
00007f9bd71cec46  addsd xmm13, xmm14
00007f9bd71cec4b  ucomisd xmm13, xmm13
00007f9bd71cec50  jp 0x00007F9BD71CEED4
00007f9bd71cec56  movq xmm13, xmm13
00007f9bd71cec5b  movq rax, xmm13
00007f9bd71cec60  movq r14, xmm1
00007f9bd71cec65  vmovq xmm1, rax
00007f9bd71cec6a  vmovq xmm15, r14
00007f9bd71cec6f  movaps xmm14, xmm1
00007f9bd71cec73  addsd xmm14, xmm15
00007f9bd71cec78  ucomisd xmm14, xmm14
00007f9bd71cec7d  jp 0x00007F9BD71CEF1C
00007f9bd71cec83  movq xmm14, xmm14
00007f9bd71cec88  movaps [r15+0x110], xmm14
00007f9bd71cec90  mov rax, [r15+0x08]
00007f9bd71cec94  mov [rsp+0x10], rax
00007f9bd71cec99  xor eax, eax
00007f9bd71cec9b  mov r14, [rsp+0x10]
00007f9bd71ceca0  mov r12d, 0x01
00007f9bd71ceca6  sub r14, r12
00007f9bd71ceca9  cmc
00007f9bd71cecaa  lahf
00007f9bd71cecab  seto al
00007f9bd71cecae  mov [r15+0x108], eax
00007f9bd71cecb5  mov [r15+0x08], r14
00007f9bd71cecb9  mov eax, [r15+0x108]
00007f9bd71cecc0  sahf
00007f9bd71cecc1  jnz 0x00007F9BD71CECF3
00007f9bd71cecc3  cmp dword ptr [r15+0x318], 0x00
00007f9bd71ceccb  jz 0x00007F9BD71CEF70
00007f9bd71cecd1  nop [rax+rax*1], ax
00007f9bd71cecda  nop [rax+rax*1], eax
00007f9bd71cece2  mov eax, 0x41006C
00007f9bd71cece7  mov [r15+0x100], rax
00007f9bd71cecee  jmp 0x00007F9BD6FFE110
00007f9bd71cecf3  cmp dword ptr [r15+0x318], 0x00
00007f9bd71cecfb  jz 0x00007F9BD71CEB10
00007f9bd71ced01  nop [rax+rax*1], ax
00007f9bd71ced0a  nop [rax+rax*1], eax
00007f9bd71ced12  mov eax, 0x410044
00007f9bd71ced17  mov [r15+0x100], rax
00007f9bd71ced1e  jmp 0x00007F9BD6FFE110
00007f9bd71ced23  int3
00007f9bd71ced24  ucomisd xmm15, xmm14
00007f9bd71ced29  jp 0x00007F9BD71CED38
00007f9bd71ced2b  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71ced33  jmp 0x00007F9BD71CEB48
00007f9bd71ced38  vxorps xmm0, xmm15, xmm14
00007f9bd71ced3d  pextrw eax, xmm0, 0x03
00007f9bd71ced42  and eax, 0x7FF8
00007f9bd71ced47  cmp eax, 0x08
00007f9bd71ced4a  jnz 0x00007F9BD71CEB48
00007f9bd71ced50  movq rax, xmm14
00007f9bd71ced55  shl rax, 0x0D
00007f9bd71ced59  jbe 0x00007F9BD71CEB48
00007f9bd71ced5f  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71ced67  jmp 0x00007F9BD71CEB48
00007f9bd71ced6c  ucomisd xmm15, xmm14
00007f9bd71ced71  jp 0x00007F9BD71CED80
00007f9bd71ced73  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71ced7b  jmp 0x00007F9BD71CEB75
00007f9bd71ced80  vxorps xmm0, xmm15, xmm14
00007f9bd71ced85  pextrw eax, xmm0, 0x03
00007f9bd71ced8a  and eax, 0x7FF8
00007f9bd71ced8f  cmp eax, 0x08
00007f9bd71ced92  jnz 0x00007F9BD71CEB75
00007f9bd71ced98  movq rax, xmm14
00007f9bd71ced9d  shl rax, 0x0D
00007f9bd71ceda1  jbe 0x00007F9BD71CEB75
00007f9bd71ceda7  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71cedaf  jmp 0x00007F9BD71CEB75
00007f9bd71cedb4  ucomisd xmm15, xmm14
00007f9bd71cedb9  jp 0x00007F9BD71CEDC8
00007f9bd71cedbb  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71cedc3  jmp 0x00007F9BD71CEBA2
00007f9bd71cedc8  vxorps xmm0, xmm15, xmm14
00007f9bd71cedcd  pextrw eax, xmm0, 0x03
00007f9bd71cedd2  and eax, 0x7FF8
00007f9bd71cedd7  cmp eax, 0x08
00007f9bd71cedda  jnz 0x00007F9BD71CEBA2
00007f9bd71cede0  movq rax, xmm14
00007f9bd71cede5  shl rax, 0x0D
00007f9bd71cede9  jbe 0x00007F9BD71CEBA2
00007f9bd71cedef  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71cedf7  jmp 0x00007F9BD71CEBA2
00007f9bd71cedfc  ucomisd xmm15, xmm14
00007f9bd71cee01  jp 0x00007F9BD71CEE10
00007f9bd71cee03  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71cee0b  jmp 0x00007F9BD71CEBCF
00007f9bd71cee10  vxorps xmm0, xmm15, xmm14
00007f9bd71cee15  pextrw eax, xmm0, 0x03
00007f9bd71cee1a  and eax, 0x7FF8
00007f9bd71cee1f  cmp eax, 0x08
00007f9bd71cee22  jnz 0x00007F9BD71CEBCF
00007f9bd71cee28  movq rax, xmm14
00007f9bd71cee2d  shl rax, 0x0D
00007f9bd71cee31  jbe 0x00007F9BD71CEBCF
00007f9bd71cee37  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71cee3f  jmp 0x00007F9BD71CEBCF
00007f9bd71cee44  ucomisd xmm15, xmm14
00007f9bd71cee49  jp 0x00007F9BD71CEE58
00007f9bd71cee4b  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71cee53  jmp 0x00007F9BD71CEBFC
00007f9bd71cee58  vxorps xmm0, xmm15, xmm14
00007f9bd71cee5d  pextrw eax, xmm0, 0x03
00007f9bd71cee62  and eax, 0x7FF8
00007f9bd71cee67  cmp eax, 0x08
00007f9bd71cee6a  jnz 0x00007F9BD71CEBFC
00007f9bd71cee70  movq rax, xmm14
00007f9bd71cee75  shl rax, 0x0D
00007f9bd71cee79  jbe 0x00007F9BD71CEBFC
00007f9bd71cee7f  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71cee87  jmp 0x00007F9BD71CEBFC
00007f9bd71cee8c  ucomisd xmm15, xmm14
00007f9bd71cee91  jp 0x00007F9BD71CEEA0
00007f9bd71cee93  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71cee9b  jmp 0x00007F9BD71CEC29
00007f9bd71ceea0  vxorps xmm0, xmm15, xmm14
00007f9bd71ceea5  pextrw eax, xmm0, 0x03
00007f9bd71ceeaa  and eax, 0x7FF8
00007f9bd71ceeaf  cmp eax, 0x08
00007f9bd71ceeb2  jnz 0x00007F9BD71CEC29
00007f9bd71ceeb8  movq rax, xmm14
00007f9bd71ceebd  shl rax, 0x0D
00007f9bd71ceec1  jbe 0x00007F9BD71CEC29
00007f9bd71ceec7  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71ceecf  jmp 0x00007F9BD71CEC29
00007f9bd71ceed4  ucomisd xmm15, xmm14
00007f9bd71ceed9  jp 0x00007F9BD71CEEE8
00007f9bd71ceedb  movaps xmm13, [0x00007F9BD6DFE030]
00007f9bd71ceee3  jmp 0x00007F9BD71CEC56
00007f9bd71ceee8  vxorps xmm0, xmm15, xmm14
00007f9bd71ceeed  pextrw eax, xmm0, 0x03
00007f9bd71ceef2  and eax, 0x7FF8
00007f9bd71ceef7  cmp eax, 0x08
00007f9bd71ceefa  jnz 0x00007F9BD71CEC56
00007f9bd71cef00  movq rax, xmm14
00007f9bd71cef05  shl rax, 0x0D
00007f9bd71cef09  jbe 0x00007F9BD71CEC56
00007f9bd71cef0f  vorps xmm13, xmm14, [0x00007F9BD6DFE040]
00007f9bd71cef17  jmp 0x00007F9BD71CEC56
00007f9bd71cef1c  ucomisd xmm1, xmm15
00007f9bd71cef21  jp 0x00007F9BD71CEF30
00007f9bd71cef23  movaps xmm14, [0x00007F9BD6DFE030]
00007f9bd71cef2b  jmp 0x00007F9BD71CEC83
00007f9bd71cef30  vxorps xmm0, xmm1, xmm15
00007f9bd71cef35  pextrw eax, xmm0, 0x03
00007f9bd71cef3a  and eax, 0x7FF8
00007f9bd71cef3f  cmp eax, 0x08
00007f9bd71cef42  jnz 0x00007F9BD71CEC83
00007f9bd71cef48  movq rax, xmm15
00007f9bd71cef4d  shl rax, 0x0D
00007f9bd71cef51  jbe 0x00007F9BD71CEC83
00007f9bd71cef57  vorps xmm14, xmm15, [0x00007F9BD6DFE040]
00007f9bd71cef5f  jmp 0x00007F9BD71CEC83
00007f9bd71cef64  int3
00007f9bd71cef65  nop [rax+rax*1], ax
00007f9bd71cef6e  nop
00007f9bd71cef70  mov rax, [r15+0x20]
00007f9bd71cef74  movaps xmm1, [r15+0x110]
00007f9bd71cef7c  movq r14, xmm1
00007f9bd71cef81  mov [r13+rax*1], r14
00007f9bd71cef86  mov rax, [r15+0xF0]
00007f9bd71cef8d  mov [r15+0x100], rax
00007f9bd71cef94  jmp 0x00007F9BD71CE5C0
00007f9bd71cef99  int3
00007f9bd71cef9a  call 0x00007F9BD700E120
00007f9bd71cef9f  jmp 0x00007F9BD71CEF86
00007f9bd71cefa4  int3
00007f9bd71cefa5  nop [rax+rax*1], ax
00007f9bd71cefae  nop
00007f9bd71cefb0  mov qword ptr [r15+0x100], 0x04
00007f9bd71cefbb  mov esi, 0x00
00007f9bd71cefc0  mov edx, 0x09
00007f9bd71cefc5  mov rdi, 0x7FFD2A2EBBD0
00007f9bd71cefcf  mov rax, 0x6270AAEA1970
00007f9bd71cefd9  call rax
00007f9bd71cefdb  cmp dword ptr [r15+0x318], 0x00
00007f9bd71cefe3  jnz 0x00007F9BD6FFE110
00007f9bd71cefe9  jmp 0x00007F9BD6FFE0A0
00007f9bd71cefee  int3
00007f9bd71cefef  int3
