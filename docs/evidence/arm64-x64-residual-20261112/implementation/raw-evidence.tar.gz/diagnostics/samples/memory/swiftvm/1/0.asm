
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/memory/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

00007a40d0d00000 <.data>:
    7a40d0d00000:	sub    rsp,0x10
    7a40d0d00004:	mov    r11,QWORD PTR [r12+0x398]
    7a40d0d0000c:	mov    QWORD PTR [rsp],r11
    7a40d0d00010:	mov    r13d,0x1b00
    7a40d0d00016:	mov    r14d,0xb7
    7a40d0d0001c:	and    r14d,0xffff
    7a40d0d00023:	mov    rax,r13
    7a40d0d00026:	movabs rcx,0xffffffff0000ffff
    7a40d0d00030:	and    rax,rcx
    7a40d0d00033:	mov    rdx,r14
    7a40d0d00036:	shl    rdx,0x10
    7a40d0d0003a:	mov    ecx,0xffff0000
    7a40d0d0003f:	and    rdx,rcx
    7a40d0d00042:	or     rax,rdx
    7a40d0d00045:	mov    r15,rax
    7a40d0d00048:	mov    QWORD PTR [r12+0x8],r15
    7a40d0d0004d:	mov    r13d,0x420060
    7a40d0d00053:	mov    QWORD PTR [r12+0x20],r13
    7a40d0d00058:	mov    r13d,0x0
    7a40d0d0005e:	mov    QWORD PTR [r12],r13
    7a40d0d00062:	mov    r11,rax
    7a40d0d00065:	movzx  eax,WORD PTR [rsp]
    7a40d0d00069:	add    al,0x7f
    7a40d0d0006b:	sahf
    7a40d0d0006c:	mov    rax,r11
    7a40d0d0006f:	jmp    0x7a40d0d00074
    7a40d0d00074:	mov    r13,QWORD PTR [r12+0x20]
    7a40d0d00079:	mov    r14,QWORD PTR [r12]
    7a40d0d0007d:	mov    QWORD PTR [r13+0x0],r14
    7a40d0d00081:	mov    r14d,0x0
    7a40d0d00087:	mov    DWORD PTR [r12+0x32c],r14d
    7a40d0d0008f:	mov    r14,QWORD PTR [r13+0x0]
    7a40d0d00093:	mov    QWORD PTR [r12+0x18],r14
    7a40d0d00098:	lea    r14,[r14+0x3]
    7a40d0d0009c:	mov    QWORD PTR [r12],r14
    7a40d0d000a0:	mov    r13,QWORD PTR [r12+0x8]
    7a40d0d000a5:	sub    r13,0x1
    7a40d0d000a9:	mov    QWORD PTR [r12+0x8],r13
    7a40d0d000ae:	mov    rcx,QWORD PTR [r12+0x380]
    7a40d0d000b6:	jrcxz  0x7a40d0d000bd
    7a40d0d000b8:	jmp    0x7a40d0d00135
    7a40d0d000bd:	jne    0x7a40d0d00074
    7a40d0d000c3:	mov    r11,rax
    7a40d0d000c6:	lahf
    7a40d0d000c7:	seto   al
    7a40d0d000ca:	mov    WORD PTR [rsp],ax
    7a40d0d000ce:	mov    rax,r11
    7a40d0d000d1:	jmp    0x7a40d0d000d6
    7a40d0d000d6:	mov    r13,QWORD PTR [r12+0x20]
    7a40d0d000db:	mov    r14,QWORD PTR [r12]
    7a40d0d000df:	mov    QWORD PTR [r13+0x0],r14
    7a40d0d000e3:	mov    r13d,0x0
    7a40d0d000e9:	mov    DWORD PTR [r12+0x32c],r13d
    7a40d0d000f1:	mov    rcx,QWORD PTR [r12+0x380]
    7a40d0d000f9:	jrcxz  0x7a40d0d00100
    7a40d0d000fb:	jmp    0x7a40d0d001c6
    7a40d0d00100:	mov    r13,QWORD PTR [r12+0xf0]
    7a40d0d00108:	mov    QWORD PTR [r12+0x100],r13
    7a40d0d00110:	mov    r11,QWORD PTR [rsp]
    7a40d0d00114:	mov    QWORD PTR [r12+0x398],r11
    7a40d0d0011c:	mov    rdi,QWORD PTR [r12+0x100]
    7a40d0d00124:	add    rsp,0x10
    7a40d0d00128:	movabs r11,0x5cc11066a940
    7a40d0d00132:	jmp    r11
    7a40d0d00135:	mov    eax,0x41004c
    7a40d0d0013a:	mov    QWORD PTR [r12+0x100],rax
    7a40d0d00142:	push   rdx
    7a40d0d00143:	push   rsi
    7a40d0d00144:	push   r10
    7a40d0d00146:	push   r11
    7a40d0d00148:	mov    r11,rax
    7a40d0d0014b:	lahf
    7a40d0d0014c:	seto   al
    7a40d0d0014f:	mov    WORD PTR [rsp+0x20],ax
    7a40d0d00154:	mov    rax,r11
    7a40d0d00157:	mov    rdx,QWORD PTR [rsp+0x20]
    7a40d0d0015c:	mov    r10d,edx
    7a40d0d0015f:	and    r10d,0xc000
    7a40d0d00166:	shl    r10d,0x10
    7a40d0d0016a:	mov    r11d,edx
    7a40d0d0016d:	and    r11d,0x100
    7a40d0d00174:	shl    r11d,0x15
    7a40d0d00178:	or     r10d,r11d
    7a40d0d0017b:	and    edx,0x1
    7a40d0d0017e:	shl    edx,0x1c
    7a40d0d00181:	or     r10d,edx
    7a40d0d00184:	btc    r10,0x1d
    7a40d0d00189:	mov    r11d,0xf0000000
    7a40d0d0018f:	and    r11,r10
    7a40d0d00192:	movabs rsi,0xffffffff0fffffff
    7a40d0d0019c:	and    rbx,rsi
    7a40d0d0019f:	or     rbx,r11
    7a40d0d001a2:	pop    r11
    7a40d0d001a4:	pop    r10
    7a40d0d001a6:	pop    rsi
    7a40d0d001a7:	pop    rdx
    7a40d0d001a8:	mov    QWORD PTR [r12+0x108],rbx
    7a40d0d001b0:	add    rsp,0x10
    7a40d0d001b4:	mov    eax,0xc
    7a40d0d001b9:	movabs r11,0x5cc11066aca0
    7a40d0d001c3:	jmp    r11
    7a40d0d001c6:	mov    eax,0x410054
    7a40d0d001cb:	mov    QWORD PTR [r12+0x100],rax
    7a40d0d001d3:	push   rdx
    7a40d0d001d4:	push   rsi
    7a40d0d001d5:	push   r10
    7a40d0d001d7:	push   r11
    7a40d0d001d9:	mov    rdx,QWORD PTR [rsp+0x20]
    7a40d0d001de:	mov    r10d,edx
    7a40d0d001e1:	and    r10d,0xc000
    7a40d0d001e8:	shl    r10d,0x10
    7a40d0d001ec:	mov    r11d,edx
    7a40d0d001ef:	and    r11d,0x100
    7a40d0d001f6:	shl    r11d,0x15
    7a40d0d001fa:	or     r10d,r11d
    7a40d0d001fd:	and    edx,0x1
    7a40d0d00200:	shl    edx,0x1c
    7a40d0d00203:	or     r10d,edx
    7a40d0d00206:	btc    r10,0x1d
    7a40d0d0020b:	mov    r11d,0xf0000000
    7a40d0d00211:	and    r11,r10
    7a40d0d00214:	movabs rsi,0xffffffff0fffffff
    7a40d0d0021e:	and    rbx,rsi
    7a40d0d00221:	or     rbx,r11
    7a40d0d00224:	pop    r11
    7a40d0d00226:	pop    r10
    7a40d0d00228:	pop    rsi
    7a40d0d00229:	pop    rdx
    7a40d0d0022a:	mov    QWORD PTR [r12+0x108],rbx
    7a40d0d00232:	add    rsp,0x10
    7a40d0d00236:	mov    eax,0xc
    7a40d0d0023b:	movabs r11,0x5cc11066aca0
    7a40d0d00245:	jmp    r11
    7a40d0d00248:	nop    DWORD PTR [rax+rax*1+0x0]
    7a40d0d00250:	sub    rsp,0x10
    7a40d0d00254:	mov    r11,QWORD PTR [r12+0x398]
    7a40d0d0025c:	mov    QWORD PTR [rsp],r11
    7a40d0d00260:	mov    r11,rax
    7a40d0d00263:	movzx  eax,WORD PTR [rsp]
    7a40d0d00267:	add    al,0x7f
    7a40d0d00269:	sahf
    7a40d0d0026a:	mov    rax,r11
    7a40d0d0026d:	jmp    0x7a40d0d00074
    7a40d0d00272:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7a40d0d00280:	sub    rsp,0x10
    7a40d0d00284:	mov    r11,QWORD PTR [r12+0x398]
    7a40d0d0028c:	mov    QWORD PTR [rsp],r11
    7a40d0d00290:	jmp    0x7a40d0d000d6
    7a40d0d00295:	nop
    7a40d0d00296:	nop
    7a40d0d00297:	nop
