00007fbd067ce69b  nop [rax+rax*1], eax
00007fbd067ce6a0  mov qword ptr [r15+0x20], 0x420060
00007fbd067ce6a8  mov eax, 0x420060
00007fbd067ce6ad  xor r14d, r14d
00007fbd067ce6b0  mov [r13+rax*1], r14
00007fbd067ce6b5  mov eax, 0x420060
00007fbd067ce6ba  mov r14, [r13+rax*1]
00007fbd067ce6bf  mov [r15+0x18], r14
00007fbd067ce6c3  lea rax, [r14+0x03]
00007fbd067ce6c7  mov [r15], rax
00007fbd067ce6ca  xor eax, eax
00007fbd067ce6cc  mov r14d, 0xB71B00
00007fbd067ce6d2  mov r12d, 0x01
00007fbd067ce6d8  sub r14, r12
00007fbd067ce6db  cmc
00007fbd067ce6dc  lahf
00007fbd067ce6dd  seto al
00007fbd067ce6e0  mov [r15+0x108], eax
00007fbd067ce6e7  mov [r15+0x08], r14
00007fbd067ce6eb  mov eax, [r15+0x108]
00007fbd067ce6f2  sahf
00007fbd067ce6f3  jnz 0x00007FBD067CE725
00007fbd067ce6f5  cmp dword ptr [r15+0x318], 0x00
00007fbd067ce6fd  jz 0x00007FBD067CE840
00007fbd067ce703  nop [rax+rax*1], ax
00007fbd067ce70c  nop [rax+rax*1], eax
00007fbd067ce714  mov eax, 0x410050
00007fbd067ce719  mov [r15+0x100], rax
00007fbd067ce720  jmp 0x00007FBD065FE110
00007fbd067ce725  cmp dword ptr [r15+0x318], 0x00
00007fbd067ce72d  jz 0x00007FBD067CE770
00007fbd067ce733  nop [rax+rax*1], ax
00007fbd067ce73c  nop [rax+rax*1], eax
00007fbd067ce744  mov eax, 0x41003C
00007fbd067ce749  mov [r15+0x100], rax
00007fbd067ce750  jmp 0x00007FBD065FE110
00007fbd067ce755  int3
00007fbd067ce756  call 0x00007FBD0660E120
00007fbd067ce75b  jmp 0x00007FBD067CE6B5
00007fbd067ce760  call 0x00007FBD0660DC20
00007fbd067ce765  jmp 0x00007FBD067CE6BF
00007fbd067ce76a  int3
00007fbd067ce76b  nop [rax+rax*1], eax
00007fbd067ce770  mov rax, [r15+0x20]
00007fbd067ce774  mov r14, [r15]
00007fbd067ce777  mov [r13+rax*1], r14
00007fbd067ce77c  mov r14, [r13+rax*1]
00007fbd067ce781  mov [r15+0x18], r14
00007fbd067ce785  lea rax, [r14+0x03]
00007fbd067ce789  mov [r15], rax
00007fbd067ce78c  mov rax, [r15+0x08]
00007fbd067ce790  mov [rsp+0x10], rax
00007fbd067ce795  xor eax, eax
00007fbd067ce797  mov r14, [rsp+0x10]
00007fbd067ce79c  mov r12d, 0x01
00007fbd067ce7a2  sub r14, r12
00007fbd067ce7a5  cmc
00007fbd067ce7a6  lahf
00007fbd067ce7a7  seto al
00007fbd067ce7aa  mov [r15+0x108], eax
00007fbd067ce7b1  mov [r15+0x08], r14
00007fbd067ce7b5  mov eax, [r15+0x108]
00007fbd067ce7bc  sahf
00007fbd067ce7bd  jnz 0x00007FBD067CE7EF
00007fbd067ce7bf  cmp dword ptr [r15+0x318], 0x00
00007fbd067ce7c7  jz 0x00007FBD067CE840
00007fbd067ce7cd  nop [rax+rax*1], ax
00007fbd067ce7d6  nop [rax+rax*1], eax
00007fbd067ce7de  mov eax, 0x410050
00007fbd067ce7e3  mov [r15+0x100], rax
00007fbd067ce7ea  jmp 0x00007FBD065FE110
00007fbd067ce7ef  cmp dword ptr [r15+0x318], 0x00
00007fbd067ce7f7  jz 0x00007FBD067CE770
00007fbd067ce7fd  nop [rax+rax*1], ax
00007fbd067ce806  nop [rax+rax*1], eax
00007fbd067ce80e  mov eax, 0x41003C
00007fbd067ce813  mov [r15+0x100], rax
00007fbd067ce81a  jmp 0x00007FBD065FE110
00007fbd067ce81f  int3
00007fbd067ce820  call 0x00007FBD0660E120
00007fbd067ce825  jmp 0x00007FBD067CE77C
00007fbd067ce82a  call 0x00007FBD0660DC20
00007fbd067ce82f  jmp 0x00007FBD067CE781
00007fbd067ce834  int3
00007fbd067ce835  nop [rax+rax*1], ax
00007fbd067ce83e  nop
00007fbd067ce840  mov rax, [r15+0x20]
00007fbd067ce844  mov r14, [r15]
00007fbd067ce847  mov [r13+rax*1], r14
00007fbd067ce84c  mov rax, [r15+0xF0]
00007fbd067ce853  mov [r15+0x100], rax
00007fbd067ce85a  jmp 0x00007FBD067CE5C0
00007fbd067ce85f  int3
00007fbd067ce860  call 0x00007FBD0660E120
00007fbd067ce865  jmp 0x00007FBD067CE84C
00007fbd067ce86a  int3
00007fbd067ce86b  nop [rax+rax*1], eax
00007fbd067ce870  mov qword ptr [r15+0x100], 0x04
00007fbd067ce87b  mov esi, 0x00
00007fbd067ce880  mov edx, 0x09
00007fbd067ce885  mov rdi, 0x7FFEBC45C5E0
00007fbd067ce88f  mov rax, 0x5B6EBB0F8970
00007fbd067ce899  call rax
00007fbd067ce89b  cmp dword ptr [r15+0x318], 0x00
00007fbd067ce8a3  jnz 0x00007FBD065FE110
00007fbd067ce8a9  jmp 0x00007FBD065FE0A0
00007fbd067ce8ae  int3
00007fbd067ce8af  int3
