
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/memory/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

000072802c100000 <.data>:
    72802c100000:	sub    rsp,0x10
    72802c100004:	mov    r11,QWORD PTR [r12+0x398]
    72802c10000c:	mov    QWORD PTR [rsp],r11
    72802c100010:	mov    r13d,0x1b00
    72802c100016:	mov    r14d,0xb7
    72802c10001c:	and    r14d,0xffff
    72802c100023:	mov    rax,r13
    72802c100026:	movabs rcx,0xffffffff0000ffff
    72802c100030:	and    rax,rcx
    72802c100033:	mov    rdx,r14
    72802c100036:	shl    rdx,0x10
    72802c10003a:	mov    ecx,0xffff0000
    72802c10003f:	and    rdx,rcx
    72802c100042:	or     rax,rdx
    72802c100045:	mov    r15,rax
    72802c100048:	mov    QWORD PTR [r12+0x8],r15
    72802c10004d:	mov    r13d,0x420060
    72802c100053:	mov    QWORD PTR [r12+0x20],r13
    72802c100058:	mov    r13d,0x0
    72802c10005e:	mov    QWORD PTR [r12],r13
    72802c100062:	mov    r11,rax
    72802c100065:	movzx  eax,WORD PTR [rsp]
    72802c100069:	add    al,0x7f
    72802c10006b:	sahf
    72802c10006c:	mov    rax,r11
    72802c10006f:	jmp    0x72802c100074
    72802c100074:	mov    r13,QWORD PTR [r12+0x20]
    72802c100079:	mov    r14,QWORD PTR [r12]
    72802c10007d:	mov    QWORD PTR [r13+0x0],r14
    72802c100081:	mov    r14d,0x0
    72802c100087:	mov    DWORD PTR [r12+0x32c],r14d
    72802c10008f:	mov    r14,QWORD PTR [r13+0x0]
    72802c100093:	mov    QWORD PTR [r12+0x18],r14
    72802c100098:	lea    r14,[r14+0x3]
    72802c10009c:	mov    QWORD PTR [r12],r14
    72802c1000a0:	mov    r13,QWORD PTR [r12+0x8]
    72802c1000a5:	sub    r13,0x1
    72802c1000a9:	mov    QWORD PTR [r12+0x8],r13
    72802c1000ae:	mov    rcx,QWORD PTR [r12+0x380]
    72802c1000b6:	jrcxz  0x72802c1000bd
    72802c1000b8:	jmp    0x72802c100135
    72802c1000bd:	jne    0x72802c100074
    72802c1000c3:	mov    r11,rax
    72802c1000c6:	lahf
    72802c1000c7:	seto   al
    72802c1000ca:	mov    WORD PTR [rsp],ax
    72802c1000ce:	mov    rax,r11
    72802c1000d1:	jmp    0x72802c1000d6
    72802c1000d6:	mov    r13,QWORD PTR [r12+0x20]
    72802c1000db:	mov    r14,QWORD PTR [r12]
    72802c1000df:	mov    QWORD PTR [r13+0x0],r14
    72802c1000e3:	mov    r13d,0x0
    72802c1000e9:	mov    DWORD PTR [r12+0x32c],r13d
    72802c1000f1:	mov    rcx,QWORD PTR [r12+0x380]
    72802c1000f9:	jrcxz  0x72802c100100
    72802c1000fb:	jmp    0x72802c1001c6
    72802c100100:	mov    r13,QWORD PTR [r12+0xf0]
    72802c100108:	mov    QWORD PTR [r12+0x100],r13
    72802c100110:	mov    r11,QWORD PTR [rsp]
    72802c100114:	mov    QWORD PTR [r12+0x398],r11
    72802c10011c:	mov    rdi,QWORD PTR [r12+0x100]
    72802c100124:	add    rsp,0x10
    72802c100128:	movabs r11,0x5ffa8cb1e940
    72802c100132:	jmp    r11
    72802c100135:	mov    eax,0x41004c
    72802c10013a:	mov    QWORD PTR [r12+0x100],rax
    72802c100142:	push   rdx
    72802c100143:	push   rsi
    72802c100144:	push   r10
    72802c100146:	push   r11
    72802c100148:	mov    r11,rax
    72802c10014b:	lahf
    72802c10014c:	seto   al
    72802c10014f:	mov    WORD PTR [rsp+0x20],ax
    72802c100154:	mov    rax,r11
    72802c100157:	mov    rdx,QWORD PTR [rsp+0x20]
    72802c10015c:	mov    r10d,edx
    72802c10015f:	and    r10d,0xc000
    72802c100166:	shl    r10d,0x10
    72802c10016a:	mov    r11d,edx
    72802c10016d:	and    r11d,0x100
    72802c100174:	shl    r11d,0x15
    72802c100178:	or     r10d,r11d
    72802c10017b:	and    edx,0x1
    72802c10017e:	shl    edx,0x1c
    72802c100181:	or     r10d,edx
    72802c100184:	btc    r10,0x1d
    72802c100189:	mov    r11d,0xf0000000
    72802c10018f:	and    r11,r10
    72802c100192:	movabs rsi,0xffffffff0fffffff
    72802c10019c:	and    rbx,rsi
    72802c10019f:	or     rbx,r11
    72802c1001a2:	pop    r11
    72802c1001a4:	pop    r10
    72802c1001a6:	pop    rsi
    72802c1001a7:	pop    rdx
    72802c1001a8:	mov    QWORD PTR [r12+0x108],rbx
    72802c1001b0:	add    rsp,0x10
    72802c1001b4:	mov    eax,0xc
    72802c1001b9:	movabs r11,0x5ffa8cb1eca0
    72802c1001c3:	jmp    r11
    72802c1001c6:	mov    eax,0x410054
    72802c1001cb:	mov    QWORD PTR [r12+0x100],rax
    72802c1001d3:	push   rdx
    72802c1001d4:	push   rsi
    72802c1001d5:	push   r10
    72802c1001d7:	push   r11
    72802c1001d9:	mov    rdx,QWORD PTR [rsp+0x20]
    72802c1001de:	mov    r10d,edx
    72802c1001e1:	and    r10d,0xc000
    72802c1001e8:	shl    r10d,0x10
    72802c1001ec:	mov    r11d,edx
    72802c1001ef:	and    r11d,0x100
    72802c1001f6:	shl    r11d,0x15
    72802c1001fa:	or     r10d,r11d
    72802c1001fd:	and    edx,0x1
    72802c100200:	shl    edx,0x1c
    72802c100203:	or     r10d,edx
    72802c100206:	btc    r10,0x1d
    72802c10020b:	mov    r11d,0xf0000000
    72802c100211:	and    r11,r10
    72802c100214:	movabs rsi,0xffffffff0fffffff
    72802c10021e:	and    rbx,rsi
    72802c100221:	or     rbx,r11
    72802c100224:	pop    r11
    72802c100226:	pop    r10
    72802c100228:	pop    rsi
    72802c100229:	pop    rdx
    72802c10022a:	mov    QWORD PTR [r12+0x108],rbx
    72802c100232:	add    rsp,0x10
    72802c100236:	mov    eax,0xc
    72802c10023b:	movabs r11,0x5ffa8cb1eca0
    72802c100245:	jmp    r11
    72802c100248:	nop    DWORD PTR [rax+rax*1+0x0]
    72802c100250:	sub    rsp,0x10
    72802c100254:	mov    r11,QWORD PTR [r12+0x398]
    72802c10025c:	mov    QWORD PTR [rsp],r11
    72802c100260:	mov    r11,rax
    72802c100263:	movzx  eax,WORD PTR [rsp]
    72802c100267:	add    al,0x7f
    72802c100269:	sahf
    72802c10026a:	mov    rax,r11
    72802c10026d:	jmp    0x72802c100074
    72802c100272:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72802c100280:	sub    rsp,0x10
    72802c100284:	mov    r11,QWORD PTR [r12+0x398]
    72802c10028c:	mov    QWORD PTR [rsp],r11
    72802c100290:	jmp    0x72802c1000d6
    72802c100295:	nop
    72802c100296:	nop
    72802c100297:	nop
