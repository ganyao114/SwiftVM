
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/memory/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

000072bddd900000 <.data>:
    72bddd900000:	sub    rsp,0x10
    72bddd900004:	mov    r11,QWORD PTR [r12+0x398]
    72bddd90000c:	mov    QWORD PTR [rsp],r11
    72bddd900010:	mov    r13d,0x1b00
    72bddd900016:	mov    r14d,0xb7
    72bddd90001c:	and    r14d,0xffff
    72bddd900023:	mov    rax,r13
    72bddd900026:	movabs rcx,0xffffffff0000ffff
    72bddd900030:	and    rax,rcx
    72bddd900033:	mov    rdx,r14
    72bddd900036:	shl    rdx,0x10
    72bddd90003a:	mov    ecx,0xffff0000
    72bddd90003f:	and    rdx,rcx
    72bddd900042:	or     rax,rdx
    72bddd900045:	mov    r15,rax
    72bddd900048:	mov    QWORD PTR [r12+0x8],r15
    72bddd90004d:	mov    r13d,0x420060
    72bddd900053:	mov    QWORD PTR [r12+0x20],r13
    72bddd900058:	mov    r13d,0x0
    72bddd90005e:	mov    QWORD PTR [r12],r13
    72bddd900062:	mov    r11,rax
    72bddd900065:	movzx  eax,WORD PTR [rsp]
    72bddd900069:	add    al,0x7f
    72bddd90006b:	sahf
    72bddd90006c:	mov    rax,r11
    72bddd90006f:	jmp    0x72bddd900074
    72bddd900074:	mov    r13,QWORD PTR [r12+0x20]
    72bddd900079:	mov    r14,QWORD PTR [r12]
    72bddd90007d:	mov    QWORD PTR [r13+0x0],r14
    72bddd900081:	mov    r14d,0x0
    72bddd900087:	mov    DWORD PTR [r12+0x32c],r14d
    72bddd90008f:	mov    r14,QWORD PTR [r13+0x0]
    72bddd900093:	mov    QWORD PTR [r12+0x18],r14
    72bddd900098:	lea    r14,[r14+0x3]
    72bddd90009c:	mov    QWORD PTR [r12],r14
    72bddd9000a0:	mov    r13,QWORD PTR [r12+0x8]
    72bddd9000a5:	sub    r13,0x1
    72bddd9000a9:	mov    QWORD PTR [r12+0x8],r13
    72bddd9000ae:	mov    rcx,QWORD PTR [r12+0x380]
    72bddd9000b6:	jrcxz  0x72bddd9000bd
    72bddd9000b8:	jmp    0x72bddd900135
    72bddd9000bd:	jne    0x72bddd900074
    72bddd9000c3:	mov    r11,rax
    72bddd9000c6:	lahf
    72bddd9000c7:	seto   al
    72bddd9000ca:	mov    WORD PTR [rsp],ax
    72bddd9000ce:	mov    rax,r11
    72bddd9000d1:	jmp    0x72bddd9000d6
    72bddd9000d6:	mov    r13,QWORD PTR [r12+0x20]
    72bddd9000db:	mov    r14,QWORD PTR [r12]
    72bddd9000df:	mov    QWORD PTR [r13+0x0],r14
    72bddd9000e3:	mov    r13d,0x0
    72bddd9000e9:	mov    DWORD PTR [r12+0x32c],r13d
    72bddd9000f1:	mov    rcx,QWORD PTR [r12+0x380]
    72bddd9000f9:	jrcxz  0x72bddd900100
    72bddd9000fb:	jmp    0x72bddd9001c6
    72bddd900100:	mov    r13,QWORD PTR [r12+0xf0]
    72bddd900108:	mov    QWORD PTR [r12+0x100],r13
    72bddd900110:	mov    r11,QWORD PTR [rsp]
    72bddd900114:	mov    QWORD PTR [r12+0x398],r11
    72bddd90011c:	mov    rdi,QWORD PTR [r12+0x100]
    72bddd900124:	add    rsp,0x10
    72bddd900128:	movabs r11,0x619127ae1940
    72bddd900132:	jmp    r11
    72bddd900135:	mov    eax,0x41004c
    72bddd90013a:	mov    QWORD PTR [r12+0x100],rax
    72bddd900142:	push   rdx
    72bddd900143:	push   rsi
    72bddd900144:	push   r10
    72bddd900146:	push   r11
    72bddd900148:	mov    r11,rax
    72bddd90014b:	lahf
    72bddd90014c:	seto   al
    72bddd90014f:	mov    WORD PTR [rsp+0x20],ax
    72bddd900154:	mov    rax,r11
    72bddd900157:	mov    rdx,QWORD PTR [rsp+0x20]
    72bddd90015c:	mov    r10d,edx
    72bddd90015f:	and    r10d,0xc000
    72bddd900166:	shl    r10d,0x10
    72bddd90016a:	mov    r11d,edx
    72bddd90016d:	and    r11d,0x100
    72bddd900174:	shl    r11d,0x15
    72bddd900178:	or     r10d,r11d
    72bddd90017b:	and    edx,0x1
    72bddd90017e:	shl    edx,0x1c
    72bddd900181:	or     r10d,edx
    72bddd900184:	btc    r10,0x1d
    72bddd900189:	mov    r11d,0xf0000000
    72bddd90018f:	and    r11,r10
    72bddd900192:	movabs rsi,0xffffffff0fffffff
    72bddd90019c:	and    rbx,rsi
    72bddd90019f:	or     rbx,r11
    72bddd9001a2:	pop    r11
    72bddd9001a4:	pop    r10
    72bddd9001a6:	pop    rsi
    72bddd9001a7:	pop    rdx
    72bddd9001a8:	mov    QWORD PTR [r12+0x108],rbx
    72bddd9001b0:	add    rsp,0x10
    72bddd9001b4:	mov    eax,0xc
    72bddd9001b9:	movabs r11,0x619127ae1ca0
    72bddd9001c3:	jmp    r11
    72bddd9001c6:	mov    eax,0x410054
    72bddd9001cb:	mov    QWORD PTR [r12+0x100],rax
    72bddd9001d3:	push   rdx
    72bddd9001d4:	push   rsi
    72bddd9001d5:	push   r10
    72bddd9001d7:	push   r11
    72bddd9001d9:	mov    rdx,QWORD PTR [rsp+0x20]
    72bddd9001de:	mov    r10d,edx
    72bddd9001e1:	and    r10d,0xc000
    72bddd9001e8:	shl    r10d,0x10
    72bddd9001ec:	mov    r11d,edx
    72bddd9001ef:	and    r11d,0x100
    72bddd9001f6:	shl    r11d,0x15
    72bddd9001fa:	or     r10d,r11d
    72bddd9001fd:	and    edx,0x1
    72bddd900200:	shl    edx,0x1c
    72bddd900203:	or     r10d,edx
    72bddd900206:	btc    r10,0x1d
    72bddd90020b:	mov    r11d,0xf0000000
    72bddd900211:	and    r11,r10
    72bddd900214:	movabs rsi,0xffffffff0fffffff
    72bddd90021e:	and    rbx,rsi
    72bddd900221:	or     rbx,r11
    72bddd900224:	pop    r11
    72bddd900226:	pop    r10
    72bddd900228:	pop    rsi
    72bddd900229:	pop    rdx
    72bddd90022a:	mov    QWORD PTR [r12+0x108],rbx
    72bddd900232:	add    rsp,0x10
    72bddd900236:	mov    eax,0xc
    72bddd90023b:	movabs r11,0x619127ae1ca0
    72bddd900245:	jmp    r11
    72bddd900248:	nop    DWORD PTR [rax+rax*1+0x0]
    72bddd900250:	sub    rsp,0x10
    72bddd900254:	mov    r11,QWORD PTR [r12+0x398]
    72bddd90025c:	mov    QWORD PTR [rsp],r11
    72bddd900260:	mov    r11,rax
    72bddd900263:	movzx  eax,WORD PTR [rsp]
    72bddd900267:	add    al,0x7f
    72bddd900269:	sahf
    72bddd90026a:	mov    rax,r11
    72bddd90026d:	jmp    0x72bddd900074
    72bddd900272:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72bddd900280:	sub    rsp,0x10
    72bddd900284:	mov    r11,QWORD PTR [r12+0x398]
    72bddd90028c:	mov    QWORD PTR [rsp],r11
    72bddd900290:	jmp    0x72bddd9000d6
    72bddd900295:	nop
    72bddd900296:	nop
    72bddd900297:	nop
