
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/0/3.bin:     file format binary


Disassembly of section .data:

000072ee5f9ffce0 <.data>:
    72ee5f9ffce0:	sub    rsp,0x10
    72ee5f9ffce4:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ffcec:	mov    QWORD PTR [rsp],r11
    72ee5f9ffcf0:	mov    r13,QWORD PTR [r12+0xf8]
    72ee5f9ffcf8:	mov    r14,r13
    72ee5f9ffcfb:	add    r14,0x68
    72ee5f9ffcff:	mov    r15,QWORD PTR [r14]
    72ee5f9ffd02:	mov    QWORD PTR [r12+0x40],r15
    72ee5f9ffd07:	add    r13,0x88
    72ee5f9ffd0e:	mov    r14d,0x0
    72ee5f9ffd14:	mov    BYTE PTR [r13+0x0],r14b
    72ee5f9ffd18:	mov    r13d,0x0
    72ee5f9ffd1e:	mov    DWORD PTR [r12+0x32c],r13d
    72ee5f9ffd26:	sub    r15,0x38
    72ee5f9ffd2a:	je     0x72ee5f9ffd43
    72ee5f9ffd30:	mov    r11,rax
    72ee5f9ffd33:	lahf
    72ee5f9ffd34:	seto   al
    72ee5f9ffd37:	mov    WORD PTR [rsp],ax
    72ee5f9ffd3b:	mov    rax,r11
    72ee5f9ffd3e:	jmp    0x72ee5f9ffd56
    72ee5f9ffd43:	mov    r11,rax
    72ee5f9ffd46:	lahf
    72ee5f9ffd47:	seto   al
    72ee5f9ffd4a:	mov    WORD PTR [rsp],ax
    72ee5f9ffd4e:	mov    rax,r11
    72ee5f9ffd51:	jmp    0x72ee5f9ffddd
    72ee5f9ffd56:	mov    r13,QWORD PTR [r12+0xf8]
    72ee5f9ffd5e:	mov    QWORD PTR [r12],r13
    72ee5f9ffd62:	add    r13,0x88
    72ee5f9ffd69:	mov    QWORD PTR [r12+0x8],r13
    72ee5f9ffd6e:	mov    r13d,0x1
    72ee5f9ffd74:	mov    QWORD PTR [r12+0x10],r13
    72ee5f9ffd79:	mov    r13d,0x4102b8
    72ee5f9ffd7f:	mov    QWORD PTR [r12+0xf0],r13
    72ee5f9ffd87:	mov    r13d,0x410338
    72ee5f9ffd8d:	mov    QWORD PTR [r12+0x100],r13
    72ee5f9ffd95:	mov    r11,QWORD PTR [rsp]
    72ee5f9ffd99:	mov    QWORD PTR [r12+0x398],r11
    72ee5f9ffda1:	mov    edi,0x410338
    72ee5f9ffda6:	mov    QWORD PTR [r12+0x100],rdi
    72ee5f9ffdae:	add    rsp,0x10
    72ee5f9ffdb2:	nop    WORD PTR [rax+rax*1+0x0]
    72ee5f9ffdb8:	jmp    QWORD PTR [rip+0x2]        # 0x72ee5f9ffdc0
    72ee5f9ffdbe:	xchg   ax,ax
    72ee5f9ffdc0:	rcl    ah,0x9f
    72ee5f9ffdc3:	pop    rdi
    72ee5f9ffdc4:	out    dx,al
    72ee5f9ffdc5:	jb     0x72ee5f9ffdc7
    72ee5f9ffdc7:	add    al,dl
    72ee5f9ffdc9:	std
    72ee5f9ffdca:	lahf
    72ee5f9ffdcb:	pop    rdi
    72ee5f9ffdcc:	out    dx,al
    72ee5f9ffdcd:	jb     0x72ee5f9ffdcf
    72ee5f9ffdcf:	add    BYTE PTR [rcx-0x45],cl
    72ee5f9ffdd2:	rex cdq
    72ee5f9ffdd4:	fiadd  DWORD PTR [rsp+rdx*4+0x5c]
    72ee5f9ffdd8:	add    BYTE PTR [rax],al
    72ee5f9ffdda:	jmp    r11
    72ee5f9ffddd:	mov    r13,QWORD PTR [r12+0x98]
    72ee5f9ffde5:	ror    r13,0x3d
    72ee5f9ffde9:	and    r13,0xfffffffffffffff8
    72ee5f9ffded:	mov    r14,QWORD PTR [r12+0xf8]
    72ee5f9ffdf5:	mov    QWORD PTR [r12],r14
    72ee5f9ffdf9:	mov    r15,r14
    72ee5f9ffdfc:	add    r15,0x78
    72ee5f9ffe00:	mov    QWORD PTR [r12+0x8],r15
    72ee5f9ffe05:	mov    r15d,0x8
    72ee5f9ffe0b:	mov    QWORD PTR [r12+0x10],r15
    72ee5f9ffe10:	movabs rcx,0xff00ff00ff00ff
    72ee5f9ffe1a:	mov    r15,r13
    72ee5f9ffe1d:	and    r15,rcx
    72ee5f9ffe20:	shl    r15,0x8
    72ee5f9ffe24:	movabs rcx,0xff00ff00ff00ff00
    72ee5f9ffe2e:	and    r13,rcx
    72ee5f9ffe31:	shr    r13,0x8
    72ee5f9ffe35:	or     r13,r15
    72ee5f9ffe38:	movabs rcx,0xffff0000ffff
    72ee5f9ffe42:	mov    r15,r13
    72ee5f9ffe45:	and    r15,rcx
    72ee5f9ffe48:	shl    r15,0x10
    72ee5f9ffe4c:	movabs rcx,0xffff0000ffff0000
    72ee5f9ffe56:	and    r13,rcx
    72ee5f9ffe59:	shr    r13,0x10
    72ee5f9ffe5d:	or     r13,r15
    72ee5f9ffe60:	mov    r15,r13
    72ee5f9ffe63:	shl    r15,0x20
    72ee5f9ffe67:	shr    r13,0x20
    72ee5f9ffe6b:	or     r13,r15
    72ee5f9ffe6e:	mov    QWORD PTR [r12+0x40],r13
    72ee5f9ffe73:	add    r14,0x78
    72ee5f9ffe77:	mov    QWORD PTR [r14],r13
    72ee5f9ffe7a:	mov    r13d,0x0
    72ee5f9ffe80:	mov    DWORD PTR [r12+0x32c],r13d
    72ee5f9ffe88:	mov    r13d,0x4102e0
    72ee5f9ffe8e:	mov    QWORD PTR [r12+0xf0],r13
    72ee5f9ffe96:	mov    r13d,0x410338
    72ee5f9ffe9c:	mov    QWORD PTR [r12+0x100],r13
    72ee5f9ffea4:	mov    r11,QWORD PTR [rsp]
    72ee5f9ffea8:	mov    QWORD PTR [r12+0x398],r11
    72ee5f9ffeb0:	mov    edi,0x410338
    72ee5f9ffeb5:	mov    QWORD PTR [r12+0x100],rdi
    72ee5f9ffebd:	add    rsp,0x10
    72ee5f9ffec1:	nop    DWORD PTR [rax+0x0]
    72ee5f9ffec8:	jmp    QWORD PTR [rip+0x2]        # 0x72ee5f9ffed0
    72ee5f9ffece:	xchg   ax,ax
    72ee5f9ffed0:	rcl    ah,0x9f
    72ee5f9ffed3:	pop    rdi
    72ee5f9ffed4:	out    dx,al
    72ee5f9ffed5:	jb     0x72ee5f9ffed7
    72ee5f9ffed7:	add    al,ah
    72ee5f9ffed9:	(bad)
    72ee5f9ffeda:	lahf
    72ee5f9ffedb:	pop    rdi
    72ee5f9ffedc:	out    dx,al
    72ee5f9ffedd:	jb     0x72ee5f9ffedf
    72ee5f9ffedf:	add    BYTE PTR [rcx-0x45],cl
    72ee5f9ffee2:	rex cdq
    72ee5f9ffee4:	fiadd  DWORD PTR [rsp+rdx*4+0x5c]
    72ee5f9ffee8:	add    BYTE PTR [rax],al
    72ee5f9ffeea:	jmp    r11
    72ee5f9ffeed:	nop    DWORD PTR [rax]
    72ee5f9ffef0:	sub    rsp,0x10
    72ee5f9ffef4:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ffefc:	mov    QWORD PTR [rsp],r11
    72ee5f9fff00:	jmp    0x72ee5f9ffd56
    72ee5f9fff05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72ee5f9fff10:	sub    rsp,0x10
    72ee5f9fff14:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9fff1c:	mov    QWORD PTR [rsp],r11
    72ee5f9fff20:	jmp    0x72ee5f9ffddd
    72ee5f9fff25:	nop
    72ee5f9fff26:	nop
    72ee5f9fff27:	nop
