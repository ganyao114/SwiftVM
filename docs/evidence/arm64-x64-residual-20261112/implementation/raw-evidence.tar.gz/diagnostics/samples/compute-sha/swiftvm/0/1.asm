
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/0/1.bin:     file format binary


Disassembly of section .data:

000072ee5f9fd4c0 <.data>:
    72ee5f9fd4c0:	sub    rsp,0xc0
    72ee5f9fd4c7:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9fd4cf:	mov    QWORD PTR [rsp+0xb0],r11
    72ee5f9fd4d7:	mov    r13,QWORD PTR [r12]
    72ee5f9fd4db:	mov    r14,r13
    72ee5f9fd4de:	add    r14,0x20
    72ee5f9fd4e2:	mov    r15,QWORD PTR [r14]
    72ee5f9fd4e5:	mov    r14,QWORD PTR [r12+0x10]
    72ee5f9fd4ea:	add    r15,r14
    72ee5f9fd4ed:	mov    QWORD PTR [r12+0x40],r15
    72ee5f9fd4f2:	add    r13,0x20
    72ee5f9fd4f6:	mov    QWORD PTR [r13+0x0],r15
    72ee5f9fd4fa:	mov    r13d,0x0
    72ee5f9fd500:	mov    DWORD PTR [r12+0x32c],r13d
    72ee5f9fd508:	mov    rax,r14
    72ee5f9fd50b:	test   rax,rax
    72ee5f9fd50e:	je     0x72ee5f9ff615
    72ee5f9fd514:	jmp    0x72ee5f9fd519
    72ee5f9fd519:	mov    r13,QWORD PTR [r12+0xf8]
    72ee5f9fd521:	sub    r13,0x150
    72ee5f9fd528:	mov    QWORD PTR [r12+0xf8],r13
    72ee5f9fd530:	mov    r14,QWORD PTR [r12]
    72ee5f9fd534:	mov    r15,r14
    72ee5f9fd537:	add    r15,0x68
    72ee5f9fd53b:	mov    rbp,QWORD PTR [r15]
    72ee5f9fd53e:	mov    QWORD PTR [r12+0x88],rbp
    72ee5f9fd546:	add    r14,0x28
    72ee5f9fd54a:	mov    QWORD PTR [r12+0x40],r14
    72ee5f9fd54f:	mov    QWORD PTR [r12+0x48],r13
    72ee5f9fd554:	mov    r14d,0x420000
    72ee5f9fd55a:	add    r14,0x758
    72ee5f9fd561:	mov    QWORD PTR [r12+0x50],r14
    72ee5f9fd566:	mov    r14,r13
    72ee5f9fd569:	add    r14,0x100
    72ee5f9fd570:	mov    r15,r14
    72ee5f9fd573:	add    r15,0x8
    72ee5f9fd577:	mov    rbp,QWORD PTR [r12+0xe8]
    72ee5f9fd57f:	mov    r8,QWORD PTR [r12+0xd8]
    72ee5f9fd587:	mov    QWORD PTR [r14],rbp
    72ee5f9fd58a:	mov    r14d,0x0
    72ee5f9fd590:	mov    DWORD PTR [r12+0x32c],r14d
    72ee5f9fd598:	mov    QWORD PTR [r15],r8
    72ee5f9fd59b:	mov    r14,r13
    72ee5f9fd59e:	add    r14,0x110
    72ee5f9fd5a5:	mov    r15,r14
    72ee5f9fd5a8:	add    r15,0x8
    72ee5f9fd5ac:	mov    rbp,QWORD PTR [r12+0xd0]
    72ee5f9fd5b4:	mov    r8,QWORD PTR [r12+0xc8]
    72ee5f9fd5bc:	mov    QWORD PTR [r14],rbp
    72ee5f9fd5bf:	mov    QWORD PTR [r15],r8
    72ee5f9fd5c2:	mov    r14,r13
    72ee5f9fd5c5:	add    r14,0x120
    72ee5f9fd5cc:	mov    r15,r14
    72ee5f9fd5cf:	add    r15,0x8
    72ee5f9fd5d3:	mov    rbp,QWORD PTR [r12+0xc0]
    72ee5f9fd5db:	mov    r8,QWORD PTR [r12+0xb8]
    72ee5f9fd5e3:	mov    QWORD PTR [r14],rbp
    72ee5f9fd5e6:	mov    QWORD PTR [r15],r8
    72ee5f9fd5e9:	mov    r14,r13
    72ee5f9fd5ec:	add    r14,0x130
    72ee5f9fd5f3:	mov    r15,r14
    72ee5f9fd5f6:	add    r15,0x8
    72ee5f9fd5fa:	mov    rbp,QWORD PTR [r12+0xb0]
    72ee5f9fd602:	mov    r8,QWORD PTR [r12+0xa8]
    72ee5f9fd60a:	mov    QWORD PTR [r14],rbp
    72ee5f9fd60d:	mov    QWORD PTR [r15],r8
    72ee5f9fd610:	add    r13,0x140
    72ee5f9fd617:	mov    r14,r13
    72ee5f9fd61a:	add    r14,0x8
    72ee5f9fd61e:	mov    r15,QWORD PTR [r12+0xa0]
    72ee5f9fd626:	mov    rbp,QWORD PTR [r12+0x98]
    72ee5f9fd62e:	mov    QWORD PTR [r13+0x0],r15
    72ee5f9fd632:	mov    QWORD PTR [r14],rbp
    72ee5f9fd635:	jmp    0x72ee5f9fd63a
    72ee5f9fd63a:	mov    r13,QWORD PTR [r12+0x8]
    72ee5f9fd63f:	mov    r14,r13
    72ee5f9fd642:	add    r14,0x1
    72ee5f9fd646:	movzx  r15d,BYTE PTR [r13+0x0]
    72ee5f9fd64b:	mov    QWORD PTR [r12+0x58],r15
    72ee5f9fd650:	mov    QWORD PTR [r12+0x8],r14
    72ee5f9fd655:	mov    r13,QWORD PTR [r12+0x88]
    72ee5f9fd65d:	mov    r14,r13
    72ee5f9fd660:	add    r14,0x1
    72ee5f9fd664:	mov    QWORD PTR [r12+0x60],r14
    72ee5f9fd669:	mov    r15,QWORD PTR [r12]
    72ee5f9fd66d:	mov    rbp,r15
    72ee5f9fd670:	add    rbp,0x68
    72ee5f9fd674:	mov    QWORD PTR [rbp+0x0],r14
    72ee5f9fd678:	mov    r14d,0x0
    72ee5f9fd67e:	mov    DWORD PTR [r12+0x32c],r14d
    72ee5f9fd686:	mov    r14,r15
    72ee5f9fd689:	add    r14,r13
    72ee5f9fd68c:	mov    QWORD PTR [r12+0x60],r14
    72ee5f9fd691:	add    r14,0x28
    72ee5f9fd695:	movzx  r13d,BYTE PTR [r12+0x58]
    72ee5f9fd69b:	mov    BYTE PTR [r14],r13b
    72ee5f9fd69e:	add    r15,0x68
    72ee5f9fd6a2:	mov    r13,QWORD PTR [r15]
    72ee5f9fd6a5:	mov    QWORD PTR [r12+0x88],r13
    72ee5f9fd6ad:	sub    r13,0x40
    72ee5f9fd6b1:	mov    rcx,QWORD PTR [r12+0x380]
    72ee5f9fd6b9:	jrcxz  0x72ee5f9fd6c0
    72ee5f9fd6bb:	jmp    0x72ee5f9ff660
    72ee5f9fd6c0:	jne    0x72ee5f9fd6dd
    72ee5f9fd6c6:	mov    r11,rax
    72ee5f9fd6c9:	lahf
    72ee5f9fd6ca:	seto   al
    72ee5f9fd6cd:	mov    WORD PTR [rsp+0xb0],ax
    72ee5f9fd6d5:	mov    rax,r11
    72ee5f9fd6d8:	jmp    0x72ee5f9fd6f4
    72ee5f9fd6dd:	mov    r11,rax
    72ee5f9fd6e0:	lahf
    72ee5f9fd6e1:	seto   al
    72ee5f9fd6e4:	mov    WORD PTR [rsp+0xb0],ax
    72ee5f9fd6ec:	mov    rax,r11
    72ee5f9fd6ef:	jmp    0x72ee5f9ff517
    72ee5f9fd6f4:	mov    rax,QWORD PTR [r12+0x40]
    72ee5f9fd6f9:	mov    eax,0x0
    72ee5f9fd6fe:	mov    QWORD PTR [rsp+0x18],rax
    72ee5f9fd703:	mov    eax,0x0
    72ee5f9fd708:	mov    QWORD PTR [rsp+0x10],rax
    72ee5f9fd70d:	mov    eax,0x0
    72ee5f9fd712:	mov    QWORD PTR [rsp+0x8],rax
    72ee5f9fd717:	mov    eax,0x0
    72ee5f9fd71c:	mov    QWORD PTR [rsp],rax
    72ee5f9fd720:	mov    rdi,QWORD PTR [r12+0x40]
    72ee5f9fd725:	movzx  r9d,BYTE PTR [rdi]
    72ee5f9fd729:	mov    r13,QWORD PTR [rsp+0x18]
    72ee5f9fd72e:	or     r13,r9
    72ee5f9fd731:	mov    r9,QWORD PTR [r12+0x40]
    72ee5f9fd736:	add    r9,0x1
    72ee5f9fd73a:	movzx  r8d,BYTE PTR [r9]
    72ee5f9fd73e:	mov    r9,QWORD PTR [rsp+0x10]
    72ee5f9fd743:	or     r9,r8
    72ee5f9fd746:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fd74b:	add    r8,0x2
    72ee5f9fd74f:	movzx  ebp,BYTE PTR [r8]
    72ee5f9fd753:	mov    r8,QWORD PTR [rsp+0x8]
    72ee5f9fd758:	or     r8,rbp
    72ee5f9fd75b:	mov    rbp,QWORD PTR [r12+0x40]
    72ee5f9fd760:	add    rbp,0x3
    72ee5f9fd764:	movzx  r15d,BYTE PTR [rbp+0x0]
    72ee5f9fd769:	mov    rbp,QWORD PTR [rsp]
    72ee5f9fd76d:	or     rbp,r15
    72ee5f9fd770:	mov    r15,QWORD PTR [r12+0x40]
    72ee5f9fd775:	add    r15,0x4
    72ee5f9fd779:	movzx  r14d,BYTE PTR [r15]
    72ee5f9fd77d:	mov    r15,r14
    72ee5f9fd780:	shl    r15,0x8
    72ee5f9fd784:	or     r13,r15
    72ee5f9fd787:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd78c:	add    r14,0x5
    72ee5f9fd790:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd794:	mov    r14,r15
    72ee5f9fd797:	shl    r14,0x8
    72ee5f9fd79b:	or     r9,r14
    72ee5f9fd79e:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd7a3:	add    r14,0x6
    72ee5f9fd7a7:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd7ab:	mov    r14,r15
    72ee5f9fd7ae:	shl    r14,0x8
    72ee5f9fd7b2:	or     r8,r14
    72ee5f9fd7b5:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd7ba:	add    r14,0x7
    72ee5f9fd7be:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd7c2:	mov    r14,r15
    72ee5f9fd7c5:	shl    r14,0x8
    72ee5f9fd7c9:	or     rbp,r14
    72ee5f9fd7cc:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd7d1:	add    r14,0x8
    72ee5f9fd7d5:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd7d9:	mov    r14,r15
    72ee5f9fd7dc:	shl    r14,0x10
    72ee5f9fd7e0:	or     r13,r14
    72ee5f9fd7e3:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd7e8:	add    r14,0x9
    72ee5f9fd7ec:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd7f0:	mov    r14,r15
    72ee5f9fd7f3:	shl    r14,0x10
    72ee5f9fd7f7:	or     r9,r14
    72ee5f9fd7fa:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd7ff:	add    r14,0xa
    72ee5f9fd803:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd807:	mov    r14,r15
    72ee5f9fd80a:	shl    r14,0x10
    72ee5f9fd80e:	or     r8,r14
    72ee5f9fd811:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd816:	add    r14,0xb
    72ee5f9fd81a:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd81e:	mov    r14,r15
    72ee5f9fd821:	shl    r14,0x10
    72ee5f9fd825:	or     rbp,r14
    72ee5f9fd828:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd82d:	add    r14,0xc
    72ee5f9fd831:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd835:	mov    r14,r15
    72ee5f9fd838:	shl    r14,0x18
    72ee5f9fd83c:	or     r13,r14
    72ee5f9fd83f:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd844:	add    r14,0xd
    72ee5f9fd848:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd84c:	mov    r14,r15
    72ee5f9fd84f:	shl    r14,0x18
    72ee5f9fd853:	or     r9,r14
    72ee5f9fd856:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd85b:	add    r14,0xe
    72ee5f9fd85f:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd863:	mov    r14,r15
    72ee5f9fd866:	shl    r14,0x18
    72ee5f9fd86a:	or     r8,r14
    72ee5f9fd86d:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd872:	add    r14,0xf
    72ee5f9fd876:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd87a:	mov    r14,r15
    72ee5f9fd87d:	shl    r14,0x18
    72ee5f9fd881:	or     rbp,r14
    72ee5f9fd884:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd889:	add    r14,0x10
    72ee5f9fd88d:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd891:	mov    r14,r15
    72ee5f9fd894:	shl    r14,0x20
    72ee5f9fd898:	or     r13,r14
    72ee5f9fd89b:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd8a0:	add    r14,0x11
    72ee5f9fd8a4:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd8a8:	mov    r14,r15
    72ee5f9fd8ab:	shl    r14,0x20
    72ee5f9fd8af:	or     r9,r14
    72ee5f9fd8b2:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd8b7:	add    r14,0x12
    72ee5f9fd8bb:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd8bf:	mov    r14,r15
    72ee5f9fd8c2:	shl    r14,0x20
    72ee5f9fd8c6:	or     r8,r14
    72ee5f9fd8c9:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd8ce:	add    r14,0x13
    72ee5f9fd8d2:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd8d6:	mov    r14,r15
    72ee5f9fd8d9:	shl    r14,0x20
    72ee5f9fd8dd:	or     rbp,r14
    72ee5f9fd8e0:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd8e5:	add    r14,0x14
    72ee5f9fd8e9:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd8ed:	mov    r14,r15
    72ee5f9fd8f0:	shl    r14,0x28
    72ee5f9fd8f4:	or     r13,r14
    72ee5f9fd8f7:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd8fc:	add    r14,0x15
    72ee5f9fd900:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd904:	mov    r14,r15
    72ee5f9fd907:	shl    r14,0x28
    72ee5f9fd90b:	or     r9,r14
    72ee5f9fd90e:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd913:	add    r14,0x16
    72ee5f9fd917:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd91b:	mov    r14,r15
    72ee5f9fd91e:	shl    r14,0x28
    72ee5f9fd922:	or     r8,r14
    72ee5f9fd925:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd92a:	add    r14,0x17
    72ee5f9fd92e:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd932:	mov    r14,r15
    72ee5f9fd935:	shl    r14,0x28
    72ee5f9fd939:	or     rbp,r14
    72ee5f9fd93c:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd941:	add    r14,0x18
    72ee5f9fd945:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd949:	mov    r14,r15
    72ee5f9fd94c:	shl    r14,0x30
    72ee5f9fd950:	or     r13,r14
    72ee5f9fd953:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd958:	add    r14,0x19
    72ee5f9fd95c:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd960:	mov    r14,r15
    72ee5f9fd963:	shl    r14,0x30
    72ee5f9fd967:	or     r9,r14
    72ee5f9fd96a:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd96f:	add    r14,0x1a
    72ee5f9fd973:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd977:	mov    r14,r15
    72ee5f9fd97a:	shl    r14,0x30
    72ee5f9fd97e:	or     r8,r14
    72ee5f9fd981:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd986:	add    r14,0x1b
    72ee5f9fd98a:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd98e:	mov    r14,r15
    72ee5f9fd991:	shl    r14,0x30
    72ee5f9fd995:	or     rbp,r14
    72ee5f9fd998:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd99d:	add    r14,0x1c
    72ee5f9fd9a1:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd9a5:	mov    r14,r15
    72ee5f9fd9a8:	shl    r14,0x38
    72ee5f9fd9ac:	mov    rax,r13
    72ee5f9fd9af:	or     rax,r14
    72ee5f9fd9b2:	mov    QWORD PTR [rsp+0x28],rax
    72ee5f9fd9b7:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd9bc:	add    r14,0x1d
    72ee5f9fd9c0:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd9c4:	mov    r14,r15
    72ee5f9fd9c7:	shl    r14,0x38
    72ee5f9fd9cb:	mov    rax,r9
    72ee5f9fd9ce:	or     rax,r14
    72ee5f9fd9d1:	mov    QWORD PTR [rsp+0x38],rax
    72ee5f9fd9d6:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd9db:	add    r14,0x1e
    72ee5f9fd9df:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fd9e3:	mov    r14,r15
    72ee5f9fd9e6:	shl    r14,0x38
    72ee5f9fd9ea:	mov    rax,r8
    72ee5f9fd9ed:	or     rax,r14
    72ee5f9fd9f0:	mov    QWORD PTR [rsp+0x30],rax
    72ee5f9fd9f5:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fd9fa:	add    r14,0x1f
    72ee5f9fd9fe:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fda02:	mov    r14,r15
    72ee5f9fda05:	shl    r14,0x38
    72ee5f9fda09:	mov    rax,rbp
    72ee5f9fda0c:	or     rax,r14
    72ee5f9fda0f:	mov    QWORD PTR [rsp+0x20],rax
    72ee5f9fda14:	mov    r14,QWORD PTR [r12+0x40]
    72ee5f9fda19:	add    r14,0x20
    72ee5f9fda1d:	movzx  r15d,BYTE PTR [r14]
    72ee5f9fda21:	mov    r14,QWORD PTR [rsp+0x18]
    72ee5f9fda26:	or     r14,r15
    72ee5f9fda29:	mov    r15,QWORD PTR [r12+0x40]
    72ee5f9fda2e:	add    r15,0x21
    72ee5f9fda32:	movzx  ebp,BYTE PTR [r15]
    72ee5f9fda36:	mov    r15,QWORD PTR [rsp+0x10]
    72ee5f9fda3b:	or     r15,rbp
    72ee5f9fda3e:	mov    rbp,QWORD PTR [r12+0x40]
    72ee5f9fda43:	add    rbp,0x22
    72ee5f9fda47:	movzx  r13d,BYTE PTR [rbp+0x0]
    72ee5f9fda4c:	mov    rbp,QWORD PTR [rsp+0x8]
    72ee5f9fda51:	or     rbp,r13
    72ee5f9fda54:	mov    r13,QWORD PTR [r12+0x40]
    72ee5f9fda59:	add    r13,0x23
    72ee5f9fda5d:	movzx  r8d,BYTE PTR [r13+0x0]
    72ee5f9fda62:	mov    r13,QWORD PTR [rsp]
    72ee5f9fda66:	or     r13,r8
    72ee5f9fda69:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fda6e:	add    r8,0x24
    72ee5f9fda72:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fda76:	mov    r8,r9
    72ee5f9fda79:	shl    r8,0x8
    72ee5f9fda7d:	or     r14,r8
    72ee5f9fda80:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fda85:	add    r8,0x25
    72ee5f9fda89:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fda8d:	mov    r8,r9
    72ee5f9fda90:	shl    r8,0x8
    72ee5f9fda94:	or     r15,r8
    72ee5f9fda97:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fda9c:	add    r8,0x26
    72ee5f9fdaa0:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdaa4:	mov    r8,r9
    72ee5f9fdaa7:	shl    r8,0x8
    72ee5f9fdaab:	or     rbp,r8
    72ee5f9fdaae:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdab3:	add    r8,0x27
    72ee5f9fdab7:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdabb:	mov    r8,r9
    72ee5f9fdabe:	shl    r8,0x8
    72ee5f9fdac2:	or     r13,r8
    72ee5f9fdac5:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdaca:	add    r8,0x28
    72ee5f9fdace:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdad2:	mov    r8,r9
    72ee5f9fdad5:	shl    r8,0x10
    72ee5f9fdad9:	or     r14,r8
    72ee5f9fdadc:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdae1:	add    r8,0x29
    72ee5f9fdae5:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdae9:	mov    r8,r9
    72ee5f9fdaec:	shl    r8,0x10
    72ee5f9fdaf0:	or     r15,r8
    72ee5f9fdaf3:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdaf8:	add    r8,0x2a
    72ee5f9fdafc:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdb00:	mov    r8,r9
    72ee5f9fdb03:	shl    r8,0x10
    72ee5f9fdb07:	or     rbp,r8
    72ee5f9fdb0a:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdb0f:	add    r8,0x2b
    72ee5f9fdb13:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdb17:	mov    r8,r9
    72ee5f9fdb1a:	shl    r8,0x10
    72ee5f9fdb1e:	or     r13,r8
    72ee5f9fdb21:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdb26:	add    r8,0x2c
    72ee5f9fdb2a:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdb2e:	mov    r8,r9
    72ee5f9fdb31:	shl    r8,0x18
    72ee5f9fdb35:	or     r14,r8
    72ee5f9fdb38:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdb3d:	add    r8,0x2d
    72ee5f9fdb41:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdb45:	mov    r8,r9
    72ee5f9fdb48:	shl    r8,0x18
    72ee5f9fdb4c:	or     r15,r8
    72ee5f9fdb4f:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdb54:	add    r8,0x2e
    72ee5f9fdb58:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdb5c:	mov    r8,r9
    72ee5f9fdb5f:	shl    r8,0x18
    72ee5f9fdb63:	or     rbp,r8
    72ee5f9fdb66:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdb6b:	add    r8,0x2f
    72ee5f9fdb6f:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdb73:	mov    r8,r9
    72ee5f9fdb76:	shl    r8,0x18
    72ee5f9fdb7a:	or     r13,r8
    72ee5f9fdb7d:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdb82:	add    r8,0x30
    72ee5f9fdb86:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdb8a:	mov    r8,r9
    72ee5f9fdb8d:	shl    r8,0x20
    72ee5f9fdb91:	or     r14,r8
    72ee5f9fdb94:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdb99:	add    r8,0x31
    72ee5f9fdb9d:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdba1:	mov    r8,r9
    72ee5f9fdba4:	shl    r8,0x20
    72ee5f9fdba8:	or     r15,r8
    72ee5f9fdbab:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdbb0:	add    r8,0x32
    72ee5f9fdbb4:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdbb8:	mov    r8,r9
    72ee5f9fdbbb:	shl    r8,0x20
    72ee5f9fdbbf:	or     rbp,r8
    72ee5f9fdbc2:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdbc7:	add    r8,0x33
    72ee5f9fdbcb:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdbcf:	mov    r8,r9
    72ee5f9fdbd2:	shl    r8,0x20
    72ee5f9fdbd6:	or     r13,r8
    72ee5f9fdbd9:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdbde:	add    r8,0x34
    72ee5f9fdbe2:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdbe6:	mov    r8,r9
    72ee5f9fdbe9:	shl    r8,0x28
    72ee5f9fdbed:	or     r14,r8
    72ee5f9fdbf0:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdbf5:	add    r8,0x35
    72ee5f9fdbf9:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdbfd:	mov    r8,r9
    72ee5f9fdc00:	shl    r8,0x28
    72ee5f9fdc04:	or     r15,r8
    72ee5f9fdc07:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdc0c:	add    r8,0x36
    72ee5f9fdc10:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdc14:	mov    r8,r9
    72ee5f9fdc17:	shl    r8,0x28
    72ee5f9fdc1b:	or     rbp,r8
    72ee5f9fdc1e:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdc23:	add    r8,0x37
    72ee5f9fdc27:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdc2b:	mov    r8,r9
    72ee5f9fdc2e:	shl    r8,0x28
    72ee5f9fdc32:	or     r13,r8
    72ee5f9fdc35:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdc3a:	add    r8,0x38
    72ee5f9fdc3e:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdc42:	mov    r8,r9
    72ee5f9fdc45:	shl    r8,0x30
    72ee5f9fdc49:	or     r14,r8
    72ee5f9fdc4c:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdc51:	add    r8,0x39
    72ee5f9fdc55:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdc59:	mov    r8,r9
    72ee5f9fdc5c:	shl    r8,0x30
    72ee5f9fdc60:	or     r15,r8
    72ee5f9fdc63:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdc68:	add    r8,0x3a
    72ee5f9fdc6c:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdc70:	mov    r8,r9
    72ee5f9fdc73:	shl    r8,0x30
    72ee5f9fdc77:	or     rbp,r8
    72ee5f9fdc7a:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdc7f:	add    r8,0x3b
    72ee5f9fdc83:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdc87:	mov    r8,r9
    72ee5f9fdc8a:	shl    r8,0x30
    72ee5f9fdc8e:	or     r13,r8
    72ee5f9fdc91:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdc96:	add    r8,0x3c
    72ee5f9fdc9a:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdc9e:	mov    r8,r9
    72ee5f9fdca1:	shl    r8,0x38
    72ee5f9fdca5:	or     r14,r8
    72ee5f9fdca8:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdcad:	add    r8,0x3d
    72ee5f9fdcb1:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdcb5:	mov    r8,r9
    72ee5f9fdcb8:	shl    r8,0x38
    72ee5f9fdcbc:	or     r15,r8
    72ee5f9fdcbf:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdcc4:	add    r8,0x3e
    72ee5f9fdcc8:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdccc:	mov    r8,r9
    72ee5f9fdccf:	shl    r8,0x38
    72ee5f9fdcd3:	or     rbp,r8
    72ee5f9fdcd6:	mov    r8,QWORD PTR [r12+0x40]
    72ee5f9fdcdb:	add    r8,0x3f
    72ee5f9fdcdf:	movzx  r9d,BYTE PTR [r8]
    72ee5f9fdce3:	mov    r8,r9
    72ee5f9fdce6:	shl    r8,0x38
    72ee5f9fdcea:	mov    rax,r13
    72ee5f9fdced:	or     rax,r8
    72ee5f9fdcf0:	mov    QWORD PTR [rsp+0x40],rax
    72ee5f9fdcf5:	mov    r8d,0x0
    72ee5f9fdcfb:	mov    QWORD PTR [r12+0x58],r8
    72ee5f9fdd00:	mov    r8d,0x0
    72ee5f9fdd06:	mov    r9,QWORD PTR [rsp+0x38]
    72ee5f9fdd0b:	and    r9,0xff
    72ee5f9fdd12:	and    r9,0xffff
    72ee5f9fdd19:	mov    r13,r8
    72ee5f9fdd1c:	or     r13,r9
    72ee5f9fdd1f:	mov    r9,QWORD PTR [rsp+0x38]
    72ee5f9fdd24:	shr    r9,0x8
    72ee5f9fdd28:	and    r9,0xff
    72ee5f9fdd2f:	and    r9,0xffff
    72ee5f9fdd36:	shl    r9,0x10
    72ee5f9fdd3a:	or     r13,r9
    72ee5f9fdd3d:	mov    r9,QWORD PTR [rsp+0x38]
    72ee5f9fdd42:	shr    r9,0x10
    72ee5f9fdd46:	and    r9,0xff
    72ee5f9fdd4d:	and    r9,0xffff
    72ee5f9fdd54:	shl    r9,0x20
    72ee5f9fdd58:	or     r13,r9
    72ee5f9fdd5b:	mov    r9,QWORD PTR [rsp+0x38]
    72ee5f9fdd60:	shr    r9,0x18
    72ee5f9fdd64:	and    r9,0xff
    72ee5f9fdd6b:	and    r9,0xffff
    72ee5f9fdd72:	shl    r9,0x30
    72ee5f9fdd76:	or     r13,r9
    72ee5f9fdd79:	mov    r9,QWORD PTR [rsp+0x38]
    72ee5f9fdd7e:	shr    r9,0x20
    72ee5f9fdd82:	and    r9,0xff
    72ee5f9fdd89:	and    r9,0xffff
    72ee5f9fdd90:	or     r8,r9
    72ee5f9fdd93:	mov    r9,QWORD PTR [rsp+0x38]
    72ee5f9fdd98:	shr    r9,0x28
    72ee5f9fdd9c:	and    r9,0xff
    72ee5f9fdda3:	and    r9,0xffff
    72ee5f9fddaa:	shl    r9,0x10
    72ee5f9fddae:	or     r8,r9
    72ee5f9fddb1:	mov    r9,QWORD PTR [rsp+0x38]
    72ee5f9fddb6:	shr    r9,0x30
    72ee5f9fddba:	and    r9,0xff
    72ee5f9fddc1:	and    r9,0xffff
    72ee5f9fddc8:	shl    r9,0x20
    72ee5f9fddcc:	or     r8,r9
    72ee5f9fddcf:	mov    r9,QWORD PTR [rsp+0x38]
    72ee5f9fddd4:	shr    r9,0x38
    72ee5f9fddd8:	and    r9,0xff
    72ee5f9fdddf:	and    r9,0xffff
    72ee5f9fdde6:	shl    r9,0x30
    72ee5f9fddea:	or     r8,r9
    72ee5f9fdded:	mov    QWORD PTR [r12+0x150],r13
    72ee5f9fddf5:	mov    QWORD PTR [r12+0x158],r8
    72ee5f9fddfd:	mov    r13d,0x0
    72ee5f9fde03:	mov    r8,QWORD PTR [rsp+0x30]
    72ee5f9fde08:	and    r8,0xff
    72ee5f9fde0f:	and    r8,0xffff
    72ee5f9fde16:	mov    r9,r13
    72ee5f9fde19:	or     r9,r8
    72ee5f9fde1c:	mov    r8,QWORD PTR [rsp+0x30]
    72ee5f9fde21:	shr    r8,0x8
    72ee5f9fde25:	and    r8,0xff
    72ee5f9fde2c:	and    r8,0xffff
    72ee5f9fde33:	shl    r8,0x10
    72ee5f9fde37:	or     r9,r8
    72ee5f9fde3a:	mov    r8,QWORD PTR [rsp+0x30]
    72ee5f9fde3f:	shr    r8,0x10
    72ee5f9fde43:	and    r8,0xff
    72ee5f9fde4a:	and    r8,0xffff
    72ee5f9fde51:	shl    r8,0x20
    72ee5f9fde55:	or     r9,r8
    72ee5f9fde58:	mov    r8,QWORD PTR [rsp+0x30]
    72ee5f9fde5d:	shr    r8,0x18
    72ee5f9fde61:	and    r8,0xff
    72ee5f9fde68:	and    r8,0xffff
    72ee5f9fde6f:	shl    r8,0x30
    72ee5f9fde73:	mov    rax,r9
    72ee5f9fde76:	or     rax,r8
    72ee5f9fde79:	mov    QWORD PTR [rsp+0x50],rax
    72ee5f9fde7e:	mov    r8,QWORD PTR [rsp+0x30]
    72ee5f9fde83:	shr    r8,0x20
    72ee5f9fde87:	and    r8,0xff
    72ee5f9fde8e:	and    r8,0xffff
    72ee5f9fde95:	or     r13,r8
    72ee5f9fde98:	mov    r8,QWORD PTR [rsp+0x30]
    72ee5f9fde9d:	shr    r8,0x28
    72ee5f9fdea1:	and    r8,0xff
    72ee5f9fdea8:	and    r8,0xffff
    72ee5f9fdeaf:	shl    r8,0x10
    72ee5f9fdeb3:	or     r13,r8
    72ee5f9fdeb6:	mov    r8,QWORD PTR [rsp+0x30]
    72ee5f9fdebb:	shr    r8,0x30
    72ee5f9fdebf:	and    r8,0xff
    72ee5f9fdec6:	and    r8,0xffff
    72ee5f9fdecd:	shl    r8,0x20
    72ee5f9fded1:	or     r13,r8
    72ee5f9fded4:	mov    r8,QWORD PTR [rsp+0x30]
    72ee5f9fded9:	shr    r8,0x38
    72ee5f9fdedd:	and    r8,0xff
    72ee5f9fdee4:	and    r8,0xffff
    72ee5f9fdeeb:	shl    r8,0x30
    72ee5f9fdeef:	mov    rax,r13
    72ee5f9fdef2:	or     rax,r8
    72ee5f9fdef5:	mov    QWORD PTR [rsp+0x48],rax
    72ee5f9fdefa:	mov    r8d,0x0
    72ee5f9fdf00:	mov    r13,QWORD PTR [rsp+0x28]
    72ee5f9fdf05:	and    r13,0xff
    72ee5f9fdf0c:	and    r13,0xffff
    72ee5f9fdf13:	mov    r9,r8
    72ee5f9fdf16:	or     r9,r13
    72ee5f9fdf19:	mov    r13,QWORD PTR [rsp+0x28]
    72ee5f9fdf1e:	shr    r13,0x8
    72ee5f9fdf22:	and    r13,0xff
    72ee5f9fdf29:	and    r13,0xffff
    72ee5f9fdf30:	shl    r13,0x10
    72ee5f9fdf34:	or     r9,r13
    72ee5f9fdf37:	mov    r13,QWORD PTR [rsp+0x28]
    72ee5f9fdf3c:	shr    r13,0x10
    72ee5f9fdf40:	and    r13,0xff
    72ee5f9fdf47:	and    r13,0xffff
    72ee5f9fdf4e:	shl    r13,0x20
    72ee5f9fdf52:	or     r9,r13
    72ee5f9fdf55:	mov    r13,QWORD PTR [rsp+0x28]
    72ee5f9fdf5a:	shr    r13,0x18
    72ee5f9fdf5e:	and    r13,0xff
    72ee5f9fdf65:	and    r13,0xffff
    72ee5f9fdf6c:	shl    r13,0x30
    72ee5f9fdf70:	mov    rax,r9
    72ee5f9fdf73:	or     rax,r13
    72ee5f9fdf76:	mov    QWORD PTR [rsp+0x58],rax
    72ee5f9fdf7b:	mov    r13,QWORD PTR [rsp+0x28]
    72ee5f9fdf80:	shr    r13,0x20
    72ee5f9fdf84:	and    r13,0xff
    72ee5f9fdf8b:	and    r13,0xffff
    72ee5f9fdf92:	or     r8,r13
    72ee5f9fdf95:	mov    r13,QWORD PTR [rsp+0x28]
    72ee5f9fdf9a:	shr    r13,0x28
    72ee5f9fdf9e:	and    r13,0xff
    72ee5f9fdfa5:	and    r13,0xffff
    72ee5f9fdfac:	shl    r13,0x10
    72ee5f9fdfb0:	or     r8,r13
    72ee5f9fdfb3:	mov    r13,QWORD PTR [rsp+0x28]
    72ee5f9fdfb8:	shr    r13,0x30
    72ee5f9fdfbc:	and    r13,0xff
    72ee5f9fdfc3:	and    r13,0xffff
    72ee5f9fdfca:	shl    r13,0x20
    72ee5f9fdfce:	or     r8,r13
    72ee5f9fdfd1:	mov    r13,QWORD PTR [rsp+0x28]
    72ee5f9fdfd6:	shr    r13,0x38
    72ee5f9fdfda:	and    r13,0xff
    72ee5f9fdfe1:	and    r13,0xffff
    72ee5f9fdfe8:	shl    r13,0x30
    72ee5f9fdfec:	mov    rax,r8
    72ee5f9fdfef:	or     rax,r13
    72ee5f9fdff2:	mov    QWORD PTR [rsp+0x60],rax
    72ee5f9fdff7:	mov    r13d,0x0
    72ee5f9fdffd:	mov    r9,r14
    72ee5f9fe000:	and    r9,0xff
    72ee5f9fe007:	and    r9,0xffff
    72ee5f9fe00e:	mov    r8,r13
    72ee5f9fe011:	or     r8,r9
    72ee5f9fe014:	mov    r9,r14
    72ee5f9fe017:	shr    r9,0x8
    72ee5f9fe01b:	and    r9,0xff
    72ee5f9fe022:	and    r9,0xffff
    72ee5f9fe029:	shl    r9,0x10
    72ee5f9fe02d:	or     r8,r9
    72ee5f9fe030:	mov    r9,r14
    72ee5f9fe033:	shr    r9,0x10
    72ee5f9fe037:	and    r9,0xff
    72ee5f9fe03e:	and    r9,0xffff
    72ee5f9fe045:	shl    r9,0x20
    72ee5f9fe049:	or     r8,r9
    72ee5f9fe04c:	mov    r9,r14
    72ee5f9fe04f:	shr    r9,0x18
    72ee5f9fe053:	and    r9,0xff
    72ee5f9fe05a:	and    r9,0xffff
    72ee5f9fe061:	shl    r9,0x30
    72ee5f9fe065:	mov    rax,r8
    72ee5f9fe068:	or     rax,r9
    72ee5f9fe06b:	mov    QWORD PTR [rsp+0x68],rax
    72ee5f9fe070:	mov    r9,r14
    72ee5f9fe073:	shr    r9,0x20
    72ee5f9fe077:	and    r9,0xff
    72ee5f9fe07e:	and    r9,0xffff
    72ee5f9fe085:	or     r13,r9
    72ee5f9fe088:	mov    r9,r14
    72ee5f9fe08b:	shr    r9,0x28
    72ee5f9fe08f:	and    r9,0xff
    72ee5f9fe096:	and    r9,0xffff
    72ee5f9fe09d:	shl    r9,0x10
    72ee5f9fe0a1:	or     r13,r9
    72ee5f9fe0a4:	mov    r9,r14
    72ee5f9fe0a7:	shr    r9,0x30
    72ee5f9fe0ab:	and    r9,0xff
    72ee5f9fe0b2:	and    r9,0xffff
    72ee5f9fe0b9:	shl    r9,0x20
    72ee5f9fe0bd:	or     r13,r9
    72ee5f9fe0c0:	shr    r14,0x38
    72ee5f9fe0c4:	and    r14,0xff
    72ee5f9fe0cb:	and    r14,0xffff
    72ee5f9fe0d2:	shl    r14,0x30
    72ee5f9fe0d6:	or     r13,r14
    72ee5f9fe0d9:	mov    r14d,0x0
    72ee5f9fe0df:	mov    r9,r15
    72ee5f9fe0e2:	and    r9,0xff
    72ee5f9fe0e9:	and    r9,0xffff
    72ee5f9fe0f0:	mov    r8,r14
    72ee5f9fe0f3:	or     r8,r9
    72ee5f9fe0f6:	mov    r9,r15
    72ee5f9fe0f9:	shr    r9,0x8
    72ee5f9fe0fd:	and    r9,0xff
    72ee5f9fe104:	and    r9,0xffff
    72ee5f9fe10b:	shl    r9,0x10
    72ee5f9fe10f:	or     r8,r9
    72ee5f9fe112:	mov    r9,r15
    72ee5f9fe115:	shr    r9,0x10
    72ee5f9fe119:	and    r9,0xff
    72ee5f9fe120:	and    r9,0xffff
    72ee5f9fe127:	shl    r9,0x20
    72ee5f9fe12b:	or     r8,r9
    72ee5f9fe12e:	mov    r9,r15
    72ee5f9fe131:	shr    r9,0x18
    72ee5f9fe135:	and    r9,0xff
    72ee5f9fe13c:	and    r9,0xffff
    72ee5f9fe143:	shl    r9,0x30
    72ee5f9fe147:	or     r8,r9
    72ee5f9fe14a:	mov    r9,r15
    72ee5f9fe14d:	shr    r9,0x20
    72ee5f9fe151:	and    r9,0xff
    72ee5f9fe158:	and    r9,0xffff
    72ee5f9fe15f:	or     r14,r9
    72ee5f9fe162:	mov    r9,r15
    72ee5f9fe165:	shr    r9,0x28
    72ee5f9fe169:	and    r9,0xff
    72ee5f9fe170:	and    r9,0xffff
    72ee5f9fe177:	shl    r9,0x10
    72ee5f9fe17b:	or     r14,r9
    72ee5f9fe17e:	mov    r9,r15
    72ee5f9fe181:	shr    r9,0x30
    72ee5f9fe185:	and    r9,0xff
    72ee5f9fe18c:	and    r9,0xffff
    72ee5f9fe193:	shl    r9,0x20
    72ee5f9fe197:	or     r14,r9
    72ee5f9fe19a:	shr    r15,0x38
    72ee5f9fe19e:	and    r15,0xff
    72ee5f9fe1a5:	and    r15,0xffff
    72ee5f9fe1ac:	shl    r15,0x30
    72ee5f9fe1b0:	or     r14,r15
    72ee5f9fe1b3:	mov    QWORD PTR [r12+0x210],r8
    72ee5f9fe1bb:	mov    QWORD PTR [r12+0x218],r14
    72ee5f9fe1c3:	mov    r14d,0x0
    72ee5f9fe1c9:	mov    r15,rbp
    72ee5f9fe1cc:	and    r15,0xff
    72ee5f9fe1d3:	and    r15,0xffff
    72ee5f9fe1da:	mov    r8,r14
    72ee5f9fe1dd:	or     r8,r15
    72ee5f9fe1e0:	mov    r15,rbp
    72ee5f9fe1e3:	shr    r15,0x8
    72ee5f9fe1e7:	and    r15,0xff
    72ee5f9fe1ee:	and    r15,0xffff
    72ee5f9fe1f5:	shl    r15,0x10
    72ee5f9fe1f9:	or     r8,r15
    72ee5f9fe1fc:	mov    r15,rbp
    72ee5f9fe1ff:	shr    r15,0x10
    72ee5f9fe203:	and    r15,0xff
    72ee5f9fe20a:	and    r15,0xffff
    72ee5f9fe211:	shl    r15,0x20
    72ee5f9fe215:	or     r8,r15
    72ee5f9fe218:	mov    r15,rbp
    72ee5f9fe21b:	shr    r15,0x18
    72ee5f9fe21f:	and    r15,0xff
    72ee5f9fe226:	and    r15,0xffff
    72ee5f9fe22d:	shl    r15,0x30
    72ee5f9fe231:	or     r8,r15
    72ee5f9fe234:	mov    r15,rbp
    72ee5f9fe237:	shr    r15,0x20
    72ee5f9fe23b:	and    r15,0xff
    72ee5f9fe242:	and    r15,0xffff
    72ee5f9fe249:	or     r14,r15
    72ee5f9fe24c:	mov    r15,rbp
    72ee5f9fe24f:	shr    r15,0x28
    72ee5f9fe253:	and    r15,0xff
    72ee5f9fe25a:	and    r15,0xffff
    72ee5f9fe261:	shl    r15,0x10
    72ee5f9fe265:	or     r14,r15
    72ee5f9fe268:	mov    r15,rbp
    72ee5f9fe26b:	shr    r15,0x30
    72ee5f9fe26f:	and    r15,0xff
    72ee5f9fe276:	and    r15,0xffff
    72ee5f9fe27d:	shl    r15,0x20
    72ee5f9fe281:	or     r14,r15
    72ee5f9fe284:	shr    rbp,0x38
    72ee5f9fe288:	and    rbp,0xff
    72ee5f9fe28f:	and    rbp,0xffff
    72ee5f9fe296:	shl    rbp,0x30
    72ee5f9fe29a:	or     r14,rbp
    72ee5f9fe29d:	mov    r15d,0x0
    72ee5f9fe2a3:	mov    rbp,QWORD PTR [rsp+0x20]
    72ee5f9fe2a8:	and    rbp,0xff
    72ee5f9fe2af:	and    rbp,0xffff
    72ee5f9fe2b6:	mov    r9,r15
    72ee5f9fe2b9:	or     r9,rbp
    72ee5f9fe2bc:	mov    rbp,QWORD PTR [rsp+0x20]
    72ee5f9fe2c1:	shr    rbp,0x8
    72ee5f9fe2c5:	and    rbp,0xff
    72ee5f9fe2cc:	and    rbp,0xffff
    72ee5f9fe2d3:	shl    rbp,0x10
    72ee5f9fe2d7:	or     r9,rbp
    72ee5f9fe2da:	mov    rbp,QWORD PTR [rsp+0x20]
    72ee5f9fe2df:	shr    rbp,0x10
    72ee5f9fe2e3:	and    rbp,0xff
    72ee5f9fe2ea:	and    rbp,0xffff
    72ee5f9fe2f1:	shl    rbp,0x20
    72ee5f9fe2f5:	or     r9,rbp
    72ee5f9fe2f8:	mov    rbp,QWORD PTR [rsp+0x20]
    72ee5f9fe2fd:	shr    rbp,0x18
    72ee5f9fe301:	and    rbp,0xff
    72ee5f9fe308:	and    rbp,0xffff
    72ee5f9fe30f:	shl    rbp,0x30
    72ee5f9fe313:	mov    rax,r9
    72ee5f9fe316:	or     rax,rbp
    72ee5f9fe319:	mov    QWORD PTR [rsp+0x78],rax
    72ee5f9fe31e:	mov    rbp,QWORD PTR [rsp+0x20]
    72ee5f9fe323:	shr    rbp,0x20
    72ee5f9fe327:	and    rbp,0xff
    72ee5f9fe32e:	and    rbp,0xffff
    72ee5f9fe335:	or     r15,rbp
    72ee5f9fe338:	mov    rbp,QWORD PTR [rsp+0x20]
    72ee5f9fe33d:	shr    rbp,0x28
    72ee5f9fe341:	and    rbp,0xff
    72ee5f9fe348:	and    rbp,0xffff
    72ee5f9fe34f:	shl    rbp,0x10
    72ee5f9fe353:	or     r15,rbp
    72ee5f9fe356:	mov    rbp,QWORD PTR [rsp+0x20]
    72ee5f9fe35b:	shr    rbp,0x30
    72ee5f9fe35f:	and    rbp,0xff
    72ee5f9fe366:	and    rbp,0xffff
    72ee5f9fe36d:	shl    rbp,0x20
    72ee5f9fe371:	or     r15,rbp
    72ee5f9fe374:	mov    rbp,QWORD PTR [rsp+0x20]
    72ee5f9fe379:	shr    rbp,0x38
    72ee5f9fe37d:	and    rbp,0xff
    72ee5f9fe384:	and    rbp,0xffff
    72ee5f9fe38b:	shl    rbp,0x30
    72ee5f9fe38f:	mov    rax,r15
    72ee5f9fe392:	or     rax,rbp
    72ee5f9fe395:	mov    QWORD PTR [rsp+0x70],rax
    72ee5f9fe39a:	mov    rax,QWORD PTR [rsp+0x78]
    72ee5f9fe39f:	mov    QWORD PTR [r12+0x250],rax
    72ee5f9fe3a7:	mov    rax,QWORD PTR [rsp+0x70]
    72ee5f9fe3ac:	mov    QWORD PTR [r12+0x258],rax
    72ee5f9fe3b4:	mov    ebp,0x0
    72ee5f9fe3b9:	mov    r15,QWORD PTR [rsp+0x40]
    72ee5f9fe3be:	and    r15,0xff
    72ee5f9fe3c5:	and    r15,0xffff
    72ee5f9fe3cc:	mov    r9,rbp
    72ee5f9fe3cf:	or     r9,r15
    72ee5f9fe3d2:	mov    r15,QWORD PTR [rsp+0x40]
    72ee5f9fe3d7:	shr    r15,0x8
    72ee5f9fe3db:	and    r15,0xff
    72ee5f9fe3e2:	and    r15,0xffff
    72ee5f9fe3e9:	shl    r15,0x10
    72ee5f9fe3ed:	or     r9,r15
    72ee5f9fe3f0:	mov    r15,QWORD PTR [rsp+0x40]
    72ee5f9fe3f5:	shr    r15,0x10
    72ee5f9fe3f9:	and    r15,0xff
    72ee5f9fe400:	and    r15,0xffff
    72ee5f9fe407:	shl    r15,0x20
    72ee5f9fe40b:	or     r9,r15
    72ee5f9fe40e:	mov    r15,QWORD PTR [rsp+0x40]
    72ee5f9fe413:	shr    r15,0x18
    72ee5f9fe417:	and    r15,0xff
    72ee5f9fe41e:	and    r15,0xffff
    72ee5f9fe425:	shl    r15,0x30
    72ee5f9fe429:	mov    rax,r9
    72ee5f9fe42c:	or     rax,r15
    72ee5f9fe42f:	mov    QWORD PTR [rsp+0x80],rax
    72ee5f9fe437:	mov    r15,QWORD PTR [rsp+0x40]
    72ee5f9fe43c:	shr    r15,0x20
    72ee5f9fe440:	and    r15,0xff
    72ee5f9fe447:	and    r15,0xffff
    72ee5f9fe44e:	or     rbp,r15
    72ee5f9fe451:	mov    r15,QWORD PTR [rsp+0x40]
    72ee5f9fe456:	shr    r15,0x28
    72ee5f9fe45a:	and    r15,0xff
    72ee5f9fe461:	and    r15,0xffff
    72ee5f9fe468:	shl    r15,0x10
    72ee5f9fe46c:	or     rbp,r15
    72ee5f9fe46f:	mov    r15,QWORD PTR [rsp+0x40]
    72ee5f9fe474:	shr    r15,0x30
    72ee5f9fe478:	and    r15,0xff
    72ee5f9fe47f:	and    r15,0xffff
    72ee5f9fe486:	shl    r15,0x20
    72ee5f9fe48a:	or     rbp,r15
    72ee5f9fe48d:	mov    r15,QWORD PTR [rsp+0x40]
    72ee5f9fe492:	shr    r15,0x38
    72ee5f9fe496:	and    r15,0xff
    72ee5f9fe49d:	and    r15,0xffff
    72ee5f9fe4a4:	shl    r15,0x30
    72ee5f9fe4a8:	mov    rax,rbp
    72ee5f9fe4ab:	or     rax,r15
    72ee5f9fe4ae:	mov    QWORD PTR [rsp+0x88],rax
    72ee5f9fe4b6:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    72ee5f9fe4c0:	pxor   xmm0,xmm0
    72ee5f9fe4c4:	movdqa xmm3,xmm0
    72ee5f9fe4c8:	movdqa xmm0,xmm2
    72ee5f9fe4cc:	movdqa xmm1,xmm3
    72ee5f9fe4d0:	punpcklwd xmm0,xmm1
    72ee5f9fe4d4:	movdqa xmm4,xmm0
    72ee5f9fe4d8:	movdqa xmm0,xmm4
    72ee5f9fe4dc:	pslld  xmm0,0x10
    72ee5f9fe4e1:	movdqa xmm3,xmm0
    72ee5f9fe4e5:	mov    r15d,0x0
    72ee5f9fe4eb:	mov    r9,QWORD PTR [rsp+0x50]
    72ee5f9fe4f0:	and    r9,0xffff
    72ee5f9fe4f7:	shl    r9,0x8
    72ee5f9fe4fb:	mov    ecx,0xffffffff
    72ee5f9fe500:	and    r9,rcx
    72ee5f9fe503:	mov    rbp,r15
    72ee5f9fe506:	or     rbp,r9
    72ee5f9fe509:	mov    r9,QWORD PTR [rsp+0x50]
    72ee5f9fe50e:	shr    r9,0x10
    72ee5f9fe512:	and    r9,0xffff
    72ee5f9fe519:	shl    r9,0x8
    72ee5f9fe51d:	mov    ecx,0xffffffff
    72ee5f9fe522:	and    r9,rcx
    72ee5f9fe525:	shl    r9,0x20
    72ee5f9fe529:	or     rbp,r9
    72ee5f9fe52c:	mov    r9,QWORD PTR [rsp+0x50]
    72ee5f9fe531:	shr    r9,0x20
    72ee5f9fe535:	and    r9,0xffff
    72ee5f9fe53c:	shl    r9,0x8
    72ee5f9fe540:	mov    ecx,0xffffffff
    72ee5f9fe545:	and    r9,rcx
    72ee5f9fe548:	or     r15,r9
    72ee5f9fe54b:	mov    r9,QWORD PTR [rsp+0x50]
    72ee5f9fe550:	shr    r9,0x30
    72ee5f9fe554:	and    r9,0xffff
    72ee5f9fe55b:	shl    r9,0x8
    72ee5f9fe55f:	mov    ecx,0xffffffff
    72ee5f9fe564:	and    r9,rcx
    72ee5f9fe567:	shl    r9,0x20
    72ee5f9fe56b:	or     r15,r9
    72ee5f9fe56e:	mov    QWORD PTR [r12+0x240],rbp
    72ee5f9fe576:	mov    QWORD PTR [r12+0x248],r15
    72ee5f9fe57e:	mov    r15d,0x0
    72ee5f9fe584:	mov    rbp,QWORD PTR [rsp+0x60]
    72ee5f9fe589:	and    rbp,0xffff
    72ee5f9fe590:	mov    ecx,0xffffffff
    72ee5f9fe595:	and    rbp,rcx
    72ee5f9fe598:	mov    r9,r15
    72ee5f9fe59b:	or     r9,rbp
    72ee5f9fe59e:	mov    rbp,QWORD PTR [rsp+0x60]
    72ee5f9fe5a3:	shr    rbp,0x10
    72ee5f9fe5a7:	and    rbp,0xffff
    72ee5f9fe5ae:	mov    ecx,0xffffffff
    72ee5f9fe5b3:	and    rbp,rcx
    72ee5f9fe5b6:	shl    rbp,0x20
    72ee5f9fe5ba:	or     r9,rbp
    72ee5f9fe5bd:	mov    rbp,QWORD PTR [rsp+0x60]
    72ee5f9fe5c2:	shr    rbp,0x20
    72ee5f9fe5c6:	and    rbp,0xffff
    72ee5f9fe5cd:	mov    ecx,0xffffffff
    72ee5f9fe5d2:	and    rbp,rcx
    72ee5f9fe5d5:	or     r15,rbp
    72ee5f9fe5d8:	mov    rbp,QWORD PTR [rsp+0x60]
    72ee5f9fe5dd:	shr    rbp,0x30
    72ee5f9fe5e1:	and    rbp,0xffff
    72ee5f9fe5e8:	mov    ecx,0xffffffff
    72ee5f9fe5ed:	and    rbp,rcx
    72ee5f9fe5f0:	shl    rbp,0x20
    72ee5f9fe5f4:	or     r15,rbp
    72ee5f9fe5f7:	mov    QWORD PTR [r12+0x260],r9
    72ee5f9fe5ff:	mov    QWORD PTR [r12+0x268],r15
    72ee5f9fe607:	mov    r15d,0x0
    72ee5f9fe60d:	mov    rbp,r13
    72ee5f9fe610:	and    rbp,0xffff
    72ee5f9fe617:	mov    ecx,0xffffffff
    72ee5f9fe61c:	and    rbp,rcx
    72ee5f9fe61f:	mov    r9,r15
    72ee5f9fe622:	or     r9,rbp
    72ee5f9fe625:	mov    rbp,r13
    72ee5f9fe628:	shr    rbp,0x10
    72ee5f9fe62c:	and    rbp,0xffff
    72ee5f9fe633:	mov    ecx,0xffffffff
    72ee5f9fe638:	and    rbp,rcx
    72ee5f9fe63b:	shl    rbp,0x20
    72ee5f9fe63f:	or     r9,rbp
    72ee5f9fe642:	mov    rbp,r13
    72ee5f9fe645:	shr    rbp,0x20
    72ee5f9fe649:	and    rbp,0xffff
    72ee5f9fe650:	mov    ecx,0xffffffff
    72ee5f9fe655:	and    rbp,rcx
    72ee5f9fe658:	or     r15,rbp
    72ee5f9fe65b:	shr    r13,0x30
    72ee5f9fe65f:	and    r13,0xffff
    72ee5f9fe666:	mov    ecx,0xffffffff
    72ee5f9fe66b:	and    r13,rcx
    72ee5f9fe66e:	shl    r13,0x20
    72ee5f9fe672:	or     r15,r13
    72ee5f9fe675:	mov    QWORD PTR [r12+0x270],r9
    72ee5f9fe67d:	mov    QWORD PTR [r12+0x278],r15
    72ee5f9fe685:	mov    r13d,0x0
    72ee5f9fe68b:	mov    r15,QWORD PTR [rsp+0x58]
    72ee5f9fe690:	and    r15,0xffff
    72ee5f9fe697:	mov    ecx,0xffffffff
    72ee5f9fe69c:	and    r15,rcx
    72ee5f9fe69f:	mov    rbp,r13
    72ee5f9fe6a2:	or     rbp,r15
    72ee5f9fe6a5:	mov    r15,QWORD PTR [rsp+0x58]
    72ee5f9fe6aa:	shr    r15,0x10
    72ee5f9fe6ae:	and    r15,0xffff
    72ee5f9fe6b5:	mov    ecx,0xffffffff
    72ee5f9fe6ba:	and    r15,rcx
    72ee5f9fe6bd:	shl    r15,0x20
    72ee5f9fe6c1:	or     rbp,r15
    72ee5f9fe6c4:	mov    r15,QWORD PTR [rsp+0x58]
    72ee5f9fe6c9:	shr    r15,0x20
    72ee5f9fe6cd:	and    r15,0xffff
    72ee5f9fe6d4:	mov    ecx,0xffffffff
    72ee5f9fe6d9:	and    r15,rcx
    72ee5f9fe6dc:	or     r13,r15
    72ee5f9fe6df:	mov    r15,QWORD PTR [rsp+0x58]
    72ee5f9fe6e4:	shr    r15,0x30
    72ee5f9fe6e8:	and    r15,0xffff
    72ee5f9fe6ef:	mov    ecx,0xffffffff
    72ee5f9fe6f4:	and    r15,rcx
    72ee5f9fe6f7:	shl    r15,0x20
    72ee5f9fe6fb:	or     r13,r15
    72ee5f9fe6fe:	mov    QWORD PTR [r12+0x170],rbp
    72ee5f9fe706:	mov    QWORD PTR [r12+0x178],r13
    72ee5f9fe70e:	movdqu xmm4,XMMWORD PTR [r12+0x210]
    72ee5f9fe718:	pxor   xmm0,xmm0
    72ee5f9fe71c:	movdqa xmm5,xmm0
    72ee5f9fe720:	movdqa xmm0,xmm4
    72ee5f9fe724:	movdqa xmm1,xmm5
    72ee5f9fe728:	punpckhwd xmm0,xmm1
    72ee5f9fe72c:	movdqa xmm6,xmm0
    72ee5f9fe730:	movdqa xmm0,xmm6
    72ee5f9fe734:	pslld  xmm0,0x10
    72ee5f9fe739:	movdqa xmm5,xmm0
    72ee5f9fe73d:	movdqu XMMWORD PTR [r12+0x280],xmm5
    72ee5f9fe747:	mov    r13d,0x0
    72ee5f9fe74d:	mov    r15,QWORD PTR [rsp+0x68]
    72ee5f9fe752:	and    r15,0xffff
    72ee5f9fe759:	mov    ecx,0xffffffff
    72ee5f9fe75e:	and    r15,rcx
    72ee5f9fe761:	mov    rbp,r13
    72ee5f9fe764:	or     rbp,r15
    72ee5f9fe767:	mov    r15,QWORD PTR [rsp+0x68]
    72ee5f9fe76c:	shr    r15,0x10
    72ee5f9fe770:	and    r15,0xffff
    72ee5f9fe777:	mov    ecx,0xffffffff
    72ee5f9fe77c:	and    r15,rcx
    72ee5f9fe77f:	shl    r15,0x20
    72ee5f9fe783:	or     rbp,r15
    72ee5f9fe786:	mov    r15,QWORD PTR [rsp+0x68]
    72ee5f9fe78b:	shr    r15,0x20
    72ee5f9fe78f:	and    r15,0xffff
    72ee5f9fe796:	mov    ecx,0xffffffff
    72ee5f9fe79b:	and    r15,rcx
    72ee5f9fe79e:	or     r13,r15
    72ee5f9fe7a1:	mov    r15,QWORD PTR [rsp+0x68]
    72ee5f9fe7a6:	shr    r15,0x30
    72ee5f9fe7aa:	and    r15,0xffff
    72ee5f9fe7b1:	mov    ecx,0xffffffff
    72ee5f9fe7b6:	and    r15,rcx
    72ee5f9fe7b9:	shl    r15,0x20
    72ee5f9fe7bd:	or     r13,r15
    72ee5f9fe7c0:	mov    QWORD PTR [r12+0x180],rbp
    72ee5f9fe7c8:	mov    QWORD PTR [r12+0x188],r13
    72ee5f9fe7d0:	pxor   xmm0,xmm0
    72ee5f9fe7d4:	movdqa xmm6,xmm0
    72ee5f9fe7d8:	movdqa xmm0,xmm4
    72ee5f9fe7dc:	movdqa xmm1,xmm6
    72ee5f9fe7e0:	punpcklwd xmm0,xmm1
    72ee5f9fe7e4:	movdqa xmm7,xmm0
    72ee5f9fe7e8:	movdqa xmm0,xmm7
    72ee5f9fe7ec:	pslld  xmm0,0x10
    72ee5f9fe7f1:	movdqa xmm4,xmm0
    72ee5f9fe7f5:	pxor   xmm0,xmm0
    72ee5f9fe7f9:	movdqa xmm6,xmm0
    72ee5f9fe7fd:	movdqa xmm0,xmm2
    72ee5f9fe801:	movdqa xmm1,xmm6
    72ee5f9fe805:	punpckhwd xmm0,xmm1
    72ee5f9fe809:	movdqa xmm7,xmm0
    72ee5f9fe80d:	movdqa xmm0,xmm7
    72ee5f9fe811:	pslld  xmm0,0x10
    72ee5f9fe816:	movdqa xmm2,xmm0
    72ee5f9fe81a:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    72ee5f9fe824:	movdqa xmm1,xmm6
    72ee5f9fe828:	por    xmm3,xmm1
    72ee5f9fe82c:	movdqu XMMWORD PTR [r12+0x230],xmm3
    72ee5f9fe836:	mov    r13d,0x0
    72ee5f9fe83c:	mov    r15,r14
    72ee5f9fe83f:	and    r15,0xffff
    72ee5f9fe846:	shl    r15,0x8
    72ee5f9fe84a:	mov    ecx,0xffffffff
    72ee5f9fe84f:	and    r15,rcx
    72ee5f9fe852:	mov    rbp,r13
    72ee5f9fe855:	or     rbp,r15
    72ee5f9fe858:	mov    r15,r14
    72ee5f9fe85b:	shr    r15,0x10
    72ee5f9fe85f:	and    r15,0xffff
    72ee5f9fe866:	shl    r15,0x8
    72ee5f9fe86a:	mov    ecx,0xffffffff
    72ee5f9fe86f:	and    r15,rcx
    72ee5f9fe872:	shl    r15,0x20
    72ee5f9fe876:	or     rbp,r15
    72ee5f9fe879:	mov    r15,r14
    72ee5f9fe87c:	shr    r15,0x20
    72ee5f9fe880:	and    r15,0xffff
    72ee5f9fe887:	shl    r15,0x8
    72ee5f9fe88b:	mov    ecx,0xffffffff
    72ee5f9fe890:	and    r15,rcx
    72ee5f9fe893:	or     r13,r15
    72ee5f9fe896:	shr    r14,0x30
    72ee5f9fe89a:	and    r14,0xffff
    72ee5f9fe8a1:	shl    r14,0x8
    72ee5f9fe8a5:	mov    ecx,0xffffffff
    72ee5f9fe8aa:	and    r14,rcx
    72ee5f9fe8ad:	shl    r14,0x20
    72ee5f9fe8b1:	or     r13,r14
    72ee5f9fe8b4:	mov    QWORD PTR [r12+0x240],rbp
    72ee5f9fe8bc:	mov    QWORD PTR [r12+0x248],r13
    72ee5f9fe8c4:	mov    r13d,0x0
    72ee5f9fe8ca:	mov    r14,r8
    72ee5f9fe8cd:	and    r14,0xffff
    72ee5f9fe8d4:	shl    r14,0x8
    72ee5f9fe8d8:	mov    ecx,0xffffffff
    72ee5f9fe8dd:	and    r14,rcx
    72ee5f9fe8e0:	mov    r15,r13
    72ee5f9fe8e3:	or     r15,r14
    72ee5f9fe8e6:	mov    r14,r8
    72ee5f9fe8e9:	shr    r14,0x10
    72ee5f9fe8ed:	and    r14,0xffff
    72ee5f9fe8f4:	shl    r14,0x8
    72ee5f9fe8f8:	mov    ecx,0xffffffff
    72ee5f9fe8fd:	and    r14,rcx
    72ee5f9fe900:	shl    r14,0x20
    72ee5f9fe904:	or     r15,r14
    72ee5f9fe907:	mov    r14,r8
    72ee5f9fe90a:	shr    r14,0x20
    72ee5f9fe90e:	and    r14,0xffff
    72ee5f9fe915:	shl    r14,0x8
    72ee5f9fe919:	mov    ecx,0xffffffff
    72ee5f9fe91e:	and    r14,rcx
    72ee5f9fe921:	or     r13,r14
    72ee5f9fe924:	shr    r8,0x30
    72ee5f9fe928:	and    r8,0xffff
    72ee5f9fe92f:	shl    r8,0x8
    72ee5f9fe933:	mov    ecx,0xffffffff
    72ee5f9fe938:	and    r8,rcx
    72ee5f9fe93b:	shl    r8,0x20
    72ee5f9fe93f:	or     r13,r8
    72ee5f9fe942:	mov    QWORD PTR [r12+0x220],r15
    72ee5f9fe94a:	mov    QWORD PTR [r12+0x228],r13
    72ee5f9fe952:	mov    r13d,0x0
    72ee5f9fe958:	mov    r14,QWORD PTR [rsp+0x48]
    72ee5f9fe95d:	and    r14,0xffff
    72ee5f9fe964:	shl    r14,0x8
    72ee5f9fe968:	mov    ecx,0xffffffff
    72ee5f9fe96d:	and    r14,rcx
    72ee5f9fe970:	mov    r15,r13
    72ee5f9fe973:	or     r15,r14
    72ee5f9fe976:	mov    r14,QWORD PTR [rsp+0x48]
    72ee5f9fe97b:	shr    r14,0x10
    72ee5f9fe97f:	and    r14,0xffff
    72ee5f9fe986:	shl    r14,0x8
    72ee5f9fe98a:	mov    ecx,0xffffffff
    72ee5f9fe98f:	and    r14,rcx
    72ee5f9fe992:	shl    r14,0x20
    72ee5f9fe996:	or     r15,r14
    72ee5f9fe999:	mov    r14,QWORD PTR [rsp+0x48]
    72ee5f9fe99e:	shr    r14,0x20
    72ee5f9fe9a2:	and    r14,0xffff
    72ee5f9fe9a9:	shl    r14,0x8
    72ee5f9fe9ad:	mov    ecx,0xffffffff
    72ee5f9fe9b2:	and    r14,rcx
    72ee5f9fe9b5:	or     r13,r14
    72ee5f9fe9b8:	mov    r14,QWORD PTR [rsp+0x48]
    72ee5f9fe9bd:	shr    r14,0x30
    72ee5f9fe9c1:	and    r14,0xffff
    72ee5f9fe9c8:	shl    r14,0x8
    72ee5f9fe9cc:	mov    ecx,0xffffffff
    72ee5f9fe9d1:	and    r14,rcx
    72ee5f9fe9d4:	shl    r14,0x20
    72ee5f9fe9d8:	or     r13,r14
    72ee5f9fe9db:	mov    QWORD PTR [r12+0x160],r15
    72ee5f9fe9e3:	mov    QWORD PTR [r12+0x168],r13
    72ee5f9fe9eb:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    72ee5f9fe9f5:	movdqa xmm0,xmm6
    72ee5f9fe9f9:	pslld  xmm0,0x18
    72ee5f9fe9fe:	movdqa xmm7,xmm0
    72ee5f9fea02:	movdqu XMMWORD PTR [r12+0x170],xmm7
    72ee5f9fea0c:	movdqu xmm6,XMMWORD PTR [r12+0x270]
    72ee5f9fea16:	movdqa xmm0,xmm6
    72ee5f9fea1a:	pslld  xmm0,0x18
    72ee5f9fea1f:	movdqa xmm8,xmm0
    72ee5f9fea24:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    72ee5f9fea2e:	movdqa xmm0,xmm6
    72ee5f9fea32:	pslld  xmm0,0x18
    72ee5f9fea37:	movdqa xmm9,xmm0
    72ee5f9fea3c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    72ee5f9fea46:	mov    r13d,0x0
    72ee5f9fea4c:	mov    r14,QWORD PTR [rsp+0x78]
    72ee5f9fea51:	and    r14,0xffff
    72ee5f9fea58:	mov    ecx,0xffffffff
    72ee5f9fea5d:	and    r14,rcx
    72ee5f9fea60:	mov    r15,r13
    72ee5f9fea63:	or     r15,r14
    72ee5f9fea66:	mov    r14,QWORD PTR [rsp+0x78]
    72ee5f9fea6b:	shr    r14,0x10
    72ee5f9fea6f:	and    r14,0xffff
    72ee5f9fea76:	mov    ecx,0xffffffff
    72ee5f9fea7b:	and    r14,rcx
    72ee5f9fea7e:	shl    r14,0x20
    72ee5f9fea82:	or     r15,r14
    72ee5f9fea85:	mov    r14,QWORD PTR [rsp+0x78]
    72ee5f9fea8a:	shr    r14,0x20
    72ee5f9fea8e:	and    r14,0xffff
    72ee5f9fea95:	mov    ecx,0xffffffff
    72ee5f9fea9a:	and    r14,rcx
    72ee5f9fea9d:	or     r13,r14
    72ee5f9feaa0:	mov    r14,QWORD PTR [rsp+0x78]
    72ee5f9feaa5:	shr    r14,0x30
    72ee5f9feaa9:	and    r14,0xffff
    72ee5f9feab0:	mov    ecx,0xffffffff
    72ee5f9feab5:	and    r14,rcx
    72ee5f9feab8:	shl    r14,0x20
    72ee5f9feabc:	or     r13,r14
    72ee5f9feabf:	mov    QWORD PTR [r12+0x140],r15
    72ee5f9feac7:	mov    QWORD PTR [r12+0x148],r13
    72ee5f9feacf:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    72ee5f9fead9:	movdqa xmm1,xmm6
    72ee5f9feadd:	por    xmm5,xmm1
    72ee5f9feae1:	movdqu xmm6,XMMWORD PTR [r12+0x220]
    72ee5f9feaeb:	movdqa xmm1,xmm6
    72ee5f9feaef:	por    xmm4,xmm1
    72ee5f9feaf3:	movdqu XMMWORD PTR [r12+0x210],xmm4
    72ee5f9feafd:	movdqu xmm6,XMMWORD PTR [r12+0x260]
    72ee5f9feb07:	movdqa xmm0,xmm6
    72ee5f9feb0b:	pslld  xmm0,0x18
    72ee5f9feb10:	movdqa xmm10,xmm0
    72ee5f9feb15:	movdqu XMMWORD PTR [r12+0x220],xmm10
    72ee5f9feb1f:	movdqu xmm6,XMMWORD PTR [r12+0x160]
    72ee5f9feb29:	movdqa xmm1,xmm6
    72ee5f9feb2d:	por    xmm2,xmm1
    72ee5f9feb31:	movdqa xmm1,xmm7
    72ee5f9feb35:	por    xmm3,xmm1
    72ee5f9feb39:	movdqu XMMWORD PTR [r12+0x160],xmm3
    72ee5f9feb43:	mov    r13d,0x0
    72ee5f9feb49:	mov    r14,QWORD PTR [rsp+0x88]
    72ee5f9feb51:	and    r14,0xffff
    72ee5f9feb58:	mov    ecx,0xffffffff
    72ee5f9feb5d:	and    r14,rcx
    72ee5f9feb60:	mov    r15,r13
    72ee5f9feb63:	or     r15,r14
    72ee5f9feb66:	mov    r14,QWORD PTR [rsp+0x88]
    72ee5f9feb6e:	shr    r14,0x10
    72ee5f9feb72:	and    r14,0xffff
    72ee5f9feb79:	mov    ecx,0xffffffff
    72ee5f9feb7e:	and    r14,rcx
    72ee5f9feb81:	shl    r14,0x20
    72ee5f9feb85:	or     r15,r14
    72ee5f9feb88:	mov    r14,QWORD PTR [rsp+0x88]
    72ee5f9feb90:	shr    r14,0x20
    72ee5f9feb94:	and    r14,0xffff
    72ee5f9feb9b:	mov    ecx,0xffffffff
    72ee5f9feba0:	and    r14,rcx
    72ee5f9feba3:	or     r13,r14
    72ee5f9feba6:	mov    r14,QWORD PTR [rsp+0x88]
    72ee5f9febae:	shr    r14,0x30
    72ee5f9febb2:	and    r14,0xffff
    72ee5f9febb9:	mov    ecx,0xffffffff
    72ee5f9febbe:	and    r14,rcx
    72ee5f9febc1:	shl    r14,0x20
    72ee5f9febc5:	or     r13,r14
    72ee5f9febc8:	mov    QWORD PTR [r12+0x170],r15
    72ee5f9febd0:	mov    QWORD PTR [r12+0x178],r13
    72ee5f9febd8:	mov    r13d,0x0
    72ee5f9febde:	mov    r14,QWORD PTR [rsp+0x80]
    72ee5f9febe6:	and    r14,0xffff
    72ee5f9febed:	mov    ecx,0xffffffff
    72ee5f9febf2:	and    r14,rcx
    72ee5f9febf5:	mov    r15,r13
    72ee5f9febf8:	or     r15,r14
    72ee5f9febfb:	mov    r14,QWORD PTR [rsp+0x80]
    72ee5f9fec03:	shr    r14,0x10
    72ee5f9fec07:	and    r14,0xffff
    72ee5f9fec0e:	mov    ecx,0xffffffff
    72ee5f9fec13:	and    r14,rcx
    72ee5f9fec16:	shl    r14,0x20
    72ee5f9fec1a:	or     r15,r14
    72ee5f9fec1d:	mov    r14,QWORD PTR [rsp+0x80]
    72ee5f9fec25:	shr    r14,0x20
    72ee5f9fec29:	and    r14,0xffff
    72ee5f9fec30:	mov    ecx,0xffffffff
    72ee5f9fec35:	and    r14,rcx
    72ee5f9fec38:	or     r13,r14
    72ee5f9fec3b:	mov    r14,QWORD PTR [rsp+0x80]
    72ee5f9fec43:	shr    r14,0x30
    72ee5f9fec47:	and    r14,0xffff
    72ee5f9fec4e:	mov    ecx,0xffffffff
    72ee5f9fec53:	and    r14,rcx
    72ee5f9fec56:	shl    r14,0x20
    72ee5f9fec5a:	or     r13,r14
    72ee5f9fec5d:	mov    QWORD PTR [r12+0x110],r15
    72ee5f9fec65:	mov    QWORD PTR [r12+0x118],r13
    72ee5f9fec6d:	movdqa xmm1,xmm8
    72ee5f9fec72:	por    xmm5,xmm1
    72ee5f9fec76:	movdqa xmm1,xmm9
    72ee5f9fec7b:	por    xmm4,xmm1
    72ee5f9fec7f:	mov    r13d,0x0
    72ee5f9fec85:	mov    r14,QWORD PTR [rsp+0x70]
    72ee5f9fec8a:	and    r14,0xffff
    72ee5f9fec91:	mov    ecx,0xffffffff
    72ee5f9fec96:	and    r14,rcx
    72ee5f9fec99:	mov    r15,r13
    72ee5f9fec9c:	or     r15,r14
    72ee5f9fec9f:	mov    r14,QWORD PTR [rsp+0x70]
    72ee5f9feca4:	shr    r14,0x10
    72ee5f9feca8:	and    r14,0xffff
    72ee5f9fecaf:	mov    ecx,0xffffffff
    72ee5f9fecb4:	and    r14,rcx
    72ee5f9fecb7:	shl    r14,0x20
    72ee5f9fecbb:	or     r15,r14
    72ee5f9fecbe:	mov    r14,QWORD PTR [rsp+0x70]
    72ee5f9fecc3:	shr    r14,0x20
    72ee5f9fecc7:	and    r14,0xffff
    72ee5f9fecce:	mov    ecx,0xffffffff
    72ee5f9fecd3:	and    r14,rcx
    72ee5f9fecd6:	or     r13,r14
    72ee5f9fecd9:	mov    r14,QWORD PTR [rsp+0x70]
    72ee5f9fecde:	shr    r14,0x30
    72ee5f9fece2:	and    r14,0xffff
    72ee5f9fece9:	mov    ecx,0xffffffff
    72ee5f9fecee:	and    r14,rcx
    72ee5f9fecf1:	shl    r14,0x20
    72ee5f9fecf5:	or     r13,r14
    72ee5f9fecf8:	mov    QWORD PTR [r12+0x180],r15
    72ee5f9fed00:	mov    QWORD PTR [r12+0x188],r13
    72ee5f9fed08:	movdqa xmm1,xmm10
    72ee5f9fed0d:	por    xmm2,xmm1
    72ee5f9fed11:	movdqu XMMWORD PTR [r12+0x150],xmm2
    72ee5f9fed1b:	movdqu xmm6,XMMWORD PTR [r12+0x140]
    72ee5f9fed25:	movdqa xmm1,xmm6
    72ee5f9fed29:	por    xmm3,xmm1
    72ee5f9fed2d:	movdqu XMMWORD PTR [r12+0x140],xmm3
    72ee5f9fed37:	movdqu xmm6,XMMWORD PTR [r12+0x110]
    72ee5f9fed41:	movdqa xmm1,xmm6
    72ee5f9fed45:	por    xmm4,xmm1
    72ee5f9fed49:	movdqu XMMWORD PTR [r12+0x110],xmm4
    72ee5f9fed53:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    72ee5f9fed5d:	movdqa xmm1,xmm6
    72ee5f9fed61:	por    xmm5,xmm1
    72ee5f9fed65:	movdqu XMMWORD PTR [r12+0x120],xmm5
    72ee5f9fed6f:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    72ee5f9fed79:	movdqa xmm1,xmm6
    72ee5f9fed7d:	por    xmm2,xmm1
    72ee5f9fed81:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72ee5f9fed8b:	mov    r13,QWORD PTR [r12+0xf8]
    72ee5f9fed93:	mov    r14,r13
    72ee5f9fed96:	add    r14,0x20
    72ee5f9fed9a:	mov    r15,r14
    72ee5f9fed9d:	add    r15,0x10
    72ee5f9feda1:	movdqu XMMWORD PTR [r14],xmm4
    72ee5f9feda6:	mov    r14d,0x0
    72ee5f9fedac:	mov    DWORD PTR [r12+0x32c],r14d
    72ee5f9fedb4:	movdqu XMMWORD PTR [r15],xmm5
    72ee5f9fedb9:	mov    r14,r13
    72ee5f9fedbc:	add    r14,0x10
    72ee5f9fedc0:	movdqu XMMWORD PTR [r13+0x0],xmm3
    72ee5f9fedc6:	movdqu XMMWORD PTR [r14],xmm2
    72ee5f9fedcb:	mov    r14d,DWORD PTR [r13+0x0]
    72ee5f9fedcf:	mov    QWORD PTR [r12+0x60],r14
    72ee5f9fedd4:	jmp    0x72ee5f9fedd9
    72ee5f9fedd9:	mov    r13,QWORD PTR [r12+0x58]
    72ee5f9fedde:	mov    r14,QWORD PTR [r12+0x48]
    72ee5f9fede3:	add    r14,r13
    72ee5f9fede6:	mov    QWORD PTR [r12+0x68],r14
    72ee5f9fedeb:	add    r13,0x4
    72ee5f9fedef:	mov    QWORD PTR [r12+0x58],r13
    72ee5f9fedf4:	mov    r15,r14
    72ee5f9fedf7:	add    r15,0x4
    72ee5f9fedfb:	mov    eax,DWORD PTR [r15]
    72ee5f9fedfe:	mov    QWORD PTR [r12+0x70],rax
    72ee5f9fee03:	mov    r15,r14
    72ee5f9fee06:	add    r15,0x38
    72ee5f9fee0a:	mov    r8d,DWORD PTR [r15]
    72ee5f9fee0d:	mov    QWORD PTR [r12+0x78],r8
    72ee5f9fee12:	mov    r15,r14
    72ee5f9fee15:	add    r15,0x24
    72ee5f9fee19:	mov    r9d,DWORD PTR [r15]
    72ee5f9fee1c:	mov    QWORD PTR [r12+0x90],r9
    72ee5f9fee24:	sub    r13,0xc0
    72ee5f9fee2b:	setne  BYTE PTR [rsp+0xb8]
    72ee5f9fee33:	mov    r11,rax
    72ee5f9fee36:	lahf
    72ee5f9fee37:	seto   al
    72ee5f9fee3a:	mov    WORD PTR [rsp+0xb0],ax
    72ee5f9fee42:	mov    rax,r11
    72ee5f9fee45:	mov    r13d,DWORD PTR [r12+0x70]
    72ee5f9fee4a:	mov    r13d,r13d
    72ee5f9fee4d:	mov    r13d,r13d
    72ee5f9fee50:	ror    r13d,0x7
    72ee5f9fee54:	mov    QWORD PTR [r12+0x80],r13
    72ee5f9fee5c:	mov    r15d,r8d
    72ee5f9fee5f:	mov    r15d,r15d
    72ee5f9fee62:	ror    r15d,0x11
    72ee5f9fee66:	mov    QWORD PTR [r12+0x88],r15
    72ee5f9fee6e:	mov    ebp,DWORD PTR [r12+0x60]
    72ee5f9fee73:	add    r9d,ebp
    72ee5f9fee76:	mov    QWORD PTR [r12+0x60],r9
    72ee5f9fee7b:	mov    ebp,DWORD PTR [r12+0x70]
    72ee5f9fee80:	mov    ebp,ebp
    72ee5f9fee82:	mov    ebp,ebp
    72ee5f9fee84:	ror    ebp,0x12
    72ee5f9fee87:	xor    r13d,ebp
    72ee5f9fee8a:	mov    QWORD PTR [r12+0x80],r13
    72ee5f9fee92:	mov    ebp,r8d
    72ee5f9fee95:	mov    ebp,ebp
    72ee5f9fee97:	ror    ebp,0x13
    72ee5f9fee9a:	xor    r15d,ebp
    72ee5f9fee9d:	mov    QWORD PTR [r12+0x88],r15
    72ee5f9feea5:	mov    ebp,DWORD PTR [r12+0x70]
    72ee5f9feeaa:	mov    ebp,ebp
    72ee5f9feeac:	mov    ebp,ebp
    72ee5f9feeae:	shr    ebp,0x3
    72ee5f9feeb1:	xor    r13d,ebp
    72ee5f9feeb4:	mov    QWORD PTR [r12+0x80],r13
    72ee5f9feebc:	mov    r8d,r8d
    72ee5f9feebf:	shr    r8d,0xa
    72ee5f9feec3:	xor    r15d,r8d
    72ee5f9feec6:	mov    QWORD PTR [r12+0x78],r15
    72ee5f9feecb:	add    r9d,r13d
    72ee5f9feece:	mov    QWORD PTR [r12+0x60],r9
    72ee5f9feed3:	add    r9d,r15d
    72ee5f9feed6:	mov    QWORD PTR [r12+0x60],r9
    72ee5f9feedb:	add    r14,0x40
    72ee5f9feedf:	mov    DWORD PTR [r14],r9d
    72ee5f9feee2:	mov    r13d,0x0
    72ee5f9feee8:	mov    DWORD PTR [r12+0x32c],r13d
    72ee5f9feef0:	mov    r13d,0x0
    72ee5f9feef6:	mov    ecx,DWORD PTR [r12+0x70]
    72ee5f9feefb:	mov    ecx,ecx
    72ee5f9feefd:	mov    r14d,r13d
    72ee5f9fef00:	or     r14d,ecx
    72ee5f9fef03:	mov    QWORD PTR [r12+0x60],r14
    72ee5f9fef08:	mov    rcx,QWORD PTR [r12+0x380]
    72ee5f9fef10:	jrcxz  0x72ee5f9fef17
    72ee5f9fef12:	jmp    0x72ee5f9ff6fa
    72ee5f9fef17:	cmp    BYTE PTR [rsp+0xb8],0x0
    72ee5f9fef1f:	jne    0x72ee5f9fedd9
    72ee5f9fef25:	jmp    0x72ee5f9fef2a
    72ee5f9fef2a:	mov    r13,QWORD PTR [r12]
    72ee5f9fef2e:	mov    r14,r13
    72ee5f9fef31:	add    r14,0x4
    72ee5f9fef35:	mov    r15d,DWORD PTR [r13+0x0]
    72ee5f9fef39:	mov    ebp,DWORD PTR [r14]
    72ee5f9fef3c:	mov    QWORD PTR [r12+0x78],r15
    72ee5f9fef41:	mov    QWORD PTR [r12+0x80],rbp
    72ee5f9fef49:	mov    r14,r13
    72ee5f9fef4c:	add    r14,0x8
    72ee5f9fef50:	mov    r8,r14
    72ee5f9fef53:	add    r8,0x4
    72ee5f9fef57:	mov    r9d,DWORD PTR [r14]
    72ee5f9fef5a:	mov    eax,DWORD PTR [r8]
    72ee5f9fef5d:	mov    QWORD PTR [rsp+0x90],rax
    72ee5f9fef65:	mov    QWORD PTR [r12+0x70],r9
    72ee5f9fef6a:	mov    rax,QWORD PTR [rsp+0x90]
    72ee5f9fef72:	mov    QWORD PTR [r12+0x68],rax
    72ee5f9fef77:	mov    r8,r13
    72ee5f9fef7a:	add    r8,0x18
    72ee5f9fef7e:	mov    r14,r8
    72ee5f9fef81:	add    r14,0x4
    72ee5f9fef85:	mov    eax,DWORD PTR [r8]
    72ee5f9fef88:	mov    QWORD PTR [rsp+0x98],rax
    72ee5f9fef90:	mov    r8d,DWORD PTR [r14]
    72ee5f9fef93:	mov    rax,QWORD PTR [rsp+0x98]
    72ee5f9fef9b:	mov    QWORD PTR [r12+0x58],rax
    72ee5f9fefa0:	mov    QWORD PTR [r12+0x60],r8
    72ee5f9fefa5:	add    r13,0x10
    72ee5f9fefa9:	mov    r14,r13
    72ee5f9fefac:	add    r14,0x4
    72ee5f9fefb0:	mov    eax,DWORD PTR [r13+0x0]
    72ee5f9fefb4:	mov    QWORD PTR [rsp+0xa0],rax
    72ee5f9fefbc:	mov    eax,DWORD PTR [r14]
    72ee5f9fefbf:	mov    QWORD PTR [rsp+0xa8],rax
    72ee5f9fefc7:	mov    rax,QWORD PTR [rsp+0xa0]
    72ee5f9fefcf:	mov    QWORD PTR [r12+0x18],rax
    72ee5f9fefd4:	mov    rax,QWORD PTR [rsp+0xa8]
    72ee5f9fefdc:	mov    QWORD PTR [r12+0x90],rax
    72ee5f9fefe4:	mov    r14d,0x0
    72ee5f9fefea:	mov    QWORD PTR [r12+0x88],r14
    72ee5f9feff2:	mov    r14d,0x0
    72ee5f9feff8:	mov    r13d,r14d
    72ee5f9feffb:	or     r13d,r15d
    72ee5f9feffe:	mov    QWORD PTR [r12+0xa8],r13
    72ee5f9ff006:	mov    r13d,0x0
    72ee5f9ff00c:	mov    r14d,r13d
    72ee5f9ff00f:	or     r14d,ebp
    72ee5f9ff012:	mov    QWORD PTR [r12+0x38],r14
    72ee5f9ff017:	mov    r13d,0x0
    72ee5f9ff01d:	mov    r14d,r13d
    72ee5f9ff020:	or     r14d,r9d
    72ee5f9ff023:	mov    QWORD PTR [r12+0x98],r14
    72ee5f9ff02b:	mov    r13d,0x0
    72ee5f9ff031:	mov    ecx,DWORD PTR [rsp+0x90]
    72ee5f9ff038:	mov    r14d,r13d
    72ee5f9ff03b:	or     r14d,ecx
    72ee5f9ff03e:	mov    QWORD PTR [r12+0x28],r14
    72ee5f9ff043:	mov    r13d,0x0
    72ee5f9ff049:	mov    r14d,r13d
    72ee5f9ff04c:	or     r14d,r8d
    72ee5f9ff04f:	mov    QWORD PTR [r12+0xb0],r14
    72ee5f9ff057:	mov    r13d,0x0
    72ee5f9ff05d:	mov    ecx,DWORD PTR [rsp+0x98]
    72ee5f9ff064:	mov    r14d,r13d
    72ee5f9ff067:	or     r14d,ecx
    72ee5f9ff06a:	mov    QWORD PTR [r12+0xc0],r14
    72ee5f9ff072:	mov    r13d,0x0
    72ee5f9ff078:	mov    ecx,DWORD PTR [rsp+0xa8]
    72ee5f9ff07f:	mov    r14d,r13d
    72ee5f9ff082:	or     r14d,ecx
    72ee5f9ff085:	mov    QWORD PTR [r12+0xc8],r14
    72ee5f9ff08d:	mov    r13d,0x0
    72ee5f9ff093:	mov    ecx,DWORD PTR [rsp+0xa0]
    72ee5f9ff09a:	mov    r14d,r13d
    72ee5f9ff09d:	or     r14d,ecx
    72ee5f9ff0a0:	mov    QWORD PTR [r12+0xb8],r14
    72ee5f9ff0a8:	jmp    0x72ee5f9ff0ad
    72ee5f9ff0ad:	mov    r13d,0x0
    72ee5f9ff0b3:	mov    r14d,DWORD PTR [r12+0xb8]
    72ee5f9ff0bb:	mov    eax,r13d
    72ee5f9ff0be:	or     eax,r14d
    72ee5f9ff0c1:	mov    QWORD PTR [r12+0x30],rax
    72ee5f9ff0c6:	mov    r13d,0x0
    72ee5f9ff0cc:	mov    ebp,DWORD PTR [r12+0xc0]
    72ee5f9ff0d4:	mov    eax,r13d
    72ee5f9ff0d7:	or     eax,ebp
    72ee5f9ff0d9:	mov    QWORD PTR [r12+0xa0],rax
    72ee5f9ff0e1:	mov    r13d,0x0
    72ee5f9ff0e7:	mov    ebp,DWORD PTR [r12+0x28]
    72ee5f9ff0ec:	mov    eax,r13d
    72ee5f9ff0ef:	or     eax,ebp
    72ee5f9ff0f1:	mov    QWORD PTR [r12+0xc0],rax
    72ee5f9ff0f9:	mov    r13d,0x0
    72ee5f9ff0ff:	mov    ebp,DWORD PTR [r12+0x98]
    72ee5f9ff107:	mov    eax,r13d
    72ee5f9ff10a:	or     eax,ebp
    72ee5f9ff10c:	mov    QWORD PTR [r12+0x28],rax
    72ee5f9ff111:	mov    r13d,0x0
    72ee5f9ff117:	mov    ebp,DWORD PTR [r12+0x38]
    72ee5f9ff11c:	mov    eax,r13d
    72ee5f9ff11f:	or     eax,ebp
    72ee5f9ff121:	mov    QWORD PTR [r12+0x98],rax
    72ee5f9ff129:	mov    r13d,0x0
    72ee5f9ff12f:	mov    ebp,DWORD PTR [r12+0xa8]
    72ee5f9ff137:	mov    eax,r13d
    72ee5f9ff13a:	or     eax,ebp
    72ee5f9ff13c:	mov    QWORD PTR [r12+0x38],rax
    72ee5f9ff141:	mov    r14d,r14d
    72ee5f9ff144:	ror    r14d,0x6
    72ee5f9ff148:	mov    QWORD PTR [r12+0xb8],r14
    72ee5f9ff150:	mov    r13d,DWORD PTR [r12+0xc8]
    72ee5f9ff158:	mov    ebp,DWORD PTR [r12+0x30]
    72ee5f9ff15d:	mov    ebp,ebp
    72ee5f9ff15f:	and    ebp,r13d
    72ee5f9ff162:	mov    QWORD PTR [r12+0xa8],rbp
    72ee5f9ff16a:	mov    r9d,DWORD PTR [r12+0x38]
    72ee5f9ff16f:	mov    r9d,r9d
    72ee5f9ff172:	mov    r9d,r9d
    72ee5f9ff175:	ror    r9d,0x2
    72ee5f9ff179:	mov    QWORD PTR [r12+0xd0],r9
    72ee5f9ff181:	mov    r15d,0x0
    72ee5f9ff187:	mov    eax,r15d
    72ee5f9ff18a:	or     eax,r13d
    72ee5f9ff18d:	mov    QWORD PTR [r12+0x20],rax
    72ee5f9ff192:	mov    rax,QWORD PTR [r12+0x88]
    72ee5f9ff19a:	mov    r15,QWORD PTR [r12+0x50]
    72ee5f9ff19f:	mov    rcx,QWORD PTR [r12+0x88]
    72ee5f9ff1a7:	add    r15,rcx
    72ee5f9ff1aa:	mov    r13d,DWORD PTR [r15]
    72ee5f9ff1ad:	mov    QWORD PTR [r12+0xc8],r13
    72ee5f9ff1b5:	mov    ecx,DWORD PTR [r12+0x30]
    72ee5f9ff1ba:	mov    ecx,ecx
    72ee5f9ff1bc:	mov    r15d,DWORD PTR [r12+0xa0]
    72ee5f9ff1c4:	mov    r15d,r15d
    72ee5f9ff1c7:	not    rcx
    72ee5f9ff1ca:	and    r15d,ecx
    72ee5f9ff1cd:	mov    QWORD PTR [r12+0xd8],r15
    72ee5f9ff1d5:	mov    r8d,DWORD PTR [r12+0xb0]
    72ee5f9ff1dd:	add    ebp,r8d
    72ee5f9ff1e0:	mov    QWORD PTR [r12+0xa8],rbp
    72ee5f9ff1e8:	mov    r8d,DWORD PTR [r12+0x30]
    72ee5f9ff1ed:	mov    r8d,r8d
    72ee5f9ff1f0:	mov    r8d,r8d
    72ee5f9ff1f3:	ror    r8d,0xb
    72ee5f9ff1f7:	xor    r14d,r8d
    72ee5f9ff1fa:	mov    QWORD PTR [r12+0xb0],r14
    72ee5f9ff202:	mov    r8d,DWORD PTR [r12+0x38]
    72ee5f9ff207:	mov    r8d,r8d
    72ee5f9ff20a:	mov    r8d,r8d
    72ee5f9ff20d:	ror    r8d,0xd
    72ee5f9ff211:	xor    r9d,r8d
    72ee5f9ff214:	mov    QWORD PTR [r12+0xd0],r9
    72ee5f9ff21c:	add    ebp,r15d
    72ee5f9ff21f:	mov    QWORD PTR [r12+0xa8],rbp
    72ee5f9ff227:	mov    r15,QWORD PTR [r12+0x48]
    72ee5f9ff22c:	mov    rcx,QWORD PTR [r12+0x88]
    72ee5f9ff234:	add    r15,rcx
    72ee5f9ff237:	mov    r8d,DWORD PTR [r15]
    72ee5f9ff23a:	mov    QWORD PTR [r12+0xb8],r8
    72ee5f9ff242:	mov    ecx,DWORD PTR [r12+0x98]
    72ee5f9ff24a:	mov    ecx,ecx
    72ee5f9ff24c:	mov    eax,DWORD PTR [r12+0x28]
    72ee5f9ff251:	mov    eax,eax
    72ee5f9ff253:	and    eax,ecx
    72ee5f9ff255:	mov    QWORD PTR [r12+0xd8],rax
    72ee5f9ff25d:	add    ebp,r13d
    72ee5f9ff260:	mov    QWORD PTR [r12+0xa8],rbp
    72ee5f9ff268:	mov    ecx,DWORD PTR [r12+0x98]
    72ee5f9ff270:	mov    ecx,ecx
    72ee5f9ff272:	mov    r13d,DWORD PTR [r12+0x28]
    72ee5f9ff277:	mov    r13d,r13d
    72ee5f9ff27a:	xor    r13d,ecx
    72ee5f9ff27d:	mov    QWORD PTR [r12+0xc8],r13
    72ee5f9ff285:	mov    r15d,DWORD PTR [r12+0x30]
    72ee5f9ff28a:	mov    r15d,r15d
    72ee5f9ff28d:	mov    r15d,r15d
    72ee5f9ff290:	ror    r15d,0x19
    72ee5f9ff294:	xor    r14d,r15d
    72ee5f9ff297:	mov    QWORD PTR [r12+0xb0],r14
    72ee5f9ff29f:	mov    ecx,DWORD PTR [r12+0x38]
    72ee5f9ff2a4:	mov    ecx,ecx
    72ee5f9ff2a6:	and    r13d,ecx
    72ee5f9ff2a9:	mov    QWORD PTR [r12+0xc8],r13
    72ee5f9ff2b1:	mov    r15d,DWORD PTR [r12+0x38]
    72ee5f9ff2b6:	mov    r15d,r15d
    72ee5f9ff2b9:	mov    r15d,r15d
    72ee5f9ff2bc:	ror    r15d,0x16
    72ee5f9ff2c0:	xor    r9d,r15d
    72ee5f9ff2c3:	mov    QWORD PTR [r12+0xd0],r9
    72ee5f9ff2cb:	add    ebp,r8d
    72ee5f9ff2ce:	mov    QWORD PTR [r12+0xa8],rbp
    72ee5f9ff2d6:	mov    ecx,DWORD PTR [r12+0xd8]
    72ee5f9ff2de:	mov    ecx,ecx
    72ee5f9ff2e0:	xor    r13d,ecx
    72ee5f9ff2e3:	mov    QWORD PTR [r12+0xb8],r13
    72ee5f9ff2eb:	add    ebp,r14d
    72ee5f9ff2ee:	mov    QWORD PTR [r12+0xa8],rbp
    72ee5f9ff2f6:	mov    r14,QWORD PTR [r12+0x88]
    72ee5f9ff2fe:	add    r14,0x4
    72ee5f9ff302:	mov    QWORD PTR [r12+0x88],r14
    72ee5f9ff30a:	add    r13d,r9d
    72ee5f9ff30d:	mov    QWORD PTR [r12+0xb0],r13
    72ee5f9ff315:	mov    ecx,DWORD PTR [r12+0xc0]
    72ee5f9ff31d:	mov    ecx,ecx
    72ee5f9ff31f:	mov    r15d,ebp
    72ee5f9ff322:	add    r15d,ecx
    72ee5f9ff325:	mov    QWORD PTR [r12+0xb8],r15
    72ee5f9ff32d:	sub    r14,0x100
    72ee5f9ff334:	setne  BYTE PTR [rsp+0xb8]
    72ee5f9ff33c:	mov    r11,rax
    72ee5f9ff33f:	lahf
    72ee5f9ff340:	seto   al
    72ee5f9ff343:	mov    WORD PTR [rsp+0xb0],ax
    72ee5f9ff34b:	mov    rax,r11
    72ee5f9ff34e:	add    r13d,ebp
    72ee5f9ff351:	mov    QWORD PTR [r12+0xa8],r13
    72ee5f9ff359:	mov    r13d,0x0
    72ee5f9ff35f:	mov    ecx,DWORD PTR [r12+0xa0]
    72ee5f9ff367:	mov    ecx,ecx
    72ee5f9ff369:	mov    r14d,r13d
    72ee5f9ff36c:	or     r14d,ecx
    72ee5f9ff36f:	mov    QWORD PTR [r12+0xb0],r14
    72ee5f9ff377:	mov    r13d,0x0
    72ee5f9ff37d:	mov    ecx,DWORD PTR [r12+0x20]
    72ee5f9ff382:	mov    ecx,ecx
    72ee5f9ff384:	mov    r14d,r13d
    72ee5f9ff387:	or     r14d,ecx
    72ee5f9ff38a:	mov    QWORD PTR [r12+0xc0],r14
    72ee5f9ff392:	mov    r13d,0x0
    72ee5f9ff398:	mov    ecx,DWORD PTR [r12+0x30]
    72ee5f9ff39d:	mov    ecx,ecx
    72ee5f9ff39f:	mov    r14d,r13d
    72ee5f9ff3a2:	or     r14d,ecx
    72ee5f9ff3a5:	mov    QWORD PTR [r12+0xc8],r14
    72ee5f9ff3ad:	mov    rcx,QWORD PTR [r12+0x380]
    72ee5f9ff3b5:	jrcxz  0x72ee5f9ff3bc
    72ee5f9ff3b7:	jmp    0x72ee5f9ff782
    72ee5f9ff3bc:	cmp    BYTE PTR [rsp+0xb8],0x0
    72ee5f9ff3c4:	jne    0x72ee5f9ff0ad
    72ee5f9ff3ca:	jmp    0x72ee5f9ff3cf
    72ee5f9ff3cf:	mov    r13d,DWORD PTR [r12+0x70]
    72ee5f9ff3d4:	mov    r14d,DWORD PTR [r12+0x98]
    72ee5f9ff3dc:	add    r14d,r13d
    72ee5f9ff3df:	mov    QWORD PTR [r12+0x70],r14
    72ee5f9ff3e4:	mov    r13d,DWORD PTR [r12+0x68]
    72ee5f9ff3e9:	mov    r15d,DWORD PTR [r12+0x28]
    72ee5f9ff3ee:	add    r15d,r13d
    72ee5f9ff3f1:	mov    QWORD PTR [r12+0x68],r15
    72ee5f9ff3f6:	mov    r13d,0x0
    72ee5f9ff3fc:	mov    QWORD PTR [r12+0x88],r13
    72ee5f9ff404:	mov    r13d,DWORD PTR [r12+0x78]
    72ee5f9ff409:	mov    ebp,DWORD PTR [r12+0xa8]
    72ee5f9ff411:	add    ebp,r13d
    72ee5f9ff414:	mov    QWORD PTR [r12+0x78],rbp
    72ee5f9ff419:	mov    r13d,DWORD PTR [r12+0x80]
    72ee5f9ff421:	mov    r8d,DWORD PTR [r12+0x38]
    72ee5f9ff426:	add    r8d,r13d
    72ee5f9ff429:	mov    QWORD PTR [r12+0x80],r8
    72ee5f9ff431:	mov    rax,QWORD PTR [r12]
    72ee5f9ff435:	mov    r9,QWORD PTR [r12]
    72ee5f9ff439:	add    r9,0x8
    72ee5f9ff43d:	mov    r13,r9
    72ee5f9ff440:	add    r13,0x4
    72ee5f9ff444:	mov    DWORD PTR [r9],r14d
    72ee5f9ff447:	mov    r14d,0x0
    72ee5f9ff44d:	mov    DWORD PTR [r12+0x32c],r14d
    72ee5f9ff455:	mov    DWORD PTR [r13+0x0],r15d
    72ee5f9ff459:	mov    r13d,DWORD PTR [r12+0x18]
    72ee5f9ff45e:	mov    r14d,DWORD PTR [r12+0xb8]
    72ee5f9ff466:	add    r14d,r13d
    72ee5f9ff469:	mov    QWORD PTR [r12+0x68],r14
    72ee5f9ff46e:	mov    r13d,DWORD PTR [r12+0x90]
    72ee5f9ff476:	mov    r15d,DWORD PTR [r12+0x30]
    72ee5f9ff47b:	add    r15d,r13d
    72ee5f9ff47e:	mov    QWORD PTR [r12+0x70],r15
    72ee5f9ff483:	mov    r13d,DWORD PTR [r12+0x58]
    72ee5f9ff488:	mov    r9d,DWORD PTR [r12+0x20]
    72ee5f9ff48d:	mov    eax,r9d
    72ee5f9ff490:	add    eax,r13d
    72ee5f9ff493:	mov    QWORD PTR [r12+0x58],rax
    72ee5f9ff498:	mov    r13d,DWORD PTR [r12+0x60]
    72ee5f9ff49d:	mov    r9d,DWORD PTR [r12+0xa0]
    72ee5f9ff4a5:	add    r9d,r13d
    72ee5f9ff4a8:	mov    QWORD PTR [r12+0x60],r9
    72ee5f9ff4ad:	mov    r13,QWORD PTR [r12]
    72ee5f9ff4b1:	add    r13,0x4
    72ee5f9ff4b5:	mov    rdi,QWORD PTR [r12]
    72ee5f9ff4b9:	mov    DWORD PTR [rdi],ebp
    72ee5f9ff4bb:	mov    DWORD PTR [r13+0x0],r8d
    72ee5f9ff4bf:	mov    r13,QWORD PTR [r12]
    72ee5f9ff4c3:	add    r13,0x10
    72ee5f9ff4c7:	mov    rbp,r13
    72ee5f9ff4ca:	add    rbp,0x4
    72ee5f9ff4ce:	mov    DWORD PTR [r13+0x0],r14d
    72ee5f9ff4d2:	mov    DWORD PTR [rbp+0x0],r15d
    72ee5f9ff4d6:	mov    r13,QWORD PTR [r12]
    72ee5f9ff4da:	add    r13,0x18
    72ee5f9ff4de:	mov    r14,r13
    72ee5f9ff4e1:	add    r14,0x4
    72ee5f9ff4e5:	mov    eax,DWORD PTR [r12+0x58]
    72ee5f9ff4ea:	mov    DWORD PTR [r13+0x0],eax
    72ee5f9ff4ee:	mov    DWORD PTR [r14],r9d
    72ee5f9ff4f1:	mov    r13,QWORD PTR [r12]
    72ee5f9ff4f5:	add    r13,0x68
    72ee5f9ff4f9:	mov    r14d,0x0
    72ee5f9ff4ff:	mov    QWORD PTR [r13+0x0],r14
    72ee5f9ff503:	mov    rcx,QWORD PTR [r12+0x380]
    72ee5f9ff50b:	jrcxz  0x72ee5f9ff512
    72ee5f9ff50d:	jmp    0x72ee5f9ff80a
    72ee5f9ff512:	jmp    0x72ee5f9ff517
    72ee5f9ff517:	mov    r13,QWORD PTR [r12+0x10]
    72ee5f9ff51c:	sub    r13,0x1
    72ee5f9ff520:	mov    QWORD PTR [r12+0x10],r13
    72ee5f9ff525:	mov    rax,r13
    72ee5f9ff528:	test   rax,rax
    72ee5f9ff52b:	je     0x72ee5f9ff536
    72ee5f9ff531:	jmp    0x72ee5f9fd63a
    72ee5f9ff536:	mov    r13,QWORD PTR [r12+0xf8]
    72ee5f9ff53e:	mov    r14,r13
    72ee5f9ff541:	add    r14,0x140
    72ee5f9ff548:	mov    r15,r14
    72ee5f9ff54b:	add    r15,0x8
    72ee5f9ff54f:	mov    rbp,QWORD PTR [r14]
    72ee5f9ff552:	mov    r14,QWORD PTR [r15]
    72ee5f9ff555:	mov    QWORD PTR [r12+0xa0],rbp
    72ee5f9ff55d:	mov    QWORD PTR [r12+0x98],r14
    72ee5f9ff565:	mov    r14,r13
    72ee5f9ff568:	add    r14,0x130
    72ee5f9ff56f:	mov    r15,r14
    72ee5f9ff572:	add    r15,0x8
    72ee5f9ff576:	mov    rbp,QWORD PTR [r14]
    72ee5f9ff579:	mov    r14,QWORD PTR [r15]
    72ee5f9ff57c:	mov    QWORD PTR [r12+0xb0],rbp
    72ee5f9ff584:	mov    QWORD PTR [r12+0xa8],r14
    72ee5f9ff58c:	mov    r14,r13
    72ee5f9ff58f:	add    r14,0x120
    72ee5f9ff596:	mov    r15,r14
    72ee5f9ff599:	add    r15,0x8
    72ee5f9ff59d:	mov    rbp,QWORD PTR [r14]
    72ee5f9ff5a0:	mov    r14,QWORD PTR [r15]
    72ee5f9ff5a3:	mov    QWORD PTR [r12+0xc0],rbp
    72ee5f9ff5ab:	mov    QWORD PTR [r12+0xb8],r14
    72ee5f9ff5b3:	mov    r14,r13
    72ee5f9ff5b6:	add    r14,0x110
    72ee5f9ff5bd:	mov    r15,r14
    72ee5f9ff5c0:	add    r15,0x8
    72ee5f9ff5c4:	mov    rbp,QWORD PTR [r14]
    72ee5f9ff5c7:	mov    r14,QWORD PTR [r15]
    72ee5f9ff5ca:	mov    QWORD PTR [r12+0xd0],rbp
    72ee5f9ff5d2:	mov    QWORD PTR [r12+0xc8],r14
    72ee5f9ff5da:	mov    r14,r13
    72ee5f9ff5dd:	add    r14,0x100
    72ee5f9ff5e4:	mov    r15,r14
    72ee5f9ff5e7:	add    r15,0x8
    72ee5f9ff5eb:	mov    rbp,QWORD PTR [r14]
    72ee5f9ff5ee:	mov    r14,QWORD PTR [r15]
    72ee5f9ff5f1:	mov    QWORD PTR [r12+0xe8],rbp
    72ee5f9ff5f9:	mov    QWORD PTR [r12+0xd8],r14
    72ee5f9ff601:	add    r13,0x150
    72ee5f9ff608:	mov    QWORD PTR [r12+0xf8],r13
    72ee5f9ff610:	jmp    0x72ee5f9ff615
    72ee5f9ff615:	mov    rcx,QWORD PTR [r12+0x380]
    72ee5f9ff61d:	jrcxz  0x72ee5f9ff624
    72ee5f9ff61f:	jmp    0x72ee5f9ff892
    72ee5f9ff624:	mov    r13,QWORD PTR [r12+0xf0]
    72ee5f9ff62c:	mov    QWORD PTR [r12+0x100],r13
    72ee5f9ff634:	mov    r11,QWORD PTR [rsp+0xb0]
    72ee5f9ff63c:	mov    QWORD PTR [r12+0x398],r11
    72ee5f9ff644:	mov    rdi,QWORD PTR [r12+0x100]
    72ee5f9ff64c:	add    rsp,0xc0
    72ee5f9ff653:	movabs r11,0x5c9444da9940
    72ee5f9ff65d:	jmp    r11
    72ee5f9ff660:	mov    eax,0x41039c
    72ee5f9ff665:	mov    QWORD PTR [r12+0x100],rax
    72ee5f9ff66d:	push   rdx
    72ee5f9ff66e:	push   rsi
    72ee5f9ff66f:	push   r10
    72ee5f9ff671:	push   r11
    72ee5f9ff673:	mov    r11,rax
    72ee5f9ff676:	lahf
    72ee5f9ff677:	seto   al
    72ee5f9ff67a:	mov    WORD PTR [rsp+0xd0],ax
    72ee5f9ff682:	mov    rax,r11
    72ee5f9ff685:	mov    rdx,QWORD PTR [rsp+0xd0]
    72ee5f9ff68d:	mov    r10d,edx
    72ee5f9ff690:	and    r10d,0xc000
    72ee5f9ff697:	shl    r10d,0x10
    72ee5f9ff69b:	mov    r11d,edx
    72ee5f9ff69e:	and    r11d,0x100
    72ee5f9ff6a5:	shl    r11d,0x15
    72ee5f9ff6a9:	or     r10d,r11d
    72ee5f9ff6ac:	and    edx,0x1
    72ee5f9ff6af:	shl    edx,0x1c
    72ee5f9ff6b2:	or     r10d,edx
    72ee5f9ff6b5:	btc    r10,0x1d
    72ee5f9ff6ba:	mov    r11d,0xf0000000
    72ee5f9ff6c0:	and    r11,r10
    72ee5f9ff6c3:	movabs rsi,0xffffffff0fffffff
    72ee5f9ff6cd:	and    rbx,rsi
    72ee5f9ff6d0:	or     rbx,r11
    72ee5f9ff6d3:	pop    r11
    72ee5f9ff6d5:	pop    r10
    72ee5f9ff6d7:	pop    rsi
    72ee5f9ff6d8:	pop    rdx
    72ee5f9ff6d9:	mov    QWORD PTR [r12+0x108],rbx
    72ee5f9ff6e1:	add    rsp,0xc0
    72ee5f9ff6e8:	mov    eax,0xc
    72ee5f9ff6ed:	movabs r11,0x5c9444da9ca0
    72ee5f9ff6f7:	jmp    r11
    72ee5f9ff6fa:	mov    eax,0x410498
    72ee5f9ff6ff:	mov    QWORD PTR [r12+0x100],rax
    72ee5f9ff707:	push   rdx
    72ee5f9ff708:	push   rsi
    72ee5f9ff709:	push   r10
    72ee5f9ff70b:	push   r11
    72ee5f9ff70d:	mov    rdx,QWORD PTR [rsp+0xd0]
    72ee5f9ff715:	mov    r10d,edx
    72ee5f9ff718:	and    r10d,0xc000
    72ee5f9ff71f:	shl    r10d,0x10
    72ee5f9ff723:	mov    r11d,edx
    72ee5f9ff726:	and    r11d,0x100
    72ee5f9ff72d:	shl    r11d,0x15
    72ee5f9ff731:	or     r10d,r11d
    72ee5f9ff734:	and    edx,0x1
    72ee5f9ff737:	shl    edx,0x1c
    72ee5f9ff73a:	or     r10d,edx
    72ee5f9ff73d:	btc    r10,0x1d
    72ee5f9ff742:	mov    r11d,0xf0000000
    72ee5f9ff748:	and    r11,r10
    72ee5f9ff74b:	movabs rsi,0xffffffff0fffffff
    72ee5f9ff755:	and    rbx,rsi
    72ee5f9ff758:	or     rbx,r11
    72ee5f9ff75b:	pop    r11
    72ee5f9ff75d:	pop    r10
    72ee5f9ff75f:	pop    rsi
    72ee5f9ff760:	pop    rdx
    72ee5f9ff761:	mov    QWORD PTR [r12+0x108],rbx
    72ee5f9ff769:	add    rsp,0xc0
    72ee5f9ff770:	mov    eax,0xc
    72ee5f9ff775:	movabs r11,0x5c9444da9ca0
    72ee5f9ff77f:	jmp    r11
    72ee5f9ff782:	mov    eax,0x410558
    72ee5f9ff787:	mov    QWORD PTR [r12+0x100],rax
    72ee5f9ff78f:	push   rdx
    72ee5f9ff790:	push   rsi
    72ee5f9ff791:	push   r10
    72ee5f9ff793:	push   r11
    72ee5f9ff795:	mov    rdx,QWORD PTR [rsp+0xd0]
    72ee5f9ff79d:	mov    r10d,edx
    72ee5f9ff7a0:	and    r10d,0xc000
    72ee5f9ff7a7:	shl    r10d,0x10
    72ee5f9ff7ab:	mov    r11d,edx
    72ee5f9ff7ae:	and    r11d,0x100
    72ee5f9ff7b5:	shl    r11d,0x15
    72ee5f9ff7b9:	or     r10d,r11d
    72ee5f9ff7bc:	and    edx,0x1
    72ee5f9ff7bf:	shl    edx,0x1c
    72ee5f9ff7c2:	or     r10d,edx
    72ee5f9ff7c5:	btc    r10,0x1d
    72ee5f9ff7ca:	mov    r11d,0xf0000000
    72ee5f9ff7d0:	and    r11,r10
    72ee5f9ff7d3:	movabs rsi,0xffffffff0fffffff
    72ee5f9ff7dd:	and    rbx,rsi
    72ee5f9ff7e0:	or     rbx,r11
    72ee5f9ff7e3:	pop    r11
    72ee5f9ff7e5:	pop    r10
    72ee5f9ff7e7:	pop    rsi
    72ee5f9ff7e8:	pop    rdx
    72ee5f9ff7e9:	mov    QWORD PTR [r12+0x108],rbx
    72ee5f9ff7f1:	add    rsp,0xc0
    72ee5f9ff7f8:	mov    eax,0xc
    72ee5f9ff7fd:	movabs r11,0x5c9444da9ca0
    72ee5f9ff807:	jmp    r11
    72ee5f9ff80a:	mov    eax,0x410594
    72ee5f9ff80f:	mov    QWORD PTR [r12+0x100],rax
    72ee5f9ff817:	push   rdx
    72ee5f9ff818:	push   rsi
    72ee5f9ff819:	push   r10
    72ee5f9ff81b:	push   r11
    72ee5f9ff81d:	mov    rdx,QWORD PTR [rsp+0xd0]
    72ee5f9ff825:	mov    r10d,edx
    72ee5f9ff828:	and    r10d,0xc000
    72ee5f9ff82f:	shl    r10d,0x10
    72ee5f9ff833:	mov    r11d,edx
    72ee5f9ff836:	and    r11d,0x100
    72ee5f9ff83d:	shl    r11d,0x15
    72ee5f9ff841:	or     r10d,r11d
    72ee5f9ff844:	and    edx,0x1
    72ee5f9ff847:	shl    edx,0x1c
    72ee5f9ff84a:	or     r10d,edx
    72ee5f9ff84d:	btc    r10,0x1d
    72ee5f9ff852:	mov    r11d,0xf0000000
    72ee5f9ff858:	and    r11,r10
    72ee5f9ff85b:	movabs rsi,0xffffffff0fffffff
    72ee5f9ff865:	and    rbx,rsi
    72ee5f9ff868:	or     rbx,r11
    72ee5f9ff86b:	pop    r11
    72ee5f9ff86d:	pop    r10
    72ee5f9ff86f:	pop    rsi
    72ee5f9ff870:	pop    rdx
    72ee5f9ff871:	mov    QWORD PTR [r12+0x108],rbx
    72ee5f9ff879:	add    rsp,0xc0
    72ee5f9ff880:	mov    eax,0xc
    72ee5f9ff885:	movabs r11,0x5c9444da9ca0
    72ee5f9ff88f:	jmp    r11
    72ee5f9ff892:	mov    eax,0x4105b0
    72ee5f9ff897:	mov    QWORD PTR [r12+0x100],rax
    72ee5f9ff89f:	push   rdx
    72ee5f9ff8a0:	push   rsi
    72ee5f9ff8a1:	push   r10
    72ee5f9ff8a3:	push   r11
    72ee5f9ff8a5:	mov    rdx,QWORD PTR [rsp+0xd0]
    72ee5f9ff8ad:	mov    r10d,edx
    72ee5f9ff8b0:	and    r10d,0xc000
    72ee5f9ff8b7:	shl    r10d,0x10
    72ee5f9ff8bb:	mov    r11d,edx
    72ee5f9ff8be:	and    r11d,0x100
    72ee5f9ff8c5:	shl    r11d,0x15
    72ee5f9ff8c9:	or     r10d,r11d
    72ee5f9ff8cc:	and    edx,0x1
    72ee5f9ff8cf:	shl    edx,0x1c
    72ee5f9ff8d2:	or     r10d,edx
    72ee5f9ff8d5:	btc    r10,0x1d
    72ee5f9ff8da:	mov    r11d,0xf0000000
    72ee5f9ff8e0:	and    r11,r10
    72ee5f9ff8e3:	movabs rsi,0xffffffff0fffffff
    72ee5f9ff8ed:	and    rbx,rsi
    72ee5f9ff8f0:	or     rbx,r11
    72ee5f9ff8f3:	pop    r11
    72ee5f9ff8f5:	pop    r10
    72ee5f9ff8f7:	pop    rsi
    72ee5f9ff8f8:	pop    rdx
    72ee5f9ff8f9:	mov    QWORD PTR [r12+0x108],rbx
    72ee5f9ff901:	add    rsp,0xc0
    72ee5f9ff908:	mov    eax,0xc
    72ee5f9ff90d:	movabs r11,0x5c9444da9ca0
    72ee5f9ff917:	jmp    r11
    72ee5f9ff91a:	nop    WORD PTR [rax+rax*1+0x0]
    72ee5f9ff920:	sub    rsp,0xc0
    72ee5f9ff927:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ff92f:	mov    QWORD PTR [rsp+0xb0],r11
    72ee5f9ff937:	jmp    0x72ee5f9fd519
    72ee5f9ff93c:	nop    DWORD PTR [rax+0x0]
    72ee5f9ff940:	sub    rsp,0xc0
    72ee5f9ff947:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ff94f:	mov    QWORD PTR [rsp+0xb0],r11
    72ee5f9ff957:	jmp    0x72ee5f9fd63a
    72ee5f9ff95c:	nop    DWORD PTR [rax+0x0]
    72ee5f9ff960:	sub    rsp,0xc0
    72ee5f9ff967:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ff96f:	mov    QWORD PTR [rsp+0xb0],r11
    72ee5f9ff977:	jmp    0x72ee5f9fd6f4
    72ee5f9ff97c:	nop    DWORD PTR [rax+0x0]
    72ee5f9ff980:	sub    rsp,0xc0
    72ee5f9ff987:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ff98f:	mov    QWORD PTR [rsp+0xb0],r11
    72ee5f9ff997:	jmp    0x72ee5f9fedd9
    72ee5f9ff99c:	nop    DWORD PTR [rax+0x0]
    72ee5f9ff9a0:	sub    rsp,0xc0
    72ee5f9ff9a7:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ff9af:	mov    QWORD PTR [rsp+0xb0],r11
    72ee5f9ff9b7:	jmp    0x72ee5f9fef2a
    72ee5f9ff9bc:	nop    DWORD PTR [rax+0x0]
    72ee5f9ff9c0:	sub    rsp,0xc0
    72ee5f9ff9c7:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ff9cf:	mov    QWORD PTR [rsp+0xb0],r11
    72ee5f9ff9d7:	jmp    0x72ee5f9ff0ad
    72ee5f9ff9dc:	nop    DWORD PTR [rax+0x0]
    72ee5f9ff9e0:	sub    rsp,0xc0
    72ee5f9ff9e7:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ff9ef:	mov    QWORD PTR [rsp+0xb0],r11
    72ee5f9ff9f7:	jmp    0x72ee5f9ff3cf
    72ee5f9ff9fc:	nop    DWORD PTR [rax+0x0]
    72ee5f9ffa00:	sub    rsp,0xc0
    72ee5f9ffa07:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ffa0f:	mov    QWORD PTR [rsp+0xb0],r11
    72ee5f9ffa17:	jmp    0x72ee5f9ff517
    72ee5f9ffa1c:	nop    DWORD PTR [rax+0x0]
    72ee5f9ffa20:	sub    rsp,0xc0
    72ee5f9ffa27:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ffa2f:	mov    QWORD PTR [rsp+0xb0],r11
    72ee5f9ffa37:	jmp    0x72ee5f9ff536
    72ee5f9ffa3c:	nop    DWORD PTR [rax+0x0]
    72ee5f9ffa40:	sub    rsp,0xc0
    72ee5f9ffa47:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ffa4f:	mov    QWORD PTR [rsp+0xb0],r11
    72ee5f9ffa57:	jmp    0x72ee5f9ff615
