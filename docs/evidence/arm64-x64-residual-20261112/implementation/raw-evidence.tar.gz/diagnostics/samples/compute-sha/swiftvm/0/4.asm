
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/0/4.bin:     file format binary


Disassembly of section .data:

000072ee5f9fff30 <.data>:
    72ee5f9fff30:	sub    rsp,0x10
    72ee5f9fff34:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9fff3c:	mov    QWORD PTR [rsp],r11
    72ee5f9fff40:	mov    r13,QWORD PTR [r12+0xf8]
    72ee5f9fff48:	add    r13,0x68
    72ee5f9fff4c:	mov    r14,QWORD PTR [r13+0x0]
    72ee5f9fff50:	mov    QWORD PTR [r12+0x40],r14
    72ee5f9fff55:	sub    r14,0x38
    72ee5f9fff59:	mov    rcx,QWORD PTR [r12+0x380]
    72ee5f9fff61:	jrcxz  0x72ee5f9fff68
    72ee5f9fff63:	jmp    0x72ee5fa00035
    72ee5f9fff68:	jne    0x72ee5f9fff81
    72ee5f9fff6e:	mov    r11,rax
    72ee5f9fff71:	lahf
    72ee5f9fff72:	seto   al
    72ee5f9fff75:	mov    WORD PTR [rsp],ax
    72ee5f9fff79:	mov    rax,r11
    72ee5f9fff7c:	jmp    0x72ee5f9fff94
    72ee5f9fff81:	mov    r11,rax
    72ee5f9fff84:	lahf
    72ee5f9fff85:	seto   al
    72ee5f9fff88:	mov    WORD PTR [rsp],ax
    72ee5f9fff8c:	mov    rax,r11
    72ee5f9fff8f:	jmp    0x72ee5f9fffe5
    72ee5f9fff94:	mov    r13d,0x4102c4
    72ee5f9fff9a:	mov    QWORD PTR [r12+0x100],r13
    72ee5f9fffa2:	mov    r11,QWORD PTR [rsp]
    72ee5f9fffa6:	mov    QWORD PTR [r12+0x398],r11
    72ee5f9fffae:	mov    edi,0x4102c4
    72ee5f9fffb3:	mov    QWORD PTR [r12+0x100],rdi
    72ee5f9fffbb:	add    rsp,0x10
    72ee5f9fffbf:	nop
    72ee5f9fffc0:	jmp    QWORD PTR [rip+0x2]        # 0x72ee5f9fffc8
    72ee5f9fffc6:	xchg   ax,ax
    72ee5f9fffc8:	adc    bh,bh
    72ee5f9fffca:	lahf
    72ee5f9fffcb:	pop    rdi
    72ee5f9fffcc:	out    dx,al
    72ee5f9fffcd:	jb     0x72ee5f9fffcf
    72ee5f9fffcf:	add    al,bl
    72ee5f9fffd1:	call   FWORD PTR [rdi+0x72ee5f]
    72ee5f9fffd7:	add    BYTE PTR [rcx-0x45],cl
    72ee5f9fffda:	rex cdq
    72ee5f9fffdc:	fiadd  DWORD PTR [rsp+rdx*4+0x5c]
    72ee5f9fffe0:	add    BYTE PTR [rax],al
    72ee5f9fffe2:	jmp    r11
    72ee5f9fffe5:	mov    r13d,0x4102a8
    72ee5f9fffeb:	mov    QWORD PTR [r12+0x100],r13
    72ee5f9ffff3:	mov    r11,QWORD PTR [rsp]
    72ee5f9ffff7:	mov    QWORD PTR [r12+0x398],r11
    72ee5f9fffff:	mov    edi,0x4102a8
    72ee5fa00004:	mov    QWORD PTR [r12+0x100],rdi
    72ee5fa0000c:	add    rsp,0x10
    72ee5fa00010:	jmp    QWORD PTR [rip+0x2]        # 0x72ee5fa00018
    72ee5fa00016:	xchg   ax,ax
    72ee5fa00018:	lock (bad)
    72ee5fa0001a:	lahf
    72ee5fa0001b:	pop    rdi
    72ee5fa0001c:	out    dx,al
    72ee5fa0001d:	jb     0x72ee5fa0001f
    72ee5fa0001f:	add    BYTE PTR [rax],ch
    72ee5fa00021:	add    BYTE PTR [rax+0x72ee5f],ah
    72ee5fa00027:	add    BYTE PTR [rcx-0x45],cl
    72ee5fa0002a:	rex cdq
    72ee5fa0002c:	fiadd  DWORD PTR [rsp+rdx*4+0x5c]
    72ee5fa00030:	add    BYTE PTR [rax],al
    72ee5fa00032:	jmp    r11
    72ee5fa00035:	mov    eax,0x4102c0
    72ee5fa0003a:	mov    QWORD PTR [r12+0x100],rax
    72ee5fa00042:	push   rdx
    72ee5fa00043:	push   rsi
    72ee5fa00044:	push   r10
    72ee5fa00046:	push   r11
    72ee5fa00048:	mov    r11,rax
    72ee5fa0004b:	lahf
    72ee5fa0004c:	seto   al
    72ee5fa0004f:	mov    WORD PTR [rsp+0x20],ax
    72ee5fa00054:	mov    rax,r11
    72ee5fa00057:	mov    rdx,QWORD PTR [rsp+0x20]
    72ee5fa0005c:	mov    r10d,edx
    72ee5fa0005f:	and    r10d,0xc000
    72ee5fa00066:	shl    r10d,0x10
    72ee5fa0006a:	mov    r11d,edx
    72ee5fa0006d:	and    r11d,0x100
    72ee5fa00074:	shl    r11d,0x15
    72ee5fa00078:	or     r10d,r11d
    72ee5fa0007b:	and    edx,0x1
    72ee5fa0007e:	shl    edx,0x1c
    72ee5fa00081:	or     r10d,edx
    72ee5fa00084:	btc    r10,0x1d
    72ee5fa00089:	mov    r11d,0xf0000000
    72ee5fa0008f:	and    r11,r10
    72ee5fa00092:	movabs rsi,0xffffffff0fffffff
    72ee5fa0009c:	and    rbx,rsi
    72ee5fa0009f:	or     rbx,r11
    72ee5fa000a2:	pop    r11
    72ee5fa000a4:	pop    r10
    72ee5fa000a6:	pop    rsi
    72ee5fa000a7:	pop    rdx
    72ee5fa000a8:	mov    QWORD PTR [r12+0x108],rbx
    72ee5fa000b0:	add    rsp,0x10
    72ee5fa000b4:	mov    eax,0xc
    72ee5fa000b9:	movabs r11,0x5c9444da9ca0
    72ee5fa000c3:	jmp    r11
    72ee5fa000c6:	nop
    72ee5fa000c7:	nop
