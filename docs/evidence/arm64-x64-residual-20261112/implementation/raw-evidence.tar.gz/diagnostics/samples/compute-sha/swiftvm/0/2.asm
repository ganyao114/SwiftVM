
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/0/2.bin:     file format binary


Disassembly of section .data:

000072ee5f9ffa60 <.data>:
    72ee5f9ffa60:	sub    rsp,0x10
    72ee5f9ffa64:	mov    r13d,DWORD PTR [r12+0xa0]
    72ee5f9ffa6c:	sub    r13d,0x1
    72ee5f9ffa70:	mov    QWORD PTR [r12+0xa0],r13
    72ee5f9ffa78:	mov    rcx,QWORD PTR [r12+0x380]
    72ee5f9ffa80:	jrcxz  0x72ee5f9ffa87
    72ee5f9ffa82:	jmp    0x72ee5f9ffc05
    72ee5f9ffa87:	jne    0x72ee5f9ffaa0
    72ee5f9ffa8d:	mov    r11,rax
    72ee5f9ffa90:	lahf
    72ee5f9ffa91:	seto   al
    72ee5f9ffa94:	mov    WORD PTR [rsp],ax
    72ee5f9ffa98:	mov    rax,r11
    72ee5f9ffa9b:	jmp    0x72ee5f9ffab3
    72ee5f9ffaa0:	mov    r11,rax
    72ee5f9ffaa3:	lahf
    72ee5f9ffaa4:	seto   al
    72ee5f9ffaa7:	mov    WORD PTR [rsp],ax
    72ee5f9ffaab:	mov    rax,r11
    72ee5f9ffaae:	jmp    0x72ee5f9ffb75
    72ee5f9ffab3:	mov    r13,QWORD PTR [r12+0xf8]
    72ee5f9ffabb:	mov    r14,r13
    72ee5f9ffabe:	add    r14,0x20
    72ee5f9ffac2:	mov    r15,QWORD PTR [r14]
    72ee5f9ffac5:	mov    QWORD PTR [r12+0x98],r15
    72ee5f9ffacd:	mov    r14d,0x80
    72ee5f9ffad3:	mov    QWORD PTR [r12+0x40],r14
    72ee5f9ffad8:	mov    QWORD PTR [r12],r13
    72ee5f9ffadc:	mov    r14,r13
    72ee5f9ffadf:	add    r14,0x8c
    72ee5f9ffae6:	mov    QWORD PTR [r12+0x8],r14
    72ee5f9ffaeb:	mov    r14d,0x1
    72ee5f9ffaf1:	mov    QWORD PTR [r12+0x10],r14
    72ee5f9ffaf6:	add    r13,0x8c
    72ee5f9ffafd:	movzx  r14d,BYTE PTR [r12+0x40]
    72ee5f9ffb03:	mov    BYTE PTR [r13+0x0],r14b
    72ee5f9ffb07:	mov    r13d,0x0
    72ee5f9ffb0d:	mov    DWORD PTR [r12+0x32c],r13d
    72ee5f9ffb15:	mov    r13d,0x410298
    72ee5f9ffb1b:	mov    QWORD PTR [r12+0xf0],r13
    72ee5f9ffb23:	mov    r13d,0x410338
    72ee5f9ffb29:	mov    QWORD PTR [r12+0x100],r13
    72ee5f9ffb31:	mov    r11,QWORD PTR [rsp]
    72ee5f9ffb35:	mov    QWORD PTR [r12+0x398],r11
    72ee5f9ffb3d:	mov    edi,0x410338
    72ee5f9ffb42:	mov    QWORD PTR [r12+0x100],rdi
    72ee5f9ffb4a:	add    rsp,0x10
    72ee5f9ffb4e:	xchg   ax,ax
    72ee5f9ffb50:	jmp    QWORD PTR [rip+0x2]        # 0x72ee5f9ffb58
    72ee5f9ffb56:	xchg   ax,ax
    72ee5f9ffb58:	rcl    ah,0x9f
    72ee5f9ffb5b:	pop    rdi
    72ee5f9ffb5c:	out    dx,al
    72ee5f9ffb5d:	jb     0x72ee5f9ffb5f
    72ee5f9ffb5f:	add    BYTE PTR [rax-0x5],ch
    72ee5f9ffb62:	lahf
    72ee5f9ffb63:	pop    rdi
    72ee5f9ffb64:	out    dx,al
    72ee5f9ffb65:	jb     0x72ee5f9ffb67
    72ee5f9ffb67:	add    BYTE PTR [rcx-0x45],cl
    72ee5f9ffb6a:	rex cdq
    72ee5f9ffb6c:	fiadd  DWORD PTR [rsp+rdx*4+0x5c]
    72ee5f9ffb70:	add    BYTE PTR [rax],al
    72ee5f9ffb72:	jmp    r11
    72ee5f9ffb75:	mov    r13,QWORD PTR [r12+0xf8]
    72ee5f9ffb7d:	mov    QWORD PTR [r12],r13
    72ee5f9ffb81:	mov    r13d,0x0
    72ee5f9ffb87:	mov    r14,QWORD PTR [r12+0x98]
    72ee5f9ffb8f:	or     r13,r14
    72ee5f9ffb92:	mov    QWORD PTR [r12+0x8],r13
    72ee5f9ffb97:	mov    r13d,0x12c
    72ee5f9ffb9d:	mov    QWORD PTR [r12+0x10],r13
    72ee5f9ffba2:	mov    r13d,0x410274
    72ee5f9ffba8:	mov    QWORD PTR [r12+0xf0],r13
    72ee5f9ffbb0:	mov    r13d,0x410338
    72ee5f9ffbb6:	mov    QWORD PTR [r12+0x100],r13
    72ee5f9ffbbe:	mov    r11,QWORD PTR [rsp]
    72ee5f9ffbc2:	mov    QWORD PTR [r12+0x398],r11
    72ee5f9ffbca:	mov    edi,0x410338
    72ee5f9ffbcf:	mov    QWORD PTR [r12+0x100],rdi
    72ee5f9ffbd7:	add    rsp,0x10
    72ee5f9ffbdb:	nop    DWORD PTR [rax+rax*1+0x0]
    72ee5f9ffbe0:	jmp    QWORD PTR [rip+0x2]        # 0x72ee5f9ffbe8
    72ee5f9ffbe6:	xchg   ax,ax
    72ee5f9ffbe8:	rcl    ah,0x9f
    72ee5f9ffbeb:	pop    rdi
    72ee5f9ffbec:	out    dx,al
    72ee5f9ffbed:	jb     0x72ee5f9ffbef
    72ee5f9ffbef:	add    al,bh
    72ee5f9ffbf1:	sti
    72ee5f9ffbf2:	lahf
    72ee5f9ffbf3:	pop    rdi
    72ee5f9ffbf4:	out    dx,al
    72ee5f9ffbf5:	jb     0x72ee5f9ffbf7
    72ee5f9ffbf7:	add    BYTE PTR [rcx-0x45],cl
    72ee5f9ffbfa:	rex cdq
    72ee5f9ffbfc:	fiadd  DWORD PTR [rsp+rdx*4+0x5c]
    72ee5f9ffc00:	add    BYTE PTR [rax],al
    72ee5f9ffc02:	jmp    r11
    72ee5f9ffc05:	mov    eax,0x410278
    72ee5f9ffc0a:	mov    QWORD PTR [r12+0x100],rax
    72ee5f9ffc12:	push   rdx
    72ee5f9ffc13:	push   rsi
    72ee5f9ffc14:	push   r10
    72ee5f9ffc16:	push   r11
    72ee5f9ffc18:	mov    r11,rax
    72ee5f9ffc1b:	lahf
    72ee5f9ffc1c:	seto   al
    72ee5f9ffc1f:	mov    WORD PTR [rsp+0x20],ax
    72ee5f9ffc24:	mov    rax,r11
    72ee5f9ffc27:	mov    rdx,QWORD PTR [rsp+0x20]
    72ee5f9ffc2c:	mov    r10d,edx
    72ee5f9ffc2f:	and    r10d,0xc000
    72ee5f9ffc36:	shl    r10d,0x10
    72ee5f9ffc3a:	mov    r11d,edx
    72ee5f9ffc3d:	and    r11d,0x100
    72ee5f9ffc44:	shl    r11d,0x15
    72ee5f9ffc48:	or     r10d,r11d
    72ee5f9ffc4b:	and    edx,0x1
    72ee5f9ffc4e:	shl    edx,0x1c
    72ee5f9ffc51:	or     r10d,edx
    72ee5f9ffc54:	btc    r10,0x1d
    72ee5f9ffc59:	mov    r11d,0xf0000000
    72ee5f9ffc5f:	and    r11,r10
    72ee5f9ffc62:	movabs rsi,0xffffffff0fffffff
    72ee5f9ffc6c:	and    rbx,rsi
    72ee5f9ffc6f:	or     rbx,r11
    72ee5f9ffc72:	pop    r11
    72ee5f9ffc74:	pop    r10
    72ee5f9ffc76:	pop    rsi
    72ee5f9ffc77:	pop    rdx
    72ee5f9ffc78:	mov    QWORD PTR [r12+0x108],rbx
    72ee5f9ffc80:	add    rsp,0x10
    72ee5f9ffc84:	mov    eax,0xc
    72ee5f9ffc89:	movabs r11,0x5c9444da9ca0
    72ee5f9ffc93:	jmp    r11
    72ee5f9ffc96:	data16 nop WORD PTR [rax+rax*1+0x0]
    72ee5f9ffca0:	sub    rsp,0x10
    72ee5f9ffca4:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ffcac:	mov    QWORD PTR [rsp],r11
    72ee5f9ffcb0:	jmp    0x72ee5f9ffab3
    72ee5f9ffcb5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72ee5f9ffcc0:	sub    rsp,0x10
    72ee5f9ffcc4:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9ffccc:	mov    QWORD PTR [rsp],r11
    72ee5f9ffcd0:	jmp    0x72ee5f9ffb75
    72ee5f9ffcd5:	nop
    72ee5f9ffcd6:	nop
    72ee5f9ffcd7:	nop
