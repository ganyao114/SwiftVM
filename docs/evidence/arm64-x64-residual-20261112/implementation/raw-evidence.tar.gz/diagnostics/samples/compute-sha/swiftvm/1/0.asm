
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

00007c0f944fe000 <.data>:
    7c0f944fe000:	sub    rsp,0x10
    7c0f944fe004:	mov    r11,QWORD PTR [r12+0x398]
    7c0f944fe00c:	mov    QWORD PTR [rsp],r11
    7c0f944fe010:	mov    r13,QWORD PTR [r12+0xf8]
    7c0f944fe018:	sub    r13,0xa0
    7c0f944fe01f:	mov    QWORD PTR [r12+0xf8],r13
    7c0f944fe027:	mov    r14d,0x420000
    7c0f944fe02d:	mov    QWORD PTR [r12+0x40],r14
    7c0f944fe032:	mov    r14d,0x420000
    7c0f944fe038:	mov    QWORD PTR [r12+0x48],r14
    7c0f944fe03d:	mov    r14,r13
    7c0f944fe040:	add    r14,0x90
    7c0f944fe047:	mov    r15,r14
    7c0f944fe04a:	add    r15,0x8
    7c0f944fe04e:	mov    rbp,QWORD PTR [r12+0xa0]
    7c0f944fe056:	mov    r8,QWORD PTR [r12+0x98]
    7c0f944fe05e:	mov    QWORD PTR [r14],rbp
    7c0f944fe061:	mov    r14d,0x0
    7c0f944fe067:	mov    DWORD PTR [r12+0x32c],r14d
    7c0f944fe06f:	mov    QWORD PTR [r15],r8
    7c0f944fe072:	mov    r14d,0x420670
    7c0f944fe078:	movdqu xmm2,XMMWORD PTR [r14]
    7c0f944fe07d:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7c0f944fe087:	mov    r14d,0x420610
    7c0f944fe08d:	movdqu xmm3,XMMWORD PTR [r14]
    7c0f944fe092:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7c0f944fe09c:	mov    r14d,0x420690
    7c0f944fe0a2:	movdqu xmm4,XMMWORD PTR [r14]
    7c0f944fe0a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
    7c0f944fe0b1:	mov    r14d,0x420630
    7c0f944fe0b7:	movdqu xmm5,XMMWORD PTR [r14]
    7c0f944fe0bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
    7c0f944fe0c6:	mov    r14d,0x430000
    7c0f944fe0cc:	add    r14,0x8a0
    7c0f944fe0d3:	mov    QWORD PTR [r12+0x98],r14
    7c0f944fe0db:	mov    r15d,0x4206a0
    7c0f944fe0e1:	movdqu xmm6,XMMWORD PTR [r15]
    7c0f944fe0e6:	movdqu XMMWORD PTR [r12+0x150],xmm6
    7c0f944fe0f0:	mov    r15,r14
    7c0f944fe0f3:	add    r15,0x10
    7c0f944fe0f7:	movdqu XMMWORD PTR [r14],xmm2
    7c0f944fe0fc:	movdqu XMMWORD PTR [r15],xmm3
    7c0f944fe101:	mov    r15,r14
    7c0f944fe104:	add    r15,0x20
    7c0f944fe108:	mov    rbp,r15
    7c0f944fe10b:	add    rbp,0x10
    7c0f944fe10f:	movdqu XMMWORD PTR [r15],xmm4
    7c0f944fe114:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    7c0f944fe119:	mov    r15d,0x420600
    7c0f944fe11f:	movdqu xmm4,XMMWORD PTR [r15]
    7c0f944fe124:	movdqu XMMWORD PTR [r12+0x130],xmm4
    7c0f944fe12e:	mov    r15d,0x4205f0
    7c0f944fe134:	movdqu xmm5,XMMWORD PTR [r15]
    7c0f944fe139:	movdqu XMMWORD PTR [r12+0x140],xmm5
    7c0f944fe143:	mov    r15,r14
    7c0f944fe146:	add    r15,0x100
    7c0f944fe14d:	mov    rbp,r15
    7c0f944fe150:	add    rbp,0x10
    7c0f944fe154:	movdqu XMMWORD PTR [r15],xmm2
    7c0f944fe159:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    7c0f944fe15e:	mov    r15,r14
    7c0f944fe161:	add    r15,0x40
    7c0f944fe165:	mov    rbp,r15
    7c0f944fe168:	add    rbp,0x10
    7c0f944fe16c:	movdqu XMMWORD PTR [r15],xmm6
    7c0f944fe171:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    7c0f944fe176:	mov    r15d,0x4205e0
    7c0f944fe17c:	movdqu xmm2,XMMWORD PTR [r15]
    7c0f944fe181:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c0f944fe18b:	mov    r15d,0x420640
    7c0f944fe191:	movdqu xmm3,XMMWORD PTR [r15]
    7c0f944fe196:	movdqu XMMWORD PTR [r12+0x150],xmm3
    7c0f944fe1a0:	mov    r15d,0xf8d3
    7c0f944fe1a6:	mov    QWORD PTR [r12+0x48],r15
    7c0f944fe1ab:	mov    r15,r14
    7c0f944fe1ae:	add    r15,0x60
    7c0f944fe1b2:	mov    rbp,r15
    7c0f944fe1b5:	add    rbp,0x10
    7c0f944fe1b9:	movdqu XMMWORD PTR [r15],xmm5
    7c0f944fe1be:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c0f944fe1c3:	mov    r15d,0x420650
    7c0f944fe1c9:	movdqu xmm2,XMMWORD PTR [r15]
    7c0f944fe1ce:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c0f944fe1d8:	mov    r15d,0x420620
    7c0f944fe1de:	movdqu xmm4,XMMWORD PTR [r15]
    7c0f944fe1e3:	movdqu XMMWORD PTR [r12+0x140],xmm4
    7c0f944fe1ed:	mov    r15d,0xf8d3
    7c0f944fe1f3:	mov    ebp,0x421d
    7c0f944fe1f8:	and    ebp,0xffff
    7c0f944fe1fe:	mov    rax,r15
    7c0f944fe201:	movabs rcx,0xffffffff0000ffff
    7c0f944fe20b:	and    rax,rcx
    7c0f944fe20e:	mov    rdx,rbp
    7c0f944fe211:	shl    rdx,0x10
    7c0f944fe215:	mov    ecx,0xffff0000
    7c0f944fe21a:	and    rdx,rcx
    7c0f944fe21d:	or     rax,rdx
    7c0f944fe220:	mov    r8d,eax
    7c0f944fe223:	mov    QWORD PTR [r12+0x48],r8
    7c0f944fe228:	mov    r15,r14
    7c0f944fe22b:	add    r15,0x80
    7c0f944fe232:	mov    rbp,r15
    7c0f944fe235:	add    rbp,0x10
    7c0f944fe239:	movdqu XMMWORD PTR [r15],xmm3
    7c0f944fe23e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c0f944fe243:	mov    r15d,0x4206c0
    7c0f944fe249:	movdqu xmm2,XMMWORD PTR [r15]
    7c0f944fe24e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c0f944fe258:	mov    r15d,0x4206d0
    7c0f944fe25e:	movdqu xmm3,XMMWORD PTR [r15]
    7c0f944fe263:	movdqu XMMWORD PTR [r12+0x150],xmm3
    7c0f944fe26d:	mov    r15d,0x3e8
    7c0f944fe273:	mov    QWORD PTR [r12+0xa0],r15
    7c0f944fe27b:	mov    r15,r14
    7c0f944fe27e:	add    r15,0xa0
    7c0f944fe285:	mov    rbp,r15
    7c0f944fe288:	add    rbp,0x10
    7c0f944fe28c:	movdqu XMMWORD PTR [r15],xmm4
    7c0f944fe291:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c0f944fe296:	mov    r15d,0x4206b0
    7c0f944fe29c:	movdqu xmm2,XMMWORD PTR [r15]
    7c0f944fe2a1:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c0f944fe2ab:	mov    r15d,0x420660
    7c0f944fe2b1:	movdqu xmm4,XMMWORD PTR [r15]
    7c0f944fe2b6:	movdqu XMMWORD PTR [r12+0x140],xmm4
    7c0f944fe2c0:	mov    r15,r13
    7c0f944fe2c3:	add    r15,0x80
    7c0f944fe2ca:	mov    rbp,QWORD PTR [r12+0xf0]
    7c0f944fe2d2:	mov    QWORD PTR [r15],rbp
    7c0f944fe2d5:	mov    r15,r14
    7c0f944fe2d8:	add    r15,0xc0
    7c0f944fe2df:	mov    rbp,r15
    7c0f944fe2e2:	add    rbp,0x10
    7c0f944fe2e6:	movdqu XMMWORD PTR [r15],xmm3
    7c0f944fe2eb:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c0f944fe2f0:	mov    r15d,0x420680
    7c0f944fe2f6:	movdqu xmm2,XMMWORD PTR [r15]
    7c0f944fe2fb:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c0f944fe305:	mov    r15d,0x4206e0
    7c0f944fe30b:	mov    rbp,QWORD PTR [r15]
    7c0f944fe30e:	mov    r15d,0x0
    7c0f944fe314:	mov    QWORD PTR [r12+0x110],rbp
    7c0f944fe31c:	mov    QWORD PTR [r12+0x118],r15
    7c0f944fe324:	mov    r15d,0x4206e8
    7c0f944fe32a:	mov    QWORD PTR [r12+0x40],r15
    7c0f944fe32f:	mov    r15,r14
    7c0f944fe332:	add    r15,0xe0
    7c0f944fe339:	mov    r9,r15
    7c0f944fe33c:	add    r9,0x10
    7c0f944fe340:	movdqu XMMWORD PTR [r15],xmm4
    7c0f944fe345:	movdqu XMMWORD PTR [r9],xmm2
    7c0f944fe34a:	mov    r15d,0x420748
    7c0f944fe350:	movdqu xmm2,XMMWORD PTR [r15]
    7c0f944fe355:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c0f944fe35f:	mov    r15,r14
    7c0f944fe362:	add    r15,0x120
    7c0f944fe369:	mov    QWORD PTR [r15],rbp
    7c0f944fe36c:	mov    r15d,0x420728
    7c0f944fe372:	mov    ebp,0x420738
    7c0f944fe377:	movdqu xmm3,XMMWORD PTR [r15]
    7c0f944fe37c:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    7c0f944fe381:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7c0f944fe38b:	movdqu XMMWORD PTR [r12+0x110],xmm4
    7c0f944fe395:	mov    r15,r13
    7c0f944fe398:	add    r15,0x60
    7c0f944fe39c:	movdqu XMMWORD PTR [r15],xmm2
    7c0f944fe3a1:	mov    r15,r14
    7c0f944fe3a4:	add    r15,0x128
    7c0f944fe3ab:	mov    DWORD PTR [r15],r8d
    7c0f944fe3ae:	mov    r15,r13
    7c0f944fe3b1:	add    r15,0x40
    7c0f944fe3b5:	mov    rbp,r15
    7c0f944fe3b8:	add    rbp,0x10
    7c0f944fe3bc:	movdqu XMMWORD PTR [r15],xmm3
    7c0f944fe3c1:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    7c0f944fe3c6:	mov    r15d,0x4206e8
    7c0f944fe3cc:	mov    ebp,0x4206f8
    7c0f944fe3d1:	movdqu xmm2,XMMWORD PTR [r15]
    7c0f944fe3d6:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c0f944fe3db:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7c0f944fe3e5:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7c0f944fe3ef:	mov    r15,r13
    7c0f944fe3f2:	add    r15,0x10
    7c0f944fe3f6:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c0f944fe3fc:	movdqu XMMWORD PTR [r15],xmm3
    7c0f944fe401:	mov    r15d,0x420708
    7c0f944fe407:	mov    ebp,0x420718
    7c0f944fe40c:	movdqu xmm2,XMMWORD PTR [r15]
    7c0f944fe411:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c0f944fe416:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7c0f944fe420:	movdqu XMMWORD PTR [r12+0x130],xmm3
    7c0f944fe42a:	mov    r15,r13
    7c0f944fe42d:	add    r15,0x20
    7c0f944fe431:	mov    rbp,r15
    7c0f944fe434:	add    rbp,0x10
    7c0f944fe438:	movdqu XMMWORD PTR [r15],xmm2
    7c0f944fe43d:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    7c0f944fe442:	mov    QWORD PTR [r12],r13
    7c0f944fe446:	mov    r13d,0x0
    7c0f944fe44c:	or     r13,r14
    7c0f944fe44f:	mov    QWORD PTR [r12+0x8],r13
    7c0f944fe454:	mov    r13d,0x12c
    7c0f944fe45a:	mov    QWORD PTR [r12+0x10],r13
    7c0f944fe45f:	mov    r13d,0x410274
    7c0f944fe465:	mov    QWORD PTR [r12+0xf0],r13
    7c0f944fe46d:	mov    r13d,0x410338
    7c0f944fe473:	mov    QWORD PTR [r12+0x100],r13
    7c0f944fe47b:	mov    r11,QWORD PTR [rsp]
    7c0f944fe47f:	mov    QWORD PTR [r12+0x398],r11
    7c0f944fe487:	mov    edi,0x410338
    7c0f944fe48c:	mov    QWORD PTR [r12+0x100],rdi
    7c0f944fe494:	add    rsp,0x10
    7c0f944fe498:	jmp    QWORD PTR [rip+0x2]        # 0x7c0f944fe4a0
    7c0f944fe49e:	xchg   ax,ax
    7c0f944fe4a0:	shl    ah,0x4f
    7c0f944fe4a3:	xchg   esp,eax
    7c0f944fe4a4:	(bad)
    7c0f944fe4a6:	add    BYTE PTR [rax],al
    7c0f944fe4a8:	mov    al,0xe4
    7c0f944fe4aa:	rex.WRXB xchg r12,rax
    7c0f944fe4ac:	(bad)
    7c0f944fe4ae:	add    BYTE PTR [rax],al
    7c0f944fe4b0:	movabs r11,0x62016968d940
    7c0f944fe4ba:	jmp    r11
    7c0f944fe4bd:	nop
    7c0f944fe4be:	nop
    7c0f944fe4bf:	nop
