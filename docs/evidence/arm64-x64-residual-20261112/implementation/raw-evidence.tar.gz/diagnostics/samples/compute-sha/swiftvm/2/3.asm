
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/2/3.bin:     file format binary


Disassembly of section .data:

0000719221f00ce0 <.data>:
    719221f00ce0:	sub    rsp,0x10
    719221f00ce4:	mov    r11,QWORD PTR [r12+0x398]
    719221f00cec:	mov    QWORD PTR [rsp],r11
    719221f00cf0:	mov    r13,QWORD PTR [r12+0xf8]
    719221f00cf8:	mov    r14,r13
    719221f00cfb:	add    r14,0x68
    719221f00cff:	mov    r15,QWORD PTR [r14]
    719221f00d02:	mov    QWORD PTR [r12+0x40],r15
    719221f00d07:	add    r13,0x88
    719221f00d0e:	mov    r14d,0x0
    719221f00d14:	mov    BYTE PTR [r13+0x0],r14b
    719221f00d18:	mov    r13d,0x0
    719221f00d1e:	mov    DWORD PTR [r12+0x32c],r13d
    719221f00d26:	sub    r15,0x38
    719221f00d2a:	je     0x719221f00d43
    719221f00d30:	mov    r11,rax
    719221f00d33:	lahf
    719221f00d34:	seto   al
    719221f00d37:	mov    WORD PTR [rsp],ax
    719221f00d3b:	mov    rax,r11
    719221f00d3e:	jmp    0x719221f00d56
    719221f00d43:	mov    r11,rax
    719221f00d46:	lahf
    719221f00d47:	seto   al
    719221f00d4a:	mov    WORD PTR [rsp],ax
    719221f00d4e:	mov    rax,r11
    719221f00d51:	jmp    0x719221f00ddd
    719221f00d56:	mov    r13,QWORD PTR [r12+0xf8]
    719221f00d5e:	mov    QWORD PTR [r12],r13
    719221f00d62:	add    r13,0x88
    719221f00d69:	mov    QWORD PTR [r12+0x8],r13
    719221f00d6e:	mov    r13d,0x1
    719221f00d74:	mov    QWORD PTR [r12+0x10],r13
    719221f00d79:	mov    r13d,0x4102b8
    719221f00d7f:	mov    QWORD PTR [r12+0xf0],r13
    719221f00d87:	mov    r13d,0x410338
    719221f00d8d:	mov    QWORD PTR [r12+0x100],r13
    719221f00d95:	mov    r11,QWORD PTR [rsp]
    719221f00d99:	mov    QWORD PTR [r12+0x398],r11
    719221f00da1:	mov    edi,0x410338
    719221f00da6:	mov    QWORD PTR [r12+0x100],rdi
    719221f00dae:	add    rsp,0x10
    719221f00db2:	nop    WORD PTR [rax+rax*1+0x0]
    719221f00db8:	jmp    QWORD PTR [rip+0x2]        # 0x719221f00dc0
    719221f00dbe:	xchg   ax,ax
    719221f00dc0:	shl    ah,0xef
    719221f00dc3:	and    DWORD PTR [rdx-0x2fffff8f],edx
    719221f00dc9:	or     eax,0x719221f0
    719221f00dce:	add    BYTE PTR [rax],al
    719221f00dd0:	movabs r11,0x64862955b940
    719221f00dda:	jmp    r11
    719221f00ddd:	mov    r13,QWORD PTR [r12+0x98]
    719221f00de5:	ror    r13,0x3d
    719221f00de9:	and    r13,0xfffffffffffffff8
    719221f00ded:	mov    r14,QWORD PTR [r12+0xf8]
    719221f00df5:	mov    QWORD PTR [r12],r14
    719221f00df9:	mov    r15,r14
    719221f00dfc:	add    r15,0x78
    719221f00e00:	mov    QWORD PTR [r12+0x8],r15
    719221f00e05:	mov    r15d,0x8
    719221f00e0b:	mov    QWORD PTR [r12+0x10],r15
    719221f00e10:	movabs rcx,0xff00ff00ff00ff
    719221f00e1a:	mov    r15,r13
    719221f00e1d:	and    r15,rcx
    719221f00e20:	shl    r15,0x8
    719221f00e24:	movabs rcx,0xff00ff00ff00ff00
    719221f00e2e:	and    r13,rcx
    719221f00e31:	shr    r13,0x8
    719221f00e35:	or     r13,r15
    719221f00e38:	movabs rcx,0xffff0000ffff
    719221f00e42:	mov    r15,r13
    719221f00e45:	and    r15,rcx
    719221f00e48:	shl    r15,0x10
    719221f00e4c:	movabs rcx,0xffff0000ffff0000
    719221f00e56:	and    r13,rcx
    719221f00e59:	shr    r13,0x10
    719221f00e5d:	or     r13,r15
    719221f00e60:	mov    r15,r13
    719221f00e63:	shl    r15,0x20
    719221f00e67:	shr    r13,0x20
    719221f00e6b:	or     r13,r15
    719221f00e6e:	mov    QWORD PTR [r12+0x40],r13
    719221f00e73:	add    r14,0x78
    719221f00e77:	mov    QWORD PTR [r14],r13
    719221f00e7a:	mov    r13d,0x0
    719221f00e80:	mov    DWORD PTR [r12+0x32c],r13d
    719221f00e88:	mov    r13d,0x4102e0
    719221f00e8e:	mov    QWORD PTR [r12+0xf0],r13
    719221f00e96:	mov    r13d,0x410338
    719221f00e9c:	mov    QWORD PTR [r12+0x100],r13
    719221f00ea4:	mov    r11,QWORD PTR [rsp]
    719221f00ea8:	mov    QWORD PTR [r12+0x398],r11
    719221f00eb0:	mov    edi,0x410338
    719221f00eb5:	mov    QWORD PTR [r12+0x100],rdi
    719221f00ebd:	add    rsp,0x10
    719221f00ec1:	nop    DWORD PTR [rax+0x0]
    719221f00ec8:	jmp    QWORD PTR [rip+0x2]        # 0x719221f00ed0
    719221f00ece:	xchg   ax,ax
    719221f00ed0:	shl    ah,0xef
    719221f00ed3:	and    DWORD PTR [rdx-0x1fffff8f],edx
    719221f00ed9:	(bad)
    719221f00eda:	lock and DWORD PTR [rdx+0x49000071],edx
    719221f00ee1:	mov    ebx,0x2955b940
    719221f00ee6:	xchg   BYTE PTR [rax+rax*1+0x0],ah
    719221f00eea:	jmp    r11
    719221f00eed:	nop    DWORD PTR [rax]
    719221f00ef0:	sub    rsp,0x10
    719221f00ef4:	mov    r11,QWORD PTR [r12+0x398]
    719221f00efc:	mov    QWORD PTR [rsp],r11
    719221f00f00:	jmp    0x719221f00d56
    719221f00f05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    719221f00f10:	sub    rsp,0x10
    719221f00f14:	mov    r11,QWORD PTR [r12+0x398]
    719221f00f1c:	mov    QWORD PTR [rsp],r11
    719221f00f20:	jmp    0x719221f00ddd
    719221f00f25:	nop
    719221f00f26:	nop
    719221f00f27:	nop
