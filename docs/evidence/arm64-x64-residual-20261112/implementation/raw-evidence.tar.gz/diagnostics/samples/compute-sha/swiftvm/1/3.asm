
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/1/3.bin:     file format binary


Disassembly of section .data:

00007c0f94500ce0 <.data>:
    7c0f94500ce0:	sub    rsp,0x10
    7c0f94500ce4:	mov    r11,QWORD PTR [r12+0x398]
    7c0f94500cec:	mov    QWORD PTR [rsp],r11
    7c0f94500cf0:	mov    r13,QWORD PTR [r12+0xf8]
    7c0f94500cf8:	mov    r14,r13
    7c0f94500cfb:	add    r14,0x68
    7c0f94500cff:	mov    r15,QWORD PTR [r14]
    7c0f94500d02:	mov    QWORD PTR [r12+0x40],r15
    7c0f94500d07:	add    r13,0x88
    7c0f94500d0e:	mov    r14d,0x0
    7c0f94500d14:	mov    BYTE PTR [r13+0x0],r14b
    7c0f94500d18:	mov    r13d,0x0
    7c0f94500d1e:	mov    DWORD PTR [r12+0x32c],r13d
    7c0f94500d26:	sub    r15,0x38
    7c0f94500d2a:	je     0x7c0f94500d43
    7c0f94500d30:	mov    r11,rax
    7c0f94500d33:	lahf
    7c0f94500d34:	seto   al
    7c0f94500d37:	mov    WORD PTR [rsp],ax
    7c0f94500d3b:	mov    rax,r11
    7c0f94500d3e:	jmp    0x7c0f94500d56
    7c0f94500d43:	mov    r11,rax
    7c0f94500d46:	lahf
    7c0f94500d47:	seto   al
    7c0f94500d4a:	mov    WORD PTR [rsp],ax
    7c0f94500d4e:	mov    rax,r11
    7c0f94500d51:	jmp    0x7c0f94500ddd
    7c0f94500d56:	mov    r13,QWORD PTR [r12+0xf8]
    7c0f94500d5e:	mov    QWORD PTR [r12],r13
    7c0f94500d62:	add    r13,0x88
    7c0f94500d69:	mov    QWORD PTR [r12+0x8],r13
    7c0f94500d6e:	mov    r13d,0x1
    7c0f94500d74:	mov    QWORD PTR [r12+0x10],r13
    7c0f94500d79:	mov    r13d,0x4102b8
    7c0f94500d7f:	mov    QWORD PTR [r12+0xf0],r13
    7c0f94500d87:	mov    r13d,0x410338
    7c0f94500d8d:	mov    QWORD PTR [r12+0x100],r13
    7c0f94500d95:	mov    r11,QWORD PTR [rsp]
    7c0f94500d99:	mov    QWORD PTR [r12+0x398],r11
    7c0f94500da1:	mov    edi,0x410338
    7c0f94500da6:	mov    QWORD PTR [r12+0x100],rdi
    7c0f94500dae:	add    rsp,0x10
    7c0f94500db2:	nop    WORD PTR [rax+rax*1+0x0]
    7c0f94500db8:	jmp    QWORD PTR [rip+0x2]        # 0x7c0f94500dc0
    7c0f94500dbe:	xchg   ax,ax
    7c0f94500dc0:	shl    ah,0x4f
    7c0f94500dc3:	xchg   esp,eax
    7c0f94500dc4:	(bad)
    7c0f94500dc6:	add    BYTE PTR [rax],al
    7c0f94500dc8:	ror    BYTE PTR [rip+0x7c0f9450],1        # 0x7c10105fa21e
    7c0f94500dce:	add    BYTE PTR [rax],al
    7c0f94500dd0:	movabs r11,0x62016968d940
    7c0f94500dda:	jmp    r11
    7c0f94500ddd:	mov    r13,QWORD PTR [r12+0x98]
    7c0f94500de5:	ror    r13,0x3d
    7c0f94500de9:	and    r13,0xfffffffffffffff8
    7c0f94500ded:	mov    r14,QWORD PTR [r12+0xf8]
    7c0f94500df5:	mov    QWORD PTR [r12],r14
    7c0f94500df9:	mov    r15,r14
    7c0f94500dfc:	add    r15,0x78
    7c0f94500e00:	mov    QWORD PTR [r12+0x8],r15
    7c0f94500e05:	mov    r15d,0x8
    7c0f94500e0b:	mov    QWORD PTR [r12+0x10],r15
    7c0f94500e10:	movabs rcx,0xff00ff00ff00ff
    7c0f94500e1a:	mov    r15,r13
    7c0f94500e1d:	and    r15,rcx
    7c0f94500e20:	shl    r15,0x8
    7c0f94500e24:	movabs rcx,0xff00ff00ff00ff00
    7c0f94500e2e:	and    r13,rcx
    7c0f94500e31:	shr    r13,0x8
    7c0f94500e35:	or     r13,r15
    7c0f94500e38:	movabs rcx,0xffff0000ffff
    7c0f94500e42:	mov    r15,r13
    7c0f94500e45:	and    r15,rcx
    7c0f94500e48:	shl    r15,0x10
    7c0f94500e4c:	movabs rcx,0xffff0000ffff0000
    7c0f94500e56:	and    r13,rcx
    7c0f94500e59:	shr    r13,0x10
    7c0f94500e5d:	or     r13,r15
    7c0f94500e60:	mov    r15,r13
    7c0f94500e63:	shl    r15,0x20
    7c0f94500e67:	shr    r13,0x20
    7c0f94500e6b:	or     r13,r15
    7c0f94500e6e:	mov    QWORD PTR [r12+0x40],r13
    7c0f94500e73:	add    r14,0x78
    7c0f94500e77:	mov    QWORD PTR [r14],r13
    7c0f94500e7a:	mov    r13d,0x0
    7c0f94500e80:	mov    DWORD PTR [r12+0x32c],r13d
    7c0f94500e88:	mov    r13d,0x4102e0
    7c0f94500e8e:	mov    QWORD PTR [r12+0xf0],r13
    7c0f94500e96:	mov    r13d,0x410338
    7c0f94500e9c:	mov    QWORD PTR [r12+0x100],r13
    7c0f94500ea4:	mov    r11,QWORD PTR [rsp]
    7c0f94500ea8:	mov    QWORD PTR [r12+0x398],r11
    7c0f94500eb0:	mov    edi,0x410338
    7c0f94500eb5:	mov    QWORD PTR [r12+0x100],rdi
    7c0f94500ebd:	add    rsp,0x10
    7c0f94500ec1:	nop    DWORD PTR [rax+0x0]
    7c0f94500ec8:	jmp    QWORD PTR [rip+0x2]        # 0x7c0f94500ed0
    7c0f94500ece:	xchg   ax,ax
    7c0f94500ed0:	shl    ah,0x4f
    7c0f94500ed3:	xchg   esp,eax
    7c0f94500ed4:	(bad)
    7c0f94500ed6:	add    BYTE PTR [rax],al
    7c0f94500ed8:	loopne 0x7c0f94500ee8
    7c0f94500eda:	push   rax
    7c0f94500edb:	xchg   esp,eax
    7c0f94500edc:	(bad)
    7c0f94500ede:	add    BYTE PTR [rax],al
    7c0f94500ee0:	movabs r11,0x62016968d940
    7c0f94500eea:	jmp    r11
    7c0f94500eed:	nop    DWORD PTR [rax]
    7c0f94500ef0:	sub    rsp,0x10
    7c0f94500ef4:	mov    r11,QWORD PTR [r12+0x398]
    7c0f94500efc:	mov    QWORD PTR [rsp],r11
    7c0f94500f00:	jmp    0x7c0f94500d56
    7c0f94500f05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c0f94500f10:	sub    rsp,0x10
    7c0f94500f14:	mov    r11,QWORD PTR [r12+0x398]
    7c0f94500f1c:	mov    QWORD PTR [rsp],r11
    7c0f94500f20:	jmp    0x7c0f94500ddd
    7c0f94500f25:	nop
    7c0f94500f26:	nop
    7c0f94500f27:	nop
