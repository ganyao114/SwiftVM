
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/1/1.bin:     file format binary


Disassembly of section .data:

00007c0f944fe4c0 <.data>:
    7c0f944fe4c0:	sub    rsp,0xc0
    7c0f944fe4c7:	mov    r11,QWORD PTR [r12+0x398]
    7c0f944fe4cf:	mov    QWORD PTR [rsp+0xb0],r11
    7c0f944fe4d7:	mov    r13,QWORD PTR [r12]
    7c0f944fe4db:	mov    r14,r13
    7c0f944fe4de:	add    r14,0x20
    7c0f944fe4e2:	mov    r15,QWORD PTR [r14]
    7c0f944fe4e5:	mov    r14,QWORD PTR [r12+0x10]
    7c0f944fe4ea:	add    r15,r14
    7c0f944fe4ed:	mov    QWORD PTR [r12+0x40],r15
    7c0f944fe4f2:	add    r13,0x20
    7c0f944fe4f6:	mov    QWORD PTR [r13+0x0],r15
    7c0f944fe4fa:	mov    r13d,0x0
    7c0f944fe500:	mov    DWORD PTR [r12+0x32c],r13d
    7c0f944fe508:	mov    rax,r14
    7c0f944fe50b:	test   rax,rax
    7c0f944fe50e:	je     0x7c0f94500615
    7c0f944fe514:	jmp    0x7c0f944fe519
    7c0f944fe519:	mov    r13,QWORD PTR [r12+0xf8]
    7c0f944fe521:	sub    r13,0x150
    7c0f944fe528:	mov    QWORD PTR [r12+0xf8],r13
    7c0f944fe530:	mov    r14,QWORD PTR [r12]
    7c0f944fe534:	mov    r15,r14
    7c0f944fe537:	add    r15,0x68
    7c0f944fe53b:	mov    rbp,QWORD PTR [r15]
    7c0f944fe53e:	mov    QWORD PTR [r12+0x88],rbp
    7c0f944fe546:	add    r14,0x28
    7c0f944fe54a:	mov    QWORD PTR [r12+0x40],r14
    7c0f944fe54f:	mov    QWORD PTR [r12+0x48],r13
    7c0f944fe554:	mov    r14d,0x420000
    7c0f944fe55a:	add    r14,0x758
    7c0f944fe561:	mov    QWORD PTR [r12+0x50],r14
    7c0f944fe566:	mov    r14,r13
    7c0f944fe569:	add    r14,0x100
    7c0f944fe570:	mov    r15,r14
    7c0f944fe573:	add    r15,0x8
    7c0f944fe577:	mov    rbp,QWORD PTR [r12+0xe8]
    7c0f944fe57f:	mov    r8,QWORD PTR [r12+0xd8]
    7c0f944fe587:	mov    QWORD PTR [r14],rbp
    7c0f944fe58a:	mov    r14d,0x0
    7c0f944fe590:	mov    DWORD PTR [r12+0x32c],r14d
    7c0f944fe598:	mov    QWORD PTR [r15],r8
    7c0f944fe59b:	mov    r14,r13
    7c0f944fe59e:	add    r14,0x110
    7c0f944fe5a5:	mov    r15,r14
    7c0f944fe5a8:	add    r15,0x8
    7c0f944fe5ac:	mov    rbp,QWORD PTR [r12+0xd0]
    7c0f944fe5b4:	mov    r8,QWORD PTR [r12+0xc8]
    7c0f944fe5bc:	mov    QWORD PTR [r14],rbp
    7c0f944fe5bf:	mov    QWORD PTR [r15],r8
    7c0f944fe5c2:	mov    r14,r13
    7c0f944fe5c5:	add    r14,0x120
    7c0f944fe5cc:	mov    r15,r14
    7c0f944fe5cf:	add    r15,0x8
    7c0f944fe5d3:	mov    rbp,QWORD PTR [r12+0xc0]
    7c0f944fe5db:	mov    r8,QWORD PTR [r12+0xb8]
    7c0f944fe5e3:	mov    QWORD PTR [r14],rbp
    7c0f944fe5e6:	mov    QWORD PTR [r15],r8
    7c0f944fe5e9:	mov    r14,r13
    7c0f944fe5ec:	add    r14,0x130
    7c0f944fe5f3:	mov    r15,r14
    7c0f944fe5f6:	add    r15,0x8
    7c0f944fe5fa:	mov    rbp,QWORD PTR [r12+0xb0]
    7c0f944fe602:	mov    r8,QWORD PTR [r12+0xa8]
    7c0f944fe60a:	mov    QWORD PTR [r14],rbp
    7c0f944fe60d:	mov    QWORD PTR [r15],r8
    7c0f944fe610:	add    r13,0x140
    7c0f944fe617:	mov    r14,r13
    7c0f944fe61a:	add    r14,0x8
    7c0f944fe61e:	mov    r15,QWORD PTR [r12+0xa0]
    7c0f944fe626:	mov    rbp,QWORD PTR [r12+0x98]
    7c0f944fe62e:	mov    QWORD PTR [r13+0x0],r15
    7c0f944fe632:	mov    QWORD PTR [r14],rbp
    7c0f944fe635:	jmp    0x7c0f944fe63a
    7c0f944fe63a:	mov    r13,QWORD PTR [r12+0x8]
    7c0f944fe63f:	mov    r14,r13
    7c0f944fe642:	add    r14,0x1
    7c0f944fe646:	movzx  r15d,BYTE PTR [r13+0x0]
    7c0f944fe64b:	mov    QWORD PTR [r12+0x58],r15
    7c0f944fe650:	mov    QWORD PTR [r12+0x8],r14
    7c0f944fe655:	mov    r13,QWORD PTR [r12+0x88]
    7c0f944fe65d:	mov    r14,r13
    7c0f944fe660:	add    r14,0x1
    7c0f944fe664:	mov    QWORD PTR [r12+0x60],r14
    7c0f944fe669:	mov    r15,QWORD PTR [r12]
    7c0f944fe66d:	mov    rbp,r15
    7c0f944fe670:	add    rbp,0x68
    7c0f944fe674:	mov    QWORD PTR [rbp+0x0],r14
    7c0f944fe678:	mov    r14d,0x0
    7c0f944fe67e:	mov    DWORD PTR [r12+0x32c],r14d
    7c0f944fe686:	mov    r14,r15
    7c0f944fe689:	add    r14,r13
    7c0f944fe68c:	mov    QWORD PTR [r12+0x60],r14
    7c0f944fe691:	add    r14,0x28
    7c0f944fe695:	movzx  r13d,BYTE PTR [r12+0x58]
    7c0f944fe69b:	mov    BYTE PTR [r14],r13b
    7c0f944fe69e:	add    r15,0x68
    7c0f944fe6a2:	mov    r13,QWORD PTR [r15]
    7c0f944fe6a5:	mov    QWORD PTR [r12+0x88],r13
    7c0f944fe6ad:	sub    r13,0x40
    7c0f944fe6b1:	mov    rcx,QWORD PTR [r12+0x380]
    7c0f944fe6b9:	jrcxz  0x7c0f944fe6c0
    7c0f944fe6bb:	jmp    0x7c0f94500660
    7c0f944fe6c0:	jne    0x7c0f944fe6dd
    7c0f944fe6c6:	mov    r11,rax
    7c0f944fe6c9:	lahf
    7c0f944fe6ca:	seto   al
    7c0f944fe6cd:	mov    WORD PTR [rsp+0xb0],ax
    7c0f944fe6d5:	mov    rax,r11
    7c0f944fe6d8:	jmp    0x7c0f944fe6f4
    7c0f944fe6dd:	mov    r11,rax
    7c0f944fe6e0:	lahf
    7c0f944fe6e1:	seto   al
    7c0f944fe6e4:	mov    WORD PTR [rsp+0xb0],ax
    7c0f944fe6ec:	mov    rax,r11
    7c0f944fe6ef:	jmp    0x7c0f94500517
    7c0f944fe6f4:	mov    rax,QWORD PTR [r12+0x40]
    7c0f944fe6f9:	mov    eax,0x0
    7c0f944fe6fe:	mov    QWORD PTR [rsp+0x18],rax
    7c0f944fe703:	mov    eax,0x0
    7c0f944fe708:	mov    QWORD PTR [rsp+0x10],rax
    7c0f944fe70d:	mov    eax,0x0
    7c0f944fe712:	mov    QWORD PTR [rsp+0x8],rax
    7c0f944fe717:	mov    eax,0x0
    7c0f944fe71c:	mov    QWORD PTR [rsp],rax
    7c0f944fe720:	mov    rdi,QWORD PTR [r12+0x40]
    7c0f944fe725:	movzx  r9d,BYTE PTR [rdi]
    7c0f944fe729:	mov    r13,QWORD PTR [rsp+0x18]
    7c0f944fe72e:	or     r13,r9
    7c0f944fe731:	mov    r9,QWORD PTR [r12+0x40]
    7c0f944fe736:	add    r9,0x1
    7c0f944fe73a:	movzx  r8d,BYTE PTR [r9]
    7c0f944fe73e:	mov    r9,QWORD PTR [rsp+0x10]
    7c0f944fe743:	or     r9,r8
    7c0f944fe746:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fe74b:	add    r8,0x2
    7c0f944fe74f:	movzx  ebp,BYTE PTR [r8]
    7c0f944fe753:	mov    r8,QWORD PTR [rsp+0x8]
    7c0f944fe758:	or     r8,rbp
    7c0f944fe75b:	mov    rbp,QWORD PTR [r12+0x40]
    7c0f944fe760:	add    rbp,0x3
    7c0f944fe764:	movzx  r15d,BYTE PTR [rbp+0x0]
    7c0f944fe769:	mov    rbp,QWORD PTR [rsp]
    7c0f944fe76d:	or     rbp,r15
    7c0f944fe770:	mov    r15,QWORD PTR [r12+0x40]
    7c0f944fe775:	add    r15,0x4
    7c0f944fe779:	movzx  r14d,BYTE PTR [r15]
    7c0f944fe77d:	mov    r15,r14
    7c0f944fe780:	shl    r15,0x8
    7c0f944fe784:	or     r13,r15
    7c0f944fe787:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe78c:	add    r14,0x5
    7c0f944fe790:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe794:	mov    r14,r15
    7c0f944fe797:	shl    r14,0x8
    7c0f944fe79b:	or     r9,r14
    7c0f944fe79e:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe7a3:	add    r14,0x6
    7c0f944fe7a7:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe7ab:	mov    r14,r15
    7c0f944fe7ae:	shl    r14,0x8
    7c0f944fe7b2:	or     r8,r14
    7c0f944fe7b5:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe7ba:	add    r14,0x7
    7c0f944fe7be:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe7c2:	mov    r14,r15
    7c0f944fe7c5:	shl    r14,0x8
    7c0f944fe7c9:	or     rbp,r14
    7c0f944fe7cc:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe7d1:	add    r14,0x8
    7c0f944fe7d5:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe7d9:	mov    r14,r15
    7c0f944fe7dc:	shl    r14,0x10
    7c0f944fe7e0:	or     r13,r14
    7c0f944fe7e3:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe7e8:	add    r14,0x9
    7c0f944fe7ec:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe7f0:	mov    r14,r15
    7c0f944fe7f3:	shl    r14,0x10
    7c0f944fe7f7:	or     r9,r14
    7c0f944fe7fa:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe7ff:	add    r14,0xa
    7c0f944fe803:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe807:	mov    r14,r15
    7c0f944fe80a:	shl    r14,0x10
    7c0f944fe80e:	or     r8,r14
    7c0f944fe811:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe816:	add    r14,0xb
    7c0f944fe81a:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe81e:	mov    r14,r15
    7c0f944fe821:	shl    r14,0x10
    7c0f944fe825:	or     rbp,r14
    7c0f944fe828:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe82d:	add    r14,0xc
    7c0f944fe831:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe835:	mov    r14,r15
    7c0f944fe838:	shl    r14,0x18
    7c0f944fe83c:	or     r13,r14
    7c0f944fe83f:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe844:	add    r14,0xd
    7c0f944fe848:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe84c:	mov    r14,r15
    7c0f944fe84f:	shl    r14,0x18
    7c0f944fe853:	or     r9,r14
    7c0f944fe856:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe85b:	add    r14,0xe
    7c0f944fe85f:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe863:	mov    r14,r15
    7c0f944fe866:	shl    r14,0x18
    7c0f944fe86a:	or     r8,r14
    7c0f944fe86d:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe872:	add    r14,0xf
    7c0f944fe876:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe87a:	mov    r14,r15
    7c0f944fe87d:	shl    r14,0x18
    7c0f944fe881:	or     rbp,r14
    7c0f944fe884:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe889:	add    r14,0x10
    7c0f944fe88d:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe891:	mov    r14,r15
    7c0f944fe894:	shl    r14,0x20
    7c0f944fe898:	or     r13,r14
    7c0f944fe89b:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe8a0:	add    r14,0x11
    7c0f944fe8a4:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe8a8:	mov    r14,r15
    7c0f944fe8ab:	shl    r14,0x20
    7c0f944fe8af:	or     r9,r14
    7c0f944fe8b2:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe8b7:	add    r14,0x12
    7c0f944fe8bb:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe8bf:	mov    r14,r15
    7c0f944fe8c2:	shl    r14,0x20
    7c0f944fe8c6:	or     r8,r14
    7c0f944fe8c9:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe8ce:	add    r14,0x13
    7c0f944fe8d2:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe8d6:	mov    r14,r15
    7c0f944fe8d9:	shl    r14,0x20
    7c0f944fe8dd:	or     rbp,r14
    7c0f944fe8e0:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe8e5:	add    r14,0x14
    7c0f944fe8e9:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe8ed:	mov    r14,r15
    7c0f944fe8f0:	shl    r14,0x28
    7c0f944fe8f4:	or     r13,r14
    7c0f944fe8f7:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe8fc:	add    r14,0x15
    7c0f944fe900:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe904:	mov    r14,r15
    7c0f944fe907:	shl    r14,0x28
    7c0f944fe90b:	or     r9,r14
    7c0f944fe90e:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe913:	add    r14,0x16
    7c0f944fe917:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe91b:	mov    r14,r15
    7c0f944fe91e:	shl    r14,0x28
    7c0f944fe922:	or     r8,r14
    7c0f944fe925:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe92a:	add    r14,0x17
    7c0f944fe92e:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe932:	mov    r14,r15
    7c0f944fe935:	shl    r14,0x28
    7c0f944fe939:	or     rbp,r14
    7c0f944fe93c:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe941:	add    r14,0x18
    7c0f944fe945:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe949:	mov    r14,r15
    7c0f944fe94c:	shl    r14,0x30
    7c0f944fe950:	or     r13,r14
    7c0f944fe953:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe958:	add    r14,0x19
    7c0f944fe95c:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe960:	mov    r14,r15
    7c0f944fe963:	shl    r14,0x30
    7c0f944fe967:	or     r9,r14
    7c0f944fe96a:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe96f:	add    r14,0x1a
    7c0f944fe973:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe977:	mov    r14,r15
    7c0f944fe97a:	shl    r14,0x30
    7c0f944fe97e:	or     r8,r14
    7c0f944fe981:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe986:	add    r14,0x1b
    7c0f944fe98a:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe98e:	mov    r14,r15
    7c0f944fe991:	shl    r14,0x30
    7c0f944fe995:	or     rbp,r14
    7c0f944fe998:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe99d:	add    r14,0x1c
    7c0f944fe9a1:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe9a5:	mov    r14,r15
    7c0f944fe9a8:	shl    r14,0x38
    7c0f944fe9ac:	mov    rax,r13
    7c0f944fe9af:	or     rax,r14
    7c0f944fe9b2:	mov    QWORD PTR [rsp+0x28],rax
    7c0f944fe9b7:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe9bc:	add    r14,0x1d
    7c0f944fe9c0:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe9c4:	mov    r14,r15
    7c0f944fe9c7:	shl    r14,0x38
    7c0f944fe9cb:	mov    rax,r9
    7c0f944fe9ce:	or     rax,r14
    7c0f944fe9d1:	mov    QWORD PTR [rsp+0x38],rax
    7c0f944fe9d6:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe9db:	add    r14,0x1e
    7c0f944fe9df:	movzx  r15d,BYTE PTR [r14]
    7c0f944fe9e3:	mov    r14,r15
    7c0f944fe9e6:	shl    r14,0x38
    7c0f944fe9ea:	mov    rax,r8
    7c0f944fe9ed:	or     rax,r14
    7c0f944fe9f0:	mov    QWORD PTR [rsp+0x30],rax
    7c0f944fe9f5:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fe9fa:	add    r14,0x1f
    7c0f944fe9fe:	movzx  r15d,BYTE PTR [r14]
    7c0f944fea02:	mov    r14,r15
    7c0f944fea05:	shl    r14,0x38
    7c0f944fea09:	mov    rax,rbp
    7c0f944fea0c:	or     rax,r14
    7c0f944fea0f:	mov    QWORD PTR [rsp+0x20],rax
    7c0f944fea14:	mov    r14,QWORD PTR [r12+0x40]
    7c0f944fea19:	add    r14,0x20
    7c0f944fea1d:	movzx  r15d,BYTE PTR [r14]
    7c0f944fea21:	mov    r14,QWORD PTR [rsp+0x18]
    7c0f944fea26:	or     r14,r15
    7c0f944fea29:	mov    r15,QWORD PTR [r12+0x40]
    7c0f944fea2e:	add    r15,0x21
    7c0f944fea32:	movzx  ebp,BYTE PTR [r15]
    7c0f944fea36:	mov    r15,QWORD PTR [rsp+0x10]
    7c0f944fea3b:	or     r15,rbp
    7c0f944fea3e:	mov    rbp,QWORD PTR [r12+0x40]
    7c0f944fea43:	add    rbp,0x22
    7c0f944fea47:	movzx  r13d,BYTE PTR [rbp+0x0]
    7c0f944fea4c:	mov    rbp,QWORD PTR [rsp+0x8]
    7c0f944fea51:	or     rbp,r13
    7c0f944fea54:	mov    r13,QWORD PTR [r12+0x40]
    7c0f944fea59:	add    r13,0x23
    7c0f944fea5d:	movzx  r8d,BYTE PTR [r13+0x0]
    7c0f944fea62:	mov    r13,QWORD PTR [rsp]
    7c0f944fea66:	or     r13,r8
    7c0f944fea69:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fea6e:	add    r8,0x24
    7c0f944fea72:	movzx  r9d,BYTE PTR [r8]
    7c0f944fea76:	mov    r8,r9
    7c0f944fea79:	shl    r8,0x8
    7c0f944fea7d:	or     r14,r8
    7c0f944fea80:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fea85:	add    r8,0x25
    7c0f944fea89:	movzx  r9d,BYTE PTR [r8]
    7c0f944fea8d:	mov    r8,r9
    7c0f944fea90:	shl    r8,0x8
    7c0f944fea94:	or     r15,r8
    7c0f944fea97:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fea9c:	add    r8,0x26
    7c0f944feaa0:	movzx  r9d,BYTE PTR [r8]
    7c0f944feaa4:	mov    r8,r9
    7c0f944feaa7:	shl    r8,0x8
    7c0f944feaab:	or     rbp,r8
    7c0f944feaae:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944feab3:	add    r8,0x27
    7c0f944feab7:	movzx  r9d,BYTE PTR [r8]
    7c0f944feabb:	mov    r8,r9
    7c0f944feabe:	shl    r8,0x8
    7c0f944feac2:	or     r13,r8
    7c0f944feac5:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944feaca:	add    r8,0x28
    7c0f944feace:	movzx  r9d,BYTE PTR [r8]
    7c0f944fead2:	mov    r8,r9
    7c0f944fead5:	shl    r8,0x10
    7c0f944fead9:	or     r14,r8
    7c0f944feadc:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944feae1:	add    r8,0x29
    7c0f944feae5:	movzx  r9d,BYTE PTR [r8]
    7c0f944feae9:	mov    r8,r9
    7c0f944feaec:	shl    r8,0x10
    7c0f944feaf0:	or     r15,r8
    7c0f944feaf3:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944feaf8:	add    r8,0x2a
    7c0f944feafc:	movzx  r9d,BYTE PTR [r8]
    7c0f944feb00:	mov    r8,r9
    7c0f944feb03:	shl    r8,0x10
    7c0f944feb07:	or     rbp,r8
    7c0f944feb0a:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944feb0f:	add    r8,0x2b
    7c0f944feb13:	movzx  r9d,BYTE PTR [r8]
    7c0f944feb17:	mov    r8,r9
    7c0f944feb1a:	shl    r8,0x10
    7c0f944feb1e:	or     r13,r8
    7c0f944feb21:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944feb26:	add    r8,0x2c
    7c0f944feb2a:	movzx  r9d,BYTE PTR [r8]
    7c0f944feb2e:	mov    r8,r9
    7c0f944feb31:	shl    r8,0x18
    7c0f944feb35:	or     r14,r8
    7c0f944feb38:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944feb3d:	add    r8,0x2d
    7c0f944feb41:	movzx  r9d,BYTE PTR [r8]
    7c0f944feb45:	mov    r8,r9
    7c0f944feb48:	shl    r8,0x18
    7c0f944feb4c:	or     r15,r8
    7c0f944feb4f:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944feb54:	add    r8,0x2e
    7c0f944feb58:	movzx  r9d,BYTE PTR [r8]
    7c0f944feb5c:	mov    r8,r9
    7c0f944feb5f:	shl    r8,0x18
    7c0f944feb63:	or     rbp,r8
    7c0f944feb66:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944feb6b:	add    r8,0x2f
    7c0f944feb6f:	movzx  r9d,BYTE PTR [r8]
    7c0f944feb73:	mov    r8,r9
    7c0f944feb76:	shl    r8,0x18
    7c0f944feb7a:	or     r13,r8
    7c0f944feb7d:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944feb82:	add    r8,0x30
    7c0f944feb86:	movzx  r9d,BYTE PTR [r8]
    7c0f944feb8a:	mov    r8,r9
    7c0f944feb8d:	shl    r8,0x20
    7c0f944feb91:	or     r14,r8
    7c0f944feb94:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944feb99:	add    r8,0x31
    7c0f944feb9d:	movzx  r9d,BYTE PTR [r8]
    7c0f944feba1:	mov    r8,r9
    7c0f944feba4:	shl    r8,0x20
    7c0f944feba8:	or     r15,r8
    7c0f944febab:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944febb0:	add    r8,0x32
    7c0f944febb4:	movzx  r9d,BYTE PTR [r8]
    7c0f944febb8:	mov    r8,r9
    7c0f944febbb:	shl    r8,0x20
    7c0f944febbf:	or     rbp,r8
    7c0f944febc2:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944febc7:	add    r8,0x33
    7c0f944febcb:	movzx  r9d,BYTE PTR [r8]
    7c0f944febcf:	mov    r8,r9
    7c0f944febd2:	shl    r8,0x20
    7c0f944febd6:	or     r13,r8
    7c0f944febd9:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944febde:	add    r8,0x34
    7c0f944febe2:	movzx  r9d,BYTE PTR [r8]
    7c0f944febe6:	mov    r8,r9
    7c0f944febe9:	shl    r8,0x28
    7c0f944febed:	or     r14,r8
    7c0f944febf0:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944febf5:	add    r8,0x35
    7c0f944febf9:	movzx  r9d,BYTE PTR [r8]
    7c0f944febfd:	mov    r8,r9
    7c0f944fec00:	shl    r8,0x28
    7c0f944fec04:	or     r15,r8
    7c0f944fec07:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fec0c:	add    r8,0x36
    7c0f944fec10:	movzx  r9d,BYTE PTR [r8]
    7c0f944fec14:	mov    r8,r9
    7c0f944fec17:	shl    r8,0x28
    7c0f944fec1b:	or     rbp,r8
    7c0f944fec1e:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fec23:	add    r8,0x37
    7c0f944fec27:	movzx  r9d,BYTE PTR [r8]
    7c0f944fec2b:	mov    r8,r9
    7c0f944fec2e:	shl    r8,0x28
    7c0f944fec32:	or     r13,r8
    7c0f944fec35:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fec3a:	add    r8,0x38
    7c0f944fec3e:	movzx  r9d,BYTE PTR [r8]
    7c0f944fec42:	mov    r8,r9
    7c0f944fec45:	shl    r8,0x30
    7c0f944fec49:	or     r14,r8
    7c0f944fec4c:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fec51:	add    r8,0x39
    7c0f944fec55:	movzx  r9d,BYTE PTR [r8]
    7c0f944fec59:	mov    r8,r9
    7c0f944fec5c:	shl    r8,0x30
    7c0f944fec60:	or     r15,r8
    7c0f944fec63:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fec68:	add    r8,0x3a
    7c0f944fec6c:	movzx  r9d,BYTE PTR [r8]
    7c0f944fec70:	mov    r8,r9
    7c0f944fec73:	shl    r8,0x30
    7c0f944fec77:	or     rbp,r8
    7c0f944fec7a:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fec7f:	add    r8,0x3b
    7c0f944fec83:	movzx  r9d,BYTE PTR [r8]
    7c0f944fec87:	mov    r8,r9
    7c0f944fec8a:	shl    r8,0x30
    7c0f944fec8e:	or     r13,r8
    7c0f944fec91:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fec96:	add    r8,0x3c
    7c0f944fec9a:	movzx  r9d,BYTE PTR [r8]
    7c0f944fec9e:	mov    r8,r9
    7c0f944feca1:	shl    r8,0x38
    7c0f944feca5:	or     r14,r8
    7c0f944feca8:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fecad:	add    r8,0x3d
    7c0f944fecb1:	movzx  r9d,BYTE PTR [r8]
    7c0f944fecb5:	mov    r8,r9
    7c0f944fecb8:	shl    r8,0x38
    7c0f944fecbc:	or     r15,r8
    7c0f944fecbf:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fecc4:	add    r8,0x3e
    7c0f944fecc8:	movzx  r9d,BYTE PTR [r8]
    7c0f944feccc:	mov    r8,r9
    7c0f944feccf:	shl    r8,0x38
    7c0f944fecd3:	or     rbp,r8
    7c0f944fecd6:	mov    r8,QWORD PTR [r12+0x40]
    7c0f944fecdb:	add    r8,0x3f
    7c0f944fecdf:	movzx  r9d,BYTE PTR [r8]
    7c0f944fece3:	mov    r8,r9
    7c0f944fece6:	shl    r8,0x38
    7c0f944fecea:	mov    rax,r13
    7c0f944feced:	or     rax,r8
    7c0f944fecf0:	mov    QWORD PTR [rsp+0x40],rax
    7c0f944fecf5:	mov    r8d,0x0
    7c0f944fecfb:	mov    QWORD PTR [r12+0x58],r8
    7c0f944fed00:	mov    r8d,0x0
    7c0f944fed06:	mov    r9,QWORD PTR [rsp+0x38]
    7c0f944fed0b:	and    r9,0xff
    7c0f944fed12:	and    r9,0xffff
    7c0f944fed19:	mov    r13,r8
    7c0f944fed1c:	or     r13,r9
    7c0f944fed1f:	mov    r9,QWORD PTR [rsp+0x38]
    7c0f944fed24:	shr    r9,0x8
    7c0f944fed28:	and    r9,0xff
    7c0f944fed2f:	and    r9,0xffff
    7c0f944fed36:	shl    r9,0x10
    7c0f944fed3a:	or     r13,r9
    7c0f944fed3d:	mov    r9,QWORD PTR [rsp+0x38]
    7c0f944fed42:	shr    r9,0x10
    7c0f944fed46:	and    r9,0xff
    7c0f944fed4d:	and    r9,0xffff
    7c0f944fed54:	shl    r9,0x20
    7c0f944fed58:	or     r13,r9
    7c0f944fed5b:	mov    r9,QWORD PTR [rsp+0x38]
    7c0f944fed60:	shr    r9,0x18
    7c0f944fed64:	and    r9,0xff
    7c0f944fed6b:	and    r9,0xffff
    7c0f944fed72:	shl    r9,0x30
    7c0f944fed76:	or     r13,r9
    7c0f944fed79:	mov    r9,QWORD PTR [rsp+0x38]
    7c0f944fed7e:	shr    r9,0x20
    7c0f944fed82:	and    r9,0xff
    7c0f944fed89:	and    r9,0xffff
    7c0f944fed90:	or     r8,r9
    7c0f944fed93:	mov    r9,QWORD PTR [rsp+0x38]
    7c0f944fed98:	shr    r9,0x28
    7c0f944fed9c:	and    r9,0xff
    7c0f944feda3:	and    r9,0xffff
    7c0f944fedaa:	shl    r9,0x10
    7c0f944fedae:	or     r8,r9
    7c0f944fedb1:	mov    r9,QWORD PTR [rsp+0x38]
    7c0f944fedb6:	shr    r9,0x30
    7c0f944fedba:	and    r9,0xff
    7c0f944fedc1:	and    r9,0xffff
    7c0f944fedc8:	shl    r9,0x20
    7c0f944fedcc:	or     r8,r9
    7c0f944fedcf:	mov    r9,QWORD PTR [rsp+0x38]
    7c0f944fedd4:	shr    r9,0x38
    7c0f944fedd8:	and    r9,0xff
    7c0f944feddf:	and    r9,0xffff
    7c0f944fede6:	shl    r9,0x30
    7c0f944fedea:	or     r8,r9
    7c0f944feded:	mov    QWORD PTR [r12+0x150],r13
    7c0f944fedf5:	mov    QWORD PTR [r12+0x158],r8
    7c0f944fedfd:	mov    r13d,0x0
    7c0f944fee03:	mov    r8,QWORD PTR [rsp+0x30]
    7c0f944fee08:	and    r8,0xff
    7c0f944fee0f:	and    r8,0xffff
    7c0f944fee16:	mov    r9,r13
    7c0f944fee19:	or     r9,r8
    7c0f944fee1c:	mov    r8,QWORD PTR [rsp+0x30]
    7c0f944fee21:	shr    r8,0x8
    7c0f944fee25:	and    r8,0xff
    7c0f944fee2c:	and    r8,0xffff
    7c0f944fee33:	shl    r8,0x10
    7c0f944fee37:	or     r9,r8
    7c0f944fee3a:	mov    r8,QWORD PTR [rsp+0x30]
    7c0f944fee3f:	shr    r8,0x10
    7c0f944fee43:	and    r8,0xff
    7c0f944fee4a:	and    r8,0xffff
    7c0f944fee51:	shl    r8,0x20
    7c0f944fee55:	or     r9,r8
    7c0f944fee58:	mov    r8,QWORD PTR [rsp+0x30]
    7c0f944fee5d:	shr    r8,0x18
    7c0f944fee61:	and    r8,0xff
    7c0f944fee68:	and    r8,0xffff
    7c0f944fee6f:	shl    r8,0x30
    7c0f944fee73:	mov    rax,r9
    7c0f944fee76:	or     rax,r8
    7c0f944fee79:	mov    QWORD PTR [rsp+0x50],rax
    7c0f944fee7e:	mov    r8,QWORD PTR [rsp+0x30]
    7c0f944fee83:	shr    r8,0x20
    7c0f944fee87:	and    r8,0xff
    7c0f944fee8e:	and    r8,0xffff
    7c0f944fee95:	or     r13,r8
    7c0f944fee98:	mov    r8,QWORD PTR [rsp+0x30]
    7c0f944fee9d:	shr    r8,0x28
    7c0f944feea1:	and    r8,0xff
    7c0f944feea8:	and    r8,0xffff
    7c0f944feeaf:	shl    r8,0x10
    7c0f944feeb3:	or     r13,r8
    7c0f944feeb6:	mov    r8,QWORD PTR [rsp+0x30]
    7c0f944feebb:	shr    r8,0x30
    7c0f944feebf:	and    r8,0xff
    7c0f944feec6:	and    r8,0xffff
    7c0f944feecd:	shl    r8,0x20
    7c0f944feed1:	or     r13,r8
    7c0f944feed4:	mov    r8,QWORD PTR [rsp+0x30]
    7c0f944feed9:	shr    r8,0x38
    7c0f944feedd:	and    r8,0xff
    7c0f944feee4:	and    r8,0xffff
    7c0f944feeeb:	shl    r8,0x30
    7c0f944feeef:	mov    rax,r13
    7c0f944feef2:	or     rax,r8
    7c0f944feef5:	mov    QWORD PTR [rsp+0x48],rax
    7c0f944feefa:	mov    r8d,0x0
    7c0f944fef00:	mov    r13,QWORD PTR [rsp+0x28]
    7c0f944fef05:	and    r13,0xff
    7c0f944fef0c:	and    r13,0xffff
    7c0f944fef13:	mov    r9,r8
    7c0f944fef16:	or     r9,r13
    7c0f944fef19:	mov    r13,QWORD PTR [rsp+0x28]
    7c0f944fef1e:	shr    r13,0x8
    7c0f944fef22:	and    r13,0xff
    7c0f944fef29:	and    r13,0xffff
    7c0f944fef30:	shl    r13,0x10
    7c0f944fef34:	or     r9,r13
    7c0f944fef37:	mov    r13,QWORD PTR [rsp+0x28]
    7c0f944fef3c:	shr    r13,0x10
    7c0f944fef40:	and    r13,0xff
    7c0f944fef47:	and    r13,0xffff
    7c0f944fef4e:	shl    r13,0x20
    7c0f944fef52:	or     r9,r13
    7c0f944fef55:	mov    r13,QWORD PTR [rsp+0x28]
    7c0f944fef5a:	shr    r13,0x18
    7c0f944fef5e:	and    r13,0xff
    7c0f944fef65:	and    r13,0xffff
    7c0f944fef6c:	shl    r13,0x30
    7c0f944fef70:	mov    rax,r9
    7c0f944fef73:	or     rax,r13
    7c0f944fef76:	mov    QWORD PTR [rsp+0x58],rax
    7c0f944fef7b:	mov    r13,QWORD PTR [rsp+0x28]
    7c0f944fef80:	shr    r13,0x20
    7c0f944fef84:	and    r13,0xff
    7c0f944fef8b:	and    r13,0xffff
    7c0f944fef92:	or     r8,r13
    7c0f944fef95:	mov    r13,QWORD PTR [rsp+0x28]
    7c0f944fef9a:	shr    r13,0x28
    7c0f944fef9e:	and    r13,0xff
    7c0f944fefa5:	and    r13,0xffff
    7c0f944fefac:	shl    r13,0x10
    7c0f944fefb0:	or     r8,r13
    7c0f944fefb3:	mov    r13,QWORD PTR [rsp+0x28]
    7c0f944fefb8:	shr    r13,0x30
    7c0f944fefbc:	and    r13,0xff
    7c0f944fefc3:	and    r13,0xffff
    7c0f944fefca:	shl    r13,0x20
    7c0f944fefce:	or     r8,r13
    7c0f944fefd1:	mov    r13,QWORD PTR [rsp+0x28]
    7c0f944fefd6:	shr    r13,0x38
    7c0f944fefda:	and    r13,0xff
    7c0f944fefe1:	and    r13,0xffff
    7c0f944fefe8:	shl    r13,0x30
    7c0f944fefec:	mov    rax,r8
    7c0f944fefef:	or     rax,r13
    7c0f944feff2:	mov    QWORD PTR [rsp+0x60],rax
    7c0f944feff7:	mov    r13d,0x0
    7c0f944feffd:	mov    r9,r14
    7c0f944ff000:	and    r9,0xff
    7c0f944ff007:	and    r9,0xffff
    7c0f944ff00e:	mov    r8,r13
    7c0f944ff011:	or     r8,r9
    7c0f944ff014:	mov    r9,r14
    7c0f944ff017:	shr    r9,0x8
    7c0f944ff01b:	and    r9,0xff
    7c0f944ff022:	and    r9,0xffff
    7c0f944ff029:	shl    r9,0x10
    7c0f944ff02d:	or     r8,r9
    7c0f944ff030:	mov    r9,r14
    7c0f944ff033:	shr    r9,0x10
    7c0f944ff037:	and    r9,0xff
    7c0f944ff03e:	and    r9,0xffff
    7c0f944ff045:	shl    r9,0x20
    7c0f944ff049:	or     r8,r9
    7c0f944ff04c:	mov    r9,r14
    7c0f944ff04f:	shr    r9,0x18
    7c0f944ff053:	and    r9,0xff
    7c0f944ff05a:	and    r9,0xffff
    7c0f944ff061:	shl    r9,0x30
    7c0f944ff065:	mov    rax,r8
    7c0f944ff068:	or     rax,r9
    7c0f944ff06b:	mov    QWORD PTR [rsp+0x68],rax
    7c0f944ff070:	mov    r9,r14
    7c0f944ff073:	shr    r9,0x20
    7c0f944ff077:	and    r9,0xff
    7c0f944ff07e:	and    r9,0xffff
    7c0f944ff085:	or     r13,r9
    7c0f944ff088:	mov    r9,r14
    7c0f944ff08b:	shr    r9,0x28
    7c0f944ff08f:	and    r9,0xff
    7c0f944ff096:	and    r9,0xffff
    7c0f944ff09d:	shl    r9,0x10
    7c0f944ff0a1:	or     r13,r9
    7c0f944ff0a4:	mov    r9,r14
    7c0f944ff0a7:	shr    r9,0x30
    7c0f944ff0ab:	and    r9,0xff
    7c0f944ff0b2:	and    r9,0xffff
    7c0f944ff0b9:	shl    r9,0x20
    7c0f944ff0bd:	or     r13,r9
    7c0f944ff0c0:	shr    r14,0x38
    7c0f944ff0c4:	and    r14,0xff
    7c0f944ff0cb:	and    r14,0xffff
    7c0f944ff0d2:	shl    r14,0x30
    7c0f944ff0d6:	or     r13,r14
    7c0f944ff0d9:	mov    r14d,0x0
    7c0f944ff0df:	mov    r9,r15
    7c0f944ff0e2:	and    r9,0xff
    7c0f944ff0e9:	and    r9,0xffff
    7c0f944ff0f0:	mov    r8,r14
    7c0f944ff0f3:	or     r8,r9
    7c0f944ff0f6:	mov    r9,r15
    7c0f944ff0f9:	shr    r9,0x8
    7c0f944ff0fd:	and    r9,0xff
    7c0f944ff104:	and    r9,0xffff
    7c0f944ff10b:	shl    r9,0x10
    7c0f944ff10f:	or     r8,r9
    7c0f944ff112:	mov    r9,r15
    7c0f944ff115:	shr    r9,0x10
    7c0f944ff119:	and    r9,0xff
    7c0f944ff120:	and    r9,0xffff
    7c0f944ff127:	shl    r9,0x20
    7c0f944ff12b:	or     r8,r9
    7c0f944ff12e:	mov    r9,r15
    7c0f944ff131:	shr    r9,0x18
    7c0f944ff135:	and    r9,0xff
    7c0f944ff13c:	and    r9,0xffff
    7c0f944ff143:	shl    r9,0x30
    7c0f944ff147:	or     r8,r9
    7c0f944ff14a:	mov    r9,r15
    7c0f944ff14d:	shr    r9,0x20
    7c0f944ff151:	and    r9,0xff
    7c0f944ff158:	and    r9,0xffff
    7c0f944ff15f:	or     r14,r9
    7c0f944ff162:	mov    r9,r15
    7c0f944ff165:	shr    r9,0x28
    7c0f944ff169:	and    r9,0xff
    7c0f944ff170:	and    r9,0xffff
    7c0f944ff177:	shl    r9,0x10
    7c0f944ff17b:	or     r14,r9
    7c0f944ff17e:	mov    r9,r15
    7c0f944ff181:	shr    r9,0x30
    7c0f944ff185:	and    r9,0xff
    7c0f944ff18c:	and    r9,0xffff
    7c0f944ff193:	shl    r9,0x20
    7c0f944ff197:	or     r14,r9
    7c0f944ff19a:	shr    r15,0x38
    7c0f944ff19e:	and    r15,0xff
    7c0f944ff1a5:	and    r15,0xffff
    7c0f944ff1ac:	shl    r15,0x30
    7c0f944ff1b0:	or     r14,r15
    7c0f944ff1b3:	mov    QWORD PTR [r12+0x210],r8
    7c0f944ff1bb:	mov    QWORD PTR [r12+0x218],r14
    7c0f944ff1c3:	mov    r14d,0x0
    7c0f944ff1c9:	mov    r15,rbp
    7c0f944ff1cc:	and    r15,0xff
    7c0f944ff1d3:	and    r15,0xffff
    7c0f944ff1da:	mov    r8,r14
    7c0f944ff1dd:	or     r8,r15
    7c0f944ff1e0:	mov    r15,rbp
    7c0f944ff1e3:	shr    r15,0x8
    7c0f944ff1e7:	and    r15,0xff
    7c0f944ff1ee:	and    r15,0xffff
    7c0f944ff1f5:	shl    r15,0x10
    7c0f944ff1f9:	or     r8,r15
    7c0f944ff1fc:	mov    r15,rbp
    7c0f944ff1ff:	shr    r15,0x10
    7c0f944ff203:	and    r15,0xff
    7c0f944ff20a:	and    r15,0xffff
    7c0f944ff211:	shl    r15,0x20
    7c0f944ff215:	or     r8,r15
    7c0f944ff218:	mov    r15,rbp
    7c0f944ff21b:	shr    r15,0x18
    7c0f944ff21f:	and    r15,0xff
    7c0f944ff226:	and    r15,0xffff
    7c0f944ff22d:	shl    r15,0x30
    7c0f944ff231:	or     r8,r15
    7c0f944ff234:	mov    r15,rbp
    7c0f944ff237:	shr    r15,0x20
    7c0f944ff23b:	and    r15,0xff
    7c0f944ff242:	and    r15,0xffff
    7c0f944ff249:	or     r14,r15
    7c0f944ff24c:	mov    r15,rbp
    7c0f944ff24f:	shr    r15,0x28
    7c0f944ff253:	and    r15,0xff
    7c0f944ff25a:	and    r15,0xffff
    7c0f944ff261:	shl    r15,0x10
    7c0f944ff265:	or     r14,r15
    7c0f944ff268:	mov    r15,rbp
    7c0f944ff26b:	shr    r15,0x30
    7c0f944ff26f:	and    r15,0xff
    7c0f944ff276:	and    r15,0xffff
    7c0f944ff27d:	shl    r15,0x20
    7c0f944ff281:	or     r14,r15
    7c0f944ff284:	shr    rbp,0x38
    7c0f944ff288:	and    rbp,0xff
    7c0f944ff28f:	and    rbp,0xffff
    7c0f944ff296:	shl    rbp,0x30
    7c0f944ff29a:	or     r14,rbp
    7c0f944ff29d:	mov    r15d,0x0
    7c0f944ff2a3:	mov    rbp,QWORD PTR [rsp+0x20]
    7c0f944ff2a8:	and    rbp,0xff
    7c0f944ff2af:	and    rbp,0xffff
    7c0f944ff2b6:	mov    r9,r15
    7c0f944ff2b9:	or     r9,rbp
    7c0f944ff2bc:	mov    rbp,QWORD PTR [rsp+0x20]
    7c0f944ff2c1:	shr    rbp,0x8
    7c0f944ff2c5:	and    rbp,0xff
    7c0f944ff2cc:	and    rbp,0xffff
    7c0f944ff2d3:	shl    rbp,0x10
    7c0f944ff2d7:	or     r9,rbp
    7c0f944ff2da:	mov    rbp,QWORD PTR [rsp+0x20]
    7c0f944ff2df:	shr    rbp,0x10
    7c0f944ff2e3:	and    rbp,0xff
    7c0f944ff2ea:	and    rbp,0xffff
    7c0f944ff2f1:	shl    rbp,0x20
    7c0f944ff2f5:	or     r9,rbp
    7c0f944ff2f8:	mov    rbp,QWORD PTR [rsp+0x20]
    7c0f944ff2fd:	shr    rbp,0x18
    7c0f944ff301:	and    rbp,0xff
    7c0f944ff308:	and    rbp,0xffff
    7c0f944ff30f:	shl    rbp,0x30
    7c0f944ff313:	mov    rax,r9
    7c0f944ff316:	or     rax,rbp
    7c0f944ff319:	mov    QWORD PTR [rsp+0x78],rax
    7c0f944ff31e:	mov    rbp,QWORD PTR [rsp+0x20]
    7c0f944ff323:	shr    rbp,0x20
    7c0f944ff327:	and    rbp,0xff
    7c0f944ff32e:	and    rbp,0xffff
    7c0f944ff335:	or     r15,rbp
    7c0f944ff338:	mov    rbp,QWORD PTR [rsp+0x20]
    7c0f944ff33d:	shr    rbp,0x28
    7c0f944ff341:	and    rbp,0xff
    7c0f944ff348:	and    rbp,0xffff
    7c0f944ff34f:	shl    rbp,0x10
    7c0f944ff353:	or     r15,rbp
    7c0f944ff356:	mov    rbp,QWORD PTR [rsp+0x20]
    7c0f944ff35b:	shr    rbp,0x30
    7c0f944ff35f:	and    rbp,0xff
    7c0f944ff366:	and    rbp,0xffff
    7c0f944ff36d:	shl    rbp,0x20
    7c0f944ff371:	or     r15,rbp
    7c0f944ff374:	mov    rbp,QWORD PTR [rsp+0x20]
    7c0f944ff379:	shr    rbp,0x38
    7c0f944ff37d:	and    rbp,0xff
    7c0f944ff384:	and    rbp,0xffff
    7c0f944ff38b:	shl    rbp,0x30
    7c0f944ff38f:	mov    rax,r15
    7c0f944ff392:	or     rax,rbp
    7c0f944ff395:	mov    QWORD PTR [rsp+0x70],rax
    7c0f944ff39a:	mov    rax,QWORD PTR [rsp+0x78]
    7c0f944ff39f:	mov    QWORD PTR [r12+0x250],rax
    7c0f944ff3a7:	mov    rax,QWORD PTR [rsp+0x70]
    7c0f944ff3ac:	mov    QWORD PTR [r12+0x258],rax
    7c0f944ff3b4:	mov    ebp,0x0
    7c0f944ff3b9:	mov    r15,QWORD PTR [rsp+0x40]
    7c0f944ff3be:	and    r15,0xff
    7c0f944ff3c5:	and    r15,0xffff
    7c0f944ff3cc:	mov    r9,rbp
    7c0f944ff3cf:	or     r9,r15
    7c0f944ff3d2:	mov    r15,QWORD PTR [rsp+0x40]
    7c0f944ff3d7:	shr    r15,0x8
    7c0f944ff3db:	and    r15,0xff
    7c0f944ff3e2:	and    r15,0xffff
    7c0f944ff3e9:	shl    r15,0x10
    7c0f944ff3ed:	or     r9,r15
    7c0f944ff3f0:	mov    r15,QWORD PTR [rsp+0x40]
    7c0f944ff3f5:	shr    r15,0x10
    7c0f944ff3f9:	and    r15,0xff
    7c0f944ff400:	and    r15,0xffff
    7c0f944ff407:	shl    r15,0x20
    7c0f944ff40b:	or     r9,r15
    7c0f944ff40e:	mov    r15,QWORD PTR [rsp+0x40]
    7c0f944ff413:	shr    r15,0x18
    7c0f944ff417:	and    r15,0xff
    7c0f944ff41e:	and    r15,0xffff
    7c0f944ff425:	shl    r15,0x30
    7c0f944ff429:	mov    rax,r9
    7c0f944ff42c:	or     rax,r15
    7c0f944ff42f:	mov    QWORD PTR [rsp+0x80],rax
    7c0f944ff437:	mov    r15,QWORD PTR [rsp+0x40]
    7c0f944ff43c:	shr    r15,0x20
    7c0f944ff440:	and    r15,0xff
    7c0f944ff447:	and    r15,0xffff
    7c0f944ff44e:	or     rbp,r15
    7c0f944ff451:	mov    r15,QWORD PTR [rsp+0x40]
    7c0f944ff456:	shr    r15,0x28
    7c0f944ff45a:	and    r15,0xff
    7c0f944ff461:	and    r15,0xffff
    7c0f944ff468:	shl    r15,0x10
    7c0f944ff46c:	or     rbp,r15
    7c0f944ff46f:	mov    r15,QWORD PTR [rsp+0x40]
    7c0f944ff474:	shr    r15,0x30
    7c0f944ff478:	and    r15,0xff
    7c0f944ff47f:	and    r15,0xffff
    7c0f944ff486:	shl    r15,0x20
    7c0f944ff48a:	or     rbp,r15
    7c0f944ff48d:	mov    r15,QWORD PTR [rsp+0x40]
    7c0f944ff492:	shr    r15,0x38
    7c0f944ff496:	and    r15,0xff
    7c0f944ff49d:	and    r15,0xffff
    7c0f944ff4a4:	shl    r15,0x30
    7c0f944ff4a8:	mov    rax,rbp
    7c0f944ff4ab:	or     rax,r15
    7c0f944ff4ae:	mov    QWORD PTR [rsp+0x88],rax
    7c0f944ff4b6:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    7c0f944ff4c0:	pxor   xmm0,xmm0
    7c0f944ff4c4:	movdqa xmm3,xmm0
    7c0f944ff4c8:	movdqa xmm0,xmm2
    7c0f944ff4cc:	movdqa xmm1,xmm3
    7c0f944ff4d0:	punpcklwd xmm0,xmm1
    7c0f944ff4d4:	movdqa xmm4,xmm0
    7c0f944ff4d8:	movdqa xmm0,xmm4
    7c0f944ff4dc:	pslld  xmm0,0x10
    7c0f944ff4e1:	movdqa xmm3,xmm0
    7c0f944ff4e5:	mov    r15d,0x0
    7c0f944ff4eb:	mov    r9,QWORD PTR [rsp+0x50]
    7c0f944ff4f0:	and    r9,0xffff
    7c0f944ff4f7:	shl    r9,0x8
    7c0f944ff4fb:	mov    ecx,0xffffffff
    7c0f944ff500:	and    r9,rcx
    7c0f944ff503:	mov    rbp,r15
    7c0f944ff506:	or     rbp,r9
    7c0f944ff509:	mov    r9,QWORD PTR [rsp+0x50]
    7c0f944ff50e:	shr    r9,0x10
    7c0f944ff512:	and    r9,0xffff
    7c0f944ff519:	shl    r9,0x8
    7c0f944ff51d:	mov    ecx,0xffffffff
    7c0f944ff522:	and    r9,rcx
    7c0f944ff525:	shl    r9,0x20
    7c0f944ff529:	or     rbp,r9
    7c0f944ff52c:	mov    r9,QWORD PTR [rsp+0x50]
    7c0f944ff531:	shr    r9,0x20
    7c0f944ff535:	and    r9,0xffff
    7c0f944ff53c:	shl    r9,0x8
    7c0f944ff540:	mov    ecx,0xffffffff
    7c0f944ff545:	and    r9,rcx
    7c0f944ff548:	or     r15,r9
    7c0f944ff54b:	mov    r9,QWORD PTR [rsp+0x50]
    7c0f944ff550:	shr    r9,0x30
    7c0f944ff554:	and    r9,0xffff
    7c0f944ff55b:	shl    r9,0x8
    7c0f944ff55f:	mov    ecx,0xffffffff
    7c0f944ff564:	and    r9,rcx
    7c0f944ff567:	shl    r9,0x20
    7c0f944ff56b:	or     r15,r9
    7c0f944ff56e:	mov    QWORD PTR [r12+0x240],rbp
    7c0f944ff576:	mov    QWORD PTR [r12+0x248],r15
    7c0f944ff57e:	mov    r15d,0x0
    7c0f944ff584:	mov    rbp,QWORD PTR [rsp+0x60]
    7c0f944ff589:	and    rbp,0xffff
    7c0f944ff590:	mov    ecx,0xffffffff
    7c0f944ff595:	and    rbp,rcx
    7c0f944ff598:	mov    r9,r15
    7c0f944ff59b:	or     r9,rbp
    7c0f944ff59e:	mov    rbp,QWORD PTR [rsp+0x60]
    7c0f944ff5a3:	shr    rbp,0x10
    7c0f944ff5a7:	and    rbp,0xffff
    7c0f944ff5ae:	mov    ecx,0xffffffff
    7c0f944ff5b3:	and    rbp,rcx
    7c0f944ff5b6:	shl    rbp,0x20
    7c0f944ff5ba:	or     r9,rbp
    7c0f944ff5bd:	mov    rbp,QWORD PTR [rsp+0x60]
    7c0f944ff5c2:	shr    rbp,0x20
    7c0f944ff5c6:	and    rbp,0xffff
    7c0f944ff5cd:	mov    ecx,0xffffffff
    7c0f944ff5d2:	and    rbp,rcx
    7c0f944ff5d5:	or     r15,rbp
    7c0f944ff5d8:	mov    rbp,QWORD PTR [rsp+0x60]
    7c0f944ff5dd:	shr    rbp,0x30
    7c0f944ff5e1:	and    rbp,0xffff
    7c0f944ff5e8:	mov    ecx,0xffffffff
    7c0f944ff5ed:	and    rbp,rcx
    7c0f944ff5f0:	shl    rbp,0x20
    7c0f944ff5f4:	or     r15,rbp
    7c0f944ff5f7:	mov    QWORD PTR [r12+0x260],r9
    7c0f944ff5ff:	mov    QWORD PTR [r12+0x268],r15
    7c0f944ff607:	mov    r15d,0x0
    7c0f944ff60d:	mov    rbp,r13
    7c0f944ff610:	and    rbp,0xffff
    7c0f944ff617:	mov    ecx,0xffffffff
    7c0f944ff61c:	and    rbp,rcx
    7c0f944ff61f:	mov    r9,r15
    7c0f944ff622:	or     r9,rbp
    7c0f944ff625:	mov    rbp,r13
    7c0f944ff628:	shr    rbp,0x10
    7c0f944ff62c:	and    rbp,0xffff
    7c0f944ff633:	mov    ecx,0xffffffff
    7c0f944ff638:	and    rbp,rcx
    7c0f944ff63b:	shl    rbp,0x20
    7c0f944ff63f:	or     r9,rbp
    7c0f944ff642:	mov    rbp,r13
    7c0f944ff645:	shr    rbp,0x20
    7c0f944ff649:	and    rbp,0xffff
    7c0f944ff650:	mov    ecx,0xffffffff
    7c0f944ff655:	and    rbp,rcx
    7c0f944ff658:	or     r15,rbp
    7c0f944ff65b:	shr    r13,0x30
    7c0f944ff65f:	and    r13,0xffff
    7c0f944ff666:	mov    ecx,0xffffffff
    7c0f944ff66b:	and    r13,rcx
    7c0f944ff66e:	shl    r13,0x20
    7c0f944ff672:	or     r15,r13
    7c0f944ff675:	mov    QWORD PTR [r12+0x270],r9
    7c0f944ff67d:	mov    QWORD PTR [r12+0x278],r15
    7c0f944ff685:	mov    r13d,0x0
    7c0f944ff68b:	mov    r15,QWORD PTR [rsp+0x58]
    7c0f944ff690:	and    r15,0xffff
    7c0f944ff697:	mov    ecx,0xffffffff
    7c0f944ff69c:	and    r15,rcx
    7c0f944ff69f:	mov    rbp,r13
    7c0f944ff6a2:	or     rbp,r15
    7c0f944ff6a5:	mov    r15,QWORD PTR [rsp+0x58]
    7c0f944ff6aa:	shr    r15,0x10
    7c0f944ff6ae:	and    r15,0xffff
    7c0f944ff6b5:	mov    ecx,0xffffffff
    7c0f944ff6ba:	and    r15,rcx
    7c0f944ff6bd:	shl    r15,0x20
    7c0f944ff6c1:	or     rbp,r15
    7c0f944ff6c4:	mov    r15,QWORD PTR [rsp+0x58]
    7c0f944ff6c9:	shr    r15,0x20
    7c0f944ff6cd:	and    r15,0xffff
    7c0f944ff6d4:	mov    ecx,0xffffffff
    7c0f944ff6d9:	and    r15,rcx
    7c0f944ff6dc:	or     r13,r15
    7c0f944ff6df:	mov    r15,QWORD PTR [rsp+0x58]
    7c0f944ff6e4:	shr    r15,0x30
    7c0f944ff6e8:	and    r15,0xffff
    7c0f944ff6ef:	mov    ecx,0xffffffff
    7c0f944ff6f4:	and    r15,rcx
    7c0f944ff6f7:	shl    r15,0x20
    7c0f944ff6fb:	or     r13,r15
    7c0f944ff6fe:	mov    QWORD PTR [r12+0x170],rbp
    7c0f944ff706:	mov    QWORD PTR [r12+0x178],r13
    7c0f944ff70e:	movdqu xmm4,XMMWORD PTR [r12+0x210]
    7c0f944ff718:	pxor   xmm0,xmm0
    7c0f944ff71c:	movdqa xmm5,xmm0
    7c0f944ff720:	movdqa xmm0,xmm4
    7c0f944ff724:	movdqa xmm1,xmm5
    7c0f944ff728:	punpckhwd xmm0,xmm1
    7c0f944ff72c:	movdqa xmm6,xmm0
    7c0f944ff730:	movdqa xmm0,xmm6
    7c0f944ff734:	pslld  xmm0,0x10
    7c0f944ff739:	movdqa xmm5,xmm0
    7c0f944ff73d:	movdqu XMMWORD PTR [r12+0x280],xmm5
    7c0f944ff747:	mov    r13d,0x0
    7c0f944ff74d:	mov    r15,QWORD PTR [rsp+0x68]
    7c0f944ff752:	and    r15,0xffff
    7c0f944ff759:	mov    ecx,0xffffffff
    7c0f944ff75e:	and    r15,rcx
    7c0f944ff761:	mov    rbp,r13
    7c0f944ff764:	or     rbp,r15
    7c0f944ff767:	mov    r15,QWORD PTR [rsp+0x68]
    7c0f944ff76c:	shr    r15,0x10
    7c0f944ff770:	and    r15,0xffff
    7c0f944ff777:	mov    ecx,0xffffffff
    7c0f944ff77c:	and    r15,rcx
    7c0f944ff77f:	shl    r15,0x20
    7c0f944ff783:	or     rbp,r15
    7c0f944ff786:	mov    r15,QWORD PTR [rsp+0x68]
    7c0f944ff78b:	shr    r15,0x20
    7c0f944ff78f:	and    r15,0xffff
    7c0f944ff796:	mov    ecx,0xffffffff
    7c0f944ff79b:	and    r15,rcx
    7c0f944ff79e:	or     r13,r15
    7c0f944ff7a1:	mov    r15,QWORD PTR [rsp+0x68]
    7c0f944ff7a6:	shr    r15,0x30
    7c0f944ff7aa:	and    r15,0xffff
    7c0f944ff7b1:	mov    ecx,0xffffffff
    7c0f944ff7b6:	and    r15,rcx
    7c0f944ff7b9:	shl    r15,0x20
    7c0f944ff7bd:	or     r13,r15
    7c0f944ff7c0:	mov    QWORD PTR [r12+0x180],rbp
    7c0f944ff7c8:	mov    QWORD PTR [r12+0x188],r13
    7c0f944ff7d0:	pxor   xmm0,xmm0
    7c0f944ff7d4:	movdqa xmm6,xmm0
    7c0f944ff7d8:	movdqa xmm0,xmm4
    7c0f944ff7dc:	movdqa xmm1,xmm6
    7c0f944ff7e0:	punpcklwd xmm0,xmm1
    7c0f944ff7e4:	movdqa xmm7,xmm0
    7c0f944ff7e8:	movdqa xmm0,xmm7
    7c0f944ff7ec:	pslld  xmm0,0x10
    7c0f944ff7f1:	movdqa xmm4,xmm0
    7c0f944ff7f5:	pxor   xmm0,xmm0
    7c0f944ff7f9:	movdqa xmm6,xmm0
    7c0f944ff7fd:	movdqa xmm0,xmm2
    7c0f944ff801:	movdqa xmm1,xmm6
    7c0f944ff805:	punpckhwd xmm0,xmm1
    7c0f944ff809:	movdqa xmm7,xmm0
    7c0f944ff80d:	movdqa xmm0,xmm7
    7c0f944ff811:	pslld  xmm0,0x10
    7c0f944ff816:	movdqa xmm2,xmm0
    7c0f944ff81a:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    7c0f944ff824:	movdqa xmm1,xmm6
    7c0f944ff828:	por    xmm3,xmm1
    7c0f944ff82c:	movdqu XMMWORD PTR [r12+0x230],xmm3
    7c0f944ff836:	mov    r13d,0x0
    7c0f944ff83c:	mov    r15,r14
    7c0f944ff83f:	and    r15,0xffff
    7c0f944ff846:	shl    r15,0x8
    7c0f944ff84a:	mov    ecx,0xffffffff
    7c0f944ff84f:	and    r15,rcx
    7c0f944ff852:	mov    rbp,r13
    7c0f944ff855:	or     rbp,r15
    7c0f944ff858:	mov    r15,r14
    7c0f944ff85b:	shr    r15,0x10
    7c0f944ff85f:	and    r15,0xffff
    7c0f944ff866:	shl    r15,0x8
    7c0f944ff86a:	mov    ecx,0xffffffff
    7c0f944ff86f:	and    r15,rcx
    7c0f944ff872:	shl    r15,0x20
    7c0f944ff876:	or     rbp,r15
    7c0f944ff879:	mov    r15,r14
    7c0f944ff87c:	shr    r15,0x20
    7c0f944ff880:	and    r15,0xffff
    7c0f944ff887:	shl    r15,0x8
    7c0f944ff88b:	mov    ecx,0xffffffff
    7c0f944ff890:	and    r15,rcx
    7c0f944ff893:	or     r13,r15
    7c0f944ff896:	shr    r14,0x30
    7c0f944ff89a:	and    r14,0xffff
    7c0f944ff8a1:	shl    r14,0x8
    7c0f944ff8a5:	mov    ecx,0xffffffff
    7c0f944ff8aa:	and    r14,rcx
    7c0f944ff8ad:	shl    r14,0x20
    7c0f944ff8b1:	or     r13,r14
    7c0f944ff8b4:	mov    QWORD PTR [r12+0x240],rbp
    7c0f944ff8bc:	mov    QWORD PTR [r12+0x248],r13
    7c0f944ff8c4:	mov    r13d,0x0
    7c0f944ff8ca:	mov    r14,r8
    7c0f944ff8cd:	and    r14,0xffff
    7c0f944ff8d4:	shl    r14,0x8
    7c0f944ff8d8:	mov    ecx,0xffffffff
    7c0f944ff8dd:	and    r14,rcx
    7c0f944ff8e0:	mov    r15,r13
    7c0f944ff8e3:	or     r15,r14
    7c0f944ff8e6:	mov    r14,r8
    7c0f944ff8e9:	shr    r14,0x10
    7c0f944ff8ed:	and    r14,0xffff
    7c0f944ff8f4:	shl    r14,0x8
    7c0f944ff8f8:	mov    ecx,0xffffffff
    7c0f944ff8fd:	and    r14,rcx
    7c0f944ff900:	shl    r14,0x20
    7c0f944ff904:	or     r15,r14
    7c0f944ff907:	mov    r14,r8
    7c0f944ff90a:	shr    r14,0x20
    7c0f944ff90e:	and    r14,0xffff
    7c0f944ff915:	shl    r14,0x8
    7c0f944ff919:	mov    ecx,0xffffffff
    7c0f944ff91e:	and    r14,rcx
    7c0f944ff921:	or     r13,r14
    7c0f944ff924:	shr    r8,0x30
    7c0f944ff928:	and    r8,0xffff
    7c0f944ff92f:	shl    r8,0x8
    7c0f944ff933:	mov    ecx,0xffffffff
    7c0f944ff938:	and    r8,rcx
    7c0f944ff93b:	shl    r8,0x20
    7c0f944ff93f:	or     r13,r8
    7c0f944ff942:	mov    QWORD PTR [r12+0x220],r15
    7c0f944ff94a:	mov    QWORD PTR [r12+0x228],r13
    7c0f944ff952:	mov    r13d,0x0
    7c0f944ff958:	mov    r14,QWORD PTR [rsp+0x48]
    7c0f944ff95d:	and    r14,0xffff
    7c0f944ff964:	shl    r14,0x8
    7c0f944ff968:	mov    ecx,0xffffffff
    7c0f944ff96d:	and    r14,rcx
    7c0f944ff970:	mov    r15,r13
    7c0f944ff973:	or     r15,r14
    7c0f944ff976:	mov    r14,QWORD PTR [rsp+0x48]
    7c0f944ff97b:	shr    r14,0x10
    7c0f944ff97f:	and    r14,0xffff
    7c0f944ff986:	shl    r14,0x8
    7c0f944ff98a:	mov    ecx,0xffffffff
    7c0f944ff98f:	and    r14,rcx
    7c0f944ff992:	shl    r14,0x20
    7c0f944ff996:	or     r15,r14
    7c0f944ff999:	mov    r14,QWORD PTR [rsp+0x48]
    7c0f944ff99e:	shr    r14,0x20
    7c0f944ff9a2:	and    r14,0xffff
    7c0f944ff9a9:	shl    r14,0x8
    7c0f944ff9ad:	mov    ecx,0xffffffff
    7c0f944ff9b2:	and    r14,rcx
    7c0f944ff9b5:	or     r13,r14
    7c0f944ff9b8:	mov    r14,QWORD PTR [rsp+0x48]
    7c0f944ff9bd:	shr    r14,0x30
    7c0f944ff9c1:	and    r14,0xffff
    7c0f944ff9c8:	shl    r14,0x8
    7c0f944ff9cc:	mov    ecx,0xffffffff
    7c0f944ff9d1:	and    r14,rcx
    7c0f944ff9d4:	shl    r14,0x20
    7c0f944ff9d8:	or     r13,r14
    7c0f944ff9db:	mov    QWORD PTR [r12+0x160],r15
    7c0f944ff9e3:	mov    QWORD PTR [r12+0x168],r13
    7c0f944ff9eb:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    7c0f944ff9f5:	movdqa xmm0,xmm6
    7c0f944ff9f9:	pslld  xmm0,0x18
    7c0f944ff9fe:	movdqa xmm7,xmm0
    7c0f944ffa02:	movdqu XMMWORD PTR [r12+0x170],xmm7
    7c0f944ffa0c:	movdqu xmm6,XMMWORD PTR [r12+0x270]
    7c0f944ffa16:	movdqa xmm0,xmm6
    7c0f944ffa1a:	pslld  xmm0,0x18
    7c0f944ffa1f:	movdqa xmm8,xmm0
    7c0f944ffa24:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    7c0f944ffa2e:	movdqa xmm0,xmm6
    7c0f944ffa32:	pslld  xmm0,0x18
    7c0f944ffa37:	movdqa xmm9,xmm0
    7c0f944ffa3c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    7c0f944ffa46:	mov    r13d,0x0
    7c0f944ffa4c:	mov    r14,QWORD PTR [rsp+0x78]
    7c0f944ffa51:	and    r14,0xffff
    7c0f944ffa58:	mov    ecx,0xffffffff
    7c0f944ffa5d:	and    r14,rcx
    7c0f944ffa60:	mov    r15,r13
    7c0f944ffa63:	or     r15,r14
    7c0f944ffa66:	mov    r14,QWORD PTR [rsp+0x78]
    7c0f944ffa6b:	shr    r14,0x10
    7c0f944ffa6f:	and    r14,0xffff
    7c0f944ffa76:	mov    ecx,0xffffffff
    7c0f944ffa7b:	and    r14,rcx
    7c0f944ffa7e:	shl    r14,0x20
    7c0f944ffa82:	or     r15,r14
    7c0f944ffa85:	mov    r14,QWORD PTR [rsp+0x78]
    7c0f944ffa8a:	shr    r14,0x20
    7c0f944ffa8e:	and    r14,0xffff
    7c0f944ffa95:	mov    ecx,0xffffffff
    7c0f944ffa9a:	and    r14,rcx
    7c0f944ffa9d:	or     r13,r14
    7c0f944ffaa0:	mov    r14,QWORD PTR [rsp+0x78]
    7c0f944ffaa5:	shr    r14,0x30
    7c0f944ffaa9:	and    r14,0xffff
    7c0f944ffab0:	mov    ecx,0xffffffff
    7c0f944ffab5:	and    r14,rcx
    7c0f944ffab8:	shl    r14,0x20
    7c0f944ffabc:	or     r13,r14
    7c0f944ffabf:	mov    QWORD PTR [r12+0x140],r15
    7c0f944ffac7:	mov    QWORD PTR [r12+0x148],r13
    7c0f944ffacf:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    7c0f944ffad9:	movdqa xmm1,xmm6
    7c0f944ffadd:	por    xmm5,xmm1
    7c0f944ffae1:	movdqu xmm6,XMMWORD PTR [r12+0x220]
    7c0f944ffaeb:	movdqa xmm1,xmm6
    7c0f944ffaef:	por    xmm4,xmm1
    7c0f944ffaf3:	movdqu XMMWORD PTR [r12+0x210],xmm4
    7c0f944ffafd:	movdqu xmm6,XMMWORD PTR [r12+0x260]
    7c0f944ffb07:	movdqa xmm0,xmm6
    7c0f944ffb0b:	pslld  xmm0,0x18
    7c0f944ffb10:	movdqa xmm10,xmm0
    7c0f944ffb15:	movdqu XMMWORD PTR [r12+0x220],xmm10
    7c0f944ffb1f:	movdqu xmm6,XMMWORD PTR [r12+0x160]
    7c0f944ffb29:	movdqa xmm1,xmm6
    7c0f944ffb2d:	por    xmm2,xmm1
    7c0f944ffb31:	movdqa xmm1,xmm7
    7c0f944ffb35:	por    xmm3,xmm1
    7c0f944ffb39:	movdqu XMMWORD PTR [r12+0x160],xmm3
    7c0f944ffb43:	mov    r13d,0x0
    7c0f944ffb49:	mov    r14,QWORD PTR [rsp+0x88]
    7c0f944ffb51:	and    r14,0xffff
    7c0f944ffb58:	mov    ecx,0xffffffff
    7c0f944ffb5d:	and    r14,rcx
    7c0f944ffb60:	mov    r15,r13
    7c0f944ffb63:	or     r15,r14
    7c0f944ffb66:	mov    r14,QWORD PTR [rsp+0x88]
    7c0f944ffb6e:	shr    r14,0x10
    7c0f944ffb72:	and    r14,0xffff
    7c0f944ffb79:	mov    ecx,0xffffffff
    7c0f944ffb7e:	and    r14,rcx
    7c0f944ffb81:	shl    r14,0x20
    7c0f944ffb85:	or     r15,r14
    7c0f944ffb88:	mov    r14,QWORD PTR [rsp+0x88]
    7c0f944ffb90:	shr    r14,0x20
    7c0f944ffb94:	and    r14,0xffff
    7c0f944ffb9b:	mov    ecx,0xffffffff
    7c0f944ffba0:	and    r14,rcx
    7c0f944ffba3:	or     r13,r14
    7c0f944ffba6:	mov    r14,QWORD PTR [rsp+0x88]
    7c0f944ffbae:	shr    r14,0x30
    7c0f944ffbb2:	and    r14,0xffff
    7c0f944ffbb9:	mov    ecx,0xffffffff
    7c0f944ffbbe:	and    r14,rcx
    7c0f944ffbc1:	shl    r14,0x20
    7c0f944ffbc5:	or     r13,r14
    7c0f944ffbc8:	mov    QWORD PTR [r12+0x170],r15
    7c0f944ffbd0:	mov    QWORD PTR [r12+0x178],r13
    7c0f944ffbd8:	mov    r13d,0x0
    7c0f944ffbde:	mov    r14,QWORD PTR [rsp+0x80]
    7c0f944ffbe6:	and    r14,0xffff
    7c0f944ffbed:	mov    ecx,0xffffffff
    7c0f944ffbf2:	and    r14,rcx
    7c0f944ffbf5:	mov    r15,r13
    7c0f944ffbf8:	or     r15,r14
    7c0f944ffbfb:	mov    r14,QWORD PTR [rsp+0x80]
    7c0f944ffc03:	shr    r14,0x10
    7c0f944ffc07:	and    r14,0xffff
    7c0f944ffc0e:	mov    ecx,0xffffffff
    7c0f944ffc13:	and    r14,rcx
    7c0f944ffc16:	shl    r14,0x20
    7c0f944ffc1a:	or     r15,r14
    7c0f944ffc1d:	mov    r14,QWORD PTR [rsp+0x80]
    7c0f944ffc25:	shr    r14,0x20
    7c0f944ffc29:	and    r14,0xffff
    7c0f944ffc30:	mov    ecx,0xffffffff
    7c0f944ffc35:	and    r14,rcx
    7c0f944ffc38:	or     r13,r14
    7c0f944ffc3b:	mov    r14,QWORD PTR [rsp+0x80]
    7c0f944ffc43:	shr    r14,0x30
    7c0f944ffc47:	and    r14,0xffff
    7c0f944ffc4e:	mov    ecx,0xffffffff
    7c0f944ffc53:	and    r14,rcx
    7c0f944ffc56:	shl    r14,0x20
    7c0f944ffc5a:	or     r13,r14
    7c0f944ffc5d:	mov    QWORD PTR [r12+0x110],r15
    7c0f944ffc65:	mov    QWORD PTR [r12+0x118],r13
    7c0f944ffc6d:	movdqa xmm1,xmm8
    7c0f944ffc72:	por    xmm5,xmm1
    7c0f944ffc76:	movdqa xmm1,xmm9
    7c0f944ffc7b:	por    xmm4,xmm1
    7c0f944ffc7f:	mov    r13d,0x0
    7c0f944ffc85:	mov    r14,QWORD PTR [rsp+0x70]
    7c0f944ffc8a:	and    r14,0xffff
    7c0f944ffc91:	mov    ecx,0xffffffff
    7c0f944ffc96:	and    r14,rcx
    7c0f944ffc99:	mov    r15,r13
    7c0f944ffc9c:	or     r15,r14
    7c0f944ffc9f:	mov    r14,QWORD PTR [rsp+0x70]
    7c0f944ffca4:	shr    r14,0x10
    7c0f944ffca8:	and    r14,0xffff
    7c0f944ffcaf:	mov    ecx,0xffffffff
    7c0f944ffcb4:	and    r14,rcx
    7c0f944ffcb7:	shl    r14,0x20
    7c0f944ffcbb:	or     r15,r14
    7c0f944ffcbe:	mov    r14,QWORD PTR [rsp+0x70]
    7c0f944ffcc3:	shr    r14,0x20
    7c0f944ffcc7:	and    r14,0xffff
    7c0f944ffcce:	mov    ecx,0xffffffff
    7c0f944ffcd3:	and    r14,rcx
    7c0f944ffcd6:	or     r13,r14
    7c0f944ffcd9:	mov    r14,QWORD PTR [rsp+0x70]
    7c0f944ffcde:	shr    r14,0x30
    7c0f944ffce2:	and    r14,0xffff
    7c0f944ffce9:	mov    ecx,0xffffffff
    7c0f944ffcee:	and    r14,rcx
    7c0f944ffcf1:	shl    r14,0x20
    7c0f944ffcf5:	or     r13,r14
    7c0f944ffcf8:	mov    QWORD PTR [r12+0x180],r15
    7c0f944ffd00:	mov    QWORD PTR [r12+0x188],r13
    7c0f944ffd08:	movdqa xmm1,xmm10
    7c0f944ffd0d:	por    xmm2,xmm1
    7c0f944ffd11:	movdqu XMMWORD PTR [r12+0x150],xmm2
    7c0f944ffd1b:	movdqu xmm6,XMMWORD PTR [r12+0x140]
    7c0f944ffd25:	movdqa xmm1,xmm6
    7c0f944ffd29:	por    xmm3,xmm1
    7c0f944ffd2d:	movdqu XMMWORD PTR [r12+0x140],xmm3
    7c0f944ffd37:	movdqu xmm6,XMMWORD PTR [r12+0x110]
    7c0f944ffd41:	movdqa xmm1,xmm6
    7c0f944ffd45:	por    xmm4,xmm1
    7c0f944ffd49:	movdqu XMMWORD PTR [r12+0x110],xmm4
    7c0f944ffd53:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    7c0f944ffd5d:	movdqa xmm1,xmm6
    7c0f944ffd61:	por    xmm5,xmm1
    7c0f944ffd65:	movdqu XMMWORD PTR [r12+0x120],xmm5
    7c0f944ffd6f:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    7c0f944ffd79:	movdqa xmm1,xmm6
    7c0f944ffd7d:	por    xmm2,xmm1
    7c0f944ffd81:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c0f944ffd8b:	mov    r13,QWORD PTR [r12+0xf8]
    7c0f944ffd93:	mov    r14,r13
    7c0f944ffd96:	add    r14,0x20
    7c0f944ffd9a:	mov    r15,r14
    7c0f944ffd9d:	add    r15,0x10
    7c0f944ffda1:	movdqu XMMWORD PTR [r14],xmm4
    7c0f944ffda6:	mov    r14d,0x0
    7c0f944ffdac:	mov    DWORD PTR [r12+0x32c],r14d
    7c0f944ffdb4:	movdqu XMMWORD PTR [r15],xmm5
    7c0f944ffdb9:	mov    r14,r13
    7c0f944ffdbc:	add    r14,0x10
    7c0f944ffdc0:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7c0f944ffdc6:	movdqu XMMWORD PTR [r14],xmm2
    7c0f944ffdcb:	mov    r14d,DWORD PTR [r13+0x0]
    7c0f944ffdcf:	mov    QWORD PTR [r12+0x60],r14
    7c0f944ffdd4:	jmp    0x7c0f944ffdd9
    7c0f944ffdd9:	mov    r13,QWORD PTR [r12+0x58]
    7c0f944ffdde:	mov    r14,QWORD PTR [r12+0x48]
    7c0f944ffde3:	add    r14,r13
    7c0f944ffde6:	mov    QWORD PTR [r12+0x68],r14
    7c0f944ffdeb:	add    r13,0x4
    7c0f944ffdef:	mov    QWORD PTR [r12+0x58],r13
    7c0f944ffdf4:	mov    r15,r14
    7c0f944ffdf7:	add    r15,0x4
    7c0f944ffdfb:	mov    eax,DWORD PTR [r15]
    7c0f944ffdfe:	mov    QWORD PTR [r12+0x70],rax
    7c0f944ffe03:	mov    r15,r14
    7c0f944ffe06:	add    r15,0x38
    7c0f944ffe0a:	mov    r8d,DWORD PTR [r15]
    7c0f944ffe0d:	mov    QWORD PTR [r12+0x78],r8
    7c0f944ffe12:	mov    r15,r14
    7c0f944ffe15:	add    r15,0x24
    7c0f944ffe19:	mov    r9d,DWORD PTR [r15]
    7c0f944ffe1c:	mov    QWORD PTR [r12+0x90],r9
    7c0f944ffe24:	sub    r13,0xc0
    7c0f944ffe2b:	setne  BYTE PTR [rsp+0xb8]
    7c0f944ffe33:	mov    r11,rax
    7c0f944ffe36:	lahf
    7c0f944ffe37:	seto   al
    7c0f944ffe3a:	mov    WORD PTR [rsp+0xb0],ax
    7c0f944ffe42:	mov    rax,r11
    7c0f944ffe45:	mov    r13d,DWORD PTR [r12+0x70]
    7c0f944ffe4a:	mov    r13d,r13d
    7c0f944ffe4d:	mov    r13d,r13d
    7c0f944ffe50:	ror    r13d,0x7
    7c0f944ffe54:	mov    QWORD PTR [r12+0x80],r13
    7c0f944ffe5c:	mov    r15d,r8d
    7c0f944ffe5f:	mov    r15d,r15d
    7c0f944ffe62:	ror    r15d,0x11
    7c0f944ffe66:	mov    QWORD PTR [r12+0x88],r15
    7c0f944ffe6e:	mov    ebp,DWORD PTR [r12+0x60]
    7c0f944ffe73:	add    r9d,ebp
    7c0f944ffe76:	mov    QWORD PTR [r12+0x60],r9
    7c0f944ffe7b:	mov    ebp,DWORD PTR [r12+0x70]
    7c0f944ffe80:	mov    ebp,ebp
    7c0f944ffe82:	mov    ebp,ebp
    7c0f944ffe84:	ror    ebp,0x12
    7c0f944ffe87:	xor    r13d,ebp
    7c0f944ffe8a:	mov    QWORD PTR [r12+0x80],r13
    7c0f944ffe92:	mov    ebp,r8d
    7c0f944ffe95:	mov    ebp,ebp
    7c0f944ffe97:	ror    ebp,0x13
    7c0f944ffe9a:	xor    r15d,ebp
    7c0f944ffe9d:	mov    QWORD PTR [r12+0x88],r15
    7c0f944ffea5:	mov    ebp,DWORD PTR [r12+0x70]
    7c0f944ffeaa:	mov    ebp,ebp
    7c0f944ffeac:	mov    ebp,ebp
    7c0f944ffeae:	shr    ebp,0x3
    7c0f944ffeb1:	xor    r13d,ebp
    7c0f944ffeb4:	mov    QWORD PTR [r12+0x80],r13
    7c0f944ffebc:	mov    r8d,r8d
    7c0f944ffebf:	shr    r8d,0xa
    7c0f944ffec3:	xor    r15d,r8d
    7c0f944ffec6:	mov    QWORD PTR [r12+0x78],r15
    7c0f944ffecb:	add    r9d,r13d
    7c0f944ffece:	mov    QWORD PTR [r12+0x60],r9
    7c0f944ffed3:	add    r9d,r15d
    7c0f944ffed6:	mov    QWORD PTR [r12+0x60],r9
    7c0f944ffedb:	add    r14,0x40
    7c0f944ffedf:	mov    DWORD PTR [r14],r9d
    7c0f944ffee2:	mov    r13d,0x0
    7c0f944ffee8:	mov    DWORD PTR [r12+0x32c],r13d
    7c0f944ffef0:	mov    r13d,0x0
    7c0f944ffef6:	mov    ecx,DWORD PTR [r12+0x70]
    7c0f944ffefb:	mov    ecx,ecx
    7c0f944ffefd:	mov    r14d,r13d
    7c0f944fff00:	or     r14d,ecx
    7c0f944fff03:	mov    QWORD PTR [r12+0x60],r14
    7c0f944fff08:	mov    rcx,QWORD PTR [r12+0x380]
    7c0f944fff10:	jrcxz  0x7c0f944fff17
    7c0f944fff12:	jmp    0x7c0f945006fa
    7c0f944fff17:	cmp    BYTE PTR [rsp+0xb8],0x0
    7c0f944fff1f:	jne    0x7c0f944ffdd9
    7c0f944fff25:	jmp    0x7c0f944fff2a
    7c0f944fff2a:	mov    r13,QWORD PTR [r12]
    7c0f944fff2e:	mov    r14,r13
    7c0f944fff31:	add    r14,0x4
    7c0f944fff35:	mov    r15d,DWORD PTR [r13+0x0]
    7c0f944fff39:	mov    ebp,DWORD PTR [r14]
    7c0f944fff3c:	mov    QWORD PTR [r12+0x78],r15
    7c0f944fff41:	mov    QWORD PTR [r12+0x80],rbp
    7c0f944fff49:	mov    r14,r13
    7c0f944fff4c:	add    r14,0x8
    7c0f944fff50:	mov    r8,r14
    7c0f944fff53:	add    r8,0x4
    7c0f944fff57:	mov    r9d,DWORD PTR [r14]
    7c0f944fff5a:	mov    eax,DWORD PTR [r8]
    7c0f944fff5d:	mov    QWORD PTR [rsp+0x90],rax
    7c0f944fff65:	mov    QWORD PTR [r12+0x70],r9
    7c0f944fff6a:	mov    rax,QWORD PTR [rsp+0x90]
    7c0f944fff72:	mov    QWORD PTR [r12+0x68],rax
    7c0f944fff77:	mov    r8,r13
    7c0f944fff7a:	add    r8,0x18
    7c0f944fff7e:	mov    r14,r8
    7c0f944fff81:	add    r14,0x4
    7c0f944fff85:	mov    eax,DWORD PTR [r8]
    7c0f944fff88:	mov    QWORD PTR [rsp+0x98],rax
    7c0f944fff90:	mov    r8d,DWORD PTR [r14]
    7c0f944fff93:	mov    rax,QWORD PTR [rsp+0x98]
    7c0f944fff9b:	mov    QWORD PTR [r12+0x58],rax
    7c0f944fffa0:	mov    QWORD PTR [r12+0x60],r8
    7c0f944fffa5:	add    r13,0x10
    7c0f944fffa9:	mov    r14,r13
    7c0f944fffac:	add    r14,0x4
    7c0f944fffb0:	mov    eax,DWORD PTR [r13+0x0]
    7c0f944fffb4:	mov    QWORD PTR [rsp+0xa0],rax
    7c0f944fffbc:	mov    eax,DWORD PTR [r14]
    7c0f944fffbf:	mov    QWORD PTR [rsp+0xa8],rax
    7c0f944fffc7:	mov    rax,QWORD PTR [rsp+0xa0]
    7c0f944fffcf:	mov    QWORD PTR [r12+0x18],rax
    7c0f944fffd4:	mov    rax,QWORD PTR [rsp+0xa8]
    7c0f944fffdc:	mov    QWORD PTR [r12+0x90],rax
    7c0f944fffe4:	mov    r14d,0x0
    7c0f944fffea:	mov    QWORD PTR [r12+0x88],r14
    7c0f944ffff2:	mov    r14d,0x0
    7c0f944ffff8:	mov    r13d,r14d
    7c0f944ffffb:	or     r13d,r15d
    7c0f944ffffe:	mov    QWORD PTR [r12+0xa8],r13
    7c0f94500006:	mov    r13d,0x0
    7c0f9450000c:	mov    r14d,r13d
    7c0f9450000f:	or     r14d,ebp
    7c0f94500012:	mov    QWORD PTR [r12+0x38],r14
    7c0f94500017:	mov    r13d,0x0
    7c0f9450001d:	mov    r14d,r13d
    7c0f94500020:	or     r14d,r9d
    7c0f94500023:	mov    QWORD PTR [r12+0x98],r14
    7c0f9450002b:	mov    r13d,0x0
    7c0f94500031:	mov    ecx,DWORD PTR [rsp+0x90]
    7c0f94500038:	mov    r14d,r13d
    7c0f9450003b:	or     r14d,ecx
    7c0f9450003e:	mov    QWORD PTR [r12+0x28],r14
    7c0f94500043:	mov    r13d,0x0
    7c0f94500049:	mov    r14d,r13d
    7c0f9450004c:	or     r14d,r8d
    7c0f9450004f:	mov    QWORD PTR [r12+0xb0],r14
    7c0f94500057:	mov    r13d,0x0
    7c0f9450005d:	mov    ecx,DWORD PTR [rsp+0x98]
    7c0f94500064:	mov    r14d,r13d
    7c0f94500067:	or     r14d,ecx
    7c0f9450006a:	mov    QWORD PTR [r12+0xc0],r14
    7c0f94500072:	mov    r13d,0x0
    7c0f94500078:	mov    ecx,DWORD PTR [rsp+0xa8]
    7c0f9450007f:	mov    r14d,r13d
    7c0f94500082:	or     r14d,ecx
    7c0f94500085:	mov    QWORD PTR [r12+0xc8],r14
    7c0f9450008d:	mov    r13d,0x0
    7c0f94500093:	mov    ecx,DWORD PTR [rsp+0xa0]
    7c0f9450009a:	mov    r14d,r13d
    7c0f9450009d:	or     r14d,ecx
    7c0f945000a0:	mov    QWORD PTR [r12+0xb8],r14
    7c0f945000a8:	jmp    0x7c0f945000ad
    7c0f945000ad:	mov    r13d,0x0
    7c0f945000b3:	mov    r14d,DWORD PTR [r12+0xb8]
    7c0f945000bb:	mov    eax,r13d
    7c0f945000be:	or     eax,r14d
    7c0f945000c1:	mov    QWORD PTR [r12+0x30],rax
    7c0f945000c6:	mov    r13d,0x0
    7c0f945000cc:	mov    ebp,DWORD PTR [r12+0xc0]
    7c0f945000d4:	mov    eax,r13d
    7c0f945000d7:	or     eax,ebp
    7c0f945000d9:	mov    QWORD PTR [r12+0xa0],rax
    7c0f945000e1:	mov    r13d,0x0
    7c0f945000e7:	mov    ebp,DWORD PTR [r12+0x28]
    7c0f945000ec:	mov    eax,r13d
    7c0f945000ef:	or     eax,ebp
    7c0f945000f1:	mov    QWORD PTR [r12+0xc0],rax
    7c0f945000f9:	mov    r13d,0x0
    7c0f945000ff:	mov    ebp,DWORD PTR [r12+0x98]
    7c0f94500107:	mov    eax,r13d
    7c0f9450010a:	or     eax,ebp
    7c0f9450010c:	mov    QWORD PTR [r12+0x28],rax
    7c0f94500111:	mov    r13d,0x0
    7c0f94500117:	mov    ebp,DWORD PTR [r12+0x38]
    7c0f9450011c:	mov    eax,r13d
    7c0f9450011f:	or     eax,ebp
    7c0f94500121:	mov    QWORD PTR [r12+0x98],rax
    7c0f94500129:	mov    r13d,0x0
    7c0f9450012f:	mov    ebp,DWORD PTR [r12+0xa8]
    7c0f94500137:	mov    eax,r13d
    7c0f9450013a:	or     eax,ebp
    7c0f9450013c:	mov    QWORD PTR [r12+0x38],rax
    7c0f94500141:	mov    r14d,r14d
    7c0f94500144:	ror    r14d,0x6
    7c0f94500148:	mov    QWORD PTR [r12+0xb8],r14
    7c0f94500150:	mov    r13d,DWORD PTR [r12+0xc8]
    7c0f94500158:	mov    ebp,DWORD PTR [r12+0x30]
    7c0f9450015d:	mov    ebp,ebp
    7c0f9450015f:	and    ebp,r13d
    7c0f94500162:	mov    QWORD PTR [r12+0xa8],rbp
    7c0f9450016a:	mov    r9d,DWORD PTR [r12+0x38]
    7c0f9450016f:	mov    r9d,r9d
    7c0f94500172:	mov    r9d,r9d
    7c0f94500175:	ror    r9d,0x2
    7c0f94500179:	mov    QWORD PTR [r12+0xd0],r9
    7c0f94500181:	mov    r15d,0x0
    7c0f94500187:	mov    eax,r15d
    7c0f9450018a:	or     eax,r13d
    7c0f9450018d:	mov    QWORD PTR [r12+0x20],rax
    7c0f94500192:	mov    rax,QWORD PTR [r12+0x88]
    7c0f9450019a:	mov    r15,QWORD PTR [r12+0x50]
    7c0f9450019f:	mov    rcx,QWORD PTR [r12+0x88]
    7c0f945001a7:	add    r15,rcx
    7c0f945001aa:	mov    r13d,DWORD PTR [r15]
    7c0f945001ad:	mov    QWORD PTR [r12+0xc8],r13
    7c0f945001b5:	mov    ecx,DWORD PTR [r12+0x30]
    7c0f945001ba:	mov    ecx,ecx
    7c0f945001bc:	mov    r15d,DWORD PTR [r12+0xa0]
    7c0f945001c4:	mov    r15d,r15d
    7c0f945001c7:	not    rcx
    7c0f945001ca:	and    r15d,ecx
    7c0f945001cd:	mov    QWORD PTR [r12+0xd8],r15
    7c0f945001d5:	mov    r8d,DWORD PTR [r12+0xb0]
    7c0f945001dd:	add    ebp,r8d
    7c0f945001e0:	mov    QWORD PTR [r12+0xa8],rbp
    7c0f945001e8:	mov    r8d,DWORD PTR [r12+0x30]
    7c0f945001ed:	mov    r8d,r8d
    7c0f945001f0:	mov    r8d,r8d
    7c0f945001f3:	ror    r8d,0xb
    7c0f945001f7:	xor    r14d,r8d
    7c0f945001fa:	mov    QWORD PTR [r12+0xb0],r14
    7c0f94500202:	mov    r8d,DWORD PTR [r12+0x38]
    7c0f94500207:	mov    r8d,r8d
    7c0f9450020a:	mov    r8d,r8d
    7c0f9450020d:	ror    r8d,0xd
    7c0f94500211:	xor    r9d,r8d
    7c0f94500214:	mov    QWORD PTR [r12+0xd0],r9
    7c0f9450021c:	add    ebp,r15d
    7c0f9450021f:	mov    QWORD PTR [r12+0xa8],rbp
    7c0f94500227:	mov    r15,QWORD PTR [r12+0x48]
    7c0f9450022c:	mov    rcx,QWORD PTR [r12+0x88]
    7c0f94500234:	add    r15,rcx
    7c0f94500237:	mov    r8d,DWORD PTR [r15]
    7c0f9450023a:	mov    QWORD PTR [r12+0xb8],r8
    7c0f94500242:	mov    ecx,DWORD PTR [r12+0x98]
    7c0f9450024a:	mov    ecx,ecx
    7c0f9450024c:	mov    eax,DWORD PTR [r12+0x28]
    7c0f94500251:	mov    eax,eax
    7c0f94500253:	and    eax,ecx
    7c0f94500255:	mov    QWORD PTR [r12+0xd8],rax
    7c0f9450025d:	add    ebp,r13d
    7c0f94500260:	mov    QWORD PTR [r12+0xa8],rbp
    7c0f94500268:	mov    ecx,DWORD PTR [r12+0x98]
    7c0f94500270:	mov    ecx,ecx
    7c0f94500272:	mov    r13d,DWORD PTR [r12+0x28]
    7c0f94500277:	mov    r13d,r13d
    7c0f9450027a:	xor    r13d,ecx
    7c0f9450027d:	mov    QWORD PTR [r12+0xc8],r13
    7c0f94500285:	mov    r15d,DWORD PTR [r12+0x30]
    7c0f9450028a:	mov    r15d,r15d
    7c0f9450028d:	mov    r15d,r15d
    7c0f94500290:	ror    r15d,0x19
    7c0f94500294:	xor    r14d,r15d
    7c0f94500297:	mov    QWORD PTR [r12+0xb0],r14
    7c0f9450029f:	mov    ecx,DWORD PTR [r12+0x38]
    7c0f945002a4:	mov    ecx,ecx
    7c0f945002a6:	and    r13d,ecx
    7c0f945002a9:	mov    QWORD PTR [r12+0xc8],r13
    7c0f945002b1:	mov    r15d,DWORD PTR [r12+0x38]
    7c0f945002b6:	mov    r15d,r15d
    7c0f945002b9:	mov    r15d,r15d
    7c0f945002bc:	ror    r15d,0x16
    7c0f945002c0:	xor    r9d,r15d
    7c0f945002c3:	mov    QWORD PTR [r12+0xd0],r9
    7c0f945002cb:	add    ebp,r8d
    7c0f945002ce:	mov    QWORD PTR [r12+0xa8],rbp
    7c0f945002d6:	mov    ecx,DWORD PTR [r12+0xd8]
    7c0f945002de:	mov    ecx,ecx
    7c0f945002e0:	xor    r13d,ecx
    7c0f945002e3:	mov    QWORD PTR [r12+0xb8],r13
    7c0f945002eb:	add    ebp,r14d
    7c0f945002ee:	mov    QWORD PTR [r12+0xa8],rbp
    7c0f945002f6:	mov    r14,QWORD PTR [r12+0x88]
    7c0f945002fe:	add    r14,0x4
    7c0f94500302:	mov    QWORD PTR [r12+0x88],r14
    7c0f9450030a:	add    r13d,r9d
    7c0f9450030d:	mov    QWORD PTR [r12+0xb0],r13
    7c0f94500315:	mov    ecx,DWORD PTR [r12+0xc0]
    7c0f9450031d:	mov    ecx,ecx
    7c0f9450031f:	mov    r15d,ebp
    7c0f94500322:	add    r15d,ecx
    7c0f94500325:	mov    QWORD PTR [r12+0xb8],r15
    7c0f9450032d:	sub    r14,0x100
    7c0f94500334:	setne  BYTE PTR [rsp+0xb8]
    7c0f9450033c:	mov    r11,rax
    7c0f9450033f:	lahf
    7c0f94500340:	seto   al
    7c0f94500343:	mov    WORD PTR [rsp+0xb0],ax
    7c0f9450034b:	mov    rax,r11
    7c0f9450034e:	add    r13d,ebp
    7c0f94500351:	mov    QWORD PTR [r12+0xa8],r13
    7c0f94500359:	mov    r13d,0x0
    7c0f9450035f:	mov    ecx,DWORD PTR [r12+0xa0]
    7c0f94500367:	mov    ecx,ecx
    7c0f94500369:	mov    r14d,r13d
    7c0f9450036c:	or     r14d,ecx
    7c0f9450036f:	mov    QWORD PTR [r12+0xb0],r14
    7c0f94500377:	mov    r13d,0x0
    7c0f9450037d:	mov    ecx,DWORD PTR [r12+0x20]
    7c0f94500382:	mov    ecx,ecx
    7c0f94500384:	mov    r14d,r13d
    7c0f94500387:	or     r14d,ecx
    7c0f9450038a:	mov    QWORD PTR [r12+0xc0],r14
    7c0f94500392:	mov    r13d,0x0
    7c0f94500398:	mov    ecx,DWORD PTR [r12+0x30]
    7c0f9450039d:	mov    ecx,ecx
    7c0f9450039f:	mov    r14d,r13d
    7c0f945003a2:	or     r14d,ecx
    7c0f945003a5:	mov    QWORD PTR [r12+0xc8],r14
    7c0f945003ad:	mov    rcx,QWORD PTR [r12+0x380]
    7c0f945003b5:	jrcxz  0x7c0f945003bc
    7c0f945003b7:	jmp    0x7c0f94500782
    7c0f945003bc:	cmp    BYTE PTR [rsp+0xb8],0x0
    7c0f945003c4:	jne    0x7c0f945000ad
    7c0f945003ca:	jmp    0x7c0f945003cf
    7c0f945003cf:	mov    r13d,DWORD PTR [r12+0x70]
    7c0f945003d4:	mov    r14d,DWORD PTR [r12+0x98]
    7c0f945003dc:	add    r14d,r13d
    7c0f945003df:	mov    QWORD PTR [r12+0x70],r14
    7c0f945003e4:	mov    r13d,DWORD PTR [r12+0x68]
    7c0f945003e9:	mov    r15d,DWORD PTR [r12+0x28]
    7c0f945003ee:	add    r15d,r13d
    7c0f945003f1:	mov    QWORD PTR [r12+0x68],r15
    7c0f945003f6:	mov    r13d,0x0
    7c0f945003fc:	mov    QWORD PTR [r12+0x88],r13
    7c0f94500404:	mov    r13d,DWORD PTR [r12+0x78]
    7c0f94500409:	mov    ebp,DWORD PTR [r12+0xa8]
    7c0f94500411:	add    ebp,r13d
    7c0f94500414:	mov    QWORD PTR [r12+0x78],rbp
    7c0f94500419:	mov    r13d,DWORD PTR [r12+0x80]
    7c0f94500421:	mov    r8d,DWORD PTR [r12+0x38]
    7c0f94500426:	add    r8d,r13d
    7c0f94500429:	mov    QWORD PTR [r12+0x80],r8
    7c0f94500431:	mov    rax,QWORD PTR [r12]
    7c0f94500435:	mov    r9,QWORD PTR [r12]
    7c0f94500439:	add    r9,0x8
    7c0f9450043d:	mov    r13,r9
    7c0f94500440:	add    r13,0x4
    7c0f94500444:	mov    DWORD PTR [r9],r14d
    7c0f94500447:	mov    r14d,0x0
    7c0f9450044d:	mov    DWORD PTR [r12+0x32c],r14d
    7c0f94500455:	mov    DWORD PTR [r13+0x0],r15d
    7c0f94500459:	mov    r13d,DWORD PTR [r12+0x18]
    7c0f9450045e:	mov    r14d,DWORD PTR [r12+0xb8]
    7c0f94500466:	add    r14d,r13d
    7c0f94500469:	mov    QWORD PTR [r12+0x68],r14
    7c0f9450046e:	mov    r13d,DWORD PTR [r12+0x90]
    7c0f94500476:	mov    r15d,DWORD PTR [r12+0x30]
    7c0f9450047b:	add    r15d,r13d
    7c0f9450047e:	mov    QWORD PTR [r12+0x70],r15
    7c0f94500483:	mov    r13d,DWORD PTR [r12+0x58]
    7c0f94500488:	mov    r9d,DWORD PTR [r12+0x20]
    7c0f9450048d:	mov    eax,r9d
    7c0f94500490:	add    eax,r13d
    7c0f94500493:	mov    QWORD PTR [r12+0x58],rax
    7c0f94500498:	mov    r13d,DWORD PTR [r12+0x60]
    7c0f9450049d:	mov    r9d,DWORD PTR [r12+0xa0]
    7c0f945004a5:	add    r9d,r13d
    7c0f945004a8:	mov    QWORD PTR [r12+0x60],r9
    7c0f945004ad:	mov    r13,QWORD PTR [r12]
    7c0f945004b1:	add    r13,0x4
    7c0f945004b5:	mov    rdi,QWORD PTR [r12]
    7c0f945004b9:	mov    DWORD PTR [rdi],ebp
    7c0f945004bb:	mov    DWORD PTR [r13+0x0],r8d
    7c0f945004bf:	mov    r13,QWORD PTR [r12]
    7c0f945004c3:	add    r13,0x10
    7c0f945004c7:	mov    rbp,r13
    7c0f945004ca:	add    rbp,0x4
    7c0f945004ce:	mov    DWORD PTR [r13+0x0],r14d
    7c0f945004d2:	mov    DWORD PTR [rbp+0x0],r15d
    7c0f945004d6:	mov    r13,QWORD PTR [r12]
    7c0f945004da:	add    r13,0x18
    7c0f945004de:	mov    r14,r13
    7c0f945004e1:	add    r14,0x4
    7c0f945004e5:	mov    eax,DWORD PTR [r12+0x58]
    7c0f945004ea:	mov    DWORD PTR [r13+0x0],eax
    7c0f945004ee:	mov    DWORD PTR [r14],r9d
    7c0f945004f1:	mov    r13,QWORD PTR [r12]
    7c0f945004f5:	add    r13,0x68
    7c0f945004f9:	mov    r14d,0x0
    7c0f945004ff:	mov    QWORD PTR [r13+0x0],r14
    7c0f94500503:	mov    rcx,QWORD PTR [r12+0x380]
    7c0f9450050b:	jrcxz  0x7c0f94500512
    7c0f9450050d:	jmp    0x7c0f9450080a
    7c0f94500512:	jmp    0x7c0f94500517
    7c0f94500517:	mov    r13,QWORD PTR [r12+0x10]
    7c0f9450051c:	sub    r13,0x1
    7c0f94500520:	mov    QWORD PTR [r12+0x10],r13
    7c0f94500525:	mov    rax,r13
    7c0f94500528:	test   rax,rax
    7c0f9450052b:	je     0x7c0f94500536
    7c0f94500531:	jmp    0x7c0f944fe63a
    7c0f94500536:	mov    r13,QWORD PTR [r12+0xf8]
    7c0f9450053e:	mov    r14,r13
    7c0f94500541:	add    r14,0x140
    7c0f94500548:	mov    r15,r14
    7c0f9450054b:	add    r15,0x8
    7c0f9450054f:	mov    rbp,QWORD PTR [r14]
    7c0f94500552:	mov    r14,QWORD PTR [r15]
    7c0f94500555:	mov    QWORD PTR [r12+0xa0],rbp
    7c0f9450055d:	mov    QWORD PTR [r12+0x98],r14
    7c0f94500565:	mov    r14,r13
    7c0f94500568:	add    r14,0x130
    7c0f9450056f:	mov    r15,r14
    7c0f94500572:	add    r15,0x8
    7c0f94500576:	mov    rbp,QWORD PTR [r14]
    7c0f94500579:	mov    r14,QWORD PTR [r15]
    7c0f9450057c:	mov    QWORD PTR [r12+0xb0],rbp
    7c0f94500584:	mov    QWORD PTR [r12+0xa8],r14
    7c0f9450058c:	mov    r14,r13
    7c0f9450058f:	add    r14,0x120
    7c0f94500596:	mov    r15,r14
    7c0f94500599:	add    r15,0x8
    7c0f9450059d:	mov    rbp,QWORD PTR [r14]
    7c0f945005a0:	mov    r14,QWORD PTR [r15]
    7c0f945005a3:	mov    QWORD PTR [r12+0xc0],rbp
    7c0f945005ab:	mov    QWORD PTR [r12+0xb8],r14
    7c0f945005b3:	mov    r14,r13
    7c0f945005b6:	add    r14,0x110
    7c0f945005bd:	mov    r15,r14
    7c0f945005c0:	add    r15,0x8
    7c0f945005c4:	mov    rbp,QWORD PTR [r14]
    7c0f945005c7:	mov    r14,QWORD PTR [r15]
    7c0f945005ca:	mov    QWORD PTR [r12+0xd0],rbp
    7c0f945005d2:	mov    QWORD PTR [r12+0xc8],r14
    7c0f945005da:	mov    r14,r13
    7c0f945005dd:	add    r14,0x100
    7c0f945005e4:	mov    r15,r14
    7c0f945005e7:	add    r15,0x8
    7c0f945005eb:	mov    rbp,QWORD PTR [r14]
    7c0f945005ee:	mov    r14,QWORD PTR [r15]
    7c0f945005f1:	mov    QWORD PTR [r12+0xe8],rbp
    7c0f945005f9:	mov    QWORD PTR [r12+0xd8],r14
    7c0f94500601:	add    r13,0x150
    7c0f94500608:	mov    QWORD PTR [r12+0xf8],r13
    7c0f94500610:	jmp    0x7c0f94500615
    7c0f94500615:	mov    rcx,QWORD PTR [r12+0x380]
    7c0f9450061d:	jrcxz  0x7c0f94500624
    7c0f9450061f:	jmp    0x7c0f94500892
    7c0f94500624:	mov    r13,QWORD PTR [r12+0xf0]
    7c0f9450062c:	mov    QWORD PTR [r12+0x100],r13
    7c0f94500634:	mov    r11,QWORD PTR [rsp+0xb0]
    7c0f9450063c:	mov    QWORD PTR [r12+0x398],r11
    7c0f94500644:	mov    rdi,QWORD PTR [r12+0x100]
    7c0f9450064c:	add    rsp,0xc0
    7c0f94500653:	movabs r11,0x62016968d940
    7c0f9450065d:	jmp    r11
    7c0f94500660:	mov    eax,0x41039c
    7c0f94500665:	mov    QWORD PTR [r12+0x100],rax
    7c0f9450066d:	push   rdx
    7c0f9450066e:	push   rsi
    7c0f9450066f:	push   r10
    7c0f94500671:	push   r11
    7c0f94500673:	mov    r11,rax
    7c0f94500676:	lahf
    7c0f94500677:	seto   al
    7c0f9450067a:	mov    WORD PTR [rsp+0xd0],ax
    7c0f94500682:	mov    rax,r11
    7c0f94500685:	mov    rdx,QWORD PTR [rsp+0xd0]
    7c0f9450068d:	mov    r10d,edx
    7c0f94500690:	and    r10d,0xc000
    7c0f94500697:	shl    r10d,0x10
    7c0f9450069b:	mov    r11d,edx
    7c0f9450069e:	and    r11d,0x100
    7c0f945006a5:	shl    r11d,0x15
    7c0f945006a9:	or     r10d,r11d
    7c0f945006ac:	and    edx,0x1
    7c0f945006af:	shl    edx,0x1c
    7c0f945006b2:	or     r10d,edx
    7c0f945006b5:	btc    r10,0x1d
    7c0f945006ba:	mov    r11d,0xf0000000
    7c0f945006c0:	and    r11,r10
    7c0f945006c3:	movabs rsi,0xffffffff0fffffff
    7c0f945006cd:	and    rbx,rsi
    7c0f945006d0:	or     rbx,r11
    7c0f945006d3:	pop    r11
    7c0f945006d5:	pop    r10
    7c0f945006d7:	pop    rsi
    7c0f945006d8:	pop    rdx
    7c0f945006d9:	mov    QWORD PTR [r12+0x108],rbx
    7c0f945006e1:	add    rsp,0xc0
    7c0f945006e8:	mov    eax,0xc
    7c0f945006ed:	movabs r11,0x62016968dca0
    7c0f945006f7:	jmp    r11
    7c0f945006fa:	mov    eax,0x410498
    7c0f945006ff:	mov    QWORD PTR [r12+0x100],rax
    7c0f94500707:	push   rdx
    7c0f94500708:	push   rsi
    7c0f94500709:	push   r10
    7c0f9450070b:	push   r11
    7c0f9450070d:	mov    rdx,QWORD PTR [rsp+0xd0]
    7c0f94500715:	mov    r10d,edx
    7c0f94500718:	and    r10d,0xc000
    7c0f9450071f:	shl    r10d,0x10
    7c0f94500723:	mov    r11d,edx
    7c0f94500726:	and    r11d,0x100
    7c0f9450072d:	shl    r11d,0x15
    7c0f94500731:	or     r10d,r11d
    7c0f94500734:	and    edx,0x1
    7c0f94500737:	shl    edx,0x1c
    7c0f9450073a:	or     r10d,edx
    7c0f9450073d:	btc    r10,0x1d
    7c0f94500742:	mov    r11d,0xf0000000
    7c0f94500748:	and    r11,r10
    7c0f9450074b:	movabs rsi,0xffffffff0fffffff
    7c0f94500755:	and    rbx,rsi
    7c0f94500758:	or     rbx,r11
    7c0f9450075b:	pop    r11
    7c0f9450075d:	pop    r10
    7c0f9450075f:	pop    rsi
    7c0f94500760:	pop    rdx
    7c0f94500761:	mov    QWORD PTR [r12+0x108],rbx
    7c0f94500769:	add    rsp,0xc0
    7c0f94500770:	mov    eax,0xc
    7c0f94500775:	movabs r11,0x62016968dca0
    7c0f9450077f:	jmp    r11
    7c0f94500782:	mov    eax,0x410558
    7c0f94500787:	mov    QWORD PTR [r12+0x100],rax
    7c0f9450078f:	push   rdx
    7c0f94500790:	push   rsi
    7c0f94500791:	push   r10
    7c0f94500793:	push   r11
    7c0f94500795:	mov    rdx,QWORD PTR [rsp+0xd0]
    7c0f9450079d:	mov    r10d,edx
    7c0f945007a0:	and    r10d,0xc000
    7c0f945007a7:	shl    r10d,0x10
    7c0f945007ab:	mov    r11d,edx
    7c0f945007ae:	and    r11d,0x100
    7c0f945007b5:	shl    r11d,0x15
    7c0f945007b9:	or     r10d,r11d
    7c0f945007bc:	and    edx,0x1
    7c0f945007bf:	shl    edx,0x1c
    7c0f945007c2:	or     r10d,edx
    7c0f945007c5:	btc    r10,0x1d
    7c0f945007ca:	mov    r11d,0xf0000000
    7c0f945007d0:	and    r11,r10
    7c0f945007d3:	movabs rsi,0xffffffff0fffffff
    7c0f945007dd:	and    rbx,rsi
    7c0f945007e0:	or     rbx,r11
    7c0f945007e3:	pop    r11
    7c0f945007e5:	pop    r10
    7c0f945007e7:	pop    rsi
    7c0f945007e8:	pop    rdx
    7c0f945007e9:	mov    QWORD PTR [r12+0x108],rbx
    7c0f945007f1:	add    rsp,0xc0
    7c0f945007f8:	mov    eax,0xc
    7c0f945007fd:	movabs r11,0x62016968dca0
    7c0f94500807:	jmp    r11
    7c0f9450080a:	mov    eax,0x410594
    7c0f9450080f:	mov    QWORD PTR [r12+0x100],rax
    7c0f94500817:	push   rdx
    7c0f94500818:	push   rsi
    7c0f94500819:	push   r10
    7c0f9450081b:	push   r11
    7c0f9450081d:	mov    rdx,QWORD PTR [rsp+0xd0]
    7c0f94500825:	mov    r10d,edx
    7c0f94500828:	and    r10d,0xc000
    7c0f9450082f:	shl    r10d,0x10
    7c0f94500833:	mov    r11d,edx
    7c0f94500836:	and    r11d,0x100
    7c0f9450083d:	shl    r11d,0x15
    7c0f94500841:	or     r10d,r11d
    7c0f94500844:	and    edx,0x1
    7c0f94500847:	shl    edx,0x1c
    7c0f9450084a:	or     r10d,edx
    7c0f9450084d:	btc    r10,0x1d
    7c0f94500852:	mov    r11d,0xf0000000
    7c0f94500858:	and    r11,r10
    7c0f9450085b:	movabs rsi,0xffffffff0fffffff
    7c0f94500865:	and    rbx,rsi
    7c0f94500868:	or     rbx,r11
    7c0f9450086b:	pop    r11
    7c0f9450086d:	pop    r10
    7c0f9450086f:	pop    rsi
    7c0f94500870:	pop    rdx
    7c0f94500871:	mov    QWORD PTR [r12+0x108],rbx
    7c0f94500879:	add    rsp,0xc0
    7c0f94500880:	mov    eax,0xc
    7c0f94500885:	movabs r11,0x62016968dca0
    7c0f9450088f:	jmp    r11
    7c0f94500892:	mov    eax,0x4105b0
    7c0f94500897:	mov    QWORD PTR [r12+0x100],rax
    7c0f9450089f:	push   rdx
    7c0f945008a0:	push   rsi
    7c0f945008a1:	push   r10
    7c0f945008a3:	push   r11
    7c0f945008a5:	mov    rdx,QWORD PTR [rsp+0xd0]
    7c0f945008ad:	mov    r10d,edx
    7c0f945008b0:	and    r10d,0xc000
    7c0f945008b7:	shl    r10d,0x10
    7c0f945008bb:	mov    r11d,edx
    7c0f945008be:	and    r11d,0x100
    7c0f945008c5:	shl    r11d,0x15
    7c0f945008c9:	or     r10d,r11d
    7c0f945008cc:	and    edx,0x1
    7c0f945008cf:	shl    edx,0x1c
    7c0f945008d2:	or     r10d,edx
    7c0f945008d5:	btc    r10,0x1d
    7c0f945008da:	mov    r11d,0xf0000000
    7c0f945008e0:	and    r11,r10
    7c0f945008e3:	movabs rsi,0xffffffff0fffffff
    7c0f945008ed:	and    rbx,rsi
    7c0f945008f0:	or     rbx,r11
    7c0f945008f3:	pop    r11
    7c0f945008f5:	pop    r10
    7c0f945008f7:	pop    rsi
    7c0f945008f8:	pop    rdx
    7c0f945008f9:	mov    QWORD PTR [r12+0x108],rbx
    7c0f94500901:	add    rsp,0xc0
    7c0f94500908:	mov    eax,0xc
    7c0f9450090d:	movabs r11,0x62016968dca0
    7c0f94500917:	jmp    r11
    7c0f9450091a:	nop    WORD PTR [rax+rax*1+0x0]
    7c0f94500920:	sub    rsp,0xc0
    7c0f94500927:	mov    r11,QWORD PTR [r12+0x398]
    7c0f9450092f:	mov    QWORD PTR [rsp+0xb0],r11
    7c0f94500937:	jmp    0x7c0f944fe519
    7c0f9450093c:	nop    DWORD PTR [rax+0x0]
    7c0f94500940:	sub    rsp,0xc0
    7c0f94500947:	mov    r11,QWORD PTR [r12+0x398]
    7c0f9450094f:	mov    QWORD PTR [rsp+0xb0],r11
    7c0f94500957:	jmp    0x7c0f944fe63a
    7c0f9450095c:	nop    DWORD PTR [rax+0x0]
    7c0f94500960:	sub    rsp,0xc0
    7c0f94500967:	mov    r11,QWORD PTR [r12+0x398]
    7c0f9450096f:	mov    QWORD PTR [rsp+0xb0],r11
    7c0f94500977:	jmp    0x7c0f944fe6f4
    7c0f9450097c:	nop    DWORD PTR [rax+0x0]
    7c0f94500980:	sub    rsp,0xc0
    7c0f94500987:	mov    r11,QWORD PTR [r12+0x398]
    7c0f9450098f:	mov    QWORD PTR [rsp+0xb0],r11
    7c0f94500997:	jmp    0x7c0f944ffdd9
    7c0f9450099c:	nop    DWORD PTR [rax+0x0]
    7c0f945009a0:	sub    rsp,0xc0
    7c0f945009a7:	mov    r11,QWORD PTR [r12+0x398]
    7c0f945009af:	mov    QWORD PTR [rsp+0xb0],r11
    7c0f945009b7:	jmp    0x7c0f944fff2a
    7c0f945009bc:	nop    DWORD PTR [rax+0x0]
    7c0f945009c0:	sub    rsp,0xc0
    7c0f945009c7:	mov    r11,QWORD PTR [r12+0x398]
    7c0f945009cf:	mov    QWORD PTR [rsp+0xb0],r11
    7c0f945009d7:	jmp    0x7c0f945000ad
    7c0f945009dc:	nop    DWORD PTR [rax+0x0]
    7c0f945009e0:	sub    rsp,0xc0
    7c0f945009e7:	mov    r11,QWORD PTR [r12+0x398]
    7c0f945009ef:	mov    QWORD PTR [rsp+0xb0],r11
    7c0f945009f7:	jmp    0x7c0f945003cf
    7c0f945009fc:	nop    DWORD PTR [rax+0x0]
    7c0f94500a00:	sub    rsp,0xc0
    7c0f94500a07:	mov    r11,QWORD PTR [r12+0x398]
    7c0f94500a0f:	mov    QWORD PTR [rsp+0xb0],r11
    7c0f94500a17:	jmp    0x7c0f94500517
    7c0f94500a1c:	nop    DWORD PTR [rax+0x0]
    7c0f94500a20:	sub    rsp,0xc0
    7c0f94500a27:	mov    r11,QWORD PTR [r12+0x398]
    7c0f94500a2f:	mov    QWORD PTR [rsp+0xb0],r11
    7c0f94500a37:	jmp    0x7c0f94500536
    7c0f94500a3c:	nop    DWORD PTR [rax+0x0]
    7c0f94500a40:	sub    rsp,0xc0
    7c0f94500a47:	mov    r11,QWORD PTR [r12+0x398]
    7c0f94500a4f:	mov    QWORD PTR [rsp+0xb0],r11
    7c0f94500a57:	jmp    0x7c0f94500615
