
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/2/4.bin:     file format binary


Disassembly of section .data:

0000719221f00f30 <.data>:
    719221f00f30:	sub    rsp,0x10
    719221f00f34:	mov    r11,QWORD PTR [r12+0x398]
    719221f00f3c:	mov    QWORD PTR [rsp],r11
    719221f00f40:	mov    r13,QWORD PTR [r12+0xf8]
    719221f00f48:	add    r13,0x68
    719221f00f4c:	mov    r14,QWORD PTR [r13+0x0]
    719221f00f50:	mov    QWORD PTR [r12+0x40],r14
    719221f00f55:	sub    r14,0x38
    719221f00f59:	mov    rcx,QWORD PTR [r12+0x380]
    719221f00f61:	jrcxz  0x719221f00f68
    719221f00f63:	jmp    0x719221f01035
    719221f00f68:	jne    0x719221f00f81
    719221f00f6e:	mov    r11,rax
    719221f00f71:	lahf
    719221f00f72:	seto   al
    719221f00f75:	mov    WORD PTR [rsp],ax
    719221f00f79:	mov    rax,r11
    719221f00f7c:	jmp    0x719221f00f94
    719221f00f81:	mov    r11,rax
    719221f00f84:	lahf
    719221f00f85:	seto   al
    719221f00f88:	mov    WORD PTR [rsp],ax
    719221f00f8c:	mov    rax,r11
    719221f00f8f:	jmp    0x719221f00fe5
    719221f00f94:	mov    r13d,0x4102c4
    719221f00f9a:	mov    QWORD PTR [r12+0x100],r13
    719221f00fa2:	mov    r11,QWORD PTR [rsp]
    719221f00fa6:	mov    QWORD PTR [r12+0x398],r11
    719221f00fae:	mov    edi,0x4102c4
    719221f00fb3:	mov    QWORD PTR [r12+0x100],rdi
    719221f00fbb:	add    rsp,0x10
    719221f00fbf:	nop
    719221f00fc0:	jmp    QWORD PTR [rip+0x2]        # 0x719221f00fc8
    719221f00fc6:	xchg   ax,ax
    719221f00fc8:	adc    BYTE PTR [rdi],cl
    719221f00fca:	lock and DWORD PTR [rdx-0x27ffff8f],edx
    719221f00fd1:	(bad)
    719221f00fd3:	and    DWORD PTR [rdx+0x49000071],edx
    719221f00fd9:	mov    ebx,0x2955b940
    719221f00fde:	xchg   BYTE PTR [rax+rax*1+0x0],ah
    719221f00fe2:	jmp    r11
    719221f00fe5:	mov    r13d,0x4102a8
    719221f00feb:	mov    QWORD PTR [r12+0x100],r13
    719221f00ff3:	mov    r11,QWORD PTR [rsp]
    719221f00ff7:	mov    QWORD PTR [r12+0x398],r11
    719221f00fff:	mov    edi,0x4102a8
    719221f01004:	mov    QWORD PTR [r12+0x100],rdi
    719221f0100c:	add    rsp,0x10
    719221f01010:	jmp    QWORD PTR [rip+0x2]        # 0x719221f01018
    719221f01016:	xchg   ax,ax
    719221f01018:	lock (bad)
    719221f0101a:	lock and DWORD PTR [rdx+0x28000071],edx
    719221f01021:	adc    al,dh
    719221f01023:	and    DWORD PTR [rdx+0x49000071],edx
    719221f01029:	mov    ebx,0x2955b940
    719221f0102e:	xchg   BYTE PTR [rax+rax*1+0x0],ah
    719221f01032:	jmp    r11
    719221f01035:	mov    eax,0x4102c0
    719221f0103a:	mov    QWORD PTR [r12+0x100],rax
    719221f01042:	push   rdx
    719221f01043:	push   rsi
    719221f01044:	push   r10
    719221f01046:	push   r11
    719221f01048:	mov    r11,rax
    719221f0104b:	lahf
    719221f0104c:	seto   al
    719221f0104f:	mov    WORD PTR [rsp+0x20],ax
    719221f01054:	mov    rax,r11
    719221f01057:	mov    rdx,QWORD PTR [rsp+0x20]
    719221f0105c:	mov    r10d,edx
    719221f0105f:	and    r10d,0xc000
    719221f01066:	shl    r10d,0x10
    719221f0106a:	mov    r11d,edx
    719221f0106d:	and    r11d,0x100
    719221f01074:	shl    r11d,0x15
    719221f01078:	or     r10d,r11d
    719221f0107b:	and    edx,0x1
    719221f0107e:	shl    edx,0x1c
    719221f01081:	or     r10d,edx
    719221f01084:	btc    r10,0x1d
    719221f01089:	mov    r11d,0xf0000000
    719221f0108f:	and    r11,r10
    719221f01092:	movabs rsi,0xffffffff0fffffff
    719221f0109c:	and    rbx,rsi
    719221f0109f:	or     rbx,r11
    719221f010a2:	pop    r11
    719221f010a4:	pop    r10
    719221f010a6:	pop    rsi
    719221f010a7:	pop    rdx
    719221f010a8:	mov    QWORD PTR [r12+0x108],rbx
    719221f010b0:	add    rsp,0x10
    719221f010b4:	mov    eax,0xc
    719221f010b9:	movabs r11,0x64862955bca0
    719221f010c3:	jmp    r11
    719221f010c6:	nop
    719221f010c7:	nop
