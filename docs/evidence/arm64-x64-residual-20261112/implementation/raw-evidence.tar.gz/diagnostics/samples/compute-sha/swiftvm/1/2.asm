
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/1/2.bin:     file format binary


Disassembly of section .data:

00007c0f94500a60 <.data>:
    7c0f94500a60:	sub    rsp,0x10
    7c0f94500a64:	mov    r13d,DWORD PTR [r12+0xa0]
    7c0f94500a6c:	sub    r13d,0x1
    7c0f94500a70:	mov    QWORD PTR [r12+0xa0],r13
    7c0f94500a78:	mov    rcx,QWORD PTR [r12+0x380]
    7c0f94500a80:	jrcxz  0x7c0f94500a87
    7c0f94500a82:	jmp    0x7c0f94500c05
    7c0f94500a87:	jne    0x7c0f94500aa0
    7c0f94500a8d:	mov    r11,rax
    7c0f94500a90:	lahf
    7c0f94500a91:	seto   al
    7c0f94500a94:	mov    WORD PTR [rsp],ax
    7c0f94500a98:	mov    rax,r11
    7c0f94500a9b:	jmp    0x7c0f94500ab3
    7c0f94500aa0:	mov    r11,rax
    7c0f94500aa3:	lahf
    7c0f94500aa4:	seto   al
    7c0f94500aa7:	mov    WORD PTR [rsp],ax
    7c0f94500aab:	mov    rax,r11
    7c0f94500aae:	jmp    0x7c0f94500b75
    7c0f94500ab3:	mov    r13,QWORD PTR [r12+0xf8]
    7c0f94500abb:	mov    r14,r13
    7c0f94500abe:	add    r14,0x20
    7c0f94500ac2:	mov    r15,QWORD PTR [r14]
    7c0f94500ac5:	mov    QWORD PTR [r12+0x98],r15
    7c0f94500acd:	mov    r14d,0x80
    7c0f94500ad3:	mov    QWORD PTR [r12+0x40],r14
    7c0f94500ad8:	mov    QWORD PTR [r12],r13
    7c0f94500adc:	mov    r14,r13
    7c0f94500adf:	add    r14,0x8c
    7c0f94500ae6:	mov    QWORD PTR [r12+0x8],r14
    7c0f94500aeb:	mov    r14d,0x1
    7c0f94500af1:	mov    QWORD PTR [r12+0x10],r14
    7c0f94500af6:	add    r13,0x8c
    7c0f94500afd:	movzx  r14d,BYTE PTR [r12+0x40]
    7c0f94500b03:	mov    BYTE PTR [r13+0x0],r14b
    7c0f94500b07:	mov    r13d,0x0
    7c0f94500b0d:	mov    DWORD PTR [r12+0x32c],r13d
    7c0f94500b15:	mov    r13d,0x410298
    7c0f94500b1b:	mov    QWORD PTR [r12+0xf0],r13
    7c0f94500b23:	mov    r13d,0x410338
    7c0f94500b29:	mov    QWORD PTR [r12+0x100],r13
    7c0f94500b31:	mov    r11,QWORD PTR [rsp]
    7c0f94500b35:	mov    QWORD PTR [r12+0x398],r11
    7c0f94500b3d:	mov    edi,0x410338
    7c0f94500b42:	mov    QWORD PTR [r12+0x100],rdi
    7c0f94500b4a:	add    rsp,0x10
    7c0f94500b4e:	xchg   ax,ax
    7c0f94500b50:	jmp    QWORD PTR [rip+0x2]        # 0x7c0f94500b58
    7c0f94500b56:	xchg   ax,ax
    7c0f94500b58:	shl    ah,0x4f
    7c0f94500b5b:	xchg   esp,eax
    7c0f94500b5c:	(bad)
    7c0f94500b5e:	add    BYTE PTR [rax],al
    7c0f94500b60:	push   0xf94500b
    7c0f94500b65:	jl     0x7c0f94500b67
    7c0f94500b67:	add    BYTE PTR [rcx-0x45],cl
    7c0f94500b6a:	rex fldcw WORD PTR [rax+0x69]
    7c0f94500b6e:	add    DWORD PTR [rdx+0x0],esp
    7c0f94500b71:	add    BYTE PTR [rcx-0x1],al
    7c0f94500b74:	jrcxz  0x7c0f94500bc3
    7c0f94500b76:	mov    ebp,DWORD PTR [rsp+0xf8]
    7c0f94500b7d:	mov    QWORD PTR [r12],r13
    7c0f94500b81:	mov    r13d,0x0
    7c0f94500b87:	mov    r14,QWORD PTR [r12+0x98]
    7c0f94500b8f:	or     r13,r14
    7c0f94500b92:	mov    QWORD PTR [r12+0x8],r13
    7c0f94500b97:	mov    r13d,0x12c
    7c0f94500b9d:	mov    QWORD PTR [r12+0x10],r13
    7c0f94500ba2:	mov    r13d,0x410274
    7c0f94500ba8:	mov    QWORD PTR [r12+0xf0],r13
    7c0f94500bb0:	mov    r13d,0x410338
    7c0f94500bb6:	mov    QWORD PTR [r12+0x100],r13
    7c0f94500bbe:	mov    r11,QWORD PTR [rsp]
    7c0f94500bc2:	mov    QWORD PTR [r12+0x398],r11
    7c0f94500bca:	mov    edi,0x410338
    7c0f94500bcf:	mov    QWORD PTR [r12+0x100],rdi
    7c0f94500bd7:	add    rsp,0x10
    7c0f94500bdb:	nop    DWORD PTR [rax+rax*1+0x0]
    7c0f94500be0:	jmp    QWORD PTR [rip+0x2]        # 0x7c0f94500be8
    7c0f94500be6:	xchg   ax,ax
    7c0f94500be8:	shl    ah,0x4f
    7c0f94500beb:	xchg   esp,eax
    7c0f94500bec:	(bad)
    7c0f94500bee:	add    BYTE PTR [rax],al
    7c0f94500bf0:	clc
    7c0f94500bf1:	or     edx,DWORD PTR [rax-0x6c]
    7c0f94500bf4:	(bad)
    7c0f94500bf6:	add    BYTE PTR [rax],al
    7c0f94500bf8:	movabs r11,0x62016968d940
    7c0f94500c02:	jmp    r11
    7c0f94500c05:	mov    eax,0x410278
    7c0f94500c0a:	mov    QWORD PTR [r12+0x100],rax
    7c0f94500c12:	push   rdx
    7c0f94500c13:	push   rsi
    7c0f94500c14:	push   r10
    7c0f94500c16:	push   r11
    7c0f94500c18:	mov    r11,rax
    7c0f94500c1b:	lahf
    7c0f94500c1c:	seto   al
    7c0f94500c1f:	mov    WORD PTR [rsp+0x20],ax
    7c0f94500c24:	mov    rax,r11
    7c0f94500c27:	mov    rdx,QWORD PTR [rsp+0x20]
    7c0f94500c2c:	mov    r10d,edx
    7c0f94500c2f:	and    r10d,0xc000
    7c0f94500c36:	shl    r10d,0x10
    7c0f94500c3a:	mov    r11d,edx
    7c0f94500c3d:	and    r11d,0x100
    7c0f94500c44:	shl    r11d,0x15
    7c0f94500c48:	or     r10d,r11d
    7c0f94500c4b:	and    edx,0x1
    7c0f94500c4e:	shl    edx,0x1c
    7c0f94500c51:	or     r10d,edx
    7c0f94500c54:	btc    r10,0x1d
    7c0f94500c59:	mov    r11d,0xf0000000
    7c0f94500c5f:	and    r11,r10
    7c0f94500c62:	movabs rsi,0xffffffff0fffffff
    7c0f94500c6c:	and    rbx,rsi
    7c0f94500c6f:	or     rbx,r11
    7c0f94500c72:	pop    r11
    7c0f94500c74:	pop    r10
    7c0f94500c76:	pop    rsi
    7c0f94500c77:	pop    rdx
    7c0f94500c78:	mov    QWORD PTR [r12+0x108],rbx
    7c0f94500c80:	add    rsp,0x10
    7c0f94500c84:	mov    eax,0xc
    7c0f94500c89:	movabs r11,0x62016968dca0
    7c0f94500c93:	jmp    r11
    7c0f94500c96:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c0f94500ca0:	sub    rsp,0x10
    7c0f94500ca4:	mov    r11,QWORD PTR [r12+0x398]
    7c0f94500cac:	mov    QWORD PTR [rsp],r11
    7c0f94500cb0:	jmp    0x7c0f94500ab3
    7c0f94500cb5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c0f94500cc0:	sub    rsp,0x10
    7c0f94500cc4:	mov    r11,QWORD PTR [r12+0x398]
    7c0f94500ccc:	mov    QWORD PTR [rsp],r11
    7c0f94500cd0:	jmp    0x7c0f94500b75
    7c0f94500cd5:	nop
    7c0f94500cd6:	nop
    7c0f94500cd7:	nop
