00007fd2b39ce69b  nop [rax+rax*1], eax
00007fd2b39ce6a0  mov rax, [r15+0xF8]
00007fd2b39ce6a7  lea r14, [rax-0xA0]
00007fd2b39ce6ae  mov [r15+0xF8], r14
00007fd2b39ce6b5  lea rax, [r14+0x90]
00007fd2b39ce6bc  mov r12, [r15+0xA0]
00007fd2b39ce6c3  mov r11, [r15+0x98]
00007fd2b39ce6ca  mov [r13+rax*1], r12
00007fd2b39ce6cf  lea rax, [r14+0x98]
00007fd2b39ce6d6  mov [r13+rax*1], r11
00007fd2b39ce6db  mov eax, 0x420670
00007fd2b39ce6e0  movups xmm1, [r13+rax*1]
00007fd2b39ce6e6  mov eax, 0x420610
00007fd2b39ce6eb  movups xmm15, [r13+rax*1]
00007fd2b39ce6f1  mov eax, 0x420690
00007fd2b39ce6f6  movups xmm14, [r13+rax*1]
00007fd2b39ce6fc  mov eax, 0x420630
00007fd2b39ce701  movups xmm13, [r13+rax*1]
00007fd2b39ce707  mov qword ptr [r15+0x98], 0x4308A0
00007fd2b39ce712  mov eax, 0x4206A0
00007fd2b39ce717  movups xmm12, [r13+rax*1]
00007fd2b39ce71d  mov eax, 0x4308A0
00007fd2b39ce722  movups [r13+rax*1], xmm1
00007fd2b39ce728  mov eax, 0x4308B0
00007fd2b39ce72d  movups [r13+rax*1], xmm15
00007fd2b39ce733  mov eax, 0x4308C0
00007fd2b39ce738  movups [r13+rax*1], xmm14
00007fd2b39ce73e  mov eax, 0x4308D0
00007fd2b39ce743  movups [r13+rax*1], xmm13
00007fd2b39ce749  mov eax, 0x420600
00007fd2b39ce74e  movups xmm14, [r13+rax*1]
00007fd2b39ce754  mov eax, 0x4205F0
00007fd2b39ce759  movups xmm13, [r13+rax*1]
00007fd2b39ce75f  mov eax, 0x4309A0
00007fd2b39ce764  movups [r13+rax*1], xmm1
00007fd2b39ce76a  mov eax, 0x4309B0
00007fd2b39ce76f  movups [r13+rax*1], xmm15
00007fd2b39ce775  mov eax, 0x4308E0
00007fd2b39ce77a  movups [r13+rax*1], xmm12
00007fd2b39ce780  mov eax, 0x4308F0
00007fd2b39ce785  movups [r13+rax*1], xmm14
00007fd2b39ce78b  mov eax, 0x4205E0
00007fd2b39ce790  movups xmm1, [r13+rax*1]
00007fd2b39ce796  mov eax, 0x420640
00007fd2b39ce79b  movups xmm15, [r13+rax*1]
00007fd2b39ce7a1  mov eax, 0x430900
00007fd2b39ce7a6  movups [r13+rax*1], xmm13
00007fd2b39ce7ac  mov eax, 0x430910
00007fd2b39ce7b1  movups [r13+rax*1], xmm1
00007fd2b39ce7b7  mov eax, 0x420650
00007fd2b39ce7bc  movups xmm1, [r13+rax*1]
00007fd2b39ce7c2  mov eax, 0x420620
00007fd2b39ce7c7  movups xmm14, [r13+rax*1]
00007fd2b39ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007fd2b39ce7d5  mov eax, 0x430920
00007fd2b39ce7da  movups [r13+rax*1], xmm15
00007fd2b39ce7e0  mov eax, 0x430930
00007fd2b39ce7e5  movups [r13+rax*1], xmm1
00007fd2b39ce7eb  mov eax, 0x4206C0
00007fd2b39ce7f0  movups xmm1, [r13+rax*1]
00007fd2b39ce7f6  mov eax, 0x4206D0
00007fd2b39ce7fb  movups xmm15, [r13+rax*1]
00007fd2b39ce801  movaps [r15+0x150], xmm15
00007fd2b39ce809  mov qword ptr [r15+0xA0], 0x3E8
00007fd2b39ce814  mov eax, 0x430940
00007fd2b39ce819  movups [r13+rax*1], xmm14
00007fd2b39ce81f  mov eax, 0x430950
00007fd2b39ce824  movups [r13+rax*1], xmm1
00007fd2b39ce82a  mov eax, 0x4206B0
00007fd2b39ce82f  movups xmm1, [r13+rax*1]
00007fd2b39ce835  mov eax, 0x420660
00007fd2b39ce83a  movups xmm14, [r13+rax*1]
00007fd2b39ce840  movaps [r15+0x140], xmm14
00007fd2b39ce848  lea rax, [r14+0x80]
00007fd2b39ce84f  mov r12, [r15+0xF0]
00007fd2b39ce856  mov [r13+rax*1], r12
00007fd2b39ce85b  mov eax, 0x430960
00007fd2b39ce860  movups [r13+rax*1], xmm15
00007fd2b39ce866  mov eax, 0x430970
00007fd2b39ce86b  movups [r13+rax*1], xmm1
00007fd2b39ce871  mov eax, 0x420680
00007fd2b39ce876  movups xmm1, [r13+rax*1]
00007fd2b39ce87c  mov eax, 0x4206E0
00007fd2b39ce881  mov r12, [r13+rax*1]
00007fd2b39ce886  movq xmm15, r12
00007fd2b39ce88b  mov qword ptr [r15+0x40], 0x4206E8
00007fd2b39ce893  mov eax, 0x430980
00007fd2b39ce898  movups [r13+rax*1], xmm14
00007fd2b39ce89e  mov eax, 0x430990
00007fd2b39ce8a3  movups [r13+rax*1], xmm1
00007fd2b39ce8a9  mov eax, 0x420748
00007fd2b39ce8ae  movups xmm1, [r13+rax*1]
00007fd2b39ce8b4  movq rax, xmm15
00007fd2b39ce8b9  mov r12d, 0x4309C0
00007fd2b39ce8bf  mov [r13+r12*1], rax
00007fd2b39ce8c4  mov eax, 0x420728
00007fd2b39ce8c9  movups xmm15, [r13+rax*1]
00007fd2b39ce8cf  mov eax, 0x420738
00007fd2b39ce8d4  movups xmm14, [r13+rax*1]
00007fd2b39ce8da  lea rax, [r14+0x60]
00007fd2b39ce8de  movups [r13+rax*1], xmm1
00007fd2b39ce8e4  mov eax, 0x4309C8
00007fd2b39ce8e9  mov r12d, 0x421DF8D3
00007fd2b39ce8ef  mov [r13+rax*1], r12d
00007fd2b39ce8f4  lea rax, [r14+0x40]
00007fd2b39ce8f8  movups [r13+rax*1], xmm15
00007fd2b39ce8fe  lea rax, [r14+0x50]
00007fd2b39ce902  movups [r13+rax*1], xmm14
00007fd2b39ce908  mov eax, 0x4206E8
00007fd2b39ce90d  movups xmm1, [r13+rax*1]
00007fd2b39ce913  mov eax, 0x4206F8
00007fd2b39ce918  movups xmm15, [r13+rax*1]
00007fd2b39ce91e  movaps [r15+0x120], xmm15
00007fd2b39ce926  movups [r13+r14*1], xmm1
00007fd2b39ce92c  lea rax, [r14+0x10]
00007fd2b39ce930  movups [r13+rax*1], xmm15
00007fd2b39ce936  mov eax, 0x420708
00007fd2b39ce93b  movups xmm1, [r13+rax*1]
00007fd2b39ce941  mov eax, 0x420718
00007fd2b39ce946  movups xmm15, [r13+rax*1]
00007fd2b39ce94c  movaps [r15+0x110], xmm1
00007fd2b39ce954  movaps [r15+0x130], xmm15
00007fd2b39ce95c  lea rax, [r14+0x20]
00007fd2b39ce960  movups [r13+rax*1], xmm1
00007fd2b39ce966  lea rax, [r14+0x30]
00007fd2b39ce96a  movups [r13+rax*1], xmm15
00007fd2b39ce970  mov [r15], r14
00007fd2b39ce973  mov qword ptr [r15+0x08], 0x4308A0
00007fd2b39ce97b  mov qword ptr [r15+0x10], 0x12C
00007fd2b39ce983  mov qword ptr [r15+0xF0], 0x410274
00007fd2b39ce98e  mov r14d, [r15+0x320]
00007fd2b39ce995  mov eax, 0x410274
00007fd2b39ce99a  mov rcx, 0x7FD2B39D0670
00007fd2b39ce9a4  mov [r15+r14*8+0x328], rax
00007fd2b39ce9ac  mov [r15+r14*8+0x368], rcx
00007fd2b39ce9b4  add r14d, 0x01
00007fd2b39ce9b8  and r14d, 0x07
00007fd2b39ce9bc  mov [r15+0x320], r14d
00007fd2b39ce9c3  cmp dword ptr [r15+0x318], 0x00
00007fd2b39ce9cb  jz 0x00007FD2B39CEC20
00007fd2b39ce9d1  nop [rax+rax*1], ax
00007fd2b39ce9da  nop [rax+rax*1], eax
00007fd2b39ce9e2  mov eax, 0x410338
00007fd2b39ce9e7  mov [r15+0x100], rax
00007fd2b39ce9ee  jmp 0x00007FD2B37FE110
00007fd2b39ce9f3  int3
00007fd2b39ce9f4  call 0x00007FD2B380BC20
00007fd2b39ce9f9  jmp 0x00007FD2B39CE6CF
00007fd2b39ce9fe  call 0x00007FD2B380A9A0
00007fd2b39cea03  jmp 0x00007FD2B39CE6DB
00007fd2b39cea08  call 0x00007FD2B37FF430
00007fd2b39cea0d  jmp 0x00007FD2B39CE6E6
00007fd2b39cea12  call 0x00007FD2B380E760
00007fd2b39cea17  jmp 0x00007FD2B39CE6F1
00007fd2b39cea1c  call 0x00007FD2B380D4E0
00007fd2b39cea21  jmp 0x00007FD2B39CE6FC
00007fd2b39cea26  call 0x00007FD2B380C260
00007fd2b39cea2b  jmp 0x00007FD2B39CE707
00007fd2b39cea30  call 0x00007FD2B380AFE0
00007fd2b39cea35  jmp 0x00007FD2B39CE71D
00007fd2b39cea3a  call 0x00007FD2B37FF540
00007fd2b39cea3f  jmp 0x00007FD2B39CE728
00007fd2b39cea44  call 0x00007FD2B380E880
00007fd2b39cea49  jmp 0x00007FD2B39CE733
00007fd2b39cea4e  call 0x00007FD2B380D600
00007fd2b39cea53  jmp 0x00007FD2B39CE73E
00007fd2b39cea58  call 0x00007FD2B380C380
00007fd2b39cea5d  jmp 0x00007FD2B39CE749
00007fd2b39cea62  call 0x00007FD2B380D4E0
00007fd2b39cea67  jmp 0x00007FD2B39CE754
00007fd2b39cea6c  call 0x00007FD2B380C260
00007fd2b39cea71  jmp 0x00007FD2B39CE75F
00007fd2b39cea76  call 0x00007FD2B37FF540
00007fd2b39cea7b  jmp 0x00007FD2B39CE76A
00007fd2b39cea80  call 0x00007FD2B380E880
00007fd2b39cea85  jmp 0x00007FD2B39CE775
00007fd2b39cea8a  call 0x00007FD2B380B100
00007fd2b39cea8f  jmp 0x00007FD2B39CE780
00007fd2b39cea94  call 0x00007FD2B380D600
00007fd2b39cea99  jmp 0x00007FD2B39CE78B
00007fd2b39cea9e  call 0x00007FD2B37FF430
00007fd2b39ceaa3  jmp 0x00007FD2B39CE796
00007fd2b39ceaa8  call 0x00007FD2B380E760
00007fd2b39ceaad  jmp 0x00007FD2B39CE7A1
00007fd2b39ceab2  call 0x00007FD2B380C380
00007fd2b39ceab7  jmp 0x00007FD2B39CE7AC
00007fd2b39ceabc  call 0x00007FD2B37FF540
00007fd2b39ceac1  jmp 0x00007FD2B39CE7B7
00007fd2b39ceac6  call 0x00007FD2B37FF430
00007fd2b39ceacb  jmp 0x00007FD2B39CE7C2
00007fd2b39cead0  call 0x00007FD2B380D4E0
00007fd2b39cead5  jmp 0x00007FD2B39CE7CD
00007fd2b39ceada  call 0x00007FD2B380E880
00007fd2b39ceadf  jmp 0x00007FD2B39CE7E0
00007fd2b39ceae4  call 0x00007FD2B37FF540
00007fd2b39ceae9  jmp 0x00007FD2B39CE7EB
00007fd2b39ceaee  call 0x00007FD2B37FF430
00007fd2b39ceaf3  jmp 0x00007FD2B39CE7F6
00007fd2b39ceaf8  call 0x00007FD2B380E760
00007fd2b39ceafd  jmp 0x00007FD2B39CE801
00007fd2b39ceb02  call 0x00007FD2B380D600
00007fd2b39ceb07  jmp 0x00007FD2B39CE81F
00007fd2b39ceb0c  call 0x00007FD2B37FF540
00007fd2b39ceb11  jmp 0x00007FD2B39CE82A
00007fd2b39ceb16  call 0x00007FD2B37FF430
00007fd2b39ceb1b  jmp 0x00007FD2B39CE835
00007fd2b39ceb20  call 0x00007FD2B380D4E0
00007fd2b39ceb25  jmp 0x00007FD2B39CE840
00007fd2b39ceb2a  call 0x00007FD2B380BC20
00007fd2b39ceb2f  jmp 0x00007FD2B39CE85B
00007fd2b39ceb34  call 0x00007FD2B380E880
00007fd2b39ceb39  jmp 0x00007FD2B39CE866
00007fd2b39ceb3e  call 0x00007FD2B37FF540
00007fd2b39ceb43  jmp 0x00007FD2B39CE871
00007fd2b39ceb48  call 0x00007FD2B37FF430
00007fd2b39ceb4d  jmp 0x00007FD2B39CE87C
00007fd2b39ceb52  call 0x00007FD2B380B720
00007fd2b39ceb57  jmp 0x00007FD2B39CE886
00007fd2b39ceb5c  call 0x00007FD2B380D600
00007fd2b39ceb61  jmp 0x00007FD2B39CE89E
00007fd2b39ceb66  call 0x00007FD2B37FF540
00007fd2b39ceb6b  jmp 0x00007FD2B39CE8A9
00007fd2b39ceb70  call 0x00007FD2B37FF430
00007fd2b39ceb75  jmp 0x00007FD2B39CE8B4
00007fd2b39ceb7a  call 0x00007FD2B38B4CB0
00007fd2b39ceb7f  jmp 0x00007FD2B39CE8C4
00007fd2b39ceb84  call 0x00007FD2B380E760
00007fd2b39ceb89  jmp 0x00007FD2B39CE8CF
00007fd2b39ceb8e  call 0x00007FD2B380D4E0
00007fd2b39ceb93  jmp 0x00007FD2B39CE8DA
00007fd2b39ceb98  call 0x00007FD2B37FF540
00007fd2b39ceb9d  jmp 0x00007FD2B39CE8E4
00007fd2b39ceba2  call 0x00007FD2B380BAE0
00007fd2b39ceba7  jmp 0x00007FD2B39CE8F4
00007fd2b39cebac  call 0x00007FD2B380E880
00007fd2b39cebb1  jmp 0x00007FD2B39CE8FE
00007fd2b39cebb6  call 0x00007FD2B380D600
00007fd2b39cebbb  jmp 0x00007FD2B39CE908
00007fd2b39cebc0  call 0x00007FD2B37FF430
00007fd2b39cebc5  jmp 0x00007FD2B39CE913
00007fd2b39cebca  call 0x00007FD2B380E760
00007fd2b39cebcf  jmp 0x00007FD2B39CE91E
00007fd2b39cebd4  call 0x00007FD2B38D6600
00007fd2b39cebd9  jmp 0x00007FD2B39CE92C
00007fd2b39cebde  call 0x00007FD2B380E880
00007fd2b39cebe3  jmp 0x00007FD2B39CE936
00007fd2b39cebe8  call 0x00007FD2B37FF430
00007fd2b39cebed  jmp 0x00007FD2B39CE941
00007fd2b39cebf2  call 0x00007FD2B380E760
00007fd2b39cebf7  jmp 0x00007FD2B39CE94C
00007fd2b39cebfc  call 0x00007FD2B37FF540
00007fd2b39cec01  jmp 0x00007FD2B39CE966
00007fd2b39cec06  call 0x00007FD2B380E880
00007fd2b39cec0b  jmp 0x00007FD2B39CE970
00007fd2b39cec10  int3
00007fd2b39cec11  nop [rax+rax*1], ax
00007fd2b39cec1a  nop [rax+rax*1], ax
00007fd2b39cec20  mov rax, [r15]
00007fd2b39cec23  lea r14, [rax+0x20]
00007fd2b39cec27  mov r12, [r13+r14*1]
00007fd2b39cec2c  mov r14, [r15+0x10]
00007fd2b39cec30  lea r11, [r12+r14*1]
00007fd2b39cec34  mov [r15+0x40], r11
00007fd2b39cec38  lea r12, [rax+0x20]
00007fd2b39cec3c  mov [r13+r12*1], r11
00007fd2b39cec41  test r14, r14
00007fd2b39cec44  setz r14b
00007fd2b39cec48  movzx r14, r14b
00007fd2b39cec4c  mov [rsp+0x414], r14b
00007fd2b39cec54  cmp byte ptr [rsp+0x414], 0x00
00007fd2b39cec5c  jz 0x00007FD2B39CEC8E
00007fd2b39cec5e  cmp dword ptr [r15+0x318], 0x00
00007fd2b39cec66  mov eax, 0x4105B0
00007fd2b39cec6b  mov [r15+0x100], rax
00007fd2b39cec72  jz 0x00007FD2B37FE0A0
00007fd2b39cec78  nop [rax+rax*1], eax
00007fd2b39cec7d  mov eax, 0x4105B0
00007fd2b39cec82  mov [r15+0x100], rax
00007fd2b39cec89  jmp 0x00007FD2B37FE110
00007fd2b39cec8e  cmp dword ptr [r15+0x318], 0x00
00007fd2b39cec96  jz 0x00007FD2B39CECE0
00007fd2b39cec9c  nop [rax+rax*1], ax
00007fd2b39ceca5  nop [rax+rax*1], eax
00007fd2b39cecad  mov eax, 0x410348
00007fd2b39cecb2  mov [r15+0x100], rax
00007fd2b39cecb9  jmp 0x00007FD2B37FE110
00007fd2b39cecbe  int3
00007fd2b39cecbf  call 0x00007FD2B38E27E0
00007fd2b39cecc4  jmp 0x00007FD2B39CEC2C
00007fd2b39cecc9  call 0x00007FD2B38C0860
00007fd2b39cecce  jmp 0x00007FD2B39CEC41
00007fd2b39cecd3  int3
00007fd2b39cecd4  nop [rax+rax*1], ax
00007fd2b39cecdd  nop [rax], eax
00007fd2b39cece0  mov rax, [r15+0xF8]
00007fd2b39cece7  lea r14, [rax-0x150]
00007fd2b39cecee  mov [r15+0xF8], r14
00007fd2b39cecf5  mov rax, [r15]
00007fd2b39cecf8  lea r12, [rax+0x68]
00007fd2b39cecfc  mov r11, [r13+r12*1]
00007fd2b39ced01  mov [r15+0x88], r11
00007fd2b39ced08  lea r12, [rax+0x28]
00007fd2b39ced0c  mov [r15+0x40], r12
00007fd2b39ced10  mov [r15+0x48], r14
00007fd2b39ced14  mov qword ptr [r15+0x50], 0x420758
00007fd2b39ced1c  lea rax, [r14+0x100]
00007fd2b39ced23  mov r12, [r15+0xE8]
00007fd2b39ced2a  mov r11, [r15+0xD8]
00007fd2b39ced31  mov [r13+rax*1], r12
00007fd2b39ced36  lea rax, [r14+0x108]
00007fd2b39ced3d  mov [r13+rax*1], r11
00007fd2b39ced42  lea rax, [r14+0x110]
00007fd2b39ced49  mov r12, [r15+0xD0]
00007fd2b39ced50  mov r11, [r15+0xC8]
00007fd2b39ced57  mov [r13+rax*1], r12
00007fd2b39ced5c  lea rax, [r14+0x118]
00007fd2b39ced63  mov [r13+rax*1], r11
00007fd2b39ced68  lea rax, [r14+0x120]
00007fd2b39ced6f  mov r12, [r15+0xC0]
00007fd2b39ced76  mov r11, [r15+0xB8]
00007fd2b39ced7d  mov [r13+rax*1], r12
00007fd2b39ced82  lea rax, [r14+0x128]
00007fd2b39ced89  mov [r13+rax*1], r11
00007fd2b39ced8e  lea rax, [r14+0x130]
00007fd2b39ced95  mov r12, [r15+0xB0]
00007fd2b39ced9c  mov r11, [r15+0xA8]
00007fd2b39ceda3  mov [r13+rax*1], r12
00007fd2b39ceda8  lea rax, [r14+0x138]
00007fd2b39cedaf  mov [r13+rax*1], r11
00007fd2b39cedb4  lea rax, [r14+0x140]
00007fd2b39cedbb  mov r12, [r15+0xA0]
00007fd2b39cedc2  mov r11, [r15+0x98]
00007fd2b39cedc9  mov [r13+rax*1], r12
00007fd2b39cedce  lea rax, [r14+0x148]
00007fd2b39cedd5  mov [r13+rax*1], r11
00007fd2b39cedda  cmp dword ptr [r15+0x318], 0x00
00007fd2b39cede2  jz 0x00007FD2B39CEE80
00007fd2b39cede8  nop [rax+rax*1], ax
00007fd2b39cedf1  nop [rax+rax*1], eax
00007fd2b39cedf9  mov eax, 0x410380
00007fd2b39cedfe  mov [r15+0x100], rax
00007fd2b39cee05  jmp 0x00007FD2B37FE110
00007fd2b39cee0a  int3
00007fd2b39cee0b  call 0x00007FD2B38C0370
00007fd2b39cee10  jmp 0x00007FD2B39CED01
00007fd2b39cee15  call 0x00007FD2B380BC20
00007fd2b39cee1a  jmp 0x00007FD2B39CED36
00007fd2b39cee1f  call 0x00007FD2B380A9A0
00007fd2b39cee24  jmp 0x00007FD2B39CED42
00007fd2b39cee29  call 0x00007FD2B380BC20
00007fd2b39cee2e  jmp 0x00007FD2B39CED5C
00007fd2b39cee33  call 0x00007FD2B380A9A0
00007fd2b39cee38  jmp 0x00007FD2B39CED68
00007fd2b39cee3d  call 0x00007FD2B380BC20
00007fd2b39cee42  jmp 0x00007FD2B39CED82
00007fd2b39cee47  call 0x00007FD2B380A9A0
00007fd2b39cee4c  jmp 0x00007FD2B39CED8E
00007fd2b39cee51  call 0x00007FD2B380BC20
00007fd2b39cee56  jmp 0x00007FD2B39CEDA8
00007fd2b39cee5b  call 0x00007FD2B380A9A0
00007fd2b39cee60  jmp 0x00007FD2B39CEDB4
00007fd2b39cee65  call 0x00007FD2B380BC20
00007fd2b39cee6a  jmp 0x00007FD2B39CEDCE
00007fd2b39cee6f  call 0x00007FD2B380A9A0
00007fd2b39cee74  jmp 0x00007FD2B39CEDDA
00007fd2b39cee79  int3
00007fd2b39cee7a  nop [rax+rax*1], ax
00007fd2b39cee80  mov rax, [r15+0x08]
00007fd2b39cee84  movzx r14d, byte ptr [r13+rax*1]
00007fd2b39cee8a  movzx r14d, r14b
00007fd2b39cee8e  mov [rsp+0x10], r14d
00007fd2b39cee93  mov r14d, r14d
00007fd2b39cee96  mov [r15+0x58], r14
00007fd2b39cee9a  lea r14, [rax+0x01]
00007fd2b39cee9e  mov [r15+0x08], r14
00007fd2b39ceea2  mov rax, [r15+0x88]
00007fd2b39ceea9  lea r14, [rax+0x01]
00007fd2b39ceead  mov r12, [r15]
00007fd2b39ceeb0  lea r11, [r12+0x68]
00007fd2b39ceeb5  mov [r13+r11*1], r14
00007fd2b39ceeba  lea r14, [r12+rax*1]
00007fd2b39ceebe  mov [r15+0x60], r14
00007fd2b39ceec2  lea rax, [r14+0x28]
00007fd2b39ceec6  mov r11d, [rsp+0x10]
00007fd2b39ceecb  movzx r14d, r11b
00007fd2b39ceecf  mov [r13+rax*1], r14b
00007fd2b39ceed4  lea rax, [r12+0x68]
00007fd2b39ceed9  mov r14, [r13+rax*1]
00007fd2b39ceede  mov [r15+0x88], r14
00007fd2b39ceee5  xor eax, eax
00007fd2b39ceee7  mov r12d, 0x40
00007fd2b39ceeed  cmp r14, r12
00007fd2b39ceef0  cmc
00007fd2b39ceef1  lahf
00007fd2b39ceef2  seto al
00007fd2b39ceef5  mov [r15+0x108], eax
00007fd2b39ceefc  mov eax, [r15+0x108]
00007fd2b39cef03  sahf
00007fd2b39cef04  jnz 0x00007FD2B39CEF36
00007fd2b39cef06  cmp dword ptr [r15+0x318], 0x00
00007fd2b39cef0e  jz 0x00007FD2B39CF020
00007fd2b39cef14  nop [rax+rax*1], ax
00007fd2b39cef1d  nop [rax+rax*1], eax
00007fd2b39cef25  mov eax, 0x4103A0
00007fd2b39cef2a  mov [r15+0x100], rax
00007fd2b39cef31  jmp 0x00007FD2B37FE110
00007fd2b39cef36  cmp dword ptr [r15+0x318], 0x00
00007fd2b39cef3e  jz 0x00007FD2B39CEF90
00007fd2b39cef44  nop [rax+rax*1], ax
00007fd2b39cef4d  nop [rax+rax*1], eax
00007fd2b39cef55  mov eax, 0x410378
00007fd2b39cef5a  mov [r15+0x100], rax
00007fd2b39cef61  jmp 0x00007FD2B37FE110
00007fd2b39cef66  int3
00007fd2b39cef67  call 0x00007FD2B380D860
00007fd2b39cef6c  jmp 0x00007FD2B39CEE8A
00007fd2b39cef71  call 0x00007FD2B38B36E0
00007fd2b39cef76  jmp 0x00007FD2B39CEEBA
00007fd2b39cef7b  call 0x00007FD2B380DD60
00007fd2b39cef80  jmp 0x00007FD2B39CEED4
00007fd2b39cef85  call 0x00007FD2B380DC20
00007fd2b39cef8a  jmp 0x00007FD2B39CEEDE
00007fd2b39cef8f  int3
00007fd2b39cef90  mov rax, [r15+0x10]
00007fd2b39cef94  lea r14, [rax-0x01]
00007fd2b39cef98  mov [r15+0x10], r14
00007fd2b39cef9c  test r14, r14
00007fd2b39cef9f  setz r14b
00007fd2b39cefa3  movzx r14, r14b
00007fd2b39cefa7  mov [rsp+0x414], r14b
00007fd2b39cefaf  cmp byte ptr [rsp+0x414], 0x00
00007fd2b39cefb7  jz 0x00007FD2B39CEFE9
00007fd2b39cefb9  cmp dword ptr [r15+0x318], 0x00
00007fd2b39cefc1  jz 0x00007FD2B39D0520
00007fd2b39cefc7  nop [rax+rax*1], ax
00007fd2b39cefd0  nop [rax+rax*1], eax
00007fd2b39cefd8  mov eax, 0x410598
00007fd2b39cefdd  mov [r15+0x100], rax
00007fd2b39cefe4  jmp 0x00007FD2B37FE110
00007fd2b39cefe9  cmp dword ptr [r15+0x318], 0x00
00007fd2b39ceff1  jz 0x00007FD2B39CEE80
00007fd2b39ceff7  nop [rax+rax*1], ax
00007fd2b39cf000  nop [rax+rax*1], eax
00007fd2b39cf008  mov eax, 0x410380
00007fd2b39cf00d  mov [r15+0x100], rax
00007fd2b39cf014  jmp 0x00007FD2B37FE110
00007fd2b39cf019  int3
00007fd2b39cf01a  int3
00007fd2b39cf01b  nop [rax+rax*1], eax
00007fd2b39cf020  mov rax, [r15+0x40]
00007fd2b39cf024  movzx r14d, byte ptr [r13+rax*1]
00007fd2b39cf02a  movaps xmm1, [r15+0x110]
00007fd2b39cf032  pinsrb xmm1, r14d, 0x00
00007fd2b39cf039  lea r14, [rax+0x01]
00007fd2b39cf03d  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf043  movaps xmm15, [r15+0x120]
00007fd2b39cf04b  pinsrb xmm15, r12d, 0x00
00007fd2b39cf052  lea r14, [rax+0x02]
00007fd2b39cf056  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf05c  movaps xmm14, [r15+0x130]
00007fd2b39cf064  pinsrb xmm14, r12d, 0x00
00007fd2b39cf06b  lea r14, [rax+0x03]
00007fd2b39cf06f  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf075  movaps xmm13, [r15+0x140]
00007fd2b39cf07d  pinsrb xmm13, r12d, 0x00
00007fd2b39cf084  lea r14, [rax+0x04]
00007fd2b39cf088  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf08e  pinsrb xmm1, r12d, 0x01
00007fd2b39cf095  lea r14, [rax+0x05]
00007fd2b39cf099  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf09f  pinsrb xmm15, r12d, 0x01
00007fd2b39cf0a6  lea r14, [rax+0x06]
00007fd2b39cf0aa  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf0b0  pinsrb xmm14, r12d, 0x01
00007fd2b39cf0b7  lea r14, [rax+0x07]
00007fd2b39cf0bb  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf0c1  pinsrb xmm13, r12d, 0x01
00007fd2b39cf0c8  lea r14, [rax+0x08]
00007fd2b39cf0cc  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf0d2  pinsrb xmm1, r12d, 0x02
00007fd2b39cf0d9  lea r14, [rax+0x09]
00007fd2b39cf0dd  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf0e3  pinsrb xmm15, r12d, 0x02
00007fd2b39cf0ea  lea r14, [rax+0x0A]
00007fd2b39cf0ee  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf0f4  pinsrb xmm14, r12d, 0x02
00007fd2b39cf0fb  lea r14, [rax+0x0B]
00007fd2b39cf0ff  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf105  pinsrb xmm13, r12d, 0x02
00007fd2b39cf10c  lea r14, [rax+0x0C]
00007fd2b39cf110  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf116  pinsrb xmm1, r12d, 0x03
00007fd2b39cf11d  lea r14, [rax+0x0D]
00007fd2b39cf121  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf127  pinsrb xmm15, r12d, 0x03
00007fd2b39cf12e  lea r14, [rax+0x0E]
00007fd2b39cf132  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf138  pinsrb xmm14, r12d, 0x03
00007fd2b39cf13f  lea r14, [rax+0x0F]
00007fd2b39cf143  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf149  pinsrb xmm13, r12d, 0x03
00007fd2b39cf150  lea r14, [rax+0x10]
00007fd2b39cf154  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf15a  pinsrb xmm1, r12d, 0x04
00007fd2b39cf161  lea r14, [rax+0x11]
00007fd2b39cf165  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf16b  pinsrb xmm15, r12d, 0x04
00007fd2b39cf172  lea r14, [rax+0x12]
00007fd2b39cf176  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf17c  pinsrb xmm14, r12d, 0x04
00007fd2b39cf183  lea r14, [rax+0x13]
00007fd2b39cf187  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf18d  pinsrb xmm13, r12d, 0x04
00007fd2b39cf194  lea r14, [rax+0x14]
00007fd2b39cf198  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf19e  pinsrb xmm1, r12d, 0x05
00007fd2b39cf1a5  lea r14, [rax+0x15]
00007fd2b39cf1a9  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf1af  pinsrb xmm15, r12d, 0x05
00007fd2b39cf1b6  lea r14, [rax+0x16]
00007fd2b39cf1ba  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf1c0  pinsrb xmm14, r12d, 0x05
00007fd2b39cf1c7  lea r14, [rax+0x17]
00007fd2b39cf1cb  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf1d1  pinsrb xmm13, r12d, 0x05
00007fd2b39cf1d8  lea r14, [rax+0x18]
00007fd2b39cf1dc  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf1e2  pinsrb xmm1, r12d, 0x06
00007fd2b39cf1e9  lea r14, [rax+0x19]
00007fd2b39cf1ed  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf1f3  pinsrb xmm15, r12d, 0x06
00007fd2b39cf1fa  lea r14, [rax+0x1A]
00007fd2b39cf1fe  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf204  pinsrb xmm14, r12d, 0x06
00007fd2b39cf20b  lea r14, [rax+0x1B]
00007fd2b39cf20f  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf215  pinsrb xmm13, r12d, 0x06
00007fd2b39cf21c  lea r14, [rax+0x1C]
00007fd2b39cf220  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf226  pinsrb xmm1, r12d, 0x07
00007fd2b39cf22d  lea r14, [rax+0x1D]
00007fd2b39cf231  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf237  pinsrb xmm15, r12d, 0x07
00007fd2b39cf23e  lea r14, [rax+0x1E]
00007fd2b39cf242  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf248  pinsrb xmm14, r12d, 0x07
00007fd2b39cf24f  lea r14, [rax+0x1F]
00007fd2b39cf253  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf259  pinsrb xmm13, r12d, 0x07
00007fd2b39cf260  lea r14, [rax+0x20]
00007fd2b39cf264  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf26a  pinsrb xmm1, r12d, 0x08
00007fd2b39cf271  lea r14, [rax+0x21]
00007fd2b39cf275  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf27b  pinsrb xmm15, r12d, 0x08
00007fd2b39cf282  lea r14, [rax+0x22]
00007fd2b39cf286  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf28c  pinsrb xmm14, r12d, 0x08
00007fd2b39cf293  lea r14, [rax+0x23]
00007fd2b39cf297  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf29d  pinsrb xmm13, r12d, 0x08
00007fd2b39cf2a4  lea r14, [rax+0x24]
00007fd2b39cf2a8  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf2ae  pinsrb xmm1, r12d, 0x09
00007fd2b39cf2b5  lea r14, [rax+0x25]
00007fd2b39cf2b9  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf2bf  pinsrb xmm15, r12d, 0x09
00007fd2b39cf2c6  lea r14, [rax+0x26]
00007fd2b39cf2ca  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf2d0  pinsrb xmm14, r12d, 0x09
00007fd2b39cf2d7  lea r14, [rax+0x27]
00007fd2b39cf2db  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf2e1  pinsrb xmm13, r12d, 0x09
00007fd2b39cf2e8  lea r14, [rax+0x28]
00007fd2b39cf2ec  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf2f2  pinsrb xmm1, r12d, 0x0A
00007fd2b39cf2f9  lea r14, [rax+0x29]
00007fd2b39cf2fd  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf303  pinsrb xmm15, r12d, 0x0A
00007fd2b39cf30a  lea r14, [rax+0x2A]
00007fd2b39cf30e  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf314  pinsrb xmm14, r12d, 0x0A
00007fd2b39cf31b  lea r14, [rax+0x2B]
00007fd2b39cf31f  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf325  pinsrb xmm13, r12d, 0x0A
00007fd2b39cf32c  lea r14, [rax+0x2C]
00007fd2b39cf330  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf336  pinsrb xmm1, r12d, 0x0B
00007fd2b39cf33d  lea r14, [rax+0x2D]
00007fd2b39cf341  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf347  pinsrb xmm15, r12d, 0x0B
00007fd2b39cf34e  lea r14, [rax+0x2E]
00007fd2b39cf352  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf358  pinsrb xmm14, r12d, 0x0B
00007fd2b39cf35f  lea r14, [rax+0x2F]
00007fd2b39cf363  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf369  pinsrb xmm13, r12d, 0x0B
00007fd2b39cf370  lea r14, [rax+0x30]
00007fd2b39cf374  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf37a  pinsrb xmm1, r12d, 0x0C
00007fd2b39cf381  lea r14, [rax+0x31]
00007fd2b39cf385  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf38b  pinsrb xmm15, r12d, 0x0C
00007fd2b39cf392  lea r14, [rax+0x32]
00007fd2b39cf396  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf39c  pinsrb xmm14, r12d, 0x0C
00007fd2b39cf3a3  lea r14, [rax+0x33]
00007fd2b39cf3a7  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf3ad  pinsrb xmm13, r12d, 0x0C
00007fd2b39cf3b4  lea r14, [rax+0x34]
00007fd2b39cf3b8  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf3be  pinsrb xmm1, r12d, 0x0D
00007fd2b39cf3c5  lea r14, [rax+0x35]
00007fd2b39cf3c9  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf3cf  pinsrb xmm15, r12d, 0x0D
00007fd2b39cf3d6  lea r14, [rax+0x36]
00007fd2b39cf3da  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf3e0  pinsrb xmm14, r12d, 0x0D
00007fd2b39cf3e7  lea r14, [rax+0x37]
00007fd2b39cf3eb  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf3f1  pinsrb xmm13, r12d, 0x0D
00007fd2b39cf3f8  lea r14, [rax+0x38]
00007fd2b39cf3fc  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf402  pinsrb xmm1, r12d, 0x0E
00007fd2b39cf409  lea r14, [rax+0x39]
00007fd2b39cf40d  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf413  pinsrb xmm15, r12d, 0x0E
00007fd2b39cf41a  lea r14, [rax+0x3A]
00007fd2b39cf41e  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf424  pinsrb xmm14, r12d, 0x0E
00007fd2b39cf42b  lea r14, [rax+0x3B]
00007fd2b39cf42f  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf435  pinsrb xmm13, r12d, 0x0E
00007fd2b39cf43c  lea r14, [rax+0x3C]
00007fd2b39cf440  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf446  pinsrb xmm1, r12d, 0x0F
00007fd2b39cf44d  movaps [r15+0x110], xmm1
00007fd2b39cf455  lea r14, [rax+0x3D]
00007fd2b39cf459  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf45f  pinsrb xmm15, r12d, 0x0F
00007fd2b39cf466  movaps [r15+0x120], xmm15
00007fd2b39cf46e  lea r14, [rax+0x3E]
00007fd2b39cf472  movzx r12d, byte ptr [r13+r14*1]
00007fd2b39cf478  pinsrb xmm14, r12d, 0x0F
00007fd2b39cf47f  movaps [r15+0x130], xmm14
00007fd2b39cf487  lea r14, [rax+0x3F]
00007fd2b39cf48b  movzx eax, byte ptr [r13+r14*1]
00007fd2b39cf491  pinsrb xmm13, eax, 0x0F
00007fd2b39cf498  movaps [r15+0x140], xmm13
00007fd2b39cf4a0  movq xmm1, qword ptr [r15+0x120]
00007fd2b39cf4a9  pmovzxbw xmm1, xmm1
00007fd2b39cf4ae  psllw xmm1, 0x00
00007fd2b39cf4b3  movaps [r15+0x150], xmm1
00007fd2b39cf4bb  movq xmm1, qword ptr [r15+0x130]
00007fd2b39cf4c4  pmovzxbw xmm1, xmm1
00007fd2b39cf4c9  psllw xmm1, 0x00
00007fd2b39cf4ce  movaps [r15+0x160], xmm1
00007fd2b39cf4d6  movq xmm1, qword ptr [r15+0x110]
00007fd2b39cf4df  pmovzxbw xmm1, xmm1
00007fd2b39cf4e4  psllw xmm1, 0x00
00007fd2b39cf4e9  movaps [r15+0x170], xmm1
00007fd2b39cf4f1  movaps xmm15, [r15+0x110]
00007fd2b39cf4f9  pextrq rax, xmm15, 0x01
00007fd2b39cf500  movq xmm15, rax
00007fd2b39cf505  pmovzxbw xmm15, xmm15
00007fd2b39cf50b  psllw xmm15, 0x00
00007fd2b39cf511  movaps [r15+0x180], xmm15
00007fd2b39cf519  movaps xmm14, [r15+0x120]
00007fd2b39cf521  pextrq rax, xmm14, 0x01
00007fd2b39cf528  movq xmm14, rax
00007fd2b39cf52d  pmovzxbw xmm14, xmm14
00007fd2b39cf533  psllw xmm14, 0x00
00007fd2b39cf539  movaps [r15+0x210], xmm14
00007fd2b39cf541  movaps xmm13, [r15+0x130]
00007fd2b39cf549  pextrq rax, xmm13, 0x01
00007fd2b39cf550  movq xmm13, rax
00007fd2b39cf555  pmovzxbw xmm13, xmm13
00007fd2b39cf55b  psllw xmm13, 0x00
00007fd2b39cf561  movaps [r15+0x220], xmm13
00007fd2b39cf569  movq xmm12, qword ptr [r15+0x140]
00007fd2b39cf572  pmovzxbw xmm12, xmm12
00007fd2b39cf578  psllw xmm12, 0x00
00007fd2b39cf57e  movaps [r15+0x250], xmm12
00007fd2b39cf586  movaps xmm12, [r15+0x140]
00007fd2b39cf58e  pextrq rax, xmm12, 0x01
00007fd2b39cf595  movq xmm12, rax
00007fd2b39cf59a  pmovzxbw xmm12, xmm12
00007fd2b39cf5a0  psllw xmm12, 0x00
00007fd2b39cf5a6  movaps [r15+0x110], xmm12
00007fd2b39cf5ae  movq xmm11, qword ptr [r15+0x150]
00007fd2b39cf5b7  pmovzxwd xmm11, xmm11
00007fd2b39cf5bd  pslld xmm11, 0x10
00007fd2b39cf5c3  movq xmm10, qword ptr [r15+0x160]
00007fd2b39cf5cc  pmovzxwd xmm10, xmm10
00007fd2b39cf5d2  pslld xmm10, 0x08
00007fd2b39cf5d8  pextrq rax, xmm1, 0x01
00007fd2b39cf5df  movq xmm1, rax
00007fd2b39cf5e4  pmovzxwd xmm1, xmm1
00007fd2b39cf5e9  pslld xmm1, 0x00
00007fd2b39cf5ee  movaps [r15+0x260], xmm1
00007fd2b39cf5f6  pextrq rax, xmm15, 0x01
00007fd2b39cf5fd  movq xmm15, rax
00007fd2b39cf602  pmovzxwd xmm15, xmm15
00007fd2b39cf608  pslld xmm15, 0x00
00007fd2b39cf60e  movaps [r15+0x270], xmm15
00007fd2b39cf616  movq xmm9, qword ptr [r15+0x170]
00007fd2b39cf61f  pmovzxwd xmm9, xmm9
00007fd2b39cf625  pslld xmm9, 0x00
00007fd2b39cf62b  pextrq rax, xmm14, 0x01
00007fd2b39cf632  movq xmm14, rax
00007fd2b39cf637  pmovzxwd xmm14, xmm14
00007fd2b39cf63d  pslld xmm14, 0x10
00007fd2b39cf643  movaps [r15+0x280], xmm14
00007fd2b39cf64b  movq xmm8, qword ptr [r15+0x180]
00007fd2b39cf654  pmovzxwd xmm8, xmm8
00007fd2b39cf65a  pslld xmm8, 0x00
00007fd2b39cf660  movq xmm7, qword ptr [r15+0x210]
00007fd2b39cf669  pmovzxwd xmm7, xmm7
00007fd2b39cf66e  pslld xmm7, 0x10
00007fd2b39cf673  movaps xmm6, [r15+0x150]
00007fd2b39cf67b  pextrq rax, xmm6, 0x01
00007fd2b39cf682  movq xmm6, rax
00007fd2b39cf687  pmovzxwd xmm6, xmm6
00007fd2b39cf68c  pslld xmm6, 0x10
00007fd2b39cf691  por xmm11, xmm10
00007fd2b39cf696  movaps [r15+0x230], xmm11
00007fd2b39cf69e  pextrq rax, xmm13, 0x01
00007fd2b39cf6a5  movq xmm13, rax
00007fd2b39cf6aa  pmovzxwd xmm13, xmm13
00007fd2b39cf6b0  pslld xmm13, 0x08
00007fd2b39cf6b6  movaps [r15+0x240], xmm13
00007fd2b39cf6be  movq xmm10, qword ptr [r15+0x220]
00007fd2b39cf6c7  pmovzxwd xmm10, xmm10
00007fd2b39cf6cd  pslld xmm10, 0x08
00007fd2b39cf6d3  movaps xmm5, [r15+0x160]
00007fd2b39cf6db  pextrq rax, xmm5, 0x01
00007fd2b39cf6e2  movq xmm5, rax
00007fd2b39cf6e7  pmovzxwd xmm5, xmm5
00007fd2b39cf6ec  pslld xmm5, 0x08
00007fd2b39cf6f1  pslld xmm9, 0x18
00007fd2b39cf6f7  pslld xmm15, 0x18
00007fd2b39cf6fd  pslld xmm8, 0x18
00007fd2b39cf703  movq xmm4, qword ptr [r15+0x250]
00007fd2b39cf70c  pmovzxwd xmm4, xmm4
00007fd2b39cf711  pslld xmm4, 0x00
00007fd2b39cf716  por xmm14, xmm13
00007fd2b39cf71b  por xmm7, xmm10
00007fd2b39cf720  movaps [r15+0x210], xmm7
00007fd2b39cf728  pslld xmm1, 0x18
00007fd2b39cf72d  movaps [r15+0x220], xmm1
00007fd2b39cf735  por xmm6, xmm5
00007fd2b39cf739  por xmm11, xmm9
00007fd2b39cf73e  movaps [r15+0x160], xmm11
00007fd2b39cf746  pextrq rax, xmm12, 0x01
00007fd2b39cf74d  movq xmm13, rax
00007fd2b39cf752  pmovzxwd xmm13, xmm13
00007fd2b39cf758  pslld xmm13, 0x00
00007fd2b39cf75e  movaps [r15+0x170], xmm13
00007fd2b39cf766  movq xmm12, qword ptr [r15+0x110]
00007fd2b39cf76f  pmovzxwd xmm12, xmm12
00007fd2b39cf775  pslld xmm12, 0x00
00007fd2b39cf77b  por xmm14, xmm15
00007fd2b39cf780  por xmm7, xmm8
00007fd2b39cf785  movaps xmm15, [r15+0x250]
00007fd2b39cf78d  pextrq rax, xmm15, 0x01
00007fd2b39cf794  movq xmm15, rax
00007fd2b39cf799  pmovzxwd xmm15, xmm15
00007fd2b39cf79f  pslld xmm15, 0x00
00007fd2b39cf7a5  movaps [r15+0x180], xmm15
00007fd2b39cf7ad  por xmm6, xmm1
00007fd2b39cf7b1  movaps [r15+0x150], xmm6
00007fd2b39cf7b9  por xmm11, xmm4
00007fd2b39cf7be  movaps [r15+0x140], xmm11
00007fd2b39cf7c6  por xmm7, xmm12
00007fd2b39cf7cb  movaps [r15+0x110], xmm7
00007fd2b39cf7d3  por xmm14, xmm13
00007fd2b39cf7d8  movaps [r15+0x120], xmm14
00007fd2b39cf7e0  por xmm6, xmm15
00007fd2b39cf7e5  movaps [r15+0x130], xmm6
00007fd2b39cf7ed  mov rax, [r15+0xF8]
00007fd2b39cf7f4  lea r14, [rax+0x20]
00007fd2b39cf7f8  movups [r13+r14*1], xmm7
00007fd2b39cf7fe  lea r14, [rax+0x30]
00007fd2b39cf802  movups [r13+r14*1], xmm14
00007fd2b39cf808  movups [r13+rax*1], xmm11
00007fd2b39cf80e  lea r14, [rax+0x10]
00007fd2b39cf812  movups [r13+r14*1], xmm6
00007fd2b39cf818  mov r14d, [r13+rax*1]
00007fd2b39cf81d  mov rax, [r15+0x48]
00007fd2b39cf821  mov [r15+0x68], rax
00007fd2b39cf825  mov qword ptr [r15+0x58], 0x04
00007fd2b39cf82d  lea r12, [rax+0x04]
00007fd2b39cf831  mov r11d, [r13+r12*1]
00007fd2b39cf836  mov [rsp+0x10], r11d
00007fd2b39cf83b  mov r11d, r11d
00007fd2b39cf83e  mov [r15+0x70], r11
00007fd2b39cf842  lea r12, [rax+0x38]
00007fd2b39cf846  mov r11d, [r13+r12*1]
00007fd2b39cf84b  lea r12, [rax+0x24]
00007fd2b39cf84f  mov r10d, [r13+r12*1]
00007fd2b39cf854  mov [rsp+0x20], r10d
00007fd2b39cf859  mov r10d, r10d
00007fd2b39cf85c  mov [r15+0x90], r10
00007fd2b39cf863  mov [rsp+0x30], rax
00007fd2b39cf868  xor eax, eax
00007fd2b39cf86a  mov r12d, 0x04
00007fd2b39cf870  mov r10d, 0xC0
00007fd2b39cf876  cmp r12, r10
00007fd2b39cf879  cmc
00007fd2b39cf87a  lahf
00007fd2b39cf87b  seto al
00007fd2b39cf87e  mov [r15+0x108], eax
00007fd2b39cf885  mov eax, [rsp+0x10]
00007fd2b39cf889  mov r12d, [rsp+0x10]
00007fd2b39cf88e  shrd eax, r12d, 0x07
00007fd2b39cf893  mov [rsp+0x10], r11d
00007fd2b39cf898  mov r10d, [rsp+0x10]
00007fd2b39cf89d  shrd r11d, r10d, 0x11
00007fd2b39cf8a2  mov r9d, [rsp+0x20]
00007fd2b39cf8a7  lea r8d, [r9d+r14d*1]
00007fd2b39cf8ac  rorx r14d, r12d, 0x12
00007fd2b39cf8b2  xor eax, r14d
00007fd2b39cf8b5  rorx r14d, r10d, 0x13
00007fd2b39cf8bb  xor r11d, r14d
00007fd2b39cf8be  mov [rsp+0x10], r11d
00007fd2b39cf8c3  mov r11d, r11d
00007fd2b39cf8c6  mov [r15+0x88], r11
00007fd2b39cf8cd  mov [rsp+0x20], r12d
00007fd2b39cf8d2  shr r12d, 0x03
00007fd2b39cf8d6  xor eax, r12d
00007fd2b39cf8d9  mov [rsp+0x40], eax
00007fd2b39cf8dd  mov eax, eax
00007fd2b39cf8df  mov [r15+0x80], rax
00007fd2b39cf8e6  shr r10d, 0x0A
00007fd2b39cf8ea  mov eax, [rsp+0x10]
00007fd2b39cf8ee  xor eax, r10d
00007fd2b39cf8f1  mov [rsp+0x10], eax
00007fd2b39cf8f5  mov eax, eax
00007fd2b39cf8f7  mov [r15+0x78], rax
00007fd2b39cf8fb  mov eax, [rsp+0x40]
00007fd2b39cf8ff  lea r14d, [r8d+eax*1]
00007fd2b39cf904  mov eax, [rsp+0x10]
00007fd2b39cf908  lea r12d, [r14d+eax*1]
00007fd2b39cf90d  mov rax, [rsp+0x30]
00007fd2b39cf912  lea r14, [rax+0x40]
00007fd2b39cf916  mov [r13+r14*1], r12d
00007fd2b39cf91b  mov eax, [rsp+0x20]
00007fd2b39cf91f  mov eax, eax
00007fd2b39cf921  mov [r15+0x60], rax
00007fd2b39cf925  mov eax, [r15+0x108]
00007fd2b39cf92c  sahf
00007fd2b39cf92d  jnz 0x00007FD2B39CF95F
00007fd2b39cf92f  cmp dword ptr [r15+0x318], 0x00
00007fd2b39cf937  jz 0x00007FD2B39CFE20
00007fd2b39cf93d  nop [rax+rax*1], ax
00007fd2b39cf946  nop [rax+rax*1], eax
00007fd2b39cf94e  mov eax, 0x41049C
00007fd2b39cf953  mov [r15+0x100], rax
00007fd2b39cf95a  jmp 0x00007FD2B37FE110
00007fd2b39cf95f  cmp dword ptr [r15+0x318], 0x00
00007fd2b39cf967  jz 0x00007FD2B39CFC70
00007fd2b39cf96d  nop [rax+rax*1], ax
00007fd2b39cf976  nop [rax+rax*1], eax
00007fd2b39cf97e  mov eax, 0x410454
00007fd2b39cf983  mov [r15+0x100], rax
00007fd2b39cf98a  jmp 0x00007FD2B37FE110
00007fd2b39cf98f  int3
00007fd2b39cf990  call 0x00007FD2B380D860
00007fd2b39cf995  jmp 0x00007FD2B39CF02A
00007fd2b39cf99a  call 0x00007FD2B38E2420
00007fd2b39cf99f  jmp 0x00007FD2B39CF043
00007fd2b39cf9a4  call 0x00007FD2B38E2420
00007fd2b39cf9a9  jmp 0x00007FD2B39CF05C
00007fd2b39cf9ae  call 0x00007FD2B38E2420
00007fd2b39cf9b3  jmp 0x00007FD2B39CF075
00007fd2b39cf9b8  call 0x00007FD2B38E2420
00007fd2b39cf9bd  jmp 0x00007FD2B39CF08E
00007fd2b39cf9c2  call 0x00007FD2B38E2420
00007fd2b39cf9c7  jmp 0x00007FD2B39CF09F
00007fd2b39cf9cc  call 0x00007FD2B38E2420
00007fd2b39cf9d1  jmp 0x00007FD2B39CF0B0
00007fd2b39cf9d6  call 0x00007FD2B38E2420
00007fd2b39cf9db  jmp 0x00007FD2B39CF0C1
00007fd2b39cf9e0  call 0x00007FD2B38E2420
00007fd2b39cf9e5  jmp 0x00007FD2B39CF0D2
00007fd2b39cf9ea  call 0x00007FD2B38E2420
00007fd2b39cf9ef  jmp 0x00007FD2B39CF0E3
00007fd2b39cf9f4  call 0x00007FD2B38E2420
00007fd2b39cf9f9  jmp 0x00007FD2B39CF0F4
00007fd2b39cf9fe  call 0x00007FD2B38E2420
00007fd2b39cfa03  jmp 0x00007FD2B39CF105
00007fd2b39cfa08  call 0x00007FD2B38E2420
00007fd2b39cfa0d  jmp 0x00007FD2B39CF116
00007fd2b39cfa12  call 0x00007FD2B38E2420
00007fd2b39cfa17  jmp 0x00007FD2B39CF127
00007fd2b39cfa1c  call 0x00007FD2B38E2420
00007fd2b39cfa21  jmp 0x00007FD2B39CF138
00007fd2b39cfa26  call 0x00007FD2B38E2420
00007fd2b39cfa2b  jmp 0x00007FD2B39CF149
00007fd2b39cfa30  call 0x00007FD2B38E2420
00007fd2b39cfa35  jmp 0x00007FD2B39CF15A
00007fd2b39cfa3a  call 0x00007FD2B38E2420
00007fd2b39cfa3f  jmp 0x00007FD2B39CF16B
00007fd2b39cfa44  call 0x00007FD2B38E2420
00007fd2b39cfa49  jmp 0x00007FD2B39CF17C
00007fd2b39cfa4e  call 0x00007FD2B38E2420
00007fd2b39cfa53  jmp 0x00007FD2B39CF18D
00007fd2b39cfa58  call 0x00007FD2B38E2420
00007fd2b39cfa5d  jmp 0x00007FD2B39CF19E
00007fd2b39cfa62  call 0x00007FD2B38E2420
00007fd2b39cfa67  jmp 0x00007FD2B39CF1AF
00007fd2b39cfa6c  call 0x00007FD2B38E2420
00007fd2b39cfa71  jmp 0x00007FD2B39CF1C0
00007fd2b39cfa76  call 0x00007FD2B38E2420
00007fd2b39cfa7b  jmp 0x00007FD2B39CF1D1
00007fd2b39cfa80  call 0x00007FD2B38E2420
00007fd2b39cfa85  jmp 0x00007FD2B39CF1E2
00007fd2b39cfa8a  call 0x00007FD2B38E2420
00007fd2b39cfa8f  jmp 0x00007FD2B39CF1F3
00007fd2b39cfa94  call 0x00007FD2B38E2420
00007fd2b39cfa99  jmp 0x00007FD2B39CF204
00007fd2b39cfa9e  call 0x00007FD2B38E2420
00007fd2b39cfaa3  jmp 0x00007FD2B39CF215
00007fd2b39cfaa8  call 0x00007FD2B38E2420
00007fd2b39cfaad  jmp 0x00007FD2B39CF226
00007fd2b39cfab2  call 0x00007FD2B38E2420
00007fd2b39cfab7  jmp 0x00007FD2B39CF237
00007fd2b39cfabc  call 0x00007FD2B38E2420
00007fd2b39cfac1  jmp 0x00007FD2B39CF248
00007fd2b39cfac6  call 0x00007FD2B38E2420
00007fd2b39cfacb  jmp 0x00007FD2B39CF259
00007fd2b39cfad0  call 0x00007FD2B38E2420
00007fd2b39cfad5  jmp 0x00007FD2B39CF26A
00007fd2b39cfada  call 0x00007FD2B38E2420
00007fd2b39cfadf  jmp 0x00007FD2B39CF27B
00007fd2b39cfae4  call 0x00007FD2B38E2420
00007fd2b39cfae9  jmp 0x00007FD2B39CF28C
00007fd2b39cfaee  call 0x00007FD2B38E2420
00007fd2b39cfaf3  jmp 0x00007FD2B39CF29D
00007fd2b39cfaf8  call 0x00007FD2B38E2420
00007fd2b39cfafd  jmp 0x00007FD2B39CF2AE
00007fd2b39cfb02  call 0x00007FD2B38E2420
00007fd2b39cfb07  jmp 0x00007FD2B39CF2BF
00007fd2b39cfb0c  call 0x00007FD2B38E2420
00007fd2b39cfb11  jmp 0x00007FD2B39CF2D0
00007fd2b39cfb16  call 0x00007FD2B38E2420
00007fd2b39cfb1b  jmp 0x00007FD2B39CF2E1
00007fd2b39cfb20  call 0x00007FD2B38E2420
00007fd2b39cfb25  jmp 0x00007FD2B39CF2F2
00007fd2b39cfb2a  call 0x00007FD2B38E2420
00007fd2b39cfb2f  jmp 0x00007FD2B39CF303
00007fd2b39cfb34  call 0x00007FD2B38E2420
00007fd2b39cfb39  jmp 0x00007FD2B39CF314
00007fd2b39cfb3e  call 0x00007FD2B38E2420
00007fd2b39cfb43  jmp 0x00007FD2B39CF325
00007fd2b39cfb48  call 0x00007FD2B38E2420
00007fd2b39cfb4d  jmp 0x00007FD2B39CF336
00007fd2b39cfb52  call 0x00007FD2B38E2420
00007fd2b39cfb57  jmp 0x00007FD2B39CF347
00007fd2b39cfb5c  call 0x00007FD2B38E2420
00007fd2b39cfb61  jmp 0x00007FD2B39CF358
00007fd2b39cfb66  call 0x00007FD2B38E2420
00007fd2b39cfb6b  jmp 0x00007FD2B39CF369
00007fd2b39cfb70  call 0x00007FD2B38E2420
00007fd2b39cfb75  jmp 0x00007FD2B39CF37A
00007fd2b39cfb7a  call 0x00007FD2B38E2420
00007fd2b39cfb7f  jmp 0x00007FD2B39CF38B
00007fd2b39cfb84  call 0x00007FD2B38E2420
00007fd2b39cfb89  jmp 0x00007FD2B39CF39C
00007fd2b39cfb8e  call 0x00007FD2B38E2420
00007fd2b39cfb93  jmp 0x00007FD2B39CF3AD
00007fd2b39cfb98  call 0x00007FD2B38E2420
00007fd2b39cfb9d  jmp 0x00007FD2B39CF3BE
00007fd2b39cfba2  call 0x00007FD2B38E2420
00007fd2b39cfba7  jmp 0x00007FD2B39CF3CF
00007fd2b39cfbac  call 0x00007FD2B38E2420
00007fd2b39cfbb1  jmp 0x00007FD2B39CF3E0
00007fd2b39cfbb6  call 0x00007FD2B38E2420
00007fd2b39cfbbb  jmp 0x00007FD2B39CF3F1
00007fd2b39cfbc0  call 0x00007FD2B38E2420
00007fd2b39cfbc5  jmp 0x00007FD2B39CF402
00007fd2b39cfbca  call 0x00007FD2B38E2420
00007fd2b39cfbcf  jmp 0x00007FD2B39CF413
00007fd2b39cfbd4  call 0x00007FD2B38E2420
00007fd2b39cfbd9  jmp 0x00007FD2B39CF424
00007fd2b39cfbde  call 0x00007FD2B38E2420
00007fd2b39cfbe3  jmp 0x00007FD2B39CF435
00007fd2b39cfbe8  call 0x00007FD2B38E2420
00007fd2b39cfbed  jmp 0x00007FD2B39CF446
00007fd2b39cfbf2  call 0x00007FD2B38E2420
00007fd2b39cfbf7  jmp 0x00007FD2B39CF45F
00007fd2b39cfbfc  call 0x00007FD2B38E2420
00007fd2b39cfc01  jmp 0x00007FD2B39CF478
00007fd2b39cfc06  call 0x00007FD2B38D5610
00007fd2b39cfc0b  jmp 0x00007FD2B39CF491
00007fd2b39cfc10  call 0x00007FD2B38DC580
00007fd2b39cfc15  jmp 0x00007FD2B39CF7FE
00007fd2b39cfc1a  call 0x00007FD2B38E46C0
00007fd2b39cfc1f  jmp 0x00007FD2B39CF808
00007fd2b39cfc24  call 0x00007FD2B3809E90
00007fd2b39cfc29  jmp 0x00007FD2B39CF80E
00007fd2b39cfc2e  call 0x00007FD2B38DB310
00007fd2b39cfc33  jmp 0x00007FD2B39CF818
00007fd2b39cfc38  call 0x00007FD2B380DAE0
00007fd2b39cfc3d  jmp 0x00007FD2B39CF81D
00007fd2b39cfc42  call 0x00007FD2B38C0230
00007fd2b39cfc47  jmp 0x00007FD2B39CF836
00007fd2b39cfc4c  call 0x00007FD2B38C0230
00007fd2b39cfc51  jmp 0x00007FD2B39CF84B
00007fd2b39cfc56  call 0x00007FD2B38BEFC0
00007fd2b39cfc5b  jmp 0x00007FD2B39CF854
00007fd2b39cfc60  call 0x00007FD2B38E2BA0
00007fd2b39cfc65  jmp 0x00007FD2B39CF91B
00007fd2b39cfc6a  int3
00007fd2b39cfc6b  nop [rax+rax*1], eax
00007fd2b39cfc70  mov rax, [r15+0x48]
00007fd2b39cfc74  mov r14, [r15+0x58]
00007fd2b39cfc78  lea r12, [rax+r14*1]
00007fd2b39cfc7c  mov [r15+0x68], r12
00007fd2b39cfc80  lea rax, [r14+0x04]
00007fd2b39cfc84  mov [r15+0x58], rax
00007fd2b39cfc88  lea r14, [r12+0x04]
00007fd2b39cfc8d  mov r11d, [r13+r14*1]
00007fd2b39cfc92  mov [rsp+0x10], r11d
00007fd2b39cfc97  mov r11d, r11d
00007fd2b39cfc9a  mov [r15+0x70], r11
00007fd2b39cfc9e  lea r14, [r12+0x38]
00007fd2b39cfca3  mov r11d, [r13+r14*1]
00007fd2b39cfca8  lea r14, [r12+0x24]
00007fd2b39cfcad  mov r10d, [r13+r14*1]
00007fd2b39cfcb2  mov [rsp+0x20], r10d
00007fd2b39cfcb7  mov r10d, r10d
00007fd2b39cfcba  mov [r15+0x90], r10
00007fd2b39cfcc1  mov [rsp+0x30], rax
00007fd2b39cfcc6  xor eax, eax
00007fd2b39cfcc8  mov r14, [rsp+0x30]
00007fd2b39cfccd  mov r10d, 0xC0
00007fd2b39cfcd3  cmp r14, r10
00007fd2b39cfcd6  cmc
00007fd2b39cfcd7  lahf
00007fd2b39cfcd8  seto al
00007fd2b39cfcdb  mov [r15+0x108], eax
00007fd2b39cfce2  mov eax, [rsp+0x10]
00007fd2b39cfce6  mov r14d, [rsp+0x10]
00007fd2b39cfceb  shrd eax, r14d, 0x07
00007fd2b39cfcf0  mov [rsp+0x10], r11d
00007fd2b39cfcf5  mov r10d, [rsp+0x10]
00007fd2b39cfcfa  shrd r11d, r10d, 0x11
00007fd2b39cfcff  mov r9d, [r15+0x60]
00007fd2b39cfd03  mov r8d, [rsp+0x20]
00007fd2b39cfd08  lea ebp, [r8d+r9d*1]
00007fd2b39cfd0d  rorx r9d, r14d, 0x12
00007fd2b39cfd13  xor eax, r9d
00007fd2b39cfd16  rorx r9d, r10d, 0x13
00007fd2b39cfd1c  xor r11d, r9d
00007fd2b39cfd1f  mov [rsp+0x10], r11d
00007fd2b39cfd24  mov r11d, r11d
00007fd2b39cfd27  mov [r15+0x88], r11
00007fd2b39cfd2e  mov [rsp+0x20], r14d
00007fd2b39cfd33  shr r14d, 0x03
00007fd2b39cfd37  xor eax, r14d
00007fd2b39cfd3a  mov [rsp+0x30], eax
00007fd2b39cfd3e  mov eax, eax
00007fd2b39cfd40  mov [r15+0x80], rax
00007fd2b39cfd47  shr r10d, 0x0A
00007fd2b39cfd4b  mov eax, [rsp+0x10]
00007fd2b39cfd4f  xor eax, r10d
00007fd2b39cfd52  mov [rsp+0x10], eax
00007fd2b39cfd56  mov eax, eax
00007fd2b39cfd58  mov [r15+0x78], rax
00007fd2b39cfd5c  mov eax, [rsp+0x30]
00007fd2b39cfd60  lea r14d, [ebp+eax*1]
00007fd2b39cfd66  mov eax, [rsp+0x10]
00007fd2b39cfd6a  lea r11d, [r14d+eax*1]
00007fd2b39cfd6f  lea rax, [r12+0x40]
00007fd2b39cfd74  mov [r13+rax*1], r11d
00007fd2b39cfd79  mov eax, [rsp+0x20]
00007fd2b39cfd7d  mov eax, eax
00007fd2b39cfd7f  mov [r15+0x60], rax
00007fd2b39cfd83  mov eax, [r15+0x108]
00007fd2b39cfd8a  sahf
00007fd2b39cfd8b  jnz 0x00007FD2B39CFDBD
00007fd2b39cfd8d  cmp dword ptr [r15+0x318], 0x00
00007fd2b39cfd95  jz 0x00007FD2B39CFE20
00007fd2b39cfd9b  nop [rax+rax*1], ax
00007fd2b39cfda4  nop [rax+rax*1], eax
00007fd2b39cfdac  mov eax, 0x41049C
00007fd2b39cfdb1  mov [r15+0x100], rax
00007fd2b39cfdb8  jmp 0x00007FD2B37FE110
00007fd2b39cfdbd  cmp dword ptr [r15+0x318], 0x00
00007fd2b39cfdc5  jz 0x00007FD2B39CFC70
00007fd2b39cfdcb  nop [rax+rax*1], ax
00007fd2b39cfdd4  nop [rax+rax*1], eax
00007fd2b39cfddc  mov eax, 0x410454
00007fd2b39cfde1  mov [r15+0x100], rax
00007fd2b39cfde8  jmp 0x00007FD2B37FE110
00007fd2b39cfded  int3
00007fd2b39cfdee  call 0x00007FD2B38E1430
00007fd2b39cfdf3  jmp 0x00007FD2B39CFC92
00007fd2b39cfdf8  call 0x00007FD2B38E1430
00007fd2b39cfdfd  jmp 0x00007FD2B39CFCA8
00007fd2b39cfe02  call 0x00007FD2B38E01C0
00007fd2b39cfe07  jmp 0x00007FD2B39CFCB2
00007fd2b39cfe0c  call 0x00007FD2B380A860
00007fd2b39cfe11  jmp 0x00007FD2B39CFD79
00007fd2b39cfe16  int3
00007fd2b39cfe17  nop [rax+rax*1], ax
00007fd2b39cfe20  mov rax, [r15]
00007fd2b39cfe23  mov r14d, [r13+rax*1]
00007fd2b39cfe28  lea r12, [rax+0x04]
00007fd2b39cfe2c  mov r11d, [r13+r12*1]
00007fd2b39cfe31  mov [rsp+0x10], r14d
00007fd2b39cfe36  mov r14d, r14d
00007fd2b39cfe39  mov [r15+0x78], r14
00007fd2b39cfe3d  mov [rsp+0x20], r11d
00007fd2b39cfe42  mov r11d, r11d
00007fd2b39cfe45  mov [r15+0x80], r11
00007fd2b39cfe4c  lea r14, [rax+0x08]
00007fd2b39cfe50  mov r12d, [r13+r14*1]
00007fd2b39cfe55  lea r14, [rax+0x0C]
00007fd2b39cfe59  mov r11d, [r13+r14*1]
00007fd2b39cfe5e  mov [rsp+0x30], r12d
00007fd2b39cfe63  mov r12d, r12d
00007fd2b39cfe66  mov [r15+0x70], r12
00007fd2b39cfe6a  mov [rsp+0x40], r11d
00007fd2b39cfe6f  mov r11d, r11d
00007fd2b39cfe72  mov [r15+0x68], r11
00007fd2b39cfe76  lea r14, [rax+0x18]
00007fd2b39cfe7a  mov r12d, [r13+r14*1]
00007fd2b39cfe7f  lea r14, [rax+0x1C]
00007fd2b39cfe83  mov r11d, [r13+r14*1]
00007fd2b39cfe88  mov [rsp+0x50], r12d
00007fd2b39cfe8d  mov r12d, r12d
00007fd2b39cfe90  mov [r15+0x58], r12
00007fd2b39cfe94  mov [rsp+0x60], r11d
00007fd2b39cfe99  mov r11d, r11d
00007fd2b39cfe9c  mov [r15+0x60], r11
00007fd2b39cfea0  lea r14, [rax+0x10]
00007fd2b39cfea4  mov r12d, [r13+r14*1]
00007fd2b39cfea9  lea r14, [rax+0x14]
00007fd2b39cfead  mov eax, [r13+r14*1]
00007fd2b39cfeb2  mov [rsp+0x70], r12d
00007fd2b39cfeb7  mov r12d, r12d
00007fd2b39cfeba  mov [r15+0x18], r12
00007fd2b39cfebe  mov [rsp+0x80], eax
00007fd2b39cfec5  mov eax, eax
00007fd2b39cfec7  mov [r15+0x90], rax
00007fd2b39cfece  mov eax, [rsp+0x70]
00007fd2b39cfed2  mov eax, eax
00007fd2b39cfed4  mov [r15+0x30], rax
00007fd2b39cfed8  mov eax, [rsp+0x50]
00007fd2b39cfedc  mov eax, eax
00007fd2b39cfede  mov [r15+0xA0], rax
00007fd2b39cfee5  mov eax, [rsp+0x30]
00007fd2b39cfee9  mov eax, eax
00007fd2b39cfeeb  mov [r15+0x28], rax
00007fd2b39cfeef  mov eax, [rsp+0x20]
00007fd2b39cfef3  mov eax, eax
00007fd2b39cfef5  mov [r15+0x98], rax
00007fd2b39cfefc  mov eax, [rsp+0x10]
00007fd2b39cff00  mov eax, eax
00007fd2b39cff02  mov [r15+0x38], rax
00007fd2b39cff06  mov eax, [rsp+0x70]
00007fd2b39cff0a  mov r14d, [rsp+0x70]
00007fd2b39cff0f  shrd eax, r14d, 0x06
00007fd2b39cff14  mov [rsp+0x70], r14d
00007fd2b39cff19  mov r12d, [rsp+0x80]
00007fd2b39cff21  and r14d, r12d
00007fd2b39cff24  mov r11d, [rsp+0x10]
00007fd2b39cff29  mov r10d, [rsp+0x10]
00007fd2b39cff2e  shrd r11d, r10d, 0x02
00007fd2b39cff33  mov [rsp+0x10], r12d
00007fd2b39cff38  mov r12d, r12d
00007fd2b39cff3b  mov [r15+0x20], r12
00007fd2b39cff3f  mov r12, [r15+0x50]
00007fd2b39cff43  mov r9d, [r13+r12*1]
00007fd2b39cff48  mov r12d, [rsp+0x50]
00007fd2b39cff4d  mov r8d, [rsp+0x70]
00007fd2b39cff52  andn ebp, r8d, r12d
00007fd2b39cff57  mov edi, [rsp+0x60]
00007fd2b39cff5b  lea esi, [r14d+edi*1]
00007fd2b39cff60  rorx r14d, r8d, 0x0B
00007fd2b39cff66  xor eax, r14d
00007fd2b39cff69  rorx r14d, r10d, 0x0D
00007fd2b39cff6f  xor r11d, r14d
00007fd2b39cff72  lea edi, [esi+ebp*1]
00007fd2b39cff76  mov r14, [r15+0x48]
00007fd2b39cff7a  mov ebp, [r13+r14*1]
00007fd2b39cff7f  mov r14d, [rsp+0x30]
00007fd2b39cff84  mov esi, [rsp+0x20]
00007fd2b39cff88  and r14d, esi
00007fd2b39cff8b  mov [rsp+0x20], r14d
00007fd2b39cff90  mov r14d, r14d
00007fd2b39cff93  mov [r15+0xD8], r14
00007fd2b39cff9a  lea r14d, [edi+r9d*1]
00007fd2b39cff9f  mov r9d, [rsp+0x30]
00007fd2b39cffa4  xor r9d, esi
00007fd2b39cffa7  rorx edi, r8d, 0x19
00007fd2b39cffad  xor eax, edi
00007fd2b39cffaf  and r9d, r10d
00007fd2b39cffb2  rorx edi, r10d, 0x16
00007fd2b39cffb8  xor r11d, edi
00007fd2b39cffbb  mov [rsp+0x30], r11d
00007fd2b39cffc0  mov r11d, r11d
00007fd2b39cffc3  mov [r15+0xD0], r11
00007fd2b39cffca  lea r11d, [r14d+ebp*1]
00007fd2b39cffcf  mov r10d, [rsp+0x20]
00007fd2b39cffd4  xor r9d, r10d
00007fd2b39cffd7  lea r14d, [r11d+eax*1]
00007fd2b39cffdc  mov qword ptr [r15+0x88], 0x04
00007fd2b39cffe7  mov eax, [rsp+0x30]
00007fd2b39cffeb  lea r11d, [r9d+eax*1]
00007fd2b39cfff0  mov eax, [rsp+0x40]
00007fd2b39cfff4  lea r10d, [r14d+eax*1]
00007fd2b39cfff9  mov r10d, r10d
00007fd2b39cfffc  mov [r15+0xB8], r10
00007fd2b39d0003  xor eax, eax
00007fd2b39d0005  mov r10d, 0x04
00007fd2b39d000b  mov r9d, 0x100
00007fd2b39d0011  cmp r10, r9
00007fd2b39d0014  cmc
00007fd2b39d0015  lahf
00007fd2b39d0016  seto al
00007fd2b39d0019  mov [r15+0x108], eax
00007fd2b39d0020  lea eax, [r11d+r14d*1]
00007fd2b39d0025  mov eax, eax
00007fd2b39d0027  mov [r15+0xA8], rax
00007fd2b39d002e  mov r12d, r12d
00007fd2b39d0031  mov [r15+0xB0], r12
00007fd2b39d0038  mov eax, [rsp+0x10]
00007fd2b39d003c  mov eax, eax
00007fd2b39d003e  mov [r15+0xC0], rax
00007fd2b39d0045  mov r8d, r8d
00007fd2b39d0048  mov [r15+0xC8], r8
00007fd2b39d004f  mov eax, [r15+0x108]
00007fd2b39d0056  sahf
00007fd2b39d0057  jnz 0x00007FD2B39D0089
00007fd2b39d0059  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d0061  jz 0x00007FD2B39D0350
00007fd2b39d0067  nop [rax+rax*1], ax
00007fd2b39d0070  nop [rax+rax*1], eax
00007fd2b39d0078  mov eax, 0x41055C
00007fd2b39d007d  mov [r15+0x100], rax
00007fd2b39d0084  jmp 0x00007FD2B37FE110
00007fd2b39d0089  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d0091  jz 0x00007FD2B39D0120
00007fd2b39d0097  nop [rax+rax*1], ax
00007fd2b39d00a0  nop [rax+rax*1], eax
00007fd2b39d00a8  mov eax, 0x4104D0
00007fd2b39d00ad  mov [r15+0x100], rax
00007fd2b39d00b4  jmp 0x00007FD2B37FE110
00007fd2b39d00b9  int3
00007fd2b39d00ba  call 0x00007FD2B380DAE0
00007fd2b39d00bf  jmp 0x00007FD2B39CFE28
00007fd2b39d00c4  call 0x00007FD2B38C0230
00007fd2b39d00c9  jmp 0x00007FD2B39CFE31
00007fd2b39d00ce  call 0x00007FD2B38E26A0
00007fd2b39d00d3  jmp 0x00007FD2B39CFE55
00007fd2b39d00d8  call 0x00007FD2B38E1430
00007fd2b39d00dd  jmp 0x00007FD2B39CFE5E
00007fd2b39d00e2  call 0x00007FD2B38E26A0
00007fd2b39d00e7  jmp 0x00007FD2B39CFE7F
00007fd2b39d00ec  call 0x00007FD2B38E1430
00007fd2b39d00f1  jmp 0x00007FD2B39CFE88
00007fd2b39d00f6  call 0x00007FD2B38E26A0
00007fd2b39d00fb  jmp 0x00007FD2B39CFEA9
00007fd2b39d0100  call 0x00007FD2B38D5890
00007fd2b39d0105  jmp 0x00007FD2B39CFEB2
00007fd2b39d010a  call 0x00007FD2B38BDD50
00007fd2b39d010f  jmp 0x00007FD2B39CFF48
00007fd2b39d0114  call 0x00007FD2B38DA580
00007fd2b39d0119  jmp 0x00007FD2B39CFF7F
00007fd2b39d011e  int3
00007fd2b39d011f  nop
00007fd2b39d0120  mov eax, [r15+0xB8]
00007fd2b39d0127  mov [rsp+0x10], eax
00007fd2b39d012b  mov eax, eax
00007fd2b39d012d  mov [r15+0x30], rax
00007fd2b39d0131  mov eax, [r15+0xC0]
00007fd2b39d0138  mov [rsp+0x20], eax
00007fd2b39d013c  mov eax, eax
00007fd2b39d013e  mov [r15+0xA0], rax
00007fd2b39d0145  mov eax, [r15+0x28]
00007fd2b39d0149  mov r14d, [r15+0x98]
00007fd2b39d0150  mov [rsp+0x30], r14d
00007fd2b39d0155  mov r14d, r14d
00007fd2b39d0158  mov [r15+0x28], r14
00007fd2b39d015c  mov r14d, [r15+0x38]
00007fd2b39d0160  mov [rsp+0x40], r14d
00007fd2b39d0165  mov r14d, r14d
00007fd2b39d0168  mov [r15+0x98], r14
00007fd2b39d016f  mov r14d, [r15+0xA8]
00007fd2b39d0176  mov [rsp+0x50], r14d
00007fd2b39d017b  mov r14d, r14d
00007fd2b39d017e  mov [r15+0x38], r14
00007fd2b39d0182  mov r14d, [rsp+0x10]
00007fd2b39d0187  mov r12d, [rsp+0x10]
00007fd2b39d018c  shrd r14d, r12d, 0x06
00007fd2b39d0191  mov r11d, [r15+0xC8]
00007fd2b39d0198  mov [rsp+0x10], r12d
00007fd2b39d019d  and r12d, r11d
00007fd2b39d01a0  mov r10d, [rsp+0x50]
00007fd2b39d01a5  mov r9d, [rsp+0x50]
00007fd2b39d01aa  shrd r10d, r9d, 0x02
00007fd2b39d01af  mov [rsp+0x50], r11d
00007fd2b39d01b4  mov r11d, r11d
00007fd2b39d01b7  mov [r15+0x20], r11
00007fd2b39d01bb  mov r11, [r15+0x88]
00007fd2b39d01c2  mov r8, [r15+0x50]
00007fd2b39d01c6  lea rbp, [r8+r11*1]
00007fd2b39d01ca  mov r8d, [r13+rbp*1]
00007fd2b39d01cf  mov ebp, [rsp+0x20]
00007fd2b39d01d3  mov edi, [rsp+0x10]
00007fd2b39d01d7  andn esi, edi, ebp
00007fd2b39d01dc  mov edx, [r15+0xB0]
00007fd2b39d01e3  lea ecx, [r12d+edx*1]
00007fd2b39d01e8  rorx r12d, edi, 0x0B
00007fd2b39d01ee  xor r14d, r12d
00007fd2b39d01f1  rorx r12d, r9d, 0x0D
00007fd2b39d01f7  xor r10d, r12d
00007fd2b39d01fa  lea r12d, [ecx+esi*1]
00007fd2b39d01ff  mov rsi, [r15+0x48]
00007fd2b39d0203  lea rdx, [rsi+r11*1]
00007fd2b39d0207  mov esi, [r13+rdx*1]
00007fd2b39d020c  mov edx, [rsp+0x30]
00007fd2b39d0210  mov ecx, [rsp+0x40]
00007fd2b39d0214  and edx, ecx
00007fd2b39d0216  mov [rsp+0x10], edx
00007fd2b39d021a  mov edx, edx
00007fd2b39d021c  mov [r15+0xD8], rdx
00007fd2b39d0223  lea edx, [r12d+r8d*1]
00007fd2b39d0228  mov r12d, [rsp+0x30]
00007fd2b39d022d  xor r12d, ecx
00007fd2b39d0230  rorx r8d, edi, 0x19
00007fd2b39d0236  xor r14d, r8d
00007fd2b39d0239  and r12d, r9d
00007fd2b39d023c  rorx r8d, r9d, 0x16
00007fd2b39d0242  xor r10d, r8d
00007fd2b39d0245  mov [rsp+0x20], r10d
00007fd2b39d024a  mov r10d, r10d
00007fd2b39d024d  mov [r15+0xD0], r10
00007fd2b39d0254  lea r10d, [edx+esi*1]
00007fd2b39d0259  mov r9d, [rsp+0x10]
00007fd2b39d025e  xor r12d, r9d
00007fd2b39d0261  lea r9d, [r10d+r14d*1]
00007fd2b39d0266  lea r14, [r11+0x04]
00007fd2b39d026a  mov [r15+0x88], r14
00007fd2b39d0271  mov r11d, [rsp+0x20]
00007fd2b39d0276  lea r10d, [r12d+r11d*1]
00007fd2b39d027b  lea r11d, [r9d+eax*1]
00007fd2b39d0280  mov r11d, r11d
00007fd2b39d0283  mov [r15+0xB8], r11
00007fd2b39d028a  xor eax, eax
00007fd2b39d028c  mov r12d, 0x100
00007fd2b39d0292  cmp r14, r12
00007fd2b39d0295  cmc
00007fd2b39d0296  lahf
00007fd2b39d0297  seto al
00007fd2b39d029a  mov [r15+0x108], eax
00007fd2b39d02a1  lea eax, [r10d+r9d*1]
00007fd2b39d02a6  mov eax, eax
00007fd2b39d02a8  mov [r15+0xA8], rax
00007fd2b39d02af  mov ebp, ebp
00007fd2b39d02b1  mov [r15+0xB0], rbp
00007fd2b39d02b8  mov eax, [rsp+0x50]
00007fd2b39d02bc  mov eax, eax
00007fd2b39d02be  mov [r15+0xC0], rax
00007fd2b39d02c5  mov edi, edi
00007fd2b39d02c7  mov [r15+0xC8], rdi
00007fd2b39d02ce  mov eax, [r15+0x108]
00007fd2b39d02d5  sahf
00007fd2b39d02d6  jnz 0x00007FD2B39D0308
00007fd2b39d02d8  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d02e0  jz 0x00007FD2B39D0350
00007fd2b39d02e6  nop [rax+rax*1], ax
00007fd2b39d02ef  nop [rax+rax*1], eax
00007fd2b39d02f7  mov eax, 0x41055C
00007fd2b39d02fc  mov [r15+0x100], rax
00007fd2b39d0303  jmp 0x00007FD2B37FE110
00007fd2b39d0308  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d0310  jz 0x00007FD2B39D0120
00007fd2b39d0316  nop [rax+rax*1], ax
00007fd2b39d031f  nop [rax+rax*1], eax
00007fd2b39d0327  mov eax, 0x4104D0
00007fd2b39d032c  mov [r15+0x100], rax
00007fd2b39d0333  jmp 0x00007FD2B37FE110
00007fd2b39d0338  int3
00007fd2b39d0339  call 0x00007FD2B3849010
00007fd2b39d033e  jmp 0x00007FD2B39D01CF
00007fd2b39d0343  call 0x00007FD2B3825930
00007fd2b39d0348  jmp 0x00007FD2B39D020C
00007fd2b39d034d  int3
00007fd2b39d034e  nop
00007fd2b39d0350  mov eax, [r15+0x98]
00007fd2b39d0357  mov r14d, [r15+0x70]
00007fd2b39d035b  lea r12d, [eax+r14d*1]
00007fd2b39d0360  mov eax, [r15+0x28]
00007fd2b39d0364  mov r14d, [r15+0x68]
00007fd2b39d0368  lea r11d, [eax+r14d*1]
00007fd2b39d036d  mov qword ptr [r15+0x88], 0x00
00007fd2b39d0378  mov eax, [r15+0xA8]
00007fd2b39d037f  mov r14d, [r15+0x78]
00007fd2b39d0383  lea r10d, [eax+r14d*1]
00007fd2b39d0388  mov [rsp+0x10], r10d
00007fd2b39d038d  mov r10d, r10d
00007fd2b39d0390  mov [r15+0x78], r10
00007fd2b39d0394  mov eax, [r15+0x38]
00007fd2b39d0398  mov r14d, [r15+0x80]
00007fd2b39d039f  lea r10d, [eax+r14d*1]
00007fd2b39d03a4  mov [rsp+0x20], r10d
00007fd2b39d03a9  mov r10d, r10d
00007fd2b39d03ac  mov [r15+0x80], r10
00007fd2b39d03b3  mov rax, [r15]
00007fd2b39d03b6  lea r14, [rax+0x08]
00007fd2b39d03ba  mov [r13+r14*1], r12d
00007fd2b39d03bf  lea r14, [rax+0x0C]
00007fd2b39d03c3  mov [r13+r14*1], r11d
00007fd2b39d03c8  mov r14d, [r15+0xB8]
00007fd2b39d03cf  mov r12d, [r15+0x18]
00007fd2b39d03d3  lea r11d, [r14d+r12d*1]
00007fd2b39d03d8  mov [rsp+0x30], r11d
00007fd2b39d03dd  mov r11d, r11d
00007fd2b39d03e0  mov [r15+0x68], r11
00007fd2b39d03e4  mov r14d, [r15+0x30]
00007fd2b39d03e8  mov r12d, [r15+0x90]
00007fd2b39d03ef  lea r11d, [r14d+r12d*1]
00007fd2b39d03f4  mov [rsp+0x40], r11d
00007fd2b39d03f9  mov r11d, r11d
00007fd2b39d03fc  mov [r15+0x70], r11
00007fd2b39d0400  mov r14d, [r15+0x20]
00007fd2b39d0404  mov r12d, [r15+0x58]
00007fd2b39d0408  lea r11d, [r14d+r12d*1]
00007fd2b39d040d  mov [rsp+0x50], r11d
00007fd2b39d0412  mov r11d, r11d
00007fd2b39d0415  mov [r15+0x58], r11
00007fd2b39d0419  mov r14d, [r15+0xA0]
00007fd2b39d0420  mov r12d, [r15+0x60]
00007fd2b39d0424  lea r11d, [r14d+r12d*1]
00007fd2b39d0429  mov [rsp+0x60], r11d
00007fd2b39d042e  mov r11d, r11d
00007fd2b39d0431  mov [r15+0x60], r11
00007fd2b39d0435  mov r14d, [rsp+0x10]
00007fd2b39d043a  mov [r13+rax*1], r14d
00007fd2b39d043f  lea r14, [rax+0x04]
00007fd2b39d0443  mov r12d, [rsp+0x20]
00007fd2b39d0448  mov [r13+r14*1], r12d
00007fd2b39d044d  lea r14, [rax+0x10]
00007fd2b39d0451  mov r12d, [rsp+0x30]
00007fd2b39d0456  mov [r13+r14*1], r12d
00007fd2b39d045b  lea r14, [rax+0x14]
00007fd2b39d045f  mov r12d, [rsp+0x40]
00007fd2b39d0464  mov [r13+r14*1], r12d
00007fd2b39d0469  lea r14, [rax+0x18]
00007fd2b39d046d  mov r12d, [rsp+0x50]
00007fd2b39d0472  mov [r13+r14*1], r12d
00007fd2b39d0477  lea r14, [rax+0x1C]
00007fd2b39d047b  mov r12d, [rsp+0x60]
00007fd2b39d0480  mov [r13+r14*1], r12d
00007fd2b39d0485  lea r14, [rax+0x68]
00007fd2b39d0489  xor eax, eax
00007fd2b39d048b  mov [r13+r14*1], rax
00007fd2b39d0490  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d0498  jz 0x00007FD2B39CEF90
00007fd2b39d049e  nop [rax+rax*1], ax
00007fd2b39d04a7  nop [rax+rax*1], eax
00007fd2b39d04af  mov eax, 0x410378
00007fd2b39d04b4  mov [r15+0x100], rax
00007fd2b39d04bb  jmp 0x00007FD2B37FE110
00007fd2b39d04c0  int3
00007fd2b39d04c1  call 0x00007FD2B38E2BA0
00007fd2b39d04c6  jmp 0x00007FD2B39D03BF
00007fd2b39d04cb  call 0x00007FD2B38E1920
00007fd2b39d04d0  jmp 0x00007FD2B39D03C8
00007fd2b39d04d5  call 0x00007FD2B380DFE0
00007fd2b39d04da  jmp 0x00007FD2B39D043F
00007fd2b39d04df  call 0x00007FD2B38E2BA0
00007fd2b39d04e4  jmp 0x00007FD2B39D044D
00007fd2b39d04e9  call 0x00007FD2B38E2BA0
00007fd2b39d04ee  jmp 0x00007FD2B39D045B
00007fd2b39d04f3  call 0x00007FD2B38E2BA0
00007fd2b39d04f8  jmp 0x00007FD2B39D0469
00007fd2b39d04fd  call 0x00007FD2B38E2BA0
00007fd2b39d0502  jmp 0x00007FD2B39D0477
00007fd2b39d0507  call 0x00007FD2B38E2BA0
00007fd2b39d050c  jmp 0x00007FD2B39D0485
00007fd2b39d0511  call 0x00007FD2B38D5EB0
00007fd2b39d0516  jmp 0x00007FD2B39D0490
00007fd2b39d051b  int3
00007fd2b39d051c  nop [rax], eax
00007fd2b39d0520  mov rax, [r15+0xF8]
00007fd2b39d0527  lea r14, [rax+0x140]
00007fd2b39d052e  mov r12, [r13+r14*1]
00007fd2b39d0533  lea r14, [rax+0x148]
00007fd2b39d053a  mov r11, [r13+r14*1]
00007fd2b39d053f  mov [r15+0xA0], r12
00007fd2b39d0546  mov [r15+0x98], r11
00007fd2b39d054d  lea r14, [rax+0x130]
00007fd2b39d0554  mov r12, [r13+r14*1]
00007fd2b39d0559  lea r14, [rax+0x138]
00007fd2b39d0560  mov r11, [r13+r14*1]
00007fd2b39d0565  mov [r15+0xB0], r12
00007fd2b39d056c  mov [r15+0xA8], r11
00007fd2b39d0573  lea r14, [rax+0x120]
00007fd2b39d057a  mov r12, [r13+r14*1]
00007fd2b39d057f  lea r14, [rax+0x128]
00007fd2b39d0586  mov r11, [r13+r14*1]
00007fd2b39d058b  mov [r15+0xC0], r12
00007fd2b39d0592  mov [r15+0xB8], r11
00007fd2b39d0599  lea r14, [rax+0x110]
00007fd2b39d05a0  mov r12, [r13+r14*1]
00007fd2b39d05a5  lea r14, [rax+0x118]
00007fd2b39d05ac  mov r11, [r13+r14*1]
00007fd2b39d05b1  mov [r15+0xD0], r12
00007fd2b39d05b8  mov [r15+0xC8], r11
00007fd2b39d05bf  lea r14, [rax+0x100]
00007fd2b39d05c6  mov r12, [r13+r14*1]
00007fd2b39d05cb  lea r14, [rax+0x108]
00007fd2b39d05d2  mov r11, [r13+r14*1]
00007fd2b39d05d7  mov [r15+0xE8], r12
00007fd2b39d05de  mov [r15+0xD8], r11
00007fd2b39d05e5  lea r14, [rax+0x150]
00007fd2b39d05ec  mov [r15+0xF8], r14
00007fd2b39d05f3  mov rax, [r15+0xF0]
00007fd2b39d05fa  mov [r15+0x100], rax
00007fd2b39d0601  jmp 0x00007FD2B39CE5C0
00007fd2b39d0606  int3
00007fd2b39d0607  call 0x00007FD2B38E27E0
00007fd2b39d060c  jmp 0x00007FD2B39D0533
00007fd2b39d0611  call 0x00007FD2B38E1570
00007fd2b39d0616  jmp 0x00007FD2B39D053F
00007fd2b39d061b  call 0x00007FD2B38E27E0
00007fd2b39d0620  jmp 0x00007FD2B39D0559
00007fd2b39d0625  call 0x00007FD2B38E1570
00007fd2b39d062a  jmp 0x00007FD2B39D0565
00007fd2b39d062f  call 0x00007FD2B38E27E0
00007fd2b39d0634  jmp 0x00007FD2B39D057F
00007fd2b39d0639  call 0x00007FD2B38E1570
00007fd2b39d063e  jmp 0x00007FD2B39D058B
00007fd2b39d0643  call 0x00007FD2B38E27E0
00007fd2b39d0648  jmp 0x00007FD2B39D05A5
00007fd2b39d064d  call 0x00007FD2B38E1570
00007fd2b39d0652  jmp 0x00007FD2B39D05B1
00007fd2b39d0657  call 0x00007FD2B38E27E0
00007fd2b39d065c  jmp 0x00007FD2B39D05CB
00007fd2b39d0661  call 0x00007FD2B38E1570
00007fd2b39d0666  jmp 0x00007FD2B39D05D7
00007fd2b39d066b  int3
00007fd2b39d066c  nop [rax], eax
00007fd2b39d0670  mov eax, [r15+0xA0]
00007fd2b39d0677  mov [rsp+0x10], eax
00007fd2b39d067b  xor eax, eax
00007fd2b39d067d  mov r14d, [rsp+0x10]
00007fd2b39d0682  sub r14d, 0x01
00007fd2b39d0686  cmc
00007fd2b39d0687  lahf
00007fd2b39d0688  seto al
00007fd2b39d068b  mov [r15+0x108], eax
00007fd2b39d0692  mov r14d, r14d
00007fd2b39d0695  mov [r15+0xA0], r14
00007fd2b39d069c  mov eax, [r15+0x108]
00007fd2b39d06a3  sahf
00007fd2b39d06a4  jnz 0x00007FD2B39D06D6
00007fd2b39d06a6  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d06ae  jz 0x00007FD2B39D07A0
00007fd2b39d06b4  nop [rax+rax*1], ax
00007fd2b39d06bd  nop [rax+rax*1], eax
00007fd2b39d06c5  mov eax, 0x41027C
00007fd2b39d06ca  mov [r15+0x100], rax
00007fd2b39d06d1  jmp 0x00007FD2B37FE110
00007fd2b39d06d6  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d06de  jz 0x00007FD2B39D0710
00007fd2b39d06e4  nop [rax+rax*1], ax
00007fd2b39d06ed  nop [rax+rax*1], eax
00007fd2b39d06f5  mov eax, 0x410264
00007fd2b39d06fa  mov [r15+0x100], rax
00007fd2b39d0701  jmp 0x00007FD2B37FE110
00007fd2b39d0706  int3
00007fd2b39d0707  int3
00007fd2b39d0708  nop [rax+rax*1], eax
00007fd2b39d0710  mov rax, [r15+0xF8]
00007fd2b39d0717  mov [r15], rax
00007fd2b39d071a  mov rax, [r15+0x98]
00007fd2b39d0721  mov [r15+0x08], rax
00007fd2b39d0725  mov qword ptr [r15+0x10], 0x12C
00007fd2b39d072d  mov qword ptr [r15+0xF0], 0x410274
00007fd2b39d0738  mov r14d, [r15+0x320]
00007fd2b39d073f  mov eax, 0x410274
00007fd2b39d0744  mov rcx, 0x7FD2B39D0670
00007fd2b39d074e  mov [r15+r14*8+0x328], rax
00007fd2b39d0756  mov [r15+r14*8+0x368], rcx
00007fd2b39d075e  add r14d, 0x01
00007fd2b39d0762  and r14d, 0x07
00007fd2b39d0766  mov [r15+0x320], r14d
00007fd2b39d076d  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d0775  jz 0x00007FD2B39CEC20
00007fd2b39d077b  nop [rax+rax*1], ax
00007fd2b39d0784  nop [rax+rax*1], eax
00007fd2b39d078c  mov eax, 0x410338
00007fd2b39d0791  mov [r15+0x100], rax
00007fd2b39d0798  jmp 0x00007FD2B37FE110
00007fd2b39d079d  int3
00007fd2b39d079e  int3
00007fd2b39d079f  nop
00007fd2b39d07a0  mov rax, [r15+0xF8]
00007fd2b39d07a7  lea r14, [rax+0x20]
00007fd2b39d07ab  mov r12, [r13+r14*1]
00007fd2b39d07b0  mov [r15+0x98], r12
00007fd2b39d07b7  mov qword ptr [r15+0x40], 0x80
00007fd2b39d07bf  mov [r15], rax
00007fd2b39d07c2  lea r14, [rax+0x8C]
00007fd2b39d07c9  mov [r15+0x08], r14
00007fd2b39d07cd  mov qword ptr [r15+0x10], 0x01
00007fd2b39d07d5  lea r14, [rax+0x8C]
00007fd2b39d07dc  mov eax, 0x80
00007fd2b39d07e1  mov [r13+r14*1], al
00007fd2b39d07e6  mov qword ptr [r15+0xF0], 0x410298
00007fd2b39d07f1  mov r14d, [r15+0x320]
00007fd2b39d07f8  mov eax, 0x410298
00007fd2b39d07fd  mov rcx, 0x7FD2B39D0870
00007fd2b39d0807  mov [r15+r14*8+0x328], rax
00007fd2b39d080f  mov [r15+r14*8+0x368], rcx
00007fd2b39d0817  add r14d, 0x01
00007fd2b39d081b  and r14d, 0x07
00007fd2b39d081f  mov [r15+0x320], r14d
00007fd2b39d0826  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d082e  jz 0x00007FD2B39CEC20
00007fd2b39d0834  nop [rax+rax*1], ax
00007fd2b39d083d  nop [rax+rax*1], eax
00007fd2b39d0845  mov eax, 0x410338
00007fd2b39d084a  mov [r15+0x100], rax
00007fd2b39d0851  jmp 0x00007FD2B37FE110
00007fd2b39d0856  int3
00007fd2b39d0857  call 0x00007FD2B38E27E0
00007fd2b39d085c  jmp 0x00007FD2B39D07B0
00007fd2b39d0861  call 0x00007FD2B38D5AF0
00007fd2b39d0866  jmp 0x00007FD2B39D07E6
00007fd2b39d086b  int3
00007fd2b39d086c  nop [rax], eax
00007fd2b39d0870  mov rax, [r15+0xF8]
00007fd2b39d0877  lea r14, [rax+0x68]
00007fd2b39d087b  mov r12, [r13+r14*1]
00007fd2b39d0880  mov [r15+0x40], r12
00007fd2b39d0884  lea r14, [rax+0x88]
00007fd2b39d088b  xor eax, eax
00007fd2b39d088d  mov [r13+r14*1], al
00007fd2b39d0892  xor eax, eax
00007fd2b39d0894  mov r14d, 0x38
00007fd2b39d089a  cmp r12, r14
00007fd2b39d089d  cmc
00007fd2b39d089e  lahf
00007fd2b39d089f  seto al
00007fd2b39d08a2  mov [r15+0x108], eax
00007fd2b39d08a9  mov eax, [r15+0x108]
00007fd2b39d08b0  sahf
00007fd2b39d08b1  jz 0x00007FD2B39D08E3
00007fd2b39d08b3  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d08bb  jz 0x00007FD2B39D0930
00007fd2b39d08c1  nop [rax+rax*1], ax
00007fd2b39d08ca  nop [rax+rax*1], eax
00007fd2b39d08d2  mov eax, 0x4102A8
00007fd2b39d08d7  mov [r15+0x100], rax
00007fd2b39d08de  jmp 0x00007FD2B37FE110
00007fd2b39d08e3  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d08eb  jz 0x00007FD2B39D0A70
00007fd2b39d08f1  nop [rax+rax*1], ax
00007fd2b39d08fa  nop [rax+rax*1], eax
00007fd2b39d0902  mov eax, 0x4102C4
00007fd2b39d0907  mov [r15+0x100], rax
00007fd2b39d090e  jmp 0x00007FD2B37FE110
00007fd2b39d0913  int3
00007fd2b39d0914  call 0x00007FD2B38E27E0
00007fd2b39d0919  jmp 0x00007FD2B39D0880
00007fd2b39d091e  call 0x00007FD2B38D5AF0
00007fd2b39d0923  jmp 0x00007FD2B39D0892
00007fd2b39d0928  int3
00007fd2b39d0929  nop [rax], eax
00007fd2b39d0930  mov rax, [r15+0xF8]
00007fd2b39d0937  mov [r15], rax
00007fd2b39d093a  lea r14, [rax+0x88]
00007fd2b39d0941  mov [r15+0x08], r14
00007fd2b39d0945  mov qword ptr [r15+0x10], 0x01
00007fd2b39d094d  mov qword ptr [r15+0xF0], 0x4102B8
00007fd2b39d0958  mov r14d, [r15+0x320]
00007fd2b39d095f  mov eax, 0x4102B8
00007fd2b39d0964  mov rcx, 0x7FD2B39D09C0
00007fd2b39d096e  mov [r15+r14*8+0x328], rax
00007fd2b39d0976  mov [r15+r14*8+0x368], rcx
00007fd2b39d097e  add r14d, 0x01
00007fd2b39d0982  and r14d, 0x07
00007fd2b39d0986  mov [r15+0x320], r14d
00007fd2b39d098d  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d0995  jz 0x00007FD2B39CEC20
00007fd2b39d099b  nop [rax+rax*1], ax
00007fd2b39d09a4  nop [rax+rax*1], eax
00007fd2b39d09ac  mov eax, 0x410338
00007fd2b39d09b1  mov [r15+0x100], rax
00007fd2b39d09b8  jmp 0x00007FD2B37FE110
00007fd2b39d09bd  int3
00007fd2b39d09be  int3
00007fd2b39d09bf  nop
00007fd2b39d09c0  mov rax, [r15+0xF8]
00007fd2b39d09c7  lea r14, [rax+0x68]
00007fd2b39d09cb  mov rax, [r13+r14*1]
00007fd2b39d09d0  mov [r15+0x40], rax
00007fd2b39d09d4  mov [rsp+0x10], rax
00007fd2b39d09d9  xor eax, eax
00007fd2b39d09db  mov r14, [rsp+0x10]
00007fd2b39d09e0  mov r12d, 0x38
00007fd2b39d09e6  cmp r14, r12
00007fd2b39d09e9  cmc
00007fd2b39d09ea  lahf
00007fd2b39d09eb  seto al
00007fd2b39d09ee  mov [r15+0x108], eax
00007fd2b39d09f5  mov eax, [r15+0x108]
00007fd2b39d09fc  sahf
00007fd2b39d09fd  jnz 0x00007FD2B39D0A2F
00007fd2b39d09ff  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d0a07  jz 0x00007FD2B39D0A70
00007fd2b39d0a0d  nop [rax+rax*1], ax
00007fd2b39d0a16  nop [rax+rax*1], eax
00007fd2b39d0a1e  mov eax, 0x4102C4
00007fd2b39d0a23  mov [r15+0x100], rax
00007fd2b39d0a2a  jmp 0x00007FD2B37FE110
00007fd2b39d0a2f  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d0a37  jz 0x00007FD2B39D0930
00007fd2b39d0a3d  nop [rax+rax*1], ax
00007fd2b39d0a46  nop [rax+rax*1], eax
00007fd2b39d0a4e  mov eax, 0x4102A8
00007fd2b39d0a53  mov [r15+0x100], rax
00007fd2b39d0a5a  jmp 0x00007FD2B37FE110
00007fd2b39d0a5f  int3
00007fd2b39d0a60  call 0x00007FD2B38D59C0
00007fd2b39d0a65  jmp 0x00007FD2B39D09D0
00007fd2b39d0a6a  int3
00007fd2b39d0a6b  nop [rax+rax*1], eax
00007fd2b39d0a70  mov rax, [r15+0x98]
00007fd2b39d0a77  rorx r14, rax, 0x3D
00007fd2b39d0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007fd2b39d0a81  mov rax, [r15+0xF8]
00007fd2b39d0a88  mov [r15], rax
00007fd2b39d0a8b  lea r12, [rax+0x78]
00007fd2b39d0a8f  mov [r15+0x08], r12
00007fd2b39d0a93  mov qword ptr [r15+0x10], 0x08
00007fd2b39d0a9b  bswap r14
00007fd2b39d0a9e  mov [r15+0x40], r14
00007fd2b39d0aa2  lea r12, [rax+0x78]
00007fd2b39d0aa6  mov [r13+r12*1], r14
00007fd2b39d0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007fd2b39d0ab6  mov r14d, [r15+0x320]
00007fd2b39d0abd  mov eax, 0x4102E0
00007fd2b39d0ac2  mov rcx, 0x7FD2B39D0B30
00007fd2b39d0acc  mov [r15+r14*8+0x328], rax
00007fd2b39d0ad4  mov [r15+r14*8+0x368], rcx
00007fd2b39d0adc  add r14d, 0x01
00007fd2b39d0ae0  and r14d, 0x07
00007fd2b39d0ae4  mov [r15+0x320], r14d
00007fd2b39d0aeb  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d0af3  jz 0x00007FD2B39CEC20
00007fd2b39d0af9  nop [rax+rax*1], ax
00007fd2b39d0b02  nop [rax+rax*1], eax
00007fd2b39d0b0a  mov eax, 0x410338
00007fd2b39d0b0f  mov [r15+0x100], rax
00007fd2b39d0b16  jmp 0x00007FD2B37FE110
00007fd2b39d0b1b  int3
00007fd2b39d0b1c  call 0x00007FD2B38C3FE0
00007fd2b39d0b21  jmp 0x00007FD2B39D0AAB
00007fd2b39d0b26  int3
00007fd2b39d0b27  nop [rax+rax*1], ax
00007fd2b39d0b30  mov rax, [r15+0xF8]
00007fd2b39d0b37  mov r14d, [r13+rax*1]
00007fd2b39d0b3c  lea r12, [rax+0x04]
00007fd2b39d0b40  mov r11d, [r13+r12*1]
00007fd2b39d0b45  lea r12, [rax+0x08]
00007fd2b39d0b49  mov r10d, [r13+r12*1]
00007fd2b39d0b4e  lea r12, [rax+0x0C]
00007fd2b39d0b52  mov r9d, [r13+r12*1]
00007fd2b39d0b57  mov qword ptr [r15+0x48], 0x430860
00007fd2b39d0b5f  lea r12, [rax+0x80]
00007fd2b39d0b66  mov r8, [r13+r12*1]
00007fd2b39d0b6b  mov [r15+0xF0], r8
00007fd2b39d0b72  bswap r14d
00007fd2b39d0b75  bswap r11d
00007fd2b39d0b78  mov r12d, 0x430860
00007fd2b39d0b7e  mov [r13+r12*1], r14d
00007fd2b39d0b83  mov r14d, 0x430864
00007fd2b39d0b89  mov [r13+r14*1], r11d
00007fd2b39d0b8e  bswap r10d
00007fd2b39d0b91  bswap r9d
00007fd2b39d0b94  lea r14, [rax+0x10]
00007fd2b39d0b98  mov r12d, [r13+r14*1]
00007fd2b39d0b9d  lea r14, [rax+0x14]
00007fd2b39d0ba1  mov r11d, [r13+r14*1]
00007fd2b39d0ba6  mov r14d, 0x430868
00007fd2b39d0bac  mov [r13+r14*1], r10d
00007fd2b39d0bb1  mov r14d, 0x43086C
00007fd2b39d0bb7  mov [r13+r14*1], r9d
00007fd2b39d0bbc  lea r14, [rax+0x90]
00007fd2b39d0bc3  mov r10, [r13+r14*1]
00007fd2b39d0bc8  lea r14, [rax+0x98]
00007fd2b39d0bcf  mov r9, [r13+r14*1]
00007fd2b39d0bd4  mov [r15+0xA0], r10
00007fd2b39d0bdb  mov [r15+0x98], r9
00007fd2b39d0be2  bswap r12d
00007fd2b39d0be5  bswap r11d
00007fd2b39d0be8  mov [rsp+0x10], r11d
00007fd2b39d0bed  mov r11d, r11d
00007fd2b39d0bf0  mov [r15+0x58], r11
00007fd2b39d0bf4  lea r14, [rax+0x18]
00007fd2b39d0bf8  mov r11d, [r13+r14*1]
00007fd2b39d0bfd  lea r14, [rax+0x1C]
00007fd2b39d0c01  mov r10d, [r13+r14*1]
00007fd2b39d0c06  mov [rsp+0x20], r10d
00007fd2b39d0c0b  mov r10d, r10d
00007fd2b39d0c0e  mov [r15+0x60], r10
00007fd2b39d0c12  mov r14d, 0x430870
00007fd2b39d0c18  mov [r13+r14*1], r12d
00007fd2b39d0c1d  mov r14d, 0x430874
00007fd2b39d0c23  mov r12d, [rsp+0x10]
00007fd2b39d0c28  mov [r13+r14*1], r12d
00007fd2b39d0c2d  bswap r11d
00007fd2b39d0c30  mov [rsp+0x10], r11d
00007fd2b39d0c35  mov r11d, r11d
00007fd2b39d0c38  mov [r15+0x40], r11
00007fd2b39d0c3c  mov r14d, [rsp+0x20]
00007fd2b39d0c41  bswap r14d
00007fd2b39d0c44  mov [rsp+0x20], r14d
00007fd2b39d0c49  mov r14d, r14d
00007fd2b39d0c4c  mov [r15+0x50], r14
00007fd2b39d0c50  mov r14d, 0x430878
00007fd2b39d0c56  mov r12d, [rsp+0x10]
00007fd2b39d0c5b  mov [r13+r14*1], r12d
00007fd2b39d0c60  mov r14d, 0x43087C
00007fd2b39d0c66  mov r12d, [rsp+0x20]
00007fd2b39d0c6b  mov [r13+r14*1], r12d
00007fd2b39d0c70  lea r14, [rax+0xA0]
00007fd2b39d0c77  mov [r15+0xF8], r14
00007fd2b39d0c7e  mov [r15+0x100], r8
00007fd2b39d0c85  jmp 0x00007FD2B39CE5C0
00007fd2b39d0c8a  int3
00007fd2b39d0c8b  call 0x00007FD2B380DAE0
00007fd2b39d0c90  jmp 0x00007FD2B39D0B3C
00007fd2b39d0c95  call 0x00007FD2B38C0230
00007fd2b39d0c9a  jmp 0x00007FD2B39D0B45
00007fd2b39d0c9f  call 0x00007FD2B38BEFC0
00007fd2b39d0ca4  jmp 0x00007FD2B39D0B4E
00007fd2b39d0ca9  call 0x00007FD2B38BDD50
00007fd2b39d0cae  jmp 0x00007FD2B39D0B57
00007fd2b39d0cb3  call 0x00007FD2B38BCC20
00007fd2b39d0cb8  jmp 0x00007FD2B39D0B6B
00007fd2b39d0cbd  call 0x00007FD2B38C3EA0
00007fd2b39d0cc2  jmp 0x00007FD2B39D0B83
00007fd2b39d0cc7  call 0x00007FD2B38E1920
00007fd2b39d0ccc  jmp 0x00007FD2B39D0B8E
00007fd2b39d0cd1  call 0x00007FD2B38E26A0
00007fd2b39d0cd6  jmp 0x00007FD2B39D0B9D
00007fd2b39d0cdb  call 0x00007FD2B38E1430
00007fd2b39d0ce0  jmp 0x00007FD2B39D0BA6
00007fd2b39d0ce5  call 0x00007FD2B38E06B0
00007fd2b39d0cea  jmp 0x00007FD2B39D0BB1
00007fd2b39d0cef  call 0x00007FD2B38DF440
00007fd2b39d0cf4  jmp 0x00007FD2B39D0BBC
00007fd2b39d0cf9  call 0x00007FD2B38E0300
00007fd2b39d0cfe  jmp 0x00007FD2B39D0BC8
00007fd2b39d0d03  call 0x00007FD2B38DF090
00007fd2b39d0d08  jmp 0x00007FD2B39D0BD4
00007fd2b39d0d0d  call 0x00007FD2B38E1430
00007fd2b39d0d12  jmp 0x00007FD2B39D0BFD
00007fd2b39d0d17  call 0x00007FD2B38E01C0
00007fd2b39d0d1c  jmp 0x00007FD2B39D0C06
00007fd2b39d0d21  call 0x00007FD2B38E2BA0
00007fd2b39d0d26  jmp 0x00007FD2B39D0C1D
00007fd2b39d0d2b  call 0x00007FD2B38E2BA0
00007fd2b39d0d30  jmp 0x00007FD2B39D0C2D
00007fd2b39d0d35  call 0x00007FD2B38E2BA0
00007fd2b39d0d3a  jmp 0x00007FD2B39D0C60
00007fd2b39d0d3f  call 0x00007FD2B38E2BA0
00007fd2b39d0d44  jmp 0x00007FD2B39D0C70
00007fd2b39d0d49  int3
00007fd2b39d0d4a  nop [rax+rax*1], ax
00007fd2b39d0d50  mov qword ptr [r15+0x100], 0x04
00007fd2b39d0d5b  mov esi, 0x00
00007fd2b39d0d60  mov edx, 0x09
00007fd2b39d0d65  mov rdi, 0x7FFCBE3A4190
00007fd2b39d0d6f  mov rax, 0x647BD7848970
00007fd2b39d0d79  call rax
00007fd2b39d0d7b  cmp dword ptr [r15+0x318], 0x00
00007fd2b39d0d83  jnz 0x00007FD2B37FE110
00007fd2b39d0d89  jmp 0x00007FD2B37FE0A0
00007fd2b39d0d8e  int3
00007fd2b39d0d8f  int3
