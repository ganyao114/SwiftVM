
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/2/1.bin:     file format binary


Disassembly of section .data:

0000719221efe4c0 <.data>:
    719221efe4c0:	sub    rsp,0xc0
    719221efe4c7:	mov    r11,QWORD PTR [r12+0x398]
    719221efe4cf:	mov    QWORD PTR [rsp+0xb0],r11
    719221efe4d7:	mov    r13,QWORD PTR [r12]
    719221efe4db:	mov    r14,r13
    719221efe4de:	add    r14,0x20
    719221efe4e2:	mov    r15,QWORD PTR [r14]
    719221efe4e5:	mov    r14,QWORD PTR [r12+0x10]
    719221efe4ea:	add    r15,r14
    719221efe4ed:	mov    QWORD PTR [r12+0x40],r15
    719221efe4f2:	add    r13,0x20
    719221efe4f6:	mov    QWORD PTR [r13+0x0],r15
    719221efe4fa:	mov    r13d,0x0
    719221efe500:	mov    DWORD PTR [r12+0x32c],r13d
    719221efe508:	mov    rax,r14
    719221efe50b:	test   rax,rax
    719221efe50e:	je     0x719221f00615
    719221efe514:	jmp    0x719221efe519
    719221efe519:	mov    r13,QWORD PTR [r12+0xf8]
    719221efe521:	sub    r13,0x150
    719221efe528:	mov    QWORD PTR [r12+0xf8],r13
    719221efe530:	mov    r14,QWORD PTR [r12]
    719221efe534:	mov    r15,r14
    719221efe537:	add    r15,0x68
    719221efe53b:	mov    rbp,QWORD PTR [r15]
    719221efe53e:	mov    QWORD PTR [r12+0x88],rbp
    719221efe546:	add    r14,0x28
    719221efe54a:	mov    QWORD PTR [r12+0x40],r14
    719221efe54f:	mov    QWORD PTR [r12+0x48],r13
    719221efe554:	mov    r14d,0x420000
    719221efe55a:	add    r14,0x758
    719221efe561:	mov    QWORD PTR [r12+0x50],r14
    719221efe566:	mov    r14,r13
    719221efe569:	add    r14,0x100
    719221efe570:	mov    r15,r14
    719221efe573:	add    r15,0x8
    719221efe577:	mov    rbp,QWORD PTR [r12+0xe8]
    719221efe57f:	mov    r8,QWORD PTR [r12+0xd8]
    719221efe587:	mov    QWORD PTR [r14],rbp
    719221efe58a:	mov    r14d,0x0
    719221efe590:	mov    DWORD PTR [r12+0x32c],r14d
    719221efe598:	mov    QWORD PTR [r15],r8
    719221efe59b:	mov    r14,r13
    719221efe59e:	add    r14,0x110
    719221efe5a5:	mov    r15,r14
    719221efe5a8:	add    r15,0x8
    719221efe5ac:	mov    rbp,QWORD PTR [r12+0xd0]
    719221efe5b4:	mov    r8,QWORD PTR [r12+0xc8]
    719221efe5bc:	mov    QWORD PTR [r14],rbp
    719221efe5bf:	mov    QWORD PTR [r15],r8
    719221efe5c2:	mov    r14,r13
    719221efe5c5:	add    r14,0x120
    719221efe5cc:	mov    r15,r14
    719221efe5cf:	add    r15,0x8
    719221efe5d3:	mov    rbp,QWORD PTR [r12+0xc0]
    719221efe5db:	mov    r8,QWORD PTR [r12+0xb8]
    719221efe5e3:	mov    QWORD PTR [r14],rbp
    719221efe5e6:	mov    QWORD PTR [r15],r8
    719221efe5e9:	mov    r14,r13
    719221efe5ec:	add    r14,0x130
    719221efe5f3:	mov    r15,r14
    719221efe5f6:	add    r15,0x8
    719221efe5fa:	mov    rbp,QWORD PTR [r12+0xb0]
    719221efe602:	mov    r8,QWORD PTR [r12+0xa8]
    719221efe60a:	mov    QWORD PTR [r14],rbp
    719221efe60d:	mov    QWORD PTR [r15],r8
    719221efe610:	add    r13,0x140
    719221efe617:	mov    r14,r13
    719221efe61a:	add    r14,0x8
    719221efe61e:	mov    r15,QWORD PTR [r12+0xa0]
    719221efe626:	mov    rbp,QWORD PTR [r12+0x98]
    719221efe62e:	mov    QWORD PTR [r13+0x0],r15
    719221efe632:	mov    QWORD PTR [r14],rbp
    719221efe635:	jmp    0x719221efe63a
    719221efe63a:	mov    r13,QWORD PTR [r12+0x8]
    719221efe63f:	mov    r14,r13
    719221efe642:	add    r14,0x1
    719221efe646:	movzx  r15d,BYTE PTR [r13+0x0]
    719221efe64b:	mov    QWORD PTR [r12+0x58],r15
    719221efe650:	mov    QWORD PTR [r12+0x8],r14
    719221efe655:	mov    r13,QWORD PTR [r12+0x88]
    719221efe65d:	mov    r14,r13
    719221efe660:	add    r14,0x1
    719221efe664:	mov    QWORD PTR [r12+0x60],r14
    719221efe669:	mov    r15,QWORD PTR [r12]
    719221efe66d:	mov    rbp,r15
    719221efe670:	add    rbp,0x68
    719221efe674:	mov    QWORD PTR [rbp+0x0],r14
    719221efe678:	mov    r14d,0x0
    719221efe67e:	mov    DWORD PTR [r12+0x32c],r14d
    719221efe686:	mov    r14,r15
    719221efe689:	add    r14,r13
    719221efe68c:	mov    QWORD PTR [r12+0x60],r14
    719221efe691:	add    r14,0x28
    719221efe695:	movzx  r13d,BYTE PTR [r12+0x58]
    719221efe69b:	mov    BYTE PTR [r14],r13b
    719221efe69e:	add    r15,0x68
    719221efe6a2:	mov    r13,QWORD PTR [r15]
    719221efe6a5:	mov    QWORD PTR [r12+0x88],r13
    719221efe6ad:	sub    r13,0x40
    719221efe6b1:	mov    rcx,QWORD PTR [r12+0x380]
    719221efe6b9:	jrcxz  0x719221efe6c0
    719221efe6bb:	jmp    0x719221f00660
    719221efe6c0:	jne    0x719221efe6dd
    719221efe6c6:	mov    r11,rax
    719221efe6c9:	lahf
    719221efe6ca:	seto   al
    719221efe6cd:	mov    WORD PTR [rsp+0xb0],ax
    719221efe6d5:	mov    rax,r11
    719221efe6d8:	jmp    0x719221efe6f4
    719221efe6dd:	mov    r11,rax
    719221efe6e0:	lahf
    719221efe6e1:	seto   al
    719221efe6e4:	mov    WORD PTR [rsp+0xb0],ax
    719221efe6ec:	mov    rax,r11
    719221efe6ef:	jmp    0x719221f00517
    719221efe6f4:	mov    rax,QWORD PTR [r12+0x40]
    719221efe6f9:	mov    eax,0x0
    719221efe6fe:	mov    QWORD PTR [rsp+0x18],rax
    719221efe703:	mov    eax,0x0
    719221efe708:	mov    QWORD PTR [rsp+0x10],rax
    719221efe70d:	mov    eax,0x0
    719221efe712:	mov    QWORD PTR [rsp+0x8],rax
    719221efe717:	mov    eax,0x0
    719221efe71c:	mov    QWORD PTR [rsp],rax
    719221efe720:	mov    rdi,QWORD PTR [r12+0x40]
    719221efe725:	movzx  r9d,BYTE PTR [rdi]
    719221efe729:	mov    r13,QWORD PTR [rsp+0x18]
    719221efe72e:	or     r13,r9
    719221efe731:	mov    r9,QWORD PTR [r12+0x40]
    719221efe736:	add    r9,0x1
    719221efe73a:	movzx  r8d,BYTE PTR [r9]
    719221efe73e:	mov    r9,QWORD PTR [rsp+0x10]
    719221efe743:	or     r9,r8
    719221efe746:	mov    r8,QWORD PTR [r12+0x40]
    719221efe74b:	add    r8,0x2
    719221efe74f:	movzx  ebp,BYTE PTR [r8]
    719221efe753:	mov    r8,QWORD PTR [rsp+0x8]
    719221efe758:	or     r8,rbp
    719221efe75b:	mov    rbp,QWORD PTR [r12+0x40]
    719221efe760:	add    rbp,0x3
    719221efe764:	movzx  r15d,BYTE PTR [rbp+0x0]
    719221efe769:	mov    rbp,QWORD PTR [rsp]
    719221efe76d:	or     rbp,r15
    719221efe770:	mov    r15,QWORD PTR [r12+0x40]
    719221efe775:	add    r15,0x4
    719221efe779:	movzx  r14d,BYTE PTR [r15]
    719221efe77d:	mov    r15,r14
    719221efe780:	shl    r15,0x8
    719221efe784:	or     r13,r15
    719221efe787:	mov    r14,QWORD PTR [r12+0x40]
    719221efe78c:	add    r14,0x5
    719221efe790:	movzx  r15d,BYTE PTR [r14]
    719221efe794:	mov    r14,r15
    719221efe797:	shl    r14,0x8
    719221efe79b:	or     r9,r14
    719221efe79e:	mov    r14,QWORD PTR [r12+0x40]
    719221efe7a3:	add    r14,0x6
    719221efe7a7:	movzx  r15d,BYTE PTR [r14]
    719221efe7ab:	mov    r14,r15
    719221efe7ae:	shl    r14,0x8
    719221efe7b2:	or     r8,r14
    719221efe7b5:	mov    r14,QWORD PTR [r12+0x40]
    719221efe7ba:	add    r14,0x7
    719221efe7be:	movzx  r15d,BYTE PTR [r14]
    719221efe7c2:	mov    r14,r15
    719221efe7c5:	shl    r14,0x8
    719221efe7c9:	or     rbp,r14
    719221efe7cc:	mov    r14,QWORD PTR [r12+0x40]
    719221efe7d1:	add    r14,0x8
    719221efe7d5:	movzx  r15d,BYTE PTR [r14]
    719221efe7d9:	mov    r14,r15
    719221efe7dc:	shl    r14,0x10
    719221efe7e0:	or     r13,r14
    719221efe7e3:	mov    r14,QWORD PTR [r12+0x40]
    719221efe7e8:	add    r14,0x9
    719221efe7ec:	movzx  r15d,BYTE PTR [r14]
    719221efe7f0:	mov    r14,r15
    719221efe7f3:	shl    r14,0x10
    719221efe7f7:	or     r9,r14
    719221efe7fa:	mov    r14,QWORD PTR [r12+0x40]
    719221efe7ff:	add    r14,0xa
    719221efe803:	movzx  r15d,BYTE PTR [r14]
    719221efe807:	mov    r14,r15
    719221efe80a:	shl    r14,0x10
    719221efe80e:	or     r8,r14
    719221efe811:	mov    r14,QWORD PTR [r12+0x40]
    719221efe816:	add    r14,0xb
    719221efe81a:	movzx  r15d,BYTE PTR [r14]
    719221efe81e:	mov    r14,r15
    719221efe821:	shl    r14,0x10
    719221efe825:	or     rbp,r14
    719221efe828:	mov    r14,QWORD PTR [r12+0x40]
    719221efe82d:	add    r14,0xc
    719221efe831:	movzx  r15d,BYTE PTR [r14]
    719221efe835:	mov    r14,r15
    719221efe838:	shl    r14,0x18
    719221efe83c:	or     r13,r14
    719221efe83f:	mov    r14,QWORD PTR [r12+0x40]
    719221efe844:	add    r14,0xd
    719221efe848:	movzx  r15d,BYTE PTR [r14]
    719221efe84c:	mov    r14,r15
    719221efe84f:	shl    r14,0x18
    719221efe853:	or     r9,r14
    719221efe856:	mov    r14,QWORD PTR [r12+0x40]
    719221efe85b:	add    r14,0xe
    719221efe85f:	movzx  r15d,BYTE PTR [r14]
    719221efe863:	mov    r14,r15
    719221efe866:	shl    r14,0x18
    719221efe86a:	or     r8,r14
    719221efe86d:	mov    r14,QWORD PTR [r12+0x40]
    719221efe872:	add    r14,0xf
    719221efe876:	movzx  r15d,BYTE PTR [r14]
    719221efe87a:	mov    r14,r15
    719221efe87d:	shl    r14,0x18
    719221efe881:	or     rbp,r14
    719221efe884:	mov    r14,QWORD PTR [r12+0x40]
    719221efe889:	add    r14,0x10
    719221efe88d:	movzx  r15d,BYTE PTR [r14]
    719221efe891:	mov    r14,r15
    719221efe894:	shl    r14,0x20
    719221efe898:	or     r13,r14
    719221efe89b:	mov    r14,QWORD PTR [r12+0x40]
    719221efe8a0:	add    r14,0x11
    719221efe8a4:	movzx  r15d,BYTE PTR [r14]
    719221efe8a8:	mov    r14,r15
    719221efe8ab:	shl    r14,0x20
    719221efe8af:	or     r9,r14
    719221efe8b2:	mov    r14,QWORD PTR [r12+0x40]
    719221efe8b7:	add    r14,0x12
    719221efe8bb:	movzx  r15d,BYTE PTR [r14]
    719221efe8bf:	mov    r14,r15
    719221efe8c2:	shl    r14,0x20
    719221efe8c6:	or     r8,r14
    719221efe8c9:	mov    r14,QWORD PTR [r12+0x40]
    719221efe8ce:	add    r14,0x13
    719221efe8d2:	movzx  r15d,BYTE PTR [r14]
    719221efe8d6:	mov    r14,r15
    719221efe8d9:	shl    r14,0x20
    719221efe8dd:	or     rbp,r14
    719221efe8e0:	mov    r14,QWORD PTR [r12+0x40]
    719221efe8e5:	add    r14,0x14
    719221efe8e9:	movzx  r15d,BYTE PTR [r14]
    719221efe8ed:	mov    r14,r15
    719221efe8f0:	shl    r14,0x28
    719221efe8f4:	or     r13,r14
    719221efe8f7:	mov    r14,QWORD PTR [r12+0x40]
    719221efe8fc:	add    r14,0x15
    719221efe900:	movzx  r15d,BYTE PTR [r14]
    719221efe904:	mov    r14,r15
    719221efe907:	shl    r14,0x28
    719221efe90b:	or     r9,r14
    719221efe90e:	mov    r14,QWORD PTR [r12+0x40]
    719221efe913:	add    r14,0x16
    719221efe917:	movzx  r15d,BYTE PTR [r14]
    719221efe91b:	mov    r14,r15
    719221efe91e:	shl    r14,0x28
    719221efe922:	or     r8,r14
    719221efe925:	mov    r14,QWORD PTR [r12+0x40]
    719221efe92a:	add    r14,0x17
    719221efe92e:	movzx  r15d,BYTE PTR [r14]
    719221efe932:	mov    r14,r15
    719221efe935:	shl    r14,0x28
    719221efe939:	or     rbp,r14
    719221efe93c:	mov    r14,QWORD PTR [r12+0x40]
    719221efe941:	add    r14,0x18
    719221efe945:	movzx  r15d,BYTE PTR [r14]
    719221efe949:	mov    r14,r15
    719221efe94c:	shl    r14,0x30
    719221efe950:	or     r13,r14
    719221efe953:	mov    r14,QWORD PTR [r12+0x40]
    719221efe958:	add    r14,0x19
    719221efe95c:	movzx  r15d,BYTE PTR [r14]
    719221efe960:	mov    r14,r15
    719221efe963:	shl    r14,0x30
    719221efe967:	or     r9,r14
    719221efe96a:	mov    r14,QWORD PTR [r12+0x40]
    719221efe96f:	add    r14,0x1a
    719221efe973:	movzx  r15d,BYTE PTR [r14]
    719221efe977:	mov    r14,r15
    719221efe97a:	shl    r14,0x30
    719221efe97e:	or     r8,r14
    719221efe981:	mov    r14,QWORD PTR [r12+0x40]
    719221efe986:	add    r14,0x1b
    719221efe98a:	movzx  r15d,BYTE PTR [r14]
    719221efe98e:	mov    r14,r15
    719221efe991:	shl    r14,0x30
    719221efe995:	or     rbp,r14
    719221efe998:	mov    r14,QWORD PTR [r12+0x40]
    719221efe99d:	add    r14,0x1c
    719221efe9a1:	movzx  r15d,BYTE PTR [r14]
    719221efe9a5:	mov    r14,r15
    719221efe9a8:	shl    r14,0x38
    719221efe9ac:	mov    rax,r13
    719221efe9af:	or     rax,r14
    719221efe9b2:	mov    QWORD PTR [rsp+0x28],rax
    719221efe9b7:	mov    r14,QWORD PTR [r12+0x40]
    719221efe9bc:	add    r14,0x1d
    719221efe9c0:	movzx  r15d,BYTE PTR [r14]
    719221efe9c4:	mov    r14,r15
    719221efe9c7:	shl    r14,0x38
    719221efe9cb:	mov    rax,r9
    719221efe9ce:	or     rax,r14
    719221efe9d1:	mov    QWORD PTR [rsp+0x38],rax
    719221efe9d6:	mov    r14,QWORD PTR [r12+0x40]
    719221efe9db:	add    r14,0x1e
    719221efe9df:	movzx  r15d,BYTE PTR [r14]
    719221efe9e3:	mov    r14,r15
    719221efe9e6:	shl    r14,0x38
    719221efe9ea:	mov    rax,r8
    719221efe9ed:	or     rax,r14
    719221efe9f0:	mov    QWORD PTR [rsp+0x30],rax
    719221efe9f5:	mov    r14,QWORD PTR [r12+0x40]
    719221efe9fa:	add    r14,0x1f
    719221efe9fe:	movzx  r15d,BYTE PTR [r14]
    719221efea02:	mov    r14,r15
    719221efea05:	shl    r14,0x38
    719221efea09:	mov    rax,rbp
    719221efea0c:	or     rax,r14
    719221efea0f:	mov    QWORD PTR [rsp+0x20],rax
    719221efea14:	mov    r14,QWORD PTR [r12+0x40]
    719221efea19:	add    r14,0x20
    719221efea1d:	movzx  r15d,BYTE PTR [r14]
    719221efea21:	mov    r14,QWORD PTR [rsp+0x18]
    719221efea26:	or     r14,r15
    719221efea29:	mov    r15,QWORD PTR [r12+0x40]
    719221efea2e:	add    r15,0x21
    719221efea32:	movzx  ebp,BYTE PTR [r15]
    719221efea36:	mov    r15,QWORD PTR [rsp+0x10]
    719221efea3b:	or     r15,rbp
    719221efea3e:	mov    rbp,QWORD PTR [r12+0x40]
    719221efea43:	add    rbp,0x22
    719221efea47:	movzx  r13d,BYTE PTR [rbp+0x0]
    719221efea4c:	mov    rbp,QWORD PTR [rsp+0x8]
    719221efea51:	or     rbp,r13
    719221efea54:	mov    r13,QWORD PTR [r12+0x40]
    719221efea59:	add    r13,0x23
    719221efea5d:	movzx  r8d,BYTE PTR [r13+0x0]
    719221efea62:	mov    r13,QWORD PTR [rsp]
    719221efea66:	or     r13,r8
    719221efea69:	mov    r8,QWORD PTR [r12+0x40]
    719221efea6e:	add    r8,0x24
    719221efea72:	movzx  r9d,BYTE PTR [r8]
    719221efea76:	mov    r8,r9
    719221efea79:	shl    r8,0x8
    719221efea7d:	or     r14,r8
    719221efea80:	mov    r8,QWORD PTR [r12+0x40]
    719221efea85:	add    r8,0x25
    719221efea89:	movzx  r9d,BYTE PTR [r8]
    719221efea8d:	mov    r8,r9
    719221efea90:	shl    r8,0x8
    719221efea94:	or     r15,r8
    719221efea97:	mov    r8,QWORD PTR [r12+0x40]
    719221efea9c:	add    r8,0x26
    719221efeaa0:	movzx  r9d,BYTE PTR [r8]
    719221efeaa4:	mov    r8,r9
    719221efeaa7:	shl    r8,0x8
    719221efeaab:	or     rbp,r8
    719221efeaae:	mov    r8,QWORD PTR [r12+0x40]
    719221efeab3:	add    r8,0x27
    719221efeab7:	movzx  r9d,BYTE PTR [r8]
    719221efeabb:	mov    r8,r9
    719221efeabe:	shl    r8,0x8
    719221efeac2:	or     r13,r8
    719221efeac5:	mov    r8,QWORD PTR [r12+0x40]
    719221efeaca:	add    r8,0x28
    719221efeace:	movzx  r9d,BYTE PTR [r8]
    719221efead2:	mov    r8,r9
    719221efead5:	shl    r8,0x10
    719221efead9:	or     r14,r8
    719221efeadc:	mov    r8,QWORD PTR [r12+0x40]
    719221efeae1:	add    r8,0x29
    719221efeae5:	movzx  r9d,BYTE PTR [r8]
    719221efeae9:	mov    r8,r9
    719221efeaec:	shl    r8,0x10
    719221efeaf0:	or     r15,r8
    719221efeaf3:	mov    r8,QWORD PTR [r12+0x40]
    719221efeaf8:	add    r8,0x2a
    719221efeafc:	movzx  r9d,BYTE PTR [r8]
    719221efeb00:	mov    r8,r9
    719221efeb03:	shl    r8,0x10
    719221efeb07:	or     rbp,r8
    719221efeb0a:	mov    r8,QWORD PTR [r12+0x40]
    719221efeb0f:	add    r8,0x2b
    719221efeb13:	movzx  r9d,BYTE PTR [r8]
    719221efeb17:	mov    r8,r9
    719221efeb1a:	shl    r8,0x10
    719221efeb1e:	or     r13,r8
    719221efeb21:	mov    r8,QWORD PTR [r12+0x40]
    719221efeb26:	add    r8,0x2c
    719221efeb2a:	movzx  r9d,BYTE PTR [r8]
    719221efeb2e:	mov    r8,r9
    719221efeb31:	shl    r8,0x18
    719221efeb35:	or     r14,r8
    719221efeb38:	mov    r8,QWORD PTR [r12+0x40]
    719221efeb3d:	add    r8,0x2d
    719221efeb41:	movzx  r9d,BYTE PTR [r8]
    719221efeb45:	mov    r8,r9
    719221efeb48:	shl    r8,0x18
    719221efeb4c:	or     r15,r8
    719221efeb4f:	mov    r8,QWORD PTR [r12+0x40]
    719221efeb54:	add    r8,0x2e
    719221efeb58:	movzx  r9d,BYTE PTR [r8]
    719221efeb5c:	mov    r8,r9
    719221efeb5f:	shl    r8,0x18
    719221efeb63:	or     rbp,r8
    719221efeb66:	mov    r8,QWORD PTR [r12+0x40]
    719221efeb6b:	add    r8,0x2f
    719221efeb6f:	movzx  r9d,BYTE PTR [r8]
    719221efeb73:	mov    r8,r9
    719221efeb76:	shl    r8,0x18
    719221efeb7a:	or     r13,r8
    719221efeb7d:	mov    r8,QWORD PTR [r12+0x40]
    719221efeb82:	add    r8,0x30
    719221efeb86:	movzx  r9d,BYTE PTR [r8]
    719221efeb8a:	mov    r8,r9
    719221efeb8d:	shl    r8,0x20
    719221efeb91:	or     r14,r8
    719221efeb94:	mov    r8,QWORD PTR [r12+0x40]
    719221efeb99:	add    r8,0x31
    719221efeb9d:	movzx  r9d,BYTE PTR [r8]
    719221efeba1:	mov    r8,r9
    719221efeba4:	shl    r8,0x20
    719221efeba8:	or     r15,r8
    719221efebab:	mov    r8,QWORD PTR [r12+0x40]
    719221efebb0:	add    r8,0x32
    719221efebb4:	movzx  r9d,BYTE PTR [r8]
    719221efebb8:	mov    r8,r9
    719221efebbb:	shl    r8,0x20
    719221efebbf:	or     rbp,r8
    719221efebc2:	mov    r8,QWORD PTR [r12+0x40]
    719221efebc7:	add    r8,0x33
    719221efebcb:	movzx  r9d,BYTE PTR [r8]
    719221efebcf:	mov    r8,r9
    719221efebd2:	shl    r8,0x20
    719221efebd6:	or     r13,r8
    719221efebd9:	mov    r8,QWORD PTR [r12+0x40]
    719221efebde:	add    r8,0x34
    719221efebe2:	movzx  r9d,BYTE PTR [r8]
    719221efebe6:	mov    r8,r9
    719221efebe9:	shl    r8,0x28
    719221efebed:	or     r14,r8
    719221efebf0:	mov    r8,QWORD PTR [r12+0x40]
    719221efebf5:	add    r8,0x35
    719221efebf9:	movzx  r9d,BYTE PTR [r8]
    719221efebfd:	mov    r8,r9
    719221efec00:	shl    r8,0x28
    719221efec04:	or     r15,r8
    719221efec07:	mov    r8,QWORD PTR [r12+0x40]
    719221efec0c:	add    r8,0x36
    719221efec10:	movzx  r9d,BYTE PTR [r8]
    719221efec14:	mov    r8,r9
    719221efec17:	shl    r8,0x28
    719221efec1b:	or     rbp,r8
    719221efec1e:	mov    r8,QWORD PTR [r12+0x40]
    719221efec23:	add    r8,0x37
    719221efec27:	movzx  r9d,BYTE PTR [r8]
    719221efec2b:	mov    r8,r9
    719221efec2e:	shl    r8,0x28
    719221efec32:	or     r13,r8
    719221efec35:	mov    r8,QWORD PTR [r12+0x40]
    719221efec3a:	add    r8,0x38
    719221efec3e:	movzx  r9d,BYTE PTR [r8]
    719221efec42:	mov    r8,r9
    719221efec45:	shl    r8,0x30
    719221efec49:	or     r14,r8
    719221efec4c:	mov    r8,QWORD PTR [r12+0x40]
    719221efec51:	add    r8,0x39
    719221efec55:	movzx  r9d,BYTE PTR [r8]
    719221efec59:	mov    r8,r9
    719221efec5c:	shl    r8,0x30
    719221efec60:	or     r15,r8
    719221efec63:	mov    r8,QWORD PTR [r12+0x40]
    719221efec68:	add    r8,0x3a
    719221efec6c:	movzx  r9d,BYTE PTR [r8]
    719221efec70:	mov    r8,r9
    719221efec73:	shl    r8,0x30
    719221efec77:	or     rbp,r8
    719221efec7a:	mov    r8,QWORD PTR [r12+0x40]
    719221efec7f:	add    r8,0x3b
    719221efec83:	movzx  r9d,BYTE PTR [r8]
    719221efec87:	mov    r8,r9
    719221efec8a:	shl    r8,0x30
    719221efec8e:	or     r13,r8
    719221efec91:	mov    r8,QWORD PTR [r12+0x40]
    719221efec96:	add    r8,0x3c
    719221efec9a:	movzx  r9d,BYTE PTR [r8]
    719221efec9e:	mov    r8,r9
    719221efeca1:	shl    r8,0x38
    719221efeca5:	or     r14,r8
    719221efeca8:	mov    r8,QWORD PTR [r12+0x40]
    719221efecad:	add    r8,0x3d
    719221efecb1:	movzx  r9d,BYTE PTR [r8]
    719221efecb5:	mov    r8,r9
    719221efecb8:	shl    r8,0x38
    719221efecbc:	or     r15,r8
    719221efecbf:	mov    r8,QWORD PTR [r12+0x40]
    719221efecc4:	add    r8,0x3e
    719221efecc8:	movzx  r9d,BYTE PTR [r8]
    719221efeccc:	mov    r8,r9
    719221efeccf:	shl    r8,0x38
    719221efecd3:	or     rbp,r8
    719221efecd6:	mov    r8,QWORD PTR [r12+0x40]
    719221efecdb:	add    r8,0x3f
    719221efecdf:	movzx  r9d,BYTE PTR [r8]
    719221efece3:	mov    r8,r9
    719221efece6:	shl    r8,0x38
    719221efecea:	mov    rax,r13
    719221efeced:	or     rax,r8
    719221efecf0:	mov    QWORD PTR [rsp+0x40],rax
    719221efecf5:	mov    r8d,0x0
    719221efecfb:	mov    QWORD PTR [r12+0x58],r8
    719221efed00:	mov    r8d,0x0
    719221efed06:	mov    r9,QWORD PTR [rsp+0x38]
    719221efed0b:	and    r9,0xff
    719221efed12:	and    r9,0xffff
    719221efed19:	mov    r13,r8
    719221efed1c:	or     r13,r9
    719221efed1f:	mov    r9,QWORD PTR [rsp+0x38]
    719221efed24:	shr    r9,0x8
    719221efed28:	and    r9,0xff
    719221efed2f:	and    r9,0xffff
    719221efed36:	shl    r9,0x10
    719221efed3a:	or     r13,r9
    719221efed3d:	mov    r9,QWORD PTR [rsp+0x38]
    719221efed42:	shr    r9,0x10
    719221efed46:	and    r9,0xff
    719221efed4d:	and    r9,0xffff
    719221efed54:	shl    r9,0x20
    719221efed58:	or     r13,r9
    719221efed5b:	mov    r9,QWORD PTR [rsp+0x38]
    719221efed60:	shr    r9,0x18
    719221efed64:	and    r9,0xff
    719221efed6b:	and    r9,0xffff
    719221efed72:	shl    r9,0x30
    719221efed76:	or     r13,r9
    719221efed79:	mov    r9,QWORD PTR [rsp+0x38]
    719221efed7e:	shr    r9,0x20
    719221efed82:	and    r9,0xff
    719221efed89:	and    r9,0xffff
    719221efed90:	or     r8,r9
    719221efed93:	mov    r9,QWORD PTR [rsp+0x38]
    719221efed98:	shr    r9,0x28
    719221efed9c:	and    r9,0xff
    719221efeda3:	and    r9,0xffff
    719221efedaa:	shl    r9,0x10
    719221efedae:	or     r8,r9
    719221efedb1:	mov    r9,QWORD PTR [rsp+0x38]
    719221efedb6:	shr    r9,0x30
    719221efedba:	and    r9,0xff
    719221efedc1:	and    r9,0xffff
    719221efedc8:	shl    r9,0x20
    719221efedcc:	or     r8,r9
    719221efedcf:	mov    r9,QWORD PTR [rsp+0x38]
    719221efedd4:	shr    r9,0x38
    719221efedd8:	and    r9,0xff
    719221efeddf:	and    r9,0xffff
    719221efede6:	shl    r9,0x30
    719221efedea:	or     r8,r9
    719221efeded:	mov    QWORD PTR [r12+0x150],r13
    719221efedf5:	mov    QWORD PTR [r12+0x158],r8
    719221efedfd:	mov    r13d,0x0
    719221efee03:	mov    r8,QWORD PTR [rsp+0x30]
    719221efee08:	and    r8,0xff
    719221efee0f:	and    r8,0xffff
    719221efee16:	mov    r9,r13
    719221efee19:	or     r9,r8
    719221efee1c:	mov    r8,QWORD PTR [rsp+0x30]
    719221efee21:	shr    r8,0x8
    719221efee25:	and    r8,0xff
    719221efee2c:	and    r8,0xffff
    719221efee33:	shl    r8,0x10
    719221efee37:	or     r9,r8
    719221efee3a:	mov    r8,QWORD PTR [rsp+0x30]
    719221efee3f:	shr    r8,0x10
    719221efee43:	and    r8,0xff
    719221efee4a:	and    r8,0xffff
    719221efee51:	shl    r8,0x20
    719221efee55:	or     r9,r8
    719221efee58:	mov    r8,QWORD PTR [rsp+0x30]
    719221efee5d:	shr    r8,0x18
    719221efee61:	and    r8,0xff
    719221efee68:	and    r8,0xffff
    719221efee6f:	shl    r8,0x30
    719221efee73:	mov    rax,r9
    719221efee76:	or     rax,r8
    719221efee79:	mov    QWORD PTR [rsp+0x50],rax
    719221efee7e:	mov    r8,QWORD PTR [rsp+0x30]
    719221efee83:	shr    r8,0x20
    719221efee87:	and    r8,0xff
    719221efee8e:	and    r8,0xffff
    719221efee95:	or     r13,r8
    719221efee98:	mov    r8,QWORD PTR [rsp+0x30]
    719221efee9d:	shr    r8,0x28
    719221efeea1:	and    r8,0xff
    719221efeea8:	and    r8,0xffff
    719221efeeaf:	shl    r8,0x10
    719221efeeb3:	or     r13,r8
    719221efeeb6:	mov    r8,QWORD PTR [rsp+0x30]
    719221efeebb:	shr    r8,0x30
    719221efeebf:	and    r8,0xff
    719221efeec6:	and    r8,0xffff
    719221efeecd:	shl    r8,0x20
    719221efeed1:	or     r13,r8
    719221efeed4:	mov    r8,QWORD PTR [rsp+0x30]
    719221efeed9:	shr    r8,0x38
    719221efeedd:	and    r8,0xff
    719221efeee4:	and    r8,0xffff
    719221efeeeb:	shl    r8,0x30
    719221efeeef:	mov    rax,r13
    719221efeef2:	or     rax,r8
    719221efeef5:	mov    QWORD PTR [rsp+0x48],rax
    719221efeefa:	mov    r8d,0x0
    719221efef00:	mov    r13,QWORD PTR [rsp+0x28]
    719221efef05:	and    r13,0xff
    719221efef0c:	and    r13,0xffff
    719221efef13:	mov    r9,r8
    719221efef16:	or     r9,r13
    719221efef19:	mov    r13,QWORD PTR [rsp+0x28]
    719221efef1e:	shr    r13,0x8
    719221efef22:	and    r13,0xff
    719221efef29:	and    r13,0xffff
    719221efef30:	shl    r13,0x10
    719221efef34:	or     r9,r13
    719221efef37:	mov    r13,QWORD PTR [rsp+0x28]
    719221efef3c:	shr    r13,0x10
    719221efef40:	and    r13,0xff
    719221efef47:	and    r13,0xffff
    719221efef4e:	shl    r13,0x20
    719221efef52:	or     r9,r13
    719221efef55:	mov    r13,QWORD PTR [rsp+0x28]
    719221efef5a:	shr    r13,0x18
    719221efef5e:	and    r13,0xff
    719221efef65:	and    r13,0xffff
    719221efef6c:	shl    r13,0x30
    719221efef70:	mov    rax,r9
    719221efef73:	or     rax,r13
    719221efef76:	mov    QWORD PTR [rsp+0x58],rax
    719221efef7b:	mov    r13,QWORD PTR [rsp+0x28]
    719221efef80:	shr    r13,0x20
    719221efef84:	and    r13,0xff
    719221efef8b:	and    r13,0xffff
    719221efef92:	or     r8,r13
    719221efef95:	mov    r13,QWORD PTR [rsp+0x28]
    719221efef9a:	shr    r13,0x28
    719221efef9e:	and    r13,0xff
    719221efefa5:	and    r13,0xffff
    719221efefac:	shl    r13,0x10
    719221efefb0:	or     r8,r13
    719221efefb3:	mov    r13,QWORD PTR [rsp+0x28]
    719221efefb8:	shr    r13,0x30
    719221efefbc:	and    r13,0xff
    719221efefc3:	and    r13,0xffff
    719221efefca:	shl    r13,0x20
    719221efefce:	or     r8,r13
    719221efefd1:	mov    r13,QWORD PTR [rsp+0x28]
    719221efefd6:	shr    r13,0x38
    719221efefda:	and    r13,0xff
    719221efefe1:	and    r13,0xffff
    719221efefe8:	shl    r13,0x30
    719221efefec:	mov    rax,r8
    719221efefef:	or     rax,r13
    719221efeff2:	mov    QWORD PTR [rsp+0x60],rax
    719221efeff7:	mov    r13d,0x0
    719221efeffd:	mov    r9,r14
    719221eff000:	and    r9,0xff
    719221eff007:	and    r9,0xffff
    719221eff00e:	mov    r8,r13
    719221eff011:	or     r8,r9
    719221eff014:	mov    r9,r14
    719221eff017:	shr    r9,0x8
    719221eff01b:	and    r9,0xff
    719221eff022:	and    r9,0xffff
    719221eff029:	shl    r9,0x10
    719221eff02d:	or     r8,r9
    719221eff030:	mov    r9,r14
    719221eff033:	shr    r9,0x10
    719221eff037:	and    r9,0xff
    719221eff03e:	and    r9,0xffff
    719221eff045:	shl    r9,0x20
    719221eff049:	or     r8,r9
    719221eff04c:	mov    r9,r14
    719221eff04f:	shr    r9,0x18
    719221eff053:	and    r9,0xff
    719221eff05a:	and    r9,0xffff
    719221eff061:	shl    r9,0x30
    719221eff065:	mov    rax,r8
    719221eff068:	or     rax,r9
    719221eff06b:	mov    QWORD PTR [rsp+0x68],rax
    719221eff070:	mov    r9,r14
    719221eff073:	shr    r9,0x20
    719221eff077:	and    r9,0xff
    719221eff07e:	and    r9,0xffff
    719221eff085:	or     r13,r9
    719221eff088:	mov    r9,r14
    719221eff08b:	shr    r9,0x28
    719221eff08f:	and    r9,0xff
    719221eff096:	and    r9,0xffff
    719221eff09d:	shl    r9,0x10
    719221eff0a1:	or     r13,r9
    719221eff0a4:	mov    r9,r14
    719221eff0a7:	shr    r9,0x30
    719221eff0ab:	and    r9,0xff
    719221eff0b2:	and    r9,0xffff
    719221eff0b9:	shl    r9,0x20
    719221eff0bd:	or     r13,r9
    719221eff0c0:	shr    r14,0x38
    719221eff0c4:	and    r14,0xff
    719221eff0cb:	and    r14,0xffff
    719221eff0d2:	shl    r14,0x30
    719221eff0d6:	or     r13,r14
    719221eff0d9:	mov    r14d,0x0
    719221eff0df:	mov    r9,r15
    719221eff0e2:	and    r9,0xff
    719221eff0e9:	and    r9,0xffff
    719221eff0f0:	mov    r8,r14
    719221eff0f3:	or     r8,r9
    719221eff0f6:	mov    r9,r15
    719221eff0f9:	shr    r9,0x8
    719221eff0fd:	and    r9,0xff
    719221eff104:	and    r9,0xffff
    719221eff10b:	shl    r9,0x10
    719221eff10f:	or     r8,r9
    719221eff112:	mov    r9,r15
    719221eff115:	shr    r9,0x10
    719221eff119:	and    r9,0xff
    719221eff120:	and    r9,0xffff
    719221eff127:	shl    r9,0x20
    719221eff12b:	or     r8,r9
    719221eff12e:	mov    r9,r15
    719221eff131:	shr    r9,0x18
    719221eff135:	and    r9,0xff
    719221eff13c:	and    r9,0xffff
    719221eff143:	shl    r9,0x30
    719221eff147:	or     r8,r9
    719221eff14a:	mov    r9,r15
    719221eff14d:	shr    r9,0x20
    719221eff151:	and    r9,0xff
    719221eff158:	and    r9,0xffff
    719221eff15f:	or     r14,r9
    719221eff162:	mov    r9,r15
    719221eff165:	shr    r9,0x28
    719221eff169:	and    r9,0xff
    719221eff170:	and    r9,0xffff
    719221eff177:	shl    r9,0x10
    719221eff17b:	or     r14,r9
    719221eff17e:	mov    r9,r15
    719221eff181:	shr    r9,0x30
    719221eff185:	and    r9,0xff
    719221eff18c:	and    r9,0xffff
    719221eff193:	shl    r9,0x20
    719221eff197:	or     r14,r9
    719221eff19a:	shr    r15,0x38
    719221eff19e:	and    r15,0xff
    719221eff1a5:	and    r15,0xffff
    719221eff1ac:	shl    r15,0x30
    719221eff1b0:	or     r14,r15
    719221eff1b3:	mov    QWORD PTR [r12+0x210],r8
    719221eff1bb:	mov    QWORD PTR [r12+0x218],r14
    719221eff1c3:	mov    r14d,0x0
    719221eff1c9:	mov    r15,rbp
    719221eff1cc:	and    r15,0xff
    719221eff1d3:	and    r15,0xffff
    719221eff1da:	mov    r8,r14
    719221eff1dd:	or     r8,r15
    719221eff1e0:	mov    r15,rbp
    719221eff1e3:	shr    r15,0x8
    719221eff1e7:	and    r15,0xff
    719221eff1ee:	and    r15,0xffff
    719221eff1f5:	shl    r15,0x10
    719221eff1f9:	or     r8,r15
    719221eff1fc:	mov    r15,rbp
    719221eff1ff:	shr    r15,0x10
    719221eff203:	and    r15,0xff
    719221eff20a:	and    r15,0xffff
    719221eff211:	shl    r15,0x20
    719221eff215:	or     r8,r15
    719221eff218:	mov    r15,rbp
    719221eff21b:	shr    r15,0x18
    719221eff21f:	and    r15,0xff
    719221eff226:	and    r15,0xffff
    719221eff22d:	shl    r15,0x30
    719221eff231:	or     r8,r15
    719221eff234:	mov    r15,rbp
    719221eff237:	shr    r15,0x20
    719221eff23b:	and    r15,0xff
    719221eff242:	and    r15,0xffff
    719221eff249:	or     r14,r15
    719221eff24c:	mov    r15,rbp
    719221eff24f:	shr    r15,0x28
    719221eff253:	and    r15,0xff
    719221eff25a:	and    r15,0xffff
    719221eff261:	shl    r15,0x10
    719221eff265:	or     r14,r15
    719221eff268:	mov    r15,rbp
    719221eff26b:	shr    r15,0x30
    719221eff26f:	and    r15,0xff
    719221eff276:	and    r15,0xffff
    719221eff27d:	shl    r15,0x20
    719221eff281:	or     r14,r15
    719221eff284:	shr    rbp,0x38
    719221eff288:	and    rbp,0xff
    719221eff28f:	and    rbp,0xffff
    719221eff296:	shl    rbp,0x30
    719221eff29a:	or     r14,rbp
    719221eff29d:	mov    r15d,0x0
    719221eff2a3:	mov    rbp,QWORD PTR [rsp+0x20]
    719221eff2a8:	and    rbp,0xff
    719221eff2af:	and    rbp,0xffff
    719221eff2b6:	mov    r9,r15
    719221eff2b9:	or     r9,rbp
    719221eff2bc:	mov    rbp,QWORD PTR [rsp+0x20]
    719221eff2c1:	shr    rbp,0x8
    719221eff2c5:	and    rbp,0xff
    719221eff2cc:	and    rbp,0xffff
    719221eff2d3:	shl    rbp,0x10
    719221eff2d7:	or     r9,rbp
    719221eff2da:	mov    rbp,QWORD PTR [rsp+0x20]
    719221eff2df:	shr    rbp,0x10
    719221eff2e3:	and    rbp,0xff
    719221eff2ea:	and    rbp,0xffff
    719221eff2f1:	shl    rbp,0x20
    719221eff2f5:	or     r9,rbp
    719221eff2f8:	mov    rbp,QWORD PTR [rsp+0x20]
    719221eff2fd:	shr    rbp,0x18
    719221eff301:	and    rbp,0xff
    719221eff308:	and    rbp,0xffff
    719221eff30f:	shl    rbp,0x30
    719221eff313:	mov    rax,r9
    719221eff316:	or     rax,rbp
    719221eff319:	mov    QWORD PTR [rsp+0x78],rax
    719221eff31e:	mov    rbp,QWORD PTR [rsp+0x20]
    719221eff323:	shr    rbp,0x20
    719221eff327:	and    rbp,0xff
    719221eff32e:	and    rbp,0xffff
    719221eff335:	or     r15,rbp
    719221eff338:	mov    rbp,QWORD PTR [rsp+0x20]
    719221eff33d:	shr    rbp,0x28
    719221eff341:	and    rbp,0xff
    719221eff348:	and    rbp,0xffff
    719221eff34f:	shl    rbp,0x10
    719221eff353:	or     r15,rbp
    719221eff356:	mov    rbp,QWORD PTR [rsp+0x20]
    719221eff35b:	shr    rbp,0x30
    719221eff35f:	and    rbp,0xff
    719221eff366:	and    rbp,0xffff
    719221eff36d:	shl    rbp,0x20
    719221eff371:	or     r15,rbp
    719221eff374:	mov    rbp,QWORD PTR [rsp+0x20]
    719221eff379:	shr    rbp,0x38
    719221eff37d:	and    rbp,0xff
    719221eff384:	and    rbp,0xffff
    719221eff38b:	shl    rbp,0x30
    719221eff38f:	mov    rax,r15
    719221eff392:	or     rax,rbp
    719221eff395:	mov    QWORD PTR [rsp+0x70],rax
    719221eff39a:	mov    rax,QWORD PTR [rsp+0x78]
    719221eff39f:	mov    QWORD PTR [r12+0x250],rax
    719221eff3a7:	mov    rax,QWORD PTR [rsp+0x70]
    719221eff3ac:	mov    QWORD PTR [r12+0x258],rax
    719221eff3b4:	mov    ebp,0x0
    719221eff3b9:	mov    r15,QWORD PTR [rsp+0x40]
    719221eff3be:	and    r15,0xff
    719221eff3c5:	and    r15,0xffff
    719221eff3cc:	mov    r9,rbp
    719221eff3cf:	or     r9,r15
    719221eff3d2:	mov    r15,QWORD PTR [rsp+0x40]
    719221eff3d7:	shr    r15,0x8
    719221eff3db:	and    r15,0xff
    719221eff3e2:	and    r15,0xffff
    719221eff3e9:	shl    r15,0x10
    719221eff3ed:	or     r9,r15
    719221eff3f0:	mov    r15,QWORD PTR [rsp+0x40]
    719221eff3f5:	shr    r15,0x10
    719221eff3f9:	and    r15,0xff
    719221eff400:	and    r15,0xffff
    719221eff407:	shl    r15,0x20
    719221eff40b:	or     r9,r15
    719221eff40e:	mov    r15,QWORD PTR [rsp+0x40]
    719221eff413:	shr    r15,0x18
    719221eff417:	and    r15,0xff
    719221eff41e:	and    r15,0xffff
    719221eff425:	shl    r15,0x30
    719221eff429:	mov    rax,r9
    719221eff42c:	or     rax,r15
    719221eff42f:	mov    QWORD PTR [rsp+0x80],rax
    719221eff437:	mov    r15,QWORD PTR [rsp+0x40]
    719221eff43c:	shr    r15,0x20
    719221eff440:	and    r15,0xff
    719221eff447:	and    r15,0xffff
    719221eff44e:	or     rbp,r15
    719221eff451:	mov    r15,QWORD PTR [rsp+0x40]
    719221eff456:	shr    r15,0x28
    719221eff45a:	and    r15,0xff
    719221eff461:	and    r15,0xffff
    719221eff468:	shl    r15,0x10
    719221eff46c:	or     rbp,r15
    719221eff46f:	mov    r15,QWORD PTR [rsp+0x40]
    719221eff474:	shr    r15,0x30
    719221eff478:	and    r15,0xff
    719221eff47f:	and    r15,0xffff
    719221eff486:	shl    r15,0x20
    719221eff48a:	or     rbp,r15
    719221eff48d:	mov    r15,QWORD PTR [rsp+0x40]
    719221eff492:	shr    r15,0x38
    719221eff496:	and    r15,0xff
    719221eff49d:	and    r15,0xffff
    719221eff4a4:	shl    r15,0x30
    719221eff4a8:	mov    rax,rbp
    719221eff4ab:	or     rax,r15
    719221eff4ae:	mov    QWORD PTR [rsp+0x88],rax
    719221eff4b6:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    719221eff4c0:	pxor   xmm0,xmm0
    719221eff4c4:	movdqa xmm3,xmm0
    719221eff4c8:	movdqa xmm0,xmm2
    719221eff4cc:	movdqa xmm1,xmm3
    719221eff4d0:	punpcklwd xmm0,xmm1
    719221eff4d4:	movdqa xmm4,xmm0
    719221eff4d8:	movdqa xmm0,xmm4
    719221eff4dc:	pslld  xmm0,0x10
    719221eff4e1:	movdqa xmm3,xmm0
    719221eff4e5:	mov    r15d,0x0
    719221eff4eb:	mov    r9,QWORD PTR [rsp+0x50]
    719221eff4f0:	and    r9,0xffff
    719221eff4f7:	shl    r9,0x8
    719221eff4fb:	mov    ecx,0xffffffff
    719221eff500:	and    r9,rcx
    719221eff503:	mov    rbp,r15
    719221eff506:	or     rbp,r9
    719221eff509:	mov    r9,QWORD PTR [rsp+0x50]
    719221eff50e:	shr    r9,0x10
    719221eff512:	and    r9,0xffff
    719221eff519:	shl    r9,0x8
    719221eff51d:	mov    ecx,0xffffffff
    719221eff522:	and    r9,rcx
    719221eff525:	shl    r9,0x20
    719221eff529:	or     rbp,r9
    719221eff52c:	mov    r9,QWORD PTR [rsp+0x50]
    719221eff531:	shr    r9,0x20
    719221eff535:	and    r9,0xffff
    719221eff53c:	shl    r9,0x8
    719221eff540:	mov    ecx,0xffffffff
    719221eff545:	and    r9,rcx
    719221eff548:	or     r15,r9
    719221eff54b:	mov    r9,QWORD PTR [rsp+0x50]
    719221eff550:	shr    r9,0x30
    719221eff554:	and    r9,0xffff
    719221eff55b:	shl    r9,0x8
    719221eff55f:	mov    ecx,0xffffffff
    719221eff564:	and    r9,rcx
    719221eff567:	shl    r9,0x20
    719221eff56b:	or     r15,r9
    719221eff56e:	mov    QWORD PTR [r12+0x240],rbp
    719221eff576:	mov    QWORD PTR [r12+0x248],r15
    719221eff57e:	mov    r15d,0x0
    719221eff584:	mov    rbp,QWORD PTR [rsp+0x60]
    719221eff589:	and    rbp,0xffff
    719221eff590:	mov    ecx,0xffffffff
    719221eff595:	and    rbp,rcx
    719221eff598:	mov    r9,r15
    719221eff59b:	or     r9,rbp
    719221eff59e:	mov    rbp,QWORD PTR [rsp+0x60]
    719221eff5a3:	shr    rbp,0x10
    719221eff5a7:	and    rbp,0xffff
    719221eff5ae:	mov    ecx,0xffffffff
    719221eff5b3:	and    rbp,rcx
    719221eff5b6:	shl    rbp,0x20
    719221eff5ba:	or     r9,rbp
    719221eff5bd:	mov    rbp,QWORD PTR [rsp+0x60]
    719221eff5c2:	shr    rbp,0x20
    719221eff5c6:	and    rbp,0xffff
    719221eff5cd:	mov    ecx,0xffffffff
    719221eff5d2:	and    rbp,rcx
    719221eff5d5:	or     r15,rbp
    719221eff5d8:	mov    rbp,QWORD PTR [rsp+0x60]
    719221eff5dd:	shr    rbp,0x30
    719221eff5e1:	and    rbp,0xffff
    719221eff5e8:	mov    ecx,0xffffffff
    719221eff5ed:	and    rbp,rcx
    719221eff5f0:	shl    rbp,0x20
    719221eff5f4:	or     r15,rbp
    719221eff5f7:	mov    QWORD PTR [r12+0x260],r9
    719221eff5ff:	mov    QWORD PTR [r12+0x268],r15
    719221eff607:	mov    r15d,0x0
    719221eff60d:	mov    rbp,r13
    719221eff610:	and    rbp,0xffff
    719221eff617:	mov    ecx,0xffffffff
    719221eff61c:	and    rbp,rcx
    719221eff61f:	mov    r9,r15
    719221eff622:	or     r9,rbp
    719221eff625:	mov    rbp,r13
    719221eff628:	shr    rbp,0x10
    719221eff62c:	and    rbp,0xffff
    719221eff633:	mov    ecx,0xffffffff
    719221eff638:	and    rbp,rcx
    719221eff63b:	shl    rbp,0x20
    719221eff63f:	or     r9,rbp
    719221eff642:	mov    rbp,r13
    719221eff645:	shr    rbp,0x20
    719221eff649:	and    rbp,0xffff
    719221eff650:	mov    ecx,0xffffffff
    719221eff655:	and    rbp,rcx
    719221eff658:	or     r15,rbp
    719221eff65b:	shr    r13,0x30
    719221eff65f:	and    r13,0xffff
    719221eff666:	mov    ecx,0xffffffff
    719221eff66b:	and    r13,rcx
    719221eff66e:	shl    r13,0x20
    719221eff672:	or     r15,r13
    719221eff675:	mov    QWORD PTR [r12+0x270],r9
    719221eff67d:	mov    QWORD PTR [r12+0x278],r15
    719221eff685:	mov    r13d,0x0
    719221eff68b:	mov    r15,QWORD PTR [rsp+0x58]
    719221eff690:	and    r15,0xffff
    719221eff697:	mov    ecx,0xffffffff
    719221eff69c:	and    r15,rcx
    719221eff69f:	mov    rbp,r13
    719221eff6a2:	or     rbp,r15
    719221eff6a5:	mov    r15,QWORD PTR [rsp+0x58]
    719221eff6aa:	shr    r15,0x10
    719221eff6ae:	and    r15,0xffff
    719221eff6b5:	mov    ecx,0xffffffff
    719221eff6ba:	and    r15,rcx
    719221eff6bd:	shl    r15,0x20
    719221eff6c1:	or     rbp,r15
    719221eff6c4:	mov    r15,QWORD PTR [rsp+0x58]
    719221eff6c9:	shr    r15,0x20
    719221eff6cd:	and    r15,0xffff
    719221eff6d4:	mov    ecx,0xffffffff
    719221eff6d9:	and    r15,rcx
    719221eff6dc:	or     r13,r15
    719221eff6df:	mov    r15,QWORD PTR [rsp+0x58]
    719221eff6e4:	shr    r15,0x30
    719221eff6e8:	and    r15,0xffff
    719221eff6ef:	mov    ecx,0xffffffff
    719221eff6f4:	and    r15,rcx
    719221eff6f7:	shl    r15,0x20
    719221eff6fb:	or     r13,r15
    719221eff6fe:	mov    QWORD PTR [r12+0x170],rbp
    719221eff706:	mov    QWORD PTR [r12+0x178],r13
    719221eff70e:	movdqu xmm4,XMMWORD PTR [r12+0x210]
    719221eff718:	pxor   xmm0,xmm0
    719221eff71c:	movdqa xmm5,xmm0
    719221eff720:	movdqa xmm0,xmm4
    719221eff724:	movdqa xmm1,xmm5
    719221eff728:	punpckhwd xmm0,xmm1
    719221eff72c:	movdqa xmm6,xmm0
    719221eff730:	movdqa xmm0,xmm6
    719221eff734:	pslld  xmm0,0x10
    719221eff739:	movdqa xmm5,xmm0
    719221eff73d:	movdqu XMMWORD PTR [r12+0x280],xmm5
    719221eff747:	mov    r13d,0x0
    719221eff74d:	mov    r15,QWORD PTR [rsp+0x68]
    719221eff752:	and    r15,0xffff
    719221eff759:	mov    ecx,0xffffffff
    719221eff75e:	and    r15,rcx
    719221eff761:	mov    rbp,r13
    719221eff764:	or     rbp,r15
    719221eff767:	mov    r15,QWORD PTR [rsp+0x68]
    719221eff76c:	shr    r15,0x10
    719221eff770:	and    r15,0xffff
    719221eff777:	mov    ecx,0xffffffff
    719221eff77c:	and    r15,rcx
    719221eff77f:	shl    r15,0x20
    719221eff783:	or     rbp,r15
    719221eff786:	mov    r15,QWORD PTR [rsp+0x68]
    719221eff78b:	shr    r15,0x20
    719221eff78f:	and    r15,0xffff
    719221eff796:	mov    ecx,0xffffffff
    719221eff79b:	and    r15,rcx
    719221eff79e:	or     r13,r15
    719221eff7a1:	mov    r15,QWORD PTR [rsp+0x68]
    719221eff7a6:	shr    r15,0x30
    719221eff7aa:	and    r15,0xffff
    719221eff7b1:	mov    ecx,0xffffffff
    719221eff7b6:	and    r15,rcx
    719221eff7b9:	shl    r15,0x20
    719221eff7bd:	or     r13,r15
    719221eff7c0:	mov    QWORD PTR [r12+0x180],rbp
    719221eff7c8:	mov    QWORD PTR [r12+0x188],r13
    719221eff7d0:	pxor   xmm0,xmm0
    719221eff7d4:	movdqa xmm6,xmm0
    719221eff7d8:	movdqa xmm0,xmm4
    719221eff7dc:	movdqa xmm1,xmm6
    719221eff7e0:	punpcklwd xmm0,xmm1
    719221eff7e4:	movdqa xmm7,xmm0
    719221eff7e8:	movdqa xmm0,xmm7
    719221eff7ec:	pslld  xmm0,0x10
    719221eff7f1:	movdqa xmm4,xmm0
    719221eff7f5:	pxor   xmm0,xmm0
    719221eff7f9:	movdqa xmm6,xmm0
    719221eff7fd:	movdqa xmm0,xmm2
    719221eff801:	movdqa xmm1,xmm6
    719221eff805:	punpckhwd xmm0,xmm1
    719221eff809:	movdqa xmm7,xmm0
    719221eff80d:	movdqa xmm0,xmm7
    719221eff811:	pslld  xmm0,0x10
    719221eff816:	movdqa xmm2,xmm0
    719221eff81a:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    719221eff824:	movdqa xmm1,xmm6
    719221eff828:	por    xmm3,xmm1
    719221eff82c:	movdqu XMMWORD PTR [r12+0x230],xmm3
    719221eff836:	mov    r13d,0x0
    719221eff83c:	mov    r15,r14
    719221eff83f:	and    r15,0xffff
    719221eff846:	shl    r15,0x8
    719221eff84a:	mov    ecx,0xffffffff
    719221eff84f:	and    r15,rcx
    719221eff852:	mov    rbp,r13
    719221eff855:	or     rbp,r15
    719221eff858:	mov    r15,r14
    719221eff85b:	shr    r15,0x10
    719221eff85f:	and    r15,0xffff
    719221eff866:	shl    r15,0x8
    719221eff86a:	mov    ecx,0xffffffff
    719221eff86f:	and    r15,rcx
    719221eff872:	shl    r15,0x20
    719221eff876:	or     rbp,r15
    719221eff879:	mov    r15,r14
    719221eff87c:	shr    r15,0x20
    719221eff880:	and    r15,0xffff
    719221eff887:	shl    r15,0x8
    719221eff88b:	mov    ecx,0xffffffff
    719221eff890:	and    r15,rcx
    719221eff893:	or     r13,r15
    719221eff896:	shr    r14,0x30
    719221eff89a:	and    r14,0xffff
    719221eff8a1:	shl    r14,0x8
    719221eff8a5:	mov    ecx,0xffffffff
    719221eff8aa:	and    r14,rcx
    719221eff8ad:	shl    r14,0x20
    719221eff8b1:	or     r13,r14
    719221eff8b4:	mov    QWORD PTR [r12+0x240],rbp
    719221eff8bc:	mov    QWORD PTR [r12+0x248],r13
    719221eff8c4:	mov    r13d,0x0
    719221eff8ca:	mov    r14,r8
    719221eff8cd:	and    r14,0xffff
    719221eff8d4:	shl    r14,0x8
    719221eff8d8:	mov    ecx,0xffffffff
    719221eff8dd:	and    r14,rcx
    719221eff8e0:	mov    r15,r13
    719221eff8e3:	or     r15,r14
    719221eff8e6:	mov    r14,r8
    719221eff8e9:	shr    r14,0x10
    719221eff8ed:	and    r14,0xffff
    719221eff8f4:	shl    r14,0x8
    719221eff8f8:	mov    ecx,0xffffffff
    719221eff8fd:	and    r14,rcx
    719221eff900:	shl    r14,0x20
    719221eff904:	or     r15,r14
    719221eff907:	mov    r14,r8
    719221eff90a:	shr    r14,0x20
    719221eff90e:	and    r14,0xffff
    719221eff915:	shl    r14,0x8
    719221eff919:	mov    ecx,0xffffffff
    719221eff91e:	and    r14,rcx
    719221eff921:	or     r13,r14
    719221eff924:	shr    r8,0x30
    719221eff928:	and    r8,0xffff
    719221eff92f:	shl    r8,0x8
    719221eff933:	mov    ecx,0xffffffff
    719221eff938:	and    r8,rcx
    719221eff93b:	shl    r8,0x20
    719221eff93f:	or     r13,r8
    719221eff942:	mov    QWORD PTR [r12+0x220],r15
    719221eff94a:	mov    QWORD PTR [r12+0x228],r13
    719221eff952:	mov    r13d,0x0
    719221eff958:	mov    r14,QWORD PTR [rsp+0x48]
    719221eff95d:	and    r14,0xffff
    719221eff964:	shl    r14,0x8
    719221eff968:	mov    ecx,0xffffffff
    719221eff96d:	and    r14,rcx
    719221eff970:	mov    r15,r13
    719221eff973:	or     r15,r14
    719221eff976:	mov    r14,QWORD PTR [rsp+0x48]
    719221eff97b:	shr    r14,0x10
    719221eff97f:	and    r14,0xffff
    719221eff986:	shl    r14,0x8
    719221eff98a:	mov    ecx,0xffffffff
    719221eff98f:	and    r14,rcx
    719221eff992:	shl    r14,0x20
    719221eff996:	or     r15,r14
    719221eff999:	mov    r14,QWORD PTR [rsp+0x48]
    719221eff99e:	shr    r14,0x20
    719221eff9a2:	and    r14,0xffff
    719221eff9a9:	shl    r14,0x8
    719221eff9ad:	mov    ecx,0xffffffff
    719221eff9b2:	and    r14,rcx
    719221eff9b5:	or     r13,r14
    719221eff9b8:	mov    r14,QWORD PTR [rsp+0x48]
    719221eff9bd:	shr    r14,0x30
    719221eff9c1:	and    r14,0xffff
    719221eff9c8:	shl    r14,0x8
    719221eff9cc:	mov    ecx,0xffffffff
    719221eff9d1:	and    r14,rcx
    719221eff9d4:	shl    r14,0x20
    719221eff9d8:	or     r13,r14
    719221eff9db:	mov    QWORD PTR [r12+0x160],r15
    719221eff9e3:	mov    QWORD PTR [r12+0x168],r13
    719221eff9eb:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    719221eff9f5:	movdqa xmm0,xmm6
    719221eff9f9:	pslld  xmm0,0x18
    719221eff9fe:	movdqa xmm7,xmm0
    719221effa02:	movdqu XMMWORD PTR [r12+0x170],xmm7
    719221effa0c:	movdqu xmm6,XMMWORD PTR [r12+0x270]
    719221effa16:	movdqa xmm0,xmm6
    719221effa1a:	pslld  xmm0,0x18
    719221effa1f:	movdqa xmm8,xmm0
    719221effa24:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    719221effa2e:	movdqa xmm0,xmm6
    719221effa32:	pslld  xmm0,0x18
    719221effa37:	movdqa xmm9,xmm0
    719221effa3c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    719221effa46:	mov    r13d,0x0
    719221effa4c:	mov    r14,QWORD PTR [rsp+0x78]
    719221effa51:	and    r14,0xffff
    719221effa58:	mov    ecx,0xffffffff
    719221effa5d:	and    r14,rcx
    719221effa60:	mov    r15,r13
    719221effa63:	or     r15,r14
    719221effa66:	mov    r14,QWORD PTR [rsp+0x78]
    719221effa6b:	shr    r14,0x10
    719221effa6f:	and    r14,0xffff
    719221effa76:	mov    ecx,0xffffffff
    719221effa7b:	and    r14,rcx
    719221effa7e:	shl    r14,0x20
    719221effa82:	or     r15,r14
    719221effa85:	mov    r14,QWORD PTR [rsp+0x78]
    719221effa8a:	shr    r14,0x20
    719221effa8e:	and    r14,0xffff
    719221effa95:	mov    ecx,0xffffffff
    719221effa9a:	and    r14,rcx
    719221effa9d:	or     r13,r14
    719221effaa0:	mov    r14,QWORD PTR [rsp+0x78]
    719221effaa5:	shr    r14,0x30
    719221effaa9:	and    r14,0xffff
    719221effab0:	mov    ecx,0xffffffff
    719221effab5:	and    r14,rcx
    719221effab8:	shl    r14,0x20
    719221effabc:	or     r13,r14
    719221effabf:	mov    QWORD PTR [r12+0x140],r15
    719221effac7:	mov    QWORD PTR [r12+0x148],r13
    719221effacf:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    719221effad9:	movdqa xmm1,xmm6
    719221effadd:	por    xmm5,xmm1
    719221effae1:	movdqu xmm6,XMMWORD PTR [r12+0x220]
    719221effaeb:	movdqa xmm1,xmm6
    719221effaef:	por    xmm4,xmm1
    719221effaf3:	movdqu XMMWORD PTR [r12+0x210],xmm4
    719221effafd:	movdqu xmm6,XMMWORD PTR [r12+0x260]
    719221effb07:	movdqa xmm0,xmm6
    719221effb0b:	pslld  xmm0,0x18
    719221effb10:	movdqa xmm10,xmm0
    719221effb15:	movdqu XMMWORD PTR [r12+0x220],xmm10
    719221effb1f:	movdqu xmm6,XMMWORD PTR [r12+0x160]
    719221effb29:	movdqa xmm1,xmm6
    719221effb2d:	por    xmm2,xmm1
    719221effb31:	movdqa xmm1,xmm7
    719221effb35:	por    xmm3,xmm1
    719221effb39:	movdqu XMMWORD PTR [r12+0x160],xmm3
    719221effb43:	mov    r13d,0x0
    719221effb49:	mov    r14,QWORD PTR [rsp+0x88]
    719221effb51:	and    r14,0xffff
    719221effb58:	mov    ecx,0xffffffff
    719221effb5d:	and    r14,rcx
    719221effb60:	mov    r15,r13
    719221effb63:	or     r15,r14
    719221effb66:	mov    r14,QWORD PTR [rsp+0x88]
    719221effb6e:	shr    r14,0x10
    719221effb72:	and    r14,0xffff
    719221effb79:	mov    ecx,0xffffffff
    719221effb7e:	and    r14,rcx
    719221effb81:	shl    r14,0x20
    719221effb85:	or     r15,r14
    719221effb88:	mov    r14,QWORD PTR [rsp+0x88]
    719221effb90:	shr    r14,0x20
    719221effb94:	and    r14,0xffff
    719221effb9b:	mov    ecx,0xffffffff
    719221effba0:	and    r14,rcx
    719221effba3:	or     r13,r14
    719221effba6:	mov    r14,QWORD PTR [rsp+0x88]
    719221effbae:	shr    r14,0x30
    719221effbb2:	and    r14,0xffff
    719221effbb9:	mov    ecx,0xffffffff
    719221effbbe:	and    r14,rcx
    719221effbc1:	shl    r14,0x20
    719221effbc5:	or     r13,r14
    719221effbc8:	mov    QWORD PTR [r12+0x170],r15
    719221effbd0:	mov    QWORD PTR [r12+0x178],r13
    719221effbd8:	mov    r13d,0x0
    719221effbde:	mov    r14,QWORD PTR [rsp+0x80]
    719221effbe6:	and    r14,0xffff
    719221effbed:	mov    ecx,0xffffffff
    719221effbf2:	and    r14,rcx
    719221effbf5:	mov    r15,r13
    719221effbf8:	or     r15,r14
    719221effbfb:	mov    r14,QWORD PTR [rsp+0x80]
    719221effc03:	shr    r14,0x10
    719221effc07:	and    r14,0xffff
    719221effc0e:	mov    ecx,0xffffffff
    719221effc13:	and    r14,rcx
    719221effc16:	shl    r14,0x20
    719221effc1a:	or     r15,r14
    719221effc1d:	mov    r14,QWORD PTR [rsp+0x80]
    719221effc25:	shr    r14,0x20
    719221effc29:	and    r14,0xffff
    719221effc30:	mov    ecx,0xffffffff
    719221effc35:	and    r14,rcx
    719221effc38:	or     r13,r14
    719221effc3b:	mov    r14,QWORD PTR [rsp+0x80]
    719221effc43:	shr    r14,0x30
    719221effc47:	and    r14,0xffff
    719221effc4e:	mov    ecx,0xffffffff
    719221effc53:	and    r14,rcx
    719221effc56:	shl    r14,0x20
    719221effc5a:	or     r13,r14
    719221effc5d:	mov    QWORD PTR [r12+0x110],r15
    719221effc65:	mov    QWORD PTR [r12+0x118],r13
    719221effc6d:	movdqa xmm1,xmm8
    719221effc72:	por    xmm5,xmm1
    719221effc76:	movdqa xmm1,xmm9
    719221effc7b:	por    xmm4,xmm1
    719221effc7f:	mov    r13d,0x0
    719221effc85:	mov    r14,QWORD PTR [rsp+0x70]
    719221effc8a:	and    r14,0xffff
    719221effc91:	mov    ecx,0xffffffff
    719221effc96:	and    r14,rcx
    719221effc99:	mov    r15,r13
    719221effc9c:	or     r15,r14
    719221effc9f:	mov    r14,QWORD PTR [rsp+0x70]
    719221effca4:	shr    r14,0x10
    719221effca8:	and    r14,0xffff
    719221effcaf:	mov    ecx,0xffffffff
    719221effcb4:	and    r14,rcx
    719221effcb7:	shl    r14,0x20
    719221effcbb:	or     r15,r14
    719221effcbe:	mov    r14,QWORD PTR [rsp+0x70]
    719221effcc3:	shr    r14,0x20
    719221effcc7:	and    r14,0xffff
    719221effcce:	mov    ecx,0xffffffff
    719221effcd3:	and    r14,rcx
    719221effcd6:	or     r13,r14
    719221effcd9:	mov    r14,QWORD PTR [rsp+0x70]
    719221effcde:	shr    r14,0x30
    719221effce2:	and    r14,0xffff
    719221effce9:	mov    ecx,0xffffffff
    719221effcee:	and    r14,rcx
    719221effcf1:	shl    r14,0x20
    719221effcf5:	or     r13,r14
    719221effcf8:	mov    QWORD PTR [r12+0x180],r15
    719221effd00:	mov    QWORD PTR [r12+0x188],r13
    719221effd08:	movdqa xmm1,xmm10
    719221effd0d:	por    xmm2,xmm1
    719221effd11:	movdqu XMMWORD PTR [r12+0x150],xmm2
    719221effd1b:	movdqu xmm6,XMMWORD PTR [r12+0x140]
    719221effd25:	movdqa xmm1,xmm6
    719221effd29:	por    xmm3,xmm1
    719221effd2d:	movdqu XMMWORD PTR [r12+0x140],xmm3
    719221effd37:	movdqu xmm6,XMMWORD PTR [r12+0x110]
    719221effd41:	movdqa xmm1,xmm6
    719221effd45:	por    xmm4,xmm1
    719221effd49:	movdqu XMMWORD PTR [r12+0x110],xmm4
    719221effd53:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    719221effd5d:	movdqa xmm1,xmm6
    719221effd61:	por    xmm5,xmm1
    719221effd65:	movdqu XMMWORD PTR [r12+0x120],xmm5
    719221effd6f:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    719221effd79:	movdqa xmm1,xmm6
    719221effd7d:	por    xmm2,xmm1
    719221effd81:	movdqu XMMWORD PTR [r12+0x130],xmm2
    719221effd8b:	mov    r13,QWORD PTR [r12+0xf8]
    719221effd93:	mov    r14,r13
    719221effd96:	add    r14,0x20
    719221effd9a:	mov    r15,r14
    719221effd9d:	add    r15,0x10
    719221effda1:	movdqu XMMWORD PTR [r14],xmm4
    719221effda6:	mov    r14d,0x0
    719221effdac:	mov    DWORD PTR [r12+0x32c],r14d
    719221effdb4:	movdqu XMMWORD PTR [r15],xmm5
    719221effdb9:	mov    r14,r13
    719221effdbc:	add    r14,0x10
    719221effdc0:	movdqu XMMWORD PTR [r13+0x0],xmm3
    719221effdc6:	movdqu XMMWORD PTR [r14],xmm2
    719221effdcb:	mov    r14d,DWORD PTR [r13+0x0]
    719221effdcf:	mov    QWORD PTR [r12+0x60],r14
    719221effdd4:	jmp    0x719221effdd9
    719221effdd9:	mov    r13,QWORD PTR [r12+0x58]
    719221effdde:	mov    r14,QWORD PTR [r12+0x48]
    719221effde3:	add    r14,r13
    719221effde6:	mov    QWORD PTR [r12+0x68],r14
    719221effdeb:	add    r13,0x4
    719221effdef:	mov    QWORD PTR [r12+0x58],r13
    719221effdf4:	mov    r15,r14
    719221effdf7:	add    r15,0x4
    719221effdfb:	mov    eax,DWORD PTR [r15]
    719221effdfe:	mov    QWORD PTR [r12+0x70],rax
    719221effe03:	mov    r15,r14
    719221effe06:	add    r15,0x38
    719221effe0a:	mov    r8d,DWORD PTR [r15]
    719221effe0d:	mov    QWORD PTR [r12+0x78],r8
    719221effe12:	mov    r15,r14
    719221effe15:	add    r15,0x24
    719221effe19:	mov    r9d,DWORD PTR [r15]
    719221effe1c:	mov    QWORD PTR [r12+0x90],r9
    719221effe24:	sub    r13,0xc0
    719221effe2b:	setne  BYTE PTR [rsp+0xb8]
    719221effe33:	mov    r11,rax
    719221effe36:	lahf
    719221effe37:	seto   al
    719221effe3a:	mov    WORD PTR [rsp+0xb0],ax
    719221effe42:	mov    rax,r11
    719221effe45:	mov    r13d,DWORD PTR [r12+0x70]
    719221effe4a:	mov    r13d,r13d
    719221effe4d:	mov    r13d,r13d
    719221effe50:	ror    r13d,0x7
    719221effe54:	mov    QWORD PTR [r12+0x80],r13
    719221effe5c:	mov    r15d,r8d
    719221effe5f:	mov    r15d,r15d
    719221effe62:	ror    r15d,0x11
    719221effe66:	mov    QWORD PTR [r12+0x88],r15
    719221effe6e:	mov    ebp,DWORD PTR [r12+0x60]
    719221effe73:	add    r9d,ebp
    719221effe76:	mov    QWORD PTR [r12+0x60],r9
    719221effe7b:	mov    ebp,DWORD PTR [r12+0x70]
    719221effe80:	mov    ebp,ebp
    719221effe82:	mov    ebp,ebp
    719221effe84:	ror    ebp,0x12
    719221effe87:	xor    r13d,ebp
    719221effe8a:	mov    QWORD PTR [r12+0x80],r13
    719221effe92:	mov    ebp,r8d
    719221effe95:	mov    ebp,ebp
    719221effe97:	ror    ebp,0x13
    719221effe9a:	xor    r15d,ebp
    719221effe9d:	mov    QWORD PTR [r12+0x88],r15
    719221effea5:	mov    ebp,DWORD PTR [r12+0x70]
    719221effeaa:	mov    ebp,ebp
    719221effeac:	mov    ebp,ebp
    719221effeae:	shr    ebp,0x3
    719221effeb1:	xor    r13d,ebp
    719221effeb4:	mov    QWORD PTR [r12+0x80],r13
    719221effebc:	mov    r8d,r8d
    719221effebf:	shr    r8d,0xa
    719221effec3:	xor    r15d,r8d
    719221effec6:	mov    QWORD PTR [r12+0x78],r15
    719221effecb:	add    r9d,r13d
    719221effece:	mov    QWORD PTR [r12+0x60],r9
    719221effed3:	add    r9d,r15d
    719221effed6:	mov    QWORD PTR [r12+0x60],r9
    719221effedb:	add    r14,0x40
    719221effedf:	mov    DWORD PTR [r14],r9d
    719221effee2:	mov    r13d,0x0
    719221effee8:	mov    DWORD PTR [r12+0x32c],r13d
    719221effef0:	mov    r13d,0x0
    719221effef6:	mov    ecx,DWORD PTR [r12+0x70]
    719221effefb:	mov    ecx,ecx
    719221effefd:	mov    r14d,r13d
    719221efff00:	or     r14d,ecx
    719221efff03:	mov    QWORD PTR [r12+0x60],r14
    719221efff08:	mov    rcx,QWORD PTR [r12+0x380]
    719221efff10:	jrcxz  0x719221efff17
    719221efff12:	jmp    0x719221f006fa
    719221efff17:	cmp    BYTE PTR [rsp+0xb8],0x0
    719221efff1f:	jne    0x719221effdd9
    719221efff25:	jmp    0x719221efff2a
    719221efff2a:	mov    r13,QWORD PTR [r12]
    719221efff2e:	mov    r14,r13
    719221efff31:	add    r14,0x4
    719221efff35:	mov    r15d,DWORD PTR [r13+0x0]
    719221efff39:	mov    ebp,DWORD PTR [r14]
    719221efff3c:	mov    QWORD PTR [r12+0x78],r15
    719221efff41:	mov    QWORD PTR [r12+0x80],rbp
    719221efff49:	mov    r14,r13
    719221efff4c:	add    r14,0x8
    719221efff50:	mov    r8,r14
    719221efff53:	add    r8,0x4
    719221efff57:	mov    r9d,DWORD PTR [r14]
    719221efff5a:	mov    eax,DWORD PTR [r8]
    719221efff5d:	mov    QWORD PTR [rsp+0x90],rax
    719221efff65:	mov    QWORD PTR [r12+0x70],r9
    719221efff6a:	mov    rax,QWORD PTR [rsp+0x90]
    719221efff72:	mov    QWORD PTR [r12+0x68],rax
    719221efff77:	mov    r8,r13
    719221efff7a:	add    r8,0x18
    719221efff7e:	mov    r14,r8
    719221efff81:	add    r14,0x4
    719221efff85:	mov    eax,DWORD PTR [r8]
    719221efff88:	mov    QWORD PTR [rsp+0x98],rax
    719221efff90:	mov    r8d,DWORD PTR [r14]
    719221efff93:	mov    rax,QWORD PTR [rsp+0x98]
    719221efff9b:	mov    QWORD PTR [r12+0x58],rax
    719221efffa0:	mov    QWORD PTR [r12+0x60],r8
    719221efffa5:	add    r13,0x10
    719221efffa9:	mov    r14,r13
    719221efffac:	add    r14,0x4
    719221efffb0:	mov    eax,DWORD PTR [r13+0x0]
    719221efffb4:	mov    QWORD PTR [rsp+0xa0],rax
    719221efffbc:	mov    eax,DWORD PTR [r14]
    719221efffbf:	mov    QWORD PTR [rsp+0xa8],rax
    719221efffc7:	mov    rax,QWORD PTR [rsp+0xa0]
    719221efffcf:	mov    QWORD PTR [r12+0x18],rax
    719221efffd4:	mov    rax,QWORD PTR [rsp+0xa8]
    719221efffdc:	mov    QWORD PTR [r12+0x90],rax
    719221efffe4:	mov    r14d,0x0
    719221efffea:	mov    QWORD PTR [r12+0x88],r14
    719221effff2:	mov    r14d,0x0
    719221effff8:	mov    r13d,r14d
    719221effffb:	or     r13d,r15d
    719221effffe:	mov    QWORD PTR [r12+0xa8],r13
    719221f00006:	mov    r13d,0x0
    719221f0000c:	mov    r14d,r13d
    719221f0000f:	or     r14d,ebp
    719221f00012:	mov    QWORD PTR [r12+0x38],r14
    719221f00017:	mov    r13d,0x0
    719221f0001d:	mov    r14d,r13d
    719221f00020:	or     r14d,r9d
    719221f00023:	mov    QWORD PTR [r12+0x98],r14
    719221f0002b:	mov    r13d,0x0
    719221f00031:	mov    ecx,DWORD PTR [rsp+0x90]
    719221f00038:	mov    r14d,r13d
    719221f0003b:	or     r14d,ecx
    719221f0003e:	mov    QWORD PTR [r12+0x28],r14
    719221f00043:	mov    r13d,0x0
    719221f00049:	mov    r14d,r13d
    719221f0004c:	or     r14d,r8d
    719221f0004f:	mov    QWORD PTR [r12+0xb0],r14
    719221f00057:	mov    r13d,0x0
    719221f0005d:	mov    ecx,DWORD PTR [rsp+0x98]
    719221f00064:	mov    r14d,r13d
    719221f00067:	or     r14d,ecx
    719221f0006a:	mov    QWORD PTR [r12+0xc0],r14
    719221f00072:	mov    r13d,0x0
    719221f00078:	mov    ecx,DWORD PTR [rsp+0xa8]
    719221f0007f:	mov    r14d,r13d
    719221f00082:	or     r14d,ecx
    719221f00085:	mov    QWORD PTR [r12+0xc8],r14
    719221f0008d:	mov    r13d,0x0
    719221f00093:	mov    ecx,DWORD PTR [rsp+0xa0]
    719221f0009a:	mov    r14d,r13d
    719221f0009d:	or     r14d,ecx
    719221f000a0:	mov    QWORD PTR [r12+0xb8],r14
    719221f000a8:	jmp    0x719221f000ad
    719221f000ad:	mov    r13d,0x0
    719221f000b3:	mov    r14d,DWORD PTR [r12+0xb8]
    719221f000bb:	mov    eax,r13d
    719221f000be:	or     eax,r14d
    719221f000c1:	mov    QWORD PTR [r12+0x30],rax
    719221f000c6:	mov    r13d,0x0
    719221f000cc:	mov    ebp,DWORD PTR [r12+0xc0]
    719221f000d4:	mov    eax,r13d
    719221f000d7:	or     eax,ebp
    719221f000d9:	mov    QWORD PTR [r12+0xa0],rax
    719221f000e1:	mov    r13d,0x0
    719221f000e7:	mov    ebp,DWORD PTR [r12+0x28]
    719221f000ec:	mov    eax,r13d
    719221f000ef:	or     eax,ebp
    719221f000f1:	mov    QWORD PTR [r12+0xc0],rax
    719221f000f9:	mov    r13d,0x0
    719221f000ff:	mov    ebp,DWORD PTR [r12+0x98]
    719221f00107:	mov    eax,r13d
    719221f0010a:	or     eax,ebp
    719221f0010c:	mov    QWORD PTR [r12+0x28],rax
    719221f00111:	mov    r13d,0x0
    719221f00117:	mov    ebp,DWORD PTR [r12+0x38]
    719221f0011c:	mov    eax,r13d
    719221f0011f:	or     eax,ebp
    719221f00121:	mov    QWORD PTR [r12+0x98],rax
    719221f00129:	mov    r13d,0x0
    719221f0012f:	mov    ebp,DWORD PTR [r12+0xa8]
    719221f00137:	mov    eax,r13d
    719221f0013a:	or     eax,ebp
    719221f0013c:	mov    QWORD PTR [r12+0x38],rax
    719221f00141:	mov    r14d,r14d
    719221f00144:	ror    r14d,0x6
    719221f00148:	mov    QWORD PTR [r12+0xb8],r14
    719221f00150:	mov    r13d,DWORD PTR [r12+0xc8]
    719221f00158:	mov    ebp,DWORD PTR [r12+0x30]
    719221f0015d:	mov    ebp,ebp
    719221f0015f:	and    ebp,r13d
    719221f00162:	mov    QWORD PTR [r12+0xa8],rbp
    719221f0016a:	mov    r9d,DWORD PTR [r12+0x38]
    719221f0016f:	mov    r9d,r9d
    719221f00172:	mov    r9d,r9d
    719221f00175:	ror    r9d,0x2
    719221f00179:	mov    QWORD PTR [r12+0xd0],r9
    719221f00181:	mov    r15d,0x0
    719221f00187:	mov    eax,r15d
    719221f0018a:	or     eax,r13d
    719221f0018d:	mov    QWORD PTR [r12+0x20],rax
    719221f00192:	mov    rax,QWORD PTR [r12+0x88]
    719221f0019a:	mov    r15,QWORD PTR [r12+0x50]
    719221f0019f:	mov    rcx,QWORD PTR [r12+0x88]
    719221f001a7:	add    r15,rcx
    719221f001aa:	mov    r13d,DWORD PTR [r15]
    719221f001ad:	mov    QWORD PTR [r12+0xc8],r13
    719221f001b5:	mov    ecx,DWORD PTR [r12+0x30]
    719221f001ba:	mov    ecx,ecx
    719221f001bc:	mov    r15d,DWORD PTR [r12+0xa0]
    719221f001c4:	mov    r15d,r15d
    719221f001c7:	not    rcx
    719221f001ca:	and    r15d,ecx
    719221f001cd:	mov    QWORD PTR [r12+0xd8],r15
    719221f001d5:	mov    r8d,DWORD PTR [r12+0xb0]
    719221f001dd:	add    ebp,r8d
    719221f001e0:	mov    QWORD PTR [r12+0xa8],rbp
    719221f001e8:	mov    r8d,DWORD PTR [r12+0x30]
    719221f001ed:	mov    r8d,r8d
    719221f001f0:	mov    r8d,r8d
    719221f001f3:	ror    r8d,0xb
    719221f001f7:	xor    r14d,r8d
    719221f001fa:	mov    QWORD PTR [r12+0xb0],r14
    719221f00202:	mov    r8d,DWORD PTR [r12+0x38]
    719221f00207:	mov    r8d,r8d
    719221f0020a:	mov    r8d,r8d
    719221f0020d:	ror    r8d,0xd
    719221f00211:	xor    r9d,r8d
    719221f00214:	mov    QWORD PTR [r12+0xd0],r9
    719221f0021c:	add    ebp,r15d
    719221f0021f:	mov    QWORD PTR [r12+0xa8],rbp
    719221f00227:	mov    r15,QWORD PTR [r12+0x48]
    719221f0022c:	mov    rcx,QWORD PTR [r12+0x88]
    719221f00234:	add    r15,rcx
    719221f00237:	mov    r8d,DWORD PTR [r15]
    719221f0023a:	mov    QWORD PTR [r12+0xb8],r8
    719221f00242:	mov    ecx,DWORD PTR [r12+0x98]
    719221f0024a:	mov    ecx,ecx
    719221f0024c:	mov    eax,DWORD PTR [r12+0x28]
    719221f00251:	mov    eax,eax
    719221f00253:	and    eax,ecx
    719221f00255:	mov    QWORD PTR [r12+0xd8],rax
    719221f0025d:	add    ebp,r13d
    719221f00260:	mov    QWORD PTR [r12+0xa8],rbp
    719221f00268:	mov    ecx,DWORD PTR [r12+0x98]
    719221f00270:	mov    ecx,ecx
    719221f00272:	mov    r13d,DWORD PTR [r12+0x28]
    719221f00277:	mov    r13d,r13d
    719221f0027a:	xor    r13d,ecx
    719221f0027d:	mov    QWORD PTR [r12+0xc8],r13
    719221f00285:	mov    r15d,DWORD PTR [r12+0x30]
    719221f0028a:	mov    r15d,r15d
    719221f0028d:	mov    r15d,r15d
    719221f00290:	ror    r15d,0x19
    719221f00294:	xor    r14d,r15d
    719221f00297:	mov    QWORD PTR [r12+0xb0],r14
    719221f0029f:	mov    ecx,DWORD PTR [r12+0x38]
    719221f002a4:	mov    ecx,ecx
    719221f002a6:	and    r13d,ecx
    719221f002a9:	mov    QWORD PTR [r12+0xc8],r13
    719221f002b1:	mov    r15d,DWORD PTR [r12+0x38]
    719221f002b6:	mov    r15d,r15d
    719221f002b9:	mov    r15d,r15d
    719221f002bc:	ror    r15d,0x16
    719221f002c0:	xor    r9d,r15d
    719221f002c3:	mov    QWORD PTR [r12+0xd0],r9
    719221f002cb:	add    ebp,r8d
    719221f002ce:	mov    QWORD PTR [r12+0xa8],rbp
    719221f002d6:	mov    ecx,DWORD PTR [r12+0xd8]
    719221f002de:	mov    ecx,ecx
    719221f002e0:	xor    r13d,ecx
    719221f002e3:	mov    QWORD PTR [r12+0xb8],r13
    719221f002eb:	add    ebp,r14d
    719221f002ee:	mov    QWORD PTR [r12+0xa8],rbp
    719221f002f6:	mov    r14,QWORD PTR [r12+0x88]
    719221f002fe:	add    r14,0x4
    719221f00302:	mov    QWORD PTR [r12+0x88],r14
    719221f0030a:	add    r13d,r9d
    719221f0030d:	mov    QWORD PTR [r12+0xb0],r13
    719221f00315:	mov    ecx,DWORD PTR [r12+0xc0]
    719221f0031d:	mov    ecx,ecx
    719221f0031f:	mov    r15d,ebp
    719221f00322:	add    r15d,ecx
    719221f00325:	mov    QWORD PTR [r12+0xb8],r15
    719221f0032d:	sub    r14,0x100
    719221f00334:	setne  BYTE PTR [rsp+0xb8]
    719221f0033c:	mov    r11,rax
    719221f0033f:	lahf
    719221f00340:	seto   al
    719221f00343:	mov    WORD PTR [rsp+0xb0],ax
    719221f0034b:	mov    rax,r11
    719221f0034e:	add    r13d,ebp
    719221f00351:	mov    QWORD PTR [r12+0xa8],r13
    719221f00359:	mov    r13d,0x0
    719221f0035f:	mov    ecx,DWORD PTR [r12+0xa0]
    719221f00367:	mov    ecx,ecx
    719221f00369:	mov    r14d,r13d
    719221f0036c:	or     r14d,ecx
    719221f0036f:	mov    QWORD PTR [r12+0xb0],r14
    719221f00377:	mov    r13d,0x0
    719221f0037d:	mov    ecx,DWORD PTR [r12+0x20]
    719221f00382:	mov    ecx,ecx
    719221f00384:	mov    r14d,r13d
    719221f00387:	or     r14d,ecx
    719221f0038a:	mov    QWORD PTR [r12+0xc0],r14
    719221f00392:	mov    r13d,0x0
    719221f00398:	mov    ecx,DWORD PTR [r12+0x30]
    719221f0039d:	mov    ecx,ecx
    719221f0039f:	mov    r14d,r13d
    719221f003a2:	or     r14d,ecx
    719221f003a5:	mov    QWORD PTR [r12+0xc8],r14
    719221f003ad:	mov    rcx,QWORD PTR [r12+0x380]
    719221f003b5:	jrcxz  0x719221f003bc
    719221f003b7:	jmp    0x719221f00782
    719221f003bc:	cmp    BYTE PTR [rsp+0xb8],0x0
    719221f003c4:	jne    0x719221f000ad
    719221f003ca:	jmp    0x719221f003cf
    719221f003cf:	mov    r13d,DWORD PTR [r12+0x70]
    719221f003d4:	mov    r14d,DWORD PTR [r12+0x98]
    719221f003dc:	add    r14d,r13d
    719221f003df:	mov    QWORD PTR [r12+0x70],r14
    719221f003e4:	mov    r13d,DWORD PTR [r12+0x68]
    719221f003e9:	mov    r15d,DWORD PTR [r12+0x28]
    719221f003ee:	add    r15d,r13d
    719221f003f1:	mov    QWORD PTR [r12+0x68],r15
    719221f003f6:	mov    r13d,0x0
    719221f003fc:	mov    QWORD PTR [r12+0x88],r13
    719221f00404:	mov    r13d,DWORD PTR [r12+0x78]
    719221f00409:	mov    ebp,DWORD PTR [r12+0xa8]
    719221f00411:	add    ebp,r13d
    719221f00414:	mov    QWORD PTR [r12+0x78],rbp
    719221f00419:	mov    r13d,DWORD PTR [r12+0x80]
    719221f00421:	mov    r8d,DWORD PTR [r12+0x38]
    719221f00426:	add    r8d,r13d
    719221f00429:	mov    QWORD PTR [r12+0x80],r8
    719221f00431:	mov    rax,QWORD PTR [r12]
    719221f00435:	mov    r9,QWORD PTR [r12]
    719221f00439:	add    r9,0x8
    719221f0043d:	mov    r13,r9
    719221f00440:	add    r13,0x4
    719221f00444:	mov    DWORD PTR [r9],r14d
    719221f00447:	mov    r14d,0x0
    719221f0044d:	mov    DWORD PTR [r12+0x32c],r14d
    719221f00455:	mov    DWORD PTR [r13+0x0],r15d
    719221f00459:	mov    r13d,DWORD PTR [r12+0x18]
    719221f0045e:	mov    r14d,DWORD PTR [r12+0xb8]
    719221f00466:	add    r14d,r13d
    719221f00469:	mov    QWORD PTR [r12+0x68],r14
    719221f0046e:	mov    r13d,DWORD PTR [r12+0x90]
    719221f00476:	mov    r15d,DWORD PTR [r12+0x30]
    719221f0047b:	add    r15d,r13d
    719221f0047e:	mov    QWORD PTR [r12+0x70],r15
    719221f00483:	mov    r13d,DWORD PTR [r12+0x58]
    719221f00488:	mov    r9d,DWORD PTR [r12+0x20]
    719221f0048d:	mov    eax,r9d
    719221f00490:	add    eax,r13d
    719221f00493:	mov    QWORD PTR [r12+0x58],rax
    719221f00498:	mov    r13d,DWORD PTR [r12+0x60]
    719221f0049d:	mov    r9d,DWORD PTR [r12+0xa0]
    719221f004a5:	add    r9d,r13d
    719221f004a8:	mov    QWORD PTR [r12+0x60],r9
    719221f004ad:	mov    r13,QWORD PTR [r12]
    719221f004b1:	add    r13,0x4
    719221f004b5:	mov    rdi,QWORD PTR [r12]
    719221f004b9:	mov    DWORD PTR [rdi],ebp
    719221f004bb:	mov    DWORD PTR [r13+0x0],r8d
    719221f004bf:	mov    r13,QWORD PTR [r12]
    719221f004c3:	add    r13,0x10
    719221f004c7:	mov    rbp,r13
    719221f004ca:	add    rbp,0x4
    719221f004ce:	mov    DWORD PTR [r13+0x0],r14d
    719221f004d2:	mov    DWORD PTR [rbp+0x0],r15d
    719221f004d6:	mov    r13,QWORD PTR [r12]
    719221f004da:	add    r13,0x18
    719221f004de:	mov    r14,r13
    719221f004e1:	add    r14,0x4
    719221f004e5:	mov    eax,DWORD PTR [r12+0x58]
    719221f004ea:	mov    DWORD PTR [r13+0x0],eax
    719221f004ee:	mov    DWORD PTR [r14],r9d
    719221f004f1:	mov    r13,QWORD PTR [r12]
    719221f004f5:	add    r13,0x68
    719221f004f9:	mov    r14d,0x0
    719221f004ff:	mov    QWORD PTR [r13+0x0],r14
    719221f00503:	mov    rcx,QWORD PTR [r12+0x380]
    719221f0050b:	jrcxz  0x719221f00512
    719221f0050d:	jmp    0x719221f0080a
    719221f00512:	jmp    0x719221f00517
    719221f00517:	mov    r13,QWORD PTR [r12+0x10]
    719221f0051c:	sub    r13,0x1
    719221f00520:	mov    QWORD PTR [r12+0x10],r13
    719221f00525:	mov    rax,r13
    719221f00528:	test   rax,rax
    719221f0052b:	je     0x719221f00536
    719221f00531:	jmp    0x719221efe63a
    719221f00536:	mov    r13,QWORD PTR [r12+0xf8]
    719221f0053e:	mov    r14,r13
    719221f00541:	add    r14,0x140
    719221f00548:	mov    r15,r14
    719221f0054b:	add    r15,0x8
    719221f0054f:	mov    rbp,QWORD PTR [r14]
    719221f00552:	mov    r14,QWORD PTR [r15]
    719221f00555:	mov    QWORD PTR [r12+0xa0],rbp
    719221f0055d:	mov    QWORD PTR [r12+0x98],r14
    719221f00565:	mov    r14,r13
    719221f00568:	add    r14,0x130
    719221f0056f:	mov    r15,r14
    719221f00572:	add    r15,0x8
    719221f00576:	mov    rbp,QWORD PTR [r14]
    719221f00579:	mov    r14,QWORD PTR [r15]
    719221f0057c:	mov    QWORD PTR [r12+0xb0],rbp
    719221f00584:	mov    QWORD PTR [r12+0xa8],r14
    719221f0058c:	mov    r14,r13
    719221f0058f:	add    r14,0x120
    719221f00596:	mov    r15,r14
    719221f00599:	add    r15,0x8
    719221f0059d:	mov    rbp,QWORD PTR [r14]
    719221f005a0:	mov    r14,QWORD PTR [r15]
    719221f005a3:	mov    QWORD PTR [r12+0xc0],rbp
    719221f005ab:	mov    QWORD PTR [r12+0xb8],r14
    719221f005b3:	mov    r14,r13
    719221f005b6:	add    r14,0x110
    719221f005bd:	mov    r15,r14
    719221f005c0:	add    r15,0x8
    719221f005c4:	mov    rbp,QWORD PTR [r14]
    719221f005c7:	mov    r14,QWORD PTR [r15]
    719221f005ca:	mov    QWORD PTR [r12+0xd0],rbp
    719221f005d2:	mov    QWORD PTR [r12+0xc8],r14
    719221f005da:	mov    r14,r13
    719221f005dd:	add    r14,0x100
    719221f005e4:	mov    r15,r14
    719221f005e7:	add    r15,0x8
    719221f005eb:	mov    rbp,QWORD PTR [r14]
    719221f005ee:	mov    r14,QWORD PTR [r15]
    719221f005f1:	mov    QWORD PTR [r12+0xe8],rbp
    719221f005f9:	mov    QWORD PTR [r12+0xd8],r14
    719221f00601:	add    r13,0x150
    719221f00608:	mov    QWORD PTR [r12+0xf8],r13
    719221f00610:	jmp    0x719221f00615
    719221f00615:	mov    rcx,QWORD PTR [r12+0x380]
    719221f0061d:	jrcxz  0x719221f00624
    719221f0061f:	jmp    0x719221f00892
    719221f00624:	mov    r13,QWORD PTR [r12+0xf0]
    719221f0062c:	mov    QWORD PTR [r12+0x100],r13
    719221f00634:	mov    r11,QWORD PTR [rsp+0xb0]
    719221f0063c:	mov    QWORD PTR [r12+0x398],r11
    719221f00644:	mov    rdi,QWORD PTR [r12+0x100]
    719221f0064c:	add    rsp,0xc0
    719221f00653:	movabs r11,0x64862955b940
    719221f0065d:	jmp    r11
    719221f00660:	mov    eax,0x41039c
    719221f00665:	mov    QWORD PTR [r12+0x100],rax
    719221f0066d:	push   rdx
    719221f0066e:	push   rsi
    719221f0066f:	push   r10
    719221f00671:	push   r11
    719221f00673:	mov    r11,rax
    719221f00676:	lahf
    719221f00677:	seto   al
    719221f0067a:	mov    WORD PTR [rsp+0xd0],ax
    719221f00682:	mov    rax,r11
    719221f00685:	mov    rdx,QWORD PTR [rsp+0xd0]
    719221f0068d:	mov    r10d,edx
    719221f00690:	and    r10d,0xc000
    719221f00697:	shl    r10d,0x10
    719221f0069b:	mov    r11d,edx
    719221f0069e:	and    r11d,0x100
    719221f006a5:	shl    r11d,0x15
    719221f006a9:	or     r10d,r11d
    719221f006ac:	and    edx,0x1
    719221f006af:	shl    edx,0x1c
    719221f006b2:	or     r10d,edx
    719221f006b5:	btc    r10,0x1d
    719221f006ba:	mov    r11d,0xf0000000
    719221f006c0:	and    r11,r10
    719221f006c3:	movabs rsi,0xffffffff0fffffff
    719221f006cd:	and    rbx,rsi
    719221f006d0:	or     rbx,r11
    719221f006d3:	pop    r11
    719221f006d5:	pop    r10
    719221f006d7:	pop    rsi
    719221f006d8:	pop    rdx
    719221f006d9:	mov    QWORD PTR [r12+0x108],rbx
    719221f006e1:	add    rsp,0xc0
    719221f006e8:	mov    eax,0xc
    719221f006ed:	movabs r11,0x64862955bca0
    719221f006f7:	jmp    r11
    719221f006fa:	mov    eax,0x410498
    719221f006ff:	mov    QWORD PTR [r12+0x100],rax
    719221f00707:	push   rdx
    719221f00708:	push   rsi
    719221f00709:	push   r10
    719221f0070b:	push   r11
    719221f0070d:	mov    rdx,QWORD PTR [rsp+0xd0]
    719221f00715:	mov    r10d,edx
    719221f00718:	and    r10d,0xc000
    719221f0071f:	shl    r10d,0x10
    719221f00723:	mov    r11d,edx
    719221f00726:	and    r11d,0x100
    719221f0072d:	shl    r11d,0x15
    719221f00731:	or     r10d,r11d
    719221f00734:	and    edx,0x1
    719221f00737:	shl    edx,0x1c
    719221f0073a:	or     r10d,edx
    719221f0073d:	btc    r10,0x1d
    719221f00742:	mov    r11d,0xf0000000
    719221f00748:	and    r11,r10
    719221f0074b:	movabs rsi,0xffffffff0fffffff
    719221f00755:	and    rbx,rsi
    719221f00758:	or     rbx,r11
    719221f0075b:	pop    r11
    719221f0075d:	pop    r10
    719221f0075f:	pop    rsi
    719221f00760:	pop    rdx
    719221f00761:	mov    QWORD PTR [r12+0x108],rbx
    719221f00769:	add    rsp,0xc0
    719221f00770:	mov    eax,0xc
    719221f00775:	movabs r11,0x64862955bca0
    719221f0077f:	jmp    r11
    719221f00782:	mov    eax,0x410558
    719221f00787:	mov    QWORD PTR [r12+0x100],rax
    719221f0078f:	push   rdx
    719221f00790:	push   rsi
    719221f00791:	push   r10
    719221f00793:	push   r11
    719221f00795:	mov    rdx,QWORD PTR [rsp+0xd0]
    719221f0079d:	mov    r10d,edx
    719221f007a0:	and    r10d,0xc000
    719221f007a7:	shl    r10d,0x10
    719221f007ab:	mov    r11d,edx
    719221f007ae:	and    r11d,0x100
    719221f007b5:	shl    r11d,0x15
    719221f007b9:	or     r10d,r11d
    719221f007bc:	and    edx,0x1
    719221f007bf:	shl    edx,0x1c
    719221f007c2:	or     r10d,edx
    719221f007c5:	btc    r10,0x1d
    719221f007ca:	mov    r11d,0xf0000000
    719221f007d0:	and    r11,r10
    719221f007d3:	movabs rsi,0xffffffff0fffffff
    719221f007dd:	and    rbx,rsi
    719221f007e0:	or     rbx,r11
    719221f007e3:	pop    r11
    719221f007e5:	pop    r10
    719221f007e7:	pop    rsi
    719221f007e8:	pop    rdx
    719221f007e9:	mov    QWORD PTR [r12+0x108],rbx
    719221f007f1:	add    rsp,0xc0
    719221f007f8:	mov    eax,0xc
    719221f007fd:	movabs r11,0x64862955bca0
    719221f00807:	jmp    r11
    719221f0080a:	mov    eax,0x410594
    719221f0080f:	mov    QWORD PTR [r12+0x100],rax
    719221f00817:	push   rdx
    719221f00818:	push   rsi
    719221f00819:	push   r10
    719221f0081b:	push   r11
    719221f0081d:	mov    rdx,QWORD PTR [rsp+0xd0]
    719221f00825:	mov    r10d,edx
    719221f00828:	and    r10d,0xc000
    719221f0082f:	shl    r10d,0x10
    719221f00833:	mov    r11d,edx
    719221f00836:	and    r11d,0x100
    719221f0083d:	shl    r11d,0x15
    719221f00841:	or     r10d,r11d
    719221f00844:	and    edx,0x1
    719221f00847:	shl    edx,0x1c
    719221f0084a:	or     r10d,edx
    719221f0084d:	btc    r10,0x1d
    719221f00852:	mov    r11d,0xf0000000
    719221f00858:	and    r11,r10
    719221f0085b:	movabs rsi,0xffffffff0fffffff
    719221f00865:	and    rbx,rsi
    719221f00868:	or     rbx,r11
    719221f0086b:	pop    r11
    719221f0086d:	pop    r10
    719221f0086f:	pop    rsi
    719221f00870:	pop    rdx
    719221f00871:	mov    QWORD PTR [r12+0x108],rbx
    719221f00879:	add    rsp,0xc0
    719221f00880:	mov    eax,0xc
    719221f00885:	movabs r11,0x64862955bca0
    719221f0088f:	jmp    r11
    719221f00892:	mov    eax,0x4105b0
    719221f00897:	mov    QWORD PTR [r12+0x100],rax
    719221f0089f:	push   rdx
    719221f008a0:	push   rsi
    719221f008a1:	push   r10
    719221f008a3:	push   r11
    719221f008a5:	mov    rdx,QWORD PTR [rsp+0xd0]
    719221f008ad:	mov    r10d,edx
    719221f008b0:	and    r10d,0xc000
    719221f008b7:	shl    r10d,0x10
    719221f008bb:	mov    r11d,edx
    719221f008be:	and    r11d,0x100
    719221f008c5:	shl    r11d,0x15
    719221f008c9:	or     r10d,r11d
    719221f008cc:	and    edx,0x1
    719221f008cf:	shl    edx,0x1c
    719221f008d2:	or     r10d,edx
    719221f008d5:	btc    r10,0x1d
    719221f008da:	mov    r11d,0xf0000000
    719221f008e0:	and    r11,r10
    719221f008e3:	movabs rsi,0xffffffff0fffffff
    719221f008ed:	and    rbx,rsi
    719221f008f0:	or     rbx,r11
    719221f008f3:	pop    r11
    719221f008f5:	pop    r10
    719221f008f7:	pop    rsi
    719221f008f8:	pop    rdx
    719221f008f9:	mov    QWORD PTR [r12+0x108],rbx
    719221f00901:	add    rsp,0xc0
    719221f00908:	mov    eax,0xc
    719221f0090d:	movabs r11,0x64862955bca0
    719221f00917:	jmp    r11
    719221f0091a:	nop    WORD PTR [rax+rax*1+0x0]
    719221f00920:	sub    rsp,0xc0
    719221f00927:	mov    r11,QWORD PTR [r12+0x398]
    719221f0092f:	mov    QWORD PTR [rsp+0xb0],r11
    719221f00937:	jmp    0x719221efe519
    719221f0093c:	nop    DWORD PTR [rax+0x0]
    719221f00940:	sub    rsp,0xc0
    719221f00947:	mov    r11,QWORD PTR [r12+0x398]
    719221f0094f:	mov    QWORD PTR [rsp+0xb0],r11
    719221f00957:	jmp    0x719221efe63a
    719221f0095c:	nop    DWORD PTR [rax+0x0]
    719221f00960:	sub    rsp,0xc0
    719221f00967:	mov    r11,QWORD PTR [r12+0x398]
    719221f0096f:	mov    QWORD PTR [rsp+0xb0],r11
    719221f00977:	jmp    0x719221efe6f4
    719221f0097c:	nop    DWORD PTR [rax+0x0]
    719221f00980:	sub    rsp,0xc0
    719221f00987:	mov    r11,QWORD PTR [r12+0x398]
    719221f0098f:	mov    QWORD PTR [rsp+0xb0],r11
    719221f00997:	jmp    0x719221effdd9
    719221f0099c:	nop    DWORD PTR [rax+0x0]
    719221f009a0:	sub    rsp,0xc0
    719221f009a7:	mov    r11,QWORD PTR [r12+0x398]
    719221f009af:	mov    QWORD PTR [rsp+0xb0],r11
    719221f009b7:	jmp    0x719221efff2a
    719221f009bc:	nop    DWORD PTR [rax+0x0]
    719221f009c0:	sub    rsp,0xc0
    719221f009c7:	mov    r11,QWORD PTR [r12+0x398]
    719221f009cf:	mov    QWORD PTR [rsp+0xb0],r11
    719221f009d7:	jmp    0x719221f000ad
    719221f009dc:	nop    DWORD PTR [rax+0x0]
    719221f009e0:	sub    rsp,0xc0
    719221f009e7:	mov    r11,QWORD PTR [r12+0x398]
    719221f009ef:	mov    QWORD PTR [rsp+0xb0],r11
    719221f009f7:	jmp    0x719221f003cf
    719221f009fc:	nop    DWORD PTR [rax+0x0]
    719221f00a00:	sub    rsp,0xc0
    719221f00a07:	mov    r11,QWORD PTR [r12+0x398]
    719221f00a0f:	mov    QWORD PTR [rsp+0xb0],r11
    719221f00a17:	jmp    0x719221f00517
    719221f00a1c:	nop    DWORD PTR [rax+0x0]
    719221f00a20:	sub    rsp,0xc0
    719221f00a27:	mov    r11,QWORD PTR [r12+0x398]
    719221f00a2f:	mov    QWORD PTR [rsp+0xb0],r11
    719221f00a37:	jmp    0x719221f00536
    719221f00a3c:	nop    DWORD PTR [rax+0x0]
    719221f00a40:	sub    rsp,0xc0
    719221f00a47:	mov    r11,QWORD PTR [r12+0x398]
    719221f00a4f:	mov    QWORD PTR [rsp+0xb0],r11
    719221f00a57:	jmp    0x719221f00615
