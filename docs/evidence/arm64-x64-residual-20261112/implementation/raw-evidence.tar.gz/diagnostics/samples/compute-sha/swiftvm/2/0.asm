
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

0000719221efe000 <.data>:
    719221efe000:	sub    rsp,0x10
    719221efe004:	mov    r11,QWORD PTR [r12+0x398]
    719221efe00c:	mov    QWORD PTR [rsp],r11
    719221efe010:	mov    r13,QWORD PTR [r12+0xf8]
    719221efe018:	sub    r13,0xa0
    719221efe01f:	mov    QWORD PTR [r12+0xf8],r13
    719221efe027:	mov    r14d,0x420000
    719221efe02d:	mov    QWORD PTR [r12+0x40],r14
    719221efe032:	mov    r14d,0x420000
    719221efe038:	mov    QWORD PTR [r12+0x48],r14
    719221efe03d:	mov    r14,r13
    719221efe040:	add    r14,0x90
    719221efe047:	mov    r15,r14
    719221efe04a:	add    r15,0x8
    719221efe04e:	mov    rbp,QWORD PTR [r12+0xa0]
    719221efe056:	mov    r8,QWORD PTR [r12+0x98]
    719221efe05e:	mov    QWORD PTR [r14],rbp
    719221efe061:	mov    r14d,0x0
    719221efe067:	mov    DWORD PTR [r12+0x32c],r14d
    719221efe06f:	mov    QWORD PTR [r15],r8
    719221efe072:	mov    r14d,0x420670
    719221efe078:	movdqu xmm2,XMMWORD PTR [r14]
    719221efe07d:	movdqu XMMWORD PTR [r12+0x110],xmm2
    719221efe087:	mov    r14d,0x420610
    719221efe08d:	movdqu xmm3,XMMWORD PTR [r14]
    719221efe092:	movdqu XMMWORD PTR [r12+0x120],xmm3
    719221efe09c:	mov    r14d,0x420690
    719221efe0a2:	movdqu xmm4,XMMWORD PTR [r14]
    719221efe0a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
    719221efe0b1:	mov    r14d,0x420630
    719221efe0b7:	movdqu xmm5,XMMWORD PTR [r14]
    719221efe0bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
    719221efe0c6:	mov    r14d,0x430000
    719221efe0cc:	add    r14,0x8a0
    719221efe0d3:	mov    QWORD PTR [r12+0x98],r14
    719221efe0db:	mov    r15d,0x4206a0
    719221efe0e1:	movdqu xmm6,XMMWORD PTR [r15]
    719221efe0e6:	movdqu XMMWORD PTR [r12+0x150],xmm6
    719221efe0f0:	mov    r15,r14
    719221efe0f3:	add    r15,0x10
    719221efe0f7:	movdqu XMMWORD PTR [r14],xmm2
    719221efe0fc:	movdqu XMMWORD PTR [r15],xmm3
    719221efe101:	mov    r15,r14
    719221efe104:	add    r15,0x20
    719221efe108:	mov    rbp,r15
    719221efe10b:	add    rbp,0x10
    719221efe10f:	movdqu XMMWORD PTR [r15],xmm4
    719221efe114:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    719221efe119:	mov    r15d,0x420600
    719221efe11f:	movdqu xmm4,XMMWORD PTR [r15]
    719221efe124:	movdqu XMMWORD PTR [r12+0x130],xmm4
    719221efe12e:	mov    r15d,0x4205f0
    719221efe134:	movdqu xmm5,XMMWORD PTR [r15]
    719221efe139:	movdqu XMMWORD PTR [r12+0x140],xmm5
    719221efe143:	mov    r15,r14
    719221efe146:	add    r15,0x100
    719221efe14d:	mov    rbp,r15
    719221efe150:	add    rbp,0x10
    719221efe154:	movdqu XMMWORD PTR [r15],xmm2
    719221efe159:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    719221efe15e:	mov    r15,r14
    719221efe161:	add    r15,0x40
    719221efe165:	mov    rbp,r15
    719221efe168:	add    rbp,0x10
    719221efe16c:	movdqu XMMWORD PTR [r15],xmm6
    719221efe171:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    719221efe176:	mov    r15d,0x4205e0
    719221efe17c:	movdqu xmm2,XMMWORD PTR [r15]
    719221efe181:	movdqu XMMWORD PTR [r12+0x130],xmm2
    719221efe18b:	mov    r15d,0x420640
    719221efe191:	movdqu xmm3,XMMWORD PTR [r15]
    719221efe196:	movdqu XMMWORD PTR [r12+0x150],xmm3
    719221efe1a0:	mov    r15d,0xf8d3
    719221efe1a6:	mov    QWORD PTR [r12+0x48],r15
    719221efe1ab:	mov    r15,r14
    719221efe1ae:	add    r15,0x60
    719221efe1b2:	mov    rbp,r15
    719221efe1b5:	add    rbp,0x10
    719221efe1b9:	movdqu XMMWORD PTR [r15],xmm5
    719221efe1be:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    719221efe1c3:	mov    r15d,0x420650
    719221efe1c9:	movdqu xmm2,XMMWORD PTR [r15]
    719221efe1ce:	movdqu XMMWORD PTR [r12+0x130],xmm2
    719221efe1d8:	mov    r15d,0x420620
    719221efe1de:	movdqu xmm4,XMMWORD PTR [r15]
    719221efe1e3:	movdqu XMMWORD PTR [r12+0x140],xmm4
    719221efe1ed:	mov    r15d,0xf8d3
    719221efe1f3:	mov    ebp,0x421d
    719221efe1f8:	and    ebp,0xffff
    719221efe1fe:	mov    rax,r15
    719221efe201:	movabs rcx,0xffffffff0000ffff
    719221efe20b:	and    rax,rcx
    719221efe20e:	mov    rdx,rbp
    719221efe211:	shl    rdx,0x10
    719221efe215:	mov    ecx,0xffff0000
    719221efe21a:	and    rdx,rcx
    719221efe21d:	or     rax,rdx
    719221efe220:	mov    r8d,eax
    719221efe223:	mov    QWORD PTR [r12+0x48],r8
    719221efe228:	mov    r15,r14
    719221efe22b:	add    r15,0x80
    719221efe232:	mov    rbp,r15
    719221efe235:	add    rbp,0x10
    719221efe239:	movdqu XMMWORD PTR [r15],xmm3
    719221efe23e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    719221efe243:	mov    r15d,0x4206c0
    719221efe249:	movdqu xmm2,XMMWORD PTR [r15]
    719221efe24e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    719221efe258:	mov    r15d,0x4206d0
    719221efe25e:	movdqu xmm3,XMMWORD PTR [r15]
    719221efe263:	movdqu XMMWORD PTR [r12+0x150],xmm3
    719221efe26d:	mov    r15d,0x3e8
    719221efe273:	mov    QWORD PTR [r12+0xa0],r15
    719221efe27b:	mov    r15,r14
    719221efe27e:	add    r15,0xa0
    719221efe285:	mov    rbp,r15
    719221efe288:	add    rbp,0x10
    719221efe28c:	movdqu XMMWORD PTR [r15],xmm4
    719221efe291:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    719221efe296:	mov    r15d,0x4206b0
    719221efe29c:	movdqu xmm2,XMMWORD PTR [r15]
    719221efe2a1:	movdqu XMMWORD PTR [r12+0x130],xmm2
    719221efe2ab:	mov    r15d,0x420660
    719221efe2b1:	movdqu xmm4,XMMWORD PTR [r15]
    719221efe2b6:	movdqu XMMWORD PTR [r12+0x140],xmm4
    719221efe2c0:	mov    r15,r13
    719221efe2c3:	add    r15,0x80
    719221efe2ca:	mov    rbp,QWORD PTR [r12+0xf0]
    719221efe2d2:	mov    QWORD PTR [r15],rbp
    719221efe2d5:	mov    r15,r14
    719221efe2d8:	add    r15,0xc0
    719221efe2df:	mov    rbp,r15
    719221efe2e2:	add    rbp,0x10
    719221efe2e6:	movdqu XMMWORD PTR [r15],xmm3
    719221efe2eb:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    719221efe2f0:	mov    r15d,0x420680
    719221efe2f6:	movdqu xmm2,XMMWORD PTR [r15]
    719221efe2fb:	movdqu XMMWORD PTR [r12+0x130],xmm2
    719221efe305:	mov    r15d,0x4206e0
    719221efe30b:	mov    rbp,QWORD PTR [r15]
    719221efe30e:	mov    r15d,0x0
    719221efe314:	mov    QWORD PTR [r12+0x110],rbp
    719221efe31c:	mov    QWORD PTR [r12+0x118],r15
    719221efe324:	mov    r15d,0x4206e8
    719221efe32a:	mov    QWORD PTR [r12+0x40],r15
    719221efe32f:	mov    r15,r14
    719221efe332:	add    r15,0xe0
    719221efe339:	mov    r9,r15
    719221efe33c:	add    r9,0x10
    719221efe340:	movdqu XMMWORD PTR [r15],xmm4
    719221efe345:	movdqu XMMWORD PTR [r9],xmm2
    719221efe34a:	mov    r15d,0x420748
    719221efe350:	movdqu xmm2,XMMWORD PTR [r15]
    719221efe355:	movdqu XMMWORD PTR [r12+0x130],xmm2
    719221efe35f:	mov    r15,r14
    719221efe362:	add    r15,0x120
    719221efe369:	mov    QWORD PTR [r15],rbp
    719221efe36c:	mov    r15d,0x420728
    719221efe372:	mov    ebp,0x420738
    719221efe377:	movdqu xmm3,XMMWORD PTR [r15]
    719221efe37c:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    719221efe381:	movdqu XMMWORD PTR [r12+0x120],xmm3
    719221efe38b:	movdqu XMMWORD PTR [r12+0x110],xmm4
    719221efe395:	mov    r15,r13
    719221efe398:	add    r15,0x60
    719221efe39c:	movdqu XMMWORD PTR [r15],xmm2
    719221efe3a1:	mov    r15,r14
    719221efe3a4:	add    r15,0x128
    719221efe3ab:	mov    DWORD PTR [r15],r8d
    719221efe3ae:	mov    r15,r13
    719221efe3b1:	add    r15,0x40
    719221efe3b5:	mov    rbp,r15
    719221efe3b8:	add    rbp,0x10
    719221efe3bc:	movdqu XMMWORD PTR [r15],xmm3
    719221efe3c1:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    719221efe3c6:	mov    r15d,0x4206e8
    719221efe3cc:	mov    ebp,0x4206f8
    719221efe3d1:	movdqu xmm2,XMMWORD PTR [r15]
    719221efe3d6:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    719221efe3db:	movdqu XMMWORD PTR [r12+0x110],xmm2
    719221efe3e5:	movdqu XMMWORD PTR [r12+0x120],xmm3
    719221efe3ef:	mov    r15,r13
    719221efe3f2:	add    r15,0x10
    719221efe3f6:	movdqu XMMWORD PTR [r13+0x0],xmm2
    719221efe3fc:	movdqu XMMWORD PTR [r15],xmm3
    719221efe401:	mov    r15d,0x420708
    719221efe407:	mov    ebp,0x420718
    719221efe40c:	movdqu xmm2,XMMWORD PTR [r15]
    719221efe411:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    719221efe416:	movdqu XMMWORD PTR [r12+0x110],xmm2
    719221efe420:	movdqu XMMWORD PTR [r12+0x130],xmm3
    719221efe42a:	mov    r15,r13
    719221efe42d:	add    r15,0x20
    719221efe431:	mov    rbp,r15
    719221efe434:	add    rbp,0x10
    719221efe438:	movdqu XMMWORD PTR [r15],xmm2
    719221efe43d:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    719221efe442:	mov    QWORD PTR [r12],r13
    719221efe446:	mov    r13d,0x0
    719221efe44c:	or     r13,r14
    719221efe44f:	mov    QWORD PTR [r12+0x8],r13
    719221efe454:	mov    r13d,0x12c
    719221efe45a:	mov    QWORD PTR [r12+0x10],r13
    719221efe45f:	mov    r13d,0x410274
    719221efe465:	mov    QWORD PTR [r12+0xf0],r13
    719221efe46d:	mov    r13d,0x410338
    719221efe473:	mov    QWORD PTR [r12+0x100],r13
    719221efe47b:	mov    r11,QWORD PTR [rsp]
    719221efe47f:	mov    QWORD PTR [r12+0x398],r11
    719221efe487:	mov    edi,0x410338
    719221efe48c:	mov    QWORD PTR [r12+0x100],rdi
    719221efe494:	add    rsp,0x10
    719221efe498:	jmp    QWORD PTR [rip+0x2]        # 0x719221efe4a0
    719221efe49e:	xchg   ax,ax
    719221efe4a0:	shl    ah,0xef
    719221efe4a3:	and    DWORD PTR [rdx-0x4fffff8f],edx
    719221efe4a9:	in     al,0xef
    719221efe4ab:	and    DWORD PTR [rdx+0x49000071],edx
    719221efe4b1:	mov    ebx,0x2955b940
    719221efe4b6:	xchg   BYTE PTR [rax+rax*1+0x0],ah
    719221efe4ba:	jmp    r11
    719221efe4bd:	nop
    719221efe4be:	nop
    719221efe4bf:	nop
