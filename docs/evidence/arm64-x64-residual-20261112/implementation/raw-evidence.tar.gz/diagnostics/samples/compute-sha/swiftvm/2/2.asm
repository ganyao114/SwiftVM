
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/2/2.bin:     file format binary


Disassembly of section .data:

0000719221f00a60 <.data>:
    719221f00a60:	sub    rsp,0x10
    719221f00a64:	mov    r13d,DWORD PTR [r12+0xa0]
    719221f00a6c:	sub    r13d,0x1
    719221f00a70:	mov    QWORD PTR [r12+0xa0],r13
    719221f00a78:	mov    rcx,QWORD PTR [r12+0x380]
    719221f00a80:	jrcxz  0x719221f00a87
    719221f00a82:	jmp    0x719221f00c05
    719221f00a87:	jne    0x719221f00aa0
    719221f00a8d:	mov    r11,rax
    719221f00a90:	lahf
    719221f00a91:	seto   al
    719221f00a94:	mov    WORD PTR [rsp],ax
    719221f00a98:	mov    rax,r11
    719221f00a9b:	jmp    0x719221f00ab3
    719221f00aa0:	mov    r11,rax
    719221f00aa3:	lahf
    719221f00aa4:	seto   al
    719221f00aa7:	mov    WORD PTR [rsp],ax
    719221f00aab:	mov    rax,r11
    719221f00aae:	jmp    0x719221f00b75
    719221f00ab3:	mov    r13,QWORD PTR [r12+0xf8]
    719221f00abb:	mov    r14,r13
    719221f00abe:	add    r14,0x20
    719221f00ac2:	mov    r15,QWORD PTR [r14]
    719221f00ac5:	mov    QWORD PTR [r12+0x98],r15
    719221f00acd:	mov    r14d,0x80
    719221f00ad3:	mov    QWORD PTR [r12+0x40],r14
    719221f00ad8:	mov    QWORD PTR [r12],r13
    719221f00adc:	mov    r14,r13
    719221f00adf:	add    r14,0x8c
    719221f00ae6:	mov    QWORD PTR [r12+0x8],r14
    719221f00aeb:	mov    r14d,0x1
    719221f00af1:	mov    QWORD PTR [r12+0x10],r14
    719221f00af6:	add    r13,0x8c
    719221f00afd:	movzx  r14d,BYTE PTR [r12+0x40]
    719221f00b03:	mov    BYTE PTR [r13+0x0],r14b
    719221f00b07:	mov    r13d,0x0
    719221f00b0d:	mov    DWORD PTR [r12+0x32c],r13d
    719221f00b15:	mov    r13d,0x410298
    719221f00b1b:	mov    QWORD PTR [r12+0xf0],r13
    719221f00b23:	mov    r13d,0x410338
    719221f00b29:	mov    QWORD PTR [r12+0x100],r13
    719221f00b31:	mov    r11,QWORD PTR [rsp]
    719221f00b35:	mov    QWORD PTR [r12+0x398],r11
    719221f00b3d:	mov    edi,0x410338
    719221f00b42:	mov    QWORD PTR [r12+0x100],rdi
    719221f00b4a:	add    rsp,0x10
    719221f00b4e:	xchg   ax,ax
    719221f00b50:	jmp    QWORD PTR [rip+0x2]        # 0x719221f00b58
    719221f00b56:	xchg   ax,ax
    719221f00b58:	shl    ah,0xef
    719221f00b5b:	and    DWORD PTR [rdx+0x68000071],edx
    719221f00b61:	or     esi,eax
    719221f00b63:	and    DWORD PTR [rdx+0x49000071],edx
    719221f00b69:	mov    ebx,0x2955b940
    719221f00b6e:	xchg   BYTE PTR [rax+rax*1+0x0],ah
    719221f00b72:	jmp    r11
    719221f00b75:	mov    r13,QWORD PTR [r12+0xf8]
    719221f00b7d:	mov    QWORD PTR [r12],r13
    719221f00b81:	mov    r13d,0x0
    719221f00b87:	mov    r14,QWORD PTR [r12+0x98]
    719221f00b8f:	or     r13,r14
    719221f00b92:	mov    QWORD PTR [r12+0x8],r13
    719221f00b97:	mov    r13d,0x12c
    719221f00b9d:	mov    QWORD PTR [r12+0x10],r13
    719221f00ba2:	mov    r13d,0x410274
    719221f00ba8:	mov    QWORD PTR [r12+0xf0],r13
    719221f00bb0:	mov    r13d,0x410338
    719221f00bb6:	mov    QWORD PTR [r12+0x100],r13
    719221f00bbe:	mov    r11,QWORD PTR [rsp]
    719221f00bc2:	mov    QWORD PTR [r12+0x398],r11
    719221f00bca:	mov    edi,0x410338
    719221f00bcf:	mov    QWORD PTR [r12+0x100],rdi
    719221f00bd7:	add    rsp,0x10
    719221f00bdb:	nop    DWORD PTR [rax+rax*1+0x0]
    719221f00be0:	jmp    QWORD PTR [rip+0x2]        # 0x719221f00be8
    719221f00be6:	xchg   ax,ax
    719221f00be8:	shl    ah,0xef
    719221f00beb:	and    DWORD PTR [rdx-0x7ffff8f],edx
    719221f00bf1:	or     esi,eax
    719221f00bf3:	and    DWORD PTR [rdx+0x49000071],edx
    719221f00bf9:	mov    ebx,0x2955b940
    719221f00bfe:	xchg   BYTE PTR [rax+rax*1+0x0],ah
    719221f00c02:	jmp    r11
    719221f00c05:	mov    eax,0x410278
    719221f00c0a:	mov    QWORD PTR [r12+0x100],rax
    719221f00c12:	push   rdx
    719221f00c13:	push   rsi
    719221f00c14:	push   r10
    719221f00c16:	push   r11
    719221f00c18:	mov    r11,rax
    719221f00c1b:	lahf
    719221f00c1c:	seto   al
    719221f00c1f:	mov    WORD PTR [rsp+0x20],ax
    719221f00c24:	mov    rax,r11
    719221f00c27:	mov    rdx,QWORD PTR [rsp+0x20]
    719221f00c2c:	mov    r10d,edx
    719221f00c2f:	and    r10d,0xc000
    719221f00c36:	shl    r10d,0x10
    719221f00c3a:	mov    r11d,edx
    719221f00c3d:	and    r11d,0x100
    719221f00c44:	shl    r11d,0x15
    719221f00c48:	or     r10d,r11d
    719221f00c4b:	and    edx,0x1
    719221f00c4e:	shl    edx,0x1c
    719221f00c51:	or     r10d,edx
    719221f00c54:	btc    r10,0x1d
    719221f00c59:	mov    r11d,0xf0000000
    719221f00c5f:	and    r11,r10
    719221f00c62:	movabs rsi,0xffffffff0fffffff
    719221f00c6c:	and    rbx,rsi
    719221f00c6f:	or     rbx,r11
    719221f00c72:	pop    r11
    719221f00c74:	pop    r10
    719221f00c76:	pop    rsi
    719221f00c77:	pop    rdx
    719221f00c78:	mov    QWORD PTR [r12+0x108],rbx
    719221f00c80:	add    rsp,0x10
    719221f00c84:	mov    eax,0xc
    719221f00c89:	movabs r11,0x64862955bca0
    719221f00c93:	jmp    r11
    719221f00c96:	data16 nop WORD PTR [rax+rax*1+0x0]
    719221f00ca0:	sub    rsp,0x10
    719221f00ca4:	mov    r11,QWORD PTR [r12+0x398]
    719221f00cac:	mov    QWORD PTR [rsp],r11
    719221f00cb0:	jmp    0x719221f00ab3
    719221f00cb5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    719221f00cc0:	sub    rsp,0x10
    719221f00cc4:	mov    r11,QWORD PTR [r12+0x398]
    719221f00ccc:	mov    QWORD PTR [rsp],r11
    719221f00cd0:	jmp    0x719221f00b75
    719221f00cd5:	nop
    719221f00cd6:	nop
    719221f00cd7:	nop
