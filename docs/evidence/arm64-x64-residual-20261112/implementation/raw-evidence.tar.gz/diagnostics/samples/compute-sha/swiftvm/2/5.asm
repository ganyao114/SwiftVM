
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/2/5.bin:     file format binary


Disassembly of section .data:

0000719221f010d0 <.data>:
    719221f010d0:	sub    rsp,0x30
    719221f010d4:	mov    r11,QWORD PTR [r12+0x398]
    719221f010dc:	mov    QWORD PTR [rsp+0x18],r11
    719221f010e1:	mov    rax,QWORD PTR [r12+0xf8]
    719221f010e9:	mov    r14,QWORD PTR [r12+0xf8]
    719221f010f1:	add    r14,0x4
    719221f010f5:	mov    rdi,QWORD PTR [r12+0xf8]
    719221f010fd:	mov    r15d,DWORD PTR [rdi]
    719221f01100:	mov    ebp,DWORD PTR [r14]
    719221f01103:	mov    QWORD PTR [r12+0x40],r15
    719221f01108:	mov    QWORD PTR [r12+0x50],rbp
    719221f0110d:	mov    r14,QWORD PTR [r12+0xf8]
    719221f01115:	add    r14,0x8
    719221f01119:	mov    r8,r14
    719221f0111c:	add    r8,0x4
    719221f01120:	mov    r9d,DWORD PTR [r14]
    719221f01123:	mov    eax,DWORD PTR [r8]
    719221f01126:	mov    QWORD PTR [rsp],rax
    719221f0112a:	mov    QWORD PTR [r12+0x58],r9
    719221f0112f:	mov    rax,QWORD PTR [rsp]
    719221f01133:	mov    QWORD PTR [r12+0x60],rax
    719221f01138:	mov    r8d,0x430860
    719221f0113e:	mov    QWORD PTR [r12+0x48],r8
    719221f01143:	mov    r8,QWORD PTR [r12+0xf8]
    719221f0114b:	add    r8,0x80
    719221f01152:	mov    r13,QWORD PTR [r8]
    719221f01155:	mov    QWORD PTR [r12+0xf0],r13
    719221f0115d:	movabs rcx,0xff00ff00ff00ff
    719221f01167:	mov    r13,r15
    719221f0116a:	and    r13,rcx
    719221f0116d:	shl    r13,0x8
    719221f01171:	movabs rcx,0xff00ff00ff00ff00
    719221f0117b:	mov    r8,r15
    719221f0117e:	and    r8,rcx
    719221f01181:	shr    r8,0x8
    719221f01185:	or     r8,r13
    719221f01188:	movabs rcx,0xffff0000ffff
    719221f01192:	mov    r13,r8
    719221f01195:	and    r13,rcx
    719221f01198:	shl    r13,0x10
    719221f0119c:	movabs rcx,0xffff0000ffff0000
    719221f011a6:	and    r8,rcx
    719221f011a9:	shr    r8,0x10
    719221f011ad:	or     r8,r13
    719221f011b0:	mov    ecx,0xffffffff
    719221f011b5:	and    r8,rcx
    719221f011b8:	mov    QWORD PTR [r12+0x40],r8
    719221f011bd:	movabs rcx,0xff00ff00ff00ff
    719221f011c7:	mov    r13,rbp
    719221f011ca:	and    r13,rcx
    719221f011cd:	shl    r13,0x8
    719221f011d1:	movabs rcx,0xff00ff00ff00ff00
    719221f011db:	mov    r15,rbp
    719221f011de:	and    r15,rcx
    719221f011e1:	shr    r15,0x8
    719221f011e5:	or     r15,r13
    719221f011e8:	movabs rcx,0xffff0000ffff
    719221f011f2:	mov    r13,r15
    719221f011f5:	and    r13,rcx
    719221f011f8:	shl    r13,0x10
    719221f011fc:	movabs rcx,0xffff0000ffff0000
    719221f01206:	and    r15,rcx
    719221f01209:	shr    r15,0x10
    719221f0120d:	or     r15,r13
    719221f01210:	mov    ecx,0xffffffff
    719221f01215:	and    r15,rcx
    719221f01218:	mov    QWORD PTR [r12+0x50],r15
    719221f0121d:	mov    r13d,0x430860
    719221f01223:	mov    ebp,0x430864
    719221f01228:	mov    rax,r8
    719221f0122b:	mov    eax,eax
    719221f0122d:	mov    r14d,eax
    719221f01230:	mov    rax,r15
    719221f01233:	mov    eax,eax
    719221f01235:	mov    r8d,eax
    719221f01238:	mov    DWORD PTR [r13+0x0],r14d
    719221f0123c:	mov    r13d,0x0
    719221f01242:	mov    DWORD PTR [r12+0x32c],r13d
    719221f0124a:	mov    DWORD PTR [rbp+0x0],r8d
    719221f0124e:	movabs rcx,0xff00ff00ff00ff
    719221f01258:	mov    r13,r9
    719221f0125b:	and    r13,rcx
    719221f0125e:	shl    r13,0x8
    719221f01262:	movabs rcx,0xff00ff00ff00ff00
    719221f0126c:	mov    r14,r9
    719221f0126f:	and    r14,rcx
    719221f01272:	shr    r14,0x8
    719221f01276:	or     r14,r13
    719221f01279:	movabs rcx,0xffff0000ffff
    719221f01283:	mov    r13,r14
    719221f01286:	and    r13,rcx
    719221f01289:	shl    r13,0x10
    719221f0128d:	movabs rcx,0xffff0000ffff0000
    719221f01297:	and    r14,rcx
    719221f0129a:	shr    r14,0x10
    719221f0129e:	or     r14,r13
    719221f012a1:	mov    ecx,0xffffffff
    719221f012a6:	and    r14,rcx
    719221f012a9:	mov    QWORD PTR [r12+0x40],r14
    719221f012ae:	movabs rcx,0xff00ff00ff00ff
    719221f012b8:	mov    r13,QWORD PTR [rsp]
    719221f012bc:	and    r13,rcx
    719221f012bf:	shl    r13,0x8
    719221f012c3:	movabs rcx,0xff00ff00ff00ff00
    719221f012cd:	mov    r15,QWORD PTR [rsp]
    719221f012d1:	and    r15,rcx
    719221f012d4:	shr    r15,0x8
    719221f012d8:	or     r15,r13
    719221f012db:	movabs rcx,0xffff0000ffff
    719221f012e5:	mov    r13,r15
    719221f012e8:	and    r13,rcx
    719221f012eb:	shl    r13,0x10
    719221f012ef:	movabs rcx,0xffff0000ffff0000
    719221f012f9:	and    r15,rcx
    719221f012fc:	shr    r15,0x10
    719221f01300:	or     r15,r13
    719221f01303:	mov    ecx,0xffffffff
    719221f01308:	and    r15,rcx
    719221f0130b:	mov    QWORD PTR [r12+0x58],r15
    719221f01310:	mov    r13,QWORD PTR [r12+0xf8]
    719221f01318:	add    r13,0x10
    719221f0131c:	mov    rbp,r13
    719221f0131f:	add    rbp,0x4
    719221f01323:	mov    r8d,DWORD PTR [r13+0x0]
    719221f01327:	mov    eax,DWORD PTR [rbp+0x0]
    719221f0132a:	mov    QWORD PTR [rsp+0x8],rax
    719221f0132f:	mov    QWORD PTR [r12+0x50],r8
    719221f01334:	mov    rax,QWORD PTR [rsp+0x8]
    719221f01339:	mov    QWORD PTR [r12+0x60],rax
    719221f0133e:	mov    ebp,0x430868
    719221f01343:	mov    r9d,0x43086c
    719221f01349:	mov    rax,r14
    719221f0134c:	mov    eax,eax
    719221f0134e:	mov    r13d,eax
    719221f01351:	mov    rax,r15
    719221f01354:	mov    eax,eax
    719221f01356:	mov    r14d,eax
    719221f01359:	mov    DWORD PTR [rbp+0x0],r13d
    719221f0135d:	mov    DWORD PTR [r9],r14d
    719221f01360:	mov    r13,QWORD PTR [r12+0xf8]
    719221f01368:	add    r13,0x90
    719221f0136f:	mov    r14,r13
    719221f01372:	add    r14,0x8
    719221f01376:	mov    r15,QWORD PTR [r13+0x0]
    719221f0137a:	mov    r13,QWORD PTR [r14]
    719221f0137d:	mov    QWORD PTR [r12+0xa0],r15
    719221f01385:	mov    QWORD PTR [r12+0x98],r13
    719221f0138d:	movabs rcx,0xff00ff00ff00ff
    719221f01397:	mov    r13,r8
    719221f0139a:	and    r13,rcx
    719221f0139d:	shl    r13,0x8
    719221f013a1:	movabs rcx,0xff00ff00ff00ff00
    719221f013ab:	mov    r14,r8
    719221f013ae:	and    r14,rcx
    719221f013b1:	shr    r14,0x8
    719221f013b5:	or     r14,r13
    719221f013b8:	movabs rcx,0xffff0000ffff
    719221f013c2:	mov    r13,r14
    719221f013c5:	and    r13,rcx
    719221f013c8:	shl    r13,0x10
    719221f013cc:	movabs rcx,0xffff0000ffff0000
    719221f013d6:	and    r14,rcx
    719221f013d9:	shr    r14,0x10
    719221f013dd:	or     r14,r13
    719221f013e0:	mov    ecx,0xffffffff
    719221f013e5:	and    r14,rcx
    719221f013e8:	mov    QWORD PTR [r12+0x40],r14
    719221f013ed:	movabs rcx,0xff00ff00ff00ff
    719221f013f7:	mov    r13,QWORD PTR [rsp+0x8]
    719221f013fc:	and    r13,rcx
    719221f013ff:	shl    r13,0x8
    719221f01403:	movabs rcx,0xff00ff00ff00ff00
    719221f0140d:	mov    r15,QWORD PTR [rsp+0x8]
    719221f01412:	and    r15,rcx
    719221f01415:	shr    r15,0x8
    719221f01419:	or     r15,r13
    719221f0141c:	movabs rcx,0xffff0000ffff
    719221f01426:	mov    r13,r15
    719221f01429:	and    r13,rcx
    719221f0142c:	shl    r13,0x10
    719221f01430:	movabs rcx,0xffff0000ffff0000
    719221f0143a:	and    r15,rcx
    719221f0143d:	shr    r15,0x10
    719221f01441:	or     r15,r13
    719221f01444:	mov    ecx,0xffffffff
    719221f01449:	and    r15,rcx
    719221f0144c:	mov    QWORD PTR [r12+0x58],r15
    719221f01451:	mov    r13,QWORD PTR [r12+0xf8]
    719221f01459:	add    r13,0x18
    719221f0145d:	mov    rbp,r13
    719221f01460:	add    rbp,0x4
    719221f01464:	mov    r8d,DWORD PTR [r13+0x0]
    719221f01468:	mov    eax,DWORD PTR [rbp+0x0]
    719221f0146b:	mov    QWORD PTR [rsp+0x10],rax
    719221f01470:	mov    QWORD PTR [r12+0x50],r8
    719221f01475:	mov    rax,QWORD PTR [rsp+0x10]
    719221f0147a:	mov    QWORD PTR [r12+0x60],rax
    719221f0147f:	mov    ebp,0x430870
    719221f01484:	mov    r9d,0x430874
    719221f0148a:	mov    rax,r14
    719221f0148d:	mov    eax,eax
    719221f0148f:	mov    r13d,eax
    719221f01492:	mov    rax,r15
    719221f01495:	mov    eax,eax
    719221f01497:	mov    r14d,eax
    719221f0149a:	mov    DWORD PTR [rbp+0x0],r13d
    719221f0149e:	mov    DWORD PTR [r9],r14d
    719221f014a1:	movabs rcx,0xff00ff00ff00ff
    719221f014ab:	mov    r13,r8
    719221f014ae:	and    r13,rcx
    719221f014b1:	shl    r13,0x8
    719221f014b5:	movabs rcx,0xff00ff00ff00ff00
    719221f014bf:	mov    r14,r8
    719221f014c2:	and    r14,rcx
    719221f014c5:	shr    r14,0x8
    719221f014c9:	or     r14,r13
    719221f014cc:	movabs rcx,0xffff0000ffff
    719221f014d6:	mov    r13,r14
    719221f014d9:	and    r13,rcx
    719221f014dc:	shl    r13,0x10
    719221f014e0:	movabs rcx,0xffff0000ffff0000
    719221f014ea:	and    r14,rcx
    719221f014ed:	shr    r14,0x10
    719221f014f1:	or     r14,r13
    719221f014f4:	mov    ecx,0xffffffff
    719221f014f9:	and    r14,rcx
    719221f014fc:	mov    QWORD PTR [r12+0x40],r14
    719221f01501:	movabs rcx,0xff00ff00ff00ff
    719221f0150b:	mov    r13,QWORD PTR [rsp+0x10]
    719221f01510:	and    r13,rcx
    719221f01513:	shl    r13,0x8
    719221f01517:	movabs rcx,0xff00ff00ff00ff00
    719221f01521:	mov    r15,QWORD PTR [rsp+0x10]
    719221f01526:	and    r15,rcx
    719221f01529:	shr    r15,0x8
    719221f0152d:	or     r15,r13
    719221f01530:	movabs rcx,0xffff0000ffff
    719221f0153a:	mov    r13,r15
    719221f0153d:	and    r13,rcx
    719221f01540:	shl    r13,0x10
    719221f01544:	movabs rcx,0xffff0000ffff0000
    719221f0154e:	and    r15,rcx
    719221f01551:	shr    r15,0x10
    719221f01555:	or     r15,r13
    719221f01558:	mov    ecx,0xffffffff
    719221f0155d:	and    r15,rcx
    719221f01560:	mov    QWORD PTR [r12+0x50],r15
    719221f01565:	mov    r13d,0x430878
    719221f0156b:	mov    ebp,0x43087c
    719221f01570:	mov    rax,r14
    719221f01573:	mov    eax,eax
    719221f01575:	mov    r8d,eax
    719221f01578:	mov    rax,r15
    719221f0157b:	mov    eax,eax
    719221f0157d:	mov    r14d,eax
    719221f01580:	mov    DWORD PTR [r13+0x0],r8d
    719221f01584:	mov    DWORD PTR [rbp+0x0],r14d
    719221f01588:	mov    r13,QWORD PTR [r12+0xf8]
    719221f01590:	add    r13,0xa0
    719221f01597:	mov    QWORD PTR [r12+0xf8],r13
    719221f0159f:	mov    rcx,QWORD PTR [r12+0x380]
    719221f015a7:	jrcxz  0x719221f015ae
    719221f015a9:	jmp    0x719221f015e4
    719221f015ae:	mov    r13,QWORD PTR [r12+0xf0]
    719221f015b6:	mov    QWORD PTR [r12+0x100],r13
    719221f015be:	mov    r11,QWORD PTR [rsp+0x18]
    719221f015c3:	mov    QWORD PTR [r12+0x398],r11
    719221f015cb:	mov    rdi,QWORD PTR [r12+0x100]
    719221f015d3:	add    rsp,0x30
    719221f015d7:	movabs r11,0x64862955b940
    719221f015e1:	jmp    r11
    719221f015e4:	mov    eax,0x410334
    719221f015e9:	mov    QWORD PTR [r12+0x100],rax
    719221f015f1:	push   rdx
    719221f015f2:	push   rsi
    719221f015f3:	push   r10
    719221f015f5:	push   r11
    719221f015f7:	mov    rdx,QWORD PTR [rsp+0x38]
    719221f015fc:	mov    r10d,edx
    719221f015ff:	and    r10d,0xc000
    719221f01606:	shl    r10d,0x10
    719221f0160a:	mov    r11d,edx
    719221f0160d:	and    r11d,0x100
    719221f01614:	shl    r11d,0x15
    719221f01618:	or     r10d,r11d
    719221f0161b:	and    edx,0x1
    719221f0161e:	shl    edx,0x1c
    719221f01621:	or     r10d,edx
    719221f01624:	btc    r10,0x1d
    719221f01629:	mov    r11d,0xf0000000
    719221f0162f:	and    r11,r10
    719221f01632:	movabs rsi,0xffffffff0fffffff
    719221f0163c:	and    rbx,rsi
    719221f0163f:	or     rbx,r11
    719221f01642:	pop    r11
    719221f01644:	pop    r10
    719221f01646:	pop    rsi
    719221f01647:	pop    rdx
    719221f01648:	mov    QWORD PTR [r12+0x108],rbx
    719221f01650:	add    rsp,0x30
    719221f01654:	mov    eax,0xc
    719221f01659:	movabs r11,0x64862955bca0
    719221f01663:	jmp    r11
    719221f01666:	nop
    719221f01667:	nop
