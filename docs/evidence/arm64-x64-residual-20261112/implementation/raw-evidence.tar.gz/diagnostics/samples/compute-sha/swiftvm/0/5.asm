
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/0/5.bin:     file format binary


Disassembly of section .data:

000072ee5fa000d0 <.data>:
    72ee5fa000d0:	sub    rsp,0x30
    72ee5fa000d4:	mov    r11,QWORD PTR [r12+0x398]
    72ee5fa000dc:	mov    QWORD PTR [rsp+0x18],r11
    72ee5fa000e1:	mov    rax,QWORD PTR [r12+0xf8]
    72ee5fa000e9:	mov    r14,QWORD PTR [r12+0xf8]
    72ee5fa000f1:	add    r14,0x4
    72ee5fa000f5:	mov    rdi,QWORD PTR [r12+0xf8]
    72ee5fa000fd:	mov    r15d,DWORD PTR [rdi]
    72ee5fa00100:	mov    ebp,DWORD PTR [r14]
    72ee5fa00103:	mov    QWORD PTR [r12+0x40],r15
    72ee5fa00108:	mov    QWORD PTR [r12+0x50],rbp
    72ee5fa0010d:	mov    r14,QWORD PTR [r12+0xf8]
    72ee5fa00115:	add    r14,0x8
    72ee5fa00119:	mov    r8,r14
    72ee5fa0011c:	add    r8,0x4
    72ee5fa00120:	mov    r9d,DWORD PTR [r14]
    72ee5fa00123:	mov    eax,DWORD PTR [r8]
    72ee5fa00126:	mov    QWORD PTR [rsp],rax
    72ee5fa0012a:	mov    QWORD PTR [r12+0x58],r9
    72ee5fa0012f:	mov    rax,QWORD PTR [rsp]
    72ee5fa00133:	mov    QWORD PTR [r12+0x60],rax
    72ee5fa00138:	mov    r8d,0x430860
    72ee5fa0013e:	mov    QWORD PTR [r12+0x48],r8
    72ee5fa00143:	mov    r8,QWORD PTR [r12+0xf8]
    72ee5fa0014b:	add    r8,0x80
    72ee5fa00152:	mov    r13,QWORD PTR [r8]
    72ee5fa00155:	mov    QWORD PTR [r12+0xf0],r13
    72ee5fa0015d:	movabs rcx,0xff00ff00ff00ff
    72ee5fa00167:	mov    r13,r15
    72ee5fa0016a:	and    r13,rcx
    72ee5fa0016d:	shl    r13,0x8
    72ee5fa00171:	movabs rcx,0xff00ff00ff00ff00
    72ee5fa0017b:	mov    r8,r15
    72ee5fa0017e:	and    r8,rcx
    72ee5fa00181:	shr    r8,0x8
    72ee5fa00185:	or     r8,r13
    72ee5fa00188:	movabs rcx,0xffff0000ffff
    72ee5fa00192:	mov    r13,r8
    72ee5fa00195:	and    r13,rcx
    72ee5fa00198:	shl    r13,0x10
    72ee5fa0019c:	movabs rcx,0xffff0000ffff0000
    72ee5fa001a6:	and    r8,rcx
    72ee5fa001a9:	shr    r8,0x10
    72ee5fa001ad:	or     r8,r13
    72ee5fa001b0:	mov    ecx,0xffffffff
    72ee5fa001b5:	and    r8,rcx
    72ee5fa001b8:	mov    QWORD PTR [r12+0x40],r8
    72ee5fa001bd:	movabs rcx,0xff00ff00ff00ff
    72ee5fa001c7:	mov    r13,rbp
    72ee5fa001ca:	and    r13,rcx
    72ee5fa001cd:	shl    r13,0x8
    72ee5fa001d1:	movabs rcx,0xff00ff00ff00ff00
    72ee5fa001db:	mov    r15,rbp
    72ee5fa001de:	and    r15,rcx
    72ee5fa001e1:	shr    r15,0x8
    72ee5fa001e5:	or     r15,r13
    72ee5fa001e8:	movabs rcx,0xffff0000ffff
    72ee5fa001f2:	mov    r13,r15
    72ee5fa001f5:	and    r13,rcx
    72ee5fa001f8:	shl    r13,0x10
    72ee5fa001fc:	movabs rcx,0xffff0000ffff0000
    72ee5fa00206:	and    r15,rcx
    72ee5fa00209:	shr    r15,0x10
    72ee5fa0020d:	or     r15,r13
    72ee5fa00210:	mov    ecx,0xffffffff
    72ee5fa00215:	and    r15,rcx
    72ee5fa00218:	mov    QWORD PTR [r12+0x50],r15
    72ee5fa0021d:	mov    r13d,0x430860
    72ee5fa00223:	mov    ebp,0x430864
    72ee5fa00228:	mov    rax,r8
    72ee5fa0022b:	mov    eax,eax
    72ee5fa0022d:	mov    r14d,eax
    72ee5fa00230:	mov    rax,r15
    72ee5fa00233:	mov    eax,eax
    72ee5fa00235:	mov    r8d,eax
    72ee5fa00238:	mov    DWORD PTR [r13+0x0],r14d
    72ee5fa0023c:	mov    r13d,0x0
    72ee5fa00242:	mov    DWORD PTR [r12+0x32c],r13d
    72ee5fa0024a:	mov    DWORD PTR [rbp+0x0],r8d
    72ee5fa0024e:	movabs rcx,0xff00ff00ff00ff
    72ee5fa00258:	mov    r13,r9
    72ee5fa0025b:	and    r13,rcx
    72ee5fa0025e:	shl    r13,0x8
    72ee5fa00262:	movabs rcx,0xff00ff00ff00ff00
    72ee5fa0026c:	mov    r14,r9
    72ee5fa0026f:	and    r14,rcx
    72ee5fa00272:	shr    r14,0x8
    72ee5fa00276:	or     r14,r13
    72ee5fa00279:	movabs rcx,0xffff0000ffff
    72ee5fa00283:	mov    r13,r14
    72ee5fa00286:	and    r13,rcx
    72ee5fa00289:	shl    r13,0x10
    72ee5fa0028d:	movabs rcx,0xffff0000ffff0000
    72ee5fa00297:	and    r14,rcx
    72ee5fa0029a:	shr    r14,0x10
    72ee5fa0029e:	or     r14,r13
    72ee5fa002a1:	mov    ecx,0xffffffff
    72ee5fa002a6:	and    r14,rcx
    72ee5fa002a9:	mov    QWORD PTR [r12+0x40],r14
    72ee5fa002ae:	movabs rcx,0xff00ff00ff00ff
    72ee5fa002b8:	mov    r13,QWORD PTR [rsp]
    72ee5fa002bc:	and    r13,rcx
    72ee5fa002bf:	shl    r13,0x8
    72ee5fa002c3:	movabs rcx,0xff00ff00ff00ff00
    72ee5fa002cd:	mov    r15,QWORD PTR [rsp]
    72ee5fa002d1:	and    r15,rcx
    72ee5fa002d4:	shr    r15,0x8
    72ee5fa002d8:	or     r15,r13
    72ee5fa002db:	movabs rcx,0xffff0000ffff
    72ee5fa002e5:	mov    r13,r15
    72ee5fa002e8:	and    r13,rcx
    72ee5fa002eb:	shl    r13,0x10
    72ee5fa002ef:	movabs rcx,0xffff0000ffff0000
    72ee5fa002f9:	and    r15,rcx
    72ee5fa002fc:	shr    r15,0x10
    72ee5fa00300:	or     r15,r13
    72ee5fa00303:	mov    ecx,0xffffffff
    72ee5fa00308:	and    r15,rcx
    72ee5fa0030b:	mov    QWORD PTR [r12+0x58],r15
    72ee5fa00310:	mov    r13,QWORD PTR [r12+0xf8]
    72ee5fa00318:	add    r13,0x10
    72ee5fa0031c:	mov    rbp,r13
    72ee5fa0031f:	add    rbp,0x4
    72ee5fa00323:	mov    r8d,DWORD PTR [r13+0x0]
    72ee5fa00327:	mov    eax,DWORD PTR [rbp+0x0]
    72ee5fa0032a:	mov    QWORD PTR [rsp+0x8],rax
    72ee5fa0032f:	mov    QWORD PTR [r12+0x50],r8
    72ee5fa00334:	mov    rax,QWORD PTR [rsp+0x8]
    72ee5fa00339:	mov    QWORD PTR [r12+0x60],rax
    72ee5fa0033e:	mov    ebp,0x430868
    72ee5fa00343:	mov    r9d,0x43086c
    72ee5fa00349:	mov    rax,r14
    72ee5fa0034c:	mov    eax,eax
    72ee5fa0034e:	mov    r13d,eax
    72ee5fa00351:	mov    rax,r15
    72ee5fa00354:	mov    eax,eax
    72ee5fa00356:	mov    r14d,eax
    72ee5fa00359:	mov    DWORD PTR [rbp+0x0],r13d
    72ee5fa0035d:	mov    DWORD PTR [r9],r14d
    72ee5fa00360:	mov    r13,QWORD PTR [r12+0xf8]
    72ee5fa00368:	add    r13,0x90
    72ee5fa0036f:	mov    r14,r13
    72ee5fa00372:	add    r14,0x8
    72ee5fa00376:	mov    r15,QWORD PTR [r13+0x0]
    72ee5fa0037a:	mov    r13,QWORD PTR [r14]
    72ee5fa0037d:	mov    QWORD PTR [r12+0xa0],r15
    72ee5fa00385:	mov    QWORD PTR [r12+0x98],r13
    72ee5fa0038d:	movabs rcx,0xff00ff00ff00ff
    72ee5fa00397:	mov    r13,r8
    72ee5fa0039a:	and    r13,rcx
    72ee5fa0039d:	shl    r13,0x8
    72ee5fa003a1:	movabs rcx,0xff00ff00ff00ff00
    72ee5fa003ab:	mov    r14,r8
    72ee5fa003ae:	and    r14,rcx
    72ee5fa003b1:	shr    r14,0x8
    72ee5fa003b5:	or     r14,r13
    72ee5fa003b8:	movabs rcx,0xffff0000ffff
    72ee5fa003c2:	mov    r13,r14
    72ee5fa003c5:	and    r13,rcx
    72ee5fa003c8:	shl    r13,0x10
    72ee5fa003cc:	movabs rcx,0xffff0000ffff0000
    72ee5fa003d6:	and    r14,rcx
    72ee5fa003d9:	shr    r14,0x10
    72ee5fa003dd:	or     r14,r13
    72ee5fa003e0:	mov    ecx,0xffffffff
    72ee5fa003e5:	and    r14,rcx
    72ee5fa003e8:	mov    QWORD PTR [r12+0x40],r14
    72ee5fa003ed:	movabs rcx,0xff00ff00ff00ff
    72ee5fa003f7:	mov    r13,QWORD PTR [rsp+0x8]
    72ee5fa003fc:	and    r13,rcx
    72ee5fa003ff:	shl    r13,0x8
    72ee5fa00403:	movabs rcx,0xff00ff00ff00ff00
    72ee5fa0040d:	mov    r15,QWORD PTR [rsp+0x8]
    72ee5fa00412:	and    r15,rcx
    72ee5fa00415:	shr    r15,0x8
    72ee5fa00419:	or     r15,r13
    72ee5fa0041c:	movabs rcx,0xffff0000ffff
    72ee5fa00426:	mov    r13,r15
    72ee5fa00429:	and    r13,rcx
    72ee5fa0042c:	shl    r13,0x10
    72ee5fa00430:	movabs rcx,0xffff0000ffff0000
    72ee5fa0043a:	and    r15,rcx
    72ee5fa0043d:	shr    r15,0x10
    72ee5fa00441:	or     r15,r13
    72ee5fa00444:	mov    ecx,0xffffffff
    72ee5fa00449:	and    r15,rcx
    72ee5fa0044c:	mov    QWORD PTR [r12+0x58],r15
    72ee5fa00451:	mov    r13,QWORD PTR [r12+0xf8]
    72ee5fa00459:	add    r13,0x18
    72ee5fa0045d:	mov    rbp,r13
    72ee5fa00460:	add    rbp,0x4
    72ee5fa00464:	mov    r8d,DWORD PTR [r13+0x0]
    72ee5fa00468:	mov    eax,DWORD PTR [rbp+0x0]
    72ee5fa0046b:	mov    QWORD PTR [rsp+0x10],rax
    72ee5fa00470:	mov    QWORD PTR [r12+0x50],r8
    72ee5fa00475:	mov    rax,QWORD PTR [rsp+0x10]
    72ee5fa0047a:	mov    QWORD PTR [r12+0x60],rax
    72ee5fa0047f:	mov    ebp,0x430870
    72ee5fa00484:	mov    r9d,0x430874
    72ee5fa0048a:	mov    rax,r14
    72ee5fa0048d:	mov    eax,eax
    72ee5fa0048f:	mov    r13d,eax
    72ee5fa00492:	mov    rax,r15
    72ee5fa00495:	mov    eax,eax
    72ee5fa00497:	mov    r14d,eax
    72ee5fa0049a:	mov    DWORD PTR [rbp+0x0],r13d
    72ee5fa0049e:	mov    DWORD PTR [r9],r14d
    72ee5fa004a1:	movabs rcx,0xff00ff00ff00ff
    72ee5fa004ab:	mov    r13,r8
    72ee5fa004ae:	and    r13,rcx
    72ee5fa004b1:	shl    r13,0x8
    72ee5fa004b5:	movabs rcx,0xff00ff00ff00ff00
    72ee5fa004bf:	mov    r14,r8
    72ee5fa004c2:	and    r14,rcx
    72ee5fa004c5:	shr    r14,0x8
    72ee5fa004c9:	or     r14,r13
    72ee5fa004cc:	movabs rcx,0xffff0000ffff
    72ee5fa004d6:	mov    r13,r14
    72ee5fa004d9:	and    r13,rcx
    72ee5fa004dc:	shl    r13,0x10
    72ee5fa004e0:	movabs rcx,0xffff0000ffff0000
    72ee5fa004ea:	and    r14,rcx
    72ee5fa004ed:	shr    r14,0x10
    72ee5fa004f1:	or     r14,r13
    72ee5fa004f4:	mov    ecx,0xffffffff
    72ee5fa004f9:	and    r14,rcx
    72ee5fa004fc:	mov    QWORD PTR [r12+0x40],r14
    72ee5fa00501:	movabs rcx,0xff00ff00ff00ff
    72ee5fa0050b:	mov    r13,QWORD PTR [rsp+0x10]
    72ee5fa00510:	and    r13,rcx
    72ee5fa00513:	shl    r13,0x8
    72ee5fa00517:	movabs rcx,0xff00ff00ff00ff00
    72ee5fa00521:	mov    r15,QWORD PTR [rsp+0x10]
    72ee5fa00526:	and    r15,rcx
    72ee5fa00529:	shr    r15,0x8
    72ee5fa0052d:	or     r15,r13
    72ee5fa00530:	movabs rcx,0xffff0000ffff
    72ee5fa0053a:	mov    r13,r15
    72ee5fa0053d:	and    r13,rcx
    72ee5fa00540:	shl    r13,0x10
    72ee5fa00544:	movabs rcx,0xffff0000ffff0000
    72ee5fa0054e:	and    r15,rcx
    72ee5fa00551:	shr    r15,0x10
    72ee5fa00555:	or     r15,r13
    72ee5fa00558:	mov    ecx,0xffffffff
    72ee5fa0055d:	and    r15,rcx
    72ee5fa00560:	mov    QWORD PTR [r12+0x50],r15
    72ee5fa00565:	mov    r13d,0x430878
    72ee5fa0056b:	mov    ebp,0x43087c
    72ee5fa00570:	mov    rax,r14
    72ee5fa00573:	mov    eax,eax
    72ee5fa00575:	mov    r8d,eax
    72ee5fa00578:	mov    rax,r15
    72ee5fa0057b:	mov    eax,eax
    72ee5fa0057d:	mov    r14d,eax
    72ee5fa00580:	mov    DWORD PTR [r13+0x0],r8d
    72ee5fa00584:	mov    DWORD PTR [rbp+0x0],r14d
    72ee5fa00588:	mov    r13,QWORD PTR [r12+0xf8]
    72ee5fa00590:	add    r13,0xa0
    72ee5fa00597:	mov    QWORD PTR [r12+0xf8],r13
    72ee5fa0059f:	mov    rcx,QWORD PTR [r12+0x380]
    72ee5fa005a7:	jrcxz  0x72ee5fa005ae
    72ee5fa005a9:	jmp    0x72ee5fa005e4
    72ee5fa005ae:	mov    r13,QWORD PTR [r12+0xf0]
    72ee5fa005b6:	mov    QWORD PTR [r12+0x100],r13
    72ee5fa005be:	mov    r11,QWORD PTR [rsp+0x18]
    72ee5fa005c3:	mov    QWORD PTR [r12+0x398],r11
    72ee5fa005cb:	mov    rdi,QWORD PTR [r12+0x100]
    72ee5fa005d3:	add    rsp,0x30
    72ee5fa005d7:	movabs r11,0x5c9444da9940
    72ee5fa005e1:	jmp    r11
    72ee5fa005e4:	mov    eax,0x410334
    72ee5fa005e9:	mov    QWORD PTR [r12+0x100],rax
    72ee5fa005f1:	push   rdx
    72ee5fa005f2:	push   rsi
    72ee5fa005f3:	push   r10
    72ee5fa005f5:	push   r11
    72ee5fa005f7:	mov    rdx,QWORD PTR [rsp+0x38]
    72ee5fa005fc:	mov    r10d,edx
    72ee5fa005ff:	and    r10d,0xc000
    72ee5fa00606:	shl    r10d,0x10
    72ee5fa0060a:	mov    r11d,edx
    72ee5fa0060d:	and    r11d,0x100
    72ee5fa00614:	shl    r11d,0x15
    72ee5fa00618:	or     r10d,r11d
    72ee5fa0061b:	and    edx,0x1
    72ee5fa0061e:	shl    edx,0x1c
    72ee5fa00621:	or     r10d,edx
    72ee5fa00624:	btc    r10,0x1d
    72ee5fa00629:	mov    r11d,0xf0000000
    72ee5fa0062f:	and    r11,r10
    72ee5fa00632:	movabs rsi,0xffffffff0fffffff
    72ee5fa0063c:	and    rbx,rsi
    72ee5fa0063f:	or     rbx,r11
    72ee5fa00642:	pop    r11
    72ee5fa00644:	pop    r10
    72ee5fa00646:	pop    rsi
    72ee5fa00647:	pop    rdx
    72ee5fa00648:	mov    QWORD PTR [r12+0x108],rbx
    72ee5fa00650:	add    rsp,0x30
    72ee5fa00654:	mov    eax,0xc
    72ee5fa00659:	movabs r11,0x5c9444da9ca0
    72ee5fa00663:	jmp    r11
    72ee5fa00666:	nop
    72ee5fa00667:	nop
