
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

000072ee5f9fd000 <.data>:
    72ee5f9fd000:	sub    rsp,0x10
    72ee5f9fd004:	mov    r11,QWORD PTR [r12+0x398]
    72ee5f9fd00c:	mov    QWORD PTR [rsp],r11
    72ee5f9fd010:	mov    r13,QWORD PTR [r12+0xf8]
    72ee5f9fd018:	sub    r13,0xa0
    72ee5f9fd01f:	mov    QWORD PTR [r12+0xf8],r13
    72ee5f9fd027:	mov    r14d,0x420000
    72ee5f9fd02d:	mov    QWORD PTR [r12+0x40],r14
    72ee5f9fd032:	mov    r14d,0x420000
    72ee5f9fd038:	mov    QWORD PTR [r12+0x48],r14
    72ee5f9fd03d:	mov    r14,r13
    72ee5f9fd040:	add    r14,0x90
    72ee5f9fd047:	mov    r15,r14
    72ee5f9fd04a:	add    r15,0x8
    72ee5f9fd04e:	mov    rbp,QWORD PTR [r12+0xa0]
    72ee5f9fd056:	mov    r8,QWORD PTR [r12+0x98]
    72ee5f9fd05e:	mov    QWORD PTR [r14],rbp
    72ee5f9fd061:	mov    r14d,0x0
    72ee5f9fd067:	mov    DWORD PTR [r12+0x32c],r14d
    72ee5f9fd06f:	mov    QWORD PTR [r15],r8
    72ee5f9fd072:	mov    r14d,0x420670
    72ee5f9fd078:	movdqu xmm2,XMMWORD PTR [r14]
    72ee5f9fd07d:	movdqu XMMWORD PTR [r12+0x110],xmm2
    72ee5f9fd087:	mov    r14d,0x420610
    72ee5f9fd08d:	movdqu xmm3,XMMWORD PTR [r14]
    72ee5f9fd092:	movdqu XMMWORD PTR [r12+0x120],xmm3
    72ee5f9fd09c:	mov    r14d,0x420690
    72ee5f9fd0a2:	movdqu xmm4,XMMWORD PTR [r14]
    72ee5f9fd0a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
    72ee5f9fd0b1:	mov    r14d,0x420630
    72ee5f9fd0b7:	movdqu xmm5,XMMWORD PTR [r14]
    72ee5f9fd0bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
    72ee5f9fd0c6:	mov    r14d,0x430000
    72ee5f9fd0cc:	add    r14,0x8a0
    72ee5f9fd0d3:	mov    QWORD PTR [r12+0x98],r14
    72ee5f9fd0db:	mov    r15d,0x4206a0
    72ee5f9fd0e1:	movdqu xmm6,XMMWORD PTR [r15]
    72ee5f9fd0e6:	movdqu XMMWORD PTR [r12+0x150],xmm6
    72ee5f9fd0f0:	mov    r15,r14
    72ee5f9fd0f3:	add    r15,0x10
    72ee5f9fd0f7:	movdqu XMMWORD PTR [r14],xmm2
    72ee5f9fd0fc:	movdqu XMMWORD PTR [r15],xmm3
    72ee5f9fd101:	mov    r15,r14
    72ee5f9fd104:	add    r15,0x20
    72ee5f9fd108:	mov    rbp,r15
    72ee5f9fd10b:	add    rbp,0x10
    72ee5f9fd10f:	movdqu XMMWORD PTR [r15],xmm4
    72ee5f9fd114:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    72ee5f9fd119:	mov    r15d,0x420600
    72ee5f9fd11f:	movdqu xmm4,XMMWORD PTR [r15]
    72ee5f9fd124:	movdqu XMMWORD PTR [r12+0x130],xmm4
    72ee5f9fd12e:	mov    r15d,0x4205f0
    72ee5f9fd134:	movdqu xmm5,XMMWORD PTR [r15]
    72ee5f9fd139:	movdqu XMMWORD PTR [r12+0x140],xmm5
    72ee5f9fd143:	mov    r15,r14
    72ee5f9fd146:	add    r15,0x100
    72ee5f9fd14d:	mov    rbp,r15
    72ee5f9fd150:	add    rbp,0x10
    72ee5f9fd154:	movdqu XMMWORD PTR [r15],xmm2
    72ee5f9fd159:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    72ee5f9fd15e:	mov    r15,r14
    72ee5f9fd161:	add    r15,0x40
    72ee5f9fd165:	mov    rbp,r15
    72ee5f9fd168:	add    rbp,0x10
    72ee5f9fd16c:	movdqu XMMWORD PTR [r15],xmm6
    72ee5f9fd171:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    72ee5f9fd176:	mov    r15d,0x4205e0
    72ee5f9fd17c:	movdqu xmm2,XMMWORD PTR [r15]
    72ee5f9fd181:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72ee5f9fd18b:	mov    r15d,0x420640
    72ee5f9fd191:	movdqu xmm3,XMMWORD PTR [r15]
    72ee5f9fd196:	movdqu XMMWORD PTR [r12+0x150],xmm3
    72ee5f9fd1a0:	mov    r15d,0xf8d3
    72ee5f9fd1a6:	mov    QWORD PTR [r12+0x48],r15
    72ee5f9fd1ab:	mov    r15,r14
    72ee5f9fd1ae:	add    r15,0x60
    72ee5f9fd1b2:	mov    rbp,r15
    72ee5f9fd1b5:	add    rbp,0x10
    72ee5f9fd1b9:	movdqu XMMWORD PTR [r15],xmm5
    72ee5f9fd1be:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72ee5f9fd1c3:	mov    r15d,0x420650
    72ee5f9fd1c9:	movdqu xmm2,XMMWORD PTR [r15]
    72ee5f9fd1ce:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72ee5f9fd1d8:	mov    r15d,0x420620
    72ee5f9fd1de:	movdqu xmm4,XMMWORD PTR [r15]
    72ee5f9fd1e3:	movdqu XMMWORD PTR [r12+0x140],xmm4
    72ee5f9fd1ed:	mov    r15d,0xf8d3
    72ee5f9fd1f3:	mov    ebp,0x421d
    72ee5f9fd1f8:	and    ebp,0xffff
    72ee5f9fd1fe:	mov    rax,r15
    72ee5f9fd201:	movabs rcx,0xffffffff0000ffff
    72ee5f9fd20b:	and    rax,rcx
    72ee5f9fd20e:	mov    rdx,rbp
    72ee5f9fd211:	shl    rdx,0x10
    72ee5f9fd215:	mov    ecx,0xffff0000
    72ee5f9fd21a:	and    rdx,rcx
    72ee5f9fd21d:	or     rax,rdx
    72ee5f9fd220:	mov    r8d,eax
    72ee5f9fd223:	mov    QWORD PTR [r12+0x48],r8
    72ee5f9fd228:	mov    r15,r14
    72ee5f9fd22b:	add    r15,0x80
    72ee5f9fd232:	mov    rbp,r15
    72ee5f9fd235:	add    rbp,0x10
    72ee5f9fd239:	movdqu XMMWORD PTR [r15],xmm3
    72ee5f9fd23e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72ee5f9fd243:	mov    r15d,0x4206c0
    72ee5f9fd249:	movdqu xmm2,XMMWORD PTR [r15]
    72ee5f9fd24e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72ee5f9fd258:	mov    r15d,0x4206d0
    72ee5f9fd25e:	movdqu xmm3,XMMWORD PTR [r15]
    72ee5f9fd263:	movdqu XMMWORD PTR [r12+0x150],xmm3
    72ee5f9fd26d:	mov    r15d,0x3e8
    72ee5f9fd273:	mov    QWORD PTR [r12+0xa0],r15
    72ee5f9fd27b:	mov    r15,r14
    72ee5f9fd27e:	add    r15,0xa0
    72ee5f9fd285:	mov    rbp,r15
    72ee5f9fd288:	add    rbp,0x10
    72ee5f9fd28c:	movdqu XMMWORD PTR [r15],xmm4
    72ee5f9fd291:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72ee5f9fd296:	mov    r15d,0x4206b0
    72ee5f9fd29c:	movdqu xmm2,XMMWORD PTR [r15]
    72ee5f9fd2a1:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72ee5f9fd2ab:	mov    r15d,0x420660
    72ee5f9fd2b1:	movdqu xmm4,XMMWORD PTR [r15]
    72ee5f9fd2b6:	movdqu XMMWORD PTR [r12+0x140],xmm4
    72ee5f9fd2c0:	mov    r15,r13
    72ee5f9fd2c3:	add    r15,0x80
    72ee5f9fd2ca:	mov    rbp,QWORD PTR [r12+0xf0]
    72ee5f9fd2d2:	mov    QWORD PTR [r15],rbp
    72ee5f9fd2d5:	mov    r15,r14
    72ee5f9fd2d8:	add    r15,0xc0
    72ee5f9fd2df:	mov    rbp,r15
    72ee5f9fd2e2:	add    rbp,0x10
    72ee5f9fd2e6:	movdqu XMMWORD PTR [r15],xmm3
    72ee5f9fd2eb:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72ee5f9fd2f0:	mov    r15d,0x420680
    72ee5f9fd2f6:	movdqu xmm2,XMMWORD PTR [r15]
    72ee5f9fd2fb:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72ee5f9fd305:	mov    r15d,0x4206e0
    72ee5f9fd30b:	mov    rbp,QWORD PTR [r15]
    72ee5f9fd30e:	mov    r15d,0x0
    72ee5f9fd314:	mov    QWORD PTR [r12+0x110],rbp
    72ee5f9fd31c:	mov    QWORD PTR [r12+0x118],r15
    72ee5f9fd324:	mov    r15d,0x4206e8
    72ee5f9fd32a:	mov    QWORD PTR [r12+0x40],r15
    72ee5f9fd32f:	mov    r15,r14
    72ee5f9fd332:	add    r15,0xe0
    72ee5f9fd339:	mov    r9,r15
    72ee5f9fd33c:	add    r9,0x10
    72ee5f9fd340:	movdqu XMMWORD PTR [r15],xmm4
    72ee5f9fd345:	movdqu XMMWORD PTR [r9],xmm2
    72ee5f9fd34a:	mov    r15d,0x420748
    72ee5f9fd350:	movdqu xmm2,XMMWORD PTR [r15]
    72ee5f9fd355:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72ee5f9fd35f:	mov    r15,r14
    72ee5f9fd362:	add    r15,0x120
    72ee5f9fd369:	mov    QWORD PTR [r15],rbp
    72ee5f9fd36c:	mov    r15d,0x420728
    72ee5f9fd372:	mov    ebp,0x420738
    72ee5f9fd377:	movdqu xmm3,XMMWORD PTR [r15]
    72ee5f9fd37c:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    72ee5f9fd381:	movdqu XMMWORD PTR [r12+0x120],xmm3
    72ee5f9fd38b:	movdqu XMMWORD PTR [r12+0x110],xmm4
    72ee5f9fd395:	mov    r15,r13
    72ee5f9fd398:	add    r15,0x60
    72ee5f9fd39c:	movdqu XMMWORD PTR [r15],xmm2
    72ee5f9fd3a1:	mov    r15,r14
    72ee5f9fd3a4:	add    r15,0x128
    72ee5f9fd3ab:	mov    DWORD PTR [r15],r8d
    72ee5f9fd3ae:	mov    r15,r13
    72ee5f9fd3b1:	add    r15,0x40
    72ee5f9fd3b5:	mov    rbp,r15
    72ee5f9fd3b8:	add    rbp,0x10
    72ee5f9fd3bc:	movdqu XMMWORD PTR [r15],xmm3
    72ee5f9fd3c1:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    72ee5f9fd3c6:	mov    r15d,0x4206e8
    72ee5f9fd3cc:	mov    ebp,0x4206f8
    72ee5f9fd3d1:	movdqu xmm2,XMMWORD PTR [r15]
    72ee5f9fd3d6:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72ee5f9fd3db:	movdqu XMMWORD PTR [r12+0x110],xmm2
    72ee5f9fd3e5:	movdqu XMMWORD PTR [r12+0x120],xmm3
    72ee5f9fd3ef:	mov    r15,r13
    72ee5f9fd3f2:	add    r15,0x10
    72ee5f9fd3f6:	movdqu XMMWORD PTR [r13+0x0],xmm2
    72ee5f9fd3fc:	movdqu XMMWORD PTR [r15],xmm3
    72ee5f9fd401:	mov    r15d,0x420708
    72ee5f9fd407:	mov    ebp,0x420718
    72ee5f9fd40c:	movdqu xmm2,XMMWORD PTR [r15]
    72ee5f9fd411:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72ee5f9fd416:	movdqu XMMWORD PTR [r12+0x110],xmm2
    72ee5f9fd420:	movdqu XMMWORD PTR [r12+0x130],xmm3
    72ee5f9fd42a:	mov    r15,r13
    72ee5f9fd42d:	add    r15,0x20
    72ee5f9fd431:	mov    rbp,r15
    72ee5f9fd434:	add    rbp,0x10
    72ee5f9fd438:	movdqu XMMWORD PTR [r15],xmm2
    72ee5f9fd43d:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    72ee5f9fd442:	mov    QWORD PTR [r12],r13
    72ee5f9fd446:	mov    r13d,0x0
    72ee5f9fd44c:	or     r13,r14
    72ee5f9fd44f:	mov    QWORD PTR [r12+0x8],r13
    72ee5f9fd454:	mov    r13d,0x12c
    72ee5f9fd45a:	mov    QWORD PTR [r12+0x10],r13
    72ee5f9fd45f:	mov    r13d,0x410274
    72ee5f9fd465:	mov    QWORD PTR [r12+0xf0],r13
    72ee5f9fd46d:	mov    r13d,0x410338
    72ee5f9fd473:	mov    QWORD PTR [r12+0x100],r13
    72ee5f9fd47b:	mov    r11,QWORD PTR [rsp]
    72ee5f9fd47f:	mov    QWORD PTR [r12+0x398],r11
    72ee5f9fd487:	mov    edi,0x410338
    72ee5f9fd48c:	mov    QWORD PTR [r12+0x100],rdi
    72ee5f9fd494:	add    rsp,0x10
    72ee5f9fd498:	jmp    QWORD PTR [rip+0x2]        # 0x72ee5f9fd4a0
    72ee5f9fd49e:	xchg   ax,ax
    72ee5f9fd4a0:	rcl    ah,0x9f
    72ee5f9fd4a3:	pop    rdi
    72ee5f9fd4a4:	out    dx,al
    72ee5f9fd4a5:	jb     0x72ee5f9fd4a7
    72ee5f9fd4a7:	add    BYTE PTR [rax-0x11a0602c],dh
    72ee5f9fd4ad:	jb     0x72ee5f9fd4af
    72ee5f9fd4af:	add    BYTE PTR [rcx-0x45],cl
    72ee5f9fd4b2:	rex cdq
    72ee5f9fd4b4:	fiadd  DWORD PTR [rsp+rdx*4+0x5c]
    72ee5f9fd4b8:	add    BYTE PTR [rax],al
    72ee5f9fd4ba:	jmp    r11
    72ee5f9fd4bd:	nop
    72ee5f9fd4be:	nop
    72ee5f9fd4bf:	nop
