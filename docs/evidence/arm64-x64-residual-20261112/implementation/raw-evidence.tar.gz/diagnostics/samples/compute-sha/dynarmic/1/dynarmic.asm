00007df2bcdce69b  nop [rax+rax*1], eax
00007df2bcdce6a0  mov rax, [r15+0xF8]
00007df2bcdce6a7  lea r14, [rax-0xA0]
00007df2bcdce6ae  mov [r15+0xF8], r14
00007df2bcdce6b5  lea rax, [r14+0x90]
00007df2bcdce6bc  mov r12, [r15+0xA0]
00007df2bcdce6c3  mov r11, [r15+0x98]
00007df2bcdce6ca  mov [r13+rax*1], r12
00007df2bcdce6cf  lea rax, [r14+0x98]
00007df2bcdce6d6  mov [r13+rax*1], r11
00007df2bcdce6db  mov eax, 0x420670
00007df2bcdce6e0  movups xmm1, [r13+rax*1]
00007df2bcdce6e6  mov eax, 0x420610
00007df2bcdce6eb  movups xmm15, [r13+rax*1]
00007df2bcdce6f1  mov eax, 0x420690
00007df2bcdce6f6  movups xmm14, [r13+rax*1]
00007df2bcdce6fc  mov eax, 0x420630
00007df2bcdce701  movups xmm13, [r13+rax*1]
00007df2bcdce707  mov qword ptr [r15+0x98], 0x4308A0
00007df2bcdce712  mov eax, 0x4206A0
00007df2bcdce717  movups xmm12, [r13+rax*1]
00007df2bcdce71d  mov eax, 0x4308A0
00007df2bcdce722  movups [r13+rax*1], xmm1
00007df2bcdce728  mov eax, 0x4308B0
00007df2bcdce72d  movups [r13+rax*1], xmm15
00007df2bcdce733  mov eax, 0x4308C0
00007df2bcdce738  movups [r13+rax*1], xmm14
00007df2bcdce73e  mov eax, 0x4308D0
00007df2bcdce743  movups [r13+rax*1], xmm13
00007df2bcdce749  mov eax, 0x420600
00007df2bcdce74e  movups xmm14, [r13+rax*1]
00007df2bcdce754  mov eax, 0x4205F0
00007df2bcdce759  movups xmm13, [r13+rax*1]
00007df2bcdce75f  mov eax, 0x4309A0
00007df2bcdce764  movups [r13+rax*1], xmm1
00007df2bcdce76a  mov eax, 0x4309B0
00007df2bcdce76f  movups [r13+rax*1], xmm15
00007df2bcdce775  mov eax, 0x4308E0
00007df2bcdce77a  movups [r13+rax*1], xmm12
00007df2bcdce780  mov eax, 0x4308F0
00007df2bcdce785  movups [r13+rax*1], xmm14
00007df2bcdce78b  mov eax, 0x4205E0
00007df2bcdce790  movups xmm1, [r13+rax*1]
00007df2bcdce796  mov eax, 0x420640
00007df2bcdce79b  movups xmm15, [r13+rax*1]
00007df2bcdce7a1  mov eax, 0x430900
00007df2bcdce7a6  movups [r13+rax*1], xmm13
00007df2bcdce7ac  mov eax, 0x430910
00007df2bcdce7b1  movups [r13+rax*1], xmm1
00007df2bcdce7b7  mov eax, 0x420650
00007df2bcdce7bc  movups xmm1, [r13+rax*1]
00007df2bcdce7c2  mov eax, 0x420620
00007df2bcdce7c7  movups xmm14, [r13+rax*1]
00007df2bcdce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007df2bcdce7d5  mov eax, 0x430920
00007df2bcdce7da  movups [r13+rax*1], xmm15
00007df2bcdce7e0  mov eax, 0x430930
00007df2bcdce7e5  movups [r13+rax*1], xmm1
00007df2bcdce7eb  mov eax, 0x4206C0
00007df2bcdce7f0  movups xmm1, [r13+rax*1]
00007df2bcdce7f6  mov eax, 0x4206D0
00007df2bcdce7fb  movups xmm15, [r13+rax*1]
00007df2bcdce801  movaps [r15+0x150], xmm15
00007df2bcdce809  mov qword ptr [r15+0xA0], 0x3E8
00007df2bcdce814  mov eax, 0x430940
00007df2bcdce819  movups [r13+rax*1], xmm14
00007df2bcdce81f  mov eax, 0x430950
00007df2bcdce824  movups [r13+rax*1], xmm1
00007df2bcdce82a  mov eax, 0x4206B0
00007df2bcdce82f  movups xmm1, [r13+rax*1]
00007df2bcdce835  mov eax, 0x420660
00007df2bcdce83a  movups xmm14, [r13+rax*1]
00007df2bcdce840  movaps [r15+0x140], xmm14
00007df2bcdce848  lea rax, [r14+0x80]
00007df2bcdce84f  mov r12, [r15+0xF0]
00007df2bcdce856  mov [r13+rax*1], r12
00007df2bcdce85b  mov eax, 0x430960
00007df2bcdce860  movups [r13+rax*1], xmm15
00007df2bcdce866  mov eax, 0x430970
00007df2bcdce86b  movups [r13+rax*1], xmm1
00007df2bcdce871  mov eax, 0x420680
00007df2bcdce876  movups xmm1, [r13+rax*1]
00007df2bcdce87c  mov eax, 0x4206E0
00007df2bcdce881  mov r12, [r13+rax*1]
00007df2bcdce886  movq xmm15, r12
00007df2bcdce88b  mov qword ptr [r15+0x40], 0x4206E8
00007df2bcdce893  mov eax, 0x430980
00007df2bcdce898  movups [r13+rax*1], xmm14
00007df2bcdce89e  mov eax, 0x430990
00007df2bcdce8a3  movups [r13+rax*1], xmm1
00007df2bcdce8a9  mov eax, 0x420748
00007df2bcdce8ae  movups xmm1, [r13+rax*1]
00007df2bcdce8b4  movq rax, xmm15
00007df2bcdce8b9  mov r12d, 0x4309C0
00007df2bcdce8bf  mov [r13+r12*1], rax
00007df2bcdce8c4  mov eax, 0x420728
00007df2bcdce8c9  movups xmm15, [r13+rax*1]
00007df2bcdce8cf  mov eax, 0x420738
00007df2bcdce8d4  movups xmm14, [r13+rax*1]
00007df2bcdce8da  lea rax, [r14+0x60]
00007df2bcdce8de  movups [r13+rax*1], xmm1
00007df2bcdce8e4  mov eax, 0x4309C8
00007df2bcdce8e9  mov r12d, 0x421DF8D3
00007df2bcdce8ef  mov [r13+rax*1], r12d
00007df2bcdce8f4  lea rax, [r14+0x40]
00007df2bcdce8f8  movups [r13+rax*1], xmm15
00007df2bcdce8fe  lea rax, [r14+0x50]
00007df2bcdce902  movups [r13+rax*1], xmm14
00007df2bcdce908  mov eax, 0x4206E8
00007df2bcdce90d  movups xmm1, [r13+rax*1]
00007df2bcdce913  mov eax, 0x4206F8
00007df2bcdce918  movups xmm15, [r13+rax*1]
00007df2bcdce91e  movaps [r15+0x120], xmm15
00007df2bcdce926  movups [r13+r14*1], xmm1
00007df2bcdce92c  lea rax, [r14+0x10]
00007df2bcdce930  movups [r13+rax*1], xmm15
00007df2bcdce936  mov eax, 0x420708
00007df2bcdce93b  movups xmm1, [r13+rax*1]
00007df2bcdce941  mov eax, 0x420718
00007df2bcdce946  movups xmm15, [r13+rax*1]
00007df2bcdce94c  movaps [r15+0x110], xmm1
00007df2bcdce954  movaps [r15+0x130], xmm15
00007df2bcdce95c  lea rax, [r14+0x20]
00007df2bcdce960  movups [r13+rax*1], xmm1
00007df2bcdce966  lea rax, [r14+0x30]
00007df2bcdce96a  movups [r13+rax*1], xmm15
00007df2bcdce970  mov [r15], r14
00007df2bcdce973  mov qword ptr [r15+0x08], 0x4308A0
00007df2bcdce97b  mov qword ptr [r15+0x10], 0x12C
00007df2bcdce983  mov qword ptr [r15+0xF0], 0x410274
00007df2bcdce98e  mov r14d, [r15+0x320]
00007df2bcdce995  mov eax, 0x410274
00007df2bcdce99a  mov rcx, 0x7DF2BCDD0670
00007df2bcdce9a4  mov [r15+r14*8+0x328], rax
00007df2bcdce9ac  mov [r15+r14*8+0x368], rcx
00007df2bcdce9b4  add r14d, 0x01
00007df2bcdce9b8  and r14d, 0x07
00007df2bcdce9bc  mov [r15+0x320], r14d
00007df2bcdce9c3  cmp dword ptr [r15+0x318], 0x00
00007df2bcdce9cb  jz 0x00007DF2BCDCEC20
00007df2bcdce9d1  nop [rax+rax*1], ax
00007df2bcdce9da  nop [rax+rax*1], eax
00007df2bcdce9e2  mov eax, 0x410338
00007df2bcdce9e7  mov [r15+0x100], rax
00007df2bcdce9ee  jmp 0x00007DF2BCBFE110
00007df2bcdce9f3  int3
00007df2bcdce9f4  call 0x00007DF2BCC0BC20
00007df2bcdce9f9  jmp 0x00007DF2BCDCE6CF
00007df2bcdce9fe  call 0x00007DF2BCC0A9A0
00007df2bcdcea03  jmp 0x00007DF2BCDCE6DB
00007df2bcdcea08  call 0x00007DF2BCBFF430
00007df2bcdcea0d  jmp 0x00007DF2BCDCE6E6
00007df2bcdcea12  call 0x00007DF2BCC0E760
00007df2bcdcea17  jmp 0x00007DF2BCDCE6F1
00007df2bcdcea1c  call 0x00007DF2BCC0D4E0
00007df2bcdcea21  jmp 0x00007DF2BCDCE6FC
00007df2bcdcea26  call 0x00007DF2BCC0C260
00007df2bcdcea2b  jmp 0x00007DF2BCDCE707
00007df2bcdcea30  call 0x00007DF2BCC0AFE0
00007df2bcdcea35  jmp 0x00007DF2BCDCE71D
00007df2bcdcea3a  call 0x00007DF2BCBFF540
00007df2bcdcea3f  jmp 0x00007DF2BCDCE728
00007df2bcdcea44  call 0x00007DF2BCC0E880
00007df2bcdcea49  jmp 0x00007DF2BCDCE733
00007df2bcdcea4e  call 0x00007DF2BCC0D600
00007df2bcdcea53  jmp 0x00007DF2BCDCE73E
00007df2bcdcea58  call 0x00007DF2BCC0C380
00007df2bcdcea5d  jmp 0x00007DF2BCDCE749
00007df2bcdcea62  call 0x00007DF2BCC0D4E0
00007df2bcdcea67  jmp 0x00007DF2BCDCE754
00007df2bcdcea6c  call 0x00007DF2BCC0C260
00007df2bcdcea71  jmp 0x00007DF2BCDCE75F
00007df2bcdcea76  call 0x00007DF2BCBFF540
00007df2bcdcea7b  jmp 0x00007DF2BCDCE76A
00007df2bcdcea80  call 0x00007DF2BCC0E880
00007df2bcdcea85  jmp 0x00007DF2BCDCE775
00007df2bcdcea8a  call 0x00007DF2BCC0B100
00007df2bcdcea8f  jmp 0x00007DF2BCDCE780
00007df2bcdcea94  call 0x00007DF2BCC0D600
00007df2bcdcea99  jmp 0x00007DF2BCDCE78B
00007df2bcdcea9e  call 0x00007DF2BCBFF430
00007df2bcdceaa3  jmp 0x00007DF2BCDCE796
00007df2bcdceaa8  call 0x00007DF2BCC0E760
00007df2bcdceaad  jmp 0x00007DF2BCDCE7A1
00007df2bcdceab2  call 0x00007DF2BCC0C380
00007df2bcdceab7  jmp 0x00007DF2BCDCE7AC
00007df2bcdceabc  call 0x00007DF2BCBFF540
00007df2bcdceac1  jmp 0x00007DF2BCDCE7B7
00007df2bcdceac6  call 0x00007DF2BCBFF430
00007df2bcdceacb  jmp 0x00007DF2BCDCE7C2
00007df2bcdcead0  call 0x00007DF2BCC0D4E0
00007df2bcdcead5  jmp 0x00007DF2BCDCE7CD
00007df2bcdceada  call 0x00007DF2BCC0E880
00007df2bcdceadf  jmp 0x00007DF2BCDCE7E0
00007df2bcdceae4  call 0x00007DF2BCBFF540
00007df2bcdceae9  jmp 0x00007DF2BCDCE7EB
00007df2bcdceaee  call 0x00007DF2BCBFF430
00007df2bcdceaf3  jmp 0x00007DF2BCDCE7F6
00007df2bcdceaf8  call 0x00007DF2BCC0E760
00007df2bcdceafd  jmp 0x00007DF2BCDCE801
00007df2bcdceb02  call 0x00007DF2BCC0D600
00007df2bcdceb07  jmp 0x00007DF2BCDCE81F
00007df2bcdceb0c  call 0x00007DF2BCBFF540
00007df2bcdceb11  jmp 0x00007DF2BCDCE82A
00007df2bcdceb16  call 0x00007DF2BCBFF430
00007df2bcdceb1b  jmp 0x00007DF2BCDCE835
00007df2bcdceb20  call 0x00007DF2BCC0D4E0
00007df2bcdceb25  jmp 0x00007DF2BCDCE840
00007df2bcdceb2a  call 0x00007DF2BCC0BC20
00007df2bcdceb2f  jmp 0x00007DF2BCDCE85B
00007df2bcdceb34  call 0x00007DF2BCC0E880
00007df2bcdceb39  jmp 0x00007DF2BCDCE866
00007df2bcdceb3e  call 0x00007DF2BCBFF540
00007df2bcdceb43  jmp 0x00007DF2BCDCE871
00007df2bcdceb48  call 0x00007DF2BCBFF430
00007df2bcdceb4d  jmp 0x00007DF2BCDCE87C
00007df2bcdceb52  call 0x00007DF2BCC0B720
00007df2bcdceb57  jmp 0x00007DF2BCDCE886
00007df2bcdceb5c  call 0x00007DF2BCC0D600
00007df2bcdceb61  jmp 0x00007DF2BCDCE89E
00007df2bcdceb66  call 0x00007DF2BCBFF540
00007df2bcdceb6b  jmp 0x00007DF2BCDCE8A9
00007df2bcdceb70  call 0x00007DF2BCBFF430
00007df2bcdceb75  jmp 0x00007DF2BCDCE8B4
00007df2bcdceb7a  call 0x00007DF2BCCB4CB0
00007df2bcdceb7f  jmp 0x00007DF2BCDCE8C4
00007df2bcdceb84  call 0x00007DF2BCC0E760
00007df2bcdceb89  jmp 0x00007DF2BCDCE8CF
00007df2bcdceb8e  call 0x00007DF2BCC0D4E0
00007df2bcdceb93  jmp 0x00007DF2BCDCE8DA
00007df2bcdceb98  call 0x00007DF2BCBFF540
00007df2bcdceb9d  jmp 0x00007DF2BCDCE8E4
00007df2bcdceba2  call 0x00007DF2BCC0BAE0
00007df2bcdceba7  jmp 0x00007DF2BCDCE8F4
00007df2bcdcebac  call 0x00007DF2BCC0E880
00007df2bcdcebb1  jmp 0x00007DF2BCDCE8FE
00007df2bcdcebb6  call 0x00007DF2BCC0D600
00007df2bcdcebbb  jmp 0x00007DF2BCDCE908
00007df2bcdcebc0  call 0x00007DF2BCBFF430
00007df2bcdcebc5  jmp 0x00007DF2BCDCE913
00007df2bcdcebca  call 0x00007DF2BCC0E760
00007df2bcdcebcf  jmp 0x00007DF2BCDCE91E
00007df2bcdcebd4  call 0x00007DF2BCCD6600
00007df2bcdcebd9  jmp 0x00007DF2BCDCE92C
00007df2bcdcebde  call 0x00007DF2BCC0E880
00007df2bcdcebe3  jmp 0x00007DF2BCDCE936
00007df2bcdcebe8  call 0x00007DF2BCBFF430
00007df2bcdcebed  jmp 0x00007DF2BCDCE941
00007df2bcdcebf2  call 0x00007DF2BCC0E760
00007df2bcdcebf7  jmp 0x00007DF2BCDCE94C
00007df2bcdcebfc  call 0x00007DF2BCBFF540
00007df2bcdcec01  jmp 0x00007DF2BCDCE966
00007df2bcdcec06  call 0x00007DF2BCC0E880
00007df2bcdcec0b  jmp 0x00007DF2BCDCE970
00007df2bcdcec10  int3
00007df2bcdcec11  nop [rax+rax*1], ax
00007df2bcdcec1a  nop [rax+rax*1], ax
00007df2bcdcec20  mov rax, [r15]
00007df2bcdcec23  lea r14, [rax+0x20]
00007df2bcdcec27  mov r12, [r13+r14*1]
00007df2bcdcec2c  mov r14, [r15+0x10]
00007df2bcdcec30  lea r11, [r12+r14*1]
00007df2bcdcec34  mov [r15+0x40], r11
00007df2bcdcec38  lea r12, [rax+0x20]
00007df2bcdcec3c  mov [r13+r12*1], r11
00007df2bcdcec41  test r14, r14
00007df2bcdcec44  setz r14b
00007df2bcdcec48  movzx r14, r14b
00007df2bcdcec4c  mov [rsp+0x414], r14b
00007df2bcdcec54  cmp byte ptr [rsp+0x414], 0x00
00007df2bcdcec5c  jz 0x00007DF2BCDCEC8E
00007df2bcdcec5e  cmp dword ptr [r15+0x318], 0x00
00007df2bcdcec66  mov eax, 0x4105B0
00007df2bcdcec6b  mov [r15+0x100], rax
00007df2bcdcec72  jz 0x00007DF2BCBFE0A0
00007df2bcdcec78  nop [rax+rax*1], eax
00007df2bcdcec7d  mov eax, 0x4105B0
00007df2bcdcec82  mov [r15+0x100], rax
00007df2bcdcec89  jmp 0x00007DF2BCBFE110
00007df2bcdcec8e  cmp dword ptr [r15+0x318], 0x00
00007df2bcdcec96  jz 0x00007DF2BCDCECE0
00007df2bcdcec9c  nop [rax+rax*1], ax
00007df2bcdceca5  nop [rax+rax*1], eax
00007df2bcdcecad  mov eax, 0x410348
00007df2bcdcecb2  mov [r15+0x100], rax
00007df2bcdcecb9  jmp 0x00007DF2BCBFE110
00007df2bcdcecbe  int3
00007df2bcdcecbf  call 0x00007DF2BCCE27E0
00007df2bcdcecc4  jmp 0x00007DF2BCDCEC2C
00007df2bcdcecc9  call 0x00007DF2BCCC0860
00007df2bcdcecce  jmp 0x00007DF2BCDCEC41
00007df2bcdcecd3  int3
00007df2bcdcecd4  nop [rax+rax*1], ax
00007df2bcdcecdd  nop [rax], eax
00007df2bcdcece0  mov rax, [r15+0xF8]
00007df2bcdcece7  lea r14, [rax-0x150]
00007df2bcdcecee  mov [r15+0xF8], r14
00007df2bcdcecf5  mov rax, [r15]
00007df2bcdcecf8  lea r12, [rax+0x68]
00007df2bcdcecfc  mov r11, [r13+r12*1]
00007df2bcdced01  mov [r15+0x88], r11
00007df2bcdced08  lea r12, [rax+0x28]
00007df2bcdced0c  mov [r15+0x40], r12
00007df2bcdced10  mov [r15+0x48], r14
00007df2bcdced14  mov qword ptr [r15+0x50], 0x420758
00007df2bcdced1c  lea rax, [r14+0x100]
00007df2bcdced23  mov r12, [r15+0xE8]
00007df2bcdced2a  mov r11, [r15+0xD8]
00007df2bcdced31  mov [r13+rax*1], r12
00007df2bcdced36  lea rax, [r14+0x108]
00007df2bcdced3d  mov [r13+rax*1], r11
00007df2bcdced42  lea rax, [r14+0x110]
00007df2bcdced49  mov r12, [r15+0xD0]
00007df2bcdced50  mov r11, [r15+0xC8]
00007df2bcdced57  mov [r13+rax*1], r12
00007df2bcdced5c  lea rax, [r14+0x118]
00007df2bcdced63  mov [r13+rax*1], r11
00007df2bcdced68  lea rax, [r14+0x120]
00007df2bcdced6f  mov r12, [r15+0xC0]
00007df2bcdced76  mov r11, [r15+0xB8]
00007df2bcdced7d  mov [r13+rax*1], r12
00007df2bcdced82  lea rax, [r14+0x128]
00007df2bcdced89  mov [r13+rax*1], r11
00007df2bcdced8e  lea rax, [r14+0x130]
00007df2bcdced95  mov r12, [r15+0xB0]
00007df2bcdced9c  mov r11, [r15+0xA8]
00007df2bcdceda3  mov [r13+rax*1], r12
00007df2bcdceda8  lea rax, [r14+0x138]
00007df2bcdcedaf  mov [r13+rax*1], r11
00007df2bcdcedb4  lea rax, [r14+0x140]
00007df2bcdcedbb  mov r12, [r15+0xA0]
00007df2bcdcedc2  mov r11, [r15+0x98]
00007df2bcdcedc9  mov [r13+rax*1], r12
00007df2bcdcedce  lea rax, [r14+0x148]
00007df2bcdcedd5  mov [r13+rax*1], r11
00007df2bcdcedda  cmp dword ptr [r15+0x318], 0x00
00007df2bcdcede2  jz 0x00007DF2BCDCEE80
00007df2bcdcede8  nop [rax+rax*1], ax
00007df2bcdcedf1  nop [rax+rax*1], eax
00007df2bcdcedf9  mov eax, 0x410380
00007df2bcdcedfe  mov [r15+0x100], rax
00007df2bcdcee05  jmp 0x00007DF2BCBFE110
00007df2bcdcee0a  int3
00007df2bcdcee0b  call 0x00007DF2BCCC0370
00007df2bcdcee10  jmp 0x00007DF2BCDCED01
00007df2bcdcee15  call 0x00007DF2BCC0BC20
00007df2bcdcee1a  jmp 0x00007DF2BCDCED36
00007df2bcdcee1f  call 0x00007DF2BCC0A9A0
00007df2bcdcee24  jmp 0x00007DF2BCDCED42
00007df2bcdcee29  call 0x00007DF2BCC0BC20
00007df2bcdcee2e  jmp 0x00007DF2BCDCED5C
00007df2bcdcee33  call 0x00007DF2BCC0A9A0
00007df2bcdcee38  jmp 0x00007DF2BCDCED68
00007df2bcdcee3d  call 0x00007DF2BCC0BC20
00007df2bcdcee42  jmp 0x00007DF2BCDCED82
00007df2bcdcee47  call 0x00007DF2BCC0A9A0
00007df2bcdcee4c  jmp 0x00007DF2BCDCED8E
00007df2bcdcee51  call 0x00007DF2BCC0BC20
00007df2bcdcee56  jmp 0x00007DF2BCDCEDA8
00007df2bcdcee5b  call 0x00007DF2BCC0A9A0
00007df2bcdcee60  jmp 0x00007DF2BCDCEDB4
00007df2bcdcee65  call 0x00007DF2BCC0BC20
00007df2bcdcee6a  jmp 0x00007DF2BCDCEDCE
00007df2bcdcee6f  call 0x00007DF2BCC0A9A0
00007df2bcdcee74  jmp 0x00007DF2BCDCEDDA
00007df2bcdcee79  int3
00007df2bcdcee7a  nop [rax+rax*1], ax
00007df2bcdcee80  mov rax, [r15+0x08]
00007df2bcdcee84  movzx r14d, byte ptr [r13+rax*1]
00007df2bcdcee8a  movzx r14d, r14b
00007df2bcdcee8e  mov [rsp+0x10], r14d
00007df2bcdcee93  mov r14d, r14d
00007df2bcdcee96  mov [r15+0x58], r14
00007df2bcdcee9a  lea r14, [rax+0x01]
00007df2bcdcee9e  mov [r15+0x08], r14
00007df2bcdceea2  mov rax, [r15+0x88]
00007df2bcdceea9  lea r14, [rax+0x01]
00007df2bcdceead  mov r12, [r15]
00007df2bcdceeb0  lea r11, [r12+0x68]
00007df2bcdceeb5  mov [r13+r11*1], r14
00007df2bcdceeba  lea r14, [r12+rax*1]
00007df2bcdceebe  mov [r15+0x60], r14
00007df2bcdceec2  lea rax, [r14+0x28]
00007df2bcdceec6  mov r11d, [rsp+0x10]
00007df2bcdceecb  movzx r14d, r11b
00007df2bcdceecf  mov [r13+rax*1], r14b
00007df2bcdceed4  lea rax, [r12+0x68]
00007df2bcdceed9  mov r14, [r13+rax*1]
00007df2bcdceede  mov [r15+0x88], r14
00007df2bcdceee5  xor eax, eax
00007df2bcdceee7  mov r12d, 0x40
00007df2bcdceeed  cmp r14, r12
00007df2bcdceef0  cmc
00007df2bcdceef1  lahf
00007df2bcdceef2  seto al
00007df2bcdceef5  mov [r15+0x108], eax
00007df2bcdceefc  mov eax, [r15+0x108]
00007df2bcdcef03  sahf
00007df2bcdcef04  jnz 0x00007DF2BCDCEF36
00007df2bcdcef06  cmp dword ptr [r15+0x318], 0x00
00007df2bcdcef0e  jz 0x00007DF2BCDCF020
00007df2bcdcef14  nop [rax+rax*1], ax
00007df2bcdcef1d  nop [rax+rax*1], eax
00007df2bcdcef25  mov eax, 0x4103A0
00007df2bcdcef2a  mov [r15+0x100], rax
00007df2bcdcef31  jmp 0x00007DF2BCBFE110
00007df2bcdcef36  cmp dword ptr [r15+0x318], 0x00
00007df2bcdcef3e  jz 0x00007DF2BCDCEF90
00007df2bcdcef44  nop [rax+rax*1], ax
00007df2bcdcef4d  nop [rax+rax*1], eax
00007df2bcdcef55  mov eax, 0x410378
00007df2bcdcef5a  mov [r15+0x100], rax
00007df2bcdcef61  jmp 0x00007DF2BCBFE110
00007df2bcdcef66  int3
00007df2bcdcef67  call 0x00007DF2BCC0D860
00007df2bcdcef6c  jmp 0x00007DF2BCDCEE8A
00007df2bcdcef71  call 0x00007DF2BCCB36E0
00007df2bcdcef76  jmp 0x00007DF2BCDCEEBA
00007df2bcdcef7b  call 0x00007DF2BCC0DD60
00007df2bcdcef80  jmp 0x00007DF2BCDCEED4
00007df2bcdcef85  call 0x00007DF2BCC0DC20
00007df2bcdcef8a  jmp 0x00007DF2BCDCEEDE
00007df2bcdcef8f  int3
00007df2bcdcef90  mov rax, [r15+0x10]
00007df2bcdcef94  lea r14, [rax-0x01]
00007df2bcdcef98  mov [r15+0x10], r14
00007df2bcdcef9c  test r14, r14
00007df2bcdcef9f  setz r14b
00007df2bcdcefa3  movzx r14, r14b
00007df2bcdcefa7  mov [rsp+0x414], r14b
00007df2bcdcefaf  cmp byte ptr [rsp+0x414], 0x00
00007df2bcdcefb7  jz 0x00007DF2BCDCEFE9
00007df2bcdcefb9  cmp dword ptr [r15+0x318], 0x00
00007df2bcdcefc1  jz 0x00007DF2BCDD0520
00007df2bcdcefc7  nop [rax+rax*1], ax
00007df2bcdcefd0  nop [rax+rax*1], eax
00007df2bcdcefd8  mov eax, 0x410598
00007df2bcdcefdd  mov [r15+0x100], rax
00007df2bcdcefe4  jmp 0x00007DF2BCBFE110
00007df2bcdcefe9  cmp dword ptr [r15+0x318], 0x00
00007df2bcdceff1  jz 0x00007DF2BCDCEE80
00007df2bcdceff7  nop [rax+rax*1], ax
00007df2bcdcf000  nop [rax+rax*1], eax
00007df2bcdcf008  mov eax, 0x410380
00007df2bcdcf00d  mov [r15+0x100], rax
00007df2bcdcf014  jmp 0x00007DF2BCBFE110
00007df2bcdcf019  int3
00007df2bcdcf01a  int3
00007df2bcdcf01b  nop [rax+rax*1], eax
00007df2bcdcf020  mov rax, [r15+0x40]
00007df2bcdcf024  movzx r14d, byte ptr [r13+rax*1]
00007df2bcdcf02a  movaps xmm1, [r15+0x110]
00007df2bcdcf032  pinsrb xmm1, r14d, 0x00
00007df2bcdcf039  lea r14, [rax+0x01]
00007df2bcdcf03d  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf043  movaps xmm15, [r15+0x120]
00007df2bcdcf04b  pinsrb xmm15, r12d, 0x00
00007df2bcdcf052  lea r14, [rax+0x02]
00007df2bcdcf056  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf05c  movaps xmm14, [r15+0x130]
00007df2bcdcf064  pinsrb xmm14, r12d, 0x00
00007df2bcdcf06b  lea r14, [rax+0x03]
00007df2bcdcf06f  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf075  movaps xmm13, [r15+0x140]
00007df2bcdcf07d  pinsrb xmm13, r12d, 0x00
00007df2bcdcf084  lea r14, [rax+0x04]
00007df2bcdcf088  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf08e  pinsrb xmm1, r12d, 0x01
00007df2bcdcf095  lea r14, [rax+0x05]
00007df2bcdcf099  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf09f  pinsrb xmm15, r12d, 0x01
00007df2bcdcf0a6  lea r14, [rax+0x06]
00007df2bcdcf0aa  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf0b0  pinsrb xmm14, r12d, 0x01
00007df2bcdcf0b7  lea r14, [rax+0x07]
00007df2bcdcf0bb  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf0c1  pinsrb xmm13, r12d, 0x01
00007df2bcdcf0c8  lea r14, [rax+0x08]
00007df2bcdcf0cc  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf0d2  pinsrb xmm1, r12d, 0x02
00007df2bcdcf0d9  lea r14, [rax+0x09]
00007df2bcdcf0dd  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf0e3  pinsrb xmm15, r12d, 0x02
00007df2bcdcf0ea  lea r14, [rax+0x0A]
00007df2bcdcf0ee  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf0f4  pinsrb xmm14, r12d, 0x02
00007df2bcdcf0fb  lea r14, [rax+0x0B]
00007df2bcdcf0ff  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf105  pinsrb xmm13, r12d, 0x02
00007df2bcdcf10c  lea r14, [rax+0x0C]
00007df2bcdcf110  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf116  pinsrb xmm1, r12d, 0x03
00007df2bcdcf11d  lea r14, [rax+0x0D]
00007df2bcdcf121  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf127  pinsrb xmm15, r12d, 0x03
00007df2bcdcf12e  lea r14, [rax+0x0E]
00007df2bcdcf132  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf138  pinsrb xmm14, r12d, 0x03
00007df2bcdcf13f  lea r14, [rax+0x0F]
00007df2bcdcf143  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf149  pinsrb xmm13, r12d, 0x03
00007df2bcdcf150  lea r14, [rax+0x10]
00007df2bcdcf154  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf15a  pinsrb xmm1, r12d, 0x04
00007df2bcdcf161  lea r14, [rax+0x11]
00007df2bcdcf165  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf16b  pinsrb xmm15, r12d, 0x04
00007df2bcdcf172  lea r14, [rax+0x12]
00007df2bcdcf176  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf17c  pinsrb xmm14, r12d, 0x04
00007df2bcdcf183  lea r14, [rax+0x13]
00007df2bcdcf187  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf18d  pinsrb xmm13, r12d, 0x04
00007df2bcdcf194  lea r14, [rax+0x14]
00007df2bcdcf198  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf19e  pinsrb xmm1, r12d, 0x05
00007df2bcdcf1a5  lea r14, [rax+0x15]
00007df2bcdcf1a9  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf1af  pinsrb xmm15, r12d, 0x05
00007df2bcdcf1b6  lea r14, [rax+0x16]
00007df2bcdcf1ba  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf1c0  pinsrb xmm14, r12d, 0x05
00007df2bcdcf1c7  lea r14, [rax+0x17]
00007df2bcdcf1cb  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf1d1  pinsrb xmm13, r12d, 0x05
00007df2bcdcf1d8  lea r14, [rax+0x18]
00007df2bcdcf1dc  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf1e2  pinsrb xmm1, r12d, 0x06
00007df2bcdcf1e9  lea r14, [rax+0x19]
00007df2bcdcf1ed  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf1f3  pinsrb xmm15, r12d, 0x06
00007df2bcdcf1fa  lea r14, [rax+0x1A]
00007df2bcdcf1fe  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf204  pinsrb xmm14, r12d, 0x06
00007df2bcdcf20b  lea r14, [rax+0x1B]
00007df2bcdcf20f  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf215  pinsrb xmm13, r12d, 0x06
00007df2bcdcf21c  lea r14, [rax+0x1C]
00007df2bcdcf220  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf226  pinsrb xmm1, r12d, 0x07
00007df2bcdcf22d  lea r14, [rax+0x1D]
00007df2bcdcf231  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf237  pinsrb xmm15, r12d, 0x07
00007df2bcdcf23e  lea r14, [rax+0x1E]
00007df2bcdcf242  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf248  pinsrb xmm14, r12d, 0x07
00007df2bcdcf24f  lea r14, [rax+0x1F]
00007df2bcdcf253  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf259  pinsrb xmm13, r12d, 0x07
00007df2bcdcf260  lea r14, [rax+0x20]
00007df2bcdcf264  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf26a  pinsrb xmm1, r12d, 0x08
00007df2bcdcf271  lea r14, [rax+0x21]
00007df2bcdcf275  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf27b  pinsrb xmm15, r12d, 0x08
00007df2bcdcf282  lea r14, [rax+0x22]
00007df2bcdcf286  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf28c  pinsrb xmm14, r12d, 0x08
00007df2bcdcf293  lea r14, [rax+0x23]
00007df2bcdcf297  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf29d  pinsrb xmm13, r12d, 0x08
00007df2bcdcf2a4  lea r14, [rax+0x24]
00007df2bcdcf2a8  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf2ae  pinsrb xmm1, r12d, 0x09
00007df2bcdcf2b5  lea r14, [rax+0x25]
00007df2bcdcf2b9  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf2bf  pinsrb xmm15, r12d, 0x09
00007df2bcdcf2c6  lea r14, [rax+0x26]
00007df2bcdcf2ca  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf2d0  pinsrb xmm14, r12d, 0x09
00007df2bcdcf2d7  lea r14, [rax+0x27]
00007df2bcdcf2db  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf2e1  pinsrb xmm13, r12d, 0x09
00007df2bcdcf2e8  lea r14, [rax+0x28]
00007df2bcdcf2ec  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf2f2  pinsrb xmm1, r12d, 0x0A
00007df2bcdcf2f9  lea r14, [rax+0x29]
00007df2bcdcf2fd  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf303  pinsrb xmm15, r12d, 0x0A
00007df2bcdcf30a  lea r14, [rax+0x2A]
00007df2bcdcf30e  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf314  pinsrb xmm14, r12d, 0x0A
00007df2bcdcf31b  lea r14, [rax+0x2B]
00007df2bcdcf31f  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf325  pinsrb xmm13, r12d, 0x0A
00007df2bcdcf32c  lea r14, [rax+0x2C]
00007df2bcdcf330  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf336  pinsrb xmm1, r12d, 0x0B
00007df2bcdcf33d  lea r14, [rax+0x2D]
00007df2bcdcf341  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf347  pinsrb xmm15, r12d, 0x0B
00007df2bcdcf34e  lea r14, [rax+0x2E]
00007df2bcdcf352  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf358  pinsrb xmm14, r12d, 0x0B
00007df2bcdcf35f  lea r14, [rax+0x2F]
00007df2bcdcf363  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf369  pinsrb xmm13, r12d, 0x0B
00007df2bcdcf370  lea r14, [rax+0x30]
00007df2bcdcf374  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf37a  pinsrb xmm1, r12d, 0x0C
00007df2bcdcf381  lea r14, [rax+0x31]
00007df2bcdcf385  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf38b  pinsrb xmm15, r12d, 0x0C
00007df2bcdcf392  lea r14, [rax+0x32]
00007df2bcdcf396  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf39c  pinsrb xmm14, r12d, 0x0C
00007df2bcdcf3a3  lea r14, [rax+0x33]
00007df2bcdcf3a7  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf3ad  pinsrb xmm13, r12d, 0x0C
00007df2bcdcf3b4  lea r14, [rax+0x34]
00007df2bcdcf3b8  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf3be  pinsrb xmm1, r12d, 0x0D
00007df2bcdcf3c5  lea r14, [rax+0x35]
00007df2bcdcf3c9  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf3cf  pinsrb xmm15, r12d, 0x0D
00007df2bcdcf3d6  lea r14, [rax+0x36]
00007df2bcdcf3da  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf3e0  pinsrb xmm14, r12d, 0x0D
00007df2bcdcf3e7  lea r14, [rax+0x37]
00007df2bcdcf3eb  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf3f1  pinsrb xmm13, r12d, 0x0D
00007df2bcdcf3f8  lea r14, [rax+0x38]
00007df2bcdcf3fc  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf402  pinsrb xmm1, r12d, 0x0E
00007df2bcdcf409  lea r14, [rax+0x39]
00007df2bcdcf40d  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf413  pinsrb xmm15, r12d, 0x0E
00007df2bcdcf41a  lea r14, [rax+0x3A]
00007df2bcdcf41e  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf424  pinsrb xmm14, r12d, 0x0E
00007df2bcdcf42b  lea r14, [rax+0x3B]
00007df2bcdcf42f  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf435  pinsrb xmm13, r12d, 0x0E
00007df2bcdcf43c  lea r14, [rax+0x3C]
00007df2bcdcf440  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf446  pinsrb xmm1, r12d, 0x0F
00007df2bcdcf44d  movaps [r15+0x110], xmm1
00007df2bcdcf455  lea r14, [rax+0x3D]
00007df2bcdcf459  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf45f  pinsrb xmm15, r12d, 0x0F
00007df2bcdcf466  movaps [r15+0x120], xmm15
00007df2bcdcf46e  lea r14, [rax+0x3E]
00007df2bcdcf472  movzx r12d, byte ptr [r13+r14*1]
00007df2bcdcf478  pinsrb xmm14, r12d, 0x0F
00007df2bcdcf47f  movaps [r15+0x130], xmm14
00007df2bcdcf487  lea r14, [rax+0x3F]
00007df2bcdcf48b  movzx eax, byte ptr [r13+r14*1]
00007df2bcdcf491  pinsrb xmm13, eax, 0x0F
00007df2bcdcf498  movaps [r15+0x140], xmm13
00007df2bcdcf4a0  movq xmm1, qword ptr [r15+0x120]
00007df2bcdcf4a9  pmovzxbw xmm1, xmm1
00007df2bcdcf4ae  psllw xmm1, 0x00
00007df2bcdcf4b3  movaps [r15+0x150], xmm1
00007df2bcdcf4bb  movq xmm1, qword ptr [r15+0x130]
00007df2bcdcf4c4  pmovzxbw xmm1, xmm1
00007df2bcdcf4c9  psllw xmm1, 0x00
00007df2bcdcf4ce  movaps [r15+0x160], xmm1
00007df2bcdcf4d6  movq xmm1, qword ptr [r15+0x110]
00007df2bcdcf4df  pmovzxbw xmm1, xmm1
00007df2bcdcf4e4  psllw xmm1, 0x00
00007df2bcdcf4e9  movaps [r15+0x170], xmm1
00007df2bcdcf4f1  movaps xmm15, [r15+0x110]
00007df2bcdcf4f9  pextrq rax, xmm15, 0x01
00007df2bcdcf500  movq xmm15, rax
00007df2bcdcf505  pmovzxbw xmm15, xmm15
00007df2bcdcf50b  psllw xmm15, 0x00
00007df2bcdcf511  movaps [r15+0x180], xmm15
00007df2bcdcf519  movaps xmm14, [r15+0x120]
00007df2bcdcf521  pextrq rax, xmm14, 0x01
00007df2bcdcf528  movq xmm14, rax
00007df2bcdcf52d  pmovzxbw xmm14, xmm14
00007df2bcdcf533  psllw xmm14, 0x00
00007df2bcdcf539  movaps [r15+0x210], xmm14
00007df2bcdcf541  movaps xmm13, [r15+0x130]
00007df2bcdcf549  pextrq rax, xmm13, 0x01
00007df2bcdcf550  movq xmm13, rax
00007df2bcdcf555  pmovzxbw xmm13, xmm13
00007df2bcdcf55b  psllw xmm13, 0x00
00007df2bcdcf561  movaps [r15+0x220], xmm13
00007df2bcdcf569  movq xmm12, qword ptr [r15+0x140]
00007df2bcdcf572  pmovzxbw xmm12, xmm12
00007df2bcdcf578  psllw xmm12, 0x00
00007df2bcdcf57e  movaps [r15+0x250], xmm12
00007df2bcdcf586  movaps xmm12, [r15+0x140]
00007df2bcdcf58e  pextrq rax, xmm12, 0x01
00007df2bcdcf595  movq xmm12, rax
00007df2bcdcf59a  pmovzxbw xmm12, xmm12
00007df2bcdcf5a0  psllw xmm12, 0x00
00007df2bcdcf5a6  movaps [r15+0x110], xmm12
00007df2bcdcf5ae  movq xmm11, qword ptr [r15+0x150]
00007df2bcdcf5b7  pmovzxwd xmm11, xmm11
00007df2bcdcf5bd  pslld xmm11, 0x10
00007df2bcdcf5c3  movq xmm10, qword ptr [r15+0x160]
00007df2bcdcf5cc  pmovzxwd xmm10, xmm10
00007df2bcdcf5d2  pslld xmm10, 0x08
00007df2bcdcf5d8  pextrq rax, xmm1, 0x01
00007df2bcdcf5df  movq xmm1, rax
00007df2bcdcf5e4  pmovzxwd xmm1, xmm1
00007df2bcdcf5e9  pslld xmm1, 0x00
00007df2bcdcf5ee  movaps [r15+0x260], xmm1
00007df2bcdcf5f6  pextrq rax, xmm15, 0x01
00007df2bcdcf5fd  movq xmm15, rax
00007df2bcdcf602  pmovzxwd xmm15, xmm15
00007df2bcdcf608  pslld xmm15, 0x00
00007df2bcdcf60e  movaps [r15+0x270], xmm15
00007df2bcdcf616  movq xmm9, qword ptr [r15+0x170]
00007df2bcdcf61f  pmovzxwd xmm9, xmm9
00007df2bcdcf625  pslld xmm9, 0x00
00007df2bcdcf62b  pextrq rax, xmm14, 0x01
00007df2bcdcf632  movq xmm14, rax
00007df2bcdcf637  pmovzxwd xmm14, xmm14
00007df2bcdcf63d  pslld xmm14, 0x10
00007df2bcdcf643  movaps [r15+0x280], xmm14
00007df2bcdcf64b  movq xmm8, qword ptr [r15+0x180]
00007df2bcdcf654  pmovzxwd xmm8, xmm8
00007df2bcdcf65a  pslld xmm8, 0x00
00007df2bcdcf660  movq xmm7, qword ptr [r15+0x210]
00007df2bcdcf669  pmovzxwd xmm7, xmm7
00007df2bcdcf66e  pslld xmm7, 0x10
00007df2bcdcf673  movaps xmm6, [r15+0x150]
00007df2bcdcf67b  pextrq rax, xmm6, 0x01
00007df2bcdcf682  movq xmm6, rax
00007df2bcdcf687  pmovzxwd xmm6, xmm6
00007df2bcdcf68c  pslld xmm6, 0x10
00007df2bcdcf691  por xmm11, xmm10
00007df2bcdcf696  movaps [r15+0x230], xmm11
00007df2bcdcf69e  pextrq rax, xmm13, 0x01
00007df2bcdcf6a5  movq xmm13, rax
00007df2bcdcf6aa  pmovzxwd xmm13, xmm13
00007df2bcdcf6b0  pslld xmm13, 0x08
00007df2bcdcf6b6  movaps [r15+0x240], xmm13
00007df2bcdcf6be  movq xmm10, qword ptr [r15+0x220]
00007df2bcdcf6c7  pmovzxwd xmm10, xmm10
00007df2bcdcf6cd  pslld xmm10, 0x08
00007df2bcdcf6d3  movaps xmm5, [r15+0x160]
00007df2bcdcf6db  pextrq rax, xmm5, 0x01
00007df2bcdcf6e2  movq xmm5, rax
00007df2bcdcf6e7  pmovzxwd xmm5, xmm5
00007df2bcdcf6ec  pslld xmm5, 0x08
00007df2bcdcf6f1  pslld xmm9, 0x18
00007df2bcdcf6f7  pslld xmm15, 0x18
00007df2bcdcf6fd  pslld xmm8, 0x18
00007df2bcdcf703  movq xmm4, qword ptr [r15+0x250]
00007df2bcdcf70c  pmovzxwd xmm4, xmm4
00007df2bcdcf711  pslld xmm4, 0x00
00007df2bcdcf716  por xmm14, xmm13
00007df2bcdcf71b  por xmm7, xmm10
00007df2bcdcf720  movaps [r15+0x210], xmm7
00007df2bcdcf728  pslld xmm1, 0x18
00007df2bcdcf72d  movaps [r15+0x220], xmm1
00007df2bcdcf735  por xmm6, xmm5
00007df2bcdcf739  por xmm11, xmm9
00007df2bcdcf73e  movaps [r15+0x160], xmm11
00007df2bcdcf746  pextrq rax, xmm12, 0x01
00007df2bcdcf74d  movq xmm13, rax
00007df2bcdcf752  pmovzxwd xmm13, xmm13
00007df2bcdcf758  pslld xmm13, 0x00
00007df2bcdcf75e  movaps [r15+0x170], xmm13
00007df2bcdcf766  movq xmm12, qword ptr [r15+0x110]
00007df2bcdcf76f  pmovzxwd xmm12, xmm12
00007df2bcdcf775  pslld xmm12, 0x00
00007df2bcdcf77b  por xmm14, xmm15
00007df2bcdcf780  por xmm7, xmm8
00007df2bcdcf785  movaps xmm15, [r15+0x250]
00007df2bcdcf78d  pextrq rax, xmm15, 0x01
00007df2bcdcf794  movq xmm15, rax
00007df2bcdcf799  pmovzxwd xmm15, xmm15
00007df2bcdcf79f  pslld xmm15, 0x00
00007df2bcdcf7a5  movaps [r15+0x180], xmm15
00007df2bcdcf7ad  por xmm6, xmm1
00007df2bcdcf7b1  movaps [r15+0x150], xmm6
00007df2bcdcf7b9  por xmm11, xmm4
00007df2bcdcf7be  movaps [r15+0x140], xmm11
00007df2bcdcf7c6  por xmm7, xmm12
00007df2bcdcf7cb  movaps [r15+0x110], xmm7
00007df2bcdcf7d3  por xmm14, xmm13
00007df2bcdcf7d8  movaps [r15+0x120], xmm14
00007df2bcdcf7e0  por xmm6, xmm15
00007df2bcdcf7e5  movaps [r15+0x130], xmm6
00007df2bcdcf7ed  mov rax, [r15+0xF8]
00007df2bcdcf7f4  lea r14, [rax+0x20]
00007df2bcdcf7f8  movups [r13+r14*1], xmm7
00007df2bcdcf7fe  lea r14, [rax+0x30]
00007df2bcdcf802  movups [r13+r14*1], xmm14
00007df2bcdcf808  movups [r13+rax*1], xmm11
00007df2bcdcf80e  lea r14, [rax+0x10]
00007df2bcdcf812  movups [r13+r14*1], xmm6
00007df2bcdcf818  mov r14d, [r13+rax*1]
00007df2bcdcf81d  mov rax, [r15+0x48]
00007df2bcdcf821  mov [r15+0x68], rax
00007df2bcdcf825  mov qword ptr [r15+0x58], 0x04
00007df2bcdcf82d  lea r12, [rax+0x04]
00007df2bcdcf831  mov r11d, [r13+r12*1]
00007df2bcdcf836  mov [rsp+0x10], r11d
00007df2bcdcf83b  mov r11d, r11d
00007df2bcdcf83e  mov [r15+0x70], r11
00007df2bcdcf842  lea r12, [rax+0x38]
00007df2bcdcf846  mov r11d, [r13+r12*1]
00007df2bcdcf84b  lea r12, [rax+0x24]
00007df2bcdcf84f  mov r10d, [r13+r12*1]
00007df2bcdcf854  mov [rsp+0x20], r10d
00007df2bcdcf859  mov r10d, r10d
00007df2bcdcf85c  mov [r15+0x90], r10
00007df2bcdcf863  mov [rsp+0x30], rax
00007df2bcdcf868  xor eax, eax
00007df2bcdcf86a  mov r12d, 0x04
00007df2bcdcf870  mov r10d, 0xC0
00007df2bcdcf876  cmp r12, r10
00007df2bcdcf879  cmc
00007df2bcdcf87a  lahf
00007df2bcdcf87b  seto al
00007df2bcdcf87e  mov [r15+0x108], eax
00007df2bcdcf885  mov eax, [rsp+0x10]
00007df2bcdcf889  mov r12d, [rsp+0x10]
00007df2bcdcf88e  shrd eax, r12d, 0x07
00007df2bcdcf893  mov [rsp+0x10], r11d
00007df2bcdcf898  mov r10d, [rsp+0x10]
00007df2bcdcf89d  shrd r11d, r10d, 0x11
00007df2bcdcf8a2  mov r9d, [rsp+0x20]
00007df2bcdcf8a7  lea r8d, [r9d+r14d*1]
00007df2bcdcf8ac  rorx r14d, r12d, 0x12
00007df2bcdcf8b2  xor eax, r14d
00007df2bcdcf8b5  rorx r14d, r10d, 0x13
00007df2bcdcf8bb  xor r11d, r14d
00007df2bcdcf8be  mov [rsp+0x10], r11d
00007df2bcdcf8c3  mov r11d, r11d
00007df2bcdcf8c6  mov [r15+0x88], r11
00007df2bcdcf8cd  mov [rsp+0x20], r12d
00007df2bcdcf8d2  shr r12d, 0x03
00007df2bcdcf8d6  xor eax, r12d
00007df2bcdcf8d9  mov [rsp+0x40], eax
00007df2bcdcf8dd  mov eax, eax
00007df2bcdcf8df  mov [r15+0x80], rax
00007df2bcdcf8e6  shr r10d, 0x0A
00007df2bcdcf8ea  mov eax, [rsp+0x10]
00007df2bcdcf8ee  xor eax, r10d
00007df2bcdcf8f1  mov [rsp+0x10], eax
00007df2bcdcf8f5  mov eax, eax
00007df2bcdcf8f7  mov [r15+0x78], rax
00007df2bcdcf8fb  mov eax, [rsp+0x40]
00007df2bcdcf8ff  lea r14d, [r8d+eax*1]
00007df2bcdcf904  mov eax, [rsp+0x10]
00007df2bcdcf908  lea r12d, [r14d+eax*1]
00007df2bcdcf90d  mov rax, [rsp+0x30]
00007df2bcdcf912  lea r14, [rax+0x40]
00007df2bcdcf916  mov [r13+r14*1], r12d
00007df2bcdcf91b  mov eax, [rsp+0x20]
00007df2bcdcf91f  mov eax, eax
00007df2bcdcf921  mov [r15+0x60], rax
00007df2bcdcf925  mov eax, [r15+0x108]
00007df2bcdcf92c  sahf
00007df2bcdcf92d  jnz 0x00007DF2BCDCF95F
00007df2bcdcf92f  cmp dword ptr [r15+0x318], 0x00
00007df2bcdcf937  jz 0x00007DF2BCDCFE20
00007df2bcdcf93d  nop [rax+rax*1], ax
00007df2bcdcf946  nop [rax+rax*1], eax
00007df2bcdcf94e  mov eax, 0x41049C
00007df2bcdcf953  mov [r15+0x100], rax
00007df2bcdcf95a  jmp 0x00007DF2BCBFE110
00007df2bcdcf95f  cmp dword ptr [r15+0x318], 0x00
00007df2bcdcf967  jz 0x00007DF2BCDCFC70
00007df2bcdcf96d  nop [rax+rax*1], ax
00007df2bcdcf976  nop [rax+rax*1], eax
00007df2bcdcf97e  mov eax, 0x410454
00007df2bcdcf983  mov [r15+0x100], rax
00007df2bcdcf98a  jmp 0x00007DF2BCBFE110
00007df2bcdcf98f  int3
00007df2bcdcf990  call 0x00007DF2BCC0D860
00007df2bcdcf995  jmp 0x00007DF2BCDCF02A
00007df2bcdcf99a  call 0x00007DF2BCCE2420
00007df2bcdcf99f  jmp 0x00007DF2BCDCF043
00007df2bcdcf9a4  call 0x00007DF2BCCE2420
00007df2bcdcf9a9  jmp 0x00007DF2BCDCF05C
00007df2bcdcf9ae  call 0x00007DF2BCCE2420
00007df2bcdcf9b3  jmp 0x00007DF2BCDCF075
00007df2bcdcf9b8  call 0x00007DF2BCCE2420
00007df2bcdcf9bd  jmp 0x00007DF2BCDCF08E
00007df2bcdcf9c2  call 0x00007DF2BCCE2420
00007df2bcdcf9c7  jmp 0x00007DF2BCDCF09F
00007df2bcdcf9cc  call 0x00007DF2BCCE2420
00007df2bcdcf9d1  jmp 0x00007DF2BCDCF0B0
00007df2bcdcf9d6  call 0x00007DF2BCCE2420
00007df2bcdcf9db  jmp 0x00007DF2BCDCF0C1
00007df2bcdcf9e0  call 0x00007DF2BCCE2420
00007df2bcdcf9e5  jmp 0x00007DF2BCDCF0D2
00007df2bcdcf9ea  call 0x00007DF2BCCE2420
00007df2bcdcf9ef  jmp 0x00007DF2BCDCF0E3
00007df2bcdcf9f4  call 0x00007DF2BCCE2420
00007df2bcdcf9f9  jmp 0x00007DF2BCDCF0F4
00007df2bcdcf9fe  call 0x00007DF2BCCE2420
00007df2bcdcfa03  jmp 0x00007DF2BCDCF105
00007df2bcdcfa08  call 0x00007DF2BCCE2420
00007df2bcdcfa0d  jmp 0x00007DF2BCDCF116
00007df2bcdcfa12  call 0x00007DF2BCCE2420
00007df2bcdcfa17  jmp 0x00007DF2BCDCF127
00007df2bcdcfa1c  call 0x00007DF2BCCE2420
00007df2bcdcfa21  jmp 0x00007DF2BCDCF138
00007df2bcdcfa26  call 0x00007DF2BCCE2420
00007df2bcdcfa2b  jmp 0x00007DF2BCDCF149
00007df2bcdcfa30  call 0x00007DF2BCCE2420
00007df2bcdcfa35  jmp 0x00007DF2BCDCF15A
00007df2bcdcfa3a  call 0x00007DF2BCCE2420
00007df2bcdcfa3f  jmp 0x00007DF2BCDCF16B
00007df2bcdcfa44  call 0x00007DF2BCCE2420
00007df2bcdcfa49  jmp 0x00007DF2BCDCF17C
00007df2bcdcfa4e  call 0x00007DF2BCCE2420
00007df2bcdcfa53  jmp 0x00007DF2BCDCF18D
00007df2bcdcfa58  call 0x00007DF2BCCE2420
00007df2bcdcfa5d  jmp 0x00007DF2BCDCF19E
00007df2bcdcfa62  call 0x00007DF2BCCE2420
00007df2bcdcfa67  jmp 0x00007DF2BCDCF1AF
00007df2bcdcfa6c  call 0x00007DF2BCCE2420
00007df2bcdcfa71  jmp 0x00007DF2BCDCF1C0
00007df2bcdcfa76  call 0x00007DF2BCCE2420
00007df2bcdcfa7b  jmp 0x00007DF2BCDCF1D1
00007df2bcdcfa80  call 0x00007DF2BCCE2420
00007df2bcdcfa85  jmp 0x00007DF2BCDCF1E2
00007df2bcdcfa8a  call 0x00007DF2BCCE2420
00007df2bcdcfa8f  jmp 0x00007DF2BCDCF1F3
00007df2bcdcfa94  call 0x00007DF2BCCE2420
00007df2bcdcfa99  jmp 0x00007DF2BCDCF204
00007df2bcdcfa9e  call 0x00007DF2BCCE2420
00007df2bcdcfaa3  jmp 0x00007DF2BCDCF215
00007df2bcdcfaa8  call 0x00007DF2BCCE2420
00007df2bcdcfaad  jmp 0x00007DF2BCDCF226
00007df2bcdcfab2  call 0x00007DF2BCCE2420
00007df2bcdcfab7  jmp 0x00007DF2BCDCF237
00007df2bcdcfabc  call 0x00007DF2BCCE2420
00007df2bcdcfac1  jmp 0x00007DF2BCDCF248
00007df2bcdcfac6  call 0x00007DF2BCCE2420
00007df2bcdcfacb  jmp 0x00007DF2BCDCF259
00007df2bcdcfad0  call 0x00007DF2BCCE2420
00007df2bcdcfad5  jmp 0x00007DF2BCDCF26A
00007df2bcdcfada  call 0x00007DF2BCCE2420
00007df2bcdcfadf  jmp 0x00007DF2BCDCF27B
00007df2bcdcfae4  call 0x00007DF2BCCE2420
00007df2bcdcfae9  jmp 0x00007DF2BCDCF28C
00007df2bcdcfaee  call 0x00007DF2BCCE2420
00007df2bcdcfaf3  jmp 0x00007DF2BCDCF29D
00007df2bcdcfaf8  call 0x00007DF2BCCE2420
00007df2bcdcfafd  jmp 0x00007DF2BCDCF2AE
00007df2bcdcfb02  call 0x00007DF2BCCE2420
00007df2bcdcfb07  jmp 0x00007DF2BCDCF2BF
00007df2bcdcfb0c  call 0x00007DF2BCCE2420
00007df2bcdcfb11  jmp 0x00007DF2BCDCF2D0
00007df2bcdcfb16  call 0x00007DF2BCCE2420
00007df2bcdcfb1b  jmp 0x00007DF2BCDCF2E1
00007df2bcdcfb20  call 0x00007DF2BCCE2420
00007df2bcdcfb25  jmp 0x00007DF2BCDCF2F2
00007df2bcdcfb2a  call 0x00007DF2BCCE2420
00007df2bcdcfb2f  jmp 0x00007DF2BCDCF303
00007df2bcdcfb34  call 0x00007DF2BCCE2420
00007df2bcdcfb39  jmp 0x00007DF2BCDCF314
00007df2bcdcfb3e  call 0x00007DF2BCCE2420
00007df2bcdcfb43  jmp 0x00007DF2BCDCF325
00007df2bcdcfb48  call 0x00007DF2BCCE2420
00007df2bcdcfb4d  jmp 0x00007DF2BCDCF336
00007df2bcdcfb52  call 0x00007DF2BCCE2420
00007df2bcdcfb57  jmp 0x00007DF2BCDCF347
00007df2bcdcfb5c  call 0x00007DF2BCCE2420
00007df2bcdcfb61  jmp 0x00007DF2BCDCF358
00007df2bcdcfb66  call 0x00007DF2BCCE2420
00007df2bcdcfb6b  jmp 0x00007DF2BCDCF369
00007df2bcdcfb70  call 0x00007DF2BCCE2420
00007df2bcdcfb75  jmp 0x00007DF2BCDCF37A
00007df2bcdcfb7a  call 0x00007DF2BCCE2420
00007df2bcdcfb7f  jmp 0x00007DF2BCDCF38B
00007df2bcdcfb84  call 0x00007DF2BCCE2420
00007df2bcdcfb89  jmp 0x00007DF2BCDCF39C
00007df2bcdcfb8e  call 0x00007DF2BCCE2420
00007df2bcdcfb93  jmp 0x00007DF2BCDCF3AD
00007df2bcdcfb98  call 0x00007DF2BCCE2420
00007df2bcdcfb9d  jmp 0x00007DF2BCDCF3BE
00007df2bcdcfba2  call 0x00007DF2BCCE2420
00007df2bcdcfba7  jmp 0x00007DF2BCDCF3CF
00007df2bcdcfbac  call 0x00007DF2BCCE2420
00007df2bcdcfbb1  jmp 0x00007DF2BCDCF3E0
00007df2bcdcfbb6  call 0x00007DF2BCCE2420
00007df2bcdcfbbb  jmp 0x00007DF2BCDCF3F1
00007df2bcdcfbc0  call 0x00007DF2BCCE2420
00007df2bcdcfbc5  jmp 0x00007DF2BCDCF402
00007df2bcdcfbca  call 0x00007DF2BCCE2420
00007df2bcdcfbcf  jmp 0x00007DF2BCDCF413
00007df2bcdcfbd4  call 0x00007DF2BCCE2420
00007df2bcdcfbd9  jmp 0x00007DF2BCDCF424
00007df2bcdcfbde  call 0x00007DF2BCCE2420
00007df2bcdcfbe3  jmp 0x00007DF2BCDCF435
00007df2bcdcfbe8  call 0x00007DF2BCCE2420
00007df2bcdcfbed  jmp 0x00007DF2BCDCF446
00007df2bcdcfbf2  call 0x00007DF2BCCE2420
00007df2bcdcfbf7  jmp 0x00007DF2BCDCF45F
00007df2bcdcfbfc  call 0x00007DF2BCCE2420
00007df2bcdcfc01  jmp 0x00007DF2BCDCF478
00007df2bcdcfc06  call 0x00007DF2BCCD5610
00007df2bcdcfc0b  jmp 0x00007DF2BCDCF491
00007df2bcdcfc10  call 0x00007DF2BCCDC580
00007df2bcdcfc15  jmp 0x00007DF2BCDCF7FE
00007df2bcdcfc1a  call 0x00007DF2BCCE46C0
00007df2bcdcfc1f  jmp 0x00007DF2BCDCF808
00007df2bcdcfc24  call 0x00007DF2BCC09E90
00007df2bcdcfc29  jmp 0x00007DF2BCDCF80E
00007df2bcdcfc2e  call 0x00007DF2BCCDB310
00007df2bcdcfc33  jmp 0x00007DF2BCDCF818
00007df2bcdcfc38  call 0x00007DF2BCC0DAE0
00007df2bcdcfc3d  jmp 0x00007DF2BCDCF81D
00007df2bcdcfc42  call 0x00007DF2BCCC0230
00007df2bcdcfc47  jmp 0x00007DF2BCDCF836
00007df2bcdcfc4c  call 0x00007DF2BCCC0230
00007df2bcdcfc51  jmp 0x00007DF2BCDCF84B
00007df2bcdcfc56  call 0x00007DF2BCCBEFC0
00007df2bcdcfc5b  jmp 0x00007DF2BCDCF854
00007df2bcdcfc60  call 0x00007DF2BCCE2BA0
00007df2bcdcfc65  jmp 0x00007DF2BCDCF91B
00007df2bcdcfc6a  int3
00007df2bcdcfc6b  nop [rax+rax*1], eax
00007df2bcdcfc70  mov rax, [r15+0x48]
00007df2bcdcfc74  mov r14, [r15+0x58]
00007df2bcdcfc78  lea r12, [rax+r14*1]
00007df2bcdcfc7c  mov [r15+0x68], r12
00007df2bcdcfc80  lea rax, [r14+0x04]
00007df2bcdcfc84  mov [r15+0x58], rax
00007df2bcdcfc88  lea r14, [r12+0x04]
00007df2bcdcfc8d  mov r11d, [r13+r14*1]
00007df2bcdcfc92  mov [rsp+0x10], r11d
00007df2bcdcfc97  mov r11d, r11d
00007df2bcdcfc9a  mov [r15+0x70], r11
00007df2bcdcfc9e  lea r14, [r12+0x38]
00007df2bcdcfca3  mov r11d, [r13+r14*1]
00007df2bcdcfca8  lea r14, [r12+0x24]
00007df2bcdcfcad  mov r10d, [r13+r14*1]
00007df2bcdcfcb2  mov [rsp+0x20], r10d
00007df2bcdcfcb7  mov r10d, r10d
00007df2bcdcfcba  mov [r15+0x90], r10
00007df2bcdcfcc1  mov [rsp+0x30], rax
00007df2bcdcfcc6  xor eax, eax
00007df2bcdcfcc8  mov r14, [rsp+0x30]
00007df2bcdcfccd  mov r10d, 0xC0
00007df2bcdcfcd3  cmp r14, r10
00007df2bcdcfcd6  cmc
00007df2bcdcfcd7  lahf
00007df2bcdcfcd8  seto al
00007df2bcdcfcdb  mov [r15+0x108], eax
00007df2bcdcfce2  mov eax, [rsp+0x10]
00007df2bcdcfce6  mov r14d, [rsp+0x10]
00007df2bcdcfceb  shrd eax, r14d, 0x07
00007df2bcdcfcf0  mov [rsp+0x10], r11d
00007df2bcdcfcf5  mov r10d, [rsp+0x10]
00007df2bcdcfcfa  shrd r11d, r10d, 0x11
00007df2bcdcfcff  mov r9d, [r15+0x60]
00007df2bcdcfd03  mov r8d, [rsp+0x20]
00007df2bcdcfd08  lea ebp, [r8d+r9d*1]
00007df2bcdcfd0d  rorx r9d, r14d, 0x12
00007df2bcdcfd13  xor eax, r9d
00007df2bcdcfd16  rorx r9d, r10d, 0x13
00007df2bcdcfd1c  xor r11d, r9d
00007df2bcdcfd1f  mov [rsp+0x10], r11d
00007df2bcdcfd24  mov r11d, r11d
00007df2bcdcfd27  mov [r15+0x88], r11
00007df2bcdcfd2e  mov [rsp+0x20], r14d
00007df2bcdcfd33  shr r14d, 0x03
00007df2bcdcfd37  xor eax, r14d
00007df2bcdcfd3a  mov [rsp+0x30], eax
00007df2bcdcfd3e  mov eax, eax
00007df2bcdcfd40  mov [r15+0x80], rax
00007df2bcdcfd47  shr r10d, 0x0A
00007df2bcdcfd4b  mov eax, [rsp+0x10]
00007df2bcdcfd4f  xor eax, r10d
00007df2bcdcfd52  mov [rsp+0x10], eax
00007df2bcdcfd56  mov eax, eax
00007df2bcdcfd58  mov [r15+0x78], rax
00007df2bcdcfd5c  mov eax, [rsp+0x30]
00007df2bcdcfd60  lea r14d, [ebp+eax*1]
00007df2bcdcfd66  mov eax, [rsp+0x10]
00007df2bcdcfd6a  lea r11d, [r14d+eax*1]
00007df2bcdcfd6f  lea rax, [r12+0x40]
00007df2bcdcfd74  mov [r13+rax*1], r11d
00007df2bcdcfd79  mov eax, [rsp+0x20]
00007df2bcdcfd7d  mov eax, eax
00007df2bcdcfd7f  mov [r15+0x60], rax
00007df2bcdcfd83  mov eax, [r15+0x108]
00007df2bcdcfd8a  sahf
00007df2bcdcfd8b  jnz 0x00007DF2BCDCFDBD
00007df2bcdcfd8d  cmp dword ptr [r15+0x318], 0x00
00007df2bcdcfd95  jz 0x00007DF2BCDCFE20
00007df2bcdcfd9b  nop [rax+rax*1], ax
00007df2bcdcfda4  nop [rax+rax*1], eax
00007df2bcdcfdac  mov eax, 0x41049C
00007df2bcdcfdb1  mov [r15+0x100], rax
00007df2bcdcfdb8  jmp 0x00007DF2BCBFE110
00007df2bcdcfdbd  cmp dword ptr [r15+0x318], 0x00
00007df2bcdcfdc5  jz 0x00007DF2BCDCFC70
00007df2bcdcfdcb  nop [rax+rax*1], ax
00007df2bcdcfdd4  nop [rax+rax*1], eax
00007df2bcdcfddc  mov eax, 0x410454
00007df2bcdcfde1  mov [r15+0x100], rax
00007df2bcdcfde8  jmp 0x00007DF2BCBFE110
00007df2bcdcfded  int3
00007df2bcdcfdee  call 0x00007DF2BCCE1430
00007df2bcdcfdf3  jmp 0x00007DF2BCDCFC92
00007df2bcdcfdf8  call 0x00007DF2BCCE1430
00007df2bcdcfdfd  jmp 0x00007DF2BCDCFCA8
00007df2bcdcfe02  call 0x00007DF2BCCE01C0
00007df2bcdcfe07  jmp 0x00007DF2BCDCFCB2
00007df2bcdcfe0c  call 0x00007DF2BCC0A860
00007df2bcdcfe11  jmp 0x00007DF2BCDCFD79
00007df2bcdcfe16  int3
00007df2bcdcfe17  nop [rax+rax*1], ax
00007df2bcdcfe20  mov rax, [r15]
00007df2bcdcfe23  mov r14d, [r13+rax*1]
00007df2bcdcfe28  lea r12, [rax+0x04]
00007df2bcdcfe2c  mov r11d, [r13+r12*1]
00007df2bcdcfe31  mov [rsp+0x10], r14d
00007df2bcdcfe36  mov r14d, r14d
00007df2bcdcfe39  mov [r15+0x78], r14
00007df2bcdcfe3d  mov [rsp+0x20], r11d
00007df2bcdcfe42  mov r11d, r11d
00007df2bcdcfe45  mov [r15+0x80], r11
00007df2bcdcfe4c  lea r14, [rax+0x08]
00007df2bcdcfe50  mov r12d, [r13+r14*1]
00007df2bcdcfe55  lea r14, [rax+0x0C]
00007df2bcdcfe59  mov r11d, [r13+r14*1]
00007df2bcdcfe5e  mov [rsp+0x30], r12d
00007df2bcdcfe63  mov r12d, r12d
00007df2bcdcfe66  mov [r15+0x70], r12
00007df2bcdcfe6a  mov [rsp+0x40], r11d
00007df2bcdcfe6f  mov r11d, r11d
00007df2bcdcfe72  mov [r15+0x68], r11
00007df2bcdcfe76  lea r14, [rax+0x18]
00007df2bcdcfe7a  mov r12d, [r13+r14*1]
00007df2bcdcfe7f  lea r14, [rax+0x1C]
00007df2bcdcfe83  mov r11d, [r13+r14*1]
00007df2bcdcfe88  mov [rsp+0x50], r12d
00007df2bcdcfe8d  mov r12d, r12d
00007df2bcdcfe90  mov [r15+0x58], r12
00007df2bcdcfe94  mov [rsp+0x60], r11d
00007df2bcdcfe99  mov r11d, r11d
00007df2bcdcfe9c  mov [r15+0x60], r11
00007df2bcdcfea0  lea r14, [rax+0x10]
00007df2bcdcfea4  mov r12d, [r13+r14*1]
00007df2bcdcfea9  lea r14, [rax+0x14]
00007df2bcdcfead  mov eax, [r13+r14*1]
00007df2bcdcfeb2  mov [rsp+0x70], r12d
00007df2bcdcfeb7  mov r12d, r12d
00007df2bcdcfeba  mov [r15+0x18], r12
00007df2bcdcfebe  mov [rsp+0x80], eax
00007df2bcdcfec5  mov eax, eax
00007df2bcdcfec7  mov [r15+0x90], rax
00007df2bcdcfece  mov eax, [rsp+0x70]
00007df2bcdcfed2  mov eax, eax
00007df2bcdcfed4  mov [r15+0x30], rax
00007df2bcdcfed8  mov eax, [rsp+0x50]
00007df2bcdcfedc  mov eax, eax
00007df2bcdcfede  mov [r15+0xA0], rax
00007df2bcdcfee5  mov eax, [rsp+0x30]
00007df2bcdcfee9  mov eax, eax
00007df2bcdcfeeb  mov [r15+0x28], rax
00007df2bcdcfeef  mov eax, [rsp+0x20]
00007df2bcdcfef3  mov eax, eax
00007df2bcdcfef5  mov [r15+0x98], rax
00007df2bcdcfefc  mov eax, [rsp+0x10]
00007df2bcdcff00  mov eax, eax
00007df2bcdcff02  mov [r15+0x38], rax
00007df2bcdcff06  mov eax, [rsp+0x70]
00007df2bcdcff0a  mov r14d, [rsp+0x70]
00007df2bcdcff0f  shrd eax, r14d, 0x06
00007df2bcdcff14  mov [rsp+0x70], r14d
00007df2bcdcff19  mov r12d, [rsp+0x80]
00007df2bcdcff21  and r14d, r12d
00007df2bcdcff24  mov r11d, [rsp+0x10]
00007df2bcdcff29  mov r10d, [rsp+0x10]
00007df2bcdcff2e  shrd r11d, r10d, 0x02
00007df2bcdcff33  mov [rsp+0x10], r12d
00007df2bcdcff38  mov r12d, r12d
00007df2bcdcff3b  mov [r15+0x20], r12
00007df2bcdcff3f  mov r12, [r15+0x50]
00007df2bcdcff43  mov r9d, [r13+r12*1]
00007df2bcdcff48  mov r12d, [rsp+0x50]
00007df2bcdcff4d  mov r8d, [rsp+0x70]
00007df2bcdcff52  andn ebp, r8d, r12d
00007df2bcdcff57  mov edi, [rsp+0x60]
00007df2bcdcff5b  lea esi, [r14d+edi*1]
00007df2bcdcff60  rorx r14d, r8d, 0x0B
00007df2bcdcff66  xor eax, r14d
00007df2bcdcff69  rorx r14d, r10d, 0x0D
00007df2bcdcff6f  xor r11d, r14d
00007df2bcdcff72  lea edi, [esi+ebp*1]
00007df2bcdcff76  mov r14, [r15+0x48]
00007df2bcdcff7a  mov ebp, [r13+r14*1]
00007df2bcdcff7f  mov r14d, [rsp+0x30]
00007df2bcdcff84  mov esi, [rsp+0x20]
00007df2bcdcff88  and r14d, esi
00007df2bcdcff8b  mov [rsp+0x20], r14d
00007df2bcdcff90  mov r14d, r14d
00007df2bcdcff93  mov [r15+0xD8], r14
00007df2bcdcff9a  lea r14d, [edi+r9d*1]
00007df2bcdcff9f  mov r9d, [rsp+0x30]
00007df2bcdcffa4  xor r9d, esi
00007df2bcdcffa7  rorx edi, r8d, 0x19
00007df2bcdcffad  xor eax, edi
00007df2bcdcffaf  and r9d, r10d
00007df2bcdcffb2  rorx edi, r10d, 0x16
00007df2bcdcffb8  xor r11d, edi
00007df2bcdcffbb  mov [rsp+0x30], r11d
00007df2bcdcffc0  mov r11d, r11d
00007df2bcdcffc3  mov [r15+0xD0], r11
00007df2bcdcffca  lea r11d, [r14d+ebp*1]
00007df2bcdcffcf  mov r10d, [rsp+0x20]
00007df2bcdcffd4  xor r9d, r10d
00007df2bcdcffd7  lea r14d, [r11d+eax*1]
00007df2bcdcffdc  mov qword ptr [r15+0x88], 0x04
00007df2bcdcffe7  mov eax, [rsp+0x30]
00007df2bcdcffeb  lea r11d, [r9d+eax*1]
00007df2bcdcfff0  mov eax, [rsp+0x40]
00007df2bcdcfff4  lea r10d, [r14d+eax*1]
00007df2bcdcfff9  mov r10d, r10d
00007df2bcdcfffc  mov [r15+0xB8], r10
00007df2bcdd0003  xor eax, eax
00007df2bcdd0005  mov r10d, 0x04
00007df2bcdd000b  mov r9d, 0x100
00007df2bcdd0011  cmp r10, r9
00007df2bcdd0014  cmc
00007df2bcdd0015  lahf
00007df2bcdd0016  seto al
00007df2bcdd0019  mov [r15+0x108], eax
00007df2bcdd0020  lea eax, [r11d+r14d*1]
00007df2bcdd0025  mov eax, eax
00007df2bcdd0027  mov [r15+0xA8], rax
00007df2bcdd002e  mov r12d, r12d
00007df2bcdd0031  mov [r15+0xB0], r12
00007df2bcdd0038  mov eax, [rsp+0x10]
00007df2bcdd003c  mov eax, eax
00007df2bcdd003e  mov [r15+0xC0], rax
00007df2bcdd0045  mov r8d, r8d
00007df2bcdd0048  mov [r15+0xC8], r8
00007df2bcdd004f  mov eax, [r15+0x108]
00007df2bcdd0056  sahf
00007df2bcdd0057  jnz 0x00007DF2BCDD0089
00007df2bcdd0059  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd0061  jz 0x00007DF2BCDD0350
00007df2bcdd0067  nop [rax+rax*1], ax
00007df2bcdd0070  nop [rax+rax*1], eax
00007df2bcdd0078  mov eax, 0x41055C
00007df2bcdd007d  mov [r15+0x100], rax
00007df2bcdd0084  jmp 0x00007DF2BCBFE110
00007df2bcdd0089  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd0091  jz 0x00007DF2BCDD0120
00007df2bcdd0097  nop [rax+rax*1], ax
00007df2bcdd00a0  nop [rax+rax*1], eax
00007df2bcdd00a8  mov eax, 0x4104D0
00007df2bcdd00ad  mov [r15+0x100], rax
00007df2bcdd00b4  jmp 0x00007DF2BCBFE110
00007df2bcdd00b9  int3
00007df2bcdd00ba  call 0x00007DF2BCC0DAE0
00007df2bcdd00bf  jmp 0x00007DF2BCDCFE28
00007df2bcdd00c4  call 0x00007DF2BCCC0230
00007df2bcdd00c9  jmp 0x00007DF2BCDCFE31
00007df2bcdd00ce  call 0x00007DF2BCCE26A0
00007df2bcdd00d3  jmp 0x00007DF2BCDCFE55
00007df2bcdd00d8  call 0x00007DF2BCCE1430
00007df2bcdd00dd  jmp 0x00007DF2BCDCFE5E
00007df2bcdd00e2  call 0x00007DF2BCCE26A0
00007df2bcdd00e7  jmp 0x00007DF2BCDCFE7F
00007df2bcdd00ec  call 0x00007DF2BCCE1430
00007df2bcdd00f1  jmp 0x00007DF2BCDCFE88
00007df2bcdd00f6  call 0x00007DF2BCCE26A0
00007df2bcdd00fb  jmp 0x00007DF2BCDCFEA9
00007df2bcdd0100  call 0x00007DF2BCCD5890
00007df2bcdd0105  jmp 0x00007DF2BCDCFEB2
00007df2bcdd010a  call 0x00007DF2BCCBDD50
00007df2bcdd010f  jmp 0x00007DF2BCDCFF48
00007df2bcdd0114  call 0x00007DF2BCCDA580
00007df2bcdd0119  jmp 0x00007DF2BCDCFF7F
00007df2bcdd011e  int3
00007df2bcdd011f  nop
00007df2bcdd0120  mov eax, [r15+0xB8]
00007df2bcdd0127  mov [rsp+0x10], eax
00007df2bcdd012b  mov eax, eax
00007df2bcdd012d  mov [r15+0x30], rax
00007df2bcdd0131  mov eax, [r15+0xC0]
00007df2bcdd0138  mov [rsp+0x20], eax
00007df2bcdd013c  mov eax, eax
00007df2bcdd013e  mov [r15+0xA0], rax
00007df2bcdd0145  mov eax, [r15+0x28]
00007df2bcdd0149  mov r14d, [r15+0x98]
00007df2bcdd0150  mov [rsp+0x30], r14d
00007df2bcdd0155  mov r14d, r14d
00007df2bcdd0158  mov [r15+0x28], r14
00007df2bcdd015c  mov r14d, [r15+0x38]
00007df2bcdd0160  mov [rsp+0x40], r14d
00007df2bcdd0165  mov r14d, r14d
00007df2bcdd0168  mov [r15+0x98], r14
00007df2bcdd016f  mov r14d, [r15+0xA8]
00007df2bcdd0176  mov [rsp+0x50], r14d
00007df2bcdd017b  mov r14d, r14d
00007df2bcdd017e  mov [r15+0x38], r14
00007df2bcdd0182  mov r14d, [rsp+0x10]
00007df2bcdd0187  mov r12d, [rsp+0x10]
00007df2bcdd018c  shrd r14d, r12d, 0x06
00007df2bcdd0191  mov r11d, [r15+0xC8]
00007df2bcdd0198  mov [rsp+0x10], r12d
00007df2bcdd019d  and r12d, r11d
00007df2bcdd01a0  mov r10d, [rsp+0x50]
00007df2bcdd01a5  mov r9d, [rsp+0x50]
00007df2bcdd01aa  shrd r10d, r9d, 0x02
00007df2bcdd01af  mov [rsp+0x50], r11d
00007df2bcdd01b4  mov r11d, r11d
00007df2bcdd01b7  mov [r15+0x20], r11
00007df2bcdd01bb  mov r11, [r15+0x88]
00007df2bcdd01c2  mov r8, [r15+0x50]
00007df2bcdd01c6  lea rbp, [r8+r11*1]
00007df2bcdd01ca  mov r8d, [r13+rbp*1]
00007df2bcdd01cf  mov ebp, [rsp+0x20]
00007df2bcdd01d3  mov edi, [rsp+0x10]
00007df2bcdd01d7  andn esi, edi, ebp
00007df2bcdd01dc  mov edx, [r15+0xB0]
00007df2bcdd01e3  lea ecx, [r12d+edx*1]
00007df2bcdd01e8  rorx r12d, edi, 0x0B
00007df2bcdd01ee  xor r14d, r12d
00007df2bcdd01f1  rorx r12d, r9d, 0x0D
00007df2bcdd01f7  xor r10d, r12d
00007df2bcdd01fa  lea r12d, [ecx+esi*1]
00007df2bcdd01ff  mov rsi, [r15+0x48]
00007df2bcdd0203  lea rdx, [rsi+r11*1]
00007df2bcdd0207  mov esi, [r13+rdx*1]
00007df2bcdd020c  mov edx, [rsp+0x30]
00007df2bcdd0210  mov ecx, [rsp+0x40]
00007df2bcdd0214  and edx, ecx
00007df2bcdd0216  mov [rsp+0x10], edx
00007df2bcdd021a  mov edx, edx
00007df2bcdd021c  mov [r15+0xD8], rdx
00007df2bcdd0223  lea edx, [r12d+r8d*1]
00007df2bcdd0228  mov r12d, [rsp+0x30]
00007df2bcdd022d  xor r12d, ecx
00007df2bcdd0230  rorx r8d, edi, 0x19
00007df2bcdd0236  xor r14d, r8d
00007df2bcdd0239  and r12d, r9d
00007df2bcdd023c  rorx r8d, r9d, 0x16
00007df2bcdd0242  xor r10d, r8d
00007df2bcdd0245  mov [rsp+0x20], r10d
00007df2bcdd024a  mov r10d, r10d
00007df2bcdd024d  mov [r15+0xD0], r10
00007df2bcdd0254  lea r10d, [edx+esi*1]
00007df2bcdd0259  mov r9d, [rsp+0x10]
00007df2bcdd025e  xor r12d, r9d
00007df2bcdd0261  lea r9d, [r10d+r14d*1]
00007df2bcdd0266  lea r14, [r11+0x04]
00007df2bcdd026a  mov [r15+0x88], r14
00007df2bcdd0271  mov r11d, [rsp+0x20]
00007df2bcdd0276  lea r10d, [r12d+r11d*1]
00007df2bcdd027b  lea r11d, [r9d+eax*1]
00007df2bcdd0280  mov r11d, r11d
00007df2bcdd0283  mov [r15+0xB8], r11
00007df2bcdd028a  xor eax, eax
00007df2bcdd028c  mov r12d, 0x100
00007df2bcdd0292  cmp r14, r12
00007df2bcdd0295  cmc
00007df2bcdd0296  lahf
00007df2bcdd0297  seto al
00007df2bcdd029a  mov [r15+0x108], eax
00007df2bcdd02a1  lea eax, [r10d+r9d*1]
00007df2bcdd02a6  mov eax, eax
00007df2bcdd02a8  mov [r15+0xA8], rax
00007df2bcdd02af  mov ebp, ebp
00007df2bcdd02b1  mov [r15+0xB0], rbp
00007df2bcdd02b8  mov eax, [rsp+0x50]
00007df2bcdd02bc  mov eax, eax
00007df2bcdd02be  mov [r15+0xC0], rax
00007df2bcdd02c5  mov edi, edi
00007df2bcdd02c7  mov [r15+0xC8], rdi
00007df2bcdd02ce  mov eax, [r15+0x108]
00007df2bcdd02d5  sahf
00007df2bcdd02d6  jnz 0x00007DF2BCDD0308
00007df2bcdd02d8  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd02e0  jz 0x00007DF2BCDD0350
00007df2bcdd02e6  nop [rax+rax*1], ax
00007df2bcdd02ef  nop [rax+rax*1], eax
00007df2bcdd02f7  mov eax, 0x41055C
00007df2bcdd02fc  mov [r15+0x100], rax
00007df2bcdd0303  jmp 0x00007DF2BCBFE110
00007df2bcdd0308  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd0310  jz 0x00007DF2BCDD0120
00007df2bcdd0316  nop [rax+rax*1], ax
00007df2bcdd031f  nop [rax+rax*1], eax
00007df2bcdd0327  mov eax, 0x4104D0
00007df2bcdd032c  mov [r15+0x100], rax
00007df2bcdd0333  jmp 0x00007DF2BCBFE110
00007df2bcdd0338  int3
00007df2bcdd0339  call 0x00007DF2BCC49010
00007df2bcdd033e  jmp 0x00007DF2BCDD01CF
00007df2bcdd0343  call 0x00007DF2BCC25930
00007df2bcdd0348  jmp 0x00007DF2BCDD020C
00007df2bcdd034d  int3
00007df2bcdd034e  nop
00007df2bcdd0350  mov eax, [r15+0x98]
00007df2bcdd0357  mov r14d, [r15+0x70]
00007df2bcdd035b  lea r12d, [eax+r14d*1]
00007df2bcdd0360  mov eax, [r15+0x28]
00007df2bcdd0364  mov r14d, [r15+0x68]
00007df2bcdd0368  lea r11d, [eax+r14d*1]
00007df2bcdd036d  mov qword ptr [r15+0x88], 0x00
00007df2bcdd0378  mov eax, [r15+0xA8]
00007df2bcdd037f  mov r14d, [r15+0x78]
00007df2bcdd0383  lea r10d, [eax+r14d*1]
00007df2bcdd0388  mov [rsp+0x10], r10d
00007df2bcdd038d  mov r10d, r10d
00007df2bcdd0390  mov [r15+0x78], r10
00007df2bcdd0394  mov eax, [r15+0x38]
00007df2bcdd0398  mov r14d, [r15+0x80]
00007df2bcdd039f  lea r10d, [eax+r14d*1]
00007df2bcdd03a4  mov [rsp+0x20], r10d
00007df2bcdd03a9  mov r10d, r10d
00007df2bcdd03ac  mov [r15+0x80], r10
00007df2bcdd03b3  mov rax, [r15]
00007df2bcdd03b6  lea r14, [rax+0x08]
00007df2bcdd03ba  mov [r13+r14*1], r12d
00007df2bcdd03bf  lea r14, [rax+0x0C]
00007df2bcdd03c3  mov [r13+r14*1], r11d
00007df2bcdd03c8  mov r14d, [r15+0xB8]
00007df2bcdd03cf  mov r12d, [r15+0x18]
00007df2bcdd03d3  lea r11d, [r14d+r12d*1]
00007df2bcdd03d8  mov [rsp+0x30], r11d
00007df2bcdd03dd  mov r11d, r11d
00007df2bcdd03e0  mov [r15+0x68], r11
00007df2bcdd03e4  mov r14d, [r15+0x30]
00007df2bcdd03e8  mov r12d, [r15+0x90]
00007df2bcdd03ef  lea r11d, [r14d+r12d*1]
00007df2bcdd03f4  mov [rsp+0x40], r11d
00007df2bcdd03f9  mov r11d, r11d
00007df2bcdd03fc  mov [r15+0x70], r11
00007df2bcdd0400  mov r14d, [r15+0x20]
00007df2bcdd0404  mov r12d, [r15+0x58]
00007df2bcdd0408  lea r11d, [r14d+r12d*1]
00007df2bcdd040d  mov [rsp+0x50], r11d
00007df2bcdd0412  mov r11d, r11d
00007df2bcdd0415  mov [r15+0x58], r11
00007df2bcdd0419  mov r14d, [r15+0xA0]
00007df2bcdd0420  mov r12d, [r15+0x60]
00007df2bcdd0424  lea r11d, [r14d+r12d*1]
00007df2bcdd0429  mov [rsp+0x60], r11d
00007df2bcdd042e  mov r11d, r11d
00007df2bcdd0431  mov [r15+0x60], r11
00007df2bcdd0435  mov r14d, [rsp+0x10]
00007df2bcdd043a  mov [r13+rax*1], r14d
00007df2bcdd043f  lea r14, [rax+0x04]
00007df2bcdd0443  mov r12d, [rsp+0x20]
00007df2bcdd0448  mov [r13+r14*1], r12d
00007df2bcdd044d  lea r14, [rax+0x10]
00007df2bcdd0451  mov r12d, [rsp+0x30]
00007df2bcdd0456  mov [r13+r14*1], r12d
00007df2bcdd045b  lea r14, [rax+0x14]
00007df2bcdd045f  mov r12d, [rsp+0x40]
00007df2bcdd0464  mov [r13+r14*1], r12d
00007df2bcdd0469  lea r14, [rax+0x18]
00007df2bcdd046d  mov r12d, [rsp+0x50]
00007df2bcdd0472  mov [r13+r14*1], r12d
00007df2bcdd0477  lea r14, [rax+0x1C]
00007df2bcdd047b  mov r12d, [rsp+0x60]
00007df2bcdd0480  mov [r13+r14*1], r12d
00007df2bcdd0485  lea r14, [rax+0x68]
00007df2bcdd0489  xor eax, eax
00007df2bcdd048b  mov [r13+r14*1], rax
00007df2bcdd0490  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd0498  jz 0x00007DF2BCDCEF90
00007df2bcdd049e  nop [rax+rax*1], ax
00007df2bcdd04a7  nop [rax+rax*1], eax
00007df2bcdd04af  mov eax, 0x410378
00007df2bcdd04b4  mov [r15+0x100], rax
00007df2bcdd04bb  jmp 0x00007DF2BCBFE110
00007df2bcdd04c0  int3
00007df2bcdd04c1  call 0x00007DF2BCCE2BA0
00007df2bcdd04c6  jmp 0x00007DF2BCDD03BF
00007df2bcdd04cb  call 0x00007DF2BCCE1920
00007df2bcdd04d0  jmp 0x00007DF2BCDD03C8
00007df2bcdd04d5  call 0x00007DF2BCC0DFE0
00007df2bcdd04da  jmp 0x00007DF2BCDD043F
00007df2bcdd04df  call 0x00007DF2BCCE2BA0
00007df2bcdd04e4  jmp 0x00007DF2BCDD044D
00007df2bcdd04e9  call 0x00007DF2BCCE2BA0
00007df2bcdd04ee  jmp 0x00007DF2BCDD045B
00007df2bcdd04f3  call 0x00007DF2BCCE2BA0
00007df2bcdd04f8  jmp 0x00007DF2BCDD0469
00007df2bcdd04fd  call 0x00007DF2BCCE2BA0
00007df2bcdd0502  jmp 0x00007DF2BCDD0477
00007df2bcdd0507  call 0x00007DF2BCCE2BA0
00007df2bcdd050c  jmp 0x00007DF2BCDD0485
00007df2bcdd0511  call 0x00007DF2BCCD5EB0
00007df2bcdd0516  jmp 0x00007DF2BCDD0490
00007df2bcdd051b  int3
00007df2bcdd051c  nop [rax], eax
00007df2bcdd0520  mov rax, [r15+0xF8]
00007df2bcdd0527  lea r14, [rax+0x140]
00007df2bcdd052e  mov r12, [r13+r14*1]
00007df2bcdd0533  lea r14, [rax+0x148]
00007df2bcdd053a  mov r11, [r13+r14*1]
00007df2bcdd053f  mov [r15+0xA0], r12
00007df2bcdd0546  mov [r15+0x98], r11
00007df2bcdd054d  lea r14, [rax+0x130]
00007df2bcdd0554  mov r12, [r13+r14*1]
00007df2bcdd0559  lea r14, [rax+0x138]
00007df2bcdd0560  mov r11, [r13+r14*1]
00007df2bcdd0565  mov [r15+0xB0], r12
00007df2bcdd056c  mov [r15+0xA8], r11
00007df2bcdd0573  lea r14, [rax+0x120]
00007df2bcdd057a  mov r12, [r13+r14*1]
00007df2bcdd057f  lea r14, [rax+0x128]
00007df2bcdd0586  mov r11, [r13+r14*1]
00007df2bcdd058b  mov [r15+0xC0], r12
00007df2bcdd0592  mov [r15+0xB8], r11
00007df2bcdd0599  lea r14, [rax+0x110]
00007df2bcdd05a0  mov r12, [r13+r14*1]
00007df2bcdd05a5  lea r14, [rax+0x118]
00007df2bcdd05ac  mov r11, [r13+r14*1]
00007df2bcdd05b1  mov [r15+0xD0], r12
00007df2bcdd05b8  mov [r15+0xC8], r11
00007df2bcdd05bf  lea r14, [rax+0x100]
00007df2bcdd05c6  mov r12, [r13+r14*1]
00007df2bcdd05cb  lea r14, [rax+0x108]
00007df2bcdd05d2  mov r11, [r13+r14*1]
00007df2bcdd05d7  mov [r15+0xE8], r12
00007df2bcdd05de  mov [r15+0xD8], r11
00007df2bcdd05e5  lea r14, [rax+0x150]
00007df2bcdd05ec  mov [r15+0xF8], r14
00007df2bcdd05f3  mov rax, [r15+0xF0]
00007df2bcdd05fa  mov [r15+0x100], rax
00007df2bcdd0601  jmp 0x00007DF2BCDCE5C0
00007df2bcdd0606  int3
00007df2bcdd0607  call 0x00007DF2BCCE27E0
00007df2bcdd060c  jmp 0x00007DF2BCDD0533
00007df2bcdd0611  call 0x00007DF2BCCE1570
00007df2bcdd0616  jmp 0x00007DF2BCDD053F
00007df2bcdd061b  call 0x00007DF2BCCE27E0
00007df2bcdd0620  jmp 0x00007DF2BCDD0559
00007df2bcdd0625  call 0x00007DF2BCCE1570
00007df2bcdd062a  jmp 0x00007DF2BCDD0565
00007df2bcdd062f  call 0x00007DF2BCCE27E0
00007df2bcdd0634  jmp 0x00007DF2BCDD057F
00007df2bcdd0639  call 0x00007DF2BCCE1570
00007df2bcdd063e  jmp 0x00007DF2BCDD058B
00007df2bcdd0643  call 0x00007DF2BCCE27E0
00007df2bcdd0648  jmp 0x00007DF2BCDD05A5
00007df2bcdd064d  call 0x00007DF2BCCE1570
00007df2bcdd0652  jmp 0x00007DF2BCDD05B1
00007df2bcdd0657  call 0x00007DF2BCCE27E0
00007df2bcdd065c  jmp 0x00007DF2BCDD05CB
00007df2bcdd0661  call 0x00007DF2BCCE1570
00007df2bcdd0666  jmp 0x00007DF2BCDD05D7
00007df2bcdd066b  int3
00007df2bcdd066c  nop [rax], eax
00007df2bcdd0670  mov eax, [r15+0xA0]
00007df2bcdd0677  mov [rsp+0x10], eax
00007df2bcdd067b  xor eax, eax
00007df2bcdd067d  mov r14d, [rsp+0x10]
00007df2bcdd0682  sub r14d, 0x01
00007df2bcdd0686  cmc
00007df2bcdd0687  lahf
00007df2bcdd0688  seto al
00007df2bcdd068b  mov [r15+0x108], eax
00007df2bcdd0692  mov r14d, r14d
00007df2bcdd0695  mov [r15+0xA0], r14
00007df2bcdd069c  mov eax, [r15+0x108]
00007df2bcdd06a3  sahf
00007df2bcdd06a4  jnz 0x00007DF2BCDD06D6
00007df2bcdd06a6  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd06ae  jz 0x00007DF2BCDD07A0
00007df2bcdd06b4  nop [rax+rax*1], ax
00007df2bcdd06bd  nop [rax+rax*1], eax
00007df2bcdd06c5  mov eax, 0x41027C
00007df2bcdd06ca  mov [r15+0x100], rax
00007df2bcdd06d1  jmp 0x00007DF2BCBFE110
00007df2bcdd06d6  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd06de  jz 0x00007DF2BCDD0710
00007df2bcdd06e4  nop [rax+rax*1], ax
00007df2bcdd06ed  nop [rax+rax*1], eax
00007df2bcdd06f5  mov eax, 0x410264
00007df2bcdd06fa  mov [r15+0x100], rax
00007df2bcdd0701  jmp 0x00007DF2BCBFE110
00007df2bcdd0706  int3
00007df2bcdd0707  int3
00007df2bcdd0708  nop [rax+rax*1], eax
00007df2bcdd0710  mov rax, [r15+0xF8]
00007df2bcdd0717  mov [r15], rax
00007df2bcdd071a  mov rax, [r15+0x98]
00007df2bcdd0721  mov [r15+0x08], rax
00007df2bcdd0725  mov qword ptr [r15+0x10], 0x12C
00007df2bcdd072d  mov qword ptr [r15+0xF0], 0x410274
00007df2bcdd0738  mov r14d, [r15+0x320]
00007df2bcdd073f  mov eax, 0x410274
00007df2bcdd0744  mov rcx, 0x7DF2BCDD0670
00007df2bcdd074e  mov [r15+r14*8+0x328], rax
00007df2bcdd0756  mov [r15+r14*8+0x368], rcx
00007df2bcdd075e  add r14d, 0x01
00007df2bcdd0762  and r14d, 0x07
00007df2bcdd0766  mov [r15+0x320], r14d
00007df2bcdd076d  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd0775  jz 0x00007DF2BCDCEC20
00007df2bcdd077b  nop [rax+rax*1], ax
00007df2bcdd0784  nop [rax+rax*1], eax
00007df2bcdd078c  mov eax, 0x410338
00007df2bcdd0791  mov [r15+0x100], rax
00007df2bcdd0798  jmp 0x00007DF2BCBFE110
00007df2bcdd079d  int3
00007df2bcdd079e  int3
00007df2bcdd079f  nop
00007df2bcdd07a0  mov rax, [r15+0xF8]
00007df2bcdd07a7  lea r14, [rax+0x20]
00007df2bcdd07ab  mov r12, [r13+r14*1]
00007df2bcdd07b0  mov [r15+0x98], r12
00007df2bcdd07b7  mov qword ptr [r15+0x40], 0x80
00007df2bcdd07bf  mov [r15], rax
00007df2bcdd07c2  lea r14, [rax+0x8C]
00007df2bcdd07c9  mov [r15+0x08], r14
00007df2bcdd07cd  mov qword ptr [r15+0x10], 0x01
00007df2bcdd07d5  lea r14, [rax+0x8C]
00007df2bcdd07dc  mov eax, 0x80
00007df2bcdd07e1  mov [r13+r14*1], al
00007df2bcdd07e6  mov qword ptr [r15+0xF0], 0x410298
00007df2bcdd07f1  mov r14d, [r15+0x320]
00007df2bcdd07f8  mov eax, 0x410298
00007df2bcdd07fd  mov rcx, 0x7DF2BCDD0870
00007df2bcdd0807  mov [r15+r14*8+0x328], rax
00007df2bcdd080f  mov [r15+r14*8+0x368], rcx
00007df2bcdd0817  add r14d, 0x01
00007df2bcdd081b  and r14d, 0x07
00007df2bcdd081f  mov [r15+0x320], r14d
00007df2bcdd0826  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd082e  jz 0x00007DF2BCDCEC20
00007df2bcdd0834  nop [rax+rax*1], ax
00007df2bcdd083d  nop [rax+rax*1], eax
00007df2bcdd0845  mov eax, 0x410338
00007df2bcdd084a  mov [r15+0x100], rax
00007df2bcdd0851  jmp 0x00007DF2BCBFE110
00007df2bcdd0856  int3
00007df2bcdd0857  call 0x00007DF2BCCE27E0
00007df2bcdd085c  jmp 0x00007DF2BCDD07B0
00007df2bcdd0861  call 0x00007DF2BCCD5AF0
00007df2bcdd0866  jmp 0x00007DF2BCDD07E6
00007df2bcdd086b  int3
00007df2bcdd086c  nop [rax], eax
00007df2bcdd0870  mov rax, [r15+0xF8]
00007df2bcdd0877  lea r14, [rax+0x68]
00007df2bcdd087b  mov r12, [r13+r14*1]
00007df2bcdd0880  mov [r15+0x40], r12
00007df2bcdd0884  lea r14, [rax+0x88]
00007df2bcdd088b  xor eax, eax
00007df2bcdd088d  mov [r13+r14*1], al
00007df2bcdd0892  xor eax, eax
00007df2bcdd0894  mov r14d, 0x38
00007df2bcdd089a  cmp r12, r14
00007df2bcdd089d  cmc
00007df2bcdd089e  lahf
00007df2bcdd089f  seto al
00007df2bcdd08a2  mov [r15+0x108], eax
00007df2bcdd08a9  mov eax, [r15+0x108]
00007df2bcdd08b0  sahf
00007df2bcdd08b1  jz 0x00007DF2BCDD08E3
00007df2bcdd08b3  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd08bb  jz 0x00007DF2BCDD0930
00007df2bcdd08c1  nop [rax+rax*1], ax
00007df2bcdd08ca  nop [rax+rax*1], eax
00007df2bcdd08d2  mov eax, 0x4102A8
00007df2bcdd08d7  mov [r15+0x100], rax
00007df2bcdd08de  jmp 0x00007DF2BCBFE110
00007df2bcdd08e3  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd08eb  jz 0x00007DF2BCDD0A70
00007df2bcdd08f1  nop [rax+rax*1], ax
00007df2bcdd08fa  nop [rax+rax*1], eax
00007df2bcdd0902  mov eax, 0x4102C4
00007df2bcdd0907  mov [r15+0x100], rax
00007df2bcdd090e  jmp 0x00007DF2BCBFE110
00007df2bcdd0913  int3
00007df2bcdd0914  call 0x00007DF2BCCE27E0
00007df2bcdd0919  jmp 0x00007DF2BCDD0880
00007df2bcdd091e  call 0x00007DF2BCCD5AF0
00007df2bcdd0923  jmp 0x00007DF2BCDD0892
00007df2bcdd0928  int3
00007df2bcdd0929  nop [rax], eax
00007df2bcdd0930  mov rax, [r15+0xF8]
00007df2bcdd0937  mov [r15], rax
00007df2bcdd093a  lea r14, [rax+0x88]
00007df2bcdd0941  mov [r15+0x08], r14
00007df2bcdd0945  mov qword ptr [r15+0x10], 0x01
00007df2bcdd094d  mov qword ptr [r15+0xF0], 0x4102B8
00007df2bcdd0958  mov r14d, [r15+0x320]
00007df2bcdd095f  mov eax, 0x4102B8
00007df2bcdd0964  mov rcx, 0x7DF2BCDD09C0
00007df2bcdd096e  mov [r15+r14*8+0x328], rax
00007df2bcdd0976  mov [r15+r14*8+0x368], rcx
00007df2bcdd097e  add r14d, 0x01
00007df2bcdd0982  and r14d, 0x07
00007df2bcdd0986  mov [r15+0x320], r14d
00007df2bcdd098d  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd0995  jz 0x00007DF2BCDCEC20
00007df2bcdd099b  nop [rax+rax*1], ax
00007df2bcdd09a4  nop [rax+rax*1], eax
00007df2bcdd09ac  mov eax, 0x410338
00007df2bcdd09b1  mov [r15+0x100], rax
00007df2bcdd09b8  jmp 0x00007DF2BCBFE110
00007df2bcdd09bd  int3
00007df2bcdd09be  int3
00007df2bcdd09bf  nop
00007df2bcdd09c0  mov rax, [r15+0xF8]
00007df2bcdd09c7  lea r14, [rax+0x68]
00007df2bcdd09cb  mov rax, [r13+r14*1]
00007df2bcdd09d0  mov [r15+0x40], rax
00007df2bcdd09d4  mov [rsp+0x10], rax
00007df2bcdd09d9  xor eax, eax
00007df2bcdd09db  mov r14, [rsp+0x10]
00007df2bcdd09e0  mov r12d, 0x38
00007df2bcdd09e6  cmp r14, r12
00007df2bcdd09e9  cmc
00007df2bcdd09ea  lahf
00007df2bcdd09eb  seto al
00007df2bcdd09ee  mov [r15+0x108], eax
00007df2bcdd09f5  mov eax, [r15+0x108]
00007df2bcdd09fc  sahf
00007df2bcdd09fd  jnz 0x00007DF2BCDD0A2F
00007df2bcdd09ff  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd0a07  jz 0x00007DF2BCDD0A70
00007df2bcdd0a0d  nop [rax+rax*1], ax
00007df2bcdd0a16  nop [rax+rax*1], eax
00007df2bcdd0a1e  mov eax, 0x4102C4
00007df2bcdd0a23  mov [r15+0x100], rax
00007df2bcdd0a2a  jmp 0x00007DF2BCBFE110
00007df2bcdd0a2f  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd0a37  jz 0x00007DF2BCDD0930
00007df2bcdd0a3d  nop [rax+rax*1], ax
00007df2bcdd0a46  nop [rax+rax*1], eax
00007df2bcdd0a4e  mov eax, 0x4102A8
00007df2bcdd0a53  mov [r15+0x100], rax
00007df2bcdd0a5a  jmp 0x00007DF2BCBFE110
00007df2bcdd0a5f  int3
00007df2bcdd0a60  call 0x00007DF2BCCD59C0
00007df2bcdd0a65  jmp 0x00007DF2BCDD09D0
00007df2bcdd0a6a  int3
00007df2bcdd0a6b  nop [rax+rax*1], eax
00007df2bcdd0a70  mov rax, [r15+0x98]
00007df2bcdd0a77  rorx r14, rax, 0x3D
00007df2bcdd0a7d  and r14, 0xFFFFFFFFFFFFFFF8
00007df2bcdd0a81  mov rax, [r15+0xF8]
00007df2bcdd0a88  mov [r15], rax
00007df2bcdd0a8b  lea r12, [rax+0x78]
00007df2bcdd0a8f  mov [r15+0x08], r12
00007df2bcdd0a93  mov qword ptr [r15+0x10], 0x08
00007df2bcdd0a9b  bswap r14
00007df2bcdd0a9e  mov [r15+0x40], r14
00007df2bcdd0aa2  lea r12, [rax+0x78]
00007df2bcdd0aa6  mov [r13+r12*1], r14
00007df2bcdd0aab  mov qword ptr [r15+0xF0], 0x4102E0
00007df2bcdd0ab6  mov r14d, [r15+0x320]
00007df2bcdd0abd  mov eax, 0x4102E0
00007df2bcdd0ac2  mov rcx, 0x7DF2BCDD0B30
00007df2bcdd0acc  mov [r15+r14*8+0x328], rax
00007df2bcdd0ad4  mov [r15+r14*8+0x368], rcx
00007df2bcdd0adc  add r14d, 0x01
00007df2bcdd0ae0  and r14d, 0x07
00007df2bcdd0ae4  mov [r15+0x320], r14d
00007df2bcdd0aeb  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd0af3  jz 0x00007DF2BCDCEC20
00007df2bcdd0af9  nop [rax+rax*1], ax
00007df2bcdd0b02  nop [rax+rax*1], eax
00007df2bcdd0b0a  mov eax, 0x410338
00007df2bcdd0b0f  mov [r15+0x100], rax
00007df2bcdd0b16  jmp 0x00007DF2BCBFE110
00007df2bcdd0b1b  int3
00007df2bcdd0b1c  call 0x00007DF2BCCC3FE0
00007df2bcdd0b21  jmp 0x00007DF2BCDD0AAB
00007df2bcdd0b26  int3
00007df2bcdd0b27  nop [rax+rax*1], ax
00007df2bcdd0b30  mov rax, [r15+0xF8]
00007df2bcdd0b37  mov r14d, [r13+rax*1]
00007df2bcdd0b3c  lea r12, [rax+0x04]
00007df2bcdd0b40  mov r11d, [r13+r12*1]
00007df2bcdd0b45  lea r12, [rax+0x08]
00007df2bcdd0b49  mov r10d, [r13+r12*1]
00007df2bcdd0b4e  lea r12, [rax+0x0C]
00007df2bcdd0b52  mov r9d, [r13+r12*1]
00007df2bcdd0b57  mov qword ptr [r15+0x48], 0x430860
00007df2bcdd0b5f  lea r12, [rax+0x80]
00007df2bcdd0b66  mov r8, [r13+r12*1]
00007df2bcdd0b6b  mov [r15+0xF0], r8
00007df2bcdd0b72  bswap r14d
00007df2bcdd0b75  bswap r11d
00007df2bcdd0b78  mov r12d, 0x430860
00007df2bcdd0b7e  mov [r13+r12*1], r14d
00007df2bcdd0b83  mov r14d, 0x430864
00007df2bcdd0b89  mov [r13+r14*1], r11d
00007df2bcdd0b8e  bswap r10d
00007df2bcdd0b91  bswap r9d
00007df2bcdd0b94  lea r14, [rax+0x10]
00007df2bcdd0b98  mov r12d, [r13+r14*1]
00007df2bcdd0b9d  lea r14, [rax+0x14]
00007df2bcdd0ba1  mov r11d, [r13+r14*1]
00007df2bcdd0ba6  mov r14d, 0x430868
00007df2bcdd0bac  mov [r13+r14*1], r10d
00007df2bcdd0bb1  mov r14d, 0x43086C
00007df2bcdd0bb7  mov [r13+r14*1], r9d
00007df2bcdd0bbc  lea r14, [rax+0x90]
00007df2bcdd0bc3  mov r10, [r13+r14*1]
00007df2bcdd0bc8  lea r14, [rax+0x98]
00007df2bcdd0bcf  mov r9, [r13+r14*1]
00007df2bcdd0bd4  mov [r15+0xA0], r10
00007df2bcdd0bdb  mov [r15+0x98], r9
00007df2bcdd0be2  bswap r12d
00007df2bcdd0be5  bswap r11d
00007df2bcdd0be8  mov [rsp+0x10], r11d
00007df2bcdd0bed  mov r11d, r11d
00007df2bcdd0bf0  mov [r15+0x58], r11
00007df2bcdd0bf4  lea r14, [rax+0x18]
00007df2bcdd0bf8  mov r11d, [r13+r14*1]
00007df2bcdd0bfd  lea r14, [rax+0x1C]
00007df2bcdd0c01  mov r10d, [r13+r14*1]
00007df2bcdd0c06  mov [rsp+0x20], r10d
00007df2bcdd0c0b  mov r10d, r10d
00007df2bcdd0c0e  mov [r15+0x60], r10
00007df2bcdd0c12  mov r14d, 0x430870
00007df2bcdd0c18  mov [r13+r14*1], r12d
00007df2bcdd0c1d  mov r14d, 0x430874
00007df2bcdd0c23  mov r12d, [rsp+0x10]
00007df2bcdd0c28  mov [r13+r14*1], r12d
00007df2bcdd0c2d  bswap r11d
00007df2bcdd0c30  mov [rsp+0x10], r11d
00007df2bcdd0c35  mov r11d, r11d
00007df2bcdd0c38  mov [r15+0x40], r11
00007df2bcdd0c3c  mov r14d, [rsp+0x20]
00007df2bcdd0c41  bswap r14d
00007df2bcdd0c44  mov [rsp+0x20], r14d
00007df2bcdd0c49  mov r14d, r14d
00007df2bcdd0c4c  mov [r15+0x50], r14
00007df2bcdd0c50  mov r14d, 0x430878
00007df2bcdd0c56  mov r12d, [rsp+0x10]
00007df2bcdd0c5b  mov [r13+r14*1], r12d
00007df2bcdd0c60  mov r14d, 0x43087C
00007df2bcdd0c66  mov r12d, [rsp+0x20]
00007df2bcdd0c6b  mov [r13+r14*1], r12d
00007df2bcdd0c70  lea r14, [rax+0xA0]
00007df2bcdd0c77  mov [r15+0xF8], r14
00007df2bcdd0c7e  mov [r15+0x100], r8
00007df2bcdd0c85  jmp 0x00007DF2BCDCE5C0
00007df2bcdd0c8a  int3
00007df2bcdd0c8b  call 0x00007DF2BCC0DAE0
00007df2bcdd0c90  jmp 0x00007DF2BCDD0B3C
00007df2bcdd0c95  call 0x00007DF2BCCC0230
00007df2bcdd0c9a  jmp 0x00007DF2BCDD0B45
00007df2bcdd0c9f  call 0x00007DF2BCCBEFC0
00007df2bcdd0ca4  jmp 0x00007DF2BCDD0B4E
00007df2bcdd0ca9  call 0x00007DF2BCCBDD50
00007df2bcdd0cae  jmp 0x00007DF2BCDD0B57
00007df2bcdd0cb3  call 0x00007DF2BCCBCC20
00007df2bcdd0cb8  jmp 0x00007DF2BCDD0B6B
00007df2bcdd0cbd  call 0x00007DF2BCCC3EA0
00007df2bcdd0cc2  jmp 0x00007DF2BCDD0B83
00007df2bcdd0cc7  call 0x00007DF2BCCE1920
00007df2bcdd0ccc  jmp 0x00007DF2BCDD0B8E
00007df2bcdd0cd1  call 0x00007DF2BCCE26A0
00007df2bcdd0cd6  jmp 0x00007DF2BCDD0B9D
00007df2bcdd0cdb  call 0x00007DF2BCCE1430
00007df2bcdd0ce0  jmp 0x00007DF2BCDD0BA6
00007df2bcdd0ce5  call 0x00007DF2BCCE06B0
00007df2bcdd0cea  jmp 0x00007DF2BCDD0BB1
00007df2bcdd0cef  call 0x00007DF2BCCDF440
00007df2bcdd0cf4  jmp 0x00007DF2BCDD0BBC
00007df2bcdd0cf9  call 0x00007DF2BCCE0300
00007df2bcdd0cfe  jmp 0x00007DF2BCDD0BC8
00007df2bcdd0d03  call 0x00007DF2BCCDF090
00007df2bcdd0d08  jmp 0x00007DF2BCDD0BD4
00007df2bcdd0d0d  call 0x00007DF2BCCE1430
00007df2bcdd0d12  jmp 0x00007DF2BCDD0BFD
00007df2bcdd0d17  call 0x00007DF2BCCE01C0
00007df2bcdd0d1c  jmp 0x00007DF2BCDD0C06
00007df2bcdd0d21  call 0x00007DF2BCCE2BA0
00007df2bcdd0d26  jmp 0x00007DF2BCDD0C1D
00007df2bcdd0d2b  call 0x00007DF2BCCE2BA0
00007df2bcdd0d30  jmp 0x00007DF2BCDD0C2D
00007df2bcdd0d35  call 0x00007DF2BCCE2BA0
00007df2bcdd0d3a  jmp 0x00007DF2BCDD0C60
00007df2bcdd0d3f  call 0x00007DF2BCCE2BA0
00007df2bcdd0d44  jmp 0x00007DF2BCDD0C70
00007df2bcdd0d49  int3
00007df2bcdd0d4a  nop [rax+rax*1], ax
00007df2bcdd0d50  mov qword ptr [r15+0x100], 0x04
00007df2bcdd0d5b  mov esi, 0x00
00007df2bcdd0d60  mov edx, 0x09
00007df2bcdd0d65  mov rdi, 0x7FFFAA5B76A0
00007df2bcdd0d6f  mov rax, 0x5C8EC8044970
00007df2bcdd0d79  call rax
00007df2bcdd0d7b  cmp dword ptr [r15+0x318], 0x00
00007df2bcdd0d83  jnz 0x00007DF2BCBFE110
00007df2bcdd0d89  jmp 0x00007DF2BCBFE0A0
00007df2bcdd0d8e  int3
00007df2bcdd0d8f  int3
