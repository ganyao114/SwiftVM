
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/1/4.bin:     file format binary


Disassembly of section .data:

00007c0f94500f30 <.data>:
    7c0f94500f30:	sub    rsp,0x10
    7c0f94500f34:	mov    r11,QWORD PTR [r12+0x398]
    7c0f94500f3c:	mov    QWORD PTR [rsp],r11
    7c0f94500f40:	mov    r13,QWORD PTR [r12+0xf8]
    7c0f94500f48:	add    r13,0x68
    7c0f94500f4c:	mov    r14,QWORD PTR [r13+0x0]
    7c0f94500f50:	mov    QWORD PTR [r12+0x40],r14
    7c0f94500f55:	sub    r14,0x38
    7c0f94500f59:	mov    rcx,QWORD PTR [r12+0x380]
    7c0f94500f61:	jrcxz  0x7c0f94500f68
    7c0f94500f63:	jmp    0x7c0f94501035
    7c0f94500f68:	jne    0x7c0f94500f81
    7c0f94500f6e:	mov    r11,rax
    7c0f94500f71:	lahf
    7c0f94500f72:	seto   al
    7c0f94500f75:	mov    WORD PTR [rsp],ax
    7c0f94500f79:	mov    rax,r11
    7c0f94500f7c:	jmp    0x7c0f94500f94
    7c0f94500f81:	mov    r11,rax
    7c0f94500f84:	lahf
    7c0f94500f85:	seto   al
    7c0f94500f88:	mov    WORD PTR [rsp],ax
    7c0f94500f8c:	mov    rax,r11
    7c0f94500f8f:	jmp    0x7c0f94500fe5
    7c0f94500f94:	mov    r13d,0x4102c4
    7c0f94500f9a:	mov    QWORD PTR [r12+0x100],r13
    7c0f94500fa2:	mov    r11,QWORD PTR [rsp]
    7c0f94500fa6:	mov    QWORD PTR [r12+0x398],r11
    7c0f94500fae:	mov    edi,0x4102c4
    7c0f94500fb3:	mov    QWORD PTR [r12+0x100],rdi
    7c0f94500fbb:	add    rsp,0x10
    7c0f94500fbf:	nop
    7c0f94500fc0:	jmp    QWORD PTR [rip+0x2]        # 0x7c0f94500fc8
    7c0f94500fc6:	xchg   ax,ax
    7c0f94500fc8:	adc    BYTE PTR [rdi],cl
    7c0f94500fca:	push   rax
    7c0f94500fcb:	xchg   esp,eax
    7c0f94500fcc:	(bad)
    7c0f94500fce:	add    BYTE PTR [rax],al
    7c0f94500fd0:	fmul   DWORD PTR [rdi]
    7c0f94500fd2:	push   rax
    7c0f94500fd3:	xchg   esp,eax
    7c0f94500fd4:	(bad)
    7c0f94500fd6:	add    BYTE PTR [rax],al
    7c0f94500fd8:	movabs r11,0x62016968d940
    7c0f94500fe2:	jmp    r11
    7c0f94500fe5:	mov    r13d,0x4102a8
    7c0f94500feb:	mov    QWORD PTR [r12+0x100],r13
    7c0f94500ff3:	mov    r11,QWORD PTR [rsp]
    7c0f94500ff7:	mov    QWORD PTR [r12+0x398],r11
    7c0f94500fff:	mov    edi,0x4102a8
    7c0f94501004:	mov    QWORD PTR [r12+0x100],rdi
    7c0f9450100c:	add    rsp,0x10
    7c0f94501010:	jmp    QWORD PTR [rip+0x2]        # 0x7c0f94501018
    7c0f94501016:	xchg   ax,ax
    7c0f94501018:	lock (bad)
    7c0f9450101a:	push   rax
    7c0f9450101b:	xchg   esp,eax
    7c0f9450101c:	(bad)
    7c0f9450101e:	add    BYTE PTR [rax],al
    7c0f94501020:	sub    BYTE PTR [rax],dl
    7c0f94501022:	push   rax
    7c0f94501023:	xchg   esp,eax
    7c0f94501024:	(bad)
    7c0f94501026:	add    BYTE PTR [rax],al
    7c0f94501028:	movabs r11,0x62016968d940
    7c0f94501032:	jmp    r11
    7c0f94501035:	mov    eax,0x4102c0
    7c0f9450103a:	mov    QWORD PTR [r12+0x100],rax
    7c0f94501042:	push   rdx
    7c0f94501043:	push   rsi
    7c0f94501044:	push   r10
    7c0f94501046:	push   r11
    7c0f94501048:	mov    r11,rax
    7c0f9450104b:	lahf
    7c0f9450104c:	seto   al
    7c0f9450104f:	mov    WORD PTR [rsp+0x20],ax
    7c0f94501054:	mov    rax,r11
    7c0f94501057:	mov    rdx,QWORD PTR [rsp+0x20]
    7c0f9450105c:	mov    r10d,edx
    7c0f9450105f:	and    r10d,0xc000
    7c0f94501066:	shl    r10d,0x10
    7c0f9450106a:	mov    r11d,edx
    7c0f9450106d:	and    r11d,0x100
    7c0f94501074:	shl    r11d,0x15
    7c0f94501078:	or     r10d,r11d
    7c0f9450107b:	and    edx,0x1
    7c0f9450107e:	shl    edx,0x1c
    7c0f94501081:	or     r10d,edx
    7c0f94501084:	btc    r10,0x1d
    7c0f94501089:	mov    r11d,0xf0000000
    7c0f9450108f:	and    r11,r10
    7c0f94501092:	movabs rsi,0xffffffff0fffffff
    7c0f9450109c:	and    rbx,rsi
    7c0f9450109f:	or     rbx,r11
    7c0f945010a2:	pop    r11
    7c0f945010a4:	pop    r10
    7c0f945010a6:	pop    rsi
    7c0f945010a7:	pop    rdx
    7c0f945010a8:	mov    QWORD PTR [r12+0x108],rbx
    7c0f945010b0:	add    rsp,0x10
    7c0f945010b4:	mov    eax,0xc
    7c0f945010b9:	movabs r11,0x62016968dca0
    7c0f945010c3:	jmp    r11
    7c0f945010c6:	nop
    7c0f945010c7:	nop
