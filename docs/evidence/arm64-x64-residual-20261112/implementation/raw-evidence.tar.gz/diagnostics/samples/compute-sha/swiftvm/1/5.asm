
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sha/swiftvm/1/5.bin:     file format binary


Disassembly of section .data:

00007c0f945010d0 <.data>:
    7c0f945010d0:	sub    rsp,0x30
    7c0f945010d4:	mov    r11,QWORD PTR [r12+0x398]
    7c0f945010dc:	mov    QWORD PTR [rsp+0x18],r11
    7c0f945010e1:	mov    rax,QWORD PTR [r12+0xf8]
    7c0f945010e9:	mov    r14,QWORD PTR [r12+0xf8]
    7c0f945010f1:	add    r14,0x4
    7c0f945010f5:	mov    rdi,QWORD PTR [r12+0xf8]
    7c0f945010fd:	mov    r15d,DWORD PTR [rdi]
    7c0f94501100:	mov    ebp,DWORD PTR [r14]
    7c0f94501103:	mov    QWORD PTR [r12+0x40],r15
    7c0f94501108:	mov    QWORD PTR [r12+0x50],rbp
    7c0f9450110d:	mov    r14,QWORD PTR [r12+0xf8]
    7c0f94501115:	add    r14,0x8
    7c0f94501119:	mov    r8,r14
    7c0f9450111c:	add    r8,0x4
    7c0f94501120:	mov    r9d,DWORD PTR [r14]
    7c0f94501123:	mov    eax,DWORD PTR [r8]
    7c0f94501126:	mov    QWORD PTR [rsp],rax
    7c0f9450112a:	mov    QWORD PTR [r12+0x58],r9
    7c0f9450112f:	mov    rax,QWORD PTR [rsp]
    7c0f94501133:	mov    QWORD PTR [r12+0x60],rax
    7c0f94501138:	mov    r8d,0x430860
    7c0f9450113e:	mov    QWORD PTR [r12+0x48],r8
    7c0f94501143:	mov    r8,QWORD PTR [r12+0xf8]
    7c0f9450114b:	add    r8,0x80
    7c0f94501152:	mov    r13,QWORD PTR [r8]
    7c0f94501155:	mov    QWORD PTR [r12+0xf0],r13
    7c0f9450115d:	movabs rcx,0xff00ff00ff00ff
    7c0f94501167:	mov    r13,r15
    7c0f9450116a:	and    r13,rcx
    7c0f9450116d:	shl    r13,0x8
    7c0f94501171:	movabs rcx,0xff00ff00ff00ff00
    7c0f9450117b:	mov    r8,r15
    7c0f9450117e:	and    r8,rcx
    7c0f94501181:	shr    r8,0x8
    7c0f94501185:	or     r8,r13
    7c0f94501188:	movabs rcx,0xffff0000ffff
    7c0f94501192:	mov    r13,r8
    7c0f94501195:	and    r13,rcx
    7c0f94501198:	shl    r13,0x10
    7c0f9450119c:	movabs rcx,0xffff0000ffff0000
    7c0f945011a6:	and    r8,rcx
    7c0f945011a9:	shr    r8,0x10
    7c0f945011ad:	or     r8,r13
    7c0f945011b0:	mov    ecx,0xffffffff
    7c0f945011b5:	and    r8,rcx
    7c0f945011b8:	mov    QWORD PTR [r12+0x40],r8
    7c0f945011bd:	movabs rcx,0xff00ff00ff00ff
    7c0f945011c7:	mov    r13,rbp
    7c0f945011ca:	and    r13,rcx
    7c0f945011cd:	shl    r13,0x8
    7c0f945011d1:	movabs rcx,0xff00ff00ff00ff00
    7c0f945011db:	mov    r15,rbp
    7c0f945011de:	and    r15,rcx
    7c0f945011e1:	shr    r15,0x8
    7c0f945011e5:	or     r15,r13
    7c0f945011e8:	movabs rcx,0xffff0000ffff
    7c0f945011f2:	mov    r13,r15
    7c0f945011f5:	and    r13,rcx
    7c0f945011f8:	shl    r13,0x10
    7c0f945011fc:	movabs rcx,0xffff0000ffff0000
    7c0f94501206:	and    r15,rcx
    7c0f94501209:	shr    r15,0x10
    7c0f9450120d:	or     r15,r13
    7c0f94501210:	mov    ecx,0xffffffff
    7c0f94501215:	and    r15,rcx
    7c0f94501218:	mov    QWORD PTR [r12+0x50],r15
    7c0f9450121d:	mov    r13d,0x430860
    7c0f94501223:	mov    ebp,0x430864
    7c0f94501228:	mov    rax,r8
    7c0f9450122b:	mov    eax,eax
    7c0f9450122d:	mov    r14d,eax
    7c0f94501230:	mov    rax,r15
    7c0f94501233:	mov    eax,eax
    7c0f94501235:	mov    r8d,eax
    7c0f94501238:	mov    DWORD PTR [r13+0x0],r14d
    7c0f9450123c:	mov    r13d,0x0
    7c0f94501242:	mov    DWORD PTR [r12+0x32c],r13d
    7c0f9450124a:	mov    DWORD PTR [rbp+0x0],r8d
    7c0f9450124e:	movabs rcx,0xff00ff00ff00ff
    7c0f94501258:	mov    r13,r9
    7c0f9450125b:	and    r13,rcx
    7c0f9450125e:	shl    r13,0x8
    7c0f94501262:	movabs rcx,0xff00ff00ff00ff00
    7c0f9450126c:	mov    r14,r9
    7c0f9450126f:	and    r14,rcx
    7c0f94501272:	shr    r14,0x8
    7c0f94501276:	or     r14,r13
    7c0f94501279:	movabs rcx,0xffff0000ffff
    7c0f94501283:	mov    r13,r14
    7c0f94501286:	and    r13,rcx
    7c0f94501289:	shl    r13,0x10
    7c0f9450128d:	movabs rcx,0xffff0000ffff0000
    7c0f94501297:	and    r14,rcx
    7c0f9450129a:	shr    r14,0x10
    7c0f9450129e:	or     r14,r13
    7c0f945012a1:	mov    ecx,0xffffffff
    7c0f945012a6:	and    r14,rcx
    7c0f945012a9:	mov    QWORD PTR [r12+0x40],r14
    7c0f945012ae:	movabs rcx,0xff00ff00ff00ff
    7c0f945012b8:	mov    r13,QWORD PTR [rsp]
    7c0f945012bc:	and    r13,rcx
    7c0f945012bf:	shl    r13,0x8
    7c0f945012c3:	movabs rcx,0xff00ff00ff00ff00
    7c0f945012cd:	mov    r15,QWORD PTR [rsp]
    7c0f945012d1:	and    r15,rcx
    7c0f945012d4:	shr    r15,0x8
    7c0f945012d8:	or     r15,r13
    7c0f945012db:	movabs rcx,0xffff0000ffff
    7c0f945012e5:	mov    r13,r15
    7c0f945012e8:	and    r13,rcx
    7c0f945012eb:	shl    r13,0x10
    7c0f945012ef:	movabs rcx,0xffff0000ffff0000
    7c0f945012f9:	and    r15,rcx
    7c0f945012fc:	shr    r15,0x10
    7c0f94501300:	or     r15,r13
    7c0f94501303:	mov    ecx,0xffffffff
    7c0f94501308:	and    r15,rcx
    7c0f9450130b:	mov    QWORD PTR [r12+0x58],r15
    7c0f94501310:	mov    r13,QWORD PTR [r12+0xf8]
    7c0f94501318:	add    r13,0x10
    7c0f9450131c:	mov    rbp,r13
    7c0f9450131f:	add    rbp,0x4
    7c0f94501323:	mov    r8d,DWORD PTR [r13+0x0]
    7c0f94501327:	mov    eax,DWORD PTR [rbp+0x0]
    7c0f9450132a:	mov    QWORD PTR [rsp+0x8],rax
    7c0f9450132f:	mov    QWORD PTR [r12+0x50],r8
    7c0f94501334:	mov    rax,QWORD PTR [rsp+0x8]
    7c0f94501339:	mov    QWORD PTR [r12+0x60],rax
    7c0f9450133e:	mov    ebp,0x430868
    7c0f94501343:	mov    r9d,0x43086c
    7c0f94501349:	mov    rax,r14
    7c0f9450134c:	mov    eax,eax
    7c0f9450134e:	mov    r13d,eax
    7c0f94501351:	mov    rax,r15
    7c0f94501354:	mov    eax,eax
    7c0f94501356:	mov    r14d,eax
    7c0f94501359:	mov    DWORD PTR [rbp+0x0],r13d
    7c0f9450135d:	mov    DWORD PTR [r9],r14d
    7c0f94501360:	mov    r13,QWORD PTR [r12+0xf8]
    7c0f94501368:	add    r13,0x90
    7c0f9450136f:	mov    r14,r13
    7c0f94501372:	add    r14,0x8
    7c0f94501376:	mov    r15,QWORD PTR [r13+0x0]
    7c0f9450137a:	mov    r13,QWORD PTR [r14]
    7c0f9450137d:	mov    QWORD PTR [r12+0xa0],r15
    7c0f94501385:	mov    QWORD PTR [r12+0x98],r13
    7c0f9450138d:	movabs rcx,0xff00ff00ff00ff
    7c0f94501397:	mov    r13,r8
    7c0f9450139a:	and    r13,rcx
    7c0f9450139d:	shl    r13,0x8
    7c0f945013a1:	movabs rcx,0xff00ff00ff00ff00
    7c0f945013ab:	mov    r14,r8
    7c0f945013ae:	and    r14,rcx
    7c0f945013b1:	shr    r14,0x8
    7c0f945013b5:	or     r14,r13
    7c0f945013b8:	movabs rcx,0xffff0000ffff
    7c0f945013c2:	mov    r13,r14
    7c0f945013c5:	and    r13,rcx
    7c0f945013c8:	shl    r13,0x10
    7c0f945013cc:	movabs rcx,0xffff0000ffff0000
    7c0f945013d6:	and    r14,rcx
    7c0f945013d9:	shr    r14,0x10
    7c0f945013dd:	or     r14,r13
    7c0f945013e0:	mov    ecx,0xffffffff
    7c0f945013e5:	and    r14,rcx
    7c0f945013e8:	mov    QWORD PTR [r12+0x40],r14
    7c0f945013ed:	movabs rcx,0xff00ff00ff00ff
    7c0f945013f7:	mov    r13,QWORD PTR [rsp+0x8]
    7c0f945013fc:	and    r13,rcx
    7c0f945013ff:	shl    r13,0x8
    7c0f94501403:	movabs rcx,0xff00ff00ff00ff00
    7c0f9450140d:	mov    r15,QWORD PTR [rsp+0x8]
    7c0f94501412:	and    r15,rcx
    7c0f94501415:	shr    r15,0x8
    7c0f94501419:	or     r15,r13
    7c0f9450141c:	movabs rcx,0xffff0000ffff
    7c0f94501426:	mov    r13,r15
    7c0f94501429:	and    r13,rcx
    7c0f9450142c:	shl    r13,0x10
    7c0f94501430:	movabs rcx,0xffff0000ffff0000
    7c0f9450143a:	and    r15,rcx
    7c0f9450143d:	shr    r15,0x10
    7c0f94501441:	or     r15,r13
    7c0f94501444:	mov    ecx,0xffffffff
    7c0f94501449:	and    r15,rcx
    7c0f9450144c:	mov    QWORD PTR [r12+0x58],r15
    7c0f94501451:	mov    r13,QWORD PTR [r12+0xf8]
    7c0f94501459:	add    r13,0x18
    7c0f9450145d:	mov    rbp,r13
    7c0f94501460:	add    rbp,0x4
    7c0f94501464:	mov    r8d,DWORD PTR [r13+0x0]
    7c0f94501468:	mov    eax,DWORD PTR [rbp+0x0]
    7c0f9450146b:	mov    QWORD PTR [rsp+0x10],rax
    7c0f94501470:	mov    QWORD PTR [r12+0x50],r8
    7c0f94501475:	mov    rax,QWORD PTR [rsp+0x10]
    7c0f9450147a:	mov    QWORD PTR [r12+0x60],rax
    7c0f9450147f:	mov    ebp,0x430870
    7c0f94501484:	mov    r9d,0x430874
    7c0f9450148a:	mov    rax,r14
    7c0f9450148d:	mov    eax,eax
    7c0f9450148f:	mov    r13d,eax
    7c0f94501492:	mov    rax,r15
    7c0f94501495:	mov    eax,eax
    7c0f94501497:	mov    r14d,eax
    7c0f9450149a:	mov    DWORD PTR [rbp+0x0],r13d
    7c0f9450149e:	mov    DWORD PTR [r9],r14d
    7c0f945014a1:	movabs rcx,0xff00ff00ff00ff
    7c0f945014ab:	mov    r13,r8
    7c0f945014ae:	and    r13,rcx
    7c0f945014b1:	shl    r13,0x8
    7c0f945014b5:	movabs rcx,0xff00ff00ff00ff00
    7c0f945014bf:	mov    r14,r8
    7c0f945014c2:	and    r14,rcx
    7c0f945014c5:	shr    r14,0x8
    7c0f945014c9:	or     r14,r13
    7c0f945014cc:	movabs rcx,0xffff0000ffff
    7c0f945014d6:	mov    r13,r14
    7c0f945014d9:	and    r13,rcx
    7c0f945014dc:	shl    r13,0x10
    7c0f945014e0:	movabs rcx,0xffff0000ffff0000
    7c0f945014ea:	and    r14,rcx
    7c0f945014ed:	shr    r14,0x10
    7c0f945014f1:	or     r14,r13
    7c0f945014f4:	mov    ecx,0xffffffff
    7c0f945014f9:	and    r14,rcx
    7c0f945014fc:	mov    QWORD PTR [r12+0x40],r14
    7c0f94501501:	movabs rcx,0xff00ff00ff00ff
    7c0f9450150b:	mov    r13,QWORD PTR [rsp+0x10]
    7c0f94501510:	and    r13,rcx
    7c0f94501513:	shl    r13,0x8
    7c0f94501517:	movabs rcx,0xff00ff00ff00ff00
    7c0f94501521:	mov    r15,QWORD PTR [rsp+0x10]
    7c0f94501526:	and    r15,rcx
    7c0f94501529:	shr    r15,0x8
    7c0f9450152d:	or     r15,r13
    7c0f94501530:	movabs rcx,0xffff0000ffff
    7c0f9450153a:	mov    r13,r15
    7c0f9450153d:	and    r13,rcx
    7c0f94501540:	shl    r13,0x10
    7c0f94501544:	movabs rcx,0xffff0000ffff0000
    7c0f9450154e:	and    r15,rcx
    7c0f94501551:	shr    r15,0x10
    7c0f94501555:	or     r15,r13
    7c0f94501558:	mov    ecx,0xffffffff
    7c0f9450155d:	and    r15,rcx
    7c0f94501560:	mov    QWORD PTR [r12+0x50],r15
    7c0f94501565:	mov    r13d,0x430878
    7c0f9450156b:	mov    ebp,0x43087c
    7c0f94501570:	mov    rax,r14
    7c0f94501573:	mov    eax,eax
    7c0f94501575:	mov    r8d,eax
    7c0f94501578:	mov    rax,r15
    7c0f9450157b:	mov    eax,eax
    7c0f9450157d:	mov    r14d,eax
    7c0f94501580:	mov    DWORD PTR [r13+0x0],r8d
    7c0f94501584:	mov    DWORD PTR [rbp+0x0],r14d
    7c0f94501588:	mov    r13,QWORD PTR [r12+0xf8]
    7c0f94501590:	add    r13,0xa0
    7c0f94501597:	mov    QWORD PTR [r12+0xf8],r13
    7c0f9450159f:	mov    rcx,QWORD PTR [r12+0x380]
    7c0f945015a7:	jrcxz  0x7c0f945015ae
    7c0f945015a9:	jmp    0x7c0f945015e4
    7c0f945015ae:	mov    r13,QWORD PTR [r12+0xf0]
    7c0f945015b6:	mov    QWORD PTR [r12+0x100],r13
    7c0f945015be:	mov    r11,QWORD PTR [rsp+0x18]
    7c0f945015c3:	mov    QWORD PTR [r12+0x398],r11
    7c0f945015cb:	mov    rdi,QWORD PTR [r12+0x100]
    7c0f945015d3:	add    rsp,0x30
    7c0f945015d7:	movabs r11,0x62016968d940
    7c0f945015e1:	jmp    r11
    7c0f945015e4:	mov    eax,0x410334
    7c0f945015e9:	mov    QWORD PTR [r12+0x100],rax
    7c0f945015f1:	push   rdx
    7c0f945015f2:	push   rsi
    7c0f945015f3:	push   r10
    7c0f945015f5:	push   r11
    7c0f945015f7:	mov    rdx,QWORD PTR [rsp+0x38]
    7c0f945015fc:	mov    r10d,edx
    7c0f945015ff:	and    r10d,0xc000
    7c0f94501606:	shl    r10d,0x10
    7c0f9450160a:	mov    r11d,edx
    7c0f9450160d:	and    r11d,0x100
    7c0f94501614:	shl    r11d,0x15
    7c0f94501618:	or     r10d,r11d
    7c0f9450161b:	and    edx,0x1
    7c0f9450161e:	shl    edx,0x1c
    7c0f94501621:	or     r10d,edx
    7c0f94501624:	btc    r10,0x1d
    7c0f94501629:	mov    r11d,0xf0000000
    7c0f9450162f:	and    r11,r10
    7c0f94501632:	movabs rsi,0xffffffff0fffffff
    7c0f9450163c:	and    rbx,rsi
    7c0f9450163f:	or     rbx,r11
    7c0f94501642:	pop    r11
    7c0f94501644:	pop    r10
    7c0f94501646:	pop    rsi
    7c0f94501647:	pop    rdx
    7c0f94501648:	mov    QWORD PTR [r12+0x108],rbx
    7c0f94501650:	add    rsp,0x30
    7c0f94501654:	mov    eax,0xc
    7c0f94501659:	movabs r11,0x62016968dca0
    7c0f94501663:	jmp    r11
    7c0f94501666:	nop
    7c0f94501667:	nop
