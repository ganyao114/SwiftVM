
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/shift/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

000070f549500000 <.data>:
    70f549500000:	sub    rsp,0x10
    70f549500004:	mov    r13d,0x1b00
    70f54950000a:	mov    r14d,0xb7
    70f549500010:	and    r14d,0xffff
    70f549500017:	mov    rax,r13
    70f54950001a:	movabs rcx,0xffffffff0000ffff
    70f549500024:	and    rax,rcx
    70f549500027:	mov    rdx,r14
    70f54950002a:	shl    rdx,0x10
    70f54950002e:	mov    ecx,0xffff0000
    70f549500033:	and    rdx,rcx
    70f549500036:	or     rax,rdx
    70f549500039:	mov    r15,rax
    70f54950003c:	mov    QWORD PTR [r12+0x8],r15
    70f549500041:	mov    r13d,0x420060
    70f549500047:	mov    QWORD PTR [r12+0x20],r13
    70f54950004c:	mov    r13d,0x0
    70f549500052:	mov    QWORD PTR [r12],r13
    70f549500056:	jmp    0x70f54950005b
    70f54950005b:	mov    r13,QWORD PTR [r12]
    70f54950005f:	ror    r13,0xd
    70f549500063:	mov    r14,r13
    70f549500066:	shr    r14,0x7
    70f54950006a:	xor    r13,r14
    70f54950006d:	add    r13,0x3
    70f549500071:	mov    QWORD PTR [r12],r13
    70f549500075:	mov    r13,QWORD PTR [r12+0x8]
    70f54950007a:	sub    r13,0x1
    70f54950007e:	mov    QWORD PTR [r12+0x8],r13
    70f549500083:	mov    rcx,QWORD PTR [r12+0x380]
    70f54950008b:	jrcxz  0x70f549500092
    70f54950008d:	jmp    0x70f54950010a
    70f549500092:	jne    0x70f54950005b
    70f549500098:	mov    r11,rax
    70f54950009b:	lahf
    70f54950009c:	seto   al
    70f54950009f:	mov    WORD PTR [rsp],ax
    70f5495000a3:	mov    rax,r11
    70f5495000a6:	jmp    0x70f5495000ab
    70f5495000ab:	mov    r13,QWORD PTR [r12+0x20]
    70f5495000b0:	mov    r14,QWORD PTR [r12]
    70f5495000b4:	mov    QWORD PTR [r13+0x0],r14
    70f5495000b8:	mov    r13d,0x0
    70f5495000be:	mov    DWORD PTR [r12+0x32c],r13d
    70f5495000c6:	mov    rcx,QWORD PTR [r12+0x380]
    70f5495000ce:	jrcxz  0x70f5495000d5
    70f5495000d0:	jmp    0x70f54950019b
    70f5495000d5:	mov    r13,QWORD PTR [r12+0xf0]
    70f5495000dd:	mov    QWORD PTR [r12+0x100],r13
    70f5495000e5:	mov    r11,QWORD PTR [rsp]
    70f5495000e9:	mov    QWORD PTR [r12+0x398],r11
    70f5495000f1:	mov    rdi,QWORD PTR [r12+0x100]
    70f5495000f9:	add    rsp,0x10
    70f5495000fd:	movabs r11,0x616905b19940
    70f549500107:	jmp    r11
    70f54950010a:	mov    eax,0x41004c
    70f54950010f:	mov    QWORD PTR [r12+0x100],rax
    70f549500117:	push   rdx
    70f549500118:	push   rsi
    70f549500119:	push   r10
    70f54950011b:	push   r11
    70f54950011d:	mov    r11,rax
    70f549500120:	lahf
    70f549500121:	seto   al
    70f549500124:	mov    WORD PTR [rsp+0x20],ax
    70f549500129:	mov    rax,r11
    70f54950012c:	mov    rdx,QWORD PTR [rsp+0x20]
    70f549500131:	mov    r10d,edx
    70f549500134:	and    r10d,0xc000
    70f54950013b:	shl    r10d,0x10
    70f54950013f:	mov    r11d,edx
    70f549500142:	and    r11d,0x100
    70f549500149:	shl    r11d,0x15
    70f54950014d:	or     r10d,r11d
    70f549500150:	and    edx,0x1
    70f549500153:	shl    edx,0x1c
    70f549500156:	or     r10d,edx
    70f549500159:	btc    r10,0x1d
    70f54950015e:	mov    r11d,0xf0000000
    70f549500164:	and    r11,r10
    70f549500167:	movabs rsi,0xffffffff0fffffff
    70f549500171:	and    rbx,rsi
    70f549500174:	or     rbx,r11
    70f549500177:	pop    r11
    70f549500179:	pop    r10
    70f54950017b:	pop    rsi
    70f54950017c:	pop    rdx
    70f54950017d:	mov    QWORD PTR [r12+0x108],rbx
    70f549500185:	add    rsp,0x10
    70f549500189:	mov    eax,0xc
    70f54950018e:	movabs r11,0x616905b19ca0
    70f549500198:	jmp    r11
    70f54950019b:	mov    eax,0x410054
    70f5495001a0:	mov    QWORD PTR [r12+0x100],rax
    70f5495001a8:	push   rdx
    70f5495001a9:	push   rsi
    70f5495001aa:	push   r10
    70f5495001ac:	push   r11
    70f5495001ae:	mov    rdx,QWORD PTR [rsp+0x20]
    70f5495001b3:	mov    r10d,edx
    70f5495001b6:	and    r10d,0xc000
    70f5495001bd:	shl    r10d,0x10
    70f5495001c1:	mov    r11d,edx
    70f5495001c4:	and    r11d,0x100
    70f5495001cb:	shl    r11d,0x15
    70f5495001cf:	or     r10d,r11d
    70f5495001d2:	and    edx,0x1
    70f5495001d5:	shl    edx,0x1c
    70f5495001d8:	or     r10d,edx
    70f5495001db:	btc    r10,0x1d
    70f5495001e0:	mov    r11d,0xf0000000
    70f5495001e6:	and    r11,r10
    70f5495001e9:	movabs rsi,0xffffffff0fffffff
    70f5495001f3:	and    rbx,rsi
    70f5495001f6:	or     rbx,r11
    70f5495001f9:	pop    r11
    70f5495001fb:	pop    r10
    70f5495001fd:	pop    rsi
    70f5495001fe:	pop    rdx
    70f5495001ff:	mov    QWORD PTR [r12+0x108],rbx
    70f549500207:	add    rsp,0x10
    70f54950020b:	mov    eax,0xc
    70f549500210:	movabs r11,0x616905b19ca0
    70f54950021a:	jmp    r11
    70f54950021d:	nop    DWORD PTR [rax]
    70f549500220:	sub    rsp,0x10
    70f549500224:	jmp    0x70f54950005b
    70f549500229:	nop    DWORD PTR [rax+0x0]
    70f549500230:	sub    rsp,0x10
    70f549500234:	mov    r11,QWORD PTR [r12+0x398]
    70f54950023c:	mov    QWORD PTR [rsp],r11
    70f549500240:	jmp    0x70f5495000ab
    70f549500245:	nop
    70f549500246:	nop
    70f549500247:	nop
