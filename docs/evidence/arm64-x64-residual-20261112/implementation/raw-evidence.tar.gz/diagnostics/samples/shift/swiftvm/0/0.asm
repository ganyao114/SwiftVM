
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/shift/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

0000701730700000 <.data>:
    701730700000:	sub    rsp,0x10
    701730700004:	mov    r13d,0x1b00
    70173070000a:	mov    r14d,0xb7
    701730700010:	and    r14d,0xffff
    701730700017:	mov    rax,r13
    70173070001a:	movabs rcx,0xffffffff0000ffff
    701730700024:	and    rax,rcx
    701730700027:	mov    rdx,r14
    70173070002a:	shl    rdx,0x10
    70173070002e:	mov    ecx,0xffff0000
    701730700033:	and    rdx,rcx
    701730700036:	or     rax,rdx
    701730700039:	mov    r15,rax
    70173070003c:	mov    QWORD PTR [r12+0x8],r15
    701730700041:	mov    r13d,0x420060
    701730700047:	mov    QWORD PTR [r12+0x20],r13
    70173070004c:	mov    r13d,0x0
    701730700052:	mov    QWORD PTR [r12],r13
    701730700056:	jmp    0x70173070005b
    70173070005b:	mov    r13,QWORD PTR [r12]
    70173070005f:	ror    r13,0xd
    701730700063:	mov    r14,r13
    701730700066:	shr    r14,0x7
    70173070006a:	xor    r13,r14
    70173070006d:	add    r13,0x3
    701730700071:	mov    QWORD PTR [r12],r13
    701730700075:	mov    r13,QWORD PTR [r12+0x8]
    70173070007a:	sub    r13,0x1
    70173070007e:	mov    QWORD PTR [r12+0x8],r13
    701730700083:	mov    rcx,QWORD PTR [r12+0x380]
    70173070008b:	jrcxz  0x701730700092
    70173070008d:	jmp    0x70173070010a
    701730700092:	jne    0x70173070005b
    701730700098:	mov    r11,rax
    70173070009b:	lahf
    70173070009c:	seto   al
    70173070009f:	mov    WORD PTR [rsp],ax
    7017307000a3:	mov    rax,r11
    7017307000a6:	jmp    0x7017307000ab
    7017307000ab:	mov    r13,QWORD PTR [r12+0x20]
    7017307000b0:	mov    r14,QWORD PTR [r12]
    7017307000b4:	mov    QWORD PTR [r13+0x0],r14
    7017307000b8:	mov    r13d,0x0
    7017307000be:	mov    DWORD PTR [r12+0x32c],r13d
    7017307000c6:	mov    rcx,QWORD PTR [r12+0x380]
    7017307000ce:	jrcxz  0x7017307000d5
    7017307000d0:	jmp    0x70173070019b
    7017307000d5:	mov    r13,QWORD PTR [r12+0xf0]
    7017307000dd:	mov    QWORD PTR [r12+0x100],r13
    7017307000e5:	mov    r11,QWORD PTR [rsp]
    7017307000e9:	mov    QWORD PTR [r12+0x398],r11
    7017307000f1:	mov    rdi,QWORD PTR [r12+0x100]
    7017307000f9:	add    rsp,0x10
    7017307000fd:	movabs r11,0x6240b80c3940
    701730700107:	jmp    r11
    70173070010a:	mov    eax,0x41004c
    70173070010f:	mov    QWORD PTR [r12+0x100],rax
    701730700117:	push   rdx
    701730700118:	push   rsi
    701730700119:	push   r10
    70173070011b:	push   r11
    70173070011d:	mov    r11,rax
    701730700120:	lahf
    701730700121:	seto   al
    701730700124:	mov    WORD PTR [rsp+0x20],ax
    701730700129:	mov    rax,r11
    70173070012c:	mov    rdx,QWORD PTR [rsp+0x20]
    701730700131:	mov    r10d,edx
    701730700134:	and    r10d,0xc000
    70173070013b:	shl    r10d,0x10
    70173070013f:	mov    r11d,edx
    701730700142:	and    r11d,0x100
    701730700149:	shl    r11d,0x15
    70173070014d:	or     r10d,r11d
    701730700150:	and    edx,0x1
    701730700153:	shl    edx,0x1c
    701730700156:	or     r10d,edx
    701730700159:	btc    r10,0x1d
    70173070015e:	mov    r11d,0xf0000000
    701730700164:	and    r11,r10
    701730700167:	movabs rsi,0xffffffff0fffffff
    701730700171:	and    rbx,rsi
    701730700174:	or     rbx,r11
    701730700177:	pop    r11
    701730700179:	pop    r10
    70173070017b:	pop    rsi
    70173070017c:	pop    rdx
    70173070017d:	mov    QWORD PTR [r12+0x108],rbx
    701730700185:	add    rsp,0x10
    701730700189:	mov    eax,0xc
    70173070018e:	movabs r11,0x6240b80c3ca0
    701730700198:	jmp    r11
    70173070019b:	mov    eax,0x410054
    7017307001a0:	mov    QWORD PTR [r12+0x100],rax
    7017307001a8:	push   rdx
    7017307001a9:	push   rsi
    7017307001aa:	push   r10
    7017307001ac:	push   r11
    7017307001ae:	mov    rdx,QWORD PTR [rsp+0x20]
    7017307001b3:	mov    r10d,edx
    7017307001b6:	and    r10d,0xc000
    7017307001bd:	shl    r10d,0x10
    7017307001c1:	mov    r11d,edx
    7017307001c4:	and    r11d,0x100
    7017307001cb:	shl    r11d,0x15
    7017307001cf:	or     r10d,r11d
    7017307001d2:	and    edx,0x1
    7017307001d5:	shl    edx,0x1c
    7017307001d8:	or     r10d,edx
    7017307001db:	btc    r10,0x1d
    7017307001e0:	mov    r11d,0xf0000000
    7017307001e6:	and    r11,r10
    7017307001e9:	movabs rsi,0xffffffff0fffffff
    7017307001f3:	and    rbx,rsi
    7017307001f6:	or     rbx,r11
    7017307001f9:	pop    r11
    7017307001fb:	pop    r10
    7017307001fd:	pop    rsi
    7017307001fe:	pop    rdx
    7017307001ff:	mov    QWORD PTR [r12+0x108],rbx
    701730700207:	add    rsp,0x10
    70173070020b:	mov    eax,0xc
    701730700210:	movabs r11,0x6240b80c3ca0
    70173070021a:	jmp    r11
    70173070021d:	nop    DWORD PTR [rax]
    701730700220:	sub    rsp,0x10
    701730700224:	jmp    0x70173070005b
    701730700229:	nop    DWORD PTR [rax+0x0]
    701730700230:	sub    rsp,0x10
    701730700234:	mov    r11,QWORD PTR [r12+0x398]
    70173070023c:	mov    QWORD PTR [rsp],r11
    701730700240:	jmp    0x7017307000ab
    701730700245:	nop
    701730700246:	nop
    701730700247:	nop
