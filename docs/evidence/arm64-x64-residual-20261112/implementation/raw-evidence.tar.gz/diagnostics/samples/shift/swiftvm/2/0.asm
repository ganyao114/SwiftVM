
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/shift/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

000079424f900000 <.data>:
    79424f900000:	sub    rsp,0x10
    79424f900004:	mov    r13d,0x1b00
    79424f90000a:	mov    r14d,0xb7
    79424f900010:	and    r14d,0xffff
    79424f900017:	mov    rax,r13
    79424f90001a:	movabs rcx,0xffffffff0000ffff
    79424f900024:	and    rax,rcx
    79424f900027:	mov    rdx,r14
    79424f90002a:	shl    rdx,0x10
    79424f90002e:	mov    ecx,0xffff0000
    79424f900033:	and    rdx,rcx
    79424f900036:	or     rax,rdx
    79424f900039:	mov    r15,rax
    79424f90003c:	mov    QWORD PTR [r12+0x8],r15
    79424f900041:	mov    r13d,0x420060
    79424f900047:	mov    QWORD PTR [r12+0x20],r13
    79424f90004c:	mov    r13d,0x0
    79424f900052:	mov    QWORD PTR [r12],r13
    79424f900056:	jmp    0x79424f90005b
    79424f90005b:	mov    r13,QWORD PTR [r12]
    79424f90005f:	ror    r13,0xd
    79424f900063:	mov    r14,r13
    79424f900066:	shr    r14,0x7
    79424f90006a:	xor    r13,r14
    79424f90006d:	add    r13,0x3
    79424f900071:	mov    QWORD PTR [r12],r13
    79424f900075:	mov    r13,QWORD PTR [r12+0x8]
    79424f90007a:	sub    r13,0x1
    79424f90007e:	mov    QWORD PTR [r12+0x8],r13
    79424f900083:	mov    rcx,QWORD PTR [r12+0x380]
    79424f90008b:	jrcxz  0x79424f900092
    79424f90008d:	jmp    0x79424f90010a
    79424f900092:	jne    0x79424f90005b
    79424f900098:	mov    r11,rax
    79424f90009b:	lahf
    79424f90009c:	seto   al
    79424f90009f:	mov    WORD PTR [rsp],ax
    79424f9000a3:	mov    rax,r11
    79424f9000a6:	jmp    0x79424f9000ab
    79424f9000ab:	mov    r13,QWORD PTR [r12+0x20]
    79424f9000b0:	mov    r14,QWORD PTR [r12]
    79424f9000b4:	mov    QWORD PTR [r13+0x0],r14
    79424f9000b8:	mov    r13d,0x0
    79424f9000be:	mov    DWORD PTR [r12+0x32c],r13d
    79424f9000c6:	mov    rcx,QWORD PTR [r12+0x380]
    79424f9000ce:	jrcxz  0x79424f9000d5
    79424f9000d0:	jmp    0x79424f90019b
    79424f9000d5:	mov    r13,QWORD PTR [r12+0xf0]
    79424f9000dd:	mov    QWORD PTR [r12+0x100],r13
    79424f9000e5:	mov    r11,QWORD PTR [rsp]
    79424f9000e9:	mov    QWORD PTR [r12+0x398],r11
    79424f9000f1:	mov    rdi,QWORD PTR [r12+0x100]
    79424f9000f9:	add    rsp,0x10
    79424f9000fd:	movabs r11,0x5786eab7e940
    79424f900107:	jmp    r11
    79424f90010a:	mov    eax,0x41004c
    79424f90010f:	mov    QWORD PTR [r12+0x100],rax
    79424f900117:	push   rdx
    79424f900118:	push   rsi
    79424f900119:	push   r10
    79424f90011b:	push   r11
    79424f90011d:	mov    r11,rax
    79424f900120:	lahf
    79424f900121:	seto   al
    79424f900124:	mov    WORD PTR [rsp+0x20],ax
    79424f900129:	mov    rax,r11
    79424f90012c:	mov    rdx,QWORD PTR [rsp+0x20]
    79424f900131:	mov    r10d,edx
    79424f900134:	and    r10d,0xc000
    79424f90013b:	shl    r10d,0x10
    79424f90013f:	mov    r11d,edx
    79424f900142:	and    r11d,0x100
    79424f900149:	shl    r11d,0x15
    79424f90014d:	or     r10d,r11d
    79424f900150:	and    edx,0x1
    79424f900153:	shl    edx,0x1c
    79424f900156:	or     r10d,edx
    79424f900159:	btc    r10,0x1d
    79424f90015e:	mov    r11d,0xf0000000
    79424f900164:	and    r11,r10
    79424f900167:	movabs rsi,0xffffffff0fffffff
    79424f900171:	and    rbx,rsi
    79424f900174:	or     rbx,r11
    79424f900177:	pop    r11
    79424f900179:	pop    r10
    79424f90017b:	pop    rsi
    79424f90017c:	pop    rdx
    79424f90017d:	mov    QWORD PTR [r12+0x108],rbx
    79424f900185:	add    rsp,0x10
    79424f900189:	mov    eax,0xc
    79424f90018e:	movabs r11,0x5786eab7eca0
    79424f900198:	jmp    r11
    79424f90019b:	mov    eax,0x410054
    79424f9001a0:	mov    QWORD PTR [r12+0x100],rax
    79424f9001a8:	push   rdx
    79424f9001a9:	push   rsi
    79424f9001aa:	push   r10
    79424f9001ac:	push   r11
    79424f9001ae:	mov    rdx,QWORD PTR [rsp+0x20]
    79424f9001b3:	mov    r10d,edx
    79424f9001b6:	and    r10d,0xc000
    79424f9001bd:	shl    r10d,0x10
    79424f9001c1:	mov    r11d,edx
    79424f9001c4:	and    r11d,0x100
    79424f9001cb:	shl    r11d,0x15
    79424f9001cf:	or     r10d,r11d
    79424f9001d2:	and    edx,0x1
    79424f9001d5:	shl    edx,0x1c
    79424f9001d8:	or     r10d,edx
    79424f9001db:	btc    r10,0x1d
    79424f9001e0:	mov    r11d,0xf0000000
    79424f9001e6:	and    r11,r10
    79424f9001e9:	movabs rsi,0xffffffff0fffffff
    79424f9001f3:	and    rbx,rsi
    79424f9001f6:	or     rbx,r11
    79424f9001f9:	pop    r11
    79424f9001fb:	pop    r10
    79424f9001fd:	pop    rsi
    79424f9001fe:	pop    rdx
    79424f9001ff:	mov    QWORD PTR [r12+0x108],rbx
    79424f900207:	add    rsp,0x10
    79424f90020b:	mov    eax,0xc
    79424f900210:	movabs r11,0x5786eab7eca0
    79424f90021a:	jmp    r11
    79424f90021d:	nop    DWORD PTR [rax]
    79424f900220:	sub    rsp,0x10
    79424f900224:	jmp    0x79424f90005b
    79424f900229:	nop    DWORD PTR [rax+0x0]
    79424f900230:	sub    rsp,0x10
    79424f900234:	mov    r11,QWORD PTR [r12+0x398]
    79424f90023c:	mov    QWORD PTR [rsp],r11
    79424f900240:	jmp    0x79424f9000ab
    79424f900245:	nop
    79424f900246:	nop
    79424f900247:	nop
