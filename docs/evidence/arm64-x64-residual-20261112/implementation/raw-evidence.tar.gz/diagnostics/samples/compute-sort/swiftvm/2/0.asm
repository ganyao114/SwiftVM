
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sort/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

00007ba63c6fe000 <.data>:
    7ba63c6fe000:	sub    rsp,0x10
    7ba63c6fe004:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6fe00c:	mov    QWORD PTR [rsp],r11
    7ba63c6fe010:	mov    r13,QWORD PTR [r12+0xf8]
    7ba63c6fe018:	sub    r13,0x20
    7ba63c6fe01c:	mov    r14,QWORD PTR [r12+0xf0]
    7ba63c6fe024:	mov    QWORD PTR [r13+0x0],r14
    7ba63c6fe028:	mov    r14d,0x0
    7ba63c6fe02e:	mov    DWORD PTR [r12+0x32c],r14d
    7ba63c6fe036:	mov    QWORD PTR [r12+0xf8],r13
    7ba63c6fe03e:	add    r13,0x10
    7ba63c6fe042:	mov    r14,r13
    7ba63c6fe045:	add    r14,0x8
    7ba63c6fe049:	mov    r15,QWORD PTR [r12+0xa0]
    7ba63c6fe051:	mov    rbp,QWORD PTR [r12+0x98]
    7ba63c6fe059:	mov    QWORD PTR [r13+0x0],r15
    7ba63c6fe05d:	mov    QWORD PTR [r14],rbp
    7ba63c6fe060:	mov    r13d,0x0
    7ba63c6fe066:	mov    QWORD PTR [r12+0xa0],r13
    7ba63c6fe06e:	mov    r13d,0x420000
    7ba63c6fe074:	add    r13,0x2a0
    7ba63c6fe07b:	mov    QWORD PTR [r12+0x98],r13
    7ba63c6fe083:	mov    r13d,0x11
    7ba63c6fe089:	mov    QWORD PTR [r12],r13
    7ba63c6fe08d:	mov    r13d,0x410184
    7ba63c6fe093:	mov    QWORD PTR [r12+0xf0],r13
    7ba63c6fe09b:	mov    r13d,0x41021c
    7ba63c6fe0a1:	mov    QWORD PTR [r12+0x100],r13
    7ba63c6fe0a9:	mov    r11,QWORD PTR [rsp]
    7ba63c6fe0ad:	mov    QWORD PTR [r12+0x398],r11
    7ba63c6fe0b5:	mov    edi,0x41021c
    7ba63c6fe0ba:	mov    QWORD PTR [r12+0x100],rdi
    7ba63c6fe0c2:	add    rsp,0x10
    7ba63c6fe0c6:	xchg   ax,ax
    7ba63c6fe0c8:	jmp    QWORD PTR [rip+0x2]        # 0x7ba63c6fe0d0
    7ba63c6fe0ce:	xchg   ax,ax
    7ba63c6fe0d0:	lock loopne 0x7ba63c6fe142
    7ba63c6fe0d3:	cmp    al,0xa6
    7ba63c6fe0d5:	jnp    0x7ba63c6fe0d7
    7ba63c6fe0d7:	add    al,ah
    7ba63c6fe0d9:	loopne 0x7ba63c6fe14a
    7ba63c6fe0db:	cmp    al,0xa6
    7ba63c6fe0dd:	jnp    0x7ba63c6fe0df
    7ba63c6fe0df:	add    BYTE PTR [rcx-0x45],cl
    7ba63c6fe0e2:	rex cdq
    7ba63c6fe0e4:	loop   0x7ba63c6fe135
    7ba63c6fe0e6:	call   FWORD PTR [rsi+0x0]
    7ba63c6fe0e9:	add    BYTE PTR [rcx-0x1],al
    7ba63c6fe0ec:	jrcxz  0x7ba63c6fe07e
    7ba63c6fe0ee:	nop
    7ba63c6fe0ef:	nop
