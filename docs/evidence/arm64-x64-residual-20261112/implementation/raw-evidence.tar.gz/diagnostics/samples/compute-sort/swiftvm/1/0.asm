
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sort/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

000076bba08fe000 <.data>:
    76bba08fe000:	sub    rsp,0x10
    76bba08fe004:	mov    r11,QWORD PTR [r12+0x398]
    76bba08fe00c:	mov    QWORD PTR [rsp],r11
    76bba08fe010:	mov    r13,QWORD PTR [r12+0xf8]
    76bba08fe018:	sub    r13,0x20
    76bba08fe01c:	mov    r14,QWORD PTR [r12+0xf0]
    76bba08fe024:	mov    QWORD PTR [r13+0x0],r14
    76bba08fe028:	mov    r14d,0x0
    76bba08fe02e:	mov    DWORD PTR [r12+0x32c],r14d
    76bba08fe036:	mov    QWORD PTR [r12+0xf8],r13
    76bba08fe03e:	add    r13,0x10
    76bba08fe042:	mov    r14,r13
    76bba08fe045:	add    r14,0x8
    76bba08fe049:	mov    r15,QWORD PTR [r12+0xa0]
    76bba08fe051:	mov    rbp,QWORD PTR [r12+0x98]
    76bba08fe059:	mov    QWORD PTR [r13+0x0],r15
    76bba08fe05d:	mov    QWORD PTR [r14],rbp
    76bba08fe060:	mov    r13d,0x0
    76bba08fe066:	mov    QWORD PTR [r12+0xa0],r13
    76bba08fe06e:	mov    r13d,0x420000
    76bba08fe074:	add    r13,0x2a0
    76bba08fe07b:	mov    QWORD PTR [r12+0x98],r13
    76bba08fe083:	mov    r13d,0x11
    76bba08fe089:	mov    QWORD PTR [r12],r13
    76bba08fe08d:	mov    r13d,0x410184
    76bba08fe093:	mov    QWORD PTR [r12+0xf0],r13
    76bba08fe09b:	mov    r13d,0x41021c
    76bba08fe0a1:	mov    QWORD PTR [r12+0x100],r13
    76bba08fe0a9:	mov    r11,QWORD PTR [rsp]
    76bba08fe0ad:	mov    QWORD PTR [r12+0x398],r11
    76bba08fe0b5:	mov    edi,0x41021c
    76bba08fe0ba:	mov    QWORD PTR [r12+0x100],rdi
    76bba08fe0c2:	add    rsp,0x10
    76bba08fe0c6:	xchg   ax,ax
    76bba08fe0c8:	jmp    QWORD PTR [rip+0x2]        # 0x76bba08fe0d0
    76bba08fe0ce:	xchg   ax,ax
    76bba08fe0d0:	lock loopne 0x76bba08fe062
    76bba08fe0d3:	movabs al,ds:0xa08fe0e0000076bb
    76bba08fe0dc:	mov    ebx,0x49000076
    76bba08fe0e1:	mov    ebx,0xad6b0940
    76bba08fe0e6:	or     al,0x59
    76bba08fe0e8:	add    BYTE PTR [rax],al
    76bba08fe0ea:	jmp    r11
    76bba08fe0ed:	nop
    76bba08fe0ee:	nop
    76bba08fe0ef:	nop
