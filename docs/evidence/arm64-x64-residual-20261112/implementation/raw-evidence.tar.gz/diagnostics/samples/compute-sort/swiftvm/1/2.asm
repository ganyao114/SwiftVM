
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sort/swiftvm/1/2.bin:     file format binary


Disassembly of section .data:

000076bba08fe2b0 <.data>:
    76bba08fe2b0:	sub    rsp,0x10
    76bba08fe2b4:	mov    r11,QWORD PTR [r12+0x398]
    76bba08fe2bc:	mov    QWORD PTR [rsp],r11
    76bba08fe2c0:	mov    r13,QWORD PTR [r12+0xa0]
    76bba08fe2c8:	mov    r14,r13
    76bba08fe2cb:	shl    r14,0x2
    76bba08fe2cf:	mov    r15,QWORD PTR [r12+0x98]
    76bba08fe2d7:	add    r15,r14
    76bba08fe2da:	mov    r14d,DWORD PTR [r12]
    76bba08fe2de:	mov    DWORD PTR [r15],r14d
    76bba08fe2e1:	mov    r14d,0x0
    76bba08fe2e7:	mov    DWORD PTR [r12+0x32c],r14d
    76bba08fe2ef:	add    r13,0x1
    76bba08fe2f3:	mov    QWORD PTR [r12+0xa0],r13
    76bba08fe2fb:	sub    r13,0x400
    76bba08fe302:	mov    rcx,QWORD PTR [r12+0x380]
    76bba08fe30a:	jrcxz  0x76bba08fe311
    76bba08fe30c:	jmp    0x76bba08fe6f5
    76bba08fe311:	jne    0x76bba08fe32a
    76bba08fe317:	mov    r11,rax
    76bba08fe31a:	lahf
    76bba08fe31b:	seto   al
    76bba08fe31e:	mov    WORD PTR [rsp],ax
    76bba08fe322:	mov    rax,r11
    76bba08fe325:	jmp    0x76bba08fe33d
    76bba08fe32a:	mov    r11,rax
    76bba08fe32d:	lahf
    76bba08fe32e:	seto   al
    76bba08fe331:	mov    WORD PTR [rsp],ax
    76bba08fe335:	mov    rax,r11
    76bba08fe338:	jmp    0x76bba08fe683
    76bba08fe33d:	mov    r13d,0x1
    76bba08fe343:	mov    QWORD PTR [r12+0x40],r13
    76bba08fe348:	mov    r11,rax
    76bba08fe34b:	movzx  eax,WORD PTR [rsp]
    76bba08fe34f:	add    al,0x7f
    76bba08fe351:	sahf
    76bba08fe352:	mov    rax,r11
    76bba08fe355:	jmp    0x76bba08fe35a
    76bba08fe35a:	mov    r13,QWORD PTR [r12+0x40]
    76bba08fe35f:	mov    r14,r13
    76bba08fe362:	lea    r14,[r14*4+0x0]
    76bba08fe36a:	mov    r15,QWORD PTR [r12+0x98]
    76bba08fe372:	mov    r11,rax
    76bba08fe375:	lahf
    76bba08fe376:	seto   al
    76bba08fe379:	mov    WORD PTR [rsp],ax
    76bba08fe37d:	mov    rax,r11
    76bba08fe380:	add    r15,r14
    76bba08fe383:	mov    r14d,DWORD PTR [r15]
    76bba08fe386:	mov    QWORD PTR [r12+0x48],r14
    76bba08fe38b:	mov    r14d,0x0
    76bba08fe391:	or     r14,r13
    76bba08fe394:	mov    QWORD PTR [r12+0x50],r14
    76bba08fe399:	jmp    0x76bba08fe39e
    76bba08fe39e:	mov    r13d,DWORD PTR [r12+0x50]
    76bba08fe3a3:	sub    r13d,0x1
    76bba08fe3a7:	mov    QWORD PTR [r12+0x58],r13
    76bba08fe3ac:	mov    ecx,0xffffffff
    76bba08fe3b1:	mov    r14,r13
    76bba08fe3b4:	and    r14,rcx
    76bba08fe3b7:	shl    r14,0x2
    76bba08fe3bb:	mov    r13,QWORD PTR [r12+0x98]
    76bba08fe3c3:	add    r13,r14
    76bba08fe3c6:	mov    r14d,DWORD PTR [r13+0x0]
    76bba08fe3ca:	mov    QWORD PTR [r12+0x60],r14
    76bba08fe3cf:	mov    r13d,DWORD PTR [r12+0x48]
    76bba08fe3d4:	sub    r14d,r13d
    76bba08fe3d7:	mov    rcx,QWORD PTR [r12+0x380]
    76bba08fe3df:	jrcxz  0x76bba08fe3e6
    76bba08fe3e1:	jmp    0x76bba08fe786
    76bba08fe3e6:	jbe    0x76bba08fe3ff
    76bba08fe3ec:	mov    r11,rax
    76bba08fe3ef:	lahf
    76bba08fe3f0:	seto   al
    76bba08fe3f3:	mov    WORD PTR [rsp],ax
    76bba08fe3f7:	mov    rax,r11
    76bba08fe3fa:	jmp    0x76bba08fe412
    76bba08fe3ff:	mov    r11,rax
    76bba08fe402:	lahf
    76bba08fe403:	seto   al
    76bba08fe406:	mov    WORD PTR [rsp],ax
    76bba08fe40a:	mov    rax,r11
    76bba08fe40d:	jmp    0x76bba08fe491
    76bba08fe412:	mov    r13,QWORD PTR [r12+0x50]
    76bba08fe417:	mov    r14,r13
    76bba08fe41a:	shl    r14,0x2
    76bba08fe41e:	mov    r15,QWORD PTR [r12+0x98]
    76bba08fe426:	add    r15,r14
    76bba08fe429:	mov    r14d,DWORD PTR [r12+0x60]
    76bba08fe42e:	mov    DWORD PTR [r15],r14d
    76bba08fe431:	mov    r14d,0x0
    76bba08fe437:	mov    DWORD PTR [r12+0x32c],r14d
    76bba08fe43f:	sub    r13,0x1
    76bba08fe443:	mov    QWORD PTR [r12+0x50],r13
    76bba08fe448:	mov    rcx,QWORD PTR [r12+0x380]
    76bba08fe450:	jrcxz  0x76bba08fe457
    76bba08fe452:	jmp    0x76bba08fe817
    76bba08fe457:	mov    r13,QWORD PTR [r12+0x58]
    76bba08fe45c:	mov    rax,r13
    76bba08fe45f:	test   rax,rax
    76bba08fe462:	jne    0x76bba08fe39e
    76bba08fe468:	jmp    0x76bba08fe46d
    76bba08fe46d:	mov    rcx,QWORD PTR [r12+0x380]
    76bba08fe475:	jrcxz  0x76bba08fe47c
    76bba08fe477:	jmp    0x76bba08fe899
    76bba08fe47c:	jmp    0x76bba08fe481
    76bba08fe481:	mov    r13d,0x0
    76bba08fe487:	mov    QWORD PTR [r12+0x50],r13
    76bba08fe48c:	jmp    0x76bba08fe491
    76bba08fe491:	mov    r13,QWORD PTR [r12+0x40]
    76bba08fe496:	add    r13,0x1
    76bba08fe49a:	mov    QWORD PTR [r12+0x40],r13
    76bba08fe49f:	mov    r14,QWORD PTR [r12+0x50]
    76bba08fe4a4:	mov    ecx,0xffffffff
    76bba08fe4a9:	and    r14,rcx
    76bba08fe4ac:	shl    r14,0x2
    76bba08fe4b0:	mov    r15,QWORD PTR [r12+0x98]
    76bba08fe4b8:	add    r15,r14
    76bba08fe4bb:	mov    r14d,DWORD PTR [r12+0x48]
    76bba08fe4c0:	mov    DWORD PTR [r15],r14d
    76bba08fe4c3:	mov    r14d,0x0
    76bba08fe4c9:	mov    DWORD PTR [r12+0x32c],r14d
    76bba08fe4d1:	sub    r13,0x400
    76bba08fe4d8:	jne    0x76bba08fe35a
    76bba08fe4de:	mov    r11,rax
    76bba08fe4e1:	lahf
    76bba08fe4e2:	seto   al
    76bba08fe4e5:	mov    WORD PTR [rsp],ax
    76bba08fe4e9:	mov    rax,r11
    76bba08fe4ec:	jmp    0x76bba08fe4f1
    76bba08fe4f1:	mov    r13d,0x420000
    76bba08fe4f7:	mov    QWORD PTR [r12+0x40],r13
    76bba08fe4fc:	mov    r13d,0x0
    76bba08fe502:	mov    QWORD PTR [r12+0x58],r13
    76bba08fe507:	mov    r13d,0x0
    76bba08fe50d:	mov    QWORD PTR [r12+0x50],r13
    76bba08fe512:	mov    r13d,0x420288
    76bba08fe518:	mov    r14,QWORD PTR [r13+0x0]
    76bba08fe51c:	mov    QWORD PTR [r12+0x48],r14
    76bba08fe521:	jmp    0x76bba08fe526
    76bba08fe526:	mov    r13,QWORD PTR [r12+0x58]
    76bba08fe52b:	mov    r14,r13
    76bba08fe52e:	shl    r14,0x2
    76bba08fe532:	mov    r15,QWORD PTR [r12+0x98]
    76bba08fe53a:	add    r15,r14
    76bba08fe53d:	mov    QWORD PTR [r12+0x60],r15
    76bba08fe542:	mov    r14,r15
    76bba08fe545:	add    r14,0x4
    76bba08fe549:	mov    ebp,DWORD PTR [r15]
    76bba08fe54c:	mov    r15d,DWORD PTR [r14]
    76bba08fe54f:	mov    QWORD PTR [r12+0x60],r15
    76bba08fe554:	mov    r14,rbp
    76bba08fe557:	imul   r14,r13
    76bba08fe55b:	mov    r8,rbp
    76bba08fe55e:	add    r8,r14
    76bba08fe561:	mov    QWORD PTR [r12+0x68],r8
    76bba08fe566:	add    r13,0x2
    76bba08fe56a:	mov    QWORD PTR [r12+0x58],r13
    76bba08fe56f:	mov    r14,r13
    76bba08fe572:	sub    r14,0x400
    76bba08fe579:	mov    r14,QWORD PTR [r12+0x50]
    76bba08fe57e:	setne  BYTE PTR [rsp+0x8]
    76bba08fe583:	mov    r11,rax
    76bba08fe586:	lahf
    76bba08fe587:	seto   al
    76bba08fe58a:	mov    WORD PTR [rsp],ax
    76bba08fe58e:	mov    rax,r11
    76bba08fe591:	imul   r13,r15
    76bba08fe595:	add    r14,r13
    76bba08fe598:	mov    QWORD PTR [r12+0x50],r14
    76bba08fe59d:	mov    r13,QWORD PTR [r12+0x48]
    76bba08fe5a2:	add    r8,r13
    76bba08fe5a5:	mov    QWORD PTR [r12+0x48],r8
    76bba08fe5aa:	mov    rcx,QWORD PTR [r12+0x380]
    76bba08fe5b2:	jrcxz  0x76bba08fe5b9
    76bba08fe5b4:	jmp    0x76bba08fe91b
    76bba08fe5b9:	cmp    BYTE PTR [rsp+0x8],0x0
    76bba08fe5be:	jne    0x76bba08fe526
    76bba08fe5c4:	jmp    0x76bba08fe5c9
    76bba08fe5c9:	mov    r13,QWORD PTR [r12+0xf8]
    76bba08fe5d1:	mov    r14,r13
    76bba08fe5d4:	add    r14,0x10
    76bba08fe5d8:	mov    r15,r14
    76bba08fe5db:	add    r15,0x8
    76bba08fe5df:	mov    rbp,QWORD PTR [r14]
    76bba08fe5e2:	mov    r14,QWORD PTR [r15]
    76bba08fe5e5:	mov    QWORD PTR [r12+0xa0],rbp
    76bba08fe5ed:	mov    QWORD PTR [r12+0x98],r14
    76bba08fe5f5:	mov    r14,QWORD PTR [r12+0x48]
    76bba08fe5fa:	mov    r15,QWORD PTR [r12+0x50]
    76bba08fe5ff:	add    r15,r14
    76bba08fe602:	mov    QWORD PTR [r12+0x48],r15
    76bba08fe607:	mov    r14,QWORD PTR [r12+0x40]
    76bba08fe60c:	add    r14,0x288
    76bba08fe613:	mov    QWORD PTR [r14],r15
    76bba08fe616:	mov    r14d,0x0
    76bba08fe61c:	mov    DWORD PTR [r12+0x32c],r14d
    76bba08fe624:	mov    r14,r13
    76bba08fe627:	add    r14,0x20
    76bba08fe62b:	mov    r15,QWORD PTR [r13+0x0]
    76bba08fe62f:	mov    QWORD PTR [r12+0xf0],r15
    76bba08fe637:	mov    QWORD PTR [r12+0xf8],r14
    76bba08fe63f:	mov    rcx,QWORD PTR [r12+0x380]
    76bba08fe647:	jrcxz  0x76bba08fe64e
    76bba08fe649:	jmp    0x76bba08fe99d
    76bba08fe64e:	mov    r13,QWORD PTR [r12+0xf0]
    76bba08fe656:	mov    QWORD PTR [r12+0x100],r13
    76bba08fe65e:	mov    r11,QWORD PTR [rsp]
    76bba08fe662:	mov    QWORD PTR [r12+0x398],r11
    76bba08fe66a:	mov    rdi,QWORD PTR [r12+0x100]
    76bba08fe672:	add    rsp,0x10
    76bba08fe676:	movabs r11,0x590cad6b0940
    76bba08fe680:	jmp    r11
    76bba08fe683:	mov    r13d,DWORD PTR [r12+0xa0]
    76bba08fe68b:	add    r13d,0x11
    76bba08fe68f:	mov    QWORD PTR [r12],r13
    76bba08fe693:	mov    r13d,0x410184
    76bba08fe699:	mov    QWORD PTR [r12+0xf0],r13
    76bba08fe6a1:	mov    r13d,0x41021c
    76bba08fe6a7:	mov    QWORD PTR [r12+0x100],r13
    76bba08fe6af:	mov    r11,QWORD PTR [rsp]
    76bba08fe6b3:	mov    QWORD PTR [r12+0x398],r11
    76bba08fe6bb:	mov    edi,0x41021c
    76bba08fe6c0:	mov    QWORD PTR [r12+0x100],rdi
    76bba08fe6c8:	add    rsp,0x10
    76bba08fe6cc:	nop    DWORD PTR [rax+0x0]
    76bba08fe6d0:	jmp    QWORD PTR [rip+0x2]        # 0x76bba08fe6d8
    76bba08fe6d6:	xchg   ax,ax
    76bba08fe6d8:	lock loopne 0x76bba08fe66a
    76bba08fe6db:	movabs al,ds:0xa08fe6e8000076bb
    76bba08fe6e4:	mov    ebx,0x49000076
    76bba08fe6e9:	mov    ebx,0xad6b0940
    76bba08fe6ee:	or     al,0x59
    76bba08fe6f0:	add    BYTE PTR [rax],al
    76bba08fe6f2:	jmp    r11
    76bba08fe6f5:	mov    eax,0x410190
    76bba08fe6fa:	mov    QWORD PTR [r12+0x100],rax
    76bba08fe702:	push   rdx
    76bba08fe703:	push   rsi
    76bba08fe704:	push   r10
    76bba08fe706:	push   r11
    76bba08fe708:	mov    r11,rax
    76bba08fe70b:	lahf
    76bba08fe70c:	seto   al
    76bba08fe70f:	mov    WORD PTR [rsp+0x20],ax
    76bba08fe714:	mov    rax,r11
    76bba08fe717:	mov    rdx,QWORD PTR [rsp+0x20]
    76bba08fe71c:	mov    r10d,edx
    76bba08fe71f:	and    r10d,0xc000
    76bba08fe726:	shl    r10d,0x10
    76bba08fe72a:	mov    r11d,edx
    76bba08fe72d:	and    r11d,0x100
    76bba08fe734:	shl    r11d,0x15
    76bba08fe738:	or     r10d,r11d
    76bba08fe73b:	and    edx,0x1
    76bba08fe73e:	shl    edx,0x1c
    76bba08fe741:	or     r10d,edx
    76bba08fe744:	btc    r10,0x1d
    76bba08fe749:	mov    r11d,0xf0000000
    76bba08fe74f:	and    r11,r10
    76bba08fe752:	movabs rsi,0xffffffff0fffffff
    76bba08fe75c:	and    rbx,rsi
    76bba08fe75f:	or     rbx,r11
    76bba08fe762:	pop    r11
    76bba08fe764:	pop    r10
    76bba08fe766:	pop    rsi
    76bba08fe767:	pop    rdx
    76bba08fe768:	mov    QWORD PTR [r12+0x108],rbx
    76bba08fe770:	add    rsp,0x10
    76bba08fe774:	mov    eax,0xc
    76bba08fe779:	movabs r11,0x590cad6b0ca0
    76bba08fe783:	jmp    r11
    76bba08fe786:	mov    eax,0x4101c4
    76bba08fe78b:	mov    QWORD PTR [r12+0x100],rax
    76bba08fe793:	push   rdx
    76bba08fe794:	push   rsi
    76bba08fe795:	push   r10
    76bba08fe797:	push   r11
    76bba08fe799:	mov    r11,rax
    76bba08fe79c:	lahf
    76bba08fe79d:	seto   al
    76bba08fe7a0:	mov    WORD PTR [rsp+0x20],ax
    76bba08fe7a5:	mov    rax,r11
    76bba08fe7a8:	mov    rdx,QWORD PTR [rsp+0x20]
    76bba08fe7ad:	mov    r10d,edx
    76bba08fe7b0:	and    r10d,0xc000
    76bba08fe7b7:	shl    r10d,0x10
    76bba08fe7bb:	mov    r11d,edx
    76bba08fe7be:	and    r11d,0x100
    76bba08fe7c5:	shl    r11d,0x15
    76bba08fe7c9:	or     r10d,r11d
    76bba08fe7cc:	and    edx,0x1
    76bba08fe7cf:	shl    edx,0x1c
    76bba08fe7d2:	or     r10d,edx
    76bba08fe7d5:	btc    r10,0x1d
    76bba08fe7da:	mov    r11d,0xf0000000
    76bba08fe7e0:	and    r11,r10
    76bba08fe7e3:	movabs rsi,0xffffffff0fffffff
    76bba08fe7ed:	and    rbx,rsi
    76bba08fe7f0:	or     rbx,r11
    76bba08fe7f3:	pop    r11
    76bba08fe7f5:	pop    r10
    76bba08fe7f7:	pop    rsi
    76bba08fe7f8:	pop    rdx
    76bba08fe7f9:	mov    QWORD PTR [r12+0x108],rbx
    76bba08fe801:	add    rsp,0x10
    76bba08fe805:	mov    eax,0xc
    76bba08fe80a:	movabs r11,0x590cad6b0ca0
    76bba08fe814:	jmp    r11
    76bba08fe817:	mov    eax,0x4101d0
    76bba08fe81c:	mov    QWORD PTR [r12+0x100],rax
    76bba08fe824:	push   rdx
    76bba08fe825:	push   rsi
    76bba08fe826:	push   r10
    76bba08fe828:	push   r11
    76bba08fe82a:	mov    rdx,QWORD PTR [rsp+0x20]
    76bba08fe82f:	mov    r10d,edx
    76bba08fe832:	and    r10d,0xc000
    76bba08fe839:	shl    r10d,0x10
    76bba08fe83d:	mov    r11d,edx
    76bba08fe840:	and    r11d,0x100
    76bba08fe847:	shl    r11d,0x15
    76bba08fe84b:	or     r10d,r11d
    76bba08fe84e:	and    edx,0x1
    76bba08fe851:	shl    edx,0x1c
    76bba08fe854:	or     r10d,edx
    76bba08fe857:	btc    r10,0x1d
    76bba08fe85c:	mov    r11d,0xf0000000
    76bba08fe862:	and    r11,r10
    76bba08fe865:	movabs rsi,0xffffffff0fffffff
    76bba08fe86f:	and    rbx,rsi
    76bba08fe872:	or     rbx,r11
    76bba08fe875:	pop    r11
    76bba08fe877:	pop    r10
    76bba08fe879:	pop    rsi
    76bba08fe87a:	pop    rdx
    76bba08fe87b:	mov    QWORD PTR [r12+0x108],rbx
    76bba08fe883:	add    rsp,0x10
    76bba08fe887:	mov    eax,0xc
    76bba08fe88c:	movabs r11,0x590cad6b0ca0
    76bba08fe896:	jmp    r11
    76bba08fe899:	mov    eax,0x4101d4
    76bba08fe89e:	mov    QWORD PTR [r12+0x100],rax
    76bba08fe8a6:	push   rdx
    76bba08fe8a7:	push   rsi
    76bba08fe8a8:	push   r10
    76bba08fe8aa:	push   r11
    76bba08fe8ac:	mov    rdx,QWORD PTR [rsp+0x20]
    76bba08fe8b1:	mov    r10d,edx
    76bba08fe8b4:	and    r10d,0xc000
    76bba08fe8bb:	shl    r10d,0x10
    76bba08fe8bf:	mov    r11d,edx
    76bba08fe8c2:	and    r11d,0x100
    76bba08fe8c9:	shl    r11d,0x15
    76bba08fe8cd:	or     r10d,r11d
    76bba08fe8d0:	and    edx,0x1
    76bba08fe8d3:	shl    edx,0x1c
    76bba08fe8d6:	or     r10d,edx
    76bba08fe8d9:	btc    r10,0x1d
    76bba08fe8de:	mov    r11d,0xf0000000
    76bba08fe8e4:	and    r11,r10
    76bba08fe8e7:	movabs rsi,0xffffffff0fffffff
    76bba08fe8f1:	and    rbx,rsi
    76bba08fe8f4:	or     rbx,r11
    76bba08fe8f7:	pop    r11
    76bba08fe8f9:	pop    r10
    76bba08fe8fb:	pop    rsi
    76bba08fe8fc:	pop    rdx
    76bba08fe8fd:	mov    QWORD PTR [r12+0x108],rbx
    76bba08fe905:	add    rsp,0x10
    76bba08fe909:	mov    eax,0xc
    76bba08fe90e:	movabs r11,0x590cad6b0ca0
    76bba08fe918:	jmp    r11
    76bba08fe91b:	mov    eax,0x410204
    76bba08fe920:	mov    QWORD PTR [r12+0x100],rax
    76bba08fe928:	push   rdx
    76bba08fe929:	push   rsi
    76bba08fe92a:	push   r10
    76bba08fe92c:	push   r11
    76bba08fe92e:	mov    rdx,QWORD PTR [rsp+0x20]
    76bba08fe933:	mov    r10d,edx
    76bba08fe936:	and    r10d,0xc000
    76bba08fe93d:	shl    r10d,0x10
    76bba08fe941:	mov    r11d,edx
    76bba08fe944:	and    r11d,0x100
    76bba08fe94b:	shl    r11d,0x15
    76bba08fe94f:	or     r10d,r11d
    76bba08fe952:	and    edx,0x1
    76bba08fe955:	shl    edx,0x1c
    76bba08fe958:	or     r10d,edx
    76bba08fe95b:	btc    r10,0x1d
    76bba08fe960:	mov    r11d,0xf0000000
    76bba08fe966:	and    r11,r10
    76bba08fe969:	movabs rsi,0xffffffff0fffffff
    76bba08fe973:	and    rbx,rsi
    76bba08fe976:	or     rbx,r11
    76bba08fe979:	pop    r11
    76bba08fe97b:	pop    r10
    76bba08fe97d:	pop    rsi
    76bba08fe97e:	pop    rdx
    76bba08fe97f:	mov    QWORD PTR [r12+0x108],rbx
    76bba08fe987:	add    rsp,0x10
    76bba08fe98b:	mov    eax,0xc
    76bba08fe990:	movabs r11,0x590cad6b0ca0
    76bba08fe99a:	jmp    r11
    76bba08fe99d:	mov    eax,0x410218
    76bba08fe9a2:	mov    QWORD PTR [r12+0x100],rax
    76bba08fe9aa:	push   rdx
    76bba08fe9ab:	push   rsi
    76bba08fe9ac:	push   r10
    76bba08fe9ae:	push   r11
    76bba08fe9b0:	mov    rdx,QWORD PTR [rsp+0x20]
    76bba08fe9b5:	mov    r10d,edx
    76bba08fe9b8:	and    r10d,0xc000
    76bba08fe9bf:	shl    r10d,0x10
    76bba08fe9c3:	mov    r11d,edx
    76bba08fe9c6:	and    r11d,0x100
    76bba08fe9cd:	shl    r11d,0x15
    76bba08fe9d1:	or     r10d,r11d
    76bba08fe9d4:	and    edx,0x1
    76bba08fe9d7:	shl    edx,0x1c
    76bba08fe9da:	or     r10d,edx
    76bba08fe9dd:	btc    r10,0x1d
    76bba08fe9e2:	mov    r11d,0xf0000000
    76bba08fe9e8:	and    r11,r10
    76bba08fe9eb:	movabs rsi,0xffffffff0fffffff
    76bba08fe9f5:	and    rbx,rsi
    76bba08fe9f8:	or     rbx,r11
    76bba08fe9fb:	pop    r11
    76bba08fe9fd:	pop    r10
    76bba08fe9ff:	pop    rsi
    76bba08fea00:	pop    rdx
    76bba08fea01:	mov    QWORD PTR [r12+0x108],rbx
    76bba08fea09:	add    rsp,0x10
    76bba08fea0d:	mov    eax,0xc
    76bba08fea12:	movabs r11,0x590cad6b0ca0
    76bba08fea1c:	jmp    r11
    76bba08fea1f:	nop
    76bba08fea20:	sub    rsp,0x10
    76bba08fea24:	mov    r11,QWORD PTR [r12+0x398]
    76bba08fea2c:	mov    QWORD PTR [rsp],r11
    76bba08fea30:	jmp    0x76bba08fe33d
    76bba08fea35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    76bba08fea40:	sub    rsp,0x10
    76bba08fea44:	mov    r11,QWORD PTR [r12+0x398]
    76bba08fea4c:	mov    QWORD PTR [rsp],r11
    76bba08fea50:	mov    r11,rax
    76bba08fea53:	movzx  eax,WORD PTR [rsp]
    76bba08fea57:	add    al,0x7f
    76bba08fea59:	sahf
    76bba08fea5a:	mov    rax,r11
    76bba08fea5d:	jmp    0x76bba08fe35a
    76bba08fea62:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    76bba08fea70:	sub    rsp,0x10
    76bba08fea74:	mov    r11,QWORD PTR [r12+0x398]
    76bba08fea7c:	mov    QWORD PTR [rsp],r11
    76bba08fea80:	jmp    0x76bba08fe39e
    76bba08fea85:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    76bba08fea90:	sub    rsp,0x10
    76bba08fea94:	mov    r11,QWORD PTR [r12+0x398]
    76bba08fea9c:	mov    QWORD PTR [rsp],r11
    76bba08feaa0:	jmp    0x76bba08fe412
    76bba08feaa5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    76bba08feab0:	sub    rsp,0x10
    76bba08feab4:	mov    r11,QWORD PTR [r12+0x398]
    76bba08feabc:	mov    QWORD PTR [rsp],r11
    76bba08feac0:	jmp    0x76bba08fe46d
    76bba08feac5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    76bba08fead0:	sub    rsp,0x10
    76bba08fead4:	mov    r11,QWORD PTR [r12+0x398]
    76bba08feadc:	mov    QWORD PTR [rsp],r11
    76bba08feae0:	jmp    0x76bba08fe481
    76bba08feae5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    76bba08feaf0:	sub    rsp,0x10
    76bba08feaf4:	mov    r11,QWORD PTR [r12+0x398]
    76bba08feafc:	mov    QWORD PTR [rsp],r11
    76bba08feb00:	jmp    0x76bba08fe491
    76bba08feb05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    76bba08feb10:	sub    rsp,0x10
    76bba08feb14:	mov    r11,QWORD PTR [r12+0x398]
    76bba08feb1c:	mov    QWORD PTR [rsp],r11
    76bba08feb20:	jmp    0x76bba08fe4f1
    76bba08feb25:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    76bba08feb30:	sub    rsp,0x10
    76bba08feb34:	mov    r11,QWORD PTR [r12+0x398]
    76bba08feb3c:	mov    QWORD PTR [rsp],r11
    76bba08feb40:	jmp    0x76bba08fe526
    76bba08feb45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    76bba08feb50:	sub    rsp,0x10
    76bba08feb54:	mov    r11,QWORD PTR [r12+0x398]
    76bba08feb5c:	mov    QWORD PTR [rsp],r11
    76bba08feb60:	jmp    0x76bba08fe5c9
    76bba08feb65:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    76bba08feb70:	sub    rsp,0x10
    76bba08feb74:	mov    r11,QWORD PTR [r12+0x398]
    76bba08feb7c:	mov    QWORD PTR [rsp],r11
    76bba08feb80:	jmp    0x76bba08fe683
    76bba08feb85:	nop
    76bba08feb86:	nop
    76bba08feb87:	nop
