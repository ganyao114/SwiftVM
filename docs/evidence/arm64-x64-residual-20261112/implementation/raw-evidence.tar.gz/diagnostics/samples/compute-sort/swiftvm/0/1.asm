
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sort/swiftvm/0/1.bin:     file format binary


Disassembly of section .data:

00007c458b4fe0f0 <.data>:
    7c458b4fe0f0:	sub    rsp,0x10
    7c458b4fe0f4:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4fe0fc:	mov    QWORD PTR [rsp],r11
    7c458b4fe100:	mov    r13d,0x352d
    7c458b4fe106:	mov    QWORD PTR [r12+0x40],r13
    7c458b4fe10b:	mov    r13d,0xa68b
    7c458b4fe111:	mov    QWORD PTR [r12+0x48],r13
    7c458b4fe116:	mov    r13d,0x352d
    7c458b4fe11c:	mov    r14d,0x7feb
    7c458b4fe122:	and    r14d,0xffff
    7c458b4fe129:	mov    rax,r13
    7c458b4fe12c:	movabs rcx,0xffffffff0000ffff
    7c458b4fe136:	and    rax,rcx
    7c458b4fe139:	mov    rdx,r14
    7c458b4fe13c:	shl    rdx,0x10
    7c458b4fe140:	mov    ecx,0xffff0000
    7c458b4fe145:	and    rdx,rcx
    7c458b4fe148:	or     rax,rdx
    7c458b4fe14b:	mov    r15d,eax
    7c458b4fe14e:	mov    QWORD PTR [r12+0x40],r15
    7c458b4fe153:	mov    r13d,0xa68b
    7c458b4fe159:	mov    r14d,0x846c
    7c458b4fe15f:	and    r14d,0xffff
    7c458b4fe166:	mov    rax,r13
    7c458b4fe169:	movabs rcx,0xffffffff0000ffff
    7c458b4fe173:	and    rax,rcx
    7c458b4fe176:	mov    rdx,r14
    7c458b4fe179:	shl    rdx,0x10
    7c458b4fe17d:	mov    ecx,0xffff0000
    7c458b4fe182:	and    rdx,rcx
    7c458b4fe185:	or     rax,rdx
    7c458b4fe188:	mov    ebp,eax
    7c458b4fe18a:	mov    QWORD PTR [r12+0x48],rbp
    7c458b4fe18f:	mov    r13d,DWORD PTR [r12]
    7c458b4fe193:	mov    r14d,0x0
    7c458b4fe199:	imul   r13d,r15d
    7c458b4fe19d:	mov    r15d,r14d
    7c458b4fe1a0:	add    r15d,r13d
    7c458b4fe1a3:	mov    QWORD PTR [r12+0x40],r15
    7c458b4fe1a8:	mov    r13d,r15d
    7c458b4fe1ab:	mov    r13d,r13d
    7c458b4fe1ae:	shr    r13d,0xf
    7c458b4fe1b2:	xor    r15d,r13d
    7c458b4fe1b5:	mov    QWORD PTR [r12+0x40],r15
    7c458b4fe1ba:	mov    r13d,0x0
    7c458b4fe1c0:	imul   r15d,ebp
    7c458b4fe1c4:	mov    r14d,r13d
    7c458b4fe1c7:	add    r14d,r15d
    7c458b4fe1ca:	mov    QWORD PTR [r12+0x40],r14
    7c458b4fe1cf:	mov    r13d,r14d
    7c458b4fe1d2:	mov    r13d,r13d
    7c458b4fe1d5:	shr    r13d,0x10
    7c458b4fe1d9:	xor    r14d,r13d
    7c458b4fe1dc:	mov    QWORD PTR [r12],r14
    7c458b4fe1e0:	mov    rcx,QWORD PTR [r12+0x380]
    7c458b4fe1e8:	jrcxz  0x7c458b4fe1ef
    7c458b4fe1ea:	jmp    0x7c458b4fe224
    7c458b4fe1ef:	mov    r13,QWORD PTR [r12+0xf0]
    7c458b4fe1f7:	mov    QWORD PTR [r12+0x100],r13
    7c458b4fe1ff:	mov    r11,QWORD PTR [rsp]
    7c458b4fe203:	mov    QWORD PTR [r12+0x398],r11
    7c458b4fe20b:	mov    rdi,QWORD PTR [r12+0x100]
    7c458b4fe213:	add    rsp,0x10
    7c458b4fe217:	movabs r11,0x5c8c5e619940
    7c458b4fe221:	jmp    r11
    7c458b4fe224:	mov    eax,0x41023c
    7c458b4fe229:	mov    QWORD PTR [r12+0x100],rax
    7c458b4fe231:	push   rdx
    7c458b4fe232:	push   rsi
    7c458b4fe233:	push   r10
    7c458b4fe235:	push   r11
    7c458b4fe237:	mov    rdx,QWORD PTR [rsp+0x20]
    7c458b4fe23c:	mov    r10d,edx
    7c458b4fe23f:	and    r10d,0xc000
    7c458b4fe246:	shl    r10d,0x10
    7c458b4fe24a:	mov    r11d,edx
    7c458b4fe24d:	and    r11d,0x100
    7c458b4fe254:	shl    r11d,0x15
    7c458b4fe258:	or     r10d,r11d
    7c458b4fe25b:	and    edx,0x1
    7c458b4fe25e:	shl    edx,0x1c
    7c458b4fe261:	or     r10d,edx
    7c458b4fe264:	btc    r10,0x1d
    7c458b4fe269:	mov    r11d,0xf0000000
    7c458b4fe26f:	and    r11,r10
    7c458b4fe272:	movabs rsi,0xffffffff0fffffff
    7c458b4fe27c:	and    rbx,rsi
    7c458b4fe27f:	or     rbx,r11
    7c458b4fe282:	pop    r11
    7c458b4fe284:	pop    r10
    7c458b4fe286:	pop    rsi
    7c458b4fe287:	pop    rdx
    7c458b4fe288:	mov    QWORD PTR [r12+0x108],rbx
    7c458b4fe290:	add    rsp,0x10
    7c458b4fe294:	mov    eax,0xc
    7c458b4fe299:	movabs r11,0x5c8c5e619ca0
    7c458b4fe2a3:	jmp    r11
    7c458b4fe2a6:	nop
    7c458b4fe2a7:	nop
