
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sort/swiftvm/2/2.bin:     file format binary


Disassembly of section .data:

00007ba63c6fe2b0 <.data>:
    7ba63c6fe2b0:	sub    rsp,0x10
    7ba63c6fe2b4:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6fe2bc:	mov    QWORD PTR [rsp],r11
    7ba63c6fe2c0:	mov    r13,QWORD PTR [r12+0xa0]
    7ba63c6fe2c8:	mov    r14,r13
    7ba63c6fe2cb:	shl    r14,0x2
    7ba63c6fe2cf:	mov    r15,QWORD PTR [r12+0x98]
    7ba63c6fe2d7:	add    r15,r14
    7ba63c6fe2da:	mov    r14d,DWORD PTR [r12]
    7ba63c6fe2de:	mov    DWORD PTR [r15],r14d
    7ba63c6fe2e1:	mov    r14d,0x0
    7ba63c6fe2e7:	mov    DWORD PTR [r12+0x32c],r14d
    7ba63c6fe2ef:	add    r13,0x1
    7ba63c6fe2f3:	mov    QWORD PTR [r12+0xa0],r13
    7ba63c6fe2fb:	sub    r13,0x400
    7ba63c6fe302:	mov    rcx,QWORD PTR [r12+0x380]
    7ba63c6fe30a:	jrcxz  0x7ba63c6fe311
    7ba63c6fe30c:	jmp    0x7ba63c6fe6f5
    7ba63c6fe311:	jne    0x7ba63c6fe32a
    7ba63c6fe317:	mov    r11,rax
    7ba63c6fe31a:	lahf
    7ba63c6fe31b:	seto   al
    7ba63c6fe31e:	mov    WORD PTR [rsp],ax
    7ba63c6fe322:	mov    rax,r11
    7ba63c6fe325:	jmp    0x7ba63c6fe33d
    7ba63c6fe32a:	mov    r11,rax
    7ba63c6fe32d:	lahf
    7ba63c6fe32e:	seto   al
    7ba63c6fe331:	mov    WORD PTR [rsp],ax
    7ba63c6fe335:	mov    rax,r11
    7ba63c6fe338:	jmp    0x7ba63c6fe683
    7ba63c6fe33d:	mov    r13d,0x1
    7ba63c6fe343:	mov    QWORD PTR [r12+0x40],r13
    7ba63c6fe348:	mov    r11,rax
    7ba63c6fe34b:	movzx  eax,WORD PTR [rsp]
    7ba63c6fe34f:	add    al,0x7f
    7ba63c6fe351:	sahf
    7ba63c6fe352:	mov    rax,r11
    7ba63c6fe355:	jmp    0x7ba63c6fe35a
    7ba63c6fe35a:	mov    r13,QWORD PTR [r12+0x40]
    7ba63c6fe35f:	mov    r14,r13
    7ba63c6fe362:	lea    r14,[r14*4+0x0]
    7ba63c6fe36a:	mov    r15,QWORD PTR [r12+0x98]
    7ba63c6fe372:	mov    r11,rax
    7ba63c6fe375:	lahf
    7ba63c6fe376:	seto   al
    7ba63c6fe379:	mov    WORD PTR [rsp],ax
    7ba63c6fe37d:	mov    rax,r11
    7ba63c6fe380:	add    r15,r14
    7ba63c6fe383:	mov    r14d,DWORD PTR [r15]
    7ba63c6fe386:	mov    QWORD PTR [r12+0x48],r14
    7ba63c6fe38b:	mov    r14d,0x0
    7ba63c6fe391:	or     r14,r13
    7ba63c6fe394:	mov    QWORD PTR [r12+0x50],r14
    7ba63c6fe399:	jmp    0x7ba63c6fe39e
    7ba63c6fe39e:	mov    r13d,DWORD PTR [r12+0x50]
    7ba63c6fe3a3:	sub    r13d,0x1
    7ba63c6fe3a7:	mov    QWORD PTR [r12+0x58],r13
    7ba63c6fe3ac:	mov    ecx,0xffffffff
    7ba63c6fe3b1:	mov    r14,r13
    7ba63c6fe3b4:	and    r14,rcx
    7ba63c6fe3b7:	shl    r14,0x2
    7ba63c6fe3bb:	mov    r13,QWORD PTR [r12+0x98]
    7ba63c6fe3c3:	add    r13,r14
    7ba63c6fe3c6:	mov    r14d,DWORD PTR [r13+0x0]
    7ba63c6fe3ca:	mov    QWORD PTR [r12+0x60],r14
    7ba63c6fe3cf:	mov    r13d,DWORD PTR [r12+0x48]
    7ba63c6fe3d4:	sub    r14d,r13d
    7ba63c6fe3d7:	mov    rcx,QWORD PTR [r12+0x380]
    7ba63c6fe3df:	jrcxz  0x7ba63c6fe3e6
    7ba63c6fe3e1:	jmp    0x7ba63c6fe786
    7ba63c6fe3e6:	jbe    0x7ba63c6fe3ff
    7ba63c6fe3ec:	mov    r11,rax
    7ba63c6fe3ef:	lahf
    7ba63c6fe3f0:	seto   al
    7ba63c6fe3f3:	mov    WORD PTR [rsp],ax
    7ba63c6fe3f7:	mov    rax,r11
    7ba63c6fe3fa:	jmp    0x7ba63c6fe412
    7ba63c6fe3ff:	mov    r11,rax
    7ba63c6fe402:	lahf
    7ba63c6fe403:	seto   al
    7ba63c6fe406:	mov    WORD PTR [rsp],ax
    7ba63c6fe40a:	mov    rax,r11
    7ba63c6fe40d:	jmp    0x7ba63c6fe491
    7ba63c6fe412:	mov    r13,QWORD PTR [r12+0x50]
    7ba63c6fe417:	mov    r14,r13
    7ba63c6fe41a:	shl    r14,0x2
    7ba63c6fe41e:	mov    r15,QWORD PTR [r12+0x98]
    7ba63c6fe426:	add    r15,r14
    7ba63c6fe429:	mov    r14d,DWORD PTR [r12+0x60]
    7ba63c6fe42e:	mov    DWORD PTR [r15],r14d
    7ba63c6fe431:	mov    r14d,0x0
    7ba63c6fe437:	mov    DWORD PTR [r12+0x32c],r14d
    7ba63c6fe43f:	sub    r13,0x1
    7ba63c6fe443:	mov    QWORD PTR [r12+0x50],r13
    7ba63c6fe448:	mov    rcx,QWORD PTR [r12+0x380]
    7ba63c6fe450:	jrcxz  0x7ba63c6fe457
    7ba63c6fe452:	jmp    0x7ba63c6fe817
    7ba63c6fe457:	mov    r13,QWORD PTR [r12+0x58]
    7ba63c6fe45c:	mov    rax,r13
    7ba63c6fe45f:	test   rax,rax
    7ba63c6fe462:	jne    0x7ba63c6fe39e
    7ba63c6fe468:	jmp    0x7ba63c6fe46d
    7ba63c6fe46d:	mov    rcx,QWORD PTR [r12+0x380]
    7ba63c6fe475:	jrcxz  0x7ba63c6fe47c
    7ba63c6fe477:	jmp    0x7ba63c6fe899
    7ba63c6fe47c:	jmp    0x7ba63c6fe481
    7ba63c6fe481:	mov    r13d,0x0
    7ba63c6fe487:	mov    QWORD PTR [r12+0x50],r13
    7ba63c6fe48c:	jmp    0x7ba63c6fe491
    7ba63c6fe491:	mov    r13,QWORD PTR [r12+0x40]
    7ba63c6fe496:	add    r13,0x1
    7ba63c6fe49a:	mov    QWORD PTR [r12+0x40],r13
    7ba63c6fe49f:	mov    r14,QWORD PTR [r12+0x50]
    7ba63c6fe4a4:	mov    ecx,0xffffffff
    7ba63c6fe4a9:	and    r14,rcx
    7ba63c6fe4ac:	shl    r14,0x2
    7ba63c6fe4b0:	mov    r15,QWORD PTR [r12+0x98]
    7ba63c6fe4b8:	add    r15,r14
    7ba63c6fe4bb:	mov    r14d,DWORD PTR [r12+0x48]
    7ba63c6fe4c0:	mov    DWORD PTR [r15],r14d
    7ba63c6fe4c3:	mov    r14d,0x0
    7ba63c6fe4c9:	mov    DWORD PTR [r12+0x32c],r14d
    7ba63c6fe4d1:	sub    r13,0x400
    7ba63c6fe4d8:	jne    0x7ba63c6fe35a
    7ba63c6fe4de:	mov    r11,rax
    7ba63c6fe4e1:	lahf
    7ba63c6fe4e2:	seto   al
    7ba63c6fe4e5:	mov    WORD PTR [rsp],ax
    7ba63c6fe4e9:	mov    rax,r11
    7ba63c6fe4ec:	jmp    0x7ba63c6fe4f1
    7ba63c6fe4f1:	mov    r13d,0x420000
    7ba63c6fe4f7:	mov    QWORD PTR [r12+0x40],r13
    7ba63c6fe4fc:	mov    r13d,0x0
    7ba63c6fe502:	mov    QWORD PTR [r12+0x58],r13
    7ba63c6fe507:	mov    r13d,0x0
    7ba63c6fe50d:	mov    QWORD PTR [r12+0x50],r13
    7ba63c6fe512:	mov    r13d,0x420288
    7ba63c6fe518:	mov    r14,QWORD PTR [r13+0x0]
    7ba63c6fe51c:	mov    QWORD PTR [r12+0x48],r14
    7ba63c6fe521:	jmp    0x7ba63c6fe526
    7ba63c6fe526:	mov    r13,QWORD PTR [r12+0x58]
    7ba63c6fe52b:	mov    r14,r13
    7ba63c6fe52e:	shl    r14,0x2
    7ba63c6fe532:	mov    r15,QWORD PTR [r12+0x98]
    7ba63c6fe53a:	add    r15,r14
    7ba63c6fe53d:	mov    QWORD PTR [r12+0x60],r15
    7ba63c6fe542:	mov    r14,r15
    7ba63c6fe545:	add    r14,0x4
    7ba63c6fe549:	mov    ebp,DWORD PTR [r15]
    7ba63c6fe54c:	mov    r15d,DWORD PTR [r14]
    7ba63c6fe54f:	mov    QWORD PTR [r12+0x60],r15
    7ba63c6fe554:	mov    r14,rbp
    7ba63c6fe557:	imul   r14,r13
    7ba63c6fe55b:	mov    r8,rbp
    7ba63c6fe55e:	add    r8,r14
    7ba63c6fe561:	mov    QWORD PTR [r12+0x68],r8
    7ba63c6fe566:	add    r13,0x2
    7ba63c6fe56a:	mov    QWORD PTR [r12+0x58],r13
    7ba63c6fe56f:	mov    r14,r13
    7ba63c6fe572:	sub    r14,0x400
    7ba63c6fe579:	mov    r14,QWORD PTR [r12+0x50]
    7ba63c6fe57e:	setne  BYTE PTR [rsp+0x8]
    7ba63c6fe583:	mov    r11,rax
    7ba63c6fe586:	lahf
    7ba63c6fe587:	seto   al
    7ba63c6fe58a:	mov    WORD PTR [rsp],ax
    7ba63c6fe58e:	mov    rax,r11
    7ba63c6fe591:	imul   r13,r15
    7ba63c6fe595:	add    r14,r13
    7ba63c6fe598:	mov    QWORD PTR [r12+0x50],r14
    7ba63c6fe59d:	mov    r13,QWORD PTR [r12+0x48]
    7ba63c6fe5a2:	add    r8,r13
    7ba63c6fe5a5:	mov    QWORD PTR [r12+0x48],r8
    7ba63c6fe5aa:	mov    rcx,QWORD PTR [r12+0x380]
    7ba63c6fe5b2:	jrcxz  0x7ba63c6fe5b9
    7ba63c6fe5b4:	jmp    0x7ba63c6fe91b
    7ba63c6fe5b9:	cmp    BYTE PTR [rsp+0x8],0x0
    7ba63c6fe5be:	jne    0x7ba63c6fe526
    7ba63c6fe5c4:	jmp    0x7ba63c6fe5c9
    7ba63c6fe5c9:	mov    r13,QWORD PTR [r12+0xf8]
    7ba63c6fe5d1:	mov    r14,r13
    7ba63c6fe5d4:	add    r14,0x10
    7ba63c6fe5d8:	mov    r15,r14
    7ba63c6fe5db:	add    r15,0x8
    7ba63c6fe5df:	mov    rbp,QWORD PTR [r14]
    7ba63c6fe5e2:	mov    r14,QWORD PTR [r15]
    7ba63c6fe5e5:	mov    QWORD PTR [r12+0xa0],rbp
    7ba63c6fe5ed:	mov    QWORD PTR [r12+0x98],r14
    7ba63c6fe5f5:	mov    r14,QWORD PTR [r12+0x48]
    7ba63c6fe5fa:	mov    r15,QWORD PTR [r12+0x50]
    7ba63c6fe5ff:	add    r15,r14
    7ba63c6fe602:	mov    QWORD PTR [r12+0x48],r15
    7ba63c6fe607:	mov    r14,QWORD PTR [r12+0x40]
    7ba63c6fe60c:	add    r14,0x288
    7ba63c6fe613:	mov    QWORD PTR [r14],r15
    7ba63c6fe616:	mov    r14d,0x0
    7ba63c6fe61c:	mov    DWORD PTR [r12+0x32c],r14d
    7ba63c6fe624:	mov    r14,r13
    7ba63c6fe627:	add    r14,0x20
    7ba63c6fe62b:	mov    r15,QWORD PTR [r13+0x0]
    7ba63c6fe62f:	mov    QWORD PTR [r12+0xf0],r15
    7ba63c6fe637:	mov    QWORD PTR [r12+0xf8],r14
    7ba63c6fe63f:	mov    rcx,QWORD PTR [r12+0x380]
    7ba63c6fe647:	jrcxz  0x7ba63c6fe64e
    7ba63c6fe649:	jmp    0x7ba63c6fe99d
    7ba63c6fe64e:	mov    r13,QWORD PTR [r12+0xf0]
    7ba63c6fe656:	mov    QWORD PTR [r12+0x100],r13
    7ba63c6fe65e:	mov    r11,QWORD PTR [rsp]
    7ba63c6fe662:	mov    QWORD PTR [r12+0x398],r11
    7ba63c6fe66a:	mov    rdi,QWORD PTR [r12+0x100]
    7ba63c6fe672:	add    rsp,0x10
    7ba63c6fe676:	movabs r11,0x5eff4fe29940
    7ba63c6fe680:	jmp    r11
    7ba63c6fe683:	mov    r13d,DWORD PTR [r12+0xa0]
    7ba63c6fe68b:	add    r13d,0x11
    7ba63c6fe68f:	mov    QWORD PTR [r12],r13
    7ba63c6fe693:	mov    r13d,0x410184
    7ba63c6fe699:	mov    QWORD PTR [r12+0xf0],r13
    7ba63c6fe6a1:	mov    r13d,0x41021c
    7ba63c6fe6a7:	mov    QWORD PTR [r12+0x100],r13
    7ba63c6fe6af:	mov    r11,QWORD PTR [rsp]
    7ba63c6fe6b3:	mov    QWORD PTR [r12+0x398],r11
    7ba63c6fe6bb:	mov    edi,0x41021c
    7ba63c6fe6c0:	mov    QWORD PTR [r12+0x100],rdi
    7ba63c6fe6c8:	add    rsp,0x10
    7ba63c6fe6cc:	nop    DWORD PTR [rax+0x0]
    7ba63c6fe6d0:	jmp    QWORD PTR [rip+0x2]        # 0x7ba63c6fe6d8
    7ba63c6fe6d6:	xchg   ax,ax
    7ba63c6fe6d8:	lock loopne 0x7ba63c6fe74a
    7ba63c6fe6db:	cmp    al,0xa6
    7ba63c6fe6dd:	jnp    0x7ba63c6fe6df
    7ba63c6fe6df:	add    al,ch
    7ba63c6fe6e1:	out    0x6f,al
    7ba63c6fe6e3:	cmp    al,0xa6
    7ba63c6fe6e5:	jnp    0x7ba63c6fe6e7
    7ba63c6fe6e7:	add    BYTE PTR [rcx-0x45],cl
    7ba63c6fe6ea:	rex cdq
    7ba63c6fe6ec:	loop   0x7ba63c6fe73d
    7ba63c6fe6ee:	call   FWORD PTR [rsi+0x0]
    7ba63c6fe6f1:	add    BYTE PTR [rcx-0x1],al
    7ba63c6fe6f4:	jrcxz  0x7ba63c6fe6ae
    7ba63c6fe6f6:	nop
    7ba63c6fe6f7:	add    DWORD PTR [rcx+0x0],eax
    7ba63c6fe6fa:	mov    QWORD PTR [r12+0x100],rax
    7ba63c6fe702:	push   rdx
    7ba63c6fe703:	push   rsi
    7ba63c6fe704:	push   r10
    7ba63c6fe706:	push   r11
    7ba63c6fe708:	mov    r11,rax
    7ba63c6fe70b:	lahf
    7ba63c6fe70c:	seto   al
    7ba63c6fe70f:	mov    WORD PTR [rsp+0x20],ax
    7ba63c6fe714:	mov    rax,r11
    7ba63c6fe717:	mov    rdx,QWORD PTR [rsp+0x20]
    7ba63c6fe71c:	mov    r10d,edx
    7ba63c6fe71f:	and    r10d,0xc000
    7ba63c6fe726:	shl    r10d,0x10
    7ba63c6fe72a:	mov    r11d,edx
    7ba63c6fe72d:	and    r11d,0x100
    7ba63c6fe734:	shl    r11d,0x15
    7ba63c6fe738:	or     r10d,r11d
    7ba63c6fe73b:	and    edx,0x1
    7ba63c6fe73e:	shl    edx,0x1c
    7ba63c6fe741:	or     r10d,edx
    7ba63c6fe744:	btc    r10,0x1d
    7ba63c6fe749:	mov    r11d,0xf0000000
    7ba63c6fe74f:	and    r11,r10
    7ba63c6fe752:	movabs rsi,0xffffffff0fffffff
    7ba63c6fe75c:	and    rbx,rsi
    7ba63c6fe75f:	or     rbx,r11
    7ba63c6fe762:	pop    r11
    7ba63c6fe764:	pop    r10
    7ba63c6fe766:	pop    rsi
    7ba63c6fe767:	pop    rdx
    7ba63c6fe768:	mov    QWORD PTR [r12+0x108],rbx
    7ba63c6fe770:	add    rsp,0x10
    7ba63c6fe774:	mov    eax,0xc
    7ba63c6fe779:	movabs r11,0x5eff4fe29ca0
    7ba63c6fe783:	jmp    r11
    7ba63c6fe786:	mov    eax,0x4101c4
    7ba63c6fe78b:	mov    QWORD PTR [r12+0x100],rax
    7ba63c6fe793:	push   rdx
    7ba63c6fe794:	push   rsi
    7ba63c6fe795:	push   r10
    7ba63c6fe797:	push   r11
    7ba63c6fe799:	mov    r11,rax
    7ba63c6fe79c:	lahf
    7ba63c6fe79d:	seto   al
    7ba63c6fe7a0:	mov    WORD PTR [rsp+0x20],ax
    7ba63c6fe7a5:	mov    rax,r11
    7ba63c6fe7a8:	mov    rdx,QWORD PTR [rsp+0x20]
    7ba63c6fe7ad:	mov    r10d,edx
    7ba63c6fe7b0:	and    r10d,0xc000
    7ba63c6fe7b7:	shl    r10d,0x10
    7ba63c6fe7bb:	mov    r11d,edx
    7ba63c6fe7be:	and    r11d,0x100
    7ba63c6fe7c5:	shl    r11d,0x15
    7ba63c6fe7c9:	or     r10d,r11d
    7ba63c6fe7cc:	and    edx,0x1
    7ba63c6fe7cf:	shl    edx,0x1c
    7ba63c6fe7d2:	or     r10d,edx
    7ba63c6fe7d5:	btc    r10,0x1d
    7ba63c6fe7da:	mov    r11d,0xf0000000
    7ba63c6fe7e0:	and    r11,r10
    7ba63c6fe7e3:	movabs rsi,0xffffffff0fffffff
    7ba63c6fe7ed:	and    rbx,rsi
    7ba63c6fe7f0:	or     rbx,r11
    7ba63c6fe7f3:	pop    r11
    7ba63c6fe7f5:	pop    r10
    7ba63c6fe7f7:	pop    rsi
    7ba63c6fe7f8:	pop    rdx
    7ba63c6fe7f9:	mov    QWORD PTR [r12+0x108],rbx
    7ba63c6fe801:	add    rsp,0x10
    7ba63c6fe805:	mov    eax,0xc
    7ba63c6fe80a:	movabs r11,0x5eff4fe29ca0
    7ba63c6fe814:	jmp    r11
    7ba63c6fe817:	mov    eax,0x4101d0
    7ba63c6fe81c:	mov    QWORD PTR [r12+0x100],rax
    7ba63c6fe824:	push   rdx
    7ba63c6fe825:	push   rsi
    7ba63c6fe826:	push   r10
    7ba63c6fe828:	push   r11
    7ba63c6fe82a:	mov    rdx,QWORD PTR [rsp+0x20]
    7ba63c6fe82f:	mov    r10d,edx
    7ba63c6fe832:	and    r10d,0xc000
    7ba63c6fe839:	shl    r10d,0x10
    7ba63c6fe83d:	mov    r11d,edx
    7ba63c6fe840:	and    r11d,0x100
    7ba63c6fe847:	shl    r11d,0x15
    7ba63c6fe84b:	or     r10d,r11d
    7ba63c6fe84e:	and    edx,0x1
    7ba63c6fe851:	shl    edx,0x1c
    7ba63c6fe854:	or     r10d,edx
    7ba63c6fe857:	btc    r10,0x1d
    7ba63c6fe85c:	mov    r11d,0xf0000000
    7ba63c6fe862:	and    r11,r10
    7ba63c6fe865:	movabs rsi,0xffffffff0fffffff
    7ba63c6fe86f:	and    rbx,rsi
    7ba63c6fe872:	or     rbx,r11
    7ba63c6fe875:	pop    r11
    7ba63c6fe877:	pop    r10
    7ba63c6fe879:	pop    rsi
    7ba63c6fe87a:	pop    rdx
    7ba63c6fe87b:	mov    QWORD PTR [r12+0x108],rbx
    7ba63c6fe883:	add    rsp,0x10
    7ba63c6fe887:	mov    eax,0xc
    7ba63c6fe88c:	movabs r11,0x5eff4fe29ca0
    7ba63c6fe896:	jmp    r11
    7ba63c6fe899:	mov    eax,0x4101d4
    7ba63c6fe89e:	mov    QWORD PTR [r12+0x100],rax
    7ba63c6fe8a6:	push   rdx
    7ba63c6fe8a7:	push   rsi
    7ba63c6fe8a8:	push   r10
    7ba63c6fe8aa:	push   r11
    7ba63c6fe8ac:	mov    rdx,QWORD PTR [rsp+0x20]
    7ba63c6fe8b1:	mov    r10d,edx
    7ba63c6fe8b4:	and    r10d,0xc000
    7ba63c6fe8bb:	shl    r10d,0x10
    7ba63c6fe8bf:	mov    r11d,edx
    7ba63c6fe8c2:	and    r11d,0x100
    7ba63c6fe8c9:	shl    r11d,0x15
    7ba63c6fe8cd:	or     r10d,r11d
    7ba63c6fe8d0:	and    edx,0x1
    7ba63c6fe8d3:	shl    edx,0x1c
    7ba63c6fe8d6:	or     r10d,edx
    7ba63c6fe8d9:	btc    r10,0x1d
    7ba63c6fe8de:	mov    r11d,0xf0000000
    7ba63c6fe8e4:	and    r11,r10
    7ba63c6fe8e7:	movabs rsi,0xffffffff0fffffff
    7ba63c6fe8f1:	and    rbx,rsi
    7ba63c6fe8f4:	or     rbx,r11
    7ba63c6fe8f7:	pop    r11
    7ba63c6fe8f9:	pop    r10
    7ba63c6fe8fb:	pop    rsi
    7ba63c6fe8fc:	pop    rdx
    7ba63c6fe8fd:	mov    QWORD PTR [r12+0x108],rbx
    7ba63c6fe905:	add    rsp,0x10
    7ba63c6fe909:	mov    eax,0xc
    7ba63c6fe90e:	movabs r11,0x5eff4fe29ca0
    7ba63c6fe918:	jmp    r11
    7ba63c6fe91b:	mov    eax,0x410204
    7ba63c6fe920:	mov    QWORD PTR [r12+0x100],rax
    7ba63c6fe928:	push   rdx
    7ba63c6fe929:	push   rsi
    7ba63c6fe92a:	push   r10
    7ba63c6fe92c:	push   r11
    7ba63c6fe92e:	mov    rdx,QWORD PTR [rsp+0x20]
    7ba63c6fe933:	mov    r10d,edx
    7ba63c6fe936:	and    r10d,0xc000
    7ba63c6fe93d:	shl    r10d,0x10
    7ba63c6fe941:	mov    r11d,edx
    7ba63c6fe944:	and    r11d,0x100
    7ba63c6fe94b:	shl    r11d,0x15
    7ba63c6fe94f:	or     r10d,r11d
    7ba63c6fe952:	and    edx,0x1
    7ba63c6fe955:	shl    edx,0x1c
    7ba63c6fe958:	or     r10d,edx
    7ba63c6fe95b:	btc    r10,0x1d
    7ba63c6fe960:	mov    r11d,0xf0000000
    7ba63c6fe966:	and    r11,r10
    7ba63c6fe969:	movabs rsi,0xffffffff0fffffff
    7ba63c6fe973:	and    rbx,rsi
    7ba63c6fe976:	or     rbx,r11
    7ba63c6fe979:	pop    r11
    7ba63c6fe97b:	pop    r10
    7ba63c6fe97d:	pop    rsi
    7ba63c6fe97e:	pop    rdx
    7ba63c6fe97f:	mov    QWORD PTR [r12+0x108],rbx
    7ba63c6fe987:	add    rsp,0x10
    7ba63c6fe98b:	mov    eax,0xc
    7ba63c6fe990:	movabs r11,0x5eff4fe29ca0
    7ba63c6fe99a:	jmp    r11
    7ba63c6fe99d:	mov    eax,0x410218
    7ba63c6fe9a2:	mov    QWORD PTR [r12+0x100],rax
    7ba63c6fe9aa:	push   rdx
    7ba63c6fe9ab:	push   rsi
    7ba63c6fe9ac:	push   r10
    7ba63c6fe9ae:	push   r11
    7ba63c6fe9b0:	mov    rdx,QWORD PTR [rsp+0x20]
    7ba63c6fe9b5:	mov    r10d,edx
    7ba63c6fe9b8:	and    r10d,0xc000
    7ba63c6fe9bf:	shl    r10d,0x10
    7ba63c6fe9c3:	mov    r11d,edx
    7ba63c6fe9c6:	and    r11d,0x100
    7ba63c6fe9cd:	shl    r11d,0x15
    7ba63c6fe9d1:	or     r10d,r11d
    7ba63c6fe9d4:	and    edx,0x1
    7ba63c6fe9d7:	shl    edx,0x1c
    7ba63c6fe9da:	or     r10d,edx
    7ba63c6fe9dd:	btc    r10,0x1d
    7ba63c6fe9e2:	mov    r11d,0xf0000000
    7ba63c6fe9e8:	and    r11,r10
    7ba63c6fe9eb:	movabs rsi,0xffffffff0fffffff
    7ba63c6fe9f5:	and    rbx,rsi
    7ba63c6fe9f8:	or     rbx,r11
    7ba63c6fe9fb:	pop    r11
    7ba63c6fe9fd:	pop    r10
    7ba63c6fe9ff:	pop    rsi
    7ba63c6fea00:	pop    rdx
    7ba63c6fea01:	mov    QWORD PTR [r12+0x108],rbx
    7ba63c6fea09:	add    rsp,0x10
    7ba63c6fea0d:	mov    eax,0xc
    7ba63c6fea12:	movabs r11,0x5eff4fe29ca0
    7ba63c6fea1c:	jmp    r11
    7ba63c6fea1f:	nop
    7ba63c6fea20:	sub    rsp,0x10
    7ba63c6fea24:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6fea2c:	mov    QWORD PTR [rsp],r11
    7ba63c6fea30:	jmp    0x7ba63c6fe33d
    7ba63c6fea35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7ba63c6fea40:	sub    rsp,0x10
    7ba63c6fea44:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6fea4c:	mov    QWORD PTR [rsp],r11
    7ba63c6fea50:	mov    r11,rax
    7ba63c6fea53:	movzx  eax,WORD PTR [rsp]
    7ba63c6fea57:	add    al,0x7f
    7ba63c6fea59:	sahf
    7ba63c6fea5a:	mov    rax,r11
    7ba63c6fea5d:	jmp    0x7ba63c6fe35a
    7ba63c6fea62:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7ba63c6fea70:	sub    rsp,0x10
    7ba63c6fea74:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6fea7c:	mov    QWORD PTR [rsp],r11
    7ba63c6fea80:	jmp    0x7ba63c6fe39e
    7ba63c6fea85:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7ba63c6fea90:	sub    rsp,0x10
    7ba63c6fea94:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6fea9c:	mov    QWORD PTR [rsp],r11
    7ba63c6feaa0:	jmp    0x7ba63c6fe412
    7ba63c6feaa5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7ba63c6feab0:	sub    rsp,0x10
    7ba63c6feab4:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6feabc:	mov    QWORD PTR [rsp],r11
    7ba63c6feac0:	jmp    0x7ba63c6fe46d
    7ba63c6feac5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7ba63c6fead0:	sub    rsp,0x10
    7ba63c6fead4:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6feadc:	mov    QWORD PTR [rsp],r11
    7ba63c6feae0:	jmp    0x7ba63c6fe481
    7ba63c6feae5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7ba63c6feaf0:	sub    rsp,0x10
    7ba63c6feaf4:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6feafc:	mov    QWORD PTR [rsp],r11
    7ba63c6feb00:	jmp    0x7ba63c6fe491
    7ba63c6feb05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7ba63c6feb10:	sub    rsp,0x10
    7ba63c6feb14:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6feb1c:	mov    QWORD PTR [rsp],r11
    7ba63c6feb20:	jmp    0x7ba63c6fe4f1
    7ba63c6feb25:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7ba63c6feb30:	sub    rsp,0x10
    7ba63c6feb34:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6feb3c:	mov    QWORD PTR [rsp],r11
    7ba63c6feb40:	jmp    0x7ba63c6fe526
    7ba63c6feb45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7ba63c6feb50:	sub    rsp,0x10
    7ba63c6feb54:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6feb5c:	mov    QWORD PTR [rsp],r11
    7ba63c6feb60:	jmp    0x7ba63c6fe5c9
    7ba63c6feb65:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7ba63c6feb70:	sub    rsp,0x10
    7ba63c6feb74:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6feb7c:	mov    QWORD PTR [rsp],r11
    7ba63c6feb80:	jmp    0x7ba63c6fe683
    7ba63c6feb85:	nop
    7ba63c6feb86:	nop
    7ba63c6feb87:	nop
