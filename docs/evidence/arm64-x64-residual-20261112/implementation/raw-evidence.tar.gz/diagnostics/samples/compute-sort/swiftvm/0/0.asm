
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sort/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

00007c458b4fe000 <.data>:
    7c458b4fe000:	sub    rsp,0x10
    7c458b4fe004:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4fe00c:	mov    QWORD PTR [rsp],r11
    7c458b4fe010:	mov    r13,QWORD PTR [r12+0xf8]
    7c458b4fe018:	sub    r13,0x20
    7c458b4fe01c:	mov    r14,QWORD PTR [r12+0xf0]
    7c458b4fe024:	mov    QWORD PTR [r13+0x0],r14
    7c458b4fe028:	mov    r14d,0x0
    7c458b4fe02e:	mov    DWORD PTR [r12+0x32c],r14d
    7c458b4fe036:	mov    QWORD PTR [r12+0xf8],r13
    7c458b4fe03e:	add    r13,0x10
    7c458b4fe042:	mov    r14,r13
    7c458b4fe045:	add    r14,0x8
    7c458b4fe049:	mov    r15,QWORD PTR [r12+0xa0]
    7c458b4fe051:	mov    rbp,QWORD PTR [r12+0x98]
    7c458b4fe059:	mov    QWORD PTR [r13+0x0],r15
    7c458b4fe05d:	mov    QWORD PTR [r14],rbp
    7c458b4fe060:	mov    r13d,0x0
    7c458b4fe066:	mov    QWORD PTR [r12+0xa0],r13
    7c458b4fe06e:	mov    r13d,0x420000
    7c458b4fe074:	add    r13,0x2a0
    7c458b4fe07b:	mov    QWORD PTR [r12+0x98],r13
    7c458b4fe083:	mov    r13d,0x11
    7c458b4fe089:	mov    QWORD PTR [r12],r13
    7c458b4fe08d:	mov    r13d,0x410184
    7c458b4fe093:	mov    QWORD PTR [r12+0xf0],r13
    7c458b4fe09b:	mov    r13d,0x41021c
    7c458b4fe0a1:	mov    QWORD PTR [r12+0x100],r13
    7c458b4fe0a9:	mov    r11,QWORD PTR [rsp]
    7c458b4fe0ad:	mov    QWORD PTR [r12+0x398],r11
    7c458b4fe0b5:	mov    edi,0x41021c
    7c458b4fe0ba:	mov    QWORD PTR [r12+0x100],rdi
    7c458b4fe0c2:	add    rsp,0x10
    7c458b4fe0c6:	xchg   ax,ax
    7c458b4fe0c8:	jmp    QWORD PTR [rip+0x2]        # 0x7c458b4fe0d0
    7c458b4fe0ce:	xchg   ax,ax
    7c458b4fe0d0:	lock loopne 0x7c458b4fe122
    7c458b4fe0d3:	mov    eax,DWORD PTR [rbp+0x7c]
    7c458b4fe0d6:	add    BYTE PTR [rax],al
    7c458b4fe0d8:	loopne 0x7c458b4fe0ba
    7c458b4fe0da:	rex.WRXB mov r8,QWORD PTR [r13+0x7c]
    7c458b4fe0de:	add    BYTE PTR [rax],al
    7c458b4fe0e0:	movabs r11,0x5c8c5e619940
    7c458b4fe0ea:	jmp    r11
    7c458b4fe0ed:	nop
    7c458b4fe0ee:	nop
    7c458b4fe0ef:	nop
