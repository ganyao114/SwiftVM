
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sort/swiftvm/2/1.bin:     file format binary


Disassembly of section .data:

00007ba63c6fe0f0 <.data>:
    7ba63c6fe0f0:	sub    rsp,0x10
    7ba63c6fe0f4:	mov    r11,QWORD PTR [r12+0x398]
    7ba63c6fe0fc:	mov    QWORD PTR [rsp],r11
    7ba63c6fe100:	mov    r13d,0x352d
    7ba63c6fe106:	mov    QWORD PTR [r12+0x40],r13
    7ba63c6fe10b:	mov    r13d,0xa68b
    7ba63c6fe111:	mov    QWORD PTR [r12+0x48],r13
    7ba63c6fe116:	mov    r13d,0x352d
    7ba63c6fe11c:	mov    r14d,0x7feb
    7ba63c6fe122:	and    r14d,0xffff
    7ba63c6fe129:	mov    rax,r13
    7ba63c6fe12c:	movabs rcx,0xffffffff0000ffff
    7ba63c6fe136:	and    rax,rcx
    7ba63c6fe139:	mov    rdx,r14
    7ba63c6fe13c:	shl    rdx,0x10
    7ba63c6fe140:	mov    ecx,0xffff0000
    7ba63c6fe145:	and    rdx,rcx
    7ba63c6fe148:	or     rax,rdx
    7ba63c6fe14b:	mov    r15d,eax
    7ba63c6fe14e:	mov    QWORD PTR [r12+0x40],r15
    7ba63c6fe153:	mov    r13d,0xa68b
    7ba63c6fe159:	mov    r14d,0x846c
    7ba63c6fe15f:	and    r14d,0xffff
    7ba63c6fe166:	mov    rax,r13
    7ba63c6fe169:	movabs rcx,0xffffffff0000ffff
    7ba63c6fe173:	and    rax,rcx
    7ba63c6fe176:	mov    rdx,r14
    7ba63c6fe179:	shl    rdx,0x10
    7ba63c6fe17d:	mov    ecx,0xffff0000
    7ba63c6fe182:	and    rdx,rcx
    7ba63c6fe185:	or     rax,rdx
    7ba63c6fe188:	mov    ebp,eax
    7ba63c6fe18a:	mov    QWORD PTR [r12+0x48],rbp
    7ba63c6fe18f:	mov    r13d,DWORD PTR [r12]
    7ba63c6fe193:	mov    r14d,0x0
    7ba63c6fe199:	imul   r13d,r15d
    7ba63c6fe19d:	mov    r15d,r14d
    7ba63c6fe1a0:	add    r15d,r13d
    7ba63c6fe1a3:	mov    QWORD PTR [r12+0x40],r15
    7ba63c6fe1a8:	mov    r13d,r15d
    7ba63c6fe1ab:	mov    r13d,r13d
    7ba63c6fe1ae:	shr    r13d,0xf
    7ba63c6fe1b2:	xor    r15d,r13d
    7ba63c6fe1b5:	mov    QWORD PTR [r12+0x40],r15
    7ba63c6fe1ba:	mov    r13d,0x0
    7ba63c6fe1c0:	imul   r15d,ebp
    7ba63c6fe1c4:	mov    r14d,r13d
    7ba63c6fe1c7:	add    r14d,r15d
    7ba63c6fe1ca:	mov    QWORD PTR [r12+0x40],r14
    7ba63c6fe1cf:	mov    r13d,r14d
    7ba63c6fe1d2:	mov    r13d,r13d
    7ba63c6fe1d5:	shr    r13d,0x10
    7ba63c6fe1d9:	xor    r14d,r13d
    7ba63c6fe1dc:	mov    QWORD PTR [r12],r14
    7ba63c6fe1e0:	mov    rcx,QWORD PTR [r12+0x380]
    7ba63c6fe1e8:	jrcxz  0x7ba63c6fe1ef
    7ba63c6fe1ea:	jmp    0x7ba63c6fe224
    7ba63c6fe1ef:	mov    r13,QWORD PTR [r12+0xf0]
    7ba63c6fe1f7:	mov    QWORD PTR [r12+0x100],r13
    7ba63c6fe1ff:	mov    r11,QWORD PTR [rsp]
    7ba63c6fe203:	mov    QWORD PTR [r12+0x398],r11
    7ba63c6fe20b:	mov    rdi,QWORD PTR [r12+0x100]
    7ba63c6fe213:	add    rsp,0x10
    7ba63c6fe217:	movabs r11,0x5eff4fe29940
    7ba63c6fe221:	jmp    r11
    7ba63c6fe224:	mov    eax,0x41023c
    7ba63c6fe229:	mov    QWORD PTR [r12+0x100],rax
    7ba63c6fe231:	push   rdx
    7ba63c6fe232:	push   rsi
    7ba63c6fe233:	push   r10
    7ba63c6fe235:	push   r11
    7ba63c6fe237:	mov    rdx,QWORD PTR [rsp+0x20]
    7ba63c6fe23c:	mov    r10d,edx
    7ba63c6fe23f:	and    r10d,0xc000
    7ba63c6fe246:	shl    r10d,0x10
    7ba63c6fe24a:	mov    r11d,edx
    7ba63c6fe24d:	and    r11d,0x100
    7ba63c6fe254:	shl    r11d,0x15
    7ba63c6fe258:	or     r10d,r11d
    7ba63c6fe25b:	and    edx,0x1
    7ba63c6fe25e:	shl    edx,0x1c
    7ba63c6fe261:	or     r10d,edx
    7ba63c6fe264:	btc    r10,0x1d
    7ba63c6fe269:	mov    r11d,0xf0000000
    7ba63c6fe26f:	and    r11,r10
    7ba63c6fe272:	movabs rsi,0xffffffff0fffffff
    7ba63c6fe27c:	and    rbx,rsi
    7ba63c6fe27f:	or     rbx,r11
    7ba63c6fe282:	pop    r11
    7ba63c6fe284:	pop    r10
    7ba63c6fe286:	pop    rsi
    7ba63c6fe287:	pop    rdx
    7ba63c6fe288:	mov    QWORD PTR [r12+0x108],rbx
    7ba63c6fe290:	add    rsp,0x10
    7ba63c6fe294:	mov    eax,0xc
    7ba63c6fe299:	movabs r11,0x5eff4fe29ca0
    7ba63c6fe2a3:	jmp    r11
    7ba63c6fe2a6:	nop
    7ba63c6fe2a7:	nop
