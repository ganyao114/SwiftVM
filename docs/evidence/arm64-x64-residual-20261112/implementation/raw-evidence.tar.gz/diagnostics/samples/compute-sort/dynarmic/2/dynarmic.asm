0000761bcd5ce69b  nop [rax+rax*1], eax
0000761bcd5ce6a0  mov rax, [r15+0xF8]
0000761bcd5ce6a7  lea r14, [rax-0x20]
0000761bcd5ce6ab  mov r12, [r15+0xF0]
0000761bcd5ce6b2  mov [r13+r14*1], r12
0000761bcd5ce6b7  mov [r15+0xF8], r14
0000761bcd5ce6be  lea r14, [rax-0x10]
0000761bcd5ce6c2  mov r12, [r15+0xA0]
0000761bcd5ce6c9  mov r11, [r15+0x98]
0000761bcd5ce6d0  mov [r13+r14*1], r12
0000761bcd5ce6d5  lea r14, [rax-0x08]
0000761bcd5ce6d9  mov [r13+r14*1], r11
0000761bcd5ce6de  mov qword ptr [r15+0xA0], 0x00
0000761bcd5ce6e9  mov qword ptr [r15+0x98], 0x4202A0
0000761bcd5ce6f4  mov eax, [r15+0xA0]
0000761bcd5ce6fb  lea r14d, [eax+0x11]
0000761bcd5ce700  mov r14d, r14d
0000761bcd5ce703  mov [r15], r14
0000761bcd5ce706  mov qword ptr [r15+0xF0], 0x410184
0000761bcd5ce711  mov r14d, [r15+0x320]
0000761bcd5ce718  mov eax, 0x410184
0000761bcd5ce71d  mov rcx, 0x761BCD5CE800
0000761bcd5ce727  mov [r15+r14*8+0x328], rax
0000761bcd5ce72f  mov [r15+r14*8+0x368], rcx
0000761bcd5ce737  add r14d, 0x01
0000761bcd5ce73b  and r14d, 0x07
0000761bcd5ce73f  mov [r15+0x320], r14d
0000761bcd5ce746  cmp dword ptr [r15+0x318], 0x00
0000761bcd5ce74e  jz 0x0000761BCD5CE7A0
0000761bcd5ce754  nop [rax+rax*1], ax
0000761bcd5ce75d  nop [rax+rax*1], eax
0000761bcd5ce765  mov eax, 0x41021C
0000761bcd5ce76a  mov [r15+0x100], rax
0000761bcd5ce771  jmp 0x0000761BCD3FE110
0000761bcd5ce776  int3
0000761bcd5ce777  call 0x0000761BCD4E2CE0
0000761bcd5ce77c  jmp 0x0000761BCD5CE6B7
0000761bcd5ce781  call 0x0000761BCD4E2CE0
0000761bcd5ce786  jmp 0x0000761BCD5CE6D5
0000761bcd5ce78b  call 0x0000761BCD4E1A60
0000761bcd5ce790  jmp 0x0000761BCD5CE6DE
0000761bcd5ce795  int3
0000761bcd5ce796  nop [rax+rax*1], ax
0000761bcd5ce79f  nop
0000761bcd5ce7a0  mov eax, 0x846CA68B
0000761bcd5ce7a5  mov eax, eax
0000761bcd5ce7a7  mov [r15+0x48], rax
0000761bcd5ce7ab  mov eax, [r15]
0000761bcd5ce7ae  imul eax, eax, 0x7FEB352D
0000761bcd5ce7b4  mov [rsp+0x10], eax
0000761bcd5ce7b8  shr eax, 0x0F
0000761bcd5ce7bb  mov r14d, [rsp+0x10]
0000761bcd5ce7c0  xor r14d, eax
0000761bcd5ce7c3  imul r14d, r14d, 0x846CA68B
0000761bcd5ce7ca  mov [rsp+0x10], r14d
0000761bcd5ce7cf  mov r14d, r14d
0000761bcd5ce7d2  mov [r15+0x40], r14
0000761bcd5ce7d6  mov eax, [rsp+0x10]
0000761bcd5ce7da  shr eax, 0x10
0000761bcd5ce7dd  mov r14d, [rsp+0x10]
0000761bcd5ce7e2  xor r14d, eax
0000761bcd5ce7e5  mov r14d, r14d
0000761bcd5ce7e8  mov [r15], r14
0000761bcd5ce7eb  mov rax, [r15+0xF0]
0000761bcd5ce7f2  mov [r15+0x100], rax
0000761bcd5ce7f9  jmp 0x0000761BCD5CE5C0
0000761bcd5ce7fe  int3
0000761bcd5ce7ff  int3
0000761bcd5ce800  mov rax, [r15+0xA0]
0000761bcd5ce807  mov [rsp+0x10], rax
0000761bcd5ce80c  shl rax, 0x02
0000761bcd5ce810  mov r14, [r15+0x98]
0000761bcd5ce817  lea r12, [r14+rax*1]
0000761bcd5ce81b  mov eax, [r15]
0000761bcd5ce81e  mov [r13+r12*1], eax
0000761bcd5ce823  mov rax, [rsp+0x10]
0000761bcd5ce828  lea r14, [rax+0x01]
0000761bcd5ce82c  mov [r15+0xA0], r14
0000761bcd5ce833  xor eax, eax
0000761bcd5ce835  mov r12d, 0x400
0000761bcd5ce83b  cmp r14, r12
0000761bcd5ce83e  cmc
0000761bcd5ce83f  lahf
0000761bcd5ce840  seto al
0000761bcd5ce843  mov [r15+0x108], eax
0000761bcd5ce84a  mov eax, [r15+0x108]
0000761bcd5ce851  sahf
0000761bcd5ce852  jnz 0x0000761BCD5CE884
0000761bcd5ce854  cmp dword ptr [r15+0x318], 0x00
0000761bcd5ce85c  jz 0x0000761BCD5CE950
0000761bcd5ce862  nop [rax+rax*1], ax
0000761bcd5ce86b  nop [rax+rax*1], eax
0000761bcd5ce873  mov eax, 0x410194
0000761bcd5ce878  mov [r15+0x100], rax
0000761bcd5ce87f  jmp 0x0000761BCD3FE110
0000761bcd5ce884  cmp dword ptr [r15+0x318], 0x00
0000761bcd5ce88c  jz 0x0000761BCD5CE8C0
0000761bcd5ce892  nop [rax+rax*1], ax
0000761bcd5ce89b  nop [rax+rax*1], eax
0000761bcd5ce8a3  mov eax, 0x41017C
0000761bcd5ce8a8  mov [r15+0x100], rax
0000761bcd5ce8af  jmp 0x0000761BCD3FE110
0000761bcd5ce8b4  int3
0000761bcd5ce8b5  call 0x0000761BCD4B4B70
0000761bcd5ce8ba  jmp 0x0000761BCD5CE823
0000761bcd5ce8bf  int3
0000761bcd5ce8c0  mov eax, [r15+0xA0]
0000761bcd5ce8c7  lea r14d, [eax+0x11]
0000761bcd5ce8cc  mov r14d, r14d
0000761bcd5ce8cf  mov [r15], r14
0000761bcd5ce8d2  mov qword ptr [r15+0xF0], 0x410184
0000761bcd5ce8dd  mov r14d, [r15+0x320]
0000761bcd5ce8e4  mov eax, 0x410184
0000761bcd5ce8e9  mov rcx, 0x761BCD5CE800
0000761bcd5ce8f3  mov [r15+r14*8+0x328], rax
0000761bcd5ce8fb  mov [r15+r14*8+0x368], rcx
0000761bcd5ce903  add r14d, 0x01
0000761bcd5ce907  and r14d, 0x07
0000761bcd5ce90b  mov [r15+0x320], r14d
0000761bcd5ce912  cmp dword ptr [r15+0x318], 0x00
0000761bcd5ce91a  jz 0x0000761BCD5CE7A0
0000761bcd5ce920  nop [rax+rax*1], ax
0000761bcd5ce929  nop [rax+rax*1], eax
0000761bcd5ce931  mov eax, 0x41021C
0000761bcd5ce936  mov [r15+0x100], rax
0000761bcd5ce93d  jmp 0x0000761BCD3FE110
0000761bcd5ce942  int3
0000761bcd5ce943  int3
0000761bcd5ce944  nop [rax+rax*1], ax
0000761bcd5ce94d  nop [rax], eax
0000761bcd5ce950  mov qword ptr [r15+0x40], 0x01
0000761bcd5ce958  cmp dword ptr [r15+0x318], 0x00
0000761bcd5ce960  jz 0x0000761BCD5CE990
0000761bcd5ce966  nop [rax+rax*1], ax
0000761bcd5ce96f  nop [rax+rax*1], eax
0000761bcd5ce977  mov eax, 0x4101B0
0000761bcd5ce97c  mov [r15+0x100], rax
0000761bcd5ce983  jmp 0x0000761BCD3FE110
0000761bcd5ce988  int3
0000761bcd5ce989  int3
0000761bcd5ce98a  nop [rax+rax*1], ax
0000761bcd5ce990  mov rax, [r15+0x40]
0000761bcd5ce994  mov [rsp+0x10], rax
0000761bcd5ce999  shl rax, 0x02
0000761bcd5ce99d  mov r14, [r15+0x98]
0000761bcd5ce9a4  lea r12, [r14+rax*1]
0000761bcd5ce9a8  mov eax, [r13+r12*1]
0000761bcd5ce9ad  mov [rsp+0x20], eax
0000761bcd5ce9b1  mov eax, eax
0000761bcd5ce9b3  mov [r15+0x48], rax
0000761bcd5ce9b7  mov rax, [rsp+0x10]
0000761bcd5ce9bc  mov [r15+0x50], rax
0000761bcd5ce9c0  mov eax, [r15+0x50]
0000761bcd5ce9c4  lea r12d, [eax-0x01]
0000761bcd5ce9c9  mov r12d, r12d
0000761bcd5ce9cc  mov [r15+0x58], r12
0000761bcd5ce9d0  mov rax, [r15+0x58]
0000761bcd5ce9d4  mov r12d, eax
0000761bcd5ce9d7  mov r12d, r12d
0000761bcd5ce9da  shl r12, 0x02
0000761bcd5ce9de  lea rax, [r14+r12*1]
0000761bcd5ce9e2  mov r14d, [r13+rax*1]
0000761bcd5ce9e7  mov [rsp+0x10], r14d
0000761bcd5ce9ec  mov r14d, r14d
0000761bcd5ce9ef  mov [r15+0x60], r14
0000761bcd5ce9f3  xor eax, eax
0000761bcd5ce9f5  mov r14d, [rsp+0x10]
0000761bcd5ce9fa  mov r12d, [rsp+0x20]
0000761bcd5ce9ff  cmp r14d, r12d
0000761bcd5cea02  cmc
0000761bcd5cea03  lahf
0000761bcd5cea04  seto al
0000761bcd5cea07  mov [r15+0x108], eax
0000761bcd5cea0e  mov eax, [r15+0x108]
0000761bcd5cea15  sahf
0000761bcd5cea16  cmc
0000761bcd5cea17  jbe 0x0000761BCD5CEA49
0000761bcd5cea19  cmp dword ptr [r15+0x318], 0x00
0000761bcd5cea21  jz 0x0000761BCD5CEA90
0000761bcd5cea27  nop [rax+rax*1], ax
0000761bcd5cea30  nop [rax+rax*1], eax
0000761bcd5cea38  mov eax, 0x4101C8
0000761bcd5cea3d  mov [r15+0x100], rax
0000761bcd5cea44  jmp 0x0000761BCD3FE110
0000761bcd5cea49  cmp dword ptr [r15+0x318], 0x00
0000761bcd5cea51  jz 0x0000761BCD5CED30
0000761bcd5cea57  nop [rax+rax*1], ax
0000761bcd5cea60  nop [rax+rax*1], eax
0000761bcd5cea68  mov eax, 0x4101A0
0000761bcd5cea6d  mov [r15+0x100], rax
0000761bcd5cea74  jmp 0x0000761BCD3FE110
0000761bcd5cea79  int3
0000761bcd5cea7a  call 0x0000761BCD4B4690
0000761bcd5cea7f  jmp 0x0000761BCD5CE9AD
0000761bcd5cea84  call 0x0000761BCD40DAE0
0000761bcd5cea89  jmp 0x0000761BCD5CE9E7
0000761bcd5cea8e  int3
0000761bcd5cea8f  nop
0000761bcd5cea90  mov rax, [r15+0x50]
0000761bcd5cea94  mov [rsp+0x10], rax
0000761bcd5cea99  shl rax, 0x02
0000761bcd5cea9d  mov r14, [r15+0x98]
0000761bcd5ceaa4  lea r12, [r14+rax*1]
0000761bcd5ceaa8  mov eax, [r15+0x60]
0000761bcd5ceaac  mov [r13+r12*1], eax
0000761bcd5ceab1  mov rax, [rsp+0x10]
0000761bcd5ceab6  lea r14, [rax-0x01]
0000761bcd5ceaba  mov [r15+0x50], r14
0000761bcd5ceabe  mov rax, [r15+0x58]
0000761bcd5ceac2  test rax, rax
0000761bcd5ceac5  setz al
0000761bcd5ceac8  movzx rax, al
0000761bcd5ceacc  mov [rsp+0x414], al
0000761bcd5cead3  cmp byte ptr [rsp+0x414], 0x00
0000761bcd5ceadb  jz 0x0000761BCD5CEB0D
0000761bcd5ceadd  cmp dword ptr [r15+0x318], 0x00
0000761bcd5ceae5  jz 0x0000761BCD5CEB50
0000761bcd5ceaeb  nop [rax+rax*1], ax
0000761bcd5ceaf4  nop [rax+rax*1], eax
0000761bcd5ceafc  mov eax, 0x4101D4
0000761bcd5ceb01  mov [r15+0x100], rax
0000761bcd5ceb08  jmp 0x0000761BCD3FE110
0000761bcd5ceb0d  cmp dword ptr [r15+0x318], 0x00
0000761bcd5ceb15  jz 0x0000761BCD5CEC50
0000761bcd5ceb1b  nop [rax+rax*1], ax
0000761bcd5ceb24  nop [rax+rax*1], eax
0000761bcd5ceb2c  mov eax, 0x4101B8
0000761bcd5ceb31  mov [r15+0x100], rax
0000761bcd5ceb38  jmp 0x0000761BCD3FE110
0000761bcd5ceb3d  int3
0000761bcd5ceb3e  call 0x0000761BCD4B4B70
0000761bcd5ceb43  jmp 0x0000761BCD5CEAB1
0000761bcd5ceb48  int3
0000761bcd5ceb49  nop [rax], eax
0000761bcd5ceb50  cmp dword ptr [r15+0x318], 0x00
0000761bcd5ceb58  jz 0x0000761BCD5CEB90
0000761bcd5ceb5e  nop [rax+rax*1], ax
0000761bcd5ceb67  nop [rax+rax*1], eax
0000761bcd5ceb6f  mov eax, 0x41019C
0000761bcd5ceb74  mov [r15+0x100], rax
0000761bcd5ceb7b  jmp 0x0000761BCD3FE110
0000761bcd5ceb80  int3
0000761bcd5ceb81  int3
0000761bcd5ceb82  nop [rax+rax*1], ax
0000761bcd5ceb8b  nop [rax+rax*1], eax
0000761bcd5ceb90  mov qword ptr [r15+0x50], 0x00
0000761bcd5ceb98  mov rax, [r15+0x40]
0000761bcd5ceb9c  lea r14, [rax+0x01]
0000761bcd5ceba0  mov [r15+0x40], r14
0000761bcd5ceba4  mov rax, [r15+0x98]
0000761bcd5cebab  mov r12d, [r15+0x48]
0000761bcd5cebaf  mov [r13+rax*1], r12d
0000761bcd5cebb4  xor eax, eax
0000761bcd5cebb6  mov r12d, 0x400
0000761bcd5cebbc  cmp r14, r12
0000761bcd5cebbf  cmc
0000761bcd5cebc0  lahf
0000761bcd5cebc1  seto al
0000761bcd5cebc4  mov [r15+0x108], eax
0000761bcd5cebcb  mov eax, [r15+0x108]
0000761bcd5cebd2  sahf
0000761bcd5cebd3  jz 0x0000761BCD5CEC05
0000761bcd5cebd5  cmp dword ptr [r15+0x318], 0x00
0000761bcd5cebdd  jz 0x0000761BCD5CE990
0000761bcd5cebe3  nop [rax+rax*1], ax
0000761bcd5cebec  nop [rax+rax*1], eax
0000761bcd5cebf4  mov eax, 0x4101B0
0000761bcd5cebf9  mov [r15+0x100], rax
0000761bcd5cec00  jmp 0x0000761BCD3FE110
0000761bcd5cec05  cmp dword ptr [r15+0x318], 0x00
0000761bcd5cec0d  jz 0x0000761BCD5CEDF0
0000761bcd5cec13  nop [rax+rax*1], ax
0000761bcd5cec1c  nop [rax+rax*1], eax
0000761bcd5cec24  mov eax, 0x4101D8
0000761bcd5cec29  mov [r15+0x100], rax
0000761bcd5cec30  jmp 0x0000761BCD3FE110
0000761bcd5cec35  int3
0000761bcd5cec36  call 0x0000761BCD40BAE0
0000761bcd5cec3b  jmp 0x0000761BCD5CEBB4
0000761bcd5cec40  int3
0000761bcd5cec41  nop [rax+rax*1], ax
0000761bcd5cec4a  nop [rax+rax*1], ax
0000761bcd5cec50  mov eax, [r15+0x50]
0000761bcd5cec54  lea r14d, [eax-0x01]
0000761bcd5cec59  mov r14d, r14d
0000761bcd5cec5c  mov [r15+0x58], r14
0000761bcd5cec60  mov rax, [r15+0x58]
0000761bcd5cec64  mov r14d, eax
0000761bcd5cec67  mov r14d, r14d
0000761bcd5cec6a  shl r14, 0x02
0000761bcd5cec6e  mov rax, [r15+0x98]
0000761bcd5cec75  lea r12, [rax+r14*1]
0000761bcd5cec79  mov eax, [r13+r12*1]
0000761bcd5cec7e  mov [rsp+0x10], eax
0000761bcd5cec82  mov eax, eax
0000761bcd5cec84  mov [r15+0x60], rax
0000761bcd5cec88  mov eax, [r15+0x48]
0000761bcd5cec8c  mov [rsp+0x20], eax
0000761bcd5cec90  xor eax, eax
0000761bcd5cec92  mov r14d, [rsp+0x10]
0000761bcd5cec97  mov r12d, [rsp+0x20]
0000761bcd5cec9c  cmp r14d, r12d
0000761bcd5cec9f  cmc
0000761bcd5ceca0  lahf
0000761bcd5ceca1  seto al
0000761bcd5ceca4  mov [r15+0x108], eax
0000761bcd5cecab  mov eax, [r15+0x108]
0000761bcd5cecb2  sahf
0000761bcd5cecb3  cmc
0000761bcd5cecb4  jbe 0x0000761BCD5CECE6
0000761bcd5cecb6  cmp dword ptr [r15+0x318], 0x00
0000761bcd5cecbe  jz 0x0000761BCD5CEA90
0000761bcd5cecc4  nop [rax+rax*1], ax
0000761bcd5ceccd  nop [rax+rax*1], eax
0000761bcd5cecd5  mov eax, 0x4101C8
0000761bcd5cecda  mov [r15+0x100], rax
0000761bcd5cece1  jmp 0x0000761BCD3FE110
0000761bcd5cece6  cmp dword ptr [r15+0x318], 0x00
0000761bcd5cecee  jz 0x0000761BCD5CED30
0000761bcd5cecf4  nop [rax+rax*1], ax
0000761bcd5cecfd  nop [rax+rax*1], eax
0000761bcd5ced05  mov eax, 0x4101A0
0000761bcd5ced0a  mov [r15+0x100], rax
0000761bcd5ced11  jmp 0x0000761BCD3FE110
0000761bcd5ced16  int3
0000761bcd5ced17  call 0x0000761BCD4B4690
0000761bcd5ced1c  jmp 0x0000761BCD5CEC7E
0000761bcd5ced21  int3
0000761bcd5ced22  nop [rax+rax*1], ax
0000761bcd5ced2b  nop [rax+rax*1], eax
0000761bcd5ced30  mov rax, [r15+0x40]
0000761bcd5ced34  lea r14, [rax+0x01]
0000761bcd5ced38  mov [r15+0x40], r14
0000761bcd5ced3c  mov rax, [r15+0x50]
0000761bcd5ced40  mov r12d, eax
0000761bcd5ced43  mov r12d, r12d
0000761bcd5ced46  shl r12, 0x02
0000761bcd5ced4a  mov rax, [r15+0x98]
0000761bcd5ced51  lea r11, [rax+r12*1]
0000761bcd5ced55  mov eax, [r15+0x48]
0000761bcd5ced59  mov [r13+r11*1], eax
0000761bcd5ced5e  xor eax, eax
0000761bcd5ced60  mov r12d, 0x400
0000761bcd5ced66  cmp r14, r12
0000761bcd5ced69  cmc
0000761bcd5ced6a  lahf
0000761bcd5ced6b  seto al
0000761bcd5ced6e  mov [r15+0x108], eax
0000761bcd5ced75  mov eax, [r15+0x108]
0000761bcd5ced7c  sahf
0000761bcd5ced7d  jz 0x0000761BCD5CEDAF
0000761bcd5ced7f  cmp dword ptr [r15+0x318], 0x00
0000761bcd5ced87  jz 0x0000761BCD5CE990
0000761bcd5ced8d  nop [rax+rax*1], ax
0000761bcd5ced96  nop [rax+rax*1], eax
0000761bcd5ced9e  mov eax, 0x4101B0
0000761bcd5ceda3  mov [r15+0x100], rax
0000761bcd5cedaa  jmp 0x0000761BCD3FE110
0000761bcd5cedaf  cmp dword ptr [r15+0x318], 0x00
0000761bcd5cedb7  jz 0x0000761BCD5CEDF0
0000761bcd5cedbd  nop [rax+rax*1], ax
0000761bcd5cedc6  nop [rax+rax*1], eax
0000761bcd5cedce  mov eax, 0x4101D8
0000761bcd5cedd3  mov [r15+0x100], rax
0000761bcd5cedda  jmp 0x0000761BCD3FE110
0000761bcd5ceddf  int3
0000761bcd5cede0  call 0x0000761BCD4A4270
0000761bcd5cede5  jmp 0x0000761BCD5CED5E
0000761bcd5cedea  int3
0000761bcd5cedeb  nop [rax+rax*1], eax
0000761bcd5cedf0  mov qword ptr [r15+0x40], 0x420000
0000761bcd5cedf8  mov eax, 0x420288
0000761bcd5cedfd  mov r14, [r13+rax*1]
0000761bcd5cee02  mov rax, [r15+0x98]
0000761bcd5cee09  mov r12d, [r13+rax*1]
0000761bcd5cee0e  lea r11, [rax+0x04]
0000761bcd5cee12  mov eax, [r13+r11*1]
0000761bcd5cee17  mov r12d, r12d
0000761bcd5cee1a  mov [r15+0x68], r12
0000761bcd5cee1e  mov eax, eax
0000761bcd5cee20  mov [r15+0x60], rax
0000761bcd5cee24  mov rax, [r15+0x68]
0000761bcd5cee28  mov [r15+0x68], rax
0000761bcd5cee2c  mov qword ptr [r15+0x58], 0x02
0000761bcd5cee34  mov [rsp+0x10], rax
0000761bcd5cee39  xor eax, eax
0000761bcd5cee3b  mov r12d, 0x02
0000761bcd5cee41  mov r11d, 0x400
0000761bcd5cee47  cmp r12, r11
0000761bcd5cee4a  cmc
0000761bcd5cee4b  lahf
0000761bcd5cee4c  seto al
0000761bcd5cee4f  mov [r15+0x108], eax
0000761bcd5cee56  mov rax, [r15+0x60]
0000761bcd5cee5a  mov r12d, 0x02
0000761bcd5cee60  imul rax, r12
0000761bcd5cee64  mov [r15+0x50], rax
0000761bcd5cee68  mov rax, [rsp+0x10]
0000761bcd5cee6d  lea r12, [rax+r14*1]
0000761bcd5cee71  mov [r15+0x48], r12
0000761bcd5cee75  mov eax, [r15+0x108]
0000761bcd5cee7c  sahf
0000761bcd5cee7d  jnz 0x0000761BCD5CEEAF
0000761bcd5cee7f  cmp dword ptr [r15+0x318], 0x00
0000761bcd5cee87  jz 0x0000761BCD5CF020
0000761bcd5cee8d  nop [rax+rax*1], ax
0000761bcd5cee96  nop [rax+rax*1], eax
0000761bcd5cee9e  mov eax, 0x410208
0000761bcd5ceea3  mov [r15+0x100], rax
0000761bcd5ceeaa  jmp 0x0000761BCD3FE110
0000761bcd5ceeaf  cmp dword ptr [r15+0x318], 0x00
0000761bcd5ceeb7  jz 0x0000761BCD5CEF00
0000761bcd5ceebd  nop [rax+rax*1], ax
0000761bcd5ceec6  nop [rax+rax*1], eax
0000761bcd5ceece  mov eax, 0x4101E8
0000761bcd5ceed3  mov [r15+0x100], rax
0000761bcd5ceeda  jmp 0x0000761BCD3FE110
0000761bcd5ceedf  int3
0000761bcd5ceee0  call 0x0000761BCD40DC20
0000761bcd5ceee5  jmp 0x0000761BCD5CEE02
0000761bcd5ceeea  call 0x0000761BCD40B5E0
0000761bcd5ceeef  jmp 0x0000761BCD5CEE0E
0000761bcd5ceef4  call 0x0000761BCD4A3D90
0000761bcd5ceef9  jmp 0x0000761BCD5CEE17
0000761bcd5ceefe  int3
0000761bcd5ceeff  nop
0000761bcd5cef00  mov rax, [r15+0x98]
0000761bcd5cef07  mov r14, [r15+0x58]
0000761bcd5cef0b  mov [rsp+0x10], r14
0000761bcd5cef10  shl r14, 0x02
0000761bcd5cef14  lea r12, [rax+r14*1]
0000761bcd5cef18  mov eax, [r13+r12*1]
0000761bcd5cef1d  lea r14, [r12+0x04]
0000761bcd5cef22  mov r12d, [r13+r14*1]
0000761bcd5cef27  mov eax, eax
0000761bcd5cef29  mov [r15+0x68], rax
0000761bcd5cef2d  mov r12d, r12d
0000761bcd5cef30  mov [r15+0x60], r12
0000761bcd5cef34  mov rax, [r15+0x68]
0000761bcd5cef38  mov [rsp+0x20], rax
0000761bcd5cef3d  mov r14, [rsp+0x10]
0000761bcd5cef42  imul rax, r14
0000761bcd5cef46  mov r12, [rsp+0x20]
0000761bcd5cef4b  lea r11, [r12+rax*1]
0000761bcd5cef4f  mov [r15+0x68], r11
0000761bcd5cef53  lea rax, [r14+0x02]
0000761bcd5cef57  mov [r15+0x58], rax
0000761bcd5cef5b  mov [rsp+0x10], rax
0000761bcd5cef60  xor eax, eax
0000761bcd5cef62  mov r14, [rsp+0x10]
0000761bcd5cef67  mov r12d, 0x400
0000761bcd5cef6d  cmp r14, r12
0000761bcd5cef70  cmc
0000761bcd5cef71  lahf
0000761bcd5cef72  seto al
0000761bcd5cef75  mov [r15+0x108], eax
0000761bcd5cef7c  mov rax, [r15+0x50]
0000761bcd5cef80  mov r12, [r15+0x60]
0000761bcd5cef84  imul r14, r12
0000761bcd5cef88  lea r12, [rax+r14*1]
0000761bcd5cef8c  mov [r15+0x50], r12
0000761bcd5cef90  mov rax, [r15+0x48]
0000761bcd5cef94  lea r14, [r11+rax*1]
0000761bcd5cef98  mov [r15+0x48], r14
0000761bcd5cef9c  mov eax, [r15+0x108]
0000761bcd5cefa3  sahf
0000761bcd5cefa4  jnz 0x0000761BCD5CEFD6
0000761bcd5cefa6  cmp dword ptr [r15+0x318], 0x00
0000761bcd5cefae  jz 0x0000761BCD5CF020
0000761bcd5cefb4  nop [rax+rax*1], ax
0000761bcd5cefbd  nop [rax+rax*1], eax
0000761bcd5cefc5  mov eax, 0x410208
0000761bcd5cefca  mov [r15+0x100], rax
0000761bcd5cefd1  jmp 0x0000761BCD3FE110
0000761bcd5cefd6  cmp dword ptr [r15+0x318], 0x00
0000761bcd5cefde  jz 0x0000761BCD5CEF00
0000761bcd5cefe4  nop [rax+rax*1], ax
0000761bcd5cefed  nop [rax+rax*1], eax
0000761bcd5ceff5  mov eax, 0x4101E8
0000761bcd5ceffa  mov [r15+0x100], rax
0000761bcd5cf001  jmp 0x0000761BCD3FE110
0000761bcd5cf006  int3
0000761bcd5cf007  call 0x0000761BCD4B4690
0000761bcd5cf00c  jmp 0x0000761BCD5CEF1D
0000761bcd5cf011  call 0x0000761BCD4E26A0
0000761bcd5cf016  jmp 0x0000761BCD5CEF27
0000761bcd5cf01b  int3
0000761bcd5cf01c  nop [rax], eax
0000761bcd5cf020  mov rax, [r15+0xF8]
0000761bcd5cf027  lea r14, [rax+0x10]
0000761bcd5cf02b  mov r12, [r13+r14*1]
0000761bcd5cf030  lea r14, [rax+0x18]
0000761bcd5cf034  mov r11, [r13+r14*1]
0000761bcd5cf039  mov [r15+0xA0], r12
0000761bcd5cf040  mov [r15+0x98], r11
0000761bcd5cf047  mov r14, [r15+0x50]
0000761bcd5cf04b  mov r12, [r15+0x48]
0000761bcd5cf04f  lea r11, [r14+r12*1]
0000761bcd5cf053  mov [r15+0x48], r11
0000761bcd5cf057  mov r14, [r15+0x40]
0000761bcd5cf05b  lea r12, [r14+0x288]
0000761bcd5cf062  mov [r13+r12*1], r11
0000761bcd5cf067  mov r14, [r13+rax*1]
0000761bcd5cf06c  mov [r15+0xF0], r14
0000761bcd5cf073  lea r12, [rax+0x20]
0000761bcd5cf077  mov [r15+0xF8], r12
0000761bcd5cf07e  mov [r15+0x100], r14
0000761bcd5cf085  jmp 0x0000761BCD5CE5C0
0000761bcd5cf08a  int3
0000761bcd5cf08b  call 0x0000761BCD4E27E0
0000761bcd5cf090  jmp 0x0000761BCD5CF030
0000761bcd5cf095  call 0x0000761BCD4E1570
0000761bcd5cf09a  jmp 0x0000761BCD5CF039
0000761bcd5cf09f  call 0x0000761BCD4C0860
0000761bcd5cf0a4  jmp 0x0000761BCD5CF067
0000761bcd5cf0a9  call 0x0000761BCD40DC20
0000761bcd5cf0ae  jmp 0x0000761BCD5CF06C
0000761bcd5cf0b3  int3
0000761bcd5cf0b4  nop [rax+rax*1], ax
0000761bcd5cf0bd  nop [rax], eax
0000761bcd5cf0c0  mov qword ptr [r15+0x100], 0x04
0000761bcd5cf0cb  mov esi, 0x00
0000761bcd5cf0d0  mov edx, 0x09
0000761bcd5cf0d5  mov rdi, 0x7FFF0A4BC3A0
0000761bcd5cf0df  mov rax, 0x6391CC8CC970
0000761bcd5cf0e9  call rax
0000761bcd5cf0eb  cmp dword ptr [r15+0x318], 0x00
0000761bcd5cf0f3  jnz 0x0000761BCD3FE110
0000761bcd5cf0f9  jmp 0x0000761BCD3FE0A0
0000761bcd5cf0fe  int3
0000761bcd5cf0ff  int3
