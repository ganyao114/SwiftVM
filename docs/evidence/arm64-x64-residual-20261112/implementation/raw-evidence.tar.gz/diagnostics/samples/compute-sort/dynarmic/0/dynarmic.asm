000074ad9b3ce69b  nop [rax+rax*1], eax
000074ad9b3ce6a0  mov rax, [r15+0xF8]
000074ad9b3ce6a7  lea r14, [rax-0x20]
000074ad9b3ce6ab  mov r12, [r15+0xF0]
000074ad9b3ce6b2  mov [r13+r14*1], r12
000074ad9b3ce6b7  mov [r15+0xF8], r14
000074ad9b3ce6be  lea r14, [rax-0x10]
000074ad9b3ce6c2  mov r12, [r15+0xA0]
000074ad9b3ce6c9  mov r11, [r15+0x98]
000074ad9b3ce6d0  mov [r13+r14*1], r12
000074ad9b3ce6d5  lea r14, [rax-0x08]
000074ad9b3ce6d9  mov [r13+r14*1], r11
000074ad9b3ce6de  mov qword ptr [r15+0xA0], 0x00
000074ad9b3ce6e9  mov qword ptr [r15+0x98], 0x4202A0
000074ad9b3ce6f4  mov eax, [r15+0xA0]
000074ad9b3ce6fb  lea r14d, [eax+0x11]
000074ad9b3ce700  mov r14d, r14d
000074ad9b3ce703  mov [r15], r14
000074ad9b3ce706  mov qword ptr [r15+0xF0], 0x410184
000074ad9b3ce711  mov r14d, [r15+0x320]
000074ad9b3ce718  mov eax, 0x410184
000074ad9b3ce71d  mov rcx, 0x74AD9B3CE800
000074ad9b3ce727  mov [r15+r14*8+0x328], rax
000074ad9b3ce72f  mov [r15+r14*8+0x368], rcx
000074ad9b3ce737  add r14d, 0x01
000074ad9b3ce73b  and r14d, 0x07
000074ad9b3ce73f  mov [r15+0x320], r14d
000074ad9b3ce746  cmp dword ptr [r15+0x318], 0x00
000074ad9b3ce74e  jz 0x000074AD9B3CE7A0
000074ad9b3ce754  nop [rax+rax*1], ax
000074ad9b3ce75d  nop [rax+rax*1], eax
000074ad9b3ce765  mov eax, 0x41021C
000074ad9b3ce76a  mov [r15+0x100], rax
000074ad9b3ce771  jmp 0x000074AD9B1FE110
000074ad9b3ce776  int3
000074ad9b3ce777  call 0x000074AD9B2E2CE0
000074ad9b3ce77c  jmp 0x000074AD9B3CE6B7
000074ad9b3ce781  call 0x000074AD9B2E2CE0
000074ad9b3ce786  jmp 0x000074AD9B3CE6D5
000074ad9b3ce78b  call 0x000074AD9B2E1A60
000074ad9b3ce790  jmp 0x000074AD9B3CE6DE
000074ad9b3ce795  int3
000074ad9b3ce796  nop [rax+rax*1], ax
000074ad9b3ce79f  nop
000074ad9b3ce7a0  mov eax, 0x846CA68B
000074ad9b3ce7a5  mov eax, eax
000074ad9b3ce7a7  mov [r15+0x48], rax
000074ad9b3ce7ab  mov eax, [r15]
000074ad9b3ce7ae  imul eax, eax, 0x7FEB352D
000074ad9b3ce7b4  mov [rsp+0x10], eax
000074ad9b3ce7b8  shr eax, 0x0F
000074ad9b3ce7bb  mov r14d, [rsp+0x10]
000074ad9b3ce7c0  xor r14d, eax
000074ad9b3ce7c3  imul r14d, r14d, 0x846CA68B
000074ad9b3ce7ca  mov [rsp+0x10], r14d
000074ad9b3ce7cf  mov r14d, r14d
000074ad9b3ce7d2  mov [r15+0x40], r14
000074ad9b3ce7d6  mov eax, [rsp+0x10]
000074ad9b3ce7da  shr eax, 0x10
000074ad9b3ce7dd  mov r14d, [rsp+0x10]
000074ad9b3ce7e2  xor r14d, eax
000074ad9b3ce7e5  mov r14d, r14d
000074ad9b3ce7e8  mov [r15], r14
000074ad9b3ce7eb  mov rax, [r15+0xF0]
000074ad9b3ce7f2  mov [r15+0x100], rax
000074ad9b3ce7f9  jmp 0x000074AD9B3CE5C0
000074ad9b3ce7fe  int3
000074ad9b3ce7ff  int3
000074ad9b3ce800  mov rax, [r15+0xA0]
000074ad9b3ce807  mov [rsp+0x10], rax
000074ad9b3ce80c  shl rax, 0x02
000074ad9b3ce810  mov r14, [r15+0x98]
000074ad9b3ce817  lea r12, [r14+rax*1]
000074ad9b3ce81b  mov eax, [r15]
000074ad9b3ce81e  mov [r13+r12*1], eax
000074ad9b3ce823  mov rax, [rsp+0x10]
000074ad9b3ce828  lea r14, [rax+0x01]
000074ad9b3ce82c  mov [r15+0xA0], r14
000074ad9b3ce833  xor eax, eax
000074ad9b3ce835  mov r12d, 0x400
000074ad9b3ce83b  cmp r14, r12
000074ad9b3ce83e  cmc
000074ad9b3ce83f  lahf
000074ad9b3ce840  seto al
000074ad9b3ce843  mov [r15+0x108], eax
000074ad9b3ce84a  mov eax, [r15+0x108]
000074ad9b3ce851  sahf
000074ad9b3ce852  jnz 0x000074AD9B3CE884
000074ad9b3ce854  cmp dword ptr [r15+0x318], 0x00
000074ad9b3ce85c  jz 0x000074AD9B3CE950
000074ad9b3ce862  nop [rax+rax*1], ax
000074ad9b3ce86b  nop [rax+rax*1], eax
000074ad9b3ce873  mov eax, 0x410194
000074ad9b3ce878  mov [r15+0x100], rax
000074ad9b3ce87f  jmp 0x000074AD9B1FE110
000074ad9b3ce884  cmp dword ptr [r15+0x318], 0x00
000074ad9b3ce88c  jz 0x000074AD9B3CE8C0
000074ad9b3ce892  nop [rax+rax*1], ax
000074ad9b3ce89b  nop [rax+rax*1], eax
000074ad9b3ce8a3  mov eax, 0x41017C
000074ad9b3ce8a8  mov [r15+0x100], rax
000074ad9b3ce8af  jmp 0x000074AD9B1FE110
000074ad9b3ce8b4  int3
000074ad9b3ce8b5  call 0x000074AD9B2B4B70
000074ad9b3ce8ba  jmp 0x000074AD9B3CE823
000074ad9b3ce8bf  int3
000074ad9b3ce8c0  mov eax, [r15+0xA0]
000074ad9b3ce8c7  lea r14d, [eax+0x11]
000074ad9b3ce8cc  mov r14d, r14d
000074ad9b3ce8cf  mov [r15], r14
000074ad9b3ce8d2  mov qword ptr [r15+0xF0], 0x410184
000074ad9b3ce8dd  mov r14d, [r15+0x320]
000074ad9b3ce8e4  mov eax, 0x410184
000074ad9b3ce8e9  mov rcx, 0x74AD9B3CE800
000074ad9b3ce8f3  mov [r15+r14*8+0x328], rax
000074ad9b3ce8fb  mov [r15+r14*8+0x368], rcx
000074ad9b3ce903  add r14d, 0x01
000074ad9b3ce907  and r14d, 0x07
000074ad9b3ce90b  mov [r15+0x320], r14d
000074ad9b3ce912  cmp dword ptr [r15+0x318], 0x00
000074ad9b3ce91a  jz 0x000074AD9B3CE7A0
000074ad9b3ce920  nop [rax+rax*1], ax
000074ad9b3ce929  nop [rax+rax*1], eax
000074ad9b3ce931  mov eax, 0x41021C
000074ad9b3ce936  mov [r15+0x100], rax
000074ad9b3ce93d  jmp 0x000074AD9B1FE110
000074ad9b3ce942  int3
000074ad9b3ce943  int3
000074ad9b3ce944  nop [rax+rax*1], ax
000074ad9b3ce94d  nop [rax], eax
000074ad9b3ce950  mov qword ptr [r15+0x40], 0x01
000074ad9b3ce958  cmp dword ptr [r15+0x318], 0x00
000074ad9b3ce960  jz 0x000074AD9B3CE990
000074ad9b3ce966  nop [rax+rax*1], ax
000074ad9b3ce96f  nop [rax+rax*1], eax
000074ad9b3ce977  mov eax, 0x4101B0
000074ad9b3ce97c  mov [r15+0x100], rax
000074ad9b3ce983  jmp 0x000074AD9B1FE110
000074ad9b3ce988  int3
000074ad9b3ce989  int3
000074ad9b3ce98a  nop [rax+rax*1], ax
000074ad9b3ce990  mov rax, [r15+0x40]
000074ad9b3ce994  mov [rsp+0x10], rax
000074ad9b3ce999  shl rax, 0x02
000074ad9b3ce99d  mov r14, [r15+0x98]
000074ad9b3ce9a4  lea r12, [r14+rax*1]
000074ad9b3ce9a8  mov eax, [r13+r12*1]
000074ad9b3ce9ad  mov [rsp+0x20], eax
000074ad9b3ce9b1  mov eax, eax
000074ad9b3ce9b3  mov [r15+0x48], rax
000074ad9b3ce9b7  mov rax, [rsp+0x10]
000074ad9b3ce9bc  mov [r15+0x50], rax
000074ad9b3ce9c0  mov eax, [r15+0x50]
000074ad9b3ce9c4  lea r12d, [eax-0x01]
000074ad9b3ce9c9  mov r12d, r12d
000074ad9b3ce9cc  mov [r15+0x58], r12
000074ad9b3ce9d0  mov rax, [r15+0x58]
000074ad9b3ce9d4  mov r12d, eax
000074ad9b3ce9d7  mov r12d, r12d
000074ad9b3ce9da  shl r12, 0x02
000074ad9b3ce9de  lea rax, [r14+r12*1]
000074ad9b3ce9e2  mov r14d, [r13+rax*1]
000074ad9b3ce9e7  mov [rsp+0x10], r14d
000074ad9b3ce9ec  mov r14d, r14d
000074ad9b3ce9ef  mov [r15+0x60], r14
000074ad9b3ce9f3  xor eax, eax
000074ad9b3ce9f5  mov r14d, [rsp+0x10]
000074ad9b3ce9fa  mov r12d, [rsp+0x20]
000074ad9b3ce9ff  cmp r14d, r12d
000074ad9b3cea02  cmc
000074ad9b3cea03  lahf
000074ad9b3cea04  seto al
000074ad9b3cea07  mov [r15+0x108], eax
000074ad9b3cea0e  mov eax, [r15+0x108]
000074ad9b3cea15  sahf
000074ad9b3cea16  cmc
000074ad9b3cea17  jbe 0x000074AD9B3CEA49
000074ad9b3cea19  cmp dword ptr [r15+0x318], 0x00
000074ad9b3cea21  jz 0x000074AD9B3CEA90
000074ad9b3cea27  nop [rax+rax*1], ax
000074ad9b3cea30  nop [rax+rax*1], eax
000074ad9b3cea38  mov eax, 0x4101C8
000074ad9b3cea3d  mov [r15+0x100], rax
000074ad9b3cea44  jmp 0x000074AD9B1FE110
000074ad9b3cea49  cmp dword ptr [r15+0x318], 0x00
000074ad9b3cea51  jz 0x000074AD9B3CED30
000074ad9b3cea57  nop [rax+rax*1], ax
000074ad9b3cea60  nop [rax+rax*1], eax
000074ad9b3cea68  mov eax, 0x4101A0
000074ad9b3cea6d  mov [r15+0x100], rax
000074ad9b3cea74  jmp 0x000074AD9B1FE110
000074ad9b3cea79  int3
000074ad9b3cea7a  call 0x000074AD9B2B4690
000074ad9b3cea7f  jmp 0x000074AD9B3CE9AD
000074ad9b3cea84  call 0x000074AD9B20DAE0
000074ad9b3cea89  jmp 0x000074AD9B3CE9E7
000074ad9b3cea8e  int3
000074ad9b3cea8f  nop
000074ad9b3cea90  mov rax, [r15+0x50]
000074ad9b3cea94  mov [rsp+0x10], rax
000074ad9b3cea99  shl rax, 0x02
000074ad9b3cea9d  mov r14, [r15+0x98]
000074ad9b3ceaa4  lea r12, [r14+rax*1]
000074ad9b3ceaa8  mov eax, [r15+0x60]
000074ad9b3ceaac  mov [r13+r12*1], eax
000074ad9b3ceab1  mov rax, [rsp+0x10]
000074ad9b3ceab6  lea r14, [rax-0x01]
000074ad9b3ceaba  mov [r15+0x50], r14
000074ad9b3ceabe  mov rax, [r15+0x58]
000074ad9b3ceac2  test rax, rax
000074ad9b3ceac5  setz al
000074ad9b3ceac8  movzx rax, al
000074ad9b3ceacc  mov [rsp+0x414], al
000074ad9b3cead3  cmp byte ptr [rsp+0x414], 0x00
000074ad9b3ceadb  jz 0x000074AD9B3CEB0D
000074ad9b3ceadd  cmp dword ptr [r15+0x318], 0x00
000074ad9b3ceae5  jz 0x000074AD9B3CEB50
000074ad9b3ceaeb  nop [rax+rax*1], ax
000074ad9b3ceaf4  nop [rax+rax*1], eax
000074ad9b3ceafc  mov eax, 0x4101D4
000074ad9b3ceb01  mov [r15+0x100], rax
000074ad9b3ceb08  jmp 0x000074AD9B1FE110
000074ad9b3ceb0d  cmp dword ptr [r15+0x318], 0x00
000074ad9b3ceb15  jz 0x000074AD9B3CEC50
000074ad9b3ceb1b  nop [rax+rax*1], ax
000074ad9b3ceb24  nop [rax+rax*1], eax
000074ad9b3ceb2c  mov eax, 0x4101B8
000074ad9b3ceb31  mov [r15+0x100], rax
000074ad9b3ceb38  jmp 0x000074AD9B1FE110
000074ad9b3ceb3d  int3
000074ad9b3ceb3e  call 0x000074AD9B2B4B70
000074ad9b3ceb43  jmp 0x000074AD9B3CEAB1
000074ad9b3ceb48  int3
000074ad9b3ceb49  nop [rax], eax
000074ad9b3ceb50  cmp dword ptr [r15+0x318], 0x00
000074ad9b3ceb58  jz 0x000074AD9B3CEB90
000074ad9b3ceb5e  nop [rax+rax*1], ax
000074ad9b3ceb67  nop [rax+rax*1], eax
000074ad9b3ceb6f  mov eax, 0x41019C
000074ad9b3ceb74  mov [r15+0x100], rax
000074ad9b3ceb7b  jmp 0x000074AD9B1FE110
000074ad9b3ceb80  int3
000074ad9b3ceb81  int3
000074ad9b3ceb82  nop [rax+rax*1], ax
000074ad9b3ceb8b  nop [rax+rax*1], eax
000074ad9b3ceb90  mov qword ptr [r15+0x50], 0x00
000074ad9b3ceb98  mov rax, [r15+0x40]
000074ad9b3ceb9c  lea r14, [rax+0x01]
000074ad9b3ceba0  mov [r15+0x40], r14
000074ad9b3ceba4  mov rax, [r15+0x98]
000074ad9b3cebab  mov r12d, [r15+0x48]
000074ad9b3cebaf  mov [r13+rax*1], r12d
000074ad9b3cebb4  xor eax, eax
000074ad9b3cebb6  mov r12d, 0x400
000074ad9b3cebbc  cmp r14, r12
000074ad9b3cebbf  cmc
000074ad9b3cebc0  lahf
000074ad9b3cebc1  seto al
000074ad9b3cebc4  mov [r15+0x108], eax
000074ad9b3cebcb  mov eax, [r15+0x108]
000074ad9b3cebd2  sahf
000074ad9b3cebd3  jz 0x000074AD9B3CEC05
000074ad9b3cebd5  cmp dword ptr [r15+0x318], 0x00
000074ad9b3cebdd  jz 0x000074AD9B3CE990
000074ad9b3cebe3  nop [rax+rax*1], ax
000074ad9b3cebec  nop [rax+rax*1], eax
000074ad9b3cebf4  mov eax, 0x4101B0
000074ad9b3cebf9  mov [r15+0x100], rax
000074ad9b3cec00  jmp 0x000074AD9B1FE110
000074ad9b3cec05  cmp dword ptr [r15+0x318], 0x00
000074ad9b3cec0d  jz 0x000074AD9B3CEDF0
000074ad9b3cec13  nop [rax+rax*1], ax
000074ad9b3cec1c  nop [rax+rax*1], eax
000074ad9b3cec24  mov eax, 0x4101D8
000074ad9b3cec29  mov [r15+0x100], rax
000074ad9b3cec30  jmp 0x000074AD9B1FE110
000074ad9b3cec35  int3
000074ad9b3cec36  call 0x000074AD9B20BAE0
000074ad9b3cec3b  jmp 0x000074AD9B3CEBB4
000074ad9b3cec40  int3
000074ad9b3cec41  nop [rax+rax*1], ax
000074ad9b3cec4a  nop [rax+rax*1], ax
000074ad9b3cec50  mov eax, [r15+0x50]
000074ad9b3cec54  lea r14d, [eax-0x01]
000074ad9b3cec59  mov r14d, r14d
000074ad9b3cec5c  mov [r15+0x58], r14
000074ad9b3cec60  mov rax, [r15+0x58]
000074ad9b3cec64  mov r14d, eax
000074ad9b3cec67  mov r14d, r14d
000074ad9b3cec6a  shl r14, 0x02
000074ad9b3cec6e  mov rax, [r15+0x98]
000074ad9b3cec75  lea r12, [rax+r14*1]
000074ad9b3cec79  mov eax, [r13+r12*1]
000074ad9b3cec7e  mov [rsp+0x10], eax
000074ad9b3cec82  mov eax, eax
000074ad9b3cec84  mov [r15+0x60], rax
000074ad9b3cec88  mov eax, [r15+0x48]
000074ad9b3cec8c  mov [rsp+0x20], eax
000074ad9b3cec90  xor eax, eax
000074ad9b3cec92  mov r14d, [rsp+0x10]
000074ad9b3cec97  mov r12d, [rsp+0x20]
000074ad9b3cec9c  cmp r14d, r12d
000074ad9b3cec9f  cmc
000074ad9b3ceca0  lahf
000074ad9b3ceca1  seto al
000074ad9b3ceca4  mov [r15+0x108], eax
000074ad9b3cecab  mov eax, [r15+0x108]
000074ad9b3cecb2  sahf
000074ad9b3cecb3  cmc
000074ad9b3cecb4  jbe 0x000074AD9B3CECE6
000074ad9b3cecb6  cmp dword ptr [r15+0x318], 0x00
000074ad9b3cecbe  jz 0x000074AD9B3CEA90
000074ad9b3cecc4  nop [rax+rax*1], ax
000074ad9b3ceccd  nop [rax+rax*1], eax
000074ad9b3cecd5  mov eax, 0x4101C8
000074ad9b3cecda  mov [r15+0x100], rax
000074ad9b3cece1  jmp 0x000074AD9B1FE110
000074ad9b3cece6  cmp dword ptr [r15+0x318], 0x00
000074ad9b3cecee  jz 0x000074AD9B3CED30
000074ad9b3cecf4  nop [rax+rax*1], ax
000074ad9b3cecfd  nop [rax+rax*1], eax
000074ad9b3ced05  mov eax, 0x4101A0
000074ad9b3ced0a  mov [r15+0x100], rax
000074ad9b3ced11  jmp 0x000074AD9B1FE110
000074ad9b3ced16  int3
000074ad9b3ced17  call 0x000074AD9B2B4690
000074ad9b3ced1c  jmp 0x000074AD9B3CEC7E
000074ad9b3ced21  int3
000074ad9b3ced22  nop [rax+rax*1], ax
000074ad9b3ced2b  nop [rax+rax*1], eax
000074ad9b3ced30  mov rax, [r15+0x40]
000074ad9b3ced34  lea r14, [rax+0x01]
000074ad9b3ced38  mov [r15+0x40], r14
000074ad9b3ced3c  mov rax, [r15+0x50]
000074ad9b3ced40  mov r12d, eax
000074ad9b3ced43  mov r12d, r12d
000074ad9b3ced46  shl r12, 0x02
000074ad9b3ced4a  mov rax, [r15+0x98]
000074ad9b3ced51  lea r11, [rax+r12*1]
000074ad9b3ced55  mov eax, [r15+0x48]
000074ad9b3ced59  mov [r13+r11*1], eax
000074ad9b3ced5e  xor eax, eax
000074ad9b3ced60  mov r12d, 0x400
000074ad9b3ced66  cmp r14, r12
000074ad9b3ced69  cmc
000074ad9b3ced6a  lahf
000074ad9b3ced6b  seto al
000074ad9b3ced6e  mov [r15+0x108], eax
000074ad9b3ced75  mov eax, [r15+0x108]
000074ad9b3ced7c  sahf
000074ad9b3ced7d  jz 0x000074AD9B3CEDAF
000074ad9b3ced7f  cmp dword ptr [r15+0x318], 0x00
000074ad9b3ced87  jz 0x000074AD9B3CE990
000074ad9b3ced8d  nop [rax+rax*1], ax
000074ad9b3ced96  nop [rax+rax*1], eax
000074ad9b3ced9e  mov eax, 0x4101B0
000074ad9b3ceda3  mov [r15+0x100], rax
000074ad9b3cedaa  jmp 0x000074AD9B1FE110
000074ad9b3cedaf  cmp dword ptr [r15+0x318], 0x00
000074ad9b3cedb7  jz 0x000074AD9B3CEDF0
000074ad9b3cedbd  nop [rax+rax*1], ax
000074ad9b3cedc6  nop [rax+rax*1], eax
000074ad9b3cedce  mov eax, 0x4101D8
000074ad9b3cedd3  mov [r15+0x100], rax
000074ad9b3cedda  jmp 0x000074AD9B1FE110
000074ad9b3ceddf  int3
000074ad9b3cede0  call 0x000074AD9B2A4270
000074ad9b3cede5  jmp 0x000074AD9B3CED5E
000074ad9b3cedea  int3
000074ad9b3cedeb  nop [rax+rax*1], eax
000074ad9b3cedf0  mov qword ptr [r15+0x40], 0x420000
000074ad9b3cedf8  mov eax, 0x420288
000074ad9b3cedfd  mov r14, [r13+rax*1]
000074ad9b3cee02  mov rax, [r15+0x98]
000074ad9b3cee09  mov r12d, [r13+rax*1]
000074ad9b3cee0e  lea r11, [rax+0x04]
000074ad9b3cee12  mov eax, [r13+r11*1]
000074ad9b3cee17  mov r12d, r12d
000074ad9b3cee1a  mov [r15+0x68], r12
000074ad9b3cee1e  mov eax, eax
000074ad9b3cee20  mov [r15+0x60], rax
000074ad9b3cee24  mov rax, [r15+0x68]
000074ad9b3cee28  mov [r15+0x68], rax
000074ad9b3cee2c  mov qword ptr [r15+0x58], 0x02
000074ad9b3cee34  mov [rsp+0x10], rax
000074ad9b3cee39  xor eax, eax
000074ad9b3cee3b  mov r12d, 0x02
000074ad9b3cee41  mov r11d, 0x400
000074ad9b3cee47  cmp r12, r11
000074ad9b3cee4a  cmc
000074ad9b3cee4b  lahf
000074ad9b3cee4c  seto al
000074ad9b3cee4f  mov [r15+0x108], eax
000074ad9b3cee56  mov rax, [r15+0x60]
000074ad9b3cee5a  mov r12d, 0x02
000074ad9b3cee60  imul rax, r12
000074ad9b3cee64  mov [r15+0x50], rax
000074ad9b3cee68  mov rax, [rsp+0x10]
000074ad9b3cee6d  lea r12, [rax+r14*1]
000074ad9b3cee71  mov [r15+0x48], r12
000074ad9b3cee75  mov eax, [r15+0x108]
000074ad9b3cee7c  sahf
000074ad9b3cee7d  jnz 0x000074AD9B3CEEAF
000074ad9b3cee7f  cmp dword ptr [r15+0x318], 0x00
000074ad9b3cee87  jz 0x000074AD9B3CF020
000074ad9b3cee8d  nop [rax+rax*1], ax
000074ad9b3cee96  nop [rax+rax*1], eax
000074ad9b3cee9e  mov eax, 0x410208
000074ad9b3ceea3  mov [r15+0x100], rax
000074ad9b3ceeaa  jmp 0x000074AD9B1FE110
000074ad9b3ceeaf  cmp dword ptr [r15+0x318], 0x00
000074ad9b3ceeb7  jz 0x000074AD9B3CEF00
000074ad9b3ceebd  nop [rax+rax*1], ax
000074ad9b3ceec6  nop [rax+rax*1], eax
000074ad9b3ceece  mov eax, 0x4101E8
000074ad9b3ceed3  mov [r15+0x100], rax
000074ad9b3ceeda  jmp 0x000074AD9B1FE110
000074ad9b3ceedf  int3
000074ad9b3ceee0  call 0x000074AD9B20DC20
000074ad9b3ceee5  jmp 0x000074AD9B3CEE02
000074ad9b3ceeea  call 0x000074AD9B20B5E0
000074ad9b3ceeef  jmp 0x000074AD9B3CEE0E
000074ad9b3ceef4  call 0x000074AD9B2A3D90
000074ad9b3ceef9  jmp 0x000074AD9B3CEE17
000074ad9b3ceefe  int3
000074ad9b3ceeff  nop
000074ad9b3cef00  mov rax, [r15+0x98]
000074ad9b3cef07  mov r14, [r15+0x58]
000074ad9b3cef0b  mov [rsp+0x10], r14
000074ad9b3cef10  shl r14, 0x02
000074ad9b3cef14  lea r12, [rax+r14*1]
000074ad9b3cef18  mov eax, [r13+r12*1]
000074ad9b3cef1d  lea r14, [r12+0x04]
000074ad9b3cef22  mov r12d, [r13+r14*1]
000074ad9b3cef27  mov eax, eax
000074ad9b3cef29  mov [r15+0x68], rax
000074ad9b3cef2d  mov r12d, r12d
000074ad9b3cef30  mov [r15+0x60], r12
000074ad9b3cef34  mov rax, [r15+0x68]
000074ad9b3cef38  mov [rsp+0x20], rax
000074ad9b3cef3d  mov r14, [rsp+0x10]
000074ad9b3cef42  imul rax, r14
000074ad9b3cef46  mov r12, [rsp+0x20]
000074ad9b3cef4b  lea r11, [r12+rax*1]
000074ad9b3cef4f  mov [r15+0x68], r11
000074ad9b3cef53  lea rax, [r14+0x02]
000074ad9b3cef57  mov [r15+0x58], rax
000074ad9b3cef5b  mov [rsp+0x10], rax
000074ad9b3cef60  xor eax, eax
000074ad9b3cef62  mov r14, [rsp+0x10]
000074ad9b3cef67  mov r12d, 0x400
000074ad9b3cef6d  cmp r14, r12
000074ad9b3cef70  cmc
000074ad9b3cef71  lahf
000074ad9b3cef72  seto al
000074ad9b3cef75  mov [r15+0x108], eax
000074ad9b3cef7c  mov rax, [r15+0x50]
000074ad9b3cef80  mov r12, [r15+0x60]
000074ad9b3cef84  imul r14, r12
000074ad9b3cef88  lea r12, [rax+r14*1]
000074ad9b3cef8c  mov [r15+0x50], r12
000074ad9b3cef90  mov rax, [r15+0x48]
000074ad9b3cef94  lea r14, [r11+rax*1]
000074ad9b3cef98  mov [r15+0x48], r14
000074ad9b3cef9c  mov eax, [r15+0x108]
000074ad9b3cefa3  sahf
000074ad9b3cefa4  jnz 0x000074AD9B3CEFD6
000074ad9b3cefa6  cmp dword ptr [r15+0x318], 0x00
000074ad9b3cefae  jz 0x000074AD9B3CF020
000074ad9b3cefb4  nop [rax+rax*1], ax
000074ad9b3cefbd  nop [rax+rax*1], eax
000074ad9b3cefc5  mov eax, 0x410208
000074ad9b3cefca  mov [r15+0x100], rax
000074ad9b3cefd1  jmp 0x000074AD9B1FE110
000074ad9b3cefd6  cmp dword ptr [r15+0x318], 0x00
000074ad9b3cefde  jz 0x000074AD9B3CEF00
000074ad9b3cefe4  nop [rax+rax*1], ax
000074ad9b3cefed  nop [rax+rax*1], eax
000074ad9b3ceff5  mov eax, 0x4101E8
000074ad9b3ceffa  mov [r15+0x100], rax
000074ad9b3cf001  jmp 0x000074AD9B1FE110
000074ad9b3cf006  int3
000074ad9b3cf007  call 0x000074AD9B2B4690
000074ad9b3cf00c  jmp 0x000074AD9B3CEF1D
000074ad9b3cf011  call 0x000074AD9B2E26A0
000074ad9b3cf016  jmp 0x000074AD9B3CEF27
000074ad9b3cf01b  int3
000074ad9b3cf01c  nop [rax], eax
000074ad9b3cf020  mov rax, [r15+0xF8]
000074ad9b3cf027  lea r14, [rax+0x10]
000074ad9b3cf02b  mov r12, [r13+r14*1]
000074ad9b3cf030  lea r14, [rax+0x18]
000074ad9b3cf034  mov r11, [r13+r14*1]
000074ad9b3cf039  mov [r15+0xA0], r12
000074ad9b3cf040  mov [r15+0x98], r11
000074ad9b3cf047  mov r14, [r15+0x50]
000074ad9b3cf04b  mov r12, [r15+0x48]
000074ad9b3cf04f  lea r11, [r14+r12*1]
000074ad9b3cf053  mov [r15+0x48], r11
000074ad9b3cf057  mov r14, [r15+0x40]
000074ad9b3cf05b  lea r12, [r14+0x288]
000074ad9b3cf062  mov [r13+r12*1], r11
000074ad9b3cf067  mov r14, [r13+rax*1]
000074ad9b3cf06c  mov [r15+0xF0], r14
000074ad9b3cf073  lea r12, [rax+0x20]
000074ad9b3cf077  mov [r15+0xF8], r12
000074ad9b3cf07e  mov [r15+0x100], r14
000074ad9b3cf085  jmp 0x000074AD9B3CE5C0
000074ad9b3cf08a  int3
000074ad9b3cf08b  call 0x000074AD9B2E27E0
000074ad9b3cf090  jmp 0x000074AD9B3CF030
000074ad9b3cf095  call 0x000074AD9B2E1570
000074ad9b3cf09a  jmp 0x000074AD9B3CF039
000074ad9b3cf09f  call 0x000074AD9B2C0860
000074ad9b3cf0a4  jmp 0x000074AD9B3CF067
000074ad9b3cf0a9  call 0x000074AD9B20DC20
000074ad9b3cf0ae  jmp 0x000074AD9B3CF06C
000074ad9b3cf0b3  int3
000074ad9b3cf0b4  nop [rax+rax*1], ax
000074ad9b3cf0bd  nop [rax], eax
000074ad9b3cf0c0  mov qword ptr [r15+0x100], 0x04
000074ad9b3cf0cb  mov esi, 0x00
000074ad9b3cf0d0  mov edx, 0x09
000074ad9b3cf0d5  mov rdi, 0x7FFD2D17ED70
000074ad9b3cf0df  mov rax, 0x5561D3BCB970
000074ad9b3cf0e9  call rax
000074ad9b3cf0eb  cmp dword ptr [r15+0x318], 0x00
000074ad9b3cf0f3  jnz 0x000074AD9B1FE110
000074ad9b3cf0f9  jmp 0x000074AD9B1FE0A0
000074ad9b3cf0fe  int3
000074ad9b3cf0ff  int3
