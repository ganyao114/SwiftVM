
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sort/swiftvm/0/2.bin:     file format binary


Disassembly of section .data:

00007c458b4fe2b0 <.data>:
    7c458b4fe2b0:	sub    rsp,0x10
    7c458b4fe2b4:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4fe2bc:	mov    QWORD PTR [rsp],r11
    7c458b4fe2c0:	mov    r13,QWORD PTR [r12+0xa0]
    7c458b4fe2c8:	mov    r14,r13
    7c458b4fe2cb:	shl    r14,0x2
    7c458b4fe2cf:	mov    r15,QWORD PTR [r12+0x98]
    7c458b4fe2d7:	add    r15,r14
    7c458b4fe2da:	mov    r14d,DWORD PTR [r12]
    7c458b4fe2de:	mov    DWORD PTR [r15],r14d
    7c458b4fe2e1:	mov    r14d,0x0
    7c458b4fe2e7:	mov    DWORD PTR [r12+0x32c],r14d
    7c458b4fe2ef:	add    r13,0x1
    7c458b4fe2f3:	mov    QWORD PTR [r12+0xa0],r13
    7c458b4fe2fb:	sub    r13,0x400
    7c458b4fe302:	mov    rcx,QWORD PTR [r12+0x380]
    7c458b4fe30a:	jrcxz  0x7c458b4fe311
    7c458b4fe30c:	jmp    0x7c458b4fe6f5
    7c458b4fe311:	jne    0x7c458b4fe32a
    7c458b4fe317:	mov    r11,rax
    7c458b4fe31a:	lahf
    7c458b4fe31b:	seto   al
    7c458b4fe31e:	mov    WORD PTR [rsp],ax
    7c458b4fe322:	mov    rax,r11
    7c458b4fe325:	jmp    0x7c458b4fe33d
    7c458b4fe32a:	mov    r11,rax
    7c458b4fe32d:	lahf
    7c458b4fe32e:	seto   al
    7c458b4fe331:	mov    WORD PTR [rsp],ax
    7c458b4fe335:	mov    rax,r11
    7c458b4fe338:	jmp    0x7c458b4fe683
    7c458b4fe33d:	mov    r13d,0x1
    7c458b4fe343:	mov    QWORD PTR [r12+0x40],r13
    7c458b4fe348:	mov    r11,rax
    7c458b4fe34b:	movzx  eax,WORD PTR [rsp]
    7c458b4fe34f:	add    al,0x7f
    7c458b4fe351:	sahf
    7c458b4fe352:	mov    rax,r11
    7c458b4fe355:	jmp    0x7c458b4fe35a
    7c458b4fe35a:	mov    r13,QWORD PTR [r12+0x40]
    7c458b4fe35f:	mov    r14,r13
    7c458b4fe362:	lea    r14,[r14*4+0x0]
    7c458b4fe36a:	mov    r15,QWORD PTR [r12+0x98]
    7c458b4fe372:	mov    r11,rax
    7c458b4fe375:	lahf
    7c458b4fe376:	seto   al
    7c458b4fe379:	mov    WORD PTR [rsp],ax
    7c458b4fe37d:	mov    rax,r11
    7c458b4fe380:	add    r15,r14
    7c458b4fe383:	mov    r14d,DWORD PTR [r15]
    7c458b4fe386:	mov    QWORD PTR [r12+0x48],r14
    7c458b4fe38b:	mov    r14d,0x0
    7c458b4fe391:	or     r14,r13
    7c458b4fe394:	mov    QWORD PTR [r12+0x50],r14
    7c458b4fe399:	jmp    0x7c458b4fe39e
    7c458b4fe39e:	mov    r13d,DWORD PTR [r12+0x50]
    7c458b4fe3a3:	sub    r13d,0x1
    7c458b4fe3a7:	mov    QWORD PTR [r12+0x58],r13
    7c458b4fe3ac:	mov    ecx,0xffffffff
    7c458b4fe3b1:	mov    r14,r13
    7c458b4fe3b4:	and    r14,rcx
    7c458b4fe3b7:	shl    r14,0x2
    7c458b4fe3bb:	mov    r13,QWORD PTR [r12+0x98]
    7c458b4fe3c3:	add    r13,r14
    7c458b4fe3c6:	mov    r14d,DWORD PTR [r13+0x0]
    7c458b4fe3ca:	mov    QWORD PTR [r12+0x60],r14
    7c458b4fe3cf:	mov    r13d,DWORD PTR [r12+0x48]
    7c458b4fe3d4:	sub    r14d,r13d
    7c458b4fe3d7:	mov    rcx,QWORD PTR [r12+0x380]
    7c458b4fe3df:	jrcxz  0x7c458b4fe3e6
    7c458b4fe3e1:	jmp    0x7c458b4fe786
    7c458b4fe3e6:	jbe    0x7c458b4fe3ff
    7c458b4fe3ec:	mov    r11,rax
    7c458b4fe3ef:	lahf
    7c458b4fe3f0:	seto   al
    7c458b4fe3f3:	mov    WORD PTR [rsp],ax
    7c458b4fe3f7:	mov    rax,r11
    7c458b4fe3fa:	jmp    0x7c458b4fe412
    7c458b4fe3ff:	mov    r11,rax
    7c458b4fe402:	lahf
    7c458b4fe403:	seto   al
    7c458b4fe406:	mov    WORD PTR [rsp],ax
    7c458b4fe40a:	mov    rax,r11
    7c458b4fe40d:	jmp    0x7c458b4fe491
    7c458b4fe412:	mov    r13,QWORD PTR [r12+0x50]
    7c458b4fe417:	mov    r14,r13
    7c458b4fe41a:	shl    r14,0x2
    7c458b4fe41e:	mov    r15,QWORD PTR [r12+0x98]
    7c458b4fe426:	add    r15,r14
    7c458b4fe429:	mov    r14d,DWORD PTR [r12+0x60]
    7c458b4fe42e:	mov    DWORD PTR [r15],r14d
    7c458b4fe431:	mov    r14d,0x0
    7c458b4fe437:	mov    DWORD PTR [r12+0x32c],r14d
    7c458b4fe43f:	sub    r13,0x1
    7c458b4fe443:	mov    QWORD PTR [r12+0x50],r13
    7c458b4fe448:	mov    rcx,QWORD PTR [r12+0x380]
    7c458b4fe450:	jrcxz  0x7c458b4fe457
    7c458b4fe452:	jmp    0x7c458b4fe817
    7c458b4fe457:	mov    r13,QWORD PTR [r12+0x58]
    7c458b4fe45c:	mov    rax,r13
    7c458b4fe45f:	test   rax,rax
    7c458b4fe462:	jne    0x7c458b4fe39e
    7c458b4fe468:	jmp    0x7c458b4fe46d
    7c458b4fe46d:	mov    rcx,QWORD PTR [r12+0x380]
    7c458b4fe475:	jrcxz  0x7c458b4fe47c
    7c458b4fe477:	jmp    0x7c458b4fe899
    7c458b4fe47c:	jmp    0x7c458b4fe481
    7c458b4fe481:	mov    r13d,0x0
    7c458b4fe487:	mov    QWORD PTR [r12+0x50],r13
    7c458b4fe48c:	jmp    0x7c458b4fe491
    7c458b4fe491:	mov    r13,QWORD PTR [r12+0x40]
    7c458b4fe496:	add    r13,0x1
    7c458b4fe49a:	mov    QWORD PTR [r12+0x40],r13
    7c458b4fe49f:	mov    r14,QWORD PTR [r12+0x50]
    7c458b4fe4a4:	mov    ecx,0xffffffff
    7c458b4fe4a9:	and    r14,rcx
    7c458b4fe4ac:	shl    r14,0x2
    7c458b4fe4b0:	mov    r15,QWORD PTR [r12+0x98]
    7c458b4fe4b8:	add    r15,r14
    7c458b4fe4bb:	mov    r14d,DWORD PTR [r12+0x48]
    7c458b4fe4c0:	mov    DWORD PTR [r15],r14d
    7c458b4fe4c3:	mov    r14d,0x0
    7c458b4fe4c9:	mov    DWORD PTR [r12+0x32c],r14d
    7c458b4fe4d1:	sub    r13,0x400
    7c458b4fe4d8:	jne    0x7c458b4fe35a
    7c458b4fe4de:	mov    r11,rax
    7c458b4fe4e1:	lahf
    7c458b4fe4e2:	seto   al
    7c458b4fe4e5:	mov    WORD PTR [rsp],ax
    7c458b4fe4e9:	mov    rax,r11
    7c458b4fe4ec:	jmp    0x7c458b4fe4f1
    7c458b4fe4f1:	mov    r13d,0x420000
    7c458b4fe4f7:	mov    QWORD PTR [r12+0x40],r13
    7c458b4fe4fc:	mov    r13d,0x0
    7c458b4fe502:	mov    QWORD PTR [r12+0x58],r13
    7c458b4fe507:	mov    r13d,0x0
    7c458b4fe50d:	mov    QWORD PTR [r12+0x50],r13
    7c458b4fe512:	mov    r13d,0x420288
    7c458b4fe518:	mov    r14,QWORD PTR [r13+0x0]
    7c458b4fe51c:	mov    QWORD PTR [r12+0x48],r14
    7c458b4fe521:	jmp    0x7c458b4fe526
    7c458b4fe526:	mov    r13,QWORD PTR [r12+0x58]
    7c458b4fe52b:	mov    r14,r13
    7c458b4fe52e:	shl    r14,0x2
    7c458b4fe532:	mov    r15,QWORD PTR [r12+0x98]
    7c458b4fe53a:	add    r15,r14
    7c458b4fe53d:	mov    QWORD PTR [r12+0x60],r15
    7c458b4fe542:	mov    r14,r15
    7c458b4fe545:	add    r14,0x4
    7c458b4fe549:	mov    ebp,DWORD PTR [r15]
    7c458b4fe54c:	mov    r15d,DWORD PTR [r14]
    7c458b4fe54f:	mov    QWORD PTR [r12+0x60],r15
    7c458b4fe554:	mov    r14,rbp
    7c458b4fe557:	imul   r14,r13
    7c458b4fe55b:	mov    r8,rbp
    7c458b4fe55e:	add    r8,r14
    7c458b4fe561:	mov    QWORD PTR [r12+0x68],r8
    7c458b4fe566:	add    r13,0x2
    7c458b4fe56a:	mov    QWORD PTR [r12+0x58],r13
    7c458b4fe56f:	mov    r14,r13
    7c458b4fe572:	sub    r14,0x400
    7c458b4fe579:	mov    r14,QWORD PTR [r12+0x50]
    7c458b4fe57e:	setne  BYTE PTR [rsp+0x8]
    7c458b4fe583:	mov    r11,rax
    7c458b4fe586:	lahf
    7c458b4fe587:	seto   al
    7c458b4fe58a:	mov    WORD PTR [rsp],ax
    7c458b4fe58e:	mov    rax,r11
    7c458b4fe591:	imul   r13,r15
    7c458b4fe595:	add    r14,r13
    7c458b4fe598:	mov    QWORD PTR [r12+0x50],r14
    7c458b4fe59d:	mov    r13,QWORD PTR [r12+0x48]
    7c458b4fe5a2:	add    r8,r13
    7c458b4fe5a5:	mov    QWORD PTR [r12+0x48],r8
    7c458b4fe5aa:	mov    rcx,QWORD PTR [r12+0x380]
    7c458b4fe5b2:	jrcxz  0x7c458b4fe5b9
    7c458b4fe5b4:	jmp    0x7c458b4fe91b
    7c458b4fe5b9:	cmp    BYTE PTR [rsp+0x8],0x0
    7c458b4fe5be:	jne    0x7c458b4fe526
    7c458b4fe5c4:	jmp    0x7c458b4fe5c9
    7c458b4fe5c9:	mov    r13,QWORD PTR [r12+0xf8]
    7c458b4fe5d1:	mov    r14,r13
    7c458b4fe5d4:	add    r14,0x10
    7c458b4fe5d8:	mov    r15,r14
    7c458b4fe5db:	add    r15,0x8
    7c458b4fe5df:	mov    rbp,QWORD PTR [r14]
    7c458b4fe5e2:	mov    r14,QWORD PTR [r15]
    7c458b4fe5e5:	mov    QWORD PTR [r12+0xa0],rbp
    7c458b4fe5ed:	mov    QWORD PTR [r12+0x98],r14
    7c458b4fe5f5:	mov    r14,QWORD PTR [r12+0x48]
    7c458b4fe5fa:	mov    r15,QWORD PTR [r12+0x50]
    7c458b4fe5ff:	add    r15,r14
    7c458b4fe602:	mov    QWORD PTR [r12+0x48],r15
    7c458b4fe607:	mov    r14,QWORD PTR [r12+0x40]
    7c458b4fe60c:	add    r14,0x288
    7c458b4fe613:	mov    QWORD PTR [r14],r15
    7c458b4fe616:	mov    r14d,0x0
    7c458b4fe61c:	mov    DWORD PTR [r12+0x32c],r14d
    7c458b4fe624:	mov    r14,r13
    7c458b4fe627:	add    r14,0x20
    7c458b4fe62b:	mov    r15,QWORD PTR [r13+0x0]
    7c458b4fe62f:	mov    QWORD PTR [r12+0xf0],r15
    7c458b4fe637:	mov    QWORD PTR [r12+0xf8],r14
    7c458b4fe63f:	mov    rcx,QWORD PTR [r12+0x380]
    7c458b4fe647:	jrcxz  0x7c458b4fe64e
    7c458b4fe649:	jmp    0x7c458b4fe99d
    7c458b4fe64e:	mov    r13,QWORD PTR [r12+0xf0]
    7c458b4fe656:	mov    QWORD PTR [r12+0x100],r13
    7c458b4fe65e:	mov    r11,QWORD PTR [rsp]
    7c458b4fe662:	mov    QWORD PTR [r12+0x398],r11
    7c458b4fe66a:	mov    rdi,QWORD PTR [r12+0x100]
    7c458b4fe672:	add    rsp,0x10
    7c458b4fe676:	movabs r11,0x5c8c5e619940
    7c458b4fe680:	jmp    r11
    7c458b4fe683:	mov    r13d,DWORD PTR [r12+0xa0]
    7c458b4fe68b:	add    r13d,0x11
    7c458b4fe68f:	mov    QWORD PTR [r12],r13
    7c458b4fe693:	mov    r13d,0x410184
    7c458b4fe699:	mov    QWORD PTR [r12+0xf0],r13
    7c458b4fe6a1:	mov    r13d,0x41021c
    7c458b4fe6a7:	mov    QWORD PTR [r12+0x100],r13
    7c458b4fe6af:	mov    r11,QWORD PTR [rsp]
    7c458b4fe6b3:	mov    QWORD PTR [r12+0x398],r11
    7c458b4fe6bb:	mov    edi,0x41021c
    7c458b4fe6c0:	mov    QWORD PTR [r12+0x100],rdi
    7c458b4fe6c8:	add    rsp,0x10
    7c458b4fe6cc:	nop    DWORD PTR [rax+0x0]
    7c458b4fe6d0:	jmp    QWORD PTR [rip+0x2]        # 0x7c458b4fe6d8
    7c458b4fe6d6:	xchg   ax,ax
    7c458b4fe6d8:	lock loopne 0x7c458b4fe72a
    7c458b4fe6db:	mov    eax,DWORD PTR [rbp+0x7c]
    7c458b4fe6de:	add    BYTE PTR [rax],al
    7c458b4fe6e0:	call   0x7c45d0db36cb
    7c458b4fe6e5:	jl     0x7c458b4fe6e7
    7c458b4fe6e7:	add    BYTE PTR [rcx-0x45],cl
    7c458b4fe6ea:	rex cdq
    7c458b4fe6ec:	(bad)
    7c458b4fe6ed:	pop    rsi
    7c458b4fe6ee:	mov    WORD PTR [rax+rax*1+0x0],ds
    7c458b4fe6f2:	jmp    r11
    7c458b4fe6f5:	mov    eax,0x410190
    7c458b4fe6fa:	mov    QWORD PTR [r12+0x100],rax
    7c458b4fe702:	push   rdx
    7c458b4fe703:	push   rsi
    7c458b4fe704:	push   r10
    7c458b4fe706:	push   r11
    7c458b4fe708:	mov    r11,rax
    7c458b4fe70b:	lahf
    7c458b4fe70c:	seto   al
    7c458b4fe70f:	mov    WORD PTR [rsp+0x20],ax
    7c458b4fe714:	mov    rax,r11
    7c458b4fe717:	mov    rdx,QWORD PTR [rsp+0x20]
    7c458b4fe71c:	mov    r10d,edx
    7c458b4fe71f:	and    r10d,0xc000
    7c458b4fe726:	shl    r10d,0x10
    7c458b4fe72a:	mov    r11d,edx
    7c458b4fe72d:	and    r11d,0x100
    7c458b4fe734:	shl    r11d,0x15
    7c458b4fe738:	or     r10d,r11d
    7c458b4fe73b:	and    edx,0x1
    7c458b4fe73e:	shl    edx,0x1c
    7c458b4fe741:	or     r10d,edx
    7c458b4fe744:	btc    r10,0x1d
    7c458b4fe749:	mov    r11d,0xf0000000
    7c458b4fe74f:	and    r11,r10
    7c458b4fe752:	movabs rsi,0xffffffff0fffffff
    7c458b4fe75c:	and    rbx,rsi
    7c458b4fe75f:	or     rbx,r11
    7c458b4fe762:	pop    r11
    7c458b4fe764:	pop    r10
    7c458b4fe766:	pop    rsi
    7c458b4fe767:	pop    rdx
    7c458b4fe768:	mov    QWORD PTR [r12+0x108],rbx
    7c458b4fe770:	add    rsp,0x10
    7c458b4fe774:	mov    eax,0xc
    7c458b4fe779:	movabs r11,0x5c8c5e619ca0
    7c458b4fe783:	jmp    r11
    7c458b4fe786:	mov    eax,0x4101c4
    7c458b4fe78b:	mov    QWORD PTR [r12+0x100],rax
    7c458b4fe793:	push   rdx
    7c458b4fe794:	push   rsi
    7c458b4fe795:	push   r10
    7c458b4fe797:	push   r11
    7c458b4fe799:	mov    r11,rax
    7c458b4fe79c:	lahf
    7c458b4fe79d:	seto   al
    7c458b4fe7a0:	mov    WORD PTR [rsp+0x20],ax
    7c458b4fe7a5:	mov    rax,r11
    7c458b4fe7a8:	mov    rdx,QWORD PTR [rsp+0x20]
    7c458b4fe7ad:	mov    r10d,edx
    7c458b4fe7b0:	and    r10d,0xc000
    7c458b4fe7b7:	shl    r10d,0x10
    7c458b4fe7bb:	mov    r11d,edx
    7c458b4fe7be:	and    r11d,0x100
    7c458b4fe7c5:	shl    r11d,0x15
    7c458b4fe7c9:	or     r10d,r11d
    7c458b4fe7cc:	and    edx,0x1
    7c458b4fe7cf:	shl    edx,0x1c
    7c458b4fe7d2:	or     r10d,edx
    7c458b4fe7d5:	btc    r10,0x1d
    7c458b4fe7da:	mov    r11d,0xf0000000
    7c458b4fe7e0:	and    r11,r10
    7c458b4fe7e3:	movabs rsi,0xffffffff0fffffff
    7c458b4fe7ed:	and    rbx,rsi
    7c458b4fe7f0:	or     rbx,r11
    7c458b4fe7f3:	pop    r11
    7c458b4fe7f5:	pop    r10
    7c458b4fe7f7:	pop    rsi
    7c458b4fe7f8:	pop    rdx
    7c458b4fe7f9:	mov    QWORD PTR [r12+0x108],rbx
    7c458b4fe801:	add    rsp,0x10
    7c458b4fe805:	mov    eax,0xc
    7c458b4fe80a:	movabs r11,0x5c8c5e619ca0
    7c458b4fe814:	jmp    r11
    7c458b4fe817:	mov    eax,0x4101d0
    7c458b4fe81c:	mov    QWORD PTR [r12+0x100],rax
    7c458b4fe824:	push   rdx
    7c458b4fe825:	push   rsi
    7c458b4fe826:	push   r10
    7c458b4fe828:	push   r11
    7c458b4fe82a:	mov    rdx,QWORD PTR [rsp+0x20]
    7c458b4fe82f:	mov    r10d,edx
    7c458b4fe832:	and    r10d,0xc000
    7c458b4fe839:	shl    r10d,0x10
    7c458b4fe83d:	mov    r11d,edx
    7c458b4fe840:	and    r11d,0x100
    7c458b4fe847:	shl    r11d,0x15
    7c458b4fe84b:	or     r10d,r11d
    7c458b4fe84e:	and    edx,0x1
    7c458b4fe851:	shl    edx,0x1c
    7c458b4fe854:	or     r10d,edx
    7c458b4fe857:	btc    r10,0x1d
    7c458b4fe85c:	mov    r11d,0xf0000000
    7c458b4fe862:	and    r11,r10
    7c458b4fe865:	movabs rsi,0xffffffff0fffffff
    7c458b4fe86f:	and    rbx,rsi
    7c458b4fe872:	or     rbx,r11
    7c458b4fe875:	pop    r11
    7c458b4fe877:	pop    r10
    7c458b4fe879:	pop    rsi
    7c458b4fe87a:	pop    rdx
    7c458b4fe87b:	mov    QWORD PTR [r12+0x108],rbx
    7c458b4fe883:	add    rsp,0x10
    7c458b4fe887:	mov    eax,0xc
    7c458b4fe88c:	movabs r11,0x5c8c5e619ca0
    7c458b4fe896:	jmp    r11
    7c458b4fe899:	mov    eax,0x4101d4
    7c458b4fe89e:	mov    QWORD PTR [r12+0x100],rax
    7c458b4fe8a6:	push   rdx
    7c458b4fe8a7:	push   rsi
    7c458b4fe8a8:	push   r10
    7c458b4fe8aa:	push   r11
    7c458b4fe8ac:	mov    rdx,QWORD PTR [rsp+0x20]
    7c458b4fe8b1:	mov    r10d,edx
    7c458b4fe8b4:	and    r10d,0xc000
    7c458b4fe8bb:	shl    r10d,0x10
    7c458b4fe8bf:	mov    r11d,edx
    7c458b4fe8c2:	and    r11d,0x100
    7c458b4fe8c9:	shl    r11d,0x15
    7c458b4fe8cd:	or     r10d,r11d
    7c458b4fe8d0:	and    edx,0x1
    7c458b4fe8d3:	shl    edx,0x1c
    7c458b4fe8d6:	or     r10d,edx
    7c458b4fe8d9:	btc    r10,0x1d
    7c458b4fe8de:	mov    r11d,0xf0000000
    7c458b4fe8e4:	and    r11,r10
    7c458b4fe8e7:	movabs rsi,0xffffffff0fffffff
    7c458b4fe8f1:	and    rbx,rsi
    7c458b4fe8f4:	or     rbx,r11
    7c458b4fe8f7:	pop    r11
    7c458b4fe8f9:	pop    r10
    7c458b4fe8fb:	pop    rsi
    7c458b4fe8fc:	pop    rdx
    7c458b4fe8fd:	mov    QWORD PTR [r12+0x108],rbx
    7c458b4fe905:	add    rsp,0x10
    7c458b4fe909:	mov    eax,0xc
    7c458b4fe90e:	movabs r11,0x5c8c5e619ca0
    7c458b4fe918:	jmp    r11
    7c458b4fe91b:	mov    eax,0x410204
    7c458b4fe920:	mov    QWORD PTR [r12+0x100],rax
    7c458b4fe928:	push   rdx
    7c458b4fe929:	push   rsi
    7c458b4fe92a:	push   r10
    7c458b4fe92c:	push   r11
    7c458b4fe92e:	mov    rdx,QWORD PTR [rsp+0x20]
    7c458b4fe933:	mov    r10d,edx
    7c458b4fe936:	and    r10d,0xc000
    7c458b4fe93d:	shl    r10d,0x10
    7c458b4fe941:	mov    r11d,edx
    7c458b4fe944:	and    r11d,0x100
    7c458b4fe94b:	shl    r11d,0x15
    7c458b4fe94f:	or     r10d,r11d
    7c458b4fe952:	and    edx,0x1
    7c458b4fe955:	shl    edx,0x1c
    7c458b4fe958:	or     r10d,edx
    7c458b4fe95b:	btc    r10,0x1d
    7c458b4fe960:	mov    r11d,0xf0000000
    7c458b4fe966:	and    r11,r10
    7c458b4fe969:	movabs rsi,0xffffffff0fffffff
    7c458b4fe973:	and    rbx,rsi
    7c458b4fe976:	or     rbx,r11
    7c458b4fe979:	pop    r11
    7c458b4fe97b:	pop    r10
    7c458b4fe97d:	pop    rsi
    7c458b4fe97e:	pop    rdx
    7c458b4fe97f:	mov    QWORD PTR [r12+0x108],rbx
    7c458b4fe987:	add    rsp,0x10
    7c458b4fe98b:	mov    eax,0xc
    7c458b4fe990:	movabs r11,0x5c8c5e619ca0
    7c458b4fe99a:	jmp    r11
    7c458b4fe99d:	mov    eax,0x410218
    7c458b4fe9a2:	mov    QWORD PTR [r12+0x100],rax
    7c458b4fe9aa:	push   rdx
    7c458b4fe9ab:	push   rsi
    7c458b4fe9ac:	push   r10
    7c458b4fe9ae:	push   r11
    7c458b4fe9b0:	mov    rdx,QWORD PTR [rsp+0x20]
    7c458b4fe9b5:	mov    r10d,edx
    7c458b4fe9b8:	and    r10d,0xc000
    7c458b4fe9bf:	shl    r10d,0x10
    7c458b4fe9c3:	mov    r11d,edx
    7c458b4fe9c6:	and    r11d,0x100
    7c458b4fe9cd:	shl    r11d,0x15
    7c458b4fe9d1:	or     r10d,r11d
    7c458b4fe9d4:	and    edx,0x1
    7c458b4fe9d7:	shl    edx,0x1c
    7c458b4fe9da:	or     r10d,edx
    7c458b4fe9dd:	btc    r10,0x1d
    7c458b4fe9e2:	mov    r11d,0xf0000000
    7c458b4fe9e8:	and    r11,r10
    7c458b4fe9eb:	movabs rsi,0xffffffff0fffffff
    7c458b4fe9f5:	and    rbx,rsi
    7c458b4fe9f8:	or     rbx,r11
    7c458b4fe9fb:	pop    r11
    7c458b4fe9fd:	pop    r10
    7c458b4fe9ff:	pop    rsi
    7c458b4fea00:	pop    rdx
    7c458b4fea01:	mov    QWORD PTR [r12+0x108],rbx
    7c458b4fea09:	add    rsp,0x10
    7c458b4fea0d:	mov    eax,0xc
    7c458b4fea12:	movabs r11,0x5c8c5e619ca0
    7c458b4fea1c:	jmp    r11
    7c458b4fea1f:	nop
    7c458b4fea20:	sub    rsp,0x10
    7c458b4fea24:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4fea2c:	mov    QWORD PTR [rsp],r11
    7c458b4fea30:	jmp    0x7c458b4fe33d
    7c458b4fea35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c458b4fea40:	sub    rsp,0x10
    7c458b4fea44:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4fea4c:	mov    QWORD PTR [rsp],r11
    7c458b4fea50:	mov    r11,rax
    7c458b4fea53:	movzx  eax,WORD PTR [rsp]
    7c458b4fea57:	add    al,0x7f
    7c458b4fea59:	sahf
    7c458b4fea5a:	mov    rax,r11
    7c458b4fea5d:	jmp    0x7c458b4fe35a
    7c458b4fea62:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c458b4fea70:	sub    rsp,0x10
    7c458b4fea74:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4fea7c:	mov    QWORD PTR [rsp],r11
    7c458b4fea80:	jmp    0x7c458b4fe39e
    7c458b4fea85:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c458b4fea90:	sub    rsp,0x10
    7c458b4fea94:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4fea9c:	mov    QWORD PTR [rsp],r11
    7c458b4feaa0:	jmp    0x7c458b4fe412
    7c458b4feaa5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c458b4feab0:	sub    rsp,0x10
    7c458b4feab4:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4feabc:	mov    QWORD PTR [rsp],r11
    7c458b4feac0:	jmp    0x7c458b4fe46d
    7c458b4feac5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c458b4fead0:	sub    rsp,0x10
    7c458b4fead4:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4feadc:	mov    QWORD PTR [rsp],r11
    7c458b4feae0:	jmp    0x7c458b4fe481
    7c458b4feae5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c458b4feaf0:	sub    rsp,0x10
    7c458b4feaf4:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4feafc:	mov    QWORD PTR [rsp],r11
    7c458b4feb00:	jmp    0x7c458b4fe491
    7c458b4feb05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c458b4feb10:	sub    rsp,0x10
    7c458b4feb14:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4feb1c:	mov    QWORD PTR [rsp],r11
    7c458b4feb20:	jmp    0x7c458b4fe4f1
    7c458b4feb25:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c458b4feb30:	sub    rsp,0x10
    7c458b4feb34:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4feb3c:	mov    QWORD PTR [rsp],r11
    7c458b4feb40:	jmp    0x7c458b4fe526
    7c458b4feb45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c458b4feb50:	sub    rsp,0x10
    7c458b4feb54:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4feb5c:	mov    QWORD PTR [rsp],r11
    7c458b4feb60:	jmp    0x7c458b4fe5c9
    7c458b4feb65:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c458b4feb70:	sub    rsp,0x10
    7c458b4feb74:	mov    r11,QWORD PTR [r12+0x398]
    7c458b4feb7c:	mov    QWORD PTR [rsp],r11
    7c458b4feb80:	jmp    0x7c458b4fe683
    7c458b4feb85:	nop
    7c458b4feb86:	nop
    7c458b4feb87:	nop
