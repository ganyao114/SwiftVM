
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-sort/swiftvm/1/1.bin:     file format binary


Disassembly of section .data:

000076bba08fe0f0 <.data>:
    76bba08fe0f0:	sub    rsp,0x10
    76bba08fe0f4:	mov    r11,QWORD PTR [r12+0x398]
    76bba08fe0fc:	mov    QWORD PTR [rsp],r11
    76bba08fe100:	mov    r13d,0x352d
    76bba08fe106:	mov    QWORD PTR [r12+0x40],r13
    76bba08fe10b:	mov    r13d,0xa68b
    76bba08fe111:	mov    QWORD PTR [r12+0x48],r13
    76bba08fe116:	mov    r13d,0x352d
    76bba08fe11c:	mov    r14d,0x7feb
    76bba08fe122:	and    r14d,0xffff
    76bba08fe129:	mov    rax,r13
    76bba08fe12c:	movabs rcx,0xffffffff0000ffff
    76bba08fe136:	and    rax,rcx
    76bba08fe139:	mov    rdx,r14
    76bba08fe13c:	shl    rdx,0x10
    76bba08fe140:	mov    ecx,0xffff0000
    76bba08fe145:	and    rdx,rcx
    76bba08fe148:	or     rax,rdx
    76bba08fe14b:	mov    r15d,eax
    76bba08fe14e:	mov    QWORD PTR [r12+0x40],r15
    76bba08fe153:	mov    r13d,0xa68b
    76bba08fe159:	mov    r14d,0x846c
    76bba08fe15f:	and    r14d,0xffff
    76bba08fe166:	mov    rax,r13
    76bba08fe169:	movabs rcx,0xffffffff0000ffff
    76bba08fe173:	and    rax,rcx
    76bba08fe176:	mov    rdx,r14
    76bba08fe179:	shl    rdx,0x10
    76bba08fe17d:	mov    ecx,0xffff0000
    76bba08fe182:	and    rdx,rcx
    76bba08fe185:	or     rax,rdx
    76bba08fe188:	mov    ebp,eax
    76bba08fe18a:	mov    QWORD PTR [r12+0x48],rbp
    76bba08fe18f:	mov    r13d,DWORD PTR [r12]
    76bba08fe193:	mov    r14d,0x0
    76bba08fe199:	imul   r13d,r15d
    76bba08fe19d:	mov    r15d,r14d
    76bba08fe1a0:	add    r15d,r13d
    76bba08fe1a3:	mov    QWORD PTR [r12+0x40],r15
    76bba08fe1a8:	mov    r13d,r15d
    76bba08fe1ab:	mov    r13d,r13d
    76bba08fe1ae:	shr    r13d,0xf
    76bba08fe1b2:	xor    r15d,r13d
    76bba08fe1b5:	mov    QWORD PTR [r12+0x40],r15
    76bba08fe1ba:	mov    r13d,0x0
    76bba08fe1c0:	imul   r15d,ebp
    76bba08fe1c4:	mov    r14d,r13d
    76bba08fe1c7:	add    r14d,r15d
    76bba08fe1ca:	mov    QWORD PTR [r12+0x40],r14
    76bba08fe1cf:	mov    r13d,r14d
    76bba08fe1d2:	mov    r13d,r13d
    76bba08fe1d5:	shr    r13d,0x10
    76bba08fe1d9:	xor    r14d,r13d
    76bba08fe1dc:	mov    QWORD PTR [r12],r14
    76bba08fe1e0:	mov    rcx,QWORD PTR [r12+0x380]
    76bba08fe1e8:	jrcxz  0x76bba08fe1ef
    76bba08fe1ea:	jmp    0x76bba08fe224
    76bba08fe1ef:	mov    r13,QWORD PTR [r12+0xf0]
    76bba08fe1f7:	mov    QWORD PTR [r12+0x100],r13
    76bba08fe1ff:	mov    r11,QWORD PTR [rsp]
    76bba08fe203:	mov    QWORD PTR [r12+0x398],r11
    76bba08fe20b:	mov    rdi,QWORD PTR [r12+0x100]
    76bba08fe213:	add    rsp,0x10
    76bba08fe217:	movabs r11,0x590cad6b0940
    76bba08fe221:	jmp    r11
    76bba08fe224:	mov    eax,0x41023c
    76bba08fe229:	mov    QWORD PTR [r12+0x100],rax
    76bba08fe231:	push   rdx
    76bba08fe232:	push   rsi
    76bba08fe233:	push   r10
    76bba08fe235:	push   r11
    76bba08fe237:	mov    rdx,QWORD PTR [rsp+0x20]
    76bba08fe23c:	mov    r10d,edx
    76bba08fe23f:	and    r10d,0xc000
    76bba08fe246:	shl    r10d,0x10
    76bba08fe24a:	mov    r11d,edx
    76bba08fe24d:	and    r11d,0x100
    76bba08fe254:	shl    r11d,0x15
    76bba08fe258:	or     r10d,r11d
    76bba08fe25b:	and    edx,0x1
    76bba08fe25e:	shl    edx,0x1c
    76bba08fe261:	or     r10d,edx
    76bba08fe264:	btc    r10,0x1d
    76bba08fe269:	mov    r11d,0xf0000000
    76bba08fe26f:	and    r11,r10
    76bba08fe272:	movabs rsi,0xffffffff0fffffff
    76bba08fe27c:	and    rbx,rsi
    76bba08fe27f:	or     rbx,r11
    76bba08fe282:	pop    r11
    76bba08fe284:	pop    r10
    76bba08fe286:	pop    rsi
    76bba08fe287:	pop    rdx
    76bba08fe288:	mov    QWORD PTR [r12+0x108],rbx
    76bba08fe290:	add    rsp,0x10
    76bba08fe294:	mov    eax,0xc
    76bba08fe299:	movabs r11,0x590cad6b0ca0
    76bba08fe2a3:	jmp    r11
    76bba08fe2a6:	nop
    76bba08fe2a7:	nop
