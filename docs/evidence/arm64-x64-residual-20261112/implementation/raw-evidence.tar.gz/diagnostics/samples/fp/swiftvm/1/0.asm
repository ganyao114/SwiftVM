
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/fp/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

000075a0ec900000 <.data>:
    75a0ec900000:	sub    rsp,0x150
    75a0ec900007:	mov    r11,QWORD PTR [r12+0x398]
    75a0ec90000f:	mov    QWORD PTR [rsp],r11
    75a0ec900013:	cmp    DWORD PTR [r12+0x310],0x0
    75a0ec90001c:	je     0x75a0ec9000a7
    75a0ec900022:	push   rdx
    75a0ec900023:	push   rsi
    75a0ec900024:	push   r10
    75a0ec900026:	push   r11
    75a0ec900028:	mov    rdx,QWORD PTR [rsp+0x20]
    75a0ec90002d:	mov    r10d,edx
    75a0ec900030:	and    r10d,0xc000
    75a0ec900037:	shl    r10d,0x10
    75a0ec90003b:	mov    r11d,edx
    75a0ec90003e:	and    r11d,0x100
    75a0ec900045:	shl    r11d,0x15
    75a0ec900049:	or     r10d,r11d
    75a0ec90004c:	and    edx,0x1
    75a0ec90004f:	shl    edx,0x1c
    75a0ec900052:	or     r10d,edx
    75a0ec900055:	btc    r10,0x1d
    75a0ec90005a:	mov    r11d,0xf0000000
    75a0ec900060:	and    r11,r10
    75a0ec900063:	movabs rsi,0xffffffff0fffffff
    75a0ec90006d:	and    rbx,rsi
    75a0ec900070:	or     rbx,r11
    75a0ec900073:	pop    r11
    75a0ec900075:	pop    r10
    75a0ec900077:	pop    rsi
    75a0ec900078:	pop    rdx
    75a0ec900079:	mov    QWORD PTR [r12+0x108],rbx
    75a0ec900081:	mov    eax,0x410028
    75a0ec900086:	mov    QWORD PTR [r12+0x100],rax
    75a0ec90008e:	add    rsp,0x150
    75a0ec900095:	mov    eax,0x3
    75a0ec90009a:	movabs r11,0x5afa90845ca0
    75a0ec9000a4:	jmp    r11
    75a0ec9000a7:	mov    r13d,0x4240
    75a0ec9000ad:	mov    r14d,0xf
    75a0ec9000b3:	and    r14d,0xffff
    75a0ec9000ba:	mov    rax,r13
    75a0ec9000bd:	movabs rcx,0xffffffff0000ffff
    75a0ec9000c7:	and    rax,rcx
    75a0ec9000ca:	mov    rdx,r14
    75a0ec9000cd:	shl    rdx,0x10
    75a0ec9000d1:	mov    ecx,0xffff0000
    75a0ec9000d6:	and    rdx,rcx
    75a0ec9000d9:	or     rax,rdx
    75a0ec9000dc:	mov    r15,rax
    75a0ec9000df:	mov    QWORD PTR [r12+0x8],r15
    75a0ec9000e4:	mov    r13d,0x420060
    75a0ec9000ea:	mov    QWORD PTR [r12+0x20],r13
    75a0ec9000ef:	mov    r13d,0x0
    75a0ec9000f5:	mov    QWORD PTR [r12],r13
    75a0ec9000f9:	mov    r13d,0x0
    75a0ec9000ff:	movabs r14,0x3ff0000000000000
    75a0ec900109:	mov    QWORD PTR [r12+0x110],r14
    75a0ec900111:	mov    QWORD PTR [r12+0x118],r13
    75a0ec900119:	mov    r13d,0x0
    75a0ec90011f:	movabs r14,0x3ff8000000000000
    75a0ec900129:	mov    QWORD PTR [r12+0x120],r14
    75a0ec900131:	mov    QWORD PTR [r12+0x128],r13
    75a0ec900139:	jmp    0x75a0ec90013e
    75a0ec90013e:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    75a0ec900148:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    75a0ec900152:	movdqa xmm0,xmm2
    75a0ec900156:	movdqa xmm1,xmm3
    75a0ec90015a:	movq   xmm0,xmm0
    75a0ec90015e:	movq   xmm1,xmm1
    75a0ec900162:	addsd  xmm0,xmm1
    75a0ec900166:	movdqa xmm14,xmm0
    75a0ec90016b:	movdqu xmm15,XMMWORD PTR [rip+0x45c]        # 0x75a0ec9005d0
    75a0ec900174:	pand   xmm14,xmm15
    75a0ec900179:	movdqu xmm15,XMMWORD PTR [rip+0x45e]        # 0x75a0ec9005e0
    75a0ec900182:	pcmpeqq xmm14,xmm15
    75a0ec900188:	movdqa xmm15,xmm0
    75a0ec90018d:	cmpunordpd xmm15,xmm0
    75a0ec900193:	por    xmm14,xmm15
    75a0ec900198:	pmovmskb ecx,xmm14
    75a0ec90019d:	jrcxz  0x75a0ec9001a4
    75a0ec90019f:	jmp    0x75a0ec90024e
    75a0ec9001a4:	movdqa xmm4,xmm0
    75a0ec9001a8:	movdqu XMMWORD PTR [r12+0x110],xmm4
    75a0ec9001b2:	mov    r13,QWORD PTR [r12+0x8]
    75a0ec9001b7:	sub    r13,0x1
    75a0ec9001bb:	mov    QWORD PTR [r12+0x8],r13
    75a0ec9001c0:	mov    rcx,QWORD PTR [r12+0x380]
    75a0ec9001c8:	jrcxz  0x75a0ec9001cf
    75a0ec9001ca:	jmp    0x75a0ec90034d
    75a0ec9001cf:	jne    0x75a0ec90013e
    75a0ec9001d5:	mov    r11,rax
    75a0ec9001d8:	lahf
    75a0ec9001d9:	seto   al
    75a0ec9001dc:	mov    WORD PTR [rsp],ax
    75a0ec9001e0:	mov    rax,r11
    75a0ec9001e3:	jmp    0x75a0ec9001e8
    75a0ec9001e8:	mov    r13,QWORD PTR [r12+0x20]
    75a0ec9001ed:	mov    r14,QWORD PTR [r12+0x110]
    75a0ec9001f5:	mov    QWORD PTR [r13+0x0],r14
    75a0ec9001f9:	mov    r13d,0x0
    75a0ec9001ff:	mov    DWORD PTR [r12+0x32c],r13d
    75a0ec900207:	mov    rcx,QWORD PTR [r12+0x380]
    75a0ec90020f:	jrcxz  0x75a0ec900216
    75a0ec900211:	jmp    0x75a0ec9003e1
    75a0ec900216:	mov    r13,QWORD PTR [r12+0xf0]
    75a0ec90021e:	mov    QWORD PTR [r12+0x100],r13
    75a0ec900226:	mov    r11,QWORD PTR [rsp]
    75a0ec90022a:	mov    QWORD PTR [r12+0x398],r11
    75a0ec900232:	mov    rdi,QWORD PTR [r12+0x100]
    75a0ec90023a:	add    rsp,0x150
    75a0ec900241:	movabs r11,0x5afa90845940
    75a0ec90024b:	jmp    r11
    75a0ec90024e:	movdqa xmm0,xmm2
    75a0ec900252:	movdqa xmm1,xmm3
    75a0ec900256:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    75a0ec90025f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    75a0ec900268:	call   0x75a0ec900280
    75a0ec90026d:	jmp    0x75a0ec9001a4
    75a0ec900272:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75a0ec900280:	sub    rsp,0x8
    75a0ec900284:	mov    QWORD PTR [r12+0x378],0x3
    75a0ec900290:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    75a0ec900296:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    75a0ec90029c:	mov    QWORD PTR [r12+0x108],rbx
    75a0ec9002a4:	stmxcsr DWORD PTR [r12-0x28]
    75a0ec9002aa:	mov    r10d,DWORD PTR [r12-0x28]
    75a0ec9002af:	test   r10d,0x3f
    75a0ec9002b6:	je     0x75a0ec9002db
    75a0ec9002bc:	mov    r11d,r10d
    75a0ec9002bf:	shr    r10d,1
    75a0ec9002c2:	and    r10d,0x1e
    75a0ec9002c6:	and    r11d,0x1
    75a0ec9002ca:	or     r10d,r11d
    75a0ec9002cd:	or     DWORD PTR [r12+0x314],r10d
    75a0ec9002d5:	and    DWORD PTR [r12-0x28],0xffffffc0
    75a0ec9002db:	ldmxcsr DWORD PTR [r12-0x38]
    75a0ec9002e1:	lea    rdi,[rsp+0x110]
    75a0ec9002e9:	lea    rsi,[rsp+0xf0]
    75a0ec9002f1:	lea    rdx,[rsp+0x100]
    75a0ec9002f9:	mov    ecx,0xc
    75a0ec9002fe:	mov    r8d,0x0
    75a0ec900304:	lea    r9,[r12+0x314]
    75a0ec90030c:	movabs r11,0x5afa906ac650
    75a0ec900316:	call   r11
    75a0ec900319:	ldmxcsr DWORD PTR [r12-0x28]
    75a0ec90031f:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    75a0ec900325:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    75a0ec90032b:	mov    rbx,QWORD PTR [r12+0x108]
    75a0ec900333:	mov    QWORD PTR [r12+0x378],0x2
    75a0ec90033f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    75a0ec900348:	add    rsp,0x8
    75a0ec90034c:	ret
    75a0ec90034d:	mov    eax,0x41004c
    75a0ec900352:	mov    QWORD PTR [r12+0x100],rax
    75a0ec90035a:	push   rdx
    75a0ec90035b:	push   rsi
    75a0ec90035c:	push   r10
    75a0ec90035e:	push   r11
    75a0ec900360:	mov    r11,rax
    75a0ec900363:	lahf
    75a0ec900364:	seto   al
    75a0ec900367:	mov    WORD PTR [rsp+0x20],ax
    75a0ec90036c:	mov    rax,r11
    75a0ec90036f:	mov    rdx,QWORD PTR [rsp+0x20]
    75a0ec900374:	mov    r10d,edx
    75a0ec900377:	and    r10d,0xc000
    75a0ec90037e:	shl    r10d,0x10
    75a0ec900382:	mov    r11d,edx
    75a0ec900385:	and    r11d,0x100
    75a0ec90038c:	shl    r11d,0x15
    75a0ec900390:	or     r10d,r11d
    75a0ec900393:	and    edx,0x1
    75a0ec900396:	shl    edx,0x1c
    75a0ec900399:	or     r10d,edx
    75a0ec90039c:	btc    r10,0x1d
    75a0ec9003a1:	mov    r11d,0xf0000000
    75a0ec9003a7:	and    r11,r10
    75a0ec9003aa:	movabs rsi,0xffffffff0fffffff
    75a0ec9003b4:	and    rbx,rsi
    75a0ec9003b7:	or     rbx,r11
    75a0ec9003ba:	pop    r11
    75a0ec9003bc:	pop    r10
    75a0ec9003be:	pop    rsi
    75a0ec9003bf:	pop    rdx
    75a0ec9003c0:	mov    QWORD PTR [r12+0x108],rbx
    75a0ec9003c8:	add    rsp,0x150
    75a0ec9003cf:	mov    eax,0xc
    75a0ec9003d4:	movabs r11,0x5afa90845ca0
    75a0ec9003de:	jmp    r11
    75a0ec9003e1:	mov    eax,0x410054
    75a0ec9003e6:	mov    QWORD PTR [r12+0x100],rax
    75a0ec9003ee:	push   rdx
    75a0ec9003ef:	push   rsi
    75a0ec9003f0:	push   r10
    75a0ec9003f2:	push   r11
    75a0ec9003f4:	mov    rdx,QWORD PTR [rsp+0x20]
    75a0ec9003f9:	mov    r10d,edx
    75a0ec9003fc:	and    r10d,0xc000
    75a0ec900403:	shl    r10d,0x10
    75a0ec900407:	mov    r11d,edx
    75a0ec90040a:	and    r11d,0x100
    75a0ec900411:	shl    r11d,0x15
    75a0ec900415:	or     r10d,r11d
    75a0ec900418:	and    edx,0x1
    75a0ec90041b:	shl    edx,0x1c
    75a0ec90041e:	or     r10d,edx
    75a0ec900421:	btc    r10,0x1d
    75a0ec900426:	mov    r11d,0xf0000000
    75a0ec90042c:	and    r11,r10
    75a0ec90042f:	movabs rsi,0xffffffff0fffffff
    75a0ec900439:	and    rbx,rsi
    75a0ec90043c:	or     rbx,r11
    75a0ec90043f:	pop    r11
    75a0ec900441:	pop    r10
    75a0ec900443:	pop    rsi
    75a0ec900444:	pop    rdx
    75a0ec900445:	mov    QWORD PTR [r12+0x108],rbx
    75a0ec90044d:	add    rsp,0x150
    75a0ec900454:	mov    eax,0xc
    75a0ec900459:	movabs r11,0x5afa90845ca0
    75a0ec900463:	jmp    r11
    75a0ec900466:	data16 nop WORD PTR [rax+rax*1+0x0]
    75a0ec900470:	sub    rsp,0x150
    75a0ec900477:	mov    r11,QWORD PTR [r12+0x398]
    75a0ec90047f:	mov    QWORD PTR [rsp],r11
    75a0ec900483:	cmp    DWORD PTR [r12+0x310],0x0
    75a0ec90048c:	je     0x75a0ec900517
    75a0ec900492:	push   rdx
    75a0ec900493:	push   rsi
    75a0ec900494:	push   r10
    75a0ec900496:	push   r11
    75a0ec900498:	mov    rdx,QWORD PTR [rsp+0x20]
    75a0ec90049d:	mov    r10d,edx
    75a0ec9004a0:	and    r10d,0xc000
    75a0ec9004a7:	shl    r10d,0x10
    75a0ec9004ab:	mov    r11d,edx
    75a0ec9004ae:	and    r11d,0x100
    75a0ec9004b5:	shl    r11d,0x15
    75a0ec9004b9:	or     r10d,r11d
    75a0ec9004bc:	and    edx,0x1
    75a0ec9004bf:	shl    edx,0x1c
    75a0ec9004c2:	or     r10d,edx
    75a0ec9004c5:	btc    r10,0x1d
    75a0ec9004ca:	mov    r11d,0xf0000000
    75a0ec9004d0:	and    r11,r10
    75a0ec9004d3:	movabs rsi,0xffffffff0fffffff
    75a0ec9004dd:	and    rbx,rsi
    75a0ec9004e0:	or     rbx,r11
    75a0ec9004e3:	pop    r11
    75a0ec9004e5:	pop    r10
    75a0ec9004e7:	pop    rsi
    75a0ec9004e8:	pop    rdx
    75a0ec9004e9:	mov    QWORD PTR [r12+0x108],rbx
    75a0ec9004f1:	mov    eax,0x410044
    75a0ec9004f6:	mov    QWORD PTR [r12+0x100],rax
    75a0ec9004fe:	add    rsp,0x150
    75a0ec900505:	mov    eax,0x3
    75a0ec90050a:	movabs r11,0x5afa90845ca0
    75a0ec900514:	jmp    r11
    75a0ec900517:	jmp    0x75a0ec90013e
    75a0ec90051c:	nop    DWORD PTR [rax+0x0]
    75a0ec900520:	sub    rsp,0x150
    75a0ec900527:	mov    r11,QWORD PTR [r12+0x398]
    75a0ec90052f:	mov    QWORD PTR [rsp],r11
    75a0ec900533:	cmp    DWORD PTR [r12+0x310],0x0
    75a0ec90053c:	je     0x75a0ec9005c7
    75a0ec900542:	push   rdx
    75a0ec900543:	push   rsi
    75a0ec900544:	push   r10
    75a0ec900546:	push   r11
    75a0ec900548:	mov    rdx,QWORD PTR [rsp+0x20]
    75a0ec90054d:	mov    r10d,edx
    75a0ec900550:	and    r10d,0xc000
    75a0ec900557:	shl    r10d,0x10
    75a0ec90055b:	mov    r11d,edx
    75a0ec90055e:	and    r11d,0x100
    75a0ec900565:	shl    r11d,0x15
    75a0ec900569:	or     r10d,r11d
    75a0ec90056c:	and    edx,0x1
    75a0ec90056f:	shl    edx,0x1c
    75a0ec900572:	or     r10d,edx
    75a0ec900575:	btc    r10,0x1d
    75a0ec90057a:	mov    r11d,0xf0000000
    75a0ec900580:	and    r11,r10
    75a0ec900583:	movabs rsi,0xffffffff0fffffff
    75a0ec90058d:	and    rbx,rsi
    75a0ec900590:	or     rbx,r11
    75a0ec900593:	pop    r11
    75a0ec900595:	pop    r10
    75a0ec900597:	pop    rsi
    75a0ec900598:	pop    rdx
    75a0ec900599:	mov    QWORD PTR [r12+0x108],rbx
    75a0ec9005a1:	mov    eax,0x410050
    75a0ec9005a6:	mov    QWORD PTR [r12+0x100],rax
    75a0ec9005ae:	add    rsp,0x150
    75a0ec9005b5:	mov    eax,0x3
    75a0ec9005ba:	movabs r11,0x5afa90845ca0
    75a0ec9005c4:	jmp    r11
    75a0ec9005c7:	jmp    0x75a0ec9001e8
    75a0ec9005cc:	nop    DWORD PTR [rax+0x0]
    75a0ec9005d0:	(bad)
    75a0ec9005d1:	(bad)
    75a0ec9005d2:	(bad)
    75a0ec9005d3:	(bad)
    75a0ec9005d4:	(bad)
    75a0ec9005d5:	(bad)
    75a0ec9005d6:	(bad)
    75a0ec9005d7:	jg     0x75a0ec9005d8
    75a0ec9005d9:	(bad)
    75a0ec9005da:	(bad)
    75a0ec9005db:	(bad)
    75a0ec9005dc:	(bad)
    75a0ec9005dd:	(bad)
    75a0ec9005de:	(bad)
    75a0ec9005df:	jg     0x75a0ec9005e1
    75a0ec9005e1:	add    BYTE PTR [rax],al
    75a0ec9005e3:	add    BYTE PTR [rax],al
    75a0ec9005e5:	add    BYTE PTR [rax],dl
    75a0ec9005e7:	add    BYTE PTR [rax],al
    75a0ec9005e9:	add    BYTE PTR [rax],al
    75a0ec9005eb:	add    BYTE PTR [rax],al
    75a0ec9005ed:	add    BYTE PTR [rax],dl
	...
