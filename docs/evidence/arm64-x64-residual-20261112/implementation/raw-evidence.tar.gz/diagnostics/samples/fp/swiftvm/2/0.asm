
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/fp/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

00007c4bd0300000 <.data>:
    7c4bd0300000:	sub    rsp,0x150
    7c4bd0300007:	mov    r11,QWORD PTR [r12+0x398]
    7c4bd030000f:	mov    QWORD PTR [rsp],r11
    7c4bd0300013:	cmp    DWORD PTR [r12+0x310],0x0
    7c4bd030001c:	je     0x7c4bd03000a7
    7c4bd0300022:	push   rdx
    7c4bd0300023:	push   rsi
    7c4bd0300024:	push   r10
    7c4bd0300026:	push   r11
    7c4bd0300028:	mov    rdx,QWORD PTR [rsp+0x20]
    7c4bd030002d:	mov    r10d,edx
    7c4bd0300030:	and    r10d,0xc000
    7c4bd0300037:	shl    r10d,0x10
    7c4bd030003b:	mov    r11d,edx
    7c4bd030003e:	and    r11d,0x100
    7c4bd0300045:	shl    r11d,0x15
    7c4bd0300049:	or     r10d,r11d
    7c4bd030004c:	and    edx,0x1
    7c4bd030004f:	shl    edx,0x1c
    7c4bd0300052:	or     r10d,edx
    7c4bd0300055:	btc    r10,0x1d
    7c4bd030005a:	mov    r11d,0xf0000000
    7c4bd0300060:	and    r11,r10
    7c4bd0300063:	movabs rsi,0xffffffff0fffffff
    7c4bd030006d:	and    rbx,rsi
    7c4bd0300070:	or     rbx,r11
    7c4bd0300073:	pop    r11
    7c4bd0300075:	pop    r10
    7c4bd0300077:	pop    rsi
    7c4bd0300078:	pop    rdx
    7c4bd0300079:	mov    QWORD PTR [r12+0x108],rbx
    7c4bd0300081:	mov    eax,0x410028
    7c4bd0300086:	mov    QWORD PTR [r12+0x100],rax
    7c4bd030008e:	add    rsp,0x150
    7c4bd0300095:	mov    eax,0x3
    7c4bd030009a:	movabs r11,0x64be02e90ca0
    7c4bd03000a4:	jmp    r11
    7c4bd03000a7:	mov    r13d,0x4240
    7c4bd03000ad:	mov    r14d,0xf
    7c4bd03000b3:	and    r14d,0xffff
    7c4bd03000ba:	mov    rax,r13
    7c4bd03000bd:	movabs rcx,0xffffffff0000ffff
    7c4bd03000c7:	and    rax,rcx
    7c4bd03000ca:	mov    rdx,r14
    7c4bd03000cd:	shl    rdx,0x10
    7c4bd03000d1:	mov    ecx,0xffff0000
    7c4bd03000d6:	and    rdx,rcx
    7c4bd03000d9:	or     rax,rdx
    7c4bd03000dc:	mov    r15,rax
    7c4bd03000df:	mov    QWORD PTR [r12+0x8],r15
    7c4bd03000e4:	mov    r13d,0x420060
    7c4bd03000ea:	mov    QWORD PTR [r12+0x20],r13
    7c4bd03000ef:	mov    r13d,0x0
    7c4bd03000f5:	mov    QWORD PTR [r12],r13
    7c4bd03000f9:	mov    r13d,0x0
    7c4bd03000ff:	movabs r14,0x3ff0000000000000
    7c4bd0300109:	mov    QWORD PTR [r12+0x110],r14
    7c4bd0300111:	mov    QWORD PTR [r12+0x118],r13
    7c4bd0300119:	mov    r13d,0x0
    7c4bd030011f:	movabs r14,0x3ff8000000000000
    7c4bd0300129:	mov    QWORD PTR [r12+0x120],r14
    7c4bd0300131:	mov    QWORD PTR [r12+0x128],r13
    7c4bd0300139:	jmp    0x7c4bd030013e
    7c4bd030013e:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    7c4bd0300148:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    7c4bd0300152:	movdqa xmm0,xmm2
    7c4bd0300156:	movdqa xmm1,xmm3
    7c4bd030015a:	movq   xmm0,xmm0
    7c4bd030015e:	movq   xmm1,xmm1
    7c4bd0300162:	addsd  xmm0,xmm1
    7c4bd0300166:	movdqa xmm14,xmm0
    7c4bd030016b:	movdqu xmm15,XMMWORD PTR [rip+0x45c]        # 0x7c4bd03005d0
    7c4bd0300174:	pand   xmm14,xmm15
    7c4bd0300179:	movdqu xmm15,XMMWORD PTR [rip+0x45e]        # 0x7c4bd03005e0
    7c4bd0300182:	pcmpeqq xmm14,xmm15
    7c4bd0300188:	movdqa xmm15,xmm0
    7c4bd030018d:	cmpunordpd xmm15,xmm0
    7c4bd0300193:	por    xmm14,xmm15
    7c4bd0300198:	pmovmskb ecx,xmm14
    7c4bd030019d:	jrcxz  0x7c4bd03001a4
    7c4bd030019f:	jmp    0x7c4bd030024e
    7c4bd03001a4:	movdqa xmm4,xmm0
    7c4bd03001a8:	movdqu XMMWORD PTR [r12+0x110],xmm4
    7c4bd03001b2:	mov    r13,QWORD PTR [r12+0x8]
    7c4bd03001b7:	sub    r13,0x1
    7c4bd03001bb:	mov    QWORD PTR [r12+0x8],r13
    7c4bd03001c0:	mov    rcx,QWORD PTR [r12+0x380]
    7c4bd03001c8:	jrcxz  0x7c4bd03001cf
    7c4bd03001ca:	jmp    0x7c4bd030034d
    7c4bd03001cf:	jne    0x7c4bd030013e
    7c4bd03001d5:	mov    r11,rax
    7c4bd03001d8:	lahf
    7c4bd03001d9:	seto   al
    7c4bd03001dc:	mov    WORD PTR [rsp],ax
    7c4bd03001e0:	mov    rax,r11
    7c4bd03001e3:	jmp    0x7c4bd03001e8
    7c4bd03001e8:	mov    r13,QWORD PTR [r12+0x20]
    7c4bd03001ed:	mov    r14,QWORD PTR [r12+0x110]
    7c4bd03001f5:	mov    QWORD PTR [r13+0x0],r14
    7c4bd03001f9:	mov    r13d,0x0
    7c4bd03001ff:	mov    DWORD PTR [r12+0x32c],r13d
    7c4bd0300207:	mov    rcx,QWORD PTR [r12+0x380]
    7c4bd030020f:	jrcxz  0x7c4bd0300216
    7c4bd0300211:	jmp    0x7c4bd03003e1
    7c4bd0300216:	mov    r13,QWORD PTR [r12+0xf0]
    7c4bd030021e:	mov    QWORD PTR [r12+0x100],r13
    7c4bd0300226:	mov    r11,QWORD PTR [rsp]
    7c4bd030022a:	mov    QWORD PTR [r12+0x398],r11
    7c4bd0300232:	mov    rdi,QWORD PTR [r12+0x100]
    7c4bd030023a:	add    rsp,0x150
    7c4bd0300241:	movabs r11,0x64be02e90940
    7c4bd030024b:	jmp    r11
    7c4bd030024e:	movdqa xmm0,xmm2
    7c4bd0300252:	movdqa xmm1,xmm3
    7c4bd0300256:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c4bd030025f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c4bd0300268:	call   0x7c4bd0300280
    7c4bd030026d:	jmp    0x7c4bd03001a4
    7c4bd0300272:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c4bd0300280:	sub    rsp,0x8
    7c4bd0300284:	mov    QWORD PTR [r12+0x378],0x3
    7c4bd0300290:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c4bd0300296:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c4bd030029c:	mov    QWORD PTR [r12+0x108],rbx
    7c4bd03002a4:	stmxcsr DWORD PTR [r12-0x28]
    7c4bd03002aa:	mov    r10d,DWORD PTR [r12-0x28]
    7c4bd03002af:	test   r10d,0x3f
    7c4bd03002b6:	je     0x7c4bd03002db
    7c4bd03002bc:	mov    r11d,r10d
    7c4bd03002bf:	shr    r10d,1
    7c4bd03002c2:	and    r10d,0x1e
    7c4bd03002c6:	and    r11d,0x1
    7c4bd03002ca:	or     r10d,r11d
    7c4bd03002cd:	or     DWORD PTR [r12+0x314],r10d
    7c4bd03002d5:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c4bd03002db:	ldmxcsr DWORD PTR [r12-0x38]
    7c4bd03002e1:	lea    rdi,[rsp+0x110]
    7c4bd03002e9:	lea    rsi,[rsp+0xf0]
    7c4bd03002f1:	lea    rdx,[rsp+0x100]
    7c4bd03002f9:	mov    ecx,0xc
    7c4bd03002fe:	mov    r8d,0x0
    7c4bd0300304:	lea    r9,[r12+0x314]
    7c4bd030030c:	movabs r11,0x64be02cf7650
    7c4bd0300316:	call   r11
    7c4bd0300319:	ldmxcsr DWORD PTR [r12-0x28]
    7c4bd030031f:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c4bd0300325:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c4bd030032b:	mov    rbx,QWORD PTR [r12+0x108]
    7c4bd0300333:	mov    QWORD PTR [r12+0x378],0x2
    7c4bd030033f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c4bd0300348:	add    rsp,0x8
    7c4bd030034c:	ret
    7c4bd030034d:	mov    eax,0x41004c
    7c4bd0300352:	mov    QWORD PTR [r12+0x100],rax
    7c4bd030035a:	push   rdx
    7c4bd030035b:	push   rsi
    7c4bd030035c:	push   r10
    7c4bd030035e:	push   r11
    7c4bd0300360:	mov    r11,rax
    7c4bd0300363:	lahf
    7c4bd0300364:	seto   al
    7c4bd0300367:	mov    WORD PTR [rsp+0x20],ax
    7c4bd030036c:	mov    rax,r11
    7c4bd030036f:	mov    rdx,QWORD PTR [rsp+0x20]
    7c4bd0300374:	mov    r10d,edx
    7c4bd0300377:	and    r10d,0xc000
    7c4bd030037e:	shl    r10d,0x10
    7c4bd0300382:	mov    r11d,edx
    7c4bd0300385:	and    r11d,0x100
    7c4bd030038c:	shl    r11d,0x15
    7c4bd0300390:	or     r10d,r11d
    7c4bd0300393:	and    edx,0x1
    7c4bd0300396:	shl    edx,0x1c
    7c4bd0300399:	or     r10d,edx
    7c4bd030039c:	btc    r10,0x1d
    7c4bd03003a1:	mov    r11d,0xf0000000
    7c4bd03003a7:	and    r11,r10
    7c4bd03003aa:	movabs rsi,0xffffffff0fffffff
    7c4bd03003b4:	and    rbx,rsi
    7c4bd03003b7:	or     rbx,r11
    7c4bd03003ba:	pop    r11
    7c4bd03003bc:	pop    r10
    7c4bd03003be:	pop    rsi
    7c4bd03003bf:	pop    rdx
    7c4bd03003c0:	mov    QWORD PTR [r12+0x108],rbx
    7c4bd03003c8:	add    rsp,0x150
    7c4bd03003cf:	mov    eax,0xc
    7c4bd03003d4:	movabs r11,0x64be02e90ca0
    7c4bd03003de:	jmp    r11
    7c4bd03003e1:	mov    eax,0x410054
    7c4bd03003e6:	mov    QWORD PTR [r12+0x100],rax
    7c4bd03003ee:	push   rdx
    7c4bd03003ef:	push   rsi
    7c4bd03003f0:	push   r10
    7c4bd03003f2:	push   r11
    7c4bd03003f4:	mov    rdx,QWORD PTR [rsp+0x20]
    7c4bd03003f9:	mov    r10d,edx
    7c4bd03003fc:	and    r10d,0xc000
    7c4bd0300403:	shl    r10d,0x10
    7c4bd0300407:	mov    r11d,edx
    7c4bd030040a:	and    r11d,0x100
    7c4bd0300411:	shl    r11d,0x15
    7c4bd0300415:	or     r10d,r11d
    7c4bd0300418:	and    edx,0x1
    7c4bd030041b:	shl    edx,0x1c
    7c4bd030041e:	or     r10d,edx
    7c4bd0300421:	btc    r10,0x1d
    7c4bd0300426:	mov    r11d,0xf0000000
    7c4bd030042c:	and    r11,r10
    7c4bd030042f:	movabs rsi,0xffffffff0fffffff
    7c4bd0300439:	and    rbx,rsi
    7c4bd030043c:	or     rbx,r11
    7c4bd030043f:	pop    r11
    7c4bd0300441:	pop    r10
    7c4bd0300443:	pop    rsi
    7c4bd0300444:	pop    rdx
    7c4bd0300445:	mov    QWORD PTR [r12+0x108],rbx
    7c4bd030044d:	add    rsp,0x150
    7c4bd0300454:	mov    eax,0xc
    7c4bd0300459:	movabs r11,0x64be02e90ca0
    7c4bd0300463:	jmp    r11
    7c4bd0300466:	data16 nop WORD PTR [rax+rax*1+0x0]
    7c4bd0300470:	sub    rsp,0x150
    7c4bd0300477:	mov    r11,QWORD PTR [r12+0x398]
    7c4bd030047f:	mov    QWORD PTR [rsp],r11
    7c4bd0300483:	cmp    DWORD PTR [r12+0x310],0x0
    7c4bd030048c:	je     0x7c4bd0300517
    7c4bd0300492:	push   rdx
    7c4bd0300493:	push   rsi
    7c4bd0300494:	push   r10
    7c4bd0300496:	push   r11
    7c4bd0300498:	mov    rdx,QWORD PTR [rsp+0x20]
    7c4bd030049d:	mov    r10d,edx
    7c4bd03004a0:	and    r10d,0xc000
    7c4bd03004a7:	shl    r10d,0x10
    7c4bd03004ab:	mov    r11d,edx
    7c4bd03004ae:	and    r11d,0x100
    7c4bd03004b5:	shl    r11d,0x15
    7c4bd03004b9:	or     r10d,r11d
    7c4bd03004bc:	and    edx,0x1
    7c4bd03004bf:	shl    edx,0x1c
    7c4bd03004c2:	or     r10d,edx
    7c4bd03004c5:	btc    r10,0x1d
    7c4bd03004ca:	mov    r11d,0xf0000000
    7c4bd03004d0:	and    r11,r10
    7c4bd03004d3:	movabs rsi,0xffffffff0fffffff
    7c4bd03004dd:	and    rbx,rsi
    7c4bd03004e0:	or     rbx,r11
    7c4bd03004e3:	pop    r11
    7c4bd03004e5:	pop    r10
    7c4bd03004e7:	pop    rsi
    7c4bd03004e8:	pop    rdx
    7c4bd03004e9:	mov    QWORD PTR [r12+0x108],rbx
    7c4bd03004f1:	mov    eax,0x410044
    7c4bd03004f6:	mov    QWORD PTR [r12+0x100],rax
    7c4bd03004fe:	add    rsp,0x150
    7c4bd0300505:	mov    eax,0x3
    7c4bd030050a:	movabs r11,0x64be02e90ca0
    7c4bd0300514:	jmp    r11
    7c4bd0300517:	jmp    0x7c4bd030013e
    7c4bd030051c:	nop    DWORD PTR [rax+0x0]
    7c4bd0300520:	sub    rsp,0x150
    7c4bd0300527:	mov    r11,QWORD PTR [r12+0x398]
    7c4bd030052f:	mov    QWORD PTR [rsp],r11
    7c4bd0300533:	cmp    DWORD PTR [r12+0x310],0x0
    7c4bd030053c:	je     0x7c4bd03005c7
    7c4bd0300542:	push   rdx
    7c4bd0300543:	push   rsi
    7c4bd0300544:	push   r10
    7c4bd0300546:	push   r11
    7c4bd0300548:	mov    rdx,QWORD PTR [rsp+0x20]
    7c4bd030054d:	mov    r10d,edx
    7c4bd0300550:	and    r10d,0xc000
    7c4bd0300557:	shl    r10d,0x10
    7c4bd030055b:	mov    r11d,edx
    7c4bd030055e:	and    r11d,0x100
    7c4bd0300565:	shl    r11d,0x15
    7c4bd0300569:	or     r10d,r11d
    7c4bd030056c:	and    edx,0x1
    7c4bd030056f:	shl    edx,0x1c
    7c4bd0300572:	or     r10d,edx
    7c4bd0300575:	btc    r10,0x1d
    7c4bd030057a:	mov    r11d,0xf0000000
    7c4bd0300580:	and    r11,r10
    7c4bd0300583:	movabs rsi,0xffffffff0fffffff
    7c4bd030058d:	and    rbx,rsi
    7c4bd0300590:	or     rbx,r11
    7c4bd0300593:	pop    r11
    7c4bd0300595:	pop    r10
    7c4bd0300597:	pop    rsi
    7c4bd0300598:	pop    rdx
    7c4bd0300599:	mov    QWORD PTR [r12+0x108],rbx
    7c4bd03005a1:	mov    eax,0x410050
    7c4bd03005a6:	mov    QWORD PTR [r12+0x100],rax
    7c4bd03005ae:	add    rsp,0x150
    7c4bd03005b5:	mov    eax,0x3
    7c4bd03005ba:	movabs r11,0x64be02e90ca0
    7c4bd03005c4:	jmp    r11
    7c4bd03005c7:	jmp    0x7c4bd03001e8
    7c4bd03005cc:	nop    DWORD PTR [rax+0x0]
    7c4bd03005d0:	(bad)
    7c4bd03005d1:	(bad)
    7c4bd03005d2:	(bad)
    7c4bd03005d3:	(bad)
    7c4bd03005d4:	(bad)
    7c4bd03005d5:	(bad)
    7c4bd03005d6:	(bad)
    7c4bd03005d7:	jg     0x7c4bd03005d8
    7c4bd03005d9:	(bad)
    7c4bd03005da:	(bad)
    7c4bd03005db:	(bad)
    7c4bd03005dc:	(bad)
    7c4bd03005dd:	(bad)
    7c4bd03005de:	(bad)
    7c4bd03005df:	jg     0x7c4bd03005e1
    7c4bd03005e1:	add    BYTE PTR [rax],al
    7c4bd03005e3:	add    BYTE PTR [rax],al
    7c4bd03005e5:	add    BYTE PTR [rax],dl
    7c4bd03005e7:	add    BYTE PTR [rax],al
    7c4bd03005e9:	add    BYTE PTR [rax],al
    7c4bd03005eb:	add    BYTE PTR [rax],al
    7c4bd03005ed:	add    BYTE PTR [rax],dl
	...
