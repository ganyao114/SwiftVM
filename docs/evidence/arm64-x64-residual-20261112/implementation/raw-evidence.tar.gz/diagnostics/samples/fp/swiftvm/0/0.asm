
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/fp/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

000071db58900000 <.data>:
    71db58900000:	sub    rsp,0x150
    71db58900007:	mov    r11,QWORD PTR [r12+0x398]
    71db5890000f:	mov    QWORD PTR [rsp],r11
    71db58900013:	cmp    DWORD PTR [r12+0x310],0x0
    71db5890001c:	je     0x71db589000a7
    71db58900022:	push   rdx
    71db58900023:	push   rsi
    71db58900024:	push   r10
    71db58900026:	push   r11
    71db58900028:	mov    rdx,QWORD PTR [rsp+0x20]
    71db5890002d:	mov    r10d,edx
    71db58900030:	and    r10d,0xc000
    71db58900037:	shl    r10d,0x10
    71db5890003b:	mov    r11d,edx
    71db5890003e:	and    r11d,0x100
    71db58900045:	shl    r11d,0x15
    71db58900049:	or     r10d,r11d
    71db5890004c:	and    edx,0x1
    71db5890004f:	shl    edx,0x1c
    71db58900052:	or     r10d,edx
    71db58900055:	btc    r10,0x1d
    71db5890005a:	mov    r11d,0xf0000000
    71db58900060:	and    r11,r10
    71db58900063:	movabs rsi,0xffffffff0fffffff
    71db5890006d:	and    rbx,rsi
    71db58900070:	or     rbx,r11
    71db58900073:	pop    r11
    71db58900075:	pop    r10
    71db58900077:	pop    rsi
    71db58900078:	pop    rdx
    71db58900079:	mov    QWORD PTR [r12+0x108],rbx
    71db58900081:	mov    eax,0x410028
    71db58900086:	mov    QWORD PTR [r12+0x100],rax
    71db5890008e:	add    rsp,0x150
    71db58900095:	mov    eax,0x3
    71db5890009a:	movabs r11,0x5bfd209f5ca0
    71db589000a4:	jmp    r11
    71db589000a7:	mov    r13d,0x4240
    71db589000ad:	mov    r14d,0xf
    71db589000b3:	and    r14d,0xffff
    71db589000ba:	mov    rax,r13
    71db589000bd:	movabs rcx,0xffffffff0000ffff
    71db589000c7:	and    rax,rcx
    71db589000ca:	mov    rdx,r14
    71db589000cd:	shl    rdx,0x10
    71db589000d1:	mov    ecx,0xffff0000
    71db589000d6:	and    rdx,rcx
    71db589000d9:	or     rax,rdx
    71db589000dc:	mov    r15,rax
    71db589000df:	mov    QWORD PTR [r12+0x8],r15
    71db589000e4:	mov    r13d,0x420060
    71db589000ea:	mov    QWORD PTR [r12+0x20],r13
    71db589000ef:	mov    r13d,0x0
    71db589000f5:	mov    QWORD PTR [r12],r13
    71db589000f9:	mov    r13d,0x0
    71db589000ff:	movabs r14,0x3ff0000000000000
    71db58900109:	mov    QWORD PTR [r12+0x110],r14
    71db58900111:	mov    QWORD PTR [r12+0x118],r13
    71db58900119:	mov    r13d,0x0
    71db5890011f:	movabs r14,0x3ff8000000000000
    71db58900129:	mov    QWORD PTR [r12+0x120],r14
    71db58900131:	mov    QWORD PTR [r12+0x128],r13
    71db58900139:	jmp    0x71db5890013e
    71db5890013e:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    71db58900148:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    71db58900152:	movdqa xmm0,xmm2
    71db58900156:	movdqa xmm1,xmm3
    71db5890015a:	movq   xmm0,xmm0
    71db5890015e:	movq   xmm1,xmm1
    71db58900162:	addsd  xmm0,xmm1
    71db58900166:	movdqa xmm14,xmm0
    71db5890016b:	movdqu xmm15,XMMWORD PTR [rip+0x45c]        # 0x71db589005d0
    71db58900174:	pand   xmm14,xmm15
    71db58900179:	movdqu xmm15,XMMWORD PTR [rip+0x45e]        # 0x71db589005e0
    71db58900182:	pcmpeqq xmm14,xmm15
    71db58900188:	movdqa xmm15,xmm0
    71db5890018d:	cmpunordpd xmm15,xmm0
    71db58900193:	por    xmm14,xmm15
    71db58900198:	pmovmskb ecx,xmm14
    71db5890019d:	jrcxz  0x71db589001a4
    71db5890019f:	jmp    0x71db5890024e
    71db589001a4:	movdqa xmm4,xmm0
    71db589001a8:	movdqu XMMWORD PTR [r12+0x110],xmm4
    71db589001b2:	mov    r13,QWORD PTR [r12+0x8]
    71db589001b7:	sub    r13,0x1
    71db589001bb:	mov    QWORD PTR [r12+0x8],r13
    71db589001c0:	mov    rcx,QWORD PTR [r12+0x380]
    71db589001c8:	jrcxz  0x71db589001cf
    71db589001ca:	jmp    0x71db5890034d
    71db589001cf:	jne    0x71db5890013e
    71db589001d5:	mov    r11,rax
    71db589001d8:	lahf
    71db589001d9:	seto   al
    71db589001dc:	mov    WORD PTR [rsp],ax
    71db589001e0:	mov    rax,r11
    71db589001e3:	jmp    0x71db589001e8
    71db589001e8:	mov    r13,QWORD PTR [r12+0x20]
    71db589001ed:	mov    r14,QWORD PTR [r12+0x110]
    71db589001f5:	mov    QWORD PTR [r13+0x0],r14
    71db589001f9:	mov    r13d,0x0
    71db589001ff:	mov    DWORD PTR [r12+0x32c],r13d
    71db58900207:	mov    rcx,QWORD PTR [r12+0x380]
    71db5890020f:	jrcxz  0x71db58900216
    71db58900211:	jmp    0x71db589003e1
    71db58900216:	mov    r13,QWORD PTR [r12+0xf0]
    71db5890021e:	mov    QWORD PTR [r12+0x100],r13
    71db58900226:	mov    r11,QWORD PTR [rsp]
    71db5890022a:	mov    QWORD PTR [r12+0x398],r11
    71db58900232:	mov    rdi,QWORD PTR [r12+0x100]
    71db5890023a:	add    rsp,0x150
    71db58900241:	movabs r11,0x5bfd209f5940
    71db5890024b:	jmp    r11
    71db5890024e:	movdqa xmm0,xmm2
    71db58900252:	movdqa xmm1,xmm3
    71db58900256:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    71db5890025f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    71db58900268:	call   0x71db58900280
    71db5890026d:	jmp    0x71db589001a4
    71db58900272:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71db58900280:	sub    rsp,0x8
    71db58900284:	mov    QWORD PTR [r12+0x378],0x3
    71db58900290:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    71db58900296:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    71db5890029c:	mov    QWORD PTR [r12+0x108],rbx
    71db589002a4:	stmxcsr DWORD PTR [r12-0x28]
    71db589002aa:	mov    r10d,DWORD PTR [r12-0x28]
    71db589002af:	test   r10d,0x3f
    71db589002b6:	je     0x71db589002db
    71db589002bc:	mov    r11d,r10d
    71db589002bf:	shr    r10d,1
    71db589002c2:	and    r10d,0x1e
    71db589002c6:	and    r11d,0x1
    71db589002ca:	or     r10d,r11d
    71db589002cd:	or     DWORD PTR [r12+0x314],r10d
    71db589002d5:	and    DWORD PTR [r12-0x28],0xffffffc0
    71db589002db:	ldmxcsr DWORD PTR [r12-0x38]
    71db589002e1:	lea    rdi,[rsp+0x110]
    71db589002e9:	lea    rsi,[rsp+0xf0]
    71db589002f1:	lea    rdx,[rsp+0x100]
    71db589002f9:	mov    ecx,0xc
    71db589002fe:	mov    r8d,0x0
    71db58900304:	lea    r9,[r12+0x314]
    71db5890030c:	movabs r11,0x5bfd2085c650
    71db58900316:	call   r11
    71db58900319:	ldmxcsr DWORD PTR [r12-0x28]
    71db5890031f:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    71db58900325:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    71db5890032b:	mov    rbx,QWORD PTR [r12+0x108]
    71db58900333:	mov    QWORD PTR [r12+0x378],0x2
    71db5890033f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    71db58900348:	add    rsp,0x8
    71db5890034c:	ret
    71db5890034d:	mov    eax,0x41004c
    71db58900352:	mov    QWORD PTR [r12+0x100],rax
    71db5890035a:	push   rdx
    71db5890035b:	push   rsi
    71db5890035c:	push   r10
    71db5890035e:	push   r11
    71db58900360:	mov    r11,rax
    71db58900363:	lahf
    71db58900364:	seto   al
    71db58900367:	mov    WORD PTR [rsp+0x20],ax
    71db5890036c:	mov    rax,r11
    71db5890036f:	mov    rdx,QWORD PTR [rsp+0x20]
    71db58900374:	mov    r10d,edx
    71db58900377:	and    r10d,0xc000
    71db5890037e:	shl    r10d,0x10
    71db58900382:	mov    r11d,edx
    71db58900385:	and    r11d,0x100
    71db5890038c:	shl    r11d,0x15
    71db58900390:	or     r10d,r11d
    71db58900393:	and    edx,0x1
    71db58900396:	shl    edx,0x1c
    71db58900399:	or     r10d,edx
    71db5890039c:	btc    r10,0x1d
    71db589003a1:	mov    r11d,0xf0000000
    71db589003a7:	and    r11,r10
    71db589003aa:	movabs rsi,0xffffffff0fffffff
    71db589003b4:	and    rbx,rsi
    71db589003b7:	or     rbx,r11
    71db589003ba:	pop    r11
    71db589003bc:	pop    r10
    71db589003be:	pop    rsi
    71db589003bf:	pop    rdx
    71db589003c0:	mov    QWORD PTR [r12+0x108],rbx
    71db589003c8:	add    rsp,0x150
    71db589003cf:	mov    eax,0xc
    71db589003d4:	movabs r11,0x5bfd209f5ca0
    71db589003de:	jmp    r11
    71db589003e1:	mov    eax,0x410054
    71db589003e6:	mov    QWORD PTR [r12+0x100],rax
    71db589003ee:	push   rdx
    71db589003ef:	push   rsi
    71db589003f0:	push   r10
    71db589003f2:	push   r11
    71db589003f4:	mov    rdx,QWORD PTR [rsp+0x20]
    71db589003f9:	mov    r10d,edx
    71db589003fc:	and    r10d,0xc000
    71db58900403:	shl    r10d,0x10
    71db58900407:	mov    r11d,edx
    71db5890040a:	and    r11d,0x100
    71db58900411:	shl    r11d,0x15
    71db58900415:	or     r10d,r11d
    71db58900418:	and    edx,0x1
    71db5890041b:	shl    edx,0x1c
    71db5890041e:	or     r10d,edx
    71db58900421:	btc    r10,0x1d
    71db58900426:	mov    r11d,0xf0000000
    71db5890042c:	and    r11,r10
    71db5890042f:	movabs rsi,0xffffffff0fffffff
    71db58900439:	and    rbx,rsi
    71db5890043c:	or     rbx,r11
    71db5890043f:	pop    r11
    71db58900441:	pop    r10
    71db58900443:	pop    rsi
    71db58900444:	pop    rdx
    71db58900445:	mov    QWORD PTR [r12+0x108],rbx
    71db5890044d:	add    rsp,0x150
    71db58900454:	mov    eax,0xc
    71db58900459:	movabs r11,0x5bfd209f5ca0
    71db58900463:	jmp    r11
    71db58900466:	data16 nop WORD PTR [rax+rax*1+0x0]
    71db58900470:	sub    rsp,0x150
    71db58900477:	mov    r11,QWORD PTR [r12+0x398]
    71db5890047f:	mov    QWORD PTR [rsp],r11
    71db58900483:	cmp    DWORD PTR [r12+0x310],0x0
    71db5890048c:	je     0x71db58900517
    71db58900492:	push   rdx
    71db58900493:	push   rsi
    71db58900494:	push   r10
    71db58900496:	push   r11
    71db58900498:	mov    rdx,QWORD PTR [rsp+0x20]
    71db5890049d:	mov    r10d,edx
    71db589004a0:	and    r10d,0xc000
    71db589004a7:	shl    r10d,0x10
    71db589004ab:	mov    r11d,edx
    71db589004ae:	and    r11d,0x100
    71db589004b5:	shl    r11d,0x15
    71db589004b9:	or     r10d,r11d
    71db589004bc:	and    edx,0x1
    71db589004bf:	shl    edx,0x1c
    71db589004c2:	or     r10d,edx
    71db589004c5:	btc    r10,0x1d
    71db589004ca:	mov    r11d,0xf0000000
    71db589004d0:	and    r11,r10
    71db589004d3:	movabs rsi,0xffffffff0fffffff
    71db589004dd:	and    rbx,rsi
    71db589004e0:	or     rbx,r11
    71db589004e3:	pop    r11
    71db589004e5:	pop    r10
    71db589004e7:	pop    rsi
    71db589004e8:	pop    rdx
    71db589004e9:	mov    QWORD PTR [r12+0x108],rbx
    71db589004f1:	mov    eax,0x410044
    71db589004f6:	mov    QWORD PTR [r12+0x100],rax
    71db589004fe:	add    rsp,0x150
    71db58900505:	mov    eax,0x3
    71db5890050a:	movabs r11,0x5bfd209f5ca0
    71db58900514:	jmp    r11
    71db58900517:	jmp    0x71db5890013e
    71db5890051c:	nop    DWORD PTR [rax+0x0]
    71db58900520:	sub    rsp,0x150
    71db58900527:	mov    r11,QWORD PTR [r12+0x398]
    71db5890052f:	mov    QWORD PTR [rsp],r11
    71db58900533:	cmp    DWORD PTR [r12+0x310],0x0
    71db5890053c:	je     0x71db589005c7
    71db58900542:	push   rdx
    71db58900543:	push   rsi
    71db58900544:	push   r10
    71db58900546:	push   r11
    71db58900548:	mov    rdx,QWORD PTR [rsp+0x20]
    71db5890054d:	mov    r10d,edx
    71db58900550:	and    r10d,0xc000
    71db58900557:	shl    r10d,0x10
    71db5890055b:	mov    r11d,edx
    71db5890055e:	and    r11d,0x100
    71db58900565:	shl    r11d,0x15
    71db58900569:	or     r10d,r11d
    71db5890056c:	and    edx,0x1
    71db5890056f:	shl    edx,0x1c
    71db58900572:	or     r10d,edx
    71db58900575:	btc    r10,0x1d
    71db5890057a:	mov    r11d,0xf0000000
    71db58900580:	and    r11,r10
    71db58900583:	movabs rsi,0xffffffff0fffffff
    71db5890058d:	and    rbx,rsi
    71db58900590:	or     rbx,r11
    71db58900593:	pop    r11
    71db58900595:	pop    r10
    71db58900597:	pop    rsi
    71db58900598:	pop    rdx
    71db58900599:	mov    QWORD PTR [r12+0x108],rbx
    71db589005a1:	mov    eax,0x410050
    71db589005a6:	mov    QWORD PTR [r12+0x100],rax
    71db589005ae:	add    rsp,0x150
    71db589005b5:	mov    eax,0x3
    71db589005ba:	movabs r11,0x5bfd209f5ca0
    71db589005c4:	jmp    r11
    71db589005c7:	jmp    0x71db589001e8
    71db589005cc:	nop    DWORD PTR [rax+0x0]
    71db589005d0:	(bad)
    71db589005d1:	(bad)
    71db589005d2:	(bad)
    71db589005d3:	(bad)
    71db589005d4:	(bad)
    71db589005d5:	(bad)
    71db589005d6:	(bad)
    71db589005d7:	jg     0x71db589005d8
    71db589005d9:	(bad)
    71db589005da:	(bad)
    71db589005db:	(bad)
    71db589005dc:	(bad)
    71db589005dd:	(bad)
    71db589005de:	(bad)
    71db589005df:	jg     0x71db589005e1
    71db589005e1:	add    BYTE PTR [rax],al
    71db589005e3:	add    BYTE PTR [rax],al
    71db589005e5:	add    BYTE PTR [rax],dl
    71db589005e7:	add    BYTE PTR [rax],al
    71db589005e9:	add    BYTE PTR [rax],al
    71db589005eb:	add    BYTE PTR [rax],al
    71db589005ed:	add    BYTE PTR [rax],dl
	...
