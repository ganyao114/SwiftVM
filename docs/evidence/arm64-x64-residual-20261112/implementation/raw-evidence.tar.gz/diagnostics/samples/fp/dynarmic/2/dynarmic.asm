000071dc72bce69b  nop [rax+rax*1], eax
000071dc72bce6a0  mov qword ptr [r15+0x20], 0x420060
000071dc72bce6a8  mov qword ptr [r15], 0x00
000071dc72bce6af  vmovaps xmm1, [0x000071DC727FE010]
000071dc72bce6b7  movq xmm1, xmm1
000071dc72bce6bb  vmovaps xmm15, [0x000071DC727FE020]
000071dc72bce6c3  movq xmm15, xmm15
000071dc72bce6c8  movaps [r15+0x120], xmm15
000071dc72bce6d0  movq rax, xmm1
000071dc72bce6d5  movq r14, xmm15
000071dc72bce6da  vmovq xmm1, rax
000071dc72bce6df  vmovq xmm15, r14
000071dc72bce6e4  movaps xmm14, xmm1
000071dc72bce6e8  addsd xmm14, xmm15
000071dc72bce6ed  ucomisd xmm14, xmm14
000071dc72bce6f2  jp 0x000071DC72BCE791
000071dc72bce6f8  movq xmm14, xmm14
000071dc72bce6fd  movaps [r15+0x110], xmm14
000071dc72bce705  xor eax, eax
000071dc72bce707  mov r14d, 0xF4240
000071dc72bce70d  mov r12d, 0x01
000071dc72bce713  sub r14, r12
000071dc72bce716  cmc
000071dc72bce717  lahf
000071dc72bce718  seto al
000071dc72bce71b  mov [r15+0x108], eax
000071dc72bce722  mov [r15+0x08], r14
000071dc72bce726  mov eax, [r15+0x108]
000071dc72bce72d  sahf
000071dc72bce72e  jnz 0x000071DC72BCE760
000071dc72bce730  cmp dword ptr [r15+0x318], 0x00
000071dc72bce738  jz 0x000071DC72BCE910
000071dc72bce73e  nop [rax+rax*1], ax
000071dc72bce747  nop [rax+rax*1], eax
000071dc72bce74f  mov eax, 0x410050
000071dc72bce754  mov [r15+0x100], rax
000071dc72bce75b  jmp 0x000071DC729FE110
000071dc72bce760  cmp dword ptr [r15+0x318], 0x00
000071dc72bce768  jz 0x000071DC72BCE7E0
000071dc72bce76e  nop [rax+rax*1], ax
000071dc72bce777  nop [rax+rax*1], eax
000071dc72bce77f  mov eax, 0x410044
000071dc72bce784  mov [r15+0x100], rax
000071dc72bce78b  jmp 0x000071DC729FE110
000071dc72bce790  int3
000071dc72bce791  ucomisd xmm1, xmm15
000071dc72bce796  jp 0x000071DC72BCE7A5
000071dc72bce798  movaps xmm14, [0x000071DC727FE030]
000071dc72bce7a0  jmp 0x000071DC72BCE6F8
000071dc72bce7a5  vxorps xmm0, xmm1, xmm15
000071dc72bce7aa  pextrw eax, xmm0, 0x03
000071dc72bce7af  and eax, 0x7FF8
000071dc72bce7b4  cmp eax, 0x08
000071dc72bce7b7  jnz 0x000071DC72BCE6F8
000071dc72bce7bd  movq rax, xmm15
000071dc72bce7c2  shl rax, 0x0D
000071dc72bce7c6  jbe 0x000071DC72BCE6F8
000071dc72bce7cc  vorps xmm14, xmm15, [0x000071DC727FE040]
000071dc72bce7d4  jmp 0x000071DC72BCE6F8
000071dc72bce7d9  int3
000071dc72bce7da  nop [rax+rax*1], ax
000071dc72bce7e0  movaps xmm1, [r15+0x110]
000071dc72bce7e8  movq rax, xmm1
000071dc72bce7ed  movaps xmm1, [r15+0x120]
000071dc72bce7f5  movq r14, xmm1
000071dc72bce7fa  vmovq xmm1, rax
000071dc72bce7ff  vmovq xmm15, r14
000071dc72bce804  movaps xmm14, xmm1
000071dc72bce808  addsd xmm14, xmm15
000071dc72bce80d  ucomisd xmm14, xmm14
000071dc72bce812  jp 0x000071DC72BCE8B9
000071dc72bce818  movq xmm14, xmm14
000071dc72bce81d  movaps [r15+0x110], xmm14
000071dc72bce825  mov rax, [r15+0x08]
000071dc72bce829  mov [rsp+0x10], rax
000071dc72bce82e  xor eax, eax
000071dc72bce830  mov r14, [rsp+0x10]
000071dc72bce835  mov r12d, 0x01
000071dc72bce83b  sub r14, r12
000071dc72bce83e  cmc
000071dc72bce83f  lahf
000071dc72bce840  seto al
000071dc72bce843  mov [r15+0x108], eax
000071dc72bce84a  mov [r15+0x08], r14
000071dc72bce84e  mov eax, [r15+0x108]
000071dc72bce855  sahf
000071dc72bce856  jnz 0x000071DC72BCE888
000071dc72bce858  cmp dword ptr [r15+0x318], 0x00
000071dc72bce860  jz 0x000071DC72BCE910
000071dc72bce866  nop [rax+rax*1], ax
000071dc72bce86f  nop [rax+rax*1], eax
000071dc72bce877  mov eax, 0x410050
000071dc72bce87c  mov [r15+0x100], rax
000071dc72bce883  jmp 0x000071DC729FE110
000071dc72bce888  cmp dword ptr [r15+0x318], 0x00
000071dc72bce890  jz 0x000071DC72BCE7E0
000071dc72bce896  nop [rax+rax*1], ax
000071dc72bce89f  nop [rax+rax*1], eax
000071dc72bce8a7  mov eax, 0x410044
000071dc72bce8ac  mov [r15+0x100], rax
000071dc72bce8b3  jmp 0x000071DC729FE110
000071dc72bce8b8  int3
000071dc72bce8b9  ucomisd xmm1, xmm15
000071dc72bce8be  jp 0x000071DC72BCE8CD
000071dc72bce8c0  movaps xmm14, [0x000071DC727FE030]
000071dc72bce8c8  jmp 0x000071DC72BCE818
000071dc72bce8cd  vxorps xmm0, xmm1, xmm15
000071dc72bce8d2  pextrw eax, xmm0, 0x03
000071dc72bce8d7  and eax, 0x7FF8
000071dc72bce8dc  cmp eax, 0x08
000071dc72bce8df  jnz 0x000071DC72BCE818
000071dc72bce8e5  movq rax, xmm15
000071dc72bce8ea  shl rax, 0x0D
000071dc72bce8ee  jbe 0x000071DC72BCE818
000071dc72bce8f4  vorps xmm14, xmm15, [0x000071DC727FE040]
000071dc72bce8fc  jmp 0x000071DC72BCE818
000071dc72bce901  int3
000071dc72bce902  nop [rax+rax*1], ax
000071dc72bce90b  nop [rax+rax*1], eax
000071dc72bce910  mov rax, [r15+0x20]
000071dc72bce914  movaps xmm1, [r15+0x110]
000071dc72bce91c  movq r14, xmm1
000071dc72bce921  mov [r13+rax*1], r14
000071dc72bce926  mov rax, [r15+0xF0]
000071dc72bce92d  mov [r15+0x100], rax
000071dc72bce934  jmp 0x000071DC72BCE5C0
000071dc72bce939  int3
000071dc72bce93a  call 0x000071DC72A0E120
000071dc72bce93f  jmp 0x000071DC72BCE926
000071dc72bce944  int3
000071dc72bce945  nop [rax+rax*1], ax
000071dc72bce94e  nop
000071dc72bce950  mov qword ptr [r15+0x100], 0x04
000071dc72bce95b  mov esi, 0x00
000071dc72bce960  mov edx, 0x09
000071dc72bce965  mov rdi, 0x7FFE117A06D0
000071dc72bce96f  mov rax, 0x60D6B6CAC970
000071dc72bce979  call rax
000071dc72bce97b  cmp dword ptr [r15+0x318], 0x00
000071dc72bce983  jnz 0x000071DC729FE110
000071dc72bce989  jmp 0x000071DC729FE0A0
000071dc72bce98e  int3
000071dc72bce98f  int3
