
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-matrix/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

000072deb7300000 <.data>:
    72deb7300000:	sub    rsp,0x150
    72deb7300007:	mov    r11,QWORD PTR [r12+0x398]
    72deb730000f:	mov    QWORD PTR [rsp],r11
    72deb7300013:	cmp    DWORD PTR [r12+0x310],0x0
    72deb730001c:	je     0x72deb73000a7
    72deb7300022:	push   rdx
    72deb7300023:	push   rsi
    72deb7300024:	push   r10
    72deb7300026:	push   r11
    72deb7300028:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb730002d:	mov    r10d,edx
    72deb7300030:	and    r10d,0xc000
    72deb7300037:	shl    r10d,0x10
    72deb730003b:	mov    r11d,edx
    72deb730003e:	and    r11d,0x100
    72deb7300045:	shl    r11d,0x15
    72deb7300049:	or     r10d,r11d
    72deb730004c:	and    edx,0x1
    72deb730004f:	shl    edx,0x1c
    72deb7300052:	or     r10d,edx
    72deb7300055:	btc    r10,0x1d
    72deb730005a:	mov    r11d,0xf0000000
    72deb7300060:	and    r11,r10
    72deb7300063:	movabs rsi,0xffffffff0fffffff
    72deb730006d:	and    rbx,rsi
    72deb7300070:	or     rbx,r11
    72deb7300073:	pop    r11
    72deb7300075:	pop    r10
    72deb7300077:	pop    rsi
    72deb7300078:	pop    rdx
    72deb7300079:	mov    QWORD PTR [r12+0x108],rbx
    72deb7300081:	mov    eax,0x410168
    72deb7300086:	mov    QWORD PTR [r12+0x100],rax
    72deb730008e:	add    rsp,0x150
    72deb7300095:	mov    eax,0x3
    72deb730009a:	movabs r11,0x5b63a40e2ca0
    72deb73000a4:	jmp    r11
    72deb73000a7:	mov    r13d,0x420000
    72deb73000ad:	mov    QWORD PTR [r12+0x40],r13
    72deb73000b2:	movabs r13,0x100000001
    72deb73000bc:	mov    r14d,0x0
    72deb73000c2:	mov    QWORD PTR [r12+0x110],r13
    72deb73000ca:	mov    QWORD PTR [r12+0x118],r14
    72deb73000d2:	movabs r13,0x3fa0000000000000
    72deb73000dc:	mov    QWORD PTR [r12+0x50],r13
    72deb73000e1:	movabs r13,0x4100000041
    72deb73000eb:	mov    r14d,0x0
    72deb73000f1:	mov    QWORD PTR [r12+0x120],r13
    72deb73000f9:	mov    QWORD PTR [r12+0x128],r14
    72deb7300101:	mov    r13d,0x4204c0
    72deb7300107:	mov    r14,QWORD PTR [r13+0x0]
    72deb730010b:	mov    r13d,0x0
    72deb7300111:	mov    QWORD PTR [r12+0x130],r14
    72deb7300119:	mov    QWORD PTR [r12+0x138],r13
    72deb7300121:	movabs r13,0x3fc0000000000000
    72deb730012b:	movabs r14,0x3fc0000000000000
    72deb7300135:	mov    QWORD PTR [r12+0x140],r13
    72deb730013d:	mov    QWORD PTR [r12+0x148],r14
    72deb7300145:	mov    r13d,0x2
    72deb730014b:	mov    QWORD PTR [r12+0x40],r13
    72deb7300150:	movabs r13,0x200000002
    72deb730015a:	mov    r14d,0x0
    72deb7300160:	mov    QWORD PTR [r12+0x150],r13
    72deb7300168:	mov    QWORD PTR [r12+0x158],r14
    72deb7300170:	mov    r13d,0x420000
    72deb7300176:	mov    QWORD PTR [r12+0x58],r13
    72deb730017b:	movabs r13,0x3fa0000000000000
    72deb7300185:	mov    QWORD PTR [r12+0x160],r13
    72deb730018d:	mov    QWORD PTR [r12+0x168],r13
    72deb7300195:	mov    r13d,0x2
    72deb730019b:	mov    QWORD PTR [r12+0x170],r13
    72deb73001a3:	mov    QWORD PTR [r12+0x178],r13
    72deb73001ab:	mov    r13d,0x4204d0
    72deb73001b1:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    72deb73001b7:	movdqu XMMWORD PTR [r12+0x180],xmm2
    72deb73001c1:	mov    r13d,0x0
    72deb73001c7:	mov    QWORD PTR [r12+0x48],r13
    72deb73001cc:	mov    r13d,0x430000
    72deb73001d2:	add    r13,0x518
    72deb73001d9:	mov    QWORD PTR [r12+0x40],r13
    72deb73001de:	mov    r13d,0x430000
    72deb73001e4:	add    r13,0x720
    72deb73001eb:	mov    QWORD PTR [r12+0x50],r13
    72deb73001f0:	mov    r11,rax
    72deb73001f3:	movzx  eax,WORD PTR [rsp]
    72deb73001f7:	add    al,0x7f
    72deb73001f9:	sahf
    72deb73001fa:	mov    rax,r11
    72deb73001fd:	jmp    0x72deb7300202
    72deb7300202:	mov    r13,QWORD PTR [r12+0x180]
    72deb730020a:	mov    r14,QWORD PTR [r12+0x188]
    72deb7300212:	mov    r15d,0x0
    72deb7300218:	mov    r11,rax
    72deb730021b:	lahf
    72deb730021c:	seto   al
    72deb730021f:	mov    WORD PTR [rsp],ax
    72deb7300223:	mov    rax,r11
    72deb7300226:	mov    ecx,0xffffffff
    72deb730022b:	and    r13,rcx
    72deb730022e:	mov    rbp,r15
    72deb7300231:	or     rbp,r13
    72deb7300234:	mov    ecx,0xffffffff
    72deb7300239:	and    r14,rcx
    72deb730023c:	shl    r14,0x20
    72deb7300240:	or     rbp,r14
    72deb7300243:	mov    QWORD PTR [r12+0x210],rbp
    72deb730024b:	mov    QWORD PTR [r12+0x218],r15
    72deb7300253:	movdqu xmm2,XMMWORD PTR [r12+0x120]
    72deb730025d:	movdqu xmm3,XMMWORD PTR [r12+0x130]
    72deb7300267:	movdqa xmm1,xmm3
    72deb730026b:	psubd  xmm2,xmm1
    72deb730026f:	movdqa xmm14,xmm2
    72deb7300274:	movdqa xmm1,xmm14
    72deb7300279:	movq   rax,xmm1
    72deb730027e:	mov    r13,rax
    72deb7300281:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    72deb730028b:	movdqu xmm4,XMMWORD PTR [r12+0x170]
    72deb7300295:	movdqa xmm1,xmm4
    72deb7300299:	paddq  xmm2,xmm1
    72deb730029d:	movdqu XMMWORD PTR [r12+0x180],xmm2
    72deb73002a7:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    72deb73002b1:	movdqa xmm1,xmm2
    72deb73002b5:	paddd  xmm3,xmm1
    72deb73002b9:	movdqa xmm14,xmm3
    72deb73002be:	movdqa xmm1,xmm14
    72deb73002c3:	movq   rax,xmm1
    72deb73002c8:	mov    r14,rax
    72deb73002cb:	mov    r15d,0x0
    72deb73002d1:	mov    QWORD PTR [r12+0x130],r14
    72deb73002d9:	mov    QWORD PTR [r12+0x138],r15
    72deb73002e1:	mov    r14d,0x0
    72deb73002e7:	mov    ecx,0xffffffff
    72deb73002ec:	mov    r15,r13
    72deb73002ef:	and    r15,rcx
    72deb73002f2:	mov    rbp,r14
    72deb73002f5:	or     rbp,r15
    72deb73002f8:	shr    r13,0x20
    72deb73002fc:	mov    ecx,0xffffffff
    72deb7300301:	and    r13,rcx
    72deb7300304:	or     r14,r13
    72deb7300307:	mov    QWORD PTR [r12+0x220],rbp
    72deb730030f:	mov    QWORD PTR [r12+0x228],r14
    72deb7300317:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    72deb7300321:	movdqu xmm3,XMMWORD PTR [r12+0x110]
    72deb730032b:	movdqa xmm1,xmm3
    72deb730032f:	paddd  xmm2,xmm1
    72deb7300333:	movdqa xmm14,xmm2
    72deb7300338:	movdqa xmm1,xmm14
    72deb730033d:	movq   rax,xmm1
    72deb7300342:	mov    r13,rax
    72deb7300345:	mov    r14d,0x0
    72deb730034b:	mov    QWORD PTR [r12+0x210],r13
    72deb7300353:	mov    QWORD PTR [r12+0x218],r14
    72deb730035b:	lea    r13,[r12]
    72deb730035f:	movabs r14,0xb6e61da31
    72deb7300369:	mov    r15d,0x4101c4
    72deb730036f:	mov    rdx,QWORD PTR [rsp]
    72deb7300373:	mov    r10d,edx
    72deb7300376:	and    r10d,0xc000
    72deb730037d:	shl    r10d,0x10
    72deb7300381:	mov    r11d,edx
    72deb7300384:	and    r11d,0x100
    72deb730038b:	shl    r11d,0x15
    72deb730038f:	or     r10d,r11d
    72deb7300392:	and    edx,0x1
    72deb7300395:	shl    edx,0x1c
    72deb7300398:	or     r10d,edx
    72deb730039b:	btc    r10,0x1d
    72deb73003a0:	mov    r11d,0xf0000000
    72deb73003a6:	and    r11,r10
    72deb73003a9:	movabs rsi,0xffffffff0fffffff
    72deb73003b3:	and    rbx,rsi
    72deb73003b6:	or     rbx,r11
    72deb73003b9:	mov    QWORD PTR [r12+0x378],0x3
    72deb73003c5:	mov    QWORD PTR [r12+0x108],rbx
    72deb73003cd:	stmxcsr DWORD PTR [r12-0x28]
    72deb73003d3:	mov    r10d,DWORD PTR [r12-0x28]
    72deb73003d8:	test   r10d,0x3f
    72deb73003df:	je     0x72deb7300404
    72deb73003e5:	mov    r11d,r10d
    72deb73003e8:	shr    r10d,1
    72deb73003eb:	and    r10d,0x1e
    72deb73003ef:	and    r11d,0x1
    72deb73003f3:	or     r10d,r11d
    72deb73003f6:	or     DWORD PTR [r12+0x314],r10d
    72deb73003fe:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7300404:	ldmxcsr DWORD PTR [r12-0x38]
    72deb730040a:	movabs r11,0x5b63a3f445e0
    72deb7300414:	mov    rdi,r13
    72deb7300417:	mov    rsi,r14
    72deb730041a:	mov    rdx,r15
    72deb730041d:	call   r11
    72deb7300420:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7300426:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730042e:	mov    QWORD PTR [r12+0x378],0x2
    72deb730043a:	mov    rbp,rax
    72deb730043d:	mov    r13,QWORD PTR [r12+0x210]
    72deb7300445:	mov    r14d,0x0
    72deb730044b:	mov    ecx,0xffffffff
    72deb7300450:	mov    r15,r13
    72deb7300453:	and    r15,rcx
    72deb7300456:	mov    rbp,r14
    72deb7300459:	or     rbp,r15
    72deb730045c:	shr    r13,0x20
    72deb7300460:	mov    ecx,0xffffffff
    72deb7300465:	and    r13,rcx
    72deb7300468:	or     r14,r13
    72deb730046b:	mov    QWORD PTR [r12+0x210],rbp
    72deb7300473:	mov    QWORD PTR [r12+0x218],r14
    72deb730047b:	lea    r13,[r12]
    72deb730047f:	movabs r14,0xb6e61da10
    72deb7300489:	mov    r15d,0x4101cc
    72deb730048f:	mov    QWORD PTR [r12+0x378],0x3
    72deb730049b:	mov    QWORD PTR [r12+0x108],rbx
    72deb73004a3:	stmxcsr DWORD PTR [r12-0x28]
    72deb73004a9:	mov    r10d,DWORD PTR [r12-0x28]
    72deb73004ae:	test   r10d,0x3f
    72deb73004b5:	je     0x72deb73004da
    72deb73004bb:	mov    r11d,r10d
    72deb73004be:	shr    r10d,1
    72deb73004c1:	and    r10d,0x1e
    72deb73004c5:	and    r11d,0x1
    72deb73004c9:	or     r10d,r11d
    72deb73004cc:	or     DWORD PTR [r12+0x314],r10d
    72deb73004d4:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73004da:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73004e0:	movabs r11,0x5b63a3f445e0
    72deb73004ea:	mov    rdi,r13
    72deb73004ed:	mov    rsi,r14
    72deb73004f0:	mov    rdx,r15
    72deb73004f3:	call   r11
    72deb73004f6:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73004fc:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7300504:	mov    QWORD PTR [r12+0x378],0x2
    72deb7300510:	mov    rbp,rax
    72deb7300513:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    72deb730051d:	movdqu xmm3,XMMWORD PTR [r12+0x140]
    72deb7300527:	movdqa xmm0,xmm2
    72deb730052b:	movdqa xmm1,xmm3
    72deb730052f:	mulpd  xmm0,xmm1
    72deb7300533:	movdqa xmm14,xmm0
    72deb7300538:	movdqu xmm15,XMMWORD PTR [rip+0x9d4f]        # 0x72deb730a290
    72deb7300541:	pand   xmm14,xmm15
    72deb7300546:	movdqu xmm15,XMMWORD PTR [rip+0x9d51]        # 0x72deb730a2a0
    72deb730054f:	pcmpeqq xmm14,xmm15
    72deb7300555:	movdqa xmm15,xmm0
    72deb730055a:	cmpunordpd xmm15,xmm0
    72deb7300560:	por    xmm14,xmm15
    72deb7300565:	pmovmskb ecx,xmm14
    72deb730056a:	jrcxz  0x72deb7300571
    72deb730056c:	jmp    0x72deb7302bee
    72deb7300571:	movdqa xmm4,xmm0
    72deb7300575:	movdqu XMMWORD PTR [r12+0x220],xmm4
    72deb730057f:	mov    r13,QWORD PTR [r12+0x48]
    72deb7300584:	mov    r14,QWORD PTR [r12+0x50]
    72deb7300589:	add    r14,r13
    72deb730058c:	movdqu XMMWORD PTR [r14],xmm4
    72deb7300591:	mov    r14d,0x0
    72deb7300597:	mov    DWORD PTR [r12+0x32c],r14d
    72deb730059f:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    72deb73005a9:	movdqu xmm3,XMMWORD PTR [r12+0x160]
    72deb73005b3:	movdqa xmm0,xmm2
    72deb73005b7:	movdqa xmm1,xmm3
    72deb73005bb:	mulpd  xmm0,xmm1
    72deb73005bf:	movdqa xmm14,xmm0
    72deb73005c4:	movdqu xmm15,XMMWORD PTR [rip+0x9cc3]        # 0x72deb730a290
    72deb73005cd:	pand   xmm14,xmm15
    72deb73005d2:	movdqu xmm15,XMMWORD PTR [rip+0x9cc5]        # 0x72deb730a2a0
    72deb73005db:	pcmpeqq xmm14,xmm15
    72deb73005e1:	movdqa xmm15,xmm0
    72deb73005e6:	cmpunordpd xmm15,xmm0
    72deb73005ec:	por    xmm14,xmm15
    72deb73005f1:	pmovmskb ecx,xmm14
    72deb73005f6:	jrcxz  0x72deb73005fd
    72deb73005f8:	jmp    0x72deb7302c12
    72deb73005fd:	movdqa xmm4,xmm0
    72deb7300601:	movdqu XMMWORD PTR [r12+0x210],xmm4
    72deb730060b:	mov    r14,QWORD PTR [r12+0x40]
    72deb7300610:	add    r14,r13
    72deb7300613:	movdqu XMMWORD PTR [r14],xmm4
    72deb7300618:	add    r13,0x10
    72deb730061c:	mov    QWORD PTR [r12+0x48],r13
    72deb7300621:	sub    r13,0x200
    72deb7300628:	mov    rcx,QWORD PTR [r12+0x380]
    72deb7300630:	jrcxz  0x72deb7300637
    72deb7300632:	jmp    0x72deb7309a25
    72deb7300637:	jne    0x72deb7300202
    72deb730063d:	mov    r11,rax
    72deb7300640:	lahf
    72deb7300641:	seto   al
    72deb7300644:	mov    WORD PTR [rsp],ax
    72deb7300648:	mov    rax,r11
    72deb730064b:	jmp    0x72deb7300650
    72deb7300650:	mov    r13,QWORD PTR [r12+0xf8]
    72deb7300658:	sub    r13,0x150
    72deb730065f:	mov    QWORD PTR [r12+0xf8],r13
    72deb7300667:	mov    r14,QWORD PTR [r12+0x50]
    72deb730066c:	mov    r15,r14
    72deb730066f:	add    r15,0x80
    72deb7300676:	mov    rbp,r15
    72deb7300679:	add    rbp,0x10
    72deb730067d:	movdqu xmm2,XMMWORD PTR [r15]
    72deb7300682:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72deb7300687:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72deb7300691:	movdqu XMMWORD PTR [r12+0x110],xmm3
    72deb730069b:	mov    r15d,0x0
    72deb73006a1:	mov    QWORD PTR [r12+0x48],r15
    72deb73006a6:	mov    r15,r14
    72deb73006a9:	add    r15,0x40
    72deb73006ad:	mov    rbp,r15
    72deb73006b0:	add    rbp,0x10
    72deb73006b4:	movdqu xmm4,XMMWORD PTR [r15]
    72deb73006b9:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    72deb73006be:	movdqu XMMWORD PTR [r12+0x250],xmm4
    72deb73006c8:	movdqu XMMWORD PTR [r12+0x120],xmm5
    72deb73006d2:	mov    r15,r13
    72deb73006d5:	add    r15,0x120
    72deb73006dc:	mov    rbp,r15
    72deb73006df:	add    rbp,0x8
    72deb73006e3:	mov    r8,QWORD PTR [r12+0x1c0]
    72deb73006eb:	mov    r9,QWORD PTR [r12+0x1b0]
    72deb73006f3:	mov    QWORD PTR [r15],r8
    72deb73006f6:	mov    r15d,0x0
    72deb73006fc:	mov    DWORD PTR [r12+0x32c],r15d
    72deb7300704:	mov    QWORD PTR [rbp+0x0],r9
    72deb7300708:	mov    r15d,0x0
    72deb730070e:	mov    ebp,0x0
    72deb7300713:	mov    QWORD PTR [r12+0x1b0],r15
    72deb730071b:	mov    QWORD PTR [r12+0x1b8],rbp
    72deb7300723:	mov    r15,r13
    72deb7300726:	add    r15,0x100
    72deb730072d:	mov    rbp,r15
    72deb7300730:	add    rbp,0x8
    72deb7300734:	mov    r8,QWORD PTR [r12+0x200]
    72deb730073c:	mov    r9,QWORD PTR [r12+0x1f0]
    72deb7300744:	mov    QWORD PTR [r15],r8
    72deb7300747:	mov    QWORD PTR [rbp+0x0],r9
    72deb730074b:	mov    r15,r13
    72deb730074e:	add    r15,0xe0
    72deb7300755:	mov    rbp,r15
    72deb7300758:	add    rbp,0x10
    72deb730075c:	movdqu XMMWORD PTR [r15],xmm3
    72deb7300761:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72deb7300766:	mov    r15,r14
    72deb7300769:	add    r15,0xc0
    72deb7300770:	mov    rbp,r15
    72deb7300773:	add    rbp,0x10
    72deb7300777:	movdqu xmm2,XMMWORD PTR [r15]
    72deb730077c:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72deb7300781:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72deb730078b:	movdqu XMMWORD PTR [r12+0x110],xmm3
    72deb7300795:	mov    r15,r13
    72deb7300798:	add    r15,0x110
    72deb730079f:	mov    rbp,r15
    72deb73007a2:	add    rbp,0x8
    72deb73007a6:	mov    r8,QWORD PTR [r12+0x1e0]
    72deb73007ae:	mov    r9,QWORD PTR [r12+0x1d0]
    72deb73007b6:	mov    QWORD PTR [r15],r8
    72deb73007b9:	mov    QWORD PTR [rbp+0x0],r9
    72deb73007bd:	mov    r15,r14
    72deb73007c0:	add    r15,0x10
    72deb73007c4:	movdqu xmm4,XMMWORD PTR [r14]
    72deb73007c9:	movdqu xmm6,XMMWORD PTR [r15]
    72deb73007ce:	movdqu XMMWORD PTR [r12+0x170],xmm4
    72deb73007d8:	movdqu XMMWORD PTR [r12+0x180],xmm6
    72deb73007e2:	mov    r15,r13
    72deb73007e5:	add    r15,0x130
    72deb73007ec:	mov    rbp,r15
    72deb73007ef:	add    rbp,0x8
    72deb73007f3:	mov    r8,QWORD PTR [r12+0x1a0]
    72deb73007fb:	mov    r9,QWORD PTR [r12+0x190]
    72deb7300803:	mov    QWORD PTR [r15],r8
    72deb7300806:	mov    QWORD PTR [rbp+0x0],r9
    72deb730080a:	mov    r15,r14
    72deb730080d:	add    r15,0x140
    72deb7300814:	mov    rbp,r15
    72deb7300817:	add    rbp,0x10
    72deb730081b:	movdqu xmm7,XMMWORD PTR [r15]
    72deb7300820:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    72deb7300826:	movdqu XMMWORD PTR [r12+0x270],xmm7
    72deb7300830:	movdqu XMMWORD PTR [r12+0x190],xmm8
    72deb730083a:	mov    r15,r13
    72deb730083d:	add    r15,0xc0
    72deb7300844:	mov    rbp,r15
    72deb7300847:	add    rbp,0x10
    72deb730084b:	movdqu XMMWORD PTR [r15],xmm3
    72deb7300850:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72deb7300855:	mov    r15,r14
    72deb7300858:	add    r15,0x100
    72deb730085f:	mov    rbp,r15
    72deb7300862:	add    rbp,0x10
    72deb7300866:	movdqu xmm2,XMMWORD PTR [r15]
    72deb730086b:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72deb7300870:	movdqu XMMWORD PTR [r12+0x110],xmm2
    72deb730087a:	movdqu XMMWORD PTR [r12+0x300],xmm3
    72deb7300884:	mov    r15,r13
    72deb7300887:	add    r15,0x140
    72deb730088e:	mov    rbp,QWORD PTR [r12+0xe8]
    72deb7300896:	mov    QWORD PTR [r15],rbp
    72deb7300899:	mov    r15,r14
    72deb730089c:	add    r15,0x180
    72deb73008a3:	mov    rbp,r15
    72deb73008a6:	add    rbp,0x10
    72deb73008aa:	movdqu xmm3,XMMWORD PTR [r15]
    72deb73008af:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    72deb73008b4:	movdqu XMMWORD PTR [r12+0x2a0],xmm3
    72deb73008be:	movdqu XMMWORD PTR [r12+0x1a0],xmm7
    72deb73008c8:	mov    r15,r14
    72deb73008cb:	add    r15,0x1c0
    72deb73008d2:	mov    rbp,r15
    72deb73008d5:	add    rbp,0x10
    72deb73008d9:	movdqu xmm3,XMMWORD PTR [r15]
    72deb73008de:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    72deb73008e3:	movdqu XMMWORD PTR [r12+0x240],xmm3
    72deb73008ed:	movdqu XMMWORD PTR [r12+0x1c0],xmm7
    72deb73008f7:	mov    r15,r13
    72deb73008fa:	add    r15,0x20
    72deb73008fe:	mov    rbp,r15
    72deb7300901:	add    rbp,0x10
    72deb7300905:	movdqu XMMWORD PTR [r15],xmm2
    72deb730090a:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    72deb730090f:	mov    r15,r14
    72deb7300912:	add    r15,0x60
    72deb7300916:	mov    rbp,r15
    72deb7300919:	add    rbp,0x10
    72deb730091d:	movdqu xmm2,XMMWORD PTR [r15]
    72deb7300922:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    72deb7300927:	movdqu XMMWORD PTR [r12+0x110],xmm2
    72deb7300931:	movdqu XMMWORD PTR [r12+0x120],xmm5
    72deb730093b:	mov    r15,r14
    72deb730093e:	add    r15,0x20
    72deb7300942:	mov    rbp,r15
    72deb7300945:	add    rbp,0x10
    72deb7300949:	movdqu xmm7,XMMWORD PTR [r15]
    72deb730094e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    72deb7300954:	movdqu XMMWORD PTR [r12+0x1d0],xmm7
    72deb730095e:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
    72deb7300968:	mov    r15,r13
    72deb730096b:	add    r15,0x60
    72deb730096f:	mov    rbp,r15
    72deb7300972:	add    rbp,0x10
    72deb7300976:	movdqu XMMWORD PTR [r15],xmm4
    72deb730097b:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    72deb7300980:	mov    r15,r14
    72deb7300983:	add    r15,0xe0
    72deb730098a:	mov    rbp,r15
    72deb730098d:	add    rbp,0x10
    72deb7300991:	movdqu xmm3,XMMWORD PTR [r15]
    72deb7300996:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    72deb730099b:	movdqu XMMWORD PTR [r12+0x200],xmm3
    72deb73009a5:	movdqu XMMWORD PTR [r12+0x2d0],xmm4
    72deb73009af:	mov    r15,r13
    72deb73009b2:	add    r15,0xa0
    72deb73009b9:	mov    rbp,r15
    72deb73009bc:	add    rbp,0x10
    72deb73009c0:	movdqu XMMWORD PTR [r15],xmm5
    72deb73009c5:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72deb73009ca:	mov    r15,r14
    72deb73009cd:	add    r15,0xa0
    72deb73009d4:	mov    rbp,r15
    72deb73009d7:	add    rbp,0x10
    72deb73009db:	movdqu xmm2,XMMWORD PTR [r15]
    72deb73009e0:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72deb73009e5:	movdqu XMMWORD PTR [r12+0x110],xmm2
    72deb73009ef:	movdqu XMMWORD PTR [r12+0x120],xmm3
    72deb73009f9:	mov    r15,r14
    72deb73009fc:	add    r15,0x120
    72deb7300a03:	mov    rbp,r15
    72deb7300a06:	add    rbp,0x10
    72deb7300a0a:	movdqu xmm4,XMMWORD PTR [r15]
    72deb7300a0f:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    72deb7300a14:	movdqu XMMWORD PTR [r12+0x2e0],xmm4
    72deb7300a1e:	movdqu XMMWORD PTR [r12+0x2f0],xmm5
    72deb7300a28:	mov    r15,r14
    72deb7300a2b:	add    r15,0x160
    72deb7300a32:	mov    rbp,r15
    72deb7300a35:	add    rbp,0x10
    72deb7300a39:	movdqu xmm4,XMMWORD PTR [r15]
    72deb7300a3e:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    72deb7300a43:	movdqu XMMWORD PTR [r12+0x2c0],xmm4
    72deb7300a4d:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
    72deb7300a57:	mov    r15,r13
    72deb7300a5a:	add    r15,0x80
    72deb7300a61:	mov    rbp,r15
    72deb7300a64:	add    rbp,0x10
    72deb7300a68:	movdqu XMMWORD PTR [r15],xmm3
    72deb7300a6d:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72deb7300a72:	mov    r15,r14
    72deb7300a75:	add    r15,0x1a0
    72deb7300a7c:	mov    rbp,r15
    72deb7300a7f:	add    rbp,0x10
    72deb7300a83:	movdqu xmm2,XMMWORD PTR [r15]
    72deb7300a88:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72deb7300a8d:	movdqu XMMWORD PTR [r12+0x290],xmm2
    72deb7300a97:	movdqu XMMWORD PTR [r12+0x1e0],xmm3
    72deb7300aa1:	add    r14,0x1e0
    72deb7300aa8:	mov    r15,r14
    72deb7300aab:	add    r15,0x10
    72deb7300aaf:	movdqu xmm2,XMMWORD PTR [r14]
    72deb7300ab4:	movdqu xmm3,XMMWORD PTR [r15]
    72deb7300ab9:	movdqu XMMWORD PTR [r12+0x230],xmm2
    72deb7300ac3:	movdqu XMMWORD PTR [r12+0x280],xmm3
    72deb7300acd:	mov    r14d,0x430000
    72deb7300ad3:	add    r14,0x920
    72deb7300ada:	mov    QWORD PTR [r12+0x50],r14
    72deb7300adf:	mov    r14,r13
    72deb7300ae2:	add    r14,0x40
    72deb7300ae6:	mov    r15,r14
    72deb7300ae9:	add    r15,0x10
    72deb7300aed:	movdqu XMMWORD PTR [r14],xmm4
    72deb7300af2:	movdqu XMMWORD PTR [r15],xmm6
    72deb7300af7:	mov    r14,r13
    72deb7300afa:	add    r14,0x10
    72deb7300afe:	movdqu XMMWORD PTR [r13+0x0],xmm3
    72deb7300b04:	movdqu XMMWORD PTR [r14],xmm2
    72deb7300b09:	mov    r11,rax
    72deb7300b0c:	movzx  eax,WORD PTR [rsp]
    72deb7300b10:	add    al,0x7f
    72deb7300b12:	sahf
    72deb7300b13:	mov    rax,r11
    72deb7300b16:	jmp    0x72deb7300b1b
    72deb7300b1b:	mov    r13d,0x0
    72deb7300b21:	mov    QWORD PTR [r12+0x58],r13
    72deb7300b26:	mov    r11,rax
    72deb7300b29:	lahf
    72deb7300b2a:	seto   al
    72deb7300b2d:	mov    WORD PTR [rsp],ax
    72deb7300b31:	mov    rax,r11
    72deb7300b34:	jmp    0x72deb7300b39
    72deb7300b39:	mov    r13,QWORD PTR [r12+0x58]
    72deb7300b3e:	mov    r14,QWORD PTR [r12+0x40]
    72deb7300b43:	add    r14,r13
    72deb7300b46:	mov    QWORD PTR [r12+0x60],r14
    72deb7300b4b:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    72deb7300b55:	movdqa xmm0,xmm2
    72deb7300b59:	movdqa xmm1,xmm2
    72deb7300b5d:	por    xmm0,xmm1
    72deb7300b61:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    72deb7300b6b:	movdqu xmm4,XMMWORD PTR [r12+0x1a0]
    72deb7300b75:	movdqa xmm0,xmm4
    72deb7300b79:	movdqa xmm1,xmm4
    72deb7300b7d:	por    xmm0,xmm1
    72deb7300b81:	movdqu XMMWORD PTR [r12+0x120],xmm0
    72deb7300b8b:	mov    r15,r14
    72deb7300b8e:	add    r15,0x30
    72deb7300b92:	mov    rbp,r15
    72deb7300b95:	add    rbp,0x8
    72deb7300b99:	mov    r8,QWORD PTR [r15]
    72deb7300b9c:	mov    r15,QWORD PTR [rbp+0x0]
    72deb7300ba0:	mov    ebp,0x0
    72deb7300ba5:	mov    QWORD PTR [r12+0x130],r8
    72deb7300bad:	mov    QWORD PTR [r12+0x138],rbp
    72deb7300bb5:	mov    ebp,0x0
    72deb7300bba:	mov    QWORD PTR [r12+0x280],r15
    72deb7300bc2:	mov    QWORD PTR [r12+0x288],rbp
    72deb7300bca:	movdqu xmm5,XMMWORD PTR [r12+0x270]
    72deb7300bd4:	movdqa xmm0,xmm5
    72deb7300bd8:	movdqa xmm1,xmm5
    72deb7300bdc:	por    xmm0,xmm1
    72deb7300be0:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    72deb7300bea:	mov    r15,r14
    72deb7300bed:	add    r15,0x20
    72deb7300bf1:	mov    rbp,r15
    72deb7300bf4:	add    rbp,0x8
    72deb7300bf8:	mov    r8,QWORD PTR [r15]
    72deb7300bfb:	mov    r15,QWORD PTR [rbp+0x0]
    72deb7300bff:	mov    ebp,0x0
    72deb7300c04:	mov    QWORD PTR [r12+0x150],r8
    72deb7300c0c:	mov    QWORD PTR [r12+0x158],rbp
    72deb7300c14:	mov    ebp,0x0
    72deb7300c19:	mov    QWORD PTR [r12+0x140],r15
    72deb7300c21:	mov    QWORD PTR [r12+0x148],rbp
    72deb7300c29:	mov    r15,r14
    72deb7300c2c:	add    r15,0x10
    72deb7300c30:	mov    rbp,r15
    72deb7300c33:	add    rbp,0x8
    72deb7300c37:	mov    r8,QWORD PTR [r15]
    72deb7300c3a:	mov    r15,QWORD PTR [rbp+0x0]
    72deb7300c3e:	mov    ebp,0x0
    72deb7300c43:	mov    QWORD PTR [r12+0x170],r8
    72deb7300c4b:	mov    QWORD PTR [r12+0x178],rbp
    72deb7300c53:	mov    ebp,0x0
    72deb7300c58:	mov    QWORD PTR [r12+0x160],r15
    72deb7300c60:	mov    QWORD PTR [r12+0x168],rbp
    72deb7300c68:	mov    r15d,0x8
    72deb7300c6e:	mov    rbp,QWORD PTR [r14]
    72deb7300c71:	mov    QWORD PTR [r12+0x180],rbp
    72deb7300c79:	mov    QWORD PTR [r12+0x188],rbp
    72deb7300c81:	add    r14,r15
    72deb7300c84:	mov    QWORD PTR [r12+0x60],r14
    72deb7300c89:	mov    r15,QWORD PTR [r14]
    72deb7300c8c:	mov    r14d,0x0
    72deb7300c92:	mov    QWORD PTR [r12+0x230],r15
    72deb7300c9a:	mov    QWORD PTR [r12+0x238],r14
    72deb7300ca2:	mov    r14,QWORD PTR [r12+0xf8]
    72deb7300caa:	mov    r15,r14
    72deb7300cad:	add    r15,0x50
    72deb7300cb1:	mov    rbp,r15
    72deb7300cb4:	add    rbp,0x10
    72deb7300cb8:	movdqu xmm6,XMMWORD PTR [r15]
    72deb7300cbd:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    72deb7300cc2:	movdqu XMMWORD PTR [r12+0x220],xmm6
    72deb7300ccc:	movdqu XMMWORD PTR [r12+0x210],xmm7
    72deb7300cd6:	mov    r15,r14
    72deb7300cd9:	add    r15,0x30
    72deb7300cdd:	movdqu xmm8,XMMWORD PTR [r15]
    72deb7300ce2:	movdqu XMMWORD PTR [r12+0x110],xmm8
    72deb7300cec:	mov    r15,QWORD PTR [r12+0x50]
    72deb7300cf1:	add    r15,r13
    72deb7300cf4:	mov    QWORD PTR [r12+0x60],r15
    72deb7300cf9:	add    r13,0x40
    72deb7300cfd:	mov    QWORD PTR [r12+0x58],r13
    72deb7300d02:	movdqu xmm9,XMMWORD PTR [r12+0x180]
    72deb7300d0c:	movdqa xmm0,xmm9
    72deb7300d11:	movdqa xmm1,xmm2
    72deb7300d15:	mulpd  xmm0,xmm1
    72deb7300d19:	movdqa xmm14,xmm0
    72deb7300d1e:	movdqu xmm15,XMMWORD PTR [rip+0x9569]        # 0x72deb730a290
    72deb7300d27:	pand   xmm14,xmm15
    72deb7300d2c:	movdqu xmm15,XMMWORD PTR [rip+0x956b]        # 0x72deb730a2a0
    72deb7300d35:	pcmpeqq xmm14,xmm15
    72deb7300d3b:	movdqa xmm15,xmm0
    72deb7300d40:	cmpunordpd xmm15,xmm0
    72deb7300d46:	por    xmm14,xmm15
    72deb7300d4b:	pmovmskb ecx,xmm14
    72deb7300d50:	jrcxz  0x72deb7300d57
    72deb7300d52:	jmp    0x72deb7302c36
    72deb7300d57:	movdqa xmm10,xmm0
    72deb7300d5c:	movdqu xmm2,XMMWORD PTR [r12+0x230]
    72deb7300d66:	movdqa xmm0,xmm8
    72deb7300d6b:	movdqa xmm1,xmm2
    72deb7300d6f:	pshufd xmm1,xmm1,0x44
    72deb7300d74:	mulpd  xmm0,xmm1
    72deb7300d78:	movdqa xmm14,xmm0
    72deb7300d7d:	movdqu xmm15,XMMWORD PTR [rip+0x950a]        # 0x72deb730a290
    72deb7300d86:	pand   xmm14,xmm15
    72deb7300d8b:	movdqu xmm15,XMMWORD PTR [rip+0x950c]        # 0x72deb730a2a0
    72deb7300d94:	pcmpeqq xmm14,xmm15
    72deb7300d9a:	movdqa xmm15,xmm0
    72deb7300d9f:	cmpunordpd xmm15,xmm0
    72deb7300da5:	por    xmm14,xmm15
    72deb7300daa:	pmovmskb ecx,xmm14
    72deb7300daf:	jrcxz  0x72deb7300db6
    72deb7300db1:	jmp    0x72deb7302c5b
    72deb7300db6:	movdqa xmm11,xmm0
    72deb7300dbb:	movdqu XMMWORD PTR [r12+0x260],xmm11
    72deb7300dc5:	mov    ebp,0x0
    72deb7300dca:	mov    r8d,0x0
    72deb7300dd0:	mov    QWORD PTR [r12+0x110],rbp
    72deb7300dd8:	mov    QWORD PTR [r12+0x118],r8
    72deb7300de0:	movdqa xmm0,xmm9
    72deb7300de5:	movdqa xmm1,xmm7
    72deb7300de9:	mulpd  xmm0,xmm1
    72deb7300ded:	movdqa xmm14,xmm0
    72deb7300df2:	movdqu xmm15,XMMWORD PTR [rip+0x9495]        # 0x72deb730a290
    72deb7300dfb:	pand   xmm14,xmm15
    72deb7300e00:	movdqu xmm15,XMMWORD PTR [rip+0x9497]        # 0x72deb730a2a0
    72deb7300e09:	pcmpeqq xmm14,xmm15
    72deb7300e0f:	movdqa xmm15,xmm0
    72deb7300e14:	cmpunordpd xmm15,xmm0
    72deb7300e1a:	por    xmm14,xmm15
    72deb7300e1f:	pmovmskb ecx,xmm14
    72deb7300e24:	jrcxz  0x72deb7300e2b
    72deb7300e26:	jmp    0x72deb7302c80
    72deb7300e2b:	movdqa xmm8,xmm0
    72deb7300e30:	movdqa xmm0,xmm9
    72deb7300e35:	movdqa xmm1,xmm6
    72deb7300e39:	mulpd  xmm0,xmm1
    72deb7300e3d:	movdqa xmm14,xmm0
    72deb7300e42:	movdqu xmm15,XMMWORD PTR [rip+0x9445]        # 0x72deb730a290
    72deb7300e4b:	pand   xmm14,xmm15
    72deb7300e50:	movdqu xmm15,XMMWORD PTR [rip+0x9447]        # 0x72deb730a2a0
    72deb7300e59:	pcmpeqq xmm14,xmm15
    72deb7300e5f:	movdqa xmm15,xmm0
    72deb7300e64:	cmpunordpd xmm15,xmm0
    72deb7300e6a:	por    xmm14,xmm15
    72deb7300e6f:	pmovmskb ecx,xmm14
    72deb7300e74:	jrcxz  0x72deb7300e7b
    72deb7300e76:	jmp    0x72deb7302ca5
    72deb7300e7b:	movdqa xmm7,xmm0
    72deb7300e7f:	movdqu xmm6,XMMWORD PTR [r12+0x1f0]
    72deb7300e89:	movdqa xmm0,xmm9
    72deb7300e8e:	movdqa xmm1,xmm6
    72deb7300e92:	mulpd  xmm0,xmm1
    72deb7300e96:	movdqa xmm14,xmm0
    72deb7300e9b:	movdqu xmm15,XMMWORD PTR [rip+0x93ec]        # 0x72deb730a290
    72deb7300ea4:	pand   xmm14,xmm15
    72deb7300ea9:	movdqu xmm15,XMMWORD PTR [rip+0x93ee]        # 0x72deb730a2a0
    72deb7300eb2:	pcmpeqq xmm14,xmm15
    72deb7300eb8:	movdqa xmm15,xmm0
    72deb7300ebd:	cmpunordpd xmm15,xmm0
    72deb7300ec3:	por    xmm14,xmm15
    72deb7300ec8:	pmovmskb ecx,xmm14
    72deb7300ecd:	jrcxz  0x72deb7300ed4
    72deb7300ecf:	jmp    0x72deb7302cca
    72deb7300ed4:	movdqa xmm12,xmm0
    72deb7300ed9:	movdqu XMMWORD PTR [r12+0x180],xmm12
    72deb7300ee3:	movdqu xmm6,XMMWORD PTR [r12+0x2a0]
    72deb7300eed:	movdqa xmm0,xmm6
    72deb7300ef1:	movdqa xmm1,xmm6
    72deb7300ef5:	por    xmm0,xmm1
    72deb7300ef9:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    72deb7300f03:	movdqu xmm9,XMMWORD PTR [r12+0x250]
    72deb7300f0d:	movdqa xmm0,xmm9
    72deb7300f12:	movdqa xmm1,xmm9
    72deb7300f17:	por    xmm0,xmm1
    72deb7300f1b:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    72deb7300f25:	movdqa xmm0,xmm9
    72deb7300f2a:	movdqa xmm1,xmm2
    72deb7300f2e:	pshufd xmm1,xmm1,0x44
    72deb7300f33:	mulpd  xmm0,xmm1
    72deb7300f37:	movdqa xmm14,xmm0
    72deb7300f3c:	movdqu xmm15,XMMWORD PTR [rip+0x934b]        # 0x72deb730a290
    72deb7300f45:	pand   xmm14,xmm15
    72deb7300f4a:	movdqu xmm15,XMMWORD PTR [rip+0x934d]        # 0x72deb730a2a0
    72deb7300f53:	pcmpeqq xmm14,xmm15
    72deb7300f59:	movdqa xmm15,xmm0
    72deb7300f5e:	cmpunordpd xmm15,xmm0
    72deb7300f64:	por    xmm14,xmm15
    72deb7300f69:	pmovmskb ecx,xmm14
    72deb7300f6e:	jrcxz  0x72deb7300f75
    72deb7300f70:	jmp    0x72deb7302cef
    72deb7300f75:	movdqa xmm4,xmm0
    72deb7300f79:	movdqu XMMWORD PTR [r12+0x250],xmm4
    72deb7300f83:	sub    r13,0x200
    72deb7300f8a:	movdqu xmm9,XMMWORD PTR [r12+0x110]
    72deb7300f94:	movdqa xmm0,xmm10
    72deb7300f99:	movdqa xmm1,xmm9
    72deb7300f9e:	addpd  xmm0,xmm1
    72deb7300fa2:	movdqa xmm14,xmm0
    72deb7300fa7:	movdqu xmm15,XMMWORD PTR [rip+0x92e0]        # 0x72deb730a290
    72deb7300fb0:	pand   xmm14,xmm15
    72deb7300fb5:	movdqu xmm15,XMMWORD PTR [rip+0x92e2]        # 0x72deb730a2a0
    72deb7300fbe:	pcmpeqq xmm14,xmm15
    72deb7300fc4:	movdqa xmm15,xmm0
    72deb7300fc9:	cmpunordpd xmm15,xmm0
    72deb7300fcf:	por    xmm14,xmm15
    72deb7300fd4:	pmovmskb ecx,xmm14
    72deb7300fd9:	jrcxz  0x72deb7300fe0
    72deb7300fdb:	jmp    0x72deb7302d14
    72deb7300fe0:	movdqu XMMWORD PTR [r12+0x240],xmm0
    72deb7300fea:	movdqu xmm10,XMMWORD PTR [r12+0x1b0]
    72deb7300ff4:	movdqa xmm0,xmm8
    72deb7300ff9:	movdqa xmm1,xmm10
    72deb7300ffe:	addpd  xmm0,xmm1
    72deb7301002:	movdqa xmm14,xmm0
    72deb7301007:	movdqu xmm15,XMMWORD PTR [rip+0x9280]        # 0x72deb730a290
    72deb7301010:	pand   xmm14,xmm15
    72deb7301015:	movdqu xmm15,XMMWORD PTR [rip+0x9282]        # 0x72deb730a2a0
    72deb730101e:	pcmpeqq xmm14,xmm15
    72deb7301024:	movdqa xmm15,xmm0
    72deb7301029:	cmpunordpd xmm15,xmm0
    72deb730102f:	por    xmm14,xmm15
    72deb7301034:	pmovmskb ecx,xmm14
    72deb7301039:	jrcxz  0x72deb7301040
    72deb730103b:	jmp    0x72deb7302d55
    72deb7301040:	movdqa xmm6,xmm0
    72deb7301044:	movdqu XMMWORD PTR [r12+0x210],xmm6
    72deb730104e:	movdqa xmm0,xmm7
    72deb7301052:	movdqa xmm1,xmm10
    72deb7301057:	addpd  xmm0,xmm1
    72deb730105b:	movdqa xmm14,xmm0
    72deb7301060:	movdqu xmm15,XMMWORD PTR [rip+0x9227]        # 0x72deb730a290
    72deb7301069:	pand   xmm14,xmm15
    72deb730106e:	movdqu xmm15,XMMWORD PTR [rip+0x9229]        # 0x72deb730a2a0
    72deb7301077:	pcmpeqq xmm14,xmm15
    72deb730107d:	movdqa xmm15,xmm0
    72deb7301082:	cmpunordpd xmm15,xmm0
    72deb7301088:	por    xmm14,xmm15
    72deb730108d:	pmovmskb ecx,xmm14
    72deb7301092:	jrcxz  0x72deb7301099
    72deb7301094:	jmp    0x72deb7302d96
    72deb7301099:	movdqa xmm8,xmm0
    72deb730109e:	movdqu XMMWORD PTR [r12+0x220],xmm8
    72deb73010a8:	movdqu xmm7,XMMWORD PTR [r12+0x2f0]
    72deb73010b2:	setne  BYTE PTR [rsp+0x8]
    72deb73010b7:	mov    r11,rax
    72deb73010ba:	lahf
    72deb73010bb:	seto   al
    72deb73010be:	mov    WORD PTR [rsp],ax
    72deb73010c2:	mov    rax,r11
    72deb73010c5:	movdqa xmm0,xmm7
    72deb73010c9:	movdqa xmm1,xmm7
    72deb73010cd:	por    xmm0,xmm1
    72deb73010d1:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    72deb73010db:	movdqu xmm10,XMMWORD PTR [r12+0x2e0]
    72deb73010e5:	movdqa xmm0,xmm10
    72deb73010ea:	movdqa xmm1,xmm10
    72deb73010ef:	por    xmm0,xmm1
    72deb73010f3:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    72deb73010fd:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    72deb7301107:	movdqa xmm0,xmm13
    72deb730110c:	movdqa xmm1,xmm13
    72deb7301111:	por    xmm0,xmm1
    72deb7301115:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    72deb730111f:	movdqu xmm5,XMMWORD PTR [r12+0x200]
    72deb7301129:	movdqa xmm0,xmm5
    72deb730112d:	movdqa xmm1,xmm5
    72deb7301131:	por    xmm0,xmm1
    72deb7301135:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    72deb730113f:	movdqu xmm7,XMMWORD PTR [r12+0x1c0]
    72deb7301149:	movdqa xmm1,xmm7
    72deb730114d:	por    xmm7,xmm1
    72deb7301151:	movdqu XMMWORD PTR [r12+0x200],xmm7
    72deb730115b:	movdqu xmm3,XMMWORD PTR [r12+0x190]
    72deb7301165:	movdqa xmm1,xmm3
    72deb7301169:	por    xmm3,xmm1
    72deb730116d:	movdqu XMMWORD PTR [r12+0x1c0],xmm3
    72deb7301177:	movdqu xmm10,XMMWORD PTR [r12+0x300]
    72deb7301181:	movdqa xmm1,xmm10
    72deb7301186:	por    xmm10,xmm1
    72deb730118b:	movdqu XMMWORD PTR [r12+0x190],xmm10
    72deb7301195:	mov    r13,r14
    72deb7301198:	add    r13,0xa0
    72deb730119f:	mov    rbp,r13
    72deb73011a2:	add    rbp,0x10
    72deb73011a6:	movdqu xmm13,XMMWORD PTR [r13+0x0]
    72deb73011ac:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    72deb73011b1:	movdqu XMMWORD PTR [r12+0x300],xmm13
    72deb73011bb:	movdqu XMMWORD PTR [r12+0x270],xmm5
    72deb73011c5:	movdqa xmm0,xmm12
    72deb73011ca:	movdqa xmm1,xmm9
    72deb73011cf:	addpd  xmm0,xmm1
    72deb73011d3:	movdqa xmm14,xmm0
    72deb73011d8:	movdqu xmm15,XMMWORD PTR [rip+0x90af]        # 0x72deb730a290
    72deb73011e1:	pand   xmm14,xmm15
    72deb73011e6:	movdqu xmm15,XMMWORD PTR [rip+0x90b1]        # 0x72deb730a2a0
    72deb73011ef:	pcmpeqq xmm14,xmm15
    72deb73011f5:	movdqa xmm15,xmm0
    72deb73011fa:	cmpunordpd xmm15,xmm0
    72deb7301200:	por    xmm14,xmm15
    72deb7301205:	pmovmskb ecx,xmm14
    72deb730120a:	jrcxz  0x72deb7301211
    72deb730120c:	jmp    0x72deb7302dd6
    72deb7301211:	movdqu XMMWORD PTR [r12+0x180],xmm0
    72deb730121b:	mov    r13,r14
    72deb730121e:	add    r13,0xf0
    72deb7301225:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    72deb730122b:	movdqu XMMWORD PTR [r12+0x110],xmm9
    72deb7301235:	movdqa xmm0,xmm6
    72deb7301239:	movdqa xmm1,xmm4
    72deb730123d:	addpd  xmm0,xmm1
    72deb7301241:	movdqa xmm14,xmm0
    72deb7301246:	movdqu xmm15,XMMWORD PTR [rip+0x9041]        # 0x72deb730a290
    72deb730124f:	pand   xmm14,xmm15
    72deb7301254:	movdqu xmm15,XMMWORD PTR [rip+0x9043]        # 0x72deb730a2a0
    72deb730125d:	pcmpeqq xmm14,xmm15
    72deb7301263:	movdqa xmm15,xmm0
    72deb7301268:	cmpunordpd xmm15,xmm0
    72deb730126e:	por    xmm14,xmm15
    72deb7301273:	pmovmskb ecx,xmm14
    72deb7301278:	jrcxz  0x72deb730127f
    72deb730127a:	jmp    0x72deb7302dfc
    72deb730127f:	movdqa xmm12,xmm0
    72deb7301284:	movdqu XMMWORD PTR [r12+0x210],xmm12
    72deb730128e:	movdqa xmm0,xmm8
    72deb7301293:	movdqa xmm1,xmm11
    72deb7301298:	addpd  xmm0,xmm1
    72deb730129c:	movdqa xmm14,xmm0
    72deb73012a1:	movdqu xmm15,XMMWORD PTR [rip+0x8fe6]        # 0x72deb730a290
    72deb73012aa:	pand   xmm14,xmm15
    72deb73012af:	movdqu xmm15,XMMWORD PTR [rip+0x8fe8]        # 0x72deb730a2a0
    72deb73012b8:	pcmpeqq xmm14,xmm15
    72deb73012be:	movdqa xmm15,xmm0
    72deb73012c3:	cmpunordpd xmm15,xmm0
    72deb73012c9:	por    xmm14,xmm15
    72deb73012ce:	pmovmskb ecx,xmm14
    72deb73012d3:	jrcxz  0x72deb73012da
    72deb73012d5:	jmp    0x72deb7302e20
    72deb73012da:	movdqa xmm4,xmm0
    72deb73012de:	movdqu XMMWORD PTR [r12+0x220],xmm4
    72deb73012e8:	movdqa xmm0,xmm5
    72deb73012ec:	movdqa xmm1,xmm2
    72deb73012f0:	pshufd xmm1,xmm1,0x44
    72deb73012f5:	mulpd  xmm0,xmm1
    72deb73012f9:	movdqa xmm14,xmm0
    72deb73012fe:	movdqu xmm15,XMMWORD PTR [rip+0x8f89]        # 0x72deb730a290
    72deb7301307:	pand   xmm14,xmm15
    72deb730130c:	movdqu xmm15,XMMWORD PTR [rip+0x8f8b]        # 0x72deb730a2a0
    72deb7301315:	pcmpeqq xmm14,xmm15
    72deb730131b:	movdqa xmm15,xmm0
    72deb7301320:	cmpunordpd xmm15,xmm0
    72deb7301326:	por    xmm14,xmm15
    72deb730132b:	pmovmskb ecx,xmm14
    72deb7301330:	jrcxz  0x72deb7301337
    72deb7301332:	jmp    0x72deb7302e46
    72deb7301337:	movdqa xmm6,xmm0
    72deb730133b:	movdqu XMMWORD PTR [r12+0x270],xmm6
    72deb7301345:	movdqu xmm5,XMMWORD PTR [r12+0x170]
    72deb730134f:	movdqa xmm0,xmm9
    72deb7301354:	movdqa xmm1,xmm5
    72deb7301358:	pshufd xmm1,xmm1,0x44
    72deb730135d:	mulpd  xmm0,xmm1
    72deb7301361:	movdqa xmm14,xmm0
    72deb7301366:	movdqu xmm15,XMMWORD PTR [rip+0x8f21]        # 0x72deb730a290
    72deb730136f:	pand   xmm14,xmm15
    72deb7301374:	movdqu xmm15,XMMWORD PTR [rip+0x8f23]        # 0x72deb730a2a0
    72deb730137d:	pcmpeqq xmm14,xmm15
    72deb7301383:	movdqa xmm15,xmm0
    72deb7301388:	cmpunordpd xmm15,xmm0
    72deb730138e:	por    xmm14,xmm15
    72deb7301393:	pmovmskb ecx,xmm14
    72deb7301398:	jrcxz  0x72deb730139f
    72deb730139a:	jmp    0x72deb7302e6a
    72deb730139f:	movdqa xmm8,xmm0
    72deb73013a4:	movdqu XMMWORD PTR [r12+0x250],xmm8
    72deb73013ae:	mov    r13,r14
    72deb73013b1:	add    r13,0xe0
    72deb73013b8:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    72deb73013be:	movdqu XMMWORD PTR [r12+0x110],xmm9
    72deb73013c8:	movdqa xmm0,xmm13
    72deb73013cd:	movdqa xmm1,xmm2
    72deb73013d1:	pshufd xmm1,xmm1,0x44
    72deb73013d6:	mulpd  xmm0,xmm1
    72deb73013da:	movdqa xmm14,xmm0
    72deb73013df:	movdqu xmm15,XMMWORD PTR [rip+0x8ea8]        # 0x72deb730a290
    72deb73013e8:	pand   xmm14,xmm15
    72deb73013ed:	movdqu xmm15,XMMWORD PTR [rip+0x8eaa]        # 0x72deb730a2a0
    72deb73013f6:	pcmpeqq xmm14,xmm15
    72deb73013fc:	movdqa xmm15,xmm0
    72deb7301401:	cmpunordpd xmm15,xmm0
    72deb7301407:	por    xmm14,xmm15
    72deb730140c:	pmovmskb ecx,xmm14
    72deb7301411:	jrcxz  0x72deb7301418
    72deb7301413:	jmp    0x72deb7302e8f
    72deb7301418:	movdqa xmm11,xmm0
    72deb730141d:	movdqu XMMWORD PTR [r12+0x230],xmm11
    72deb7301427:	movdqa xmm0,xmm10
    72deb730142c:	movdqa xmm1,xmm10
    72deb7301431:	por    xmm0,xmm1
    72deb7301435:	movdqu XMMWORD PTR [r12+0x300],xmm0
    72deb730143f:	movdqa xmm0,xmm3
    72deb7301443:	movdqa xmm1,xmm3
    72deb7301447:	por    xmm0,xmm1
    72deb730144b:	movdqu XMMWORD PTR [r12+0x190],xmm0
    72deb7301455:	movdqa xmm0,xmm9
    72deb730145a:	movdqa xmm1,xmm5
    72deb730145e:	pshufd xmm1,xmm1,0x44
    72deb7301463:	mulpd  xmm0,xmm1
    72deb7301467:	movdqa xmm14,xmm0
    72deb730146c:	movdqu xmm15,XMMWORD PTR [rip+0x8e1b]        # 0x72deb730a290
    72deb7301475:	pand   xmm14,xmm15
    72deb730147a:	movdqu xmm15,XMMWORD PTR [rip+0x8e1d]        # 0x72deb730a2a0
    72deb7301483:	pcmpeqq xmm14,xmm15
    72deb7301489:	movdqa xmm15,xmm0
    72deb730148e:	cmpunordpd xmm15,xmm0
    72deb7301494:	por    xmm14,xmm15
    72deb7301499:	pmovmskb ecx,xmm14
    72deb730149e:	jrcxz  0x72deb73014a5
    72deb73014a0:	jmp    0x72deb7302eb4
    72deb73014a5:	movdqa xmm2,xmm0
    72deb73014a9:	movdqu XMMWORD PTR [r12+0x260],xmm2
    72deb73014b3:	mov    r13,r14
    72deb73014b6:	add    r13,0x90
    72deb73014bd:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    72deb73014c3:	movdqu XMMWORD PTR [r12+0x110],xmm9
    72deb73014cd:	movdqa xmm0,xmm7
    72deb73014d1:	movdqa xmm1,xmm7
    72deb73014d5:	por    xmm0,xmm1
    72deb73014d9:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    72deb73014e3:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    72deb73014ed:	movdqu xmm1,XMMWORD PTR [r12+0x2d0]
    72deb73014f7:	por    xmm13,xmm1
    72deb73014fc:	movdqu XMMWORD PTR [r12+0x200],xmm13
    72deb7301506:	movdqu xmm7,XMMWORD PTR [r12+0x2e0]
    72deb7301510:	movdqu xmm1,XMMWORD PTR [r12+0x2e0]
    72deb730151a:	por    xmm7,xmm1
    72deb730151e:	movdqu XMMWORD PTR [r12+0x2d0],xmm7
    72deb7301528:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    72deb7301532:	movdqu xmm1,XMMWORD PTR [r12+0x2f0]
    72deb730153c:	por    xmm0,xmm1
    72deb7301540:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    72deb730154a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    72deb7301554:	movdqa xmm1,xmm6
    72deb7301558:	addpd  xmm0,xmm1
    72deb730155c:	movdqa xmm14,xmm0
    72deb7301561:	movdqu xmm15,XMMWORD PTR [rip+0x8d26]        # 0x72deb730a290
    72deb730156a:	pand   xmm14,xmm15
    72deb730156f:	movdqu xmm15,XMMWORD PTR [rip+0x8d28]        # 0x72deb730a2a0
    72deb7301578:	pcmpeqq xmm14,xmm15
    72deb730157e:	movdqa xmm15,xmm0
    72deb7301583:	cmpunordpd xmm15,xmm0
    72deb7301589:	por    xmm14,xmm15
    72deb730158e:	pmovmskb ecx,xmm14
    72deb7301593:	jrcxz  0x72deb730159a
    72deb7301595:	jmp    0x72deb7302ed9
    72deb730159a:	movdqa xmm3,xmm0
    72deb730159e:	movdqu XMMWORD PTR [r12+0x240],xmm3
    72deb73015a8:	movdqa xmm0,xmm9
    72deb73015ad:	movdqa xmm1,xmm5
    72deb73015b1:	pshufd xmm1,xmm1,0x44
    72deb73015b6:	mulpd  xmm0,xmm1
    72deb73015ba:	movdqa xmm14,xmm0
    72deb73015bf:	movdqu xmm15,XMMWORD PTR [rip+0x8cc8]        # 0x72deb730a290
    72deb73015c8:	pand   xmm14,xmm15
    72deb73015cd:	movdqu xmm15,XMMWORD PTR [rip+0x8cca]        # 0x72deb730a2a0
    72deb73015d6:	pcmpeqq xmm14,xmm15
    72deb73015dc:	movdqa xmm15,xmm0
    72deb73015e1:	cmpunordpd xmm15,xmm0
    72deb73015e7:	por    xmm14,xmm15
    72deb73015ec:	pmovmskb ecx,xmm14
    72deb73015f1:	jrcxz  0x72deb73015f8
    72deb73015f3:	jmp    0x72deb7302f03
    72deb73015f8:	movdqa xmm6,xmm0
    72deb73015fc:	movdqu XMMWORD PTR [r12+0x270],xmm6
    72deb7301606:	mov    r13,r14
    72deb7301609:	add    r13,0x80
    72deb7301610:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    72deb7301616:	movdqu XMMWORD PTR [r12+0x110],xmm9
    72deb7301620:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    72deb730162a:	movdqa xmm1,xmm11
    72deb730162f:	addpd  xmm0,xmm1
    72deb7301633:	movdqa xmm14,xmm0
    72deb7301638:	movdqu xmm15,XMMWORD PTR [rip+0x8c4f]        # 0x72deb730a290
    72deb7301641:	pand   xmm14,xmm15
    72deb7301646:	movdqu xmm15,XMMWORD PTR [rip+0x8c51]        # 0x72deb730a2a0
    72deb730164f:	pcmpeqq xmm14,xmm15
    72deb7301655:	movdqa xmm15,xmm0
    72deb730165a:	cmpunordpd xmm15,xmm0
    72deb7301660:	por    xmm14,xmm15
    72deb7301665:	pmovmskb ecx,xmm14
    72deb730166a:	jrcxz  0x72deb7301671
    72deb730166c:	jmp    0x72deb7302f28
    72deb7301671:	movdqa xmm10,xmm0
    72deb7301676:	movdqu XMMWORD PTR [r12+0x180],xmm10
    72deb7301680:	movdqa xmm0,xmm12
    72deb7301685:	movdqa xmm1,xmm8
    72deb730168a:	addpd  xmm0,xmm1
    72deb730168e:	movdqa xmm14,xmm0
    72deb7301693:	movdqu xmm15,XMMWORD PTR [rip+0x8bf4]        # 0x72deb730a290
    72deb730169c:	pand   xmm14,xmm15
    72deb73016a1:	movdqu xmm15,XMMWORD PTR [rip+0x8bf6]        # 0x72deb730a2a0
    72deb73016aa:	pcmpeqq xmm14,xmm15
    72deb73016b0:	movdqa xmm15,xmm0
    72deb73016b5:	cmpunordpd xmm15,xmm0
    72deb73016bb:	por    xmm14,xmm15
    72deb73016c0:	pmovmskb ecx,xmm14
    72deb73016c5:	jrcxz  0x72deb73016cc
    72deb73016c7:	jmp    0x72deb7302f53
    72deb73016cc:	movdqa xmm11,xmm0
    72deb73016d1:	movdqu XMMWORD PTR [r12+0x210],xmm11
    72deb73016db:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    72deb73016e5:	movdqu xmm1,XMMWORD PTR [r12+0x1b0]
    72deb73016ef:	por    xmm0,xmm1
    72deb73016f3:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    72deb73016fd:	movdqa xmm0,xmm9
    72deb7301702:	movdqa xmm1,xmm5
    72deb7301706:	pshufd xmm1,xmm1,0x44
    72deb730170b:	mulpd  xmm0,xmm1
    72deb730170f:	movdqa xmm14,xmm0
    72deb7301714:	movdqu xmm15,XMMWORD PTR [rip+0x8b73]        # 0x72deb730a290
    72deb730171d:	pand   xmm14,xmm15
    72deb7301722:	movdqu xmm15,XMMWORD PTR [rip+0x8b75]        # 0x72deb730a2a0
    72deb730172b:	pcmpeqq xmm14,xmm15
    72deb7301731:	movdqa xmm15,xmm0
    72deb7301736:	cmpunordpd xmm15,xmm0
    72deb730173c:	por    xmm14,xmm15
    72deb7301741:	pmovmskb ecx,xmm14
    72deb7301746:	jrcxz  0x72deb730174d
    72deb7301748:	jmp    0x72deb7302f79
    72deb730174d:	movdqa xmm12,xmm0
    72deb7301752:	movdqu XMMWORD PTR [r12+0x170],xmm12
    72deb730175c:	mov    r13,r14
    72deb730175f:	add    r13,0xd0
    72deb7301766:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    72deb730176c:	movdqu XMMWORD PTR [r12+0x110],xmm5
    72deb7301776:	movdqa xmm0,xmm4
    72deb730177a:	movdqa xmm1,xmm2
    72deb730177e:	addpd  xmm0,xmm1
    72deb7301782:	movdqa xmm14,xmm0
    72deb7301787:	movdqu xmm15,XMMWORD PTR [rip+0x8b00]        # 0x72deb730a290
    72deb7301790:	pand   xmm14,xmm15
    72deb7301795:	movdqu xmm15,XMMWORD PTR [rip+0x8b02]        # 0x72deb730a2a0
    72deb730179e:	pcmpeqq xmm14,xmm15
    72deb73017a4:	movdqa xmm15,xmm0
    72deb73017a9:	cmpunordpd xmm15,xmm0
    72deb73017af:	por    xmm14,xmm15
    72deb73017b4:	pmovmskb ecx,xmm14
    72deb73017b9:	jrcxz  0x72deb73017c0
    72deb73017bb:	jmp    0x72deb7302f9e
    72deb73017c0:	movdqa xmm9,xmm0
    72deb73017c5:	movdqu XMMWORD PTR [r12+0x220],xmm9
    72deb73017cf:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    72deb73017d9:	movdqa xmm0,xmm13
    72deb73017de:	movdqa xmm1,xmm2
    72deb73017e2:	pshufd xmm1,xmm1,0x44
    72deb73017e7:	mulpd  xmm0,xmm1
    72deb73017eb:	movdqa xmm14,xmm0
    72deb73017f0:	movdqu xmm15,XMMWORD PTR [rip+0x8a97]        # 0x72deb730a290
    72deb73017f9:	pand   xmm14,xmm15
    72deb73017fe:	movdqu xmm15,XMMWORD PTR [rip+0x8a99]        # 0x72deb730a2a0
    72deb7301807:	pcmpeqq xmm14,xmm15
    72deb730180d:	movdqa xmm15,xmm0
    72deb7301812:	cmpunordpd xmm15,xmm0
    72deb7301818:	por    xmm14,xmm15
    72deb730181d:	pmovmskb ecx,xmm14
    72deb7301822:	jrcxz  0x72deb7301829
    72deb7301824:	jmp    0x72deb7302fc2
    72deb7301829:	movdqa xmm4,xmm0
    72deb730182d:	movdqu XMMWORD PTR [r12+0x260],xmm4
    72deb7301837:	mov    r13d,0x0
    72deb730183d:	mov    ebp,0x0
    72deb7301842:	mov    QWORD PTR [r12+0x1b0],r13
    72deb730184a:	mov    QWORD PTR [r12+0x1b8],rbp
    72deb7301852:	movdqa xmm0,xmm5
    72deb7301856:	movdqa xmm1,xmm2
    72deb730185a:	pshufd xmm1,xmm1,0x44
    72deb730185f:	mulpd  xmm0,xmm1
    72deb7301863:	movdqa xmm14,xmm0
    72deb7301868:	movdqu xmm15,XMMWORD PTR [rip+0x8a1f]        # 0x72deb730a290
    72deb7301871:	pand   xmm14,xmm15
    72deb7301876:	movdqu xmm15,XMMWORD PTR [rip+0x8a21]        # 0x72deb730a2a0
    72deb730187f:	pcmpeqq xmm14,xmm15
    72deb7301885:	movdqa xmm15,xmm0
    72deb730188a:	cmpunordpd xmm15,xmm0
    72deb7301890:	por    xmm14,xmm15
    72deb7301895:	pmovmskb ecx,xmm14
    72deb730189a:	jrcxz  0x72deb73018a1
    72deb730189c:	jmp    0x72deb7302fe7
    72deb73018a1:	movdqa xmm13,xmm0
    72deb73018a6:	movdqu XMMWORD PTR [r12+0x230],xmm13
    72deb73018b0:	mov    r13,r14
    72deb73018b3:	add    r13,0xc0
    72deb73018ba:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    72deb73018c0:	movdqu XMMWORD PTR [r12+0x110],xmm5
    72deb73018ca:	movdqa xmm0,xmm3
    72deb73018ce:	movdqa xmm1,xmm6
    72deb73018d2:	addpd  xmm0,xmm1
    72deb73018d6:	movdqa xmm14,xmm0
    72deb73018db:	movdqu xmm15,XMMWORD PTR [rip+0x89ac]        # 0x72deb730a290
    72deb73018e4:	pand   xmm14,xmm15
    72deb73018e9:	movdqu xmm15,XMMWORD PTR [rip+0x89ae]        # 0x72deb730a2a0
    72deb73018f2:	pcmpeqq xmm14,xmm15
    72deb73018f8:	movdqa xmm15,xmm0
    72deb73018fd:	cmpunordpd xmm15,xmm0
    72deb7301903:	por    xmm14,xmm15
    72deb7301908:	pmovmskb ecx,xmm14
    72deb730190d:	jrcxz  0x72deb7301914
    72deb730190f:	jmp    0x72deb730300b
    72deb7301914:	movdqa xmm8,xmm0
    72deb7301919:	movdqu XMMWORD PTR [r12+0x240],xmm8
    72deb7301923:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    72deb730192d:	movdqu xmm1,XMMWORD PTR [r12+0x1a0]
    72deb7301937:	por    xmm0,xmm1
    72deb730193b:	movdqu XMMWORD PTR [r12+0x270],xmm0
    72deb7301945:	movdqu xmm6,XMMWORD PTR [r12+0x120]
    72deb730194f:	movdqu xmm1,XMMWORD PTR [r12+0x120]
    72deb7301959:	por    xmm6,xmm1
    72deb730195d:	movdqu XMMWORD PTR [r12+0x1a0],xmm6
    72deb7301967:	movdqa xmm0,xmm5
    72deb730196b:	movdqa xmm1,xmm2
    72deb730196f:	pshufd xmm1,xmm1,0x44
    72deb7301974:	mulpd  xmm0,xmm1
    72deb7301978:	movdqa xmm14,xmm0
    72deb730197d:	movdqu xmm15,XMMWORD PTR [rip+0x890a]        # 0x72deb730a290
    72deb7301986:	pand   xmm14,xmm15
    72deb730198b:	movdqu xmm15,XMMWORD PTR [rip+0x890c]        # 0x72deb730a2a0
    72deb7301994:	pcmpeqq xmm14,xmm15
    72deb730199a:	movdqa xmm15,xmm0
    72deb730199f:	cmpunordpd xmm15,xmm0
    72deb73019a5:	por    xmm14,xmm15
    72deb73019aa:	pmovmskb ecx,xmm14
    72deb73019af:	jrcxz  0x72deb73019b6
    72deb73019b1:	jmp    0x72deb730302f
    72deb73019b6:	movdqa xmm6,xmm0
    72deb73019ba:	movdqu XMMWORD PTR [r12+0x250],xmm6
    72deb73019c4:	mov    r13,r14
    72deb73019c7:	add    r13,0x20
    72deb73019cb:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    72deb73019d1:	movdqu XMMWORD PTR [r12+0x110],xmm5
    72deb73019db:	movdqa xmm0,xmm10
    72deb73019e0:	movdqa xmm1,xmm12
    72deb73019e5:	addpd  xmm0,xmm1
    72deb73019e9:	movdqa xmm14,xmm0
    72deb73019ee:	movdqu xmm15,XMMWORD PTR [rip+0x8899]        # 0x72deb730a290
    72deb73019f7:	pand   xmm14,xmm15
    72deb73019fc:	movdqu xmm15,XMMWORD PTR [rip+0x889b]        # 0x72deb730a2a0
    72deb7301a05:	pcmpeqq xmm14,xmm15
    72deb7301a0b:	movdqa xmm15,xmm0
    72deb7301a10:	cmpunordpd xmm15,xmm0
    72deb7301a16:	por    xmm14,xmm15
    72deb7301a1b:	pmovmskb ecx,xmm14
    72deb7301a20:	jrcxz  0x72deb7301a27
    72deb7301a22:	jmp    0x72deb7303053
    72deb7301a27:	movdqa xmm3,xmm0
    72deb7301a2b:	movdqa xmm0,xmm7
    72deb7301a2f:	movdqa xmm1,xmm2
    72deb7301a33:	pshufd xmm1,xmm1,0x44
    72deb7301a38:	mulpd  xmm0,xmm1
    72deb7301a3c:	movdqa xmm14,xmm0
    72deb7301a41:	movdqu xmm15,XMMWORD PTR [rip+0x8846]        # 0x72deb730a290
    72deb7301a4a:	pand   xmm14,xmm15
    72deb7301a4f:	movdqu xmm15,XMMWORD PTR [rip+0x8848]        # 0x72deb730a2a0
    72deb7301a58:	pcmpeqq xmm14,xmm15
    72deb7301a5e:	movdqa xmm15,xmm0
    72deb7301a63:	cmpunordpd xmm15,xmm0
    72deb7301a69:	por    xmm14,xmm15
    72deb7301a6e:	pmovmskb ecx,xmm14
    72deb7301a73:	jrcxz  0x72deb7301a7a
    72deb7301a75:	jmp    0x72deb7303079
    72deb7301a7a:	movdqa xmm10,xmm0
    72deb7301a7f:	movdqa xmm0,xmm11
    72deb7301a84:	movdqa xmm1,xmm13
    72deb7301a89:	addpd  xmm0,xmm1
    72deb7301a8d:	movdqa xmm14,xmm0
    72deb7301a92:	movdqu xmm15,XMMWORD PTR [rip+0x87f5]        # 0x72deb730a290
    72deb7301a9b:	pand   xmm14,xmm15
    72deb7301aa0:	movdqu xmm15,XMMWORD PTR [rip+0x87f7]        # 0x72deb730a2a0
    72deb7301aa9:	pcmpeqq xmm14,xmm15
    72deb7301aaf:	movdqa xmm15,xmm0
    72deb7301ab4:	cmpunordpd xmm15,xmm0
    72deb7301aba:	por    xmm14,xmm15
    72deb7301abf:	pmovmskb ecx,xmm14
    72deb7301ac4:	jrcxz  0x72deb7301acb
    72deb7301ac6:	jmp    0x72deb730309d
    72deb7301acb:	movdqa xmm2,xmm0
    72deb7301acf:	movdqu xmm7,XMMWORD PTR [r12+0x150]
    72deb7301ad9:	movdqa xmm0,xmm5
    72deb7301add:	movdqa xmm1,xmm7
    72deb7301ae1:	pshufd xmm1,xmm1,0x44
    72deb7301ae6:	mulpd  xmm0,xmm1
    72deb7301aea:	movdqa xmm14,xmm0
    72deb7301aef:	movdqu xmm15,XMMWORD PTR [rip+0x8798]        # 0x72deb730a290
    72deb7301af8:	pand   xmm14,xmm15
    72deb7301afd:	movdqu xmm15,XMMWORD PTR [rip+0x879a]        # 0x72deb730a2a0
    72deb7301b06:	pcmpeqq xmm14,xmm15
    72deb7301b0c:	movdqa xmm15,xmm0
    72deb7301b11:	cmpunordpd xmm15,xmm0
    72deb7301b17:	por    xmm14,xmm15
    72deb7301b1c:	pmovmskb ecx,xmm14
    72deb7301b21:	jrcxz  0x72deb7301b28
    72deb7301b23:	jmp    0x72deb73030c3
    72deb7301b28:	movdqa xmm11,xmm0
    72deb7301b2d:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    72deb7301b37:	movdqa xmm1,xmm7
    72deb7301b3b:	pshufd xmm1,xmm1,0x44
    72deb7301b40:	mulpd  xmm0,xmm1
    72deb7301b44:	movdqa xmm14,xmm0
    72deb7301b49:	movdqu xmm15,XMMWORD PTR [rip+0x873e]        # 0x72deb730a290
    72deb7301b52:	pand   xmm14,xmm15
    72deb7301b57:	movdqu xmm15,XMMWORD PTR [rip+0x8740]        # 0x72deb730a2a0
    72deb7301b60:	pcmpeqq xmm14,xmm15
    72deb7301b66:	movdqa xmm15,xmm0
    72deb7301b6b:	cmpunordpd xmm15,xmm0
    72deb7301b71:	por    xmm14,xmm15
    72deb7301b76:	pmovmskb ecx,xmm14
    72deb7301b7b:	jrcxz  0x72deb7301b82
    72deb7301b7d:	jmp    0x72deb73030e7
    72deb7301b82:	movdqa xmm5,xmm0
    72deb7301b86:	movdqa xmm0,xmm8
    72deb7301b8b:	movdqa xmm1,xmm4
    72deb7301b8f:	addpd  xmm0,xmm1
    72deb7301b93:	movdqa xmm14,xmm0
    72deb7301b98:	movdqu xmm15,XMMWORD PTR [rip+0x86ef]        # 0x72deb730a290
    72deb7301ba1:	pand   xmm14,xmm15
    72deb7301ba6:	movdqu xmm15,XMMWORD PTR [rip+0x86f1]        # 0x72deb730a2a0
    72deb7301baf:	pcmpeqq xmm14,xmm15
    72deb7301bb5:	movdqa xmm15,xmm0
    72deb7301bba:	cmpunordpd xmm15,xmm0
    72deb7301bc0:	por    xmm14,xmm15
    72deb7301bc5:	pmovmskb ecx,xmm14
    72deb7301bca:	jrcxz  0x72deb7301bd1
    72deb7301bcc:	jmp    0x72deb7303111
    72deb7301bd1:	movdqa xmm12,xmm0
    72deb7301bd6:	movdqu XMMWORD PTR [r12+0x240],xmm12
    72deb7301be0:	movdqa xmm0,xmm9
    72deb7301be5:	movdqa xmm1,xmm6
    72deb7301be9:	addpd  xmm0,xmm1
    72deb7301bed:	movdqa xmm14,xmm0
    72deb7301bf2:	movdqu xmm15,XMMWORD PTR [rip+0x8695]        # 0x72deb730a290
    72deb7301bfb:	pand   xmm14,xmm15
    72deb7301c00:	movdqu xmm15,XMMWORD PTR [rip+0x8697]        # 0x72deb730a2a0
    72deb7301c09:	pcmpeqq xmm14,xmm15
    72deb7301c0f:	movdqa xmm15,xmm0
    72deb7301c14:	cmpunordpd xmm15,xmm0
    72deb7301c1a:	por    xmm14,xmm15
    72deb7301c1f:	pmovmskb ecx,xmm14
    72deb7301c24:	jrcxz  0x72deb7301c2b
    72deb7301c26:	jmp    0x72deb7303136
    72deb7301c2b:	movdqa xmm4,xmm0
    72deb7301c2f:	movdqu XMMWORD PTR [r12+0x220],xmm4
    72deb7301c39:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    72deb7301c43:	movdqa xmm1,xmm7
    72deb7301c47:	pshufd xmm1,xmm1,0x44
    72deb7301c4c:	mulpd  xmm0,xmm1
    72deb7301c50:	movdqa xmm14,xmm0
    72deb7301c55:	movdqu xmm15,XMMWORD PTR [rip+0x8632]        # 0x72deb730a290
    72deb7301c5e:	pand   xmm14,xmm15
    72deb7301c63:	movdqu xmm15,XMMWORD PTR [rip+0x8634]        # 0x72deb730a2a0
    72deb7301c6c:	pcmpeqq xmm14,xmm15
    72deb7301c72:	movdqa xmm15,xmm0
    72deb7301c77:	cmpunordpd xmm15,xmm0
    72deb7301c7d:	por    xmm14,xmm15
    72deb7301c82:	pmovmskb ecx,xmm14
    72deb7301c87:	jrcxz  0x72deb7301c8e
    72deb7301c89:	jmp    0x72deb730315b
    72deb7301c8e:	movdqa xmm6,xmm0
    72deb7301c92:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    72deb7301c9c:	movdqa xmm1,xmm7
    72deb7301ca0:	pshufd xmm1,xmm1,0x44
    72deb7301ca5:	mulpd  xmm0,xmm1
    72deb7301ca9:	movdqa xmm14,xmm0
    72deb7301cae:	movdqu xmm15,XMMWORD PTR [rip+0x85d9]        # 0x72deb730a290
    72deb7301cb7:	pand   xmm14,xmm15
    72deb7301cbc:	movdqu xmm15,XMMWORD PTR [rip+0x85db]        # 0x72deb730a2a0
    72deb7301cc5:	pcmpeqq xmm14,xmm15
    72deb7301ccb:	movdqa xmm15,xmm0
    72deb7301cd0:	cmpunordpd xmm15,xmm0
    72deb7301cd6:	por    xmm14,xmm15
    72deb7301cdb:	pmovmskb ecx,xmm14
    72deb7301ce0:	jrcxz  0x72deb7301ce7
    72deb7301ce2:	jmp    0x72deb7303185
    72deb7301ce7:	movdqa xmm8,xmm0
    72deb7301cec:	movdqu XMMWORD PTR [r12+0x150],xmm8
    72deb7301cf6:	movdqa xmm0,xmm3
    72deb7301cfa:	movdqa xmm1,xmm10
    72deb7301cff:	addpd  xmm0,xmm1
    72deb7301d03:	movdqa xmm14,xmm0
    72deb7301d08:	movdqu xmm15,XMMWORD PTR [rip+0x857f]        # 0x72deb730a290
    72deb7301d11:	pand   xmm14,xmm15
    72deb7301d16:	movdqu xmm15,XMMWORD PTR [rip+0x8581]        # 0x72deb730a2a0
    72deb7301d1f:	pcmpeqq xmm14,xmm15
    72deb7301d25:	movdqa xmm15,xmm0
    72deb7301d2a:	cmpunordpd xmm15,xmm0
    72deb7301d30:	por    xmm14,xmm15
    72deb7301d35:	pmovmskb ecx,xmm14
    72deb7301d3a:	jrcxz  0x72deb7301d41
    72deb7301d3c:	jmp    0x72deb73031af
    72deb7301d41:	movdqa xmm7,xmm0
    72deb7301d45:	movdqu XMMWORD PTR [r12+0x160],xmm7
    72deb7301d4f:	movdqa xmm0,xmm2
    72deb7301d53:	movdqa xmm1,xmm11
    72deb7301d58:	addpd  xmm0,xmm1
    72deb7301d5c:	movdqa xmm14,xmm0
    72deb7301d61:	movdqu xmm15,XMMWORD PTR [rip+0x8526]        # 0x72deb730a290
    72deb7301d6a:	pand   xmm14,xmm15
    72deb7301d6f:	movdqu xmm15,XMMWORD PTR [rip+0x8528]        # 0x72deb730a2a0
    72deb7301d78:	pcmpeqq xmm14,xmm15
    72deb7301d7e:	movdqa xmm15,xmm0
    72deb7301d83:	cmpunordpd xmm15,xmm0
    72deb7301d89:	por    xmm14,xmm15
    72deb7301d8e:	pmovmskb ecx,xmm14
    72deb7301d93:	jrcxz  0x72deb7301d9a
    72deb7301d95:	jmp    0x72deb73031d4
    72deb7301d9a:	movdqa xmm3,xmm0
    72deb7301d9e:	movdqu XMMWORD PTR [r12+0x170],xmm3
    72deb7301da8:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    72deb7301db2:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    72deb7301dbc:	movdqa xmm1,xmm2
    72deb7301dc0:	pshufd xmm1,xmm1,0x44
    72deb7301dc5:	mulpd  xmm0,xmm1
    72deb7301dc9:	movdqa xmm14,xmm0
    72deb7301dce:	movdqu xmm15,XMMWORD PTR [rip+0x84b9]        # 0x72deb730a290
    72deb7301dd7:	pand   xmm14,xmm15
    72deb7301ddc:	movdqu xmm15,XMMWORD PTR [rip+0x84bb]        # 0x72deb730a2a0
    72deb7301de5:	pcmpeqq xmm14,xmm15
    72deb7301deb:	movdqa xmm15,xmm0
    72deb7301df0:	cmpunordpd xmm15,xmm0
    72deb7301df6:	por    xmm14,xmm15
    72deb7301dfb:	pmovmskb ecx,xmm14
    72deb7301e00:	jrcxz  0x72deb7301e07
    72deb7301e02:	jmp    0x72deb73031f9
    72deb7301e07:	movdqa xmm9,xmm0
    72deb7301e0c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    72deb7301e16:	movdqa xmm0,xmm4
    72deb7301e1a:	movdqa xmm1,xmm5
    72deb7301e1e:	addpd  xmm0,xmm1
    72deb7301e22:	movdqa xmm14,xmm0
    72deb7301e27:	movdqu xmm15,XMMWORD PTR [rip+0x8460]        # 0x72deb730a290
    72deb7301e30:	pand   xmm14,xmm15
    72deb7301e35:	movdqu xmm15,XMMWORD PTR [rip+0x8462]        # 0x72deb730a2a0
    72deb7301e3e:	pcmpeqq xmm14,xmm15
    72deb7301e44:	movdqa xmm15,xmm0
    72deb7301e49:	cmpunordpd xmm15,xmm0
    72deb7301e4f:	por    xmm14,xmm15
    72deb7301e54:	pmovmskb ecx,xmm14
    72deb7301e59:	jrcxz  0x72deb7301e60
    72deb7301e5b:	jmp    0x72deb7303223
    72deb7301e60:	movdqa xmm10,xmm0
    72deb7301e65:	movdqu XMMWORD PTR [r12+0x210],xmm10
    72deb7301e6f:	movdqa xmm0,xmm12
    72deb7301e74:	movdqa xmm1,xmm6
    72deb7301e78:	addpd  xmm0,xmm1
    72deb7301e7c:	movdqa xmm14,xmm0
    72deb7301e81:	movdqu xmm15,XMMWORD PTR [rip+0x8406]        # 0x72deb730a290
    72deb7301e8a:	pand   xmm14,xmm15
    72deb7301e8f:	movdqu xmm15,XMMWORD PTR [rip+0x8408]        # 0x72deb730a2a0
    72deb7301e98:	pcmpeqq xmm14,xmm15
    72deb7301e9e:	movdqa xmm15,xmm0
    72deb7301ea3:	cmpunordpd xmm15,xmm0
    72deb7301ea9:	por    xmm14,xmm15
    72deb7301eae:	pmovmskb ecx,xmm14
    72deb7301eb3:	jrcxz  0x72deb7301eba
    72deb7301eb5:	jmp    0x72deb7303247
    72deb7301eba:	movdqa xmm4,xmm0
    72deb7301ebe:	movdqu XMMWORD PTR [r12+0x230],xmm4
    72deb7301ec8:	movdqu xmm5,XMMWORD PTR [r12+0x2a0]
    72deb7301ed2:	movdqu xmm1,XMMWORD PTR [r12+0x2a0]
    72deb7301edc:	por    xmm5,xmm1
    72deb7301ee0:	movdqu XMMWORD PTR [r12+0x250],xmm5
    72deb7301eea:	movdqu xmm5,XMMWORD PTR [r12+0x1d0]
    72deb7301ef4:	movdqu xmm1,XMMWORD PTR [r12+0x1d0]
    72deb7301efe:	por    xmm5,xmm1
    72deb7301f02:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    72deb7301f0c:	movdqu xmm6,XMMWORD PTR [r12+0x2c0]
    72deb7301f16:	movdqu xmm1,XMMWORD PTR [r12+0x2c0]
    72deb7301f20:	por    xmm6,xmm1
    72deb7301f24:	movdqu XMMWORD PTR [r12+0x1d0],xmm6
    72deb7301f2e:	mov    r13,r14
    72deb7301f31:	add    r13,0x40
    72deb7301f35:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    72deb7301f3b:	movdqu XMMWORD PTR [r12+0x2c0],xmm6
    72deb7301f45:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    72deb7301f4f:	movdqa xmm1,xmm2
    72deb7301f53:	pshufd xmm1,xmm1,0x44
    72deb7301f58:	mulpd  xmm0,xmm1
    72deb7301f5c:	movdqa xmm14,xmm0
    72deb7301f61:	movdqu xmm15,XMMWORD PTR [rip+0x8326]        # 0x72deb730a290
    72deb7301f6a:	pand   xmm14,xmm15
    72deb7301f6f:	movdqu xmm15,XMMWORD PTR [rip+0x8328]        # 0x72deb730a2a0
    72deb7301f78:	pcmpeqq xmm14,xmm15
    72deb7301f7e:	movdqa xmm15,xmm0
    72deb7301f83:	cmpunordpd xmm15,xmm0
    72deb7301f89:	por    xmm14,xmm15
    72deb7301f8e:	pmovmskb ecx,xmm14
    72deb7301f93:	jrcxz  0x72deb7301f9a
    72deb7301f95:	jmp    0x72deb730326c
    72deb7301f9a:	movdqa xmm11,xmm0
    72deb7301f9f:	movdqa xmm0,xmm7
    72deb7301fa3:	movdqa xmm1,xmm8
    72deb7301fa8:	addpd  xmm0,xmm1
    72deb7301fac:	movdqa xmm14,xmm0
    72deb7301fb1:	movdqu xmm15,XMMWORD PTR [rip+0x82d6]        # 0x72deb730a290
    72deb7301fba:	pand   xmm14,xmm15
    72deb7301fbf:	movdqu xmm15,XMMWORD PTR [rip+0x82d8]        # 0x72deb730a2a0
    72deb7301fc8:	pcmpeqq xmm14,xmm15
    72deb7301fce:	movdqa xmm15,xmm0
    72deb7301fd3:	cmpunordpd xmm15,xmm0
    72deb7301fd9:	por    xmm14,xmm15
    72deb7301fde:	pmovmskb ecx,xmm14
    72deb7301fe3:	jrcxz  0x72deb7301fea
    72deb7301fe5:	jmp    0x72deb7303296
    72deb7301fea:	movdqa xmm12,xmm0
    72deb7301fef:	movdqa xmm0,xmm3
    72deb7301ff3:	movdqa xmm1,xmm9
    72deb7301ff8:	addpd  xmm0,xmm1
    72deb7301ffc:	movdqa xmm14,xmm0
    72deb7302001:	movdqu xmm15,XMMWORD PTR [rip+0x8286]        # 0x72deb730a290
    72deb730200a:	pand   xmm14,xmm15
    72deb730200f:	movdqu xmm15,XMMWORD PTR [rip+0x8288]        # 0x72deb730a2a0
    72deb7302018:	pcmpeqq xmm14,xmm15
    72deb730201e:	movdqa xmm15,xmm0
    72deb7302023:	cmpunordpd xmm15,xmm0
    72deb7302029:	por    xmm14,xmm15
    72deb730202e:	pmovmskb ecx,xmm14
    72deb7302033:	jrcxz  0x72deb730203a
    72deb7302035:	jmp    0x72deb73032bb
    72deb730203a:	movdqa xmm7,xmm0
    72deb730203e:	movdqu XMMWORD PTR [r12+0x160],xmm7
    72deb7302048:	movdqa xmm0,xmm6
    72deb730204c:	movdqa xmm1,xmm2
    72deb7302050:	pshufd xmm1,xmm1,0x44
    72deb7302055:	mulpd  xmm0,xmm1
    72deb7302059:	movdqa xmm14,xmm0
    72deb730205e:	movdqu xmm15,XMMWORD PTR [rip+0x8229]        # 0x72deb730a290
    72deb7302067:	pand   xmm14,xmm15
    72deb730206c:	movdqu xmm15,XMMWORD PTR [rip+0x822b]        # 0x72deb730a2a0
    72deb7302075:	pcmpeqq xmm14,xmm15
    72deb730207b:	movdqa xmm15,xmm0
    72deb7302080:	cmpunordpd xmm15,xmm0
    72deb7302086:	por    xmm14,xmm15
    72deb730208b:	pmovmskb ecx,xmm14
    72deb7302090:	jrcxz  0x72deb7302097
    72deb7302092:	jmp    0x72deb73032e0
    72deb7302097:	movdqa xmm3,xmm0
    72deb730209b:	movdqu XMMWORD PTR [r12+0x240],xmm3
    72deb73020a5:	movdqu xmm6,XMMWORD PTR [r12+0x2b0]
    72deb73020af:	movdqa xmm0,xmm6
    72deb73020b3:	movdqa xmm1,xmm2
    72deb73020b7:	pshufd xmm1,xmm1,0x44
    72deb73020bc:	mulpd  xmm0,xmm1
    72deb73020c0:	movdqa xmm14,xmm0
    72deb73020c5:	movdqu xmm15,XMMWORD PTR [rip+0x81c2]        # 0x72deb730a290
    72deb73020ce:	pand   xmm14,xmm15
    72deb73020d3:	movdqu xmm15,XMMWORD PTR [rip+0x81c4]        # 0x72deb730a2a0
    72deb73020dc:	pcmpeqq xmm14,xmm15
    72deb73020e2:	movdqa xmm15,xmm0
    72deb73020e7:	cmpunordpd xmm15,xmm0
    72deb73020ed:	por    xmm14,xmm15
    72deb73020f2:	pmovmskb ecx,xmm14
    72deb73020f7:	jrcxz  0x72deb73020fe
    72deb73020f9:	jmp    0x72deb7303304
    72deb73020fe:	movdqa xmm8,xmm0
    72deb7302103:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    72deb730210d:	movdqa xmm0,xmm5
    72deb7302111:	movdqa xmm1,xmm2
    72deb7302115:	pshufd xmm1,xmm1,0x44
    72deb730211a:	mulpd  xmm0,xmm1
    72deb730211e:	movdqa xmm14,xmm0
    72deb7302123:	movdqu xmm15,XMMWORD PTR [rip+0x8164]        # 0x72deb730a290
    72deb730212c:	pand   xmm14,xmm15
    72deb7302131:	movdqu xmm15,XMMWORD PTR [rip+0x8166]        # 0x72deb730a2a0
    72deb730213a:	pcmpeqq xmm14,xmm15
    72deb7302140:	movdqa xmm15,xmm0
    72deb7302145:	cmpunordpd xmm15,xmm0
    72deb730214b:	por    xmm14,xmm15
    72deb7302150:	pmovmskb ecx,xmm14
    72deb7302155:	jrcxz  0x72deb730215c
    72deb7302157:	jmp    0x72deb7303328
    72deb730215c:	movdqa xmm6,xmm0
    72deb7302160:	movdqu XMMWORD PTR [r12+0x170],xmm6
    72deb730216a:	movdqa xmm0,xmm10
    72deb730216f:	movdqa xmm1,xmm11
    72deb7302174:	addpd  xmm0,xmm1
    72deb7302178:	movdqa xmm14,xmm0
    72deb730217d:	movdqu xmm15,XMMWORD PTR [rip+0x810a]        # 0x72deb730a290
    72deb7302186:	pand   xmm14,xmm15
    72deb730218b:	movdqu xmm15,XMMWORD PTR [rip+0x810c]        # 0x72deb730a2a0
    72deb7302194:	pcmpeqq xmm14,xmm15
    72deb730219a:	movdqa xmm15,xmm0
    72deb730219f:	cmpunordpd xmm15,xmm0
    72deb73021a5:	por    xmm14,xmm15
    72deb73021aa:	pmovmskb ecx,xmm14
    72deb73021af:	jrcxz  0x72deb73021b6
    72deb73021b1:	jmp    0x72deb730334c
    72deb73021b6:	movdqa xmm5,xmm0
    72deb73021ba:	movdqu XMMWORD PTR [r12+0x180],xmm5
    72deb73021c4:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    72deb73021ce:	movdqa xmm1,xmm2
    72deb73021d2:	pshufd xmm1,xmm1,0x44
    72deb73021d7:	mulpd  xmm0,xmm1
    72deb73021db:	movdqa xmm14,xmm0
    72deb73021e0:	movdqu xmm15,XMMWORD PTR [rip+0x80a7]        # 0x72deb730a290
    72deb73021e9:	pand   xmm14,xmm15
    72deb73021ee:	movdqu xmm15,XMMWORD PTR [rip+0x80a9]        # 0x72deb730a2a0
    72deb73021f7:	pcmpeqq xmm14,xmm15
    72deb73021fd:	movdqa xmm15,xmm0
    72deb7302202:	cmpunordpd xmm15,xmm0
    72deb7302208:	por    xmm14,xmm15
    72deb730220d:	pmovmskb ecx,xmm14
    72deb7302212:	jrcxz  0x72deb7302219
    72deb7302214:	jmp    0x72deb7303372
    72deb7302219:	movdqa xmm9,xmm0
    72deb730221e:	movdqu XMMWORD PTR [r12+0x210],xmm9
    72deb7302228:	movdqa xmm0,xmm4
    72deb730222c:	movdqa xmm1,xmm3
    72deb7302230:	addpd  xmm0,xmm1
    72deb7302234:	movdqa xmm14,xmm0
    72deb7302239:	movdqu xmm15,XMMWORD PTR [rip+0x804e]        # 0x72deb730a290
    72deb7302242:	pand   xmm14,xmm15
    72deb7302247:	movdqu xmm15,XMMWORD PTR [rip+0x8050]        # 0x72deb730a2a0
    72deb7302250:	pcmpeqq xmm14,xmm15
    72deb7302256:	movdqa xmm15,xmm0
    72deb730225b:	cmpunordpd xmm15,xmm0
    72deb7302261:	por    xmm14,xmm15
    72deb7302266:	pmovmskb ecx,xmm14
    72deb730226b:	jrcxz  0x72deb7302272
    72deb730226d:	jmp    0x72deb730339c
    72deb7302272:	movdqa xmm10,xmm0
    72deb7302277:	movdqu XMMWORD PTR [r12+0x220],xmm10
    72deb7302281:	movdqu xmm3,XMMWORD PTR [r12+0x290]
    72deb730228b:	movdqa xmm0,xmm3
    72deb730228f:	movdqa xmm1,xmm2
    72deb7302293:	pshufd xmm1,xmm1,0x44
    72deb7302298:	mulpd  xmm0,xmm1
    72deb730229c:	movdqa xmm14,xmm0
    72deb73022a1:	movdqu xmm15,XMMWORD PTR [rip+0x7fe6]        # 0x72deb730a290
    72deb73022aa:	pand   xmm14,xmm15
    72deb73022af:	movdqu xmm15,XMMWORD PTR [rip+0x7fe8]        # 0x72deb730a2a0
    72deb73022b8:	pcmpeqq xmm14,xmm15
    72deb73022be:	movdqa xmm15,xmm0
    72deb73022c3:	cmpunordpd xmm15,xmm0
    72deb73022c9:	por    xmm14,xmm15
    72deb73022ce:	pmovmskb ecx,xmm14
    72deb73022d3:	jrcxz  0x72deb73022da
    72deb73022d5:	jmp    0x72deb73033c0
    72deb73022da:	movdqa xmm4,xmm0
    72deb73022de:	movdqu XMMWORD PTR [r12+0x230],xmm4
    72deb73022e8:	movdqa xmm0,xmm12
    72deb73022ed:	movdqa xmm1,xmm8
    72deb73022f2:	addpd  xmm0,xmm1
    72deb73022f6:	movdqa xmm14,xmm0
    72deb73022fb:	movdqu xmm15,XMMWORD PTR [rip+0x7f8c]        # 0x72deb730a290
    72deb7302304:	pand   xmm14,xmm15
    72deb7302309:	movdqu xmm15,XMMWORD PTR [rip+0x7f8e]        # 0x72deb730a2a0
    72deb7302312:	pcmpeqq xmm14,xmm15
    72deb7302318:	movdqa xmm15,xmm0
    72deb730231d:	cmpunordpd xmm15,xmm0
    72deb7302323:	por    xmm14,xmm15
    72deb7302328:	pmovmskb ecx,xmm14
    72deb730232d:	jrcxz  0x72deb7302334
    72deb730232f:	jmp    0x72deb73033e4
    72deb7302334:	movdqa xmm3,xmm0
    72deb7302338:	movdqu XMMWORD PTR [r12+0x140],xmm3
    72deb7302342:	movdqu xmm8,XMMWORD PTR [r12+0x1e0]
    72deb730234c:	movdqa xmm0,xmm8
    72deb7302351:	movdqa xmm1,xmm2
    72deb7302355:	pshufd xmm1,xmm1,0x44
    72deb730235a:	mulpd  xmm0,xmm1
    72deb730235e:	movdqa xmm14,xmm0
    72deb7302363:	movdqu xmm15,XMMWORD PTR [rip+0x7f24]        # 0x72deb730a290
    72deb730236c:	pand   xmm14,xmm15
    72deb7302371:	movdqu xmm15,XMMWORD PTR [rip+0x7f26]        # 0x72deb730a2a0
    72deb730237a:	pcmpeqq xmm14,xmm15
    72deb7302380:	movdqa xmm15,xmm0
    72deb7302385:	cmpunordpd xmm15,xmm0
    72deb730238b:	por    xmm14,xmm15
    72deb7302390:	pmovmskb ecx,xmm14
    72deb7302395:	jrcxz  0x72deb730239c
    72deb7302397:	jmp    0x72deb730340a
    72deb730239c:	movdqa xmm11,xmm0
    72deb73023a1:	movdqu XMMWORD PTR [r12+0x130],xmm11
    72deb73023ab:	movdqa xmm0,xmm7
    72deb73023af:	movdqa xmm1,xmm6
    72deb73023b3:	addpd  xmm0,xmm1
    72deb73023b7:	movdqa xmm14,xmm0
    72deb73023bc:	movdqu xmm15,XMMWORD PTR [rip+0x7ecb]        # 0x72deb730a290
    72deb73023c5:	pand   xmm14,xmm15
    72deb73023ca:	movdqu xmm15,XMMWORD PTR [rip+0x7ecd]        # 0x72deb730a2a0
    72deb73023d3:	pcmpeqq xmm14,xmm15
    72deb73023d9:	movdqa xmm15,xmm0
    72deb73023de:	cmpunordpd xmm15,xmm0
    72deb73023e4:	por    xmm14,xmm15
    72deb73023e9:	pmovmskb ecx,xmm14
    72deb73023ee:	jrcxz  0x72deb73023f5
    72deb73023f0:	jmp    0x72deb730342f
    72deb73023f5:	movdqa xmm2,xmm0
    72deb73023f9:	movdqu XMMWORD PTR [r12+0x150],xmm2
    72deb7302403:	mov    r13,r14
    72deb7302406:	add    r13,0x70
    72deb730240a:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    72deb7302410:	movdqu XMMWORD PTR [r12+0x240],xmm6
    72deb730241a:	movdqa xmm0,xmm5
    72deb730241e:	movdqa xmm1,xmm9
    72deb7302423:	addpd  xmm0,xmm1
    72deb7302427:	movdqa xmm14,xmm0
    72deb730242c:	movdqu xmm15,XMMWORD PTR [rip+0x7e5b]        # 0x72deb730a290
    72deb7302435:	pand   xmm14,xmm15
    72deb730243a:	movdqu xmm15,XMMWORD PTR [rip+0x7e5d]        # 0x72deb730a2a0
    72deb7302443:	pcmpeqq xmm14,xmm15
    72deb7302449:	movdqa xmm15,xmm0
    72deb730244e:	cmpunordpd xmm15,xmm0
    72deb7302454:	por    xmm14,xmm15
    72deb7302459:	pmovmskb ecx,xmm14
    72deb730245e:	jrcxz  0x72deb7302465
    72deb7302460:	jmp    0x72deb7303453
    72deb7302465:	movdqa xmm7,xmm0
    72deb7302469:	movdqu XMMWORD PTR [r12+0x170],xmm7
    72deb7302473:	movdqu xmm5,XMMWORD PTR [r12+0x280]
    72deb730247d:	movdqa xmm0,xmm6
    72deb7302481:	movdqa xmm1,xmm5
    72deb7302485:	pshufd xmm1,xmm1,0x44
    72deb730248a:	mulpd  xmm0,xmm1
    72deb730248e:	movdqa xmm14,xmm0
    72deb7302493:	movdqu xmm15,XMMWORD PTR [rip+0x7df4]        # 0x72deb730a290
    72deb730249c:	pand   xmm14,xmm15
    72deb73024a1:	movdqu xmm15,XMMWORD PTR [rip+0x7df6]        # 0x72deb730a2a0
    72deb73024aa:	pcmpeqq xmm14,xmm15
    72deb73024b0:	movdqa xmm15,xmm0
    72deb73024b5:	cmpunordpd xmm15,xmm0
    72deb73024bb:	por    xmm14,xmm15
    72deb73024c0:	pmovmskb ecx,xmm14
    72deb73024c5:	jrcxz  0x72deb73024cc
    72deb73024c7:	jmp    0x72deb7303478
    72deb73024cc:	movdqa xmm8,xmm0
    72deb73024d1:	movdqu XMMWORD PTR [r12+0x160],xmm8
    72deb73024db:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    72deb73024e5:	movdqa xmm1,xmm5
    72deb73024e9:	pshufd xmm1,xmm1,0x44
    72deb73024ee:	mulpd  xmm0,xmm1
    72deb73024f2:	movdqa xmm14,xmm0
    72deb73024f7:	movdqu xmm15,XMMWORD PTR [rip+0x7d90]        # 0x72deb730a290
    72deb7302500:	pand   xmm14,xmm15
    72deb7302505:	movdqu xmm15,XMMWORD PTR [rip+0x7d92]        # 0x72deb730a2a0
    72deb730250e:	pcmpeqq xmm14,xmm15
    72deb7302514:	movdqa xmm15,xmm0
    72deb7302519:	cmpunordpd xmm15,xmm0
    72deb730251f:	por    xmm14,xmm15
    72deb7302524:	pmovmskb ecx,xmm14
    72deb7302529:	jrcxz  0x72deb7302530
    72deb730252b:	jmp    0x72deb730349c
    72deb7302530:	movdqa xmm6,xmm0
    72deb7302534:	movdqu XMMWORD PTR [r12+0x180],xmm6
    72deb730253e:	movdqa xmm0,xmm10
    72deb7302543:	movdqa xmm1,xmm4
    72deb7302547:	addpd  xmm0,xmm1
    72deb730254b:	movdqa xmm14,xmm0
    72deb7302550:	movdqu xmm15,XMMWORD PTR [rip+0x7d37]        # 0x72deb730a290
    72deb7302559:	pand   xmm14,xmm15
    72deb730255e:	movdqu xmm15,XMMWORD PTR [rip+0x7d39]        # 0x72deb730a2a0
    72deb7302567:	pcmpeqq xmm14,xmm15
    72deb730256d:	movdqa xmm15,xmm0
    72deb7302572:	cmpunordpd xmm15,xmm0
    72deb7302578:	por    xmm14,xmm15
    72deb730257d:	pmovmskb ecx,xmm14
    72deb7302582:	jrcxz  0x72deb7302589
    72deb7302584:	jmp    0x72deb73034c6
    72deb7302589:	movdqa xmm9,xmm0
    72deb730258e:	movdqu XMMWORD PTR [r12+0x210],xmm9
    72deb7302598:	mov    r13,r14
    72deb730259b:	add    r13,0x10
    72deb730259f:	movdqu xmm4,XMMWORD PTR [r14]
    72deb73025a4:	movdqu xmm10,XMMWORD PTR [r13+0x0]
    72deb73025aa:	movdqu XMMWORD PTR [r12+0x230],xmm10
    72deb73025b4:	movdqa xmm0,xmm3
    72deb73025b8:	movdqa xmm1,xmm11
    72deb73025bd:	addpd  xmm0,xmm1
    72deb73025c1:	movdqa xmm14,xmm0
    72deb73025c6:	movdqu xmm15,XMMWORD PTR [rip+0x7cc1]        # 0x72deb730a290
    72deb73025cf:	pand   xmm14,xmm15
    72deb73025d4:	movdqu xmm15,XMMWORD PTR [rip+0x7cc3]        # 0x72deb730a2a0
    72deb73025dd:	pcmpeqq xmm14,xmm15
    72deb73025e3:	movdqa xmm15,xmm0
    72deb73025e8:	cmpunordpd xmm15,xmm0
    72deb73025ee:	por    xmm14,xmm15
    72deb73025f3:	pmovmskb ecx,xmm14
    72deb73025f8:	jrcxz  0x72deb73025ff
    72deb73025fa:	jmp    0x72deb73034eb
    72deb73025ff:	movdqa xmm12,xmm0
    72deb7302604:	movdqu XMMWORD PTR [r12+0x130],xmm12
    72deb730260e:	movdqa xmm0,xmm10
    72deb7302613:	movdqa xmm1,xmm5
    72deb7302617:	pshufd xmm1,xmm1,0x44
    72deb730261c:	mulpd  xmm0,xmm1
    72deb7302620:	movdqa xmm14,xmm0
    72deb7302625:	movdqu xmm15,XMMWORD PTR [rip+0x7c62]        # 0x72deb730a290
    72deb730262e:	pand   xmm14,xmm15
    72deb7302633:	movdqu xmm15,XMMWORD PTR [rip+0x7c64]        # 0x72deb730a2a0
    72deb730263c:	pcmpeqq xmm14,xmm15
    72deb7302642:	movdqa xmm15,xmm0
    72deb7302647:	cmpunordpd xmm15,xmm0
    72deb730264d:	por    xmm14,xmm15
    72deb7302652:	pmovmskb ecx,xmm14
    72deb7302657:	jrcxz  0x72deb730265e
    72deb7302659:	jmp    0x72deb7303510
    72deb730265e:	movdqa xmm3,xmm0
    72deb7302662:	movdqu XMMWORD PTR [r12+0x220],xmm3
    72deb730266c:	movdqa xmm0,xmm4
    72deb7302670:	movdqa xmm1,xmm5
    72deb7302674:	pshufd xmm1,xmm1,0x44
    72deb7302679:	mulpd  xmm0,xmm1
    72deb730267d:	movdqa xmm14,xmm0
    72deb7302682:	movdqu xmm15,XMMWORD PTR [rip+0x7c05]        # 0x72deb730a290
    72deb730268b:	pand   xmm14,xmm15
    72deb7302690:	movdqu xmm15,XMMWORD PTR [rip+0x7c07]        # 0x72deb730a2a0
    72deb7302699:	pcmpeqq xmm14,xmm15
    72deb730269f:	movdqa xmm15,xmm0
    72deb73026a4:	cmpunordpd xmm15,xmm0
    72deb73026aa:	por    xmm14,xmm15
    72deb73026af:	pmovmskb ecx,xmm14
    72deb73026b4:	jrcxz  0x72deb73026bb
    72deb73026b6:	jmp    0x72deb7303535
    72deb73026bb:	movdqa xmm10,xmm0
    72deb73026c0:	movdqa xmm0,xmm2
    72deb73026c4:	movdqa xmm1,xmm8
    72deb73026c9:	addpd  xmm0,xmm1
    72deb73026cd:	movdqa xmm14,xmm0
    72deb73026d2:	movdqu xmm15,XMMWORD PTR [rip+0x7bb5]        # 0x72deb730a290
    72deb73026db:	pand   xmm14,xmm15
    72deb73026e0:	movdqu xmm15,XMMWORD PTR [rip+0x7bb7]        # 0x72deb730a2a0
    72deb73026e9:	pcmpeqq xmm14,xmm15
    72deb73026ef:	movdqa xmm15,xmm0
    72deb73026f4:	cmpunordpd xmm15,xmm0
    72deb73026fa:	por    xmm14,xmm15
    72deb73026ff:	pmovmskb ecx,xmm14
    72deb7302704:	jrcxz  0x72deb730270b
    72deb7302706:	jmp    0x72deb7303559
    72deb730270b:	movdqa xmm4,xmm0
    72deb730270f:	movdqu XMMWORD PTR [r12+0x140],xmm4
    72deb7302719:	movdqa xmm0,xmm7
    72deb730271d:	movdqa xmm1,xmm6
    72deb7302721:	addpd  xmm0,xmm1
    72deb7302725:	movdqa xmm14,xmm0
    72deb730272a:	movdqu xmm15,XMMWORD PTR [rip+0x7b5d]        # 0x72deb730a290
    72deb7302733:	pand   xmm14,xmm15
    72deb7302738:	movdqu xmm15,XMMWORD PTR [rip+0x7b5f]        # 0x72deb730a2a0
    72deb7302741:	pcmpeqq xmm14,xmm15
    72deb7302747:	movdqa xmm15,xmm0
    72deb730274c:	cmpunordpd xmm15,xmm0
    72deb7302752:	por    xmm14,xmm15
    72deb7302757:	pmovmskb ecx,xmm14
    72deb730275c:	jrcxz  0x72deb7302763
    72deb730275e:	jmp    0x72deb730357e
    72deb7302763:	movdqa xmm2,xmm0
    72deb7302767:	movdqu XMMWORD PTR [r12+0x150],xmm2
    72deb7302771:	movdqa xmm0,xmm9
    72deb7302776:	movdqa xmm1,xmm3
    72deb730277a:	addpd  xmm0,xmm1
    72deb730277e:	movdqa xmm14,xmm0
    72deb7302783:	movdqu xmm15,XMMWORD PTR [rip+0x7b04]        # 0x72deb730a290
    72deb730278c:	pand   xmm14,xmm15
    72deb7302791:	movdqu xmm15,XMMWORD PTR [rip+0x7b06]        # 0x72deb730a2a0
    72deb730279a:	pcmpeqq xmm14,xmm15
    72deb73027a0:	movdqa xmm15,xmm0
    72deb73027a5:	cmpunordpd xmm15,xmm0
    72deb73027ab:	por    xmm14,xmm15
    72deb73027b0:	pmovmskb ecx,xmm14
    72deb73027b5:	jrcxz  0x72deb73027bc
    72deb73027b7:	jmp    0x72deb73035a2
    72deb73027bc:	movdqa xmm5,xmm0
    72deb73027c0:	movdqu XMMWORD PTR [r12+0x160],xmm5
    72deb73027ca:	movdqa xmm0,xmm12
    72deb73027cf:	movdqa xmm1,xmm10
    72deb73027d4:	addpd  xmm0,xmm1
    72deb73027d8:	movdqa xmm14,xmm0
    72deb73027dd:	movdqu xmm15,XMMWORD PTR [rip+0x7aaa]        # 0x72deb730a290
    72deb73027e6:	pand   xmm14,xmm15
    72deb73027eb:	movdqu xmm15,XMMWORD PTR [rip+0x7aac]        # 0x72deb730a2a0
    72deb73027f4:	pcmpeqq xmm14,xmm15
    72deb73027fa:	movdqa xmm15,xmm0
    72deb73027ff:	cmpunordpd xmm15,xmm0
    72deb7302805:	por    xmm14,xmm15
    72deb730280a:	pmovmskb ecx,xmm14
    72deb730280f:	jrcxz  0x72deb7302816
    72deb7302811:	jmp    0x72deb73035c7
    72deb7302816:	movdqa xmm3,xmm0
    72deb730281a:	movdqu XMMWORD PTR [r12+0x120],xmm3
    72deb7302824:	mov    r13,r15
    72deb7302827:	add    r13,0x10
    72deb730282b:	movdqu XMMWORD PTR [r15],xmm4
    72deb7302830:	mov    r14d,0x0
    72deb7302836:	mov    DWORD PTR [r12+0x32c],r14d
    72deb730283e:	movdqu XMMWORD PTR [r13+0x0],xmm2
    72deb7302844:	add    r15,0x20
    72deb7302848:	mov    r13,r15
    72deb730284b:	add    r13,0x10
    72deb730284f:	movdqu XMMWORD PTR [r15],xmm5
    72deb7302854:	movdqu XMMWORD PTR [r13+0x0],xmm3
    72deb730285a:	mov    rcx,QWORD PTR [r12+0x380]
    72deb7302862:	jrcxz  0x72deb7302869
    72deb7302864:	jmp    0x72deb7309ab9
    72deb7302869:	cmp    BYTE PTR [rsp+0x8],0x0
    72deb730286e:	jne    0x72deb7300b39
    72deb7302874:	jmp    0x72deb7302879
    72deb7302879:	mov    r13d,DWORD PTR [r12+0x48]
    72deb730287e:	add    r13d,0x1
    72deb7302882:	mov    QWORD PTR [r12+0x48],r13
    72deb7302887:	sub    r13d,0x1f4
    72deb730288e:	mov    rcx,QWORD PTR [r12+0x380]
    72deb7302896:	jrcxz  0x72deb730289d
    72deb7302898:	jmp    0x72deb7309b3e
    72deb730289d:	jne    0x72deb7300b1b
    72deb73028a3:	mov    r11,rax
    72deb73028a6:	lahf
    72deb73028a7:	seto   al
    72deb73028aa:	mov    WORD PTR [rsp],ax
    72deb73028ae:	mov    rax,r11
    72deb73028b1:	jmp    0x72deb73028b6
    72deb73028b6:	mov    r13d,0x0
    72deb73028bc:	mov    QWORD PTR [r12+0x48],r13
    72deb73028c1:	mov    r13,QWORD PTR [r12+0xf8]
    72deb73028c9:	mov    r14,r13
    72deb73028cc:	add    r14,0x140
    72deb73028d3:	mov    r15,QWORD PTR [r14]
    72deb73028d6:	mov    QWORD PTR [r12+0xe8],r15
    72deb73028de:	mov    r14,r13
    72deb73028e1:	add    r14,0x130
    72deb73028e8:	mov    r15,r14
    72deb73028eb:	add    r15,0x8
    72deb73028ef:	mov    rbp,QWORD PTR [r14]
    72deb73028f2:	mov    r14,QWORD PTR [r15]
    72deb73028f5:	mov    r15d,0x0
    72deb73028fb:	mov    QWORD PTR [r12+0x1a0],rbp
    72deb7302903:	mov    QWORD PTR [r12+0x1a8],r15
    72deb730290b:	mov    r15d,0x0
    72deb7302911:	mov    QWORD PTR [r12+0x190],r14
    72deb7302919:	mov    QWORD PTR [r12+0x198],r15
    72deb7302921:	mov    r14,r13
    72deb7302924:	add    r14,0x120
    72deb730292b:	mov    r15,r14
    72deb730292e:	add    r15,0x8
    72deb7302932:	mov    rbp,QWORD PTR [r14]
    72deb7302935:	mov    r14,QWORD PTR [r15]
    72deb7302938:	mov    r15d,0x0
    72deb730293e:	mov    QWORD PTR [r12+0x1c0],rbp
    72deb7302946:	mov    QWORD PTR [r12+0x1c8],r15
    72deb730294e:	mov    r15d,0x0
    72deb7302954:	mov    QWORD PTR [r12+0x1b0],r14
    72deb730295c:	mov    QWORD PTR [r12+0x1b8],r15
    72deb7302964:	mov    r14,r13
    72deb7302967:	add    r14,0x110
    72deb730296e:	mov    r15,r14
    72deb7302971:	add    r15,0x8
    72deb7302975:	mov    rbp,QWORD PTR [r14]
    72deb7302978:	mov    r14,QWORD PTR [r15]
    72deb730297b:	mov    r15d,0x0
    72deb7302981:	mov    QWORD PTR [r12+0x1e0],rbp
    72deb7302989:	mov    QWORD PTR [r12+0x1e8],r15
    72deb7302991:	mov    r15d,0x0
    72deb7302997:	mov    QWORD PTR [r12+0x1d0],r14
    72deb730299f:	mov    QWORD PTR [r12+0x1d8],r15
    72deb73029a7:	mov    r14,r13
    72deb73029aa:	add    r14,0x100
    72deb73029b1:	mov    r15,r14
    72deb73029b4:	add    r15,0x8
    72deb73029b8:	mov    rbp,QWORD PTR [r14]
    72deb73029bb:	mov    r14,QWORD PTR [r15]
    72deb73029be:	mov    r15d,0x0
    72deb73029c4:	mov    QWORD PTR [r12+0x200],rbp
    72deb73029cc:	mov    QWORD PTR [r12+0x208],r15
    72deb73029d4:	mov    r15d,0x0
    72deb73029da:	mov    QWORD PTR [r12+0x1f0],r14
    72deb73029e2:	mov    QWORD PTR [r12+0x1f8],r15
    72deb73029ea:	mov    r14d,0x430000
    72deb73029f0:	mov    QWORD PTR [r12+0x40],r14
    72deb73029f5:	mov    r14d,0x430510
    72deb73029fb:	mov    r15,QWORD PTR [r14]
    72deb73029fe:	mov    r14d,0x0
    72deb7302a04:	mov    QWORD PTR [r12+0x110],r15
    72deb7302a0c:	mov    QWORD PTR [r12+0x118],r14
    72deb7302a14:	add    r13,0x150
    72deb7302a1b:	mov    QWORD PTR [r12+0xf8],r13
    72deb7302a23:	jmp    0x72deb7302a28
    72deb7302a28:	mov    r13,QWORD PTR [r12+0x48]
    72deb7302a2d:	mov    r14,QWORD PTR [r12+0x50]
    72deb7302a32:	add    r14,r13
    72deb7302a35:	movdqu xmm2,XMMWORD PTR [r14]
    72deb7302a3a:	movdqu XMMWORD PTR [r12+0x120],xmm2
    72deb7302a44:	add    r13,0x10
    72deb7302a48:	mov    QWORD PTR [r12+0x48],r13
    72deb7302a4d:	sub    r13,0x200
    72deb7302a54:	mov    r13,QWORD PTR [r12+0x128]
    72deb7302a5c:	mov    r14d,0x0
    72deb7302a62:	mov    QWORD PTR [r12+0x130],r13
    72deb7302a6a:	mov    QWORD PTR [r12+0x138],r14
    72deb7302a72:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    72deb7302a7c:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    72deb7302a86:	movdqa xmm0,xmm2
    72deb7302a8a:	movdqa xmm1,xmm3
    72deb7302a8e:	movq   xmm0,xmm0
    72deb7302a92:	movq   xmm1,xmm1
    72deb7302a96:	addsd  xmm0,xmm1
    72deb7302a9a:	movdqa xmm14,xmm0
    72deb7302a9f:	movdqu xmm15,XMMWORD PTR [rip+0x77e8]        # 0x72deb730a290
    72deb7302aa8:	pand   xmm14,xmm15
    72deb7302aad:	movdqu xmm15,XMMWORD PTR [rip+0x77ea]        # 0x72deb730a2a0
    72deb7302ab6:	pcmpeqq xmm14,xmm15
    72deb7302abc:	movdqa xmm15,xmm0
    72deb7302ac1:	cmpunordpd xmm15,xmm0
    72deb7302ac7:	por    xmm14,xmm15
    72deb7302acc:	pmovmskb ecx,xmm14
    72deb7302ad1:	jrcxz  0x72deb7302ad8
    72deb7302ad3:	jmp    0x72deb73035ed
    72deb7302ad8:	movdqa xmm4,xmm0
    72deb7302adc:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    72deb7302ae6:	movdqa xmm0,xmm4
    72deb7302aea:	movdqa xmm1,xmm2
    72deb7302aee:	movq   xmm0,xmm0
    72deb7302af2:	movq   xmm1,xmm1
    72deb7302af6:	addsd  xmm0,xmm1
    72deb7302afa:	movdqa xmm14,xmm0
    72deb7302aff:	movdqu xmm15,XMMWORD PTR [rip+0x7788]        # 0x72deb730a290
    72deb7302b08:	pand   xmm14,xmm15
    72deb7302b0d:	movdqu xmm15,XMMWORD PTR [rip+0x778a]        # 0x72deb730a2a0
    72deb7302b16:	pcmpeqq xmm14,xmm15
    72deb7302b1c:	movdqa xmm15,xmm0
    72deb7302b21:	cmpunordpd xmm15,xmm0
    72deb7302b27:	por    xmm14,xmm15
    72deb7302b2c:	pmovmskb ecx,xmm14
    72deb7302b31:	jrcxz  0x72deb7302b38
    72deb7302b33:	jmp    0x72deb730362c
    72deb7302b38:	movdqa xmm3,xmm0
    72deb7302b3c:	movdqu XMMWORD PTR [r12+0x110],xmm3
    72deb7302b46:	mov    rcx,QWORD PTR [r12+0x380]
    72deb7302b4e:	jrcxz  0x72deb7302b55
    72deb7302b50:	jmp    0x72deb7309bd2
    72deb7302b55:	jne    0x72deb7302b6e
    72deb7302b5b:	mov    r11,rax
    72deb7302b5e:	lahf
    72deb7302b5f:	seto   al
    72deb7302b62:	mov    WORD PTR [rsp],ax
    72deb7302b66:	mov    rax,r11
    72deb7302b69:	jmp    0x72deb7302b81
    72deb7302b6e:	mov    r11,rax
    72deb7302b71:	lahf
    72deb7302b72:	seto   al
    72deb7302b75:	mov    WORD PTR [rsp],ax
    72deb7302b79:	mov    rax,r11
    72deb7302b7c:	jmp    0x72deb7302a28
    72deb7302b81:	mov    r13,QWORD PTR [r12+0x40]
    72deb7302b86:	add    r13,0x510
    72deb7302b8d:	mov    r14,QWORD PTR [r12+0x110]
    72deb7302b95:	mov    QWORD PTR [r13+0x0],r14
    72deb7302b99:	mov    r13d,0x0
    72deb7302b9f:	mov    DWORD PTR [r12+0x32c],r13d
    72deb7302ba7:	mov    rcx,QWORD PTR [r12+0x380]
    72deb7302baf:	jrcxz  0x72deb7302bb6
    72deb7302bb1:	jmp    0x72deb7309c66
    72deb7302bb6:	mov    r13,QWORD PTR [r12+0xf0]
    72deb7302bbe:	mov    QWORD PTR [r12+0x100],r13
    72deb7302bc6:	mov    r11,QWORD PTR [rsp]
    72deb7302bca:	mov    QWORD PTR [r12+0x398],r11
    72deb7302bd2:	mov    rdi,QWORD PTR [r12+0x100]
    72deb7302bda:	add    rsp,0x150
    72deb7302be1:	movabs r11,0x5b63a40e2940
    72deb7302beb:	jmp    r11
    72deb7302bee:	movdqa xmm0,xmm2
    72deb7302bf2:	movdqa xmm1,xmm3
    72deb7302bf6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302bff:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302c08:	call   0x72deb7303670
    72deb7302c0d:	jmp    0x72deb7300571
    72deb7302c12:	movdqa xmm0,xmm2
    72deb7302c16:	movdqa xmm1,xmm3
    72deb7302c1a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302c23:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302c2c:	call   0x72deb7303670
    72deb7302c31:	jmp    0x72deb73005fd
    72deb7302c36:	movdqa xmm0,xmm9
    72deb7302c3b:	movdqa xmm1,xmm2
    72deb7302c3f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302c48:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302c51:	call   0x72deb7303740
    72deb7302c56:	jmp    0x72deb7300d57
    72deb7302c5b:	movdqa xmm0,xmm8
    72deb7302c60:	movdqa xmm1,xmm2
    72deb7302c64:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302c6d:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302c76:	call   0x72deb7303850
    72deb7302c7b:	jmp    0x72deb7300db6
    72deb7302c80:	movdqa xmm0,xmm9
    72deb7302c85:	movdqa xmm1,xmm7
    72deb7302c89:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302c92:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302c9b:	call   0x72deb7303970
    72deb7302ca0:	jmp    0x72deb7300e2b
    72deb7302ca5:	movdqa xmm0,xmm9
    72deb7302caa:	movdqa xmm1,xmm6
    72deb7302cae:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302cb7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302cc0:	call   0x72deb7303a90
    72deb7302cc5:	jmp    0x72deb7300e7b
    72deb7302cca:	movdqa xmm0,xmm9
    72deb7302ccf:	movdqa xmm1,xmm6
    72deb7302cd3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302cdc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302ce5:	call   0x72deb7303bb0
    72deb7302cea:	jmp    0x72deb7300ed4
    72deb7302cef:	movdqa xmm0,xmm9
    72deb7302cf4:	movdqa xmm1,xmm2
    72deb7302cf8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302d01:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302d0a:	call   0x72deb7303ce0
    72deb7302d0f:	jmp    0x72deb7300f75
    72deb7302d14:	mov    r11,rax
    72deb7302d17:	lahf
    72deb7302d18:	seto   al
    72deb7302d1b:	mov    WORD PTR [rsp],ax
    72deb7302d1f:	mov    rax,r11
    72deb7302d22:	movdqa xmm0,xmm10
    72deb7302d27:	movdqa xmm1,xmm9
    72deb7302d2c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302d35:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302d3e:	call   0x72deb7303e20
    72deb7302d43:	mov    r11,rax
    72deb7302d46:	movzx  eax,WORD PTR [rsp]
    72deb7302d4a:	add    al,0x7f
    72deb7302d4c:	sahf
    72deb7302d4d:	mov    rax,r11
    72deb7302d50:	jmp    0x72deb7300fe0
    72deb7302d55:	mov    r11,rax
    72deb7302d58:	lahf
    72deb7302d59:	seto   al
    72deb7302d5c:	mov    WORD PTR [rsp],ax
    72deb7302d60:	mov    rax,r11
    72deb7302d63:	movdqa xmm0,xmm8
    72deb7302d68:	movdqa xmm1,xmm10
    72deb7302d6d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302d76:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302d7f:	call   0x72deb7303e20
    72deb7302d84:	mov    r11,rax
    72deb7302d87:	movzx  eax,WORD PTR [rsp]
    72deb7302d8b:	add    al,0x7f
    72deb7302d8d:	sahf
    72deb7302d8e:	mov    rax,r11
    72deb7302d91:	jmp    0x72deb7301040
    72deb7302d96:	mov    r11,rax
    72deb7302d99:	lahf
    72deb7302d9a:	seto   al
    72deb7302d9d:	mov    WORD PTR [rsp],ax
    72deb7302da1:	mov    rax,r11
    72deb7302da4:	movdqa xmm0,xmm7
    72deb7302da8:	movdqa xmm1,xmm10
    72deb7302dad:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302db6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302dbf:	call   0x72deb7303ff0
    72deb7302dc4:	mov    r11,rax
    72deb7302dc7:	movzx  eax,WORD PTR [rsp]
    72deb7302dcb:	add    al,0x7f
    72deb7302dcd:	sahf
    72deb7302dce:	mov    rax,r11
    72deb7302dd1:	jmp    0x72deb7301099
    72deb7302dd6:	movdqa xmm0,xmm12
    72deb7302ddb:	movdqa xmm1,xmm9
    72deb7302de0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302de9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302df2:	call   0x72deb73041b0
    72deb7302df7:	jmp    0x72deb7301211
    72deb7302dfc:	movdqa xmm0,xmm6
    72deb7302e00:	movdqa xmm1,xmm4
    72deb7302e04:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302e0d:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302e16:	call   0x72deb73043b0
    72deb7302e1b:	jmp    0x72deb730127f
    72deb7302e20:	movdqa xmm0,xmm8
    72deb7302e25:	movdqa xmm1,xmm11
    72deb7302e2a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302e33:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302e3c:	call   0x72deb73045a0
    72deb7302e41:	jmp    0x72deb73012da
    72deb7302e46:	movdqa xmm0,xmm5
    72deb7302e4a:	movdqa xmm1,xmm2
    72deb7302e4e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302e57:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302e60:	call   0x72deb7304790
    72deb7302e65:	jmp    0x72deb7301337
    72deb7302e6a:	movdqa xmm0,xmm9
    72deb7302e6f:	movdqa xmm1,xmm5
    72deb7302e73:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302e7c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302e85:	call   0x72deb7304960
    72deb7302e8a:	jmp    0x72deb730139f
    72deb7302e8f:	movdqa xmm0,xmm13
    72deb7302e94:	movdqa xmm1,xmm2
    72deb7302e98:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302ea1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302eaa:	call   0x72deb7304b40
    72deb7302eaf:	jmp    0x72deb7301418
    72deb7302eb4:	movdqa xmm0,xmm9
    72deb7302eb9:	movdqa xmm1,xmm5
    72deb7302ebd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302ec6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302ecf:	call   0x72deb7304d30
    72deb7302ed4:	jmp    0x72deb73014a5
    72deb7302ed9:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    72deb7302ee3:	movdqa xmm1,xmm6
    72deb7302ee7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302ef0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302ef9:	call   0x72deb7304ef0
    72deb7302efe:	jmp    0x72deb730159a
    72deb7302f03:	movdqa xmm0,xmm9
    72deb7302f08:	movdqa xmm1,xmm5
    72deb7302f0c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302f15:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302f1e:	call   0x72deb73050d0
    72deb7302f23:	jmp    0x72deb73015f8
    72deb7302f28:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    72deb7302f32:	movdqa xmm1,xmm11
    72deb7302f37:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302f40:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302f49:	call   0x72deb73052b0
    72deb7302f4e:	jmp    0x72deb7301671
    72deb7302f53:	movdqa xmm0,xmm12
    72deb7302f58:	movdqa xmm1,xmm8
    72deb7302f5d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302f66:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302f6f:	call   0x72deb73054a0
    72deb7302f74:	jmp    0x72deb73016cc
    72deb7302f79:	movdqa xmm0,xmm9
    72deb7302f7e:	movdqa xmm1,xmm5
    72deb7302f82:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302f8b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302f94:	call   0x72deb7305690
    72deb7302f99:	jmp    0x72deb730174d
    72deb7302f9e:	movdqa xmm0,xmm4
    72deb7302fa2:	movdqa xmm1,xmm2
    72deb7302fa6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302faf:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302fb8:	call   0x72deb7305870
    72deb7302fbd:	jmp    0x72deb73017c0
    72deb7302fc2:	movdqa xmm0,xmm13
    72deb7302fc7:	movdqa xmm1,xmm2
    72deb7302fcb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302fd4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7302fdd:	call   0x72deb7305a50
    72deb7302fe2:	jmp    0x72deb7301829
    72deb7302fe7:	movdqa xmm0,xmm5
    72deb7302feb:	movdqa xmm1,xmm2
    72deb7302fef:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7302ff8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303001:	call   0x72deb7305c30
    72deb7303006:	jmp    0x72deb73018a1
    72deb730300b:	movdqa xmm0,xmm3
    72deb730300f:	movdqa xmm1,xmm6
    72deb7303013:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb730301c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303025:	call   0x72deb7305e10
    72deb730302a:	jmp    0x72deb7301914
    72deb730302f:	movdqa xmm0,xmm5
    72deb7303033:	movdqa xmm1,xmm2
    72deb7303037:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303040:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303049:	call   0x72deb7306000
    72deb730304e:	jmp    0x72deb73019b6
    72deb7303053:	movdqa xmm0,xmm10
    72deb7303058:	movdqa xmm1,xmm12
    72deb730305d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303066:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb730306f:	call   0x72deb73061f0
    72deb7303074:	jmp    0x72deb7301a27
    72deb7303079:	movdqa xmm0,xmm7
    72deb730307d:	movdqa xmm1,xmm2
    72deb7303081:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb730308a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303093:	call   0x72deb73063f0
    72deb7303098:	jmp    0x72deb7301a7a
    72deb730309d:	movdqa xmm0,xmm11
    72deb73030a2:	movdqa xmm1,xmm13
    72deb73030a7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73030b0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73030b9:	call   0x72deb73065d0
    72deb73030be:	jmp    0x72deb7301acb
    72deb73030c3:	movdqa xmm0,xmm5
    72deb73030c7:	movdqa xmm1,xmm7
    72deb73030cb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73030d4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73030dd:	call   0x72deb73067b0
    72deb73030e2:	jmp    0x72deb7301b28
    72deb73030e7:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    72deb73030f1:	movdqa xmm1,xmm7
    72deb73030f5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73030fe:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303107:	call   0x72deb7306980
    72deb730310c:	jmp    0x72deb7301b82
    72deb7303111:	movdqa xmm0,xmm8
    72deb7303116:	movdqa xmm1,xmm4
    72deb730311a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303123:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb730312c:	call   0x72deb7306b50
    72deb7303131:	jmp    0x72deb7301bd1
    72deb7303136:	movdqa xmm0,xmm9
    72deb730313b:	movdqa xmm1,xmm6
    72deb730313f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303148:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303151:	call   0x72deb7306d30
    72deb7303156:	jmp    0x72deb7301c2b
    72deb730315b:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    72deb7303165:	movdqa xmm1,xmm7
    72deb7303169:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303172:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb730317b:	call   0x72deb7306f00
    72deb7303180:	jmp    0x72deb7301c8e
    72deb7303185:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    72deb730318f:	movdqa xmm1,xmm7
    72deb7303193:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb730319c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73031a5:	call   0x72deb73070c0
    72deb73031aa:	jmp    0x72deb7301ce7
    72deb73031af:	movdqa xmm0,xmm3
    72deb73031b3:	movdqa xmm1,xmm10
    72deb73031b8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73031c1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73031ca:	call   0x72deb7307290
    72deb73031cf:	jmp    0x72deb7301d41
    72deb73031d4:	movdqa xmm0,xmm2
    72deb73031d8:	movdqa xmm1,xmm11
    72deb73031dd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73031e6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73031ef:	call   0x72deb7307460
    72deb73031f4:	jmp    0x72deb7301d9a
    72deb73031f9:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    72deb7303203:	movdqa xmm1,xmm2
    72deb7303207:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303210:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303219:	call   0x72deb7307620
    72deb730321e:	jmp    0x72deb7301e07
    72deb7303223:	movdqa xmm0,xmm4
    72deb7303227:	movdqa xmm1,xmm5
    72deb730322b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303234:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb730323d:	call   0x72deb73077d0
    72deb7303242:	jmp    0x72deb7301e60
    72deb7303247:	movdqa xmm0,xmm12
    72deb730324c:	movdqa xmm1,xmm6
    72deb7303250:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303259:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303262:	call   0x72deb73079a0
    72deb7303267:	jmp    0x72deb7301eba
    72deb730326c:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    72deb7303276:	movdqa xmm1,xmm2
    72deb730327a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303283:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb730328c:	call   0x72deb73067b0
    72deb7303291:	jmp    0x72deb7301f9a
    72deb7303296:	movdqa xmm0,xmm7
    72deb730329a:	movdqa xmm1,xmm8
    72deb730329f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73032a8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73032b1:	call   0x72deb7306b50
    72deb73032b6:	jmp    0x72deb7301fea
    72deb73032bb:	movdqa xmm0,xmm3
    72deb73032bf:	movdqa xmm1,xmm9
    72deb73032c4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73032cd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73032d6:	call   0x72deb7307b60
    72deb73032db:	jmp    0x72deb730203a
    72deb73032e0:	movdqa xmm0,xmm6
    72deb73032e4:	movdqa xmm1,xmm2
    72deb73032e8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73032f1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73032fa:	call   0x72deb7307d30
    72deb73032ff:	jmp    0x72deb7302097
    72deb7303304:	movdqa xmm0,xmm6
    72deb7303308:	movdqa xmm1,xmm2
    72deb730330c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303315:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb730331e:	call   0x72deb73070c0
    72deb7303323:	jmp    0x72deb73020fe
    72deb7303328:	movdqa xmm0,xmm5
    72deb730332c:	movdqa xmm1,xmm2
    72deb7303330:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303339:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303342:	call   0x72deb7307ef0
    72deb7303347:	jmp    0x72deb730215c
    72deb730334c:	movdqa xmm0,xmm10
    72deb7303351:	movdqa xmm1,xmm11
    72deb7303356:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb730335f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303368:	call   0x72deb73080c0
    72deb730336d:	jmp    0x72deb73021b6
    72deb7303372:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    72deb730337c:	movdqa xmm1,xmm2
    72deb7303380:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303389:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303392:	call   0x72deb7307620
    72deb7303397:	jmp    0x72deb7302219
    72deb730339c:	movdqa xmm0,xmm4
    72deb73033a0:	movdqa xmm1,xmm3
    72deb73033a4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73033ad:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73033b6:	call   0x72deb73077d0
    72deb73033bb:	jmp    0x72deb7302272
    72deb73033c0:	movdqa xmm0,xmm3
    72deb73033c4:	movdqa xmm1,xmm2
    72deb73033c8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73033d1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73033da:	call   0x72deb7308290
    72deb73033df:	jmp    0x72deb73022da
    72deb73033e4:	movdqa xmm0,xmm12
    72deb73033e9:	movdqa xmm1,xmm8
    72deb73033ee:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73033f7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303400:	call   0x72deb7308460
    72deb7303405:	jmp    0x72deb7302334
    72deb730340a:	movdqa xmm0,xmm8
    72deb730340f:	movdqa xmm1,xmm2
    72deb7303413:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb730341c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303425:	call   0x72deb73067b0
    72deb730342a:	jmp    0x72deb730239c
    72deb730342f:	movdqa xmm0,xmm7
    72deb7303433:	movdqa xmm1,xmm6
    72deb7303437:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303440:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303449:	call   0x72deb7308630
    72deb730344e:	jmp    0x72deb73023f5
    72deb7303453:	movdqa xmm0,xmm5
    72deb7303457:	movdqa xmm1,xmm9
    72deb730345c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303465:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb730346e:	call   0x72deb73087f0
    72deb7303473:	jmp    0x72deb7302465
    72deb7303478:	movdqa xmm0,xmm6
    72deb730347c:	movdqa xmm1,xmm5
    72deb7303480:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303489:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303492:	call   0x72deb73089b0
    72deb7303497:	jmp    0x72deb73024cc
    72deb730349c:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    72deb73034a6:	movdqa xmm1,xmm5
    72deb73034aa:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73034b3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73034bc:	call   0x72deb7308b60
    72deb73034c1:	jmp    0x72deb7302530
    72deb73034c6:	movdqa xmm0,xmm10
    72deb73034cb:	movdqa xmm1,xmm4
    72deb73034cf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73034d8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73034e1:	call   0x72deb7308d20
    72deb73034e6:	jmp    0x72deb7302589
    72deb73034eb:	movdqa xmm0,xmm3
    72deb73034ef:	movdqa xmm1,xmm11
    72deb73034f4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73034fd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303506:	call   0x72deb7306b50
    72deb730350b:	jmp    0x72deb73025ff
    72deb7303510:	movdqa xmm0,xmm10
    72deb7303515:	movdqa xmm1,xmm5
    72deb7303519:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303522:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb730352b:	call   0x72deb7308ef0
    72deb7303530:	jmp    0x72deb730265e
    72deb7303535:	movdqa xmm0,xmm4
    72deb7303539:	movdqa xmm1,xmm5
    72deb730353d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb7303546:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb730354f:	call   0x72deb73090c0
    72deb7303554:	jmp    0x72deb73026bb
    72deb7303559:	movdqa xmm0,xmm2
    72deb730355d:	movdqa xmm1,xmm8
    72deb7303562:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb730356b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303574:	call   0x72deb73079a0
    72deb7303579:	jmp    0x72deb730270b
    72deb730357e:	movdqa xmm0,xmm7
    72deb7303582:	movdqa xmm1,xmm6
    72deb7303586:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb730358f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303598:	call   0x72deb7309290
    72deb730359d:	jmp    0x72deb7302763
    72deb73035a2:	movdqa xmm0,xmm9
    72deb73035a7:	movdqa xmm1,xmm3
    72deb73035ab:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73035b4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73035bd:	call   0x72deb7309440
    72deb73035c2:	jmp    0x72deb73027bc
    72deb73035c7:	movdqa xmm0,xmm12
    72deb73035cc:	movdqa xmm1,xmm10
    72deb73035d1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb73035da:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb73035e3:	call   0x72deb73095e0
    72deb73035e8:	jmp    0x72deb7302816
    72deb73035ed:	mov    r11,rax
    72deb73035f0:	lahf
    72deb73035f1:	seto   al
    72deb73035f4:	mov    WORD PTR [rsp],ax
    72deb73035f8:	mov    rax,r11
    72deb73035fb:	movdqa xmm0,xmm2
    72deb73035ff:	movdqa xmm1,xmm3
    72deb7303603:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb730360c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303615:	call   0x72deb7309770
    72deb730361a:	mov    r11,rax
    72deb730361d:	movzx  eax,WORD PTR [rsp]
    72deb7303621:	add    al,0x7f
    72deb7303623:	sahf
    72deb7303624:	mov    rax,r11
    72deb7303627:	jmp    0x72deb7302ad8
    72deb730362c:	mov    r11,rax
    72deb730362f:	lahf
    72deb7303630:	seto   al
    72deb7303633:	mov    WORD PTR [rsp],ax
    72deb7303637:	mov    rax,r11
    72deb730363a:	movdqa xmm0,xmm4
    72deb730363e:	movdqa xmm1,xmm2
    72deb7303642:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72deb730364b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72deb7303654:	call   0x72deb73098d0
    72deb7303659:	mov    r11,rax
    72deb730365c:	movzx  eax,WORD PTR [rsp]
    72deb7303660:	add    al,0x7f
    72deb7303662:	sahf
    72deb7303663:	mov    rax,r11
    72deb7303666:	jmp    0x72deb7302b38
    72deb730366b:	nop    DWORD PTR [rax+rax*1+0x0]
    72deb7303670:	sub    rsp,0x8
    72deb7303674:	mov    QWORD PTR [r12+0x378],0x3
    72deb7303680:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7303686:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb730368c:	mov    QWORD PTR [r12+0x108],rbx
    72deb7303694:	stmxcsr DWORD PTR [r12-0x28]
    72deb730369a:	mov    r10d,DWORD PTR [r12-0x28]
    72deb730369f:	test   r10d,0x3f
    72deb73036a6:	je     0x72deb73036cb
    72deb73036ac:	mov    r11d,r10d
    72deb73036af:	shr    r10d,1
    72deb73036b2:	and    r10d,0x1e
    72deb73036b6:	and    r11d,0x1
    72deb73036ba:	or     r10d,r11d
    72deb73036bd:	or     DWORD PTR [r12+0x314],r10d
    72deb73036c5:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73036cb:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73036d1:	lea    rdi,[rsp+0x110]
    72deb73036d9:	lea    rsi,[rsp+0xf0]
    72deb73036e1:	lea    rdx,[rsp+0x100]
    72deb73036e9:	mov    ecx,0x16
    72deb73036ee:	mov    r8d,0x0
    72deb73036f4:	lea    r9,[r12+0x314]
    72deb73036fc:	movabs r11,0x5b63a3f49650
    72deb7303706:	call   r11
    72deb7303709:	ldmxcsr DWORD PTR [r12-0x28]
    72deb730370f:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7303715:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb730371b:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7303723:	mov    QWORD PTR [r12+0x378],0x2
    72deb730372f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7303738:	add    rsp,0x8
    72deb730373c:	ret
    72deb730373d:	nop    DWORD PTR [rax]
    72deb7303740:	sub    rsp,0x8
    72deb7303744:	mov    QWORD PTR [r12+0x378],0x3
    72deb7303750:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7303756:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb730375c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7303762:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb730376c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7303776:	mov    QWORD PTR [r12+0x108],rbx
    72deb730377e:	stmxcsr DWORD PTR [r12-0x28]
    72deb7303784:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7303789:	test   r10d,0x3f
    72deb7303790:	je     0x72deb73037b5
    72deb7303796:	mov    r11d,r10d
    72deb7303799:	shr    r10d,1
    72deb730379c:	and    r10d,0x1e
    72deb73037a0:	and    r11d,0x1
    72deb73037a4:	or     r10d,r11d
    72deb73037a7:	or     DWORD PTR [r12+0x314],r10d
    72deb73037af:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73037b5:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73037bb:	lea    rdi,[rsp+0x110]
    72deb73037c3:	lea    rsi,[rsp+0xf0]
    72deb73037cb:	lea    rdx,[rsp+0x100]
    72deb73037d3:	mov    ecx,0x16
    72deb73037d8:	mov    r8d,0x0
    72deb73037de:	lea    r9,[r12+0x314]
    72deb73037e6:	movabs r11,0x5b63a3f49650
    72deb73037f0:	call   r11
    72deb73037f3:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73037f9:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73037ff:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7303805:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb730380b:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7303815:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb730381f:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7303827:	mov    QWORD PTR [r12+0x378],0x2
    72deb7303833:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb730383c:	add    rsp,0x8
    72deb7303840:	ret
    72deb7303841:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7303850:	sub    rsp,0x8
    72deb7303854:	mov    QWORD PTR [r12+0x378],0x3
    72deb7303860:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7303866:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb730386c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7303872:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb730387c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7303886:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7303890:	mov    QWORD PTR [r12+0x108],rbx
    72deb7303898:	stmxcsr DWORD PTR [r12-0x28]
    72deb730389e:	mov    r10d,DWORD PTR [r12-0x28]
    72deb73038a3:	test   r10d,0x3f
    72deb73038aa:	je     0x72deb73038cf
    72deb73038b0:	mov    r11d,r10d
    72deb73038b3:	shr    r10d,1
    72deb73038b6:	and    r10d,0x1e
    72deb73038ba:	and    r11d,0x1
    72deb73038be:	or     r10d,r11d
    72deb73038c1:	or     DWORD PTR [r12+0x314],r10d
    72deb73038c9:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73038cf:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73038d5:	lea    rdi,[rsp+0x110]
    72deb73038dd:	lea    rsi,[rsp+0xf0]
    72deb73038e5:	lea    rdx,[rsp+0x100]
    72deb73038ed:	mov    ecx,0x56
    72deb73038f2:	mov    r8d,0x0
    72deb73038f8:	lea    r9,[r12+0x314]
    72deb7303900:	movabs r11,0x5b63a3f49650
    72deb730390a:	call   r11
    72deb730390d:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7303913:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7303919:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb730391f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7303925:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb730392f:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7303939:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7303943:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730394b:	mov    QWORD PTR [r12+0x378],0x2
    72deb7303957:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7303960:	add    rsp,0x8
    72deb7303964:	ret
    72deb7303965:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7303970:	sub    rsp,0x8
    72deb7303974:	mov    QWORD PTR [r12+0x378],0x3
    72deb7303980:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7303986:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb730398c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7303992:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb730399c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73039a6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb73039b0:	mov    QWORD PTR [r12+0x108],rbx
    72deb73039b8:	stmxcsr DWORD PTR [r12-0x28]
    72deb73039be:	mov    r10d,DWORD PTR [r12-0x28]
    72deb73039c3:	test   r10d,0x3f
    72deb73039ca:	je     0x72deb73039ef
    72deb73039d0:	mov    r11d,r10d
    72deb73039d3:	shr    r10d,1
    72deb73039d6:	and    r10d,0x1e
    72deb73039da:	and    r11d,0x1
    72deb73039de:	or     r10d,r11d
    72deb73039e1:	or     DWORD PTR [r12+0x314],r10d
    72deb73039e9:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73039ef:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73039f5:	lea    rdi,[rsp+0x110]
    72deb73039fd:	lea    rsi,[rsp+0xf0]
    72deb7303a05:	lea    rdx,[rsp+0x100]
    72deb7303a0d:	mov    ecx,0x16
    72deb7303a12:	mov    r8d,0x0
    72deb7303a18:	lea    r9,[r12+0x314]
    72deb7303a20:	movabs r11,0x5b63a3f49650
    72deb7303a2a:	call   r11
    72deb7303a2d:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7303a33:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7303a39:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7303a3f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7303a45:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7303a4f:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7303a59:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7303a63:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7303a6b:	mov    QWORD PTR [r12+0x378],0x2
    72deb7303a77:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7303a80:	add    rsp,0x8
    72deb7303a84:	ret
    72deb7303a85:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7303a90:	sub    rsp,0x8
    72deb7303a94:	mov    QWORD PTR [r12+0x378],0x3
    72deb7303aa0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7303aa6:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7303aac:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7303ab6:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7303ac0:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7303aca:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7303ad4:	mov    QWORD PTR [r12+0x108],rbx
    72deb7303adc:	stmxcsr DWORD PTR [r12-0x28]
    72deb7303ae2:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7303ae7:	test   r10d,0x3f
    72deb7303aee:	je     0x72deb7303b13
    72deb7303af4:	mov    r11d,r10d
    72deb7303af7:	shr    r10d,1
    72deb7303afa:	and    r10d,0x1e
    72deb7303afe:	and    r11d,0x1
    72deb7303b02:	or     r10d,r11d
    72deb7303b05:	or     DWORD PTR [r12+0x314],r10d
    72deb7303b0d:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7303b13:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7303b19:	lea    rdi,[rsp+0x110]
    72deb7303b21:	lea    rsi,[rsp+0xf0]
    72deb7303b29:	lea    rdx,[rsp+0x100]
    72deb7303b31:	mov    ecx,0x16
    72deb7303b36:	mov    r8d,0x0
    72deb7303b3c:	lea    r9,[r12+0x314]
    72deb7303b44:	movabs r11,0x5b63a3f49650
    72deb7303b4e:	call   r11
    72deb7303b51:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7303b57:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7303b5d:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7303b63:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7303b6d:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7303b77:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7303b81:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7303b8b:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7303b93:	mov    QWORD PTR [r12+0x378],0x2
    72deb7303b9f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7303ba8:	add    rsp,0x8
    72deb7303bac:	ret
    72deb7303bad:	nop    DWORD PTR [rax]
    72deb7303bb0:	sub    rsp,0x8
    72deb7303bb4:	mov    QWORD PTR [r12+0x378],0x3
    72deb7303bc0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7303bc6:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7303bcc:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7303bd2:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7303bdc:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7303be6:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7303bf0:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7303bfa:	mov    QWORD PTR [r12+0x108],rbx
    72deb7303c02:	stmxcsr DWORD PTR [r12-0x28]
    72deb7303c08:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7303c0d:	test   r10d,0x3f
    72deb7303c14:	je     0x72deb7303c39
    72deb7303c1a:	mov    r11d,r10d
    72deb7303c1d:	shr    r10d,1
    72deb7303c20:	and    r10d,0x1e
    72deb7303c24:	and    r11d,0x1
    72deb7303c28:	or     r10d,r11d
    72deb7303c2b:	or     DWORD PTR [r12+0x314],r10d
    72deb7303c33:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7303c39:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7303c3f:	lea    rdi,[rsp+0x110]
    72deb7303c47:	lea    rsi,[rsp+0xf0]
    72deb7303c4f:	lea    rdx,[rsp+0x100]
    72deb7303c57:	mov    ecx,0x16
    72deb7303c5c:	mov    r8d,0x0
    72deb7303c62:	lea    r9,[r12+0x314]
    72deb7303c6a:	movabs r11,0x5b63a3f49650
    72deb7303c74:	call   r11
    72deb7303c77:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7303c7d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7303c83:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7303c89:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7303c8f:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7303c99:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7303ca3:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7303cad:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7303cb7:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7303cbf:	mov    QWORD PTR [r12+0x378],0x2
    72deb7303ccb:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7303cd4:	add    rsp,0x8
    72deb7303cd8:	ret
    72deb7303cd9:	nop    DWORD PTR [rax+0x0]
    72deb7303ce0:	sub    rsp,0x8
    72deb7303ce4:	mov    QWORD PTR [r12+0x378],0x3
    72deb7303cf0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7303cf6:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7303cfc:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7303d06:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7303d10:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7303d1a:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7303d24:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7303d2e:	mov    QWORD PTR [r12+0x108],rbx
    72deb7303d36:	stmxcsr DWORD PTR [r12-0x28]
    72deb7303d3c:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7303d41:	test   r10d,0x3f
    72deb7303d48:	je     0x72deb7303d6d
    72deb7303d4e:	mov    r11d,r10d
    72deb7303d51:	shr    r10d,1
    72deb7303d54:	and    r10d,0x1e
    72deb7303d58:	and    r11d,0x1
    72deb7303d5c:	or     r10d,r11d
    72deb7303d5f:	or     DWORD PTR [r12+0x314],r10d
    72deb7303d67:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7303d6d:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7303d73:	lea    rdi,[rsp+0x110]
    72deb7303d7b:	lea    rsi,[rsp+0xf0]
    72deb7303d83:	lea    rdx,[rsp+0x100]
    72deb7303d8b:	mov    ecx,0x56
    72deb7303d90:	mov    r8d,0x0
    72deb7303d96:	lea    r9,[r12+0x314]
    72deb7303d9e:	movabs r11,0x5b63a3f49650
    72deb7303da8:	call   r11
    72deb7303dab:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7303db1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7303db7:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7303dbd:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7303dc7:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7303dd1:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7303ddb:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7303de5:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7303def:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7303df7:	mov    QWORD PTR [r12+0x378],0x2
    72deb7303e03:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7303e0c:	add    rsp,0x8
    72deb7303e10:	ret
    72deb7303e11:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7303e20:	sub    rsp,0x8
    72deb7303e24:	mov    QWORD PTR [r12+0x378],0x3
    72deb7303e30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7303e36:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7303e3c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7303e42:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7303e4c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7303e56:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7303e60:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7303e6a:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7303e74:	push   rdx
    72deb7303e75:	push   rsi
    72deb7303e76:	push   r10
    72deb7303e78:	push   r11
    72deb7303e7a:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7303e7f:	mov    r10d,edx
    72deb7303e82:	and    r10d,0xc000
    72deb7303e89:	shl    r10d,0x10
    72deb7303e8d:	mov    r11d,edx
    72deb7303e90:	and    r11d,0x100
    72deb7303e97:	shl    r11d,0x15
    72deb7303e9b:	or     r10d,r11d
    72deb7303e9e:	and    edx,0x1
    72deb7303ea1:	shl    edx,0x1c
    72deb7303ea4:	or     r10d,edx
    72deb7303ea7:	btc    r10,0x1d
    72deb7303eac:	mov    r11d,0xf0000000
    72deb7303eb2:	and    r11,r10
    72deb7303eb5:	movabs rsi,0xffffffff0fffffff
    72deb7303ebf:	and    rbx,rsi
    72deb7303ec2:	or     rbx,r11
    72deb7303ec5:	pop    r11
    72deb7303ec7:	pop    r10
    72deb7303ec9:	pop    rsi
    72deb7303eca:	pop    rdx
    72deb7303ecb:	mov    QWORD PTR [r12+0x108],rbx
    72deb7303ed3:	stmxcsr DWORD PTR [r12-0x28]
    72deb7303ed9:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7303ede:	test   r10d,0x3f
    72deb7303ee5:	je     0x72deb7303f0a
    72deb7303eeb:	mov    r11d,r10d
    72deb7303eee:	shr    r10d,1
    72deb7303ef1:	and    r10d,0x1e
    72deb7303ef5:	and    r11d,0x1
    72deb7303ef9:	or     r10d,r11d
    72deb7303efc:	or     DWORD PTR [r12+0x314],r10d
    72deb7303f04:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7303f0a:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7303f10:	lea    rdi,[rsp+0x110]
    72deb7303f18:	lea    rsi,[rsp+0xf0]
    72deb7303f20:	lea    rdx,[rsp+0x100]
    72deb7303f28:	mov    ecx,0x14
    72deb7303f2d:	mov    r8d,0x0
    72deb7303f33:	lea    r9,[r12+0x314]
    72deb7303f3b:	movabs r11,0x5b63a3f49650
    72deb7303f45:	call   r11
    72deb7303f48:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7303f4e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7303f54:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7303f5a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7303f60:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7303f6a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7303f74:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7303f7e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7303f88:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7303f92:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7303f9a:	mov    QWORD PTR [r12+0x378],0x2
    72deb7303fa6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7303faf:	mov    rdx,rbx
    72deb7303fb2:	shr    rdx,0x10
    72deb7303fb6:	and    edx,0xc000
    72deb7303fbc:	mov    rax,rbx
    72deb7303fbf:	shr    rax,0x15
    72deb7303fc3:	and    eax,0x100
    72deb7303fc8:	xor    eax,0x100
    72deb7303fcd:	or     edx,eax
    72deb7303fcf:	mov    rax,rbx
    72deb7303fd2:	shr    rax,0x1c
    72deb7303fd6:	and    eax,0x1
    72deb7303fd9:	or     edx,eax
    72deb7303fdb:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7303fe0:	add    rsp,0x8
    72deb7303fe4:	ret
    72deb7303fe5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7303ff0:	sub    rsp,0x8
    72deb7303ff4:	mov    QWORD PTR [r12+0x378],0x3
    72deb7304000:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7304006:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb730400c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7304012:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7304018:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7304022:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb730402c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7304036:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7304040:	push   rdx
    72deb7304041:	push   rsi
    72deb7304042:	push   r10
    72deb7304044:	push   r11
    72deb7304046:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb730404b:	mov    r10d,edx
    72deb730404e:	and    r10d,0xc000
    72deb7304055:	shl    r10d,0x10
    72deb7304059:	mov    r11d,edx
    72deb730405c:	and    r11d,0x100
    72deb7304063:	shl    r11d,0x15
    72deb7304067:	or     r10d,r11d
    72deb730406a:	and    edx,0x1
    72deb730406d:	shl    edx,0x1c
    72deb7304070:	or     r10d,edx
    72deb7304073:	btc    r10,0x1d
    72deb7304078:	mov    r11d,0xf0000000
    72deb730407e:	and    r11,r10
    72deb7304081:	movabs rsi,0xffffffff0fffffff
    72deb730408b:	and    rbx,rsi
    72deb730408e:	or     rbx,r11
    72deb7304091:	pop    r11
    72deb7304093:	pop    r10
    72deb7304095:	pop    rsi
    72deb7304096:	pop    rdx
    72deb7304097:	mov    QWORD PTR [r12+0x108],rbx
    72deb730409f:	stmxcsr DWORD PTR [r12-0x28]
    72deb73040a5:	mov    r10d,DWORD PTR [r12-0x28]
    72deb73040aa:	test   r10d,0x3f
    72deb73040b1:	je     0x72deb73040d6
    72deb73040b7:	mov    r11d,r10d
    72deb73040ba:	shr    r10d,1
    72deb73040bd:	and    r10d,0x1e
    72deb73040c1:	and    r11d,0x1
    72deb73040c5:	or     r10d,r11d
    72deb73040c8:	or     DWORD PTR [r12+0x314],r10d
    72deb73040d0:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73040d6:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73040dc:	lea    rdi,[rsp+0x110]
    72deb73040e4:	lea    rsi,[rsp+0xf0]
    72deb73040ec:	lea    rdx,[rsp+0x100]
    72deb73040f4:	mov    ecx,0x14
    72deb73040f9:	mov    r8d,0x0
    72deb73040ff:	lea    r9,[r12+0x314]
    72deb7304107:	movabs r11,0x5b63a3f49650
    72deb7304111:	call   r11
    72deb7304114:	ldmxcsr DWORD PTR [r12-0x28]
    72deb730411a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7304120:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7304126:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb730412c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7304132:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb730413c:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7304146:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7304150:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb730415a:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7304162:	mov    QWORD PTR [r12+0x378],0x2
    72deb730416e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7304177:	mov    rdx,rbx
    72deb730417a:	shr    rdx,0x10
    72deb730417e:	and    edx,0xc000
    72deb7304184:	mov    rax,rbx
    72deb7304187:	shr    rax,0x15
    72deb730418b:	and    eax,0x100
    72deb7304190:	xor    eax,0x100
    72deb7304195:	or     edx,eax
    72deb7304197:	mov    rax,rbx
    72deb730419a:	shr    rax,0x1c
    72deb730419e:	and    eax,0x1
    72deb73041a1:	or     edx,eax
    72deb73041a3:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73041a8:	add    rsp,0x8
    72deb73041ac:	ret
    72deb73041ad:	nop    DWORD PTR [rax]
    72deb73041b0:	sub    rsp,0x8
    72deb73041b4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73041c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73041c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73041cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73041d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73041d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73041de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73041e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb73041ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb73041f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7304202:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb730420c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7304216:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb7304220:	push   rdx
    72deb7304221:	push   rsi
    72deb7304222:	push   r10
    72deb7304224:	push   r11
    72deb7304226:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb730422b:	mov    r10d,edx
    72deb730422e:	and    r10d,0xc000
    72deb7304235:	shl    r10d,0x10
    72deb7304239:	mov    r11d,edx
    72deb730423c:	and    r11d,0x100
    72deb7304243:	shl    r11d,0x15
    72deb7304247:	or     r10d,r11d
    72deb730424a:	and    edx,0x1
    72deb730424d:	shl    edx,0x1c
    72deb7304250:	or     r10d,edx
    72deb7304253:	btc    r10,0x1d
    72deb7304258:	mov    r11d,0xf0000000
    72deb730425e:	and    r11,r10
    72deb7304261:	movabs rsi,0xffffffff0fffffff
    72deb730426b:	and    rbx,rsi
    72deb730426e:	or     rbx,r11
    72deb7304271:	pop    r11
    72deb7304273:	pop    r10
    72deb7304275:	pop    rsi
    72deb7304276:	pop    rdx
    72deb7304277:	mov    QWORD PTR [r12+0x108],rbx
    72deb730427f:	stmxcsr DWORD PTR [r12-0x28]
    72deb7304285:	mov    r10d,DWORD PTR [r12-0x28]
    72deb730428a:	test   r10d,0x3f
    72deb7304291:	je     0x72deb73042b6
    72deb7304297:	mov    r11d,r10d
    72deb730429a:	shr    r10d,1
    72deb730429d:	and    r10d,0x1e
    72deb73042a1:	and    r11d,0x1
    72deb73042a5:	or     r10d,r11d
    72deb73042a8:	or     DWORD PTR [r12+0x314],r10d
    72deb73042b0:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73042b6:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73042bc:	lea    rdi,[rsp+0x110]
    72deb73042c4:	lea    rsi,[rsp+0xf0]
    72deb73042cc:	lea    rdx,[rsp+0x100]
    72deb73042d4:	mov    ecx,0x14
    72deb73042d9:	mov    r8d,0x0
    72deb73042df:	lea    r9,[r12+0x314]
    72deb73042e7:	movabs r11,0x5b63a3f49650
    72deb73042f1:	call   r11
    72deb73042f4:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73042fa:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7304300:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7304306:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb730430c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7304312:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7304318:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb730431e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7304328:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7304332:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb730433c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7304346:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7304350:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb730435a:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7304362:	mov    QWORD PTR [r12+0x378],0x2
    72deb730436e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7304377:	mov    rdx,rbx
    72deb730437a:	shr    rdx,0x10
    72deb730437e:	and    edx,0xc000
    72deb7304384:	mov    rax,rbx
    72deb7304387:	shr    rax,0x15
    72deb730438b:	and    eax,0x100
    72deb7304390:	xor    eax,0x100
    72deb7304395:	or     edx,eax
    72deb7304397:	mov    rax,rbx
    72deb730439a:	shr    rax,0x1c
    72deb730439e:	and    eax,0x1
    72deb73043a1:	or     edx,eax
    72deb73043a3:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73043a8:	add    rsp,0x8
    72deb73043ac:	ret
    72deb73043ad:	nop    DWORD PTR [rax]
    72deb73043b0:	sub    rsp,0x8
    72deb73043b4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73043c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73043c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73043cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73043d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73043d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73043de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73043e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb73043ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb73043f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7304402:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb730440c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb7304416:	push   rdx
    72deb7304417:	push   rsi
    72deb7304418:	push   r10
    72deb730441a:	push   r11
    72deb730441c:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7304421:	mov    r10d,edx
    72deb7304424:	and    r10d,0xc000
    72deb730442b:	shl    r10d,0x10
    72deb730442f:	mov    r11d,edx
    72deb7304432:	and    r11d,0x100
    72deb7304439:	shl    r11d,0x15
    72deb730443d:	or     r10d,r11d
    72deb7304440:	and    edx,0x1
    72deb7304443:	shl    edx,0x1c
    72deb7304446:	or     r10d,edx
    72deb7304449:	btc    r10,0x1d
    72deb730444e:	mov    r11d,0xf0000000
    72deb7304454:	and    r11,r10
    72deb7304457:	movabs rsi,0xffffffff0fffffff
    72deb7304461:	and    rbx,rsi
    72deb7304464:	or     rbx,r11
    72deb7304467:	pop    r11
    72deb7304469:	pop    r10
    72deb730446b:	pop    rsi
    72deb730446c:	pop    rdx
    72deb730446d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7304475:	stmxcsr DWORD PTR [r12-0x28]
    72deb730447b:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7304480:	test   r10d,0x3f
    72deb7304487:	je     0x72deb73044ac
    72deb730448d:	mov    r11d,r10d
    72deb7304490:	shr    r10d,1
    72deb7304493:	and    r10d,0x1e
    72deb7304497:	and    r11d,0x1
    72deb730449b:	or     r10d,r11d
    72deb730449e:	or     DWORD PTR [r12+0x314],r10d
    72deb73044a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73044ac:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73044b2:	lea    rdi,[rsp+0x110]
    72deb73044ba:	lea    rsi,[rsp+0xf0]
    72deb73044c2:	lea    rdx,[rsp+0x100]
    72deb73044ca:	mov    ecx,0x14
    72deb73044cf:	mov    r8d,0x0
    72deb73044d5:	lea    r9,[r12+0x314]
    72deb73044dd:	movabs r11,0x5b63a3f49650
    72deb73044e7:	call   r11
    72deb73044ea:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73044f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73044f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73044fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7304502:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7304508:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb730450e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7304514:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb730451e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7304528:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7304532:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb730453c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb7304546:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730454e:	mov    QWORD PTR [r12+0x378],0x2
    72deb730455a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7304563:	mov    rdx,rbx
    72deb7304566:	shr    rdx,0x10
    72deb730456a:	and    edx,0xc000
    72deb7304570:	mov    rax,rbx
    72deb7304573:	shr    rax,0x15
    72deb7304577:	and    eax,0x100
    72deb730457c:	xor    eax,0x100
    72deb7304581:	or     edx,eax
    72deb7304583:	mov    rax,rbx
    72deb7304586:	shr    rax,0x1c
    72deb730458a:	and    eax,0x1
    72deb730458d:	or     edx,eax
    72deb730458f:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7304594:	add    rsp,0x8
    72deb7304598:	ret
    72deb7304599:	nop    DWORD PTR [rax+0x0]
    72deb73045a0:	sub    rsp,0x8
    72deb73045a4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73045b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73045b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73045bc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73045c2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73045c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb73045d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb73045dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73045e6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb73045f0:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb73045fa:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb7304604:	push   rdx
    72deb7304605:	push   rsi
    72deb7304606:	push   r10
    72deb7304608:	push   r11
    72deb730460a:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb730460f:	mov    r10d,edx
    72deb7304612:	and    r10d,0xc000
    72deb7304619:	shl    r10d,0x10
    72deb730461d:	mov    r11d,edx
    72deb7304620:	and    r11d,0x100
    72deb7304627:	shl    r11d,0x15
    72deb730462b:	or     r10d,r11d
    72deb730462e:	and    edx,0x1
    72deb7304631:	shl    edx,0x1c
    72deb7304634:	or     r10d,edx
    72deb7304637:	btc    r10,0x1d
    72deb730463c:	mov    r11d,0xf0000000
    72deb7304642:	and    r11,r10
    72deb7304645:	movabs rsi,0xffffffff0fffffff
    72deb730464f:	and    rbx,rsi
    72deb7304652:	or     rbx,r11
    72deb7304655:	pop    r11
    72deb7304657:	pop    r10
    72deb7304659:	pop    rsi
    72deb730465a:	pop    rdx
    72deb730465b:	mov    QWORD PTR [r12+0x108],rbx
    72deb7304663:	stmxcsr DWORD PTR [r12-0x28]
    72deb7304669:	mov    r10d,DWORD PTR [r12-0x28]
    72deb730466e:	test   r10d,0x3f
    72deb7304675:	je     0x72deb730469a
    72deb730467b:	mov    r11d,r10d
    72deb730467e:	shr    r10d,1
    72deb7304681:	and    r10d,0x1e
    72deb7304685:	and    r11d,0x1
    72deb7304689:	or     r10d,r11d
    72deb730468c:	or     DWORD PTR [r12+0x314],r10d
    72deb7304694:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb730469a:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73046a0:	lea    rdi,[rsp+0x110]
    72deb73046a8:	lea    rsi,[rsp+0xf0]
    72deb73046b0:	lea    rdx,[rsp+0x100]
    72deb73046b8:	mov    ecx,0x14
    72deb73046bd:	mov    r8d,0x0
    72deb73046c3:	lea    r9,[r12+0x314]
    72deb73046cb:	movabs r11,0x5b63a3f49650
    72deb73046d5:	call   r11
    72deb73046d8:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73046de:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73046e4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73046ea:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb73046f0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb73046f6:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7304700:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb730470a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7304714:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb730471e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7304728:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb7304732:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730473a:	mov    QWORD PTR [r12+0x378],0x2
    72deb7304746:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb730474f:	mov    rdx,rbx
    72deb7304752:	shr    rdx,0x10
    72deb7304756:	and    edx,0xc000
    72deb730475c:	mov    rax,rbx
    72deb730475f:	shr    rax,0x15
    72deb7304763:	and    eax,0x100
    72deb7304768:	xor    eax,0x100
    72deb730476d:	or     edx,eax
    72deb730476f:	mov    rax,rbx
    72deb7304772:	shr    rax,0x1c
    72deb7304776:	and    eax,0x1
    72deb7304779:	or     edx,eax
    72deb730477b:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7304780:	add    rsp,0x8
    72deb7304784:	ret
    72deb7304785:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7304790:	sub    rsp,0x8
    72deb7304794:	mov    QWORD PTR [r12+0x378],0x3
    72deb73047a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73047a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73047ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73047b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73047b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73047be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb73047c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73047d2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb73047dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb73047e6:	push   rdx
    72deb73047e7:	push   rsi
    72deb73047e8:	push   r10
    72deb73047ea:	push   r11
    72deb73047ec:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb73047f1:	mov    r10d,edx
    72deb73047f4:	and    r10d,0xc000
    72deb73047fb:	shl    r10d,0x10
    72deb73047ff:	mov    r11d,edx
    72deb7304802:	and    r11d,0x100
    72deb7304809:	shl    r11d,0x15
    72deb730480d:	or     r10d,r11d
    72deb7304810:	and    edx,0x1
    72deb7304813:	shl    edx,0x1c
    72deb7304816:	or     r10d,edx
    72deb7304819:	btc    r10,0x1d
    72deb730481e:	mov    r11d,0xf0000000
    72deb7304824:	and    r11,r10
    72deb7304827:	movabs rsi,0xffffffff0fffffff
    72deb7304831:	and    rbx,rsi
    72deb7304834:	or     rbx,r11
    72deb7304837:	pop    r11
    72deb7304839:	pop    r10
    72deb730483b:	pop    rsi
    72deb730483c:	pop    rdx
    72deb730483d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7304845:	stmxcsr DWORD PTR [r12-0x28]
    72deb730484b:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7304850:	test   r10d,0x3f
    72deb7304857:	je     0x72deb730487c
    72deb730485d:	mov    r11d,r10d
    72deb7304860:	shr    r10d,1
    72deb7304863:	and    r10d,0x1e
    72deb7304867:	and    r11d,0x1
    72deb730486b:	or     r10d,r11d
    72deb730486e:	or     DWORD PTR [r12+0x314],r10d
    72deb7304876:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb730487c:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7304882:	lea    rdi,[rsp+0x110]
    72deb730488a:	lea    rsi,[rsp+0xf0]
    72deb7304892:	lea    rdx,[rsp+0x100]
    72deb730489a:	mov    ecx,0x56
    72deb730489f:	mov    r8d,0x0
    72deb73048a5:	lea    r9,[r12+0x314]
    72deb73048ad:	movabs r11,0x5b63a3f49650
    72deb73048b7:	call   r11
    72deb73048ba:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73048c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73048c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73048cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb73048d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb73048d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb73048de:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb73048e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb73048f2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb73048fc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb7304906:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730490e:	mov    QWORD PTR [r12+0x378],0x2
    72deb730491a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7304923:	mov    rdx,rbx
    72deb7304926:	shr    rdx,0x10
    72deb730492a:	and    edx,0xc000
    72deb7304930:	mov    rax,rbx
    72deb7304933:	shr    rax,0x15
    72deb7304937:	and    eax,0x100
    72deb730493c:	xor    eax,0x100
    72deb7304941:	or     edx,eax
    72deb7304943:	mov    rax,rbx
    72deb7304946:	shr    rax,0x1c
    72deb730494a:	and    eax,0x1
    72deb730494d:	or     edx,eax
    72deb730494f:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7304954:	add    rsp,0x8
    72deb7304958:	ret
    72deb7304959:	nop    DWORD PTR [rax+0x0]
    72deb7304960:	sub    rsp,0x8
    72deb7304964:	mov    QWORD PTR [r12+0x378],0x3
    72deb7304970:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7304976:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb730497c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7304982:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7304988:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb730498e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7304994:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb730499e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73049a8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb73049b2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb73049bc:	push   rdx
    72deb73049bd:	push   rsi
    72deb73049be:	push   r10
    72deb73049c0:	push   r11
    72deb73049c2:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb73049c7:	mov    r10d,edx
    72deb73049ca:	and    r10d,0xc000
    72deb73049d1:	shl    r10d,0x10
    72deb73049d5:	mov    r11d,edx
    72deb73049d8:	and    r11d,0x100
    72deb73049df:	shl    r11d,0x15
    72deb73049e3:	or     r10d,r11d
    72deb73049e6:	and    edx,0x1
    72deb73049e9:	shl    edx,0x1c
    72deb73049ec:	or     r10d,edx
    72deb73049ef:	btc    r10,0x1d
    72deb73049f4:	mov    r11d,0xf0000000
    72deb73049fa:	and    r11,r10
    72deb73049fd:	movabs rsi,0xffffffff0fffffff
    72deb7304a07:	and    rbx,rsi
    72deb7304a0a:	or     rbx,r11
    72deb7304a0d:	pop    r11
    72deb7304a0f:	pop    r10
    72deb7304a11:	pop    rsi
    72deb7304a12:	pop    rdx
    72deb7304a13:	mov    QWORD PTR [r12+0x108],rbx
    72deb7304a1b:	stmxcsr DWORD PTR [r12-0x28]
    72deb7304a21:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7304a26:	test   r10d,0x3f
    72deb7304a2d:	je     0x72deb7304a52
    72deb7304a33:	mov    r11d,r10d
    72deb7304a36:	shr    r10d,1
    72deb7304a39:	and    r10d,0x1e
    72deb7304a3d:	and    r11d,0x1
    72deb7304a41:	or     r10d,r11d
    72deb7304a44:	or     DWORD PTR [r12+0x314],r10d
    72deb7304a4c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7304a52:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7304a58:	lea    rdi,[rsp+0x110]
    72deb7304a60:	lea    rsi,[rsp+0xf0]
    72deb7304a68:	lea    rdx,[rsp+0x100]
    72deb7304a70:	mov    ecx,0x56
    72deb7304a75:	mov    r8d,0x0
    72deb7304a7b:	lea    r9,[r12+0x314]
    72deb7304a83:	movabs r11,0x5b63a3f49650
    72deb7304a8d:	call   r11
    72deb7304a90:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7304a96:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7304a9c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7304aa2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7304aa8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7304aae:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7304ab4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7304aba:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7304ac4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7304ace:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7304ad8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb7304ae2:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7304aea:	mov    QWORD PTR [r12+0x378],0x2
    72deb7304af6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7304aff:	mov    rdx,rbx
    72deb7304b02:	shr    rdx,0x10
    72deb7304b06:	and    edx,0xc000
    72deb7304b0c:	mov    rax,rbx
    72deb7304b0f:	shr    rax,0x15
    72deb7304b13:	and    eax,0x100
    72deb7304b18:	xor    eax,0x100
    72deb7304b1d:	or     edx,eax
    72deb7304b1f:	mov    rax,rbx
    72deb7304b22:	shr    rax,0x1c
    72deb7304b26:	and    eax,0x1
    72deb7304b29:	or     edx,eax
    72deb7304b2b:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7304b30:	add    rsp,0x8
    72deb7304b34:	ret
    72deb7304b35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7304b40:	sub    rsp,0x8
    72deb7304b44:	mov    QWORD PTR [r12+0x378],0x3
    72deb7304b50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7304b56:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb7304b5c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7304b62:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7304b68:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7304b6e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7304b74:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7304b7e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7304b88:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7304b92:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7304b9c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb7304ba6:	push   rdx
    72deb7304ba7:	push   rsi
    72deb7304ba8:	push   r10
    72deb7304baa:	push   r11
    72deb7304bac:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7304bb1:	mov    r10d,edx
    72deb7304bb4:	and    r10d,0xc000
    72deb7304bbb:	shl    r10d,0x10
    72deb7304bbf:	mov    r11d,edx
    72deb7304bc2:	and    r11d,0x100
    72deb7304bc9:	shl    r11d,0x15
    72deb7304bcd:	or     r10d,r11d
    72deb7304bd0:	and    edx,0x1
    72deb7304bd3:	shl    edx,0x1c
    72deb7304bd6:	or     r10d,edx
    72deb7304bd9:	btc    r10,0x1d
    72deb7304bde:	mov    r11d,0xf0000000
    72deb7304be4:	and    r11,r10
    72deb7304be7:	movabs rsi,0xffffffff0fffffff
    72deb7304bf1:	and    rbx,rsi
    72deb7304bf4:	or     rbx,r11
    72deb7304bf7:	pop    r11
    72deb7304bf9:	pop    r10
    72deb7304bfb:	pop    rsi
    72deb7304bfc:	pop    rdx
    72deb7304bfd:	mov    QWORD PTR [r12+0x108],rbx
    72deb7304c05:	stmxcsr DWORD PTR [r12-0x28]
    72deb7304c0b:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7304c10:	test   r10d,0x3f
    72deb7304c17:	je     0x72deb7304c3c
    72deb7304c1d:	mov    r11d,r10d
    72deb7304c20:	shr    r10d,1
    72deb7304c23:	and    r10d,0x1e
    72deb7304c27:	and    r11d,0x1
    72deb7304c2b:	or     r10d,r11d
    72deb7304c2e:	or     DWORD PTR [r12+0x314],r10d
    72deb7304c36:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7304c3c:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7304c42:	lea    rdi,[rsp+0x110]
    72deb7304c4a:	lea    rsi,[rsp+0xf0]
    72deb7304c52:	lea    rdx,[rsp+0x100]
    72deb7304c5a:	mov    ecx,0x56
    72deb7304c5f:	mov    r8d,0x0
    72deb7304c65:	lea    r9,[r12+0x314]
    72deb7304c6d:	movabs r11,0x5b63a3f49650
    72deb7304c77:	call   r11
    72deb7304c7a:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7304c80:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7304c86:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7304c8c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7304c92:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7304c98:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7304c9e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7304ca4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7304cae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7304cb8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7304cc2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7304ccc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb7304cd6:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7304cde:	mov    QWORD PTR [r12+0x378],0x2
    72deb7304cea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7304cf3:	mov    rdx,rbx
    72deb7304cf6:	shr    rdx,0x10
    72deb7304cfa:	and    edx,0xc000
    72deb7304d00:	mov    rax,rbx
    72deb7304d03:	shr    rax,0x15
    72deb7304d07:	and    eax,0x100
    72deb7304d0c:	xor    eax,0x100
    72deb7304d11:	or     edx,eax
    72deb7304d13:	mov    rax,rbx
    72deb7304d16:	shr    rax,0x1c
    72deb7304d1a:	and    eax,0x1
    72deb7304d1d:	or     edx,eax
    72deb7304d1f:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7304d24:	add    rsp,0x8
    72deb7304d28:	ret
    72deb7304d29:	nop    DWORD PTR [rax+0x0]
    72deb7304d30:	sub    rsp,0x8
    72deb7304d34:	mov    QWORD PTR [r12+0x378],0x3
    72deb7304d40:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7304d46:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7304d4c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7304d52:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7304d58:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7304d62:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7304d6c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7304d76:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7304d80:	push   rdx
    72deb7304d81:	push   rsi
    72deb7304d82:	push   r10
    72deb7304d84:	push   r11
    72deb7304d86:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7304d8b:	mov    r10d,edx
    72deb7304d8e:	and    r10d,0xc000
    72deb7304d95:	shl    r10d,0x10
    72deb7304d99:	mov    r11d,edx
    72deb7304d9c:	and    r11d,0x100
    72deb7304da3:	shl    r11d,0x15
    72deb7304da7:	or     r10d,r11d
    72deb7304daa:	and    edx,0x1
    72deb7304dad:	shl    edx,0x1c
    72deb7304db0:	or     r10d,edx
    72deb7304db3:	btc    r10,0x1d
    72deb7304db8:	mov    r11d,0xf0000000
    72deb7304dbe:	and    r11,r10
    72deb7304dc1:	movabs rsi,0xffffffff0fffffff
    72deb7304dcb:	and    rbx,rsi
    72deb7304dce:	or     rbx,r11
    72deb7304dd1:	pop    r11
    72deb7304dd3:	pop    r10
    72deb7304dd5:	pop    rsi
    72deb7304dd6:	pop    rdx
    72deb7304dd7:	mov    QWORD PTR [r12+0x108],rbx
    72deb7304ddf:	stmxcsr DWORD PTR [r12-0x28]
    72deb7304de5:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7304dea:	test   r10d,0x3f
    72deb7304df1:	je     0x72deb7304e16
    72deb7304df7:	mov    r11d,r10d
    72deb7304dfa:	shr    r10d,1
    72deb7304dfd:	and    r10d,0x1e
    72deb7304e01:	and    r11d,0x1
    72deb7304e05:	or     r10d,r11d
    72deb7304e08:	or     DWORD PTR [r12+0x314],r10d
    72deb7304e10:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7304e16:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7304e1c:	lea    rdi,[rsp+0x110]
    72deb7304e24:	lea    rsi,[rsp+0xf0]
    72deb7304e2c:	lea    rdx,[rsp+0x100]
    72deb7304e34:	mov    ecx,0x56
    72deb7304e39:	mov    r8d,0x0
    72deb7304e3f:	lea    r9,[r12+0x314]
    72deb7304e47:	movabs r11,0x5b63a3f49650
    72deb7304e51:	call   r11
    72deb7304e54:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7304e5a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7304e60:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7304e66:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7304e6c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7304e72:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7304e7c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7304e86:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7304e90:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7304e9a:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7304ea2:	mov    QWORD PTR [r12+0x378],0x2
    72deb7304eae:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7304eb7:	mov    rdx,rbx
    72deb7304eba:	shr    rdx,0x10
    72deb7304ebe:	and    edx,0xc000
    72deb7304ec4:	mov    rax,rbx
    72deb7304ec7:	shr    rax,0x15
    72deb7304ecb:	and    eax,0x100
    72deb7304ed0:	xor    eax,0x100
    72deb7304ed5:	or     edx,eax
    72deb7304ed7:	mov    rax,rbx
    72deb7304eda:	shr    rax,0x1c
    72deb7304ede:	and    eax,0x1
    72deb7304ee1:	or     edx,eax
    72deb7304ee3:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7304ee8:	add    rsp,0x8
    72deb7304eec:	ret
    72deb7304eed:	nop    DWORD PTR [rax]
    72deb7304ef0:	sub    rsp,0x8
    72deb7304ef4:	mov    QWORD PTR [r12+0x378],0x3
    72deb7304f00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7304f06:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7304f0c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7304f12:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7304f18:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7304f1e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7304f28:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7304f32:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7304f3c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7304f46:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb7304f50:	push   rdx
    72deb7304f51:	push   rsi
    72deb7304f52:	push   r10
    72deb7304f54:	push   r11
    72deb7304f56:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7304f5b:	mov    r10d,edx
    72deb7304f5e:	and    r10d,0xc000
    72deb7304f65:	shl    r10d,0x10
    72deb7304f69:	mov    r11d,edx
    72deb7304f6c:	and    r11d,0x100
    72deb7304f73:	shl    r11d,0x15
    72deb7304f77:	or     r10d,r11d
    72deb7304f7a:	and    edx,0x1
    72deb7304f7d:	shl    edx,0x1c
    72deb7304f80:	or     r10d,edx
    72deb7304f83:	btc    r10,0x1d
    72deb7304f88:	mov    r11d,0xf0000000
    72deb7304f8e:	and    r11,r10
    72deb7304f91:	movabs rsi,0xffffffff0fffffff
    72deb7304f9b:	and    rbx,rsi
    72deb7304f9e:	or     rbx,r11
    72deb7304fa1:	pop    r11
    72deb7304fa3:	pop    r10
    72deb7304fa5:	pop    rsi
    72deb7304fa6:	pop    rdx
    72deb7304fa7:	mov    QWORD PTR [r12+0x108],rbx
    72deb7304faf:	stmxcsr DWORD PTR [r12-0x28]
    72deb7304fb5:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7304fba:	test   r10d,0x3f
    72deb7304fc1:	je     0x72deb7304fe6
    72deb7304fc7:	mov    r11d,r10d
    72deb7304fca:	shr    r10d,1
    72deb7304fcd:	and    r10d,0x1e
    72deb7304fd1:	and    r11d,0x1
    72deb7304fd5:	or     r10d,r11d
    72deb7304fd8:	or     DWORD PTR [r12+0x314],r10d
    72deb7304fe0:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7304fe6:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7304fec:	lea    rdi,[rsp+0x110]
    72deb7304ff4:	lea    rsi,[rsp+0xf0]
    72deb7304ffc:	lea    rdx,[rsp+0x100]
    72deb7305004:	mov    ecx,0x14
    72deb7305009:	mov    r8d,0x0
    72deb730500f:	lea    r9,[r12+0x314]
    72deb7305017:	movabs r11,0x5b63a3f49650
    72deb7305021:	call   r11
    72deb7305024:	ldmxcsr DWORD PTR [r12-0x28]
    72deb730502a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7305030:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7305036:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb730503c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7305042:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7305048:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7305052:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb730505c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7305066:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7305070:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb730507a:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7305082:	mov    QWORD PTR [r12+0x378],0x2
    72deb730508e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7305097:	mov    rdx,rbx
    72deb730509a:	shr    rdx,0x10
    72deb730509e:	and    edx,0xc000
    72deb73050a4:	mov    rax,rbx
    72deb73050a7:	shr    rax,0x15
    72deb73050ab:	and    eax,0x100
    72deb73050b0:	xor    eax,0x100
    72deb73050b5:	or     edx,eax
    72deb73050b7:	mov    rax,rbx
    72deb73050ba:	shr    rax,0x1c
    72deb73050be:	and    eax,0x1
    72deb73050c1:	or     edx,eax
    72deb73050c3:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73050c8:	add    rsp,0x8
    72deb73050cc:	ret
    72deb73050cd:	nop    DWORD PTR [rax]
    72deb73050d0:	sub    rsp,0x8
    72deb73050d4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73050e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73050e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73050ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73050f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73050f8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73050fe:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7305108:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7305112:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb730511c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7305126:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb7305130:	push   rdx
    72deb7305131:	push   rsi
    72deb7305132:	push   r10
    72deb7305134:	push   r11
    72deb7305136:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb730513b:	mov    r10d,edx
    72deb730513e:	and    r10d,0xc000
    72deb7305145:	shl    r10d,0x10
    72deb7305149:	mov    r11d,edx
    72deb730514c:	and    r11d,0x100
    72deb7305153:	shl    r11d,0x15
    72deb7305157:	or     r10d,r11d
    72deb730515a:	and    edx,0x1
    72deb730515d:	shl    edx,0x1c
    72deb7305160:	or     r10d,edx
    72deb7305163:	btc    r10,0x1d
    72deb7305168:	mov    r11d,0xf0000000
    72deb730516e:	and    r11,r10
    72deb7305171:	movabs rsi,0xffffffff0fffffff
    72deb730517b:	and    rbx,rsi
    72deb730517e:	or     rbx,r11
    72deb7305181:	pop    r11
    72deb7305183:	pop    r10
    72deb7305185:	pop    rsi
    72deb7305186:	pop    rdx
    72deb7305187:	mov    QWORD PTR [r12+0x108],rbx
    72deb730518f:	stmxcsr DWORD PTR [r12-0x28]
    72deb7305195:	mov    r10d,DWORD PTR [r12-0x28]
    72deb730519a:	test   r10d,0x3f
    72deb73051a1:	je     0x72deb73051c6
    72deb73051a7:	mov    r11d,r10d
    72deb73051aa:	shr    r10d,1
    72deb73051ad:	and    r10d,0x1e
    72deb73051b1:	and    r11d,0x1
    72deb73051b5:	or     r10d,r11d
    72deb73051b8:	or     DWORD PTR [r12+0x314],r10d
    72deb73051c0:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73051c6:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73051cc:	lea    rdi,[rsp+0x110]
    72deb73051d4:	lea    rsi,[rsp+0xf0]
    72deb73051dc:	lea    rdx,[rsp+0x100]
    72deb73051e4:	mov    ecx,0x56
    72deb73051e9:	mov    r8d,0x0
    72deb73051ef:	lea    r9,[r12+0x314]
    72deb73051f7:	movabs r11,0x5b63a3f49650
    72deb7305201:	call   r11
    72deb7305204:	ldmxcsr DWORD PTR [r12-0x28]
    72deb730520a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7305210:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7305216:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb730521c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7305222:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7305228:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7305232:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb730523c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7305246:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7305250:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb730525a:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7305262:	mov    QWORD PTR [r12+0x378],0x2
    72deb730526e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7305277:	mov    rdx,rbx
    72deb730527a:	shr    rdx,0x10
    72deb730527e:	and    edx,0xc000
    72deb7305284:	mov    rax,rbx
    72deb7305287:	shr    rax,0x15
    72deb730528b:	and    eax,0x100
    72deb7305290:	xor    eax,0x100
    72deb7305295:	or     edx,eax
    72deb7305297:	mov    rax,rbx
    72deb730529a:	shr    rax,0x1c
    72deb730529e:	and    eax,0x1
    72deb73052a1:	or     edx,eax
    72deb73052a3:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73052a8:	add    rsp,0x8
    72deb73052ac:	ret
    72deb73052ad:	nop    DWORD PTR [rax]
    72deb73052b0:	sub    rsp,0x8
    72deb73052b4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73052c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73052c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73052cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73052d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73052d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73052de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73052e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb73052ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb73052f8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7305302:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb730530c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb7305316:	push   rdx
    72deb7305317:	push   rsi
    72deb7305318:	push   r10
    72deb730531a:	push   r11
    72deb730531c:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7305321:	mov    r10d,edx
    72deb7305324:	and    r10d,0xc000
    72deb730532b:	shl    r10d,0x10
    72deb730532f:	mov    r11d,edx
    72deb7305332:	and    r11d,0x100
    72deb7305339:	shl    r11d,0x15
    72deb730533d:	or     r10d,r11d
    72deb7305340:	and    edx,0x1
    72deb7305343:	shl    edx,0x1c
    72deb7305346:	or     r10d,edx
    72deb7305349:	btc    r10,0x1d
    72deb730534e:	mov    r11d,0xf0000000
    72deb7305354:	and    r11,r10
    72deb7305357:	movabs rsi,0xffffffff0fffffff
    72deb7305361:	and    rbx,rsi
    72deb7305364:	or     rbx,r11
    72deb7305367:	pop    r11
    72deb7305369:	pop    r10
    72deb730536b:	pop    rsi
    72deb730536c:	pop    rdx
    72deb730536d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7305375:	stmxcsr DWORD PTR [r12-0x28]
    72deb730537b:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7305380:	test   r10d,0x3f
    72deb7305387:	je     0x72deb73053ac
    72deb730538d:	mov    r11d,r10d
    72deb7305390:	shr    r10d,1
    72deb7305393:	and    r10d,0x1e
    72deb7305397:	and    r11d,0x1
    72deb730539b:	or     r10d,r11d
    72deb730539e:	or     DWORD PTR [r12+0x314],r10d
    72deb73053a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73053ac:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73053b2:	lea    rdi,[rsp+0x110]
    72deb73053ba:	lea    rsi,[rsp+0xf0]
    72deb73053c2:	lea    rdx,[rsp+0x100]
    72deb73053ca:	mov    ecx,0x14
    72deb73053cf:	mov    r8d,0x0
    72deb73053d5:	lea    r9,[r12+0x314]
    72deb73053dd:	movabs r11,0x5b63a3f49650
    72deb73053e7:	call   r11
    72deb73053ea:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73053f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73053f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73053fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7305402:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7305408:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb730540e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7305414:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb730541e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7305428:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7305432:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb730543c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb7305446:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730544e:	mov    QWORD PTR [r12+0x378],0x2
    72deb730545a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7305463:	mov    rdx,rbx
    72deb7305466:	shr    rdx,0x10
    72deb730546a:	and    edx,0xc000
    72deb7305470:	mov    rax,rbx
    72deb7305473:	shr    rax,0x15
    72deb7305477:	and    eax,0x100
    72deb730547c:	xor    eax,0x100
    72deb7305481:	or     edx,eax
    72deb7305483:	mov    rax,rbx
    72deb7305486:	shr    rax,0x1c
    72deb730548a:	and    eax,0x1
    72deb730548d:	or     edx,eax
    72deb730548f:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7305494:	add    rsp,0x8
    72deb7305498:	ret
    72deb7305499:	nop    DWORD PTR [rax+0x0]
    72deb73054a0:	sub    rsp,0x8
    72deb73054a4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73054b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73054b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73054bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73054c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73054c8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73054ce:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73054d4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb73054de:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb73054e8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73054f2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb73054fc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb7305506:	push   rdx
    72deb7305507:	push   rsi
    72deb7305508:	push   r10
    72deb730550a:	push   r11
    72deb730550c:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7305511:	mov    r10d,edx
    72deb7305514:	and    r10d,0xc000
    72deb730551b:	shl    r10d,0x10
    72deb730551f:	mov    r11d,edx
    72deb7305522:	and    r11d,0x100
    72deb7305529:	shl    r11d,0x15
    72deb730552d:	or     r10d,r11d
    72deb7305530:	and    edx,0x1
    72deb7305533:	shl    edx,0x1c
    72deb7305536:	or     r10d,edx
    72deb7305539:	btc    r10,0x1d
    72deb730553e:	mov    r11d,0xf0000000
    72deb7305544:	and    r11,r10
    72deb7305547:	movabs rsi,0xffffffff0fffffff
    72deb7305551:	and    rbx,rsi
    72deb7305554:	or     rbx,r11
    72deb7305557:	pop    r11
    72deb7305559:	pop    r10
    72deb730555b:	pop    rsi
    72deb730555c:	pop    rdx
    72deb730555d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7305565:	stmxcsr DWORD PTR [r12-0x28]
    72deb730556b:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7305570:	test   r10d,0x3f
    72deb7305577:	je     0x72deb730559c
    72deb730557d:	mov    r11d,r10d
    72deb7305580:	shr    r10d,1
    72deb7305583:	and    r10d,0x1e
    72deb7305587:	and    r11d,0x1
    72deb730558b:	or     r10d,r11d
    72deb730558e:	or     DWORD PTR [r12+0x314],r10d
    72deb7305596:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb730559c:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73055a2:	lea    rdi,[rsp+0x110]
    72deb73055aa:	lea    rsi,[rsp+0xf0]
    72deb73055b2:	lea    rdx,[rsp+0x100]
    72deb73055ba:	mov    ecx,0x14
    72deb73055bf:	mov    r8d,0x0
    72deb73055c5:	lea    r9,[r12+0x314]
    72deb73055cd:	movabs r11,0x5b63a3f49650
    72deb73055d7:	call   r11
    72deb73055da:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73055e0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73055e6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73055ec:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb73055f2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb73055f8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb73055fe:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7305604:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb730560e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7305618:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7305622:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb730562c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb7305636:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730563e:	mov    QWORD PTR [r12+0x378],0x2
    72deb730564a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7305653:	mov    rdx,rbx
    72deb7305656:	shr    rdx,0x10
    72deb730565a:	and    edx,0xc000
    72deb7305660:	mov    rax,rbx
    72deb7305663:	shr    rax,0x15
    72deb7305667:	and    eax,0x100
    72deb730566c:	xor    eax,0x100
    72deb7305671:	or     edx,eax
    72deb7305673:	mov    rax,rbx
    72deb7305676:	shr    rax,0x1c
    72deb730567a:	and    eax,0x1
    72deb730567d:	or     edx,eax
    72deb730567f:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7305684:	add    rsp,0x8
    72deb7305688:	ret
    72deb7305689:	nop    DWORD PTR [rax+0x0]
    72deb7305690:	sub    rsp,0x8
    72deb7305694:	mov    QWORD PTR [r12+0x378],0x3
    72deb73056a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73056a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73056ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73056b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73056b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73056be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73056c4:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb73056ce:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73056d8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb73056e2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb73056ec:	push   rdx
    72deb73056ed:	push   rsi
    72deb73056ee:	push   r10
    72deb73056f0:	push   r11
    72deb73056f2:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb73056f7:	mov    r10d,edx
    72deb73056fa:	and    r10d,0xc000
    72deb7305701:	shl    r10d,0x10
    72deb7305705:	mov    r11d,edx
    72deb7305708:	and    r11d,0x100
    72deb730570f:	shl    r11d,0x15
    72deb7305713:	or     r10d,r11d
    72deb7305716:	and    edx,0x1
    72deb7305719:	shl    edx,0x1c
    72deb730571c:	or     r10d,edx
    72deb730571f:	btc    r10,0x1d
    72deb7305724:	mov    r11d,0xf0000000
    72deb730572a:	and    r11,r10
    72deb730572d:	movabs rsi,0xffffffff0fffffff
    72deb7305737:	and    rbx,rsi
    72deb730573a:	or     rbx,r11
    72deb730573d:	pop    r11
    72deb730573f:	pop    r10
    72deb7305741:	pop    rsi
    72deb7305742:	pop    rdx
    72deb7305743:	mov    QWORD PTR [r12+0x108],rbx
    72deb730574b:	stmxcsr DWORD PTR [r12-0x28]
    72deb7305751:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7305756:	test   r10d,0x3f
    72deb730575d:	je     0x72deb7305782
    72deb7305763:	mov    r11d,r10d
    72deb7305766:	shr    r10d,1
    72deb7305769:	and    r10d,0x1e
    72deb730576d:	and    r11d,0x1
    72deb7305771:	or     r10d,r11d
    72deb7305774:	or     DWORD PTR [r12+0x314],r10d
    72deb730577c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7305782:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7305788:	lea    rdi,[rsp+0x110]
    72deb7305790:	lea    rsi,[rsp+0xf0]
    72deb7305798:	lea    rdx,[rsp+0x100]
    72deb73057a0:	mov    ecx,0x56
    72deb73057a5:	mov    r8d,0x0
    72deb73057ab:	lea    r9,[r12+0x314]
    72deb73057b3:	movabs r11,0x5b63a3f49650
    72deb73057bd:	call   r11
    72deb73057c0:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73057c6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73057cc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73057d2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb73057d8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb73057de:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb73057e4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb73057ea:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb73057f4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb73057fe:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7305808:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb7305812:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730581a:	mov    QWORD PTR [r12+0x378],0x2
    72deb7305826:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb730582f:	mov    rdx,rbx
    72deb7305832:	shr    rdx,0x10
    72deb7305836:	and    edx,0xc000
    72deb730583c:	mov    rax,rbx
    72deb730583f:	shr    rax,0x15
    72deb7305843:	and    eax,0x100
    72deb7305848:	xor    eax,0x100
    72deb730584d:	or     edx,eax
    72deb730584f:	mov    rax,rbx
    72deb7305852:	shr    rax,0x1c
    72deb7305856:	and    eax,0x1
    72deb7305859:	or     edx,eax
    72deb730585b:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7305860:	add    rsp,0x8
    72deb7305864:	ret
    72deb7305865:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7305870:	sub    rsp,0x8
    72deb7305874:	mov    QWORD PTR [r12+0x378],0x3
    72deb7305880:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7305886:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb730588c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7305892:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7305898:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb730589e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73058a4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73058ae:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb73058b8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb73058c2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb73058cc:	push   rdx
    72deb73058cd:	push   rsi
    72deb73058ce:	push   r10
    72deb73058d0:	push   r11
    72deb73058d2:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb73058d7:	mov    r10d,edx
    72deb73058da:	and    r10d,0xc000
    72deb73058e1:	shl    r10d,0x10
    72deb73058e5:	mov    r11d,edx
    72deb73058e8:	and    r11d,0x100
    72deb73058ef:	shl    r11d,0x15
    72deb73058f3:	or     r10d,r11d
    72deb73058f6:	and    edx,0x1
    72deb73058f9:	shl    edx,0x1c
    72deb73058fc:	or     r10d,edx
    72deb73058ff:	btc    r10,0x1d
    72deb7305904:	mov    r11d,0xf0000000
    72deb730590a:	and    r11,r10
    72deb730590d:	movabs rsi,0xffffffff0fffffff
    72deb7305917:	and    rbx,rsi
    72deb730591a:	or     rbx,r11
    72deb730591d:	pop    r11
    72deb730591f:	pop    r10
    72deb7305921:	pop    rsi
    72deb7305922:	pop    rdx
    72deb7305923:	mov    QWORD PTR [r12+0x108],rbx
    72deb730592b:	stmxcsr DWORD PTR [r12-0x28]
    72deb7305931:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7305936:	test   r10d,0x3f
    72deb730593d:	je     0x72deb7305962
    72deb7305943:	mov    r11d,r10d
    72deb7305946:	shr    r10d,1
    72deb7305949:	and    r10d,0x1e
    72deb730594d:	and    r11d,0x1
    72deb7305951:	or     r10d,r11d
    72deb7305954:	or     DWORD PTR [r12+0x314],r10d
    72deb730595c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7305962:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7305968:	lea    rdi,[rsp+0x110]
    72deb7305970:	lea    rsi,[rsp+0xf0]
    72deb7305978:	lea    rdx,[rsp+0x100]
    72deb7305980:	mov    ecx,0x14
    72deb7305985:	mov    r8d,0x0
    72deb730598b:	lea    r9,[r12+0x314]
    72deb7305993:	movabs r11,0x5b63a3f49650
    72deb730599d:	call   r11
    72deb73059a0:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73059a6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73059ac:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73059b2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb73059b8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb73059be:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb73059c4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb73059ca:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb73059d4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb73059de:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb73059e8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb73059f2:	mov    rbx,QWORD PTR [r12+0x108]
    72deb73059fa:	mov    QWORD PTR [r12+0x378],0x2
    72deb7305a06:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7305a0f:	mov    rdx,rbx
    72deb7305a12:	shr    rdx,0x10
    72deb7305a16:	and    edx,0xc000
    72deb7305a1c:	mov    rax,rbx
    72deb7305a1f:	shr    rax,0x15
    72deb7305a23:	and    eax,0x100
    72deb7305a28:	xor    eax,0x100
    72deb7305a2d:	or     edx,eax
    72deb7305a2f:	mov    rax,rbx
    72deb7305a32:	shr    rax,0x1c
    72deb7305a36:	and    eax,0x1
    72deb7305a39:	or     edx,eax
    72deb7305a3b:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7305a40:	add    rsp,0x8
    72deb7305a44:	ret
    72deb7305a45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7305a50:	sub    rsp,0x8
    72deb7305a54:	mov    QWORD PTR [r12+0x378],0x3
    72deb7305a60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7305a66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb7305a6c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7305a72:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7305a78:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7305a7e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7305a88:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7305a92:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7305a9c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7305aa6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb7305ab0:	push   rdx
    72deb7305ab1:	push   rsi
    72deb7305ab2:	push   r10
    72deb7305ab4:	push   r11
    72deb7305ab6:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7305abb:	mov    r10d,edx
    72deb7305abe:	and    r10d,0xc000
    72deb7305ac5:	shl    r10d,0x10
    72deb7305ac9:	mov    r11d,edx
    72deb7305acc:	and    r11d,0x100
    72deb7305ad3:	shl    r11d,0x15
    72deb7305ad7:	or     r10d,r11d
    72deb7305ada:	and    edx,0x1
    72deb7305add:	shl    edx,0x1c
    72deb7305ae0:	or     r10d,edx
    72deb7305ae3:	btc    r10,0x1d
    72deb7305ae8:	mov    r11d,0xf0000000
    72deb7305aee:	and    r11,r10
    72deb7305af1:	movabs rsi,0xffffffff0fffffff
    72deb7305afb:	and    rbx,rsi
    72deb7305afe:	or     rbx,r11
    72deb7305b01:	pop    r11
    72deb7305b03:	pop    r10
    72deb7305b05:	pop    rsi
    72deb7305b06:	pop    rdx
    72deb7305b07:	mov    QWORD PTR [r12+0x108],rbx
    72deb7305b0f:	stmxcsr DWORD PTR [r12-0x28]
    72deb7305b15:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7305b1a:	test   r10d,0x3f
    72deb7305b21:	je     0x72deb7305b46
    72deb7305b27:	mov    r11d,r10d
    72deb7305b2a:	shr    r10d,1
    72deb7305b2d:	and    r10d,0x1e
    72deb7305b31:	and    r11d,0x1
    72deb7305b35:	or     r10d,r11d
    72deb7305b38:	or     DWORD PTR [r12+0x314],r10d
    72deb7305b40:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7305b46:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7305b4c:	lea    rdi,[rsp+0x110]
    72deb7305b54:	lea    rsi,[rsp+0xf0]
    72deb7305b5c:	lea    rdx,[rsp+0x100]
    72deb7305b64:	mov    ecx,0x56
    72deb7305b69:	mov    r8d,0x0
    72deb7305b6f:	lea    r9,[r12+0x314]
    72deb7305b77:	movabs r11,0x5b63a3f49650
    72deb7305b81:	call   r11
    72deb7305b84:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7305b8a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7305b90:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7305b96:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7305b9c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7305ba2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7305ba8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7305bb2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7305bbc:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7305bc6:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7305bd0:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb7305bda:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7305be2:	mov    QWORD PTR [r12+0x378],0x2
    72deb7305bee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7305bf7:	mov    rdx,rbx
    72deb7305bfa:	shr    rdx,0x10
    72deb7305bfe:	and    edx,0xc000
    72deb7305c04:	mov    rax,rbx
    72deb7305c07:	shr    rax,0x15
    72deb7305c0b:	and    eax,0x100
    72deb7305c10:	xor    eax,0x100
    72deb7305c15:	or     edx,eax
    72deb7305c17:	mov    rax,rbx
    72deb7305c1a:	shr    rax,0x1c
    72deb7305c1e:	and    eax,0x1
    72deb7305c21:	or     edx,eax
    72deb7305c23:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7305c28:	add    rsp,0x8
    72deb7305c2c:	ret
    72deb7305c2d:	nop    DWORD PTR [rax]
    72deb7305c30:	sub    rsp,0x8
    72deb7305c34:	mov    QWORD PTR [r12+0x378],0x3
    72deb7305c40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7305c46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb7305c4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7305c52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7305c58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7305c5e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7305c64:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7305c6e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7305c78:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7305c82:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7305c8c:	push   rdx
    72deb7305c8d:	push   rsi
    72deb7305c8e:	push   r10
    72deb7305c90:	push   r11
    72deb7305c92:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7305c97:	mov    r10d,edx
    72deb7305c9a:	and    r10d,0xc000
    72deb7305ca1:	shl    r10d,0x10
    72deb7305ca5:	mov    r11d,edx
    72deb7305ca8:	and    r11d,0x100
    72deb7305caf:	shl    r11d,0x15
    72deb7305cb3:	or     r10d,r11d
    72deb7305cb6:	and    edx,0x1
    72deb7305cb9:	shl    edx,0x1c
    72deb7305cbc:	or     r10d,edx
    72deb7305cbf:	btc    r10,0x1d
    72deb7305cc4:	mov    r11d,0xf0000000
    72deb7305cca:	and    r11,r10
    72deb7305ccd:	movabs rsi,0xffffffff0fffffff
    72deb7305cd7:	and    rbx,rsi
    72deb7305cda:	or     rbx,r11
    72deb7305cdd:	pop    r11
    72deb7305cdf:	pop    r10
    72deb7305ce1:	pop    rsi
    72deb7305ce2:	pop    rdx
    72deb7305ce3:	mov    QWORD PTR [r12+0x108],rbx
    72deb7305ceb:	stmxcsr DWORD PTR [r12-0x28]
    72deb7305cf1:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7305cf6:	test   r10d,0x3f
    72deb7305cfd:	je     0x72deb7305d22
    72deb7305d03:	mov    r11d,r10d
    72deb7305d06:	shr    r10d,1
    72deb7305d09:	and    r10d,0x1e
    72deb7305d0d:	and    r11d,0x1
    72deb7305d11:	or     r10d,r11d
    72deb7305d14:	or     DWORD PTR [r12+0x314],r10d
    72deb7305d1c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7305d22:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7305d28:	lea    rdi,[rsp+0x110]
    72deb7305d30:	lea    rsi,[rsp+0xf0]
    72deb7305d38:	lea    rdx,[rsp+0x100]
    72deb7305d40:	mov    ecx,0x56
    72deb7305d45:	mov    r8d,0x0
    72deb7305d4b:	lea    r9,[r12+0x314]
    72deb7305d53:	movabs r11,0x5b63a3f49650
    72deb7305d5d:	call   r11
    72deb7305d60:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7305d66:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7305d6c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7305d72:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7305d78:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7305d7e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7305d84:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7305d8a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7305d94:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7305d9e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7305da8:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7305db2:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7305dba:	mov    QWORD PTR [r12+0x378],0x2
    72deb7305dc6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7305dcf:	mov    rdx,rbx
    72deb7305dd2:	shr    rdx,0x10
    72deb7305dd6:	and    edx,0xc000
    72deb7305ddc:	mov    rax,rbx
    72deb7305ddf:	shr    rax,0x15
    72deb7305de3:	and    eax,0x100
    72deb7305de8:	xor    eax,0x100
    72deb7305ded:	or     edx,eax
    72deb7305def:	mov    rax,rbx
    72deb7305df2:	shr    rax,0x1c
    72deb7305df6:	and    eax,0x1
    72deb7305df9:	or     edx,eax
    72deb7305dfb:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7305e00:	add    rsp,0x8
    72deb7305e04:	ret
    72deb7305e05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7305e10:	sub    rsp,0x8
    72deb7305e14:	mov    QWORD PTR [r12+0x378],0x3
    72deb7305e20:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7305e26:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb7305e2c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7305e32:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7305e38:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7305e3e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7305e44:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7305e4e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7305e58:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7305e62:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7305e6c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb7305e76:	push   rdx
    72deb7305e77:	push   rsi
    72deb7305e78:	push   r10
    72deb7305e7a:	push   r11
    72deb7305e7c:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7305e81:	mov    r10d,edx
    72deb7305e84:	and    r10d,0xc000
    72deb7305e8b:	shl    r10d,0x10
    72deb7305e8f:	mov    r11d,edx
    72deb7305e92:	and    r11d,0x100
    72deb7305e99:	shl    r11d,0x15
    72deb7305e9d:	or     r10d,r11d
    72deb7305ea0:	and    edx,0x1
    72deb7305ea3:	shl    edx,0x1c
    72deb7305ea6:	or     r10d,edx
    72deb7305ea9:	btc    r10,0x1d
    72deb7305eae:	mov    r11d,0xf0000000
    72deb7305eb4:	and    r11,r10
    72deb7305eb7:	movabs rsi,0xffffffff0fffffff
    72deb7305ec1:	and    rbx,rsi
    72deb7305ec4:	or     rbx,r11
    72deb7305ec7:	pop    r11
    72deb7305ec9:	pop    r10
    72deb7305ecb:	pop    rsi
    72deb7305ecc:	pop    rdx
    72deb7305ecd:	mov    QWORD PTR [r12+0x108],rbx
    72deb7305ed5:	stmxcsr DWORD PTR [r12-0x28]
    72deb7305edb:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7305ee0:	test   r10d,0x3f
    72deb7305ee7:	je     0x72deb7305f0c
    72deb7305eed:	mov    r11d,r10d
    72deb7305ef0:	shr    r10d,1
    72deb7305ef3:	and    r10d,0x1e
    72deb7305ef7:	and    r11d,0x1
    72deb7305efb:	or     r10d,r11d
    72deb7305efe:	or     DWORD PTR [r12+0x314],r10d
    72deb7305f06:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7305f0c:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7305f12:	lea    rdi,[rsp+0x110]
    72deb7305f1a:	lea    rsi,[rsp+0xf0]
    72deb7305f22:	lea    rdx,[rsp+0x100]
    72deb7305f2a:	mov    ecx,0x14
    72deb7305f2f:	mov    r8d,0x0
    72deb7305f35:	lea    r9,[r12+0x314]
    72deb7305f3d:	movabs r11,0x5b63a3f49650
    72deb7305f47:	call   r11
    72deb7305f4a:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7305f50:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7305f56:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7305f5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7305f62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7305f68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7305f6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7305f74:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7305f7e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7305f88:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7305f92:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7305f9c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb7305fa6:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7305fae:	mov    QWORD PTR [r12+0x378],0x2
    72deb7305fba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7305fc3:	mov    rdx,rbx
    72deb7305fc6:	shr    rdx,0x10
    72deb7305fca:	and    edx,0xc000
    72deb7305fd0:	mov    rax,rbx
    72deb7305fd3:	shr    rax,0x15
    72deb7305fd7:	and    eax,0x100
    72deb7305fdc:	xor    eax,0x100
    72deb7305fe1:	or     edx,eax
    72deb7305fe3:	mov    rax,rbx
    72deb7305fe6:	shr    rax,0x1c
    72deb7305fea:	and    eax,0x1
    72deb7305fed:	or     edx,eax
    72deb7305fef:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7305ff4:	add    rsp,0x8
    72deb7305ff8:	ret
    72deb7305ff9:	nop    DWORD PTR [rax+0x0]
    72deb7306000:	sub    rsp,0x8
    72deb7306004:	mov    QWORD PTR [r12+0x378],0x3
    72deb7306010:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7306016:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb730601c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7306022:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7306028:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7306032:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb730603c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7306046:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7306050:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb730605a:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb7306064:	push   rdx
    72deb7306065:	push   rsi
    72deb7306066:	push   r10
    72deb7306068:	push   r11
    72deb730606a:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb730606f:	mov    r10d,edx
    72deb7306072:	and    r10d,0xc000
    72deb7306079:	shl    r10d,0x10
    72deb730607d:	mov    r11d,edx
    72deb7306080:	and    r11d,0x100
    72deb7306087:	shl    r11d,0x15
    72deb730608b:	or     r10d,r11d
    72deb730608e:	and    edx,0x1
    72deb7306091:	shl    edx,0x1c
    72deb7306094:	or     r10d,edx
    72deb7306097:	btc    r10,0x1d
    72deb730609c:	mov    r11d,0xf0000000
    72deb73060a2:	and    r11,r10
    72deb73060a5:	movabs rsi,0xffffffff0fffffff
    72deb73060af:	and    rbx,rsi
    72deb73060b2:	or     rbx,r11
    72deb73060b5:	pop    r11
    72deb73060b7:	pop    r10
    72deb73060b9:	pop    rsi
    72deb73060ba:	pop    rdx
    72deb73060bb:	mov    QWORD PTR [r12+0x108],rbx
    72deb73060c3:	stmxcsr DWORD PTR [r12-0x28]
    72deb73060c9:	mov    r10d,DWORD PTR [r12-0x28]
    72deb73060ce:	test   r10d,0x3f
    72deb73060d5:	je     0x72deb73060fa
    72deb73060db:	mov    r11d,r10d
    72deb73060de:	shr    r10d,1
    72deb73060e1:	and    r10d,0x1e
    72deb73060e5:	and    r11d,0x1
    72deb73060e9:	or     r10d,r11d
    72deb73060ec:	or     DWORD PTR [r12+0x314],r10d
    72deb73060f4:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73060fa:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7306100:	lea    rdi,[rsp+0x110]
    72deb7306108:	lea    rsi,[rsp+0xf0]
    72deb7306110:	lea    rdx,[rsp+0x100]
    72deb7306118:	mov    ecx,0x56
    72deb730611d:	mov    r8d,0x0
    72deb7306123:	lea    r9,[r12+0x314]
    72deb730612b:	movabs r11,0x5b63a3f49650
    72deb7306135:	call   r11
    72deb7306138:	ldmxcsr DWORD PTR [r12-0x28]
    72deb730613e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7306144:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb730614a:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7306150:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7306156:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7306160:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb730616a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7306174:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb730617e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7306188:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb7306192:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730619a:	mov    QWORD PTR [r12+0x378],0x2
    72deb73061a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb73061af:	mov    rdx,rbx
    72deb73061b2:	shr    rdx,0x10
    72deb73061b6:	and    edx,0xc000
    72deb73061bc:	mov    rax,rbx
    72deb73061bf:	shr    rax,0x15
    72deb73061c3:	and    eax,0x100
    72deb73061c8:	xor    eax,0x100
    72deb73061cd:	or     edx,eax
    72deb73061cf:	mov    rax,rbx
    72deb73061d2:	shr    rax,0x1c
    72deb73061d6:	and    eax,0x1
    72deb73061d9:	or     edx,eax
    72deb73061db:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73061e0:	add    rsp,0x8
    72deb73061e4:	ret
    72deb73061e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb73061f0:	sub    rsp,0x8
    72deb73061f4:	mov    QWORD PTR [r12+0x378],0x3
    72deb7306200:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7306206:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb730620c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7306212:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7306218:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb730621e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7306228:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7306232:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb730623c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7306246:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7306250:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb730625a:	push   rdx
    72deb730625b:	push   rsi
    72deb730625c:	push   r10
    72deb730625e:	push   r11
    72deb7306260:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7306265:	mov    r10d,edx
    72deb7306268:	and    r10d,0xc000
    72deb730626f:	shl    r10d,0x10
    72deb7306273:	mov    r11d,edx
    72deb7306276:	and    r11d,0x100
    72deb730627d:	shl    r11d,0x15
    72deb7306281:	or     r10d,r11d
    72deb7306284:	and    edx,0x1
    72deb7306287:	shl    edx,0x1c
    72deb730628a:	or     r10d,edx
    72deb730628d:	btc    r10,0x1d
    72deb7306292:	mov    r11d,0xf0000000
    72deb7306298:	and    r11,r10
    72deb730629b:	movabs rsi,0xffffffff0fffffff
    72deb73062a5:	and    rbx,rsi
    72deb73062a8:	or     rbx,r11
    72deb73062ab:	pop    r11
    72deb73062ad:	pop    r10
    72deb73062af:	pop    rsi
    72deb73062b0:	pop    rdx
    72deb73062b1:	mov    QWORD PTR [r12+0x108],rbx
    72deb73062b9:	stmxcsr DWORD PTR [r12-0x28]
    72deb73062bf:	mov    r10d,DWORD PTR [r12-0x28]
    72deb73062c4:	test   r10d,0x3f
    72deb73062cb:	je     0x72deb73062f0
    72deb73062d1:	mov    r11d,r10d
    72deb73062d4:	shr    r10d,1
    72deb73062d7:	and    r10d,0x1e
    72deb73062db:	and    r11d,0x1
    72deb73062df:	or     r10d,r11d
    72deb73062e2:	or     DWORD PTR [r12+0x314],r10d
    72deb73062ea:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73062f0:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73062f6:	lea    rdi,[rsp+0x110]
    72deb73062fe:	lea    rsi,[rsp+0xf0]
    72deb7306306:	lea    rdx,[rsp+0x100]
    72deb730630e:	mov    ecx,0x14
    72deb7306313:	mov    r8d,0x0
    72deb7306319:	lea    r9,[r12+0x314]
    72deb7306321:	movabs r11,0x5b63a3f49650
    72deb730632b:	call   r11
    72deb730632e:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7306334:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb730633a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7306340:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7306346:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb730634c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7306352:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb730635c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7306366:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7306370:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb730637a:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7306384:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb730638e:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7306396:	mov    QWORD PTR [r12+0x378],0x2
    72deb73063a2:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb73063ab:	mov    rdx,rbx
    72deb73063ae:	shr    rdx,0x10
    72deb73063b2:	and    edx,0xc000
    72deb73063b8:	mov    rax,rbx
    72deb73063bb:	shr    rax,0x15
    72deb73063bf:	and    eax,0x100
    72deb73063c4:	xor    eax,0x100
    72deb73063c9:	or     edx,eax
    72deb73063cb:	mov    rax,rbx
    72deb73063ce:	shr    rax,0x1c
    72deb73063d2:	and    eax,0x1
    72deb73063d5:	or     edx,eax
    72deb73063d7:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73063dc:	add    rsp,0x8
    72deb73063e0:	ret
    72deb73063e1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb73063f0:	sub    rsp,0x8
    72deb73063f4:	mov    QWORD PTR [r12+0x378],0x3
    72deb7306400:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7306406:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb730640c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7306412:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7306418:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb730641e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7306424:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb730642e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7306438:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7306442:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb730644c:	push   rdx
    72deb730644d:	push   rsi
    72deb730644e:	push   r10
    72deb7306450:	push   r11
    72deb7306452:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7306457:	mov    r10d,edx
    72deb730645a:	and    r10d,0xc000
    72deb7306461:	shl    r10d,0x10
    72deb7306465:	mov    r11d,edx
    72deb7306468:	and    r11d,0x100
    72deb730646f:	shl    r11d,0x15
    72deb7306473:	or     r10d,r11d
    72deb7306476:	and    edx,0x1
    72deb7306479:	shl    edx,0x1c
    72deb730647c:	or     r10d,edx
    72deb730647f:	btc    r10,0x1d
    72deb7306484:	mov    r11d,0xf0000000
    72deb730648a:	and    r11,r10
    72deb730648d:	movabs rsi,0xffffffff0fffffff
    72deb7306497:	and    rbx,rsi
    72deb730649a:	or     rbx,r11
    72deb730649d:	pop    r11
    72deb730649f:	pop    r10
    72deb73064a1:	pop    rsi
    72deb73064a2:	pop    rdx
    72deb73064a3:	mov    QWORD PTR [r12+0x108],rbx
    72deb73064ab:	stmxcsr DWORD PTR [r12-0x28]
    72deb73064b1:	mov    r10d,DWORD PTR [r12-0x28]
    72deb73064b6:	test   r10d,0x3f
    72deb73064bd:	je     0x72deb73064e2
    72deb73064c3:	mov    r11d,r10d
    72deb73064c6:	shr    r10d,1
    72deb73064c9:	and    r10d,0x1e
    72deb73064cd:	and    r11d,0x1
    72deb73064d1:	or     r10d,r11d
    72deb73064d4:	or     DWORD PTR [r12+0x314],r10d
    72deb73064dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73064e2:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73064e8:	lea    rdi,[rsp+0x110]
    72deb73064f0:	lea    rsi,[rsp+0xf0]
    72deb73064f8:	lea    rdx,[rsp+0x100]
    72deb7306500:	mov    ecx,0x56
    72deb7306505:	mov    r8d,0x0
    72deb730650b:	lea    r9,[r12+0x314]
    72deb7306513:	movabs r11,0x5b63a3f49650
    72deb730651d:	call   r11
    72deb7306520:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7306526:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb730652c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7306532:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7306538:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb730653e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7306544:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb730654a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7306554:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb730655e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7306568:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb7306572:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730657a:	mov    QWORD PTR [r12+0x378],0x2
    72deb7306586:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb730658f:	mov    rdx,rbx
    72deb7306592:	shr    rdx,0x10
    72deb7306596:	and    edx,0xc000
    72deb730659c:	mov    rax,rbx
    72deb730659f:	shr    rax,0x15
    72deb73065a3:	and    eax,0x100
    72deb73065a8:	xor    eax,0x100
    72deb73065ad:	or     edx,eax
    72deb73065af:	mov    rax,rbx
    72deb73065b2:	shr    rax,0x1c
    72deb73065b6:	and    eax,0x1
    72deb73065b9:	or     edx,eax
    72deb73065bb:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73065c0:	add    rsp,0x8
    72deb73065c4:	ret
    72deb73065c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb73065d0:	sub    rsp,0x8
    72deb73065d4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73065e0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73065e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73065ec:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73065f2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73065f8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7306602:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb730660c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7306616:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7306620:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72deb730662a:	push   rdx
    72deb730662b:	push   rsi
    72deb730662c:	push   r10
    72deb730662e:	push   r11
    72deb7306630:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7306635:	mov    r10d,edx
    72deb7306638:	and    r10d,0xc000
    72deb730663f:	shl    r10d,0x10
    72deb7306643:	mov    r11d,edx
    72deb7306646:	and    r11d,0x100
    72deb730664d:	shl    r11d,0x15
    72deb7306651:	or     r10d,r11d
    72deb7306654:	and    edx,0x1
    72deb7306657:	shl    edx,0x1c
    72deb730665a:	or     r10d,edx
    72deb730665d:	btc    r10,0x1d
    72deb7306662:	mov    r11d,0xf0000000
    72deb7306668:	and    r11,r10
    72deb730666b:	movabs rsi,0xffffffff0fffffff
    72deb7306675:	and    rbx,rsi
    72deb7306678:	or     rbx,r11
    72deb730667b:	pop    r11
    72deb730667d:	pop    r10
    72deb730667f:	pop    rsi
    72deb7306680:	pop    rdx
    72deb7306681:	mov    QWORD PTR [r12+0x108],rbx
    72deb7306689:	stmxcsr DWORD PTR [r12-0x28]
    72deb730668f:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7306694:	test   r10d,0x3f
    72deb730669b:	je     0x72deb73066c0
    72deb73066a1:	mov    r11d,r10d
    72deb73066a4:	shr    r10d,1
    72deb73066a7:	and    r10d,0x1e
    72deb73066ab:	and    r11d,0x1
    72deb73066af:	or     r10d,r11d
    72deb73066b2:	or     DWORD PTR [r12+0x314],r10d
    72deb73066ba:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73066c0:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73066c6:	lea    rdi,[rsp+0x110]
    72deb73066ce:	lea    rsi,[rsp+0xf0]
    72deb73066d6:	lea    rdx,[rsp+0x100]
    72deb73066de:	mov    ecx,0x14
    72deb73066e3:	mov    r8d,0x0
    72deb73066e9:	lea    r9,[r12+0x314]
    72deb73066f1:	movabs r11,0x5b63a3f49650
    72deb73066fb:	call   r11
    72deb73066fe:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7306704:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb730670a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7306710:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7306716:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb730671c:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7306726:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7306730:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb730673a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7306744:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72deb730674e:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7306756:	mov    QWORD PTR [r12+0x378],0x2
    72deb7306762:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb730676b:	mov    rdx,rbx
    72deb730676e:	shr    rdx,0x10
    72deb7306772:	and    edx,0xc000
    72deb7306778:	mov    rax,rbx
    72deb730677b:	shr    rax,0x15
    72deb730677f:	and    eax,0x100
    72deb7306784:	xor    eax,0x100
    72deb7306789:	or     edx,eax
    72deb730678b:	mov    rax,rbx
    72deb730678e:	shr    rax,0x1c
    72deb7306792:	and    eax,0x1
    72deb7306795:	or     edx,eax
    72deb7306797:	mov    QWORD PTR [rsp+0x10],rdx
    72deb730679c:	add    rsp,0x8
    72deb73067a0:	ret
    72deb73067a1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb73067b0:	sub    rsp,0x8
    72deb73067b4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73067c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73067c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73067cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73067d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73067d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73067de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73067e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb73067ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb73067f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7306802:	push   rdx
    72deb7306803:	push   rsi
    72deb7306804:	push   r10
    72deb7306806:	push   r11
    72deb7306808:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb730680d:	mov    r10d,edx
    72deb7306810:	and    r10d,0xc000
    72deb7306817:	shl    r10d,0x10
    72deb730681b:	mov    r11d,edx
    72deb730681e:	and    r11d,0x100
    72deb7306825:	shl    r11d,0x15
    72deb7306829:	or     r10d,r11d
    72deb730682c:	and    edx,0x1
    72deb730682f:	shl    edx,0x1c
    72deb7306832:	or     r10d,edx
    72deb7306835:	btc    r10,0x1d
    72deb730683a:	mov    r11d,0xf0000000
    72deb7306840:	and    r11,r10
    72deb7306843:	movabs rsi,0xffffffff0fffffff
    72deb730684d:	and    rbx,rsi
    72deb7306850:	or     rbx,r11
    72deb7306853:	pop    r11
    72deb7306855:	pop    r10
    72deb7306857:	pop    rsi
    72deb7306858:	pop    rdx
    72deb7306859:	mov    QWORD PTR [r12+0x108],rbx
    72deb7306861:	stmxcsr DWORD PTR [r12-0x28]
    72deb7306867:	mov    r10d,DWORD PTR [r12-0x28]
    72deb730686c:	test   r10d,0x3f
    72deb7306873:	je     0x72deb7306898
    72deb7306879:	mov    r11d,r10d
    72deb730687c:	shr    r10d,1
    72deb730687f:	and    r10d,0x1e
    72deb7306883:	and    r11d,0x1
    72deb7306887:	or     r10d,r11d
    72deb730688a:	or     DWORD PTR [r12+0x314],r10d
    72deb7306892:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7306898:	ldmxcsr DWORD PTR [r12-0x38]
    72deb730689e:	lea    rdi,[rsp+0x110]
    72deb73068a6:	lea    rsi,[rsp+0xf0]
    72deb73068ae:	lea    rdx,[rsp+0x100]
    72deb73068b6:	mov    ecx,0x56
    72deb73068bb:	mov    r8d,0x0
    72deb73068c1:	lea    r9,[r12+0x314]
    72deb73068c9:	movabs r11,0x5b63a3f49650
    72deb73068d3:	call   r11
    72deb73068d6:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73068dc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73068e2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73068e8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb73068ee:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb73068f4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb73068fa:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7306900:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb730690a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7306914:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb730691e:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7306926:	mov    QWORD PTR [r12+0x378],0x2
    72deb7306932:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb730693b:	mov    rdx,rbx
    72deb730693e:	shr    rdx,0x10
    72deb7306942:	and    edx,0xc000
    72deb7306948:	mov    rax,rbx
    72deb730694b:	shr    rax,0x15
    72deb730694f:	and    eax,0x100
    72deb7306954:	xor    eax,0x100
    72deb7306959:	or     edx,eax
    72deb730695b:	mov    rax,rbx
    72deb730695e:	shr    rax,0x1c
    72deb7306962:	and    eax,0x1
    72deb7306965:	or     edx,eax
    72deb7306967:	mov    QWORD PTR [rsp+0x10],rdx
    72deb730696c:	add    rsp,0x8
    72deb7306970:	ret
    72deb7306971:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7306980:	sub    rsp,0x8
    72deb7306984:	mov    QWORD PTR [r12+0x378],0x3
    72deb7306990:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7306996:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb730699c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73069a2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73069a8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73069ae:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb73069b8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb73069c2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73069cc:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb73069d6:	push   rdx
    72deb73069d7:	push   rsi
    72deb73069d8:	push   r10
    72deb73069da:	push   r11
    72deb73069dc:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb73069e1:	mov    r10d,edx
    72deb73069e4:	and    r10d,0xc000
    72deb73069eb:	shl    r10d,0x10
    72deb73069ef:	mov    r11d,edx
    72deb73069f2:	and    r11d,0x100
    72deb73069f9:	shl    r11d,0x15
    72deb73069fd:	or     r10d,r11d
    72deb7306a00:	and    edx,0x1
    72deb7306a03:	shl    edx,0x1c
    72deb7306a06:	or     r10d,edx
    72deb7306a09:	btc    r10,0x1d
    72deb7306a0e:	mov    r11d,0xf0000000
    72deb7306a14:	and    r11,r10
    72deb7306a17:	movabs rsi,0xffffffff0fffffff
    72deb7306a21:	and    rbx,rsi
    72deb7306a24:	or     rbx,r11
    72deb7306a27:	pop    r11
    72deb7306a29:	pop    r10
    72deb7306a2b:	pop    rsi
    72deb7306a2c:	pop    rdx
    72deb7306a2d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7306a35:	stmxcsr DWORD PTR [r12-0x28]
    72deb7306a3b:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7306a40:	test   r10d,0x3f
    72deb7306a47:	je     0x72deb7306a6c
    72deb7306a4d:	mov    r11d,r10d
    72deb7306a50:	shr    r10d,1
    72deb7306a53:	and    r10d,0x1e
    72deb7306a57:	and    r11d,0x1
    72deb7306a5b:	or     r10d,r11d
    72deb7306a5e:	or     DWORD PTR [r12+0x314],r10d
    72deb7306a66:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7306a6c:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7306a72:	lea    rdi,[rsp+0x110]
    72deb7306a7a:	lea    rsi,[rsp+0xf0]
    72deb7306a82:	lea    rdx,[rsp+0x100]
    72deb7306a8a:	mov    ecx,0x56
    72deb7306a8f:	mov    r8d,0x0
    72deb7306a95:	lea    r9,[r12+0x314]
    72deb7306a9d:	movabs r11,0x5b63a3f49650
    72deb7306aa7:	call   r11
    72deb7306aaa:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7306ab0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7306ab6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7306abc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7306ac2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7306ac8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7306ace:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7306ad8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7306ae2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7306aec:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7306af6:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7306afe:	mov    QWORD PTR [r12+0x378],0x2
    72deb7306b0a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7306b13:	mov    rdx,rbx
    72deb7306b16:	shr    rdx,0x10
    72deb7306b1a:	and    edx,0xc000
    72deb7306b20:	mov    rax,rbx
    72deb7306b23:	shr    rax,0x15
    72deb7306b27:	and    eax,0x100
    72deb7306b2c:	xor    eax,0x100
    72deb7306b31:	or     edx,eax
    72deb7306b33:	mov    rax,rbx
    72deb7306b36:	shr    rax,0x1c
    72deb7306b3a:	and    eax,0x1
    72deb7306b3d:	or     edx,eax
    72deb7306b3f:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7306b44:	add    rsp,0x8
    72deb7306b48:	ret
    72deb7306b49:	nop    DWORD PTR [rax+0x0]
    72deb7306b50:	sub    rsp,0x8
    72deb7306b54:	mov    QWORD PTR [r12+0x378],0x3
    72deb7306b60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7306b66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb7306b6c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7306b72:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7306b78:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7306b7e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7306b84:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7306b8e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7306b98:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7306ba2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7306bac:	push   rdx
    72deb7306bad:	push   rsi
    72deb7306bae:	push   r10
    72deb7306bb0:	push   r11
    72deb7306bb2:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7306bb7:	mov    r10d,edx
    72deb7306bba:	and    r10d,0xc000
    72deb7306bc1:	shl    r10d,0x10
    72deb7306bc5:	mov    r11d,edx
    72deb7306bc8:	and    r11d,0x100
    72deb7306bcf:	shl    r11d,0x15
    72deb7306bd3:	or     r10d,r11d
    72deb7306bd6:	and    edx,0x1
    72deb7306bd9:	shl    edx,0x1c
    72deb7306bdc:	or     r10d,edx
    72deb7306bdf:	btc    r10,0x1d
    72deb7306be4:	mov    r11d,0xf0000000
    72deb7306bea:	and    r11,r10
    72deb7306bed:	movabs rsi,0xffffffff0fffffff
    72deb7306bf7:	and    rbx,rsi
    72deb7306bfa:	or     rbx,r11
    72deb7306bfd:	pop    r11
    72deb7306bff:	pop    r10
    72deb7306c01:	pop    rsi
    72deb7306c02:	pop    rdx
    72deb7306c03:	mov    QWORD PTR [r12+0x108],rbx
    72deb7306c0b:	stmxcsr DWORD PTR [r12-0x28]
    72deb7306c11:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7306c16:	test   r10d,0x3f
    72deb7306c1d:	je     0x72deb7306c42
    72deb7306c23:	mov    r11d,r10d
    72deb7306c26:	shr    r10d,1
    72deb7306c29:	and    r10d,0x1e
    72deb7306c2d:	and    r11d,0x1
    72deb7306c31:	or     r10d,r11d
    72deb7306c34:	or     DWORD PTR [r12+0x314],r10d
    72deb7306c3c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7306c42:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7306c48:	lea    rdi,[rsp+0x110]
    72deb7306c50:	lea    rsi,[rsp+0xf0]
    72deb7306c58:	lea    rdx,[rsp+0x100]
    72deb7306c60:	mov    ecx,0x14
    72deb7306c65:	mov    r8d,0x0
    72deb7306c6b:	lea    r9,[r12+0x314]
    72deb7306c73:	movabs r11,0x5b63a3f49650
    72deb7306c7d:	call   r11
    72deb7306c80:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7306c86:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7306c8c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7306c92:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7306c98:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7306c9e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7306ca4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7306caa:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7306cb4:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7306cbe:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7306cc8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7306cd2:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7306cda:	mov    QWORD PTR [r12+0x378],0x2
    72deb7306ce6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7306cef:	mov    rdx,rbx
    72deb7306cf2:	shr    rdx,0x10
    72deb7306cf6:	and    edx,0xc000
    72deb7306cfc:	mov    rax,rbx
    72deb7306cff:	shr    rax,0x15
    72deb7306d03:	and    eax,0x100
    72deb7306d08:	xor    eax,0x100
    72deb7306d0d:	or     edx,eax
    72deb7306d0f:	mov    rax,rbx
    72deb7306d12:	shr    rax,0x1c
    72deb7306d16:	and    eax,0x1
    72deb7306d19:	or     edx,eax
    72deb7306d1b:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7306d20:	add    rsp,0x8
    72deb7306d24:	ret
    72deb7306d25:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7306d30:	sub    rsp,0x8
    72deb7306d34:	mov    QWORD PTR [r12+0x378],0x3
    72deb7306d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7306d46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb7306d4c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7306d52:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7306d58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7306d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7306d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7306d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7306d7c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7306d86:	push   rdx
    72deb7306d87:	push   rsi
    72deb7306d88:	push   r10
    72deb7306d8a:	push   r11
    72deb7306d8c:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7306d91:	mov    r10d,edx
    72deb7306d94:	and    r10d,0xc000
    72deb7306d9b:	shl    r10d,0x10
    72deb7306d9f:	mov    r11d,edx
    72deb7306da2:	and    r11d,0x100
    72deb7306da9:	shl    r11d,0x15
    72deb7306dad:	or     r10d,r11d
    72deb7306db0:	and    edx,0x1
    72deb7306db3:	shl    edx,0x1c
    72deb7306db6:	or     r10d,edx
    72deb7306db9:	btc    r10,0x1d
    72deb7306dbe:	mov    r11d,0xf0000000
    72deb7306dc4:	and    r11,r10
    72deb7306dc7:	movabs rsi,0xffffffff0fffffff
    72deb7306dd1:	and    rbx,rsi
    72deb7306dd4:	or     rbx,r11
    72deb7306dd7:	pop    r11
    72deb7306dd9:	pop    r10
    72deb7306ddb:	pop    rsi
    72deb7306ddc:	pop    rdx
    72deb7306ddd:	mov    QWORD PTR [r12+0x108],rbx
    72deb7306de5:	stmxcsr DWORD PTR [r12-0x28]
    72deb7306deb:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7306df0:	test   r10d,0x3f
    72deb7306df7:	je     0x72deb7306e1c
    72deb7306dfd:	mov    r11d,r10d
    72deb7306e00:	shr    r10d,1
    72deb7306e03:	and    r10d,0x1e
    72deb7306e07:	and    r11d,0x1
    72deb7306e0b:	or     r10d,r11d
    72deb7306e0e:	or     DWORD PTR [r12+0x314],r10d
    72deb7306e16:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7306e1c:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7306e22:	lea    rdi,[rsp+0x110]
    72deb7306e2a:	lea    rsi,[rsp+0xf0]
    72deb7306e32:	lea    rdx,[rsp+0x100]
    72deb7306e3a:	mov    ecx,0x14
    72deb7306e3f:	mov    r8d,0x0
    72deb7306e45:	lea    r9,[r12+0x314]
    72deb7306e4d:	movabs r11,0x5b63a3f49650
    72deb7306e57:	call   r11
    72deb7306e5a:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7306e60:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7306e66:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7306e6c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7306e72:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7306e78:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7306e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7306e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7306e92:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7306e9c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7306ea6:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7306eae:	mov    QWORD PTR [r12+0x378],0x2
    72deb7306eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7306ec3:	mov    rdx,rbx
    72deb7306ec6:	shr    rdx,0x10
    72deb7306eca:	and    edx,0xc000
    72deb7306ed0:	mov    rax,rbx
    72deb7306ed3:	shr    rax,0x15
    72deb7306ed7:	and    eax,0x100
    72deb7306edc:	xor    eax,0x100
    72deb7306ee1:	or     edx,eax
    72deb7306ee3:	mov    rax,rbx
    72deb7306ee6:	shr    rax,0x1c
    72deb7306eea:	and    eax,0x1
    72deb7306eed:	or     edx,eax
    72deb7306eef:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7306ef4:	add    rsp,0x8
    72deb7306ef8:	ret
    72deb7306ef9:	nop    DWORD PTR [rax+0x0]
    72deb7306f00:	sub    rsp,0x8
    72deb7306f04:	mov    QWORD PTR [r12+0x378],0x3
    72deb7306f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7306f16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb7306f1c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7306f22:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7306f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7306f2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7306f38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7306f42:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7306f4c:	push   rdx
    72deb7306f4d:	push   rsi
    72deb7306f4e:	push   r10
    72deb7306f50:	push   r11
    72deb7306f52:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7306f57:	mov    r10d,edx
    72deb7306f5a:	and    r10d,0xc000
    72deb7306f61:	shl    r10d,0x10
    72deb7306f65:	mov    r11d,edx
    72deb7306f68:	and    r11d,0x100
    72deb7306f6f:	shl    r11d,0x15
    72deb7306f73:	or     r10d,r11d
    72deb7306f76:	and    edx,0x1
    72deb7306f79:	shl    edx,0x1c
    72deb7306f7c:	or     r10d,edx
    72deb7306f7f:	btc    r10,0x1d
    72deb7306f84:	mov    r11d,0xf0000000
    72deb7306f8a:	and    r11,r10
    72deb7306f8d:	movabs rsi,0xffffffff0fffffff
    72deb7306f97:	and    rbx,rsi
    72deb7306f9a:	or     rbx,r11
    72deb7306f9d:	pop    r11
    72deb7306f9f:	pop    r10
    72deb7306fa1:	pop    rsi
    72deb7306fa2:	pop    rdx
    72deb7306fa3:	mov    QWORD PTR [r12+0x108],rbx
    72deb7306fab:	stmxcsr DWORD PTR [r12-0x28]
    72deb7306fb1:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7306fb6:	test   r10d,0x3f
    72deb7306fbd:	je     0x72deb7306fe2
    72deb7306fc3:	mov    r11d,r10d
    72deb7306fc6:	shr    r10d,1
    72deb7306fc9:	and    r10d,0x1e
    72deb7306fcd:	and    r11d,0x1
    72deb7306fd1:	or     r10d,r11d
    72deb7306fd4:	or     DWORD PTR [r12+0x314],r10d
    72deb7306fdc:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7306fe2:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7306fe8:	lea    rdi,[rsp+0x110]
    72deb7306ff0:	lea    rsi,[rsp+0xf0]
    72deb7306ff8:	lea    rdx,[rsp+0x100]
    72deb7307000:	mov    ecx,0x56
    72deb7307005:	mov    r8d,0x0
    72deb730700b:	lea    r9,[r12+0x314]
    72deb7307013:	movabs r11,0x5b63a3f49650
    72deb730701d:	call   r11
    72deb7307020:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7307026:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb730702c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7307032:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7307038:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb730703e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7307044:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb730704e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7307058:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7307062:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730706a:	mov    QWORD PTR [r12+0x378],0x2
    72deb7307076:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb730707f:	mov    rdx,rbx
    72deb7307082:	shr    rdx,0x10
    72deb7307086:	and    edx,0xc000
    72deb730708c:	mov    rax,rbx
    72deb730708f:	shr    rax,0x15
    72deb7307093:	and    eax,0x100
    72deb7307098:	xor    eax,0x100
    72deb730709d:	or     edx,eax
    72deb730709f:	mov    rax,rbx
    72deb73070a2:	shr    rax,0x1c
    72deb73070a6:	and    eax,0x1
    72deb73070a9:	or     edx,eax
    72deb73070ab:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73070b0:	add    rsp,0x8
    72deb73070b4:	ret
    72deb73070b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb73070c0:	sub    rsp,0x8
    72deb73070c4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73070d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73070d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73070dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73070e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73070e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73070ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73070f4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73070fe:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7307108:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7307112:	push   rdx
    72deb7307113:	push   rsi
    72deb7307114:	push   r10
    72deb7307116:	push   r11
    72deb7307118:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb730711d:	mov    r10d,edx
    72deb7307120:	and    r10d,0xc000
    72deb7307127:	shl    r10d,0x10
    72deb730712b:	mov    r11d,edx
    72deb730712e:	and    r11d,0x100
    72deb7307135:	shl    r11d,0x15
    72deb7307139:	or     r10d,r11d
    72deb730713c:	and    edx,0x1
    72deb730713f:	shl    edx,0x1c
    72deb7307142:	or     r10d,edx
    72deb7307145:	btc    r10,0x1d
    72deb730714a:	mov    r11d,0xf0000000
    72deb7307150:	and    r11,r10
    72deb7307153:	movabs rsi,0xffffffff0fffffff
    72deb730715d:	and    rbx,rsi
    72deb7307160:	or     rbx,r11
    72deb7307163:	pop    r11
    72deb7307165:	pop    r10
    72deb7307167:	pop    rsi
    72deb7307168:	pop    rdx
    72deb7307169:	mov    QWORD PTR [r12+0x108],rbx
    72deb7307171:	stmxcsr DWORD PTR [r12-0x28]
    72deb7307177:	mov    r10d,DWORD PTR [r12-0x28]
    72deb730717c:	test   r10d,0x3f
    72deb7307183:	je     0x72deb73071a8
    72deb7307189:	mov    r11d,r10d
    72deb730718c:	shr    r10d,1
    72deb730718f:	and    r10d,0x1e
    72deb7307193:	and    r11d,0x1
    72deb7307197:	or     r10d,r11d
    72deb730719a:	or     DWORD PTR [r12+0x314],r10d
    72deb73071a2:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73071a8:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73071ae:	lea    rdi,[rsp+0x110]
    72deb73071b6:	lea    rsi,[rsp+0xf0]
    72deb73071be:	lea    rdx,[rsp+0x100]
    72deb73071c6:	mov    ecx,0x56
    72deb73071cb:	mov    r8d,0x0
    72deb73071d1:	lea    r9,[r12+0x314]
    72deb73071d9:	movabs r11,0x5b63a3f49650
    72deb73071e3:	call   r11
    72deb73071e6:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73071ec:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73071f2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73071f8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb73071fe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7307204:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb730720a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7307210:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb730721a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7307224:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb730722e:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7307236:	mov    QWORD PTR [r12+0x378],0x2
    72deb7307242:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb730724b:	mov    rdx,rbx
    72deb730724e:	shr    rdx,0x10
    72deb7307252:	and    edx,0xc000
    72deb7307258:	mov    rax,rbx
    72deb730725b:	shr    rax,0x15
    72deb730725f:	and    eax,0x100
    72deb7307264:	xor    eax,0x100
    72deb7307269:	or     edx,eax
    72deb730726b:	mov    rax,rbx
    72deb730726e:	shr    rax,0x1c
    72deb7307272:	and    eax,0x1
    72deb7307275:	or     edx,eax
    72deb7307277:	mov    QWORD PTR [rsp+0x10],rdx
    72deb730727c:	add    rsp,0x8
    72deb7307280:	ret
    72deb7307281:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7307290:	sub    rsp,0x8
    72deb7307294:	mov    QWORD PTR [r12+0x378],0x3
    72deb73072a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73072a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73072ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73072b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73072b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73072be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb73072c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73072d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb73072dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb73072e6:	push   rdx
    72deb73072e7:	push   rsi
    72deb73072e8:	push   r10
    72deb73072ea:	push   r11
    72deb73072ec:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb73072f1:	mov    r10d,edx
    72deb73072f4:	and    r10d,0xc000
    72deb73072fb:	shl    r10d,0x10
    72deb73072ff:	mov    r11d,edx
    72deb7307302:	and    r11d,0x100
    72deb7307309:	shl    r11d,0x15
    72deb730730d:	or     r10d,r11d
    72deb7307310:	and    edx,0x1
    72deb7307313:	shl    edx,0x1c
    72deb7307316:	or     r10d,edx
    72deb7307319:	btc    r10,0x1d
    72deb730731e:	mov    r11d,0xf0000000
    72deb7307324:	and    r11,r10
    72deb7307327:	movabs rsi,0xffffffff0fffffff
    72deb7307331:	and    rbx,rsi
    72deb7307334:	or     rbx,r11
    72deb7307337:	pop    r11
    72deb7307339:	pop    r10
    72deb730733b:	pop    rsi
    72deb730733c:	pop    rdx
    72deb730733d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7307345:	stmxcsr DWORD PTR [r12-0x28]
    72deb730734b:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7307350:	test   r10d,0x3f
    72deb7307357:	je     0x72deb730737c
    72deb730735d:	mov    r11d,r10d
    72deb7307360:	shr    r10d,1
    72deb7307363:	and    r10d,0x1e
    72deb7307367:	and    r11d,0x1
    72deb730736b:	or     r10d,r11d
    72deb730736e:	or     DWORD PTR [r12+0x314],r10d
    72deb7307376:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb730737c:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7307382:	lea    rdi,[rsp+0x110]
    72deb730738a:	lea    rsi,[rsp+0xf0]
    72deb7307392:	lea    rdx,[rsp+0x100]
    72deb730739a:	mov    ecx,0x14
    72deb730739f:	mov    r8d,0x0
    72deb73073a5:	lea    r9,[r12+0x314]
    72deb73073ad:	movabs r11,0x5b63a3f49650
    72deb73073b7:	call   r11
    72deb73073ba:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73073c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73073c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73073cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb73073d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb73073d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb73073de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb73073e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb73073f2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb73073fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7307406:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730740e:	mov    QWORD PTR [r12+0x378],0x2
    72deb730741a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7307423:	mov    rdx,rbx
    72deb7307426:	shr    rdx,0x10
    72deb730742a:	and    edx,0xc000
    72deb7307430:	mov    rax,rbx
    72deb7307433:	shr    rax,0x15
    72deb7307437:	and    eax,0x100
    72deb730743c:	xor    eax,0x100
    72deb7307441:	or     edx,eax
    72deb7307443:	mov    rax,rbx
    72deb7307446:	shr    rax,0x1c
    72deb730744a:	and    eax,0x1
    72deb730744d:	or     edx,eax
    72deb730744f:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7307454:	add    rsp,0x8
    72deb7307458:	ret
    72deb7307459:	nop    DWORD PTR [rax+0x0]
    72deb7307460:	sub    rsp,0x8
    72deb7307464:	mov    QWORD PTR [r12+0x378],0x3
    72deb7307470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7307476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb730747c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7307482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7307488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb730748e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7307498:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb73074a2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb73074ac:	push   rdx
    72deb73074ad:	push   rsi
    72deb73074ae:	push   r10
    72deb73074b0:	push   r11
    72deb73074b2:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb73074b7:	mov    r10d,edx
    72deb73074ba:	and    r10d,0xc000
    72deb73074c1:	shl    r10d,0x10
    72deb73074c5:	mov    r11d,edx
    72deb73074c8:	and    r11d,0x100
    72deb73074cf:	shl    r11d,0x15
    72deb73074d3:	or     r10d,r11d
    72deb73074d6:	and    edx,0x1
    72deb73074d9:	shl    edx,0x1c
    72deb73074dc:	or     r10d,edx
    72deb73074df:	btc    r10,0x1d
    72deb73074e4:	mov    r11d,0xf0000000
    72deb73074ea:	and    r11,r10
    72deb73074ed:	movabs rsi,0xffffffff0fffffff
    72deb73074f7:	and    rbx,rsi
    72deb73074fa:	or     rbx,r11
    72deb73074fd:	pop    r11
    72deb73074ff:	pop    r10
    72deb7307501:	pop    rsi
    72deb7307502:	pop    rdx
    72deb7307503:	mov    QWORD PTR [r12+0x108],rbx
    72deb730750b:	stmxcsr DWORD PTR [r12-0x28]
    72deb7307511:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7307516:	test   r10d,0x3f
    72deb730751d:	je     0x72deb7307542
    72deb7307523:	mov    r11d,r10d
    72deb7307526:	shr    r10d,1
    72deb7307529:	and    r10d,0x1e
    72deb730752d:	and    r11d,0x1
    72deb7307531:	or     r10d,r11d
    72deb7307534:	or     DWORD PTR [r12+0x314],r10d
    72deb730753c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7307542:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7307548:	lea    rdi,[rsp+0x110]
    72deb7307550:	lea    rsi,[rsp+0xf0]
    72deb7307558:	lea    rdx,[rsp+0x100]
    72deb7307560:	mov    ecx,0x14
    72deb7307565:	mov    r8d,0x0
    72deb730756b:	lea    r9,[r12+0x314]
    72deb7307573:	movabs r11,0x5b63a3f49650
    72deb730757d:	call   r11
    72deb7307580:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7307586:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb730758c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7307592:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7307598:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb730759e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb73075a4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb73075ae:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb73075b8:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb73075c2:	mov    rbx,QWORD PTR [r12+0x108]
    72deb73075ca:	mov    QWORD PTR [r12+0x378],0x2
    72deb73075d6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb73075df:	mov    rdx,rbx
    72deb73075e2:	shr    rdx,0x10
    72deb73075e6:	and    edx,0xc000
    72deb73075ec:	mov    rax,rbx
    72deb73075ef:	shr    rax,0x15
    72deb73075f3:	and    eax,0x100
    72deb73075f8:	xor    eax,0x100
    72deb73075fd:	or     edx,eax
    72deb73075ff:	mov    rax,rbx
    72deb7307602:	shr    rax,0x1c
    72deb7307606:	and    eax,0x1
    72deb7307609:	or     edx,eax
    72deb730760b:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7307610:	add    rsp,0x8
    72deb7307614:	ret
    72deb7307615:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7307620:	sub    rsp,0x8
    72deb7307624:	mov    QWORD PTR [r12+0x378],0x3
    72deb7307630:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7307636:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb730763c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7307642:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7307648:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb730764e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7307654:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb730765e:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7307668:	push   rdx
    72deb7307669:	push   rsi
    72deb730766a:	push   r10
    72deb730766c:	push   r11
    72deb730766e:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7307673:	mov    r10d,edx
    72deb7307676:	and    r10d,0xc000
    72deb730767d:	shl    r10d,0x10
    72deb7307681:	mov    r11d,edx
    72deb7307684:	and    r11d,0x100
    72deb730768b:	shl    r11d,0x15
    72deb730768f:	or     r10d,r11d
    72deb7307692:	and    edx,0x1
    72deb7307695:	shl    edx,0x1c
    72deb7307698:	or     r10d,edx
    72deb730769b:	btc    r10,0x1d
    72deb73076a0:	mov    r11d,0xf0000000
    72deb73076a6:	and    r11,r10
    72deb73076a9:	movabs rsi,0xffffffff0fffffff
    72deb73076b3:	and    rbx,rsi
    72deb73076b6:	or     rbx,r11
    72deb73076b9:	pop    r11
    72deb73076bb:	pop    r10
    72deb73076bd:	pop    rsi
    72deb73076be:	pop    rdx
    72deb73076bf:	mov    QWORD PTR [r12+0x108],rbx
    72deb73076c7:	stmxcsr DWORD PTR [r12-0x28]
    72deb73076cd:	mov    r10d,DWORD PTR [r12-0x28]
    72deb73076d2:	test   r10d,0x3f
    72deb73076d9:	je     0x72deb73076fe
    72deb73076df:	mov    r11d,r10d
    72deb73076e2:	shr    r10d,1
    72deb73076e5:	and    r10d,0x1e
    72deb73076e9:	and    r11d,0x1
    72deb73076ed:	or     r10d,r11d
    72deb73076f0:	or     DWORD PTR [r12+0x314],r10d
    72deb73076f8:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73076fe:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7307704:	lea    rdi,[rsp+0x110]
    72deb730770c:	lea    rsi,[rsp+0xf0]
    72deb7307714:	lea    rdx,[rsp+0x100]
    72deb730771c:	mov    ecx,0x56
    72deb7307721:	mov    r8d,0x0
    72deb7307727:	lea    r9,[r12+0x314]
    72deb730772f:	movabs r11,0x5b63a3f49650
    72deb7307739:	call   r11
    72deb730773c:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7307742:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7307748:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb730774e:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7307754:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb730775a:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7307760:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7307766:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7307770:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb730777a:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7307782:	mov    QWORD PTR [r12+0x378],0x2
    72deb730778e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7307797:	mov    rdx,rbx
    72deb730779a:	shr    rdx,0x10
    72deb730779e:	and    edx,0xc000
    72deb73077a4:	mov    rax,rbx
    72deb73077a7:	shr    rax,0x15
    72deb73077ab:	and    eax,0x100
    72deb73077b0:	xor    eax,0x100
    72deb73077b5:	or     edx,eax
    72deb73077b7:	mov    rax,rbx
    72deb73077ba:	shr    rax,0x1c
    72deb73077be:	and    eax,0x1
    72deb73077c1:	or     edx,eax
    72deb73077c3:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73077c8:	add    rsp,0x8
    72deb73077cc:	ret
    72deb73077cd:	nop    DWORD PTR [rax]
    72deb73077d0:	sub    rsp,0x8
    72deb73077d4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73077e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73077e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73077ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73077f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73077f8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73077fe:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7307804:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb730780e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7307818:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7307822:	push   rdx
    72deb7307823:	push   rsi
    72deb7307824:	push   r10
    72deb7307826:	push   r11
    72deb7307828:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb730782d:	mov    r10d,edx
    72deb7307830:	and    r10d,0xc000
    72deb7307837:	shl    r10d,0x10
    72deb730783b:	mov    r11d,edx
    72deb730783e:	and    r11d,0x100
    72deb7307845:	shl    r11d,0x15
    72deb7307849:	or     r10d,r11d
    72deb730784c:	and    edx,0x1
    72deb730784f:	shl    edx,0x1c
    72deb7307852:	or     r10d,edx
    72deb7307855:	btc    r10,0x1d
    72deb730785a:	mov    r11d,0xf0000000
    72deb7307860:	and    r11,r10
    72deb7307863:	movabs rsi,0xffffffff0fffffff
    72deb730786d:	and    rbx,rsi
    72deb7307870:	or     rbx,r11
    72deb7307873:	pop    r11
    72deb7307875:	pop    r10
    72deb7307877:	pop    rsi
    72deb7307878:	pop    rdx
    72deb7307879:	mov    QWORD PTR [r12+0x108],rbx
    72deb7307881:	stmxcsr DWORD PTR [r12-0x28]
    72deb7307887:	mov    r10d,DWORD PTR [r12-0x28]
    72deb730788c:	test   r10d,0x3f
    72deb7307893:	je     0x72deb73078b8
    72deb7307899:	mov    r11d,r10d
    72deb730789c:	shr    r10d,1
    72deb730789f:	and    r10d,0x1e
    72deb73078a3:	and    r11d,0x1
    72deb73078a7:	or     r10d,r11d
    72deb73078aa:	or     DWORD PTR [r12+0x314],r10d
    72deb73078b2:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73078b8:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73078be:	lea    rdi,[rsp+0x110]
    72deb73078c6:	lea    rsi,[rsp+0xf0]
    72deb73078ce:	lea    rdx,[rsp+0x100]
    72deb73078d6:	mov    ecx,0x14
    72deb73078db:	mov    r8d,0x0
    72deb73078e1:	lea    r9,[r12+0x314]
    72deb73078e9:	movabs r11,0x5b63a3f49650
    72deb73078f3:	call   r11
    72deb73078f6:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73078fc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7307902:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7307908:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb730790e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7307914:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb730791a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7307920:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb730792a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7307934:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb730793e:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7307946:	mov    QWORD PTR [r12+0x378],0x2
    72deb7307952:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb730795b:	mov    rdx,rbx
    72deb730795e:	shr    rdx,0x10
    72deb7307962:	and    edx,0xc000
    72deb7307968:	mov    rax,rbx
    72deb730796b:	shr    rax,0x15
    72deb730796f:	and    eax,0x100
    72deb7307974:	xor    eax,0x100
    72deb7307979:	or     edx,eax
    72deb730797b:	mov    rax,rbx
    72deb730797e:	shr    rax,0x1c
    72deb7307982:	and    eax,0x1
    72deb7307985:	or     edx,eax
    72deb7307987:	mov    QWORD PTR [rsp+0x10],rdx
    72deb730798c:	add    rsp,0x8
    72deb7307990:	ret
    72deb7307991:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb73079a0:	sub    rsp,0x8
    72deb73079a4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73079b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73079b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73079bc:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73079c2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73079c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb73079d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb73079dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73079e6:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb73079f0:	push   rdx
    72deb73079f1:	push   rsi
    72deb73079f2:	push   r10
    72deb73079f4:	push   r11
    72deb73079f6:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb73079fb:	mov    r10d,edx
    72deb73079fe:	and    r10d,0xc000
    72deb7307a05:	shl    r10d,0x10
    72deb7307a09:	mov    r11d,edx
    72deb7307a0c:	and    r11d,0x100
    72deb7307a13:	shl    r11d,0x15
    72deb7307a17:	or     r10d,r11d
    72deb7307a1a:	and    edx,0x1
    72deb7307a1d:	shl    edx,0x1c
    72deb7307a20:	or     r10d,edx
    72deb7307a23:	btc    r10,0x1d
    72deb7307a28:	mov    r11d,0xf0000000
    72deb7307a2e:	and    r11,r10
    72deb7307a31:	movabs rsi,0xffffffff0fffffff
    72deb7307a3b:	and    rbx,rsi
    72deb7307a3e:	or     rbx,r11
    72deb7307a41:	pop    r11
    72deb7307a43:	pop    r10
    72deb7307a45:	pop    rsi
    72deb7307a46:	pop    rdx
    72deb7307a47:	mov    QWORD PTR [r12+0x108],rbx
    72deb7307a4f:	stmxcsr DWORD PTR [r12-0x28]
    72deb7307a55:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7307a5a:	test   r10d,0x3f
    72deb7307a61:	je     0x72deb7307a86
    72deb7307a67:	mov    r11d,r10d
    72deb7307a6a:	shr    r10d,1
    72deb7307a6d:	and    r10d,0x1e
    72deb7307a71:	and    r11d,0x1
    72deb7307a75:	or     r10d,r11d
    72deb7307a78:	or     DWORD PTR [r12+0x314],r10d
    72deb7307a80:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7307a86:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7307a8c:	lea    rdi,[rsp+0x110]
    72deb7307a94:	lea    rsi,[rsp+0xf0]
    72deb7307a9c:	lea    rdx,[rsp+0x100]
    72deb7307aa4:	mov    ecx,0x14
    72deb7307aa9:	mov    r8d,0x0
    72deb7307aaf:	lea    r9,[r12+0x314]
    72deb7307ab7:	movabs r11,0x5b63a3f49650
    72deb7307ac1:	call   r11
    72deb7307ac4:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7307aca:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7307ad0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7307ad6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7307adc:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7307ae2:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7307aec:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7307af6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7307b00:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7307b0a:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7307b12:	mov    QWORD PTR [r12+0x378],0x2
    72deb7307b1e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7307b27:	mov    rdx,rbx
    72deb7307b2a:	shr    rdx,0x10
    72deb7307b2e:	and    edx,0xc000
    72deb7307b34:	mov    rax,rbx
    72deb7307b37:	shr    rax,0x15
    72deb7307b3b:	and    eax,0x100
    72deb7307b40:	xor    eax,0x100
    72deb7307b45:	or     edx,eax
    72deb7307b47:	mov    rax,rbx
    72deb7307b4a:	shr    rax,0x1c
    72deb7307b4e:	and    eax,0x1
    72deb7307b51:	or     edx,eax
    72deb7307b53:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7307b58:	add    rsp,0x8
    72deb7307b5c:	ret
    72deb7307b5d:	nop    DWORD PTR [rax]
    72deb7307b60:	sub    rsp,0x8
    72deb7307b64:	mov    QWORD PTR [r12+0x378],0x3
    72deb7307b70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7307b76:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb7307b7c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7307b82:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7307b88:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7307b8e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7307b98:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7307ba2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7307bac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7307bb6:	push   rdx
    72deb7307bb7:	push   rsi
    72deb7307bb8:	push   r10
    72deb7307bba:	push   r11
    72deb7307bbc:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7307bc1:	mov    r10d,edx
    72deb7307bc4:	and    r10d,0xc000
    72deb7307bcb:	shl    r10d,0x10
    72deb7307bcf:	mov    r11d,edx
    72deb7307bd2:	and    r11d,0x100
    72deb7307bd9:	shl    r11d,0x15
    72deb7307bdd:	or     r10d,r11d
    72deb7307be0:	and    edx,0x1
    72deb7307be3:	shl    edx,0x1c
    72deb7307be6:	or     r10d,edx
    72deb7307be9:	btc    r10,0x1d
    72deb7307bee:	mov    r11d,0xf0000000
    72deb7307bf4:	and    r11,r10
    72deb7307bf7:	movabs rsi,0xffffffff0fffffff
    72deb7307c01:	and    rbx,rsi
    72deb7307c04:	or     rbx,r11
    72deb7307c07:	pop    r11
    72deb7307c09:	pop    r10
    72deb7307c0b:	pop    rsi
    72deb7307c0c:	pop    rdx
    72deb7307c0d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7307c15:	stmxcsr DWORD PTR [r12-0x28]
    72deb7307c1b:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7307c20:	test   r10d,0x3f
    72deb7307c27:	je     0x72deb7307c4c
    72deb7307c2d:	mov    r11d,r10d
    72deb7307c30:	shr    r10d,1
    72deb7307c33:	and    r10d,0x1e
    72deb7307c37:	and    r11d,0x1
    72deb7307c3b:	or     r10d,r11d
    72deb7307c3e:	or     DWORD PTR [r12+0x314],r10d
    72deb7307c46:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7307c4c:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7307c52:	lea    rdi,[rsp+0x110]
    72deb7307c5a:	lea    rsi,[rsp+0xf0]
    72deb7307c62:	lea    rdx,[rsp+0x100]
    72deb7307c6a:	mov    ecx,0x14
    72deb7307c6f:	mov    r8d,0x0
    72deb7307c75:	lea    r9,[r12+0x314]
    72deb7307c7d:	movabs r11,0x5b63a3f49650
    72deb7307c87:	call   r11
    72deb7307c8a:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7307c90:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7307c96:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7307c9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7307ca2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7307ca8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7307cae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7307cb8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7307cc2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7307ccc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7307cd6:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7307cde:	mov    QWORD PTR [r12+0x378],0x2
    72deb7307cea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7307cf3:	mov    rdx,rbx
    72deb7307cf6:	shr    rdx,0x10
    72deb7307cfa:	and    edx,0xc000
    72deb7307d00:	mov    rax,rbx
    72deb7307d03:	shr    rax,0x15
    72deb7307d07:	and    eax,0x100
    72deb7307d0c:	xor    eax,0x100
    72deb7307d11:	or     edx,eax
    72deb7307d13:	mov    rax,rbx
    72deb7307d16:	shr    rax,0x1c
    72deb7307d1a:	and    eax,0x1
    72deb7307d1d:	or     edx,eax
    72deb7307d1f:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7307d24:	add    rsp,0x8
    72deb7307d28:	ret
    72deb7307d29:	nop    DWORD PTR [rax+0x0]
    72deb7307d30:	sub    rsp,0x8
    72deb7307d34:	mov    QWORD PTR [r12+0x378],0x3
    72deb7307d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7307d46:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7307d4c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7307d52:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7307d58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7307d5e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7307d68:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7307d72:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7307d7c:	push   rdx
    72deb7307d7d:	push   rsi
    72deb7307d7e:	push   r10
    72deb7307d80:	push   r11
    72deb7307d82:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7307d87:	mov    r10d,edx
    72deb7307d8a:	and    r10d,0xc000
    72deb7307d91:	shl    r10d,0x10
    72deb7307d95:	mov    r11d,edx
    72deb7307d98:	and    r11d,0x100
    72deb7307d9f:	shl    r11d,0x15
    72deb7307da3:	or     r10d,r11d
    72deb7307da6:	and    edx,0x1
    72deb7307da9:	shl    edx,0x1c
    72deb7307dac:	or     r10d,edx
    72deb7307daf:	btc    r10,0x1d
    72deb7307db4:	mov    r11d,0xf0000000
    72deb7307dba:	and    r11,r10
    72deb7307dbd:	movabs rsi,0xffffffff0fffffff
    72deb7307dc7:	and    rbx,rsi
    72deb7307dca:	or     rbx,r11
    72deb7307dcd:	pop    r11
    72deb7307dcf:	pop    r10
    72deb7307dd1:	pop    rsi
    72deb7307dd2:	pop    rdx
    72deb7307dd3:	mov    QWORD PTR [r12+0x108],rbx
    72deb7307ddb:	stmxcsr DWORD PTR [r12-0x28]
    72deb7307de1:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7307de6:	test   r10d,0x3f
    72deb7307ded:	je     0x72deb7307e12
    72deb7307df3:	mov    r11d,r10d
    72deb7307df6:	shr    r10d,1
    72deb7307df9:	and    r10d,0x1e
    72deb7307dfd:	and    r11d,0x1
    72deb7307e01:	or     r10d,r11d
    72deb7307e04:	or     DWORD PTR [r12+0x314],r10d
    72deb7307e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7307e12:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7307e18:	lea    rdi,[rsp+0x110]
    72deb7307e20:	lea    rsi,[rsp+0xf0]
    72deb7307e28:	lea    rdx,[rsp+0x100]
    72deb7307e30:	mov    ecx,0x56
    72deb7307e35:	mov    r8d,0x0
    72deb7307e3b:	lea    r9,[r12+0x314]
    72deb7307e43:	movabs r11,0x5b63a3f49650
    72deb7307e4d:	call   r11
    72deb7307e50:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7307e56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7307e5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7307e62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7307e68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7307e6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7307e74:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7307e7e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7307e88:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7307e92:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7307e9a:	mov    QWORD PTR [r12+0x378],0x2
    72deb7307ea6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7307eaf:	mov    rdx,rbx
    72deb7307eb2:	shr    rdx,0x10
    72deb7307eb6:	and    edx,0xc000
    72deb7307ebc:	mov    rax,rbx
    72deb7307ebf:	shr    rax,0x15
    72deb7307ec3:	and    eax,0x100
    72deb7307ec8:	xor    eax,0x100
    72deb7307ecd:	or     edx,eax
    72deb7307ecf:	mov    rax,rbx
    72deb7307ed2:	shr    rax,0x1c
    72deb7307ed6:	and    eax,0x1
    72deb7307ed9:	or     edx,eax
    72deb7307edb:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7307ee0:	add    rsp,0x8
    72deb7307ee4:	ret
    72deb7307ee5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7307ef0:	sub    rsp,0x8
    72deb7307ef4:	mov    QWORD PTR [r12+0x378],0x3
    72deb7307f00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7307f06:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb7307f0c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7307f12:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7307f18:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7307f1e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7307f28:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7307f32:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7307f3c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7307f46:	push   rdx
    72deb7307f47:	push   rsi
    72deb7307f48:	push   r10
    72deb7307f4a:	push   r11
    72deb7307f4c:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7307f51:	mov    r10d,edx
    72deb7307f54:	and    r10d,0xc000
    72deb7307f5b:	shl    r10d,0x10
    72deb7307f5f:	mov    r11d,edx
    72deb7307f62:	and    r11d,0x100
    72deb7307f69:	shl    r11d,0x15
    72deb7307f6d:	or     r10d,r11d
    72deb7307f70:	and    edx,0x1
    72deb7307f73:	shl    edx,0x1c
    72deb7307f76:	or     r10d,edx
    72deb7307f79:	btc    r10,0x1d
    72deb7307f7e:	mov    r11d,0xf0000000
    72deb7307f84:	and    r11,r10
    72deb7307f87:	movabs rsi,0xffffffff0fffffff
    72deb7307f91:	and    rbx,rsi
    72deb7307f94:	or     rbx,r11
    72deb7307f97:	pop    r11
    72deb7307f99:	pop    r10
    72deb7307f9b:	pop    rsi
    72deb7307f9c:	pop    rdx
    72deb7307f9d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7307fa5:	stmxcsr DWORD PTR [r12-0x28]
    72deb7307fab:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7307fb0:	test   r10d,0x3f
    72deb7307fb7:	je     0x72deb7307fdc
    72deb7307fbd:	mov    r11d,r10d
    72deb7307fc0:	shr    r10d,1
    72deb7307fc3:	and    r10d,0x1e
    72deb7307fc7:	and    r11d,0x1
    72deb7307fcb:	or     r10d,r11d
    72deb7307fce:	or     DWORD PTR [r12+0x314],r10d
    72deb7307fd6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7307fdc:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7307fe2:	lea    rdi,[rsp+0x110]
    72deb7307fea:	lea    rsi,[rsp+0xf0]
    72deb7307ff2:	lea    rdx,[rsp+0x100]
    72deb7307ffa:	mov    ecx,0x56
    72deb7307fff:	mov    r8d,0x0
    72deb7308005:	lea    r9,[r12+0x314]
    72deb730800d:	movabs r11,0x5b63a3f49650
    72deb7308017:	call   r11
    72deb730801a:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7308020:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7308026:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb730802c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7308032:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7308038:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb730803e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7308048:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7308052:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb730805c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7308066:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730806e:	mov    QWORD PTR [r12+0x378],0x2
    72deb730807a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7308083:	mov    rdx,rbx
    72deb7308086:	shr    rdx,0x10
    72deb730808a:	and    edx,0xc000
    72deb7308090:	mov    rax,rbx
    72deb7308093:	shr    rax,0x15
    72deb7308097:	and    eax,0x100
    72deb730809c:	xor    eax,0x100
    72deb73080a1:	or     edx,eax
    72deb73080a3:	mov    rax,rbx
    72deb73080a6:	shr    rax,0x1c
    72deb73080aa:	and    eax,0x1
    72deb73080ad:	or     edx,eax
    72deb73080af:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73080b4:	add    rsp,0x8
    72deb73080b8:	ret
    72deb73080b9:	nop    DWORD PTR [rax+0x0]
    72deb73080c0:	sub    rsp,0x8
    72deb73080c4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73080d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73080d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73080dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73080e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73080e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73080ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb73080f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7308102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb730810c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7308116:	push   rdx
    72deb7308117:	push   rsi
    72deb7308118:	push   r10
    72deb730811a:	push   r11
    72deb730811c:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7308121:	mov    r10d,edx
    72deb7308124:	and    r10d,0xc000
    72deb730812b:	shl    r10d,0x10
    72deb730812f:	mov    r11d,edx
    72deb7308132:	and    r11d,0x100
    72deb7308139:	shl    r11d,0x15
    72deb730813d:	or     r10d,r11d
    72deb7308140:	and    edx,0x1
    72deb7308143:	shl    edx,0x1c
    72deb7308146:	or     r10d,edx
    72deb7308149:	btc    r10,0x1d
    72deb730814e:	mov    r11d,0xf0000000
    72deb7308154:	and    r11,r10
    72deb7308157:	movabs rsi,0xffffffff0fffffff
    72deb7308161:	and    rbx,rsi
    72deb7308164:	or     rbx,r11
    72deb7308167:	pop    r11
    72deb7308169:	pop    r10
    72deb730816b:	pop    rsi
    72deb730816c:	pop    rdx
    72deb730816d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7308175:	stmxcsr DWORD PTR [r12-0x28]
    72deb730817b:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7308180:	test   r10d,0x3f
    72deb7308187:	je     0x72deb73081ac
    72deb730818d:	mov    r11d,r10d
    72deb7308190:	shr    r10d,1
    72deb7308193:	and    r10d,0x1e
    72deb7308197:	and    r11d,0x1
    72deb730819b:	or     r10d,r11d
    72deb730819e:	or     DWORD PTR [r12+0x314],r10d
    72deb73081a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73081ac:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73081b2:	lea    rdi,[rsp+0x110]
    72deb73081ba:	lea    rsi,[rsp+0xf0]
    72deb73081c2:	lea    rdx,[rsp+0x100]
    72deb73081ca:	mov    ecx,0x14
    72deb73081cf:	mov    r8d,0x0
    72deb73081d5:	lea    r9,[r12+0x314]
    72deb73081dd:	movabs r11,0x5b63a3f49650
    72deb73081e7:	call   r11
    72deb73081ea:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73081f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73081f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73081fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7308202:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7308208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb730820e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7308218:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7308222:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb730822c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7308236:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730823e:	mov    QWORD PTR [r12+0x378],0x2
    72deb730824a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7308253:	mov    rdx,rbx
    72deb7308256:	shr    rdx,0x10
    72deb730825a:	and    edx,0xc000
    72deb7308260:	mov    rax,rbx
    72deb7308263:	shr    rax,0x15
    72deb7308267:	and    eax,0x100
    72deb730826c:	xor    eax,0x100
    72deb7308271:	or     edx,eax
    72deb7308273:	mov    rax,rbx
    72deb7308276:	shr    rax,0x1c
    72deb730827a:	and    eax,0x1
    72deb730827d:	or     edx,eax
    72deb730827f:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7308284:	add    rsp,0x8
    72deb7308288:	ret
    72deb7308289:	nop    DWORD PTR [rax+0x0]
    72deb7308290:	sub    rsp,0x8
    72deb7308294:	mov    QWORD PTR [r12+0x378],0x3
    72deb73082a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73082a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73082ac:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73082b2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73082b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73082be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb73082c8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb73082d2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73082dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb73082e6:	push   rdx
    72deb73082e7:	push   rsi
    72deb73082e8:	push   r10
    72deb73082ea:	push   r11
    72deb73082ec:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb73082f1:	mov    r10d,edx
    72deb73082f4:	and    r10d,0xc000
    72deb73082fb:	shl    r10d,0x10
    72deb73082ff:	mov    r11d,edx
    72deb7308302:	and    r11d,0x100
    72deb7308309:	shl    r11d,0x15
    72deb730830d:	or     r10d,r11d
    72deb7308310:	and    edx,0x1
    72deb7308313:	shl    edx,0x1c
    72deb7308316:	or     r10d,edx
    72deb7308319:	btc    r10,0x1d
    72deb730831e:	mov    r11d,0xf0000000
    72deb7308324:	and    r11,r10
    72deb7308327:	movabs rsi,0xffffffff0fffffff
    72deb7308331:	and    rbx,rsi
    72deb7308334:	or     rbx,r11
    72deb7308337:	pop    r11
    72deb7308339:	pop    r10
    72deb730833b:	pop    rsi
    72deb730833c:	pop    rdx
    72deb730833d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7308345:	stmxcsr DWORD PTR [r12-0x28]
    72deb730834b:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7308350:	test   r10d,0x3f
    72deb7308357:	je     0x72deb730837c
    72deb730835d:	mov    r11d,r10d
    72deb7308360:	shr    r10d,1
    72deb7308363:	and    r10d,0x1e
    72deb7308367:	and    r11d,0x1
    72deb730836b:	or     r10d,r11d
    72deb730836e:	or     DWORD PTR [r12+0x314],r10d
    72deb7308376:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb730837c:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7308382:	lea    rdi,[rsp+0x110]
    72deb730838a:	lea    rsi,[rsp+0xf0]
    72deb7308392:	lea    rdx,[rsp+0x100]
    72deb730839a:	mov    ecx,0x56
    72deb730839f:	mov    r8d,0x0
    72deb73083a5:	lea    r9,[r12+0x314]
    72deb73083ad:	movabs r11,0x5b63a3f49650
    72deb73083b7:	call   r11
    72deb73083ba:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73083c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73083c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73083cc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb73083d2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb73083d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb73083de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb73083e8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb73083f2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb73083fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7308406:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730840e:	mov    QWORD PTR [r12+0x378],0x2
    72deb730841a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7308423:	mov    rdx,rbx
    72deb7308426:	shr    rdx,0x10
    72deb730842a:	and    edx,0xc000
    72deb7308430:	mov    rax,rbx
    72deb7308433:	shr    rax,0x15
    72deb7308437:	and    eax,0x100
    72deb730843c:	xor    eax,0x100
    72deb7308441:	or     edx,eax
    72deb7308443:	mov    rax,rbx
    72deb7308446:	shr    rax,0x1c
    72deb730844a:	and    eax,0x1
    72deb730844d:	or     edx,eax
    72deb730844f:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7308454:	add    rsp,0x8
    72deb7308458:	ret
    72deb7308459:	nop    DWORD PTR [rax+0x0]
    72deb7308460:	sub    rsp,0x8
    72deb7308464:	mov    QWORD PTR [r12+0x378],0x3
    72deb7308470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7308476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb730847c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7308482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7308488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb730848e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7308498:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb73084a2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73084ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb73084b6:	push   rdx
    72deb73084b7:	push   rsi
    72deb73084b8:	push   r10
    72deb73084ba:	push   r11
    72deb73084bc:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb73084c1:	mov    r10d,edx
    72deb73084c4:	and    r10d,0xc000
    72deb73084cb:	shl    r10d,0x10
    72deb73084cf:	mov    r11d,edx
    72deb73084d2:	and    r11d,0x100
    72deb73084d9:	shl    r11d,0x15
    72deb73084dd:	or     r10d,r11d
    72deb73084e0:	and    edx,0x1
    72deb73084e3:	shl    edx,0x1c
    72deb73084e6:	or     r10d,edx
    72deb73084e9:	btc    r10,0x1d
    72deb73084ee:	mov    r11d,0xf0000000
    72deb73084f4:	and    r11,r10
    72deb73084f7:	movabs rsi,0xffffffff0fffffff
    72deb7308501:	and    rbx,rsi
    72deb7308504:	or     rbx,r11
    72deb7308507:	pop    r11
    72deb7308509:	pop    r10
    72deb730850b:	pop    rsi
    72deb730850c:	pop    rdx
    72deb730850d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7308515:	stmxcsr DWORD PTR [r12-0x28]
    72deb730851b:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7308520:	test   r10d,0x3f
    72deb7308527:	je     0x72deb730854c
    72deb730852d:	mov    r11d,r10d
    72deb7308530:	shr    r10d,1
    72deb7308533:	and    r10d,0x1e
    72deb7308537:	and    r11d,0x1
    72deb730853b:	or     r10d,r11d
    72deb730853e:	or     DWORD PTR [r12+0x314],r10d
    72deb7308546:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb730854c:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7308552:	lea    rdi,[rsp+0x110]
    72deb730855a:	lea    rsi,[rsp+0xf0]
    72deb7308562:	lea    rdx,[rsp+0x100]
    72deb730856a:	mov    ecx,0x14
    72deb730856f:	mov    r8d,0x0
    72deb7308575:	lea    r9,[r12+0x314]
    72deb730857d:	movabs r11,0x5b63a3f49650
    72deb7308587:	call   r11
    72deb730858a:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7308590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7308596:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb730859c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb73085a2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb73085a8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb73085ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb73085b8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb73085c2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb73085cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb73085d6:	mov    rbx,QWORD PTR [r12+0x108]
    72deb73085de:	mov    QWORD PTR [r12+0x378],0x2
    72deb73085ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb73085f3:	mov    rdx,rbx
    72deb73085f6:	shr    rdx,0x10
    72deb73085fa:	and    edx,0xc000
    72deb7308600:	mov    rax,rbx
    72deb7308603:	shr    rax,0x15
    72deb7308607:	and    eax,0x100
    72deb730860c:	xor    eax,0x100
    72deb7308611:	or     edx,eax
    72deb7308613:	mov    rax,rbx
    72deb7308616:	shr    rax,0x1c
    72deb730861a:	and    eax,0x1
    72deb730861d:	or     edx,eax
    72deb730861f:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7308624:	add    rsp,0x8
    72deb7308628:	ret
    72deb7308629:	nop    DWORD PTR [rax+0x0]
    72deb7308630:	sub    rsp,0x8
    72deb7308634:	mov    QWORD PTR [r12+0x378],0x3
    72deb7308640:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb7308646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb730864c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7308652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7308658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb730865e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7308668:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7308672:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb730867c:	push   rdx
    72deb730867d:	push   rsi
    72deb730867e:	push   r10
    72deb7308680:	push   r11
    72deb7308682:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7308687:	mov    r10d,edx
    72deb730868a:	and    r10d,0xc000
    72deb7308691:	shl    r10d,0x10
    72deb7308695:	mov    r11d,edx
    72deb7308698:	and    r11d,0x100
    72deb730869f:	shl    r11d,0x15
    72deb73086a3:	or     r10d,r11d
    72deb73086a6:	and    edx,0x1
    72deb73086a9:	shl    edx,0x1c
    72deb73086ac:	or     r10d,edx
    72deb73086af:	btc    r10,0x1d
    72deb73086b4:	mov    r11d,0xf0000000
    72deb73086ba:	and    r11,r10
    72deb73086bd:	movabs rsi,0xffffffff0fffffff
    72deb73086c7:	and    rbx,rsi
    72deb73086ca:	or     rbx,r11
    72deb73086cd:	pop    r11
    72deb73086cf:	pop    r10
    72deb73086d1:	pop    rsi
    72deb73086d2:	pop    rdx
    72deb73086d3:	mov    QWORD PTR [r12+0x108],rbx
    72deb73086db:	stmxcsr DWORD PTR [r12-0x28]
    72deb73086e1:	mov    r10d,DWORD PTR [r12-0x28]
    72deb73086e6:	test   r10d,0x3f
    72deb73086ed:	je     0x72deb7308712
    72deb73086f3:	mov    r11d,r10d
    72deb73086f6:	shr    r10d,1
    72deb73086f9:	and    r10d,0x1e
    72deb73086fd:	and    r11d,0x1
    72deb7308701:	or     r10d,r11d
    72deb7308704:	or     DWORD PTR [r12+0x314],r10d
    72deb730870c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7308712:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7308718:	lea    rdi,[rsp+0x110]
    72deb7308720:	lea    rsi,[rsp+0xf0]
    72deb7308728:	lea    rdx,[rsp+0x100]
    72deb7308730:	mov    ecx,0x14
    72deb7308735:	mov    r8d,0x0
    72deb730873b:	lea    r9,[r12+0x314]
    72deb7308743:	movabs r11,0x5b63a3f49650
    72deb730874d:	call   r11
    72deb7308750:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7308756:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb730875c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7308762:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7308768:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb730876e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7308774:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb730877e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7308788:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7308792:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730879a:	mov    QWORD PTR [r12+0x378],0x2
    72deb73087a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb73087af:	mov    rdx,rbx
    72deb73087b2:	shr    rdx,0x10
    72deb73087b6:	and    edx,0xc000
    72deb73087bc:	mov    rax,rbx
    72deb73087bf:	shr    rax,0x15
    72deb73087c3:	and    eax,0x100
    72deb73087c8:	xor    eax,0x100
    72deb73087cd:	or     edx,eax
    72deb73087cf:	mov    rax,rbx
    72deb73087d2:	shr    rax,0x1c
    72deb73087d6:	and    eax,0x1
    72deb73087d9:	or     edx,eax
    72deb73087db:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73087e0:	add    rsp,0x8
    72deb73087e4:	ret
    72deb73087e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb73087f0:	sub    rsp,0x8
    72deb73087f4:	mov    QWORD PTR [r12+0x378],0x3
    72deb7308800:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7308806:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb730880c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7308812:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7308818:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb730881e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7308828:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7308832:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb730883c:	push   rdx
    72deb730883d:	push   rsi
    72deb730883e:	push   r10
    72deb7308840:	push   r11
    72deb7308842:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7308847:	mov    r10d,edx
    72deb730884a:	and    r10d,0xc000
    72deb7308851:	shl    r10d,0x10
    72deb7308855:	mov    r11d,edx
    72deb7308858:	and    r11d,0x100
    72deb730885f:	shl    r11d,0x15
    72deb7308863:	or     r10d,r11d
    72deb7308866:	and    edx,0x1
    72deb7308869:	shl    edx,0x1c
    72deb730886c:	or     r10d,edx
    72deb730886f:	btc    r10,0x1d
    72deb7308874:	mov    r11d,0xf0000000
    72deb730887a:	and    r11,r10
    72deb730887d:	movabs rsi,0xffffffff0fffffff
    72deb7308887:	and    rbx,rsi
    72deb730888a:	or     rbx,r11
    72deb730888d:	pop    r11
    72deb730888f:	pop    r10
    72deb7308891:	pop    rsi
    72deb7308892:	pop    rdx
    72deb7308893:	mov    QWORD PTR [r12+0x108],rbx
    72deb730889b:	stmxcsr DWORD PTR [r12-0x28]
    72deb73088a1:	mov    r10d,DWORD PTR [r12-0x28]
    72deb73088a6:	test   r10d,0x3f
    72deb73088ad:	je     0x72deb73088d2
    72deb73088b3:	mov    r11d,r10d
    72deb73088b6:	shr    r10d,1
    72deb73088b9:	and    r10d,0x1e
    72deb73088bd:	and    r11d,0x1
    72deb73088c1:	or     r10d,r11d
    72deb73088c4:	or     DWORD PTR [r12+0x314],r10d
    72deb73088cc:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73088d2:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73088d8:	lea    rdi,[rsp+0x110]
    72deb73088e0:	lea    rsi,[rsp+0xf0]
    72deb73088e8:	lea    rdx,[rsp+0x100]
    72deb73088f0:	mov    ecx,0x14
    72deb73088f5:	mov    r8d,0x0
    72deb73088fb:	lea    r9,[r12+0x314]
    72deb7308903:	movabs r11,0x5b63a3f49650
    72deb730890d:	call   r11
    72deb7308910:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7308916:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb730891c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7308922:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7308928:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb730892e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7308934:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb730893e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7308948:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7308952:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730895a:	mov    QWORD PTR [r12+0x378],0x2
    72deb7308966:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb730896f:	mov    rdx,rbx
    72deb7308972:	shr    rdx,0x10
    72deb7308976:	and    edx,0xc000
    72deb730897c:	mov    rax,rbx
    72deb730897f:	shr    rax,0x15
    72deb7308983:	and    eax,0x100
    72deb7308988:	xor    eax,0x100
    72deb730898d:	or     edx,eax
    72deb730898f:	mov    rax,rbx
    72deb7308992:	shr    rax,0x1c
    72deb7308996:	and    eax,0x1
    72deb7308999:	or     edx,eax
    72deb730899b:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73089a0:	add    rsp,0x8
    72deb73089a4:	ret
    72deb73089a5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb73089b0:	sub    rsp,0x8
    72deb73089b4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73089c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73089c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73089cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73089d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73089d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73089de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73089e4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73089ee:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb73089f8:	push   rdx
    72deb73089f9:	push   rsi
    72deb73089fa:	push   r10
    72deb73089fc:	push   r11
    72deb73089fe:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7308a03:	mov    r10d,edx
    72deb7308a06:	and    r10d,0xc000
    72deb7308a0d:	shl    r10d,0x10
    72deb7308a11:	mov    r11d,edx
    72deb7308a14:	and    r11d,0x100
    72deb7308a1b:	shl    r11d,0x15
    72deb7308a1f:	or     r10d,r11d
    72deb7308a22:	and    edx,0x1
    72deb7308a25:	shl    edx,0x1c
    72deb7308a28:	or     r10d,edx
    72deb7308a2b:	btc    r10,0x1d
    72deb7308a30:	mov    r11d,0xf0000000
    72deb7308a36:	and    r11,r10
    72deb7308a39:	movabs rsi,0xffffffff0fffffff
    72deb7308a43:	and    rbx,rsi
    72deb7308a46:	or     rbx,r11
    72deb7308a49:	pop    r11
    72deb7308a4b:	pop    r10
    72deb7308a4d:	pop    rsi
    72deb7308a4e:	pop    rdx
    72deb7308a4f:	mov    QWORD PTR [r12+0x108],rbx
    72deb7308a57:	stmxcsr DWORD PTR [r12-0x28]
    72deb7308a5d:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7308a62:	test   r10d,0x3f
    72deb7308a69:	je     0x72deb7308a8e
    72deb7308a6f:	mov    r11d,r10d
    72deb7308a72:	shr    r10d,1
    72deb7308a75:	and    r10d,0x1e
    72deb7308a79:	and    r11d,0x1
    72deb7308a7d:	or     r10d,r11d
    72deb7308a80:	or     DWORD PTR [r12+0x314],r10d
    72deb7308a88:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7308a8e:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7308a94:	lea    rdi,[rsp+0x110]
    72deb7308a9c:	lea    rsi,[rsp+0xf0]
    72deb7308aa4:	lea    rdx,[rsp+0x100]
    72deb7308aac:	mov    ecx,0x56
    72deb7308ab1:	mov    r8d,0x0
    72deb7308ab7:	lea    r9,[r12+0x314]
    72deb7308abf:	movabs r11,0x5b63a3f49650
    72deb7308ac9:	call   r11
    72deb7308acc:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7308ad2:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7308ad8:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7308ade:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7308ae4:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7308aea:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7308af0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7308af6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7308b00:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7308b0a:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7308b12:	mov    QWORD PTR [r12+0x378],0x2
    72deb7308b1e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7308b27:	mov    rdx,rbx
    72deb7308b2a:	shr    rdx,0x10
    72deb7308b2e:	and    edx,0xc000
    72deb7308b34:	mov    rax,rbx
    72deb7308b37:	shr    rax,0x15
    72deb7308b3b:	and    eax,0x100
    72deb7308b40:	xor    eax,0x100
    72deb7308b45:	or     edx,eax
    72deb7308b47:	mov    rax,rbx
    72deb7308b4a:	shr    rax,0x1c
    72deb7308b4e:	and    eax,0x1
    72deb7308b51:	or     edx,eax
    72deb7308b53:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7308b58:	add    rsp,0x8
    72deb7308b5c:	ret
    72deb7308b5d:	nop    DWORD PTR [rax]
    72deb7308b60:	sub    rsp,0x8
    72deb7308b64:	mov    QWORD PTR [r12+0x378],0x3
    72deb7308b70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7308b76:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb7308b7c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7308b82:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7308b88:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7308b8e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7308b98:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7308ba2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7308bac:	push   rdx
    72deb7308bad:	push   rsi
    72deb7308bae:	push   r10
    72deb7308bb0:	push   r11
    72deb7308bb2:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7308bb7:	mov    r10d,edx
    72deb7308bba:	and    r10d,0xc000
    72deb7308bc1:	shl    r10d,0x10
    72deb7308bc5:	mov    r11d,edx
    72deb7308bc8:	and    r11d,0x100
    72deb7308bcf:	shl    r11d,0x15
    72deb7308bd3:	or     r10d,r11d
    72deb7308bd6:	and    edx,0x1
    72deb7308bd9:	shl    edx,0x1c
    72deb7308bdc:	or     r10d,edx
    72deb7308bdf:	btc    r10,0x1d
    72deb7308be4:	mov    r11d,0xf0000000
    72deb7308bea:	and    r11,r10
    72deb7308bed:	movabs rsi,0xffffffff0fffffff
    72deb7308bf7:	and    rbx,rsi
    72deb7308bfa:	or     rbx,r11
    72deb7308bfd:	pop    r11
    72deb7308bff:	pop    r10
    72deb7308c01:	pop    rsi
    72deb7308c02:	pop    rdx
    72deb7308c03:	mov    QWORD PTR [r12+0x108],rbx
    72deb7308c0b:	stmxcsr DWORD PTR [r12-0x28]
    72deb7308c11:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7308c16:	test   r10d,0x3f
    72deb7308c1d:	je     0x72deb7308c42
    72deb7308c23:	mov    r11d,r10d
    72deb7308c26:	shr    r10d,1
    72deb7308c29:	and    r10d,0x1e
    72deb7308c2d:	and    r11d,0x1
    72deb7308c31:	or     r10d,r11d
    72deb7308c34:	or     DWORD PTR [r12+0x314],r10d
    72deb7308c3c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7308c42:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7308c48:	lea    rdi,[rsp+0x110]
    72deb7308c50:	lea    rsi,[rsp+0xf0]
    72deb7308c58:	lea    rdx,[rsp+0x100]
    72deb7308c60:	mov    ecx,0x56
    72deb7308c65:	mov    r8d,0x0
    72deb7308c6b:	lea    r9,[r12+0x314]
    72deb7308c73:	movabs r11,0x5b63a3f49650
    72deb7308c7d:	call   r11
    72deb7308c80:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7308c86:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7308c8c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7308c92:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7308c98:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7308c9e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7308ca4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7308cae:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7308cb8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7308cc2:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7308cca:	mov    QWORD PTR [r12+0x378],0x2
    72deb7308cd6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7308cdf:	mov    rdx,rbx
    72deb7308ce2:	shr    rdx,0x10
    72deb7308ce6:	and    edx,0xc000
    72deb7308cec:	mov    rax,rbx
    72deb7308cef:	shr    rax,0x15
    72deb7308cf3:	and    eax,0x100
    72deb7308cf8:	xor    eax,0x100
    72deb7308cfd:	or     edx,eax
    72deb7308cff:	mov    rax,rbx
    72deb7308d02:	shr    rax,0x1c
    72deb7308d06:	and    eax,0x1
    72deb7308d09:	or     edx,eax
    72deb7308d0b:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7308d10:	add    rsp,0x8
    72deb7308d14:	ret
    72deb7308d15:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7308d20:	sub    rsp,0x8
    72deb7308d24:	mov    QWORD PTR [r12+0x378],0x3
    72deb7308d30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7308d36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb7308d3c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7308d42:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7308d48:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7308d4e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7308d54:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7308d5e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7308d68:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72deb7308d72:	push   rdx
    72deb7308d73:	push   rsi
    72deb7308d74:	push   r10
    72deb7308d76:	push   r11
    72deb7308d78:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7308d7d:	mov    r10d,edx
    72deb7308d80:	and    r10d,0xc000
    72deb7308d87:	shl    r10d,0x10
    72deb7308d8b:	mov    r11d,edx
    72deb7308d8e:	and    r11d,0x100
    72deb7308d95:	shl    r11d,0x15
    72deb7308d99:	or     r10d,r11d
    72deb7308d9c:	and    edx,0x1
    72deb7308d9f:	shl    edx,0x1c
    72deb7308da2:	or     r10d,edx
    72deb7308da5:	btc    r10,0x1d
    72deb7308daa:	mov    r11d,0xf0000000
    72deb7308db0:	and    r11,r10
    72deb7308db3:	movabs rsi,0xffffffff0fffffff
    72deb7308dbd:	and    rbx,rsi
    72deb7308dc0:	or     rbx,r11
    72deb7308dc3:	pop    r11
    72deb7308dc5:	pop    r10
    72deb7308dc7:	pop    rsi
    72deb7308dc8:	pop    rdx
    72deb7308dc9:	mov    QWORD PTR [r12+0x108],rbx
    72deb7308dd1:	stmxcsr DWORD PTR [r12-0x28]
    72deb7308dd7:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7308ddc:	test   r10d,0x3f
    72deb7308de3:	je     0x72deb7308e08
    72deb7308de9:	mov    r11d,r10d
    72deb7308dec:	shr    r10d,1
    72deb7308def:	and    r10d,0x1e
    72deb7308df3:	and    r11d,0x1
    72deb7308df7:	or     r10d,r11d
    72deb7308dfa:	or     DWORD PTR [r12+0x314],r10d
    72deb7308e02:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7308e08:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7308e0e:	lea    rdi,[rsp+0x110]
    72deb7308e16:	lea    rsi,[rsp+0xf0]
    72deb7308e1e:	lea    rdx,[rsp+0x100]
    72deb7308e26:	mov    ecx,0x14
    72deb7308e2b:	mov    r8d,0x0
    72deb7308e31:	lea    r9,[r12+0x314]
    72deb7308e39:	movabs r11,0x5b63a3f49650
    72deb7308e43:	call   r11
    72deb7308e46:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7308e4c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7308e52:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7308e58:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb7308e5e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7308e64:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7308e6a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7308e70:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7308e7a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7308e84:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72deb7308e8e:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7308e96:	mov    QWORD PTR [r12+0x378],0x2
    72deb7308ea2:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7308eab:	mov    rdx,rbx
    72deb7308eae:	shr    rdx,0x10
    72deb7308eb2:	and    edx,0xc000
    72deb7308eb8:	mov    rax,rbx
    72deb7308ebb:	shr    rax,0x15
    72deb7308ebf:	and    eax,0x100
    72deb7308ec4:	xor    eax,0x100
    72deb7308ec9:	or     edx,eax
    72deb7308ecb:	mov    rax,rbx
    72deb7308ece:	shr    rax,0x1c
    72deb7308ed2:	and    eax,0x1
    72deb7308ed5:	or     edx,eax
    72deb7308ed7:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7308edc:	add    rsp,0x8
    72deb7308ee0:	ret
    72deb7308ee1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7308ef0:	sub    rsp,0x8
    72deb7308ef4:	mov    QWORD PTR [r12+0x378],0x3
    72deb7308f00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7308f06:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7308f0c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7308f12:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb7308f18:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb7308f1e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb7308f28:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7308f32:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7308f3c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7308f46:	push   rdx
    72deb7308f47:	push   rsi
    72deb7308f48:	push   r10
    72deb7308f4a:	push   r11
    72deb7308f4c:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7308f51:	mov    r10d,edx
    72deb7308f54:	and    r10d,0xc000
    72deb7308f5b:	shl    r10d,0x10
    72deb7308f5f:	mov    r11d,edx
    72deb7308f62:	and    r11d,0x100
    72deb7308f69:	shl    r11d,0x15
    72deb7308f6d:	or     r10d,r11d
    72deb7308f70:	and    edx,0x1
    72deb7308f73:	shl    edx,0x1c
    72deb7308f76:	or     r10d,edx
    72deb7308f79:	btc    r10,0x1d
    72deb7308f7e:	mov    r11d,0xf0000000
    72deb7308f84:	and    r11,r10
    72deb7308f87:	movabs rsi,0xffffffff0fffffff
    72deb7308f91:	and    rbx,rsi
    72deb7308f94:	or     rbx,r11
    72deb7308f97:	pop    r11
    72deb7308f99:	pop    r10
    72deb7308f9b:	pop    rsi
    72deb7308f9c:	pop    rdx
    72deb7308f9d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7308fa5:	stmxcsr DWORD PTR [r12-0x28]
    72deb7308fab:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7308fb0:	test   r10d,0x3f
    72deb7308fb7:	je     0x72deb7308fdc
    72deb7308fbd:	mov    r11d,r10d
    72deb7308fc0:	shr    r10d,1
    72deb7308fc3:	and    r10d,0x1e
    72deb7308fc7:	and    r11d,0x1
    72deb7308fcb:	or     r10d,r11d
    72deb7308fce:	or     DWORD PTR [r12+0x314],r10d
    72deb7308fd6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7308fdc:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7308fe2:	lea    rdi,[rsp+0x110]
    72deb7308fea:	lea    rsi,[rsp+0xf0]
    72deb7308ff2:	lea    rdx,[rsp+0x100]
    72deb7308ffa:	mov    ecx,0x56
    72deb7308fff:	mov    r8d,0x0
    72deb7309005:	lea    r9,[r12+0x314]
    72deb730900d:	movabs r11,0x5b63a3f49650
    72deb7309017:	call   r11
    72deb730901a:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7309020:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7309026:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb730902c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7309032:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb7309038:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb730903e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb7309048:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7309052:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb730905c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7309066:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730906e:	mov    QWORD PTR [r12+0x378],0x2
    72deb730907a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7309083:	mov    rdx,rbx
    72deb7309086:	shr    rdx,0x10
    72deb730908a:	and    edx,0xc000
    72deb7309090:	mov    rax,rbx
    72deb7309093:	shr    rax,0x15
    72deb7309097:	and    eax,0x100
    72deb730909c:	xor    eax,0x100
    72deb73090a1:	or     edx,eax
    72deb73090a3:	mov    rax,rbx
    72deb73090a6:	shr    rax,0x1c
    72deb73090aa:	and    eax,0x1
    72deb73090ad:	or     edx,eax
    72deb73090af:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73090b4:	add    rsp,0x8
    72deb73090b8:	ret
    72deb73090b9:	nop    DWORD PTR [rax+0x0]
    72deb73090c0:	sub    rsp,0x8
    72deb73090c4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73090d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73090d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73090dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73090e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb73090e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73090ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73090f4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72deb73090fe:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb7309108:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7309112:	push   rdx
    72deb7309113:	push   rsi
    72deb7309114:	push   r10
    72deb7309116:	push   r11
    72deb7309118:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb730911d:	mov    r10d,edx
    72deb7309120:	and    r10d,0xc000
    72deb7309127:	shl    r10d,0x10
    72deb730912b:	mov    r11d,edx
    72deb730912e:	and    r11d,0x100
    72deb7309135:	shl    r11d,0x15
    72deb7309139:	or     r10d,r11d
    72deb730913c:	and    edx,0x1
    72deb730913f:	shl    edx,0x1c
    72deb7309142:	or     r10d,edx
    72deb7309145:	btc    r10,0x1d
    72deb730914a:	mov    r11d,0xf0000000
    72deb7309150:	and    r11,r10
    72deb7309153:	movabs rsi,0xffffffff0fffffff
    72deb730915d:	and    rbx,rsi
    72deb7309160:	or     rbx,r11
    72deb7309163:	pop    r11
    72deb7309165:	pop    r10
    72deb7309167:	pop    rsi
    72deb7309168:	pop    rdx
    72deb7309169:	mov    QWORD PTR [r12+0x108],rbx
    72deb7309171:	stmxcsr DWORD PTR [r12-0x28]
    72deb7309177:	mov    r10d,DWORD PTR [r12-0x28]
    72deb730917c:	test   r10d,0x3f
    72deb7309183:	je     0x72deb73091a8
    72deb7309189:	mov    r11d,r10d
    72deb730918c:	shr    r10d,1
    72deb730918f:	and    r10d,0x1e
    72deb7309193:	and    r11d,0x1
    72deb7309197:	or     r10d,r11d
    72deb730919a:	or     DWORD PTR [r12+0x314],r10d
    72deb73091a2:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73091a8:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73091ae:	lea    rdi,[rsp+0x110]
    72deb73091b6:	lea    rsi,[rsp+0xf0]
    72deb73091be:	lea    rdx,[rsp+0x100]
    72deb73091c6:	mov    ecx,0x56
    72deb73091cb:	mov    r8d,0x0
    72deb73091d1:	lea    r9,[r12+0x314]
    72deb73091d9:	movabs r11,0x5b63a3f49650
    72deb73091e3:	call   r11
    72deb73091e6:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73091ec:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73091f2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73091f8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb73091fe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7309204:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb730920a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb7309210:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72deb730921a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7309224:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb730922e:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7309236:	mov    QWORD PTR [r12+0x378],0x2
    72deb7309242:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb730924b:	mov    rdx,rbx
    72deb730924e:	shr    rdx,0x10
    72deb7309252:	and    edx,0xc000
    72deb7309258:	mov    rax,rbx
    72deb730925b:	shr    rax,0x15
    72deb730925f:	and    eax,0x100
    72deb7309264:	xor    eax,0x100
    72deb7309269:	or     edx,eax
    72deb730926b:	mov    rax,rbx
    72deb730926e:	shr    rax,0x1c
    72deb7309272:	and    eax,0x1
    72deb7309275:	or     edx,eax
    72deb7309277:	mov    QWORD PTR [rsp+0x10],rdx
    72deb730927c:	add    rsp,0x8
    72deb7309280:	ret
    72deb7309281:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb7309290:	sub    rsp,0x8
    72deb7309294:	mov    QWORD PTR [r12+0x378],0x3
    72deb73092a0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb73092a6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73092ac:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72deb73092b2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72deb73092b8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb73092c2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb73092cc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb73092d6:	push   rdx
    72deb73092d7:	push   rsi
    72deb73092d8:	push   r10
    72deb73092da:	push   r11
    72deb73092dc:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb73092e1:	mov    r10d,edx
    72deb73092e4:	and    r10d,0xc000
    72deb73092eb:	shl    r10d,0x10
    72deb73092ef:	mov    r11d,edx
    72deb73092f2:	and    r11d,0x100
    72deb73092f9:	shl    r11d,0x15
    72deb73092fd:	or     r10d,r11d
    72deb7309300:	and    edx,0x1
    72deb7309303:	shl    edx,0x1c
    72deb7309306:	or     r10d,edx
    72deb7309309:	btc    r10,0x1d
    72deb730930e:	mov    r11d,0xf0000000
    72deb7309314:	and    r11,r10
    72deb7309317:	movabs rsi,0xffffffff0fffffff
    72deb7309321:	and    rbx,rsi
    72deb7309324:	or     rbx,r11
    72deb7309327:	pop    r11
    72deb7309329:	pop    r10
    72deb730932b:	pop    rsi
    72deb730932c:	pop    rdx
    72deb730932d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7309335:	stmxcsr DWORD PTR [r12-0x28]
    72deb730933b:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7309340:	test   r10d,0x3f
    72deb7309347:	je     0x72deb730936c
    72deb730934d:	mov    r11d,r10d
    72deb7309350:	shr    r10d,1
    72deb7309353:	and    r10d,0x1e
    72deb7309357:	and    r11d,0x1
    72deb730935b:	or     r10d,r11d
    72deb730935e:	or     DWORD PTR [r12+0x314],r10d
    72deb7309366:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb730936c:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7309372:	lea    rdi,[rsp+0x110]
    72deb730937a:	lea    rsi,[rsp+0xf0]
    72deb7309382:	lea    rdx,[rsp+0x100]
    72deb730938a:	mov    ecx,0x14
    72deb730938f:	mov    r8d,0x0
    72deb7309395:	lea    r9,[r12+0x314]
    72deb730939d:	movabs r11,0x5b63a3f49650
    72deb73093a7:	call   r11
    72deb73093aa:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73093b0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb73093b6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb73093bc:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72deb73093c2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72deb73093c8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb73093d2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb73093dc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb73093e6:	mov    rbx,QWORD PTR [r12+0x108]
    72deb73093ee:	mov    QWORD PTR [r12+0x378],0x2
    72deb73093fa:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7309403:	mov    rdx,rbx
    72deb7309406:	shr    rdx,0x10
    72deb730940a:	and    edx,0xc000
    72deb7309410:	mov    rax,rbx
    72deb7309413:	shr    rax,0x15
    72deb7309417:	and    eax,0x100
    72deb730941c:	xor    eax,0x100
    72deb7309421:	or     edx,eax
    72deb7309423:	mov    rax,rbx
    72deb7309426:	shr    rax,0x1c
    72deb730942a:	and    eax,0x1
    72deb730942d:	or     edx,eax
    72deb730942f:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7309434:	add    rsp,0x8
    72deb7309438:	ret
    72deb7309439:	nop    DWORD PTR [rax+0x0]
    72deb7309440:	sub    rsp,0x8
    72deb7309444:	mov    QWORD PTR [r12+0x378],0x3
    72deb7309450:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7309456:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb730945c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb7309462:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72deb730946c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb7309476:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7309480:	push   rdx
    72deb7309481:	push   rsi
    72deb7309482:	push   r10
    72deb7309484:	push   r11
    72deb7309486:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb730948b:	mov    r10d,edx
    72deb730948e:	and    r10d,0xc000
    72deb7309495:	shl    r10d,0x10
    72deb7309499:	mov    r11d,edx
    72deb730949c:	and    r11d,0x100
    72deb73094a3:	shl    r11d,0x15
    72deb73094a7:	or     r10d,r11d
    72deb73094aa:	and    edx,0x1
    72deb73094ad:	shl    edx,0x1c
    72deb73094b0:	or     r10d,edx
    72deb73094b3:	btc    r10,0x1d
    72deb73094b8:	mov    r11d,0xf0000000
    72deb73094be:	and    r11,r10
    72deb73094c1:	movabs rsi,0xffffffff0fffffff
    72deb73094cb:	and    rbx,rsi
    72deb73094ce:	or     rbx,r11
    72deb73094d1:	pop    r11
    72deb73094d3:	pop    r10
    72deb73094d5:	pop    rsi
    72deb73094d6:	pop    rdx
    72deb73094d7:	mov    QWORD PTR [r12+0x108],rbx
    72deb73094df:	stmxcsr DWORD PTR [r12-0x28]
    72deb73094e5:	mov    r10d,DWORD PTR [r12-0x28]
    72deb73094ea:	test   r10d,0x3f
    72deb73094f1:	je     0x72deb7309516
    72deb73094f7:	mov    r11d,r10d
    72deb73094fa:	shr    r10d,1
    72deb73094fd:	and    r10d,0x1e
    72deb7309501:	and    r11d,0x1
    72deb7309505:	or     r10d,r11d
    72deb7309508:	or     DWORD PTR [r12+0x314],r10d
    72deb7309510:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7309516:	ldmxcsr DWORD PTR [r12-0x38]
    72deb730951c:	lea    rdi,[rsp+0x110]
    72deb7309524:	lea    rsi,[rsp+0xf0]
    72deb730952c:	lea    rdx,[rsp+0x100]
    72deb7309534:	mov    ecx,0x14
    72deb7309539:	mov    r8d,0x0
    72deb730953f:	lea    r9,[r12+0x314]
    72deb7309547:	movabs r11,0x5b63a3f49650
    72deb7309551:	call   r11
    72deb7309554:	ldmxcsr DWORD PTR [r12-0x28]
    72deb730955a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb7309560:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7309566:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb730956c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72deb7309576:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb7309580:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb730958a:	mov    rbx,QWORD PTR [r12+0x108]
    72deb7309592:	mov    QWORD PTR [r12+0x378],0x2
    72deb730959e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb73095a7:	mov    rdx,rbx
    72deb73095aa:	shr    rdx,0x10
    72deb73095ae:	and    edx,0xc000
    72deb73095b4:	mov    rax,rbx
    72deb73095b7:	shr    rax,0x15
    72deb73095bb:	and    eax,0x100
    72deb73095c0:	xor    eax,0x100
    72deb73095c5:	or     edx,eax
    72deb73095c7:	mov    rax,rbx
    72deb73095ca:	shr    rax,0x1c
    72deb73095ce:	and    eax,0x1
    72deb73095d1:	or     edx,eax
    72deb73095d3:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73095d8:	add    rsp,0x8
    72deb73095dc:	ret
    72deb73095dd:	nop    DWORD PTR [rax]
    72deb73095e0:	sub    rsp,0x8
    72deb73095e4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73095f0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73095f6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73095fc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72deb7309602:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72deb730960c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72deb7309616:	push   rdx
    72deb7309617:	push   rsi
    72deb7309618:	push   r10
    72deb730961a:	push   r11
    72deb730961c:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7309621:	mov    r10d,edx
    72deb7309624:	and    r10d,0xc000
    72deb730962b:	shl    r10d,0x10
    72deb730962f:	mov    r11d,edx
    72deb7309632:	and    r11d,0x100
    72deb7309639:	shl    r11d,0x15
    72deb730963d:	or     r10d,r11d
    72deb7309640:	and    edx,0x1
    72deb7309643:	shl    edx,0x1c
    72deb7309646:	or     r10d,edx
    72deb7309649:	btc    r10,0x1d
    72deb730964e:	mov    r11d,0xf0000000
    72deb7309654:	and    r11,r10
    72deb7309657:	movabs rsi,0xffffffff0fffffff
    72deb7309661:	and    rbx,rsi
    72deb7309664:	or     rbx,r11
    72deb7309667:	pop    r11
    72deb7309669:	pop    r10
    72deb730966b:	pop    rsi
    72deb730966c:	pop    rdx
    72deb730966d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7309675:	stmxcsr DWORD PTR [r12-0x28]
    72deb730967b:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7309680:	test   r10d,0x3f
    72deb7309687:	je     0x72deb73096ac
    72deb730968d:	mov    r11d,r10d
    72deb7309690:	shr    r10d,1
    72deb7309693:	and    r10d,0x1e
    72deb7309697:	and    r11d,0x1
    72deb730969b:	or     r10d,r11d
    72deb730969e:	or     DWORD PTR [r12+0x314],r10d
    72deb73096a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb73096ac:	ldmxcsr DWORD PTR [r12-0x38]
    72deb73096b2:	lea    rdi,[rsp+0x110]
    72deb73096ba:	lea    rsi,[rsp+0xf0]
    72deb73096c2:	lea    rdx,[rsp+0x100]
    72deb73096ca:	mov    ecx,0x14
    72deb73096cf:	mov    r8d,0x0
    72deb73096d5:	lea    r9,[r12+0x314]
    72deb73096dd:	movabs r11,0x5b63a3f49650
    72deb73096e7:	call   r11
    72deb73096ea:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73096f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73096f6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb73096fc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72deb7309702:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72deb730970c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72deb7309716:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730971e:	mov    QWORD PTR [r12+0x378],0x2
    72deb730972a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb7309733:	mov    rdx,rbx
    72deb7309736:	shr    rdx,0x10
    72deb730973a:	and    edx,0xc000
    72deb7309740:	mov    rax,rbx
    72deb7309743:	shr    rax,0x15
    72deb7309747:	and    eax,0x100
    72deb730974c:	xor    eax,0x100
    72deb7309751:	or     edx,eax
    72deb7309753:	mov    rax,rbx
    72deb7309756:	shr    rax,0x1c
    72deb730975a:	and    eax,0x1
    72deb730975d:	or     edx,eax
    72deb730975f:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7309764:	add    rsp,0x8
    72deb7309768:	ret
    72deb7309769:	nop    DWORD PTR [rax+0x0]
    72deb7309770:	sub    rsp,0x8
    72deb7309774:	mov    QWORD PTR [r12+0x378],0x3
    72deb7309780:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb7309786:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72deb730978c:	push   rdx
    72deb730978d:	push   rsi
    72deb730978e:	push   r10
    72deb7309790:	push   r11
    72deb7309792:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb7309797:	mov    r10d,edx
    72deb730979a:	and    r10d,0xc000
    72deb73097a1:	shl    r10d,0x10
    72deb73097a5:	mov    r11d,edx
    72deb73097a8:	and    r11d,0x100
    72deb73097af:	shl    r11d,0x15
    72deb73097b3:	or     r10d,r11d
    72deb73097b6:	and    edx,0x1
    72deb73097b9:	shl    edx,0x1c
    72deb73097bc:	or     r10d,edx
    72deb73097bf:	btc    r10,0x1d
    72deb73097c4:	mov    r11d,0xf0000000
    72deb73097ca:	and    r11,r10
    72deb73097cd:	movabs rsi,0xffffffff0fffffff
    72deb73097d7:	and    rbx,rsi
    72deb73097da:	or     rbx,r11
    72deb73097dd:	pop    r11
    72deb73097df:	pop    r10
    72deb73097e1:	pop    rsi
    72deb73097e2:	pop    rdx
    72deb73097e3:	mov    QWORD PTR [r12+0x108],rbx
    72deb73097eb:	stmxcsr DWORD PTR [r12-0x28]
    72deb73097f1:	mov    r10d,DWORD PTR [r12-0x28]
    72deb73097f6:	test   r10d,0x3f
    72deb73097fd:	je     0x72deb7309822
    72deb7309803:	mov    r11d,r10d
    72deb7309806:	shr    r10d,1
    72deb7309809:	and    r10d,0x1e
    72deb730980d:	and    r11d,0x1
    72deb7309811:	or     r10d,r11d
    72deb7309814:	or     DWORD PTR [r12+0x314],r10d
    72deb730981c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7309822:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7309828:	lea    rdi,[rsp+0x110]
    72deb7309830:	lea    rsi,[rsp+0xf0]
    72deb7309838:	lea    rdx,[rsp+0x100]
    72deb7309840:	mov    ecx,0xc
    72deb7309845:	mov    r8d,0x0
    72deb730984b:	lea    r9,[r12+0x314]
    72deb7309853:	movabs r11,0x5b63a3f49650
    72deb730985d:	call   r11
    72deb7309860:	ldmxcsr DWORD PTR [r12-0x28]
    72deb7309866:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb730986c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72deb7309872:	mov    rbx,QWORD PTR [r12+0x108]
    72deb730987a:	mov    QWORD PTR [r12+0x378],0x2
    72deb7309886:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb730988f:	mov    rdx,rbx
    72deb7309892:	shr    rdx,0x10
    72deb7309896:	and    edx,0xc000
    72deb730989c:	mov    rax,rbx
    72deb730989f:	shr    rax,0x15
    72deb73098a3:	and    eax,0x100
    72deb73098a8:	xor    eax,0x100
    72deb73098ad:	or     edx,eax
    72deb73098af:	mov    rax,rbx
    72deb73098b2:	shr    rax,0x1c
    72deb73098b6:	and    eax,0x1
    72deb73098b9:	or     edx,eax
    72deb73098bb:	mov    QWORD PTR [rsp+0x10],rdx
    72deb73098c0:	add    rsp,0x8
    72deb73098c4:	ret
    72deb73098c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72deb73098d0:	sub    rsp,0x8
    72deb73098d4:	mov    QWORD PTR [r12+0x378],0x3
    72deb73098e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72deb73098e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72deb73098ec:	push   rdx
    72deb73098ed:	push   rsi
    72deb73098ee:	push   r10
    72deb73098f0:	push   r11
    72deb73098f2:	mov    rdx,QWORD PTR [rsp+0x30]
    72deb73098f7:	mov    r10d,edx
    72deb73098fa:	and    r10d,0xc000
    72deb7309901:	shl    r10d,0x10
    72deb7309905:	mov    r11d,edx
    72deb7309908:	and    r11d,0x100
    72deb730990f:	shl    r11d,0x15
    72deb7309913:	or     r10d,r11d
    72deb7309916:	and    edx,0x1
    72deb7309919:	shl    edx,0x1c
    72deb730991c:	or     r10d,edx
    72deb730991f:	btc    r10,0x1d
    72deb7309924:	mov    r11d,0xf0000000
    72deb730992a:	and    r11,r10
    72deb730992d:	movabs rsi,0xffffffff0fffffff
    72deb7309937:	and    rbx,rsi
    72deb730993a:	or     rbx,r11
    72deb730993d:	pop    r11
    72deb730993f:	pop    r10
    72deb7309941:	pop    rsi
    72deb7309942:	pop    rdx
    72deb7309943:	mov    QWORD PTR [r12+0x108],rbx
    72deb730994b:	stmxcsr DWORD PTR [r12-0x28]
    72deb7309951:	mov    r10d,DWORD PTR [r12-0x28]
    72deb7309956:	test   r10d,0x3f
    72deb730995d:	je     0x72deb7309982
    72deb7309963:	mov    r11d,r10d
    72deb7309966:	shr    r10d,1
    72deb7309969:	and    r10d,0x1e
    72deb730996d:	and    r11d,0x1
    72deb7309971:	or     r10d,r11d
    72deb7309974:	or     DWORD PTR [r12+0x314],r10d
    72deb730997c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72deb7309982:	ldmxcsr DWORD PTR [r12-0x38]
    72deb7309988:	lea    rdi,[rsp+0x110]
    72deb7309990:	lea    rsi,[rsp+0xf0]
    72deb7309998:	lea    rdx,[rsp+0x100]
    72deb73099a0:	mov    ecx,0xc
    72deb73099a5:	mov    r8d,0x0
    72deb73099ab:	lea    r9,[r12+0x314]
    72deb73099b3:	movabs r11,0x5b63a3f49650
    72deb73099bd:	call   r11
    72deb73099c0:	ldmxcsr DWORD PTR [r12-0x28]
    72deb73099c6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72deb73099cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72deb73099d2:	mov    rbx,QWORD PTR [r12+0x108]
    72deb73099da:	mov    QWORD PTR [r12+0x378],0x2
    72deb73099e6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72deb73099ef:	mov    rdx,rbx
    72deb73099f2:	shr    rdx,0x10
    72deb73099f6:	and    edx,0xc000
    72deb73099fc:	mov    rax,rbx
    72deb73099ff:	shr    rax,0x15
    72deb7309a03:	and    eax,0x100
    72deb7309a08:	xor    eax,0x100
    72deb7309a0d:	or     edx,eax
    72deb7309a0f:	mov    rax,rbx
    72deb7309a12:	shr    rax,0x1c
    72deb7309a16:	and    eax,0x1
    72deb7309a19:	or     edx,eax
    72deb7309a1b:	mov    QWORD PTR [rsp+0x10],rdx
    72deb7309a20:	add    rsp,0x8
    72deb7309a24:	ret
    72deb7309a25:	mov    eax,0x4101e8
    72deb7309a2a:	mov    QWORD PTR [r12+0x100],rax
    72deb7309a32:	push   rdx
    72deb7309a33:	push   rsi
    72deb7309a34:	push   r10
    72deb7309a36:	push   r11
    72deb7309a38:	mov    r11,rax
    72deb7309a3b:	lahf
    72deb7309a3c:	seto   al
    72deb7309a3f:	mov    WORD PTR [rsp+0x20],ax
    72deb7309a44:	mov    rax,r11
    72deb7309a47:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb7309a4c:	mov    r10d,edx
    72deb7309a4f:	and    r10d,0xc000
    72deb7309a56:	shl    r10d,0x10
    72deb7309a5a:	mov    r11d,edx
    72deb7309a5d:	and    r11d,0x100
    72deb7309a64:	shl    r11d,0x15
    72deb7309a68:	or     r10d,r11d
    72deb7309a6b:	and    edx,0x1
    72deb7309a6e:	shl    edx,0x1c
    72deb7309a71:	or     r10d,edx
    72deb7309a74:	btc    r10,0x1d
    72deb7309a79:	mov    r11d,0xf0000000
    72deb7309a7f:	and    r11,r10
    72deb7309a82:	movabs rsi,0xffffffff0fffffff
    72deb7309a8c:	and    rbx,rsi
    72deb7309a8f:	or     rbx,r11
    72deb7309a92:	pop    r11
    72deb7309a94:	pop    r10
    72deb7309a96:	pop    rsi
    72deb7309a97:	pop    rdx
    72deb7309a98:	mov    QWORD PTR [r12+0x108],rbx
    72deb7309aa0:	add    rsp,0x150
    72deb7309aa7:	mov    eax,0xc
    72deb7309aac:	movabs r11,0x5b63a40e2ca0
    72deb7309ab6:	jmp    r11
    72deb7309ab9:	mov    eax,0x410440
    72deb7309abe:	mov    QWORD PTR [r12+0x100],rax
    72deb7309ac6:	push   rdx
    72deb7309ac7:	push   rsi
    72deb7309ac8:	push   r10
    72deb7309aca:	push   r11
    72deb7309acc:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb7309ad1:	mov    r10d,edx
    72deb7309ad4:	and    r10d,0xc000
    72deb7309adb:	shl    r10d,0x10
    72deb7309adf:	mov    r11d,edx
    72deb7309ae2:	and    r11d,0x100
    72deb7309ae9:	shl    r11d,0x15
    72deb7309aed:	or     r10d,r11d
    72deb7309af0:	and    edx,0x1
    72deb7309af3:	shl    edx,0x1c
    72deb7309af6:	or     r10d,edx
    72deb7309af9:	btc    r10,0x1d
    72deb7309afe:	mov    r11d,0xf0000000
    72deb7309b04:	and    r11,r10
    72deb7309b07:	movabs rsi,0xffffffff0fffffff
    72deb7309b11:	and    rbx,rsi
    72deb7309b14:	or     rbx,r11
    72deb7309b17:	pop    r11
    72deb7309b19:	pop    r10
    72deb7309b1b:	pop    rsi
    72deb7309b1c:	pop    rdx
    72deb7309b1d:	mov    QWORD PTR [r12+0x108],rbx
    72deb7309b25:	add    rsp,0x150
    72deb7309b2c:	mov    eax,0xc
    72deb7309b31:	movabs r11,0x5b63a40e2ca0
    72deb7309b3b:	jmp    r11
    72deb7309b3e:	mov    eax,0x41044c
    72deb7309b43:	mov    QWORD PTR [r12+0x100],rax
    72deb7309b4b:	push   rdx
    72deb7309b4c:	push   rsi
    72deb7309b4d:	push   r10
    72deb7309b4f:	push   r11
    72deb7309b51:	mov    r11,rax
    72deb7309b54:	lahf
    72deb7309b55:	seto   al
    72deb7309b58:	mov    WORD PTR [rsp+0x20],ax
    72deb7309b5d:	mov    rax,r11
    72deb7309b60:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb7309b65:	mov    r10d,edx
    72deb7309b68:	and    r10d,0xc000
    72deb7309b6f:	shl    r10d,0x10
    72deb7309b73:	mov    r11d,edx
    72deb7309b76:	and    r11d,0x100
    72deb7309b7d:	shl    r11d,0x15
    72deb7309b81:	or     r10d,r11d
    72deb7309b84:	and    edx,0x1
    72deb7309b87:	shl    edx,0x1c
    72deb7309b8a:	or     r10d,edx
    72deb7309b8d:	btc    r10,0x1d
    72deb7309b92:	mov    r11d,0xf0000000
    72deb7309b98:	and    r11,r10
    72deb7309b9b:	movabs rsi,0xffffffff0fffffff
    72deb7309ba5:	and    rbx,rsi
    72deb7309ba8:	or     rbx,r11
    72deb7309bab:	pop    r11
    72deb7309bad:	pop    r10
    72deb7309baf:	pop    rsi
    72deb7309bb0:	pop    rdx
    72deb7309bb1:	mov    QWORD PTR [r12+0x108],rbx
    72deb7309bb9:	add    rsp,0x150
    72deb7309bc0:	mov    eax,0xc
    72deb7309bc5:	movabs r11,0x5b63a40e2ca0
    72deb7309bcf:	jmp    r11
    72deb7309bd2:	mov    eax,0x41048c
    72deb7309bd7:	mov    QWORD PTR [r12+0x100],rax
    72deb7309bdf:	push   rdx
    72deb7309be0:	push   rsi
    72deb7309be1:	push   r10
    72deb7309be3:	push   r11
    72deb7309be5:	mov    r11,rax
    72deb7309be8:	lahf
    72deb7309be9:	seto   al
    72deb7309bec:	mov    WORD PTR [rsp+0x20],ax
    72deb7309bf1:	mov    rax,r11
    72deb7309bf4:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb7309bf9:	mov    r10d,edx
    72deb7309bfc:	and    r10d,0xc000
    72deb7309c03:	shl    r10d,0x10
    72deb7309c07:	mov    r11d,edx
    72deb7309c0a:	and    r11d,0x100
    72deb7309c11:	shl    r11d,0x15
    72deb7309c15:	or     r10d,r11d
    72deb7309c18:	and    edx,0x1
    72deb7309c1b:	shl    edx,0x1c
    72deb7309c1e:	or     r10d,edx
    72deb7309c21:	btc    r10,0x1d
    72deb7309c26:	mov    r11d,0xf0000000
    72deb7309c2c:	and    r11,r10
    72deb7309c2f:	movabs rsi,0xffffffff0fffffff
    72deb7309c39:	and    rbx,rsi
    72deb7309c3c:	or     rbx,r11
    72deb7309c3f:	pop    r11
    72deb7309c41:	pop    r10
    72deb7309c43:	pop    rsi
    72deb7309c44:	pop    rdx
    72deb7309c45:	mov    QWORD PTR [r12+0x108],rbx
    72deb7309c4d:	add    rsp,0x150
    72deb7309c54:	mov    eax,0xc
    72deb7309c59:	movabs r11,0x5b63a40e2ca0
    72deb7309c63:	jmp    r11
    72deb7309c66:	mov    eax,0x410494
    72deb7309c6b:	mov    QWORD PTR [r12+0x100],rax
    72deb7309c73:	push   rdx
    72deb7309c74:	push   rsi
    72deb7309c75:	push   r10
    72deb7309c77:	push   r11
    72deb7309c79:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb7309c7e:	mov    r10d,edx
    72deb7309c81:	and    r10d,0xc000
    72deb7309c88:	shl    r10d,0x10
    72deb7309c8c:	mov    r11d,edx
    72deb7309c8f:	and    r11d,0x100
    72deb7309c96:	shl    r11d,0x15
    72deb7309c9a:	or     r10d,r11d
    72deb7309c9d:	and    edx,0x1
    72deb7309ca0:	shl    edx,0x1c
    72deb7309ca3:	or     r10d,edx
    72deb7309ca6:	btc    r10,0x1d
    72deb7309cab:	mov    r11d,0xf0000000
    72deb7309cb1:	and    r11,r10
    72deb7309cb4:	movabs rsi,0xffffffff0fffffff
    72deb7309cbe:	and    rbx,rsi
    72deb7309cc1:	or     rbx,r11
    72deb7309cc4:	pop    r11
    72deb7309cc6:	pop    r10
    72deb7309cc8:	pop    rsi
    72deb7309cc9:	pop    rdx
    72deb7309cca:	mov    QWORD PTR [r12+0x108],rbx
    72deb7309cd2:	add    rsp,0x150
    72deb7309cd9:	mov    eax,0xc
    72deb7309cde:	movabs r11,0x5b63a40e2ca0
    72deb7309ce8:	jmp    r11
    72deb7309ceb:	nop    DWORD PTR [rax+rax*1+0x0]
    72deb7309cf0:	sub    rsp,0x150
    72deb7309cf7:	mov    r11,QWORD PTR [r12+0x398]
    72deb7309cff:	mov    QWORD PTR [rsp],r11
    72deb7309d03:	cmp    DWORD PTR [r12+0x310],0x0
    72deb7309d0c:	je     0x72deb7309d97
    72deb7309d12:	push   rdx
    72deb7309d13:	push   rsi
    72deb7309d14:	push   r10
    72deb7309d16:	push   r11
    72deb7309d18:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb7309d1d:	mov    r10d,edx
    72deb7309d20:	and    r10d,0xc000
    72deb7309d27:	shl    r10d,0x10
    72deb7309d2b:	mov    r11d,edx
    72deb7309d2e:	and    r11d,0x100
    72deb7309d35:	shl    r11d,0x15
    72deb7309d39:	or     r10d,r11d
    72deb7309d3c:	and    edx,0x1
    72deb7309d3f:	shl    edx,0x1c
    72deb7309d42:	or     r10d,edx
    72deb7309d45:	btc    r10,0x1d
    72deb7309d4a:	mov    r11d,0xf0000000
    72deb7309d50:	and    r11,r10
    72deb7309d53:	movabs rsi,0xffffffff0fffffff
    72deb7309d5d:	and    rbx,rsi
    72deb7309d60:	or     rbx,r11
    72deb7309d63:	pop    r11
    72deb7309d65:	pop    r10
    72deb7309d67:	pop    rsi
    72deb7309d68:	pop    rdx
    72deb7309d69:	mov    QWORD PTR [r12+0x108],rbx
    72deb7309d71:	mov    eax,0x4101ac
    72deb7309d76:	mov    QWORD PTR [r12+0x100],rax
    72deb7309d7e:	add    rsp,0x150
    72deb7309d85:	mov    eax,0x3
    72deb7309d8a:	movabs r11,0x5b63a40e2ca0
    72deb7309d94:	jmp    r11
    72deb7309d97:	mov    r11,rax
    72deb7309d9a:	movzx  eax,WORD PTR [rsp]
    72deb7309d9e:	add    al,0x7f
    72deb7309da0:	sahf
    72deb7309da1:	mov    rax,r11
    72deb7309da4:	jmp    0x72deb7300202
    72deb7309da9:	nop    DWORD PTR [rax+0x0]
    72deb7309db0:	sub    rsp,0x150
    72deb7309db7:	mov    r11,QWORD PTR [r12+0x398]
    72deb7309dbf:	mov    QWORD PTR [rsp],r11
    72deb7309dc3:	cmp    DWORD PTR [r12+0x310],0x0
    72deb7309dcc:	je     0x72deb7309e57
    72deb7309dd2:	push   rdx
    72deb7309dd3:	push   rsi
    72deb7309dd4:	push   r10
    72deb7309dd6:	push   r11
    72deb7309dd8:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb7309ddd:	mov    r10d,edx
    72deb7309de0:	and    r10d,0xc000
    72deb7309de7:	shl    r10d,0x10
    72deb7309deb:	mov    r11d,edx
    72deb7309dee:	and    r11d,0x100
    72deb7309df5:	shl    r11d,0x15
    72deb7309df9:	or     r10d,r11d
    72deb7309dfc:	and    edx,0x1
    72deb7309dff:	shl    edx,0x1c
    72deb7309e02:	or     r10d,edx
    72deb7309e05:	btc    r10,0x1d
    72deb7309e0a:	mov    r11d,0xf0000000
    72deb7309e10:	and    r11,r10
    72deb7309e13:	movabs rsi,0xffffffff0fffffff
    72deb7309e1d:	and    rbx,rsi
    72deb7309e20:	or     rbx,r11
    72deb7309e23:	pop    r11
    72deb7309e25:	pop    r10
    72deb7309e27:	pop    rsi
    72deb7309e28:	pop    rdx
    72deb7309e29:	mov    QWORD PTR [r12+0x108],rbx
    72deb7309e31:	mov    eax,0x4101ec
    72deb7309e36:	mov    QWORD PTR [r12+0x100],rax
    72deb7309e3e:	add    rsp,0x150
    72deb7309e45:	mov    eax,0x3
    72deb7309e4a:	movabs r11,0x5b63a40e2ca0
    72deb7309e54:	jmp    r11
    72deb7309e57:	jmp    0x72deb7300650
    72deb7309e5c:	nop    DWORD PTR [rax+0x0]
    72deb7309e60:	sub    rsp,0x150
    72deb7309e67:	mov    r11,QWORD PTR [r12+0x398]
    72deb7309e6f:	mov    QWORD PTR [rsp],r11
    72deb7309e73:	cmp    DWORD PTR [r12+0x310],0x0
    72deb7309e7c:	je     0x72deb7309f07
    72deb7309e82:	push   rdx
    72deb7309e83:	push   rsi
    72deb7309e84:	push   r10
    72deb7309e86:	push   r11
    72deb7309e88:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb7309e8d:	mov    r10d,edx
    72deb7309e90:	and    r10d,0xc000
    72deb7309e97:	shl    r10d,0x10
    72deb7309e9b:	mov    r11d,edx
    72deb7309e9e:	and    r11d,0x100
    72deb7309ea5:	shl    r11d,0x15
    72deb7309ea9:	or     r10d,r11d
    72deb7309eac:	and    edx,0x1
    72deb7309eaf:	shl    edx,0x1c
    72deb7309eb2:	or     r10d,edx
    72deb7309eb5:	btc    r10,0x1d
    72deb7309eba:	mov    r11d,0xf0000000
    72deb7309ec0:	and    r11,r10
    72deb7309ec3:	movabs rsi,0xffffffff0fffffff
    72deb7309ecd:	and    rbx,rsi
    72deb7309ed0:	or     rbx,r11
    72deb7309ed3:	pop    r11
    72deb7309ed5:	pop    r10
    72deb7309ed7:	pop    rsi
    72deb7309ed8:	pop    rdx
    72deb7309ed9:	mov    QWORD PTR [r12+0x108],rbx
    72deb7309ee1:	mov    eax,0x410274
    72deb7309ee6:	mov    QWORD PTR [r12+0x100],rax
    72deb7309eee:	add    rsp,0x150
    72deb7309ef5:	mov    eax,0x3
    72deb7309efa:	movabs r11,0x5b63a40e2ca0
    72deb7309f04:	jmp    r11
    72deb7309f07:	mov    r11,rax
    72deb7309f0a:	movzx  eax,WORD PTR [rsp]
    72deb7309f0e:	add    al,0x7f
    72deb7309f10:	sahf
    72deb7309f11:	mov    rax,r11
    72deb7309f14:	jmp    0x72deb7300b1b
    72deb7309f19:	nop    DWORD PTR [rax+0x0]
    72deb7309f20:	sub    rsp,0x150
    72deb7309f27:	mov    r11,QWORD PTR [r12+0x398]
    72deb7309f2f:	mov    QWORD PTR [rsp],r11
    72deb7309f33:	cmp    DWORD PTR [r12+0x310],0x0
    72deb7309f3c:	je     0x72deb7309fc7
    72deb7309f42:	push   rdx
    72deb7309f43:	push   rsi
    72deb7309f44:	push   r10
    72deb7309f46:	push   r11
    72deb7309f48:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb7309f4d:	mov    r10d,edx
    72deb7309f50:	and    r10d,0xc000
    72deb7309f57:	shl    r10d,0x10
    72deb7309f5b:	mov    r11d,edx
    72deb7309f5e:	and    r11d,0x100
    72deb7309f65:	shl    r11d,0x15
    72deb7309f69:	or     r10d,r11d
    72deb7309f6c:	and    edx,0x1
    72deb7309f6f:	shl    edx,0x1c
    72deb7309f72:	or     r10d,edx
    72deb7309f75:	btc    r10,0x1d
    72deb7309f7a:	mov    r11d,0xf0000000
    72deb7309f80:	and    r11,r10
    72deb7309f83:	movabs rsi,0xffffffff0fffffff
    72deb7309f8d:	and    rbx,rsi
    72deb7309f90:	or     rbx,r11
    72deb7309f93:	pop    r11
    72deb7309f95:	pop    r10
    72deb7309f97:	pop    rsi
    72deb7309f98:	pop    rdx
    72deb7309f99:	mov    QWORD PTR [r12+0x108],rbx
    72deb7309fa1:	mov    eax,0x410278
    72deb7309fa6:	mov    QWORD PTR [r12+0x100],rax
    72deb7309fae:	add    rsp,0x150
    72deb7309fb5:	mov    eax,0x3
    72deb7309fba:	movabs r11,0x5b63a40e2ca0
    72deb7309fc4:	jmp    r11
    72deb7309fc7:	jmp    0x72deb7300b39
    72deb7309fcc:	nop    DWORD PTR [rax+0x0]
    72deb7309fd0:	sub    rsp,0x150
    72deb7309fd7:	mov    r11,QWORD PTR [r12+0x398]
    72deb7309fdf:	mov    QWORD PTR [rsp],r11
    72deb7309fe3:	cmp    DWORD PTR [r12+0x310],0x0
    72deb7309fec:	je     0x72deb730a077
    72deb7309ff2:	push   rdx
    72deb7309ff3:	push   rsi
    72deb7309ff4:	push   r10
    72deb7309ff6:	push   r11
    72deb7309ff8:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb7309ffd:	mov    r10d,edx
    72deb730a000:	and    r10d,0xc000
    72deb730a007:	shl    r10d,0x10
    72deb730a00b:	mov    r11d,edx
    72deb730a00e:	and    r11d,0x100
    72deb730a015:	shl    r11d,0x15
    72deb730a019:	or     r10d,r11d
    72deb730a01c:	and    edx,0x1
    72deb730a01f:	shl    edx,0x1c
    72deb730a022:	or     r10d,edx
    72deb730a025:	btc    r10,0x1d
    72deb730a02a:	mov    r11d,0xf0000000
    72deb730a030:	and    r11,r10
    72deb730a033:	movabs rsi,0xffffffff0fffffff
    72deb730a03d:	and    rbx,rsi
    72deb730a040:	or     rbx,r11
    72deb730a043:	pop    r11
    72deb730a045:	pop    r10
    72deb730a047:	pop    rsi
    72deb730a048:	pop    rdx
    72deb730a049:	mov    QWORD PTR [r12+0x108],rbx
    72deb730a051:	mov    eax,0x410444
    72deb730a056:	mov    QWORD PTR [r12+0x100],rax
    72deb730a05e:	add    rsp,0x150
    72deb730a065:	mov    eax,0x3
    72deb730a06a:	movabs r11,0x5b63a40e2ca0
    72deb730a074:	jmp    r11
    72deb730a077:	jmp    0x72deb7302879
    72deb730a07c:	nop    DWORD PTR [rax+0x0]
    72deb730a080:	sub    rsp,0x150
    72deb730a087:	mov    r11,QWORD PTR [r12+0x398]
    72deb730a08f:	mov    QWORD PTR [rsp],r11
    72deb730a093:	cmp    DWORD PTR [r12+0x310],0x0
    72deb730a09c:	je     0x72deb730a127
    72deb730a0a2:	push   rdx
    72deb730a0a3:	push   rsi
    72deb730a0a4:	push   r10
    72deb730a0a6:	push   r11
    72deb730a0a8:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb730a0ad:	mov    r10d,edx
    72deb730a0b0:	and    r10d,0xc000
    72deb730a0b7:	shl    r10d,0x10
    72deb730a0bb:	mov    r11d,edx
    72deb730a0be:	and    r11d,0x100
    72deb730a0c5:	shl    r11d,0x15
    72deb730a0c9:	or     r10d,r11d
    72deb730a0cc:	and    edx,0x1
    72deb730a0cf:	shl    edx,0x1c
    72deb730a0d2:	or     r10d,edx
    72deb730a0d5:	btc    r10,0x1d
    72deb730a0da:	mov    r11d,0xf0000000
    72deb730a0e0:	and    r11,r10
    72deb730a0e3:	movabs rsi,0xffffffff0fffffff
    72deb730a0ed:	and    rbx,rsi
    72deb730a0f0:	or     rbx,r11
    72deb730a0f3:	pop    r11
    72deb730a0f5:	pop    r10
    72deb730a0f7:	pop    rsi
    72deb730a0f8:	pop    rdx
    72deb730a0f9:	mov    QWORD PTR [r12+0x108],rbx
    72deb730a101:	mov    eax,0x410450
    72deb730a106:	mov    QWORD PTR [r12+0x100],rax
    72deb730a10e:	add    rsp,0x150
    72deb730a115:	mov    eax,0x3
    72deb730a11a:	movabs r11,0x5b63a40e2ca0
    72deb730a124:	jmp    r11
    72deb730a127:	jmp    0x72deb73028b6
    72deb730a12c:	nop    DWORD PTR [rax+0x0]
    72deb730a130:	sub    rsp,0x150
    72deb730a137:	mov    r11,QWORD PTR [r12+0x398]
    72deb730a13f:	mov    QWORD PTR [rsp],r11
    72deb730a143:	cmp    DWORD PTR [r12+0x310],0x0
    72deb730a14c:	je     0x72deb730a1d7
    72deb730a152:	push   rdx
    72deb730a153:	push   rsi
    72deb730a154:	push   r10
    72deb730a156:	push   r11
    72deb730a158:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb730a15d:	mov    r10d,edx
    72deb730a160:	and    r10d,0xc000
    72deb730a167:	shl    r10d,0x10
    72deb730a16b:	mov    r11d,edx
    72deb730a16e:	and    r11d,0x100
    72deb730a175:	shl    r11d,0x15
    72deb730a179:	or     r10d,r11d
    72deb730a17c:	and    edx,0x1
    72deb730a17f:	shl    edx,0x1c
    72deb730a182:	or     r10d,edx
    72deb730a185:	btc    r10,0x1d
    72deb730a18a:	mov    r11d,0xf0000000
    72deb730a190:	and    r11,r10
    72deb730a193:	movabs rsi,0xffffffff0fffffff
    72deb730a19d:	and    rbx,rsi
    72deb730a1a0:	or     rbx,r11
    72deb730a1a3:	pop    r11
    72deb730a1a5:	pop    r10
    72deb730a1a7:	pop    rsi
    72deb730a1a8:	pop    rdx
    72deb730a1a9:	mov    QWORD PTR [r12+0x108],rbx
    72deb730a1b1:	mov    eax,0x410474
    72deb730a1b6:	mov    QWORD PTR [r12+0x100],rax
    72deb730a1be:	add    rsp,0x150
    72deb730a1c5:	mov    eax,0x3
    72deb730a1ca:	movabs r11,0x5b63a40e2ca0
    72deb730a1d4:	jmp    r11
    72deb730a1d7:	jmp    0x72deb7302a28
    72deb730a1dc:	nop    DWORD PTR [rax+0x0]
    72deb730a1e0:	sub    rsp,0x150
    72deb730a1e7:	mov    r11,QWORD PTR [r12+0x398]
    72deb730a1ef:	mov    QWORD PTR [rsp],r11
    72deb730a1f3:	cmp    DWORD PTR [r12+0x310],0x0
    72deb730a1fc:	je     0x72deb730a287
    72deb730a202:	push   rdx
    72deb730a203:	push   rsi
    72deb730a204:	push   r10
    72deb730a206:	push   r11
    72deb730a208:	mov    rdx,QWORD PTR [rsp+0x20]
    72deb730a20d:	mov    r10d,edx
    72deb730a210:	and    r10d,0xc000
    72deb730a217:	shl    r10d,0x10
    72deb730a21b:	mov    r11d,edx
    72deb730a21e:	and    r11d,0x100
    72deb730a225:	shl    r11d,0x15
    72deb730a229:	or     r10d,r11d
    72deb730a22c:	and    edx,0x1
    72deb730a22f:	shl    edx,0x1c
    72deb730a232:	or     r10d,edx
    72deb730a235:	btc    r10,0x1d
    72deb730a23a:	mov    r11d,0xf0000000
    72deb730a240:	and    r11,r10
    72deb730a243:	movabs rsi,0xffffffff0fffffff
    72deb730a24d:	and    rbx,rsi
    72deb730a250:	or     rbx,r11
    72deb730a253:	pop    r11
    72deb730a255:	pop    r10
    72deb730a257:	pop    rsi
    72deb730a258:	pop    rdx
    72deb730a259:	mov    QWORD PTR [r12+0x108],rbx
    72deb730a261:	mov    eax,0x410490
    72deb730a266:	mov    QWORD PTR [r12+0x100],rax
    72deb730a26e:	add    rsp,0x150
    72deb730a275:	mov    eax,0x3
    72deb730a27a:	movabs r11,0x5b63a40e2ca0
    72deb730a284:	jmp    r11
    72deb730a287:	jmp    0x72deb7302b81
    72deb730a28c:	nop    DWORD PTR [rax+0x0]
    72deb730a290:	(bad)
    72deb730a291:	(bad)
    72deb730a292:	(bad)
    72deb730a293:	(bad)
    72deb730a294:	(bad)
    72deb730a295:	(bad)
    72deb730a296:	(bad)
    72deb730a297:	jg     0x72deb730a298
    72deb730a299:	(bad)
    72deb730a29a:	(bad)
    72deb730a29b:	(bad)
    72deb730a29c:	(bad)
    72deb730a29d:	(bad)
    72deb730a29e:	(bad)
    72deb730a29f:	jg     0x72deb730a2a1
    72deb730a2a1:	add    BYTE PTR [rax],al
    72deb730a2a3:	add    BYTE PTR [rax],al
    72deb730a2a5:	add    BYTE PTR [rax],dl
    72deb730a2a7:	add    BYTE PTR [rax],al
    72deb730a2a9:	add    BYTE PTR [rax],al
    72deb730a2ab:	add    BYTE PTR [rax],al
    72deb730a2ad:	add    BYTE PTR [rax],dl
	...
