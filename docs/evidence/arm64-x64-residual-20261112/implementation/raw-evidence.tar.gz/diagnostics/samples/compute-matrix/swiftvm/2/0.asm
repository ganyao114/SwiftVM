
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-matrix/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

0000756c3e100000 <.data>:
    756c3e100000:	sub    rsp,0x150
    756c3e100007:	mov    r11,QWORD PTR [r12+0x398]
    756c3e10000f:	mov    QWORD PTR [rsp],r11
    756c3e100013:	cmp    DWORD PTR [r12+0x310],0x0
    756c3e10001c:	je     0x756c3e1000a7
    756c3e100022:	push   rdx
    756c3e100023:	push   rsi
    756c3e100024:	push   r10
    756c3e100026:	push   r11
    756c3e100028:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e10002d:	mov    r10d,edx
    756c3e100030:	and    r10d,0xc000
    756c3e100037:	shl    r10d,0x10
    756c3e10003b:	mov    r11d,edx
    756c3e10003e:	and    r11d,0x100
    756c3e100045:	shl    r11d,0x15
    756c3e100049:	or     r10d,r11d
    756c3e10004c:	and    edx,0x1
    756c3e10004f:	shl    edx,0x1c
    756c3e100052:	or     r10d,edx
    756c3e100055:	btc    r10,0x1d
    756c3e10005a:	mov    r11d,0xf0000000
    756c3e100060:	and    r11,r10
    756c3e100063:	movabs rsi,0xffffffff0fffffff
    756c3e10006d:	and    rbx,rsi
    756c3e100070:	or     rbx,r11
    756c3e100073:	pop    r11
    756c3e100075:	pop    r10
    756c3e100077:	pop    rsi
    756c3e100078:	pop    rdx
    756c3e100079:	mov    QWORD PTR [r12+0x108],rbx
    756c3e100081:	mov    eax,0x410168
    756c3e100086:	mov    QWORD PTR [r12+0x100],rax
    756c3e10008e:	add    rsp,0x150
    756c3e100095:	mov    eax,0x3
    756c3e10009a:	movabs r11,0x60a546e96ca0
    756c3e1000a4:	jmp    r11
    756c3e1000a7:	mov    r13d,0x420000
    756c3e1000ad:	mov    QWORD PTR [r12+0x40],r13
    756c3e1000b2:	movabs r13,0x100000001
    756c3e1000bc:	mov    r14d,0x0
    756c3e1000c2:	mov    QWORD PTR [r12+0x110],r13
    756c3e1000ca:	mov    QWORD PTR [r12+0x118],r14
    756c3e1000d2:	movabs r13,0x3fa0000000000000
    756c3e1000dc:	mov    QWORD PTR [r12+0x50],r13
    756c3e1000e1:	movabs r13,0x4100000041
    756c3e1000eb:	mov    r14d,0x0
    756c3e1000f1:	mov    QWORD PTR [r12+0x120],r13
    756c3e1000f9:	mov    QWORD PTR [r12+0x128],r14
    756c3e100101:	mov    r13d,0x4204c0
    756c3e100107:	mov    r14,QWORD PTR [r13+0x0]
    756c3e10010b:	mov    r13d,0x0
    756c3e100111:	mov    QWORD PTR [r12+0x130],r14
    756c3e100119:	mov    QWORD PTR [r12+0x138],r13
    756c3e100121:	movabs r13,0x3fc0000000000000
    756c3e10012b:	movabs r14,0x3fc0000000000000
    756c3e100135:	mov    QWORD PTR [r12+0x140],r13
    756c3e10013d:	mov    QWORD PTR [r12+0x148],r14
    756c3e100145:	mov    r13d,0x2
    756c3e10014b:	mov    QWORD PTR [r12+0x40],r13
    756c3e100150:	movabs r13,0x200000002
    756c3e10015a:	mov    r14d,0x0
    756c3e100160:	mov    QWORD PTR [r12+0x150],r13
    756c3e100168:	mov    QWORD PTR [r12+0x158],r14
    756c3e100170:	mov    r13d,0x420000
    756c3e100176:	mov    QWORD PTR [r12+0x58],r13
    756c3e10017b:	movabs r13,0x3fa0000000000000
    756c3e100185:	mov    QWORD PTR [r12+0x160],r13
    756c3e10018d:	mov    QWORD PTR [r12+0x168],r13
    756c3e100195:	mov    r13d,0x2
    756c3e10019b:	mov    QWORD PTR [r12+0x170],r13
    756c3e1001a3:	mov    QWORD PTR [r12+0x178],r13
    756c3e1001ab:	mov    r13d,0x4204d0
    756c3e1001b1:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    756c3e1001b7:	movdqu XMMWORD PTR [r12+0x180],xmm2
    756c3e1001c1:	mov    r13d,0x0
    756c3e1001c7:	mov    QWORD PTR [r12+0x48],r13
    756c3e1001cc:	mov    r13d,0x430000
    756c3e1001d2:	add    r13,0x518
    756c3e1001d9:	mov    QWORD PTR [r12+0x40],r13
    756c3e1001de:	mov    r13d,0x430000
    756c3e1001e4:	add    r13,0x720
    756c3e1001eb:	mov    QWORD PTR [r12+0x50],r13
    756c3e1001f0:	mov    r11,rax
    756c3e1001f3:	movzx  eax,WORD PTR [rsp]
    756c3e1001f7:	add    al,0x7f
    756c3e1001f9:	sahf
    756c3e1001fa:	mov    rax,r11
    756c3e1001fd:	jmp    0x756c3e100202
    756c3e100202:	mov    r13,QWORD PTR [r12+0x180]
    756c3e10020a:	mov    r14,QWORD PTR [r12+0x188]
    756c3e100212:	mov    r15d,0x0
    756c3e100218:	mov    r11,rax
    756c3e10021b:	lahf
    756c3e10021c:	seto   al
    756c3e10021f:	mov    WORD PTR [rsp],ax
    756c3e100223:	mov    rax,r11
    756c3e100226:	mov    ecx,0xffffffff
    756c3e10022b:	and    r13,rcx
    756c3e10022e:	mov    rbp,r15
    756c3e100231:	or     rbp,r13
    756c3e100234:	mov    ecx,0xffffffff
    756c3e100239:	and    r14,rcx
    756c3e10023c:	shl    r14,0x20
    756c3e100240:	or     rbp,r14
    756c3e100243:	mov    QWORD PTR [r12+0x210],rbp
    756c3e10024b:	mov    QWORD PTR [r12+0x218],r15
    756c3e100253:	movdqu xmm2,XMMWORD PTR [r12+0x120]
    756c3e10025d:	movdqu xmm3,XMMWORD PTR [r12+0x130]
    756c3e100267:	movdqa xmm1,xmm3
    756c3e10026b:	psubd  xmm2,xmm1
    756c3e10026f:	movdqa xmm14,xmm2
    756c3e100274:	movdqa xmm1,xmm14
    756c3e100279:	movq   rax,xmm1
    756c3e10027e:	mov    r13,rax
    756c3e100281:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    756c3e10028b:	movdqu xmm4,XMMWORD PTR [r12+0x170]
    756c3e100295:	movdqa xmm1,xmm4
    756c3e100299:	paddq  xmm2,xmm1
    756c3e10029d:	movdqu XMMWORD PTR [r12+0x180],xmm2
    756c3e1002a7:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    756c3e1002b1:	movdqa xmm1,xmm2
    756c3e1002b5:	paddd  xmm3,xmm1
    756c3e1002b9:	movdqa xmm14,xmm3
    756c3e1002be:	movdqa xmm1,xmm14
    756c3e1002c3:	movq   rax,xmm1
    756c3e1002c8:	mov    r14,rax
    756c3e1002cb:	mov    r15d,0x0
    756c3e1002d1:	mov    QWORD PTR [r12+0x130],r14
    756c3e1002d9:	mov    QWORD PTR [r12+0x138],r15
    756c3e1002e1:	mov    r14d,0x0
    756c3e1002e7:	mov    ecx,0xffffffff
    756c3e1002ec:	mov    r15,r13
    756c3e1002ef:	and    r15,rcx
    756c3e1002f2:	mov    rbp,r14
    756c3e1002f5:	or     rbp,r15
    756c3e1002f8:	shr    r13,0x20
    756c3e1002fc:	mov    ecx,0xffffffff
    756c3e100301:	and    r13,rcx
    756c3e100304:	or     r14,r13
    756c3e100307:	mov    QWORD PTR [r12+0x220],rbp
    756c3e10030f:	mov    QWORD PTR [r12+0x228],r14
    756c3e100317:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    756c3e100321:	movdqu xmm3,XMMWORD PTR [r12+0x110]
    756c3e10032b:	movdqa xmm1,xmm3
    756c3e10032f:	paddd  xmm2,xmm1
    756c3e100333:	movdqa xmm14,xmm2
    756c3e100338:	movdqa xmm1,xmm14
    756c3e10033d:	movq   rax,xmm1
    756c3e100342:	mov    r13,rax
    756c3e100345:	mov    r14d,0x0
    756c3e10034b:	mov    QWORD PTR [r12+0x210],r13
    756c3e100353:	mov    QWORD PTR [r12+0x218],r14
    756c3e10035b:	lea    r13,[r12]
    756c3e10035f:	movabs r14,0xb6e61da31
    756c3e100369:	mov    r15d,0x4101c4
    756c3e10036f:	mov    rdx,QWORD PTR [rsp]
    756c3e100373:	mov    r10d,edx
    756c3e100376:	and    r10d,0xc000
    756c3e10037d:	shl    r10d,0x10
    756c3e100381:	mov    r11d,edx
    756c3e100384:	and    r11d,0x100
    756c3e10038b:	shl    r11d,0x15
    756c3e10038f:	or     r10d,r11d
    756c3e100392:	and    edx,0x1
    756c3e100395:	shl    edx,0x1c
    756c3e100398:	or     r10d,edx
    756c3e10039b:	btc    r10,0x1d
    756c3e1003a0:	mov    r11d,0xf0000000
    756c3e1003a6:	and    r11,r10
    756c3e1003a9:	movabs rsi,0xffffffff0fffffff
    756c3e1003b3:	and    rbx,rsi
    756c3e1003b6:	or     rbx,r11
    756c3e1003b9:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1003c5:	mov    QWORD PTR [r12+0x108],rbx
    756c3e1003cd:	stmxcsr DWORD PTR [r12-0x28]
    756c3e1003d3:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e1003d8:	test   r10d,0x3f
    756c3e1003df:	je     0x756c3e100404
    756c3e1003e5:	mov    r11d,r10d
    756c3e1003e8:	shr    r10d,1
    756c3e1003eb:	and    r10d,0x1e
    756c3e1003ef:	and    r11d,0x1
    756c3e1003f3:	or     r10d,r11d
    756c3e1003f6:	or     DWORD PTR [r12+0x314],r10d
    756c3e1003fe:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e100404:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e10040a:	movabs r11,0x60a546cf85e0
    756c3e100414:	mov    rdi,r13
    756c3e100417:	mov    rsi,r14
    756c3e10041a:	mov    rdx,r15
    756c3e10041d:	call   r11
    756c3e100420:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e100426:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10042e:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10043a:	mov    rbp,rax
    756c3e10043d:	mov    r13,QWORD PTR [r12+0x210]
    756c3e100445:	mov    r14d,0x0
    756c3e10044b:	mov    ecx,0xffffffff
    756c3e100450:	mov    r15,r13
    756c3e100453:	and    r15,rcx
    756c3e100456:	mov    rbp,r14
    756c3e100459:	or     rbp,r15
    756c3e10045c:	shr    r13,0x20
    756c3e100460:	mov    ecx,0xffffffff
    756c3e100465:	and    r13,rcx
    756c3e100468:	or     r14,r13
    756c3e10046b:	mov    QWORD PTR [r12+0x210],rbp
    756c3e100473:	mov    QWORD PTR [r12+0x218],r14
    756c3e10047b:	lea    r13,[r12]
    756c3e10047f:	movabs r14,0xb6e61da10
    756c3e100489:	mov    r15d,0x4101cc
    756c3e10048f:	mov    QWORD PTR [r12+0x378],0x3
    756c3e10049b:	mov    QWORD PTR [r12+0x108],rbx
    756c3e1004a3:	stmxcsr DWORD PTR [r12-0x28]
    756c3e1004a9:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e1004ae:	test   r10d,0x3f
    756c3e1004b5:	je     0x756c3e1004da
    756c3e1004bb:	mov    r11d,r10d
    756c3e1004be:	shr    r10d,1
    756c3e1004c1:	and    r10d,0x1e
    756c3e1004c5:	and    r11d,0x1
    756c3e1004c9:	or     r10d,r11d
    756c3e1004cc:	or     DWORD PTR [r12+0x314],r10d
    756c3e1004d4:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1004da:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1004e0:	movabs r11,0x60a546cf85e0
    756c3e1004ea:	mov    rdi,r13
    756c3e1004ed:	mov    rsi,r14
    756c3e1004f0:	mov    rdx,r15
    756c3e1004f3:	call   r11
    756c3e1004f6:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1004fc:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e100504:	mov    QWORD PTR [r12+0x378],0x2
    756c3e100510:	mov    rbp,rax
    756c3e100513:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    756c3e10051d:	movdqu xmm3,XMMWORD PTR [r12+0x140]
    756c3e100527:	movdqa xmm0,xmm2
    756c3e10052b:	movdqa xmm1,xmm3
    756c3e10052f:	mulpd  xmm0,xmm1
    756c3e100533:	movdqa xmm14,xmm0
    756c3e100538:	movdqu xmm15,XMMWORD PTR [rip+0x9d4f]        # 0x756c3e10a290
    756c3e100541:	pand   xmm14,xmm15
    756c3e100546:	movdqu xmm15,XMMWORD PTR [rip+0x9d51]        # 0x756c3e10a2a0
    756c3e10054f:	pcmpeqq xmm14,xmm15
    756c3e100555:	movdqa xmm15,xmm0
    756c3e10055a:	cmpunordpd xmm15,xmm0
    756c3e100560:	por    xmm14,xmm15
    756c3e100565:	pmovmskb ecx,xmm14
    756c3e10056a:	jrcxz  0x756c3e100571
    756c3e10056c:	jmp    0x756c3e102bee
    756c3e100571:	movdqa xmm4,xmm0
    756c3e100575:	movdqu XMMWORD PTR [r12+0x220],xmm4
    756c3e10057f:	mov    r13,QWORD PTR [r12+0x48]
    756c3e100584:	mov    r14,QWORD PTR [r12+0x50]
    756c3e100589:	add    r14,r13
    756c3e10058c:	movdqu XMMWORD PTR [r14],xmm4
    756c3e100591:	mov    r14d,0x0
    756c3e100597:	mov    DWORD PTR [r12+0x32c],r14d
    756c3e10059f:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    756c3e1005a9:	movdqu xmm3,XMMWORD PTR [r12+0x160]
    756c3e1005b3:	movdqa xmm0,xmm2
    756c3e1005b7:	movdqa xmm1,xmm3
    756c3e1005bb:	mulpd  xmm0,xmm1
    756c3e1005bf:	movdqa xmm14,xmm0
    756c3e1005c4:	movdqu xmm15,XMMWORD PTR [rip+0x9cc3]        # 0x756c3e10a290
    756c3e1005cd:	pand   xmm14,xmm15
    756c3e1005d2:	movdqu xmm15,XMMWORD PTR [rip+0x9cc5]        # 0x756c3e10a2a0
    756c3e1005db:	pcmpeqq xmm14,xmm15
    756c3e1005e1:	movdqa xmm15,xmm0
    756c3e1005e6:	cmpunordpd xmm15,xmm0
    756c3e1005ec:	por    xmm14,xmm15
    756c3e1005f1:	pmovmskb ecx,xmm14
    756c3e1005f6:	jrcxz  0x756c3e1005fd
    756c3e1005f8:	jmp    0x756c3e102c12
    756c3e1005fd:	movdqa xmm4,xmm0
    756c3e100601:	movdqu XMMWORD PTR [r12+0x210],xmm4
    756c3e10060b:	mov    r14,QWORD PTR [r12+0x40]
    756c3e100610:	add    r14,r13
    756c3e100613:	movdqu XMMWORD PTR [r14],xmm4
    756c3e100618:	add    r13,0x10
    756c3e10061c:	mov    QWORD PTR [r12+0x48],r13
    756c3e100621:	sub    r13,0x200
    756c3e100628:	mov    rcx,QWORD PTR [r12+0x380]
    756c3e100630:	jrcxz  0x756c3e100637
    756c3e100632:	jmp    0x756c3e109a25
    756c3e100637:	jne    0x756c3e100202
    756c3e10063d:	mov    r11,rax
    756c3e100640:	lahf
    756c3e100641:	seto   al
    756c3e100644:	mov    WORD PTR [rsp],ax
    756c3e100648:	mov    rax,r11
    756c3e10064b:	jmp    0x756c3e100650
    756c3e100650:	mov    r13,QWORD PTR [r12+0xf8]
    756c3e100658:	sub    r13,0x150
    756c3e10065f:	mov    QWORD PTR [r12+0xf8],r13
    756c3e100667:	mov    r14,QWORD PTR [r12+0x50]
    756c3e10066c:	mov    r15,r14
    756c3e10066f:	add    r15,0x80
    756c3e100676:	mov    rbp,r15
    756c3e100679:	add    rbp,0x10
    756c3e10067d:	movdqu xmm2,XMMWORD PTR [r15]
    756c3e100682:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    756c3e100687:	movdqu XMMWORD PTR [r12+0x130],xmm2
    756c3e100691:	movdqu XMMWORD PTR [r12+0x110],xmm3
    756c3e10069b:	mov    r15d,0x0
    756c3e1006a1:	mov    QWORD PTR [r12+0x48],r15
    756c3e1006a6:	mov    r15,r14
    756c3e1006a9:	add    r15,0x40
    756c3e1006ad:	mov    rbp,r15
    756c3e1006b0:	add    rbp,0x10
    756c3e1006b4:	movdqu xmm4,XMMWORD PTR [r15]
    756c3e1006b9:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    756c3e1006be:	movdqu XMMWORD PTR [r12+0x250],xmm4
    756c3e1006c8:	movdqu XMMWORD PTR [r12+0x120],xmm5
    756c3e1006d2:	mov    r15,r13
    756c3e1006d5:	add    r15,0x120
    756c3e1006dc:	mov    rbp,r15
    756c3e1006df:	add    rbp,0x8
    756c3e1006e3:	mov    r8,QWORD PTR [r12+0x1c0]
    756c3e1006eb:	mov    r9,QWORD PTR [r12+0x1b0]
    756c3e1006f3:	mov    QWORD PTR [r15],r8
    756c3e1006f6:	mov    r15d,0x0
    756c3e1006fc:	mov    DWORD PTR [r12+0x32c],r15d
    756c3e100704:	mov    QWORD PTR [rbp+0x0],r9
    756c3e100708:	mov    r15d,0x0
    756c3e10070e:	mov    ebp,0x0
    756c3e100713:	mov    QWORD PTR [r12+0x1b0],r15
    756c3e10071b:	mov    QWORD PTR [r12+0x1b8],rbp
    756c3e100723:	mov    r15,r13
    756c3e100726:	add    r15,0x100
    756c3e10072d:	mov    rbp,r15
    756c3e100730:	add    rbp,0x8
    756c3e100734:	mov    r8,QWORD PTR [r12+0x200]
    756c3e10073c:	mov    r9,QWORD PTR [r12+0x1f0]
    756c3e100744:	mov    QWORD PTR [r15],r8
    756c3e100747:	mov    QWORD PTR [rbp+0x0],r9
    756c3e10074b:	mov    r15,r13
    756c3e10074e:	add    r15,0xe0
    756c3e100755:	mov    rbp,r15
    756c3e100758:	add    rbp,0x10
    756c3e10075c:	movdqu XMMWORD PTR [r15],xmm3
    756c3e100761:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    756c3e100766:	mov    r15,r14
    756c3e100769:	add    r15,0xc0
    756c3e100770:	mov    rbp,r15
    756c3e100773:	add    rbp,0x10
    756c3e100777:	movdqu xmm2,XMMWORD PTR [r15]
    756c3e10077c:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    756c3e100781:	movdqu XMMWORD PTR [r12+0x130],xmm2
    756c3e10078b:	movdqu XMMWORD PTR [r12+0x110],xmm3
    756c3e100795:	mov    r15,r13
    756c3e100798:	add    r15,0x110
    756c3e10079f:	mov    rbp,r15
    756c3e1007a2:	add    rbp,0x8
    756c3e1007a6:	mov    r8,QWORD PTR [r12+0x1e0]
    756c3e1007ae:	mov    r9,QWORD PTR [r12+0x1d0]
    756c3e1007b6:	mov    QWORD PTR [r15],r8
    756c3e1007b9:	mov    QWORD PTR [rbp+0x0],r9
    756c3e1007bd:	mov    r15,r14
    756c3e1007c0:	add    r15,0x10
    756c3e1007c4:	movdqu xmm4,XMMWORD PTR [r14]
    756c3e1007c9:	movdqu xmm6,XMMWORD PTR [r15]
    756c3e1007ce:	movdqu XMMWORD PTR [r12+0x170],xmm4
    756c3e1007d8:	movdqu XMMWORD PTR [r12+0x180],xmm6
    756c3e1007e2:	mov    r15,r13
    756c3e1007e5:	add    r15,0x130
    756c3e1007ec:	mov    rbp,r15
    756c3e1007ef:	add    rbp,0x8
    756c3e1007f3:	mov    r8,QWORD PTR [r12+0x1a0]
    756c3e1007fb:	mov    r9,QWORD PTR [r12+0x190]
    756c3e100803:	mov    QWORD PTR [r15],r8
    756c3e100806:	mov    QWORD PTR [rbp+0x0],r9
    756c3e10080a:	mov    r15,r14
    756c3e10080d:	add    r15,0x140
    756c3e100814:	mov    rbp,r15
    756c3e100817:	add    rbp,0x10
    756c3e10081b:	movdqu xmm7,XMMWORD PTR [r15]
    756c3e100820:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    756c3e100826:	movdqu XMMWORD PTR [r12+0x270],xmm7
    756c3e100830:	movdqu XMMWORD PTR [r12+0x190],xmm8
    756c3e10083a:	mov    r15,r13
    756c3e10083d:	add    r15,0xc0
    756c3e100844:	mov    rbp,r15
    756c3e100847:	add    rbp,0x10
    756c3e10084b:	movdqu XMMWORD PTR [r15],xmm3
    756c3e100850:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    756c3e100855:	mov    r15,r14
    756c3e100858:	add    r15,0x100
    756c3e10085f:	mov    rbp,r15
    756c3e100862:	add    rbp,0x10
    756c3e100866:	movdqu xmm2,XMMWORD PTR [r15]
    756c3e10086b:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    756c3e100870:	movdqu XMMWORD PTR [r12+0x110],xmm2
    756c3e10087a:	movdqu XMMWORD PTR [r12+0x300],xmm3
    756c3e100884:	mov    r15,r13
    756c3e100887:	add    r15,0x140
    756c3e10088e:	mov    rbp,QWORD PTR [r12+0xe8]
    756c3e100896:	mov    QWORD PTR [r15],rbp
    756c3e100899:	mov    r15,r14
    756c3e10089c:	add    r15,0x180
    756c3e1008a3:	mov    rbp,r15
    756c3e1008a6:	add    rbp,0x10
    756c3e1008aa:	movdqu xmm3,XMMWORD PTR [r15]
    756c3e1008af:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    756c3e1008b4:	movdqu XMMWORD PTR [r12+0x2a0],xmm3
    756c3e1008be:	movdqu XMMWORD PTR [r12+0x1a0],xmm7
    756c3e1008c8:	mov    r15,r14
    756c3e1008cb:	add    r15,0x1c0
    756c3e1008d2:	mov    rbp,r15
    756c3e1008d5:	add    rbp,0x10
    756c3e1008d9:	movdqu xmm3,XMMWORD PTR [r15]
    756c3e1008de:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    756c3e1008e3:	movdqu XMMWORD PTR [r12+0x240],xmm3
    756c3e1008ed:	movdqu XMMWORD PTR [r12+0x1c0],xmm7
    756c3e1008f7:	mov    r15,r13
    756c3e1008fa:	add    r15,0x20
    756c3e1008fe:	mov    rbp,r15
    756c3e100901:	add    rbp,0x10
    756c3e100905:	movdqu XMMWORD PTR [r15],xmm2
    756c3e10090a:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    756c3e10090f:	mov    r15,r14
    756c3e100912:	add    r15,0x60
    756c3e100916:	mov    rbp,r15
    756c3e100919:	add    rbp,0x10
    756c3e10091d:	movdqu xmm2,XMMWORD PTR [r15]
    756c3e100922:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    756c3e100927:	movdqu XMMWORD PTR [r12+0x110],xmm2
    756c3e100931:	movdqu XMMWORD PTR [r12+0x120],xmm5
    756c3e10093b:	mov    r15,r14
    756c3e10093e:	add    r15,0x20
    756c3e100942:	mov    rbp,r15
    756c3e100945:	add    rbp,0x10
    756c3e100949:	movdqu xmm7,XMMWORD PTR [r15]
    756c3e10094e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    756c3e100954:	movdqu XMMWORD PTR [r12+0x1d0],xmm7
    756c3e10095e:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
    756c3e100968:	mov    r15,r13
    756c3e10096b:	add    r15,0x60
    756c3e10096f:	mov    rbp,r15
    756c3e100972:	add    rbp,0x10
    756c3e100976:	movdqu XMMWORD PTR [r15],xmm4
    756c3e10097b:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    756c3e100980:	mov    r15,r14
    756c3e100983:	add    r15,0xe0
    756c3e10098a:	mov    rbp,r15
    756c3e10098d:	add    rbp,0x10
    756c3e100991:	movdqu xmm3,XMMWORD PTR [r15]
    756c3e100996:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    756c3e10099b:	movdqu XMMWORD PTR [r12+0x200],xmm3
    756c3e1009a5:	movdqu XMMWORD PTR [r12+0x2d0],xmm4
    756c3e1009af:	mov    r15,r13
    756c3e1009b2:	add    r15,0xa0
    756c3e1009b9:	mov    rbp,r15
    756c3e1009bc:	add    rbp,0x10
    756c3e1009c0:	movdqu XMMWORD PTR [r15],xmm5
    756c3e1009c5:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    756c3e1009ca:	mov    r15,r14
    756c3e1009cd:	add    r15,0xa0
    756c3e1009d4:	mov    rbp,r15
    756c3e1009d7:	add    rbp,0x10
    756c3e1009db:	movdqu xmm2,XMMWORD PTR [r15]
    756c3e1009e0:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    756c3e1009e5:	movdqu XMMWORD PTR [r12+0x110],xmm2
    756c3e1009ef:	movdqu XMMWORD PTR [r12+0x120],xmm3
    756c3e1009f9:	mov    r15,r14
    756c3e1009fc:	add    r15,0x120
    756c3e100a03:	mov    rbp,r15
    756c3e100a06:	add    rbp,0x10
    756c3e100a0a:	movdqu xmm4,XMMWORD PTR [r15]
    756c3e100a0f:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    756c3e100a14:	movdqu XMMWORD PTR [r12+0x2e0],xmm4
    756c3e100a1e:	movdqu XMMWORD PTR [r12+0x2f0],xmm5
    756c3e100a28:	mov    r15,r14
    756c3e100a2b:	add    r15,0x160
    756c3e100a32:	mov    rbp,r15
    756c3e100a35:	add    rbp,0x10
    756c3e100a39:	movdqu xmm4,XMMWORD PTR [r15]
    756c3e100a3e:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    756c3e100a43:	movdqu XMMWORD PTR [r12+0x2c0],xmm4
    756c3e100a4d:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
    756c3e100a57:	mov    r15,r13
    756c3e100a5a:	add    r15,0x80
    756c3e100a61:	mov    rbp,r15
    756c3e100a64:	add    rbp,0x10
    756c3e100a68:	movdqu XMMWORD PTR [r15],xmm3
    756c3e100a6d:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    756c3e100a72:	mov    r15,r14
    756c3e100a75:	add    r15,0x1a0
    756c3e100a7c:	mov    rbp,r15
    756c3e100a7f:	add    rbp,0x10
    756c3e100a83:	movdqu xmm2,XMMWORD PTR [r15]
    756c3e100a88:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    756c3e100a8d:	movdqu XMMWORD PTR [r12+0x290],xmm2
    756c3e100a97:	movdqu XMMWORD PTR [r12+0x1e0],xmm3
    756c3e100aa1:	add    r14,0x1e0
    756c3e100aa8:	mov    r15,r14
    756c3e100aab:	add    r15,0x10
    756c3e100aaf:	movdqu xmm2,XMMWORD PTR [r14]
    756c3e100ab4:	movdqu xmm3,XMMWORD PTR [r15]
    756c3e100ab9:	movdqu XMMWORD PTR [r12+0x230],xmm2
    756c3e100ac3:	movdqu XMMWORD PTR [r12+0x280],xmm3
    756c3e100acd:	mov    r14d,0x430000
    756c3e100ad3:	add    r14,0x920
    756c3e100ada:	mov    QWORD PTR [r12+0x50],r14
    756c3e100adf:	mov    r14,r13
    756c3e100ae2:	add    r14,0x40
    756c3e100ae6:	mov    r15,r14
    756c3e100ae9:	add    r15,0x10
    756c3e100aed:	movdqu XMMWORD PTR [r14],xmm4
    756c3e100af2:	movdqu XMMWORD PTR [r15],xmm6
    756c3e100af7:	mov    r14,r13
    756c3e100afa:	add    r14,0x10
    756c3e100afe:	movdqu XMMWORD PTR [r13+0x0],xmm3
    756c3e100b04:	movdqu XMMWORD PTR [r14],xmm2
    756c3e100b09:	mov    r11,rax
    756c3e100b0c:	movzx  eax,WORD PTR [rsp]
    756c3e100b10:	add    al,0x7f
    756c3e100b12:	sahf
    756c3e100b13:	mov    rax,r11
    756c3e100b16:	jmp    0x756c3e100b1b
    756c3e100b1b:	mov    r13d,0x0
    756c3e100b21:	mov    QWORD PTR [r12+0x58],r13
    756c3e100b26:	mov    r11,rax
    756c3e100b29:	lahf
    756c3e100b2a:	seto   al
    756c3e100b2d:	mov    WORD PTR [rsp],ax
    756c3e100b31:	mov    rax,r11
    756c3e100b34:	jmp    0x756c3e100b39
    756c3e100b39:	mov    r13,QWORD PTR [r12+0x58]
    756c3e100b3e:	mov    r14,QWORD PTR [r12+0x40]
    756c3e100b43:	add    r14,r13
    756c3e100b46:	mov    QWORD PTR [r12+0x60],r14
    756c3e100b4b:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    756c3e100b55:	movdqa xmm0,xmm2
    756c3e100b59:	movdqa xmm1,xmm2
    756c3e100b5d:	por    xmm0,xmm1
    756c3e100b61:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    756c3e100b6b:	movdqu xmm4,XMMWORD PTR [r12+0x1a0]
    756c3e100b75:	movdqa xmm0,xmm4
    756c3e100b79:	movdqa xmm1,xmm4
    756c3e100b7d:	por    xmm0,xmm1
    756c3e100b81:	movdqu XMMWORD PTR [r12+0x120],xmm0
    756c3e100b8b:	mov    r15,r14
    756c3e100b8e:	add    r15,0x30
    756c3e100b92:	mov    rbp,r15
    756c3e100b95:	add    rbp,0x8
    756c3e100b99:	mov    r8,QWORD PTR [r15]
    756c3e100b9c:	mov    r15,QWORD PTR [rbp+0x0]
    756c3e100ba0:	mov    ebp,0x0
    756c3e100ba5:	mov    QWORD PTR [r12+0x130],r8
    756c3e100bad:	mov    QWORD PTR [r12+0x138],rbp
    756c3e100bb5:	mov    ebp,0x0
    756c3e100bba:	mov    QWORD PTR [r12+0x280],r15
    756c3e100bc2:	mov    QWORD PTR [r12+0x288],rbp
    756c3e100bca:	movdqu xmm5,XMMWORD PTR [r12+0x270]
    756c3e100bd4:	movdqa xmm0,xmm5
    756c3e100bd8:	movdqa xmm1,xmm5
    756c3e100bdc:	por    xmm0,xmm1
    756c3e100be0:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    756c3e100bea:	mov    r15,r14
    756c3e100bed:	add    r15,0x20
    756c3e100bf1:	mov    rbp,r15
    756c3e100bf4:	add    rbp,0x8
    756c3e100bf8:	mov    r8,QWORD PTR [r15]
    756c3e100bfb:	mov    r15,QWORD PTR [rbp+0x0]
    756c3e100bff:	mov    ebp,0x0
    756c3e100c04:	mov    QWORD PTR [r12+0x150],r8
    756c3e100c0c:	mov    QWORD PTR [r12+0x158],rbp
    756c3e100c14:	mov    ebp,0x0
    756c3e100c19:	mov    QWORD PTR [r12+0x140],r15
    756c3e100c21:	mov    QWORD PTR [r12+0x148],rbp
    756c3e100c29:	mov    r15,r14
    756c3e100c2c:	add    r15,0x10
    756c3e100c30:	mov    rbp,r15
    756c3e100c33:	add    rbp,0x8
    756c3e100c37:	mov    r8,QWORD PTR [r15]
    756c3e100c3a:	mov    r15,QWORD PTR [rbp+0x0]
    756c3e100c3e:	mov    ebp,0x0
    756c3e100c43:	mov    QWORD PTR [r12+0x170],r8
    756c3e100c4b:	mov    QWORD PTR [r12+0x178],rbp
    756c3e100c53:	mov    ebp,0x0
    756c3e100c58:	mov    QWORD PTR [r12+0x160],r15
    756c3e100c60:	mov    QWORD PTR [r12+0x168],rbp
    756c3e100c68:	mov    r15d,0x8
    756c3e100c6e:	mov    rbp,QWORD PTR [r14]
    756c3e100c71:	mov    QWORD PTR [r12+0x180],rbp
    756c3e100c79:	mov    QWORD PTR [r12+0x188],rbp
    756c3e100c81:	add    r14,r15
    756c3e100c84:	mov    QWORD PTR [r12+0x60],r14
    756c3e100c89:	mov    r15,QWORD PTR [r14]
    756c3e100c8c:	mov    r14d,0x0
    756c3e100c92:	mov    QWORD PTR [r12+0x230],r15
    756c3e100c9a:	mov    QWORD PTR [r12+0x238],r14
    756c3e100ca2:	mov    r14,QWORD PTR [r12+0xf8]
    756c3e100caa:	mov    r15,r14
    756c3e100cad:	add    r15,0x50
    756c3e100cb1:	mov    rbp,r15
    756c3e100cb4:	add    rbp,0x10
    756c3e100cb8:	movdqu xmm6,XMMWORD PTR [r15]
    756c3e100cbd:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    756c3e100cc2:	movdqu XMMWORD PTR [r12+0x220],xmm6
    756c3e100ccc:	movdqu XMMWORD PTR [r12+0x210],xmm7
    756c3e100cd6:	mov    r15,r14
    756c3e100cd9:	add    r15,0x30
    756c3e100cdd:	movdqu xmm8,XMMWORD PTR [r15]
    756c3e100ce2:	movdqu XMMWORD PTR [r12+0x110],xmm8
    756c3e100cec:	mov    r15,QWORD PTR [r12+0x50]
    756c3e100cf1:	add    r15,r13
    756c3e100cf4:	mov    QWORD PTR [r12+0x60],r15
    756c3e100cf9:	add    r13,0x40
    756c3e100cfd:	mov    QWORD PTR [r12+0x58],r13
    756c3e100d02:	movdqu xmm9,XMMWORD PTR [r12+0x180]
    756c3e100d0c:	movdqa xmm0,xmm9
    756c3e100d11:	movdqa xmm1,xmm2
    756c3e100d15:	mulpd  xmm0,xmm1
    756c3e100d19:	movdqa xmm14,xmm0
    756c3e100d1e:	movdqu xmm15,XMMWORD PTR [rip+0x9569]        # 0x756c3e10a290
    756c3e100d27:	pand   xmm14,xmm15
    756c3e100d2c:	movdqu xmm15,XMMWORD PTR [rip+0x956b]        # 0x756c3e10a2a0
    756c3e100d35:	pcmpeqq xmm14,xmm15
    756c3e100d3b:	movdqa xmm15,xmm0
    756c3e100d40:	cmpunordpd xmm15,xmm0
    756c3e100d46:	por    xmm14,xmm15
    756c3e100d4b:	pmovmskb ecx,xmm14
    756c3e100d50:	jrcxz  0x756c3e100d57
    756c3e100d52:	jmp    0x756c3e102c36
    756c3e100d57:	movdqa xmm10,xmm0
    756c3e100d5c:	movdqu xmm2,XMMWORD PTR [r12+0x230]
    756c3e100d66:	movdqa xmm0,xmm8
    756c3e100d6b:	movdqa xmm1,xmm2
    756c3e100d6f:	pshufd xmm1,xmm1,0x44
    756c3e100d74:	mulpd  xmm0,xmm1
    756c3e100d78:	movdqa xmm14,xmm0
    756c3e100d7d:	movdqu xmm15,XMMWORD PTR [rip+0x950a]        # 0x756c3e10a290
    756c3e100d86:	pand   xmm14,xmm15
    756c3e100d8b:	movdqu xmm15,XMMWORD PTR [rip+0x950c]        # 0x756c3e10a2a0
    756c3e100d94:	pcmpeqq xmm14,xmm15
    756c3e100d9a:	movdqa xmm15,xmm0
    756c3e100d9f:	cmpunordpd xmm15,xmm0
    756c3e100da5:	por    xmm14,xmm15
    756c3e100daa:	pmovmskb ecx,xmm14
    756c3e100daf:	jrcxz  0x756c3e100db6
    756c3e100db1:	jmp    0x756c3e102c5b
    756c3e100db6:	movdqa xmm11,xmm0
    756c3e100dbb:	movdqu XMMWORD PTR [r12+0x260],xmm11
    756c3e100dc5:	mov    ebp,0x0
    756c3e100dca:	mov    r8d,0x0
    756c3e100dd0:	mov    QWORD PTR [r12+0x110],rbp
    756c3e100dd8:	mov    QWORD PTR [r12+0x118],r8
    756c3e100de0:	movdqa xmm0,xmm9
    756c3e100de5:	movdqa xmm1,xmm7
    756c3e100de9:	mulpd  xmm0,xmm1
    756c3e100ded:	movdqa xmm14,xmm0
    756c3e100df2:	movdqu xmm15,XMMWORD PTR [rip+0x9495]        # 0x756c3e10a290
    756c3e100dfb:	pand   xmm14,xmm15
    756c3e100e00:	movdqu xmm15,XMMWORD PTR [rip+0x9497]        # 0x756c3e10a2a0
    756c3e100e09:	pcmpeqq xmm14,xmm15
    756c3e100e0f:	movdqa xmm15,xmm0
    756c3e100e14:	cmpunordpd xmm15,xmm0
    756c3e100e1a:	por    xmm14,xmm15
    756c3e100e1f:	pmovmskb ecx,xmm14
    756c3e100e24:	jrcxz  0x756c3e100e2b
    756c3e100e26:	jmp    0x756c3e102c80
    756c3e100e2b:	movdqa xmm8,xmm0
    756c3e100e30:	movdqa xmm0,xmm9
    756c3e100e35:	movdqa xmm1,xmm6
    756c3e100e39:	mulpd  xmm0,xmm1
    756c3e100e3d:	movdqa xmm14,xmm0
    756c3e100e42:	movdqu xmm15,XMMWORD PTR [rip+0x9445]        # 0x756c3e10a290
    756c3e100e4b:	pand   xmm14,xmm15
    756c3e100e50:	movdqu xmm15,XMMWORD PTR [rip+0x9447]        # 0x756c3e10a2a0
    756c3e100e59:	pcmpeqq xmm14,xmm15
    756c3e100e5f:	movdqa xmm15,xmm0
    756c3e100e64:	cmpunordpd xmm15,xmm0
    756c3e100e6a:	por    xmm14,xmm15
    756c3e100e6f:	pmovmskb ecx,xmm14
    756c3e100e74:	jrcxz  0x756c3e100e7b
    756c3e100e76:	jmp    0x756c3e102ca5
    756c3e100e7b:	movdqa xmm7,xmm0
    756c3e100e7f:	movdqu xmm6,XMMWORD PTR [r12+0x1f0]
    756c3e100e89:	movdqa xmm0,xmm9
    756c3e100e8e:	movdqa xmm1,xmm6
    756c3e100e92:	mulpd  xmm0,xmm1
    756c3e100e96:	movdqa xmm14,xmm0
    756c3e100e9b:	movdqu xmm15,XMMWORD PTR [rip+0x93ec]        # 0x756c3e10a290
    756c3e100ea4:	pand   xmm14,xmm15
    756c3e100ea9:	movdqu xmm15,XMMWORD PTR [rip+0x93ee]        # 0x756c3e10a2a0
    756c3e100eb2:	pcmpeqq xmm14,xmm15
    756c3e100eb8:	movdqa xmm15,xmm0
    756c3e100ebd:	cmpunordpd xmm15,xmm0
    756c3e100ec3:	por    xmm14,xmm15
    756c3e100ec8:	pmovmskb ecx,xmm14
    756c3e100ecd:	jrcxz  0x756c3e100ed4
    756c3e100ecf:	jmp    0x756c3e102cca
    756c3e100ed4:	movdqa xmm12,xmm0
    756c3e100ed9:	movdqu XMMWORD PTR [r12+0x180],xmm12
    756c3e100ee3:	movdqu xmm6,XMMWORD PTR [r12+0x2a0]
    756c3e100eed:	movdqa xmm0,xmm6
    756c3e100ef1:	movdqa xmm1,xmm6
    756c3e100ef5:	por    xmm0,xmm1
    756c3e100ef9:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    756c3e100f03:	movdqu xmm9,XMMWORD PTR [r12+0x250]
    756c3e100f0d:	movdqa xmm0,xmm9
    756c3e100f12:	movdqa xmm1,xmm9
    756c3e100f17:	por    xmm0,xmm1
    756c3e100f1b:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    756c3e100f25:	movdqa xmm0,xmm9
    756c3e100f2a:	movdqa xmm1,xmm2
    756c3e100f2e:	pshufd xmm1,xmm1,0x44
    756c3e100f33:	mulpd  xmm0,xmm1
    756c3e100f37:	movdqa xmm14,xmm0
    756c3e100f3c:	movdqu xmm15,XMMWORD PTR [rip+0x934b]        # 0x756c3e10a290
    756c3e100f45:	pand   xmm14,xmm15
    756c3e100f4a:	movdqu xmm15,XMMWORD PTR [rip+0x934d]        # 0x756c3e10a2a0
    756c3e100f53:	pcmpeqq xmm14,xmm15
    756c3e100f59:	movdqa xmm15,xmm0
    756c3e100f5e:	cmpunordpd xmm15,xmm0
    756c3e100f64:	por    xmm14,xmm15
    756c3e100f69:	pmovmskb ecx,xmm14
    756c3e100f6e:	jrcxz  0x756c3e100f75
    756c3e100f70:	jmp    0x756c3e102cef
    756c3e100f75:	movdqa xmm4,xmm0
    756c3e100f79:	movdqu XMMWORD PTR [r12+0x250],xmm4
    756c3e100f83:	sub    r13,0x200
    756c3e100f8a:	movdqu xmm9,XMMWORD PTR [r12+0x110]
    756c3e100f94:	movdqa xmm0,xmm10
    756c3e100f99:	movdqa xmm1,xmm9
    756c3e100f9e:	addpd  xmm0,xmm1
    756c3e100fa2:	movdqa xmm14,xmm0
    756c3e100fa7:	movdqu xmm15,XMMWORD PTR [rip+0x92e0]        # 0x756c3e10a290
    756c3e100fb0:	pand   xmm14,xmm15
    756c3e100fb5:	movdqu xmm15,XMMWORD PTR [rip+0x92e2]        # 0x756c3e10a2a0
    756c3e100fbe:	pcmpeqq xmm14,xmm15
    756c3e100fc4:	movdqa xmm15,xmm0
    756c3e100fc9:	cmpunordpd xmm15,xmm0
    756c3e100fcf:	por    xmm14,xmm15
    756c3e100fd4:	pmovmskb ecx,xmm14
    756c3e100fd9:	jrcxz  0x756c3e100fe0
    756c3e100fdb:	jmp    0x756c3e102d14
    756c3e100fe0:	movdqu XMMWORD PTR [r12+0x240],xmm0
    756c3e100fea:	movdqu xmm10,XMMWORD PTR [r12+0x1b0]
    756c3e100ff4:	movdqa xmm0,xmm8
    756c3e100ff9:	movdqa xmm1,xmm10
    756c3e100ffe:	addpd  xmm0,xmm1
    756c3e101002:	movdqa xmm14,xmm0
    756c3e101007:	movdqu xmm15,XMMWORD PTR [rip+0x9280]        # 0x756c3e10a290
    756c3e101010:	pand   xmm14,xmm15
    756c3e101015:	movdqu xmm15,XMMWORD PTR [rip+0x9282]        # 0x756c3e10a2a0
    756c3e10101e:	pcmpeqq xmm14,xmm15
    756c3e101024:	movdqa xmm15,xmm0
    756c3e101029:	cmpunordpd xmm15,xmm0
    756c3e10102f:	por    xmm14,xmm15
    756c3e101034:	pmovmskb ecx,xmm14
    756c3e101039:	jrcxz  0x756c3e101040
    756c3e10103b:	jmp    0x756c3e102d55
    756c3e101040:	movdqa xmm6,xmm0
    756c3e101044:	movdqu XMMWORD PTR [r12+0x210],xmm6
    756c3e10104e:	movdqa xmm0,xmm7
    756c3e101052:	movdqa xmm1,xmm10
    756c3e101057:	addpd  xmm0,xmm1
    756c3e10105b:	movdqa xmm14,xmm0
    756c3e101060:	movdqu xmm15,XMMWORD PTR [rip+0x9227]        # 0x756c3e10a290
    756c3e101069:	pand   xmm14,xmm15
    756c3e10106e:	movdqu xmm15,XMMWORD PTR [rip+0x9229]        # 0x756c3e10a2a0
    756c3e101077:	pcmpeqq xmm14,xmm15
    756c3e10107d:	movdqa xmm15,xmm0
    756c3e101082:	cmpunordpd xmm15,xmm0
    756c3e101088:	por    xmm14,xmm15
    756c3e10108d:	pmovmskb ecx,xmm14
    756c3e101092:	jrcxz  0x756c3e101099
    756c3e101094:	jmp    0x756c3e102d96
    756c3e101099:	movdqa xmm8,xmm0
    756c3e10109e:	movdqu XMMWORD PTR [r12+0x220],xmm8
    756c3e1010a8:	movdqu xmm7,XMMWORD PTR [r12+0x2f0]
    756c3e1010b2:	setne  BYTE PTR [rsp+0x8]
    756c3e1010b7:	mov    r11,rax
    756c3e1010ba:	lahf
    756c3e1010bb:	seto   al
    756c3e1010be:	mov    WORD PTR [rsp],ax
    756c3e1010c2:	mov    rax,r11
    756c3e1010c5:	movdqa xmm0,xmm7
    756c3e1010c9:	movdqa xmm1,xmm7
    756c3e1010cd:	por    xmm0,xmm1
    756c3e1010d1:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    756c3e1010db:	movdqu xmm10,XMMWORD PTR [r12+0x2e0]
    756c3e1010e5:	movdqa xmm0,xmm10
    756c3e1010ea:	movdqa xmm1,xmm10
    756c3e1010ef:	por    xmm0,xmm1
    756c3e1010f3:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    756c3e1010fd:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    756c3e101107:	movdqa xmm0,xmm13
    756c3e10110c:	movdqa xmm1,xmm13
    756c3e101111:	por    xmm0,xmm1
    756c3e101115:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    756c3e10111f:	movdqu xmm5,XMMWORD PTR [r12+0x200]
    756c3e101129:	movdqa xmm0,xmm5
    756c3e10112d:	movdqa xmm1,xmm5
    756c3e101131:	por    xmm0,xmm1
    756c3e101135:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    756c3e10113f:	movdqu xmm7,XMMWORD PTR [r12+0x1c0]
    756c3e101149:	movdqa xmm1,xmm7
    756c3e10114d:	por    xmm7,xmm1
    756c3e101151:	movdqu XMMWORD PTR [r12+0x200],xmm7
    756c3e10115b:	movdqu xmm3,XMMWORD PTR [r12+0x190]
    756c3e101165:	movdqa xmm1,xmm3
    756c3e101169:	por    xmm3,xmm1
    756c3e10116d:	movdqu XMMWORD PTR [r12+0x1c0],xmm3
    756c3e101177:	movdqu xmm10,XMMWORD PTR [r12+0x300]
    756c3e101181:	movdqa xmm1,xmm10
    756c3e101186:	por    xmm10,xmm1
    756c3e10118b:	movdqu XMMWORD PTR [r12+0x190],xmm10
    756c3e101195:	mov    r13,r14
    756c3e101198:	add    r13,0xa0
    756c3e10119f:	mov    rbp,r13
    756c3e1011a2:	add    rbp,0x10
    756c3e1011a6:	movdqu xmm13,XMMWORD PTR [r13+0x0]
    756c3e1011ac:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    756c3e1011b1:	movdqu XMMWORD PTR [r12+0x300],xmm13
    756c3e1011bb:	movdqu XMMWORD PTR [r12+0x270],xmm5
    756c3e1011c5:	movdqa xmm0,xmm12
    756c3e1011ca:	movdqa xmm1,xmm9
    756c3e1011cf:	addpd  xmm0,xmm1
    756c3e1011d3:	movdqa xmm14,xmm0
    756c3e1011d8:	movdqu xmm15,XMMWORD PTR [rip+0x90af]        # 0x756c3e10a290
    756c3e1011e1:	pand   xmm14,xmm15
    756c3e1011e6:	movdqu xmm15,XMMWORD PTR [rip+0x90b1]        # 0x756c3e10a2a0
    756c3e1011ef:	pcmpeqq xmm14,xmm15
    756c3e1011f5:	movdqa xmm15,xmm0
    756c3e1011fa:	cmpunordpd xmm15,xmm0
    756c3e101200:	por    xmm14,xmm15
    756c3e101205:	pmovmskb ecx,xmm14
    756c3e10120a:	jrcxz  0x756c3e101211
    756c3e10120c:	jmp    0x756c3e102dd6
    756c3e101211:	movdqu XMMWORD PTR [r12+0x180],xmm0
    756c3e10121b:	mov    r13,r14
    756c3e10121e:	add    r13,0xf0
    756c3e101225:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    756c3e10122b:	movdqu XMMWORD PTR [r12+0x110],xmm9
    756c3e101235:	movdqa xmm0,xmm6
    756c3e101239:	movdqa xmm1,xmm4
    756c3e10123d:	addpd  xmm0,xmm1
    756c3e101241:	movdqa xmm14,xmm0
    756c3e101246:	movdqu xmm15,XMMWORD PTR [rip+0x9041]        # 0x756c3e10a290
    756c3e10124f:	pand   xmm14,xmm15
    756c3e101254:	movdqu xmm15,XMMWORD PTR [rip+0x9043]        # 0x756c3e10a2a0
    756c3e10125d:	pcmpeqq xmm14,xmm15
    756c3e101263:	movdqa xmm15,xmm0
    756c3e101268:	cmpunordpd xmm15,xmm0
    756c3e10126e:	por    xmm14,xmm15
    756c3e101273:	pmovmskb ecx,xmm14
    756c3e101278:	jrcxz  0x756c3e10127f
    756c3e10127a:	jmp    0x756c3e102dfc
    756c3e10127f:	movdqa xmm12,xmm0
    756c3e101284:	movdqu XMMWORD PTR [r12+0x210],xmm12
    756c3e10128e:	movdqa xmm0,xmm8
    756c3e101293:	movdqa xmm1,xmm11
    756c3e101298:	addpd  xmm0,xmm1
    756c3e10129c:	movdqa xmm14,xmm0
    756c3e1012a1:	movdqu xmm15,XMMWORD PTR [rip+0x8fe6]        # 0x756c3e10a290
    756c3e1012aa:	pand   xmm14,xmm15
    756c3e1012af:	movdqu xmm15,XMMWORD PTR [rip+0x8fe8]        # 0x756c3e10a2a0
    756c3e1012b8:	pcmpeqq xmm14,xmm15
    756c3e1012be:	movdqa xmm15,xmm0
    756c3e1012c3:	cmpunordpd xmm15,xmm0
    756c3e1012c9:	por    xmm14,xmm15
    756c3e1012ce:	pmovmskb ecx,xmm14
    756c3e1012d3:	jrcxz  0x756c3e1012da
    756c3e1012d5:	jmp    0x756c3e102e20
    756c3e1012da:	movdqa xmm4,xmm0
    756c3e1012de:	movdqu XMMWORD PTR [r12+0x220],xmm4
    756c3e1012e8:	movdqa xmm0,xmm5
    756c3e1012ec:	movdqa xmm1,xmm2
    756c3e1012f0:	pshufd xmm1,xmm1,0x44
    756c3e1012f5:	mulpd  xmm0,xmm1
    756c3e1012f9:	movdqa xmm14,xmm0
    756c3e1012fe:	movdqu xmm15,XMMWORD PTR [rip+0x8f89]        # 0x756c3e10a290
    756c3e101307:	pand   xmm14,xmm15
    756c3e10130c:	movdqu xmm15,XMMWORD PTR [rip+0x8f8b]        # 0x756c3e10a2a0
    756c3e101315:	pcmpeqq xmm14,xmm15
    756c3e10131b:	movdqa xmm15,xmm0
    756c3e101320:	cmpunordpd xmm15,xmm0
    756c3e101326:	por    xmm14,xmm15
    756c3e10132b:	pmovmskb ecx,xmm14
    756c3e101330:	jrcxz  0x756c3e101337
    756c3e101332:	jmp    0x756c3e102e46
    756c3e101337:	movdqa xmm6,xmm0
    756c3e10133b:	movdqu XMMWORD PTR [r12+0x270],xmm6
    756c3e101345:	movdqu xmm5,XMMWORD PTR [r12+0x170]
    756c3e10134f:	movdqa xmm0,xmm9
    756c3e101354:	movdqa xmm1,xmm5
    756c3e101358:	pshufd xmm1,xmm1,0x44
    756c3e10135d:	mulpd  xmm0,xmm1
    756c3e101361:	movdqa xmm14,xmm0
    756c3e101366:	movdqu xmm15,XMMWORD PTR [rip+0x8f21]        # 0x756c3e10a290
    756c3e10136f:	pand   xmm14,xmm15
    756c3e101374:	movdqu xmm15,XMMWORD PTR [rip+0x8f23]        # 0x756c3e10a2a0
    756c3e10137d:	pcmpeqq xmm14,xmm15
    756c3e101383:	movdqa xmm15,xmm0
    756c3e101388:	cmpunordpd xmm15,xmm0
    756c3e10138e:	por    xmm14,xmm15
    756c3e101393:	pmovmskb ecx,xmm14
    756c3e101398:	jrcxz  0x756c3e10139f
    756c3e10139a:	jmp    0x756c3e102e6a
    756c3e10139f:	movdqa xmm8,xmm0
    756c3e1013a4:	movdqu XMMWORD PTR [r12+0x250],xmm8
    756c3e1013ae:	mov    r13,r14
    756c3e1013b1:	add    r13,0xe0
    756c3e1013b8:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    756c3e1013be:	movdqu XMMWORD PTR [r12+0x110],xmm9
    756c3e1013c8:	movdqa xmm0,xmm13
    756c3e1013cd:	movdqa xmm1,xmm2
    756c3e1013d1:	pshufd xmm1,xmm1,0x44
    756c3e1013d6:	mulpd  xmm0,xmm1
    756c3e1013da:	movdqa xmm14,xmm0
    756c3e1013df:	movdqu xmm15,XMMWORD PTR [rip+0x8ea8]        # 0x756c3e10a290
    756c3e1013e8:	pand   xmm14,xmm15
    756c3e1013ed:	movdqu xmm15,XMMWORD PTR [rip+0x8eaa]        # 0x756c3e10a2a0
    756c3e1013f6:	pcmpeqq xmm14,xmm15
    756c3e1013fc:	movdqa xmm15,xmm0
    756c3e101401:	cmpunordpd xmm15,xmm0
    756c3e101407:	por    xmm14,xmm15
    756c3e10140c:	pmovmskb ecx,xmm14
    756c3e101411:	jrcxz  0x756c3e101418
    756c3e101413:	jmp    0x756c3e102e8f
    756c3e101418:	movdqa xmm11,xmm0
    756c3e10141d:	movdqu XMMWORD PTR [r12+0x230],xmm11
    756c3e101427:	movdqa xmm0,xmm10
    756c3e10142c:	movdqa xmm1,xmm10
    756c3e101431:	por    xmm0,xmm1
    756c3e101435:	movdqu XMMWORD PTR [r12+0x300],xmm0
    756c3e10143f:	movdqa xmm0,xmm3
    756c3e101443:	movdqa xmm1,xmm3
    756c3e101447:	por    xmm0,xmm1
    756c3e10144b:	movdqu XMMWORD PTR [r12+0x190],xmm0
    756c3e101455:	movdqa xmm0,xmm9
    756c3e10145a:	movdqa xmm1,xmm5
    756c3e10145e:	pshufd xmm1,xmm1,0x44
    756c3e101463:	mulpd  xmm0,xmm1
    756c3e101467:	movdqa xmm14,xmm0
    756c3e10146c:	movdqu xmm15,XMMWORD PTR [rip+0x8e1b]        # 0x756c3e10a290
    756c3e101475:	pand   xmm14,xmm15
    756c3e10147a:	movdqu xmm15,XMMWORD PTR [rip+0x8e1d]        # 0x756c3e10a2a0
    756c3e101483:	pcmpeqq xmm14,xmm15
    756c3e101489:	movdqa xmm15,xmm0
    756c3e10148e:	cmpunordpd xmm15,xmm0
    756c3e101494:	por    xmm14,xmm15
    756c3e101499:	pmovmskb ecx,xmm14
    756c3e10149e:	jrcxz  0x756c3e1014a5
    756c3e1014a0:	jmp    0x756c3e102eb4
    756c3e1014a5:	movdqa xmm2,xmm0
    756c3e1014a9:	movdqu XMMWORD PTR [r12+0x260],xmm2
    756c3e1014b3:	mov    r13,r14
    756c3e1014b6:	add    r13,0x90
    756c3e1014bd:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    756c3e1014c3:	movdqu XMMWORD PTR [r12+0x110],xmm9
    756c3e1014cd:	movdqa xmm0,xmm7
    756c3e1014d1:	movdqa xmm1,xmm7
    756c3e1014d5:	por    xmm0,xmm1
    756c3e1014d9:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    756c3e1014e3:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    756c3e1014ed:	movdqu xmm1,XMMWORD PTR [r12+0x2d0]
    756c3e1014f7:	por    xmm13,xmm1
    756c3e1014fc:	movdqu XMMWORD PTR [r12+0x200],xmm13
    756c3e101506:	movdqu xmm7,XMMWORD PTR [r12+0x2e0]
    756c3e101510:	movdqu xmm1,XMMWORD PTR [r12+0x2e0]
    756c3e10151a:	por    xmm7,xmm1
    756c3e10151e:	movdqu XMMWORD PTR [r12+0x2d0],xmm7
    756c3e101528:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    756c3e101532:	movdqu xmm1,XMMWORD PTR [r12+0x2f0]
    756c3e10153c:	por    xmm0,xmm1
    756c3e101540:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    756c3e10154a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    756c3e101554:	movdqa xmm1,xmm6
    756c3e101558:	addpd  xmm0,xmm1
    756c3e10155c:	movdqa xmm14,xmm0
    756c3e101561:	movdqu xmm15,XMMWORD PTR [rip+0x8d26]        # 0x756c3e10a290
    756c3e10156a:	pand   xmm14,xmm15
    756c3e10156f:	movdqu xmm15,XMMWORD PTR [rip+0x8d28]        # 0x756c3e10a2a0
    756c3e101578:	pcmpeqq xmm14,xmm15
    756c3e10157e:	movdqa xmm15,xmm0
    756c3e101583:	cmpunordpd xmm15,xmm0
    756c3e101589:	por    xmm14,xmm15
    756c3e10158e:	pmovmskb ecx,xmm14
    756c3e101593:	jrcxz  0x756c3e10159a
    756c3e101595:	jmp    0x756c3e102ed9
    756c3e10159a:	movdqa xmm3,xmm0
    756c3e10159e:	movdqu XMMWORD PTR [r12+0x240],xmm3
    756c3e1015a8:	movdqa xmm0,xmm9
    756c3e1015ad:	movdqa xmm1,xmm5
    756c3e1015b1:	pshufd xmm1,xmm1,0x44
    756c3e1015b6:	mulpd  xmm0,xmm1
    756c3e1015ba:	movdqa xmm14,xmm0
    756c3e1015bf:	movdqu xmm15,XMMWORD PTR [rip+0x8cc8]        # 0x756c3e10a290
    756c3e1015c8:	pand   xmm14,xmm15
    756c3e1015cd:	movdqu xmm15,XMMWORD PTR [rip+0x8cca]        # 0x756c3e10a2a0
    756c3e1015d6:	pcmpeqq xmm14,xmm15
    756c3e1015dc:	movdqa xmm15,xmm0
    756c3e1015e1:	cmpunordpd xmm15,xmm0
    756c3e1015e7:	por    xmm14,xmm15
    756c3e1015ec:	pmovmskb ecx,xmm14
    756c3e1015f1:	jrcxz  0x756c3e1015f8
    756c3e1015f3:	jmp    0x756c3e102f03
    756c3e1015f8:	movdqa xmm6,xmm0
    756c3e1015fc:	movdqu XMMWORD PTR [r12+0x270],xmm6
    756c3e101606:	mov    r13,r14
    756c3e101609:	add    r13,0x80
    756c3e101610:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    756c3e101616:	movdqu XMMWORD PTR [r12+0x110],xmm9
    756c3e101620:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    756c3e10162a:	movdqa xmm1,xmm11
    756c3e10162f:	addpd  xmm0,xmm1
    756c3e101633:	movdqa xmm14,xmm0
    756c3e101638:	movdqu xmm15,XMMWORD PTR [rip+0x8c4f]        # 0x756c3e10a290
    756c3e101641:	pand   xmm14,xmm15
    756c3e101646:	movdqu xmm15,XMMWORD PTR [rip+0x8c51]        # 0x756c3e10a2a0
    756c3e10164f:	pcmpeqq xmm14,xmm15
    756c3e101655:	movdqa xmm15,xmm0
    756c3e10165a:	cmpunordpd xmm15,xmm0
    756c3e101660:	por    xmm14,xmm15
    756c3e101665:	pmovmskb ecx,xmm14
    756c3e10166a:	jrcxz  0x756c3e101671
    756c3e10166c:	jmp    0x756c3e102f28
    756c3e101671:	movdqa xmm10,xmm0
    756c3e101676:	movdqu XMMWORD PTR [r12+0x180],xmm10
    756c3e101680:	movdqa xmm0,xmm12
    756c3e101685:	movdqa xmm1,xmm8
    756c3e10168a:	addpd  xmm0,xmm1
    756c3e10168e:	movdqa xmm14,xmm0
    756c3e101693:	movdqu xmm15,XMMWORD PTR [rip+0x8bf4]        # 0x756c3e10a290
    756c3e10169c:	pand   xmm14,xmm15
    756c3e1016a1:	movdqu xmm15,XMMWORD PTR [rip+0x8bf6]        # 0x756c3e10a2a0
    756c3e1016aa:	pcmpeqq xmm14,xmm15
    756c3e1016b0:	movdqa xmm15,xmm0
    756c3e1016b5:	cmpunordpd xmm15,xmm0
    756c3e1016bb:	por    xmm14,xmm15
    756c3e1016c0:	pmovmskb ecx,xmm14
    756c3e1016c5:	jrcxz  0x756c3e1016cc
    756c3e1016c7:	jmp    0x756c3e102f53
    756c3e1016cc:	movdqa xmm11,xmm0
    756c3e1016d1:	movdqu XMMWORD PTR [r12+0x210],xmm11
    756c3e1016db:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    756c3e1016e5:	movdqu xmm1,XMMWORD PTR [r12+0x1b0]
    756c3e1016ef:	por    xmm0,xmm1
    756c3e1016f3:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    756c3e1016fd:	movdqa xmm0,xmm9
    756c3e101702:	movdqa xmm1,xmm5
    756c3e101706:	pshufd xmm1,xmm1,0x44
    756c3e10170b:	mulpd  xmm0,xmm1
    756c3e10170f:	movdqa xmm14,xmm0
    756c3e101714:	movdqu xmm15,XMMWORD PTR [rip+0x8b73]        # 0x756c3e10a290
    756c3e10171d:	pand   xmm14,xmm15
    756c3e101722:	movdqu xmm15,XMMWORD PTR [rip+0x8b75]        # 0x756c3e10a2a0
    756c3e10172b:	pcmpeqq xmm14,xmm15
    756c3e101731:	movdqa xmm15,xmm0
    756c3e101736:	cmpunordpd xmm15,xmm0
    756c3e10173c:	por    xmm14,xmm15
    756c3e101741:	pmovmskb ecx,xmm14
    756c3e101746:	jrcxz  0x756c3e10174d
    756c3e101748:	jmp    0x756c3e102f79
    756c3e10174d:	movdqa xmm12,xmm0
    756c3e101752:	movdqu XMMWORD PTR [r12+0x170],xmm12
    756c3e10175c:	mov    r13,r14
    756c3e10175f:	add    r13,0xd0
    756c3e101766:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    756c3e10176c:	movdqu XMMWORD PTR [r12+0x110],xmm5
    756c3e101776:	movdqa xmm0,xmm4
    756c3e10177a:	movdqa xmm1,xmm2
    756c3e10177e:	addpd  xmm0,xmm1
    756c3e101782:	movdqa xmm14,xmm0
    756c3e101787:	movdqu xmm15,XMMWORD PTR [rip+0x8b00]        # 0x756c3e10a290
    756c3e101790:	pand   xmm14,xmm15
    756c3e101795:	movdqu xmm15,XMMWORD PTR [rip+0x8b02]        # 0x756c3e10a2a0
    756c3e10179e:	pcmpeqq xmm14,xmm15
    756c3e1017a4:	movdqa xmm15,xmm0
    756c3e1017a9:	cmpunordpd xmm15,xmm0
    756c3e1017af:	por    xmm14,xmm15
    756c3e1017b4:	pmovmskb ecx,xmm14
    756c3e1017b9:	jrcxz  0x756c3e1017c0
    756c3e1017bb:	jmp    0x756c3e102f9e
    756c3e1017c0:	movdqa xmm9,xmm0
    756c3e1017c5:	movdqu XMMWORD PTR [r12+0x220],xmm9
    756c3e1017cf:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    756c3e1017d9:	movdqa xmm0,xmm13
    756c3e1017de:	movdqa xmm1,xmm2
    756c3e1017e2:	pshufd xmm1,xmm1,0x44
    756c3e1017e7:	mulpd  xmm0,xmm1
    756c3e1017eb:	movdqa xmm14,xmm0
    756c3e1017f0:	movdqu xmm15,XMMWORD PTR [rip+0x8a97]        # 0x756c3e10a290
    756c3e1017f9:	pand   xmm14,xmm15
    756c3e1017fe:	movdqu xmm15,XMMWORD PTR [rip+0x8a99]        # 0x756c3e10a2a0
    756c3e101807:	pcmpeqq xmm14,xmm15
    756c3e10180d:	movdqa xmm15,xmm0
    756c3e101812:	cmpunordpd xmm15,xmm0
    756c3e101818:	por    xmm14,xmm15
    756c3e10181d:	pmovmskb ecx,xmm14
    756c3e101822:	jrcxz  0x756c3e101829
    756c3e101824:	jmp    0x756c3e102fc2
    756c3e101829:	movdqa xmm4,xmm0
    756c3e10182d:	movdqu XMMWORD PTR [r12+0x260],xmm4
    756c3e101837:	mov    r13d,0x0
    756c3e10183d:	mov    ebp,0x0
    756c3e101842:	mov    QWORD PTR [r12+0x1b0],r13
    756c3e10184a:	mov    QWORD PTR [r12+0x1b8],rbp
    756c3e101852:	movdqa xmm0,xmm5
    756c3e101856:	movdqa xmm1,xmm2
    756c3e10185a:	pshufd xmm1,xmm1,0x44
    756c3e10185f:	mulpd  xmm0,xmm1
    756c3e101863:	movdqa xmm14,xmm0
    756c3e101868:	movdqu xmm15,XMMWORD PTR [rip+0x8a1f]        # 0x756c3e10a290
    756c3e101871:	pand   xmm14,xmm15
    756c3e101876:	movdqu xmm15,XMMWORD PTR [rip+0x8a21]        # 0x756c3e10a2a0
    756c3e10187f:	pcmpeqq xmm14,xmm15
    756c3e101885:	movdqa xmm15,xmm0
    756c3e10188a:	cmpunordpd xmm15,xmm0
    756c3e101890:	por    xmm14,xmm15
    756c3e101895:	pmovmskb ecx,xmm14
    756c3e10189a:	jrcxz  0x756c3e1018a1
    756c3e10189c:	jmp    0x756c3e102fe7
    756c3e1018a1:	movdqa xmm13,xmm0
    756c3e1018a6:	movdqu XMMWORD PTR [r12+0x230],xmm13
    756c3e1018b0:	mov    r13,r14
    756c3e1018b3:	add    r13,0xc0
    756c3e1018ba:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    756c3e1018c0:	movdqu XMMWORD PTR [r12+0x110],xmm5
    756c3e1018ca:	movdqa xmm0,xmm3
    756c3e1018ce:	movdqa xmm1,xmm6
    756c3e1018d2:	addpd  xmm0,xmm1
    756c3e1018d6:	movdqa xmm14,xmm0
    756c3e1018db:	movdqu xmm15,XMMWORD PTR [rip+0x89ac]        # 0x756c3e10a290
    756c3e1018e4:	pand   xmm14,xmm15
    756c3e1018e9:	movdqu xmm15,XMMWORD PTR [rip+0x89ae]        # 0x756c3e10a2a0
    756c3e1018f2:	pcmpeqq xmm14,xmm15
    756c3e1018f8:	movdqa xmm15,xmm0
    756c3e1018fd:	cmpunordpd xmm15,xmm0
    756c3e101903:	por    xmm14,xmm15
    756c3e101908:	pmovmskb ecx,xmm14
    756c3e10190d:	jrcxz  0x756c3e101914
    756c3e10190f:	jmp    0x756c3e10300b
    756c3e101914:	movdqa xmm8,xmm0
    756c3e101919:	movdqu XMMWORD PTR [r12+0x240],xmm8
    756c3e101923:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    756c3e10192d:	movdqu xmm1,XMMWORD PTR [r12+0x1a0]
    756c3e101937:	por    xmm0,xmm1
    756c3e10193b:	movdqu XMMWORD PTR [r12+0x270],xmm0
    756c3e101945:	movdqu xmm6,XMMWORD PTR [r12+0x120]
    756c3e10194f:	movdqu xmm1,XMMWORD PTR [r12+0x120]
    756c3e101959:	por    xmm6,xmm1
    756c3e10195d:	movdqu XMMWORD PTR [r12+0x1a0],xmm6
    756c3e101967:	movdqa xmm0,xmm5
    756c3e10196b:	movdqa xmm1,xmm2
    756c3e10196f:	pshufd xmm1,xmm1,0x44
    756c3e101974:	mulpd  xmm0,xmm1
    756c3e101978:	movdqa xmm14,xmm0
    756c3e10197d:	movdqu xmm15,XMMWORD PTR [rip+0x890a]        # 0x756c3e10a290
    756c3e101986:	pand   xmm14,xmm15
    756c3e10198b:	movdqu xmm15,XMMWORD PTR [rip+0x890c]        # 0x756c3e10a2a0
    756c3e101994:	pcmpeqq xmm14,xmm15
    756c3e10199a:	movdqa xmm15,xmm0
    756c3e10199f:	cmpunordpd xmm15,xmm0
    756c3e1019a5:	por    xmm14,xmm15
    756c3e1019aa:	pmovmskb ecx,xmm14
    756c3e1019af:	jrcxz  0x756c3e1019b6
    756c3e1019b1:	jmp    0x756c3e10302f
    756c3e1019b6:	movdqa xmm6,xmm0
    756c3e1019ba:	movdqu XMMWORD PTR [r12+0x250],xmm6
    756c3e1019c4:	mov    r13,r14
    756c3e1019c7:	add    r13,0x20
    756c3e1019cb:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    756c3e1019d1:	movdqu XMMWORD PTR [r12+0x110],xmm5
    756c3e1019db:	movdqa xmm0,xmm10
    756c3e1019e0:	movdqa xmm1,xmm12
    756c3e1019e5:	addpd  xmm0,xmm1
    756c3e1019e9:	movdqa xmm14,xmm0
    756c3e1019ee:	movdqu xmm15,XMMWORD PTR [rip+0x8899]        # 0x756c3e10a290
    756c3e1019f7:	pand   xmm14,xmm15
    756c3e1019fc:	movdqu xmm15,XMMWORD PTR [rip+0x889b]        # 0x756c3e10a2a0
    756c3e101a05:	pcmpeqq xmm14,xmm15
    756c3e101a0b:	movdqa xmm15,xmm0
    756c3e101a10:	cmpunordpd xmm15,xmm0
    756c3e101a16:	por    xmm14,xmm15
    756c3e101a1b:	pmovmskb ecx,xmm14
    756c3e101a20:	jrcxz  0x756c3e101a27
    756c3e101a22:	jmp    0x756c3e103053
    756c3e101a27:	movdqa xmm3,xmm0
    756c3e101a2b:	movdqa xmm0,xmm7
    756c3e101a2f:	movdqa xmm1,xmm2
    756c3e101a33:	pshufd xmm1,xmm1,0x44
    756c3e101a38:	mulpd  xmm0,xmm1
    756c3e101a3c:	movdqa xmm14,xmm0
    756c3e101a41:	movdqu xmm15,XMMWORD PTR [rip+0x8846]        # 0x756c3e10a290
    756c3e101a4a:	pand   xmm14,xmm15
    756c3e101a4f:	movdqu xmm15,XMMWORD PTR [rip+0x8848]        # 0x756c3e10a2a0
    756c3e101a58:	pcmpeqq xmm14,xmm15
    756c3e101a5e:	movdqa xmm15,xmm0
    756c3e101a63:	cmpunordpd xmm15,xmm0
    756c3e101a69:	por    xmm14,xmm15
    756c3e101a6e:	pmovmskb ecx,xmm14
    756c3e101a73:	jrcxz  0x756c3e101a7a
    756c3e101a75:	jmp    0x756c3e103079
    756c3e101a7a:	movdqa xmm10,xmm0
    756c3e101a7f:	movdqa xmm0,xmm11
    756c3e101a84:	movdqa xmm1,xmm13
    756c3e101a89:	addpd  xmm0,xmm1
    756c3e101a8d:	movdqa xmm14,xmm0
    756c3e101a92:	movdqu xmm15,XMMWORD PTR [rip+0x87f5]        # 0x756c3e10a290
    756c3e101a9b:	pand   xmm14,xmm15
    756c3e101aa0:	movdqu xmm15,XMMWORD PTR [rip+0x87f7]        # 0x756c3e10a2a0
    756c3e101aa9:	pcmpeqq xmm14,xmm15
    756c3e101aaf:	movdqa xmm15,xmm0
    756c3e101ab4:	cmpunordpd xmm15,xmm0
    756c3e101aba:	por    xmm14,xmm15
    756c3e101abf:	pmovmskb ecx,xmm14
    756c3e101ac4:	jrcxz  0x756c3e101acb
    756c3e101ac6:	jmp    0x756c3e10309d
    756c3e101acb:	movdqa xmm2,xmm0
    756c3e101acf:	movdqu xmm7,XMMWORD PTR [r12+0x150]
    756c3e101ad9:	movdqa xmm0,xmm5
    756c3e101add:	movdqa xmm1,xmm7
    756c3e101ae1:	pshufd xmm1,xmm1,0x44
    756c3e101ae6:	mulpd  xmm0,xmm1
    756c3e101aea:	movdqa xmm14,xmm0
    756c3e101aef:	movdqu xmm15,XMMWORD PTR [rip+0x8798]        # 0x756c3e10a290
    756c3e101af8:	pand   xmm14,xmm15
    756c3e101afd:	movdqu xmm15,XMMWORD PTR [rip+0x879a]        # 0x756c3e10a2a0
    756c3e101b06:	pcmpeqq xmm14,xmm15
    756c3e101b0c:	movdqa xmm15,xmm0
    756c3e101b11:	cmpunordpd xmm15,xmm0
    756c3e101b17:	por    xmm14,xmm15
    756c3e101b1c:	pmovmskb ecx,xmm14
    756c3e101b21:	jrcxz  0x756c3e101b28
    756c3e101b23:	jmp    0x756c3e1030c3
    756c3e101b28:	movdqa xmm11,xmm0
    756c3e101b2d:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    756c3e101b37:	movdqa xmm1,xmm7
    756c3e101b3b:	pshufd xmm1,xmm1,0x44
    756c3e101b40:	mulpd  xmm0,xmm1
    756c3e101b44:	movdqa xmm14,xmm0
    756c3e101b49:	movdqu xmm15,XMMWORD PTR [rip+0x873e]        # 0x756c3e10a290
    756c3e101b52:	pand   xmm14,xmm15
    756c3e101b57:	movdqu xmm15,XMMWORD PTR [rip+0x8740]        # 0x756c3e10a2a0
    756c3e101b60:	pcmpeqq xmm14,xmm15
    756c3e101b66:	movdqa xmm15,xmm0
    756c3e101b6b:	cmpunordpd xmm15,xmm0
    756c3e101b71:	por    xmm14,xmm15
    756c3e101b76:	pmovmskb ecx,xmm14
    756c3e101b7b:	jrcxz  0x756c3e101b82
    756c3e101b7d:	jmp    0x756c3e1030e7
    756c3e101b82:	movdqa xmm5,xmm0
    756c3e101b86:	movdqa xmm0,xmm8
    756c3e101b8b:	movdqa xmm1,xmm4
    756c3e101b8f:	addpd  xmm0,xmm1
    756c3e101b93:	movdqa xmm14,xmm0
    756c3e101b98:	movdqu xmm15,XMMWORD PTR [rip+0x86ef]        # 0x756c3e10a290
    756c3e101ba1:	pand   xmm14,xmm15
    756c3e101ba6:	movdqu xmm15,XMMWORD PTR [rip+0x86f1]        # 0x756c3e10a2a0
    756c3e101baf:	pcmpeqq xmm14,xmm15
    756c3e101bb5:	movdqa xmm15,xmm0
    756c3e101bba:	cmpunordpd xmm15,xmm0
    756c3e101bc0:	por    xmm14,xmm15
    756c3e101bc5:	pmovmskb ecx,xmm14
    756c3e101bca:	jrcxz  0x756c3e101bd1
    756c3e101bcc:	jmp    0x756c3e103111
    756c3e101bd1:	movdqa xmm12,xmm0
    756c3e101bd6:	movdqu XMMWORD PTR [r12+0x240],xmm12
    756c3e101be0:	movdqa xmm0,xmm9
    756c3e101be5:	movdqa xmm1,xmm6
    756c3e101be9:	addpd  xmm0,xmm1
    756c3e101bed:	movdqa xmm14,xmm0
    756c3e101bf2:	movdqu xmm15,XMMWORD PTR [rip+0x8695]        # 0x756c3e10a290
    756c3e101bfb:	pand   xmm14,xmm15
    756c3e101c00:	movdqu xmm15,XMMWORD PTR [rip+0x8697]        # 0x756c3e10a2a0
    756c3e101c09:	pcmpeqq xmm14,xmm15
    756c3e101c0f:	movdqa xmm15,xmm0
    756c3e101c14:	cmpunordpd xmm15,xmm0
    756c3e101c1a:	por    xmm14,xmm15
    756c3e101c1f:	pmovmskb ecx,xmm14
    756c3e101c24:	jrcxz  0x756c3e101c2b
    756c3e101c26:	jmp    0x756c3e103136
    756c3e101c2b:	movdqa xmm4,xmm0
    756c3e101c2f:	movdqu XMMWORD PTR [r12+0x220],xmm4
    756c3e101c39:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    756c3e101c43:	movdqa xmm1,xmm7
    756c3e101c47:	pshufd xmm1,xmm1,0x44
    756c3e101c4c:	mulpd  xmm0,xmm1
    756c3e101c50:	movdqa xmm14,xmm0
    756c3e101c55:	movdqu xmm15,XMMWORD PTR [rip+0x8632]        # 0x756c3e10a290
    756c3e101c5e:	pand   xmm14,xmm15
    756c3e101c63:	movdqu xmm15,XMMWORD PTR [rip+0x8634]        # 0x756c3e10a2a0
    756c3e101c6c:	pcmpeqq xmm14,xmm15
    756c3e101c72:	movdqa xmm15,xmm0
    756c3e101c77:	cmpunordpd xmm15,xmm0
    756c3e101c7d:	por    xmm14,xmm15
    756c3e101c82:	pmovmskb ecx,xmm14
    756c3e101c87:	jrcxz  0x756c3e101c8e
    756c3e101c89:	jmp    0x756c3e10315b
    756c3e101c8e:	movdqa xmm6,xmm0
    756c3e101c92:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    756c3e101c9c:	movdqa xmm1,xmm7
    756c3e101ca0:	pshufd xmm1,xmm1,0x44
    756c3e101ca5:	mulpd  xmm0,xmm1
    756c3e101ca9:	movdqa xmm14,xmm0
    756c3e101cae:	movdqu xmm15,XMMWORD PTR [rip+0x85d9]        # 0x756c3e10a290
    756c3e101cb7:	pand   xmm14,xmm15
    756c3e101cbc:	movdqu xmm15,XMMWORD PTR [rip+0x85db]        # 0x756c3e10a2a0
    756c3e101cc5:	pcmpeqq xmm14,xmm15
    756c3e101ccb:	movdqa xmm15,xmm0
    756c3e101cd0:	cmpunordpd xmm15,xmm0
    756c3e101cd6:	por    xmm14,xmm15
    756c3e101cdb:	pmovmskb ecx,xmm14
    756c3e101ce0:	jrcxz  0x756c3e101ce7
    756c3e101ce2:	jmp    0x756c3e103185
    756c3e101ce7:	movdqa xmm8,xmm0
    756c3e101cec:	movdqu XMMWORD PTR [r12+0x150],xmm8
    756c3e101cf6:	movdqa xmm0,xmm3
    756c3e101cfa:	movdqa xmm1,xmm10
    756c3e101cff:	addpd  xmm0,xmm1
    756c3e101d03:	movdqa xmm14,xmm0
    756c3e101d08:	movdqu xmm15,XMMWORD PTR [rip+0x857f]        # 0x756c3e10a290
    756c3e101d11:	pand   xmm14,xmm15
    756c3e101d16:	movdqu xmm15,XMMWORD PTR [rip+0x8581]        # 0x756c3e10a2a0
    756c3e101d1f:	pcmpeqq xmm14,xmm15
    756c3e101d25:	movdqa xmm15,xmm0
    756c3e101d2a:	cmpunordpd xmm15,xmm0
    756c3e101d30:	por    xmm14,xmm15
    756c3e101d35:	pmovmskb ecx,xmm14
    756c3e101d3a:	jrcxz  0x756c3e101d41
    756c3e101d3c:	jmp    0x756c3e1031af
    756c3e101d41:	movdqa xmm7,xmm0
    756c3e101d45:	movdqu XMMWORD PTR [r12+0x160],xmm7
    756c3e101d4f:	movdqa xmm0,xmm2
    756c3e101d53:	movdqa xmm1,xmm11
    756c3e101d58:	addpd  xmm0,xmm1
    756c3e101d5c:	movdqa xmm14,xmm0
    756c3e101d61:	movdqu xmm15,XMMWORD PTR [rip+0x8526]        # 0x756c3e10a290
    756c3e101d6a:	pand   xmm14,xmm15
    756c3e101d6f:	movdqu xmm15,XMMWORD PTR [rip+0x8528]        # 0x756c3e10a2a0
    756c3e101d78:	pcmpeqq xmm14,xmm15
    756c3e101d7e:	movdqa xmm15,xmm0
    756c3e101d83:	cmpunordpd xmm15,xmm0
    756c3e101d89:	por    xmm14,xmm15
    756c3e101d8e:	pmovmskb ecx,xmm14
    756c3e101d93:	jrcxz  0x756c3e101d9a
    756c3e101d95:	jmp    0x756c3e1031d4
    756c3e101d9a:	movdqa xmm3,xmm0
    756c3e101d9e:	movdqu XMMWORD PTR [r12+0x170],xmm3
    756c3e101da8:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    756c3e101db2:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    756c3e101dbc:	movdqa xmm1,xmm2
    756c3e101dc0:	pshufd xmm1,xmm1,0x44
    756c3e101dc5:	mulpd  xmm0,xmm1
    756c3e101dc9:	movdqa xmm14,xmm0
    756c3e101dce:	movdqu xmm15,XMMWORD PTR [rip+0x84b9]        # 0x756c3e10a290
    756c3e101dd7:	pand   xmm14,xmm15
    756c3e101ddc:	movdqu xmm15,XMMWORD PTR [rip+0x84bb]        # 0x756c3e10a2a0
    756c3e101de5:	pcmpeqq xmm14,xmm15
    756c3e101deb:	movdqa xmm15,xmm0
    756c3e101df0:	cmpunordpd xmm15,xmm0
    756c3e101df6:	por    xmm14,xmm15
    756c3e101dfb:	pmovmskb ecx,xmm14
    756c3e101e00:	jrcxz  0x756c3e101e07
    756c3e101e02:	jmp    0x756c3e1031f9
    756c3e101e07:	movdqa xmm9,xmm0
    756c3e101e0c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    756c3e101e16:	movdqa xmm0,xmm4
    756c3e101e1a:	movdqa xmm1,xmm5
    756c3e101e1e:	addpd  xmm0,xmm1
    756c3e101e22:	movdqa xmm14,xmm0
    756c3e101e27:	movdqu xmm15,XMMWORD PTR [rip+0x8460]        # 0x756c3e10a290
    756c3e101e30:	pand   xmm14,xmm15
    756c3e101e35:	movdqu xmm15,XMMWORD PTR [rip+0x8462]        # 0x756c3e10a2a0
    756c3e101e3e:	pcmpeqq xmm14,xmm15
    756c3e101e44:	movdqa xmm15,xmm0
    756c3e101e49:	cmpunordpd xmm15,xmm0
    756c3e101e4f:	por    xmm14,xmm15
    756c3e101e54:	pmovmskb ecx,xmm14
    756c3e101e59:	jrcxz  0x756c3e101e60
    756c3e101e5b:	jmp    0x756c3e103223
    756c3e101e60:	movdqa xmm10,xmm0
    756c3e101e65:	movdqu XMMWORD PTR [r12+0x210],xmm10
    756c3e101e6f:	movdqa xmm0,xmm12
    756c3e101e74:	movdqa xmm1,xmm6
    756c3e101e78:	addpd  xmm0,xmm1
    756c3e101e7c:	movdqa xmm14,xmm0
    756c3e101e81:	movdqu xmm15,XMMWORD PTR [rip+0x8406]        # 0x756c3e10a290
    756c3e101e8a:	pand   xmm14,xmm15
    756c3e101e8f:	movdqu xmm15,XMMWORD PTR [rip+0x8408]        # 0x756c3e10a2a0
    756c3e101e98:	pcmpeqq xmm14,xmm15
    756c3e101e9e:	movdqa xmm15,xmm0
    756c3e101ea3:	cmpunordpd xmm15,xmm0
    756c3e101ea9:	por    xmm14,xmm15
    756c3e101eae:	pmovmskb ecx,xmm14
    756c3e101eb3:	jrcxz  0x756c3e101eba
    756c3e101eb5:	jmp    0x756c3e103247
    756c3e101eba:	movdqa xmm4,xmm0
    756c3e101ebe:	movdqu XMMWORD PTR [r12+0x230],xmm4
    756c3e101ec8:	movdqu xmm5,XMMWORD PTR [r12+0x2a0]
    756c3e101ed2:	movdqu xmm1,XMMWORD PTR [r12+0x2a0]
    756c3e101edc:	por    xmm5,xmm1
    756c3e101ee0:	movdqu XMMWORD PTR [r12+0x250],xmm5
    756c3e101eea:	movdqu xmm5,XMMWORD PTR [r12+0x1d0]
    756c3e101ef4:	movdqu xmm1,XMMWORD PTR [r12+0x1d0]
    756c3e101efe:	por    xmm5,xmm1
    756c3e101f02:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    756c3e101f0c:	movdqu xmm6,XMMWORD PTR [r12+0x2c0]
    756c3e101f16:	movdqu xmm1,XMMWORD PTR [r12+0x2c0]
    756c3e101f20:	por    xmm6,xmm1
    756c3e101f24:	movdqu XMMWORD PTR [r12+0x1d0],xmm6
    756c3e101f2e:	mov    r13,r14
    756c3e101f31:	add    r13,0x40
    756c3e101f35:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    756c3e101f3b:	movdqu XMMWORD PTR [r12+0x2c0],xmm6
    756c3e101f45:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    756c3e101f4f:	movdqa xmm1,xmm2
    756c3e101f53:	pshufd xmm1,xmm1,0x44
    756c3e101f58:	mulpd  xmm0,xmm1
    756c3e101f5c:	movdqa xmm14,xmm0
    756c3e101f61:	movdqu xmm15,XMMWORD PTR [rip+0x8326]        # 0x756c3e10a290
    756c3e101f6a:	pand   xmm14,xmm15
    756c3e101f6f:	movdqu xmm15,XMMWORD PTR [rip+0x8328]        # 0x756c3e10a2a0
    756c3e101f78:	pcmpeqq xmm14,xmm15
    756c3e101f7e:	movdqa xmm15,xmm0
    756c3e101f83:	cmpunordpd xmm15,xmm0
    756c3e101f89:	por    xmm14,xmm15
    756c3e101f8e:	pmovmskb ecx,xmm14
    756c3e101f93:	jrcxz  0x756c3e101f9a
    756c3e101f95:	jmp    0x756c3e10326c
    756c3e101f9a:	movdqa xmm11,xmm0
    756c3e101f9f:	movdqa xmm0,xmm7
    756c3e101fa3:	movdqa xmm1,xmm8
    756c3e101fa8:	addpd  xmm0,xmm1
    756c3e101fac:	movdqa xmm14,xmm0
    756c3e101fb1:	movdqu xmm15,XMMWORD PTR [rip+0x82d6]        # 0x756c3e10a290
    756c3e101fba:	pand   xmm14,xmm15
    756c3e101fbf:	movdqu xmm15,XMMWORD PTR [rip+0x82d8]        # 0x756c3e10a2a0
    756c3e101fc8:	pcmpeqq xmm14,xmm15
    756c3e101fce:	movdqa xmm15,xmm0
    756c3e101fd3:	cmpunordpd xmm15,xmm0
    756c3e101fd9:	por    xmm14,xmm15
    756c3e101fde:	pmovmskb ecx,xmm14
    756c3e101fe3:	jrcxz  0x756c3e101fea
    756c3e101fe5:	jmp    0x756c3e103296
    756c3e101fea:	movdqa xmm12,xmm0
    756c3e101fef:	movdqa xmm0,xmm3
    756c3e101ff3:	movdqa xmm1,xmm9
    756c3e101ff8:	addpd  xmm0,xmm1
    756c3e101ffc:	movdqa xmm14,xmm0
    756c3e102001:	movdqu xmm15,XMMWORD PTR [rip+0x8286]        # 0x756c3e10a290
    756c3e10200a:	pand   xmm14,xmm15
    756c3e10200f:	movdqu xmm15,XMMWORD PTR [rip+0x8288]        # 0x756c3e10a2a0
    756c3e102018:	pcmpeqq xmm14,xmm15
    756c3e10201e:	movdqa xmm15,xmm0
    756c3e102023:	cmpunordpd xmm15,xmm0
    756c3e102029:	por    xmm14,xmm15
    756c3e10202e:	pmovmskb ecx,xmm14
    756c3e102033:	jrcxz  0x756c3e10203a
    756c3e102035:	jmp    0x756c3e1032bb
    756c3e10203a:	movdqa xmm7,xmm0
    756c3e10203e:	movdqu XMMWORD PTR [r12+0x160],xmm7
    756c3e102048:	movdqa xmm0,xmm6
    756c3e10204c:	movdqa xmm1,xmm2
    756c3e102050:	pshufd xmm1,xmm1,0x44
    756c3e102055:	mulpd  xmm0,xmm1
    756c3e102059:	movdqa xmm14,xmm0
    756c3e10205e:	movdqu xmm15,XMMWORD PTR [rip+0x8229]        # 0x756c3e10a290
    756c3e102067:	pand   xmm14,xmm15
    756c3e10206c:	movdqu xmm15,XMMWORD PTR [rip+0x822b]        # 0x756c3e10a2a0
    756c3e102075:	pcmpeqq xmm14,xmm15
    756c3e10207b:	movdqa xmm15,xmm0
    756c3e102080:	cmpunordpd xmm15,xmm0
    756c3e102086:	por    xmm14,xmm15
    756c3e10208b:	pmovmskb ecx,xmm14
    756c3e102090:	jrcxz  0x756c3e102097
    756c3e102092:	jmp    0x756c3e1032e0
    756c3e102097:	movdqa xmm3,xmm0
    756c3e10209b:	movdqu XMMWORD PTR [r12+0x240],xmm3
    756c3e1020a5:	movdqu xmm6,XMMWORD PTR [r12+0x2b0]
    756c3e1020af:	movdqa xmm0,xmm6
    756c3e1020b3:	movdqa xmm1,xmm2
    756c3e1020b7:	pshufd xmm1,xmm1,0x44
    756c3e1020bc:	mulpd  xmm0,xmm1
    756c3e1020c0:	movdqa xmm14,xmm0
    756c3e1020c5:	movdqu xmm15,XMMWORD PTR [rip+0x81c2]        # 0x756c3e10a290
    756c3e1020ce:	pand   xmm14,xmm15
    756c3e1020d3:	movdqu xmm15,XMMWORD PTR [rip+0x81c4]        # 0x756c3e10a2a0
    756c3e1020dc:	pcmpeqq xmm14,xmm15
    756c3e1020e2:	movdqa xmm15,xmm0
    756c3e1020e7:	cmpunordpd xmm15,xmm0
    756c3e1020ed:	por    xmm14,xmm15
    756c3e1020f2:	pmovmskb ecx,xmm14
    756c3e1020f7:	jrcxz  0x756c3e1020fe
    756c3e1020f9:	jmp    0x756c3e103304
    756c3e1020fe:	movdqa xmm8,xmm0
    756c3e102103:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    756c3e10210d:	movdqa xmm0,xmm5
    756c3e102111:	movdqa xmm1,xmm2
    756c3e102115:	pshufd xmm1,xmm1,0x44
    756c3e10211a:	mulpd  xmm0,xmm1
    756c3e10211e:	movdqa xmm14,xmm0
    756c3e102123:	movdqu xmm15,XMMWORD PTR [rip+0x8164]        # 0x756c3e10a290
    756c3e10212c:	pand   xmm14,xmm15
    756c3e102131:	movdqu xmm15,XMMWORD PTR [rip+0x8166]        # 0x756c3e10a2a0
    756c3e10213a:	pcmpeqq xmm14,xmm15
    756c3e102140:	movdqa xmm15,xmm0
    756c3e102145:	cmpunordpd xmm15,xmm0
    756c3e10214b:	por    xmm14,xmm15
    756c3e102150:	pmovmskb ecx,xmm14
    756c3e102155:	jrcxz  0x756c3e10215c
    756c3e102157:	jmp    0x756c3e103328
    756c3e10215c:	movdqa xmm6,xmm0
    756c3e102160:	movdqu XMMWORD PTR [r12+0x170],xmm6
    756c3e10216a:	movdqa xmm0,xmm10
    756c3e10216f:	movdqa xmm1,xmm11
    756c3e102174:	addpd  xmm0,xmm1
    756c3e102178:	movdqa xmm14,xmm0
    756c3e10217d:	movdqu xmm15,XMMWORD PTR [rip+0x810a]        # 0x756c3e10a290
    756c3e102186:	pand   xmm14,xmm15
    756c3e10218b:	movdqu xmm15,XMMWORD PTR [rip+0x810c]        # 0x756c3e10a2a0
    756c3e102194:	pcmpeqq xmm14,xmm15
    756c3e10219a:	movdqa xmm15,xmm0
    756c3e10219f:	cmpunordpd xmm15,xmm0
    756c3e1021a5:	por    xmm14,xmm15
    756c3e1021aa:	pmovmskb ecx,xmm14
    756c3e1021af:	jrcxz  0x756c3e1021b6
    756c3e1021b1:	jmp    0x756c3e10334c
    756c3e1021b6:	movdqa xmm5,xmm0
    756c3e1021ba:	movdqu XMMWORD PTR [r12+0x180],xmm5
    756c3e1021c4:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    756c3e1021ce:	movdqa xmm1,xmm2
    756c3e1021d2:	pshufd xmm1,xmm1,0x44
    756c3e1021d7:	mulpd  xmm0,xmm1
    756c3e1021db:	movdqa xmm14,xmm0
    756c3e1021e0:	movdqu xmm15,XMMWORD PTR [rip+0x80a7]        # 0x756c3e10a290
    756c3e1021e9:	pand   xmm14,xmm15
    756c3e1021ee:	movdqu xmm15,XMMWORD PTR [rip+0x80a9]        # 0x756c3e10a2a0
    756c3e1021f7:	pcmpeqq xmm14,xmm15
    756c3e1021fd:	movdqa xmm15,xmm0
    756c3e102202:	cmpunordpd xmm15,xmm0
    756c3e102208:	por    xmm14,xmm15
    756c3e10220d:	pmovmskb ecx,xmm14
    756c3e102212:	jrcxz  0x756c3e102219
    756c3e102214:	jmp    0x756c3e103372
    756c3e102219:	movdqa xmm9,xmm0
    756c3e10221e:	movdqu XMMWORD PTR [r12+0x210],xmm9
    756c3e102228:	movdqa xmm0,xmm4
    756c3e10222c:	movdqa xmm1,xmm3
    756c3e102230:	addpd  xmm0,xmm1
    756c3e102234:	movdqa xmm14,xmm0
    756c3e102239:	movdqu xmm15,XMMWORD PTR [rip+0x804e]        # 0x756c3e10a290
    756c3e102242:	pand   xmm14,xmm15
    756c3e102247:	movdqu xmm15,XMMWORD PTR [rip+0x8050]        # 0x756c3e10a2a0
    756c3e102250:	pcmpeqq xmm14,xmm15
    756c3e102256:	movdqa xmm15,xmm0
    756c3e10225b:	cmpunordpd xmm15,xmm0
    756c3e102261:	por    xmm14,xmm15
    756c3e102266:	pmovmskb ecx,xmm14
    756c3e10226b:	jrcxz  0x756c3e102272
    756c3e10226d:	jmp    0x756c3e10339c
    756c3e102272:	movdqa xmm10,xmm0
    756c3e102277:	movdqu XMMWORD PTR [r12+0x220],xmm10
    756c3e102281:	movdqu xmm3,XMMWORD PTR [r12+0x290]
    756c3e10228b:	movdqa xmm0,xmm3
    756c3e10228f:	movdqa xmm1,xmm2
    756c3e102293:	pshufd xmm1,xmm1,0x44
    756c3e102298:	mulpd  xmm0,xmm1
    756c3e10229c:	movdqa xmm14,xmm0
    756c3e1022a1:	movdqu xmm15,XMMWORD PTR [rip+0x7fe6]        # 0x756c3e10a290
    756c3e1022aa:	pand   xmm14,xmm15
    756c3e1022af:	movdqu xmm15,XMMWORD PTR [rip+0x7fe8]        # 0x756c3e10a2a0
    756c3e1022b8:	pcmpeqq xmm14,xmm15
    756c3e1022be:	movdqa xmm15,xmm0
    756c3e1022c3:	cmpunordpd xmm15,xmm0
    756c3e1022c9:	por    xmm14,xmm15
    756c3e1022ce:	pmovmskb ecx,xmm14
    756c3e1022d3:	jrcxz  0x756c3e1022da
    756c3e1022d5:	jmp    0x756c3e1033c0
    756c3e1022da:	movdqa xmm4,xmm0
    756c3e1022de:	movdqu XMMWORD PTR [r12+0x230],xmm4
    756c3e1022e8:	movdqa xmm0,xmm12
    756c3e1022ed:	movdqa xmm1,xmm8
    756c3e1022f2:	addpd  xmm0,xmm1
    756c3e1022f6:	movdqa xmm14,xmm0
    756c3e1022fb:	movdqu xmm15,XMMWORD PTR [rip+0x7f8c]        # 0x756c3e10a290
    756c3e102304:	pand   xmm14,xmm15
    756c3e102309:	movdqu xmm15,XMMWORD PTR [rip+0x7f8e]        # 0x756c3e10a2a0
    756c3e102312:	pcmpeqq xmm14,xmm15
    756c3e102318:	movdqa xmm15,xmm0
    756c3e10231d:	cmpunordpd xmm15,xmm0
    756c3e102323:	por    xmm14,xmm15
    756c3e102328:	pmovmskb ecx,xmm14
    756c3e10232d:	jrcxz  0x756c3e102334
    756c3e10232f:	jmp    0x756c3e1033e4
    756c3e102334:	movdqa xmm3,xmm0
    756c3e102338:	movdqu XMMWORD PTR [r12+0x140],xmm3
    756c3e102342:	movdqu xmm8,XMMWORD PTR [r12+0x1e0]
    756c3e10234c:	movdqa xmm0,xmm8
    756c3e102351:	movdqa xmm1,xmm2
    756c3e102355:	pshufd xmm1,xmm1,0x44
    756c3e10235a:	mulpd  xmm0,xmm1
    756c3e10235e:	movdqa xmm14,xmm0
    756c3e102363:	movdqu xmm15,XMMWORD PTR [rip+0x7f24]        # 0x756c3e10a290
    756c3e10236c:	pand   xmm14,xmm15
    756c3e102371:	movdqu xmm15,XMMWORD PTR [rip+0x7f26]        # 0x756c3e10a2a0
    756c3e10237a:	pcmpeqq xmm14,xmm15
    756c3e102380:	movdqa xmm15,xmm0
    756c3e102385:	cmpunordpd xmm15,xmm0
    756c3e10238b:	por    xmm14,xmm15
    756c3e102390:	pmovmskb ecx,xmm14
    756c3e102395:	jrcxz  0x756c3e10239c
    756c3e102397:	jmp    0x756c3e10340a
    756c3e10239c:	movdqa xmm11,xmm0
    756c3e1023a1:	movdqu XMMWORD PTR [r12+0x130],xmm11
    756c3e1023ab:	movdqa xmm0,xmm7
    756c3e1023af:	movdqa xmm1,xmm6
    756c3e1023b3:	addpd  xmm0,xmm1
    756c3e1023b7:	movdqa xmm14,xmm0
    756c3e1023bc:	movdqu xmm15,XMMWORD PTR [rip+0x7ecb]        # 0x756c3e10a290
    756c3e1023c5:	pand   xmm14,xmm15
    756c3e1023ca:	movdqu xmm15,XMMWORD PTR [rip+0x7ecd]        # 0x756c3e10a2a0
    756c3e1023d3:	pcmpeqq xmm14,xmm15
    756c3e1023d9:	movdqa xmm15,xmm0
    756c3e1023de:	cmpunordpd xmm15,xmm0
    756c3e1023e4:	por    xmm14,xmm15
    756c3e1023e9:	pmovmskb ecx,xmm14
    756c3e1023ee:	jrcxz  0x756c3e1023f5
    756c3e1023f0:	jmp    0x756c3e10342f
    756c3e1023f5:	movdqa xmm2,xmm0
    756c3e1023f9:	movdqu XMMWORD PTR [r12+0x150],xmm2
    756c3e102403:	mov    r13,r14
    756c3e102406:	add    r13,0x70
    756c3e10240a:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    756c3e102410:	movdqu XMMWORD PTR [r12+0x240],xmm6
    756c3e10241a:	movdqa xmm0,xmm5
    756c3e10241e:	movdqa xmm1,xmm9
    756c3e102423:	addpd  xmm0,xmm1
    756c3e102427:	movdqa xmm14,xmm0
    756c3e10242c:	movdqu xmm15,XMMWORD PTR [rip+0x7e5b]        # 0x756c3e10a290
    756c3e102435:	pand   xmm14,xmm15
    756c3e10243a:	movdqu xmm15,XMMWORD PTR [rip+0x7e5d]        # 0x756c3e10a2a0
    756c3e102443:	pcmpeqq xmm14,xmm15
    756c3e102449:	movdqa xmm15,xmm0
    756c3e10244e:	cmpunordpd xmm15,xmm0
    756c3e102454:	por    xmm14,xmm15
    756c3e102459:	pmovmskb ecx,xmm14
    756c3e10245e:	jrcxz  0x756c3e102465
    756c3e102460:	jmp    0x756c3e103453
    756c3e102465:	movdqa xmm7,xmm0
    756c3e102469:	movdqu XMMWORD PTR [r12+0x170],xmm7
    756c3e102473:	movdqu xmm5,XMMWORD PTR [r12+0x280]
    756c3e10247d:	movdqa xmm0,xmm6
    756c3e102481:	movdqa xmm1,xmm5
    756c3e102485:	pshufd xmm1,xmm1,0x44
    756c3e10248a:	mulpd  xmm0,xmm1
    756c3e10248e:	movdqa xmm14,xmm0
    756c3e102493:	movdqu xmm15,XMMWORD PTR [rip+0x7df4]        # 0x756c3e10a290
    756c3e10249c:	pand   xmm14,xmm15
    756c3e1024a1:	movdqu xmm15,XMMWORD PTR [rip+0x7df6]        # 0x756c3e10a2a0
    756c3e1024aa:	pcmpeqq xmm14,xmm15
    756c3e1024b0:	movdqa xmm15,xmm0
    756c3e1024b5:	cmpunordpd xmm15,xmm0
    756c3e1024bb:	por    xmm14,xmm15
    756c3e1024c0:	pmovmskb ecx,xmm14
    756c3e1024c5:	jrcxz  0x756c3e1024cc
    756c3e1024c7:	jmp    0x756c3e103478
    756c3e1024cc:	movdqa xmm8,xmm0
    756c3e1024d1:	movdqu XMMWORD PTR [r12+0x160],xmm8
    756c3e1024db:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    756c3e1024e5:	movdqa xmm1,xmm5
    756c3e1024e9:	pshufd xmm1,xmm1,0x44
    756c3e1024ee:	mulpd  xmm0,xmm1
    756c3e1024f2:	movdqa xmm14,xmm0
    756c3e1024f7:	movdqu xmm15,XMMWORD PTR [rip+0x7d90]        # 0x756c3e10a290
    756c3e102500:	pand   xmm14,xmm15
    756c3e102505:	movdqu xmm15,XMMWORD PTR [rip+0x7d92]        # 0x756c3e10a2a0
    756c3e10250e:	pcmpeqq xmm14,xmm15
    756c3e102514:	movdqa xmm15,xmm0
    756c3e102519:	cmpunordpd xmm15,xmm0
    756c3e10251f:	por    xmm14,xmm15
    756c3e102524:	pmovmskb ecx,xmm14
    756c3e102529:	jrcxz  0x756c3e102530
    756c3e10252b:	jmp    0x756c3e10349c
    756c3e102530:	movdqa xmm6,xmm0
    756c3e102534:	movdqu XMMWORD PTR [r12+0x180],xmm6
    756c3e10253e:	movdqa xmm0,xmm10
    756c3e102543:	movdqa xmm1,xmm4
    756c3e102547:	addpd  xmm0,xmm1
    756c3e10254b:	movdqa xmm14,xmm0
    756c3e102550:	movdqu xmm15,XMMWORD PTR [rip+0x7d37]        # 0x756c3e10a290
    756c3e102559:	pand   xmm14,xmm15
    756c3e10255e:	movdqu xmm15,XMMWORD PTR [rip+0x7d39]        # 0x756c3e10a2a0
    756c3e102567:	pcmpeqq xmm14,xmm15
    756c3e10256d:	movdqa xmm15,xmm0
    756c3e102572:	cmpunordpd xmm15,xmm0
    756c3e102578:	por    xmm14,xmm15
    756c3e10257d:	pmovmskb ecx,xmm14
    756c3e102582:	jrcxz  0x756c3e102589
    756c3e102584:	jmp    0x756c3e1034c6
    756c3e102589:	movdqa xmm9,xmm0
    756c3e10258e:	movdqu XMMWORD PTR [r12+0x210],xmm9
    756c3e102598:	mov    r13,r14
    756c3e10259b:	add    r13,0x10
    756c3e10259f:	movdqu xmm4,XMMWORD PTR [r14]
    756c3e1025a4:	movdqu xmm10,XMMWORD PTR [r13+0x0]
    756c3e1025aa:	movdqu XMMWORD PTR [r12+0x230],xmm10
    756c3e1025b4:	movdqa xmm0,xmm3
    756c3e1025b8:	movdqa xmm1,xmm11
    756c3e1025bd:	addpd  xmm0,xmm1
    756c3e1025c1:	movdqa xmm14,xmm0
    756c3e1025c6:	movdqu xmm15,XMMWORD PTR [rip+0x7cc1]        # 0x756c3e10a290
    756c3e1025cf:	pand   xmm14,xmm15
    756c3e1025d4:	movdqu xmm15,XMMWORD PTR [rip+0x7cc3]        # 0x756c3e10a2a0
    756c3e1025dd:	pcmpeqq xmm14,xmm15
    756c3e1025e3:	movdqa xmm15,xmm0
    756c3e1025e8:	cmpunordpd xmm15,xmm0
    756c3e1025ee:	por    xmm14,xmm15
    756c3e1025f3:	pmovmskb ecx,xmm14
    756c3e1025f8:	jrcxz  0x756c3e1025ff
    756c3e1025fa:	jmp    0x756c3e1034eb
    756c3e1025ff:	movdqa xmm12,xmm0
    756c3e102604:	movdqu XMMWORD PTR [r12+0x130],xmm12
    756c3e10260e:	movdqa xmm0,xmm10
    756c3e102613:	movdqa xmm1,xmm5
    756c3e102617:	pshufd xmm1,xmm1,0x44
    756c3e10261c:	mulpd  xmm0,xmm1
    756c3e102620:	movdqa xmm14,xmm0
    756c3e102625:	movdqu xmm15,XMMWORD PTR [rip+0x7c62]        # 0x756c3e10a290
    756c3e10262e:	pand   xmm14,xmm15
    756c3e102633:	movdqu xmm15,XMMWORD PTR [rip+0x7c64]        # 0x756c3e10a2a0
    756c3e10263c:	pcmpeqq xmm14,xmm15
    756c3e102642:	movdqa xmm15,xmm0
    756c3e102647:	cmpunordpd xmm15,xmm0
    756c3e10264d:	por    xmm14,xmm15
    756c3e102652:	pmovmskb ecx,xmm14
    756c3e102657:	jrcxz  0x756c3e10265e
    756c3e102659:	jmp    0x756c3e103510
    756c3e10265e:	movdqa xmm3,xmm0
    756c3e102662:	movdqu XMMWORD PTR [r12+0x220],xmm3
    756c3e10266c:	movdqa xmm0,xmm4
    756c3e102670:	movdqa xmm1,xmm5
    756c3e102674:	pshufd xmm1,xmm1,0x44
    756c3e102679:	mulpd  xmm0,xmm1
    756c3e10267d:	movdqa xmm14,xmm0
    756c3e102682:	movdqu xmm15,XMMWORD PTR [rip+0x7c05]        # 0x756c3e10a290
    756c3e10268b:	pand   xmm14,xmm15
    756c3e102690:	movdqu xmm15,XMMWORD PTR [rip+0x7c07]        # 0x756c3e10a2a0
    756c3e102699:	pcmpeqq xmm14,xmm15
    756c3e10269f:	movdqa xmm15,xmm0
    756c3e1026a4:	cmpunordpd xmm15,xmm0
    756c3e1026aa:	por    xmm14,xmm15
    756c3e1026af:	pmovmskb ecx,xmm14
    756c3e1026b4:	jrcxz  0x756c3e1026bb
    756c3e1026b6:	jmp    0x756c3e103535
    756c3e1026bb:	movdqa xmm10,xmm0
    756c3e1026c0:	movdqa xmm0,xmm2
    756c3e1026c4:	movdqa xmm1,xmm8
    756c3e1026c9:	addpd  xmm0,xmm1
    756c3e1026cd:	movdqa xmm14,xmm0
    756c3e1026d2:	movdqu xmm15,XMMWORD PTR [rip+0x7bb5]        # 0x756c3e10a290
    756c3e1026db:	pand   xmm14,xmm15
    756c3e1026e0:	movdqu xmm15,XMMWORD PTR [rip+0x7bb7]        # 0x756c3e10a2a0
    756c3e1026e9:	pcmpeqq xmm14,xmm15
    756c3e1026ef:	movdqa xmm15,xmm0
    756c3e1026f4:	cmpunordpd xmm15,xmm0
    756c3e1026fa:	por    xmm14,xmm15
    756c3e1026ff:	pmovmskb ecx,xmm14
    756c3e102704:	jrcxz  0x756c3e10270b
    756c3e102706:	jmp    0x756c3e103559
    756c3e10270b:	movdqa xmm4,xmm0
    756c3e10270f:	movdqu XMMWORD PTR [r12+0x140],xmm4
    756c3e102719:	movdqa xmm0,xmm7
    756c3e10271d:	movdqa xmm1,xmm6
    756c3e102721:	addpd  xmm0,xmm1
    756c3e102725:	movdqa xmm14,xmm0
    756c3e10272a:	movdqu xmm15,XMMWORD PTR [rip+0x7b5d]        # 0x756c3e10a290
    756c3e102733:	pand   xmm14,xmm15
    756c3e102738:	movdqu xmm15,XMMWORD PTR [rip+0x7b5f]        # 0x756c3e10a2a0
    756c3e102741:	pcmpeqq xmm14,xmm15
    756c3e102747:	movdqa xmm15,xmm0
    756c3e10274c:	cmpunordpd xmm15,xmm0
    756c3e102752:	por    xmm14,xmm15
    756c3e102757:	pmovmskb ecx,xmm14
    756c3e10275c:	jrcxz  0x756c3e102763
    756c3e10275e:	jmp    0x756c3e10357e
    756c3e102763:	movdqa xmm2,xmm0
    756c3e102767:	movdqu XMMWORD PTR [r12+0x150],xmm2
    756c3e102771:	movdqa xmm0,xmm9
    756c3e102776:	movdqa xmm1,xmm3
    756c3e10277a:	addpd  xmm0,xmm1
    756c3e10277e:	movdqa xmm14,xmm0
    756c3e102783:	movdqu xmm15,XMMWORD PTR [rip+0x7b04]        # 0x756c3e10a290
    756c3e10278c:	pand   xmm14,xmm15
    756c3e102791:	movdqu xmm15,XMMWORD PTR [rip+0x7b06]        # 0x756c3e10a2a0
    756c3e10279a:	pcmpeqq xmm14,xmm15
    756c3e1027a0:	movdqa xmm15,xmm0
    756c3e1027a5:	cmpunordpd xmm15,xmm0
    756c3e1027ab:	por    xmm14,xmm15
    756c3e1027b0:	pmovmskb ecx,xmm14
    756c3e1027b5:	jrcxz  0x756c3e1027bc
    756c3e1027b7:	jmp    0x756c3e1035a2
    756c3e1027bc:	movdqa xmm5,xmm0
    756c3e1027c0:	movdqu XMMWORD PTR [r12+0x160],xmm5
    756c3e1027ca:	movdqa xmm0,xmm12
    756c3e1027cf:	movdqa xmm1,xmm10
    756c3e1027d4:	addpd  xmm0,xmm1
    756c3e1027d8:	movdqa xmm14,xmm0
    756c3e1027dd:	movdqu xmm15,XMMWORD PTR [rip+0x7aaa]        # 0x756c3e10a290
    756c3e1027e6:	pand   xmm14,xmm15
    756c3e1027eb:	movdqu xmm15,XMMWORD PTR [rip+0x7aac]        # 0x756c3e10a2a0
    756c3e1027f4:	pcmpeqq xmm14,xmm15
    756c3e1027fa:	movdqa xmm15,xmm0
    756c3e1027ff:	cmpunordpd xmm15,xmm0
    756c3e102805:	por    xmm14,xmm15
    756c3e10280a:	pmovmskb ecx,xmm14
    756c3e10280f:	jrcxz  0x756c3e102816
    756c3e102811:	jmp    0x756c3e1035c7
    756c3e102816:	movdqa xmm3,xmm0
    756c3e10281a:	movdqu XMMWORD PTR [r12+0x120],xmm3
    756c3e102824:	mov    r13,r15
    756c3e102827:	add    r13,0x10
    756c3e10282b:	movdqu XMMWORD PTR [r15],xmm4
    756c3e102830:	mov    r14d,0x0
    756c3e102836:	mov    DWORD PTR [r12+0x32c],r14d
    756c3e10283e:	movdqu XMMWORD PTR [r13+0x0],xmm2
    756c3e102844:	add    r15,0x20
    756c3e102848:	mov    r13,r15
    756c3e10284b:	add    r13,0x10
    756c3e10284f:	movdqu XMMWORD PTR [r15],xmm5
    756c3e102854:	movdqu XMMWORD PTR [r13+0x0],xmm3
    756c3e10285a:	mov    rcx,QWORD PTR [r12+0x380]
    756c3e102862:	jrcxz  0x756c3e102869
    756c3e102864:	jmp    0x756c3e109ab9
    756c3e102869:	cmp    BYTE PTR [rsp+0x8],0x0
    756c3e10286e:	jne    0x756c3e100b39
    756c3e102874:	jmp    0x756c3e102879
    756c3e102879:	mov    r13d,DWORD PTR [r12+0x48]
    756c3e10287e:	add    r13d,0x1
    756c3e102882:	mov    QWORD PTR [r12+0x48],r13
    756c3e102887:	sub    r13d,0x1f4
    756c3e10288e:	mov    rcx,QWORD PTR [r12+0x380]
    756c3e102896:	jrcxz  0x756c3e10289d
    756c3e102898:	jmp    0x756c3e109b3e
    756c3e10289d:	jne    0x756c3e100b1b
    756c3e1028a3:	mov    r11,rax
    756c3e1028a6:	lahf
    756c3e1028a7:	seto   al
    756c3e1028aa:	mov    WORD PTR [rsp],ax
    756c3e1028ae:	mov    rax,r11
    756c3e1028b1:	jmp    0x756c3e1028b6
    756c3e1028b6:	mov    r13d,0x0
    756c3e1028bc:	mov    QWORD PTR [r12+0x48],r13
    756c3e1028c1:	mov    r13,QWORD PTR [r12+0xf8]
    756c3e1028c9:	mov    r14,r13
    756c3e1028cc:	add    r14,0x140
    756c3e1028d3:	mov    r15,QWORD PTR [r14]
    756c3e1028d6:	mov    QWORD PTR [r12+0xe8],r15
    756c3e1028de:	mov    r14,r13
    756c3e1028e1:	add    r14,0x130
    756c3e1028e8:	mov    r15,r14
    756c3e1028eb:	add    r15,0x8
    756c3e1028ef:	mov    rbp,QWORD PTR [r14]
    756c3e1028f2:	mov    r14,QWORD PTR [r15]
    756c3e1028f5:	mov    r15d,0x0
    756c3e1028fb:	mov    QWORD PTR [r12+0x1a0],rbp
    756c3e102903:	mov    QWORD PTR [r12+0x1a8],r15
    756c3e10290b:	mov    r15d,0x0
    756c3e102911:	mov    QWORD PTR [r12+0x190],r14
    756c3e102919:	mov    QWORD PTR [r12+0x198],r15
    756c3e102921:	mov    r14,r13
    756c3e102924:	add    r14,0x120
    756c3e10292b:	mov    r15,r14
    756c3e10292e:	add    r15,0x8
    756c3e102932:	mov    rbp,QWORD PTR [r14]
    756c3e102935:	mov    r14,QWORD PTR [r15]
    756c3e102938:	mov    r15d,0x0
    756c3e10293e:	mov    QWORD PTR [r12+0x1c0],rbp
    756c3e102946:	mov    QWORD PTR [r12+0x1c8],r15
    756c3e10294e:	mov    r15d,0x0
    756c3e102954:	mov    QWORD PTR [r12+0x1b0],r14
    756c3e10295c:	mov    QWORD PTR [r12+0x1b8],r15
    756c3e102964:	mov    r14,r13
    756c3e102967:	add    r14,0x110
    756c3e10296e:	mov    r15,r14
    756c3e102971:	add    r15,0x8
    756c3e102975:	mov    rbp,QWORD PTR [r14]
    756c3e102978:	mov    r14,QWORD PTR [r15]
    756c3e10297b:	mov    r15d,0x0
    756c3e102981:	mov    QWORD PTR [r12+0x1e0],rbp
    756c3e102989:	mov    QWORD PTR [r12+0x1e8],r15
    756c3e102991:	mov    r15d,0x0
    756c3e102997:	mov    QWORD PTR [r12+0x1d0],r14
    756c3e10299f:	mov    QWORD PTR [r12+0x1d8],r15
    756c3e1029a7:	mov    r14,r13
    756c3e1029aa:	add    r14,0x100
    756c3e1029b1:	mov    r15,r14
    756c3e1029b4:	add    r15,0x8
    756c3e1029b8:	mov    rbp,QWORD PTR [r14]
    756c3e1029bb:	mov    r14,QWORD PTR [r15]
    756c3e1029be:	mov    r15d,0x0
    756c3e1029c4:	mov    QWORD PTR [r12+0x200],rbp
    756c3e1029cc:	mov    QWORD PTR [r12+0x208],r15
    756c3e1029d4:	mov    r15d,0x0
    756c3e1029da:	mov    QWORD PTR [r12+0x1f0],r14
    756c3e1029e2:	mov    QWORD PTR [r12+0x1f8],r15
    756c3e1029ea:	mov    r14d,0x430000
    756c3e1029f0:	mov    QWORD PTR [r12+0x40],r14
    756c3e1029f5:	mov    r14d,0x430510
    756c3e1029fb:	mov    r15,QWORD PTR [r14]
    756c3e1029fe:	mov    r14d,0x0
    756c3e102a04:	mov    QWORD PTR [r12+0x110],r15
    756c3e102a0c:	mov    QWORD PTR [r12+0x118],r14
    756c3e102a14:	add    r13,0x150
    756c3e102a1b:	mov    QWORD PTR [r12+0xf8],r13
    756c3e102a23:	jmp    0x756c3e102a28
    756c3e102a28:	mov    r13,QWORD PTR [r12+0x48]
    756c3e102a2d:	mov    r14,QWORD PTR [r12+0x50]
    756c3e102a32:	add    r14,r13
    756c3e102a35:	movdqu xmm2,XMMWORD PTR [r14]
    756c3e102a3a:	movdqu XMMWORD PTR [r12+0x120],xmm2
    756c3e102a44:	add    r13,0x10
    756c3e102a48:	mov    QWORD PTR [r12+0x48],r13
    756c3e102a4d:	sub    r13,0x200
    756c3e102a54:	mov    r13,QWORD PTR [r12+0x128]
    756c3e102a5c:	mov    r14d,0x0
    756c3e102a62:	mov    QWORD PTR [r12+0x130],r13
    756c3e102a6a:	mov    QWORD PTR [r12+0x138],r14
    756c3e102a72:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    756c3e102a7c:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    756c3e102a86:	movdqa xmm0,xmm2
    756c3e102a8a:	movdqa xmm1,xmm3
    756c3e102a8e:	movq   xmm0,xmm0
    756c3e102a92:	movq   xmm1,xmm1
    756c3e102a96:	addsd  xmm0,xmm1
    756c3e102a9a:	movdqa xmm14,xmm0
    756c3e102a9f:	movdqu xmm15,XMMWORD PTR [rip+0x77e8]        # 0x756c3e10a290
    756c3e102aa8:	pand   xmm14,xmm15
    756c3e102aad:	movdqu xmm15,XMMWORD PTR [rip+0x77ea]        # 0x756c3e10a2a0
    756c3e102ab6:	pcmpeqq xmm14,xmm15
    756c3e102abc:	movdqa xmm15,xmm0
    756c3e102ac1:	cmpunordpd xmm15,xmm0
    756c3e102ac7:	por    xmm14,xmm15
    756c3e102acc:	pmovmskb ecx,xmm14
    756c3e102ad1:	jrcxz  0x756c3e102ad8
    756c3e102ad3:	jmp    0x756c3e1035ed
    756c3e102ad8:	movdqa xmm4,xmm0
    756c3e102adc:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    756c3e102ae6:	movdqa xmm0,xmm4
    756c3e102aea:	movdqa xmm1,xmm2
    756c3e102aee:	movq   xmm0,xmm0
    756c3e102af2:	movq   xmm1,xmm1
    756c3e102af6:	addsd  xmm0,xmm1
    756c3e102afa:	movdqa xmm14,xmm0
    756c3e102aff:	movdqu xmm15,XMMWORD PTR [rip+0x7788]        # 0x756c3e10a290
    756c3e102b08:	pand   xmm14,xmm15
    756c3e102b0d:	movdqu xmm15,XMMWORD PTR [rip+0x778a]        # 0x756c3e10a2a0
    756c3e102b16:	pcmpeqq xmm14,xmm15
    756c3e102b1c:	movdqa xmm15,xmm0
    756c3e102b21:	cmpunordpd xmm15,xmm0
    756c3e102b27:	por    xmm14,xmm15
    756c3e102b2c:	pmovmskb ecx,xmm14
    756c3e102b31:	jrcxz  0x756c3e102b38
    756c3e102b33:	jmp    0x756c3e10362c
    756c3e102b38:	movdqa xmm3,xmm0
    756c3e102b3c:	movdqu XMMWORD PTR [r12+0x110],xmm3
    756c3e102b46:	mov    rcx,QWORD PTR [r12+0x380]
    756c3e102b4e:	jrcxz  0x756c3e102b55
    756c3e102b50:	jmp    0x756c3e109bd2
    756c3e102b55:	jne    0x756c3e102b6e
    756c3e102b5b:	mov    r11,rax
    756c3e102b5e:	lahf
    756c3e102b5f:	seto   al
    756c3e102b62:	mov    WORD PTR [rsp],ax
    756c3e102b66:	mov    rax,r11
    756c3e102b69:	jmp    0x756c3e102b81
    756c3e102b6e:	mov    r11,rax
    756c3e102b71:	lahf
    756c3e102b72:	seto   al
    756c3e102b75:	mov    WORD PTR [rsp],ax
    756c3e102b79:	mov    rax,r11
    756c3e102b7c:	jmp    0x756c3e102a28
    756c3e102b81:	mov    r13,QWORD PTR [r12+0x40]
    756c3e102b86:	add    r13,0x510
    756c3e102b8d:	mov    r14,QWORD PTR [r12+0x110]
    756c3e102b95:	mov    QWORD PTR [r13+0x0],r14
    756c3e102b99:	mov    r13d,0x0
    756c3e102b9f:	mov    DWORD PTR [r12+0x32c],r13d
    756c3e102ba7:	mov    rcx,QWORD PTR [r12+0x380]
    756c3e102baf:	jrcxz  0x756c3e102bb6
    756c3e102bb1:	jmp    0x756c3e109c66
    756c3e102bb6:	mov    r13,QWORD PTR [r12+0xf0]
    756c3e102bbe:	mov    QWORD PTR [r12+0x100],r13
    756c3e102bc6:	mov    r11,QWORD PTR [rsp]
    756c3e102bca:	mov    QWORD PTR [r12+0x398],r11
    756c3e102bd2:	mov    rdi,QWORD PTR [r12+0x100]
    756c3e102bda:	add    rsp,0x150
    756c3e102be1:	movabs r11,0x60a546e96940
    756c3e102beb:	jmp    r11
    756c3e102bee:	movdqa xmm0,xmm2
    756c3e102bf2:	movdqa xmm1,xmm3
    756c3e102bf6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102bff:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102c08:	call   0x756c3e103670
    756c3e102c0d:	jmp    0x756c3e100571
    756c3e102c12:	movdqa xmm0,xmm2
    756c3e102c16:	movdqa xmm1,xmm3
    756c3e102c1a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102c23:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102c2c:	call   0x756c3e103670
    756c3e102c31:	jmp    0x756c3e1005fd
    756c3e102c36:	movdqa xmm0,xmm9
    756c3e102c3b:	movdqa xmm1,xmm2
    756c3e102c3f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102c48:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102c51:	call   0x756c3e103740
    756c3e102c56:	jmp    0x756c3e100d57
    756c3e102c5b:	movdqa xmm0,xmm8
    756c3e102c60:	movdqa xmm1,xmm2
    756c3e102c64:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102c6d:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102c76:	call   0x756c3e103850
    756c3e102c7b:	jmp    0x756c3e100db6
    756c3e102c80:	movdqa xmm0,xmm9
    756c3e102c85:	movdqa xmm1,xmm7
    756c3e102c89:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102c92:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102c9b:	call   0x756c3e103970
    756c3e102ca0:	jmp    0x756c3e100e2b
    756c3e102ca5:	movdqa xmm0,xmm9
    756c3e102caa:	movdqa xmm1,xmm6
    756c3e102cae:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102cb7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102cc0:	call   0x756c3e103a90
    756c3e102cc5:	jmp    0x756c3e100e7b
    756c3e102cca:	movdqa xmm0,xmm9
    756c3e102ccf:	movdqa xmm1,xmm6
    756c3e102cd3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102cdc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102ce5:	call   0x756c3e103bb0
    756c3e102cea:	jmp    0x756c3e100ed4
    756c3e102cef:	movdqa xmm0,xmm9
    756c3e102cf4:	movdqa xmm1,xmm2
    756c3e102cf8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102d01:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102d0a:	call   0x756c3e103ce0
    756c3e102d0f:	jmp    0x756c3e100f75
    756c3e102d14:	mov    r11,rax
    756c3e102d17:	lahf
    756c3e102d18:	seto   al
    756c3e102d1b:	mov    WORD PTR [rsp],ax
    756c3e102d1f:	mov    rax,r11
    756c3e102d22:	movdqa xmm0,xmm10
    756c3e102d27:	movdqa xmm1,xmm9
    756c3e102d2c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102d35:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102d3e:	call   0x756c3e103e20
    756c3e102d43:	mov    r11,rax
    756c3e102d46:	movzx  eax,WORD PTR [rsp]
    756c3e102d4a:	add    al,0x7f
    756c3e102d4c:	sahf
    756c3e102d4d:	mov    rax,r11
    756c3e102d50:	jmp    0x756c3e100fe0
    756c3e102d55:	mov    r11,rax
    756c3e102d58:	lahf
    756c3e102d59:	seto   al
    756c3e102d5c:	mov    WORD PTR [rsp],ax
    756c3e102d60:	mov    rax,r11
    756c3e102d63:	movdqa xmm0,xmm8
    756c3e102d68:	movdqa xmm1,xmm10
    756c3e102d6d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102d76:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102d7f:	call   0x756c3e103e20
    756c3e102d84:	mov    r11,rax
    756c3e102d87:	movzx  eax,WORD PTR [rsp]
    756c3e102d8b:	add    al,0x7f
    756c3e102d8d:	sahf
    756c3e102d8e:	mov    rax,r11
    756c3e102d91:	jmp    0x756c3e101040
    756c3e102d96:	mov    r11,rax
    756c3e102d99:	lahf
    756c3e102d9a:	seto   al
    756c3e102d9d:	mov    WORD PTR [rsp],ax
    756c3e102da1:	mov    rax,r11
    756c3e102da4:	movdqa xmm0,xmm7
    756c3e102da8:	movdqa xmm1,xmm10
    756c3e102dad:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102db6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102dbf:	call   0x756c3e103ff0
    756c3e102dc4:	mov    r11,rax
    756c3e102dc7:	movzx  eax,WORD PTR [rsp]
    756c3e102dcb:	add    al,0x7f
    756c3e102dcd:	sahf
    756c3e102dce:	mov    rax,r11
    756c3e102dd1:	jmp    0x756c3e101099
    756c3e102dd6:	movdqa xmm0,xmm12
    756c3e102ddb:	movdqa xmm1,xmm9
    756c3e102de0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102de9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102df2:	call   0x756c3e1041b0
    756c3e102df7:	jmp    0x756c3e101211
    756c3e102dfc:	movdqa xmm0,xmm6
    756c3e102e00:	movdqa xmm1,xmm4
    756c3e102e04:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102e0d:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102e16:	call   0x756c3e1043b0
    756c3e102e1b:	jmp    0x756c3e10127f
    756c3e102e20:	movdqa xmm0,xmm8
    756c3e102e25:	movdqa xmm1,xmm11
    756c3e102e2a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102e33:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102e3c:	call   0x756c3e1045a0
    756c3e102e41:	jmp    0x756c3e1012da
    756c3e102e46:	movdqa xmm0,xmm5
    756c3e102e4a:	movdqa xmm1,xmm2
    756c3e102e4e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102e57:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102e60:	call   0x756c3e104790
    756c3e102e65:	jmp    0x756c3e101337
    756c3e102e6a:	movdqa xmm0,xmm9
    756c3e102e6f:	movdqa xmm1,xmm5
    756c3e102e73:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102e7c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102e85:	call   0x756c3e104960
    756c3e102e8a:	jmp    0x756c3e10139f
    756c3e102e8f:	movdqa xmm0,xmm13
    756c3e102e94:	movdqa xmm1,xmm2
    756c3e102e98:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102ea1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102eaa:	call   0x756c3e104b40
    756c3e102eaf:	jmp    0x756c3e101418
    756c3e102eb4:	movdqa xmm0,xmm9
    756c3e102eb9:	movdqa xmm1,xmm5
    756c3e102ebd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102ec6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102ecf:	call   0x756c3e104d30
    756c3e102ed4:	jmp    0x756c3e1014a5
    756c3e102ed9:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    756c3e102ee3:	movdqa xmm1,xmm6
    756c3e102ee7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102ef0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102ef9:	call   0x756c3e104ef0
    756c3e102efe:	jmp    0x756c3e10159a
    756c3e102f03:	movdqa xmm0,xmm9
    756c3e102f08:	movdqa xmm1,xmm5
    756c3e102f0c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102f15:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102f1e:	call   0x756c3e1050d0
    756c3e102f23:	jmp    0x756c3e1015f8
    756c3e102f28:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    756c3e102f32:	movdqa xmm1,xmm11
    756c3e102f37:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102f40:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102f49:	call   0x756c3e1052b0
    756c3e102f4e:	jmp    0x756c3e101671
    756c3e102f53:	movdqa xmm0,xmm12
    756c3e102f58:	movdqa xmm1,xmm8
    756c3e102f5d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102f66:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102f6f:	call   0x756c3e1054a0
    756c3e102f74:	jmp    0x756c3e1016cc
    756c3e102f79:	movdqa xmm0,xmm9
    756c3e102f7e:	movdqa xmm1,xmm5
    756c3e102f82:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102f8b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102f94:	call   0x756c3e105690
    756c3e102f99:	jmp    0x756c3e10174d
    756c3e102f9e:	movdqa xmm0,xmm4
    756c3e102fa2:	movdqa xmm1,xmm2
    756c3e102fa6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102faf:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102fb8:	call   0x756c3e105870
    756c3e102fbd:	jmp    0x756c3e1017c0
    756c3e102fc2:	movdqa xmm0,xmm13
    756c3e102fc7:	movdqa xmm1,xmm2
    756c3e102fcb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102fd4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e102fdd:	call   0x756c3e105a50
    756c3e102fe2:	jmp    0x756c3e101829
    756c3e102fe7:	movdqa xmm0,xmm5
    756c3e102feb:	movdqa xmm1,xmm2
    756c3e102fef:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e102ff8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103001:	call   0x756c3e105c30
    756c3e103006:	jmp    0x756c3e1018a1
    756c3e10300b:	movdqa xmm0,xmm3
    756c3e10300f:	movdqa xmm1,xmm6
    756c3e103013:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e10301c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103025:	call   0x756c3e105e10
    756c3e10302a:	jmp    0x756c3e101914
    756c3e10302f:	movdqa xmm0,xmm5
    756c3e103033:	movdqa xmm1,xmm2
    756c3e103037:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103040:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103049:	call   0x756c3e106000
    756c3e10304e:	jmp    0x756c3e1019b6
    756c3e103053:	movdqa xmm0,xmm10
    756c3e103058:	movdqa xmm1,xmm12
    756c3e10305d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103066:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e10306f:	call   0x756c3e1061f0
    756c3e103074:	jmp    0x756c3e101a27
    756c3e103079:	movdqa xmm0,xmm7
    756c3e10307d:	movdqa xmm1,xmm2
    756c3e103081:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e10308a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103093:	call   0x756c3e1063f0
    756c3e103098:	jmp    0x756c3e101a7a
    756c3e10309d:	movdqa xmm0,xmm11
    756c3e1030a2:	movdqa xmm1,xmm13
    756c3e1030a7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1030b0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1030b9:	call   0x756c3e1065d0
    756c3e1030be:	jmp    0x756c3e101acb
    756c3e1030c3:	movdqa xmm0,xmm5
    756c3e1030c7:	movdqa xmm1,xmm7
    756c3e1030cb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1030d4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1030dd:	call   0x756c3e1067b0
    756c3e1030e2:	jmp    0x756c3e101b28
    756c3e1030e7:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    756c3e1030f1:	movdqa xmm1,xmm7
    756c3e1030f5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1030fe:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103107:	call   0x756c3e106980
    756c3e10310c:	jmp    0x756c3e101b82
    756c3e103111:	movdqa xmm0,xmm8
    756c3e103116:	movdqa xmm1,xmm4
    756c3e10311a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103123:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e10312c:	call   0x756c3e106b50
    756c3e103131:	jmp    0x756c3e101bd1
    756c3e103136:	movdqa xmm0,xmm9
    756c3e10313b:	movdqa xmm1,xmm6
    756c3e10313f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103148:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103151:	call   0x756c3e106d30
    756c3e103156:	jmp    0x756c3e101c2b
    756c3e10315b:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    756c3e103165:	movdqa xmm1,xmm7
    756c3e103169:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103172:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e10317b:	call   0x756c3e106f00
    756c3e103180:	jmp    0x756c3e101c8e
    756c3e103185:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    756c3e10318f:	movdqa xmm1,xmm7
    756c3e103193:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e10319c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1031a5:	call   0x756c3e1070c0
    756c3e1031aa:	jmp    0x756c3e101ce7
    756c3e1031af:	movdqa xmm0,xmm3
    756c3e1031b3:	movdqa xmm1,xmm10
    756c3e1031b8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1031c1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1031ca:	call   0x756c3e107290
    756c3e1031cf:	jmp    0x756c3e101d41
    756c3e1031d4:	movdqa xmm0,xmm2
    756c3e1031d8:	movdqa xmm1,xmm11
    756c3e1031dd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1031e6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1031ef:	call   0x756c3e107460
    756c3e1031f4:	jmp    0x756c3e101d9a
    756c3e1031f9:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    756c3e103203:	movdqa xmm1,xmm2
    756c3e103207:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103210:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103219:	call   0x756c3e107620
    756c3e10321e:	jmp    0x756c3e101e07
    756c3e103223:	movdqa xmm0,xmm4
    756c3e103227:	movdqa xmm1,xmm5
    756c3e10322b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103234:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e10323d:	call   0x756c3e1077d0
    756c3e103242:	jmp    0x756c3e101e60
    756c3e103247:	movdqa xmm0,xmm12
    756c3e10324c:	movdqa xmm1,xmm6
    756c3e103250:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103259:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103262:	call   0x756c3e1079a0
    756c3e103267:	jmp    0x756c3e101eba
    756c3e10326c:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    756c3e103276:	movdqa xmm1,xmm2
    756c3e10327a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103283:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e10328c:	call   0x756c3e1067b0
    756c3e103291:	jmp    0x756c3e101f9a
    756c3e103296:	movdqa xmm0,xmm7
    756c3e10329a:	movdqa xmm1,xmm8
    756c3e10329f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1032a8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1032b1:	call   0x756c3e106b50
    756c3e1032b6:	jmp    0x756c3e101fea
    756c3e1032bb:	movdqa xmm0,xmm3
    756c3e1032bf:	movdqa xmm1,xmm9
    756c3e1032c4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1032cd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1032d6:	call   0x756c3e107b60
    756c3e1032db:	jmp    0x756c3e10203a
    756c3e1032e0:	movdqa xmm0,xmm6
    756c3e1032e4:	movdqa xmm1,xmm2
    756c3e1032e8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1032f1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1032fa:	call   0x756c3e107d30
    756c3e1032ff:	jmp    0x756c3e102097
    756c3e103304:	movdqa xmm0,xmm6
    756c3e103308:	movdqa xmm1,xmm2
    756c3e10330c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103315:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e10331e:	call   0x756c3e1070c0
    756c3e103323:	jmp    0x756c3e1020fe
    756c3e103328:	movdqa xmm0,xmm5
    756c3e10332c:	movdqa xmm1,xmm2
    756c3e103330:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103339:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103342:	call   0x756c3e107ef0
    756c3e103347:	jmp    0x756c3e10215c
    756c3e10334c:	movdqa xmm0,xmm10
    756c3e103351:	movdqa xmm1,xmm11
    756c3e103356:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e10335f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103368:	call   0x756c3e1080c0
    756c3e10336d:	jmp    0x756c3e1021b6
    756c3e103372:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    756c3e10337c:	movdqa xmm1,xmm2
    756c3e103380:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103389:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103392:	call   0x756c3e107620
    756c3e103397:	jmp    0x756c3e102219
    756c3e10339c:	movdqa xmm0,xmm4
    756c3e1033a0:	movdqa xmm1,xmm3
    756c3e1033a4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1033ad:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1033b6:	call   0x756c3e1077d0
    756c3e1033bb:	jmp    0x756c3e102272
    756c3e1033c0:	movdqa xmm0,xmm3
    756c3e1033c4:	movdqa xmm1,xmm2
    756c3e1033c8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1033d1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1033da:	call   0x756c3e108290
    756c3e1033df:	jmp    0x756c3e1022da
    756c3e1033e4:	movdqa xmm0,xmm12
    756c3e1033e9:	movdqa xmm1,xmm8
    756c3e1033ee:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1033f7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103400:	call   0x756c3e108460
    756c3e103405:	jmp    0x756c3e102334
    756c3e10340a:	movdqa xmm0,xmm8
    756c3e10340f:	movdqa xmm1,xmm2
    756c3e103413:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e10341c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103425:	call   0x756c3e1067b0
    756c3e10342a:	jmp    0x756c3e10239c
    756c3e10342f:	movdqa xmm0,xmm7
    756c3e103433:	movdqa xmm1,xmm6
    756c3e103437:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103440:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103449:	call   0x756c3e108630
    756c3e10344e:	jmp    0x756c3e1023f5
    756c3e103453:	movdqa xmm0,xmm5
    756c3e103457:	movdqa xmm1,xmm9
    756c3e10345c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103465:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e10346e:	call   0x756c3e1087f0
    756c3e103473:	jmp    0x756c3e102465
    756c3e103478:	movdqa xmm0,xmm6
    756c3e10347c:	movdqa xmm1,xmm5
    756c3e103480:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103489:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103492:	call   0x756c3e1089b0
    756c3e103497:	jmp    0x756c3e1024cc
    756c3e10349c:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    756c3e1034a6:	movdqa xmm1,xmm5
    756c3e1034aa:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1034b3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1034bc:	call   0x756c3e108b60
    756c3e1034c1:	jmp    0x756c3e102530
    756c3e1034c6:	movdqa xmm0,xmm10
    756c3e1034cb:	movdqa xmm1,xmm4
    756c3e1034cf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1034d8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1034e1:	call   0x756c3e108d20
    756c3e1034e6:	jmp    0x756c3e102589
    756c3e1034eb:	movdqa xmm0,xmm3
    756c3e1034ef:	movdqa xmm1,xmm11
    756c3e1034f4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1034fd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103506:	call   0x756c3e106b50
    756c3e10350b:	jmp    0x756c3e1025ff
    756c3e103510:	movdqa xmm0,xmm10
    756c3e103515:	movdqa xmm1,xmm5
    756c3e103519:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103522:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e10352b:	call   0x756c3e108ef0
    756c3e103530:	jmp    0x756c3e10265e
    756c3e103535:	movdqa xmm0,xmm4
    756c3e103539:	movdqa xmm1,xmm5
    756c3e10353d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e103546:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e10354f:	call   0x756c3e1090c0
    756c3e103554:	jmp    0x756c3e1026bb
    756c3e103559:	movdqa xmm0,xmm2
    756c3e10355d:	movdqa xmm1,xmm8
    756c3e103562:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e10356b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103574:	call   0x756c3e1079a0
    756c3e103579:	jmp    0x756c3e10270b
    756c3e10357e:	movdqa xmm0,xmm7
    756c3e103582:	movdqa xmm1,xmm6
    756c3e103586:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e10358f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103598:	call   0x756c3e109290
    756c3e10359d:	jmp    0x756c3e102763
    756c3e1035a2:	movdqa xmm0,xmm9
    756c3e1035a7:	movdqa xmm1,xmm3
    756c3e1035ab:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1035b4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1035bd:	call   0x756c3e109440
    756c3e1035c2:	jmp    0x756c3e1027bc
    756c3e1035c7:	movdqa xmm0,xmm12
    756c3e1035cc:	movdqa xmm1,xmm10
    756c3e1035d1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e1035da:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e1035e3:	call   0x756c3e1095e0
    756c3e1035e8:	jmp    0x756c3e102816
    756c3e1035ed:	mov    r11,rax
    756c3e1035f0:	lahf
    756c3e1035f1:	seto   al
    756c3e1035f4:	mov    WORD PTR [rsp],ax
    756c3e1035f8:	mov    rax,r11
    756c3e1035fb:	movdqa xmm0,xmm2
    756c3e1035ff:	movdqa xmm1,xmm3
    756c3e103603:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e10360c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103615:	call   0x756c3e109770
    756c3e10361a:	mov    r11,rax
    756c3e10361d:	movzx  eax,WORD PTR [rsp]
    756c3e103621:	add    al,0x7f
    756c3e103623:	sahf
    756c3e103624:	mov    rax,r11
    756c3e103627:	jmp    0x756c3e102ad8
    756c3e10362c:	mov    r11,rax
    756c3e10362f:	lahf
    756c3e103630:	seto   al
    756c3e103633:	mov    WORD PTR [rsp],ax
    756c3e103637:	mov    rax,r11
    756c3e10363a:	movdqa xmm0,xmm4
    756c3e10363e:	movdqa xmm1,xmm2
    756c3e103642:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    756c3e10364b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    756c3e103654:	call   0x756c3e1098d0
    756c3e103659:	mov    r11,rax
    756c3e10365c:	movzx  eax,WORD PTR [rsp]
    756c3e103660:	add    al,0x7f
    756c3e103662:	sahf
    756c3e103663:	mov    rax,r11
    756c3e103666:	jmp    0x756c3e102b38
    756c3e10366b:	nop    DWORD PTR [rax+rax*1+0x0]
    756c3e103670:	sub    rsp,0x8
    756c3e103674:	mov    QWORD PTR [r12+0x378],0x3
    756c3e103680:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e103686:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e10368c:	mov    QWORD PTR [r12+0x108],rbx
    756c3e103694:	stmxcsr DWORD PTR [r12-0x28]
    756c3e10369a:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e10369f:	test   r10d,0x3f
    756c3e1036a6:	je     0x756c3e1036cb
    756c3e1036ac:	mov    r11d,r10d
    756c3e1036af:	shr    r10d,1
    756c3e1036b2:	and    r10d,0x1e
    756c3e1036b6:	and    r11d,0x1
    756c3e1036ba:	or     r10d,r11d
    756c3e1036bd:	or     DWORD PTR [r12+0x314],r10d
    756c3e1036c5:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1036cb:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1036d1:	lea    rdi,[rsp+0x110]
    756c3e1036d9:	lea    rsi,[rsp+0xf0]
    756c3e1036e1:	lea    rdx,[rsp+0x100]
    756c3e1036e9:	mov    ecx,0x16
    756c3e1036ee:	mov    r8d,0x0
    756c3e1036f4:	lea    r9,[r12+0x314]
    756c3e1036fc:	movabs r11,0x60a546cfd650
    756c3e103706:	call   r11
    756c3e103709:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e10370f:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e103715:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e10371b:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e103723:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10372f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e103738:	add    rsp,0x8
    756c3e10373c:	ret
    756c3e10373d:	nop    DWORD PTR [rax]
    756c3e103740:	sub    rsp,0x8
    756c3e103744:	mov    QWORD PTR [r12+0x378],0x3
    756c3e103750:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e103756:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e10375c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e103762:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e10376c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e103776:	mov    QWORD PTR [r12+0x108],rbx
    756c3e10377e:	stmxcsr DWORD PTR [r12-0x28]
    756c3e103784:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e103789:	test   r10d,0x3f
    756c3e103790:	je     0x756c3e1037b5
    756c3e103796:	mov    r11d,r10d
    756c3e103799:	shr    r10d,1
    756c3e10379c:	and    r10d,0x1e
    756c3e1037a0:	and    r11d,0x1
    756c3e1037a4:	or     r10d,r11d
    756c3e1037a7:	or     DWORD PTR [r12+0x314],r10d
    756c3e1037af:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1037b5:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1037bb:	lea    rdi,[rsp+0x110]
    756c3e1037c3:	lea    rsi,[rsp+0xf0]
    756c3e1037cb:	lea    rdx,[rsp+0x100]
    756c3e1037d3:	mov    ecx,0x16
    756c3e1037d8:	mov    r8d,0x0
    756c3e1037de:	lea    r9,[r12+0x314]
    756c3e1037e6:	movabs r11,0x60a546cfd650
    756c3e1037f0:	call   r11
    756c3e1037f3:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1037f9:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1037ff:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e103805:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e10380b:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e103815:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e10381f:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e103827:	mov    QWORD PTR [r12+0x378],0x2
    756c3e103833:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e10383c:	add    rsp,0x8
    756c3e103840:	ret
    756c3e103841:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e103850:	sub    rsp,0x8
    756c3e103854:	mov    QWORD PTR [r12+0x378],0x3
    756c3e103860:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e103866:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e10386c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e103872:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e10387c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e103886:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e103890:	mov    QWORD PTR [r12+0x108],rbx
    756c3e103898:	stmxcsr DWORD PTR [r12-0x28]
    756c3e10389e:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e1038a3:	test   r10d,0x3f
    756c3e1038aa:	je     0x756c3e1038cf
    756c3e1038b0:	mov    r11d,r10d
    756c3e1038b3:	shr    r10d,1
    756c3e1038b6:	and    r10d,0x1e
    756c3e1038ba:	and    r11d,0x1
    756c3e1038be:	or     r10d,r11d
    756c3e1038c1:	or     DWORD PTR [r12+0x314],r10d
    756c3e1038c9:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1038cf:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1038d5:	lea    rdi,[rsp+0x110]
    756c3e1038dd:	lea    rsi,[rsp+0xf0]
    756c3e1038e5:	lea    rdx,[rsp+0x100]
    756c3e1038ed:	mov    ecx,0x56
    756c3e1038f2:	mov    r8d,0x0
    756c3e1038f8:	lea    r9,[r12+0x314]
    756c3e103900:	movabs r11,0x60a546cfd650
    756c3e10390a:	call   r11
    756c3e10390d:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e103913:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e103919:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e10391f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e103925:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e10392f:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e103939:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e103943:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10394b:	mov    QWORD PTR [r12+0x378],0x2
    756c3e103957:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e103960:	add    rsp,0x8
    756c3e103964:	ret
    756c3e103965:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e103970:	sub    rsp,0x8
    756c3e103974:	mov    QWORD PTR [r12+0x378],0x3
    756c3e103980:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e103986:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e10398c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e103992:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e10399c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1039a6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e1039b0:	mov    QWORD PTR [r12+0x108],rbx
    756c3e1039b8:	stmxcsr DWORD PTR [r12-0x28]
    756c3e1039be:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e1039c3:	test   r10d,0x3f
    756c3e1039ca:	je     0x756c3e1039ef
    756c3e1039d0:	mov    r11d,r10d
    756c3e1039d3:	shr    r10d,1
    756c3e1039d6:	and    r10d,0x1e
    756c3e1039da:	and    r11d,0x1
    756c3e1039de:	or     r10d,r11d
    756c3e1039e1:	or     DWORD PTR [r12+0x314],r10d
    756c3e1039e9:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1039ef:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1039f5:	lea    rdi,[rsp+0x110]
    756c3e1039fd:	lea    rsi,[rsp+0xf0]
    756c3e103a05:	lea    rdx,[rsp+0x100]
    756c3e103a0d:	mov    ecx,0x16
    756c3e103a12:	mov    r8d,0x0
    756c3e103a18:	lea    r9,[r12+0x314]
    756c3e103a20:	movabs r11,0x60a546cfd650
    756c3e103a2a:	call   r11
    756c3e103a2d:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e103a33:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e103a39:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e103a3f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e103a45:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e103a4f:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e103a59:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e103a63:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e103a6b:	mov    QWORD PTR [r12+0x378],0x2
    756c3e103a77:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e103a80:	add    rsp,0x8
    756c3e103a84:	ret
    756c3e103a85:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e103a90:	sub    rsp,0x8
    756c3e103a94:	mov    QWORD PTR [r12+0x378],0x3
    756c3e103aa0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e103aa6:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e103aac:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e103ab6:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e103ac0:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e103aca:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e103ad4:	mov    QWORD PTR [r12+0x108],rbx
    756c3e103adc:	stmxcsr DWORD PTR [r12-0x28]
    756c3e103ae2:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e103ae7:	test   r10d,0x3f
    756c3e103aee:	je     0x756c3e103b13
    756c3e103af4:	mov    r11d,r10d
    756c3e103af7:	shr    r10d,1
    756c3e103afa:	and    r10d,0x1e
    756c3e103afe:	and    r11d,0x1
    756c3e103b02:	or     r10d,r11d
    756c3e103b05:	or     DWORD PTR [r12+0x314],r10d
    756c3e103b0d:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e103b13:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e103b19:	lea    rdi,[rsp+0x110]
    756c3e103b21:	lea    rsi,[rsp+0xf0]
    756c3e103b29:	lea    rdx,[rsp+0x100]
    756c3e103b31:	mov    ecx,0x16
    756c3e103b36:	mov    r8d,0x0
    756c3e103b3c:	lea    r9,[r12+0x314]
    756c3e103b44:	movabs r11,0x60a546cfd650
    756c3e103b4e:	call   r11
    756c3e103b51:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e103b57:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e103b5d:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e103b63:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e103b6d:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e103b77:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e103b81:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e103b8b:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e103b93:	mov    QWORD PTR [r12+0x378],0x2
    756c3e103b9f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e103ba8:	add    rsp,0x8
    756c3e103bac:	ret
    756c3e103bad:	nop    DWORD PTR [rax]
    756c3e103bb0:	sub    rsp,0x8
    756c3e103bb4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e103bc0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e103bc6:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e103bcc:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e103bd2:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e103bdc:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e103be6:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e103bf0:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e103bfa:	mov    QWORD PTR [r12+0x108],rbx
    756c3e103c02:	stmxcsr DWORD PTR [r12-0x28]
    756c3e103c08:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e103c0d:	test   r10d,0x3f
    756c3e103c14:	je     0x756c3e103c39
    756c3e103c1a:	mov    r11d,r10d
    756c3e103c1d:	shr    r10d,1
    756c3e103c20:	and    r10d,0x1e
    756c3e103c24:	and    r11d,0x1
    756c3e103c28:	or     r10d,r11d
    756c3e103c2b:	or     DWORD PTR [r12+0x314],r10d
    756c3e103c33:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e103c39:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e103c3f:	lea    rdi,[rsp+0x110]
    756c3e103c47:	lea    rsi,[rsp+0xf0]
    756c3e103c4f:	lea    rdx,[rsp+0x100]
    756c3e103c57:	mov    ecx,0x16
    756c3e103c5c:	mov    r8d,0x0
    756c3e103c62:	lea    r9,[r12+0x314]
    756c3e103c6a:	movabs r11,0x60a546cfd650
    756c3e103c74:	call   r11
    756c3e103c77:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e103c7d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e103c83:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e103c89:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e103c8f:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e103c99:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e103ca3:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e103cad:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e103cb7:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e103cbf:	mov    QWORD PTR [r12+0x378],0x2
    756c3e103ccb:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e103cd4:	add    rsp,0x8
    756c3e103cd8:	ret
    756c3e103cd9:	nop    DWORD PTR [rax+0x0]
    756c3e103ce0:	sub    rsp,0x8
    756c3e103ce4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e103cf0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e103cf6:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e103cfc:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e103d06:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e103d10:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e103d1a:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e103d24:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e103d2e:	mov    QWORD PTR [r12+0x108],rbx
    756c3e103d36:	stmxcsr DWORD PTR [r12-0x28]
    756c3e103d3c:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e103d41:	test   r10d,0x3f
    756c3e103d48:	je     0x756c3e103d6d
    756c3e103d4e:	mov    r11d,r10d
    756c3e103d51:	shr    r10d,1
    756c3e103d54:	and    r10d,0x1e
    756c3e103d58:	and    r11d,0x1
    756c3e103d5c:	or     r10d,r11d
    756c3e103d5f:	or     DWORD PTR [r12+0x314],r10d
    756c3e103d67:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e103d6d:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e103d73:	lea    rdi,[rsp+0x110]
    756c3e103d7b:	lea    rsi,[rsp+0xf0]
    756c3e103d83:	lea    rdx,[rsp+0x100]
    756c3e103d8b:	mov    ecx,0x56
    756c3e103d90:	mov    r8d,0x0
    756c3e103d96:	lea    r9,[r12+0x314]
    756c3e103d9e:	movabs r11,0x60a546cfd650
    756c3e103da8:	call   r11
    756c3e103dab:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e103db1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e103db7:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e103dbd:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e103dc7:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e103dd1:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e103ddb:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e103de5:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e103def:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e103df7:	mov    QWORD PTR [r12+0x378],0x2
    756c3e103e03:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e103e0c:	add    rsp,0x8
    756c3e103e10:	ret
    756c3e103e11:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e103e20:	sub    rsp,0x8
    756c3e103e24:	mov    QWORD PTR [r12+0x378],0x3
    756c3e103e30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e103e36:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e103e3c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e103e42:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e103e4c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e103e56:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e103e60:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e103e6a:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e103e74:	push   rdx
    756c3e103e75:	push   rsi
    756c3e103e76:	push   r10
    756c3e103e78:	push   r11
    756c3e103e7a:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e103e7f:	mov    r10d,edx
    756c3e103e82:	and    r10d,0xc000
    756c3e103e89:	shl    r10d,0x10
    756c3e103e8d:	mov    r11d,edx
    756c3e103e90:	and    r11d,0x100
    756c3e103e97:	shl    r11d,0x15
    756c3e103e9b:	or     r10d,r11d
    756c3e103e9e:	and    edx,0x1
    756c3e103ea1:	shl    edx,0x1c
    756c3e103ea4:	or     r10d,edx
    756c3e103ea7:	btc    r10,0x1d
    756c3e103eac:	mov    r11d,0xf0000000
    756c3e103eb2:	and    r11,r10
    756c3e103eb5:	movabs rsi,0xffffffff0fffffff
    756c3e103ebf:	and    rbx,rsi
    756c3e103ec2:	or     rbx,r11
    756c3e103ec5:	pop    r11
    756c3e103ec7:	pop    r10
    756c3e103ec9:	pop    rsi
    756c3e103eca:	pop    rdx
    756c3e103ecb:	mov    QWORD PTR [r12+0x108],rbx
    756c3e103ed3:	stmxcsr DWORD PTR [r12-0x28]
    756c3e103ed9:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e103ede:	test   r10d,0x3f
    756c3e103ee5:	je     0x756c3e103f0a
    756c3e103eeb:	mov    r11d,r10d
    756c3e103eee:	shr    r10d,1
    756c3e103ef1:	and    r10d,0x1e
    756c3e103ef5:	and    r11d,0x1
    756c3e103ef9:	or     r10d,r11d
    756c3e103efc:	or     DWORD PTR [r12+0x314],r10d
    756c3e103f04:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e103f0a:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e103f10:	lea    rdi,[rsp+0x110]
    756c3e103f18:	lea    rsi,[rsp+0xf0]
    756c3e103f20:	lea    rdx,[rsp+0x100]
    756c3e103f28:	mov    ecx,0x14
    756c3e103f2d:	mov    r8d,0x0
    756c3e103f33:	lea    r9,[r12+0x314]
    756c3e103f3b:	movabs r11,0x60a546cfd650
    756c3e103f45:	call   r11
    756c3e103f48:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e103f4e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e103f54:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e103f5a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e103f60:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e103f6a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e103f74:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e103f7e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e103f88:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e103f92:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e103f9a:	mov    QWORD PTR [r12+0x378],0x2
    756c3e103fa6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e103faf:	mov    rdx,rbx
    756c3e103fb2:	shr    rdx,0x10
    756c3e103fb6:	and    edx,0xc000
    756c3e103fbc:	mov    rax,rbx
    756c3e103fbf:	shr    rax,0x15
    756c3e103fc3:	and    eax,0x100
    756c3e103fc8:	xor    eax,0x100
    756c3e103fcd:	or     edx,eax
    756c3e103fcf:	mov    rax,rbx
    756c3e103fd2:	shr    rax,0x1c
    756c3e103fd6:	and    eax,0x1
    756c3e103fd9:	or     edx,eax
    756c3e103fdb:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e103fe0:	add    rsp,0x8
    756c3e103fe4:	ret
    756c3e103fe5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e103ff0:	sub    rsp,0x8
    756c3e103ff4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e104000:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e104006:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e10400c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e104012:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e104018:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e104022:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e10402c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e104036:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e104040:	push   rdx
    756c3e104041:	push   rsi
    756c3e104042:	push   r10
    756c3e104044:	push   r11
    756c3e104046:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e10404b:	mov    r10d,edx
    756c3e10404e:	and    r10d,0xc000
    756c3e104055:	shl    r10d,0x10
    756c3e104059:	mov    r11d,edx
    756c3e10405c:	and    r11d,0x100
    756c3e104063:	shl    r11d,0x15
    756c3e104067:	or     r10d,r11d
    756c3e10406a:	and    edx,0x1
    756c3e10406d:	shl    edx,0x1c
    756c3e104070:	or     r10d,edx
    756c3e104073:	btc    r10,0x1d
    756c3e104078:	mov    r11d,0xf0000000
    756c3e10407e:	and    r11,r10
    756c3e104081:	movabs rsi,0xffffffff0fffffff
    756c3e10408b:	and    rbx,rsi
    756c3e10408e:	or     rbx,r11
    756c3e104091:	pop    r11
    756c3e104093:	pop    r10
    756c3e104095:	pop    rsi
    756c3e104096:	pop    rdx
    756c3e104097:	mov    QWORD PTR [r12+0x108],rbx
    756c3e10409f:	stmxcsr DWORD PTR [r12-0x28]
    756c3e1040a5:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e1040aa:	test   r10d,0x3f
    756c3e1040b1:	je     0x756c3e1040d6
    756c3e1040b7:	mov    r11d,r10d
    756c3e1040ba:	shr    r10d,1
    756c3e1040bd:	and    r10d,0x1e
    756c3e1040c1:	and    r11d,0x1
    756c3e1040c5:	or     r10d,r11d
    756c3e1040c8:	or     DWORD PTR [r12+0x314],r10d
    756c3e1040d0:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1040d6:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1040dc:	lea    rdi,[rsp+0x110]
    756c3e1040e4:	lea    rsi,[rsp+0xf0]
    756c3e1040ec:	lea    rdx,[rsp+0x100]
    756c3e1040f4:	mov    ecx,0x14
    756c3e1040f9:	mov    r8d,0x0
    756c3e1040ff:	lea    r9,[r12+0x314]
    756c3e104107:	movabs r11,0x60a546cfd650
    756c3e104111:	call   r11
    756c3e104114:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e10411a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e104120:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e104126:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e10412c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e104132:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e10413c:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e104146:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e104150:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e10415a:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e104162:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10416e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e104177:	mov    rdx,rbx
    756c3e10417a:	shr    rdx,0x10
    756c3e10417e:	and    edx,0xc000
    756c3e104184:	mov    rax,rbx
    756c3e104187:	shr    rax,0x15
    756c3e10418b:	and    eax,0x100
    756c3e104190:	xor    eax,0x100
    756c3e104195:	or     edx,eax
    756c3e104197:	mov    rax,rbx
    756c3e10419a:	shr    rax,0x1c
    756c3e10419e:	and    eax,0x1
    756c3e1041a1:	or     edx,eax
    756c3e1041a3:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1041a8:	add    rsp,0x8
    756c3e1041ac:	ret
    756c3e1041ad:	nop    DWORD PTR [rax]
    756c3e1041b0:	sub    rsp,0x8
    756c3e1041b4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1041c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1041c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1041cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1041d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1041d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1041de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1041e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e1041ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e1041f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e104202:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e10420c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e104216:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e104220:	push   rdx
    756c3e104221:	push   rsi
    756c3e104222:	push   r10
    756c3e104224:	push   r11
    756c3e104226:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e10422b:	mov    r10d,edx
    756c3e10422e:	and    r10d,0xc000
    756c3e104235:	shl    r10d,0x10
    756c3e104239:	mov    r11d,edx
    756c3e10423c:	and    r11d,0x100
    756c3e104243:	shl    r11d,0x15
    756c3e104247:	or     r10d,r11d
    756c3e10424a:	and    edx,0x1
    756c3e10424d:	shl    edx,0x1c
    756c3e104250:	or     r10d,edx
    756c3e104253:	btc    r10,0x1d
    756c3e104258:	mov    r11d,0xf0000000
    756c3e10425e:	and    r11,r10
    756c3e104261:	movabs rsi,0xffffffff0fffffff
    756c3e10426b:	and    rbx,rsi
    756c3e10426e:	or     rbx,r11
    756c3e104271:	pop    r11
    756c3e104273:	pop    r10
    756c3e104275:	pop    rsi
    756c3e104276:	pop    rdx
    756c3e104277:	mov    QWORD PTR [r12+0x108],rbx
    756c3e10427f:	stmxcsr DWORD PTR [r12-0x28]
    756c3e104285:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e10428a:	test   r10d,0x3f
    756c3e104291:	je     0x756c3e1042b6
    756c3e104297:	mov    r11d,r10d
    756c3e10429a:	shr    r10d,1
    756c3e10429d:	and    r10d,0x1e
    756c3e1042a1:	and    r11d,0x1
    756c3e1042a5:	or     r10d,r11d
    756c3e1042a8:	or     DWORD PTR [r12+0x314],r10d
    756c3e1042b0:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1042b6:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1042bc:	lea    rdi,[rsp+0x110]
    756c3e1042c4:	lea    rsi,[rsp+0xf0]
    756c3e1042cc:	lea    rdx,[rsp+0x100]
    756c3e1042d4:	mov    ecx,0x14
    756c3e1042d9:	mov    r8d,0x0
    756c3e1042df:	lea    r9,[r12+0x314]
    756c3e1042e7:	movabs r11,0x60a546cfd650
    756c3e1042f1:	call   r11
    756c3e1042f4:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1042fa:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e104300:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e104306:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e10430c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e104312:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e104318:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e10431e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e104328:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e104332:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e10433c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e104346:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e104350:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e10435a:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e104362:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10436e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e104377:	mov    rdx,rbx
    756c3e10437a:	shr    rdx,0x10
    756c3e10437e:	and    edx,0xc000
    756c3e104384:	mov    rax,rbx
    756c3e104387:	shr    rax,0x15
    756c3e10438b:	and    eax,0x100
    756c3e104390:	xor    eax,0x100
    756c3e104395:	or     edx,eax
    756c3e104397:	mov    rax,rbx
    756c3e10439a:	shr    rax,0x1c
    756c3e10439e:	and    eax,0x1
    756c3e1043a1:	or     edx,eax
    756c3e1043a3:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1043a8:	add    rsp,0x8
    756c3e1043ac:	ret
    756c3e1043ad:	nop    DWORD PTR [rax]
    756c3e1043b0:	sub    rsp,0x8
    756c3e1043b4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1043c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1043c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1043cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1043d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1043d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1043de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1043e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e1043ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e1043f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e104402:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e10440c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e104416:	push   rdx
    756c3e104417:	push   rsi
    756c3e104418:	push   r10
    756c3e10441a:	push   r11
    756c3e10441c:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e104421:	mov    r10d,edx
    756c3e104424:	and    r10d,0xc000
    756c3e10442b:	shl    r10d,0x10
    756c3e10442f:	mov    r11d,edx
    756c3e104432:	and    r11d,0x100
    756c3e104439:	shl    r11d,0x15
    756c3e10443d:	or     r10d,r11d
    756c3e104440:	and    edx,0x1
    756c3e104443:	shl    edx,0x1c
    756c3e104446:	or     r10d,edx
    756c3e104449:	btc    r10,0x1d
    756c3e10444e:	mov    r11d,0xf0000000
    756c3e104454:	and    r11,r10
    756c3e104457:	movabs rsi,0xffffffff0fffffff
    756c3e104461:	and    rbx,rsi
    756c3e104464:	or     rbx,r11
    756c3e104467:	pop    r11
    756c3e104469:	pop    r10
    756c3e10446b:	pop    rsi
    756c3e10446c:	pop    rdx
    756c3e10446d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e104475:	stmxcsr DWORD PTR [r12-0x28]
    756c3e10447b:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e104480:	test   r10d,0x3f
    756c3e104487:	je     0x756c3e1044ac
    756c3e10448d:	mov    r11d,r10d
    756c3e104490:	shr    r10d,1
    756c3e104493:	and    r10d,0x1e
    756c3e104497:	and    r11d,0x1
    756c3e10449b:	or     r10d,r11d
    756c3e10449e:	or     DWORD PTR [r12+0x314],r10d
    756c3e1044a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1044ac:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1044b2:	lea    rdi,[rsp+0x110]
    756c3e1044ba:	lea    rsi,[rsp+0xf0]
    756c3e1044c2:	lea    rdx,[rsp+0x100]
    756c3e1044ca:	mov    ecx,0x14
    756c3e1044cf:	mov    r8d,0x0
    756c3e1044d5:	lea    r9,[r12+0x314]
    756c3e1044dd:	movabs r11,0x60a546cfd650
    756c3e1044e7:	call   r11
    756c3e1044ea:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1044f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1044f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1044fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e104502:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e104508:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e10450e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e104514:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e10451e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e104528:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e104532:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e10453c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e104546:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10454e:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10455a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e104563:	mov    rdx,rbx
    756c3e104566:	shr    rdx,0x10
    756c3e10456a:	and    edx,0xc000
    756c3e104570:	mov    rax,rbx
    756c3e104573:	shr    rax,0x15
    756c3e104577:	and    eax,0x100
    756c3e10457c:	xor    eax,0x100
    756c3e104581:	or     edx,eax
    756c3e104583:	mov    rax,rbx
    756c3e104586:	shr    rax,0x1c
    756c3e10458a:	and    eax,0x1
    756c3e10458d:	or     edx,eax
    756c3e10458f:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e104594:	add    rsp,0x8
    756c3e104598:	ret
    756c3e104599:	nop    DWORD PTR [rax+0x0]
    756c3e1045a0:	sub    rsp,0x8
    756c3e1045a4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1045b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1045b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1045bc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1045c2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1045c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e1045d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e1045dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1045e6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e1045f0:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e1045fa:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e104604:	push   rdx
    756c3e104605:	push   rsi
    756c3e104606:	push   r10
    756c3e104608:	push   r11
    756c3e10460a:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e10460f:	mov    r10d,edx
    756c3e104612:	and    r10d,0xc000
    756c3e104619:	shl    r10d,0x10
    756c3e10461d:	mov    r11d,edx
    756c3e104620:	and    r11d,0x100
    756c3e104627:	shl    r11d,0x15
    756c3e10462b:	or     r10d,r11d
    756c3e10462e:	and    edx,0x1
    756c3e104631:	shl    edx,0x1c
    756c3e104634:	or     r10d,edx
    756c3e104637:	btc    r10,0x1d
    756c3e10463c:	mov    r11d,0xf0000000
    756c3e104642:	and    r11,r10
    756c3e104645:	movabs rsi,0xffffffff0fffffff
    756c3e10464f:	and    rbx,rsi
    756c3e104652:	or     rbx,r11
    756c3e104655:	pop    r11
    756c3e104657:	pop    r10
    756c3e104659:	pop    rsi
    756c3e10465a:	pop    rdx
    756c3e10465b:	mov    QWORD PTR [r12+0x108],rbx
    756c3e104663:	stmxcsr DWORD PTR [r12-0x28]
    756c3e104669:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e10466e:	test   r10d,0x3f
    756c3e104675:	je     0x756c3e10469a
    756c3e10467b:	mov    r11d,r10d
    756c3e10467e:	shr    r10d,1
    756c3e104681:	and    r10d,0x1e
    756c3e104685:	and    r11d,0x1
    756c3e104689:	or     r10d,r11d
    756c3e10468c:	or     DWORD PTR [r12+0x314],r10d
    756c3e104694:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e10469a:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1046a0:	lea    rdi,[rsp+0x110]
    756c3e1046a8:	lea    rsi,[rsp+0xf0]
    756c3e1046b0:	lea    rdx,[rsp+0x100]
    756c3e1046b8:	mov    ecx,0x14
    756c3e1046bd:	mov    r8d,0x0
    756c3e1046c3:	lea    r9,[r12+0x314]
    756c3e1046cb:	movabs r11,0x60a546cfd650
    756c3e1046d5:	call   r11
    756c3e1046d8:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1046de:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1046e4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1046ea:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e1046f0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e1046f6:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e104700:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e10470a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e104714:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e10471e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e104728:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e104732:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10473a:	mov    QWORD PTR [r12+0x378],0x2
    756c3e104746:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e10474f:	mov    rdx,rbx
    756c3e104752:	shr    rdx,0x10
    756c3e104756:	and    edx,0xc000
    756c3e10475c:	mov    rax,rbx
    756c3e10475f:	shr    rax,0x15
    756c3e104763:	and    eax,0x100
    756c3e104768:	xor    eax,0x100
    756c3e10476d:	or     edx,eax
    756c3e10476f:	mov    rax,rbx
    756c3e104772:	shr    rax,0x1c
    756c3e104776:	and    eax,0x1
    756c3e104779:	or     edx,eax
    756c3e10477b:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e104780:	add    rsp,0x8
    756c3e104784:	ret
    756c3e104785:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e104790:	sub    rsp,0x8
    756c3e104794:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1047a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1047a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1047ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1047b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1047b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1047be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e1047c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1047d2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e1047dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e1047e6:	push   rdx
    756c3e1047e7:	push   rsi
    756c3e1047e8:	push   r10
    756c3e1047ea:	push   r11
    756c3e1047ec:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e1047f1:	mov    r10d,edx
    756c3e1047f4:	and    r10d,0xc000
    756c3e1047fb:	shl    r10d,0x10
    756c3e1047ff:	mov    r11d,edx
    756c3e104802:	and    r11d,0x100
    756c3e104809:	shl    r11d,0x15
    756c3e10480d:	or     r10d,r11d
    756c3e104810:	and    edx,0x1
    756c3e104813:	shl    edx,0x1c
    756c3e104816:	or     r10d,edx
    756c3e104819:	btc    r10,0x1d
    756c3e10481e:	mov    r11d,0xf0000000
    756c3e104824:	and    r11,r10
    756c3e104827:	movabs rsi,0xffffffff0fffffff
    756c3e104831:	and    rbx,rsi
    756c3e104834:	or     rbx,r11
    756c3e104837:	pop    r11
    756c3e104839:	pop    r10
    756c3e10483b:	pop    rsi
    756c3e10483c:	pop    rdx
    756c3e10483d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e104845:	stmxcsr DWORD PTR [r12-0x28]
    756c3e10484b:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e104850:	test   r10d,0x3f
    756c3e104857:	je     0x756c3e10487c
    756c3e10485d:	mov    r11d,r10d
    756c3e104860:	shr    r10d,1
    756c3e104863:	and    r10d,0x1e
    756c3e104867:	and    r11d,0x1
    756c3e10486b:	or     r10d,r11d
    756c3e10486e:	or     DWORD PTR [r12+0x314],r10d
    756c3e104876:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e10487c:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e104882:	lea    rdi,[rsp+0x110]
    756c3e10488a:	lea    rsi,[rsp+0xf0]
    756c3e104892:	lea    rdx,[rsp+0x100]
    756c3e10489a:	mov    ecx,0x56
    756c3e10489f:	mov    r8d,0x0
    756c3e1048a5:	lea    r9,[r12+0x314]
    756c3e1048ad:	movabs r11,0x60a546cfd650
    756c3e1048b7:	call   r11
    756c3e1048ba:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1048c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1048c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1048cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e1048d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e1048d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e1048de:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e1048e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e1048f2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e1048fc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e104906:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10490e:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10491a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e104923:	mov    rdx,rbx
    756c3e104926:	shr    rdx,0x10
    756c3e10492a:	and    edx,0xc000
    756c3e104930:	mov    rax,rbx
    756c3e104933:	shr    rax,0x15
    756c3e104937:	and    eax,0x100
    756c3e10493c:	xor    eax,0x100
    756c3e104941:	or     edx,eax
    756c3e104943:	mov    rax,rbx
    756c3e104946:	shr    rax,0x1c
    756c3e10494a:	and    eax,0x1
    756c3e10494d:	or     edx,eax
    756c3e10494f:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e104954:	add    rsp,0x8
    756c3e104958:	ret
    756c3e104959:	nop    DWORD PTR [rax+0x0]
    756c3e104960:	sub    rsp,0x8
    756c3e104964:	mov    QWORD PTR [r12+0x378],0x3
    756c3e104970:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e104976:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e10497c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e104982:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e104988:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e10498e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e104994:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e10499e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1049a8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e1049b2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e1049bc:	push   rdx
    756c3e1049bd:	push   rsi
    756c3e1049be:	push   r10
    756c3e1049c0:	push   r11
    756c3e1049c2:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e1049c7:	mov    r10d,edx
    756c3e1049ca:	and    r10d,0xc000
    756c3e1049d1:	shl    r10d,0x10
    756c3e1049d5:	mov    r11d,edx
    756c3e1049d8:	and    r11d,0x100
    756c3e1049df:	shl    r11d,0x15
    756c3e1049e3:	or     r10d,r11d
    756c3e1049e6:	and    edx,0x1
    756c3e1049e9:	shl    edx,0x1c
    756c3e1049ec:	or     r10d,edx
    756c3e1049ef:	btc    r10,0x1d
    756c3e1049f4:	mov    r11d,0xf0000000
    756c3e1049fa:	and    r11,r10
    756c3e1049fd:	movabs rsi,0xffffffff0fffffff
    756c3e104a07:	and    rbx,rsi
    756c3e104a0a:	or     rbx,r11
    756c3e104a0d:	pop    r11
    756c3e104a0f:	pop    r10
    756c3e104a11:	pop    rsi
    756c3e104a12:	pop    rdx
    756c3e104a13:	mov    QWORD PTR [r12+0x108],rbx
    756c3e104a1b:	stmxcsr DWORD PTR [r12-0x28]
    756c3e104a21:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e104a26:	test   r10d,0x3f
    756c3e104a2d:	je     0x756c3e104a52
    756c3e104a33:	mov    r11d,r10d
    756c3e104a36:	shr    r10d,1
    756c3e104a39:	and    r10d,0x1e
    756c3e104a3d:	and    r11d,0x1
    756c3e104a41:	or     r10d,r11d
    756c3e104a44:	or     DWORD PTR [r12+0x314],r10d
    756c3e104a4c:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e104a52:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e104a58:	lea    rdi,[rsp+0x110]
    756c3e104a60:	lea    rsi,[rsp+0xf0]
    756c3e104a68:	lea    rdx,[rsp+0x100]
    756c3e104a70:	mov    ecx,0x56
    756c3e104a75:	mov    r8d,0x0
    756c3e104a7b:	lea    r9,[r12+0x314]
    756c3e104a83:	movabs r11,0x60a546cfd650
    756c3e104a8d:	call   r11
    756c3e104a90:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e104a96:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e104a9c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e104aa2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e104aa8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e104aae:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e104ab4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e104aba:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e104ac4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e104ace:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e104ad8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e104ae2:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e104aea:	mov    QWORD PTR [r12+0x378],0x2
    756c3e104af6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e104aff:	mov    rdx,rbx
    756c3e104b02:	shr    rdx,0x10
    756c3e104b06:	and    edx,0xc000
    756c3e104b0c:	mov    rax,rbx
    756c3e104b0f:	shr    rax,0x15
    756c3e104b13:	and    eax,0x100
    756c3e104b18:	xor    eax,0x100
    756c3e104b1d:	or     edx,eax
    756c3e104b1f:	mov    rax,rbx
    756c3e104b22:	shr    rax,0x1c
    756c3e104b26:	and    eax,0x1
    756c3e104b29:	or     edx,eax
    756c3e104b2b:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e104b30:	add    rsp,0x8
    756c3e104b34:	ret
    756c3e104b35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e104b40:	sub    rsp,0x8
    756c3e104b44:	mov    QWORD PTR [r12+0x378],0x3
    756c3e104b50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e104b56:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e104b5c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e104b62:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e104b68:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e104b6e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e104b74:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e104b7e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e104b88:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e104b92:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e104b9c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e104ba6:	push   rdx
    756c3e104ba7:	push   rsi
    756c3e104ba8:	push   r10
    756c3e104baa:	push   r11
    756c3e104bac:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e104bb1:	mov    r10d,edx
    756c3e104bb4:	and    r10d,0xc000
    756c3e104bbb:	shl    r10d,0x10
    756c3e104bbf:	mov    r11d,edx
    756c3e104bc2:	and    r11d,0x100
    756c3e104bc9:	shl    r11d,0x15
    756c3e104bcd:	or     r10d,r11d
    756c3e104bd0:	and    edx,0x1
    756c3e104bd3:	shl    edx,0x1c
    756c3e104bd6:	or     r10d,edx
    756c3e104bd9:	btc    r10,0x1d
    756c3e104bde:	mov    r11d,0xf0000000
    756c3e104be4:	and    r11,r10
    756c3e104be7:	movabs rsi,0xffffffff0fffffff
    756c3e104bf1:	and    rbx,rsi
    756c3e104bf4:	or     rbx,r11
    756c3e104bf7:	pop    r11
    756c3e104bf9:	pop    r10
    756c3e104bfb:	pop    rsi
    756c3e104bfc:	pop    rdx
    756c3e104bfd:	mov    QWORD PTR [r12+0x108],rbx
    756c3e104c05:	stmxcsr DWORD PTR [r12-0x28]
    756c3e104c0b:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e104c10:	test   r10d,0x3f
    756c3e104c17:	je     0x756c3e104c3c
    756c3e104c1d:	mov    r11d,r10d
    756c3e104c20:	shr    r10d,1
    756c3e104c23:	and    r10d,0x1e
    756c3e104c27:	and    r11d,0x1
    756c3e104c2b:	or     r10d,r11d
    756c3e104c2e:	or     DWORD PTR [r12+0x314],r10d
    756c3e104c36:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e104c3c:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e104c42:	lea    rdi,[rsp+0x110]
    756c3e104c4a:	lea    rsi,[rsp+0xf0]
    756c3e104c52:	lea    rdx,[rsp+0x100]
    756c3e104c5a:	mov    ecx,0x56
    756c3e104c5f:	mov    r8d,0x0
    756c3e104c65:	lea    r9,[r12+0x314]
    756c3e104c6d:	movabs r11,0x60a546cfd650
    756c3e104c77:	call   r11
    756c3e104c7a:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e104c80:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e104c86:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e104c8c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e104c92:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e104c98:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e104c9e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e104ca4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e104cae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e104cb8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e104cc2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e104ccc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e104cd6:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e104cde:	mov    QWORD PTR [r12+0x378],0x2
    756c3e104cea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e104cf3:	mov    rdx,rbx
    756c3e104cf6:	shr    rdx,0x10
    756c3e104cfa:	and    edx,0xc000
    756c3e104d00:	mov    rax,rbx
    756c3e104d03:	shr    rax,0x15
    756c3e104d07:	and    eax,0x100
    756c3e104d0c:	xor    eax,0x100
    756c3e104d11:	or     edx,eax
    756c3e104d13:	mov    rax,rbx
    756c3e104d16:	shr    rax,0x1c
    756c3e104d1a:	and    eax,0x1
    756c3e104d1d:	or     edx,eax
    756c3e104d1f:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e104d24:	add    rsp,0x8
    756c3e104d28:	ret
    756c3e104d29:	nop    DWORD PTR [rax+0x0]
    756c3e104d30:	sub    rsp,0x8
    756c3e104d34:	mov    QWORD PTR [r12+0x378],0x3
    756c3e104d40:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e104d46:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e104d4c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e104d52:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e104d58:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e104d62:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e104d6c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e104d76:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e104d80:	push   rdx
    756c3e104d81:	push   rsi
    756c3e104d82:	push   r10
    756c3e104d84:	push   r11
    756c3e104d86:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e104d8b:	mov    r10d,edx
    756c3e104d8e:	and    r10d,0xc000
    756c3e104d95:	shl    r10d,0x10
    756c3e104d99:	mov    r11d,edx
    756c3e104d9c:	and    r11d,0x100
    756c3e104da3:	shl    r11d,0x15
    756c3e104da7:	or     r10d,r11d
    756c3e104daa:	and    edx,0x1
    756c3e104dad:	shl    edx,0x1c
    756c3e104db0:	or     r10d,edx
    756c3e104db3:	btc    r10,0x1d
    756c3e104db8:	mov    r11d,0xf0000000
    756c3e104dbe:	and    r11,r10
    756c3e104dc1:	movabs rsi,0xffffffff0fffffff
    756c3e104dcb:	and    rbx,rsi
    756c3e104dce:	or     rbx,r11
    756c3e104dd1:	pop    r11
    756c3e104dd3:	pop    r10
    756c3e104dd5:	pop    rsi
    756c3e104dd6:	pop    rdx
    756c3e104dd7:	mov    QWORD PTR [r12+0x108],rbx
    756c3e104ddf:	stmxcsr DWORD PTR [r12-0x28]
    756c3e104de5:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e104dea:	test   r10d,0x3f
    756c3e104df1:	je     0x756c3e104e16
    756c3e104df7:	mov    r11d,r10d
    756c3e104dfa:	shr    r10d,1
    756c3e104dfd:	and    r10d,0x1e
    756c3e104e01:	and    r11d,0x1
    756c3e104e05:	or     r10d,r11d
    756c3e104e08:	or     DWORD PTR [r12+0x314],r10d
    756c3e104e10:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e104e16:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e104e1c:	lea    rdi,[rsp+0x110]
    756c3e104e24:	lea    rsi,[rsp+0xf0]
    756c3e104e2c:	lea    rdx,[rsp+0x100]
    756c3e104e34:	mov    ecx,0x56
    756c3e104e39:	mov    r8d,0x0
    756c3e104e3f:	lea    r9,[r12+0x314]
    756c3e104e47:	movabs r11,0x60a546cfd650
    756c3e104e51:	call   r11
    756c3e104e54:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e104e5a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e104e60:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e104e66:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e104e6c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e104e72:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e104e7c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e104e86:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e104e90:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e104e9a:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e104ea2:	mov    QWORD PTR [r12+0x378],0x2
    756c3e104eae:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e104eb7:	mov    rdx,rbx
    756c3e104eba:	shr    rdx,0x10
    756c3e104ebe:	and    edx,0xc000
    756c3e104ec4:	mov    rax,rbx
    756c3e104ec7:	shr    rax,0x15
    756c3e104ecb:	and    eax,0x100
    756c3e104ed0:	xor    eax,0x100
    756c3e104ed5:	or     edx,eax
    756c3e104ed7:	mov    rax,rbx
    756c3e104eda:	shr    rax,0x1c
    756c3e104ede:	and    eax,0x1
    756c3e104ee1:	or     edx,eax
    756c3e104ee3:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e104ee8:	add    rsp,0x8
    756c3e104eec:	ret
    756c3e104eed:	nop    DWORD PTR [rax]
    756c3e104ef0:	sub    rsp,0x8
    756c3e104ef4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e104f00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e104f06:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e104f0c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e104f12:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e104f18:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e104f1e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e104f28:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e104f32:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e104f3c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e104f46:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e104f50:	push   rdx
    756c3e104f51:	push   rsi
    756c3e104f52:	push   r10
    756c3e104f54:	push   r11
    756c3e104f56:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e104f5b:	mov    r10d,edx
    756c3e104f5e:	and    r10d,0xc000
    756c3e104f65:	shl    r10d,0x10
    756c3e104f69:	mov    r11d,edx
    756c3e104f6c:	and    r11d,0x100
    756c3e104f73:	shl    r11d,0x15
    756c3e104f77:	or     r10d,r11d
    756c3e104f7a:	and    edx,0x1
    756c3e104f7d:	shl    edx,0x1c
    756c3e104f80:	or     r10d,edx
    756c3e104f83:	btc    r10,0x1d
    756c3e104f88:	mov    r11d,0xf0000000
    756c3e104f8e:	and    r11,r10
    756c3e104f91:	movabs rsi,0xffffffff0fffffff
    756c3e104f9b:	and    rbx,rsi
    756c3e104f9e:	or     rbx,r11
    756c3e104fa1:	pop    r11
    756c3e104fa3:	pop    r10
    756c3e104fa5:	pop    rsi
    756c3e104fa6:	pop    rdx
    756c3e104fa7:	mov    QWORD PTR [r12+0x108],rbx
    756c3e104faf:	stmxcsr DWORD PTR [r12-0x28]
    756c3e104fb5:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e104fba:	test   r10d,0x3f
    756c3e104fc1:	je     0x756c3e104fe6
    756c3e104fc7:	mov    r11d,r10d
    756c3e104fca:	shr    r10d,1
    756c3e104fcd:	and    r10d,0x1e
    756c3e104fd1:	and    r11d,0x1
    756c3e104fd5:	or     r10d,r11d
    756c3e104fd8:	or     DWORD PTR [r12+0x314],r10d
    756c3e104fe0:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e104fe6:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e104fec:	lea    rdi,[rsp+0x110]
    756c3e104ff4:	lea    rsi,[rsp+0xf0]
    756c3e104ffc:	lea    rdx,[rsp+0x100]
    756c3e105004:	mov    ecx,0x14
    756c3e105009:	mov    r8d,0x0
    756c3e10500f:	lea    r9,[r12+0x314]
    756c3e105017:	movabs r11,0x60a546cfd650
    756c3e105021:	call   r11
    756c3e105024:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e10502a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e105030:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e105036:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e10503c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e105042:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e105048:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e105052:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e10505c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e105066:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e105070:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e10507a:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e105082:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10508e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e105097:	mov    rdx,rbx
    756c3e10509a:	shr    rdx,0x10
    756c3e10509e:	and    edx,0xc000
    756c3e1050a4:	mov    rax,rbx
    756c3e1050a7:	shr    rax,0x15
    756c3e1050ab:	and    eax,0x100
    756c3e1050b0:	xor    eax,0x100
    756c3e1050b5:	or     edx,eax
    756c3e1050b7:	mov    rax,rbx
    756c3e1050ba:	shr    rax,0x1c
    756c3e1050be:	and    eax,0x1
    756c3e1050c1:	or     edx,eax
    756c3e1050c3:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1050c8:	add    rsp,0x8
    756c3e1050cc:	ret
    756c3e1050cd:	nop    DWORD PTR [rax]
    756c3e1050d0:	sub    rsp,0x8
    756c3e1050d4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1050e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1050e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1050ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1050f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1050f8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1050fe:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e105108:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e105112:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e10511c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e105126:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e105130:	push   rdx
    756c3e105131:	push   rsi
    756c3e105132:	push   r10
    756c3e105134:	push   r11
    756c3e105136:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e10513b:	mov    r10d,edx
    756c3e10513e:	and    r10d,0xc000
    756c3e105145:	shl    r10d,0x10
    756c3e105149:	mov    r11d,edx
    756c3e10514c:	and    r11d,0x100
    756c3e105153:	shl    r11d,0x15
    756c3e105157:	or     r10d,r11d
    756c3e10515a:	and    edx,0x1
    756c3e10515d:	shl    edx,0x1c
    756c3e105160:	or     r10d,edx
    756c3e105163:	btc    r10,0x1d
    756c3e105168:	mov    r11d,0xf0000000
    756c3e10516e:	and    r11,r10
    756c3e105171:	movabs rsi,0xffffffff0fffffff
    756c3e10517b:	and    rbx,rsi
    756c3e10517e:	or     rbx,r11
    756c3e105181:	pop    r11
    756c3e105183:	pop    r10
    756c3e105185:	pop    rsi
    756c3e105186:	pop    rdx
    756c3e105187:	mov    QWORD PTR [r12+0x108],rbx
    756c3e10518f:	stmxcsr DWORD PTR [r12-0x28]
    756c3e105195:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e10519a:	test   r10d,0x3f
    756c3e1051a1:	je     0x756c3e1051c6
    756c3e1051a7:	mov    r11d,r10d
    756c3e1051aa:	shr    r10d,1
    756c3e1051ad:	and    r10d,0x1e
    756c3e1051b1:	and    r11d,0x1
    756c3e1051b5:	or     r10d,r11d
    756c3e1051b8:	or     DWORD PTR [r12+0x314],r10d
    756c3e1051c0:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1051c6:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1051cc:	lea    rdi,[rsp+0x110]
    756c3e1051d4:	lea    rsi,[rsp+0xf0]
    756c3e1051dc:	lea    rdx,[rsp+0x100]
    756c3e1051e4:	mov    ecx,0x56
    756c3e1051e9:	mov    r8d,0x0
    756c3e1051ef:	lea    r9,[r12+0x314]
    756c3e1051f7:	movabs r11,0x60a546cfd650
    756c3e105201:	call   r11
    756c3e105204:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e10520a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e105210:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e105216:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e10521c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e105222:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e105228:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e105232:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e10523c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e105246:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e105250:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e10525a:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e105262:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10526e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e105277:	mov    rdx,rbx
    756c3e10527a:	shr    rdx,0x10
    756c3e10527e:	and    edx,0xc000
    756c3e105284:	mov    rax,rbx
    756c3e105287:	shr    rax,0x15
    756c3e10528b:	and    eax,0x100
    756c3e105290:	xor    eax,0x100
    756c3e105295:	or     edx,eax
    756c3e105297:	mov    rax,rbx
    756c3e10529a:	shr    rax,0x1c
    756c3e10529e:	and    eax,0x1
    756c3e1052a1:	or     edx,eax
    756c3e1052a3:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1052a8:	add    rsp,0x8
    756c3e1052ac:	ret
    756c3e1052ad:	nop    DWORD PTR [rax]
    756c3e1052b0:	sub    rsp,0x8
    756c3e1052b4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1052c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1052c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1052cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1052d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1052d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1052de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1052e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e1052ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e1052f8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e105302:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e10530c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e105316:	push   rdx
    756c3e105317:	push   rsi
    756c3e105318:	push   r10
    756c3e10531a:	push   r11
    756c3e10531c:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e105321:	mov    r10d,edx
    756c3e105324:	and    r10d,0xc000
    756c3e10532b:	shl    r10d,0x10
    756c3e10532f:	mov    r11d,edx
    756c3e105332:	and    r11d,0x100
    756c3e105339:	shl    r11d,0x15
    756c3e10533d:	or     r10d,r11d
    756c3e105340:	and    edx,0x1
    756c3e105343:	shl    edx,0x1c
    756c3e105346:	or     r10d,edx
    756c3e105349:	btc    r10,0x1d
    756c3e10534e:	mov    r11d,0xf0000000
    756c3e105354:	and    r11,r10
    756c3e105357:	movabs rsi,0xffffffff0fffffff
    756c3e105361:	and    rbx,rsi
    756c3e105364:	or     rbx,r11
    756c3e105367:	pop    r11
    756c3e105369:	pop    r10
    756c3e10536b:	pop    rsi
    756c3e10536c:	pop    rdx
    756c3e10536d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e105375:	stmxcsr DWORD PTR [r12-0x28]
    756c3e10537b:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e105380:	test   r10d,0x3f
    756c3e105387:	je     0x756c3e1053ac
    756c3e10538d:	mov    r11d,r10d
    756c3e105390:	shr    r10d,1
    756c3e105393:	and    r10d,0x1e
    756c3e105397:	and    r11d,0x1
    756c3e10539b:	or     r10d,r11d
    756c3e10539e:	or     DWORD PTR [r12+0x314],r10d
    756c3e1053a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1053ac:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1053b2:	lea    rdi,[rsp+0x110]
    756c3e1053ba:	lea    rsi,[rsp+0xf0]
    756c3e1053c2:	lea    rdx,[rsp+0x100]
    756c3e1053ca:	mov    ecx,0x14
    756c3e1053cf:	mov    r8d,0x0
    756c3e1053d5:	lea    r9,[r12+0x314]
    756c3e1053dd:	movabs r11,0x60a546cfd650
    756c3e1053e7:	call   r11
    756c3e1053ea:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1053f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1053f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1053fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e105402:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e105408:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e10540e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e105414:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e10541e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e105428:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e105432:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e10543c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e105446:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10544e:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10545a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e105463:	mov    rdx,rbx
    756c3e105466:	shr    rdx,0x10
    756c3e10546a:	and    edx,0xc000
    756c3e105470:	mov    rax,rbx
    756c3e105473:	shr    rax,0x15
    756c3e105477:	and    eax,0x100
    756c3e10547c:	xor    eax,0x100
    756c3e105481:	or     edx,eax
    756c3e105483:	mov    rax,rbx
    756c3e105486:	shr    rax,0x1c
    756c3e10548a:	and    eax,0x1
    756c3e10548d:	or     edx,eax
    756c3e10548f:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e105494:	add    rsp,0x8
    756c3e105498:	ret
    756c3e105499:	nop    DWORD PTR [rax+0x0]
    756c3e1054a0:	sub    rsp,0x8
    756c3e1054a4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1054b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1054b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1054bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1054c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1054c8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1054ce:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1054d4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e1054de:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e1054e8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1054f2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e1054fc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e105506:	push   rdx
    756c3e105507:	push   rsi
    756c3e105508:	push   r10
    756c3e10550a:	push   r11
    756c3e10550c:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e105511:	mov    r10d,edx
    756c3e105514:	and    r10d,0xc000
    756c3e10551b:	shl    r10d,0x10
    756c3e10551f:	mov    r11d,edx
    756c3e105522:	and    r11d,0x100
    756c3e105529:	shl    r11d,0x15
    756c3e10552d:	or     r10d,r11d
    756c3e105530:	and    edx,0x1
    756c3e105533:	shl    edx,0x1c
    756c3e105536:	or     r10d,edx
    756c3e105539:	btc    r10,0x1d
    756c3e10553e:	mov    r11d,0xf0000000
    756c3e105544:	and    r11,r10
    756c3e105547:	movabs rsi,0xffffffff0fffffff
    756c3e105551:	and    rbx,rsi
    756c3e105554:	or     rbx,r11
    756c3e105557:	pop    r11
    756c3e105559:	pop    r10
    756c3e10555b:	pop    rsi
    756c3e10555c:	pop    rdx
    756c3e10555d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e105565:	stmxcsr DWORD PTR [r12-0x28]
    756c3e10556b:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e105570:	test   r10d,0x3f
    756c3e105577:	je     0x756c3e10559c
    756c3e10557d:	mov    r11d,r10d
    756c3e105580:	shr    r10d,1
    756c3e105583:	and    r10d,0x1e
    756c3e105587:	and    r11d,0x1
    756c3e10558b:	or     r10d,r11d
    756c3e10558e:	or     DWORD PTR [r12+0x314],r10d
    756c3e105596:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e10559c:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1055a2:	lea    rdi,[rsp+0x110]
    756c3e1055aa:	lea    rsi,[rsp+0xf0]
    756c3e1055b2:	lea    rdx,[rsp+0x100]
    756c3e1055ba:	mov    ecx,0x14
    756c3e1055bf:	mov    r8d,0x0
    756c3e1055c5:	lea    r9,[r12+0x314]
    756c3e1055cd:	movabs r11,0x60a546cfd650
    756c3e1055d7:	call   r11
    756c3e1055da:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1055e0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1055e6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1055ec:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e1055f2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e1055f8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e1055fe:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e105604:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e10560e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e105618:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e105622:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e10562c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e105636:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10563e:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10564a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e105653:	mov    rdx,rbx
    756c3e105656:	shr    rdx,0x10
    756c3e10565a:	and    edx,0xc000
    756c3e105660:	mov    rax,rbx
    756c3e105663:	shr    rax,0x15
    756c3e105667:	and    eax,0x100
    756c3e10566c:	xor    eax,0x100
    756c3e105671:	or     edx,eax
    756c3e105673:	mov    rax,rbx
    756c3e105676:	shr    rax,0x1c
    756c3e10567a:	and    eax,0x1
    756c3e10567d:	or     edx,eax
    756c3e10567f:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e105684:	add    rsp,0x8
    756c3e105688:	ret
    756c3e105689:	nop    DWORD PTR [rax+0x0]
    756c3e105690:	sub    rsp,0x8
    756c3e105694:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1056a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1056a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1056ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1056b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1056b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1056be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1056c4:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e1056ce:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1056d8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e1056e2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e1056ec:	push   rdx
    756c3e1056ed:	push   rsi
    756c3e1056ee:	push   r10
    756c3e1056f0:	push   r11
    756c3e1056f2:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e1056f7:	mov    r10d,edx
    756c3e1056fa:	and    r10d,0xc000
    756c3e105701:	shl    r10d,0x10
    756c3e105705:	mov    r11d,edx
    756c3e105708:	and    r11d,0x100
    756c3e10570f:	shl    r11d,0x15
    756c3e105713:	or     r10d,r11d
    756c3e105716:	and    edx,0x1
    756c3e105719:	shl    edx,0x1c
    756c3e10571c:	or     r10d,edx
    756c3e10571f:	btc    r10,0x1d
    756c3e105724:	mov    r11d,0xf0000000
    756c3e10572a:	and    r11,r10
    756c3e10572d:	movabs rsi,0xffffffff0fffffff
    756c3e105737:	and    rbx,rsi
    756c3e10573a:	or     rbx,r11
    756c3e10573d:	pop    r11
    756c3e10573f:	pop    r10
    756c3e105741:	pop    rsi
    756c3e105742:	pop    rdx
    756c3e105743:	mov    QWORD PTR [r12+0x108],rbx
    756c3e10574b:	stmxcsr DWORD PTR [r12-0x28]
    756c3e105751:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e105756:	test   r10d,0x3f
    756c3e10575d:	je     0x756c3e105782
    756c3e105763:	mov    r11d,r10d
    756c3e105766:	shr    r10d,1
    756c3e105769:	and    r10d,0x1e
    756c3e10576d:	and    r11d,0x1
    756c3e105771:	or     r10d,r11d
    756c3e105774:	or     DWORD PTR [r12+0x314],r10d
    756c3e10577c:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e105782:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e105788:	lea    rdi,[rsp+0x110]
    756c3e105790:	lea    rsi,[rsp+0xf0]
    756c3e105798:	lea    rdx,[rsp+0x100]
    756c3e1057a0:	mov    ecx,0x56
    756c3e1057a5:	mov    r8d,0x0
    756c3e1057ab:	lea    r9,[r12+0x314]
    756c3e1057b3:	movabs r11,0x60a546cfd650
    756c3e1057bd:	call   r11
    756c3e1057c0:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1057c6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1057cc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1057d2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e1057d8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e1057de:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e1057e4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e1057ea:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e1057f4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e1057fe:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e105808:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e105812:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10581a:	mov    QWORD PTR [r12+0x378],0x2
    756c3e105826:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e10582f:	mov    rdx,rbx
    756c3e105832:	shr    rdx,0x10
    756c3e105836:	and    edx,0xc000
    756c3e10583c:	mov    rax,rbx
    756c3e10583f:	shr    rax,0x15
    756c3e105843:	and    eax,0x100
    756c3e105848:	xor    eax,0x100
    756c3e10584d:	or     edx,eax
    756c3e10584f:	mov    rax,rbx
    756c3e105852:	shr    rax,0x1c
    756c3e105856:	and    eax,0x1
    756c3e105859:	or     edx,eax
    756c3e10585b:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e105860:	add    rsp,0x8
    756c3e105864:	ret
    756c3e105865:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e105870:	sub    rsp,0x8
    756c3e105874:	mov    QWORD PTR [r12+0x378],0x3
    756c3e105880:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e105886:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e10588c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e105892:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e105898:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e10589e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1058a4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1058ae:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e1058b8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e1058c2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e1058cc:	push   rdx
    756c3e1058cd:	push   rsi
    756c3e1058ce:	push   r10
    756c3e1058d0:	push   r11
    756c3e1058d2:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e1058d7:	mov    r10d,edx
    756c3e1058da:	and    r10d,0xc000
    756c3e1058e1:	shl    r10d,0x10
    756c3e1058e5:	mov    r11d,edx
    756c3e1058e8:	and    r11d,0x100
    756c3e1058ef:	shl    r11d,0x15
    756c3e1058f3:	or     r10d,r11d
    756c3e1058f6:	and    edx,0x1
    756c3e1058f9:	shl    edx,0x1c
    756c3e1058fc:	or     r10d,edx
    756c3e1058ff:	btc    r10,0x1d
    756c3e105904:	mov    r11d,0xf0000000
    756c3e10590a:	and    r11,r10
    756c3e10590d:	movabs rsi,0xffffffff0fffffff
    756c3e105917:	and    rbx,rsi
    756c3e10591a:	or     rbx,r11
    756c3e10591d:	pop    r11
    756c3e10591f:	pop    r10
    756c3e105921:	pop    rsi
    756c3e105922:	pop    rdx
    756c3e105923:	mov    QWORD PTR [r12+0x108],rbx
    756c3e10592b:	stmxcsr DWORD PTR [r12-0x28]
    756c3e105931:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e105936:	test   r10d,0x3f
    756c3e10593d:	je     0x756c3e105962
    756c3e105943:	mov    r11d,r10d
    756c3e105946:	shr    r10d,1
    756c3e105949:	and    r10d,0x1e
    756c3e10594d:	and    r11d,0x1
    756c3e105951:	or     r10d,r11d
    756c3e105954:	or     DWORD PTR [r12+0x314],r10d
    756c3e10595c:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e105962:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e105968:	lea    rdi,[rsp+0x110]
    756c3e105970:	lea    rsi,[rsp+0xf0]
    756c3e105978:	lea    rdx,[rsp+0x100]
    756c3e105980:	mov    ecx,0x14
    756c3e105985:	mov    r8d,0x0
    756c3e10598b:	lea    r9,[r12+0x314]
    756c3e105993:	movabs r11,0x60a546cfd650
    756c3e10599d:	call   r11
    756c3e1059a0:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1059a6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1059ac:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1059b2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e1059b8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e1059be:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e1059c4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e1059ca:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e1059d4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e1059de:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e1059e8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e1059f2:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e1059fa:	mov    QWORD PTR [r12+0x378],0x2
    756c3e105a06:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e105a0f:	mov    rdx,rbx
    756c3e105a12:	shr    rdx,0x10
    756c3e105a16:	and    edx,0xc000
    756c3e105a1c:	mov    rax,rbx
    756c3e105a1f:	shr    rax,0x15
    756c3e105a23:	and    eax,0x100
    756c3e105a28:	xor    eax,0x100
    756c3e105a2d:	or     edx,eax
    756c3e105a2f:	mov    rax,rbx
    756c3e105a32:	shr    rax,0x1c
    756c3e105a36:	and    eax,0x1
    756c3e105a39:	or     edx,eax
    756c3e105a3b:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e105a40:	add    rsp,0x8
    756c3e105a44:	ret
    756c3e105a45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e105a50:	sub    rsp,0x8
    756c3e105a54:	mov    QWORD PTR [r12+0x378],0x3
    756c3e105a60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e105a66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e105a6c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e105a72:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e105a78:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e105a7e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e105a88:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e105a92:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e105a9c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e105aa6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e105ab0:	push   rdx
    756c3e105ab1:	push   rsi
    756c3e105ab2:	push   r10
    756c3e105ab4:	push   r11
    756c3e105ab6:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e105abb:	mov    r10d,edx
    756c3e105abe:	and    r10d,0xc000
    756c3e105ac5:	shl    r10d,0x10
    756c3e105ac9:	mov    r11d,edx
    756c3e105acc:	and    r11d,0x100
    756c3e105ad3:	shl    r11d,0x15
    756c3e105ad7:	or     r10d,r11d
    756c3e105ada:	and    edx,0x1
    756c3e105add:	shl    edx,0x1c
    756c3e105ae0:	or     r10d,edx
    756c3e105ae3:	btc    r10,0x1d
    756c3e105ae8:	mov    r11d,0xf0000000
    756c3e105aee:	and    r11,r10
    756c3e105af1:	movabs rsi,0xffffffff0fffffff
    756c3e105afb:	and    rbx,rsi
    756c3e105afe:	or     rbx,r11
    756c3e105b01:	pop    r11
    756c3e105b03:	pop    r10
    756c3e105b05:	pop    rsi
    756c3e105b06:	pop    rdx
    756c3e105b07:	mov    QWORD PTR [r12+0x108],rbx
    756c3e105b0f:	stmxcsr DWORD PTR [r12-0x28]
    756c3e105b15:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e105b1a:	test   r10d,0x3f
    756c3e105b21:	je     0x756c3e105b46
    756c3e105b27:	mov    r11d,r10d
    756c3e105b2a:	shr    r10d,1
    756c3e105b2d:	and    r10d,0x1e
    756c3e105b31:	and    r11d,0x1
    756c3e105b35:	or     r10d,r11d
    756c3e105b38:	or     DWORD PTR [r12+0x314],r10d
    756c3e105b40:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e105b46:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e105b4c:	lea    rdi,[rsp+0x110]
    756c3e105b54:	lea    rsi,[rsp+0xf0]
    756c3e105b5c:	lea    rdx,[rsp+0x100]
    756c3e105b64:	mov    ecx,0x56
    756c3e105b69:	mov    r8d,0x0
    756c3e105b6f:	lea    r9,[r12+0x314]
    756c3e105b77:	movabs r11,0x60a546cfd650
    756c3e105b81:	call   r11
    756c3e105b84:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e105b8a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e105b90:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e105b96:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e105b9c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e105ba2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e105ba8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e105bb2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e105bbc:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e105bc6:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e105bd0:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e105bda:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e105be2:	mov    QWORD PTR [r12+0x378],0x2
    756c3e105bee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e105bf7:	mov    rdx,rbx
    756c3e105bfa:	shr    rdx,0x10
    756c3e105bfe:	and    edx,0xc000
    756c3e105c04:	mov    rax,rbx
    756c3e105c07:	shr    rax,0x15
    756c3e105c0b:	and    eax,0x100
    756c3e105c10:	xor    eax,0x100
    756c3e105c15:	or     edx,eax
    756c3e105c17:	mov    rax,rbx
    756c3e105c1a:	shr    rax,0x1c
    756c3e105c1e:	and    eax,0x1
    756c3e105c21:	or     edx,eax
    756c3e105c23:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e105c28:	add    rsp,0x8
    756c3e105c2c:	ret
    756c3e105c2d:	nop    DWORD PTR [rax]
    756c3e105c30:	sub    rsp,0x8
    756c3e105c34:	mov    QWORD PTR [r12+0x378],0x3
    756c3e105c40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e105c46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e105c4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e105c52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e105c58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e105c5e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e105c64:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e105c6e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e105c78:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e105c82:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e105c8c:	push   rdx
    756c3e105c8d:	push   rsi
    756c3e105c8e:	push   r10
    756c3e105c90:	push   r11
    756c3e105c92:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e105c97:	mov    r10d,edx
    756c3e105c9a:	and    r10d,0xc000
    756c3e105ca1:	shl    r10d,0x10
    756c3e105ca5:	mov    r11d,edx
    756c3e105ca8:	and    r11d,0x100
    756c3e105caf:	shl    r11d,0x15
    756c3e105cb3:	or     r10d,r11d
    756c3e105cb6:	and    edx,0x1
    756c3e105cb9:	shl    edx,0x1c
    756c3e105cbc:	or     r10d,edx
    756c3e105cbf:	btc    r10,0x1d
    756c3e105cc4:	mov    r11d,0xf0000000
    756c3e105cca:	and    r11,r10
    756c3e105ccd:	movabs rsi,0xffffffff0fffffff
    756c3e105cd7:	and    rbx,rsi
    756c3e105cda:	or     rbx,r11
    756c3e105cdd:	pop    r11
    756c3e105cdf:	pop    r10
    756c3e105ce1:	pop    rsi
    756c3e105ce2:	pop    rdx
    756c3e105ce3:	mov    QWORD PTR [r12+0x108],rbx
    756c3e105ceb:	stmxcsr DWORD PTR [r12-0x28]
    756c3e105cf1:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e105cf6:	test   r10d,0x3f
    756c3e105cfd:	je     0x756c3e105d22
    756c3e105d03:	mov    r11d,r10d
    756c3e105d06:	shr    r10d,1
    756c3e105d09:	and    r10d,0x1e
    756c3e105d0d:	and    r11d,0x1
    756c3e105d11:	or     r10d,r11d
    756c3e105d14:	or     DWORD PTR [r12+0x314],r10d
    756c3e105d1c:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e105d22:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e105d28:	lea    rdi,[rsp+0x110]
    756c3e105d30:	lea    rsi,[rsp+0xf0]
    756c3e105d38:	lea    rdx,[rsp+0x100]
    756c3e105d40:	mov    ecx,0x56
    756c3e105d45:	mov    r8d,0x0
    756c3e105d4b:	lea    r9,[r12+0x314]
    756c3e105d53:	movabs r11,0x60a546cfd650
    756c3e105d5d:	call   r11
    756c3e105d60:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e105d66:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e105d6c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e105d72:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e105d78:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e105d7e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e105d84:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e105d8a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e105d94:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e105d9e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e105da8:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e105db2:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e105dba:	mov    QWORD PTR [r12+0x378],0x2
    756c3e105dc6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e105dcf:	mov    rdx,rbx
    756c3e105dd2:	shr    rdx,0x10
    756c3e105dd6:	and    edx,0xc000
    756c3e105ddc:	mov    rax,rbx
    756c3e105ddf:	shr    rax,0x15
    756c3e105de3:	and    eax,0x100
    756c3e105de8:	xor    eax,0x100
    756c3e105ded:	or     edx,eax
    756c3e105def:	mov    rax,rbx
    756c3e105df2:	shr    rax,0x1c
    756c3e105df6:	and    eax,0x1
    756c3e105df9:	or     edx,eax
    756c3e105dfb:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e105e00:	add    rsp,0x8
    756c3e105e04:	ret
    756c3e105e05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e105e10:	sub    rsp,0x8
    756c3e105e14:	mov    QWORD PTR [r12+0x378],0x3
    756c3e105e20:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e105e26:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e105e2c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e105e32:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e105e38:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e105e3e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e105e44:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e105e4e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e105e58:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e105e62:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e105e6c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e105e76:	push   rdx
    756c3e105e77:	push   rsi
    756c3e105e78:	push   r10
    756c3e105e7a:	push   r11
    756c3e105e7c:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e105e81:	mov    r10d,edx
    756c3e105e84:	and    r10d,0xc000
    756c3e105e8b:	shl    r10d,0x10
    756c3e105e8f:	mov    r11d,edx
    756c3e105e92:	and    r11d,0x100
    756c3e105e99:	shl    r11d,0x15
    756c3e105e9d:	or     r10d,r11d
    756c3e105ea0:	and    edx,0x1
    756c3e105ea3:	shl    edx,0x1c
    756c3e105ea6:	or     r10d,edx
    756c3e105ea9:	btc    r10,0x1d
    756c3e105eae:	mov    r11d,0xf0000000
    756c3e105eb4:	and    r11,r10
    756c3e105eb7:	movabs rsi,0xffffffff0fffffff
    756c3e105ec1:	and    rbx,rsi
    756c3e105ec4:	or     rbx,r11
    756c3e105ec7:	pop    r11
    756c3e105ec9:	pop    r10
    756c3e105ecb:	pop    rsi
    756c3e105ecc:	pop    rdx
    756c3e105ecd:	mov    QWORD PTR [r12+0x108],rbx
    756c3e105ed5:	stmxcsr DWORD PTR [r12-0x28]
    756c3e105edb:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e105ee0:	test   r10d,0x3f
    756c3e105ee7:	je     0x756c3e105f0c
    756c3e105eed:	mov    r11d,r10d
    756c3e105ef0:	shr    r10d,1
    756c3e105ef3:	and    r10d,0x1e
    756c3e105ef7:	and    r11d,0x1
    756c3e105efb:	or     r10d,r11d
    756c3e105efe:	or     DWORD PTR [r12+0x314],r10d
    756c3e105f06:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e105f0c:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e105f12:	lea    rdi,[rsp+0x110]
    756c3e105f1a:	lea    rsi,[rsp+0xf0]
    756c3e105f22:	lea    rdx,[rsp+0x100]
    756c3e105f2a:	mov    ecx,0x14
    756c3e105f2f:	mov    r8d,0x0
    756c3e105f35:	lea    r9,[r12+0x314]
    756c3e105f3d:	movabs r11,0x60a546cfd650
    756c3e105f47:	call   r11
    756c3e105f4a:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e105f50:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e105f56:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e105f5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e105f62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e105f68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e105f6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e105f74:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e105f7e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e105f88:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e105f92:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e105f9c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e105fa6:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e105fae:	mov    QWORD PTR [r12+0x378],0x2
    756c3e105fba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e105fc3:	mov    rdx,rbx
    756c3e105fc6:	shr    rdx,0x10
    756c3e105fca:	and    edx,0xc000
    756c3e105fd0:	mov    rax,rbx
    756c3e105fd3:	shr    rax,0x15
    756c3e105fd7:	and    eax,0x100
    756c3e105fdc:	xor    eax,0x100
    756c3e105fe1:	or     edx,eax
    756c3e105fe3:	mov    rax,rbx
    756c3e105fe6:	shr    rax,0x1c
    756c3e105fea:	and    eax,0x1
    756c3e105fed:	or     edx,eax
    756c3e105fef:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e105ff4:	add    rsp,0x8
    756c3e105ff8:	ret
    756c3e105ff9:	nop    DWORD PTR [rax+0x0]
    756c3e106000:	sub    rsp,0x8
    756c3e106004:	mov    QWORD PTR [r12+0x378],0x3
    756c3e106010:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e106016:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e10601c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e106022:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e106028:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e106032:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e10603c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e106046:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e106050:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e10605a:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e106064:	push   rdx
    756c3e106065:	push   rsi
    756c3e106066:	push   r10
    756c3e106068:	push   r11
    756c3e10606a:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e10606f:	mov    r10d,edx
    756c3e106072:	and    r10d,0xc000
    756c3e106079:	shl    r10d,0x10
    756c3e10607d:	mov    r11d,edx
    756c3e106080:	and    r11d,0x100
    756c3e106087:	shl    r11d,0x15
    756c3e10608b:	or     r10d,r11d
    756c3e10608e:	and    edx,0x1
    756c3e106091:	shl    edx,0x1c
    756c3e106094:	or     r10d,edx
    756c3e106097:	btc    r10,0x1d
    756c3e10609c:	mov    r11d,0xf0000000
    756c3e1060a2:	and    r11,r10
    756c3e1060a5:	movabs rsi,0xffffffff0fffffff
    756c3e1060af:	and    rbx,rsi
    756c3e1060b2:	or     rbx,r11
    756c3e1060b5:	pop    r11
    756c3e1060b7:	pop    r10
    756c3e1060b9:	pop    rsi
    756c3e1060ba:	pop    rdx
    756c3e1060bb:	mov    QWORD PTR [r12+0x108],rbx
    756c3e1060c3:	stmxcsr DWORD PTR [r12-0x28]
    756c3e1060c9:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e1060ce:	test   r10d,0x3f
    756c3e1060d5:	je     0x756c3e1060fa
    756c3e1060db:	mov    r11d,r10d
    756c3e1060de:	shr    r10d,1
    756c3e1060e1:	and    r10d,0x1e
    756c3e1060e5:	and    r11d,0x1
    756c3e1060e9:	or     r10d,r11d
    756c3e1060ec:	or     DWORD PTR [r12+0x314],r10d
    756c3e1060f4:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1060fa:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e106100:	lea    rdi,[rsp+0x110]
    756c3e106108:	lea    rsi,[rsp+0xf0]
    756c3e106110:	lea    rdx,[rsp+0x100]
    756c3e106118:	mov    ecx,0x56
    756c3e10611d:	mov    r8d,0x0
    756c3e106123:	lea    r9,[r12+0x314]
    756c3e10612b:	movabs r11,0x60a546cfd650
    756c3e106135:	call   r11
    756c3e106138:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e10613e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e106144:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e10614a:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e106150:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e106156:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e106160:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e10616a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e106174:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e10617e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e106188:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e106192:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10619a:	mov    QWORD PTR [r12+0x378],0x2
    756c3e1061a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e1061af:	mov    rdx,rbx
    756c3e1061b2:	shr    rdx,0x10
    756c3e1061b6:	and    edx,0xc000
    756c3e1061bc:	mov    rax,rbx
    756c3e1061bf:	shr    rax,0x15
    756c3e1061c3:	and    eax,0x100
    756c3e1061c8:	xor    eax,0x100
    756c3e1061cd:	or     edx,eax
    756c3e1061cf:	mov    rax,rbx
    756c3e1061d2:	shr    rax,0x1c
    756c3e1061d6:	and    eax,0x1
    756c3e1061d9:	or     edx,eax
    756c3e1061db:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1061e0:	add    rsp,0x8
    756c3e1061e4:	ret
    756c3e1061e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e1061f0:	sub    rsp,0x8
    756c3e1061f4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e106200:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e106206:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e10620c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e106212:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e106218:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e10621e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e106228:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e106232:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e10623c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e106246:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e106250:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e10625a:	push   rdx
    756c3e10625b:	push   rsi
    756c3e10625c:	push   r10
    756c3e10625e:	push   r11
    756c3e106260:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e106265:	mov    r10d,edx
    756c3e106268:	and    r10d,0xc000
    756c3e10626f:	shl    r10d,0x10
    756c3e106273:	mov    r11d,edx
    756c3e106276:	and    r11d,0x100
    756c3e10627d:	shl    r11d,0x15
    756c3e106281:	or     r10d,r11d
    756c3e106284:	and    edx,0x1
    756c3e106287:	shl    edx,0x1c
    756c3e10628a:	or     r10d,edx
    756c3e10628d:	btc    r10,0x1d
    756c3e106292:	mov    r11d,0xf0000000
    756c3e106298:	and    r11,r10
    756c3e10629b:	movabs rsi,0xffffffff0fffffff
    756c3e1062a5:	and    rbx,rsi
    756c3e1062a8:	or     rbx,r11
    756c3e1062ab:	pop    r11
    756c3e1062ad:	pop    r10
    756c3e1062af:	pop    rsi
    756c3e1062b0:	pop    rdx
    756c3e1062b1:	mov    QWORD PTR [r12+0x108],rbx
    756c3e1062b9:	stmxcsr DWORD PTR [r12-0x28]
    756c3e1062bf:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e1062c4:	test   r10d,0x3f
    756c3e1062cb:	je     0x756c3e1062f0
    756c3e1062d1:	mov    r11d,r10d
    756c3e1062d4:	shr    r10d,1
    756c3e1062d7:	and    r10d,0x1e
    756c3e1062db:	and    r11d,0x1
    756c3e1062df:	or     r10d,r11d
    756c3e1062e2:	or     DWORD PTR [r12+0x314],r10d
    756c3e1062ea:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1062f0:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1062f6:	lea    rdi,[rsp+0x110]
    756c3e1062fe:	lea    rsi,[rsp+0xf0]
    756c3e106306:	lea    rdx,[rsp+0x100]
    756c3e10630e:	mov    ecx,0x14
    756c3e106313:	mov    r8d,0x0
    756c3e106319:	lea    r9,[r12+0x314]
    756c3e106321:	movabs r11,0x60a546cfd650
    756c3e10632b:	call   r11
    756c3e10632e:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e106334:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e10633a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e106340:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e106346:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e10634c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e106352:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e10635c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e106366:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e106370:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e10637a:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e106384:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e10638e:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e106396:	mov    QWORD PTR [r12+0x378],0x2
    756c3e1063a2:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e1063ab:	mov    rdx,rbx
    756c3e1063ae:	shr    rdx,0x10
    756c3e1063b2:	and    edx,0xc000
    756c3e1063b8:	mov    rax,rbx
    756c3e1063bb:	shr    rax,0x15
    756c3e1063bf:	and    eax,0x100
    756c3e1063c4:	xor    eax,0x100
    756c3e1063c9:	or     edx,eax
    756c3e1063cb:	mov    rax,rbx
    756c3e1063ce:	shr    rax,0x1c
    756c3e1063d2:	and    eax,0x1
    756c3e1063d5:	or     edx,eax
    756c3e1063d7:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1063dc:	add    rsp,0x8
    756c3e1063e0:	ret
    756c3e1063e1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e1063f0:	sub    rsp,0x8
    756c3e1063f4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e106400:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e106406:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e10640c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e106412:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e106418:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e10641e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e106424:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e10642e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e106438:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e106442:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e10644c:	push   rdx
    756c3e10644d:	push   rsi
    756c3e10644e:	push   r10
    756c3e106450:	push   r11
    756c3e106452:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e106457:	mov    r10d,edx
    756c3e10645a:	and    r10d,0xc000
    756c3e106461:	shl    r10d,0x10
    756c3e106465:	mov    r11d,edx
    756c3e106468:	and    r11d,0x100
    756c3e10646f:	shl    r11d,0x15
    756c3e106473:	or     r10d,r11d
    756c3e106476:	and    edx,0x1
    756c3e106479:	shl    edx,0x1c
    756c3e10647c:	or     r10d,edx
    756c3e10647f:	btc    r10,0x1d
    756c3e106484:	mov    r11d,0xf0000000
    756c3e10648a:	and    r11,r10
    756c3e10648d:	movabs rsi,0xffffffff0fffffff
    756c3e106497:	and    rbx,rsi
    756c3e10649a:	or     rbx,r11
    756c3e10649d:	pop    r11
    756c3e10649f:	pop    r10
    756c3e1064a1:	pop    rsi
    756c3e1064a2:	pop    rdx
    756c3e1064a3:	mov    QWORD PTR [r12+0x108],rbx
    756c3e1064ab:	stmxcsr DWORD PTR [r12-0x28]
    756c3e1064b1:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e1064b6:	test   r10d,0x3f
    756c3e1064bd:	je     0x756c3e1064e2
    756c3e1064c3:	mov    r11d,r10d
    756c3e1064c6:	shr    r10d,1
    756c3e1064c9:	and    r10d,0x1e
    756c3e1064cd:	and    r11d,0x1
    756c3e1064d1:	or     r10d,r11d
    756c3e1064d4:	or     DWORD PTR [r12+0x314],r10d
    756c3e1064dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1064e2:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1064e8:	lea    rdi,[rsp+0x110]
    756c3e1064f0:	lea    rsi,[rsp+0xf0]
    756c3e1064f8:	lea    rdx,[rsp+0x100]
    756c3e106500:	mov    ecx,0x56
    756c3e106505:	mov    r8d,0x0
    756c3e10650b:	lea    r9,[r12+0x314]
    756c3e106513:	movabs r11,0x60a546cfd650
    756c3e10651d:	call   r11
    756c3e106520:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e106526:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e10652c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e106532:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e106538:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e10653e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e106544:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e10654a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e106554:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e10655e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e106568:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e106572:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10657a:	mov    QWORD PTR [r12+0x378],0x2
    756c3e106586:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e10658f:	mov    rdx,rbx
    756c3e106592:	shr    rdx,0x10
    756c3e106596:	and    edx,0xc000
    756c3e10659c:	mov    rax,rbx
    756c3e10659f:	shr    rax,0x15
    756c3e1065a3:	and    eax,0x100
    756c3e1065a8:	xor    eax,0x100
    756c3e1065ad:	or     edx,eax
    756c3e1065af:	mov    rax,rbx
    756c3e1065b2:	shr    rax,0x1c
    756c3e1065b6:	and    eax,0x1
    756c3e1065b9:	or     edx,eax
    756c3e1065bb:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1065c0:	add    rsp,0x8
    756c3e1065c4:	ret
    756c3e1065c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e1065d0:	sub    rsp,0x8
    756c3e1065d4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1065e0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1065e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1065ec:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1065f2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1065f8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e106602:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e10660c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e106616:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e106620:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    756c3e10662a:	push   rdx
    756c3e10662b:	push   rsi
    756c3e10662c:	push   r10
    756c3e10662e:	push   r11
    756c3e106630:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e106635:	mov    r10d,edx
    756c3e106638:	and    r10d,0xc000
    756c3e10663f:	shl    r10d,0x10
    756c3e106643:	mov    r11d,edx
    756c3e106646:	and    r11d,0x100
    756c3e10664d:	shl    r11d,0x15
    756c3e106651:	or     r10d,r11d
    756c3e106654:	and    edx,0x1
    756c3e106657:	shl    edx,0x1c
    756c3e10665a:	or     r10d,edx
    756c3e10665d:	btc    r10,0x1d
    756c3e106662:	mov    r11d,0xf0000000
    756c3e106668:	and    r11,r10
    756c3e10666b:	movabs rsi,0xffffffff0fffffff
    756c3e106675:	and    rbx,rsi
    756c3e106678:	or     rbx,r11
    756c3e10667b:	pop    r11
    756c3e10667d:	pop    r10
    756c3e10667f:	pop    rsi
    756c3e106680:	pop    rdx
    756c3e106681:	mov    QWORD PTR [r12+0x108],rbx
    756c3e106689:	stmxcsr DWORD PTR [r12-0x28]
    756c3e10668f:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e106694:	test   r10d,0x3f
    756c3e10669b:	je     0x756c3e1066c0
    756c3e1066a1:	mov    r11d,r10d
    756c3e1066a4:	shr    r10d,1
    756c3e1066a7:	and    r10d,0x1e
    756c3e1066ab:	and    r11d,0x1
    756c3e1066af:	or     r10d,r11d
    756c3e1066b2:	or     DWORD PTR [r12+0x314],r10d
    756c3e1066ba:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1066c0:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1066c6:	lea    rdi,[rsp+0x110]
    756c3e1066ce:	lea    rsi,[rsp+0xf0]
    756c3e1066d6:	lea    rdx,[rsp+0x100]
    756c3e1066de:	mov    ecx,0x14
    756c3e1066e3:	mov    r8d,0x0
    756c3e1066e9:	lea    r9,[r12+0x314]
    756c3e1066f1:	movabs r11,0x60a546cfd650
    756c3e1066fb:	call   r11
    756c3e1066fe:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e106704:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e10670a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e106710:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e106716:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e10671c:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e106726:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e106730:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e10673a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e106744:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    756c3e10674e:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e106756:	mov    QWORD PTR [r12+0x378],0x2
    756c3e106762:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e10676b:	mov    rdx,rbx
    756c3e10676e:	shr    rdx,0x10
    756c3e106772:	and    edx,0xc000
    756c3e106778:	mov    rax,rbx
    756c3e10677b:	shr    rax,0x15
    756c3e10677f:	and    eax,0x100
    756c3e106784:	xor    eax,0x100
    756c3e106789:	or     edx,eax
    756c3e10678b:	mov    rax,rbx
    756c3e10678e:	shr    rax,0x1c
    756c3e106792:	and    eax,0x1
    756c3e106795:	or     edx,eax
    756c3e106797:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e10679c:	add    rsp,0x8
    756c3e1067a0:	ret
    756c3e1067a1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e1067b0:	sub    rsp,0x8
    756c3e1067b4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1067c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1067c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1067cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1067d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1067d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1067de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1067e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e1067ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e1067f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e106802:	push   rdx
    756c3e106803:	push   rsi
    756c3e106804:	push   r10
    756c3e106806:	push   r11
    756c3e106808:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e10680d:	mov    r10d,edx
    756c3e106810:	and    r10d,0xc000
    756c3e106817:	shl    r10d,0x10
    756c3e10681b:	mov    r11d,edx
    756c3e10681e:	and    r11d,0x100
    756c3e106825:	shl    r11d,0x15
    756c3e106829:	or     r10d,r11d
    756c3e10682c:	and    edx,0x1
    756c3e10682f:	shl    edx,0x1c
    756c3e106832:	or     r10d,edx
    756c3e106835:	btc    r10,0x1d
    756c3e10683a:	mov    r11d,0xf0000000
    756c3e106840:	and    r11,r10
    756c3e106843:	movabs rsi,0xffffffff0fffffff
    756c3e10684d:	and    rbx,rsi
    756c3e106850:	or     rbx,r11
    756c3e106853:	pop    r11
    756c3e106855:	pop    r10
    756c3e106857:	pop    rsi
    756c3e106858:	pop    rdx
    756c3e106859:	mov    QWORD PTR [r12+0x108],rbx
    756c3e106861:	stmxcsr DWORD PTR [r12-0x28]
    756c3e106867:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e10686c:	test   r10d,0x3f
    756c3e106873:	je     0x756c3e106898
    756c3e106879:	mov    r11d,r10d
    756c3e10687c:	shr    r10d,1
    756c3e10687f:	and    r10d,0x1e
    756c3e106883:	and    r11d,0x1
    756c3e106887:	or     r10d,r11d
    756c3e10688a:	or     DWORD PTR [r12+0x314],r10d
    756c3e106892:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e106898:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e10689e:	lea    rdi,[rsp+0x110]
    756c3e1068a6:	lea    rsi,[rsp+0xf0]
    756c3e1068ae:	lea    rdx,[rsp+0x100]
    756c3e1068b6:	mov    ecx,0x56
    756c3e1068bb:	mov    r8d,0x0
    756c3e1068c1:	lea    r9,[r12+0x314]
    756c3e1068c9:	movabs r11,0x60a546cfd650
    756c3e1068d3:	call   r11
    756c3e1068d6:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1068dc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1068e2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1068e8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e1068ee:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e1068f4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e1068fa:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e106900:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e10690a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e106914:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e10691e:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e106926:	mov    QWORD PTR [r12+0x378],0x2
    756c3e106932:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e10693b:	mov    rdx,rbx
    756c3e10693e:	shr    rdx,0x10
    756c3e106942:	and    edx,0xc000
    756c3e106948:	mov    rax,rbx
    756c3e10694b:	shr    rax,0x15
    756c3e10694f:	and    eax,0x100
    756c3e106954:	xor    eax,0x100
    756c3e106959:	or     edx,eax
    756c3e10695b:	mov    rax,rbx
    756c3e10695e:	shr    rax,0x1c
    756c3e106962:	and    eax,0x1
    756c3e106965:	or     edx,eax
    756c3e106967:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e10696c:	add    rsp,0x8
    756c3e106970:	ret
    756c3e106971:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e106980:	sub    rsp,0x8
    756c3e106984:	mov    QWORD PTR [r12+0x378],0x3
    756c3e106990:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e106996:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e10699c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1069a2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1069a8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1069ae:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e1069b8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e1069c2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1069cc:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e1069d6:	push   rdx
    756c3e1069d7:	push   rsi
    756c3e1069d8:	push   r10
    756c3e1069da:	push   r11
    756c3e1069dc:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e1069e1:	mov    r10d,edx
    756c3e1069e4:	and    r10d,0xc000
    756c3e1069eb:	shl    r10d,0x10
    756c3e1069ef:	mov    r11d,edx
    756c3e1069f2:	and    r11d,0x100
    756c3e1069f9:	shl    r11d,0x15
    756c3e1069fd:	or     r10d,r11d
    756c3e106a00:	and    edx,0x1
    756c3e106a03:	shl    edx,0x1c
    756c3e106a06:	or     r10d,edx
    756c3e106a09:	btc    r10,0x1d
    756c3e106a0e:	mov    r11d,0xf0000000
    756c3e106a14:	and    r11,r10
    756c3e106a17:	movabs rsi,0xffffffff0fffffff
    756c3e106a21:	and    rbx,rsi
    756c3e106a24:	or     rbx,r11
    756c3e106a27:	pop    r11
    756c3e106a29:	pop    r10
    756c3e106a2b:	pop    rsi
    756c3e106a2c:	pop    rdx
    756c3e106a2d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e106a35:	stmxcsr DWORD PTR [r12-0x28]
    756c3e106a3b:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e106a40:	test   r10d,0x3f
    756c3e106a47:	je     0x756c3e106a6c
    756c3e106a4d:	mov    r11d,r10d
    756c3e106a50:	shr    r10d,1
    756c3e106a53:	and    r10d,0x1e
    756c3e106a57:	and    r11d,0x1
    756c3e106a5b:	or     r10d,r11d
    756c3e106a5e:	or     DWORD PTR [r12+0x314],r10d
    756c3e106a66:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e106a6c:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e106a72:	lea    rdi,[rsp+0x110]
    756c3e106a7a:	lea    rsi,[rsp+0xf0]
    756c3e106a82:	lea    rdx,[rsp+0x100]
    756c3e106a8a:	mov    ecx,0x56
    756c3e106a8f:	mov    r8d,0x0
    756c3e106a95:	lea    r9,[r12+0x314]
    756c3e106a9d:	movabs r11,0x60a546cfd650
    756c3e106aa7:	call   r11
    756c3e106aaa:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e106ab0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e106ab6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e106abc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e106ac2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e106ac8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e106ace:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e106ad8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e106ae2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e106aec:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e106af6:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e106afe:	mov    QWORD PTR [r12+0x378],0x2
    756c3e106b0a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e106b13:	mov    rdx,rbx
    756c3e106b16:	shr    rdx,0x10
    756c3e106b1a:	and    edx,0xc000
    756c3e106b20:	mov    rax,rbx
    756c3e106b23:	shr    rax,0x15
    756c3e106b27:	and    eax,0x100
    756c3e106b2c:	xor    eax,0x100
    756c3e106b31:	or     edx,eax
    756c3e106b33:	mov    rax,rbx
    756c3e106b36:	shr    rax,0x1c
    756c3e106b3a:	and    eax,0x1
    756c3e106b3d:	or     edx,eax
    756c3e106b3f:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e106b44:	add    rsp,0x8
    756c3e106b48:	ret
    756c3e106b49:	nop    DWORD PTR [rax+0x0]
    756c3e106b50:	sub    rsp,0x8
    756c3e106b54:	mov    QWORD PTR [r12+0x378],0x3
    756c3e106b60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e106b66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e106b6c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e106b72:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e106b78:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e106b7e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e106b84:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e106b8e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e106b98:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e106ba2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e106bac:	push   rdx
    756c3e106bad:	push   rsi
    756c3e106bae:	push   r10
    756c3e106bb0:	push   r11
    756c3e106bb2:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e106bb7:	mov    r10d,edx
    756c3e106bba:	and    r10d,0xc000
    756c3e106bc1:	shl    r10d,0x10
    756c3e106bc5:	mov    r11d,edx
    756c3e106bc8:	and    r11d,0x100
    756c3e106bcf:	shl    r11d,0x15
    756c3e106bd3:	or     r10d,r11d
    756c3e106bd6:	and    edx,0x1
    756c3e106bd9:	shl    edx,0x1c
    756c3e106bdc:	or     r10d,edx
    756c3e106bdf:	btc    r10,0x1d
    756c3e106be4:	mov    r11d,0xf0000000
    756c3e106bea:	and    r11,r10
    756c3e106bed:	movabs rsi,0xffffffff0fffffff
    756c3e106bf7:	and    rbx,rsi
    756c3e106bfa:	or     rbx,r11
    756c3e106bfd:	pop    r11
    756c3e106bff:	pop    r10
    756c3e106c01:	pop    rsi
    756c3e106c02:	pop    rdx
    756c3e106c03:	mov    QWORD PTR [r12+0x108],rbx
    756c3e106c0b:	stmxcsr DWORD PTR [r12-0x28]
    756c3e106c11:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e106c16:	test   r10d,0x3f
    756c3e106c1d:	je     0x756c3e106c42
    756c3e106c23:	mov    r11d,r10d
    756c3e106c26:	shr    r10d,1
    756c3e106c29:	and    r10d,0x1e
    756c3e106c2d:	and    r11d,0x1
    756c3e106c31:	or     r10d,r11d
    756c3e106c34:	or     DWORD PTR [r12+0x314],r10d
    756c3e106c3c:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e106c42:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e106c48:	lea    rdi,[rsp+0x110]
    756c3e106c50:	lea    rsi,[rsp+0xf0]
    756c3e106c58:	lea    rdx,[rsp+0x100]
    756c3e106c60:	mov    ecx,0x14
    756c3e106c65:	mov    r8d,0x0
    756c3e106c6b:	lea    r9,[r12+0x314]
    756c3e106c73:	movabs r11,0x60a546cfd650
    756c3e106c7d:	call   r11
    756c3e106c80:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e106c86:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e106c8c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e106c92:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e106c98:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e106c9e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e106ca4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e106caa:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e106cb4:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e106cbe:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e106cc8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e106cd2:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e106cda:	mov    QWORD PTR [r12+0x378],0x2
    756c3e106ce6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e106cef:	mov    rdx,rbx
    756c3e106cf2:	shr    rdx,0x10
    756c3e106cf6:	and    edx,0xc000
    756c3e106cfc:	mov    rax,rbx
    756c3e106cff:	shr    rax,0x15
    756c3e106d03:	and    eax,0x100
    756c3e106d08:	xor    eax,0x100
    756c3e106d0d:	or     edx,eax
    756c3e106d0f:	mov    rax,rbx
    756c3e106d12:	shr    rax,0x1c
    756c3e106d16:	and    eax,0x1
    756c3e106d19:	or     edx,eax
    756c3e106d1b:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e106d20:	add    rsp,0x8
    756c3e106d24:	ret
    756c3e106d25:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e106d30:	sub    rsp,0x8
    756c3e106d34:	mov    QWORD PTR [r12+0x378],0x3
    756c3e106d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e106d46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e106d4c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e106d52:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e106d58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e106d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e106d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e106d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e106d7c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e106d86:	push   rdx
    756c3e106d87:	push   rsi
    756c3e106d88:	push   r10
    756c3e106d8a:	push   r11
    756c3e106d8c:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e106d91:	mov    r10d,edx
    756c3e106d94:	and    r10d,0xc000
    756c3e106d9b:	shl    r10d,0x10
    756c3e106d9f:	mov    r11d,edx
    756c3e106da2:	and    r11d,0x100
    756c3e106da9:	shl    r11d,0x15
    756c3e106dad:	or     r10d,r11d
    756c3e106db0:	and    edx,0x1
    756c3e106db3:	shl    edx,0x1c
    756c3e106db6:	or     r10d,edx
    756c3e106db9:	btc    r10,0x1d
    756c3e106dbe:	mov    r11d,0xf0000000
    756c3e106dc4:	and    r11,r10
    756c3e106dc7:	movabs rsi,0xffffffff0fffffff
    756c3e106dd1:	and    rbx,rsi
    756c3e106dd4:	or     rbx,r11
    756c3e106dd7:	pop    r11
    756c3e106dd9:	pop    r10
    756c3e106ddb:	pop    rsi
    756c3e106ddc:	pop    rdx
    756c3e106ddd:	mov    QWORD PTR [r12+0x108],rbx
    756c3e106de5:	stmxcsr DWORD PTR [r12-0x28]
    756c3e106deb:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e106df0:	test   r10d,0x3f
    756c3e106df7:	je     0x756c3e106e1c
    756c3e106dfd:	mov    r11d,r10d
    756c3e106e00:	shr    r10d,1
    756c3e106e03:	and    r10d,0x1e
    756c3e106e07:	and    r11d,0x1
    756c3e106e0b:	or     r10d,r11d
    756c3e106e0e:	or     DWORD PTR [r12+0x314],r10d
    756c3e106e16:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e106e1c:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e106e22:	lea    rdi,[rsp+0x110]
    756c3e106e2a:	lea    rsi,[rsp+0xf0]
    756c3e106e32:	lea    rdx,[rsp+0x100]
    756c3e106e3a:	mov    ecx,0x14
    756c3e106e3f:	mov    r8d,0x0
    756c3e106e45:	lea    r9,[r12+0x314]
    756c3e106e4d:	movabs r11,0x60a546cfd650
    756c3e106e57:	call   r11
    756c3e106e5a:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e106e60:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e106e66:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e106e6c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e106e72:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e106e78:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e106e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e106e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e106e92:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e106e9c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e106ea6:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e106eae:	mov    QWORD PTR [r12+0x378],0x2
    756c3e106eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e106ec3:	mov    rdx,rbx
    756c3e106ec6:	shr    rdx,0x10
    756c3e106eca:	and    edx,0xc000
    756c3e106ed0:	mov    rax,rbx
    756c3e106ed3:	shr    rax,0x15
    756c3e106ed7:	and    eax,0x100
    756c3e106edc:	xor    eax,0x100
    756c3e106ee1:	or     edx,eax
    756c3e106ee3:	mov    rax,rbx
    756c3e106ee6:	shr    rax,0x1c
    756c3e106eea:	and    eax,0x1
    756c3e106eed:	or     edx,eax
    756c3e106eef:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e106ef4:	add    rsp,0x8
    756c3e106ef8:	ret
    756c3e106ef9:	nop    DWORD PTR [rax+0x0]
    756c3e106f00:	sub    rsp,0x8
    756c3e106f04:	mov    QWORD PTR [r12+0x378],0x3
    756c3e106f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e106f16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e106f1c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e106f22:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e106f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e106f2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e106f38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e106f42:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e106f4c:	push   rdx
    756c3e106f4d:	push   rsi
    756c3e106f4e:	push   r10
    756c3e106f50:	push   r11
    756c3e106f52:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e106f57:	mov    r10d,edx
    756c3e106f5a:	and    r10d,0xc000
    756c3e106f61:	shl    r10d,0x10
    756c3e106f65:	mov    r11d,edx
    756c3e106f68:	and    r11d,0x100
    756c3e106f6f:	shl    r11d,0x15
    756c3e106f73:	or     r10d,r11d
    756c3e106f76:	and    edx,0x1
    756c3e106f79:	shl    edx,0x1c
    756c3e106f7c:	or     r10d,edx
    756c3e106f7f:	btc    r10,0x1d
    756c3e106f84:	mov    r11d,0xf0000000
    756c3e106f8a:	and    r11,r10
    756c3e106f8d:	movabs rsi,0xffffffff0fffffff
    756c3e106f97:	and    rbx,rsi
    756c3e106f9a:	or     rbx,r11
    756c3e106f9d:	pop    r11
    756c3e106f9f:	pop    r10
    756c3e106fa1:	pop    rsi
    756c3e106fa2:	pop    rdx
    756c3e106fa3:	mov    QWORD PTR [r12+0x108],rbx
    756c3e106fab:	stmxcsr DWORD PTR [r12-0x28]
    756c3e106fb1:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e106fb6:	test   r10d,0x3f
    756c3e106fbd:	je     0x756c3e106fe2
    756c3e106fc3:	mov    r11d,r10d
    756c3e106fc6:	shr    r10d,1
    756c3e106fc9:	and    r10d,0x1e
    756c3e106fcd:	and    r11d,0x1
    756c3e106fd1:	or     r10d,r11d
    756c3e106fd4:	or     DWORD PTR [r12+0x314],r10d
    756c3e106fdc:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e106fe2:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e106fe8:	lea    rdi,[rsp+0x110]
    756c3e106ff0:	lea    rsi,[rsp+0xf0]
    756c3e106ff8:	lea    rdx,[rsp+0x100]
    756c3e107000:	mov    ecx,0x56
    756c3e107005:	mov    r8d,0x0
    756c3e10700b:	lea    r9,[r12+0x314]
    756c3e107013:	movabs r11,0x60a546cfd650
    756c3e10701d:	call   r11
    756c3e107020:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e107026:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e10702c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e107032:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e107038:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e10703e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e107044:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e10704e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e107058:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e107062:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10706a:	mov    QWORD PTR [r12+0x378],0x2
    756c3e107076:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e10707f:	mov    rdx,rbx
    756c3e107082:	shr    rdx,0x10
    756c3e107086:	and    edx,0xc000
    756c3e10708c:	mov    rax,rbx
    756c3e10708f:	shr    rax,0x15
    756c3e107093:	and    eax,0x100
    756c3e107098:	xor    eax,0x100
    756c3e10709d:	or     edx,eax
    756c3e10709f:	mov    rax,rbx
    756c3e1070a2:	shr    rax,0x1c
    756c3e1070a6:	and    eax,0x1
    756c3e1070a9:	or     edx,eax
    756c3e1070ab:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1070b0:	add    rsp,0x8
    756c3e1070b4:	ret
    756c3e1070b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e1070c0:	sub    rsp,0x8
    756c3e1070c4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1070d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1070d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1070dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1070e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1070e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1070ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1070f4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1070fe:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e107108:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e107112:	push   rdx
    756c3e107113:	push   rsi
    756c3e107114:	push   r10
    756c3e107116:	push   r11
    756c3e107118:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e10711d:	mov    r10d,edx
    756c3e107120:	and    r10d,0xc000
    756c3e107127:	shl    r10d,0x10
    756c3e10712b:	mov    r11d,edx
    756c3e10712e:	and    r11d,0x100
    756c3e107135:	shl    r11d,0x15
    756c3e107139:	or     r10d,r11d
    756c3e10713c:	and    edx,0x1
    756c3e10713f:	shl    edx,0x1c
    756c3e107142:	or     r10d,edx
    756c3e107145:	btc    r10,0x1d
    756c3e10714a:	mov    r11d,0xf0000000
    756c3e107150:	and    r11,r10
    756c3e107153:	movabs rsi,0xffffffff0fffffff
    756c3e10715d:	and    rbx,rsi
    756c3e107160:	or     rbx,r11
    756c3e107163:	pop    r11
    756c3e107165:	pop    r10
    756c3e107167:	pop    rsi
    756c3e107168:	pop    rdx
    756c3e107169:	mov    QWORD PTR [r12+0x108],rbx
    756c3e107171:	stmxcsr DWORD PTR [r12-0x28]
    756c3e107177:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e10717c:	test   r10d,0x3f
    756c3e107183:	je     0x756c3e1071a8
    756c3e107189:	mov    r11d,r10d
    756c3e10718c:	shr    r10d,1
    756c3e10718f:	and    r10d,0x1e
    756c3e107193:	and    r11d,0x1
    756c3e107197:	or     r10d,r11d
    756c3e10719a:	or     DWORD PTR [r12+0x314],r10d
    756c3e1071a2:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1071a8:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1071ae:	lea    rdi,[rsp+0x110]
    756c3e1071b6:	lea    rsi,[rsp+0xf0]
    756c3e1071be:	lea    rdx,[rsp+0x100]
    756c3e1071c6:	mov    ecx,0x56
    756c3e1071cb:	mov    r8d,0x0
    756c3e1071d1:	lea    r9,[r12+0x314]
    756c3e1071d9:	movabs r11,0x60a546cfd650
    756c3e1071e3:	call   r11
    756c3e1071e6:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1071ec:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1071f2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1071f8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e1071fe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e107204:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e10720a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e107210:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e10721a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e107224:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e10722e:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e107236:	mov    QWORD PTR [r12+0x378],0x2
    756c3e107242:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e10724b:	mov    rdx,rbx
    756c3e10724e:	shr    rdx,0x10
    756c3e107252:	and    edx,0xc000
    756c3e107258:	mov    rax,rbx
    756c3e10725b:	shr    rax,0x15
    756c3e10725f:	and    eax,0x100
    756c3e107264:	xor    eax,0x100
    756c3e107269:	or     edx,eax
    756c3e10726b:	mov    rax,rbx
    756c3e10726e:	shr    rax,0x1c
    756c3e107272:	and    eax,0x1
    756c3e107275:	or     edx,eax
    756c3e107277:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e10727c:	add    rsp,0x8
    756c3e107280:	ret
    756c3e107281:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e107290:	sub    rsp,0x8
    756c3e107294:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1072a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1072a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1072ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1072b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1072b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1072be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e1072c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1072d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e1072dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e1072e6:	push   rdx
    756c3e1072e7:	push   rsi
    756c3e1072e8:	push   r10
    756c3e1072ea:	push   r11
    756c3e1072ec:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e1072f1:	mov    r10d,edx
    756c3e1072f4:	and    r10d,0xc000
    756c3e1072fb:	shl    r10d,0x10
    756c3e1072ff:	mov    r11d,edx
    756c3e107302:	and    r11d,0x100
    756c3e107309:	shl    r11d,0x15
    756c3e10730d:	or     r10d,r11d
    756c3e107310:	and    edx,0x1
    756c3e107313:	shl    edx,0x1c
    756c3e107316:	or     r10d,edx
    756c3e107319:	btc    r10,0x1d
    756c3e10731e:	mov    r11d,0xf0000000
    756c3e107324:	and    r11,r10
    756c3e107327:	movabs rsi,0xffffffff0fffffff
    756c3e107331:	and    rbx,rsi
    756c3e107334:	or     rbx,r11
    756c3e107337:	pop    r11
    756c3e107339:	pop    r10
    756c3e10733b:	pop    rsi
    756c3e10733c:	pop    rdx
    756c3e10733d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e107345:	stmxcsr DWORD PTR [r12-0x28]
    756c3e10734b:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e107350:	test   r10d,0x3f
    756c3e107357:	je     0x756c3e10737c
    756c3e10735d:	mov    r11d,r10d
    756c3e107360:	shr    r10d,1
    756c3e107363:	and    r10d,0x1e
    756c3e107367:	and    r11d,0x1
    756c3e10736b:	or     r10d,r11d
    756c3e10736e:	or     DWORD PTR [r12+0x314],r10d
    756c3e107376:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e10737c:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e107382:	lea    rdi,[rsp+0x110]
    756c3e10738a:	lea    rsi,[rsp+0xf0]
    756c3e107392:	lea    rdx,[rsp+0x100]
    756c3e10739a:	mov    ecx,0x14
    756c3e10739f:	mov    r8d,0x0
    756c3e1073a5:	lea    r9,[r12+0x314]
    756c3e1073ad:	movabs r11,0x60a546cfd650
    756c3e1073b7:	call   r11
    756c3e1073ba:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1073c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1073c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1073cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e1073d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e1073d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e1073de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e1073e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e1073f2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e1073fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e107406:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10740e:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10741a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e107423:	mov    rdx,rbx
    756c3e107426:	shr    rdx,0x10
    756c3e10742a:	and    edx,0xc000
    756c3e107430:	mov    rax,rbx
    756c3e107433:	shr    rax,0x15
    756c3e107437:	and    eax,0x100
    756c3e10743c:	xor    eax,0x100
    756c3e107441:	or     edx,eax
    756c3e107443:	mov    rax,rbx
    756c3e107446:	shr    rax,0x1c
    756c3e10744a:	and    eax,0x1
    756c3e10744d:	or     edx,eax
    756c3e10744f:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e107454:	add    rsp,0x8
    756c3e107458:	ret
    756c3e107459:	nop    DWORD PTR [rax+0x0]
    756c3e107460:	sub    rsp,0x8
    756c3e107464:	mov    QWORD PTR [r12+0x378],0x3
    756c3e107470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e107476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e10747c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e107482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e107488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e10748e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e107498:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e1074a2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e1074ac:	push   rdx
    756c3e1074ad:	push   rsi
    756c3e1074ae:	push   r10
    756c3e1074b0:	push   r11
    756c3e1074b2:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e1074b7:	mov    r10d,edx
    756c3e1074ba:	and    r10d,0xc000
    756c3e1074c1:	shl    r10d,0x10
    756c3e1074c5:	mov    r11d,edx
    756c3e1074c8:	and    r11d,0x100
    756c3e1074cf:	shl    r11d,0x15
    756c3e1074d3:	or     r10d,r11d
    756c3e1074d6:	and    edx,0x1
    756c3e1074d9:	shl    edx,0x1c
    756c3e1074dc:	or     r10d,edx
    756c3e1074df:	btc    r10,0x1d
    756c3e1074e4:	mov    r11d,0xf0000000
    756c3e1074ea:	and    r11,r10
    756c3e1074ed:	movabs rsi,0xffffffff0fffffff
    756c3e1074f7:	and    rbx,rsi
    756c3e1074fa:	or     rbx,r11
    756c3e1074fd:	pop    r11
    756c3e1074ff:	pop    r10
    756c3e107501:	pop    rsi
    756c3e107502:	pop    rdx
    756c3e107503:	mov    QWORD PTR [r12+0x108],rbx
    756c3e10750b:	stmxcsr DWORD PTR [r12-0x28]
    756c3e107511:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e107516:	test   r10d,0x3f
    756c3e10751d:	je     0x756c3e107542
    756c3e107523:	mov    r11d,r10d
    756c3e107526:	shr    r10d,1
    756c3e107529:	and    r10d,0x1e
    756c3e10752d:	and    r11d,0x1
    756c3e107531:	or     r10d,r11d
    756c3e107534:	or     DWORD PTR [r12+0x314],r10d
    756c3e10753c:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e107542:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e107548:	lea    rdi,[rsp+0x110]
    756c3e107550:	lea    rsi,[rsp+0xf0]
    756c3e107558:	lea    rdx,[rsp+0x100]
    756c3e107560:	mov    ecx,0x14
    756c3e107565:	mov    r8d,0x0
    756c3e10756b:	lea    r9,[r12+0x314]
    756c3e107573:	movabs r11,0x60a546cfd650
    756c3e10757d:	call   r11
    756c3e107580:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e107586:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e10758c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e107592:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e107598:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e10759e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e1075a4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e1075ae:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e1075b8:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e1075c2:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e1075ca:	mov    QWORD PTR [r12+0x378],0x2
    756c3e1075d6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e1075df:	mov    rdx,rbx
    756c3e1075e2:	shr    rdx,0x10
    756c3e1075e6:	and    edx,0xc000
    756c3e1075ec:	mov    rax,rbx
    756c3e1075ef:	shr    rax,0x15
    756c3e1075f3:	and    eax,0x100
    756c3e1075f8:	xor    eax,0x100
    756c3e1075fd:	or     edx,eax
    756c3e1075ff:	mov    rax,rbx
    756c3e107602:	shr    rax,0x1c
    756c3e107606:	and    eax,0x1
    756c3e107609:	or     edx,eax
    756c3e10760b:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e107610:	add    rsp,0x8
    756c3e107614:	ret
    756c3e107615:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e107620:	sub    rsp,0x8
    756c3e107624:	mov    QWORD PTR [r12+0x378],0x3
    756c3e107630:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e107636:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e10763c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e107642:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e107648:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e10764e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e107654:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e10765e:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e107668:	push   rdx
    756c3e107669:	push   rsi
    756c3e10766a:	push   r10
    756c3e10766c:	push   r11
    756c3e10766e:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e107673:	mov    r10d,edx
    756c3e107676:	and    r10d,0xc000
    756c3e10767d:	shl    r10d,0x10
    756c3e107681:	mov    r11d,edx
    756c3e107684:	and    r11d,0x100
    756c3e10768b:	shl    r11d,0x15
    756c3e10768f:	or     r10d,r11d
    756c3e107692:	and    edx,0x1
    756c3e107695:	shl    edx,0x1c
    756c3e107698:	or     r10d,edx
    756c3e10769b:	btc    r10,0x1d
    756c3e1076a0:	mov    r11d,0xf0000000
    756c3e1076a6:	and    r11,r10
    756c3e1076a9:	movabs rsi,0xffffffff0fffffff
    756c3e1076b3:	and    rbx,rsi
    756c3e1076b6:	or     rbx,r11
    756c3e1076b9:	pop    r11
    756c3e1076bb:	pop    r10
    756c3e1076bd:	pop    rsi
    756c3e1076be:	pop    rdx
    756c3e1076bf:	mov    QWORD PTR [r12+0x108],rbx
    756c3e1076c7:	stmxcsr DWORD PTR [r12-0x28]
    756c3e1076cd:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e1076d2:	test   r10d,0x3f
    756c3e1076d9:	je     0x756c3e1076fe
    756c3e1076df:	mov    r11d,r10d
    756c3e1076e2:	shr    r10d,1
    756c3e1076e5:	and    r10d,0x1e
    756c3e1076e9:	and    r11d,0x1
    756c3e1076ed:	or     r10d,r11d
    756c3e1076f0:	or     DWORD PTR [r12+0x314],r10d
    756c3e1076f8:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1076fe:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e107704:	lea    rdi,[rsp+0x110]
    756c3e10770c:	lea    rsi,[rsp+0xf0]
    756c3e107714:	lea    rdx,[rsp+0x100]
    756c3e10771c:	mov    ecx,0x56
    756c3e107721:	mov    r8d,0x0
    756c3e107727:	lea    r9,[r12+0x314]
    756c3e10772f:	movabs r11,0x60a546cfd650
    756c3e107739:	call   r11
    756c3e10773c:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e107742:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e107748:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e10774e:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e107754:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e10775a:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e107760:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e107766:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e107770:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e10777a:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e107782:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10778e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e107797:	mov    rdx,rbx
    756c3e10779a:	shr    rdx,0x10
    756c3e10779e:	and    edx,0xc000
    756c3e1077a4:	mov    rax,rbx
    756c3e1077a7:	shr    rax,0x15
    756c3e1077ab:	and    eax,0x100
    756c3e1077b0:	xor    eax,0x100
    756c3e1077b5:	or     edx,eax
    756c3e1077b7:	mov    rax,rbx
    756c3e1077ba:	shr    rax,0x1c
    756c3e1077be:	and    eax,0x1
    756c3e1077c1:	or     edx,eax
    756c3e1077c3:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1077c8:	add    rsp,0x8
    756c3e1077cc:	ret
    756c3e1077cd:	nop    DWORD PTR [rax]
    756c3e1077d0:	sub    rsp,0x8
    756c3e1077d4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1077e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1077e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1077ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1077f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1077f8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1077fe:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e107804:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e10780e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e107818:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e107822:	push   rdx
    756c3e107823:	push   rsi
    756c3e107824:	push   r10
    756c3e107826:	push   r11
    756c3e107828:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e10782d:	mov    r10d,edx
    756c3e107830:	and    r10d,0xc000
    756c3e107837:	shl    r10d,0x10
    756c3e10783b:	mov    r11d,edx
    756c3e10783e:	and    r11d,0x100
    756c3e107845:	shl    r11d,0x15
    756c3e107849:	or     r10d,r11d
    756c3e10784c:	and    edx,0x1
    756c3e10784f:	shl    edx,0x1c
    756c3e107852:	or     r10d,edx
    756c3e107855:	btc    r10,0x1d
    756c3e10785a:	mov    r11d,0xf0000000
    756c3e107860:	and    r11,r10
    756c3e107863:	movabs rsi,0xffffffff0fffffff
    756c3e10786d:	and    rbx,rsi
    756c3e107870:	or     rbx,r11
    756c3e107873:	pop    r11
    756c3e107875:	pop    r10
    756c3e107877:	pop    rsi
    756c3e107878:	pop    rdx
    756c3e107879:	mov    QWORD PTR [r12+0x108],rbx
    756c3e107881:	stmxcsr DWORD PTR [r12-0x28]
    756c3e107887:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e10788c:	test   r10d,0x3f
    756c3e107893:	je     0x756c3e1078b8
    756c3e107899:	mov    r11d,r10d
    756c3e10789c:	shr    r10d,1
    756c3e10789f:	and    r10d,0x1e
    756c3e1078a3:	and    r11d,0x1
    756c3e1078a7:	or     r10d,r11d
    756c3e1078aa:	or     DWORD PTR [r12+0x314],r10d
    756c3e1078b2:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1078b8:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1078be:	lea    rdi,[rsp+0x110]
    756c3e1078c6:	lea    rsi,[rsp+0xf0]
    756c3e1078ce:	lea    rdx,[rsp+0x100]
    756c3e1078d6:	mov    ecx,0x14
    756c3e1078db:	mov    r8d,0x0
    756c3e1078e1:	lea    r9,[r12+0x314]
    756c3e1078e9:	movabs r11,0x60a546cfd650
    756c3e1078f3:	call   r11
    756c3e1078f6:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1078fc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e107902:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e107908:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e10790e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e107914:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e10791a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e107920:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e10792a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e107934:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e10793e:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e107946:	mov    QWORD PTR [r12+0x378],0x2
    756c3e107952:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e10795b:	mov    rdx,rbx
    756c3e10795e:	shr    rdx,0x10
    756c3e107962:	and    edx,0xc000
    756c3e107968:	mov    rax,rbx
    756c3e10796b:	shr    rax,0x15
    756c3e10796f:	and    eax,0x100
    756c3e107974:	xor    eax,0x100
    756c3e107979:	or     edx,eax
    756c3e10797b:	mov    rax,rbx
    756c3e10797e:	shr    rax,0x1c
    756c3e107982:	and    eax,0x1
    756c3e107985:	or     edx,eax
    756c3e107987:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e10798c:	add    rsp,0x8
    756c3e107990:	ret
    756c3e107991:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e1079a0:	sub    rsp,0x8
    756c3e1079a4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1079b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1079b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1079bc:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1079c2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1079c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e1079d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e1079dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1079e6:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e1079f0:	push   rdx
    756c3e1079f1:	push   rsi
    756c3e1079f2:	push   r10
    756c3e1079f4:	push   r11
    756c3e1079f6:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e1079fb:	mov    r10d,edx
    756c3e1079fe:	and    r10d,0xc000
    756c3e107a05:	shl    r10d,0x10
    756c3e107a09:	mov    r11d,edx
    756c3e107a0c:	and    r11d,0x100
    756c3e107a13:	shl    r11d,0x15
    756c3e107a17:	or     r10d,r11d
    756c3e107a1a:	and    edx,0x1
    756c3e107a1d:	shl    edx,0x1c
    756c3e107a20:	or     r10d,edx
    756c3e107a23:	btc    r10,0x1d
    756c3e107a28:	mov    r11d,0xf0000000
    756c3e107a2e:	and    r11,r10
    756c3e107a31:	movabs rsi,0xffffffff0fffffff
    756c3e107a3b:	and    rbx,rsi
    756c3e107a3e:	or     rbx,r11
    756c3e107a41:	pop    r11
    756c3e107a43:	pop    r10
    756c3e107a45:	pop    rsi
    756c3e107a46:	pop    rdx
    756c3e107a47:	mov    QWORD PTR [r12+0x108],rbx
    756c3e107a4f:	stmxcsr DWORD PTR [r12-0x28]
    756c3e107a55:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e107a5a:	test   r10d,0x3f
    756c3e107a61:	je     0x756c3e107a86
    756c3e107a67:	mov    r11d,r10d
    756c3e107a6a:	shr    r10d,1
    756c3e107a6d:	and    r10d,0x1e
    756c3e107a71:	and    r11d,0x1
    756c3e107a75:	or     r10d,r11d
    756c3e107a78:	or     DWORD PTR [r12+0x314],r10d
    756c3e107a80:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e107a86:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e107a8c:	lea    rdi,[rsp+0x110]
    756c3e107a94:	lea    rsi,[rsp+0xf0]
    756c3e107a9c:	lea    rdx,[rsp+0x100]
    756c3e107aa4:	mov    ecx,0x14
    756c3e107aa9:	mov    r8d,0x0
    756c3e107aaf:	lea    r9,[r12+0x314]
    756c3e107ab7:	movabs r11,0x60a546cfd650
    756c3e107ac1:	call   r11
    756c3e107ac4:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e107aca:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e107ad0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e107ad6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e107adc:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e107ae2:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e107aec:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e107af6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e107b00:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e107b0a:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e107b12:	mov    QWORD PTR [r12+0x378],0x2
    756c3e107b1e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e107b27:	mov    rdx,rbx
    756c3e107b2a:	shr    rdx,0x10
    756c3e107b2e:	and    edx,0xc000
    756c3e107b34:	mov    rax,rbx
    756c3e107b37:	shr    rax,0x15
    756c3e107b3b:	and    eax,0x100
    756c3e107b40:	xor    eax,0x100
    756c3e107b45:	or     edx,eax
    756c3e107b47:	mov    rax,rbx
    756c3e107b4a:	shr    rax,0x1c
    756c3e107b4e:	and    eax,0x1
    756c3e107b51:	or     edx,eax
    756c3e107b53:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e107b58:	add    rsp,0x8
    756c3e107b5c:	ret
    756c3e107b5d:	nop    DWORD PTR [rax]
    756c3e107b60:	sub    rsp,0x8
    756c3e107b64:	mov    QWORD PTR [r12+0x378],0x3
    756c3e107b70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e107b76:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e107b7c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e107b82:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e107b88:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e107b8e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e107b98:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e107ba2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e107bac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e107bb6:	push   rdx
    756c3e107bb7:	push   rsi
    756c3e107bb8:	push   r10
    756c3e107bba:	push   r11
    756c3e107bbc:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e107bc1:	mov    r10d,edx
    756c3e107bc4:	and    r10d,0xc000
    756c3e107bcb:	shl    r10d,0x10
    756c3e107bcf:	mov    r11d,edx
    756c3e107bd2:	and    r11d,0x100
    756c3e107bd9:	shl    r11d,0x15
    756c3e107bdd:	or     r10d,r11d
    756c3e107be0:	and    edx,0x1
    756c3e107be3:	shl    edx,0x1c
    756c3e107be6:	or     r10d,edx
    756c3e107be9:	btc    r10,0x1d
    756c3e107bee:	mov    r11d,0xf0000000
    756c3e107bf4:	and    r11,r10
    756c3e107bf7:	movabs rsi,0xffffffff0fffffff
    756c3e107c01:	and    rbx,rsi
    756c3e107c04:	or     rbx,r11
    756c3e107c07:	pop    r11
    756c3e107c09:	pop    r10
    756c3e107c0b:	pop    rsi
    756c3e107c0c:	pop    rdx
    756c3e107c0d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e107c15:	stmxcsr DWORD PTR [r12-0x28]
    756c3e107c1b:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e107c20:	test   r10d,0x3f
    756c3e107c27:	je     0x756c3e107c4c
    756c3e107c2d:	mov    r11d,r10d
    756c3e107c30:	shr    r10d,1
    756c3e107c33:	and    r10d,0x1e
    756c3e107c37:	and    r11d,0x1
    756c3e107c3b:	or     r10d,r11d
    756c3e107c3e:	or     DWORD PTR [r12+0x314],r10d
    756c3e107c46:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e107c4c:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e107c52:	lea    rdi,[rsp+0x110]
    756c3e107c5a:	lea    rsi,[rsp+0xf0]
    756c3e107c62:	lea    rdx,[rsp+0x100]
    756c3e107c6a:	mov    ecx,0x14
    756c3e107c6f:	mov    r8d,0x0
    756c3e107c75:	lea    r9,[r12+0x314]
    756c3e107c7d:	movabs r11,0x60a546cfd650
    756c3e107c87:	call   r11
    756c3e107c8a:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e107c90:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e107c96:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e107c9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e107ca2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e107ca8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e107cae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e107cb8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e107cc2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e107ccc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e107cd6:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e107cde:	mov    QWORD PTR [r12+0x378],0x2
    756c3e107cea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e107cf3:	mov    rdx,rbx
    756c3e107cf6:	shr    rdx,0x10
    756c3e107cfa:	and    edx,0xc000
    756c3e107d00:	mov    rax,rbx
    756c3e107d03:	shr    rax,0x15
    756c3e107d07:	and    eax,0x100
    756c3e107d0c:	xor    eax,0x100
    756c3e107d11:	or     edx,eax
    756c3e107d13:	mov    rax,rbx
    756c3e107d16:	shr    rax,0x1c
    756c3e107d1a:	and    eax,0x1
    756c3e107d1d:	or     edx,eax
    756c3e107d1f:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e107d24:	add    rsp,0x8
    756c3e107d28:	ret
    756c3e107d29:	nop    DWORD PTR [rax+0x0]
    756c3e107d30:	sub    rsp,0x8
    756c3e107d34:	mov    QWORD PTR [r12+0x378],0x3
    756c3e107d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e107d46:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e107d4c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e107d52:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e107d58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e107d5e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e107d68:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e107d72:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e107d7c:	push   rdx
    756c3e107d7d:	push   rsi
    756c3e107d7e:	push   r10
    756c3e107d80:	push   r11
    756c3e107d82:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e107d87:	mov    r10d,edx
    756c3e107d8a:	and    r10d,0xc000
    756c3e107d91:	shl    r10d,0x10
    756c3e107d95:	mov    r11d,edx
    756c3e107d98:	and    r11d,0x100
    756c3e107d9f:	shl    r11d,0x15
    756c3e107da3:	or     r10d,r11d
    756c3e107da6:	and    edx,0x1
    756c3e107da9:	shl    edx,0x1c
    756c3e107dac:	or     r10d,edx
    756c3e107daf:	btc    r10,0x1d
    756c3e107db4:	mov    r11d,0xf0000000
    756c3e107dba:	and    r11,r10
    756c3e107dbd:	movabs rsi,0xffffffff0fffffff
    756c3e107dc7:	and    rbx,rsi
    756c3e107dca:	or     rbx,r11
    756c3e107dcd:	pop    r11
    756c3e107dcf:	pop    r10
    756c3e107dd1:	pop    rsi
    756c3e107dd2:	pop    rdx
    756c3e107dd3:	mov    QWORD PTR [r12+0x108],rbx
    756c3e107ddb:	stmxcsr DWORD PTR [r12-0x28]
    756c3e107de1:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e107de6:	test   r10d,0x3f
    756c3e107ded:	je     0x756c3e107e12
    756c3e107df3:	mov    r11d,r10d
    756c3e107df6:	shr    r10d,1
    756c3e107df9:	and    r10d,0x1e
    756c3e107dfd:	and    r11d,0x1
    756c3e107e01:	or     r10d,r11d
    756c3e107e04:	or     DWORD PTR [r12+0x314],r10d
    756c3e107e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e107e12:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e107e18:	lea    rdi,[rsp+0x110]
    756c3e107e20:	lea    rsi,[rsp+0xf0]
    756c3e107e28:	lea    rdx,[rsp+0x100]
    756c3e107e30:	mov    ecx,0x56
    756c3e107e35:	mov    r8d,0x0
    756c3e107e3b:	lea    r9,[r12+0x314]
    756c3e107e43:	movabs r11,0x60a546cfd650
    756c3e107e4d:	call   r11
    756c3e107e50:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e107e56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e107e5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e107e62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e107e68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e107e6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e107e74:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e107e7e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e107e88:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e107e92:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e107e9a:	mov    QWORD PTR [r12+0x378],0x2
    756c3e107ea6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e107eaf:	mov    rdx,rbx
    756c3e107eb2:	shr    rdx,0x10
    756c3e107eb6:	and    edx,0xc000
    756c3e107ebc:	mov    rax,rbx
    756c3e107ebf:	shr    rax,0x15
    756c3e107ec3:	and    eax,0x100
    756c3e107ec8:	xor    eax,0x100
    756c3e107ecd:	or     edx,eax
    756c3e107ecf:	mov    rax,rbx
    756c3e107ed2:	shr    rax,0x1c
    756c3e107ed6:	and    eax,0x1
    756c3e107ed9:	or     edx,eax
    756c3e107edb:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e107ee0:	add    rsp,0x8
    756c3e107ee4:	ret
    756c3e107ee5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e107ef0:	sub    rsp,0x8
    756c3e107ef4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e107f00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e107f06:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e107f0c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e107f12:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e107f18:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e107f1e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e107f28:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e107f32:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e107f3c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e107f46:	push   rdx
    756c3e107f47:	push   rsi
    756c3e107f48:	push   r10
    756c3e107f4a:	push   r11
    756c3e107f4c:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e107f51:	mov    r10d,edx
    756c3e107f54:	and    r10d,0xc000
    756c3e107f5b:	shl    r10d,0x10
    756c3e107f5f:	mov    r11d,edx
    756c3e107f62:	and    r11d,0x100
    756c3e107f69:	shl    r11d,0x15
    756c3e107f6d:	or     r10d,r11d
    756c3e107f70:	and    edx,0x1
    756c3e107f73:	shl    edx,0x1c
    756c3e107f76:	or     r10d,edx
    756c3e107f79:	btc    r10,0x1d
    756c3e107f7e:	mov    r11d,0xf0000000
    756c3e107f84:	and    r11,r10
    756c3e107f87:	movabs rsi,0xffffffff0fffffff
    756c3e107f91:	and    rbx,rsi
    756c3e107f94:	or     rbx,r11
    756c3e107f97:	pop    r11
    756c3e107f99:	pop    r10
    756c3e107f9b:	pop    rsi
    756c3e107f9c:	pop    rdx
    756c3e107f9d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e107fa5:	stmxcsr DWORD PTR [r12-0x28]
    756c3e107fab:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e107fb0:	test   r10d,0x3f
    756c3e107fb7:	je     0x756c3e107fdc
    756c3e107fbd:	mov    r11d,r10d
    756c3e107fc0:	shr    r10d,1
    756c3e107fc3:	and    r10d,0x1e
    756c3e107fc7:	and    r11d,0x1
    756c3e107fcb:	or     r10d,r11d
    756c3e107fce:	or     DWORD PTR [r12+0x314],r10d
    756c3e107fd6:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e107fdc:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e107fe2:	lea    rdi,[rsp+0x110]
    756c3e107fea:	lea    rsi,[rsp+0xf0]
    756c3e107ff2:	lea    rdx,[rsp+0x100]
    756c3e107ffa:	mov    ecx,0x56
    756c3e107fff:	mov    r8d,0x0
    756c3e108005:	lea    r9,[r12+0x314]
    756c3e10800d:	movabs r11,0x60a546cfd650
    756c3e108017:	call   r11
    756c3e10801a:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e108020:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e108026:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e10802c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e108032:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e108038:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e10803e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e108048:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e108052:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e10805c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e108066:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10806e:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10807a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e108083:	mov    rdx,rbx
    756c3e108086:	shr    rdx,0x10
    756c3e10808a:	and    edx,0xc000
    756c3e108090:	mov    rax,rbx
    756c3e108093:	shr    rax,0x15
    756c3e108097:	and    eax,0x100
    756c3e10809c:	xor    eax,0x100
    756c3e1080a1:	or     edx,eax
    756c3e1080a3:	mov    rax,rbx
    756c3e1080a6:	shr    rax,0x1c
    756c3e1080aa:	and    eax,0x1
    756c3e1080ad:	or     edx,eax
    756c3e1080af:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1080b4:	add    rsp,0x8
    756c3e1080b8:	ret
    756c3e1080b9:	nop    DWORD PTR [rax+0x0]
    756c3e1080c0:	sub    rsp,0x8
    756c3e1080c4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1080d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1080d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1080dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1080e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1080e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1080ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e1080f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e108102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e10810c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e108116:	push   rdx
    756c3e108117:	push   rsi
    756c3e108118:	push   r10
    756c3e10811a:	push   r11
    756c3e10811c:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e108121:	mov    r10d,edx
    756c3e108124:	and    r10d,0xc000
    756c3e10812b:	shl    r10d,0x10
    756c3e10812f:	mov    r11d,edx
    756c3e108132:	and    r11d,0x100
    756c3e108139:	shl    r11d,0x15
    756c3e10813d:	or     r10d,r11d
    756c3e108140:	and    edx,0x1
    756c3e108143:	shl    edx,0x1c
    756c3e108146:	or     r10d,edx
    756c3e108149:	btc    r10,0x1d
    756c3e10814e:	mov    r11d,0xf0000000
    756c3e108154:	and    r11,r10
    756c3e108157:	movabs rsi,0xffffffff0fffffff
    756c3e108161:	and    rbx,rsi
    756c3e108164:	or     rbx,r11
    756c3e108167:	pop    r11
    756c3e108169:	pop    r10
    756c3e10816b:	pop    rsi
    756c3e10816c:	pop    rdx
    756c3e10816d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e108175:	stmxcsr DWORD PTR [r12-0x28]
    756c3e10817b:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e108180:	test   r10d,0x3f
    756c3e108187:	je     0x756c3e1081ac
    756c3e10818d:	mov    r11d,r10d
    756c3e108190:	shr    r10d,1
    756c3e108193:	and    r10d,0x1e
    756c3e108197:	and    r11d,0x1
    756c3e10819b:	or     r10d,r11d
    756c3e10819e:	or     DWORD PTR [r12+0x314],r10d
    756c3e1081a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1081ac:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1081b2:	lea    rdi,[rsp+0x110]
    756c3e1081ba:	lea    rsi,[rsp+0xf0]
    756c3e1081c2:	lea    rdx,[rsp+0x100]
    756c3e1081ca:	mov    ecx,0x14
    756c3e1081cf:	mov    r8d,0x0
    756c3e1081d5:	lea    r9,[r12+0x314]
    756c3e1081dd:	movabs r11,0x60a546cfd650
    756c3e1081e7:	call   r11
    756c3e1081ea:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1081f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1081f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1081fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e108202:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e108208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e10820e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e108218:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e108222:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e10822c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e108236:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10823e:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10824a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e108253:	mov    rdx,rbx
    756c3e108256:	shr    rdx,0x10
    756c3e10825a:	and    edx,0xc000
    756c3e108260:	mov    rax,rbx
    756c3e108263:	shr    rax,0x15
    756c3e108267:	and    eax,0x100
    756c3e10826c:	xor    eax,0x100
    756c3e108271:	or     edx,eax
    756c3e108273:	mov    rax,rbx
    756c3e108276:	shr    rax,0x1c
    756c3e10827a:	and    eax,0x1
    756c3e10827d:	or     edx,eax
    756c3e10827f:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e108284:	add    rsp,0x8
    756c3e108288:	ret
    756c3e108289:	nop    DWORD PTR [rax+0x0]
    756c3e108290:	sub    rsp,0x8
    756c3e108294:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1082a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1082a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1082ac:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1082b2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1082b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1082be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e1082c8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e1082d2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1082dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e1082e6:	push   rdx
    756c3e1082e7:	push   rsi
    756c3e1082e8:	push   r10
    756c3e1082ea:	push   r11
    756c3e1082ec:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e1082f1:	mov    r10d,edx
    756c3e1082f4:	and    r10d,0xc000
    756c3e1082fb:	shl    r10d,0x10
    756c3e1082ff:	mov    r11d,edx
    756c3e108302:	and    r11d,0x100
    756c3e108309:	shl    r11d,0x15
    756c3e10830d:	or     r10d,r11d
    756c3e108310:	and    edx,0x1
    756c3e108313:	shl    edx,0x1c
    756c3e108316:	or     r10d,edx
    756c3e108319:	btc    r10,0x1d
    756c3e10831e:	mov    r11d,0xf0000000
    756c3e108324:	and    r11,r10
    756c3e108327:	movabs rsi,0xffffffff0fffffff
    756c3e108331:	and    rbx,rsi
    756c3e108334:	or     rbx,r11
    756c3e108337:	pop    r11
    756c3e108339:	pop    r10
    756c3e10833b:	pop    rsi
    756c3e10833c:	pop    rdx
    756c3e10833d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e108345:	stmxcsr DWORD PTR [r12-0x28]
    756c3e10834b:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e108350:	test   r10d,0x3f
    756c3e108357:	je     0x756c3e10837c
    756c3e10835d:	mov    r11d,r10d
    756c3e108360:	shr    r10d,1
    756c3e108363:	and    r10d,0x1e
    756c3e108367:	and    r11d,0x1
    756c3e10836b:	or     r10d,r11d
    756c3e10836e:	or     DWORD PTR [r12+0x314],r10d
    756c3e108376:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e10837c:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e108382:	lea    rdi,[rsp+0x110]
    756c3e10838a:	lea    rsi,[rsp+0xf0]
    756c3e108392:	lea    rdx,[rsp+0x100]
    756c3e10839a:	mov    ecx,0x56
    756c3e10839f:	mov    r8d,0x0
    756c3e1083a5:	lea    r9,[r12+0x314]
    756c3e1083ad:	movabs r11,0x60a546cfd650
    756c3e1083b7:	call   r11
    756c3e1083ba:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1083c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1083c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1083cc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e1083d2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e1083d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e1083de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e1083e8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e1083f2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e1083fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e108406:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10840e:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10841a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e108423:	mov    rdx,rbx
    756c3e108426:	shr    rdx,0x10
    756c3e10842a:	and    edx,0xc000
    756c3e108430:	mov    rax,rbx
    756c3e108433:	shr    rax,0x15
    756c3e108437:	and    eax,0x100
    756c3e10843c:	xor    eax,0x100
    756c3e108441:	or     edx,eax
    756c3e108443:	mov    rax,rbx
    756c3e108446:	shr    rax,0x1c
    756c3e10844a:	and    eax,0x1
    756c3e10844d:	or     edx,eax
    756c3e10844f:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e108454:	add    rsp,0x8
    756c3e108458:	ret
    756c3e108459:	nop    DWORD PTR [rax+0x0]
    756c3e108460:	sub    rsp,0x8
    756c3e108464:	mov    QWORD PTR [r12+0x378],0x3
    756c3e108470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e108476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e10847c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e108482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e108488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e10848e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e108498:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e1084a2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1084ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e1084b6:	push   rdx
    756c3e1084b7:	push   rsi
    756c3e1084b8:	push   r10
    756c3e1084ba:	push   r11
    756c3e1084bc:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e1084c1:	mov    r10d,edx
    756c3e1084c4:	and    r10d,0xc000
    756c3e1084cb:	shl    r10d,0x10
    756c3e1084cf:	mov    r11d,edx
    756c3e1084d2:	and    r11d,0x100
    756c3e1084d9:	shl    r11d,0x15
    756c3e1084dd:	or     r10d,r11d
    756c3e1084e0:	and    edx,0x1
    756c3e1084e3:	shl    edx,0x1c
    756c3e1084e6:	or     r10d,edx
    756c3e1084e9:	btc    r10,0x1d
    756c3e1084ee:	mov    r11d,0xf0000000
    756c3e1084f4:	and    r11,r10
    756c3e1084f7:	movabs rsi,0xffffffff0fffffff
    756c3e108501:	and    rbx,rsi
    756c3e108504:	or     rbx,r11
    756c3e108507:	pop    r11
    756c3e108509:	pop    r10
    756c3e10850b:	pop    rsi
    756c3e10850c:	pop    rdx
    756c3e10850d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e108515:	stmxcsr DWORD PTR [r12-0x28]
    756c3e10851b:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e108520:	test   r10d,0x3f
    756c3e108527:	je     0x756c3e10854c
    756c3e10852d:	mov    r11d,r10d
    756c3e108530:	shr    r10d,1
    756c3e108533:	and    r10d,0x1e
    756c3e108537:	and    r11d,0x1
    756c3e10853b:	or     r10d,r11d
    756c3e10853e:	or     DWORD PTR [r12+0x314],r10d
    756c3e108546:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e10854c:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e108552:	lea    rdi,[rsp+0x110]
    756c3e10855a:	lea    rsi,[rsp+0xf0]
    756c3e108562:	lea    rdx,[rsp+0x100]
    756c3e10856a:	mov    ecx,0x14
    756c3e10856f:	mov    r8d,0x0
    756c3e108575:	lea    r9,[r12+0x314]
    756c3e10857d:	movabs r11,0x60a546cfd650
    756c3e108587:	call   r11
    756c3e10858a:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e108590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e108596:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e10859c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e1085a2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e1085a8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e1085ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e1085b8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e1085c2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e1085cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e1085d6:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e1085de:	mov    QWORD PTR [r12+0x378],0x2
    756c3e1085ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e1085f3:	mov    rdx,rbx
    756c3e1085f6:	shr    rdx,0x10
    756c3e1085fa:	and    edx,0xc000
    756c3e108600:	mov    rax,rbx
    756c3e108603:	shr    rax,0x15
    756c3e108607:	and    eax,0x100
    756c3e10860c:	xor    eax,0x100
    756c3e108611:	or     edx,eax
    756c3e108613:	mov    rax,rbx
    756c3e108616:	shr    rax,0x1c
    756c3e10861a:	and    eax,0x1
    756c3e10861d:	or     edx,eax
    756c3e10861f:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e108624:	add    rsp,0x8
    756c3e108628:	ret
    756c3e108629:	nop    DWORD PTR [rax+0x0]
    756c3e108630:	sub    rsp,0x8
    756c3e108634:	mov    QWORD PTR [r12+0x378],0x3
    756c3e108640:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e108646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e10864c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e108652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e108658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e10865e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e108668:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e108672:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e10867c:	push   rdx
    756c3e10867d:	push   rsi
    756c3e10867e:	push   r10
    756c3e108680:	push   r11
    756c3e108682:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e108687:	mov    r10d,edx
    756c3e10868a:	and    r10d,0xc000
    756c3e108691:	shl    r10d,0x10
    756c3e108695:	mov    r11d,edx
    756c3e108698:	and    r11d,0x100
    756c3e10869f:	shl    r11d,0x15
    756c3e1086a3:	or     r10d,r11d
    756c3e1086a6:	and    edx,0x1
    756c3e1086a9:	shl    edx,0x1c
    756c3e1086ac:	or     r10d,edx
    756c3e1086af:	btc    r10,0x1d
    756c3e1086b4:	mov    r11d,0xf0000000
    756c3e1086ba:	and    r11,r10
    756c3e1086bd:	movabs rsi,0xffffffff0fffffff
    756c3e1086c7:	and    rbx,rsi
    756c3e1086ca:	or     rbx,r11
    756c3e1086cd:	pop    r11
    756c3e1086cf:	pop    r10
    756c3e1086d1:	pop    rsi
    756c3e1086d2:	pop    rdx
    756c3e1086d3:	mov    QWORD PTR [r12+0x108],rbx
    756c3e1086db:	stmxcsr DWORD PTR [r12-0x28]
    756c3e1086e1:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e1086e6:	test   r10d,0x3f
    756c3e1086ed:	je     0x756c3e108712
    756c3e1086f3:	mov    r11d,r10d
    756c3e1086f6:	shr    r10d,1
    756c3e1086f9:	and    r10d,0x1e
    756c3e1086fd:	and    r11d,0x1
    756c3e108701:	or     r10d,r11d
    756c3e108704:	or     DWORD PTR [r12+0x314],r10d
    756c3e10870c:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e108712:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e108718:	lea    rdi,[rsp+0x110]
    756c3e108720:	lea    rsi,[rsp+0xf0]
    756c3e108728:	lea    rdx,[rsp+0x100]
    756c3e108730:	mov    ecx,0x14
    756c3e108735:	mov    r8d,0x0
    756c3e10873b:	lea    r9,[r12+0x314]
    756c3e108743:	movabs r11,0x60a546cfd650
    756c3e10874d:	call   r11
    756c3e108750:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e108756:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e10875c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e108762:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e108768:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e10876e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e108774:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e10877e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e108788:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e108792:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10879a:	mov    QWORD PTR [r12+0x378],0x2
    756c3e1087a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e1087af:	mov    rdx,rbx
    756c3e1087b2:	shr    rdx,0x10
    756c3e1087b6:	and    edx,0xc000
    756c3e1087bc:	mov    rax,rbx
    756c3e1087bf:	shr    rax,0x15
    756c3e1087c3:	and    eax,0x100
    756c3e1087c8:	xor    eax,0x100
    756c3e1087cd:	or     edx,eax
    756c3e1087cf:	mov    rax,rbx
    756c3e1087d2:	shr    rax,0x1c
    756c3e1087d6:	and    eax,0x1
    756c3e1087d9:	or     edx,eax
    756c3e1087db:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1087e0:	add    rsp,0x8
    756c3e1087e4:	ret
    756c3e1087e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e1087f0:	sub    rsp,0x8
    756c3e1087f4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e108800:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e108806:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e10880c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e108812:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e108818:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e10881e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e108828:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e108832:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e10883c:	push   rdx
    756c3e10883d:	push   rsi
    756c3e10883e:	push   r10
    756c3e108840:	push   r11
    756c3e108842:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e108847:	mov    r10d,edx
    756c3e10884a:	and    r10d,0xc000
    756c3e108851:	shl    r10d,0x10
    756c3e108855:	mov    r11d,edx
    756c3e108858:	and    r11d,0x100
    756c3e10885f:	shl    r11d,0x15
    756c3e108863:	or     r10d,r11d
    756c3e108866:	and    edx,0x1
    756c3e108869:	shl    edx,0x1c
    756c3e10886c:	or     r10d,edx
    756c3e10886f:	btc    r10,0x1d
    756c3e108874:	mov    r11d,0xf0000000
    756c3e10887a:	and    r11,r10
    756c3e10887d:	movabs rsi,0xffffffff0fffffff
    756c3e108887:	and    rbx,rsi
    756c3e10888a:	or     rbx,r11
    756c3e10888d:	pop    r11
    756c3e10888f:	pop    r10
    756c3e108891:	pop    rsi
    756c3e108892:	pop    rdx
    756c3e108893:	mov    QWORD PTR [r12+0x108],rbx
    756c3e10889b:	stmxcsr DWORD PTR [r12-0x28]
    756c3e1088a1:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e1088a6:	test   r10d,0x3f
    756c3e1088ad:	je     0x756c3e1088d2
    756c3e1088b3:	mov    r11d,r10d
    756c3e1088b6:	shr    r10d,1
    756c3e1088b9:	and    r10d,0x1e
    756c3e1088bd:	and    r11d,0x1
    756c3e1088c1:	or     r10d,r11d
    756c3e1088c4:	or     DWORD PTR [r12+0x314],r10d
    756c3e1088cc:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1088d2:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1088d8:	lea    rdi,[rsp+0x110]
    756c3e1088e0:	lea    rsi,[rsp+0xf0]
    756c3e1088e8:	lea    rdx,[rsp+0x100]
    756c3e1088f0:	mov    ecx,0x14
    756c3e1088f5:	mov    r8d,0x0
    756c3e1088fb:	lea    r9,[r12+0x314]
    756c3e108903:	movabs r11,0x60a546cfd650
    756c3e10890d:	call   r11
    756c3e108910:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e108916:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e10891c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e108922:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e108928:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e10892e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e108934:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e10893e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e108948:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e108952:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10895a:	mov    QWORD PTR [r12+0x378],0x2
    756c3e108966:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e10896f:	mov    rdx,rbx
    756c3e108972:	shr    rdx,0x10
    756c3e108976:	and    edx,0xc000
    756c3e10897c:	mov    rax,rbx
    756c3e10897f:	shr    rax,0x15
    756c3e108983:	and    eax,0x100
    756c3e108988:	xor    eax,0x100
    756c3e10898d:	or     edx,eax
    756c3e10898f:	mov    rax,rbx
    756c3e108992:	shr    rax,0x1c
    756c3e108996:	and    eax,0x1
    756c3e108999:	or     edx,eax
    756c3e10899b:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1089a0:	add    rsp,0x8
    756c3e1089a4:	ret
    756c3e1089a5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e1089b0:	sub    rsp,0x8
    756c3e1089b4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1089c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1089c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1089cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1089d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1089d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1089de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1089e4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1089ee:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e1089f8:	push   rdx
    756c3e1089f9:	push   rsi
    756c3e1089fa:	push   r10
    756c3e1089fc:	push   r11
    756c3e1089fe:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e108a03:	mov    r10d,edx
    756c3e108a06:	and    r10d,0xc000
    756c3e108a0d:	shl    r10d,0x10
    756c3e108a11:	mov    r11d,edx
    756c3e108a14:	and    r11d,0x100
    756c3e108a1b:	shl    r11d,0x15
    756c3e108a1f:	or     r10d,r11d
    756c3e108a22:	and    edx,0x1
    756c3e108a25:	shl    edx,0x1c
    756c3e108a28:	or     r10d,edx
    756c3e108a2b:	btc    r10,0x1d
    756c3e108a30:	mov    r11d,0xf0000000
    756c3e108a36:	and    r11,r10
    756c3e108a39:	movabs rsi,0xffffffff0fffffff
    756c3e108a43:	and    rbx,rsi
    756c3e108a46:	or     rbx,r11
    756c3e108a49:	pop    r11
    756c3e108a4b:	pop    r10
    756c3e108a4d:	pop    rsi
    756c3e108a4e:	pop    rdx
    756c3e108a4f:	mov    QWORD PTR [r12+0x108],rbx
    756c3e108a57:	stmxcsr DWORD PTR [r12-0x28]
    756c3e108a5d:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e108a62:	test   r10d,0x3f
    756c3e108a69:	je     0x756c3e108a8e
    756c3e108a6f:	mov    r11d,r10d
    756c3e108a72:	shr    r10d,1
    756c3e108a75:	and    r10d,0x1e
    756c3e108a79:	and    r11d,0x1
    756c3e108a7d:	or     r10d,r11d
    756c3e108a80:	or     DWORD PTR [r12+0x314],r10d
    756c3e108a88:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e108a8e:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e108a94:	lea    rdi,[rsp+0x110]
    756c3e108a9c:	lea    rsi,[rsp+0xf0]
    756c3e108aa4:	lea    rdx,[rsp+0x100]
    756c3e108aac:	mov    ecx,0x56
    756c3e108ab1:	mov    r8d,0x0
    756c3e108ab7:	lea    r9,[r12+0x314]
    756c3e108abf:	movabs r11,0x60a546cfd650
    756c3e108ac9:	call   r11
    756c3e108acc:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e108ad2:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e108ad8:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e108ade:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e108ae4:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e108aea:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e108af0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e108af6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e108b00:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e108b0a:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e108b12:	mov    QWORD PTR [r12+0x378],0x2
    756c3e108b1e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e108b27:	mov    rdx,rbx
    756c3e108b2a:	shr    rdx,0x10
    756c3e108b2e:	and    edx,0xc000
    756c3e108b34:	mov    rax,rbx
    756c3e108b37:	shr    rax,0x15
    756c3e108b3b:	and    eax,0x100
    756c3e108b40:	xor    eax,0x100
    756c3e108b45:	or     edx,eax
    756c3e108b47:	mov    rax,rbx
    756c3e108b4a:	shr    rax,0x1c
    756c3e108b4e:	and    eax,0x1
    756c3e108b51:	or     edx,eax
    756c3e108b53:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e108b58:	add    rsp,0x8
    756c3e108b5c:	ret
    756c3e108b5d:	nop    DWORD PTR [rax]
    756c3e108b60:	sub    rsp,0x8
    756c3e108b64:	mov    QWORD PTR [r12+0x378],0x3
    756c3e108b70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e108b76:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e108b7c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e108b82:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e108b88:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e108b8e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e108b98:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e108ba2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e108bac:	push   rdx
    756c3e108bad:	push   rsi
    756c3e108bae:	push   r10
    756c3e108bb0:	push   r11
    756c3e108bb2:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e108bb7:	mov    r10d,edx
    756c3e108bba:	and    r10d,0xc000
    756c3e108bc1:	shl    r10d,0x10
    756c3e108bc5:	mov    r11d,edx
    756c3e108bc8:	and    r11d,0x100
    756c3e108bcf:	shl    r11d,0x15
    756c3e108bd3:	or     r10d,r11d
    756c3e108bd6:	and    edx,0x1
    756c3e108bd9:	shl    edx,0x1c
    756c3e108bdc:	or     r10d,edx
    756c3e108bdf:	btc    r10,0x1d
    756c3e108be4:	mov    r11d,0xf0000000
    756c3e108bea:	and    r11,r10
    756c3e108bed:	movabs rsi,0xffffffff0fffffff
    756c3e108bf7:	and    rbx,rsi
    756c3e108bfa:	or     rbx,r11
    756c3e108bfd:	pop    r11
    756c3e108bff:	pop    r10
    756c3e108c01:	pop    rsi
    756c3e108c02:	pop    rdx
    756c3e108c03:	mov    QWORD PTR [r12+0x108],rbx
    756c3e108c0b:	stmxcsr DWORD PTR [r12-0x28]
    756c3e108c11:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e108c16:	test   r10d,0x3f
    756c3e108c1d:	je     0x756c3e108c42
    756c3e108c23:	mov    r11d,r10d
    756c3e108c26:	shr    r10d,1
    756c3e108c29:	and    r10d,0x1e
    756c3e108c2d:	and    r11d,0x1
    756c3e108c31:	or     r10d,r11d
    756c3e108c34:	or     DWORD PTR [r12+0x314],r10d
    756c3e108c3c:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e108c42:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e108c48:	lea    rdi,[rsp+0x110]
    756c3e108c50:	lea    rsi,[rsp+0xf0]
    756c3e108c58:	lea    rdx,[rsp+0x100]
    756c3e108c60:	mov    ecx,0x56
    756c3e108c65:	mov    r8d,0x0
    756c3e108c6b:	lea    r9,[r12+0x314]
    756c3e108c73:	movabs r11,0x60a546cfd650
    756c3e108c7d:	call   r11
    756c3e108c80:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e108c86:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e108c8c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e108c92:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e108c98:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e108c9e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e108ca4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e108cae:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e108cb8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e108cc2:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e108cca:	mov    QWORD PTR [r12+0x378],0x2
    756c3e108cd6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e108cdf:	mov    rdx,rbx
    756c3e108ce2:	shr    rdx,0x10
    756c3e108ce6:	and    edx,0xc000
    756c3e108cec:	mov    rax,rbx
    756c3e108cef:	shr    rax,0x15
    756c3e108cf3:	and    eax,0x100
    756c3e108cf8:	xor    eax,0x100
    756c3e108cfd:	or     edx,eax
    756c3e108cff:	mov    rax,rbx
    756c3e108d02:	shr    rax,0x1c
    756c3e108d06:	and    eax,0x1
    756c3e108d09:	or     edx,eax
    756c3e108d0b:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e108d10:	add    rsp,0x8
    756c3e108d14:	ret
    756c3e108d15:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e108d20:	sub    rsp,0x8
    756c3e108d24:	mov    QWORD PTR [r12+0x378],0x3
    756c3e108d30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e108d36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e108d3c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e108d42:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e108d48:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e108d4e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e108d54:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e108d5e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e108d68:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    756c3e108d72:	push   rdx
    756c3e108d73:	push   rsi
    756c3e108d74:	push   r10
    756c3e108d76:	push   r11
    756c3e108d78:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e108d7d:	mov    r10d,edx
    756c3e108d80:	and    r10d,0xc000
    756c3e108d87:	shl    r10d,0x10
    756c3e108d8b:	mov    r11d,edx
    756c3e108d8e:	and    r11d,0x100
    756c3e108d95:	shl    r11d,0x15
    756c3e108d99:	or     r10d,r11d
    756c3e108d9c:	and    edx,0x1
    756c3e108d9f:	shl    edx,0x1c
    756c3e108da2:	or     r10d,edx
    756c3e108da5:	btc    r10,0x1d
    756c3e108daa:	mov    r11d,0xf0000000
    756c3e108db0:	and    r11,r10
    756c3e108db3:	movabs rsi,0xffffffff0fffffff
    756c3e108dbd:	and    rbx,rsi
    756c3e108dc0:	or     rbx,r11
    756c3e108dc3:	pop    r11
    756c3e108dc5:	pop    r10
    756c3e108dc7:	pop    rsi
    756c3e108dc8:	pop    rdx
    756c3e108dc9:	mov    QWORD PTR [r12+0x108],rbx
    756c3e108dd1:	stmxcsr DWORD PTR [r12-0x28]
    756c3e108dd7:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e108ddc:	test   r10d,0x3f
    756c3e108de3:	je     0x756c3e108e08
    756c3e108de9:	mov    r11d,r10d
    756c3e108dec:	shr    r10d,1
    756c3e108def:	and    r10d,0x1e
    756c3e108df3:	and    r11d,0x1
    756c3e108df7:	or     r10d,r11d
    756c3e108dfa:	or     DWORD PTR [r12+0x314],r10d
    756c3e108e02:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e108e08:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e108e0e:	lea    rdi,[rsp+0x110]
    756c3e108e16:	lea    rsi,[rsp+0xf0]
    756c3e108e1e:	lea    rdx,[rsp+0x100]
    756c3e108e26:	mov    ecx,0x14
    756c3e108e2b:	mov    r8d,0x0
    756c3e108e31:	lea    r9,[r12+0x314]
    756c3e108e39:	movabs r11,0x60a546cfd650
    756c3e108e43:	call   r11
    756c3e108e46:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e108e4c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e108e52:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e108e58:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e108e5e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e108e64:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e108e6a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e108e70:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e108e7a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e108e84:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    756c3e108e8e:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e108e96:	mov    QWORD PTR [r12+0x378],0x2
    756c3e108ea2:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e108eab:	mov    rdx,rbx
    756c3e108eae:	shr    rdx,0x10
    756c3e108eb2:	and    edx,0xc000
    756c3e108eb8:	mov    rax,rbx
    756c3e108ebb:	shr    rax,0x15
    756c3e108ebf:	and    eax,0x100
    756c3e108ec4:	xor    eax,0x100
    756c3e108ec9:	or     edx,eax
    756c3e108ecb:	mov    rax,rbx
    756c3e108ece:	shr    rax,0x1c
    756c3e108ed2:	and    eax,0x1
    756c3e108ed5:	or     edx,eax
    756c3e108ed7:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e108edc:	add    rsp,0x8
    756c3e108ee0:	ret
    756c3e108ee1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e108ef0:	sub    rsp,0x8
    756c3e108ef4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e108f00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e108f06:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e108f0c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e108f12:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e108f18:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e108f1e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e108f28:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e108f32:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e108f3c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e108f46:	push   rdx
    756c3e108f47:	push   rsi
    756c3e108f48:	push   r10
    756c3e108f4a:	push   r11
    756c3e108f4c:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e108f51:	mov    r10d,edx
    756c3e108f54:	and    r10d,0xc000
    756c3e108f5b:	shl    r10d,0x10
    756c3e108f5f:	mov    r11d,edx
    756c3e108f62:	and    r11d,0x100
    756c3e108f69:	shl    r11d,0x15
    756c3e108f6d:	or     r10d,r11d
    756c3e108f70:	and    edx,0x1
    756c3e108f73:	shl    edx,0x1c
    756c3e108f76:	or     r10d,edx
    756c3e108f79:	btc    r10,0x1d
    756c3e108f7e:	mov    r11d,0xf0000000
    756c3e108f84:	and    r11,r10
    756c3e108f87:	movabs rsi,0xffffffff0fffffff
    756c3e108f91:	and    rbx,rsi
    756c3e108f94:	or     rbx,r11
    756c3e108f97:	pop    r11
    756c3e108f99:	pop    r10
    756c3e108f9b:	pop    rsi
    756c3e108f9c:	pop    rdx
    756c3e108f9d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e108fa5:	stmxcsr DWORD PTR [r12-0x28]
    756c3e108fab:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e108fb0:	test   r10d,0x3f
    756c3e108fb7:	je     0x756c3e108fdc
    756c3e108fbd:	mov    r11d,r10d
    756c3e108fc0:	shr    r10d,1
    756c3e108fc3:	and    r10d,0x1e
    756c3e108fc7:	and    r11d,0x1
    756c3e108fcb:	or     r10d,r11d
    756c3e108fce:	or     DWORD PTR [r12+0x314],r10d
    756c3e108fd6:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e108fdc:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e108fe2:	lea    rdi,[rsp+0x110]
    756c3e108fea:	lea    rsi,[rsp+0xf0]
    756c3e108ff2:	lea    rdx,[rsp+0x100]
    756c3e108ffa:	mov    ecx,0x56
    756c3e108fff:	mov    r8d,0x0
    756c3e109005:	lea    r9,[r12+0x314]
    756c3e10900d:	movabs r11,0x60a546cfd650
    756c3e109017:	call   r11
    756c3e10901a:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e109020:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e109026:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e10902c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e109032:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e109038:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e10903e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e109048:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e109052:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e10905c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e109066:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10906e:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10907a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e109083:	mov    rdx,rbx
    756c3e109086:	shr    rdx,0x10
    756c3e10908a:	and    edx,0xc000
    756c3e109090:	mov    rax,rbx
    756c3e109093:	shr    rax,0x15
    756c3e109097:	and    eax,0x100
    756c3e10909c:	xor    eax,0x100
    756c3e1090a1:	or     edx,eax
    756c3e1090a3:	mov    rax,rbx
    756c3e1090a6:	shr    rax,0x1c
    756c3e1090aa:	and    eax,0x1
    756c3e1090ad:	or     edx,eax
    756c3e1090af:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1090b4:	add    rsp,0x8
    756c3e1090b8:	ret
    756c3e1090b9:	nop    DWORD PTR [rax+0x0]
    756c3e1090c0:	sub    rsp,0x8
    756c3e1090c4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1090d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1090d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1090dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1090e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e1090e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1090ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1090f4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    756c3e1090fe:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e109108:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e109112:	push   rdx
    756c3e109113:	push   rsi
    756c3e109114:	push   r10
    756c3e109116:	push   r11
    756c3e109118:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e10911d:	mov    r10d,edx
    756c3e109120:	and    r10d,0xc000
    756c3e109127:	shl    r10d,0x10
    756c3e10912b:	mov    r11d,edx
    756c3e10912e:	and    r11d,0x100
    756c3e109135:	shl    r11d,0x15
    756c3e109139:	or     r10d,r11d
    756c3e10913c:	and    edx,0x1
    756c3e10913f:	shl    edx,0x1c
    756c3e109142:	or     r10d,edx
    756c3e109145:	btc    r10,0x1d
    756c3e10914a:	mov    r11d,0xf0000000
    756c3e109150:	and    r11,r10
    756c3e109153:	movabs rsi,0xffffffff0fffffff
    756c3e10915d:	and    rbx,rsi
    756c3e109160:	or     rbx,r11
    756c3e109163:	pop    r11
    756c3e109165:	pop    r10
    756c3e109167:	pop    rsi
    756c3e109168:	pop    rdx
    756c3e109169:	mov    QWORD PTR [r12+0x108],rbx
    756c3e109171:	stmxcsr DWORD PTR [r12-0x28]
    756c3e109177:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e10917c:	test   r10d,0x3f
    756c3e109183:	je     0x756c3e1091a8
    756c3e109189:	mov    r11d,r10d
    756c3e10918c:	shr    r10d,1
    756c3e10918f:	and    r10d,0x1e
    756c3e109193:	and    r11d,0x1
    756c3e109197:	or     r10d,r11d
    756c3e10919a:	or     DWORD PTR [r12+0x314],r10d
    756c3e1091a2:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1091a8:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1091ae:	lea    rdi,[rsp+0x110]
    756c3e1091b6:	lea    rsi,[rsp+0xf0]
    756c3e1091be:	lea    rdx,[rsp+0x100]
    756c3e1091c6:	mov    ecx,0x56
    756c3e1091cb:	mov    r8d,0x0
    756c3e1091d1:	lea    r9,[r12+0x314]
    756c3e1091d9:	movabs r11,0x60a546cfd650
    756c3e1091e3:	call   r11
    756c3e1091e6:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1091ec:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1091f2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1091f8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e1091fe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e109204:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e10920a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e109210:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    756c3e10921a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e109224:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e10922e:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e109236:	mov    QWORD PTR [r12+0x378],0x2
    756c3e109242:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e10924b:	mov    rdx,rbx
    756c3e10924e:	shr    rdx,0x10
    756c3e109252:	and    edx,0xc000
    756c3e109258:	mov    rax,rbx
    756c3e10925b:	shr    rax,0x15
    756c3e10925f:	and    eax,0x100
    756c3e109264:	xor    eax,0x100
    756c3e109269:	or     edx,eax
    756c3e10926b:	mov    rax,rbx
    756c3e10926e:	shr    rax,0x1c
    756c3e109272:	and    eax,0x1
    756c3e109275:	or     edx,eax
    756c3e109277:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e10927c:	add    rsp,0x8
    756c3e109280:	ret
    756c3e109281:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e109290:	sub    rsp,0x8
    756c3e109294:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1092a0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e1092a6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1092ac:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    756c3e1092b2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    756c3e1092b8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e1092c2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e1092cc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e1092d6:	push   rdx
    756c3e1092d7:	push   rsi
    756c3e1092d8:	push   r10
    756c3e1092da:	push   r11
    756c3e1092dc:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e1092e1:	mov    r10d,edx
    756c3e1092e4:	and    r10d,0xc000
    756c3e1092eb:	shl    r10d,0x10
    756c3e1092ef:	mov    r11d,edx
    756c3e1092f2:	and    r11d,0x100
    756c3e1092f9:	shl    r11d,0x15
    756c3e1092fd:	or     r10d,r11d
    756c3e109300:	and    edx,0x1
    756c3e109303:	shl    edx,0x1c
    756c3e109306:	or     r10d,edx
    756c3e109309:	btc    r10,0x1d
    756c3e10930e:	mov    r11d,0xf0000000
    756c3e109314:	and    r11,r10
    756c3e109317:	movabs rsi,0xffffffff0fffffff
    756c3e109321:	and    rbx,rsi
    756c3e109324:	or     rbx,r11
    756c3e109327:	pop    r11
    756c3e109329:	pop    r10
    756c3e10932b:	pop    rsi
    756c3e10932c:	pop    rdx
    756c3e10932d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e109335:	stmxcsr DWORD PTR [r12-0x28]
    756c3e10933b:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e109340:	test   r10d,0x3f
    756c3e109347:	je     0x756c3e10936c
    756c3e10934d:	mov    r11d,r10d
    756c3e109350:	shr    r10d,1
    756c3e109353:	and    r10d,0x1e
    756c3e109357:	and    r11d,0x1
    756c3e10935b:	or     r10d,r11d
    756c3e10935e:	or     DWORD PTR [r12+0x314],r10d
    756c3e109366:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e10936c:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e109372:	lea    rdi,[rsp+0x110]
    756c3e10937a:	lea    rsi,[rsp+0xf0]
    756c3e109382:	lea    rdx,[rsp+0x100]
    756c3e10938a:	mov    ecx,0x14
    756c3e10938f:	mov    r8d,0x0
    756c3e109395:	lea    r9,[r12+0x314]
    756c3e10939d:	movabs r11,0x60a546cfd650
    756c3e1093a7:	call   r11
    756c3e1093aa:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1093b0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e1093b6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e1093bc:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    756c3e1093c2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    756c3e1093c8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e1093d2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e1093dc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e1093e6:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e1093ee:	mov    QWORD PTR [r12+0x378],0x2
    756c3e1093fa:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e109403:	mov    rdx,rbx
    756c3e109406:	shr    rdx,0x10
    756c3e10940a:	and    edx,0xc000
    756c3e109410:	mov    rax,rbx
    756c3e109413:	shr    rax,0x15
    756c3e109417:	and    eax,0x100
    756c3e10941c:	xor    eax,0x100
    756c3e109421:	or     edx,eax
    756c3e109423:	mov    rax,rbx
    756c3e109426:	shr    rax,0x1c
    756c3e10942a:	and    eax,0x1
    756c3e10942d:	or     edx,eax
    756c3e10942f:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e109434:	add    rsp,0x8
    756c3e109438:	ret
    756c3e109439:	nop    DWORD PTR [rax+0x0]
    756c3e109440:	sub    rsp,0x8
    756c3e109444:	mov    QWORD PTR [r12+0x378],0x3
    756c3e109450:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e109456:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e10945c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e109462:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    756c3e10946c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e109476:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e109480:	push   rdx
    756c3e109481:	push   rsi
    756c3e109482:	push   r10
    756c3e109484:	push   r11
    756c3e109486:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e10948b:	mov    r10d,edx
    756c3e10948e:	and    r10d,0xc000
    756c3e109495:	shl    r10d,0x10
    756c3e109499:	mov    r11d,edx
    756c3e10949c:	and    r11d,0x100
    756c3e1094a3:	shl    r11d,0x15
    756c3e1094a7:	or     r10d,r11d
    756c3e1094aa:	and    edx,0x1
    756c3e1094ad:	shl    edx,0x1c
    756c3e1094b0:	or     r10d,edx
    756c3e1094b3:	btc    r10,0x1d
    756c3e1094b8:	mov    r11d,0xf0000000
    756c3e1094be:	and    r11,r10
    756c3e1094c1:	movabs rsi,0xffffffff0fffffff
    756c3e1094cb:	and    rbx,rsi
    756c3e1094ce:	or     rbx,r11
    756c3e1094d1:	pop    r11
    756c3e1094d3:	pop    r10
    756c3e1094d5:	pop    rsi
    756c3e1094d6:	pop    rdx
    756c3e1094d7:	mov    QWORD PTR [r12+0x108],rbx
    756c3e1094df:	stmxcsr DWORD PTR [r12-0x28]
    756c3e1094e5:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e1094ea:	test   r10d,0x3f
    756c3e1094f1:	je     0x756c3e109516
    756c3e1094f7:	mov    r11d,r10d
    756c3e1094fa:	shr    r10d,1
    756c3e1094fd:	and    r10d,0x1e
    756c3e109501:	and    r11d,0x1
    756c3e109505:	or     r10d,r11d
    756c3e109508:	or     DWORD PTR [r12+0x314],r10d
    756c3e109510:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e109516:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e10951c:	lea    rdi,[rsp+0x110]
    756c3e109524:	lea    rsi,[rsp+0xf0]
    756c3e10952c:	lea    rdx,[rsp+0x100]
    756c3e109534:	mov    ecx,0x14
    756c3e109539:	mov    r8d,0x0
    756c3e10953f:	lea    r9,[r12+0x314]
    756c3e109547:	movabs r11,0x60a546cfd650
    756c3e109551:	call   r11
    756c3e109554:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e10955a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e109560:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e109566:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e10956c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    756c3e109576:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e109580:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e10958a:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e109592:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10959e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e1095a7:	mov    rdx,rbx
    756c3e1095aa:	shr    rdx,0x10
    756c3e1095ae:	and    edx,0xc000
    756c3e1095b4:	mov    rax,rbx
    756c3e1095b7:	shr    rax,0x15
    756c3e1095bb:	and    eax,0x100
    756c3e1095c0:	xor    eax,0x100
    756c3e1095c5:	or     edx,eax
    756c3e1095c7:	mov    rax,rbx
    756c3e1095ca:	shr    rax,0x1c
    756c3e1095ce:	and    eax,0x1
    756c3e1095d1:	or     edx,eax
    756c3e1095d3:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1095d8:	add    rsp,0x8
    756c3e1095dc:	ret
    756c3e1095dd:	nop    DWORD PTR [rax]
    756c3e1095e0:	sub    rsp,0x8
    756c3e1095e4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1095f0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1095f6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1095fc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    756c3e109602:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    756c3e10960c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    756c3e109616:	push   rdx
    756c3e109617:	push   rsi
    756c3e109618:	push   r10
    756c3e10961a:	push   r11
    756c3e10961c:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e109621:	mov    r10d,edx
    756c3e109624:	and    r10d,0xc000
    756c3e10962b:	shl    r10d,0x10
    756c3e10962f:	mov    r11d,edx
    756c3e109632:	and    r11d,0x100
    756c3e109639:	shl    r11d,0x15
    756c3e10963d:	or     r10d,r11d
    756c3e109640:	and    edx,0x1
    756c3e109643:	shl    edx,0x1c
    756c3e109646:	or     r10d,edx
    756c3e109649:	btc    r10,0x1d
    756c3e10964e:	mov    r11d,0xf0000000
    756c3e109654:	and    r11,r10
    756c3e109657:	movabs rsi,0xffffffff0fffffff
    756c3e109661:	and    rbx,rsi
    756c3e109664:	or     rbx,r11
    756c3e109667:	pop    r11
    756c3e109669:	pop    r10
    756c3e10966b:	pop    rsi
    756c3e10966c:	pop    rdx
    756c3e10966d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e109675:	stmxcsr DWORD PTR [r12-0x28]
    756c3e10967b:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e109680:	test   r10d,0x3f
    756c3e109687:	je     0x756c3e1096ac
    756c3e10968d:	mov    r11d,r10d
    756c3e109690:	shr    r10d,1
    756c3e109693:	and    r10d,0x1e
    756c3e109697:	and    r11d,0x1
    756c3e10969b:	or     r10d,r11d
    756c3e10969e:	or     DWORD PTR [r12+0x314],r10d
    756c3e1096a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e1096ac:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e1096b2:	lea    rdi,[rsp+0x110]
    756c3e1096ba:	lea    rsi,[rsp+0xf0]
    756c3e1096c2:	lea    rdx,[rsp+0x100]
    756c3e1096ca:	mov    ecx,0x14
    756c3e1096cf:	mov    r8d,0x0
    756c3e1096d5:	lea    r9,[r12+0x314]
    756c3e1096dd:	movabs r11,0x60a546cfd650
    756c3e1096e7:	call   r11
    756c3e1096ea:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1096f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1096f6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e1096fc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    756c3e109702:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    756c3e10970c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    756c3e109716:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10971e:	mov    QWORD PTR [r12+0x378],0x2
    756c3e10972a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e109733:	mov    rdx,rbx
    756c3e109736:	shr    rdx,0x10
    756c3e10973a:	and    edx,0xc000
    756c3e109740:	mov    rax,rbx
    756c3e109743:	shr    rax,0x15
    756c3e109747:	and    eax,0x100
    756c3e10974c:	xor    eax,0x100
    756c3e109751:	or     edx,eax
    756c3e109753:	mov    rax,rbx
    756c3e109756:	shr    rax,0x1c
    756c3e10975a:	and    eax,0x1
    756c3e10975d:	or     edx,eax
    756c3e10975f:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e109764:	add    rsp,0x8
    756c3e109768:	ret
    756c3e109769:	nop    DWORD PTR [rax+0x0]
    756c3e109770:	sub    rsp,0x8
    756c3e109774:	mov    QWORD PTR [r12+0x378],0x3
    756c3e109780:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e109786:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    756c3e10978c:	push   rdx
    756c3e10978d:	push   rsi
    756c3e10978e:	push   r10
    756c3e109790:	push   r11
    756c3e109792:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e109797:	mov    r10d,edx
    756c3e10979a:	and    r10d,0xc000
    756c3e1097a1:	shl    r10d,0x10
    756c3e1097a5:	mov    r11d,edx
    756c3e1097a8:	and    r11d,0x100
    756c3e1097af:	shl    r11d,0x15
    756c3e1097b3:	or     r10d,r11d
    756c3e1097b6:	and    edx,0x1
    756c3e1097b9:	shl    edx,0x1c
    756c3e1097bc:	or     r10d,edx
    756c3e1097bf:	btc    r10,0x1d
    756c3e1097c4:	mov    r11d,0xf0000000
    756c3e1097ca:	and    r11,r10
    756c3e1097cd:	movabs rsi,0xffffffff0fffffff
    756c3e1097d7:	and    rbx,rsi
    756c3e1097da:	or     rbx,r11
    756c3e1097dd:	pop    r11
    756c3e1097df:	pop    r10
    756c3e1097e1:	pop    rsi
    756c3e1097e2:	pop    rdx
    756c3e1097e3:	mov    QWORD PTR [r12+0x108],rbx
    756c3e1097eb:	stmxcsr DWORD PTR [r12-0x28]
    756c3e1097f1:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e1097f6:	test   r10d,0x3f
    756c3e1097fd:	je     0x756c3e109822
    756c3e109803:	mov    r11d,r10d
    756c3e109806:	shr    r10d,1
    756c3e109809:	and    r10d,0x1e
    756c3e10980d:	and    r11d,0x1
    756c3e109811:	or     r10d,r11d
    756c3e109814:	or     DWORD PTR [r12+0x314],r10d
    756c3e10981c:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e109822:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e109828:	lea    rdi,[rsp+0x110]
    756c3e109830:	lea    rsi,[rsp+0xf0]
    756c3e109838:	lea    rdx,[rsp+0x100]
    756c3e109840:	mov    ecx,0xc
    756c3e109845:	mov    r8d,0x0
    756c3e10984b:	lea    r9,[r12+0x314]
    756c3e109853:	movabs r11,0x60a546cfd650
    756c3e10985d:	call   r11
    756c3e109860:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e109866:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e10986c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    756c3e109872:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e10987a:	mov    QWORD PTR [r12+0x378],0x2
    756c3e109886:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e10988f:	mov    rdx,rbx
    756c3e109892:	shr    rdx,0x10
    756c3e109896:	and    edx,0xc000
    756c3e10989c:	mov    rax,rbx
    756c3e10989f:	shr    rax,0x15
    756c3e1098a3:	and    eax,0x100
    756c3e1098a8:	xor    eax,0x100
    756c3e1098ad:	or     edx,eax
    756c3e1098af:	mov    rax,rbx
    756c3e1098b2:	shr    rax,0x1c
    756c3e1098b6:	and    eax,0x1
    756c3e1098b9:	or     edx,eax
    756c3e1098bb:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e1098c0:	add    rsp,0x8
    756c3e1098c4:	ret
    756c3e1098c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    756c3e1098d0:	sub    rsp,0x8
    756c3e1098d4:	mov    QWORD PTR [r12+0x378],0x3
    756c3e1098e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    756c3e1098e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    756c3e1098ec:	push   rdx
    756c3e1098ed:	push   rsi
    756c3e1098ee:	push   r10
    756c3e1098f0:	push   r11
    756c3e1098f2:	mov    rdx,QWORD PTR [rsp+0x30]
    756c3e1098f7:	mov    r10d,edx
    756c3e1098fa:	and    r10d,0xc000
    756c3e109901:	shl    r10d,0x10
    756c3e109905:	mov    r11d,edx
    756c3e109908:	and    r11d,0x100
    756c3e10990f:	shl    r11d,0x15
    756c3e109913:	or     r10d,r11d
    756c3e109916:	and    edx,0x1
    756c3e109919:	shl    edx,0x1c
    756c3e10991c:	or     r10d,edx
    756c3e10991f:	btc    r10,0x1d
    756c3e109924:	mov    r11d,0xf0000000
    756c3e10992a:	and    r11,r10
    756c3e10992d:	movabs rsi,0xffffffff0fffffff
    756c3e109937:	and    rbx,rsi
    756c3e10993a:	or     rbx,r11
    756c3e10993d:	pop    r11
    756c3e10993f:	pop    r10
    756c3e109941:	pop    rsi
    756c3e109942:	pop    rdx
    756c3e109943:	mov    QWORD PTR [r12+0x108],rbx
    756c3e10994b:	stmxcsr DWORD PTR [r12-0x28]
    756c3e109951:	mov    r10d,DWORD PTR [r12-0x28]
    756c3e109956:	test   r10d,0x3f
    756c3e10995d:	je     0x756c3e109982
    756c3e109963:	mov    r11d,r10d
    756c3e109966:	shr    r10d,1
    756c3e109969:	and    r10d,0x1e
    756c3e10996d:	and    r11d,0x1
    756c3e109971:	or     r10d,r11d
    756c3e109974:	or     DWORD PTR [r12+0x314],r10d
    756c3e10997c:	and    DWORD PTR [r12-0x28],0xffffffc0
    756c3e109982:	ldmxcsr DWORD PTR [r12-0x38]
    756c3e109988:	lea    rdi,[rsp+0x110]
    756c3e109990:	lea    rsi,[rsp+0xf0]
    756c3e109998:	lea    rdx,[rsp+0x100]
    756c3e1099a0:	mov    ecx,0xc
    756c3e1099a5:	mov    r8d,0x0
    756c3e1099ab:	lea    r9,[r12+0x314]
    756c3e1099b3:	movabs r11,0x60a546cfd650
    756c3e1099bd:	call   r11
    756c3e1099c0:	ldmxcsr DWORD PTR [r12-0x28]
    756c3e1099c6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    756c3e1099cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    756c3e1099d2:	mov    rbx,QWORD PTR [r12+0x108]
    756c3e1099da:	mov    QWORD PTR [r12+0x378],0x2
    756c3e1099e6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    756c3e1099ef:	mov    rdx,rbx
    756c3e1099f2:	shr    rdx,0x10
    756c3e1099f6:	and    edx,0xc000
    756c3e1099fc:	mov    rax,rbx
    756c3e1099ff:	shr    rax,0x15
    756c3e109a03:	and    eax,0x100
    756c3e109a08:	xor    eax,0x100
    756c3e109a0d:	or     edx,eax
    756c3e109a0f:	mov    rax,rbx
    756c3e109a12:	shr    rax,0x1c
    756c3e109a16:	and    eax,0x1
    756c3e109a19:	or     edx,eax
    756c3e109a1b:	mov    QWORD PTR [rsp+0x10],rdx
    756c3e109a20:	add    rsp,0x8
    756c3e109a24:	ret
    756c3e109a25:	mov    eax,0x4101e8
    756c3e109a2a:	mov    QWORD PTR [r12+0x100],rax
    756c3e109a32:	push   rdx
    756c3e109a33:	push   rsi
    756c3e109a34:	push   r10
    756c3e109a36:	push   r11
    756c3e109a38:	mov    r11,rax
    756c3e109a3b:	lahf
    756c3e109a3c:	seto   al
    756c3e109a3f:	mov    WORD PTR [rsp+0x20],ax
    756c3e109a44:	mov    rax,r11
    756c3e109a47:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e109a4c:	mov    r10d,edx
    756c3e109a4f:	and    r10d,0xc000
    756c3e109a56:	shl    r10d,0x10
    756c3e109a5a:	mov    r11d,edx
    756c3e109a5d:	and    r11d,0x100
    756c3e109a64:	shl    r11d,0x15
    756c3e109a68:	or     r10d,r11d
    756c3e109a6b:	and    edx,0x1
    756c3e109a6e:	shl    edx,0x1c
    756c3e109a71:	or     r10d,edx
    756c3e109a74:	btc    r10,0x1d
    756c3e109a79:	mov    r11d,0xf0000000
    756c3e109a7f:	and    r11,r10
    756c3e109a82:	movabs rsi,0xffffffff0fffffff
    756c3e109a8c:	and    rbx,rsi
    756c3e109a8f:	or     rbx,r11
    756c3e109a92:	pop    r11
    756c3e109a94:	pop    r10
    756c3e109a96:	pop    rsi
    756c3e109a97:	pop    rdx
    756c3e109a98:	mov    QWORD PTR [r12+0x108],rbx
    756c3e109aa0:	add    rsp,0x150
    756c3e109aa7:	mov    eax,0xc
    756c3e109aac:	movabs r11,0x60a546e96ca0
    756c3e109ab6:	jmp    r11
    756c3e109ab9:	mov    eax,0x410440
    756c3e109abe:	mov    QWORD PTR [r12+0x100],rax
    756c3e109ac6:	push   rdx
    756c3e109ac7:	push   rsi
    756c3e109ac8:	push   r10
    756c3e109aca:	push   r11
    756c3e109acc:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e109ad1:	mov    r10d,edx
    756c3e109ad4:	and    r10d,0xc000
    756c3e109adb:	shl    r10d,0x10
    756c3e109adf:	mov    r11d,edx
    756c3e109ae2:	and    r11d,0x100
    756c3e109ae9:	shl    r11d,0x15
    756c3e109aed:	or     r10d,r11d
    756c3e109af0:	and    edx,0x1
    756c3e109af3:	shl    edx,0x1c
    756c3e109af6:	or     r10d,edx
    756c3e109af9:	btc    r10,0x1d
    756c3e109afe:	mov    r11d,0xf0000000
    756c3e109b04:	and    r11,r10
    756c3e109b07:	movabs rsi,0xffffffff0fffffff
    756c3e109b11:	and    rbx,rsi
    756c3e109b14:	or     rbx,r11
    756c3e109b17:	pop    r11
    756c3e109b19:	pop    r10
    756c3e109b1b:	pop    rsi
    756c3e109b1c:	pop    rdx
    756c3e109b1d:	mov    QWORD PTR [r12+0x108],rbx
    756c3e109b25:	add    rsp,0x150
    756c3e109b2c:	mov    eax,0xc
    756c3e109b31:	movabs r11,0x60a546e96ca0
    756c3e109b3b:	jmp    r11
    756c3e109b3e:	mov    eax,0x41044c
    756c3e109b43:	mov    QWORD PTR [r12+0x100],rax
    756c3e109b4b:	push   rdx
    756c3e109b4c:	push   rsi
    756c3e109b4d:	push   r10
    756c3e109b4f:	push   r11
    756c3e109b51:	mov    r11,rax
    756c3e109b54:	lahf
    756c3e109b55:	seto   al
    756c3e109b58:	mov    WORD PTR [rsp+0x20],ax
    756c3e109b5d:	mov    rax,r11
    756c3e109b60:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e109b65:	mov    r10d,edx
    756c3e109b68:	and    r10d,0xc000
    756c3e109b6f:	shl    r10d,0x10
    756c3e109b73:	mov    r11d,edx
    756c3e109b76:	and    r11d,0x100
    756c3e109b7d:	shl    r11d,0x15
    756c3e109b81:	or     r10d,r11d
    756c3e109b84:	and    edx,0x1
    756c3e109b87:	shl    edx,0x1c
    756c3e109b8a:	or     r10d,edx
    756c3e109b8d:	btc    r10,0x1d
    756c3e109b92:	mov    r11d,0xf0000000
    756c3e109b98:	and    r11,r10
    756c3e109b9b:	movabs rsi,0xffffffff0fffffff
    756c3e109ba5:	and    rbx,rsi
    756c3e109ba8:	or     rbx,r11
    756c3e109bab:	pop    r11
    756c3e109bad:	pop    r10
    756c3e109baf:	pop    rsi
    756c3e109bb0:	pop    rdx
    756c3e109bb1:	mov    QWORD PTR [r12+0x108],rbx
    756c3e109bb9:	add    rsp,0x150
    756c3e109bc0:	mov    eax,0xc
    756c3e109bc5:	movabs r11,0x60a546e96ca0
    756c3e109bcf:	jmp    r11
    756c3e109bd2:	mov    eax,0x41048c
    756c3e109bd7:	mov    QWORD PTR [r12+0x100],rax
    756c3e109bdf:	push   rdx
    756c3e109be0:	push   rsi
    756c3e109be1:	push   r10
    756c3e109be3:	push   r11
    756c3e109be5:	mov    r11,rax
    756c3e109be8:	lahf
    756c3e109be9:	seto   al
    756c3e109bec:	mov    WORD PTR [rsp+0x20],ax
    756c3e109bf1:	mov    rax,r11
    756c3e109bf4:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e109bf9:	mov    r10d,edx
    756c3e109bfc:	and    r10d,0xc000
    756c3e109c03:	shl    r10d,0x10
    756c3e109c07:	mov    r11d,edx
    756c3e109c0a:	and    r11d,0x100
    756c3e109c11:	shl    r11d,0x15
    756c3e109c15:	or     r10d,r11d
    756c3e109c18:	and    edx,0x1
    756c3e109c1b:	shl    edx,0x1c
    756c3e109c1e:	or     r10d,edx
    756c3e109c21:	btc    r10,0x1d
    756c3e109c26:	mov    r11d,0xf0000000
    756c3e109c2c:	and    r11,r10
    756c3e109c2f:	movabs rsi,0xffffffff0fffffff
    756c3e109c39:	and    rbx,rsi
    756c3e109c3c:	or     rbx,r11
    756c3e109c3f:	pop    r11
    756c3e109c41:	pop    r10
    756c3e109c43:	pop    rsi
    756c3e109c44:	pop    rdx
    756c3e109c45:	mov    QWORD PTR [r12+0x108],rbx
    756c3e109c4d:	add    rsp,0x150
    756c3e109c54:	mov    eax,0xc
    756c3e109c59:	movabs r11,0x60a546e96ca0
    756c3e109c63:	jmp    r11
    756c3e109c66:	mov    eax,0x410494
    756c3e109c6b:	mov    QWORD PTR [r12+0x100],rax
    756c3e109c73:	push   rdx
    756c3e109c74:	push   rsi
    756c3e109c75:	push   r10
    756c3e109c77:	push   r11
    756c3e109c79:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e109c7e:	mov    r10d,edx
    756c3e109c81:	and    r10d,0xc000
    756c3e109c88:	shl    r10d,0x10
    756c3e109c8c:	mov    r11d,edx
    756c3e109c8f:	and    r11d,0x100
    756c3e109c96:	shl    r11d,0x15
    756c3e109c9a:	or     r10d,r11d
    756c3e109c9d:	and    edx,0x1
    756c3e109ca0:	shl    edx,0x1c
    756c3e109ca3:	or     r10d,edx
    756c3e109ca6:	btc    r10,0x1d
    756c3e109cab:	mov    r11d,0xf0000000
    756c3e109cb1:	and    r11,r10
    756c3e109cb4:	movabs rsi,0xffffffff0fffffff
    756c3e109cbe:	and    rbx,rsi
    756c3e109cc1:	or     rbx,r11
    756c3e109cc4:	pop    r11
    756c3e109cc6:	pop    r10
    756c3e109cc8:	pop    rsi
    756c3e109cc9:	pop    rdx
    756c3e109cca:	mov    QWORD PTR [r12+0x108],rbx
    756c3e109cd2:	add    rsp,0x150
    756c3e109cd9:	mov    eax,0xc
    756c3e109cde:	movabs r11,0x60a546e96ca0
    756c3e109ce8:	jmp    r11
    756c3e109ceb:	nop    DWORD PTR [rax+rax*1+0x0]
    756c3e109cf0:	sub    rsp,0x150
    756c3e109cf7:	mov    r11,QWORD PTR [r12+0x398]
    756c3e109cff:	mov    QWORD PTR [rsp],r11
    756c3e109d03:	cmp    DWORD PTR [r12+0x310],0x0
    756c3e109d0c:	je     0x756c3e109d97
    756c3e109d12:	push   rdx
    756c3e109d13:	push   rsi
    756c3e109d14:	push   r10
    756c3e109d16:	push   r11
    756c3e109d18:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e109d1d:	mov    r10d,edx
    756c3e109d20:	and    r10d,0xc000
    756c3e109d27:	shl    r10d,0x10
    756c3e109d2b:	mov    r11d,edx
    756c3e109d2e:	and    r11d,0x100
    756c3e109d35:	shl    r11d,0x15
    756c3e109d39:	or     r10d,r11d
    756c3e109d3c:	and    edx,0x1
    756c3e109d3f:	shl    edx,0x1c
    756c3e109d42:	or     r10d,edx
    756c3e109d45:	btc    r10,0x1d
    756c3e109d4a:	mov    r11d,0xf0000000
    756c3e109d50:	and    r11,r10
    756c3e109d53:	movabs rsi,0xffffffff0fffffff
    756c3e109d5d:	and    rbx,rsi
    756c3e109d60:	or     rbx,r11
    756c3e109d63:	pop    r11
    756c3e109d65:	pop    r10
    756c3e109d67:	pop    rsi
    756c3e109d68:	pop    rdx
    756c3e109d69:	mov    QWORD PTR [r12+0x108],rbx
    756c3e109d71:	mov    eax,0x4101ac
    756c3e109d76:	mov    QWORD PTR [r12+0x100],rax
    756c3e109d7e:	add    rsp,0x150
    756c3e109d85:	mov    eax,0x3
    756c3e109d8a:	movabs r11,0x60a546e96ca0
    756c3e109d94:	jmp    r11
    756c3e109d97:	mov    r11,rax
    756c3e109d9a:	movzx  eax,WORD PTR [rsp]
    756c3e109d9e:	add    al,0x7f
    756c3e109da0:	sahf
    756c3e109da1:	mov    rax,r11
    756c3e109da4:	jmp    0x756c3e100202
    756c3e109da9:	nop    DWORD PTR [rax+0x0]
    756c3e109db0:	sub    rsp,0x150
    756c3e109db7:	mov    r11,QWORD PTR [r12+0x398]
    756c3e109dbf:	mov    QWORD PTR [rsp],r11
    756c3e109dc3:	cmp    DWORD PTR [r12+0x310],0x0
    756c3e109dcc:	je     0x756c3e109e57
    756c3e109dd2:	push   rdx
    756c3e109dd3:	push   rsi
    756c3e109dd4:	push   r10
    756c3e109dd6:	push   r11
    756c3e109dd8:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e109ddd:	mov    r10d,edx
    756c3e109de0:	and    r10d,0xc000
    756c3e109de7:	shl    r10d,0x10
    756c3e109deb:	mov    r11d,edx
    756c3e109dee:	and    r11d,0x100
    756c3e109df5:	shl    r11d,0x15
    756c3e109df9:	or     r10d,r11d
    756c3e109dfc:	and    edx,0x1
    756c3e109dff:	shl    edx,0x1c
    756c3e109e02:	or     r10d,edx
    756c3e109e05:	btc    r10,0x1d
    756c3e109e0a:	mov    r11d,0xf0000000
    756c3e109e10:	and    r11,r10
    756c3e109e13:	movabs rsi,0xffffffff0fffffff
    756c3e109e1d:	and    rbx,rsi
    756c3e109e20:	or     rbx,r11
    756c3e109e23:	pop    r11
    756c3e109e25:	pop    r10
    756c3e109e27:	pop    rsi
    756c3e109e28:	pop    rdx
    756c3e109e29:	mov    QWORD PTR [r12+0x108],rbx
    756c3e109e31:	mov    eax,0x4101ec
    756c3e109e36:	mov    QWORD PTR [r12+0x100],rax
    756c3e109e3e:	add    rsp,0x150
    756c3e109e45:	mov    eax,0x3
    756c3e109e4a:	movabs r11,0x60a546e96ca0
    756c3e109e54:	jmp    r11
    756c3e109e57:	jmp    0x756c3e100650
    756c3e109e5c:	nop    DWORD PTR [rax+0x0]
    756c3e109e60:	sub    rsp,0x150
    756c3e109e67:	mov    r11,QWORD PTR [r12+0x398]
    756c3e109e6f:	mov    QWORD PTR [rsp],r11
    756c3e109e73:	cmp    DWORD PTR [r12+0x310],0x0
    756c3e109e7c:	je     0x756c3e109f07
    756c3e109e82:	push   rdx
    756c3e109e83:	push   rsi
    756c3e109e84:	push   r10
    756c3e109e86:	push   r11
    756c3e109e88:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e109e8d:	mov    r10d,edx
    756c3e109e90:	and    r10d,0xc000
    756c3e109e97:	shl    r10d,0x10
    756c3e109e9b:	mov    r11d,edx
    756c3e109e9e:	and    r11d,0x100
    756c3e109ea5:	shl    r11d,0x15
    756c3e109ea9:	or     r10d,r11d
    756c3e109eac:	and    edx,0x1
    756c3e109eaf:	shl    edx,0x1c
    756c3e109eb2:	or     r10d,edx
    756c3e109eb5:	btc    r10,0x1d
    756c3e109eba:	mov    r11d,0xf0000000
    756c3e109ec0:	and    r11,r10
    756c3e109ec3:	movabs rsi,0xffffffff0fffffff
    756c3e109ecd:	and    rbx,rsi
    756c3e109ed0:	or     rbx,r11
    756c3e109ed3:	pop    r11
    756c3e109ed5:	pop    r10
    756c3e109ed7:	pop    rsi
    756c3e109ed8:	pop    rdx
    756c3e109ed9:	mov    QWORD PTR [r12+0x108],rbx
    756c3e109ee1:	mov    eax,0x410274
    756c3e109ee6:	mov    QWORD PTR [r12+0x100],rax
    756c3e109eee:	add    rsp,0x150
    756c3e109ef5:	mov    eax,0x3
    756c3e109efa:	movabs r11,0x60a546e96ca0
    756c3e109f04:	jmp    r11
    756c3e109f07:	mov    r11,rax
    756c3e109f0a:	movzx  eax,WORD PTR [rsp]
    756c3e109f0e:	add    al,0x7f
    756c3e109f10:	sahf
    756c3e109f11:	mov    rax,r11
    756c3e109f14:	jmp    0x756c3e100b1b
    756c3e109f19:	nop    DWORD PTR [rax+0x0]
    756c3e109f20:	sub    rsp,0x150
    756c3e109f27:	mov    r11,QWORD PTR [r12+0x398]
    756c3e109f2f:	mov    QWORD PTR [rsp],r11
    756c3e109f33:	cmp    DWORD PTR [r12+0x310],0x0
    756c3e109f3c:	je     0x756c3e109fc7
    756c3e109f42:	push   rdx
    756c3e109f43:	push   rsi
    756c3e109f44:	push   r10
    756c3e109f46:	push   r11
    756c3e109f48:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e109f4d:	mov    r10d,edx
    756c3e109f50:	and    r10d,0xc000
    756c3e109f57:	shl    r10d,0x10
    756c3e109f5b:	mov    r11d,edx
    756c3e109f5e:	and    r11d,0x100
    756c3e109f65:	shl    r11d,0x15
    756c3e109f69:	or     r10d,r11d
    756c3e109f6c:	and    edx,0x1
    756c3e109f6f:	shl    edx,0x1c
    756c3e109f72:	or     r10d,edx
    756c3e109f75:	btc    r10,0x1d
    756c3e109f7a:	mov    r11d,0xf0000000
    756c3e109f80:	and    r11,r10
    756c3e109f83:	movabs rsi,0xffffffff0fffffff
    756c3e109f8d:	and    rbx,rsi
    756c3e109f90:	or     rbx,r11
    756c3e109f93:	pop    r11
    756c3e109f95:	pop    r10
    756c3e109f97:	pop    rsi
    756c3e109f98:	pop    rdx
    756c3e109f99:	mov    QWORD PTR [r12+0x108],rbx
    756c3e109fa1:	mov    eax,0x410278
    756c3e109fa6:	mov    QWORD PTR [r12+0x100],rax
    756c3e109fae:	add    rsp,0x150
    756c3e109fb5:	mov    eax,0x3
    756c3e109fba:	movabs r11,0x60a546e96ca0
    756c3e109fc4:	jmp    r11
    756c3e109fc7:	jmp    0x756c3e100b39
    756c3e109fcc:	nop    DWORD PTR [rax+0x0]
    756c3e109fd0:	sub    rsp,0x150
    756c3e109fd7:	mov    r11,QWORD PTR [r12+0x398]
    756c3e109fdf:	mov    QWORD PTR [rsp],r11
    756c3e109fe3:	cmp    DWORD PTR [r12+0x310],0x0
    756c3e109fec:	je     0x756c3e10a077
    756c3e109ff2:	push   rdx
    756c3e109ff3:	push   rsi
    756c3e109ff4:	push   r10
    756c3e109ff6:	push   r11
    756c3e109ff8:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e109ffd:	mov    r10d,edx
    756c3e10a000:	and    r10d,0xc000
    756c3e10a007:	shl    r10d,0x10
    756c3e10a00b:	mov    r11d,edx
    756c3e10a00e:	and    r11d,0x100
    756c3e10a015:	shl    r11d,0x15
    756c3e10a019:	or     r10d,r11d
    756c3e10a01c:	and    edx,0x1
    756c3e10a01f:	shl    edx,0x1c
    756c3e10a022:	or     r10d,edx
    756c3e10a025:	btc    r10,0x1d
    756c3e10a02a:	mov    r11d,0xf0000000
    756c3e10a030:	and    r11,r10
    756c3e10a033:	movabs rsi,0xffffffff0fffffff
    756c3e10a03d:	and    rbx,rsi
    756c3e10a040:	or     rbx,r11
    756c3e10a043:	pop    r11
    756c3e10a045:	pop    r10
    756c3e10a047:	pop    rsi
    756c3e10a048:	pop    rdx
    756c3e10a049:	mov    QWORD PTR [r12+0x108],rbx
    756c3e10a051:	mov    eax,0x410444
    756c3e10a056:	mov    QWORD PTR [r12+0x100],rax
    756c3e10a05e:	add    rsp,0x150
    756c3e10a065:	mov    eax,0x3
    756c3e10a06a:	movabs r11,0x60a546e96ca0
    756c3e10a074:	jmp    r11
    756c3e10a077:	jmp    0x756c3e102879
    756c3e10a07c:	nop    DWORD PTR [rax+0x0]
    756c3e10a080:	sub    rsp,0x150
    756c3e10a087:	mov    r11,QWORD PTR [r12+0x398]
    756c3e10a08f:	mov    QWORD PTR [rsp],r11
    756c3e10a093:	cmp    DWORD PTR [r12+0x310],0x0
    756c3e10a09c:	je     0x756c3e10a127
    756c3e10a0a2:	push   rdx
    756c3e10a0a3:	push   rsi
    756c3e10a0a4:	push   r10
    756c3e10a0a6:	push   r11
    756c3e10a0a8:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e10a0ad:	mov    r10d,edx
    756c3e10a0b0:	and    r10d,0xc000
    756c3e10a0b7:	shl    r10d,0x10
    756c3e10a0bb:	mov    r11d,edx
    756c3e10a0be:	and    r11d,0x100
    756c3e10a0c5:	shl    r11d,0x15
    756c3e10a0c9:	or     r10d,r11d
    756c3e10a0cc:	and    edx,0x1
    756c3e10a0cf:	shl    edx,0x1c
    756c3e10a0d2:	or     r10d,edx
    756c3e10a0d5:	btc    r10,0x1d
    756c3e10a0da:	mov    r11d,0xf0000000
    756c3e10a0e0:	and    r11,r10
    756c3e10a0e3:	movabs rsi,0xffffffff0fffffff
    756c3e10a0ed:	and    rbx,rsi
    756c3e10a0f0:	or     rbx,r11
    756c3e10a0f3:	pop    r11
    756c3e10a0f5:	pop    r10
    756c3e10a0f7:	pop    rsi
    756c3e10a0f8:	pop    rdx
    756c3e10a0f9:	mov    QWORD PTR [r12+0x108],rbx
    756c3e10a101:	mov    eax,0x410450
    756c3e10a106:	mov    QWORD PTR [r12+0x100],rax
    756c3e10a10e:	add    rsp,0x150
    756c3e10a115:	mov    eax,0x3
    756c3e10a11a:	movabs r11,0x60a546e96ca0
    756c3e10a124:	jmp    r11
    756c3e10a127:	jmp    0x756c3e1028b6
    756c3e10a12c:	nop    DWORD PTR [rax+0x0]
    756c3e10a130:	sub    rsp,0x150
    756c3e10a137:	mov    r11,QWORD PTR [r12+0x398]
    756c3e10a13f:	mov    QWORD PTR [rsp],r11
    756c3e10a143:	cmp    DWORD PTR [r12+0x310],0x0
    756c3e10a14c:	je     0x756c3e10a1d7
    756c3e10a152:	push   rdx
    756c3e10a153:	push   rsi
    756c3e10a154:	push   r10
    756c3e10a156:	push   r11
    756c3e10a158:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e10a15d:	mov    r10d,edx
    756c3e10a160:	and    r10d,0xc000
    756c3e10a167:	shl    r10d,0x10
    756c3e10a16b:	mov    r11d,edx
    756c3e10a16e:	and    r11d,0x100
    756c3e10a175:	shl    r11d,0x15
    756c3e10a179:	or     r10d,r11d
    756c3e10a17c:	and    edx,0x1
    756c3e10a17f:	shl    edx,0x1c
    756c3e10a182:	or     r10d,edx
    756c3e10a185:	btc    r10,0x1d
    756c3e10a18a:	mov    r11d,0xf0000000
    756c3e10a190:	and    r11,r10
    756c3e10a193:	movabs rsi,0xffffffff0fffffff
    756c3e10a19d:	and    rbx,rsi
    756c3e10a1a0:	or     rbx,r11
    756c3e10a1a3:	pop    r11
    756c3e10a1a5:	pop    r10
    756c3e10a1a7:	pop    rsi
    756c3e10a1a8:	pop    rdx
    756c3e10a1a9:	mov    QWORD PTR [r12+0x108],rbx
    756c3e10a1b1:	mov    eax,0x410474
    756c3e10a1b6:	mov    QWORD PTR [r12+0x100],rax
    756c3e10a1be:	add    rsp,0x150
    756c3e10a1c5:	mov    eax,0x3
    756c3e10a1ca:	movabs r11,0x60a546e96ca0
    756c3e10a1d4:	jmp    r11
    756c3e10a1d7:	jmp    0x756c3e102a28
    756c3e10a1dc:	nop    DWORD PTR [rax+0x0]
    756c3e10a1e0:	sub    rsp,0x150
    756c3e10a1e7:	mov    r11,QWORD PTR [r12+0x398]
    756c3e10a1ef:	mov    QWORD PTR [rsp],r11
    756c3e10a1f3:	cmp    DWORD PTR [r12+0x310],0x0
    756c3e10a1fc:	je     0x756c3e10a287
    756c3e10a202:	push   rdx
    756c3e10a203:	push   rsi
    756c3e10a204:	push   r10
    756c3e10a206:	push   r11
    756c3e10a208:	mov    rdx,QWORD PTR [rsp+0x20]
    756c3e10a20d:	mov    r10d,edx
    756c3e10a210:	and    r10d,0xc000
    756c3e10a217:	shl    r10d,0x10
    756c3e10a21b:	mov    r11d,edx
    756c3e10a21e:	and    r11d,0x100
    756c3e10a225:	shl    r11d,0x15
    756c3e10a229:	or     r10d,r11d
    756c3e10a22c:	and    edx,0x1
    756c3e10a22f:	shl    edx,0x1c
    756c3e10a232:	or     r10d,edx
    756c3e10a235:	btc    r10,0x1d
    756c3e10a23a:	mov    r11d,0xf0000000
    756c3e10a240:	and    r11,r10
    756c3e10a243:	movabs rsi,0xffffffff0fffffff
    756c3e10a24d:	and    rbx,rsi
    756c3e10a250:	or     rbx,r11
    756c3e10a253:	pop    r11
    756c3e10a255:	pop    r10
    756c3e10a257:	pop    rsi
    756c3e10a258:	pop    rdx
    756c3e10a259:	mov    QWORD PTR [r12+0x108],rbx
    756c3e10a261:	mov    eax,0x410490
    756c3e10a266:	mov    QWORD PTR [r12+0x100],rax
    756c3e10a26e:	add    rsp,0x150
    756c3e10a275:	mov    eax,0x3
    756c3e10a27a:	movabs r11,0x60a546e96ca0
    756c3e10a284:	jmp    r11
    756c3e10a287:	jmp    0x756c3e102b81
    756c3e10a28c:	nop    DWORD PTR [rax+0x0]
    756c3e10a290:	(bad)
    756c3e10a291:	(bad)
    756c3e10a292:	(bad)
    756c3e10a293:	(bad)
    756c3e10a294:	(bad)
    756c3e10a295:	(bad)
    756c3e10a296:	(bad)
    756c3e10a297:	jg     0x756c3e10a298
    756c3e10a299:	(bad)
    756c3e10a29a:	(bad)
    756c3e10a29b:	(bad)
    756c3e10a29c:	(bad)
    756c3e10a29d:	(bad)
    756c3e10a29e:	(bad)
    756c3e10a29f:	jg     0x756c3e10a2a1
    756c3e10a2a1:	add    BYTE PTR [rax],al
    756c3e10a2a3:	add    BYTE PTR [rax],al
    756c3e10a2a5:	add    BYTE PTR [rax],dl
    756c3e10a2a7:	add    BYTE PTR [rax],al
    756c3e10a2a9:	add    BYTE PTR [rax],al
    756c3e10a2ab:	add    BYTE PTR [rax],al
    756c3e10a2ad:	add    BYTE PTR [rax],dl
	...
