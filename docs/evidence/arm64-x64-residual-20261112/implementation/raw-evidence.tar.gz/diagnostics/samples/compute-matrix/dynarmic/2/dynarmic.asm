000070bab59ce69b  nop [rax+rax*1], eax
000070bab59ce6a0  vmovaps xmm1, [0x000070BAB55FE010]
000070bab59ce6a8  movq xmm1, xmm1
000070bab59ce6ac  movaps [r15+0x110], xmm1
000070bab59ce6b4  vmovaps xmm1, [0x000070BAB55FE020]
000070bab59ce6bc  movq xmm1, xmm1
000070bab59ce6c0  movaps [r15+0x120], xmm1
000070bab59ce6c8  mov eax, 0x4204C0
000070bab59ce6cd  mov r14, [r13+rax*1]
000070bab59ce6d2  movq xmm1, r14
000070bab59ce6d7  movaps [r15+0x130], xmm1
000070bab59ce6df  vmovaps xmm1, [0x000070BAB55FE030]
000070bab59ce6e7  vpbroadcastq xmm1, xmm1
000070bab59ce6ec  movaps [r15+0x140], xmm1
000070bab59ce6f4  mov qword ptr [r15+0x40], 0x02
000070bab59ce6fc  vmovaps xmm15, [0x000070BAB55FE040]
000070bab59ce704  movq xmm15, xmm15
000070bab59ce709  movaps [r15+0x150], xmm15
000070bab59ce711  mov qword ptr [r15+0x58], 0x420000
000070bab59ce719  vmovaps xmm15, [0x000070BAB55FE050]
000070bab59ce721  vpbroadcastq xmm15, xmm15
000070bab59ce726  movaps [r15+0x160], xmm15
000070bab59ce72e  mov rax, [r15+0x40]
000070bab59ce732  vmovq xmm14, rax
000070bab59ce737  vpbroadcastq xmm14, xmm14
000070bab59ce73c  movaps [r15+0x170], xmm14
000070bab59ce744  mov eax, 0x4204D0
000070bab59ce749  movups xmm13, [r13+rax*1]
000070bab59ce74f  mov qword ptr [r15+0x40], 0x430518
000070bab59ce757  mov qword ptr [r15+0x50], 0x430720
000070bab59ce75f  vpmovqd xmm12, xmm13
000070bab59ce765  pxor xmm11, xmm11
000070bab59ce76a  punpcklqdq xmm12, xmm11
000070bab59ce76f  movaps [r15+0x210], xmm12
000070bab59ce777  movq xmm12, qword ptr [r15+0x120]
000070bab59ce780  movq xmm11, qword ptr [r15+0x130]
000070bab59ce789  psubd xmm12, xmm11
000070bab59ce78e  movq xmm12, xmm12
000070bab59ce793  paddq xmm13, xmm14
000070bab59ce798  movaps [r15+0x180], xmm13
000070bab59ce7a0  movq xmm14, qword ptr [r15+0x150]
000070bab59ce7a9  paddd xmm11, xmm14
000070bab59ce7ae  movq xmm11, xmm11
000070bab59ce7b3  movq xmm11, xmm11
000070bab59ce7b8  movaps [r15+0x130], xmm11
000070bab59ce7c0  pmovzxdq xmm12, xmm12
000070bab59ce7c6  psllq xmm12, 0x00
000070bab59ce7cc  movq xmm14, qword ptr [r15+0x210]
000070bab59ce7d5  movq xmm13, qword ptr [r15+0x110]
000070bab59ce7de  paddd xmm14, xmm13
000070bab59ce7e3  movq xmm14, xmm14
000070bab59ce7e8  vcvtuqq2pd xmm12, xmm12
000070bab59ce7ee  pmovzxdq xmm14, xmm14
000070bab59ce7f4  psllq xmm14, 0x00
000070bab59ce7fa  vcvtuqq2pd xmm14, xmm14
000070bab59ce800  movaps xmm13, xmm12
000070bab59ce804  mulpd xmm13, xmm1
000070bab59ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000070bab59ce80f  ptest xmm11, xmm11
000070bab59ce815  jnz 0x000070BAB59CE8FF
000070bab59ce81b  movaps [r15+0x220], xmm13
000070bab59ce823  mov eax, 0x430720
000070bab59ce828  movups [r13+rax*1], xmm13
000070bab59ce82e  movaps xmm1, xmm14
000070bab59ce832  mulpd xmm1, xmm15
000070bab59ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000070bab59ce83c  ptest xmm13, xmm13
000070bab59ce842  jnz 0x000070BAB59CEA4C
000070bab59ce848  movaps [r15+0x210], xmm1
000070bab59ce850  mov eax, 0x430518
000070bab59ce855  movups [r13+rax*1], xmm1
000070bab59ce85b  mov qword ptr [r15+0x48], 0x10
000070bab59ce863  xor eax, eax
000070bab59ce865  mov r14d, 0x10
000070bab59ce86b  mov r12d, 0x200
000070bab59ce871  cmp r14, r12
000070bab59ce874  cmc
000070bab59ce875  lahf
000070bab59ce876  seto al
000070bab59ce879  mov [r15+0x108], eax
000070bab59ce880  mov eax, [r15+0x108]
000070bab59ce887  sahf
000070bab59ce888  jnz 0x000070BAB59CE8BA
000070bab59ce88a  cmp dword ptr [r15+0x318], 0x00
000070bab59ce892  jz 0x000070BAB59CEFF0
000070bab59ce898  nop [rax+rax*1], ax
000070bab59ce8a1  nop [rax+rax*1], eax
000070bab59ce8a9  mov eax, 0x4101EC
000070bab59ce8ae  mov [r15+0x100], rax
000070bab59ce8b5  jmp 0x000070BAB57FE110
000070bab59ce8ba  cmp dword ptr [r15+0x318], 0x00
000070bab59ce8c2  jz 0x000070BAB59CEBA0
000070bab59ce8c8  nop [rax+rax*1], ax
000070bab59ce8d1  nop [rax+rax*1], eax
000070bab59ce8d9  mov eax, 0x4101AC
000070bab59ce8de  mov [r15+0x100], rax
000070bab59ce8e5  jmp 0x000070BAB57FE110
000070bab59ce8ea  int3
000070bab59ce8eb  call 0x000070BAB580DC20
000070bab59ce8f0  jmp 0x000070BAB59CE6D2
000070bab59ce8f5  call 0x000070BAB580C260
000070bab59ce8fa  jmp 0x000070BAB59CE74F
000070bab59ce8ff  sub rsp, 0x08
000070bab59ce903  push rax
000070bab59ce904  push rcx
000070bab59ce905  push rdx
000070bab59ce906  push rdi
000070bab59ce907  push rsi
000070bab59ce908  push r8
000070bab59ce90a  push r9
000070bab59ce90c  push r10
000070bab59ce90e  push r11
000070bab59ce910  sub rsp, 0xF0
000070bab59ce917  vmovaps [rsp], xmm0
000070bab59ce91c  vmovaps [rsp+0x10], xmm1
000070bab59ce922  vmovaps [rsp+0x20], xmm2
000070bab59ce928  vmovaps [rsp+0x30], xmm3
000070bab59ce92e  vmovaps [rsp+0x40], xmm4
000070bab59ce934  vmovaps [rsp+0x50], xmm5
000070bab59ce93a  vmovaps [rsp+0x60], xmm6
000070bab59ce940  vmovaps [rsp+0x70], xmm7
000070bab59ce946  vmovaps [rsp+0x80], xmm8
000070bab59ce94f  vmovaps [rsp+0x90], xmm9
000070bab59ce958  vmovaps [rsp+0xA0], xmm10
000070bab59ce961  vmovaps [rsp+0xB0], xmm11
000070bab59ce96a  vmovaps [rsp+0xC0], xmm12
000070bab59ce973  vmovaps [rsp+0xD0], xmm14
000070bab59ce97c  vmovaps [rsp+0xE0], xmm15
000070bab59ce985  sub rsp, 0x30
000070bab59ce989  movaps [rsp], xmm13
000070bab59ce98e  movaps [rsp+0x10], xmm12
000070bab59ce994  movaps [rsp+0x20], xmm1
000070bab59ce999  lea rdi, [rsp]
000070bab59ce99d  mov esi, 0x00
000070bab59ce9a2  mov rax, 0x63B35AFBC530
000070bab59ce9ac  call rax
000070bab59ce9ae  movaps xmm13, [rsp]
000070bab59ce9b3  add rsp, 0x30
000070bab59ce9b7  vmovaps xmm0, [rsp]
000070bab59ce9bc  vmovaps xmm1, [rsp+0x10]
000070bab59ce9c2  vmovaps xmm2, [rsp+0x20]
000070bab59ce9c8  vmovaps xmm3, [rsp+0x30]
000070bab59ce9ce  vmovaps xmm4, [rsp+0x40]
000070bab59ce9d4  vmovaps xmm5, [rsp+0x50]
000070bab59ce9da  vmovaps xmm6, [rsp+0x60]
000070bab59ce9e0  vmovaps xmm7, [rsp+0x70]
000070bab59ce9e6  vmovaps xmm8, [rsp+0x80]
000070bab59ce9ef  vmovaps xmm9, [rsp+0x90]
000070bab59ce9f8  vmovaps xmm10, [rsp+0xA0]
000070bab59cea01  vmovaps xmm11, [rsp+0xB0]
000070bab59cea0a  vmovaps xmm12, [rsp+0xC0]
000070bab59cea13  vmovaps xmm14, [rsp+0xD0]
000070bab59cea1c  vmovaps xmm15, [rsp+0xE0]
000070bab59cea25  add rsp, 0xF0
000070bab59cea2c  pop r11
000070bab59cea2e  pop r10
000070bab59cea30  pop r9
000070bab59cea32  pop r8
000070bab59cea34  pop rsi
000070bab59cea35  pop rdi
000070bab59cea36  pop rdx
000070bab59cea37  pop rcx
000070bab59cea38  pop rax
000070bab59cea39  add rsp, 0x08
000070bab59cea3d  jmp 0x000070BAB59CE81B
000070bab59cea42  call 0x000070BAB580C380
000070bab59cea47  jmp 0x000070BAB59CE82E
000070bab59cea4c  sub rsp, 0x08
000070bab59cea50  push rax
000070bab59cea51  push rcx
000070bab59cea52  push rdx
000070bab59cea53  push rdi
000070bab59cea54  push rsi
000070bab59cea55  push r8
000070bab59cea57  push r9
000070bab59cea59  push r10
000070bab59cea5b  push r11
000070bab59cea5d  sub rsp, 0xF0
000070bab59cea64  vmovaps [rsp], xmm0
000070bab59cea69  vmovaps [rsp+0x10], xmm2
000070bab59cea6f  vmovaps [rsp+0x20], xmm3
000070bab59cea75  vmovaps [rsp+0x30], xmm4
000070bab59cea7b  vmovaps [rsp+0x40], xmm5
000070bab59cea81  vmovaps [rsp+0x50], xmm6
000070bab59cea87  vmovaps [rsp+0x60], xmm7
000070bab59cea8d  vmovaps [rsp+0x70], xmm8
000070bab59cea93  vmovaps [rsp+0x80], xmm9
000070bab59cea9c  vmovaps [rsp+0x90], xmm10
000070bab59ceaa5  vmovaps [rsp+0xA0], xmm11
000070bab59ceaae  vmovaps [rsp+0xB0], xmm12
000070bab59ceab7  vmovaps [rsp+0xC0], xmm13
000070bab59ceac0  vmovaps [rsp+0xD0], xmm14
000070bab59ceac9  vmovaps [rsp+0xE0], xmm15
000070bab59cead2  sub rsp, 0x30
000070bab59cead6  movaps [rsp], xmm1
000070bab59ceada  movaps [rsp+0x10], xmm14
000070bab59ceae0  movaps [rsp+0x20], xmm15
000070bab59ceae6  lea rdi, [rsp]
000070bab59ceaea  mov esi, 0x00
000070bab59ceaef  mov rax, 0x63B35AFBC530
000070bab59ceaf9  call rax
000070bab59ceafb  movaps xmm1, [rsp]
000070bab59ceaff  add rsp, 0x30
000070bab59ceb03  vmovaps xmm0, [rsp]
000070bab59ceb08  vmovaps xmm2, [rsp+0x10]
000070bab59ceb0e  vmovaps xmm3, [rsp+0x20]
000070bab59ceb14  vmovaps xmm4, [rsp+0x30]
000070bab59ceb1a  vmovaps xmm5, [rsp+0x40]
000070bab59ceb20  vmovaps xmm6, [rsp+0x50]
000070bab59ceb26  vmovaps xmm7, [rsp+0x60]
000070bab59ceb2c  vmovaps xmm8, [rsp+0x70]
000070bab59ceb32  vmovaps xmm9, [rsp+0x80]
000070bab59ceb3b  vmovaps xmm10, [rsp+0x90]
000070bab59ceb44  vmovaps xmm11, [rsp+0xA0]
000070bab59ceb4d  vmovaps xmm12, [rsp+0xB0]
000070bab59ceb56  vmovaps xmm13, [rsp+0xC0]
000070bab59ceb5f  vmovaps xmm14, [rsp+0xD0]
000070bab59ceb68  vmovaps xmm15, [rsp+0xE0]
000070bab59ceb71  add rsp, 0xF0
000070bab59ceb78  pop r11
000070bab59ceb7a  pop r10
000070bab59ceb7c  pop r9
000070bab59ceb7e  pop r8
000070bab59ceb80  pop rsi
000070bab59ceb81  pop rdi
000070bab59ceb82  pop rdx
000070bab59ceb83  pop rcx
000070bab59ceb84  pop rax
000070bab59ceb85  add rsp, 0x08
000070bab59ceb89  jmp 0x000070BAB59CE848
000070bab59ceb8e  call 0x000070BAB57FF540
000070bab59ceb93  jmp 0x000070BAB59CE85B
000070bab59ceb98  int3
000070bab59ceb99  nop [rax], eax
000070bab59ceba0  movaps xmm1, [r15+0x180]
000070bab59ceba8  vpmovqd xmm15, xmm1
000070bab59cebae  pxor xmm14, xmm14
000070bab59cebb3  punpcklqdq xmm15, xmm14
000070bab59cebb8  movaps [r15+0x210], xmm15
000070bab59cebc0  movq xmm15, qword ptr [r15+0x120]
000070bab59cebc9  movq xmm14, qword ptr [r15+0x130]
000070bab59cebd2  psubd xmm15, xmm14
000070bab59cebd7  movq xmm15, xmm15
000070bab59cebdc  movaps xmm13, [r15+0x170]
000070bab59cebe4  paddq xmm1, xmm13
000070bab59cebe9  movaps [r15+0x180], xmm1
000070bab59cebf1  movq xmm1, qword ptr [r15+0x150]
000070bab59cebfa  paddd xmm14, xmm1
000070bab59cebff  movq xmm14, xmm14
000070bab59cec04  movq xmm14, xmm14
000070bab59cec09  movaps [r15+0x130], xmm14
000070bab59cec11  pmovzxdq xmm15, xmm15
000070bab59cec17  psllq xmm15, 0x00
000070bab59cec1d  movq xmm1, qword ptr [r15+0x210]
000070bab59cec26  movq xmm14, qword ptr [r15+0x110]
000070bab59cec2f  paddd xmm1, xmm14
000070bab59cec34  movq xmm1, xmm1
000070bab59cec38  vcvtuqq2pd xmm15, xmm15
000070bab59cec3e  pmovzxdq xmm1, xmm1
000070bab59cec43  psllq xmm1, 0x00
000070bab59cec48  vcvtuqq2pd xmm1, xmm1
000070bab59cec4e  movaps xmm14, [r15+0x140]
000070bab59cec56  movaps xmm13, xmm15
000070bab59cec5a  mulpd xmm13, xmm14
000070bab59cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000070bab59cec65  ptest xmm12, xmm12
000070bab59cec6b  jnz 0x000070BAB59CED4E
000070bab59cec71  movaps [r15+0x220], xmm13
000070bab59cec79  mov rax, [r15+0x48]
000070bab59cec7d  mov r14, [r15+0x50]
000070bab59cec81  lea r12, [r14+rax*1]
000070bab59cec85  movups [r13+r12*1], xmm13
000070bab59cec8b  movaps xmm15, [r15+0x160]
000070bab59cec93  movaps xmm14, xmm1
000070bab59cec97  mulpd xmm14, xmm15
000070bab59cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000070bab59ceca2  ptest xmm13, xmm13
000070bab59ceca8  jnz 0x000070BAB59CEE9C
000070bab59cecae  movaps [r15+0x210], xmm14
000070bab59cecb6  mov r14, [r15+0x40]
000070bab59cecba  lea r12, [r14+rax*1]
000070bab59cecbe  movups [r13+r12*1], xmm14
000070bab59cecc4  lea r14, [rax+0x10]
000070bab59cecc8  mov [r15+0x48], r14
000070bab59ceccc  xor eax, eax
000070bab59cecce  mov r12d, 0x200
000070bab59cecd4  cmp r14, r12
000070bab59cecd7  cmc
000070bab59cecd8  lahf
000070bab59cecd9  seto al
000070bab59cecdc  mov [r15+0x108], eax
000070bab59cece3  mov eax, [r15+0x108]
000070bab59cecea  sahf
000070bab59ceceb  jnz 0x000070BAB59CED1D
000070bab59ceced  cmp dword ptr [r15+0x318], 0x00
000070bab59cecf5  jz 0x000070BAB59CEFF0
000070bab59cecfb  nop [rax+rax*1], ax
000070bab59ced04  nop [rax+rax*1], eax
000070bab59ced0c  mov eax, 0x4101EC
000070bab59ced11  mov [r15+0x100], rax
000070bab59ced18  jmp 0x000070BAB57FE110
000070bab59ced1d  cmp dword ptr [r15+0x318], 0x00
000070bab59ced25  jz 0x000070BAB59CEBA0
000070bab59ced2b  nop [rax+rax*1], ax
000070bab59ced34  nop [rax+rax*1], eax
000070bab59ced3c  mov eax, 0x4101AC
000070bab59ced41  mov [r15+0x100], rax
000070bab59ced48  jmp 0x000070BAB57FE110
000070bab59ced4d  int3
000070bab59ced4e  sub rsp, 0x08
000070bab59ced52  push rax
000070bab59ced53  push rcx
000070bab59ced54  push rdx
000070bab59ced55  push rdi
000070bab59ced56  push rsi
000070bab59ced57  push r8
000070bab59ced59  push r9
000070bab59ced5b  push r10
000070bab59ced5d  push r11
000070bab59ced5f  sub rsp, 0xF0
000070bab59ced66  vmovaps [rsp], xmm0
000070bab59ced6b  vmovaps [rsp+0x10], xmm1
000070bab59ced71  vmovaps [rsp+0x20], xmm2
000070bab59ced77  vmovaps [rsp+0x30], xmm3
000070bab59ced7d  vmovaps [rsp+0x40], xmm4
000070bab59ced83  vmovaps [rsp+0x50], xmm5
000070bab59ced89  vmovaps [rsp+0x60], xmm6
000070bab59ced8f  vmovaps [rsp+0x70], xmm7
000070bab59ced95  vmovaps [rsp+0x80], xmm8
000070bab59ced9e  vmovaps [rsp+0x90], xmm9
000070bab59ceda7  vmovaps [rsp+0xA0], xmm10
000070bab59cedb0  vmovaps [rsp+0xB0], xmm11
000070bab59cedb9  vmovaps [rsp+0xC0], xmm12
000070bab59cedc2  vmovaps [rsp+0xD0], xmm14
000070bab59cedcb  vmovaps [rsp+0xE0], xmm15
000070bab59cedd4  sub rsp, 0x30
000070bab59cedd8  movaps [rsp], xmm13
000070bab59ceddd  movaps [rsp+0x10], xmm15
000070bab59cede3  movaps [rsp+0x20], xmm14
000070bab59cede9  lea rdi, [rsp]
000070bab59ceded  mov esi, 0x00
000070bab59cedf2  mov rax, 0x63B35AFBC530
000070bab59cedfc  call rax
000070bab59cedfe  movaps xmm13, [rsp]
000070bab59cee03  add rsp, 0x30
000070bab59cee07  vmovaps xmm0, [rsp]
000070bab59cee0c  vmovaps xmm1, [rsp+0x10]
000070bab59cee12  vmovaps xmm2, [rsp+0x20]
000070bab59cee18  vmovaps xmm3, [rsp+0x30]
000070bab59cee1e  vmovaps xmm4, [rsp+0x40]
000070bab59cee24  vmovaps xmm5, [rsp+0x50]
000070bab59cee2a  vmovaps xmm6, [rsp+0x60]
000070bab59cee30  vmovaps xmm7, [rsp+0x70]
000070bab59cee36  vmovaps xmm8, [rsp+0x80]
000070bab59cee3f  vmovaps xmm9, [rsp+0x90]
000070bab59cee48  vmovaps xmm10, [rsp+0xA0]
000070bab59cee51  vmovaps xmm11, [rsp+0xB0]
000070bab59cee5a  vmovaps xmm12, [rsp+0xC0]
000070bab59cee63  vmovaps xmm14, [rsp+0xD0]
000070bab59cee6c  vmovaps xmm15, [rsp+0xE0]
000070bab59cee75  add rsp, 0xF0
000070bab59cee7c  pop r11
000070bab59cee7e  pop r10
000070bab59cee80  pop r9
000070bab59cee82  pop r8
000070bab59cee84  pop rsi
000070bab59cee85  pop rdi
000070bab59cee86  pop rdx
000070bab59cee87  pop rcx
000070bab59cee88  pop rax
000070bab59cee89  add rsp, 0x08
000070bab59cee8d  jmp 0x000070BAB59CEC71
000070bab59cee92  call 0x000070BAB58C2240
000070bab59cee97  jmp 0x000070BAB59CEC8B
000070bab59cee9c  sub rsp, 0x08
000070bab59ceea0  push rax
000070bab59ceea1  push rcx
000070bab59ceea2  push rdx
000070bab59ceea3  push rdi
000070bab59ceea4  push rsi
000070bab59ceea5  push r8
000070bab59ceea7  push r9
000070bab59ceea9  push r10
000070bab59ceeab  push r11
000070bab59ceead  sub rsp, 0xF0
000070bab59ceeb4  vmovaps [rsp], xmm0
000070bab59ceeb9  vmovaps [rsp+0x10], xmm1
000070bab59ceebf  vmovaps [rsp+0x20], xmm2
000070bab59ceec5  vmovaps [rsp+0x30], xmm3
000070bab59ceecb  vmovaps [rsp+0x40], xmm4
000070bab59ceed1  vmovaps [rsp+0x50], xmm5
000070bab59ceed7  vmovaps [rsp+0x60], xmm6
000070bab59ceedd  vmovaps [rsp+0x70], xmm7
000070bab59ceee3  vmovaps [rsp+0x80], xmm8
000070bab59ceeec  vmovaps [rsp+0x90], xmm9
000070bab59ceef5  vmovaps [rsp+0xA0], xmm10
000070bab59ceefe  vmovaps [rsp+0xB0], xmm11
000070bab59cef07  vmovaps [rsp+0xC0], xmm12
000070bab59cef10  vmovaps [rsp+0xD0], xmm13
000070bab59cef19  vmovaps [rsp+0xE0], xmm15
000070bab59cef22  sub rsp, 0x30
000070bab59cef26  movaps [rsp], xmm14
000070bab59cef2b  movaps [rsp+0x10], xmm1
000070bab59cef30  movaps [rsp+0x20], xmm15
000070bab59cef36  lea rdi, [rsp]
000070bab59cef3a  mov esi, 0x00
000070bab59cef3f  mov rax, 0x63B35AFBC530
000070bab59cef49  call rax
000070bab59cef4b  movaps xmm14, [rsp]
000070bab59cef50  add rsp, 0x30
000070bab59cef54  vmovaps xmm0, [rsp]
000070bab59cef59  vmovaps xmm1, [rsp+0x10]
000070bab59cef5f  vmovaps xmm2, [rsp+0x20]
000070bab59cef65  vmovaps xmm3, [rsp+0x30]
000070bab59cef6b  vmovaps xmm4, [rsp+0x40]
000070bab59cef71  vmovaps xmm5, [rsp+0x50]
000070bab59cef77  vmovaps xmm6, [rsp+0x60]
000070bab59cef7d  vmovaps xmm7, [rsp+0x70]
000070bab59cef83  vmovaps xmm8, [rsp+0x80]
000070bab59cef8c  vmovaps xmm9, [rsp+0x90]
000070bab59cef95  vmovaps xmm10, [rsp+0xA0]
000070bab59cef9e  vmovaps xmm11, [rsp+0xB0]
000070bab59cefa7  vmovaps xmm12, [rsp+0xC0]
000070bab59cefb0  vmovaps xmm13, [rsp+0xD0]
000070bab59cefb9  vmovaps xmm15, [rsp+0xE0]
000070bab59cefc2  add rsp, 0xF0
000070bab59cefc9  pop r11
000070bab59cefcb  pop r10
000070bab59cefcd  pop r9
000070bab59cefcf  pop r8
000070bab59cefd1  pop rsi
000070bab59cefd2  pop rdi
000070bab59cefd3  pop rdx
000070bab59cefd4  pop rcx
000070bab59cefd5  pop rax
000070bab59cefd6  add rsp, 0x08
000070bab59cefda  jmp 0x000070BAB59CECAE
000070bab59cefdf  call 0x000070BAB58C34C0
000070bab59cefe4  jmp 0x000070BAB59CECC4
000070bab59cefe9  int3
000070bab59cefea  nop [rax+rax*1], ax
000070bab59ceff0  mov rax, [r15+0xF8]
000070bab59ceff7  lea r14, [rax-0x150]
000070bab59ceffe  mov [r15+0xF8], r14
000070bab59cf005  mov rax, [r15+0x50]
000070bab59cf009  lea r12, [rax+0x80]
000070bab59cf010  movups xmm1, [r13+r12*1]
000070bab59cf016  lea r12, [rax+0x90]
000070bab59cf01d  movups xmm15, [r13+r12*1]
000070bab59cf023  mov qword ptr [r15+0x48], 0x00
000070bab59cf02b  lea r12, [rax+0x40]
000070bab59cf02f  movups xmm14, [r13+r12*1]
000070bab59cf035  lea r12, [rax+0x50]
000070bab59cf039  movups xmm13, [r13+r12*1]
000070bab59cf03f  lea r12, [r14+0x120]
000070bab59cf046  movq xmm12, qword ptr [r15+0x1C0]
000070bab59cf04f  movq xmm11, qword ptr [r15+0x1B0]
000070bab59cf058  movq r11, xmm12
000070bab59cf05d  movq r10, xmm11
000070bab59cf062  mov [r13+r12*1], r11
000070bab59cf067  lea r12, [r14+0x128]
000070bab59cf06e  mov [r13+r12*1], r10
000070bab59cf073  vxorps xmm12, xmm12, xmm12
000070bab59cf078  vpbroadcastq xmm12, xmm12
000070bab59cf07d  lea r12, [r14+0x100]
000070bab59cf084  movq xmm11, qword ptr [r15+0x200]
000070bab59cf08d  movq xmm10, qword ptr [r15+0x1F0]
000070bab59cf096  movq r11, xmm11
000070bab59cf09b  movq r10, xmm10
000070bab59cf0a0  mov [r13+r12*1], r11
000070bab59cf0a5  lea r12, [r14+0x108]
000070bab59cf0ac  mov [r13+r12*1], r10
000070bab59cf0b1  lea r12, [r14+0xE0]
000070bab59cf0b8  movups [r13+r12*1], xmm15
000070bab59cf0be  lea r12, [r14+0xF0]
000070bab59cf0c5  movups [r13+r12*1], xmm1
000070bab59cf0cb  lea r12, [rax+0xC0]
000070bab59cf0d2  movups xmm1, [r13+r12*1]
000070bab59cf0d8  lea r12, [rax+0xD0]
000070bab59cf0df  movups xmm15, [r13+r12*1]
000070bab59cf0e5  lea r12, [r14+0x110]
000070bab59cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000070bab59cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000070bab59cf0fe  movq r11, xmm11
000070bab59cf103  movq r10, xmm10
000070bab59cf108  mov [r13+r12*1], r11
000070bab59cf10d  lea r12, [r14+0x118]
000070bab59cf114  mov [r13+r12*1], r10
000070bab59cf119  movups xmm11, [r13+rax*1]
000070bab59cf11f  lea r12, [rax+0x10]
000070bab59cf123  movups xmm10, [r13+r12*1]
000070bab59cf129  lea r12, [r14+0x130]
000070bab59cf130  movq xmm9, qword ptr [r15+0x1A0]
000070bab59cf139  movq xmm8, qword ptr [r15+0x190]
000070bab59cf142  movq r11, xmm9
000070bab59cf147  movq r10, xmm8
000070bab59cf14c  mov [r13+r12*1], r11
000070bab59cf151  lea r12, [r14+0x138]
000070bab59cf158  mov [r13+r12*1], r10
000070bab59cf15d  lea r12, [rax+0x140]
000070bab59cf164  movups xmm9, [r13+r12*1]
000070bab59cf16a  lea r12, [rax+0x150]
000070bab59cf171  movups xmm8, [r13+r12*1]
000070bab59cf177  lea r12, [r14+0xC0]
000070bab59cf17e  movups [r13+r12*1], xmm15
000070bab59cf184  lea r12, [r14+0xD0]
000070bab59cf18b  movups [r13+r12*1], xmm1
000070bab59cf191  lea r12, [rax+0x100]
000070bab59cf198  movups xmm1, [r13+r12*1]
000070bab59cf19e  lea r12, [rax+0x110]
000070bab59cf1a5  movups xmm15, [r13+r12*1]
000070bab59cf1ab  lea r12, [r14+0x140]
000070bab59cf1b2  mov r11, [r15+0xE8]
000070bab59cf1b9  mov [r13+r12*1], r11
000070bab59cf1be  lea r12, [rax+0x180]
000070bab59cf1c5  movups xmm7, [r13+r12*1]
000070bab59cf1cb  lea r12, [rax+0x190]
000070bab59cf1d2  movups xmm6, [r13+r12*1]
000070bab59cf1d8  lea r12, [rax+0x1C0]
000070bab59cf1df  movups xmm5, [r13+r12*1]
000070bab59cf1e5  lea r12, [rax+0x1D0]
000070bab59cf1ec  movups xmm4, [r13+r12*1]
000070bab59cf1f2  lea r12, [r14+0x20]
000070bab59cf1f6  movups [r13+r12*1], xmm1
000070bab59cf1fc  lea r12, [r14+0x30]
000070bab59cf200  movups [r13+r12*1], xmm13
000070bab59cf206  lea r12, [rax+0x60]
000070bab59cf20a  movups xmm1, [r13+r12*1]
000070bab59cf210  lea r12, [rax+0x70]
000070bab59cf214  movups xmm13, [r13+r12*1]
000070bab59cf21a  lea r12, [rax+0x20]
000070bab59cf21e  movups xmm3, [r13+r12*1]
000070bab59cf224  lea r12, [rax+0x30]
000070bab59cf228  movups xmm2, [r13+r12*1]
000070bab59cf22e  movaps [r15+0x1F0], xmm2
000070bab59cf236  lea r12, [r14+0x60]
000070bab59cf23a  movups [r13+r12*1], xmm11
000070bab59cf240  lea r12, [r14+0x70]
000070bab59cf244  movups [r13+r12*1], xmm5
000070bab59cf24a  lea r12, [rax+0xE0]
000070bab59cf251  movups xmm11, [r13+r12*1]
000070bab59cf257  lea r12, [rax+0xF0]
000070bab59cf25e  movups xmm5, [r13+r12*1]
000070bab59cf264  lea r12, [r14+0xA0]
000070bab59cf26b  movups [r13+r12*1], xmm13
000070bab59cf271  lea r12, [r14+0xB0]
000070bab59cf278  movups [r13+r12*1], xmm1
000070bab59cf27e  lea r12, [rax+0xA0]
000070bab59cf285  movups xmm1, [r13+r12*1]
000070bab59cf28b  lea r12, [rax+0xB0]
000070bab59cf292  movups xmm13, [r13+r12*1]
000070bab59cf298  lea r12, [rax+0x120]
000070bab59cf29f  vmovaps [rsp+0x10], xmm1
000070bab59cf2a5  movups xmm1, [r13+r12*1]
000070bab59cf2ab  lea r12, [rax+0x130]
000070bab59cf2b2  vmovaps [rsp+0x20], xmm1
000070bab59cf2b8  movups xmm1, [r13+r12*1]
000070bab59cf2be  lea r12, [rax+0x160]
000070bab59cf2c5  vmovaps [rsp+0x30], xmm1
000070bab59cf2cb  movups xmm1, [r13+r12*1]
000070bab59cf2d1  lea r12, [rax+0x170]
000070bab59cf2d8  vmovaps [rsp+0x40], xmm1
000070bab59cf2de  movups xmm1, [r13+r12*1]
000070bab59cf2e4  movaps [r15+0x2B0], xmm1
000070bab59cf2ec  lea r12, [r14+0x80]
000070bab59cf2f3  movups [r13+r12*1], xmm13
000070bab59cf2f9  lea r12, [r14+0x90]
000070bab59cf300  vmovaps xmm13, [rsp+0x10]
000070bab59cf306  movups [r13+r12*1], xmm13
000070bab59cf30c  lea r12, [rax+0x1A0]
000070bab59cf313  movups xmm13, [r13+r12*1]
000070bab59cf319  lea r12, [rax+0x1B0]
000070bab59cf320  vmovaps [rsp+0x10], xmm1
000070bab59cf326  movups xmm1, [r13+r12*1]
000070bab59cf32c  movaps [r15+0x290], xmm13
000070bab59cf334  movaps [r15+0x1E0], xmm1
000070bab59cf33c  lea r12, [rax+0x1E0]
000070bab59cf343  vmovaps [rsp+0x50], xmm1
000070bab59cf349  movups xmm1, [r13+r12*1]
000070bab59cf34f  lea r12, [rax+0x1F0]
000070bab59cf356  vmovaps [rsp+0x60], xmm1
000070bab59cf35c  movups xmm1, [r13+r12*1]
000070bab59cf362  mov qword ptr [r15+0x50], 0x430920
000070bab59cf36a  lea rax, [r14+0x40]
000070bab59cf36e  vmovaps [rsp+0x70], xmm1
000070bab59cf374  vmovaps xmm1, [rsp+0x40]
000070bab59cf37a  movups [r13+rax*1], xmm1
000070bab59cf380  lea rax, [r14+0x50]
000070bab59cf384  movups [r13+rax*1], xmm10
000070bab59cf38a  vmovaps xmm1, [rsp+0x70]
000070bab59cf390  movups [r13+r14*1], xmm1
000070bab59cf396  lea rax, [r14+0x10]
000070bab59cf39a  vmovaps xmm1, [rsp+0x60]
000070bab59cf3a0  movups [r13+rax*1], xmm1
000070bab59cf3a6  mov rax, [r15+0x40]
000070bab59cf3aa  vmovaps [rsp+0x40], xmm3
000070bab59cf3b0  vmovaps xmm1, [rsp+0x40]
000070bab59cf3b6  por xmm3, xmm1
000070bab59cf3ba  vmovaps [rsp+0x40], xmm6
000070bab59cf3c0  vmovaps xmm10, [rsp+0x40]
000070bab59cf3c6  por xmm6, xmm10
000070bab59cf3cb  lea r12, [rax+0x30]
000070bab59cf3cf  mov r11, [r13+r12*1]
000070bab59cf3d4  lea r12, [rax+0x38]
000070bab59cf3d8  mov r10, [r13+r12*1]
000070bab59cf3dd  movq xmm10, r11
000070bab59cf3e2  vmovaps [rsp+0x40], xmm1
000070bab59cf3e8  movq xmm1, r10
000070bab59cf3ed  movq xmm10, xmm10
000070bab59cf3f2  vmovaps [rsp+0x60], xmm10
000070bab59cf3f8  movq xmm10, xmm10
000070bab59cf3fd  movaps [r15+0x130], xmm10
000070bab59cf405  movq xmm1, xmm1
000070bab59cf409  vmovaps [rsp+0x70], xmm1
000070bab59cf40f  movq xmm1, xmm1
000070bab59cf413  movaps [r15+0x280], xmm1
000070bab59cf41b  vmovaps [rsp+0x80], xmm9
000070bab59cf424  vmovaps xmm1, [rsp+0x80]
000070bab59cf42d  por xmm9, xmm1
000070bab59cf432  lea r12, [rax+0x20]
000070bab59cf436  mov r11, [r13+r12*1]
000070bab59cf43b  lea r12, [rax+0x28]
000070bab59cf43f  mov r10, [r13+r12*1]
000070bab59cf444  movq xmm1, r11
000070bab59cf449  movq xmm10, r10
000070bab59cf44e  movq xmm1, xmm1
000070bab59cf452  vmovaps [rsp+0x80], xmm1
000070bab59cf45b  movq xmm1, xmm1
000070bab59cf45f  movaps [r15+0x150], xmm1
000070bab59cf467  movq xmm10, xmm10
000070bab59cf46c  vmovaps [rsp+0x90], xmm10
000070bab59cf475  movq xmm10, xmm10
000070bab59cf47a  movaps [r15+0x140], xmm10
000070bab59cf482  lea r12, [rax+0x10]
000070bab59cf486  mov r11, [r13+r12*1]
000070bab59cf48b  lea r12, [rax+0x18]
000070bab59cf48f  mov r10, [r13+r12*1]
000070bab59cf494  movq xmm1, r11
000070bab59cf499  movq xmm10, r10
000070bab59cf49e  movq xmm1, xmm1
000070bab59cf4a2  vmovaps [rsp+0xA0], xmm1
000070bab59cf4ab  movq xmm1, xmm1
000070bab59cf4af  movaps [r15+0x170], xmm1
000070bab59cf4b7  movq xmm10, xmm10
000070bab59cf4bc  vmovaps [rsp+0xB0], xmm10
000070bab59cf4c5  movq xmm10, xmm10
000070bab59cf4ca  movaps [r15+0x160], xmm10
000070bab59cf4d2  mov r12, [r13+rax*1]
000070bab59cf4d7  vmovq xmm1, r12
000070bab59cf4dc  vpbroadcastq xmm1, xmm1
000070bab59cf4e1  lea r12, [rax+0x08]
000070bab59cf4e5  mov rax, [r13+r12*1]
000070bab59cf4ea  movq xmm10, rax
000070bab59cf4ef  movaps [r15+0x230], xmm10
000070bab59cf4f7  lea rax, [r14+0x50]
000070bab59cf4fb  movups xmm10, [r13+rax*1]
000070bab59cf501  lea rax, [r14+0x60]
000070bab59cf505  vmovaps [rsp+0xC0], xmm1
000070bab59cf50e  movups xmm1, [r13+rax*1]
000070bab59cf514  lea rax, [r14+0x30]
000070bab59cf518  vmovaps [rsp+0xD0], xmm1
000070bab59cf521  movups xmm1, [r13+rax*1]
000070bab59cf527  mov qword ptr [r15+0x60], 0x430920
000070bab59cf52f  mov qword ptr [r15+0x58], 0x40
000070bab59cf537  vmovaps [rsp+0xE0], xmm1
000070bab59cf540  vmovaps [rsp+0xF0], xmm15
000070bab59cf549  vmovaps xmm15, [rsp+0xC0]
000070bab59cf552  vmovaps [rsp+0xC0], xmm14
000070bab59cf55b  vmovaps xmm14, [rsp+0x40]
000070bab59cf561  vmovaps [rsp+0x40], xmm13
000070bab59cf567  movaps xmm1, xmm15
000070bab59cf56b  mulpd xmm1, xmm14
000070bab59cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000070bab59cf575  ptest xmm13, xmm13
000070bab59cf57b  jnz 0x000070BAB59D0682
000070bab59cf581  movq xmm14, qword ptr [r15+0x230]
000070bab59cf58a  vmovaps [rsp+0x100], xmm14
000070bab59cf593  vpermilpd xmm14, xmm14, 0x00
000070bab59cf599  vmovaps [rsp+0x110], xmm1
000070bab59cf5a2  vmovaps xmm1, [rsp+0xE0]
000070bab59cf5ab  vmovaps [rsp+0xE0], xmm15
000070bab59cf5b4  movaps xmm13, xmm1
000070bab59cf5b8  mulpd xmm13, xmm14
000070bab59cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000070bab59cf5c3  ptest xmm15, xmm15
000070bab59cf5c9  jnz 0x000070BAB59D07C4
000070bab59cf5cf  vxorps xmm1, xmm1, xmm1
000070bab59cf5d3  vpbroadcastq xmm1, xmm1
000070bab59cf5d8  vmovaps xmm14, [rsp+0xE0]
000070bab59cf5e1  vmovaps [rsp+0xE0], xmm1
000070bab59cf5ea  vmovaps xmm1, [rsp+0xD0]
000070bab59cf5f3  vmovaps [rsp+0xD0], xmm13
000070bab59cf5fc  movaps xmm15, xmm14
000070bab59cf600  mulpd xmm15, xmm1
000070bab59cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000070bab59cf60b  ptest xmm13, xmm13
000070bab59cf611  jnz 0x000070BAB59D0907
000070bab59cf617  movaps xmm1, xmm14
000070bab59cf61b  mulpd xmm1, xmm10
000070bab59cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000070bab59cf625  ptest xmm13, xmm13
000070bab59cf62b  jnz 0x000070BAB59D0A4A
000070bab59cf631  movaps xmm13, xmm14
000070bab59cf635  mulpd xmm13, xmm2
000070bab59cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000070bab59cf640  ptest xmm10, xmm10
000070bab59cf646  jnz 0x000070BAB59D0B8C
000070bab59cf64c  vmovaps [rsp+0x120], xmm7
000070bab59cf655  vmovaps xmm14, [rsp+0x120]
000070bab59cf65e  por xmm7, xmm14
000070bab59cf663  vmovaps xmm14, [rsp+0xC0]
000070bab59cf66c  vmovaps xmm10, [rsp+0xC0]
000070bab59cf675  por xmm14, xmm10
000070bab59cf67a  vmovaps xmm2, [rsp+0x100]
000070bab59cf683  vpermilpd xmm2, xmm2, 0x00
000070bab59cf689  vmovaps [rsp+0xC0], xmm1
000070bab59cf692  vmovaps [rsp+0x120], xmm15
000070bab59cf69b  movaps xmm1, xmm10
000070bab59cf69f  mulpd xmm1, xmm2
000070bab59cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000070bab59cf6a8  ptest xmm15, xmm15
000070bab59cf6ae  jnz 0x000070BAB59D0CCF
000070bab59cf6b4  xor eax, eax
000070bab59cf6b6  mov r12d, 0x40
000070bab59cf6bc  mov r11d, 0x200
000070bab59cf6c2  cmp r12, r11
000070bab59cf6c5  cmc
000070bab59cf6c6  lahf
000070bab59cf6c7  seto al
000070bab59cf6ca  mov [r15+0x108], eax
000070bab59cf6d1  vmovaps xmm10, [rsp+0x110]
000070bab59cf6da  vmovaps xmm2, [rsp+0xE0]
000070bab59cf6e3  vmovaps [rsp+0xE0], xmm1
000070bab59cf6ec  movaps xmm15, xmm10
000070bab59cf6f0  addpd xmm15, xmm2
000070bab59cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000070bab59cf6fb  ptest xmm1, xmm1
000070bab59cf700  jnz 0x000070BAB59D0E10
000070bab59cf706  vmovaps xmm10, [rsp+0x120]
000070bab59cf70f  vmovaps [rsp+0x110], xmm15
000070bab59cf718  movaps xmm1, xmm10
000070bab59cf71c  addpd xmm1, xmm12
000070bab59cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000070bab59cf726  ptest xmm15, xmm15
000070bab59cf72c  jnz 0x000070BAB59D0F53
000070bab59cf732  vmovaps xmm10, [rsp+0xC0]
000070bab59cf73b  vmovaps [rsp+0xC0], xmm1
000070bab59cf744  movaps xmm15, xmm10
000070bab59cf748  addpd xmm15, xmm12
000070bab59cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000070bab59cf753  ptest xmm1, xmm1
000070bab59cf758  jnz 0x000070BAB59D1095
000070bab59cf75e  vmovaps xmm1, [rsp+0x30]
000070bab59cf764  vmovaps xmm12, [rsp+0x30]
000070bab59cf76a  por xmm1, xmm12
000070bab59cf76f  vmovaps xmm12, [rsp+0x20]
000070bab59cf775  vmovaps xmm10, [rsp+0x20]
000070bab59cf77b  por xmm12, xmm10
000070bab59cf780  vmovaps [rsp+0x20], xmm5
000070bab59cf786  vmovaps xmm10, [rsp+0x20]
000070bab59cf78c  por xmm5, xmm10
000070bab59cf791  vmovaps [rsp+0x20], xmm11
000070bab59cf797  vmovaps xmm10, [rsp+0x20]
000070bab59cf79d  por xmm11, xmm10
000070bab59cf7a2  vmovaps [rsp+0x20], xmm4
000070bab59cf7a8  vmovaps xmm10, [rsp+0x20]
000070bab59cf7ae  por xmm4, xmm10
000070bab59cf7b3  vmovaps [rsp+0x20], xmm8
000070bab59cf7b9  vmovaps xmm10, [rsp+0x20]
000070bab59cf7bf  por xmm8, xmm10
000070bab59cf7c4  vmovaps xmm10, [rsp+0xF0]
000070bab59cf7cd  vmovaps [rsp+0x20], xmm1
000070bab59cf7d3  vmovaps xmm1, [rsp+0xF0]
000070bab59cf7dc  por xmm10, xmm1
000070bab59cf7e1  lea rax, [r14+0xA0]
000070bab59cf7e8  movups xmm1, [r13+rax*1]
000070bab59cf7ee  lea rax, [r14+0xB0]
000070bab59cf7f5  vmovaps [rsp+0x30], xmm1
000070bab59cf7fb  movups xmm1, [r13+rax*1]
000070bab59cf801  vmovaps [rsp+0xF0], xmm1
000070bab59cf80a  vmovaps [rsp+0x120], xmm15
000070bab59cf813  movaps xmm1, xmm13
000070bab59cf817  addpd xmm1, xmm2
000070bab59cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000070bab59cf820  ptest xmm15, xmm15
000070bab59cf826  jnz 0x000070BAB59D11ED
000070bab59cf82c  lea rax, [r14+0xF0]
000070bab59cf833  movups xmm15, [r13+rax*1]
000070bab59cf839  vmovaps xmm2, [rsp+0xC0]
000070bab59cf842  vmovaps [rsp+0xC0], xmm1
000070bab59cf84b  vmovaps xmm1, [rsp+0xE0]
000070bab59cf854  vmovaps [rsp+0xE0], xmm15
000070bab59cf85d  movaps xmm13, xmm2
000070bab59cf861  addpd xmm13, xmm1
000070bab59cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000070bab59cf86c  ptest xmm15, xmm15
000070bab59cf872  jnz 0x000070BAB59D1338
000070bab59cf878  vmovaps xmm15, [rsp+0x120]
000070bab59cf881  vmovaps xmm2, [rsp+0xD0]
000070bab59cf88a  vmovaps [rsp+0xD0], xmm14
000070bab59cf893  movaps xmm1, xmm15
000070bab59cf897  addpd xmm1, xmm2
000070bab59cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000070bab59cf8a0  ptest xmm14, xmm14
000070bab59cf8a6  jnz 0x000070BAB59D147A
000070bab59cf8ac  vmovaps xmm15, [rsp+0x100]
000070bab59cf8b5  vpermilpd xmm15, xmm15, 0x00
000070bab59cf8bb  vmovaps xmm2, [rsp+0xF0]
000070bab59cf8c4  vmovaps [rsp+0xF0], xmm1
000070bab59cf8cd  movaps xmm14, xmm2
000070bab59cf8d1  mulpd xmm14, xmm15
000070bab59cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000070bab59cf8dc  ptest xmm1, xmm1
000070bab59cf8e1  jnz 0x000070BAB59D15BB
000070bab59cf8e7  vmovaps xmm1, [rsp+0xA0]
000070bab59cf8f0  vpermilpd xmm1, xmm1, 0x00
000070bab59cf8f6  vmovaps xmm2, [rsp+0xE0]
000070bab59cf8ff  vmovaps [rsp+0xE0], xmm14
000070bab59cf908  movaps xmm15, xmm2
000070bab59cf90c  mulpd xmm15, xmm1
000070bab59cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000070bab59cf917  ptest xmm14, xmm14
000070bab59cf91d  jnz 0x000070BAB59D16FE
000070bab59cf923  lea rax, [r14+0xE0]
000070bab59cf92a  movups xmm1, [r13+rax*1]
000070bab59cf930  vmovaps xmm14, [rsp+0x100]
000070bab59cf939  vpermilpd xmm14, xmm14, 0x00
000070bab59cf93f  vmovaps [rsp+0x100], xmm1
000070bab59cf948  vmovaps xmm1, [rsp+0x30]
000070bab59cf94e  vmovaps [rsp+0x30], xmm15
000070bab59cf954  movaps xmm2, xmm1
000070bab59cf957  mulpd xmm2, xmm14
000070bab59cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000070bab59cf961  ptest xmm15, xmm15
000070bab59cf967  jnz 0x000070BAB59D184A
000070bab59cf96d  vmovaps [rsp+0x120], xmm10
000070bab59cf976  vmovaps xmm1, [rsp+0x120]
000070bab59cf97f  por xmm10, xmm1
000070bab59cf984  movaps [r15+0x300], xmm10
000070bab59cf98c  vmovaps [rsp+0x120], xmm8
000070bab59cf995  vmovaps xmm1, [rsp+0x120]
000070bab59cf99e  por xmm8, xmm1
000070bab59cf9a3  movaps [r15+0x190], xmm8
000070bab59cf9ab  vmovaps xmm1, [rsp+0xA0]
000070bab59cf9b4  vpermilpd xmm1, xmm1, 0x00
000070bab59cf9ba  vmovaps xmm14, [rsp+0x100]
000070bab59cf9c3  vmovaps [rsp+0x100], xmm13
000070bab59cf9cc  movaps xmm15, xmm14
000070bab59cf9d0  mulpd xmm15, xmm1
000070bab59cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000070bab59cf9db  ptest xmm13, xmm13
000070bab59cf9e1  jnz 0x000070BAB59D198B
000070bab59cf9e7  lea rax, [r14+0x90]
000070bab59cf9ee  movups xmm1, [r13+rax*1]
000070bab59cf9f4  vmovaps [rsp+0x120], xmm4
000070bab59cf9fd  vmovaps xmm14, [rsp+0x120]
000070bab59cfa06  por xmm4, xmm14
000070bab59cfa0b  movaps [r15+0x1C0], xmm4
000070bab59cfa13  vmovaps [rsp+0x120], xmm11
000070bab59cfa1c  vmovaps xmm14, [rsp+0x120]
000070bab59cfa25  por xmm11, xmm14
000070bab59cfa2a  movaps [r15+0x200], xmm11
000070bab59cfa32  vmovaps [rsp+0x120], xmm5
000070bab59cfa3b  vmovaps xmm14, [rsp+0x120]
000070bab59cfa44  por xmm5, xmm14
000070bab59cfa49  movaps [r15+0x2D0], xmm5
000070bab59cfa51  vmovaps [rsp+0x120], xmm12
000070bab59cfa5a  vmovaps xmm14, [rsp+0x120]
000070bab59cfa63  por xmm12, xmm14
000070bab59cfa68  movaps [r15+0x2E0], xmm12
000070bab59cfa70  vmovaps xmm13, [rsp+0x110]
000070bab59cfa79  vmovaps [rsp+0x110], xmm1
000070bab59cfa82  vmovaps xmm1, [rsp+0xE0]
000070bab59cfa8b  vmovaps [rsp+0xE0], xmm15
000070bab59cfa94  movaps xmm14, xmm13
000070bab59cfa98  addpd xmm14, xmm1
000070bab59cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000070bab59cfaa3  ptest xmm15, xmm15
000070bab59cfaa9  jnz 0x000070BAB59D1AD8
000070bab59cfaaf  vmovaps xmm1, [rsp+0xA0]
000070bab59cfab8  vpermilpd xmm1, xmm1, 0x00
000070bab59cfabe  vmovaps xmm13, [rsp+0x110]
000070bab59cfac7  vmovaps [rsp+0x110], xmm14
000070bab59cfad0  movaps xmm15, xmm13
000070bab59cfad4  mulpd xmm15, xmm1
000070bab59cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000070bab59cfadf  ptest xmm14, xmm14
000070bab59cfae5  jnz 0x000070BAB59D1C1B
000070bab59cfaeb  lea rax, [r14+0x80]
000070bab59cfaf2  movups xmm1, [r13+rax*1]
000070bab59cfaf8  vmovaps xmm13, [rsp+0xC0]
000070bab59cfb01  vmovaps [rsp+0xC0], xmm1
000070bab59cfb0a  movaps xmm14, xmm13
000070bab59cfb0e  addpd xmm14, xmm2
000070bab59cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000070bab59cfb19  ptest xmm1, xmm1
000070bab59cfb1e  jnz 0x000070BAB59D1D68
000070bab59cfb24  vmovaps xmm13, [rsp+0x100]
000070bab59cfb2d  vmovaps xmm2, [rsp+0x30]
000070bab59cfb33  vmovaps [rsp+0x30], xmm15
000070bab59cfb39  movaps xmm1, xmm13
000070bab59cfb3d  addpd xmm1, xmm2
000070bab59cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000070bab59cfb46  ptest xmm15, xmm15
000070bab59cfb4c  jnz 0x000070BAB59D1EAB
000070bab59cfb52  vmovaps xmm15, [rsp+0x20]
000070bab59cfb58  vmovaps xmm13, [rsp+0x20]
000070bab59cfb5e  por xmm15, xmm13
000070bab59cfb63  movaps [r15+0x2F0], xmm15
000070bab59cfb6b  vmovaps xmm13, [rsp+0xA0]
000070bab59cfb74  vpermilpd xmm13, xmm13, 0x00
000070bab59cfb7a  vmovaps [rsp+0x20], xmm1
000070bab59cfb80  vmovaps xmm1, [rsp+0xC0]
000070bab59cfb89  vmovaps [rsp+0xA0], xmm15
000070bab59cfb92  movaps xmm2, xmm1
000070bab59cfb95  mulpd xmm2, xmm13
000070bab59cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000070bab59cfb9f  ptest xmm15, xmm15
000070bab59cfba5  jnz 0x000070BAB59D1FEC
000070bab59cfbab  lea rax, [r14+0xD0]
000070bab59cfbb2  movups xmm1, [r13+rax*1]
000070bab59cfbb8  vmovaps xmm13, [rsp+0xF0]
000070bab59cfbc1  vmovaps [rsp+0xC0], xmm1
000070bab59cfbca  vmovaps xmm1, [rsp+0xE0]
000070bab59cfbd3  vmovaps [rsp+0xE0], xmm14
000070bab59cfbdc  movaps xmm15, xmm13
000070bab59cfbe0  addpd xmm15, xmm1
000070bab59cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000070bab59cfbeb  ptest xmm14, xmm14
000070bab59cfbf1  jnz 0x000070BAB59D2137
000070bab59cfbf7  vmovaps xmm1, [rsp+0xB0]
000070bab59cfc00  vpermilpd xmm1, xmm1, 0x00
000070bab59cfc06  movaps xmm14, xmm11
000070bab59cfc0a  mulpd xmm14, xmm1
000070bab59cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000070bab59cfc15  ptest xmm13, xmm13
000070bab59cfc1b  jnz 0x000070BAB59D227A
000070bab59cfc21  movaps [r15+0x260], xmm14
000070bab59cfc29  vxorps xmm1, xmm1, xmm1
000070bab59cfc2d  vpbroadcastq xmm1, xmm1
000070bab59cfc32  movaps [r15+0x1B0], xmm1
000070bab59cfc3a  vmovaps xmm1, [rsp+0xB0]
000070bab59cfc43  vpermilpd xmm1, xmm1, 0x00
000070bab59cfc49  vmovaps xmm11, [rsp+0xC0]
000070bab59cfc52  vmovaps [rsp+0xC0], xmm15
000070bab59cfc5b  movaps xmm13, xmm11
000070bab59cfc5f  mulpd xmm13, xmm1
000070bab59cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000070bab59cfc6a  ptest xmm15, xmm15
000070bab59cfc70  jnz 0x000070BAB59D23BD
000070bab59cfc76  lea rax, [r14+0xC0]
000070bab59cfc7d  movups xmm1, [r13+rax*1]
000070bab59cfc83  vmovaps xmm11, [rsp+0x110]
000070bab59cfc8c  vmovaps [rsp+0xF0], xmm1
000070bab59cfc95  vmovaps xmm1, [rsp+0x30]
000070bab59cfc9b  vmovaps [rsp+0x30], xmm14
000070bab59cfca1  movaps xmm15, xmm11
000070bab59cfca5  addpd xmm15, xmm1
000070bab59cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000070bab59cfcb0  ptest xmm14, xmm14
000070bab59cfcb6  jnz 0x000070BAB59D250A
000070bab59cfcbc  vmovaps [rsp+0x100], xmm9
000070bab59cfcc5  vmovaps xmm1, [rsp+0x100]
000070bab59cfcce  por xmm9, xmm1
000070bab59cfcd3  movaps [r15+0x270], xmm9
000070bab59cfcdb  vmovaps [rsp+0x100], xmm6
000070bab59cfce4  vmovaps xmm1, [rsp+0x100]
000070bab59cfced  por xmm6, xmm1
000070bab59cfcf1  movaps [r15+0x1A0], xmm6
000070bab59cfcf9  vmovaps xmm14, [rsp+0xB0]
000070bab59cfd02  vpermilpd xmm14, xmm14, 0x00
000070bab59cfd08  vmovaps xmm6, [rsp+0xF0]
000070bab59cfd11  vmovaps [rsp+0xF0], xmm1
000070bab59cfd1a  movaps xmm11, xmm6
000070bab59cfd1e  mulpd xmm11, xmm14
000070bab59cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000070bab59cfd29  ptest xmm1, xmm1
000070bab59cfd2e  jnz 0x000070BAB59D264D
000070bab59cfd34  lea rax, [r14+0x20]
000070bab59cfd38  movups xmm1, [r13+rax*1]
000070bab59cfd3e  movaps [r15+0x110], xmm1
000070bab59cfd46  vmovaps xmm6, [rsp+0xE0]
000070bab59cfd4f  vmovaps [rsp+0xE0], xmm1
000070bab59cfd58  movaps xmm14, xmm6
000070bab59cfd5c  addpd xmm14, xmm2
000070bab59cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000070bab59cfd67  ptest xmm1, xmm1
000070bab59cfd6c  jnz 0x000070BAB59D279A
000070bab59cfd72  vmovaps xmm1, [rsp+0xB0]
000070bab59cfd7b  vpermilpd xmm1, xmm1, 0x00
000070bab59cfd81  movaps xmm6, xmm5
000070bab59cfd84  mulpd xmm6, xmm1
000070bab59cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000070bab59cfd8d  ptest xmm2, xmm2
000070bab59cfd92  jnz 0x000070BAB59D28DC
000070bab59cfd98  vmovaps xmm5, [rsp+0x20]
000070bab59cfd9e  movaps xmm1, xmm5
000070bab59cfda1  addpd xmm1, xmm13
000070bab59cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000070bab59cfdab  ptest xmm2, xmm2
000070bab59cfdb0  jnz 0x000070BAB59D2A1C
000070bab59cfdb6  vmovaps xmm13, [rsp+0x80]
000070bab59cfdbf  vpermilpd xmm13, xmm13, 0x00
000070bab59cfdc5  vmovaps xmm2, [rsp+0xE0]
000070bab59cfdce  vmovaps [rsp+0x20], xmm1
000070bab59cfdd4  movaps xmm5, xmm2
000070bab59cfdd7  mulpd xmm5, xmm13
000070bab59cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000070bab59cfde1  ptest xmm1, xmm1
000070bab59cfde6  jnz 0x000070BAB59D2B5D
000070bab59cfdec  vmovaps xmm1, [rsp+0x80]
000070bab59cfdf5  vpermilpd xmm1, xmm1, 0x00
000070bab59cfdfb  movaps xmm13, xmm10
000070bab59cfdff  mulpd xmm13, xmm1
000070bab59cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000070bab59cfe0a  ptest xmm2, xmm2
000070bab59cfe0f  jnz 0x000070BAB59D2C9E
000070bab59cfe15  vmovaps xmm10, [rsp+0x30]
000070bab59cfe1b  movaps xmm1, xmm15
000070bab59cfe1f  addpd xmm1, xmm10
000070bab59cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000070bab59cfe29  ptest xmm2, xmm2
000070bab59cfe2e  jnz 0x000070BAB59D2DE1
000070bab59cfe34  vmovaps xmm10, [rsp+0xC0]
000070bab59cfe3d  movaps xmm15, xmm10
000070bab59cfe41  addpd xmm15, xmm11
000070bab59cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000070bab59cfe4c  ptest xmm2, xmm2
000070bab59cfe51  jnz 0x000070BAB59D2F23
000070bab59cfe57  vmovaps xmm11, [rsp+0x80]
000070bab59cfe60  vpermilpd xmm11, xmm11, 0x00
000070bab59cfe66  movaps xmm10, xmm12
000070bab59cfe6a  mulpd xmm10, xmm11
000070bab59cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000070bab59cfe75  ptest xmm2, xmm2
000070bab59cfe7a  jnz 0x000070BAB59D3067
000070bab59cfe80  vmovaps xmm12, [rsp+0x80]
000070bab59cfe89  vpermilpd xmm12, xmm12, 0x00
000070bab59cfe8f  vmovaps xmm2, [rsp+0xA0]
000070bab59cfe98  vmovaps [rsp+0x30], xmm1
000070bab59cfe9e  movaps xmm11, xmm2
000070bab59cfea2  mulpd xmm11, xmm12
000070bab59cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000070bab59cfead  ptest xmm1, xmm1
000070bab59cfeb2  jnz 0x000070BAB59D31AB
000070bab59cfeb8  movaps xmm1, xmm14
000070bab59cfebc  addpd xmm1, xmm6
000070bab59cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000070bab59cfec5  ptest xmm12, xmm12
000070bab59cfecb  jnz 0x000070BAB59D32EE
000070bab59cfed1  vmovaps xmm12, [rsp+0x20]
000070bab59cfed7  movaps xmm14, xmm12
000070bab59cfedb  addpd xmm14, xmm5
000070bab59cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000070bab59cfee6  ptest xmm6, xmm6
000070bab59cfeeb  jnz 0x000070BAB59D342F
000070bab59cfef1  vmovaps xmm12, [rsp+0x90]
000070bab59cfefa  vpermilpd xmm12, xmm12, 0x00
000070bab59cff00  movaps xmm6, xmm9
000070bab59cff04  mulpd xmm6, xmm12
000070bab59cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000070bab59cff0e  ptest xmm5, xmm5
000070bab59cff13  jnz 0x000070BAB59D3572
000070bab59cff19  movaps xmm12, xmm15
000070bab59cff1d  addpd xmm12, xmm13
000070bab59cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000070bab59cff28  ptest xmm9, xmm9
000070bab59cff2e  jnz 0x000070BAB59D36B4
000070bab59cff34  vmovaps xmm13, [rsp+0x30]
000070bab59cff3a  movaps xmm15, xmm13
000070bab59cff3e  addpd xmm15, xmm10
000070bab59cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000070bab59cff49  ptest xmm9, xmm9
000070bab59cff4f  jnz 0x000070BAB59D37F8
000070bab59cff55  vmovaps xmm13, [rsp+0xD0]
000070bab59cff5e  vmovaps xmm10, [rsp+0xD0]
000070bab59cff67  por xmm13, xmm10
000070bab59cff6c  movaps [r15+0x250], xmm13
000070bab59cff74  vmovaps [rsp+0x20], xmm7
000070bab59cff7a  vmovaps xmm13, [rsp+0x20]
000070bab59cff80  por xmm7, xmm13
000070bab59cff85  movaps [r15+0x2A0], xmm7
000070bab59cff8d  vmovaps [rsp+0x20], xmm3
000070bab59cff93  vmovaps xmm13, [rsp+0x20]
000070bab59cff99  por xmm3, xmm13
000070bab59cff9e  movaps [r15+0x1D0], xmm3
000070bab59cffa6  lea rax, [r14+0x40]
000070bab59cffaa  movups xmm13, [r13+rax*1]
000070bab59cffb0  movaps [r15+0x2C0], xmm13
000070bab59cffb8  vmovaps xmm10, [rsp+0x90]
000070bab59cffc1  vpermilpd xmm10, xmm10, 0x00
000070bab59cffc7  movaps xmm9, xmm8
000070bab59cffcb  mulpd xmm9, xmm10
000070bab59cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000070bab59cffd6  ptest xmm5, xmm5
000070bab59cffdb  jnz 0x000070BAB59D3946
000070bab59cffe1  movaps xmm10, xmm1
000070bab59cffe5  addpd xmm10, xmm11
000070bab59cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000070bab59cfff0  ptest xmm8, xmm8
000070bab59cfff6  jnz 0x000070BAB59D3A8A
000070bab59cfffc  movaps xmm1, xmm14
000070bab59d0000  addpd xmm1, xmm6
000070bab59d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000070bab59d0009  ptest xmm11, xmm11
000070bab59d000f  jnz 0x000070BAB59D3BCD
000070bab59d0015  vmovaps xmm14, [rsp+0x90]
000070bab59d001e  vpermilpd xmm14, xmm14, 0x00
000070bab59d0024  movaps xmm11, xmm13
000070bab59d0028  mulpd xmm11, xmm14
000070bab59d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000070bab59d0033  ptest xmm8, xmm8
000070bab59d0039  jnz 0x000070BAB59D3D0E
000070bab59d003f  vmovaps xmm14, [rsp+0x90]
000070bab59d0048  vpermilpd xmm14, xmm14, 0x00
000070bab59d004e  vmovaps xmm8, [rsp+0x10]
000070bab59d0054  movaps xmm13, xmm8
000070bab59d0058  mulpd xmm13, xmm14
000070bab59d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000070bab59d0063  ptest xmm6, xmm6
000070bab59d0068  jnz 0x000070BAB59D3E52
000070bab59d006e  vmovaps xmm14, [rsp+0x60]
000070bab59d0074  vpermilpd xmm14, xmm14, 0x00
000070bab59d007a  movaps xmm8, xmm7
000070bab59d007e  mulpd xmm8, xmm14
000070bab59d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000070bab59d0089  ptest xmm6, xmm6
000070bab59d008e  jnz 0x000070BAB59D3F96
000070bab59d0094  movaps xmm14, xmm12
000070bab59d0098  addpd xmm14, xmm9
000070bab59d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000070bab59d00a3  ptest xmm7, xmm7
000070bab59d00a8  jnz 0x000070BAB59D40D9
000070bab59d00ae  vmovaps xmm12, [rsp+0x60]
000070bab59d00b4  vpermilpd xmm12, xmm12, 0x00
000070bab59d00ba  vmovaps xmm7, [rsp+0xF0]
000070bab59d00c3  movaps xmm9, xmm7
000070bab59d00c7  mulpd xmm9, xmm12
000070bab59d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000070bab59d00d2  ptest xmm6, xmm6
000070bab59d00d7  jnz 0x000070BAB59D421D
000070bab59d00dd  movaps xmm12, xmm15
000070bab59d00e1  addpd xmm12, xmm11
000070bab59d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000070bab59d00ec  ptest xmm7, xmm7
000070bab59d00f1  jnz 0x000070BAB59D4360
000070bab59d00f7  vmovaps xmm15, [rsp+0x60]
000070bab59d00fd  vpermilpd xmm15, xmm15, 0x00
000070bab59d0103  vmovaps xmm7, [rsp+0x40]
000070bab59d0109  movaps xmm11, xmm7
000070bab59d010d  mulpd xmm11, xmm15
000070bab59d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000070bab59d0118  ptest xmm6, xmm6
000070bab59d011d  jnz 0x000070BAB59D44A4
000070bab59d0123  movaps xmm15, xmm10
000070bab59d0127  addpd xmm15, xmm13
000070bab59d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000070bab59d0132  ptest xmm7, xmm7
000070bab59d0137  jnz 0x000070BAB59D45E7
000070bab59d013d  vmovaps xmm13, [rsp+0x60]
000070bab59d0143  vpermilpd xmm13, xmm13, 0x00
000070bab59d0149  vmovaps xmm7, [rsp+0x50]
000070bab59d014f  movaps xmm10, xmm7
000070bab59d0153  mulpd xmm10, xmm13
000070bab59d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000070bab59d015e  ptest xmm6, xmm6
000070bab59d0163  jnz 0x000070BAB59D472B
000070bab59d0169  movaps xmm13, xmm1
000070bab59d016d  addpd xmm13, xmm8
000070bab59d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000070bab59d0178  ptest xmm7, xmm7
000070bab59d017d  jnz 0x000070BAB59D486E
000070bab59d0183  lea rax, [r14+0x70]
000070bab59d0187  movups xmm1, [r13+rax*1]
000070bab59d018d  movaps [r15+0x240], xmm1
000070bab59d0195  movaps xmm8, xmm14
000070bab59d0199  addpd xmm8, xmm9
000070bab59d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000070bab59d01a4  ptest xmm7, xmm7
000070bab59d01a9  jnz 0x000070BAB59D49BB
000070bab59d01af  movaps [r15+0x170], xmm8
000070bab59d01b7  vmovaps xmm14, [rsp+0x70]
000070bab59d01bd  vpermilpd xmm14, xmm14, 0x00
000070bab59d01c3  movaps xmm9, xmm1
000070bab59d01c7  mulpd xmm9, xmm14
000070bab59d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000070bab59d01d2  ptest xmm7, xmm7
000070bab59d01d7  jnz 0x000070BAB59D4AFF
000070bab59d01dd  vmovaps xmm1, [rsp+0x70]
000070bab59d01e3  vpermilpd xmm1, xmm1, 0x00
000070bab59d01e9  movaps xmm14, xmm4
000070bab59d01ed  mulpd xmm14, xmm1
000070bab59d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000070bab59d01f8  ptest xmm7, xmm7
000070bab59d01fd  jnz 0x000070BAB59D4C42
000070bab59d0203  movaps [r15+0x180], xmm14
000070bab59d020b  movaps xmm1, xmm12
000070bab59d020f  addpd xmm1, xmm11
000070bab59d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000070bab59d0219  ptest xmm7, xmm7
000070bab59d021e  jnz 0x000070BAB59D4D84
000070bab59d0224  movaps [r15+0x210], xmm1
000070bab59d022c  movups xmm12, [r13+r14*1]
000070bab59d0232  lea rax, [r14+0x10]
000070bab59d0236  movups xmm11, [r13+rax*1]
000070bab59d023c  movaps [r15+0x230], xmm11
000070bab59d0244  movaps xmm7, xmm15
000070bab59d0248  addpd xmm7, xmm10
000070bab59d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000070bab59d0252  ptest xmm6, xmm6
000070bab59d0257  jnz 0x000070BAB59D4EDA
000070bab59d025d  movaps [r15+0x130], xmm7
000070bab59d0265  vmovaps xmm15, [rsp+0x70]
000070bab59d026b  vpermilpd xmm15, xmm15, 0x00
000070bab59d0271  movaps xmm10, xmm11
000070bab59d0275  mulpd xmm10, xmm15
000070bab59d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000070bab59d0280  ptest xmm6, xmm6
000070bab59d0285  jnz 0x000070BAB59D501C
000070bab59d028b  movaps [r15+0x220], xmm10
000070bab59d0293  vmovaps xmm15, [rsp+0x70]
000070bab59d0299  vpermilpd xmm15, xmm15, 0x00
000070bab59d029f  movaps xmm11, xmm12
000070bab59d02a3  mulpd xmm11, xmm15
000070bab59d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000070bab59d02ae  ptest xmm6, xmm6
000070bab59d02b3  jnz 0x000070BAB59D5160
000070bab59d02b9  movaps xmm15, xmm13
000070bab59d02bd  addpd xmm15, xmm9
000070bab59d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000070bab59d02c8  ptest xmm12, xmm12
000070bab59d02ce  jnz 0x000070BAB59D52A4
000070bab59d02d4  movaps [r15+0x140], xmm15
000070bab59d02dc  movaps xmm13, xmm8
000070bab59d02e0  addpd xmm13, xmm14
000070bab59d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000070bab59d02eb  ptest xmm12, xmm12
000070bab59d02f1  jnz 0x000070BAB59D53E8
000070bab59d02f7  movaps [r15+0x150], xmm13
000070bab59d02ff  movaps xmm14, xmm1
000070bab59d0303  addpd xmm14, xmm10
000070bab59d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000070bab59d030e  ptest xmm12, xmm12
000070bab59d0314  jnz 0x000070BAB59D552C
000070bab59d031a  movaps [r15+0x160], xmm14
000070bab59d0322  movaps xmm1, xmm7
000070bab59d0325  addpd xmm1, xmm11
000070bab59d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000070bab59d032f  ptest xmm12, xmm12
000070bab59d0335  jnz 0x000070BAB59D566F
000070bab59d033b  movaps [r15+0x120], xmm1
000070bab59d0343  mov eax, 0x430920
000070bab59d0348  movups [r13+rax*1], xmm15
000070bab59d034e  mov eax, 0x430930
000070bab59d0353  movups [r13+rax*1], xmm13
000070bab59d0359  mov eax, 0x430940
000070bab59d035e  movups [r13+rax*1], xmm14
000070bab59d0364  mov eax, 0x430950
000070bab59d0369  movups [r13+rax*1], xmm1
000070bab59d036f  mov eax, [r15+0x108]
000070bab59d0376  sahf
000070bab59d0377  jnz 0x000070BAB59D03A9
000070bab59d0379  cmp dword ptr [r15+0x318], 0x00
000070bab59d0381  jz 0x000070BAB59DB900
000070bab59d0387  nop [rax+rax*1], ax
000070bab59d0390  nop [rax+rax*1], eax
000070bab59d0398  mov eax, 0x410444
000070bab59d039d  mov [r15+0x100], rax
000070bab59d03a4  jmp 0x000070BAB57FE110
000070bab59d03a9  cmp dword ptr [r15+0x318], 0x00
000070bab59d03b1  jz 0x000070BAB59D57E0
000070bab59d03b7  nop [rax+rax*1], ax
000070bab59d03c0  nop [rax+rax*1], eax
000070bab59d03c8  mov eax, 0x410278
000070bab59d03cd  mov [r15+0x100], rax
000070bab59d03d4  jmp 0x000070BAB57FE110
000070bab59d03d9  int3
000070bab59d03da  call 0x000070BAB58B52F0
000070bab59d03df  jmp 0x000070BAB59CF016
000070bab59d03e4  call 0x000070BAB58C4620
000070bab59d03e9  jmp 0x000070BAB59CF023
000070bab59d03ee  call 0x000070BAB58C33A0
000070bab59d03f3  jmp 0x000070BAB59CF035
000070bab59d03f8  call 0x000070BAB58C2120
000070bab59d03fd  jmp 0x000070BAB59CF03F
000070bab59d0402  call 0x000070BAB58C0860
000070bab59d0407  jmp 0x000070BAB59CF067
000070bab59d040c  call 0x000070BAB58BF5F0
000070bab59d0411  jmp 0x000070BAB59CF073
000070bab59d0416  call 0x000070BAB58C0860
000070bab59d041b  jmp 0x000070BAB59CF0A5
000070bab59d0420  call 0x000070BAB58BF5F0
000070bab59d0425  jmp 0x000070BAB59CF0B1
000070bab59d042a  call 0x000070BAB58C4740
000070bab59d042f  jmp 0x000070BAB59CF0BE
000070bab59d0434  call 0x000070BAB58B5400
000070bab59d0439  jmp 0x000070BAB59CF0CB
000070bab59d043e  call 0x000070BAB58B52F0
000070bab59d0443  jmp 0x000070BAB59CF0D8
000070bab59d0448  call 0x000070BAB58C4620
000070bab59d044d  jmp 0x000070BAB59CF0E5
000070bab59d0452  call 0x000070BAB58C0860
000070bab59d0457  jmp 0x000070BAB59CF10D
000070bab59d045c  call 0x000070BAB58BF5F0
000070bab59d0461  jmp 0x000070BAB59CF119
000070bab59d0466  call 0x000070BAB5809D70
000070bab59d046b  jmp 0x000070BAB59CF11F
000070bab59d0470  call 0x000070BAB58BE9C0
000070bab59d0475  jmp 0x000070BAB59CF129
000070bab59d047a  call 0x000070BAB58C0860
000070bab59d047f  jmp 0x000070BAB59CF151
000070bab59d0484  call 0x000070BAB58BF5F0
000070bab59d0489  jmp 0x000070BAB59CF15D
000070bab59d048e  call 0x000070BAB58BD750
000070bab59d0493  jmp 0x000070BAB59CF16A
000070bab59d0498  call 0x000070BAB58BC4E0
000070bab59d049d  jmp 0x000070BAB59CF177
000070bab59d04a2  call 0x000070BAB58C4740
000070bab59d04a7  jmp 0x000070BAB59CF184
000070bab59d04ac  call 0x000070BAB58B5400
000070bab59d04b1  jmp 0x000070BAB59CF191
000070bab59d04b6  call 0x000070BAB58B52F0
000070bab59d04bb  jmp 0x000070BAB59CF19E
000070bab59d04c0  call 0x000070BAB58C4620
000070bab59d04c5  jmp 0x000070BAB59CF1AB
000070bab59d04ca  call 0x000070BAB58C0860
000070bab59d04cf  jmp 0x000070BAB59CF1BE
000070bab59d04d4  call 0x000070BAB58BB270
000070bab59d04d9  jmp 0x000070BAB59CF1CB
000070bab59d04de  call 0x000070BAB58BA000
000070bab59d04e3  jmp 0x000070BAB59CF1D8
000070bab59d04e8  call 0x000070BAB58B8D90
000070bab59d04ed  jmp 0x000070BAB59CF1E5
000070bab59d04f2  call 0x000070BAB58B8A20
000070bab59d04f7  jmp 0x000070BAB59CF1F2
000070bab59d04fc  call 0x000070BAB58B5400
000070bab59d0501  jmp 0x000070BAB59CF1FC
000070bab59d0506  call 0x000070BAB58C2240
000070bab59d050b  jmp 0x000070BAB59CF206
000070bab59d0510  call 0x000070BAB58B52F0
000070bab59d0515  jmp 0x000070BAB59CF210
000070bab59d051a  call 0x000070BAB58C2120
000070bab59d051f  jmp 0x000070BAB59CF21A
000070bab59d0524  call 0x000070BAB58B77B0
000070bab59d0529  jmp 0x000070BAB59CF224
000070bab59d052e  call 0x000070BAB58B6550
000070bab59d0533  jmp 0x000070BAB59CF22E
000070bab59d0538  call 0x000070BAB58BFD50
000070bab59d053d  jmp 0x000070BAB59CF240
000070bab59d0542  call 0x000070BAB58B8EA0
000070bab59d0547  jmp 0x000070BAB59CF24A
000070bab59d054c  call 0x000070BAB58BFC30
000070bab59d0551  jmp 0x000070BAB59CF257
000070bab59d0556  call 0x000070BAB58B8D90
000070bab59d055b  jmp 0x000070BAB59CF264
000070bab59d0560  call 0x000070BAB58C2240
000070bab59d0565  jmp 0x000070BAB59CF271
000070bab59d056a  call 0x000070BAB58B5400
000070bab59d056f  jmp 0x000070BAB59CF27E
000070bab59d0574  call 0x000070BAB58B52F0
000070bab59d0579  jmp 0x000070BAB59CF28B
000070bab59d057e  call 0x000070BAB58C2120
000070bab59d0583  jmp 0x000070BAB59CF298
000070bab59d0588  call 0x000070BAB58B52F0
000070bab59d058d  jmp 0x000070BAB59CF2AB
000070bab59d0592  call 0x000070BAB58B52F0
000070bab59d0597  jmp 0x000070BAB59CF2BE
000070bab59d059c  call 0x000070BAB58B52F0
000070bab59d05a1  jmp 0x000070BAB59CF2D1
000070bab59d05a6  call 0x000070BAB58B52F0
000070bab59d05ab  jmp 0x000070BAB59CF2E4
000070bab59d05b0  call 0x000070BAB58C2240
000070bab59d05b5  jmp 0x000070BAB59CF2F9
000070bab59d05ba  call 0x000070BAB58C2240
000070bab59d05bf  jmp 0x000070BAB59CF30C
000070bab59d05c4  call 0x000070BAB58C2120
000070bab59d05c9  jmp 0x000070BAB59CF319
000070bab59d05ce  call 0x000070BAB58B52F0
000070bab59d05d3  jmp 0x000070BAB59CF32C
000070bab59d05d8  call 0x000070BAB58B52F0
000070bab59d05dd  jmp 0x000070BAB59CF34F
000070bab59d05e2  call 0x000070BAB58B52F0
000070bab59d05e7  jmp 0x000070BAB59CF362
000070bab59d05ec  call 0x000070BAB57FF540
000070bab59d05f1  jmp 0x000070BAB59CF380
000070bab59d05f6  call 0x000070BAB5808C20
000070bab59d05fb  jmp 0x000070BAB59CF38A
000070bab59d0600  call 0x000070BAB58D6600
000070bab59d0605  jmp 0x000070BAB59CF396
000070bab59d060a  call 0x000070BAB57FF540
000070bab59d060f  jmp 0x000070BAB59CF3A6
000070bab59d0614  call 0x000070BAB58C0370
000070bab59d0619  jmp 0x000070BAB59CF3D4
000070bab59d061e  call 0x000070BAB58BF100
000070bab59d0623  jmp 0x000070BAB59CF3DD
000070bab59d0628  call 0x000070BAB58C0370
000070bab59d062d  jmp 0x000070BAB59CF43B
000070bab59d0632  call 0x000070BAB58BF100
000070bab59d0637  jmp 0x000070BAB59CF444
000070bab59d063c  call 0x000070BAB58C0370
000070bab59d0641  jmp 0x000070BAB59CF48B
000070bab59d0646  call 0x000070BAB58BF100
000070bab59d064b  jmp 0x000070BAB59CF494
000070bab59d0650  call 0x000070BAB580B720
000070bab59d0655  jmp 0x000070BAB59CF4D7
000070bab59d065a  call 0x000070BAB58B47C0
000070bab59d065f  jmp 0x000070BAB59CF4EA
000070bab59d0664  call 0x000070BAB5808B00
000070bab59d0669  jmp 0x000070BAB59CF501
000070bab59d066e  call 0x000070BAB57FF430
000070bab59d0673  jmp 0x000070BAB59CF514
000070bab59d0678  call 0x000070BAB57FF430
000070bab59d067d  jmp 0x000070BAB59CF527
000070bab59d0682  sub rsp, 0x08
000070bab59d0686  push rax
000070bab59d0687  push rcx
000070bab59d0688  push rdx
000070bab59d0689  push rdi
000070bab59d068a  push rsi
000070bab59d068b  push r8
000070bab59d068d  push r9
000070bab59d068f  push r10
000070bab59d0691  push r11
000070bab59d0693  sub rsp, 0xF0
000070bab59d069a  vmovaps [rsp], xmm0
000070bab59d069f  vmovaps [rsp+0x10], xmm2
000070bab59d06a5  vmovaps [rsp+0x20], xmm3
000070bab59d06ab  vmovaps [rsp+0x30], xmm4
000070bab59d06b1  vmovaps [rsp+0x40], xmm5
000070bab59d06b7  vmovaps [rsp+0x50], xmm6
000070bab59d06bd  vmovaps [rsp+0x60], xmm7
000070bab59d06c3  vmovaps [rsp+0x70], xmm8
000070bab59d06c9  vmovaps [rsp+0x80], xmm9
000070bab59d06d2  vmovaps [rsp+0x90], xmm10
000070bab59d06db  vmovaps [rsp+0xA0], xmm11
000070bab59d06e4  vmovaps [rsp+0xB0], xmm12
000070bab59d06ed  vmovaps [rsp+0xC0], xmm13
000070bab59d06f6  vmovaps [rsp+0xD0], xmm14
000070bab59d06ff  vmovaps [rsp+0xE0], xmm15
000070bab59d0708  sub rsp, 0x30
000070bab59d070c  movaps [rsp], xmm1
000070bab59d0710  movaps [rsp+0x10], xmm15
000070bab59d0716  movaps [rsp+0x20], xmm14
000070bab59d071c  lea rdi, [rsp]
000070bab59d0720  mov esi, 0x00
000070bab59d0725  mov rax, 0x63B35AFBC530
000070bab59d072f  call rax
000070bab59d0731  movaps xmm1, [rsp]
000070bab59d0735  add rsp, 0x30
000070bab59d0739  vmovaps xmm0, [rsp]
000070bab59d073e  vmovaps xmm2, [rsp+0x10]
000070bab59d0744  vmovaps xmm3, [rsp+0x20]
000070bab59d074a  vmovaps xmm4, [rsp+0x30]
000070bab59d0750  vmovaps xmm5, [rsp+0x40]
000070bab59d0756  vmovaps xmm6, [rsp+0x50]
000070bab59d075c  vmovaps xmm7, [rsp+0x60]
000070bab59d0762  vmovaps xmm8, [rsp+0x70]
000070bab59d0768  vmovaps xmm9, [rsp+0x80]
000070bab59d0771  vmovaps xmm10, [rsp+0x90]
000070bab59d077a  vmovaps xmm11, [rsp+0xA0]
000070bab59d0783  vmovaps xmm12, [rsp+0xB0]
000070bab59d078c  vmovaps xmm13, [rsp+0xC0]
000070bab59d0795  vmovaps xmm14, [rsp+0xD0]
000070bab59d079e  vmovaps xmm15, [rsp+0xE0]
000070bab59d07a7  add rsp, 0xF0
000070bab59d07ae  pop r11
000070bab59d07b0  pop r10
000070bab59d07b2  pop r9
000070bab59d07b4  pop r8
000070bab59d07b6  pop rsi
000070bab59d07b7  pop rdi
000070bab59d07b8  pop rdx
000070bab59d07b9  pop rcx
000070bab59d07ba  pop rax
000070bab59d07bb  add rsp, 0x08
000070bab59d07bf  jmp 0x000070BAB59CF581
000070bab59d07c4  sub rsp, 0x08
000070bab59d07c8  push rax
000070bab59d07c9  push rcx
000070bab59d07ca  push rdx
000070bab59d07cb  push rdi
000070bab59d07cc  push rsi
000070bab59d07cd  push r8
000070bab59d07cf  push r9
000070bab59d07d1  push r10
000070bab59d07d3  push r11
000070bab59d07d5  sub rsp, 0xF0
000070bab59d07dc  vmovaps [rsp], xmm0
000070bab59d07e1  vmovaps [rsp+0x10], xmm1
000070bab59d07e7  vmovaps [rsp+0x20], xmm2
000070bab59d07ed  vmovaps [rsp+0x30], xmm3
000070bab59d07f3  vmovaps [rsp+0x40], xmm4
000070bab59d07f9  vmovaps [rsp+0x50], xmm5
000070bab59d07ff  vmovaps [rsp+0x60], xmm6
000070bab59d0805  vmovaps [rsp+0x70], xmm7
000070bab59d080b  vmovaps [rsp+0x80], xmm8
000070bab59d0814  vmovaps [rsp+0x90], xmm9
000070bab59d081d  vmovaps [rsp+0xA0], xmm10
000070bab59d0826  vmovaps [rsp+0xB0], xmm11
000070bab59d082f  vmovaps [rsp+0xC0], xmm12
000070bab59d0838  vmovaps [rsp+0xD0], xmm14
000070bab59d0841  vmovaps [rsp+0xE0], xmm15
000070bab59d084a  sub rsp, 0x30
000070bab59d084e  movaps [rsp], xmm13
000070bab59d0853  movaps [rsp+0x10], xmm1
000070bab59d0858  movaps [rsp+0x20], xmm14
000070bab59d085e  lea rdi, [rsp]
000070bab59d0862  mov esi, 0x00
000070bab59d0867  mov rax, 0x63B35AFBC530
000070bab59d0871  call rax
000070bab59d0873  movaps xmm13, [rsp]
000070bab59d0878  add rsp, 0x30
000070bab59d087c  vmovaps xmm0, [rsp]
000070bab59d0881  vmovaps xmm1, [rsp+0x10]
000070bab59d0887  vmovaps xmm2, [rsp+0x20]
000070bab59d088d  vmovaps xmm3, [rsp+0x30]
000070bab59d0893  vmovaps xmm4, [rsp+0x40]
000070bab59d0899  vmovaps xmm5, [rsp+0x50]
000070bab59d089f  vmovaps xmm6, [rsp+0x60]
000070bab59d08a5  vmovaps xmm7, [rsp+0x70]
000070bab59d08ab  vmovaps xmm8, [rsp+0x80]
000070bab59d08b4  vmovaps xmm9, [rsp+0x90]
000070bab59d08bd  vmovaps xmm10, [rsp+0xA0]
000070bab59d08c6  vmovaps xmm11, [rsp+0xB0]
000070bab59d08cf  vmovaps xmm12, [rsp+0xC0]
000070bab59d08d8  vmovaps xmm14, [rsp+0xD0]
000070bab59d08e1  vmovaps xmm15, [rsp+0xE0]
000070bab59d08ea  add rsp, 0xF0
000070bab59d08f1  pop r11
000070bab59d08f3  pop r10
000070bab59d08f5  pop r9
000070bab59d08f7  pop r8
000070bab59d08f9  pop rsi
000070bab59d08fa  pop rdi
000070bab59d08fb  pop rdx
000070bab59d08fc  pop rcx
000070bab59d08fd  pop rax
000070bab59d08fe  add rsp, 0x08
000070bab59d0902  jmp 0x000070BAB59CF5CF
000070bab59d0907  sub rsp, 0x08
000070bab59d090b  push rax
000070bab59d090c  push rcx
000070bab59d090d  push rdx
000070bab59d090e  push rdi
000070bab59d090f  push rsi
000070bab59d0910  push r8
000070bab59d0912  push r9
000070bab59d0914  push r10
000070bab59d0916  push r11
000070bab59d0918  sub rsp, 0xF0
000070bab59d091f  vmovaps [rsp], xmm0
000070bab59d0924  vmovaps [rsp+0x10], xmm1
000070bab59d092a  vmovaps [rsp+0x20], xmm2
000070bab59d0930  vmovaps [rsp+0x30], xmm3
000070bab59d0936  vmovaps [rsp+0x40], xmm4
000070bab59d093c  vmovaps [rsp+0x50], xmm5
000070bab59d0942  vmovaps [rsp+0x60], xmm6
000070bab59d0948  vmovaps [rsp+0x70], xmm7
000070bab59d094e  vmovaps [rsp+0x80], xmm8
000070bab59d0957  vmovaps [rsp+0x90], xmm9
000070bab59d0960  vmovaps [rsp+0xA0], xmm10
000070bab59d0969  vmovaps [rsp+0xB0], xmm11
000070bab59d0972  vmovaps [rsp+0xC0], xmm12
000070bab59d097b  vmovaps [rsp+0xD0], xmm13
000070bab59d0984  vmovaps [rsp+0xE0], xmm14
000070bab59d098d  sub rsp, 0x30
000070bab59d0991  movaps [rsp], xmm15
000070bab59d0996  movaps [rsp+0x10], xmm14
000070bab59d099c  movaps [rsp+0x20], xmm1
000070bab59d09a1  lea rdi, [rsp]
000070bab59d09a5  mov esi, 0x00
000070bab59d09aa  mov rax, 0x63B35AFBC530
000070bab59d09b4  call rax
000070bab59d09b6  movaps xmm15, [rsp]
000070bab59d09bb  add rsp, 0x30
000070bab59d09bf  vmovaps xmm0, [rsp]
000070bab59d09c4  vmovaps xmm1, [rsp+0x10]
000070bab59d09ca  vmovaps xmm2, [rsp+0x20]
000070bab59d09d0  vmovaps xmm3, [rsp+0x30]
000070bab59d09d6  vmovaps xmm4, [rsp+0x40]
000070bab59d09dc  vmovaps xmm5, [rsp+0x50]
000070bab59d09e2  vmovaps xmm6, [rsp+0x60]
000070bab59d09e8  vmovaps xmm7, [rsp+0x70]
000070bab59d09ee  vmovaps xmm8, [rsp+0x80]
000070bab59d09f7  vmovaps xmm9, [rsp+0x90]
000070bab59d0a00  vmovaps xmm10, [rsp+0xA0]
000070bab59d0a09  vmovaps xmm11, [rsp+0xB0]
000070bab59d0a12  vmovaps xmm12, [rsp+0xC0]
000070bab59d0a1b  vmovaps xmm13, [rsp+0xD0]
000070bab59d0a24  vmovaps xmm14, [rsp+0xE0]
000070bab59d0a2d  add rsp, 0xF0
000070bab59d0a34  pop r11
000070bab59d0a36  pop r10
000070bab59d0a38  pop r9
000070bab59d0a3a  pop r8
000070bab59d0a3c  pop rsi
000070bab59d0a3d  pop rdi
000070bab59d0a3e  pop rdx
000070bab59d0a3f  pop rcx
000070bab59d0a40  pop rax
000070bab59d0a41  add rsp, 0x08
000070bab59d0a45  jmp 0x000070BAB59CF617
000070bab59d0a4a  sub rsp, 0x08
000070bab59d0a4e  push rax
000070bab59d0a4f  push rcx
000070bab59d0a50  push rdx
000070bab59d0a51  push rdi
000070bab59d0a52  push rsi
000070bab59d0a53  push r8
000070bab59d0a55  push r9
000070bab59d0a57  push r10
000070bab59d0a59  push r11
000070bab59d0a5b  sub rsp, 0xF0
000070bab59d0a62  vmovaps [rsp], xmm0
000070bab59d0a67  vmovaps [rsp+0x10], xmm2
000070bab59d0a6d  vmovaps [rsp+0x20], xmm3
000070bab59d0a73  vmovaps [rsp+0x30], xmm4
000070bab59d0a79  vmovaps [rsp+0x40], xmm5
000070bab59d0a7f  vmovaps [rsp+0x50], xmm6
000070bab59d0a85  vmovaps [rsp+0x60], xmm7
000070bab59d0a8b  vmovaps [rsp+0x70], xmm8
000070bab59d0a91  vmovaps [rsp+0x80], xmm9
000070bab59d0a9a  vmovaps [rsp+0x90], xmm10
000070bab59d0aa3  vmovaps [rsp+0xA0], xmm11
000070bab59d0aac  vmovaps [rsp+0xB0], xmm12
000070bab59d0ab5  vmovaps [rsp+0xC0], xmm13
000070bab59d0abe  vmovaps [rsp+0xD0], xmm14
000070bab59d0ac7  vmovaps [rsp+0xE0], xmm15
000070bab59d0ad0  sub rsp, 0x30
000070bab59d0ad4  movaps [rsp], xmm1
000070bab59d0ad8  movaps [rsp+0x10], xmm14
000070bab59d0ade  movaps [rsp+0x20], xmm10
000070bab59d0ae4  lea rdi, [rsp]
000070bab59d0ae8  mov esi, 0x00
000070bab59d0aed  mov rax, 0x63B35AFBC530
000070bab59d0af7  call rax
000070bab59d0af9  movaps xmm1, [rsp]
000070bab59d0afd  add rsp, 0x30
000070bab59d0b01  vmovaps xmm0, [rsp]
000070bab59d0b06  vmovaps xmm2, [rsp+0x10]
000070bab59d0b0c  vmovaps xmm3, [rsp+0x20]
000070bab59d0b12  vmovaps xmm4, [rsp+0x30]
000070bab59d0b18  vmovaps xmm5, [rsp+0x40]
000070bab59d0b1e  vmovaps xmm6, [rsp+0x50]
000070bab59d0b24  vmovaps xmm7, [rsp+0x60]
000070bab59d0b2a  vmovaps xmm8, [rsp+0x70]
000070bab59d0b30  vmovaps xmm9, [rsp+0x80]
000070bab59d0b39  vmovaps xmm10, [rsp+0x90]
000070bab59d0b42  vmovaps xmm11, [rsp+0xA0]
000070bab59d0b4b  vmovaps xmm12, [rsp+0xB0]
000070bab59d0b54  vmovaps xmm13, [rsp+0xC0]
000070bab59d0b5d  vmovaps xmm14, [rsp+0xD0]
000070bab59d0b66  vmovaps xmm15, [rsp+0xE0]
000070bab59d0b6f  add rsp, 0xF0
000070bab59d0b76  pop r11
000070bab59d0b78  pop r10
000070bab59d0b7a  pop r9
000070bab59d0b7c  pop r8
000070bab59d0b7e  pop rsi
000070bab59d0b7f  pop rdi
000070bab59d0b80  pop rdx
000070bab59d0b81  pop rcx
000070bab59d0b82  pop rax
000070bab59d0b83  add rsp, 0x08
000070bab59d0b87  jmp 0x000070BAB59CF631
000070bab59d0b8c  sub rsp, 0x08
000070bab59d0b90  push rax
000070bab59d0b91  push rcx
000070bab59d0b92  push rdx
000070bab59d0b93  push rdi
000070bab59d0b94  push rsi
000070bab59d0b95  push r8
000070bab59d0b97  push r9
000070bab59d0b99  push r10
000070bab59d0b9b  push r11
000070bab59d0b9d  sub rsp, 0xF0
000070bab59d0ba4  vmovaps [rsp], xmm0
000070bab59d0ba9  vmovaps [rsp+0x10], xmm1
000070bab59d0baf  vmovaps [rsp+0x20], xmm2
000070bab59d0bb5  vmovaps [rsp+0x30], xmm3
000070bab59d0bbb  vmovaps [rsp+0x40], xmm4
000070bab59d0bc1  vmovaps [rsp+0x50], xmm5
000070bab59d0bc7  vmovaps [rsp+0x60], xmm6
000070bab59d0bcd  vmovaps [rsp+0x70], xmm7
000070bab59d0bd3  vmovaps [rsp+0x80], xmm8
000070bab59d0bdc  vmovaps [rsp+0x90], xmm9
000070bab59d0be5  vmovaps [rsp+0xA0], xmm10
000070bab59d0bee  vmovaps [rsp+0xB0], xmm11
000070bab59d0bf7  vmovaps [rsp+0xC0], xmm12
000070bab59d0c00  vmovaps [rsp+0xD0], xmm14
000070bab59d0c09  vmovaps [rsp+0xE0], xmm15
000070bab59d0c12  sub rsp, 0x30
000070bab59d0c16  movaps [rsp], xmm13
000070bab59d0c1b  movaps [rsp+0x10], xmm14
000070bab59d0c21  movaps [rsp+0x20], xmm2
000070bab59d0c26  lea rdi, [rsp]
000070bab59d0c2a  mov esi, 0x00
000070bab59d0c2f  mov rax, 0x63B35AFBC530
000070bab59d0c39  call rax
000070bab59d0c3b  movaps xmm13, [rsp]
000070bab59d0c40  add rsp, 0x30
000070bab59d0c44  vmovaps xmm0, [rsp]
000070bab59d0c49  vmovaps xmm1, [rsp+0x10]
000070bab59d0c4f  vmovaps xmm2, [rsp+0x20]
000070bab59d0c55  vmovaps xmm3, [rsp+0x30]
000070bab59d0c5b  vmovaps xmm4, [rsp+0x40]
000070bab59d0c61  vmovaps xmm5, [rsp+0x50]
000070bab59d0c67  vmovaps xmm6, [rsp+0x60]
000070bab59d0c6d  vmovaps xmm7, [rsp+0x70]
000070bab59d0c73  vmovaps xmm8, [rsp+0x80]
000070bab59d0c7c  vmovaps xmm9, [rsp+0x90]
000070bab59d0c85  vmovaps xmm10, [rsp+0xA0]
000070bab59d0c8e  vmovaps xmm11, [rsp+0xB0]
000070bab59d0c97  vmovaps xmm12, [rsp+0xC0]
000070bab59d0ca0  vmovaps xmm14, [rsp+0xD0]
000070bab59d0ca9  vmovaps xmm15, [rsp+0xE0]
000070bab59d0cb2  add rsp, 0xF0
000070bab59d0cb9  pop r11
000070bab59d0cbb  pop r10
000070bab59d0cbd  pop r9
000070bab59d0cbf  pop r8
000070bab59d0cc1  pop rsi
000070bab59d0cc2  pop rdi
000070bab59d0cc3  pop rdx
000070bab59d0cc4  pop rcx
000070bab59d0cc5  pop rax
000070bab59d0cc6  add rsp, 0x08
000070bab59d0cca  jmp 0x000070BAB59CF64C
000070bab59d0ccf  sub rsp, 0x08
000070bab59d0cd3  push rax
000070bab59d0cd4  push rcx
000070bab59d0cd5  push rdx
000070bab59d0cd6  push rdi
000070bab59d0cd7  push rsi
000070bab59d0cd8  push r8
000070bab59d0cda  push r9
000070bab59d0cdc  push r10
000070bab59d0cde  push r11
000070bab59d0ce0  sub rsp, 0xF0
000070bab59d0ce7  vmovaps [rsp], xmm0
000070bab59d0cec  vmovaps [rsp+0x10], xmm2
000070bab59d0cf2  vmovaps [rsp+0x20], xmm3
000070bab59d0cf8  vmovaps [rsp+0x30], xmm4
000070bab59d0cfe  vmovaps [rsp+0x40], xmm5
000070bab59d0d04  vmovaps [rsp+0x50], xmm6
000070bab59d0d0a  vmovaps [rsp+0x60], xmm7
000070bab59d0d10  vmovaps [rsp+0x70], xmm8
000070bab59d0d16  vmovaps [rsp+0x80], xmm9
000070bab59d0d1f  vmovaps [rsp+0x90], xmm10
000070bab59d0d28  vmovaps [rsp+0xA0], xmm11
000070bab59d0d31  vmovaps [rsp+0xB0], xmm12
000070bab59d0d3a  vmovaps [rsp+0xC0], xmm13
000070bab59d0d43  vmovaps [rsp+0xD0], xmm14
000070bab59d0d4c  vmovaps [rsp+0xE0], xmm15
000070bab59d0d55  sub rsp, 0x30
000070bab59d0d59  movaps [rsp], xmm1
000070bab59d0d5d  movaps [rsp+0x10], xmm10
000070bab59d0d63  movaps [rsp+0x20], xmm2
000070bab59d0d68  lea rdi, [rsp]
000070bab59d0d6c  mov esi, 0x00
000070bab59d0d71  mov rax, 0x63B35AFBC530
000070bab59d0d7b  call rax
000070bab59d0d7d  movaps xmm1, [rsp]
000070bab59d0d81  add rsp, 0x30
000070bab59d0d85  vmovaps xmm0, [rsp]
000070bab59d0d8a  vmovaps xmm2, [rsp+0x10]
000070bab59d0d90  vmovaps xmm3, [rsp+0x20]
000070bab59d0d96  vmovaps xmm4, [rsp+0x30]
000070bab59d0d9c  vmovaps xmm5, [rsp+0x40]
000070bab59d0da2  vmovaps xmm6, [rsp+0x50]
000070bab59d0da8  vmovaps xmm7, [rsp+0x60]
000070bab59d0dae  vmovaps xmm8, [rsp+0x70]
000070bab59d0db4  vmovaps xmm9, [rsp+0x80]
000070bab59d0dbd  vmovaps xmm10, [rsp+0x90]
000070bab59d0dc6  vmovaps xmm11, [rsp+0xA0]
000070bab59d0dcf  vmovaps xmm12, [rsp+0xB0]
000070bab59d0dd8  vmovaps xmm13, [rsp+0xC0]
000070bab59d0de1  vmovaps xmm14, [rsp+0xD0]
000070bab59d0dea  vmovaps xmm15, [rsp+0xE0]
000070bab59d0df3  add rsp, 0xF0
000070bab59d0dfa  pop r11
000070bab59d0dfc  pop r10
000070bab59d0dfe  pop r9
000070bab59d0e00  pop r8
000070bab59d0e02  pop rsi
000070bab59d0e03  pop rdi
000070bab59d0e04  pop rdx
000070bab59d0e05  pop rcx
000070bab59d0e06  pop rax
000070bab59d0e07  add rsp, 0x08
000070bab59d0e0b  jmp 0x000070BAB59CF6B4
000070bab59d0e10  sub rsp, 0x08
000070bab59d0e14  push rax
000070bab59d0e15  push rcx
000070bab59d0e16  push rdx
000070bab59d0e17  push rdi
000070bab59d0e18  push rsi
000070bab59d0e19  push r8
000070bab59d0e1b  push r9
000070bab59d0e1d  push r10
000070bab59d0e1f  push r11
000070bab59d0e21  sub rsp, 0xF0
000070bab59d0e28  vmovaps [rsp], xmm0
000070bab59d0e2d  vmovaps [rsp+0x10], xmm1
000070bab59d0e33  vmovaps [rsp+0x20], xmm2
000070bab59d0e39  vmovaps [rsp+0x30], xmm3
000070bab59d0e3f  vmovaps [rsp+0x40], xmm4
000070bab59d0e45  vmovaps [rsp+0x50], xmm5
000070bab59d0e4b  vmovaps [rsp+0x60], xmm6
000070bab59d0e51  vmovaps [rsp+0x70], xmm7
000070bab59d0e57  vmovaps [rsp+0x80], xmm8
000070bab59d0e60  vmovaps [rsp+0x90], xmm9
000070bab59d0e69  vmovaps [rsp+0xA0], xmm10
000070bab59d0e72  vmovaps [rsp+0xB0], xmm11
000070bab59d0e7b  vmovaps [rsp+0xC0], xmm12
000070bab59d0e84  vmovaps [rsp+0xD0], xmm13
000070bab59d0e8d  vmovaps [rsp+0xE0], xmm14
000070bab59d0e96  sub rsp, 0x30
000070bab59d0e9a  movaps [rsp], xmm15
000070bab59d0e9f  movaps [rsp+0x10], xmm10
000070bab59d0ea5  movaps [rsp+0x20], xmm2
000070bab59d0eaa  lea rdi, [rsp]
000070bab59d0eae  mov esi, 0x00
000070bab59d0eb3  mov rax, 0x63B35AFBC530
000070bab59d0ebd  call rax
000070bab59d0ebf  movaps xmm15, [rsp]
000070bab59d0ec4  add rsp, 0x30
000070bab59d0ec8  vmovaps xmm0, [rsp]
000070bab59d0ecd  vmovaps xmm1, [rsp+0x10]
000070bab59d0ed3  vmovaps xmm2, [rsp+0x20]
000070bab59d0ed9  vmovaps xmm3, [rsp+0x30]
000070bab59d0edf  vmovaps xmm4, [rsp+0x40]
000070bab59d0ee5  vmovaps xmm5, [rsp+0x50]
000070bab59d0eeb  vmovaps xmm6, [rsp+0x60]
000070bab59d0ef1  vmovaps xmm7, [rsp+0x70]
000070bab59d0ef7  vmovaps xmm8, [rsp+0x80]
000070bab59d0f00  vmovaps xmm9, [rsp+0x90]
000070bab59d0f09  vmovaps xmm10, [rsp+0xA0]
000070bab59d0f12  vmovaps xmm11, [rsp+0xB0]
000070bab59d0f1b  vmovaps xmm12, [rsp+0xC0]
000070bab59d0f24  vmovaps xmm13, [rsp+0xD0]
000070bab59d0f2d  vmovaps xmm14, [rsp+0xE0]
000070bab59d0f36  add rsp, 0xF0
000070bab59d0f3d  pop r11
000070bab59d0f3f  pop r10
000070bab59d0f41  pop r9
000070bab59d0f43  pop r8
000070bab59d0f45  pop rsi
000070bab59d0f46  pop rdi
000070bab59d0f47  pop rdx
000070bab59d0f48  pop rcx
000070bab59d0f49  pop rax
000070bab59d0f4a  add rsp, 0x08
000070bab59d0f4e  jmp 0x000070BAB59CF706
000070bab59d0f53  sub rsp, 0x08
000070bab59d0f57  push rax
000070bab59d0f58  push rcx
000070bab59d0f59  push rdx
000070bab59d0f5a  push rdi
000070bab59d0f5b  push rsi
000070bab59d0f5c  push r8
000070bab59d0f5e  push r9
000070bab59d0f60  push r10
000070bab59d0f62  push r11
000070bab59d0f64  sub rsp, 0xF0
000070bab59d0f6b  vmovaps [rsp], xmm0
000070bab59d0f70  vmovaps [rsp+0x10], xmm2
000070bab59d0f76  vmovaps [rsp+0x20], xmm3
000070bab59d0f7c  vmovaps [rsp+0x30], xmm4
000070bab59d0f82  vmovaps [rsp+0x40], xmm5
000070bab59d0f88  vmovaps [rsp+0x50], xmm6
000070bab59d0f8e  vmovaps [rsp+0x60], xmm7
000070bab59d0f94  vmovaps [rsp+0x70], xmm8
000070bab59d0f9a  vmovaps [rsp+0x80], xmm9
000070bab59d0fa3  vmovaps [rsp+0x90], xmm10
000070bab59d0fac  vmovaps [rsp+0xA0], xmm11
000070bab59d0fb5  vmovaps [rsp+0xB0], xmm12
000070bab59d0fbe  vmovaps [rsp+0xC0], xmm13
000070bab59d0fc7  vmovaps [rsp+0xD0], xmm14
000070bab59d0fd0  vmovaps [rsp+0xE0], xmm15
000070bab59d0fd9  sub rsp, 0x30
000070bab59d0fdd  movaps [rsp], xmm1
000070bab59d0fe1  movaps [rsp+0x10], xmm10
000070bab59d0fe7  movaps [rsp+0x20], xmm12
000070bab59d0fed  lea rdi, [rsp]
000070bab59d0ff1  mov esi, 0x00
000070bab59d0ff6  mov rax, 0x63B35AFBC530
000070bab59d1000  call rax
000070bab59d1002  movaps xmm1, [rsp]
000070bab59d1006  add rsp, 0x30
000070bab59d100a  vmovaps xmm0, [rsp]
000070bab59d100f  vmovaps xmm2, [rsp+0x10]
000070bab59d1015  vmovaps xmm3, [rsp+0x20]
000070bab59d101b  vmovaps xmm4, [rsp+0x30]
000070bab59d1021  vmovaps xmm5, [rsp+0x40]
000070bab59d1027  vmovaps xmm6, [rsp+0x50]
000070bab59d102d  vmovaps xmm7, [rsp+0x60]
000070bab59d1033  vmovaps xmm8, [rsp+0x70]
000070bab59d1039  vmovaps xmm9, [rsp+0x80]
000070bab59d1042  vmovaps xmm10, [rsp+0x90]
000070bab59d104b  vmovaps xmm11, [rsp+0xA0]
000070bab59d1054  vmovaps xmm12, [rsp+0xB0]
000070bab59d105d  vmovaps xmm13, [rsp+0xC0]
000070bab59d1066  vmovaps xmm14, [rsp+0xD0]
000070bab59d106f  vmovaps xmm15, [rsp+0xE0]
000070bab59d1078  add rsp, 0xF0
000070bab59d107f  pop r11
000070bab59d1081  pop r10
000070bab59d1083  pop r9
000070bab59d1085  pop r8
000070bab59d1087  pop rsi
000070bab59d1088  pop rdi
000070bab59d1089  pop rdx
000070bab59d108a  pop rcx
000070bab59d108b  pop rax
000070bab59d108c  add rsp, 0x08
000070bab59d1090  jmp 0x000070BAB59CF732
000070bab59d1095  sub rsp, 0x08
000070bab59d1099  push rax
000070bab59d109a  push rcx
000070bab59d109b  push rdx
000070bab59d109c  push rdi
000070bab59d109d  push rsi
000070bab59d109e  push r8
000070bab59d10a0  push r9
000070bab59d10a2  push r10
000070bab59d10a4  push r11
000070bab59d10a6  sub rsp, 0xF0
000070bab59d10ad  vmovaps [rsp], xmm0
000070bab59d10b2  vmovaps [rsp+0x10], xmm1
000070bab59d10b8  vmovaps [rsp+0x20], xmm2
000070bab59d10be  vmovaps [rsp+0x30], xmm3
000070bab59d10c4  vmovaps [rsp+0x40], xmm4
000070bab59d10ca  vmovaps [rsp+0x50], xmm5
000070bab59d10d0  vmovaps [rsp+0x60], xmm6
000070bab59d10d6  vmovaps [rsp+0x70], xmm7
000070bab59d10dc  vmovaps [rsp+0x80], xmm8
000070bab59d10e5  vmovaps [rsp+0x90], xmm9
000070bab59d10ee  vmovaps [rsp+0xA0], xmm10
000070bab59d10f7  vmovaps [rsp+0xB0], xmm11
000070bab59d1100  vmovaps [rsp+0xC0], xmm12
000070bab59d1109  vmovaps [rsp+0xD0], xmm13
000070bab59d1112  vmovaps [rsp+0xE0], xmm14
000070bab59d111b  sub rsp, 0x30
000070bab59d111f  movaps [rsp], xmm15
000070bab59d1124  movaps [rsp+0x10], xmm10
000070bab59d112a  movaps [rsp+0x20], xmm12
000070bab59d1130  lea rdi, [rsp]
000070bab59d1134  mov esi, 0x00
000070bab59d1139  mov rax, 0x63B35AFBC530
000070bab59d1143  call rax
000070bab59d1145  movaps xmm15, [rsp]
000070bab59d114a  add rsp, 0x30
000070bab59d114e  vmovaps xmm0, [rsp]
000070bab59d1153  vmovaps xmm1, [rsp+0x10]
000070bab59d1159  vmovaps xmm2, [rsp+0x20]
000070bab59d115f  vmovaps xmm3, [rsp+0x30]
000070bab59d1165  vmovaps xmm4, [rsp+0x40]
000070bab59d116b  vmovaps xmm5, [rsp+0x50]
000070bab59d1171  vmovaps xmm6, [rsp+0x60]
000070bab59d1177  vmovaps xmm7, [rsp+0x70]
000070bab59d117d  vmovaps xmm8, [rsp+0x80]
000070bab59d1186  vmovaps xmm9, [rsp+0x90]
000070bab59d118f  vmovaps xmm10, [rsp+0xA0]
000070bab59d1198  vmovaps xmm11, [rsp+0xB0]
000070bab59d11a1  vmovaps xmm12, [rsp+0xC0]
000070bab59d11aa  vmovaps xmm13, [rsp+0xD0]
000070bab59d11b3  vmovaps xmm14, [rsp+0xE0]
000070bab59d11bc  add rsp, 0xF0
000070bab59d11c3  pop r11
000070bab59d11c5  pop r10
000070bab59d11c7  pop r9
000070bab59d11c9  pop r8
000070bab59d11cb  pop rsi
000070bab59d11cc  pop rdi
000070bab59d11cd  pop rdx
000070bab59d11ce  pop rcx
000070bab59d11cf  pop rax
000070bab59d11d0  add rsp, 0x08
000070bab59d11d4  jmp 0x000070BAB59CF75E
000070bab59d11d9  call 0x000070BAB57FF430
000070bab59d11de  jmp 0x000070BAB59CF7EE
000070bab59d11e3  call 0x000070BAB57FF430
000070bab59d11e8  jmp 0x000070BAB59CF801
000070bab59d11ed  sub rsp, 0x08
000070bab59d11f1  push rax
000070bab59d11f2  push rcx
000070bab59d11f3  push rdx
000070bab59d11f4  push rdi
000070bab59d11f5  push rsi
000070bab59d11f6  push r8
000070bab59d11f8  push r9
000070bab59d11fa  push r10
000070bab59d11fc  push r11
000070bab59d11fe  sub rsp, 0xF0
000070bab59d1205  vmovaps [rsp], xmm0
000070bab59d120a  vmovaps [rsp+0x10], xmm2
000070bab59d1210  vmovaps [rsp+0x20], xmm3
000070bab59d1216  vmovaps [rsp+0x30], xmm4
000070bab59d121c  vmovaps [rsp+0x40], xmm5
000070bab59d1222  vmovaps [rsp+0x50], xmm6
000070bab59d1228  vmovaps [rsp+0x60], xmm7
000070bab59d122e  vmovaps [rsp+0x70], xmm8
000070bab59d1234  vmovaps [rsp+0x80], xmm9
000070bab59d123d  vmovaps [rsp+0x90], xmm10
000070bab59d1246  vmovaps [rsp+0xA0], xmm11
000070bab59d124f  vmovaps [rsp+0xB0], xmm12
000070bab59d1258  vmovaps [rsp+0xC0], xmm13
000070bab59d1261  vmovaps [rsp+0xD0], xmm14
000070bab59d126a  vmovaps [rsp+0xE0], xmm15
000070bab59d1273  sub rsp, 0x30
000070bab59d1277  movaps [rsp], xmm1
000070bab59d127b  movaps [rsp+0x10], xmm13
000070bab59d1281  movaps [rsp+0x20], xmm2
000070bab59d1286  lea rdi, [rsp]
000070bab59d128a  mov esi, 0x00
000070bab59d128f  mov rax, 0x63B35AFBC530
000070bab59d1299  call rax
000070bab59d129b  movaps xmm1, [rsp]
000070bab59d129f  add rsp, 0x30
000070bab59d12a3  vmovaps xmm0, [rsp]
000070bab59d12a8  vmovaps xmm2, [rsp+0x10]
000070bab59d12ae  vmovaps xmm3, [rsp+0x20]
000070bab59d12b4  vmovaps xmm4, [rsp+0x30]
000070bab59d12ba  vmovaps xmm5, [rsp+0x40]
000070bab59d12c0  vmovaps xmm6, [rsp+0x50]
000070bab59d12c6  vmovaps xmm7, [rsp+0x60]
000070bab59d12cc  vmovaps xmm8, [rsp+0x70]
000070bab59d12d2  vmovaps xmm9, [rsp+0x80]
000070bab59d12db  vmovaps xmm10, [rsp+0x90]
000070bab59d12e4  vmovaps xmm11, [rsp+0xA0]
000070bab59d12ed  vmovaps xmm12, [rsp+0xB0]
000070bab59d12f6  vmovaps xmm13, [rsp+0xC0]
000070bab59d12ff  vmovaps xmm14, [rsp+0xD0]
000070bab59d1308  vmovaps xmm15, [rsp+0xE0]
000070bab59d1311  add rsp, 0xF0
000070bab59d1318  pop r11
000070bab59d131a  pop r10
000070bab59d131c  pop r9
000070bab59d131e  pop r8
000070bab59d1320  pop rsi
000070bab59d1321  pop rdi
000070bab59d1322  pop rdx
000070bab59d1323  pop rcx
000070bab59d1324  pop rax
000070bab59d1325  add rsp, 0x08
000070bab59d1329  jmp 0x000070BAB59CF82C
000070bab59d132e  call 0x000070BAB580E760
000070bab59d1333  jmp 0x000070BAB59CF839
000070bab59d1338  sub rsp, 0x08
000070bab59d133c  push rax
000070bab59d133d  push rcx
000070bab59d133e  push rdx
000070bab59d133f  push rdi
000070bab59d1340  push rsi
000070bab59d1341  push r8
000070bab59d1343  push r9
000070bab59d1345  push r10
000070bab59d1347  push r11
000070bab59d1349  sub rsp, 0xF0
000070bab59d1350  vmovaps [rsp], xmm0
000070bab59d1355  vmovaps [rsp+0x10], xmm1
000070bab59d135b  vmovaps [rsp+0x20], xmm2
000070bab59d1361  vmovaps [rsp+0x30], xmm3
000070bab59d1367  vmovaps [rsp+0x40], xmm4
000070bab59d136d  vmovaps [rsp+0x50], xmm5
000070bab59d1373  vmovaps [rsp+0x60], xmm6
000070bab59d1379  vmovaps [rsp+0x70], xmm7
000070bab59d137f  vmovaps [rsp+0x80], xmm8
000070bab59d1388  vmovaps [rsp+0x90], xmm9
000070bab59d1391  vmovaps [rsp+0xA0], xmm10
000070bab59d139a  vmovaps [rsp+0xB0], xmm11
000070bab59d13a3  vmovaps [rsp+0xC0], xmm12
000070bab59d13ac  vmovaps [rsp+0xD0], xmm14
000070bab59d13b5  vmovaps [rsp+0xE0], xmm15
000070bab59d13be  sub rsp, 0x30
000070bab59d13c2  movaps [rsp], xmm13
000070bab59d13c7  movaps [rsp+0x10], xmm2
000070bab59d13cc  movaps [rsp+0x20], xmm1
000070bab59d13d1  lea rdi, [rsp]
000070bab59d13d5  mov esi, 0x00
000070bab59d13da  mov rax, 0x63B35AFBC530
000070bab59d13e4  call rax
000070bab59d13e6  movaps xmm13, [rsp]
000070bab59d13eb  add rsp, 0x30
000070bab59d13ef  vmovaps xmm0, [rsp]
000070bab59d13f4  vmovaps xmm1, [rsp+0x10]
000070bab59d13fa  vmovaps xmm2, [rsp+0x20]
000070bab59d1400  vmovaps xmm3, [rsp+0x30]
000070bab59d1406  vmovaps xmm4, [rsp+0x40]
000070bab59d140c  vmovaps xmm5, [rsp+0x50]
000070bab59d1412  vmovaps xmm6, [rsp+0x60]
000070bab59d1418  vmovaps xmm7, [rsp+0x70]
000070bab59d141e  vmovaps xmm8, [rsp+0x80]
000070bab59d1427  vmovaps xmm9, [rsp+0x90]
000070bab59d1430  vmovaps xmm10, [rsp+0xA0]
000070bab59d1439  vmovaps xmm11, [rsp+0xB0]
000070bab59d1442  vmovaps xmm12, [rsp+0xC0]
000070bab59d144b  vmovaps xmm14, [rsp+0xD0]
000070bab59d1454  vmovaps xmm15, [rsp+0xE0]
000070bab59d145d  add rsp, 0xF0
000070bab59d1464  pop r11
000070bab59d1466  pop r10
000070bab59d1468  pop r9
000070bab59d146a  pop r8
000070bab59d146c  pop rsi
000070bab59d146d  pop rdi
000070bab59d146e  pop rdx
000070bab59d146f  pop rcx
000070bab59d1470  pop rax
000070bab59d1471  add rsp, 0x08
000070bab59d1475  jmp 0x000070BAB59CF878
000070bab59d147a  sub rsp, 0x08
000070bab59d147e  push rax
000070bab59d147f  push rcx
000070bab59d1480  push rdx
000070bab59d1481  push rdi
000070bab59d1482  push rsi
000070bab59d1483  push r8
000070bab59d1485  push r9
000070bab59d1487  push r10
000070bab59d1489  push r11
000070bab59d148b  sub rsp, 0xF0
000070bab59d1492  vmovaps [rsp], xmm0
000070bab59d1497  vmovaps [rsp+0x10], xmm2
000070bab59d149d  vmovaps [rsp+0x20], xmm3
000070bab59d14a3  vmovaps [rsp+0x30], xmm4
000070bab59d14a9  vmovaps [rsp+0x40], xmm5
000070bab59d14af  vmovaps [rsp+0x50], xmm6
000070bab59d14b5  vmovaps [rsp+0x60], xmm7
000070bab59d14bb  vmovaps [rsp+0x70], xmm8
000070bab59d14c1  vmovaps [rsp+0x80], xmm9
000070bab59d14ca  vmovaps [rsp+0x90], xmm10
000070bab59d14d3  vmovaps [rsp+0xA0], xmm11
000070bab59d14dc  vmovaps [rsp+0xB0], xmm12
000070bab59d14e5  vmovaps [rsp+0xC0], xmm13
000070bab59d14ee  vmovaps [rsp+0xD0], xmm14
000070bab59d14f7  vmovaps [rsp+0xE0], xmm15
000070bab59d1500  sub rsp, 0x30
000070bab59d1504  movaps [rsp], xmm1
000070bab59d1508  movaps [rsp+0x10], xmm15
000070bab59d150e  movaps [rsp+0x20], xmm2
000070bab59d1513  lea rdi, [rsp]
000070bab59d1517  mov esi, 0x00
000070bab59d151c  mov rax, 0x63B35AFBC530
000070bab59d1526  call rax
000070bab59d1528  movaps xmm1, [rsp]
000070bab59d152c  add rsp, 0x30
000070bab59d1530  vmovaps xmm0, [rsp]
000070bab59d1535  vmovaps xmm2, [rsp+0x10]
000070bab59d153b  vmovaps xmm3, [rsp+0x20]
000070bab59d1541  vmovaps xmm4, [rsp+0x30]
000070bab59d1547  vmovaps xmm5, [rsp+0x40]
000070bab59d154d  vmovaps xmm6, [rsp+0x50]
000070bab59d1553  vmovaps xmm7, [rsp+0x60]
000070bab59d1559  vmovaps xmm8, [rsp+0x70]
000070bab59d155f  vmovaps xmm9, [rsp+0x80]
000070bab59d1568  vmovaps xmm10, [rsp+0x90]
000070bab59d1571  vmovaps xmm11, [rsp+0xA0]
000070bab59d157a  vmovaps xmm12, [rsp+0xB0]
000070bab59d1583  vmovaps xmm13, [rsp+0xC0]
000070bab59d158c  vmovaps xmm14, [rsp+0xD0]
000070bab59d1595  vmovaps xmm15, [rsp+0xE0]
000070bab59d159e  add rsp, 0xF0
000070bab59d15a5  pop r11
000070bab59d15a7  pop r10
000070bab59d15a9  pop r9
000070bab59d15ab  pop r8
000070bab59d15ad  pop rsi
000070bab59d15ae  pop rdi
000070bab59d15af  pop rdx
000070bab59d15b0  pop rcx
000070bab59d15b1  pop rax
000070bab59d15b2  add rsp, 0x08
000070bab59d15b6  jmp 0x000070BAB59CF8AC
000070bab59d15bb  sub rsp, 0x08
000070bab59d15bf  push rax
000070bab59d15c0  push rcx
000070bab59d15c1  push rdx
000070bab59d15c2  push rdi
000070bab59d15c3  push rsi
000070bab59d15c4  push r8
000070bab59d15c6  push r9
000070bab59d15c8  push r10
000070bab59d15ca  push r11
000070bab59d15cc  sub rsp, 0xF0
000070bab59d15d3  vmovaps [rsp], xmm0
000070bab59d15d8  vmovaps [rsp+0x10], xmm1
000070bab59d15de  vmovaps [rsp+0x20], xmm2
000070bab59d15e4  vmovaps [rsp+0x30], xmm3
000070bab59d15ea  vmovaps [rsp+0x40], xmm4
000070bab59d15f0  vmovaps [rsp+0x50], xmm5
000070bab59d15f6  vmovaps [rsp+0x60], xmm6
000070bab59d15fc  vmovaps [rsp+0x70], xmm7
000070bab59d1602  vmovaps [rsp+0x80], xmm8
000070bab59d160b  vmovaps [rsp+0x90], xmm9
000070bab59d1614  vmovaps [rsp+0xA0], xmm10
000070bab59d161d  vmovaps [rsp+0xB0], xmm11
000070bab59d1626  vmovaps [rsp+0xC0], xmm12
000070bab59d162f  vmovaps [rsp+0xD0], xmm13
000070bab59d1638  vmovaps [rsp+0xE0], xmm15
000070bab59d1641  sub rsp, 0x30
000070bab59d1645  movaps [rsp], xmm14
000070bab59d164a  movaps [rsp+0x10], xmm2
000070bab59d164f  movaps [rsp+0x20], xmm15
000070bab59d1655  lea rdi, [rsp]
000070bab59d1659  mov esi, 0x00
000070bab59d165e  mov rax, 0x63B35AFBC530
000070bab59d1668  call rax
000070bab59d166a  movaps xmm14, [rsp]
000070bab59d166f  add rsp, 0x30
000070bab59d1673  vmovaps xmm0, [rsp]
000070bab59d1678  vmovaps xmm1, [rsp+0x10]
000070bab59d167e  vmovaps xmm2, [rsp+0x20]
000070bab59d1684  vmovaps xmm3, [rsp+0x30]
000070bab59d168a  vmovaps xmm4, [rsp+0x40]
000070bab59d1690  vmovaps xmm5, [rsp+0x50]
000070bab59d1696  vmovaps xmm6, [rsp+0x60]
000070bab59d169c  vmovaps xmm7, [rsp+0x70]
000070bab59d16a2  vmovaps xmm8, [rsp+0x80]
000070bab59d16ab  vmovaps xmm9, [rsp+0x90]
000070bab59d16b4  vmovaps xmm10, [rsp+0xA0]
000070bab59d16bd  vmovaps xmm11, [rsp+0xB0]
000070bab59d16c6  vmovaps xmm12, [rsp+0xC0]
000070bab59d16cf  vmovaps xmm13, [rsp+0xD0]
000070bab59d16d8  vmovaps xmm15, [rsp+0xE0]
000070bab59d16e1  add rsp, 0xF0
000070bab59d16e8  pop r11
000070bab59d16ea  pop r10
000070bab59d16ec  pop r9
000070bab59d16ee  pop r8
000070bab59d16f0  pop rsi
000070bab59d16f1  pop rdi
000070bab59d16f2  pop rdx
000070bab59d16f3  pop rcx
000070bab59d16f4  pop rax
000070bab59d16f5  add rsp, 0x08
000070bab59d16f9  jmp 0x000070BAB59CF8E7
000070bab59d16fe  sub rsp, 0x08
000070bab59d1702  push rax
000070bab59d1703  push rcx
000070bab59d1704  push rdx
000070bab59d1705  push rdi
000070bab59d1706  push rsi
000070bab59d1707  push r8
000070bab59d1709  push r9
000070bab59d170b  push r10
000070bab59d170d  push r11
000070bab59d170f  sub rsp, 0xF0
000070bab59d1716  vmovaps [rsp], xmm0
000070bab59d171b  vmovaps [rsp+0x10], xmm1
000070bab59d1721  vmovaps [rsp+0x20], xmm2
000070bab59d1727  vmovaps [rsp+0x30], xmm3
000070bab59d172d  vmovaps [rsp+0x40], xmm4
000070bab59d1733  vmovaps [rsp+0x50], xmm5
000070bab59d1739  vmovaps [rsp+0x60], xmm6
000070bab59d173f  vmovaps [rsp+0x70], xmm7
000070bab59d1745  vmovaps [rsp+0x80], xmm8
000070bab59d174e  vmovaps [rsp+0x90], xmm9
000070bab59d1757  vmovaps [rsp+0xA0], xmm10
000070bab59d1760  vmovaps [rsp+0xB0], xmm11
000070bab59d1769  vmovaps [rsp+0xC0], xmm12
000070bab59d1772  vmovaps [rsp+0xD0], xmm13
000070bab59d177b  vmovaps [rsp+0xE0], xmm14
000070bab59d1784  sub rsp, 0x30
000070bab59d1788  movaps [rsp], xmm15
000070bab59d178d  movaps [rsp+0x10], xmm2
000070bab59d1792  movaps [rsp+0x20], xmm1
000070bab59d1797  lea rdi, [rsp]
000070bab59d179b  mov esi, 0x00
000070bab59d17a0  mov rax, 0x63B35AFBC530
000070bab59d17aa  call rax
000070bab59d17ac  movaps xmm15, [rsp]
000070bab59d17b1  add rsp, 0x30
000070bab59d17b5  vmovaps xmm0, [rsp]
000070bab59d17ba  vmovaps xmm1, [rsp+0x10]
000070bab59d17c0  vmovaps xmm2, [rsp+0x20]
000070bab59d17c6  vmovaps xmm3, [rsp+0x30]
000070bab59d17cc  vmovaps xmm4, [rsp+0x40]
000070bab59d17d2  vmovaps xmm5, [rsp+0x50]
000070bab59d17d8  vmovaps xmm6, [rsp+0x60]
000070bab59d17de  vmovaps xmm7, [rsp+0x70]
000070bab59d17e4  vmovaps xmm8, [rsp+0x80]
000070bab59d17ed  vmovaps xmm9, [rsp+0x90]
000070bab59d17f6  vmovaps xmm10, [rsp+0xA0]
000070bab59d17ff  vmovaps xmm11, [rsp+0xB0]
000070bab59d1808  vmovaps xmm12, [rsp+0xC0]
000070bab59d1811  vmovaps xmm13, [rsp+0xD0]
000070bab59d181a  vmovaps xmm14, [rsp+0xE0]
000070bab59d1823  add rsp, 0xF0
000070bab59d182a  pop r11
000070bab59d182c  pop r10
000070bab59d182e  pop r9
000070bab59d1830  pop r8
000070bab59d1832  pop rsi
000070bab59d1833  pop rdi
000070bab59d1834  pop rdx
000070bab59d1835  pop rcx
000070bab59d1836  pop rax
000070bab59d1837  add rsp, 0x08
000070bab59d183b  jmp 0x000070BAB59CF923
000070bab59d1840  call 0x000070BAB57FF430
000070bab59d1845  jmp 0x000070BAB59CF930
000070bab59d184a  sub rsp, 0x08
000070bab59d184e  push rax
000070bab59d184f  push rcx
000070bab59d1850  push rdx
000070bab59d1851  push rdi
000070bab59d1852  push rsi
000070bab59d1853  push r8
000070bab59d1855  push r9
000070bab59d1857  push r10
000070bab59d1859  push r11
000070bab59d185b  sub rsp, 0xF0
000070bab59d1862  vmovaps [rsp], xmm0
000070bab59d1867  vmovaps [rsp+0x10], xmm1
000070bab59d186d  vmovaps [rsp+0x20], xmm3
000070bab59d1873  vmovaps [rsp+0x30], xmm4
000070bab59d1879  vmovaps [rsp+0x40], xmm5
000070bab59d187f  vmovaps [rsp+0x50], xmm6
000070bab59d1885  vmovaps [rsp+0x60], xmm7
000070bab59d188b  vmovaps [rsp+0x70], xmm8
000070bab59d1891  vmovaps [rsp+0x80], xmm9
000070bab59d189a  vmovaps [rsp+0x90], xmm10
000070bab59d18a3  vmovaps [rsp+0xA0], xmm11
000070bab59d18ac  vmovaps [rsp+0xB0], xmm12
000070bab59d18b5  vmovaps [rsp+0xC0], xmm13
000070bab59d18be  vmovaps [rsp+0xD0], xmm14
000070bab59d18c7  vmovaps [rsp+0xE0], xmm15
000070bab59d18d0  sub rsp, 0x30
000070bab59d18d4  movaps [rsp], xmm2
000070bab59d18d8  movaps [rsp+0x10], xmm1
000070bab59d18dd  movaps [rsp+0x20], xmm14
000070bab59d18e3  lea rdi, [rsp]
000070bab59d18e7  mov esi, 0x00
000070bab59d18ec  mov rax, 0x63B35AFBC530
000070bab59d18f6  call rax
000070bab59d18f8  movaps xmm2, [rsp]
000070bab59d18fc  add rsp, 0x30
000070bab59d1900  vmovaps xmm0, [rsp]
000070bab59d1905  vmovaps xmm1, [rsp+0x10]
000070bab59d190b  vmovaps xmm3, [rsp+0x20]
000070bab59d1911  vmovaps xmm4, [rsp+0x30]
000070bab59d1917  vmovaps xmm5, [rsp+0x40]
000070bab59d191d  vmovaps xmm6, [rsp+0x50]
000070bab59d1923  vmovaps xmm7, [rsp+0x60]
000070bab59d1929  vmovaps xmm8, [rsp+0x70]
000070bab59d192f  vmovaps xmm9, [rsp+0x80]
000070bab59d1938  vmovaps xmm10, [rsp+0x90]
000070bab59d1941  vmovaps xmm11, [rsp+0xA0]
000070bab59d194a  vmovaps xmm12, [rsp+0xB0]
000070bab59d1953  vmovaps xmm13, [rsp+0xC0]
000070bab59d195c  vmovaps xmm14, [rsp+0xD0]
000070bab59d1965  vmovaps xmm15, [rsp+0xE0]
000070bab59d196e  add rsp, 0xF0
000070bab59d1975  pop r11
000070bab59d1977  pop r10
000070bab59d1979  pop r9
000070bab59d197b  pop r8
000070bab59d197d  pop rsi
000070bab59d197e  pop rdi
000070bab59d197f  pop rdx
000070bab59d1980  pop rcx
000070bab59d1981  pop rax
000070bab59d1982  add rsp, 0x08
000070bab59d1986  jmp 0x000070BAB59CF96D
000070bab59d198b  sub rsp, 0x08
000070bab59d198f  push rax
000070bab59d1990  push rcx
000070bab59d1991  push rdx
000070bab59d1992  push rdi
000070bab59d1993  push rsi
000070bab59d1994  push r8
000070bab59d1996  push r9
000070bab59d1998  push r10
000070bab59d199a  push r11
000070bab59d199c  sub rsp, 0xF0
000070bab59d19a3  vmovaps [rsp], xmm0
000070bab59d19a8  vmovaps [rsp+0x10], xmm1
000070bab59d19ae  vmovaps [rsp+0x20], xmm2
000070bab59d19b4  vmovaps [rsp+0x30], xmm3
000070bab59d19ba  vmovaps [rsp+0x40], xmm4
000070bab59d19c0  vmovaps [rsp+0x50], xmm5
000070bab59d19c6  vmovaps [rsp+0x60], xmm6
000070bab59d19cc  vmovaps [rsp+0x70], xmm7
000070bab59d19d2  vmovaps [rsp+0x80], xmm8
000070bab59d19db  vmovaps [rsp+0x90], xmm9
000070bab59d19e4  vmovaps [rsp+0xA0], xmm10
000070bab59d19ed  vmovaps [rsp+0xB0], xmm11
000070bab59d19f6  vmovaps [rsp+0xC0], xmm12
000070bab59d19ff  vmovaps [rsp+0xD0], xmm13
000070bab59d1a08  vmovaps [rsp+0xE0], xmm14
000070bab59d1a11  sub rsp, 0x30
000070bab59d1a15  movaps [rsp], xmm15
000070bab59d1a1a  movaps [rsp+0x10], xmm14
000070bab59d1a20  movaps [rsp+0x20], xmm1
000070bab59d1a25  lea rdi, [rsp]
000070bab59d1a29  mov esi, 0x00
000070bab59d1a2e  mov rax, 0x63B35AFBC530
000070bab59d1a38  call rax
000070bab59d1a3a  movaps xmm15, [rsp]
000070bab59d1a3f  add rsp, 0x30
000070bab59d1a43  vmovaps xmm0, [rsp]
000070bab59d1a48  vmovaps xmm1, [rsp+0x10]
000070bab59d1a4e  vmovaps xmm2, [rsp+0x20]
000070bab59d1a54  vmovaps xmm3, [rsp+0x30]
000070bab59d1a5a  vmovaps xmm4, [rsp+0x40]
000070bab59d1a60  vmovaps xmm5, [rsp+0x50]
000070bab59d1a66  vmovaps xmm6, [rsp+0x60]
000070bab59d1a6c  vmovaps xmm7, [rsp+0x70]
000070bab59d1a72  vmovaps xmm8, [rsp+0x80]
000070bab59d1a7b  vmovaps xmm9, [rsp+0x90]
000070bab59d1a84  vmovaps xmm10, [rsp+0xA0]
000070bab59d1a8d  vmovaps xmm11, [rsp+0xB0]
000070bab59d1a96  vmovaps xmm12, [rsp+0xC0]
000070bab59d1a9f  vmovaps xmm13, [rsp+0xD0]
000070bab59d1aa8  vmovaps xmm14, [rsp+0xE0]
000070bab59d1ab1  add rsp, 0xF0
000070bab59d1ab8  pop r11
000070bab59d1aba  pop r10
000070bab59d1abc  pop r9
000070bab59d1abe  pop r8
000070bab59d1ac0  pop rsi
000070bab59d1ac1  pop rdi
000070bab59d1ac2  pop rdx
000070bab59d1ac3  pop rcx
000070bab59d1ac4  pop rax
000070bab59d1ac5  add rsp, 0x08
000070bab59d1ac9  jmp 0x000070BAB59CF9E7
000070bab59d1ace  call 0x000070BAB57FF430
000070bab59d1ad3  jmp 0x000070BAB59CF9F4
000070bab59d1ad8  sub rsp, 0x08
000070bab59d1adc  push rax
000070bab59d1add  push rcx
000070bab59d1ade  push rdx
000070bab59d1adf  push rdi
000070bab59d1ae0  push rsi
000070bab59d1ae1  push r8
000070bab59d1ae3  push r9
000070bab59d1ae5  push r10
000070bab59d1ae7  push r11
000070bab59d1ae9  sub rsp, 0xF0
000070bab59d1af0  vmovaps [rsp], xmm0
000070bab59d1af5  vmovaps [rsp+0x10], xmm1
000070bab59d1afb  vmovaps [rsp+0x20], xmm2
000070bab59d1b01  vmovaps [rsp+0x30], xmm3
000070bab59d1b07  vmovaps [rsp+0x40], xmm4
000070bab59d1b0d  vmovaps [rsp+0x50], xmm5
000070bab59d1b13  vmovaps [rsp+0x60], xmm6
000070bab59d1b19  vmovaps [rsp+0x70], xmm7
000070bab59d1b1f  vmovaps [rsp+0x80], xmm8
000070bab59d1b28  vmovaps [rsp+0x90], xmm9
000070bab59d1b31  vmovaps [rsp+0xA0], xmm10
000070bab59d1b3a  vmovaps [rsp+0xB0], xmm11
000070bab59d1b43  vmovaps [rsp+0xC0], xmm12
000070bab59d1b4c  vmovaps [rsp+0xD0], xmm13
000070bab59d1b55  vmovaps [rsp+0xE0], xmm15
000070bab59d1b5e  sub rsp, 0x30
000070bab59d1b62  movaps [rsp], xmm14
000070bab59d1b67  movaps [rsp+0x10], xmm13
000070bab59d1b6d  movaps [rsp+0x20], xmm1
000070bab59d1b72  lea rdi, [rsp]
000070bab59d1b76  mov esi, 0x00
000070bab59d1b7b  mov rax, 0x63B35AFBC530
000070bab59d1b85  call rax
000070bab59d1b87  movaps xmm14, [rsp]
000070bab59d1b8c  add rsp, 0x30
000070bab59d1b90  vmovaps xmm0, [rsp]
000070bab59d1b95  vmovaps xmm1, [rsp+0x10]
000070bab59d1b9b  vmovaps xmm2, [rsp+0x20]
000070bab59d1ba1  vmovaps xmm3, [rsp+0x30]
000070bab59d1ba7  vmovaps xmm4, [rsp+0x40]
000070bab59d1bad  vmovaps xmm5, [rsp+0x50]
000070bab59d1bb3  vmovaps xmm6, [rsp+0x60]
000070bab59d1bb9  vmovaps xmm7, [rsp+0x70]
000070bab59d1bbf  vmovaps xmm8, [rsp+0x80]
000070bab59d1bc8  vmovaps xmm9, [rsp+0x90]
000070bab59d1bd1  vmovaps xmm10, [rsp+0xA0]
000070bab59d1bda  vmovaps xmm11, [rsp+0xB0]
000070bab59d1be3  vmovaps xmm12, [rsp+0xC0]
000070bab59d1bec  vmovaps xmm13, [rsp+0xD0]
000070bab59d1bf5  vmovaps xmm15, [rsp+0xE0]
000070bab59d1bfe  add rsp, 0xF0
000070bab59d1c05  pop r11
000070bab59d1c07  pop r10
000070bab59d1c09  pop r9
000070bab59d1c0b  pop r8
000070bab59d1c0d  pop rsi
000070bab59d1c0e  pop rdi
000070bab59d1c0f  pop rdx
000070bab59d1c10  pop rcx
000070bab59d1c11  pop rax
000070bab59d1c12  add rsp, 0x08
000070bab59d1c16  jmp 0x000070BAB59CFAAF
000070bab59d1c1b  sub rsp, 0x08
000070bab59d1c1f  push rax
000070bab59d1c20  push rcx
000070bab59d1c21  push rdx
000070bab59d1c22  push rdi
000070bab59d1c23  push rsi
000070bab59d1c24  push r8
000070bab59d1c26  push r9
000070bab59d1c28  push r10
000070bab59d1c2a  push r11
000070bab59d1c2c  sub rsp, 0xF0
000070bab59d1c33  vmovaps [rsp], xmm0
000070bab59d1c38  vmovaps [rsp+0x10], xmm1
000070bab59d1c3e  vmovaps [rsp+0x20], xmm2
000070bab59d1c44  vmovaps [rsp+0x30], xmm3
000070bab59d1c4a  vmovaps [rsp+0x40], xmm4
000070bab59d1c50  vmovaps [rsp+0x50], xmm5
000070bab59d1c56  vmovaps [rsp+0x60], xmm6
000070bab59d1c5c  vmovaps [rsp+0x70], xmm7
000070bab59d1c62  vmovaps [rsp+0x80], xmm8
000070bab59d1c6b  vmovaps [rsp+0x90], xmm9
000070bab59d1c74  vmovaps [rsp+0xA0], xmm10
000070bab59d1c7d  vmovaps [rsp+0xB0], xmm11
000070bab59d1c86  vmovaps [rsp+0xC0], xmm12
000070bab59d1c8f  vmovaps [rsp+0xD0], xmm13
000070bab59d1c98  vmovaps [rsp+0xE0], xmm14
000070bab59d1ca1  sub rsp, 0x30
000070bab59d1ca5  movaps [rsp], xmm15
000070bab59d1caa  movaps [rsp+0x10], xmm13
000070bab59d1cb0  movaps [rsp+0x20], xmm1
000070bab59d1cb5  lea rdi, [rsp]
000070bab59d1cb9  mov esi, 0x00
000070bab59d1cbe  mov rax, 0x63B35AFBC530
000070bab59d1cc8  call rax
000070bab59d1cca  movaps xmm15, [rsp]
000070bab59d1ccf  add rsp, 0x30
000070bab59d1cd3  vmovaps xmm0, [rsp]
000070bab59d1cd8  vmovaps xmm1, [rsp+0x10]
000070bab59d1cde  vmovaps xmm2, [rsp+0x20]
000070bab59d1ce4  vmovaps xmm3, [rsp+0x30]
000070bab59d1cea  vmovaps xmm4, [rsp+0x40]
000070bab59d1cf0  vmovaps xmm5, [rsp+0x50]
000070bab59d1cf6  vmovaps xmm6, [rsp+0x60]
000070bab59d1cfc  vmovaps xmm7, [rsp+0x70]
000070bab59d1d02  vmovaps xmm8, [rsp+0x80]
000070bab59d1d0b  vmovaps xmm9, [rsp+0x90]
000070bab59d1d14  vmovaps xmm10, [rsp+0xA0]
000070bab59d1d1d  vmovaps xmm11, [rsp+0xB0]
000070bab59d1d26  vmovaps xmm12, [rsp+0xC0]
000070bab59d1d2f  vmovaps xmm13, [rsp+0xD0]
000070bab59d1d38  vmovaps xmm14, [rsp+0xE0]
000070bab59d1d41  add rsp, 0xF0
000070bab59d1d48  pop r11
000070bab59d1d4a  pop r10
000070bab59d1d4c  pop r9
000070bab59d1d4e  pop r8
000070bab59d1d50  pop rsi
000070bab59d1d51  pop rdi
000070bab59d1d52  pop rdx
000070bab59d1d53  pop rcx
000070bab59d1d54  pop rax
000070bab59d1d55  add rsp, 0x08
000070bab59d1d59  jmp 0x000070BAB59CFAEB
000070bab59d1d5e  call 0x000070BAB57FF430
000070bab59d1d63  jmp 0x000070BAB59CFAF8
000070bab59d1d68  sub rsp, 0x08
000070bab59d1d6c  push rax
000070bab59d1d6d  push rcx
000070bab59d1d6e  push rdx
000070bab59d1d6f  push rdi
000070bab59d1d70  push rsi
000070bab59d1d71  push r8
000070bab59d1d73  push r9
000070bab59d1d75  push r10
000070bab59d1d77  push r11
000070bab59d1d79  sub rsp, 0xF0
000070bab59d1d80  vmovaps [rsp], xmm0
000070bab59d1d85  vmovaps [rsp+0x10], xmm1
000070bab59d1d8b  vmovaps [rsp+0x20], xmm2
000070bab59d1d91  vmovaps [rsp+0x30], xmm3
000070bab59d1d97  vmovaps [rsp+0x40], xmm4
000070bab59d1d9d  vmovaps [rsp+0x50], xmm5
000070bab59d1da3  vmovaps [rsp+0x60], xmm6
000070bab59d1da9  vmovaps [rsp+0x70], xmm7
000070bab59d1daf  vmovaps [rsp+0x80], xmm8
000070bab59d1db8  vmovaps [rsp+0x90], xmm9
000070bab59d1dc1  vmovaps [rsp+0xA0], xmm10
000070bab59d1dca  vmovaps [rsp+0xB0], xmm11
000070bab59d1dd3  vmovaps [rsp+0xC0], xmm12
000070bab59d1ddc  vmovaps [rsp+0xD0], xmm13
000070bab59d1de5  vmovaps [rsp+0xE0], xmm15
000070bab59d1dee  sub rsp, 0x30
000070bab59d1df2  movaps [rsp], xmm14
000070bab59d1df7  movaps [rsp+0x10], xmm13
000070bab59d1dfd  movaps [rsp+0x20], xmm2
000070bab59d1e02  lea rdi, [rsp]
000070bab59d1e06  mov esi, 0x00
000070bab59d1e0b  mov rax, 0x63B35AFBC530
000070bab59d1e15  call rax
000070bab59d1e17  movaps xmm14, [rsp]
000070bab59d1e1c  add rsp, 0x30
000070bab59d1e20  vmovaps xmm0, [rsp]
000070bab59d1e25  vmovaps xmm1, [rsp+0x10]
000070bab59d1e2b  vmovaps xmm2, [rsp+0x20]
000070bab59d1e31  vmovaps xmm3, [rsp+0x30]
000070bab59d1e37  vmovaps xmm4, [rsp+0x40]
000070bab59d1e3d  vmovaps xmm5, [rsp+0x50]
000070bab59d1e43  vmovaps xmm6, [rsp+0x60]
000070bab59d1e49  vmovaps xmm7, [rsp+0x70]
000070bab59d1e4f  vmovaps xmm8, [rsp+0x80]
000070bab59d1e58  vmovaps xmm9, [rsp+0x90]
000070bab59d1e61  vmovaps xmm10, [rsp+0xA0]
000070bab59d1e6a  vmovaps xmm11, [rsp+0xB0]
000070bab59d1e73  vmovaps xmm12, [rsp+0xC0]
000070bab59d1e7c  vmovaps xmm13, [rsp+0xD0]
000070bab59d1e85  vmovaps xmm15, [rsp+0xE0]
000070bab59d1e8e  add rsp, 0xF0
000070bab59d1e95  pop r11
000070bab59d1e97  pop r10
000070bab59d1e99  pop r9
000070bab59d1e9b  pop r8
000070bab59d1e9d  pop rsi
000070bab59d1e9e  pop rdi
000070bab59d1e9f  pop rdx
000070bab59d1ea0  pop rcx
000070bab59d1ea1  pop rax
000070bab59d1ea2  add rsp, 0x08
000070bab59d1ea6  jmp 0x000070BAB59CFB24
000070bab59d1eab  sub rsp, 0x08
000070bab59d1eaf  push rax
000070bab59d1eb0  push rcx
000070bab59d1eb1  push rdx
000070bab59d1eb2  push rdi
000070bab59d1eb3  push rsi
000070bab59d1eb4  push r8
000070bab59d1eb6  push r9
000070bab59d1eb8  push r10
000070bab59d1eba  push r11
000070bab59d1ebc  sub rsp, 0xF0
000070bab59d1ec3  vmovaps [rsp], xmm0
000070bab59d1ec8  vmovaps [rsp+0x10], xmm2
000070bab59d1ece  vmovaps [rsp+0x20], xmm3
000070bab59d1ed4  vmovaps [rsp+0x30], xmm4
000070bab59d1eda  vmovaps [rsp+0x40], xmm5
000070bab59d1ee0  vmovaps [rsp+0x50], xmm6
000070bab59d1ee6  vmovaps [rsp+0x60], xmm7
000070bab59d1eec  vmovaps [rsp+0x70], xmm8
000070bab59d1ef2  vmovaps [rsp+0x80], xmm9
000070bab59d1efb  vmovaps [rsp+0x90], xmm10
000070bab59d1f04  vmovaps [rsp+0xA0], xmm11
000070bab59d1f0d  vmovaps [rsp+0xB0], xmm12
000070bab59d1f16  vmovaps [rsp+0xC0], xmm13
000070bab59d1f1f  vmovaps [rsp+0xD0], xmm14
000070bab59d1f28  vmovaps [rsp+0xE0], xmm15
000070bab59d1f31  sub rsp, 0x30
000070bab59d1f35  movaps [rsp], xmm1
000070bab59d1f39  movaps [rsp+0x10], xmm13
000070bab59d1f3f  movaps [rsp+0x20], xmm2
000070bab59d1f44  lea rdi, [rsp]
000070bab59d1f48  mov esi, 0x00
000070bab59d1f4d  mov rax, 0x63B35AFBC530
000070bab59d1f57  call rax
000070bab59d1f59  movaps xmm1, [rsp]
000070bab59d1f5d  add rsp, 0x30
000070bab59d1f61  vmovaps xmm0, [rsp]
000070bab59d1f66  vmovaps xmm2, [rsp+0x10]
000070bab59d1f6c  vmovaps xmm3, [rsp+0x20]
000070bab59d1f72  vmovaps xmm4, [rsp+0x30]
000070bab59d1f78  vmovaps xmm5, [rsp+0x40]
000070bab59d1f7e  vmovaps xmm6, [rsp+0x50]
000070bab59d1f84  vmovaps xmm7, [rsp+0x60]
000070bab59d1f8a  vmovaps xmm8, [rsp+0x70]
000070bab59d1f90  vmovaps xmm9, [rsp+0x80]
000070bab59d1f99  vmovaps xmm10, [rsp+0x90]
000070bab59d1fa2  vmovaps xmm11, [rsp+0xA0]
000070bab59d1fab  vmovaps xmm12, [rsp+0xB0]
000070bab59d1fb4  vmovaps xmm13, [rsp+0xC0]
000070bab59d1fbd  vmovaps xmm14, [rsp+0xD0]
000070bab59d1fc6  vmovaps xmm15, [rsp+0xE0]
000070bab59d1fcf  add rsp, 0xF0
000070bab59d1fd6  pop r11
000070bab59d1fd8  pop r10
000070bab59d1fda  pop r9
000070bab59d1fdc  pop r8
000070bab59d1fde  pop rsi
000070bab59d1fdf  pop rdi
000070bab59d1fe0  pop rdx
000070bab59d1fe1  pop rcx
000070bab59d1fe2  pop rax
000070bab59d1fe3  add rsp, 0x08
000070bab59d1fe7  jmp 0x000070BAB59CFB52
000070bab59d1fec  sub rsp, 0x08
000070bab59d1ff0  push rax
000070bab59d1ff1  push rcx
000070bab59d1ff2  push rdx
000070bab59d1ff3  push rdi
000070bab59d1ff4  push rsi
000070bab59d1ff5  push r8
000070bab59d1ff7  push r9
000070bab59d1ff9  push r10
000070bab59d1ffb  push r11
000070bab59d1ffd  sub rsp, 0xF0
000070bab59d2004  vmovaps [rsp], xmm0
000070bab59d2009  vmovaps [rsp+0x10], xmm1
000070bab59d200f  vmovaps [rsp+0x20], xmm3
000070bab59d2015  vmovaps [rsp+0x30], xmm4
000070bab59d201b  vmovaps [rsp+0x40], xmm5
000070bab59d2021  vmovaps [rsp+0x50], xmm6
000070bab59d2027  vmovaps [rsp+0x60], xmm7
000070bab59d202d  vmovaps [rsp+0x70], xmm8
000070bab59d2033  vmovaps [rsp+0x80], xmm9
000070bab59d203c  vmovaps [rsp+0x90], xmm10
000070bab59d2045  vmovaps [rsp+0xA0], xmm11
000070bab59d204e  vmovaps [rsp+0xB0], xmm12
000070bab59d2057  vmovaps [rsp+0xC0], xmm13
000070bab59d2060  vmovaps [rsp+0xD0], xmm14
000070bab59d2069  vmovaps [rsp+0xE0], xmm15
000070bab59d2072  sub rsp, 0x30
000070bab59d2076  movaps [rsp], xmm2
000070bab59d207a  movaps [rsp+0x10], xmm1
000070bab59d207f  movaps [rsp+0x20], xmm13
000070bab59d2085  lea rdi, [rsp]
000070bab59d2089  mov esi, 0x00
000070bab59d208e  mov rax, 0x63B35AFBC530
000070bab59d2098  call rax
000070bab59d209a  movaps xmm2, [rsp]
000070bab59d209e  add rsp, 0x30
000070bab59d20a2  vmovaps xmm0, [rsp]
000070bab59d20a7  vmovaps xmm1, [rsp+0x10]
000070bab59d20ad  vmovaps xmm3, [rsp+0x20]
000070bab59d20b3  vmovaps xmm4, [rsp+0x30]
000070bab59d20b9  vmovaps xmm5, [rsp+0x40]
000070bab59d20bf  vmovaps xmm6, [rsp+0x50]
000070bab59d20c5  vmovaps xmm7, [rsp+0x60]
000070bab59d20cb  vmovaps xmm8, [rsp+0x70]
000070bab59d20d1  vmovaps xmm9, [rsp+0x80]
000070bab59d20da  vmovaps xmm10, [rsp+0x90]
000070bab59d20e3  vmovaps xmm11, [rsp+0xA0]
000070bab59d20ec  vmovaps xmm12, [rsp+0xB0]
000070bab59d20f5  vmovaps xmm13, [rsp+0xC0]
000070bab59d20fe  vmovaps xmm14, [rsp+0xD0]
000070bab59d2107  vmovaps xmm15, [rsp+0xE0]
000070bab59d2110  add rsp, 0xF0
000070bab59d2117  pop r11
000070bab59d2119  pop r10
000070bab59d211b  pop r9
000070bab59d211d  pop r8
000070bab59d211f  pop rsi
000070bab59d2120  pop rdi
000070bab59d2121  pop rdx
000070bab59d2122  pop rcx
000070bab59d2123  pop rax
000070bab59d2124  add rsp, 0x08
000070bab59d2128  jmp 0x000070BAB59CFBAB
000070bab59d212d  call 0x000070BAB57FF430
000070bab59d2132  jmp 0x000070BAB59CFBB8
000070bab59d2137  sub rsp, 0x08
000070bab59d213b  push rax
000070bab59d213c  push rcx
000070bab59d213d  push rdx
000070bab59d213e  push rdi
000070bab59d213f  push rsi
000070bab59d2140  push r8
000070bab59d2142  push r9
000070bab59d2144  push r10
000070bab59d2146  push r11
000070bab59d2148  sub rsp, 0xF0
000070bab59d214f  vmovaps [rsp], xmm0
000070bab59d2154  vmovaps [rsp+0x10], xmm1
000070bab59d215a  vmovaps [rsp+0x20], xmm2
000070bab59d2160  vmovaps [rsp+0x30], xmm3
000070bab59d2166  vmovaps [rsp+0x40], xmm4
000070bab59d216c  vmovaps [rsp+0x50], xmm5
000070bab59d2172  vmovaps [rsp+0x60], xmm6
000070bab59d2178  vmovaps [rsp+0x70], xmm7
000070bab59d217e  vmovaps [rsp+0x80], xmm8
000070bab59d2187  vmovaps [rsp+0x90], xmm9
000070bab59d2190  vmovaps [rsp+0xA0], xmm10
000070bab59d2199  vmovaps [rsp+0xB0], xmm11
000070bab59d21a2  vmovaps [rsp+0xC0], xmm12
000070bab59d21ab  vmovaps [rsp+0xD0], xmm13
000070bab59d21b4  vmovaps [rsp+0xE0], xmm14
000070bab59d21bd  sub rsp, 0x30
000070bab59d21c1  movaps [rsp], xmm15
000070bab59d21c6  movaps [rsp+0x10], xmm13
000070bab59d21cc  movaps [rsp+0x20], xmm1
000070bab59d21d1  lea rdi, [rsp]
000070bab59d21d5  mov esi, 0x00
000070bab59d21da  mov rax, 0x63B35AFBC530
000070bab59d21e4  call rax
000070bab59d21e6  movaps xmm15, [rsp]
000070bab59d21eb  add rsp, 0x30
000070bab59d21ef  vmovaps xmm0, [rsp]
000070bab59d21f4  vmovaps xmm1, [rsp+0x10]
000070bab59d21fa  vmovaps xmm2, [rsp+0x20]
000070bab59d2200  vmovaps xmm3, [rsp+0x30]
000070bab59d2206  vmovaps xmm4, [rsp+0x40]
000070bab59d220c  vmovaps xmm5, [rsp+0x50]
000070bab59d2212  vmovaps xmm6, [rsp+0x60]
000070bab59d2218  vmovaps xmm7, [rsp+0x70]
000070bab59d221e  vmovaps xmm8, [rsp+0x80]
000070bab59d2227  vmovaps xmm9, [rsp+0x90]
000070bab59d2230  vmovaps xmm10, [rsp+0xA0]
000070bab59d2239  vmovaps xmm11, [rsp+0xB0]
000070bab59d2242  vmovaps xmm12, [rsp+0xC0]
000070bab59d224b  vmovaps xmm13, [rsp+0xD0]
000070bab59d2254  vmovaps xmm14, [rsp+0xE0]
000070bab59d225d  add rsp, 0xF0
000070bab59d2264  pop r11
000070bab59d2266  pop r10
000070bab59d2268  pop r9
000070bab59d226a  pop r8
000070bab59d226c  pop rsi
000070bab59d226d  pop rdi
000070bab59d226e  pop rdx
000070bab59d226f  pop rcx
000070bab59d2270  pop rax
000070bab59d2271  add rsp, 0x08
000070bab59d2275  jmp 0x000070BAB59CFBF7
000070bab59d227a  sub rsp, 0x08
000070bab59d227e  push rax
000070bab59d227f  push rcx
000070bab59d2280  push rdx
000070bab59d2281  push rdi
000070bab59d2282  push rsi
000070bab59d2283  push r8
000070bab59d2285  push r9
000070bab59d2287  push r10
000070bab59d2289  push r11
000070bab59d228b  sub rsp, 0xF0
000070bab59d2292  vmovaps [rsp], xmm0
000070bab59d2297  vmovaps [rsp+0x10], xmm1
000070bab59d229d  vmovaps [rsp+0x20], xmm2
000070bab59d22a3  vmovaps [rsp+0x30], xmm3
000070bab59d22a9  vmovaps [rsp+0x40], xmm4
000070bab59d22af  vmovaps [rsp+0x50], xmm5
000070bab59d22b5  vmovaps [rsp+0x60], xmm6
000070bab59d22bb  vmovaps [rsp+0x70], xmm7
000070bab59d22c1  vmovaps [rsp+0x80], xmm8
000070bab59d22ca  vmovaps [rsp+0x90], xmm9
000070bab59d22d3  vmovaps [rsp+0xA0], xmm10
000070bab59d22dc  vmovaps [rsp+0xB0], xmm11
000070bab59d22e5  vmovaps [rsp+0xC0], xmm12
000070bab59d22ee  vmovaps [rsp+0xD0], xmm13
000070bab59d22f7  vmovaps [rsp+0xE0], xmm15
000070bab59d2300  sub rsp, 0x30
000070bab59d2304  movaps [rsp], xmm14
000070bab59d2309  movaps [rsp+0x10], xmm11
000070bab59d230f  movaps [rsp+0x20], xmm1
000070bab59d2314  lea rdi, [rsp]
000070bab59d2318  mov esi, 0x00
000070bab59d231d  mov rax, 0x63B35AFBC530
000070bab59d2327  call rax
000070bab59d2329  movaps xmm14, [rsp]
000070bab59d232e  add rsp, 0x30
000070bab59d2332  vmovaps xmm0, [rsp]
000070bab59d2337  vmovaps xmm1, [rsp+0x10]
000070bab59d233d  vmovaps xmm2, [rsp+0x20]
000070bab59d2343  vmovaps xmm3, [rsp+0x30]
000070bab59d2349  vmovaps xmm4, [rsp+0x40]
000070bab59d234f  vmovaps xmm5, [rsp+0x50]
000070bab59d2355  vmovaps xmm6, [rsp+0x60]
000070bab59d235b  vmovaps xmm7, [rsp+0x70]
000070bab59d2361  vmovaps xmm8, [rsp+0x80]
000070bab59d236a  vmovaps xmm9, [rsp+0x90]
000070bab59d2373  vmovaps xmm10, [rsp+0xA0]
000070bab59d237c  vmovaps xmm11, [rsp+0xB0]
000070bab59d2385  vmovaps xmm12, [rsp+0xC0]
000070bab59d238e  vmovaps xmm13, [rsp+0xD0]
000070bab59d2397  vmovaps xmm15, [rsp+0xE0]
000070bab59d23a0  add rsp, 0xF0
000070bab59d23a7  pop r11
000070bab59d23a9  pop r10
000070bab59d23ab  pop r9
000070bab59d23ad  pop r8
000070bab59d23af  pop rsi
000070bab59d23b0  pop rdi
000070bab59d23b1  pop rdx
000070bab59d23b2  pop rcx
000070bab59d23b3  pop rax
000070bab59d23b4  add rsp, 0x08
000070bab59d23b8  jmp 0x000070BAB59CFC21
000070bab59d23bd  sub rsp, 0x08
000070bab59d23c1  push rax
000070bab59d23c2  push rcx
000070bab59d23c3  push rdx
000070bab59d23c4  push rdi
000070bab59d23c5  push rsi
000070bab59d23c6  push r8
000070bab59d23c8  push r9
000070bab59d23ca  push r10
000070bab59d23cc  push r11
000070bab59d23ce  sub rsp, 0xF0
000070bab59d23d5  vmovaps [rsp], xmm0
000070bab59d23da  vmovaps [rsp+0x10], xmm1
000070bab59d23e0  vmovaps [rsp+0x20], xmm2
000070bab59d23e6  vmovaps [rsp+0x30], xmm3
000070bab59d23ec  vmovaps [rsp+0x40], xmm4
000070bab59d23f2  vmovaps [rsp+0x50], xmm5
000070bab59d23f8  vmovaps [rsp+0x60], xmm6
000070bab59d23fe  vmovaps [rsp+0x70], xmm7
000070bab59d2404  vmovaps [rsp+0x80], xmm8
000070bab59d240d  vmovaps [rsp+0x90], xmm9
000070bab59d2416  vmovaps [rsp+0xA0], xmm10
000070bab59d241f  vmovaps [rsp+0xB0], xmm11
000070bab59d2428  vmovaps [rsp+0xC0], xmm12
000070bab59d2431  vmovaps [rsp+0xD0], xmm14
000070bab59d243a  vmovaps [rsp+0xE0], xmm15
000070bab59d2443  sub rsp, 0x30
000070bab59d2447  movaps [rsp], xmm13
000070bab59d244c  movaps [rsp+0x10], xmm11
000070bab59d2452  movaps [rsp+0x20], xmm1
000070bab59d2457  lea rdi, [rsp]
000070bab59d245b  mov esi, 0x00
000070bab59d2460  mov rax, 0x63B35AFBC530
000070bab59d246a  call rax
000070bab59d246c  movaps xmm13, [rsp]
000070bab59d2471  add rsp, 0x30
000070bab59d2475  vmovaps xmm0, [rsp]
000070bab59d247a  vmovaps xmm1, [rsp+0x10]
000070bab59d2480  vmovaps xmm2, [rsp+0x20]
000070bab59d2486  vmovaps xmm3, [rsp+0x30]
000070bab59d248c  vmovaps xmm4, [rsp+0x40]
000070bab59d2492  vmovaps xmm5, [rsp+0x50]
000070bab59d2498  vmovaps xmm6, [rsp+0x60]
000070bab59d249e  vmovaps xmm7, [rsp+0x70]
000070bab59d24a4  vmovaps xmm8, [rsp+0x80]
000070bab59d24ad  vmovaps xmm9, [rsp+0x90]
000070bab59d24b6  vmovaps xmm10, [rsp+0xA0]
000070bab59d24bf  vmovaps xmm11, [rsp+0xB0]
000070bab59d24c8  vmovaps xmm12, [rsp+0xC0]
000070bab59d24d1  vmovaps xmm14, [rsp+0xD0]
000070bab59d24da  vmovaps xmm15, [rsp+0xE0]
000070bab59d24e3  add rsp, 0xF0
000070bab59d24ea  pop r11
000070bab59d24ec  pop r10
000070bab59d24ee  pop r9
000070bab59d24f0  pop r8
000070bab59d24f2  pop rsi
000070bab59d24f3  pop rdi
000070bab59d24f4  pop rdx
000070bab59d24f5  pop rcx
000070bab59d24f6  pop rax
000070bab59d24f7  add rsp, 0x08
000070bab59d24fb  jmp 0x000070BAB59CFC76
000070bab59d2500  call 0x000070BAB57FF430
000070bab59d2505  jmp 0x000070BAB59CFC83
000070bab59d250a  sub rsp, 0x08
000070bab59d250e  push rax
000070bab59d250f  push rcx
000070bab59d2510  push rdx
000070bab59d2511  push rdi
000070bab59d2512  push rsi
000070bab59d2513  push r8
000070bab59d2515  push r9
000070bab59d2517  push r10
000070bab59d2519  push r11
000070bab59d251b  sub rsp, 0xF0
000070bab59d2522  vmovaps [rsp], xmm0
000070bab59d2527  vmovaps [rsp+0x10], xmm1
000070bab59d252d  vmovaps [rsp+0x20], xmm2
000070bab59d2533  vmovaps [rsp+0x30], xmm3
000070bab59d2539  vmovaps [rsp+0x40], xmm4
000070bab59d253f  vmovaps [rsp+0x50], xmm5
000070bab59d2545  vmovaps [rsp+0x60], xmm6
000070bab59d254b  vmovaps [rsp+0x70], xmm7
000070bab59d2551  vmovaps [rsp+0x80], xmm8
000070bab59d255a  vmovaps [rsp+0x90], xmm9
000070bab59d2563  vmovaps [rsp+0xA0], xmm10
000070bab59d256c  vmovaps [rsp+0xB0], xmm11
000070bab59d2575  vmovaps [rsp+0xC0], xmm12
000070bab59d257e  vmovaps [rsp+0xD0], xmm13
000070bab59d2587  vmovaps [rsp+0xE0], xmm14
000070bab59d2590  sub rsp, 0x30
000070bab59d2594  movaps [rsp], xmm15
000070bab59d2599  movaps [rsp+0x10], xmm11
000070bab59d259f  movaps [rsp+0x20], xmm1
000070bab59d25a4  lea rdi, [rsp]
000070bab59d25a8  mov esi, 0x00
000070bab59d25ad  mov rax, 0x63B35AFBC530
000070bab59d25b7  call rax
000070bab59d25b9  movaps xmm15, [rsp]
000070bab59d25be  add rsp, 0x30
000070bab59d25c2  vmovaps xmm0, [rsp]
000070bab59d25c7  vmovaps xmm1, [rsp+0x10]
000070bab59d25cd  vmovaps xmm2, [rsp+0x20]
000070bab59d25d3  vmovaps xmm3, [rsp+0x30]
000070bab59d25d9  vmovaps xmm4, [rsp+0x40]
000070bab59d25df  vmovaps xmm5, [rsp+0x50]
000070bab59d25e5  vmovaps xmm6, [rsp+0x60]
000070bab59d25eb  vmovaps xmm7, [rsp+0x70]
000070bab59d25f1  vmovaps xmm8, [rsp+0x80]
000070bab59d25fa  vmovaps xmm9, [rsp+0x90]
000070bab59d2603  vmovaps xmm10, [rsp+0xA0]
000070bab59d260c  vmovaps xmm11, [rsp+0xB0]
000070bab59d2615  vmovaps xmm12, [rsp+0xC0]
000070bab59d261e  vmovaps xmm13, [rsp+0xD0]
000070bab59d2627  vmovaps xmm14, [rsp+0xE0]
000070bab59d2630  add rsp, 0xF0
000070bab59d2637  pop r11
000070bab59d2639  pop r10
000070bab59d263b  pop r9
000070bab59d263d  pop r8
000070bab59d263f  pop rsi
000070bab59d2640  pop rdi
000070bab59d2641  pop rdx
000070bab59d2642  pop rcx
000070bab59d2643  pop rax
000070bab59d2644  add rsp, 0x08
000070bab59d2648  jmp 0x000070BAB59CFCBC
000070bab59d264d  sub rsp, 0x08
000070bab59d2651  push rax
000070bab59d2652  push rcx
000070bab59d2653  push rdx
000070bab59d2654  push rdi
000070bab59d2655  push rsi
000070bab59d2656  push r8
000070bab59d2658  push r9
000070bab59d265a  push r10
000070bab59d265c  push r11
000070bab59d265e  sub rsp, 0xF0
000070bab59d2665  vmovaps [rsp], xmm0
000070bab59d266a  vmovaps [rsp+0x10], xmm1
000070bab59d2670  vmovaps [rsp+0x20], xmm2
000070bab59d2676  vmovaps [rsp+0x30], xmm3
000070bab59d267c  vmovaps [rsp+0x40], xmm4
000070bab59d2682  vmovaps [rsp+0x50], xmm5
000070bab59d2688  vmovaps [rsp+0x60], xmm6
000070bab59d268e  vmovaps [rsp+0x70], xmm7
000070bab59d2694  vmovaps [rsp+0x80], xmm8
000070bab59d269d  vmovaps [rsp+0x90], xmm9
000070bab59d26a6  vmovaps [rsp+0xA0], xmm10
000070bab59d26af  vmovaps [rsp+0xB0], xmm12
000070bab59d26b8  vmovaps [rsp+0xC0], xmm13
000070bab59d26c1  vmovaps [rsp+0xD0], xmm14
000070bab59d26ca  vmovaps [rsp+0xE0], xmm15
000070bab59d26d3  sub rsp, 0x30
000070bab59d26d7  movaps [rsp], xmm11
000070bab59d26dc  movaps [rsp+0x10], xmm6
000070bab59d26e1  movaps [rsp+0x20], xmm14
000070bab59d26e7  lea rdi, [rsp]
000070bab59d26eb  mov esi, 0x00
000070bab59d26f0  mov rax, 0x63B35AFBC530
000070bab59d26fa  call rax
000070bab59d26fc  movaps xmm11, [rsp]
000070bab59d2701  add rsp, 0x30
000070bab59d2705  vmovaps xmm0, [rsp]
000070bab59d270a  vmovaps xmm1, [rsp+0x10]
000070bab59d2710  vmovaps xmm2, [rsp+0x20]
000070bab59d2716  vmovaps xmm3, [rsp+0x30]
000070bab59d271c  vmovaps xmm4, [rsp+0x40]
000070bab59d2722  vmovaps xmm5, [rsp+0x50]
000070bab59d2728  vmovaps xmm6, [rsp+0x60]
000070bab59d272e  vmovaps xmm7, [rsp+0x70]
000070bab59d2734  vmovaps xmm8, [rsp+0x80]
000070bab59d273d  vmovaps xmm9, [rsp+0x90]
000070bab59d2746  vmovaps xmm10, [rsp+0xA0]
000070bab59d274f  vmovaps xmm12, [rsp+0xB0]
000070bab59d2758  vmovaps xmm13, [rsp+0xC0]
000070bab59d2761  vmovaps xmm14, [rsp+0xD0]
000070bab59d276a  vmovaps xmm15, [rsp+0xE0]
000070bab59d2773  add rsp, 0xF0
000070bab59d277a  pop r11
000070bab59d277c  pop r10
000070bab59d277e  pop r9
000070bab59d2780  pop r8
000070bab59d2782  pop rsi
000070bab59d2783  pop rdi
000070bab59d2784  pop rdx
000070bab59d2785  pop rcx
000070bab59d2786  pop rax
000070bab59d2787  add rsp, 0x08
000070bab59d278b  jmp 0x000070BAB59CFD34
000070bab59d2790  call 0x000070BAB57FF430
000070bab59d2795  jmp 0x000070BAB59CFD3E
000070bab59d279a  sub rsp, 0x08
000070bab59d279e  push rax
000070bab59d279f  push rcx
000070bab59d27a0  push rdx
000070bab59d27a1  push rdi
000070bab59d27a2  push rsi
000070bab59d27a3  push r8
000070bab59d27a5  push r9
000070bab59d27a7  push r10
000070bab59d27a9  push r11
000070bab59d27ab  sub rsp, 0xF0
000070bab59d27b2  vmovaps [rsp], xmm0
000070bab59d27b7  vmovaps [rsp+0x10], xmm1
000070bab59d27bd  vmovaps [rsp+0x20], xmm2
000070bab59d27c3  vmovaps [rsp+0x30], xmm3
000070bab59d27c9  vmovaps [rsp+0x40], xmm4
000070bab59d27cf  vmovaps [rsp+0x50], xmm5
000070bab59d27d5  vmovaps [rsp+0x60], xmm6
000070bab59d27db  vmovaps [rsp+0x70], xmm7
000070bab59d27e1  vmovaps [rsp+0x80], xmm8
000070bab59d27ea  vmovaps [rsp+0x90], xmm9
000070bab59d27f3  vmovaps [rsp+0xA0], xmm10
000070bab59d27fc  vmovaps [rsp+0xB0], xmm11
000070bab59d2805  vmovaps [rsp+0xC0], xmm12
000070bab59d280e  vmovaps [rsp+0xD0], xmm13
000070bab59d2817  vmovaps [rsp+0xE0], xmm15
000070bab59d2820  sub rsp, 0x30
000070bab59d2824  movaps [rsp], xmm14
000070bab59d2829  movaps [rsp+0x10], xmm6
000070bab59d282e  movaps [rsp+0x20], xmm2
000070bab59d2833  lea rdi, [rsp]
000070bab59d2837  mov esi, 0x00
000070bab59d283c  mov rax, 0x63B35AFBC530
000070bab59d2846  call rax
000070bab59d2848  movaps xmm14, [rsp]
000070bab59d284d  add rsp, 0x30
000070bab59d2851  vmovaps xmm0, [rsp]
000070bab59d2856  vmovaps xmm1, [rsp+0x10]
000070bab59d285c  vmovaps xmm2, [rsp+0x20]
000070bab59d2862  vmovaps xmm3, [rsp+0x30]
000070bab59d2868  vmovaps xmm4, [rsp+0x40]
000070bab59d286e  vmovaps xmm5, [rsp+0x50]
000070bab59d2874  vmovaps xmm6, [rsp+0x60]
000070bab59d287a  vmovaps xmm7, [rsp+0x70]
000070bab59d2880  vmovaps xmm8, [rsp+0x80]
000070bab59d2889  vmovaps xmm9, [rsp+0x90]
000070bab59d2892  vmovaps xmm10, [rsp+0xA0]
000070bab59d289b  vmovaps xmm11, [rsp+0xB0]
000070bab59d28a4  vmovaps xmm12, [rsp+0xC0]
000070bab59d28ad  vmovaps xmm13, [rsp+0xD0]
000070bab59d28b6  vmovaps xmm15, [rsp+0xE0]
000070bab59d28bf  add rsp, 0xF0
000070bab59d28c6  pop r11
000070bab59d28c8  pop r10
000070bab59d28ca  pop r9
000070bab59d28cc  pop r8
000070bab59d28ce  pop rsi
000070bab59d28cf  pop rdi
000070bab59d28d0  pop rdx
000070bab59d28d1  pop rcx
000070bab59d28d2  pop rax
000070bab59d28d3  add rsp, 0x08
000070bab59d28d7  jmp 0x000070BAB59CFD72
000070bab59d28dc  sub rsp, 0x08
000070bab59d28e0  push rax
000070bab59d28e1  push rcx
000070bab59d28e2  push rdx
000070bab59d28e3  push rdi
000070bab59d28e4  push rsi
000070bab59d28e5  push r8
000070bab59d28e7  push r9
000070bab59d28e9  push r10
000070bab59d28eb  push r11
000070bab59d28ed  sub rsp, 0xF0
000070bab59d28f4  vmovaps [rsp], xmm0
000070bab59d28f9  vmovaps [rsp+0x10], xmm1
000070bab59d28ff  vmovaps [rsp+0x20], xmm2
000070bab59d2905  vmovaps [rsp+0x30], xmm3
000070bab59d290b  vmovaps [rsp+0x40], xmm4
000070bab59d2911  vmovaps [rsp+0x50], xmm5
000070bab59d2917  vmovaps [rsp+0x60], xmm7
000070bab59d291d  vmovaps [rsp+0x70], xmm8
000070bab59d2923  vmovaps [rsp+0x80], xmm9
000070bab59d292c  vmovaps [rsp+0x90], xmm10
000070bab59d2935  vmovaps [rsp+0xA0], xmm11
000070bab59d293e  vmovaps [rsp+0xB0], xmm12
000070bab59d2947  vmovaps [rsp+0xC0], xmm13
000070bab59d2950  vmovaps [rsp+0xD0], xmm14
000070bab59d2959  vmovaps [rsp+0xE0], xmm15
000070bab59d2962  sub rsp, 0x30
000070bab59d2966  movaps [rsp], xmm6
000070bab59d296a  movaps [rsp+0x10], xmm5
000070bab59d296f  movaps [rsp+0x20], xmm1
000070bab59d2974  lea rdi, [rsp]
000070bab59d2978  mov esi, 0x00
000070bab59d297d  mov rax, 0x63B35AFBC530
000070bab59d2987  call rax
000070bab59d2989  movaps xmm6, [rsp]
000070bab59d298d  add rsp, 0x30
000070bab59d2991  vmovaps xmm0, [rsp]
000070bab59d2996  vmovaps xmm1, [rsp+0x10]
000070bab59d299c  vmovaps xmm2, [rsp+0x20]
000070bab59d29a2  vmovaps xmm3, [rsp+0x30]
000070bab59d29a8  vmovaps xmm4, [rsp+0x40]
000070bab59d29ae  vmovaps xmm5, [rsp+0x50]
000070bab59d29b4  vmovaps xmm7, [rsp+0x60]
000070bab59d29ba  vmovaps xmm8, [rsp+0x70]
000070bab59d29c0  vmovaps xmm9, [rsp+0x80]
000070bab59d29c9  vmovaps xmm10, [rsp+0x90]
000070bab59d29d2  vmovaps xmm11, [rsp+0xA0]
000070bab59d29db  vmovaps xmm12, [rsp+0xB0]
000070bab59d29e4  vmovaps xmm13, [rsp+0xC0]
000070bab59d29ed  vmovaps xmm14, [rsp+0xD0]
000070bab59d29f6  vmovaps xmm15, [rsp+0xE0]
000070bab59d29ff  add rsp, 0xF0
000070bab59d2a06  pop r11
000070bab59d2a08  pop r10
000070bab59d2a0a  pop r9
000070bab59d2a0c  pop r8
000070bab59d2a0e  pop rsi
000070bab59d2a0f  pop rdi
000070bab59d2a10  pop rdx
000070bab59d2a11  pop rcx
000070bab59d2a12  pop rax
000070bab59d2a13  add rsp, 0x08
000070bab59d2a17  jmp 0x000070BAB59CFD98
000070bab59d2a1c  sub rsp, 0x08
000070bab59d2a20  push rax
000070bab59d2a21  push rcx
000070bab59d2a22  push rdx
000070bab59d2a23  push rdi
000070bab59d2a24  push rsi
000070bab59d2a25  push r8
000070bab59d2a27  push r9
000070bab59d2a29  push r10
000070bab59d2a2b  push r11
000070bab59d2a2d  sub rsp, 0xF0
000070bab59d2a34  vmovaps [rsp], xmm0
000070bab59d2a39  vmovaps [rsp+0x10], xmm2
000070bab59d2a3f  vmovaps [rsp+0x20], xmm3
000070bab59d2a45  vmovaps [rsp+0x30], xmm4
000070bab59d2a4b  vmovaps [rsp+0x40], xmm5
000070bab59d2a51  vmovaps [rsp+0x50], xmm6
000070bab59d2a57  vmovaps [rsp+0x60], xmm7
000070bab59d2a5d  vmovaps [rsp+0x70], xmm8
000070bab59d2a63  vmovaps [rsp+0x80], xmm9
000070bab59d2a6c  vmovaps [rsp+0x90], xmm10
000070bab59d2a75  vmovaps [rsp+0xA0], xmm11
000070bab59d2a7e  vmovaps [rsp+0xB0], xmm12
000070bab59d2a87  vmovaps [rsp+0xC0], xmm13
000070bab59d2a90  vmovaps [rsp+0xD0], xmm14
000070bab59d2a99  vmovaps [rsp+0xE0], xmm15
000070bab59d2aa2  sub rsp, 0x30
000070bab59d2aa6  movaps [rsp], xmm1
000070bab59d2aaa  movaps [rsp+0x10], xmm5
000070bab59d2aaf  movaps [rsp+0x20], xmm13
000070bab59d2ab5  lea rdi, [rsp]
000070bab59d2ab9  mov esi, 0x00
000070bab59d2abe  mov rax, 0x63B35AFBC530
000070bab59d2ac8  call rax
000070bab59d2aca  movaps xmm1, [rsp]
000070bab59d2ace  add rsp, 0x30
000070bab59d2ad2  vmovaps xmm0, [rsp]
000070bab59d2ad7  vmovaps xmm2, [rsp+0x10]
000070bab59d2add  vmovaps xmm3, [rsp+0x20]
000070bab59d2ae3  vmovaps xmm4, [rsp+0x30]
000070bab59d2ae9  vmovaps xmm5, [rsp+0x40]
000070bab59d2aef  vmovaps xmm6, [rsp+0x50]
000070bab59d2af5  vmovaps xmm7, [rsp+0x60]
000070bab59d2afb  vmovaps xmm8, [rsp+0x70]
000070bab59d2b01  vmovaps xmm9, [rsp+0x80]
000070bab59d2b0a  vmovaps xmm10, [rsp+0x90]
000070bab59d2b13  vmovaps xmm11, [rsp+0xA0]
000070bab59d2b1c  vmovaps xmm12, [rsp+0xB0]
000070bab59d2b25  vmovaps xmm13, [rsp+0xC0]
000070bab59d2b2e  vmovaps xmm14, [rsp+0xD0]
000070bab59d2b37  vmovaps xmm15, [rsp+0xE0]
000070bab59d2b40  add rsp, 0xF0
000070bab59d2b47  pop r11
000070bab59d2b49  pop r10
000070bab59d2b4b  pop r9
000070bab59d2b4d  pop r8
000070bab59d2b4f  pop rsi
000070bab59d2b50  pop rdi
000070bab59d2b51  pop rdx
000070bab59d2b52  pop rcx
000070bab59d2b53  pop rax
000070bab59d2b54  add rsp, 0x08
000070bab59d2b58  jmp 0x000070BAB59CFDB6
000070bab59d2b5d  sub rsp, 0x08
000070bab59d2b61  push rax
000070bab59d2b62  push rcx
000070bab59d2b63  push rdx
000070bab59d2b64  push rdi
000070bab59d2b65  push rsi
000070bab59d2b66  push r8
000070bab59d2b68  push r9
000070bab59d2b6a  push r10
000070bab59d2b6c  push r11
000070bab59d2b6e  sub rsp, 0xF0
000070bab59d2b75  vmovaps [rsp], xmm0
000070bab59d2b7a  vmovaps [rsp+0x10], xmm1
000070bab59d2b80  vmovaps [rsp+0x20], xmm2
000070bab59d2b86  vmovaps [rsp+0x30], xmm3
000070bab59d2b8c  vmovaps [rsp+0x40], xmm4
000070bab59d2b92  vmovaps [rsp+0x50], xmm6
000070bab59d2b98  vmovaps [rsp+0x60], xmm7
000070bab59d2b9e  vmovaps [rsp+0x70], xmm8
000070bab59d2ba4  vmovaps [rsp+0x80], xmm9
000070bab59d2bad  vmovaps [rsp+0x90], xmm10
000070bab59d2bb6  vmovaps [rsp+0xA0], xmm11
000070bab59d2bbf  vmovaps [rsp+0xB0], xmm12
000070bab59d2bc8  vmovaps [rsp+0xC0], xmm13
000070bab59d2bd1  vmovaps [rsp+0xD0], xmm14
000070bab59d2bda  vmovaps [rsp+0xE0], xmm15
000070bab59d2be3  sub rsp, 0x30
000070bab59d2be7  movaps [rsp], xmm5
000070bab59d2beb  movaps [rsp+0x10], xmm2
000070bab59d2bf0  movaps [rsp+0x20], xmm13
000070bab59d2bf6  lea rdi, [rsp]
000070bab59d2bfa  mov esi, 0x00
000070bab59d2bff  mov rax, 0x63B35AFBC530
000070bab59d2c09  call rax
000070bab59d2c0b  movaps xmm5, [rsp]
000070bab59d2c0f  add rsp, 0x30
000070bab59d2c13  vmovaps xmm0, [rsp]
000070bab59d2c18  vmovaps xmm1, [rsp+0x10]
000070bab59d2c1e  vmovaps xmm2, [rsp+0x20]
000070bab59d2c24  vmovaps xmm3, [rsp+0x30]
000070bab59d2c2a  vmovaps xmm4, [rsp+0x40]
000070bab59d2c30  vmovaps xmm6, [rsp+0x50]
000070bab59d2c36  vmovaps xmm7, [rsp+0x60]
000070bab59d2c3c  vmovaps xmm8, [rsp+0x70]
000070bab59d2c42  vmovaps xmm9, [rsp+0x80]
000070bab59d2c4b  vmovaps xmm10, [rsp+0x90]
000070bab59d2c54  vmovaps xmm11, [rsp+0xA0]
000070bab59d2c5d  vmovaps xmm12, [rsp+0xB0]
000070bab59d2c66  vmovaps xmm13, [rsp+0xC0]
000070bab59d2c6f  vmovaps xmm14, [rsp+0xD0]
000070bab59d2c78  vmovaps xmm15, [rsp+0xE0]
000070bab59d2c81  add rsp, 0xF0
000070bab59d2c88  pop r11
000070bab59d2c8a  pop r10
000070bab59d2c8c  pop r9
000070bab59d2c8e  pop r8
000070bab59d2c90  pop rsi
000070bab59d2c91  pop rdi
000070bab59d2c92  pop rdx
000070bab59d2c93  pop rcx
000070bab59d2c94  pop rax
000070bab59d2c95  add rsp, 0x08
000070bab59d2c99  jmp 0x000070BAB59CFDEC
000070bab59d2c9e  sub rsp, 0x08
000070bab59d2ca2  push rax
000070bab59d2ca3  push rcx
000070bab59d2ca4  push rdx
000070bab59d2ca5  push rdi
000070bab59d2ca6  push rsi
000070bab59d2ca7  push r8
000070bab59d2ca9  push r9
000070bab59d2cab  push r10
000070bab59d2cad  push r11
000070bab59d2caf  sub rsp, 0xF0
000070bab59d2cb6  vmovaps [rsp], xmm0
000070bab59d2cbb  vmovaps [rsp+0x10], xmm1
000070bab59d2cc1  vmovaps [rsp+0x20], xmm2
000070bab59d2cc7  vmovaps [rsp+0x30], xmm3
000070bab59d2ccd  vmovaps [rsp+0x40], xmm4
000070bab59d2cd3  vmovaps [rsp+0x50], xmm5
000070bab59d2cd9  vmovaps [rsp+0x60], xmm6
000070bab59d2cdf  vmovaps [rsp+0x70], xmm7
000070bab59d2ce5  vmovaps [rsp+0x80], xmm8
000070bab59d2cee  vmovaps [rsp+0x90], xmm9
000070bab59d2cf7  vmovaps [rsp+0xA0], xmm10
000070bab59d2d00  vmovaps [rsp+0xB0], xmm11
000070bab59d2d09  vmovaps [rsp+0xC0], xmm12
000070bab59d2d12  vmovaps [rsp+0xD0], xmm14
000070bab59d2d1b  vmovaps [rsp+0xE0], xmm15
000070bab59d2d24  sub rsp, 0x30
000070bab59d2d28  movaps [rsp], xmm13
000070bab59d2d2d  movaps [rsp+0x10], xmm10
000070bab59d2d33  movaps [rsp+0x20], xmm1
000070bab59d2d38  lea rdi, [rsp]
000070bab59d2d3c  mov esi, 0x00
000070bab59d2d41  mov rax, 0x63B35AFBC530
000070bab59d2d4b  call rax
000070bab59d2d4d  movaps xmm13, [rsp]
000070bab59d2d52  add rsp, 0x30
000070bab59d2d56  vmovaps xmm0, [rsp]
000070bab59d2d5b  vmovaps xmm1, [rsp+0x10]
000070bab59d2d61  vmovaps xmm2, [rsp+0x20]
000070bab59d2d67  vmovaps xmm3, [rsp+0x30]
000070bab59d2d6d  vmovaps xmm4, [rsp+0x40]
000070bab59d2d73  vmovaps xmm5, [rsp+0x50]
000070bab59d2d79  vmovaps xmm6, [rsp+0x60]
000070bab59d2d7f  vmovaps xmm7, [rsp+0x70]
000070bab59d2d85  vmovaps xmm8, [rsp+0x80]
000070bab59d2d8e  vmovaps xmm9, [rsp+0x90]
000070bab59d2d97  vmovaps xmm10, [rsp+0xA0]
000070bab59d2da0  vmovaps xmm11, [rsp+0xB0]
000070bab59d2da9  vmovaps xmm12, [rsp+0xC0]
000070bab59d2db2  vmovaps xmm14, [rsp+0xD0]
000070bab59d2dbb  vmovaps xmm15, [rsp+0xE0]
000070bab59d2dc4  add rsp, 0xF0
000070bab59d2dcb  pop r11
000070bab59d2dcd  pop r10
000070bab59d2dcf  pop r9
000070bab59d2dd1  pop r8
000070bab59d2dd3  pop rsi
000070bab59d2dd4  pop rdi
000070bab59d2dd5  pop rdx
000070bab59d2dd6  pop rcx
000070bab59d2dd7  pop rax
000070bab59d2dd8  add rsp, 0x08
000070bab59d2ddc  jmp 0x000070BAB59CFE15
000070bab59d2de1  sub rsp, 0x08
000070bab59d2de5  push rax
000070bab59d2de6  push rcx
000070bab59d2de7  push rdx
000070bab59d2de8  push rdi
000070bab59d2de9  push rsi
000070bab59d2dea  push r8
000070bab59d2dec  push r9
000070bab59d2dee  push r10
000070bab59d2df0  push r11
000070bab59d2df2  sub rsp, 0xF0
000070bab59d2df9  vmovaps [rsp], xmm0
000070bab59d2dfe  vmovaps [rsp+0x10], xmm2
000070bab59d2e04  vmovaps [rsp+0x20], xmm3
000070bab59d2e0a  vmovaps [rsp+0x30], xmm4
000070bab59d2e10  vmovaps [rsp+0x40], xmm5
000070bab59d2e16  vmovaps [rsp+0x50], xmm6
000070bab59d2e1c  vmovaps [rsp+0x60], xmm7
000070bab59d2e22  vmovaps [rsp+0x70], xmm8
000070bab59d2e28  vmovaps [rsp+0x80], xmm9
000070bab59d2e31  vmovaps [rsp+0x90], xmm10
000070bab59d2e3a  vmovaps [rsp+0xA0], xmm11
000070bab59d2e43  vmovaps [rsp+0xB0], xmm12
000070bab59d2e4c  vmovaps [rsp+0xC0], xmm13
000070bab59d2e55  vmovaps [rsp+0xD0], xmm14
000070bab59d2e5e  vmovaps [rsp+0xE0], xmm15
000070bab59d2e67  sub rsp, 0x30
000070bab59d2e6b  movaps [rsp], xmm1
000070bab59d2e6f  movaps [rsp+0x10], xmm15
000070bab59d2e75  movaps [rsp+0x20], xmm10
000070bab59d2e7b  lea rdi, [rsp]
000070bab59d2e7f  mov esi, 0x00
000070bab59d2e84  mov rax, 0x63B35AFBC530
000070bab59d2e8e  call rax
000070bab59d2e90  movaps xmm1, [rsp]
000070bab59d2e94  add rsp, 0x30
000070bab59d2e98  vmovaps xmm0, [rsp]
000070bab59d2e9d  vmovaps xmm2, [rsp+0x10]
000070bab59d2ea3  vmovaps xmm3, [rsp+0x20]
000070bab59d2ea9  vmovaps xmm4, [rsp+0x30]
000070bab59d2eaf  vmovaps xmm5, [rsp+0x40]
000070bab59d2eb5  vmovaps xmm6, [rsp+0x50]
000070bab59d2ebb  vmovaps xmm7, [rsp+0x60]
000070bab59d2ec1  vmovaps xmm8, [rsp+0x70]
000070bab59d2ec7  vmovaps xmm9, [rsp+0x80]
000070bab59d2ed0  vmovaps xmm10, [rsp+0x90]
000070bab59d2ed9  vmovaps xmm11, [rsp+0xA0]
000070bab59d2ee2  vmovaps xmm12, [rsp+0xB0]
000070bab59d2eeb  vmovaps xmm13, [rsp+0xC0]
000070bab59d2ef4  vmovaps xmm14, [rsp+0xD0]
000070bab59d2efd  vmovaps xmm15, [rsp+0xE0]
000070bab59d2f06  add rsp, 0xF0
000070bab59d2f0d  pop r11
000070bab59d2f0f  pop r10
000070bab59d2f11  pop r9
000070bab59d2f13  pop r8
000070bab59d2f15  pop rsi
000070bab59d2f16  pop rdi
000070bab59d2f17  pop rdx
000070bab59d2f18  pop rcx
000070bab59d2f19  pop rax
000070bab59d2f1a  add rsp, 0x08
000070bab59d2f1e  jmp 0x000070BAB59CFE34
000070bab59d2f23  sub rsp, 0x08
000070bab59d2f27  push rax
000070bab59d2f28  push rcx
000070bab59d2f29  push rdx
000070bab59d2f2a  push rdi
000070bab59d2f2b  push rsi
000070bab59d2f2c  push r8
000070bab59d2f2e  push r9
000070bab59d2f30  push r10
000070bab59d2f32  push r11
000070bab59d2f34  sub rsp, 0xF0
000070bab59d2f3b  vmovaps [rsp], xmm0
000070bab59d2f40  vmovaps [rsp+0x10], xmm1
000070bab59d2f46  vmovaps [rsp+0x20], xmm2
000070bab59d2f4c  vmovaps [rsp+0x30], xmm3
000070bab59d2f52  vmovaps [rsp+0x40], xmm4
000070bab59d2f58  vmovaps [rsp+0x50], xmm5
000070bab59d2f5e  vmovaps [rsp+0x60], xmm6
000070bab59d2f64  vmovaps [rsp+0x70], xmm7
000070bab59d2f6a  vmovaps [rsp+0x80], xmm8
000070bab59d2f73  vmovaps [rsp+0x90], xmm9
000070bab59d2f7c  vmovaps [rsp+0xA0], xmm10
000070bab59d2f85  vmovaps [rsp+0xB0], xmm11
000070bab59d2f8e  vmovaps [rsp+0xC0], xmm12
000070bab59d2f97  vmovaps [rsp+0xD0], xmm13
000070bab59d2fa0  vmovaps [rsp+0xE0], xmm14
000070bab59d2fa9  sub rsp, 0x30
000070bab59d2fad  movaps [rsp], xmm15
000070bab59d2fb2  movaps [rsp+0x10], xmm10
000070bab59d2fb8  movaps [rsp+0x20], xmm11
000070bab59d2fbe  lea rdi, [rsp]
000070bab59d2fc2  mov esi, 0x00
000070bab59d2fc7  mov rax, 0x63B35AFBC530
000070bab59d2fd1  call rax
000070bab59d2fd3  movaps xmm15, [rsp]
000070bab59d2fd8  add rsp, 0x30
000070bab59d2fdc  vmovaps xmm0, [rsp]
000070bab59d2fe1  vmovaps xmm1, [rsp+0x10]
000070bab59d2fe7  vmovaps xmm2, [rsp+0x20]
000070bab59d2fed  vmovaps xmm3, [rsp+0x30]
000070bab59d2ff3  vmovaps xmm4, [rsp+0x40]
000070bab59d2ff9  vmovaps xmm5, [rsp+0x50]
000070bab59d2fff  vmovaps xmm6, [rsp+0x60]
000070bab59d3005  vmovaps xmm7, [rsp+0x70]
000070bab59d300b  vmovaps xmm8, [rsp+0x80]
000070bab59d3014  vmovaps xmm9, [rsp+0x90]
000070bab59d301d  vmovaps xmm10, [rsp+0xA0]
000070bab59d3026  vmovaps xmm11, [rsp+0xB0]
000070bab59d302f  vmovaps xmm12, [rsp+0xC0]
000070bab59d3038  vmovaps xmm13, [rsp+0xD0]
000070bab59d3041  vmovaps xmm14, [rsp+0xE0]
000070bab59d304a  add rsp, 0xF0
000070bab59d3051  pop r11
000070bab59d3053  pop r10
000070bab59d3055  pop r9
000070bab59d3057  pop r8
000070bab59d3059  pop rsi
000070bab59d305a  pop rdi
000070bab59d305b  pop rdx
000070bab59d305c  pop rcx
000070bab59d305d  pop rax
000070bab59d305e  add rsp, 0x08
000070bab59d3062  jmp 0x000070BAB59CFE57
000070bab59d3067  sub rsp, 0x08
000070bab59d306b  push rax
000070bab59d306c  push rcx
000070bab59d306d  push rdx
000070bab59d306e  push rdi
000070bab59d306f  push rsi
000070bab59d3070  push r8
000070bab59d3072  push r9
000070bab59d3074  push r10
000070bab59d3076  push r11
000070bab59d3078  sub rsp, 0xF0
000070bab59d307f  vmovaps [rsp], xmm0
000070bab59d3084  vmovaps [rsp+0x10], xmm1
000070bab59d308a  vmovaps [rsp+0x20], xmm2
000070bab59d3090  vmovaps [rsp+0x30], xmm3
000070bab59d3096  vmovaps [rsp+0x40], xmm4
000070bab59d309c  vmovaps [rsp+0x50], xmm5
000070bab59d30a2  vmovaps [rsp+0x60], xmm6
000070bab59d30a8  vmovaps [rsp+0x70], xmm7
000070bab59d30ae  vmovaps [rsp+0x80], xmm8
000070bab59d30b7  vmovaps [rsp+0x90], xmm9
000070bab59d30c0  vmovaps [rsp+0xA0], xmm11
000070bab59d30c9  vmovaps [rsp+0xB0], xmm12
000070bab59d30d2  vmovaps [rsp+0xC0], xmm13
000070bab59d30db  vmovaps [rsp+0xD0], xmm14
000070bab59d30e4  vmovaps [rsp+0xE0], xmm15
000070bab59d30ed  sub rsp, 0x30
000070bab59d30f1  movaps [rsp], xmm10
000070bab59d30f6  movaps [rsp+0x10], xmm12
000070bab59d30fc  movaps [rsp+0x20], xmm11
000070bab59d3102  lea rdi, [rsp]
000070bab59d3106  mov esi, 0x00
000070bab59d310b  mov rax, 0x63B35AFBC530
000070bab59d3115  call rax
000070bab59d3117  movaps xmm10, [rsp]
000070bab59d311c  add rsp, 0x30
000070bab59d3120  vmovaps xmm0, [rsp]
000070bab59d3125  vmovaps xmm1, [rsp+0x10]
000070bab59d312b  vmovaps xmm2, [rsp+0x20]
000070bab59d3131  vmovaps xmm3, [rsp+0x30]
000070bab59d3137  vmovaps xmm4, [rsp+0x40]
000070bab59d313d  vmovaps xmm5, [rsp+0x50]
000070bab59d3143  vmovaps xmm6, [rsp+0x60]
000070bab59d3149  vmovaps xmm7, [rsp+0x70]
000070bab59d314f  vmovaps xmm8, [rsp+0x80]
000070bab59d3158  vmovaps xmm9, [rsp+0x90]
000070bab59d3161  vmovaps xmm11, [rsp+0xA0]
000070bab59d316a  vmovaps xmm12, [rsp+0xB0]
000070bab59d3173  vmovaps xmm13, [rsp+0xC0]
000070bab59d317c  vmovaps xmm14, [rsp+0xD0]
000070bab59d3185  vmovaps xmm15, [rsp+0xE0]
000070bab59d318e  add rsp, 0xF0
000070bab59d3195  pop r11
000070bab59d3197  pop r10
000070bab59d3199  pop r9
000070bab59d319b  pop r8
000070bab59d319d  pop rsi
000070bab59d319e  pop rdi
000070bab59d319f  pop rdx
000070bab59d31a0  pop rcx
000070bab59d31a1  pop rax
000070bab59d31a2  add rsp, 0x08
000070bab59d31a6  jmp 0x000070BAB59CFE80
000070bab59d31ab  sub rsp, 0x08
000070bab59d31af  push rax
000070bab59d31b0  push rcx
000070bab59d31b1  push rdx
000070bab59d31b2  push rdi
000070bab59d31b3  push rsi
000070bab59d31b4  push r8
000070bab59d31b6  push r9
000070bab59d31b8  push r10
000070bab59d31ba  push r11
000070bab59d31bc  sub rsp, 0xF0
000070bab59d31c3  vmovaps [rsp], xmm0
000070bab59d31c8  vmovaps [rsp+0x10], xmm1
000070bab59d31ce  vmovaps [rsp+0x20], xmm2
000070bab59d31d4  vmovaps [rsp+0x30], xmm3
000070bab59d31da  vmovaps [rsp+0x40], xmm4
000070bab59d31e0  vmovaps [rsp+0x50], xmm5
000070bab59d31e6  vmovaps [rsp+0x60], xmm6
000070bab59d31ec  vmovaps [rsp+0x70], xmm7
000070bab59d31f2  vmovaps [rsp+0x80], xmm8
000070bab59d31fb  vmovaps [rsp+0x90], xmm9
000070bab59d3204  vmovaps [rsp+0xA0], xmm10
000070bab59d320d  vmovaps [rsp+0xB0], xmm12
000070bab59d3216  vmovaps [rsp+0xC0], xmm13
000070bab59d321f  vmovaps [rsp+0xD0], xmm14
000070bab59d3228  vmovaps [rsp+0xE0], xmm15
000070bab59d3231  sub rsp, 0x30
000070bab59d3235  movaps [rsp], xmm11
000070bab59d323a  movaps [rsp+0x10], xmm2
000070bab59d323f  movaps [rsp+0x20], xmm12
000070bab59d3245  lea rdi, [rsp]
000070bab59d3249  mov esi, 0x00
000070bab59d324e  mov rax, 0x63B35AFBC530
000070bab59d3258  call rax
000070bab59d325a  movaps xmm11, [rsp]
000070bab59d325f  add rsp, 0x30
000070bab59d3263  vmovaps xmm0, [rsp]
000070bab59d3268  vmovaps xmm1, [rsp+0x10]
000070bab59d326e  vmovaps xmm2, [rsp+0x20]
000070bab59d3274  vmovaps xmm3, [rsp+0x30]
000070bab59d327a  vmovaps xmm4, [rsp+0x40]
000070bab59d3280  vmovaps xmm5, [rsp+0x50]
000070bab59d3286  vmovaps xmm6, [rsp+0x60]
000070bab59d328c  vmovaps xmm7, [rsp+0x70]
000070bab59d3292  vmovaps xmm8, [rsp+0x80]
000070bab59d329b  vmovaps xmm9, [rsp+0x90]
000070bab59d32a4  vmovaps xmm10, [rsp+0xA0]
000070bab59d32ad  vmovaps xmm12, [rsp+0xB0]
000070bab59d32b6  vmovaps xmm13, [rsp+0xC0]
000070bab59d32bf  vmovaps xmm14, [rsp+0xD0]
000070bab59d32c8  vmovaps xmm15, [rsp+0xE0]
000070bab59d32d1  add rsp, 0xF0
000070bab59d32d8  pop r11
000070bab59d32da  pop r10
000070bab59d32dc  pop r9
000070bab59d32de  pop r8
000070bab59d32e0  pop rsi
000070bab59d32e1  pop rdi
000070bab59d32e2  pop rdx
000070bab59d32e3  pop rcx
000070bab59d32e4  pop rax
000070bab59d32e5  add rsp, 0x08
000070bab59d32e9  jmp 0x000070BAB59CFEB8
000070bab59d32ee  sub rsp, 0x08
000070bab59d32f2  push rax
000070bab59d32f3  push rcx
000070bab59d32f4  push rdx
000070bab59d32f5  push rdi
000070bab59d32f6  push rsi
000070bab59d32f7  push r8
000070bab59d32f9  push r9
000070bab59d32fb  push r10
000070bab59d32fd  push r11
000070bab59d32ff  sub rsp, 0xF0
000070bab59d3306  vmovaps [rsp], xmm0
000070bab59d330b  vmovaps [rsp+0x10], xmm2
000070bab59d3311  vmovaps [rsp+0x20], xmm3
000070bab59d3317  vmovaps [rsp+0x30], xmm4
000070bab59d331d  vmovaps [rsp+0x40], xmm5
000070bab59d3323  vmovaps [rsp+0x50], xmm6
000070bab59d3329  vmovaps [rsp+0x60], xmm7
000070bab59d332f  vmovaps [rsp+0x70], xmm8
000070bab59d3335  vmovaps [rsp+0x80], xmm9
000070bab59d333e  vmovaps [rsp+0x90], xmm10
000070bab59d3347  vmovaps [rsp+0xA0], xmm11
000070bab59d3350  vmovaps [rsp+0xB0], xmm12
000070bab59d3359  vmovaps [rsp+0xC0], xmm13
000070bab59d3362  vmovaps [rsp+0xD0], xmm14
000070bab59d336b  vmovaps [rsp+0xE0], xmm15
000070bab59d3374  sub rsp, 0x30
000070bab59d3378  movaps [rsp], xmm1
000070bab59d337c  movaps [rsp+0x10], xmm14
000070bab59d3382  movaps [rsp+0x20], xmm6
000070bab59d3387  lea rdi, [rsp]
000070bab59d338b  mov esi, 0x00
000070bab59d3390  mov rax, 0x63B35AFBC530
000070bab59d339a  call rax
000070bab59d339c  movaps xmm1, [rsp]
000070bab59d33a0  add rsp, 0x30
000070bab59d33a4  vmovaps xmm0, [rsp]
000070bab59d33a9  vmovaps xmm2, [rsp+0x10]
000070bab59d33af  vmovaps xmm3, [rsp+0x20]
000070bab59d33b5  vmovaps xmm4, [rsp+0x30]
000070bab59d33bb  vmovaps xmm5, [rsp+0x40]
000070bab59d33c1  vmovaps xmm6, [rsp+0x50]
000070bab59d33c7  vmovaps xmm7, [rsp+0x60]
000070bab59d33cd  vmovaps xmm8, [rsp+0x70]
000070bab59d33d3  vmovaps xmm9, [rsp+0x80]
000070bab59d33dc  vmovaps xmm10, [rsp+0x90]
000070bab59d33e5  vmovaps xmm11, [rsp+0xA0]
000070bab59d33ee  vmovaps xmm12, [rsp+0xB0]
000070bab59d33f7  vmovaps xmm13, [rsp+0xC0]
000070bab59d3400  vmovaps xmm14, [rsp+0xD0]
000070bab59d3409  vmovaps xmm15, [rsp+0xE0]
000070bab59d3412  add rsp, 0xF0
000070bab59d3419  pop r11
000070bab59d341b  pop r10
000070bab59d341d  pop r9
000070bab59d341f  pop r8
000070bab59d3421  pop rsi
000070bab59d3422  pop rdi
000070bab59d3423  pop rdx
000070bab59d3424  pop rcx
000070bab59d3425  pop rax
000070bab59d3426  add rsp, 0x08
000070bab59d342a  jmp 0x000070BAB59CFED1
000070bab59d342f  sub rsp, 0x08
000070bab59d3433  push rax
000070bab59d3434  push rcx
000070bab59d3435  push rdx
000070bab59d3436  push rdi
000070bab59d3437  push rsi
000070bab59d3438  push r8
000070bab59d343a  push r9
000070bab59d343c  push r10
000070bab59d343e  push r11
000070bab59d3440  sub rsp, 0xF0
000070bab59d3447  vmovaps [rsp], xmm0
000070bab59d344c  vmovaps [rsp+0x10], xmm1
000070bab59d3452  vmovaps [rsp+0x20], xmm2
000070bab59d3458  vmovaps [rsp+0x30], xmm3
000070bab59d345e  vmovaps [rsp+0x40], xmm4
000070bab59d3464  vmovaps [rsp+0x50], xmm5
000070bab59d346a  vmovaps [rsp+0x60], xmm6
000070bab59d3470  vmovaps [rsp+0x70], xmm7
000070bab59d3476  vmovaps [rsp+0x80], xmm8
000070bab59d347f  vmovaps [rsp+0x90], xmm9
000070bab59d3488  vmovaps [rsp+0xA0], xmm10
000070bab59d3491  vmovaps [rsp+0xB0], xmm11
000070bab59d349a  vmovaps [rsp+0xC0], xmm12
000070bab59d34a3  vmovaps [rsp+0xD0], xmm13
000070bab59d34ac  vmovaps [rsp+0xE0], xmm15
000070bab59d34b5  sub rsp, 0x30
000070bab59d34b9  movaps [rsp], xmm14
000070bab59d34be  movaps [rsp+0x10], xmm12
000070bab59d34c4  movaps [rsp+0x20], xmm5
000070bab59d34c9  lea rdi, [rsp]
000070bab59d34cd  mov esi, 0x00
000070bab59d34d2  mov rax, 0x63B35AFBC530
000070bab59d34dc  call rax
000070bab59d34de  movaps xmm14, [rsp]
000070bab59d34e3  add rsp, 0x30
000070bab59d34e7  vmovaps xmm0, [rsp]
000070bab59d34ec  vmovaps xmm1, [rsp+0x10]
000070bab59d34f2  vmovaps xmm2, [rsp+0x20]
000070bab59d34f8  vmovaps xmm3, [rsp+0x30]
000070bab59d34fe  vmovaps xmm4, [rsp+0x40]
000070bab59d3504  vmovaps xmm5, [rsp+0x50]
000070bab59d350a  vmovaps xmm6, [rsp+0x60]
000070bab59d3510  vmovaps xmm7, [rsp+0x70]
000070bab59d3516  vmovaps xmm8, [rsp+0x80]
000070bab59d351f  vmovaps xmm9, [rsp+0x90]
000070bab59d3528  vmovaps xmm10, [rsp+0xA0]
000070bab59d3531  vmovaps xmm11, [rsp+0xB0]
000070bab59d353a  vmovaps xmm12, [rsp+0xC0]
000070bab59d3543  vmovaps xmm13, [rsp+0xD0]
000070bab59d354c  vmovaps xmm15, [rsp+0xE0]
000070bab59d3555  add rsp, 0xF0
000070bab59d355c  pop r11
000070bab59d355e  pop r10
000070bab59d3560  pop r9
000070bab59d3562  pop r8
000070bab59d3564  pop rsi
000070bab59d3565  pop rdi
000070bab59d3566  pop rdx
000070bab59d3567  pop rcx
000070bab59d3568  pop rax
000070bab59d3569  add rsp, 0x08
000070bab59d356d  jmp 0x000070BAB59CFEF1
000070bab59d3572  sub rsp, 0x08
000070bab59d3576  push rax
000070bab59d3577  push rcx
000070bab59d3578  push rdx
000070bab59d3579  push rdi
000070bab59d357a  push rsi
000070bab59d357b  push r8
000070bab59d357d  push r9
000070bab59d357f  push r10
000070bab59d3581  push r11
000070bab59d3583  sub rsp, 0xF0
000070bab59d358a  vmovaps [rsp], xmm0
000070bab59d358f  vmovaps [rsp+0x10], xmm1
000070bab59d3595  vmovaps [rsp+0x20], xmm2
000070bab59d359b  vmovaps [rsp+0x30], xmm3
000070bab59d35a1  vmovaps [rsp+0x40], xmm4
000070bab59d35a7  vmovaps [rsp+0x50], xmm5
000070bab59d35ad  vmovaps [rsp+0x60], xmm7
000070bab59d35b3  vmovaps [rsp+0x70], xmm8
000070bab59d35b9  vmovaps [rsp+0x80], xmm9
000070bab59d35c2  vmovaps [rsp+0x90], xmm10
000070bab59d35cb  vmovaps [rsp+0xA0], xmm11
000070bab59d35d4  vmovaps [rsp+0xB0], xmm12
000070bab59d35dd  vmovaps [rsp+0xC0], xmm13
000070bab59d35e6  vmovaps [rsp+0xD0], xmm14
000070bab59d35ef  vmovaps [rsp+0xE0], xmm15
000070bab59d35f8  sub rsp, 0x30
000070bab59d35fc  movaps [rsp], xmm6
000070bab59d3600  movaps [rsp+0x10], xmm9
000070bab59d3606  movaps [rsp+0x20], xmm12
000070bab59d360c  lea rdi, [rsp]
000070bab59d3610  mov esi, 0x00
000070bab59d3615  mov rax, 0x63B35AFBC530
000070bab59d361f  call rax
000070bab59d3621  movaps xmm6, [rsp]
000070bab59d3625  add rsp, 0x30
000070bab59d3629  vmovaps xmm0, [rsp]
000070bab59d362e  vmovaps xmm1, [rsp+0x10]
000070bab59d3634  vmovaps xmm2, [rsp+0x20]
000070bab59d363a  vmovaps xmm3, [rsp+0x30]
000070bab59d3640  vmovaps xmm4, [rsp+0x40]
000070bab59d3646  vmovaps xmm5, [rsp+0x50]
000070bab59d364c  vmovaps xmm7, [rsp+0x60]
000070bab59d3652  vmovaps xmm8, [rsp+0x70]
000070bab59d3658  vmovaps xmm9, [rsp+0x80]
000070bab59d3661  vmovaps xmm10, [rsp+0x90]
000070bab59d366a  vmovaps xmm11, [rsp+0xA0]
000070bab59d3673  vmovaps xmm12, [rsp+0xB0]
000070bab59d367c  vmovaps xmm13, [rsp+0xC0]
000070bab59d3685  vmovaps xmm14, [rsp+0xD0]
000070bab59d368e  vmovaps xmm15, [rsp+0xE0]
000070bab59d3697  add rsp, 0xF0
000070bab59d369e  pop r11
000070bab59d36a0  pop r10
000070bab59d36a2  pop r9
000070bab59d36a4  pop r8
000070bab59d36a6  pop rsi
000070bab59d36a7  pop rdi
000070bab59d36a8  pop rdx
000070bab59d36a9  pop rcx
000070bab59d36aa  pop rax
000070bab59d36ab  add rsp, 0x08
000070bab59d36af  jmp 0x000070BAB59CFF19
000070bab59d36b4  sub rsp, 0x08
000070bab59d36b8  push rax
000070bab59d36b9  push rcx
000070bab59d36ba  push rdx
000070bab59d36bb  push rdi
000070bab59d36bc  push rsi
000070bab59d36bd  push r8
000070bab59d36bf  push r9
000070bab59d36c1  push r10
000070bab59d36c3  push r11
000070bab59d36c5  sub rsp, 0xF0
000070bab59d36cc  vmovaps [rsp], xmm0
000070bab59d36d1  vmovaps [rsp+0x10], xmm1
000070bab59d36d7  vmovaps [rsp+0x20], xmm2
000070bab59d36dd  vmovaps [rsp+0x30], xmm3
000070bab59d36e3  vmovaps [rsp+0x40], xmm4
000070bab59d36e9  vmovaps [rsp+0x50], xmm5
000070bab59d36ef  vmovaps [rsp+0x60], xmm6
000070bab59d36f5  vmovaps [rsp+0x70], xmm7
000070bab59d36fb  vmovaps [rsp+0x80], xmm8
000070bab59d3704  vmovaps [rsp+0x90], xmm9
000070bab59d370d  vmovaps [rsp+0xA0], xmm10
000070bab59d3716  vmovaps [rsp+0xB0], xmm11
000070bab59d371f  vmovaps [rsp+0xC0], xmm13
000070bab59d3728  vmovaps [rsp+0xD0], xmm14
000070bab59d3731  vmovaps [rsp+0xE0], xmm15
000070bab59d373a  sub rsp, 0x30
000070bab59d373e  movaps [rsp], xmm12
000070bab59d3743  movaps [rsp+0x10], xmm15
000070bab59d3749  movaps [rsp+0x20], xmm13
000070bab59d374f  lea rdi, [rsp]
000070bab59d3753  mov esi, 0x00
000070bab59d3758  mov rax, 0x63B35AFBC530
000070bab59d3762  call rax
000070bab59d3764  movaps xmm12, [rsp]
000070bab59d3769  add rsp, 0x30
000070bab59d376d  vmovaps xmm0, [rsp]
000070bab59d3772  vmovaps xmm1, [rsp+0x10]
000070bab59d3778  vmovaps xmm2, [rsp+0x20]
000070bab59d377e  vmovaps xmm3, [rsp+0x30]
000070bab59d3784  vmovaps xmm4, [rsp+0x40]
000070bab59d378a  vmovaps xmm5, [rsp+0x50]
000070bab59d3790  vmovaps xmm6, [rsp+0x60]
000070bab59d3796  vmovaps xmm7, [rsp+0x70]
000070bab59d379c  vmovaps xmm8, [rsp+0x80]
000070bab59d37a5  vmovaps xmm9, [rsp+0x90]
000070bab59d37ae  vmovaps xmm10, [rsp+0xA0]
000070bab59d37b7  vmovaps xmm11, [rsp+0xB0]
000070bab59d37c0  vmovaps xmm13, [rsp+0xC0]
000070bab59d37c9  vmovaps xmm14, [rsp+0xD0]
000070bab59d37d2  vmovaps xmm15, [rsp+0xE0]
000070bab59d37db  add rsp, 0xF0
000070bab59d37e2  pop r11
000070bab59d37e4  pop r10
000070bab59d37e6  pop r9
000070bab59d37e8  pop r8
000070bab59d37ea  pop rsi
000070bab59d37eb  pop rdi
000070bab59d37ec  pop rdx
000070bab59d37ed  pop rcx
000070bab59d37ee  pop rax
000070bab59d37ef  add rsp, 0x08
000070bab59d37f3  jmp 0x000070BAB59CFF34
000070bab59d37f8  sub rsp, 0x08
000070bab59d37fc  push rax
000070bab59d37fd  push rcx
000070bab59d37fe  push rdx
000070bab59d37ff  push rdi
000070bab59d3800  push rsi
000070bab59d3801  push r8
000070bab59d3803  push r9
000070bab59d3805  push r10
000070bab59d3807  push r11
000070bab59d3809  sub rsp, 0xF0
000070bab59d3810  vmovaps [rsp], xmm0
000070bab59d3815  vmovaps [rsp+0x10], xmm1
000070bab59d381b  vmovaps [rsp+0x20], xmm2
000070bab59d3821  vmovaps [rsp+0x30], xmm3
000070bab59d3827  vmovaps [rsp+0x40], xmm4
000070bab59d382d  vmovaps [rsp+0x50], xmm5
000070bab59d3833  vmovaps [rsp+0x60], xmm6
000070bab59d3839  vmovaps [rsp+0x70], xmm7
000070bab59d383f  vmovaps [rsp+0x80], xmm8
000070bab59d3848  vmovaps [rsp+0x90], xmm9
000070bab59d3851  vmovaps [rsp+0xA0], xmm10
000070bab59d385a  vmovaps [rsp+0xB0], xmm11
000070bab59d3863  vmovaps [rsp+0xC0], xmm12
000070bab59d386c  vmovaps [rsp+0xD0], xmm13
000070bab59d3875  vmovaps [rsp+0xE0], xmm14
000070bab59d387e  sub rsp, 0x30
000070bab59d3882  movaps [rsp], xmm15
000070bab59d3887  movaps [rsp+0x10], xmm13
000070bab59d388d  movaps [rsp+0x20], xmm10
000070bab59d3893  lea rdi, [rsp]
000070bab59d3897  mov esi, 0x00
000070bab59d389c  mov rax, 0x63B35AFBC530
000070bab59d38a6  call rax
000070bab59d38a8  movaps xmm15, [rsp]
000070bab59d38ad  add rsp, 0x30
000070bab59d38b1  vmovaps xmm0, [rsp]
000070bab59d38b6  vmovaps xmm1, [rsp+0x10]
000070bab59d38bc  vmovaps xmm2, [rsp+0x20]
000070bab59d38c2  vmovaps xmm3, [rsp+0x30]
000070bab59d38c8  vmovaps xmm4, [rsp+0x40]
000070bab59d38ce  vmovaps xmm5, [rsp+0x50]
000070bab59d38d4  vmovaps xmm6, [rsp+0x60]
000070bab59d38da  vmovaps xmm7, [rsp+0x70]
000070bab59d38e0  vmovaps xmm8, [rsp+0x80]
000070bab59d38e9  vmovaps xmm9, [rsp+0x90]
000070bab59d38f2  vmovaps xmm10, [rsp+0xA0]
000070bab59d38fb  vmovaps xmm11, [rsp+0xB0]
000070bab59d3904  vmovaps xmm12, [rsp+0xC0]
000070bab59d390d  vmovaps xmm13, [rsp+0xD0]
000070bab59d3916  vmovaps xmm14, [rsp+0xE0]
000070bab59d391f  add rsp, 0xF0
000070bab59d3926  pop r11
000070bab59d3928  pop r10
000070bab59d392a  pop r9
000070bab59d392c  pop r8
000070bab59d392e  pop rsi
000070bab59d392f  pop rdi
000070bab59d3930  pop rdx
000070bab59d3931  pop rcx
000070bab59d3932  pop rax
000070bab59d3933  add rsp, 0x08
000070bab59d3937  jmp 0x000070BAB59CFF55
000070bab59d393c  call 0x000070BAB580C260
000070bab59d3941  jmp 0x000070BAB59CFFB0
000070bab59d3946  sub rsp, 0x08
000070bab59d394a  push rax
000070bab59d394b  push rcx
000070bab59d394c  push rdx
000070bab59d394d  push rdi
000070bab59d394e  push rsi
000070bab59d394f  push r8
000070bab59d3951  push r9
000070bab59d3953  push r10
000070bab59d3955  push r11
000070bab59d3957  sub rsp, 0xF0
000070bab59d395e  vmovaps [rsp], xmm0
000070bab59d3963  vmovaps [rsp+0x10], xmm1
000070bab59d3969  vmovaps [rsp+0x20], xmm2
000070bab59d396f  vmovaps [rsp+0x30], xmm3
000070bab59d3975  vmovaps [rsp+0x40], xmm4
000070bab59d397b  vmovaps [rsp+0x50], xmm5
000070bab59d3981  vmovaps [rsp+0x60], xmm6
000070bab59d3987  vmovaps [rsp+0x70], xmm7
000070bab59d398d  vmovaps [rsp+0x80], xmm8
000070bab59d3996  vmovaps [rsp+0x90], xmm10
000070bab59d399f  vmovaps [rsp+0xA0], xmm11
000070bab59d39a8  vmovaps [rsp+0xB0], xmm12
000070bab59d39b1  vmovaps [rsp+0xC0], xmm13
000070bab59d39ba  vmovaps [rsp+0xD0], xmm14
000070bab59d39c3  vmovaps [rsp+0xE0], xmm15
000070bab59d39cc  sub rsp, 0x30
000070bab59d39d0  movaps [rsp], xmm9
000070bab59d39d5  movaps [rsp+0x10], xmm8
000070bab59d39db  movaps [rsp+0x20], xmm10
000070bab59d39e1  lea rdi, [rsp]
000070bab59d39e5  mov esi, 0x00
000070bab59d39ea  mov rax, 0x63B35AFBC530
000070bab59d39f4  call rax
000070bab59d39f6  movaps xmm9, [rsp]
000070bab59d39fb  add rsp, 0x30
000070bab59d39ff  vmovaps xmm0, [rsp]
000070bab59d3a04  vmovaps xmm1, [rsp+0x10]
000070bab59d3a0a  vmovaps xmm2, [rsp+0x20]
000070bab59d3a10  vmovaps xmm3, [rsp+0x30]
000070bab59d3a16  vmovaps xmm4, [rsp+0x40]
000070bab59d3a1c  vmovaps xmm5, [rsp+0x50]
000070bab59d3a22  vmovaps xmm6, [rsp+0x60]
000070bab59d3a28  vmovaps xmm7, [rsp+0x70]
000070bab59d3a2e  vmovaps xmm8, [rsp+0x80]
000070bab59d3a37  vmovaps xmm10, [rsp+0x90]
000070bab59d3a40  vmovaps xmm11, [rsp+0xA0]
000070bab59d3a49  vmovaps xmm12, [rsp+0xB0]
000070bab59d3a52  vmovaps xmm13, [rsp+0xC0]
000070bab59d3a5b  vmovaps xmm14, [rsp+0xD0]
000070bab59d3a64  vmovaps xmm15, [rsp+0xE0]
000070bab59d3a6d  add rsp, 0xF0
000070bab59d3a74  pop r11
000070bab59d3a76  pop r10
000070bab59d3a78  pop r9
000070bab59d3a7a  pop r8
000070bab59d3a7c  pop rsi
000070bab59d3a7d  pop rdi
000070bab59d3a7e  pop rdx
000070bab59d3a7f  pop rcx
000070bab59d3a80  pop rax
000070bab59d3a81  add rsp, 0x08
000070bab59d3a85  jmp 0x000070BAB59CFFE1
000070bab59d3a8a  sub rsp, 0x08
000070bab59d3a8e  push rax
000070bab59d3a8f  push rcx
000070bab59d3a90  push rdx
000070bab59d3a91  push rdi
000070bab59d3a92  push rsi
000070bab59d3a93  push r8
000070bab59d3a95  push r9
000070bab59d3a97  push r10
000070bab59d3a99  push r11
000070bab59d3a9b  sub rsp, 0xF0
000070bab59d3aa2  vmovaps [rsp], xmm0
000070bab59d3aa7  vmovaps [rsp+0x10], xmm1
000070bab59d3aad  vmovaps [rsp+0x20], xmm2
000070bab59d3ab3  vmovaps [rsp+0x30], xmm3
000070bab59d3ab9  vmovaps [rsp+0x40], xmm4
000070bab59d3abf  vmovaps [rsp+0x50], xmm5
000070bab59d3ac5  vmovaps [rsp+0x60], xmm6
000070bab59d3acb  vmovaps [rsp+0x70], xmm7
000070bab59d3ad1  vmovaps [rsp+0x80], xmm8
000070bab59d3ada  vmovaps [rsp+0x90], xmm9
000070bab59d3ae3  vmovaps [rsp+0xA0], xmm11
000070bab59d3aec  vmovaps [rsp+0xB0], xmm12
000070bab59d3af5  vmovaps [rsp+0xC0], xmm13
000070bab59d3afe  vmovaps [rsp+0xD0], xmm14
000070bab59d3b07  vmovaps [rsp+0xE0], xmm15
000070bab59d3b10  sub rsp, 0x30
000070bab59d3b14  movaps [rsp], xmm10
000070bab59d3b19  movaps [rsp+0x10], xmm1
000070bab59d3b1e  movaps [rsp+0x20], xmm11
000070bab59d3b24  lea rdi, [rsp]
000070bab59d3b28  mov esi, 0x00
000070bab59d3b2d  mov rax, 0x63B35AFBC530
000070bab59d3b37  call rax
000070bab59d3b39  movaps xmm10, [rsp]
000070bab59d3b3e  add rsp, 0x30
000070bab59d3b42  vmovaps xmm0, [rsp]
000070bab59d3b47  vmovaps xmm1, [rsp+0x10]
000070bab59d3b4d  vmovaps xmm2, [rsp+0x20]
000070bab59d3b53  vmovaps xmm3, [rsp+0x30]
000070bab59d3b59  vmovaps xmm4, [rsp+0x40]
000070bab59d3b5f  vmovaps xmm5, [rsp+0x50]
000070bab59d3b65  vmovaps xmm6, [rsp+0x60]
000070bab59d3b6b  vmovaps xmm7, [rsp+0x70]
000070bab59d3b71  vmovaps xmm8, [rsp+0x80]
000070bab59d3b7a  vmovaps xmm9, [rsp+0x90]
000070bab59d3b83  vmovaps xmm11, [rsp+0xA0]
000070bab59d3b8c  vmovaps xmm12, [rsp+0xB0]
000070bab59d3b95  vmovaps xmm13, [rsp+0xC0]
000070bab59d3b9e  vmovaps xmm14, [rsp+0xD0]
000070bab59d3ba7  vmovaps xmm15, [rsp+0xE0]
000070bab59d3bb0  add rsp, 0xF0
000070bab59d3bb7  pop r11
000070bab59d3bb9  pop r10
000070bab59d3bbb  pop r9
000070bab59d3bbd  pop r8
000070bab59d3bbf  pop rsi
000070bab59d3bc0  pop rdi
000070bab59d3bc1  pop rdx
000070bab59d3bc2  pop rcx
000070bab59d3bc3  pop rax
000070bab59d3bc4  add rsp, 0x08
000070bab59d3bc8  jmp 0x000070BAB59CFFFC
000070bab59d3bcd  sub rsp, 0x08
000070bab59d3bd1  push rax
000070bab59d3bd2  push rcx
000070bab59d3bd3  push rdx
000070bab59d3bd4  push rdi
000070bab59d3bd5  push rsi
000070bab59d3bd6  push r8
000070bab59d3bd8  push r9
000070bab59d3bda  push r10
000070bab59d3bdc  push r11
000070bab59d3bde  sub rsp, 0xF0
000070bab59d3be5  vmovaps [rsp], xmm0
000070bab59d3bea  vmovaps [rsp+0x10], xmm2
000070bab59d3bf0  vmovaps [rsp+0x20], xmm3
000070bab59d3bf6  vmovaps [rsp+0x30], xmm4
000070bab59d3bfc  vmovaps [rsp+0x40], xmm5
000070bab59d3c02  vmovaps [rsp+0x50], xmm6
000070bab59d3c08  vmovaps [rsp+0x60], xmm7
000070bab59d3c0e  vmovaps [rsp+0x70], xmm8
000070bab59d3c14  vmovaps [rsp+0x80], xmm9
000070bab59d3c1d  vmovaps [rsp+0x90], xmm10
000070bab59d3c26  vmovaps [rsp+0xA0], xmm11
000070bab59d3c2f  vmovaps [rsp+0xB0], xmm12
000070bab59d3c38  vmovaps [rsp+0xC0], xmm13
000070bab59d3c41  vmovaps [rsp+0xD0], xmm14
000070bab59d3c4a  vmovaps [rsp+0xE0], xmm15
000070bab59d3c53  sub rsp, 0x30
000070bab59d3c57  movaps [rsp], xmm1
000070bab59d3c5b  movaps [rsp+0x10], xmm14
000070bab59d3c61  movaps [rsp+0x20], xmm6
000070bab59d3c66  lea rdi, [rsp]
000070bab59d3c6a  mov esi, 0x00
000070bab59d3c6f  mov rax, 0x63B35AFBC530
000070bab59d3c79  call rax
000070bab59d3c7b  movaps xmm1, [rsp]
000070bab59d3c7f  add rsp, 0x30
000070bab59d3c83  vmovaps xmm0, [rsp]
000070bab59d3c88  vmovaps xmm2, [rsp+0x10]
000070bab59d3c8e  vmovaps xmm3, [rsp+0x20]
000070bab59d3c94  vmovaps xmm4, [rsp+0x30]
000070bab59d3c9a  vmovaps xmm5, [rsp+0x40]
000070bab59d3ca0  vmovaps xmm6, [rsp+0x50]
000070bab59d3ca6  vmovaps xmm7, [rsp+0x60]
000070bab59d3cac  vmovaps xmm8, [rsp+0x70]
000070bab59d3cb2  vmovaps xmm9, [rsp+0x80]
000070bab59d3cbb  vmovaps xmm10, [rsp+0x90]
000070bab59d3cc4  vmovaps xmm11, [rsp+0xA0]
000070bab59d3ccd  vmovaps xmm12, [rsp+0xB0]
000070bab59d3cd6  vmovaps xmm13, [rsp+0xC0]
000070bab59d3cdf  vmovaps xmm14, [rsp+0xD0]
000070bab59d3ce8  vmovaps xmm15, [rsp+0xE0]
000070bab59d3cf1  add rsp, 0xF0
000070bab59d3cf8  pop r11
000070bab59d3cfa  pop r10
000070bab59d3cfc  pop r9
000070bab59d3cfe  pop r8
000070bab59d3d00  pop rsi
000070bab59d3d01  pop rdi
000070bab59d3d02  pop rdx
000070bab59d3d03  pop rcx
000070bab59d3d04  pop rax
000070bab59d3d05  add rsp, 0x08
000070bab59d3d09  jmp 0x000070BAB59D0015
000070bab59d3d0e  sub rsp, 0x08
000070bab59d3d12  push rax
000070bab59d3d13  push rcx
000070bab59d3d14  push rdx
000070bab59d3d15  push rdi
000070bab59d3d16  push rsi
000070bab59d3d17  push r8
000070bab59d3d19  push r9
000070bab59d3d1b  push r10
000070bab59d3d1d  push r11
000070bab59d3d1f  sub rsp, 0xF0
000070bab59d3d26  vmovaps [rsp], xmm0
000070bab59d3d2b  vmovaps [rsp+0x10], xmm1
000070bab59d3d31  vmovaps [rsp+0x20], xmm2
000070bab59d3d37  vmovaps [rsp+0x30], xmm3
000070bab59d3d3d  vmovaps [rsp+0x40], xmm4
000070bab59d3d43  vmovaps [rsp+0x50], xmm5
000070bab59d3d49  vmovaps [rsp+0x60], xmm6
000070bab59d3d4f  vmovaps [rsp+0x70], xmm7
000070bab59d3d55  vmovaps [rsp+0x80], xmm8
000070bab59d3d5e  vmovaps [rsp+0x90], xmm9
000070bab59d3d67  vmovaps [rsp+0xA0], xmm10
000070bab59d3d70  vmovaps [rsp+0xB0], xmm12
000070bab59d3d79  vmovaps [rsp+0xC0], xmm13
000070bab59d3d82  vmovaps [rsp+0xD0], xmm14
000070bab59d3d8b  vmovaps [rsp+0xE0], xmm15
000070bab59d3d94  sub rsp, 0x30
000070bab59d3d98  movaps [rsp], xmm11
000070bab59d3d9d  movaps [rsp+0x10], xmm13
000070bab59d3da3  movaps [rsp+0x20], xmm14
000070bab59d3da9  lea rdi, [rsp]
000070bab59d3dad  mov esi, 0x00
000070bab59d3db2  mov rax, 0x63B35AFBC530
000070bab59d3dbc  call rax
000070bab59d3dbe  movaps xmm11, [rsp]
000070bab59d3dc3  add rsp, 0x30
000070bab59d3dc7  vmovaps xmm0, [rsp]
000070bab59d3dcc  vmovaps xmm1, [rsp+0x10]
000070bab59d3dd2  vmovaps xmm2, [rsp+0x20]
000070bab59d3dd8  vmovaps xmm3, [rsp+0x30]
000070bab59d3dde  vmovaps xmm4, [rsp+0x40]
000070bab59d3de4  vmovaps xmm5, [rsp+0x50]
000070bab59d3dea  vmovaps xmm6, [rsp+0x60]
000070bab59d3df0  vmovaps xmm7, [rsp+0x70]
000070bab59d3df6  vmovaps xmm8, [rsp+0x80]
000070bab59d3dff  vmovaps xmm9, [rsp+0x90]
000070bab59d3e08  vmovaps xmm10, [rsp+0xA0]
000070bab59d3e11  vmovaps xmm12, [rsp+0xB0]
000070bab59d3e1a  vmovaps xmm13, [rsp+0xC0]
000070bab59d3e23  vmovaps xmm14, [rsp+0xD0]
000070bab59d3e2c  vmovaps xmm15, [rsp+0xE0]
000070bab59d3e35  add rsp, 0xF0
000070bab59d3e3c  pop r11
000070bab59d3e3e  pop r10
000070bab59d3e40  pop r9
000070bab59d3e42  pop r8
000070bab59d3e44  pop rsi
000070bab59d3e45  pop rdi
000070bab59d3e46  pop rdx
000070bab59d3e47  pop rcx
000070bab59d3e48  pop rax
000070bab59d3e49  add rsp, 0x08
000070bab59d3e4d  jmp 0x000070BAB59D003F
000070bab59d3e52  sub rsp, 0x08
000070bab59d3e56  push rax
000070bab59d3e57  push rcx
000070bab59d3e58  push rdx
000070bab59d3e59  push rdi
000070bab59d3e5a  push rsi
000070bab59d3e5b  push r8
000070bab59d3e5d  push r9
000070bab59d3e5f  push r10
000070bab59d3e61  push r11
000070bab59d3e63  sub rsp, 0xF0
000070bab59d3e6a  vmovaps [rsp], xmm0
000070bab59d3e6f  vmovaps [rsp+0x10], xmm1
000070bab59d3e75  vmovaps [rsp+0x20], xmm2
000070bab59d3e7b  vmovaps [rsp+0x30], xmm3
000070bab59d3e81  vmovaps [rsp+0x40], xmm4
000070bab59d3e87  vmovaps [rsp+0x50], xmm5
000070bab59d3e8d  vmovaps [rsp+0x60], xmm6
000070bab59d3e93  vmovaps [rsp+0x70], xmm7
000070bab59d3e99  vmovaps [rsp+0x80], xmm8
000070bab59d3ea2  vmovaps [rsp+0x90], xmm9
000070bab59d3eab  vmovaps [rsp+0xA0], xmm10
000070bab59d3eb4  vmovaps [rsp+0xB0], xmm11
000070bab59d3ebd  vmovaps [rsp+0xC0], xmm12
000070bab59d3ec6  vmovaps [rsp+0xD0], xmm14
000070bab59d3ecf  vmovaps [rsp+0xE0], xmm15
000070bab59d3ed8  sub rsp, 0x30
000070bab59d3edc  movaps [rsp], xmm13
000070bab59d3ee1  movaps [rsp+0x10], xmm8
000070bab59d3ee7  movaps [rsp+0x20], xmm14
000070bab59d3eed  lea rdi, [rsp]
000070bab59d3ef1  mov esi, 0x00
000070bab59d3ef6  mov rax, 0x63B35AFBC530
000070bab59d3f00  call rax
000070bab59d3f02  movaps xmm13, [rsp]
000070bab59d3f07  add rsp, 0x30
000070bab59d3f0b  vmovaps xmm0, [rsp]
000070bab59d3f10  vmovaps xmm1, [rsp+0x10]
000070bab59d3f16  vmovaps xmm2, [rsp+0x20]
000070bab59d3f1c  vmovaps xmm3, [rsp+0x30]
000070bab59d3f22  vmovaps xmm4, [rsp+0x40]
000070bab59d3f28  vmovaps xmm5, [rsp+0x50]
000070bab59d3f2e  vmovaps xmm6, [rsp+0x60]
000070bab59d3f34  vmovaps xmm7, [rsp+0x70]
000070bab59d3f3a  vmovaps xmm8, [rsp+0x80]
000070bab59d3f43  vmovaps xmm9, [rsp+0x90]
000070bab59d3f4c  vmovaps xmm10, [rsp+0xA0]
000070bab59d3f55  vmovaps xmm11, [rsp+0xB0]
000070bab59d3f5e  vmovaps xmm12, [rsp+0xC0]
000070bab59d3f67  vmovaps xmm14, [rsp+0xD0]
000070bab59d3f70  vmovaps xmm15, [rsp+0xE0]
000070bab59d3f79  add rsp, 0xF0
000070bab59d3f80  pop r11
000070bab59d3f82  pop r10
000070bab59d3f84  pop r9
000070bab59d3f86  pop r8
000070bab59d3f88  pop rsi
000070bab59d3f89  pop rdi
000070bab59d3f8a  pop rdx
000070bab59d3f8b  pop rcx
000070bab59d3f8c  pop rax
000070bab59d3f8d  add rsp, 0x08
000070bab59d3f91  jmp 0x000070BAB59D006E
000070bab59d3f96  sub rsp, 0x08
000070bab59d3f9a  push rax
000070bab59d3f9b  push rcx
000070bab59d3f9c  push rdx
000070bab59d3f9d  push rdi
000070bab59d3f9e  push rsi
000070bab59d3f9f  push r8
000070bab59d3fa1  push r9
000070bab59d3fa3  push r10
000070bab59d3fa5  push r11
000070bab59d3fa7  sub rsp, 0xF0
000070bab59d3fae  vmovaps [rsp], xmm0
000070bab59d3fb3  vmovaps [rsp+0x10], xmm1
000070bab59d3fb9  vmovaps [rsp+0x20], xmm2
000070bab59d3fbf  vmovaps [rsp+0x30], xmm3
000070bab59d3fc5  vmovaps [rsp+0x40], xmm4
000070bab59d3fcb  vmovaps [rsp+0x50], xmm5
000070bab59d3fd1  vmovaps [rsp+0x60], xmm6
000070bab59d3fd7  vmovaps [rsp+0x70], xmm7
000070bab59d3fdd  vmovaps [rsp+0x80], xmm9
000070bab59d3fe6  vmovaps [rsp+0x90], xmm10
000070bab59d3fef  vmovaps [rsp+0xA0], xmm11
000070bab59d3ff8  vmovaps [rsp+0xB0], xmm12
000070bab59d4001  vmovaps [rsp+0xC0], xmm13
000070bab59d400a  vmovaps [rsp+0xD0], xmm14
000070bab59d4013  vmovaps [rsp+0xE0], xmm15
000070bab59d401c  sub rsp, 0x30
000070bab59d4020  movaps [rsp], xmm8
000070bab59d4025  movaps [rsp+0x10], xmm7
000070bab59d402a  movaps [rsp+0x20], xmm14
000070bab59d4030  lea rdi, [rsp]
000070bab59d4034  mov esi, 0x00
000070bab59d4039  mov rax, 0x63B35AFBC530
000070bab59d4043  call rax
000070bab59d4045  movaps xmm8, [rsp]
000070bab59d404a  add rsp, 0x30
000070bab59d404e  vmovaps xmm0, [rsp]
000070bab59d4053  vmovaps xmm1, [rsp+0x10]
000070bab59d4059  vmovaps xmm2, [rsp+0x20]
000070bab59d405f  vmovaps xmm3, [rsp+0x30]
000070bab59d4065  vmovaps xmm4, [rsp+0x40]
000070bab59d406b  vmovaps xmm5, [rsp+0x50]
000070bab59d4071  vmovaps xmm6, [rsp+0x60]
000070bab59d4077  vmovaps xmm7, [rsp+0x70]
000070bab59d407d  vmovaps xmm9, [rsp+0x80]
000070bab59d4086  vmovaps xmm10, [rsp+0x90]
000070bab59d408f  vmovaps xmm11, [rsp+0xA0]
000070bab59d4098  vmovaps xmm12, [rsp+0xB0]
000070bab59d40a1  vmovaps xmm13, [rsp+0xC0]
000070bab59d40aa  vmovaps xmm14, [rsp+0xD0]
000070bab59d40b3  vmovaps xmm15, [rsp+0xE0]
000070bab59d40bc  add rsp, 0xF0
000070bab59d40c3  pop r11
000070bab59d40c5  pop r10
000070bab59d40c7  pop r9
000070bab59d40c9  pop r8
000070bab59d40cb  pop rsi
000070bab59d40cc  pop rdi
000070bab59d40cd  pop rdx
000070bab59d40ce  pop rcx
000070bab59d40cf  pop rax
000070bab59d40d0  add rsp, 0x08
000070bab59d40d4  jmp 0x000070BAB59D0094
000070bab59d40d9  sub rsp, 0x08
000070bab59d40dd  push rax
000070bab59d40de  push rcx
000070bab59d40df  push rdx
000070bab59d40e0  push rdi
000070bab59d40e1  push rsi
000070bab59d40e2  push r8
000070bab59d40e4  push r9
000070bab59d40e6  push r10
000070bab59d40e8  push r11
000070bab59d40ea  sub rsp, 0xF0
000070bab59d40f1  vmovaps [rsp], xmm0
000070bab59d40f6  vmovaps [rsp+0x10], xmm1
000070bab59d40fc  vmovaps [rsp+0x20], xmm2
000070bab59d4102  vmovaps [rsp+0x30], xmm3
000070bab59d4108  vmovaps [rsp+0x40], xmm4
000070bab59d410e  vmovaps [rsp+0x50], xmm5
000070bab59d4114  vmovaps [rsp+0x60], xmm6
000070bab59d411a  vmovaps [rsp+0x70], xmm7
000070bab59d4120  vmovaps [rsp+0x80], xmm8
000070bab59d4129  vmovaps [rsp+0x90], xmm9
000070bab59d4132  vmovaps [rsp+0xA0], xmm10
000070bab59d413b  vmovaps [rsp+0xB0], xmm11
000070bab59d4144  vmovaps [rsp+0xC0], xmm12
000070bab59d414d  vmovaps [rsp+0xD0], xmm13
000070bab59d4156  vmovaps [rsp+0xE0], xmm15
000070bab59d415f  sub rsp, 0x30
000070bab59d4163  movaps [rsp], xmm14
000070bab59d4168  movaps [rsp+0x10], xmm12
000070bab59d416e  movaps [rsp+0x20], xmm9
000070bab59d4174  lea rdi, [rsp]
000070bab59d4178  mov esi, 0x00
000070bab59d417d  mov rax, 0x63B35AFBC530
000070bab59d4187  call rax
000070bab59d4189  movaps xmm14, [rsp]
000070bab59d418e  add rsp, 0x30
000070bab59d4192  vmovaps xmm0, [rsp]
000070bab59d4197  vmovaps xmm1, [rsp+0x10]
000070bab59d419d  vmovaps xmm2, [rsp+0x20]
000070bab59d41a3  vmovaps xmm3, [rsp+0x30]
000070bab59d41a9  vmovaps xmm4, [rsp+0x40]
000070bab59d41af  vmovaps xmm5, [rsp+0x50]
000070bab59d41b5  vmovaps xmm6, [rsp+0x60]
000070bab59d41bb  vmovaps xmm7, [rsp+0x70]
000070bab59d41c1  vmovaps xmm8, [rsp+0x80]
000070bab59d41ca  vmovaps xmm9, [rsp+0x90]
000070bab59d41d3  vmovaps xmm10, [rsp+0xA0]
000070bab59d41dc  vmovaps xmm11, [rsp+0xB0]
000070bab59d41e5  vmovaps xmm12, [rsp+0xC0]
000070bab59d41ee  vmovaps xmm13, [rsp+0xD0]
000070bab59d41f7  vmovaps xmm15, [rsp+0xE0]
000070bab59d4200  add rsp, 0xF0
000070bab59d4207  pop r11
000070bab59d4209  pop r10
000070bab59d420b  pop r9
000070bab59d420d  pop r8
000070bab59d420f  pop rsi
000070bab59d4210  pop rdi
000070bab59d4211  pop rdx
000070bab59d4212  pop rcx
000070bab59d4213  pop rax
000070bab59d4214  add rsp, 0x08
000070bab59d4218  jmp 0x000070BAB59D00AE
000070bab59d421d  sub rsp, 0x08
000070bab59d4221  push rax
000070bab59d4222  push rcx
000070bab59d4223  push rdx
000070bab59d4224  push rdi
000070bab59d4225  push rsi
000070bab59d4226  push r8
000070bab59d4228  push r9
000070bab59d422a  push r10
000070bab59d422c  push r11
000070bab59d422e  sub rsp, 0xF0
000070bab59d4235  vmovaps [rsp], xmm0
000070bab59d423a  vmovaps [rsp+0x10], xmm1
000070bab59d4240  vmovaps [rsp+0x20], xmm2
000070bab59d4246  vmovaps [rsp+0x30], xmm3
000070bab59d424c  vmovaps [rsp+0x40], xmm4
000070bab59d4252  vmovaps [rsp+0x50], xmm5
000070bab59d4258  vmovaps [rsp+0x60], xmm6
000070bab59d425e  vmovaps [rsp+0x70], xmm7
000070bab59d4264  vmovaps [rsp+0x80], xmm8
000070bab59d426d  vmovaps [rsp+0x90], xmm10
000070bab59d4276  vmovaps [rsp+0xA0], xmm11
000070bab59d427f  vmovaps [rsp+0xB0], xmm12
000070bab59d4288  vmovaps [rsp+0xC0], xmm13
000070bab59d4291  vmovaps [rsp+0xD0], xmm14
000070bab59d429a  vmovaps [rsp+0xE0], xmm15
000070bab59d42a3  sub rsp, 0x30
000070bab59d42a7  movaps [rsp], xmm9
000070bab59d42ac  movaps [rsp+0x10], xmm7
000070bab59d42b1  movaps [rsp+0x20], xmm12
000070bab59d42b7  lea rdi, [rsp]
000070bab59d42bb  mov esi, 0x00
000070bab59d42c0  mov rax, 0x63B35AFBC530
000070bab59d42ca  call rax
000070bab59d42cc  movaps xmm9, [rsp]
000070bab59d42d1  add rsp, 0x30
000070bab59d42d5  vmovaps xmm0, [rsp]
000070bab59d42da  vmovaps xmm1, [rsp+0x10]
000070bab59d42e0  vmovaps xmm2, [rsp+0x20]
000070bab59d42e6  vmovaps xmm3, [rsp+0x30]
000070bab59d42ec  vmovaps xmm4, [rsp+0x40]
000070bab59d42f2  vmovaps xmm5, [rsp+0x50]
000070bab59d42f8  vmovaps xmm6, [rsp+0x60]
000070bab59d42fe  vmovaps xmm7, [rsp+0x70]
000070bab59d4304  vmovaps xmm8, [rsp+0x80]
000070bab59d430d  vmovaps xmm10, [rsp+0x90]
000070bab59d4316  vmovaps xmm11, [rsp+0xA0]
000070bab59d431f  vmovaps xmm12, [rsp+0xB0]
000070bab59d4328  vmovaps xmm13, [rsp+0xC0]
000070bab59d4331  vmovaps xmm14, [rsp+0xD0]
000070bab59d433a  vmovaps xmm15, [rsp+0xE0]
000070bab59d4343  add rsp, 0xF0
000070bab59d434a  pop r11
000070bab59d434c  pop r10
000070bab59d434e  pop r9
000070bab59d4350  pop r8
000070bab59d4352  pop rsi
000070bab59d4353  pop rdi
000070bab59d4354  pop rdx
000070bab59d4355  pop rcx
000070bab59d4356  pop rax
000070bab59d4357  add rsp, 0x08
000070bab59d435b  jmp 0x000070BAB59D00DD
000070bab59d4360  sub rsp, 0x08
000070bab59d4364  push rax
000070bab59d4365  push rcx
000070bab59d4366  push rdx
000070bab59d4367  push rdi
000070bab59d4368  push rsi
000070bab59d4369  push r8
000070bab59d436b  push r9
000070bab59d436d  push r10
000070bab59d436f  push r11
000070bab59d4371  sub rsp, 0xF0
000070bab59d4378  vmovaps [rsp], xmm0
000070bab59d437d  vmovaps [rsp+0x10], xmm1
000070bab59d4383  vmovaps [rsp+0x20], xmm2
000070bab59d4389  vmovaps [rsp+0x30], xmm3
000070bab59d438f  vmovaps [rsp+0x40], xmm4
000070bab59d4395  vmovaps [rsp+0x50], xmm5
000070bab59d439b  vmovaps [rsp+0x60], xmm6
000070bab59d43a1  vmovaps [rsp+0x70], xmm7
000070bab59d43a7  vmovaps [rsp+0x80], xmm8
000070bab59d43b0  vmovaps [rsp+0x90], xmm9
000070bab59d43b9  vmovaps [rsp+0xA0], xmm10
000070bab59d43c2  vmovaps [rsp+0xB0], xmm11
000070bab59d43cb  vmovaps [rsp+0xC0], xmm13
000070bab59d43d4  vmovaps [rsp+0xD0], xmm14
000070bab59d43dd  vmovaps [rsp+0xE0], xmm15
000070bab59d43e6  sub rsp, 0x30
000070bab59d43ea  movaps [rsp], xmm12
000070bab59d43ef  movaps [rsp+0x10], xmm15
000070bab59d43f5  movaps [rsp+0x20], xmm11
000070bab59d43fb  lea rdi, [rsp]
000070bab59d43ff  mov esi, 0x00
000070bab59d4404  mov rax, 0x63B35AFBC530
000070bab59d440e  call rax
000070bab59d4410  movaps xmm12, [rsp]
000070bab59d4415  add rsp, 0x30
000070bab59d4419  vmovaps xmm0, [rsp]
000070bab59d441e  vmovaps xmm1, [rsp+0x10]
000070bab59d4424  vmovaps xmm2, [rsp+0x20]
000070bab59d442a  vmovaps xmm3, [rsp+0x30]
000070bab59d4430  vmovaps xmm4, [rsp+0x40]
000070bab59d4436  vmovaps xmm5, [rsp+0x50]
000070bab59d443c  vmovaps xmm6, [rsp+0x60]
000070bab59d4442  vmovaps xmm7, [rsp+0x70]
000070bab59d4448  vmovaps xmm8, [rsp+0x80]
000070bab59d4451  vmovaps xmm9, [rsp+0x90]
000070bab59d445a  vmovaps xmm10, [rsp+0xA0]
000070bab59d4463  vmovaps xmm11, [rsp+0xB0]
000070bab59d446c  vmovaps xmm13, [rsp+0xC0]
000070bab59d4475  vmovaps xmm14, [rsp+0xD0]
000070bab59d447e  vmovaps xmm15, [rsp+0xE0]
000070bab59d4487  add rsp, 0xF0
000070bab59d448e  pop r11
000070bab59d4490  pop r10
000070bab59d4492  pop r9
000070bab59d4494  pop r8
000070bab59d4496  pop rsi
000070bab59d4497  pop rdi
000070bab59d4498  pop rdx
000070bab59d4499  pop rcx
000070bab59d449a  pop rax
000070bab59d449b  add rsp, 0x08
000070bab59d449f  jmp 0x000070BAB59D00F7
000070bab59d44a4  sub rsp, 0x08
000070bab59d44a8  push rax
000070bab59d44a9  push rcx
000070bab59d44aa  push rdx
000070bab59d44ab  push rdi
000070bab59d44ac  push rsi
000070bab59d44ad  push r8
000070bab59d44af  push r9
000070bab59d44b1  push r10
000070bab59d44b3  push r11
000070bab59d44b5  sub rsp, 0xF0
000070bab59d44bc  vmovaps [rsp], xmm0
000070bab59d44c1  vmovaps [rsp+0x10], xmm1
000070bab59d44c7  vmovaps [rsp+0x20], xmm2
000070bab59d44cd  vmovaps [rsp+0x30], xmm3
000070bab59d44d3  vmovaps [rsp+0x40], xmm4
000070bab59d44d9  vmovaps [rsp+0x50], xmm5
000070bab59d44df  vmovaps [rsp+0x60], xmm6
000070bab59d44e5  vmovaps [rsp+0x70], xmm7
000070bab59d44eb  vmovaps [rsp+0x80], xmm8
000070bab59d44f4  vmovaps [rsp+0x90], xmm9
000070bab59d44fd  vmovaps [rsp+0xA0], xmm10
000070bab59d4506  vmovaps [rsp+0xB0], xmm12
000070bab59d450f  vmovaps [rsp+0xC0], xmm13
000070bab59d4518  vmovaps [rsp+0xD0], xmm14
000070bab59d4521  vmovaps [rsp+0xE0], xmm15
000070bab59d452a  sub rsp, 0x30
000070bab59d452e  movaps [rsp], xmm11
000070bab59d4533  movaps [rsp+0x10], xmm7
000070bab59d4538  movaps [rsp+0x20], xmm15
000070bab59d453e  lea rdi, [rsp]
000070bab59d4542  mov esi, 0x00
000070bab59d4547  mov rax, 0x63B35AFBC530
000070bab59d4551  call rax
000070bab59d4553  movaps xmm11, [rsp]
000070bab59d4558  add rsp, 0x30
000070bab59d455c  vmovaps xmm0, [rsp]
000070bab59d4561  vmovaps xmm1, [rsp+0x10]
000070bab59d4567  vmovaps xmm2, [rsp+0x20]
000070bab59d456d  vmovaps xmm3, [rsp+0x30]
000070bab59d4573  vmovaps xmm4, [rsp+0x40]
000070bab59d4579  vmovaps xmm5, [rsp+0x50]
000070bab59d457f  vmovaps xmm6, [rsp+0x60]
000070bab59d4585  vmovaps xmm7, [rsp+0x70]
000070bab59d458b  vmovaps xmm8, [rsp+0x80]
000070bab59d4594  vmovaps xmm9, [rsp+0x90]
000070bab59d459d  vmovaps xmm10, [rsp+0xA0]
000070bab59d45a6  vmovaps xmm12, [rsp+0xB0]
000070bab59d45af  vmovaps xmm13, [rsp+0xC0]
000070bab59d45b8  vmovaps xmm14, [rsp+0xD0]
000070bab59d45c1  vmovaps xmm15, [rsp+0xE0]
000070bab59d45ca  add rsp, 0xF0
000070bab59d45d1  pop r11
000070bab59d45d3  pop r10
000070bab59d45d5  pop r9
000070bab59d45d7  pop r8
000070bab59d45d9  pop rsi
000070bab59d45da  pop rdi
000070bab59d45db  pop rdx
000070bab59d45dc  pop rcx
000070bab59d45dd  pop rax
000070bab59d45de  add rsp, 0x08
000070bab59d45e2  jmp 0x000070BAB59D0123
000070bab59d45e7  sub rsp, 0x08
000070bab59d45eb  push rax
000070bab59d45ec  push rcx
000070bab59d45ed  push rdx
000070bab59d45ee  push rdi
000070bab59d45ef  push rsi
000070bab59d45f0  push r8
000070bab59d45f2  push r9
000070bab59d45f4  push r10
000070bab59d45f6  push r11
000070bab59d45f8  sub rsp, 0xF0
000070bab59d45ff  vmovaps [rsp], xmm0
000070bab59d4604  vmovaps [rsp+0x10], xmm1
000070bab59d460a  vmovaps [rsp+0x20], xmm2
000070bab59d4610  vmovaps [rsp+0x30], xmm3
000070bab59d4616  vmovaps [rsp+0x40], xmm4
000070bab59d461c  vmovaps [rsp+0x50], xmm5
000070bab59d4622  vmovaps [rsp+0x60], xmm6
000070bab59d4628  vmovaps [rsp+0x70], xmm7
000070bab59d462e  vmovaps [rsp+0x80], xmm8
000070bab59d4637  vmovaps [rsp+0x90], xmm9
000070bab59d4640  vmovaps [rsp+0xA0], xmm10
000070bab59d4649  vmovaps [rsp+0xB0], xmm11
000070bab59d4652  vmovaps [rsp+0xC0], xmm12
000070bab59d465b  vmovaps [rsp+0xD0], xmm13
000070bab59d4664  vmovaps [rsp+0xE0], xmm14
000070bab59d466d  sub rsp, 0x30
000070bab59d4671  movaps [rsp], xmm15
000070bab59d4676  movaps [rsp+0x10], xmm10
000070bab59d467c  movaps [rsp+0x20], xmm13
000070bab59d4682  lea rdi, [rsp]
000070bab59d4686  mov esi, 0x00
000070bab59d468b  mov rax, 0x63B35AFBC530
000070bab59d4695  call rax
000070bab59d4697  movaps xmm15, [rsp]
000070bab59d469c  add rsp, 0x30
000070bab59d46a0  vmovaps xmm0, [rsp]
000070bab59d46a5  vmovaps xmm1, [rsp+0x10]
000070bab59d46ab  vmovaps xmm2, [rsp+0x20]
000070bab59d46b1  vmovaps xmm3, [rsp+0x30]
000070bab59d46b7  vmovaps xmm4, [rsp+0x40]
000070bab59d46bd  vmovaps xmm5, [rsp+0x50]
000070bab59d46c3  vmovaps xmm6, [rsp+0x60]
000070bab59d46c9  vmovaps xmm7, [rsp+0x70]
000070bab59d46cf  vmovaps xmm8, [rsp+0x80]
000070bab59d46d8  vmovaps xmm9, [rsp+0x90]
000070bab59d46e1  vmovaps xmm10, [rsp+0xA0]
000070bab59d46ea  vmovaps xmm11, [rsp+0xB0]
000070bab59d46f3  vmovaps xmm12, [rsp+0xC0]
000070bab59d46fc  vmovaps xmm13, [rsp+0xD0]
000070bab59d4705  vmovaps xmm14, [rsp+0xE0]
000070bab59d470e  add rsp, 0xF0
000070bab59d4715  pop r11
000070bab59d4717  pop r10
000070bab59d4719  pop r9
000070bab59d471b  pop r8
000070bab59d471d  pop rsi
000070bab59d471e  pop rdi
000070bab59d471f  pop rdx
000070bab59d4720  pop rcx
000070bab59d4721  pop rax
000070bab59d4722  add rsp, 0x08
000070bab59d4726  jmp 0x000070BAB59D013D
000070bab59d472b  sub rsp, 0x08
000070bab59d472f  push rax
000070bab59d4730  push rcx
000070bab59d4731  push rdx
000070bab59d4732  push rdi
000070bab59d4733  push rsi
000070bab59d4734  push r8
000070bab59d4736  push r9
000070bab59d4738  push r10
000070bab59d473a  push r11
000070bab59d473c  sub rsp, 0xF0
000070bab59d4743  vmovaps [rsp], xmm0
000070bab59d4748  vmovaps [rsp+0x10], xmm1
000070bab59d474e  vmovaps [rsp+0x20], xmm2
000070bab59d4754  vmovaps [rsp+0x30], xmm3
000070bab59d475a  vmovaps [rsp+0x40], xmm4
000070bab59d4760  vmovaps [rsp+0x50], xmm5
000070bab59d4766  vmovaps [rsp+0x60], xmm6
000070bab59d476c  vmovaps [rsp+0x70], xmm7
000070bab59d4772  vmovaps [rsp+0x80], xmm8
000070bab59d477b  vmovaps [rsp+0x90], xmm9
000070bab59d4784  vmovaps [rsp+0xA0], xmm11
000070bab59d478d  vmovaps [rsp+0xB0], xmm12
000070bab59d4796  vmovaps [rsp+0xC0], xmm13
000070bab59d479f  vmovaps [rsp+0xD0], xmm14
000070bab59d47a8  vmovaps [rsp+0xE0], xmm15
000070bab59d47b1  sub rsp, 0x30
000070bab59d47b5  movaps [rsp], xmm10
000070bab59d47ba  movaps [rsp+0x10], xmm7
000070bab59d47bf  movaps [rsp+0x20], xmm13
000070bab59d47c5  lea rdi, [rsp]
000070bab59d47c9  mov esi, 0x00
000070bab59d47ce  mov rax, 0x63B35AFBC530
000070bab59d47d8  call rax
000070bab59d47da  movaps xmm10, [rsp]
000070bab59d47df  add rsp, 0x30
000070bab59d47e3  vmovaps xmm0, [rsp]
000070bab59d47e8  vmovaps xmm1, [rsp+0x10]
000070bab59d47ee  vmovaps xmm2, [rsp+0x20]
000070bab59d47f4  vmovaps xmm3, [rsp+0x30]
000070bab59d47fa  vmovaps xmm4, [rsp+0x40]
000070bab59d4800  vmovaps xmm5, [rsp+0x50]
000070bab59d4806  vmovaps xmm6, [rsp+0x60]
000070bab59d480c  vmovaps xmm7, [rsp+0x70]
000070bab59d4812  vmovaps xmm8, [rsp+0x80]
000070bab59d481b  vmovaps xmm9, [rsp+0x90]
000070bab59d4824  vmovaps xmm11, [rsp+0xA0]
000070bab59d482d  vmovaps xmm12, [rsp+0xB0]
000070bab59d4836  vmovaps xmm13, [rsp+0xC0]
000070bab59d483f  vmovaps xmm14, [rsp+0xD0]
000070bab59d4848  vmovaps xmm15, [rsp+0xE0]
000070bab59d4851  add rsp, 0xF0
000070bab59d4858  pop r11
000070bab59d485a  pop r10
000070bab59d485c  pop r9
000070bab59d485e  pop r8
000070bab59d4860  pop rsi
000070bab59d4861  pop rdi
000070bab59d4862  pop rdx
000070bab59d4863  pop rcx
000070bab59d4864  pop rax
000070bab59d4865  add rsp, 0x08
000070bab59d4869  jmp 0x000070BAB59D0169
000070bab59d486e  sub rsp, 0x08
000070bab59d4872  push rax
000070bab59d4873  push rcx
000070bab59d4874  push rdx
000070bab59d4875  push rdi
000070bab59d4876  push rsi
000070bab59d4877  push r8
000070bab59d4879  push r9
000070bab59d487b  push r10
000070bab59d487d  push r11
000070bab59d487f  sub rsp, 0xF0
000070bab59d4886  vmovaps [rsp], xmm0
000070bab59d488b  vmovaps [rsp+0x10], xmm1
000070bab59d4891  vmovaps [rsp+0x20], xmm2
000070bab59d4897  vmovaps [rsp+0x30], xmm3
000070bab59d489d  vmovaps [rsp+0x40], xmm4
000070bab59d48a3  vmovaps [rsp+0x50], xmm5
000070bab59d48a9  vmovaps [rsp+0x60], xmm6
000070bab59d48af  vmovaps [rsp+0x70], xmm7
000070bab59d48b5  vmovaps [rsp+0x80], xmm8
000070bab59d48be  vmovaps [rsp+0x90], xmm9
000070bab59d48c7  vmovaps [rsp+0xA0], xmm10
000070bab59d48d0  vmovaps [rsp+0xB0], xmm11
000070bab59d48d9  vmovaps [rsp+0xC0], xmm12
000070bab59d48e2  vmovaps [rsp+0xD0], xmm14
000070bab59d48eb  vmovaps [rsp+0xE0], xmm15
000070bab59d48f4  sub rsp, 0x30
000070bab59d48f8  movaps [rsp], xmm13
000070bab59d48fd  movaps [rsp+0x10], xmm1
000070bab59d4902  movaps [rsp+0x20], xmm8
000070bab59d4908  lea rdi, [rsp]
000070bab59d490c  mov esi, 0x00
000070bab59d4911  mov rax, 0x63B35AFBC530
000070bab59d491b  call rax
000070bab59d491d  movaps xmm13, [rsp]
000070bab59d4922  add rsp, 0x30
000070bab59d4926  vmovaps xmm0, [rsp]
000070bab59d492b  vmovaps xmm1, [rsp+0x10]
000070bab59d4931  vmovaps xmm2, [rsp+0x20]
000070bab59d4937  vmovaps xmm3, [rsp+0x30]
000070bab59d493d  vmovaps xmm4, [rsp+0x40]
000070bab59d4943  vmovaps xmm5, [rsp+0x50]
000070bab59d4949  vmovaps xmm6, [rsp+0x60]
000070bab59d494f  vmovaps xmm7, [rsp+0x70]
000070bab59d4955  vmovaps xmm8, [rsp+0x80]
000070bab59d495e  vmovaps xmm9, [rsp+0x90]
000070bab59d4967  vmovaps xmm10, [rsp+0xA0]
000070bab59d4970  vmovaps xmm11, [rsp+0xB0]
000070bab59d4979  vmovaps xmm12, [rsp+0xC0]
000070bab59d4982  vmovaps xmm14, [rsp+0xD0]
000070bab59d498b  vmovaps xmm15, [rsp+0xE0]
000070bab59d4994  add rsp, 0xF0
000070bab59d499b  pop r11
000070bab59d499d  pop r10
000070bab59d499f  pop r9
000070bab59d49a1  pop r8
000070bab59d49a3  pop rsi
000070bab59d49a4  pop rdi
000070bab59d49a5  pop rdx
000070bab59d49a6  pop rcx
000070bab59d49a7  pop rax
000070bab59d49a8  add rsp, 0x08
000070bab59d49ac  jmp 0x000070BAB59D0183
000070bab59d49b1  call 0x000070BAB57FF430
000070bab59d49b6  jmp 0x000070BAB59D018D
000070bab59d49bb  sub rsp, 0x08
000070bab59d49bf  push rax
000070bab59d49c0  push rcx
000070bab59d49c1  push rdx
000070bab59d49c2  push rdi
000070bab59d49c3  push rsi
000070bab59d49c4  push r8
000070bab59d49c6  push r9
000070bab59d49c8  push r10
000070bab59d49ca  push r11
000070bab59d49cc  sub rsp, 0xF0
000070bab59d49d3  vmovaps [rsp], xmm0
000070bab59d49d8  vmovaps [rsp+0x10], xmm1
000070bab59d49de  vmovaps [rsp+0x20], xmm2
000070bab59d49e4  vmovaps [rsp+0x30], xmm3
000070bab59d49ea  vmovaps [rsp+0x40], xmm4
000070bab59d49f0  vmovaps [rsp+0x50], xmm5
000070bab59d49f6  vmovaps [rsp+0x60], xmm6
000070bab59d49fc  vmovaps [rsp+0x70], xmm7
000070bab59d4a02  vmovaps [rsp+0x80], xmm9
000070bab59d4a0b  vmovaps [rsp+0x90], xmm10
000070bab59d4a14  vmovaps [rsp+0xA0], xmm11
000070bab59d4a1d  vmovaps [rsp+0xB0], xmm12
000070bab59d4a26  vmovaps [rsp+0xC0], xmm13
000070bab59d4a2f  vmovaps [rsp+0xD0], xmm14
000070bab59d4a38  vmovaps [rsp+0xE0], xmm15
000070bab59d4a41  sub rsp, 0x30
000070bab59d4a45  movaps [rsp], xmm8
000070bab59d4a4a  movaps [rsp+0x10], xmm14
000070bab59d4a50  movaps [rsp+0x20], xmm9
000070bab59d4a56  lea rdi, [rsp]
000070bab59d4a5a  mov esi, 0x00
000070bab59d4a5f  mov rax, 0x63B35AFBC530
000070bab59d4a69  call rax
000070bab59d4a6b  movaps xmm8, [rsp]
000070bab59d4a70  add rsp, 0x30
000070bab59d4a74  vmovaps xmm0, [rsp]
000070bab59d4a79  vmovaps xmm1, [rsp+0x10]
000070bab59d4a7f  vmovaps xmm2, [rsp+0x20]
000070bab59d4a85  vmovaps xmm3, [rsp+0x30]
000070bab59d4a8b  vmovaps xmm4, [rsp+0x40]
000070bab59d4a91  vmovaps xmm5, [rsp+0x50]
000070bab59d4a97  vmovaps xmm6, [rsp+0x60]
000070bab59d4a9d  vmovaps xmm7, [rsp+0x70]
000070bab59d4aa3  vmovaps xmm9, [rsp+0x80]
000070bab59d4aac  vmovaps xmm10, [rsp+0x90]
000070bab59d4ab5  vmovaps xmm11, [rsp+0xA0]
000070bab59d4abe  vmovaps xmm12, [rsp+0xB0]
000070bab59d4ac7  vmovaps xmm13, [rsp+0xC0]
000070bab59d4ad0  vmovaps xmm14, [rsp+0xD0]
000070bab59d4ad9  vmovaps xmm15, [rsp+0xE0]
000070bab59d4ae2  add rsp, 0xF0
000070bab59d4ae9  pop r11
000070bab59d4aeb  pop r10
000070bab59d4aed  pop r9
000070bab59d4aef  pop r8
000070bab59d4af1  pop rsi
000070bab59d4af2  pop rdi
000070bab59d4af3  pop rdx
000070bab59d4af4  pop rcx
000070bab59d4af5  pop rax
000070bab59d4af6  add rsp, 0x08
000070bab59d4afa  jmp 0x000070BAB59D01AF
000070bab59d4aff  sub rsp, 0x08
000070bab59d4b03  push rax
000070bab59d4b04  push rcx
000070bab59d4b05  push rdx
000070bab59d4b06  push rdi
000070bab59d4b07  push rsi
000070bab59d4b08  push r8
000070bab59d4b0a  push r9
000070bab59d4b0c  push r10
000070bab59d4b0e  push r11
000070bab59d4b10  sub rsp, 0xF0
000070bab59d4b17  vmovaps [rsp], xmm0
000070bab59d4b1c  vmovaps [rsp+0x10], xmm1
000070bab59d4b22  vmovaps [rsp+0x20], xmm2
000070bab59d4b28  vmovaps [rsp+0x30], xmm3
000070bab59d4b2e  vmovaps [rsp+0x40], xmm4
000070bab59d4b34  vmovaps [rsp+0x50], xmm5
000070bab59d4b3a  vmovaps [rsp+0x60], xmm6
000070bab59d4b40  vmovaps [rsp+0x70], xmm7
000070bab59d4b46  vmovaps [rsp+0x80], xmm8
000070bab59d4b4f  vmovaps [rsp+0x90], xmm10
000070bab59d4b58  vmovaps [rsp+0xA0], xmm11
000070bab59d4b61  vmovaps [rsp+0xB0], xmm12
000070bab59d4b6a  vmovaps [rsp+0xC0], xmm13
000070bab59d4b73  vmovaps [rsp+0xD0], xmm14
000070bab59d4b7c  vmovaps [rsp+0xE0], xmm15
000070bab59d4b85  sub rsp, 0x30
000070bab59d4b89  movaps [rsp], xmm9
000070bab59d4b8e  movaps [rsp+0x10], xmm1
000070bab59d4b93  movaps [rsp+0x20], xmm14
000070bab59d4b99  lea rdi, [rsp]
000070bab59d4b9d  mov esi, 0x00
000070bab59d4ba2  mov rax, 0x63B35AFBC530
000070bab59d4bac  call rax
000070bab59d4bae  movaps xmm9, [rsp]
000070bab59d4bb3  add rsp, 0x30
000070bab59d4bb7  vmovaps xmm0, [rsp]
000070bab59d4bbc  vmovaps xmm1, [rsp+0x10]
000070bab59d4bc2  vmovaps xmm2, [rsp+0x20]
000070bab59d4bc8  vmovaps xmm3, [rsp+0x30]
000070bab59d4bce  vmovaps xmm4, [rsp+0x40]
000070bab59d4bd4  vmovaps xmm5, [rsp+0x50]
000070bab59d4bda  vmovaps xmm6, [rsp+0x60]
000070bab59d4be0  vmovaps xmm7, [rsp+0x70]
000070bab59d4be6  vmovaps xmm8, [rsp+0x80]
000070bab59d4bef  vmovaps xmm10, [rsp+0x90]
000070bab59d4bf8  vmovaps xmm11, [rsp+0xA0]
000070bab59d4c01  vmovaps xmm12, [rsp+0xB0]
000070bab59d4c0a  vmovaps xmm13, [rsp+0xC0]
000070bab59d4c13  vmovaps xmm14, [rsp+0xD0]
000070bab59d4c1c  vmovaps xmm15, [rsp+0xE0]
000070bab59d4c25  add rsp, 0xF0
000070bab59d4c2c  pop r11
000070bab59d4c2e  pop r10
000070bab59d4c30  pop r9
000070bab59d4c32  pop r8
000070bab59d4c34  pop rsi
000070bab59d4c35  pop rdi
000070bab59d4c36  pop rdx
000070bab59d4c37  pop rcx
000070bab59d4c38  pop rax
000070bab59d4c39  add rsp, 0x08
000070bab59d4c3d  jmp 0x000070BAB59D01DD
000070bab59d4c42  sub rsp, 0x08
000070bab59d4c46  push rax
000070bab59d4c47  push rcx
000070bab59d4c48  push rdx
000070bab59d4c49  push rdi
000070bab59d4c4a  push rsi
000070bab59d4c4b  push r8
000070bab59d4c4d  push r9
000070bab59d4c4f  push r10
000070bab59d4c51  push r11
000070bab59d4c53  sub rsp, 0xF0
000070bab59d4c5a  vmovaps [rsp], xmm0
000070bab59d4c5f  vmovaps [rsp+0x10], xmm1
000070bab59d4c65  vmovaps [rsp+0x20], xmm2
000070bab59d4c6b  vmovaps [rsp+0x30], xmm3
000070bab59d4c71  vmovaps [rsp+0x40], xmm4
000070bab59d4c77  vmovaps [rsp+0x50], xmm5
000070bab59d4c7d  vmovaps [rsp+0x60], xmm6
000070bab59d4c83  vmovaps [rsp+0x70], xmm7
000070bab59d4c89  vmovaps [rsp+0x80], xmm8
000070bab59d4c92  vmovaps [rsp+0x90], xmm9
000070bab59d4c9b  vmovaps [rsp+0xA0], xmm10
000070bab59d4ca4  vmovaps [rsp+0xB0], xmm11
000070bab59d4cad  vmovaps [rsp+0xC0], xmm12
000070bab59d4cb6  vmovaps [rsp+0xD0], xmm13
000070bab59d4cbf  vmovaps [rsp+0xE0], xmm15
000070bab59d4cc8  sub rsp, 0x30
000070bab59d4ccc  movaps [rsp], xmm14
000070bab59d4cd1  movaps [rsp+0x10], xmm4
000070bab59d4cd6  movaps [rsp+0x20], xmm1
000070bab59d4cdb  lea rdi, [rsp]
000070bab59d4cdf  mov esi, 0x00
000070bab59d4ce4  mov rax, 0x63B35AFBC530
000070bab59d4cee  call rax
000070bab59d4cf0  movaps xmm14, [rsp]
000070bab59d4cf5  add rsp, 0x30
000070bab59d4cf9  vmovaps xmm0, [rsp]
000070bab59d4cfe  vmovaps xmm1, [rsp+0x10]
000070bab59d4d04  vmovaps xmm2, [rsp+0x20]
000070bab59d4d0a  vmovaps xmm3, [rsp+0x30]
000070bab59d4d10  vmovaps xmm4, [rsp+0x40]
000070bab59d4d16  vmovaps xmm5, [rsp+0x50]
000070bab59d4d1c  vmovaps xmm6, [rsp+0x60]
000070bab59d4d22  vmovaps xmm7, [rsp+0x70]
000070bab59d4d28  vmovaps xmm8, [rsp+0x80]
000070bab59d4d31  vmovaps xmm9, [rsp+0x90]
000070bab59d4d3a  vmovaps xmm10, [rsp+0xA0]
000070bab59d4d43  vmovaps xmm11, [rsp+0xB0]
000070bab59d4d4c  vmovaps xmm12, [rsp+0xC0]
000070bab59d4d55  vmovaps xmm13, [rsp+0xD0]
000070bab59d4d5e  vmovaps xmm15, [rsp+0xE0]
000070bab59d4d67  add rsp, 0xF0
000070bab59d4d6e  pop r11
000070bab59d4d70  pop r10
000070bab59d4d72  pop r9
000070bab59d4d74  pop r8
000070bab59d4d76  pop rsi
000070bab59d4d77  pop rdi
000070bab59d4d78  pop rdx
000070bab59d4d79  pop rcx
000070bab59d4d7a  pop rax
000070bab59d4d7b  add rsp, 0x08
000070bab59d4d7f  jmp 0x000070BAB59D0203
000070bab59d4d84  sub rsp, 0x08
000070bab59d4d88  push rax
000070bab59d4d89  push rcx
000070bab59d4d8a  push rdx
000070bab59d4d8b  push rdi
000070bab59d4d8c  push rsi
000070bab59d4d8d  push r8
000070bab59d4d8f  push r9
000070bab59d4d91  push r10
000070bab59d4d93  push r11
000070bab59d4d95  sub rsp, 0xF0
000070bab59d4d9c  vmovaps [rsp], xmm0
000070bab59d4da1  vmovaps [rsp+0x10], xmm2
000070bab59d4da7  vmovaps [rsp+0x20], xmm3
000070bab59d4dad  vmovaps [rsp+0x30], xmm4
000070bab59d4db3  vmovaps [rsp+0x40], xmm5
000070bab59d4db9  vmovaps [rsp+0x50], xmm6
000070bab59d4dbf  vmovaps [rsp+0x60], xmm7
000070bab59d4dc5  vmovaps [rsp+0x70], xmm8
000070bab59d4dcb  vmovaps [rsp+0x80], xmm9
000070bab59d4dd4  vmovaps [rsp+0x90], xmm10
000070bab59d4ddd  vmovaps [rsp+0xA0], xmm11
000070bab59d4de6  vmovaps [rsp+0xB0], xmm12
000070bab59d4def  vmovaps [rsp+0xC0], xmm13
000070bab59d4df8  vmovaps [rsp+0xD0], xmm14
000070bab59d4e01  vmovaps [rsp+0xE0], xmm15
000070bab59d4e0a  sub rsp, 0x30
000070bab59d4e0e  movaps [rsp], xmm1
000070bab59d4e12  movaps [rsp+0x10], xmm12
000070bab59d4e18  movaps [rsp+0x20], xmm11
000070bab59d4e1e  lea rdi, [rsp]
000070bab59d4e22  mov esi, 0x00
000070bab59d4e27  mov rax, 0x63B35AFBC530
000070bab59d4e31  call rax
000070bab59d4e33  movaps xmm1, [rsp]
000070bab59d4e37  add rsp, 0x30
000070bab59d4e3b  vmovaps xmm0, [rsp]
000070bab59d4e40  vmovaps xmm2, [rsp+0x10]
000070bab59d4e46  vmovaps xmm3, [rsp+0x20]
000070bab59d4e4c  vmovaps xmm4, [rsp+0x30]
000070bab59d4e52  vmovaps xmm5, [rsp+0x40]
000070bab59d4e58  vmovaps xmm6, [rsp+0x50]
000070bab59d4e5e  vmovaps xmm7, [rsp+0x60]
000070bab59d4e64  vmovaps xmm8, [rsp+0x70]
000070bab59d4e6a  vmovaps xmm9, [rsp+0x80]
000070bab59d4e73  vmovaps xmm10, [rsp+0x90]
000070bab59d4e7c  vmovaps xmm11, [rsp+0xA0]
000070bab59d4e85  vmovaps xmm12, [rsp+0xB0]
000070bab59d4e8e  vmovaps xmm13, [rsp+0xC0]
000070bab59d4e97  vmovaps xmm14, [rsp+0xD0]
000070bab59d4ea0  vmovaps xmm15, [rsp+0xE0]
000070bab59d4ea9  add rsp, 0xF0
000070bab59d4eb0  pop r11
000070bab59d4eb2  pop r10
000070bab59d4eb4  pop r9
000070bab59d4eb6  pop r8
000070bab59d4eb8  pop rsi
000070bab59d4eb9  pop rdi
000070bab59d4eba  pop rdx
000070bab59d4ebb  pop rcx
000070bab59d4ebc  pop rax
000070bab59d4ebd  add rsp, 0x08
000070bab59d4ec1  jmp 0x000070BAB59D0224
000070bab59d4ec6  call 0x000070BAB58E20A0
000070bab59d4ecb  jmp 0x000070BAB59D0232
000070bab59d4ed0  call 0x000070BAB5809D70
000070bab59d4ed5  jmp 0x000070BAB59D023C
000070bab59d4eda  sub rsp, 0x08
000070bab59d4ede  push rax
000070bab59d4edf  push rcx
000070bab59d4ee0  push rdx
000070bab59d4ee1  push rdi
000070bab59d4ee2  push rsi
000070bab59d4ee3  push r8
000070bab59d4ee5  push r9
000070bab59d4ee7  push r10
000070bab59d4ee9  push r11
000070bab59d4eeb  sub rsp, 0xF0
000070bab59d4ef2  vmovaps [rsp], xmm0
000070bab59d4ef7  vmovaps [rsp+0x10], xmm1
000070bab59d4efd  vmovaps [rsp+0x20], xmm2
000070bab59d4f03  vmovaps [rsp+0x30], xmm3
000070bab59d4f09  vmovaps [rsp+0x40], xmm4
000070bab59d4f0f  vmovaps [rsp+0x50], xmm5
000070bab59d4f15  vmovaps [rsp+0x60], xmm6
000070bab59d4f1b  vmovaps [rsp+0x70], xmm8
000070bab59d4f21  vmovaps [rsp+0x80], xmm9
000070bab59d4f2a  vmovaps [rsp+0x90], xmm10
000070bab59d4f33  vmovaps [rsp+0xA0], xmm11
000070bab59d4f3c  vmovaps [rsp+0xB0], xmm12
000070bab59d4f45  vmovaps [rsp+0xC0], xmm13
000070bab59d4f4e  vmovaps [rsp+0xD0], xmm14
000070bab59d4f57  vmovaps [rsp+0xE0], xmm15
000070bab59d4f60  sub rsp, 0x30
000070bab59d4f64  movaps [rsp], xmm7
000070bab59d4f68  movaps [rsp+0x10], xmm15
000070bab59d4f6e  movaps [rsp+0x20], xmm10
000070bab59d4f74  lea rdi, [rsp]
000070bab59d4f78  mov esi, 0x00
000070bab59d4f7d  mov rax, 0x63B35AFBC530
000070bab59d4f87  call rax
000070bab59d4f89  movaps xmm7, [rsp]
000070bab59d4f8d  add rsp, 0x30
000070bab59d4f91  vmovaps xmm0, [rsp]
000070bab59d4f96  vmovaps xmm1, [rsp+0x10]
000070bab59d4f9c  vmovaps xmm2, [rsp+0x20]
000070bab59d4fa2  vmovaps xmm3, [rsp+0x30]
000070bab59d4fa8  vmovaps xmm4, [rsp+0x40]
000070bab59d4fae  vmovaps xmm5, [rsp+0x50]
000070bab59d4fb4  vmovaps xmm6, [rsp+0x60]
000070bab59d4fba  vmovaps xmm8, [rsp+0x70]
000070bab59d4fc0  vmovaps xmm9, [rsp+0x80]
000070bab59d4fc9  vmovaps xmm10, [rsp+0x90]
000070bab59d4fd2  vmovaps xmm11, [rsp+0xA0]
000070bab59d4fdb  vmovaps xmm12, [rsp+0xB0]
000070bab59d4fe4  vmovaps xmm13, [rsp+0xC0]
000070bab59d4fed  vmovaps xmm14, [rsp+0xD0]
000070bab59d4ff6  vmovaps xmm15, [rsp+0xE0]
000070bab59d4fff  add rsp, 0xF0
000070bab59d5006  pop r11
000070bab59d5008  pop r10
000070bab59d500a  pop r9
000070bab59d500c  pop r8
000070bab59d500e  pop rsi
000070bab59d500f  pop rdi
000070bab59d5010  pop rdx
000070bab59d5011  pop rcx
000070bab59d5012  pop rax
000070bab59d5013  add rsp, 0x08
000070bab59d5017  jmp 0x000070BAB59D025D
000070bab59d501c  sub rsp, 0x08
000070bab59d5020  push rax
000070bab59d5021  push rcx
000070bab59d5022  push rdx
000070bab59d5023  push rdi
000070bab59d5024  push rsi
000070bab59d5025  push r8
000070bab59d5027  push r9
000070bab59d5029  push r10
000070bab59d502b  push r11
000070bab59d502d  sub rsp, 0xF0
000070bab59d5034  vmovaps [rsp], xmm0
000070bab59d5039  vmovaps [rsp+0x10], xmm1
000070bab59d503f  vmovaps [rsp+0x20], xmm2
000070bab59d5045  vmovaps [rsp+0x30], xmm3
000070bab59d504b  vmovaps [rsp+0x40], xmm4
000070bab59d5051  vmovaps [rsp+0x50], xmm5
000070bab59d5057  vmovaps [rsp+0x60], xmm6
000070bab59d505d  vmovaps [rsp+0x70], xmm7
000070bab59d5063  vmovaps [rsp+0x80], xmm8
000070bab59d506c  vmovaps [rsp+0x90], xmm9
000070bab59d5075  vmovaps [rsp+0xA0], xmm11
000070bab59d507e  vmovaps [rsp+0xB0], xmm12
000070bab59d5087  vmovaps [rsp+0xC0], xmm13
000070bab59d5090  vmovaps [rsp+0xD0], xmm14
000070bab59d5099  vmovaps [rsp+0xE0], xmm15
000070bab59d50a2  sub rsp, 0x30
000070bab59d50a6  movaps [rsp], xmm10
000070bab59d50ab  movaps [rsp+0x10], xmm11
000070bab59d50b1  movaps [rsp+0x20], xmm15
000070bab59d50b7  lea rdi, [rsp]
000070bab59d50bb  mov esi, 0x00
000070bab59d50c0  mov rax, 0x63B35AFBC530
000070bab59d50ca  call rax
000070bab59d50cc  movaps xmm10, [rsp]
000070bab59d50d1  add rsp, 0x30
000070bab59d50d5  vmovaps xmm0, [rsp]
000070bab59d50da  vmovaps xmm1, [rsp+0x10]
000070bab59d50e0  vmovaps xmm2, [rsp+0x20]
000070bab59d50e6  vmovaps xmm3, [rsp+0x30]
000070bab59d50ec  vmovaps xmm4, [rsp+0x40]
000070bab59d50f2  vmovaps xmm5, [rsp+0x50]
000070bab59d50f8  vmovaps xmm6, [rsp+0x60]
000070bab59d50fe  vmovaps xmm7, [rsp+0x70]
000070bab59d5104  vmovaps xmm8, [rsp+0x80]
000070bab59d510d  vmovaps xmm9, [rsp+0x90]
000070bab59d5116  vmovaps xmm11, [rsp+0xA0]
000070bab59d511f  vmovaps xmm12, [rsp+0xB0]
000070bab59d5128  vmovaps xmm13, [rsp+0xC0]
000070bab59d5131  vmovaps xmm14, [rsp+0xD0]
000070bab59d513a  vmovaps xmm15, [rsp+0xE0]
000070bab59d5143  add rsp, 0xF0
000070bab59d514a  pop r11
000070bab59d514c  pop r10
000070bab59d514e  pop r9
000070bab59d5150  pop r8
000070bab59d5152  pop rsi
000070bab59d5153  pop rdi
000070bab59d5154  pop rdx
000070bab59d5155  pop rcx
000070bab59d5156  pop rax
000070bab59d5157  add rsp, 0x08
000070bab59d515b  jmp 0x000070BAB59D028B
000070bab59d5160  sub rsp, 0x08
000070bab59d5164  push rax
000070bab59d5165  push rcx
000070bab59d5166  push rdx
000070bab59d5167  push rdi
000070bab59d5168  push rsi
000070bab59d5169  push r8
000070bab59d516b  push r9
000070bab59d516d  push r10
000070bab59d516f  push r11
000070bab59d5171  sub rsp, 0xF0
000070bab59d5178  vmovaps [rsp], xmm0
000070bab59d517d  vmovaps [rsp+0x10], xmm1
000070bab59d5183  vmovaps [rsp+0x20], xmm2
000070bab59d5189  vmovaps [rsp+0x30], xmm3
000070bab59d518f  vmovaps [rsp+0x40], xmm4
000070bab59d5195  vmovaps [rsp+0x50], xmm5
000070bab59d519b  vmovaps [rsp+0x60], xmm6
000070bab59d51a1  vmovaps [rsp+0x70], xmm7
000070bab59d51a7  vmovaps [rsp+0x80], xmm8
000070bab59d51b0  vmovaps [rsp+0x90], xmm9
000070bab59d51b9  vmovaps [rsp+0xA0], xmm10
000070bab59d51c2  vmovaps [rsp+0xB0], xmm12
000070bab59d51cb  vmovaps [rsp+0xC0], xmm13
000070bab59d51d4  vmovaps [rsp+0xD0], xmm14
000070bab59d51dd  vmovaps [rsp+0xE0], xmm15
000070bab59d51e6  sub rsp, 0x30
000070bab59d51ea  movaps [rsp], xmm11
000070bab59d51ef  movaps [rsp+0x10], xmm12
000070bab59d51f5  movaps [rsp+0x20], xmm15
000070bab59d51fb  lea rdi, [rsp]
000070bab59d51ff  mov esi, 0x00
000070bab59d5204  mov rax, 0x63B35AFBC530
000070bab59d520e  call rax
000070bab59d5210  movaps xmm11, [rsp]
000070bab59d5215  add rsp, 0x30
000070bab59d5219  vmovaps xmm0, [rsp]
000070bab59d521e  vmovaps xmm1, [rsp+0x10]
000070bab59d5224  vmovaps xmm2, [rsp+0x20]
000070bab59d522a  vmovaps xmm3, [rsp+0x30]
000070bab59d5230  vmovaps xmm4, [rsp+0x40]
000070bab59d5236  vmovaps xmm5, [rsp+0x50]
000070bab59d523c  vmovaps xmm6, [rsp+0x60]
000070bab59d5242  vmovaps xmm7, [rsp+0x70]
000070bab59d5248  vmovaps xmm8, [rsp+0x80]
000070bab59d5251  vmovaps xmm9, [rsp+0x90]
000070bab59d525a  vmovaps xmm10, [rsp+0xA0]
000070bab59d5263  vmovaps xmm12, [rsp+0xB0]
000070bab59d526c  vmovaps xmm13, [rsp+0xC0]
000070bab59d5275  vmovaps xmm14, [rsp+0xD0]
000070bab59d527e  vmovaps xmm15, [rsp+0xE0]
000070bab59d5287  add rsp, 0xF0
000070bab59d528e  pop r11
000070bab59d5290  pop r10
000070bab59d5292  pop r9
000070bab59d5294  pop r8
000070bab59d5296  pop rsi
000070bab59d5297  pop rdi
000070bab59d5298  pop rdx
000070bab59d5299  pop rcx
000070bab59d529a  pop rax
000070bab59d529b  add rsp, 0x08
000070bab59d529f  jmp 0x000070BAB59D02B9
000070bab59d52a4  sub rsp, 0x08
000070bab59d52a8  push rax
000070bab59d52a9  push rcx
000070bab59d52aa  push rdx
000070bab59d52ab  push rdi
000070bab59d52ac  push rsi
000070bab59d52ad  push r8
000070bab59d52af  push r9
000070bab59d52b1  push r10
000070bab59d52b3  push r11
000070bab59d52b5  sub rsp, 0xF0
000070bab59d52bc  vmovaps [rsp], xmm0
000070bab59d52c1  vmovaps [rsp+0x10], xmm1
000070bab59d52c7  vmovaps [rsp+0x20], xmm2
000070bab59d52cd  vmovaps [rsp+0x30], xmm3
000070bab59d52d3  vmovaps [rsp+0x40], xmm4
000070bab59d52d9  vmovaps [rsp+0x50], xmm5
000070bab59d52df  vmovaps [rsp+0x60], xmm6
000070bab59d52e5  vmovaps [rsp+0x70], xmm7
000070bab59d52eb  vmovaps [rsp+0x80], xmm8
000070bab59d52f4  vmovaps [rsp+0x90], xmm9
000070bab59d52fd  vmovaps [rsp+0xA0], xmm10
000070bab59d5306  vmovaps [rsp+0xB0], xmm11
000070bab59d530f  vmovaps [rsp+0xC0], xmm12
000070bab59d5318  vmovaps [rsp+0xD0], xmm13
000070bab59d5321  vmovaps [rsp+0xE0], xmm14
000070bab59d532a  sub rsp, 0x30
000070bab59d532e  movaps [rsp], xmm15
000070bab59d5333  movaps [rsp+0x10], xmm13
000070bab59d5339  movaps [rsp+0x20], xmm9
000070bab59d533f  lea rdi, [rsp]
000070bab59d5343  mov esi, 0x00
000070bab59d5348  mov rax, 0x63B35AFBC530
000070bab59d5352  call rax
000070bab59d5354  movaps xmm15, [rsp]
000070bab59d5359  add rsp, 0x30
000070bab59d535d  vmovaps xmm0, [rsp]
000070bab59d5362  vmovaps xmm1, [rsp+0x10]
000070bab59d5368  vmovaps xmm2, [rsp+0x20]
000070bab59d536e  vmovaps xmm3, [rsp+0x30]
000070bab59d5374  vmovaps xmm4, [rsp+0x40]
000070bab59d537a  vmovaps xmm5, [rsp+0x50]
000070bab59d5380  vmovaps xmm6, [rsp+0x60]
000070bab59d5386  vmovaps xmm7, [rsp+0x70]
000070bab59d538c  vmovaps xmm8, [rsp+0x80]
000070bab59d5395  vmovaps xmm9, [rsp+0x90]
000070bab59d539e  vmovaps xmm10, [rsp+0xA0]
000070bab59d53a7  vmovaps xmm11, [rsp+0xB0]
000070bab59d53b0  vmovaps xmm12, [rsp+0xC0]
000070bab59d53b9  vmovaps xmm13, [rsp+0xD0]
000070bab59d53c2  vmovaps xmm14, [rsp+0xE0]
000070bab59d53cb  add rsp, 0xF0
000070bab59d53d2  pop r11
000070bab59d53d4  pop r10
000070bab59d53d6  pop r9
000070bab59d53d8  pop r8
000070bab59d53da  pop rsi
000070bab59d53db  pop rdi
000070bab59d53dc  pop rdx
000070bab59d53dd  pop rcx
000070bab59d53de  pop rax
000070bab59d53df  add rsp, 0x08
000070bab59d53e3  jmp 0x000070BAB59D02D4
000070bab59d53e8  sub rsp, 0x08
000070bab59d53ec  push rax
000070bab59d53ed  push rcx
000070bab59d53ee  push rdx
000070bab59d53ef  push rdi
000070bab59d53f0  push rsi
000070bab59d53f1  push r8
000070bab59d53f3  push r9
000070bab59d53f5  push r10
000070bab59d53f7  push r11
000070bab59d53f9  sub rsp, 0xF0
000070bab59d5400  vmovaps [rsp], xmm0
000070bab59d5405  vmovaps [rsp+0x10], xmm1
000070bab59d540b  vmovaps [rsp+0x20], xmm2
000070bab59d5411  vmovaps [rsp+0x30], xmm3
000070bab59d5417  vmovaps [rsp+0x40], xmm4
000070bab59d541d  vmovaps [rsp+0x50], xmm5
000070bab59d5423  vmovaps [rsp+0x60], xmm6
000070bab59d5429  vmovaps [rsp+0x70], xmm7
000070bab59d542f  vmovaps [rsp+0x80], xmm8
000070bab59d5438  vmovaps [rsp+0x90], xmm9
000070bab59d5441  vmovaps [rsp+0xA0], xmm10
000070bab59d544a  vmovaps [rsp+0xB0], xmm11
000070bab59d5453  vmovaps [rsp+0xC0], xmm12
000070bab59d545c  vmovaps [rsp+0xD0], xmm14
000070bab59d5465  vmovaps [rsp+0xE0], xmm15
000070bab59d546e  sub rsp, 0x30
000070bab59d5472  movaps [rsp], xmm13
000070bab59d5477  movaps [rsp+0x10], xmm8
000070bab59d547d  movaps [rsp+0x20], xmm14
000070bab59d5483  lea rdi, [rsp]
000070bab59d5487  mov esi, 0x00
000070bab59d548c  mov rax, 0x63B35AFBC530
000070bab59d5496  call rax
000070bab59d5498  movaps xmm13, [rsp]
000070bab59d549d  add rsp, 0x30
000070bab59d54a1  vmovaps xmm0, [rsp]
000070bab59d54a6  vmovaps xmm1, [rsp+0x10]
000070bab59d54ac  vmovaps xmm2, [rsp+0x20]
000070bab59d54b2  vmovaps xmm3, [rsp+0x30]
000070bab59d54b8  vmovaps xmm4, [rsp+0x40]
000070bab59d54be  vmovaps xmm5, [rsp+0x50]
000070bab59d54c4  vmovaps xmm6, [rsp+0x60]
000070bab59d54ca  vmovaps xmm7, [rsp+0x70]
000070bab59d54d0  vmovaps xmm8, [rsp+0x80]
000070bab59d54d9  vmovaps xmm9, [rsp+0x90]
000070bab59d54e2  vmovaps xmm10, [rsp+0xA0]
000070bab59d54eb  vmovaps xmm11, [rsp+0xB0]
000070bab59d54f4  vmovaps xmm12, [rsp+0xC0]
000070bab59d54fd  vmovaps xmm14, [rsp+0xD0]
000070bab59d5506  vmovaps xmm15, [rsp+0xE0]
000070bab59d550f  add rsp, 0xF0
000070bab59d5516  pop r11
000070bab59d5518  pop r10
000070bab59d551a  pop r9
000070bab59d551c  pop r8
000070bab59d551e  pop rsi
000070bab59d551f  pop rdi
000070bab59d5520  pop rdx
000070bab59d5521  pop rcx
000070bab59d5522  pop rax
000070bab59d5523  add rsp, 0x08
000070bab59d5527  jmp 0x000070BAB59D02F7
000070bab59d552c  sub rsp, 0x08
000070bab59d5530  push rax
000070bab59d5531  push rcx
000070bab59d5532  push rdx
000070bab59d5533  push rdi
000070bab59d5534  push rsi
000070bab59d5535  push r8
000070bab59d5537  push r9
000070bab59d5539  push r10
000070bab59d553b  push r11
000070bab59d553d  sub rsp, 0xF0
000070bab59d5544  vmovaps [rsp], xmm0
000070bab59d5549  vmovaps [rsp+0x10], xmm1
000070bab59d554f  vmovaps [rsp+0x20], xmm2
000070bab59d5555  vmovaps [rsp+0x30], xmm3
000070bab59d555b  vmovaps [rsp+0x40], xmm4
000070bab59d5561  vmovaps [rsp+0x50], xmm5
000070bab59d5567  vmovaps [rsp+0x60], xmm6
000070bab59d556d  vmovaps [rsp+0x70], xmm7
000070bab59d5573  vmovaps [rsp+0x80], xmm8
000070bab59d557c  vmovaps [rsp+0x90], xmm9
000070bab59d5585  vmovaps [rsp+0xA0], xmm10
000070bab59d558e  vmovaps [rsp+0xB0], xmm11
000070bab59d5597  vmovaps [rsp+0xC0], xmm12
000070bab59d55a0  vmovaps [rsp+0xD0], xmm13
000070bab59d55a9  vmovaps [rsp+0xE0], xmm15
000070bab59d55b2  sub rsp, 0x30
000070bab59d55b6  movaps [rsp], xmm14
000070bab59d55bb  movaps [rsp+0x10], xmm1
000070bab59d55c0  movaps [rsp+0x20], xmm10
000070bab59d55c6  lea rdi, [rsp]
000070bab59d55ca  mov esi, 0x00
000070bab59d55cf  mov rax, 0x63B35AFBC530
000070bab59d55d9  call rax
000070bab59d55db  movaps xmm14, [rsp]
000070bab59d55e0  add rsp, 0x30
000070bab59d55e4  vmovaps xmm0, [rsp]
000070bab59d55e9  vmovaps xmm1, [rsp+0x10]
000070bab59d55ef  vmovaps xmm2, [rsp+0x20]
000070bab59d55f5  vmovaps xmm3, [rsp+0x30]
000070bab59d55fb  vmovaps xmm4, [rsp+0x40]
000070bab59d5601  vmovaps xmm5, [rsp+0x50]
000070bab59d5607  vmovaps xmm6, [rsp+0x60]
000070bab59d560d  vmovaps xmm7, [rsp+0x70]
000070bab59d5613  vmovaps xmm8, [rsp+0x80]
000070bab59d561c  vmovaps xmm9, [rsp+0x90]
000070bab59d5625  vmovaps xmm10, [rsp+0xA0]
000070bab59d562e  vmovaps xmm11, [rsp+0xB0]
000070bab59d5637  vmovaps xmm12, [rsp+0xC0]
000070bab59d5640  vmovaps xmm13, [rsp+0xD0]
000070bab59d5649  vmovaps xmm15, [rsp+0xE0]
000070bab59d5652  add rsp, 0xF0
000070bab59d5659  pop r11
000070bab59d565b  pop r10
000070bab59d565d  pop r9
000070bab59d565f  pop r8
000070bab59d5661  pop rsi
000070bab59d5662  pop rdi
000070bab59d5663  pop rdx
000070bab59d5664  pop rcx
000070bab59d5665  pop rax
000070bab59d5666  add rsp, 0x08
000070bab59d566a  jmp 0x000070BAB59D031A
000070bab59d566f  sub rsp, 0x08
000070bab59d5673  push rax
000070bab59d5674  push rcx
000070bab59d5675  push rdx
000070bab59d5676  push rdi
000070bab59d5677  push rsi
000070bab59d5678  push r8
000070bab59d567a  push r9
000070bab59d567c  push r10
000070bab59d567e  push r11
000070bab59d5680  sub rsp, 0xF0
000070bab59d5687  vmovaps [rsp], xmm0
000070bab59d568c  vmovaps [rsp+0x10], xmm2
000070bab59d5692  vmovaps [rsp+0x20], xmm3
000070bab59d5698  vmovaps [rsp+0x30], xmm4
000070bab59d569e  vmovaps [rsp+0x40], xmm5
000070bab59d56a4  vmovaps [rsp+0x50], xmm6
000070bab59d56aa  vmovaps [rsp+0x60], xmm7
000070bab59d56b0  vmovaps [rsp+0x70], xmm8
000070bab59d56b6  vmovaps [rsp+0x80], xmm9
000070bab59d56bf  vmovaps [rsp+0x90], xmm10
000070bab59d56c8  vmovaps [rsp+0xA0], xmm11
000070bab59d56d1  vmovaps [rsp+0xB0], xmm12
000070bab59d56da  vmovaps [rsp+0xC0], xmm13
000070bab59d56e3  vmovaps [rsp+0xD0], xmm14
000070bab59d56ec  vmovaps [rsp+0xE0], xmm15
000070bab59d56f5  sub rsp, 0x30
000070bab59d56f9  movaps [rsp], xmm1
000070bab59d56fd  movaps [rsp+0x10], xmm7
000070bab59d5702  movaps [rsp+0x20], xmm11
000070bab59d5708  lea rdi, [rsp]
000070bab59d570c  mov esi, 0x00
000070bab59d5711  mov rax, 0x63B35AFBC530
000070bab59d571b  call rax
000070bab59d571d  movaps xmm1, [rsp]
000070bab59d5721  add rsp, 0x30
000070bab59d5725  vmovaps xmm0, [rsp]
000070bab59d572a  vmovaps xmm2, [rsp+0x10]
000070bab59d5730  vmovaps xmm3, [rsp+0x20]
000070bab59d5736  vmovaps xmm4, [rsp+0x30]
000070bab59d573c  vmovaps xmm5, [rsp+0x40]
000070bab59d5742  vmovaps xmm6, [rsp+0x50]
000070bab59d5748  vmovaps xmm7, [rsp+0x60]
000070bab59d574e  vmovaps xmm8, [rsp+0x70]
000070bab59d5754  vmovaps xmm9, [rsp+0x80]
000070bab59d575d  vmovaps xmm10, [rsp+0x90]
000070bab59d5766  vmovaps xmm11, [rsp+0xA0]
000070bab59d576f  vmovaps xmm12, [rsp+0xB0]
000070bab59d5778  vmovaps xmm13, [rsp+0xC0]
000070bab59d5781  vmovaps xmm14, [rsp+0xD0]
000070bab59d578a  vmovaps xmm15, [rsp+0xE0]
000070bab59d5793  add rsp, 0xF0
000070bab59d579a  pop r11
000070bab59d579c  pop r10
000070bab59d579e  pop r9
000070bab59d57a0  pop r8
000070bab59d57a2  pop rsi
000070bab59d57a3  pop rdi
000070bab59d57a4  pop rdx
000070bab59d57a5  pop rcx
000070bab59d57a6  pop rax
000070bab59d57a7  add rsp, 0x08
000070bab59d57ab  jmp 0x000070BAB59D033B
000070bab59d57b0  call 0x000070BAB580E880
000070bab59d57b5  jmp 0x000070BAB59D034E
000070bab59d57ba  call 0x000070BAB580C380
000070bab59d57bf  jmp 0x000070BAB59D0359
000070bab59d57c4  call 0x000070BAB580D600
000070bab59d57c9  jmp 0x000070BAB59D0364
000070bab59d57ce  call 0x000070BAB57FF540
000070bab59d57d3  jmp 0x000070BAB59D036F
000070bab59d57d8  int3
000070bab59d57d9  nop [rax], eax
000070bab59d57e0  mov rax, [r15+0x40]
000070bab59d57e4  mov r14, [r15+0x58]
000070bab59d57e8  lea r12, [rax+r14*1]
000070bab59d57ec  movaps xmm1, [r15+0x1D0]
000070bab59d57f4  vmovaps [rsp+0x10], xmm1
000070bab59d57fa  vmovaps xmm15, [rsp+0x10]
000070bab59d5800  por xmm1, xmm15
000070bab59d5805  movaps xmm14, [r15+0x1A0]
000070bab59d580d  vmovaps [rsp+0x10], xmm14
000070bab59d5813  vmovaps xmm13, [rsp+0x10]
000070bab59d5819  por xmm14, xmm13
000070bab59d581e  lea rax, [r12+0x30]
000070bab59d5823  mov r11, [r13+rax*1]
000070bab59d5828  lea rax, [r12+0x38]
000070bab59d582d  mov r10, [r13+rax*1]
000070bab59d5832  movq xmm13, r11
000070bab59d5837  movq xmm12, r10
000070bab59d583c  movq xmm13, xmm13
000070bab59d5841  vmovaps [rsp+0x10], xmm13
000070bab59d5847  movq xmm13, xmm13
000070bab59d584c  movaps [r15+0x130], xmm13
000070bab59d5854  movq xmm12, xmm12
000070bab59d5859  vmovaps [rsp+0x20], xmm12
000070bab59d585f  movq xmm12, xmm12
000070bab59d5864  movaps [r15+0x280], xmm12
000070bab59d586c  movaps xmm13, [r15+0x270]
000070bab59d5874  vmovaps [rsp+0x30], xmm13
000070bab59d587a  vmovaps xmm12, [rsp+0x30]
000070bab59d5880  por xmm13, xmm12
000070bab59d5885  lea rax, [r12+0x20]
000070bab59d588a  mov r11, [r13+rax*1]
000070bab59d588f  lea rax, [r12+0x28]
000070bab59d5894  mov r10, [r13+rax*1]
000070bab59d5899  movq xmm12, r11
000070bab59d589e  movq xmm11, r10
000070bab59d58a3  movq xmm12, xmm12
000070bab59d58a8  vmovaps [rsp+0x30], xmm12
000070bab59d58ae  movq xmm12, xmm12
000070bab59d58b3  movaps [r15+0x150], xmm12
000070bab59d58bb  movq xmm11, xmm11
000070bab59d58c0  vmovaps [rsp+0x40], xmm11
000070bab59d58c6  movq xmm11, xmm11
000070bab59d58cb  movaps [r15+0x140], xmm11
000070bab59d58d3  lea rax, [r12+0x10]
000070bab59d58d8  mov r11, [r13+rax*1]
000070bab59d58dd  lea rax, [r12+0x18]
000070bab59d58e2  mov r10, [r13+rax*1]
000070bab59d58e7  movq xmm12, r11
000070bab59d58ec  movq xmm11, r10
000070bab59d58f1  movq xmm12, xmm12
000070bab59d58f6  vmovaps [rsp+0x50], xmm12
000070bab59d58fc  movq xmm12, xmm12
000070bab59d5901  movaps [r15+0x170], xmm12
000070bab59d5909  movq xmm11, xmm11
000070bab59d590e  vmovaps [rsp+0x60], xmm11
000070bab59d5914  movq xmm11, xmm11
000070bab59d5919  movaps [r15+0x160], xmm11
000070bab59d5921  mov rax, [r13+r12*1]
000070bab59d5926  vmovq xmm12, rax
000070bab59d592b  vpbroadcastq xmm12, xmm12
000070bab59d5930  lea rax, [r12+0x08]
000070bab59d5935  mov r12, [r13+rax*1]
000070bab59d593a  movq xmm11, r12
000070bab59d593f  movaps [r15+0x230], xmm11
000070bab59d5947  mov rax, [r15+0xF8]
000070bab59d594e  lea r12, [rax+0x50]
000070bab59d5952  movups xmm11, [r13+r12*1]
000070bab59d5958  lea r12, [rax+0x60]
000070bab59d595c  movups xmm10, [r13+r12*1]
000070bab59d5962  lea r12, [rax+0x30]
000070bab59d5966  movups xmm9, [r13+r12*1]
000070bab59d596c  mov r12, [r15+0x50]
000070bab59d5970  lea r11, [r12+r14*1]
000070bab59d5974  mov [r15+0x60], r11
000070bab59d5978  lea r12, [r14+0x40]
000070bab59d597c  mov [r15+0x58], r12
000070bab59d5980  movaps xmm8, xmm12
000070bab59d5984  mulpd xmm8, xmm15
000070bab59d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000070bab59d598f  ptest xmm7, xmm7
000070bab59d5994  jnz 0x000070BAB59D67B7
000070bab59d599a  movq xmm15, qword ptr [r15+0x230]
000070bab59d59a3  vmovaps [rsp+0x70], xmm15
000070bab59d59a9  vpermilpd xmm15, xmm15, 0x00
000070bab59d59af  movaps xmm7, xmm9
000070bab59d59b3  mulpd xmm7, xmm15
000070bab59d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000070bab59d59bd  ptest xmm6, xmm6
000070bab59d59c2  jnz 0x000070BAB59D68FB
000070bab59d59c8  vxorps xmm15, xmm15, xmm15
000070bab59d59cd  vpbroadcastq xmm15, xmm15
000070bab59d59d2  movaps xmm9, xmm12
000070bab59d59d6  mulpd xmm9, xmm10
000070bab59d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000070bab59d59e1  ptest xmm6, xmm6
000070bab59d59e6  jnz 0x000070BAB59D6A3D
000070bab59d59ec  movaps xmm10, xmm12
000070bab59d59f0  mulpd xmm10, xmm11
000070bab59d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000070bab59d59fb  ptest xmm6, xmm6
000070bab59d5a00  jnz 0x000070BAB59D6B81
000070bab59d5a06  movaps xmm11, [r15+0x1F0]
000070bab59d5a0e  movaps xmm6, xmm12
000070bab59d5a12  mulpd xmm6, xmm11
000070bab59d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000070bab59d5a1c  ptest xmm5, xmm5
000070bab59d5a21  jnz 0x000070BAB59D6CC5
000070bab59d5a27  movaps xmm12, [r15+0x2A0]
000070bab59d5a2f  vmovaps [rsp+0x80], xmm12
000070bab59d5a38  vmovaps xmm11, [rsp+0x80]
000070bab59d5a41  por xmm12, xmm11
000070bab59d5a46  movaps xmm11, [r15+0x250]
000070bab59d5a4e  vmovaps [rsp+0x80], xmm11
000070bab59d5a57  vmovaps xmm5, [rsp+0x80]
000070bab59d5a60  por xmm11, xmm5
000070bab59d5a65  vmovaps xmm4, [rsp+0x70]
000070bab59d5a6b  vpermilpd xmm4, xmm4, 0x00
000070bab59d5a71  movaps xmm3, xmm5
000070bab59d5a74  mulpd xmm3, xmm4
000070bab59d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000070bab59d5a7d  ptest xmm2, xmm2
000070bab59d5a82  jnz 0x000070BAB59D6E07
000070bab59d5a88  mov [rsp+0x80], rax
000070bab59d5a90  xor eax, eax
000070bab59d5a92  mov r14d, 0x200
000070bab59d5a98  cmp r12, r14
000070bab59d5a9b  cmc
000070bab59d5a9c  lahf
000070bab59d5a9d  seto al
000070bab59d5aa0  mov [r15+0x108], eax
000070bab59d5aa7  movaps xmm5, xmm8
000070bab59d5aab  addpd xmm5, xmm15
000070bab59d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000070bab59d5ab5  ptest xmm4, xmm4
000070bab59d5aba  jnz 0x000070BAB59D6F47
000070bab59d5ac0  movaps xmm8, [r15+0x1B0]
000070bab59d5ac8  movaps xmm4, xmm9
000070bab59d5acc  addpd xmm4, xmm8
000070bab59d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000070bab59d5ad6  ptest xmm2, xmm2
000070bab59d5adb  jnz 0x000070BAB59D7089
000070bab59d5ae1  movaps xmm9, xmm10
000070bab59d5ae5  addpd xmm9, xmm8
000070bab59d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000070bab59d5af0  ptest xmm2, xmm2
000070bab59d5af5  jnz 0x000070BAB59D71CB
000070bab59d5afb  movaps xmm10, [r15+0x2F0]
000070bab59d5b03  vmovaps [rsp+0x90], xmm10
000070bab59d5b0c  vmovaps xmm8, [rsp+0x90]
000070bab59d5b15  por xmm10, xmm8
000070bab59d5b1a  movaps xmm8, [r15+0x2E0]
000070bab59d5b22  vmovaps [rsp+0x90], xmm8
000070bab59d5b2b  vmovaps xmm2, [rsp+0x90]
000070bab59d5b34  por xmm8, xmm2
000070bab59d5b39  movaps xmm2, [r15+0x2D0]
000070bab59d5b41  vmovaps [rsp+0x90], xmm2
000070bab59d5b4a  vmovaps [rsp+0xA0], xmm1
000070bab59d5b53  vmovaps xmm1, [rsp+0x90]
000070bab59d5b5c  por xmm2, xmm1
000070bab59d5b60  movaps xmm1, [r15+0x200]
000070bab59d5b68  vmovaps [rsp+0x90], xmm1
000070bab59d5b71  vmovaps [rsp+0xB0], xmm15
000070bab59d5b7a  vmovaps xmm15, [rsp+0x90]
000070bab59d5b83  por xmm1, xmm15
000070bab59d5b88  movaps xmm15, [r15+0x1C0]
000070bab59d5b90  vmovaps [rsp+0x90], xmm15
000070bab59d5b99  vmovaps [rsp+0xC0], xmm1
000070bab59d5ba2  vmovaps xmm1, [rsp+0x90]
000070bab59d5bab  por xmm15, xmm1
000070bab59d5bb0  movaps xmm1, [r15+0x190]
000070bab59d5bb8  vmovaps [rsp+0x90], xmm1
000070bab59d5bc1  vmovaps [rsp+0xD0], xmm15
000070bab59d5bca  vmovaps xmm15, [rsp+0x90]
000070bab59d5bd3  por xmm1, xmm15
000070bab59d5bd8  movaps xmm15, [r15+0x300]
000070bab59d5be0  vmovaps [rsp+0x90], xmm15
000070bab59d5be9  vmovaps [rsp+0xE0], xmm1
000070bab59d5bf2  vmovaps xmm1, [rsp+0x90]
000070bab59d5bfb  por xmm15, xmm1
000070bab59d5c00  mov rax, [rsp+0x80]
000070bab59d5c08  lea r14, [rax+0xA0]
000070bab59d5c0f  movups xmm1, [r13+r14*1]
000070bab59d5c15  lea r14, [rax+0xB0]
000070bab59d5c1c  vmovaps [rsp+0x80], xmm1
000070bab59d5c25  movups xmm1, [r13+r14*1]
000070bab59d5c2b  vmovaps [rsp+0x90], xmm1
000070bab59d5c34  vmovaps [rsp+0xF0], xmm15
000070bab59d5c3d  vmovaps xmm15, [rsp+0xB0]
000070bab59d5c46  vmovaps [rsp+0xB0], xmm14
000070bab59d5c4f  movaps xmm1, xmm6
000070bab59d5c52  addpd xmm1, xmm15
000070bab59d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000070bab59d5c5c  ptest xmm14, xmm14
000070bab59d5c62  jnz 0x000070BAB59D7323
000070bab59d5c68  lea r14, [rax+0xF0]
000070bab59d5c6f  movups xmm15, [r13+r14*1]
000070bab59d5c75  movaps xmm14, xmm4
000070bab59d5c79  addpd xmm14, xmm3
000070bab59d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000070bab59d5c84  ptest xmm6, xmm6
000070bab59d5c89  jnz 0x000070BAB59D746E
000070bab59d5c8f  movaps xmm6, xmm9
000070bab59d5c93  addpd xmm6, xmm7
000070bab59d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000070bab59d5c9c  ptest xmm4, xmm4
000070bab59d5ca1  jnz 0x000070BAB59D75B0
000070bab59d5ca7  vmovaps xmm9, [rsp+0x70]
000070bab59d5cad  vpermilpd xmm9, xmm9, 0x00
000070bab59d5cb3  vmovaps xmm4, [rsp+0x90]
000070bab59d5cbc  movaps xmm7, xmm4
000070bab59d5cbf  mulpd xmm7, xmm9
000070bab59d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000070bab59d5cc9  ptest xmm3, xmm3
000070bab59d5cce  jnz 0x000070BAB59D76F1
000070bab59d5cd4  vmovaps xmm9, [rsp+0x50]
000070bab59d5cda  vpermilpd xmm9, xmm9, 0x00
000070bab59d5ce0  movaps xmm4, xmm15
000070bab59d5ce4  mulpd xmm4, xmm9
000070bab59d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000070bab59d5cee  ptest xmm3, xmm3
000070bab59d5cf3  jnz 0x000070BAB59D7832
000070bab59d5cf9  lea r14, [rax+0xE0]
000070bab59d5d00  movups xmm15, [r13+r14*1]
000070bab59d5d06  vmovaps xmm9, [rsp+0x70]
000070bab59d5d0c  vpermilpd xmm9, xmm9, 0x00
000070bab59d5d12  vmovaps [rsp+0x70], xmm1
000070bab59d5d18  vmovaps xmm1, [rsp+0x80]
000070bab59d5d21  vmovaps [rsp+0x80], xmm15
000070bab59d5d2a  movaps xmm3, xmm1
000070bab59d5d2d  mulpd xmm3, xmm9
000070bab59d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000070bab59d5d37  ptest xmm15, xmm15
000070bab59d5d3d  jnz 0x000070BAB59D797E
000070bab59d5d43  vmovaps xmm1, [rsp+0xF0]
000070bab59d5d4c  vmovaps xmm15, [rsp+0xF0]
000070bab59d5d55  por xmm1, xmm15
000070bab59d5d5a  movaps [r15+0x300], xmm1
000070bab59d5d62  vmovaps xmm15, [rsp+0xE0]
000070bab59d5d6b  vmovaps xmm9, [rsp+0xE0]
000070bab59d5d74  por xmm15, xmm9
000070bab59d5d79  movaps [r15+0x190], xmm15
000070bab59d5d81  vmovaps xmm9, [rsp+0x50]
000070bab59d5d87  vpermilpd xmm9, xmm9, 0x00
000070bab59d5d8d  vmovaps [rsp+0x90], xmm1
000070bab59d5d96  vmovaps [rsp+0xE0], xmm15
000070bab59d5d9f  vmovaps xmm15, [rsp+0x80]
000070bab59d5da8  vmovaps [rsp+0x80], xmm14
000070bab59d5db1  movaps xmm1, xmm15
000070bab59d5db5  mulpd xmm1, xmm9
000070bab59d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000070bab59d5dbf  ptest xmm14, xmm14
000070bab59d5dc5  jnz 0x000070BAB59D7ABF
000070bab59d5dcb  lea r14, [rax+0x90]
000070bab59d5dd2  movups xmm15, [r13+r14*1]
000070bab59d5dd8  vmovaps xmm14, [rsp+0xD0]
000070bab59d5de1  vmovaps xmm9, [rsp+0xD0]
000070bab59d5dea  por xmm14, xmm9
000070bab59d5def  movaps [r15+0x1C0], xmm14
000070bab59d5df7  vmovaps xmm9, [rsp+0xC0]
000070bab59d5e00  vmovaps [rsp+0xD0], xmm1
000070bab59d5e09  vmovaps xmm1, [rsp+0xC0]
000070bab59d5e12  por xmm9, xmm1
000070bab59d5e17  movaps [r15+0x200], xmm9
000070bab59d5e1f  vmovaps [rsp+0xC0], xmm2
000070bab59d5e28  vmovaps xmm1, [rsp+0xC0]
000070bab59d5e31  por xmm2, xmm1
000070bab59d5e35  movaps [r15+0x2D0], xmm2
000070bab59d5e3d  vmovaps [rsp+0xC0], xmm8
000070bab59d5e46  vmovaps xmm1, [rsp+0xC0]
000070bab59d5e4f  por xmm8, xmm1
000070bab59d5e54  movaps [r15+0x2E0], xmm8
000070bab59d5e5c  vmovaps [rsp+0xC0], xmm15
000070bab59d5e65  movaps xmm1, xmm5
000070bab59d5e68  addpd xmm1, xmm7
000070bab59d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000070bab59d5e71  ptest xmm15, xmm15
000070bab59d5e77  jnz 0x000070BAB59D7C0B
000070bab59d5e7d  vmovaps xmm15, [rsp+0x50]
000070bab59d5e83  vpermilpd xmm15, xmm15, 0x00
000070bab59d5e89  vmovaps xmm5, [rsp+0xC0]
000070bab59d5e92  vmovaps [rsp+0xC0], xmm1
000070bab59d5e9b  movaps xmm7, xmm5
000070bab59d5e9e  mulpd xmm7, xmm15
000070bab59d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000070bab59d5ea8  ptest xmm1, xmm1
000070bab59d5ead  jnz 0x000070BAB59D7D4B
000070bab59d5eb3  lea r14, [rax+0x80]
000070bab59d5eba  movups xmm1, [r13+r14*1]
000070bab59d5ec0  vmovaps xmm5, [rsp+0x70]
000070bab59d5ec6  vmovaps [rsp+0x70], xmm1
000070bab59d5ecc  movaps xmm15, xmm5
000070bab59d5ed0  addpd xmm15, xmm3
000070bab59d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000070bab59d5edb  ptest xmm1, xmm1
000070bab59d5ee0  jnz 0x000070BAB59D7E96
000070bab59d5ee6  vmovaps xmm5, [rsp+0x80]
000070bab59d5eef  movaps xmm1, xmm5
000070bab59d5ef2  addpd xmm1, xmm4
000070bab59d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000070bab59d5efb  ptest xmm3, xmm3
000070bab59d5f00  jnz 0x000070BAB59D7FD8
000070bab59d5f06  vmovaps [rsp+0x80], xmm10
000070bab59d5f0f  vmovaps xmm5, [rsp+0x80]
000070bab59d5f18  por xmm10, xmm5
000070bab59d5f1d  movaps [r15+0x2F0], xmm10
000070bab59d5f25  vmovaps xmm5, [rsp+0x50]
000070bab59d5f2b  vpermilpd xmm5, xmm5, 0x00
000070bab59d5f31  vmovaps xmm3, [rsp+0x70]
000070bab59d5f37  vmovaps [rsp+0x50], xmm1
000070bab59d5f3d  movaps xmm4, xmm3
000070bab59d5f40  mulpd xmm4, xmm5
000070bab59d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000070bab59d5f49  ptest xmm1, xmm1
000070bab59d5f4e  jnz 0x000070BAB59D8118
000070bab59d5f54  lea r14, [rax+0xD0]
000070bab59d5f5b  movups xmm1, [r13+r14*1]
000070bab59d5f61  vmovaps xmm3, [rsp+0xD0]
000070bab59d5f6a  vmovaps [rsp+0x70], xmm1
000070bab59d5f70  movaps xmm5, xmm6
000070bab59d5f73  addpd xmm5, xmm3
000070bab59d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000070bab59d5f7c  ptest xmm1, xmm1
000070bab59d5f81  jnz 0x000070BAB59D8262
000070bab59d5f87  vmovaps xmm1, [rsp+0x60]
000070bab59d5f8d  vpermilpd xmm1, xmm1, 0x00
000070bab59d5f93  movaps xmm6, xmm9
000070bab59d5f97  mulpd xmm6, xmm1
000070bab59d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000070bab59d5fa0  ptest xmm3, xmm3
000070bab59d5fa5  jnz 0x000070BAB59D83A2
000070bab59d5fab  movaps [r15+0x260], xmm6
000070bab59d5fb3  vxorps xmm1, xmm1, xmm1
000070bab59d5fb7  vpbroadcastq xmm1, xmm1
000070bab59d5fbc  movaps [r15+0x1B0], xmm1
000070bab59d5fc4  vmovaps xmm1, [rsp+0x60]
000070bab59d5fca  vpermilpd xmm1, xmm1, 0x00
000070bab59d5fd0  vmovaps xmm3, [rsp+0x70]
000070bab59d5fd6  vmovaps [rsp+0x70], xmm15
000070bab59d5fdc  movaps xmm9, xmm3
000070bab59d5fe0  mulpd xmm9, xmm1
000070bab59d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000070bab59d5feb  ptest xmm15, xmm15
000070bab59d5ff1  jnz 0x000070BAB59D84E3
000070bab59d5ff7  lea r14, [rax+0xC0]
000070bab59d5ffe  movups xmm1, [r13+r14*1]
000070bab59d6004  vmovaps xmm3, [rsp+0xC0]
000070bab59d600d  vmovaps [rsp+0x80], xmm1
000070bab59d6016  movaps xmm15, xmm3
000070bab59d601a  addpd xmm15, xmm7
000070bab59d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000070bab59d6025  ptest xmm1, xmm1
000070bab59d602a  jnz 0x000070BAB59D862F
000070bab59d6030  vmovaps [rsp+0xC0], xmm13
000070bab59d6039  vmovaps xmm1, [rsp+0xC0]
000070bab59d6042  por xmm13, xmm1
000070bab59d6047  movaps [r15+0x270], xmm13
000070bab59d604f  vmovaps xmm1, [rsp+0xB0]
000070bab59d6058  vmovaps xmm7, [rsp+0xB0]
000070bab59d6061  por xmm1, xmm7
000070bab59d6065  movaps [r15+0x1A0], xmm1
000070bab59d606d  vmovaps xmm1, [rsp+0x60]
000070bab59d6073  vpermilpd xmm1, xmm1, 0x00
000070bab59d6079  vmovaps [rsp+0xB0], xmm1
000070bab59d6082  vmovaps xmm1, [rsp+0x80]
000070bab59d608b  vmovaps [rsp+0x80], xmm15
000070bab59d6094  vmovaps xmm15, [rsp+0xB0]
000070bab59d609d  vmovaps [rsp+0xB0], xmm14
000070bab59d60a6  movaps xmm3, xmm1
000070bab59d60a9  mulpd xmm3, xmm15
000070bab59d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000070bab59d60b3  ptest xmm14, xmm14
000070bab59d60b9  jnz 0x000070BAB59D8771
000070bab59d60bf  lea r14, [rax+0x20]
000070bab59d60c3  movups xmm1, [r13+r14*1]
000070bab59d60c9  movaps [r15+0x110], xmm1
000070bab59d60d1  vmovaps xmm14, [rsp+0x70]
000070bab59d60d7  vmovaps [rsp+0x70], xmm1
000070bab59d60dd  movaps xmm15, xmm14
000070bab59d60e1  addpd xmm15, xmm4
000070bab59d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000070bab59d60ec  ptest xmm1, xmm1
000070bab59d60f1  jnz 0x000070BAB59D88BC
000070bab59d60f7  vmovaps xmm1, [rsp+0x60]
000070bab59d60fd  vpermilpd xmm1, xmm1, 0x00
000070bab59d6103  movaps xmm14, xmm2
000070bab59d6107  mulpd xmm14, xmm1
000070bab59d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000070bab59d6112  ptest xmm4, xmm4
000070bab59d6117  jnz 0x000070BAB59D89FF
000070bab59d611d  vmovaps xmm4, [rsp+0x50]
000070bab59d6123  movaps xmm1, xmm4
000070bab59d6126  addpd xmm1, xmm9
000070bab59d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000070bab59d6130  ptest xmm2, xmm2
000070bab59d6135  jnz 0x000070BAB59D8B41
000070bab59d613b  vmovaps xmm9, [rsp+0x30]
000070bab59d6141  vpermilpd xmm9, xmm9, 0x00
000070bab59d6147  vmovaps xmm2, [rsp+0x70]
000070bab59d614d  vmovaps [rsp+0x50], xmm1
000070bab59d6153  movaps xmm4, xmm2
000070bab59d6156  mulpd xmm4, xmm9
000070bab59d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000070bab59d6160  ptest xmm1, xmm1
000070bab59d6165  jnz 0x000070BAB59D8C82
000070bab59d616b  vmovaps xmm1, [rsp+0x30]
000070bab59d6171  vpermilpd xmm1, xmm1, 0x00
000070bab59d6177  vmovaps xmm2, [rsp+0x90]
000070bab59d6180  vmovaps [rsp+0x60], xmm15
000070bab59d6186  movaps xmm9, xmm2
000070bab59d618a  mulpd xmm9, xmm1
000070bab59d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000070bab59d6195  ptest xmm15, xmm15
000070bab59d619b  jnz 0x000070BAB59D8DC3
000070bab59d61a1  vmovaps xmm15, [rsp+0x80]
000070bab59d61aa  movaps xmm1, xmm15
000070bab59d61ae  addpd xmm1, xmm6
000070bab59d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000070bab59d61b7  ptest xmm2, xmm2
000070bab59d61bc  jnz 0x000070BAB59D8F05
000070bab59d61c2  movaps xmm15, xmm5
000070bab59d61c6  addpd xmm15, xmm3
000070bab59d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000070bab59d61d1  ptest xmm6, xmm6
000070bab59d61d6  jnz 0x000070BAB59D9046
000070bab59d61dc  vmovaps xmm6, [rsp+0x30]
000070bab59d61e2  vpermilpd xmm6, xmm6, 0x00
000070bab59d61e8  movaps xmm5, xmm8
000070bab59d61ec  mulpd xmm5, xmm6
000070bab59d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000070bab59d61f5  ptest xmm3, xmm3
000070bab59d61fa  jnz 0x000070BAB59D9188
000070bab59d6200  vmovaps xmm8, [rsp+0x30]
000070bab59d6206  vpermilpd xmm8, xmm8, 0x00
000070bab59d620c  movaps xmm6, xmm10
000070bab59d6210  mulpd xmm6, xmm8
000070bab59d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000070bab59d621a  ptest xmm3, xmm3
000070bab59d621f  jnz 0x000070BAB59D92C9
000070bab59d6225  vmovaps xmm8, [rsp+0x60]
000070bab59d622b  movaps xmm10, xmm8
000070bab59d622f  addpd xmm10, xmm14
000070bab59d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000070bab59d623a  ptest xmm3, xmm3
000070bab59d623f  jnz 0x000070BAB59D940B
000070bab59d6245  vmovaps xmm8, [rsp+0x50]
000070bab59d624b  movaps xmm14, xmm8
000070bab59d624f  addpd xmm14, xmm4
000070bab59d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000070bab59d625a  ptest xmm3, xmm3
000070bab59d625f  jnz 0x000070BAB59D954F
000070bab59d6265  vmovaps xmm8, [rsp+0x40]
000070bab59d626b  vpermilpd xmm8, xmm8, 0x00
000070bab59d6271  movaps xmm4, xmm13
000070bab59d6275  mulpd xmm4, xmm8
000070bab59d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000070bab59d627f  ptest xmm3, xmm3
000070bab59d6284  jnz 0x000070BAB59D9692
000070bab59d628a  movaps xmm13, xmm15
000070bab59d628e  addpd xmm13, xmm9
000070bab59d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000070bab59d6299  ptest xmm8, xmm8
000070bab59d629f  jnz 0x000070BAB59D97D4
000070bab59d62a5  movaps xmm15, xmm1
000070bab59d62a9  addpd xmm15, xmm5
000070bab59d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000070bab59d62b4  ptest xmm9, xmm9
000070bab59d62ba  jnz 0x000070BAB59D9918
000070bab59d62c0  vmovaps [rsp+0x30], xmm11
000070bab59d62c6  vmovaps xmm1, [rsp+0x30]
000070bab59d62cc  por xmm11, xmm1
000070bab59d62d1  movaps [r15+0x250], xmm11
000070bab59d62d9  vmovaps [rsp+0x30], xmm12
000070bab59d62df  vmovaps xmm1, [rsp+0x30]
000070bab59d62e5  por xmm12, xmm1
000070bab59d62ea  movaps [r15+0x2A0], xmm12
000070bab59d62f2  vmovaps xmm1, [rsp+0xA0]
000070bab59d62fb  vmovaps xmm11, [rsp+0xA0]
000070bab59d6304  por xmm1, xmm11
000070bab59d6309  movaps [r15+0x1D0], xmm1
000070bab59d6311  lea r14, [rax+0x40]
000070bab59d6315  movups xmm1, [r13+r14*1]
000070bab59d631b  movaps [r15+0x2C0], xmm1
000070bab59d6323  vmovaps xmm11, [rsp+0x40]
000070bab59d6329  vpermilpd xmm11, xmm11, 0x00
000070bab59d632f  vmovaps xmm8, [rsp+0xE0]
000070bab59d6338  movaps xmm9, xmm8
000070bab59d633c  mulpd xmm9, xmm11
000070bab59d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000070bab59d6347  ptest xmm5, xmm5
000070bab59d634c  jnz 0x000070BAB59D9A64
000070bab59d6352  movaps xmm11, xmm10
000070bab59d6356  addpd xmm11, xmm6
000070bab59d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000070bab59d6361  ptest xmm8, xmm8
000070bab59d6367  jnz 0x000070BAB59D9BA8
000070bab59d636d  movaps xmm10, xmm14
000070bab59d6371  addpd xmm10, xmm4
000070bab59d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000070bab59d637c  ptest xmm8, xmm8
000070bab59d6382  jnz 0x000070BAB59D9CEB
000070bab59d6388  vmovaps xmm14, [rsp+0x40]
000070bab59d638e  vpermilpd xmm14, xmm14, 0x00
000070bab59d6394  movaps xmm8, xmm1
000070bab59d6398  mulpd xmm8, xmm14
000070bab59d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000070bab59d63a3  ptest xmm6, xmm6
000070bab59d63a8  jnz 0x000070BAB59D9E2E
000070bab59d63ae  movaps xmm1, [r15+0x2B0]
000070bab59d63b6  vmovaps xmm14, [rsp+0x40]
000070bab59d63bc  vpermilpd xmm14, xmm14, 0x00
000070bab59d63c2  movaps xmm6, xmm1
000070bab59d63c5  mulpd xmm6, xmm14
000070bab59d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000070bab59d63cf  ptest xmm5, xmm5
000070bab59d63d4  jnz 0x000070BAB59D9F71
000070bab59d63da  vmovaps xmm1, [rsp+0x10]
000070bab59d63e0  vpermilpd xmm1, xmm1, 0x00
000070bab59d63e6  movaps xmm14, xmm12
000070bab59d63ea  mulpd xmm14, xmm1
000070bab59d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000070bab59d63f5  ptest xmm5, xmm5
000070bab59d63fa  jnz 0x000070BAB59DA0B2
000070bab59d6400  movaps xmm1, xmm13
000070bab59d6404  addpd xmm1, xmm9
000070bab59d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000070bab59d640e  ptest xmm12, xmm12
000070bab59d6414  jnz 0x000070BAB59DA1F5
000070bab59d641a  vmovaps xmm13, [rsp+0x10]
000070bab59d6420  vpermilpd xmm13, xmm13, 0x00
000070bab59d6426  movaps xmm12, xmm7
000070bab59d642a  mulpd xmm12, xmm13
000070bab59d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000070bab59d6435  ptest xmm9, xmm9
000070bab59d643b  jnz 0x000070BAB59DA337
000070bab59d6441  movaps xmm13, xmm15
000070bab59d6445  addpd xmm13, xmm8
000070bab59d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000070bab59d6450  ptest xmm9, xmm9
000070bab59d6456  jnz 0x000070BAB59DA47A
000070bab59d645c  movaps xmm15, [r15+0x290]
000070bab59d6464  vmovaps xmm9, [rsp+0x10]
000070bab59d646a  vpermilpd xmm9, xmm9, 0x00
000070bab59d6470  movaps xmm8, xmm15
000070bab59d6474  mulpd xmm8, xmm9
000070bab59d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000070bab59d647f  ptest xmm7, xmm7
000070bab59d6484  jnz 0x000070BAB59DA5BE
000070bab59d648a  movaps xmm15, xmm11
000070bab59d648e  addpd xmm15, xmm6
000070bab59d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000070bab59d6499  ptest xmm9, xmm9
000070bab59d649f  jnz 0x000070BAB59DA702
000070bab59d64a5  movaps xmm11, [r15+0x1E0]
000070bab59d64ad  vmovaps xmm9, [rsp+0x10]
000070bab59d64b3  vpermilpd xmm9, xmm9, 0x00
000070bab59d64b9  movaps xmm7, xmm11
000070bab59d64bd  mulpd xmm7, xmm9
000070bab59d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000070bab59d64c7  ptest xmm6, xmm6
000070bab59d64cc  jnz 0x000070BAB59DA845
000070bab59d64d2  movaps xmm11, xmm10
000070bab59d64d6  addpd xmm11, xmm14
000070bab59d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000070bab59d64e1  ptest xmm9, xmm9
000070bab59d64e7  jnz 0x000070BAB59DA987
000070bab59d64ed  lea r14, [rax+0x70]
000070bab59d64f1  movups xmm14, [r13+r14*1]
000070bab59d64f7  movaps [r15+0x240], xmm14
000070bab59d64ff  movaps xmm10, xmm1
000070bab59d6503  addpd xmm10, xmm12
000070bab59d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000070bab59d650e  ptest xmm9, xmm9
000070bab59d6514  jnz 0x000070BAB59DAAD5
000070bab59d651a  movaps [r15+0x170], xmm10
000070bab59d6522  vmovaps xmm1, [rsp+0x20]
000070bab59d6528  vpermilpd xmm1, xmm1, 0x00
000070bab59d652e  movaps xmm12, xmm14
000070bab59d6532  mulpd xmm12, xmm1
000070bab59d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000070bab59d653d  ptest xmm9, xmm9
000070bab59d6543  jnz 0x000070BAB59DAC18
000070bab59d6549  vmovaps xmm1, [rsp+0x20]
000070bab59d654f  vpermilpd xmm1, xmm1, 0x00
000070bab59d6555  vmovaps xmm9, [rsp+0xB0]
000070bab59d655e  movaps xmm14, xmm9
000070bab59d6562  mulpd xmm14, xmm1
000070bab59d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000070bab59d656d  ptest xmm6, xmm6
000070bab59d6572  jnz 0x000070BAB59DAD5B
000070bab59d6578  movaps [r15+0x180], xmm14
000070bab59d6580  movaps xmm1, xmm13
000070bab59d6584  addpd xmm1, xmm8
000070bab59d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000070bab59d658e  ptest xmm9, xmm9
000070bab59d6594  jnz 0x000070BAB59DAE9E
000070bab59d659a  movaps [r15+0x210], xmm1
000070bab59d65a2  movups xmm13, [r13+rax*1]
000070bab59d65a8  lea r14, [rax+0x10]
000070bab59d65ac  movups xmm9, [r13+r14*1]
000070bab59d65b2  movaps [r15+0x230], xmm9
000070bab59d65ba  movaps xmm8, xmm15
000070bab59d65be  addpd xmm8, xmm7
000070bab59d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000070bab59d65c9  ptest xmm6, xmm6
000070bab59d65ce  jnz 0x000070BAB59DAFF4
000070bab59d65d4  movaps [r15+0x130], xmm8
000070bab59d65dc  vmovaps xmm15, [rsp+0x20]
000070bab59d65e2  vpermilpd xmm15, xmm15, 0x00
000070bab59d65e8  movaps xmm7, xmm9
000070bab59d65ec  mulpd xmm7, xmm15
000070bab59d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000070bab59d65f6  ptest xmm6, xmm6
000070bab59d65fb  jnz 0x000070BAB59DB137
000070bab59d6601  movaps [r15+0x220], xmm7
000070bab59d6609  vmovaps xmm15, [rsp+0x20]
000070bab59d660f  vpermilpd xmm15, xmm15, 0x00
000070bab59d6615  movaps xmm9, xmm13
000070bab59d6619  mulpd xmm9, xmm15
000070bab59d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000070bab59d6624  ptest xmm6, xmm6
000070bab59d6629  jnz 0x000070BAB59DB279
000070bab59d662f  movaps xmm15, xmm11
000070bab59d6633  addpd xmm15, xmm12
000070bab59d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000070bab59d663e  ptest xmm13, xmm13
000070bab59d6644  jnz 0x000070BAB59DB3BD
000070bab59d664a  movaps [r15+0x140], xmm15
000070bab59d6652  movaps xmm13, xmm10
000070bab59d6656  addpd xmm13, xmm14
000070bab59d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000070bab59d6661  ptest xmm12, xmm12
000070bab59d6667  jnz 0x000070BAB59DB501
000070bab59d666d  movaps [r15+0x150], xmm13
000070bab59d6675  movaps xmm14, xmm1
000070bab59d6679  addpd xmm14, xmm7
000070bab59d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000070bab59d6684  ptest xmm12, xmm12
000070bab59d668a  jnz 0x000070BAB59DB645
000070bab59d6690  movaps [r15+0x160], xmm14
000070bab59d6698  movaps xmm1, xmm8
000070bab59d669c  addpd xmm1, xmm9
000070bab59d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000070bab59d66a6  ptest xmm12, xmm12
000070bab59d66ac  jnz 0x000070BAB59DB787
000070bab59d66b2  movaps [r15+0x120], xmm1
000070bab59d66ba  movups [r13+r11*1], xmm15
000070bab59d66c0  lea rax, [r11+0x10]
000070bab59d66c4  movups [r13+rax*1], xmm13
000070bab59d66ca  lea rax, [r11+0x20]
000070bab59d66ce  movups [r13+rax*1], xmm14
000070bab59d66d4  lea rax, [r11+0x30]
000070bab59d66d8  movups [r13+rax*1], xmm1
000070bab59d66de  mov eax, [r15+0x108]
000070bab59d66e5  sahf
000070bab59d66e6  jnz 0x000070BAB59D6718
000070bab59d66e8  cmp dword ptr [r15+0x318], 0x00
000070bab59d66f0  jz 0x000070BAB59DB900
000070bab59d66f6  nop [rax+rax*1], ax
000070bab59d66ff  nop [rax+rax*1], eax
000070bab59d6707  mov eax, 0x410444
000070bab59d670c  mov [r15+0x100], rax
000070bab59d6713  jmp 0x000070BAB57FE110
000070bab59d6718  cmp dword ptr [r15+0x318], 0x00
000070bab59d6720  jz 0x000070BAB59D57E0
000070bab59d6726  nop [rax+rax*1], ax
000070bab59d672f  nop [rax+rax*1], eax
000070bab59d6737  mov eax, 0x410278
000070bab59d673c  mov [r15+0x100], rax
000070bab59d6743  jmp 0x000070BAB57FE110
000070bab59d6748  int3
000070bab59d6749  call 0x000070BAB580A4B0
000070bab59d674e  jmp 0x000070BAB59D5828
000070bab59d6753  call 0x000070BAB5809240
000070bab59d6758  jmp 0x000070BAB59D5832
000070bab59d675d  call 0x000070BAB580A4B0
000070bab59d6762  jmp 0x000070BAB59D588F
000070bab59d6767  call 0x000070BAB5809240
000070bab59d676c  jmp 0x000070BAB59D5899
000070bab59d6771  call 0x000070BAB580A4B0
000070bab59d6776  jmp 0x000070BAB59D58DD
000070bab59d677b  call 0x000070BAB5809240
000070bab59d6780  jmp 0x000070BAB59D58E7
000070bab59d6785  call 0x000070BAB58B47C0
000070bab59d678a  jmp 0x000070BAB59D5926
000070bab59d678f  call 0x000070BAB580B720
000070bab59d6794  jmp 0x000070BAB59D593A
000070bab59d6799  call 0x000070BAB58BFC30
000070bab59d679e  jmp 0x000070BAB59D5958
000070bab59d67a3  call 0x000070BAB58BE9C0
000070bab59d67a8  jmp 0x000070BAB59D5962
000070bab59d67ad  call 0x000070BAB58BD750
000070bab59d67b2  jmp 0x000070BAB59D596C
000070bab59d67b7  sub rsp, 0x08
000070bab59d67bb  push rax
000070bab59d67bc  push rcx
000070bab59d67bd  push rdx
000070bab59d67be  push rdi
000070bab59d67bf  push rsi
000070bab59d67c0  push r8
000070bab59d67c2  push r9
000070bab59d67c4  push r10
000070bab59d67c6  push r11
000070bab59d67c8  sub rsp, 0xF0
000070bab59d67cf  vmovaps [rsp], xmm0
000070bab59d67d4  vmovaps [rsp+0x10], xmm1
000070bab59d67da  vmovaps [rsp+0x20], xmm2
000070bab59d67e0  vmovaps [rsp+0x30], xmm3
000070bab59d67e6  vmovaps [rsp+0x40], xmm4
000070bab59d67ec  vmovaps [rsp+0x50], xmm5
000070bab59d67f2  vmovaps [rsp+0x60], xmm6
000070bab59d67f8  vmovaps [rsp+0x70], xmm7
000070bab59d67fe  vmovaps [rsp+0x80], xmm9
000070bab59d6807  vmovaps [rsp+0x90], xmm10
000070bab59d6810  vmovaps [rsp+0xA0], xmm11
000070bab59d6819  vmovaps [rsp+0xB0], xmm12
000070bab59d6822  vmovaps [rsp+0xC0], xmm13
000070bab59d682b  vmovaps [rsp+0xD0], xmm14
000070bab59d6834  vmovaps [rsp+0xE0], xmm15
000070bab59d683d  sub rsp, 0x30
000070bab59d6841  movaps [rsp], xmm8
000070bab59d6846  movaps [rsp+0x10], xmm12
000070bab59d684c  movaps [rsp+0x20], xmm15
000070bab59d6852  lea rdi, [rsp]
000070bab59d6856  mov esi, 0x00
000070bab59d685b  mov rax, 0x63B35AFBC530
000070bab59d6865  call rax
000070bab59d6867  movaps xmm8, [rsp]
000070bab59d686c  add rsp, 0x30
000070bab59d6870  vmovaps xmm0, [rsp]
000070bab59d6875  vmovaps xmm1, [rsp+0x10]
000070bab59d687b  vmovaps xmm2, [rsp+0x20]
000070bab59d6881  vmovaps xmm3, [rsp+0x30]
000070bab59d6887  vmovaps xmm4, [rsp+0x40]
000070bab59d688d  vmovaps xmm5, [rsp+0x50]
000070bab59d6893  vmovaps xmm6, [rsp+0x60]
000070bab59d6899  vmovaps xmm7, [rsp+0x70]
000070bab59d689f  vmovaps xmm9, [rsp+0x80]
000070bab59d68a8  vmovaps xmm10, [rsp+0x90]
000070bab59d68b1  vmovaps xmm11, [rsp+0xA0]
000070bab59d68ba  vmovaps xmm12, [rsp+0xB0]
000070bab59d68c3  vmovaps xmm13, [rsp+0xC0]
000070bab59d68cc  vmovaps xmm14, [rsp+0xD0]
000070bab59d68d5  vmovaps xmm15, [rsp+0xE0]
000070bab59d68de  add rsp, 0xF0
000070bab59d68e5  pop r11
000070bab59d68e7  pop r10
000070bab59d68e9  pop r9
000070bab59d68eb  pop r8
000070bab59d68ed  pop rsi
000070bab59d68ee  pop rdi
000070bab59d68ef  pop rdx
000070bab59d68f0  pop rcx
000070bab59d68f1  pop rax
000070bab59d68f2  add rsp, 0x08
000070bab59d68f6  jmp 0x000070BAB59D599A
000070bab59d68fb  sub rsp, 0x08
000070bab59d68ff  push rax
000070bab59d6900  push rcx
000070bab59d6901  push rdx
000070bab59d6902  push rdi
000070bab59d6903  push rsi
000070bab59d6904  push r8
000070bab59d6906  push r9
000070bab59d6908  push r10
000070bab59d690a  push r11
000070bab59d690c  sub rsp, 0xF0
000070bab59d6913  vmovaps [rsp], xmm0
000070bab59d6918  vmovaps [rsp+0x10], xmm1
000070bab59d691e  vmovaps [rsp+0x20], xmm2
000070bab59d6924  vmovaps [rsp+0x30], xmm3
000070bab59d692a  vmovaps [rsp+0x40], xmm4
000070bab59d6930  vmovaps [rsp+0x50], xmm5
000070bab59d6936  vmovaps [rsp+0x60], xmm6
000070bab59d693c  vmovaps [rsp+0x70], xmm8
000070bab59d6942  vmovaps [rsp+0x80], xmm9
000070bab59d694b  vmovaps [rsp+0x90], xmm10
000070bab59d6954  vmovaps [rsp+0xA0], xmm11
000070bab59d695d  vmovaps [rsp+0xB0], xmm12
000070bab59d6966  vmovaps [rsp+0xC0], xmm13
000070bab59d696f  vmovaps [rsp+0xD0], xmm14
000070bab59d6978  vmovaps [rsp+0xE0], xmm15
000070bab59d6981  sub rsp, 0x30
000070bab59d6985  movaps [rsp], xmm7
000070bab59d6989  movaps [rsp+0x10], xmm9
000070bab59d698f  movaps [rsp+0x20], xmm15
000070bab59d6995  lea rdi, [rsp]
000070bab59d6999  mov esi, 0x00
000070bab59d699e  mov rax, 0x63B35AFBC530
000070bab59d69a8  call rax
000070bab59d69aa  movaps xmm7, [rsp]
000070bab59d69ae  add rsp, 0x30
000070bab59d69b2  vmovaps xmm0, [rsp]
000070bab59d69b7  vmovaps xmm1, [rsp+0x10]
000070bab59d69bd  vmovaps xmm2, [rsp+0x20]
000070bab59d69c3  vmovaps xmm3, [rsp+0x30]
000070bab59d69c9  vmovaps xmm4, [rsp+0x40]
000070bab59d69cf  vmovaps xmm5, [rsp+0x50]
000070bab59d69d5  vmovaps xmm6, [rsp+0x60]
000070bab59d69db  vmovaps xmm8, [rsp+0x70]
000070bab59d69e1  vmovaps xmm9, [rsp+0x80]
000070bab59d69ea  vmovaps xmm10, [rsp+0x90]
000070bab59d69f3  vmovaps xmm11, [rsp+0xA0]
000070bab59d69fc  vmovaps xmm12, [rsp+0xB0]
000070bab59d6a05  vmovaps xmm13, [rsp+0xC0]
000070bab59d6a0e  vmovaps xmm14, [rsp+0xD0]
000070bab59d6a17  vmovaps xmm15, [rsp+0xE0]
000070bab59d6a20  add rsp, 0xF0
000070bab59d6a27  pop r11
000070bab59d6a29  pop r10
000070bab59d6a2b  pop r9
000070bab59d6a2d  pop r8
000070bab59d6a2f  pop rsi
000070bab59d6a30  pop rdi
000070bab59d6a31  pop rdx
000070bab59d6a32  pop rcx
000070bab59d6a33  pop rax
000070bab59d6a34  add rsp, 0x08
000070bab59d6a38  jmp 0x000070BAB59D59C8
000070bab59d6a3d  sub rsp, 0x08
000070bab59d6a41  push rax
000070bab59d6a42  push rcx
000070bab59d6a43  push rdx
000070bab59d6a44  push rdi
000070bab59d6a45  push rsi
000070bab59d6a46  push r8
000070bab59d6a48  push r9
000070bab59d6a4a  push r10
000070bab59d6a4c  push r11
000070bab59d6a4e  sub rsp, 0xF0
000070bab59d6a55  vmovaps [rsp], xmm0
000070bab59d6a5a  vmovaps [rsp+0x10], xmm1
000070bab59d6a60  vmovaps [rsp+0x20], xmm2
000070bab59d6a66  vmovaps [rsp+0x30], xmm3
000070bab59d6a6c  vmovaps [rsp+0x40], xmm4
000070bab59d6a72  vmovaps [rsp+0x50], xmm5
000070bab59d6a78  vmovaps [rsp+0x60], xmm6
000070bab59d6a7e  vmovaps [rsp+0x70], xmm7
000070bab59d6a84  vmovaps [rsp+0x80], xmm8
000070bab59d6a8d  vmovaps [rsp+0x90], xmm10
000070bab59d6a96  vmovaps [rsp+0xA0], xmm11
000070bab59d6a9f  vmovaps [rsp+0xB0], xmm12
000070bab59d6aa8  vmovaps [rsp+0xC0], xmm13
000070bab59d6ab1  vmovaps [rsp+0xD0], xmm14
000070bab59d6aba  vmovaps [rsp+0xE0], xmm15
000070bab59d6ac3  sub rsp, 0x30
000070bab59d6ac7  movaps [rsp], xmm9
000070bab59d6acc  movaps [rsp+0x10], xmm12
000070bab59d6ad2  movaps [rsp+0x20], xmm10
000070bab59d6ad8  lea rdi, [rsp]
000070bab59d6adc  mov esi, 0x00
000070bab59d6ae1  mov rax, 0x63B35AFBC530
000070bab59d6aeb  call rax
000070bab59d6aed  movaps xmm9, [rsp]
000070bab59d6af2  add rsp, 0x30
000070bab59d6af6  vmovaps xmm0, [rsp]
000070bab59d6afb  vmovaps xmm1, [rsp+0x10]
000070bab59d6b01  vmovaps xmm2, [rsp+0x20]
000070bab59d6b07  vmovaps xmm3, [rsp+0x30]
000070bab59d6b0d  vmovaps xmm4, [rsp+0x40]
000070bab59d6b13  vmovaps xmm5, [rsp+0x50]
000070bab59d6b19  vmovaps xmm6, [rsp+0x60]
000070bab59d6b1f  vmovaps xmm7, [rsp+0x70]
000070bab59d6b25  vmovaps xmm8, [rsp+0x80]
000070bab59d6b2e  vmovaps xmm10, [rsp+0x90]
000070bab59d6b37  vmovaps xmm11, [rsp+0xA0]
000070bab59d6b40  vmovaps xmm12, [rsp+0xB0]
000070bab59d6b49  vmovaps xmm13, [rsp+0xC0]
000070bab59d6b52  vmovaps xmm14, [rsp+0xD0]
000070bab59d6b5b  vmovaps xmm15, [rsp+0xE0]
000070bab59d6b64  add rsp, 0xF0
000070bab59d6b6b  pop r11
000070bab59d6b6d  pop r10
000070bab59d6b6f  pop r9
000070bab59d6b71  pop r8
000070bab59d6b73  pop rsi
000070bab59d6b74  pop rdi
000070bab59d6b75  pop rdx
000070bab59d6b76  pop rcx
000070bab59d6b77  pop rax
000070bab59d6b78  add rsp, 0x08
000070bab59d6b7c  jmp 0x000070BAB59D59EC
000070bab59d6b81  sub rsp, 0x08
000070bab59d6b85  push rax
000070bab59d6b86  push rcx
000070bab59d6b87  push rdx
000070bab59d6b88  push rdi
000070bab59d6b89  push rsi
000070bab59d6b8a  push r8
000070bab59d6b8c  push r9
000070bab59d6b8e  push r10
000070bab59d6b90  push r11
000070bab59d6b92  sub rsp, 0xF0
000070bab59d6b99  vmovaps [rsp], xmm0
000070bab59d6b9e  vmovaps [rsp+0x10], xmm1
000070bab59d6ba4  vmovaps [rsp+0x20], xmm2
000070bab59d6baa  vmovaps [rsp+0x30], xmm3
000070bab59d6bb0  vmovaps [rsp+0x40], xmm4
000070bab59d6bb6  vmovaps [rsp+0x50], xmm5
000070bab59d6bbc  vmovaps [rsp+0x60], xmm6
000070bab59d6bc2  vmovaps [rsp+0x70], xmm7
000070bab59d6bc8  vmovaps [rsp+0x80], xmm8
000070bab59d6bd1  vmovaps [rsp+0x90], xmm9
000070bab59d6bda  vmovaps [rsp+0xA0], xmm11
000070bab59d6be3  vmovaps [rsp+0xB0], xmm12
000070bab59d6bec  vmovaps [rsp+0xC0], xmm13
000070bab59d6bf5  vmovaps [rsp+0xD0], xmm14
000070bab59d6bfe  vmovaps [rsp+0xE0], xmm15
000070bab59d6c07  sub rsp, 0x30
000070bab59d6c0b  movaps [rsp], xmm10
000070bab59d6c10  movaps [rsp+0x10], xmm12
000070bab59d6c16  movaps [rsp+0x20], xmm11
000070bab59d6c1c  lea rdi, [rsp]
000070bab59d6c20  mov esi, 0x00
000070bab59d6c25  mov rax, 0x63B35AFBC530
000070bab59d6c2f  call rax
000070bab59d6c31  movaps xmm10, [rsp]
000070bab59d6c36  add rsp, 0x30
000070bab59d6c3a  vmovaps xmm0, [rsp]
000070bab59d6c3f  vmovaps xmm1, [rsp+0x10]
000070bab59d6c45  vmovaps xmm2, [rsp+0x20]
000070bab59d6c4b  vmovaps xmm3, [rsp+0x30]
000070bab59d6c51  vmovaps xmm4, [rsp+0x40]
000070bab59d6c57  vmovaps xmm5, [rsp+0x50]
000070bab59d6c5d  vmovaps xmm6, [rsp+0x60]
000070bab59d6c63  vmovaps xmm7, [rsp+0x70]
000070bab59d6c69  vmovaps xmm8, [rsp+0x80]
000070bab59d6c72  vmovaps xmm9, [rsp+0x90]
000070bab59d6c7b  vmovaps xmm11, [rsp+0xA0]
000070bab59d6c84  vmovaps xmm12, [rsp+0xB0]
000070bab59d6c8d  vmovaps xmm13, [rsp+0xC0]
000070bab59d6c96  vmovaps xmm14, [rsp+0xD0]
000070bab59d6c9f  vmovaps xmm15, [rsp+0xE0]
000070bab59d6ca8  add rsp, 0xF0
000070bab59d6caf  pop r11
000070bab59d6cb1  pop r10
000070bab59d6cb3  pop r9
000070bab59d6cb5  pop r8
000070bab59d6cb7  pop rsi
000070bab59d6cb8  pop rdi
000070bab59d6cb9  pop rdx
000070bab59d6cba  pop rcx
000070bab59d6cbb  pop rax
000070bab59d6cbc  add rsp, 0x08
000070bab59d6cc0  jmp 0x000070BAB59D5A06
000070bab59d6cc5  sub rsp, 0x08
000070bab59d6cc9  push rax
000070bab59d6cca  push rcx
000070bab59d6ccb  push rdx
000070bab59d6ccc  push rdi
000070bab59d6ccd  push rsi
000070bab59d6cce  push r8
000070bab59d6cd0  push r9
000070bab59d6cd2  push r10
000070bab59d6cd4  push r11
000070bab59d6cd6  sub rsp, 0xF0
000070bab59d6cdd  vmovaps [rsp], xmm0
000070bab59d6ce2  vmovaps [rsp+0x10], xmm1
000070bab59d6ce8  vmovaps [rsp+0x20], xmm2
000070bab59d6cee  vmovaps [rsp+0x30], xmm3
000070bab59d6cf4  vmovaps [rsp+0x40], xmm4
000070bab59d6cfa  vmovaps [rsp+0x50], xmm5
000070bab59d6d00  vmovaps [rsp+0x60], xmm7
000070bab59d6d06  vmovaps [rsp+0x70], xmm8
000070bab59d6d0c  vmovaps [rsp+0x80], xmm9
000070bab59d6d15  vmovaps [rsp+0x90], xmm10
000070bab59d6d1e  vmovaps [rsp+0xA0], xmm11
000070bab59d6d27  vmovaps [rsp+0xB0], xmm12
000070bab59d6d30  vmovaps [rsp+0xC0], xmm13
000070bab59d6d39  vmovaps [rsp+0xD0], xmm14
000070bab59d6d42  vmovaps [rsp+0xE0], xmm15
000070bab59d6d4b  sub rsp, 0x30
000070bab59d6d4f  movaps [rsp], xmm6
000070bab59d6d53  movaps [rsp+0x10], xmm12
000070bab59d6d59  movaps [rsp+0x20], xmm11
000070bab59d6d5f  lea rdi, [rsp]
000070bab59d6d63  mov esi, 0x00
000070bab59d6d68  mov rax, 0x63B35AFBC530
000070bab59d6d72  call rax
000070bab59d6d74  movaps xmm6, [rsp]
000070bab59d6d78  add rsp, 0x30
000070bab59d6d7c  vmovaps xmm0, [rsp]
000070bab59d6d81  vmovaps xmm1, [rsp+0x10]
000070bab59d6d87  vmovaps xmm2, [rsp+0x20]
000070bab59d6d8d  vmovaps xmm3, [rsp+0x30]
000070bab59d6d93  vmovaps xmm4, [rsp+0x40]
000070bab59d6d99  vmovaps xmm5, [rsp+0x50]
000070bab59d6d9f  vmovaps xmm7, [rsp+0x60]
000070bab59d6da5  vmovaps xmm8, [rsp+0x70]
000070bab59d6dab  vmovaps xmm9, [rsp+0x80]
000070bab59d6db4  vmovaps xmm10, [rsp+0x90]
000070bab59d6dbd  vmovaps xmm11, [rsp+0xA0]
000070bab59d6dc6  vmovaps xmm12, [rsp+0xB0]
000070bab59d6dcf  vmovaps xmm13, [rsp+0xC0]
000070bab59d6dd8  vmovaps xmm14, [rsp+0xD0]
000070bab59d6de1  vmovaps xmm15, [rsp+0xE0]
000070bab59d6dea  add rsp, 0xF0
000070bab59d6df1  pop r11
000070bab59d6df3  pop r10
000070bab59d6df5  pop r9
000070bab59d6df7  pop r8
000070bab59d6df9  pop rsi
000070bab59d6dfa  pop rdi
000070bab59d6dfb  pop rdx
000070bab59d6dfc  pop rcx
000070bab59d6dfd  pop rax
000070bab59d6dfe  add rsp, 0x08
000070bab59d6e02  jmp 0x000070BAB59D5A27
000070bab59d6e07  sub rsp, 0x08
000070bab59d6e0b  push rax
000070bab59d6e0c  push rcx
000070bab59d6e0d  push rdx
000070bab59d6e0e  push rdi
000070bab59d6e0f  push rsi
000070bab59d6e10  push r8
000070bab59d6e12  push r9
000070bab59d6e14  push r10
000070bab59d6e16  push r11
000070bab59d6e18  sub rsp, 0xF0
000070bab59d6e1f  vmovaps [rsp], xmm0
000070bab59d6e24  vmovaps [rsp+0x10], xmm1
000070bab59d6e2a  vmovaps [rsp+0x20], xmm2
000070bab59d6e30  vmovaps [rsp+0x30], xmm4
000070bab59d6e36  vmovaps [rsp+0x40], xmm5
000070bab59d6e3c  vmovaps [rsp+0x50], xmm6
000070bab59d6e42  vmovaps [rsp+0x60], xmm7
000070bab59d6e48  vmovaps [rsp+0x70], xmm8
000070bab59d6e4e  vmovaps [rsp+0x80], xmm9
000070bab59d6e57  vmovaps [rsp+0x90], xmm10
000070bab59d6e60  vmovaps [rsp+0xA0], xmm11
000070bab59d6e69  vmovaps [rsp+0xB0], xmm12
000070bab59d6e72  vmovaps [rsp+0xC0], xmm13
000070bab59d6e7b  vmovaps [rsp+0xD0], xmm14
000070bab59d6e84  vmovaps [rsp+0xE0], xmm15
000070bab59d6e8d  sub rsp, 0x30
000070bab59d6e91  movaps [rsp], xmm3
000070bab59d6e95  movaps [rsp+0x10], xmm5
000070bab59d6e9a  movaps [rsp+0x20], xmm4
000070bab59d6e9f  lea rdi, [rsp]
000070bab59d6ea3  mov esi, 0x00
000070bab59d6ea8  mov rax, 0x63B35AFBC530
000070bab59d6eb2  call rax
000070bab59d6eb4  movaps xmm3, [rsp]
000070bab59d6eb8  add rsp, 0x30
000070bab59d6ebc  vmovaps xmm0, [rsp]
000070bab59d6ec1  vmovaps xmm1, [rsp+0x10]
000070bab59d6ec7  vmovaps xmm2, [rsp+0x20]
000070bab59d6ecd  vmovaps xmm4, [rsp+0x30]
000070bab59d6ed3  vmovaps xmm5, [rsp+0x40]
000070bab59d6ed9  vmovaps xmm6, [rsp+0x50]
000070bab59d6edf  vmovaps xmm7, [rsp+0x60]
000070bab59d6ee5  vmovaps xmm8, [rsp+0x70]
000070bab59d6eeb  vmovaps xmm9, [rsp+0x80]
000070bab59d6ef4  vmovaps xmm10, [rsp+0x90]
000070bab59d6efd  vmovaps xmm11, [rsp+0xA0]
000070bab59d6f06  vmovaps xmm12, [rsp+0xB0]
000070bab59d6f0f  vmovaps xmm13, [rsp+0xC0]
000070bab59d6f18  vmovaps xmm14, [rsp+0xD0]
000070bab59d6f21  vmovaps xmm15, [rsp+0xE0]
000070bab59d6f2a  add rsp, 0xF0
000070bab59d6f31  pop r11
000070bab59d6f33  pop r10
000070bab59d6f35  pop r9
000070bab59d6f37  pop r8
000070bab59d6f39  pop rsi
000070bab59d6f3a  pop rdi
000070bab59d6f3b  pop rdx
000070bab59d6f3c  pop rcx
000070bab59d6f3d  pop rax
000070bab59d6f3e  add rsp, 0x08
000070bab59d6f42  jmp 0x000070BAB59D5A88
000070bab59d6f47  sub rsp, 0x08
000070bab59d6f4b  push rax
000070bab59d6f4c  push rcx
000070bab59d6f4d  push rdx
000070bab59d6f4e  push rdi
000070bab59d6f4f  push rsi
000070bab59d6f50  push r8
000070bab59d6f52  push r9
000070bab59d6f54  push r10
000070bab59d6f56  push r11
000070bab59d6f58  sub rsp, 0xF0
000070bab59d6f5f  vmovaps [rsp], xmm0
000070bab59d6f64  vmovaps [rsp+0x10], xmm1
000070bab59d6f6a  vmovaps [rsp+0x20], xmm2
000070bab59d6f70  vmovaps [rsp+0x30], xmm3
000070bab59d6f76  vmovaps [rsp+0x40], xmm4
000070bab59d6f7c  vmovaps [rsp+0x50], xmm6
000070bab59d6f82  vmovaps [rsp+0x60], xmm7
000070bab59d6f88  vmovaps [rsp+0x70], xmm8
000070bab59d6f8e  vmovaps [rsp+0x80], xmm9
000070bab59d6f97  vmovaps [rsp+0x90], xmm10
000070bab59d6fa0  vmovaps [rsp+0xA0], xmm11
000070bab59d6fa9  vmovaps [rsp+0xB0], xmm12
000070bab59d6fb2  vmovaps [rsp+0xC0], xmm13
000070bab59d6fbb  vmovaps [rsp+0xD0], xmm14
000070bab59d6fc4  vmovaps [rsp+0xE0], xmm15
000070bab59d6fcd  sub rsp, 0x30
000070bab59d6fd1  movaps [rsp], xmm5
000070bab59d6fd5  movaps [rsp+0x10], xmm8
000070bab59d6fdb  movaps [rsp+0x20], xmm15
000070bab59d6fe1  lea rdi, [rsp]
000070bab59d6fe5  mov esi, 0x00
000070bab59d6fea  mov rax, 0x63B35AFBC530
000070bab59d6ff4  call rax
000070bab59d6ff6  movaps xmm5, [rsp]
000070bab59d6ffa  add rsp, 0x30
000070bab59d6ffe  vmovaps xmm0, [rsp]
000070bab59d7003  vmovaps xmm1, [rsp+0x10]
000070bab59d7009  vmovaps xmm2, [rsp+0x20]
000070bab59d700f  vmovaps xmm3, [rsp+0x30]
000070bab59d7015  vmovaps xmm4, [rsp+0x40]
000070bab59d701b  vmovaps xmm6, [rsp+0x50]
000070bab59d7021  vmovaps xmm7, [rsp+0x60]
000070bab59d7027  vmovaps xmm8, [rsp+0x70]
000070bab59d702d  vmovaps xmm9, [rsp+0x80]
000070bab59d7036  vmovaps xmm10, [rsp+0x90]
000070bab59d703f  vmovaps xmm11, [rsp+0xA0]
000070bab59d7048  vmovaps xmm12, [rsp+0xB0]
000070bab59d7051  vmovaps xmm13, [rsp+0xC0]
000070bab59d705a  vmovaps xmm14, [rsp+0xD0]
000070bab59d7063  vmovaps xmm15, [rsp+0xE0]
000070bab59d706c  add rsp, 0xF0
000070bab59d7073  pop r11
000070bab59d7075  pop r10
000070bab59d7077  pop r9
000070bab59d7079  pop r8
000070bab59d707b  pop rsi
000070bab59d707c  pop rdi
000070bab59d707d  pop rdx
000070bab59d707e  pop rcx
000070bab59d707f  pop rax
000070bab59d7080  add rsp, 0x08
000070bab59d7084  jmp 0x000070BAB59D5AC0
000070bab59d7089  sub rsp, 0x08
000070bab59d708d  push rax
000070bab59d708e  push rcx
000070bab59d708f  push rdx
000070bab59d7090  push rdi
000070bab59d7091  push rsi
000070bab59d7092  push r8
000070bab59d7094  push r9
000070bab59d7096  push r10
000070bab59d7098  push r11
000070bab59d709a  sub rsp, 0xF0
000070bab59d70a1  vmovaps [rsp], xmm0
000070bab59d70a6  vmovaps [rsp+0x10], xmm1
000070bab59d70ac  vmovaps [rsp+0x20], xmm2
000070bab59d70b2  vmovaps [rsp+0x30], xmm3
000070bab59d70b8  vmovaps [rsp+0x40], xmm5
000070bab59d70be  vmovaps [rsp+0x50], xmm6
000070bab59d70c4  vmovaps [rsp+0x60], xmm7
000070bab59d70ca  vmovaps [rsp+0x70], xmm8
000070bab59d70d0  vmovaps [rsp+0x80], xmm9
000070bab59d70d9  vmovaps [rsp+0x90], xmm10
000070bab59d70e2  vmovaps [rsp+0xA0], xmm11
000070bab59d70eb  vmovaps [rsp+0xB0], xmm12
000070bab59d70f4  vmovaps [rsp+0xC0], xmm13
000070bab59d70fd  vmovaps [rsp+0xD0], xmm14
000070bab59d7106  vmovaps [rsp+0xE0], xmm15
000070bab59d710f  sub rsp, 0x30
000070bab59d7113  movaps [rsp], xmm4
000070bab59d7117  movaps [rsp+0x10], xmm9
000070bab59d711d  movaps [rsp+0x20], xmm8
000070bab59d7123  lea rdi, [rsp]
000070bab59d7127  mov esi, 0x00
000070bab59d712c  mov rax, 0x63B35AFBC530
000070bab59d7136  call rax
000070bab59d7138  movaps xmm4, [rsp]
000070bab59d713c  add rsp, 0x30
000070bab59d7140  vmovaps xmm0, [rsp]
000070bab59d7145  vmovaps xmm1, [rsp+0x10]
000070bab59d714b  vmovaps xmm2, [rsp+0x20]
000070bab59d7151  vmovaps xmm3, [rsp+0x30]
000070bab59d7157  vmovaps xmm5, [rsp+0x40]
000070bab59d715d  vmovaps xmm6, [rsp+0x50]
000070bab59d7163  vmovaps xmm7, [rsp+0x60]
000070bab59d7169  vmovaps xmm8, [rsp+0x70]
000070bab59d716f  vmovaps xmm9, [rsp+0x80]
000070bab59d7178  vmovaps xmm10, [rsp+0x90]
000070bab59d7181  vmovaps xmm11, [rsp+0xA0]
000070bab59d718a  vmovaps xmm12, [rsp+0xB0]
000070bab59d7193  vmovaps xmm13, [rsp+0xC0]
000070bab59d719c  vmovaps xmm14, [rsp+0xD0]
000070bab59d71a5  vmovaps xmm15, [rsp+0xE0]
000070bab59d71ae  add rsp, 0xF0
000070bab59d71b5  pop r11
000070bab59d71b7  pop r10
000070bab59d71b9  pop r9
000070bab59d71bb  pop r8
000070bab59d71bd  pop rsi
000070bab59d71be  pop rdi
000070bab59d71bf  pop rdx
000070bab59d71c0  pop rcx
000070bab59d71c1  pop rax
000070bab59d71c2  add rsp, 0x08
000070bab59d71c6  jmp 0x000070BAB59D5AE1
000070bab59d71cb  sub rsp, 0x08
000070bab59d71cf  push rax
000070bab59d71d0  push rcx
000070bab59d71d1  push rdx
000070bab59d71d2  push rdi
000070bab59d71d3  push rsi
000070bab59d71d4  push r8
000070bab59d71d6  push r9
000070bab59d71d8  push r10
000070bab59d71da  push r11
000070bab59d71dc  sub rsp, 0xF0
000070bab59d71e3  vmovaps [rsp], xmm0
000070bab59d71e8  vmovaps [rsp+0x10], xmm1
000070bab59d71ee  vmovaps [rsp+0x20], xmm2
000070bab59d71f4  vmovaps [rsp+0x30], xmm3
000070bab59d71fa  vmovaps [rsp+0x40], xmm4
000070bab59d7200  vmovaps [rsp+0x50], xmm5
000070bab59d7206  vmovaps [rsp+0x60], xmm6
000070bab59d720c  vmovaps [rsp+0x70], xmm7
000070bab59d7212  vmovaps [rsp+0x80], xmm8
000070bab59d721b  vmovaps [rsp+0x90], xmm10
000070bab59d7224  vmovaps [rsp+0xA0], xmm11
000070bab59d722d  vmovaps [rsp+0xB0], xmm12
000070bab59d7236  vmovaps [rsp+0xC0], xmm13
000070bab59d723f  vmovaps [rsp+0xD0], xmm14
000070bab59d7248  vmovaps [rsp+0xE0], xmm15
000070bab59d7251  sub rsp, 0x30
000070bab59d7255  movaps [rsp], xmm9
000070bab59d725a  movaps [rsp+0x10], xmm10
000070bab59d7260  movaps [rsp+0x20], xmm8
000070bab59d7266  lea rdi, [rsp]
000070bab59d726a  mov esi, 0x00
000070bab59d726f  mov rax, 0x63B35AFBC530
000070bab59d7279  call rax
000070bab59d727b  movaps xmm9, [rsp]
000070bab59d7280  add rsp, 0x30
000070bab59d7284  vmovaps xmm0, [rsp]
000070bab59d7289  vmovaps xmm1, [rsp+0x10]
000070bab59d728f  vmovaps xmm2, [rsp+0x20]
000070bab59d7295  vmovaps xmm3, [rsp+0x30]
000070bab59d729b  vmovaps xmm4, [rsp+0x40]
000070bab59d72a1  vmovaps xmm5, [rsp+0x50]
000070bab59d72a7  vmovaps xmm6, [rsp+0x60]
000070bab59d72ad  vmovaps xmm7, [rsp+0x70]
000070bab59d72b3  vmovaps xmm8, [rsp+0x80]
000070bab59d72bc  vmovaps xmm10, [rsp+0x90]
000070bab59d72c5  vmovaps xmm11, [rsp+0xA0]
000070bab59d72ce  vmovaps xmm12, [rsp+0xB0]
000070bab59d72d7  vmovaps xmm13, [rsp+0xC0]
000070bab59d72e0  vmovaps xmm14, [rsp+0xD0]
000070bab59d72e9  vmovaps xmm15, [rsp+0xE0]
000070bab59d72f2  add rsp, 0xF0
000070bab59d72f9  pop r11
000070bab59d72fb  pop r10
000070bab59d72fd  pop r9
000070bab59d72ff  pop r8
000070bab59d7301  pop rsi
000070bab59d7302  pop rdi
000070bab59d7303  pop rdx
000070bab59d7304  pop rcx
000070bab59d7305  pop rax
000070bab59d7306  add rsp, 0x08
000070bab59d730a  jmp 0x000070BAB59D5AFB
000070bab59d730f  call 0x000070BAB58D64F0
000070bab59d7314  jmp 0x000070BAB59D5C15
000070bab59d7319  call 0x000070BAB58D64F0
000070bab59d731e  jmp 0x000070BAB59D5C2B
000070bab59d7323  sub rsp, 0x08
000070bab59d7327  push rax
000070bab59d7328  push rcx
000070bab59d7329  push rdx
000070bab59d732a  push rdi
000070bab59d732b  push rsi
000070bab59d732c  push r8
000070bab59d732e  push r9
000070bab59d7330  push r10
000070bab59d7332  push r11
000070bab59d7334  sub rsp, 0xF0
000070bab59d733b  vmovaps [rsp], xmm0
000070bab59d7340  vmovaps [rsp+0x10], xmm2
000070bab59d7346  vmovaps [rsp+0x20], xmm3
000070bab59d734c  vmovaps [rsp+0x30], xmm4
000070bab59d7352  vmovaps [rsp+0x40], xmm5
000070bab59d7358  vmovaps [rsp+0x50], xmm6
000070bab59d735e  vmovaps [rsp+0x60], xmm7
000070bab59d7364  vmovaps [rsp+0x70], xmm8
000070bab59d736a  vmovaps [rsp+0x80], xmm9
000070bab59d7373  vmovaps [rsp+0x90], xmm10
000070bab59d737c  vmovaps [rsp+0xA0], xmm11
000070bab59d7385  vmovaps [rsp+0xB0], xmm12
000070bab59d738e  vmovaps [rsp+0xC0], xmm13
000070bab59d7397  vmovaps [rsp+0xD0], xmm14
000070bab59d73a0  vmovaps [rsp+0xE0], xmm15
000070bab59d73a9  sub rsp, 0x30
000070bab59d73ad  movaps [rsp], xmm1
000070bab59d73b1  movaps [rsp+0x10], xmm6
000070bab59d73b6  movaps [rsp+0x20], xmm15
000070bab59d73bc  lea rdi, [rsp]
000070bab59d73c0  mov esi, 0x00
000070bab59d73c5  mov rax, 0x63B35AFBC530
000070bab59d73cf  call rax
000070bab59d73d1  movaps xmm1, [rsp]
000070bab59d73d5  add rsp, 0x30
000070bab59d73d9  vmovaps xmm0, [rsp]
000070bab59d73de  vmovaps xmm2, [rsp+0x10]
000070bab59d73e4  vmovaps xmm3, [rsp+0x20]
000070bab59d73ea  vmovaps xmm4, [rsp+0x30]
000070bab59d73f0  vmovaps xmm5, [rsp+0x40]
000070bab59d73f6  vmovaps xmm6, [rsp+0x50]
000070bab59d73fc  vmovaps xmm7, [rsp+0x60]
000070bab59d7402  vmovaps xmm8, [rsp+0x70]
000070bab59d7408  vmovaps xmm9, [rsp+0x80]
000070bab59d7411  vmovaps xmm10, [rsp+0x90]
000070bab59d741a  vmovaps xmm11, [rsp+0xA0]
000070bab59d7423  vmovaps xmm12, [rsp+0xB0]
000070bab59d742c  vmovaps xmm13, [rsp+0xC0]
000070bab59d7435  vmovaps xmm14, [rsp+0xD0]
000070bab59d743e  vmovaps xmm15, [rsp+0xE0]
000070bab59d7447  add rsp, 0xF0
000070bab59d744e  pop r11
000070bab59d7450  pop r10
000070bab59d7452  pop r9
000070bab59d7454  pop r8
000070bab59d7456  pop rsi
000070bab59d7457  pop rdi
000070bab59d7458  pop rdx
000070bab59d7459  pop rcx
000070bab59d745a  pop rax
000070bab59d745b  add rsp, 0x08
000070bab59d745f  jmp 0x000070BAB59D5C68
000070bab59d7464  call 0x000070BAB58E5820
000070bab59d7469  jmp 0x000070BAB59D5C75
000070bab59d746e  sub rsp, 0x08
000070bab59d7472  push rax
000070bab59d7473  push rcx
000070bab59d7474  push rdx
000070bab59d7475  push rdi
000070bab59d7476  push rsi
000070bab59d7477  push r8
000070bab59d7479  push r9
000070bab59d747b  push r10
000070bab59d747d  push r11
000070bab59d747f  sub rsp, 0xF0
000070bab59d7486  vmovaps [rsp], xmm0
000070bab59d748b  vmovaps [rsp+0x10], xmm1
000070bab59d7491  vmovaps [rsp+0x20], xmm2
000070bab59d7497  vmovaps [rsp+0x30], xmm3
000070bab59d749d  vmovaps [rsp+0x40], xmm4
000070bab59d74a3  vmovaps [rsp+0x50], xmm5
000070bab59d74a9  vmovaps [rsp+0x60], xmm6
000070bab59d74af  vmovaps [rsp+0x70], xmm7
000070bab59d74b5  vmovaps [rsp+0x80], xmm8
000070bab59d74be  vmovaps [rsp+0x90], xmm9
000070bab59d74c7  vmovaps [rsp+0xA0], xmm10
000070bab59d74d0  vmovaps [rsp+0xB0], xmm11
000070bab59d74d9  vmovaps [rsp+0xC0], xmm12
000070bab59d74e2  vmovaps [rsp+0xD0], xmm13
000070bab59d74eb  vmovaps [rsp+0xE0], xmm15
000070bab59d74f4  sub rsp, 0x30
000070bab59d74f8  movaps [rsp], xmm14
000070bab59d74fd  movaps [rsp+0x10], xmm4
000070bab59d7502  movaps [rsp+0x20], xmm3
000070bab59d7507  lea rdi, [rsp]
000070bab59d750b  mov esi, 0x00
000070bab59d7510  mov rax, 0x63B35AFBC530
000070bab59d751a  call rax
000070bab59d751c  movaps xmm14, [rsp]
000070bab59d7521  add rsp, 0x30
000070bab59d7525  vmovaps xmm0, [rsp]
000070bab59d752a  vmovaps xmm1, [rsp+0x10]
000070bab59d7530  vmovaps xmm2, [rsp+0x20]
000070bab59d7536  vmovaps xmm3, [rsp+0x30]
000070bab59d753c  vmovaps xmm4, [rsp+0x40]
000070bab59d7542  vmovaps xmm5, [rsp+0x50]
000070bab59d7548  vmovaps xmm6, [rsp+0x60]
000070bab59d754e  vmovaps xmm7, [rsp+0x70]
000070bab59d7554  vmovaps xmm8, [rsp+0x80]
000070bab59d755d  vmovaps xmm9, [rsp+0x90]
000070bab59d7566  vmovaps xmm10, [rsp+0xA0]
000070bab59d756f  vmovaps xmm11, [rsp+0xB0]
000070bab59d7578  vmovaps xmm12, [rsp+0xC0]
000070bab59d7581  vmovaps xmm13, [rsp+0xD0]
000070bab59d758a  vmovaps xmm15, [rsp+0xE0]
000070bab59d7593  add rsp, 0xF0
000070bab59d759a  pop r11
000070bab59d759c  pop r10
000070bab59d759e  pop r9
000070bab59d75a0  pop r8
000070bab59d75a2  pop rsi
000070bab59d75a3  pop rdi
000070bab59d75a4  pop rdx
000070bab59d75a5  pop rcx
000070bab59d75a6  pop rax
000070bab59d75a7  add rsp, 0x08
000070bab59d75ab  jmp 0x000070BAB59D5C8F
000070bab59d75b0  sub rsp, 0x08
000070bab59d75b4  push rax
000070bab59d75b5  push rcx
000070bab59d75b6  push rdx
000070bab59d75b7  push rdi
000070bab59d75b8  push rsi
000070bab59d75b9  push r8
000070bab59d75bb  push r9
000070bab59d75bd  push r10
000070bab59d75bf  push r11
000070bab59d75c1  sub rsp, 0xF0
000070bab59d75c8  vmovaps [rsp], xmm0
000070bab59d75cd  vmovaps [rsp+0x10], xmm1
000070bab59d75d3  vmovaps [rsp+0x20], xmm2
000070bab59d75d9  vmovaps [rsp+0x30], xmm3
000070bab59d75df  vmovaps [rsp+0x40], xmm4
000070bab59d75e5  vmovaps [rsp+0x50], xmm5
000070bab59d75eb  vmovaps [rsp+0x60], xmm7
000070bab59d75f1  vmovaps [rsp+0x70], xmm8
000070bab59d75f7  vmovaps [rsp+0x80], xmm9
000070bab59d7600  vmovaps [rsp+0x90], xmm10
000070bab59d7609  vmovaps [rsp+0xA0], xmm11
000070bab59d7612  vmovaps [rsp+0xB0], xmm12
000070bab59d761b  vmovaps [rsp+0xC0], xmm13
000070bab59d7624  vmovaps [rsp+0xD0], xmm14
000070bab59d762d  vmovaps [rsp+0xE0], xmm15
000070bab59d7636  sub rsp, 0x30
000070bab59d763a  movaps [rsp], xmm6
000070bab59d763e  movaps [rsp+0x10], xmm9
000070bab59d7644  movaps [rsp+0x20], xmm7
000070bab59d7649  lea rdi, [rsp]
000070bab59d764d  mov esi, 0x00
000070bab59d7652  mov rax, 0x63B35AFBC530
000070bab59d765c  call rax
000070bab59d765e  movaps xmm6, [rsp]
000070bab59d7662  add rsp, 0x30
000070bab59d7666  vmovaps xmm0, [rsp]
000070bab59d766b  vmovaps xmm1, [rsp+0x10]
000070bab59d7671  vmovaps xmm2, [rsp+0x20]
000070bab59d7677  vmovaps xmm3, [rsp+0x30]
000070bab59d767d  vmovaps xmm4, [rsp+0x40]
000070bab59d7683  vmovaps xmm5, [rsp+0x50]
000070bab59d7689  vmovaps xmm7, [rsp+0x60]
000070bab59d768f  vmovaps xmm8, [rsp+0x70]
000070bab59d7695  vmovaps xmm9, [rsp+0x80]
000070bab59d769e  vmovaps xmm10, [rsp+0x90]
000070bab59d76a7  vmovaps xmm11, [rsp+0xA0]
000070bab59d76b0  vmovaps xmm12, [rsp+0xB0]
000070bab59d76b9  vmovaps xmm13, [rsp+0xC0]
000070bab59d76c2  vmovaps xmm14, [rsp+0xD0]
000070bab59d76cb  vmovaps xmm15, [rsp+0xE0]
000070bab59d76d4  add rsp, 0xF0
000070bab59d76db  pop r11
000070bab59d76dd  pop r10
000070bab59d76df  pop r9
000070bab59d76e1  pop r8
000070bab59d76e3  pop rsi
000070bab59d76e4  pop rdi
000070bab59d76e5  pop rdx
000070bab59d76e6  pop rcx
000070bab59d76e7  pop rax
000070bab59d76e8  add rsp, 0x08
000070bab59d76ec  jmp 0x000070BAB59D5CA7
000070bab59d76f1  sub rsp, 0x08
000070bab59d76f5  push rax
000070bab59d76f6  push rcx
000070bab59d76f7  push rdx
000070bab59d76f8  push rdi
000070bab59d76f9  push rsi
000070bab59d76fa  push r8
000070bab59d76fc  push r9
000070bab59d76fe  push r10
000070bab59d7700  push r11
000070bab59d7702  sub rsp, 0xF0
000070bab59d7709  vmovaps [rsp], xmm0
000070bab59d770e  vmovaps [rsp+0x10], xmm1
000070bab59d7714  vmovaps [rsp+0x20], xmm2
000070bab59d771a  vmovaps [rsp+0x30], xmm3
000070bab59d7720  vmovaps [rsp+0x40], xmm4
000070bab59d7726  vmovaps [rsp+0x50], xmm5
000070bab59d772c  vmovaps [rsp+0x60], xmm6
000070bab59d7732  vmovaps [rsp+0x70], xmm8
000070bab59d7738  vmovaps [rsp+0x80], xmm9
000070bab59d7741  vmovaps [rsp+0x90], xmm10
000070bab59d774a  vmovaps [rsp+0xA0], xmm11
000070bab59d7753  vmovaps [rsp+0xB0], xmm12
000070bab59d775c  vmovaps [rsp+0xC0], xmm13
000070bab59d7765  vmovaps [rsp+0xD0], xmm14
000070bab59d776e  vmovaps [rsp+0xE0], xmm15
000070bab59d7777  sub rsp, 0x30
000070bab59d777b  movaps [rsp], xmm7
000070bab59d777f  movaps [rsp+0x10], xmm4
000070bab59d7784  movaps [rsp+0x20], xmm9
000070bab59d778a  lea rdi, [rsp]
000070bab59d778e  mov esi, 0x00
000070bab59d7793  mov rax, 0x63B35AFBC530
000070bab59d779d  call rax
000070bab59d779f  movaps xmm7, [rsp]
000070bab59d77a3  add rsp, 0x30
000070bab59d77a7  vmovaps xmm0, [rsp]
000070bab59d77ac  vmovaps xmm1, [rsp+0x10]
000070bab59d77b2  vmovaps xmm2, [rsp+0x20]
000070bab59d77b8  vmovaps xmm3, [rsp+0x30]
000070bab59d77be  vmovaps xmm4, [rsp+0x40]
000070bab59d77c4  vmovaps xmm5, [rsp+0x50]
000070bab59d77ca  vmovaps xmm6, [rsp+0x60]
000070bab59d77d0  vmovaps xmm8, [rsp+0x70]
000070bab59d77d6  vmovaps xmm9, [rsp+0x80]
000070bab59d77df  vmovaps xmm10, [rsp+0x90]
000070bab59d77e8  vmovaps xmm11, [rsp+0xA0]
000070bab59d77f1  vmovaps xmm12, [rsp+0xB0]
000070bab59d77fa  vmovaps xmm13, [rsp+0xC0]
000070bab59d7803  vmovaps xmm14, [rsp+0xD0]
000070bab59d780c  vmovaps xmm15, [rsp+0xE0]
000070bab59d7815  add rsp, 0xF0
000070bab59d781c  pop r11
000070bab59d781e  pop r10
000070bab59d7820  pop r9
000070bab59d7822  pop r8
000070bab59d7824  pop rsi
000070bab59d7825  pop rdi
000070bab59d7826  pop rdx
000070bab59d7827  pop rcx
000070bab59d7828  pop rax
000070bab59d7829  add rsp, 0x08
000070bab59d782d  jmp 0x000070BAB59D5CD4
000070bab59d7832  sub rsp, 0x08
000070bab59d7836  push rax
000070bab59d7837  push rcx
000070bab59d7838  push rdx
000070bab59d7839  push rdi
000070bab59d783a  push rsi
000070bab59d783b  push r8
000070bab59d783d  push r9
000070bab59d783f  push r10
000070bab59d7841  push r11
000070bab59d7843  sub rsp, 0xF0
000070bab59d784a  vmovaps [rsp], xmm0
000070bab59d784f  vmovaps [rsp+0x10], xmm1
000070bab59d7855  vmovaps [rsp+0x20], xmm2
000070bab59d785b  vmovaps [rsp+0x30], xmm3
000070bab59d7861  vmovaps [rsp+0x40], xmm5
000070bab59d7867  vmovaps [rsp+0x50], xmm6
000070bab59d786d  vmovaps [rsp+0x60], xmm7
000070bab59d7873  vmovaps [rsp+0x70], xmm8
000070bab59d7879  vmovaps [rsp+0x80], xmm9
000070bab59d7882  vmovaps [rsp+0x90], xmm10
000070bab59d788b  vmovaps [rsp+0xA0], xmm11
000070bab59d7894  vmovaps [rsp+0xB0], xmm12
000070bab59d789d  vmovaps [rsp+0xC0], xmm13
000070bab59d78a6  vmovaps [rsp+0xD0], xmm14
000070bab59d78af  vmovaps [rsp+0xE0], xmm15
000070bab59d78b8  sub rsp, 0x30
000070bab59d78bc  movaps [rsp], xmm4
000070bab59d78c0  movaps [rsp+0x10], xmm15
000070bab59d78c6  movaps [rsp+0x20], xmm9
000070bab59d78cc  lea rdi, [rsp]
000070bab59d78d0  mov esi, 0x00
000070bab59d78d5  mov rax, 0x63B35AFBC530
000070bab59d78df  call rax
000070bab59d78e1  movaps xmm4, [rsp]
000070bab59d78e5  add rsp, 0x30
000070bab59d78e9  vmovaps xmm0, [rsp]
000070bab59d78ee  vmovaps xmm1, [rsp+0x10]
000070bab59d78f4  vmovaps xmm2, [rsp+0x20]
000070bab59d78fa  vmovaps xmm3, [rsp+0x30]
000070bab59d7900  vmovaps xmm5, [rsp+0x40]
000070bab59d7906  vmovaps xmm6, [rsp+0x50]
000070bab59d790c  vmovaps xmm7, [rsp+0x60]
000070bab59d7912  vmovaps xmm8, [rsp+0x70]
000070bab59d7918  vmovaps xmm9, [rsp+0x80]
000070bab59d7921  vmovaps xmm10, [rsp+0x90]
000070bab59d792a  vmovaps xmm11, [rsp+0xA0]
000070bab59d7933  vmovaps xmm12, [rsp+0xB0]
000070bab59d793c  vmovaps xmm13, [rsp+0xC0]
000070bab59d7945  vmovaps xmm14, [rsp+0xD0]
000070bab59d794e  vmovaps xmm15, [rsp+0xE0]
000070bab59d7957  add rsp, 0xF0
000070bab59d795e  pop r11
000070bab59d7960  pop r10
000070bab59d7962  pop r9
000070bab59d7964  pop r8
000070bab59d7966  pop rsi
000070bab59d7967  pop rdi
000070bab59d7968  pop rdx
000070bab59d7969  pop rcx
000070bab59d796a  pop rax
000070bab59d796b  add rsp, 0x08
000070bab59d796f  jmp 0x000070BAB59D5CF9
000070bab59d7974  call 0x000070BAB58E5820
000070bab59d7979  jmp 0x000070BAB59D5D06
000070bab59d797e  sub rsp, 0x08
000070bab59d7982  push rax
000070bab59d7983  push rcx
000070bab59d7984  push rdx
000070bab59d7985  push rdi
000070bab59d7986  push rsi
000070bab59d7987  push r8
000070bab59d7989  push r9
000070bab59d798b  push r10
000070bab59d798d  push r11
000070bab59d798f  sub rsp, 0xF0
000070bab59d7996  vmovaps [rsp], xmm0
000070bab59d799b  vmovaps [rsp+0x10], xmm1
000070bab59d79a1  vmovaps [rsp+0x20], xmm2
000070bab59d79a7  vmovaps [rsp+0x30], xmm4
000070bab59d79ad  vmovaps [rsp+0x40], xmm5
000070bab59d79b3  vmovaps [rsp+0x50], xmm6
000070bab59d79b9  vmovaps [rsp+0x60], xmm7
000070bab59d79bf  vmovaps [rsp+0x70], xmm8
000070bab59d79c5  vmovaps [rsp+0x80], xmm9
000070bab59d79ce  vmovaps [rsp+0x90], xmm10
000070bab59d79d7  vmovaps [rsp+0xA0], xmm11
000070bab59d79e0  vmovaps [rsp+0xB0], xmm12
000070bab59d79e9  vmovaps [rsp+0xC0], xmm13
000070bab59d79f2  vmovaps [rsp+0xD0], xmm14
000070bab59d79fb  vmovaps [rsp+0xE0], xmm15
000070bab59d7a04  sub rsp, 0x30
000070bab59d7a08  movaps [rsp], xmm3
000070bab59d7a0c  movaps [rsp+0x10], xmm1
000070bab59d7a11  movaps [rsp+0x20], xmm9
000070bab59d7a17  lea rdi, [rsp]
000070bab59d7a1b  mov esi, 0x00
000070bab59d7a20  mov rax, 0x63B35AFBC530
000070bab59d7a2a  call rax
000070bab59d7a2c  movaps xmm3, [rsp]
000070bab59d7a30  add rsp, 0x30
000070bab59d7a34  vmovaps xmm0, [rsp]
000070bab59d7a39  vmovaps xmm1, [rsp+0x10]
000070bab59d7a3f  vmovaps xmm2, [rsp+0x20]
000070bab59d7a45  vmovaps xmm4, [rsp+0x30]
000070bab59d7a4b  vmovaps xmm5, [rsp+0x40]
000070bab59d7a51  vmovaps xmm6, [rsp+0x50]
000070bab59d7a57  vmovaps xmm7, [rsp+0x60]
000070bab59d7a5d  vmovaps xmm8, [rsp+0x70]
000070bab59d7a63  vmovaps xmm9, [rsp+0x80]
000070bab59d7a6c  vmovaps xmm10, [rsp+0x90]
000070bab59d7a75  vmovaps xmm11, [rsp+0xA0]
000070bab59d7a7e  vmovaps xmm12, [rsp+0xB0]
000070bab59d7a87  vmovaps xmm13, [rsp+0xC0]
000070bab59d7a90  vmovaps xmm14, [rsp+0xD0]
000070bab59d7a99  vmovaps xmm15, [rsp+0xE0]
000070bab59d7aa2  add rsp, 0xF0
000070bab59d7aa9  pop r11
000070bab59d7aab  pop r10
000070bab59d7aad  pop r9
000070bab59d7aaf  pop r8
000070bab59d7ab1  pop rsi
000070bab59d7ab2  pop rdi
000070bab59d7ab3  pop rdx
000070bab59d7ab4  pop rcx
000070bab59d7ab5  pop rax
000070bab59d7ab6  add rsp, 0x08
000070bab59d7aba  jmp 0x000070BAB59D5D43
000070bab59d7abf  sub rsp, 0x08
000070bab59d7ac3  push rax
000070bab59d7ac4  push rcx
000070bab59d7ac5  push rdx
000070bab59d7ac6  push rdi
000070bab59d7ac7  push rsi
000070bab59d7ac8  push r8
000070bab59d7aca  push r9
000070bab59d7acc  push r10
000070bab59d7ace  push r11
000070bab59d7ad0  sub rsp, 0xF0
000070bab59d7ad7  vmovaps [rsp], xmm0
000070bab59d7adc  vmovaps [rsp+0x10], xmm2
000070bab59d7ae2  vmovaps [rsp+0x20], xmm3
000070bab59d7ae8  vmovaps [rsp+0x30], xmm4
000070bab59d7aee  vmovaps [rsp+0x40], xmm5
000070bab59d7af4  vmovaps [rsp+0x50], xmm6
000070bab59d7afa  vmovaps [rsp+0x60], xmm7
000070bab59d7b00  vmovaps [rsp+0x70], xmm8
000070bab59d7b06  vmovaps [rsp+0x80], xmm9
000070bab59d7b0f  vmovaps [rsp+0x90], xmm10
000070bab59d7b18  vmovaps [rsp+0xA0], xmm11
000070bab59d7b21  vmovaps [rsp+0xB0], xmm12
000070bab59d7b2a  vmovaps [rsp+0xC0], xmm13
000070bab59d7b33  vmovaps [rsp+0xD0], xmm14
000070bab59d7b3c  vmovaps [rsp+0xE0], xmm15
000070bab59d7b45  sub rsp, 0x30
000070bab59d7b49  movaps [rsp], xmm1
000070bab59d7b4d  movaps [rsp+0x10], xmm15
000070bab59d7b53  movaps [rsp+0x20], xmm9
000070bab59d7b59  lea rdi, [rsp]
000070bab59d7b5d  mov esi, 0x00
000070bab59d7b62  mov rax, 0x63B35AFBC530
000070bab59d7b6c  call rax
000070bab59d7b6e  movaps xmm1, [rsp]
000070bab59d7b72  add rsp, 0x30
000070bab59d7b76  vmovaps xmm0, [rsp]
000070bab59d7b7b  vmovaps xmm2, [rsp+0x10]
000070bab59d7b81  vmovaps xmm3, [rsp+0x20]
000070bab59d7b87  vmovaps xmm4, [rsp+0x30]
000070bab59d7b8d  vmovaps xmm5, [rsp+0x40]
000070bab59d7b93  vmovaps xmm6, [rsp+0x50]
000070bab59d7b99  vmovaps xmm7, [rsp+0x60]
000070bab59d7b9f  vmovaps xmm8, [rsp+0x70]
000070bab59d7ba5  vmovaps xmm9, [rsp+0x80]
000070bab59d7bae  vmovaps xmm10, [rsp+0x90]
000070bab59d7bb7  vmovaps xmm11, [rsp+0xA0]
000070bab59d7bc0  vmovaps xmm12, [rsp+0xB0]
000070bab59d7bc9  vmovaps xmm13, [rsp+0xC0]
000070bab59d7bd2  vmovaps xmm14, [rsp+0xD0]
000070bab59d7bdb  vmovaps xmm15, [rsp+0xE0]
000070bab59d7be4  add rsp, 0xF0
000070bab59d7beb  pop r11
000070bab59d7bed  pop r10
000070bab59d7bef  pop r9
000070bab59d7bf1  pop r8
000070bab59d7bf3  pop rsi
000070bab59d7bf4  pop rdi
000070bab59d7bf5  pop rdx
000070bab59d7bf6  pop rcx
000070bab59d7bf7  pop rax
000070bab59d7bf8  add rsp, 0x08
000070bab59d7bfc  jmp 0x000070BAB59D5DCB
000070bab59d7c01  call 0x000070BAB58E5820
000070bab59d7c06  jmp 0x000070BAB59D5DD8
000070bab59d7c0b  sub rsp, 0x08
000070bab59d7c0f  push rax
000070bab59d7c10  push rcx
000070bab59d7c11  push rdx
000070bab59d7c12  push rdi
000070bab59d7c13  push rsi
000070bab59d7c14  push r8
000070bab59d7c16  push r9
000070bab59d7c18  push r10
000070bab59d7c1a  push r11
000070bab59d7c1c  sub rsp, 0xF0
000070bab59d7c23  vmovaps [rsp], xmm0
000070bab59d7c28  vmovaps [rsp+0x10], xmm2
000070bab59d7c2e  vmovaps [rsp+0x20], xmm3
000070bab59d7c34  vmovaps [rsp+0x30], xmm4
000070bab59d7c3a  vmovaps [rsp+0x40], xmm5
000070bab59d7c40  vmovaps [rsp+0x50], xmm6
000070bab59d7c46  vmovaps [rsp+0x60], xmm7
000070bab59d7c4c  vmovaps [rsp+0x70], xmm8
000070bab59d7c52  vmovaps [rsp+0x80], xmm9
000070bab59d7c5b  vmovaps [rsp+0x90], xmm10
000070bab59d7c64  vmovaps [rsp+0xA0], xmm11
000070bab59d7c6d  vmovaps [rsp+0xB0], xmm12
000070bab59d7c76  vmovaps [rsp+0xC0], xmm13
000070bab59d7c7f  vmovaps [rsp+0xD0], xmm14
000070bab59d7c88  vmovaps [rsp+0xE0], xmm15
000070bab59d7c91  sub rsp, 0x30
000070bab59d7c95  movaps [rsp], xmm1
000070bab59d7c99  movaps [rsp+0x10], xmm5
000070bab59d7c9e  movaps [rsp+0x20], xmm7
000070bab59d7ca3  lea rdi, [rsp]
000070bab59d7ca7  mov esi, 0x00
000070bab59d7cac  mov rax, 0x63B35AFBC530
000070bab59d7cb6  call rax
000070bab59d7cb8  movaps xmm1, [rsp]
000070bab59d7cbc  add rsp, 0x30
000070bab59d7cc0  vmovaps xmm0, [rsp]
000070bab59d7cc5  vmovaps xmm2, [rsp+0x10]
000070bab59d7ccb  vmovaps xmm3, [rsp+0x20]
000070bab59d7cd1  vmovaps xmm4, [rsp+0x30]
000070bab59d7cd7  vmovaps xmm5, [rsp+0x40]
000070bab59d7cdd  vmovaps xmm6, [rsp+0x50]
000070bab59d7ce3  vmovaps xmm7, [rsp+0x60]
000070bab59d7ce9  vmovaps xmm8, [rsp+0x70]
000070bab59d7cef  vmovaps xmm9, [rsp+0x80]
000070bab59d7cf8  vmovaps xmm10, [rsp+0x90]
000070bab59d7d01  vmovaps xmm11, [rsp+0xA0]
000070bab59d7d0a  vmovaps xmm12, [rsp+0xB0]
000070bab59d7d13  vmovaps xmm13, [rsp+0xC0]
000070bab59d7d1c  vmovaps xmm14, [rsp+0xD0]
000070bab59d7d25  vmovaps xmm15, [rsp+0xE0]
000070bab59d7d2e  add rsp, 0xF0
000070bab59d7d35  pop r11
000070bab59d7d37  pop r10
000070bab59d7d39  pop r9
000070bab59d7d3b  pop r8
000070bab59d7d3d  pop rsi
000070bab59d7d3e  pop rdi
000070bab59d7d3f  pop rdx
000070bab59d7d40  pop rcx
000070bab59d7d41  pop rax
000070bab59d7d42  add rsp, 0x08
000070bab59d7d46  jmp 0x000070BAB59D5E7D
000070bab59d7d4b  sub rsp, 0x08
000070bab59d7d4f  push rax
000070bab59d7d50  push rcx
000070bab59d7d51  push rdx
000070bab59d7d52  push rdi
000070bab59d7d53  push rsi
000070bab59d7d54  push r8
000070bab59d7d56  push r9
000070bab59d7d58  push r10
000070bab59d7d5a  push r11
000070bab59d7d5c  sub rsp, 0xF0
000070bab59d7d63  vmovaps [rsp], xmm0
000070bab59d7d68  vmovaps [rsp+0x10], xmm1
000070bab59d7d6e  vmovaps [rsp+0x20], xmm2
000070bab59d7d74  vmovaps [rsp+0x30], xmm3
000070bab59d7d7a  vmovaps [rsp+0x40], xmm4
000070bab59d7d80  vmovaps [rsp+0x50], xmm5
000070bab59d7d86  vmovaps [rsp+0x60], xmm6
000070bab59d7d8c  vmovaps [rsp+0x70], xmm8
000070bab59d7d92  vmovaps [rsp+0x80], xmm9
000070bab59d7d9b  vmovaps [rsp+0x90], xmm10
000070bab59d7da4  vmovaps [rsp+0xA0], xmm11
000070bab59d7dad  vmovaps [rsp+0xB0], xmm12
000070bab59d7db6  vmovaps [rsp+0xC0], xmm13
000070bab59d7dbf  vmovaps [rsp+0xD0], xmm14
000070bab59d7dc8  vmovaps [rsp+0xE0], xmm15
000070bab59d7dd1  sub rsp, 0x30
000070bab59d7dd5  movaps [rsp], xmm7
000070bab59d7dd9  movaps [rsp+0x10], xmm5
000070bab59d7dde  movaps [rsp+0x20], xmm15
000070bab59d7de4  lea rdi, [rsp]
000070bab59d7de8  mov esi, 0x00
000070bab59d7ded  mov rax, 0x63B35AFBC530
000070bab59d7df7  call rax
000070bab59d7df9  movaps xmm7, [rsp]
000070bab59d7dfd  add rsp, 0x30
000070bab59d7e01  vmovaps xmm0, [rsp]
000070bab59d7e06  vmovaps xmm1, [rsp+0x10]
000070bab59d7e0c  vmovaps xmm2, [rsp+0x20]
000070bab59d7e12  vmovaps xmm3, [rsp+0x30]
000070bab59d7e18  vmovaps xmm4, [rsp+0x40]
000070bab59d7e1e  vmovaps xmm5, [rsp+0x50]
000070bab59d7e24  vmovaps xmm6, [rsp+0x60]
000070bab59d7e2a  vmovaps xmm8, [rsp+0x70]
000070bab59d7e30  vmovaps xmm9, [rsp+0x80]
000070bab59d7e39  vmovaps xmm10, [rsp+0x90]
000070bab59d7e42  vmovaps xmm11, [rsp+0xA0]
000070bab59d7e4b  vmovaps xmm12, [rsp+0xB0]
000070bab59d7e54  vmovaps xmm13, [rsp+0xC0]
000070bab59d7e5d  vmovaps xmm14, [rsp+0xD0]
000070bab59d7e66  vmovaps xmm15, [rsp+0xE0]
000070bab59d7e6f  add rsp, 0xF0
000070bab59d7e76  pop r11
000070bab59d7e78  pop r10
000070bab59d7e7a  pop r9
000070bab59d7e7c  pop r8
000070bab59d7e7e  pop rsi
000070bab59d7e7f  pop rdi
000070bab59d7e80  pop rdx
000070bab59d7e81  pop rcx
000070bab59d7e82  pop rax
000070bab59d7e83  add rsp, 0x08
000070bab59d7e87  jmp 0x000070BAB59D5EB3
000070bab59d7e8c  call 0x000070BAB58D64F0
000070bab59d7e91  jmp 0x000070BAB59D5EC0
000070bab59d7e96  sub rsp, 0x08
000070bab59d7e9a  push rax
000070bab59d7e9b  push rcx
000070bab59d7e9c  push rdx
000070bab59d7e9d  push rdi
000070bab59d7e9e  push rsi
000070bab59d7e9f  push r8
000070bab59d7ea1  push r9
000070bab59d7ea3  push r10
000070bab59d7ea5  push r11
000070bab59d7ea7  sub rsp, 0xF0
000070bab59d7eae  vmovaps [rsp], xmm0
000070bab59d7eb3  vmovaps [rsp+0x10], xmm1
000070bab59d7eb9  vmovaps [rsp+0x20], xmm2
000070bab59d7ebf  vmovaps [rsp+0x30], xmm3
000070bab59d7ec5  vmovaps [rsp+0x40], xmm4
000070bab59d7ecb  vmovaps [rsp+0x50], xmm5
000070bab59d7ed1  vmovaps [rsp+0x60], xmm6
000070bab59d7ed7  vmovaps [rsp+0x70], xmm7
000070bab59d7edd  vmovaps [rsp+0x80], xmm8
000070bab59d7ee6  vmovaps [rsp+0x90], xmm9
000070bab59d7eef  vmovaps [rsp+0xA0], xmm10
000070bab59d7ef8  vmovaps [rsp+0xB0], xmm11
000070bab59d7f01  vmovaps [rsp+0xC0], xmm12
000070bab59d7f0a  vmovaps [rsp+0xD0], xmm13
000070bab59d7f13  vmovaps [rsp+0xE0], xmm14
000070bab59d7f1c  sub rsp, 0x30
000070bab59d7f20  movaps [rsp], xmm15
000070bab59d7f25  movaps [rsp+0x10], xmm5
000070bab59d7f2a  movaps [rsp+0x20], xmm3
000070bab59d7f2f  lea rdi, [rsp]
000070bab59d7f33  mov esi, 0x00
000070bab59d7f38  mov rax, 0x63B35AFBC530
000070bab59d7f42  call rax
000070bab59d7f44  movaps xmm15, [rsp]
000070bab59d7f49  add rsp, 0x30
000070bab59d7f4d  vmovaps xmm0, [rsp]
000070bab59d7f52  vmovaps xmm1, [rsp+0x10]
000070bab59d7f58  vmovaps xmm2, [rsp+0x20]
000070bab59d7f5e  vmovaps xmm3, [rsp+0x30]
000070bab59d7f64  vmovaps xmm4, [rsp+0x40]
000070bab59d7f6a  vmovaps xmm5, [rsp+0x50]
000070bab59d7f70  vmovaps xmm6, [rsp+0x60]
000070bab59d7f76  vmovaps xmm7, [rsp+0x70]
000070bab59d7f7c  vmovaps xmm8, [rsp+0x80]
000070bab59d7f85  vmovaps xmm9, [rsp+0x90]
000070bab59d7f8e  vmovaps xmm10, [rsp+0xA0]
000070bab59d7f97  vmovaps xmm11, [rsp+0xB0]
000070bab59d7fa0  vmovaps xmm12, [rsp+0xC0]
000070bab59d7fa9  vmovaps xmm13, [rsp+0xD0]
000070bab59d7fb2  vmovaps xmm14, [rsp+0xE0]
000070bab59d7fbb  add rsp, 0xF0
000070bab59d7fc2  pop r11
000070bab59d7fc4  pop r10
000070bab59d7fc6  pop r9
000070bab59d7fc8  pop r8
000070bab59d7fca  pop rsi
000070bab59d7fcb  pop rdi
000070bab59d7fcc  pop rdx
000070bab59d7fcd  pop rcx
000070bab59d7fce  pop rax
000070bab59d7fcf  add rsp, 0x08
000070bab59d7fd3  jmp 0x000070BAB59D5EE6
000070bab59d7fd8  sub rsp, 0x08
000070bab59d7fdc  push rax
000070bab59d7fdd  push rcx
000070bab59d7fde  push rdx
000070bab59d7fdf  push rdi
000070bab59d7fe0  push rsi
000070bab59d7fe1  push r8
000070bab59d7fe3  push r9
000070bab59d7fe5  push r10
000070bab59d7fe7  push r11
000070bab59d7fe9  sub rsp, 0xF0
000070bab59d7ff0  vmovaps [rsp], xmm0
000070bab59d7ff5  vmovaps [rsp+0x10], xmm2
000070bab59d7ffb  vmovaps [rsp+0x20], xmm3
000070bab59d8001  vmovaps [rsp+0x30], xmm4
000070bab59d8007  vmovaps [rsp+0x40], xmm5
000070bab59d800d  vmovaps [rsp+0x50], xmm6
000070bab59d8013  vmovaps [rsp+0x60], xmm7
000070bab59d8019  vmovaps [rsp+0x70], xmm8
000070bab59d801f  vmovaps [rsp+0x80], xmm9
000070bab59d8028  vmovaps [rsp+0x90], xmm10
000070bab59d8031  vmovaps [rsp+0xA0], xmm11
000070bab59d803a  vmovaps [rsp+0xB0], xmm12
000070bab59d8043  vmovaps [rsp+0xC0], xmm13
000070bab59d804c  vmovaps [rsp+0xD0], xmm14
000070bab59d8055  vmovaps [rsp+0xE0], xmm15
000070bab59d805e  sub rsp, 0x30
000070bab59d8062  movaps [rsp], xmm1
000070bab59d8066  movaps [rsp+0x10], xmm5
000070bab59d806b  movaps [rsp+0x20], xmm4
000070bab59d8070  lea rdi, [rsp]
000070bab59d8074  mov esi, 0x00
000070bab59d8079  mov rax, 0x63B35AFBC530
000070bab59d8083  call rax
000070bab59d8085  movaps xmm1, [rsp]
000070bab59d8089  add rsp, 0x30
000070bab59d808d  vmovaps xmm0, [rsp]
000070bab59d8092  vmovaps xmm2, [rsp+0x10]
000070bab59d8098  vmovaps xmm3, [rsp+0x20]
000070bab59d809e  vmovaps xmm4, [rsp+0x30]
000070bab59d80a4  vmovaps xmm5, [rsp+0x40]
000070bab59d80aa  vmovaps xmm6, [rsp+0x50]
000070bab59d80b0  vmovaps xmm7, [rsp+0x60]
000070bab59d80b6  vmovaps xmm8, [rsp+0x70]
000070bab59d80bc  vmovaps xmm9, [rsp+0x80]
000070bab59d80c5  vmovaps xmm10, [rsp+0x90]
000070bab59d80ce  vmovaps xmm11, [rsp+0xA0]
000070bab59d80d7  vmovaps xmm12, [rsp+0xB0]
000070bab59d80e0  vmovaps xmm13, [rsp+0xC0]
000070bab59d80e9  vmovaps xmm14, [rsp+0xD0]
000070bab59d80f2  vmovaps xmm15, [rsp+0xE0]
000070bab59d80fb  add rsp, 0xF0
000070bab59d8102  pop r11
000070bab59d8104  pop r10
000070bab59d8106  pop r9
000070bab59d8108  pop r8
000070bab59d810a  pop rsi
000070bab59d810b  pop rdi
000070bab59d810c  pop rdx
000070bab59d810d  pop rcx
000070bab59d810e  pop rax
000070bab59d810f  add rsp, 0x08
000070bab59d8113  jmp 0x000070BAB59D5F06
000070bab59d8118  sub rsp, 0x08
000070bab59d811c  push rax
000070bab59d811d  push rcx
000070bab59d811e  push rdx
000070bab59d811f  push rdi
000070bab59d8120  push rsi
000070bab59d8121  push r8
000070bab59d8123  push r9
000070bab59d8125  push r10
000070bab59d8127  push r11
000070bab59d8129  sub rsp, 0xF0
000070bab59d8130  vmovaps [rsp], xmm0
000070bab59d8135  vmovaps [rsp+0x10], xmm1
000070bab59d813b  vmovaps [rsp+0x20], xmm2
000070bab59d8141  vmovaps [rsp+0x30], xmm3
000070bab59d8147  vmovaps [rsp+0x40], xmm5
000070bab59d814d  vmovaps [rsp+0x50], xmm6
000070bab59d8153  vmovaps [rsp+0x60], xmm7
000070bab59d8159  vmovaps [rsp+0x70], xmm8
000070bab59d815f  vmovaps [rsp+0x80], xmm9
000070bab59d8168  vmovaps [rsp+0x90], xmm10
000070bab59d8171  vmovaps [rsp+0xA0], xmm11
000070bab59d817a  vmovaps [rsp+0xB0], xmm12
000070bab59d8183  vmovaps [rsp+0xC0], xmm13
000070bab59d818c  vmovaps [rsp+0xD0], xmm14
000070bab59d8195  vmovaps [rsp+0xE0], xmm15
000070bab59d819e  sub rsp, 0x30
000070bab59d81a2  movaps [rsp], xmm4
000070bab59d81a6  movaps [rsp+0x10], xmm3
000070bab59d81ab  movaps [rsp+0x20], xmm5
000070bab59d81b0  lea rdi, [rsp]
000070bab59d81b4  mov esi, 0x00
000070bab59d81b9  mov rax, 0x63B35AFBC530
000070bab59d81c3  call rax
000070bab59d81c5  movaps xmm4, [rsp]
000070bab59d81c9  add rsp, 0x30
000070bab59d81cd  vmovaps xmm0, [rsp]
000070bab59d81d2  vmovaps xmm1, [rsp+0x10]
000070bab59d81d8  vmovaps xmm2, [rsp+0x20]
000070bab59d81de  vmovaps xmm3, [rsp+0x30]
000070bab59d81e4  vmovaps xmm5, [rsp+0x40]
000070bab59d81ea  vmovaps xmm6, [rsp+0x50]
000070bab59d81f0  vmovaps xmm7, [rsp+0x60]
000070bab59d81f6  vmovaps xmm8, [rsp+0x70]
000070bab59d81fc  vmovaps xmm9, [rsp+0x80]
000070bab59d8205  vmovaps xmm10, [rsp+0x90]
000070bab59d820e  vmovaps xmm11, [rsp+0xA0]
000070bab59d8217  vmovaps xmm12, [rsp+0xB0]
000070bab59d8220  vmovaps xmm13, [rsp+0xC0]
000070bab59d8229  vmovaps xmm14, [rsp+0xD0]
000070bab59d8232  vmovaps xmm15, [rsp+0xE0]
000070bab59d823b  add rsp, 0xF0
000070bab59d8242  pop r11
000070bab59d8244  pop r10
000070bab59d8246  pop r9
000070bab59d8248  pop r8
000070bab59d824a  pop rsi
000070bab59d824b  pop rdi
000070bab59d824c  pop rdx
000070bab59d824d  pop rcx
000070bab59d824e  pop rax
000070bab59d824f  add rsp, 0x08
000070bab59d8253  jmp 0x000070BAB59D5F54
000070bab59d8258  call 0x000070BAB58D64F0
000070bab59d825d  jmp 0x000070BAB59D5F61
000070bab59d8262  sub rsp, 0x08
000070bab59d8266  push rax
000070bab59d8267  push rcx
000070bab59d8268  push rdx
000070bab59d8269  push rdi
000070bab59d826a  push rsi
000070bab59d826b  push r8
000070bab59d826d  push r9
000070bab59d826f  push r10
000070bab59d8271  push r11
000070bab59d8273  sub rsp, 0xF0
000070bab59d827a  vmovaps [rsp], xmm0
000070bab59d827f  vmovaps [rsp+0x10], xmm1
000070bab59d8285  vmovaps [rsp+0x20], xmm2
000070bab59d828b  vmovaps [rsp+0x30], xmm3
000070bab59d8291  vmovaps [rsp+0x40], xmm4
000070bab59d8297  vmovaps [rsp+0x50], xmm6
000070bab59d829d  vmovaps [rsp+0x60], xmm7
000070bab59d82a3  vmovaps [rsp+0x70], xmm8
000070bab59d82a9  vmovaps [rsp+0x80], xmm9
000070bab59d82b2  vmovaps [rsp+0x90], xmm10
000070bab59d82bb  vmovaps [rsp+0xA0], xmm11
000070bab59d82c4  vmovaps [rsp+0xB0], xmm12
000070bab59d82cd  vmovaps [rsp+0xC0], xmm13
000070bab59d82d6  vmovaps [rsp+0xD0], xmm14
000070bab59d82df  vmovaps [rsp+0xE0], xmm15
000070bab59d82e8  sub rsp, 0x30
000070bab59d82ec  movaps [rsp], xmm5
000070bab59d82f0  movaps [rsp+0x10], xmm6
000070bab59d82f5  movaps [rsp+0x20], xmm3
000070bab59d82fa  lea rdi, [rsp]
000070bab59d82fe  mov esi, 0x00
000070bab59d8303  mov rax, 0x63B35AFBC530
000070bab59d830d  call rax
000070bab59d830f  movaps xmm5, [rsp]
000070bab59d8313  add rsp, 0x30
000070bab59d8317  vmovaps xmm0, [rsp]
000070bab59d831c  vmovaps xmm1, [rsp+0x10]
000070bab59d8322  vmovaps xmm2, [rsp+0x20]
000070bab59d8328  vmovaps xmm3, [rsp+0x30]
000070bab59d832e  vmovaps xmm4, [rsp+0x40]
000070bab59d8334  vmovaps xmm6, [rsp+0x50]
000070bab59d833a  vmovaps xmm7, [rsp+0x60]
000070bab59d8340  vmovaps xmm8, [rsp+0x70]
000070bab59d8346  vmovaps xmm9, [rsp+0x80]
000070bab59d834f  vmovaps xmm10, [rsp+0x90]
000070bab59d8358  vmovaps xmm11, [rsp+0xA0]
000070bab59d8361  vmovaps xmm12, [rsp+0xB0]
000070bab59d836a  vmovaps xmm13, [rsp+0xC0]
000070bab59d8373  vmovaps xmm14, [rsp+0xD0]
000070bab59d837c  vmovaps xmm15, [rsp+0xE0]
000070bab59d8385  add rsp, 0xF0
000070bab59d838c  pop r11
000070bab59d838e  pop r10
000070bab59d8390  pop r9
000070bab59d8392  pop r8
000070bab59d8394  pop rsi
000070bab59d8395  pop rdi
000070bab59d8396  pop rdx
000070bab59d8397  pop rcx
000070bab59d8398  pop rax
000070bab59d8399  add rsp, 0x08
000070bab59d839d  jmp 0x000070BAB59D5F87
000070bab59d83a2  sub rsp, 0x08
000070bab59d83a6  push rax
000070bab59d83a7  push rcx
000070bab59d83a8  push rdx
000070bab59d83a9  push rdi
000070bab59d83aa  push rsi
000070bab59d83ab  push r8
000070bab59d83ad  push r9
000070bab59d83af  push r10
000070bab59d83b1  push r11
000070bab59d83b3  sub rsp, 0xF0
000070bab59d83ba  vmovaps [rsp], xmm0
000070bab59d83bf  vmovaps [rsp+0x10], xmm1
000070bab59d83c5  vmovaps [rsp+0x20], xmm2
000070bab59d83cb  vmovaps [rsp+0x30], xmm3
000070bab59d83d1  vmovaps [rsp+0x40], xmm4
000070bab59d83d7  vmovaps [rsp+0x50], xmm5
000070bab59d83dd  vmovaps [rsp+0x60], xmm7
000070bab59d83e3  vmovaps [rsp+0x70], xmm8
000070bab59d83e9  vmovaps [rsp+0x80], xmm9
000070bab59d83f2  vmovaps [rsp+0x90], xmm10
000070bab59d83fb  vmovaps [rsp+0xA0], xmm11
000070bab59d8404  vmovaps [rsp+0xB0], xmm12
000070bab59d840d  vmovaps [rsp+0xC0], xmm13
000070bab59d8416  vmovaps [rsp+0xD0], xmm14
000070bab59d841f  vmovaps [rsp+0xE0], xmm15
000070bab59d8428  sub rsp, 0x30
000070bab59d842c  movaps [rsp], xmm6
000070bab59d8430  movaps [rsp+0x10], xmm9
000070bab59d8436  movaps [rsp+0x20], xmm1
000070bab59d843b  lea rdi, [rsp]
000070bab59d843f  mov esi, 0x00
000070bab59d8444  mov rax, 0x63B35AFBC530
000070bab59d844e  call rax
000070bab59d8450  movaps xmm6, [rsp]
000070bab59d8454  add rsp, 0x30
000070bab59d8458  vmovaps xmm0, [rsp]
000070bab59d845d  vmovaps xmm1, [rsp+0x10]
000070bab59d8463  vmovaps xmm2, [rsp+0x20]
000070bab59d8469  vmovaps xmm3, [rsp+0x30]
000070bab59d846f  vmovaps xmm4, [rsp+0x40]
000070bab59d8475  vmovaps xmm5, [rsp+0x50]
000070bab59d847b  vmovaps xmm7, [rsp+0x60]
000070bab59d8481  vmovaps xmm8, [rsp+0x70]
000070bab59d8487  vmovaps xmm9, [rsp+0x80]
000070bab59d8490  vmovaps xmm10, [rsp+0x90]
000070bab59d8499  vmovaps xmm11, [rsp+0xA0]
000070bab59d84a2  vmovaps xmm12, [rsp+0xB0]
000070bab59d84ab  vmovaps xmm13, [rsp+0xC0]
000070bab59d84b4  vmovaps xmm14, [rsp+0xD0]
000070bab59d84bd  vmovaps xmm15, [rsp+0xE0]
000070bab59d84c6  add rsp, 0xF0
000070bab59d84cd  pop r11
000070bab59d84cf  pop r10
000070bab59d84d1  pop r9
000070bab59d84d3  pop r8
000070bab59d84d5  pop rsi
000070bab59d84d6  pop rdi
000070bab59d84d7  pop rdx
000070bab59d84d8  pop rcx
000070bab59d84d9  pop rax
000070bab59d84da  add rsp, 0x08
000070bab59d84de  jmp 0x000070BAB59D5FAB
000070bab59d84e3  sub rsp, 0x08
000070bab59d84e7  push rax
000070bab59d84e8  push rcx
000070bab59d84e9  push rdx
000070bab59d84ea  push rdi
000070bab59d84eb  push rsi
000070bab59d84ec  push r8
000070bab59d84ee  push r9
000070bab59d84f0  push r10
000070bab59d84f2  push r11
000070bab59d84f4  sub rsp, 0xF0
000070bab59d84fb  vmovaps [rsp], xmm0
000070bab59d8500  vmovaps [rsp+0x10], xmm1
000070bab59d8506  vmovaps [rsp+0x20], xmm2
000070bab59d850c  vmovaps [rsp+0x30], xmm3
000070bab59d8512  vmovaps [rsp+0x40], xmm4
000070bab59d8518  vmovaps [rsp+0x50], xmm5
000070bab59d851e  vmovaps [rsp+0x60], xmm6
000070bab59d8524  vmovaps [rsp+0x70], xmm7
000070bab59d852a  vmovaps [rsp+0x80], xmm8
000070bab59d8533  vmovaps [rsp+0x90], xmm10
000070bab59d853c  vmovaps [rsp+0xA0], xmm11
000070bab59d8545  vmovaps [rsp+0xB0], xmm12
000070bab59d854e  vmovaps [rsp+0xC0], xmm13
000070bab59d8557  vmovaps [rsp+0xD0], xmm14
000070bab59d8560  vmovaps [rsp+0xE0], xmm15
000070bab59d8569  sub rsp, 0x30
000070bab59d856d  movaps [rsp], xmm9
000070bab59d8572  movaps [rsp+0x10], xmm3
000070bab59d8577  movaps [rsp+0x20], xmm1
000070bab59d857c  lea rdi, [rsp]
000070bab59d8580  mov esi, 0x00
000070bab59d8585  mov rax, 0x63B35AFBC530
000070bab59d858f  call rax
000070bab59d8591  movaps xmm9, [rsp]
000070bab59d8596  add rsp, 0x30
000070bab59d859a  vmovaps xmm0, [rsp]
000070bab59d859f  vmovaps xmm1, [rsp+0x10]
000070bab59d85a5  vmovaps xmm2, [rsp+0x20]
000070bab59d85ab  vmovaps xmm3, [rsp+0x30]
000070bab59d85b1  vmovaps xmm4, [rsp+0x40]
000070bab59d85b7  vmovaps xmm5, [rsp+0x50]
000070bab59d85bd  vmovaps xmm6, [rsp+0x60]
000070bab59d85c3  vmovaps xmm7, [rsp+0x70]
000070bab59d85c9  vmovaps xmm8, [rsp+0x80]
000070bab59d85d2  vmovaps xmm10, [rsp+0x90]
000070bab59d85db  vmovaps xmm11, [rsp+0xA0]
000070bab59d85e4  vmovaps xmm12, [rsp+0xB0]
000070bab59d85ed  vmovaps xmm13, [rsp+0xC0]
000070bab59d85f6  vmovaps xmm14, [rsp+0xD0]
000070bab59d85ff  vmovaps xmm15, [rsp+0xE0]
000070bab59d8608  add rsp, 0xF0
000070bab59d860f  pop r11
000070bab59d8611  pop r10
000070bab59d8613  pop r9
000070bab59d8615  pop r8
000070bab59d8617  pop rsi
000070bab59d8618  pop rdi
000070bab59d8619  pop rdx
000070bab59d861a  pop rcx
000070bab59d861b  pop rax
000070bab59d861c  add rsp, 0x08
000070bab59d8620  jmp 0x000070BAB59D5FF7
000070bab59d8625  call 0x000070BAB58D64F0
000070bab59d862a  jmp 0x000070BAB59D6004
000070bab59d862f  sub rsp, 0x08
000070bab59d8633  push rax
000070bab59d8634  push rcx
000070bab59d8635  push rdx
000070bab59d8636  push rdi
000070bab59d8637  push rsi
000070bab59d8638  push r8
000070bab59d863a  push r9
000070bab59d863c  push r10
000070bab59d863e  push r11
000070bab59d8640  sub rsp, 0xF0
000070bab59d8647  vmovaps [rsp], xmm0
000070bab59d864c  vmovaps [rsp+0x10], xmm1
000070bab59d8652  vmovaps [rsp+0x20], xmm2
000070bab59d8658  vmovaps [rsp+0x30], xmm3
000070bab59d865e  vmovaps [rsp+0x40], xmm4
000070bab59d8664  vmovaps [rsp+0x50], xmm5
000070bab59d866a  vmovaps [rsp+0x60], xmm6
000070bab59d8670  vmovaps [rsp+0x70], xmm7
000070bab59d8676  vmovaps [rsp+0x80], xmm8
000070bab59d867f  vmovaps [rsp+0x90], xmm9
000070bab59d8688  vmovaps [rsp+0xA0], xmm10
000070bab59d8691  vmovaps [rsp+0xB0], xmm11
000070bab59d869a  vmovaps [rsp+0xC0], xmm12
000070bab59d86a3  vmovaps [rsp+0xD0], xmm13
000070bab59d86ac  vmovaps [rsp+0xE0], xmm14
000070bab59d86b5  sub rsp, 0x30
000070bab59d86b9  movaps [rsp], xmm15
000070bab59d86be  movaps [rsp+0x10], xmm3
000070bab59d86c3  movaps [rsp+0x20], xmm7
000070bab59d86c8  lea rdi, [rsp]
000070bab59d86cc  mov esi, 0x00
000070bab59d86d1  mov rax, 0x63B35AFBC530
000070bab59d86db  call rax
000070bab59d86dd  movaps xmm15, [rsp]
000070bab59d86e2  add rsp, 0x30
000070bab59d86e6  vmovaps xmm0, [rsp]
000070bab59d86eb  vmovaps xmm1, [rsp+0x10]
000070bab59d86f1  vmovaps xmm2, [rsp+0x20]
000070bab59d86f7  vmovaps xmm3, [rsp+0x30]
000070bab59d86fd  vmovaps xmm4, [rsp+0x40]
000070bab59d8703  vmovaps xmm5, [rsp+0x50]
000070bab59d8709  vmovaps xmm6, [rsp+0x60]
000070bab59d870f  vmovaps xmm7, [rsp+0x70]
000070bab59d8715  vmovaps xmm8, [rsp+0x80]
000070bab59d871e  vmovaps xmm9, [rsp+0x90]
000070bab59d8727  vmovaps xmm10, [rsp+0xA0]
000070bab59d8730  vmovaps xmm11, [rsp+0xB0]
000070bab59d8739  vmovaps xmm12, [rsp+0xC0]
000070bab59d8742  vmovaps xmm13, [rsp+0xD0]
000070bab59d874b  vmovaps xmm14, [rsp+0xE0]
000070bab59d8754  add rsp, 0xF0
000070bab59d875b  pop r11
000070bab59d875d  pop r10
000070bab59d875f  pop r9
000070bab59d8761  pop r8
000070bab59d8763  pop rsi
000070bab59d8764  pop rdi
000070bab59d8765  pop rdx
000070bab59d8766  pop rcx
000070bab59d8767  pop rax
000070bab59d8768  add rsp, 0x08
000070bab59d876c  jmp 0x000070BAB59D6030
000070bab59d8771  sub rsp, 0x08
000070bab59d8775  push rax
000070bab59d8776  push rcx
000070bab59d8777  push rdx
000070bab59d8778  push rdi
000070bab59d8779  push rsi
000070bab59d877a  push r8
000070bab59d877c  push r9
000070bab59d877e  push r10
000070bab59d8780  push r11
000070bab59d8782  sub rsp, 0xF0
000070bab59d8789  vmovaps [rsp], xmm0
000070bab59d878e  vmovaps [rsp+0x10], xmm1
000070bab59d8794  vmovaps [rsp+0x20], xmm2
000070bab59d879a  vmovaps [rsp+0x30], xmm4
000070bab59d87a0  vmovaps [rsp+0x40], xmm5
000070bab59d87a6  vmovaps [rsp+0x50], xmm6
000070bab59d87ac  vmovaps [rsp+0x60], xmm7
000070bab59d87b2  vmovaps [rsp+0x70], xmm8
000070bab59d87b8  vmovaps [rsp+0x80], xmm9
000070bab59d87c1  vmovaps [rsp+0x90], xmm10
000070bab59d87ca  vmovaps [rsp+0xA0], xmm11
000070bab59d87d3  vmovaps [rsp+0xB0], xmm12
000070bab59d87dc  vmovaps [rsp+0xC0], xmm13
000070bab59d87e5  vmovaps [rsp+0xD0], xmm14
000070bab59d87ee  vmovaps [rsp+0xE0], xmm15
000070bab59d87f7  sub rsp, 0x30
000070bab59d87fb  movaps [rsp], xmm3
000070bab59d87ff  movaps [rsp+0x10], xmm1
000070bab59d8804  movaps [rsp+0x20], xmm15
000070bab59d880a  lea rdi, [rsp]
000070bab59d880e  mov esi, 0x00
000070bab59d8813  mov rax, 0x63B35AFBC530
000070bab59d881d  call rax
000070bab59d881f  movaps xmm3, [rsp]
000070bab59d8823  add rsp, 0x30
000070bab59d8827  vmovaps xmm0, [rsp]
000070bab59d882c  vmovaps xmm1, [rsp+0x10]
000070bab59d8832  vmovaps xmm2, [rsp+0x20]
000070bab59d8838  vmovaps xmm4, [rsp+0x30]
000070bab59d883e  vmovaps xmm5, [rsp+0x40]
000070bab59d8844  vmovaps xmm6, [rsp+0x50]
000070bab59d884a  vmovaps xmm7, [rsp+0x60]
000070bab59d8850  vmovaps xmm8, [rsp+0x70]
000070bab59d8856  vmovaps xmm9, [rsp+0x80]
000070bab59d885f  vmovaps xmm10, [rsp+0x90]
000070bab59d8868  vmovaps xmm11, [rsp+0xA0]
000070bab59d8871  vmovaps xmm12, [rsp+0xB0]
000070bab59d887a  vmovaps xmm13, [rsp+0xC0]
000070bab59d8883  vmovaps xmm14, [rsp+0xD0]
000070bab59d888c  vmovaps xmm15, [rsp+0xE0]
000070bab59d8895  add rsp, 0xF0
000070bab59d889c  pop r11
000070bab59d889e  pop r10
000070bab59d88a0  pop r9
000070bab59d88a2  pop r8
000070bab59d88a4  pop rsi
000070bab59d88a5  pop rdi
000070bab59d88a6  pop rdx
000070bab59d88a7  pop rcx
000070bab59d88a8  pop rax
000070bab59d88a9  add rsp, 0x08
000070bab59d88ad  jmp 0x000070BAB59D60BF
000070bab59d88b2  call 0x000070BAB58D64F0
000070bab59d88b7  jmp 0x000070BAB59D60C9
000070bab59d88bc  sub rsp, 0x08
000070bab59d88c0  push rax
000070bab59d88c1  push rcx
000070bab59d88c2  push rdx
000070bab59d88c3  push rdi
000070bab59d88c4  push rsi
000070bab59d88c5  push r8
000070bab59d88c7  push r9
000070bab59d88c9  push r10
000070bab59d88cb  push r11
000070bab59d88cd  sub rsp, 0xF0
000070bab59d88d4  vmovaps [rsp], xmm0
000070bab59d88d9  vmovaps [rsp+0x10], xmm1
000070bab59d88df  vmovaps [rsp+0x20], xmm2
000070bab59d88e5  vmovaps [rsp+0x30], xmm3
000070bab59d88eb  vmovaps [rsp+0x40], xmm4
000070bab59d88f1  vmovaps [rsp+0x50], xmm5
000070bab59d88f7  vmovaps [rsp+0x60], xmm6
000070bab59d88fd  vmovaps [rsp+0x70], xmm7
000070bab59d8903  vmovaps [rsp+0x80], xmm8
000070bab59d890c  vmovaps [rsp+0x90], xmm9
000070bab59d8915  vmovaps [rsp+0xA0], xmm10
000070bab59d891e  vmovaps [rsp+0xB0], xmm11
000070bab59d8927  vmovaps [rsp+0xC0], xmm12
000070bab59d8930  vmovaps [rsp+0xD0], xmm13
000070bab59d8939  vmovaps [rsp+0xE0], xmm14
000070bab59d8942  sub rsp, 0x30
000070bab59d8946  movaps [rsp], xmm15
000070bab59d894b  movaps [rsp+0x10], xmm14
000070bab59d8951  movaps [rsp+0x20], xmm4
000070bab59d8956  lea rdi, [rsp]
000070bab59d895a  mov esi, 0x00
000070bab59d895f  mov rax, 0x63B35AFBC530
000070bab59d8969  call rax
000070bab59d896b  movaps xmm15, [rsp]
000070bab59d8970  add rsp, 0x30
000070bab59d8974  vmovaps xmm0, [rsp]
000070bab59d8979  vmovaps xmm1, [rsp+0x10]
000070bab59d897f  vmovaps xmm2, [rsp+0x20]
000070bab59d8985  vmovaps xmm3, [rsp+0x30]
000070bab59d898b  vmovaps xmm4, [rsp+0x40]
000070bab59d8991  vmovaps xmm5, [rsp+0x50]
000070bab59d8997  vmovaps xmm6, [rsp+0x60]
000070bab59d899d  vmovaps xmm7, [rsp+0x70]
000070bab59d89a3  vmovaps xmm8, [rsp+0x80]
000070bab59d89ac  vmovaps xmm9, [rsp+0x90]
000070bab59d89b5  vmovaps xmm10, [rsp+0xA0]
000070bab59d89be  vmovaps xmm11, [rsp+0xB0]
000070bab59d89c7  vmovaps xmm12, [rsp+0xC0]
000070bab59d89d0  vmovaps xmm13, [rsp+0xD0]
000070bab59d89d9  vmovaps xmm14, [rsp+0xE0]
000070bab59d89e2  add rsp, 0xF0
000070bab59d89e9  pop r11
000070bab59d89eb  pop r10
000070bab59d89ed  pop r9
000070bab59d89ef  pop r8
000070bab59d89f1  pop rsi
000070bab59d89f2  pop rdi
000070bab59d89f3  pop rdx
000070bab59d89f4  pop rcx
000070bab59d89f5  pop rax
000070bab59d89f6  add rsp, 0x08
000070bab59d89fa  jmp 0x000070BAB59D60F7
000070bab59d89ff  sub rsp, 0x08
000070bab59d8a03  push rax
000070bab59d8a04  push rcx
000070bab59d8a05  push rdx
000070bab59d8a06  push rdi
000070bab59d8a07  push rsi
000070bab59d8a08  push r8
000070bab59d8a0a  push r9
000070bab59d8a0c  push r10
000070bab59d8a0e  push r11
000070bab59d8a10  sub rsp, 0xF0
000070bab59d8a17  vmovaps [rsp], xmm0
000070bab59d8a1c  vmovaps [rsp+0x10], xmm1
000070bab59d8a22  vmovaps [rsp+0x20], xmm2
000070bab59d8a28  vmovaps [rsp+0x30], xmm3
000070bab59d8a2e  vmovaps [rsp+0x40], xmm4
000070bab59d8a34  vmovaps [rsp+0x50], xmm5
000070bab59d8a3a  vmovaps [rsp+0x60], xmm6
000070bab59d8a40  vmovaps [rsp+0x70], xmm7
000070bab59d8a46  vmovaps [rsp+0x80], xmm8
000070bab59d8a4f  vmovaps [rsp+0x90], xmm9
000070bab59d8a58  vmovaps [rsp+0xA0], xmm10
000070bab59d8a61  vmovaps [rsp+0xB0], xmm11
000070bab59d8a6a  vmovaps [rsp+0xC0], xmm12
000070bab59d8a73  vmovaps [rsp+0xD0], xmm13
000070bab59d8a7c  vmovaps [rsp+0xE0], xmm15
000070bab59d8a85  sub rsp, 0x30
000070bab59d8a89  movaps [rsp], xmm14
000070bab59d8a8e  movaps [rsp+0x10], xmm2
000070bab59d8a93  movaps [rsp+0x20], xmm1
000070bab59d8a98  lea rdi, [rsp]
000070bab59d8a9c  mov esi, 0x00
000070bab59d8aa1  mov rax, 0x63B35AFBC530
000070bab59d8aab  call rax
000070bab59d8aad  movaps xmm14, [rsp]
000070bab59d8ab2  add rsp, 0x30
000070bab59d8ab6  vmovaps xmm0, [rsp]
000070bab59d8abb  vmovaps xmm1, [rsp+0x10]
000070bab59d8ac1  vmovaps xmm2, [rsp+0x20]
000070bab59d8ac7  vmovaps xmm3, [rsp+0x30]
000070bab59d8acd  vmovaps xmm4, [rsp+0x40]
000070bab59d8ad3  vmovaps xmm5, [rsp+0x50]
000070bab59d8ad9  vmovaps xmm6, [rsp+0x60]
000070bab59d8adf  vmovaps xmm7, [rsp+0x70]
000070bab59d8ae5  vmovaps xmm8, [rsp+0x80]
000070bab59d8aee  vmovaps xmm9, [rsp+0x90]
000070bab59d8af7  vmovaps xmm10, [rsp+0xA0]
000070bab59d8b00  vmovaps xmm11, [rsp+0xB0]
000070bab59d8b09  vmovaps xmm12, [rsp+0xC0]
000070bab59d8b12  vmovaps xmm13, [rsp+0xD0]
000070bab59d8b1b  vmovaps xmm15, [rsp+0xE0]
000070bab59d8b24  add rsp, 0xF0
000070bab59d8b2b  pop r11
000070bab59d8b2d  pop r10
000070bab59d8b2f  pop r9
000070bab59d8b31  pop r8
000070bab59d8b33  pop rsi
000070bab59d8b34  pop rdi
000070bab59d8b35  pop rdx
000070bab59d8b36  pop rcx
000070bab59d8b37  pop rax
000070bab59d8b38  add rsp, 0x08
000070bab59d8b3c  jmp 0x000070BAB59D611D
000070bab59d8b41  sub rsp, 0x08
000070bab59d8b45  push rax
000070bab59d8b46  push rcx
000070bab59d8b47  push rdx
000070bab59d8b48  push rdi
000070bab59d8b49  push rsi
000070bab59d8b4a  push r8
000070bab59d8b4c  push r9
000070bab59d8b4e  push r10
000070bab59d8b50  push r11
000070bab59d8b52  sub rsp, 0xF0
000070bab59d8b59  vmovaps [rsp], xmm0
000070bab59d8b5e  vmovaps [rsp+0x10], xmm2
000070bab59d8b64  vmovaps [rsp+0x20], xmm3
000070bab59d8b6a  vmovaps [rsp+0x30], xmm4
000070bab59d8b70  vmovaps [rsp+0x40], xmm5
000070bab59d8b76  vmovaps [rsp+0x50], xmm6
000070bab59d8b7c  vmovaps [rsp+0x60], xmm7
000070bab59d8b82  vmovaps [rsp+0x70], xmm8
000070bab59d8b88  vmovaps [rsp+0x80], xmm9
000070bab59d8b91  vmovaps [rsp+0x90], xmm10
000070bab59d8b9a  vmovaps [rsp+0xA0], xmm11
000070bab59d8ba3  vmovaps [rsp+0xB0], xmm12
000070bab59d8bac  vmovaps [rsp+0xC0], xmm13
000070bab59d8bb5  vmovaps [rsp+0xD0], xmm14
000070bab59d8bbe  vmovaps [rsp+0xE0], xmm15
000070bab59d8bc7  sub rsp, 0x30
000070bab59d8bcb  movaps [rsp], xmm1
000070bab59d8bcf  movaps [rsp+0x10], xmm4
000070bab59d8bd4  movaps [rsp+0x20], xmm9
000070bab59d8bda  lea rdi, [rsp]
000070bab59d8bde  mov esi, 0x00
000070bab59d8be3  mov rax, 0x63B35AFBC530
000070bab59d8bed  call rax
000070bab59d8bef  movaps xmm1, [rsp]
000070bab59d8bf3  add rsp, 0x30
000070bab59d8bf7  vmovaps xmm0, [rsp]
000070bab59d8bfc  vmovaps xmm2, [rsp+0x10]
000070bab59d8c02  vmovaps xmm3, [rsp+0x20]
000070bab59d8c08  vmovaps xmm4, [rsp+0x30]
000070bab59d8c0e  vmovaps xmm5, [rsp+0x40]
000070bab59d8c14  vmovaps xmm6, [rsp+0x50]
000070bab59d8c1a  vmovaps xmm7, [rsp+0x60]
000070bab59d8c20  vmovaps xmm8, [rsp+0x70]
000070bab59d8c26  vmovaps xmm9, [rsp+0x80]
000070bab59d8c2f  vmovaps xmm10, [rsp+0x90]
000070bab59d8c38  vmovaps xmm11, [rsp+0xA0]
000070bab59d8c41  vmovaps xmm12, [rsp+0xB0]
000070bab59d8c4a  vmovaps xmm13, [rsp+0xC0]
000070bab59d8c53  vmovaps xmm14, [rsp+0xD0]
000070bab59d8c5c  vmovaps xmm15, [rsp+0xE0]
000070bab59d8c65  add rsp, 0xF0
000070bab59d8c6c  pop r11
000070bab59d8c6e  pop r10
000070bab59d8c70  pop r9
000070bab59d8c72  pop r8
000070bab59d8c74  pop rsi
000070bab59d8c75  pop rdi
000070bab59d8c76  pop rdx
000070bab59d8c77  pop rcx
000070bab59d8c78  pop rax
000070bab59d8c79  add rsp, 0x08
000070bab59d8c7d  jmp 0x000070BAB59D613B
000070bab59d8c82  sub rsp, 0x08
000070bab59d8c86  push rax
000070bab59d8c87  push rcx
000070bab59d8c88  push rdx
000070bab59d8c89  push rdi
000070bab59d8c8a  push rsi
000070bab59d8c8b  push r8
000070bab59d8c8d  push r9
000070bab59d8c8f  push r10
000070bab59d8c91  push r11
000070bab59d8c93  sub rsp, 0xF0
000070bab59d8c9a  vmovaps [rsp], xmm0
000070bab59d8c9f  vmovaps [rsp+0x10], xmm1
000070bab59d8ca5  vmovaps [rsp+0x20], xmm2
000070bab59d8cab  vmovaps [rsp+0x30], xmm3
000070bab59d8cb1  vmovaps [rsp+0x40], xmm5
000070bab59d8cb7  vmovaps [rsp+0x50], xmm6
000070bab59d8cbd  vmovaps [rsp+0x60], xmm7
000070bab59d8cc3  vmovaps [rsp+0x70], xmm8
000070bab59d8cc9  vmovaps [rsp+0x80], xmm9
000070bab59d8cd2  vmovaps [rsp+0x90], xmm10
000070bab59d8cdb  vmovaps [rsp+0xA0], xmm11
000070bab59d8ce4  vmovaps [rsp+0xB0], xmm12
000070bab59d8ced  vmovaps [rsp+0xC0], xmm13
000070bab59d8cf6  vmovaps [rsp+0xD0], xmm14
000070bab59d8cff  vmovaps [rsp+0xE0], xmm15
000070bab59d8d08  sub rsp, 0x30
000070bab59d8d0c  movaps [rsp], xmm4
000070bab59d8d10  movaps [rsp+0x10], xmm2
000070bab59d8d15  movaps [rsp+0x20], xmm9
000070bab59d8d1b  lea rdi, [rsp]
000070bab59d8d1f  mov esi, 0x00
000070bab59d8d24  mov rax, 0x63B35AFBC530
000070bab59d8d2e  call rax
000070bab59d8d30  movaps xmm4, [rsp]
000070bab59d8d34  add rsp, 0x30
000070bab59d8d38  vmovaps xmm0, [rsp]
000070bab59d8d3d  vmovaps xmm1, [rsp+0x10]
000070bab59d8d43  vmovaps xmm2, [rsp+0x20]
000070bab59d8d49  vmovaps xmm3, [rsp+0x30]
000070bab59d8d4f  vmovaps xmm5, [rsp+0x40]
000070bab59d8d55  vmovaps xmm6, [rsp+0x50]
000070bab59d8d5b  vmovaps xmm7, [rsp+0x60]
000070bab59d8d61  vmovaps xmm8, [rsp+0x70]
000070bab59d8d67  vmovaps xmm9, [rsp+0x80]
000070bab59d8d70  vmovaps xmm10, [rsp+0x90]
000070bab59d8d79  vmovaps xmm11, [rsp+0xA0]
000070bab59d8d82  vmovaps xmm12, [rsp+0xB0]
000070bab59d8d8b  vmovaps xmm13, [rsp+0xC0]
000070bab59d8d94  vmovaps xmm14, [rsp+0xD0]
000070bab59d8d9d  vmovaps xmm15, [rsp+0xE0]
000070bab59d8da6  add rsp, 0xF0
000070bab59d8dad  pop r11
000070bab59d8daf  pop r10
000070bab59d8db1  pop r9
000070bab59d8db3  pop r8
000070bab59d8db5  pop rsi
000070bab59d8db6  pop rdi
000070bab59d8db7  pop rdx
000070bab59d8db8  pop rcx
000070bab59d8db9  pop rax
000070bab59d8dba  add rsp, 0x08
000070bab59d8dbe  jmp 0x000070BAB59D616B
000070bab59d8dc3  sub rsp, 0x08
000070bab59d8dc7  push rax
000070bab59d8dc8  push rcx
000070bab59d8dc9  push rdx
000070bab59d8dca  push rdi
000070bab59d8dcb  push rsi
000070bab59d8dcc  push r8
000070bab59d8dce  push r9
000070bab59d8dd0  push r10
000070bab59d8dd2  push r11
000070bab59d8dd4  sub rsp, 0xF0
000070bab59d8ddb  vmovaps [rsp], xmm0
000070bab59d8de0  vmovaps [rsp+0x10], xmm1
000070bab59d8de6  vmovaps [rsp+0x20], xmm2
000070bab59d8dec  vmovaps [rsp+0x30], xmm3
000070bab59d8df2  vmovaps [rsp+0x40], xmm4
000070bab59d8df8  vmovaps [rsp+0x50], xmm5
000070bab59d8dfe  vmovaps [rsp+0x60], xmm6
000070bab59d8e04  vmovaps [rsp+0x70], xmm7
000070bab59d8e0a  vmovaps [rsp+0x80], xmm8
000070bab59d8e13  vmovaps [rsp+0x90], xmm10
000070bab59d8e1c  vmovaps [rsp+0xA0], xmm11
000070bab59d8e25  vmovaps [rsp+0xB0], xmm12
000070bab59d8e2e  vmovaps [rsp+0xC0], xmm13
000070bab59d8e37  vmovaps [rsp+0xD0], xmm14
000070bab59d8e40  vmovaps [rsp+0xE0], xmm15
000070bab59d8e49  sub rsp, 0x30
000070bab59d8e4d  movaps [rsp], xmm9
000070bab59d8e52  movaps [rsp+0x10], xmm2
000070bab59d8e57  movaps [rsp+0x20], xmm1
000070bab59d8e5c  lea rdi, [rsp]
000070bab59d8e60  mov esi, 0x00
000070bab59d8e65  mov rax, 0x63B35AFBC530
000070bab59d8e6f  call rax
000070bab59d8e71  movaps xmm9, [rsp]
000070bab59d8e76  add rsp, 0x30
000070bab59d8e7a  vmovaps xmm0, [rsp]
000070bab59d8e7f  vmovaps xmm1, [rsp+0x10]
000070bab59d8e85  vmovaps xmm2, [rsp+0x20]
000070bab59d8e8b  vmovaps xmm3, [rsp+0x30]
000070bab59d8e91  vmovaps xmm4, [rsp+0x40]
000070bab59d8e97  vmovaps xmm5, [rsp+0x50]
000070bab59d8e9d  vmovaps xmm6, [rsp+0x60]
000070bab59d8ea3  vmovaps xmm7, [rsp+0x70]
000070bab59d8ea9  vmovaps xmm8, [rsp+0x80]
000070bab59d8eb2  vmovaps xmm10, [rsp+0x90]
000070bab59d8ebb  vmovaps xmm11, [rsp+0xA0]
000070bab59d8ec4  vmovaps xmm12, [rsp+0xB0]
000070bab59d8ecd  vmovaps xmm13, [rsp+0xC0]
000070bab59d8ed6  vmovaps xmm14, [rsp+0xD0]
000070bab59d8edf  vmovaps xmm15, [rsp+0xE0]
000070bab59d8ee8  add rsp, 0xF0
000070bab59d8eef  pop r11
000070bab59d8ef1  pop r10
000070bab59d8ef3  pop r9
000070bab59d8ef5  pop r8
000070bab59d8ef7  pop rsi
000070bab59d8ef8  pop rdi
000070bab59d8ef9  pop rdx
000070bab59d8efa  pop rcx
000070bab59d8efb  pop rax
000070bab59d8efc  add rsp, 0x08
000070bab59d8f00  jmp 0x000070BAB59D61A1
000070bab59d8f05  sub rsp, 0x08
000070bab59d8f09  push rax
000070bab59d8f0a  push rcx
000070bab59d8f0b  push rdx
000070bab59d8f0c  push rdi
000070bab59d8f0d  push rsi
000070bab59d8f0e  push r8
000070bab59d8f10  push r9
000070bab59d8f12  push r10
000070bab59d8f14  push r11
000070bab59d8f16  sub rsp, 0xF0
000070bab59d8f1d  vmovaps [rsp], xmm0
000070bab59d8f22  vmovaps [rsp+0x10], xmm2
000070bab59d8f28  vmovaps [rsp+0x20], xmm3
000070bab59d8f2e  vmovaps [rsp+0x30], xmm4
000070bab59d8f34  vmovaps [rsp+0x40], xmm5
000070bab59d8f3a  vmovaps [rsp+0x50], xmm6
000070bab59d8f40  vmovaps [rsp+0x60], xmm7
000070bab59d8f46  vmovaps [rsp+0x70], xmm8
000070bab59d8f4c  vmovaps [rsp+0x80], xmm9
000070bab59d8f55  vmovaps [rsp+0x90], xmm10
000070bab59d8f5e  vmovaps [rsp+0xA0], xmm11
000070bab59d8f67  vmovaps [rsp+0xB0], xmm12
000070bab59d8f70  vmovaps [rsp+0xC0], xmm13
000070bab59d8f79  vmovaps [rsp+0xD0], xmm14
000070bab59d8f82  vmovaps [rsp+0xE0], xmm15
000070bab59d8f8b  sub rsp, 0x30
000070bab59d8f8f  movaps [rsp], xmm1
000070bab59d8f93  movaps [rsp+0x10], xmm15
000070bab59d8f99  movaps [rsp+0x20], xmm6
000070bab59d8f9e  lea rdi, [rsp]
000070bab59d8fa2  mov esi, 0x00
000070bab59d8fa7  mov rax, 0x63B35AFBC530
000070bab59d8fb1  call rax
000070bab59d8fb3  movaps xmm1, [rsp]
000070bab59d8fb7  add rsp, 0x30
000070bab59d8fbb  vmovaps xmm0, [rsp]
000070bab59d8fc0  vmovaps xmm2, [rsp+0x10]
000070bab59d8fc6  vmovaps xmm3, [rsp+0x20]
000070bab59d8fcc  vmovaps xmm4, [rsp+0x30]
000070bab59d8fd2  vmovaps xmm5, [rsp+0x40]
000070bab59d8fd8  vmovaps xmm6, [rsp+0x50]
000070bab59d8fde  vmovaps xmm7, [rsp+0x60]
000070bab59d8fe4  vmovaps xmm8, [rsp+0x70]
000070bab59d8fea  vmovaps xmm9, [rsp+0x80]
000070bab59d8ff3  vmovaps xmm10, [rsp+0x90]
000070bab59d8ffc  vmovaps xmm11, [rsp+0xA0]
000070bab59d9005  vmovaps xmm12, [rsp+0xB0]
000070bab59d900e  vmovaps xmm13, [rsp+0xC0]
000070bab59d9017  vmovaps xmm14, [rsp+0xD0]
000070bab59d9020  vmovaps xmm15, [rsp+0xE0]
000070bab59d9029  add rsp, 0xF0
000070bab59d9030  pop r11
000070bab59d9032  pop r10
000070bab59d9034  pop r9
000070bab59d9036  pop r8
000070bab59d9038  pop rsi
000070bab59d9039  pop rdi
000070bab59d903a  pop rdx
000070bab59d903b  pop rcx
000070bab59d903c  pop rax
000070bab59d903d  add rsp, 0x08
000070bab59d9041  jmp 0x000070BAB59D61C2
000070bab59d9046  sub rsp, 0x08
000070bab59d904a  push rax
000070bab59d904b  push rcx
000070bab59d904c  push rdx
000070bab59d904d  push rdi
000070bab59d904e  push rsi
000070bab59d904f  push r8
000070bab59d9051  push r9
000070bab59d9053  push r10
000070bab59d9055  push r11
000070bab59d9057  sub rsp, 0xF0
000070bab59d905e  vmovaps [rsp], xmm0
000070bab59d9063  vmovaps [rsp+0x10], xmm1
000070bab59d9069  vmovaps [rsp+0x20], xmm2
000070bab59d906f  vmovaps [rsp+0x30], xmm3
000070bab59d9075  vmovaps [rsp+0x40], xmm4
000070bab59d907b  vmovaps [rsp+0x50], xmm5
000070bab59d9081  vmovaps [rsp+0x60], xmm6
000070bab59d9087  vmovaps [rsp+0x70], xmm7
000070bab59d908d  vmovaps [rsp+0x80], xmm8
000070bab59d9096  vmovaps [rsp+0x90], xmm9
000070bab59d909f  vmovaps [rsp+0xA0], xmm10
000070bab59d90a8  vmovaps [rsp+0xB0], xmm11
000070bab59d90b1  vmovaps [rsp+0xC0], xmm12
000070bab59d90ba  vmovaps [rsp+0xD0], xmm13
000070bab59d90c3  vmovaps [rsp+0xE0], xmm14
000070bab59d90cc  sub rsp, 0x30
000070bab59d90d0  movaps [rsp], xmm15
000070bab59d90d5  movaps [rsp+0x10], xmm5
000070bab59d90da  movaps [rsp+0x20], xmm3
000070bab59d90df  lea rdi, [rsp]
000070bab59d90e3  mov esi, 0x00
000070bab59d90e8  mov rax, 0x63B35AFBC530
000070bab59d90f2  call rax
000070bab59d90f4  movaps xmm15, [rsp]
000070bab59d90f9  add rsp, 0x30
000070bab59d90fd  vmovaps xmm0, [rsp]
000070bab59d9102  vmovaps xmm1, [rsp+0x10]
000070bab59d9108  vmovaps xmm2, [rsp+0x20]
000070bab59d910e  vmovaps xmm3, [rsp+0x30]
000070bab59d9114  vmovaps xmm4, [rsp+0x40]
000070bab59d911a  vmovaps xmm5, [rsp+0x50]
000070bab59d9120  vmovaps xmm6, [rsp+0x60]
000070bab59d9126  vmovaps xmm7, [rsp+0x70]
000070bab59d912c  vmovaps xmm8, [rsp+0x80]
000070bab59d9135  vmovaps xmm9, [rsp+0x90]
000070bab59d913e  vmovaps xmm10, [rsp+0xA0]
000070bab59d9147  vmovaps xmm11, [rsp+0xB0]
000070bab59d9150  vmovaps xmm12, [rsp+0xC0]
000070bab59d9159  vmovaps xmm13, [rsp+0xD0]
000070bab59d9162  vmovaps xmm14, [rsp+0xE0]
000070bab59d916b  add rsp, 0xF0
000070bab59d9172  pop r11
000070bab59d9174  pop r10
000070bab59d9176  pop r9
000070bab59d9178  pop r8
000070bab59d917a  pop rsi
000070bab59d917b  pop rdi
000070bab59d917c  pop rdx
000070bab59d917d  pop rcx
000070bab59d917e  pop rax
000070bab59d917f  add rsp, 0x08
000070bab59d9183  jmp 0x000070BAB59D61DC
000070bab59d9188  sub rsp, 0x08
000070bab59d918c  push rax
000070bab59d918d  push rcx
000070bab59d918e  push rdx
000070bab59d918f  push rdi
000070bab59d9190  push rsi
000070bab59d9191  push r8
000070bab59d9193  push r9
000070bab59d9195  push r10
000070bab59d9197  push r11
000070bab59d9199  sub rsp, 0xF0
000070bab59d91a0  vmovaps [rsp], xmm0
000070bab59d91a5  vmovaps [rsp+0x10], xmm1
000070bab59d91ab  vmovaps [rsp+0x20], xmm2
000070bab59d91b1  vmovaps [rsp+0x30], xmm3
000070bab59d91b7  vmovaps [rsp+0x40], xmm4
000070bab59d91bd  vmovaps [rsp+0x50], xmm6
000070bab59d91c3  vmovaps [rsp+0x60], xmm7
000070bab59d91c9  vmovaps [rsp+0x70], xmm8
000070bab59d91cf  vmovaps [rsp+0x80], xmm9
000070bab59d91d8  vmovaps [rsp+0x90], xmm10
000070bab59d91e1  vmovaps [rsp+0xA0], xmm11
000070bab59d91ea  vmovaps [rsp+0xB0], xmm12
000070bab59d91f3  vmovaps [rsp+0xC0], xmm13
000070bab59d91fc  vmovaps [rsp+0xD0], xmm14
000070bab59d9205  vmovaps [rsp+0xE0], xmm15
000070bab59d920e  sub rsp, 0x30
000070bab59d9212  movaps [rsp], xmm5
000070bab59d9216  movaps [rsp+0x10], xmm8
000070bab59d921c  movaps [rsp+0x20], xmm6
000070bab59d9221  lea rdi, [rsp]
000070bab59d9225  mov esi, 0x00
000070bab59d922a  mov rax, 0x63B35AFBC530
000070bab59d9234  call rax
000070bab59d9236  movaps xmm5, [rsp]
000070bab59d923a  add rsp, 0x30
000070bab59d923e  vmovaps xmm0, [rsp]
000070bab59d9243  vmovaps xmm1, [rsp+0x10]
000070bab59d9249  vmovaps xmm2, [rsp+0x20]
000070bab59d924f  vmovaps xmm3, [rsp+0x30]
000070bab59d9255  vmovaps xmm4, [rsp+0x40]
000070bab59d925b  vmovaps xmm6, [rsp+0x50]
000070bab59d9261  vmovaps xmm7, [rsp+0x60]
000070bab59d9267  vmovaps xmm8, [rsp+0x70]
000070bab59d926d  vmovaps xmm9, [rsp+0x80]
000070bab59d9276  vmovaps xmm10, [rsp+0x90]
000070bab59d927f  vmovaps xmm11, [rsp+0xA0]
000070bab59d9288  vmovaps xmm12, [rsp+0xB0]
000070bab59d9291  vmovaps xmm13, [rsp+0xC0]
000070bab59d929a  vmovaps xmm14, [rsp+0xD0]
000070bab59d92a3  vmovaps xmm15, [rsp+0xE0]
000070bab59d92ac  add rsp, 0xF0
000070bab59d92b3  pop r11
000070bab59d92b5  pop r10
000070bab59d92b7  pop r9
000070bab59d92b9  pop r8
000070bab59d92bb  pop rsi
000070bab59d92bc  pop rdi
000070bab59d92bd  pop rdx
000070bab59d92be  pop rcx
000070bab59d92bf  pop rax
000070bab59d92c0  add rsp, 0x08
000070bab59d92c4  jmp 0x000070BAB59D6200
000070bab59d92c9  sub rsp, 0x08
000070bab59d92cd  push rax
000070bab59d92ce  push rcx
000070bab59d92cf  push rdx
000070bab59d92d0  push rdi
000070bab59d92d1  push rsi
000070bab59d92d2  push r8
000070bab59d92d4  push r9
000070bab59d92d6  push r10
000070bab59d92d8  push r11
000070bab59d92da  sub rsp, 0xF0
000070bab59d92e1  vmovaps [rsp], xmm0
000070bab59d92e6  vmovaps [rsp+0x10], xmm1
000070bab59d92ec  vmovaps [rsp+0x20], xmm2
000070bab59d92f2  vmovaps [rsp+0x30], xmm3
000070bab59d92f8  vmovaps [rsp+0x40], xmm4
000070bab59d92fe  vmovaps [rsp+0x50], xmm5
000070bab59d9304  vmovaps [rsp+0x60], xmm7
000070bab59d930a  vmovaps [rsp+0x70], xmm8
000070bab59d9310  vmovaps [rsp+0x80], xmm9
000070bab59d9319  vmovaps [rsp+0x90], xmm10
000070bab59d9322  vmovaps [rsp+0xA0], xmm11
000070bab59d932b  vmovaps [rsp+0xB0], xmm12
000070bab59d9334  vmovaps [rsp+0xC0], xmm13
000070bab59d933d  vmovaps [rsp+0xD0], xmm14
000070bab59d9346  vmovaps [rsp+0xE0], xmm15
000070bab59d934f  sub rsp, 0x30
000070bab59d9353  movaps [rsp], xmm6
000070bab59d9357  movaps [rsp+0x10], xmm10
000070bab59d935d  movaps [rsp+0x20], xmm8
000070bab59d9363  lea rdi, [rsp]
000070bab59d9367  mov esi, 0x00
000070bab59d936c  mov rax, 0x63B35AFBC530
000070bab59d9376  call rax
000070bab59d9378  movaps xmm6, [rsp]
000070bab59d937c  add rsp, 0x30
000070bab59d9380  vmovaps xmm0, [rsp]
000070bab59d9385  vmovaps xmm1, [rsp+0x10]
000070bab59d938b  vmovaps xmm2, [rsp+0x20]
000070bab59d9391  vmovaps xmm3, [rsp+0x30]
000070bab59d9397  vmovaps xmm4, [rsp+0x40]
000070bab59d939d  vmovaps xmm5, [rsp+0x50]
000070bab59d93a3  vmovaps xmm7, [rsp+0x60]
000070bab59d93a9  vmovaps xmm8, [rsp+0x70]
000070bab59d93af  vmovaps xmm9, [rsp+0x80]
000070bab59d93b8  vmovaps xmm10, [rsp+0x90]
000070bab59d93c1  vmovaps xmm11, [rsp+0xA0]
000070bab59d93ca  vmovaps xmm12, [rsp+0xB0]
000070bab59d93d3  vmovaps xmm13, [rsp+0xC0]
000070bab59d93dc  vmovaps xmm14, [rsp+0xD0]
000070bab59d93e5  vmovaps xmm15, [rsp+0xE0]
000070bab59d93ee  add rsp, 0xF0
000070bab59d93f5  pop r11
000070bab59d93f7  pop r10
000070bab59d93f9  pop r9
000070bab59d93fb  pop r8
000070bab59d93fd  pop rsi
000070bab59d93fe  pop rdi
000070bab59d93ff  pop rdx
000070bab59d9400  pop rcx
000070bab59d9401  pop rax
000070bab59d9402  add rsp, 0x08
000070bab59d9406  jmp 0x000070BAB59D6225
000070bab59d940b  sub rsp, 0x08
000070bab59d940f  push rax
000070bab59d9410  push rcx
000070bab59d9411  push rdx
000070bab59d9412  push rdi
000070bab59d9413  push rsi
000070bab59d9414  push r8
000070bab59d9416  push r9
000070bab59d9418  push r10
000070bab59d941a  push r11
000070bab59d941c  sub rsp, 0xF0
000070bab59d9423  vmovaps [rsp], xmm0
000070bab59d9428  vmovaps [rsp+0x10], xmm1
000070bab59d942e  vmovaps [rsp+0x20], xmm2
000070bab59d9434  vmovaps [rsp+0x30], xmm3
000070bab59d943a  vmovaps [rsp+0x40], xmm4
000070bab59d9440  vmovaps [rsp+0x50], xmm5
000070bab59d9446  vmovaps [rsp+0x60], xmm6
000070bab59d944c  vmovaps [rsp+0x70], xmm7
000070bab59d9452  vmovaps [rsp+0x80], xmm8
000070bab59d945b  vmovaps [rsp+0x90], xmm9
000070bab59d9464  vmovaps [rsp+0xA0], xmm11
000070bab59d946d  vmovaps [rsp+0xB0], xmm12
000070bab59d9476  vmovaps [rsp+0xC0], xmm13
000070bab59d947f  vmovaps [rsp+0xD0], xmm14
000070bab59d9488  vmovaps [rsp+0xE0], xmm15
000070bab59d9491  sub rsp, 0x30
000070bab59d9495  movaps [rsp], xmm10
000070bab59d949a  movaps [rsp+0x10], xmm8
000070bab59d94a0  movaps [rsp+0x20], xmm14
000070bab59d94a6  lea rdi, [rsp]
000070bab59d94aa  mov esi, 0x00
000070bab59d94af  mov rax, 0x63B35AFBC530
000070bab59d94b9  call rax
000070bab59d94bb  movaps xmm10, [rsp]
000070bab59d94c0  add rsp, 0x30
000070bab59d94c4  vmovaps xmm0, [rsp]
000070bab59d94c9  vmovaps xmm1, [rsp+0x10]
000070bab59d94cf  vmovaps xmm2, [rsp+0x20]
000070bab59d94d5  vmovaps xmm3, [rsp+0x30]
000070bab59d94db  vmovaps xmm4, [rsp+0x40]
000070bab59d94e1  vmovaps xmm5, [rsp+0x50]
000070bab59d94e7  vmovaps xmm6, [rsp+0x60]
000070bab59d94ed  vmovaps xmm7, [rsp+0x70]
000070bab59d94f3  vmovaps xmm8, [rsp+0x80]
000070bab59d94fc  vmovaps xmm9, [rsp+0x90]
000070bab59d9505  vmovaps xmm11, [rsp+0xA0]
000070bab59d950e  vmovaps xmm12, [rsp+0xB0]
000070bab59d9517  vmovaps xmm13, [rsp+0xC0]
000070bab59d9520  vmovaps xmm14, [rsp+0xD0]
000070bab59d9529  vmovaps xmm15, [rsp+0xE0]
000070bab59d9532  add rsp, 0xF0
000070bab59d9539  pop r11
000070bab59d953b  pop r10
000070bab59d953d  pop r9
000070bab59d953f  pop r8
000070bab59d9541  pop rsi
000070bab59d9542  pop rdi
000070bab59d9543  pop rdx
000070bab59d9544  pop rcx
000070bab59d9545  pop rax
000070bab59d9546  add rsp, 0x08
000070bab59d954a  jmp 0x000070BAB59D6245
000070bab59d954f  sub rsp, 0x08
000070bab59d9553  push rax
000070bab59d9554  push rcx
000070bab59d9555  push rdx
000070bab59d9556  push rdi
000070bab59d9557  push rsi
000070bab59d9558  push r8
000070bab59d955a  push r9
000070bab59d955c  push r10
000070bab59d955e  push r11
000070bab59d9560  sub rsp, 0xF0
000070bab59d9567  vmovaps [rsp], xmm0
000070bab59d956c  vmovaps [rsp+0x10], xmm1
000070bab59d9572  vmovaps [rsp+0x20], xmm2
000070bab59d9578  vmovaps [rsp+0x30], xmm3
000070bab59d957e  vmovaps [rsp+0x40], xmm4
000070bab59d9584  vmovaps [rsp+0x50], xmm5
000070bab59d958a  vmovaps [rsp+0x60], xmm6
000070bab59d9590  vmovaps [rsp+0x70], xmm7
000070bab59d9596  vmovaps [rsp+0x80], xmm8
000070bab59d959f  vmovaps [rsp+0x90], xmm9
000070bab59d95a8  vmovaps [rsp+0xA0], xmm10
000070bab59d95b1  vmovaps [rsp+0xB0], xmm11
000070bab59d95ba  vmovaps [rsp+0xC0], xmm12
000070bab59d95c3  vmovaps [rsp+0xD0], xmm13
000070bab59d95cc  vmovaps [rsp+0xE0], xmm15
000070bab59d95d5  sub rsp, 0x30
000070bab59d95d9  movaps [rsp], xmm14
000070bab59d95de  movaps [rsp+0x10], xmm8
000070bab59d95e4  movaps [rsp+0x20], xmm4
000070bab59d95e9  lea rdi, [rsp]
000070bab59d95ed  mov esi, 0x00
000070bab59d95f2  mov rax, 0x63B35AFBC530
000070bab59d95fc  call rax
000070bab59d95fe  movaps xmm14, [rsp]
000070bab59d9603  add rsp, 0x30
000070bab59d9607  vmovaps xmm0, [rsp]
000070bab59d960c  vmovaps xmm1, [rsp+0x10]
000070bab59d9612  vmovaps xmm2, [rsp+0x20]
000070bab59d9618  vmovaps xmm3, [rsp+0x30]
000070bab59d961e  vmovaps xmm4, [rsp+0x40]
000070bab59d9624  vmovaps xmm5, [rsp+0x50]
000070bab59d962a  vmovaps xmm6, [rsp+0x60]
000070bab59d9630  vmovaps xmm7, [rsp+0x70]
000070bab59d9636  vmovaps xmm8, [rsp+0x80]
000070bab59d963f  vmovaps xmm9, [rsp+0x90]
000070bab59d9648  vmovaps xmm10, [rsp+0xA0]
000070bab59d9651  vmovaps xmm11, [rsp+0xB0]
000070bab59d965a  vmovaps xmm12, [rsp+0xC0]
000070bab59d9663  vmovaps xmm13, [rsp+0xD0]
000070bab59d966c  vmovaps xmm15, [rsp+0xE0]
000070bab59d9675  add rsp, 0xF0
000070bab59d967c  pop r11
000070bab59d967e  pop r10
000070bab59d9680  pop r9
000070bab59d9682  pop r8
000070bab59d9684  pop rsi
000070bab59d9685  pop rdi
000070bab59d9686  pop rdx
000070bab59d9687  pop rcx
000070bab59d9688  pop rax
000070bab59d9689  add rsp, 0x08
000070bab59d968d  jmp 0x000070BAB59D6265
000070bab59d9692  sub rsp, 0x08
000070bab59d9696  push rax
000070bab59d9697  push rcx
000070bab59d9698  push rdx
000070bab59d9699  push rdi
000070bab59d969a  push rsi
000070bab59d969b  push r8
000070bab59d969d  push r9
000070bab59d969f  push r10
000070bab59d96a1  push r11
000070bab59d96a3  sub rsp, 0xF0
000070bab59d96aa  vmovaps [rsp], xmm0
000070bab59d96af  vmovaps [rsp+0x10], xmm1
000070bab59d96b5  vmovaps [rsp+0x20], xmm2
000070bab59d96bb  vmovaps [rsp+0x30], xmm3
000070bab59d96c1  vmovaps [rsp+0x40], xmm5
000070bab59d96c7  vmovaps [rsp+0x50], xmm6
000070bab59d96cd  vmovaps [rsp+0x60], xmm7
000070bab59d96d3  vmovaps [rsp+0x70], xmm8
000070bab59d96d9  vmovaps [rsp+0x80], xmm9
000070bab59d96e2  vmovaps [rsp+0x90], xmm10
000070bab59d96eb  vmovaps [rsp+0xA0], xmm11
000070bab59d96f4  vmovaps [rsp+0xB0], xmm12
000070bab59d96fd  vmovaps [rsp+0xC0], xmm13
000070bab59d9706  vmovaps [rsp+0xD0], xmm14
000070bab59d970f  vmovaps [rsp+0xE0], xmm15
000070bab59d9718  sub rsp, 0x30
000070bab59d971c  movaps [rsp], xmm4
000070bab59d9720  movaps [rsp+0x10], xmm13
000070bab59d9726  movaps [rsp+0x20], xmm8
000070bab59d972c  lea rdi, [rsp]
000070bab59d9730  mov esi, 0x00
000070bab59d9735  mov rax, 0x63B35AFBC530
000070bab59d973f  call rax
000070bab59d9741  movaps xmm4, [rsp]
000070bab59d9745  add rsp, 0x30
000070bab59d9749  vmovaps xmm0, [rsp]
000070bab59d974e  vmovaps xmm1, [rsp+0x10]
000070bab59d9754  vmovaps xmm2, [rsp+0x20]
000070bab59d975a  vmovaps xmm3, [rsp+0x30]
000070bab59d9760  vmovaps xmm5, [rsp+0x40]
000070bab59d9766  vmovaps xmm6, [rsp+0x50]
000070bab59d976c  vmovaps xmm7, [rsp+0x60]
000070bab59d9772  vmovaps xmm8, [rsp+0x70]
000070bab59d9778  vmovaps xmm9, [rsp+0x80]
000070bab59d9781  vmovaps xmm10, [rsp+0x90]
000070bab59d978a  vmovaps xmm11, [rsp+0xA0]
000070bab59d9793  vmovaps xmm12, [rsp+0xB0]
000070bab59d979c  vmovaps xmm13, [rsp+0xC0]
000070bab59d97a5  vmovaps xmm14, [rsp+0xD0]
000070bab59d97ae  vmovaps xmm15, [rsp+0xE0]
000070bab59d97b7  add rsp, 0xF0
000070bab59d97be  pop r11
000070bab59d97c0  pop r10
000070bab59d97c2  pop r9
000070bab59d97c4  pop r8
000070bab59d97c6  pop rsi
000070bab59d97c7  pop rdi
000070bab59d97c8  pop rdx
000070bab59d97c9  pop rcx
000070bab59d97ca  pop rax
000070bab59d97cb  add rsp, 0x08
000070bab59d97cf  jmp 0x000070BAB59D628A
000070bab59d97d4  sub rsp, 0x08
000070bab59d97d8  push rax
000070bab59d97d9  push rcx
000070bab59d97da  push rdx
000070bab59d97db  push rdi
000070bab59d97dc  push rsi
000070bab59d97dd  push r8
000070bab59d97df  push r9
000070bab59d97e1  push r10
000070bab59d97e3  push r11
000070bab59d97e5  sub rsp, 0xF0
000070bab59d97ec  vmovaps [rsp], xmm0
000070bab59d97f1  vmovaps [rsp+0x10], xmm1
000070bab59d97f7  vmovaps [rsp+0x20], xmm2
000070bab59d97fd  vmovaps [rsp+0x30], xmm3
000070bab59d9803  vmovaps [rsp+0x40], xmm4
000070bab59d9809  vmovaps [rsp+0x50], xmm5
000070bab59d980f  vmovaps [rsp+0x60], xmm6
000070bab59d9815  vmovaps [rsp+0x70], xmm7
000070bab59d981b  vmovaps [rsp+0x80], xmm8
000070bab59d9824  vmovaps [rsp+0x90], xmm9
000070bab59d982d  vmovaps [rsp+0xA0], xmm10
000070bab59d9836  vmovaps [rsp+0xB0], xmm11
000070bab59d983f  vmovaps [rsp+0xC0], xmm12
000070bab59d9848  vmovaps [rsp+0xD0], xmm14
000070bab59d9851  vmovaps [rsp+0xE0], xmm15
000070bab59d985a  sub rsp, 0x30
000070bab59d985e  movaps [rsp], xmm13
000070bab59d9863  movaps [rsp+0x10], xmm15
000070bab59d9869  movaps [rsp+0x20], xmm9
000070bab59d986f  lea rdi, [rsp]
000070bab59d9873  mov esi, 0x00
000070bab59d9878  mov rax, 0x63B35AFBC530
000070bab59d9882  call rax
000070bab59d9884  movaps xmm13, [rsp]
000070bab59d9889  add rsp, 0x30
000070bab59d988d  vmovaps xmm0, [rsp]
000070bab59d9892  vmovaps xmm1, [rsp+0x10]
000070bab59d9898  vmovaps xmm2, [rsp+0x20]
000070bab59d989e  vmovaps xmm3, [rsp+0x30]
000070bab59d98a4  vmovaps xmm4, [rsp+0x40]
000070bab59d98aa  vmovaps xmm5, [rsp+0x50]
000070bab59d98b0  vmovaps xmm6, [rsp+0x60]
000070bab59d98b6  vmovaps xmm7, [rsp+0x70]
000070bab59d98bc  vmovaps xmm8, [rsp+0x80]
000070bab59d98c5  vmovaps xmm9, [rsp+0x90]
000070bab59d98ce  vmovaps xmm10, [rsp+0xA0]
000070bab59d98d7  vmovaps xmm11, [rsp+0xB0]
000070bab59d98e0  vmovaps xmm12, [rsp+0xC0]
000070bab59d98e9  vmovaps xmm14, [rsp+0xD0]
000070bab59d98f2  vmovaps xmm15, [rsp+0xE0]
000070bab59d98fb  add rsp, 0xF0
000070bab59d9902  pop r11
000070bab59d9904  pop r10
000070bab59d9906  pop r9
000070bab59d9908  pop r8
000070bab59d990a  pop rsi
000070bab59d990b  pop rdi
000070bab59d990c  pop rdx
000070bab59d990d  pop rcx
000070bab59d990e  pop rax
000070bab59d990f  add rsp, 0x08
000070bab59d9913  jmp 0x000070BAB59D62A5
000070bab59d9918  sub rsp, 0x08
000070bab59d991c  push rax
000070bab59d991d  push rcx
000070bab59d991e  push rdx
000070bab59d991f  push rdi
000070bab59d9920  push rsi
000070bab59d9921  push r8
000070bab59d9923  push r9
000070bab59d9925  push r10
000070bab59d9927  push r11
000070bab59d9929  sub rsp, 0xF0
000070bab59d9930  vmovaps [rsp], xmm0
000070bab59d9935  vmovaps [rsp+0x10], xmm1
000070bab59d993b  vmovaps [rsp+0x20], xmm2
000070bab59d9941  vmovaps [rsp+0x30], xmm3
000070bab59d9947  vmovaps [rsp+0x40], xmm4
000070bab59d994d  vmovaps [rsp+0x50], xmm5
000070bab59d9953  vmovaps [rsp+0x60], xmm6
000070bab59d9959  vmovaps [rsp+0x70], xmm7
000070bab59d995f  vmovaps [rsp+0x80], xmm8
000070bab59d9968  vmovaps [rsp+0x90], xmm9
000070bab59d9971  vmovaps [rsp+0xA0], xmm10
000070bab59d997a  vmovaps [rsp+0xB0], xmm11
000070bab59d9983  vmovaps [rsp+0xC0], xmm12
000070bab59d998c  vmovaps [rsp+0xD0], xmm13
000070bab59d9995  vmovaps [rsp+0xE0], xmm14
000070bab59d999e  sub rsp, 0x30
000070bab59d99a2  movaps [rsp], xmm15
000070bab59d99a7  movaps [rsp+0x10], xmm1
000070bab59d99ac  movaps [rsp+0x20], xmm5
000070bab59d99b1  lea rdi, [rsp]
000070bab59d99b5  mov esi, 0x00
000070bab59d99ba  mov rax, 0x63B35AFBC530
000070bab59d99c4  call rax
000070bab59d99c6  movaps xmm15, [rsp]
000070bab59d99cb  add rsp, 0x30
000070bab59d99cf  vmovaps xmm0, [rsp]
000070bab59d99d4  vmovaps xmm1, [rsp+0x10]
000070bab59d99da  vmovaps xmm2, [rsp+0x20]
000070bab59d99e0  vmovaps xmm3, [rsp+0x30]
000070bab59d99e6  vmovaps xmm4, [rsp+0x40]
000070bab59d99ec  vmovaps xmm5, [rsp+0x50]
000070bab59d99f2  vmovaps xmm6, [rsp+0x60]
000070bab59d99f8  vmovaps xmm7, [rsp+0x70]
000070bab59d99fe  vmovaps xmm8, [rsp+0x80]
000070bab59d9a07  vmovaps xmm9, [rsp+0x90]
000070bab59d9a10  vmovaps xmm10, [rsp+0xA0]
000070bab59d9a19  vmovaps xmm11, [rsp+0xB0]
000070bab59d9a22  vmovaps xmm12, [rsp+0xC0]
000070bab59d9a2b  vmovaps xmm13, [rsp+0xD0]
000070bab59d9a34  vmovaps xmm14, [rsp+0xE0]
000070bab59d9a3d  add rsp, 0xF0
000070bab59d9a44  pop r11
000070bab59d9a46  pop r10
000070bab59d9a48  pop r9
000070bab59d9a4a  pop r8
000070bab59d9a4c  pop rsi
000070bab59d9a4d  pop rdi
000070bab59d9a4e  pop rdx
000070bab59d9a4f  pop rcx
000070bab59d9a50  pop rax
000070bab59d9a51  add rsp, 0x08
000070bab59d9a55  jmp 0x000070BAB59D62C0
000070bab59d9a5a  call 0x000070BAB58D64F0
000070bab59d9a5f  jmp 0x000070BAB59D631B
000070bab59d9a64  sub rsp, 0x08
000070bab59d9a68  push rax
000070bab59d9a69  push rcx
000070bab59d9a6a  push rdx
000070bab59d9a6b  push rdi
000070bab59d9a6c  push rsi
000070bab59d9a6d  push r8
000070bab59d9a6f  push r9
000070bab59d9a71  push r10
000070bab59d9a73  push r11
000070bab59d9a75  sub rsp, 0xF0
000070bab59d9a7c  vmovaps [rsp], xmm0
000070bab59d9a81  vmovaps [rsp+0x10], xmm1
000070bab59d9a87  vmovaps [rsp+0x20], xmm2
000070bab59d9a8d  vmovaps [rsp+0x30], xmm3
000070bab59d9a93  vmovaps [rsp+0x40], xmm4
000070bab59d9a99  vmovaps [rsp+0x50], xmm5
000070bab59d9a9f  vmovaps [rsp+0x60], xmm6
000070bab59d9aa5  vmovaps [rsp+0x70], xmm7
000070bab59d9aab  vmovaps [rsp+0x80], xmm8
000070bab59d9ab4  vmovaps [rsp+0x90], xmm10
000070bab59d9abd  vmovaps [rsp+0xA0], xmm11
000070bab59d9ac6  vmovaps [rsp+0xB0], xmm12
000070bab59d9acf  vmovaps [rsp+0xC0], xmm13
000070bab59d9ad8  vmovaps [rsp+0xD0], xmm14
000070bab59d9ae1  vmovaps [rsp+0xE0], xmm15
000070bab59d9aea  sub rsp, 0x30
000070bab59d9aee  movaps [rsp], xmm9
000070bab59d9af3  movaps [rsp+0x10], xmm8
000070bab59d9af9  movaps [rsp+0x20], xmm11
000070bab59d9aff  lea rdi, [rsp]
000070bab59d9b03  mov esi, 0x00
000070bab59d9b08  mov rax, 0x63B35AFBC530
000070bab59d9b12  call rax
000070bab59d9b14  movaps xmm9, [rsp]
000070bab59d9b19  add rsp, 0x30
000070bab59d9b1d  vmovaps xmm0, [rsp]
000070bab59d9b22  vmovaps xmm1, [rsp+0x10]
000070bab59d9b28  vmovaps xmm2, [rsp+0x20]
000070bab59d9b2e  vmovaps xmm3, [rsp+0x30]
000070bab59d9b34  vmovaps xmm4, [rsp+0x40]
000070bab59d9b3a  vmovaps xmm5, [rsp+0x50]
000070bab59d9b40  vmovaps xmm6, [rsp+0x60]
000070bab59d9b46  vmovaps xmm7, [rsp+0x70]
000070bab59d9b4c  vmovaps xmm8, [rsp+0x80]
000070bab59d9b55  vmovaps xmm10, [rsp+0x90]
000070bab59d9b5e  vmovaps xmm11, [rsp+0xA0]
000070bab59d9b67  vmovaps xmm12, [rsp+0xB0]
000070bab59d9b70  vmovaps xmm13, [rsp+0xC0]
000070bab59d9b79  vmovaps xmm14, [rsp+0xD0]
000070bab59d9b82  vmovaps xmm15, [rsp+0xE0]
000070bab59d9b8b  add rsp, 0xF0
000070bab59d9b92  pop r11
000070bab59d9b94  pop r10
000070bab59d9b96  pop r9
000070bab59d9b98  pop r8
000070bab59d9b9a  pop rsi
000070bab59d9b9b  pop rdi
000070bab59d9b9c  pop rdx
000070bab59d9b9d  pop rcx
000070bab59d9b9e  pop rax
000070bab59d9b9f  add rsp, 0x08
000070bab59d9ba3  jmp 0x000070BAB59D6352
000070bab59d9ba8  sub rsp, 0x08
000070bab59d9bac  push rax
000070bab59d9bad  push rcx
000070bab59d9bae  push rdx
000070bab59d9baf  push rdi
000070bab59d9bb0  push rsi
000070bab59d9bb1  push r8
000070bab59d9bb3  push r9
000070bab59d9bb5  push r10
000070bab59d9bb7  push r11
000070bab59d9bb9  sub rsp, 0xF0
000070bab59d9bc0  vmovaps [rsp], xmm0
000070bab59d9bc5  vmovaps [rsp+0x10], xmm1
000070bab59d9bcb  vmovaps [rsp+0x20], xmm2
000070bab59d9bd1  vmovaps [rsp+0x30], xmm3
000070bab59d9bd7  vmovaps [rsp+0x40], xmm4
000070bab59d9bdd  vmovaps [rsp+0x50], xmm5
000070bab59d9be3  vmovaps [rsp+0x60], xmm6
000070bab59d9be9  vmovaps [rsp+0x70], xmm7
000070bab59d9bef  vmovaps [rsp+0x80], xmm8
000070bab59d9bf8  vmovaps [rsp+0x90], xmm9
000070bab59d9c01  vmovaps [rsp+0xA0], xmm10
000070bab59d9c0a  vmovaps [rsp+0xB0], xmm12
000070bab59d9c13  vmovaps [rsp+0xC0], xmm13
000070bab59d9c1c  vmovaps [rsp+0xD0], xmm14
000070bab59d9c25  vmovaps [rsp+0xE0], xmm15
000070bab59d9c2e  sub rsp, 0x30
000070bab59d9c32  movaps [rsp], xmm11
000070bab59d9c37  movaps [rsp+0x10], xmm10
000070bab59d9c3d  movaps [rsp+0x20], xmm6
000070bab59d9c42  lea rdi, [rsp]
000070bab59d9c46  mov esi, 0x00
000070bab59d9c4b  mov rax, 0x63B35AFBC530
000070bab59d9c55  call rax
000070bab59d9c57  movaps xmm11, [rsp]
000070bab59d9c5c  add rsp, 0x30
000070bab59d9c60  vmovaps xmm0, [rsp]
000070bab59d9c65  vmovaps xmm1, [rsp+0x10]
000070bab59d9c6b  vmovaps xmm2, [rsp+0x20]
000070bab59d9c71  vmovaps xmm3, [rsp+0x30]
000070bab59d9c77  vmovaps xmm4, [rsp+0x40]
000070bab59d9c7d  vmovaps xmm5, [rsp+0x50]
000070bab59d9c83  vmovaps xmm6, [rsp+0x60]
000070bab59d9c89  vmovaps xmm7, [rsp+0x70]
000070bab59d9c8f  vmovaps xmm8, [rsp+0x80]
000070bab59d9c98  vmovaps xmm9, [rsp+0x90]
000070bab59d9ca1  vmovaps xmm10, [rsp+0xA0]
000070bab59d9caa  vmovaps xmm12, [rsp+0xB0]
000070bab59d9cb3  vmovaps xmm13, [rsp+0xC0]
000070bab59d9cbc  vmovaps xmm14, [rsp+0xD0]
000070bab59d9cc5  vmovaps xmm15, [rsp+0xE0]
000070bab59d9cce  add rsp, 0xF0
000070bab59d9cd5  pop r11
000070bab59d9cd7  pop r10
000070bab59d9cd9  pop r9
000070bab59d9cdb  pop r8
000070bab59d9cdd  pop rsi
000070bab59d9cde  pop rdi
000070bab59d9cdf  pop rdx
000070bab59d9ce0  pop rcx
000070bab59d9ce1  pop rax
000070bab59d9ce2  add rsp, 0x08
000070bab59d9ce6  jmp 0x000070BAB59D636D
000070bab59d9ceb  sub rsp, 0x08
000070bab59d9cef  push rax
000070bab59d9cf0  push rcx
000070bab59d9cf1  push rdx
000070bab59d9cf2  push rdi
000070bab59d9cf3  push rsi
000070bab59d9cf4  push r8
000070bab59d9cf6  push r9
000070bab59d9cf8  push r10
000070bab59d9cfa  push r11
000070bab59d9cfc  sub rsp, 0xF0
000070bab59d9d03  vmovaps [rsp], xmm0
000070bab59d9d08  vmovaps [rsp+0x10], xmm1
000070bab59d9d0e  vmovaps [rsp+0x20], xmm2
000070bab59d9d14  vmovaps [rsp+0x30], xmm3
000070bab59d9d1a  vmovaps [rsp+0x40], xmm4
000070bab59d9d20  vmovaps [rsp+0x50], xmm5
000070bab59d9d26  vmovaps [rsp+0x60], xmm6
000070bab59d9d2c  vmovaps [rsp+0x70], xmm7
000070bab59d9d32  vmovaps [rsp+0x80], xmm8
000070bab59d9d3b  vmovaps [rsp+0x90], xmm9
000070bab59d9d44  vmovaps [rsp+0xA0], xmm11
000070bab59d9d4d  vmovaps [rsp+0xB0], xmm12
000070bab59d9d56  vmovaps [rsp+0xC0], xmm13
000070bab59d9d5f  vmovaps [rsp+0xD0], xmm14
000070bab59d9d68  vmovaps [rsp+0xE0], xmm15
000070bab59d9d71  sub rsp, 0x30
000070bab59d9d75  movaps [rsp], xmm10
000070bab59d9d7a  movaps [rsp+0x10], xmm14
000070bab59d9d80  movaps [rsp+0x20], xmm4
000070bab59d9d85  lea rdi, [rsp]
000070bab59d9d89  mov esi, 0x00
000070bab59d9d8e  mov rax, 0x63B35AFBC530
000070bab59d9d98  call rax
000070bab59d9d9a  movaps xmm10, [rsp]
000070bab59d9d9f  add rsp, 0x30
000070bab59d9da3  vmovaps xmm0, [rsp]
000070bab59d9da8  vmovaps xmm1, [rsp+0x10]
000070bab59d9dae  vmovaps xmm2, [rsp+0x20]
000070bab59d9db4  vmovaps xmm3, [rsp+0x30]
000070bab59d9dba  vmovaps xmm4, [rsp+0x40]
000070bab59d9dc0  vmovaps xmm5, [rsp+0x50]
000070bab59d9dc6  vmovaps xmm6, [rsp+0x60]
000070bab59d9dcc  vmovaps xmm7, [rsp+0x70]
000070bab59d9dd2  vmovaps xmm8, [rsp+0x80]
000070bab59d9ddb  vmovaps xmm9, [rsp+0x90]
000070bab59d9de4  vmovaps xmm11, [rsp+0xA0]
000070bab59d9ded  vmovaps xmm12, [rsp+0xB0]
000070bab59d9df6  vmovaps xmm13, [rsp+0xC0]
000070bab59d9dff  vmovaps xmm14, [rsp+0xD0]
000070bab59d9e08  vmovaps xmm15, [rsp+0xE0]
000070bab59d9e11  add rsp, 0xF0
000070bab59d9e18  pop r11
000070bab59d9e1a  pop r10
000070bab59d9e1c  pop r9
000070bab59d9e1e  pop r8
000070bab59d9e20  pop rsi
000070bab59d9e21  pop rdi
000070bab59d9e22  pop rdx
000070bab59d9e23  pop rcx
000070bab59d9e24  pop rax
000070bab59d9e25  add rsp, 0x08
000070bab59d9e29  jmp 0x000070BAB59D6388
000070bab59d9e2e  sub rsp, 0x08
000070bab59d9e32  push rax
000070bab59d9e33  push rcx
000070bab59d9e34  push rdx
000070bab59d9e35  push rdi
000070bab59d9e36  push rsi
000070bab59d9e37  push r8
000070bab59d9e39  push r9
000070bab59d9e3b  push r10
000070bab59d9e3d  push r11
000070bab59d9e3f  sub rsp, 0xF0
000070bab59d9e46  vmovaps [rsp], xmm0
000070bab59d9e4b  vmovaps [rsp+0x10], xmm1
000070bab59d9e51  vmovaps [rsp+0x20], xmm2
000070bab59d9e57  vmovaps [rsp+0x30], xmm3
000070bab59d9e5d  vmovaps [rsp+0x40], xmm4
000070bab59d9e63  vmovaps [rsp+0x50], xmm5
000070bab59d9e69  vmovaps [rsp+0x60], xmm6
000070bab59d9e6f  vmovaps [rsp+0x70], xmm7
000070bab59d9e75  vmovaps [rsp+0x80], xmm9
000070bab59d9e7e  vmovaps [rsp+0x90], xmm10
000070bab59d9e87  vmovaps [rsp+0xA0], xmm11
000070bab59d9e90  vmovaps [rsp+0xB0], xmm12
000070bab59d9e99  vmovaps [rsp+0xC0], xmm13
000070bab59d9ea2  vmovaps [rsp+0xD0], xmm14
000070bab59d9eab  vmovaps [rsp+0xE0], xmm15
000070bab59d9eb4  sub rsp, 0x30
000070bab59d9eb8  movaps [rsp], xmm8
000070bab59d9ebd  movaps [rsp+0x10], xmm1
000070bab59d9ec2  movaps [rsp+0x20], xmm14
000070bab59d9ec8  lea rdi, [rsp]
000070bab59d9ecc  mov esi, 0x00
000070bab59d9ed1  mov rax, 0x63B35AFBC530
000070bab59d9edb  call rax
000070bab59d9edd  movaps xmm8, [rsp]
000070bab59d9ee2  add rsp, 0x30
000070bab59d9ee6  vmovaps xmm0, [rsp]
000070bab59d9eeb  vmovaps xmm1, [rsp+0x10]
000070bab59d9ef1  vmovaps xmm2, [rsp+0x20]
000070bab59d9ef7  vmovaps xmm3, [rsp+0x30]
000070bab59d9efd  vmovaps xmm4, [rsp+0x40]
000070bab59d9f03  vmovaps xmm5, [rsp+0x50]
000070bab59d9f09  vmovaps xmm6, [rsp+0x60]
000070bab59d9f0f  vmovaps xmm7, [rsp+0x70]
000070bab59d9f15  vmovaps xmm9, [rsp+0x80]
000070bab59d9f1e  vmovaps xmm10, [rsp+0x90]
000070bab59d9f27  vmovaps xmm11, [rsp+0xA0]
000070bab59d9f30  vmovaps xmm12, [rsp+0xB0]
000070bab59d9f39  vmovaps xmm13, [rsp+0xC0]
000070bab59d9f42  vmovaps xmm14, [rsp+0xD0]
000070bab59d9f4b  vmovaps xmm15, [rsp+0xE0]
000070bab59d9f54  add rsp, 0xF0
000070bab59d9f5b  pop r11
000070bab59d9f5d  pop r10
000070bab59d9f5f  pop r9
000070bab59d9f61  pop r8
000070bab59d9f63  pop rsi
000070bab59d9f64  pop rdi
000070bab59d9f65  pop rdx
000070bab59d9f66  pop rcx
000070bab59d9f67  pop rax
000070bab59d9f68  add rsp, 0x08
000070bab59d9f6c  jmp 0x000070BAB59D63AE
000070bab59d9f71  sub rsp, 0x08
000070bab59d9f75  push rax
000070bab59d9f76  push rcx
000070bab59d9f77  push rdx
000070bab59d9f78  push rdi
000070bab59d9f79  push rsi
000070bab59d9f7a  push r8
000070bab59d9f7c  push r9
000070bab59d9f7e  push r10
000070bab59d9f80  push r11
000070bab59d9f82  sub rsp, 0xF0
000070bab59d9f89  vmovaps [rsp], xmm0
000070bab59d9f8e  vmovaps [rsp+0x10], xmm1
000070bab59d9f94  vmovaps [rsp+0x20], xmm2
000070bab59d9f9a  vmovaps [rsp+0x30], xmm3
000070bab59d9fa0  vmovaps [rsp+0x40], xmm4
000070bab59d9fa6  vmovaps [rsp+0x50], xmm5
000070bab59d9fac  vmovaps [rsp+0x60], xmm7
000070bab59d9fb2  vmovaps [rsp+0x70], xmm8
000070bab59d9fb8  vmovaps [rsp+0x80], xmm9
000070bab59d9fc1  vmovaps [rsp+0x90], xmm10
000070bab59d9fca  vmovaps [rsp+0xA0], xmm11
000070bab59d9fd3  vmovaps [rsp+0xB0], xmm12
000070bab59d9fdc  vmovaps [rsp+0xC0], xmm13
000070bab59d9fe5  vmovaps [rsp+0xD0], xmm14
000070bab59d9fee  vmovaps [rsp+0xE0], xmm15
000070bab59d9ff7  sub rsp, 0x30
000070bab59d9ffb  movaps [rsp], xmm6
000070bab59d9fff  movaps [rsp+0x10], xmm1
000070bab59da004  movaps [rsp+0x20], xmm14
000070bab59da00a  lea rdi, [rsp]
000070bab59da00e  mov esi, 0x00
000070bab59da013  mov rax, 0x63B35AFBC530
000070bab59da01d  call rax
000070bab59da01f  movaps xmm6, [rsp]
000070bab59da023  add rsp, 0x30
000070bab59da027  vmovaps xmm0, [rsp]
000070bab59da02c  vmovaps xmm1, [rsp+0x10]
000070bab59da032  vmovaps xmm2, [rsp+0x20]
000070bab59da038  vmovaps xmm3, [rsp+0x30]
000070bab59da03e  vmovaps xmm4, [rsp+0x40]
000070bab59da044  vmovaps xmm5, [rsp+0x50]
000070bab59da04a  vmovaps xmm7, [rsp+0x60]
000070bab59da050  vmovaps xmm8, [rsp+0x70]
000070bab59da056  vmovaps xmm9, [rsp+0x80]
000070bab59da05f  vmovaps xmm10, [rsp+0x90]
000070bab59da068  vmovaps xmm11, [rsp+0xA0]
000070bab59da071  vmovaps xmm12, [rsp+0xB0]
000070bab59da07a  vmovaps xmm13, [rsp+0xC0]
000070bab59da083  vmovaps xmm14, [rsp+0xD0]
000070bab59da08c  vmovaps xmm15, [rsp+0xE0]
000070bab59da095  add rsp, 0xF0
000070bab59da09c  pop r11
000070bab59da09e  pop r10
000070bab59da0a0  pop r9
000070bab59da0a2  pop r8
000070bab59da0a4  pop rsi
000070bab59da0a5  pop rdi
000070bab59da0a6  pop rdx
000070bab59da0a7  pop rcx
000070bab59da0a8  pop rax
000070bab59da0a9  add rsp, 0x08
000070bab59da0ad  jmp 0x000070BAB59D63DA
000070bab59da0b2  sub rsp, 0x08
000070bab59da0b6  push rax
000070bab59da0b7  push rcx
000070bab59da0b8  push rdx
000070bab59da0b9  push rdi
000070bab59da0ba  push rsi
000070bab59da0bb  push r8
000070bab59da0bd  push r9
000070bab59da0bf  push r10
000070bab59da0c1  push r11
000070bab59da0c3  sub rsp, 0xF0
000070bab59da0ca  vmovaps [rsp], xmm0
000070bab59da0cf  vmovaps [rsp+0x10], xmm1
000070bab59da0d5  vmovaps [rsp+0x20], xmm2
000070bab59da0db  vmovaps [rsp+0x30], xmm3
000070bab59da0e1  vmovaps [rsp+0x40], xmm4
000070bab59da0e7  vmovaps [rsp+0x50], xmm5
000070bab59da0ed  vmovaps [rsp+0x60], xmm6
000070bab59da0f3  vmovaps [rsp+0x70], xmm7
000070bab59da0f9  vmovaps [rsp+0x80], xmm8
000070bab59da102  vmovaps [rsp+0x90], xmm9
000070bab59da10b  vmovaps [rsp+0xA0], xmm10
000070bab59da114  vmovaps [rsp+0xB0], xmm11
000070bab59da11d  vmovaps [rsp+0xC0], xmm12
000070bab59da126  vmovaps [rsp+0xD0], xmm13
000070bab59da12f  vmovaps [rsp+0xE0], xmm15
000070bab59da138  sub rsp, 0x30
000070bab59da13c  movaps [rsp], xmm14
000070bab59da141  movaps [rsp+0x10], xmm12
000070bab59da147  movaps [rsp+0x20], xmm1
000070bab59da14c  lea rdi, [rsp]
000070bab59da150  mov esi, 0x00
000070bab59da155  mov rax, 0x63B35AFBC530
000070bab59da15f  call rax
000070bab59da161  movaps xmm14, [rsp]
000070bab59da166  add rsp, 0x30
000070bab59da16a  vmovaps xmm0, [rsp]
000070bab59da16f  vmovaps xmm1, [rsp+0x10]
000070bab59da175  vmovaps xmm2, [rsp+0x20]
000070bab59da17b  vmovaps xmm3, [rsp+0x30]
000070bab59da181  vmovaps xmm4, [rsp+0x40]
000070bab59da187  vmovaps xmm5, [rsp+0x50]
000070bab59da18d  vmovaps xmm6, [rsp+0x60]
000070bab59da193  vmovaps xmm7, [rsp+0x70]
000070bab59da199  vmovaps xmm8, [rsp+0x80]
000070bab59da1a2  vmovaps xmm9, [rsp+0x90]
000070bab59da1ab  vmovaps xmm10, [rsp+0xA0]
000070bab59da1b4  vmovaps xmm11, [rsp+0xB0]
000070bab59da1bd  vmovaps xmm12, [rsp+0xC0]
000070bab59da1c6  vmovaps xmm13, [rsp+0xD0]
000070bab59da1cf  vmovaps xmm15, [rsp+0xE0]
000070bab59da1d8  add rsp, 0xF0
000070bab59da1df  pop r11
000070bab59da1e1  pop r10
000070bab59da1e3  pop r9
000070bab59da1e5  pop r8
000070bab59da1e7  pop rsi
000070bab59da1e8  pop rdi
000070bab59da1e9  pop rdx
000070bab59da1ea  pop rcx
000070bab59da1eb  pop rax
000070bab59da1ec  add rsp, 0x08
000070bab59da1f0  jmp 0x000070BAB59D6400
000070bab59da1f5  sub rsp, 0x08
000070bab59da1f9  push rax
000070bab59da1fa  push rcx
000070bab59da1fb  push rdx
000070bab59da1fc  push rdi
000070bab59da1fd  push rsi
000070bab59da1fe  push r8
000070bab59da200  push r9
000070bab59da202  push r10
000070bab59da204  push r11
000070bab59da206  sub rsp, 0xF0
000070bab59da20d  vmovaps [rsp], xmm0
000070bab59da212  vmovaps [rsp+0x10], xmm2
000070bab59da218  vmovaps [rsp+0x20], xmm3
000070bab59da21e  vmovaps [rsp+0x30], xmm4
000070bab59da224  vmovaps [rsp+0x40], xmm5
000070bab59da22a  vmovaps [rsp+0x50], xmm6
000070bab59da230  vmovaps [rsp+0x60], xmm7
000070bab59da236  vmovaps [rsp+0x70], xmm8
000070bab59da23c  vmovaps [rsp+0x80], xmm9
000070bab59da245  vmovaps [rsp+0x90], xmm10
000070bab59da24e  vmovaps [rsp+0xA0], xmm11
000070bab59da257  vmovaps [rsp+0xB0], xmm12
000070bab59da260  vmovaps [rsp+0xC0], xmm13
000070bab59da269  vmovaps [rsp+0xD0], xmm14
000070bab59da272  vmovaps [rsp+0xE0], xmm15
000070bab59da27b  sub rsp, 0x30
000070bab59da27f  movaps [rsp], xmm1
000070bab59da283  movaps [rsp+0x10], xmm13
000070bab59da289  movaps [rsp+0x20], xmm9
000070bab59da28f  lea rdi, [rsp]
000070bab59da293  mov esi, 0x00
000070bab59da298  mov rax, 0x63B35AFBC530
000070bab59da2a2  call rax
000070bab59da2a4  movaps xmm1, [rsp]
000070bab59da2a8  add rsp, 0x30
000070bab59da2ac  vmovaps xmm0, [rsp]
000070bab59da2b1  vmovaps xmm2, [rsp+0x10]
000070bab59da2b7  vmovaps xmm3, [rsp+0x20]
000070bab59da2bd  vmovaps xmm4, [rsp+0x30]
000070bab59da2c3  vmovaps xmm5, [rsp+0x40]
000070bab59da2c9  vmovaps xmm6, [rsp+0x50]
000070bab59da2cf  vmovaps xmm7, [rsp+0x60]
000070bab59da2d5  vmovaps xmm8, [rsp+0x70]
000070bab59da2db  vmovaps xmm9, [rsp+0x80]
000070bab59da2e4  vmovaps xmm10, [rsp+0x90]
000070bab59da2ed  vmovaps xmm11, [rsp+0xA0]
000070bab59da2f6  vmovaps xmm12, [rsp+0xB0]
000070bab59da2ff  vmovaps xmm13, [rsp+0xC0]
000070bab59da308  vmovaps xmm14, [rsp+0xD0]
000070bab59da311  vmovaps xmm15, [rsp+0xE0]
000070bab59da31a  add rsp, 0xF0
000070bab59da321  pop r11
000070bab59da323  pop r10
000070bab59da325  pop r9
000070bab59da327  pop r8
000070bab59da329  pop rsi
000070bab59da32a  pop rdi
000070bab59da32b  pop rdx
000070bab59da32c  pop rcx
000070bab59da32d  pop rax
000070bab59da32e  add rsp, 0x08
000070bab59da332  jmp 0x000070BAB59D641A
000070bab59da337  sub rsp, 0x08
000070bab59da33b  push rax
000070bab59da33c  push rcx
000070bab59da33d  push rdx
000070bab59da33e  push rdi
000070bab59da33f  push rsi
000070bab59da340  push r8
000070bab59da342  push r9
000070bab59da344  push r10
000070bab59da346  push r11
000070bab59da348  sub rsp, 0xF0
000070bab59da34f  vmovaps [rsp], xmm0
000070bab59da354  vmovaps [rsp+0x10], xmm1
000070bab59da35a  vmovaps [rsp+0x20], xmm2
000070bab59da360  vmovaps [rsp+0x30], xmm3
000070bab59da366  vmovaps [rsp+0x40], xmm4
000070bab59da36c  vmovaps [rsp+0x50], xmm5
000070bab59da372  vmovaps [rsp+0x60], xmm6
000070bab59da378  vmovaps [rsp+0x70], xmm7
000070bab59da37e  vmovaps [rsp+0x80], xmm8
000070bab59da387  vmovaps [rsp+0x90], xmm9
000070bab59da390  vmovaps [rsp+0xA0], xmm10
000070bab59da399  vmovaps [rsp+0xB0], xmm11
000070bab59da3a2  vmovaps [rsp+0xC0], xmm13
000070bab59da3ab  vmovaps [rsp+0xD0], xmm14
000070bab59da3b4  vmovaps [rsp+0xE0], xmm15
000070bab59da3bd  sub rsp, 0x30
000070bab59da3c1  movaps [rsp], xmm12
000070bab59da3c6  movaps [rsp+0x10], xmm7
000070bab59da3cb  movaps [rsp+0x20], xmm13
000070bab59da3d1  lea rdi, [rsp]
000070bab59da3d5  mov esi, 0x00
000070bab59da3da  mov rax, 0x63B35AFBC530
000070bab59da3e4  call rax
000070bab59da3e6  movaps xmm12, [rsp]
000070bab59da3eb  add rsp, 0x30
000070bab59da3ef  vmovaps xmm0, [rsp]
000070bab59da3f4  vmovaps xmm1, [rsp+0x10]
000070bab59da3fa  vmovaps xmm2, [rsp+0x20]
000070bab59da400  vmovaps xmm3, [rsp+0x30]
000070bab59da406  vmovaps xmm4, [rsp+0x40]
000070bab59da40c  vmovaps xmm5, [rsp+0x50]
000070bab59da412  vmovaps xmm6, [rsp+0x60]
000070bab59da418  vmovaps xmm7, [rsp+0x70]
000070bab59da41e  vmovaps xmm8, [rsp+0x80]
000070bab59da427  vmovaps xmm9, [rsp+0x90]
000070bab59da430  vmovaps xmm10, [rsp+0xA0]
000070bab59da439  vmovaps xmm11, [rsp+0xB0]
000070bab59da442  vmovaps xmm13, [rsp+0xC0]
000070bab59da44b  vmovaps xmm14, [rsp+0xD0]
000070bab59da454  vmovaps xmm15, [rsp+0xE0]
000070bab59da45d  add rsp, 0xF0
000070bab59da464  pop r11
000070bab59da466  pop r10
000070bab59da468  pop r9
000070bab59da46a  pop r8
000070bab59da46c  pop rsi
000070bab59da46d  pop rdi
000070bab59da46e  pop rdx
000070bab59da46f  pop rcx
000070bab59da470  pop rax
000070bab59da471  add rsp, 0x08
000070bab59da475  jmp 0x000070BAB59D6441
000070bab59da47a  sub rsp, 0x08
000070bab59da47e  push rax
000070bab59da47f  push rcx
000070bab59da480  push rdx
000070bab59da481  push rdi
000070bab59da482  push rsi
000070bab59da483  push r8
000070bab59da485  push r9
000070bab59da487  push r10
000070bab59da489  push r11
000070bab59da48b  sub rsp, 0xF0
000070bab59da492  vmovaps [rsp], xmm0
000070bab59da497  vmovaps [rsp+0x10], xmm1
000070bab59da49d  vmovaps [rsp+0x20], xmm2
000070bab59da4a3  vmovaps [rsp+0x30], xmm3
000070bab59da4a9  vmovaps [rsp+0x40], xmm4
000070bab59da4af  vmovaps [rsp+0x50], xmm5
000070bab59da4b5  vmovaps [rsp+0x60], xmm6
000070bab59da4bb  vmovaps [rsp+0x70], xmm7
000070bab59da4c1  vmovaps [rsp+0x80], xmm8
000070bab59da4ca  vmovaps [rsp+0x90], xmm9
000070bab59da4d3  vmovaps [rsp+0xA0], xmm10
000070bab59da4dc  vmovaps [rsp+0xB0], xmm11
000070bab59da4e5  vmovaps [rsp+0xC0], xmm12
000070bab59da4ee  vmovaps [rsp+0xD0], xmm14
000070bab59da4f7  vmovaps [rsp+0xE0], xmm15
000070bab59da500  sub rsp, 0x30
000070bab59da504  movaps [rsp], xmm13
000070bab59da509  movaps [rsp+0x10], xmm15
000070bab59da50f  movaps [rsp+0x20], xmm8
000070bab59da515  lea rdi, [rsp]
000070bab59da519  mov esi, 0x00
000070bab59da51e  mov rax, 0x63B35AFBC530
000070bab59da528  call rax
000070bab59da52a  movaps xmm13, [rsp]
000070bab59da52f  add rsp, 0x30
000070bab59da533  vmovaps xmm0, [rsp]
000070bab59da538  vmovaps xmm1, [rsp+0x10]
000070bab59da53e  vmovaps xmm2, [rsp+0x20]
000070bab59da544  vmovaps xmm3, [rsp+0x30]
000070bab59da54a  vmovaps xmm4, [rsp+0x40]
000070bab59da550  vmovaps xmm5, [rsp+0x50]
000070bab59da556  vmovaps xmm6, [rsp+0x60]
000070bab59da55c  vmovaps xmm7, [rsp+0x70]
000070bab59da562  vmovaps xmm8, [rsp+0x80]
000070bab59da56b  vmovaps xmm9, [rsp+0x90]
000070bab59da574  vmovaps xmm10, [rsp+0xA0]
000070bab59da57d  vmovaps xmm11, [rsp+0xB0]
000070bab59da586  vmovaps xmm12, [rsp+0xC0]
000070bab59da58f  vmovaps xmm14, [rsp+0xD0]
000070bab59da598  vmovaps xmm15, [rsp+0xE0]
000070bab59da5a1  add rsp, 0xF0
000070bab59da5a8  pop r11
000070bab59da5aa  pop r10
000070bab59da5ac  pop r9
000070bab59da5ae  pop r8
000070bab59da5b0  pop rsi
000070bab59da5b1  pop rdi
000070bab59da5b2  pop rdx
000070bab59da5b3  pop rcx
000070bab59da5b4  pop rax
000070bab59da5b5  add rsp, 0x08
000070bab59da5b9  jmp 0x000070BAB59D645C
000070bab59da5be  sub rsp, 0x08
000070bab59da5c2  push rax
000070bab59da5c3  push rcx
000070bab59da5c4  push rdx
000070bab59da5c5  push rdi
000070bab59da5c6  push rsi
000070bab59da5c7  push r8
000070bab59da5c9  push r9
000070bab59da5cb  push r10
000070bab59da5cd  push r11
000070bab59da5cf  sub rsp, 0xF0
000070bab59da5d6  vmovaps [rsp], xmm0
000070bab59da5db  vmovaps [rsp+0x10], xmm1
000070bab59da5e1  vmovaps [rsp+0x20], xmm2
000070bab59da5e7  vmovaps [rsp+0x30], xmm3
000070bab59da5ed  vmovaps [rsp+0x40], xmm4
000070bab59da5f3  vmovaps [rsp+0x50], xmm5
000070bab59da5f9  vmovaps [rsp+0x60], xmm6
000070bab59da5ff  vmovaps [rsp+0x70], xmm7
000070bab59da605  vmovaps [rsp+0x80], xmm9
000070bab59da60e  vmovaps [rsp+0x90], xmm10
000070bab59da617  vmovaps [rsp+0xA0], xmm11
000070bab59da620  vmovaps [rsp+0xB0], xmm12
000070bab59da629  vmovaps [rsp+0xC0], xmm13
000070bab59da632  vmovaps [rsp+0xD0], xmm14
000070bab59da63b  vmovaps [rsp+0xE0], xmm15
000070bab59da644  sub rsp, 0x30
000070bab59da648  movaps [rsp], xmm8
000070bab59da64d  movaps [rsp+0x10], xmm15
000070bab59da653  movaps [rsp+0x20], xmm9
000070bab59da659  lea rdi, [rsp]
000070bab59da65d  mov esi, 0x00
000070bab59da662  mov rax, 0x63B35AFBC530
000070bab59da66c  call rax
000070bab59da66e  movaps xmm8, [rsp]
000070bab59da673  add rsp, 0x30
000070bab59da677  vmovaps xmm0, [rsp]
000070bab59da67c  vmovaps xmm1, [rsp+0x10]
000070bab59da682  vmovaps xmm2, [rsp+0x20]
000070bab59da688  vmovaps xmm3, [rsp+0x30]
000070bab59da68e  vmovaps xmm4, [rsp+0x40]
000070bab59da694  vmovaps xmm5, [rsp+0x50]
000070bab59da69a  vmovaps xmm6, [rsp+0x60]
000070bab59da6a0  vmovaps xmm7, [rsp+0x70]
000070bab59da6a6  vmovaps xmm9, [rsp+0x80]
000070bab59da6af  vmovaps xmm10, [rsp+0x90]
000070bab59da6b8  vmovaps xmm11, [rsp+0xA0]
000070bab59da6c1  vmovaps xmm12, [rsp+0xB0]
000070bab59da6ca  vmovaps xmm13, [rsp+0xC0]
000070bab59da6d3  vmovaps xmm14, [rsp+0xD0]
000070bab59da6dc  vmovaps xmm15, [rsp+0xE0]
000070bab59da6e5  add rsp, 0xF0
000070bab59da6ec  pop r11
000070bab59da6ee  pop r10
000070bab59da6f0  pop r9
000070bab59da6f2  pop r8
000070bab59da6f4  pop rsi
000070bab59da6f5  pop rdi
000070bab59da6f6  pop rdx
000070bab59da6f7  pop rcx
000070bab59da6f8  pop rax
000070bab59da6f9  add rsp, 0x08
000070bab59da6fd  jmp 0x000070BAB59D648A
000070bab59da702  sub rsp, 0x08
000070bab59da706  push rax
000070bab59da707  push rcx
000070bab59da708  push rdx
000070bab59da709  push rdi
000070bab59da70a  push rsi
000070bab59da70b  push r8
000070bab59da70d  push r9
000070bab59da70f  push r10
000070bab59da711  push r11
000070bab59da713  sub rsp, 0xF0
000070bab59da71a  vmovaps [rsp], xmm0
000070bab59da71f  vmovaps [rsp+0x10], xmm1
000070bab59da725  vmovaps [rsp+0x20], xmm2
000070bab59da72b  vmovaps [rsp+0x30], xmm3
000070bab59da731  vmovaps [rsp+0x40], xmm4
000070bab59da737  vmovaps [rsp+0x50], xmm5
000070bab59da73d  vmovaps [rsp+0x60], xmm6
000070bab59da743  vmovaps [rsp+0x70], xmm7
000070bab59da749  vmovaps [rsp+0x80], xmm8
000070bab59da752  vmovaps [rsp+0x90], xmm9
000070bab59da75b  vmovaps [rsp+0xA0], xmm10
000070bab59da764  vmovaps [rsp+0xB0], xmm11
000070bab59da76d  vmovaps [rsp+0xC0], xmm12
000070bab59da776  vmovaps [rsp+0xD0], xmm13
000070bab59da77f  vmovaps [rsp+0xE0], xmm14
000070bab59da788  sub rsp, 0x30
000070bab59da78c  movaps [rsp], xmm15
000070bab59da791  movaps [rsp+0x10], xmm11
000070bab59da797  movaps [rsp+0x20], xmm6
000070bab59da79c  lea rdi, [rsp]
000070bab59da7a0  mov esi, 0x00
000070bab59da7a5  mov rax, 0x63B35AFBC530
000070bab59da7af  call rax
000070bab59da7b1  movaps xmm15, [rsp]
000070bab59da7b6  add rsp, 0x30
000070bab59da7ba  vmovaps xmm0, [rsp]
000070bab59da7bf  vmovaps xmm1, [rsp+0x10]
000070bab59da7c5  vmovaps xmm2, [rsp+0x20]
000070bab59da7cb  vmovaps xmm3, [rsp+0x30]
000070bab59da7d1  vmovaps xmm4, [rsp+0x40]
000070bab59da7d7  vmovaps xmm5, [rsp+0x50]
000070bab59da7dd  vmovaps xmm6, [rsp+0x60]
000070bab59da7e3  vmovaps xmm7, [rsp+0x70]
000070bab59da7e9  vmovaps xmm8, [rsp+0x80]
000070bab59da7f2  vmovaps xmm9, [rsp+0x90]
000070bab59da7fb  vmovaps xmm10, [rsp+0xA0]
000070bab59da804  vmovaps xmm11, [rsp+0xB0]
000070bab59da80d  vmovaps xmm12, [rsp+0xC0]
000070bab59da816  vmovaps xmm13, [rsp+0xD0]
000070bab59da81f  vmovaps xmm14, [rsp+0xE0]
000070bab59da828  add rsp, 0xF0
000070bab59da82f  pop r11
000070bab59da831  pop r10
000070bab59da833  pop r9
000070bab59da835  pop r8
000070bab59da837  pop rsi
000070bab59da838  pop rdi
000070bab59da839  pop rdx
000070bab59da83a  pop rcx
000070bab59da83b  pop rax
000070bab59da83c  add rsp, 0x08
000070bab59da840  jmp 0x000070BAB59D64A5
000070bab59da845  sub rsp, 0x08
000070bab59da849  push rax
000070bab59da84a  push rcx
000070bab59da84b  push rdx
000070bab59da84c  push rdi
000070bab59da84d  push rsi
000070bab59da84e  push r8
000070bab59da850  push r9
000070bab59da852  push r10
000070bab59da854  push r11
000070bab59da856  sub rsp, 0xF0
000070bab59da85d  vmovaps [rsp], xmm0
000070bab59da862  vmovaps [rsp+0x10], xmm1
000070bab59da868  vmovaps [rsp+0x20], xmm2
000070bab59da86e  vmovaps [rsp+0x30], xmm3
000070bab59da874  vmovaps [rsp+0x40], xmm4
000070bab59da87a  vmovaps [rsp+0x50], xmm5
000070bab59da880  vmovaps [rsp+0x60], xmm6
000070bab59da886  vmovaps [rsp+0x70], xmm8
000070bab59da88c  vmovaps [rsp+0x80], xmm9
000070bab59da895  vmovaps [rsp+0x90], xmm10
000070bab59da89e  vmovaps [rsp+0xA0], xmm11
000070bab59da8a7  vmovaps [rsp+0xB0], xmm12
000070bab59da8b0  vmovaps [rsp+0xC0], xmm13
000070bab59da8b9  vmovaps [rsp+0xD0], xmm14
000070bab59da8c2  vmovaps [rsp+0xE0], xmm15
000070bab59da8cb  sub rsp, 0x30
000070bab59da8cf  movaps [rsp], xmm7
000070bab59da8d3  movaps [rsp+0x10], xmm11
000070bab59da8d9  movaps [rsp+0x20], xmm9
000070bab59da8df  lea rdi, [rsp]
000070bab59da8e3  mov esi, 0x00
000070bab59da8e8  mov rax, 0x63B35AFBC530
000070bab59da8f2  call rax
000070bab59da8f4  movaps xmm7, [rsp]
000070bab59da8f8  add rsp, 0x30
000070bab59da8fc  vmovaps xmm0, [rsp]
000070bab59da901  vmovaps xmm1, [rsp+0x10]
000070bab59da907  vmovaps xmm2, [rsp+0x20]
000070bab59da90d  vmovaps xmm3, [rsp+0x30]
000070bab59da913  vmovaps xmm4, [rsp+0x40]
000070bab59da919  vmovaps xmm5, [rsp+0x50]
000070bab59da91f  vmovaps xmm6, [rsp+0x60]
000070bab59da925  vmovaps xmm8, [rsp+0x70]
000070bab59da92b  vmovaps xmm9, [rsp+0x80]
000070bab59da934  vmovaps xmm10, [rsp+0x90]
000070bab59da93d  vmovaps xmm11, [rsp+0xA0]
000070bab59da946  vmovaps xmm12, [rsp+0xB0]
000070bab59da94f  vmovaps xmm13, [rsp+0xC0]
000070bab59da958  vmovaps xmm14, [rsp+0xD0]
000070bab59da961  vmovaps xmm15, [rsp+0xE0]
000070bab59da96a  add rsp, 0xF0
000070bab59da971  pop r11
000070bab59da973  pop r10
000070bab59da975  pop r9
000070bab59da977  pop r8
000070bab59da979  pop rsi
000070bab59da97a  pop rdi
000070bab59da97b  pop rdx
000070bab59da97c  pop rcx
000070bab59da97d  pop rax
000070bab59da97e  add rsp, 0x08
000070bab59da982  jmp 0x000070BAB59D64D2
000070bab59da987  sub rsp, 0x08
000070bab59da98b  push rax
000070bab59da98c  push rcx
000070bab59da98d  push rdx
000070bab59da98e  push rdi
000070bab59da98f  push rsi
000070bab59da990  push r8
000070bab59da992  push r9
000070bab59da994  push r10
000070bab59da996  push r11
000070bab59da998  sub rsp, 0xF0
000070bab59da99f  vmovaps [rsp], xmm0
000070bab59da9a4  vmovaps [rsp+0x10], xmm1
000070bab59da9aa  vmovaps [rsp+0x20], xmm2
000070bab59da9b0  vmovaps [rsp+0x30], xmm3
000070bab59da9b6  vmovaps [rsp+0x40], xmm4
000070bab59da9bc  vmovaps [rsp+0x50], xmm5
000070bab59da9c2  vmovaps [rsp+0x60], xmm6
000070bab59da9c8  vmovaps [rsp+0x70], xmm7
000070bab59da9ce  vmovaps [rsp+0x80], xmm8
000070bab59da9d7  vmovaps [rsp+0x90], xmm9
000070bab59da9e0  vmovaps [rsp+0xA0], xmm10
000070bab59da9e9  vmovaps [rsp+0xB0], xmm12
000070bab59da9f2  vmovaps [rsp+0xC0], xmm13
000070bab59da9fb  vmovaps [rsp+0xD0], xmm14
000070bab59daa04  vmovaps [rsp+0xE0], xmm15
000070bab59daa0d  sub rsp, 0x30
000070bab59daa11  movaps [rsp], xmm11
000070bab59daa16  movaps [rsp+0x10], xmm10
000070bab59daa1c  movaps [rsp+0x20], xmm14
000070bab59daa22  lea rdi, [rsp]
000070bab59daa26  mov esi, 0x00
000070bab59daa2b  mov rax, 0x63B35AFBC530
000070bab59daa35  call rax
000070bab59daa37  movaps xmm11, [rsp]
000070bab59daa3c  add rsp, 0x30
000070bab59daa40  vmovaps xmm0, [rsp]
000070bab59daa45  vmovaps xmm1, [rsp+0x10]
000070bab59daa4b  vmovaps xmm2, [rsp+0x20]
000070bab59daa51  vmovaps xmm3, [rsp+0x30]
000070bab59daa57  vmovaps xmm4, [rsp+0x40]
000070bab59daa5d  vmovaps xmm5, [rsp+0x50]
000070bab59daa63  vmovaps xmm6, [rsp+0x60]
000070bab59daa69  vmovaps xmm7, [rsp+0x70]
000070bab59daa6f  vmovaps xmm8, [rsp+0x80]
000070bab59daa78  vmovaps xmm9, [rsp+0x90]
000070bab59daa81  vmovaps xmm10, [rsp+0xA0]
000070bab59daa8a  vmovaps xmm12, [rsp+0xB0]
000070bab59daa93  vmovaps xmm13, [rsp+0xC0]
000070bab59daa9c  vmovaps xmm14, [rsp+0xD0]
000070bab59daaa5  vmovaps xmm15, [rsp+0xE0]
000070bab59daaae  add rsp, 0xF0
000070bab59daab5  pop r11
000070bab59daab7  pop r10
000070bab59daab9  pop r9
000070bab59daabb  pop r8
000070bab59daabd  pop rsi
000070bab59daabe  pop rdi
000070bab59daabf  pop rdx
000070bab59daac0  pop rcx
000070bab59daac1  pop rax
000070bab59daac2  add rsp, 0x08
000070bab59daac6  jmp 0x000070BAB59D64ED
000070bab59daacb  call 0x000070BAB58E45A0
000070bab59daad0  jmp 0x000070BAB59D64F7
000070bab59daad5  sub rsp, 0x08
000070bab59daad9  push rax
000070bab59daada  push rcx
000070bab59daadb  push rdx
000070bab59daadc  push rdi
000070bab59daadd  push rsi
000070bab59daade  push r8
000070bab59daae0  push r9
000070bab59daae2  push r10
000070bab59daae4  push r11
000070bab59daae6  sub rsp, 0xF0
000070bab59daaed  vmovaps [rsp], xmm0
000070bab59daaf2  vmovaps [rsp+0x10], xmm1
000070bab59daaf8  vmovaps [rsp+0x20], xmm2
000070bab59daafe  vmovaps [rsp+0x30], xmm3
000070bab59dab04  vmovaps [rsp+0x40], xmm4
000070bab59dab0a  vmovaps [rsp+0x50], xmm5
000070bab59dab10  vmovaps [rsp+0x60], xmm6
000070bab59dab16  vmovaps [rsp+0x70], xmm7
000070bab59dab1c  vmovaps [rsp+0x80], xmm8
000070bab59dab25  vmovaps [rsp+0x90], xmm9
000070bab59dab2e  vmovaps [rsp+0xA0], xmm11
000070bab59dab37  vmovaps [rsp+0xB0], xmm12
000070bab59dab40  vmovaps [rsp+0xC0], xmm13
000070bab59dab49  vmovaps [rsp+0xD0], xmm14
000070bab59dab52  vmovaps [rsp+0xE0], xmm15
000070bab59dab5b  sub rsp, 0x30
000070bab59dab5f  movaps [rsp], xmm10
000070bab59dab64  movaps [rsp+0x10], xmm1
000070bab59dab69  movaps [rsp+0x20], xmm12
000070bab59dab6f  lea rdi, [rsp]
000070bab59dab73  mov esi, 0x00
000070bab59dab78  mov rax, 0x63B35AFBC530
000070bab59dab82  call rax
000070bab59dab84  movaps xmm10, [rsp]
000070bab59dab89  add rsp, 0x30
000070bab59dab8d  vmovaps xmm0, [rsp]
000070bab59dab92  vmovaps xmm1, [rsp+0x10]
000070bab59dab98  vmovaps xmm2, [rsp+0x20]
000070bab59dab9e  vmovaps xmm3, [rsp+0x30]
000070bab59daba4  vmovaps xmm4, [rsp+0x40]
000070bab59dabaa  vmovaps xmm5, [rsp+0x50]
000070bab59dabb0  vmovaps xmm6, [rsp+0x60]
000070bab59dabb6  vmovaps xmm7, [rsp+0x70]
000070bab59dabbc  vmovaps xmm8, [rsp+0x80]
000070bab59dabc5  vmovaps xmm9, [rsp+0x90]
000070bab59dabce  vmovaps xmm11, [rsp+0xA0]
000070bab59dabd7  vmovaps xmm12, [rsp+0xB0]
000070bab59dabe0  vmovaps xmm13, [rsp+0xC0]
000070bab59dabe9  vmovaps xmm14, [rsp+0xD0]
000070bab59dabf2  vmovaps xmm15, [rsp+0xE0]
000070bab59dabfb  add rsp, 0xF0
000070bab59dac02  pop r11
000070bab59dac04  pop r10
000070bab59dac06  pop r9
000070bab59dac08  pop r8
000070bab59dac0a  pop rsi
000070bab59dac0b  pop rdi
000070bab59dac0c  pop rdx
000070bab59dac0d  pop rcx
000070bab59dac0e  pop rax
000070bab59dac0f  add rsp, 0x08
000070bab59dac13  jmp 0x000070BAB59D651A
000070bab59dac18  sub rsp, 0x08
000070bab59dac1c  push rax
000070bab59dac1d  push rcx
000070bab59dac1e  push rdx
000070bab59dac1f  push rdi
000070bab59dac20  push rsi
000070bab59dac21  push r8
000070bab59dac23  push r9
000070bab59dac25  push r10
000070bab59dac27  push r11
000070bab59dac29  sub rsp, 0xF0
000070bab59dac30  vmovaps [rsp], xmm0
000070bab59dac35  vmovaps [rsp+0x10], xmm1
000070bab59dac3b  vmovaps [rsp+0x20], xmm2
000070bab59dac41  vmovaps [rsp+0x30], xmm3
000070bab59dac47  vmovaps [rsp+0x40], xmm4
000070bab59dac4d  vmovaps [rsp+0x50], xmm5
000070bab59dac53  vmovaps [rsp+0x60], xmm6
000070bab59dac59  vmovaps [rsp+0x70], xmm7
000070bab59dac5f  vmovaps [rsp+0x80], xmm8
000070bab59dac68  vmovaps [rsp+0x90], xmm9
000070bab59dac71  vmovaps [rsp+0xA0], xmm10
000070bab59dac7a  vmovaps [rsp+0xB0], xmm11
000070bab59dac83  vmovaps [rsp+0xC0], xmm13
000070bab59dac8c  vmovaps [rsp+0xD0], xmm14
000070bab59dac95  vmovaps [rsp+0xE0], xmm15
000070bab59dac9e  sub rsp, 0x30
000070bab59daca2  movaps [rsp], xmm12
000070bab59daca7  movaps [rsp+0x10], xmm14
000070bab59dacad  movaps [rsp+0x20], xmm1
000070bab59dacb2  lea rdi, [rsp]
000070bab59dacb6  mov esi, 0x00
000070bab59dacbb  mov rax, 0x63B35AFBC530
000070bab59dacc5  call rax
000070bab59dacc7  movaps xmm12, [rsp]
000070bab59daccc  add rsp, 0x30
000070bab59dacd0  vmovaps xmm0, [rsp]
000070bab59dacd5  vmovaps xmm1, [rsp+0x10]
000070bab59dacdb  vmovaps xmm2, [rsp+0x20]
000070bab59dace1  vmovaps xmm3, [rsp+0x30]
000070bab59dace7  vmovaps xmm4, [rsp+0x40]
000070bab59daced  vmovaps xmm5, [rsp+0x50]
000070bab59dacf3  vmovaps xmm6, [rsp+0x60]
000070bab59dacf9  vmovaps xmm7, [rsp+0x70]
000070bab59dacff  vmovaps xmm8, [rsp+0x80]
000070bab59dad08  vmovaps xmm9, [rsp+0x90]
000070bab59dad11  vmovaps xmm10, [rsp+0xA0]
000070bab59dad1a  vmovaps xmm11, [rsp+0xB0]
000070bab59dad23  vmovaps xmm13, [rsp+0xC0]
000070bab59dad2c  vmovaps xmm14, [rsp+0xD0]
000070bab59dad35  vmovaps xmm15, [rsp+0xE0]
000070bab59dad3e  add rsp, 0xF0
000070bab59dad45  pop r11
000070bab59dad47  pop r10
000070bab59dad49  pop r9
000070bab59dad4b  pop r8
000070bab59dad4d  pop rsi
000070bab59dad4e  pop rdi
000070bab59dad4f  pop rdx
000070bab59dad50  pop rcx
000070bab59dad51  pop rax
000070bab59dad52  add rsp, 0x08
000070bab59dad56  jmp 0x000070BAB59D6549
000070bab59dad5b  sub rsp, 0x08
000070bab59dad5f  push rax
000070bab59dad60  push rcx
000070bab59dad61  push rdx
000070bab59dad62  push rdi
000070bab59dad63  push rsi
000070bab59dad64  push r8
000070bab59dad66  push r9
000070bab59dad68  push r10
000070bab59dad6a  push r11
000070bab59dad6c  sub rsp, 0xF0
000070bab59dad73  vmovaps [rsp], xmm0
000070bab59dad78  vmovaps [rsp+0x10], xmm1
000070bab59dad7e  vmovaps [rsp+0x20], xmm2
000070bab59dad84  vmovaps [rsp+0x30], xmm3
000070bab59dad8a  vmovaps [rsp+0x40], xmm4
000070bab59dad90  vmovaps [rsp+0x50], xmm5
000070bab59dad96  vmovaps [rsp+0x60], xmm6
000070bab59dad9c  vmovaps [rsp+0x70], xmm7
000070bab59dada2  vmovaps [rsp+0x80], xmm8
000070bab59dadab  vmovaps [rsp+0x90], xmm9
000070bab59dadb4  vmovaps [rsp+0xA0], xmm10
000070bab59dadbd  vmovaps [rsp+0xB0], xmm11
000070bab59dadc6  vmovaps [rsp+0xC0], xmm12
000070bab59dadcf  vmovaps [rsp+0xD0], xmm13
000070bab59dadd8  vmovaps [rsp+0xE0], xmm15
000070bab59dade1  sub rsp, 0x30
000070bab59dade5  movaps [rsp], xmm14
000070bab59dadea  movaps [rsp+0x10], xmm9
000070bab59dadf0  movaps [rsp+0x20], xmm1
000070bab59dadf5  lea rdi, [rsp]
000070bab59dadf9  mov esi, 0x00
000070bab59dadfe  mov rax, 0x63B35AFBC530
000070bab59dae08  call rax
000070bab59dae0a  movaps xmm14, [rsp]
000070bab59dae0f  add rsp, 0x30
000070bab59dae13  vmovaps xmm0, [rsp]
000070bab59dae18  vmovaps xmm1, [rsp+0x10]
000070bab59dae1e  vmovaps xmm2, [rsp+0x20]
000070bab59dae24  vmovaps xmm3, [rsp+0x30]
000070bab59dae2a  vmovaps xmm4, [rsp+0x40]
000070bab59dae30  vmovaps xmm5, [rsp+0x50]
000070bab59dae36  vmovaps xmm6, [rsp+0x60]
000070bab59dae3c  vmovaps xmm7, [rsp+0x70]
000070bab59dae42  vmovaps xmm8, [rsp+0x80]
000070bab59dae4b  vmovaps xmm9, [rsp+0x90]
000070bab59dae54  vmovaps xmm10, [rsp+0xA0]
000070bab59dae5d  vmovaps xmm11, [rsp+0xB0]
000070bab59dae66  vmovaps xmm12, [rsp+0xC0]
000070bab59dae6f  vmovaps xmm13, [rsp+0xD0]
000070bab59dae78  vmovaps xmm15, [rsp+0xE0]
000070bab59dae81  add rsp, 0xF0
000070bab59dae88  pop r11
000070bab59dae8a  pop r10
000070bab59dae8c  pop r9
000070bab59dae8e  pop r8
000070bab59dae90  pop rsi
000070bab59dae91  pop rdi
000070bab59dae92  pop rdx
000070bab59dae93  pop rcx
000070bab59dae94  pop rax
000070bab59dae95  add rsp, 0x08
000070bab59dae99  jmp 0x000070BAB59D6578
000070bab59dae9e  sub rsp, 0x08
000070bab59daea2  push rax
000070bab59daea3  push rcx
000070bab59daea4  push rdx
000070bab59daea5  push rdi
000070bab59daea6  push rsi
000070bab59daea7  push r8
000070bab59daea9  push r9
000070bab59daeab  push r10
000070bab59daead  push r11
000070bab59daeaf  sub rsp, 0xF0
000070bab59daeb6  vmovaps [rsp], xmm0
000070bab59daebb  vmovaps [rsp+0x10], xmm2
000070bab59daec1  vmovaps [rsp+0x20], xmm3
000070bab59daec7  vmovaps [rsp+0x30], xmm4
000070bab59daecd  vmovaps [rsp+0x40], xmm5
000070bab59daed3  vmovaps [rsp+0x50], xmm6
000070bab59daed9  vmovaps [rsp+0x60], xmm7
000070bab59daedf  vmovaps [rsp+0x70], xmm8
000070bab59daee5  vmovaps [rsp+0x80], xmm9
000070bab59daeee  vmovaps [rsp+0x90], xmm10
000070bab59daef7  vmovaps [rsp+0xA0], xmm11
000070bab59daf00  vmovaps [rsp+0xB0], xmm12
000070bab59daf09  vmovaps [rsp+0xC0], xmm13
000070bab59daf12  vmovaps [rsp+0xD0], xmm14
000070bab59daf1b  vmovaps [rsp+0xE0], xmm15
000070bab59daf24  sub rsp, 0x30
000070bab59daf28  movaps [rsp], xmm1
000070bab59daf2c  movaps [rsp+0x10], xmm13
000070bab59daf32  movaps [rsp+0x20], xmm8
000070bab59daf38  lea rdi, [rsp]
000070bab59daf3c  mov esi, 0x00
000070bab59daf41  mov rax, 0x63B35AFBC530
000070bab59daf4b  call rax
000070bab59daf4d  movaps xmm1, [rsp]
000070bab59daf51  add rsp, 0x30
000070bab59daf55  vmovaps xmm0, [rsp]
000070bab59daf5a  vmovaps xmm2, [rsp+0x10]
000070bab59daf60  vmovaps xmm3, [rsp+0x20]
000070bab59daf66  vmovaps xmm4, [rsp+0x30]
000070bab59daf6c  vmovaps xmm5, [rsp+0x40]
000070bab59daf72  vmovaps xmm6, [rsp+0x50]
000070bab59daf78  vmovaps xmm7, [rsp+0x60]
000070bab59daf7e  vmovaps xmm8, [rsp+0x70]
000070bab59daf84  vmovaps xmm9, [rsp+0x80]
000070bab59daf8d  vmovaps xmm10, [rsp+0x90]
000070bab59daf96  vmovaps xmm11, [rsp+0xA0]
000070bab59daf9f  vmovaps xmm12, [rsp+0xB0]
000070bab59dafa8  vmovaps xmm13, [rsp+0xC0]
000070bab59dafb1  vmovaps xmm14, [rsp+0xD0]
000070bab59dafba  vmovaps xmm15, [rsp+0xE0]
000070bab59dafc3  add rsp, 0xF0
000070bab59dafca  pop r11
000070bab59dafcc  pop r10
000070bab59dafce  pop r9
000070bab59dafd0  pop r8
000070bab59dafd2  pop rsi
000070bab59dafd3  pop rdi
000070bab59dafd4  pop rdx
000070bab59dafd5  pop rcx
000070bab59dafd6  pop rax
000070bab59dafd7  add rsp, 0x08
000070bab59dafdb  jmp 0x000070BAB59D659A
000070bab59dafe0  call 0x000070BAB580C260
000070bab59dafe5  jmp 0x000070BAB59D65A8
000070bab59dafea  call 0x000070BAB58DE950
000070bab59dafef  jmp 0x000070BAB59D65B2
000070bab59daff4  sub rsp, 0x08
000070bab59daff8  push rax
000070bab59daff9  push rcx
000070bab59daffa  push rdx
000070bab59daffb  push rdi
000070bab59daffc  push rsi
000070bab59daffd  push r8
000070bab59dafff  push r9
000070bab59db001  push r10
000070bab59db003  push r11
000070bab59db005  sub rsp, 0xF0
000070bab59db00c  vmovaps [rsp], xmm0
000070bab59db011  vmovaps [rsp+0x10], xmm1
000070bab59db017  vmovaps [rsp+0x20], xmm2
000070bab59db01d  vmovaps [rsp+0x30], xmm3
000070bab59db023  vmovaps [rsp+0x40], xmm4
000070bab59db029  vmovaps [rsp+0x50], xmm5
000070bab59db02f  vmovaps [rsp+0x60], xmm6
000070bab59db035  vmovaps [rsp+0x70], xmm7
000070bab59db03b  vmovaps [rsp+0x80], xmm9
000070bab59db044  vmovaps [rsp+0x90], xmm10
000070bab59db04d  vmovaps [rsp+0xA0], xmm11
000070bab59db056  vmovaps [rsp+0xB0], xmm12
000070bab59db05f  vmovaps [rsp+0xC0], xmm13
000070bab59db068  vmovaps [rsp+0xD0], xmm14
000070bab59db071  vmovaps [rsp+0xE0], xmm15
000070bab59db07a  sub rsp, 0x30
000070bab59db07e  movaps [rsp], xmm8
000070bab59db083  movaps [rsp+0x10], xmm15
000070bab59db089  movaps [rsp+0x20], xmm7
000070bab59db08e  lea rdi, [rsp]
000070bab59db092  mov esi, 0x00
000070bab59db097  mov rax, 0x63B35AFBC530
000070bab59db0a1  call rax
000070bab59db0a3  movaps xmm8, [rsp]
000070bab59db0a8  add rsp, 0x30
000070bab59db0ac  vmovaps xmm0, [rsp]
000070bab59db0b1  vmovaps xmm1, [rsp+0x10]
000070bab59db0b7  vmovaps xmm2, [rsp+0x20]
000070bab59db0bd  vmovaps xmm3, [rsp+0x30]
000070bab59db0c3  vmovaps xmm4, [rsp+0x40]
000070bab59db0c9  vmovaps xmm5, [rsp+0x50]
000070bab59db0cf  vmovaps xmm6, [rsp+0x60]
000070bab59db0d5  vmovaps xmm7, [rsp+0x70]
000070bab59db0db  vmovaps xmm9, [rsp+0x80]
000070bab59db0e4  vmovaps xmm10, [rsp+0x90]
000070bab59db0ed  vmovaps xmm11, [rsp+0xA0]
000070bab59db0f6  vmovaps xmm12, [rsp+0xB0]
000070bab59db0ff  vmovaps xmm13, [rsp+0xC0]
000070bab59db108  vmovaps xmm14, [rsp+0xD0]
000070bab59db111  vmovaps xmm15, [rsp+0xE0]
000070bab59db11a  add rsp, 0xF0
000070bab59db121  pop r11
000070bab59db123  pop r10
000070bab59db125  pop r9
000070bab59db127  pop r8
000070bab59db129  pop rsi
000070bab59db12a  pop rdi
000070bab59db12b  pop rdx
000070bab59db12c  pop rcx
000070bab59db12d  pop rax
000070bab59db12e  add rsp, 0x08
000070bab59db132  jmp 0x000070BAB59D65D4
000070bab59db137  sub rsp, 0x08
000070bab59db13b  push rax
000070bab59db13c  push rcx
000070bab59db13d  push rdx
000070bab59db13e  push rdi
000070bab59db13f  push rsi
000070bab59db140  push r8
000070bab59db142  push r9
000070bab59db144  push r10
000070bab59db146  push r11
000070bab59db148  sub rsp, 0xF0
000070bab59db14f  vmovaps [rsp], xmm0
000070bab59db154  vmovaps [rsp+0x10], xmm1
000070bab59db15a  vmovaps [rsp+0x20], xmm2
000070bab59db160  vmovaps [rsp+0x30], xmm3
000070bab59db166  vmovaps [rsp+0x40], xmm4
000070bab59db16c  vmovaps [rsp+0x50], xmm5
000070bab59db172  vmovaps [rsp+0x60], xmm6
000070bab59db178  vmovaps [rsp+0x70], xmm8
000070bab59db17e  vmovaps [rsp+0x80], xmm9
000070bab59db187  vmovaps [rsp+0x90], xmm10
000070bab59db190  vmovaps [rsp+0xA0], xmm11
000070bab59db199  vmovaps [rsp+0xB0], xmm12
000070bab59db1a2  vmovaps [rsp+0xC0], xmm13
000070bab59db1ab  vmovaps [rsp+0xD0], xmm14
000070bab59db1b4  vmovaps [rsp+0xE0], xmm15
000070bab59db1bd  sub rsp, 0x30
000070bab59db1c1  movaps [rsp], xmm7
000070bab59db1c5  movaps [rsp+0x10], xmm9
000070bab59db1cb  movaps [rsp+0x20], xmm15
000070bab59db1d1  lea rdi, [rsp]
000070bab59db1d5  mov esi, 0x00
000070bab59db1da  mov rax, 0x63B35AFBC530
000070bab59db1e4  call rax
000070bab59db1e6  movaps xmm7, [rsp]
000070bab59db1ea  add rsp, 0x30
000070bab59db1ee  vmovaps xmm0, [rsp]
000070bab59db1f3  vmovaps xmm1, [rsp+0x10]
000070bab59db1f9  vmovaps xmm2, [rsp+0x20]
000070bab59db1ff  vmovaps xmm3, [rsp+0x30]
000070bab59db205  vmovaps xmm4, [rsp+0x40]
000070bab59db20b  vmovaps xmm5, [rsp+0x50]
000070bab59db211  vmovaps xmm6, [rsp+0x60]
000070bab59db217  vmovaps xmm8, [rsp+0x70]
000070bab59db21d  vmovaps xmm9, [rsp+0x80]
000070bab59db226  vmovaps xmm10, [rsp+0x90]
000070bab59db22f  vmovaps xmm11, [rsp+0xA0]
000070bab59db238  vmovaps xmm12, [rsp+0xB0]
000070bab59db241  vmovaps xmm13, [rsp+0xC0]
000070bab59db24a  vmovaps xmm14, [rsp+0xD0]
000070bab59db253  vmovaps xmm15, [rsp+0xE0]
000070bab59db25c  add rsp, 0xF0
000070bab59db263  pop r11
000070bab59db265  pop r10
000070bab59db267  pop r9
000070bab59db269  pop r8
000070bab59db26b  pop rsi
000070bab59db26c  pop rdi
000070bab59db26d  pop rdx
000070bab59db26e  pop rcx
000070bab59db26f  pop rax
000070bab59db270  add rsp, 0x08
000070bab59db274  jmp 0x000070BAB59D6601
000070bab59db279  sub rsp, 0x08
000070bab59db27d  push rax
000070bab59db27e  push rcx
000070bab59db27f  push rdx
000070bab59db280  push rdi
000070bab59db281  push rsi
000070bab59db282  push r8
000070bab59db284  push r9
000070bab59db286  push r10
000070bab59db288  push r11
000070bab59db28a  sub rsp, 0xF0
000070bab59db291  vmovaps [rsp], xmm0
000070bab59db296  vmovaps [rsp+0x10], xmm1
000070bab59db29c  vmovaps [rsp+0x20], xmm2
000070bab59db2a2  vmovaps [rsp+0x30], xmm3
000070bab59db2a8  vmovaps [rsp+0x40], xmm4
000070bab59db2ae  vmovaps [rsp+0x50], xmm5
000070bab59db2b4  vmovaps [rsp+0x60], xmm6
000070bab59db2ba  vmovaps [rsp+0x70], xmm7
000070bab59db2c0  vmovaps [rsp+0x80], xmm8
000070bab59db2c9  vmovaps [rsp+0x90], xmm10
000070bab59db2d2  vmovaps [rsp+0xA0], xmm11
000070bab59db2db  vmovaps [rsp+0xB0], xmm12
000070bab59db2e4  vmovaps [rsp+0xC0], xmm13
000070bab59db2ed  vmovaps [rsp+0xD0], xmm14
000070bab59db2f6  vmovaps [rsp+0xE0], xmm15
000070bab59db2ff  sub rsp, 0x30
000070bab59db303  movaps [rsp], xmm9
000070bab59db308  movaps [rsp+0x10], xmm13
000070bab59db30e  movaps [rsp+0x20], xmm15
000070bab59db314  lea rdi, [rsp]
000070bab59db318  mov esi, 0x00
000070bab59db31d  mov rax, 0x63B35AFBC530
000070bab59db327  call rax
000070bab59db329  movaps xmm9, [rsp]
000070bab59db32e  add rsp, 0x30
000070bab59db332  vmovaps xmm0, [rsp]
000070bab59db337  vmovaps xmm1, [rsp+0x10]
000070bab59db33d  vmovaps xmm2, [rsp+0x20]
000070bab59db343  vmovaps xmm3, [rsp+0x30]
000070bab59db349  vmovaps xmm4, [rsp+0x40]
000070bab59db34f  vmovaps xmm5, [rsp+0x50]
000070bab59db355  vmovaps xmm6, [rsp+0x60]
000070bab59db35b  vmovaps xmm7, [rsp+0x70]
000070bab59db361  vmovaps xmm8, [rsp+0x80]
000070bab59db36a  vmovaps xmm10, [rsp+0x90]
000070bab59db373  vmovaps xmm11, [rsp+0xA0]
000070bab59db37c  vmovaps xmm12, [rsp+0xB0]
000070bab59db385  vmovaps xmm13, [rsp+0xC0]
000070bab59db38e  vmovaps xmm14, [rsp+0xD0]
000070bab59db397  vmovaps xmm15, [rsp+0xE0]
000070bab59db3a0  add rsp, 0xF0
000070bab59db3a7  pop r11
000070bab59db3a9  pop r10
000070bab59db3ab  pop r9
000070bab59db3ad  pop r8
000070bab59db3af  pop rsi
000070bab59db3b0  pop rdi
000070bab59db3b1  pop rdx
000070bab59db3b2  pop rcx
000070bab59db3b3  pop rax
000070bab59db3b4  add rsp, 0x08
000070bab59db3b8  jmp 0x000070BAB59D662F
000070bab59db3bd  sub rsp, 0x08
000070bab59db3c1  push rax
000070bab59db3c2  push rcx
000070bab59db3c3  push rdx
000070bab59db3c4  push rdi
000070bab59db3c5  push rsi
000070bab59db3c6  push r8
000070bab59db3c8  push r9
000070bab59db3ca  push r10
000070bab59db3cc  push r11
000070bab59db3ce  sub rsp, 0xF0
000070bab59db3d5  vmovaps [rsp], xmm0
000070bab59db3da  vmovaps [rsp+0x10], xmm1
000070bab59db3e0  vmovaps [rsp+0x20], xmm2
000070bab59db3e6  vmovaps [rsp+0x30], xmm3
000070bab59db3ec  vmovaps [rsp+0x40], xmm4
000070bab59db3f2  vmovaps [rsp+0x50], xmm5
000070bab59db3f8  vmovaps [rsp+0x60], xmm6
000070bab59db3fe  vmovaps [rsp+0x70], xmm7
000070bab59db404  vmovaps [rsp+0x80], xmm8
000070bab59db40d  vmovaps [rsp+0x90], xmm9
000070bab59db416  vmovaps [rsp+0xA0], xmm10
000070bab59db41f  vmovaps [rsp+0xB0], xmm11
000070bab59db428  vmovaps [rsp+0xC0], xmm12
000070bab59db431  vmovaps [rsp+0xD0], xmm13
000070bab59db43a  vmovaps [rsp+0xE0], xmm14
000070bab59db443  sub rsp, 0x30
000070bab59db447  movaps [rsp], xmm15
000070bab59db44c  movaps [rsp+0x10], xmm11
000070bab59db452  movaps [rsp+0x20], xmm12
000070bab59db458  lea rdi, [rsp]
000070bab59db45c  mov esi, 0x00
000070bab59db461  mov rax, 0x63B35AFBC530
000070bab59db46b  call rax
000070bab59db46d  movaps xmm15, [rsp]
000070bab59db472  add rsp, 0x30
000070bab59db476  vmovaps xmm0, [rsp]
000070bab59db47b  vmovaps xmm1, [rsp+0x10]
000070bab59db481  vmovaps xmm2, [rsp+0x20]
000070bab59db487  vmovaps xmm3, [rsp+0x30]
000070bab59db48d  vmovaps xmm4, [rsp+0x40]
000070bab59db493  vmovaps xmm5, [rsp+0x50]
000070bab59db499  vmovaps xmm6, [rsp+0x60]
000070bab59db49f  vmovaps xmm7, [rsp+0x70]
000070bab59db4a5  vmovaps xmm8, [rsp+0x80]
000070bab59db4ae  vmovaps xmm9, [rsp+0x90]
000070bab59db4b7  vmovaps xmm10, [rsp+0xA0]
000070bab59db4c0  vmovaps xmm11, [rsp+0xB0]
000070bab59db4c9  vmovaps xmm12, [rsp+0xC0]
000070bab59db4d2  vmovaps xmm13, [rsp+0xD0]
000070bab59db4db  vmovaps xmm14, [rsp+0xE0]
000070bab59db4e4  add rsp, 0xF0
000070bab59db4eb  pop r11
000070bab59db4ed  pop r10
000070bab59db4ef  pop r9
000070bab59db4f1  pop r8
000070bab59db4f3  pop rsi
000070bab59db4f4  pop rdi
000070bab59db4f5  pop rdx
000070bab59db4f6  pop rcx
000070bab59db4f7  pop rax
000070bab59db4f8  add rsp, 0x08
000070bab59db4fc  jmp 0x000070BAB59D664A
000070bab59db501  sub rsp, 0x08
000070bab59db505  push rax
000070bab59db506  push rcx
000070bab59db507  push rdx
000070bab59db508  push rdi
000070bab59db509  push rsi
000070bab59db50a  push r8
000070bab59db50c  push r9
000070bab59db50e  push r10
000070bab59db510  push r11
000070bab59db512  sub rsp, 0xF0
000070bab59db519  vmovaps [rsp], xmm0
000070bab59db51e  vmovaps [rsp+0x10], xmm1
000070bab59db524  vmovaps [rsp+0x20], xmm2
000070bab59db52a  vmovaps [rsp+0x30], xmm3
000070bab59db530  vmovaps [rsp+0x40], xmm4
000070bab59db536  vmovaps [rsp+0x50], xmm5
000070bab59db53c  vmovaps [rsp+0x60], xmm6
000070bab59db542  vmovaps [rsp+0x70], xmm7
000070bab59db548  vmovaps [rsp+0x80], xmm8
000070bab59db551  vmovaps [rsp+0x90], xmm9
000070bab59db55a  vmovaps [rsp+0xA0], xmm10
000070bab59db563  vmovaps [rsp+0xB0], xmm11
000070bab59db56c  vmovaps [rsp+0xC0], xmm12
000070bab59db575  vmovaps [rsp+0xD0], xmm14
000070bab59db57e  vmovaps [rsp+0xE0], xmm15
000070bab59db587  sub rsp, 0x30
000070bab59db58b  movaps [rsp], xmm13
000070bab59db590  movaps [rsp+0x10], xmm10
000070bab59db596  movaps [rsp+0x20], xmm14
000070bab59db59c  lea rdi, [rsp]
000070bab59db5a0  mov esi, 0x00
000070bab59db5a5  mov rax, 0x63B35AFBC530
000070bab59db5af  call rax
000070bab59db5b1  movaps xmm13, [rsp]
000070bab59db5b6  add rsp, 0x30
000070bab59db5ba  vmovaps xmm0, [rsp]
000070bab59db5bf  vmovaps xmm1, [rsp+0x10]
000070bab59db5c5  vmovaps xmm2, [rsp+0x20]
000070bab59db5cb  vmovaps xmm3, [rsp+0x30]
000070bab59db5d1  vmovaps xmm4, [rsp+0x40]
000070bab59db5d7  vmovaps xmm5, [rsp+0x50]
000070bab59db5dd  vmovaps xmm6, [rsp+0x60]
000070bab59db5e3  vmovaps xmm7, [rsp+0x70]
000070bab59db5e9  vmovaps xmm8, [rsp+0x80]
000070bab59db5f2  vmovaps xmm9, [rsp+0x90]
000070bab59db5fb  vmovaps xmm10, [rsp+0xA0]
000070bab59db604  vmovaps xmm11, [rsp+0xB0]
000070bab59db60d  vmovaps xmm12, [rsp+0xC0]
000070bab59db616  vmovaps xmm14, [rsp+0xD0]
000070bab59db61f  vmovaps xmm15, [rsp+0xE0]
000070bab59db628  add rsp, 0xF0
000070bab59db62f  pop r11
000070bab59db631  pop r10
000070bab59db633  pop r9
000070bab59db635  pop r8
000070bab59db637  pop rsi
000070bab59db638  pop rdi
000070bab59db639  pop rdx
000070bab59db63a  pop rcx
000070bab59db63b  pop rax
000070bab59db63c  add rsp, 0x08
000070bab59db640  jmp 0x000070BAB59D666D
000070bab59db645  sub rsp, 0x08
000070bab59db649  push rax
000070bab59db64a  push rcx
000070bab59db64b  push rdx
000070bab59db64c  push rdi
000070bab59db64d  push rsi
000070bab59db64e  push r8
000070bab59db650  push r9
000070bab59db652  push r10
000070bab59db654  push r11
000070bab59db656  sub rsp, 0xF0
000070bab59db65d  vmovaps [rsp], xmm0
000070bab59db662  vmovaps [rsp+0x10], xmm1
000070bab59db668  vmovaps [rsp+0x20], xmm2
000070bab59db66e  vmovaps [rsp+0x30], xmm3
000070bab59db674  vmovaps [rsp+0x40], xmm4
000070bab59db67a  vmovaps [rsp+0x50], xmm5
000070bab59db680  vmovaps [rsp+0x60], xmm6
000070bab59db686  vmovaps [rsp+0x70], xmm7
000070bab59db68c  vmovaps [rsp+0x80], xmm8
000070bab59db695  vmovaps [rsp+0x90], xmm9
000070bab59db69e  vmovaps [rsp+0xA0], xmm10
000070bab59db6a7  vmovaps [rsp+0xB0], xmm11
000070bab59db6b0  vmovaps [rsp+0xC0], xmm12
000070bab59db6b9  vmovaps [rsp+0xD0], xmm13
000070bab59db6c2  vmovaps [rsp+0xE0], xmm15
000070bab59db6cb  sub rsp, 0x30
000070bab59db6cf  movaps [rsp], xmm14
000070bab59db6d4  movaps [rsp+0x10], xmm1
000070bab59db6d9  movaps [rsp+0x20], xmm7
000070bab59db6de  lea rdi, [rsp]
000070bab59db6e2  mov esi, 0x00
000070bab59db6e7  mov rax, 0x63B35AFBC530
000070bab59db6f1  call rax
000070bab59db6f3  movaps xmm14, [rsp]
000070bab59db6f8  add rsp, 0x30
000070bab59db6fc  vmovaps xmm0, [rsp]
000070bab59db701  vmovaps xmm1, [rsp+0x10]
000070bab59db707  vmovaps xmm2, [rsp+0x20]
000070bab59db70d  vmovaps xmm3, [rsp+0x30]
000070bab59db713  vmovaps xmm4, [rsp+0x40]
000070bab59db719  vmovaps xmm5, [rsp+0x50]
000070bab59db71f  vmovaps xmm6, [rsp+0x60]
000070bab59db725  vmovaps xmm7, [rsp+0x70]
000070bab59db72b  vmovaps xmm8, [rsp+0x80]
000070bab59db734  vmovaps xmm9, [rsp+0x90]
000070bab59db73d  vmovaps xmm10, [rsp+0xA0]
000070bab59db746  vmovaps xmm11, [rsp+0xB0]
000070bab59db74f  vmovaps xmm12, [rsp+0xC0]
000070bab59db758  vmovaps xmm13, [rsp+0xD0]
000070bab59db761  vmovaps xmm15, [rsp+0xE0]
000070bab59db76a  add rsp, 0xF0
000070bab59db771  pop r11
000070bab59db773  pop r10
000070bab59db775  pop r9
000070bab59db777  pop r8
000070bab59db779  pop rsi
000070bab59db77a  pop rdi
000070bab59db77b  pop rdx
000070bab59db77c  pop rcx
000070bab59db77d  pop rax
000070bab59db77e  add rsp, 0x08
000070bab59db782  jmp 0x000070BAB59D6690
000070bab59db787  sub rsp, 0x08
000070bab59db78b  push rax
000070bab59db78c  push rcx
000070bab59db78d  push rdx
000070bab59db78e  push rdi
000070bab59db78f  push rsi
000070bab59db790  push r8
000070bab59db792  push r9
000070bab59db794  push r10
000070bab59db796  push r11
000070bab59db798  sub rsp, 0xF0
000070bab59db79f  vmovaps [rsp], xmm0
000070bab59db7a4  vmovaps [rsp+0x10], xmm2
000070bab59db7aa  vmovaps [rsp+0x20], xmm3
000070bab59db7b0  vmovaps [rsp+0x30], xmm4
000070bab59db7b6  vmovaps [rsp+0x40], xmm5
000070bab59db7bc  vmovaps [rsp+0x50], xmm6
000070bab59db7c2  vmovaps [rsp+0x60], xmm7
000070bab59db7c8  vmovaps [rsp+0x70], xmm8
000070bab59db7ce  vmovaps [rsp+0x80], xmm9
000070bab59db7d7  vmovaps [rsp+0x90], xmm10
000070bab59db7e0  vmovaps [rsp+0xA0], xmm11
000070bab59db7e9  vmovaps [rsp+0xB0], xmm12
000070bab59db7f2  vmovaps [rsp+0xC0], xmm13
000070bab59db7fb  vmovaps [rsp+0xD0], xmm14
000070bab59db804  vmovaps [rsp+0xE0], xmm15
000070bab59db80d  sub rsp, 0x30
000070bab59db811  movaps [rsp], xmm1
000070bab59db815  movaps [rsp+0x10], xmm8
000070bab59db81b  movaps [rsp+0x20], xmm9
000070bab59db821  lea rdi, [rsp]
000070bab59db825  mov esi, 0x00
000070bab59db82a  mov rax, 0x63B35AFBC530
000070bab59db834  call rax
000070bab59db836  movaps xmm1, [rsp]
000070bab59db83a  add rsp, 0x30
000070bab59db83e  vmovaps xmm0, [rsp]
000070bab59db843  vmovaps xmm2, [rsp+0x10]
000070bab59db849  vmovaps xmm3, [rsp+0x20]
000070bab59db84f  vmovaps xmm4, [rsp+0x30]
000070bab59db855  vmovaps xmm5, [rsp+0x40]
000070bab59db85b  vmovaps xmm6, [rsp+0x50]
000070bab59db861  vmovaps xmm7, [rsp+0x60]
000070bab59db867  vmovaps xmm8, [rsp+0x70]
000070bab59db86d  vmovaps xmm9, [rsp+0x80]
000070bab59db876  vmovaps xmm10, [rsp+0x90]
000070bab59db87f  vmovaps xmm11, [rsp+0xA0]
000070bab59db888  vmovaps xmm12, [rsp+0xB0]
000070bab59db891  vmovaps xmm13, [rsp+0xC0]
000070bab59db89a  vmovaps xmm14, [rsp+0xD0]
000070bab59db8a3  vmovaps xmm15, [rsp+0xE0]
000070bab59db8ac  add rsp, 0xF0
000070bab59db8b3  pop r11
000070bab59db8b5  pop r10
000070bab59db8b7  pop r9
000070bab59db8b9  pop r8
000070bab59db8bb  pop rsi
000070bab59db8bc  pop rdi
000070bab59db8bd  pop rdx
000070bab59db8be  pop rcx
000070bab59db8bf  pop rax
000070bab59db8c0  add rsp, 0x08
000070bab59db8c4  jmp 0x000070BAB59D66B2
000070bab59db8c9  call 0x000070BAB58B3E40
000070bab59db8ce  jmp 0x000070BAB59D66C0
000070bab59db8d3  call 0x000070BAB580C380
000070bab59db8d8  jmp 0x000070BAB59D66CA
000070bab59db8dd  call 0x000070BAB580D600
000070bab59db8e2  jmp 0x000070BAB59D66D4
000070bab59db8e7  call 0x000070BAB57FF540
000070bab59db8ec  jmp 0x000070BAB59D66DE
000070bab59db8f1  int3
000070bab59db8f2  nop [rax+rax*1], ax
000070bab59db8fb  nop [rax+rax*1], eax
000070bab59db900  mov eax, [r15+0x48]
000070bab59db904  lea r14d, [eax+0x01]
000070bab59db909  mov [rsp+0x10], r14d
000070bab59db90e  mov r14d, r14d
000070bab59db911  mov [r15+0x48], r14
000070bab59db915  xor eax, eax
000070bab59db917  mov r14d, [rsp+0x10]
000070bab59db91c  cmp r14d, 0x1F4
000070bab59db923  cmc
000070bab59db924  lahf
000070bab59db925  seto al
000070bab59db928  mov [r15+0x108], eax
000070bab59db92f  mov eax, [r15+0x108]
000070bab59db936  sahf
000070bab59db937  jnz 0x000070BAB59DB969
000070bab59db939  cmp dword ptr [r15+0x318], 0x00
000070bab59db941  jz 0x000070BAB59E1AB0
000070bab59db947  nop [rax+rax*1], ax
000070bab59db950  nop [rax+rax*1], eax
000070bab59db958  mov eax, 0x410450
000070bab59db95d  mov [r15+0x100], rax
000070bab59db964  jmp 0x000070BAB57FE110
000070bab59db969  cmp dword ptr [r15+0x318], 0x00
000070bab59db971  jz 0x000070BAB59DB9A0
000070bab59db977  nop [rax+rax*1], ax
000070bab59db980  nop [rax+rax*1], eax
000070bab59db988  mov eax, 0x410274
000070bab59db98d  mov [r15+0x100], rax
000070bab59db994  jmp 0x000070BAB57FE110
000070bab59db999  int3
000070bab59db99a  int3
000070bab59db99b  nop [rax+rax*1], eax
000070bab59db9a0  mov rax, [r15+0x40]
000070bab59db9a4  movaps xmm1, [r15+0x1D0]
000070bab59db9ac  vmovaps [rsp+0x10], xmm1
000070bab59db9b2  vmovaps xmm15, [rsp+0x10]
000070bab59db9b8  por xmm1, xmm15
000070bab59db9bd  movaps xmm14, [r15+0x1A0]
000070bab59db9c5  vmovaps [rsp+0x10], xmm14
000070bab59db9cb  vmovaps xmm13, [rsp+0x10]
000070bab59db9d1  por xmm14, xmm13
000070bab59db9d6  lea r14, [rax+0x30]
000070bab59db9da  mov r12, [r13+r14*1]
000070bab59db9df  lea r14, [rax+0x38]
000070bab59db9e3  mov r11, [r13+r14*1]
000070bab59db9e8  movq xmm13, r12
000070bab59db9ed  movq xmm12, r11
000070bab59db9f2  movq xmm13, xmm13
000070bab59db9f7  vmovaps [rsp+0x10], xmm13
000070bab59db9fd  movq xmm13, xmm13
000070bab59dba02  movaps [r15+0x130], xmm13
000070bab59dba0a  movq xmm12, xmm12
000070bab59dba0f  vmovaps [rsp+0x20], xmm12
000070bab59dba15  movq xmm12, xmm12
000070bab59dba1a  movaps [r15+0x280], xmm12
000070bab59dba22  movaps xmm13, [r15+0x270]
000070bab59dba2a  vmovaps [rsp+0x30], xmm13
000070bab59dba30  vmovaps xmm12, [rsp+0x30]
000070bab59dba36  por xmm13, xmm12
000070bab59dba3b  lea r14, [rax+0x20]
000070bab59dba3f  mov r12, [r13+r14*1]
000070bab59dba44  lea r14, [rax+0x28]
000070bab59dba48  mov r11, [r13+r14*1]
000070bab59dba4d  movq xmm12, r12
000070bab59dba52  movq xmm11, r11
000070bab59dba57  movq xmm12, xmm12
000070bab59dba5c  vmovaps [rsp+0x30], xmm12
000070bab59dba62  movq xmm12, xmm12
000070bab59dba67  movaps [r15+0x150], xmm12
000070bab59dba6f  movq xmm11, xmm11
000070bab59dba74  vmovaps [rsp+0x40], xmm11
000070bab59dba7a  movq xmm11, xmm11
000070bab59dba7f  movaps [r15+0x140], xmm11
000070bab59dba87  lea r14, [rax+0x10]
000070bab59dba8b  mov r12, [r13+r14*1]
000070bab59dba90  lea r14, [rax+0x18]
000070bab59dba94  mov r11, [r13+r14*1]
000070bab59dba99  movq xmm12, r12
000070bab59dba9e  movq xmm11, r11
000070bab59dbaa3  movq xmm12, xmm12
000070bab59dbaa8  vmovaps [rsp+0x50], xmm12
000070bab59dbaae  movq xmm12, xmm12
000070bab59dbab3  movaps [r15+0x170], xmm12
000070bab59dbabb  movq xmm11, xmm11
000070bab59dbac0  vmovaps [rsp+0x60], xmm11
000070bab59dbac6  movq xmm11, xmm11
000070bab59dbacb  movaps [r15+0x160], xmm11
000070bab59dbad3  mov r14, [r13+rax*1]
000070bab59dbad8  vmovq xmm12, r14
000070bab59dbadd  vpbroadcastq xmm12, xmm12
000070bab59dbae2  lea r14, [rax+0x08]
000070bab59dbae6  mov rax, [r13+r14*1]
000070bab59dbaeb  movq xmm11, rax
000070bab59dbaf0  movaps [r15+0x230], xmm11
000070bab59dbaf8  mov rax, [r15+0xF8]
000070bab59dbaff  lea r14, [rax+0x50]
000070bab59dbb03  movups xmm11, [r13+r14*1]
000070bab59dbb09  lea r14, [rax+0x60]
000070bab59dbb0d  movups xmm10, [r13+r14*1]
000070bab59dbb13  lea r14, [rax+0x30]
000070bab59dbb17  movups xmm9, [r13+r14*1]
000070bab59dbb1d  mov r14, [r15+0x50]
000070bab59dbb21  mov [r15+0x60], r14
000070bab59dbb25  mov qword ptr [r15+0x58], 0x40
000070bab59dbb2d  movaps xmm8, xmm12
000070bab59dbb31  mulpd xmm8, xmm15
000070bab59dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000070bab59dbb3c  ptest xmm7, xmm7
000070bab59dbb41  jnz 0x000070BAB59DC96A
000070bab59dbb47  movq xmm15, qword ptr [r15+0x230]
000070bab59dbb50  vmovaps [rsp+0x70], xmm15
000070bab59dbb56  vpermilpd xmm15, xmm15, 0x00
000070bab59dbb5c  movaps xmm7, xmm9
000070bab59dbb60  mulpd xmm7, xmm15
000070bab59dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000070bab59dbb6a  ptest xmm6, xmm6
000070bab59dbb6f  jnz 0x000070BAB59DCAAE
000070bab59dbb75  vxorps xmm15, xmm15, xmm15
000070bab59dbb7a  vpbroadcastq xmm15, xmm15
000070bab59dbb7f  movaps xmm9, xmm12
000070bab59dbb83  mulpd xmm9, xmm10
000070bab59dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000070bab59dbb8e  ptest xmm6, xmm6
000070bab59dbb93  jnz 0x000070BAB59DCBF0
000070bab59dbb99  movaps xmm10, xmm12
000070bab59dbb9d  mulpd xmm10, xmm11
000070bab59dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000070bab59dbba8  ptest xmm6, xmm6
000070bab59dbbad  jnz 0x000070BAB59DCD34
000070bab59dbbb3  movaps xmm11, [r15+0x1F0]
000070bab59dbbbb  movaps xmm6, xmm12
000070bab59dbbbf  mulpd xmm6, xmm11
000070bab59dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000070bab59dbbc9  ptest xmm5, xmm5
000070bab59dbbce  jnz 0x000070BAB59DCE78
000070bab59dbbd4  movaps xmm12, [r15+0x2A0]
000070bab59dbbdc  vmovaps [rsp+0x80], xmm12
000070bab59dbbe5  vmovaps xmm11, [rsp+0x80]
000070bab59dbbee  por xmm12, xmm11
000070bab59dbbf3  movaps xmm11, [r15+0x250]
000070bab59dbbfb  vmovaps [rsp+0x80], xmm11
000070bab59dbc04  vmovaps xmm5, [rsp+0x80]
000070bab59dbc0d  por xmm11, xmm5
000070bab59dbc12  vmovaps xmm4, [rsp+0x70]
000070bab59dbc18  vpermilpd xmm4, xmm4, 0x00
000070bab59dbc1e  movaps xmm3, xmm5
000070bab59dbc21  mulpd xmm3, xmm4
000070bab59dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000070bab59dbc2a  ptest xmm2, xmm2
000070bab59dbc2f  jnz 0x000070BAB59DCFBA
000070bab59dbc35  mov [rsp+0x80], rax
000070bab59dbc3d  xor eax, eax
000070bab59dbc3f  mov r12d, 0x40
000070bab59dbc45  mov r11d, 0x200
000070bab59dbc4b  cmp r12, r11
000070bab59dbc4e  cmc
000070bab59dbc4f  lahf
000070bab59dbc50  seto al
000070bab59dbc53  mov [r15+0x108], eax
000070bab59dbc5a  movaps xmm5, xmm8
000070bab59dbc5e  addpd xmm5, xmm15
000070bab59dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000070bab59dbc68  ptest xmm4, xmm4
000070bab59dbc6d  jnz 0x000070BAB59DD0FA
000070bab59dbc73  movaps xmm8, [r15+0x1B0]
000070bab59dbc7b  movaps xmm4, xmm9
000070bab59dbc7f  addpd xmm4, xmm8
000070bab59dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000070bab59dbc89  ptest xmm2, xmm2
000070bab59dbc8e  jnz 0x000070BAB59DD23C
000070bab59dbc94  movaps xmm9, xmm10
000070bab59dbc98  addpd xmm9, xmm8
000070bab59dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000070bab59dbca3  ptest xmm2, xmm2
000070bab59dbca8  jnz 0x000070BAB59DD37E
000070bab59dbcae  movaps xmm10, [r15+0x2F0]
000070bab59dbcb6  vmovaps [rsp+0x90], xmm10
000070bab59dbcbf  vmovaps xmm8, [rsp+0x90]
000070bab59dbcc8  por xmm10, xmm8
000070bab59dbccd  movaps xmm8, [r15+0x2E0]
000070bab59dbcd5  vmovaps [rsp+0x90], xmm8
000070bab59dbcde  vmovaps xmm2, [rsp+0x90]
000070bab59dbce7  por xmm8, xmm2
000070bab59dbcec  movaps xmm2, [r15+0x2D0]
000070bab59dbcf4  vmovaps [rsp+0x90], xmm2
000070bab59dbcfd  vmovaps [rsp+0xA0], xmm1
000070bab59dbd06  vmovaps xmm1, [rsp+0x90]
000070bab59dbd0f  por xmm2, xmm1
000070bab59dbd13  movaps xmm1, [r15+0x200]
000070bab59dbd1b  vmovaps [rsp+0x90], xmm1
000070bab59dbd24  vmovaps [rsp+0xB0], xmm15
000070bab59dbd2d  vmovaps xmm15, [rsp+0x90]
000070bab59dbd36  por xmm1, xmm15
000070bab59dbd3b  movaps xmm15, [r15+0x1C0]
000070bab59dbd43  vmovaps [rsp+0x90], xmm15
000070bab59dbd4c  vmovaps [rsp+0xC0], xmm1
000070bab59dbd55  vmovaps xmm1, [rsp+0x90]
000070bab59dbd5e  por xmm15, xmm1
000070bab59dbd63  movaps xmm1, [r15+0x190]
000070bab59dbd6b  vmovaps [rsp+0x90], xmm1
000070bab59dbd74  vmovaps [rsp+0xD0], xmm15
000070bab59dbd7d  vmovaps xmm15, [rsp+0x90]
000070bab59dbd86  por xmm1, xmm15
000070bab59dbd8b  movaps xmm15, [r15+0x300]
000070bab59dbd93  vmovaps [rsp+0x90], xmm15
000070bab59dbd9c  vmovaps [rsp+0xE0], xmm1
000070bab59dbda5  vmovaps xmm1, [rsp+0x90]
000070bab59dbdae  por xmm15, xmm1
000070bab59dbdb3  mov rax, [rsp+0x80]
000070bab59dbdbb  lea r12, [rax+0xA0]
000070bab59dbdc2  movups xmm1, [r13+r12*1]
000070bab59dbdc8  lea r12, [rax+0xB0]
000070bab59dbdcf  vmovaps [rsp+0x80], xmm1
000070bab59dbdd8  movups xmm1, [r13+r12*1]
000070bab59dbdde  vmovaps [rsp+0x90], xmm1
000070bab59dbde7  vmovaps [rsp+0xF0], xmm15
000070bab59dbdf0  vmovaps xmm15, [rsp+0xB0]
000070bab59dbdf9  vmovaps [rsp+0xB0], xmm14
000070bab59dbe02  movaps xmm1, xmm6
000070bab59dbe05  addpd xmm1, xmm15
000070bab59dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000070bab59dbe0f  ptest xmm14, xmm14
000070bab59dbe15  jnz 0x000070BAB59DD4D6
000070bab59dbe1b  lea r12, [rax+0xF0]
000070bab59dbe22  movups xmm15, [r13+r12*1]
000070bab59dbe28  movaps xmm14, xmm4
000070bab59dbe2c  addpd xmm14, xmm3
000070bab59dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000070bab59dbe37  ptest xmm6, xmm6
000070bab59dbe3c  jnz 0x000070BAB59DD621
000070bab59dbe42  movaps xmm6, xmm9
000070bab59dbe46  addpd xmm6, xmm7
000070bab59dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000070bab59dbe4f  ptest xmm4, xmm4
000070bab59dbe54  jnz 0x000070BAB59DD763
000070bab59dbe5a  vmovaps xmm9, [rsp+0x70]
000070bab59dbe60  vpermilpd xmm9, xmm9, 0x00
000070bab59dbe66  vmovaps xmm4, [rsp+0x90]
000070bab59dbe6f  movaps xmm7, xmm4
000070bab59dbe72  mulpd xmm7, xmm9
000070bab59dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000070bab59dbe7c  ptest xmm3, xmm3
000070bab59dbe81  jnz 0x000070BAB59DD8A4
000070bab59dbe87  vmovaps xmm9, [rsp+0x50]
000070bab59dbe8d  vpermilpd xmm9, xmm9, 0x00
000070bab59dbe93  movaps xmm4, xmm15
000070bab59dbe97  mulpd xmm4, xmm9
000070bab59dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000070bab59dbea1  ptest xmm3, xmm3
000070bab59dbea6  jnz 0x000070BAB59DD9E5
000070bab59dbeac  lea r12, [rax+0xE0]
000070bab59dbeb3  movups xmm15, [r13+r12*1]
000070bab59dbeb9  vmovaps xmm9, [rsp+0x70]
000070bab59dbebf  vpermilpd xmm9, xmm9, 0x00
000070bab59dbec5  vmovaps [rsp+0x70], xmm1
000070bab59dbecb  vmovaps xmm1, [rsp+0x80]
000070bab59dbed4  vmovaps [rsp+0x80], xmm15
000070bab59dbedd  movaps xmm3, xmm1
000070bab59dbee0  mulpd xmm3, xmm9
000070bab59dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000070bab59dbeea  ptest xmm15, xmm15
000070bab59dbef0  jnz 0x000070BAB59DDB31
000070bab59dbef6  vmovaps xmm1, [rsp+0xF0]
000070bab59dbeff  vmovaps xmm15, [rsp+0xF0]
000070bab59dbf08  por xmm1, xmm15
000070bab59dbf0d  movaps [r15+0x300], xmm1
000070bab59dbf15  vmovaps xmm15, [rsp+0xE0]
000070bab59dbf1e  vmovaps xmm9, [rsp+0xE0]
000070bab59dbf27  por xmm15, xmm9
000070bab59dbf2c  movaps [r15+0x190], xmm15
000070bab59dbf34  vmovaps xmm9, [rsp+0x50]
000070bab59dbf3a  vpermilpd xmm9, xmm9, 0x00
000070bab59dbf40  vmovaps [rsp+0x90], xmm1
000070bab59dbf49  vmovaps [rsp+0xE0], xmm15
000070bab59dbf52  vmovaps xmm15, [rsp+0x80]
000070bab59dbf5b  vmovaps [rsp+0x80], xmm14
000070bab59dbf64  movaps xmm1, xmm15
000070bab59dbf68  mulpd xmm1, xmm9
000070bab59dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000070bab59dbf72  ptest xmm14, xmm14
000070bab59dbf78  jnz 0x000070BAB59DDC72
000070bab59dbf7e  lea r12, [rax+0x90]
000070bab59dbf85  movups xmm15, [r13+r12*1]
000070bab59dbf8b  vmovaps xmm14, [rsp+0xD0]
000070bab59dbf94  vmovaps xmm9, [rsp+0xD0]
000070bab59dbf9d  por xmm14, xmm9
000070bab59dbfa2  movaps [r15+0x1C0], xmm14
000070bab59dbfaa  vmovaps xmm9, [rsp+0xC0]
000070bab59dbfb3  vmovaps [rsp+0xD0], xmm1
000070bab59dbfbc  vmovaps xmm1, [rsp+0xC0]
000070bab59dbfc5  por xmm9, xmm1
000070bab59dbfca  movaps [r15+0x200], xmm9
000070bab59dbfd2  vmovaps [rsp+0xC0], xmm2
000070bab59dbfdb  vmovaps xmm1, [rsp+0xC0]
000070bab59dbfe4  por xmm2, xmm1
000070bab59dbfe8  movaps [r15+0x2D0], xmm2
000070bab59dbff0  vmovaps [rsp+0xC0], xmm8
000070bab59dbff9  vmovaps xmm1, [rsp+0xC0]
000070bab59dc002  por xmm8, xmm1
000070bab59dc007  movaps [r15+0x2E0], xmm8
000070bab59dc00f  vmovaps [rsp+0xC0], xmm15
000070bab59dc018  movaps xmm1, xmm5
000070bab59dc01b  addpd xmm1, xmm7
000070bab59dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000070bab59dc024  ptest xmm15, xmm15
000070bab59dc02a  jnz 0x000070BAB59DDDBE
000070bab59dc030  vmovaps xmm15, [rsp+0x50]
000070bab59dc036  vpermilpd xmm15, xmm15, 0x00
000070bab59dc03c  vmovaps xmm5, [rsp+0xC0]
000070bab59dc045  vmovaps [rsp+0xC0], xmm1
000070bab59dc04e  movaps xmm7, xmm5
000070bab59dc051  mulpd xmm7, xmm15
000070bab59dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000070bab59dc05b  ptest xmm1, xmm1
000070bab59dc060  jnz 0x000070BAB59DDEFE
000070bab59dc066  lea r12, [rax+0x80]
000070bab59dc06d  movups xmm1, [r13+r12*1]
000070bab59dc073  vmovaps xmm5, [rsp+0x70]
000070bab59dc079  vmovaps [rsp+0x70], xmm1
000070bab59dc07f  movaps xmm15, xmm5
000070bab59dc083  addpd xmm15, xmm3
000070bab59dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000070bab59dc08e  ptest xmm1, xmm1
000070bab59dc093  jnz 0x000070BAB59DE049
000070bab59dc099  vmovaps xmm5, [rsp+0x80]
000070bab59dc0a2  movaps xmm1, xmm5
000070bab59dc0a5  addpd xmm1, xmm4
000070bab59dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000070bab59dc0ae  ptest xmm3, xmm3
000070bab59dc0b3  jnz 0x000070BAB59DE18B
000070bab59dc0b9  vmovaps [rsp+0x80], xmm10
000070bab59dc0c2  vmovaps xmm5, [rsp+0x80]
000070bab59dc0cb  por xmm10, xmm5
000070bab59dc0d0  movaps [r15+0x2F0], xmm10
000070bab59dc0d8  vmovaps xmm5, [rsp+0x50]
000070bab59dc0de  vpermilpd xmm5, xmm5, 0x00
000070bab59dc0e4  vmovaps xmm3, [rsp+0x70]
000070bab59dc0ea  vmovaps [rsp+0x50], xmm1
000070bab59dc0f0  movaps xmm4, xmm3
000070bab59dc0f3  mulpd xmm4, xmm5
000070bab59dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000070bab59dc0fc  ptest xmm1, xmm1
000070bab59dc101  jnz 0x000070BAB59DE2CB
000070bab59dc107  lea r12, [rax+0xD0]
000070bab59dc10e  movups xmm1, [r13+r12*1]
000070bab59dc114  vmovaps xmm3, [rsp+0xD0]
000070bab59dc11d  vmovaps [rsp+0x70], xmm1
000070bab59dc123  movaps xmm5, xmm6
000070bab59dc126  addpd xmm5, xmm3
000070bab59dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000070bab59dc12f  ptest xmm1, xmm1
000070bab59dc134  jnz 0x000070BAB59DE415
000070bab59dc13a  vmovaps xmm1, [rsp+0x60]
000070bab59dc140  vpermilpd xmm1, xmm1, 0x00
000070bab59dc146  movaps xmm6, xmm9
000070bab59dc14a  mulpd xmm6, xmm1
000070bab59dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000070bab59dc153  ptest xmm3, xmm3
000070bab59dc158  jnz 0x000070BAB59DE555
000070bab59dc15e  movaps [r15+0x260], xmm6
000070bab59dc166  vxorps xmm1, xmm1, xmm1
000070bab59dc16a  vpbroadcastq xmm1, xmm1
000070bab59dc16f  movaps [r15+0x1B0], xmm1
000070bab59dc177  vmovaps xmm1, [rsp+0x60]
000070bab59dc17d  vpermilpd xmm1, xmm1, 0x00
000070bab59dc183  vmovaps xmm3, [rsp+0x70]
000070bab59dc189  vmovaps [rsp+0x70], xmm15
000070bab59dc18f  movaps xmm9, xmm3
000070bab59dc193  mulpd xmm9, xmm1
000070bab59dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000070bab59dc19e  ptest xmm15, xmm15
000070bab59dc1a4  jnz 0x000070BAB59DE696
000070bab59dc1aa  lea r12, [rax+0xC0]
000070bab59dc1b1  movups xmm1, [r13+r12*1]
000070bab59dc1b7  vmovaps xmm3, [rsp+0xC0]
000070bab59dc1c0  vmovaps [rsp+0x80], xmm1
000070bab59dc1c9  movaps xmm15, xmm3
000070bab59dc1cd  addpd xmm15, xmm7
000070bab59dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000070bab59dc1d8  ptest xmm1, xmm1
000070bab59dc1dd  jnz 0x000070BAB59DE7E2
000070bab59dc1e3  vmovaps [rsp+0xC0], xmm13
000070bab59dc1ec  vmovaps xmm1, [rsp+0xC0]
000070bab59dc1f5  por xmm13, xmm1
000070bab59dc1fa  movaps [r15+0x270], xmm13
000070bab59dc202  vmovaps xmm1, [rsp+0xB0]
000070bab59dc20b  vmovaps xmm7, [rsp+0xB0]
000070bab59dc214  por xmm1, xmm7
000070bab59dc218  movaps [r15+0x1A0], xmm1
000070bab59dc220  vmovaps xmm1, [rsp+0x60]
000070bab59dc226  vpermilpd xmm1, xmm1, 0x00
000070bab59dc22c  vmovaps [rsp+0xB0], xmm1
000070bab59dc235  vmovaps xmm1, [rsp+0x80]
000070bab59dc23e  vmovaps [rsp+0x80], xmm15
000070bab59dc247  vmovaps xmm15, [rsp+0xB0]
000070bab59dc250  vmovaps [rsp+0xB0], xmm14
000070bab59dc259  movaps xmm3, xmm1
000070bab59dc25c  mulpd xmm3, xmm15
000070bab59dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000070bab59dc266  ptest xmm14, xmm14
000070bab59dc26c  jnz 0x000070BAB59DE924
000070bab59dc272  lea r12, [rax+0x20]
000070bab59dc276  movups xmm1, [r13+r12*1]
000070bab59dc27c  movaps [r15+0x110], xmm1
000070bab59dc284  vmovaps xmm14, [rsp+0x70]
000070bab59dc28a  vmovaps [rsp+0x70], xmm1
000070bab59dc290  movaps xmm15, xmm14
000070bab59dc294  addpd xmm15, xmm4
000070bab59dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000070bab59dc29f  ptest xmm1, xmm1
000070bab59dc2a4  jnz 0x000070BAB59DEA6F
000070bab59dc2aa  vmovaps xmm1, [rsp+0x60]
000070bab59dc2b0  vpermilpd xmm1, xmm1, 0x00
000070bab59dc2b6  movaps xmm14, xmm2
000070bab59dc2ba  mulpd xmm14, xmm1
000070bab59dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000070bab59dc2c5  ptest xmm4, xmm4
000070bab59dc2ca  jnz 0x000070BAB59DEBB2
000070bab59dc2d0  vmovaps xmm4, [rsp+0x50]
000070bab59dc2d6  movaps xmm1, xmm4
000070bab59dc2d9  addpd xmm1, xmm9
000070bab59dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000070bab59dc2e3  ptest xmm2, xmm2
000070bab59dc2e8  jnz 0x000070BAB59DECF4
000070bab59dc2ee  vmovaps xmm9, [rsp+0x30]
000070bab59dc2f4  vpermilpd xmm9, xmm9, 0x00
000070bab59dc2fa  vmovaps xmm2, [rsp+0x70]
000070bab59dc300  vmovaps [rsp+0x50], xmm1
000070bab59dc306  movaps xmm4, xmm2
000070bab59dc309  mulpd xmm4, xmm9
000070bab59dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000070bab59dc313  ptest xmm1, xmm1
000070bab59dc318  jnz 0x000070BAB59DEE35
000070bab59dc31e  vmovaps xmm1, [rsp+0x30]
000070bab59dc324  vpermilpd xmm1, xmm1, 0x00
000070bab59dc32a  vmovaps xmm2, [rsp+0x90]
000070bab59dc333  vmovaps [rsp+0x60], xmm15
000070bab59dc339  movaps xmm9, xmm2
000070bab59dc33d  mulpd xmm9, xmm1
000070bab59dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000070bab59dc348  ptest xmm15, xmm15
000070bab59dc34e  jnz 0x000070BAB59DEF76
000070bab59dc354  vmovaps xmm15, [rsp+0x80]
000070bab59dc35d  movaps xmm1, xmm15
000070bab59dc361  addpd xmm1, xmm6
000070bab59dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000070bab59dc36a  ptest xmm2, xmm2
000070bab59dc36f  jnz 0x000070BAB59DF0B8
000070bab59dc375  movaps xmm15, xmm5
000070bab59dc379  addpd xmm15, xmm3
000070bab59dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000070bab59dc384  ptest xmm6, xmm6
000070bab59dc389  jnz 0x000070BAB59DF1F9
000070bab59dc38f  vmovaps xmm6, [rsp+0x30]
000070bab59dc395  vpermilpd xmm6, xmm6, 0x00
000070bab59dc39b  movaps xmm5, xmm8
000070bab59dc39f  mulpd xmm5, xmm6
000070bab59dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000070bab59dc3a8  ptest xmm3, xmm3
000070bab59dc3ad  jnz 0x000070BAB59DF33B
000070bab59dc3b3  vmovaps xmm8, [rsp+0x30]
000070bab59dc3b9  vpermilpd xmm8, xmm8, 0x00
000070bab59dc3bf  movaps xmm6, xmm10
000070bab59dc3c3  mulpd xmm6, xmm8
000070bab59dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000070bab59dc3cd  ptest xmm3, xmm3
000070bab59dc3d2  jnz 0x000070BAB59DF47C
000070bab59dc3d8  vmovaps xmm8, [rsp+0x60]
000070bab59dc3de  movaps xmm10, xmm8
000070bab59dc3e2  addpd xmm10, xmm14
000070bab59dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000070bab59dc3ed  ptest xmm3, xmm3
000070bab59dc3f2  jnz 0x000070BAB59DF5BE
000070bab59dc3f8  vmovaps xmm8, [rsp+0x50]
000070bab59dc3fe  movaps xmm14, xmm8
000070bab59dc402  addpd xmm14, xmm4
000070bab59dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000070bab59dc40d  ptest xmm3, xmm3
000070bab59dc412  jnz 0x000070BAB59DF702
000070bab59dc418  vmovaps xmm8, [rsp+0x40]
000070bab59dc41e  vpermilpd xmm8, xmm8, 0x00
000070bab59dc424  movaps xmm4, xmm13
000070bab59dc428  mulpd xmm4, xmm8
000070bab59dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000070bab59dc432  ptest xmm3, xmm3
000070bab59dc437  jnz 0x000070BAB59DF845
000070bab59dc43d  movaps xmm13, xmm15
000070bab59dc441  addpd xmm13, xmm9
000070bab59dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000070bab59dc44c  ptest xmm8, xmm8
000070bab59dc452  jnz 0x000070BAB59DF987
000070bab59dc458  movaps xmm15, xmm1
000070bab59dc45c  addpd xmm15, xmm5
000070bab59dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000070bab59dc467  ptest xmm9, xmm9
000070bab59dc46d  jnz 0x000070BAB59DFACB
000070bab59dc473  vmovaps [rsp+0x30], xmm11
000070bab59dc479  vmovaps xmm1, [rsp+0x30]
000070bab59dc47f  por xmm11, xmm1
000070bab59dc484  movaps [r15+0x250], xmm11
000070bab59dc48c  vmovaps [rsp+0x30], xmm12
000070bab59dc492  vmovaps xmm1, [rsp+0x30]
000070bab59dc498  por xmm12, xmm1
000070bab59dc49d  movaps [r15+0x2A0], xmm12
000070bab59dc4a5  vmovaps xmm1, [rsp+0xA0]
000070bab59dc4ae  vmovaps xmm11, [rsp+0xA0]
000070bab59dc4b7  por xmm1, xmm11
000070bab59dc4bc  movaps [r15+0x1D0], xmm1
000070bab59dc4c4  lea r12, [rax+0x40]
000070bab59dc4c8  movups xmm1, [r13+r12*1]
000070bab59dc4ce  movaps [r15+0x2C0], xmm1
000070bab59dc4d6  vmovaps xmm11, [rsp+0x40]
000070bab59dc4dc  vpermilpd xmm11, xmm11, 0x00
000070bab59dc4e2  vmovaps xmm8, [rsp+0xE0]
000070bab59dc4eb  movaps xmm9, xmm8
000070bab59dc4ef  mulpd xmm9, xmm11
000070bab59dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000070bab59dc4fa  ptest xmm5, xmm5
000070bab59dc4ff  jnz 0x000070BAB59DFC17
000070bab59dc505  movaps xmm11, xmm10
000070bab59dc509  addpd xmm11, xmm6
000070bab59dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000070bab59dc514  ptest xmm8, xmm8
000070bab59dc51a  jnz 0x000070BAB59DFD5B
000070bab59dc520  movaps xmm10, xmm14
000070bab59dc524  addpd xmm10, xmm4
000070bab59dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000070bab59dc52f  ptest xmm8, xmm8
000070bab59dc535  jnz 0x000070BAB59DFE9E
000070bab59dc53b  vmovaps xmm14, [rsp+0x40]
000070bab59dc541  vpermilpd xmm14, xmm14, 0x00
000070bab59dc547  movaps xmm8, xmm1
000070bab59dc54b  mulpd xmm8, xmm14
000070bab59dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000070bab59dc556  ptest xmm6, xmm6
000070bab59dc55b  jnz 0x000070BAB59DFFE1
000070bab59dc561  movaps xmm1, [r15+0x2B0]
000070bab59dc569  vmovaps xmm14, [rsp+0x40]
000070bab59dc56f  vpermilpd xmm14, xmm14, 0x00
000070bab59dc575  movaps xmm6, xmm1
000070bab59dc578  mulpd xmm6, xmm14
000070bab59dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000070bab59dc582  ptest xmm5, xmm5
000070bab59dc587  jnz 0x000070BAB59E0124
000070bab59dc58d  vmovaps xmm1, [rsp+0x10]
000070bab59dc593  vpermilpd xmm1, xmm1, 0x00
000070bab59dc599  movaps xmm14, xmm12
000070bab59dc59d  mulpd xmm14, xmm1
000070bab59dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000070bab59dc5a8  ptest xmm5, xmm5
000070bab59dc5ad  jnz 0x000070BAB59E0265
000070bab59dc5b3  movaps xmm1, xmm13
000070bab59dc5b7  addpd xmm1, xmm9
000070bab59dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000070bab59dc5c1  ptest xmm12, xmm12
000070bab59dc5c7  jnz 0x000070BAB59E03A8
000070bab59dc5cd  vmovaps xmm13, [rsp+0x10]
000070bab59dc5d3  vpermilpd xmm13, xmm13, 0x00
000070bab59dc5d9  movaps xmm12, xmm7
000070bab59dc5dd  mulpd xmm12, xmm13
000070bab59dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000070bab59dc5e8  ptest xmm9, xmm9
000070bab59dc5ee  jnz 0x000070BAB59E04EA
000070bab59dc5f4  movaps xmm13, xmm15
000070bab59dc5f8  addpd xmm13, xmm8
000070bab59dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000070bab59dc603  ptest xmm9, xmm9
000070bab59dc609  jnz 0x000070BAB59E062D
000070bab59dc60f  movaps xmm15, [r15+0x290]
000070bab59dc617  vmovaps xmm9, [rsp+0x10]
000070bab59dc61d  vpermilpd xmm9, xmm9, 0x00
000070bab59dc623  movaps xmm8, xmm15
000070bab59dc627  mulpd xmm8, xmm9
000070bab59dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000070bab59dc632  ptest xmm7, xmm7
000070bab59dc637  jnz 0x000070BAB59E0771
000070bab59dc63d  movaps xmm15, xmm11
000070bab59dc641  addpd xmm15, xmm6
000070bab59dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000070bab59dc64c  ptest xmm9, xmm9
000070bab59dc652  jnz 0x000070BAB59E08B5
000070bab59dc658  movaps xmm11, [r15+0x1E0]
000070bab59dc660  vmovaps xmm9, [rsp+0x10]
000070bab59dc666  vpermilpd xmm9, xmm9, 0x00
000070bab59dc66c  movaps xmm7, xmm11
000070bab59dc670  mulpd xmm7, xmm9
000070bab59dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000070bab59dc67a  ptest xmm6, xmm6
000070bab59dc67f  jnz 0x000070BAB59E09F8
000070bab59dc685  movaps xmm11, xmm10
000070bab59dc689  addpd xmm11, xmm14
000070bab59dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000070bab59dc694  ptest xmm9, xmm9
000070bab59dc69a  jnz 0x000070BAB59E0B3A
000070bab59dc6a0  lea r12, [rax+0x70]
000070bab59dc6a4  movups xmm14, [r13+r12*1]
000070bab59dc6aa  movaps [r15+0x240], xmm14
000070bab59dc6b2  movaps xmm10, xmm1
000070bab59dc6b6  addpd xmm10, xmm12
000070bab59dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000070bab59dc6c1  ptest xmm9, xmm9
000070bab59dc6c7  jnz 0x000070BAB59E0C88
000070bab59dc6cd  movaps [r15+0x170], xmm10
000070bab59dc6d5  vmovaps xmm1, [rsp+0x20]
000070bab59dc6db  vpermilpd xmm1, xmm1, 0x00
000070bab59dc6e1  movaps xmm12, xmm14
000070bab59dc6e5  mulpd xmm12, xmm1
000070bab59dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000070bab59dc6f0  ptest xmm9, xmm9
000070bab59dc6f6  jnz 0x000070BAB59E0DCB
000070bab59dc6fc  vmovaps xmm1, [rsp+0x20]
000070bab59dc702  vpermilpd xmm1, xmm1, 0x00
000070bab59dc708  vmovaps xmm9, [rsp+0xB0]
000070bab59dc711  movaps xmm14, xmm9
000070bab59dc715  mulpd xmm14, xmm1
000070bab59dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000070bab59dc720  ptest xmm6, xmm6
000070bab59dc725  jnz 0x000070BAB59E0F0E
000070bab59dc72b  movaps [r15+0x180], xmm14
000070bab59dc733  movaps xmm1, xmm13
000070bab59dc737  addpd xmm1, xmm8
000070bab59dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000070bab59dc741  ptest xmm9, xmm9
000070bab59dc747  jnz 0x000070BAB59E1051
000070bab59dc74d  movaps [r15+0x210], xmm1
000070bab59dc755  movups xmm13, [r13+rax*1]
000070bab59dc75b  lea r12, [rax+0x10]
000070bab59dc75f  movups xmm9, [r13+r12*1]
000070bab59dc765  movaps [r15+0x230], xmm9
000070bab59dc76d  movaps xmm8, xmm15
000070bab59dc771  addpd xmm8, xmm7
000070bab59dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000070bab59dc77c  ptest xmm6, xmm6
000070bab59dc781  jnz 0x000070BAB59E11A7
000070bab59dc787  movaps [r15+0x130], xmm8
000070bab59dc78f  vmovaps xmm15, [rsp+0x20]
000070bab59dc795  vpermilpd xmm15, xmm15, 0x00
000070bab59dc79b  movaps xmm7, xmm9
000070bab59dc79f  mulpd xmm7, xmm15
000070bab59dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000070bab59dc7a9  ptest xmm6, xmm6
000070bab59dc7ae  jnz 0x000070BAB59E12EA
000070bab59dc7b4  movaps [r15+0x220], xmm7
000070bab59dc7bc  vmovaps xmm15, [rsp+0x20]
000070bab59dc7c2  vpermilpd xmm15, xmm15, 0x00
000070bab59dc7c8  movaps xmm9, xmm13
000070bab59dc7cc  mulpd xmm9, xmm15
000070bab59dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000070bab59dc7d7  ptest xmm6, xmm6
000070bab59dc7dc  jnz 0x000070BAB59E142C
000070bab59dc7e2  movaps xmm15, xmm11
000070bab59dc7e6  addpd xmm15, xmm12
000070bab59dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000070bab59dc7f1  ptest xmm13, xmm13
000070bab59dc7f7  jnz 0x000070BAB59E1570
000070bab59dc7fd  movaps [r15+0x140], xmm15
000070bab59dc805  movaps xmm13, xmm10
000070bab59dc809  addpd xmm13, xmm14
000070bab59dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000070bab59dc814  ptest xmm12, xmm12
000070bab59dc81a  jnz 0x000070BAB59E16B4
000070bab59dc820  movaps [r15+0x150], xmm13
000070bab59dc828  movaps xmm14, xmm1
000070bab59dc82c  addpd xmm14, xmm7
000070bab59dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000070bab59dc837  ptest xmm12, xmm12
000070bab59dc83d  jnz 0x000070BAB59E17F8
000070bab59dc843  movaps [r15+0x160], xmm14
000070bab59dc84b  movaps xmm1, xmm8
000070bab59dc84f  addpd xmm1, xmm9
000070bab59dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000070bab59dc859  ptest xmm12, xmm12
000070bab59dc85f  jnz 0x000070BAB59E193A
000070bab59dc865  movaps [r15+0x120], xmm1
000070bab59dc86d  movups [r13+r14*1], xmm15
000070bab59dc873  lea rax, [r14+0x10]
000070bab59dc877  movups [r13+rax*1], xmm13
000070bab59dc87d  lea rax, [r14+0x20]
000070bab59dc881  movups [r13+rax*1], xmm14
000070bab59dc887  lea rax, [r14+0x30]
000070bab59dc88b  movups [r13+rax*1], xmm1
000070bab59dc891  mov eax, [r15+0x108]
000070bab59dc898  sahf
000070bab59dc899  jnz 0x000070BAB59DC8CB
000070bab59dc89b  cmp dword ptr [r15+0x318], 0x00
000070bab59dc8a3  jz 0x000070BAB59DB900
000070bab59dc8a9  nop [rax+rax*1], ax
000070bab59dc8b2  nop [rax+rax*1], eax
000070bab59dc8ba  mov eax, 0x410444
000070bab59dc8bf  mov [r15+0x100], rax
000070bab59dc8c6  jmp 0x000070BAB57FE110
000070bab59dc8cb  cmp dword ptr [r15+0x318], 0x00
000070bab59dc8d3  jz 0x000070BAB59D57E0
000070bab59dc8d9  nop [rax+rax*1], ax
000070bab59dc8e2  nop [rax+rax*1], eax
000070bab59dc8ea  mov eax, 0x410278
000070bab59dc8ef  mov [r15+0x100], rax
000070bab59dc8f6  jmp 0x000070BAB57FE110
000070bab59dc8fb  int3
000070bab59dc8fc  call 0x000070BAB58E27E0
000070bab59dc901  jmp 0x000070BAB59DB9DF
000070bab59dc906  call 0x000070BAB58E1570
000070bab59dc90b  jmp 0x000070BAB59DB9E8
000070bab59dc910  call 0x000070BAB58E27E0
000070bab59dc915  jmp 0x000070BAB59DBA44
000070bab59dc91a  call 0x000070BAB58E1570
000070bab59dc91f  jmp 0x000070BAB59DBA4D
000070bab59dc924  call 0x000070BAB58E27E0
000070bab59dc929  jmp 0x000070BAB59DBA90
000070bab59dc92e  call 0x000070BAB58E1570
000070bab59dc933  jmp 0x000070BAB59DBA99
000070bab59dc938  call 0x000070BAB580DC20
000070bab59dc93d  jmp 0x000070BAB59DBAD8
000070bab59dc942  call 0x000070BAB58D59C0
000070bab59dc947  jmp 0x000070BAB59DBAEB
000070bab59dc94c  call 0x000070BAB58E0E30
000070bab59dc951  jmp 0x000070BAB59DBB09
000070bab59dc956  call 0x000070BAB58DFBC0
000070bab59dc95b  jmp 0x000070BAB59DBB13
000070bab59dc960  call 0x000070BAB58DE950
000070bab59dc965  jmp 0x000070BAB59DBB1D
000070bab59dc96a  sub rsp, 0x08
000070bab59dc96e  push rax
000070bab59dc96f  push rcx
000070bab59dc970  push rdx
000070bab59dc971  push rdi
000070bab59dc972  push rsi
000070bab59dc973  push r8
000070bab59dc975  push r9
000070bab59dc977  push r10
000070bab59dc979  push r11
000070bab59dc97b  sub rsp, 0xF0
000070bab59dc982  vmovaps [rsp], xmm0
000070bab59dc987  vmovaps [rsp+0x10], xmm1
000070bab59dc98d  vmovaps [rsp+0x20], xmm2
000070bab59dc993  vmovaps [rsp+0x30], xmm3
000070bab59dc999  vmovaps [rsp+0x40], xmm4
000070bab59dc99f  vmovaps [rsp+0x50], xmm5
000070bab59dc9a5  vmovaps [rsp+0x60], xmm6
000070bab59dc9ab  vmovaps [rsp+0x70], xmm7
000070bab59dc9b1  vmovaps [rsp+0x80], xmm9
000070bab59dc9ba  vmovaps [rsp+0x90], xmm10
000070bab59dc9c3  vmovaps [rsp+0xA0], xmm11
000070bab59dc9cc  vmovaps [rsp+0xB0], xmm12
000070bab59dc9d5  vmovaps [rsp+0xC0], xmm13
000070bab59dc9de  vmovaps [rsp+0xD0], xmm14
000070bab59dc9e7  vmovaps [rsp+0xE0], xmm15
000070bab59dc9f0  sub rsp, 0x30
000070bab59dc9f4  movaps [rsp], xmm8
000070bab59dc9f9  movaps [rsp+0x10], xmm12
000070bab59dc9ff  movaps [rsp+0x20], xmm15
000070bab59dca05  lea rdi, [rsp]
000070bab59dca09  mov esi, 0x00
000070bab59dca0e  mov rax, 0x63B35AFBC530
000070bab59dca18  call rax
000070bab59dca1a  movaps xmm8, [rsp]
000070bab59dca1f  add rsp, 0x30
000070bab59dca23  vmovaps xmm0, [rsp]
000070bab59dca28  vmovaps xmm1, [rsp+0x10]
000070bab59dca2e  vmovaps xmm2, [rsp+0x20]
000070bab59dca34  vmovaps xmm3, [rsp+0x30]
000070bab59dca3a  vmovaps xmm4, [rsp+0x40]
000070bab59dca40  vmovaps xmm5, [rsp+0x50]
000070bab59dca46  vmovaps xmm6, [rsp+0x60]
000070bab59dca4c  vmovaps xmm7, [rsp+0x70]
000070bab59dca52  vmovaps xmm9, [rsp+0x80]
000070bab59dca5b  vmovaps xmm10, [rsp+0x90]
000070bab59dca64  vmovaps xmm11, [rsp+0xA0]
000070bab59dca6d  vmovaps xmm12, [rsp+0xB0]
000070bab59dca76  vmovaps xmm13, [rsp+0xC0]
000070bab59dca7f  vmovaps xmm14, [rsp+0xD0]
000070bab59dca88  vmovaps xmm15, [rsp+0xE0]
000070bab59dca91  add rsp, 0xF0
000070bab59dca98  pop r11
000070bab59dca9a  pop r10
000070bab59dca9c  pop r9
000070bab59dca9e  pop r8
000070bab59dcaa0  pop rsi
000070bab59dcaa1  pop rdi
000070bab59dcaa2  pop rdx
000070bab59dcaa3  pop rcx
000070bab59dcaa4  pop rax
000070bab59dcaa5  add rsp, 0x08
000070bab59dcaa9  jmp 0x000070BAB59DBB47
000070bab59dcaae  sub rsp, 0x08
000070bab59dcab2  push rax
000070bab59dcab3  push rcx
000070bab59dcab4  push rdx
000070bab59dcab5  push rdi
000070bab59dcab6  push rsi
000070bab59dcab7  push r8
000070bab59dcab9  push r9
000070bab59dcabb  push r10
000070bab59dcabd  push r11
000070bab59dcabf  sub rsp, 0xF0
000070bab59dcac6  vmovaps [rsp], xmm0
000070bab59dcacb  vmovaps [rsp+0x10], xmm1
000070bab59dcad1  vmovaps [rsp+0x20], xmm2
000070bab59dcad7  vmovaps [rsp+0x30], xmm3
000070bab59dcadd  vmovaps [rsp+0x40], xmm4
000070bab59dcae3  vmovaps [rsp+0x50], xmm5
000070bab59dcae9  vmovaps [rsp+0x60], xmm6
000070bab59dcaef  vmovaps [rsp+0x70], xmm8
000070bab59dcaf5  vmovaps [rsp+0x80], xmm9
000070bab59dcafe  vmovaps [rsp+0x90], xmm10
000070bab59dcb07  vmovaps [rsp+0xA0], xmm11
000070bab59dcb10  vmovaps [rsp+0xB0], xmm12
000070bab59dcb19  vmovaps [rsp+0xC0], xmm13
000070bab59dcb22  vmovaps [rsp+0xD0], xmm14
000070bab59dcb2b  vmovaps [rsp+0xE0], xmm15
000070bab59dcb34  sub rsp, 0x30
000070bab59dcb38  movaps [rsp], xmm7
000070bab59dcb3c  movaps [rsp+0x10], xmm9
000070bab59dcb42  movaps [rsp+0x20], xmm15
000070bab59dcb48  lea rdi, [rsp]
000070bab59dcb4c  mov esi, 0x00
000070bab59dcb51  mov rax, 0x63B35AFBC530
000070bab59dcb5b  call rax
000070bab59dcb5d  movaps xmm7, [rsp]
000070bab59dcb61  add rsp, 0x30
000070bab59dcb65  vmovaps xmm0, [rsp]
000070bab59dcb6a  vmovaps xmm1, [rsp+0x10]
000070bab59dcb70  vmovaps xmm2, [rsp+0x20]
000070bab59dcb76  vmovaps xmm3, [rsp+0x30]
000070bab59dcb7c  vmovaps xmm4, [rsp+0x40]
000070bab59dcb82  vmovaps xmm5, [rsp+0x50]
000070bab59dcb88  vmovaps xmm6, [rsp+0x60]
000070bab59dcb8e  vmovaps xmm8, [rsp+0x70]
000070bab59dcb94  vmovaps xmm9, [rsp+0x80]
000070bab59dcb9d  vmovaps xmm10, [rsp+0x90]
000070bab59dcba6  vmovaps xmm11, [rsp+0xA0]
000070bab59dcbaf  vmovaps xmm12, [rsp+0xB0]
000070bab59dcbb8  vmovaps xmm13, [rsp+0xC0]
000070bab59dcbc1  vmovaps xmm14, [rsp+0xD0]
000070bab59dcbca  vmovaps xmm15, [rsp+0xE0]
000070bab59dcbd3  add rsp, 0xF0
000070bab59dcbda  pop r11
000070bab59dcbdc  pop r10
000070bab59dcbde  pop r9
000070bab59dcbe0  pop r8
000070bab59dcbe2  pop rsi
000070bab59dcbe3  pop rdi
000070bab59dcbe4  pop rdx
000070bab59dcbe5  pop rcx
000070bab59dcbe6  pop rax
000070bab59dcbe7  add rsp, 0x08
000070bab59dcbeb  jmp 0x000070BAB59DBB75
000070bab59dcbf0  sub rsp, 0x08
000070bab59dcbf4  push rax
000070bab59dcbf5  push rcx
000070bab59dcbf6  push rdx
000070bab59dcbf7  push rdi
000070bab59dcbf8  push rsi
000070bab59dcbf9  push r8
000070bab59dcbfb  push r9
000070bab59dcbfd  push r10
000070bab59dcbff  push r11
000070bab59dcc01  sub rsp, 0xF0
000070bab59dcc08  vmovaps [rsp], xmm0
000070bab59dcc0d  vmovaps [rsp+0x10], xmm1
000070bab59dcc13  vmovaps [rsp+0x20], xmm2
000070bab59dcc19  vmovaps [rsp+0x30], xmm3
000070bab59dcc1f  vmovaps [rsp+0x40], xmm4
000070bab59dcc25  vmovaps [rsp+0x50], xmm5
000070bab59dcc2b  vmovaps [rsp+0x60], xmm6
000070bab59dcc31  vmovaps [rsp+0x70], xmm7
000070bab59dcc37  vmovaps [rsp+0x80], xmm8
000070bab59dcc40  vmovaps [rsp+0x90], xmm10
000070bab59dcc49  vmovaps [rsp+0xA0], xmm11
000070bab59dcc52  vmovaps [rsp+0xB0], xmm12
000070bab59dcc5b  vmovaps [rsp+0xC0], xmm13
000070bab59dcc64  vmovaps [rsp+0xD0], xmm14
000070bab59dcc6d  vmovaps [rsp+0xE0], xmm15
000070bab59dcc76  sub rsp, 0x30
000070bab59dcc7a  movaps [rsp], xmm9
000070bab59dcc7f  movaps [rsp+0x10], xmm12
000070bab59dcc85  movaps [rsp+0x20], xmm10
000070bab59dcc8b  lea rdi, [rsp]
000070bab59dcc8f  mov esi, 0x00
000070bab59dcc94  mov rax, 0x63B35AFBC530
000070bab59dcc9e  call rax
000070bab59dcca0  movaps xmm9, [rsp]
000070bab59dcca5  add rsp, 0x30
000070bab59dcca9  vmovaps xmm0, [rsp]
000070bab59dccae  vmovaps xmm1, [rsp+0x10]
000070bab59dccb4  vmovaps xmm2, [rsp+0x20]
000070bab59dccba  vmovaps xmm3, [rsp+0x30]
000070bab59dccc0  vmovaps xmm4, [rsp+0x40]
000070bab59dccc6  vmovaps xmm5, [rsp+0x50]
000070bab59dcccc  vmovaps xmm6, [rsp+0x60]
000070bab59dccd2  vmovaps xmm7, [rsp+0x70]
000070bab59dccd8  vmovaps xmm8, [rsp+0x80]
000070bab59dcce1  vmovaps xmm10, [rsp+0x90]
000070bab59dccea  vmovaps xmm11, [rsp+0xA0]
000070bab59dccf3  vmovaps xmm12, [rsp+0xB0]
000070bab59dccfc  vmovaps xmm13, [rsp+0xC0]
000070bab59dcd05  vmovaps xmm14, [rsp+0xD0]
000070bab59dcd0e  vmovaps xmm15, [rsp+0xE0]
000070bab59dcd17  add rsp, 0xF0
000070bab59dcd1e  pop r11
000070bab59dcd20  pop r10
000070bab59dcd22  pop r9
000070bab59dcd24  pop r8
000070bab59dcd26  pop rsi
000070bab59dcd27  pop rdi
000070bab59dcd28  pop rdx
000070bab59dcd29  pop rcx
000070bab59dcd2a  pop rax
000070bab59dcd2b  add rsp, 0x08
000070bab59dcd2f  jmp 0x000070BAB59DBB99
000070bab59dcd34  sub rsp, 0x08
000070bab59dcd38  push rax
000070bab59dcd39  push rcx
000070bab59dcd3a  push rdx
000070bab59dcd3b  push rdi
000070bab59dcd3c  push rsi
000070bab59dcd3d  push r8
000070bab59dcd3f  push r9
000070bab59dcd41  push r10
000070bab59dcd43  push r11
000070bab59dcd45  sub rsp, 0xF0
000070bab59dcd4c  vmovaps [rsp], xmm0
000070bab59dcd51  vmovaps [rsp+0x10], xmm1
000070bab59dcd57  vmovaps [rsp+0x20], xmm2
000070bab59dcd5d  vmovaps [rsp+0x30], xmm3
000070bab59dcd63  vmovaps [rsp+0x40], xmm4
000070bab59dcd69  vmovaps [rsp+0x50], xmm5
000070bab59dcd6f  vmovaps [rsp+0x60], xmm6
000070bab59dcd75  vmovaps [rsp+0x70], xmm7
000070bab59dcd7b  vmovaps [rsp+0x80], xmm8
000070bab59dcd84  vmovaps [rsp+0x90], xmm9
000070bab59dcd8d  vmovaps [rsp+0xA0], xmm11
000070bab59dcd96  vmovaps [rsp+0xB0], xmm12
000070bab59dcd9f  vmovaps [rsp+0xC0], xmm13
000070bab59dcda8  vmovaps [rsp+0xD0], xmm14
000070bab59dcdb1  vmovaps [rsp+0xE0], xmm15
000070bab59dcdba  sub rsp, 0x30
000070bab59dcdbe  movaps [rsp], xmm10
000070bab59dcdc3  movaps [rsp+0x10], xmm12
000070bab59dcdc9  movaps [rsp+0x20], xmm11
000070bab59dcdcf  lea rdi, [rsp]
000070bab59dcdd3  mov esi, 0x00
000070bab59dcdd8  mov rax, 0x63B35AFBC530
000070bab59dcde2  call rax
000070bab59dcde4  movaps xmm10, [rsp]
000070bab59dcde9  add rsp, 0x30
000070bab59dcded  vmovaps xmm0, [rsp]
000070bab59dcdf2  vmovaps xmm1, [rsp+0x10]
000070bab59dcdf8  vmovaps xmm2, [rsp+0x20]
000070bab59dcdfe  vmovaps xmm3, [rsp+0x30]
000070bab59dce04  vmovaps xmm4, [rsp+0x40]
000070bab59dce0a  vmovaps xmm5, [rsp+0x50]
000070bab59dce10  vmovaps xmm6, [rsp+0x60]
000070bab59dce16  vmovaps xmm7, [rsp+0x70]
000070bab59dce1c  vmovaps xmm8, [rsp+0x80]
000070bab59dce25  vmovaps xmm9, [rsp+0x90]
000070bab59dce2e  vmovaps xmm11, [rsp+0xA0]
000070bab59dce37  vmovaps xmm12, [rsp+0xB0]
000070bab59dce40  vmovaps xmm13, [rsp+0xC0]
000070bab59dce49  vmovaps xmm14, [rsp+0xD0]
000070bab59dce52  vmovaps xmm15, [rsp+0xE0]
000070bab59dce5b  add rsp, 0xF0
000070bab59dce62  pop r11
000070bab59dce64  pop r10
000070bab59dce66  pop r9
000070bab59dce68  pop r8
000070bab59dce6a  pop rsi
000070bab59dce6b  pop rdi
000070bab59dce6c  pop rdx
000070bab59dce6d  pop rcx
000070bab59dce6e  pop rax
000070bab59dce6f  add rsp, 0x08
000070bab59dce73  jmp 0x000070BAB59DBBB3
000070bab59dce78  sub rsp, 0x08
000070bab59dce7c  push rax
000070bab59dce7d  push rcx
000070bab59dce7e  push rdx
000070bab59dce7f  push rdi
000070bab59dce80  push rsi
000070bab59dce81  push r8
000070bab59dce83  push r9
000070bab59dce85  push r10
000070bab59dce87  push r11
000070bab59dce89  sub rsp, 0xF0
000070bab59dce90  vmovaps [rsp], xmm0
000070bab59dce95  vmovaps [rsp+0x10], xmm1
000070bab59dce9b  vmovaps [rsp+0x20], xmm2
000070bab59dcea1  vmovaps [rsp+0x30], xmm3
000070bab59dcea7  vmovaps [rsp+0x40], xmm4
000070bab59dcead  vmovaps [rsp+0x50], xmm5
000070bab59dceb3  vmovaps [rsp+0x60], xmm7
000070bab59dceb9  vmovaps [rsp+0x70], xmm8
000070bab59dcebf  vmovaps [rsp+0x80], xmm9
000070bab59dcec8  vmovaps [rsp+0x90], xmm10
000070bab59dced1  vmovaps [rsp+0xA0], xmm11
000070bab59dceda  vmovaps [rsp+0xB0], xmm12
000070bab59dcee3  vmovaps [rsp+0xC0], xmm13
000070bab59dceec  vmovaps [rsp+0xD0], xmm14
000070bab59dcef5  vmovaps [rsp+0xE0], xmm15
000070bab59dcefe  sub rsp, 0x30
000070bab59dcf02  movaps [rsp], xmm6
000070bab59dcf06  movaps [rsp+0x10], xmm12
000070bab59dcf0c  movaps [rsp+0x20], xmm11
000070bab59dcf12  lea rdi, [rsp]
000070bab59dcf16  mov esi, 0x00
000070bab59dcf1b  mov rax, 0x63B35AFBC530
000070bab59dcf25  call rax
000070bab59dcf27  movaps xmm6, [rsp]
000070bab59dcf2b  add rsp, 0x30
000070bab59dcf2f  vmovaps xmm0, [rsp]
000070bab59dcf34  vmovaps xmm1, [rsp+0x10]
000070bab59dcf3a  vmovaps xmm2, [rsp+0x20]
000070bab59dcf40  vmovaps xmm3, [rsp+0x30]
000070bab59dcf46  vmovaps xmm4, [rsp+0x40]
000070bab59dcf4c  vmovaps xmm5, [rsp+0x50]
000070bab59dcf52  vmovaps xmm7, [rsp+0x60]
000070bab59dcf58  vmovaps xmm8, [rsp+0x70]
000070bab59dcf5e  vmovaps xmm9, [rsp+0x80]
000070bab59dcf67  vmovaps xmm10, [rsp+0x90]
000070bab59dcf70  vmovaps xmm11, [rsp+0xA0]
000070bab59dcf79  vmovaps xmm12, [rsp+0xB0]
000070bab59dcf82  vmovaps xmm13, [rsp+0xC0]
000070bab59dcf8b  vmovaps xmm14, [rsp+0xD0]
000070bab59dcf94  vmovaps xmm15, [rsp+0xE0]
000070bab59dcf9d  add rsp, 0xF0
000070bab59dcfa4  pop r11
000070bab59dcfa6  pop r10
000070bab59dcfa8  pop r9
000070bab59dcfaa  pop r8
000070bab59dcfac  pop rsi
000070bab59dcfad  pop rdi
000070bab59dcfae  pop rdx
000070bab59dcfaf  pop rcx
000070bab59dcfb0  pop rax
000070bab59dcfb1  add rsp, 0x08
000070bab59dcfb5  jmp 0x000070BAB59DBBD4
000070bab59dcfba  sub rsp, 0x08
000070bab59dcfbe  push rax
000070bab59dcfbf  push rcx
000070bab59dcfc0  push rdx
000070bab59dcfc1  push rdi
000070bab59dcfc2  push rsi
000070bab59dcfc3  push r8
000070bab59dcfc5  push r9
000070bab59dcfc7  push r10
000070bab59dcfc9  push r11
000070bab59dcfcb  sub rsp, 0xF0
000070bab59dcfd2  vmovaps [rsp], xmm0
000070bab59dcfd7  vmovaps [rsp+0x10], xmm1
000070bab59dcfdd  vmovaps [rsp+0x20], xmm2
000070bab59dcfe3  vmovaps [rsp+0x30], xmm4
000070bab59dcfe9  vmovaps [rsp+0x40], xmm5
000070bab59dcfef  vmovaps [rsp+0x50], xmm6
000070bab59dcff5  vmovaps [rsp+0x60], xmm7
000070bab59dcffb  vmovaps [rsp+0x70], xmm8
000070bab59dd001  vmovaps [rsp+0x80], xmm9
000070bab59dd00a  vmovaps [rsp+0x90], xmm10
000070bab59dd013  vmovaps [rsp+0xA0], xmm11
000070bab59dd01c  vmovaps [rsp+0xB0], xmm12
000070bab59dd025  vmovaps [rsp+0xC0], xmm13
000070bab59dd02e  vmovaps [rsp+0xD0], xmm14
000070bab59dd037  vmovaps [rsp+0xE0], xmm15
000070bab59dd040  sub rsp, 0x30
000070bab59dd044  movaps [rsp], xmm3
000070bab59dd048  movaps [rsp+0x10], xmm5
000070bab59dd04d  movaps [rsp+0x20], xmm4
000070bab59dd052  lea rdi, [rsp]
000070bab59dd056  mov esi, 0x00
000070bab59dd05b  mov rax, 0x63B35AFBC530
000070bab59dd065  call rax
000070bab59dd067  movaps xmm3, [rsp]
000070bab59dd06b  add rsp, 0x30
000070bab59dd06f  vmovaps xmm0, [rsp]
000070bab59dd074  vmovaps xmm1, [rsp+0x10]
000070bab59dd07a  vmovaps xmm2, [rsp+0x20]
000070bab59dd080  vmovaps xmm4, [rsp+0x30]
000070bab59dd086  vmovaps xmm5, [rsp+0x40]
000070bab59dd08c  vmovaps xmm6, [rsp+0x50]
000070bab59dd092  vmovaps xmm7, [rsp+0x60]
000070bab59dd098  vmovaps xmm8, [rsp+0x70]
000070bab59dd09e  vmovaps xmm9, [rsp+0x80]
000070bab59dd0a7  vmovaps xmm10, [rsp+0x90]
000070bab59dd0b0  vmovaps xmm11, [rsp+0xA0]
000070bab59dd0b9  vmovaps xmm12, [rsp+0xB0]
000070bab59dd0c2  vmovaps xmm13, [rsp+0xC0]
000070bab59dd0cb  vmovaps xmm14, [rsp+0xD0]
000070bab59dd0d4  vmovaps xmm15, [rsp+0xE0]
000070bab59dd0dd  add rsp, 0xF0
000070bab59dd0e4  pop r11
000070bab59dd0e6  pop r10
000070bab59dd0e8  pop r9
000070bab59dd0ea  pop r8
000070bab59dd0ec  pop rsi
000070bab59dd0ed  pop rdi
000070bab59dd0ee  pop rdx
000070bab59dd0ef  pop rcx
000070bab59dd0f0  pop rax
000070bab59dd0f1  add rsp, 0x08
000070bab59dd0f5  jmp 0x000070BAB59DBC35
000070bab59dd0fa  sub rsp, 0x08
000070bab59dd0fe  push rax
000070bab59dd0ff  push rcx
000070bab59dd100  push rdx
000070bab59dd101  push rdi
000070bab59dd102  push rsi
000070bab59dd103  push r8
000070bab59dd105  push r9
000070bab59dd107  push r10
000070bab59dd109  push r11
000070bab59dd10b  sub rsp, 0xF0
000070bab59dd112  vmovaps [rsp], xmm0
000070bab59dd117  vmovaps [rsp+0x10], xmm1
000070bab59dd11d  vmovaps [rsp+0x20], xmm2
000070bab59dd123  vmovaps [rsp+0x30], xmm3
000070bab59dd129  vmovaps [rsp+0x40], xmm4
000070bab59dd12f  vmovaps [rsp+0x50], xmm6
000070bab59dd135  vmovaps [rsp+0x60], xmm7
000070bab59dd13b  vmovaps [rsp+0x70], xmm8
000070bab59dd141  vmovaps [rsp+0x80], xmm9
000070bab59dd14a  vmovaps [rsp+0x90], xmm10
000070bab59dd153  vmovaps [rsp+0xA0], xmm11
000070bab59dd15c  vmovaps [rsp+0xB0], xmm12
000070bab59dd165  vmovaps [rsp+0xC0], xmm13
000070bab59dd16e  vmovaps [rsp+0xD0], xmm14
000070bab59dd177  vmovaps [rsp+0xE0], xmm15
000070bab59dd180  sub rsp, 0x30
000070bab59dd184  movaps [rsp], xmm5
000070bab59dd188  movaps [rsp+0x10], xmm8
000070bab59dd18e  movaps [rsp+0x20], xmm15
000070bab59dd194  lea rdi, [rsp]
000070bab59dd198  mov esi, 0x00
000070bab59dd19d  mov rax, 0x63B35AFBC530
000070bab59dd1a7  call rax
000070bab59dd1a9  movaps xmm5, [rsp]
000070bab59dd1ad  add rsp, 0x30
000070bab59dd1b1  vmovaps xmm0, [rsp]
000070bab59dd1b6  vmovaps xmm1, [rsp+0x10]
000070bab59dd1bc  vmovaps xmm2, [rsp+0x20]
000070bab59dd1c2  vmovaps xmm3, [rsp+0x30]
000070bab59dd1c8  vmovaps xmm4, [rsp+0x40]
000070bab59dd1ce  vmovaps xmm6, [rsp+0x50]
000070bab59dd1d4  vmovaps xmm7, [rsp+0x60]
000070bab59dd1da  vmovaps xmm8, [rsp+0x70]
000070bab59dd1e0  vmovaps xmm9, [rsp+0x80]
000070bab59dd1e9  vmovaps xmm10, [rsp+0x90]
000070bab59dd1f2  vmovaps xmm11, [rsp+0xA0]
000070bab59dd1fb  vmovaps xmm12, [rsp+0xB0]
000070bab59dd204  vmovaps xmm13, [rsp+0xC0]
000070bab59dd20d  vmovaps xmm14, [rsp+0xD0]
000070bab59dd216  vmovaps xmm15, [rsp+0xE0]
000070bab59dd21f  add rsp, 0xF0
000070bab59dd226  pop r11
000070bab59dd228  pop r10
000070bab59dd22a  pop r9
000070bab59dd22c  pop r8
000070bab59dd22e  pop rsi
000070bab59dd22f  pop rdi
000070bab59dd230  pop rdx
000070bab59dd231  pop rcx
000070bab59dd232  pop rax
000070bab59dd233  add rsp, 0x08
000070bab59dd237  jmp 0x000070BAB59DBC73
000070bab59dd23c  sub rsp, 0x08
000070bab59dd240  push rax
000070bab59dd241  push rcx
000070bab59dd242  push rdx
000070bab59dd243  push rdi
000070bab59dd244  push rsi
000070bab59dd245  push r8
000070bab59dd247  push r9
000070bab59dd249  push r10
000070bab59dd24b  push r11
000070bab59dd24d  sub rsp, 0xF0
000070bab59dd254  vmovaps [rsp], xmm0
000070bab59dd259  vmovaps [rsp+0x10], xmm1
000070bab59dd25f  vmovaps [rsp+0x20], xmm2
000070bab59dd265  vmovaps [rsp+0x30], xmm3
000070bab59dd26b  vmovaps [rsp+0x40], xmm5
000070bab59dd271  vmovaps [rsp+0x50], xmm6
000070bab59dd277  vmovaps [rsp+0x60], xmm7
000070bab59dd27d  vmovaps [rsp+0x70], xmm8
000070bab59dd283  vmovaps [rsp+0x80], xmm9
000070bab59dd28c  vmovaps [rsp+0x90], xmm10
000070bab59dd295  vmovaps [rsp+0xA0], xmm11
000070bab59dd29e  vmovaps [rsp+0xB0], xmm12
000070bab59dd2a7  vmovaps [rsp+0xC0], xmm13
000070bab59dd2b0  vmovaps [rsp+0xD0], xmm14
000070bab59dd2b9  vmovaps [rsp+0xE0], xmm15
000070bab59dd2c2  sub rsp, 0x30
000070bab59dd2c6  movaps [rsp], xmm4
000070bab59dd2ca  movaps [rsp+0x10], xmm9
000070bab59dd2d0  movaps [rsp+0x20], xmm8
000070bab59dd2d6  lea rdi, [rsp]
000070bab59dd2da  mov esi, 0x00
000070bab59dd2df  mov rax, 0x63B35AFBC530
000070bab59dd2e9  call rax
000070bab59dd2eb  movaps xmm4, [rsp]
000070bab59dd2ef  add rsp, 0x30
000070bab59dd2f3  vmovaps xmm0, [rsp]
000070bab59dd2f8  vmovaps xmm1, [rsp+0x10]
000070bab59dd2fe  vmovaps xmm2, [rsp+0x20]
000070bab59dd304  vmovaps xmm3, [rsp+0x30]
000070bab59dd30a  vmovaps xmm5, [rsp+0x40]
000070bab59dd310  vmovaps xmm6, [rsp+0x50]
000070bab59dd316  vmovaps xmm7, [rsp+0x60]
000070bab59dd31c  vmovaps xmm8, [rsp+0x70]
000070bab59dd322  vmovaps xmm9, [rsp+0x80]
000070bab59dd32b  vmovaps xmm10, [rsp+0x90]
000070bab59dd334  vmovaps xmm11, [rsp+0xA0]
000070bab59dd33d  vmovaps xmm12, [rsp+0xB0]
000070bab59dd346  vmovaps xmm13, [rsp+0xC0]
000070bab59dd34f  vmovaps xmm14, [rsp+0xD0]
000070bab59dd358  vmovaps xmm15, [rsp+0xE0]
000070bab59dd361  add rsp, 0xF0
000070bab59dd368  pop r11
000070bab59dd36a  pop r10
000070bab59dd36c  pop r9
000070bab59dd36e  pop r8
000070bab59dd370  pop rsi
000070bab59dd371  pop rdi
000070bab59dd372  pop rdx
000070bab59dd373  pop rcx
000070bab59dd374  pop rax
000070bab59dd375  add rsp, 0x08
000070bab59dd379  jmp 0x000070BAB59DBC94
000070bab59dd37e  sub rsp, 0x08
000070bab59dd382  push rax
000070bab59dd383  push rcx
000070bab59dd384  push rdx
000070bab59dd385  push rdi
000070bab59dd386  push rsi
000070bab59dd387  push r8
000070bab59dd389  push r9
000070bab59dd38b  push r10
000070bab59dd38d  push r11
000070bab59dd38f  sub rsp, 0xF0
000070bab59dd396  vmovaps [rsp], xmm0
000070bab59dd39b  vmovaps [rsp+0x10], xmm1
000070bab59dd3a1  vmovaps [rsp+0x20], xmm2
000070bab59dd3a7  vmovaps [rsp+0x30], xmm3
000070bab59dd3ad  vmovaps [rsp+0x40], xmm4
000070bab59dd3b3  vmovaps [rsp+0x50], xmm5
000070bab59dd3b9  vmovaps [rsp+0x60], xmm6
000070bab59dd3bf  vmovaps [rsp+0x70], xmm7
000070bab59dd3c5  vmovaps [rsp+0x80], xmm8
000070bab59dd3ce  vmovaps [rsp+0x90], xmm10
000070bab59dd3d7  vmovaps [rsp+0xA0], xmm11
000070bab59dd3e0  vmovaps [rsp+0xB0], xmm12
000070bab59dd3e9  vmovaps [rsp+0xC0], xmm13
000070bab59dd3f2  vmovaps [rsp+0xD0], xmm14
000070bab59dd3fb  vmovaps [rsp+0xE0], xmm15
000070bab59dd404  sub rsp, 0x30
000070bab59dd408  movaps [rsp], xmm9
000070bab59dd40d  movaps [rsp+0x10], xmm10
000070bab59dd413  movaps [rsp+0x20], xmm8
000070bab59dd419  lea rdi, [rsp]
000070bab59dd41d  mov esi, 0x00
000070bab59dd422  mov rax, 0x63B35AFBC530
000070bab59dd42c  call rax
000070bab59dd42e  movaps xmm9, [rsp]
000070bab59dd433  add rsp, 0x30
000070bab59dd437  vmovaps xmm0, [rsp]
000070bab59dd43c  vmovaps xmm1, [rsp+0x10]
000070bab59dd442  vmovaps xmm2, [rsp+0x20]
000070bab59dd448  vmovaps xmm3, [rsp+0x30]
000070bab59dd44e  vmovaps xmm4, [rsp+0x40]
000070bab59dd454  vmovaps xmm5, [rsp+0x50]
000070bab59dd45a  vmovaps xmm6, [rsp+0x60]
000070bab59dd460  vmovaps xmm7, [rsp+0x70]
000070bab59dd466  vmovaps xmm8, [rsp+0x80]
000070bab59dd46f  vmovaps xmm10, [rsp+0x90]
000070bab59dd478  vmovaps xmm11, [rsp+0xA0]
000070bab59dd481  vmovaps xmm12, [rsp+0xB0]
000070bab59dd48a  vmovaps xmm13, [rsp+0xC0]
000070bab59dd493  vmovaps xmm14, [rsp+0xD0]
000070bab59dd49c  vmovaps xmm15, [rsp+0xE0]
000070bab59dd4a5  add rsp, 0xF0
000070bab59dd4ac  pop r11
000070bab59dd4ae  pop r10
000070bab59dd4b0  pop r9
000070bab59dd4b2  pop r8
000070bab59dd4b4  pop rsi
000070bab59dd4b5  pop rdi
000070bab59dd4b6  pop rdx
000070bab59dd4b7  pop rcx
000070bab59dd4b8  pop rax
000070bab59dd4b9  add rsp, 0x08
000070bab59dd4bd  jmp 0x000070BAB59DBCAE
000070bab59dd4c2  call 0x000070BAB58B52F0
000070bab59dd4c7  jmp 0x000070BAB59DBDC8
000070bab59dd4cc  call 0x000070BAB58B52F0
000070bab59dd4d1  jmp 0x000070BAB59DBDDE
000070bab59dd4d6  sub rsp, 0x08
000070bab59dd4da  push rax
000070bab59dd4db  push rcx
000070bab59dd4dc  push rdx
000070bab59dd4dd  push rdi
000070bab59dd4de  push rsi
000070bab59dd4df  push r8
000070bab59dd4e1  push r9
000070bab59dd4e3  push r10
000070bab59dd4e5  push r11
000070bab59dd4e7  sub rsp, 0xF0
000070bab59dd4ee  vmovaps [rsp], xmm0
000070bab59dd4f3  vmovaps [rsp+0x10], xmm2
000070bab59dd4f9  vmovaps [rsp+0x20], xmm3
000070bab59dd4ff  vmovaps [rsp+0x30], xmm4
000070bab59dd505  vmovaps [rsp+0x40], xmm5
000070bab59dd50b  vmovaps [rsp+0x50], xmm6
000070bab59dd511  vmovaps [rsp+0x60], xmm7
000070bab59dd517  vmovaps [rsp+0x70], xmm8
000070bab59dd51d  vmovaps [rsp+0x80], xmm9
000070bab59dd526  vmovaps [rsp+0x90], xmm10
000070bab59dd52f  vmovaps [rsp+0xA0], xmm11
000070bab59dd538  vmovaps [rsp+0xB0], xmm12
000070bab59dd541  vmovaps [rsp+0xC0], xmm13
000070bab59dd54a  vmovaps [rsp+0xD0], xmm14
000070bab59dd553  vmovaps [rsp+0xE0], xmm15
000070bab59dd55c  sub rsp, 0x30
000070bab59dd560  movaps [rsp], xmm1
000070bab59dd564  movaps [rsp+0x10], xmm6
000070bab59dd569  movaps [rsp+0x20], xmm15
000070bab59dd56f  lea rdi, [rsp]
000070bab59dd573  mov esi, 0x00
000070bab59dd578  mov rax, 0x63B35AFBC530
000070bab59dd582  call rax
000070bab59dd584  movaps xmm1, [rsp]
000070bab59dd588  add rsp, 0x30
000070bab59dd58c  vmovaps xmm0, [rsp]
000070bab59dd591  vmovaps xmm2, [rsp+0x10]
000070bab59dd597  vmovaps xmm3, [rsp+0x20]
000070bab59dd59d  vmovaps xmm4, [rsp+0x30]
000070bab59dd5a3  vmovaps xmm5, [rsp+0x40]
000070bab59dd5a9  vmovaps xmm6, [rsp+0x50]
000070bab59dd5af  vmovaps xmm7, [rsp+0x60]
000070bab59dd5b5  vmovaps xmm8, [rsp+0x70]
000070bab59dd5bb  vmovaps xmm9, [rsp+0x80]
000070bab59dd5c4  vmovaps xmm10, [rsp+0x90]
000070bab59dd5cd  vmovaps xmm11, [rsp+0xA0]
000070bab59dd5d6  vmovaps xmm12, [rsp+0xB0]
000070bab59dd5df  vmovaps xmm13, [rsp+0xC0]
000070bab59dd5e8  vmovaps xmm14, [rsp+0xD0]
000070bab59dd5f1  vmovaps xmm15, [rsp+0xE0]
000070bab59dd5fa  add rsp, 0xF0
000070bab59dd601  pop r11
000070bab59dd603  pop r10
000070bab59dd605  pop r9
000070bab59dd607  pop r8
000070bab59dd609  pop rsi
000070bab59dd60a  pop rdi
000070bab59dd60b  pop rdx
000070bab59dd60c  pop rcx
000070bab59dd60d  pop rax
000070bab59dd60e  add rsp, 0x08
000070bab59dd612  jmp 0x000070BAB59DBE1B
000070bab59dd617  call 0x000070BAB58C4620
000070bab59dd61c  jmp 0x000070BAB59DBE28
000070bab59dd621  sub rsp, 0x08
000070bab59dd625  push rax
000070bab59dd626  push rcx
000070bab59dd627  push rdx
000070bab59dd628  push rdi
000070bab59dd629  push rsi
000070bab59dd62a  push r8
000070bab59dd62c  push r9
000070bab59dd62e  push r10
000070bab59dd630  push r11
000070bab59dd632  sub rsp, 0xF0
000070bab59dd639  vmovaps [rsp], xmm0
000070bab59dd63e  vmovaps [rsp+0x10], xmm1
000070bab59dd644  vmovaps [rsp+0x20], xmm2
000070bab59dd64a  vmovaps [rsp+0x30], xmm3
000070bab59dd650  vmovaps [rsp+0x40], xmm4
000070bab59dd656  vmovaps [rsp+0x50], xmm5
000070bab59dd65c  vmovaps [rsp+0x60], xmm6
000070bab59dd662  vmovaps [rsp+0x70], xmm7
000070bab59dd668  vmovaps [rsp+0x80], xmm8
000070bab59dd671  vmovaps [rsp+0x90], xmm9
000070bab59dd67a  vmovaps [rsp+0xA0], xmm10
000070bab59dd683  vmovaps [rsp+0xB0], xmm11
000070bab59dd68c  vmovaps [rsp+0xC0], xmm12
000070bab59dd695  vmovaps [rsp+0xD0], xmm13
000070bab59dd69e  vmovaps [rsp+0xE0], xmm15
000070bab59dd6a7  sub rsp, 0x30
000070bab59dd6ab  movaps [rsp], xmm14
000070bab59dd6b0  movaps [rsp+0x10], xmm4
000070bab59dd6b5  movaps [rsp+0x20], xmm3
000070bab59dd6ba  lea rdi, [rsp]
000070bab59dd6be  mov esi, 0x00
000070bab59dd6c3  mov rax, 0x63B35AFBC530
000070bab59dd6cd  call rax
000070bab59dd6cf  movaps xmm14, [rsp]
000070bab59dd6d4  add rsp, 0x30
000070bab59dd6d8  vmovaps xmm0, [rsp]
000070bab59dd6dd  vmovaps xmm1, [rsp+0x10]
000070bab59dd6e3  vmovaps xmm2, [rsp+0x20]
000070bab59dd6e9  vmovaps xmm3, [rsp+0x30]
000070bab59dd6ef  vmovaps xmm4, [rsp+0x40]
000070bab59dd6f5  vmovaps xmm5, [rsp+0x50]
000070bab59dd6fb  vmovaps xmm6, [rsp+0x60]
000070bab59dd701  vmovaps xmm7, [rsp+0x70]
000070bab59dd707  vmovaps xmm8, [rsp+0x80]
000070bab59dd710  vmovaps xmm9, [rsp+0x90]
000070bab59dd719  vmovaps xmm10, [rsp+0xA0]
000070bab59dd722  vmovaps xmm11, [rsp+0xB0]
000070bab59dd72b  vmovaps xmm12, [rsp+0xC0]
000070bab59dd734  vmovaps xmm13, [rsp+0xD0]
000070bab59dd73d  vmovaps xmm15, [rsp+0xE0]
000070bab59dd746  add rsp, 0xF0
000070bab59dd74d  pop r11
000070bab59dd74f  pop r10
000070bab59dd751  pop r9
000070bab59dd753  pop r8
000070bab59dd755  pop rsi
000070bab59dd756  pop rdi
000070bab59dd757  pop rdx
000070bab59dd758  pop rcx
000070bab59dd759  pop rax
000070bab59dd75a  add rsp, 0x08
000070bab59dd75e  jmp 0x000070BAB59DBE42
000070bab59dd763  sub rsp, 0x08
000070bab59dd767  push rax
000070bab59dd768  push rcx
000070bab59dd769  push rdx
000070bab59dd76a  push rdi
000070bab59dd76b  push rsi
000070bab59dd76c  push r8
000070bab59dd76e  push r9
000070bab59dd770  push r10
000070bab59dd772  push r11
000070bab59dd774  sub rsp, 0xF0
000070bab59dd77b  vmovaps [rsp], xmm0
000070bab59dd780  vmovaps [rsp+0x10], xmm1
000070bab59dd786  vmovaps [rsp+0x20], xmm2
000070bab59dd78c  vmovaps [rsp+0x30], xmm3
000070bab59dd792  vmovaps [rsp+0x40], xmm4
000070bab59dd798  vmovaps [rsp+0x50], xmm5
000070bab59dd79e  vmovaps [rsp+0x60], xmm7
000070bab59dd7a4  vmovaps [rsp+0x70], xmm8
000070bab59dd7aa  vmovaps [rsp+0x80], xmm9
000070bab59dd7b3  vmovaps [rsp+0x90], xmm10
000070bab59dd7bc  vmovaps [rsp+0xA0], xmm11
000070bab59dd7c5  vmovaps [rsp+0xB0], xmm12
000070bab59dd7ce  vmovaps [rsp+0xC0], xmm13
000070bab59dd7d7  vmovaps [rsp+0xD0], xmm14
000070bab59dd7e0  vmovaps [rsp+0xE0], xmm15
000070bab59dd7e9  sub rsp, 0x30
000070bab59dd7ed  movaps [rsp], xmm6
000070bab59dd7f1  movaps [rsp+0x10], xmm9
000070bab59dd7f7  movaps [rsp+0x20], xmm7
000070bab59dd7fc  lea rdi, [rsp]
000070bab59dd800  mov esi, 0x00
000070bab59dd805  mov rax, 0x63B35AFBC530
000070bab59dd80f  call rax
000070bab59dd811  movaps xmm6, [rsp]
000070bab59dd815  add rsp, 0x30
000070bab59dd819  vmovaps xmm0, [rsp]
000070bab59dd81e  vmovaps xmm1, [rsp+0x10]
000070bab59dd824  vmovaps xmm2, [rsp+0x20]
000070bab59dd82a  vmovaps xmm3, [rsp+0x30]
000070bab59dd830  vmovaps xmm4, [rsp+0x40]
000070bab59dd836  vmovaps xmm5, [rsp+0x50]
000070bab59dd83c  vmovaps xmm7, [rsp+0x60]
000070bab59dd842  vmovaps xmm8, [rsp+0x70]
000070bab59dd848  vmovaps xmm9, [rsp+0x80]
000070bab59dd851  vmovaps xmm10, [rsp+0x90]
000070bab59dd85a  vmovaps xmm11, [rsp+0xA0]
000070bab59dd863  vmovaps xmm12, [rsp+0xB0]
000070bab59dd86c  vmovaps xmm13, [rsp+0xC0]
000070bab59dd875  vmovaps xmm14, [rsp+0xD0]
000070bab59dd87e  vmovaps xmm15, [rsp+0xE0]
000070bab59dd887  add rsp, 0xF0
000070bab59dd88e  pop r11
000070bab59dd890  pop r10
000070bab59dd892  pop r9
000070bab59dd894  pop r8
000070bab59dd896  pop rsi
000070bab59dd897  pop rdi
000070bab59dd898  pop rdx
000070bab59dd899  pop rcx
000070bab59dd89a  pop rax
000070bab59dd89b  add rsp, 0x08
000070bab59dd89f  jmp 0x000070BAB59DBE5A
000070bab59dd8a4  sub rsp, 0x08
000070bab59dd8a8  push rax
000070bab59dd8a9  push rcx
000070bab59dd8aa  push rdx
000070bab59dd8ab  push rdi
000070bab59dd8ac  push rsi
000070bab59dd8ad  push r8
000070bab59dd8af  push r9
000070bab59dd8b1  push r10
000070bab59dd8b3  push r11
000070bab59dd8b5  sub rsp, 0xF0
000070bab59dd8bc  vmovaps [rsp], xmm0
000070bab59dd8c1  vmovaps [rsp+0x10], xmm1
000070bab59dd8c7  vmovaps [rsp+0x20], xmm2
000070bab59dd8cd  vmovaps [rsp+0x30], xmm3
000070bab59dd8d3  vmovaps [rsp+0x40], xmm4
000070bab59dd8d9  vmovaps [rsp+0x50], xmm5
000070bab59dd8df  vmovaps [rsp+0x60], xmm6
000070bab59dd8e5  vmovaps [rsp+0x70], xmm8
000070bab59dd8eb  vmovaps [rsp+0x80], xmm9
000070bab59dd8f4  vmovaps [rsp+0x90], xmm10
000070bab59dd8fd  vmovaps [rsp+0xA0], xmm11
000070bab59dd906  vmovaps [rsp+0xB0], xmm12
000070bab59dd90f  vmovaps [rsp+0xC0], xmm13
000070bab59dd918  vmovaps [rsp+0xD0], xmm14
000070bab59dd921  vmovaps [rsp+0xE0], xmm15
000070bab59dd92a  sub rsp, 0x30
000070bab59dd92e  movaps [rsp], xmm7
000070bab59dd932  movaps [rsp+0x10], xmm4
000070bab59dd937  movaps [rsp+0x20], xmm9
000070bab59dd93d  lea rdi, [rsp]
000070bab59dd941  mov esi, 0x00
000070bab59dd946  mov rax, 0x63B35AFBC530
000070bab59dd950  call rax
000070bab59dd952  movaps xmm7, [rsp]
000070bab59dd956  add rsp, 0x30
000070bab59dd95a  vmovaps xmm0, [rsp]
000070bab59dd95f  vmovaps xmm1, [rsp+0x10]
000070bab59dd965  vmovaps xmm2, [rsp+0x20]
000070bab59dd96b  vmovaps xmm3, [rsp+0x30]
000070bab59dd971  vmovaps xmm4, [rsp+0x40]
000070bab59dd977  vmovaps xmm5, [rsp+0x50]
000070bab59dd97d  vmovaps xmm6, [rsp+0x60]
000070bab59dd983  vmovaps xmm8, [rsp+0x70]
000070bab59dd989  vmovaps xmm9, [rsp+0x80]
000070bab59dd992  vmovaps xmm10, [rsp+0x90]
000070bab59dd99b  vmovaps xmm11, [rsp+0xA0]
000070bab59dd9a4  vmovaps xmm12, [rsp+0xB0]
000070bab59dd9ad  vmovaps xmm13, [rsp+0xC0]
000070bab59dd9b6  vmovaps xmm14, [rsp+0xD0]
000070bab59dd9bf  vmovaps xmm15, [rsp+0xE0]
000070bab59dd9c8  add rsp, 0xF0
000070bab59dd9cf  pop r11
000070bab59dd9d1  pop r10
000070bab59dd9d3  pop r9
000070bab59dd9d5  pop r8
000070bab59dd9d7  pop rsi
000070bab59dd9d8  pop rdi
000070bab59dd9d9  pop rdx
000070bab59dd9da  pop rcx
000070bab59dd9db  pop rax
000070bab59dd9dc  add rsp, 0x08
000070bab59dd9e0  jmp 0x000070BAB59DBE87
000070bab59dd9e5  sub rsp, 0x08
000070bab59dd9e9  push rax
000070bab59dd9ea  push rcx
000070bab59dd9eb  push rdx
000070bab59dd9ec  push rdi
000070bab59dd9ed  push rsi
000070bab59dd9ee  push r8
000070bab59dd9f0  push r9
000070bab59dd9f2  push r10
000070bab59dd9f4  push r11
000070bab59dd9f6  sub rsp, 0xF0
000070bab59dd9fd  vmovaps [rsp], xmm0
000070bab59dda02  vmovaps [rsp+0x10], xmm1
000070bab59dda08  vmovaps [rsp+0x20], xmm2
000070bab59dda0e  vmovaps [rsp+0x30], xmm3
000070bab59dda14  vmovaps [rsp+0x40], xmm5
000070bab59dda1a  vmovaps [rsp+0x50], xmm6
000070bab59dda20  vmovaps [rsp+0x60], xmm7
000070bab59dda26  vmovaps [rsp+0x70], xmm8
000070bab59dda2c  vmovaps [rsp+0x80], xmm9
000070bab59dda35  vmovaps [rsp+0x90], xmm10
000070bab59dda3e  vmovaps [rsp+0xA0], xmm11
000070bab59dda47  vmovaps [rsp+0xB0], xmm12
000070bab59dda50  vmovaps [rsp+0xC0], xmm13
000070bab59dda59  vmovaps [rsp+0xD0], xmm14
000070bab59dda62  vmovaps [rsp+0xE0], xmm15
000070bab59dda6b  sub rsp, 0x30
000070bab59dda6f  movaps [rsp], xmm4
000070bab59dda73  movaps [rsp+0x10], xmm15
000070bab59dda79  movaps [rsp+0x20], xmm9
000070bab59dda7f  lea rdi, [rsp]
000070bab59dda83  mov esi, 0x00
000070bab59dda88  mov rax, 0x63B35AFBC530
000070bab59dda92  call rax
000070bab59dda94  movaps xmm4, [rsp]
000070bab59dda98  add rsp, 0x30
000070bab59dda9c  vmovaps xmm0, [rsp]
000070bab59ddaa1  vmovaps xmm1, [rsp+0x10]
000070bab59ddaa7  vmovaps xmm2, [rsp+0x20]
000070bab59ddaad  vmovaps xmm3, [rsp+0x30]
000070bab59ddab3  vmovaps xmm5, [rsp+0x40]
000070bab59ddab9  vmovaps xmm6, [rsp+0x50]
000070bab59ddabf  vmovaps xmm7, [rsp+0x60]
000070bab59ddac5  vmovaps xmm8, [rsp+0x70]
000070bab59ddacb  vmovaps xmm9, [rsp+0x80]
000070bab59ddad4  vmovaps xmm10, [rsp+0x90]
000070bab59ddadd  vmovaps xmm11, [rsp+0xA0]
000070bab59ddae6  vmovaps xmm12, [rsp+0xB0]
000070bab59ddaef  vmovaps xmm13, [rsp+0xC0]
000070bab59ddaf8  vmovaps xmm14, [rsp+0xD0]
000070bab59ddb01  vmovaps xmm15, [rsp+0xE0]
000070bab59ddb0a  add rsp, 0xF0
000070bab59ddb11  pop r11
000070bab59ddb13  pop r10
000070bab59ddb15  pop r9
000070bab59ddb17  pop r8
000070bab59ddb19  pop rsi
000070bab59ddb1a  pop rdi
000070bab59ddb1b  pop rdx
000070bab59ddb1c  pop rcx
000070bab59ddb1d  pop rax
000070bab59ddb1e  add rsp, 0x08
000070bab59ddb22  jmp 0x000070BAB59DBEAC
000070bab59ddb27  call 0x000070BAB58C4620
000070bab59ddb2c  jmp 0x000070BAB59DBEB9
000070bab59ddb31  sub rsp, 0x08
000070bab59ddb35  push rax
000070bab59ddb36  push rcx
000070bab59ddb37  push rdx
000070bab59ddb38  push rdi
000070bab59ddb39  push rsi
000070bab59ddb3a  push r8
000070bab59ddb3c  push r9
000070bab59ddb3e  push r10
000070bab59ddb40  push r11
000070bab59ddb42  sub rsp, 0xF0
000070bab59ddb49  vmovaps [rsp], xmm0
000070bab59ddb4e  vmovaps [rsp+0x10], xmm1
000070bab59ddb54  vmovaps [rsp+0x20], xmm2
000070bab59ddb5a  vmovaps [rsp+0x30], xmm4
000070bab59ddb60  vmovaps [rsp+0x40], xmm5
000070bab59ddb66  vmovaps [rsp+0x50], xmm6
000070bab59ddb6c  vmovaps [rsp+0x60], xmm7
000070bab59ddb72  vmovaps [rsp+0x70], xmm8
000070bab59ddb78  vmovaps [rsp+0x80], xmm9
000070bab59ddb81  vmovaps [rsp+0x90], xmm10
000070bab59ddb8a  vmovaps [rsp+0xA0], xmm11
000070bab59ddb93  vmovaps [rsp+0xB0], xmm12
000070bab59ddb9c  vmovaps [rsp+0xC0], xmm13
000070bab59ddba5  vmovaps [rsp+0xD0], xmm14
000070bab59ddbae  vmovaps [rsp+0xE0], xmm15
000070bab59ddbb7  sub rsp, 0x30
000070bab59ddbbb  movaps [rsp], xmm3
000070bab59ddbbf  movaps [rsp+0x10], xmm1
000070bab59ddbc4  movaps [rsp+0x20], xmm9
000070bab59ddbca  lea rdi, [rsp]
000070bab59ddbce  mov esi, 0x00
000070bab59ddbd3  mov rax, 0x63B35AFBC530
000070bab59ddbdd  call rax
000070bab59ddbdf  movaps xmm3, [rsp]
000070bab59ddbe3  add rsp, 0x30
000070bab59ddbe7  vmovaps xmm0, [rsp]
000070bab59ddbec  vmovaps xmm1, [rsp+0x10]
000070bab59ddbf2  vmovaps xmm2, [rsp+0x20]
000070bab59ddbf8  vmovaps xmm4, [rsp+0x30]
000070bab59ddbfe  vmovaps xmm5, [rsp+0x40]
000070bab59ddc04  vmovaps xmm6, [rsp+0x50]
000070bab59ddc0a  vmovaps xmm7, [rsp+0x60]
000070bab59ddc10  vmovaps xmm8, [rsp+0x70]
000070bab59ddc16  vmovaps xmm9, [rsp+0x80]
000070bab59ddc1f  vmovaps xmm10, [rsp+0x90]
000070bab59ddc28  vmovaps xmm11, [rsp+0xA0]
000070bab59ddc31  vmovaps xmm12, [rsp+0xB0]
000070bab59ddc3a  vmovaps xmm13, [rsp+0xC0]
000070bab59ddc43  vmovaps xmm14, [rsp+0xD0]
000070bab59ddc4c  vmovaps xmm15, [rsp+0xE0]
000070bab59ddc55  add rsp, 0xF0
000070bab59ddc5c  pop r11
000070bab59ddc5e  pop r10
000070bab59ddc60  pop r9
000070bab59ddc62  pop r8
000070bab59ddc64  pop rsi
000070bab59ddc65  pop rdi
000070bab59ddc66  pop rdx
000070bab59ddc67  pop rcx
000070bab59ddc68  pop rax
000070bab59ddc69  add rsp, 0x08
000070bab59ddc6d  jmp 0x000070BAB59DBEF6
000070bab59ddc72  sub rsp, 0x08
000070bab59ddc76  push rax
000070bab59ddc77  push rcx
000070bab59ddc78  push rdx
000070bab59ddc79  push rdi
000070bab59ddc7a  push rsi
000070bab59ddc7b  push r8
000070bab59ddc7d  push r9
000070bab59ddc7f  push r10
000070bab59ddc81  push r11
000070bab59ddc83  sub rsp, 0xF0
000070bab59ddc8a  vmovaps [rsp], xmm0
000070bab59ddc8f  vmovaps [rsp+0x10], xmm2
000070bab59ddc95  vmovaps [rsp+0x20], xmm3
000070bab59ddc9b  vmovaps [rsp+0x30], xmm4
000070bab59ddca1  vmovaps [rsp+0x40], xmm5
000070bab59ddca7  vmovaps [rsp+0x50], xmm6
000070bab59ddcad  vmovaps [rsp+0x60], xmm7
000070bab59ddcb3  vmovaps [rsp+0x70], xmm8
000070bab59ddcb9  vmovaps [rsp+0x80], xmm9
000070bab59ddcc2  vmovaps [rsp+0x90], xmm10
000070bab59ddccb  vmovaps [rsp+0xA0], xmm11
000070bab59ddcd4  vmovaps [rsp+0xB0], xmm12
000070bab59ddcdd  vmovaps [rsp+0xC0], xmm13
000070bab59ddce6  vmovaps [rsp+0xD0], xmm14
000070bab59ddcef  vmovaps [rsp+0xE0], xmm15
000070bab59ddcf8  sub rsp, 0x30
000070bab59ddcfc  movaps [rsp], xmm1
000070bab59ddd00  movaps [rsp+0x10], xmm15
000070bab59ddd06  movaps [rsp+0x20], xmm9
000070bab59ddd0c  lea rdi, [rsp]
000070bab59ddd10  mov esi, 0x00
000070bab59ddd15  mov rax, 0x63B35AFBC530
000070bab59ddd1f  call rax
000070bab59ddd21  movaps xmm1, [rsp]
000070bab59ddd25  add rsp, 0x30
000070bab59ddd29  vmovaps xmm0, [rsp]
000070bab59ddd2e  vmovaps xmm2, [rsp+0x10]
000070bab59ddd34  vmovaps xmm3, [rsp+0x20]
000070bab59ddd3a  vmovaps xmm4, [rsp+0x30]
000070bab59ddd40  vmovaps xmm5, [rsp+0x40]
000070bab59ddd46  vmovaps xmm6, [rsp+0x50]
000070bab59ddd4c  vmovaps xmm7, [rsp+0x60]
000070bab59ddd52  vmovaps xmm8, [rsp+0x70]
000070bab59ddd58  vmovaps xmm9, [rsp+0x80]
000070bab59ddd61  vmovaps xmm10, [rsp+0x90]
000070bab59ddd6a  vmovaps xmm11, [rsp+0xA0]
000070bab59ddd73  vmovaps xmm12, [rsp+0xB0]
000070bab59ddd7c  vmovaps xmm13, [rsp+0xC0]
000070bab59ddd85  vmovaps xmm14, [rsp+0xD0]
000070bab59ddd8e  vmovaps xmm15, [rsp+0xE0]
000070bab59ddd97  add rsp, 0xF0
000070bab59ddd9e  pop r11
000070bab59ddda0  pop r10
000070bab59ddda2  pop r9
000070bab59ddda4  pop r8
000070bab59ddda6  pop rsi
000070bab59ddda7  pop rdi
000070bab59ddda8  pop rdx
000070bab59ddda9  pop rcx
000070bab59dddaa  pop rax
000070bab59dddab  add rsp, 0x08
000070bab59dddaf  jmp 0x000070BAB59DBF7E
000070bab59dddb4  call 0x000070BAB58C4620
000070bab59dddb9  jmp 0x000070BAB59DBF8B
000070bab59dddbe  sub rsp, 0x08
000070bab59dddc2  push rax
000070bab59dddc3  push rcx
000070bab59dddc4  push rdx
000070bab59dddc5  push rdi
000070bab59dddc6  push rsi
000070bab59dddc7  push r8
000070bab59dddc9  push r9
000070bab59dddcb  push r10
000070bab59dddcd  push r11
000070bab59dddcf  sub rsp, 0xF0
000070bab59dddd6  vmovaps [rsp], xmm0
000070bab59ddddb  vmovaps [rsp+0x10], xmm2
000070bab59ddde1  vmovaps [rsp+0x20], xmm3
000070bab59ddde7  vmovaps [rsp+0x30], xmm4
000070bab59ddded  vmovaps [rsp+0x40], xmm5
000070bab59dddf3  vmovaps [rsp+0x50], xmm6
000070bab59dddf9  vmovaps [rsp+0x60], xmm7
000070bab59dddff  vmovaps [rsp+0x70], xmm8
000070bab59dde05  vmovaps [rsp+0x80], xmm9
000070bab59dde0e  vmovaps [rsp+0x90], xmm10
000070bab59dde17  vmovaps [rsp+0xA0], xmm11
000070bab59dde20  vmovaps [rsp+0xB0], xmm12
000070bab59dde29  vmovaps [rsp+0xC0], xmm13
000070bab59dde32  vmovaps [rsp+0xD0], xmm14
000070bab59dde3b  vmovaps [rsp+0xE0], xmm15
000070bab59dde44  sub rsp, 0x30
000070bab59dde48  movaps [rsp], xmm1
000070bab59dde4c  movaps [rsp+0x10], xmm5
000070bab59dde51  movaps [rsp+0x20], xmm7
000070bab59dde56  lea rdi, [rsp]
000070bab59dde5a  mov esi, 0x00
000070bab59dde5f  mov rax, 0x63B35AFBC530
000070bab59dde69  call rax
000070bab59dde6b  movaps xmm1, [rsp]
000070bab59dde6f  add rsp, 0x30
000070bab59dde73  vmovaps xmm0, [rsp]
000070bab59dde78  vmovaps xmm2, [rsp+0x10]
000070bab59dde7e  vmovaps xmm3, [rsp+0x20]
000070bab59dde84  vmovaps xmm4, [rsp+0x30]
000070bab59dde8a  vmovaps xmm5, [rsp+0x40]
000070bab59dde90  vmovaps xmm6, [rsp+0x50]
000070bab59dde96  vmovaps xmm7, [rsp+0x60]
000070bab59dde9c  vmovaps xmm8, [rsp+0x70]
000070bab59ddea2  vmovaps xmm9, [rsp+0x80]
000070bab59ddeab  vmovaps xmm10, [rsp+0x90]
000070bab59ddeb4  vmovaps xmm11, [rsp+0xA0]
000070bab59ddebd  vmovaps xmm12, [rsp+0xB0]
000070bab59ddec6  vmovaps xmm13, [rsp+0xC0]
000070bab59ddecf  vmovaps xmm14, [rsp+0xD0]
000070bab59dded8  vmovaps xmm15, [rsp+0xE0]
000070bab59ddee1  add rsp, 0xF0
000070bab59ddee8  pop r11
000070bab59ddeea  pop r10
000070bab59ddeec  pop r9
000070bab59ddeee  pop r8
000070bab59ddef0  pop rsi
000070bab59ddef1  pop rdi
000070bab59ddef2  pop rdx
000070bab59ddef3  pop rcx
000070bab59ddef4  pop rax
000070bab59ddef5  add rsp, 0x08
000070bab59ddef9  jmp 0x000070BAB59DC030
000070bab59ddefe  sub rsp, 0x08
000070bab59ddf02  push rax
000070bab59ddf03  push rcx
000070bab59ddf04  push rdx
000070bab59ddf05  push rdi
000070bab59ddf06  push rsi
000070bab59ddf07  push r8
000070bab59ddf09  push r9
000070bab59ddf0b  push r10
000070bab59ddf0d  push r11
000070bab59ddf0f  sub rsp, 0xF0
000070bab59ddf16  vmovaps [rsp], xmm0
000070bab59ddf1b  vmovaps [rsp+0x10], xmm1
000070bab59ddf21  vmovaps [rsp+0x20], xmm2
000070bab59ddf27  vmovaps [rsp+0x30], xmm3
000070bab59ddf2d  vmovaps [rsp+0x40], xmm4
000070bab59ddf33  vmovaps [rsp+0x50], xmm5
000070bab59ddf39  vmovaps [rsp+0x60], xmm6
000070bab59ddf3f  vmovaps [rsp+0x70], xmm8
000070bab59ddf45  vmovaps [rsp+0x80], xmm9
000070bab59ddf4e  vmovaps [rsp+0x90], xmm10
000070bab59ddf57  vmovaps [rsp+0xA0], xmm11
000070bab59ddf60  vmovaps [rsp+0xB0], xmm12
000070bab59ddf69  vmovaps [rsp+0xC0], xmm13
000070bab59ddf72  vmovaps [rsp+0xD0], xmm14
000070bab59ddf7b  vmovaps [rsp+0xE0], xmm15
000070bab59ddf84  sub rsp, 0x30
000070bab59ddf88  movaps [rsp], xmm7
000070bab59ddf8c  movaps [rsp+0x10], xmm5
000070bab59ddf91  movaps [rsp+0x20], xmm15
000070bab59ddf97  lea rdi, [rsp]
000070bab59ddf9b  mov esi, 0x00
000070bab59ddfa0  mov rax, 0x63B35AFBC530
000070bab59ddfaa  call rax
000070bab59ddfac  movaps xmm7, [rsp]
000070bab59ddfb0  add rsp, 0x30
000070bab59ddfb4  vmovaps xmm0, [rsp]
000070bab59ddfb9  vmovaps xmm1, [rsp+0x10]
000070bab59ddfbf  vmovaps xmm2, [rsp+0x20]
000070bab59ddfc5  vmovaps xmm3, [rsp+0x30]
000070bab59ddfcb  vmovaps xmm4, [rsp+0x40]
000070bab59ddfd1  vmovaps xmm5, [rsp+0x50]
000070bab59ddfd7  vmovaps xmm6, [rsp+0x60]
000070bab59ddfdd  vmovaps xmm8, [rsp+0x70]
000070bab59ddfe3  vmovaps xmm9, [rsp+0x80]
000070bab59ddfec  vmovaps xmm10, [rsp+0x90]
000070bab59ddff5  vmovaps xmm11, [rsp+0xA0]
000070bab59ddffe  vmovaps xmm12, [rsp+0xB0]
000070bab59de007  vmovaps xmm13, [rsp+0xC0]
000070bab59de010  vmovaps xmm14, [rsp+0xD0]
000070bab59de019  vmovaps xmm15, [rsp+0xE0]
000070bab59de022  add rsp, 0xF0
000070bab59de029  pop r11
000070bab59de02b  pop r10
000070bab59de02d  pop r9
000070bab59de02f  pop r8
000070bab59de031  pop rsi
000070bab59de032  pop rdi
000070bab59de033  pop rdx
000070bab59de034  pop rcx
000070bab59de035  pop rax
000070bab59de036  add rsp, 0x08
000070bab59de03a  jmp 0x000070BAB59DC066
000070bab59de03f  call 0x000070BAB58B52F0
000070bab59de044  jmp 0x000070BAB59DC073
000070bab59de049  sub rsp, 0x08
000070bab59de04d  push rax
000070bab59de04e  push rcx
000070bab59de04f  push rdx
000070bab59de050  push rdi
000070bab59de051  push rsi
000070bab59de052  push r8
000070bab59de054  push r9
000070bab59de056  push r10
000070bab59de058  push r11
000070bab59de05a  sub rsp, 0xF0
000070bab59de061  vmovaps [rsp], xmm0
000070bab59de066  vmovaps [rsp+0x10], xmm1
000070bab59de06c  vmovaps [rsp+0x20], xmm2
000070bab59de072  vmovaps [rsp+0x30], xmm3
000070bab59de078  vmovaps [rsp+0x40], xmm4
000070bab59de07e  vmovaps [rsp+0x50], xmm5
000070bab59de084  vmovaps [rsp+0x60], xmm6
000070bab59de08a  vmovaps [rsp+0x70], xmm7
000070bab59de090  vmovaps [rsp+0x80], xmm8
000070bab59de099  vmovaps [rsp+0x90], xmm9
000070bab59de0a2  vmovaps [rsp+0xA0], xmm10
000070bab59de0ab  vmovaps [rsp+0xB0], xmm11
000070bab59de0b4  vmovaps [rsp+0xC0], xmm12
000070bab59de0bd  vmovaps [rsp+0xD0], xmm13
000070bab59de0c6  vmovaps [rsp+0xE0], xmm14
000070bab59de0cf  sub rsp, 0x30
000070bab59de0d3  movaps [rsp], xmm15
000070bab59de0d8  movaps [rsp+0x10], xmm5
000070bab59de0dd  movaps [rsp+0x20], xmm3
000070bab59de0e2  lea rdi, [rsp]
000070bab59de0e6  mov esi, 0x00
000070bab59de0eb  mov rax, 0x63B35AFBC530
000070bab59de0f5  call rax
000070bab59de0f7  movaps xmm15, [rsp]
000070bab59de0fc  add rsp, 0x30
000070bab59de100  vmovaps xmm0, [rsp]
000070bab59de105  vmovaps xmm1, [rsp+0x10]
000070bab59de10b  vmovaps xmm2, [rsp+0x20]
000070bab59de111  vmovaps xmm3, [rsp+0x30]
000070bab59de117  vmovaps xmm4, [rsp+0x40]
000070bab59de11d  vmovaps xmm5, [rsp+0x50]
000070bab59de123  vmovaps xmm6, [rsp+0x60]
000070bab59de129  vmovaps xmm7, [rsp+0x70]
000070bab59de12f  vmovaps xmm8, [rsp+0x80]
000070bab59de138  vmovaps xmm9, [rsp+0x90]
000070bab59de141  vmovaps xmm10, [rsp+0xA0]
000070bab59de14a  vmovaps xmm11, [rsp+0xB0]
000070bab59de153  vmovaps xmm12, [rsp+0xC0]
000070bab59de15c  vmovaps xmm13, [rsp+0xD0]
000070bab59de165  vmovaps xmm14, [rsp+0xE0]
000070bab59de16e  add rsp, 0xF0
000070bab59de175  pop r11
000070bab59de177  pop r10
000070bab59de179  pop r9
000070bab59de17b  pop r8
000070bab59de17d  pop rsi
000070bab59de17e  pop rdi
000070bab59de17f  pop rdx
000070bab59de180  pop rcx
000070bab59de181  pop rax
000070bab59de182  add rsp, 0x08
000070bab59de186  jmp 0x000070BAB59DC099
000070bab59de18b  sub rsp, 0x08
000070bab59de18f  push rax
000070bab59de190  push rcx
000070bab59de191  push rdx
000070bab59de192  push rdi
000070bab59de193  push rsi
000070bab59de194  push r8
000070bab59de196  push r9
000070bab59de198  push r10
000070bab59de19a  push r11
000070bab59de19c  sub rsp, 0xF0
000070bab59de1a3  vmovaps [rsp], xmm0
000070bab59de1a8  vmovaps [rsp+0x10], xmm2
000070bab59de1ae  vmovaps [rsp+0x20], xmm3
000070bab59de1b4  vmovaps [rsp+0x30], xmm4
000070bab59de1ba  vmovaps [rsp+0x40], xmm5
000070bab59de1c0  vmovaps [rsp+0x50], xmm6
000070bab59de1c6  vmovaps [rsp+0x60], xmm7
000070bab59de1cc  vmovaps [rsp+0x70], xmm8
000070bab59de1d2  vmovaps [rsp+0x80], xmm9
000070bab59de1db  vmovaps [rsp+0x90], xmm10
000070bab59de1e4  vmovaps [rsp+0xA0], xmm11
000070bab59de1ed  vmovaps [rsp+0xB0], xmm12
000070bab59de1f6  vmovaps [rsp+0xC0], xmm13
000070bab59de1ff  vmovaps [rsp+0xD0], xmm14
000070bab59de208  vmovaps [rsp+0xE0], xmm15
000070bab59de211  sub rsp, 0x30
000070bab59de215  movaps [rsp], xmm1
000070bab59de219  movaps [rsp+0x10], xmm5
000070bab59de21e  movaps [rsp+0x20], xmm4
000070bab59de223  lea rdi, [rsp]
000070bab59de227  mov esi, 0x00
000070bab59de22c  mov rax, 0x63B35AFBC530
000070bab59de236  call rax
000070bab59de238  movaps xmm1, [rsp]
000070bab59de23c  add rsp, 0x30
000070bab59de240  vmovaps xmm0, [rsp]
000070bab59de245  vmovaps xmm2, [rsp+0x10]
000070bab59de24b  vmovaps xmm3, [rsp+0x20]
000070bab59de251  vmovaps xmm4, [rsp+0x30]
000070bab59de257  vmovaps xmm5, [rsp+0x40]
000070bab59de25d  vmovaps xmm6, [rsp+0x50]
000070bab59de263  vmovaps xmm7, [rsp+0x60]
000070bab59de269  vmovaps xmm8, [rsp+0x70]
000070bab59de26f  vmovaps xmm9, [rsp+0x80]
000070bab59de278  vmovaps xmm10, [rsp+0x90]
000070bab59de281  vmovaps xmm11, [rsp+0xA0]
000070bab59de28a  vmovaps xmm12, [rsp+0xB0]
000070bab59de293  vmovaps xmm13, [rsp+0xC0]
000070bab59de29c  vmovaps xmm14, [rsp+0xD0]
000070bab59de2a5  vmovaps xmm15, [rsp+0xE0]
000070bab59de2ae  add rsp, 0xF0
000070bab59de2b5  pop r11
000070bab59de2b7  pop r10
000070bab59de2b9  pop r9
000070bab59de2bb  pop r8
000070bab59de2bd  pop rsi
000070bab59de2be  pop rdi
000070bab59de2bf  pop rdx
000070bab59de2c0  pop rcx
000070bab59de2c1  pop rax
000070bab59de2c2  add rsp, 0x08
000070bab59de2c6  jmp 0x000070BAB59DC0B9
000070bab59de2cb  sub rsp, 0x08
000070bab59de2cf  push rax
000070bab59de2d0  push rcx
000070bab59de2d1  push rdx
000070bab59de2d2  push rdi
000070bab59de2d3  push rsi
000070bab59de2d4  push r8
000070bab59de2d6  push r9
000070bab59de2d8  push r10
000070bab59de2da  push r11
000070bab59de2dc  sub rsp, 0xF0
000070bab59de2e3  vmovaps [rsp], xmm0
000070bab59de2e8  vmovaps [rsp+0x10], xmm1
000070bab59de2ee  vmovaps [rsp+0x20], xmm2
000070bab59de2f4  vmovaps [rsp+0x30], xmm3
000070bab59de2fa  vmovaps [rsp+0x40], xmm5
000070bab59de300  vmovaps [rsp+0x50], xmm6
000070bab59de306  vmovaps [rsp+0x60], xmm7
000070bab59de30c  vmovaps [rsp+0x70], xmm8
000070bab59de312  vmovaps [rsp+0x80], xmm9
000070bab59de31b  vmovaps [rsp+0x90], xmm10
000070bab59de324  vmovaps [rsp+0xA0], xmm11
000070bab59de32d  vmovaps [rsp+0xB0], xmm12
000070bab59de336  vmovaps [rsp+0xC0], xmm13
000070bab59de33f  vmovaps [rsp+0xD0], xmm14
000070bab59de348  vmovaps [rsp+0xE0], xmm15
000070bab59de351  sub rsp, 0x30
000070bab59de355  movaps [rsp], xmm4
000070bab59de359  movaps [rsp+0x10], xmm3
000070bab59de35e  movaps [rsp+0x20], xmm5
000070bab59de363  lea rdi, [rsp]
000070bab59de367  mov esi, 0x00
000070bab59de36c  mov rax, 0x63B35AFBC530
000070bab59de376  call rax
000070bab59de378  movaps xmm4, [rsp]
000070bab59de37c  add rsp, 0x30
000070bab59de380  vmovaps xmm0, [rsp]
000070bab59de385  vmovaps xmm1, [rsp+0x10]
000070bab59de38b  vmovaps xmm2, [rsp+0x20]
000070bab59de391  vmovaps xmm3, [rsp+0x30]
000070bab59de397  vmovaps xmm5, [rsp+0x40]
000070bab59de39d  vmovaps xmm6, [rsp+0x50]
000070bab59de3a3  vmovaps xmm7, [rsp+0x60]
000070bab59de3a9  vmovaps xmm8, [rsp+0x70]
000070bab59de3af  vmovaps xmm9, [rsp+0x80]
000070bab59de3b8  vmovaps xmm10, [rsp+0x90]
000070bab59de3c1  vmovaps xmm11, [rsp+0xA0]
000070bab59de3ca  vmovaps xmm12, [rsp+0xB0]
000070bab59de3d3  vmovaps xmm13, [rsp+0xC0]
000070bab59de3dc  vmovaps xmm14, [rsp+0xD0]
000070bab59de3e5  vmovaps xmm15, [rsp+0xE0]
000070bab59de3ee  add rsp, 0xF0
000070bab59de3f5  pop r11
000070bab59de3f7  pop r10
000070bab59de3f9  pop r9
000070bab59de3fb  pop r8
000070bab59de3fd  pop rsi
000070bab59de3fe  pop rdi
000070bab59de3ff  pop rdx
000070bab59de400  pop rcx
000070bab59de401  pop rax
000070bab59de402  add rsp, 0x08
000070bab59de406  jmp 0x000070BAB59DC107
000070bab59de40b  call 0x000070BAB58B52F0
000070bab59de410  jmp 0x000070BAB59DC114
000070bab59de415  sub rsp, 0x08
000070bab59de419  push rax
000070bab59de41a  push rcx
000070bab59de41b  push rdx
000070bab59de41c  push rdi
000070bab59de41d  push rsi
000070bab59de41e  push r8
000070bab59de420  push r9
000070bab59de422  push r10
000070bab59de424  push r11
000070bab59de426  sub rsp, 0xF0
000070bab59de42d  vmovaps [rsp], xmm0
000070bab59de432  vmovaps [rsp+0x10], xmm1
000070bab59de438  vmovaps [rsp+0x20], xmm2
000070bab59de43e  vmovaps [rsp+0x30], xmm3
000070bab59de444  vmovaps [rsp+0x40], xmm4
000070bab59de44a  vmovaps [rsp+0x50], xmm6
000070bab59de450  vmovaps [rsp+0x60], xmm7
000070bab59de456  vmovaps [rsp+0x70], xmm8
000070bab59de45c  vmovaps [rsp+0x80], xmm9
000070bab59de465  vmovaps [rsp+0x90], xmm10
000070bab59de46e  vmovaps [rsp+0xA0], xmm11
000070bab59de477  vmovaps [rsp+0xB0], xmm12
000070bab59de480  vmovaps [rsp+0xC0], xmm13
000070bab59de489  vmovaps [rsp+0xD0], xmm14
000070bab59de492  vmovaps [rsp+0xE0], xmm15
000070bab59de49b  sub rsp, 0x30
000070bab59de49f  movaps [rsp], xmm5
000070bab59de4a3  movaps [rsp+0x10], xmm6
000070bab59de4a8  movaps [rsp+0x20], xmm3
000070bab59de4ad  lea rdi, [rsp]
000070bab59de4b1  mov esi, 0x00
000070bab59de4b6  mov rax, 0x63B35AFBC530
000070bab59de4c0  call rax
000070bab59de4c2  movaps xmm5, [rsp]
000070bab59de4c6  add rsp, 0x30
000070bab59de4ca  vmovaps xmm0, [rsp]
000070bab59de4cf  vmovaps xmm1, [rsp+0x10]
000070bab59de4d5  vmovaps xmm2, [rsp+0x20]
000070bab59de4db  vmovaps xmm3, [rsp+0x30]
000070bab59de4e1  vmovaps xmm4, [rsp+0x40]
000070bab59de4e7  vmovaps xmm6, [rsp+0x50]
000070bab59de4ed  vmovaps xmm7, [rsp+0x60]
000070bab59de4f3  vmovaps xmm8, [rsp+0x70]
000070bab59de4f9  vmovaps xmm9, [rsp+0x80]
000070bab59de502  vmovaps xmm10, [rsp+0x90]
000070bab59de50b  vmovaps xmm11, [rsp+0xA0]
000070bab59de514  vmovaps xmm12, [rsp+0xB0]
000070bab59de51d  vmovaps xmm13, [rsp+0xC0]
000070bab59de526  vmovaps xmm14, [rsp+0xD0]
000070bab59de52f  vmovaps xmm15, [rsp+0xE0]
000070bab59de538  add rsp, 0xF0
000070bab59de53f  pop r11
000070bab59de541  pop r10
000070bab59de543  pop r9
000070bab59de545  pop r8
000070bab59de547  pop rsi
000070bab59de548  pop rdi
000070bab59de549  pop rdx
000070bab59de54a  pop rcx
000070bab59de54b  pop rax
000070bab59de54c  add rsp, 0x08
000070bab59de550  jmp 0x000070BAB59DC13A
000070bab59de555  sub rsp, 0x08
000070bab59de559  push rax
000070bab59de55a  push rcx
000070bab59de55b  push rdx
000070bab59de55c  push rdi
000070bab59de55d  push rsi
000070bab59de55e  push r8
000070bab59de560  push r9
000070bab59de562  push r10
000070bab59de564  push r11
000070bab59de566  sub rsp, 0xF0
000070bab59de56d  vmovaps [rsp], xmm0
000070bab59de572  vmovaps [rsp+0x10], xmm1
000070bab59de578  vmovaps [rsp+0x20], xmm2
000070bab59de57e  vmovaps [rsp+0x30], xmm3
000070bab59de584  vmovaps [rsp+0x40], xmm4
000070bab59de58a  vmovaps [rsp+0x50], xmm5
000070bab59de590  vmovaps [rsp+0x60], xmm7
000070bab59de596  vmovaps [rsp+0x70], xmm8
000070bab59de59c  vmovaps [rsp+0x80], xmm9
000070bab59de5a5  vmovaps [rsp+0x90], xmm10
000070bab59de5ae  vmovaps [rsp+0xA0], xmm11
000070bab59de5b7  vmovaps [rsp+0xB0], xmm12
000070bab59de5c0  vmovaps [rsp+0xC0], xmm13
000070bab59de5c9  vmovaps [rsp+0xD0], xmm14
000070bab59de5d2  vmovaps [rsp+0xE0], xmm15
000070bab59de5db  sub rsp, 0x30
000070bab59de5df  movaps [rsp], xmm6
000070bab59de5e3  movaps [rsp+0x10], xmm9
000070bab59de5e9  movaps [rsp+0x20], xmm1
000070bab59de5ee  lea rdi, [rsp]
000070bab59de5f2  mov esi, 0x00
000070bab59de5f7  mov rax, 0x63B35AFBC530
000070bab59de601  call rax
000070bab59de603  movaps xmm6, [rsp]
000070bab59de607  add rsp, 0x30
000070bab59de60b  vmovaps xmm0, [rsp]
000070bab59de610  vmovaps xmm1, [rsp+0x10]
000070bab59de616  vmovaps xmm2, [rsp+0x20]
000070bab59de61c  vmovaps xmm3, [rsp+0x30]
000070bab59de622  vmovaps xmm4, [rsp+0x40]
000070bab59de628  vmovaps xmm5, [rsp+0x50]
000070bab59de62e  vmovaps xmm7, [rsp+0x60]
000070bab59de634  vmovaps xmm8, [rsp+0x70]
000070bab59de63a  vmovaps xmm9, [rsp+0x80]
000070bab59de643  vmovaps xmm10, [rsp+0x90]
000070bab59de64c  vmovaps xmm11, [rsp+0xA0]
000070bab59de655  vmovaps xmm12, [rsp+0xB0]
000070bab59de65e  vmovaps xmm13, [rsp+0xC0]
000070bab59de667  vmovaps xmm14, [rsp+0xD0]
000070bab59de670  vmovaps xmm15, [rsp+0xE0]
000070bab59de679  add rsp, 0xF0
000070bab59de680  pop r11
000070bab59de682  pop r10
000070bab59de684  pop r9
000070bab59de686  pop r8
000070bab59de688  pop rsi
000070bab59de689  pop rdi
000070bab59de68a  pop rdx
000070bab59de68b  pop rcx
000070bab59de68c  pop rax
000070bab59de68d  add rsp, 0x08
000070bab59de691  jmp 0x000070BAB59DC15E
000070bab59de696  sub rsp, 0x08
000070bab59de69a  push rax
000070bab59de69b  push rcx
000070bab59de69c  push rdx
000070bab59de69d  push rdi
000070bab59de69e  push rsi
000070bab59de69f  push r8
000070bab59de6a1  push r9
000070bab59de6a3  push r10
000070bab59de6a5  push r11
000070bab59de6a7  sub rsp, 0xF0
000070bab59de6ae  vmovaps [rsp], xmm0
000070bab59de6b3  vmovaps [rsp+0x10], xmm1
000070bab59de6b9  vmovaps [rsp+0x20], xmm2
000070bab59de6bf  vmovaps [rsp+0x30], xmm3
000070bab59de6c5  vmovaps [rsp+0x40], xmm4
000070bab59de6cb  vmovaps [rsp+0x50], xmm5
000070bab59de6d1  vmovaps [rsp+0x60], xmm6
000070bab59de6d7  vmovaps [rsp+0x70], xmm7
000070bab59de6dd  vmovaps [rsp+0x80], xmm8
000070bab59de6e6  vmovaps [rsp+0x90], xmm10
000070bab59de6ef  vmovaps [rsp+0xA0], xmm11
000070bab59de6f8  vmovaps [rsp+0xB0], xmm12
000070bab59de701  vmovaps [rsp+0xC0], xmm13
000070bab59de70a  vmovaps [rsp+0xD0], xmm14
000070bab59de713  vmovaps [rsp+0xE0], xmm15
000070bab59de71c  sub rsp, 0x30
000070bab59de720  movaps [rsp], xmm9
000070bab59de725  movaps [rsp+0x10], xmm3
000070bab59de72a  movaps [rsp+0x20], xmm1
000070bab59de72f  lea rdi, [rsp]
000070bab59de733  mov esi, 0x00
000070bab59de738  mov rax, 0x63B35AFBC530
000070bab59de742  call rax
000070bab59de744  movaps xmm9, [rsp]
000070bab59de749  add rsp, 0x30
000070bab59de74d  vmovaps xmm0, [rsp]
000070bab59de752  vmovaps xmm1, [rsp+0x10]
000070bab59de758  vmovaps xmm2, [rsp+0x20]
000070bab59de75e  vmovaps xmm3, [rsp+0x30]
000070bab59de764  vmovaps xmm4, [rsp+0x40]
000070bab59de76a  vmovaps xmm5, [rsp+0x50]
000070bab59de770  vmovaps xmm6, [rsp+0x60]
000070bab59de776  vmovaps xmm7, [rsp+0x70]
000070bab59de77c  vmovaps xmm8, [rsp+0x80]
000070bab59de785  vmovaps xmm10, [rsp+0x90]
000070bab59de78e  vmovaps xmm11, [rsp+0xA0]
000070bab59de797  vmovaps xmm12, [rsp+0xB0]
000070bab59de7a0  vmovaps xmm13, [rsp+0xC0]
000070bab59de7a9  vmovaps xmm14, [rsp+0xD0]
000070bab59de7b2  vmovaps xmm15, [rsp+0xE0]
000070bab59de7bb  add rsp, 0xF0
000070bab59de7c2  pop r11
000070bab59de7c4  pop r10
000070bab59de7c6  pop r9
000070bab59de7c8  pop r8
000070bab59de7ca  pop rsi
000070bab59de7cb  pop rdi
000070bab59de7cc  pop rdx
000070bab59de7cd  pop rcx
000070bab59de7ce  pop rax
000070bab59de7cf  add rsp, 0x08
000070bab59de7d3  jmp 0x000070BAB59DC1AA
000070bab59de7d8  call 0x000070BAB58B52F0
000070bab59de7dd  jmp 0x000070BAB59DC1B7
000070bab59de7e2  sub rsp, 0x08
000070bab59de7e6  push rax
000070bab59de7e7  push rcx
000070bab59de7e8  push rdx
000070bab59de7e9  push rdi
000070bab59de7ea  push rsi
000070bab59de7eb  push r8
000070bab59de7ed  push r9
000070bab59de7ef  push r10
000070bab59de7f1  push r11
000070bab59de7f3  sub rsp, 0xF0
000070bab59de7fa  vmovaps [rsp], xmm0
000070bab59de7ff  vmovaps [rsp+0x10], xmm1
000070bab59de805  vmovaps [rsp+0x20], xmm2
000070bab59de80b  vmovaps [rsp+0x30], xmm3
000070bab59de811  vmovaps [rsp+0x40], xmm4
000070bab59de817  vmovaps [rsp+0x50], xmm5
000070bab59de81d  vmovaps [rsp+0x60], xmm6
000070bab59de823  vmovaps [rsp+0x70], xmm7
000070bab59de829  vmovaps [rsp+0x80], xmm8
000070bab59de832  vmovaps [rsp+0x90], xmm9
000070bab59de83b  vmovaps [rsp+0xA0], xmm10
000070bab59de844  vmovaps [rsp+0xB0], xmm11
000070bab59de84d  vmovaps [rsp+0xC0], xmm12
000070bab59de856  vmovaps [rsp+0xD0], xmm13
000070bab59de85f  vmovaps [rsp+0xE0], xmm14
000070bab59de868  sub rsp, 0x30
000070bab59de86c  movaps [rsp], xmm15
000070bab59de871  movaps [rsp+0x10], xmm3
000070bab59de876  movaps [rsp+0x20], xmm7
000070bab59de87b  lea rdi, [rsp]
000070bab59de87f  mov esi, 0x00
000070bab59de884  mov rax, 0x63B35AFBC530
000070bab59de88e  call rax
000070bab59de890  movaps xmm15, [rsp]
000070bab59de895  add rsp, 0x30
000070bab59de899  vmovaps xmm0, [rsp]
000070bab59de89e  vmovaps xmm1, [rsp+0x10]
000070bab59de8a4  vmovaps xmm2, [rsp+0x20]
000070bab59de8aa  vmovaps xmm3, [rsp+0x30]
000070bab59de8b0  vmovaps xmm4, [rsp+0x40]
000070bab59de8b6  vmovaps xmm5, [rsp+0x50]
000070bab59de8bc  vmovaps xmm6, [rsp+0x60]
000070bab59de8c2  vmovaps xmm7, [rsp+0x70]
000070bab59de8c8  vmovaps xmm8, [rsp+0x80]
000070bab59de8d1  vmovaps xmm9, [rsp+0x90]
000070bab59de8da  vmovaps xmm10, [rsp+0xA0]
000070bab59de8e3  vmovaps xmm11, [rsp+0xB0]
000070bab59de8ec  vmovaps xmm12, [rsp+0xC0]
000070bab59de8f5  vmovaps xmm13, [rsp+0xD0]
000070bab59de8fe  vmovaps xmm14, [rsp+0xE0]
000070bab59de907  add rsp, 0xF0
000070bab59de90e  pop r11
000070bab59de910  pop r10
000070bab59de912  pop r9
000070bab59de914  pop r8
000070bab59de916  pop rsi
000070bab59de917  pop rdi
000070bab59de918  pop rdx
000070bab59de919  pop rcx
000070bab59de91a  pop rax
000070bab59de91b  add rsp, 0x08
000070bab59de91f  jmp 0x000070BAB59DC1E3
000070bab59de924  sub rsp, 0x08
000070bab59de928  push rax
000070bab59de929  push rcx
000070bab59de92a  push rdx
000070bab59de92b  push rdi
000070bab59de92c  push rsi
000070bab59de92d  push r8
000070bab59de92f  push r9
000070bab59de931  push r10
000070bab59de933  push r11
000070bab59de935  sub rsp, 0xF0
000070bab59de93c  vmovaps [rsp], xmm0
000070bab59de941  vmovaps [rsp+0x10], xmm1
000070bab59de947  vmovaps [rsp+0x20], xmm2
000070bab59de94d  vmovaps [rsp+0x30], xmm4
000070bab59de953  vmovaps [rsp+0x40], xmm5
000070bab59de959  vmovaps [rsp+0x50], xmm6
000070bab59de95f  vmovaps [rsp+0x60], xmm7
000070bab59de965  vmovaps [rsp+0x70], xmm8
000070bab59de96b  vmovaps [rsp+0x80], xmm9
000070bab59de974  vmovaps [rsp+0x90], xmm10
000070bab59de97d  vmovaps [rsp+0xA0], xmm11
000070bab59de986  vmovaps [rsp+0xB0], xmm12
000070bab59de98f  vmovaps [rsp+0xC0], xmm13
000070bab59de998  vmovaps [rsp+0xD0], xmm14
000070bab59de9a1  vmovaps [rsp+0xE0], xmm15
000070bab59de9aa  sub rsp, 0x30
000070bab59de9ae  movaps [rsp], xmm3
000070bab59de9b2  movaps [rsp+0x10], xmm1
000070bab59de9b7  movaps [rsp+0x20], xmm15
000070bab59de9bd  lea rdi, [rsp]
000070bab59de9c1  mov esi, 0x00
000070bab59de9c6  mov rax, 0x63B35AFBC530
000070bab59de9d0  call rax
000070bab59de9d2  movaps xmm3, [rsp]
000070bab59de9d6  add rsp, 0x30
000070bab59de9da  vmovaps xmm0, [rsp]
000070bab59de9df  vmovaps xmm1, [rsp+0x10]
000070bab59de9e5  vmovaps xmm2, [rsp+0x20]
000070bab59de9eb  vmovaps xmm4, [rsp+0x30]
000070bab59de9f1  vmovaps xmm5, [rsp+0x40]
000070bab59de9f7  vmovaps xmm6, [rsp+0x50]
000070bab59de9fd  vmovaps xmm7, [rsp+0x60]
000070bab59dea03  vmovaps xmm8, [rsp+0x70]
000070bab59dea09  vmovaps xmm9, [rsp+0x80]
000070bab59dea12  vmovaps xmm10, [rsp+0x90]
000070bab59dea1b  vmovaps xmm11, [rsp+0xA0]
000070bab59dea24  vmovaps xmm12, [rsp+0xB0]
000070bab59dea2d  vmovaps xmm13, [rsp+0xC0]
000070bab59dea36  vmovaps xmm14, [rsp+0xD0]
000070bab59dea3f  vmovaps xmm15, [rsp+0xE0]
000070bab59dea48  add rsp, 0xF0
000070bab59dea4f  pop r11
000070bab59dea51  pop r10
000070bab59dea53  pop r9
000070bab59dea55  pop r8
000070bab59dea57  pop rsi
000070bab59dea58  pop rdi
000070bab59dea59  pop rdx
000070bab59dea5a  pop rcx
000070bab59dea5b  pop rax
000070bab59dea5c  add rsp, 0x08
000070bab59dea60  jmp 0x000070BAB59DC272
000070bab59dea65  call 0x000070BAB58B52F0
000070bab59dea6a  jmp 0x000070BAB59DC27C
000070bab59dea6f  sub rsp, 0x08
000070bab59dea73  push rax
000070bab59dea74  push rcx
000070bab59dea75  push rdx
000070bab59dea76  push rdi
000070bab59dea77  push rsi
000070bab59dea78  push r8
000070bab59dea7a  push r9
000070bab59dea7c  push r10
000070bab59dea7e  push r11
000070bab59dea80  sub rsp, 0xF0
000070bab59dea87  vmovaps [rsp], xmm0
000070bab59dea8c  vmovaps [rsp+0x10], xmm1
000070bab59dea92  vmovaps [rsp+0x20], xmm2
000070bab59dea98  vmovaps [rsp+0x30], xmm3
000070bab59dea9e  vmovaps [rsp+0x40], xmm4
000070bab59deaa4  vmovaps [rsp+0x50], xmm5
000070bab59deaaa  vmovaps [rsp+0x60], xmm6
000070bab59deab0  vmovaps [rsp+0x70], xmm7
000070bab59deab6  vmovaps [rsp+0x80], xmm8
000070bab59deabf  vmovaps [rsp+0x90], xmm9
000070bab59deac8  vmovaps [rsp+0xA0], xmm10
000070bab59dead1  vmovaps [rsp+0xB0], xmm11
000070bab59deada  vmovaps [rsp+0xC0], xmm12
000070bab59deae3  vmovaps [rsp+0xD0], xmm13
000070bab59deaec  vmovaps [rsp+0xE0], xmm14
000070bab59deaf5  sub rsp, 0x30
000070bab59deaf9  movaps [rsp], xmm15
000070bab59deafe  movaps [rsp+0x10], xmm14
000070bab59deb04  movaps [rsp+0x20], xmm4
000070bab59deb09  lea rdi, [rsp]
000070bab59deb0d  mov esi, 0x00
000070bab59deb12  mov rax, 0x63B35AFBC530
000070bab59deb1c  call rax
000070bab59deb1e  movaps xmm15, [rsp]
000070bab59deb23  add rsp, 0x30
000070bab59deb27  vmovaps xmm0, [rsp]
000070bab59deb2c  vmovaps xmm1, [rsp+0x10]
000070bab59deb32  vmovaps xmm2, [rsp+0x20]
000070bab59deb38  vmovaps xmm3, [rsp+0x30]
000070bab59deb3e  vmovaps xmm4, [rsp+0x40]
000070bab59deb44  vmovaps xmm5, [rsp+0x50]
000070bab59deb4a  vmovaps xmm6, [rsp+0x60]
000070bab59deb50  vmovaps xmm7, [rsp+0x70]
000070bab59deb56  vmovaps xmm8, [rsp+0x80]
000070bab59deb5f  vmovaps xmm9, [rsp+0x90]
000070bab59deb68  vmovaps xmm10, [rsp+0xA0]
000070bab59deb71  vmovaps xmm11, [rsp+0xB0]
000070bab59deb7a  vmovaps xmm12, [rsp+0xC0]
000070bab59deb83  vmovaps xmm13, [rsp+0xD0]
000070bab59deb8c  vmovaps xmm14, [rsp+0xE0]
000070bab59deb95  add rsp, 0xF0
000070bab59deb9c  pop r11
000070bab59deb9e  pop r10
000070bab59deba0  pop r9
000070bab59deba2  pop r8
000070bab59deba4  pop rsi
000070bab59deba5  pop rdi
000070bab59deba6  pop rdx
000070bab59deba7  pop rcx
000070bab59deba8  pop rax
000070bab59deba9  add rsp, 0x08
000070bab59debad  jmp 0x000070BAB59DC2AA
000070bab59debb2  sub rsp, 0x08
000070bab59debb6  push rax
000070bab59debb7  push rcx
000070bab59debb8  push rdx
000070bab59debb9  push rdi
000070bab59debba  push rsi
000070bab59debbb  push r8
000070bab59debbd  push r9
000070bab59debbf  push r10
000070bab59debc1  push r11
000070bab59debc3  sub rsp, 0xF0
000070bab59debca  vmovaps [rsp], xmm0
000070bab59debcf  vmovaps [rsp+0x10], xmm1
000070bab59debd5  vmovaps [rsp+0x20], xmm2
000070bab59debdb  vmovaps [rsp+0x30], xmm3
000070bab59debe1  vmovaps [rsp+0x40], xmm4
000070bab59debe7  vmovaps [rsp+0x50], xmm5
000070bab59debed  vmovaps [rsp+0x60], xmm6
000070bab59debf3  vmovaps [rsp+0x70], xmm7
000070bab59debf9  vmovaps [rsp+0x80], xmm8
000070bab59dec02  vmovaps [rsp+0x90], xmm9
000070bab59dec0b  vmovaps [rsp+0xA0], xmm10
000070bab59dec14  vmovaps [rsp+0xB0], xmm11
000070bab59dec1d  vmovaps [rsp+0xC0], xmm12
000070bab59dec26  vmovaps [rsp+0xD0], xmm13
000070bab59dec2f  vmovaps [rsp+0xE0], xmm15
000070bab59dec38  sub rsp, 0x30
000070bab59dec3c  movaps [rsp], xmm14
000070bab59dec41  movaps [rsp+0x10], xmm2
000070bab59dec46  movaps [rsp+0x20], xmm1
000070bab59dec4b  lea rdi, [rsp]
000070bab59dec4f  mov esi, 0x00
000070bab59dec54  mov rax, 0x63B35AFBC530
000070bab59dec5e  call rax
000070bab59dec60  movaps xmm14, [rsp]
000070bab59dec65  add rsp, 0x30
000070bab59dec69  vmovaps xmm0, [rsp]
000070bab59dec6e  vmovaps xmm1, [rsp+0x10]
000070bab59dec74  vmovaps xmm2, [rsp+0x20]
000070bab59dec7a  vmovaps xmm3, [rsp+0x30]
000070bab59dec80  vmovaps xmm4, [rsp+0x40]
000070bab59dec86  vmovaps xmm5, [rsp+0x50]
000070bab59dec8c  vmovaps xmm6, [rsp+0x60]
000070bab59dec92  vmovaps xmm7, [rsp+0x70]
000070bab59dec98  vmovaps xmm8, [rsp+0x80]
000070bab59deca1  vmovaps xmm9, [rsp+0x90]
000070bab59decaa  vmovaps xmm10, [rsp+0xA0]
000070bab59decb3  vmovaps xmm11, [rsp+0xB0]
000070bab59decbc  vmovaps xmm12, [rsp+0xC0]
000070bab59decc5  vmovaps xmm13, [rsp+0xD0]
000070bab59decce  vmovaps xmm15, [rsp+0xE0]
000070bab59decd7  add rsp, 0xF0
000070bab59decde  pop r11
000070bab59dece0  pop r10
000070bab59dece2  pop r9
000070bab59dece4  pop r8
000070bab59dece6  pop rsi
000070bab59dece7  pop rdi
000070bab59dece8  pop rdx
000070bab59dece9  pop rcx
000070bab59decea  pop rax
000070bab59deceb  add rsp, 0x08
000070bab59decef  jmp 0x000070BAB59DC2D0
000070bab59decf4  sub rsp, 0x08
000070bab59decf8  push rax
000070bab59decf9  push rcx
000070bab59decfa  push rdx
000070bab59decfb  push rdi
000070bab59decfc  push rsi
000070bab59decfd  push r8
000070bab59decff  push r9
000070bab59ded01  push r10
000070bab59ded03  push r11
000070bab59ded05  sub rsp, 0xF0
000070bab59ded0c  vmovaps [rsp], xmm0
000070bab59ded11  vmovaps [rsp+0x10], xmm2
000070bab59ded17  vmovaps [rsp+0x20], xmm3
000070bab59ded1d  vmovaps [rsp+0x30], xmm4
000070bab59ded23  vmovaps [rsp+0x40], xmm5
000070bab59ded29  vmovaps [rsp+0x50], xmm6
000070bab59ded2f  vmovaps [rsp+0x60], xmm7
000070bab59ded35  vmovaps [rsp+0x70], xmm8
000070bab59ded3b  vmovaps [rsp+0x80], xmm9
000070bab59ded44  vmovaps [rsp+0x90], xmm10
000070bab59ded4d  vmovaps [rsp+0xA0], xmm11
000070bab59ded56  vmovaps [rsp+0xB0], xmm12
000070bab59ded5f  vmovaps [rsp+0xC0], xmm13
000070bab59ded68  vmovaps [rsp+0xD0], xmm14
000070bab59ded71  vmovaps [rsp+0xE0], xmm15
000070bab59ded7a  sub rsp, 0x30
000070bab59ded7e  movaps [rsp], xmm1
000070bab59ded82  movaps [rsp+0x10], xmm4
000070bab59ded87  movaps [rsp+0x20], xmm9
000070bab59ded8d  lea rdi, [rsp]
000070bab59ded91  mov esi, 0x00
000070bab59ded96  mov rax, 0x63B35AFBC530
000070bab59deda0  call rax
000070bab59deda2  movaps xmm1, [rsp]
000070bab59deda6  add rsp, 0x30
000070bab59dedaa  vmovaps xmm0, [rsp]
000070bab59dedaf  vmovaps xmm2, [rsp+0x10]
000070bab59dedb5  vmovaps xmm3, [rsp+0x20]
000070bab59dedbb  vmovaps xmm4, [rsp+0x30]
000070bab59dedc1  vmovaps xmm5, [rsp+0x40]
000070bab59dedc7  vmovaps xmm6, [rsp+0x50]
000070bab59dedcd  vmovaps xmm7, [rsp+0x60]
000070bab59dedd3  vmovaps xmm8, [rsp+0x70]
000070bab59dedd9  vmovaps xmm9, [rsp+0x80]
000070bab59dede2  vmovaps xmm10, [rsp+0x90]
000070bab59dedeb  vmovaps xmm11, [rsp+0xA0]
000070bab59dedf4  vmovaps xmm12, [rsp+0xB0]
000070bab59dedfd  vmovaps xmm13, [rsp+0xC0]
000070bab59dee06  vmovaps xmm14, [rsp+0xD0]
000070bab59dee0f  vmovaps xmm15, [rsp+0xE0]
000070bab59dee18  add rsp, 0xF0
000070bab59dee1f  pop r11
000070bab59dee21  pop r10
000070bab59dee23  pop r9
000070bab59dee25  pop r8
000070bab59dee27  pop rsi
000070bab59dee28  pop rdi
000070bab59dee29  pop rdx
000070bab59dee2a  pop rcx
000070bab59dee2b  pop rax
000070bab59dee2c  add rsp, 0x08
000070bab59dee30  jmp 0x000070BAB59DC2EE
000070bab59dee35  sub rsp, 0x08
000070bab59dee39  push rax
000070bab59dee3a  push rcx
000070bab59dee3b  push rdx
000070bab59dee3c  push rdi
000070bab59dee3d  push rsi
000070bab59dee3e  push r8
000070bab59dee40  push r9
000070bab59dee42  push r10
000070bab59dee44  push r11
000070bab59dee46  sub rsp, 0xF0
000070bab59dee4d  vmovaps [rsp], xmm0
000070bab59dee52  vmovaps [rsp+0x10], xmm1
000070bab59dee58  vmovaps [rsp+0x20], xmm2
000070bab59dee5e  vmovaps [rsp+0x30], xmm3
000070bab59dee64  vmovaps [rsp+0x40], xmm5
000070bab59dee6a  vmovaps [rsp+0x50], xmm6
000070bab59dee70  vmovaps [rsp+0x60], xmm7
000070bab59dee76  vmovaps [rsp+0x70], xmm8
000070bab59dee7c  vmovaps [rsp+0x80], xmm9
000070bab59dee85  vmovaps [rsp+0x90], xmm10
000070bab59dee8e  vmovaps [rsp+0xA0], xmm11
000070bab59dee97  vmovaps [rsp+0xB0], xmm12
000070bab59deea0  vmovaps [rsp+0xC0], xmm13
000070bab59deea9  vmovaps [rsp+0xD0], xmm14
000070bab59deeb2  vmovaps [rsp+0xE0], xmm15
000070bab59deebb  sub rsp, 0x30
000070bab59deebf  movaps [rsp], xmm4
000070bab59deec3  movaps [rsp+0x10], xmm2
000070bab59deec8  movaps [rsp+0x20], xmm9
000070bab59deece  lea rdi, [rsp]
000070bab59deed2  mov esi, 0x00
000070bab59deed7  mov rax, 0x63B35AFBC530
000070bab59deee1  call rax
000070bab59deee3  movaps xmm4, [rsp]
000070bab59deee7  add rsp, 0x30
000070bab59deeeb  vmovaps xmm0, [rsp]
000070bab59deef0  vmovaps xmm1, [rsp+0x10]
000070bab59deef6  vmovaps xmm2, [rsp+0x20]
000070bab59deefc  vmovaps xmm3, [rsp+0x30]
000070bab59def02  vmovaps xmm5, [rsp+0x40]
000070bab59def08  vmovaps xmm6, [rsp+0x50]
000070bab59def0e  vmovaps xmm7, [rsp+0x60]
000070bab59def14  vmovaps xmm8, [rsp+0x70]
000070bab59def1a  vmovaps xmm9, [rsp+0x80]
000070bab59def23  vmovaps xmm10, [rsp+0x90]
000070bab59def2c  vmovaps xmm11, [rsp+0xA0]
000070bab59def35  vmovaps xmm12, [rsp+0xB0]
000070bab59def3e  vmovaps xmm13, [rsp+0xC0]
000070bab59def47  vmovaps xmm14, [rsp+0xD0]
000070bab59def50  vmovaps xmm15, [rsp+0xE0]
000070bab59def59  add rsp, 0xF0
000070bab59def60  pop r11
000070bab59def62  pop r10
000070bab59def64  pop r9
000070bab59def66  pop r8
000070bab59def68  pop rsi
000070bab59def69  pop rdi
000070bab59def6a  pop rdx
000070bab59def6b  pop rcx
000070bab59def6c  pop rax
000070bab59def6d  add rsp, 0x08
000070bab59def71  jmp 0x000070BAB59DC31E
000070bab59def76  sub rsp, 0x08
000070bab59def7a  push rax
000070bab59def7b  push rcx
000070bab59def7c  push rdx
000070bab59def7d  push rdi
000070bab59def7e  push rsi
000070bab59def7f  push r8
000070bab59def81  push r9
000070bab59def83  push r10
000070bab59def85  push r11
000070bab59def87  sub rsp, 0xF0
000070bab59def8e  vmovaps [rsp], xmm0
000070bab59def93  vmovaps [rsp+0x10], xmm1
000070bab59def99  vmovaps [rsp+0x20], xmm2
000070bab59def9f  vmovaps [rsp+0x30], xmm3
000070bab59defa5  vmovaps [rsp+0x40], xmm4
000070bab59defab  vmovaps [rsp+0x50], xmm5
000070bab59defb1  vmovaps [rsp+0x60], xmm6
000070bab59defb7  vmovaps [rsp+0x70], xmm7
000070bab59defbd  vmovaps [rsp+0x80], xmm8
000070bab59defc6  vmovaps [rsp+0x90], xmm10
000070bab59defcf  vmovaps [rsp+0xA0], xmm11
000070bab59defd8  vmovaps [rsp+0xB0], xmm12
000070bab59defe1  vmovaps [rsp+0xC0], xmm13
000070bab59defea  vmovaps [rsp+0xD0], xmm14
000070bab59deff3  vmovaps [rsp+0xE0], xmm15
000070bab59deffc  sub rsp, 0x30
000070bab59df000  movaps [rsp], xmm9
000070bab59df005  movaps [rsp+0x10], xmm2
000070bab59df00a  movaps [rsp+0x20], xmm1
000070bab59df00f  lea rdi, [rsp]
000070bab59df013  mov esi, 0x00
000070bab59df018  mov rax, 0x63B35AFBC530
000070bab59df022  call rax
000070bab59df024  movaps xmm9, [rsp]
000070bab59df029  add rsp, 0x30
000070bab59df02d  vmovaps xmm0, [rsp]
000070bab59df032  vmovaps xmm1, [rsp+0x10]
000070bab59df038  vmovaps xmm2, [rsp+0x20]
000070bab59df03e  vmovaps xmm3, [rsp+0x30]
000070bab59df044  vmovaps xmm4, [rsp+0x40]
000070bab59df04a  vmovaps xmm5, [rsp+0x50]
000070bab59df050  vmovaps xmm6, [rsp+0x60]
000070bab59df056  vmovaps xmm7, [rsp+0x70]
000070bab59df05c  vmovaps xmm8, [rsp+0x80]
000070bab59df065  vmovaps xmm10, [rsp+0x90]
000070bab59df06e  vmovaps xmm11, [rsp+0xA0]
000070bab59df077  vmovaps xmm12, [rsp+0xB0]
000070bab59df080  vmovaps xmm13, [rsp+0xC0]
000070bab59df089  vmovaps xmm14, [rsp+0xD0]
000070bab59df092  vmovaps xmm15, [rsp+0xE0]
000070bab59df09b  add rsp, 0xF0
000070bab59df0a2  pop r11
000070bab59df0a4  pop r10
000070bab59df0a6  pop r9
000070bab59df0a8  pop r8
000070bab59df0aa  pop rsi
000070bab59df0ab  pop rdi
000070bab59df0ac  pop rdx
000070bab59df0ad  pop rcx
000070bab59df0ae  pop rax
000070bab59df0af  add rsp, 0x08
000070bab59df0b3  jmp 0x000070BAB59DC354
000070bab59df0b8  sub rsp, 0x08
000070bab59df0bc  push rax
000070bab59df0bd  push rcx
000070bab59df0be  push rdx
000070bab59df0bf  push rdi
000070bab59df0c0  push rsi
000070bab59df0c1  push r8
000070bab59df0c3  push r9
000070bab59df0c5  push r10
000070bab59df0c7  push r11
000070bab59df0c9  sub rsp, 0xF0
000070bab59df0d0  vmovaps [rsp], xmm0
000070bab59df0d5  vmovaps [rsp+0x10], xmm2
000070bab59df0db  vmovaps [rsp+0x20], xmm3
000070bab59df0e1  vmovaps [rsp+0x30], xmm4
000070bab59df0e7  vmovaps [rsp+0x40], xmm5
000070bab59df0ed  vmovaps [rsp+0x50], xmm6
000070bab59df0f3  vmovaps [rsp+0x60], xmm7
000070bab59df0f9  vmovaps [rsp+0x70], xmm8
000070bab59df0ff  vmovaps [rsp+0x80], xmm9
000070bab59df108  vmovaps [rsp+0x90], xmm10
000070bab59df111  vmovaps [rsp+0xA0], xmm11
000070bab59df11a  vmovaps [rsp+0xB0], xmm12
000070bab59df123  vmovaps [rsp+0xC0], xmm13
000070bab59df12c  vmovaps [rsp+0xD0], xmm14
000070bab59df135  vmovaps [rsp+0xE0], xmm15
000070bab59df13e  sub rsp, 0x30
000070bab59df142  movaps [rsp], xmm1
000070bab59df146  movaps [rsp+0x10], xmm15
000070bab59df14c  movaps [rsp+0x20], xmm6
000070bab59df151  lea rdi, [rsp]
000070bab59df155  mov esi, 0x00
000070bab59df15a  mov rax, 0x63B35AFBC530
000070bab59df164  call rax
000070bab59df166  movaps xmm1, [rsp]
000070bab59df16a  add rsp, 0x30
000070bab59df16e  vmovaps xmm0, [rsp]
000070bab59df173  vmovaps xmm2, [rsp+0x10]
000070bab59df179  vmovaps xmm3, [rsp+0x20]
000070bab59df17f  vmovaps xmm4, [rsp+0x30]
000070bab59df185  vmovaps xmm5, [rsp+0x40]
000070bab59df18b  vmovaps xmm6, [rsp+0x50]
000070bab59df191  vmovaps xmm7, [rsp+0x60]
000070bab59df197  vmovaps xmm8, [rsp+0x70]
000070bab59df19d  vmovaps xmm9, [rsp+0x80]
000070bab59df1a6  vmovaps xmm10, [rsp+0x90]
000070bab59df1af  vmovaps xmm11, [rsp+0xA0]
000070bab59df1b8  vmovaps xmm12, [rsp+0xB0]
000070bab59df1c1  vmovaps xmm13, [rsp+0xC0]
000070bab59df1ca  vmovaps xmm14, [rsp+0xD0]
000070bab59df1d3  vmovaps xmm15, [rsp+0xE0]
000070bab59df1dc  add rsp, 0xF0
000070bab59df1e3  pop r11
000070bab59df1e5  pop r10
000070bab59df1e7  pop r9
000070bab59df1e9  pop r8
000070bab59df1eb  pop rsi
000070bab59df1ec  pop rdi
000070bab59df1ed  pop rdx
000070bab59df1ee  pop rcx
000070bab59df1ef  pop rax
000070bab59df1f0  add rsp, 0x08
000070bab59df1f4  jmp 0x000070BAB59DC375
000070bab59df1f9  sub rsp, 0x08
000070bab59df1fd  push rax
000070bab59df1fe  push rcx
000070bab59df1ff  push rdx
000070bab59df200  push rdi
000070bab59df201  push rsi
000070bab59df202  push r8
000070bab59df204  push r9
000070bab59df206  push r10
000070bab59df208  push r11
000070bab59df20a  sub rsp, 0xF0
000070bab59df211  vmovaps [rsp], xmm0
000070bab59df216  vmovaps [rsp+0x10], xmm1
000070bab59df21c  vmovaps [rsp+0x20], xmm2
000070bab59df222  vmovaps [rsp+0x30], xmm3
000070bab59df228  vmovaps [rsp+0x40], xmm4
000070bab59df22e  vmovaps [rsp+0x50], xmm5
000070bab59df234  vmovaps [rsp+0x60], xmm6
000070bab59df23a  vmovaps [rsp+0x70], xmm7
000070bab59df240  vmovaps [rsp+0x80], xmm8
000070bab59df249  vmovaps [rsp+0x90], xmm9
000070bab59df252  vmovaps [rsp+0xA0], xmm10
000070bab59df25b  vmovaps [rsp+0xB0], xmm11
000070bab59df264  vmovaps [rsp+0xC0], xmm12
000070bab59df26d  vmovaps [rsp+0xD0], xmm13
000070bab59df276  vmovaps [rsp+0xE0], xmm14
000070bab59df27f  sub rsp, 0x30
000070bab59df283  movaps [rsp], xmm15
000070bab59df288  movaps [rsp+0x10], xmm5
000070bab59df28d  movaps [rsp+0x20], xmm3
000070bab59df292  lea rdi, [rsp]
000070bab59df296  mov esi, 0x00
000070bab59df29b  mov rax, 0x63B35AFBC530
000070bab59df2a5  call rax
000070bab59df2a7  movaps xmm15, [rsp]
000070bab59df2ac  add rsp, 0x30
000070bab59df2b0  vmovaps xmm0, [rsp]
000070bab59df2b5  vmovaps xmm1, [rsp+0x10]
000070bab59df2bb  vmovaps xmm2, [rsp+0x20]
000070bab59df2c1  vmovaps xmm3, [rsp+0x30]
000070bab59df2c7  vmovaps xmm4, [rsp+0x40]
000070bab59df2cd  vmovaps xmm5, [rsp+0x50]
000070bab59df2d3  vmovaps xmm6, [rsp+0x60]
000070bab59df2d9  vmovaps xmm7, [rsp+0x70]
000070bab59df2df  vmovaps xmm8, [rsp+0x80]
000070bab59df2e8  vmovaps xmm9, [rsp+0x90]
000070bab59df2f1  vmovaps xmm10, [rsp+0xA0]
000070bab59df2fa  vmovaps xmm11, [rsp+0xB0]
000070bab59df303  vmovaps xmm12, [rsp+0xC0]
000070bab59df30c  vmovaps xmm13, [rsp+0xD0]
000070bab59df315  vmovaps xmm14, [rsp+0xE0]
000070bab59df31e  add rsp, 0xF0
000070bab59df325  pop r11
000070bab59df327  pop r10
000070bab59df329  pop r9
000070bab59df32b  pop r8
000070bab59df32d  pop rsi
000070bab59df32e  pop rdi
000070bab59df32f  pop rdx
000070bab59df330  pop rcx
000070bab59df331  pop rax
000070bab59df332  add rsp, 0x08
000070bab59df336  jmp 0x000070BAB59DC38F
000070bab59df33b  sub rsp, 0x08
000070bab59df33f  push rax
000070bab59df340  push rcx
000070bab59df341  push rdx
000070bab59df342  push rdi
000070bab59df343  push rsi
000070bab59df344  push r8
000070bab59df346  push r9
000070bab59df348  push r10
000070bab59df34a  push r11
000070bab59df34c  sub rsp, 0xF0
000070bab59df353  vmovaps [rsp], xmm0
000070bab59df358  vmovaps [rsp+0x10], xmm1
000070bab59df35e  vmovaps [rsp+0x20], xmm2
000070bab59df364  vmovaps [rsp+0x30], xmm3
000070bab59df36a  vmovaps [rsp+0x40], xmm4
000070bab59df370  vmovaps [rsp+0x50], xmm6
000070bab59df376  vmovaps [rsp+0x60], xmm7
000070bab59df37c  vmovaps [rsp+0x70], xmm8
000070bab59df382  vmovaps [rsp+0x80], xmm9
000070bab59df38b  vmovaps [rsp+0x90], xmm10
000070bab59df394  vmovaps [rsp+0xA0], xmm11
000070bab59df39d  vmovaps [rsp+0xB0], xmm12
000070bab59df3a6  vmovaps [rsp+0xC0], xmm13
000070bab59df3af  vmovaps [rsp+0xD0], xmm14
000070bab59df3b8  vmovaps [rsp+0xE0], xmm15
000070bab59df3c1  sub rsp, 0x30
000070bab59df3c5  movaps [rsp], xmm5
000070bab59df3c9  movaps [rsp+0x10], xmm8
000070bab59df3cf  movaps [rsp+0x20], xmm6
000070bab59df3d4  lea rdi, [rsp]
000070bab59df3d8  mov esi, 0x00
000070bab59df3dd  mov rax, 0x63B35AFBC530
000070bab59df3e7  call rax
000070bab59df3e9  movaps xmm5, [rsp]
000070bab59df3ed  add rsp, 0x30
000070bab59df3f1  vmovaps xmm0, [rsp]
000070bab59df3f6  vmovaps xmm1, [rsp+0x10]
000070bab59df3fc  vmovaps xmm2, [rsp+0x20]
000070bab59df402  vmovaps xmm3, [rsp+0x30]
000070bab59df408  vmovaps xmm4, [rsp+0x40]
000070bab59df40e  vmovaps xmm6, [rsp+0x50]
000070bab59df414  vmovaps xmm7, [rsp+0x60]
000070bab59df41a  vmovaps xmm8, [rsp+0x70]
000070bab59df420  vmovaps xmm9, [rsp+0x80]
000070bab59df429  vmovaps xmm10, [rsp+0x90]
000070bab59df432  vmovaps xmm11, [rsp+0xA0]
000070bab59df43b  vmovaps xmm12, [rsp+0xB0]
000070bab59df444  vmovaps xmm13, [rsp+0xC0]
000070bab59df44d  vmovaps xmm14, [rsp+0xD0]
000070bab59df456  vmovaps xmm15, [rsp+0xE0]
000070bab59df45f  add rsp, 0xF0
000070bab59df466  pop r11
000070bab59df468  pop r10
000070bab59df46a  pop r9
000070bab59df46c  pop r8
000070bab59df46e  pop rsi
000070bab59df46f  pop rdi
000070bab59df470  pop rdx
000070bab59df471  pop rcx
000070bab59df472  pop rax
000070bab59df473  add rsp, 0x08
000070bab59df477  jmp 0x000070BAB59DC3B3
000070bab59df47c  sub rsp, 0x08
000070bab59df480  push rax
000070bab59df481  push rcx
000070bab59df482  push rdx
000070bab59df483  push rdi
000070bab59df484  push rsi
000070bab59df485  push r8
000070bab59df487  push r9
000070bab59df489  push r10
000070bab59df48b  push r11
000070bab59df48d  sub rsp, 0xF0
000070bab59df494  vmovaps [rsp], xmm0
000070bab59df499  vmovaps [rsp+0x10], xmm1
000070bab59df49f  vmovaps [rsp+0x20], xmm2
000070bab59df4a5  vmovaps [rsp+0x30], xmm3
000070bab59df4ab  vmovaps [rsp+0x40], xmm4
000070bab59df4b1  vmovaps [rsp+0x50], xmm5
000070bab59df4b7  vmovaps [rsp+0x60], xmm7
000070bab59df4bd  vmovaps [rsp+0x70], xmm8
000070bab59df4c3  vmovaps [rsp+0x80], xmm9
000070bab59df4cc  vmovaps [rsp+0x90], xmm10
000070bab59df4d5  vmovaps [rsp+0xA0], xmm11
000070bab59df4de  vmovaps [rsp+0xB0], xmm12
000070bab59df4e7  vmovaps [rsp+0xC0], xmm13
000070bab59df4f0  vmovaps [rsp+0xD0], xmm14
000070bab59df4f9  vmovaps [rsp+0xE0], xmm15
000070bab59df502  sub rsp, 0x30
000070bab59df506  movaps [rsp], xmm6
000070bab59df50a  movaps [rsp+0x10], xmm10
000070bab59df510  movaps [rsp+0x20], xmm8
000070bab59df516  lea rdi, [rsp]
000070bab59df51a  mov esi, 0x00
000070bab59df51f  mov rax, 0x63B35AFBC530
000070bab59df529  call rax
000070bab59df52b  movaps xmm6, [rsp]
000070bab59df52f  add rsp, 0x30
000070bab59df533  vmovaps xmm0, [rsp]
000070bab59df538  vmovaps xmm1, [rsp+0x10]
000070bab59df53e  vmovaps xmm2, [rsp+0x20]
000070bab59df544  vmovaps xmm3, [rsp+0x30]
000070bab59df54a  vmovaps xmm4, [rsp+0x40]
000070bab59df550  vmovaps xmm5, [rsp+0x50]
000070bab59df556  vmovaps xmm7, [rsp+0x60]
000070bab59df55c  vmovaps xmm8, [rsp+0x70]
000070bab59df562  vmovaps xmm9, [rsp+0x80]
000070bab59df56b  vmovaps xmm10, [rsp+0x90]
000070bab59df574  vmovaps xmm11, [rsp+0xA0]
000070bab59df57d  vmovaps xmm12, [rsp+0xB0]
000070bab59df586  vmovaps xmm13, [rsp+0xC0]
000070bab59df58f  vmovaps xmm14, [rsp+0xD0]
000070bab59df598  vmovaps xmm15, [rsp+0xE0]
000070bab59df5a1  add rsp, 0xF0
000070bab59df5a8  pop r11
000070bab59df5aa  pop r10
000070bab59df5ac  pop r9
000070bab59df5ae  pop r8
000070bab59df5b0  pop rsi
000070bab59df5b1  pop rdi
000070bab59df5b2  pop rdx
000070bab59df5b3  pop rcx
000070bab59df5b4  pop rax
000070bab59df5b5  add rsp, 0x08
000070bab59df5b9  jmp 0x000070BAB59DC3D8
000070bab59df5be  sub rsp, 0x08
000070bab59df5c2  push rax
000070bab59df5c3  push rcx
000070bab59df5c4  push rdx
000070bab59df5c5  push rdi
000070bab59df5c6  push rsi
000070bab59df5c7  push r8
000070bab59df5c9  push r9
000070bab59df5cb  push r10
000070bab59df5cd  push r11
000070bab59df5cf  sub rsp, 0xF0
000070bab59df5d6  vmovaps [rsp], xmm0
000070bab59df5db  vmovaps [rsp+0x10], xmm1
000070bab59df5e1  vmovaps [rsp+0x20], xmm2
000070bab59df5e7  vmovaps [rsp+0x30], xmm3
000070bab59df5ed  vmovaps [rsp+0x40], xmm4
000070bab59df5f3  vmovaps [rsp+0x50], xmm5
000070bab59df5f9  vmovaps [rsp+0x60], xmm6
000070bab59df5ff  vmovaps [rsp+0x70], xmm7
000070bab59df605  vmovaps [rsp+0x80], xmm8
000070bab59df60e  vmovaps [rsp+0x90], xmm9
000070bab59df617  vmovaps [rsp+0xA0], xmm11
000070bab59df620  vmovaps [rsp+0xB0], xmm12
000070bab59df629  vmovaps [rsp+0xC0], xmm13
000070bab59df632  vmovaps [rsp+0xD0], xmm14
000070bab59df63b  vmovaps [rsp+0xE0], xmm15
000070bab59df644  sub rsp, 0x30
000070bab59df648  movaps [rsp], xmm10
000070bab59df64d  movaps [rsp+0x10], xmm8
000070bab59df653  movaps [rsp+0x20], xmm14
000070bab59df659  lea rdi, [rsp]
000070bab59df65d  mov esi, 0x00
000070bab59df662  mov rax, 0x63B35AFBC530
000070bab59df66c  call rax
000070bab59df66e  movaps xmm10, [rsp]
000070bab59df673  add rsp, 0x30
000070bab59df677  vmovaps xmm0, [rsp]
000070bab59df67c  vmovaps xmm1, [rsp+0x10]
000070bab59df682  vmovaps xmm2, [rsp+0x20]
000070bab59df688  vmovaps xmm3, [rsp+0x30]
000070bab59df68e  vmovaps xmm4, [rsp+0x40]
000070bab59df694  vmovaps xmm5, [rsp+0x50]
000070bab59df69a  vmovaps xmm6, [rsp+0x60]
000070bab59df6a0  vmovaps xmm7, [rsp+0x70]
000070bab59df6a6  vmovaps xmm8, [rsp+0x80]
000070bab59df6af  vmovaps xmm9, [rsp+0x90]
000070bab59df6b8  vmovaps xmm11, [rsp+0xA0]
000070bab59df6c1  vmovaps xmm12, [rsp+0xB0]
000070bab59df6ca  vmovaps xmm13, [rsp+0xC0]
000070bab59df6d3  vmovaps xmm14, [rsp+0xD0]
000070bab59df6dc  vmovaps xmm15, [rsp+0xE0]
000070bab59df6e5  add rsp, 0xF0
000070bab59df6ec  pop r11
000070bab59df6ee  pop r10
000070bab59df6f0  pop r9
000070bab59df6f2  pop r8
000070bab59df6f4  pop rsi
000070bab59df6f5  pop rdi
000070bab59df6f6  pop rdx
000070bab59df6f7  pop rcx
000070bab59df6f8  pop rax
000070bab59df6f9  add rsp, 0x08
000070bab59df6fd  jmp 0x000070BAB59DC3F8
000070bab59df702  sub rsp, 0x08
000070bab59df706  push rax
000070bab59df707  push rcx
000070bab59df708  push rdx
000070bab59df709  push rdi
000070bab59df70a  push rsi
000070bab59df70b  push r8
000070bab59df70d  push r9
000070bab59df70f  push r10
000070bab59df711  push r11
000070bab59df713  sub rsp, 0xF0
000070bab59df71a  vmovaps [rsp], xmm0
000070bab59df71f  vmovaps [rsp+0x10], xmm1
000070bab59df725  vmovaps [rsp+0x20], xmm2
000070bab59df72b  vmovaps [rsp+0x30], xmm3
000070bab59df731  vmovaps [rsp+0x40], xmm4
000070bab59df737  vmovaps [rsp+0x50], xmm5
000070bab59df73d  vmovaps [rsp+0x60], xmm6
000070bab59df743  vmovaps [rsp+0x70], xmm7
000070bab59df749  vmovaps [rsp+0x80], xmm8
000070bab59df752  vmovaps [rsp+0x90], xmm9
000070bab59df75b  vmovaps [rsp+0xA0], xmm10
000070bab59df764  vmovaps [rsp+0xB0], xmm11
000070bab59df76d  vmovaps [rsp+0xC0], xmm12
000070bab59df776  vmovaps [rsp+0xD0], xmm13
000070bab59df77f  vmovaps [rsp+0xE0], xmm15
000070bab59df788  sub rsp, 0x30
000070bab59df78c  movaps [rsp], xmm14
000070bab59df791  movaps [rsp+0x10], xmm8
000070bab59df797  movaps [rsp+0x20], xmm4
000070bab59df79c  lea rdi, [rsp]
000070bab59df7a0  mov esi, 0x00
000070bab59df7a5  mov rax, 0x63B35AFBC530
000070bab59df7af  call rax
000070bab59df7b1  movaps xmm14, [rsp]
000070bab59df7b6  add rsp, 0x30
000070bab59df7ba  vmovaps xmm0, [rsp]
000070bab59df7bf  vmovaps xmm1, [rsp+0x10]
000070bab59df7c5  vmovaps xmm2, [rsp+0x20]
000070bab59df7cb  vmovaps xmm3, [rsp+0x30]
000070bab59df7d1  vmovaps xmm4, [rsp+0x40]
000070bab59df7d7  vmovaps xmm5, [rsp+0x50]
000070bab59df7dd  vmovaps xmm6, [rsp+0x60]
000070bab59df7e3  vmovaps xmm7, [rsp+0x70]
000070bab59df7e9  vmovaps xmm8, [rsp+0x80]
000070bab59df7f2  vmovaps xmm9, [rsp+0x90]
000070bab59df7fb  vmovaps xmm10, [rsp+0xA0]
000070bab59df804  vmovaps xmm11, [rsp+0xB0]
000070bab59df80d  vmovaps xmm12, [rsp+0xC0]
000070bab59df816  vmovaps xmm13, [rsp+0xD0]
000070bab59df81f  vmovaps xmm15, [rsp+0xE0]
000070bab59df828  add rsp, 0xF0
000070bab59df82f  pop r11
000070bab59df831  pop r10
000070bab59df833  pop r9
000070bab59df835  pop r8
000070bab59df837  pop rsi
000070bab59df838  pop rdi
000070bab59df839  pop rdx
000070bab59df83a  pop rcx
000070bab59df83b  pop rax
000070bab59df83c  add rsp, 0x08
000070bab59df840  jmp 0x000070BAB59DC418
000070bab59df845  sub rsp, 0x08
000070bab59df849  push rax
000070bab59df84a  push rcx
000070bab59df84b  push rdx
000070bab59df84c  push rdi
000070bab59df84d  push rsi
000070bab59df84e  push r8
000070bab59df850  push r9
000070bab59df852  push r10
000070bab59df854  push r11
000070bab59df856  sub rsp, 0xF0
000070bab59df85d  vmovaps [rsp], xmm0
000070bab59df862  vmovaps [rsp+0x10], xmm1
000070bab59df868  vmovaps [rsp+0x20], xmm2
000070bab59df86e  vmovaps [rsp+0x30], xmm3
000070bab59df874  vmovaps [rsp+0x40], xmm5
000070bab59df87a  vmovaps [rsp+0x50], xmm6
000070bab59df880  vmovaps [rsp+0x60], xmm7
000070bab59df886  vmovaps [rsp+0x70], xmm8
000070bab59df88c  vmovaps [rsp+0x80], xmm9
000070bab59df895  vmovaps [rsp+0x90], xmm10
000070bab59df89e  vmovaps [rsp+0xA0], xmm11
000070bab59df8a7  vmovaps [rsp+0xB0], xmm12
000070bab59df8b0  vmovaps [rsp+0xC0], xmm13
000070bab59df8b9  vmovaps [rsp+0xD0], xmm14
000070bab59df8c2  vmovaps [rsp+0xE0], xmm15
000070bab59df8cb  sub rsp, 0x30
000070bab59df8cf  movaps [rsp], xmm4
000070bab59df8d3  movaps [rsp+0x10], xmm13
000070bab59df8d9  movaps [rsp+0x20], xmm8
000070bab59df8df  lea rdi, [rsp]
000070bab59df8e3  mov esi, 0x00
000070bab59df8e8  mov rax, 0x63B35AFBC530
000070bab59df8f2  call rax
000070bab59df8f4  movaps xmm4, [rsp]
000070bab59df8f8  add rsp, 0x30
000070bab59df8fc  vmovaps xmm0, [rsp]
000070bab59df901  vmovaps xmm1, [rsp+0x10]
000070bab59df907  vmovaps xmm2, [rsp+0x20]
000070bab59df90d  vmovaps xmm3, [rsp+0x30]
000070bab59df913  vmovaps xmm5, [rsp+0x40]
000070bab59df919  vmovaps xmm6, [rsp+0x50]
000070bab59df91f  vmovaps xmm7, [rsp+0x60]
000070bab59df925  vmovaps xmm8, [rsp+0x70]
000070bab59df92b  vmovaps xmm9, [rsp+0x80]
000070bab59df934  vmovaps xmm10, [rsp+0x90]
000070bab59df93d  vmovaps xmm11, [rsp+0xA0]
000070bab59df946  vmovaps xmm12, [rsp+0xB0]
000070bab59df94f  vmovaps xmm13, [rsp+0xC0]
000070bab59df958  vmovaps xmm14, [rsp+0xD0]
000070bab59df961  vmovaps xmm15, [rsp+0xE0]
000070bab59df96a  add rsp, 0xF0
000070bab59df971  pop r11
000070bab59df973  pop r10
000070bab59df975  pop r9
000070bab59df977  pop r8
000070bab59df979  pop rsi
000070bab59df97a  pop rdi
000070bab59df97b  pop rdx
000070bab59df97c  pop rcx
000070bab59df97d  pop rax
000070bab59df97e  add rsp, 0x08
000070bab59df982  jmp 0x000070BAB59DC43D
000070bab59df987  sub rsp, 0x08
000070bab59df98b  push rax
000070bab59df98c  push rcx
000070bab59df98d  push rdx
000070bab59df98e  push rdi
000070bab59df98f  push rsi
000070bab59df990  push r8
000070bab59df992  push r9
000070bab59df994  push r10
000070bab59df996  push r11
000070bab59df998  sub rsp, 0xF0
000070bab59df99f  vmovaps [rsp], xmm0
000070bab59df9a4  vmovaps [rsp+0x10], xmm1
000070bab59df9aa  vmovaps [rsp+0x20], xmm2
000070bab59df9b0  vmovaps [rsp+0x30], xmm3
000070bab59df9b6  vmovaps [rsp+0x40], xmm4
000070bab59df9bc  vmovaps [rsp+0x50], xmm5
000070bab59df9c2  vmovaps [rsp+0x60], xmm6
000070bab59df9c8  vmovaps [rsp+0x70], xmm7
000070bab59df9ce  vmovaps [rsp+0x80], xmm8
000070bab59df9d7  vmovaps [rsp+0x90], xmm9
000070bab59df9e0  vmovaps [rsp+0xA0], xmm10
000070bab59df9e9  vmovaps [rsp+0xB0], xmm11
000070bab59df9f2  vmovaps [rsp+0xC0], xmm12
000070bab59df9fb  vmovaps [rsp+0xD0], xmm14
000070bab59dfa04  vmovaps [rsp+0xE0], xmm15
000070bab59dfa0d  sub rsp, 0x30
000070bab59dfa11  movaps [rsp], xmm13
000070bab59dfa16  movaps [rsp+0x10], xmm15
000070bab59dfa1c  movaps [rsp+0x20], xmm9
000070bab59dfa22  lea rdi, [rsp]
000070bab59dfa26  mov esi, 0x00
000070bab59dfa2b  mov rax, 0x63B35AFBC530
000070bab59dfa35  call rax
000070bab59dfa37  movaps xmm13, [rsp]
000070bab59dfa3c  add rsp, 0x30
000070bab59dfa40  vmovaps xmm0, [rsp]
000070bab59dfa45  vmovaps xmm1, [rsp+0x10]
000070bab59dfa4b  vmovaps xmm2, [rsp+0x20]
000070bab59dfa51  vmovaps xmm3, [rsp+0x30]
000070bab59dfa57  vmovaps xmm4, [rsp+0x40]
000070bab59dfa5d  vmovaps xmm5, [rsp+0x50]
000070bab59dfa63  vmovaps xmm6, [rsp+0x60]
000070bab59dfa69  vmovaps xmm7, [rsp+0x70]
000070bab59dfa6f  vmovaps xmm8, [rsp+0x80]
000070bab59dfa78  vmovaps xmm9, [rsp+0x90]
000070bab59dfa81  vmovaps xmm10, [rsp+0xA0]
000070bab59dfa8a  vmovaps xmm11, [rsp+0xB0]
000070bab59dfa93  vmovaps xmm12, [rsp+0xC0]
000070bab59dfa9c  vmovaps xmm14, [rsp+0xD0]
000070bab59dfaa5  vmovaps xmm15, [rsp+0xE0]
000070bab59dfaae  add rsp, 0xF0
000070bab59dfab5  pop r11
000070bab59dfab7  pop r10
000070bab59dfab9  pop r9
000070bab59dfabb  pop r8
000070bab59dfabd  pop rsi
000070bab59dfabe  pop rdi
000070bab59dfabf  pop rdx
000070bab59dfac0  pop rcx
000070bab59dfac1  pop rax
000070bab59dfac2  add rsp, 0x08
000070bab59dfac6  jmp 0x000070BAB59DC458
000070bab59dfacb  sub rsp, 0x08
000070bab59dfacf  push rax
000070bab59dfad0  push rcx
000070bab59dfad1  push rdx
000070bab59dfad2  push rdi
000070bab59dfad3  push rsi
000070bab59dfad4  push r8
000070bab59dfad6  push r9
000070bab59dfad8  push r10
000070bab59dfada  push r11
000070bab59dfadc  sub rsp, 0xF0
000070bab59dfae3  vmovaps [rsp], xmm0
000070bab59dfae8  vmovaps [rsp+0x10], xmm1
000070bab59dfaee  vmovaps [rsp+0x20], xmm2
000070bab59dfaf4  vmovaps [rsp+0x30], xmm3
000070bab59dfafa  vmovaps [rsp+0x40], xmm4
000070bab59dfb00  vmovaps [rsp+0x50], xmm5
000070bab59dfb06  vmovaps [rsp+0x60], xmm6
000070bab59dfb0c  vmovaps [rsp+0x70], xmm7
000070bab59dfb12  vmovaps [rsp+0x80], xmm8
000070bab59dfb1b  vmovaps [rsp+0x90], xmm9
000070bab59dfb24  vmovaps [rsp+0xA0], xmm10
000070bab59dfb2d  vmovaps [rsp+0xB0], xmm11
000070bab59dfb36  vmovaps [rsp+0xC0], xmm12
000070bab59dfb3f  vmovaps [rsp+0xD0], xmm13
000070bab59dfb48  vmovaps [rsp+0xE0], xmm14
000070bab59dfb51  sub rsp, 0x30
000070bab59dfb55  movaps [rsp], xmm15
000070bab59dfb5a  movaps [rsp+0x10], xmm1
000070bab59dfb5f  movaps [rsp+0x20], xmm5
000070bab59dfb64  lea rdi, [rsp]
000070bab59dfb68  mov esi, 0x00
000070bab59dfb6d  mov rax, 0x63B35AFBC530
000070bab59dfb77  call rax
000070bab59dfb79  movaps xmm15, [rsp]
000070bab59dfb7e  add rsp, 0x30
000070bab59dfb82  vmovaps xmm0, [rsp]
000070bab59dfb87  vmovaps xmm1, [rsp+0x10]
000070bab59dfb8d  vmovaps xmm2, [rsp+0x20]
000070bab59dfb93  vmovaps xmm3, [rsp+0x30]
000070bab59dfb99  vmovaps xmm4, [rsp+0x40]
000070bab59dfb9f  vmovaps xmm5, [rsp+0x50]
000070bab59dfba5  vmovaps xmm6, [rsp+0x60]
000070bab59dfbab  vmovaps xmm7, [rsp+0x70]
000070bab59dfbb1  vmovaps xmm8, [rsp+0x80]
000070bab59dfbba  vmovaps xmm9, [rsp+0x90]
000070bab59dfbc3  vmovaps xmm10, [rsp+0xA0]
000070bab59dfbcc  vmovaps xmm11, [rsp+0xB0]
000070bab59dfbd5  vmovaps xmm12, [rsp+0xC0]
000070bab59dfbde  vmovaps xmm13, [rsp+0xD0]
000070bab59dfbe7  vmovaps xmm14, [rsp+0xE0]
000070bab59dfbf0  add rsp, 0xF0
000070bab59dfbf7  pop r11
000070bab59dfbf9  pop r10
000070bab59dfbfb  pop r9
000070bab59dfbfd  pop r8
000070bab59dfbff  pop rsi
000070bab59dfc00  pop rdi
000070bab59dfc01  pop rdx
000070bab59dfc02  pop rcx
000070bab59dfc03  pop rax
000070bab59dfc04  add rsp, 0x08
000070bab59dfc08  jmp 0x000070BAB59DC473
000070bab59dfc0d  call 0x000070BAB58B52F0
000070bab59dfc12  jmp 0x000070BAB59DC4CE
000070bab59dfc17  sub rsp, 0x08
000070bab59dfc1b  push rax
000070bab59dfc1c  push rcx
000070bab59dfc1d  push rdx
000070bab59dfc1e  push rdi
000070bab59dfc1f  push rsi
000070bab59dfc20  push r8
000070bab59dfc22  push r9
000070bab59dfc24  push r10
000070bab59dfc26  push r11
000070bab59dfc28  sub rsp, 0xF0
000070bab59dfc2f  vmovaps [rsp], xmm0
000070bab59dfc34  vmovaps [rsp+0x10], xmm1
000070bab59dfc3a  vmovaps [rsp+0x20], xmm2
000070bab59dfc40  vmovaps [rsp+0x30], xmm3
000070bab59dfc46  vmovaps [rsp+0x40], xmm4
000070bab59dfc4c  vmovaps [rsp+0x50], xmm5
000070bab59dfc52  vmovaps [rsp+0x60], xmm6
000070bab59dfc58  vmovaps [rsp+0x70], xmm7
000070bab59dfc5e  vmovaps [rsp+0x80], xmm8
000070bab59dfc67  vmovaps [rsp+0x90], xmm10
000070bab59dfc70  vmovaps [rsp+0xA0], xmm11
000070bab59dfc79  vmovaps [rsp+0xB0], xmm12
000070bab59dfc82  vmovaps [rsp+0xC0], xmm13
000070bab59dfc8b  vmovaps [rsp+0xD0], xmm14
000070bab59dfc94  vmovaps [rsp+0xE0], xmm15
000070bab59dfc9d  sub rsp, 0x30
000070bab59dfca1  movaps [rsp], xmm9
000070bab59dfca6  movaps [rsp+0x10], xmm8
000070bab59dfcac  movaps [rsp+0x20], xmm11
000070bab59dfcb2  lea rdi, [rsp]
000070bab59dfcb6  mov esi, 0x00
000070bab59dfcbb  mov rax, 0x63B35AFBC530
000070bab59dfcc5  call rax
000070bab59dfcc7  movaps xmm9, [rsp]
000070bab59dfccc  add rsp, 0x30
000070bab59dfcd0  vmovaps xmm0, [rsp]
000070bab59dfcd5  vmovaps xmm1, [rsp+0x10]
000070bab59dfcdb  vmovaps xmm2, [rsp+0x20]
000070bab59dfce1  vmovaps xmm3, [rsp+0x30]
000070bab59dfce7  vmovaps xmm4, [rsp+0x40]
000070bab59dfced  vmovaps xmm5, [rsp+0x50]
000070bab59dfcf3  vmovaps xmm6, [rsp+0x60]
000070bab59dfcf9  vmovaps xmm7, [rsp+0x70]
000070bab59dfcff  vmovaps xmm8, [rsp+0x80]
000070bab59dfd08  vmovaps xmm10, [rsp+0x90]
000070bab59dfd11  vmovaps xmm11, [rsp+0xA0]
000070bab59dfd1a  vmovaps xmm12, [rsp+0xB0]
000070bab59dfd23  vmovaps xmm13, [rsp+0xC0]
000070bab59dfd2c  vmovaps xmm14, [rsp+0xD0]
000070bab59dfd35  vmovaps xmm15, [rsp+0xE0]
000070bab59dfd3e  add rsp, 0xF0
000070bab59dfd45  pop r11
000070bab59dfd47  pop r10
000070bab59dfd49  pop r9
000070bab59dfd4b  pop r8
000070bab59dfd4d  pop rsi
000070bab59dfd4e  pop rdi
000070bab59dfd4f  pop rdx
000070bab59dfd50  pop rcx
000070bab59dfd51  pop rax
000070bab59dfd52  add rsp, 0x08
000070bab59dfd56  jmp 0x000070BAB59DC505
000070bab59dfd5b  sub rsp, 0x08
000070bab59dfd5f  push rax
000070bab59dfd60  push rcx
000070bab59dfd61  push rdx
000070bab59dfd62  push rdi
000070bab59dfd63  push rsi
000070bab59dfd64  push r8
000070bab59dfd66  push r9
000070bab59dfd68  push r10
000070bab59dfd6a  push r11
000070bab59dfd6c  sub rsp, 0xF0
000070bab59dfd73  vmovaps [rsp], xmm0
000070bab59dfd78  vmovaps [rsp+0x10], xmm1
000070bab59dfd7e  vmovaps [rsp+0x20], xmm2
000070bab59dfd84  vmovaps [rsp+0x30], xmm3
000070bab59dfd8a  vmovaps [rsp+0x40], xmm4
000070bab59dfd90  vmovaps [rsp+0x50], xmm5
000070bab59dfd96  vmovaps [rsp+0x60], xmm6
000070bab59dfd9c  vmovaps [rsp+0x70], xmm7
000070bab59dfda2  vmovaps [rsp+0x80], xmm8
000070bab59dfdab  vmovaps [rsp+0x90], xmm9
000070bab59dfdb4  vmovaps [rsp+0xA0], xmm10
000070bab59dfdbd  vmovaps [rsp+0xB0], xmm12
000070bab59dfdc6  vmovaps [rsp+0xC0], xmm13
000070bab59dfdcf  vmovaps [rsp+0xD0], xmm14
000070bab59dfdd8  vmovaps [rsp+0xE0], xmm15
000070bab59dfde1  sub rsp, 0x30
000070bab59dfde5  movaps [rsp], xmm11
000070bab59dfdea  movaps [rsp+0x10], xmm10
000070bab59dfdf0  movaps [rsp+0x20], xmm6
000070bab59dfdf5  lea rdi, [rsp]
000070bab59dfdf9  mov esi, 0x00
000070bab59dfdfe  mov rax, 0x63B35AFBC530
000070bab59dfe08  call rax
000070bab59dfe0a  movaps xmm11, [rsp]
000070bab59dfe0f  add rsp, 0x30
000070bab59dfe13  vmovaps xmm0, [rsp]
000070bab59dfe18  vmovaps xmm1, [rsp+0x10]
000070bab59dfe1e  vmovaps xmm2, [rsp+0x20]
000070bab59dfe24  vmovaps xmm3, [rsp+0x30]
000070bab59dfe2a  vmovaps xmm4, [rsp+0x40]
000070bab59dfe30  vmovaps xmm5, [rsp+0x50]
000070bab59dfe36  vmovaps xmm6, [rsp+0x60]
000070bab59dfe3c  vmovaps xmm7, [rsp+0x70]
000070bab59dfe42  vmovaps xmm8, [rsp+0x80]
000070bab59dfe4b  vmovaps xmm9, [rsp+0x90]
000070bab59dfe54  vmovaps xmm10, [rsp+0xA0]
000070bab59dfe5d  vmovaps xmm12, [rsp+0xB0]
000070bab59dfe66  vmovaps xmm13, [rsp+0xC0]
000070bab59dfe6f  vmovaps xmm14, [rsp+0xD0]
000070bab59dfe78  vmovaps xmm15, [rsp+0xE0]
000070bab59dfe81  add rsp, 0xF0
000070bab59dfe88  pop r11
000070bab59dfe8a  pop r10
000070bab59dfe8c  pop r9
000070bab59dfe8e  pop r8
000070bab59dfe90  pop rsi
000070bab59dfe91  pop rdi
000070bab59dfe92  pop rdx
000070bab59dfe93  pop rcx
000070bab59dfe94  pop rax
000070bab59dfe95  add rsp, 0x08
000070bab59dfe99  jmp 0x000070BAB59DC520
000070bab59dfe9e  sub rsp, 0x08
000070bab59dfea2  push rax
000070bab59dfea3  push rcx
000070bab59dfea4  push rdx
000070bab59dfea5  push rdi
000070bab59dfea6  push rsi
000070bab59dfea7  push r8
000070bab59dfea9  push r9
000070bab59dfeab  push r10
000070bab59dfead  push r11
000070bab59dfeaf  sub rsp, 0xF0
000070bab59dfeb6  vmovaps [rsp], xmm0
000070bab59dfebb  vmovaps [rsp+0x10], xmm1
000070bab59dfec1  vmovaps [rsp+0x20], xmm2
000070bab59dfec7  vmovaps [rsp+0x30], xmm3
000070bab59dfecd  vmovaps [rsp+0x40], xmm4
000070bab59dfed3  vmovaps [rsp+0x50], xmm5
000070bab59dfed9  vmovaps [rsp+0x60], xmm6
000070bab59dfedf  vmovaps [rsp+0x70], xmm7
000070bab59dfee5  vmovaps [rsp+0x80], xmm8
000070bab59dfeee  vmovaps [rsp+0x90], xmm9
000070bab59dfef7  vmovaps [rsp+0xA0], xmm11
000070bab59dff00  vmovaps [rsp+0xB0], xmm12
000070bab59dff09  vmovaps [rsp+0xC0], xmm13
000070bab59dff12  vmovaps [rsp+0xD0], xmm14
000070bab59dff1b  vmovaps [rsp+0xE0], xmm15
000070bab59dff24  sub rsp, 0x30
000070bab59dff28  movaps [rsp], xmm10
000070bab59dff2d  movaps [rsp+0x10], xmm14
000070bab59dff33  movaps [rsp+0x20], xmm4
000070bab59dff38  lea rdi, [rsp]
000070bab59dff3c  mov esi, 0x00
000070bab59dff41  mov rax, 0x63B35AFBC530
000070bab59dff4b  call rax
000070bab59dff4d  movaps xmm10, [rsp]
000070bab59dff52  add rsp, 0x30
000070bab59dff56  vmovaps xmm0, [rsp]
000070bab59dff5b  vmovaps xmm1, [rsp+0x10]
000070bab59dff61  vmovaps xmm2, [rsp+0x20]
000070bab59dff67  vmovaps xmm3, [rsp+0x30]
000070bab59dff6d  vmovaps xmm4, [rsp+0x40]
000070bab59dff73  vmovaps xmm5, [rsp+0x50]
000070bab59dff79  vmovaps xmm6, [rsp+0x60]
000070bab59dff7f  vmovaps xmm7, [rsp+0x70]
000070bab59dff85  vmovaps xmm8, [rsp+0x80]
000070bab59dff8e  vmovaps xmm9, [rsp+0x90]
000070bab59dff97  vmovaps xmm11, [rsp+0xA0]
000070bab59dffa0  vmovaps xmm12, [rsp+0xB0]
000070bab59dffa9  vmovaps xmm13, [rsp+0xC0]
000070bab59dffb2  vmovaps xmm14, [rsp+0xD0]
000070bab59dffbb  vmovaps xmm15, [rsp+0xE0]
000070bab59dffc4  add rsp, 0xF0
000070bab59dffcb  pop r11
000070bab59dffcd  pop r10
000070bab59dffcf  pop r9
000070bab59dffd1  pop r8
000070bab59dffd3  pop rsi
000070bab59dffd4  pop rdi
000070bab59dffd5  pop rdx
000070bab59dffd6  pop rcx
000070bab59dffd7  pop rax
000070bab59dffd8  add rsp, 0x08
000070bab59dffdc  jmp 0x000070BAB59DC53B
000070bab59dffe1  sub rsp, 0x08
000070bab59dffe5  push rax
000070bab59dffe6  push rcx
000070bab59dffe7  push rdx
000070bab59dffe8  push rdi
000070bab59dffe9  push rsi
000070bab59dffea  push r8
000070bab59dffec  push r9
000070bab59dffee  push r10
000070bab59dfff0  push r11
000070bab59dfff2  sub rsp, 0xF0
000070bab59dfff9  vmovaps [rsp], xmm0
000070bab59dfffe  vmovaps [rsp+0x10], xmm1
000070bab59e0004  vmovaps [rsp+0x20], xmm2
000070bab59e000a  vmovaps [rsp+0x30], xmm3
000070bab59e0010  vmovaps [rsp+0x40], xmm4
000070bab59e0016  vmovaps [rsp+0x50], xmm5
000070bab59e001c  vmovaps [rsp+0x60], xmm6
000070bab59e0022  vmovaps [rsp+0x70], xmm7
000070bab59e0028  vmovaps [rsp+0x80], xmm9
000070bab59e0031  vmovaps [rsp+0x90], xmm10
000070bab59e003a  vmovaps [rsp+0xA0], xmm11
000070bab59e0043  vmovaps [rsp+0xB0], xmm12
000070bab59e004c  vmovaps [rsp+0xC0], xmm13
000070bab59e0055  vmovaps [rsp+0xD0], xmm14
000070bab59e005e  vmovaps [rsp+0xE0], xmm15
000070bab59e0067  sub rsp, 0x30
000070bab59e006b  movaps [rsp], xmm8
000070bab59e0070  movaps [rsp+0x10], xmm1
000070bab59e0075  movaps [rsp+0x20], xmm14
000070bab59e007b  lea rdi, [rsp]
000070bab59e007f  mov esi, 0x00
000070bab59e0084  mov rax, 0x63B35AFBC530
000070bab59e008e  call rax
000070bab59e0090  movaps xmm8, [rsp]
000070bab59e0095  add rsp, 0x30
000070bab59e0099  vmovaps xmm0, [rsp]
000070bab59e009e  vmovaps xmm1, [rsp+0x10]
000070bab59e00a4  vmovaps xmm2, [rsp+0x20]
000070bab59e00aa  vmovaps xmm3, [rsp+0x30]
000070bab59e00b0  vmovaps xmm4, [rsp+0x40]
000070bab59e00b6  vmovaps xmm5, [rsp+0x50]
000070bab59e00bc  vmovaps xmm6, [rsp+0x60]
000070bab59e00c2  vmovaps xmm7, [rsp+0x70]
000070bab59e00c8  vmovaps xmm9, [rsp+0x80]
000070bab59e00d1  vmovaps xmm10, [rsp+0x90]
000070bab59e00da  vmovaps xmm11, [rsp+0xA0]
000070bab59e00e3  vmovaps xmm12, [rsp+0xB0]
000070bab59e00ec  vmovaps xmm13, [rsp+0xC0]
000070bab59e00f5  vmovaps xmm14, [rsp+0xD0]
000070bab59e00fe  vmovaps xmm15, [rsp+0xE0]
000070bab59e0107  add rsp, 0xF0
000070bab59e010e  pop r11
000070bab59e0110  pop r10
000070bab59e0112  pop r9
000070bab59e0114  pop r8
000070bab59e0116  pop rsi
000070bab59e0117  pop rdi
000070bab59e0118  pop rdx
000070bab59e0119  pop rcx
000070bab59e011a  pop rax
000070bab59e011b  add rsp, 0x08
000070bab59e011f  jmp 0x000070BAB59DC561
000070bab59e0124  sub rsp, 0x08
000070bab59e0128  push rax
000070bab59e0129  push rcx
000070bab59e012a  push rdx
000070bab59e012b  push rdi
000070bab59e012c  push rsi
000070bab59e012d  push r8
000070bab59e012f  push r9
000070bab59e0131  push r10
000070bab59e0133  push r11
000070bab59e0135  sub rsp, 0xF0
000070bab59e013c  vmovaps [rsp], xmm0
000070bab59e0141  vmovaps [rsp+0x10], xmm1
000070bab59e0147  vmovaps [rsp+0x20], xmm2
000070bab59e014d  vmovaps [rsp+0x30], xmm3
000070bab59e0153  vmovaps [rsp+0x40], xmm4
000070bab59e0159  vmovaps [rsp+0x50], xmm5
000070bab59e015f  vmovaps [rsp+0x60], xmm7
000070bab59e0165  vmovaps [rsp+0x70], xmm8
000070bab59e016b  vmovaps [rsp+0x80], xmm9
000070bab59e0174  vmovaps [rsp+0x90], xmm10
000070bab59e017d  vmovaps [rsp+0xA0], xmm11
000070bab59e0186  vmovaps [rsp+0xB0], xmm12
000070bab59e018f  vmovaps [rsp+0xC0], xmm13
000070bab59e0198  vmovaps [rsp+0xD0], xmm14
000070bab59e01a1  vmovaps [rsp+0xE0], xmm15
000070bab59e01aa  sub rsp, 0x30
000070bab59e01ae  movaps [rsp], xmm6
000070bab59e01b2  movaps [rsp+0x10], xmm1
000070bab59e01b7  movaps [rsp+0x20], xmm14
000070bab59e01bd  lea rdi, [rsp]
000070bab59e01c1  mov esi, 0x00
000070bab59e01c6  mov rax, 0x63B35AFBC530
000070bab59e01d0  call rax
000070bab59e01d2  movaps xmm6, [rsp]
000070bab59e01d6  add rsp, 0x30
000070bab59e01da  vmovaps xmm0, [rsp]
000070bab59e01df  vmovaps xmm1, [rsp+0x10]
000070bab59e01e5  vmovaps xmm2, [rsp+0x20]
000070bab59e01eb  vmovaps xmm3, [rsp+0x30]
000070bab59e01f1  vmovaps xmm4, [rsp+0x40]
000070bab59e01f7  vmovaps xmm5, [rsp+0x50]
000070bab59e01fd  vmovaps xmm7, [rsp+0x60]
000070bab59e0203  vmovaps xmm8, [rsp+0x70]
000070bab59e0209  vmovaps xmm9, [rsp+0x80]
000070bab59e0212  vmovaps xmm10, [rsp+0x90]
000070bab59e021b  vmovaps xmm11, [rsp+0xA0]
000070bab59e0224  vmovaps xmm12, [rsp+0xB0]
000070bab59e022d  vmovaps xmm13, [rsp+0xC0]
000070bab59e0236  vmovaps xmm14, [rsp+0xD0]
000070bab59e023f  vmovaps xmm15, [rsp+0xE0]
000070bab59e0248  add rsp, 0xF0
000070bab59e024f  pop r11
000070bab59e0251  pop r10
000070bab59e0253  pop r9
000070bab59e0255  pop r8
000070bab59e0257  pop rsi
000070bab59e0258  pop rdi
000070bab59e0259  pop rdx
000070bab59e025a  pop rcx
000070bab59e025b  pop rax
000070bab59e025c  add rsp, 0x08
000070bab59e0260  jmp 0x000070BAB59DC58D
000070bab59e0265  sub rsp, 0x08
000070bab59e0269  push rax
000070bab59e026a  push rcx
000070bab59e026b  push rdx
000070bab59e026c  push rdi
000070bab59e026d  push rsi
000070bab59e026e  push r8
000070bab59e0270  push r9
000070bab59e0272  push r10
000070bab59e0274  push r11
000070bab59e0276  sub rsp, 0xF0
000070bab59e027d  vmovaps [rsp], xmm0
000070bab59e0282  vmovaps [rsp+0x10], xmm1
000070bab59e0288  vmovaps [rsp+0x20], xmm2
000070bab59e028e  vmovaps [rsp+0x30], xmm3
000070bab59e0294  vmovaps [rsp+0x40], xmm4
000070bab59e029a  vmovaps [rsp+0x50], xmm5
000070bab59e02a0  vmovaps [rsp+0x60], xmm6
000070bab59e02a6  vmovaps [rsp+0x70], xmm7
000070bab59e02ac  vmovaps [rsp+0x80], xmm8
000070bab59e02b5  vmovaps [rsp+0x90], xmm9
000070bab59e02be  vmovaps [rsp+0xA0], xmm10
000070bab59e02c7  vmovaps [rsp+0xB0], xmm11
000070bab59e02d0  vmovaps [rsp+0xC0], xmm12
000070bab59e02d9  vmovaps [rsp+0xD0], xmm13
000070bab59e02e2  vmovaps [rsp+0xE0], xmm15
000070bab59e02eb  sub rsp, 0x30
000070bab59e02ef  movaps [rsp], xmm14
000070bab59e02f4  movaps [rsp+0x10], xmm12
000070bab59e02fa  movaps [rsp+0x20], xmm1
000070bab59e02ff  lea rdi, [rsp]
000070bab59e0303  mov esi, 0x00
000070bab59e0308  mov rax, 0x63B35AFBC530
000070bab59e0312  call rax
000070bab59e0314  movaps xmm14, [rsp]
000070bab59e0319  add rsp, 0x30
000070bab59e031d  vmovaps xmm0, [rsp]
000070bab59e0322  vmovaps xmm1, [rsp+0x10]
000070bab59e0328  vmovaps xmm2, [rsp+0x20]
000070bab59e032e  vmovaps xmm3, [rsp+0x30]
000070bab59e0334  vmovaps xmm4, [rsp+0x40]
000070bab59e033a  vmovaps xmm5, [rsp+0x50]
000070bab59e0340  vmovaps xmm6, [rsp+0x60]
000070bab59e0346  vmovaps xmm7, [rsp+0x70]
000070bab59e034c  vmovaps xmm8, [rsp+0x80]
000070bab59e0355  vmovaps xmm9, [rsp+0x90]
000070bab59e035e  vmovaps xmm10, [rsp+0xA0]
000070bab59e0367  vmovaps xmm11, [rsp+0xB0]
000070bab59e0370  vmovaps xmm12, [rsp+0xC0]
000070bab59e0379  vmovaps xmm13, [rsp+0xD0]
000070bab59e0382  vmovaps xmm15, [rsp+0xE0]
000070bab59e038b  add rsp, 0xF0
000070bab59e0392  pop r11
000070bab59e0394  pop r10
000070bab59e0396  pop r9
000070bab59e0398  pop r8
000070bab59e039a  pop rsi
000070bab59e039b  pop rdi
000070bab59e039c  pop rdx
000070bab59e039d  pop rcx
000070bab59e039e  pop rax
000070bab59e039f  add rsp, 0x08
000070bab59e03a3  jmp 0x000070BAB59DC5B3
000070bab59e03a8  sub rsp, 0x08
000070bab59e03ac  push rax
000070bab59e03ad  push rcx
000070bab59e03ae  push rdx
000070bab59e03af  push rdi
000070bab59e03b0  push rsi
000070bab59e03b1  push r8
000070bab59e03b3  push r9
000070bab59e03b5  push r10
000070bab59e03b7  push r11
000070bab59e03b9  sub rsp, 0xF0
000070bab59e03c0  vmovaps [rsp], xmm0
000070bab59e03c5  vmovaps [rsp+0x10], xmm2
000070bab59e03cb  vmovaps [rsp+0x20], xmm3
000070bab59e03d1  vmovaps [rsp+0x30], xmm4
000070bab59e03d7  vmovaps [rsp+0x40], xmm5
000070bab59e03dd  vmovaps [rsp+0x50], xmm6
000070bab59e03e3  vmovaps [rsp+0x60], xmm7
000070bab59e03e9  vmovaps [rsp+0x70], xmm8
000070bab59e03ef  vmovaps [rsp+0x80], xmm9
000070bab59e03f8  vmovaps [rsp+0x90], xmm10
000070bab59e0401  vmovaps [rsp+0xA0], xmm11
000070bab59e040a  vmovaps [rsp+0xB0], xmm12
000070bab59e0413  vmovaps [rsp+0xC0], xmm13
000070bab59e041c  vmovaps [rsp+0xD0], xmm14
000070bab59e0425  vmovaps [rsp+0xE0], xmm15
000070bab59e042e  sub rsp, 0x30
000070bab59e0432  movaps [rsp], xmm1
000070bab59e0436  movaps [rsp+0x10], xmm13
000070bab59e043c  movaps [rsp+0x20], xmm9
000070bab59e0442  lea rdi, [rsp]
000070bab59e0446  mov esi, 0x00
000070bab59e044b  mov rax, 0x63B35AFBC530
000070bab59e0455  call rax
000070bab59e0457  movaps xmm1, [rsp]
000070bab59e045b  add rsp, 0x30
000070bab59e045f  vmovaps xmm0, [rsp]
000070bab59e0464  vmovaps xmm2, [rsp+0x10]
000070bab59e046a  vmovaps xmm3, [rsp+0x20]
000070bab59e0470  vmovaps xmm4, [rsp+0x30]
000070bab59e0476  vmovaps xmm5, [rsp+0x40]
000070bab59e047c  vmovaps xmm6, [rsp+0x50]
000070bab59e0482  vmovaps xmm7, [rsp+0x60]
000070bab59e0488  vmovaps xmm8, [rsp+0x70]
000070bab59e048e  vmovaps xmm9, [rsp+0x80]
000070bab59e0497  vmovaps xmm10, [rsp+0x90]
000070bab59e04a0  vmovaps xmm11, [rsp+0xA0]
000070bab59e04a9  vmovaps xmm12, [rsp+0xB0]
000070bab59e04b2  vmovaps xmm13, [rsp+0xC0]
000070bab59e04bb  vmovaps xmm14, [rsp+0xD0]
000070bab59e04c4  vmovaps xmm15, [rsp+0xE0]
000070bab59e04cd  add rsp, 0xF0
000070bab59e04d4  pop r11
000070bab59e04d6  pop r10
000070bab59e04d8  pop r9
000070bab59e04da  pop r8
000070bab59e04dc  pop rsi
000070bab59e04dd  pop rdi
000070bab59e04de  pop rdx
000070bab59e04df  pop rcx
000070bab59e04e0  pop rax
000070bab59e04e1  add rsp, 0x08
000070bab59e04e5  jmp 0x000070BAB59DC5CD
000070bab59e04ea  sub rsp, 0x08
000070bab59e04ee  push rax
000070bab59e04ef  push rcx
000070bab59e04f0  push rdx
000070bab59e04f1  push rdi
000070bab59e04f2  push rsi
000070bab59e04f3  push r8
000070bab59e04f5  push r9
000070bab59e04f7  push r10
000070bab59e04f9  push r11
000070bab59e04fb  sub rsp, 0xF0
000070bab59e0502  vmovaps [rsp], xmm0
000070bab59e0507  vmovaps [rsp+0x10], xmm1
000070bab59e050d  vmovaps [rsp+0x20], xmm2
000070bab59e0513  vmovaps [rsp+0x30], xmm3
000070bab59e0519  vmovaps [rsp+0x40], xmm4
000070bab59e051f  vmovaps [rsp+0x50], xmm5
000070bab59e0525  vmovaps [rsp+0x60], xmm6
000070bab59e052b  vmovaps [rsp+0x70], xmm7
000070bab59e0531  vmovaps [rsp+0x80], xmm8
000070bab59e053a  vmovaps [rsp+0x90], xmm9
000070bab59e0543  vmovaps [rsp+0xA0], xmm10
000070bab59e054c  vmovaps [rsp+0xB0], xmm11
000070bab59e0555  vmovaps [rsp+0xC0], xmm13
000070bab59e055e  vmovaps [rsp+0xD0], xmm14
000070bab59e0567  vmovaps [rsp+0xE0], xmm15
000070bab59e0570  sub rsp, 0x30
000070bab59e0574  movaps [rsp], xmm12
000070bab59e0579  movaps [rsp+0x10], xmm7
000070bab59e057e  movaps [rsp+0x20], xmm13
000070bab59e0584  lea rdi, [rsp]
000070bab59e0588  mov esi, 0x00
000070bab59e058d  mov rax, 0x63B35AFBC530
000070bab59e0597  call rax
000070bab59e0599  movaps xmm12, [rsp]
000070bab59e059e  add rsp, 0x30
000070bab59e05a2  vmovaps xmm0, [rsp]
000070bab59e05a7  vmovaps xmm1, [rsp+0x10]
000070bab59e05ad  vmovaps xmm2, [rsp+0x20]
000070bab59e05b3  vmovaps xmm3, [rsp+0x30]
000070bab59e05b9  vmovaps xmm4, [rsp+0x40]
000070bab59e05bf  vmovaps xmm5, [rsp+0x50]
000070bab59e05c5  vmovaps xmm6, [rsp+0x60]
000070bab59e05cb  vmovaps xmm7, [rsp+0x70]
000070bab59e05d1  vmovaps xmm8, [rsp+0x80]
000070bab59e05da  vmovaps xmm9, [rsp+0x90]
000070bab59e05e3  vmovaps xmm10, [rsp+0xA0]
000070bab59e05ec  vmovaps xmm11, [rsp+0xB0]
000070bab59e05f5  vmovaps xmm13, [rsp+0xC0]
000070bab59e05fe  vmovaps xmm14, [rsp+0xD0]
000070bab59e0607  vmovaps xmm15, [rsp+0xE0]
000070bab59e0610  add rsp, 0xF0
000070bab59e0617  pop r11
000070bab59e0619  pop r10
000070bab59e061b  pop r9
000070bab59e061d  pop r8
000070bab59e061f  pop rsi
000070bab59e0620  pop rdi
000070bab59e0621  pop rdx
000070bab59e0622  pop rcx
000070bab59e0623  pop rax
000070bab59e0624  add rsp, 0x08
000070bab59e0628  jmp 0x000070BAB59DC5F4
000070bab59e062d  sub rsp, 0x08
000070bab59e0631  push rax
000070bab59e0632  push rcx
000070bab59e0633  push rdx
000070bab59e0634  push rdi
000070bab59e0635  push rsi
000070bab59e0636  push r8
000070bab59e0638  push r9
000070bab59e063a  push r10
000070bab59e063c  push r11
000070bab59e063e  sub rsp, 0xF0
000070bab59e0645  vmovaps [rsp], xmm0
000070bab59e064a  vmovaps [rsp+0x10], xmm1
000070bab59e0650  vmovaps [rsp+0x20], xmm2
000070bab59e0656  vmovaps [rsp+0x30], xmm3
000070bab59e065c  vmovaps [rsp+0x40], xmm4
000070bab59e0662  vmovaps [rsp+0x50], xmm5
000070bab59e0668  vmovaps [rsp+0x60], xmm6
000070bab59e066e  vmovaps [rsp+0x70], xmm7
000070bab59e0674  vmovaps [rsp+0x80], xmm8
000070bab59e067d  vmovaps [rsp+0x90], xmm9
000070bab59e0686  vmovaps [rsp+0xA0], xmm10
000070bab59e068f  vmovaps [rsp+0xB0], xmm11
000070bab59e0698  vmovaps [rsp+0xC0], xmm12
000070bab59e06a1  vmovaps [rsp+0xD0], xmm14
000070bab59e06aa  vmovaps [rsp+0xE0], xmm15
000070bab59e06b3  sub rsp, 0x30
000070bab59e06b7  movaps [rsp], xmm13
000070bab59e06bc  movaps [rsp+0x10], xmm15
000070bab59e06c2  movaps [rsp+0x20], xmm8
000070bab59e06c8  lea rdi, [rsp]
000070bab59e06cc  mov esi, 0x00
000070bab59e06d1  mov rax, 0x63B35AFBC530
000070bab59e06db  call rax
000070bab59e06dd  movaps xmm13, [rsp]
000070bab59e06e2  add rsp, 0x30
000070bab59e06e6  vmovaps xmm0, [rsp]
000070bab59e06eb  vmovaps xmm1, [rsp+0x10]
000070bab59e06f1  vmovaps xmm2, [rsp+0x20]
000070bab59e06f7  vmovaps xmm3, [rsp+0x30]
000070bab59e06fd  vmovaps xmm4, [rsp+0x40]
000070bab59e0703  vmovaps xmm5, [rsp+0x50]
000070bab59e0709  vmovaps xmm6, [rsp+0x60]
000070bab59e070f  vmovaps xmm7, [rsp+0x70]
000070bab59e0715  vmovaps xmm8, [rsp+0x80]
000070bab59e071e  vmovaps xmm9, [rsp+0x90]
000070bab59e0727  vmovaps xmm10, [rsp+0xA0]
000070bab59e0730  vmovaps xmm11, [rsp+0xB0]
000070bab59e0739  vmovaps xmm12, [rsp+0xC0]
000070bab59e0742  vmovaps xmm14, [rsp+0xD0]
000070bab59e074b  vmovaps xmm15, [rsp+0xE0]
000070bab59e0754  add rsp, 0xF0
000070bab59e075b  pop r11
000070bab59e075d  pop r10
000070bab59e075f  pop r9
000070bab59e0761  pop r8
000070bab59e0763  pop rsi
000070bab59e0764  pop rdi
000070bab59e0765  pop rdx
000070bab59e0766  pop rcx
000070bab59e0767  pop rax
000070bab59e0768  add rsp, 0x08
000070bab59e076c  jmp 0x000070BAB59DC60F
000070bab59e0771  sub rsp, 0x08
000070bab59e0775  push rax
000070bab59e0776  push rcx
000070bab59e0777  push rdx
000070bab59e0778  push rdi
000070bab59e0779  push rsi
000070bab59e077a  push r8
000070bab59e077c  push r9
000070bab59e077e  push r10
000070bab59e0780  push r11
000070bab59e0782  sub rsp, 0xF0
000070bab59e0789  vmovaps [rsp], xmm0
000070bab59e078e  vmovaps [rsp+0x10], xmm1
000070bab59e0794  vmovaps [rsp+0x20], xmm2
000070bab59e079a  vmovaps [rsp+0x30], xmm3
000070bab59e07a0  vmovaps [rsp+0x40], xmm4
000070bab59e07a6  vmovaps [rsp+0x50], xmm5
000070bab59e07ac  vmovaps [rsp+0x60], xmm6
000070bab59e07b2  vmovaps [rsp+0x70], xmm7
000070bab59e07b8  vmovaps [rsp+0x80], xmm9
000070bab59e07c1  vmovaps [rsp+0x90], xmm10
000070bab59e07ca  vmovaps [rsp+0xA0], xmm11
000070bab59e07d3  vmovaps [rsp+0xB0], xmm12
000070bab59e07dc  vmovaps [rsp+0xC0], xmm13
000070bab59e07e5  vmovaps [rsp+0xD0], xmm14
000070bab59e07ee  vmovaps [rsp+0xE0], xmm15
000070bab59e07f7  sub rsp, 0x30
000070bab59e07fb  movaps [rsp], xmm8
000070bab59e0800  movaps [rsp+0x10], xmm15
000070bab59e0806  movaps [rsp+0x20], xmm9
000070bab59e080c  lea rdi, [rsp]
000070bab59e0810  mov esi, 0x00
000070bab59e0815  mov rax, 0x63B35AFBC530
000070bab59e081f  call rax
000070bab59e0821  movaps xmm8, [rsp]
000070bab59e0826  add rsp, 0x30
000070bab59e082a  vmovaps xmm0, [rsp]
000070bab59e082f  vmovaps xmm1, [rsp+0x10]
000070bab59e0835  vmovaps xmm2, [rsp+0x20]
000070bab59e083b  vmovaps xmm3, [rsp+0x30]
000070bab59e0841  vmovaps xmm4, [rsp+0x40]
000070bab59e0847  vmovaps xmm5, [rsp+0x50]
000070bab59e084d  vmovaps xmm6, [rsp+0x60]
000070bab59e0853  vmovaps xmm7, [rsp+0x70]
000070bab59e0859  vmovaps xmm9, [rsp+0x80]
000070bab59e0862  vmovaps xmm10, [rsp+0x90]
000070bab59e086b  vmovaps xmm11, [rsp+0xA0]
000070bab59e0874  vmovaps xmm12, [rsp+0xB0]
000070bab59e087d  vmovaps xmm13, [rsp+0xC0]
000070bab59e0886  vmovaps xmm14, [rsp+0xD0]
000070bab59e088f  vmovaps xmm15, [rsp+0xE0]
000070bab59e0898  add rsp, 0xF0
000070bab59e089f  pop r11
000070bab59e08a1  pop r10
000070bab59e08a3  pop r9
000070bab59e08a5  pop r8
000070bab59e08a7  pop rsi
000070bab59e08a8  pop rdi
000070bab59e08a9  pop rdx
000070bab59e08aa  pop rcx
000070bab59e08ab  pop rax
000070bab59e08ac  add rsp, 0x08
000070bab59e08b0  jmp 0x000070BAB59DC63D
000070bab59e08b5  sub rsp, 0x08
000070bab59e08b9  push rax
000070bab59e08ba  push rcx
000070bab59e08bb  push rdx
000070bab59e08bc  push rdi
000070bab59e08bd  push rsi
000070bab59e08be  push r8
000070bab59e08c0  push r9
000070bab59e08c2  push r10
000070bab59e08c4  push r11
000070bab59e08c6  sub rsp, 0xF0
000070bab59e08cd  vmovaps [rsp], xmm0
000070bab59e08d2  vmovaps [rsp+0x10], xmm1
000070bab59e08d8  vmovaps [rsp+0x20], xmm2
000070bab59e08de  vmovaps [rsp+0x30], xmm3
000070bab59e08e4  vmovaps [rsp+0x40], xmm4
000070bab59e08ea  vmovaps [rsp+0x50], xmm5
000070bab59e08f0  vmovaps [rsp+0x60], xmm6
000070bab59e08f6  vmovaps [rsp+0x70], xmm7
000070bab59e08fc  vmovaps [rsp+0x80], xmm8
000070bab59e0905  vmovaps [rsp+0x90], xmm9
000070bab59e090e  vmovaps [rsp+0xA0], xmm10
000070bab59e0917  vmovaps [rsp+0xB0], xmm11
000070bab59e0920  vmovaps [rsp+0xC0], xmm12
000070bab59e0929  vmovaps [rsp+0xD0], xmm13
000070bab59e0932  vmovaps [rsp+0xE0], xmm14
000070bab59e093b  sub rsp, 0x30
000070bab59e093f  movaps [rsp], xmm15
000070bab59e0944  movaps [rsp+0x10], xmm11
000070bab59e094a  movaps [rsp+0x20], xmm6
000070bab59e094f  lea rdi, [rsp]
000070bab59e0953  mov esi, 0x00
000070bab59e0958  mov rax, 0x63B35AFBC530
000070bab59e0962  call rax
000070bab59e0964  movaps xmm15, [rsp]
000070bab59e0969  add rsp, 0x30
000070bab59e096d  vmovaps xmm0, [rsp]
000070bab59e0972  vmovaps xmm1, [rsp+0x10]
000070bab59e0978  vmovaps xmm2, [rsp+0x20]
000070bab59e097e  vmovaps xmm3, [rsp+0x30]
000070bab59e0984  vmovaps xmm4, [rsp+0x40]
000070bab59e098a  vmovaps xmm5, [rsp+0x50]
000070bab59e0990  vmovaps xmm6, [rsp+0x60]
000070bab59e0996  vmovaps xmm7, [rsp+0x70]
000070bab59e099c  vmovaps xmm8, [rsp+0x80]
000070bab59e09a5  vmovaps xmm9, [rsp+0x90]
000070bab59e09ae  vmovaps xmm10, [rsp+0xA0]
000070bab59e09b7  vmovaps xmm11, [rsp+0xB0]
000070bab59e09c0  vmovaps xmm12, [rsp+0xC0]
000070bab59e09c9  vmovaps xmm13, [rsp+0xD0]
000070bab59e09d2  vmovaps xmm14, [rsp+0xE0]
000070bab59e09db  add rsp, 0xF0
000070bab59e09e2  pop r11
000070bab59e09e4  pop r10
000070bab59e09e6  pop r9
000070bab59e09e8  pop r8
000070bab59e09ea  pop rsi
000070bab59e09eb  pop rdi
000070bab59e09ec  pop rdx
000070bab59e09ed  pop rcx
000070bab59e09ee  pop rax
000070bab59e09ef  add rsp, 0x08
000070bab59e09f3  jmp 0x000070BAB59DC658
000070bab59e09f8  sub rsp, 0x08
000070bab59e09fc  push rax
000070bab59e09fd  push rcx
000070bab59e09fe  push rdx
000070bab59e09ff  push rdi
000070bab59e0a00  push rsi
000070bab59e0a01  push r8
000070bab59e0a03  push r9
000070bab59e0a05  push r10
000070bab59e0a07  push r11
000070bab59e0a09  sub rsp, 0xF0
000070bab59e0a10  vmovaps [rsp], xmm0
000070bab59e0a15  vmovaps [rsp+0x10], xmm1
000070bab59e0a1b  vmovaps [rsp+0x20], xmm2
000070bab59e0a21  vmovaps [rsp+0x30], xmm3
000070bab59e0a27  vmovaps [rsp+0x40], xmm4
000070bab59e0a2d  vmovaps [rsp+0x50], xmm5
000070bab59e0a33  vmovaps [rsp+0x60], xmm6
000070bab59e0a39  vmovaps [rsp+0x70], xmm8
000070bab59e0a3f  vmovaps [rsp+0x80], xmm9
000070bab59e0a48  vmovaps [rsp+0x90], xmm10
000070bab59e0a51  vmovaps [rsp+0xA0], xmm11
000070bab59e0a5a  vmovaps [rsp+0xB0], xmm12
000070bab59e0a63  vmovaps [rsp+0xC0], xmm13
000070bab59e0a6c  vmovaps [rsp+0xD0], xmm14
000070bab59e0a75  vmovaps [rsp+0xE0], xmm15
000070bab59e0a7e  sub rsp, 0x30
000070bab59e0a82  movaps [rsp], xmm7
000070bab59e0a86  movaps [rsp+0x10], xmm11
000070bab59e0a8c  movaps [rsp+0x20], xmm9
000070bab59e0a92  lea rdi, [rsp]
000070bab59e0a96  mov esi, 0x00
000070bab59e0a9b  mov rax, 0x63B35AFBC530
000070bab59e0aa5  call rax
000070bab59e0aa7  movaps xmm7, [rsp]
000070bab59e0aab  add rsp, 0x30
000070bab59e0aaf  vmovaps xmm0, [rsp]
000070bab59e0ab4  vmovaps xmm1, [rsp+0x10]
000070bab59e0aba  vmovaps xmm2, [rsp+0x20]
000070bab59e0ac0  vmovaps xmm3, [rsp+0x30]
000070bab59e0ac6  vmovaps xmm4, [rsp+0x40]
000070bab59e0acc  vmovaps xmm5, [rsp+0x50]
000070bab59e0ad2  vmovaps xmm6, [rsp+0x60]
000070bab59e0ad8  vmovaps xmm8, [rsp+0x70]
000070bab59e0ade  vmovaps xmm9, [rsp+0x80]
000070bab59e0ae7  vmovaps xmm10, [rsp+0x90]
000070bab59e0af0  vmovaps xmm11, [rsp+0xA0]
000070bab59e0af9  vmovaps xmm12, [rsp+0xB0]
000070bab59e0b02  vmovaps xmm13, [rsp+0xC0]
000070bab59e0b0b  vmovaps xmm14, [rsp+0xD0]
000070bab59e0b14  vmovaps xmm15, [rsp+0xE0]
000070bab59e0b1d  add rsp, 0xF0
000070bab59e0b24  pop r11
000070bab59e0b26  pop r10
000070bab59e0b28  pop r9
000070bab59e0b2a  pop r8
000070bab59e0b2c  pop rsi
000070bab59e0b2d  pop rdi
000070bab59e0b2e  pop rdx
000070bab59e0b2f  pop rcx
000070bab59e0b30  pop rax
000070bab59e0b31  add rsp, 0x08
000070bab59e0b35  jmp 0x000070BAB59DC685
000070bab59e0b3a  sub rsp, 0x08
000070bab59e0b3e  push rax
000070bab59e0b3f  push rcx
000070bab59e0b40  push rdx
000070bab59e0b41  push rdi
000070bab59e0b42  push rsi
000070bab59e0b43  push r8
000070bab59e0b45  push r9
000070bab59e0b47  push r10
000070bab59e0b49  push r11
000070bab59e0b4b  sub rsp, 0xF0
000070bab59e0b52  vmovaps [rsp], xmm0
000070bab59e0b57  vmovaps [rsp+0x10], xmm1
000070bab59e0b5d  vmovaps [rsp+0x20], xmm2
000070bab59e0b63  vmovaps [rsp+0x30], xmm3
000070bab59e0b69  vmovaps [rsp+0x40], xmm4
000070bab59e0b6f  vmovaps [rsp+0x50], xmm5
000070bab59e0b75  vmovaps [rsp+0x60], xmm6
000070bab59e0b7b  vmovaps [rsp+0x70], xmm7
000070bab59e0b81  vmovaps [rsp+0x80], xmm8
000070bab59e0b8a  vmovaps [rsp+0x90], xmm9
000070bab59e0b93  vmovaps [rsp+0xA0], xmm10
000070bab59e0b9c  vmovaps [rsp+0xB0], xmm12
000070bab59e0ba5  vmovaps [rsp+0xC0], xmm13
000070bab59e0bae  vmovaps [rsp+0xD0], xmm14
000070bab59e0bb7  vmovaps [rsp+0xE0], xmm15
000070bab59e0bc0  sub rsp, 0x30
000070bab59e0bc4  movaps [rsp], xmm11
000070bab59e0bc9  movaps [rsp+0x10], xmm10
000070bab59e0bcf  movaps [rsp+0x20], xmm14
000070bab59e0bd5  lea rdi, [rsp]
000070bab59e0bd9  mov esi, 0x00
000070bab59e0bde  mov rax, 0x63B35AFBC530
000070bab59e0be8  call rax
000070bab59e0bea  movaps xmm11, [rsp]
000070bab59e0bef  add rsp, 0x30
000070bab59e0bf3  vmovaps xmm0, [rsp]
000070bab59e0bf8  vmovaps xmm1, [rsp+0x10]
000070bab59e0bfe  vmovaps xmm2, [rsp+0x20]
000070bab59e0c04  vmovaps xmm3, [rsp+0x30]
000070bab59e0c0a  vmovaps xmm4, [rsp+0x40]
000070bab59e0c10  vmovaps xmm5, [rsp+0x50]
000070bab59e0c16  vmovaps xmm6, [rsp+0x60]
000070bab59e0c1c  vmovaps xmm7, [rsp+0x70]
000070bab59e0c22  vmovaps xmm8, [rsp+0x80]
000070bab59e0c2b  vmovaps xmm9, [rsp+0x90]
000070bab59e0c34  vmovaps xmm10, [rsp+0xA0]
000070bab59e0c3d  vmovaps xmm12, [rsp+0xB0]
000070bab59e0c46  vmovaps xmm13, [rsp+0xC0]
000070bab59e0c4f  vmovaps xmm14, [rsp+0xD0]
000070bab59e0c58  vmovaps xmm15, [rsp+0xE0]
000070bab59e0c61  add rsp, 0xF0
000070bab59e0c68  pop r11
000070bab59e0c6a  pop r10
000070bab59e0c6c  pop r9
000070bab59e0c6e  pop r8
000070bab59e0c70  pop rsi
000070bab59e0c71  pop rdi
000070bab59e0c72  pop rdx
000070bab59e0c73  pop rcx
000070bab59e0c74  pop rax
000070bab59e0c75  add rsp, 0x08
000070bab59e0c79  jmp 0x000070BAB59DC6A0
000070bab59e0c7e  call 0x000070BAB58C33A0
000070bab59e0c83  jmp 0x000070BAB59DC6AA
000070bab59e0c88  sub rsp, 0x08
000070bab59e0c8c  push rax
000070bab59e0c8d  push rcx
000070bab59e0c8e  push rdx
000070bab59e0c8f  push rdi
000070bab59e0c90  push rsi
000070bab59e0c91  push r8
000070bab59e0c93  push r9
000070bab59e0c95  push r10
000070bab59e0c97  push r11
000070bab59e0c99  sub rsp, 0xF0
000070bab59e0ca0  vmovaps [rsp], xmm0
000070bab59e0ca5  vmovaps [rsp+0x10], xmm1
000070bab59e0cab  vmovaps [rsp+0x20], xmm2
000070bab59e0cb1  vmovaps [rsp+0x30], xmm3
000070bab59e0cb7  vmovaps [rsp+0x40], xmm4
000070bab59e0cbd  vmovaps [rsp+0x50], xmm5
000070bab59e0cc3  vmovaps [rsp+0x60], xmm6
000070bab59e0cc9  vmovaps [rsp+0x70], xmm7
000070bab59e0ccf  vmovaps [rsp+0x80], xmm8
000070bab59e0cd8  vmovaps [rsp+0x90], xmm9
000070bab59e0ce1  vmovaps [rsp+0xA0], xmm11
000070bab59e0cea  vmovaps [rsp+0xB0], xmm12
000070bab59e0cf3  vmovaps [rsp+0xC0], xmm13
000070bab59e0cfc  vmovaps [rsp+0xD0], xmm14
000070bab59e0d05  vmovaps [rsp+0xE0], xmm15
000070bab59e0d0e  sub rsp, 0x30
000070bab59e0d12  movaps [rsp], xmm10
000070bab59e0d17  movaps [rsp+0x10], xmm1
000070bab59e0d1c  movaps [rsp+0x20], xmm12
000070bab59e0d22  lea rdi, [rsp]
000070bab59e0d26  mov esi, 0x00
000070bab59e0d2b  mov rax, 0x63B35AFBC530
000070bab59e0d35  call rax
000070bab59e0d37  movaps xmm10, [rsp]
000070bab59e0d3c  add rsp, 0x30
000070bab59e0d40  vmovaps xmm0, [rsp]
000070bab59e0d45  vmovaps xmm1, [rsp+0x10]
000070bab59e0d4b  vmovaps xmm2, [rsp+0x20]
000070bab59e0d51  vmovaps xmm3, [rsp+0x30]
000070bab59e0d57  vmovaps xmm4, [rsp+0x40]
000070bab59e0d5d  vmovaps xmm5, [rsp+0x50]
000070bab59e0d63  vmovaps xmm6, [rsp+0x60]
000070bab59e0d69  vmovaps xmm7, [rsp+0x70]
000070bab59e0d6f  vmovaps xmm8, [rsp+0x80]
000070bab59e0d78  vmovaps xmm9, [rsp+0x90]
000070bab59e0d81  vmovaps xmm11, [rsp+0xA0]
000070bab59e0d8a  vmovaps xmm12, [rsp+0xB0]
000070bab59e0d93  vmovaps xmm13, [rsp+0xC0]
000070bab59e0d9c  vmovaps xmm14, [rsp+0xD0]
000070bab59e0da5  vmovaps xmm15, [rsp+0xE0]
000070bab59e0dae  add rsp, 0xF0
000070bab59e0db5  pop r11
000070bab59e0db7  pop r10
000070bab59e0db9  pop r9
000070bab59e0dbb  pop r8
000070bab59e0dbd  pop rsi
000070bab59e0dbe  pop rdi
000070bab59e0dbf  pop rdx
000070bab59e0dc0  pop rcx
000070bab59e0dc1  pop rax
000070bab59e0dc2  add rsp, 0x08
000070bab59e0dc6  jmp 0x000070BAB59DC6CD
000070bab59e0dcb  sub rsp, 0x08
000070bab59e0dcf  push rax
000070bab59e0dd0  push rcx
000070bab59e0dd1  push rdx
000070bab59e0dd2  push rdi
000070bab59e0dd3  push rsi
000070bab59e0dd4  push r8
000070bab59e0dd6  push r9
000070bab59e0dd8  push r10
000070bab59e0dda  push r11
000070bab59e0ddc  sub rsp, 0xF0
000070bab59e0de3  vmovaps [rsp], xmm0
000070bab59e0de8  vmovaps [rsp+0x10], xmm1
000070bab59e0dee  vmovaps [rsp+0x20], xmm2
000070bab59e0df4  vmovaps [rsp+0x30], xmm3
000070bab59e0dfa  vmovaps [rsp+0x40], xmm4
000070bab59e0e00  vmovaps [rsp+0x50], xmm5
000070bab59e0e06  vmovaps [rsp+0x60], xmm6
000070bab59e0e0c  vmovaps [rsp+0x70], xmm7
000070bab59e0e12  vmovaps [rsp+0x80], xmm8
000070bab59e0e1b  vmovaps [rsp+0x90], xmm9
000070bab59e0e24  vmovaps [rsp+0xA0], xmm10
000070bab59e0e2d  vmovaps [rsp+0xB0], xmm11
000070bab59e0e36  vmovaps [rsp+0xC0], xmm13
000070bab59e0e3f  vmovaps [rsp+0xD0], xmm14
000070bab59e0e48  vmovaps [rsp+0xE0], xmm15
000070bab59e0e51  sub rsp, 0x30
000070bab59e0e55  movaps [rsp], xmm12
000070bab59e0e5a  movaps [rsp+0x10], xmm14
000070bab59e0e60  movaps [rsp+0x20], xmm1
000070bab59e0e65  lea rdi, [rsp]
000070bab59e0e69  mov esi, 0x00
000070bab59e0e6e  mov rax, 0x63B35AFBC530
000070bab59e0e78  call rax
000070bab59e0e7a  movaps xmm12, [rsp]
000070bab59e0e7f  add rsp, 0x30
000070bab59e0e83  vmovaps xmm0, [rsp]
000070bab59e0e88  vmovaps xmm1, [rsp+0x10]
000070bab59e0e8e  vmovaps xmm2, [rsp+0x20]
000070bab59e0e94  vmovaps xmm3, [rsp+0x30]
000070bab59e0e9a  vmovaps xmm4, [rsp+0x40]
000070bab59e0ea0  vmovaps xmm5, [rsp+0x50]
000070bab59e0ea6  vmovaps xmm6, [rsp+0x60]
000070bab59e0eac  vmovaps xmm7, [rsp+0x70]
000070bab59e0eb2  vmovaps xmm8, [rsp+0x80]
000070bab59e0ebb  vmovaps xmm9, [rsp+0x90]
000070bab59e0ec4  vmovaps xmm10, [rsp+0xA0]
000070bab59e0ecd  vmovaps xmm11, [rsp+0xB0]
000070bab59e0ed6  vmovaps xmm13, [rsp+0xC0]
000070bab59e0edf  vmovaps xmm14, [rsp+0xD0]
000070bab59e0ee8  vmovaps xmm15, [rsp+0xE0]
000070bab59e0ef1  add rsp, 0xF0
000070bab59e0ef8  pop r11
000070bab59e0efa  pop r10
000070bab59e0efc  pop r9
000070bab59e0efe  pop r8
000070bab59e0f00  pop rsi
000070bab59e0f01  pop rdi
000070bab59e0f02  pop rdx
000070bab59e0f03  pop rcx
000070bab59e0f04  pop rax
000070bab59e0f05  add rsp, 0x08
000070bab59e0f09  jmp 0x000070BAB59DC6FC
000070bab59e0f0e  sub rsp, 0x08
000070bab59e0f12  push rax
000070bab59e0f13  push rcx
000070bab59e0f14  push rdx
000070bab59e0f15  push rdi
000070bab59e0f16  push rsi
000070bab59e0f17  push r8
000070bab59e0f19  push r9
000070bab59e0f1b  push r10
000070bab59e0f1d  push r11
000070bab59e0f1f  sub rsp, 0xF0
000070bab59e0f26  vmovaps [rsp], xmm0
000070bab59e0f2b  vmovaps [rsp+0x10], xmm1
000070bab59e0f31  vmovaps [rsp+0x20], xmm2
000070bab59e0f37  vmovaps [rsp+0x30], xmm3
000070bab59e0f3d  vmovaps [rsp+0x40], xmm4
000070bab59e0f43  vmovaps [rsp+0x50], xmm5
000070bab59e0f49  vmovaps [rsp+0x60], xmm6
000070bab59e0f4f  vmovaps [rsp+0x70], xmm7
000070bab59e0f55  vmovaps [rsp+0x80], xmm8
000070bab59e0f5e  vmovaps [rsp+0x90], xmm9
000070bab59e0f67  vmovaps [rsp+0xA0], xmm10
000070bab59e0f70  vmovaps [rsp+0xB0], xmm11
000070bab59e0f79  vmovaps [rsp+0xC0], xmm12
000070bab59e0f82  vmovaps [rsp+0xD0], xmm13
000070bab59e0f8b  vmovaps [rsp+0xE0], xmm15
000070bab59e0f94  sub rsp, 0x30
000070bab59e0f98  movaps [rsp], xmm14
000070bab59e0f9d  movaps [rsp+0x10], xmm9
000070bab59e0fa3  movaps [rsp+0x20], xmm1
000070bab59e0fa8  lea rdi, [rsp]
000070bab59e0fac  mov esi, 0x00
000070bab59e0fb1  mov rax, 0x63B35AFBC530
000070bab59e0fbb  call rax
000070bab59e0fbd  movaps xmm14, [rsp]
000070bab59e0fc2  add rsp, 0x30
000070bab59e0fc6  vmovaps xmm0, [rsp]
000070bab59e0fcb  vmovaps xmm1, [rsp+0x10]
000070bab59e0fd1  vmovaps xmm2, [rsp+0x20]
000070bab59e0fd7  vmovaps xmm3, [rsp+0x30]
000070bab59e0fdd  vmovaps xmm4, [rsp+0x40]
000070bab59e0fe3  vmovaps xmm5, [rsp+0x50]
000070bab59e0fe9  vmovaps xmm6, [rsp+0x60]
000070bab59e0fef  vmovaps xmm7, [rsp+0x70]
000070bab59e0ff5  vmovaps xmm8, [rsp+0x80]
000070bab59e0ffe  vmovaps xmm9, [rsp+0x90]
000070bab59e1007  vmovaps xmm10, [rsp+0xA0]
000070bab59e1010  vmovaps xmm11, [rsp+0xB0]
000070bab59e1019  vmovaps xmm12, [rsp+0xC0]
000070bab59e1022  vmovaps xmm13, [rsp+0xD0]
000070bab59e102b  vmovaps xmm15, [rsp+0xE0]
000070bab59e1034  add rsp, 0xF0
000070bab59e103b  pop r11
000070bab59e103d  pop r10
000070bab59e103f  pop r9
000070bab59e1041  pop r8
000070bab59e1043  pop rsi
000070bab59e1044  pop rdi
000070bab59e1045  pop rdx
000070bab59e1046  pop rcx
000070bab59e1047  pop rax
000070bab59e1048  add rsp, 0x08
000070bab59e104c  jmp 0x000070BAB59DC72B
000070bab59e1051  sub rsp, 0x08
000070bab59e1055  push rax
000070bab59e1056  push rcx
000070bab59e1057  push rdx
000070bab59e1058  push rdi
000070bab59e1059  push rsi
000070bab59e105a  push r8
000070bab59e105c  push r9
000070bab59e105e  push r10
000070bab59e1060  push r11
000070bab59e1062  sub rsp, 0xF0
000070bab59e1069  vmovaps [rsp], xmm0
000070bab59e106e  vmovaps [rsp+0x10], xmm2
000070bab59e1074  vmovaps [rsp+0x20], xmm3
000070bab59e107a  vmovaps [rsp+0x30], xmm4
000070bab59e1080  vmovaps [rsp+0x40], xmm5
000070bab59e1086  vmovaps [rsp+0x50], xmm6
000070bab59e108c  vmovaps [rsp+0x60], xmm7
000070bab59e1092  vmovaps [rsp+0x70], xmm8
000070bab59e1098  vmovaps [rsp+0x80], xmm9
000070bab59e10a1  vmovaps [rsp+0x90], xmm10
000070bab59e10aa  vmovaps [rsp+0xA0], xmm11
000070bab59e10b3  vmovaps [rsp+0xB0], xmm12
000070bab59e10bc  vmovaps [rsp+0xC0], xmm13
000070bab59e10c5  vmovaps [rsp+0xD0], xmm14
000070bab59e10ce  vmovaps [rsp+0xE0], xmm15
000070bab59e10d7  sub rsp, 0x30
000070bab59e10db  movaps [rsp], xmm1
000070bab59e10df  movaps [rsp+0x10], xmm13
000070bab59e10e5  movaps [rsp+0x20], xmm8
000070bab59e10eb  lea rdi, [rsp]
000070bab59e10ef  mov esi, 0x00
000070bab59e10f4  mov rax, 0x63B35AFBC530
000070bab59e10fe  call rax
000070bab59e1100  movaps xmm1, [rsp]
000070bab59e1104  add rsp, 0x30
000070bab59e1108  vmovaps xmm0, [rsp]
000070bab59e110d  vmovaps xmm2, [rsp+0x10]
000070bab59e1113  vmovaps xmm3, [rsp+0x20]
000070bab59e1119  vmovaps xmm4, [rsp+0x30]
000070bab59e111f  vmovaps xmm5, [rsp+0x40]
000070bab59e1125  vmovaps xmm6, [rsp+0x50]
000070bab59e112b  vmovaps xmm7, [rsp+0x60]
000070bab59e1131  vmovaps xmm8, [rsp+0x70]
000070bab59e1137  vmovaps xmm9, [rsp+0x80]
000070bab59e1140  vmovaps xmm10, [rsp+0x90]
000070bab59e1149  vmovaps xmm11, [rsp+0xA0]
000070bab59e1152  vmovaps xmm12, [rsp+0xB0]
000070bab59e115b  vmovaps xmm13, [rsp+0xC0]
000070bab59e1164  vmovaps xmm14, [rsp+0xD0]
000070bab59e116d  vmovaps xmm15, [rsp+0xE0]
000070bab59e1176  add rsp, 0xF0
000070bab59e117d  pop r11
000070bab59e117f  pop r10
000070bab59e1181  pop r9
000070bab59e1183  pop r8
000070bab59e1185  pop rsi
000070bab59e1186  pop rdi
000070bab59e1187  pop rdx
000070bab59e1188  pop rcx
000070bab59e1189  pop rax
000070bab59e118a  add rsp, 0x08
000070bab59e118e  jmp 0x000070BAB59DC74D
000070bab59e1193  call 0x000070BAB580C260
000070bab59e1198  jmp 0x000070BAB59DC75B
000070bab59e119d  call 0x000070BAB58BD750
000070bab59e11a2  jmp 0x000070BAB59DC765
000070bab59e11a7  sub rsp, 0x08
000070bab59e11ab  push rax
000070bab59e11ac  push rcx
000070bab59e11ad  push rdx
000070bab59e11ae  push rdi
000070bab59e11af  push rsi
000070bab59e11b0  push r8
000070bab59e11b2  push r9
000070bab59e11b4  push r10
000070bab59e11b6  push r11
000070bab59e11b8  sub rsp, 0xF0
000070bab59e11bf  vmovaps [rsp], xmm0
000070bab59e11c4  vmovaps [rsp+0x10], xmm1
000070bab59e11ca  vmovaps [rsp+0x20], xmm2
000070bab59e11d0  vmovaps [rsp+0x30], xmm3
000070bab59e11d6  vmovaps [rsp+0x40], xmm4
000070bab59e11dc  vmovaps [rsp+0x50], xmm5
000070bab59e11e2  vmovaps [rsp+0x60], xmm6
000070bab59e11e8  vmovaps [rsp+0x70], xmm7
000070bab59e11ee  vmovaps [rsp+0x80], xmm9
000070bab59e11f7  vmovaps [rsp+0x90], xmm10
000070bab59e1200  vmovaps [rsp+0xA0], xmm11
000070bab59e1209  vmovaps [rsp+0xB0], xmm12
000070bab59e1212  vmovaps [rsp+0xC0], xmm13
000070bab59e121b  vmovaps [rsp+0xD0], xmm14
000070bab59e1224  vmovaps [rsp+0xE0], xmm15
000070bab59e122d  sub rsp, 0x30
000070bab59e1231  movaps [rsp], xmm8
000070bab59e1236  movaps [rsp+0x10], xmm15
000070bab59e123c  movaps [rsp+0x20], xmm7
000070bab59e1241  lea rdi, [rsp]
000070bab59e1245  mov esi, 0x00
000070bab59e124a  mov rax, 0x63B35AFBC530
000070bab59e1254  call rax
000070bab59e1256  movaps xmm8, [rsp]
000070bab59e125b  add rsp, 0x30
000070bab59e125f  vmovaps xmm0, [rsp]
000070bab59e1264  vmovaps xmm1, [rsp+0x10]
000070bab59e126a  vmovaps xmm2, [rsp+0x20]
000070bab59e1270  vmovaps xmm3, [rsp+0x30]
000070bab59e1276  vmovaps xmm4, [rsp+0x40]
000070bab59e127c  vmovaps xmm5, [rsp+0x50]
000070bab59e1282  vmovaps xmm6, [rsp+0x60]
000070bab59e1288  vmovaps xmm7, [rsp+0x70]
000070bab59e128e  vmovaps xmm9, [rsp+0x80]
000070bab59e1297  vmovaps xmm10, [rsp+0x90]
000070bab59e12a0  vmovaps xmm11, [rsp+0xA0]
000070bab59e12a9  vmovaps xmm12, [rsp+0xB0]
000070bab59e12b2  vmovaps xmm13, [rsp+0xC0]
000070bab59e12bb  vmovaps xmm14, [rsp+0xD0]
000070bab59e12c4  vmovaps xmm15, [rsp+0xE0]
000070bab59e12cd  add rsp, 0xF0
000070bab59e12d4  pop r11
000070bab59e12d6  pop r10
000070bab59e12d8  pop r9
000070bab59e12da  pop r8
000070bab59e12dc  pop rsi
000070bab59e12dd  pop rdi
000070bab59e12de  pop rdx
000070bab59e12df  pop rcx
000070bab59e12e0  pop rax
000070bab59e12e1  add rsp, 0x08
000070bab59e12e5  jmp 0x000070BAB59DC787
000070bab59e12ea  sub rsp, 0x08
000070bab59e12ee  push rax
000070bab59e12ef  push rcx
000070bab59e12f0  push rdx
000070bab59e12f1  push rdi
000070bab59e12f2  push rsi
000070bab59e12f3  push r8
000070bab59e12f5  push r9
000070bab59e12f7  push r10
000070bab59e12f9  push r11
000070bab59e12fb  sub rsp, 0xF0
000070bab59e1302  vmovaps [rsp], xmm0
000070bab59e1307  vmovaps [rsp+0x10], xmm1
000070bab59e130d  vmovaps [rsp+0x20], xmm2
000070bab59e1313  vmovaps [rsp+0x30], xmm3
000070bab59e1319  vmovaps [rsp+0x40], xmm4
000070bab59e131f  vmovaps [rsp+0x50], xmm5
000070bab59e1325  vmovaps [rsp+0x60], xmm6
000070bab59e132b  vmovaps [rsp+0x70], xmm8
000070bab59e1331  vmovaps [rsp+0x80], xmm9
000070bab59e133a  vmovaps [rsp+0x90], xmm10
000070bab59e1343  vmovaps [rsp+0xA0], xmm11
000070bab59e134c  vmovaps [rsp+0xB0], xmm12
000070bab59e1355  vmovaps [rsp+0xC0], xmm13
000070bab59e135e  vmovaps [rsp+0xD0], xmm14
000070bab59e1367  vmovaps [rsp+0xE0], xmm15
000070bab59e1370  sub rsp, 0x30
000070bab59e1374  movaps [rsp], xmm7
000070bab59e1378  movaps [rsp+0x10], xmm9
000070bab59e137e  movaps [rsp+0x20], xmm15
000070bab59e1384  lea rdi, [rsp]
000070bab59e1388  mov esi, 0x00
000070bab59e138d  mov rax, 0x63B35AFBC530
000070bab59e1397  call rax
000070bab59e1399  movaps xmm7, [rsp]
000070bab59e139d  add rsp, 0x30
000070bab59e13a1  vmovaps xmm0, [rsp]
000070bab59e13a6  vmovaps xmm1, [rsp+0x10]
000070bab59e13ac  vmovaps xmm2, [rsp+0x20]
000070bab59e13b2  vmovaps xmm3, [rsp+0x30]
000070bab59e13b8  vmovaps xmm4, [rsp+0x40]
000070bab59e13be  vmovaps xmm5, [rsp+0x50]
000070bab59e13c4  vmovaps xmm6, [rsp+0x60]
000070bab59e13ca  vmovaps xmm8, [rsp+0x70]
000070bab59e13d0  vmovaps xmm9, [rsp+0x80]
000070bab59e13d9  vmovaps xmm10, [rsp+0x90]
000070bab59e13e2  vmovaps xmm11, [rsp+0xA0]
000070bab59e13eb  vmovaps xmm12, [rsp+0xB0]
000070bab59e13f4  vmovaps xmm13, [rsp+0xC0]
000070bab59e13fd  vmovaps xmm14, [rsp+0xD0]
000070bab59e1406  vmovaps xmm15, [rsp+0xE0]
000070bab59e140f  add rsp, 0xF0
000070bab59e1416  pop r11
000070bab59e1418  pop r10
000070bab59e141a  pop r9
000070bab59e141c  pop r8
000070bab59e141e  pop rsi
000070bab59e141f  pop rdi
000070bab59e1420  pop rdx
000070bab59e1421  pop rcx
000070bab59e1422  pop rax
000070bab59e1423  add rsp, 0x08
000070bab59e1427  jmp 0x000070BAB59DC7B4
000070bab59e142c  sub rsp, 0x08
000070bab59e1430  push rax
000070bab59e1431  push rcx
000070bab59e1432  push rdx
000070bab59e1433  push rdi
000070bab59e1434  push rsi
000070bab59e1435  push r8
000070bab59e1437  push r9
000070bab59e1439  push r10
000070bab59e143b  push r11
000070bab59e143d  sub rsp, 0xF0
000070bab59e1444  vmovaps [rsp], xmm0
000070bab59e1449  vmovaps [rsp+0x10], xmm1
000070bab59e144f  vmovaps [rsp+0x20], xmm2
000070bab59e1455  vmovaps [rsp+0x30], xmm3
000070bab59e145b  vmovaps [rsp+0x40], xmm4
000070bab59e1461  vmovaps [rsp+0x50], xmm5
000070bab59e1467  vmovaps [rsp+0x60], xmm6
000070bab59e146d  vmovaps [rsp+0x70], xmm7
000070bab59e1473  vmovaps [rsp+0x80], xmm8
000070bab59e147c  vmovaps [rsp+0x90], xmm10
000070bab59e1485  vmovaps [rsp+0xA0], xmm11
000070bab59e148e  vmovaps [rsp+0xB0], xmm12
000070bab59e1497  vmovaps [rsp+0xC0], xmm13
000070bab59e14a0  vmovaps [rsp+0xD0], xmm14
000070bab59e14a9  vmovaps [rsp+0xE0], xmm15
000070bab59e14b2  sub rsp, 0x30
000070bab59e14b6  movaps [rsp], xmm9
000070bab59e14bb  movaps [rsp+0x10], xmm13
000070bab59e14c1  movaps [rsp+0x20], xmm15
000070bab59e14c7  lea rdi, [rsp]
000070bab59e14cb  mov esi, 0x00
000070bab59e14d0  mov rax, 0x63B35AFBC530
000070bab59e14da  call rax
000070bab59e14dc  movaps xmm9, [rsp]
000070bab59e14e1  add rsp, 0x30
000070bab59e14e5  vmovaps xmm0, [rsp]
000070bab59e14ea  vmovaps xmm1, [rsp+0x10]
000070bab59e14f0  vmovaps xmm2, [rsp+0x20]
000070bab59e14f6  vmovaps xmm3, [rsp+0x30]
000070bab59e14fc  vmovaps xmm4, [rsp+0x40]
000070bab59e1502  vmovaps xmm5, [rsp+0x50]
000070bab59e1508  vmovaps xmm6, [rsp+0x60]
000070bab59e150e  vmovaps xmm7, [rsp+0x70]
000070bab59e1514  vmovaps xmm8, [rsp+0x80]
000070bab59e151d  vmovaps xmm10, [rsp+0x90]
000070bab59e1526  vmovaps xmm11, [rsp+0xA0]
000070bab59e152f  vmovaps xmm12, [rsp+0xB0]
000070bab59e1538  vmovaps xmm13, [rsp+0xC0]
000070bab59e1541  vmovaps xmm14, [rsp+0xD0]
000070bab59e154a  vmovaps xmm15, [rsp+0xE0]
000070bab59e1553  add rsp, 0xF0
000070bab59e155a  pop r11
000070bab59e155c  pop r10
000070bab59e155e  pop r9
000070bab59e1560  pop r8
000070bab59e1562  pop rsi
000070bab59e1563  pop rdi
000070bab59e1564  pop rdx
000070bab59e1565  pop rcx
000070bab59e1566  pop rax
000070bab59e1567  add rsp, 0x08
000070bab59e156b  jmp 0x000070BAB59DC7E2
000070bab59e1570  sub rsp, 0x08
000070bab59e1574  push rax
000070bab59e1575  push rcx
000070bab59e1576  push rdx
000070bab59e1577  push rdi
000070bab59e1578  push rsi
000070bab59e1579  push r8
000070bab59e157b  push r9
000070bab59e157d  push r10
000070bab59e157f  push r11
000070bab59e1581  sub rsp, 0xF0
000070bab59e1588  vmovaps [rsp], xmm0
000070bab59e158d  vmovaps [rsp+0x10], xmm1
000070bab59e1593  vmovaps [rsp+0x20], xmm2
000070bab59e1599  vmovaps [rsp+0x30], xmm3
000070bab59e159f  vmovaps [rsp+0x40], xmm4
000070bab59e15a5  vmovaps [rsp+0x50], xmm5
000070bab59e15ab  vmovaps [rsp+0x60], xmm6
000070bab59e15b1  vmovaps [rsp+0x70], xmm7
000070bab59e15b7  vmovaps [rsp+0x80], xmm8
000070bab59e15c0  vmovaps [rsp+0x90], xmm9
000070bab59e15c9  vmovaps [rsp+0xA0], xmm10
000070bab59e15d2  vmovaps [rsp+0xB0], xmm11
000070bab59e15db  vmovaps [rsp+0xC0], xmm12
000070bab59e15e4  vmovaps [rsp+0xD0], xmm13
000070bab59e15ed  vmovaps [rsp+0xE0], xmm14
000070bab59e15f6  sub rsp, 0x30
000070bab59e15fa  movaps [rsp], xmm15
000070bab59e15ff  movaps [rsp+0x10], xmm11
000070bab59e1605  movaps [rsp+0x20], xmm12
000070bab59e160b  lea rdi, [rsp]
000070bab59e160f  mov esi, 0x00
000070bab59e1614  mov rax, 0x63B35AFBC530
000070bab59e161e  call rax
000070bab59e1620  movaps xmm15, [rsp]
000070bab59e1625  add rsp, 0x30
000070bab59e1629  vmovaps xmm0, [rsp]
000070bab59e162e  vmovaps xmm1, [rsp+0x10]
000070bab59e1634  vmovaps xmm2, [rsp+0x20]
000070bab59e163a  vmovaps xmm3, [rsp+0x30]
000070bab59e1640  vmovaps xmm4, [rsp+0x40]
000070bab59e1646  vmovaps xmm5, [rsp+0x50]
000070bab59e164c  vmovaps xmm6, [rsp+0x60]
000070bab59e1652  vmovaps xmm7, [rsp+0x70]
000070bab59e1658  vmovaps xmm8, [rsp+0x80]
000070bab59e1661  vmovaps xmm9, [rsp+0x90]
000070bab59e166a  vmovaps xmm10, [rsp+0xA0]
000070bab59e1673  vmovaps xmm11, [rsp+0xB0]
000070bab59e167c  vmovaps xmm12, [rsp+0xC0]
000070bab59e1685  vmovaps xmm13, [rsp+0xD0]
000070bab59e168e  vmovaps xmm14, [rsp+0xE0]
000070bab59e1697  add rsp, 0xF0
000070bab59e169e  pop r11
000070bab59e16a0  pop r10
000070bab59e16a2  pop r9
000070bab59e16a4  pop r8
000070bab59e16a6  pop rsi
000070bab59e16a7  pop rdi
000070bab59e16a8  pop rdx
000070bab59e16a9  pop rcx
000070bab59e16aa  pop rax
000070bab59e16ab  add rsp, 0x08
000070bab59e16af  jmp 0x000070BAB59DC7FD
000070bab59e16b4  sub rsp, 0x08
000070bab59e16b8  push rax
000070bab59e16b9  push rcx
000070bab59e16ba  push rdx
000070bab59e16bb  push rdi
000070bab59e16bc  push rsi
000070bab59e16bd  push r8
000070bab59e16bf  push r9
000070bab59e16c1  push r10
000070bab59e16c3  push r11
000070bab59e16c5  sub rsp, 0xF0
000070bab59e16cc  vmovaps [rsp], xmm0
000070bab59e16d1  vmovaps [rsp+0x10], xmm1
000070bab59e16d7  vmovaps [rsp+0x20], xmm2
000070bab59e16dd  vmovaps [rsp+0x30], xmm3
000070bab59e16e3  vmovaps [rsp+0x40], xmm4
000070bab59e16e9  vmovaps [rsp+0x50], xmm5
000070bab59e16ef  vmovaps [rsp+0x60], xmm6
000070bab59e16f5  vmovaps [rsp+0x70], xmm7
000070bab59e16fb  vmovaps [rsp+0x80], xmm8
000070bab59e1704  vmovaps [rsp+0x90], xmm9
000070bab59e170d  vmovaps [rsp+0xA0], xmm10
000070bab59e1716  vmovaps [rsp+0xB0], xmm11
000070bab59e171f  vmovaps [rsp+0xC0], xmm12
000070bab59e1728  vmovaps [rsp+0xD0], xmm14
000070bab59e1731  vmovaps [rsp+0xE0], xmm15
000070bab59e173a  sub rsp, 0x30
000070bab59e173e  movaps [rsp], xmm13
000070bab59e1743  movaps [rsp+0x10], xmm10
000070bab59e1749  movaps [rsp+0x20], xmm14
000070bab59e174f  lea rdi, [rsp]
000070bab59e1753  mov esi, 0x00
000070bab59e1758  mov rax, 0x63B35AFBC530
000070bab59e1762  call rax
000070bab59e1764  movaps xmm13, [rsp]
000070bab59e1769  add rsp, 0x30
000070bab59e176d  vmovaps xmm0, [rsp]
000070bab59e1772  vmovaps xmm1, [rsp+0x10]
000070bab59e1778  vmovaps xmm2, [rsp+0x20]
000070bab59e177e  vmovaps xmm3, [rsp+0x30]
000070bab59e1784  vmovaps xmm4, [rsp+0x40]
000070bab59e178a  vmovaps xmm5, [rsp+0x50]
000070bab59e1790  vmovaps xmm6, [rsp+0x60]
000070bab59e1796  vmovaps xmm7, [rsp+0x70]
000070bab59e179c  vmovaps xmm8, [rsp+0x80]
000070bab59e17a5  vmovaps xmm9, [rsp+0x90]
000070bab59e17ae  vmovaps xmm10, [rsp+0xA0]
000070bab59e17b7  vmovaps xmm11, [rsp+0xB0]
000070bab59e17c0  vmovaps xmm12, [rsp+0xC0]
000070bab59e17c9  vmovaps xmm14, [rsp+0xD0]
000070bab59e17d2  vmovaps xmm15, [rsp+0xE0]
000070bab59e17db  add rsp, 0xF0
000070bab59e17e2  pop r11
000070bab59e17e4  pop r10
000070bab59e17e6  pop r9
000070bab59e17e8  pop r8
000070bab59e17ea  pop rsi
000070bab59e17eb  pop rdi
000070bab59e17ec  pop rdx
000070bab59e17ed  pop rcx
000070bab59e17ee  pop rax
000070bab59e17ef  add rsp, 0x08
000070bab59e17f3  jmp 0x000070BAB59DC820
000070bab59e17f8  sub rsp, 0x08
000070bab59e17fc  push rax
000070bab59e17fd  push rcx
000070bab59e17fe  push rdx
000070bab59e17ff  push rdi
000070bab59e1800  push rsi
000070bab59e1801  push r8
000070bab59e1803  push r9
000070bab59e1805  push r10
000070bab59e1807  push r11
000070bab59e1809  sub rsp, 0xF0
000070bab59e1810  vmovaps [rsp], xmm0
000070bab59e1815  vmovaps [rsp+0x10], xmm1
000070bab59e181b  vmovaps [rsp+0x20], xmm2
000070bab59e1821  vmovaps [rsp+0x30], xmm3
000070bab59e1827  vmovaps [rsp+0x40], xmm4
000070bab59e182d  vmovaps [rsp+0x50], xmm5
000070bab59e1833  vmovaps [rsp+0x60], xmm6
000070bab59e1839  vmovaps [rsp+0x70], xmm7
000070bab59e183f  vmovaps [rsp+0x80], xmm8
000070bab59e1848  vmovaps [rsp+0x90], xmm9
000070bab59e1851  vmovaps [rsp+0xA0], xmm10
000070bab59e185a  vmovaps [rsp+0xB0], xmm11
000070bab59e1863  vmovaps [rsp+0xC0], xmm12
000070bab59e186c  vmovaps [rsp+0xD0], xmm13
000070bab59e1875  vmovaps [rsp+0xE0], xmm15
000070bab59e187e  sub rsp, 0x30
000070bab59e1882  movaps [rsp], xmm14
000070bab59e1887  movaps [rsp+0x10], xmm1
000070bab59e188c  movaps [rsp+0x20], xmm7
000070bab59e1891  lea rdi, [rsp]
000070bab59e1895  mov esi, 0x00
000070bab59e189a  mov rax, 0x63B35AFBC530
000070bab59e18a4  call rax
000070bab59e18a6  movaps xmm14, [rsp]
000070bab59e18ab  add rsp, 0x30
000070bab59e18af  vmovaps xmm0, [rsp]
000070bab59e18b4  vmovaps xmm1, [rsp+0x10]
000070bab59e18ba  vmovaps xmm2, [rsp+0x20]
000070bab59e18c0  vmovaps xmm3, [rsp+0x30]
000070bab59e18c6  vmovaps xmm4, [rsp+0x40]
000070bab59e18cc  vmovaps xmm5, [rsp+0x50]
000070bab59e18d2  vmovaps xmm6, [rsp+0x60]
000070bab59e18d8  vmovaps xmm7, [rsp+0x70]
000070bab59e18de  vmovaps xmm8, [rsp+0x80]
000070bab59e18e7  vmovaps xmm9, [rsp+0x90]
000070bab59e18f0  vmovaps xmm10, [rsp+0xA0]
000070bab59e18f9  vmovaps xmm11, [rsp+0xB0]
000070bab59e1902  vmovaps xmm12, [rsp+0xC0]
000070bab59e190b  vmovaps xmm13, [rsp+0xD0]
000070bab59e1914  vmovaps xmm15, [rsp+0xE0]
000070bab59e191d  add rsp, 0xF0
000070bab59e1924  pop r11
000070bab59e1926  pop r10
000070bab59e1928  pop r9
000070bab59e192a  pop r8
000070bab59e192c  pop rsi
000070bab59e192d  pop rdi
000070bab59e192e  pop rdx
000070bab59e192f  pop rcx
000070bab59e1930  pop rax
000070bab59e1931  add rsp, 0x08
000070bab59e1935  jmp 0x000070BAB59DC843
000070bab59e193a  sub rsp, 0x08
000070bab59e193e  push rax
000070bab59e193f  push rcx
000070bab59e1940  push rdx
000070bab59e1941  push rdi
000070bab59e1942  push rsi
000070bab59e1943  push r8
000070bab59e1945  push r9
000070bab59e1947  push r10
000070bab59e1949  push r11
000070bab59e194b  sub rsp, 0xF0
000070bab59e1952  vmovaps [rsp], xmm0
000070bab59e1957  vmovaps [rsp+0x10], xmm2
000070bab59e195d  vmovaps [rsp+0x20], xmm3
000070bab59e1963  vmovaps [rsp+0x30], xmm4
000070bab59e1969  vmovaps [rsp+0x40], xmm5
000070bab59e196f  vmovaps [rsp+0x50], xmm6
000070bab59e1975  vmovaps [rsp+0x60], xmm7
000070bab59e197b  vmovaps [rsp+0x70], xmm8
000070bab59e1981  vmovaps [rsp+0x80], xmm9
000070bab59e198a  vmovaps [rsp+0x90], xmm10
000070bab59e1993  vmovaps [rsp+0xA0], xmm11
000070bab59e199c  vmovaps [rsp+0xB0], xmm12
000070bab59e19a5  vmovaps [rsp+0xC0], xmm13
000070bab59e19ae  vmovaps [rsp+0xD0], xmm14
000070bab59e19b7  vmovaps [rsp+0xE0], xmm15
000070bab59e19c0  sub rsp, 0x30
000070bab59e19c4  movaps [rsp], xmm1
000070bab59e19c8  movaps [rsp+0x10], xmm8
000070bab59e19ce  movaps [rsp+0x20], xmm9
000070bab59e19d4  lea rdi, [rsp]
000070bab59e19d8  mov esi, 0x00
000070bab59e19dd  mov rax, 0x63B35AFBC530
000070bab59e19e7  call rax
000070bab59e19e9  movaps xmm1, [rsp]
000070bab59e19ed  add rsp, 0x30
000070bab59e19f1  vmovaps xmm0, [rsp]
000070bab59e19f6  vmovaps xmm2, [rsp+0x10]
000070bab59e19fc  vmovaps xmm3, [rsp+0x20]
000070bab59e1a02  vmovaps xmm4, [rsp+0x30]
000070bab59e1a08  vmovaps xmm5, [rsp+0x40]
000070bab59e1a0e  vmovaps xmm6, [rsp+0x50]
000070bab59e1a14  vmovaps xmm7, [rsp+0x60]
000070bab59e1a1a  vmovaps xmm8, [rsp+0x70]
000070bab59e1a20  vmovaps xmm9, [rsp+0x80]
000070bab59e1a29  vmovaps xmm10, [rsp+0x90]
000070bab59e1a32  vmovaps xmm11, [rsp+0xA0]
000070bab59e1a3b  vmovaps xmm12, [rsp+0xB0]
000070bab59e1a44  vmovaps xmm13, [rsp+0xC0]
000070bab59e1a4d  vmovaps xmm14, [rsp+0xD0]
000070bab59e1a56  vmovaps xmm15, [rsp+0xE0]
000070bab59e1a5f  add rsp, 0xF0
000070bab59e1a66  pop r11
000070bab59e1a68  pop r10
000070bab59e1a6a  pop r9
000070bab59e1a6c  pop r8
000070bab59e1a6e  pop rsi
000070bab59e1a6f  pop rdi
000070bab59e1a70  pop rdx
000070bab59e1a71  pop rcx
000070bab59e1a72  pop rax
000070bab59e1a73  add rsp, 0x08
000070bab59e1a77  jmp 0x000070BAB59DC865
000070bab59e1a7c  call 0x000070BAB58E5940
000070bab59e1a81  jmp 0x000070BAB59DC873
000070bab59e1a86  call 0x000070BAB580C380
000070bab59e1a8b  jmp 0x000070BAB59DC87D
000070bab59e1a90  call 0x000070BAB580D600
000070bab59e1a95  jmp 0x000070BAB59DC887
000070bab59e1a9a  call 0x000070BAB57FF540
000070bab59e1a9f  jmp 0x000070BAB59DC891
000070bab59e1aa4  int3
000070bab59e1aa5  nop [rax+rax*1], ax
000070bab59e1aae  nop
000070bab59e1ab0  mov rax, [r15+0xF8]
000070bab59e1ab7  lea r14, [rax+0x140]
000070bab59e1abe  mov r12, [r13+r14*1]
000070bab59e1ac3  mov [r15+0xE8], r12
000070bab59e1aca  lea r14, [rax+0x130]
000070bab59e1ad1  mov r12, [r13+r14*1]
000070bab59e1ad6  lea r14, [rax+0x138]
000070bab59e1add  mov r11, [r13+r14*1]
000070bab59e1ae2  movq xmm1, r12
000070bab59e1ae7  movq xmm15, r11
000070bab59e1aec  movq xmm1, xmm1
000070bab59e1af0  movq xmm1, xmm1
000070bab59e1af4  movaps [r15+0x1A0], xmm1
000070bab59e1afc  movq xmm15, xmm15
000070bab59e1b01  movq xmm15, xmm15
000070bab59e1b06  movaps [r15+0x190], xmm15
000070bab59e1b0e  lea r14, [rax+0x120]
000070bab59e1b15  mov r12, [r13+r14*1]
000070bab59e1b1a  lea r14, [rax+0x128]
000070bab59e1b21  mov r11, [r13+r14*1]
000070bab59e1b26  movq xmm1, r12
000070bab59e1b2b  movq xmm15, r11
000070bab59e1b30  movq xmm1, xmm1
000070bab59e1b34  movq xmm1, xmm1
000070bab59e1b38  movaps [r15+0x1C0], xmm1
000070bab59e1b40  movq xmm15, xmm15
000070bab59e1b45  movq xmm15, xmm15
000070bab59e1b4a  movaps [r15+0x1B0], xmm15
000070bab59e1b52  lea r14, [rax+0x110]
000070bab59e1b59  mov r12, [r13+r14*1]
000070bab59e1b5e  lea r14, [rax+0x118]
000070bab59e1b65  mov r11, [r13+r14*1]
000070bab59e1b6a  movq xmm1, r12
000070bab59e1b6f  movq xmm15, r11
000070bab59e1b74  movq xmm1, xmm1
000070bab59e1b78  movq xmm1, xmm1
000070bab59e1b7c  movaps [r15+0x1E0], xmm1
000070bab59e1b84  movq xmm15, xmm15
000070bab59e1b89  movq xmm15, xmm15
000070bab59e1b8e  movaps [r15+0x1D0], xmm15
000070bab59e1b96  lea r14, [rax+0x100]
000070bab59e1b9d  mov r12, [r13+r14*1]
000070bab59e1ba2  lea r14, [rax+0x108]
000070bab59e1ba9  mov r11, [r13+r14*1]
000070bab59e1bae  movq xmm1, r12
000070bab59e1bb3  movq xmm15, r11
000070bab59e1bb8  movq xmm1, xmm1
000070bab59e1bbc  movq xmm1, xmm1
000070bab59e1bc0  movaps [r15+0x200], xmm1
000070bab59e1bc8  movq xmm15, xmm15
000070bab59e1bcd  movq xmm15, xmm15
000070bab59e1bd2  movaps [r15+0x1F0], xmm15
000070bab59e1bda  mov qword ptr [r15+0x40], 0x430000
000070bab59e1be2  mov r14d, 0x430510
000070bab59e1be8  mov r12, [r13+r14*1]
000070bab59e1bed  movq xmm1, r12
000070bab59e1bf2  lea r14, [rax+0x150]
000070bab59e1bf9  mov [r15+0xF8], r14
000070bab59e1c00  mov rax, [r15+0x50]
000070bab59e1c04  movups xmm15, [r13+rax*1]
000070bab59e1c0a  movaps [r15+0x120], xmm15
000070bab59e1c12  mov qword ptr [r15+0x48], 0x10
000070bab59e1c1a  xor eax, eax
000070bab59e1c1c  mov r14d, 0x10
000070bab59e1c22  mov r12d, 0x200
000070bab59e1c28  cmp r14, r12
000070bab59e1c2b  cmc
000070bab59e1c2c  lahf
000070bab59e1c2d  seto al
000070bab59e1c30  mov [r15+0x108], eax
000070bab59e1c37  pextrq rax, xmm15, 0x01
000070bab59e1c3e  movq xmm14, rax
000070bab59e1c43  movaps [r15+0x130], xmm14
000070bab59e1c4b  movq rax, xmm1
000070bab59e1c50  movq r14, xmm15
000070bab59e1c55  vmovq xmm1, rax
000070bab59e1c5a  vmovq xmm15, r14
000070bab59e1c5f  movaps xmm13, xmm1
000070bab59e1c63  addsd xmm13, xmm15
000070bab59e1c68  ucomisd xmm13, xmm13
000070bab59e1c6d  jp 0x000070BAB59E1D86
000070bab59e1c73  movq xmm13, xmm13
000070bab59e1c78  movq rax, xmm13
000070bab59e1c7d  movq r14, xmm14
000070bab59e1c82  vmovq xmm1, rax
000070bab59e1c87  vmovq xmm15, r14
000070bab59e1c8c  movaps xmm14, xmm1
000070bab59e1c90  addsd xmm14, xmm15
000070bab59e1c95  ucomisd xmm14, xmm14
000070bab59e1c9a  jp 0x000070BAB59E1DCE
000070bab59e1ca0  movq xmm14, xmm14
000070bab59e1ca5  movaps [r15+0x110], xmm14
000070bab59e1cad  mov eax, [r15+0x108]
000070bab59e1cb4  sahf
000070bab59e1cb5  jnz 0x000070BAB59E1CE7
000070bab59e1cb7  cmp dword ptr [r15+0x318], 0x00
000070bab59e1cbf  jz 0x000070BAB59E1FE0
000070bab59e1cc5  nop [rax+rax*1], ax
000070bab59e1cce  nop [rax+rax*1], eax
000070bab59e1cd6  mov eax, 0x410490
000070bab59e1cdb  mov [r15+0x100], rax
000070bab59e1ce2  jmp 0x000070BAB57FE110
000070bab59e1ce7  cmp dword ptr [r15+0x318], 0x00
000070bab59e1cef  jz 0x000070BAB59E1E20
000070bab59e1cf5  nop [rax+rax*1], ax
000070bab59e1cfe  nop [rax+rax*1], eax
000070bab59e1d06  mov eax, 0x410474
000070bab59e1d0b  mov [r15+0x100], rax
000070bab59e1d12  jmp 0x000070BAB57FE110
000070bab59e1d17  int3
000070bab59e1d18  call 0x000070BAB58E27E0
000070bab59e1d1d  jmp 0x000070BAB59E1AC3
000070bab59e1d22  call 0x000070BAB58E27E0
000070bab59e1d27  jmp 0x000070BAB59E1AD6
000070bab59e1d2c  call 0x000070BAB58E1570
000070bab59e1d31  jmp 0x000070BAB59E1AE2
000070bab59e1d36  call 0x000070BAB58E27E0
000070bab59e1d3b  jmp 0x000070BAB59E1B1A
000070bab59e1d40  call 0x000070BAB58E1570
000070bab59e1d45  jmp 0x000070BAB59E1B26
000070bab59e1d4a  call 0x000070BAB58E27E0
000070bab59e1d4f  jmp 0x000070BAB59E1B5E
000070bab59e1d54  call 0x000070BAB58E1570
000070bab59e1d59  jmp 0x000070BAB59E1B6A
000070bab59e1d5e  call 0x000070BAB58E27E0
000070bab59e1d63  jmp 0x000070BAB59E1BA2
000070bab59e1d68  call 0x000070BAB58E1570
000070bab59e1d6d  jmp 0x000070BAB59E1BAE
000070bab59e1d72  call 0x000070BAB58E27E0
000070bab59e1d77  jmp 0x000070BAB59E1BED
000070bab59e1d7c  call 0x000070BAB580E760
000070bab59e1d81  jmp 0x000070BAB59E1C0A
000070bab59e1d86  ucomisd xmm1, xmm15
000070bab59e1d8b  jp 0x000070BAB59E1D9A
000070bab59e1d8d  movaps xmm13, [0x000070BAB55FE060]
000070bab59e1d95  jmp 0x000070BAB59E1C73
000070bab59e1d9a  vxorps xmm0, xmm1, xmm15
000070bab59e1d9f  pextrw eax, xmm0, 0x03
000070bab59e1da4  and eax, 0x7FF8
000070bab59e1da9  cmp eax, 0x08
000070bab59e1dac  jnz 0x000070BAB59E1C73
000070bab59e1db2  movq rax, xmm15
000070bab59e1db7  shl rax, 0x0D
000070bab59e1dbb  jbe 0x000070BAB59E1C73
000070bab59e1dc1  vorps xmm13, xmm15, [0x000070BAB55FE070]
000070bab59e1dc9  jmp 0x000070BAB59E1C73
000070bab59e1dce  ucomisd xmm1, xmm15
000070bab59e1dd3  jp 0x000070BAB59E1DE2
000070bab59e1dd5  movaps xmm14, [0x000070BAB55FE060]
000070bab59e1ddd  jmp 0x000070BAB59E1CA0
000070bab59e1de2  vxorps xmm0, xmm1, xmm15
000070bab59e1de7  pextrw eax, xmm0, 0x03
000070bab59e1dec  and eax, 0x7FF8
000070bab59e1df1  cmp eax, 0x08
000070bab59e1df4  jnz 0x000070BAB59E1CA0
000070bab59e1dfa  movq rax, xmm15
000070bab59e1dff  shl rax, 0x0D
000070bab59e1e03  jbe 0x000070BAB59E1CA0
000070bab59e1e09  vorps xmm14, xmm15, [0x000070BAB55FE070]
000070bab59e1e11  jmp 0x000070BAB59E1CA0
000070bab59e1e16  int3
000070bab59e1e17  nop [rax+rax*1], ax
000070bab59e1e20  mov rax, [r15+0x48]
000070bab59e1e24  mov r14, [r15+0x50]
000070bab59e1e28  lea r12, [r14+rax*1]
000070bab59e1e2c  movups xmm1, [r13+r12*1]
000070bab59e1e32  movaps [r15+0x120], xmm1
000070bab59e1e3a  lea r14, [rax+0x10]
000070bab59e1e3e  mov [r15+0x48], r14
000070bab59e1e42  xor eax, eax
000070bab59e1e44  mov r12d, 0x200
000070bab59e1e4a  cmp r14, r12
000070bab59e1e4d  cmc
000070bab59e1e4e  lahf
000070bab59e1e4f  seto al
000070bab59e1e52  mov [r15+0x108], eax
000070bab59e1e59  pextrq rax, xmm1, 0x01
000070bab59e1e60  movq xmm15, rax
000070bab59e1e65  movaps [r15+0x130], xmm15
000070bab59e1e6d  movaps xmm14, [r15+0x110]
000070bab59e1e75  movq rax, xmm14
000070bab59e1e7a  movq r14, xmm1
000070bab59e1e7f  vmovq xmm1, rax
000070bab59e1e84  vmovq xmm14, r14
000070bab59e1e89  movaps xmm13, xmm1
000070bab59e1e8d  addsd xmm13, xmm14
000070bab59e1e92  ucomisd xmm13, xmm13
000070bab59e1e97  jp 0x000070BAB59E1F4C
000070bab59e1e9d  movq xmm13, xmm13
000070bab59e1ea2  movq rax, xmm13
000070bab59e1ea7  movq r14, xmm15
000070bab59e1eac  vmovq xmm1, rax
000070bab59e1eb1  vmovq xmm15, r14
000070bab59e1eb6  movaps xmm14, xmm1
000070bab59e1eba  addsd xmm14, xmm15
000070bab59e1ebf  ucomisd xmm14, xmm14
000070bab59e1ec4  jp 0x000070BAB59E1F94
000070bab59e1eca  movq xmm14, xmm14
000070bab59e1ecf  movaps [r15+0x110], xmm14
000070bab59e1ed7  mov eax, [r15+0x108]
000070bab59e1ede  sahf
000070bab59e1edf  jnz 0x000070BAB59E1F11
000070bab59e1ee1  cmp dword ptr [r15+0x318], 0x00
000070bab59e1ee9  jz 0x000070BAB59E1FE0
000070bab59e1eef  nop [rax+rax*1], ax
000070bab59e1ef8  nop [rax+rax*1], eax
000070bab59e1f00  mov eax, 0x410490
000070bab59e1f05  mov [r15+0x100], rax
000070bab59e1f0c  jmp 0x000070BAB57FE110
000070bab59e1f11  cmp dword ptr [r15+0x318], 0x00
000070bab59e1f19  jz 0x000070BAB59E1E20
000070bab59e1f1f  nop [rax+rax*1], ax
000070bab59e1f28  nop [rax+rax*1], eax
000070bab59e1f30  mov eax, 0x410474
000070bab59e1f35  mov [r15+0x100], rax
000070bab59e1f3c  jmp 0x000070BAB57FE110
000070bab59e1f41  int3
000070bab59e1f42  call 0x000070BAB58B52F0
000070bab59e1f47  jmp 0x000070BAB59E1E32
000070bab59e1f4c  ucomisd xmm1, xmm14
000070bab59e1f51  jp 0x000070BAB59E1F60
000070bab59e1f53  movaps xmm13, [0x000070BAB55FE060]
000070bab59e1f5b  jmp 0x000070BAB59E1E9D
000070bab59e1f60  vxorps xmm0, xmm1, xmm14
000070bab59e1f65  pextrw eax, xmm0, 0x03
000070bab59e1f6a  and eax, 0x7FF8
000070bab59e1f6f  cmp eax, 0x08
000070bab59e1f72  jnz 0x000070BAB59E1E9D
000070bab59e1f78  movq rax, xmm14
000070bab59e1f7d  shl rax, 0x0D
000070bab59e1f81  jbe 0x000070BAB59E1E9D
000070bab59e1f87  vorps xmm13, xmm14, [0x000070BAB55FE070]
000070bab59e1f8f  jmp 0x000070BAB59E1E9D
000070bab59e1f94  ucomisd xmm1, xmm15
000070bab59e1f99  jp 0x000070BAB59E1FA8
000070bab59e1f9b  movaps xmm14, [0x000070BAB55FE060]
000070bab59e1fa3  jmp 0x000070BAB59E1ECA
000070bab59e1fa8  vxorps xmm0, xmm1, xmm15
000070bab59e1fad  pextrw eax, xmm0, 0x03
000070bab59e1fb2  and eax, 0x7FF8
000070bab59e1fb7  cmp eax, 0x08
000070bab59e1fba  jnz 0x000070BAB59E1ECA
000070bab59e1fc0  movq rax, xmm15
000070bab59e1fc5  shl rax, 0x0D
000070bab59e1fc9  jbe 0x000070BAB59E1ECA
000070bab59e1fcf  vorps xmm14, xmm15, [0x000070BAB55FE070]
000070bab59e1fd7  jmp 0x000070BAB59E1ECA
000070bab59e1fdc  int3
000070bab59e1fdd  nop [rax], eax
000070bab59e1fe0  mov rax, [r15+0x40]
000070bab59e1fe4  lea r14, [rax+0x510]
000070bab59e1feb  movaps xmm1, [r15+0x110]
000070bab59e1ff3  movq rax, xmm1
000070bab59e1ff8  mov [r13+r14*1], rax
000070bab59e1ffd  mov rax, [r15+0xF0]
000070bab59e2004  mov [r15+0x100], rax
000070bab59e200b  jmp 0x000070BAB59CE5C0
000070bab59e2010  int3
000070bab59e2011  call 0x000070BAB58D5EB0
000070bab59e2016  jmp 0x000070BAB59E1FFD
000070bab59e201b  int3
000070bab59e201c  nop [rax], eax
000070bab59e2020  mov qword ptr [r15+0x100], 0x04
000070bab59e202b  mov esi, 0x00
000070bab59e2030  mov edx, 0x09
000070bab59e2035  mov rdi, 0x7FFE8FB57120
000070bab59e203f  mov rax, 0x63B35AE4F970
000070bab59e2049  call rax
000070bab59e204b  cmp dword ptr [r15+0x318], 0x00
000070bab59e2053  jnz 0x000070BAB57FE110
000070bab59e2059  jmp 0x000070BAB57FE0A0
000070bab59e205e  int3
000070bab59e205f  int3
