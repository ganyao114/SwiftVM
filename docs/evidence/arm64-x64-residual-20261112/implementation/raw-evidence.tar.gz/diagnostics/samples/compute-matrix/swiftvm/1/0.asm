
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute-matrix/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

000072e311b00000 <.data>:
    72e311b00000:	sub    rsp,0x150
    72e311b00007:	mov    r11,QWORD PTR [r12+0x398]
    72e311b0000f:	mov    QWORD PTR [rsp],r11
    72e311b00013:	cmp    DWORD PTR [r12+0x310],0x0
    72e311b0001c:	je     0x72e311b000a7
    72e311b00022:	push   rdx
    72e311b00023:	push   rsi
    72e311b00024:	push   r10
    72e311b00026:	push   r11
    72e311b00028:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b0002d:	mov    r10d,edx
    72e311b00030:	and    r10d,0xc000
    72e311b00037:	shl    r10d,0x10
    72e311b0003b:	mov    r11d,edx
    72e311b0003e:	and    r11d,0x100
    72e311b00045:	shl    r11d,0x15
    72e311b00049:	or     r10d,r11d
    72e311b0004c:	and    edx,0x1
    72e311b0004f:	shl    edx,0x1c
    72e311b00052:	or     r10d,edx
    72e311b00055:	btc    r10,0x1d
    72e311b0005a:	mov    r11d,0xf0000000
    72e311b00060:	and    r11,r10
    72e311b00063:	movabs rsi,0xffffffff0fffffff
    72e311b0006d:	and    rbx,rsi
    72e311b00070:	or     rbx,r11
    72e311b00073:	pop    r11
    72e311b00075:	pop    r10
    72e311b00077:	pop    rsi
    72e311b00078:	pop    rdx
    72e311b00079:	mov    QWORD PTR [r12+0x108],rbx
    72e311b00081:	mov    eax,0x410168
    72e311b00086:	mov    QWORD PTR [r12+0x100],rax
    72e311b0008e:	add    rsp,0x150
    72e311b00095:	mov    eax,0x3
    72e311b0009a:	movabs r11,0x62e306617ca0
    72e311b000a4:	jmp    r11
    72e311b000a7:	mov    r13d,0x420000
    72e311b000ad:	mov    QWORD PTR [r12+0x40],r13
    72e311b000b2:	movabs r13,0x100000001
    72e311b000bc:	mov    r14d,0x0
    72e311b000c2:	mov    QWORD PTR [r12+0x110],r13
    72e311b000ca:	mov    QWORD PTR [r12+0x118],r14
    72e311b000d2:	movabs r13,0x3fa0000000000000
    72e311b000dc:	mov    QWORD PTR [r12+0x50],r13
    72e311b000e1:	movabs r13,0x4100000041
    72e311b000eb:	mov    r14d,0x0
    72e311b000f1:	mov    QWORD PTR [r12+0x120],r13
    72e311b000f9:	mov    QWORD PTR [r12+0x128],r14
    72e311b00101:	mov    r13d,0x4204c0
    72e311b00107:	mov    r14,QWORD PTR [r13+0x0]
    72e311b0010b:	mov    r13d,0x0
    72e311b00111:	mov    QWORD PTR [r12+0x130],r14
    72e311b00119:	mov    QWORD PTR [r12+0x138],r13
    72e311b00121:	movabs r13,0x3fc0000000000000
    72e311b0012b:	movabs r14,0x3fc0000000000000
    72e311b00135:	mov    QWORD PTR [r12+0x140],r13
    72e311b0013d:	mov    QWORD PTR [r12+0x148],r14
    72e311b00145:	mov    r13d,0x2
    72e311b0014b:	mov    QWORD PTR [r12+0x40],r13
    72e311b00150:	movabs r13,0x200000002
    72e311b0015a:	mov    r14d,0x0
    72e311b00160:	mov    QWORD PTR [r12+0x150],r13
    72e311b00168:	mov    QWORD PTR [r12+0x158],r14
    72e311b00170:	mov    r13d,0x420000
    72e311b00176:	mov    QWORD PTR [r12+0x58],r13
    72e311b0017b:	movabs r13,0x3fa0000000000000
    72e311b00185:	mov    QWORD PTR [r12+0x160],r13
    72e311b0018d:	mov    QWORD PTR [r12+0x168],r13
    72e311b00195:	mov    r13d,0x2
    72e311b0019b:	mov    QWORD PTR [r12+0x170],r13
    72e311b001a3:	mov    QWORD PTR [r12+0x178],r13
    72e311b001ab:	mov    r13d,0x4204d0
    72e311b001b1:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    72e311b001b7:	movdqu XMMWORD PTR [r12+0x180],xmm2
    72e311b001c1:	mov    r13d,0x0
    72e311b001c7:	mov    QWORD PTR [r12+0x48],r13
    72e311b001cc:	mov    r13d,0x430000
    72e311b001d2:	add    r13,0x518
    72e311b001d9:	mov    QWORD PTR [r12+0x40],r13
    72e311b001de:	mov    r13d,0x430000
    72e311b001e4:	add    r13,0x720
    72e311b001eb:	mov    QWORD PTR [r12+0x50],r13
    72e311b001f0:	mov    r11,rax
    72e311b001f3:	movzx  eax,WORD PTR [rsp]
    72e311b001f7:	add    al,0x7f
    72e311b001f9:	sahf
    72e311b001fa:	mov    rax,r11
    72e311b001fd:	jmp    0x72e311b00202
    72e311b00202:	mov    r13,QWORD PTR [r12+0x180]
    72e311b0020a:	mov    r14,QWORD PTR [r12+0x188]
    72e311b00212:	mov    r15d,0x0
    72e311b00218:	mov    r11,rax
    72e311b0021b:	lahf
    72e311b0021c:	seto   al
    72e311b0021f:	mov    WORD PTR [rsp],ax
    72e311b00223:	mov    rax,r11
    72e311b00226:	mov    ecx,0xffffffff
    72e311b0022b:	and    r13,rcx
    72e311b0022e:	mov    rbp,r15
    72e311b00231:	or     rbp,r13
    72e311b00234:	mov    ecx,0xffffffff
    72e311b00239:	and    r14,rcx
    72e311b0023c:	shl    r14,0x20
    72e311b00240:	or     rbp,r14
    72e311b00243:	mov    QWORD PTR [r12+0x210],rbp
    72e311b0024b:	mov    QWORD PTR [r12+0x218],r15
    72e311b00253:	movdqu xmm2,XMMWORD PTR [r12+0x120]
    72e311b0025d:	movdqu xmm3,XMMWORD PTR [r12+0x130]
    72e311b00267:	movdqa xmm1,xmm3
    72e311b0026b:	psubd  xmm2,xmm1
    72e311b0026f:	movdqa xmm14,xmm2
    72e311b00274:	movdqa xmm1,xmm14
    72e311b00279:	movq   rax,xmm1
    72e311b0027e:	mov    r13,rax
    72e311b00281:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    72e311b0028b:	movdqu xmm4,XMMWORD PTR [r12+0x170]
    72e311b00295:	movdqa xmm1,xmm4
    72e311b00299:	paddq  xmm2,xmm1
    72e311b0029d:	movdqu XMMWORD PTR [r12+0x180],xmm2
    72e311b002a7:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    72e311b002b1:	movdqa xmm1,xmm2
    72e311b002b5:	paddd  xmm3,xmm1
    72e311b002b9:	movdqa xmm14,xmm3
    72e311b002be:	movdqa xmm1,xmm14
    72e311b002c3:	movq   rax,xmm1
    72e311b002c8:	mov    r14,rax
    72e311b002cb:	mov    r15d,0x0
    72e311b002d1:	mov    QWORD PTR [r12+0x130],r14
    72e311b002d9:	mov    QWORD PTR [r12+0x138],r15
    72e311b002e1:	mov    r14d,0x0
    72e311b002e7:	mov    ecx,0xffffffff
    72e311b002ec:	mov    r15,r13
    72e311b002ef:	and    r15,rcx
    72e311b002f2:	mov    rbp,r14
    72e311b002f5:	or     rbp,r15
    72e311b002f8:	shr    r13,0x20
    72e311b002fc:	mov    ecx,0xffffffff
    72e311b00301:	and    r13,rcx
    72e311b00304:	or     r14,r13
    72e311b00307:	mov    QWORD PTR [r12+0x220],rbp
    72e311b0030f:	mov    QWORD PTR [r12+0x228],r14
    72e311b00317:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    72e311b00321:	movdqu xmm3,XMMWORD PTR [r12+0x110]
    72e311b0032b:	movdqa xmm1,xmm3
    72e311b0032f:	paddd  xmm2,xmm1
    72e311b00333:	movdqa xmm14,xmm2
    72e311b00338:	movdqa xmm1,xmm14
    72e311b0033d:	movq   rax,xmm1
    72e311b00342:	mov    r13,rax
    72e311b00345:	mov    r14d,0x0
    72e311b0034b:	mov    QWORD PTR [r12+0x210],r13
    72e311b00353:	mov    QWORD PTR [r12+0x218],r14
    72e311b0035b:	lea    r13,[r12]
    72e311b0035f:	movabs r14,0xb6e61da31
    72e311b00369:	mov    r15d,0x4101c4
    72e311b0036f:	mov    rdx,QWORD PTR [rsp]
    72e311b00373:	mov    r10d,edx
    72e311b00376:	and    r10d,0xc000
    72e311b0037d:	shl    r10d,0x10
    72e311b00381:	mov    r11d,edx
    72e311b00384:	and    r11d,0x100
    72e311b0038b:	shl    r11d,0x15
    72e311b0038f:	or     r10d,r11d
    72e311b00392:	and    edx,0x1
    72e311b00395:	shl    edx,0x1c
    72e311b00398:	or     r10d,edx
    72e311b0039b:	btc    r10,0x1d
    72e311b003a0:	mov    r11d,0xf0000000
    72e311b003a6:	and    r11,r10
    72e311b003a9:	movabs rsi,0xffffffff0fffffff
    72e311b003b3:	and    rbx,rsi
    72e311b003b6:	or     rbx,r11
    72e311b003b9:	mov    QWORD PTR [r12+0x378],0x3
    72e311b003c5:	mov    QWORD PTR [r12+0x108],rbx
    72e311b003cd:	stmxcsr DWORD PTR [r12-0x28]
    72e311b003d3:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b003d8:	test   r10d,0x3f
    72e311b003df:	je     0x72e311b00404
    72e311b003e5:	mov    r11d,r10d
    72e311b003e8:	shr    r10d,1
    72e311b003eb:	and    r10d,0x1e
    72e311b003ef:	and    r11d,0x1
    72e311b003f3:	or     r10d,r11d
    72e311b003f6:	or     DWORD PTR [r12+0x314],r10d
    72e311b003fe:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b00404:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b0040a:	movabs r11,0x62e3064795e0
    72e311b00414:	mov    rdi,r13
    72e311b00417:	mov    rsi,r14
    72e311b0041a:	mov    rdx,r15
    72e311b0041d:	call   r11
    72e311b00420:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b00426:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0042e:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0043a:	mov    rbp,rax
    72e311b0043d:	mov    r13,QWORD PTR [r12+0x210]
    72e311b00445:	mov    r14d,0x0
    72e311b0044b:	mov    ecx,0xffffffff
    72e311b00450:	mov    r15,r13
    72e311b00453:	and    r15,rcx
    72e311b00456:	mov    rbp,r14
    72e311b00459:	or     rbp,r15
    72e311b0045c:	shr    r13,0x20
    72e311b00460:	mov    ecx,0xffffffff
    72e311b00465:	and    r13,rcx
    72e311b00468:	or     r14,r13
    72e311b0046b:	mov    QWORD PTR [r12+0x210],rbp
    72e311b00473:	mov    QWORD PTR [r12+0x218],r14
    72e311b0047b:	lea    r13,[r12]
    72e311b0047f:	movabs r14,0xb6e61da10
    72e311b00489:	mov    r15d,0x4101cc
    72e311b0048f:	mov    QWORD PTR [r12+0x378],0x3
    72e311b0049b:	mov    QWORD PTR [r12+0x108],rbx
    72e311b004a3:	stmxcsr DWORD PTR [r12-0x28]
    72e311b004a9:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b004ae:	test   r10d,0x3f
    72e311b004b5:	je     0x72e311b004da
    72e311b004bb:	mov    r11d,r10d
    72e311b004be:	shr    r10d,1
    72e311b004c1:	and    r10d,0x1e
    72e311b004c5:	and    r11d,0x1
    72e311b004c9:	or     r10d,r11d
    72e311b004cc:	or     DWORD PTR [r12+0x314],r10d
    72e311b004d4:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b004da:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b004e0:	movabs r11,0x62e3064795e0
    72e311b004ea:	mov    rdi,r13
    72e311b004ed:	mov    rsi,r14
    72e311b004f0:	mov    rdx,r15
    72e311b004f3:	call   r11
    72e311b004f6:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b004fc:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b00504:	mov    QWORD PTR [r12+0x378],0x2
    72e311b00510:	mov    rbp,rax
    72e311b00513:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    72e311b0051d:	movdqu xmm3,XMMWORD PTR [r12+0x140]
    72e311b00527:	movdqa xmm0,xmm2
    72e311b0052b:	movdqa xmm1,xmm3
    72e311b0052f:	mulpd  xmm0,xmm1
    72e311b00533:	movdqa xmm14,xmm0
    72e311b00538:	movdqu xmm15,XMMWORD PTR [rip+0x9d4f]        # 0x72e311b0a290
    72e311b00541:	pand   xmm14,xmm15
    72e311b00546:	movdqu xmm15,XMMWORD PTR [rip+0x9d51]        # 0x72e311b0a2a0
    72e311b0054f:	pcmpeqq xmm14,xmm15
    72e311b00555:	movdqa xmm15,xmm0
    72e311b0055a:	cmpunordpd xmm15,xmm0
    72e311b00560:	por    xmm14,xmm15
    72e311b00565:	pmovmskb ecx,xmm14
    72e311b0056a:	jrcxz  0x72e311b00571
    72e311b0056c:	jmp    0x72e311b02bee
    72e311b00571:	movdqa xmm4,xmm0
    72e311b00575:	movdqu XMMWORD PTR [r12+0x220],xmm4
    72e311b0057f:	mov    r13,QWORD PTR [r12+0x48]
    72e311b00584:	mov    r14,QWORD PTR [r12+0x50]
    72e311b00589:	add    r14,r13
    72e311b0058c:	movdqu XMMWORD PTR [r14],xmm4
    72e311b00591:	mov    r14d,0x0
    72e311b00597:	mov    DWORD PTR [r12+0x32c],r14d
    72e311b0059f:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    72e311b005a9:	movdqu xmm3,XMMWORD PTR [r12+0x160]
    72e311b005b3:	movdqa xmm0,xmm2
    72e311b005b7:	movdqa xmm1,xmm3
    72e311b005bb:	mulpd  xmm0,xmm1
    72e311b005bf:	movdqa xmm14,xmm0
    72e311b005c4:	movdqu xmm15,XMMWORD PTR [rip+0x9cc3]        # 0x72e311b0a290
    72e311b005cd:	pand   xmm14,xmm15
    72e311b005d2:	movdqu xmm15,XMMWORD PTR [rip+0x9cc5]        # 0x72e311b0a2a0
    72e311b005db:	pcmpeqq xmm14,xmm15
    72e311b005e1:	movdqa xmm15,xmm0
    72e311b005e6:	cmpunordpd xmm15,xmm0
    72e311b005ec:	por    xmm14,xmm15
    72e311b005f1:	pmovmskb ecx,xmm14
    72e311b005f6:	jrcxz  0x72e311b005fd
    72e311b005f8:	jmp    0x72e311b02c12
    72e311b005fd:	movdqa xmm4,xmm0
    72e311b00601:	movdqu XMMWORD PTR [r12+0x210],xmm4
    72e311b0060b:	mov    r14,QWORD PTR [r12+0x40]
    72e311b00610:	add    r14,r13
    72e311b00613:	movdqu XMMWORD PTR [r14],xmm4
    72e311b00618:	add    r13,0x10
    72e311b0061c:	mov    QWORD PTR [r12+0x48],r13
    72e311b00621:	sub    r13,0x200
    72e311b00628:	mov    rcx,QWORD PTR [r12+0x380]
    72e311b00630:	jrcxz  0x72e311b00637
    72e311b00632:	jmp    0x72e311b09a25
    72e311b00637:	jne    0x72e311b00202
    72e311b0063d:	mov    r11,rax
    72e311b00640:	lahf
    72e311b00641:	seto   al
    72e311b00644:	mov    WORD PTR [rsp],ax
    72e311b00648:	mov    rax,r11
    72e311b0064b:	jmp    0x72e311b00650
    72e311b00650:	mov    r13,QWORD PTR [r12+0xf8]
    72e311b00658:	sub    r13,0x150
    72e311b0065f:	mov    QWORD PTR [r12+0xf8],r13
    72e311b00667:	mov    r14,QWORD PTR [r12+0x50]
    72e311b0066c:	mov    r15,r14
    72e311b0066f:	add    r15,0x80
    72e311b00676:	mov    rbp,r15
    72e311b00679:	add    rbp,0x10
    72e311b0067d:	movdqu xmm2,XMMWORD PTR [r15]
    72e311b00682:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72e311b00687:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72e311b00691:	movdqu XMMWORD PTR [r12+0x110],xmm3
    72e311b0069b:	mov    r15d,0x0
    72e311b006a1:	mov    QWORD PTR [r12+0x48],r15
    72e311b006a6:	mov    r15,r14
    72e311b006a9:	add    r15,0x40
    72e311b006ad:	mov    rbp,r15
    72e311b006b0:	add    rbp,0x10
    72e311b006b4:	movdqu xmm4,XMMWORD PTR [r15]
    72e311b006b9:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    72e311b006be:	movdqu XMMWORD PTR [r12+0x250],xmm4
    72e311b006c8:	movdqu XMMWORD PTR [r12+0x120],xmm5
    72e311b006d2:	mov    r15,r13
    72e311b006d5:	add    r15,0x120
    72e311b006dc:	mov    rbp,r15
    72e311b006df:	add    rbp,0x8
    72e311b006e3:	mov    r8,QWORD PTR [r12+0x1c0]
    72e311b006eb:	mov    r9,QWORD PTR [r12+0x1b0]
    72e311b006f3:	mov    QWORD PTR [r15],r8
    72e311b006f6:	mov    r15d,0x0
    72e311b006fc:	mov    DWORD PTR [r12+0x32c],r15d
    72e311b00704:	mov    QWORD PTR [rbp+0x0],r9
    72e311b00708:	mov    r15d,0x0
    72e311b0070e:	mov    ebp,0x0
    72e311b00713:	mov    QWORD PTR [r12+0x1b0],r15
    72e311b0071b:	mov    QWORD PTR [r12+0x1b8],rbp
    72e311b00723:	mov    r15,r13
    72e311b00726:	add    r15,0x100
    72e311b0072d:	mov    rbp,r15
    72e311b00730:	add    rbp,0x8
    72e311b00734:	mov    r8,QWORD PTR [r12+0x200]
    72e311b0073c:	mov    r9,QWORD PTR [r12+0x1f0]
    72e311b00744:	mov    QWORD PTR [r15],r8
    72e311b00747:	mov    QWORD PTR [rbp+0x0],r9
    72e311b0074b:	mov    r15,r13
    72e311b0074e:	add    r15,0xe0
    72e311b00755:	mov    rbp,r15
    72e311b00758:	add    rbp,0x10
    72e311b0075c:	movdqu XMMWORD PTR [r15],xmm3
    72e311b00761:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72e311b00766:	mov    r15,r14
    72e311b00769:	add    r15,0xc0
    72e311b00770:	mov    rbp,r15
    72e311b00773:	add    rbp,0x10
    72e311b00777:	movdqu xmm2,XMMWORD PTR [r15]
    72e311b0077c:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72e311b00781:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72e311b0078b:	movdqu XMMWORD PTR [r12+0x110],xmm3
    72e311b00795:	mov    r15,r13
    72e311b00798:	add    r15,0x110
    72e311b0079f:	mov    rbp,r15
    72e311b007a2:	add    rbp,0x8
    72e311b007a6:	mov    r8,QWORD PTR [r12+0x1e0]
    72e311b007ae:	mov    r9,QWORD PTR [r12+0x1d0]
    72e311b007b6:	mov    QWORD PTR [r15],r8
    72e311b007b9:	mov    QWORD PTR [rbp+0x0],r9
    72e311b007bd:	mov    r15,r14
    72e311b007c0:	add    r15,0x10
    72e311b007c4:	movdqu xmm4,XMMWORD PTR [r14]
    72e311b007c9:	movdqu xmm6,XMMWORD PTR [r15]
    72e311b007ce:	movdqu XMMWORD PTR [r12+0x170],xmm4
    72e311b007d8:	movdqu XMMWORD PTR [r12+0x180],xmm6
    72e311b007e2:	mov    r15,r13
    72e311b007e5:	add    r15,0x130
    72e311b007ec:	mov    rbp,r15
    72e311b007ef:	add    rbp,0x8
    72e311b007f3:	mov    r8,QWORD PTR [r12+0x1a0]
    72e311b007fb:	mov    r9,QWORD PTR [r12+0x190]
    72e311b00803:	mov    QWORD PTR [r15],r8
    72e311b00806:	mov    QWORD PTR [rbp+0x0],r9
    72e311b0080a:	mov    r15,r14
    72e311b0080d:	add    r15,0x140
    72e311b00814:	mov    rbp,r15
    72e311b00817:	add    rbp,0x10
    72e311b0081b:	movdqu xmm7,XMMWORD PTR [r15]
    72e311b00820:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    72e311b00826:	movdqu XMMWORD PTR [r12+0x270],xmm7
    72e311b00830:	movdqu XMMWORD PTR [r12+0x190],xmm8
    72e311b0083a:	mov    r15,r13
    72e311b0083d:	add    r15,0xc0
    72e311b00844:	mov    rbp,r15
    72e311b00847:	add    rbp,0x10
    72e311b0084b:	movdqu XMMWORD PTR [r15],xmm3
    72e311b00850:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72e311b00855:	mov    r15,r14
    72e311b00858:	add    r15,0x100
    72e311b0085f:	mov    rbp,r15
    72e311b00862:	add    rbp,0x10
    72e311b00866:	movdqu xmm2,XMMWORD PTR [r15]
    72e311b0086b:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72e311b00870:	movdqu XMMWORD PTR [r12+0x110],xmm2
    72e311b0087a:	movdqu XMMWORD PTR [r12+0x300],xmm3
    72e311b00884:	mov    r15,r13
    72e311b00887:	add    r15,0x140
    72e311b0088e:	mov    rbp,QWORD PTR [r12+0xe8]
    72e311b00896:	mov    QWORD PTR [r15],rbp
    72e311b00899:	mov    r15,r14
    72e311b0089c:	add    r15,0x180
    72e311b008a3:	mov    rbp,r15
    72e311b008a6:	add    rbp,0x10
    72e311b008aa:	movdqu xmm3,XMMWORD PTR [r15]
    72e311b008af:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    72e311b008b4:	movdqu XMMWORD PTR [r12+0x2a0],xmm3
    72e311b008be:	movdqu XMMWORD PTR [r12+0x1a0],xmm7
    72e311b008c8:	mov    r15,r14
    72e311b008cb:	add    r15,0x1c0
    72e311b008d2:	mov    rbp,r15
    72e311b008d5:	add    rbp,0x10
    72e311b008d9:	movdqu xmm3,XMMWORD PTR [r15]
    72e311b008de:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    72e311b008e3:	movdqu XMMWORD PTR [r12+0x240],xmm3
    72e311b008ed:	movdqu XMMWORD PTR [r12+0x1c0],xmm7
    72e311b008f7:	mov    r15,r13
    72e311b008fa:	add    r15,0x20
    72e311b008fe:	mov    rbp,r15
    72e311b00901:	add    rbp,0x10
    72e311b00905:	movdqu XMMWORD PTR [r15],xmm2
    72e311b0090a:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    72e311b0090f:	mov    r15,r14
    72e311b00912:	add    r15,0x60
    72e311b00916:	mov    rbp,r15
    72e311b00919:	add    rbp,0x10
    72e311b0091d:	movdqu xmm2,XMMWORD PTR [r15]
    72e311b00922:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    72e311b00927:	movdqu XMMWORD PTR [r12+0x110],xmm2
    72e311b00931:	movdqu XMMWORD PTR [r12+0x120],xmm5
    72e311b0093b:	mov    r15,r14
    72e311b0093e:	add    r15,0x20
    72e311b00942:	mov    rbp,r15
    72e311b00945:	add    rbp,0x10
    72e311b00949:	movdqu xmm7,XMMWORD PTR [r15]
    72e311b0094e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    72e311b00954:	movdqu XMMWORD PTR [r12+0x1d0],xmm7
    72e311b0095e:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
    72e311b00968:	mov    r15,r13
    72e311b0096b:	add    r15,0x60
    72e311b0096f:	mov    rbp,r15
    72e311b00972:	add    rbp,0x10
    72e311b00976:	movdqu XMMWORD PTR [r15],xmm4
    72e311b0097b:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    72e311b00980:	mov    r15,r14
    72e311b00983:	add    r15,0xe0
    72e311b0098a:	mov    rbp,r15
    72e311b0098d:	add    rbp,0x10
    72e311b00991:	movdqu xmm3,XMMWORD PTR [r15]
    72e311b00996:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    72e311b0099b:	movdqu XMMWORD PTR [r12+0x200],xmm3
    72e311b009a5:	movdqu XMMWORD PTR [r12+0x2d0],xmm4
    72e311b009af:	mov    r15,r13
    72e311b009b2:	add    r15,0xa0
    72e311b009b9:	mov    rbp,r15
    72e311b009bc:	add    rbp,0x10
    72e311b009c0:	movdqu XMMWORD PTR [r15],xmm5
    72e311b009c5:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72e311b009ca:	mov    r15,r14
    72e311b009cd:	add    r15,0xa0
    72e311b009d4:	mov    rbp,r15
    72e311b009d7:	add    rbp,0x10
    72e311b009db:	movdqu xmm2,XMMWORD PTR [r15]
    72e311b009e0:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72e311b009e5:	movdqu XMMWORD PTR [r12+0x110],xmm2
    72e311b009ef:	movdqu XMMWORD PTR [r12+0x120],xmm3
    72e311b009f9:	mov    r15,r14
    72e311b009fc:	add    r15,0x120
    72e311b00a03:	mov    rbp,r15
    72e311b00a06:	add    rbp,0x10
    72e311b00a0a:	movdqu xmm4,XMMWORD PTR [r15]
    72e311b00a0f:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    72e311b00a14:	movdqu XMMWORD PTR [r12+0x2e0],xmm4
    72e311b00a1e:	movdqu XMMWORD PTR [r12+0x2f0],xmm5
    72e311b00a28:	mov    r15,r14
    72e311b00a2b:	add    r15,0x160
    72e311b00a32:	mov    rbp,r15
    72e311b00a35:	add    rbp,0x10
    72e311b00a39:	movdqu xmm4,XMMWORD PTR [r15]
    72e311b00a3e:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    72e311b00a43:	movdqu XMMWORD PTR [r12+0x2c0],xmm4
    72e311b00a4d:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
    72e311b00a57:	mov    r15,r13
    72e311b00a5a:	add    r15,0x80
    72e311b00a61:	mov    rbp,r15
    72e311b00a64:	add    rbp,0x10
    72e311b00a68:	movdqu XMMWORD PTR [r15],xmm3
    72e311b00a6d:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72e311b00a72:	mov    r15,r14
    72e311b00a75:	add    r15,0x1a0
    72e311b00a7c:	mov    rbp,r15
    72e311b00a7f:	add    rbp,0x10
    72e311b00a83:	movdqu xmm2,XMMWORD PTR [r15]
    72e311b00a88:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72e311b00a8d:	movdqu XMMWORD PTR [r12+0x290],xmm2
    72e311b00a97:	movdqu XMMWORD PTR [r12+0x1e0],xmm3
    72e311b00aa1:	add    r14,0x1e0
    72e311b00aa8:	mov    r15,r14
    72e311b00aab:	add    r15,0x10
    72e311b00aaf:	movdqu xmm2,XMMWORD PTR [r14]
    72e311b00ab4:	movdqu xmm3,XMMWORD PTR [r15]
    72e311b00ab9:	movdqu XMMWORD PTR [r12+0x230],xmm2
    72e311b00ac3:	movdqu XMMWORD PTR [r12+0x280],xmm3
    72e311b00acd:	mov    r14d,0x430000
    72e311b00ad3:	add    r14,0x920
    72e311b00ada:	mov    QWORD PTR [r12+0x50],r14
    72e311b00adf:	mov    r14,r13
    72e311b00ae2:	add    r14,0x40
    72e311b00ae6:	mov    r15,r14
    72e311b00ae9:	add    r15,0x10
    72e311b00aed:	movdqu XMMWORD PTR [r14],xmm4
    72e311b00af2:	movdqu XMMWORD PTR [r15],xmm6
    72e311b00af7:	mov    r14,r13
    72e311b00afa:	add    r14,0x10
    72e311b00afe:	movdqu XMMWORD PTR [r13+0x0],xmm3
    72e311b00b04:	movdqu XMMWORD PTR [r14],xmm2
    72e311b00b09:	mov    r11,rax
    72e311b00b0c:	movzx  eax,WORD PTR [rsp]
    72e311b00b10:	add    al,0x7f
    72e311b00b12:	sahf
    72e311b00b13:	mov    rax,r11
    72e311b00b16:	jmp    0x72e311b00b1b
    72e311b00b1b:	mov    r13d,0x0
    72e311b00b21:	mov    QWORD PTR [r12+0x58],r13
    72e311b00b26:	mov    r11,rax
    72e311b00b29:	lahf
    72e311b00b2a:	seto   al
    72e311b00b2d:	mov    WORD PTR [rsp],ax
    72e311b00b31:	mov    rax,r11
    72e311b00b34:	jmp    0x72e311b00b39
    72e311b00b39:	mov    r13,QWORD PTR [r12+0x58]
    72e311b00b3e:	mov    r14,QWORD PTR [r12+0x40]
    72e311b00b43:	add    r14,r13
    72e311b00b46:	mov    QWORD PTR [r12+0x60],r14
    72e311b00b4b:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    72e311b00b55:	movdqa xmm0,xmm2
    72e311b00b59:	movdqa xmm1,xmm2
    72e311b00b5d:	por    xmm0,xmm1
    72e311b00b61:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    72e311b00b6b:	movdqu xmm4,XMMWORD PTR [r12+0x1a0]
    72e311b00b75:	movdqa xmm0,xmm4
    72e311b00b79:	movdqa xmm1,xmm4
    72e311b00b7d:	por    xmm0,xmm1
    72e311b00b81:	movdqu XMMWORD PTR [r12+0x120],xmm0
    72e311b00b8b:	mov    r15,r14
    72e311b00b8e:	add    r15,0x30
    72e311b00b92:	mov    rbp,r15
    72e311b00b95:	add    rbp,0x8
    72e311b00b99:	mov    r8,QWORD PTR [r15]
    72e311b00b9c:	mov    r15,QWORD PTR [rbp+0x0]
    72e311b00ba0:	mov    ebp,0x0
    72e311b00ba5:	mov    QWORD PTR [r12+0x130],r8
    72e311b00bad:	mov    QWORD PTR [r12+0x138],rbp
    72e311b00bb5:	mov    ebp,0x0
    72e311b00bba:	mov    QWORD PTR [r12+0x280],r15
    72e311b00bc2:	mov    QWORD PTR [r12+0x288],rbp
    72e311b00bca:	movdqu xmm5,XMMWORD PTR [r12+0x270]
    72e311b00bd4:	movdqa xmm0,xmm5
    72e311b00bd8:	movdqa xmm1,xmm5
    72e311b00bdc:	por    xmm0,xmm1
    72e311b00be0:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    72e311b00bea:	mov    r15,r14
    72e311b00bed:	add    r15,0x20
    72e311b00bf1:	mov    rbp,r15
    72e311b00bf4:	add    rbp,0x8
    72e311b00bf8:	mov    r8,QWORD PTR [r15]
    72e311b00bfb:	mov    r15,QWORD PTR [rbp+0x0]
    72e311b00bff:	mov    ebp,0x0
    72e311b00c04:	mov    QWORD PTR [r12+0x150],r8
    72e311b00c0c:	mov    QWORD PTR [r12+0x158],rbp
    72e311b00c14:	mov    ebp,0x0
    72e311b00c19:	mov    QWORD PTR [r12+0x140],r15
    72e311b00c21:	mov    QWORD PTR [r12+0x148],rbp
    72e311b00c29:	mov    r15,r14
    72e311b00c2c:	add    r15,0x10
    72e311b00c30:	mov    rbp,r15
    72e311b00c33:	add    rbp,0x8
    72e311b00c37:	mov    r8,QWORD PTR [r15]
    72e311b00c3a:	mov    r15,QWORD PTR [rbp+0x0]
    72e311b00c3e:	mov    ebp,0x0
    72e311b00c43:	mov    QWORD PTR [r12+0x170],r8
    72e311b00c4b:	mov    QWORD PTR [r12+0x178],rbp
    72e311b00c53:	mov    ebp,0x0
    72e311b00c58:	mov    QWORD PTR [r12+0x160],r15
    72e311b00c60:	mov    QWORD PTR [r12+0x168],rbp
    72e311b00c68:	mov    r15d,0x8
    72e311b00c6e:	mov    rbp,QWORD PTR [r14]
    72e311b00c71:	mov    QWORD PTR [r12+0x180],rbp
    72e311b00c79:	mov    QWORD PTR [r12+0x188],rbp
    72e311b00c81:	add    r14,r15
    72e311b00c84:	mov    QWORD PTR [r12+0x60],r14
    72e311b00c89:	mov    r15,QWORD PTR [r14]
    72e311b00c8c:	mov    r14d,0x0
    72e311b00c92:	mov    QWORD PTR [r12+0x230],r15
    72e311b00c9a:	mov    QWORD PTR [r12+0x238],r14
    72e311b00ca2:	mov    r14,QWORD PTR [r12+0xf8]
    72e311b00caa:	mov    r15,r14
    72e311b00cad:	add    r15,0x50
    72e311b00cb1:	mov    rbp,r15
    72e311b00cb4:	add    rbp,0x10
    72e311b00cb8:	movdqu xmm6,XMMWORD PTR [r15]
    72e311b00cbd:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    72e311b00cc2:	movdqu XMMWORD PTR [r12+0x220],xmm6
    72e311b00ccc:	movdqu XMMWORD PTR [r12+0x210],xmm7
    72e311b00cd6:	mov    r15,r14
    72e311b00cd9:	add    r15,0x30
    72e311b00cdd:	movdqu xmm8,XMMWORD PTR [r15]
    72e311b00ce2:	movdqu XMMWORD PTR [r12+0x110],xmm8
    72e311b00cec:	mov    r15,QWORD PTR [r12+0x50]
    72e311b00cf1:	add    r15,r13
    72e311b00cf4:	mov    QWORD PTR [r12+0x60],r15
    72e311b00cf9:	add    r13,0x40
    72e311b00cfd:	mov    QWORD PTR [r12+0x58],r13
    72e311b00d02:	movdqu xmm9,XMMWORD PTR [r12+0x180]
    72e311b00d0c:	movdqa xmm0,xmm9
    72e311b00d11:	movdqa xmm1,xmm2
    72e311b00d15:	mulpd  xmm0,xmm1
    72e311b00d19:	movdqa xmm14,xmm0
    72e311b00d1e:	movdqu xmm15,XMMWORD PTR [rip+0x9569]        # 0x72e311b0a290
    72e311b00d27:	pand   xmm14,xmm15
    72e311b00d2c:	movdqu xmm15,XMMWORD PTR [rip+0x956b]        # 0x72e311b0a2a0
    72e311b00d35:	pcmpeqq xmm14,xmm15
    72e311b00d3b:	movdqa xmm15,xmm0
    72e311b00d40:	cmpunordpd xmm15,xmm0
    72e311b00d46:	por    xmm14,xmm15
    72e311b00d4b:	pmovmskb ecx,xmm14
    72e311b00d50:	jrcxz  0x72e311b00d57
    72e311b00d52:	jmp    0x72e311b02c36
    72e311b00d57:	movdqa xmm10,xmm0
    72e311b00d5c:	movdqu xmm2,XMMWORD PTR [r12+0x230]
    72e311b00d66:	movdqa xmm0,xmm8
    72e311b00d6b:	movdqa xmm1,xmm2
    72e311b00d6f:	pshufd xmm1,xmm1,0x44
    72e311b00d74:	mulpd  xmm0,xmm1
    72e311b00d78:	movdqa xmm14,xmm0
    72e311b00d7d:	movdqu xmm15,XMMWORD PTR [rip+0x950a]        # 0x72e311b0a290
    72e311b00d86:	pand   xmm14,xmm15
    72e311b00d8b:	movdqu xmm15,XMMWORD PTR [rip+0x950c]        # 0x72e311b0a2a0
    72e311b00d94:	pcmpeqq xmm14,xmm15
    72e311b00d9a:	movdqa xmm15,xmm0
    72e311b00d9f:	cmpunordpd xmm15,xmm0
    72e311b00da5:	por    xmm14,xmm15
    72e311b00daa:	pmovmskb ecx,xmm14
    72e311b00daf:	jrcxz  0x72e311b00db6
    72e311b00db1:	jmp    0x72e311b02c5b
    72e311b00db6:	movdqa xmm11,xmm0
    72e311b00dbb:	movdqu XMMWORD PTR [r12+0x260],xmm11
    72e311b00dc5:	mov    ebp,0x0
    72e311b00dca:	mov    r8d,0x0
    72e311b00dd0:	mov    QWORD PTR [r12+0x110],rbp
    72e311b00dd8:	mov    QWORD PTR [r12+0x118],r8
    72e311b00de0:	movdqa xmm0,xmm9
    72e311b00de5:	movdqa xmm1,xmm7
    72e311b00de9:	mulpd  xmm0,xmm1
    72e311b00ded:	movdqa xmm14,xmm0
    72e311b00df2:	movdqu xmm15,XMMWORD PTR [rip+0x9495]        # 0x72e311b0a290
    72e311b00dfb:	pand   xmm14,xmm15
    72e311b00e00:	movdqu xmm15,XMMWORD PTR [rip+0x9497]        # 0x72e311b0a2a0
    72e311b00e09:	pcmpeqq xmm14,xmm15
    72e311b00e0f:	movdqa xmm15,xmm0
    72e311b00e14:	cmpunordpd xmm15,xmm0
    72e311b00e1a:	por    xmm14,xmm15
    72e311b00e1f:	pmovmskb ecx,xmm14
    72e311b00e24:	jrcxz  0x72e311b00e2b
    72e311b00e26:	jmp    0x72e311b02c80
    72e311b00e2b:	movdqa xmm8,xmm0
    72e311b00e30:	movdqa xmm0,xmm9
    72e311b00e35:	movdqa xmm1,xmm6
    72e311b00e39:	mulpd  xmm0,xmm1
    72e311b00e3d:	movdqa xmm14,xmm0
    72e311b00e42:	movdqu xmm15,XMMWORD PTR [rip+0x9445]        # 0x72e311b0a290
    72e311b00e4b:	pand   xmm14,xmm15
    72e311b00e50:	movdqu xmm15,XMMWORD PTR [rip+0x9447]        # 0x72e311b0a2a0
    72e311b00e59:	pcmpeqq xmm14,xmm15
    72e311b00e5f:	movdqa xmm15,xmm0
    72e311b00e64:	cmpunordpd xmm15,xmm0
    72e311b00e6a:	por    xmm14,xmm15
    72e311b00e6f:	pmovmskb ecx,xmm14
    72e311b00e74:	jrcxz  0x72e311b00e7b
    72e311b00e76:	jmp    0x72e311b02ca5
    72e311b00e7b:	movdqa xmm7,xmm0
    72e311b00e7f:	movdqu xmm6,XMMWORD PTR [r12+0x1f0]
    72e311b00e89:	movdqa xmm0,xmm9
    72e311b00e8e:	movdqa xmm1,xmm6
    72e311b00e92:	mulpd  xmm0,xmm1
    72e311b00e96:	movdqa xmm14,xmm0
    72e311b00e9b:	movdqu xmm15,XMMWORD PTR [rip+0x93ec]        # 0x72e311b0a290
    72e311b00ea4:	pand   xmm14,xmm15
    72e311b00ea9:	movdqu xmm15,XMMWORD PTR [rip+0x93ee]        # 0x72e311b0a2a0
    72e311b00eb2:	pcmpeqq xmm14,xmm15
    72e311b00eb8:	movdqa xmm15,xmm0
    72e311b00ebd:	cmpunordpd xmm15,xmm0
    72e311b00ec3:	por    xmm14,xmm15
    72e311b00ec8:	pmovmskb ecx,xmm14
    72e311b00ecd:	jrcxz  0x72e311b00ed4
    72e311b00ecf:	jmp    0x72e311b02cca
    72e311b00ed4:	movdqa xmm12,xmm0
    72e311b00ed9:	movdqu XMMWORD PTR [r12+0x180],xmm12
    72e311b00ee3:	movdqu xmm6,XMMWORD PTR [r12+0x2a0]
    72e311b00eed:	movdqa xmm0,xmm6
    72e311b00ef1:	movdqa xmm1,xmm6
    72e311b00ef5:	por    xmm0,xmm1
    72e311b00ef9:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    72e311b00f03:	movdqu xmm9,XMMWORD PTR [r12+0x250]
    72e311b00f0d:	movdqa xmm0,xmm9
    72e311b00f12:	movdqa xmm1,xmm9
    72e311b00f17:	por    xmm0,xmm1
    72e311b00f1b:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    72e311b00f25:	movdqa xmm0,xmm9
    72e311b00f2a:	movdqa xmm1,xmm2
    72e311b00f2e:	pshufd xmm1,xmm1,0x44
    72e311b00f33:	mulpd  xmm0,xmm1
    72e311b00f37:	movdqa xmm14,xmm0
    72e311b00f3c:	movdqu xmm15,XMMWORD PTR [rip+0x934b]        # 0x72e311b0a290
    72e311b00f45:	pand   xmm14,xmm15
    72e311b00f4a:	movdqu xmm15,XMMWORD PTR [rip+0x934d]        # 0x72e311b0a2a0
    72e311b00f53:	pcmpeqq xmm14,xmm15
    72e311b00f59:	movdqa xmm15,xmm0
    72e311b00f5e:	cmpunordpd xmm15,xmm0
    72e311b00f64:	por    xmm14,xmm15
    72e311b00f69:	pmovmskb ecx,xmm14
    72e311b00f6e:	jrcxz  0x72e311b00f75
    72e311b00f70:	jmp    0x72e311b02cef
    72e311b00f75:	movdqa xmm4,xmm0
    72e311b00f79:	movdqu XMMWORD PTR [r12+0x250],xmm4
    72e311b00f83:	sub    r13,0x200
    72e311b00f8a:	movdqu xmm9,XMMWORD PTR [r12+0x110]
    72e311b00f94:	movdqa xmm0,xmm10
    72e311b00f99:	movdqa xmm1,xmm9
    72e311b00f9e:	addpd  xmm0,xmm1
    72e311b00fa2:	movdqa xmm14,xmm0
    72e311b00fa7:	movdqu xmm15,XMMWORD PTR [rip+0x92e0]        # 0x72e311b0a290
    72e311b00fb0:	pand   xmm14,xmm15
    72e311b00fb5:	movdqu xmm15,XMMWORD PTR [rip+0x92e2]        # 0x72e311b0a2a0
    72e311b00fbe:	pcmpeqq xmm14,xmm15
    72e311b00fc4:	movdqa xmm15,xmm0
    72e311b00fc9:	cmpunordpd xmm15,xmm0
    72e311b00fcf:	por    xmm14,xmm15
    72e311b00fd4:	pmovmskb ecx,xmm14
    72e311b00fd9:	jrcxz  0x72e311b00fe0
    72e311b00fdb:	jmp    0x72e311b02d14
    72e311b00fe0:	movdqu XMMWORD PTR [r12+0x240],xmm0
    72e311b00fea:	movdqu xmm10,XMMWORD PTR [r12+0x1b0]
    72e311b00ff4:	movdqa xmm0,xmm8
    72e311b00ff9:	movdqa xmm1,xmm10
    72e311b00ffe:	addpd  xmm0,xmm1
    72e311b01002:	movdqa xmm14,xmm0
    72e311b01007:	movdqu xmm15,XMMWORD PTR [rip+0x9280]        # 0x72e311b0a290
    72e311b01010:	pand   xmm14,xmm15
    72e311b01015:	movdqu xmm15,XMMWORD PTR [rip+0x9282]        # 0x72e311b0a2a0
    72e311b0101e:	pcmpeqq xmm14,xmm15
    72e311b01024:	movdqa xmm15,xmm0
    72e311b01029:	cmpunordpd xmm15,xmm0
    72e311b0102f:	por    xmm14,xmm15
    72e311b01034:	pmovmskb ecx,xmm14
    72e311b01039:	jrcxz  0x72e311b01040
    72e311b0103b:	jmp    0x72e311b02d55
    72e311b01040:	movdqa xmm6,xmm0
    72e311b01044:	movdqu XMMWORD PTR [r12+0x210],xmm6
    72e311b0104e:	movdqa xmm0,xmm7
    72e311b01052:	movdqa xmm1,xmm10
    72e311b01057:	addpd  xmm0,xmm1
    72e311b0105b:	movdqa xmm14,xmm0
    72e311b01060:	movdqu xmm15,XMMWORD PTR [rip+0x9227]        # 0x72e311b0a290
    72e311b01069:	pand   xmm14,xmm15
    72e311b0106e:	movdqu xmm15,XMMWORD PTR [rip+0x9229]        # 0x72e311b0a2a0
    72e311b01077:	pcmpeqq xmm14,xmm15
    72e311b0107d:	movdqa xmm15,xmm0
    72e311b01082:	cmpunordpd xmm15,xmm0
    72e311b01088:	por    xmm14,xmm15
    72e311b0108d:	pmovmskb ecx,xmm14
    72e311b01092:	jrcxz  0x72e311b01099
    72e311b01094:	jmp    0x72e311b02d96
    72e311b01099:	movdqa xmm8,xmm0
    72e311b0109e:	movdqu XMMWORD PTR [r12+0x220],xmm8
    72e311b010a8:	movdqu xmm7,XMMWORD PTR [r12+0x2f0]
    72e311b010b2:	setne  BYTE PTR [rsp+0x8]
    72e311b010b7:	mov    r11,rax
    72e311b010ba:	lahf
    72e311b010bb:	seto   al
    72e311b010be:	mov    WORD PTR [rsp],ax
    72e311b010c2:	mov    rax,r11
    72e311b010c5:	movdqa xmm0,xmm7
    72e311b010c9:	movdqa xmm1,xmm7
    72e311b010cd:	por    xmm0,xmm1
    72e311b010d1:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    72e311b010db:	movdqu xmm10,XMMWORD PTR [r12+0x2e0]
    72e311b010e5:	movdqa xmm0,xmm10
    72e311b010ea:	movdqa xmm1,xmm10
    72e311b010ef:	por    xmm0,xmm1
    72e311b010f3:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    72e311b010fd:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    72e311b01107:	movdqa xmm0,xmm13
    72e311b0110c:	movdqa xmm1,xmm13
    72e311b01111:	por    xmm0,xmm1
    72e311b01115:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    72e311b0111f:	movdqu xmm5,XMMWORD PTR [r12+0x200]
    72e311b01129:	movdqa xmm0,xmm5
    72e311b0112d:	movdqa xmm1,xmm5
    72e311b01131:	por    xmm0,xmm1
    72e311b01135:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    72e311b0113f:	movdqu xmm7,XMMWORD PTR [r12+0x1c0]
    72e311b01149:	movdqa xmm1,xmm7
    72e311b0114d:	por    xmm7,xmm1
    72e311b01151:	movdqu XMMWORD PTR [r12+0x200],xmm7
    72e311b0115b:	movdqu xmm3,XMMWORD PTR [r12+0x190]
    72e311b01165:	movdqa xmm1,xmm3
    72e311b01169:	por    xmm3,xmm1
    72e311b0116d:	movdqu XMMWORD PTR [r12+0x1c0],xmm3
    72e311b01177:	movdqu xmm10,XMMWORD PTR [r12+0x300]
    72e311b01181:	movdqa xmm1,xmm10
    72e311b01186:	por    xmm10,xmm1
    72e311b0118b:	movdqu XMMWORD PTR [r12+0x190],xmm10
    72e311b01195:	mov    r13,r14
    72e311b01198:	add    r13,0xa0
    72e311b0119f:	mov    rbp,r13
    72e311b011a2:	add    rbp,0x10
    72e311b011a6:	movdqu xmm13,XMMWORD PTR [r13+0x0]
    72e311b011ac:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    72e311b011b1:	movdqu XMMWORD PTR [r12+0x300],xmm13
    72e311b011bb:	movdqu XMMWORD PTR [r12+0x270],xmm5
    72e311b011c5:	movdqa xmm0,xmm12
    72e311b011ca:	movdqa xmm1,xmm9
    72e311b011cf:	addpd  xmm0,xmm1
    72e311b011d3:	movdqa xmm14,xmm0
    72e311b011d8:	movdqu xmm15,XMMWORD PTR [rip+0x90af]        # 0x72e311b0a290
    72e311b011e1:	pand   xmm14,xmm15
    72e311b011e6:	movdqu xmm15,XMMWORD PTR [rip+0x90b1]        # 0x72e311b0a2a0
    72e311b011ef:	pcmpeqq xmm14,xmm15
    72e311b011f5:	movdqa xmm15,xmm0
    72e311b011fa:	cmpunordpd xmm15,xmm0
    72e311b01200:	por    xmm14,xmm15
    72e311b01205:	pmovmskb ecx,xmm14
    72e311b0120a:	jrcxz  0x72e311b01211
    72e311b0120c:	jmp    0x72e311b02dd6
    72e311b01211:	movdqu XMMWORD PTR [r12+0x180],xmm0
    72e311b0121b:	mov    r13,r14
    72e311b0121e:	add    r13,0xf0
    72e311b01225:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    72e311b0122b:	movdqu XMMWORD PTR [r12+0x110],xmm9
    72e311b01235:	movdqa xmm0,xmm6
    72e311b01239:	movdqa xmm1,xmm4
    72e311b0123d:	addpd  xmm0,xmm1
    72e311b01241:	movdqa xmm14,xmm0
    72e311b01246:	movdqu xmm15,XMMWORD PTR [rip+0x9041]        # 0x72e311b0a290
    72e311b0124f:	pand   xmm14,xmm15
    72e311b01254:	movdqu xmm15,XMMWORD PTR [rip+0x9043]        # 0x72e311b0a2a0
    72e311b0125d:	pcmpeqq xmm14,xmm15
    72e311b01263:	movdqa xmm15,xmm0
    72e311b01268:	cmpunordpd xmm15,xmm0
    72e311b0126e:	por    xmm14,xmm15
    72e311b01273:	pmovmskb ecx,xmm14
    72e311b01278:	jrcxz  0x72e311b0127f
    72e311b0127a:	jmp    0x72e311b02dfc
    72e311b0127f:	movdqa xmm12,xmm0
    72e311b01284:	movdqu XMMWORD PTR [r12+0x210],xmm12
    72e311b0128e:	movdqa xmm0,xmm8
    72e311b01293:	movdqa xmm1,xmm11
    72e311b01298:	addpd  xmm0,xmm1
    72e311b0129c:	movdqa xmm14,xmm0
    72e311b012a1:	movdqu xmm15,XMMWORD PTR [rip+0x8fe6]        # 0x72e311b0a290
    72e311b012aa:	pand   xmm14,xmm15
    72e311b012af:	movdqu xmm15,XMMWORD PTR [rip+0x8fe8]        # 0x72e311b0a2a0
    72e311b012b8:	pcmpeqq xmm14,xmm15
    72e311b012be:	movdqa xmm15,xmm0
    72e311b012c3:	cmpunordpd xmm15,xmm0
    72e311b012c9:	por    xmm14,xmm15
    72e311b012ce:	pmovmskb ecx,xmm14
    72e311b012d3:	jrcxz  0x72e311b012da
    72e311b012d5:	jmp    0x72e311b02e20
    72e311b012da:	movdqa xmm4,xmm0
    72e311b012de:	movdqu XMMWORD PTR [r12+0x220],xmm4
    72e311b012e8:	movdqa xmm0,xmm5
    72e311b012ec:	movdqa xmm1,xmm2
    72e311b012f0:	pshufd xmm1,xmm1,0x44
    72e311b012f5:	mulpd  xmm0,xmm1
    72e311b012f9:	movdqa xmm14,xmm0
    72e311b012fe:	movdqu xmm15,XMMWORD PTR [rip+0x8f89]        # 0x72e311b0a290
    72e311b01307:	pand   xmm14,xmm15
    72e311b0130c:	movdqu xmm15,XMMWORD PTR [rip+0x8f8b]        # 0x72e311b0a2a0
    72e311b01315:	pcmpeqq xmm14,xmm15
    72e311b0131b:	movdqa xmm15,xmm0
    72e311b01320:	cmpunordpd xmm15,xmm0
    72e311b01326:	por    xmm14,xmm15
    72e311b0132b:	pmovmskb ecx,xmm14
    72e311b01330:	jrcxz  0x72e311b01337
    72e311b01332:	jmp    0x72e311b02e46
    72e311b01337:	movdqa xmm6,xmm0
    72e311b0133b:	movdqu XMMWORD PTR [r12+0x270],xmm6
    72e311b01345:	movdqu xmm5,XMMWORD PTR [r12+0x170]
    72e311b0134f:	movdqa xmm0,xmm9
    72e311b01354:	movdqa xmm1,xmm5
    72e311b01358:	pshufd xmm1,xmm1,0x44
    72e311b0135d:	mulpd  xmm0,xmm1
    72e311b01361:	movdqa xmm14,xmm0
    72e311b01366:	movdqu xmm15,XMMWORD PTR [rip+0x8f21]        # 0x72e311b0a290
    72e311b0136f:	pand   xmm14,xmm15
    72e311b01374:	movdqu xmm15,XMMWORD PTR [rip+0x8f23]        # 0x72e311b0a2a0
    72e311b0137d:	pcmpeqq xmm14,xmm15
    72e311b01383:	movdqa xmm15,xmm0
    72e311b01388:	cmpunordpd xmm15,xmm0
    72e311b0138e:	por    xmm14,xmm15
    72e311b01393:	pmovmskb ecx,xmm14
    72e311b01398:	jrcxz  0x72e311b0139f
    72e311b0139a:	jmp    0x72e311b02e6a
    72e311b0139f:	movdqa xmm8,xmm0
    72e311b013a4:	movdqu XMMWORD PTR [r12+0x250],xmm8
    72e311b013ae:	mov    r13,r14
    72e311b013b1:	add    r13,0xe0
    72e311b013b8:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    72e311b013be:	movdqu XMMWORD PTR [r12+0x110],xmm9
    72e311b013c8:	movdqa xmm0,xmm13
    72e311b013cd:	movdqa xmm1,xmm2
    72e311b013d1:	pshufd xmm1,xmm1,0x44
    72e311b013d6:	mulpd  xmm0,xmm1
    72e311b013da:	movdqa xmm14,xmm0
    72e311b013df:	movdqu xmm15,XMMWORD PTR [rip+0x8ea8]        # 0x72e311b0a290
    72e311b013e8:	pand   xmm14,xmm15
    72e311b013ed:	movdqu xmm15,XMMWORD PTR [rip+0x8eaa]        # 0x72e311b0a2a0
    72e311b013f6:	pcmpeqq xmm14,xmm15
    72e311b013fc:	movdqa xmm15,xmm0
    72e311b01401:	cmpunordpd xmm15,xmm0
    72e311b01407:	por    xmm14,xmm15
    72e311b0140c:	pmovmskb ecx,xmm14
    72e311b01411:	jrcxz  0x72e311b01418
    72e311b01413:	jmp    0x72e311b02e8f
    72e311b01418:	movdqa xmm11,xmm0
    72e311b0141d:	movdqu XMMWORD PTR [r12+0x230],xmm11
    72e311b01427:	movdqa xmm0,xmm10
    72e311b0142c:	movdqa xmm1,xmm10
    72e311b01431:	por    xmm0,xmm1
    72e311b01435:	movdqu XMMWORD PTR [r12+0x300],xmm0
    72e311b0143f:	movdqa xmm0,xmm3
    72e311b01443:	movdqa xmm1,xmm3
    72e311b01447:	por    xmm0,xmm1
    72e311b0144b:	movdqu XMMWORD PTR [r12+0x190],xmm0
    72e311b01455:	movdqa xmm0,xmm9
    72e311b0145a:	movdqa xmm1,xmm5
    72e311b0145e:	pshufd xmm1,xmm1,0x44
    72e311b01463:	mulpd  xmm0,xmm1
    72e311b01467:	movdqa xmm14,xmm0
    72e311b0146c:	movdqu xmm15,XMMWORD PTR [rip+0x8e1b]        # 0x72e311b0a290
    72e311b01475:	pand   xmm14,xmm15
    72e311b0147a:	movdqu xmm15,XMMWORD PTR [rip+0x8e1d]        # 0x72e311b0a2a0
    72e311b01483:	pcmpeqq xmm14,xmm15
    72e311b01489:	movdqa xmm15,xmm0
    72e311b0148e:	cmpunordpd xmm15,xmm0
    72e311b01494:	por    xmm14,xmm15
    72e311b01499:	pmovmskb ecx,xmm14
    72e311b0149e:	jrcxz  0x72e311b014a5
    72e311b014a0:	jmp    0x72e311b02eb4
    72e311b014a5:	movdqa xmm2,xmm0
    72e311b014a9:	movdqu XMMWORD PTR [r12+0x260],xmm2
    72e311b014b3:	mov    r13,r14
    72e311b014b6:	add    r13,0x90
    72e311b014bd:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    72e311b014c3:	movdqu XMMWORD PTR [r12+0x110],xmm9
    72e311b014cd:	movdqa xmm0,xmm7
    72e311b014d1:	movdqa xmm1,xmm7
    72e311b014d5:	por    xmm0,xmm1
    72e311b014d9:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    72e311b014e3:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    72e311b014ed:	movdqu xmm1,XMMWORD PTR [r12+0x2d0]
    72e311b014f7:	por    xmm13,xmm1
    72e311b014fc:	movdqu XMMWORD PTR [r12+0x200],xmm13
    72e311b01506:	movdqu xmm7,XMMWORD PTR [r12+0x2e0]
    72e311b01510:	movdqu xmm1,XMMWORD PTR [r12+0x2e0]
    72e311b0151a:	por    xmm7,xmm1
    72e311b0151e:	movdqu XMMWORD PTR [r12+0x2d0],xmm7
    72e311b01528:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    72e311b01532:	movdqu xmm1,XMMWORD PTR [r12+0x2f0]
    72e311b0153c:	por    xmm0,xmm1
    72e311b01540:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    72e311b0154a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    72e311b01554:	movdqa xmm1,xmm6
    72e311b01558:	addpd  xmm0,xmm1
    72e311b0155c:	movdqa xmm14,xmm0
    72e311b01561:	movdqu xmm15,XMMWORD PTR [rip+0x8d26]        # 0x72e311b0a290
    72e311b0156a:	pand   xmm14,xmm15
    72e311b0156f:	movdqu xmm15,XMMWORD PTR [rip+0x8d28]        # 0x72e311b0a2a0
    72e311b01578:	pcmpeqq xmm14,xmm15
    72e311b0157e:	movdqa xmm15,xmm0
    72e311b01583:	cmpunordpd xmm15,xmm0
    72e311b01589:	por    xmm14,xmm15
    72e311b0158e:	pmovmskb ecx,xmm14
    72e311b01593:	jrcxz  0x72e311b0159a
    72e311b01595:	jmp    0x72e311b02ed9
    72e311b0159a:	movdqa xmm3,xmm0
    72e311b0159e:	movdqu XMMWORD PTR [r12+0x240],xmm3
    72e311b015a8:	movdqa xmm0,xmm9
    72e311b015ad:	movdqa xmm1,xmm5
    72e311b015b1:	pshufd xmm1,xmm1,0x44
    72e311b015b6:	mulpd  xmm0,xmm1
    72e311b015ba:	movdqa xmm14,xmm0
    72e311b015bf:	movdqu xmm15,XMMWORD PTR [rip+0x8cc8]        # 0x72e311b0a290
    72e311b015c8:	pand   xmm14,xmm15
    72e311b015cd:	movdqu xmm15,XMMWORD PTR [rip+0x8cca]        # 0x72e311b0a2a0
    72e311b015d6:	pcmpeqq xmm14,xmm15
    72e311b015dc:	movdqa xmm15,xmm0
    72e311b015e1:	cmpunordpd xmm15,xmm0
    72e311b015e7:	por    xmm14,xmm15
    72e311b015ec:	pmovmskb ecx,xmm14
    72e311b015f1:	jrcxz  0x72e311b015f8
    72e311b015f3:	jmp    0x72e311b02f03
    72e311b015f8:	movdqa xmm6,xmm0
    72e311b015fc:	movdqu XMMWORD PTR [r12+0x270],xmm6
    72e311b01606:	mov    r13,r14
    72e311b01609:	add    r13,0x80
    72e311b01610:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    72e311b01616:	movdqu XMMWORD PTR [r12+0x110],xmm9
    72e311b01620:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    72e311b0162a:	movdqa xmm1,xmm11
    72e311b0162f:	addpd  xmm0,xmm1
    72e311b01633:	movdqa xmm14,xmm0
    72e311b01638:	movdqu xmm15,XMMWORD PTR [rip+0x8c4f]        # 0x72e311b0a290
    72e311b01641:	pand   xmm14,xmm15
    72e311b01646:	movdqu xmm15,XMMWORD PTR [rip+0x8c51]        # 0x72e311b0a2a0
    72e311b0164f:	pcmpeqq xmm14,xmm15
    72e311b01655:	movdqa xmm15,xmm0
    72e311b0165a:	cmpunordpd xmm15,xmm0
    72e311b01660:	por    xmm14,xmm15
    72e311b01665:	pmovmskb ecx,xmm14
    72e311b0166a:	jrcxz  0x72e311b01671
    72e311b0166c:	jmp    0x72e311b02f28
    72e311b01671:	movdqa xmm10,xmm0
    72e311b01676:	movdqu XMMWORD PTR [r12+0x180],xmm10
    72e311b01680:	movdqa xmm0,xmm12
    72e311b01685:	movdqa xmm1,xmm8
    72e311b0168a:	addpd  xmm0,xmm1
    72e311b0168e:	movdqa xmm14,xmm0
    72e311b01693:	movdqu xmm15,XMMWORD PTR [rip+0x8bf4]        # 0x72e311b0a290
    72e311b0169c:	pand   xmm14,xmm15
    72e311b016a1:	movdqu xmm15,XMMWORD PTR [rip+0x8bf6]        # 0x72e311b0a2a0
    72e311b016aa:	pcmpeqq xmm14,xmm15
    72e311b016b0:	movdqa xmm15,xmm0
    72e311b016b5:	cmpunordpd xmm15,xmm0
    72e311b016bb:	por    xmm14,xmm15
    72e311b016c0:	pmovmskb ecx,xmm14
    72e311b016c5:	jrcxz  0x72e311b016cc
    72e311b016c7:	jmp    0x72e311b02f53
    72e311b016cc:	movdqa xmm11,xmm0
    72e311b016d1:	movdqu XMMWORD PTR [r12+0x210],xmm11
    72e311b016db:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    72e311b016e5:	movdqu xmm1,XMMWORD PTR [r12+0x1b0]
    72e311b016ef:	por    xmm0,xmm1
    72e311b016f3:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    72e311b016fd:	movdqa xmm0,xmm9
    72e311b01702:	movdqa xmm1,xmm5
    72e311b01706:	pshufd xmm1,xmm1,0x44
    72e311b0170b:	mulpd  xmm0,xmm1
    72e311b0170f:	movdqa xmm14,xmm0
    72e311b01714:	movdqu xmm15,XMMWORD PTR [rip+0x8b73]        # 0x72e311b0a290
    72e311b0171d:	pand   xmm14,xmm15
    72e311b01722:	movdqu xmm15,XMMWORD PTR [rip+0x8b75]        # 0x72e311b0a2a0
    72e311b0172b:	pcmpeqq xmm14,xmm15
    72e311b01731:	movdqa xmm15,xmm0
    72e311b01736:	cmpunordpd xmm15,xmm0
    72e311b0173c:	por    xmm14,xmm15
    72e311b01741:	pmovmskb ecx,xmm14
    72e311b01746:	jrcxz  0x72e311b0174d
    72e311b01748:	jmp    0x72e311b02f79
    72e311b0174d:	movdqa xmm12,xmm0
    72e311b01752:	movdqu XMMWORD PTR [r12+0x170],xmm12
    72e311b0175c:	mov    r13,r14
    72e311b0175f:	add    r13,0xd0
    72e311b01766:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    72e311b0176c:	movdqu XMMWORD PTR [r12+0x110],xmm5
    72e311b01776:	movdqa xmm0,xmm4
    72e311b0177a:	movdqa xmm1,xmm2
    72e311b0177e:	addpd  xmm0,xmm1
    72e311b01782:	movdqa xmm14,xmm0
    72e311b01787:	movdqu xmm15,XMMWORD PTR [rip+0x8b00]        # 0x72e311b0a290
    72e311b01790:	pand   xmm14,xmm15
    72e311b01795:	movdqu xmm15,XMMWORD PTR [rip+0x8b02]        # 0x72e311b0a2a0
    72e311b0179e:	pcmpeqq xmm14,xmm15
    72e311b017a4:	movdqa xmm15,xmm0
    72e311b017a9:	cmpunordpd xmm15,xmm0
    72e311b017af:	por    xmm14,xmm15
    72e311b017b4:	pmovmskb ecx,xmm14
    72e311b017b9:	jrcxz  0x72e311b017c0
    72e311b017bb:	jmp    0x72e311b02f9e
    72e311b017c0:	movdqa xmm9,xmm0
    72e311b017c5:	movdqu XMMWORD PTR [r12+0x220],xmm9
    72e311b017cf:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    72e311b017d9:	movdqa xmm0,xmm13
    72e311b017de:	movdqa xmm1,xmm2
    72e311b017e2:	pshufd xmm1,xmm1,0x44
    72e311b017e7:	mulpd  xmm0,xmm1
    72e311b017eb:	movdqa xmm14,xmm0
    72e311b017f0:	movdqu xmm15,XMMWORD PTR [rip+0x8a97]        # 0x72e311b0a290
    72e311b017f9:	pand   xmm14,xmm15
    72e311b017fe:	movdqu xmm15,XMMWORD PTR [rip+0x8a99]        # 0x72e311b0a2a0
    72e311b01807:	pcmpeqq xmm14,xmm15
    72e311b0180d:	movdqa xmm15,xmm0
    72e311b01812:	cmpunordpd xmm15,xmm0
    72e311b01818:	por    xmm14,xmm15
    72e311b0181d:	pmovmskb ecx,xmm14
    72e311b01822:	jrcxz  0x72e311b01829
    72e311b01824:	jmp    0x72e311b02fc2
    72e311b01829:	movdqa xmm4,xmm0
    72e311b0182d:	movdqu XMMWORD PTR [r12+0x260],xmm4
    72e311b01837:	mov    r13d,0x0
    72e311b0183d:	mov    ebp,0x0
    72e311b01842:	mov    QWORD PTR [r12+0x1b0],r13
    72e311b0184a:	mov    QWORD PTR [r12+0x1b8],rbp
    72e311b01852:	movdqa xmm0,xmm5
    72e311b01856:	movdqa xmm1,xmm2
    72e311b0185a:	pshufd xmm1,xmm1,0x44
    72e311b0185f:	mulpd  xmm0,xmm1
    72e311b01863:	movdqa xmm14,xmm0
    72e311b01868:	movdqu xmm15,XMMWORD PTR [rip+0x8a1f]        # 0x72e311b0a290
    72e311b01871:	pand   xmm14,xmm15
    72e311b01876:	movdqu xmm15,XMMWORD PTR [rip+0x8a21]        # 0x72e311b0a2a0
    72e311b0187f:	pcmpeqq xmm14,xmm15
    72e311b01885:	movdqa xmm15,xmm0
    72e311b0188a:	cmpunordpd xmm15,xmm0
    72e311b01890:	por    xmm14,xmm15
    72e311b01895:	pmovmskb ecx,xmm14
    72e311b0189a:	jrcxz  0x72e311b018a1
    72e311b0189c:	jmp    0x72e311b02fe7
    72e311b018a1:	movdqa xmm13,xmm0
    72e311b018a6:	movdqu XMMWORD PTR [r12+0x230],xmm13
    72e311b018b0:	mov    r13,r14
    72e311b018b3:	add    r13,0xc0
    72e311b018ba:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    72e311b018c0:	movdqu XMMWORD PTR [r12+0x110],xmm5
    72e311b018ca:	movdqa xmm0,xmm3
    72e311b018ce:	movdqa xmm1,xmm6
    72e311b018d2:	addpd  xmm0,xmm1
    72e311b018d6:	movdqa xmm14,xmm0
    72e311b018db:	movdqu xmm15,XMMWORD PTR [rip+0x89ac]        # 0x72e311b0a290
    72e311b018e4:	pand   xmm14,xmm15
    72e311b018e9:	movdqu xmm15,XMMWORD PTR [rip+0x89ae]        # 0x72e311b0a2a0
    72e311b018f2:	pcmpeqq xmm14,xmm15
    72e311b018f8:	movdqa xmm15,xmm0
    72e311b018fd:	cmpunordpd xmm15,xmm0
    72e311b01903:	por    xmm14,xmm15
    72e311b01908:	pmovmskb ecx,xmm14
    72e311b0190d:	jrcxz  0x72e311b01914
    72e311b0190f:	jmp    0x72e311b0300b
    72e311b01914:	movdqa xmm8,xmm0
    72e311b01919:	movdqu XMMWORD PTR [r12+0x240],xmm8
    72e311b01923:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    72e311b0192d:	movdqu xmm1,XMMWORD PTR [r12+0x1a0]
    72e311b01937:	por    xmm0,xmm1
    72e311b0193b:	movdqu XMMWORD PTR [r12+0x270],xmm0
    72e311b01945:	movdqu xmm6,XMMWORD PTR [r12+0x120]
    72e311b0194f:	movdqu xmm1,XMMWORD PTR [r12+0x120]
    72e311b01959:	por    xmm6,xmm1
    72e311b0195d:	movdqu XMMWORD PTR [r12+0x1a0],xmm6
    72e311b01967:	movdqa xmm0,xmm5
    72e311b0196b:	movdqa xmm1,xmm2
    72e311b0196f:	pshufd xmm1,xmm1,0x44
    72e311b01974:	mulpd  xmm0,xmm1
    72e311b01978:	movdqa xmm14,xmm0
    72e311b0197d:	movdqu xmm15,XMMWORD PTR [rip+0x890a]        # 0x72e311b0a290
    72e311b01986:	pand   xmm14,xmm15
    72e311b0198b:	movdqu xmm15,XMMWORD PTR [rip+0x890c]        # 0x72e311b0a2a0
    72e311b01994:	pcmpeqq xmm14,xmm15
    72e311b0199a:	movdqa xmm15,xmm0
    72e311b0199f:	cmpunordpd xmm15,xmm0
    72e311b019a5:	por    xmm14,xmm15
    72e311b019aa:	pmovmskb ecx,xmm14
    72e311b019af:	jrcxz  0x72e311b019b6
    72e311b019b1:	jmp    0x72e311b0302f
    72e311b019b6:	movdqa xmm6,xmm0
    72e311b019ba:	movdqu XMMWORD PTR [r12+0x250],xmm6
    72e311b019c4:	mov    r13,r14
    72e311b019c7:	add    r13,0x20
    72e311b019cb:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    72e311b019d1:	movdqu XMMWORD PTR [r12+0x110],xmm5
    72e311b019db:	movdqa xmm0,xmm10
    72e311b019e0:	movdqa xmm1,xmm12
    72e311b019e5:	addpd  xmm0,xmm1
    72e311b019e9:	movdqa xmm14,xmm0
    72e311b019ee:	movdqu xmm15,XMMWORD PTR [rip+0x8899]        # 0x72e311b0a290
    72e311b019f7:	pand   xmm14,xmm15
    72e311b019fc:	movdqu xmm15,XMMWORD PTR [rip+0x889b]        # 0x72e311b0a2a0
    72e311b01a05:	pcmpeqq xmm14,xmm15
    72e311b01a0b:	movdqa xmm15,xmm0
    72e311b01a10:	cmpunordpd xmm15,xmm0
    72e311b01a16:	por    xmm14,xmm15
    72e311b01a1b:	pmovmskb ecx,xmm14
    72e311b01a20:	jrcxz  0x72e311b01a27
    72e311b01a22:	jmp    0x72e311b03053
    72e311b01a27:	movdqa xmm3,xmm0
    72e311b01a2b:	movdqa xmm0,xmm7
    72e311b01a2f:	movdqa xmm1,xmm2
    72e311b01a33:	pshufd xmm1,xmm1,0x44
    72e311b01a38:	mulpd  xmm0,xmm1
    72e311b01a3c:	movdqa xmm14,xmm0
    72e311b01a41:	movdqu xmm15,XMMWORD PTR [rip+0x8846]        # 0x72e311b0a290
    72e311b01a4a:	pand   xmm14,xmm15
    72e311b01a4f:	movdqu xmm15,XMMWORD PTR [rip+0x8848]        # 0x72e311b0a2a0
    72e311b01a58:	pcmpeqq xmm14,xmm15
    72e311b01a5e:	movdqa xmm15,xmm0
    72e311b01a63:	cmpunordpd xmm15,xmm0
    72e311b01a69:	por    xmm14,xmm15
    72e311b01a6e:	pmovmskb ecx,xmm14
    72e311b01a73:	jrcxz  0x72e311b01a7a
    72e311b01a75:	jmp    0x72e311b03079
    72e311b01a7a:	movdqa xmm10,xmm0
    72e311b01a7f:	movdqa xmm0,xmm11
    72e311b01a84:	movdqa xmm1,xmm13
    72e311b01a89:	addpd  xmm0,xmm1
    72e311b01a8d:	movdqa xmm14,xmm0
    72e311b01a92:	movdqu xmm15,XMMWORD PTR [rip+0x87f5]        # 0x72e311b0a290
    72e311b01a9b:	pand   xmm14,xmm15
    72e311b01aa0:	movdqu xmm15,XMMWORD PTR [rip+0x87f7]        # 0x72e311b0a2a0
    72e311b01aa9:	pcmpeqq xmm14,xmm15
    72e311b01aaf:	movdqa xmm15,xmm0
    72e311b01ab4:	cmpunordpd xmm15,xmm0
    72e311b01aba:	por    xmm14,xmm15
    72e311b01abf:	pmovmskb ecx,xmm14
    72e311b01ac4:	jrcxz  0x72e311b01acb
    72e311b01ac6:	jmp    0x72e311b0309d
    72e311b01acb:	movdqa xmm2,xmm0
    72e311b01acf:	movdqu xmm7,XMMWORD PTR [r12+0x150]
    72e311b01ad9:	movdqa xmm0,xmm5
    72e311b01add:	movdqa xmm1,xmm7
    72e311b01ae1:	pshufd xmm1,xmm1,0x44
    72e311b01ae6:	mulpd  xmm0,xmm1
    72e311b01aea:	movdqa xmm14,xmm0
    72e311b01aef:	movdqu xmm15,XMMWORD PTR [rip+0x8798]        # 0x72e311b0a290
    72e311b01af8:	pand   xmm14,xmm15
    72e311b01afd:	movdqu xmm15,XMMWORD PTR [rip+0x879a]        # 0x72e311b0a2a0
    72e311b01b06:	pcmpeqq xmm14,xmm15
    72e311b01b0c:	movdqa xmm15,xmm0
    72e311b01b11:	cmpunordpd xmm15,xmm0
    72e311b01b17:	por    xmm14,xmm15
    72e311b01b1c:	pmovmskb ecx,xmm14
    72e311b01b21:	jrcxz  0x72e311b01b28
    72e311b01b23:	jmp    0x72e311b030c3
    72e311b01b28:	movdqa xmm11,xmm0
    72e311b01b2d:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    72e311b01b37:	movdqa xmm1,xmm7
    72e311b01b3b:	pshufd xmm1,xmm1,0x44
    72e311b01b40:	mulpd  xmm0,xmm1
    72e311b01b44:	movdqa xmm14,xmm0
    72e311b01b49:	movdqu xmm15,XMMWORD PTR [rip+0x873e]        # 0x72e311b0a290
    72e311b01b52:	pand   xmm14,xmm15
    72e311b01b57:	movdqu xmm15,XMMWORD PTR [rip+0x8740]        # 0x72e311b0a2a0
    72e311b01b60:	pcmpeqq xmm14,xmm15
    72e311b01b66:	movdqa xmm15,xmm0
    72e311b01b6b:	cmpunordpd xmm15,xmm0
    72e311b01b71:	por    xmm14,xmm15
    72e311b01b76:	pmovmskb ecx,xmm14
    72e311b01b7b:	jrcxz  0x72e311b01b82
    72e311b01b7d:	jmp    0x72e311b030e7
    72e311b01b82:	movdqa xmm5,xmm0
    72e311b01b86:	movdqa xmm0,xmm8
    72e311b01b8b:	movdqa xmm1,xmm4
    72e311b01b8f:	addpd  xmm0,xmm1
    72e311b01b93:	movdqa xmm14,xmm0
    72e311b01b98:	movdqu xmm15,XMMWORD PTR [rip+0x86ef]        # 0x72e311b0a290
    72e311b01ba1:	pand   xmm14,xmm15
    72e311b01ba6:	movdqu xmm15,XMMWORD PTR [rip+0x86f1]        # 0x72e311b0a2a0
    72e311b01baf:	pcmpeqq xmm14,xmm15
    72e311b01bb5:	movdqa xmm15,xmm0
    72e311b01bba:	cmpunordpd xmm15,xmm0
    72e311b01bc0:	por    xmm14,xmm15
    72e311b01bc5:	pmovmskb ecx,xmm14
    72e311b01bca:	jrcxz  0x72e311b01bd1
    72e311b01bcc:	jmp    0x72e311b03111
    72e311b01bd1:	movdqa xmm12,xmm0
    72e311b01bd6:	movdqu XMMWORD PTR [r12+0x240],xmm12
    72e311b01be0:	movdqa xmm0,xmm9
    72e311b01be5:	movdqa xmm1,xmm6
    72e311b01be9:	addpd  xmm0,xmm1
    72e311b01bed:	movdqa xmm14,xmm0
    72e311b01bf2:	movdqu xmm15,XMMWORD PTR [rip+0x8695]        # 0x72e311b0a290
    72e311b01bfb:	pand   xmm14,xmm15
    72e311b01c00:	movdqu xmm15,XMMWORD PTR [rip+0x8697]        # 0x72e311b0a2a0
    72e311b01c09:	pcmpeqq xmm14,xmm15
    72e311b01c0f:	movdqa xmm15,xmm0
    72e311b01c14:	cmpunordpd xmm15,xmm0
    72e311b01c1a:	por    xmm14,xmm15
    72e311b01c1f:	pmovmskb ecx,xmm14
    72e311b01c24:	jrcxz  0x72e311b01c2b
    72e311b01c26:	jmp    0x72e311b03136
    72e311b01c2b:	movdqa xmm4,xmm0
    72e311b01c2f:	movdqu XMMWORD PTR [r12+0x220],xmm4
    72e311b01c39:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    72e311b01c43:	movdqa xmm1,xmm7
    72e311b01c47:	pshufd xmm1,xmm1,0x44
    72e311b01c4c:	mulpd  xmm0,xmm1
    72e311b01c50:	movdqa xmm14,xmm0
    72e311b01c55:	movdqu xmm15,XMMWORD PTR [rip+0x8632]        # 0x72e311b0a290
    72e311b01c5e:	pand   xmm14,xmm15
    72e311b01c63:	movdqu xmm15,XMMWORD PTR [rip+0x8634]        # 0x72e311b0a2a0
    72e311b01c6c:	pcmpeqq xmm14,xmm15
    72e311b01c72:	movdqa xmm15,xmm0
    72e311b01c77:	cmpunordpd xmm15,xmm0
    72e311b01c7d:	por    xmm14,xmm15
    72e311b01c82:	pmovmskb ecx,xmm14
    72e311b01c87:	jrcxz  0x72e311b01c8e
    72e311b01c89:	jmp    0x72e311b0315b
    72e311b01c8e:	movdqa xmm6,xmm0
    72e311b01c92:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    72e311b01c9c:	movdqa xmm1,xmm7
    72e311b01ca0:	pshufd xmm1,xmm1,0x44
    72e311b01ca5:	mulpd  xmm0,xmm1
    72e311b01ca9:	movdqa xmm14,xmm0
    72e311b01cae:	movdqu xmm15,XMMWORD PTR [rip+0x85d9]        # 0x72e311b0a290
    72e311b01cb7:	pand   xmm14,xmm15
    72e311b01cbc:	movdqu xmm15,XMMWORD PTR [rip+0x85db]        # 0x72e311b0a2a0
    72e311b01cc5:	pcmpeqq xmm14,xmm15
    72e311b01ccb:	movdqa xmm15,xmm0
    72e311b01cd0:	cmpunordpd xmm15,xmm0
    72e311b01cd6:	por    xmm14,xmm15
    72e311b01cdb:	pmovmskb ecx,xmm14
    72e311b01ce0:	jrcxz  0x72e311b01ce7
    72e311b01ce2:	jmp    0x72e311b03185
    72e311b01ce7:	movdqa xmm8,xmm0
    72e311b01cec:	movdqu XMMWORD PTR [r12+0x150],xmm8
    72e311b01cf6:	movdqa xmm0,xmm3
    72e311b01cfa:	movdqa xmm1,xmm10
    72e311b01cff:	addpd  xmm0,xmm1
    72e311b01d03:	movdqa xmm14,xmm0
    72e311b01d08:	movdqu xmm15,XMMWORD PTR [rip+0x857f]        # 0x72e311b0a290
    72e311b01d11:	pand   xmm14,xmm15
    72e311b01d16:	movdqu xmm15,XMMWORD PTR [rip+0x8581]        # 0x72e311b0a2a0
    72e311b01d1f:	pcmpeqq xmm14,xmm15
    72e311b01d25:	movdqa xmm15,xmm0
    72e311b01d2a:	cmpunordpd xmm15,xmm0
    72e311b01d30:	por    xmm14,xmm15
    72e311b01d35:	pmovmskb ecx,xmm14
    72e311b01d3a:	jrcxz  0x72e311b01d41
    72e311b01d3c:	jmp    0x72e311b031af
    72e311b01d41:	movdqa xmm7,xmm0
    72e311b01d45:	movdqu XMMWORD PTR [r12+0x160],xmm7
    72e311b01d4f:	movdqa xmm0,xmm2
    72e311b01d53:	movdqa xmm1,xmm11
    72e311b01d58:	addpd  xmm0,xmm1
    72e311b01d5c:	movdqa xmm14,xmm0
    72e311b01d61:	movdqu xmm15,XMMWORD PTR [rip+0x8526]        # 0x72e311b0a290
    72e311b01d6a:	pand   xmm14,xmm15
    72e311b01d6f:	movdqu xmm15,XMMWORD PTR [rip+0x8528]        # 0x72e311b0a2a0
    72e311b01d78:	pcmpeqq xmm14,xmm15
    72e311b01d7e:	movdqa xmm15,xmm0
    72e311b01d83:	cmpunordpd xmm15,xmm0
    72e311b01d89:	por    xmm14,xmm15
    72e311b01d8e:	pmovmskb ecx,xmm14
    72e311b01d93:	jrcxz  0x72e311b01d9a
    72e311b01d95:	jmp    0x72e311b031d4
    72e311b01d9a:	movdqa xmm3,xmm0
    72e311b01d9e:	movdqu XMMWORD PTR [r12+0x170],xmm3
    72e311b01da8:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    72e311b01db2:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    72e311b01dbc:	movdqa xmm1,xmm2
    72e311b01dc0:	pshufd xmm1,xmm1,0x44
    72e311b01dc5:	mulpd  xmm0,xmm1
    72e311b01dc9:	movdqa xmm14,xmm0
    72e311b01dce:	movdqu xmm15,XMMWORD PTR [rip+0x84b9]        # 0x72e311b0a290
    72e311b01dd7:	pand   xmm14,xmm15
    72e311b01ddc:	movdqu xmm15,XMMWORD PTR [rip+0x84bb]        # 0x72e311b0a2a0
    72e311b01de5:	pcmpeqq xmm14,xmm15
    72e311b01deb:	movdqa xmm15,xmm0
    72e311b01df0:	cmpunordpd xmm15,xmm0
    72e311b01df6:	por    xmm14,xmm15
    72e311b01dfb:	pmovmskb ecx,xmm14
    72e311b01e00:	jrcxz  0x72e311b01e07
    72e311b01e02:	jmp    0x72e311b031f9
    72e311b01e07:	movdqa xmm9,xmm0
    72e311b01e0c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    72e311b01e16:	movdqa xmm0,xmm4
    72e311b01e1a:	movdqa xmm1,xmm5
    72e311b01e1e:	addpd  xmm0,xmm1
    72e311b01e22:	movdqa xmm14,xmm0
    72e311b01e27:	movdqu xmm15,XMMWORD PTR [rip+0x8460]        # 0x72e311b0a290
    72e311b01e30:	pand   xmm14,xmm15
    72e311b01e35:	movdqu xmm15,XMMWORD PTR [rip+0x8462]        # 0x72e311b0a2a0
    72e311b01e3e:	pcmpeqq xmm14,xmm15
    72e311b01e44:	movdqa xmm15,xmm0
    72e311b01e49:	cmpunordpd xmm15,xmm0
    72e311b01e4f:	por    xmm14,xmm15
    72e311b01e54:	pmovmskb ecx,xmm14
    72e311b01e59:	jrcxz  0x72e311b01e60
    72e311b01e5b:	jmp    0x72e311b03223
    72e311b01e60:	movdqa xmm10,xmm0
    72e311b01e65:	movdqu XMMWORD PTR [r12+0x210],xmm10
    72e311b01e6f:	movdqa xmm0,xmm12
    72e311b01e74:	movdqa xmm1,xmm6
    72e311b01e78:	addpd  xmm0,xmm1
    72e311b01e7c:	movdqa xmm14,xmm0
    72e311b01e81:	movdqu xmm15,XMMWORD PTR [rip+0x8406]        # 0x72e311b0a290
    72e311b01e8a:	pand   xmm14,xmm15
    72e311b01e8f:	movdqu xmm15,XMMWORD PTR [rip+0x8408]        # 0x72e311b0a2a0
    72e311b01e98:	pcmpeqq xmm14,xmm15
    72e311b01e9e:	movdqa xmm15,xmm0
    72e311b01ea3:	cmpunordpd xmm15,xmm0
    72e311b01ea9:	por    xmm14,xmm15
    72e311b01eae:	pmovmskb ecx,xmm14
    72e311b01eb3:	jrcxz  0x72e311b01eba
    72e311b01eb5:	jmp    0x72e311b03247
    72e311b01eba:	movdqa xmm4,xmm0
    72e311b01ebe:	movdqu XMMWORD PTR [r12+0x230],xmm4
    72e311b01ec8:	movdqu xmm5,XMMWORD PTR [r12+0x2a0]
    72e311b01ed2:	movdqu xmm1,XMMWORD PTR [r12+0x2a0]
    72e311b01edc:	por    xmm5,xmm1
    72e311b01ee0:	movdqu XMMWORD PTR [r12+0x250],xmm5
    72e311b01eea:	movdqu xmm5,XMMWORD PTR [r12+0x1d0]
    72e311b01ef4:	movdqu xmm1,XMMWORD PTR [r12+0x1d0]
    72e311b01efe:	por    xmm5,xmm1
    72e311b01f02:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    72e311b01f0c:	movdqu xmm6,XMMWORD PTR [r12+0x2c0]
    72e311b01f16:	movdqu xmm1,XMMWORD PTR [r12+0x2c0]
    72e311b01f20:	por    xmm6,xmm1
    72e311b01f24:	movdqu XMMWORD PTR [r12+0x1d0],xmm6
    72e311b01f2e:	mov    r13,r14
    72e311b01f31:	add    r13,0x40
    72e311b01f35:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    72e311b01f3b:	movdqu XMMWORD PTR [r12+0x2c0],xmm6
    72e311b01f45:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    72e311b01f4f:	movdqa xmm1,xmm2
    72e311b01f53:	pshufd xmm1,xmm1,0x44
    72e311b01f58:	mulpd  xmm0,xmm1
    72e311b01f5c:	movdqa xmm14,xmm0
    72e311b01f61:	movdqu xmm15,XMMWORD PTR [rip+0x8326]        # 0x72e311b0a290
    72e311b01f6a:	pand   xmm14,xmm15
    72e311b01f6f:	movdqu xmm15,XMMWORD PTR [rip+0x8328]        # 0x72e311b0a2a0
    72e311b01f78:	pcmpeqq xmm14,xmm15
    72e311b01f7e:	movdqa xmm15,xmm0
    72e311b01f83:	cmpunordpd xmm15,xmm0
    72e311b01f89:	por    xmm14,xmm15
    72e311b01f8e:	pmovmskb ecx,xmm14
    72e311b01f93:	jrcxz  0x72e311b01f9a
    72e311b01f95:	jmp    0x72e311b0326c
    72e311b01f9a:	movdqa xmm11,xmm0
    72e311b01f9f:	movdqa xmm0,xmm7
    72e311b01fa3:	movdqa xmm1,xmm8
    72e311b01fa8:	addpd  xmm0,xmm1
    72e311b01fac:	movdqa xmm14,xmm0
    72e311b01fb1:	movdqu xmm15,XMMWORD PTR [rip+0x82d6]        # 0x72e311b0a290
    72e311b01fba:	pand   xmm14,xmm15
    72e311b01fbf:	movdqu xmm15,XMMWORD PTR [rip+0x82d8]        # 0x72e311b0a2a0
    72e311b01fc8:	pcmpeqq xmm14,xmm15
    72e311b01fce:	movdqa xmm15,xmm0
    72e311b01fd3:	cmpunordpd xmm15,xmm0
    72e311b01fd9:	por    xmm14,xmm15
    72e311b01fde:	pmovmskb ecx,xmm14
    72e311b01fe3:	jrcxz  0x72e311b01fea
    72e311b01fe5:	jmp    0x72e311b03296
    72e311b01fea:	movdqa xmm12,xmm0
    72e311b01fef:	movdqa xmm0,xmm3
    72e311b01ff3:	movdqa xmm1,xmm9
    72e311b01ff8:	addpd  xmm0,xmm1
    72e311b01ffc:	movdqa xmm14,xmm0
    72e311b02001:	movdqu xmm15,XMMWORD PTR [rip+0x8286]        # 0x72e311b0a290
    72e311b0200a:	pand   xmm14,xmm15
    72e311b0200f:	movdqu xmm15,XMMWORD PTR [rip+0x8288]        # 0x72e311b0a2a0
    72e311b02018:	pcmpeqq xmm14,xmm15
    72e311b0201e:	movdqa xmm15,xmm0
    72e311b02023:	cmpunordpd xmm15,xmm0
    72e311b02029:	por    xmm14,xmm15
    72e311b0202e:	pmovmskb ecx,xmm14
    72e311b02033:	jrcxz  0x72e311b0203a
    72e311b02035:	jmp    0x72e311b032bb
    72e311b0203a:	movdqa xmm7,xmm0
    72e311b0203e:	movdqu XMMWORD PTR [r12+0x160],xmm7
    72e311b02048:	movdqa xmm0,xmm6
    72e311b0204c:	movdqa xmm1,xmm2
    72e311b02050:	pshufd xmm1,xmm1,0x44
    72e311b02055:	mulpd  xmm0,xmm1
    72e311b02059:	movdqa xmm14,xmm0
    72e311b0205e:	movdqu xmm15,XMMWORD PTR [rip+0x8229]        # 0x72e311b0a290
    72e311b02067:	pand   xmm14,xmm15
    72e311b0206c:	movdqu xmm15,XMMWORD PTR [rip+0x822b]        # 0x72e311b0a2a0
    72e311b02075:	pcmpeqq xmm14,xmm15
    72e311b0207b:	movdqa xmm15,xmm0
    72e311b02080:	cmpunordpd xmm15,xmm0
    72e311b02086:	por    xmm14,xmm15
    72e311b0208b:	pmovmskb ecx,xmm14
    72e311b02090:	jrcxz  0x72e311b02097
    72e311b02092:	jmp    0x72e311b032e0
    72e311b02097:	movdqa xmm3,xmm0
    72e311b0209b:	movdqu XMMWORD PTR [r12+0x240],xmm3
    72e311b020a5:	movdqu xmm6,XMMWORD PTR [r12+0x2b0]
    72e311b020af:	movdqa xmm0,xmm6
    72e311b020b3:	movdqa xmm1,xmm2
    72e311b020b7:	pshufd xmm1,xmm1,0x44
    72e311b020bc:	mulpd  xmm0,xmm1
    72e311b020c0:	movdqa xmm14,xmm0
    72e311b020c5:	movdqu xmm15,XMMWORD PTR [rip+0x81c2]        # 0x72e311b0a290
    72e311b020ce:	pand   xmm14,xmm15
    72e311b020d3:	movdqu xmm15,XMMWORD PTR [rip+0x81c4]        # 0x72e311b0a2a0
    72e311b020dc:	pcmpeqq xmm14,xmm15
    72e311b020e2:	movdqa xmm15,xmm0
    72e311b020e7:	cmpunordpd xmm15,xmm0
    72e311b020ed:	por    xmm14,xmm15
    72e311b020f2:	pmovmskb ecx,xmm14
    72e311b020f7:	jrcxz  0x72e311b020fe
    72e311b020f9:	jmp    0x72e311b03304
    72e311b020fe:	movdqa xmm8,xmm0
    72e311b02103:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    72e311b0210d:	movdqa xmm0,xmm5
    72e311b02111:	movdqa xmm1,xmm2
    72e311b02115:	pshufd xmm1,xmm1,0x44
    72e311b0211a:	mulpd  xmm0,xmm1
    72e311b0211e:	movdqa xmm14,xmm0
    72e311b02123:	movdqu xmm15,XMMWORD PTR [rip+0x8164]        # 0x72e311b0a290
    72e311b0212c:	pand   xmm14,xmm15
    72e311b02131:	movdqu xmm15,XMMWORD PTR [rip+0x8166]        # 0x72e311b0a2a0
    72e311b0213a:	pcmpeqq xmm14,xmm15
    72e311b02140:	movdqa xmm15,xmm0
    72e311b02145:	cmpunordpd xmm15,xmm0
    72e311b0214b:	por    xmm14,xmm15
    72e311b02150:	pmovmskb ecx,xmm14
    72e311b02155:	jrcxz  0x72e311b0215c
    72e311b02157:	jmp    0x72e311b03328
    72e311b0215c:	movdqa xmm6,xmm0
    72e311b02160:	movdqu XMMWORD PTR [r12+0x170],xmm6
    72e311b0216a:	movdqa xmm0,xmm10
    72e311b0216f:	movdqa xmm1,xmm11
    72e311b02174:	addpd  xmm0,xmm1
    72e311b02178:	movdqa xmm14,xmm0
    72e311b0217d:	movdqu xmm15,XMMWORD PTR [rip+0x810a]        # 0x72e311b0a290
    72e311b02186:	pand   xmm14,xmm15
    72e311b0218b:	movdqu xmm15,XMMWORD PTR [rip+0x810c]        # 0x72e311b0a2a0
    72e311b02194:	pcmpeqq xmm14,xmm15
    72e311b0219a:	movdqa xmm15,xmm0
    72e311b0219f:	cmpunordpd xmm15,xmm0
    72e311b021a5:	por    xmm14,xmm15
    72e311b021aa:	pmovmskb ecx,xmm14
    72e311b021af:	jrcxz  0x72e311b021b6
    72e311b021b1:	jmp    0x72e311b0334c
    72e311b021b6:	movdqa xmm5,xmm0
    72e311b021ba:	movdqu XMMWORD PTR [r12+0x180],xmm5
    72e311b021c4:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    72e311b021ce:	movdqa xmm1,xmm2
    72e311b021d2:	pshufd xmm1,xmm1,0x44
    72e311b021d7:	mulpd  xmm0,xmm1
    72e311b021db:	movdqa xmm14,xmm0
    72e311b021e0:	movdqu xmm15,XMMWORD PTR [rip+0x80a7]        # 0x72e311b0a290
    72e311b021e9:	pand   xmm14,xmm15
    72e311b021ee:	movdqu xmm15,XMMWORD PTR [rip+0x80a9]        # 0x72e311b0a2a0
    72e311b021f7:	pcmpeqq xmm14,xmm15
    72e311b021fd:	movdqa xmm15,xmm0
    72e311b02202:	cmpunordpd xmm15,xmm0
    72e311b02208:	por    xmm14,xmm15
    72e311b0220d:	pmovmskb ecx,xmm14
    72e311b02212:	jrcxz  0x72e311b02219
    72e311b02214:	jmp    0x72e311b03372
    72e311b02219:	movdqa xmm9,xmm0
    72e311b0221e:	movdqu XMMWORD PTR [r12+0x210],xmm9
    72e311b02228:	movdqa xmm0,xmm4
    72e311b0222c:	movdqa xmm1,xmm3
    72e311b02230:	addpd  xmm0,xmm1
    72e311b02234:	movdqa xmm14,xmm0
    72e311b02239:	movdqu xmm15,XMMWORD PTR [rip+0x804e]        # 0x72e311b0a290
    72e311b02242:	pand   xmm14,xmm15
    72e311b02247:	movdqu xmm15,XMMWORD PTR [rip+0x8050]        # 0x72e311b0a2a0
    72e311b02250:	pcmpeqq xmm14,xmm15
    72e311b02256:	movdqa xmm15,xmm0
    72e311b0225b:	cmpunordpd xmm15,xmm0
    72e311b02261:	por    xmm14,xmm15
    72e311b02266:	pmovmskb ecx,xmm14
    72e311b0226b:	jrcxz  0x72e311b02272
    72e311b0226d:	jmp    0x72e311b0339c
    72e311b02272:	movdqa xmm10,xmm0
    72e311b02277:	movdqu XMMWORD PTR [r12+0x220],xmm10
    72e311b02281:	movdqu xmm3,XMMWORD PTR [r12+0x290]
    72e311b0228b:	movdqa xmm0,xmm3
    72e311b0228f:	movdqa xmm1,xmm2
    72e311b02293:	pshufd xmm1,xmm1,0x44
    72e311b02298:	mulpd  xmm0,xmm1
    72e311b0229c:	movdqa xmm14,xmm0
    72e311b022a1:	movdqu xmm15,XMMWORD PTR [rip+0x7fe6]        # 0x72e311b0a290
    72e311b022aa:	pand   xmm14,xmm15
    72e311b022af:	movdqu xmm15,XMMWORD PTR [rip+0x7fe8]        # 0x72e311b0a2a0
    72e311b022b8:	pcmpeqq xmm14,xmm15
    72e311b022be:	movdqa xmm15,xmm0
    72e311b022c3:	cmpunordpd xmm15,xmm0
    72e311b022c9:	por    xmm14,xmm15
    72e311b022ce:	pmovmskb ecx,xmm14
    72e311b022d3:	jrcxz  0x72e311b022da
    72e311b022d5:	jmp    0x72e311b033c0
    72e311b022da:	movdqa xmm4,xmm0
    72e311b022de:	movdqu XMMWORD PTR [r12+0x230],xmm4
    72e311b022e8:	movdqa xmm0,xmm12
    72e311b022ed:	movdqa xmm1,xmm8
    72e311b022f2:	addpd  xmm0,xmm1
    72e311b022f6:	movdqa xmm14,xmm0
    72e311b022fb:	movdqu xmm15,XMMWORD PTR [rip+0x7f8c]        # 0x72e311b0a290
    72e311b02304:	pand   xmm14,xmm15
    72e311b02309:	movdqu xmm15,XMMWORD PTR [rip+0x7f8e]        # 0x72e311b0a2a0
    72e311b02312:	pcmpeqq xmm14,xmm15
    72e311b02318:	movdqa xmm15,xmm0
    72e311b0231d:	cmpunordpd xmm15,xmm0
    72e311b02323:	por    xmm14,xmm15
    72e311b02328:	pmovmskb ecx,xmm14
    72e311b0232d:	jrcxz  0x72e311b02334
    72e311b0232f:	jmp    0x72e311b033e4
    72e311b02334:	movdqa xmm3,xmm0
    72e311b02338:	movdqu XMMWORD PTR [r12+0x140],xmm3
    72e311b02342:	movdqu xmm8,XMMWORD PTR [r12+0x1e0]
    72e311b0234c:	movdqa xmm0,xmm8
    72e311b02351:	movdqa xmm1,xmm2
    72e311b02355:	pshufd xmm1,xmm1,0x44
    72e311b0235a:	mulpd  xmm0,xmm1
    72e311b0235e:	movdqa xmm14,xmm0
    72e311b02363:	movdqu xmm15,XMMWORD PTR [rip+0x7f24]        # 0x72e311b0a290
    72e311b0236c:	pand   xmm14,xmm15
    72e311b02371:	movdqu xmm15,XMMWORD PTR [rip+0x7f26]        # 0x72e311b0a2a0
    72e311b0237a:	pcmpeqq xmm14,xmm15
    72e311b02380:	movdqa xmm15,xmm0
    72e311b02385:	cmpunordpd xmm15,xmm0
    72e311b0238b:	por    xmm14,xmm15
    72e311b02390:	pmovmskb ecx,xmm14
    72e311b02395:	jrcxz  0x72e311b0239c
    72e311b02397:	jmp    0x72e311b0340a
    72e311b0239c:	movdqa xmm11,xmm0
    72e311b023a1:	movdqu XMMWORD PTR [r12+0x130],xmm11
    72e311b023ab:	movdqa xmm0,xmm7
    72e311b023af:	movdqa xmm1,xmm6
    72e311b023b3:	addpd  xmm0,xmm1
    72e311b023b7:	movdqa xmm14,xmm0
    72e311b023bc:	movdqu xmm15,XMMWORD PTR [rip+0x7ecb]        # 0x72e311b0a290
    72e311b023c5:	pand   xmm14,xmm15
    72e311b023ca:	movdqu xmm15,XMMWORD PTR [rip+0x7ecd]        # 0x72e311b0a2a0
    72e311b023d3:	pcmpeqq xmm14,xmm15
    72e311b023d9:	movdqa xmm15,xmm0
    72e311b023de:	cmpunordpd xmm15,xmm0
    72e311b023e4:	por    xmm14,xmm15
    72e311b023e9:	pmovmskb ecx,xmm14
    72e311b023ee:	jrcxz  0x72e311b023f5
    72e311b023f0:	jmp    0x72e311b0342f
    72e311b023f5:	movdqa xmm2,xmm0
    72e311b023f9:	movdqu XMMWORD PTR [r12+0x150],xmm2
    72e311b02403:	mov    r13,r14
    72e311b02406:	add    r13,0x70
    72e311b0240a:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    72e311b02410:	movdqu XMMWORD PTR [r12+0x240],xmm6
    72e311b0241a:	movdqa xmm0,xmm5
    72e311b0241e:	movdqa xmm1,xmm9
    72e311b02423:	addpd  xmm0,xmm1
    72e311b02427:	movdqa xmm14,xmm0
    72e311b0242c:	movdqu xmm15,XMMWORD PTR [rip+0x7e5b]        # 0x72e311b0a290
    72e311b02435:	pand   xmm14,xmm15
    72e311b0243a:	movdqu xmm15,XMMWORD PTR [rip+0x7e5d]        # 0x72e311b0a2a0
    72e311b02443:	pcmpeqq xmm14,xmm15
    72e311b02449:	movdqa xmm15,xmm0
    72e311b0244e:	cmpunordpd xmm15,xmm0
    72e311b02454:	por    xmm14,xmm15
    72e311b02459:	pmovmskb ecx,xmm14
    72e311b0245e:	jrcxz  0x72e311b02465
    72e311b02460:	jmp    0x72e311b03453
    72e311b02465:	movdqa xmm7,xmm0
    72e311b02469:	movdqu XMMWORD PTR [r12+0x170],xmm7
    72e311b02473:	movdqu xmm5,XMMWORD PTR [r12+0x280]
    72e311b0247d:	movdqa xmm0,xmm6
    72e311b02481:	movdqa xmm1,xmm5
    72e311b02485:	pshufd xmm1,xmm1,0x44
    72e311b0248a:	mulpd  xmm0,xmm1
    72e311b0248e:	movdqa xmm14,xmm0
    72e311b02493:	movdqu xmm15,XMMWORD PTR [rip+0x7df4]        # 0x72e311b0a290
    72e311b0249c:	pand   xmm14,xmm15
    72e311b024a1:	movdqu xmm15,XMMWORD PTR [rip+0x7df6]        # 0x72e311b0a2a0
    72e311b024aa:	pcmpeqq xmm14,xmm15
    72e311b024b0:	movdqa xmm15,xmm0
    72e311b024b5:	cmpunordpd xmm15,xmm0
    72e311b024bb:	por    xmm14,xmm15
    72e311b024c0:	pmovmskb ecx,xmm14
    72e311b024c5:	jrcxz  0x72e311b024cc
    72e311b024c7:	jmp    0x72e311b03478
    72e311b024cc:	movdqa xmm8,xmm0
    72e311b024d1:	movdqu XMMWORD PTR [r12+0x160],xmm8
    72e311b024db:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    72e311b024e5:	movdqa xmm1,xmm5
    72e311b024e9:	pshufd xmm1,xmm1,0x44
    72e311b024ee:	mulpd  xmm0,xmm1
    72e311b024f2:	movdqa xmm14,xmm0
    72e311b024f7:	movdqu xmm15,XMMWORD PTR [rip+0x7d90]        # 0x72e311b0a290
    72e311b02500:	pand   xmm14,xmm15
    72e311b02505:	movdqu xmm15,XMMWORD PTR [rip+0x7d92]        # 0x72e311b0a2a0
    72e311b0250e:	pcmpeqq xmm14,xmm15
    72e311b02514:	movdqa xmm15,xmm0
    72e311b02519:	cmpunordpd xmm15,xmm0
    72e311b0251f:	por    xmm14,xmm15
    72e311b02524:	pmovmskb ecx,xmm14
    72e311b02529:	jrcxz  0x72e311b02530
    72e311b0252b:	jmp    0x72e311b0349c
    72e311b02530:	movdqa xmm6,xmm0
    72e311b02534:	movdqu XMMWORD PTR [r12+0x180],xmm6
    72e311b0253e:	movdqa xmm0,xmm10
    72e311b02543:	movdqa xmm1,xmm4
    72e311b02547:	addpd  xmm0,xmm1
    72e311b0254b:	movdqa xmm14,xmm0
    72e311b02550:	movdqu xmm15,XMMWORD PTR [rip+0x7d37]        # 0x72e311b0a290
    72e311b02559:	pand   xmm14,xmm15
    72e311b0255e:	movdqu xmm15,XMMWORD PTR [rip+0x7d39]        # 0x72e311b0a2a0
    72e311b02567:	pcmpeqq xmm14,xmm15
    72e311b0256d:	movdqa xmm15,xmm0
    72e311b02572:	cmpunordpd xmm15,xmm0
    72e311b02578:	por    xmm14,xmm15
    72e311b0257d:	pmovmskb ecx,xmm14
    72e311b02582:	jrcxz  0x72e311b02589
    72e311b02584:	jmp    0x72e311b034c6
    72e311b02589:	movdqa xmm9,xmm0
    72e311b0258e:	movdqu XMMWORD PTR [r12+0x210],xmm9
    72e311b02598:	mov    r13,r14
    72e311b0259b:	add    r13,0x10
    72e311b0259f:	movdqu xmm4,XMMWORD PTR [r14]
    72e311b025a4:	movdqu xmm10,XMMWORD PTR [r13+0x0]
    72e311b025aa:	movdqu XMMWORD PTR [r12+0x230],xmm10
    72e311b025b4:	movdqa xmm0,xmm3
    72e311b025b8:	movdqa xmm1,xmm11
    72e311b025bd:	addpd  xmm0,xmm1
    72e311b025c1:	movdqa xmm14,xmm0
    72e311b025c6:	movdqu xmm15,XMMWORD PTR [rip+0x7cc1]        # 0x72e311b0a290
    72e311b025cf:	pand   xmm14,xmm15
    72e311b025d4:	movdqu xmm15,XMMWORD PTR [rip+0x7cc3]        # 0x72e311b0a2a0
    72e311b025dd:	pcmpeqq xmm14,xmm15
    72e311b025e3:	movdqa xmm15,xmm0
    72e311b025e8:	cmpunordpd xmm15,xmm0
    72e311b025ee:	por    xmm14,xmm15
    72e311b025f3:	pmovmskb ecx,xmm14
    72e311b025f8:	jrcxz  0x72e311b025ff
    72e311b025fa:	jmp    0x72e311b034eb
    72e311b025ff:	movdqa xmm12,xmm0
    72e311b02604:	movdqu XMMWORD PTR [r12+0x130],xmm12
    72e311b0260e:	movdqa xmm0,xmm10
    72e311b02613:	movdqa xmm1,xmm5
    72e311b02617:	pshufd xmm1,xmm1,0x44
    72e311b0261c:	mulpd  xmm0,xmm1
    72e311b02620:	movdqa xmm14,xmm0
    72e311b02625:	movdqu xmm15,XMMWORD PTR [rip+0x7c62]        # 0x72e311b0a290
    72e311b0262e:	pand   xmm14,xmm15
    72e311b02633:	movdqu xmm15,XMMWORD PTR [rip+0x7c64]        # 0x72e311b0a2a0
    72e311b0263c:	pcmpeqq xmm14,xmm15
    72e311b02642:	movdqa xmm15,xmm0
    72e311b02647:	cmpunordpd xmm15,xmm0
    72e311b0264d:	por    xmm14,xmm15
    72e311b02652:	pmovmskb ecx,xmm14
    72e311b02657:	jrcxz  0x72e311b0265e
    72e311b02659:	jmp    0x72e311b03510
    72e311b0265e:	movdqa xmm3,xmm0
    72e311b02662:	movdqu XMMWORD PTR [r12+0x220],xmm3
    72e311b0266c:	movdqa xmm0,xmm4
    72e311b02670:	movdqa xmm1,xmm5
    72e311b02674:	pshufd xmm1,xmm1,0x44
    72e311b02679:	mulpd  xmm0,xmm1
    72e311b0267d:	movdqa xmm14,xmm0
    72e311b02682:	movdqu xmm15,XMMWORD PTR [rip+0x7c05]        # 0x72e311b0a290
    72e311b0268b:	pand   xmm14,xmm15
    72e311b02690:	movdqu xmm15,XMMWORD PTR [rip+0x7c07]        # 0x72e311b0a2a0
    72e311b02699:	pcmpeqq xmm14,xmm15
    72e311b0269f:	movdqa xmm15,xmm0
    72e311b026a4:	cmpunordpd xmm15,xmm0
    72e311b026aa:	por    xmm14,xmm15
    72e311b026af:	pmovmskb ecx,xmm14
    72e311b026b4:	jrcxz  0x72e311b026bb
    72e311b026b6:	jmp    0x72e311b03535
    72e311b026bb:	movdqa xmm10,xmm0
    72e311b026c0:	movdqa xmm0,xmm2
    72e311b026c4:	movdqa xmm1,xmm8
    72e311b026c9:	addpd  xmm0,xmm1
    72e311b026cd:	movdqa xmm14,xmm0
    72e311b026d2:	movdqu xmm15,XMMWORD PTR [rip+0x7bb5]        # 0x72e311b0a290
    72e311b026db:	pand   xmm14,xmm15
    72e311b026e0:	movdqu xmm15,XMMWORD PTR [rip+0x7bb7]        # 0x72e311b0a2a0
    72e311b026e9:	pcmpeqq xmm14,xmm15
    72e311b026ef:	movdqa xmm15,xmm0
    72e311b026f4:	cmpunordpd xmm15,xmm0
    72e311b026fa:	por    xmm14,xmm15
    72e311b026ff:	pmovmskb ecx,xmm14
    72e311b02704:	jrcxz  0x72e311b0270b
    72e311b02706:	jmp    0x72e311b03559
    72e311b0270b:	movdqa xmm4,xmm0
    72e311b0270f:	movdqu XMMWORD PTR [r12+0x140],xmm4
    72e311b02719:	movdqa xmm0,xmm7
    72e311b0271d:	movdqa xmm1,xmm6
    72e311b02721:	addpd  xmm0,xmm1
    72e311b02725:	movdqa xmm14,xmm0
    72e311b0272a:	movdqu xmm15,XMMWORD PTR [rip+0x7b5d]        # 0x72e311b0a290
    72e311b02733:	pand   xmm14,xmm15
    72e311b02738:	movdqu xmm15,XMMWORD PTR [rip+0x7b5f]        # 0x72e311b0a2a0
    72e311b02741:	pcmpeqq xmm14,xmm15
    72e311b02747:	movdqa xmm15,xmm0
    72e311b0274c:	cmpunordpd xmm15,xmm0
    72e311b02752:	por    xmm14,xmm15
    72e311b02757:	pmovmskb ecx,xmm14
    72e311b0275c:	jrcxz  0x72e311b02763
    72e311b0275e:	jmp    0x72e311b0357e
    72e311b02763:	movdqa xmm2,xmm0
    72e311b02767:	movdqu XMMWORD PTR [r12+0x150],xmm2
    72e311b02771:	movdqa xmm0,xmm9
    72e311b02776:	movdqa xmm1,xmm3
    72e311b0277a:	addpd  xmm0,xmm1
    72e311b0277e:	movdqa xmm14,xmm0
    72e311b02783:	movdqu xmm15,XMMWORD PTR [rip+0x7b04]        # 0x72e311b0a290
    72e311b0278c:	pand   xmm14,xmm15
    72e311b02791:	movdqu xmm15,XMMWORD PTR [rip+0x7b06]        # 0x72e311b0a2a0
    72e311b0279a:	pcmpeqq xmm14,xmm15
    72e311b027a0:	movdqa xmm15,xmm0
    72e311b027a5:	cmpunordpd xmm15,xmm0
    72e311b027ab:	por    xmm14,xmm15
    72e311b027b0:	pmovmskb ecx,xmm14
    72e311b027b5:	jrcxz  0x72e311b027bc
    72e311b027b7:	jmp    0x72e311b035a2
    72e311b027bc:	movdqa xmm5,xmm0
    72e311b027c0:	movdqu XMMWORD PTR [r12+0x160],xmm5
    72e311b027ca:	movdqa xmm0,xmm12
    72e311b027cf:	movdqa xmm1,xmm10
    72e311b027d4:	addpd  xmm0,xmm1
    72e311b027d8:	movdqa xmm14,xmm0
    72e311b027dd:	movdqu xmm15,XMMWORD PTR [rip+0x7aaa]        # 0x72e311b0a290
    72e311b027e6:	pand   xmm14,xmm15
    72e311b027eb:	movdqu xmm15,XMMWORD PTR [rip+0x7aac]        # 0x72e311b0a2a0
    72e311b027f4:	pcmpeqq xmm14,xmm15
    72e311b027fa:	movdqa xmm15,xmm0
    72e311b027ff:	cmpunordpd xmm15,xmm0
    72e311b02805:	por    xmm14,xmm15
    72e311b0280a:	pmovmskb ecx,xmm14
    72e311b0280f:	jrcxz  0x72e311b02816
    72e311b02811:	jmp    0x72e311b035c7
    72e311b02816:	movdqa xmm3,xmm0
    72e311b0281a:	movdqu XMMWORD PTR [r12+0x120],xmm3
    72e311b02824:	mov    r13,r15
    72e311b02827:	add    r13,0x10
    72e311b0282b:	movdqu XMMWORD PTR [r15],xmm4
    72e311b02830:	mov    r14d,0x0
    72e311b02836:	mov    DWORD PTR [r12+0x32c],r14d
    72e311b0283e:	movdqu XMMWORD PTR [r13+0x0],xmm2
    72e311b02844:	add    r15,0x20
    72e311b02848:	mov    r13,r15
    72e311b0284b:	add    r13,0x10
    72e311b0284f:	movdqu XMMWORD PTR [r15],xmm5
    72e311b02854:	movdqu XMMWORD PTR [r13+0x0],xmm3
    72e311b0285a:	mov    rcx,QWORD PTR [r12+0x380]
    72e311b02862:	jrcxz  0x72e311b02869
    72e311b02864:	jmp    0x72e311b09ab9
    72e311b02869:	cmp    BYTE PTR [rsp+0x8],0x0
    72e311b0286e:	jne    0x72e311b00b39
    72e311b02874:	jmp    0x72e311b02879
    72e311b02879:	mov    r13d,DWORD PTR [r12+0x48]
    72e311b0287e:	add    r13d,0x1
    72e311b02882:	mov    QWORD PTR [r12+0x48],r13
    72e311b02887:	sub    r13d,0x1f4
    72e311b0288e:	mov    rcx,QWORD PTR [r12+0x380]
    72e311b02896:	jrcxz  0x72e311b0289d
    72e311b02898:	jmp    0x72e311b09b3e
    72e311b0289d:	jne    0x72e311b00b1b
    72e311b028a3:	mov    r11,rax
    72e311b028a6:	lahf
    72e311b028a7:	seto   al
    72e311b028aa:	mov    WORD PTR [rsp],ax
    72e311b028ae:	mov    rax,r11
    72e311b028b1:	jmp    0x72e311b028b6
    72e311b028b6:	mov    r13d,0x0
    72e311b028bc:	mov    QWORD PTR [r12+0x48],r13
    72e311b028c1:	mov    r13,QWORD PTR [r12+0xf8]
    72e311b028c9:	mov    r14,r13
    72e311b028cc:	add    r14,0x140
    72e311b028d3:	mov    r15,QWORD PTR [r14]
    72e311b028d6:	mov    QWORD PTR [r12+0xe8],r15
    72e311b028de:	mov    r14,r13
    72e311b028e1:	add    r14,0x130
    72e311b028e8:	mov    r15,r14
    72e311b028eb:	add    r15,0x8
    72e311b028ef:	mov    rbp,QWORD PTR [r14]
    72e311b028f2:	mov    r14,QWORD PTR [r15]
    72e311b028f5:	mov    r15d,0x0
    72e311b028fb:	mov    QWORD PTR [r12+0x1a0],rbp
    72e311b02903:	mov    QWORD PTR [r12+0x1a8],r15
    72e311b0290b:	mov    r15d,0x0
    72e311b02911:	mov    QWORD PTR [r12+0x190],r14
    72e311b02919:	mov    QWORD PTR [r12+0x198],r15
    72e311b02921:	mov    r14,r13
    72e311b02924:	add    r14,0x120
    72e311b0292b:	mov    r15,r14
    72e311b0292e:	add    r15,0x8
    72e311b02932:	mov    rbp,QWORD PTR [r14]
    72e311b02935:	mov    r14,QWORD PTR [r15]
    72e311b02938:	mov    r15d,0x0
    72e311b0293e:	mov    QWORD PTR [r12+0x1c0],rbp
    72e311b02946:	mov    QWORD PTR [r12+0x1c8],r15
    72e311b0294e:	mov    r15d,0x0
    72e311b02954:	mov    QWORD PTR [r12+0x1b0],r14
    72e311b0295c:	mov    QWORD PTR [r12+0x1b8],r15
    72e311b02964:	mov    r14,r13
    72e311b02967:	add    r14,0x110
    72e311b0296e:	mov    r15,r14
    72e311b02971:	add    r15,0x8
    72e311b02975:	mov    rbp,QWORD PTR [r14]
    72e311b02978:	mov    r14,QWORD PTR [r15]
    72e311b0297b:	mov    r15d,0x0
    72e311b02981:	mov    QWORD PTR [r12+0x1e0],rbp
    72e311b02989:	mov    QWORD PTR [r12+0x1e8],r15
    72e311b02991:	mov    r15d,0x0
    72e311b02997:	mov    QWORD PTR [r12+0x1d0],r14
    72e311b0299f:	mov    QWORD PTR [r12+0x1d8],r15
    72e311b029a7:	mov    r14,r13
    72e311b029aa:	add    r14,0x100
    72e311b029b1:	mov    r15,r14
    72e311b029b4:	add    r15,0x8
    72e311b029b8:	mov    rbp,QWORD PTR [r14]
    72e311b029bb:	mov    r14,QWORD PTR [r15]
    72e311b029be:	mov    r15d,0x0
    72e311b029c4:	mov    QWORD PTR [r12+0x200],rbp
    72e311b029cc:	mov    QWORD PTR [r12+0x208],r15
    72e311b029d4:	mov    r15d,0x0
    72e311b029da:	mov    QWORD PTR [r12+0x1f0],r14
    72e311b029e2:	mov    QWORD PTR [r12+0x1f8],r15
    72e311b029ea:	mov    r14d,0x430000
    72e311b029f0:	mov    QWORD PTR [r12+0x40],r14
    72e311b029f5:	mov    r14d,0x430510
    72e311b029fb:	mov    r15,QWORD PTR [r14]
    72e311b029fe:	mov    r14d,0x0
    72e311b02a04:	mov    QWORD PTR [r12+0x110],r15
    72e311b02a0c:	mov    QWORD PTR [r12+0x118],r14
    72e311b02a14:	add    r13,0x150
    72e311b02a1b:	mov    QWORD PTR [r12+0xf8],r13
    72e311b02a23:	jmp    0x72e311b02a28
    72e311b02a28:	mov    r13,QWORD PTR [r12+0x48]
    72e311b02a2d:	mov    r14,QWORD PTR [r12+0x50]
    72e311b02a32:	add    r14,r13
    72e311b02a35:	movdqu xmm2,XMMWORD PTR [r14]
    72e311b02a3a:	movdqu XMMWORD PTR [r12+0x120],xmm2
    72e311b02a44:	add    r13,0x10
    72e311b02a48:	mov    QWORD PTR [r12+0x48],r13
    72e311b02a4d:	sub    r13,0x200
    72e311b02a54:	mov    r13,QWORD PTR [r12+0x128]
    72e311b02a5c:	mov    r14d,0x0
    72e311b02a62:	mov    QWORD PTR [r12+0x130],r13
    72e311b02a6a:	mov    QWORD PTR [r12+0x138],r14
    72e311b02a72:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    72e311b02a7c:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    72e311b02a86:	movdqa xmm0,xmm2
    72e311b02a8a:	movdqa xmm1,xmm3
    72e311b02a8e:	movq   xmm0,xmm0
    72e311b02a92:	movq   xmm1,xmm1
    72e311b02a96:	addsd  xmm0,xmm1
    72e311b02a9a:	movdqa xmm14,xmm0
    72e311b02a9f:	movdqu xmm15,XMMWORD PTR [rip+0x77e8]        # 0x72e311b0a290
    72e311b02aa8:	pand   xmm14,xmm15
    72e311b02aad:	movdqu xmm15,XMMWORD PTR [rip+0x77ea]        # 0x72e311b0a2a0
    72e311b02ab6:	pcmpeqq xmm14,xmm15
    72e311b02abc:	movdqa xmm15,xmm0
    72e311b02ac1:	cmpunordpd xmm15,xmm0
    72e311b02ac7:	por    xmm14,xmm15
    72e311b02acc:	pmovmskb ecx,xmm14
    72e311b02ad1:	jrcxz  0x72e311b02ad8
    72e311b02ad3:	jmp    0x72e311b035ed
    72e311b02ad8:	movdqa xmm4,xmm0
    72e311b02adc:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    72e311b02ae6:	movdqa xmm0,xmm4
    72e311b02aea:	movdqa xmm1,xmm2
    72e311b02aee:	movq   xmm0,xmm0
    72e311b02af2:	movq   xmm1,xmm1
    72e311b02af6:	addsd  xmm0,xmm1
    72e311b02afa:	movdqa xmm14,xmm0
    72e311b02aff:	movdqu xmm15,XMMWORD PTR [rip+0x7788]        # 0x72e311b0a290
    72e311b02b08:	pand   xmm14,xmm15
    72e311b02b0d:	movdqu xmm15,XMMWORD PTR [rip+0x778a]        # 0x72e311b0a2a0
    72e311b02b16:	pcmpeqq xmm14,xmm15
    72e311b02b1c:	movdqa xmm15,xmm0
    72e311b02b21:	cmpunordpd xmm15,xmm0
    72e311b02b27:	por    xmm14,xmm15
    72e311b02b2c:	pmovmskb ecx,xmm14
    72e311b02b31:	jrcxz  0x72e311b02b38
    72e311b02b33:	jmp    0x72e311b0362c
    72e311b02b38:	movdqa xmm3,xmm0
    72e311b02b3c:	movdqu XMMWORD PTR [r12+0x110],xmm3
    72e311b02b46:	mov    rcx,QWORD PTR [r12+0x380]
    72e311b02b4e:	jrcxz  0x72e311b02b55
    72e311b02b50:	jmp    0x72e311b09bd2
    72e311b02b55:	jne    0x72e311b02b6e
    72e311b02b5b:	mov    r11,rax
    72e311b02b5e:	lahf
    72e311b02b5f:	seto   al
    72e311b02b62:	mov    WORD PTR [rsp],ax
    72e311b02b66:	mov    rax,r11
    72e311b02b69:	jmp    0x72e311b02b81
    72e311b02b6e:	mov    r11,rax
    72e311b02b71:	lahf
    72e311b02b72:	seto   al
    72e311b02b75:	mov    WORD PTR [rsp],ax
    72e311b02b79:	mov    rax,r11
    72e311b02b7c:	jmp    0x72e311b02a28
    72e311b02b81:	mov    r13,QWORD PTR [r12+0x40]
    72e311b02b86:	add    r13,0x510
    72e311b02b8d:	mov    r14,QWORD PTR [r12+0x110]
    72e311b02b95:	mov    QWORD PTR [r13+0x0],r14
    72e311b02b99:	mov    r13d,0x0
    72e311b02b9f:	mov    DWORD PTR [r12+0x32c],r13d
    72e311b02ba7:	mov    rcx,QWORD PTR [r12+0x380]
    72e311b02baf:	jrcxz  0x72e311b02bb6
    72e311b02bb1:	jmp    0x72e311b09c66
    72e311b02bb6:	mov    r13,QWORD PTR [r12+0xf0]
    72e311b02bbe:	mov    QWORD PTR [r12+0x100],r13
    72e311b02bc6:	mov    r11,QWORD PTR [rsp]
    72e311b02bca:	mov    QWORD PTR [r12+0x398],r11
    72e311b02bd2:	mov    rdi,QWORD PTR [r12+0x100]
    72e311b02bda:	add    rsp,0x150
    72e311b02be1:	movabs r11,0x62e306617940
    72e311b02beb:	jmp    r11
    72e311b02bee:	movdqa xmm0,xmm2
    72e311b02bf2:	movdqa xmm1,xmm3
    72e311b02bf6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02bff:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02c08:	call   0x72e311b03670
    72e311b02c0d:	jmp    0x72e311b00571
    72e311b02c12:	movdqa xmm0,xmm2
    72e311b02c16:	movdqa xmm1,xmm3
    72e311b02c1a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02c23:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02c2c:	call   0x72e311b03670
    72e311b02c31:	jmp    0x72e311b005fd
    72e311b02c36:	movdqa xmm0,xmm9
    72e311b02c3b:	movdqa xmm1,xmm2
    72e311b02c3f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02c48:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02c51:	call   0x72e311b03740
    72e311b02c56:	jmp    0x72e311b00d57
    72e311b02c5b:	movdqa xmm0,xmm8
    72e311b02c60:	movdqa xmm1,xmm2
    72e311b02c64:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02c6d:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02c76:	call   0x72e311b03850
    72e311b02c7b:	jmp    0x72e311b00db6
    72e311b02c80:	movdqa xmm0,xmm9
    72e311b02c85:	movdqa xmm1,xmm7
    72e311b02c89:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02c92:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02c9b:	call   0x72e311b03970
    72e311b02ca0:	jmp    0x72e311b00e2b
    72e311b02ca5:	movdqa xmm0,xmm9
    72e311b02caa:	movdqa xmm1,xmm6
    72e311b02cae:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02cb7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02cc0:	call   0x72e311b03a90
    72e311b02cc5:	jmp    0x72e311b00e7b
    72e311b02cca:	movdqa xmm0,xmm9
    72e311b02ccf:	movdqa xmm1,xmm6
    72e311b02cd3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02cdc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02ce5:	call   0x72e311b03bb0
    72e311b02cea:	jmp    0x72e311b00ed4
    72e311b02cef:	movdqa xmm0,xmm9
    72e311b02cf4:	movdqa xmm1,xmm2
    72e311b02cf8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02d01:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02d0a:	call   0x72e311b03ce0
    72e311b02d0f:	jmp    0x72e311b00f75
    72e311b02d14:	mov    r11,rax
    72e311b02d17:	lahf
    72e311b02d18:	seto   al
    72e311b02d1b:	mov    WORD PTR [rsp],ax
    72e311b02d1f:	mov    rax,r11
    72e311b02d22:	movdqa xmm0,xmm10
    72e311b02d27:	movdqa xmm1,xmm9
    72e311b02d2c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02d35:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02d3e:	call   0x72e311b03e20
    72e311b02d43:	mov    r11,rax
    72e311b02d46:	movzx  eax,WORD PTR [rsp]
    72e311b02d4a:	add    al,0x7f
    72e311b02d4c:	sahf
    72e311b02d4d:	mov    rax,r11
    72e311b02d50:	jmp    0x72e311b00fe0
    72e311b02d55:	mov    r11,rax
    72e311b02d58:	lahf
    72e311b02d59:	seto   al
    72e311b02d5c:	mov    WORD PTR [rsp],ax
    72e311b02d60:	mov    rax,r11
    72e311b02d63:	movdqa xmm0,xmm8
    72e311b02d68:	movdqa xmm1,xmm10
    72e311b02d6d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02d76:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02d7f:	call   0x72e311b03e20
    72e311b02d84:	mov    r11,rax
    72e311b02d87:	movzx  eax,WORD PTR [rsp]
    72e311b02d8b:	add    al,0x7f
    72e311b02d8d:	sahf
    72e311b02d8e:	mov    rax,r11
    72e311b02d91:	jmp    0x72e311b01040
    72e311b02d96:	mov    r11,rax
    72e311b02d99:	lahf
    72e311b02d9a:	seto   al
    72e311b02d9d:	mov    WORD PTR [rsp],ax
    72e311b02da1:	mov    rax,r11
    72e311b02da4:	movdqa xmm0,xmm7
    72e311b02da8:	movdqa xmm1,xmm10
    72e311b02dad:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02db6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02dbf:	call   0x72e311b03ff0
    72e311b02dc4:	mov    r11,rax
    72e311b02dc7:	movzx  eax,WORD PTR [rsp]
    72e311b02dcb:	add    al,0x7f
    72e311b02dcd:	sahf
    72e311b02dce:	mov    rax,r11
    72e311b02dd1:	jmp    0x72e311b01099
    72e311b02dd6:	movdqa xmm0,xmm12
    72e311b02ddb:	movdqa xmm1,xmm9
    72e311b02de0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02de9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02df2:	call   0x72e311b041b0
    72e311b02df7:	jmp    0x72e311b01211
    72e311b02dfc:	movdqa xmm0,xmm6
    72e311b02e00:	movdqa xmm1,xmm4
    72e311b02e04:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02e0d:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02e16:	call   0x72e311b043b0
    72e311b02e1b:	jmp    0x72e311b0127f
    72e311b02e20:	movdqa xmm0,xmm8
    72e311b02e25:	movdqa xmm1,xmm11
    72e311b02e2a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02e33:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02e3c:	call   0x72e311b045a0
    72e311b02e41:	jmp    0x72e311b012da
    72e311b02e46:	movdqa xmm0,xmm5
    72e311b02e4a:	movdqa xmm1,xmm2
    72e311b02e4e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02e57:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02e60:	call   0x72e311b04790
    72e311b02e65:	jmp    0x72e311b01337
    72e311b02e6a:	movdqa xmm0,xmm9
    72e311b02e6f:	movdqa xmm1,xmm5
    72e311b02e73:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02e7c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02e85:	call   0x72e311b04960
    72e311b02e8a:	jmp    0x72e311b0139f
    72e311b02e8f:	movdqa xmm0,xmm13
    72e311b02e94:	movdqa xmm1,xmm2
    72e311b02e98:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02ea1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02eaa:	call   0x72e311b04b40
    72e311b02eaf:	jmp    0x72e311b01418
    72e311b02eb4:	movdqa xmm0,xmm9
    72e311b02eb9:	movdqa xmm1,xmm5
    72e311b02ebd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02ec6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02ecf:	call   0x72e311b04d30
    72e311b02ed4:	jmp    0x72e311b014a5
    72e311b02ed9:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    72e311b02ee3:	movdqa xmm1,xmm6
    72e311b02ee7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02ef0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02ef9:	call   0x72e311b04ef0
    72e311b02efe:	jmp    0x72e311b0159a
    72e311b02f03:	movdqa xmm0,xmm9
    72e311b02f08:	movdqa xmm1,xmm5
    72e311b02f0c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02f15:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02f1e:	call   0x72e311b050d0
    72e311b02f23:	jmp    0x72e311b015f8
    72e311b02f28:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    72e311b02f32:	movdqa xmm1,xmm11
    72e311b02f37:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02f40:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02f49:	call   0x72e311b052b0
    72e311b02f4e:	jmp    0x72e311b01671
    72e311b02f53:	movdqa xmm0,xmm12
    72e311b02f58:	movdqa xmm1,xmm8
    72e311b02f5d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02f66:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02f6f:	call   0x72e311b054a0
    72e311b02f74:	jmp    0x72e311b016cc
    72e311b02f79:	movdqa xmm0,xmm9
    72e311b02f7e:	movdqa xmm1,xmm5
    72e311b02f82:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02f8b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02f94:	call   0x72e311b05690
    72e311b02f99:	jmp    0x72e311b0174d
    72e311b02f9e:	movdqa xmm0,xmm4
    72e311b02fa2:	movdqa xmm1,xmm2
    72e311b02fa6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02faf:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02fb8:	call   0x72e311b05870
    72e311b02fbd:	jmp    0x72e311b017c0
    72e311b02fc2:	movdqa xmm0,xmm13
    72e311b02fc7:	movdqa xmm1,xmm2
    72e311b02fcb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02fd4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b02fdd:	call   0x72e311b05a50
    72e311b02fe2:	jmp    0x72e311b01829
    72e311b02fe7:	movdqa xmm0,xmm5
    72e311b02feb:	movdqa xmm1,xmm2
    72e311b02fef:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b02ff8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03001:	call   0x72e311b05c30
    72e311b03006:	jmp    0x72e311b018a1
    72e311b0300b:	movdqa xmm0,xmm3
    72e311b0300f:	movdqa xmm1,xmm6
    72e311b03013:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b0301c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03025:	call   0x72e311b05e10
    72e311b0302a:	jmp    0x72e311b01914
    72e311b0302f:	movdqa xmm0,xmm5
    72e311b03033:	movdqa xmm1,xmm2
    72e311b03037:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03040:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03049:	call   0x72e311b06000
    72e311b0304e:	jmp    0x72e311b019b6
    72e311b03053:	movdqa xmm0,xmm10
    72e311b03058:	movdqa xmm1,xmm12
    72e311b0305d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03066:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b0306f:	call   0x72e311b061f0
    72e311b03074:	jmp    0x72e311b01a27
    72e311b03079:	movdqa xmm0,xmm7
    72e311b0307d:	movdqa xmm1,xmm2
    72e311b03081:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b0308a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03093:	call   0x72e311b063f0
    72e311b03098:	jmp    0x72e311b01a7a
    72e311b0309d:	movdqa xmm0,xmm11
    72e311b030a2:	movdqa xmm1,xmm13
    72e311b030a7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b030b0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b030b9:	call   0x72e311b065d0
    72e311b030be:	jmp    0x72e311b01acb
    72e311b030c3:	movdqa xmm0,xmm5
    72e311b030c7:	movdqa xmm1,xmm7
    72e311b030cb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b030d4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b030dd:	call   0x72e311b067b0
    72e311b030e2:	jmp    0x72e311b01b28
    72e311b030e7:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    72e311b030f1:	movdqa xmm1,xmm7
    72e311b030f5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b030fe:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03107:	call   0x72e311b06980
    72e311b0310c:	jmp    0x72e311b01b82
    72e311b03111:	movdqa xmm0,xmm8
    72e311b03116:	movdqa xmm1,xmm4
    72e311b0311a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03123:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b0312c:	call   0x72e311b06b50
    72e311b03131:	jmp    0x72e311b01bd1
    72e311b03136:	movdqa xmm0,xmm9
    72e311b0313b:	movdqa xmm1,xmm6
    72e311b0313f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03148:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03151:	call   0x72e311b06d30
    72e311b03156:	jmp    0x72e311b01c2b
    72e311b0315b:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    72e311b03165:	movdqa xmm1,xmm7
    72e311b03169:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03172:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b0317b:	call   0x72e311b06f00
    72e311b03180:	jmp    0x72e311b01c8e
    72e311b03185:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    72e311b0318f:	movdqa xmm1,xmm7
    72e311b03193:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b0319c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b031a5:	call   0x72e311b070c0
    72e311b031aa:	jmp    0x72e311b01ce7
    72e311b031af:	movdqa xmm0,xmm3
    72e311b031b3:	movdqa xmm1,xmm10
    72e311b031b8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b031c1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b031ca:	call   0x72e311b07290
    72e311b031cf:	jmp    0x72e311b01d41
    72e311b031d4:	movdqa xmm0,xmm2
    72e311b031d8:	movdqa xmm1,xmm11
    72e311b031dd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b031e6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b031ef:	call   0x72e311b07460
    72e311b031f4:	jmp    0x72e311b01d9a
    72e311b031f9:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    72e311b03203:	movdqa xmm1,xmm2
    72e311b03207:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03210:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03219:	call   0x72e311b07620
    72e311b0321e:	jmp    0x72e311b01e07
    72e311b03223:	movdqa xmm0,xmm4
    72e311b03227:	movdqa xmm1,xmm5
    72e311b0322b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03234:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b0323d:	call   0x72e311b077d0
    72e311b03242:	jmp    0x72e311b01e60
    72e311b03247:	movdqa xmm0,xmm12
    72e311b0324c:	movdqa xmm1,xmm6
    72e311b03250:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03259:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03262:	call   0x72e311b079a0
    72e311b03267:	jmp    0x72e311b01eba
    72e311b0326c:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    72e311b03276:	movdqa xmm1,xmm2
    72e311b0327a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03283:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b0328c:	call   0x72e311b067b0
    72e311b03291:	jmp    0x72e311b01f9a
    72e311b03296:	movdqa xmm0,xmm7
    72e311b0329a:	movdqa xmm1,xmm8
    72e311b0329f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b032a8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b032b1:	call   0x72e311b06b50
    72e311b032b6:	jmp    0x72e311b01fea
    72e311b032bb:	movdqa xmm0,xmm3
    72e311b032bf:	movdqa xmm1,xmm9
    72e311b032c4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b032cd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b032d6:	call   0x72e311b07b60
    72e311b032db:	jmp    0x72e311b0203a
    72e311b032e0:	movdqa xmm0,xmm6
    72e311b032e4:	movdqa xmm1,xmm2
    72e311b032e8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b032f1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b032fa:	call   0x72e311b07d30
    72e311b032ff:	jmp    0x72e311b02097
    72e311b03304:	movdqa xmm0,xmm6
    72e311b03308:	movdqa xmm1,xmm2
    72e311b0330c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03315:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b0331e:	call   0x72e311b070c0
    72e311b03323:	jmp    0x72e311b020fe
    72e311b03328:	movdqa xmm0,xmm5
    72e311b0332c:	movdqa xmm1,xmm2
    72e311b03330:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03339:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03342:	call   0x72e311b07ef0
    72e311b03347:	jmp    0x72e311b0215c
    72e311b0334c:	movdqa xmm0,xmm10
    72e311b03351:	movdqa xmm1,xmm11
    72e311b03356:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b0335f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03368:	call   0x72e311b080c0
    72e311b0336d:	jmp    0x72e311b021b6
    72e311b03372:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    72e311b0337c:	movdqa xmm1,xmm2
    72e311b03380:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03389:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03392:	call   0x72e311b07620
    72e311b03397:	jmp    0x72e311b02219
    72e311b0339c:	movdqa xmm0,xmm4
    72e311b033a0:	movdqa xmm1,xmm3
    72e311b033a4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b033ad:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b033b6:	call   0x72e311b077d0
    72e311b033bb:	jmp    0x72e311b02272
    72e311b033c0:	movdqa xmm0,xmm3
    72e311b033c4:	movdqa xmm1,xmm2
    72e311b033c8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b033d1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b033da:	call   0x72e311b08290
    72e311b033df:	jmp    0x72e311b022da
    72e311b033e4:	movdqa xmm0,xmm12
    72e311b033e9:	movdqa xmm1,xmm8
    72e311b033ee:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b033f7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03400:	call   0x72e311b08460
    72e311b03405:	jmp    0x72e311b02334
    72e311b0340a:	movdqa xmm0,xmm8
    72e311b0340f:	movdqa xmm1,xmm2
    72e311b03413:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b0341c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03425:	call   0x72e311b067b0
    72e311b0342a:	jmp    0x72e311b0239c
    72e311b0342f:	movdqa xmm0,xmm7
    72e311b03433:	movdqa xmm1,xmm6
    72e311b03437:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03440:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03449:	call   0x72e311b08630
    72e311b0344e:	jmp    0x72e311b023f5
    72e311b03453:	movdqa xmm0,xmm5
    72e311b03457:	movdqa xmm1,xmm9
    72e311b0345c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03465:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b0346e:	call   0x72e311b087f0
    72e311b03473:	jmp    0x72e311b02465
    72e311b03478:	movdqa xmm0,xmm6
    72e311b0347c:	movdqa xmm1,xmm5
    72e311b03480:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03489:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03492:	call   0x72e311b089b0
    72e311b03497:	jmp    0x72e311b024cc
    72e311b0349c:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    72e311b034a6:	movdqa xmm1,xmm5
    72e311b034aa:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b034b3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b034bc:	call   0x72e311b08b60
    72e311b034c1:	jmp    0x72e311b02530
    72e311b034c6:	movdqa xmm0,xmm10
    72e311b034cb:	movdqa xmm1,xmm4
    72e311b034cf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b034d8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b034e1:	call   0x72e311b08d20
    72e311b034e6:	jmp    0x72e311b02589
    72e311b034eb:	movdqa xmm0,xmm3
    72e311b034ef:	movdqa xmm1,xmm11
    72e311b034f4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b034fd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03506:	call   0x72e311b06b50
    72e311b0350b:	jmp    0x72e311b025ff
    72e311b03510:	movdqa xmm0,xmm10
    72e311b03515:	movdqa xmm1,xmm5
    72e311b03519:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03522:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b0352b:	call   0x72e311b08ef0
    72e311b03530:	jmp    0x72e311b0265e
    72e311b03535:	movdqa xmm0,xmm4
    72e311b03539:	movdqa xmm1,xmm5
    72e311b0353d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b03546:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b0354f:	call   0x72e311b090c0
    72e311b03554:	jmp    0x72e311b026bb
    72e311b03559:	movdqa xmm0,xmm2
    72e311b0355d:	movdqa xmm1,xmm8
    72e311b03562:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b0356b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03574:	call   0x72e311b079a0
    72e311b03579:	jmp    0x72e311b0270b
    72e311b0357e:	movdqa xmm0,xmm7
    72e311b03582:	movdqa xmm1,xmm6
    72e311b03586:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b0358f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03598:	call   0x72e311b09290
    72e311b0359d:	jmp    0x72e311b02763
    72e311b035a2:	movdqa xmm0,xmm9
    72e311b035a7:	movdqa xmm1,xmm3
    72e311b035ab:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b035b4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b035bd:	call   0x72e311b09440
    72e311b035c2:	jmp    0x72e311b027bc
    72e311b035c7:	movdqa xmm0,xmm12
    72e311b035cc:	movdqa xmm1,xmm10
    72e311b035d1:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b035da:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b035e3:	call   0x72e311b095e0
    72e311b035e8:	jmp    0x72e311b02816
    72e311b035ed:	mov    r11,rax
    72e311b035f0:	lahf
    72e311b035f1:	seto   al
    72e311b035f4:	mov    WORD PTR [rsp],ax
    72e311b035f8:	mov    rax,r11
    72e311b035fb:	movdqa xmm0,xmm2
    72e311b035ff:	movdqa xmm1,xmm3
    72e311b03603:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b0360c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03615:	call   0x72e311b09770
    72e311b0361a:	mov    r11,rax
    72e311b0361d:	movzx  eax,WORD PTR [rsp]
    72e311b03621:	add    al,0x7f
    72e311b03623:	sahf
    72e311b03624:	mov    rax,r11
    72e311b03627:	jmp    0x72e311b02ad8
    72e311b0362c:	mov    r11,rax
    72e311b0362f:	lahf
    72e311b03630:	seto   al
    72e311b03633:	mov    WORD PTR [rsp],ax
    72e311b03637:	mov    rax,r11
    72e311b0363a:	movdqa xmm0,xmm4
    72e311b0363e:	movdqa xmm1,xmm2
    72e311b03642:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72e311b0364b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72e311b03654:	call   0x72e311b098d0
    72e311b03659:	mov    r11,rax
    72e311b0365c:	movzx  eax,WORD PTR [rsp]
    72e311b03660:	add    al,0x7f
    72e311b03662:	sahf
    72e311b03663:	mov    rax,r11
    72e311b03666:	jmp    0x72e311b02b38
    72e311b0366b:	nop    DWORD PTR [rax+rax*1+0x0]
    72e311b03670:	sub    rsp,0x8
    72e311b03674:	mov    QWORD PTR [r12+0x378],0x3
    72e311b03680:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b03686:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b0368c:	mov    QWORD PTR [r12+0x108],rbx
    72e311b03694:	stmxcsr DWORD PTR [r12-0x28]
    72e311b0369a:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b0369f:	test   r10d,0x3f
    72e311b036a6:	je     0x72e311b036cb
    72e311b036ac:	mov    r11d,r10d
    72e311b036af:	shr    r10d,1
    72e311b036b2:	and    r10d,0x1e
    72e311b036b6:	and    r11d,0x1
    72e311b036ba:	or     r10d,r11d
    72e311b036bd:	or     DWORD PTR [r12+0x314],r10d
    72e311b036c5:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b036cb:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b036d1:	lea    rdi,[rsp+0x110]
    72e311b036d9:	lea    rsi,[rsp+0xf0]
    72e311b036e1:	lea    rdx,[rsp+0x100]
    72e311b036e9:	mov    ecx,0x16
    72e311b036ee:	mov    r8d,0x0
    72e311b036f4:	lea    r9,[r12+0x314]
    72e311b036fc:	movabs r11,0x62e30647e650
    72e311b03706:	call   r11
    72e311b03709:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b0370f:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b03715:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b0371b:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b03723:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0372f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b03738:	add    rsp,0x8
    72e311b0373c:	ret
    72e311b0373d:	nop    DWORD PTR [rax]
    72e311b03740:	sub    rsp,0x8
    72e311b03744:	mov    QWORD PTR [r12+0x378],0x3
    72e311b03750:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b03756:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b0375c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b03762:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b0376c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b03776:	mov    QWORD PTR [r12+0x108],rbx
    72e311b0377e:	stmxcsr DWORD PTR [r12-0x28]
    72e311b03784:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b03789:	test   r10d,0x3f
    72e311b03790:	je     0x72e311b037b5
    72e311b03796:	mov    r11d,r10d
    72e311b03799:	shr    r10d,1
    72e311b0379c:	and    r10d,0x1e
    72e311b037a0:	and    r11d,0x1
    72e311b037a4:	or     r10d,r11d
    72e311b037a7:	or     DWORD PTR [r12+0x314],r10d
    72e311b037af:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b037b5:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b037bb:	lea    rdi,[rsp+0x110]
    72e311b037c3:	lea    rsi,[rsp+0xf0]
    72e311b037cb:	lea    rdx,[rsp+0x100]
    72e311b037d3:	mov    ecx,0x16
    72e311b037d8:	mov    r8d,0x0
    72e311b037de:	lea    r9,[r12+0x314]
    72e311b037e6:	movabs r11,0x62e30647e650
    72e311b037f0:	call   r11
    72e311b037f3:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b037f9:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b037ff:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b03805:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b0380b:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b03815:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b0381f:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b03827:	mov    QWORD PTR [r12+0x378],0x2
    72e311b03833:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b0383c:	add    rsp,0x8
    72e311b03840:	ret
    72e311b03841:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b03850:	sub    rsp,0x8
    72e311b03854:	mov    QWORD PTR [r12+0x378],0x3
    72e311b03860:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b03866:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b0386c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b03872:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b0387c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b03886:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b03890:	mov    QWORD PTR [r12+0x108],rbx
    72e311b03898:	stmxcsr DWORD PTR [r12-0x28]
    72e311b0389e:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b038a3:	test   r10d,0x3f
    72e311b038aa:	je     0x72e311b038cf
    72e311b038b0:	mov    r11d,r10d
    72e311b038b3:	shr    r10d,1
    72e311b038b6:	and    r10d,0x1e
    72e311b038ba:	and    r11d,0x1
    72e311b038be:	or     r10d,r11d
    72e311b038c1:	or     DWORD PTR [r12+0x314],r10d
    72e311b038c9:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b038cf:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b038d5:	lea    rdi,[rsp+0x110]
    72e311b038dd:	lea    rsi,[rsp+0xf0]
    72e311b038e5:	lea    rdx,[rsp+0x100]
    72e311b038ed:	mov    ecx,0x56
    72e311b038f2:	mov    r8d,0x0
    72e311b038f8:	lea    r9,[r12+0x314]
    72e311b03900:	movabs r11,0x62e30647e650
    72e311b0390a:	call   r11
    72e311b0390d:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b03913:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b03919:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b0391f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b03925:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b0392f:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b03939:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b03943:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0394b:	mov    QWORD PTR [r12+0x378],0x2
    72e311b03957:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b03960:	add    rsp,0x8
    72e311b03964:	ret
    72e311b03965:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b03970:	sub    rsp,0x8
    72e311b03974:	mov    QWORD PTR [r12+0x378],0x3
    72e311b03980:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b03986:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b0398c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b03992:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b0399c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b039a6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b039b0:	mov    QWORD PTR [r12+0x108],rbx
    72e311b039b8:	stmxcsr DWORD PTR [r12-0x28]
    72e311b039be:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b039c3:	test   r10d,0x3f
    72e311b039ca:	je     0x72e311b039ef
    72e311b039d0:	mov    r11d,r10d
    72e311b039d3:	shr    r10d,1
    72e311b039d6:	and    r10d,0x1e
    72e311b039da:	and    r11d,0x1
    72e311b039de:	or     r10d,r11d
    72e311b039e1:	or     DWORD PTR [r12+0x314],r10d
    72e311b039e9:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b039ef:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b039f5:	lea    rdi,[rsp+0x110]
    72e311b039fd:	lea    rsi,[rsp+0xf0]
    72e311b03a05:	lea    rdx,[rsp+0x100]
    72e311b03a0d:	mov    ecx,0x16
    72e311b03a12:	mov    r8d,0x0
    72e311b03a18:	lea    r9,[r12+0x314]
    72e311b03a20:	movabs r11,0x62e30647e650
    72e311b03a2a:	call   r11
    72e311b03a2d:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b03a33:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b03a39:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b03a3f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b03a45:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b03a4f:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b03a59:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b03a63:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b03a6b:	mov    QWORD PTR [r12+0x378],0x2
    72e311b03a77:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b03a80:	add    rsp,0x8
    72e311b03a84:	ret
    72e311b03a85:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b03a90:	sub    rsp,0x8
    72e311b03a94:	mov    QWORD PTR [r12+0x378],0x3
    72e311b03aa0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b03aa6:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b03aac:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b03ab6:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b03ac0:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b03aca:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b03ad4:	mov    QWORD PTR [r12+0x108],rbx
    72e311b03adc:	stmxcsr DWORD PTR [r12-0x28]
    72e311b03ae2:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b03ae7:	test   r10d,0x3f
    72e311b03aee:	je     0x72e311b03b13
    72e311b03af4:	mov    r11d,r10d
    72e311b03af7:	shr    r10d,1
    72e311b03afa:	and    r10d,0x1e
    72e311b03afe:	and    r11d,0x1
    72e311b03b02:	or     r10d,r11d
    72e311b03b05:	or     DWORD PTR [r12+0x314],r10d
    72e311b03b0d:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b03b13:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b03b19:	lea    rdi,[rsp+0x110]
    72e311b03b21:	lea    rsi,[rsp+0xf0]
    72e311b03b29:	lea    rdx,[rsp+0x100]
    72e311b03b31:	mov    ecx,0x16
    72e311b03b36:	mov    r8d,0x0
    72e311b03b3c:	lea    r9,[r12+0x314]
    72e311b03b44:	movabs r11,0x62e30647e650
    72e311b03b4e:	call   r11
    72e311b03b51:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b03b57:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b03b5d:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b03b63:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b03b6d:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b03b77:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b03b81:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b03b8b:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b03b93:	mov    QWORD PTR [r12+0x378],0x2
    72e311b03b9f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b03ba8:	add    rsp,0x8
    72e311b03bac:	ret
    72e311b03bad:	nop    DWORD PTR [rax]
    72e311b03bb0:	sub    rsp,0x8
    72e311b03bb4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b03bc0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b03bc6:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b03bcc:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b03bd2:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b03bdc:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b03be6:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b03bf0:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b03bfa:	mov    QWORD PTR [r12+0x108],rbx
    72e311b03c02:	stmxcsr DWORD PTR [r12-0x28]
    72e311b03c08:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b03c0d:	test   r10d,0x3f
    72e311b03c14:	je     0x72e311b03c39
    72e311b03c1a:	mov    r11d,r10d
    72e311b03c1d:	shr    r10d,1
    72e311b03c20:	and    r10d,0x1e
    72e311b03c24:	and    r11d,0x1
    72e311b03c28:	or     r10d,r11d
    72e311b03c2b:	or     DWORD PTR [r12+0x314],r10d
    72e311b03c33:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b03c39:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b03c3f:	lea    rdi,[rsp+0x110]
    72e311b03c47:	lea    rsi,[rsp+0xf0]
    72e311b03c4f:	lea    rdx,[rsp+0x100]
    72e311b03c57:	mov    ecx,0x16
    72e311b03c5c:	mov    r8d,0x0
    72e311b03c62:	lea    r9,[r12+0x314]
    72e311b03c6a:	movabs r11,0x62e30647e650
    72e311b03c74:	call   r11
    72e311b03c77:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b03c7d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b03c83:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b03c89:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b03c8f:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b03c99:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b03ca3:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b03cad:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b03cb7:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b03cbf:	mov    QWORD PTR [r12+0x378],0x2
    72e311b03ccb:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b03cd4:	add    rsp,0x8
    72e311b03cd8:	ret
    72e311b03cd9:	nop    DWORD PTR [rax+0x0]
    72e311b03ce0:	sub    rsp,0x8
    72e311b03ce4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b03cf0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b03cf6:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b03cfc:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b03d06:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b03d10:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b03d1a:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b03d24:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b03d2e:	mov    QWORD PTR [r12+0x108],rbx
    72e311b03d36:	stmxcsr DWORD PTR [r12-0x28]
    72e311b03d3c:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b03d41:	test   r10d,0x3f
    72e311b03d48:	je     0x72e311b03d6d
    72e311b03d4e:	mov    r11d,r10d
    72e311b03d51:	shr    r10d,1
    72e311b03d54:	and    r10d,0x1e
    72e311b03d58:	and    r11d,0x1
    72e311b03d5c:	or     r10d,r11d
    72e311b03d5f:	or     DWORD PTR [r12+0x314],r10d
    72e311b03d67:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b03d6d:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b03d73:	lea    rdi,[rsp+0x110]
    72e311b03d7b:	lea    rsi,[rsp+0xf0]
    72e311b03d83:	lea    rdx,[rsp+0x100]
    72e311b03d8b:	mov    ecx,0x56
    72e311b03d90:	mov    r8d,0x0
    72e311b03d96:	lea    r9,[r12+0x314]
    72e311b03d9e:	movabs r11,0x62e30647e650
    72e311b03da8:	call   r11
    72e311b03dab:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b03db1:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b03db7:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b03dbd:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b03dc7:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b03dd1:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b03ddb:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b03de5:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b03def:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b03df7:	mov    QWORD PTR [r12+0x378],0x2
    72e311b03e03:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b03e0c:	add    rsp,0x8
    72e311b03e10:	ret
    72e311b03e11:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b03e20:	sub    rsp,0x8
    72e311b03e24:	mov    QWORD PTR [r12+0x378],0x3
    72e311b03e30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b03e36:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b03e3c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b03e42:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b03e4c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b03e56:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b03e60:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b03e6a:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b03e74:	push   rdx
    72e311b03e75:	push   rsi
    72e311b03e76:	push   r10
    72e311b03e78:	push   r11
    72e311b03e7a:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b03e7f:	mov    r10d,edx
    72e311b03e82:	and    r10d,0xc000
    72e311b03e89:	shl    r10d,0x10
    72e311b03e8d:	mov    r11d,edx
    72e311b03e90:	and    r11d,0x100
    72e311b03e97:	shl    r11d,0x15
    72e311b03e9b:	or     r10d,r11d
    72e311b03e9e:	and    edx,0x1
    72e311b03ea1:	shl    edx,0x1c
    72e311b03ea4:	or     r10d,edx
    72e311b03ea7:	btc    r10,0x1d
    72e311b03eac:	mov    r11d,0xf0000000
    72e311b03eb2:	and    r11,r10
    72e311b03eb5:	movabs rsi,0xffffffff0fffffff
    72e311b03ebf:	and    rbx,rsi
    72e311b03ec2:	or     rbx,r11
    72e311b03ec5:	pop    r11
    72e311b03ec7:	pop    r10
    72e311b03ec9:	pop    rsi
    72e311b03eca:	pop    rdx
    72e311b03ecb:	mov    QWORD PTR [r12+0x108],rbx
    72e311b03ed3:	stmxcsr DWORD PTR [r12-0x28]
    72e311b03ed9:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b03ede:	test   r10d,0x3f
    72e311b03ee5:	je     0x72e311b03f0a
    72e311b03eeb:	mov    r11d,r10d
    72e311b03eee:	shr    r10d,1
    72e311b03ef1:	and    r10d,0x1e
    72e311b03ef5:	and    r11d,0x1
    72e311b03ef9:	or     r10d,r11d
    72e311b03efc:	or     DWORD PTR [r12+0x314],r10d
    72e311b03f04:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b03f0a:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b03f10:	lea    rdi,[rsp+0x110]
    72e311b03f18:	lea    rsi,[rsp+0xf0]
    72e311b03f20:	lea    rdx,[rsp+0x100]
    72e311b03f28:	mov    ecx,0x14
    72e311b03f2d:	mov    r8d,0x0
    72e311b03f33:	lea    r9,[r12+0x314]
    72e311b03f3b:	movabs r11,0x62e30647e650
    72e311b03f45:	call   r11
    72e311b03f48:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b03f4e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b03f54:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b03f5a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b03f60:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b03f6a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b03f74:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b03f7e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b03f88:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b03f92:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b03f9a:	mov    QWORD PTR [r12+0x378],0x2
    72e311b03fa6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b03faf:	mov    rdx,rbx
    72e311b03fb2:	shr    rdx,0x10
    72e311b03fb6:	and    edx,0xc000
    72e311b03fbc:	mov    rax,rbx
    72e311b03fbf:	shr    rax,0x15
    72e311b03fc3:	and    eax,0x100
    72e311b03fc8:	xor    eax,0x100
    72e311b03fcd:	or     edx,eax
    72e311b03fcf:	mov    rax,rbx
    72e311b03fd2:	shr    rax,0x1c
    72e311b03fd6:	and    eax,0x1
    72e311b03fd9:	or     edx,eax
    72e311b03fdb:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b03fe0:	add    rsp,0x8
    72e311b03fe4:	ret
    72e311b03fe5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b03ff0:	sub    rsp,0x8
    72e311b03ff4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b04000:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b04006:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b0400c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b04012:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b04018:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b04022:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b0402c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b04036:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b04040:	push   rdx
    72e311b04041:	push   rsi
    72e311b04042:	push   r10
    72e311b04044:	push   r11
    72e311b04046:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b0404b:	mov    r10d,edx
    72e311b0404e:	and    r10d,0xc000
    72e311b04055:	shl    r10d,0x10
    72e311b04059:	mov    r11d,edx
    72e311b0405c:	and    r11d,0x100
    72e311b04063:	shl    r11d,0x15
    72e311b04067:	or     r10d,r11d
    72e311b0406a:	and    edx,0x1
    72e311b0406d:	shl    edx,0x1c
    72e311b04070:	or     r10d,edx
    72e311b04073:	btc    r10,0x1d
    72e311b04078:	mov    r11d,0xf0000000
    72e311b0407e:	and    r11,r10
    72e311b04081:	movabs rsi,0xffffffff0fffffff
    72e311b0408b:	and    rbx,rsi
    72e311b0408e:	or     rbx,r11
    72e311b04091:	pop    r11
    72e311b04093:	pop    r10
    72e311b04095:	pop    rsi
    72e311b04096:	pop    rdx
    72e311b04097:	mov    QWORD PTR [r12+0x108],rbx
    72e311b0409f:	stmxcsr DWORD PTR [r12-0x28]
    72e311b040a5:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b040aa:	test   r10d,0x3f
    72e311b040b1:	je     0x72e311b040d6
    72e311b040b7:	mov    r11d,r10d
    72e311b040ba:	shr    r10d,1
    72e311b040bd:	and    r10d,0x1e
    72e311b040c1:	and    r11d,0x1
    72e311b040c5:	or     r10d,r11d
    72e311b040c8:	or     DWORD PTR [r12+0x314],r10d
    72e311b040d0:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b040d6:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b040dc:	lea    rdi,[rsp+0x110]
    72e311b040e4:	lea    rsi,[rsp+0xf0]
    72e311b040ec:	lea    rdx,[rsp+0x100]
    72e311b040f4:	mov    ecx,0x14
    72e311b040f9:	mov    r8d,0x0
    72e311b040ff:	lea    r9,[r12+0x314]
    72e311b04107:	movabs r11,0x62e30647e650
    72e311b04111:	call   r11
    72e311b04114:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b0411a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b04120:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b04126:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b0412c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b04132:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b0413c:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b04146:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b04150:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b0415a:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b04162:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0416e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b04177:	mov    rdx,rbx
    72e311b0417a:	shr    rdx,0x10
    72e311b0417e:	and    edx,0xc000
    72e311b04184:	mov    rax,rbx
    72e311b04187:	shr    rax,0x15
    72e311b0418b:	and    eax,0x100
    72e311b04190:	xor    eax,0x100
    72e311b04195:	or     edx,eax
    72e311b04197:	mov    rax,rbx
    72e311b0419a:	shr    rax,0x1c
    72e311b0419e:	and    eax,0x1
    72e311b041a1:	or     edx,eax
    72e311b041a3:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b041a8:	add    rsp,0x8
    72e311b041ac:	ret
    72e311b041ad:	nop    DWORD PTR [rax]
    72e311b041b0:	sub    rsp,0x8
    72e311b041b4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b041c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b041c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b041cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b041d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b041d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b041de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b041e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b041ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b041f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b04202:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b0420c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b04216:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b04220:	push   rdx
    72e311b04221:	push   rsi
    72e311b04222:	push   r10
    72e311b04224:	push   r11
    72e311b04226:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b0422b:	mov    r10d,edx
    72e311b0422e:	and    r10d,0xc000
    72e311b04235:	shl    r10d,0x10
    72e311b04239:	mov    r11d,edx
    72e311b0423c:	and    r11d,0x100
    72e311b04243:	shl    r11d,0x15
    72e311b04247:	or     r10d,r11d
    72e311b0424a:	and    edx,0x1
    72e311b0424d:	shl    edx,0x1c
    72e311b04250:	or     r10d,edx
    72e311b04253:	btc    r10,0x1d
    72e311b04258:	mov    r11d,0xf0000000
    72e311b0425e:	and    r11,r10
    72e311b04261:	movabs rsi,0xffffffff0fffffff
    72e311b0426b:	and    rbx,rsi
    72e311b0426e:	or     rbx,r11
    72e311b04271:	pop    r11
    72e311b04273:	pop    r10
    72e311b04275:	pop    rsi
    72e311b04276:	pop    rdx
    72e311b04277:	mov    QWORD PTR [r12+0x108],rbx
    72e311b0427f:	stmxcsr DWORD PTR [r12-0x28]
    72e311b04285:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b0428a:	test   r10d,0x3f
    72e311b04291:	je     0x72e311b042b6
    72e311b04297:	mov    r11d,r10d
    72e311b0429a:	shr    r10d,1
    72e311b0429d:	and    r10d,0x1e
    72e311b042a1:	and    r11d,0x1
    72e311b042a5:	or     r10d,r11d
    72e311b042a8:	or     DWORD PTR [r12+0x314],r10d
    72e311b042b0:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b042b6:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b042bc:	lea    rdi,[rsp+0x110]
    72e311b042c4:	lea    rsi,[rsp+0xf0]
    72e311b042cc:	lea    rdx,[rsp+0x100]
    72e311b042d4:	mov    ecx,0x14
    72e311b042d9:	mov    r8d,0x0
    72e311b042df:	lea    r9,[r12+0x314]
    72e311b042e7:	movabs r11,0x62e30647e650
    72e311b042f1:	call   r11
    72e311b042f4:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b042fa:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b04300:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b04306:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b0430c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b04312:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b04318:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b0431e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b04328:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b04332:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b0433c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b04346:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b04350:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b0435a:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b04362:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0436e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b04377:	mov    rdx,rbx
    72e311b0437a:	shr    rdx,0x10
    72e311b0437e:	and    edx,0xc000
    72e311b04384:	mov    rax,rbx
    72e311b04387:	shr    rax,0x15
    72e311b0438b:	and    eax,0x100
    72e311b04390:	xor    eax,0x100
    72e311b04395:	or     edx,eax
    72e311b04397:	mov    rax,rbx
    72e311b0439a:	shr    rax,0x1c
    72e311b0439e:	and    eax,0x1
    72e311b043a1:	or     edx,eax
    72e311b043a3:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b043a8:	add    rsp,0x8
    72e311b043ac:	ret
    72e311b043ad:	nop    DWORD PTR [rax]
    72e311b043b0:	sub    rsp,0x8
    72e311b043b4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b043c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b043c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b043cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b043d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b043d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b043de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b043e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b043ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b043f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b04402:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b0440c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b04416:	push   rdx
    72e311b04417:	push   rsi
    72e311b04418:	push   r10
    72e311b0441a:	push   r11
    72e311b0441c:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b04421:	mov    r10d,edx
    72e311b04424:	and    r10d,0xc000
    72e311b0442b:	shl    r10d,0x10
    72e311b0442f:	mov    r11d,edx
    72e311b04432:	and    r11d,0x100
    72e311b04439:	shl    r11d,0x15
    72e311b0443d:	or     r10d,r11d
    72e311b04440:	and    edx,0x1
    72e311b04443:	shl    edx,0x1c
    72e311b04446:	or     r10d,edx
    72e311b04449:	btc    r10,0x1d
    72e311b0444e:	mov    r11d,0xf0000000
    72e311b04454:	and    r11,r10
    72e311b04457:	movabs rsi,0xffffffff0fffffff
    72e311b04461:	and    rbx,rsi
    72e311b04464:	or     rbx,r11
    72e311b04467:	pop    r11
    72e311b04469:	pop    r10
    72e311b0446b:	pop    rsi
    72e311b0446c:	pop    rdx
    72e311b0446d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b04475:	stmxcsr DWORD PTR [r12-0x28]
    72e311b0447b:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b04480:	test   r10d,0x3f
    72e311b04487:	je     0x72e311b044ac
    72e311b0448d:	mov    r11d,r10d
    72e311b04490:	shr    r10d,1
    72e311b04493:	and    r10d,0x1e
    72e311b04497:	and    r11d,0x1
    72e311b0449b:	or     r10d,r11d
    72e311b0449e:	or     DWORD PTR [r12+0x314],r10d
    72e311b044a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b044ac:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b044b2:	lea    rdi,[rsp+0x110]
    72e311b044ba:	lea    rsi,[rsp+0xf0]
    72e311b044c2:	lea    rdx,[rsp+0x100]
    72e311b044ca:	mov    ecx,0x14
    72e311b044cf:	mov    r8d,0x0
    72e311b044d5:	lea    r9,[r12+0x314]
    72e311b044dd:	movabs r11,0x62e30647e650
    72e311b044e7:	call   r11
    72e311b044ea:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b044f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b044f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b044fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b04502:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b04508:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b0450e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b04514:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b0451e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b04528:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b04532:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b0453c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b04546:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0454e:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0455a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b04563:	mov    rdx,rbx
    72e311b04566:	shr    rdx,0x10
    72e311b0456a:	and    edx,0xc000
    72e311b04570:	mov    rax,rbx
    72e311b04573:	shr    rax,0x15
    72e311b04577:	and    eax,0x100
    72e311b0457c:	xor    eax,0x100
    72e311b04581:	or     edx,eax
    72e311b04583:	mov    rax,rbx
    72e311b04586:	shr    rax,0x1c
    72e311b0458a:	and    eax,0x1
    72e311b0458d:	or     edx,eax
    72e311b0458f:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b04594:	add    rsp,0x8
    72e311b04598:	ret
    72e311b04599:	nop    DWORD PTR [rax+0x0]
    72e311b045a0:	sub    rsp,0x8
    72e311b045a4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b045b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b045b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b045bc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b045c2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b045c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b045d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b045dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b045e6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b045f0:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b045fa:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b04604:	push   rdx
    72e311b04605:	push   rsi
    72e311b04606:	push   r10
    72e311b04608:	push   r11
    72e311b0460a:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b0460f:	mov    r10d,edx
    72e311b04612:	and    r10d,0xc000
    72e311b04619:	shl    r10d,0x10
    72e311b0461d:	mov    r11d,edx
    72e311b04620:	and    r11d,0x100
    72e311b04627:	shl    r11d,0x15
    72e311b0462b:	or     r10d,r11d
    72e311b0462e:	and    edx,0x1
    72e311b04631:	shl    edx,0x1c
    72e311b04634:	or     r10d,edx
    72e311b04637:	btc    r10,0x1d
    72e311b0463c:	mov    r11d,0xf0000000
    72e311b04642:	and    r11,r10
    72e311b04645:	movabs rsi,0xffffffff0fffffff
    72e311b0464f:	and    rbx,rsi
    72e311b04652:	or     rbx,r11
    72e311b04655:	pop    r11
    72e311b04657:	pop    r10
    72e311b04659:	pop    rsi
    72e311b0465a:	pop    rdx
    72e311b0465b:	mov    QWORD PTR [r12+0x108],rbx
    72e311b04663:	stmxcsr DWORD PTR [r12-0x28]
    72e311b04669:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b0466e:	test   r10d,0x3f
    72e311b04675:	je     0x72e311b0469a
    72e311b0467b:	mov    r11d,r10d
    72e311b0467e:	shr    r10d,1
    72e311b04681:	and    r10d,0x1e
    72e311b04685:	and    r11d,0x1
    72e311b04689:	or     r10d,r11d
    72e311b0468c:	or     DWORD PTR [r12+0x314],r10d
    72e311b04694:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b0469a:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b046a0:	lea    rdi,[rsp+0x110]
    72e311b046a8:	lea    rsi,[rsp+0xf0]
    72e311b046b0:	lea    rdx,[rsp+0x100]
    72e311b046b8:	mov    ecx,0x14
    72e311b046bd:	mov    r8d,0x0
    72e311b046c3:	lea    r9,[r12+0x314]
    72e311b046cb:	movabs r11,0x62e30647e650
    72e311b046d5:	call   r11
    72e311b046d8:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b046de:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b046e4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b046ea:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b046f0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b046f6:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b04700:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b0470a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b04714:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b0471e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b04728:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b04732:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0473a:	mov    QWORD PTR [r12+0x378],0x2
    72e311b04746:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b0474f:	mov    rdx,rbx
    72e311b04752:	shr    rdx,0x10
    72e311b04756:	and    edx,0xc000
    72e311b0475c:	mov    rax,rbx
    72e311b0475f:	shr    rax,0x15
    72e311b04763:	and    eax,0x100
    72e311b04768:	xor    eax,0x100
    72e311b0476d:	or     edx,eax
    72e311b0476f:	mov    rax,rbx
    72e311b04772:	shr    rax,0x1c
    72e311b04776:	and    eax,0x1
    72e311b04779:	or     edx,eax
    72e311b0477b:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b04780:	add    rsp,0x8
    72e311b04784:	ret
    72e311b04785:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b04790:	sub    rsp,0x8
    72e311b04794:	mov    QWORD PTR [r12+0x378],0x3
    72e311b047a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b047a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b047ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b047b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b047b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b047be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b047c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b047d2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b047dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b047e6:	push   rdx
    72e311b047e7:	push   rsi
    72e311b047e8:	push   r10
    72e311b047ea:	push   r11
    72e311b047ec:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b047f1:	mov    r10d,edx
    72e311b047f4:	and    r10d,0xc000
    72e311b047fb:	shl    r10d,0x10
    72e311b047ff:	mov    r11d,edx
    72e311b04802:	and    r11d,0x100
    72e311b04809:	shl    r11d,0x15
    72e311b0480d:	or     r10d,r11d
    72e311b04810:	and    edx,0x1
    72e311b04813:	shl    edx,0x1c
    72e311b04816:	or     r10d,edx
    72e311b04819:	btc    r10,0x1d
    72e311b0481e:	mov    r11d,0xf0000000
    72e311b04824:	and    r11,r10
    72e311b04827:	movabs rsi,0xffffffff0fffffff
    72e311b04831:	and    rbx,rsi
    72e311b04834:	or     rbx,r11
    72e311b04837:	pop    r11
    72e311b04839:	pop    r10
    72e311b0483b:	pop    rsi
    72e311b0483c:	pop    rdx
    72e311b0483d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b04845:	stmxcsr DWORD PTR [r12-0x28]
    72e311b0484b:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b04850:	test   r10d,0x3f
    72e311b04857:	je     0x72e311b0487c
    72e311b0485d:	mov    r11d,r10d
    72e311b04860:	shr    r10d,1
    72e311b04863:	and    r10d,0x1e
    72e311b04867:	and    r11d,0x1
    72e311b0486b:	or     r10d,r11d
    72e311b0486e:	or     DWORD PTR [r12+0x314],r10d
    72e311b04876:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b0487c:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b04882:	lea    rdi,[rsp+0x110]
    72e311b0488a:	lea    rsi,[rsp+0xf0]
    72e311b04892:	lea    rdx,[rsp+0x100]
    72e311b0489a:	mov    ecx,0x56
    72e311b0489f:	mov    r8d,0x0
    72e311b048a5:	lea    r9,[r12+0x314]
    72e311b048ad:	movabs r11,0x62e30647e650
    72e311b048b7:	call   r11
    72e311b048ba:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b048c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b048c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b048cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b048d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b048d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b048de:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b048e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b048f2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b048fc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b04906:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0490e:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0491a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b04923:	mov    rdx,rbx
    72e311b04926:	shr    rdx,0x10
    72e311b0492a:	and    edx,0xc000
    72e311b04930:	mov    rax,rbx
    72e311b04933:	shr    rax,0x15
    72e311b04937:	and    eax,0x100
    72e311b0493c:	xor    eax,0x100
    72e311b04941:	or     edx,eax
    72e311b04943:	mov    rax,rbx
    72e311b04946:	shr    rax,0x1c
    72e311b0494a:	and    eax,0x1
    72e311b0494d:	or     edx,eax
    72e311b0494f:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b04954:	add    rsp,0x8
    72e311b04958:	ret
    72e311b04959:	nop    DWORD PTR [rax+0x0]
    72e311b04960:	sub    rsp,0x8
    72e311b04964:	mov    QWORD PTR [r12+0x378],0x3
    72e311b04970:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b04976:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b0497c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b04982:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b04988:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b0498e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b04994:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b0499e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b049a8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b049b2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b049bc:	push   rdx
    72e311b049bd:	push   rsi
    72e311b049be:	push   r10
    72e311b049c0:	push   r11
    72e311b049c2:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b049c7:	mov    r10d,edx
    72e311b049ca:	and    r10d,0xc000
    72e311b049d1:	shl    r10d,0x10
    72e311b049d5:	mov    r11d,edx
    72e311b049d8:	and    r11d,0x100
    72e311b049df:	shl    r11d,0x15
    72e311b049e3:	or     r10d,r11d
    72e311b049e6:	and    edx,0x1
    72e311b049e9:	shl    edx,0x1c
    72e311b049ec:	or     r10d,edx
    72e311b049ef:	btc    r10,0x1d
    72e311b049f4:	mov    r11d,0xf0000000
    72e311b049fa:	and    r11,r10
    72e311b049fd:	movabs rsi,0xffffffff0fffffff
    72e311b04a07:	and    rbx,rsi
    72e311b04a0a:	or     rbx,r11
    72e311b04a0d:	pop    r11
    72e311b04a0f:	pop    r10
    72e311b04a11:	pop    rsi
    72e311b04a12:	pop    rdx
    72e311b04a13:	mov    QWORD PTR [r12+0x108],rbx
    72e311b04a1b:	stmxcsr DWORD PTR [r12-0x28]
    72e311b04a21:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b04a26:	test   r10d,0x3f
    72e311b04a2d:	je     0x72e311b04a52
    72e311b04a33:	mov    r11d,r10d
    72e311b04a36:	shr    r10d,1
    72e311b04a39:	and    r10d,0x1e
    72e311b04a3d:	and    r11d,0x1
    72e311b04a41:	or     r10d,r11d
    72e311b04a44:	or     DWORD PTR [r12+0x314],r10d
    72e311b04a4c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b04a52:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b04a58:	lea    rdi,[rsp+0x110]
    72e311b04a60:	lea    rsi,[rsp+0xf0]
    72e311b04a68:	lea    rdx,[rsp+0x100]
    72e311b04a70:	mov    ecx,0x56
    72e311b04a75:	mov    r8d,0x0
    72e311b04a7b:	lea    r9,[r12+0x314]
    72e311b04a83:	movabs r11,0x62e30647e650
    72e311b04a8d:	call   r11
    72e311b04a90:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b04a96:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b04a9c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b04aa2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b04aa8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b04aae:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b04ab4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b04aba:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b04ac4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b04ace:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b04ad8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b04ae2:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b04aea:	mov    QWORD PTR [r12+0x378],0x2
    72e311b04af6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b04aff:	mov    rdx,rbx
    72e311b04b02:	shr    rdx,0x10
    72e311b04b06:	and    edx,0xc000
    72e311b04b0c:	mov    rax,rbx
    72e311b04b0f:	shr    rax,0x15
    72e311b04b13:	and    eax,0x100
    72e311b04b18:	xor    eax,0x100
    72e311b04b1d:	or     edx,eax
    72e311b04b1f:	mov    rax,rbx
    72e311b04b22:	shr    rax,0x1c
    72e311b04b26:	and    eax,0x1
    72e311b04b29:	or     edx,eax
    72e311b04b2b:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b04b30:	add    rsp,0x8
    72e311b04b34:	ret
    72e311b04b35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b04b40:	sub    rsp,0x8
    72e311b04b44:	mov    QWORD PTR [r12+0x378],0x3
    72e311b04b50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b04b56:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b04b5c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b04b62:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b04b68:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b04b6e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b04b74:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b04b7e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b04b88:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b04b92:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b04b9c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b04ba6:	push   rdx
    72e311b04ba7:	push   rsi
    72e311b04ba8:	push   r10
    72e311b04baa:	push   r11
    72e311b04bac:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b04bb1:	mov    r10d,edx
    72e311b04bb4:	and    r10d,0xc000
    72e311b04bbb:	shl    r10d,0x10
    72e311b04bbf:	mov    r11d,edx
    72e311b04bc2:	and    r11d,0x100
    72e311b04bc9:	shl    r11d,0x15
    72e311b04bcd:	or     r10d,r11d
    72e311b04bd0:	and    edx,0x1
    72e311b04bd3:	shl    edx,0x1c
    72e311b04bd6:	or     r10d,edx
    72e311b04bd9:	btc    r10,0x1d
    72e311b04bde:	mov    r11d,0xf0000000
    72e311b04be4:	and    r11,r10
    72e311b04be7:	movabs rsi,0xffffffff0fffffff
    72e311b04bf1:	and    rbx,rsi
    72e311b04bf4:	or     rbx,r11
    72e311b04bf7:	pop    r11
    72e311b04bf9:	pop    r10
    72e311b04bfb:	pop    rsi
    72e311b04bfc:	pop    rdx
    72e311b04bfd:	mov    QWORD PTR [r12+0x108],rbx
    72e311b04c05:	stmxcsr DWORD PTR [r12-0x28]
    72e311b04c0b:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b04c10:	test   r10d,0x3f
    72e311b04c17:	je     0x72e311b04c3c
    72e311b04c1d:	mov    r11d,r10d
    72e311b04c20:	shr    r10d,1
    72e311b04c23:	and    r10d,0x1e
    72e311b04c27:	and    r11d,0x1
    72e311b04c2b:	or     r10d,r11d
    72e311b04c2e:	or     DWORD PTR [r12+0x314],r10d
    72e311b04c36:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b04c3c:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b04c42:	lea    rdi,[rsp+0x110]
    72e311b04c4a:	lea    rsi,[rsp+0xf0]
    72e311b04c52:	lea    rdx,[rsp+0x100]
    72e311b04c5a:	mov    ecx,0x56
    72e311b04c5f:	mov    r8d,0x0
    72e311b04c65:	lea    r9,[r12+0x314]
    72e311b04c6d:	movabs r11,0x62e30647e650
    72e311b04c77:	call   r11
    72e311b04c7a:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b04c80:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b04c86:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b04c8c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b04c92:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b04c98:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b04c9e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b04ca4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b04cae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b04cb8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b04cc2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b04ccc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b04cd6:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b04cde:	mov    QWORD PTR [r12+0x378],0x2
    72e311b04cea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b04cf3:	mov    rdx,rbx
    72e311b04cf6:	shr    rdx,0x10
    72e311b04cfa:	and    edx,0xc000
    72e311b04d00:	mov    rax,rbx
    72e311b04d03:	shr    rax,0x15
    72e311b04d07:	and    eax,0x100
    72e311b04d0c:	xor    eax,0x100
    72e311b04d11:	or     edx,eax
    72e311b04d13:	mov    rax,rbx
    72e311b04d16:	shr    rax,0x1c
    72e311b04d1a:	and    eax,0x1
    72e311b04d1d:	or     edx,eax
    72e311b04d1f:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b04d24:	add    rsp,0x8
    72e311b04d28:	ret
    72e311b04d29:	nop    DWORD PTR [rax+0x0]
    72e311b04d30:	sub    rsp,0x8
    72e311b04d34:	mov    QWORD PTR [r12+0x378],0x3
    72e311b04d40:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b04d46:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b04d4c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b04d52:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b04d58:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b04d62:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b04d6c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b04d76:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b04d80:	push   rdx
    72e311b04d81:	push   rsi
    72e311b04d82:	push   r10
    72e311b04d84:	push   r11
    72e311b04d86:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b04d8b:	mov    r10d,edx
    72e311b04d8e:	and    r10d,0xc000
    72e311b04d95:	shl    r10d,0x10
    72e311b04d99:	mov    r11d,edx
    72e311b04d9c:	and    r11d,0x100
    72e311b04da3:	shl    r11d,0x15
    72e311b04da7:	or     r10d,r11d
    72e311b04daa:	and    edx,0x1
    72e311b04dad:	shl    edx,0x1c
    72e311b04db0:	or     r10d,edx
    72e311b04db3:	btc    r10,0x1d
    72e311b04db8:	mov    r11d,0xf0000000
    72e311b04dbe:	and    r11,r10
    72e311b04dc1:	movabs rsi,0xffffffff0fffffff
    72e311b04dcb:	and    rbx,rsi
    72e311b04dce:	or     rbx,r11
    72e311b04dd1:	pop    r11
    72e311b04dd3:	pop    r10
    72e311b04dd5:	pop    rsi
    72e311b04dd6:	pop    rdx
    72e311b04dd7:	mov    QWORD PTR [r12+0x108],rbx
    72e311b04ddf:	stmxcsr DWORD PTR [r12-0x28]
    72e311b04de5:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b04dea:	test   r10d,0x3f
    72e311b04df1:	je     0x72e311b04e16
    72e311b04df7:	mov    r11d,r10d
    72e311b04dfa:	shr    r10d,1
    72e311b04dfd:	and    r10d,0x1e
    72e311b04e01:	and    r11d,0x1
    72e311b04e05:	or     r10d,r11d
    72e311b04e08:	or     DWORD PTR [r12+0x314],r10d
    72e311b04e10:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b04e16:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b04e1c:	lea    rdi,[rsp+0x110]
    72e311b04e24:	lea    rsi,[rsp+0xf0]
    72e311b04e2c:	lea    rdx,[rsp+0x100]
    72e311b04e34:	mov    ecx,0x56
    72e311b04e39:	mov    r8d,0x0
    72e311b04e3f:	lea    r9,[r12+0x314]
    72e311b04e47:	movabs r11,0x62e30647e650
    72e311b04e51:	call   r11
    72e311b04e54:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b04e5a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b04e60:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b04e66:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b04e6c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b04e72:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b04e7c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b04e86:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b04e90:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b04e9a:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b04ea2:	mov    QWORD PTR [r12+0x378],0x2
    72e311b04eae:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b04eb7:	mov    rdx,rbx
    72e311b04eba:	shr    rdx,0x10
    72e311b04ebe:	and    edx,0xc000
    72e311b04ec4:	mov    rax,rbx
    72e311b04ec7:	shr    rax,0x15
    72e311b04ecb:	and    eax,0x100
    72e311b04ed0:	xor    eax,0x100
    72e311b04ed5:	or     edx,eax
    72e311b04ed7:	mov    rax,rbx
    72e311b04eda:	shr    rax,0x1c
    72e311b04ede:	and    eax,0x1
    72e311b04ee1:	or     edx,eax
    72e311b04ee3:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b04ee8:	add    rsp,0x8
    72e311b04eec:	ret
    72e311b04eed:	nop    DWORD PTR [rax]
    72e311b04ef0:	sub    rsp,0x8
    72e311b04ef4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b04f00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b04f06:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b04f0c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b04f12:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b04f18:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b04f1e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b04f28:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b04f32:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b04f3c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b04f46:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b04f50:	push   rdx
    72e311b04f51:	push   rsi
    72e311b04f52:	push   r10
    72e311b04f54:	push   r11
    72e311b04f56:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b04f5b:	mov    r10d,edx
    72e311b04f5e:	and    r10d,0xc000
    72e311b04f65:	shl    r10d,0x10
    72e311b04f69:	mov    r11d,edx
    72e311b04f6c:	and    r11d,0x100
    72e311b04f73:	shl    r11d,0x15
    72e311b04f77:	or     r10d,r11d
    72e311b04f7a:	and    edx,0x1
    72e311b04f7d:	shl    edx,0x1c
    72e311b04f80:	or     r10d,edx
    72e311b04f83:	btc    r10,0x1d
    72e311b04f88:	mov    r11d,0xf0000000
    72e311b04f8e:	and    r11,r10
    72e311b04f91:	movabs rsi,0xffffffff0fffffff
    72e311b04f9b:	and    rbx,rsi
    72e311b04f9e:	or     rbx,r11
    72e311b04fa1:	pop    r11
    72e311b04fa3:	pop    r10
    72e311b04fa5:	pop    rsi
    72e311b04fa6:	pop    rdx
    72e311b04fa7:	mov    QWORD PTR [r12+0x108],rbx
    72e311b04faf:	stmxcsr DWORD PTR [r12-0x28]
    72e311b04fb5:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b04fba:	test   r10d,0x3f
    72e311b04fc1:	je     0x72e311b04fe6
    72e311b04fc7:	mov    r11d,r10d
    72e311b04fca:	shr    r10d,1
    72e311b04fcd:	and    r10d,0x1e
    72e311b04fd1:	and    r11d,0x1
    72e311b04fd5:	or     r10d,r11d
    72e311b04fd8:	or     DWORD PTR [r12+0x314],r10d
    72e311b04fe0:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b04fe6:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b04fec:	lea    rdi,[rsp+0x110]
    72e311b04ff4:	lea    rsi,[rsp+0xf0]
    72e311b04ffc:	lea    rdx,[rsp+0x100]
    72e311b05004:	mov    ecx,0x14
    72e311b05009:	mov    r8d,0x0
    72e311b0500f:	lea    r9,[r12+0x314]
    72e311b05017:	movabs r11,0x62e30647e650
    72e311b05021:	call   r11
    72e311b05024:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b0502a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b05030:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b05036:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b0503c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b05042:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b05048:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b05052:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b0505c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b05066:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b05070:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b0507a:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b05082:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0508e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b05097:	mov    rdx,rbx
    72e311b0509a:	shr    rdx,0x10
    72e311b0509e:	and    edx,0xc000
    72e311b050a4:	mov    rax,rbx
    72e311b050a7:	shr    rax,0x15
    72e311b050ab:	and    eax,0x100
    72e311b050b0:	xor    eax,0x100
    72e311b050b5:	or     edx,eax
    72e311b050b7:	mov    rax,rbx
    72e311b050ba:	shr    rax,0x1c
    72e311b050be:	and    eax,0x1
    72e311b050c1:	or     edx,eax
    72e311b050c3:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b050c8:	add    rsp,0x8
    72e311b050cc:	ret
    72e311b050cd:	nop    DWORD PTR [rax]
    72e311b050d0:	sub    rsp,0x8
    72e311b050d4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b050e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b050e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b050ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b050f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b050f8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b050fe:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b05108:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b05112:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b0511c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b05126:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b05130:	push   rdx
    72e311b05131:	push   rsi
    72e311b05132:	push   r10
    72e311b05134:	push   r11
    72e311b05136:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b0513b:	mov    r10d,edx
    72e311b0513e:	and    r10d,0xc000
    72e311b05145:	shl    r10d,0x10
    72e311b05149:	mov    r11d,edx
    72e311b0514c:	and    r11d,0x100
    72e311b05153:	shl    r11d,0x15
    72e311b05157:	or     r10d,r11d
    72e311b0515a:	and    edx,0x1
    72e311b0515d:	shl    edx,0x1c
    72e311b05160:	or     r10d,edx
    72e311b05163:	btc    r10,0x1d
    72e311b05168:	mov    r11d,0xf0000000
    72e311b0516e:	and    r11,r10
    72e311b05171:	movabs rsi,0xffffffff0fffffff
    72e311b0517b:	and    rbx,rsi
    72e311b0517e:	or     rbx,r11
    72e311b05181:	pop    r11
    72e311b05183:	pop    r10
    72e311b05185:	pop    rsi
    72e311b05186:	pop    rdx
    72e311b05187:	mov    QWORD PTR [r12+0x108],rbx
    72e311b0518f:	stmxcsr DWORD PTR [r12-0x28]
    72e311b05195:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b0519a:	test   r10d,0x3f
    72e311b051a1:	je     0x72e311b051c6
    72e311b051a7:	mov    r11d,r10d
    72e311b051aa:	shr    r10d,1
    72e311b051ad:	and    r10d,0x1e
    72e311b051b1:	and    r11d,0x1
    72e311b051b5:	or     r10d,r11d
    72e311b051b8:	or     DWORD PTR [r12+0x314],r10d
    72e311b051c0:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b051c6:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b051cc:	lea    rdi,[rsp+0x110]
    72e311b051d4:	lea    rsi,[rsp+0xf0]
    72e311b051dc:	lea    rdx,[rsp+0x100]
    72e311b051e4:	mov    ecx,0x56
    72e311b051e9:	mov    r8d,0x0
    72e311b051ef:	lea    r9,[r12+0x314]
    72e311b051f7:	movabs r11,0x62e30647e650
    72e311b05201:	call   r11
    72e311b05204:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b0520a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b05210:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b05216:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b0521c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b05222:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b05228:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b05232:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b0523c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b05246:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b05250:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b0525a:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b05262:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0526e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b05277:	mov    rdx,rbx
    72e311b0527a:	shr    rdx,0x10
    72e311b0527e:	and    edx,0xc000
    72e311b05284:	mov    rax,rbx
    72e311b05287:	shr    rax,0x15
    72e311b0528b:	and    eax,0x100
    72e311b05290:	xor    eax,0x100
    72e311b05295:	or     edx,eax
    72e311b05297:	mov    rax,rbx
    72e311b0529a:	shr    rax,0x1c
    72e311b0529e:	and    eax,0x1
    72e311b052a1:	or     edx,eax
    72e311b052a3:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b052a8:	add    rsp,0x8
    72e311b052ac:	ret
    72e311b052ad:	nop    DWORD PTR [rax]
    72e311b052b0:	sub    rsp,0x8
    72e311b052b4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b052c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b052c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b052cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b052d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b052d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b052de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b052e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b052ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b052f8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b05302:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b0530c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b05316:	push   rdx
    72e311b05317:	push   rsi
    72e311b05318:	push   r10
    72e311b0531a:	push   r11
    72e311b0531c:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b05321:	mov    r10d,edx
    72e311b05324:	and    r10d,0xc000
    72e311b0532b:	shl    r10d,0x10
    72e311b0532f:	mov    r11d,edx
    72e311b05332:	and    r11d,0x100
    72e311b05339:	shl    r11d,0x15
    72e311b0533d:	or     r10d,r11d
    72e311b05340:	and    edx,0x1
    72e311b05343:	shl    edx,0x1c
    72e311b05346:	or     r10d,edx
    72e311b05349:	btc    r10,0x1d
    72e311b0534e:	mov    r11d,0xf0000000
    72e311b05354:	and    r11,r10
    72e311b05357:	movabs rsi,0xffffffff0fffffff
    72e311b05361:	and    rbx,rsi
    72e311b05364:	or     rbx,r11
    72e311b05367:	pop    r11
    72e311b05369:	pop    r10
    72e311b0536b:	pop    rsi
    72e311b0536c:	pop    rdx
    72e311b0536d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b05375:	stmxcsr DWORD PTR [r12-0x28]
    72e311b0537b:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b05380:	test   r10d,0x3f
    72e311b05387:	je     0x72e311b053ac
    72e311b0538d:	mov    r11d,r10d
    72e311b05390:	shr    r10d,1
    72e311b05393:	and    r10d,0x1e
    72e311b05397:	and    r11d,0x1
    72e311b0539b:	or     r10d,r11d
    72e311b0539e:	or     DWORD PTR [r12+0x314],r10d
    72e311b053a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b053ac:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b053b2:	lea    rdi,[rsp+0x110]
    72e311b053ba:	lea    rsi,[rsp+0xf0]
    72e311b053c2:	lea    rdx,[rsp+0x100]
    72e311b053ca:	mov    ecx,0x14
    72e311b053cf:	mov    r8d,0x0
    72e311b053d5:	lea    r9,[r12+0x314]
    72e311b053dd:	movabs r11,0x62e30647e650
    72e311b053e7:	call   r11
    72e311b053ea:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b053f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b053f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b053fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b05402:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b05408:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b0540e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b05414:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b0541e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b05428:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b05432:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b0543c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b05446:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0544e:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0545a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b05463:	mov    rdx,rbx
    72e311b05466:	shr    rdx,0x10
    72e311b0546a:	and    edx,0xc000
    72e311b05470:	mov    rax,rbx
    72e311b05473:	shr    rax,0x15
    72e311b05477:	and    eax,0x100
    72e311b0547c:	xor    eax,0x100
    72e311b05481:	or     edx,eax
    72e311b05483:	mov    rax,rbx
    72e311b05486:	shr    rax,0x1c
    72e311b0548a:	and    eax,0x1
    72e311b0548d:	or     edx,eax
    72e311b0548f:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b05494:	add    rsp,0x8
    72e311b05498:	ret
    72e311b05499:	nop    DWORD PTR [rax+0x0]
    72e311b054a0:	sub    rsp,0x8
    72e311b054a4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b054b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b054b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b054bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b054c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b054c8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b054ce:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b054d4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b054de:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b054e8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b054f2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b054fc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b05506:	push   rdx
    72e311b05507:	push   rsi
    72e311b05508:	push   r10
    72e311b0550a:	push   r11
    72e311b0550c:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b05511:	mov    r10d,edx
    72e311b05514:	and    r10d,0xc000
    72e311b0551b:	shl    r10d,0x10
    72e311b0551f:	mov    r11d,edx
    72e311b05522:	and    r11d,0x100
    72e311b05529:	shl    r11d,0x15
    72e311b0552d:	or     r10d,r11d
    72e311b05530:	and    edx,0x1
    72e311b05533:	shl    edx,0x1c
    72e311b05536:	or     r10d,edx
    72e311b05539:	btc    r10,0x1d
    72e311b0553e:	mov    r11d,0xf0000000
    72e311b05544:	and    r11,r10
    72e311b05547:	movabs rsi,0xffffffff0fffffff
    72e311b05551:	and    rbx,rsi
    72e311b05554:	or     rbx,r11
    72e311b05557:	pop    r11
    72e311b05559:	pop    r10
    72e311b0555b:	pop    rsi
    72e311b0555c:	pop    rdx
    72e311b0555d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b05565:	stmxcsr DWORD PTR [r12-0x28]
    72e311b0556b:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b05570:	test   r10d,0x3f
    72e311b05577:	je     0x72e311b0559c
    72e311b0557d:	mov    r11d,r10d
    72e311b05580:	shr    r10d,1
    72e311b05583:	and    r10d,0x1e
    72e311b05587:	and    r11d,0x1
    72e311b0558b:	or     r10d,r11d
    72e311b0558e:	or     DWORD PTR [r12+0x314],r10d
    72e311b05596:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b0559c:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b055a2:	lea    rdi,[rsp+0x110]
    72e311b055aa:	lea    rsi,[rsp+0xf0]
    72e311b055b2:	lea    rdx,[rsp+0x100]
    72e311b055ba:	mov    ecx,0x14
    72e311b055bf:	mov    r8d,0x0
    72e311b055c5:	lea    r9,[r12+0x314]
    72e311b055cd:	movabs r11,0x62e30647e650
    72e311b055d7:	call   r11
    72e311b055da:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b055e0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b055e6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b055ec:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b055f2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b055f8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b055fe:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b05604:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b0560e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b05618:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b05622:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b0562c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b05636:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0563e:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0564a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b05653:	mov    rdx,rbx
    72e311b05656:	shr    rdx,0x10
    72e311b0565a:	and    edx,0xc000
    72e311b05660:	mov    rax,rbx
    72e311b05663:	shr    rax,0x15
    72e311b05667:	and    eax,0x100
    72e311b0566c:	xor    eax,0x100
    72e311b05671:	or     edx,eax
    72e311b05673:	mov    rax,rbx
    72e311b05676:	shr    rax,0x1c
    72e311b0567a:	and    eax,0x1
    72e311b0567d:	or     edx,eax
    72e311b0567f:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b05684:	add    rsp,0x8
    72e311b05688:	ret
    72e311b05689:	nop    DWORD PTR [rax+0x0]
    72e311b05690:	sub    rsp,0x8
    72e311b05694:	mov    QWORD PTR [r12+0x378],0x3
    72e311b056a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b056a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b056ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b056b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b056b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b056be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b056c4:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b056ce:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b056d8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b056e2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b056ec:	push   rdx
    72e311b056ed:	push   rsi
    72e311b056ee:	push   r10
    72e311b056f0:	push   r11
    72e311b056f2:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b056f7:	mov    r10d,edx
    72e311b056fa:	and    r10d,0xc000
    72e311b05701:	shl    r10d,0x10
    72e311b05705:	mov    r11d,edx
    72e311b05708:	and    r11d,0x100
    72e311b0570f:	shl    r11d,0x15
    72e311b05713:	or     r10d,r11d
    72e311b05716:	and    edx,0x1
    72e311b05719:	shl    edx,0x1c
    72e311b0571c:	or     r10d,edx
    72e311b0571f:	btc    r10,0x1d
    72e311b05724:	mov    r11d,0xf0000000
    72e311b0572a:	and    r11,r10
    72e311b0572d:	movabs rsi,0xffffffff0fffffff
    72e311b05737:	and    rbx,rsi
    72e311b0573a:	or     rbx,r11
    72e311b0573d:	pop    r11
    72e311b0573f:	pop    r10
    72e311b05741:	pop    rsi
    72e311b05742:	pop    rdx
    72e311b05743:	mov    QWORD PTR [r12+0x108],rbx
    72e311b0574b:	stmxcsr DWORD PTR [r12-0x28]
    72e311b05751:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b05756:	test   r10d,0x3f
    72e311b0575d:	je     0x72e311b05782
    72e311b05763:	mov    r11d,r10d
    72e311b05766:	shr    r10d,1
    72e311b05769:	and    r10d,0x1e
    72e311b0576d:	and    r11d,0x1
    72e311b05771:	or     r10d,r11d
    72e311b05774:	or     DWORD PTR [r12+0x314],r10d
    72e311b0577c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b05782:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b05788:	lea    rdi,[rsp+0x110]
    72e311b05790:	lea    rsi,[rsp+0xf0]
    72e311b05798:	lea    rdx,[rsp+0x100]
    72e311b057a0:	mov    ecx,0x56
    72e311b057a5:	mov    r8d,0x0
    72e311b057ab:	lea    r9,[r12+0x314]
    72e311b057b3:	movabs r11,0x62e30647e650
    72e311b057bd:	call   r11
    72e311b057c0:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b057c6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b057cc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b057d2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b057d8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b057de:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b057e4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b057ea:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b057f4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b057fe:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b05808:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b05812:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0581a:	mov    QWORD PTR [r12+0x378],0x2
    72e311b05826:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b0582f:	mov    rdx,rbx
    72e311b05832:	shr    rdx,0x10
    72e311b05836:	and    edx,0xc000
    72e311b0583c:	mov    rax,rbx
    72e311b0583f:	shr    rax,0x15
    72e311b05843:	and    eax,0x100
    72e311b05848:	xor    eax,0x100
    72e311b0584d:	or     edx,eax
    72e311b0584f:	mov    rax,rbx
    72e311b05852:	shr    rax,0x1c
    72e311b05856:	and    eax,0x1
    72e311b05859:	or     edx,eax
    72e311b0585b:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b05860:	add    rsp,0x8
    72e311b05864:	ret
    72e311b05865:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b05870:	sub    rsp,0x8
    72e311b05874:	mov    QWORD PTR [r12+0x378],0x3
    72e311b05880:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b05886:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b0588c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b05892:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b05898:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b0589e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b058a4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b058ae:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b058b8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b058c2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b058cc:	push   rdx
    72e311b058cd:	push   rsi
    72e311b058ce:	push   r10
    72e311b058d0:	push   r11
    72e311b058d2:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b058d7:	mov    r10d,edx
    72e311b058da:	and    r10d,0xc000
    72e311b058e1:	shl    r10d,0x10
    72e311b058e5:	mov    r11d,edx
    72e311b058e8:	and    r11d,0x100
    72e311b058ef:	shl    r11d,0x15
    72e311b058f3:	or     r10d,r11d
    72e311b058f6:	and    edx,0x1
    72e311b058f9:	shl    edx,0x1c
    72e311b058fc:	or     r10d,edx
    72e311b058ff:	btc    r10,0x1d
    72e311b05904:	mov    r11d,0xf0000000
    72e311b0590a:	and    r11,r10
    72e311b0590d:	movabs rsi,0xffffffff0fffffff
    72e311b05917:	and    rbx,rsi
    72e311b0591a:	or     rbx,r11
    72e311b0591d:	pop    r11
    72e311b0591f:	pop    r10
    72e311b05921:	pop    rsi
    72e311b05922:	pop    rdx
    72e311b05923:	mov    QWORD PTR [r12+0x108],rbx
    72e311b0592b:	stmxcsr DWORD PTR [r12-0x28]
    72e311b05931:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b05936:	test   r10d,0x3f
    72e311b0593d:	je     0x72e311b05962
    72e311b05943:	mov    r11d,r10d
    72e311b05946:	shr    r10d,1
    72e311b05949:	and    r10d,0x1e
    72e311b0594d:	and    r11d,0x1
    72e311b05951:	or     r10d,r11d
    72e311b05954:	or     DWORD PTR [r12+0x314],r10d
    72e311b0595c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b05962:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b05968:	lea    rdi,[rsp+0x110]
    72e311b05970:	lea    rsi,[rsp+0xf0]
    72e311b05978:	lea    rdx,[rsp+0x100]
    72e311b05980:	mov    ecx,0x14
    72e311b05985:	mov    r8d,0x0
    72e311b0598b:	lea    r9,[r12+0x314]
    72e311b05993:	movabs r11,0x62e30647e650
    72e311b0599d:	call   r11
    72e311b059a0:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b059a6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b059ac:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b059b2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b059b8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b059be:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b059c4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b059ca:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b059d4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b059de:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b059e8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b059f2:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b059fa:	mov    QWORD PTR [r12+0x378],0x2
    72e311b05a06:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b05a0f:	mov    rdx,rbx
    72e311b05a12:	shr    rdx,0x10
    72e311b05a16:	and    edx,0xc000
    72e311b05a1c:	mov    rax,rbx
    72e311b05a1f:	shr    rax,0x15
    72e311b05a23:	and    eax,0x100
    72e311b05a28:	xor    eax,0x100
    72e311b05a2d:	or     edx,eax
    72e311b05a2f:	mov    rax,rbx
    72e311b05a32:	shr    rax,0x1c
    72e311b05a36:	and    eax,0x1
    72e311b05a39:	or     edx,eax
    72e311b05a3b:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b05a40:	add    rsp,0x8
    72e311b05a44:	ret
    72e311b05a45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b05a50:	sub    rsp,0x8
    72e311b05a54:	mov    QWORD PTR [r12+0x378],0x3
    72e311b05a60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b05a66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b05a6c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b05a72:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b05a78:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b05a7e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b05a88:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b05a92:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b05a9c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b05aa6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b05ab0:	push   rdx
    72e311b05ab1:	push   rsi
    72e311b05ab2:	push   r10
    72e311b05ab4:	push   r11
    72e311b05ab6:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b05abb:	mov    r10d,edx
    72e311b05abe:	and    r10d,0xc000
    72e311b05ac5:	shl    r10d,0x10
    72e311b05ac9:	mov    r11d,edx
    72e311b05acc:	and    r11d,0x100
    72e311b05ad3:	shl    r11d,0x15
    72e311b05ad7:	or     r10d,r11d
    72e311b05ada:	and    edx,0x1
    72e311b05add:	shl    edx,0x1c
    72e311b05ae0:	or     r10d,edx
    72e311b05ae3:	btc    r10,0x1d
    72e311b05ae8:	mov    r11d,0xf0000000
    72e311b05aee:	and    r11,r10
    72e311b05af1:	movabs rsi,0xffffffff0fffffff
    72e311b05afb:	and    rbx,rsi
    72e311b05afe:	or     rbx,r11
    72e311b05b01:	pop    r11
    72e311b05b03:	pop    r10
    72e311b05b05:	pop    rsi
    72e311b05b06:	pop    rdx
    72e311b05b07:	mov    QWORD PTR [r12+0x108],rbx
    72e311b05b0f:	stmxcsr DWORD PTR [r12-0x28]
    72e311b05b15:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b05b1a:	test   r10d,0x3f
    72e311b05b21:	je     0x72e311b05b46
    72e311b05b27:	mov    r11d,r10d
    72e311b05b2a:	shr    r10d,1
    72e311b05b2d:	and    r10d,0x1e
    72e311b05b31:	and    r11d,0x1
    72e311b05b35:	or     r10d,r11d
    72e311b05b38:	or     DWORD PTR [r12+0x314],r10d
    72e311b05b40:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b05b46:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b05b4c:	lea    rdi,[rsp+0x110]
    72e311b05b54:	lea    rsi,[rsp+0xf0]
    72e311b05b5c:	lea    rdx,[rsp+0x100]
    72e311b05b64:	mov    ecx,0x56
    72e311b05b69:	mov    r8d,0x0
    72e311b05b6f:	lea    r9,[r12+0x314]
    72e311b05b77:	movabs r11,0x62e30647e650
    72e311b05b81:	call   r11
    72e311b05b84:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b05b8a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b05b90:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b05b96:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b05b9c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b05ba2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b05ba8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b05bb2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b05bbc:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b05bc6:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b05bd0:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b05bda:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b05be2:	mov    QWORD PTR [r12+0x378],0x2
    72e311b05bee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b05bf7:	mov    rdx,rbx
    72e311b05bfa:	shr    rdx,0x10
    72e311b05bfe:	and    edx,0xc000
    72e311b05c04:	mov    rax,rbx
    72e311b05c07:	shr    rax,0x15
    72e311b05c0b:	and    eax,0x100
    72e311b05c10:	xor    eax,0x100
    72e311b05c15:	or     edx,eax
    72e311b05c17:	mov    rax,rbx
    72e311b05c1a:	shr    rax,0x1c
    72e311b05c1e:	and    eax,0x1
    72e311b05c21:	or     edx,eax
    72e311b05c23:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b05c28:	add    rsp,0x8
    72e311b05c2c:	ret
    72e311b05c2d:	nop    DWORD PTR [rax]
    72e311b05c30:	sub    rsp,0x8
    72e311b05c34:	mov    QWORD PTR [r12+0x378],0x3
    72e311b05c40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b05c46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b05c4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b05c52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b05c58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b05c5e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b05c64:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b05c6e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b05c78:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b05c82:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b05c8c:	push   rdx
    72e311b05c8d:	push   rsi
    72e311b05c8e:	push   r10
    72e311b05c90:	push   r11
    72e311b05c92:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b05c97:	mov    r10d,edx
    72e311b05c9a:	and    r10d,0xc000
    72e311b05ca1:	shl    r10d,0x10
    72e311b05ca5:	mov    r11d,edx
    72e311b05ca8:	and    r11d,0x100
    72e311b05caf:	shl    r11d,0x15
    72e311b05cb3:	or     r10d,r11d
    72e311b05cb6:	and    edx,0x1
    72e311b05cb9:	shl    edx,0x1c
    72e311b05cbc:	or     r10d,edx
    72e311b05cbf:	btc    r10,0x1d
    72e311b05cc4:	mov    r11d,0xf0000000
    72e311b05cca:	and    r11,r10
    72e311b05ccd:	movabs rsi,0xffffffff0fffffff
    72e311b05cd7:	and    rbx,rsi
    72e311b05cda:	or     rbx,r11
    72e311b05cdd:	pop    r11
    72e311b05cdf:	pop    r10
    72e311b05ce1:	pop    rsi
    72e311b05ce2:	pop    rdx
    72e311b05ce3:	mov    QWORD PTR [r12+0x108],rbx
    72e311b05ceb:	stmxcsr DWORD PTR [r12-0x28]
    72e311b05cf1:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b05cf6:	test   r10d,0x3f
    72e311b05cfd:	je     0x72e311b05d22
    72e311b05d03:	mov    r11d,r10d
    72e311b05d06:	shr    r10d,1
    72e311b05d09:	and    r10d,0x1e
    72e311b05d0d:	and    r11d,0x1
    72e311b05d11:	or     r10d,r11d
    72e311b05d14:	or     DWORD PTR [r12+0x314],r10d
    72e311b05d1c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b05d22:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b05d28:	lea    rdi,[rsp+0x110]
    72e311b05d30:	lea    rsi,[rsp+0xf0]
    72e311b05d38:	lea    rdx,[rsp+0x100]
    72e311b05d40:	mov    ecx,0x56
    72e311b05d45:	mov    r8d,0x0
    72e311b05d4b:	lea    r9,[r12+0x314]
    72e311b05d53:	movabs r11,0x62e30647e650
    72e311b05d5d:	call   r11
    72e311b05d60:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b05d66:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b05d6c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b05d72:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b05d78:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b05d7e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b05d84:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b05d8a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b05d94:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b05d9e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b05da8:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b05db2:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b05dba:	mov    QWORD PTR [r12+0x378],0x2
    72e311b05dc6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b05dcf:	mov    rdx,rbx
    72e311b05dd2:	shr    rdx,0x10
    72e311b05dd6:	and    edx,0xc000
    72e311b05ddc:	mov    rax,rbx
    72e311b05ddf:	shr    rax,0x15
    72e311b05de3:	and    eax,0x100
    72e311b05de8:	xor    eax,0x100
    72e311b05ded:	or     edx,eax
    72e311b05def:	mov    rax,rbx
    72e311b05df2:	shr    rax,0x1c
    72e311b05df6:	and    eax,0x1
    72e311b05df9:	or     edx,eax
    72e311b05dfb:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b05e00:	add    rsp,0x8
    72e311b05e04:	ret
    72e311b05e05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b05e10:	sub    rsp,0x8
    72e311b05e14:	mov    QWORD PTR [r12+0x378],0x3
    72e311b05e20:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b05e26:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b05e2c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b05e32:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b05e38:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b05e3e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b05e44:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b05e4e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b05e58:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b05e62:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b05e6c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b05e76:	push   rdx
    72e311b05e77:	push   rsi
    72e311b05e78:	push   r10
    72e311b05e7a:	push   r11
    72e311b05e7c:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b05e81:	mov    r10d,edx
    72e311b05e84:	and    r10d,0xc000
    72e311b05e8b:	shl    r10d,0x10
    72e311b05e8f:	mov    r11d,edx
    72e311b05e92:	and    r11d,0x100
    72e311b05e99:	shl    r11d,0x15
    72e311b05e9d:	or     r10d,r11d
    72e311b05ea0:	and    edx,0x1
    72e311b05ea3:	shl    edx,0x1c
    72e311b05ea6:	or     r10d,edx
    72e311b05ea9:	btc    r10,0x1d
    72e311b05eae:	mov    r11d,0xf0000000
    72e311b05eb4:	and    r11,r10
    72e311b05eb7:	movabs rsi,0xffffffff0fffffff
    72e311b05ec1:	and    rbx,rsi
    72e311b05ec4:	or     rbx,r11
    72e311b05ec7:	pop    r11
    72e311b05ec9:	pop    r10
    72e311b05ecb:	pop    rsi
    72e311b05ecc:	pop    rdx
    72e311b05ecd:	mov    QWORD PTR [r12+0x108],rbx
    72e311b05ed5:	stmxcsr DWORD PTR [r12-0x28]
    72e311b05edb:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b05ee0:	test   r10d,0x3f
    72e311b05ee7:	je     0x72e311b05f0c
    72e311b05eed:	mov    r11d,r10d
    72e311b05ef0:	shr    r10d,1
    72e311b05ef3:	and    r10d,0x1e
    72e311b05ef7:	and    r11d,0x1
    72e311b05efb:	or     r10d,r11d
    72e311b05efe:	or     DWORD PTR [r12+0x314],r10d
    72e311b05f06:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b05f0c:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b05f12:	lea    rdi,[rsp+0x110]
    72e311b05f1a:	lea    rsi,[rsp+0xf0]
    72e311b05f22:	lea    rdx,[rsp+0x100]
    72e311b05f2a:	mov    ecx,0x14
    72e311b05f2f:	mov    r8d,0x0
    72e311b05f35:	lea    r9,[r12+0x314]
    72e311b05f3d:	movabs r11,0x62e30647e650
    72e311b05f47:	call   r11
    72e311b05f4a:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b05f50:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b05f56:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b05f5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b05f62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b05f68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b05f6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b05f74:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b05f7e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b05f88:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b05f92:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b05f9c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b05fa6:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b05fae:	mov    QWORD PTR [r12+0x378],0x2
    72e311b05fba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b05fc3:	mov    rdx,rbx
    72e311b05fc6:	shr    rdx,0x10
    72e311b05fca:	and    edx,0xc000
    72e311b05fd0:	mov    rax,rbx
    72e311b05fd3:	shr    rax,0x15
    72e311b05fd7:	and    eax,0x100
    72e311b05fdc:	xor    eax,0x100
    72e311b05fe1:	or     edx,eax
    72e311b05fe3:	mov    rax,rbx
    72e311b05fe6:	shr    rax,0x1c
    72e311b05fea:	and    eax,0x1
    72e311b05fed:	or     edx,eax
    72e311b05fef:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b05ff4:	add    rsp,0x8
    72e311b05ff8:	ret
    72e311b05ff9:	nop    DWORD PTR [rax+0x0]
    72e311b06000:	sub    rsp,0x8
    72e311b06004:	mov    QWORD PTR [r12+0x378],0x3
    72e311b06010:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b06016:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b0601c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b06022:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b06028:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b06032:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b0603c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b06046:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b06050:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b0605a:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b06064:	push   rdx
    72e311b06065:	push   rsi
    72e311b06066:	push   r10
    72e311b06068:	push   r11
    72e311b0606a:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b0606f:	mov    r10d,edx
    72e311b06072:	and    r10d,0xc000
    72e311b06079:	shl    r10d,0x10
    72e311b0607d:	mov    r11d,edx
    72e311b06080:	and    r11d,0x100
    72e311b06087:	shl    r11d,0x15
    72e311b0608b:	or     r10d,r11d
    72e311b0608e:	and    edx,0x1
    72e311b06091:	shl    edx,0x1c
    72e311b06094:	or     r10d,edx
    72e311b06097:	btc    r10,0x1d
    72e311b0609c:	mov    r11d,0xf0000000
    72e311b060a2:	and    r11,r10
    72e311b060a5:	movabs rsi,0xffffffff0fffffff
    72e311b060af:	and    rbx,rsi
    72e311b060b2:	or     rbx,r11
    72e311b060b5:	pop    r11
    72e311b060b7:	pop    r10
    72e311b060b9:	pop    rsi
    72e311b060ba:	pop    rdx
    72e311b060bb:	mov    QWORD PTR [r12+0x108],rbx
    72e311b060c3:	stmxcsr DWORD PTR [r12-0x28]
    72e311b060c9:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b060ce:	test   r10d,0x3f
    72e311b060d5:	je     0x72e311b060fa
    72e311b060db:	mov    r11d,r10d
    72e311b060de:	shr    r10d,1
    72e311b060e1:	and    r10d,0x1e
    72e311b060e5:	and    r11d,0x1
    72e311b060e9:	or     r10d,r11d
    72e311b060ec:	or     DWORD PTR [r12+0x314],r10d
    72e311b060f4:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b060fa:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b06100:	lea    rdi,[rsp+0x110]
    72e311b06108:	lea    rsi,[rsp+0xf0]
    72e311b06110:	lea    rdx,[rsp+0x100]
    72e311b06118:	mov    ecx,0x56
    72e311b0611d:	mov    r8d,0x0
    72e311b06123:	lea    r9,[r12+0x314]
    72e311b0612b:	movabs r11,0x62e30647e650
    72e311b06135:	call   r11
    72e311b06138:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b0613e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b06144:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b0614a:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b06150:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b06156:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b06160:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b0616a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b06174:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b0617e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b06188:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b06192:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0619a:	mov    QWORD PTR [r12+0x378],0x2
    72e311b061a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b061af:	mov    rdx,rbx
    72e311b061b2:	shr    rdx,0x10
    72e311b061b6:	and    edx,0xc000
    72e311b061bc:	mov    rax,rbx
    72e311b061bf:	shr    rax,0x15
    72e311b061c3:	and    eax,0x100
    72e311b061c8:	xor    eax,0x100
    72e311b061cd:	or     edx,eax
    72e311b061cf:	mov    rax,rbx
    72e311b061d2:	shr    rax,0x1c
    72e311b061d6:	and    eax,0x1
    72e311b061d9:	or     edx,eax
    72e311b061db:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b061e0:	add    rsp,0x8
    72e311b061e4:	ret
    72e311b061e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b061f0:	sub    rsp,0x8
    72e311b061f4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b06200:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b06206:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b0620c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b06212:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b06218:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b0621e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b06228:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b06232:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b0623c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b06246:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b06250:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b0625a:	push   rdx
    72e311b0625b:	push   rsi
    72e311b0625c:	push   r10
    72e311b0625e:	push   r11
    72e311b06260:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b06265:	mov    r10d,edx
    72e311b06268:	and    r10d,0xc000
    72e311b0626f:	shl    r10d,0x10
    72e311b06273:	mov    r11d,edx
    72e311b06276:	and    r11d,0x100
    72e311b0627d:	shl    r11d,0x15
    72e311b06281:	or     r10d,r11d
    72e311b06284:	and    edx,0x1
    72e311b06287:	shl    edx,0x1c
    72e311b0628a:	or     r10d,edx
    72e311b0628d:	btc    r10,0x1d
    72e311b06292:	mov    r11d,0xf0000000
    72e311b06298:	and    r11,r10
    72e311b0629b:	movabs rsi,0xffffffff0fffffff
    72e311b062a5:	and    rbx,rsi
    72e311b062a8:	or     rbx,r11
    72e311b062ab:	pop    r11
    72e311b062ad:	pop    r10
    72e311b062af:	pop    rsi
    72e311b062b0:	pop    rdx
    72e311b062b1:	mov    QWORD PTR [r12+0x108],rbx
    72e311b062b9:	stmxcsr DWORD PTR [r12-0x28]
    72e311b062bf:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b062c4:	test   r10d,0x3f
    72e311b062cb:	je     0x72e311b062f0
    72e311b062d1:	mov    r11d,r10d
    72e311b062d4:	shr    r10d,1
    72e311b062d7:	and    r10d,0x1e
    72e311b062db:	and    r11d,0x1
    72e311b062df:	or     r10d,r11d
    72e311b062e2:	or     DWORD PTR [r12+0x314],r10d
    72e311b062ea:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b062f0:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b062f6:	lea    rdi,[rsp+0x110]
    72e311b062fe:	lea    rsi,[rsp+0xf0]
    72e311b06306:	lea    rdx,[rsp+0x100]
    72e311b0630e:	mov    ecx,0x14
    72e311b06313:	mov    r8d,0x0
    72e311b06319:	lea    r9,[r12+0x314]
    72e311b06321:	movabs r11,0x62e30647e650
    72e311b0632b:	call   r11
    72e311b0632e:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b06334:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b0633a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b06340:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b06346:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b0634c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b06352:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b0635c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b06366:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b06370:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b0637a:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b06384:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b0638e:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b06396:	mov    QWORD PTR [r12+0x378],0x2
    72e311b063a2:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b063ab:	mov    rdx,rbx
    72e311b063ae:	shr    rdx,0x10
    72e311b063b2:	and    edx,0xc000
    72e311b063b8:	mov    rax,rbx
    72e311b063bb:	shr    rax,0x15
    72e311b063bf:	and    eax,0x100
    72e311b063c4:	xor    eax,0x100
    72e311b063c9:	or     edx,eax
    72e311b063cb:	mov    rax,rbx
    72e311b063ce:	shr    rax,0x1c
    72e311b063d2:	and    eax,0x1
    72e311b063d5:	or     edx,eax
    72e311b063d7:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b063dc:	add    rsp,0x8
    72e311b063e0:	ret
    72e311b063e1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b063f0:	sub    rsp,0x8
    72e311b063f4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b06400:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b06406:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b0640c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b06412:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b06418:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b0641e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b06424:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b0642e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b06438:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b06442:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b0644c:	push   rdx
    72e311b0644d:	push   rsi
    72e311b0644e:	push   r10
    72e311b06450:	push   r11
    72e311b06452:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b06457:	mov    r10d,edx
    72e311b0645a:	and    r10d,0xc000
    72e311b06461:	shl    r10d,0x10
    72e311b06465:	mov    r11d,edx
    72e311b06468:	and    r11d,0x100
    72e311b0646f:	shl    r11d,0x15
    72e311b06473:	or     r10d,r11d
    72e311b06476:	and    edx,0x1
    72e311b06479:	shl    edx,0x1c
    72e311b0647c:	or     r10d,edx
    72e311b0647f:	btc    r10,0x1d
    72e311b06484:	mov    r11d,0xf0000000
    72e311b0648a:	and    r11,r10
    72e311b0648d:	movabs rsi,0xffffffff0fffffff
    72e311b06497:	and    rbx,rsi
    72e311b0649a:	or     rbx,r11
    72e311b0649d:	pop    r11
    72e311b0649f:	pop    r10
    72e311b064a1:	pop    rsi
    72e311b064a2:	pop    rdx
    72e311b064a3:	mov    QWORD PTR [r12+0x108],rbx
    72e311b064ab:	stmxcsr DWORD PTR [r12-0x28]
    72e311b064b1:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b064b6:	test   r10d,0x3f
    72e311b064bd:	je     0x72e311b064e2
    72e311b064c3:	mov    r11d,r10d
    72e311b064c6:	shr    r10d,1
    72e311b064c9:	and    r10d,0x1e
    72e311b064cd:	and    r11d,0x1
    72e311b064d1:	or     r10d,r11d
    72e311b064d4:	or     DWORD PTR [r12+0x314],r10d
    72e311b064dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b064e2:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b064e8:	lea    rdi,[rsp+0x110]
    72e311b064f0:	lea    rsi,[rsp+0xf0]
    72e311b064f8:	lea    rdx,[rsp+0x100]
    72e311b06500:	mov    ecx,0x56
    72e311b06505:	mov    r8d,0x0
    72e311b0650b:	lea    r9,[r12+0x314]
    72e311b06513:	movabs r11,0x62e30647e650
    72e311b0651d:	call   r11
    72e311b06520:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b06526:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b0652c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b06532:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b06538:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b0653e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b06544:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b0654a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b06554:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b0655e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b06568:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b06572:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0657a:	mov    QWORD PTR [r12+0x378],0x2
    72e311b06586:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b0658f:	mov    rdx,rbx
    72e311b06592:	shr    rdx,0x10
    72e311b06596:	and    edx,0xc000
    72e311b0659c:	mov    rax,rbx
    72e311b0659f:	shr    rax,0x15
    72e311b065a3:	and    eax,0x100
    72e311b065a8:	xor    eax,0x100
    72e311b065ad:	or     edx,eax
    72e311b065af:	mov    rax,rbx
    72e311b065b2:	shr    rax,0x1c
    72e311b065b6:	and    eax,0x1
    72e311b065b9:	or     edx,eax
    72e311b065bb:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b065c0:	add    rsp,0x8
    72e311b065c4:	ret
    72e311b065c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b065d0:	sub    rsp,0x8
    72e311b065d4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b065e0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b065e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b065ec:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b065f2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b065f8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b06602:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b0660c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b06616:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b06620:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    72e311b0662a:	push   rdx
    72e311b0662b:	push   rsi
    72e311b0662c:	push   r10
    72e311b0662e:	push   r11
    72e311b06630:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b06635:	mov    r10d,edx
    72e311b06638:	and    r10d,0xc000
    72e311b0663f:	shl    r10d,0x10
    72e311b06643:	mov    r11d,edx
    72e311b06646:	and    r11d,0x100
    72e311b0664d:	shl    r11d,0x15
    72e311b06651:	or     r10d,r11d
    72e311b06654:	and    edx,0x1
    72e311b06657:	shl    edx,0x1c
    72e311b0665a:	or     r10d,edx
    72e311b0665d:	btc    r10,0x1d
    72e311b06662:	mov    r11d,0xf0000000
    72e311b06668:	and    r11,r10
    72e311b0666b:	movabs rsi,0xffffffff0fffffff
    72e311b06675:	and    rbx,rsi
    72e311b06678:	or     rbx,r11
    72e311b0667b:	pop    r11
    72e311b0667d:	pop    r10
    72e311b0667f:	pop    rsi
    72e311b06680:	pop    rdx
    72e311b06681:	mov    QWORD PTR [r12+0x108],rbx
    72e311b06689:	stmxcsr DWORD PTR [r12-0x28]
    72e311b0668f:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b06694:	test   r10d,0x3f
    72e311b0669b:	je     0x72e311b066c0
    72e311b066a1:	mov    r11d,r10d
    72e311b066a4:	shr    r10d,1
    72e311b066a7:	and    r10d,0x1e
    72e311b066ab:	and    r11d,0x1
    72e311b066af:	or     r10d,r11d
    72e311b066b2:	or     DWORD PTR [r12+0x314],r10d
    72e311b066ba:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b066c0:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b066c6:	lea    rdi,[rsp+0x110]
    72e311b066ce:	lea    rsi,[rsp+0xf0]
    72e311b066d6:	lea    rdx,[rsp+0x100]
    72e311b066de:	mov    ecx,0x14
    72e311b066e3:	mov    r8d,0x0
    72e311b066e9:	lea    r9,[r12+0x314]
    72e311b066f1:	movabs r11,0x62e30647e650
    72e311b066fb:	call   r11
    72e311b066fe:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b06704:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b0670a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b06710:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b06716:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b0671c:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b06726:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b06730:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b0673a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b06744:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    72e311b0674e:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b06756:	mov    QWORD PTR [r12+0x378],0x2
    72e311b06762:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b0676b:	mov    rdx,rbx
    72e311b0676e:	shr    rdx,0x10
    72e311b06772:	and    edx,0xc000
    72e311b06778:	mov    rax,rbx
    72e311b0677b:	shr    rax,0x15
    72e311b0677f:	and    eax,0x100
    72e311b06784:	xor    eax,0x100
    72e311b06789:	or     edx,eax
    72e311b0678b:	mov    rax,rbx
    72e311b0678e:	shr    rax,0x1c
    72e311b06792:	and    eax,0x1
    72e311b06795:	or     edx,eax
    72e311b06797:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b0679c:	add    rsp,0x8
    72e311b067a0:	ret
    72e311b067a1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b067b0:	sub    rsp,0x8
    72e311b067b4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b067c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b067c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b067cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b067d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b067d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b067de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b067e4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b067ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b067f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b06802:	push   rdx
    72e311b06803:	push   rsi
    72e311b06804:	push   r10
    72e311b06806:	push   r11
    72e311b06808:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b0680d:	mov    r10d,edx
    72e311b06810:	and    r10d,0xc000
    72e311b06817:	shl    r10d,0x10
    72e311b0681b:	mov    r11d,edx
    72e311b0681e:	and    r11d,0x100
    72e311b06825:	shl    r11d,0x15
    72e311b06829:	or     r10d,r11d
    72e311b0682c:	and    edx,0x1
    72e311b0682f:	shl    edx,0x1c
    72e311b06832:	or     r10d,edx
    72e311b06835:	btc    r10,0x1d
    72e311b0683a:	mov    r11d,0xf0000000
    72e311b06840:	and    r11,r10
    72e311b06843:	movabs rsi,0xffffffff0fffffff
    72e311b0684d:	and    rbx,rsi
    72e311b06850:	or     rbx,r11
    72e311b06853:	pop    r11
    72e311b06855:	pop    r10
    72e311b06857:	pop    rsi
    72e311b06858:	pop    rdx
    72e311b06859:	mov    QWORD PTR [r12+0x108],rbx
    72e311b06861:	stmxcsr DWORD PTR [r12-0x28]
    72e311b06867:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b0686c:	test   r10d,0x3f
    72e311b06873:	je     0x72e311b06898
    72e311b06879:	mov    r11d,r10d
    72e311b0687c:	shr    r10d,1
    72e311b0687f:	and    r10d,0x1e
    72e311b06883:	and    r11d,0x1
    72e311b06887:	or     r10d,r11d
    72e311b0688a:	or     DWORD PTR [r12+0x314],r10d
    72e311b06892:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b06898:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b0689e:	lea    rdi,[rsp+0x110]
    72e311b068a6:	lea    rsi,[rsp+0xf0]
    72e311b068ae:	lea    rdx,[rsp+0x100]
    72e311b068b6:	mov    ecx,0x56
    72e311b068bb:	mov    r8d,0x0
    72e311b068c1:	lea    r9,[r12+0x314]
    72e311b068c9:	movabs r11,0x62e30647e650
    72e311b068d3:	call   r11
    72e311b068d6:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b068dc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b068e2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b068e8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b068ee:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b068f4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b068fa:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b06900:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b0690a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b06914:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b0691e:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b06926:	mov    QWORD PTR [r12+0x378],0x2
    72e311b06932:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b0693b:	mov    rdx,rbx
    72e311b0693e:	shr    rdx,0x10
    72e311b06942:	and    edx,0xc000
    72e311b06948:	mov    rax,rbx
    72e311b0694b:	shr    rax,0x15
    72e311b0694f:	and    eax,0x100
    72e311b06954:	xor    eax,0x100
    72e311b06959:	or     edx,eax
    72e311b0695b:	mov    rax,rbx
    72e311b0695e:	shr    rax,0x1c
    72e311b06962:	and    eax,0x1
    72e311b06965:	or     edx,eax
    72e311b06967:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b0696c:	add    rsp,0x8
    72e311b06970:	ret
    72e311b06971:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b06980:	sub    rsp,0x8
    72e311b06984:	mov    QWORD PTR [r12+0x378],0x3
    72e311b06990:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b06996:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b0699c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b069a2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b069a8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b069ae:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b069b8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b069c2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b069cc:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b069d6:	push   rdx
    72e311b069d7:	push   rsi
    72e311b069d8:	push   r10
    72e311b069da:	push   r11
    72e311b069dc:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b069e1:	mov    r10d,edx
    72e311b069e4:	and    r10d,0xc000
    72e311b069eb:	shl    r10d,0x10
    72e311b069ef:	mov    r11d,edx
    72e311b069f2:	and    r11d,0x100
    72e311b069f9:	shl    r11d,0x15
    72e311b069fd:	or     r10d,r11d
    72e311b06a00:	and    edx,0x1
    72e311b06a03:	shl    edx,0x1c
    72e311b06a06:	or     r10d,edx
    72e311b06a09:	btc    r10,0x1d
    72e311b06a0e:	mov    r11d,0xf0000000
    72e311b06a14:	and    r11,r10
    72e311b06a17:	movabs rsi,0xffffffff0fffffff
    72e311b06a21:	and    rbx,rsi
    72e311b06a24:	or     rbx,r11
    72e311b06a27:	pop    r11
    72e311b06a29:	pop    r10
    72e311b06a2b:	pop    rsi
    72e311b06a2c:	pop    rdx
    72e311b06a2d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b06a35:	stmxcsr DWORD PTR [r12-0x28]
    72e311b06a3b:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b06a40:	test   r10d,0x3f
    72e311b06a47:	je     0x72e311b06a6c
    72e311b06a4d:	mov    r11d,r10d
    72e311b06a50:	shr    r10d,1
    72e311b06a53:	and    r10d,0x1e
    72e311b06a57:	and    r11d,0x1
    72e311b06a5b:	or     r10d,r11d
    72e311b06a5e:	or     DWORD PTR [r12+0x314],r10d
    72e311b06a66:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b06a6c:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b06a72:	lea    rdi,[rsp+0x110]
    72e311b06a7a:	lea    rsi,[rsp+0xf0]
    72e311b06a82:	lea    rdx,[rsp+0x100]
    72e311b06a8a:	mov    ecx,0x56
    72e311b06a8f:	mov    r8d,0x0
    72e311b06a95:	lea    r9,[r12+0x314]
    72e311b06a9d:	movabs r11,0x62e30647e650
    72e311b06aa7:	call   r11
    72e311b06aaa:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b06ab0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b06ab6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b06abc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b06ac2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b06ac8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b06ace:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b06ad8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b06ae2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b06aec:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b06af6:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b06afe:	mov    QWORD PTR [r12+0x378],0x2
    72e311b06b0a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b06b13:	mov    rdx,rbx
    72e311b06b16:	shr    rdx,0x10
    72e311b06b1a:	and    edx,0xc000
    72e311b06b20:	mov    rax,rbx
    72e311b06b23:	shr    rax,0x15
    72e311b06b27:	and    eax,0x100
    72e311b06b2c:	xor    eax,0x100
    72e311b06b31:	or     edx,eax
    72e311b06b33:	mov    rax,rbx
    72e311b06b36:	shr    rax,0x1c
    72e311b06b3a:	and    eax,0x1
    72e311b06b3d:	or     edx,eax
    72e311b06b3f:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b06b44:	add    rsp,0x8
    72e311b06b48:	ret
    72e311b06b49:	nop    DWORD PTR [rax+0x0]
    72e311b06b50:	sub    rsp,0x8
    72e311b06b54:	mov    QWORD PTR [r12+0x378],0x3
    72e311b06b60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b06b66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b06b6c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b06b72:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b06b78:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b06b7e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b06b84:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b06b8e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b06b98:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b06ba2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b06bac:	push   rdx
    72e311b06bad:	push   rsi
    72e311b06bae:	push   r10
    72e311b06bb0:	push   r11
    72e311b06bb2:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b06bb7:	mov    r10d,edx
    72e311b06bba:	and    r10d,0xc000
    72e311b06bc1:	shl    r10d,0x10
    72e311b06bc5:	mov    r11d,edx
    72e311b06bc8:	and    r11d,0x100
    72e311b06bcf:	shl    r11d,0x15
    72e311b06bd3:	or     r10d,r11d
    72e311b06bd6:	and    edx,0x1
    72e311b06bd9:	shl    edx,0x1c
    72e311b06bdc:	or     r10d,edx
    72e311b06bdf:	btc    r10,0x1d
    72e311b06be4:	mov    r11d,0xf0000000
    72e311b06bea:	and    r11,r10
    72e311b06bed:	movabs rsi,0xffffffff0fffffff
    72e311b06bf7:	and    rbx,rsi
    72e311b06bfa:	or     rbx,r11
    72e311b06bfd:	pop    r11
    72e311b06bff:	pop    r10
    72e311b06c01:	pop    rsi
    72e311b06c02:	pop    rdx
    72e311b06c03:	mov    QWORD PTR [r12+0x108],rbx
    72e311b06c0b:	stmxcsr DWORD PTR [r12-0x28]
    72e311b06c11:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b06c16:	test   r10d,0x3f
    72e311b06c1d:	je     0x72e311b06c42
    72e311b06c23:	mov    r11d,r10d
    72e311b06c26:	shr    r10d,1
    72e311b06c29:	and    r10d,0x1e
    72e311b06c2d:	and    r11d,0x1
    72e311b06c31:	or     r10d,r11d
    72e311b06c34:	or     DWORD PTR [r12+0x314],r10d
    72e311b06c3c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b06c42:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b06c48:	lea    rdi,[rsp+0x110]
    72e311b06c50:	lea    rsi,[rsp+0xf0]
    72e311b06c58:	lea    rdx,[rsp+0x100]
    72e311b06c60:	mov    ecx,0x14
    72e311b06c65:	mov    r8d,0x0
    72e311b06c6b:	lea    r9,[r12+0x314]
    72e311b06c73:	movabs r11,0x62e30647e650
    72e311b06c7d:	call   r11
    72e311b06c80:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b06c86:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b06c8c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b06c92:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b06c98:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b06c9e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b06ca4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b06caa:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b06cb4:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b06cbe:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b06cc8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b06cd2:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b06cda:	mov    QWORD PTR [r12+0x378],0x2
    72e311b06ce6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b06cef:	mov    rdx,rbx
    72e311b06cf2:	shr    rdx,0x10
    72e311b06cf6:	and    edx,0xc000
    72e311b06cfc:	mov    rax,rbx
    72e311b06cff:	shr    rax,0x15
    72e311b06d03:	and    eax,0x100
    72e311b06d08:	xor    eax,0x100
    72e311b06d0d:	or     edx,eax
    72e311b06d0f:	mov    rax,rbx
    72e311b06d12:	shr    rax,0x1c
    72e311b06d16:	and    eax,0x1
    72e311b06d19:	or     edx,eax
    72e311b06d1b:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b06d20:	add    rsp,0x8
    72e311b06d24:	ret
    72e311b06d25:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b06d30:	sub    rsp,0x8
    72e311b06d34:	mov    QWORD PTR [r12+0x378],0x3
    72e311b06d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b06d46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b06d4c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b06d52:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b06d58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b06d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b06d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b06d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b06d7c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b06d86:	push   rdx
    72e311b06d87:	push   rsi
    72e311b06d88:	push   r10
    72e311b06d8a:	push   r11
    72e311b06d8c:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b06d91:	mov    r10d,edx
    72e311b06d94:	and    r10d,0xc000
    72e311b06d9b:	shl    r10d,0x10
    72e311b06d9f:	mov    r11d,edx
    72e311b06da2:	and    r11d,0x100
    72e311b06da9:	shl    r11d,0x15
    72e311b06dad:	or     r10d,r11d
    72e311b06db0:	and    edx,0x1
    72e311b06db3:	shl    edx,0x1c
    72e311b06db6:	or     r10d,edx
    72e311b06db9:	btc    r10,0x1d
    72e311b06dbe:	mov    r11d,0xf0000000
    72e311b06dc4:	and    r11,r10
    72e311b06dc7:	movabs rsi,0xffffffff0fffffff
    72e311b06dd1:	and    rbx,rsi
    72e311b06dd4:	or     rbx,r11
    72e311b06dd7:	pop    r11
    72e311b06dd9:	pop    r10
    72e311b06ddb:	pop    rsi
    72e311b06ddc:	pop    rdx
    72e311b06ddd:	mov    QWORD PTR [r12+0x108],rbx
    72e311b06de5:	stmxcsr DWORD PTR [r12-0x28]
    72e311b06deb:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b06df0:	test   r10d,0x3f
    72e311b06df7:	je     0x72e311b06e1c
    72e311b06dfd:	mov    r11d,r10d
    72e311b06e00:	shr    r10d,1
    72e311b06e03:	and    r10d,0x1e
    72e311b06e07:	and    r11d,0x1
    72e311b06e0b:	or     r10d,r11d
    72e311b06e0e:	or     DWORD PTR [r12+0x314],r10d
    72e311b06e16:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b06e1c:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b06e22:	lea    rdi,[rsp+0x110]
    72e311b06e2a:	lea    rsi,[rsp+0xf0]
    72e311b06e32:	lea    rdx,[rsp+0x100]
    72e311b06e3a:	mov    ecx,0x14
    72e311b06e3f:	mov    r8d,0x0
    72e311b06e45:	lea    r9,[r12+0x314]
    72e311b06e4d:	movabs r11,0x62e30647e650
    72e311b06e57:	call   r11
    72e311b06e5a:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b06e60:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b06e66:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b06e6c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b06e72:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b06e78:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b06e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b06e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b06e92:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b06e9c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b06ea6:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b06eae:	mov    QWORD PTR [r12+0x378],0x2
    72e311b06eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b06ec3:	mov    rdx,rbx
    72e311b06ec6:	shr    rdx,0x10
    72e311b06eca:	and    edx,0xc000
    72e311b06ed0:	mov    rax,rbx
    72e311b06ed3:	shr    rax,0x15
    72e311b06ed7:	and    eax,0x100
    72e311b06edc:	xor    eax,0x100
    72e311b06ee1:	or     edx,eax
    72e311b06ee3:	mov    rax,rbx
    72e311b06ee6:	shr    rax,0x1c
    72e311b06eea:	and    eax,0x1
    72e311b06eed:	or     edx,eax
    72e311b06eef:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b06ef4:	add    rsp,0x8
    72e311b06ef8:	ret
    72e311b06ef9:	nop    DWORD PTR [rax+0x0]
    72e311b06f00:	sub    rsp,0x8
    72e311b06f04:	mov    QWORD PTR [r12+0x378],0x3
    72e311b06f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b06f16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b06f1c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b06f22:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b06f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b06f2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b06f38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b06f42:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b06f4c:	push   rdx
    72e311b06f4d:	push   rsi
    72e311b06f4e:	push   r10
    72e311b06f50:	push   r11
    72e311b06f52:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b06f57:	mov    r10d,edx
    72e311b06f5a:	and    r10d,0xc000
    72e311b06f61:	shl    r10d,0x10
    72e311b06f65:	mov    r11d,edx
    72e311b06f68:	and    r11d,0x100
    72e311b06f6f:	shl    r11d,0x15
    72e311b06f73:	or     r10d,r11d
    72e311b06f76:	and    edx,0x1
    72e311b06f79:	shl    edx,0x1c
    72e311b06f7c:	or     r10d,edx
    72e311b06f7f:	btc    r10,0x1d
    72e311b06f84:	mov    r11d,0xf0000000
    72e311b06f8a:	and    r11,r10
    72e311b06f8d:	movabs rsi,0xffffffff0fffffff
    72e311b06f97:	and    rbx,rsi
    72e311b06f9a:	or     rbx,r11
    72e311b06f9d:	pop    r11
    72e311b06f9f:	pop    r10
    72e311b06fa1:	pop    rsi
    72e311b06fa2:	pop    rdx
    72e311b06fa3:	mov    QWORD PTR [r12+0x108],rbx
    72e311b06fab:	stmxcsr DWORD PTR [r12-0x28]
    72e311b06fb1:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b06fb6:	test   r10d,0x3f
    72e311b06fbd:	je     0x72e311b06fe2
    72e311b06fc3:	mov    r11d,r10d
    72e311b06fc6:	shr    r10d,1
    72e311b06fc9:	and    r10d,0x1e
    72e311b06fcd:	and    r11d,0x1
    72e311b06fd1:	or     r10d,r11d
    72e311b06fd4:	or     DWORD PTR [r12+0x314],r10d
    72e311b06fdc:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b06fe2:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b06fe8:	lea    rdi,[rsp+0x110]
    72e311b06ff0:	lea    rsi,[rsp+0xf0]
    72e311b06ff8:	lea    rdx,[rsp+0x100]
    72e311b07000:	mov    ecx,0x56
    72e311b07005:	mov    r8d,0x0
    72e311b0700b:	lea    r9,[r12+0x314]
    72e311b07013:	movabs r11,0x62e30647e650
    72e311b0701d:	call   r11
    72e311b07020:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b07026:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b0702c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b07032:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b07038:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b0703e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b07044:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b0704e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b07058:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b07062:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0706a:	mov    QWORD PTR [r12+0x378],0x2
    72e311b07076:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b0707f:	mov    rdx,rbx
    72e311b07082:	shr    rdx,0x10
    72e311b07086:	and    edx,0xc000
    72e311b0708c:	mov    rax,rbx
    72e311b0708f:	shr    rax,0x15
    72e311b07093:	and    eax,0x100
    72e311b07098:	xor    eax,0x100
    72e311b0709d:	or     edx,eax
    72e311b0709f:	mov    rax,rbx
    72e311b070a2:	shr    rax,0x1c
    72e311b070a6:	and    eax,0x1
    72e311b070a9:	or     edx,eax
    72e311b070ab:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b070b0:	add    rsp,0x8
    72e311b070b4:	ret
    72e311b070b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b070c0:	sub    rsp,0x8
    72e311b070c4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b070d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b070d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b070dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b070e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b070e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b070ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b070f4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b070fe:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b07108:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b07112:	push   rdx
    72e311b07113:	push   rsi
    72e311b07114:	push   r10
    72e311b07116:	push   r11
    72e311b07118:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b0711d:	mov    r10d,edx
    72e311b07120:	and    r10d,0xc000
    72e311b07127:	shl    r10d,0x10
    72e311b0712b:	mov    r11d,edx
    72e311b0712e:	and    r11d,0x100
    72e311b07135:	shl    r11d,0x15
    72e311b07139:	or     r10d,r11d
    72e311b0713c:	and    edx,0x1
    72e311b0713f:	shl    edx,0x1c
    72e311b07142:	or     r10d,edx
    72e311b07145:	btc    r10,0x1d
    72e311b0714a:	mov    r11d,0xf0000000
    72e311b07150:	and    r11,r10
    72e311b07153:	movabs rsi,0xffffffff0fffffff
    72e311b0715d:	and    rbx,rsi
    72e311b07160:	or     rbx,r11
    72e311b07163:	pop    r11
    72e311b07165:	pop    r10
    72e311b07167:	pop    rsi
    72e311b07168:	pop    rdx
    72e311b07169:	mov    QWORD PTR [r12+0x108],rbx
    72e311b07171:	stmxcsr DWORD PTR [r12-0x28]
    72e311b07177:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b0717c:	test   r10d,0x3f
    72e311b07183:	je     0x72e311b071a8
    72e311b07189:	mov    r11d,r10d
    72e311b0718c:	shr    r10d,1
    72e311b0718f:	and    r10d,0x1e
    72e311b07193:	and    r11d,0x1
    72e311b07197:	or     r10d,r11d
    72e311b0719a:	or     DWORD PTR [r12+0x314],r10d
    72e311b071a2:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b071a8:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b071ae:	lea    rdi,[rsp+0x110]
    72e311b071b6:	lea    rsi,[rsp+0xf0]
    72e311b071be:	lea    rdx,[rsp+0x100]
    72e311b071c6:	mov    ecx,0x56
    72e311b071cb:	mov    r8d,0x0
    72e311b071d1:	lea    r9,[r12+0x314]
    72e311b071d9:	movabs r11,0x62e30647e650
    72e311b071e3:	call   r11
    72e311b071e6:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b071ec:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b071f2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b071f8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b071fe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b07204:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b0720a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b07210:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b0721a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b07224:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b0722e:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b07236:	mov    QWORD PTR [r12+0x378],0x2
    72e311b07242:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b0724b:	mov    rdx,rbx
    72e311b0724e:	shr    rdx,0x10
    72e311b07252:	and    edx,0xc000
    72e311b07258:	mov    rax,rbx
    72e311b0725b:	shr    rax,0x15
    72e311b0725f:	and    eax,0x100
    72e311b07264:	xor    eax,0x100
    72e311b07269:	or     edx,eax
    72e311b0726b:	mov    rax,rbx
    72e311b0726e:	shr    rax,0x1c
    72e311b07272:	and    eax,0x1
    72e311b07275:	or     edx,eax
    72e311b07277:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b0727c:	add    rsp,0x8
    72e311b07280:	ret
    72e311b07281:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b07290:	sub    rsp,0x8
    72e311b07294:	mov    QWORD PTR [r12+0x378],0x3
    72e311b072a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b072a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b072ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b072b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b072b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b072be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b072c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b072d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b072dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b072e6:	push   rdx
    72e311b072e7:	push   rsi
    72e311b072e8:	push   r10
    72e311b072ea:	push   r11
    72e311b072ec:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b072f1:	mov    r10d,edx
    72e311b072f4:	and    r10d,0xc000
    72e311b072fb:	shl    r10d,0x10
    72e311b072ff:	mov    r11d,edx
    72e311b07302:	and    r11d,0x100
    72e311b07309:	shl    r11d,0x15
    72e311b0730d:	or     r10d,r11d
    72e311b07310:	and    edx,0x1
    72e311b07313:	shl    edx,0x1c
    72e311b07316:	or     r10d,edx
    72e311b07319:	btc    r10,0x1d
    72e311b0731e:	mov    r11d,0xf0000000
    72e311b07324:	and    r11,r10
    72e311b07327:	movabs rsi,0xffffffff0fffffff
    72e311b07331:	and    rbx,rsi
    72e311b07334:	or     rbx,r11
    72e311b07337:	pop    r11
    72e311b07339:	pop    r10
    72e311b0733b:	pop    rsi
    72e311b0733c:	pop    rdx
    72e311b0733d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b07345:	stmxcsr DWORD PTR [r12-0x28]
    72e311b0734b:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b07350:	test   r10d,0x3f
    72e311b07357:	je     0x72e311b0737c
    72e311b0735d:	mov    r11d,r10d
    72e311b07360:	shr    r10d,1
    72e311b07363:	and    r10d,0x1e
    72e311b07367:	and    r11d,0x1
    72e311b0736b:	or     r10d,r11d
    72e311b0736e:	or     DWORD PTR [r12+0x314],r10d
    72e311b07376:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b0737c:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b07382:	lea    rdi,[rsp+0x110]
    72e311b0738a:	lea    rsi,[rsp+0xf0]
    72e311b07392:	lea    rdx,[rsp+0x100]
    72e311b0739a:	mov    ecx,0x14
    72e311b0739f:	mov    r8d,0x0
    72e311b073a5:	lea    r9,[r12+0x314]
    72e311b073ad:	movabs r11,0x62e30647e650
    72e311b073b7:	call   r11
    72e311b073ba:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b073c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b073c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b073cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b073d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b073d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b073de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b073e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b073f2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b073fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b07406:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0740e:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0741a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b07423:	mov    rdx,rbx
    72e311b07426:	shr    rdx,0x10
    72e311b0742a:	and    edx,0xc000
    72e311b07430:	mov    rax,rbx
    72e311b07433:	shr    rax,0x15
    72e311b07437:	and    eax,0x100
    72e311b0743c:	xor    eax,0x100
    72e311b07441:	or     edx,eax
    72e311b07443:	mov    rax,rbx
    72e311b07446:	shr    rax,0x1c
    72e311b0744a:	and    eax,0x1
    72e311b0744d:	or     edx,eax
    72e311b0744f:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b07454:	add    rsp,0x8
    72e311b07458:	ret
    72e311b07459:	nop    DWORD PTR [rax+0x0]
    72e311b07460:	sub    rsp,0x8
    72e311b07464:	mov    QWORD PTR [r12+0x378],0x3
    72e311b07470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b07476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b0747c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b07482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b07488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b0748e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b07498:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b074a2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b074ac:	push   rdx
    72e311b074ad:	push   rsi
    72e311b074ae:	push   r10
    72e311b074b0:	push   r11
    72e311b074b2:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b074b7:	mov    r10d,edx
    72e311b074ba:	and    r10d,0xc000
    72e311b074c1:	shl    r10d,0x10
    72e311b074c5:	mov    r11d,edx
    72e311b074c8:	and    r11d,0x100
    72e311b074cf:	shl    r11d,0x15
    72e311b074d3:	or     r10d,r11d
    72e311b074d6:	and    edx,0x1
    72e311b074d9:	shl    edx,0x1c
    72e311b074dc:	or     r10d,edx
    72e311b074df:	btc    r10,0x1d
    72e311b074e4:	mov    r11d,0xf0000000
    72e311b074ea:	and    r11,r10
    72e311b074ed:	movabs rsi,0xffffffff0fffffff
    72e311b074f7:	and    rbx,rsi
    72e311b074fa:	or     rbx,r11
    72e311b074fd:	pop    r11
    72e311b074ff:	pop    r10
    72e311b07501:	pop    rsi
    72e311b07502:	pop    rdx
    72e311b07503:	mov    QWORD PTR [r12+0x108],rbx
    72e311b0750b:	stmxcsr DWORD PTR [r12-0x28]
    72e311b07511:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b07516:	test   r10d,0x3f
    72e311b0751d:	je     0x72e311b07542
    72e311b07523:	mov    r11d,r10d
    72e311b07526:	shr    r10d,1
    72e311b07529:	and    r10d,0x1e
    72e311b0752d:	and    r11d,0x1
    72e311b07531:	or     r10d,r11d
    72e311b07534:	or     DWORD PTR [r12+0x314],r10d
    72e311b0753c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b07542:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b07548:	lea    rdi,[rsp+0x110]
    72e311b07550:	lea    rsi,[rsp+0xf0]
    72e311b07558:	lea    rdx,[rsp+0x100]
    72e311b07560:	mov    ecx,0x14
    72e311b07565:	mov    r8d,0x0
    72e311b0756b:	lea    r9,[r12+0x314]
    72e311b07573:	movabs r11,0x62e30647e650
    72e311b0757d:	call   r11
    72e311b07580:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b07586:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b0758c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b07592:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b07598:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b0759e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b075a4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b075ae:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b075b8:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b075c2:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b075ca:	mov    QWORD PTR [r12+0x378],0x2
    72e311b075d6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b075df:	mov    rdx,rbx
    72e311b075e2:	shr    rdx,0x10
    72e311b075e6:	and    edx,0xc000
    72e311b075ec:	mov    rax,rbx
    72e311b075ef:	shr    rax,0x15
    72e311b075f3:	and    eax,0x100
    72e311b075f8:	xor    eax,0x100
    72e311b075fd:	or     edx,eax
    72e311b075ff:	mov    rax,rbx
    72e311b07602:	shr    rax,0x1c
    72e311b07606:	and    eax,0x1
    72e311b07609:	or     edx,eax
    72e311b0760b:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b07610:	add    rsp,0x8
    72e311b07614:	ret
    72e311b07615:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b07620:	sub    rsp,0x8
    72e311b07624:	mov    QWORD PTR [r12+0x378],0x3
    72e311b07630:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b07636:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b0763c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b07642:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b07648:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b0764e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b07654:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b0765e:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b07668:	push   rdx
    72e311b07669:	push   rsi
    72e311b0766a:	push   r10
    72e311b0766c:	push   r11
    72e311b0766e:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b07673:	mov    r10d,edx
    72e311b07676:	and    r10d,0xc000
    72e311b0767d:	shl    r10d,0x10
    72e311b07681:	mov    r11d,edx
    72e311b07684:	and    r11d,0x100
    72e311b0768b:	shl    r11d,0x15
    72e311b0768f:	or     r10d,r11d
    72e311b07692:	and    edx,0x1
    72e311b07695:	shl    edx,0x1c
    72e311b07698:	or     r10d,edx
    72e311b0769b:	btc    r10,0x1d
    72e311b076a0:	mov    r11d,0xf0000000
    72e311b076a6:	and    r11,r10
    72e311b076a9:	movabs rsi,0xffffffff0fffffff
    72e311b076b3:	and    rbx,rsi
    72e311b076b6:	or     rbx,r11
    72e311b076b9:	pop    r11
    72e311b076bb:	pop    r10
    72e311b076bd:	pop    rsi
    72e311b076be:	pop    rdx
    72e311b076bf:	mov    QWORD PTR [r12+0x108],rbx
    72e311b076c7:	stmxcsr DWORD PTR [r12-0x28]
    72e311b076cd:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b076d2:	test   r10d,0x3f
    72e311b076d9:	je     0x72e311b076fe
    72e311b076df:	mov    r11d,r10d
    72e311b076e2:	shr    r10d,1
    72e311b076e5:	and    r10d,0x1e
    72e311b076e9:	and    r11d,0x1
    72e311b076ed:	or     r10d,r11d
    72e311b076f0:	or     DWORD PTR [r12+0x314],r10d
    72e311b076f8:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b076fe:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b07704:	lea    rdi,[rsp+0x110]
    72e311b0770c:	lea    rsi,[rsp+0xf0]
    72e311b07714:	lea    rdx,[rsp+0x100]
    72e311b0771c:	mov    ecx,0x56
    72e311b07721:	mov    r8d,0x0
    72e311b07727:	lea    r9,[r12+0x314]
    72e311b0772f:	movabs r11,0x62e30647e650
    72e311b07739:	call   r11
    72e311b0773c:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b07742:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b07748:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b0774e:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b07754:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b0775a:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b07760:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b07766:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b07770:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b0777a:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b07782:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0778e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b07797:	mov    rdx,rbx
    72e311b0779a:	shr    rdx,0x10
    72e311b0779e:	and    edx,0xc000
    72e311b077a4:	mov    rax,rbx
    72e311b077a7:	shr    rax,0x15
    72e311b077ab:	and    eax,0x100
    72e311b077b0:	xor    eax,0x100
    72e311b077b5:	or     edx,eax
    72e311b077b7:	mov    rax,rbx
    72e311b077ba:	shr    rax,0x1c
    72e311b077be:	and    eax,0x1
    72e311b077c1:	or     edx,eax
    72e311b077c3:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b077c8:	add    rsp,0x8
    72e311b077cc:	ret
    72e311b077cd:	nop    DWORD PTR [rax]
    72e311b077d0:	sub    rsp,0x8
    72e311b077d4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b077e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b077e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b077ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b077f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b077f8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b077fe:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b07804:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b0780e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b07818:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b07822:	push   rdx
    72e311b07823:	push   rsi
    72e311b07824:	push   r10
    72e311b07826:	push   r11
    72e311b07828:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b0782d:	mov    r10d,edx
    72e311b07830:	and    r10d,0xc000
    72e311b07837:	shl    r10d,0x10
    72e311b0783b:	mov    r11d,edx
    72e311b0783e:	and    r11d,0x100
    72e311b07845:	shl    r11d,0x15
    72e311b07849:	or     r10d,r11d
    72e311b0784c:	and    edx,0x1
    72e311b0784f:	shl    edx,0x1c
    72e311b07852:	or     r10d,edx
    72e311b07855:	btc    r10,0x1d
    72e311b0785a:	mov    r11d,0xf0000000
    72e311b07860:	and    r11,r10
    72e311b07863:	movabs rsi,0xffffffff0fffffff
    72e311b0786d:	and    rbx,rsi
    72e311b07870:	or     rbx,r11
    72e311b07873:	pop    r11
    72e311b07875:	pop    r10
    72e311b07877:	pop    rsi
    72e311b07878:	pop    rdx
    72e311b07879:	mov    QWORD PTR [r12+0x108],rbx
    72e311b07881:	stmxcsr DWORD PTR [r12-0x28]
    72e311b07887:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b0788c:	test   r10d,0x3f
    72e311b07893:	je     0x72e311b078b8
    72e311b07899:	mov    r11d,r10d
    72e311b0789c:	shr    r10d,1
    72e311b0789f:	and    r10d,0x1e
    72e311b078a3:	and    r11d,0x1
    72e311b078a7:	or     r10d,r11d
    72e311b078aa:	or     DWORD PTR [r12+0x314],r10d
    72e311b078b2:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b078b8:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b078be:	lea    rdi,[rsp+0x110]
    72e311b078c6:	lea    rsi,[rsp+0xf0]
    72e311b078ce:	lea    rdx,[rsp+0x100]
    72e311b078d6:	mov    ecx,0x14
    72e311b078db:	mov    r8d,0x0
    72e311b078e1:	lea    r9,[r12+0x314]
    72e311b078e9:	movabs r11,0x62e30647e650
    72e311b078f3:	call   r11
    72e311b078f6:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b078fc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b07902:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b07908:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b0790e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b07914:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b0791a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b07920:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b0792a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b07934:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b0793e:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b07946:	mov    QWORD PTR [r12+0x378],0x2
    72e311b07952:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b0795b:	mov    rdx,rbx
    72e311b0795e:	shr    rdx,0x10
    72e311b07962:	and    edx,0xc000
    72e311b07968:	mov    rax,rbx
    72e311b0796b:	shr    rax,0x15
    72e311b0796f:	and    eax,0x100
    72e311b07974:	xor    eax,0x100
    72e311b07979:	or     edx,eax
    72e311b0797b:	mov    rax,rbx
    72e311b0797e:	shr    rax,0x1c
    72e311b07982:	and    eax,0x1
    72e311b07985:	or     edx,eax
    72e311b07987:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b0798c:	add    rsp,0x8
    72e311b07990:	ret
    72e311b07991:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b079a0:	sub    rsp,0x8
    72e311b079a4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b079b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b079b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b079bc:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b079c2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b079c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b079d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b079dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b079e6:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b079f0:	push   rdx
    72e311b079f1:	push   rsi
    72e311b079f2:	push   r10
    72e311b079f4:	push   r11
    72e311b079f6:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b079fb:	mov    r10d,edx
    72e311b079fe:	and    r10d,0xc000
    72e311b07a05:	shl    r10d,0x10
    72e311b07a09:	mov    r11d,edx
    72e311b07a0c:	and    r11d,0x100
    72e311b07a13:	shl    r11d,0x15
    72e311b07a17:	or     r10d,r11d
    72e311b07a1a:	and    edx,0x1
    72e311b07a1d:	shl    edx,0x1c
    72e311b07a20:	or     r10d,edx
    72e311b07a23:	btc    r10,0x1d
    72e311b07a28:	mov    r11d,0xf0000000
    72e311b07a2e:	and    r11,r10
    72e311b07a31:	movabs rsi,0xffffffff0fffffff
    72e311b07a3b:	and    rbx,rsi
    72e311b07a3e:	or     rbx,r11
    72e311b07a41:	pop    r11
    72e311b07a43:	pop    r10
    72e311b07a45:	pop    rsi
    72e311b07a46:	pop    rdx
    72e311b07a47:	mov    QWORD PTR [r12+0x108],rbx
    72e311b07a4f:	stmxcsr DWORD PTR [r12-0x28]
    72e311b07a55:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b07a5a:	test   r10d,0x3f
    72e311b07a61:	je     0x72e311b07a86
    72e311b07a67:	mov    r11d,r10d
    72e311b07a6a:	shr    r10d,1
    72e311b07a6d:	and    r10d,0x1e
    72e311b07a71:	and    r11d,0x1
    72e311b07a75:	or     r10d,r11d
    72e311b07a78:	or     DWORD PTR [r12+0x314],r10d
    72e311b07a80:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b07a86:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b07a8c:	lea    rdi,[rsp+0x110]
    72e311b07a94:	lea    rsi,[rsp+0xf0]
    72e311b07a9c:	lea    rdx,[rsp+0x100]
    72e311b07aa4:	mov    ecx,0x14
    72e311b07aa9:	mov    r8d,0x0
    72e311b07aaf:	lea    r9,[r12+0x314]
    72e311b07ab7:	movabs r11,0x62e30647e650
    72e311b07ac1:	call   r11
    72e311b07ac4:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b07aca:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b07ad0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b07ad6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b07adc:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b07ae2:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b07aec:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b07af6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b07b00:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b07b0a:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b07b12:	mov    QWORD PTR [r12+0x378],0x2
    72e311b07b1e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b07b27:	mov    rdx,rbx
    72e311b07b2a:	shr    rdx,0x10
    72e311b07b2e:	and    edx,0xc000
    72e311b07b34:	mov    rax,rbx
    72e311b07b37:	shr    rax,0x15
    72e311b07b3b:	and    eax,0x100
    72e311b07b40:	xor    eax,0x100
    72e311b07b45:	or     edx,eax
    72e311b07b47:	mov    rax,rbx
    72e311b07b4a:	shr    rax,0x1c
    72e311b07b4e:	and    eax,0x1
    72e311b07b51:	or     edx,eax
    72e311b07b53:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b07b58:	add    rsp,0x8
    72e311b07b5c:	ret
    72e311b07b5d:	nop    DWORD PTR [rax]
    72e311b07b60:	sub    rsp,0x8
    72e311b07b64:	mov    QWORD PTR [r12+0x378],0x3
    72e311b07b70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b07b76:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b07b7c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b07b82:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b07b88:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b07b8e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b07b98:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b07ba2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b07bac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b07bb6:	push   rdx
    72e311b07bb7:	push   rsi
    72e311b07bb8:	push   r10
    72e311b07bba:	push   r11
    72e311b07bbc:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b07bc1:	mov    r10d,edx
    72e311b07bc4:	and    r10d,0xc000
    72e311b07bcb:	shl    r10d,0x10
    72e311b07bcf:	mov    r11d,edx
    72e311b07bd2:	and    r11d,0x100
    72e311b07bd9:	shl    r11d,0x15
    72e311b07bdd:	or     r10d,r11d
    72e311b07be0:	and    edx,0x1
    72e311b07be3:	shl    edx,0x1c
    72e311b07be6:	or     r10d,edx
    72e311b07be9:	btc    r10,0x1d
    72e311b07bee:	mov    r11d,0xf0000000
    72e311b07bf4:	and    r11,r10
    72e311b07bf7:	movabs rsi,0xffffffff0fffffff
    72e311b07c01:	and    rbx,rsi
    72e311b07c04:	or     rbx,r11
    72e311b07c07:	pop    r11
    72e311b07c09:	pop    r10
    72e311b07c0b:	pop    rsi
    72e311b07c0c:	pop    rdx
    72e311b07c0d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b07c15:	stmxcsr DWORD PTR [r12-0x28]
    72e311b07c1b:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b07c20:	test   r10d,0x3f
    72e311b07c27:	je     0x72e311b07c4c
    72e311b07c2d:	mov    r11d,r10d
    72e311b07c30:	shr    r10d,1
    72e311b07c33:	and    r10d,0x1e
    72e311b07c37:	and    r11d,0x1
    72e311b07c3b:	or     r10d,r11d
    72e311b07c3e:	or     DWORD PTR [r12+0x314],r10d
    72e311b07c46:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b07c4c:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b07c52:	lea    rdi,[rsp+0x110]
    72e311b07c5a:	lea    rsi,[rsp+0xf0]
    72e311b07c62:	lea    rdx,[rsp+0x100]
    72e311b07c6a:	mov    ecx,0x14
    72e311b07c6f:	mov    r8d,0x0
    72e311b07c75:	lea    r9,[r12+0x314]
    72e311b07c7d:	movabs r11,0x62e30647e650
    72e311b07c87:	call   r11
    72e311b07c8a:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b07c90:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b07c96:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b07c9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b07ca2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b07ca8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b07cae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b07cb8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b07cc2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b07ccc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b07cd6:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b07cde:	mov    QWORD PTR [r12+0x378],0x2
    72e311b07cea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b07cf3:	mov    rdx,rbx
    72e311b07cf6:	shr    rdx,0x10
    72e311b07cfa:	and    edx,0xc000
    72e311b07d00:	mov    rax,rbx
    72e311b07d03:	shr    rax,0x15
    72e311b07d07:	and    eax,0x100
    72e311b07d0c:	xor    eax,0x100
    72e311b07d11:	or     edx,eax
    72e311b07d13:	mov    rax,rbx
    72e311b07d16:	shr    rax,0x1c
    72e311b07d1a:	and    eax,0x1
    72e311b07d1d:	or     edx,eax
    72e311b07d1f:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b07d24:	add    rsp,0x8
    72e311b07d28:	ret
    72e311b07d29:	nop    DWORD PTR [rax+0x0]
    72e311b07d30:	sub    rsp,0x8
    72e311b07d34:	mov    QWORD PTR [r12+0x378],0x3
    72e311b07d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b07d46:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b07d4c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b07d52:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b07d58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b07d5e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b07d68:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b07d72:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b07d7c:	push   rdx
    72e311b07d7d:	push   rsi
    72e311b07d7e:	push   r10
    72e311b07d80:	push   r11
    72e311b07d82:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b07d87:	mov    r10d,edx
    72e311b07d8a:	and    r10d,0xc000
    72e311b07d91:	shl    r10d,0x10
    72e311b07d95:	mov    r11d,edx
    72e311b07d98:	and    r11d,0x100
    72e311b07d9f:	shl    r11d,0x15
    72e311b07da3:	or     r10d,r11d
    72e311b07da6:	and    edx,0x1
    72e311b07da9:	shl    edx,0x1c
    72e311b07dac:	or     r10d,edx
    72e311b07daf:	btc    r10,0x1d
    72e311b07db4:	mov    r11d,0xf0000000
    72e311b07dba:	and    r11,r10
    72e311b07dbd:	movabs rsi,0xffffffff0fffffff
    72e311b07dc7:	and    rbx,rsi
    72e311b07dca:	or     rbx,r11
    72e311b07dcd:	pop    r11
    72e311b07dcf:	pop    r10
    72e311b07dd1:	pop    rsi
    72e311b07dd2:	pop    rdx
    72e311b07dd3:	mov    QWORD PTR [r12+0x108],rbx
    72e311b07ddb:	stmxcsr DWORD PTR [r12-0x28]
    72e311b07de1:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b07de6:	test   r10d,0x3f
    72e311b07ded:	je     0x72e311b07e12
    72e311b07df3:	mov    r11d,r10d
    72e311b07df6:	shr    r10d,1
    72e311b07df9:	and    r10d,0x1e
    72e311b07dfd:	and    r11d,0x1
    72e311b07e01:	or     r10d,r11d
    72e311b07e04:	or     DWORD PTR [r12+0x314],r10d
    72e311b07e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b07e12:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b07e18:	lea    rdi,[rsp+0x110]
    72e311b07e20:	lea    rsi,[rsp+0xf0]
    72e311b07e28:	lea    rdx,[rsp+0x100]
    72e311b07e30:	mov    ecx,0x56
    72e311b07e35:	mov    r8d,0x0
    72e311b07e3b:	lea    r9,[r12+0x314]
    72e311b07e43:	movabs r11,0x62e30647e650
    72e311b07e4d:	call   r11
    72e311b07e50:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b07e56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b07e5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b07e62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b07e68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b07e6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b07e74:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b07e7e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b07e88:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b07e92:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b07e9a:	mov    QWORD PTR [r12+0x378],0x2
    72e311b07ea6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b07eaf:	mov    rdx,rbx
    72e311b07eb2:	shr    rdx,0x10
    72e311b07eb6:	and    edx,0xc000
    72e311b07ebc:	mov    rax,rbx
    72e311b07ebf:	shr    rax,0x15
    72e311b07ec3:	and    eax,0x100
    72e311b07ec8:	xor    eax,0x100
    72e311b07ecd:	or     edx,eax
    72e311b07ecf:	mov    rax,rbx
    72e311b07ed2:	shr    rax,0x1c
    72e311b07ed6:	and    eax,0x1
    72e311b07ed9:	or     edx,eax
    72e311b07edb:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b07ee0:	add    rsp,0x8
    72e311b07ee4:	ret
    72e311b07ee5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b07ef0:	sub    rsp,0x8
    72e311b07ef4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b07f00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b07f06:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b07f0c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b07f12:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b07f18:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b07f1e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b07f28:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b07f32:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b07f3c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b07f46:	push   rdx
    72e311b07f47:	push   rsi
    72e311b07f48:	push   r10
    72e311b07f4a:	push   r11
    72e311b07f4c:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b07f51:	mov    r10d,edx
    72e311b07f54:	and    r10d,0xc000
    72e311b07f5b:	shl    r10d,0x10
    72e311b07f5f:	mov    r11d,edx
    72e311b07f62:	and    r11d,0x100
    72e311b07f69:	shl    r11d,0x15
    72e311b07f6d:	or     r10d,r11d
    72e311b07f70:	and    edx,0x1
    72e311b07f73:	shl    edx,0x1c
    72e311b07f76:	or     r10d,edx
    72e311b07f79:	btc    r10,0x1d
    72e311b07f7e:	mov    r11d,0xf0000000
    72e311b07f84:	and    r11,r10
    72e311b07f87:	movabs rsi,0xffffffff0fffffff
    72e311b07f91:	and    rbx,rsi
    72e311b07f94:	or     rbx,r11
    72e311b07f97:	pop    r11
    72e311b07f99:	pop    r10
    72e311b07f9b:	pop    rsi
    72e311b07f9c:	pop    rdx
    72e311b07f9d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b07fa5:	stmxcsr DWORD PTR [r12-0x28]
    72e311b07fab:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b07fb0:	test   r10d,0x3f
    72e311b07fb7:	je     0x72e311b07fdc
    72e311b07fbd:	mov    r11d,r10d
    72e311b07fc0:	shr    r10d,1
    72e311b07fc3:	and    r10d,0x1e
    72e311b07fc7:	and    r11d,0x1
    72e311b07fcb:	or     r10d,r11d
    72e311b07fce:	or     DWORD PTR [r12+0x314],r10d
    72e311b07fd6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b07fdc:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b07fe2:	lea    rdi,[rsp+0x110]
    72e311b07fea:	lea    rsi,[rsp+0xf0]
    72e311b07ff2:	lea    rdx,[rsp+0x100]
    72e311b07ffa:	mov    ecx,0x56
    72e311b07fff:	mov    r8d,0x0
    72e311b08005:	lea    r9,[r12+0x314]
    72e311b0800d:	movabs r11,0x62e30647e650
    72e311b08017:	call   r11
    72e311b0801a:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b08020:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b08026:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b0802c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b08032:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b08038:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b0803e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b08048:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b08052:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b0805c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b08066:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0806e:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0807a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b08083:	mov    rdx,rbx
    72e311b08086:	shr    rdx,0x10
    72e311b0808a:	and    edx,0xc000
    72e311b08090:	mov    rax,rbx
    72e311b08093:	shr    rax,0x15
    72e311b08097:	and    eax,0x100
    72e311b0809c:	xor    eax,0x100
    72e311b080a1:	or     edx,eax
    72e311b080a3:	mov    rax,rbx
    72e311b080a6:	shr    rax,0x1c
    72e311b080aa:	and    eax,0x1
    72e311b080ad:	or     edx,eax
    72e311b080af:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b080b4:	add    rsp,0x8
    72e311b080b8:	ret
    72e311b080b9:	nop    DWORD PTR [rax+0x0]
    72e311b080c0:	sub    rsp,0x8
    72e311b080c4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b080d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b080d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b080dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b080e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b080e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b080ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b080f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b08102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b0810c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b08116:	push   rdx
    72e311b08117:	push   rsi
    72e311b08118:	push   r10
    72e311b0811a:	push   r11
    72e311b0811c:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b08121:	mov    r10d,edx
    72e311b08124:	and    r10d,0xc000
    72e311b0812b:	shl    r10d,0x10
    72e311b0812f:	mov    r11d,edx
    72e311b08132:	and    r11d,0x100
    72e311b08139:	shl    r11d,0x15
    72e311b0813d:	or     r10d,r11d
    72e311b08140:	and    edx,0x1
    72e311b08143:	shl    edx,0x1c
    72e311b08146:	or     r10d,edx
    72e311b08149:	btc    r10,0x1d
    72e311b0814e:	mov    r11d,0xf0000000
    72e311b08154:	and    r11,r10
    72e311b08157:	movabs rsi,0xffffffff0fffffff
    72e311b08161:	and    rbx,rsi
    72e311b08164:	or     rbx,r11
    72e311b08167:	pop    r11
    72e311b08169:	pop    r10
    72e311b0816b:	pop    rsi
    72e311b0816c:	pop    rdx
    72e311b0816d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b08175:	stmxcsr DWORD PTR [r12-0x28]
    72e311b0817b:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b08180:	test   r10d,0x3f
    72e311b08187:	je     0x72e311b081ac
    72e311b0818d:	mov    r11d,r10d
    72e311b08190:	shr    r10d,1
    72e311b08193:	and    r10d,0x1e
    72e311b08197:	and    r11d,0x1
    72e311b0819b:	or     r10d,r11d
    72e311b0819e:	or     DWORD PTR [r12+0x314],r10d
    72e311b081a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b081ac:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b081b2:	lea    rdi,[rsp+0x110]
    72e311b081ba:	lea    rsi,[rsp+0xf0]
    72e311b081c2:	lea    rdx,[rsp+0x100]
    72e311b081ca:	mov    ecx,0x14
    72e311b081cf:	mov    r8d,0x0
    72e311b081d5:	lea    r9,[r12+0x314]
    72e311b081dd:	movabs r11,0x62e30647e650
    72e311b081e7:	call   r11
    72e311b081ea:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b081f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b081f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b081fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b08202:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b08208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b0820e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b08218:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b08222:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b0822c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b08236:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0823e:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0824a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b08253:	mov    rdx,rbx
    72e311b08256:	shr    rdx,0x10
    72e311b0825a:	and    edx,0xc000
    72e311b08260:	mov    rax,rbx
    72e311b08263:	shr    rax,0x15
    72e311b08267:	and    eax,0x100
    72e311b0826c:	xor    eax,0x100
    72e311b08271:	or     edx,eax
    72e311b08273:	mov    rax,rbx
    72e311b08276:	shr    rax,0x1c
    72e311b0827a:	and    eax,0x1
    72e311b0827d:	or     edx,eax
    72e311b0827f:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b08284:	add    rsp,0x8
    72e311b08288:	ret
    72e311b08289:	nop    DWORD PTR [rax+0x0]
    72e311b08290:	sub    rsp,0x8
    72e311b08294:	mov    QWORD PTR [r12+0x378],0x3
    72e311b082a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b082a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b082ac:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b082b2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b082b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b082be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b082c8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b082d2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b082dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b082e6:	push   rdx
    72e311b082e7:	push   rsi
    72e311b082e8:	push   r10
    72e311b082ea:	push   r11
    72e311b082ec:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b082f1:	mov    r10d,edx
    72e311b082f4:	and    r10d,0xc000
    72e311b082fb:	shl    r10d,0x10
    72e311b082ff:	mov    r11d,edx
    72e311b08302:	and    r11d,0x100
    72e311b08309:	shl    r11d,0x15
    72e311b0830d:	or     r10d,r11d
    72e311b08310:	and    edx,0x1
    72e311b08313:	shl    edx,0x1c
    72e311b08316:	or     r10d,edx
    72e311b08319:	btc    r10,0x1d
    72e311b0831e:	mov    r11d,0xf0000000
    72e311b08324:	and    r11,r10
    72e311b08327:	movabs rsi,0xffffffff0fffffff
    72e311b08331:	and    rbx,rsi
    72e311b08334:	or     rbx,r11
    72e311b08337:	pop    r11
    72e311b08339:	pop    r10
    72e311b0833b:	pop    rsi
    72e311b0833c:	pop    rdx
    72e311b0833d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b08345:	stmxcsr DWORD PTR [r12-0x28]
    72e311b0834b:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b08350:	test   r10d,0x3f
    72e311b08357:	je     0x72e311b0837c
    72e311b0835d:	mov    r11d,r10d
    72e311b08360:	shr    r10d,1
    72e311b08363:	and    r10d,0x1e
    72e311b08367:	and    r11d,0x1
    72e311b0836b:	or     r10d,r11d
    72e311b0836e:	or     DWORD PTR [r12+0x314],r10d
    72e311b08376:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b0837c:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b08382:	lea    rdi,[rsp+0x110]
    72e311b0838a:	lea    rsi,[rsp+0xf0]
    72e311b08392:	lea    rdx,[rsp+0x100]
    72e311b0839a:	mov    ecx,0x56
    72e311b0839f:	mov    r8d,0x0
    72e311b083a5:	lea    r9,[r12+0x314]
    72e311b083ad:	movabs r11,0x62e30647e650
    72e311b083b7:	call   r11
    72e311b083ba:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b083c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b083c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b083cc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b083d2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b083d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b083de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b083e8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b083f2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b083fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b08406:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0840e:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0841a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b08423:	mov    rdx,rbx
    72e311b08426:	shr    rdx,0x10
    72e311b0842a:	and    edx,0xc000
    72e311b08430:	mov    rax,rbx
    72e311b08433:	shr    rax,0x15
    72e311b08437:	and    eax,0x100
    72e311b0843c:	xor    eax,0x100
    72e311b08441:	or     edx,eax
    72e311b08443:	mov    rax,rbx
    72e311b08446:	shr    rax,0x1c
    72e311b0844a:	and    eax,0x1
    72e311b0844d:	or     edx,eax
    72e311b0844f:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b08454:	add    rsp,0x8
    72e311b08458:	ret
    72e311b08459:	nop    DWORD PTR [rax+0x0]
    72e311b08460:	sub    rsp,0x8
    72e311b08464:	mov    QWORD PTR [r12+0x378],0x3
    72e311b08470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b08476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b0847c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b08482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b08488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b0848e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b08498:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b084a2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b084ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b084b6:	push   rdx
    72e311b084b7:	push   rsi
    72e311b084b8:	push   r10
    72e311b084ba:	push   r11
    72e311b084bc:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b084c1:	mov    r10d,edx
    72e311b084c4:	and    r10d,0xc000
    72e311b084cb:	shl    r10d,0x10
    72e311b084cf:	mov    r11d,edx
    72e311b084d2:	and    r11d,0x100
    72e311b084d9:	shl    r11d,0x15
    72e311b084dd:	or     r10d,r11d
    72e311b084e0:	and    edx,0x1
    72e311b084e3:	shl    edx,0x1c
    72e311b084e6:	or     r10d,edx
    72e311b084e9:	btc    r10,0x1d
    72e311b084ee:	mov    r11d,0xf0000000
    72e311b084f4:	and    r11,r10
    72e311b084f7:	movabs rsi,0xffffffff0fffffff
    72e311b08501:	and    rbx,rsi
    72e311b08504:	or     rbx,r11
    72e311b08507:	pop    r11
    72e311b08509:	pop    r10
    72e311b0850b:	pop    rsi
    72e311b0850c:	pop    rdx
    72e311b0850d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b08515:	stmxcsr DWORD PTR [r12-0x28]
    72e311b0851b:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b08520:	test   r10d,0x3f
    72e311b08527:	je     0x72e311b0854c
    72e311b0852d:	mov    r11d,r10d
    72e311b08530:	shr    r10d,1
    72e311b08533:	and    r10d,0x1e
    72e311b08537:	and    r11d,0x1
    72e311b0853b:	or     r10d,r11d
    72e311b0853e:	or     DWORD PTR [r12+0x314],r10d
    72e311b08546:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b0854c:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b08552:	lea    rdi,[rsp+0x110]
    72e311b0855a:	lea    rsi,[rsp+0xf0]
    72e311b08562:	lea    rdx,[rsp+0x100]
    72e311b0856a:	mov    ecx,0x14
    72e311b0856f:	mov    r8d,0x0
    72e311b08575:	lea    r9,[r12+0x314]
    72e311b0857d:	movabs r11,0x62e30647e650
    72e311b08587:	call   r11
    72e311b0858a:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b08590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b08596:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b0859c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b085a2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b085a8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b085ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b085b8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b085c2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b085cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b085d6:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b085de:	mov    QWORD PTR [r12+0x378],0x2
    72e311b085ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b085f3:	mov    rdx,rbx
    72e311b085f6:	shr    rdx,0x10
    72e311b085fa:	and    edx,0xc000
    72e311b08600:	mov    rax,rbx
    72e311b08603:	shr    rax,0x15
    72e311b08607:	and    eax,0x100
    72e311b0860c:	xor    eax,0x100
    72e311b08611:	or     edx,eax
    72e311b08613:	mov    rax,rbx
    72e311b08616:	shr    rax,0x1c
    72e311b0861a:	and    eax,0x1
    72e311b0861d:	or     edx,eax
    72e311b0861f:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b08624:	add    rsp,0x8
    72e311b08628:	ret
    72e311b08629:	nop    DWORD PTR [rax+0x0]
    72e311b08630:	sub    rsp,0x8
    72e311b08634:	mov    QWORD PTR [r12+0x378],0x3
    72e311b08640:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b08646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b0864c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b08652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b08658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b0865e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b08668:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b08672:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b0867c:	push   rdx
    72e311b0867d:	push   rsi
    72e311b0867e:	push   r10
    72e311b08680:	push   r11
    72e311b08682:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b08687:	mov    r10d,edx
    72e311b0868a:	and    r10d,0xc000
    72e311b08691:	shl    r10d,0x10
    72e311b08695:	mov    r11d,edx
    72e311b08698:	and    r11d,0x100
    72e311b0869f:	shl    r11d,0x15
    72e311b086a3:	or     r10d,r11d
    72e311b086a6:	and    edx,0x1
    72e311b086a9:	shl    edx,0x1c
    72e311b086ac:	or     r10d,edx
    72e311b086af:	btc    r10,0x1d
    72e311b086b4:	mov    r11d,0xf0000000
    72e311b086ba:	and    r11,r10
    72e311b086bd:	movabs rsi,0xffffffff0fffffff
    72e311b086c7:	and    rbx,rsi
    72e311b086ca:	or     rbx,r11
    72e311b086cd:	pop    r11
    72e311b086cf:	pop    r10
    72e311b086d1:	pop    rsi
    72e311b086d2:	pop    rdx
    72e311b086d3:	mov    QWORD PTR [r12+0x108],rbx
    72e311b086db:	stmxcsr DWORD PTR [r12-0x28]
    72e311b086e1:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b086e6:	test   r10d,0x3f
    72e311b086ed:	je     0x72e311b08712
    72e311b086f3:	mov    r11d,r10d
    72e311b086f6:	shr    r10d,1
    72e311b086f9:	and    r10d,0x1e
    72e311b086fd:	and    r11d,0x1
    72e311b08701:	or     r10d,r11d
    72e311b08704:	or     DWORD PTR [r12+0x314],r10d
    72e311b0870c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b08712:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b08718:	lea    rdi,[rsp+0x110]
    72e311b08720:	lea    rsi,[rsp+0xf0]
    72e311b08728:	lea    rdx,[rsp+0x100]
    72e311b08730:	mov    ecx,0x14
    72e311b08735:	mov    r8d,0x0
    72e311b0873b:	lea    r9,[r12+0x314]
    72e311b08743:	movabs r11,0x62e30647e650
    72e311b0874d:	call   r11
    72e311b08750:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b08756:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b0875c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b08762:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b08768:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b0876e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b08774:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b0877e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b08788:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b08792:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0879a:	mov    QWORD PTR [r12+0x378],0x2
    72e311b087a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b087af:	mov    rdx,rbx
    72e311b087b2:	shr    rdx,0x10
    72e311b087b6:	and    edx,0xc000
    72e311b087bc:	mov    rax,rbx
    72e311b087bf:	shr    rax,0x15
    72e311b087c3:	and    eax,0x100
    72e311b087c8:	xor    eax,0x100
    72e311b087cd:	or     edx,eax
    72e311b087cf:	mov    rax,rbx
    72e311b087d2:	shr    rax,0x1c
    72e311b087d6:	and    eax,0x1
    72e311b087d9:	or     edx,eax
    72e311b087db:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b087e0:	add    rsp,0x8
    72e311b087e4:	ret
    72e311b087e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b087f0:	sub    rsp,0x8
    72e311b087f4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b08800:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b08806:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b0880c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b08812:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b08818:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b0881e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b08828:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b08832:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b0883c:	push   rdx
    72e311b0883d:	push   rsi
    72e311b0883e:	push   r10
    72e311b08840:	push   r11
    72e311b08842:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b08847:	mov    r10d,edx
    72e311b0884a:	and    r10d,0xc000
    72e311b08851:	shl    r10d,0x10
    72e311b08855:	mov    r11d,edx
    72e311b08858:	and    r11d,0x100
    72e311b0885f:	shl    r11d,0x15
    72e311b08863:	or     r10d,r11d
    72e311b08866:	and    edx,0x1
    72e311b08869:	shl    edx,0x1c
    72e311b0886c:	or     r10d,edx
    72e311b0886f:	btc    r10,0x1d
    72e311b08874:	mov    r11d,0xf0000000
    72e311b0887a:	and    r11,r10
    72e311b0887d:	movabs rsi,0xffffffff0fffffff
    72e311b08887:	and    rbx,rsi
    72e311b0888a:	or     rbx,r11
    72e311b0888d:	pop    r11
    72e311b0888f:	pop    r10
    72e311b08891:	pop    rsi
    72e311b08892:	pop    rdx
    72e311b08893:	mov    QWORD PTR [r12+0x108],rbx
    72e311b0889b:	stmxcsr DWORD PTR [r12-0x28]
    72e311b088a1:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b088a6:	test   r10d,0x3f
    72e311b088ad:	je     0x72e311b088d2
    72e311b088b3:	mov    r11d,r10d
    72e311b088b6:	shr    r10d,1
    72e311b088b9:	and    r10d,0x1e
    72e311b088bd:	and    r11d,0x1
    72e311b088c1:	or     r10d,r11d
    72e311b088c4:	or     DWORD PTR [r12+0x314],r10d
    72e311b088cc:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b088d2:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b088d8:	lea    rdi,[rsp+0x110]
    72e311b088e0:	lea    rsi,[rsp+0xf0]
    72e311b088e8:	lea    rdx,[rsp+0x100]
    72e311b088f0:	mov    ecx,0x14
    72e311b088f5:	mov    r8d,0x0
    72e311b088fb:	lea    r9,[r12+0x314]
    72e311b08903:	movabs r11,0x62e30647e650
    72e311b0890d:	call   r11
    72e311b08910:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b08916:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b0891c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b08922:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b08928:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b0892e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b08934:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b0893e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b08948:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b08952:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0895a:	mov    QWORD PTR [r12+0x378],0x2
    72e311b08966:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b0896f:	mov    rdx,rbx
    72e311b08972:	shr    rdx,0x10
    72e311b08976:	and    edx,0xc000
    72e311b0897c:	mov    rax,rbx
    72e311b0897f:	shr    rax,0x15
    72e311b08983:	and    eax,0x100
    72e311b08988:	xor    eax,0x100
    72e311b0898d:	or     edx,eax
    72e311b0898f:	mov    rax,rbx
    72e311b08992:	shr    rax,0x1c
    72e311b08996:	and    eax,0x1
    72e311b08999:	or     edx,eax
    72e311b0899b:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b089a0:	add    rsp,0x8
    72e311b089a4:	ret
    72e311b089a5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b089b0:	sub    rsp,0x8
    72e311b089b4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b089c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b089c6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b089cc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b089d2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b089d8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b089de:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b089e4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b089ee:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b089f8:	push   rdx
    72e311b089f9:	push   rsi
    72e311b089fa:	push   r10
    72e311b089fc:	push   r11
    72e311b089fe:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b08a03:	mov    r10d,edx
    72e311b08a06:	and    r10d,0xc000
    72e311b08a0d:	shl    r10d,0x10
    72e311b08a11:	mov    r11d,edx
    72e311b08a14:	and    r11d,0x100
    72e311b08a1b:	shl    r11d,0x15
    72e311b08a1f:	or     r10d,r11d
    72e311b08a22:	and    edx,0x1
    72e311b08a25:	shl    edx,0x1c
    72e311b08a28:	or     r10d,edx
    72e311b08a2b:	btc    r10,0x1d
    72e311b08a30:	mov    r11d,0xf0000000
    72e311b08a36:	and    r11,r10
    72e311b08a39:	movabs rsi,0xffffffff0fffffff
    72e311b08a43:	and    rbx,rsi
    72e311b08a46:	or     rbx,r11
    72e311b08a49:	pop    r11
    72e311b08a4b:	pop    r10
    72e311b08a4d:	pop    rsi
    72e311b08a4e:	pop    rdx
    72e311b08a4f:	mov    QWORD PTR [r12+0x108],rbx
    72e311b08a57:	stmxcsr DWORD PTR [r12-0x28]
    72e311b08a5d:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b08a62:	test   r10d,0x3f
    72e311b08a69:	je     0x72e311b08a8e
    72e311b08a6f:	mov    r11d,r10d
    72e311b08a72:	shr    r10d,1
    72e311b08a75:	and    r10d,0x1e
    72e311b08a79:	and    r11d,0x1
    72e311b08a7d:	or     r10d,r11d
    72e311b08a80:	or     DWORD PTR [r12+0x314],r10d
    72e311b08a88:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b08a8e:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b08a94:	lea    rdi,[rsp+0x110]
    72e311b08a9c:	lea    rsi,[rsp+0xf0]
    72e311b08aa4:	lea    rdx,[rsp+0x100]
    72e311b08aac:	mov    ecx,0x56
    72e311b08ab1:	mov    r8d,0x0
    72e311b08ab7:	lea    r9,[r12+0x314]
    72e311b08abf:	movabs r11,0x62e30647e650
    72e311b08ac9:	call   r11
    72e311b08acc:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b08ad2:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b08ad8:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b08ade:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b08ae4:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b08aea:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b08af0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b08af6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b08b00:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b08b0a:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b08b12:	mov    QWORD PTR [r12+0x378],0x2
    72e311b08b1e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b08b27:	mov    rdx,rbx
    72e311b08b2a:	shr    rdx,0x10
    72e311b08b2e:	and    edx,0xc000
    72e311b08b34:	mov    rax,rbx
    72e311b08b37:	shr    rax,0x15
    72e311b08b3b:	and    eax,0x100
    72e311b08b40:	xor    eax,0x100
    72e311b08b45:	or     edx,eax
    72e311b08b47:	mov    rax,rbx
    72e311b08b4a:	shr    rax,0x1c
    72e311b08b4e:	and    eax,0x1
    72e311b08b51:	or     edx,eax
    72e311b08b53:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b08b58:	add    rsp,0x8
    72e311b08b5c:	ret
    72e311b08b5d:	nop    DWORD PTR [rax]
    72e311b08b60:	sub    rsp,0x8
    72e311b08b64:	mov    QWORD PTR [r12+0x378],0x3
    72e311b08b70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b08b76:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b08b7c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b08b82:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b08b88:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b08b8e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b08b98:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b08ba2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b08bac:	push   rdx
    72e311b08bad:	push   rsi
    72e311b08bae:	push   r10
    72e311b08bb0:	push   r11
    72e311b08bb2:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b08bb7:	mov    r10d,edx
    72e311b08bba:	and    r10d,0xc000
    72e311b08bc1:	shl    r10d,0x10
    72e311b08bc5:	mov    r11d,edx
    72e311b08bc8:	and    r11d,0x100
    72e311b08bcf:	shl    r11d,0x15
    72e311b08bd3:	or     r10d,r11d
    72e311b08bd6:	and    edx,0x1
    72e311b08bd9:	shl    edx,0x1c
    72e311b08bdc:	or     r10d,edx
    72e311b08bdf:	btc    r10,0x1d
    72e311b08be4:	mov    r11d,0xf0000000
    72e311b08bea:	and    r11,r10
    72e311b08bed:	movabs rsi,0xffffffff0fffffff
    72e311b08bf7:	and    rbx,rsi
    72e311b08bfa:	or     rbx,r11
    72e311b08bfd:	pop    r11
    72e311b08bff:	pop    r10
    72e311b08c01:	pop    rsi
    72e311b08c02:	pop    rdx
    72e311b08c03:	mov    QWORD PTR [r12+0x108],rbx
    72e311b08c0b:	stmxcsr DWORD PTR [r12-0x28]
    72e311b08c11:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b08c16:	test   r10d,0x3f
    72e311b08c1d:	je     0x72e311b08c42
    72e311b08c23:	mov    r11d,r10d
    72e311b08c26:	shr    r10d,1
    72e311b08c29:	and    r10d,0x1e
    72e311b08c2d:	and    r11d,0x1
    72e311b08c31:	or     r10d,r11d
    72e311b08c34:	or     DWORD PTR [r12+0x314],r10d
    72e311b08c3c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b08c42:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b08c48:	lea    rdi,[rsp+0x110]
    72e311b08c50:	lea    rsi,[rsp+0xf0]
    72e311b08c58:	lea    rdx,[rsp+0x100]
    72e311b08c60:	mov    ecx,0x56
    72e311b08c65:	mov    r8d,0x0
    72e311b08c6b:	lea    r9,[r12+0x314]
    72e311b08c73:	movabs r11,0x62e30647e650
    72e311b08c7d:	call   r11
    72e311b08c80:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b08c86:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b08c8c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b08c92:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b08c98:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b08c9e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b08ca4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b08cae:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b08cb8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b08cc2:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b08cca:	mov    QWORD PTR [r12+0x378],0x2
    72e311b08cd6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b08cdf:	mov    rdx,rbx
    72e311b08ce2:	shr    rdx,0x10
    72e311b08ce6:	and    edx,0xc000
    72e311b08cec:	mov    rax,rbx
    72e311b08cef:	shr    rax,0x15
    72e311b08cf3:	and    eax,0x100
    72e311b08cf8:	xor    eax,0x100
    72e311b08cfd:	or     edx,eax
    72e311b08cff:	mov    rax,rbx
    72e311b08d02:	shr    rax,0x1c
    72e311b08d06:	and    eax,0x1
    72e311b08d09:	or     edx,eax
    72e311b08d0b:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b08d10:	add    rsp,0x8
    72e311b08d14:	ret
    72e311b08d15:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b08d20:	sub    rsp,0x8
    72e311b08d24:	mov    QWORD PTR [r12+0x378],0x3
    72e311b08d30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b08d36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b08d3c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b08d42:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b08d48:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b08d4e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b08d54:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b08d5e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b08d68:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    72e311b08d72:	push   rdx
    72e311b08d73:	push   rsi
    72e311b08d74:	push   r10
    72e311b08d76:	push   r11
    72e311b08d78:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b08d7d:	mov    r10d,edx
    72e311b08d80:	and    r10d,0xc000
    72e311b08d87:	shl    r10d,0x10
    72e311b08d8b:	mov    r11d,edx
    72e311b08d8e:	and    r11d,0x100
    72e311b08d95:	shl    r11d,0x15
    72e311b08d99:	or     r10d,r11d
    72e311b08d9c:	and    edx,0x1
    72e311b08d9f:	shl    edx,0x1c
    72e311b08da2:	or     r10d,edx
    72e311b08da5:	btc    r10,0x1d
    72e311b08daa:	mov    r11d,0xf0000000
    72e311b08db0:	and    r11,r10
    72e311b08db3:	movabs rsi,0xffffffff0fffffff
    72e311b08dbd:	and    rbx,rsi
    72e311b08dc0:	or     rbx,r11
    72e311b08dc3:	pop    r11
    72e311b08dc5:	pop    r10
    72e311b08dc7:	pop    rsi
    72e311b08dc8:	pop    rdx
    72e311b08dc9:	mov    QWORD PTR [r12+0x108],rbx
    72e311b08dd1:	stmxcsr DWORD PTR [r12-0x28]
    72e311b08dd7:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b08ddc:	test   r10d,0x3f
    72e311b08de3:	je     0x72e311b08e08
    72e311b08de9:	mov    r11d,r10d
    72e311b08dec:	shr    r10d,1
    72e311b08def:	and    r10d,0x1e
    72e311b08df3:	and    r11d,0x1
    72e311b08df7:	or     r10d,r11d
    72e311b08dfa:	or     DWORD PTR [r12+0x314],r10d
    72e311b08e02:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b08e08:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b08e0e:	lea    rdi,[rsp+0x110]
    72e311b08e16:	lea    rsi,[rsp+0xf0]
    72e311b08e1e:	lea    rdx,[rsp+0x100]
    72e311b08e26:	mov    ecx,0x14
    72e311b08e2b:	mov    r8d,0x0
    72e311b08e31:	lea    r9,[r12+0x314]
    72e311b08e39:	movabs r11,0x62e30647e650
    72e311b08e43:	call   r11
    72e311b08e46:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b08e4c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b08e52:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b08e58:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b08e5e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b08e64:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b08e6a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b08e70:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b08e7a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b08e84:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    72e311b08e8e:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b08e96:	mov    QWORD PTR [r12+0x378],0x2
    72e311b08ea2:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b08eab:	mov    rdx,rbx
    72e311b08eae:	shr    rdx,0x10
    72e311b08eb2:	and    edx,0xc000
    72e311b08eb8:	mov    rax,rbx
    72e311b08ebb:	shr    rax,0x15
    72e311b08ebf:	and    eax,0x100
    72e311b08ec4:	xor    eax,0x100
    72e311b08ec9:	or     edx,eax
    72e311b08ecb:	mov    rax,rbx
    72e311b08ece:	shr    rax,0x1c
    72e311b08ed2:	and    eax,0x1
    72e311b08ed5:	or     edx,eax
    72e311b08ed7:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b08edc:	add    rsp,0x8
    72e311b08ee0:	ret
    72e311b08ee1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b08ef0:	sub    rsp,0x8
    72e311b08ef4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b08f00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b08f06:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b08f0c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b08f12:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b08f18:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b08f1e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b08f28:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b08f32:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b08f3c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b08f46:	push   rdx
    72e311b08f47:	push   rsi
    72e311b08f48:	push   r10
    72e311b08f4a:	push   r11
    72e311b08f4c:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b08f51:	mov    r10d,edx
    72e311b08f54:	and    r10d,0xc000
    72e311b08f5b:	shl    r10d,0x10
    72e311b08f5f:	mov    r11d,edx
    72e311b08f62:	and    r11d,0x100
    72e311b08f69:	shl    r11d,0x15
    72e311b08f6d:	or     r10d,r11d
    72e311b08f70:	and    edx,0x1
    72e311b08f73:	shl    edx,0x1c
    72e311b08f76:	or     r10d,edx
    72e311b08f79:	btc    r10,0x1d
    72e311b08f7e:	mov    r11d,0xf0000000
    72e311b08f84:	and    r11,r10
    72e311b08f87:	movabs rsi,0xffffffff0fffffff
    72e311b08f91:	and    rbx,rsi
    72e311b08f94:	or     rbx,r11
    72e311b08f97:	pop    r11
    72e311b08f99:	pop    r10
    72e311b08f9b:	pop    rsi
    72e311b08f9c:	pop    rdx
    72e311b08f9d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b08fa5:	stmxcsr DWORD PTR [r12-0x28]
    72e311b08fab:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b08fb0:	test   r10d,0x3f
    72e311b08fb7:	je     0x72e311b08fdc
    72e311b08fbd:	mov    r11d,r10d
    72e311b08fc0:	shr    r10d,1
    72e311b08fc3:	and    r10d,0x1e
    72e311b08fc7:	and    r11d,0x1
    72e311b08fcb:	or     r10d,r11d
    72e311b08fce:	or     DWORD PTR [r12+0x314],r10d
    72e311b08fd6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b08fdc:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b08fe2:	lea    rdi,[rsp+0x110]
    72e311b08fea:	lea    rsi,[rsp+0xf0]
    72e311b08ff2:	lea    rdx,[rsp+0x100]
    72e311b08ffa:	mov    ecx,0x56
    72e311b08fff:	mov    r8d,0x0
    72e311b09005:	lea    r9,[r12+0x314]
    72e311b0900d:	movabs r11,0x62e30647e650
    72e311b09017:	call   r11
    72e311b0901a:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b09020:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b09026:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b0902c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b09032:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b09038:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b0903e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b09048:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b09052:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b0905c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b09066:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0906e:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0907a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b09083:	mov    rdx,rbx
    72e311b09086:	shr    rdx,0x10
    72e311b0908a:	and    edx,0xc000
    72e311b09090:	mov    rax,rbx
    72e311b09093:	shr    rax,0x15
    72e311b09097:	and    eax,0x100
    72e311b0909c:	xor    eax,0x100
    72e311b090a1:	or     edx,eax
    72e311b090a3:	mov    rax,rbx
    72e311b090a6:	shr    rax,0x1c
    72e311b090aa:	and    eax,0x1
    72e311b090ad:	or     edx,eax
    72e311b090af:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b090b4:	add    rsp,0x8
    72e311b090b8:	ret
    72e311b090b9:	nop    DWORD PTR [rax+0x0]
    72e311b090c0:	sub    rsp,0x8
    72e311b090c4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b090d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b090d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b090dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b090e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b090e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b090ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b090f4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    72e311b090fe:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b09108:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b09112:	push   rdx
    72e311b09113:	push   rsi
    72e311b09114:	push   r10
    72e311b09116:	push   r11
    72e311b09118:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b0911d:	mov    r10d,edx
    72e311b09120:	and    r10d,0xc000
    72e311b09127:	shl    r10d,0x10
    72e311b0912b:	mov    r11d,edx
    72e311b0912e:	and    r11d,0x100
    72e311b09135:	shl    r11d,0x15
    72e311b09139:	or     r10d,r11d
    72e311b0913c:	and    edx,0x1
    72e311b0913f:	shl    edx,0x1c
    72e311b09142:	or     r10d,edx
    72e311b09145:	btc    r10,0x1d
    72e311b0914a:	mov    r11d,0xf0000000
    72e311b09150:	and    r11,r10
    72e311b09153:	movabs rsi,0xffffffff0fffffff
    72e311b0915d:	and    rbx,rsi
    72e311b09160:	or     rbx,r11
    72e311b09163:	pop    r11
    72e311b09165:	pop    r10
    72e311b09167:	pop    rsi
    72e311b09168:	pop    rdx
    72e311b09169:	mov    QWORD PTR [r12+0x108],rbx
    72e311b09171:	stmxcsr DWORD PTR [r12-0x28]
    72e311b09177:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b0917c:	test   r10d,0x3f
    72e311b09183:	je     0x72e311b091a8
    72e311b09189:	mov    r11d,r10d
    72e311b0918c:	shr    r10d,1
    72e311b0918f:	and    r10d,0x1e
    72e311b09193:	and    r11d,0x1
    72e311b09197:	or     r10d,r11d
    72e311b0919a:	or     DWORD PTR [r12+0x314],r10d
    72e311b091a2:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b091a8:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b091ae:	lea    rdi,[rsp+0x110]
    72e311b091b6:	lea    rsi,[rsp+0xf0]
    72e311b091be:	lea    rdx,[rsp+0x100]
    72e311b091c6:	mov    ecx,0x56
    72e311b091cb:	mov    r8d,0x0
    72e311b091d1:	lea    r9,[r12+0x314]
    72e311b091d9:	movabs r11,0x62e30647e650
    72e311b091e3:	call   r11
    72e311b091e6:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b091ec:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b091f2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b091f8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b091fe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b09204:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b0920a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b09210:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    72e311b0921a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b09224:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b0922e:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b09236:	mov    QWORD PTR [r12+0x378],0x2
    72e311b09242:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b0924b:	mov    rdx,rbx
    72e311b0924e:	shr    rdx,0x10
    72e311b09252:	and    edx,0xc000
    72e311b09258:	mov    rax,rbx
    72e311b0925b:	shr    rax,0x15
    72e311b0925f:	and    eax,0x100
    72e311b09264:	xor    eax,0x100
    72e311b09269:	or     edx,eax
    72e311b0926b:	mov    rax,rbx
    72e311b0926e:	shr    rax,0x1c
    72e311b09272:	and    eax,0x1
    72e311b09275:	or     edx,eax
    72e311b09277:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b0927c:	add    rsp,0x8
    72e311b09280:	ret
    72e311b09281:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b09290:	sub    rsp,0x8
    72e311b09294:	mov    QWORD PTR [r12+0x378],0x3
    72e311b092a0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b092a6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b092ac:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    72e311b092b2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    72e311b092b8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b092c2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b092cc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b092d6:	push   rdx
    72e311b092d7:	push   rsi
    72e311b092d8:	push   r10
    72e311b092da:	push   r11
    72e311b092dc:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b092e1:	mov    r10d,edx
    72e311b092e4:	and    r10d,0xc000
    72e311b092eb:	shl    r10d,0x10
    72e311b092ef:	mov    r11d,edx
    72e311b092f2:	and    r11d,0x100
    72e311b092f9:	shl    r11d,0x15
    72e311b092fd:	or     r10d,r11d
    72e311b09300:	and    edx,0x1
    72e311b09303:	shl    edx,0x1c
    72e311b09306:	or     r10d,edx
    72e311b09309:	btc    r10,0x1d
    72e311b0930e:	mov    r11d,0xf0000000
    72e311b09314:	and    r11,r10
    72e311b09317:	movabs rsi,0xffffffff0fffffff
    72e311b09321:	and    rbx,rsi
    72e311b09324:	or     rbx,r11
    72e311b09327:	pop    r11
    72e311b09329:	pop    r10
    72e311b0932b:	pop    rsi
    72e311b0932c:	pop    rdx
    72e311b0932d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b09335:	stmxcsr DWORD PTR [r12-0x28]
    72e311b0933b:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b09340:	test   r10d,0x3f
    72e311b09347:	je     0x72e311b0936c
    72e311b0934d:	mov    r11d,r10d
    72e311b09350:	shr    r10d,1
    72e311b09353:	and    r10d,0x1e
    72e311b09357:	and    r11d,0x1
    72e311b0935b:	or     r10d,r11d
    72e311b0935e:	or     DWORD PTR [r12+0x314],r10d
    72e311b09366:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b0936c:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b09372:	lea    rdi,[rsp+0x110]
    72e311b0937a:	lea    rsi,[rsp+0xf0]
    72e311b09382:	lea    rdx,[rsp+0x100]
    72e311b0938a:	mov    ecx,0x14
    72e311b0938f:	mov    r8d,0x0
    72e311b09395:	lea    r9,[r12+0x314]
    72e311b0939d:	movabs r11,0x62e30647e650
    72e311b093a7:	call   r11
    72e311b093aa:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b093b0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b093b6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b093bc:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    72e311b093c2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    72e311b093c8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b093d2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b093dc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b093e6:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b093ee:	mov    QWORD PTR [r12+0x378],0x2
    72e311b093fa:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b09403:	mov    rdx,rbx
    72e311b09406:	shr    rdx,0x10
    72e311b0940a:	and    edx,0xc000
    72e311b09410:	mov    rax,rbx
    72e311b09413:	shr    rax,0x15
    72e311b09417:	and    eax,0x100
    72e311b0941c:	xor    eax,0x100
    72e311b09421:	or     edx,eax
    72e311b09423:	mov    rax,rbx
    72e311b09426:	shr    rax,0x1c
    72e311b0942a:	and    eax,0x1
    72e311b0942d:	or     edx,eax
    72e311b0942f:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b09434:	add    rsp,0x8
    72e311b09438:	ret
    72e311b09439:	nop    DWORD PTR [rax+0x0]
    72e311b09440:	sub    rsp,0x8
    72e311b09444:	mov    QWORD PTR [r12+0x378],0x3
    72e311b09450:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b09456:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b0945c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b09462:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    72e311b0946c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b09476:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b09480:	push   rdx
    72e311b09481:	push   rsi
    72e311b09482:	push   r10
    72e311b09484:	push   r11
    72e311b09486:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b0948b:	mov    r10d,edx
    72e311b0948e:	and    r10d,0xc000
    72e311b09495:	shl    r10d,0x10
    72e311b09499:	mov    r11d,edx
    72e311b0949c:	and    r11d,0x100
    72e311b094a3:	shl    r11d,0x15
    72e311b094a7:	or     r10d,r11d
    72e311b094aa:	and    edx,0x1
    72e311b094ad:	shl    edx,0x1c
    72e311b094b0:	or     r10d,edx
    72e311b094b3:	btc    r10,0x1d
    72e311b094b8:	mov    r11d,0xf0000000
    72e311b094be:	and    r11,r10
    72e311b094c1:	movabs rsi,0xffffffff0fffffff
    72e311b094cb:	and    rbx,rsi
    72e311b094ce:	or     rbx,r11
    72e311b094d1:	pop    r11
    72e311b094d3:	pop    r10
    72e311b094d5:	pop    rsi
    72e311b094d6:	pop    rdx
    72e311b094d7:	mov    QWORD PTR [r12+0x108],rbx
    72e311b094df:	stmxcsr DWORD PTR [r12-0x28]
    72e311b094e5:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b094ea:	test   r10d,0x3f
    72e311b094f1:	je     0x72e311b09516
    72e311b094f7:	mov    r11d,r10d
    72e311b094fa:	shr    r10d,1
    72e311b094fd:	and    r10d,0x1e
    72e311b09501:	and    r11d,0x1
    72e311b09505:	or     r10d,r11d
    72e311b09508:	or     DWORD PTR [r12+0x314],r10d
    72e311b09510:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b09516:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b0951c:	lea    rdi,[rsp+0x110]
    72e311b09524:	lea    rsi,[rsp+0xf0]
    72e311b0952c:	lea    rdx,[rsp+0x100]
    72e311b09534:	mov    ecx,0x14
    72e311b09539:	mov    r8d,0x0
    72e311b0953f:	lea    r9,[r12+0x314]
    72e311b09547:	movabs r11,0x62e30647e650
    72e311b09551:	call   r11
    72e311b09554:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b0955a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b09560:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b09566:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b0956c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    72e311b09576:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b09580:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b0958a:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b09592:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0959e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b095a7:	mov    rdx,rbx
    72e311b095aa:	shr    rdx,0x10
    72e311b095ae:	and    edx,0xc000
    72e311b095b4:	mov    rax,rbx
    72e311b095b7:	shr    rax,0x15
    72e311b095bb:	and    eax,0x100
    72e311b095c0:	xor    eax,0x100
    72e311b095c5:	or     edx,eax
    72e311b095c7:	mov    rax,rbx
    72e311b095ca:	shr    rax,0x1c
    72e311b095ce:	and    eax,0x1
    72e311b095d1:	or     edx,eax
    72e311b095d3:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b095d8:	add    rsp,0x8
    72e311b095dc:	ret
    72e311b095dd:	nop    DWORD PTR [rax]
    72e311b095e0:	sub    rsp,0x8
    72e311b095e4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b095f0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b095f6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b095fc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    72e311b09602:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    72e311b0960c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    72e311b09616:	push   rdx
    72e311b09617:	push   rsi
    72e311b09618:	push   r10
    72e311b0961a:	push   r11
    72e311b0961c:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b09621:	mov    r10d,edx
    72e311b09624:	and    r10d,0xc000
    72e311b0962b:	shl    r10d,0x10
    72e311b0962f:	mov    r11d,edx
    72e311b09632:	and    r11d,0x100
    72e311b09639:	shl    r11d,0x15
    72e311b0963d:	or     r10d,r11d
    72e311b09640:	and    edx,0x1
    72e311b09643:	shl    edx,0x1c
    72e311b09646:	or     r10d,edx
    72e311b09649:	btc    r10,0x1d
    72e311b0964e:	mov    r11d,0xf0000000
    72e311b09654:	and    r11,r10
    72e311b09657:	movabs rsi,0xffffffff0fffffff
    72e311b09661:	and    rbx,rsi
    72e311b09664:	or     rbx,r11
    72e311b09667:	pop    r11
    72e311b09669:	pop    r10
    72e311b0966b:	pop    rsi
    72e311b0966c:	pop    rdx
    72e311b0966d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b09675:	stmxcsr DWORD PTR [r12-0x28]
    72e311b0967b:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b09680:	test   r10d,0x3f
    72e311b09687:	je     0x72e311b096ac
    72e311b0968d:	mov    r11d,r10d
    72e311b09690:	shr    r10d,1
    72e311b09693:	and    r10d,0x1e
    72e311b09697:	and    r11d,0x1
    72e311b0969b:	or     r10d,r11d
    72e311b0969e:	or     DWORD PTR [r12+0x314],r10d
    72e311b096a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b096ac:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b096b2:	lea    rdi,[rsp+0x110]
    72e311b096ba:	lea    rsi,[rsp+0xf0]
    72e311b096c2:	lea    rdx,[rsp+0x100]
    72e311b096ca:	mov    ecx,0x14
    72e311b096cf:	mov    r8d,0x0
    72e311b096d5:	lea    r9,[r12+0x314]
    72e311b096dd:	movabs r11,0x62e30647e650
    72e311b096e7:	call   r11
    72e311b096ea:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b096f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b096f6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b096fc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    72e311b09702:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    72e311b0970c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    72e311b09716:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0971e:	mov    QWORD PTR [r12+0x378],0x2
    72e311b0972a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b09733:	mov    rdx,rbx
    72e311b09736:	shr    rdx,0x10
    72e311b0973a:	and    edx,0xc000
    72e311b09740:	mov    rax,rbx
    72e311b09743:	shr    rax,0x15
    72e311b09747:	and    eax,0x100
    72e311b0974c:	xor    eax,0x100
    72e311b09751:	or     edx,eax
    72e311b09753:	mov    rax,rbx
    72e311b09756:	shr    rax,0x1c
    72e311b0975a:	and    eax,0x1
    72e311b0975d:	or     edx,eax
    72e311b0975f:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b09764:	add    rsp,0x8
    72e311b09768:	ret
    72e311b09769:	nop    DWORD PTR [rax+0x0]
    72e311b09770:	sub    rsp,0x8
    72e311b09774:	mov    QWORD PTR [r12+0x378],0x3
    72e311b09780:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b09786:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72e311b0978c:	push   rdx
    72e311b0978d:	push   rsi
    72e311b0978e:	push   r10
    72e311b09790:	push   r11
    72e311b09792:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b09797:	mov    r10d,edx
    72e311b0979a:	and    r10d,0xc000
    72e311b097a1:	shl    r10d,0x10
    72e311b097a5:	mov    r11d,edx
    72e311b097a8:	and    r11d,0x100
    72e311b097af:	shl    r11d,0x15
    72e311b097b3:	or     r10d,r11d
    72e311b097b6:	and    edx,0x1
    72e311b097b9:	shl    edx,0x1c
    72e311b097bc:	or     r10d,edx
    72e311b097bf:	btc    r10,0x1d
    72e311b097c4:	mov    r11d,0xf0000000
    72e311b097ca:	and    r11,r10
    72e311b097cd:	movabs rsi,0xffffffff0fffffff
    72e311b097d7:	and    rbx,rsi
    72e311b097da:	or     rbx,r11
    72e311b097dd:	pop    r11
    72e311b097df:	pop    r10
    72e311b097e1:	pop    rsi
    72e311b097e2:	pop    rdx
    72e311b097e3:	mov    QWORD PTR [r12+0x108],rbx
    72e311b097eb:	stmxcsr DWORD PTR [r12-0x28]
    72e311b097f1:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b097f6:	test   r10d,0x3f
    72e311b097fd:	je     0x72e311b09822
    72e311b09803:	mov    r11d,r10d
    72e311b09806:	shr    r10d,1
    72e311b09809:	and    r10d,0x1e
    72e311b0980d:	and    r11d,0x1
    72e311b09811:	or     r10d,r11d
    72e311b09814:	or     DWORD PTR [r12+0x314],r10d
    72e311b0981c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b09822:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b09828:	lea    rdi,[rsp+0x110]
    72e311b09830:	lea    rsi,[rsp+0xf0]
    72e311b09838:	lea    rdx,[rsp+0x100]
    72e311b09840:	mov    ecx,0xc
    72e311b09845:	mov    r8d,0x0
    72e311b0984b:	lea    r9,[r12+0x314]
    72e311b09853:	movabs r11,0x62e30647e650
    72e311b0985d:	call   r11
    72e311b09860:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b09866:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b0986c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72e311b09872:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b0987a:	mov    QWORD PTR [r12+0x378],0x2
    72e311b09886:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b0988f:	mov    rdx,rbx
    72e311b09892:	shr    rdx,0x10
    72e311b09896:	and    edx,0xc000
    72e311b0989c:	mov    rax,rbx
    72e311b0989f:	shr    rax,0x15
    72e311b098a3:	and    eax,0x100
    72e311b098a8:	xor    eax,0x100
    72e311b098ad:	or     edx,eax
    72e311b098af:	mov    rax,rbx
    72e311b098b2:	shr    rax,0x1c
    72e311b098b6:	and    eax,0x1
    72e311b098b9:	or     edx,eax
    72e311b098bb:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b098c0:	add    rsp,0x8
    72e311b098c4:	ret
    72e311b098c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72e311b098d0:	sub    rsp,0x8
    72e311b098d4:	mov    QWORD PTR [r12+0x378],0x3
    72e311b098e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72e311b098e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72e311b098ec:	push   rdx
    72e311b098ed:	push   rsi
    72e311b098ee:	push   r10
    72e311b098f0:	push   r11
    72e311b098f2:	mov    rdx,QWORD PTR [rsp+0x30]
    72e311b098f7:	mov    r10d,edx
    72e311b098fa:	and    r10d,0xc000
    72e311b09901:	shl    r10d,0x10
    72e311b09905:	mov    r11d,edx
    72e311b09908:	and    r11d,0x100
    72e311b0990f:	shl    r11d,0x15
    72e311b09913:	or     r10d,r11d
    72e311b09916:	and    edx,0x1
    72e311b09919:	shl    edx,0x1c
    72e311b0991c:	or     r10d,edx
    72e311b0991f:	btc    r10,0x1d
    72e311b09924:	mov    r11d,0xf0000000
    72e311b0992a:	and    r11,r10
    72e311b0992d:	movabs rsi,0xffffffff0fffffff
    72e311b09937:	and    rbx,rsi
    72e311b0993a:	or     rbx,r11
    72e311b0993d:	pop    r11
    72e311b0993f:	pop    r10
    72e311b09941:	pop    rsi
    72e311b09942:	pop    rdx
    72e311b09943:	mov    QWORD PTR [r12+0x108],rbx
    72e311b0994b:	stmxcsr DWORD PTR [r12-0x28]
    72e311b09951:	mov    r10d,DWORD PTR [r12-0x28]
    72e311b09956:	test   r10d,0x3f
    72e311b0995d:	je     0x72e311b09982
    72e311b09963:	mov    r11d,r10d
    72e311b09966:	shr    r10d,1
    72e311b09969:	and    r10d,0x1e
    72e311b0996d:	and    r11d,0x1
    72e311b09971:	or     r10d,r11d
    72e311b09974:	or     DWORD PTR [r12+0x314],r10d
    72e311b0997c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72e311b09982:	ldmxcsr DWORD PTR [r12-0x38]
    72e311b09988:	lea    rdi,[rsp+0x110]
    72e311b09990:	lea    rsi,[rsp+0xf0]
    72e311b09998:	lea    rdx,[rsp+0x100]
    72e311b099a0:	mov    ecx,0xc
    72e311b099a5:	mov    r8d,0x0
    72e311b099ab:	lea    r9,[r12+0x314]
    72e311b099b3:	movabs r11,0x62e30647e650
    72e311b099bd:	call   r11
    72e311b099c0:	ldmxcsr DWORD PTR [r12-0x28]
    72e311b099c6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72e311b099cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72e311b099d2:	mov    rbx,QWORD PTR [r12+0x108]
    72e311b099da:	mov    QWORD PTR [r12+0x378],0x2
    72e311b099e6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72e311b099ef:	mov    rdx,rbx
    72e311b099f2:	shr    rdx,0x10
    72e311b099f6:	and    edx,0xc000
    72e311b099fc:	mov    rax,rbx
    72e311b099ff:	shr    rax,0x15
    72e311b09a03:	and    eax,0x100
    72e311b09a08:	xor    eax,0x100
    72e311b09a0d:	or     edx,eax
    72e311b09a0f:	mov    rax,rbx
    72e311b09a12:	shr    rax,0x1c
    72e311b09a16:	and    eax,0x1
    72e311b09a19:	or     edx,eax
    72e311b09a1b:	mov    QWORD PTR [rsp+0x10],rdx
    72e311b09a20:	add    rsp,0x8
    72e311b09a24:	ret
    72e311b09a25:	mov    eax,0x4101e8
    72e311b09a2a:	mov    QWORD PTR [r12+0x100],rax
    72e311b09a32:	push   rdx
    72e311b09a33:	push   rsi
    72e311b09a34:	push   r10
    72e311b09a36:	push   r11
    72e311b09a38:	mov    r11,rax
    72e311b09a3b:	lahf
    72e311b09a3c:	seto   al
    72e311b09a3f:	mov    WORD PTR [rsp+0x20],ax
    72e311b09a44:	mov    rax,r11
    72e311b09a47:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b09a4c:	mov    r10d,edx
    72e311b09a4f:	and    r10d,0xc000
    72e311b09a56:	shl    r10d,0x10
    72e311b09a5a:	mov    r11d,edx
    72e311b09a5d:	and    r11d,0x100
    72e311b09a64:	shl    r11d,0x15
    72e311b09a68:	or     r10d,r11d
    72e311b09a6b:	and    edx,0x1
    72e311b09a6e:	shl    edx,0x1c
    72e311b09a71:	or     r10d,edx
    72e311b09a74:	btc    r10,0x1d
    72e311b09a79:	mov    r11d,0xf0000000
    72e311b09a7f:	and    r11,r10
    72e311b09a82:	movabs rsi,0xffffffff0fffffff
    72e311b09a8c:	and    rbx,rsi
    72e311b09a8f:	or     rbx,r11
    72e311b09a92:	pop    r11
    72e311b09a94:	pop    r10
    72e311b09a96:	pop    rsi
    72e311b09a97:	pop    rdx
    72e311b09a98:	mov    QWORD PTR [r12+0x108],rbx
    72e311b09aa0:	add    rsp,0x150
    72e311b09aa7:	mov    eax,0xc
    72e311b09aac:	movabs r11,0x62e306617ca0
    72e311b09ab6:	jmp    r11
    72e311b09ab9:	mov    eax,0x410440
    72e311b09abe:	mov    QWORD PTR [r12+0x100],rax
    72e311b09ac6:	push   rdx
    72e311b09ac7:	push   rsi
    72e311b09ac8:	push   r10
    72e311b09aca:	push   r11
    72e311b09acc:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b09ad1:	mov    r10d,edx
    72e311b09ad4:	and    r10d,0xc000
    72e311b09adb:	shl    r10d,0x10
    72e311b09adf:	mov    r11d,edx
    72e311b09ae2:	and    r11d,0x100
    72e311b09ae9:	shl    r11d,0x15
    72e311b09aed:	or     r10d,r11d
    72e311b09af0:	and    edx,0x1
    72e311b09af3:	shl    edx,0x1c
    72e311b09af6:	or     r10d,edx
    72e311b09af9:	btc    r10,0x1d
    72e311b09afe:	mov    r11d,0xf0000000
    72e311b09b04:	and    r11,r10
    72e311b09b07:	movabs rsi,0xffffffff0fffffff
    72e311b09b11:	and    rbx,rsi
    72e311b09b14:	or     rbx,r11
    72e311b09b17:	pop    r11
    72e311b09b19:	pop    r10
    72e311b09b1b:	pop    rsi
    72e311b09b1c:	pop    rdx
    72e311b09b1d:	mov    QWORD PTR [r12+0x108],rbx
    72e311b09b25:	add    rsp,0x150
    72e311b09b2c:	mov    eax,0xc
    72e311b09b31:	movabs r11,0x62e306617ca0
    72e311b09b3b:	jmp    r11
    72e311b09b3e:	mov    eax,0x41044c
    72e311b09b43:	mov    QWORD PTR [r12+0x100],rax
    72e311b09b4b:	push   rdx
    72e311b09b4c:	push   rsi
    72e311b09b4d:	push   r10
    72e311b09b4f:	push   r11
    72e311b09b51:	mov    r11,rax
    72e311b09b54:	lahf
    72e311b09b55:	seto   al
    72e311b09b58:	mov    WORD PTR [rsp+0x20],ax
    72e311b09b5d:	mov    rax,r11
    72e311b09b60:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b09b65:	mov    r10d,edx
    72e311b09b68:	and    r10d,0xc000
    72e311b09b6f:	shl    r10d,0x10
    72e311b09b73:	mov    r11d,edx
    72e311b09b76:	and    r11d,0x100
    72e311b09b7d:	shl    r11d,0x15
    72e311b09b81:	or     r10d,r11d
    72e311b09b84:	and    edx,0x1
    72e311b09b87:	shl    edx,0x1c
    72e311b09b8a:	or     r10d,edx
    72e311b09b8d:	btc    r10,0x1d
    72e311b09b92:	mov    r11d,0xf0000000
    72e311b09b98:	and    r11,r10
    72e311b09b9b:	movabs rsi,0xffffffff0fffffff
    72e311b09ba5:	and    rbx,rsi
    72e311b09ba8:	or     rbx,r11
    72e311b09bab:	pop    r11
    72e311b09bad:	pop    r10
    72e311b09baf:	pop    rsi
    72e311b09bb0:	pop    rdx
    72e311b09bb1:	mov    QWORD PTR [r12+0x108],rbx
    72e311b09bb9:	add    rsp,0x150
    72e311b09bc0:	mov    eax,0xc
    72e311b09bc5:	movabs r11,0x62e306617ca0
    72e311b09bcf:	jmp    r11
    72e311b09bd2:	mov    eax,0x41048c
    72e311b09bd7:	mov    QWORD PTR [r12+0x100],rax
    72e311b09bdf:	push   rdx
    72e311b09be0:	push   rsi
    72e311b09be1:	push   r10
    72e311b09be3:	push   r11
    72e311b09be5:	mov    r11,rax
    72e311b09be8:	lahf
    72e311b09be9:	seto   al
    72e311b09bec:	mov    WORD PTR [rsp+0x20],ax
    72e311b09bf1:	mov    rax,r11
    72e311b09bf4:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b09bf9:	mov    r10d,edx
    72e311b09bfc:	and    r10d,0xc000
    72e311b09c03:	shl    r10d,0x10
    72e311b09c07:	mov    r11d,edx
    72e311b09c0a:	and    r11d,0x100
    72e311b09c11:	shl    r11d,0x15
    72e311b09c15:	or     r10d,r11d
    72e311b09c18:	and    edx,0x1
    72e311b09c1b:	shl    edx,0x1c
    72e311b09c1e:	or     r10d,edx
    72e311b09c21:	btc    r10,0x1d
    72e311b09c26:	mov    r11d,0xf0000000
    72e311b09c2c:	and    r11,r10
    72e311b09c2f:	movabs rsi,0xffffffff0fffffff
    72e311b09c39:	and    rbx,rsi
    72e311b09c3c:	or     rbx,r11
    72e311b09c3f:	pop    r11
    72e311b09c41:	pop    r10
    72e311b09c43:	pop    rsi
    72e311b09c44:	pop    rdx
    72e311b09c45:	mov    QWORD PTR [r12+0x108],rbx
    72e311b09c4d:	add    rsp,0x150
    72e311b09c54:	mov    eax,0xc
    72e311b09c59:	movabs r11,0x62e306617ca0
    72e311b09c63:	jmp    r11
    72e311b09c66:	mov    eax,0x410494
    72e311b09c6b:	mov    QWORD PTR [r12+0x100],rax
    72e311b09c73:	push   rdx
    72e311b09c74:	push   rsi
    72e311b09c75:	push   r10
    72e311b09c77:	push   r11
    72e311b09c79:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b09c7e:	mov    r10d,edx
    72e311b09c81:	and    r10d,0xc000
    72e311b09c88:	shl    r10d,0x10
    72e311b09c8c:	mov    r11d,edx
    72e311b09c8f:	and    r11d,0x100
    72e311b09c96:	shl    r11d,0x15
    72e311b09c9a:	or     r10d,r11d
    72e311b09c9d:	and    edx,0x1
    72e311b09ca0:	shl    edx,0x1c
    72e311b09ca3:	or     r10d,edx
    72e311b09ca6:	btc    r10,0x1d
    72e311b09cab:	mov    r11d,0xf0000000
    72e311b09cb1:	and    r11,r10
    72e311b09cb4:	movabs rsi,0xffffffff0fffffff
    72e311b09cbe:	and    rbx,rsi
    72e311b09cc1:	or     rbx,r11
    72e311b09cc4:	pop    r11
    72e311b09cc6:	pop    r10
    72e311b09cc8:	pop    rsi
    72e311b09cc9:	pop    rdx
    72e311b09cca:	mov    QWORD PTR [r12+0x108],rbx
    72e311b09cd2:	add    rsp,0x150
    72e311b09cd9:	mov    eax,0xc
    72e311b09cde:	movabs r11,0x62e306617ca0
    72e311b09ce8:	jmp    r11
    72e311b09ceb:	nop    DWORD PTR [rax+rax*1+0x0]
    72e311b09cf0:	sub    rsp,0x150
    72e311b09cf7:	mov    r11,QWORD PTR [r12+0x398]
    72e311b09cff:	mov    QWORD PTR [rsp],r11
    72e311b09d03:	cmp    DWORD PTR [r12+0x310],0x0
    72e311b09d0c:	je     0x72e311b09d97
    72e311b09d12:	push   rdx
    72e311b09d13:	push   rsi
    72e311b09d14:	push   r10
    72e311b09d16:	push   r11
    72e311b09d18:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b09d1d:	mov    r10d,edx
    72e311b09d20:	and    r10d,0xc000
    72e311b09d27:	shl    r10d,0x10
    72e311b09d2b:	mov    r11d,edx
    72e311b09d2e:	and    r11d,0x100
    72e311b09d35:	shl    r11d,0x15
    72e311b09d39:	or     r10d,r11d
    72e311b09d3c:	and    edx,0x1
    72e311b09d3f:	shl    edx,0x1c
    72e311b09d42:	or     r10d,edx
    72e311b09d45:	btc    r10,0x1d
    72e311b09d4a:	mov    r11d,0xf0000000
    72e311b09d50:	and    r11,r10
    72e311b09d53:	movabs rsi,0xffffffff0fffffff
    72e311b09d5d:	and    rbx,rsi
    72e311b09d60:	or     rbx,r11
    72e311b09d63:	pop    r11
    72e311b09d65:	pop    r10
    72e311b09d67:	pop    rsi
    72e311b09d68:	pop    rdx
    72e311b09d69:	mov    QWORD PTR [r12+0x108],rbx
    72e311b09d71:	mov    eax,0x4101ac
    72e311b09d76:	mov    QWORD PTR [r12+0x100],rax
    72e311b09d7e:	add    rsp,0x150
    72e311b09d85:	mov    eax,0x3
    72e311b09d8a:	movabs r11,0x62e306617ca0
    72e311b09d94:	jmp    r11
    72e311b09d97:	mov    r11,rax
    72e311b09d9a:	movzx  eax,WORD PTR [rsp]
    72e311b09d9e:	add    al,0x7f
    72e311b09da0:	sahf
    72e311b09da1:	mov    rax,r11
    72e311b09da4:	jmp    0x72e311b00202
    72e311b09da9:	nop    DWORD PTR [rax+0x0]
    72e311b09db0:	sub    rsp,0x150
    72e311b09db7:	mov    r11,QWORD PTR [r12+0x398]
    72e311b09dbf:	mov    QWORD PTR [rsp],r11
    72e311b09dc3:	cmp    DWORD PTR [r12+0x310],0x0
    72e311b09dcc:	je     0x72e311b09e57
    72e311b09dd2:	push   rdx
    72e311b09dd3:	push   rsi
    72e311b09dd4:	push   r10
    72e311b09dd6:	push   r11
    72e311b09dd8:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b09ddd:	mov    r10d,edx
    72e311b09de0:	and    r10d,0xc000
    72e311b09de7:	shl    r10d,0x10
    72e311b09deb:	mov    r11d,edx
    72e311b09dee:	and    r11d,0x100
    72e311b09df5:	shl    r11d,0x15
    72e311b09df9:	or     r10d,r11d
    72e311b09dfc:	and    edx,0x1
    72e311b09dff:	shl    edx,0x1c
    72e311b09e02:	or     r10d,edx
    72e311b09e05:	btc    r10,0x1d
    72e311b09e0a:	mov    r11d,0xf0000000
    72e311b09e10:	and    r11,r10
    72e311b09e13:	movabs rsi,0xffffffff0fffffff
    72e311b09e1d:	and    rbx,rsi
    72e311b09e20:	or     rbx,r11
    72e311b09e23:	pop    r11
    72e311b09e25:	pop    r10
    72e311b09e27:	pop    rsi
    72e311b09e28:	pop    rdx
    72e311b09e29:	mov    QWORD PTR [r12+0x108],rbx
    72e311b09e31:	mov    eax,0x4101ec
    72e311b09e36:	mov    QWORD PTR [r12+0x100],rax
    72e311b09e3e:	add    rsp,0x150
    72e311b09e45:	mov    eax,0x3
    72e311b09e4a:	movabs r11,0x62e306617ca0
    72e311b09e54:	jmp    r11
    72e311b09e57:	jmp    0x72e311b00650
    72e311b09e5c:	nop    DWORD PTR [rax+0x0]
    72e311b09e60:	sub    rsp,0x150
    72e311b09e67:	mov    r11,QWORD PTR [r12+0x398]
    72e311b09e6f:	mov    QWORD PTR [rsp],r11
    72e311b09e73:	cmp    DWORD PTR [r12+0x310],0x0
    72e311b09e7c:	je     0x72e311b09f07
    72e311b09e82:	push   rdx
    72e311b09e83:	push   rsi
    72e311b09e84:	push   r10
    72e311b09e86:	push   r11
    72e311b09e88:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b09e8d:	mov    r10d,edx
    72e311b09e90:	and    r10d,0xc000
    72e311b09e97:	shl    r10d,0x10
    72e311b09e9b:	mov    r11d,edx
    72e311b09e9e:	and    r11d,0x100
    72e311b09ea5:	shl    r11d,0x15
    72e311b09ea9:	or     r10d,r11d
    72e311b09eac:	and    edx,0x1
    72e311b09eaf:	shl    edx,0x1c
    72e311b09eb2:	or     r10d,edx
    72e311b09eb5:	btc    r10,0x1d
    72e311b09eba:	mov    r11d,0xf0000000
    72e311b09ec0:	and    r11,r10
    72e311b09ec3:	movabs rsi,0xffffffff0fffffff
    72e311b09ecd:	and    rbx,rsi
    72e311b09ed0:	or     rbx,r11
    72e311b09ed3:	pop    r11
    72e311b09ed5:	pop    r10
    72e311b09ed7:	pop    rsi
    72e311b09ed8:	pop    rdx
    72e311b09ed9:	mov    QWORD PTR [r12+0x108],rbx
    72e311b09ee1:	mov    eax,0x410274
    72e311b09ee6:	mov    QWORD PTR [r12+0x100],rax
    72e311b09eee:	add    rsp,0x150
    72e311b09ef5:	mov    eax,0x3
    72e311b09efa:	movabs r11,0x62e306617ca0
    72e311b09f04:	jmp    r11
    72e311b09f07:	mov    r11,rax
    72e311b09f0a:	movzx  eax,WORD PTR [rsp]
    72e311b09f0e:	add    al,0x7f
    72e311b09f10:	sahf
    72e311b09f11:	mov    rax,r11
    72e311b09f14:	jmp    0x72e311b00b1b
    72e311b09f19:	nop    DWORD PTR [rax+0x0]
    72e311b09f20:	sub    rsp,0x150
    72e311b09f27:	mov    r11,QWORD PTR [r12+0x398]
    72e311b09f2f:	mov    QWORD PTR [rsp],r11
    72e311b09f33:	cmp    DWORD PTR [r12+0x310],0x0
    72e311b09f3c:	je     0x72e311b09fc7
    72e311b09f42:	push   rdx
    72e311b09f43:	push   rsi
    72e311b09f44:	push   r10
    72e311b09f46:	push   r11
    72e311b09f48:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b09f4d:	mov    r10d,edx
    72e311b09f50:	and    r10d,0xc000
    72e311b09f57:	shl    r10d,0x10
    72e311b09f5b:	mov    r11d,edx
    72e311b09f5e:	and    r11d,0x100
    72e311b09f65:	shl    r11d,0x15
    72e311b09f69:	or     r10d,r11d
    72e311b09f6c:	and    edx,0x1
    72e311b09f6f:	shl    edx,0x1c
    72e311b09f72:	or     r10d,edx
    72e311b09f75:	btc    r10,0x1d
    72e311b09f7a:	mov    r11d,0xf0000000
    72e311b09f80:	and    r11,r10
    72e311b09f83:	movabs rsi,0xffffffff0fffffff
    72e311b09f8d:	and    rbx,rsi
    72e311b09f90:	or     rbx,r11
    72e311b09f93:	pop    r11
    72e311b09f95:	pop    r10
    72e311b09f97:	pop    rsi
    72e311b09f98:	pop    rdx
    72e311b09f99:	mov    QWORD PTR [r12+0x108],rbx
    72e311b09fa1:	mov    eax,0x410278
    72e311b09fa6:	mov    QWORD PTR [r12+0x100],rax
    72e311b09fae:	add    rsp,0x150
    72e311b09fb5:	mov    eax,0x3
    72e311b09fba:	movabs r11,0x62e306617ca0
    72e311b09fc4:	jmp    r11
    72e311b09fc7:	jmp    0x72e311b00b39
    72e311b09fcc:	nop    DWORD PTR [rax+0x0]
    72e311b09fd0:	sub    rsp,0x150
    72e311b09fd7:	mov    r11,QWORD PTR [r12+0x398]
    72e311b09fdf:	mov    QWORD PTR [rsp],r11
    72e311b09fe3:	cmp    DWORD PTR [r12+0x310],0x0
    72e311b09fec:	je     0x72e311b0a077
    72e311b09ff2:	push   rdx
    72e311b09ff3:	push   rsi
    72e311b09ff4:	push   r10
    72e311b09ff6:	push   r11
    72e311b09ff8:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b09ffd:	mov    r10d,edx
    72e311b0a000:	and    r10d,0xc000
    72e311b0a007:	shl    r10d,0x10
    72e311b0a00b:	mov    r11d,edx
    72e311b0a00e:	and    r11d,0x100
    72e311b0a015:	shl    r11d,0x15
    72e311b0a019:	or     r10d,r11d
    72e311b0a01c:	and    edx,0x1
    72e311b0a01f:	shl    edx,0x1c
    72e311b0a022:	or     r10d,edx
    72e311b0a025:	btc    r10,0x1d
    72e311b0a02a:	mov    r11d,0xf0000000
    72e311b0a030:	and    r11,r10
    72e311b0a033:	movabs rsi,0xffffffff0fffffff
    72e311b0a03d:	and    rbx,rsi
    72e311b0a040:	or     rbx,r11
    72e311b0a043:	pop    r11
    72e311b0a045:	pop    r10
    72e311b0a047:	pop    rsi
    72e311b0a048:	pop    rdx
    72e311b0a049:	mov    QWORD PTR [r12+0x108],rbx
    72e311b0a051:	mov    eax,0x410444
    72e311b0a056:	mov    QWORD PTR [r12+0x100],rax
    72e311b0a05e:	add    rsp,0x150
    72e311b0a065:	mov    eax,0x3
    72e311b0a06a:	movabs r11,0x62e306617ca0
    72e311b0a074:	jmp    r11
    72e311b0a077:	jmp    0x72e311b02879
    72e311b0a07c:	nop    DWORD PTR [rax+0x0]
    72e311b0a080:	sub    rsp,0x150
    72e311b0a087:	mov    r11,QWORD PTR [r12+0x398]
    72e311b0a08f:	mov    QWORD PTR [rsp],r11
    72e311b0a093:	cmp    DWORD PTR [r12+0x310],0x0
    72e311b0a09c:	je     0x72e311b0a127
    72e311b0a0a2:	push   rdx
    72e311b0a0a3:	push   rsi
    72e311b0a0a4:	push   r10
    72e311b0a0a6:	push   r11
    72e311b0a0a8:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b0a0ad:	mov    r10d,edx
    72e311b0a0b0:	and    r10d,0xc000
    72e311b0a0b7:	shl    r10d,0x10
    72e311b0a0bb:	mov    r11d,edx
    72e311b0a0be:	and    r11d,0x100
    72e311b0a0c5:	shl    r11d,0x15
    72e311b0a0c9:	or     r10d,r11d
    72e311b0a0cc:	and    edx,0x1
    72e311b0a0cf:	shl    edx,0x1c
    72e311b0a0d2:	or     r10d,edx
    72e311b0a0d5:	btc    r10,0x1d
    72e311b0a0da:	mov    r11d,0xf0000000
    72e311b0a0e0:	and    r11,r10
    72e311b0a0e3:	movabs rsi,0xffffffff0fffffff
    72e311b0a0ed:	and    rbx,rsi
    72e311b0a0f0:	or     rbx,r11
    72e311b0a0f3:	pop    r11
    72e311b0a0f5:	pop    r10
    72e311b0a0f7:	pop    rsi
    72e311b0a0f8:	pop    rdx
    72e311b0a0f9:	mov    QWORD PTR [r12+0x108],rbx
    72e311b0a101:	mov    eax,0x410450
    72e311b0a106:	mov    QWORD PTR [r12+0x100],rax
    72e311b0a10e:	add    rsp,0x150
    72e311b0a115:	mov    eax,0x3
    72e311b0a11a:	movabs r11,0x62e306617ca0
    72e311b0a124:	jmp    r11
    72e311b0a127:	jmp    0x72e311b028b6
    72e311b0a12c:	nop    DWORD PTR [rax+0x0]
    72e311b0a130:	sub    rsp,0x150
    72e311b0a137:	mov    r11,QWORD PTR [r12+0x398]
    72e311b0a13f:	mov    QWORD PTR [rsp],r11
    72e311b0a143:	cmp    DWORD PTR [r12+0x310],0x0
    72e311b0a14c:	je     0x72e311b0a1d7
    72e311b0a152:	push   rdx
    72e311b0a153:	push   rsi
    72e311b0a154:	push   r10
    72e311b0a156:	push   r11
    72e311b0a158:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b0a15d:	mov    r10d,edx
    72e311b0a160:	and    r10d,0xc000
    72e311b0a167:	shl    r10d,0x10
    72e311b0a16b:	mov    r11d,edx
    72e311b0a16e:	and    r11d,0x100
    72e311b0a175:	shl    r11d,0x15
    72e311b0a179:	or     r10d,r11d
    72e311b0a17c:	and    edx,0x1
    72e311b0a17f:	shl    edx,0x1c
    72e311b0a182:	or     r10d,edx
    72e311b0a185:	btc    r10,0x1d
    72e311b0a18a:	mov    r11d,0xf0000000
    72e311b0a190:	and    r11,r10
    72e311b0a193:	movabs rsi,0xffffffff0fffffff
    72e311b0a19d:	and    rbx,rsi
    72e311b0a1a0:	or     rbx,r11
    72e311b0a1a3:	pop    r11
    72e311b0a1a5:	pop    r10
    72e311b0a1a7:	pop    rsi
    72e311b0a1a8:	pop    rdx
    72e311b0a1a9:	mov    QWORD PTR [r12+0x108],rbx
    72e311b0a1b1:	mov    eax,0x410474
    72e311b0a1b6:	mov    QWORD PTR [r12+0x100],rax
    72e311b0a1be:	add    rsp,0x150
    72e311b0a1c5:	mov    eax,0x3
    72e311b0a1ca:	movabs r11,0x62e306617ca0
    72e311b0a1d4:	jmp    r11
    72e311b0a1d7:	jmp    0x72e311b02a28
    72e311b0a1dc:	nop    DWORD PTR [rax+0x0]
    72e311b0a1e0:	sub    rsp,0x150
    72e311b0a1e7:	mov    r11,QWORD PTR [r12+0x398]
    72e311b0a1ef:	mov    QWORD PTR [rsp],r11
    72e311b0a1f3:	cmp    DWORD PTR [r12+0x310],0x0
    72e311b0a1fc:	je     0x72e311b0a287
    72e311b0a202:	push   rdx
    72e311b0a203:	push   rsi
    72e311b0a204:	push   r10
    72e311b0a206:	push   r11
    72e311b0a208:	mov    rdx,QWORD PTR [rsp+0x20]
    72e311b0a20d:	mov    r10d,edx
    72e311b0a210:	and    r10d,0xc000
    72e311b0a217:	shl    r10d,0x10
    72e311b0a21b:	mov    r11d,edx
    72e311b0a21e:	and    r11d,0x100
    72e311b0a225:	shl    r11d,0x15
    72e311b0a229:	or     r10d,r11d
    72e311b0a22c:	and    edx,0x1
    72e311b0a22f:	shl    edx,0x1c
    72e311b0a232:	or     r10d,edx
    72e311b0a235:	btc    r10,0x1d
    72e311b0a23a:	mov    r11d,0xf0000000
    72e311b0a240:	and    r11,r10
    72e311b0a243:	movabs rsi,0xffffffff0fffffff
    72e311b0a24d:	and    rbx,rsi
    72e311b0a250:	or     rbx,r11
    72e311b0a253:	pop    r11
    72e311b0a255:	pop    r10
    72e311b0a257:	pop    rsi
    72e311b0a258:	pop    rdx
    72e311b0a259:	mov    QWORD PTR [r12+0x108],rbx
    72e311b0a261:	mov    eax,0x410490
    72e311b0a266:	mov    QWORD PTR [r12+0x100],rax
    72e311b0a26e:	add    rsp,0x150
    72e311b0a275:	mov    eax,0x3
    72e311b0a27a:	movabs r11,0x62e306617ca0
    72e311b0a284:	jmp    r11
    72e311b0a287:	jmp    0x72e311b02b81
    72e311b0a28c:	nop    DWORD PTR [rax+0x0]
    72e311b0a290:	(bad)
    72e311b0a291:	(bad)
    72e311b0a292:	(bad)
    72e311b0a293:	(bad)
    72e311b0a294:	(bad)
    72e311b0a295:	(bad)
    72e311b0a296:	(bad)
    72e311b0a297:	jg     0x72e311b0a298
    72e311b0a299:	(bad)
    72e311b0a29a:	(bad)
    72e311b0a29b:	(bad)
    72e311b0a29c:	(bad)
    72e311b0a29d:	(bad)
    72e311b0a29e:	(bad)
    72e311b0a29f:	jg     0x72e311b0a2a1
    72e311b0a2a1:	add    BYTE PTR [rax],al
    72e311b0a2a3:	add    BYTE PTR [rax],al
    72e311b0a2a5:	add    BYTE PTR [rax],dl
    72e311b0a2a7:	add    BYTE PTR [rax],al
    72e311b0a2a9:	add    BYTE PTR [rax],al
    72e311b0a2ab:	add    BYTE PTR [rax],al
    72e311b0a2ad:	add    BYTE PTR [rax],dl
	...
