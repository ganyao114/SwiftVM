0000785dab1ce69b  nop [rax+rax*1], eax
0000785dab1ce6a0  vmovaps xmm1, [0x0000785DAADFE010]
0000785dab1ce6a8  movq xmm1, xmm1
0000785dab1ce6ac  movaps [r15+0x110], xmm1
0000785dab1ce6b4  vmovaps xmm1, [0x0000785DAADFE020]
0000785dab1ce6bc  movq xmm1, xmm1
0000785dab1ce6c0  movaps [r15+0x120], xmm1
0000785dab1ce6c8  mov eax, 0x4204C0
0000785dab1ce6cd  mov r14, [r13+rax*1]
0000785dab1ce6d2  movq xmm1, r14
0000785dab1ce6d7  movaps [r15+0x130], xmm1
0000785dab1ce6df  vmovaps xmm1, [0x0000785DAADFE030]
0000785dab1ce6e7  vpbroadcastq xmm1, xmm1
0000785dab1ce6ec  movaps [r15+0x140], xmm1
0000785dab1ce6f4  mov qword ptr [r15+0x40], 0x02
0000785dab1ce6fc  vmovaps xmm15, [0x0000785DAADFE040]
0000785dab1ce704  movq xmm15, xmm15
0000785dab1ce709  movaps [r15+0x150], xmm15
0000785dab1ce711  mov qword ptr [r15+0x58], 0x420000
0000785dab1ce719  vmovaps xmm15, [0x0000785DAADFE050]
0000785dab1ce721  vpbroadcastq xmm15, xmm15
0000785dab1ce726  movaps [r15+0x160], xmm15
0000785dab1ce72e  mov rax, [r15+0x40]
0000785dab1ce732  vmovq xmm14, rax
0000785dab1ce737  vpbroadcastq xmm14, xmm14
0000785dab1ce73c  movaps [r15+0x170], xmm14
0000785dab1ce744  mov eax, 0x4204D0
0000785dab1ce749  movups xmm13, [r13+rax*1]
0000785dab1ce74f  mov qword ptr [r15+0x40], 0x430518
0000785dab1ce757  mov qword ptr [r15+0x50], 0x430720
0000785dab1ce75f  vpmovqd xmm12, xmm13
0000785dab1ce765  pxor xmm11, xmm11
0000785dab1ce76a  punpcklqdq xmm12, xmm11
0000785dab1ce76f  movaps [r15+0x210], xmm12
0000785dab1ce777  movq xmm12, qword ptr [r15+0x120]
0000785dab1ce780  movq xmm11, qword ptr [r15+0x130]
0000785dab1ce789  psubd xmm12, xmm11
0000785dab1ce78e  movq xmm12, xmm12
0000785dab1ce793  paddq xmm13, xmm14
0000785dab1ce798  movaps [r15+0x180], xmm13
0000785dab1ce7a0  movq xmm14, qword ptr [r15+0x150]
0000785dab1ce7a9  paddd xmm11, xmm14
0000785dab1ce7ae  movq xmm11, xmm11
0000785dab1ce7b3  movq xmm11, xmm11
0000785dab1ce7b8  movaps [r15+0x130], xmm11
0000785dab1ce7c0  pmovzxdq xmm12, xmm12
0000785dab1ce7c6  psllq xmm12, 0x00
0000785dab1ce7cc  movq xmm14, qword ptr [r15+0x210]
0000785dab1ce7d5  movq xmm13, qword ptr [r15+0x110]
0000785dab1ce7de  paddd xmm14, xmm13
0000785dab1ce7e3  movq xmm14, xmm14
0000785dab1ce7e8  vcvtuqq2pd xmm12, xmm12
0000785dab1ce7ee  pmovzxdq xmm14, xmm14
0000785dab1ce7f4  psllq xmm14, 0x00
0000785dab1ce7fa  vcvtuqq2pd xmm14, xmm14
0000785dab1ce800  movaps xmm13, xmm12
0000785dab1ce804  mulpd xmm13, xmm1
0000785dab1ce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000785dab1ce80f  ptest xmm11, xmm11
0000785dab1ce815  jnz 0x0000785DAB1CE8FF
0000785dab1ce81b  movaps [r15+0x220], xmm13
0000785dab1ce823  mov eax, 0x430720
0000785dab1ce828  movups [r13+rax*1], xmm13
0000785dab1ce82e  movaps xmm1, xmm14
0000785dab1ce832  mulpd xmm1, xmm15
0000785dab1ce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000785dab1ce83c  ptest xmm13, xmm13
0000785dab1ce842  jnz 0x0000785DAB1CEA4C
0000785dab1ce848  movaps [r15+0x210], xmm1
0000785dab1ce850  mov eax, 0x430518
0000785dab1ce855  movups [r13+rax*1], xmm1
0000785dab1ce85b  mov qword ptr [r15+0x48], 0x10
0000785dab1ce863  xor eax, eax
0000785dab1ce865  mov r14d, 0x10
0000785dab1ce86b  mov r12d, 0x200
0000785dab1ce871  cmp r14, r12
0000785dab1ce874  cmc
0000785dab1ce875  lahf
0000785dab1ce876  seto al
0000785dab1ce879  mov [r15+0x108], eax
0000785dab1ce880  mov eax, [r15+0x108]
0000785dab1ce887  sahf
0000785dab1ce888  jnz 0x0000785DAB1CE8BA
0000785dab1ce88a  cmp dword ptr [r15+0x318], 0x00
0000785dab1ce892  jz 0x0000785DAB1CEFF0
0000785dab1ce898  nop [rax+rax*1], ax
0000785dab1ce8a1  nop [rax+rax*1], eax
0000785dab1ce8a9  mov eax, 0x4101EC
0000785dab1ce8ae  mov [r15+0x100], rax
0000785dab1ce8b5  jmp 0x0000785DAAFFE110
0000785dab1ce8ba  cmp dword ptr [r15+0x318], 0x00
0000785dab1ce8c2  jz 0x0000785DAB1CEBA0
0000785dab1ce8c8  nop [rax+rax*1], ax
0000785dab1ce8d1  nop [rax+rax*1], eax
0000785dab1ce8d9  mov eax, 0x4101AC
0000785dab1ce8de  mov [r15+0x100], rax
0000785dab1ce8e5  jmp 0x0000785DAAFFE110
0000785dab1ce8ea  int3
0000785dab1ce8eb  call 0x0000785DAB00DC20
0000785dab1ce8f0  jmp 0x0000785DAB1CE6D2
0000785dab1ce8f5  call 0x0000785DAB00C260
0000785dab1ce8fa  jmp 0x0000785DAB1CE74F
0000785dab1ce8ff  sub rsp, 0x08
0000785dab1ce903  push rax
0000785dab1ce904  push rcx
0000785dab1ce905  push rdx
0000785dab1ce906  push rdi
0000785dab1ce907  push rsi
0000785dab1ce908  push r8
0000785dab1ce90a  push r9
0000785dab1ce90c  push r10
0000785dab1ce90e  push r11
0000785dab1ce910  sub rsp, 0xF0
0000785dab1ce917  vmovaps [rsp], xmm0
0000785dab1ce91c  vmovaps [rsp+0x10], xmm1
0000785dab1ce922  vmovaps [rsp+0x20], xmm2
0000785dab1ce928  vmovaps [rsp+0x30], xmm3
0000785dab1ce92e  vmovaps [rsp+0x40], xmm4
0000785dab1ce934  vmovaps [rsp+0x50], xmm5
0000785dab1ce93a  vmovaps [rsp+0x60], xmm6
0000785dab1ce940  vmovaps [rsp+0x70], xmm7
0000785dab1ce946  vmovaps [rsp+0x80], xmm8
0000785dab1ce94f  vmovaps [rsp+0x90], xmm9
0000785dab1ce958  vmovaps [rsp+0xA0], xmm10
0000785dab1ce961  vmovaps [rsp+0xB0], xmm11
0000785dab1ce96a  vmovaps [rsp+0xC0], xmm12
0000785dab1ce973  vmovaps [rsp+0xD0], xmm14
0000785dab1ce97c  vmovaps [rsp+0xE0], xmm15
0000785dab1ce985  sub rsp, 0x30
0000785dab1ce989  movaps [rsp], xmm13
0000785dab1ce98e  movaps [rsp+0x10], xmm12
0000785dab1ce994  movaps [rsp+0x20], xmm1
0000785dab1ce999  lea rdi, [rsp]
0000785dab1ce99d  mov esi, 0x00
0000785dab1ce9a2  mov rax, 0x61B13BBD6530
0000785dab1ce9ac  call rax
0000785dab1ce9ae  movaps xmm13, [rsp]
0000785dab1ce9b3  add rsp, 0x30
0000785dab1ce9b7  vmovaps xmm0, [rsp]
0000785dab1ce9bc  vmovaps xmm1, [rsp+0x10]
0000785dab1ce9c2  vmovaps xmm2, [rsp+0x20]
0000785dab1ce9c8  vmovaps xmm3, [rsp+0x30]
0000785dab1ce9ce  vmovaps xmm4, [rsp+0x40]
0000785dab1ce9d4  vmovaps xmm5, [rsp+0x50]
0000785dab1ce9da  vmovaps xmm6, [rsp+0x60]
0000785dab1ce9e0  vmovaps xmm7, [rsp+0x70]
0000785dab1ce9e6  vmovaps xmm8, [rsp+0x80]
0000785dab1ce9ef  vmovaps xmm9, [rsp+0x90]
0000785dab1ce9f8  vmovaps xmm10, [rsp+0xA0]
0000785dab1cea01  vmovaps xmm11, [rsp+0xB0]
0000785dab1cea0a  vmovaps xmm12, [rsp+0xC0]
0000785dab1cea13  vmovaps xmm14, [rsp+0xD0]
0000785dab1cea1c  vmovaps xmm15, [rsp+0xE0]
0000785dab1cea25  add rsp, 0xF0
0000785dab1cea2c  pop r11
0000785dab1cea2e  pop r10
0000785dab1cea30  pop r9
0000785dab1cea32  pop r8
0000785dab1cea34  pop rsi
0000785dab1cea35  pop rdi
0000785dab1cea36  pop rdx
0000785dab1cea37  pop rcx
0000785dab1cea38  pop rax
0000785dab1cea39  add rsp, 0x08
0000785dab1cea3d  jmp 0x0000785DAB1CE81B
0000785dab1cea42  call 0x0000785DAB00C380
0000785dab1cea47  jmp 0x0000785DAB1CE82E
0000785dab1cea4c  sub rsp, 0x08
0000785dab1cea50  push rax
0000785dab1cea51  push rcx
0000785dab1cea52  push rdx
0000785dab1cea53  push rdi
0000785dab1cea54  push rsi
0000785dab1cea55  push r8
0000785dab1cea57  push r9
0000785dab1cea59  push r10
0000785dab1cea5b  push r11
0000785dab1cea5d  sub rsp, 0xF0
0000785dab1cea64  vmovaps [rsp], xmm0
0000785dab1cea69  vmovaps [rsp+0x10], xmm2
0000785dab1cea6f  vmovaps [rsp+0x20], xmm3
0000785dab1cea75  vmovaps [rsp+0x30], xmm4
0000785dab1cea7b  vmovaps [rsp+0x40], xmm5
0000785dab1cea81  vmovaps [rsp+0x50], xmm6
0000785dab1cea87  vmovaps [rsp+0x60], xmm7
0000785dab1cea8d  vmovaps [rsp+0x70], xmm8
0000785dab1cea93  vmovaps [rsp+0x80], xmm9
0000785dab1cea9c  vmovaps [rsp+0x90], xmm10
0000785dab1ceaa5  vmovaps [rsp+0xA0], xmm11
0000785dab1ceaae  vmovaps [rsp+0xB0], xmm12
0000785dab1ceab7  vmovaps [rsp+0xC0], xmm13
0000785dab1ceac0  vmovaps [rsp+0xD0], xmm14
0000785dab1ceac9  vmovaps [rsp+0xE0], xmm15
0000785dab1cead2  sub rsp, 0x30
0000785dab1cead6  movaps [rsp], xmm1
0000785dab1ceada  movaps [rsp+0x10], xmm14
0000785dab1ceae0  movaps [rsp+0x20], xmm15
0000785dab1ceae6  lea rdi, [rsp]
0000785dab1ceaea  mov esi, 0x00
0000785dab1ceaef  mov rax, 0x61B13BBD6530
0000785dab1ceaf9  call rax
0000785dab1ceafb  movaps xmm1, [rsp]
0000785dab1ceaff  add rsp, 0x30
0000785dab1ceb03  vmovaps xmm0, [rsp]
0000785dab1ceb08  vmovaps xmm2, [rsp+0x10]
0000785dab1ceb0e  vmovaps xmm3, [rsp+0x20]
0000785dab1ceb14  vmovaps xmm4, [rsp+0x30]
0000785dab1ceb1a  vmovaps xmm5, [rsp+0x40]
0000785dab1ceb20  vmovaps xmm6, [rsp+0x50]
0000785dab1ceb26  vmovaps xmm7, [rsp+0x60]
0000785dab1ceb2c  vmovaps xmm8, [rsp+0x70]
0000785dab1ceb32  vmovaps xmm9, [rsp+0x80]
0000785dab1ceb3b  vmovaps xmm10, [rsp+0x90]
0000785dab1ceb44  vmovaps xmm11, [rsp+0xA0]
0000785dab1ceb4d  vmovaps xmm12, [rsp+0xB0]
0000785dab1ceb56  vmovaps xmm13, [rsp+0xC0]
0000785dab1ceb5f  vmovaps xmm14, [rsp+0xD0]
0000785dab1ceb68  vmovaps xmm15, [rsp+0xE0]
0000785dab1ceb71  add rsp, 0xF0
0000785dab1ceb78  pop r11
0000785dab1ceb7a  pop r10
0000785dab1ceb7c  pop r9
0000785dab1ceb7e  pop r8
0000785dab1ceb80  pop rsi
0000785dab1ceb81  pop rdi
0000785dab1ceb82  pop rdx
0000785dab1ceb83  pop rcx
0000785dab1ceb84  pop rax
0000785dab1ceb85  add rsp, 0x08
0000785dab1ceb89  jmp 0x0000785DAB1CE848
0000785dab1ceb8e  call 0x0000785DAAFFF540
0000785dab1ceb93  jmp 0x0000785DAB1CE85B
0000785dab1ceb98  int3
0000785dab1ceb99  nop [rax], eax
0000785dab1ceba0  movaps xmm1, [r15+0x180]
0000785dab1ceba8  vpmovqd xmm15, xmm1
0000785dab1cebae  pxor xmm14, xmm14
0000785dab1cebb3  punpcklqdq xmm15, xmm14
0000785dab1cebb8  movaps [r15+0x210], xmm15
0000785dab1cebc0  movq xmm15, qword ptr [r15+0x120]
0000785dab1cebc9  movq xmm14, qword ptr [r15+0x130]
0000785dab1cebd2  psubd xmm15, xmm14
0000785dab1cebd7  movq xmm15, xmm15
0000785dab1cebdc  movaps xmm13, [r15+0x170]
0000785dab1cebe4  paddq xmm1, xmm13
0000785dab1cebe9  movaps [r15+0x180], xmm1
0000785dab1cebf1  movq xmm1, qword ptr [r15+0x150]
0000785dab1cebfa  paddd xmm14, xmm1
0000785dab1cebff  movq xmm14, xmm14
0000785dab1cec04  movq xmm14, xmm14
0000785dab1cec09  movaps [r15+0x130], xmm14
0000785dab1cec11  pmovzxdq xmm15, xmm15
0000785dab1cec17  psllq xmm15, 0x00
0000785dab1cec1d  movq xmm1, qword ptr [r15+0x210]
0000785dab1cec26  movq xmm14, qword ptr [r15+0x110]
0000785dab1cec2f  paddd xmm1, xmm14
0000785dab1cec34  movq xmm1, xmm1
0000785dab1cec38  vcvtuqq2pd xmm15, xmm15
0000785dab1cec3e  pmovzxdq xmm1, xmm1
0000785dab1cec43  psllq xmm1, 0x00
0000785dab1cec48  vcvtuqq2pd xmm1, xmm1
0000785dab1cec4e  movaps xmm14, [r15+0x140]
0000785dab1cec56  movaps xmm13, xmm15
0000785dab1cec5a  mulpd xmm13, xmm14
0000785dab1cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000785dab1cec65  ptest xmm12, xmm12
0000785dab1cec6b  jnz 0x0000785DAB1CED4E
0000785dab1cec71  movaps [r15+0x220], xmm13
0000785dab1cec79  mov rax, [r15+0x48]
0000785dab1cec7d  mov r14, [r15+0x50]
0000785dab1cec81  lea r12, [r14+rax*1]
0000785dab1cec85  movups [r13+r12*1], xmm13
0000785dab1cec8b  movaps xmm15, [r15+0x160]
0000785dab1cec93  movaps xmm14, xmm1
0000785dab1cec97  mulpd xmm14, xmm15
0000785dab1cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000785dab1ceca2  ptest xmm13, xmm13
0000785dab1ceca8  jnz 0x0000785DAB1CEE9C
0000785dab1cecae  movaps [r15+0x210], xmm14
0000785dab1cecb6  mov r14, [r15+0x40]
0000785dab1cecba  lea r12, [r14+rax*1]
0000785dab1cecbe  movups [r13+r12*1], xmm14
0000785dab1cecc4  lea r14, [rax+0x10]
0000785dab1cecc8  mov [r15+0x48], r14
0000785dab1ceccc  xor eax, eax
0000785dab1cecce  mov r12d, 0x200
0000785dab1cecd4  cmp r14, r12
0000785dab1cecd7  cmc
0000785dab1cecd8  lahf
0000785dab1cecd9  seto al
0000785dab1cecdc  mov [r15+0x108], eax
0000785dab1cece3  mov eax, [r15+0x108]
0000785dab1cecea  sahf
0000785dab1ceceb  jnz 0x0000785DAB1CED1D
0000785dab1ceced  cmp dword ptr [r15+0x318], 0x00
0000785dab1cecf5  jz 0x0000785DAB1CEFF0
0000785dab1cecfb  nop [rax+rax*1], ax
0000785dab1ced04  nop [rax+rax*1], eax
0000785dab1ced0c  mov eax, 0x4101EC
0000785dab1ced11  mov [r15+0x100], rax
0000785dab1ced18  jmp 0x0000785DAAFFE110
0000785dab1ced1d  cmp dword ptr [r15+0x318], 0x00
0000785dab1ced25  jz 0x0000785DAB1CEBA0
0000785dab1ced2b  nop [rax+rax*1], ax
0000785dab1ced34  nop [rax+rax*1], eax
0000785dab1ced3c  mov eax, 0x4101AC
0000785dab1ced41  mov [r15+0x100], rax
0000785dab1ced48  jmp 0x0000785DAAFFE110
0000785dab1ced4d  int3
0000785dab1ced4e  sub rsp, 0x08
0000785dab1ced52  push rax
0000785dab1ced53  push rcx
0000785dab1ced54  push rdx
0000785dab1ced55  push rdi
0000785dab1ced56  push rsi
0000785dab1ced57  push r8
0000785dab1ced59  push r9
0000785dab1ced5b  push r10
0000785dab1ced5d  push r11
0000785dab1ced5f  sub rsp, 0xF0
0000785dab1ced66  vmovaps [rsp], xmm0
0000785dab1ced6b  vmovaps [rsp+0x10], xmm1
0000785dab1ced71  vmovaps [rsp+0x20], xmm2
0000785dab1ced77  vmovaps [rsp+0x30], xmm3
0000785dab1ced7d  vmovaps [rsp+0x40], xmm4
0000785dab1ced83  vmovaps [rsp+0x50], xmm5
0000785dab1ced89  vmovaps [rsp+0x60], xmm6
0000785dab1ced8f  vmovaps [rsp+0x70], xmm7
0000785dab1ced95  vmovaps [rsp+0x80], xmm8
0000785dab1ced9e  vmovaps [rsp+0x90], xmm9
0000785dab1ceda7  vmovaps [rsp+0xA0], xmm10
0000785dab1cedb0  vmovaps [rsp+0xB0], xmm11
0000785dab1cedb9  vmovaps [rsp+0xC0], xmm12
0000785dab1cedc2  vmovaps [rsp+0xD0], xmm14
0000785dab1cedcb  vmovaps [rsp+0xE0], xmm15
0000785dab1cedd4  sub rsp, 0x30
0000785dab1cedd8  movaps [rsp], xmm13
0000785dab1ceddd  movaps [rsp+0x10], xmm15
0000785dab1cede3  movaps [rsp+0x20], xmm14
0000785dab1cede9  lea rdi, [rsp]
0000785dab1ceded  mov esi, 0x00
0000785dab1cedf2  mov rax, 0x61B13BBD6530
0000785dab1cedfc  call rax
0000785dab1cedfe  movaps xmm13, [rsp]
0000785dab1cee03  add rsp, 0x30
0000785dab1cee07  vmovaps xmm0, [rsp]
0000785dab1cee0c  vmovaps xmm1, [rsp+0x10]
0000785dab1cee12  vmovaps xmm2, [rsp+0x20]
0000785dab1cee18  vmovaps xmm3, [rsp+0x30]
0000785dab1cee1e  vmovaps xmm4, [rsp+0x40]
0000785dab1cee24  vmovaps xmm5, [rsp+0x50]
0000785dab1cee2a  vmovaps xmm6, [rsp+0x60]
0000785dab1cee30  vmovaps xmm7, [rsp+0x70]
0000785dab1cee36  vmovaps xmm8, [rsp+0x80]
0000785dab1cee3f  vmovaps xmm9, [rsp+0x90]
0000785dab1cee48  vmovaps xmm10, [rsp+0xA0]
0000785dab1cee51  vmovaps xmm11, [rsp+0xB0]
0000785dab1cee5a  vmovaps xmm12, [rsp+0xC0]
0000785dab1cee63  vmovaps xmm14, [rsp+0xD0]
0000785dab1cee6c  vmovaps xmm15, [rsp+0xE0]
0000785dab1cee75  add rsp, 0xF0
0000785dab1cee7c  pop r11
0000785dab1cee7e  pop r10
0000785dab1cee80  pop r9
0000785dab1cee82  pop r8
0000785dab1cee84  pop rsi
0000785dab1cee85  pop rdi
0000785dab1cee86  pop rdx
0000785dab1cee87  pop rcx
0000785dab1cee88  pop rax
0000785dab1cee89  add rsp, 0x08
0000785dab1cee8d  jmp 0x0000785DAB1CEC71
0000785dab1cee92  call 0x0000785DAB0C2240
0000785dab1cee97  jmp 0x0000785DAB1CEC8B
0000785dab1cee9c  sub rsp, 0x08
0000785dab1ceea0  push rax
0000785dab1ceea1  push rcx
0000785dab1ceea2  push rdx
0000785dab1ceea3  push rdi
0000785dab1ceea4  push rsi
0000785dab1ceea5  push r8
0000785dab1ceea7  push r9
0000785dab1ceea9  push r10
0000785dab1ceeab  push r11
0000785dab1ceead  sub rsp, 0xF0
0000785dab1ceeb4  vmovaps [rsp], xmm0
0000785dab1ceeb9  vmovaps [rsp+0x10], xmm1
0000785dab1ceebf  vmovaps [rsp+0x20], xmm2
0000785dab1ceec5  vmovaps [rsp+0x30], xmm3
0000785dab1ceecb  vmovaps [rsp+0x40], xmm4
0000785dab1ceed1  vmovaps [rsp+0x50], xmm5
0000785dab1ceed7  vmovaps [rsp+0x60], xmm6
0000785dab1ceedd  vmovaps [rsp+0x70], xmm7
0000785dab1ceee3  vmovaps [rsp+0x80], xmm8
0000785dab1ceeec  vmovaps [rsp+0x90], xmm9
0000785dab1ceef5  vmovaps [rsp+0xA0], xmm10
0000785dab1ceefe  vmovaps [rsp+0xB0], xmm11
0000785dab1cef07  vmovaps [rsp+0xC0], xmm12
0000785dab1cef10  vmovaps [rsp+0xD0], xmm13
0000785dab1cef19  vmovaps [rsp+0xE0], xmm15
0000785dab1cef22  sub rsp, 0x30
0000785dab1cef26  movaps [rsp], xmm14
0000785dab1cef2b  movaps [rsp+0x10], xmm1
0000785dab1cef30  movaps [rsp+0x20], xmm15
0000785dab1cef36  lea rdi, [rsp]
0000785dab1cef3a  mov esi, 0x00
0000785dab1cef3f  mov rax, 0x61B13BBD6530
0000785dab1cef49  call rax
0000785dab1cef4b  movaps xmm14, [rsp]
0000785dab1cef50  add rsp, 0x30
0000785dab1cef54  vmovaps xmm0, [rsp]
0000785dab1cef59  vmovaps xmm1, [rsp+0x10]
0000785dab1cef5f  vmovaps xmm2, [rsp+0x20]
0000785dab1cef65  vmovaps xmm3, [rsp+0x30]
0000785dab1cef6b  vmovaps xmm4, [rsp+0x40]
0000785dab1cef71  vmovaps xmm5, [rsp+0x50]
0000785dab1cef77  vmovaps xmm6, [rsp+0x60]
0000785dab1cef7d  vmovaps xmm7, [rsp+0x70]
0000785dab1cef83  vmovaps xmm8, [rsp+0x80]
0000785dab1cef8c  vmovaps xmm9, [rsp+0x90]
0000785dab1cef95  vmovaps xmm10, [rsp+0xA0]
0000785dab1cef9e  vmovaps xmm11, [rsp+0xB0]
0000785dab1cefa7  vmovaps xmm12, [rsp+0xC0]
0000785dab1cefb0  vmovaps xmm13, [rsp+0xD0]
0000785dab1cefb9  vmovaps xmm15, [rsp+0xE0]
0000785dab1cefc2  add rsp, 0xF0
0000785dab1cefc9  pop r11
0000785dab1cefcb  pop r10
0000785dab1cefcd  pop r9
0000785dab1cefcf  pop r8
0000785dab1cefd1  pop rsi
0000785dab1cefd2  pop rdi
0000785dab1cefd3  pop rdx
0000785dab1cefd4  pop rcx
0000785dab1cefd5  pop rax
0000785dab1cefd6  add rsp, 0x08
0000785dab1cefda  jmp 0x0000785DAB1CECAE
0000785dab1cefdf  call 0x0000785DAB0C34C0
0000785dab1cefe4  jmp 0x0000785DAB1CECC4
0000785dab1cefe9  int3
0000785dab1cefea  nop [rax+rax*1], ax
0000785dab1ceff0  mov rax, [r15+0xF8]
0000785dab1ceff7  lea r14, [rax-0x150]
0000785dab1ceffe  mov [r15+0xF8], r14
0000785dab1cf005  mov rax, [r15+0x50]
0000785dab1cf009  lea r12, [rax+0x80]
0000785dab1cf010  movups xmm1, [r13+r12*1]
0000785dab1cf016  lea r12, [rax+0x90]
0000785dab1cf01d  movups xmm15, [r13+r12*1]
0000785dab1cf023  mov qword ptr [r15+0x48], 0x00
0000785dab1cf02b  lea r12, [rax+0x40]
0000785dab1cf02f  movups xmm14, [r13+r12*1]
0000785dab1cf035  lea r12, [rax+0x50]
0000785dab1cf039  movups xmm13, [r13+r12*1]
0000785dab1cf03f  lea r12, [r14+0x120]
0000785dab1cf046  movq xmm12, qword ptr [r15+0x1C0]
0000785dab1cf04f  movq xmm11, qword ptr [r15+0x1B0]
0000785dab1cf058  movq r11, xmm12
0000785dab1cf05d  movq r10, xmm11
0000785dab1cf062  mov [r13+r12*1], r11
0000785dab1cf067  lea r12, [r14+0x128]
0000785dab1cf06e  mov [r13+r12*1], r10
0000785dab1cf073  vxorps xmm12, xmm12, xmm12
0000785dab1cf078  vpbroadcastq xmm12, xmm12
0000785dab1cf07d  lea r12, [r14+0x100]
0000785dab1cf084  movq xmm11, qword ptr [r15+0x200]
0000785dab1cf08d  movq xmm10, qword ptr [r15+0x1F0]
0000785dab1cf096  movq r11, xmm11
0000785dab1cf09b  movq r10, xmm10
0000785dab1cf0a0  mov [r13+r12*1], r11
0000785dab1cf0a5  lea r12, [r14+0x108]
0000785dab1cf0ac  mov [r13+r12*1], r10
0000785dab1cf0b1  lea r12, [r14+0xE0]
0000785dab1cf0b8  movups [r13+r12*1], xmm15
0000785dab1cf0be  lea r12, [r14+0xF0]
0000785dab1cf0c5  movups [r13+r12*1], xmm1
0000785dab1cf0cb  lea r12, [rax+0xC0]
0000785dab1cf0d2  movups xmm1, [r13+r12*1]
0000785dab1cf0d8  lea r12, [rax+0xD0]
0000785dab1cf0df  movups xmm15, [r13+r12*1]
0000785dab1cf0e5  lea r12, [r14+0x110]
0000785dab1cf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000785dab1cf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000785dab1cf0fe  movq r11, xmm11
0000785dab1cf103  movq r10, xmm10
0000785dab1cf108  mov [r13+r12*1], r11
0000785dab1cf10d  lea r12, [r14+0x118]
0000785dab1cf114  mov [r13+r12*1], r10
0000785dab1cf119  movups xmm11, [r13+rax*1]
0000785dab1cf11f  lea r12, [rax+0x10]
0000785dab1cf123  movups xmm10, [r13+r12*1]
0000785dab1cf129  lea r12, [r14+0x130]
0000785dab1cf130  movq xmm9, qword ptr [r15+0x1A0]
0000785dab1cf139  movq xmm8, qword ptr [r15+0x190]
0000785dab1cf142  movq r11, xmm9
0000785dab1cf147  movq r10, xmm8
0000785dab1cf14c  mov [r13+r12*1], r11
0000785dab1cf151  lea r12, [r14+0x138]
0000785dab1cf158  mov [r13+r12*1], r10
0000785dab1cf15d  lea r12, [rax+0x140]
0000785dab1cf164  movups xmm9, [r13+r12*1]
0000785dab1cf16a  lea r12, [rax+0x150]
0000785dab1cf171  movups xmm8, [r13+r12*1]
0000785dab1cf177  lea r12, [r14+0xC0]
0000785dab1cf17e  movups [r13+r12*1], xmm15
0000785dab1cf184  lea r12, [r14+0xD0]
0000785dab1cf18b  movups [r13+r12*1], xmm1
0000785dab1cf191  lea r12, [rax+0x100]
0000785dab1cf198  movups xmm1, [r13+r12*1]
0000785dab1cf19e  lea r12, [rax+0x110]
0000785dab1cf1a5  movups xmm15, [r13+r12*1]
0000785dab1cf1ab  lea r12, [r14+0x140]
0000785dab1cf1b2  mov r11, [r15+0xE8]
0000785dab1cf1b9  mov [r13+r12*1], r11
0000785dab1cf1be  lea r12, [rax+0x180]
0000785dab1cf1c5  movups xmm7, [r13+r12*1]
0000785dab1cf1cb  lea r12, [rax+0x190]
0000785dab1cf1d2  movups xmm6, [r13+r12*1]
0000785dab1cf1d8  lea r12, [rax+0x1C0]
0000785dab1cf1df  movups xmm5, [r13+r12*1]
0000785dab1cf1e5  lea r12, [rax+0x1D0]
0000785dab1cf1ec  movups xmm4, [r13+r12*1]
0000785dab1cf1f2  lea r12, [r14+0x20]
0000785dab1cf1f6  movups [r13+r12*1], xmm1
0000785dab1cf1fc  lea r12, [r14+0x30]
0000785dab1cf200  movups [r13+r12*1], xmm13
0000785dab1cf206  lea r12, [rax+0x60]
0000785dab1cf20a  movups xmm1, [r13+r12*1]
0000785dab1cf210  lea r12, [rax+0x70]
0000785dab1cf214  movups xmm13, [r13+r12*1]
0000785dab1cf21a  lea r12, [rax+0x20]
0000785dab1cf21e  movups xmm3, [r13+r12*1]
0000785dab1cf224  lea r12, [rax+0x30]
0000785dab1cf228  movups xmm2, [r13+r12*1]
0000785dab1cf22e  movaps [r15+0x1F0], xmm2
0000785dab1cf236  lea r12, [r14+0x60]
0000785dab1cf23a  movups [r13+r12*1], xmm11
0000785dab1cf240  lea r12, [r14+0x70]
0000785dab1cf244  movups [r13+r12*1], xmm5
0000785dab1cf24a  lea r12, [rax+0xE0]
0000785dab1cf251  movups xmm11, [r13+r12*1]
0000785dab1cf257  lea r12, [rax+0xF0]
0000785dab1cf25e  movups xmm5, [r13+r12*1]
0000785dab1cf264  lea r12, [r14+0xA0]
0000785dab1cf26b  movups [r13+r12*1], xmm13
0000785dab1cf271  lea r12, [r14+0xB0]
0000785dab1cf278  movups [r13+r12*1], xmm1
0000785dab1cf27e  lea r12, [rax+0xA0]
0000785dab1cf285  movups xmm1, [r13+r12*1]
0000785dab1cf28b  lea r12, [rax+0xB0]
0000785dab1cf292  movups xmm13, [r13+r12*1]
0000785dab1cf298  lea r12, [rax+0x120]
0000785dab1cf29f  vmovaps [rsp+0x10], xmm1
0000785dab1cf2a5  movups xmm1, [r13+r12*1]
0000785dab1cf2ab  lea r12, [rax+0x130]
0000785dab1cf2b2  vmovaps [rsp+0x20], xmm1
0000785dab1cf2b8  movups xmm1, [r13+r12*1]
0000785dab1cf2be  lea r12, [rax+0x160]
0000785dab1cf2c5  vmovaps [rsp+0x30], xmm1
0000785dab1cf2cb  movups xmm1, [r13+r12*1]
0000785dab1cf2d1  lea r12, [rax+0x170]
0000785dab1cf2d8  vmovaps [rsp+0x40], xmm1
0000785dab1cf2de  movups xmm1, [r13+r12*1]
0000785dab1cf2e4  movaps [r15+0x2B0], xmm1
0000785dab1cf2ec  lea r12, [r14+0x80]
0000785dab1cf2f3  movups [r13+r12*1], xmm13
0000785dab1cf2f9  lea r12, [r14+0x90]
0000785dab1cf300  vmovaps xmm13, [rsp+0x10]
0000785dab1cf306  movups [r13+r12*1], xmm13
0000785dab1cf30c  lea r12, [rax+0x1A0]
0000785dab1cf313  movups xmm13, [r13+r12*1]
0000785dab1cf319  lea r12, [rax+0x1B0]
0000785dab1cf320  vmovaps [rsp+0x10], xmm1
0000785dab1cf326  movups xmm1, [r13+r12*1]
0000785dab1cf32c  movaps [r15+0x290], xmm13
0000785dab1cf334  movaps [r15+0x1E0], xmm1
0000785dab1cf33c  lea r12, [rax+0x1E0]
0000785dab1cf343  vmovaps [rsp+0x50], xmm1
0000785dab1cf349  movups xmm1, [r13+r12*1]
0000785dab1cf34f  lea r12, [rax+0x1F0]
0000785dab1cf356  vmovaps [rsp+0x60], xmm1
0000785dab1cf35c  movups xmm1, [r13+r12*1]
0000785dab1cf362  mov qword ptr [r15+0x50], 0x430920
0000785dab1cf36a  lea rax, [r14+0x40]
0000785dab1cf36e  vmovaps [rsp+0x70], xmm1
0000785dab1cf374  vmovaps xmm1, [rsp+0x40]
0000785dab1cf37a  movups [r13+rax*1], xmm1
0000785dab1cf380  lea rax, [r14+0x50]
0000785dab1cf384  movups [r13+rax*1], xmm10
0000785dab1cf38a  vmovaps xmm1, [rsp+0x70]
0000785dab1cf390  movups [r13+r14*1], xmm1
0000785dab1cf396  lea rax, [r14+0x10]
0000785dab1cf39a  vmovaps xmm1, [rsp+0x60]
0000785dab1cf3a0  movups [r13+rax*1], xmm1
0000785dab1cf3a6  mov rax, [r15+0x40]
0000785dab1cf3aa  vmovaps [rsp+0x40], xmm3
0000785dab1cf3b0  vmovaps xmm1, [rsp+0x40]
0000785dab1cf3b6  por xmm3, xmm1
0000785dab1cf3ba  vmovaps [rsp+0x40], xmm6
0000785dab1cf3c0  vmovaps xmm10, [rsp+0x40]
0000785dab1cf3c6  por xmm6, xmm10
0000785dab1cf3cb  lea r12, [rax+0x30]
0000785dab1cf3cf  mov r11, [r13+r12*1]
0000785dab1cf3d4  lea r12, [rax+0x38]
0000785dab1cf3d8  mov r10, [r13+r12*1]
0000785dab1cf3dd  movq xmm10, r11
0000785dab1cf3e2  vmovaps [rsp+0x40], xmm1
0000785dab1cf3e8  movq xmm1, r10
0000785dab1cf3ed  movq xmm10, xmm10
0000785dab1cf3f2  vmovaps [rsp+0x60], xmm10
0000785dab1cf3f8  movq xmm10, xmm10
0000785dab1cf3fd  movaps [r15+0x130], xmm10
0000785dab1cf405  movq xmm1, xmm1
0000785dab1cf409  vmovaps [rsp+0x70], xmm1
0000785dab1cf40f  movq xmm1, xmm1
0000785dab1cf413  movaps [r15+0x280], xmm1
0000785dab1cf41b  vmovaps [rsp+0x80], xmm9
0000785dab1cf424  vmovaps xmm1, [rsp+0x80]
0000785dab1cf42d  por xmm9, xmm1
0000785dab1cf432  lea r12, [rax+0x20]
0000785dab1cf436  mov r11, [r13+r12*1]
0000785dab1cf43b  lea r12, [rax+0x28]
0000785dab1cf43f  mov r10, [r13+r12*1]
0000785dab1cf444  movq xmm1, r11
0000785dab1cf449  movq xmm10, r10
0000785dab1cf44e  movq xmm1, xmm1
0000785dab1cf452  vmovaps [rsp+0x80], xmm1
0000785dab1cf45b  movq xmm1, xmm1
0000785dab1cf45f  movaps [r15+0x150], xmm1
0000785dab1cf467  movq xmm10, xmm10
0000785dab1cf46c  vmovaps [rsp+0x90], xmm10
0000785dab1cf475  movq xmm10, xmm10
0000785dab1cf47a  movaps [r15+0x140], xmm10
0000785dab1cf482  lea r12, [rax+0x10]
0000785dab1cf486  mov r11, [r13+r12*1]
0000785dab1cf48b  lea r12, [rax+0x18]
0000785dab1cf48f  mov r10, [r13+r12*1]
0000785dab1cf494  movq xmm1, r11
0000785dab1cf499  movq xmm10, r10
0000785dab1cf49e  movq xmm1, xmm1
0000785dab1cf4a2  vmovaps [rsp+0xA0], xmm1
0000785dab1cf4ab  movq xmm1, xmm1
0000785dab1cf4af  movaps [r15+0x170], xmm1
0000785dab1cf4b7  movq xmm10, xmm10
0000785dab1cf4bc  vmovaps [rsp+0xB0], xmm10
0000785dab1cf4c5  movq xmm10, xmm10
0000785dab1cf4ca  movaps [r15+0x160], xmm10
0000785dab1cf4d2  mov r12, [r13+rax*1]
0000785dab1cf4d7  vmovq xmm1, r12
0000785dab1cf4dc  vpbroadcastq xmm1, xmm1
0000785dab1cf4e1  lea r12, [rax+0x08]
0000785dab1cf4e5  mov rax, [r13+r12*1]
0000785dab1cf4ea  movq xmm10, rax
0000785dab1cf4ef  movaps [r15+0x230], xmm10
0000785dab1cf4f7  lea rax, [r14+0x50]
0000785dab1cf4fb  movups xmm10, [r13+rax*1]
0000785dab1cf501  lea rax, [r14+0x60]
0000785dab1cf505  vmovaps [rsp+0xC0], xmm1
0000785dab1cf50e  movups xmm1, [r13+rax*1]
0000785dab1cf514  lea rax, [r14+0x30]
0000785dab1cf518  vmovaps [rsp+0xD0], xmm1
0000785dab1cf521  movups xmm1, [r13+rax*1]
0000785dab1cf527  mov qword ptr [r15+0x60], 0x430920
0000785dab1cf52f  mov qword ptr [r15+0x58], 0x40
0000785dab1cf537  vmovaps [rsp+0xE0], xmm1
0000785dab1cf540  vmovaps [rsp+0xF0], xmm15
0000785dab1cf549  vmovaps xmm15, [rsp+0xC0]
0000785dab1cf552  vmovaps [rsp+0xC0], xmm14
0000785dab1cf55b  vmovaps xmm14, [rsp+0x40]
0000785dab1cf561  vmovaps [rsp+0x40], xmm13
0000785dab1cf567  movaps xmm1, xmm15
0000785dab1cf56b  mulpd xmm1, xmm14
0000785dab1cf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000785dab1cf575  ptest xmm13, xmm13
0000785dab1cf57b  jnz 0x0000785DAB1D0682
0000785dab1cf581  movq xmm14, qword ptr [r15+0x230]
0000785dab1cf58a  vmovaps [rsp+0x100], xmm14
0000785dab1cf593  vpermilpd xmm14, xmm14, 0x00
0000785dab1cf599  vmovaps [rsp+0x110], xmm1
0000785dab1cf5a2  vmovaps xmm1, [rsp+0xE0]
0000785dab1cf5ab  vmovaps [rsp+0xE0], xmm15
0000785dab1cf5b4  movaps xmm13, xmm1
0000785dab1cf5b8  mulpd xmm13, xmm14
0000785dab1cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000785dab1cf5c3  ptest xmm15, xmm15
0000785dab1cf5c9  jnz 0x0000785DAB1D07C4
0000785dab1cf5cf  vxorps xmm1, xmm1, xmm1
0000785dab1cf5d3  vpbroadcastq xmm1, xmm1
0000785dab1cf5d8  vmovaps xmm14, [rsp+0xE0]
0000785dab1cf5e1  vmovaps [rsp+0xE0], xmm1
0000785dab1cf5ea  vmovaps xmm1, [rsp+0xD0]
0000785dab1cf5f3  vmovaps [rsp+0xD0], xmm13
0000785dab1cf5fc  movaps xmm15, xmm14
0000785dab1cf600  mulpd xmm15, xmm1
0000785dab1cf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000785dab1cf60b  ptest xmm13, xmm13
0000785dab1cf611  jnz 0x0000785DAB1D0907
0000785dab1cf617  movaps xmm1, xmm14
0000785dab1cf61b  mulpd xmm1, xmm10
0000785dab1cf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000785dab1cf625  ptest xmm13, xmm13
0000785dab1cf62b  jnz 0x0000785DAB1D0A4A
0000785dab1cf631  movaps xmm13, xmm14
0000785dab1cf635  mulpd xmm13, xmm2
0000785dab1cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000785dab1cf640  ptest xmm10, xmm10
0000785dab1cf646  jnz 0x0000785DAB1D0B8C
0000785dab1cf64c  vmovaps [rsp+0x120], xmm7
0000785dab1cf655  vmovaps xmm14, [rsp+0x120]
0000785dab1cf65e  por xmm7, xmm14
0000785dab1cf663  vmovaps xmm14, [rsp+0xC0]
0000785dab1cf66c  vmovaps xmm10, [rsp+0xC0]
0000785dab1cf675  por xmm14, xmm10
0000785dab1cf67a  vmovaps xmm2, [rsp+0x100]
0000785dab1cf683  vpermilpd xmm2, xmm2, 0x00
0000785dab1cf689  vmovaps [rsp+0xC0], xmm1
0000785dab1cf692  vmovaps [rsp+0x120], xmm15
0000785dab1cf69b  movaps xmm1, xmm10
0000785dab1cf69f  mulpd xmm1, xmm2
0000785dab1cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000785dab1cf6a8  ptest xmm15, xmm15
0000785dab1cf6ae  jnz 0x0000785DAB1D0CCF
0000785dab1cf6b4  xor eax, eax
0000785dab1cf6b6  mov r12d, 0x40
0000785dab1cf6bc  mov r11d, 0x200
0000785dab1cf6c2  cmp r12, r11
0000785dab1cf6c5  cmc
0000785dab1cf6c6  lahf
0000785dab1cf6c7  seto al
0000785dab1cf6ca  mov [r15+0x108], eax
0000785dab1cf6d1  vmovaps xmm10, [rsp+0x110]
0000785dab1cf6da  vmovaps xmm2, [rsp+0xE0]
0000785dab1cf6e3  vmovaps [rsp+0xE0], xmm1
0000785dab1cf6ec  movaps xmm15, xmm10
0000785dab1cf6f0  addpd xmm15, xmm2
0000785dab1cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000785dab1cf6fb  ptest xmm1, xmm1
0000785dab1cf700  jnz 0x0000785DAB1D0E10
0000785dab1cf706  vmovaps xmm10, [rsp+0x120]
0000785dab1cf70f  vmovaps [rsp+0x110], xmm15
0000785dab1cf718  movaps xmm1, xmm10
0000785dab1cf71c  addpd xmm1, xmm12
0000785dab1cf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000785dab1cf726  ptest xmm15, xmm15
0000785dab1cf72c  jnz 0x0000785DAB1D0F53
0000785dab1cf732  vmovaps xmm10, [rsp+0xC0]
0000785dab1cf73b  vmovaps [rsp+0xC0], xmm1
0000785dab1cf744  movaps xmm15, xmm10
0000785dab1cf748  addpd xmm15, xmm12
0000785dab1cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000785dab1cf753  ptest xmm1, xmm1
0000785dab1cf758  jnz 0x0000785DAB1D1095
0000785dab1cf75e  vmovaps xmm1, [rsp+0x30]
0000785dab1cf764  vmovaps xmm12, [rsp+0x30]
0000785dab1cf76a  por xmm1, xmm12
0000785dab1cf76f  vmovaps xmm12, [rsp+0x20]
0000785dab1cf775  vmovaps xmm10, [rsp+0x20]
0000785dab1cf77b  por xmm12, xmm10
0000785dab1cf780  vmovaps [rsp+0x20], xmm5
0000785dab1cf786  vmovaps xmm10, [rsp+0x20]
0000785dab1cf78c  por xmm5, xmm10
0000785dab1cf791  vmovaps [rsp+0x20], xmm11
0000785dab1cf797  vmovaps xmm10, [rsp+0x20]
0000785dab1cf79d  por xmm11, xmm10
0000785dab1cf7a2  vmovaps [rsp+0x20], xmm4
0000785dab1cf7a8  vmovaps xmm10, [rsp+0x20]
0000785dab1cf7ae  por xmm4, xmm10
0000785dab1cf7b3  vmovaps [rsp+0x20], xmm8
0000785dab1cf7b9  vmovaps xmm10, [rsp+0x20]
0000785dab1cf7bf  por xmm8, xmm10
0000785dab1cf7c4  vmovaps xmm10, [rsp+0xF0]
0000785dab1cf7cd  vmovaps [rsp+0x20], xmm1
0000785dab1cf7d3  vmovaps xmm1, [rsp+0xF0]
0000785dab1cf7dc  por xmm10, xmm1
0000785dab1cf7e1  lea rax, [r14+0xA0]
0000785dab1cf7e8  movups xmm1, [r13+rax*1]
0000785dab1cf7ee  lea rax, [r14+0xB0]
0000785dab1cf7f5  vmovaps [rsp+0x30], xmm1
0000785dab1cf7fb  movups xmm1, [r13+rax*1]
0000785dab1cf801  vmovaps [rsp+0xF0], xmm1
0000785dab1cf80a  vmovaps [rsp+0x120], xmm15
0000785dab1cf813  movaps xmm1, xmm13
0000785dab1cf817  addpd xmm1, xmm2
0000785dab1cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000785dab1cf820  ptest xmm15, xmm15
0000785dab1cf826  jnz 0x0000785DAB1D11ED
0000785dab1cf82c  lea rax, [r14+0xF0]
0000785dab1cf833  movups xmm15, [r13+rax*1]
0000785dab1cf839  vmovaps xmm2, [rsp+0xC0]
0000785dab1cf842  vmovaps [rsp+0xC0], xmm1
0000785dab1cf84b  vmovaps xmm1, [rsp+0xE0]
0000785dab1cf854  vmovaps [rsp+0xE0], xmm15
0000785dab1cf85d  movaps xmm13, xmm2
0000785dab1cf861  addpd xmm13, xmm1
0000785dab1cf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000785dab1cf86c  ptest xmm15, xmm15
0000785dab1cf872  jnz 0x0000785DAB1D1338
0000785dab1cf878  vmovaps xmm15, [rsp+0x120]
0000785dab1cf881  vmovaps xmm2, [rsp+0xD0]
0000785dab1cf88a  vmovaps [rsp+0xD0], xmm14
0000785dab1cf893  movaps xmm1, xmm15
0000785dab1cf897  addpd xmm1, xmm2
0000785dab1cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000785dab1cf8a0  ptest xmm14, xmm14
0000785dab1cf8a6  jnz 0x0000785DAB1D147A
0000785dab1cf8ac  vmovaps xmm15, [rsp+0x100]
0000785dab1cf8b5  vpermilpd xmm15, xmm15, 0x00
0000785dab1cf8bb  vmovaps xmm2, [rsp+0xF0]
0000785dab1cf8c4  vmovaps [rsp+0xF0], xmm1
0000785dab1cf8cd  movaps xmm14, xmm2
0000785dab1cf8d1  mulpd xmm14, xmm15
0000785dab1cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000785dab1cf8dc  ptest xmm1, xmm1
0000785dab1cf8e1  jnz 0x0000785DAB1D15BB
0000785dab1cf8e7  vmovaps xmm1, [rsp+0xA0]
0000785dab1cf8f0  vpermilpd xmm1, xmm1, 0x00
0000785dab1cf8f6  vmovaps xmm2, [rsp+0xE0]
0000785dab1cf8ff  vmovaps [rsp+0xE0], xmm14
0000785dab1cf908  movaps xmm15, xmm2
0000785dab1cf90c  mulpd xmm15, xmm1
0000785dab1cf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000785dab1cf917  ptest xmm14, xmm14
0000785dab1cf91d  jnz 0x0000785DAB1D16FE
0000785dab1cf923  lea rax, [r14+0xE0]
0000785dab1cf92a  movups xmm1, [r13+rax*1]
0000785dab1cf930  vmovaps xmm14, [rsp+0x100]
0000785dab1cf939  vpermilpd xmm14, xmm14, 0x00
0000785dab1cf93f  vmovaps [rsp+0x100], xmm1
0000785dab1cf948  vmovaps xmm1, [rsp+0x30]
0000785dab1cf94e  vmovaps [rsp+0x30], xmm15
0000785dab1cf954  movaps xmm2, xmm1
0000785dab1cf957  mulpd xmm2, xmm14
0000785dab1cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000785dab1cf961  ptest xmm15, xmm15
0000785dab1cf967  jnz 0x0000785DAB1D184A
0000785dab1cf96d  vmovaps [rsp+0x120], xmm10
0000785dab1cf976  vmovaps xmm1, [rsp+0x120]
0000785dab1cf97f  por xmm10, xmm1
0000785dab1cf984  movaps [r15+0x300], xmm10
0000785dab1cf98c  vmovaps [rsp+0x120], xmm8
0000785dab1cf995  vmovaps xmm1, [rsp+0x120]
0000785dab1cf99e  por xmm8, xmm1
0000785dab1cf9a3  movaps [r15+0x190], xmm8
0000785dab1cf9ab  vmovaps xmm1, [rsp+0xA0]
0000785dab1cf9b4  vpermilpd xmm1, xmm1, 0x00
0000785dab1cf9ba  vmovaps xmm14, [rsp+0x100]
0000785dab1cf9c3  vmovaps [rsp+0x100], xmm13
0000785dab1cf9cc  movaps xmm15, xmm14
0000785dab1cf9d0  mulpd xmm15, xmm1
0000785dab1cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000785dab1cf9db  ptest xmm13, xmm13
0000785dab1cf9e1  jnz 0x0000785DAB1D198B
0000785dab1cf9e7  lea rax, [r14+0x90]
0000785dab1cf9ee  movups xmm1, [r13+rax*1]
0000785dab1cf9f4  vmovaps [rsp+0x120], xmm4
0000785dab1cf9fd  vmovaps xmm14, [rsp+0x120]
0000785dab1cfa06  por xmm4, xmm14
0000785dab1cfa0b  movaps [r15+0x1C0], xmm4
0000785dab1cfa13  vmovaps [rsp+0x120], xmm11
0000785dab1cfa1c  vmovaps xmm14, [rsp+0x120]
0000785dab1cfa25  por xmm11, xmm14
0000785dab1cfa2a  movaps [r15+0x200], xmm11
0000785dab1cfa32  vmovaps [rsp+0x120], xmm5
0000785dab1cfa3b  vmovaps xmm14, [rsp+0x120]
0000785dab1cfa44  por xmm5, xmm14
0000785dab1cfa49  movaps [r15+0x2D0], xmm5
0000785dab1cfa51  vmovaps [rsp+0x120], xmm12
0000785dab1cfa5a  vmovaps xmm14, [rsp+0x120]
0000785dab1cfa63  por xmm12, xmm14
0000785dab1cfa68  movaps [r15+0x2E0], xmm12
0000785dab1cfa70  vmovaps xmm13, [rsp+0x110]
0000785dab1cfa79  vmovaps [rsp+0x110], xmm1
0000785dab1cfa82  vmovaps xmm1, [rsp+0xE0]
0000785dab1cfa8b  vmovaps [rsp+0xE0], xmm15
0000785dab1cfa94  movaps xmm14, xmm13
0000785dab1cfa98  addpd xmm14, xmm1
0000785dab1cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000785dab1cfaa3  ptest xmm15, xmm15
0000785dab1cfaa9  jnz 0x0000785DAB1D1AD8
0000785dab1cfaaf  vmovaps xmm1, [rsp+0xA0]
0000785dab1cfab8  vpermilpd xmm1, xmm1, 0x00
0000785dab1cfabe  vmovaps xmm13, [rsp+0x110]
0000785dab1cfac7  vmovaps [rsp+0x110], xmm14
0000785dab1cfad0  movaps xmm15, xmm13
0000785dab1cfad4  mulpd xmm15, xmm1
0000785dab1cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000785dab1cfadf  ptest xmm14, xmm14
0000785dab1cfae5  jnz 0x0000785DAB1D1C1B
0000785dab1cfaeb  lea rax, [r14+0x80]
0000785dab1cfaf2  movups xmm1, [r13+rax*1]
0000785dab1cfaf8  vmovaps xmm13, [rsp+0xC0]
0000785dab1cfb01  vmovaps [rsp+0xC0], xmm1
0000785dab1cfb0a  movaps xmm14, xmm13
0000785dab1cfb0e  addpd xmm14, xmm2
0000785dab1cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000785dab1cfb19  ptest xmm1, xmm1
0000785dab1cfb1e  jnz 0x0000785DAB1D1D68
0000785dab1cfb24  vmovaps xmm13, [rsp+0x100]
0000785dab1cfb2d  vmovaps xmm2, [rsp+0x30]
0000785dab1cfb33  vmovaps [rsp+0x30], xmm15
0000785dab1cfb39  movaps xmm1, xmm13
0000785dab1cfb3d  addpd xmm1, xmm2
0000785dab1cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000785dab1cfb46  ptest xmm15, xmm15
0000785dab1cfb4c  jnz 0x0000785DAB1D1EAB
0000785dab1cfb52  vmovaps xmm15, [rsp+0x20]
0000785dab1cfb58  vmovaps xmm13, [rsp+0x20]
0000785dab1cfb5e  por xmm15, xmm13
0000785dab1cfb63  movaps [r15+0x2F0], xmm15
0000785dab1cfb6b  vmovaps xmm13, [rsp+0xA0]
0000785dab1cfb74  vpermilpd xmm13, xmm13, 0x00
0000785dab1cfb7a  vmovaps [rsp+0x20], xmm1
0000785dab1cfb80  vmovaps xmm1, [rsp+0xC0]
0000785dab1cfb89  vmovaps [rsp+0xA0], xmm15
0000785dab1cfb92  movaps xmm2, xmm1
0000785dab1cfb95  mulpd xmm2, xmm13
0000785dab1cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000785dab1cfb9f  ptest xmm15, xmm15
0000785dab1cfba5  jnz 0x0000785DAB1D1FEC
0000785dab1cfbab  lea rax, [r14+0xD0]
0000785dab1cfbb2  movups xmm1, [r13+rax*1]
0000785dab1cfbb8  vmovaps xmm13, [rsp+0xF0]
0000785dab1cfbc1  vmovaps [rsp+0xC0], xmm1
0000785dab1cfbca  vmovaps xmm1, [rsp+0xE0]
0000785dab1cfbd3  vmovaps [rsp+0xE0], xmm14
0000785dab1cfbdc  movaps xmm15, xmm13
0000785dab1cfbe0  addpd xmm15, xmm1
0000785dab1cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000785dab1cfbeb  ptest xmm14, xmm14
0000785dab1cfbf1  jnz 0x0000785DAB1D2137
0000785dab1cfbf7  vmovaps xmm1, [rsp+0xB0]
0000785dab1cfc00  vpermilpd xmm1, xmm1, 0x00
0000785dab1cfc06  movaps xmm14, xmm11
0000785dab1cfc0a  mulpd xmm14, xmm1
0000785dab1cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000785dab1cfc15  ptest xmm13, xmm13
0000785dab1cfc1b  jnz 0x0000785DAB1D227A
0000785dab1cfc21  movaps [r15+0x260], xmm14
0000785dab1cfc29  vxorps xmm1, xmm1, xmm1
0000785dab1cfc2d  vpbroadcastq xmm1, xmm1
0000785dab1cfc32  movaps [r15+0x1B0], xmm1
0000785dab1cfc3a  vmovaps xmm1, [rsp+0xB0]
0000785dab1cfc43  vpermilpd xmm1, xmm1, 0x00
0000785dab1cfc49  vmovaps xmm11, [rsp+0xC0]
0000785dab1cfc52  vmovaps [rsp+0xC0], xmm15
0000785dab1cfc5b  movaps xmm13, xmm11
0000785dab1cfc5f  mulpd xmm13, xmm1
0000785dab1cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000785dab1cfc6a  ptest xmm15, xmm15
0000785dab1cfc70  jnz 0x0000785DAB1D23BD
0000785dab1cfc76  lea rax, [r14+0xC0]
0000785dab1cfc7d  movups xmm1, [r13+rax*1]
0000785dab1cfc83  vmovaps xmm11, [rsp+0x110]
0000785dab1cfc8c  vmovaps [rsp+0xF0], xmm1
0000785dab1cfc95  vmovaps xmm1, [rsp+0x30]
0000785dab1cfc9b  vmovaps [rsp+0x30], xmm14
0000785dab1cfca1  movaps xmm15, xmm11
0000785dab1cfca5  addpd xmm15, xmm1
0000785dab1cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000785dab1cfcb0  ptest xmm14, xmm14
0000785dab1cfcb6  jnz 0x0000785DAB1D250A
0000785dab1cfcbc  vmovaps [rsp+0x100], xmm9
0000785dab1cfcc5  vmovaps xmm1, [rsp+0x100]
0000785dab1cfcce  por xmm9, xmm1
0000785dab1cfcd3  movaps [r15+0x270], xmm9
0000785dab1cfcdb  vmovaps [rsp+0x100], xmm6
0000785dab1cfce4  vmovaps xmm1, [rsp+0x100]
0000785dab1cfced  por xmm6, xmm1
0000785dab1cfcf1  movaps [r15+0x1A0], xmm6
0000785dab1cfcf9  vmovaps xmm14, [rsp+0xB0]
0000785dab1cfd02  vpermilpd xmm14, xmm14, 0x00
0000785dab1cfd08  vmovaps xmm6, [rsp+0xF0]
0000785dab1cfd11  vmovaps [rsp+0xF0], xmm1
0000785dab1cfd1a  movaps xmm11, xmm6
0000785dab1cfd1e  mulpd xmm11, xmm14
0000785dab1cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000785dab1cfd29  ptest xmm1, xmm1
0000785dab1cfd2e  jnz 0x0000785DAB1D264D
0000785dab1cfd34  lea rax, [r14+0x20]
0000785dab1cfd38  movups xmm1, [r13+rax*1]
0000785dab1cfd3e  movaps [r15+0x110], xmm1
0000785dab1cfd46  vmovaps xmm6, [rsp+0xE0]
0000785dab1cfd4f  vmovaps [rsp+0xE0], xmm1
0000785dab1cfd58  movaps xmm14, xmm6
0000785dab1cfd5c  addpd xmm14, xmm2
0000785dab1cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000785dab1cfd67  ptest xmm1, xmm1
0000785dab1cfd6c  jnz 0x0000785DAB1D279A
0000785dab1cfd72  vmovaps xmm1, [rsp+0xB0]
0000785dab1cfd7b  vpermilpd xmm1, xmm1, 0x00
0000785dab1cfd81  movaps xmm6, xmm5
0000785dab1cfd84  mulpd xmm6, xmm1
0000785dab1cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000785dab1cfd8d  ptest xmm2, xmm2
0000785dab1cfd92  jnz 0x0000785DAB1D28DC
0000785dab1cfd98  vmovaps xmm5, [rsp+0x20]
0000785dab1cfd9e  movaps xmm1, xmm5
0000785dab1cfda1  addpd xmm1, xmm13
0000785dab1cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000785dab1cfdab  ptest xmm2, xmm2
0000785dab1cfdb0  jnz 0x0000785DAB1D2A1C
0000785dab1cfdb6  vmovaps xmm13, [rsp+0x80]
0000785dab1cfdbf  vpermilpd xmm13, xmm13, 0x00
0000785dab1cfdc5  vmovaps xmm2, [rsp+0xE0]
0000785dab1cfdce  vmovaps [rsp+0x20], xmm1
0000785dab1cfdd4  movaps xmm5, xmm2
0000785dab1cfdd7  mulpd xmm5, xmm13
0000785dab1cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000785dab1cfde1  ptest xmm1, xmm1
0000785dab1cfde6  jnz 0x0000785DAB1D2B5D
0000785dab1cfdec  vmovaps xmm1, [rsp+0x80]
0000785dab1cfdf5  vpermilpd xmm1, xmm1, 0x00
0000785dab1cfdfb  movaps xmm13, xmm10
0000785dab1cfdff  mulpd xmm13, xmm1
0000785dab1cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000785dab1cfe0a  ptest xmm2, xmm2
0000785dab1cfe0f  jnz 0x0000785DAB1D2C9E
0000785dab1cfe15  vmovaps xmm10, [rsp+0x30]
0000785dab1cfe1b  movaps xmm1, xmm15
0000785dab1cfe1f  addpd xmm1, xmm10
0000785dab1cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000785dab1cfe29  ptest xmm2, xmm2
0000785dab1cfe2e  jnz 0x0000785DAB1D2DE1
0000785dab1cfe34  vmovaps xmm10, [rsp+0xC0]
0000785dab1cfe3d  movaps xmm15, xmm10
0000785dab1cfe41  addpd xmm15, xmm11
0000785dab1cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000785dab1cfe4c  ptest xmm2, xmm2
0000785dab1cfe51  jnz 0x0000785DAB1D2F23
0000785dab1cfe57  vmovaps xmm11, [rsp+0x80]
0000785dab1cfe60  vpermilpd xmm11, xmm11, 0x00
0000785dab1cfe66  movaps xmm10, xmm12
0000785dab1cfe6a  mulpd xmm10, xmm11
0000785dab1cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000785dab1cfe75  ptest xmm2, xmm2
0000785dab1cfe7a  jnz 0x0000785DAB1D3067
0000785dab1cfe80  vmovaps xmm12, [rsp+0x80]
0000785dab1cfe89  vpermilpd xmm12, xmm12, 0x00
0000785dab1cfe8f  vmovaps xmm2, [rsp+0xA0]
0000785dab1cfe98  vmovaps [rsp+0x30], xmm1
0000785dab1cfe9e  movaps xmm11, xmm2
0000785dab1cfea2  mulpd xmm11, xmm12
0000785dab1cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000785dab1cfead  ptest xmm1, xmm1
0000785dab1cfeb2  jnz 0x0000785DAB1D31AB
0000785dab1cfeb8  movaps xmm1, xmm14
0000785dab1cfebc  addpd xmm1, xmm6
0000785dab1cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000785dab1cfec5  ptest xmm12, xmm12
0000785dab1cfecb  jnz 0x0000785DAB1D32EE
0000785dab1cfed1  vmovaps xmm12, [rsp+0x20]
0000785dab1cfed7  movaps xmm14, xmm12
0000785dab1cfedb  addpd xmm14, xmm5
0000785dab1cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000785dab1cfee6  ptest xmm6, xmm6
0000785dab1cfeeb  jnz 0x0000785DAB1D342F
0000785dab1cfef1  vmovaps xmm12, [rsp+0x90]
0000785dab1cfefa  vpermilpd xmm12, xmm12, 0x00
0000785dab1cff00  movaps xmm6, xmm9
0000785dab1cff04  mulpd xmm6, xmm12
0000785dab1cff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000785dab1cff0e  ptest xmm5, xmm5
0000785dab1cff13  jnz 0x0000785DAB1D3572
0000785dab1cff19  movaps xmm12, xmm15
0000785dab1cff1d  addpd xmm12, xmm13
0000785dab1cff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000785dab1cff28  ptest xmm9, xmm9
0000785dab1cff2e  jnz 0x0000785DAB1D36B4
0000785dab1cff34  vmovaps xmm13, [rsp+0x30]
0000785dab1cff3a  movaps xmm15, xmm13
0000785dab1cff3e  addpd xmm15, xmm10
0000785dab1cff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000785dab1cff49  ptest xmm9, xmm9
0000785dab1cff4f  jnz 0x0000785DAB1D37F8
0000785dab1cff55  vmovaps xmm13, [rsp+0xD0]
0000785dab1cff5e  vmovaps xmm10, [rsp+0xD0]
0000785dab1cff67  por xmm13, xmm10
0000785dab1cff6c  movaps [r15+0x250], xmm13
0000785dab1cff74  vmovaps [rsp+0x20], xmm7
0000785dab1cff7a  vmovaps xmm13, [rsp+0x20]
0000785dab1cff80  por xmm7, xmm13
0000785dab1cff85  movaps [r15+0x2A0], xmm7
0000785dab1cff8d  vmovaps [rsp+0x20], xmm3
0000785dab1cff93  vmovaps xmm13, [rsp+0x20]
0000785dab1cff99  por xmm3, xmm13
0000785dab1cff9e  movaps [r15+0x1D0], xmm3
0000785dab1cffa6  lea rax, [r14+0x40]
0000785dab1cffaa  movups xmm13, [r13+rax*1]
0000785dab1cffb0  movaps [r15+0x2C0], xmm13
0000785dab1cffb8  vmovaps xmm10, [rsp+0x90]
0000785dab1cffc1  vpermilpd xmm10, xmm10, 0x00
0000785dab1cffc7  movaps xmm9, xmm8
0000785dab1cffcb  mulpd xmm9, xmm10
0000785dab1cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000785dab1cffd6  ptest xmm5, xmm5
0000785dab1cffdb  jnz 0x0000785DAB1D3946
0000785dab1cffe1  movaps xmm10, xmm1
0000785dab1cffe5  addpd xmm10, xmm11
0000785dab1cffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000785dab1cfff0  ptest xmm8, xmm8
0000785dab1cfff6  jnz 0x0000785DAB1D3A8A
0000785dab1cfffc  movaps xmm1, xmm14
0000785dab1d0000  addpd xmm1, xmm6
0000785dab1d0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000785dab1d0009  ptest xmm11, xmm11
0000785dab1d000f  jnz 0x0000785DAB1D3BCD
0000785dab1d0015  vmovaps xmm14, [rsp+0x90]
0000785dab1d001e  vpermilpd xmm14, xmm14, 0x00
0000785dab1d0024  movaps xmm11, xmm13
0000785dab1d0028  mulpd xmm11, xmm14
0000785dab1d002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000785dab1d0033  ptest xmm8, xmm8
0000785dab1d0039  jnz 0x0000785DAB1D3D0E
0000785dab1d003f  vmovaps xmm14, [rsp+0x90]
0000785dab1d0048  vpermilpd xmm14, xmm14, 0x00
0000785dab1d004e  vmovaps xmm8, [rsp+0x10]
0000785dab1d0054  movaps xmm13, xmm8
0000785dab1d0058  mulpd xmm13, xmm14
0000785dab1d005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000785dab1d0063  ptest xmm6, xmm6
0000785dab1d0068  jnz 0x0000785DAB1D3E52
0000785dab1d006e  vmovaps xmm14, [rsp+0x60]
0000785dab1d0074  vpermilpd xmm14, xmm14, 0x00
0000785dab1d007a  movaps xmm8, xmm7
0000785dab1d007e  mulpd xmm8, xmm14
0000785dab1d0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000785dab1d0089  ptest xmm6, xmm6
0000785dab1d008e  jnz 0x0000785DAB1D3F96
0000785dab1d0094  movaps xmm14, xmm12
0000785dab1d0098  addpd xmm14, xmm9
0000785dab1d009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000785dab1d00a3  ptest xmm7, xmm7
0000785dab1d00a8  jnz 0x0000785DAB1D40D9
0000785dab1d00ae  vmovaps xmm12, [rsp+0x60]
0000785dab1d00b4  vpermilpd xmm12, xmm12, 0x00
0000785dab1d00ba  vmovaps xmm7, [rsp+0xF0]
0000785dab1d00c3  movaps xmm9, xmm7
0000785dab1d00c7  mulpd xmm9, xmm12
0000785dab1d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000785dab1d00d2  ptest xmm6, xmm6
0000785dab1d00d7  jnz 0x0000785DAB1D421D
0000785dab1d00dd  movaps xmm12, xmm15
0000785dab1d00e1  addpd xmm12, xmm11
0000785dab1d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000785dab1d00ec  ptest xmm7, xmm7
0000785dab1d00f1  jnz 0x0000785DAB1D4360
0000785dab1d00f7  vmovaps xmm15, [rsp+0x60]
0000785dab1d00fd  vpermilpd xmm15, xmm15, 0x00
0000785dab1d0103  vmovaps xmm7, [rsp+0x40]
0000785dab1d0109  movaps xmm11, xmm7
0000785dab1d010d  mulpd xmm11, xmm15
0000785dab1d0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000785dab1d0118  ptest xmm6, xmm6
0000785dab1d011d  jnz 0x0000785DAB1D44A4
0000785dab1d0123  movaps xmm15, xmm10
0000785dab1d0127  addpd xmm15, xmm13
0000785dab1d012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000785dab1d0132  ptest xmm7, xmm7
0000785dab1d0137  jnz 0x0000785DAB1D45E7
0000785dab1d013d  vmovaps xmm13, [rsp+0x60]
0000785dab1d0143  vpermilpd xmm13, xmm13, 0x00
0000785dab1d0149  vmovaps xmm7, [rsp+0x50]
0000785dab1d014f  movaps xmm10, xmm7
0000785dab1d0153  mulpd xmm10, xmm13
0000785dab1d0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000785dab1d015e  ptest xmm6, xmm6
0000785dab1d0163  jnz 0x0000785DAB1D472B
0000785dab1d0169  movaps xmm13, xmm1
0000785dab1d016d  addpd xmm13, xmm8
0000785dab1d0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000785dab1d0178  ptest xmm7, xmm7
0000785dab1d017d  jnz 0x0000785DAB1D486E
0000785dab1d0183  lea rax, [r14+0x70]
0000785dab1d0187  movups xmm1, [r13+rax*1]
0000785dab1d018d  movaps [r15+0x240], xmm1
0000785dab1d0195  movaps xmm8, xmm14
0000785dab1d0199  addpd xmm8, xmm9
0000785dab1d019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000785dab1d01a4  ptest xmm7, xmm7
0000785dab1d01a9  jnz 0x0000785DAB1D49BB
0000785dab1d01af  movaps [r15+0x170], xmm8
0000785dab1d01b7  vmovaps xmm14, [rsp+0x70]
0000785dab1d01bd  vpermilpd xmm14, xmm14, 0x00
0000785dab1d01c3  movaps xmm9, xmm1
0000785dab1d01c7  mulpd xmm9, xmm14
0000785dab1d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000785dab1d01d2  ptest xmm7, xmm7
0000785dab1d01d7  jnz 0x0000785DAB1D4AFF
0000785dab1d01dd  vmovaps xmm1, [rsp+0x70]
0000785dab1d01e3  vpermilpd xmm1, xmm1, 0x00
0000785dab1d01e9  movaps xmm14, xmm4
0000785dab1d01ed  mulpd xmm14, xmm1
0000785dab1d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000785dab1d01f8  ptest xmm7, xmm7
0000785dab1d01fd  jnz 0x0000785DAB1D4C42
0000785dab1d0203  movaps [r15+0x180], xmm14
0000785dab1d020b  movaps xmm1, xmm12
0000785dab1d020f  addpd xmm1, xmm11
0000785dab1d0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000785dab1d0219  ptest xmm7, xmm7
0000785dab1d021e  jnz 0x0000785DAB1D4D84
0000785dab1d0224  movaps [r15+0x210], xmm1
0000785dab1d022c  movups xmm12, [r13+r14*1]
0000785dab1d0232  lea rax, [r14+0x10]
0000785dab1d0236  movups xmm11, [r13+rax*1]
0000785dab1d023c  movaps [r15+0x230], xmm11
0000785dab1d0244  movaps xmm7, xmm15
0000785dab1d0248  addpd xmm7, xmm10
0000785dab1d024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000785dab1d0252  ptest xmm6, xmm6
0000785dab1d0257  jnz 0x0000785DAB1D4EDA
0000785dab1d025d  movaps [r15+0x130], xmm7
0000785dab1d0265  vmovaps xmm15, [rsp+0x70]
0000785dab1d026b  vpermilpd xmm15, xmm15, 0x00
0000785dab1d0271  movaps xmm10, xmm11
0000785dab1d0275  mulpd xmm10, xmm15
0000785dab1d027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000785dab1d0280  ptest xmm6, xmm6
0000785dab1d0285  jnz 0x0000785DAB1D501C
0000785dab1d028b  movaps [r15+0x220], xmm10
0000785dab1d0293  vmovaps xmm15, [rsp+0x70]
0000785dab1d0299  vpermilpd xmm15, xmm15, 0x00
0000785dab1d029f  movaps xmm11, xmm12
0000785dab1d02a3  mulpd xmm11, xmm15
0000785dab1d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000785dab1d02ae  ptest xmm6, xmm6
0000785dab1d02b3  jnz 0x0000785DAB1D5160
0000785dab1d02b9  movaps xmm15, xmm13
0000785dab1d02bd  addpd xmm15, xmm9
0000785dab1d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000785dab1d02c8  ptest xmm12, xmm12
0000785dab1d02ce  jnz 0x0000785DAB1D52A4
0000785dab1d02d4  movaps [r15+0x140], xmm15
0000785dab1d02dc  movaps xmm13, xmm8
0000785dab1d02e0  addpd xmm13, xmm14
0000785dab1d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000785dab1d02eb  ptest xmm12, xmm12
0000785dab1d02f1  jnz 0x0000785DAB1D53E8
0000785dab1d02f7  movaps [r15+0x150], xmm13
0000785dab1d02ff  movaps xmm14, xmm1
0000785dab1d0303  addpd xmm14, xmm10
0000785dab1d0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000785dab1d030e  ptest xmm12, xmm12
0000785dab1d0314  jnz 0x0000785DAB1D552C
0000785dab1d031a  movaps [r15+0x160], xmm14
0000785dab1d0322  movaps xmm1, xmm7
0000785dab1d0325  addpd xmm1, xmm11
0000785dab1d032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000785dab1d032f  ptest xmm12, xmm12
0000785dab1d0335  jnz 0x0000785DAB1D566F
0000785dab1d033b  movaps [r15+0x120], xmm1
0000785dab1d0343  mov eax, 0x430920
0000785dab1d0348  movups [r13+rax*1], xmm15
0000785dab1d034e  mov eax, 0x430930
0000785dab1d0353  movups [r13+rax*1], xmm13
0000785dab1d0359  mov eax, 0x430940
0000785dab1d035e  movups [r13+rax*1], xmm14
0000785dab1d0364  mov eax, 0x430950
0000785dab1d0369  movups [r13+rax*1], xmm1
0000785dab1d036f  mov eax, [r15+0x108]
0000785dab1d0376  sahf
0000785dab1d0377  jnz 0x0000785DAB1D03A9
0000785dab1d0379  cmp dword ptr [r15+0x318], 0x00
0000785dab1d0381  jz 0x0000785DAB1DB900
0000785dab1d0387  nop [rax+rax*1], ax
0000785dab1d0390  nop [rax+rax*1], eax
0000785dab1d0398  mov eax, 0x410444
0000785dab1d039d  mov [r15+0x100], rax
0000785dab1d03a4  jmp 0x0000785DAAFFE110
0000785dab1d03a9  cmp dword ptr [r15+0x318], 0x00
0000785dab1d03b1  jz 0x0000785DAB1D57E0
0000785dab1d03b7  nop [rax+rax*1], ax
0000785dab1d03c0  nop [rax+rax*1], eax
0000785dab1d03c8  mov eax, 0x410278
0000785dab1d03cd  mov [r15+0x100], rax
0000785dab1d03d4  jmp 0x0000785DAAFFE110
0000785dab1d03d9  int3
0000785dab1d03da  call 0x0000785DAB0B52F0
0000785dab1d03df  jmp 0x0000785DAB1CF016
0000785dab1d03e4  call 0x0000785DAB0C4620
0000785dab1d03e9  jmp 0x0000785DAB1CF023
0000785dab1d03ee  call 0x0000785DAB0C33A0
0000785dab1d03f3  jmp 0x0000785DAB1CF035
0000785dab1d03f8  call 0x0000785DAB0C2120
0000785dab1d03fd  jmp 0x0000785DAB1CF03F
0000785dab1d0402  call 0x0000785DAB0C0860
0000785dab1d0407  jmp 0x0000785DAB1CF067
0000785dab1d040c  call 0x0000785DAB0BF5F0
0000785dab1d0411  jmp 0x0000785DAB1CF073
0000785dab1d0416  call 0x0000785DAB0C0860
0000785dab1d041b  jmp 0x0000785DAB1CF0A5
0000785dab1d0420  call 0x0000785DAB0BF5F0
0000785dab1d0425  jmp 0x0000785DAB1CF0B1
0000785dab1d042a  call 0x0000785DAB0C4740
0000785dab1d042f  jmp 0x0000785DAB1CF0BE
0000785dab1d0434  call 0x0000785DAB0B5400
0000785dab1d0439  jmp 0x0000785DAB1CF0CB
0000785dab1d043e  call 0x0000785DAB0B52F0
0000785dab1d0443  jmp 0x0000785DAB1CF0D8
0000785dab1d0448  call 0x0000785DAB0C4620
0000785dab1d044d  jmp 0x0000785DAB1CF0E5
0000785dab1d0452  call 0x0000785DAB0C0860
0000785dab1d0457  jmp 0x0000785DAB1CF10D
0000785dab1d045c  call 0x0000785DAB0BF5F0
0000785dab1d0461  jmp 0x0000785DAB1CF119
0000785dab1d0466  call 0x0000785DAB009D70
0000785dab1d046b  jmp 0x0000785DAB1CF11F
0000785dab1d0470  call 0x0000785DAB0BE9C0
0000785dab1d0475  jmp 0x0000785DAB1CF129
0000785dab1d047a  call 0x0000785DAB0C0860
0000785dab1d047f  jmp 0x0000785DAB1CF151
0000785dab1d0484  call 0x0000785DAB0BF5F0
0000785dab1d0489  jmp 0x0000785DAB1CF15D
0000785dab1d048e  call 0x0000785DAB0BD750
0000785dab1d0493  jmp 0x0000785DAB1CF16A
0000785dab1d0498  call 0x0000785DAB0BC4E0
0000785dab1d049d  jmp 0x0000785DAB1CF177
0000785dab1d04a2  call 0x0000785DAB0C4740
0000785dab1d04a7  jmp 0x0000785DAB1CF184
0000785dab1d04ac  call 0x0000785DAB0B5400
0000785dab1d04b1  jmp 0x0000785DAB1CF191
0000785dab1d04b6  call 0x0000785DAB0B52F0
0000785dab1d04bb  jmp 0x0000785DAB1CF19E
0000785dab1d04c0  call 0x0000785DAB0C4620
0000785dab1d04c5  jmp 0x0000785DAB1CF1AB
0000785dab1d04ca  call 0x0000785DAB0C0860
0000785dab1d04cf  jmp 0x0000785DAB1CF1BE
0000785dab1d04d4  call 0x0000785DAB0BB270
0000785dab1d04d9  jmp 0x0000785DAB1CF1CB
0000785dab1d04de  call 0x0000785DAB0BA000
0000785dab1d04e3  jmp 0x0000785DAB1CF1D8
0000785dab1d04e8  call 0x0000785DAB0B8D90
0000785dab1d04ed  jmp 0x0000785DAB1CF1E5
0000785dab1d04f2  call 0x0000785DAB0B8A20
0000785dab1d04f7  jmp 0x0000785DAB1CF1F2
0000785dab1d04fc  call 0x0000785DAB0B5400
0000785dab1d0501  jmp 0x0000785DAB1CF1FC
0000785dab1d0506  call 0x0000785DAB0C2240
0000785dab1d050b  jmp 0x0000785DAB1CF206
0000785dab1d0510  call 0x0000785DAB0B52F0
0000785dab1d0515  jmp 0x0000785DAB1CF210
0000785dab1d051a  call 0x0000785DAB0C2120
0000785dab1d051f  jmp 0x0000785DAB1CF21A
0000785dab1d0524  call 0x0000785DAB0B77B0
0000785dab1d0529  jmp 0x0000785DAB1CF224
0000785dab1d052e  call 0x0000785DAB0B6550
0000785dab1d0533  jmp 0x0000785DAB1CF22E
0000785dab1d0538  call 0x0000785DAB0BFD50
0000785dab1d053d  jmp 0x0000785DAB1CF240
0000785dab1d0542  call 0x0000785DAB0B8EA0
0000785dab1d0547  jmp 0x0000785DAB1CF24A
0000785dab1d054c  call 0x0000785DAB0BFC30
0000785dab1d0551  jmp 0x0000785DAB1CF257
0000785dab1d0556  call 0x0000785DAB0B8D90
0000785dab1d055b  jmp 0x0000785DAB1CF264
0000785dab1d0560  call 0x0000785DAB0C2240
0000785dab1d0565  jmp 0x0000785DAB1CF271
0000785dab1d056a  call 0x0000785DAB0B5400
0000785dab1d056f  jmp 0x0000785DAB1CF27E
0000785dab1d0574  call 0x0000785DAB0B52F0
0000785dab1d0579  jmp 0x0000785DAB1CF28B
0000785dab1d057e  call 0x0000785DAB0C2120
0000785dab1d0583  jmp 0x0000785DAB1CF298
0000785dab1d0588  call 0x0000785DAB0B52F0
0000785dab1d058d  jmp 0x0000785DAB1CF2AB
0000785dab1d0592  call 0x0000785DAB0B52F0
0000785dab1d0597  jmp 0x0000785DAB1CF2BE
0000785dab1d059c  call 0x0000785DAB0B52F0
0000785dab1d05a1  jmp 0x0000785DAB1CF2D1
0000785dab1d05a6  call 0x0000785DAB0B52F0
0000785dab1d05ab  jmp 0x0000785DAB1CF2E4
0000785dab1d05b0  call 0x0000785DAB0C2240
0000785dab1d05b5  jmp 0x0000785DAB1CF2F9
0000785dab1d05ba  call 0x0000785DAB0C2240
0000785dab1d05bf  jmp 0x0000785DAB1CF30C
0000785dab1d05c4  call 0x0000785DAB0C2120
0000785dab1d05c9  jmp 0x0000785DAB1CF319
0000785dab1d05ce  call 0x0000785DAB0B52F0
0000785dab1d05d3  jmp 0x0000785DAB1CF32C
0000785dab1d05d8  call 0x0000785DAB0B52F0
0000785dab1d05dd  jmp 0x0000785DAB1CF34F
0000785dab1d05e2  call 0x0000785DAB0B52F0
0000785dab1d05e7  jmp 0x0000785DAB1CF362
0000785dab1d05ec  call 0x0000785DAAFFF540
0000785dab1d05f1  jmp 0x0000785DAB1CF380
0000785dab1d05f6  call 0x0000785DAB008C20
0000785dab1d05fb  jmp 0x0000785DAB1CF38A
0000785dab1d0600  call 0x0000785DAB0D6600
0000785dab1d0605  jmp 0x0000785DAB1CF396
0000785dab1d060a  call 0x0000785DAAFFF540
0000785dab1d060f  jmp 0x0000785DAB1CF3A6
0000785dab1d0614  call 0x0000785DAB0C0370
0000785dab1d0619  jmp 0x0000785DAB1CF3D4
0000785dab1d061e  call 0x0000785DAB0BF100
0000785dab1d0623  jmp 0x0000785DAB1CF3DD
0000785dab1d0628  call 0x0000785DAB0C0370
0000785dab1d062d  jmp 0x0000785DAB1CF43B
0000785dab1d0632  call 0x0000785DAB0BF100
0000785dab1d0637  jmp 0x0000785DAB1CF444
0000785dab1d063c  call 0x0000785DAB0C0370
0000785dab1d0641  jmp 0x0000785DAB1CF48B
0000785dab1d0646  call 0x0000785DAB0BF100
0000785dab1d064b  jmp 0x0000785DAB1CF494
0000785dab1d0650  call 0x0000785DAB00B720
0000785dab1d0655  jmp 0x0000785DAB1CF4D7
0000785dab1d065a  call 0x0000785DAB0B47C0
0000785dab1d065f  jmp 0x0000785DAB1CF4EA
0000785dab1d0664  call 0x0000785DAB008B00
0000785dab1d0669  jmp 0x0000785DAB1CF501
0000785dab1d066e  call 0x0000785DAAFFF430
0000785dab1d0673  jmp 0x0000785DAB1CF514
0000785dab1d0678  call 0x0000785DAAFFF430
0000785dab1d067d  jmp 0x0000785DAB1CF527
0000785dab1d0682  sub rsp, 0x08
0000785dab1d0686  push rax
0000785dab1d0687  push rcx
0000785dab1d0688  push rdx
0000785dab1d0689  push rdi
0000785dab1d068a  push rsi
0000785dab1d068b  push r8
0000785dab1d068d  push r9
0000785dab1d068f  push r10
0000785dab1d0691  push r11
0000785dab1d0693  sub rsp, 0xF0
0000785dab1d069a  vmovaps [rsp], xmm0
0000785dab1d069f  vmovaps [rsp+0x10], xmm2
0000785dab1d06a5  vmovaps [rsp+0x20], xmm3
0000785dab1d06ab  vmovaps [rsp+0x30], xmm4
0000785dab1d06b1  vmovaps [rsp+0x40], xmm5
0000785dab1d06b7  vmovaps [rsp+0x50], xmm6
0000785dab1d06bd  vmovaps [rsp+0x60], xmm7
0000785dab1d06c3  vmovaps [rsp+0x70], xmm8
0000785dab1d06c9  vmovaps [rsp+0x80], xmm9
0000785dab1d06d2  vmovaps [rsp+0x90], xmm10
0000785dab1d06db  vmovaps [rsp+0xA0], xmm11
0000785dab1d06e4  vmovaps [rsp+0xB0], xmm12
0000785dab1d06ed  vmovaps [rsp+0xC0], xmm13
0000785dab1d06f6  vmovaps [rsp+0xD0], xmm14
0000785dab1d06ff  vmovaps [rsp+0xE0], xmm15
0000785dab1d0708  sub rsp, 0x30
0000785dab1d070c  movaps [rsp], xmm1
0000785dab1d0710  movaps [rsp+0x10], xmm15
0000785dab1d0716  movaps [rsp+0x20], xmm14
0000785dab1d071c  lea rdi, [rsp]
0000785dab1d0720  mov esi, 0x00
0000785dab1d0725  mov rax, 0x61B13BBD6530
0000785dab1d072f  call rax
0000785dab1d0731  movaps xmm1, [rsp]
0000785dab1d0735  add rsp, 0x30
0000785dab1d0739  vmovaps xmm0, [rsp]
0000785dab1d073e  vmovaps xmm2, [rsp+0x10]
0000785dab1d0744  vmovaps xmm3, [rsp+0x20]
0000785dab1d074a  vmovaps xmm4, [rsp+0x30]
0000785dab1d0750  vmovaps xmm5, [rsp+0x40]
0000785dab1d0756  vmovaps xmm6, [rsp+0x50]
0000785dab1d075c  vmovaps xmm7, [rsp+0x60]
0000785dab1d0762  vmovaps xmm8, [rsp+0x70]
0000785dab1d0768  vmovaps xmm9, [rsp+0x80]
0000785dab1d0771  vmovaps xmm10, [rsp+0x90]
0000785dab1d077a  vmovaps xmm11, [rsp+0xA0]
0000785dab1d0783  vmovaps xmm12, [rsp+0xB0]
0000785dab1d078c  vmovaps xmm13, [rsp+0xC0]
0000785dab1d0795  vmovaps xmm14, [rsp+0xD0]
0000785dab1d079e  vmovaps xmm15, [rsp+0xE0]
0000785dab1d07a7  add rsp, 0xF0
0000785dab1d07ae  pop r11
0000785dab1d07b0  pop r10
0000785dab1d07b2  pop r9
0000785dab1d07b4  pop r8
0000785dab1d07b6  pop rsi
0000785dab1d07b7  pop rdi
0000785dab1d07b8  pop rdx
0000785dab1d07b9  pop rcx
0000785dab1d07ba  pop rax
0000785dab1d07bb  add rsp, 0x08
0000785dab1d07bf  jmp 0x0000785DAB1CF581
0000785dab1d07c4  sub rsp, 0x08
0000785dab1d07c8  push rax
0000785dab1d07c9  push rcx
0000785dab1d07ca  push rdx
0000785dab1d07cb  push rdi
0000785dab1d07cc  push rsi
0000785dab1d07cd  push r8
0000785dab1d07cf  push r9
0000785dab1d07d1  push r10
0000785dab1d07d3  push r11
0000785dab1d07d5  sub rsp, 0xF0
0000785dab1d07dc  vmovaps [rsp], xmm0
0000785dab1d07e1  vmovaps [rsp+0x10], xmm1
0000785dab1d07e7  vmovaps [rsp+0x20], xmm2
0000785dab1d07ed  vmovaps [rsp+0x30], xmm3
0000785dab1d07f3  vmovaps [rsp+0x40], xmm4
0000785dab1d07f9  vmovaps [rsp+0x50], xmm5
0000785dab1d07ff  vmovaps [rsp+0x60], xmm6
0000785dab1d0805  vmovaps [rsp+0x70], xmm7
0000785dab1d080b  vmovaps [rsp+0x80], xmm8
0000785dab1d0814  vmovaps [rsp+0x90], xmm9
0000785dab1d081d  vmovaps [rsp+0xA0], xmm10
0000785dab1d0826  vmovaps [rsp+0xB0], xmm11
0000785dab1d082f  vmovaps [rsp+0xC0], xmm12
0000785dab1d0838  vmovaps [rsp+0xD0], xmm14
0000785dab1d0841  vmovaps [rsp+0xE0], xmm15
0000785dab1d084a  sub rsp, 0x30
0000785dab1d084e  movaps [rsp], xmm13
0000785dab1d0853  movaps [rsp+0x10], xmm1
0000785dab1d0858  movaps [rsp+0x20], xmm14
0000785dab1d085e  lea rdi, [rsp]
0000785dab1d0862  mov esi, 0x00
0000785dab1d0867  mov rax, 0x61B13BBD6530
0000785dab1d0871  call rax
0000785dab1d0873  movaps xmm13, [rsp]
0000785dab1d0878  add rsp, 0x30
0000785dab1d087c  vmovaps xmm0, [rsp]
0000785dab1d0881  vmovaps xmm1, [rsp+0x10]
0000785dab1d0887  vmovaps xmm2, [rsp+0x20]
0000785dab1d088d  vmovaps xmm3, [rsp+0x30]
0000785dab1d0893  vmovaps xmm4, [rsp+0x40]
0000785dab1d0899  vmovaps xmm5, [rsp+0x50]
0000785dab1d089f  vmovaps xmm6, [rsp+0x60]
0000785dab1d08a5  vmovaps xmm7, [rsp+0x70]
0000785dab1d08ab  vmovaps xmm8, [rsp+0x80]
0000785dab1d08b4  vmovaps xmm9, [rsp+0x90]
0000785dab1d08bd  vmovaps xmm10, [rsp+0xA0]
0000785dab1d08c6  vmovaps xmm11, [rsp+0xB0]
0000785dab1d08cf  vmovaps xmm12, [rsp+0xC0]
0000785dab1d08d8  vmovaps xmm14, [rsp+0xD0]
0000785dab1d08e1  vmovaps xmm15, [rsp+0xE0]
0000785dab1d08ea  add rsp, 0xF0
0000785dab1d08f1  pop r11
0000785dab1d08f3  pop r10
0000785dab1d08f5  pop r9
0000785dab1d08f7  pop r8
0000785dab1d08f9  pop rsi
0000785dab1d08fa  pop rdi
0000785dab1d08fb  pop rdx
0000785dab1d08fc  pop rcx
0000785dab1d08fd  pop rax
0000785dab1d08fe  add rsp, 0x08
0000785dab1d0902  jmp 0x0000785DAB1CF5CF
0000785dab1d0907  sub rsp, 0x08
0000785dab1d090b  push rax
0000785dab1d090c  push rcx
0000785dab1d090d  push rdx
0000785dab1d090e  push rdi
0000785dab1d090f  push rsi
0000785dab1d0910  push r8
0000785dab1d0912  push r9
0000785dab1d0914  push r10
0000785dab1d0916  push r11
0000785dab1d0918  sub rsp, 0xF0
0000785dab1d091f  vmovaps [rsp], xmm0
0000785dab1d0924  vmovaps [rsp+0x10], xmm1
0000785dab1d092a  vmovaps [rsp+0x20], xmm2
0000785dab1d0930  vmovaps [rsp+0x30], xmm3
0000785dab1d0936  vmovaps [rsp+0x40], xmm4
0000785dab1d093c  vmovaps [rsp+0x50], xmm5
0000785dab1d0942  vmovaps [rsp+0x60], xmm6
0000785dab1d0948  vmovaps [rsp+0x70], xmm7
0000785dab1d094e  vmovaps [rsp+0x80], xmm8
0000785dab1d0957  vmovaps [rsp+0x90], xmm9
0000785dab1d0960  vmovaps [rsp+0xA0], xmm10
0000785dab1d0969  vmovaps [rsp+0xB0], xmm11
0000785dab1d0972  vmovaps [rsp+0xC0], xmm12
0000785dab1d097b  vmovaps [rsp+0xD0], xmm13
0000785dab1d0984  vmovaps [rsp+0xE0], xmm14
0000785dab1d098d  sub rsp, 0x30
0000785dab1d0991  movaps [rsp], xmm15
0000785dab1d0996  movaps [rsp+0x10], xmm14
0000785dab1d099c  movaps [rsp+0x20], xmm1
0000785dab1d09a1  lea rdi, [rsp]
0000785dab1d09a5  mov esi, 0x00
0000785dab1d09aa  mov rax, 0x61B13BBD6530
0000785dab1d09b4  call rax
0000785dab1d09b6  movaps xmm15, [rsp]
0000785dab1d09bb  add rsp, 0x30
0000785dab1d09bf  vmovaps xmm0, [rsp]
0000785dab1d09c4  vmovaps xmm1, [rsp+0x10]
0000785dab1d09ca  vmovaps xmm2, [rsp+0x20]
0000785dab1d09d0  vmovaps xmm3, [rsp+0x30]
0000785dab1d09d6  vmovaps xmm4, [rsp+0x40]
0000785dab1d09dc  vmovaps xmm5, [rsp+0x50]
0000785dab1d09e2  vmovaps xmm6, [rsp+0x60]
0000785dab1d09e8  vmovaps xmm7, [rsp+0x70]
0000785dab1d09ee  vmovaps xmm8, [rsp+0x80]
0000785dab1d09f7  vmovaps xmm9, [rsp+0x90]
0000785dab1d0a00  vmovaps xmm10, [rsp+0xA0]
0000785dab1d0a09  vmovaps xmm11, [rsp+0xB0]
0000785dab1d0a12  vmovaps xmm12, [rsp+0xC0]
0000785dab1d0a1b  vmovaps xmm13, [rsp+0xD0]
0000785dab1d0a24  vmovaps xmm14, [rsp+0xE0]
0000785dab1d0a2d  add rsp, 0xF0
0000785dab1d0a34  pop r11
0000785dab1d0a36  pop r10
0000785dab1d0a38  pop r9
0000785dab1d0a3a  pop r8
0000785dab1d0a3c  pop rsi
0000785dab1d0a3d  pop rdi
0000785dab1d0a3e  pop rdx
0000785dab1d0a3f  pop rcx
0000785dab1d0a40  pop rax
0000785dab1d0a41  add rsp, 0x08
0000785dab1d0a45  jmp 0x0000785DAB1CF617
0000785dab1d0a4a  sub rsp, 0x08
0000785dab1d0a4e  push rax
0000785dab1d0a4f  push rcx
0000785dab1d0a50  push rdx
0000785dab1d0a51  push rdi
0000785dab1d0a52  push rsi
0000785dab1d0a53  push r8
0000785dab1d0a55  push r9
0000785dab1d0a57  push r10
0000785dab1d0a59  push r11
0000785dab1d0a5b  sub rsp, 0xF0
0000785dab1d0a62  vmovaps [rsp], xmm0
0000785dab1d0a67  vmovaps [rsp+0x10], xmm2
0000785dab1d0a6d  vmovaps [rsp+0x20], xmm3
0000785dab1d0a73  vmovaps [rsp+0x30], xmm4
0000785dab1d0a79  vmovaps [rsp+0x40], xmm5
0000785dab1d0a7f  vmovaps [rsp+0x50], xmm6
0000785dab1d0a85  vmovaps [rsp+0x60], xmm7
0000785dab1d0a8b  vmovaps [rsp+0x70], xmm8
0000785dab1d0a91  vmovaps [rsp+0x80], xmm9
0000785dab1d0a9a  vmovaps [rsp+0x90], xmm10
0000785dab1d0aa3  vmovaps [rsp+0xA0], xmm11
0000785dab1d0aac  vmovaps [rsp+0xB0], xmm12
0000785dab1d0ab5  vmovaps [rsp+0xC0], xmm13
0000785dab1d0abe  vmovaps [rsp+0xD0], xmm14
0000785dab1d0ac7  vmovaps [rsp+0xE0], xmm15
0000785dab1d0ad0  sub rsp, 0x30
0000785dab1d0ad4  movaps [rsp], xmm1
0000785dab1d0ad8  movaps [rsp+0x10], xmm14
0000785dab1d0ade  movaps [rsp+0x20], xmm10
0000785dab1d0ae4  lea rdi, [rsp]
0000785dab1d0ae8  mov esi, 0x00
0000785dab1d0aed  mov rax, 0x61B13BBD6530
0000785dab1d0af7  call rax
0000785dab1d0af9  movaps xmm1, [rsp]
0000785dab1d0afd  add rsp, 0x30
0000785dab1d0b01  vmovaps xmm0, [rsp]
0000785dab1d0b06  vmovaps xmm2, [rsp+0x10]
0000785dab1d0b0c  vmovaps xmm3, [rsp+0x20]
0000785dab1d0b12  vmovaps xmm4, [rsp+0x30]
0000785dab1d0b18  vmovaps xmm5, [rsp+0x40]
0000785dab1d0b1e  vmovaps xmm6, [rsp+0x50]
0000785dab1d0b24  vmovaps xmm7, [rsp+0x60]
0000785dab1d0b2a  vmovaps xmm8, [rsp+0x70]
0000785dab1d0b30  vmovaps xmm9, [rsp+0x80]
0000785dab1d0b39  vmovaps xmm10, [rsp+0x90]
0000785dab1d0b42  vmovaps xmm11, [rsp+0xA0]
0000785dab1d0b4b  vmovaps xmm12, [rsp+0xB0]
0000785dab1d0b54  vmovaps xmm13, [rsp+0xC0]
0000785dab1d0b5d  vmovaps xmm14, [rsp+0xD0]
0000785dab1d0b66  vmovaps xmm15, [rsp+0xE0]
0000785dab1d0b6f  add rsp, 0xF0
0000785dab1d0b76  pop r11
0000785dab1d0b78  pop r10
0000785dab1d0b7a  pop r9
0000785dab1d0b7c  pop r8
0000785dab1d0b7e  pop rsi
0000785dab1d0b7f  pop rdi
0000785dab1d0b80  pop rdx
0000785dab1d0b81  pop rcx
0000785dab1d0b82  pop rax
0000785dab1d0b83  add rsp, 0x08
0000785dab1d0b87  jmp 0x0000785DAB1CF631
0000785dab1d0b8c  sub rsp, 0x08
0000785dab1d0b90  push rax
0000785dab1d0b91  push rcx
0000785dab1d0b92  push rdx
0000785dab1d0b93  push rdi
0000785dab1d0b94  push rsi
0000785dab1d0b95  push r8
0000785dab1d0b97  push r9
0000785dab1d0b99  push r10
0000785dab1d0b9b  push r11
0000785dab1d0b9d  sub rsp, 0xF0
0000785dab1d0ba4  vmovaps [rsp], xmm0
0000785dab1d0ba9  vmovaps [rsp+0x10], xmm1
0000785dab1d0baf  vmovaps [rsp+0x20], xmm2
0000785dab1d0bb5  vmovaps [rsp+0x30], xmm3
0000785dab1d0bbb  vmovaps [rsp+0x40], xmm4
0000785dab1d0bc1  vmovaps [rsp+0x50], xmm5
0000785dab1d0bc7  vmovaps [rsp+0x60], xmm6
0000785dab1d0bcd  vmovaps [rsp+0x70], xmm7
0000785dab1d0bd3  vmovaps [rsp+0x80], xmm8
0000785dab1d0bdc  vmovaps [rsp+0x90], xmm9
0000785dab1d0be5  vmovaps [rsp+0xA0], xmm10
0000785dab1d0bee  vmovaps [rsp+0xB0], xmm11
0000785dab1d0bf7  vmovaps [rsp+0xC0], xmm12
0000785dab1d0c00  vmovaps [rsp+0xD0], xmm14
0000785dab1d0c09  vmovaps [rsp+0xE0], xmm15
0000785dab1d0c12  sub rsp, 0x30
0000785dab1d0c16  movaps [rsp], xmm13
0000785dab1d0c1b  movaps [rsp+0x10], xmm14
0000785dab1d0c21  movaps [rsp+0x20], xmm2
0000785dab1d0c26  lea rdi, [rsp]
0000785dab1d0c2a  mov esi, 0x00
0000785dab1d0c2f  mov rax, 0x61B13BBD6530
0000785dab1d0c39  call rax
0000785dab1d0c3b  movaps xmm13, [rsp]
0000785dab1d0c40  add rsp, 0x30
0000785dab1d0c44  vmovaps xmm0, [rsp]
0000785dab1d0c49  vmovaps xmm1, [rsp+0x10]
0000785dab1d0c4f  vmovaps xmm2, [rsp+0x20]
0000785dab1d0c55  vmovaps xmm3, [rsp+0x30]
0000785dab1d0c5b  vmovaps xmm4, [rsp+0x40]
0000785dab1d0c61  vmovaps xmm5, [rsp+0x50]
0000785dab1d0c67  vmovaps xmm6, [rsp+0x60]
0000785dab1d0c6d  vmovaps xmm7, [rsp+0x70]
0000785dab1d0c73  vmovaps xmm8, [rsp+0x80]
0000785dab1d0c7c  vmovaps xmm9, [rsp+0x90]
0000785dab1d0c85  vmovaps xmm10, [rsp+0xA0]
0000785dab1d0c8e  vmovaps xmm11, [rsp+0xB0]
0000785dab1d0c97  vmovaps xmm12, [rsp+0xC0]
0000785dab1d0ca0  vmovaps xmm14, [rsp+0xD0]
0000785dab1d0ca9  vmovaps xmm15, [rsp+0xE0]
0000785dab1d0cb2  add rsp, 0xF0
0000785dab1d0cb9  pop r11
0000785dab1d0cbb  pop r10
0000785dab1d0cbd  pop r9
0000785dab1d0cbf  pop r8
0000785dab1d0cc1  pop rsi
0000785dab1d0cc2  pop rdi
0000785dab1d0cc3  pop rdx
0000785dab1d0cc4  pop rcx
0000785dab1d0cc5  pop rax
0000785dab1d0cc6  add rsp, 0x08
0000785dab1d0cca  jmp 0x0000785DAB1CF64C
0000785dab1d0ccf  sub rsp, 0x08
0000785dab1d0cd3  push rax
0000785dab1d0cd4  push rcx
0000785dab1d0cd5  push rdx
0000785dab1d0cd6  push rdi
0000785dab1d0cd7  push rsi
0000785dab1d0cd8  push r8
0000785dab1d0cda  push r9
0000785dab1d0cdc  push r10
0000785dab1d0cde  push r11
0000785dab1d0ce0  sub rsp, 0xF0
0000785dab1d0ce7  vmovaps [rsp], xmm0
0000785dab1d0cec  vmovaps [rsp+0x10], xmm2
0000785dab1d0cf2  vmovaps [rsp+0x20], xmm3
0000785dab1d0cf8  vmovaps [rsp+0x30], xmm4
0000785dab1d0cfe  vmovaps [rsp+0x40], xmm5
0000785dab1d0d04  vmovaps [rsp+0x50], xmm6
0000785dab1d0d0a  vmovaps [rsp+0x60], xmm7
0000785dab1d0d10  vmovaps [rsp+0x70], xmm8
0000785dab1d0d16  vmovaps [rsp+0x80], xmm9
0000785dab1d0d1f  vmovaps [rsp+0x90], xmm10
0000785dab1d0d28  vmovaps [rsp+0xA0], xmm11
0000785dab1d0d31  vmovaps [rsp+0xB0], xmm12
0000785dab1d0d3a  vmovaps [rsp+0xC0], xmm13
0000785dab1d0d43  vmovaps [rsp+0xD0], xmm14
0000785dab1d0d4c  vmovaps [rsp+0xE0], xmm15
0000785dab1d0d55  sub rsp, 0x30
0000785dab1d0d59  movaps [rsp], xmm1
0000785dab1d0d5d  movaps [rsp+0x10], xmm10
0000785dab1d0d63  movaps [rsp+0x20], xmm2
0000785dab1d0d68  lea rdi, [rsp]
0000785dab1d0d6c  mov esi, 0x00
0000785dab1d0d71  mov rax, 0x61B13BBD6530
0000785dab1d0d7b  call rax
0000785dab1d0d7d  movaps xmm1, [rsp]
0000785dab1d0d81  add rsp, 0x30
0000785dab1d0d85  vmovaps xmm0, [rsp]
0000785dab1d0d8a  vmovaps xmm2, [rsp+0x10]
0000785dab1d0d90  vmovaps xmm3, [rsp+0x20]
0000785dab1d0d96  vmovaps xmm4, [rsp+0x30]
0000785dab1d0d9c  vmovaps xmm5, [rsp+0x40]
0000785dab1d0da2  vmovaps xmm6, [rsp+0x50]
0000785dab1d0da8  vmovaps xmm7, [rsp+0x60]
0000785dab1d0dae  vmovaps xmm8, [rsp+0x70]
0000785dab1d0db4  vmovaps xmm9, [rsp+0x80]
0000785dab1d0dbd  vmovaps xmm10, [rsp+0x90]
0000785dab1d0dc6  vmovaps xmm11, [rsp+0xA0]
0000785dab1d0dcf  vmovaps xmm12, [rsp+0xB0]
0000785dab1d0dd8  vmovaps xmm13, [rsp+0xC0]
0000785dab1d0de1  vmovaps xmm14, [rsp+0xD0]
0000785dab1d0dea  vmovaps xmm15, [rsp+0xE0]
0000785dab1d0df3  add rsp, 0xF0
0000785dab1d0dfa  pop r11
0000785dab1d0dfc  pop r10
0000785dab1d0dfe  pop r9
0000785dab1d0e00  pop r8
0000785dab1d0e02  pop rsi
0000785dab1d0e03  pop rdi
0000785dab1d0e04  pop rdx
0000785dab1d0e05  pop rcx
0000785dab1d0e06  pop rax
0000785dab1d0e07  add rsp, 0x08
0000785dab1d0e0b  jmp 0x0000785DAB1CF6B4
0000785dab1d0e10  sub rsp, 0x08
0000785dab1d0e14  push rax
0000785dab1d0e15  push rcx
0000785dab1d0e16  push rdx
0000785dab1d0e17  push rdi
0000785dab1d0e18  push rsi
0000785dab1d0e19  push r8
0000785dab1d0e1b  push r9
0000785dab1d0e1d  push r10
0000785dab1d0e1f  push r11
0000785dab1d0e21  sub rsp, 0xF0
0000785dab1d0e28  vmovaps [rsp], xmm0
0000785dab1d0e2d  vmovaps [rsp+0x10], xmm1
0000785dab1d0e33  vmovaps [rsp+0x20], xmm2
0000785dab1d0e39  vmovaps [rsp+0x30], xmm3
0000785dab1d0e3f  vmovaps [rsp+0x40], xmm4
0000785dab1d0e45  vmovaps [rsp+0x50], xmm5
0000785dab1d0e4b  vmovaps [rsp+0x60], xmm6
0000785dab1d0e51  vmovaps [rsp+0x70], xmm7
0000785dab1d0e57  vmovaps [rsp+0x80], xmm8
0000785dab1d0e60  vmovaps [rsp+0x90], xmm9
0000785dab1d0e69  vmovaps [rsp+0xA0], xmm10
0000785dab1d0e72  vmovaps [rsp+0xB0], xmm11
0000785dab1d0e7b  vmovaps [rsp+0xC0], xmm12
0000785dab1d0e84  vmovaps [rsp+0xD0], xmm13
0000785dab1d0e8d  vmovaps [rsp+0xE0], xmm14
0000785dab1d0e96  sub rsp, 0x30
0000785dab1d0e9a  movaps [rsp], xmm15
0000785dab1d0e9f  movaps [rsp+0x10], xmm10
0000785dab1d0ea5  movaps [rsp+0x20], xmm2
0000785dab1d0eaa  lea rdi, [rsp]
0000785dab1d0eae  mov esi, 0x00
0000785dab1d0eb3  mov rax, 0x61B13BBD6530
0000785dab1d0ebd  call rax
0000785dab1d0ebf  movaps xmm15, [rsp]
0000785dab1d0ec4  add rsp, 0x30
0000785dab1d0ec8  vmovaps xmm0, [rsp]
0000785dab1d0ecd  vmovaps xmm1, [rsp+0x10]
0000785dab1d0ed3  vmovaps xmm2, [rsp+0x20]
0000785dab1d0ed9  vmovaps xmm3, [rsp+0x30]
0000785dab1d0edf  vmovaps xmm4, [rsp+0x40]
0000785dab1d0ee5  vmovaps xmm5, [rsp+0x50]
0000785dab1d0eeb  vmovaps xmm6, [rsp+0x60]
0000785dab1d0ef1  vmovaps xmm7, [rsp+0x70]
0000785dab1d0ef7  vmovaps xmm8, [rsp+0x80]
0000785dab1d0f00  vmovaps xmm9, [rsp+0x90]
0000785dab1d0f09  vmovaps xmm10, [rsp+0xA0]
0000785dab1d0f12  vmovaps xmm11, [rsp+0xB0]
0000785dab1d0f1b  vmovaps xmm12, [rsp+0xC0]
0000785dab1d0f24  vmovaps xmm13, [rsp+0xD0]
0000785dab1d0f2d  vmovaps xmm14, [rsp+0xE0]
0000785dab1d0f36  add rsp, 0xF0
0000785dab1d0f3d  pop r11
0000785dab1d0f3f  pop r10
0000785dab1d0f41  pop r9
0000785dab1d0f43  pop r8
0000785dab1d0f45  pop rsi
0000785dab1d0f46  pop rdi
0000785dab1d0f47  pop rdx
0000785dab1d0f48  pop rcx
0000785dab1d0f49  pop rax
0000785dab1d0f4a  add rsp, 0x08
0000785dab1d0f4e  jmp 0x0000785DAB1CF706
0000785dab1d0f53  sub rsp, 0x08
0000785dab1d0f57  push rax
0000785dab1d0f58  push rcx
0000785dab1d0f59  push rdx
0000785dab1d0f5a  push rdi
0000785dab1d0f5b  push rsi
0000785dab1d0f5c  push r8
0000785dab1d0f5e  push r9
0000785dab1d0f60  push r10
0000785dab1d0f62  push r11
0000785dab1d0f64  sub rsp, 0xF0
0000785dab1d0f6b  vmovaps [rsp], xmm0
0000785dab1d0f70  vmovaps [rsp+0x10], xmm2
0000785dab1d0f76  vmovaps [rsp+0x20], xmm3
0000785dab1d0f7c  vmovaps [rsp+0x30], xmm4
0000785dab1d0f82  vmovaps [rsp+0x40], xmm5
0000785dab1d0f88  vmovaps [rsp+0x50], xmm6
0000785dab1d0f8e  vmovaps [rsp+0x60], xmm7
0000785dab1d0f94  vmovaps [rsp+0x70], xmm8
0000785dab1d0f9a  vmovaps [rsp+0x80], xmm9
0000785dab1d0fa3  vmovaps [rsp+0x90], xmm10
0000785dab1d0fac  vmovaps [rsp+0xA0], xmm11
0000785dab1d0fb5  vmovaps [rsp+0xB0], xmm12
0000785dab1d0fbe  vmovaps [rsp+0xC0], xmm13
0000785dab1d0fc7  vmovaps [rsp+0xD0], xmm14
0000785dab1d0fd0  vmovaps [rsp+0xE0], xmm15
0000785dab1d0fd9  sub rsp, 0x30
0000785dab1d0fdd  movaps [rsp], xmm1
0000785dab1d0fe1  movaps [rsp+0x10], xmm10
0000785dab1d0fe7  movaps [rsp+0x20], xmm12
0000785dab1d0fed  lea rdi, [rsp]
0000785dab1d0ff1  mov esi, 0x00
0000785dab1d0ff6  mov rax, 0x61B13BBD6530
0000785dab1d1000  call rax
0000785dab1d1002  movaps xmm1, [rsp]
0000785dab1d1006  add rsp, 0x30
0000785dab1d100a  vmovaps xmm0, [rsp]
0000785dab1d100f  vmovaps xmm2, [rsp+0x10]
0000785dab1d1015  vmovaps xmm3, [rsp+0x20]
0000785dab1d101b  vmovaps xmm4, [rsp+0x30]
0000785dab1d1021  vmovaps xmm5, [rsp+0x40]
0000785dab1d1027  vmovaps xmm6, [rsp+0x50]
0000785dab1d102d  vmovaps xmm7, [rsp+0x60]
0000785dab1d1033  vmovaps xmm8, [rsp+0x70]
0000785dab1d1039  vmovaps xmm9, [rsp+0x80]
0000785dab1d1042  vmovaps xmm10, [rsp+0x90]
0000785dab1d104b  vmovaps xmm11, [rsp+0xA0]
0000785dab1d1054  vmovaps xmm12, [rsp+0xB0]
0000785dab1d105d  vmovaps xmm13, [rsp+0xC0]
0000785dab1d1066  vmovaps xmm14, [rsp+0xD0]
0000785dab1d106f  vmovaps xmm15, [rsp+0xE0]
0000785dab1d1078  add rsp, 0xF0
0000785dab1d107f  pop r11
0000785dab1d1081  pop r10
0000785dab1d1083  pop r9
0000785dab1d1085  pop r8
0000785dab1d1087  pop rsi
0000785dab1d1088  pop rdi
0000785dab1d1089  pop rdx
0000785dab1d108a  pop rcx
0000785dab1d108b  pop rax
0000785dab1d108c  add rsp, 0x08
0000785dab1d1090  jmp 0x0000785DAB1CF732
0000785dab1d1095  sub rsp, 0x08
0000785dab1d1099  push rax
0000785dab1d109a  push rcx
0000785dab1d109b  push rdx
0000785dab1d109c  push rdi
0000785dab1d109d  push rsi
0000785dab1d109e  push r8
0000785dab1d10a0  push r9
0000785dab1d10a2  push r10
0000785dab1d10a4  push r11
0000785dab1d10a6  sub rsp, 0xF0
0000785dab1d10ad  vmovaps [rsp], xmm0
0000785dab1d10b2  vmovaps [rsp+0x10], xmm1
0000785dab1d10b8  vmovaps [rsp+0x20], xmm2
0000785dab1d10be  vmovaps [rsp+0x30], xmm3
0000785dab1d10c4  vmovaps [rsp+0x40], xmm4
0000785dab1d10ca  vmovaps [rsp+0x50], xmm5
0000785dab1d10d0  vmovaps [rsp+0x60], xmm6
0000785dab1d10d6  vmovaps [rsp+0x70], xmm7
0000785dab1d10dc  vmovaps [rsp+0x80], xmm8
0000785dab1d10e5  vmovaps [rsp+0x90], xmm9
0000785dab1d10ee  vmovaps [rsp+0xA0], xmm10
0000785dab1d10f7  vmovaps [rsp+0xB0], xmm11
0000785dab1d1100  vmovaps [rsp+0xC0], xmm12
0000785dab1d1109  vmovaps [rsp+0xD0], xmm13
0000785dab1d1112  vmovaps [rsp+0xE0], xmm14
0000785dab1d111b  sub rsp, 0x30
0000785dab1d111f  movaps [rsp], xmm15
0000785dab1d1124  movaps [rsp+0x10], xmm10
0000785dab1d112a  movaps [rsp+0x20], xmm12
0000785dab1d1130  lea rdi, [rsp]
0000785dab1d1134  mov esi, 0x00
0000785dab1d1139  mov rax, 0x61B13BBD6530
0000785dab1d1143  call rax
0000785dab1d1145  movaps xmm15, [rsp]
0000785dab1d114a  add rsp, 0x30
0000785dab1d114e  vmovaps xmm0, [rsp]
0000785dab1d1153  vmovaps xmm1, [rsp+0x10]
0000785dab1d1159  vmovaps xmm2, [rsp+0x20]
0000785dab1d115f  vmovaps xmm3, [rsp+0x30]
0000785dab1d1165  vmovaps xmm4, [rsp+0x40]
0000785dab1d116b  vmovaps xmm5, [rsp+0x50]
0000785dab1d1171  vmovaps xmm6, [rsp+0x60]
0000785dab1d1177  vmovaps xmm7, [rsp+0x70]
0000785dab1d117d  vmovaps xmm8, [rsp+0x80]
0000785dab1d1186  vmovaps xmm9, [rsp+0x90]
0000785dab1d118f  vmovaps xmm10, [rsp+0xA0]
0000785dab1d1198  vmovaps xmm11, [rsp+0xB0]
0000785dab1d11a1  vmovaps xmm12, [rsp+0xC0]
0000785dab1d11aa  vmovaps xmm13, [rsp+0xD0]
0000785dab1d11b3  vmovaps xmm14, [rsp+0xE0]
0000785dab1d11bc  add rsp, 0xF0
0000785dab1d11c3  pop r11
0000785dab1d11c5  pop r10
0000785dab1d11c7  pop r9
0000785dab1d11c9  pop r8
0000785dab1d11cb  pop rsi
0000785dab1d11cc  pop rdi
0000785dab1d11cd  pop rdx
0000785dab1d11ce  pop rcx
0000785dab1d11cf  pop rax
0000785dab1d11d0  add rsp, 0x08
0000785dab1d11d4  jmp 0x0000785DAB1CF75E
0000785dab1d11d9  call 0x0000785DAAFFF430
0000785dab1d11de  jmp 0x0000785DAB1CF7EE
0000785dab1d11e3  call 0x0000785DAAFFF430
0000785dab1d11e8  jmp 0x0000785DAB1CF801
0000785dab1d11ed  sub rsp, 0x08
0000785dab1d11f1  push rax
0000785dab1d11f2  push rcx
0000785dab1d11f3  push rdx
0000785dab1d11f4  push rdi
0000785dab1d11f5  push rsi
0000785dab1d11f6  push r8
0000785dab1d11f8  push r9
0000785dab1d11fa  push r10
0000785dab1d11fc  push r11
0000785dab1d11fe  sub rsp, 0xF0
0000785dab1d1205  vmovaps [rsp], xmm0
0000785dab1d120a  vmovaps [rsp+0x10], xmm2
0000785dab1d1210  vmovaps [rsp+0x20], xmm3
0000785dab1d1216  vmovaps [rsp+0x30], xmm4
0000785dab1d121c  vmovaps [rsp+0x40], xmm5
0000785dab1d1222  vmovaps [rsp+0x50], xmm6
0000785dab1d1228  vmovaps [rsp+0x60], xmm7
0000785dab1d122e  vmovaps [rsp+0x70], xmm8
0000785dab1d1234  vmovaps [rsp+0x80], xmm9
0000785dab1d123d  vmovaps [rsp+0x90], xmm10
0000785dab1d1246  vmovaps [rsp+0xA0], xmm11
0000785dab1d124f  vmovaps [rsp+0xB0], xmm12
0000785dab1d1258  vmovaps [rsp+0xC0], xmm13
0000785dab1d1261  vmovaps [rsp+0xD0], xmm14
0000785dab1d126a  vmovaps [rsp+0xE0], xmm15
0000785dab1d1273  sub rsp, 0x30
0000785dab1d1277  movaps [rsp], xmm1
0000785dab1d127b  movaps [rsp+0x10], xmm13
0000785dab1d1281  movaps [rsp+0x20], xmm2
0000785dab1d1286  lea rdi, [rsp]
0000785dab1d128a  mov esi, 0x00
0000785dab1d128f  mov rax, 0x61B13BBD6530
0000785dab1d1299  call rax
0000785dab1d129b  movaps xmm1, [rsp]
0000785dab1d129f  add rsp, 0x30
0000785dab1d12a3  vmovaps xmm0, [rsp]
0000785dab1d12a8  vmovaps xmm2, [rsp+0x10]
0000785dab1d12ae  vmovaps xmm3, [rsp+0x20]
0000785dab1d12b4  vmovaps xmm4, [rsp+0x30]
0000785dab1d12ba  vmovaps xmm5, [rsp+0x40]
0000785dab1d12c0  vmovaps xmm6, [rsp+0x50]
0000785dab1d12c6  vmovaps xmm7, [rsp+0x60]
0000785dab1d12cc  vmovaps xmm8, [rsp+0x70]
0000785dab1d12d2  vmovaps xmm9, [rsp+0x80]
0000785dab1d12db  vmovaps xmm10, [rsp+0x90]
0000785dab1d12e4  vmovaps xmm11, [rsp+0xA0]
0000785dab1d12ed  vmovaps xmm12, [rsp+0xB0]
0000785dab1d12f6  vmovaps xmm13, [rsp+0xC0]
0000785dab1d12ff  vmovaps xmm14, [rsp+0xD0]
0000785dab1d1308  vmovaps xmm15, [rsp+0xE0]
0000785dab1d1311  add rsp, 0xF0
0000785dab1d1318  pop r11
0000785dab1d131a  pop r10
0000785dab1d131c  pop r9
0000785dab1d131e  pop r8
0000785dab1d1320  pop rsi
0000785dab1d1321  pop rdi
0000785dab1d1322  pop rdx
0000785dab1d1323  pop rcx
0000785dab1d1324  pop rax
0000785dab1d1325  add rsp, 0x08
0000785dab1d1329  jmp 0x0000785DAB1CF82C
0000785dab1d132e  call 0x0000785DAB00E760
0000785dab1d1333  jmp 0x0000785DAB1CF839
0000785dab1d1338  sub rsp, 0x08
0000785dab1d133c  push rax
0000785dab1d133d  push rcx
0000785dab1d133e  push rdx
0000785dab1d133f  push rdi
0000785dab1d1340  push rsi
0000785dab1d1341  push r8
0000785dab1d1343  push r9
0000785dab1d1345  push r10
0000785dab1d1347  push r11
0000785dab1d1349  sub rsp, 0xF0
0000785dab1d1350  vmovaps [rsp], xmm0
0000785dab1d1355  vmovaps [rsp+0x10], xmm1
0000785dab1d135b  vmovaps [rsp+0x20], xmm2
0000785dab1d1361  vmovaps [rsp+0x30], xmm3
0000785dab1d1367  vmovaps [rsp+0x40], xmm4
0000785dab1d136d  vmovaps [rsp+0x50], xmm5
0000785dab1d1373  vmovaps [rsp+0x60], xmm6
0000785dab1d1379  vmovaps [rsp+0x70], xmm7
0000785dab1d137f  vmovaps [rsp+0x80], xmm8
0000785dab1d1388  vmovaps [rsp+0x90], xmm9
0000785dab1d1391  vmovaps [rsp+0xA0], xmm10
0000785dab1d139a  vmovaps [rsp+0xB0], xmm11
0000785dab1d13a3  vmovaps [rsp+0xC0], xmm12
0000785dab1d13ac  vmovaps [rsp+0xD0], xmm14
0000785dab1d13b5  vmovaps [rsp+0xE0], xmm15
0000785dab1d13be  sub rsp, 0x30
0000785dab1d13c2  movaps [rsp], xmm13
0000785dab1d13c7  movaps [rsp+0x10], xmm2
0000785dab1d13cc  movaps [rsp+0x20], xmm1
0000785dab1d13d1  lea rdi, [rsp]
0000785dab1d13d5  mov esi, 0x00
0000785dab1d13da  mov rax, 0x61B13BBD6530
0000785dab1d13e4  call rax
0000785dab1d13e6  movaps xmm13, [rsp]
0000785dab1d13eb  add rsp, 0x30
0000785dab1d13ef  vmovaps xmm0, [rsp]
0000785dab1d13f4  vmovaps xmm1, [rsp+0x10]
0000785dab1d13fa  vmovaps xmm2, [rsp+0x20]
0000785dab1d1400  vmovaps xmm3, [rsp+0x30]
0000785dab1d1406  vmovaps xmm4, [rsp+0x40]
0000785dab1d140c  vmovaps xmm5, [rsp+0x50]
0000785dab1d1412  vmovaps xmm6, [rsp+0x60]
0000785dab1d1418  vmovaps xmm7, [rsp+0x70]
0000785dab1d141e  vmovaps xmm8, [rsp+0x80]
0000785dab1d1427  vmovaps xmm9, [rsp+0x90]
0000785dab1d1430  vmovaps xmm10, [rsp+0xA0]
0000785dab1d1439  vmovaps xmm11, [rsp+0xB0]
0000785dab1d1442  vmovaps xmm12, [rsp+0xC0]
0000785dab1d144b  vmovaps xmm14, [rsp+0xD0]
0000785dab1d1454  vmovaps xmm15, [rsp+0xE0]
0000785dab1d145d  add rsp, 0xF0
0000785dab1d1464  pop r11
0000785dab1d1466  pop r10
0000785dab1d1468  pop r9
0000785dab1d146a  pop r8
0000785dab1d146c  pop rsi
0000785dab1d146d  pop rdi
0000785dab1d146e  pop rdx
0000785dab1d146f  pop rcx
0000785dab1d1470  pop rax
0000785dab1d1471  add rsp, 0x08
0000785dab1d1475  jmp 0x0000785DAB1CF878
0000785dab1d147a  sub rsp, 0x08
0000785dab1d147e  push rax
0000785dab1d147f  push rcx
0000785dab1d1480  push rdx
0000785dab1d1481  push rdi
0000785dab1d1482  push rsi
0000785dab1d1483  push r8
0000785dab1d1485  push r9
0000785dab1d1487  push r10
0000785dab1d1489  push r11
0000785dab1d148b  sub rsp, 0xF0
0000785dab1d1492  vmovaps [rsp], xmm0
0000785dab1d1497  vmovaps [rsp+0x10], xmm2
0000785dab1d149d  vmovaps [rsp+0x20], xmm3
0000785dab1d14a3  vmovaps [rsp+0x30], xmm4
0000785dab1d14a9  vmovaps [rsp+0x40], xmm5
0000785dab1d14af  vmovaps [rsp+0x50], xmm6
0000785dab1d14b5  vmovaps [rsp+0x60], xmm7
0000785dab1d14bb  vmovaps [rsp+0x70], xmm8
0000785dab1d14c1  vmovaps [rsp+0x80], xmm9
0000785dab1d14ca  vmovaps [rsp+0x90], xmm10
0000785dab1d14d3  vmovaps [rsp+0xA0], xmm11
0000785dab1d14dc  vmovaps [rsp+0xB0], xmm12
0000785dab1d14e5  vmovaps [rsp+0xC0], xmm13
0000785dab1d14ee  vmovaps [rsp+0xD0], xmm14
0000785dab1d14f7  vmovaps [rsp+0xE0], xmm15
0000785dab1d1500  sub rsp, 0x30
0000785dab1d1504  movaps [rsp], xmm1
0000785dab1d1508  movaps [rsp+0x10], xmm15
0000785dab1d150e  movaps [rsp+0x20], xmm2
0000785dab1d1513  lea rdi, [rsp]
0000785dab1d1517  mov esi, 0x00
0000785dab1d151c  mov rax, 0x61B13BBD6530
0000785dab1d1526  call rax
0000785dab1d1528  movaps xmm1, [rsp]
0000785dab1d152c  add rsp, 0x30
0000785dab1d1530  vmovaps xmm0, [rsp]
0000785dab1d1535  vmovaps xmm2, [rsp+0x10]
0000785dab1d153b  vmovaps xmm3, [rsp+0x20]
0000785dab1d1541  vmovaps xmm4, [rsp+0x30]
0000785dab1d1547  vmovaps xmm5, [rsp+0x40]
0000785dab1d154d  vmovaps xmm6, [rsp+0x50]
0000785dab1d1553  vmovaps xmm7, [rsp+0x60]
0000785dab1d1559  vmovaps xmm8, [rsp+0x70]
0000785dab1d155f  vmovaps xmm9, [rsp+0x80]
0000785dab1d1568  vmovaps xmm10, [rsp+0x90]
0000785dab1d1571  vmovaps xmm11, [rsp+0xA0]
0000785dab1d157a  vmovaps xmm12, [rsp+0xB0]
0000785dab1d1583  vmovaps xmm13, [rsp+0xC0]
0000785dab1d158c  vmovaps xmm14, [rsp+0xD0]
0000785dab1d1595  vmovaps xmm15, [rsp+0xE0]
0000785dab1d159e  add rsp, 0xF0
0000785dab1d15a5  pop r11
0000785dab1d15a7  pop r10
0000785dab1d15a9  pop r9
0000785dab1d15ab  pop r8
0000785dab1d15ad  pop rsi
0000785dab1d15ae  pop rdi
0000785dab1d15af  pop rdx
0000785dab1d15b0  pop rcx
0000785dab1d15b1  pop rax
0000785dab1d15b2  add rsp, 0x08
0000785dab1d15b6  jmp 0x0000785DAB1CF8AC
0000785dab1d15bb  sub rsp, 0x08
0000785dab1d15bf  push rax
0000785dab1d15c0  push rcx
0000785dab1d15c1  push rdx
0000785dab1d15c2  push rdi
0000785dab1d15c3  push rsi
0000785dab1d15c4  push r8
0000785dab1d15c6  push r9
0000785dab1d15c8  push r10
0000785dab1d15ca  push r11
0000785dab1d15cc  sub rsp, 0xF0
0000785dab1d15d3  vmovaps [rsp], xmm0
0000785dab1d15d8  vmovaps [rsp+0x10], xmm1
0000785dab1d15de  vmovaps [rsp+0x20], xmm2
0000785dab1d15e4  vmovaps [rsp+0x30], xmm3
0000785dab1d15ea  vmovaps [rsp+0x40], xmm4
0000785dab1d15f0  vmovaps [rsp+0x50], xmm5
0000785dab1d15f6  vmovaps [rsp+0x60], xmm6
0000785dab1d15fc  vmovaps [rsp+0x70], xmm7
0000785dab1d1602  vmovaps [rsp+0x80], xmm8
0000785dab1d160b  vmovaps [rsp+0x90], xmm9
0000785dab1d1614  vmovaps [rsp+0xA0], xmm10
0000785dab1d161d  vmovaps [rsp+0xB0], xmm11
0000785dab1d1626  vmovaps [rsp+0xC0], xmm12
0000785dab1d162f  vmovaps [rsp+0xD0], xmm13
0000785dab1d1638  vmovaps [rsp+0xE0], xmm15
0000785dab1d1641  sub rsp, 0x30
0000785dab1d1645  movaps [rsp], xmm14
0000785dab1d164a  movaps [rsp+0x10], xmm2
0000785dab1d164f  movaps [rsp+0x20], xmm15
0000785dab1d1655  lea rdi, [rsp]
0000785dab1d1659  mov esi, 0x00
0000785dab1d165e  mov rax, 0x61B13BBD6530
0000785dab1d1668  call rax
0000785dab1d166a  movaps xmm14, [rsp]
0000785dab1d166f  add rsp, 0x30
0000785dab1d1673  vmovaps xmm0, [rsp]
0000785dab1d1678  vmovaps xmm1, [rsp+0x10]
0000785dab1d167e  vmovaps xmm2, [rsp+0x20]
0000785dab1d1684  vmovaps xmm3, [rsp+0x30]
0000785dab1d168a  vmovaps xmm4, [rsp+0x40]
0000785dab1d1690  vmovaps xmm5, [rsp+0x50]
0000785dab1d1696  vmovaps xmm6, [rsp+0x60]
0000785dab1d169c  vmovaps xmm7, [rsp+0x70]
0000785dab1d16a2  vmovaps xmm8, [rsp+0x80]
0000785dab1d16ab  vmovaps xmm9, [rsp+0x90]
0000785dab1d16b4  vmovaps xmm10, [rsp+0xA0]
0000785dab1d16bd  vmovaps xmm11, [rsp+0xB0]
0000785dab1d16c6  vmovaps xmm12, [rsp+0xC0]
0000785dab1d16cf  vmovaps xmm13, [rsp+0xD0]
0000785dab1d16d8  vmovaps xmm15, [rsp+0xE0]
0000785dab1d16e1  add rsp, 0xF0
0000785dab1d16e8  pop r11
0000785dab1d16ea  pop r10
0000785dab1d16ec  pop r9
0000785dab1d16ee  pop r8
0000785dab1d16f0  pop rsi
0000785dab1d16f1  pop rdi
0000785dab1d16f2  pop rdx
0000785dab1d16f3  pop rcx
0000785dab1d16f4  pop rax
0000785dab1d16f5  add rsp, 0x08
0000785dab1d16f9  jmp 0x0000785DAB1CF8E7
0000785dab1d16fe  sub rsp, 0x08
0000785dab1d1702  push rax
0000785dab1d1703  push rcx
0000785dab1d1704  push rdx
0000785dab1d1705  push rdi
0000785dab1d1706  push rsi
0000785dab1d1707  push r8
0000785dab1d1709  push r9
0000785dab1d170b  push r10
0000785dab1d170d  push r11
0000785dab1d170f  sub rsp, 0xF0
0000785dab1d1716  vmovaps [rsp], xmm0
0000785dab1d171b  vmovaps [rsp+0x10], xmm1
0000785dab1d1721  vmovaps [rsp+0x20], xmm2
0000785dab1d1727  vmovaps [rsp+0x30], xmm3
0000785dab1d172d  vmovaps [rsp+0x40], xmm4
0000785dab1d1733  vmovaps [rsp+0x50], xmm5
0000785dab1d1739  vmovaps [rsp+0x60], xmm6
0000785dab1d173f  vmovaps [rsp+0x70], xmm7
0000785dab1d1745  vmovaps [rsp+0x80], xmm8
0000785dab1d174e  vmovaps [rsp+0x90], xmm9
0000785dab1d1757  vmovaps [rsp+0xA0], xmm10
0000785dab1d1760  vmovaps [rsp+0xB0], xmm11
0000785dab1d1769  vmovaps [rsp+0xC0], xmm12
0000785dab1d1772  vmovaps [rsp+0xD0], xmm13
0000785dab1d177b  vmovaps [rsp+0xE0], xmm14
0000785dab1d1784  sub rsp, 0x30
0000785dab1d1788  movaps [rsp], xmm15
0000785dab1d178d  movaps [rsp+0x10], xmm2
0000785dab1d1792  movaps [rsp+0x20], xmm1
0000785dab1d1797  lea rdi, [rsp]
0000785dab1d179b  mov esi, 0x00
0000785dab1d17a0  mov rax, 0x61B13BBD6530
0000785dab1d17aa  call rax
0000785dab1d17ac  movaps xmm15, [rsp]
0000785dab1d17b1  add rsp, 0x30
0000785dab1d17b5  vmovaps xmm0, [rsp]
0000785dab1d17ba  vmovaps xmm1, [rsp+0x10]
0000785dab1d17c0  vmovaps xmm2, [rsp+0x20]
0000785dab1d17c6  vmovaps xmm3, [rsp+0x30]
0000785dab1d17cc  vmovaps xmm4, [rsp+0x40]
0000785dab1d17d2  vmovaps xmm5, [rsp+0x50]
0000785dab1d17d8  vmovaps xmm6, [rsp+0x60]
0000785dab1d17de  vmovaps xmm7, [rsp+0x70]
0000785dab1d17e4  vmovaps xmm8, [rsp+0x80]
0000785dab1d17ed  vmovaps xmm9, [rsp+0x90]
0000785dab1d17f6  vmovaps xmm10, [rsp+0xA0]
0000785dab1d17ff  vmovaps xmm11, [rsp+0xB0]
0000785dab1d1808  vmovaps xmm12, [rsp+0xC0]
0000785dab1d1811  vmovaps xmm13, [rsp+0xD0]
0000785dab1d181a  vmovaps xmm14, [rsp+0xE0]
0000785dab1d1823  add rsp, 0xF0
0000785dab1d182a  pop r11
0000785dab1d182c  pop r10
0000785dab1d182e  pop r9
0000785dab1d1830  pop r8
0000785dab1d1832  pop rsi
0000785dab1d1833  pop rdi
0000785dab1d1834  pop rdx
0000785dab1d1835  pop rcx
0000785dab1d1836  pop rax
0000785dab1d1837  add rsp, 0x08
0000785dab1d183b  jmp 0x0000785DAB1CF923
0000785dab1d1840  call 0x0000785DAAFFF430
0000785dab1d1845  jmp 0x0000785DAB1CF930
0000785dab1d184a  sub rsp, 0x08
0000785dab1d184e  push rax
0000785dab1d184f  push rcx
0000785dab1d1850  push rdx
0000785dab1d1851  push rdi
0000785dab1d1852  push rsi
0000785dab1d1853  push r8
0000785dab1d1855  push r9
0000785dab1d1857  push r10
0000785dab1d1859  push r11
0000785dab1d185b  sub rsp, 0xF0
0000785dab1d1862  vmovaps [rsp], xmm0
0000785dab1d1867  vmovaps [rsp+0x10], xmm1
0000785dab1d186d  vmovaps [rsp+0x20], xmm3
0000785dab1d1873  vmovaps [rsp+0x30], xmm4
0000785dab1d1879  vmovaps [rsp+0x40], xmm5
0000785dab1d187f  vmovaps [rsp+0x50], xmm6
0000785dab1d1885  vmovaps [rsp+0x60], xmm7
0000785dab1d188b  vmovaps [rsp+0x70], xmm8
0000785dab1d1891  vmovaps [rsp+0x80], xmm9
0000785dab1d189a  vmovaps [rsp+0x90], xmm10
0000785dab1d18a3  vmovaps [rsp+0xA0], xmm11
0000785dab1d18ac  vmovaps [rsp+0xB0], xmm12
0000785dab1d18b5  vmovaps [rsp+0xC0], xmm13
0000785dab1d18be  vmovaps [rsp+0xD0], xmm14
0000785dab1d18c7  vmovaps [rsp+0xE0], xmm15
0000785dab1d18d0  sub rsp, 0x30
0000785dab1d18d4  movaps [rsp], xmm2
0000785dab1d18d8  movaps [rsp+0x10], xmm1
0000785dab1d18dd  movaps [rsp+0x20], xmm14
0000785dab1d18e3  lea rdi, [rsp]
0000785dab1d18e7  mov esi, 0x00
0000785dab1d18ec  mov rax, 0x61B13BBD6530
0000785dab1d18f6  call rax
0000785dab1d18f8  movaps xmm2, [rsp]
0000785dab1d18fc  add rsp, 0x30
0000785dab1d1900  vmovaps xmm0, [rsp]
0000785dab1d1905  vmovaps xmm1, [rsp+0x10]
0000785dab1d190b  vmovaps xmm3, [rsp+0x20]
0000785dab1d1911  vmovaps xmm4, [rsp+0x30]
0000785dab1d1917  vmovaps xmm5, [rsp+0x40]
0000785dab1d191d  vmovaps xmm6, [rsp+0x50]
0000785dab1d1923  vmovaps xmm7, [rsp+0x60]
0000785dab1d1929  vmovaps xmm8, [rsp+0x70]
0000785dab1d192f  vmovaps xmm9, [rsp+0x80]
0000785dab1d1938  vmovaps xmm10, [rsp+0x90]
0000785dab1d1941  vmovaps xmm11, [rsp+0xA0]
0000785dab1d194a  vmovaps xmm12, [rsp+0xB0]
0000785dab1d1953  vmovaps xmm13, [rsp+0xC0]
0000785dab1d195c  vmovaps xmm14, [rsp+0xD0]
0000785dab1d1965  vmovaps xmm15, [rsp+0xE0]
0000785dab1d196e  add rsp, 0xF0
0000785dab1d1975  pop r11
0000785dab1d1977  pop r10
0000785dab1d1979  pop r9
0000785dab1d197b  pop r8
0000785dab1d197d  pop rsi
0000785dab1d197e  pop rdi
0000785dab1d197f  pop rdx
0000785dab1d1980  pop rcx
0000785dab1d1981  pop rax
0000785dab1d1982  add rsp, 0x08
0000785dab1d1986  jmp 0x0000785DAB1CF96D
0000785dab1d198b  sub rsp, 0x08
0000785dab1d198f  push rax
0000785dab1d1990  push rcx
0000785dab1d1991  push rdx
0000785dab1d1992  push rdi
0000785dab1d1993  push rsi
0000785dab1d1994  push r8
0000785dab1d1996  push r9
0000785dab1d1998  push r10
0000785dab1d199a  push r11
0000785dab1d199c  sub rsp, 0xF0
0000785dab1d19a3  vmovaps [rsp], xmm0
0000785dab1d19a8  vmovaps [rsp+0x10], xmm1
0000785dab1d19ae  vmovaps [rsp+0x20], xmm2
0000785dab1d19b4  vmovaps [rsp+0x30], xmm3
0000785dab1d19ba  vmovaps [rsp+0x40], xmm4
0000785dab1d19c0  vmovaps [rsp+0x50], xmm5
0000785dab1d19c6  vmovaps [rsp+0x60], xmm6
0000785dab1d19cc  vmovaps [rsp+0x70], xmm7
0000785dab1d19d2  vmovaps [rsp+0x80], xmm8
0000785dab1d19db  vmovaps [rsp+0x90], xmm9
0000785dab1d19e4  vmovaps [rsp+0xA0], xmm10
0000785dab1d19ed  vmovaps [rsp+0xB0], xmm11
0000785dab1d19f6  vmovaps [rsp+0xC0], xmm12
0000785dab1d19ff  vmovaps [rsp+0xD0], xmm13
0000785dab1d1a08  vmovaps [rsp+0xE0], xmm14
0000785dab1d1a11  sub rsp, 0x30
0000785dab1d1a15  movaps [rsp], xmm15
0000785dab1d1a1a  movaps [rsp+0x10], xmm14
0000785dab1d1a20  movaps [rsp+0x20], xmm1
0000785dab1d1a25  lea rdi, [rsp]
0000785dab1d1a29  mov esi, 0x00
0000785dab1d1a2e  mov rax, 0x61B13BBD6530
0000785dab1d1a38  call rax
0000785dab1d1a3a  movaps xmm15, [rsp]
0000785dab1d1a3f  add rsp, 0x30
0000785dab1d1a43  vmovaps xmm0, [rsp]
0000785dab1d1a48  vmovaps xmm1, [rsp+0x10]
0000785dab1d1a4e  vmovaps xmm2, [rsp+0x20]
0000785dab1d1a54  vmovaps xmm3, [rsp+0x30]
0000785dab1d1a5a  vmovaps xmm4, [rsp+0x40]
0000785dab1d1a60  vmovaps xmm5, [rsp+0x50]
0000785dab1d1a66  vmovaps xmm6, [rsp+0x60]
0000785dab1d1a6c  vmovaps xmm7, [rsp+0x70]
0000785dab1d1a72  vmovaps xmm8, [rsp+0x80]
0000785dab1d1a7b  vmovaps xmm9, [rsp+0x90]
0000785dab1d1a84  vmovaps xmm10, [rsp+0xA0]
0000785dab1d1a8d  vmovaps xmm11, [rsp+0xB0]
0000785dab1d1a96  vmovaps xmm12, [rsp+0xC0]
0000785dab1d1a9f  vmovaps xmm13, [rsp+0xD0]
0000785dab1d1aa8  vmovaps xmm14, [rsp+0xE0]
0000785dab1d1ab1  add rsp, 0xF0
0000785dab1d1ab8  pop r11
0000785dab1d1aba  pop r10
0000785dab1d1abc  pop r9
0000785dab1d1abe  pop r8
0000785dab1d1ac0  pop rsi
0000785dab1d1ac1  pop rdi
0000785dab1d1ac2  pop rdx
0000785dab1d1ac3  pop rcx
0000785dab1d1ac4  pop rax
0000785dab1d1ac5  add rsp, 0x08
0000785dab1d1ac9  jmp 0x0000785DAB1CF9E7
0000785dab1d1ace  call 0x0000785DAAFFF430
0000785dab1d1ad3  jmp 0x0000785DAB1CF9F4
0000785dab1d1ad8  sub rsp, 0x08
0000785dab1d1adc  push rax
0000785dab1d1add  push rcx
0000785dab1d1ade  push rdx
0000785dab1d1adf  push rdi
0000785dab1d1ae0  push rsi
0000785dab1d1ae1  push r8
0000785dab1d1ae3  push r9
0000785dab1d1ae5  push r10
0000785dab1d1ae7  push r11
0000785dab1d1ae9  sub rsp, 0xF0
0000785dab1d1af0  vmovaps [rsp], xmm0
0000785dab1d1af5  vmovaps [rsp+0x10], xmm1
0000785dab1d1afb  vmovaps [rsp+0x20], xmm2
0000785dab1d1b01  vmovaps [rsp+0x30], xmm3
0000785dab1d1b07  vmovaps [rsp+0x40], xmm4
0000785dab1d1b0d  vmovaps [rsp+0x50], xmm5
0000785dab1d1b13  vmovaps [rsp+0x60], xmm6
0000785dab1d1b19  vmovaps [rsp+0x70], xmm7
0000785dab1d1b1f  vmovaps [rsp+0x80], xmm8
0000785dab1d1b28  vmovaps [rsp+0x90], xmm9
0000785dab1d1b31  vmovaps [rsp+0xA0], xmm10
0000785dab1d1b3a  vmovaps [rsp+0xB0], xmm11
0000785dab1d1b43  vmovaps [rsp+0xC0], xmm12
0000785dab1d1b4c  vmovaps [rsp+0xD0], xmm13
0000785dab1d1b55  vmovaps [rsp+0xE0], xmm15
0000785dab1d1b5e  sub rsp, 0x30
0000785dab1d1b62  movaps [rsp], xmm14
0000785dab1d1b67  movaps [rsp+0x10], xmm13
0000785dab1d1b6d  movaps [rsp+0x20], xmm1
0000785dab1d1b72  lea rdi, [rsp]
0000785dab1d1b76  mov esi, 0x00
0000785dab1d1b7b  mov rax, 0x61B13BBD6530
0000785dab1d1b85  call rax
0000785dab1d1b87  movaps xmm14, [rsp]
0000785dab1d1b8c  add rsp, 0x30
0000785dab1d1b90  vmovaps xmm0, [rsp]
0000785dab1d1b95  vmovaps xmm1, [rsp+0x10]
0000785dab1d1b9b  vmovaps xmm2, [rsp+0x20]
0000785dab1d1ba1  vmovaps xmm3, [rsp+0x30]
0000785dab1d1ba7  vmovaps xmm4, [rsp+0x40]
0000785dab1d1bad  vmovaps xmm5, [rsp+0x50]
0000785dab1d1bb3  vmovaps xmm6, [rsp+0x60]
0000785dab1d1bb9  vmovaps xmm7, [rsp+0x70]
0000785dab1d1bbf  vmovaps xmm8, [rsp+0x80]
0000785dab1d1bc8  vmovaps xmm9, [rsp+0x90]
0000785dab1d1bd1  vmovaps xmm10, [rsp+0xA0]
0000785dab1d1bda  vmovaps xmm11, [rsp+0xB0]
0000785dab1d1be3  vmovaps xmm12, [rsp+0xC0]
0000785dab1d1bec  vmovaps xmm13, [rsp+0xD0]
0000785dab1d1bf5  vmovaps xmm15, [rsp+0xE0]
0000785dab1d1bfe  add rsp, 0xF0
0000785dab1d1c05  pop r11
0000785dab1d1c07  pop r10
0000785dab1d1c09  pop r9
0000785dab1d1c0b  pop r8
0000785dab1d1c0d  pop rsi
0000785dab1d1c0e  pop rdi
0000785dab1d1c0f  pop rdx
0000785dab1d1c10  pop rcx
0000785dab1d1c11  pop rax
0000785dab1d1c12  add rsp, 0x08
0000785dab1d1c16  jmp 0x0000785DAB1CFAAF
0000785dab1d1c1b  sub rsp, 0x08
0000785dab1d1c1f  push rax
0000785dab1d1c20  push rcx
0000785dab1d1c21  push rdx
0000785dab1d1c22  push rdi
0000785dab1d1c23  push rsi
0000785dab1d1c24  push r8
0000785dab1d1c26  push r9
0000785dab1d1c28  push r10
0000785dab1d1c2a  push r11
0000785dab1d1c2c  sub rsp, 0xF0
0000785dab1d1c33  vmovaps [rsp], xmm0
0000785dab1d1c38  vmovaps [rsp+0x10], xmm1
0000785dab1d1c3e  vmovaps [rsp+0x20], xmm2
0000785dab1d1c44  vmovaps [rsp+0x30], xmm3
0000785dab1d1c4a  vmovaps [rsp+0x40], xmm4
0000785dab1d1c50  vmovaps [rsp+0x50], xmm5
0000785dab1d1c56  vmovaps [rsp+0x60], xmm6
0000785dab1d1c5c  vmovaps [rsp+0x70], xmm7
0000785dab1d1c62  vmovaps [rsp+0x80], xmm8
0000785dab1d1c6b  vmovaps [rsp+0x90], xmm9
0000785dab1d1c74  vmovaps [rsp+0xA0], xmm10
0000785dab1d1c7d  vmovaps [rsp+0xB0], xmm11
0000785dab1d1c86  vmovaps [rsp+0xC0], xmm12
0000785dab1d1c8f  vmovaps [rsp+0xD0], xmm13
0000785dab1d1c98  vmovaps [rsp+0xE0], xmm14
0000785dab1d1ca1  sub rsp, 0x30
0000785dab1d1ca5  movaps [rsp], xmm15
0000785dab1d1caa  movaps [rsp+0x10], xmm13
0000785dab1d1cb0  movaps [rsp+0x20], xmm1
0000785dab1d1cb5  lea rdi, [rsp]
0000785dab1d1cb9  mov esi, 0x00
0000785dab1d1cbe  mov rax, 0x61B13BBD6530
0000785dab1d1cc8  call rax
0000785dab1d1cca  movaps xmm15, [rsp]
0000785dab1d1ccf  add rsp, 0x30
0000785dab1d1cd3  vmovaps xmm0, [rsp]
0000785dab1d1cd8  vmovaps xmm1, [rsp+0x10]
0000785dab1d1cde  vmovaps xmm2, [rsp+0x20]
0000785dab1d1ce4  vmovaps xmm3, [rsp+0x30]
0000785dab1d1cea  vmovaps xmm4, [rsp+0x40]
0000785dab1d1cf0  vmovaps xmm5, [rsp+0x50]
0000785dab1d1cf6  vmovaps xmm6, [rsp+0x60]
0000785dab1d1cfc  vmovaps xmm7, [rsp+0x70]
0000785dab1d1d02  vmovaps xmm8, [rsp+0x80]
0000785dab1d1d0b  vmovaps xmm9, [rsp+0x90]
0000785dab1d1d14  vmovaps xmm10, [rsp+0xA0]
0000785dab1d1d1d  vmovaps xmm11, [rsp+0xB0]
0000785dab1d1d26  vmovaps xmm12, [rsp+0xC0]
0000785dab1d1d2f  vmovaps xmm13, [rsp+0xD0]
0000785dab1d1d38  vmovaps xmm14, [rsp+0xE0]
0000785dab1d1d41  add rsp, 0xF0
0000785dab1d1d48  pop r11
0000785dab1d1d4a  pop r10
0000785dab1d1d4c  pop r9
0000785dab1d1d4e  pop r8
0000785dab1d1d50  pop rsi
0000785dab1d1d51  pop rdi
0000785dab1d1d52  pop rdx
0000785dab1d1d53  pop rcx
0000785dab1d1d54  pop rax
0000785dab1d1d55  add rsp, 0x08
0000785dab1d1d59  jmp 0x0000785DAB1CFAEB
0000785dab1d1d5e  call 0x0000785DAAFFF430
0000785dab1d1d63  jmp 0x0000785DAB1CFAF8
0000785dab1d1d68  sub rsp, 0x08
0000785dab1d1d6c  push rax
0000785dab1d1d6d  push rcx
0000785dab1d1d6e  push rdx
0000785dab1d1d6f  push rdi
0000785dab1d1d70  push rsi
0000785dab1d1d71  push r8
0000785dab1d1d73  push r9
0000785dab1d1d75  push r10
0000785dab1d1d77  push r11
0000785dab1d1d79  sub rsp, 0xF0
0000785dab1d1d80  vmovaps [rsp], xmm0
0000785dab1d1d85  vmovaps [rsp+0x10], xmm1
0000785dab1d1d8b  vmovaps [rsp+0x20], xmm2
0000785dab1d1d91  vmovaps [rsp+0x30], xmm3
0000785dab1d1d97  vmovaps [rsp+0x40], xmm4
0000785dab1d1d9d  vmovaps [rsp+0x50], xmm5
0000785dab1d1da3  vmovaps [rsp+0x60], xmm6
0000785dab1d1da9  vmovaps [rsp+0x70], xmm7
0000785dab1d1daf  vmovaps [rsp+0x80], xmm8
0000785dab1d1db8  vmovaps [rsp+0x90], xmm9
0000785dab1d1dc1  vmovaps [rsp+0xA0], xmm10
0000785dab1d1dca  vmovaps [rsp+0xB0], xmm11
0000785dab1d1dd3  vmovaps [rsp+0xC0], xmm12
0000785dab1d1ddc  vmovaps [rsp+0xD0], xmm13
0000785dab1d1de5  vmovaps [rsp+0xE0], xmm15
0000785dab1d1dee  sub rsp, 0x30
0000785dab1d1df2  movaps [rsp], xmm14
0000785dab1d1df7  movaps [rsp+0x10], xmm13
0000785dab1d1dfd  movaps [rsp+0x20], xmm2
0000785dab1d1e02  lea rdi, [rsp]
0000785dab1d1e06  mov esi, 0x00
0000785dab1d1e0b  mov rax, 0x61B13BBD6530
0000785dab1d1e15  call rax
0000785dab1d1e17  movaps xmm14, [rsp]
0000785dab1d1e1c  add rsp, 0x30
0000785dab1d1e20  vmovaps xmm0, [rsp]
0000785dab1d1e25  vmovaps xmm1, [rsp+0x10]
0000785dab1d1e2b  vmovaps xmm2, [rsp+0x20]
0000785dab1d1e31  vmovaps xmm3, [rsp+0x30]
0000785dab1d1e37  vmovaps xmm4, [rsp+0x40]
0000785dab1d1e3d  vmovaps xmm5, [rsp+0x50]
0000785dab1d1e43  vmovaps xmm6, [rsp+0x60]
0000785dab1d1e49  vmovaps xmm7, [rsp+0x70]
0000785dab1d1e4f  vmovaps xmm8, [rsp+0x80]
0000785dab1d1e58  vmovaps xmm9, [rsp+0x90]
0000785dab1d1e61  vmovaps xmm10, [rsp+0xA0]
0000785dab1d1e6a  vmovaps xmm11, [rsp+0xB0]
0000785dab1d1e73  vmovaps xmm12, [rsp+0xC0]
0000785dab1d1e7c  vmovaps xmm13, [rsp+0xD0]
0000785dab1d1e85  vmovaps xmm15, [rsp+0xE0]
0000785dab1d1e8e  add rsp, 0xF0
0000785dab1d1e95  pop r11
0000785dab1d1e97  pop r10
0000785dab1d1e99  pop r9
0000785dab1d1e9b  pop r8
0000785dab1d1e9d  pop rsi
0000785dab1d1e9e  pop rdi
0000785dab1d1e9f  pop rdx
0000785dab1d1ea0  pop rcx
0000785dab1d1ea1  pop rax
0000785dab1d1ea2  add rsp, 0x08
0000785dab1d1ea6  jmp 0x0000785DAB1CFB24
0000785dab1d1eab  sub rsp, 0x08
0000785dab1d1eaf  push rax
0000785dab1d1eb0  push rcx
0000785dab1d1eb1  push rdx
0000785dab1d1eb2  push rdi
0000785dab1d1eb3  push rsi
0000785dab1d1eb4  push r8
0000785dab1d1eb6  push r9
0000785dab1d1eb8  push r10
0000785dab1d1eba  push r11
0000785dab1d1ebc  sub rsp, 0xF0
0000785dab1d1ec3  vmovaps [rsp], xmm0
0000785dab1d1ec8  vmovaps [rsp+0x10], xmm2
0000785dab1d1ece  vmovaps [rsp+0x20], xmm3
0000785dab1d1ed4  vmovaps [rsp+0x30], xmm4
0000785dab1d1eda  vmovaps [rsp+0x40], xmm5
0000785dab1d1ee0  vmovaps [rsp+0x50], xmm6
0000785dab1d1ee6  vmovaps [rsp+0x60], xmm7
0000785dab1d1eec  vmovaps [rsp+0x70], xmm8
0000785dab1d1ef2  vmovaps [rsp+0x80], xmm9
0000785dab1d1efb  vmovaps [rsp+0x90], xmm10
0000785dab1d1f04  vmovaps [rsp+0xA0], xmm11
0000785dab1d1f0d  vmovaps [rsp+0xB0], xmm12
0000785dab1d1f16  vmovaps [rsp+0xC0], xmm13
0000785dab1d1f1f  vmovaps [rsp+0xD0], xmm14
0000785dab1d1f28  vmovaps [rsp+0xE0], xmm15
0000785dab1d1f31  sub rsp, 0x30
0000785dab1d1f35  movaps [rsp], xmm1
0000785dab1d1f39  movaps [rsp+0x10], xmm13
0000785dab1d1f3f  movaps [rsp+0x20], xmm2
0000785dab1d1f44  lea rdi, [rsp]
0000785dab1d1f48  mov esi, 0x00
0000785dab1d1f4d  mov rax, 0x61B13BBD6530
0000785dab1d1f57  call rax
0000785dab1d1f59  movaps xmm1, [rsp]
0000785dab1d1f5d  add rsp, 0x30
0000785dab1d1f61  vmovaps xmm0, [rsp]
0000785dab1d1f66  vmovaps xmm2, [rsp+0x10]
0000785dab1d1f6c  vmovaps xmm3, [rsp+0x20]
0000785dab1d1f72  vmovaps xmm4, [rsp+0x30]
0000785dab1d1f78  vmovaps xmm5, [rsp+0x40]
0000785dab1d1f7e  vmovaps xmm6, [rsp+0x50]
0000785dab1d1f84  vmovaps xmm7, [rsp+0x60]
0000785dab1d1f8a  vmovaps xmm8, [rsp+0x70]
0000785dab1d1f90  vmovaps xmm9, [rsp+0x80]
0000785dab1d1f99  vmovaps xmm10, [rsp+0x90]
0000785dab1d1fa2  vmovaps xmm11, [rsp+0xA0]
0000785dab1d1fab  vmovaps xmm12, [rsp+0xB0]
0000785dab1d1fb4  vmovaps xmm13, [rsp+0xC0]
0000785dab1d1fbd  vmovaps xmm14, [rsp+0xD0]
0000785dab1d1fc6  vmovaps xmm15, [rsp+0xE0]
0000785dab1d1fcf  add rsp, 0xF0
0000785dab1d1fd6  pop r11
0000785dab1d1fd8  pop r10
0000785dab1d1fda  pop r9
0000785dab1d1fdc  pop r8
0000785dab1d1fde  pop rsi
0000785dab1d1fdf  pop rdi
0000785dab1d1fe0  pop rdx
0000785dab1d1fe1  pop rcx
0000785dab1d1fe2  pop rax
0000785dab1d1fe3  add rsp, 0x08
0000785dab1d1fe7  jmp 0x0000785DAB1CFB52
0000785dab1d1fec  sub rsp, 0x08
0000785dab1d1ff0  push rax
0000785dab1d1ff1  push rcx
0000785dab1d1ff2  push rdx
0000785dab1d1ff3  push rdi
0000785dab1d1ff4  push rsi
0000785dab1d1ff5  push r8
0000785dab1d1ff7  push r9
0000785dab1d1ff9  push r10
0000785dab1d1ffb  push r11
0000785dab1d1ffd  sub rsp, 0xF0
0000785dab1d2004  vmovaps [rsp], xmm0
0000785dab1d2009  vmovaps [rsp+0x10], xmm1
0000785dab1d200f  vmovaps [rsp+0x20], xmm3
0000785dab1d2015  vmovaps [rsp+0x30], xmm4
0000785dab1d201b  vmovaps [rsp+0x40], xmm5
0000785dab1d2021  vmovaps [rsp+0x50], xmm6
0000785dab1d2027  vmovaps [rsp+0x60], xmm7
0000785dab1d202d  vmovaps [rsp+0x70], xmm8
0000785dab1d2033  vmovaps [rsp+0x80], xmm9
0000785dab1d203c  vmovaps [rsp+0x90], xmm10
0000785dab1d2045  vmovaps [rsp+0xA0], xmm11
0000785dab1d204e  vmovaps [rsp+0xB0], xmm12
0000785dab1d2057  vmovaps [rsp+0xC0], xmm13
0000785dab1d2060  vmovaps [rsp+0xD0], xmm14
0000785dab1d2069  vmovaps [rsp+0xE0], xmm15
0000785dab1d2072  sub rsp, 0x30
0000785dab1d2076  movaps [rsp], xmm2
0000785dab1d207a  movaps [rsp+0x10], xmm1
0000785dab1d207f  movaps [rsp+0x20], xmm13
0000785dab1d2085  lea rdi, [rsp]
0000785dab1d2089  mov esi, 0x00
0000785dab1d208e  mov rax, 0x61B13BBD6530
0000785dab1d2098  call rax
0000785dab1d209a  movaps xmm2, [rsp]
0000785dab1d209e  add rsp, 0x30
0000785dab1d20a2  vmovaps xmm0, [rsp]
0000785dab1d20a7  vmovaps xmm1, [rsp+0x10]
0000785dab1d20ad  vmovaps xmm3, [rsp+0x20]
0000785dab1d20b3  vmovaps xmm4, [rsp+0x30]
0000785dab1d20b9  vmovaps xmm5, [rsp+0x40]
0000785dab1d20bf  vmovaps xmm6, [rsp+0x50]
0000785dab1d20c5  vmovaps xmm7, [rsp+0x60]
0000785dab1d20cb  vmovaps xmm8, [rsp+0x70]
0000785dab1d20d1  vmovaps xmm9, [rsp+0x80]
0000785dab1d20da  vmovaps xmm10, [rsp+0x90]
0000785dab1d20e3  vmovaps xmm11, [rsp+0xA0]
0000785dab1d20ec  vmovaps xmm12, [rsp+0xB0]
0000785dab1d20f5  vmovaps xmm13, [rsp+0xC0]
0000785dab1d20fe  vmovaps xmm14, [rsp+0xD0]
0000785dab1d2107  vmovaps xmm15, [rsp+0xE0]
0000785dab1d2110  add rsp, 0xF0
0000785dab1d2117  pop r11
0000785dab1d2119  pop r10
0000785dab1d211b  pop r9
0000785dab1d211d  pop r8
0000785dab1d211f  pop rsi
0000785dab1d2120  pop rdi
0000785dab1d2121  pop rdx
0000785dab1d2122  pop rcx
0000785dab1d2123  pop rax
0000785dab1d2124  add rsp, 0x08
0000785dab1d2128  jmp 0x0000785DAB1CFBAB
0000785dab1d212d  call 0x0000785DAAFFF430
0000785dab1d2132  jmp 0x0000785DAB1CFBB8
0000785dab1d2137  sub rsp, 0x08
0000785dab1d213b  push rax
0000785dab1d213c  push rcx
0000785dab1d213d  push rdx
0000785dab1d213e  push rdi
0000785dab1d213f  push rsi
0000785dab1d2140  push r8
0000785dab1d2142  push r9
0000785dab1d2144  push r10
0000785dab1d2146  push r11
0000785dab1d2148  sub rsp, 0xF0
0000785dab1d214f  vmovaps [rsp], xmm0
0000785dab1d2154  vmovaps [rsp+0x10], xmm1
0000785dab1d215a  vmovaps [rsp+0x20], xmm2
0000785dab1d2160  vmovaps [rsp+0x30], xmm3
0000785dab1d2166  vmovaps [rsp+0x40], xmm4
0000785dab1d216c  vmovaps [rsp+0x50], xmm5
0000785dab1d2172  vmovaps [rsp+0x60], xmm6
0000785dab1d2178  vmovaps [rsp+0x70], xmm7
0000785dab1d217e  vmovaps [rsp+0x80], xmm8
0000785dab1d2187  vmovaps [rsp+0x90], xmm9
0000785dab1d2190  vmovaps [rsp+0xA0], xmm10
0000785dab1d2199  vmovaps [rsp+0xB0], xmm11
0000785dab1d21a2  vmovaps [rsp+0xC0], xmm12
0000785dab1d21ab  vmovaps [rsp+0xD0], xmm13
0000785dab1d21b4  vmovaps [rsp+0xE0], xmm14
0000785dab1d21bd  sub rsp, 0x30
0000785dab1d21c1  movaps [rsp], xmm15
0000785dab1d21c6  movaps [rsp+0x10], xmm13
0000785dab1d21cc  movaps [rsp+0x20], xmm1
0000785dab1d21d1  lea rdi, [rsp]
0000785dab1d21d5  mov esi, 0x00
0000785dab1d21da  mov rax, 0x61B13BBD6530
0000785dab1d21e4  call rax
0000785dab1d21e6  movaps xmm15, [rsp]
0000785dab1d21eb  add rsp, 0x30
0000785dab1d21ef  vmovaps xmm0, [rsp]
0000785dab1d21f4  vmovaps xmm1, [rsp+0x10]
0000785dab1d21fa  vmovaps xmm2, [rsp+0x20]
0000785dab1d2200  vmovaps xmm3, [rsp+0x30]
0000785dab1d2206  vmovaps xmm4, [rsp+0x40]
0000785dab1d220c  vmovaps xmm5, [rsp+0x50]
0000785dab1d2212  vmovaps xmm6, [rsp+0x60]
0000785dab1d2218  vmovaps xmm7, [rsp+0x70]
0000785dab1d221e  vmovaps xmm8, [rsp+0x80]
0000785dab1d2227  vmovaps xmm9, [rsp+0x90]
0000785dab1d2230  vmovaps xmm10, [rsp+0xA0]
0000785dab1d2239  vmovaps xmm11, [rsp+0xB0]
0000785dab1d2242  vmovaps xmm12, [rsp+0xC0]
0000785dab1d224b  vmovaps xmm13, [rsp+0xD0]
0000785dab1d2254  vmovaps xmm14, [rsp+0xE0]
0000785dab1d225d  add rsp, 0xF0
0000785dab1d2264  pop r11
0000785dab1d2266  pop r10
0000785dab1d2268  pop r9
0000785dab1d226a  pop r8
0000785dab1d226c  pop rsi
0000785dab1d226d  pop rdi
0000785dab1d226e  pop rdx
0000785dab1d226f  pop rcx
0000785dab1d2270  pop rax
0000785dab1d2271  add rsp, 0x08
0000785dab1d2275  jmp 0x0000785DAB1CFBF7
0000785dab1d227a  sub rsp, 0x08
0000785dab1d227e  push rax
0000785dab1d227f  push rcx
0000785dab1d2280  push rdx
0000785dab1d2281  push rdi
0000785dab1d2282  push rsi
0000785dab1d2283  push r8
0000785dab1d2285  push r9
0000785dab1d2287  push r10
0000785dab1d2289  push r11
0000785dab1d228b  sub rsp, 0xF0
0000785dab1d2292  vmovaps [rsp], xmm0
0000785dab1d2297  vmovaps [rsp+0x10], xmm1
0000785dab1d229d  vmovaps [rsp+0x20], xmm2
0000785dab1d22a3  vmovaps [rsp+0x30], xmm3
0000785dab1d22a9  vmovaps [rsp+0x40], xmm4
0000785dab1d22af  vmovaps [rsp+0x50], xmm5
0000785dab1d22b5  vmovaps [rsp+0x60], xmm6
0000785dab1d22bb  vmovaps [rsp+0x70], xmm7
0000785dab1d22c1  vmovaps [rsp+0x80], xmm8
0000785dab1d22ca  vmovaps [rsp+0x90], xmm9
0000785dab1d22d3  vmovaps [rsp+0xA0], xmm10
0000785dab1d22dc  vmovaps [rsp+0xB0], xmm11
0000785dab1d22e5  vmovaps [rsp+0xC0], xmm12
0000785dab1d22ee  vmovaps [rsp+0xD0], xmm13
0000785dab1d22f7  vmovaps [rsp+0xE0], xmm15
0000785dab1d2300  sub rsp, 0x30
0000785dab1d2304  movaps [rsp], xmm14
0000785dab1d2309  movaps [rsp+0x10], xmm11
0000785dab1d230f  movaps [rsp+0x20], xmm1
0000785dab1d2314  lea rdi, [rsp]
0000785dab1d2318  mov esi, 0x00
0000785dab1d231d  mov rax, 0x61B13BBD6530
0000785dab1d2327  call rax
0000785dab1d2329  movaps xmm14, [rsp]
0000785dab1d232e  add rsp, 0x30
0000785dab1d2332  vmovaps xmm0, [rsp]
0000785dab1d2337  vmovaps xmm1, [rsp+0x10]
0000785dab1d233d  vmovaps xmm2, [rsp+0x20]
0000785dab1d2343  vmovaps xmm3, [rsp+0x30]
0000785dab1d2349  vmovaps xmm4, [rsp+0x40]
0000785dab1d234f  vmovaps xmm5, [rsp+0x50]
0000785dab1d2355  vmovaps xmm6, [rsp+0x60]
0000785dab1d235b  vmovaps xmm7, [rsp+0x70]
0000785dab1d2361  vmovaps xmm8, [rsp+0x80]
0000785dab1d236a  vmovaps xmm9, [rsp+0x90]
0000785dab1d2373  vmovaps xmm10, [rsp+0xA0]
0000785dab1d237c  vmovaps xmm11, [rsp+0xB0]
0000785dab1d2385  vmovaps xmm12, [rsp+0xC0]
0000785dab1d238e  vmovaps xmm13, [rsp+0xD0]
0000785dab1d2397  vmovaps xmm15, [rsp+0xE0]
0000785dab1d23a0  add rsp, 0xF0
0000785dab1d23a7  pop r11
0000785dab1d23a9  pop r10
0000785dab1d23ab  pop r9
0000785dab1d23ad  pop r8
0000785dab1d23af  pop rsi
0000785dab1d23b0  pop rdi
0000785dab1d23b1  pop rdx
0000785dab1d23b2  pop rcx
0000785dab1d23b3  pop rax
0000785dab1d23b4  add rsp, 0x08
0000785dab1d23b8  jmp 0x0000785DAB1CFC21
0000785dab1d23bd  sub rsp, 0x08
0000785dab1d23c1  push rax
0000785dab1d23c2  push rcx
0000785dab1d23c3  push rdx
0000785dab1d23c4  push rdi
0000785dab1d23c5  push rsi
0000785dab1d23c6  push r8
0000785dab1d23c8  push r9
0000785dab1d23ca  push r10
0000785dab1d23cc  push r11
0000785dab1d23ce  sub rsp, 0xF0
0000785dab1d23d5  vmovaps [rsp], xmm0
0000785dab1d23da  vmovaps [rsp+0x10], xmm1
0000785dab1d23e0  vmovaps [rsp+0x20], xmm2
0000785dab1d23e6  vmovaps [rsp+0x30], xmm3
0000785dab1d23ec  vmovaps [rsp+0x40], xmm4
0000785dab1d23f2  vmovaps [rsp+0x50], xmm5
0000785dab1d23f8  vmovaps [rsp+0x60], xmm6
0000785dab1d23fe  vmovaps [rsp+0x70], xmm7
0000785dab1d2404  vmovaps [rsp+0x80], xmm8
0000785dab1d240d  vmovaps [rsp+0x90], xmm9
0000785dab1d2416  vmovaps [rsp+0xA0], xmm10
0000785dab1d241f  vmovaps [rsp+0xB0], xmm11
0000785dab1d2428  vmovaps [rsp+0xC0], xmm12
0000785dab1d2431  vmovaps [rsp+0xD0], xmm14
0000785dab1d243a  vmovaps [rsp+0xE0], xmm15
0000785dab1d2443  sub rsp, 0x30
0000785dab1d2447  movaps [rsp], xmm13
0000785dab1d244c  movaps [rsp+0x10], xmm11
0000785dab1d2452  movaps [rsp+0x20], xmm1
0000785dab1d2457  lea rdi, [rsp]
0000785dab1d245b  mov esi, 0x00
0000785dab1d2460  mov rax, 0x61B13BBD6530
0000785dab1d246a  call rax
0000785dab1d246c  movaps xmm13, [rsp]
0000785dab1d2471  add rsp, 0x30
0000785dab1d2475  vmovaps xmm0, [rsp]
0000785dab1d247a  vmovaps xmm1, [rsp+0x10]
0000785dab1d2480  vmovaps xmm2, [rsp+0x20]
0000785dab1d2486  vmovaps xmm3, [rsp+0x30]
0000785dab1d248c  vmovaps xmm4, [rsp+0x40]
0000785dab1d2492  vmovaps xmm5, [rsp+0x50]
0000785dab1d2498  vmovaps xmm6, [rsp+0x60]
0000785dab1d249e  vmovaps xmm7, [rsp+0x70]
0000785dab1d24a4  vmovaps xmm8, [rsp+0x80]
0000785dab1d24ad  vmovaps xmm9, [rsp+0x90]
0000785dab1d24b6  vmovaps xmm10, [rsp+0xA0]
0000785dab1d24bf  vmovaps xmm11, [rsp+0xB0]
0000785dab1d24c8  vmovaps xmm12, [rsp+0xC0]
0000785dab1d24d1  vmovaps xmm14, [rsp+0xD0]
0000785dab1d24da  vmovaps xmm15, [rsp+0xE0]
0000785dab1d24e3  add rsp, 0xF0
0000785dab1d24ea  pop r11
0000785dab1d24ec  pop r10
0000785dab1d24ee  pop r9
0000785dab1d24f0  pop r8
0000785dab1d24f2  pop rsi
0000785dab1d24f3  pop rdi
0000785dab1d24f4  pop rdx
0000785dab1d24f5  pop rcx
0000785dab1d24f6  pop rax
0000785dab1d24f7  add rsp, 0x08
0000785dab1d24fb  jmp 0x0000785DAB1CFC76
0000785dab1d2500  call 0x0000785DAAFFF430
0000785dab1d2505  jmp 0x0000785DAB1CFC83
0000785dab1d250a  sub rsp, 0x08
0000785dab1d250e  push rax
0000785dab1d250f  push rcx
0000785dab1d2510  push rdx
0000785dab1d2511  push rdi
0000785dab1d2512  push rsi
0000785dab1d2513  push r8
0000785dab1d2515  push r9
0000785dab1d2517  push r10
0000785dab1d2519  push r11
0000785dab1d251b  sub rsp, 0xF0
0000785dab1d2522  vmovaps [rsp], xmm0
0000785dab1d2527  vmovaps [rsp+0x10], xmm1
0000785dab1d252d  vmovaps [rsp+0x20], xmm2
0000785dab1d2533  vmovaps [rsp+0x30], xmm3
0000785dab1d2539  vmovaps [rsp+0x40], xmm4
0000785dab1d253f  vmovaps [rsp+0x50], xmm5
0000785dab1d2545  vmovaps [rsp+0x60], xmm6
0000785dab1d254b  vmovaps [rsp+0x70], xmm7
0000785dab1d2551  vmovaps [rsp+0x80], xmm8
0000785dab1d255a  vmovaps [rsp+0x90], xmm9
0000785dab1d2563  vmovaps [rsp+0xA0], xmm10
0000785dab1d256c  vmovaps [rsp+0xB0], xmm11
0000785dab1d2575  vmovaps [rsp+0xC0], xmm12
0000785dab1d257e  vmovaps [rsp+0xD0], xmm13
0000785dab1d2587  vmovaps [rsp+0xE0], xmm14
0000785dab1d2590  sub rsp, 0x30
0000785dab1d2594  movaps [rsp], xmm15
0000785dab1d2599  movaps [rsp+0x10], xmm11
0000785dab1d259f  movaps [rsp+0x20], xmm1
0000785dab1d25a4  lea rdi, [rsp]
0000785dab1d25a8  mov esi, 0x00
0000785dab1d25ad  mov rax, 0x61B13BBD6530
0000785dab1d25b7  call rax
0000785dab1d25b9  movaps xmm15, [rsp]
0000785dab1d25be  add rsp, 0x30
0000785dab1d25c2  vmovaps xmm0, [rsp]
0000785dab1d25c7  vmovaps xmm1, [rsp+0x10]
0000785dab1d25cd  vmovaps xmm2, [rsp+0x20]
0000785dab1d25d3  vmovaps xmm3, [rsp+0x30]
0000785dab1d25d9  vmovaps xmm4, [rsp+0x40]
0000785dab1d25df  vmovaps xmm5, [rsp+0x50]
0000785dab1d25e5  vmovaps xmm6, [rsp+0x60]
0000785dab1d25eb  vmovaps xmm7, [rsp+0x70]
0000785dab1d25f1  vmovaps xmm8, [rsp+0x80]
0000785dab1d25fa  vmovaps xmm9, [rsp+0x90]
0000785dab1d2603  vmovaps xmm10, [rsp+0xA0]
0000785dab1d260c  vmovaps xmm11, [rsp+0xB0]
0000785dab1d2615  vmovaps xmm12, [rsp+0xC0]
0000785dab1d261e  vmovaps xmm13, [rsp+0xD0]
0000785dab1d2627  vmovaps xmm14, [rsp+0xE0]
0000785dab1d2630  add rsp, 0xF0
0000785dab1d2637  pop r11
0000785dab1d2639  pop r10
0000785dab1d263b  pop r9
0000785dab1d263d  pop r8
0000785dab1d263f  pop rsi
0000785dab1d2640  pop rdi
0000785dab1d2641  pop rdx
0000785dab1d2642  pop rcx
0000785dab1d2643  pop rax
0000785dab1d2644  add rsp, 0x08
0000785dab1d2648  jmp 0x0000785DAB1CFCBC
0000785dab1d264d  sub rsp, 0x08
0000785dab1d2651  push rax
0000785dab1d2652  push rcx
0000785dab1d2653  push rdx
0000785dab1d2654  push rdi
0000785dab1d2655  push rsi
0000785dab1d2656  push r8
0000785dab1d2658  push r9
0000785dab1d265a  push r10
0000785dab1d265c  push r11
0000785dab1d265e  sub rsp, 0xF0
0000785dab1d2665  vmovaps [rsp], xmm0
0000785dab1d266a  vmovaps [rsp+0x10], xmm1
0000785dab1d2670  vmovaps [rsp+0x20], xmm2
0000785dab1d2676  vmovaps [rsp+0x30], xmm3
0000785dab1d267c  vmovaps [rsp+0x40], xmm4
0000785dab1d2682  vmovaps [rsp+0x50], xmm5
0000785dab1d2688  vmovaps [rsp+0x60], xmm6
0000785dab1d268e  vmovaps [rsp+0x70], xmm7
0000785dab1d2694  vmovaps [rsp+0x80], xmm8
0000785dab1d269d  vmovaps [rsp+0x90], xmm9
0000785dab1d26a6  vmovaps [rsp+0xA0], xmm10
0000785dab1d26af  vmovaps [rsp+0xB0], xmm12
0000785dab1d26b8  vmovaps [rsp+0xC0], xmm13
0000785dab1d26c1  vmovaps [rsp+0xD0], xmm14
0000785dab1d26ca  vmovaps [rsp+0xE0], xmm15
0000785dab1d26d3  sub rsp, 0x30
0000785dab1d26d7  movaps [rsp], xmm11
0000785dab1d26dc  movaps [rsp+0x10], xmm6
0000785dab1d26e1  movaps [rsp+0x20], xmm14
0000785dab1d26e7  lea rdi, [rsp]
0000785dab1d26eb  mov esi, 0x00
0000785dab1d26f0  mov rax, 0x61B13BBD6530
0000785dab1d26fa  call rax
0000785dab1d26fc  movaps xmm11, [rsp]
0000785dab1d2701  add rsp, 0x30
0000785dab1d2705  vmovaps xmm0, [rsp]
0000785dab1d270a  vmovaps xmm1, [rsp+0x10]
0000785dab1d2710  vmovaps xmm2, [rsp+0x20]
0000785dab1d2716  vmovaps xmm3, [rsp+0x30]
0000785dab1d271c  vmovaps xmm4, [rsp+0x40]
0000785dab1d2722  vmovaps xmm5, [rsp+0x50]
0000785dab1d2728  vmovaps xmm6, [rsp+0x60]
0000785dab1d272e  vmovaps xmm7, [rsp+0x70]
0000785dab1d2734  vmovaps xmm8, [rsp+0x80]
0000785dab1d273d  vmovaps xmm9, [rsp+0x90]
0000785dab1d2746  vmovaps xmm10, [rsp+0xA0]
0000785dab1d274f  vmovaps xmm12, [rsp+0xB0]
0000785dab1d2758  vmovaps xmm13, [rsp+0xC0]
0000785dab1d2761  vmovaps xmm14, [rsp+0xD0]
0000785dab1d276a  vmovaps xmm15, [rsp+0xE0]
0000785dab1d2773  add rsp, 0xF0
0000785dab1d277a  pop r11
0000785dab1d277c  pop r10
0000785dab1d277e  pop r9
0000785dab1d2780  pop r8
0000785dab1d2782  pop rsi
0000785dab1d2783  pop rdi
0000785dab1d2784  pop rdx
0000785dab1d2785  pop rcx
0000785dab1d2786  pop rax
0000785dab1d2787  add rsp, 0x08
0000785dab1d278b  jmp 0x0000785DAB1CFD34
0000785dab1d2790  call 0x0000785DAAFFF430
0000785dab1d2795  jmp 0x0000785DAB1CFD3E
0000785dab1d279a  sub rsp, 0x08
0000785dab1d279e  push rax
0000785dab1d279f  push rcx
0000785dab1d27a0  push rdx
0000785dab1d27a1  push rdi
0000785dab1d27a2  push rsi
0000785dab1d27a3  push r8
0000785dab1d27a5  push r9
0000785dab1d27a7  push r10
0000785dab1d27a9  push r11
0000785dab1d27ab  sub rsp, 0xF0
0000785dab1d27b2  vmovaps [rsp], xmm0
0000785dab1d27b7  vmovaps [rsp+0x10], xmm1
0000785dab1d27bd  vmovaps [rsp+0x20], xmm2
0000785dab1d27c3  vmovaps [rsp+0x30], xmm3
0000785dab1d27c9  vmovaps [rsp+0x40], xmm4
0000785dab1d27cf  vmovaps [rsp+0x50], xmm5
0000785dab1d27d5  vmovaps [rsp+0x60], xmm6
0000785dab1d27db  vmovaps [rsp+0x70], xmm7
0000785dab1d27e1  vmovaps [rsp+0x80], xmm8
0000785dab1d27ea  vmovaps [rsp+0x90], xmm9
0000785dab1d27f3  vmovaps [rsp+0xA0], xmm10
0000785dab1d27fc  vmovaps [rsp+0xB0], xmm11
0000785dab1d2805  vmovaps [rsp+0xC0], xmm12
0000785dab1d280e  vmovaps [rsp+0xD0], xmm13
0000785dab1d2817  vmovaps [rsp+0xE0], xmm15
0000785dab1d2820  sub rsp, 0x30
0000785dab1d2824  movaps [rsp], xmm14
0000785dab1d2829  movaps [rsp+0x10], xmm6
0000785dab1d282e  movaps [rsp+0x20], xmm2
0000785dab1d2833  lea rdi, [rsp]
0000785dab1d2837  mov esi, 0x00
0000785dab1d283c  mov rax, 0x61B13BBD6530
0000785dab1d2846  call rax
0000785dab1d2848  movaps xmm14, [rsp]
0000785dab1d284d  add rsp, 0x30
0000785dab1d2851  vmovaps xmm0, [rsp]
0000785dab1d2856  vmovaps xmm1, [rsp+0x10]
0000785dab1d285c  vmovaps xmm2, [rsp+0x20]
0000785dab1d2862  vmovaps xmm3, [rsp+0x30]
0000785dab1d2868  vmovaps xmm4, [rsp+0x40]
0000785dab1d286e  vmovaps xmm5, [rsp+0x50]
0000785dab1d2874  vmovaps xmm6, [rsp+0x60]
0000785dab1d287a  vmovaps xmm7, [rsp+0x70]
0000785dab1d2880  vmovaps xmm8, [rsp+0x80]
0000785dab1d2889  vmovaps xmm9, [rsp+0x90]
0000785dab1d2892  vmovaps xmm10, [rsp+0xA0]
0000785dab1d289b  vmovaps xmm11, [rsp+0xB0]
0000785dab1d28a4  vmovaps xmm12, [rsp+0xC0]
0000785dab1d28ad  vmovaps xmm13, [rsp+0xD0]
0000785dab1d28b6  vmovaps xmm15, [rsp+0xE0]
0000785dab1d28bf  add rsp, 0xF0
0000785dab1d28c6  pop r11
0000785dab1d28c8  pop r10
0000785dab1d28ca  pop r9
0000785dab1d28cc  pop r8
0000785dab1d28ce  pop rsi
0000785dab1d28cf  pop rdi
0000785dab1d28d0  pop rdx
0000785dab1d28d1  pop rcx
0000785dab1d28d2  pop rax
0000785dab1d28d3  add rsp, 0x08
0000785dab1d28d7  jmp 0x0000785DAB1CFD72
0000785dab1d28dc  sub rsp, 0x08
0000785dab1d28e0  push rax
0000785dab1d28e1  push rcx
0000785dab1d28e2  push rdx
0000785dab1d28e3  push rdi
0000785dab1d28e4  push rsi
0000785dab1d28e5  push r8
0000785dab1d28e7  push r9
0000785dab1d28e9  push r10
0000785dab1d28eb  push r11
0000785dab1d28ed  sub rsp, 0xF0
0000785dab1d28f4  vmovaps [rsp], xmm0
0000785dab1d28f9  vmovaps [rsp+0x10], xmm1
0000785dab1d28ff  vmovaps [rsp+0x20], xmm2
0000785dab1d2905  vmovaps [rsp+0x30], xmm3
0000785dab1d290b  vmovaps [rsp+0x40], xmm4
0000785dab1d2911  vmovaps [rsp+0x50], xmm5
0000785dab1d2917  vmovaps [rsp+0x60], xmm7
0000785dab1d291d  vmovaps [rsp+0x70], xmm8
0000785dab1d2923  vmovaps [rsp+0x80], xmm9
0000785dab1d292c  vmovaps [rsp+0x90], xmm10
0000785dab1d2935  vmovaps [rsp+0xA0], xmm11
0000785dab1d293e  vmovaps [rsp+0xB0], xmm12
0000785dab1d2947  vmovaps [rsp+0xC0], xmm13
0000785dab1d2950  vmovaps [rsp+0xD0], xmm14
0000785dab1d2959  vmovaps [rsp+0xE0], xmm15
0000785dab1d2962  sub rsp, 0x30
0000785dab1d2966  movaps [rsp], xmm6
0000785dab1d296a  movaps [rsp+0x10], xmm5
0000785dab1d296f  movaps [rsp+0x20], xmm1
0000785dab1d2974  lea rdi, [rsp]
0000785dab1d2978  mov esi, 0x00
0000785dab1d297d  mov rax, 0x61B13BBD6530
0000785dab1d2987  call rax
0000785dab1d2989  movaps xmm6, [rsp]
0000785dab1d298d  add rsp, 0x30
0000785dab1d2991  vmovaps xmm0, [rsp]
0000785dab1d2996  vmovaps xmm1, [rsp+0x10]
0000785dab1d299c  vmovaps xmm2, [rsp+0x20]
0000785dab1d29a2  vmovaps xmm3, [rsp+0x30]
0000785dab1d29a8  vmovaps xmm4, [rsp+0x40]
0000785dab1d29ae  vmovaps xmm5, [rsp+0x50]
0000785dab1d29b4  vmovaps xmm7, [rsp+0x60]
0000785dab1d29ba  vmovaps xmm8, [rsp+0x70]
0000785dab1d29c0  vmovaps xmm9, [rsp+0x80]
0000785dab1d29c9  vmovaps xmm10, [rsp+0x90]
0000785dab1d29d2  vmovaps xmm11, [rsp+0xA0]
0000785dab1d29db  vmovaps xmm12, [rsp+0xB0]
0000785dab1d29e4  vmovaps xmm13, [rsp+0xC0]
0000785dab1d29ed  vmovaps xmm14, [rsp+0xD0]
0000785dab1d29f6  vmovaps xmm15, [rsp+0xE0]
0000785dab1d29ff  add rsp, 0xF0
0000785dab1d2a06  pop r11
0000785dab1d2a08  pop r10
0000785dab1d2a0a  pop r9
0000785dab1d2a0c  pop r8
0000785dab1d2a0e  pop rsi
0000785dab1d2a0f  pop rdi
0000785dab1d2a10  pop rdx
0000785dab1d2a11  pop rcx
0000785dab1d2a12  pop rax
0000785dab1d2a13  add rsp, 0x08
0000785dab1d2a17  jmp 0x0000785DAB1CFD98
0000785dab1d2a1c  sub rsp, 0x08
0000785dab1d2a20  push rax
0000785dab1d2a21  push rcx
0000785dab1d2a22  push rdx
0000785dab1d2a23  push rdi
0000785dab1d2a24  push rsi
0000785dab1d2a25  push r8
0000785dab1d2a27  push r9
0000785dab1d2a29  push r10
0000785dab1d2a2b  push r11
0000785dab1d2a2d  sub rsp, 0xF0
0000785dab1d2a34  vmovaps [rsp], xmm0
0000785dab1d2a39  vmovaps [rsp+0x10], xmm2
0000785dab1d2a3f  vmovaps [rsp+0x20], xmm3
0000785dab1d2a45  vmovaps [rsp+0x30], xmm4
0000785dab1d2a4b  vmovaps [rsp+0x40], xmm5
0000785dab1d2a51  vmovaps [rsp+0x50], xmm6
0000785dab1d2a57  vmovaps [rsp+0x60], xmm7
0000785dab1d2a5d  vmovaps [rsp+0x70], xmm8
0000785dab1d2a63  vmovaps [rsp+0x80], xmm9
0000785dab1d2a6c  vmovaps [rsp+0x90], xmm10
0000785dab1d2a75  vmovaps [rsp+0xA0], xmm11
0000785dab1d2a7e  vmovaps [rsp+0xB0], xmm12
0000785dab1d2a87  vmovaps [rsp+0xC0], xmm13
0000785dab1d2a90  vmovaps [rsp+0xD0], xmm14
0000785dab1d2a99  vmovaps [rsp+0xE0], xmm15
0000785dab1d2aa2  sub rsp, 0x30
0000785dab1d2aa6  movaps [rsp], xmm1
0000785dab1d2aaa  movaps [rsp+0x10], xmm5
0000785dab1d2aaf  movaps [rsp+0x20], xmm13
0000785dab1d2ab5  lea rdi, [rsp]
0000785dab1d2ab9  mov esi, 0x00
0000785dab1d2abe  mov rax, 0x61B13BBD6530
0000785dab1d2ac8  call rax
0000785dab1d2aca  movaps xmm1, [rsp]
0000785dab1d2ace  add rsp, 0x30
0000785dab1d2ad2  vmovaps xmm0, [rsp]
0000785dab1d2ad7  vmovaps xmm2, [rsp+0x10]
0000785dab1d2add  vmovaps xmm3, [rsp+0x20]
0000785dab1d2ae3  vmovaps xmm4, [rsp+0x30]
0000785dab1d2ae9  vmovaps xmm5, [rsp+0x40]
0000785dab1d2aef  vmovaps xmm6, [rsp+0x50]
0000785dab1d2af5  vmovaps xmm7, [rsp+0x60]
0000785dab1d2afb  vmovaps xmm8, [rsp+0x70]
0000785dab1d2b01  vmovaps xmm9, [rsp+0x80]
0000785dab1d2b0a  vmovaps xmm10, [rsp+0x90]
0000785dab1d2b13  vmovaps xmm11, [rsp+0xA0]
0000785dab1d2b1c  vmovaps xmm12, [rsp+0xB0]
0000785dab1d2b25  vmovaps xmm13, [rsp+0xC0]
0000785dab1d2b2e  vmovaps xmm14, [rsp+0xD0]
0000785dab1d2b37  vmovaps xmm15, [rsp+0xE0]
0000785dab1d2b40  add rsp, 0xF0
0000785dab1d2b47  pop r11
0000785dab1d2b49  pop r10
0000785dab1d2b4b  pop r9
0000785dab1d2b4d  pop r8
0000785dab1d2b4f  pop rsi
0000785dab1d2b50  pop rdi
0000785dab1d2b51  pop rdx
0000785dab1d2b52  pop rcx
0000785dab1d2b53  pop rax
0000785dab1d2b54  add rsp, 0x08
0000785dab1d2b58  jmp 0x0000785DAB1CFDB6
0000785dab1d2b5d  sub rsp, 0x08
0000785dab1d2b61  push rax
0000785dab1d2b62  push rcx
0000785dab1d2b63  push rdx
0000785dab1d2b64  push rdi
0000785dab1d2b65  push rsi
0000785dab1d2b66  push r8
0000785dab1d2b68  push r9
0000785dab1d2b6a  push r10
0000785dab1d2b6c  push r11
0000785dab1d2b6e  sub rsp, 0xF0
0000785dab1d2b75  vmovaps [rsp], xmm0
0000785dab1d2b7a  vmovaps [rsp+0x10], xmm1
0000785dab1d2b80  vmovaps [rsp+0x20], xmm2
0000785dab1d2b86  vmovaps [rsp+0x30], xmm3
0000785dab1d2b8c  vmovaps [rsp+0x40], xmm4
0000785dab1d2b92  vmovaps [rsp+0x50], xmm6
0000785dab1d2b98  vmovaps [rsp+0x60], xmm7
0000785dab1d2b9e  vmovaps [rsp+0x70], xmm8
0000785dab1d2ba4  vmovaps [rsp+0x80], xmm9
0000785dab1d2bad  vmovaps [rsp+0x90], xmm10
0000785dab1d2bb6  vmovaps [rsp+0xA0], xmm11
0000785dab1d2bbf  vmovaps [rsp+0xB0], xmm12
0000785dab1d2bc8  vmovaps [rsp+0xC0], xmm13
0000785dab1d2bd1  vmovaps [rsp+0xD0], xmm14
0000785dab1d2bda  vmovaps [rsp+0xE0], xmm15
0000785dab1d2be3  sub rsp, 0x30
0000785dab1d2be7  movaps [rsp], xmm5
0000785dab1d2beb  movaps [rsp+0x10], xmm2
0000785dab1d2bf0  movaps [rsp+0x20], xmm13
0000785dab1d2bf6  lea rdi, [rsp]
0000785dab1d2bfa  mov esi, 0x00
0000785dab1d2bff  mov rax, 0x61B13BBD6530
0000785dab1d2c09  call rax
0000785dab1d2c0b  movaps xmm5, [rsp]
0000785dab1d2c0f  add rsp, 0x30
0000785dab1d2c13  vmovaps xmm0, [rsp]
0000785dab1d2c18  vmovaps xmm1, [rsp+0x10]
0000785dab1d2c1e  vmovaps xmm2, [rsp+0x20]
0000785dab1d2c24  vmovaps xmm3, [rsp+0x30]
0000785dab1d2c2a  vmovaps xmm4, [rsp+0x40]
0000785dab1d2c30  vmovaps xmm6, [rsp+0x50]
0000785dab1d2c36  vmovaps xmm7, [rsp+0x60]
0000785dab1d2c3c  vmovaps xmm8, [rsp+0x70]
0000785dab1d2c42  vmovaps xmm9, [rsp+0x80]
0000785dab1d2c4b  vmovaps xmm10, [rsp+0x90]
0000785dab1d2c54  vmovaps xmm11, [rsp+0xA0]
0000785dab1d2c5d  vmovaps xmm12, [rsp+0xB0]
0000785dab1d2c66  vmovaps xmm13, [rsp+0xC0]
0000785dab1d2c6f  vmovaps xmm14, [rsp+0xD0]
0000785dab1d2c78  vmovaps xmm15, [rsp+0xE0]
0000785dab1d2c81  add rsp, 0xF0
0000785dab1d2c88  pop r11
0000785dab1d2c8a  pop r10
0000785dab1d2c8c  pop r9
0000785dab1d2c8e  pop r8
0000785dab1d2c90  pop rsi
0000785dab1d2c91  pop rdi
0000785dab1d2c92  pop rdx
0000785dab1d2c93  pop rcx
0000785dab1d2c94  pop rax
0000785dab1d2c95  add rsp, 0x08
0000785dab1d2c99  jmp 0x0000785DAB1CFDEC
0000785dab1d2c9e  sub rsp, 0x08
0000785dab1d2ca2  push rax
0000785dab1d2ca3  push rcx
0000785dab1d2ca4  push rdx
0000785dab1d2ca5  push rdi
0000785dab1d2ca6  push rsi
0000785dab1d2ca7  push r8
0000785dab1d2ca9  push r9
0000785dab1d2cab  push r10
0000785dab1d2cad  push r11
0000785dab1d2caf  sub rsp, 0xF0
0000785dab1d2cb6  vmovaps [rsp], xmm0
0000785dab1d2cbb  vmovaps [rsp+0x10], xmm1
0000785dab1d2cc1  vmovaps [rsp+0x20], xmm2
0000785dab1d2cc7  vmovaps [rsp+0x30], xmm3
0000785dab1d2ccd  vmovaps [rsp+0x40], xmm4
0000785dab1d2cd3  vmovaps [rsp+0x50], xmm5
0000785dab1d2cd9  vmovaps [rsp+0x60], xmm6
0000785dab1d2cdf  vmovaps [rsp+0x70], xmm7
0000785dab1d2ce5  vmovaps [rsp+0x80], xmm8
0000785dab1d2cee  vmovaps [rsp+0x90], xmm9
0000785dab1d2cf7  vmovaps [rsp+0xA0], xmm10
0000785dab1d2d00  vmovaps [rsp+0xB0], xmm11
0000785dab1d2d09  vmovaps [rsp+0xC0], xmm12
0000785dab1d2d12  vmovaps [rsp+0xD0], xmm14
0000785dab1d2d1b  vmovaps [rsp+0xE0], xmm15
0000785dab1d2d24  sub rsp, 0x30
0000785dab1d2d28  movaps [rsp], xmm13
0000785dab1d2d2d  movaps [rsp+0x10], xmm10
0000785dab1d2d33  movaps [rsp+0x20], xmm1
0000785dab1d2d38  lea rdi, [rsp]
0000785dab1d2d3c  mov esi, 0x00
0000785dab1d2d41  mov rax, 0x61B13BBD6530
0000785dab1d2d4b  call rax
0000785dab1d2d4d  movaps xmm13, [rsp]
0000785dab1d2d52  add rsp, 0x30
0000785dab1d2d56  vmovaps xmm0, [rsp]
0000785dab1d2d5b  vmovaps xmm1, [rsp+0x10]
0000785dab1d2d61  vmovaps xmm2, [rsp+0x20]
0000785dab1d2d67  vmovaps xmm3, [rsp+0x30]
0000785dab1d2d6d  vmovaps xmm4, [rsp+0x40]
0000785dab1d2d73  vmovaps xmm5, [rsp+0x50]
0000785dab1d2d79  vmovaps xmm6, [rsp+0x60]
0000785dab1d2d7f  vmovaps xmm7, [rsp+0x70]
0000785dab1d2d85  vmovaps xmm8, [rsp+0x80]
0000785dab1d2d8e  vmovaps xmm9, [rsp+0x90]
0000785dab1d2d97  vmovaps xmm10, [rsp+0xA0]
0000785dab1d2da0  vmovaps xmm11, [rsp+0xB0]
0000785dab1d2da9  vmovaps xmm12, [rsp+0xC0]
0000785dab1d2db2  vmovaps xmm14, [rsp+0xD0]
0000785dab1d2dbb  vmovaps xmm15, [rsp+0xE0]
0000785dab1d2dc4  add rsp, 0xF0
0000785dab1d2dcb  pop r11
0000785dab1d2dcd  pop r10
0000785dab1d2dcf  pop r9
0000785dab1d2dd1  pop r8
0000785dab1d2dd3  pop rsi
0000785dab1d2dd4  pop rdi
0000785dab1d2dd5  pop rdx
0000785dab1d2dd6  pop rcx
0000785dab1d2dd7  pop rax
0000785dab1d2dd8  add rsp, 0x08
0000785dab1d2ddc  jmp 0x0000785DAB1CFE15
0000785dab1d2de1  sub rsp, 0x08
0000785dab1d2de5  push rax
0000785dab1d2de6  push rcx
0000785dab1d2de7  push rdx
0000785dab1d2de8  push rdi
0000785dab1d2de9  push rsi
0000785dab1d2dea  push r8
0000785dab1d2dec  push r9
0000785dab1d2dee  push r10
0000785dab1d2df0  push r11
0000785dab1d2df2  sub rsp, 0xF0
0000785dab1d2df9  vmovaps [rsp], xmm0
0000785dab1d2dfe  vmovaps [rsp+0x10], xmm2
0000785dab1d2e04  vmovaps [rsp+0x20], xmm3
0000785dab1d2e0a  vmovaps [rsp+0x30], xmm4
0000785dab1d2e10  vmovaps [rsp+0x40], xmm5
0000785dab1d2e16  vmovaps [rsp+0x50], xmm6
0000785dab1d2e1c  vmovaps [rsp+0x60], xmm7
0000785dab1d2e22  vmovaps [rsp+0x70], xmm8
0000785dab1d2e28  vmovaps [rsp+0x80], xmm9
0000785dab1d2e31  vmovaps [rsp+0x90], xmm10
0000785dab1d2e3a  vmovaps [rsp+0xA0], xmm11
0000785dab1d2e43  vmovaps [rsp+0xB0], xmm12
0000785dab1d2e4c  vmovaps [rsp+0xC0], xmm13
0000785dab1d2e55  vmovaps [rsp+0xD0], xmm14
0000785dab1d2e5e  vmovaps [rsp+0xE0], xmm15
0000785dab1d2e67  sub rsp, 0x30
0000785dab1d2e6b  movaps [rsp], xmm1
0000785dab1d2e6f  movaps [rsp+0x10], xmm15
0000785dab1d2e75  movaps [rsp+0x20], xmm10
0000785dab1d2e7b  lea rdi, [rsp]
0000785dab1d2e7f  mov esi, 0x00
0000785dab1d2e84  mov rax, 0x61B13BBD6530
0000785dab1d2e8e  call rax
0000785dab1d2e90  movaps xmm1, [rsp]
0000785dab1d2e94  add rsp, 0x30
0000785dab1d2e98  vmovaps xmm0, [rsp]
0000785dab1d2e9d  vmovaps xmm2, [rsp+0x10]
0000785dab1d2ea3  vmovaps xmm3, [rsp+0x20]
0000785dab1d2ea9  vmovaps xmm4, [rsp+0x30]
0000785dab1d2eaf  vmovaps xmm5, [rsp+0x40]
0000785dab1d2eb5  vmovaps xmm6, [rsp+0x50]
0000785dab1d2ebb  vmovaps xmm7, [rsp+0x60]
0000785dab1d2ec1  vmovaps xmm8, [rsp+0x70]
0000785dab1d2ec7  vmovaps xmm9, [rsp+0x80]
0000785dab1d2ed0  vmovaps xmm10, [rsp+0x90]
0000785dab1d2ed9  vmovaps xmm11, [rsp+0xA0]
0000785dab1d2ee2  vmovaps xmm12, [rsp+0xB0]
0000785dab1d2eeb  vmovaps xmm13, [rsp+0xC0]
0000785dab1d2ef4  vmovaps xmm14, [rsp+0xD0]
0000785dab1d2efd  vmovaps xmm15, [rsp+0xE0]
0000785dab1d2f06  add rsp, 0xF0
0000785dab1d2f0d  pop r11
0000785dab1d2f0f  pop r10
0000785dab1d2f11  pop r9
0000785dab1d2f13  pop r8
0000785dab1d2f15  pop rsi
0000785dab1d2f16  pop rdi
0000785dab1d2f17  pop rdx
0000785dab1d2f18  pop rcx
0000785dab1d2f19  pop rax
0000785dab1d2f1a  add rsp, 0x08
0000785dab1d2f1e  jmp 0x0000785DAB1CFE34
0000785dab1d2f23  sub rsp, 0x08
0000785dab1d2f27  push rax
0000785dab1d2f28  push rcx
0000785dab1d2f29  push rdx
0000785dab1d2f2a  push rdi
0000785dab1d2f2b  push rsi
0000785dab1d2f2c  push r8
0000785dab1d2f2e  push r9
0000785dab1d2f30  push r10
0000785dab1d2f32  push r11
0000785dab1d2f34  sub rsp, 0xF0
0000785dab1d2f3b  vmovaps [rsp], xmm0
0000785dab1d2f40  vmovaps [rsp+0x10], xmm1
0000785dab1d2f46  vmovaps [rsp+0x20], xmm2
0000785dab1d2f4c  vmovaps [rsp+0x30], xmm3
0000785dab1d2f52  vmovaps [rsp+0x40], xmm4
0000785dab1d2f58  vmovaps [rsp+0x50], xmm5
0000785dab1d2f5e  vmovaps [rsp+0x60], xmm6
0000785dab1d2f64  vmovaps [rsp+0x70], xmm7
0000785dab1d2f6a  vmovaps [rsp+0x80], xmm8
0000785dab1d2f73  vmovaps [rsp+0x90], xmm9
0000785dab1d2f7c  vmovaps [rsp+0xA0], xmm10
0000785dab1d2f85  vmovaps [rsp+0xB0], xmm11
0000785dab1d2f8e  vmovaps [rsp+0xC0], xmm12
0000785dab1d2f97  vmovaps [rsp+0xD0], xmm13
0000785dab1d2fa0  vmovaps [rsp+0xE0], xmm14
0000785dab1d2fa9  sub rsp, 0x30
0000785dab1d2fad  movaps [rsp], xmm15
0000785dab1d2fb2  movaps [rsp+0x10], xmm10
0000785dab1d2fb8  movaps [rsp+0x20], xmm11
0000785dab1d2fbe  lea rdi, [rsp]
0000785dab1d2fc2  mov esi, 0x00
0000785dab1d2fc7  mov rax, 0x61B13BBD6530
0000785dab1d2fd1  call rax
0000785dab1d2fd3  movaps xmm15, [rsp]
0000785dab1d2fd8  add rsp, 0x30
0000785dab1d2fdc  vmovaps xmm0, [rsp]
0000785dab1d2fe1  vmovaps xmm1, [rsp+0x10]
0000785dab1d2fe7  vmovaps xmm2, [rsp+0x20]
0000785dab1d2fed  vmovaps xmm3, [rsp+0x30]
0000785dab1d2ff3  vmovaps xmm4, [rsp+0x40]
0000785dab1d2ff9  vmovaps xmm5, [rsp+0x50]
0000785dab1d2fff  vmovaps xmm6, [rsp+0x60]
0000785dab1d3005  vmovaps xmm7, [rsp+0x70]
0000785dab1d300b  vmovaps xmm8, [rsp+0x80]
0000785dab1d3014  vmovaps xmm9, [rsp+0x90]
0000785dab1d301d  vmovaps xmm10, [rsp+0xA0]
0000785dab1d3026  vmovaps xmm11, [rsp+0xB0]
0000785dab1d302f  vmovaps xmm12, [rsp+0xC0]
0000785dab1d3038  vmovaps xmm13, [rsp+0xD0]
0000785dab1d3041  vmovaps xmm14, [rsp+0xE0]
0000785dab1d304a  add rsp, 0xF0
0000785dab1d3051  pop r11
0000785dab1d3053  pop r10
0000785dab1d3055  pop r9
0000785dab1d3057  pop r8
0000785dab1d3059  pop rsi
0000785dab1d305a  pop rdi
0000785dab1d305b  pop rdx
0000785dab1d305c  pop rcx
0000785dab1d305d  pop rax
0000785dab1d305e  add rsp, 0x08
0000785dab1d3062  jmp 0x0000785DAB1CFE57
0000785dab1d3067  sub rsp, 0x08
0000785dab1d306b  push rax
0000785dab1d306c  push rcx
0000785dab1d306d  push rdx
0000785dab1d306e  push rdi
0000785dab1d306f  push rsi
0000785dab1d3070  push r8
0000785dab1d3072  push r9
0000785dab1d3074  push r10
0000785dab1d3076  push r11
0000785dab1d3078  sub rsp, 0xF0
0000785dab1d307f  vmovaps [rsp], xmm0
0000785dab1d3084  vmovaps [rsp+0x10], xmm1
0000785dab1d308a  vmovaps [rsp+0x20], xmm2
0000785dab1d3090  vmovaps [rsp+0x30], xmm3
0000785dab1d3096  vmovaps [rsp+0x40], xmm4
0000785dab1d309c  vmovaps [rsp+0x50], xmm5
0000785dab1d30a2  vmovaps [rsp+0x60], xmm6
0000785dab1d30a8  vmovaps [rsp+0x70], xmm7
0000785dab1d30ae  vmovaps [rsp+0x80], xmm8
0000785dab1d30b7  vmovaps [rsp+0x90], xmm9
0000785dab1d30c0  vmovaps [rsp+0xA0], xmm11
0000785dab1d30c9  vmovaps [rsp+0xB0], xmm12
0000785dab1d30d2  vmovaps [rsp+0xC0], xmm13
0000785dab1d30db  vmovaps [rsp+0xD0], xmm14
0000785dab1d30e4  vmovaps [rsp+0xE0], xmm15
0000785dab1d30ed  sub rsp, 0x30
0000785dab1d30f1  movaps [rsp], xmm10
0000785dab1d30f6  movaps [rsp+0x10], xmm12
0000785dab1d30fc  movaps [rsp+0x20], xmm11
0000785dab1d3102  lea rdi, [rsp]
0000785dab1d3106  mov esi, 0x00
0000785dab1d310b  mov rax, 0x61B13BBD6530
0000785dab1d3115  call rax
0000785dab1d3117  movaps xmm10, [rsp]
0000785dab1d311c  add rsp, 0x30
0000785dab1d3120  vmovaps xmm0, [rsp]
0000785dab1d3125  vmovaps xmm1, [rsp+0x10]
0000785dab1d312b  vmovaps xmm2, [rsp+0x20]
0000785dab1d3131  vmovaps xmm3, [rsp+0x30]
0000785dab1d3137  vmovaps xmm4, [rsp+0x40]
0000785dab1d313d  vmovaps xmm5, [rsp+0x50]
0000785dab1d3143  vmovaps xmm6, [rsp+0x60]
0000785dab1d3149  vmovaps xmm7, [rsp+0x70]
0000785dab1d314f  vmovaps xmm8, [rsp+0x80]
0000785dab1d3158  vmovaps xmm9, [rsp+0x90]
0000785dab1d3161  vmovaps xmm11, [rsp+0xA0]
0000785dab1d316a  vmovaps xmm12, [rsp+0xB0]
0000785dab1d3173  vmovaps xmm13, [rsp+0xC0]
0000785dab1d317c  vmovaps xmm14, [rsp+0xD0]
0000785dab1d3185  vmovaps xmm15, [rsp+0xE0]
0000785dab1d318e  add rsp, 0xF0
0000785dab1d3195  pop r11
0000785dab1d3197  pop r10
0000785dab1d3199  pop r9
0000785dab1d319b  pop r8
0000785dab1d319d  pop rsi
0000785dab1d319e  pop rdi
0000785dab1d319f  pop rdx
0000785dab1d31a0  pop rcx
0000785dab1d31a1  pop rax
0000785dab1d31a2  add rsp, 0x08
0000785dab1d31a6  jmp 0x0000785DAB1CFE80
0000785dab1d31ab  sub rsp, 0x08
0000785dab1d31af  push rax
0000785dab1d31b0  push rcx
0000785dab1d31b1  push rdx
0000785dab1d31b2  push rdi
0000785dab1d31b3  push rsi
0000785dab1d31b4  push r8
0000785dab1d31b6  push r9
0000785dab1d31b8  push r10
0000785dab1d31ba  push r11
0000785dab1d31bc  sub rsp, 0xF0
0000785dab1d31c3  vmovaps [rsp], xmm0
0000785dab1d31c8  vmovaps [rsp+0x10], xmm1
0000785dab1d31ce  vmovaps [rsp+0x20], xmm2
0000785dab1d31d4  vmovaps [rsp+0x30], xmm3
0000785dab1d31da  vmovaps [rsp+0x40], xmm4
0000785dab1d31e0  vmovaps [rsp+0x50], xmm5
0000785dab1d31e6  vmovaps [rsp+0x60], xmm6
0000785dab1d31ec  vmovaps [rsp+0x70], xmm7
0000785dab1d31f2  vmovaps [rsp+0x80], xmm8
0000785dab1d31fb  vmovaps [rsp+0x90], xmm9
0000785dab1d3204  vmovaps [rsp+0xA0], xmm10
0000785dab1d320d  vmovaps [rsp+0xB0], xmm12
0000785dab1d3216  vmovaps [rsp+0xC0], xmm13
0000785dab1d321f  vmovaps [rsp+0xD0], xmm14
0000785dab1d3228  vmovaps [rsp+0xE0], xmm15
0000785dab1d3231  sub rsp, 0x30
0000785dab1d3235  movaps [rsp], xmm11
0000785dab1d323a  movaps [rsp+0x10], xmm2
0000785dab1d323f  movaps [rsp+0x20], xmm12
0000785dab1d3245  lea rdi, [rsp]
0000785dab1d3249  mov esi, 0x00
0000785dab1d324e  mov rax, 0x61B13BBD6530
0000785dab1d3258  call rax
0000785dab1d325a  movaps xmm11, [rsp]
0000785dab1d325f  add rsp, 0x30
0000785dab1d3263  vmovaps xmm0, [rsp]
0000785dab1d3268  vmovaps xmm1, [rsp+0x10]
0000785dab1d326e  vmovaps xmm2, [rsp+0x20]
0000785dab1d3274  vmovaps xmm3, [rsp+0x30]
0000785dab1d327a  vmovaps xmm4, [rsp+0x40]
0000785dab1d3280  vmovaps xmm5, [rsp+0x50]
0000785dab1d3286  vmovaps xmm6, [rsp+0x60]
0000785dab1d328c  vmovaps xmm7, [rsp+0x70]
0000785dab1d3292  vmovaps xmm8, [rsp+0x80]
0000785dab1d329b  vmovaps xmm9, [rsp+0x90]
0000785dab1d32a4  vmovaps xmm10, [rsp+0xA0]
0000785dab1d32ad  vmovaps xmm12, [rsp+0xB0]
0000785dab1d32b6  vmovaps xmm13, [rsp+0xC0]
0000785dab1d32bf  vmovaps xmm14, [rsp+0xD0]
0000785dab1d32c8  vmovaps xmm15, [rsp+0xE0]
0000785dab1d32d1  add rsp, 0xF0
0000785dab1d32d8  pop r11
0000785dab1d32da  pop r10
0000785dab1d32dc  pop r9
0000785dab1d32de  pop r8
0000785dab1d32e0  pop rsi
0000785dab1d32e1  pop rdi
0000785dab1d32e2  pop rdx
0000785dab1d32e3  pop rcx
0000785dab1d32e4  pop rax
0000785dab1d32e5  add rsp, 0x08
0000785dab1d32e9  jmp 0x0000785DAB1CFEB8
0000785dab1d32ee  sub rsp, 0x08
0000785dab1d32f2  push rax
0000785dab1d32f3  push rcx
0000785dab1d32f4  push rdx
0000785dab1d32f5  push rdi
0000785dab1d32f6  push rsi
0000785dab1d32f7  push r8
0000785dab1d32f9  push r9
0000785dab1d32fb  push r10
0000785dab1d32fd  push r11
0000785dab1d32ff  sub rsp, 0xF0
0000785dab1d3306  vmovaps [rsp], xmm0
0000785dab1d330b  vmovaps [rsp+0x10], xmm2
0000785dab1d3311  vmovaps [rsp+0x20], xmm3
0000785dab1d3317  vmovaps [rsp+0x30], xmm4
0000785dab1d331d  vmovaps [rsp+0x40], xmm5
0000785dab1d3323  vmovaps [rsp+0x50], xmm6
0000785dab1d3329  vmovaps [rsp+0x60], xmm7
0000785dab1d332f  vmovaps [rsp+0x70], xmm8
0000785dab1d3335  vmovaps [rsp+0x80], xmm9
0000785dab1d333e  vmovaps [rsp+0x90], xmm10
0000785dab1d3347  vmovaps [rsp+0xA0], xmm11
0000785dab1d3350  vmovaps [rsp+0xB0], xmm12
0000785dab1d3359  vmovaps [rsp+0xC0], xmm13
0000785dab1d3362  vmovaps [rsp+0xD0], xmm14
0000785dab1d336b  vmovaps [rsp+0xE0], xmm15
0000785dab1d3374  sub rsp, 0x30
0000785dab1d3378  movaps [rsp], xmm1
0000785dab1d337c  movaps [rsp+0x10], xmm14
0000785dab1d3382  movaps [rsp+0x20], xmm6
0000785dab1d3387  lea rdi, [rsp]
0000785dab1d338b  mov esi, 0x00
0000785dab1d3390  mov rax, 0x61B13BBD6530
0000785dab1d339a  call rax
0000785dab1d339c  movaps xmm1, [rsp]
0000785dab1d33a0  add rsp, 0x30
0000785dab1d33a4  vmovaps xmm0, [rsp]
0000785dab1d33a9  vmovaps xmm2, [rsp+0x10]
0000785dab1d33af  vmovaps xmm3, [rsp+0x20]
0000785dab1d33b5  vmovaps xmm4, [rsp+0x30]
0000785dab1d33bb  vmovaps xmm5, [rsp+0x40]
0000785dab1d33c1  vmovaps xmm6, [rsp+0x50]
0000785dab1d33c7  vmovaps xmm7, [rsp+0x60]
0000785dab1d33cd  vmovaps xmm8, [rsp+0x70]
0000785dab1d33d3  vmovaps xmm9, [rsp+0x80]
0000785dab1d33dc  vmovaps xmm10, [rsp+0x90]
0000785dab1d33e5  vmovaps xmm11, [rsp+0xA0]
0000785dab1d33ee  vmovaps xmm12, [rsp+0xB0]
0000785dab1d33f7  vmovaps xmm13, [rsp+0xC0]
0000785dab1d3400  vmovaps xmm14, [rsp+0xD0]
0000785dab1d3409  vmovaps xmm15, [rsp+0xE0]
0000785dab1d3412  add rsp, 0xF0
0000785dab1d3419  pop r11
0000785dab1d341b  pop r10
0000785dab1d341d  pop r9
0000785dab1d341f  pop r8
0000785dab1d3421  pop rsi
0000785dab1d3422  pop rdi
0000785dab1d3423  pop rdx
0000785dab1d3424  pop rcx
0000785dab1d3425  pop rax
0000785dab1d3426  add rsp, 0x08
0000785dab1d342a  jmp 0x0000785DAB1CFED1
0000785dab1d342f  sub rsp, 0x08
0000785dab1d3433  push rax
0000785dab1d3434  push rcx
0000785dab1d3435  push rdx
0000785dab1d3436  push rdi
0000785dab1d3437  push rsi
0000785dab1d3438  push r8
0000785dab1d343a  push r9
0000785dab1d343c  push r10
0000785dab1d343e  push r11
0000785dab1d3440  sub rsp, 0xF0
0000785dab1d3447  vmovaps [rsp], xmm0
0000785dab1d344c  vmovaps [rsp+0x10], xmm1
0000785dab1d3452  vmovaps [rsp+0x20], xmm2
0000785dab1d3458  vmovaps [rsp+0x30], xmm3
0000785dab1d345e  vmovaps [rsp+0x40], xmm4
0000785dab1d3464  vmovaps [rsp+0x50], xmm5
0000785dab1d346a  vmovaps [rsp+0x60], xmm6
0000785dab1d3470  vmovaps [rsp+0x70], xmm7
0000785dab1d3476  vmovaps [rsp+0x80], xmm8
0000785dab1d347f  vmovaps [rsp+0x90], xmm9
0000785dab1d3488  vmovaps [rsp+0xA0], xmm10
0000785dab1d3491  vmovaps [rsp+0xB0], xmm11
0000785dab1d349a  vmovaps [rsp+0xC0], xmm12
0000785dab1d34a3  vmovaps [rsp+0xD0], xmm13
0000785dab1d34ac  vmovaps [rsp+0xE0], xmm15
0000785dab1d34b5  sub rsp, 0x30
0000785dab1d34b9  movaps [rsp], xmm14
0000785dab1d34be  movaps [rsp+0x10], xmm12
0000785dab1d34c4  movaps [rsp+0x20], xmm5
0000785dab1d34c9  lea rdi, [rsp]
0000785dab1d34cd  mov esi, 0x00
0000785dab1d34d2  mov rax, 0x61B13BBD6530
0000785dab1d34dc  call rax
0000785dab1d34de  movaps xmm14, [rsp]
0000785dab1d34e3  add rsp, 0x30
0000785dab1d34e7  vmovaps xmm0, [rsp]
0000785dab1d34ec  vmovaps xmm1, [rsp+0x10]
0000785dab1d34f2  vmovaps xmm2, [rsp+0x20]
0000785dab1d34f8  vmovaps xmm3, [rsp+0x30]
0000785dab1d34fe  vmovaps xmm4, [rsp+0x40]
0000785dab1d3504  vmovaps xmm5, [rsp+0x50]
0000785dab1d350a  vmovaps xmm6, [rsp+0x60]
0000785dab1d3510  vmovaps xmm7, [rsp+0x70]
0000785dab1d3516  vmovaps xmm8, [rsp+0x80]
0000785dab1d351f  vmovaps xmm9, [rsp+0x90]
0000785dab1d3528  vmovaps xmm10, [rsp+0xA0]
0000785dab1d3531  vmovaps xmm11, [rsp+0xB0]
0000785dab1d353a  vmovaps xmm12, [rsp+0xC0]
0000785dab1d3543  vmovaps xmm13, [rsp+0xD0]
0000785dab1d354c  vmovaps xmm15, [rsp+0xE0]
0000785dab1d3555  add rsp, 0xF0
0000785dab1d355c  pop r11
0000785dab1d355e  pop r10
0000785dab1d3560  pop r9
0000785dab1d3562  pop r8
0000785dab1d3564  pop rsi
0000785dab1d3565  pop rdi
0000785dab1d3566  pop rdx
0000785dab1d3567  pop rcx
0000785dab1d3568  pop rax
0000785dab1d3569  add rsp, 0x08
0000785dab1d356d  jmp 0x0000785DAB1CFEF1
0000785dab1d3572  sub rsp, 0x08
0000785dab1d3576  push rax
0000785dab1d3577  push rcx
0000785dab1d3578  push rdx
0000785dab1d3579  push rdi
0000785dab1d357a  push rsi
0000785dab1d357b  push r8
0000785dab1d357d  push r9
0000785dab1d357f  push r10
0000785dab1d3581  push r11
0000785dab1d3583  sub rsp, 0xF0
0000785dab1d358a  vmovaps [rsp], xmm0
0000785dab1d358f  vmovaps [rsp+0x10], xmm1
0000785dab1d3595  vmovaps [rsp+0x20], xmm2
0000785dab1d359b  vmovaps [rsp+0x30], xmm3
0000785dab1d35a1  vmovaps [rsp+0x40], xmm4
0000785dab1d35a7  vmovaps [rsp+0x50], xmm5
0000785dab1d35ad  vmovaps [rsp+0x60], xmm7
0000785dab1d35b3  vmovaps [rsp+0x70], xmm8
0000785dab1d35b9  vmovaps [rsp+0x80], xmm9
0000785dab1d35c2  vmovaps [rsp+0x90], xmm10
0000785dab1d35cb  vmovaps [rsp+0xA0], xmm11
0000785dab1d35d4  vmovaps [rsp+0xB0], xmm12
0000785dab1d35dd  vmovaps [rsp+0xC0], xmm13
0000785dab1d35e6  vmovaps [rsp+0xD0], xmm14
0000785dab1d35ef  vmovaps [rsp+0xE0], xmm15
0000785dab1d35f8  sub rsp, 0x30
0000785dab1d35fc  movaps [rsp], xmm6
0000785dab1d3600  movaps [rsp+0x10], xmm9
0000785dab1d3606  movaps [rsp+0x20], xmm12
0000785dab1d360c  lea rdi, [rsp]
0000785dab1d3610  mov esi, 0x00
0000785dab1d3615  mov rax, 0x61B13BBD6530
0000785dab1d361f  call rax
0000785dab1d3621  movaps xmm6, [rsp]
0000785dab1d3625  add rsp, 0x30
0000785dab1d3629  vmovaps xmm0, [rsp]
0000785dab1d362e  vmovaps xmm1, [rsp+0x10]
0000785dab1d3634  vmovaps xmm2, [rsp+0x20]
0000785dab1d363a  vmovaps xmm3, [rsp+0x30]
0000785dab1d3640  vmovaps xmm4, [rsp+0x40]
0000785dab1d3646  vmovaps xmm5, [rsp+0x50]
0000785dab1d364c  vmovaps xmm7, [rsp+0x60]
0000785dab1d3652  vmovaps xmm8, [rsp+0x70]
0000785dab1d3658  vmovaps xmm9, [rsp+0x80]
0000785dab1d3661  vmovaps xmm10, [rsp+0x90]
0000785dab1d366a  vmovaps xmm11, [rsp+0xA0]
0000785dab1d3673  vmovaps xmm12, [rsp+0xB0]
0000785dab1d367c  vmovaps xmm13, [rsp+0xC0]
0000785dab1d3685  vmovaps xmm14, [rsp+0xD0]
0000785dab1d368e  vmovaps xmm15, [rsp+0xE0]
0000785dab1d3697  add rsp, 0xF0
0000785dab1d369e  pop r11
0000785dab1d36a0  pop r10
0000785dab1d36a2  pop r9
0000785dab1d36a4  pop r8
0000785dab1d36a6  pop rsi
0000785dab1d36a7  pop rdi
0000785dab1d36a8  pop rdx
0000785dab1d36a9  pop rcx
0000785dab1d36aa  pop rax
0000785dab1d36ab  add rsp, 0x08
0000785dab1d36af  jmp 0x0000785DAB1CFF19
0000785dab1d36b4  sub rsp, 0x08
0000785dab1d36b8  push rax
0000785dab1d36b9  push rcx
0000785dab1d36ba  push rdx
0000785dab1d36bb  push rdi
0000785dab1d36bc  push rsi
0000785dab1d36bd  push r8
0000785dab1d36bf  push r9
0000785dab1d36c1  push r10
0000785dab1d36c3  push r11
0000785dab1d36c5  sub rsp, 0xF0
0000785dab1d36cc  vmovaps [rsp], xmm0
0000785dab1d36d1  vmovaps [rsp+0x10], xmm1
0000785dab1d36d7  vmovaps [rsp+0x20], xmm2
0000785dab1d36dd  vmovaps [rsp+0x30], xmm3
0000785dab1d36e3  vmovaps [rsp+0x40], xmm4
0000785dab1d36e9  vmovaps [rsp+0x50], xmm5
0000785dab1d36ef  vmovaps [rsp+0x60], xmm6
0000785dab1d36f5  vmovaps [rsp+0x70], xmm7
0000785dab1d36fb  vmovaps [rsp+0x80], xmm8
0000785dab1d3704  vmovaps [rsp+0x90], xmm9
0000785dab1d370d  vmovaps [rsp+0xA0], xmm10
0000785dab1d3716  vmovaps [rsp+0xB0], xmm11
0000785dab1d371f  vmovaps [rsp+0xC0], xmm13
0000785dab1d3728  vmovaps [rsp+0xD0], xmm14
0000785dab1d3731  vmovaps [rsp+0xE0], xmm15
0000785dab1d373a  sub rsp, 0x30
0000785dab1d373e  movaps [rsp], xmm12
0000785dab1d3743  movaps [rsp+0x10], xmm15
0000785dab1d3749  movaps [rsp+0x20], xmm13
0000785dab1d374f  lea rdi, [rsp]
0000785dab1d3753  mov esi, 0x00
0000785dab1d3758  mov rax, 0x61B13BBD6530
0000785dab1d3762  call rax
0000785dab1d3764  movaps xmm12, [rsp]
0000785dab1d3769  add rsp, 0x30
0000785dab1d376d  vmovaps xmm0, [rsp]
0000785dab1d3772  vmovaps xmm1, [rsp+0x10]
0000785dab1d3778  vmovaps xmm2, [rsp+0x20]
0000785dab1d377e  vmovaps xmm3, [rsp+0x30]
0000785dab1d3784  vmovaps xmm4, [rsp+0x40]
0000785dab1d378a  vmovaps xmm5, [rsp+0x50]
0000785dab1d3790  vmovaps xmm6, [rsp+0x60]
0000785dab1d3796  vmovaps xmm7, [rsp+0x70]
0000785dab1d379c  vmovaps xmm8, [rsp+0x80]
0000785dab1d37a5  vmovaps xmm9, [rsp+0x90]
0000785dab1d37ae  vmovaps xmm10, [rsp+0xA0]
0000785dab1d37b7  vmovaps xmm11, [rsp+0xB0]
0000785dab1d37c0  vmovaps xmm13, [rsp+0xC0]
0000785dab1d37c9  vmovaps xmm14, [rsp+0xD0]
0000785dab1d37d2  vmovaps xmm15, [rsp+0xE0]
0000785dab1d37db  add rsp, 0xF0
0000785dab1d37e2  pop r11
0000785dab1d37e4  pop r10
0000785dab1d37e6  pop r9
0000785dab1d37e8  pop r8
0000785dab1d37ea  pop rsi
0000785dab1d37eb  pop rdi
0000785dab1d37ec  pop rdx
0000785dab1d37ed  pop rcx
0000785dab1d37ee  pop rax
0000785dab1d37ef  add rsp, 0x08
0000785dab1d37f3  jmp 0x0000785DAB1CFF34
0000785dab1d37f8  sub rsp, 0x08
0000785dab1d37fc  push rax
0000785dab1d37fd  push rcx
0000785dab1d37fe  push rdx
0000785dab1d37ff  push rdi
0000785dab1d3800  push rsi
0000785dab1d3801  push r8
0000785dab1d3803  push r9
0000785dab1d3805  push r10
0000785dab1d3807  push r11
0000785dab1d3809  sub rsp, 0xF0
0000785dab1d3810  vmovaps [rsp], xmm0
0000785dab1d3815  vmovaps [rsp+0x10], xmm1
0000785dab1d381b  vmovaps [rsp+0x20], xmm2
0000785dab1d3821  vmovaps [rsp+0x30], xmm3
0000785dab1d3827  vmovaps [rsp+0x40], xmm4
0000785dab1d382d  vmovaps [rsp+0x50], xmm5
0000785dab1d3833  vmovaps [rsp+0x60], xmm6
0000785dab1d3839  vmovaps [rsp+0x70], xmm7
0000785dab1d383f  vmovaps [rsp+0x80], xmm8
0000785dab1d3848  vmovaps [rsp+0x90], xmm9
0000785dab1d3851  vmovaps [rsp+0xA0], xmm10
0000785dab1d385a  vmovaps [rsp+0xB0], xmm11
0000785dab1d3863  vmovaps [rsp+0xC0], xmm12
0000785dab1d386c  vmovaps [rsp+0xD0], xmm13
0000785dab1d3875  vmovaps [rsp+0xE0], xmm14
0000785dab1d387e  sub rsp, 0x30
0000785dab1d3882  movaps [rsp], xmm15
0000785dab1d3887  movaps [rsp+0x10], xmm13
0000785dab1d388d  movaps [rsp+0x20], xmm10
0000785dab1d3893  lea rdi, [rsp]
0000785dab1d3897  mov esi, 0x00
0000785dab1d389c  mov rax, 0x61B13BBD6530
0000785dab1d38a6  call rax
0000785dab1d38a8  movaps xmm15, [rsp]
0000785dab1d38ad  add rsp, 0x30
0000785dab1d38b1  vmovaps xmm0, [rsp]
0000785dab1d38b6  vmovaps xmm1, [rsp+0x10]
0000785dab1d38bc  vmovaps xmm2, [rsp+0x20]
0000785dab1d38c2  vmovaps xmm3, [rsp+0x30]
0000785dab1d38c8  vmovaps xmm4, [rsp+0x40]
0000785dab1d38ce  vmovaps xmm5, [rsp+0x50]
0000785dab1d38d4  vmovaps xmm6, [rsp+0x60]
0000785dab1d38da  vmovaps xmm7, [rsp+0x70]
0000785dab1d38e0  vmovaps xmm8, [rsp+0x80]
0000785dab1d38e9  vmovaps xmm9, [rsp+0x90]
0000785dab1d38f2  vmovaps xmm10, [rsp+0xA0]
0000785dab1d38fb  vmovaps xmm11, [rsp+0xB0]
0000785dab1d3904  vmovaps xmm12, [rsp+0xC0]
0000785dab1d390d  vmovaps xmm13, [rsp+0xD0]
0000785dab1d3916  vmovaps xmm14, [rsp+0xE0]
0000785dab1d391f  add rsp, 0xF0
0000785dab1d3926  pop r11
0000785dab1d3928  pop r10
0000785dab1d392a  pop r9
0000785dab1d392c  pop r8
0000785dab1d392e  pop rsi
0000785dab1d392f  pop rdi
0000785dab1d3930  pop rdx
0000785dab1d3931  pop rcx
0000785dab1d3932  pop rax
0000785dab1d3933  add rsp, 0x08
0000785dab1d3937  jmp 0x0000785DAB1CFF55
0000785dab1d393c  call 0x0000785DAB00C260
0000785dab1d3941  jmp 0x0000785DAB1CFFB0
0000785dab1d3946  sub rsp, 0x08
0000785dab1d394a  push rax
0000785dab1d394b  push rcx
0000785dab1d394c  push rdx
0000785dab1d394d  push rdi
0000785dab1d394e  push rsi
0000785dab1d394f  push r8
0000785dab1d3951  push r9
0000785dab1d3953  push r10
0000785dab1d3955  push r11
0000785dab1d3957  sub rsp, 0xF0
0000785dab1d395e  vmovaps [rsp], xmm0
0000785dab1d3963  vmovaps [rsp+0x10], xmm1
0000785dab1d3969  vmovaps [rsp+0x20], xmm2
0000785dab1d396f  vmovaps [rsp+0x30], xmm3
0000785dab1d3975  vmovaps [rsp+0x40], xmm4
0000785dab1d397b  vmovaps [rsp+0x50], xmm5
0000785dab1d3981  vmovaps [rsp+0x60], xmm6
0000785dab1d3987  vmovaps [rsp+0x70], xmm7
0000785dab1d398d  vmovaps [rsp+0x80], xmm8
0000785dab1d3996  vmovaps [rsp+0x90], xmm10
0000785dab1d399f  vmovaps [rsp+0xA0], xmm11
0000785dab1d39a8  vmovaps [rsp+0xB0], xmm12
0000785dab1d39b1  vmovaps [rsp+0xC0], xmm13
0000785dab1d39ba  vmovaps [rsp+0xD0], xmm14
0000785dab1d39c3  vmovaps [rsp+0xE0], xmm15
0000785dab1d39cc  sub rsp, 0x30
0000785dab1d39d0  movaps [rsp], xmm9
0000785dab1d39d5  movaps [rsp+0x10], xmm8
0000785dab1d39db  movaps [rsp+0x20], xmm10
0000785dab1d39e1  lea rdi, [rsp]
0000785dab1d39e5  mov esi, 0x00
0000785dab1d39ea  mov rax, 0x61B13BBD6530
0000785dab1d39f4  call rax
0000785dab1d39f6  movaps xmm9, [rsp]
0000785dab1d39fb  add rsp, 0x30
0000785dab1d39ff  vmovaps xmm0, [rsp]
0000785dab1d3a04  vmovaps xmm1, [rsp+0x10]
0000785dab1d3a0a  vmovaps xmm2, [rsp+0x20]
0000785dab1d3a10  vmovaps xmm3, [rsp+0x30]
0000785dab1d3a16  vmovaps xmm4, [rsp+0x40]
0000785dab1d3a1c  vmovaps xmm5, [rsp+0x50]
0000785dab1d3a22  vmovaps xmm6, [rsp+0x60]
0000785dab1d3a28  vmovaps xmm7, [rsp+0x70]
0000785dab1d3a2e  vmovaps xmm8, [rsp+0x80]
0000785dab1d3a37  vmovaps xmm10, [rsp+0x90]
0000785dab1d3a40  vmovaps xmm11, [rsp+0xA0]
0000785dab1d3a49  vmovaps xmm12, [rsp+0xB0]
0000785dab1d3a52  vmovaps xmm13, [rsp+0xC0]
0000785dab1d3a5b  vmovaps xmm14, [rsp+0xD0]
0000785dab1d3a64  vmovaps xmm15, [rsp+0xE0]
0000785dab1d3a6d  add rsp, 0xF0
0000785dab1d3a74  pop r11
0000785dab1d3a76  pop r10
0000785dab1d3a78  pop r9
0000785dab1d3a7a  pop r8
0000785dab1d3a7c  pop rsi
0000785dab1d3a7d  pop rdi
0000785dab1d3a7e  pop rdx
0000785dab1d3a7f  pop rcx
0000785dab1d3a80  pop rax
0000785dab1d3a81  add rsp, 0x08
0000785dab1d3a85  jmp 0x0000785DAB1CFFE1
0000785dab1d3a8a  sub rsp, 0x08
0000785dab1d3a8e  push rax
0000785dab1d3a8f  push rcx
0000785dab1d3a90  push rdx
0000785dab1d3a91  push rdi
0000785dab1d3a92  push rsi
0000785dab1d3a93  push r8
0000785dab1d3a95  push r9
0000785dab1d3a97  push r10
0000785dab1d3a99  push r11
0000785dab1d3a9b  sub rsp, 0xF0
0000785dab1d3aa2  vmovaps [rsp], xmm0
0000785dab1d3aa7  vmovaps [rsp+0x10], xmm1
0000785dab1d3aad  vmovaps [rsp+0x20], xmm2
0000785dab1d3ab3  vmovaps [rsp+0x30], xmm3
0000785dab1d3ab9  vmovaps [rsp+0x40], xmm4
0000785dab1d3abf  vmovaps [rsp+0x50], xmm5
0000785dab1d3ac5  vmovaps [rsp+0x60], xmm6
0000785dab1d3acb  vmovaps [rsp+0x70], xmm7
0000785dab1d3ad1  vmovaps [rsp+0x80], xmm8
0000785dab1d3ada  vmovaps [rsp+0x90], xmm9
0000785dab1d3ae3  vmovaps [rsp+0xA0], xmm11
0000785dab1d3aec  vmovaps [rsp+0xB0], xmm12
0000785dab1d3af5  vmovaps [rsp+0xC0], xmm13
0000785dab1d3afe  vmovaps [rsp+0xD0], xmm14
0000785dab1d3b07  vmovaps [rsp+0xE0], xmm15
0000785dab1d3b10  sub rsp, 0x30
0000785dab1d3b14  movaps [rsp], xmm10
0000785dab1d3b19  movaps [rsp+0x10], xmm1
0000785dab1d3b1e  movaps [rsp+0x20], xmm11
0000785dab1d3b24  lea rdi, [rsp]
0000785dab1d3b28  mov esi, 0x00
0000785dab1d3b2d  mov rax, 0x61B13BBD6530
0000785dab1d3b37  call rax
0000785dab1d3b39  movaps xmm10, [rsp]
0000785dab1d3b3e  add rsp, 0x30
0000785dab1d3b42  vmovaps xmm0, [rsp]
0000785dab1d3b47  vmovaps xmm1, [rsp+0x10]
0000785dab1d3b4d  vmovaps xmm2, [rsp+0x20]
0000785dab1d3b53  vmovaps xmm3, [rsp+0x30]
0000785dab1d3b59  vmovaps xmm4, [rsp+0x40]
0000785dab1d3b5f  vmovaps xmm5, [rsp+0x50]
0000785dab1d3b65  vmovaps xmm6, [rsp+0x60]
0000785dab1d3b6b  vmovaps xmm7, [rsp+0x70]
0000785dab1d3b71  vmovaps xmm8, [rsp+0x80]
0000785dab1d3b7a  vmovaps xmm9, [rsp+0x90]
0000785dab1d3b83  vmovaps xmm11, [rsp+0xA0]
0000785dab1d3b8c  vmovaps xmm12, [rsp+0xB0]
0000785dab1d3b95  vmovaps xmm13, [rsp+0xC0]
0000785dab1d3b9e  vmovaps xmm14, [rsp+0xD0]
0000785dab1d3ba7  vmovaps xmm15, [rsp+0xE0]
0000785dab1d3bb0  add rsp, 0xF0
0000785dab1d3bb7  pop r11
0000785dab1d3bb9  pop r10
0000785dab1d3bbb  pop r9
0000785dab1d3bbd  pop r8
0000785dab1d3bbf  pop rsi
0000785dab1d3bc0  pop rdi
0000785dab1d3bc1  pop rdx
0000785dab1d3bc2  pop rcx
0000785dab1d3bc3  pop rax
0000785dab1d3bc4  add rsp, 0x08
0000785dab1d3bc8  jmp 0x0000785DAB1CFFFC
0000785dab1d3bcd  sub rsp, 0x08
0000785dab1d3bd1  push rax
0000785dab1d3bd2  push rcx
0000785dab1d3bd3  push rdx
0000785dab1d3bd4  push rdi
0000785dab1d3bd5  push rsi
0000785dab1d3bd6  push r8
0000785dab1d3bd8  push r9
0000785dab1d3bda  push r10
0000785dab1d3bdc  push r11
0000785dab1d3bde  sub rsp, 0xF0
0000785dab1d3be5  vmovaps [rsp], xmm0
0000785dab1d3bea  vmovaps [rsp+0x10], xmm2
0000785dab1d3bf0  vmovaps [rsp+0x20], xmm3
0000785dab1d3bf6  vmovaps [rsp+0x30], xmm4
0000785dab1d3bfc  vmovaps [rsp+0x40], xmm5
0000785dab1d3c02  vmovaps [rsp+0x50], xmm6
0000785dab1d3c08  vmovaps [rsp+0x60], xmm7
0000785dab1d3c0e  vmovaps [rsp+0x70], xmm8
0000785dab1d3c14  vmovaps [rsp+0x80], xmm9
0000785dab1d3c1d  vmovaps [rsp+0x90], xmm10
0000785dab1d3c26  vmovaps [rsp+0xA0], xmm11
0000785dab1d3c2f  vmovaps [rsp+0xB0], xmm12
0000785dab1d3c38  vmovaps [rsp+0xC0], xmm13
0000785dab1d3c41  vmovaps [rsp+0xD0], xmm14
0000785dab1d3c4a  vmovaps [rsp+0xE0], xmm15
0000785dab1d3c53  sub rsp, 0x30
0000785dab1d3c57  movaps [rsp], xmm1
0000785dab1d3c5b  movaps [rsp+0x10], xmm14
0000785dab1d3c61  movaps [rsp+0x20], xmm6
0000785dab1d3c66  lea rdi, [rsp]
0000785dab1d3c6a  mov esi, 0x00
0000785dab1d3c6f  mov rax, 0x61B13BBD6530
0000785dab1d3c79  call rax
0000785dab1d3c7b  movaps xmm1, [rsp]
0000785dab1d3c7f  add rsp, 0x30
0000785dab1d3c83  vmovaps xmm0, [rsp]
0000785dab1d3c88  vmovaps xmm2, [rsp+0x10]
0000785dab1d3c8e  vmovaps xmm3, [rsp+0x20]
0000785dab1d3c94  vmovaps xmm4, [rsp+0x30]
0000785dab1d3c9a  vmovaps xmm5, [rsp+0x40]
0000785dab1d3ca0  vmovaps xmm6, [rsp+0x50]
0000785dab1d3ca6  vmovaps xmm7, [rsp+0x60]
0000785dab1d3cac  vmovaps xmm8, [rsp+0x70]
0000785dab1d3cb2  vmovaps xmm9, [rsp+0x80]
0000785dab1d3cbb  vmovaps xmm10, [rsp+0x90]
0000785dab1d3cc4  vmovaps xmm11, [rsp+0xA0]
0000785dab1d3ccd  vmovaps xmm12, [rsp+0xB0]
0000785dab1d3cd6  vmovaps xmm13, [rsp+0xC0]
0000785dab1d3cdf  vmovaps xmm14, [rsp+0xD0]
0000785dab1d3ce8  vmovaps xmm15, [rsp+0xE0]
0000785dab1d3cf1  add rsp, 0xF0
0000785dab1d3cf8  pop r11
0000785dab1d3cfa  pop r10
0000785dab1d3cfc  pop r9
0000785dab1d3cfe  pop r8
0000785dab1d3d00  pop rsi
0000785dab1d3d01  pop rdi
0000785dab1d3d02  pop rdx
0000785dab1d3d03  pop rcx
0000785dab1d3d04  pop rax
0000785dab1d3d05  add rsp, 0x08
0000785dab1d3d09  jmp 0x0000785DAB1D0015
0000785dab1d3d0e  sub rsp, 0x08
0000785dab1d3d12  push rax
0000785dab1d3d13  push rcx
0000785dab1d3d14  push rdx
0000785dab1d3d15  push rdi
0000785dab1d3d16  push rsi
0000785dab1d3d17  push r8
0000785dab1d3d19  push r9
0000785dab1d3d1b  push r10
0000785dab1d3d1d  push r11
0000785dab1d3d1f  sub rsp, 0xF0
0000785dab1d3d26  vmovaps [rsp], xmm0
0000785dab1d3d2b  vmovaps [rsp+0x10], xmm1
0000785dab1d3d31  vmovaps [rsp+0x20], xmm2
0000785dab1d3d37  vmovaps [rsp+0x30], xmm3
0000785dab1d3d3d  vmovaps [rsp+0x40], xmm4
0000785dab1d3d43  vmovaps [rsp+0x50], xmm5
0000785dab1d3d49  vmovaps [rsp+0x60], xmm6
0000785dab1d3d4f  vmovaps [rsp+0x70], xmm7
0000785dab1d3d55  vmovaps [rsp+0x80], xmm8
0000785dab1d3d5e  vmovaps [rsp+0x90], xmm9
0000785dab1d3d67  vmovaps [rsp+0xA0], xmm10
0000785dab1d3d70  vmovaps [rsp+0xB0], xmm12
0000785dab1d3d79  vmovaps [rsp+0xC0], xmm13
0000785dab1d3d82  vmovaps [rsp+0xD0], xmm14
0000785dab1d3d8b  vmovaps [rsp+0xE0], xmm15
0000785dab1d3d94  sub rsp, 0x30
0000785dab1d3d98  movaps [rsp], xmm11
0000785dab1d3d9d  movaps [rsp+0x10], xmm13
0000785dab1d3da3  movaps [rsp+0x20], xmm14
0000785dab1d3da9  lea rdi, [rsp]
0000785dab1d3dad  mov esi, 0x00
0000785dab1d3db2  mov rax, 0x61B13BBD6530
0000785dab1d3dbc  call rax
0000785dab1d3dbe  movaps xmm11, [rsp]
0000785dab1d3dc3  add rsp, 0x30
0000785dab1d3dc7  vmovaps xmm0, [rsp]
0000785dab1d3dcc  vmovaps xmm1, [rsp+0x10]
0000785dab1d3dd2  vmovaps xmm2, [rsp+0x20]
0000785dab1d3dd8  vmovaps xmm3, [rsp+0x30]
0000785dab1d3dde  vmovaps xmm4, [rsp+0x40]
0000785dab1d3de4  vmovaps xmm5, [rsp+0x50]
0000785dab1d3dea  vmovaps xmm6, [rsp+0x60]
0000785dab1d3df0  vmovaps xmm7, [rsp+0x70]
0000785dab1d3df6  vmovaps xmm8, [rsp+0x80]
0000785dab1d3dff  vmovaps xmm9, [rsp+0x90]
0000785dab1d3e08  vmovaps xmm10, [rsp+0xA0]
0000785dab1d3e11  vmovaps xmm12, [rsp+0xB0]
0000785dab1d3e1a  vmovaps xmm13, [rsp+0xC0]
0000785dab1d3e23  vmovaps xmm14, [rsp+0xD0]
0000785dab1d3e2c  vmovaps xmm15, [rsp+0xE0]
0000785dab1d3e35  add rsp, 0xF0
0000785dab1d3e3c  pop r11
0000785dab1d3e3e  pop r10
0000785dab1d3e40  pop r9
0000785dab1d3e42  pop r8
0000785dab1d3e44  pop rsi
0000785dab1d3e45  pop rdi
0000785dab1d3e46  pop rdx
0000785dab1d3e47  pop rcx
0000785dab1d3e48  pop rax
0000785dab1d3e49  add rsp, 0x08
0000785dab1d3e4d  jmp 0x0000785DAB1D003F
0000785dab1d3e52  sub rsp, 0x08
0000785dab1d3e56  push rax
0000785dab1d3e57  push rcx
0000785dab1d3e58  push rdx
0000785dab1d3e59  push rdi
0000785dab1d3e5a  push rsi
0000785dab1d3e5b  push r8
0000785dab1d3e5d  push r9
0000785dab1d3e5f  push r10
0000785dab1d3e61  push r11
0000785dab1d3e63  sub rsp, 0xF0
0000785dab1d3e6a  vmovaps [rsp], xmm0
0000785dab1d3e6f  vmovaps [rsp+0x10], xmm1
0000785dab1d3e75  vmovaps [rsp+0x20], xmm2
0000785dab1d3e7b  vmovaps [rsp+0x30], xmm3
0000785dab1d3e81  vmovaps [rsp+0x40], xmm4
0000785dab1d3e87  vmovaps [rsp+0x50], xmm5
0000785dab1d3e8d  vmovaps [rsp+0x60], xmm6
0000785dab1d3e93  vmovaps [rsp+0x70], xmm7
0000785dab1d3e99  vmovaps [rsp+0x80], xmm8
0000785dab1d3ea2  vmovaps [rsp+0x90], xmm9
0000785dab1d3eab  vmovaps [rsp+0xA0], xmm10
0000785dab1d3eb4  vmovaps [rsp+0xB0], xmm11
0000785dab1d3ebd  vmovaps [rsp+0xC0], xmm12
0000785dab1d3ec6  vmovaps [rsp+0xD0], xmm14
0000785dab1d3ecf  vmovaps [rsp+0xE0], xmm15
0000785dab1d3ed8  sub rsp, 0x30
0000785dab1d3edc  movaps [rsp], xmm13
0000785dab1d3ee1  movaps [rsp+0x10], xmm8
0000785dab1d3ee7  movaps [rsp+0x20], xmm14
0000785dab1d3eed  lea rdi, [rsp]
0000785dab1d3ef1  mov esi, 0x00
0000785dab1d3ef6  mov rax, 0x61B13BBD6530
0000785dab1d3f00  call rax
0000785dab1d3f02  movaps xmm13, [rsp]
0000785dab1d3f07  add rsp, 0x30
0000785dab1d3f0b  vmovaps xmm0, [rsp]
0000785dab1d3f10  vmovaps xmm1, [rsp+0x10]
0000785dab1d3f16  vmovaps xmm2, [rsp+0x20]
0000785dab1d3f1c  vmovaps xmm3, [rsp+0x30]
0000785dab1d3f22  vmovaps xmm4, [rsp+0x40]
0000785dab1d3f28  vmovaps xmm5, [rsp+0x50]
0000785dab1d3f2e  vmovaps xmm6, [rsp+0x60]
0000785dab1d3f34  vmovaps xmm7, [rsp+0x70]
0000785dab1d3f3a  vmovaps xmm8, [rsp+0x80]
0000785dab1d3f43  vmovaps xmm9, [rsp+0x90]
0000785dab1d3f4c  vmovaps xmm10, [rsp+0xA0]
0000785dab1d3f55  vmovaps xmm11, [rsp+0xB0]
0000785dab1d3f5e  vmovaps xmm12, [rsp+0xC0]
0000785dab1d3f67  vmovaps xmm14, [rsp+0xD0]
0000785dab1d3f70  vmovaps xmm15, [rsp+0xE0]
0000785dab1d3f79  add rsp, 0xF0
0000785dab1d3f80  pop r11
0000785dab1d3f82  pop r10
0000785dab1d3f84  pop r9
0000785dab1d3f86  pop r8
0000785dab1d3f88  pop rsi
0000785dab1d3f89  pop rdi
0000785dab1d3f8a  pop rdx
0000785dab1d3f8b  pop rcx
0000785dab1d3f8c  pop rax
0000785dab1d3f8d  add rsp, 0x08
0000785dab1d3f91  jmp 0x0000785DAB1D006E
0000785dab1d3f96  sub rsp, 0x08
0000785dab1d3f9a  push rax
0000785dab1d3f9b  push rcx
0000785dab1d3f9c  push rdx
0000785dab1d3f9d  push rdi
0000785dab1d3f9e  push rsi
0000785dab1d3f9f  push r8
0000785dab1d3fa1  push r9
0000785dab1d3fa3  push r10
0000785dab1d3fa5  push r11
0000785dab1d3fa7  sub rsp, 0xF0
0000785dab1d3fae  vmovaps [rsp], xmm0
0000785dab1d3fb3  vmovaps [rsp+0x10], xmm1
0000785dab1d3fb9  vmovaps [rsp+0x20], xmm2
0000785dab1d3fbf  vmovaps [rsp+0x30], xmm3
0000785dab1d3fc5  vmovaps [rsp+0x40], xmm4
0000785dab1d3fcb  vmovaps [rsp+0x50], xmm5
0000785dab1d3fd1  vmovaps [rsp+0x60], xmm6
0000785dab1d3fd7  vmovaps [rsp+0x70], xmm7
0000785dab1d3fdd  vmovaps [rsp+0x80], xmm9
0000785dab1d3fe6  vmovaps [rsp+0x90], xmm10
0000785dab1d3fef  vmovaps [rsp+0xA0], xmm11
0000785dab1d3ff8  vmovaps [rsp+0xB0], xmm12
0000785dab1d4001  vmovaps [rsp+0xC0], xmm13
0000785dab1d400a  vmovaps [rsp+0xD0], xmm14
0000785dab1d4013  vmovaps [rsp+0xE0], xmm15
0000785dab1d401c  sub rsp, 0x30
0000785dab1d4020  movaps [rsp], xmm8
0000785dab1d4025  movaps [rsp+0x10], xmm7
0000785dab1d402a  movaps [rsp+0x20], xmm14
0000785dab1d4030  lea rdi, [rsp]
0000785dab1d4034  mov esi, 0x00
0000785dab1d4039  mov rax, 0x61B13BBD6530
0000785dab1d4043  call rax
0000785dab1d4045  movaps xmm8, [rsp]
0000785dab1d404a  add rsp, 0x30
0000785dab1d404e  vmovaps xmm0, [rsp]
0000785dab1d4053  vmovaps xmm1, [rsp+0x10]
0000785dab1d4059  vmovaps xmm2, [rsp+0x20]
0000785dab1d405f  vmovaps xmm3, [rsp+0x30]
0000785dab1d4065  vmovaps xmm4, [rsp+0x40]
0000785dab1d406b  vmovaps xmm5, [rsp+0x50]
0000785dab1d4071  vmovaps xmm6, [rsp+0x60]
0000785dab1d4077  vmovaps xmm7, [rsp+0x70]
0000785dab1d407d  vmovaps xmm9, [rsp+0x80]
0000785dab1d4086  vmovaps xmm10, [rsp+0x90]
0000785dab1d408f  vmovaps xmm11, [rsp+0xA0]
0000785dab1d4098  vmovaps xmm12, [rsp+0xB0]
0000785dab1d40a1  vmovaps xmm13, [rsp+0xC0]
0000785dab1d40aa  vmovaps xmm14, [rsp+0xD0]
0000785dab1d40b3  vmovaps xmm15, [rsp+0xE0]
0000785dab1d40bc  add rsp, 0xF0
0000785dab1d40c3  pop r11
0000785dab1d40c5  pop r10
0000785dab1d40c7  pop r9
0000785dab1d40c9  pop r8
0000785dab1d40cb  pop rsi
0000785dab1d40cc  pop rdi
0000785dab1d40cd  pop rdx
0000785dab1d40ce  pop rcx
0000785dab1d40cf  pop rax
0000785dab1d40d0  add rsp, 0x08
0000785dab1d40d4  jmp 0x0000785DAB1D0094
0000785dab1d40d9  sub rsp, 0x08
0000785dab1d40dd  push rax
0000785dab1d40de  push rcx
0000785dab1d40df  push rdx
0000785dab1d40e0  push rdi
0000785dab1d40e1  push rsi
0000785dab1d40e2  push r8
0000785dab1d40e4  push r9
0000785dab1d40e6  push r10
0000785dab1d40e8  push r11
0000785dab1d40ea  sub rsp, 0xF0
0000785dab1d40f1  vmovaps [rsp], xmm0
0000785dab1d40f6  vmovaps [rsp+0x10], xmm1
0000785dab1d40fc  vmovaps [rsp+0x20], xmm2
0000785dab1d4102  vmovaps [rsp+0x30], xmm3
0000785dab1d4108  vmovaps [rsp+0x40], xmm4
0000785dab1d410e  vmovaps [rsp+0x50], xmm5
0000785dab1d4114  vmovaps [rsp+0x60], xmm6
0000785dab1d411a  vmovaps [rsp+0x70], xmm7
0000785dab1d4120  vmovaps [rsp+0x80], xmm8
0000785dab1d4129  vmovaps [rsp+0x90], xmm9
0000785dab1d4132  vmovaps [rsp+0xA0], xmm10
0000785dab1d413b  vmovaps [rsp+0xB0], xmm11
0000785dab1d4144  vmovaps [rsp+0xC0], xmm12
0000785dab1d414d  vmovaps [rsp+0xD0], xmm13
0000785dab1d4156  vmovaps [rsp+0xE0], xmm15
0000785dab1d415f  sub rsp, 0x30
0000785dab1d4163  movaps [rsp], xmm14
0000785dab1d4168  movaps [rsp+0x10], xmm12
0000785dab1d416e  movaps [rsp+0x20], xmm9
0000785dab1d4174  lea rdi, [rsp]
0000785dab1d4178  mov esi, 0x00
0000785dab1d417d  mov rax, 0x61B13BBD6530
0000785dab1d4187  call rax
0000785dab1d4189  movaps xmm14, [rsp]
0000785dab1d418e  add rsp, 0x30
0000785dab1d4192  vmovaps xmm0, [rsp]
0000785dab1d4197  vmovaps xmm1, [rsp+0x10]
0000785dab1d419d  vmovaps xmm2, [rsp+0x20]
0000785dab1d41a3  vmovaps xmm3, [rsp+0x30]
0000785dab1d41a9  vmovaps xmm4, [rsp+0x40]
0000785dab1d41af  vmovaps xmm5, [rsp+0x50]
0000785dab1d41b5  vmovaps xmm6, [rsp+0x60]
0000785dab1d41bb  vmovaps xmm7, [rsp+0x70]
0000785dab1d41c1  vmovaps xmm8, [rsp+0x80]
0000785dab1d41ca  vmovaps xmm9, [rsp+0x90]
0000785dab1d41d3  vmovaps xmm10, [rsp+0xA0]
0000785dab1d41dc  vmovaps xmm11, [rsp+0xB0]
0000785dab1d41e5  vmovaps xmm12, [rsp+0xC0]
0000785dab1d41ee  vmovaps xmm13, [rsp+0xD0]
0000785dab1d41f7  vmovaps xmm15, [rsp+0xE0]
0000785dab1d4200  add rsp, 0xF0
0000785dab1d4207  pop r11
0000785dab1d4209  pop r10
0000785dab1d420b  pop r9
0000785dab1d420d  pop r8
0000785dab1d420f  pop rsi
0000785dab1d4210  pop rdi
0000785dab1d4211  pop rdx
0000785dab1d4212  pop rcx
0000785dab1d4213  pop rax
0000785dab1d4214  add rsp, 0x08
0000785dab1d4218  jmp 0x0000785DAB1D00AE
0000785dab1d421d  sub rsp, 0x08
0000785dab1d4221  push rax
0000785dab1d4222  push rcx
0000785dab1d4223  push rdx
0000785dab1d4224  push rdi
0000785dab1d4225  push rsi
0000785dab1d4226  push r8
0000785dab1d4228  push r9
0000785dab1d422a  push r10
0000785dab1d422c  push r11
0000785dab1d422e  sub rsp, 0xF0
0000785dab1d4235  vmovaps [rsp], xmm0
0000785dab1d423a  vmovaps [rsp+0x10], xmm1
0000785dab1d4240  vmovaps [rsp+0x20], xmm2
0000785dab1d4246  vmovaps [rsp+0x30], xmm3
0000785dab1d424c  vmovaps [rsp+0x40], xmm4
0000785dab1d4252  vmovaps [rsp+0x50], xmm5
0000785dab1d4258  vmovaps [rsp+0x60], xmm6
0000785dab1d425e  vmovaps [rsp+0x70], xmm7
0000785dab1d4264  vmovaps [rsp+0x80], xmm8
0000785dab1d426d  vmovaps [rsp+0x90], xmm10
0000785dab1d4276  vmovaps [rsp+0xA0], xmm11
0000785dab1d427f  vmovaps [rsp+0xB0], xmm12
0000785dab1d4288  vmovaps [rsp+0xC0], xmm13
0000785dab1d4291  vmovaps [rsp+0xD0], xmm14
0000785dab1d429a  vmovaps [rsp+0xE0], xmm15
0000785dab1d42a3  sub rsp, 0x30
0000785dab1d42a7  movaps [rsp], xmm9
0000785dab1d42ac  movaps [rsp+0x10], xmm7
0000785dab1d42b1  movaps [rsp+0x20], xmm12
0000785dab1d42b7  lea rdi, [rsp]
0000785dab1d42bb  mov esi, 0x00
0000785dab1d42c0  mov rax, 0x61B13BBD6530
0000785dab1d42ca  call rax
0000785dab1d42cc  movaps xmm9, [rsp]
0000785dab1d42d1  add rsp, 0x30
0000785dab1d42d5  vmovaps xmm0, [rsp]
0000785dab1d42da  vmovaps xmm1, [rsp+0x10]
0000785dab1d42e0  vmovaps xmm2, [rsp+0x20]
0000785dab1d42e6  vmovaps xmm3, [rsp+0x30]
0000785dab1d42ec  vmovaps xmm4, [rsp+0x40]
0000785dab1d42f2  vmovaps xmm5, [rsp+0x50]
0000785dab1d42f8  vmovaps xmm6, [rsp+0x60]
0000785dab1d42fe  vmovaps xmm7, [rsp+0x70]
0000785dab1d4304  vmovaps xmm8, [rsp+0x80]
0000785dab1d430d  vmovaps xmm10, [rsp+0x90]
0000785dab1d4316  vmovaps xmm11, [rsp+0xA0]
0000785dab1d431f  vmovaps xmm12, [rsp+0xB0]
0000785dab1d4328  vmovaps xmm13, [rsp+0xC0]
0000785dab1d4331  vmovaps xmm14, [rsp+0xD0]
0000785dab1d433a  vmovaps xmm15, [rsp+0xE0]
0000785dab1d4343  add rsp, 0xF0
0000785dab1d434a  pop r11
0000785dab1d434c  pop r10
0000785dab1d434e  pop r9
0000785dab1d4350  pop r8
0000785dab1d4352  pop rsi
0000785dab1d4353  pop rdi
0000785dab1d4354  pop rdx
0000785dab1d4355  pop rcx
0000785dab1d4356  pop rax
0000785dab1d4357  add rsp, 0x08
0000785dab1d435b  jmp 0x0000785DAB1D00DD
0000785dab1d4360  sub rsp, 0x08
0000785dab1d4364  push rax
0000785dab1d4365  push rcx
0000785dab1d4366  push rdx
0000785dab1d4367  push rdi
0000785dab1d4368  push rsi
0000785dab1d4369  push r8
0000785dab1d436b  push r9
0000785dab1d436d  push r10
0000785dab1d436f  push r11
0000785dab1d4371  sub rsp, 0xF0
0000785dab1d4378  vmovaps [rsp], xmm0
0000785dab1d437d  vmovaps [rsp+0x10], xmm1
0000785dab1d4383  vmovaps [rsp+0x20], xmm2
0000785dab1d4389  vmovaps [rsp+0x30], xmm3
0000785dab1d438f  vmovaps [rsp+0x40], xmm4
0000785dab1d4395  vmovaps [rsp+0x50], xmm5
0000785dab1d439b  vmovaps [rsp+0x60], xmm6
0000785dab1d43a1  vmovaps [rsp+0x70], xmm7
0000785dab1d43a7  vmovaps [rsp+0x80], xmm8
0000785dab1d43b0  vmovaps [rsp+0x90], xmm9
0000785dab1d43b9  vmovaps [rsp+0xA0], xmm10
0000785dab1d43c2  vmovaps [rsp+0xB0], xmm11
0000785dab1d43cb  vmovaps [rsp+0xC0], xmm13
0000785dab1d43d4  vmovaps [rsp+0xD0], xmm14
0000785dab1d43dd  vmovaps [rsp+0xE0], xmm15
0000785dab1d43e6  sub rsp, 0x30
0000785dab1d43ea  movaps [rsp], xmm12
0000785dab1d43ef  movaps [rsp+0x10], xmm15
0000785dab1d43f5  movaps [rsp+0x20], xmm11
0000785dab1d43fb  lea rdi, [rsp]
0000785dab1d43ff  mov esi, 0x00
0000785dab1d4404  mov rax, 0x61B13BBD6530
0000785dab1d440e  call rax
0000785dab1d4410  movaps xmm12, [rsp]
0000785dab1d4415  add rsp, 0x30
0000785dab1d4419  vmovaps xmm0, [rsp]
0000785dab1d441e  vmovaps xmm1, [rsp+0x10]
0000785dab1d4424  vmovaps xmm2, [rsp+0x20]
0000785dab1d442a  vmovaps xmm3, [rsp+0x30]
0000785dab1d4430  vmovaps xmm4, [rsp+0x40]
0000785dab1d4436  vmovaps xmm5, [rsp+0x50]
0000785dab1d443c  vmovaps xmm6, [rsp+0x60]
0000785dab1d4442  vmovaps xmm7, [rsp+0x70]
0000785dab1d4448  vmovaps xmm8, [rsp+0x80]
0000785dab1d4451  vmovaps xmm9, [rsp+0x90]
0000785dab1d445a  vmovaps xmm10, [rsp+0xA0]
0000785dab1d4463  vmovaps xmm11, [rsp+0xB0]
0000785dab1d446c  vmovaps xmm13, [rsp+0xC0]
0000785dab1d4475  vmovaps xmm14, [rsp+0xD0]
0000785dab1d447e  vmovaps xmm15, [rsp+0xE0]
0000785dab1d4487  add rsp, 0xF0
0000785dab1d448e  pop r11
0000785dab1d4490  pop r10
0000785dab1d4492  pop r9
0000785dab1d4494  pop r8
0000785dab1d4496  pop rsi
0000785dab1d4497  pop rdi
0000785dab1d4498  pop rdx
0000785dab1d4499  pop rcx
0000785dab1d449a  pop rax
0000785dab1d449b  add rsp, 0x08
0000785dab1d449f  jmp 0x0000785DAB1D00F7
0000785dab1d44a4  sub rsp, 0x08
0000785dab1d44a8  push rax
0000785dab1d44a9  push rcx
0000785dab1d44aa  push rdx
0000785dab1d44ab  push rdi
0000785dab1d44ac  push rsi
0000785dab1d44ad  push r8
0000785dab1d44af  push r9
0000785dab1d44b1  push r10
0000785dab1d44b3  push r11
0000785dab1d44b5  sub rsp, 0xF0
0000785dab1d44bc  vmovaps [rsp], xmm0
0000785dab1d44c1  vmovaps [rsp+0x10], xmm1
0000785dab1d44c7  vmovaps [rsp+0x20], xmm2
0000785dab1d44cd  vmovaps [rsp+0x30], xmm3
0000785dab1d44d3  vmovaps [rsp+0x40], xmm4
0000785dab1d44d9  vmovaps [rsp+0x50], xmm5
0000785dab1d44df  vmovaps [rsp+0x60], xmm6
0000785dab1d44e5  vmovaps [rsp+0x70], xmm7
0000785dab1d44eb  vmovaps [rsp+0x80], xmm8
0000785dab1d44f4  vmovaps [rsp+0x90], xmm9
0000785dab1d44fd  vmovaps [rsp+0xA0], xmm10
0000785dab1d4506  vmovaps [rsp+0xB0], xmm12
0000785dab1d450f  vmovaps [rsp+0xC0], xmm13
0000785dab1d4518  vmovaps [rsp+0xD0], xmm14
0000785dab1d4521  vmovaps [rsp+0xE0], xmm15
0000785dab1d452a  sub rsp, 0x30
0000785dab1d452e  movaps [rsp], xmm11
0000785dab1d4533  movaps [rsp+0x10], xmm7
0000785dab1d4538  movaps [rsp+0x20], xmm15
0000785dab1d453e  lea rdi, [rsp]
0000785dab1d4542  mov esi, 0x00
0000785dab1d4547  mov rax, 0x61B13BBD6530
0000785dab1d4551  call rax
0000785dab1d4553  movaps xmm11, [rsp]
0000785dab1d4558  add rsp, 0x30
0000785dab1d455c  vmovaps xmm0, [rsp]
0000785dab1d4561  vmovaps xmm1, [rsp+0x10]
0000785dab1d4567  vmovaps xmm2, [rsp+0x20]
0000785dab1d456d  vmovaps xmm3, [rsp+0x30]
0000785dab1d4573  vmovaps xmm4, [rsp+0x40]
0000785dab1d4579  vmovaps xmm5, [rsp+0x50]
0000785dab1d457f  vmovaps xmm6, [rsp+0x60]
0000785dab1d4585  vmovaps xmm7, [rsp+0x70]
0000785dab1d458b  vmovaps xmm8, [rsp+0x80]
0000785dab1d4594  vmovaps xmm9, [rsp+0x90]
0000785dab1d459d  vmovaps xmm10, [rsp+0xA0]
0000785dab1d45a6  vmovaps xmm12, [rsp+0xB0]
0000785dab1d45af  vmovaps xmm13, [rsp+0xC0]
0000785dab1d45b8  vmovaps xmm14, [rsp+0xD0]
0000785dab1d45c1  vmovaps xmm15, [rsp+0xE0]
0000785dab1d45ca  add rsp, 0xF0
0000785dab1d45d1  pop r11
0000785dab1d45d3  pop r10
0000785dab1d45d5  pop r9
0000785dab1d45d7  pop r8
0000785dab1d45d9  pop rsi
0000785dab1d45da  pop rdi
0000785dab1d45db  pop rdx
0000785dab1d45dc  pop rcx
0000785dab1d45dd  pop rax
0000785dab1d45de  add rsp, 0x08
0000785dab1d45e2  jmp 0x0000785DAB1D0123
0000785dab1d45e7  sub rsp, 0x08
0000785dab1d45eb  push rax
0000785dab1d45ec  push rcx
0000785dab1d45ed  push rdx
0000785dab1d45ee  push rdi
0000785dab1d45ef  push rsi
0000785dab1d45f0  push r8
0000785dab1d45f2  push r9
0000785dab1d45f4  push r10
0000785dab1d45f6  push r11
0000785dab1d45f8  sub rsp, 0xF0
0000785dab1d45ff  vmovaps [rsp], xmm0
0000785dab1d4604  vmovaps [rsp+0x10], xmm1
0000785dab1d460a  vmovaps [rsp+0x20], xmm2
0000785dab1d4610  vmovaps [rsp+0x30], xmm3
0000785dab1d4616  vmovaps [rsp+0x40], xmm4
0000785dab1d461c  vmovaps [rsp+0x50], xmm5
0000785dab1d4622  vmovaps [rsp+0x60], xmm6
0000785dab1d4628  vmovaps [rsp+0x70], xmm7
0000785dab1d462e  vmovaps [rsp+0x80], xmm8
0000785dab1d4637  vmovaps [rsp+0x90], xmm9
0000785dab1d4640  vmovaps [rsp+0xA0], xmm10
0000785dab1d4649  vmovaps [rsp+0xB0], xmm11
0000785dab1d4652  vmovaps [rsp+0xC0], xmm12
0000785dab1d465b  vmovaps [rsp+0xD0], xmm13
0000785dab1d4664  vmovaps [rsp+0xE0], xmm14
0000785dab1d466d  sub rsp, 0x30
0000785dab1d4671  movaps [rsp], xmm15
0000785dab1d4676  movaps [rsp+0x10], xmm10
0000785dab1d467c  movaps [rsp+0x20], xmm13
0000785dab1d4682  lea rdi, [rsp]
0000785dab1d4686  mov esi, 0x00
0000785dab1d468b  mov rax, 0x61B13BBD6530
0000785dab1d4695  call rax
0000785dab1d4697  movaps xmm15, [rsp]
0000785dab1d469c  add rsp, 0x30
0000785dab1d46a0  vmovaps xmm0, [rsp]
0000785dab1d46a5  vmovaps xmm1, [rsp+0x10]
0000785dab1d46ab  vmovaps xmm2, [rsp+0x20]
0000785dab1d46b1  vmovaps xmm3, [rsp+0x30]
0000785dab1d46b7  vmovaps xmm4, [rsp+0x40]
0000785dab1d46bd  vmovaps xmm5, [rsp+0x50]
0000785dab1d46c3  vmovaps xmm6, [rsp+0x60]
0000785dab1d46c9  vmovaps xmm7, [rsp+0x70]
0000785dab1d46cf  vmovaps xmm8, [rsp+0x80]
0000785dab1d46d8  vmovaps xmm9, [rsp+0x90]
0000785dab1d46e1  vmovaps xmm10, [rsp+0xA0]
0000785dab1d46ea  vmovaps xmm11, [rsp+0xB0]
0000785dab1d46f3  vmovaps xmm12, [rsp+0xC0]
0000785dab1d46fc  vmovaps xmm13, [rsp+0xD0]
0000785dab1d4705  vmovaps xmm14, [rsp+0xE0]
0000785dab1d470e  add rsp, 0xF0
0000785dab1d4715  pop r11
0000785dab1d4717  pop r10
0000785dab1d4719  pop r9
0000785dab1d471b  pop r8
0000785dab1d471d  pop rsi
0000785dab1d471e  pop rdi
0000785dab1d471f  pop rdx
0000785dab1d4720  pop rcx
0000785dab1d4721  pop rax
0000785dab1d4722  add rsp, 0x08
0000785dab1d4726  jmp 0x0000785DAB1D013D
0000785dab1d472b  sub rsp, 0x08
0000785dab1d472f  push rax
0000785dab1d4730  push rcx
0000785dab1d4731  push rdx
0000785dab1d4732  push rdi
0000785dab1d4733  push rsi
0000785dab1d4734  push r8
0000785dab1d4736  push r9
0000785dab1d4738  push r10
0000785dab1d473a  push r11
0000785dab1d473c  sub rsp, 0xF0
0000785dab1d4743  vmovaps [rsp], xmm0
0000785dab1d4748  vmovaps [rsp+0x10], xmm1
0000785dab1d474e  vmovaps [rsp+0x20], xmm2
0000785dab1d4754  vmovaps [rsp+0x30], xmm3
0000785dab1d475a  vmovaps [rsp+0x40], xmm4
0000785dab1d4760  vmovaps [rsp+0x50], xmm5
0000785dab1d4766  vmovaps [rsp+0x60], xmm6
0000785dab1d476c  vmovaps [rsp+0x70], xmm7
0000785dab1d4772  vmovaps [rsp+0x80], xmm8
0000785dab1d477b  vmovaps [rsp+0x90], xmm9
0000785dab1d4784  vmovaps [rsp+0xA0], xmm11
0000785dab1d478d  vmovaps [rsp+0xB0], xmm12
0000785dab1d4796  vmovaps [rsp+0xC0], xmm13
0000785dab1d479f  vmovaps [rsp+0xD0], xmm14
0000785dab1d47a8  vmovaps [rsp+0xE0], xmm15
0000785dab1d47b1  sub rsp, 0x30
0000785dab1d47b5  movaps [rsp], xmm10
0000785dab1d47ba  movaps [rsp+0x10], xmm7
0000785dab1d47bf  movaps [rsp+0x20], xmm13
0000785dab1d47c5  lea rdi, [rsp]
0000785dab1d47c9  mov esi, 0x00
0000785dab1d47ce  mov rax, 0x61B13BBD6530
0000785dab1d47d8  call rax
0000785dab1d47da  movaps xmm10, [rsp]
0000785dab1d47df  add rsp, 0x30
0000785dab1d47e3  vmovaps xmm0, [rsp]
0000785dab1d47e8  vmovaps xmm1, [rsp+0x10]
0000785dab1d47ee  vmovaps xmm2, [rsp+0x20]
0000785dab1d47f4  vmovaps xmm3, [rsp+0x30]
0000785dab1d47fa  vmovaps xmm4, [rsp+0x40]
0000785dab1d4800  vmovaps xmm5, [rsp+0x50]
0000785dab1d4806  vmovaps xmm6, [rsp+0x60]
0000785dab1d480c  vmovaps xmm7, [rsp+0x70]
0000785dab1d4812  vmovaps xmm8, [rsp+0x80]
0000785dab1d481b  vmovaps xmm9, [rsp+0x90]
0000785dab1d4824  vmovaps xmm11, [rsp+0xA0]
0000785dab1d482d  vmovaps xmm12, [rsp+0xB0]
0000785dab1d4836  vmovaps xmm13, [rsp+0xC0]
0000785dab1d483f  vmovaps xmm14, [rsp+0xD0]
0000785dab1d4848  vmovaps xmm15, [rsp+0xE0]
0000785dab1d4851  add rsp, 0xF0
0000785dab1d4858  pop r11
0000785dab1d485a  pop r10
0000785dab1d485c  pop r9
0000785dab1d485e  pop r8
0000785dab1d4860  pop rsi
0000785dab1d4861  pop rdi
0000785dab1d4862  pop rdx
0000785dab1d4863  pop rcx
0000785dab1d4864  pop rax
0000785dab1d4865  add rsp, 0x08
0000785dab1d4869  jmp 0x0000785DAB1D0169
0000785dab1d486e  sub rsp, 0x08
0000785dab1d4872  push rax
0000785dab1d4873  push rcx
0000785dab1d4874  push rdx
0000785dab1d4875  push rdi
0000785dab1d4876  push rsi
0000785dab1d4877  push r8
0000785dab1d4879  push r9
0000785dab1d487b  push r10
0000785dab1d487d  push r11
0000785dab1d487f  sub rsp, 0xF0
0000785dab1d4886  vmovaps [rsp], xmm0
0000785dab1d488b  vmovaps [rsp+0x10], xmm1
0000785dab1d4891  vmovaps [rsp+0x20], xmm2
0000785dab1d4897  vmovaps [rsp+0x30], xmm3
0000785dab1d489d  vmovaps [rsp+0x40], xmm4
0000785dab1d48a3  vmovaps [rsp+0x50], xmm5
0000785dab1d48a9  vmovaps [rsp+0x60], xmm6
0000785dab1d48af  vmovaps [rsp+0x70], xmm7
0000785dab1d48b5  vmovaps [rsp+0x80], xmm8
0000785dab1d48be  vmovaps [rsp+0x90], xmm9
0000785dab1d48c7  vmovaps [rsp+0xA0], xmm10
0000785dab1d48d0  vmovaps [rsp+0xB0], xmm11
0000785dab1d48d9  vmovaps [rsp+0xC0], xmm12
0000785dab1d48e2  vmovaps [rsp+0xD0], xmm14
0000785dab1d48eb  vmovaps [rsp+0xE0], xmm15
0000785dab1d48f4  sub rsp, 0x30
0000785dab1d48f8  movaps [rsp], xmm13
0000785dab1d48fd  movaps [rsp+0x10], xmm1
0000785dab1d4902  movaps [rsp+0x20], xmm8
0000785dab1d4908  lea rdi, [rsp]
0000785dab1d490c  mov esi, 0x00
0000785dab1d4911  mov rax, 0x61B13BBD6530
0000785dab1d491b  call rax
0000785dab1d491d  movaps xmm13, [rsp]
0000785dab1d4922  add rsp, 0x30
0000785dab1d4926  vmovaps xmm0, [rsp]
0000785dab1d492b  vmovaps xmm1, [rsp+0x10]
0000785dab1d4931  vmovaps xmm2, [rsp+0x20]
0000785dab1d4937  vmovaps xmm3, [rsp+0x30]
0000785dab1d493d  vmovaps xmm4, [rsp+0x40]
0000785dab1d4943  vmovaps xmm5, [rsp+0x50]
0000785dab1d4949  vmovaps xmm6, [rsp+0x60]
0000785dab1d494f  vmovaps xmm7, [rsp+0x70]
0000785dab1d4955  vmovaps xmm8, [rsp+0x80]
0000785dab1d495e  vmovaps xmm9, [rsp+0x90]
0000785dab1d4967  vmovaps xmm10, [rsp+0xA0]
0000785dab1d4970  vmovaps xmm11, [rsp+0xB0]
0000785dab1d4979  vmovaps xmm12, [rsp+0xC0]
0000785dab1d4982  vmovaps xmm14, [rsp+0xD0]
0000785dab1d498b  vmovaps xmm15, [rsp+0xE0]
0000785dab1d4994  add rsp, 0xF0
0000785dab1d499b  pop r11
0000785dab1d499d  pop r10
0000785dab1d499f  pop r9
0000785dab1d49a1  pop r8
0000785dab1d49a3  pop rsi
0000785dab1d49a4  pop rdi
0000785dab1d49a5  pop rdx
0000785dab1d49a6  pop rcx
0000785dab1d49a7  pop rax
0000785dab1d49a8  add rsp, 0x08
0000785dab1d49ac  jmp 0x0000785DAB1D0183
0000785dab1d49b1  call 0x0000785DAAFFF430
0000785dab1d49b6  jmp 0x0000785DAB1D018D
0000785dab1d49bb  sub rsp, 0x08
0000785dab1d49bf  push rax
0000785dab1d49c0  push rcx
0000785dab1d49c1  push rdx
0000785dab1d49c2  push rdi
0000785dab1d49c3  push rsi
0000785dab1d49c4  push r8
0000785dab1d49c6  push r9
0000785dab1d49c8  push r10
0000785dab1d49ca  push r11
0000785dab1d49cc  sub rsp, 0xF0
0000785dab1d49d3  vmovaps [rsp], xmm0
0000785dab1d49d8  vmovaps [rsp+0x10], xmm1
0000785dab1d49de  vmovaps [rsp+0x20], xmm2
0000785dab1d49e4  vmovaps [rsp+0x30], xmm3
0000785dab1d49ea  vmovaps [rsp+0x40], xmm4
0000785dab1d49f0  vmovaps [rsp+0x50], xmm5
0000785dab1d49f6  vmovaps [rsp+0x60], xmm6
0000785dab1d49fc  vmovaps [rsp+0x70], xmm7
0000785dab1d4a02  vmovaps [rsp+0x80], xmm9
0000785dab1d4a0b  vmovaps [rsp+0x90], xmm10
0000785dab1d4a14  vmovaps [rsp+0xA0], xmm11
0000785dab1d4a1d  vmovaps [rsp+0xB0], xmm12
0000785dab1d4a26  vmovaps [rsp+0xC0], xmm13
0000785dab1d4a2f  vmovaps [rsp+0xD0], xmm14
0000785dab1d4a38  vmovaps [rsp+0xE0], xmm15
0000785dab1d4a41  sub rsp, 0x30
0000785dab1d4a45  movaps [rsp], xmm8
0000785dab1d4a4a  movaps [rsp+0x10], xmm14
0000785dab1d4a50  movaps [rsp+0x20], xmm9
0000785dab1d4a56  lea rdi, [rsp]
0000785dab1d4a5a  mov esi, 0x00
0000785dab1d4a5f  mov rax, 0x61B13BBD6530
0000785dab1d4a69  call rax
0000785dab1d4a6b  movaps xmm8, [rsp]
0000785dab1d4a70  add rsp, 0x30
0000785dab1d4a74  vmovaps xmm0, [rsp]
0000785dab1d4a79  vmovaps xmm1, [rsp+0x10]
0000785dab1d4a7f  vmovaps xmm2, [rsp+0x20]
0000785dab1d4a85  vmovaps xmm3, [rsp+0x30]
0000785dab1d4a8b  vmovaps xmm4, [rsp+0x40]
0000785dab1d4a91  vmovaps xmm5, [rsp+0x50]
0000785dab1d4a97  vmovaps xmm6, [rsp+0x60]
0000785dab1d4a9d  vmovaps xmm7, [rsp+0x70]
0000785dab1d4aa3  vmovaps xmm9, [rsp+0x80]
0000785dab1d4aac  vmovaps xmm10, [rsp+0x90]
0000785dab1d4ab5  vmovaps xmm11, [rsp+0xA0]
0000785dab1d4abe  vmovaps xmm12, [rsp+0xB0]
0000785dab1d4ac7  vmovaps xmm13, [rsp+0xC0]
0000785dab1d4ad0  vmovaps xmm14, [rsp+0xD0]
0000785dab1d4ad9  vmovaps xmm15, [rsp+0xE0]
0000785dab1d4ae2  add rsp, 0xF0
0000785dab1d4ae9  pop r11
0000785dab1d4aeb  pop r10
0000785dab1d4aed  pop r9
0000785dab1d4aef  pop r8
0000785dab1d4af1  pop rsi
0000785dab1d4af2  pop rdi
0000785dab1d4af3  pop rdx
0000785dab1d4af4  pop rcx
0000785dab1d4af5  pop rax
0000785dab1d4af6  add rsp, 0x08
0000785dab1d4afa  jmp 0x0000785DAB1D01AF
0000785dab1d4aff  sub rsp, 0x08
0000785dab1d4b03  push rax
0000785dab1d4b04  push rcx
0000785dab1d4b05  push rdx
0000785dab1d4b06  push rdi
0000785dab1d4b07  push rsi
0000785dab1d4b08  push r8
0000785dab1d4b0a  push r9
0000785dab1d4b0c  push r10
0000785dab1d4b0e  push r11
0000785dab1d4b10  sub rsp, 0xF0
0000785dab1d4b17  vmovaps [rsp], xmm0
0000785dab1d4b1c  vmovaps [rsp+0x10], xmm1
0000785dab1d4b22  vmovaps [rsp+0x20], xmm2
0000785dab1d4b28  vmovaps [rsp+0x30], xmm3
0000785dab1d4b2e  vmovaps [rsp+0x40], xmm4
0000785dab1d4b34  vmovaps [rsp+0x50], xmm5
0000785dab1d4b3a  vmovaps [rsp+0x60], xmm6
0000785dab1d4b40  vmovaps [rsp+0x70], xmm7
0000785dab1d4b46  vmovaps [rsp+0x80], xmm8
0000785dab1d4b4f  vmovaps [rsp+0x90], xmm10
0000785dab1d4b58  vmovaps [rsp+0xA0], xmm11
0000785dab1d4b61  vmovaps [rsp+0xB0], xmm12
0000785dab1d4b6a  vmovaps [rsp+0xC0], xmm13
0000785dab1d4b73  vmovaps [rsp+0xD0], xmm14
0000785dab1d4b7c  vmovaps [rsp+0xE0], xmm15
0000785dab1d4b85  sub rsp, 0x30
0000785dab1d4b89  movaps [rsp], xmm9
0000785dab1d4b8e  movaps [rsp+0x10], xmm1
0000785dab1d4b93  movaps [rsp+0x20], xmm14
0000785dab1d4b99  lea rdi, [rsp]
0000785dab1d4b9d  mov esi, 0x00
0000785dab1d4ba2  mov rax, 0x61B13BBD6530
0000785dab1d4bac  call rax
0000785dab1d4bae  movaps xmm9, [rsp]
0000785dab1d4bb3  add rsp, 0x30
0000785dab1d4bb7  vmovaps xmm0, [rsp]
0000785dab1d4bbc  vmovaps xmm1, [rsp+0x10]
0000785dab1d4bc2  vmovaps xmm2, [rsp+0x20]
0000785dab1d4bc8  vmovaps xmm3, [rsp+0x30]
0000785dab1d4bce  vmovaps xmm4, [rsp+0x40]
0000785dab1d4bd4  vmovaps xmm5, [rsp+0x50]
0000785dab1d4bda  vmovaps xmm6, [rsp+0x60]
0000785dab1d4be0  vmovaps xmm7, [rsp+0x70]
0000785dab1d4be6  vmovaps xmm8, [rsp+0x80]
0000785dab1d4bef  vmovaps xmm10, [rsp+0x90]
0000785dab1d4bf8  vmovaps xmm11, [rsp+0xA0]
0000785dab1d4c01  vmovaps xmm12, [rsp+0xB0]
0000785dab1d4c0a  vmovaps xmm13, [rsp+0xC0]
0000785dab1d4c13  vmovaps xmm14, [rsp+0xD0]
0000785dab1d4c1c  vmovaps xmm15, [rsp+0xE0]
0000785dab1d4c25  add rsp, 0xF0
0000785dab1d4c2c  pop r11
0000785dab1d4c2e  pop r10
0000785dab1d4c30  pop r9
0000785dab1d4c32  pop r8
0000785dab1d4c34  pop rsi
0000785dab1d4c35  pop rdi
0000785dab1d4c36  pop rdx
0000785dab1d4c37  pop rcx
0000785dab1d4c38  pop rax
0000785dab1d4c39  add rsp, 0x08
0000785dab1d4c3d  jmp 0x0000785DAB1D01DD
0000785dab1d4c42  sub rsp, 0x08
0000785dab1d4c46  push rax
0000785dab1d4c47  push rcx
0000785dab1d4c48  push rdx
0000785dab1d4c49  push rdi
0000785dab1d4c4a  push rsi
0000785dab1d4c4b  push r8
0000785dab1d4c4d  push r9
0000785dab1d4c4f  push r10
0000785dab1d4c51  push r11
0000785dab1d4c53  sub rsp, 0xF0
0000785dab1d4c5a  vmovaps [rsp], xmm0
0000785dab1d4c5f  vmovaps [rsp+0x10], xmm1
0000785dab1d4c65  vmovaps [rsp+0x20], xmm2
0000785dab1d4c6b  vmovaps [rsp+0x30], xmm3
0000785dab1d4c71  vmovaps [rsp+0x40], xmm4
0000785dab1d4c77  vmovaps [rsp+0x50], xmm5
0000785dab1d4c7d  vmovaps [rsp+0x60], xmm6
0000785dab1d4c83  vmovaps [rsp+0x70], xmm7
0000785dab1d4c89  vmovaps [rsp+0x80], xmm8
0000785dab1d4c92  vmovaps [rsp+0x90], xmm9
0000785dab1d4c9b  vmovaps [rsp+0xA0], xmm10
0000785dab1d4ca4  vmovaps [rsp+0xB0], xmm11
0000785dab1d4cad  vmovaps [rsp+0xC0], xmm12
0000785dab1d4cb6  vmovaps [rsp+0xD0], xmm13
0000785dab1d4cbf  vmovaps [rsp+0xE0], xmm15
0000785dab1d4cc8  sub rsp, 0x30
0000785dab1d4ccc  movaps [rsp], xmm14
0000785dab1d4cd1  movaps [rsp+0x10], xmm4
0000785dab1d4cd6  movaps [rsp+0x20], xmm1
0000785dab1d4cdb  lea rdi, [rsp]
0000785dab1d4cdf  mov esi, 0x00
0000785dab1d4ce4  mov rax, 0x61B13BBD6530
0000785dab1d4cee  call rax
0000785dab1d4cf0  movaps xmm14, [rsp]
0000785dab1d4cf5  add rsp, 0x30
0000785dab1d4cf9  vmovaps xmm0, [rsp]
0000785dab1d4cfe  vmovaps xmm1, [rsp+0x10]
0000785dab1d4d04  vmovaps xmm2, [rsp+0x20]
0000785dab1d4d0a  vmovaps xmm3, [rsp+0x30]
0000785dab1d4d10  vmovaps xmm4, [rsp+0x40]
0000785dab1d4d16  vmovaps xmm5, [rsp+0x50]
0000785dab1d4d1c  vmovaps xmm6, [rsp+0x60]
0000785dab1d4d22  vmovaps xmm7, [rsp+0x70]
0000785dab1d4d28  vmovaps xmm8, [rsp+0x80]
0000785dab1d4d31  vmovaps xmm9, [rsp+0x90]
0000785dab1d4d3a  vmovaps xmm10, [rsp+0xA0]
0000785dab1d4d43  vmovaps xmm11, [rsp+0xB0]
0000785dab1d4d4c  vmovaps xmm12, [rsp+0xC0]
0000785dab1d4d55  vmovaps xmm13, [rsp+0xD0]
0000785dab1d4d5e  vmovaps xmm15, [rsp+0xE0]
0000785dab1d4d67  add rsp, 0xF0
0000785dab1d4d6e  pop r11
0000785dab1d4d70  pop r10
0000785dab1d4d72  pop r9
0000785dab1d4d74  pop r8
0000785dab1d4d76  pop rsi
0000785dab1d4d77  pop rdi
0000785dab1d4d78  pop rdx
0000785dab1d4d79  pop rcx
0000785dab1d4d7a  pop rax
0000785dab1d4d7b  add rsp, 0x08
0000785dab1d4d7f  jmp 0x0000785DAB1D0203
0000785dab1d4d84  sub rsp, 0x08
0000785dab1d4d88  push rax
0000785dab1d4d89  push rcx
0000785dab1d4d8a  push rdx
0000785dab1d4d8b  push rdi
0000785dab1d4d8c  push rsi
0000785dab1d4d8d  push r8
0000785dab1d4d8f  push r9
0000785dab1d4d91  push r10
0000785dab1d4d93  push r11
0000785dab1d4d95  sub rsp, 0xF0
0000785dab1d4d9c  vmovaps [rsp], xmm0
0000785dab1d4da1  vmovaps [rsp+0x10], xmm2
0000785dab1d4da7  vmovaps [rsp+0x20], xmm3
0000785dab1d4dad  vmovaps [rsp+0x30], xmm4
0000785dab1d4db3  vmovaps [rsp+0x40], xmm5
0000785dab1d4db9  vmovaps [rsp+0x50], xmm6
0000785dab1d4dbf  vmovaps [rsp+0x60], xmm7
0000785dab1d4dc5  vmovaps [rsp+0x70], xmm8
0000785dab1d4dcb  vmovaps [rsp+0x80], xmm9
0000785dab1d4dd4  vmovaps [rsp+0x90], xmm10
0000785dab1d4ddd  vmovaps [rsp+0xA0], xmm11
0000785dab1d4de6  vmovaps [rsp+0xB0], xmm12
0000785dab1d4def  vmovaps [rsp+0xC0], xmm13
0000785dab1d4df8  vmovaps [rsp+0xD0], xmm14
0000785dab1d4e01  vmovaps [rsp+0xE0], xmm15
0000785dab1d4e0a  sub rsp, 0x30
0000785dab1d4e0e  movaps [rsp], xmm1
0000785dab1d4e12  movaps [rsp+0x10], xmm12
0000785dab1d4e18  movaps [rsp+0x20], xmm11
0000785dab1d4e1e  lea rdi, [rsp]
0000785dab1d4e22  mov esi, 0x00
0000785dab1d4e27  mov rax, 0x61B13BBD6530
0000785dab1d4e31  call rax
0000785dab1d4e33  movaps xmm1, [rsp]
0000785dab1d4e37  add rsp, 0x30
0000785dab1d4e3b  vmovaps xmm0, [rsp]
0000785dab1d4e40  vmovaps xmm2, [rsp+0x10]
0000785dab1d4e46  vmovaps xmm3, [rsp+0x20]
0000785dab1d4e4c  vmovaps xmm4, [rsp+0x30]
0000785dab1d4e52  vmovaps xmm5, [rsp+0x40]
0000785dab1d4e58  vmovaps xmm6, [rsp+0x50]
0000785dab1d4e5e  vmovaps xmm7, [rsp+0x60]
0000785dab1d4e64  vmovaps xmm8, [rsp+0x70]
0000785dab1d4e6a  vmovaps xmm9, [rsp+0x80]
0000785dab1d4e73  vmovaps xmm10, [rsp+0x90]
0000785dab1d4e7c  vmovaps xmm11, [rsp+0xA0]
0000785dab1d4e85  vmovaps xmm12, [rsp+0xB0]
0000785dab1d4e8e  vmovaps xmm13, [rsp+0xC0]
0000785dab1d4e97  vmovaps xmm14, [rsp+0xD0]
0000785dab1d4ea0  vmovaps xmm15, [rsp+0xE0]
0000785dab1d4ea9  add rsp, 0xF0
0000785dab1d4eb0  pop r11
0000785dab1d4eb2  pop r10
0000785dab1d4eb4  pop r9
0000785dab1d4eb6  pop r8
0000785dab1d4eb8  pop rsi
0000785dab1d4eb9  pop rdi
0000785dab1d4eba  pop rdx
0000785dab1d4ebb  pop rcx
0000785dab1d4ebc  pop rax
0000785dab1d4ebd  add rsp, 0x08
0000785dab1d4ec1  jmp 0x0000785DAB1D0224
0000785dab1d4ec6  call 0x0000785DAB0E20A0
0000785dab1d4ecb  jmp 0x0000785DAB1D0232
0000785dab1d4ed0  call 0x0000785DAB009D70
0000785dab1d4ed5  jmp 0x0000785DAB1D023C
0000785dab1d4eda  sub rsp, 0x08
0000785dab1d4ede  push rax
0000785dab1d4edf  push rcx
0000785dab1d4ee0  push rdx
0000785dab1d4ee1  push rdi
0000785dab1d4ee2  push rsi
0000785dab1d4ee3  push r8
0000785dab1d4ee5  push r9
0000785dab1d4ee7  push r10
0000785dab1d4ee9  push r11
0000785dab1d4eeb  sub rsp, 0xF0
0000785dab1d4ef2  vmovaps [rsp], xmm0
0000785dab1d4ef7  vmovaps [rsp+0x10], xmm1
0000785dab1d4efd  vmovaps [rsp+0x20], xmm2
0000785dab1d4f03  vmovaps [rsp+0x30], xmm3
0000785dab1d4f09  vmovaps [rsp+0x40], xmm4
0000785dab1d4f0f  vmovaps [rsp+0x50], xmm5
0000785dab1d4f15  vmovaps [rsp+0x60], xmm6
0000785dab1d4f1b  vmovaps [rsp+0x70], xmm8
0000785dab1d4f21  vmovaps [rsp+0x80], xmm9
0000785dab1d4f2a  vmovaps [rsp+0x90], xmm10
0000785dab1d4f33  vmovaps [rsp+0xA0], xmm11
0000785dab1d4f3c  vmovaps [rsp+0xB0], xmm12
0000785dab1d4f45  vmovaps [rsp+0xC0], xmm13
0000785dab1d4f4e  vmovaps [rsp+0xD0], xmm14
0000785dab1d4f57  vmovaps [rsp+0xE0], xmm15
0000785dab1d4f60  sub rsp, 0x30
0000785dab1d4f64  movaps [rsp], xmm7
0000785dab1d4f68  movaps [rsp+0x10], xmm15
0000785dab1d4f6e  movaps [rsp+0x20], xmm10
0000785dab1d4f74  lea rdi, [rsp]
0000785dab1d4f78  mov esi, 0x00
0000785dab1d4f7d  mov rax, 0x61B13BBD6530
0000785dab1d4f87  call rax
0000785dab1d4f89  movaps xmm7, [rsp]
0000785dab1d4f8d  add rsp, 0x30
0000785dab1d4f91  vmovaps xmm0, [rsp]
0000785dab1d4f96  vmovaps xmm1, [rsp+0x10]
0000785dab1d4f9c  vmovaps xmm2, [rsp+0x20]
0000785dab1d4fa2  vmovaps xmm3, [rsp+0x30]
0000785dab1d4fa8  vmovaps xmm4, [rsp+0x40]
0000785dab1d4fae  vmovaps xmm5, [rsp+0x50]
0000785dab1d4fb4  vmovaps xmm6, [rsp+0x60]
0000785dab1d4fba  vmovaps xmm8, [rsp+0x70]
0000785dab1d4fc0  vmovaps xmm9, [rsp+0x80]
0000785dab1d4fc9  vmovaps xmm10, [rsp+0x90]
0000785dab1d4fd2  vmovaps xmm11, [rsp+0xA0]
0000785dab1d4fdb  vmovaps xmm12, [rsp+0xB0]
0000785dab1d4fe4  vmovaps xmm13, [rsp+0xC0]
0000785dab1d4fed  vmovaps xmm14, [rsp+0xD0]
0000785dab1d4ff6  vmovaps xmm15, [rsp+0xE0]
0000785dab1d4fff  add rsp, 0xF0
0000785dab1d5006  pop r11
0000785dab1d5008  pop r10
0000785dab1d500a  pop r9
0000785dab1d500c  pop r8
0000785dab1d500e  pop rsi
0000785dab1d500f  pop rdi
0000785dab1d5010  pop rdx
0000785dab1d5011  pop rcx
0000785dab1d5012  pop rax
0000785dab1d5013  add rsp, 0x08
0000785dab1d5017  jmp 0x0000785DAB1D025D
0000785dab1d501c  sub rsp, 0x08
0000785dab1d5020  push rax
0000785dab1d5021  push rcx
0000785dab1d5022  push rdx
0000785dab1d5023  push rdi
0000785dab1d5024  push rsi
0000785dab1d5025  push r8
0000785dab1d5027  push r9
0000785dab1d5029  push r10
0000785dab1d502b  push r11
0000785dab1d502d  sub rsp, 0xF0
0000785dab1d5034  vmovaps [rsp], xmm0
0000785dab1d5039  vmovaps [rsp+0x10], xmm1
0000785dab1d503f  vmovaps [rsp+0x20], xmm2
0000785dab1d5045  vmovaps [rsp+0x30], xmm3
0000785dab1d504b  vmovaps [rsp+0x40], xmm4
0000785dab1d5051  vmovaps [rsp+0x50], xmm5
0000785dab1d5057  vmovaps [rsp+0x60], xmm6
0000785dab1d505d  vmovaps [rsp+0x70], xmm7
0000785dab1d5063  vmovaps [rsp+0x80], xmm8
0000785dab1d506c  vmovaps [rsp+0x90], xmm9
0000785dab1d5075  vmovaps [rsp+0xA0], xmm11
0000785dab1d507e  vmovaps [rsp+0xB0], xmm12
0000785dab1d5087  vmovaps [rsp+0xC0], xmm13
0000785dab1d5090  vmovaps [rsp+0xD0], xmm14
0000785dab1d5099  vmovaps [rsp+0xE0], xmm15
0000785dab1d50a2  sub rsp, 0x30
0000785dab1d50a6  movaps [rsp], xmm10
0000785dab1d50ab  movaps [rsp+0x10], xmm11
0000785dab1d50b1  movaps [rsp+0x20], xmm15
0000785dab1d50b7  lea rdi, [rsp]
0000785dab1d50bb  mov esi, 0x00
0000785dab1d50c0  mov rax, 0x61B13BBD6530
0000785dab1d50ca  call rax
0000785dab1d50cc  movaps xmm10, [rsp]
0000785dab1d50d1  add rsp, 0x30
0000785dab1d50d5  vmovaps xmm0, [rsp]
0000785dab1d50da  vmovaps xmm1, [rsp+0x10]
0000785dab1d50e0  vmovaps xmm2, [rsp+0x20]
0000785dab1d50e6  vmovaps xmm3, [rsp+0x30]
0000785dab1d50ec  vmovaps xmm4, [rsp+0x40]
0000785dab1d50f2  vmovaps xmm5, [rsp+0x50]
0000785dab1d50f8  vmovaps xmm6, [rsp+0x60]
0000785dab1d50fe  vmovaps xmm7, [rsp+0x70]
0000785dab1d5104  vmovaps xmm8, [rsp+0x80]
0000785dab1d510d  vmovaps xmm9, [rsp+0x90]
0000785dab1d5116  vmovaps xmm11, [rsp+0xA0]
0000785dab1d511f  vmovaps xmm12, [rsp+0xB0]
0000785dab1d5128  vmovaps xmm13, [rsp+0xC0]
0000785dab1d5131  vmovaps xmm14, [rsp+0xD0]
0000785dab1d513a  vmovaps xmm15, [rsp+0xE0]
0000785dab1d5143  add rsp, 0xF0
0000785dab1d514a  pop r11
0000785dab1d514c  pop r10
0000785dab1d514e  pop r9
0000785dab1d5150  pop r8
0000785dab1d5152  pop rsi
0000785dab1d5153  pop rdi
0000785dab1d5154  pop rdx
0000785dab1d5155  pop rcx
0000785dab1d5156  pop rax
0000785dab1d5157  add rsp, 0x08
0000785dab1d515b  jmp 0x0000785DAB1D028B
0000785dab1d5160  sub rsp, 0x08
0000785dab1d5164  push rax
0000785dab1d5165  push rcx
0000785dab1d5166  push rdx
0000785dab1d5167  push rdi
0000785dab1d5168  push rsi
0000785dab1d5169  push r8
0000785dab1d516b  push r9
0000785dab1d516d  push r10
0000785dab1d516f  push r11
0000785dab1d5171  sub rsp, 0xF0
0000785dab1d5178  vmovaps [rsp], xmm0
0000785dab1d517d  vmovaps [rsp+0x10], xmm1
0000785dab1d5183  vmovaps [rsp+0x20], xmm2
0000785dab1d5189  vmovaps [rsp+0x30], xmm3
0000785dab1d518f  vmovaps [rsp+0x40], xmm4
0000785dab1d5195  vmovaps [rsp+0x50], xmm5
0000785dab1d519b  vmovaps [rsp+0x60], xmm6
0000785dab1d51a1  vmovaps [rsp+0x70], xmm7
0000785dab1d51a7  vmovaps [rsp+0x80], xmm8
0000785dab1d51b0  vmovaps [rsp+0x90], xmm9
0000785dab1d51b9  vmovaps [rsp+0xA0], xmm10
0000785dab1d51c2  vmovaps [rsp+0xB0], xmm12
0000785dab1d51cb  vmovaps [rsp+0xC0], xmm13
0000785dab1d51d4  vmovaps [rsp+0xD0], xmm14
0000785dab1d51dd  vmovaps [rsp+0xE0], xmm15
0000785dab1d51e6  sub rsp, 0x30
0000785dab1d51ea  movaps [rsp], xmm11
0000785dab1d51ef  movaps [rsp+0x10], xmm12
0000785dab1d51f5  movaps [rsp+0x20], xmm15
0000785dab1d51fb  lea rdi, [rsp]
0000785dab1d51ff  mov esi, 0x00
0000785dab1d5204  mov rax, 0x61B13BBD6530
0000785dab1d520e  call rax
0000785dab1d5210  movaps xmm11, [rsp]
0000785dab1d5215  add rsp, 0x30
0000785dab1d5219  vmovaps xmm0, [rsp]
0000785dab1d521e  vmovaps xmm1, [rsp+0x10]
0000785dab1d5224  vmovaps xmm2, [rsp+0x20]
0000785dab1d522a  vmovaps xmm3, [rsp+0x30]
0000785dab1d5230  vmovaps xmm4, [rsp+0x40]
0000785dab1d5236  vmovaps xmm5, [rsp+0x50]
0000785dab1d523c  vmovaps xmm6, [rsp+0x60]
0000785dab1d5242  vmovaps xmm7, [rsp+0x70]
0000785dab1d5248  vmovaps xmm8, [rsp+0x80]
0000785dab1d5251  vmovaps xmm9, [rsp+0x90]
0000785dab1d525a  vmovaps xmm10, [rsp+0xA0]
0000785dab1d5263  vmovaps xmm12, [rsp+0xB0]
0000785dab1d526c  vmovaps xmm13, [rsp+0xC0]
0000785dab1d5275  vmovaps xmm14, [rsp+0xD0]
0000785dab1d527e  vmovaps xmm15, [rsp+0xE0]
0000785dab1d5287  add rsp, 0xF0
0000785dab1d528e  pop r11
0000785dab1d5290  pop r10
0000785dab1d5292  pop r9
0000785dab1d5294  pop r8
0000785dab1d5296  pop rsi
0000785dab1d5297  pop rdi
0000785dab1d5298  pop rdx
0000785dab1d5299  pop rcx
0000785dab1d529a  pop rax
0000785dab1d529b  add rsp, 0x08
0000785dab1d529f  jmp 0x0000785DAB1D02B9
0000785dab1d52a4  sub rsp, 0x08
0000785dab1d52a8  push rax
0000785dab1d52a9  push rcx
0000785dab1d52aa  push rdx
0000785dab1d52ab  push rdi
0000785dab1d52ac  push rsi
0000785dab1d52ad  push r8
0000785dab1d52af  push r9
0000785dab1d52b1  push r10
0000785dab1d52b3  push r11
0000785dab1d52b5  sub rsp, 0xF0
0000785dab1d52bc  vmovaps [rsp], xmm0
0000785dab1d52c1  vmovaps [rsp+0x10], xmm1
0000785dab1d52c7  vmovaps [rsp+0x20], xmm2
0000785dab1d52cd  vmovaps [rsp+0x30], xmm3
0000785dab1d52d3  vmovaps [rsp+0x40], xmm4
0000785dab1d52d9  vmovaps [rsp+0x50], xmm5
0000785dab1d52df  vmovaps [rsp+0x60], xmm6
0000785dab1d52e5  vmovaps [rsp+0x70], xmm7
0000785dab1d52eb  vmovaps [rsp+0x80], xmm8
0000785dab1d52f4  vmovaps [rsp+0x90], xmm9
0000785dab1d52fd  vmovaps [rsp+0xA0], xmm10
0000785dab1d5306  vmovaps [rsp+0xB0], xmm11
0000785dab1d530f  vmovaps [rsp+0xC0], xmm12
0000785dab1d5318  vmovaps [rsp+0xD0], xmm13
0000785dab1d5321  vmovaps [rsp+0xE0], xmm14
0000785dab1d532a  sub rsp, 0x30
0000785dab1d532e  movaps [rsp], xmm15
0000785dab1d5333  movaps [rsp+0x10], xmm13
0000785dab1d5339  movaps [rsp+0x20], xmm9
0000785dab1d533f  lea rdi, [rsp]
0000785dab1d5343  mov esi, 0x00
0000785dab1d5348  mov rax, 0x61B13BBD6530
0000785dab1d5352  call rax
0000785dab1d5354  movaps xmm15, [rsp]
0000785dab1d5359  add rsp, 0x30
0000785dab1d535d  vmovaps xmm0, [rsp]
0000785dab1d5362  vmovaps xmm1, [rsp+0x10]
0000785dab1d5368  vmovaps xmm2, [rsp+0x20]
0000785dab1d536e  vmovaps xmm3, [rsp+0x30]
0000785dab1d5374  vmovaps xmm4, [rsp+0x40]
0000785dab1d537a  vmovaps xmm5, [rsp+0x50]
0000785dab1d5380  vmovaps xmm6, [rsp+0x60]
0000785dab1d5386  vmovaps xmm7, [rsp+0x70]
0000785dab1d538c  vmovaps xmm8, [rsp+0x80]
0000785dab1d5395  vmovaps xmm9, [rsp+0x90]
0000785dab1d539e  vmovaps xmm10, [rsp+0xA0]
0000785dab1d53a7  vmovaps xmm11, [rsp+0xB0]
0000785dab1d53b0  vmovaps xmm12, [rsp+0xC0]
0000785dab1d53b9  vmovaps xmm13, [rsp+0xD0]
0000785dab1d53c2  vmovaps xmm14, [rsp+0xE0]
0000785dab1d53cb  add rsp, 0xF0
0000785dab1d53d2  pop r11
0000785dab1d53d4  pop r10
0000785dab1d53d6  pop r9
0000785dab1d53d8  pop r8
0000785dab1d53da  pop rsi
0000785dab1d53db  pop rdi
0000785dab1d53dc  pop rdx
0000785dab1d53dd  pop rcx
0000785dab1d53de  pop rax
0000785dab1d53df  add rsp, 0x08
0000785dab1d53e3  jmp 0x0000785DAB1D02D4
0000785dab1d53e8  sub rsp, 0x08
0000785dab1d53ec  push rax
0000785dab1d53ed  push rcx
0000785dab1d53ee  push rdx
0000785dab1d53ef  push rdi
0000785dab1d53f0  push rsi
0000785dab1d53f1  push r8
0000785dab1d53f3  push r9
0000785dab1d53f5  push r10
0000785dab1d53f7  push r11
0000785dab1d53f9  sub rsp, 0xF0
0000785dab1d5400  vmovaps [rsp], xmm0
0000785dab1d5405  vmovaps [rsp+0x10], xmm1
0000785dab1d540b  vmovaps [rsp+0x20], xmm2
0000785dab1d5411  vmovaps [rsp+0x30], xmm3
0000785dab1d5417  vmovaps [rsp+0x40], xmm4
0000785dab1d541d  vmovaps [rsp+0x50], xmm5
0000785dab1d5423  vmovaps [rsp+0x60], xmm6
0000785dab1d5429  vmovaps [rsp+0x70], xmm7
0000785dab1d542f  vmovaps [rsp+0x80], xmm8
0000785dab1d5438  vmovaps [rsp+0x90], xmm9
0000785dab1d5441  vmovaps [rsp+0xA0], xmm10
0000785dab1d544a  vmovaps [rsp+0xB0], xmm11
0000785dab1d5453  vmovaps [rsp+0xC0], xmm12
0000785dab1d545c  vmovaps [rsp+0xD0], xmm14
0000785dab1d5465  vmovaps [rsp+0xE0], xmm15
0000785dab1d546e  sub rsp, 0x30
0000785dab1d5472  movaps [rsp], xmm13
0000785dab1d5477  movaps [rsp+0x10], xmm8
0000785dab1d547d  movaps [rsp+0x20], xmm14
0000785dab1d5483  lea rdi, [rsp]
0000785dab1d5487  mov esi, 0x00
0000785dab1d548c  mov rax, 0x61B13BBD6530
0000785dab1d5496  call rax
0000785dab1d5498  movaps xmm13, [rsp]
0000785dab1d549d  add rsp, 0x30
0000785dab1d54a1  vmovaps xmm0, [rsp]
0000785dab1d54a6  vmovaps xmm1, [rsp+0x10]
0000785dab1d54ac  vmovaps xmm2, [rsp+0x20]
0000785dab1d54b2  vmovaps xmm3, [rsp+0x30]
0000785dab1d54b8  vmovaps xmm4, [rsp+0x40]
0000785dab1d54be  vmovaps xmm5, [rsp+0x50]
0000785dab1d54c4  vmovaps xmm6, [rsp+0x60]
0000785dab1d54ca  vmovaps xmm7, [rsp+0x70]
0000785dab1d54d0  vmovaps xmm8, [rsp+0x80]
0000785dab1d54d9  vmovaps xmm9, [rsp+0x90]
0000785dab1d54e2  vmovaps xmm10, [rsp+0xA0]
0000785dab1d54eb  vmovaps xmm11, [rsp+0xB0]
0000785dab1d54f4  vmovaps xmm12, [rsp+0xC0]
0000785dab1d54fd  vmovaps xmm14, [rsp+0xD0]
0000785dab1d5506  vmovaps xmm15, [rsp+0xE0]
0000785dab1d550f  add rsp, 0xF0
0000785dab1d5516  pop r11
0000785dab1d5518  pop r10
0000785dab1d551a  pop r9
0000785dab1d551c  pop r8
0000785dab1d551e  pop rsi
0000785dab1d551f  pop rdi
0000785dab1d5520  pop rdx
0000785dab1d5521  pop rcx
0000785dab1d5522  pop rax
0000785dab1d5523  add rsp, 0x08
0000785dab1d5527  jmp 0x0000785DAB1D02F7
0000785dab1d552c  sub rsp, 0x08
0000785dab1d5530  push rax
0000785dab1d5531  push rcx
0000785dab1d5532  push rdx
0000785dab1d5533  push rdi
0000785dab1d5534  push rsi
0000785dab1d5535  push r8
0000785dab1d5537  push r9
0000785dab1d5539  push r10
0000785dab1d553b  push r11
0000785dab1d553d  sub rsp, 0xF0
0000785dab1d5544  vmovaps [rsp], xmm0
0000785dab1d5549  vmovaps [rsp+0x10], xmm1
0000785dab1d554f  vmovaps [rsp+0x20], xmm2
0000785dab1d5555  vmovaps [rsp+0x30], xmm3
0000785dab1d555b  vmovaps [rsp+0x40], xmm4
0000785dab1d5561  vmovaps [rsp+0x50], xmm5
0000785dab1d5567  vmovaps [rsp+0x60], xmm6
0000785dab1d556d  vmovaps [rsp+0x70], xmm7
0000785dab1d5573  vmovaps [rsp+0x80], xmm8
0000785dab1d557c  vmovaps [rsp+0x90], xmm9
0000785dab1d5585  vmovaps [rsp+0xA0], xmm10
0000785dab1d558e  vmovaps [rsp+0xB0], xmm11
0000785dab1d5597  vmovaps [rsp+0xC0], xmm12
0000785dab1d55a0  vmovaps [rsp+0xD0], xmm13
0000785dab1d55a9  vmovaps [rsp+0xE0], xmm15
0000785dab1d55b2  sub rsp, 0x30
0000785dab1d55b6  movaps [rsp], xmm14
0000785dab1d55bb  movaps [rsp+0x10], xmm1
0000785dab1d55c0  movaps [rsp+0x20], xmm10
0000785dab1d55c6  lea rdi, [rsp]
0000785dab1d55ca  mov esi, 0x00
0000785dab1d55cf  mov rax, 0x61B13BBD6530
0000785dab1d55d9  call rax
0000785dab1d55db  movaps xmm14, [rsp]
0000785dab1d55e0  add rsp, 0x30
0000785dab1d55e4  vmovaps xmm0, [rsp]
0000785dab1d55e9  vmovaps xmm1, [rsp+0x10]
0000785dab1d55ef  vmovaps xmm2, [rsp+0x20]
0000785dab1d55f5  vmovaps xmm3, [rsp+0x30]
0000785dab1d55fb  vmovaps xmm4, [rsp+0x40]
0000785dab1d5601  vmovaps xmm5, [rsp+0x50]
0000785dab1d5607  vmovaps xmm6, [rsp+0x60]
0000785dab1d560d  vmovaps xmm7, [rsp+0x70]
0000785dab1d5613  vmovaps xmm8, [rsp+0x80]
0000785dab1d561c  vmovaps xmm9, [rsp+0x90]
0000785dab1d5625  vmovaps xmm10, [rsp+0xA0]
0000785dab1d562e  vmovaps xmm11, [rsp+0xB0]
0000785dab1d5637  vmovaps xmm12, [rsp+0xC0]
0000785dab1d5640  vmovaps xmm13, [rsp+0xD0]
0000785dab1d5649  vmovaps xmm15, [rsp+0xE0]
0000785dab1d5652  add rsp, 0xF0
0000785dab1d5659  pop r11
0000785dab1d565b  pop r10
0000785dab1d565d  pop r9
0000785dab1d565f  pop r8
0000785dab1d5661  pop rsi
0000785dab1d5662  pop rdi
0000785dab1d5663  pop rdx
0000785dab1d5664  pop rcx
0000785dab1d5665  pop rax
0000785dab1d5666  add rsp, 0x08
0000785dab1d566a  jmp 0x0000785DAB1D031A
0000785dab1d566f  sub rsp, 0x08
0000785dab1d5673  push rax
0000785dab1d5674  push rcx
0000785dab1d5675  push rdx
0000785dab1d5676  push rdi
0000785dab1d5677  push rsi
0000785dab1d5678  push r8
0000785dab1d567a  push r9
0000785dab1d567c  push r10
0000785dab1d567e  push r11
0000785dab1d5680  sub rsp, 0xF0
0000785dab1d5687  vmovaps [rsp], xmm0
0000785dab1d568c  vmovaps [rsp+0x10], xmm2
0000785dab1d5692  vmovaps [rsp+0x20], xmm3
0000785dab1d5698  vmovaps [rsp+0x30], xmm4
0000785dab1d569e  vmovaps [rsp+0x40], xmm5
0000785dab1d56a4  vmovaps [rsp+0x50], xmm6
0000785dab1d56aa  vmovaps [rsp+0x60], xmm7
0000785dab1d56b0  vmovaps [rsp+0x70], xmm8
0000785dab1d56b6  vmovaps [rsp+0x80], xmm9
0000785dab1d56bf  vmovaps [rsp+0x90], xmm10
0000785dab1d56c8  vmovaps [rsp+0xA0], xmm11
0000785dab1d56d1  vmovaps [rsp+0xB0], xmm12
0000785dab1d56da  vmovaps [rsp+0xC0], xmm13
0000785dab1d56e3  vmovaps [rsp+0xD0], xmm14
0000785dab1d56ec  vmovaps [rsp+0xE0], xmm15
0000785dab1d56f5  sub rsp, 0x30
0000785dab1d56f9  movaps [rsp], xmm1
0000785dab1d56fd  movaps [rsp+0x10], xmm7
0000785dab1d5702  movaps [rsp+0x20], xmm11
0000785dab1d5708  lea rdi, [rsp]
0000785dab1d570c  mov esi, 0x00
0000785dab1d5711  mov rax, 0x61B13BBD6530
0000785dab1d571b  call rax
0000785dab1d571d  movaps xmm1, [rsp]
0000785dab1d5721  add rsp, 0x30
0000785dab1d5725  vmovaps xmm0, [rsp]
0000785dab1d572a  vmovaps xmm2, [rsp+0x10]
0000785dab1d5730  vmovaps xmm3, [rsp+0x20]
0000785dab1d5736  vmovaps xmm4, [rsp+0x30]
0000785dab1d573c  vmovaps xmm5, [rsp+0x40]
0000785dab1d5742  vmovaps xmm6, [rsp+0x50]
0000785dab1d5748  vmovaps xmm7, [rsp+0x60]
0000785dab1d574e  vmovaps xmm8, [rsp+0x70]
0000785dab1d5754  vmovaps xmm9, [rsp+0x80]
0000785dab1d575d  vmovaps xmm10, [rsp+0x90]
0000785dab1d5766  vmovaps xmm11, [rsp+0xA0]
0000785dab1d576f  vmovaps xmm12, [rsp+0xB0]
0000785dab1d5778  vmovaps xmm13, [rsp+0xC0]
0000785dab1d5781  vmovaps xmm14, [rsp+0xD0]
0000785dab1d578a  vmovaps xmm15, [rsp+0xE0]
0000785dab1d5793  add rsp, 0xF0
0000785dab1d579a  pop r11
0000785dab1d579c  pop r10
0000785dab1d579e  pop r9
0000785dab1d57a0  pop r8
0000785dab1d57a2  pop rsi
0000785dab1d57a3  pop rdi
0000785dab1d57a4  pop rdx
0000785dab1d57a5  pop rcx
0000785dab1d57a6  pop rax
0000785dab1d57a7  add rsp, 0x08
0000785dab1d57ab  jmp 0x0000785DAB1D033B
0000785dab1d57b0  call 0x0000785DAB00E880
0000785dab1d57b5  jmp 0x0000785DAB1D034E
0000785dab1d57ba  call 0x0000785DAB00C380
0000785dab1d57bf  jmp 0x0000785DAB1D0359
0000785dab1d57c4  call 0x0000785DAB00D600
0000785dab1d57c9  jmp 0x0000785DAB1D0364
0000785dab1d57ce  call 0x0000785DAAFFF540
0000785dab1d57d3  jmp 0x0000785DAB1D036F
0000785dab1d57d8  int3
0000785dab1d57d9  nop [rax], eax
0000785dab1d57e0  mov rax, [r15+0x40]
0000785dab1d57e4  mov r14, [r15+0x58]
0000785dab1d57e8  lea r12, [rax+r14*1]
0000785dab1d57ec  movaps xmm1, [r15+0x1D0]
0000785dab1d57f4  vmovaps [rsp+0x10], xmm1
0000785dab1d57fa  vmovaps xmm15, [rsp+0x10]
0000785dab1d5800  por xmm1, xmm15
0000785dab1d5805  movaps xmm14, [r15+0x1A0]
0000785dab1d580d  vmovaps [rsp+0x10], xmm14
0000785dab1d5813  vmovaps xmm13, [rsp+0x10]
0000785dab1d5819  por xmm14, xmm13
0000785dab1d581e  lea rax, [r12+0x30]
0000785dab1d5823  mov r11, [r13+rax*1]
0000785dab1d5828  lea rax, [r12+0x38]
0000785dab1d582d  mov r10, [r13+rax*1]
0000785dab1d5832  movq xmm13, r11
0000785dab1d5837  movq xmm12, r10
0000785dab1d583c  movq xmm13, xmm13
0000785dab1d5841  vmovaps [rsp+0x10], xmm13
0000785dab1d5847  movq xmm13, xmm13
0000785dab1d584c  movaps [r15+0x130], xmm13
0000785dab1d5854  movq xmm12, xmm12
0000785dab1d5859  vmovaps [rsp+0x20], xmm12
0000785dab1d585f  movq xmm12, xmm12
0000785dab1d5864  movaps [r15+0x280], xmm12
0000785dab1d586c  movaps xmm13, [r15+0x270]
0000785dab1d5874  vmovaps [rsp+0x30], xmm13
0000785dab1d587a  vmovaps xmm12, [rsp+0x30]
0000785dab1d5880  por xmm13, xmm12
0000785dab1d5885  lea rax, [r12+0x20]
0000785dab1d588a  mov r11, [r13+rax*1]
0000785dab1d588f  lea rax, [r12+0x28]
0000785dab1d5894  mov r10, [r13+rax*1]
0000785dab1d5899  movq xmm12, r11
0000785dab1d589e  movq xmm11, r10
0000785dab1d58a3  movq xmm12, xmm12
0000785dab1d58a8  vmovaps [rsp+0x30], xmm12
0000785dab1d58ae  movq xmm12, xmm12
0000785dab1d58b3  movaps [r15+0x150], xmm12
0000785dab1d58bb  movq xmm11, xmm11
0000785dab1d58c0  vmovaps [rsp+0x40], xmm11
0000785dab1d58c6  movq xmm11, xmm11
0000785dab1d58cb  movaps [r15+0x140], xmm11
0000785dab1d58d3  lea rax, [r12+0x10]
0000785dab1d58d8  mov r11, [r13+rax*1]
0000785dab1d58dd  lea rax, [r12+0x18]
0000785dab1d58e2  mov r10, [r13+rax*1]
0000785dab1d58e7  movq xmm12, r11
0000785dab1d58ec  movq xmm11, r10
0000785dab1d58f1  movq xmm12, xmm12
0000785dab1d58f6  vmovaps [rsp+0x50], xmm12
0000785dab1d58fc  movq xmm12, xmm12
0000785dab1d5901  movaps [r15+0x170], xmm12
0000785dab1d5909  movq xmm11, xmm11
0000785dab1d590e  vmovaps [rsp+0x60], xmm11
0000785dab1d5914  movq xmm11, xmm11
0000785dab1d5919  movaps [r15+0x160], xmm11
0000785dab1d5921  mov rax, [r13+r12*1]
0000785dab1d5926  vmovq xmm12, rax
0000785dab1d592b  vpbroadcastq xmm12, xmm12
0000785dab1d5930  lea rax, [r12+0x08]
0000785dab1d5935  mov r12, [r13+rax*1]
0000785dab1d593a  movq xmm11, r12
0000785dab1d593f  movaps [r15+0x230], xmm11
0000785dab1d5947  mov rax, [r15+0xF8]
0000785dab1d594e  lea r12, [rax+0x50]
0000785dab1d5952  movups xmm11, [r13+r12*1]
0000785dab1d5958  lea r12, [rax+0x60]
0000785dab1d595c  movups xmm10, [r13+r12*1]
0000785dab1d5962  lea r12, [rax+0x30]
0000785dab1d5966  movups xmm9, [r13+r12*1]
0000785dab1d596c  mov r12, [r15+0x50]
0000785dab1d5970  lea r11, [r12+r14*1]
0000785dab1d5974  mov [r15+0x60], r11
0000785dab1d5978  lea r12, [r14+0x40]
0000785dab1d597c  mov [r15+0x58], r12
0000785dab1d5980  movaps xmm8, xmm12
0000785dab1d5984  mulpd xmm8, xmm15
0000785dab1d5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000785dab1d598f  ptest xmm7, xmm7
0000785dab1d5994  jnz 0x0000785DAB1D67B7
0000785dab1d599a  movq xmm15, qword ptr [r15+0x230]
0000785dab1d59a3  vmovaps [rsp+0x70], xmm15
0000785dab1d59a9  vpermilpd xmm15, xmm15, 0x00
0000785dab1d59af  movaps xmm7, xmm9
0000785dab1d59b3  mulpd xmm7, xmm15
0000785dab1d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000785dab1d59bd  ptest xmm6, xmm6
0000785dab1d59c2  jnz 0x0000785DAB1D68FB
0000785dab1d59c8  vxorps xmm15, xmm15, xmm15
0000785dab1d59cd  vpbroadcastq xmm15, xmm15
0000785dab1d59d2  movaps xmm9, xmm12
0000785dab1d59d6  mulpd xmm9, xmm10
0000785dab1d59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000785dab1d59e1  ptest xmm6, xmm6
0000785dab1d59e6  jnz 0x0000785DAB1D6A3D
0000785dab1d59ec  movaps xmm10, xmm12
0000785dab1d59f0  mulpd xmm10, xmm11
0000785dab1d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000785dab1d59fb  ptest xmm6, xmm6
0000785dab1d5a00  jnz 0x0000785DAB1D6B81
0000785dab1d5a06  movaps xmm11, [r15+0x1F0]
0000785dab1d5a0e  movaps xmm6, xmm12
0000785dab1d5a12  mulpd xmm6, xmm11
0000785dab1d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000785dab1d5a1c  ptest xmm5, xmm5
0000785dab1d5a21  jnz 0x0000785DAB1D6CC5
0000785dab1d5a27  movaps xmm12, [r15+0x2A0]
0000785dab1d5a2f  vmovaps [rsp+0x80], xmm12
0000785dab1d5a38  vmovaps xmm11, [rsp+0x80]
0000785dab1d5a41  por xmm12, xmm11
0000785dab1d5a46  movaps xmm11, [r15+0x250]
0000785dab1d5a4e  vmovaps [rsp+0x80], xmm11
0000785dab1d5a57  vmovaps xmm5, [rsp+0x80]
0000785dab1d5a60  por xmm11, xmm5
0000785dab1d5a65  vmovaps xmm4, [rsp+0x70]
0000785dab1d5a6b  vpermilpd xmm4, xmm4, 0x00
0000785dab1d5a71  movaps xmm3, xmm5
0000785dab1d5a74  mulpd xmm3, xmm4
0000785dab1d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000785dab1d5a7d  ptest xmm2, xmm2
0000785dab1d5a82  jnz 0x0000785DAB1D6E07
0000785dab1d5a88  mov [rsp+0x80], rax
0000785dab1d5a90  xor eax, eax
0000785dab1d5a92  mov r14d, 0x200
0000785dab1d5a98  cmp r12, r14
0000785dab1d5a9b  cmc
0000785dab1d5a9c  lahf
0000785dab1d5a9d  seto al
0000785dab1d5aa0  mov [r15+0x108], eax
0000785dab1d5aa7  movaps xmm5, xmm8
0000785dab1d5aab  addpd xmm5, xmm15
0000785dab1d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000785dab1d5ab5  ptest xmm4, xmm4
0000785dab1d5aba  jnz 0x0000785DAB1D6F47
0000785dab1d5ac0  movaps xmm8, [r15+0x1B0]
0000785dab1d5ac8  movaps xmm4, xmm9
0000785dab1d5acc  addpd xmm4, xmm8
0000785dab1d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000785dab1d5ad6  ptest xmm2, xmm2
0000785dab1d5adb  jnz 0x0000785DAB1D7089
0000785dab1d5ae1  movaps xmm9, xmm10
0000785dab1d5ae5  addpd xmm9, xmm8
0000785dab1d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000785dab1d5af0  ptest xmm2, xmm2
0000785dab1d5af5  jnz 0x0000785DAB1D71CB
0000785dab1d5afb  movaps xmm10, [r15+0x2F0]
0000785dab1d5b03  vmovaps [rsp+0x90], xmm10
0000785dab1d5b0c  vmovaps xmm8, [rsp+0x90]
0000785dab1d5b15  por xmm10, xmm8
0000785dab1d5b1a  movaps xmm8, [r15+0x2E0]
0000785dab1d5b22  vmovaps [rsp+0x90], xmm8
0000785dab1d5b2b  vmovaps xmm2, [rsp+0x90]
0000785dab1d5b34  por xmm8, xmm2
0000785dab1d5b39  movaps xmm2, [r15+0x2D0]
0000785dab1d5b41  vmovaps [rsp+0x90], xmm2
0000785dab1d5b4a  vmovaps [rsp+0xA0], xmm1
0000785dab1d5b53  vmovaps xmm1, [rsp+0x90]
0000785dab1d5b5c  por xmm2, xmm1
0000785dab1d5b60  movaps xmm1, [r15+0x200]
0000785dab1d5b68  vmovaps [rsp+0x90], xmm1
0000785dab1d5b71  vmovaps [rsp+0xB0], xmm15
0000785dab1d5b7a  vmovaps xmm15, [rsp+0x90]
0000785dab1d5b83  por xmm1, xmm15
0000785dab1d5b88  movaps xmm15, [r15+0x1C0]
0000785dab1d5b90  vmovaps [rsp+0x90], xmm15
0000785dab1d5b99  vmovaps [rsp+0xC0], xmm1
0000785dab1d5ba2  vmovaps xmm1, [rsp+0x90]
0000785dab1d5bab  por xmm15, xmm1
0000785dab1d5bb0  movaps xmm1, [r15+0x190]
0000785dab1d5bb8  vmovaps [rsp+0x90], xmm1
0000785dab1d5bc1  vmovaps [rsp+0xD0], xmm15
0000785dab1d5bca  vmovaps xmm15, [rsp+0x90]
0000785dab1d5bd3  por xmm1, xmm15
0000785dab1d5bd8  movaps xmm15, [r15+0x300]
0000785dab1d5be0  vmovaps [rsp+0x90], xmm15
0000785dab1d5be9  vmovaps [rsp+0xE0], xmm1
0000785dab1d5bf2  vmovaps xmm1, [rsp+0x90]
0000785dab1d5bfb  por xmm15, xmm1
0000785dab1d5c00  mov rax, [rsp+0x80]
0000785dab1d5c08  lea r14, [rax+0xA0]
0000785dab1d5c0f  movups xmm1, [r13+r14*1]
0000785dab1d5c15  lea r14, [rax+0xB0]
0000785dab1d5c1c  vmovaps [rsp+0x80], xmm1
0000785dab1d5c25  movups xmm1, [r13+r14*1]
0000785dab1d5c2b  vmovaps [rsp+0x90], xmm1
0000785dab1d5c34  vmovaps [rsp+0xF0], xmm15
0000785dab1d5c3d  vmovaps xmm15, [rsp+0xB0]
0000785dab1d5c46  vmovaps [rsp+0xB0], xmm14
0000785dab1d5c4f  movaps xmm1, xmm6
0000785dab1d5c52  addpd xmm1, xmm15
0000785dab1d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000785dab1d5c5c  ptest xmm14, xmm14
0000785dab1d5c62  jnz 0x0000785DAB1D7323
0000785dab1d5c68  lea r14, [rax+0xF0]
0000785dab1d5c6f  movups xmm15, [r13+r14*1]
0000785dab1d5c75  movaps xmm14, xmm4
0000785dab1d5c79  addpd xmm14, xmm3
0000785dab1d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000785dab1d5c84  ptest xmm6, xmm6
0000785dab1d5c89  jnz 0x0000785DAB1D746E
0000785dab1d5c8f  movaps xmm6, xmm9
0000785dab1d5c93  addpd xmm6, xmm7
0000785dab1d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000785dab1d5c9c  ptest xmm4, xmm4
0000785dab1d5ca1  jnz 0x0000785DAB1D75B0
0000785dab1d5ca7  vmovaps xmm9, [rsp+0x70]
0000785dab1d5cad  vpermilpd xmm9, xmm9, 0x00
0000785dab1d5cb3  vmovaps xmm4, [rsp+0x90]
0000785dab1d5cbc  movaps xmm7, xmm4
0000785dab1d5cbf  mulpd xmm7, xmm9
0000785dab1d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000785dab1d5cc9  ptest xmm3, xmm3
0000785dab1d5cce  jnz 0x0000785DAB1D76F1
0000785dab1d5cd4  vmovaps xmm9, [rsp+0x50]
0000785dab1d5cda  vpermilpd xmm9, xmm9, 0x00
0000785dab1d5ce0  movaps xmm4, xmm15
0000785dab1d5ce4  mulpd xmm4, xmm9
0000785dab1d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000785dab1d5cee  ptest xmm3, xmm3
0000785dab1d5cf3  jnz 0x0000785DAB1D7832
0000785dab1d5cf9  lea r14, [rax+0xE0]
0000785dab1d5d00  movups xmm15, [r13+r14*1]
0000785dab1d5d06  vmovaps xmm9, [rsp+0x70]
0000785dab1d5d0c  vpermilpd xmm9, xmm9, 0x00
0000785dab1d5d12  vmovaps [rsp+0x70], xmm1
0000785dab1d5d18  vmovaps xmm1, [rsp+0x80]
0000785dab1d5d21  vmovaps [rsp+0x80], xmm15
0000785dab1d5d2a  movaps xmm3, xmm1
0000785dab1d5d2d  mulpd xmm3, xmm9
0000785dab1d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000785dab1d5d37  ptest xmm15, xmm15
0000785dab1d5d3d  jnz 0x0000785DAB1D797E
0000785dab1d5d43  vmovaps xmm1, [rsp+0xF0]
0000785dab1d5d4c  vmovaps xmm15, [rsp+0xF0]
0000785dab1d5d55  por xmm1, xmm15
0000785dab1d5d5a  movaps [r15+0x300], xmm1
0000785dab1d5d62  vmovaps xmm15, [rsp+0xE0]
0000785dab1d5d6b  vmovaps xmm9, [rsp+0xE0]
0000785dab1d5d74  por xmm15, xmm9
0000785dab1d5d79  movaps [r15+0x190], xmm15
0000785dab1d5d81  vmovaps xmm9, [rsp+0x50]
0000785dab1d5d87  vpermilpd xmm9, xmm9, 0x00
0000785dab1d5d8d  vmovaps [rsp+0x90], xmm1
0000785dab1d5d96  vmovaps [rsp+0xE0], xmm15
0000785dab1d5d9f  vmovaps xmm15, [rsp+0x80]
0000785dab1d5da8  vmovaps [rsp+0x80], xmm14
0000785dab1d5db1  movaps xmm1, xmm15
0000785dab1d5db5  mulpd xmm1, xmm9
0000785dab1d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000785dab1d5dbf  ptest xmm14, xmm14
0000785dab1d5dc5  jnz 0x0000785DAB1D7ABF
0000785dab1d5dcb  lea r14, [rax+0x90]
0000785dab1d5dd2  movups xmm15, [r13+r14*1]
0000785dab1d5dd8  vmovaps xmm14, [rsp+0xD0]
0000785dab1d5de1  vmovaps xmm9, [rsp+0xD0]
0000785dab1d5dea  por xmm14, xmm9
0000785dab1d5def  movaps [r15+0x1C0], xmm14
0000785dab1d5df7  vmovaps xmm9, [rsp+0xC0]
0000785dab1d5e00  vmovaps [rsp+0xD0], xmm1
0000785dab1d5e09  vmovaps xmm1, [rsp+0xC0]
0000785dab1d5e12  por xmm9, xmm1
0000785dab1d5e17  movaps [r15+0x200], xmm9
0000785dab1d5e1f  vmovaps [rsp+0xC0], xmm2
0000785dab1d5e28  vmovaps xmm1, [rsp+0xC0]
0000785dab1d5e31  por xmm2, xmm1
0000785dab1d5e35  movaps [r15+0x2D0], xmm2
0000785dab1d5e3d  vmovaps [rsp+0xC0], xmm8
0000785dab1d5e46  vmovaps xmm1, [rsp+0xC0]
0000785dab1d5e4f  por xmm8, xmm1
0000785dab1d5e54  movaps [r15+0x2E0], xmm8
0000785dab1d5e5c  vmovaps [rsp+0xC0], xmm15
0000785dab1d5e65  movaps xmm1, xmm5
0000785dab1d5e68  addpd xmm1, xmm7
0000785dab1d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000785dab1d5e71  ptest xmm15, xmm15
0000785dab1d5e77  jnz 0x0000785DAB1D7C0B
0000785dab1d5e7d  vmovaps xmm15, [rsp+0x50]
0000785dab1d5e83  vpermilpd xmm15, xmm15, 0x00
0000785dab1d5e89  vmovaps xmm5, [rsp+0xC0]
0000785dab1d5e92  vmovaps [rsp+0xC0], xmm1
0000785dab1d5e9b  movaps xmm7, xmm5
0000785dab1d5e9e  mulpd xmm7, xmm15
0000785dab1d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000785dab1d5ea8  ptest xmm1, xmm1
0000785dab1d5ead  jnz 0x0000785DAB1D7D4B
0000785dab1d5eb3  lea r14, [rax+0x80]
0000785dab1d5eba  movups xmm1, [r13+r14*1]
0000785dab1d5ec0  vmovaps xmm5, [rsp+0x70]
0000785dab1d5ec6  vmovaps [rsp+0x70], xmm1
0000785dab1d5ecc  movaps xmm15, xmm5
0000785dab1d5ed0  addpd xmm15, xmm3
0000785dab1d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000785dab1d5edb  ptest xmm1, xmm1
0000785dab1d5ee0  jnz 0x0000785DAB1D7E96
0000785dab1d5ee6  vmovaps xmm5, [rsp+0x80]
0000785dab1d5eef  movaps xmm1, xmm5
0000785dab1d5ef2  addpd xmm1, xmm4
0000785dab1d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000785dab1d5efb  ptest xmm3, xmm3
0000785dab1d5f00  jnz 0x0000785DAB1D7FD8
0000785dab1d5f06  vmovaps [rsp+0x80], xmm10
0000785dab1d5f0f  vmovaps xmm5, [rsp+0x80]
0000785dab1d5f18  por xmm10, xmm5
0000785dab1d5f1d  movaps [r15+0x2F0], xmm10
0000785dab1d5f25  vmovaps xmm5, [rsp+0x50]
0000785dab1d5f2b  vpermilpd xmm5, xmm5, 0x00
0000785dab1d5f31  vmovaps xmm3, [rsp+0x70]
0000785dab1d5f37  vmovaps [rsp+0x50], xmm1
0000785dab1d5f3d  movaps xmm4, xmm3
0000785dab1d5f40  mulpd xmm4, xmm5
0000785dab1d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000785dab1d5f49  ptest xmm1, xmm1
0000785dab1d5f4e  jnz 0x0000785DAB1D8118
0000785dab1d5f54  lea r14, [rax+0xD0]
0000785dab1d5f5b  movups xmm1, [r13+r14*1]
0000785dab1d5f61  vmovaps xmm3, [rsp+0xD0]
0000785dab1d5f6a  vmovaps [rsp+0x70], xmm1
0000785dab1d5f70  movaps xmm5, xmm6
0000785dab1d5f73  addpd xmm5, xmm3
0000785dab1d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000785dab1d5f7c  ptest xmm1, xmm1
0000785dab1d5f81  jnz 0x0000785DAB1D8262
0000785dab1d5f87  vmovaps xmm1, [rsp+0x60]
0000785dab1d5f8d  vpermilpd xmm1, xmm1, 0x00
0000785dab1d5f93  movaps xmm6, xmm9
0000785dab1d5f97  mulpd xmm6, xmm1
0000785dab1d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000785dab1d5fa0  ptest xmm3, xmm3
0000785dab1d5fa5  jnz 0x0000785DAB1D83A2
0000785dab1d5fab  movaps [r15+0x260], xmm6
0000785dab1d5fb3  vxorps xmm1, xmm1, xmm1
0000785dab1d5fb7  vpbroadcastq xmm1, xmm1
0000785dab1d5fbc  movaps [r15+0x1B0], xmm1
0000785dab1d5fc4  vmovaps xmm1, [rsp+0x60]
0000785dab1d5fca  vpermilpd xmm1, xmm1, 0x00
0000785dab1d5fd0  vmovaps xmm3, [rsp+0x70]
0000785dab1d5fd6  vmovaps [rsp+0x70], xmm15
0000785dab1d5fdc  movaps xmm9, xmm3
0000785dab1d5fe0  mulpd xmm9, xmm1
0000785dab1d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000785dab1d5feb  ptest xmm15, xmm15
0000785dab1d5ff1  jnz 0x0000785DAB1D84E3
0000785dab1d5ff7  lea r14, [rax+0xC0]
0000785dab1d5ffe  movups xmm1, [r13+r14*1]
0000785dab1d6004  vmovaps xmm3, [rsp+0xC0]
0000785dab1d600d  vmovaps [rsp+0x80], xmm1
0000785dab1d6016  movaps xmm15, xmm3
0000785dab1d601a  addpd xmm15, xmm7
0000785dab1d601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000785dab1d6025  ptest xmm1, xmm1
0000785dab1d602a  jnz 0x0000785DAB1D862F
0000785dab1d6030  vmovaps [rsp+0xC0], xmm13
0000785dab1d6039  vmovaps xmm1, [rsp+0xC0]
0000785dab1d6042  por xmm13, xmm1
0000785dab1d6047  movaps [r15+0x270], xmm13
0000785dab1d604f  vmovaps xmm1, [rsp+0xB0]
0000785dab1d6058  vmovaps xmm7, [rsp+0xB0]
0000785dab1d6061  por xmm1, xmm7
0000785dab1d6065  movaps [r15+0x1A0], xmm1
0000785dab1d606d  vmovaps xmm1, [rsp+0x60]
0000785dab1d6073  vpermilpd xmm1, xmm1, 0x00
0000785dab1d6079  vmovaps [rsp+0xB0], xmm1
0000785dab1d6082  vmovaps xmm1, [rsp+0x80]
0000785dab1d608b  vmovaps [rsp+0x80], xmm15
0000785dab1d6094  vmovaps xmm15, [rsp+0xB0]
0000785dab1d609d  vmovaps [rsp+0xB0], xmm14
0000785dab1d60a6  movaps xmm3, xmm1
0000785dab1d60a9  mulpd xmm3, xmm15
0000785dab1d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000785dab1d60b3  ptest xmm14, xmm14
0000785dab1d60b9  jnz 0x0000785DAB1D8771
0000785dab1d60bf  lea r14, [rax+0x20]
0000785dab1d60c3  movups xmm1, [r13+r14*1]
0000785dab1d60c9  movaps [r15+0x110], xmm1
0000785dab1d60d1  vmovaps xmm14, [rsp+0x70]
0000785dab1d60d7  vmovaps [rsp+0x70], xmm1
0000785dab1d60dd  movaps xmm15, xmm14
0000785dab1d60e1  addpd xmm15, xmm4
0000785dab1d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000785dab1d60ec  ptest xmm1, xmm1
0000785dab1d60f1  jnz 0x0000785DAB1D88BC
0000785dab1d60f7  vmovaps xmm1, [rsp+0x60]
0000785dab1d60fd  vpermilpd xmm1, xmm1, 0x00
0000785dab1d6103  movaps xmm14, xmm2
0000785dab1d6107  mulpd xmm14, xmm1
0000785dab1d610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000785dab1d6112  ptest xmm4, xmm4
0000785dab1d6117  jnz 0x0000785DAB1D89FF
0000785dab1d611d  vmovaps xmm4, [rsp+0x50]
0000785dab1d6123  movaps xmm1, xmm4
0000785dab1d6126  addpd xmm1, xmm9
0000785dab1d612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000785dab1d6130  ptest xmm2, xmm2
0000785dab1d6135  jnz 0x0000785DAB1D8B41
0000785dab1d613b  vmovaps xmm9, [rsp+0x30]
0000785dab1d6141  vpermilpd xmm9, xmm9, 0x00
0000785dab1d6147  vmovaps xmm2, [rsp+0x70]
0000785dab1d614d  vmovaps [rsp+0x50], xmm1
0000785dab1d6153  movaps xmm4, xmm2
0000785dab1d6156  mulpd xmm4, xmm9
0000785dab1d615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000785dab1d6160  ptest xmm1, xmm1
0000785dab1d6165  jnz 0x0000785DAB1D8C82
0000785dab1d616b  vmovaps xmm1, [rsp+0x30]
0000785dab1d6171  vpermilpd xmm1, xmm1, 0x00
0000785dab1d6177  vmovaps xmm2, [rsp+0x90]
0000785dab1d6180  vmovaps [rsp+0x60], xmm15
0000785dab1d6186  movaps xmm9, xmm2
0000785dab1d618a  mulpd xmm9, xmm1
0000785dab1d618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000785dab1d6195  ptest xmm15, xmm15
0000785dab1d619b  jnz 0x0000785DAB1D8DC3
0000785dab1d61a1  vmovaps xmm15, [rsp+0x80]
0000785dab1d61aa  movaps xmm1, xmm15
0000785dab1d61ae  addpd xmm1, xmm6
0000785dab1d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000785dab1d61b7  ptest xmm2, xmm2
0000785dab1d61bc  jnz 0x0000785DAB1D8F05
0000785dab1d61c2  movaps xmm15, xmm5
0000785dab1d61c6  addpd xmm15, xmm3
0000785dab1d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000785dab1d61d1  ptest xmm6, xmm6
0000785dab1d61d6  jnz 0x0000785DAB1D9046
0000785dab1d61dc  vmovaps xmm6, [rsp+0x30]
0000785dab1d61e2  vpermilpd xmm6, xmm6, 0x00
0000785dab1d61e8  movaps xmm5, xmm8
0000785dab1d61ec  mulpd xmm5, xmm6
0000785dab1d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000785dab1d61f5  ptest xmm3, xmm3
0000785dab1d61fa  jnz 0x0000785DAB1D9188
0000785dab1d6200  vmovaps xmm8, [rsp+0x30]
0000785dab1d6206  vpermilpd xmm8, xmm8, 0x00
0000785dab1d620c  movaps xmm6, xmm10
0000785dab1d6210  mulpd xmm6, xmm8
0000785dab1d6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000785dab1d621a  ptest xmm3, xmm3
0000785dab1d621f  jnz 0x0000785DAB1D92C9
0000785dab1d6225  vmovaps xmm8, [rsp+0x60]
0000785dab1d622b  movaps xmm10, xmm8
0000785dab1d622f  addpd xmm10, xmm14
0000785dab1d6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000785dab1d623a  ptest xmm3, xmm3
0000785dab1d623f  jnz 0x0000785DAB1D940B
0000785dab1d6245  vmovaps xmm8, [rsp+0x50]
0000785dab1d624b  movaps xmm14, xmm8
0000785dab1d624f  addpd xmm14, xmm4
0000785dab1d6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000785dab1d625a  ptest xmm3, xmm3
0000785dab1d625f  jnz 0x0000785DAB1D954F
0000785dab1d6265  vmovaps xmm8, [rsp+0x40]
0000785dab1d626b  vpermilpd xmm8, xmm8, 0x00
0000785dab1d6271  movaps xmm4, xmm13
0000785dab1d6275  mulpd xmm4, xmm8
0000785dab1d627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000785dab1d627f  ptest xmm3, xmm3
0000785dab1d6284  jnz 0x0000785DAB1D9692
0000785dab1d628a  movaps xmm13, xmm15
0000785dab1d628e  addpd xmm13, xmm9
0000785dab1d6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000785dab1d6299  ptest xmm8, xmm8
0000785dab1d629f  jnz 0x0000785DAB1D97D4
0000785dab1d62a5  movaps xmm15, xmm1
0000785dab1d62a9  addpd xmm15, xmm5
0000785dab1d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000785dab1d62b4  ptest xmm9, xmm9
0000785dab1d62ba  jnz 0x0000785DAB1D9918
0000785dab1d62c0  vmovaps [rsp+0x30], xmm11
0000785dab1d62c6  vmovaps xmm1, [rsp+0x30]
0000785dab1d62cc  por xmm11, xmm1
0000785dab1d62d1  movaps [r15+0x250], xmm11
0000785dab1d62d9  vmovaps [rsp+0x30], xmm12
0000785dab1d62df  vmovaps xmm1, [rsp+0x30]
0000785dab1d62e5  por xmm12, xmm1
0000785dab1d62ea  movaps [r15+0x2A0], xmm12
0000785dab1d62f2  vmovaps xmm1, [rsp+0xA0]
0000785dab1d62fb  vmovaps xmm11, [rsp+0xA0]
0000785dab1d6304  por xmm1, xmm11
0000785dab1d6309  movaps [r15+0x1D0], xmm1
0000785dab1d6311  lea r14, [rax+0x40]
0000785dab1d6315  movups xmm1, [r13+r14*1]
0000785dab1d631b  movaps [r15+0x2C0], xmm1
0000785dab1d6323  vmovaps xmm11, [rsp+0x40]
0000785dab1d6329  vpermilpd xmm11, xmm11, 0x00
0000785dab1d632f  vmovaps xmm8, [rsp+0xE0]
0000785dab1d6338  movaps xmm9, xmm8
0000785dab1d633c  mulpd xmm9, xmm11
0000785dab1d6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000785dab1d6347  ptest xmm5, xmm5
0000785dab1d634c  jnz 0x0000785DAB1D9A64
0000785dab1d6352  movaps xmm11, xmm10
0000785dab1d6356  addpd xmm11, xmm6
0000785dab1d635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000785dab1d6361  ptest xmm8, xmm8
0000785dab1d6367  jnz 0x0000785DAB1D9BA8
0000785dab1d636d  movaps xmm10, xmm14
0000785dab1d6371  addpd xmm10, xmm4
0000785dab1d6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000785dab1d637c  ptest xmm8, xmm8
0000785dab1d6382  jnz 0x0000785DAB1D9CEB
0000785dab1d6388  vmovaps xmm14, [rsp+0x40]
0000785dab1d638e  vpermilpd xmm14, xmm14, 0x00
0000785dab1d6394  movaps xmm8, xmm1
0000785dab1d6398  mulpd xmm8, xmm14
0000785dab1d639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000785dab1d63a3  ptest xmm6, xmm6
0000785dab1d63a8  jnz 0x0000785DAB1D9E2E
0000785dab1d63ae  movaps xmm1, [r15+0x2B0]
0000785dab1d63b6  vmovaps xmm14, [rsp+0x40]
0000785dab1d63bc  vpermilpd xmm14, xmm14, 0x00
0000785dab1d63c2  movaps xmm6, xmm1
0000785dab1d63c5  mulpd xmm6, xmm14
0000785dab1d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000785dab1d63cf  ptest xmm5, xmm5
0000785dab1d63d4  jnz 0x0000785DAB1D9F71
0000785dab1d63da  vmovaps xmm1, [rsp+0x10]
0000785dab1d63e0  vpermilpd xmm1, xmm1, 0x00
0000785dab1d63e6  movaps xmm14, xmm12
0000785dab1d63ea  mulpd xmm14, xmm1
0000785dab1d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000785dab1d63f5  ptest xmm5, xmm5
0000785dab1d63fa  jnz 0x0000785DAB1DA0B2
0000785dab1d6400  movaps xmm1, xmm13
0000785dab1d6404  addpd xmm1, xmm9
0000785dab1d6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000785dab1d640e  ptest xmm12, xmm12
0000785dab1d6414  jnz 0x0000785DAB1DA1F5
0000785dab1d641a  vmovaps xmm13, [rsp+0x10]
0000785dab1d6420  vpermilpd xmm13, xmm13, 0x00
0000785dab1d6426  movaps xmm12, xmm7
0000785dab1d642a  mulpd xmm12, xmm13
0000785dab1d642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000785dab1d6435  ptest xmm9, xmm9
0000785dab1d643b  jnz 0x0000785DAB1DA337
0000785dab1d6441  movaps xmm13, xmm15
0000785dab1d6445  addpd xmm13, xmm8
0000785dab1d644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000785dab1d6450  ptest xmm9, xmm9
0000785dab1d6456  jnz 0x0000785DAB1DA47A
0000785dab1d645c  movaps xmm15, [r15+0x290]
0000785dab1d6464  vmovaps xmm9, [rsp+0x10]
0000785dab1d646a  vpermilpd xmm9, xmm9, 0x00
0000785dab1d6470  movaps xmm8, xmm15
0000785dab1d6474  mulpd xmm8, xmm9
0000785dab1d6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000785dab1d647f  ptest xmm7, xmm7
0000785dab1d6484  jnz 0x0000785DAB1DA5BE
0000785dab1d648a  movaps xmm15, xmm11
0000785dab1d648e  addpd xmm15, xmm6
0000785dab1d6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000785dab1d6499  ptest xmm9, xmm9
0000785dab1d649f  jnz 0x0000785DAB1DA702
0000785dab1d64a5  movaps xmm11, [r15+0x1E0]
0000785dab1d64ad  vmovaps xmm9, [rsp+0x10]
0000785dab1d64b3  vpermilpd xmm9, xmm9, 0x00
0000785dab1d64b9  movaps xmm7, xmm11
0000785dab1d64bd  mulpd xmm7, xmm9
0000785dab1d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000785dab1d64c7  ptest xmm6, xmm6
0000785dab1d64cc  jnz 0x0000785DAB1DA845
0000785dab1d64d2  movaps xmm11, xmm10
0000785dab1d64d6  addpd xmm11, xmm14
0000785dab1d64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000785dab1d64e1  ptest xmm9, xmm9
0000785dab1d64e7  jnz 0x0000785DAB1DA987
0000785dab1d64ed  lea r14, [rax+0x70]
0000785dab1d64f1  movups xmm14, [r13+r14*1]
0000785dab1d64f7  movaps [r15+0x240], xmm14
0000785dab1d64ff  movaps xmm10, xmm1
0000785dab1d6503  addpd xmm10, xmm12
0000785dab1d6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000785dab1d650e  ptest xmm9, xmm9
0000785dab1d6514  jnz 0x0000785DAB1DAAD5
0000785dab1d651a  movaps [r15+0x170], xmm10
0000785dab1d6522  vmovaps xmm1, [rsp+0x20]
0000785dab1d6528  vpermilpd xmm1, xmm1, 0x00
0000785dab1d652e  movaps xmm12, xmm14
0000785dab1d6532  mulpd xmm12, xmm1
0000785dab1d6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000785dab1d653d  ptest xmm9, xmm9
0000785dab1d6543  jnz 0x0000785DAB1DAC18
0000785dab1d6549  vmovaps xmm1, [rsp+0x20]
0000785dab1d654f  vpermilpd xmm1, xmm1, 0x00
0000785dab1d6555  vmovaps xmm9, [rsp+0xB0]
0000785dab1d655e  movaps xmm14, xmm9
0000785dab1d6562  mulpd xmm14, xmm1
0000785dab1d6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000785dab1d656d  ptest xmm6, xmm6
0000785dab1d6572  jnz 0x0000785DAB1DAD5B
0000785dab1d6578  movaps [r15+0x180], xmm14
0000785dab1d6580  movaps xmm1, xmm13
0000785dab1d6584  addpd xmm1, xmm8
0000785dab1d6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000785dab1d658e  ptest xmm9, xmm9
0000785dab1d6594  jnz 0x0000785DAB1DAE9E
0000785dab1d659a  movaps [r15+0x210], xmm1
0000785dab1d65a2  movups xmm13, [r13+rax*1]
0000785dab1d65a8  lea r14, [rax+0x10]
0000785dab1d65ac  movups xmm9, [r13+r14*1]
0000785dab1d65b2  movaps [r15+0x230], xmm9
0000785dab1d65ba  movaps xmm8, xmm15
0000785dab1d65be  addpd xmm8, xmm7
0000785dab1d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000785dab1d65c9  ptest xmm6, xmm6
0000785dab1d65ce  jnz 0x0000785DAB1DAFF4
0000785dab1d65d4  movaps [r15+0x130], xmm8
0000785dab1d65dc  vmovaps xmm15, [rsp+0x20]
0000785dab1d65e2  vpermilpd xmm15, xmm15, 0x00
0000785dab1d65e8  movaps xmm7, xmm9
0000785dab1d65ec  mulpd xmm7, xmm15
0000785dab1d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000785dab1d65f6  ptest xmm6, xmm6
0000785dab1d65fb  jnz 0x0000785DAB1DB137
0000785dab1d6601  movaps [r15+0x220], xmm7
0000785dab1d6609  vmovaps xmm15, [rsp+0x20]
0000785dab1d660f  vpermilpd xmm15, xmm15, 0x00
0000785dab1d6615  movaps xmm9, xmm13
0000785dab1d6619  mulpd xmm9, xmm15
0000785dab1d661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000785dab1d6624  ptest xmm6, xmm6
0000785dab1d6629  jnz 0x0000785DAB1DB279
0000785dab1d662f  movaps xmm15, xmm11
0000785dab1d6633  addpd xmm15, xmm12
0000785dab1d6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000785dab1d663e  ptest xmm13, xmm13
0000785dab1d6644  jnz 0x0000785DAB1DB3BD
0000785dab1d664a  movaps [r15+0x140], xmm15
0000785dab1d6652  movaps xmm13, xmm10
0000785dab1d6656  addpd xmm13, xmm14
0000785dab1d665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000785dab1d6661  ptest xmm12, xmm12
0000785dab1d6667  jnz 0x0000785DAB1DB501
0000785dab1d666d  movaps [r15+0x150], xmm13
0000785dab1d6675  movaps xmm14, xmm1
0000785dab1d6679  addpd xmm14, xmm7
0000785dab1d667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000785dab1d6684  ptest xmm12, xmm12
0000785dab1d668a  jnz 0x0000785DAB1DB645
0000785dab1d6690  movaps [r15+0x160], xmm14
0000785dab1d6698  movaps xmm1, xmm8
0000785dab1d669c  addpd xmm1, xmm9
0000785dab1d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000785dab1d66a6  ptest xmm12, xmm12
0000785dab1d66ac  jnz 0x0000785DAB1DB787
0000785dab1d66b2  movaps [r15+0x120], xmm1
0000785dab1d66ba  movups [r13+r11*1], xmm15
0000785dab1d66c0  lea rax, [r11+0x10]
0000785dab1d66c4  movups [r13+rax*1], xmm13
0000785dab1d66ca  lea rax, [r11+0x20]
0000785dab1d66ce  movups [r13+rax*1], xmm14
0000785dab1d66d4  lea rax, [r11+0x30]
0000785dab1d66d8  movups [r13+rax*1], xmm1
0000785dab1d66de  mov eax, [r15+0x108]
0000785dab1d66e5  sahf
0000785dab1d66e6  jnz 0x0000785DAB1D6718
0000785dab1d66e8  cmp dword ptr [r15+0x318], 0x00
0000785dab1d66f0  jz 0x0000785DAB1DB900
0000785dab1d66f6  nop [rax+rax*1], ax
0000785dab1d66ff  nop [rax+rax*1], eax
0000785dab1d6707  mov eax, 0x410444
0000785dab1d670c  mov [r15+0x100], rax
0000785dab1d6713  jmp 0x0000785DAAFFE110
0000785dab1d6718  cmp dword ptr [r15+0x318], 0x00
0000785dab1d6720  jz 0x0000785DAB1D57E0
0000785dab1d6726  nop [rax+rax*1], ax
0000785dab1d672f  nop [rax+rax*1], eax
0000785dab1d6737  mov eax, 0x410278
0000785dab1d673c  mov [r15+0x100], rax
0000785dab1d6743  jmp 0x0000785DAAFFE110
0000785dab1d6748  int3
0000785dab1d6749  call 0x0000785DAB00A4B0
0000785dab1d674e  jmp 0x0000785DAB1D5828
0000785dab1d6753  call 0x0000785DAB009240
0000785dab1d6758  jmp 0x0000785DAB1D5832
0000785dab1d675d  call 0x0000785DAB00A4B0
0000785dab1d6762  jmp 0x0000785DAB1D588F
0000785dab1d6767  call 0x0000785DAB009240
0000785dab1d676c  jmp 0x0000785DAB1D5899
0000785dab1d6771  call 0x0000785DAB00A4B0
0000785dab1d6776  jmp 0x0000785DAB1D58DD
0000785dab1d677b  call 0x0000785DAB009240
0000785dab1d6780  jmp 0x0000785DAB1D58E7
0000785dab1d6785  call 0x0000785DAB0B47C0
0000785dab1d678a  jmp 0x0000785DAB1D5926
0000785dab1d678f  call 0x0000785DAB00B720
0000785dab1d6794  jmp 0x0000785DAB1D593A
0000785dab1d6799  call 0x0000785DAB0BFC30
0000785dab1d679e  jmp 0x0000785DAB1D5958
0000785dab1d67a3  call 0x0000785DAB0BE9C0
0000785dab1d67a8  jmp 0x0000785DAB1D5962
0000785dab1d67ad  call 0x0000785DAB0BD750
0000785dab1d67b2  jmp 0x0000785DAB1D596C
0000785dab1d67b7  sub rsp, 0x08
0000785dab1d67bb  push rax
0000785dab1d67bc  push rcx
0000785dab1d67bd  push rdx
0000785dab1d67be  push rdi
0000785dab1d67bf  push rsi
0000785dab1d67c0  push r8
0000785dab1d67c2  push r9
0000785dab1d67c4  push r10
0000785dab1d67c6  push r11
0000785dab1d67c8  sub rsp, 0xF0
0000785dab1d67cf  vmovaps [rsp], xmm0
0000785dab1d67d4  vmovaps [rsp+0x10], xmm1
0000785dab1d67da  vmovaps [rsp+0x20], xmm2
0000785dab1d67e0  vmovaps [rsp+0x30], xmm3
0000785dab1d67e6  vmovaps [rsp+0x40], xmm4
0000785dab1d67ec  vmovaps [rsp+0x50], xmm5
0000785dab1d67f2  vmovaps [rsp+0x60], xmm6
0000785dab1d67f8  vmovaps [rsp+0x70], xmm7
0000785dab1d67fe  vmovaps [rsp+0x80], xmm9
0000785dab1d6807  vmovaps [rsp+0x90], xmm10
0000785dab1d6810  vmovaps [rsp+0xA0], xmm11
0000785dab1d6819  vmovaps [rsp+0xB0], xmm12
0000785dab1d6822  vmovaps [rsp+0xC0], xmm13
0000785dab1d682b  vmovaps [rsp+0xD0], xmm14
0000785dab1d6834  vmovaps [rsp+0xE0], xmm15
0000785dab1d683d  sub rsp, 0x30
0000785dab1d6841  movaps [rsp], xmm8
0000785dab1d6846  movaps [rsp+0x10], xmm12
0000785dab1d684c  movaps [rsp+0x20], xmm15
0000785dab1d6852  lea rdi, [rsp]
0000785dab1d6856  mov esi, 0x00
0000785dab1d685b  mov rax, 0x61B13BBD6530
0000785dab1d6865  call rax
0000785dab1d6867  movaps xmm8, [rsp]
0000785dab1d686c  add rsp, 0x30
0000785dab1d6870  vmovaps xmm0, [rsp]
0000785dab1d6875  vmovaps xmm1, [rsp+0x10]
0000785dab1d687b  vmovaps xmm2, [rsp+0x20]
0000785dab1d6881  vmovaps xmm3, [rsp+0x30]
0000785dab1d6887  vmovaps xmm4, [rsp+0x40]
0000785dab1d688d  vmovaps xmm5, [rsp+0x50]
0000785dab1d6893  vmovaps xmm6, [rsp+0x60]
0000785dab1d6899  vmovaps xmm7, [rsp+0x70]
0000785dab1d689f  vmovaps xmm9, [rsp+0x80]
0000785dab1d68a8  vmovaps xmm10, [rsp+0x90]
0000785dab1d68b1  vmovaps xmm11, [rsp+0xA0]
0000785dab1d68ba  vmovaps xmm12, [rsp+0xB0]
0000785dab1d68c3  vmovaps xmm13, [rsp+0xC0]
0000785dab1d68cc  vmovaps xmm14, [rsp+0xD0]
0000785dab1d68d5  vmovaps xmm15, [rsp+0xE0]
0000785dab1d68de  add rsp, 0xF0
0000785dab1d68e5  pop r11
0000785dab1d68e7  pop r10
0000785dab1d68e9  pop r9
0000785dab1d68eb  pop r8
0000785dab1d68ed  pop rsi
0000785dab1d68ee  pop rdi
0000785dab1d68ef  pop rdx
0000785dab1d68f0  pop rcx
0000785dab1d68f1  pop rax
0000785dab1d68f2  add rsp, 0x08
0000785dab1d68f6  jmp 0x0000785DAB1D599A
0000785dab1d68fb  sub rsp, 0x08
0000785dab1d68ff  push rax
0000785dab1d6900  push rcx
0000785dab1d6901  push rdx
0000785dab1d6902  push rdi
0000785dab1d6903  push rsi
0000785dab1d6904  push r8
0000785dab1d6906  push r9
0000785dab1d6908  push r10
0000785dab1d690a  push r11
0000785dab1d690c  sub rsp, 0xF0
0000785dab1d6913  vmovaps [rsp], xmm0
0000785dab1d6918  vmovaps [rsp+0x10], xmm1
0000785dab1d691e  vmovaps [rsp+0x20], xmm2
0000785dab1d6924  vmovaps [rsp+0x30], xmm3
0000785dab1d692a  vmovaps [rsp+0x40], xmm4
0000785dab1d6930  vmovaps [rsp+0x50], xmm5
0000785dab1d6936  vmovaps [rsp+0x60], xmm6
0000785dab1d693c  vmovaps [rsp+0x70], xmm8
0000785dab1d6942  vmovaps [rsp+0x80], xmm9
0000785dab1d694b  vmovaps [rsp+0x90], xmm10
0000785dab1d6954  vmovaps [rsp+0xA0], xmm11
0000785dab1d695d  vmovaps [rsp+0xB0], xmm12
0000785dab1d6966  vmovaps [rsp+0xC0], xmm13
0000785dab1d696f  vmovaps [rsp+0xD0], xmm14
0000785dab1d6978  vmovaps [rsp+0xE0], xmm15
0000785dab1d6981  sub rsp, 0x30
0000785dab1d6985  movaps [rsp], xmm7
0000785dab1d6989  movaps [rsp+0x10], xmm9
0000785dab1d698f  movaps [rsp+0x20], xmm15
0000785dab1d6995  lea rdi, [rsp]
0000785dab1d6999  mov esi, 0x00
0000785dab1d699e  mov rax, 0x61B13BBD6530
0000785dab1d69a8  call rax
0000785dab1d69aa  movaps xmm7, [rsp]
0000785dab1d69ae  add rsp, 0x30
0000785dab1d69b2  vmovaps xmm0, [rsp]
0000785dab1d69b7  vmovaps xmm1, [rsp+0x10]
0000785dab1d69bd  vmovaps xmm2, [rsp+0x20]
0000785dab1d69c3  vmovaps xmm3, [rsp+0x30]
0000785dab1d69c9  vmovaps xmm4, [rsp+0x40]
0000785dab1d69cf  vmovaps xmm5, [rsp+0x50]
0000785dab1d69d5  vmovaps xmm6, [rsp+0x60]
0000785dab1d69db  vmovaps xmm8, [rsp+0x70]
0000785dab1d69e1  vmovaps xmm9, [rsp+0x80]
0000785dab1d69ea  vmovaps xmm10, [rsp+0x90]
0000785dab1d69f3  vmovaps xmm11, [rsp+0xA0]
0000785dab1d69fc  vmovaps xmm12, [rsp+0xB0]
0000785dab1d6a05  vmovaps xmm13, [rsp+0xC0]
0000785dab1d6a0e  vmovaps xmm14, [rsp+0xD0]
0000785dab1d6a17  vmovaps xmm15, [rsp+0xE0]
0000785dab1d6a20  add rsp, 0xF0
0000785dab1d6a27  pop r11
0000785dab1d6a29  pop r10
0000785dab1d6a2b  pop r9
0000785dab1d6a2d  pop r8
0000785dab1d6a2f  pop rsi
0000785dab1d6a30  pop rdi
0000785dab1d6a31  pop rdx
0000785dab1d6a32  pop rcx
0000785dab1d6a33  pop rax
0000785dab1d6a34  add rsp, 0x08
0000785dab1d6a38  jmp 0x0000785DAB1D59C8
0000785dab1d6a3d  sub rsp, 0x08
0000785dab1d6a41  push rax
0000785dab1d6a42  push rcx
0000785dab1d6a43  push rdx
0000785dab1d6a44  push rdi
0000785dab1d6a45  push rsi
0000785dab1d6a46  push r8
0000785dab1d6a48  push r9
0000785dab1d6a4a  push r10
0000785dab1d6a4c  push r11
0000785dab1d6a4e  sub rsp, 0xF0
0000785dab1d6a55  vmovaps [rsp], xmm0
0000785dab1d6a5a  vmovaps [rsp+0x10], xmm1
0000785dab1d6a60  vmovaps [rsp+0x20], xmm2
0000785dab1d6a66  vmovaps [rsp+0x30], xmm3
0000785dab1d6a6c  vmovaps [rsp+0x40], xmm4
0000785dab1d6a72  vmovaps [rsp+0x50], xmm5
0000785dab1d6a78  vmovaps [rsp+0x60], xmm6
0000785dab1d6a7e  vmovaps [rsp+0x70], xmm7
0000785dab1d6a84  vmovaps [rsp+0x80], xmm8
0000785dab1d6a8d  vmovaps [rsp+0x90], xmm10
0000785dab1d6a96  vmovaps [rsp+0xA0], xmm11
0000785dab1d6a9f  vmovaps [rsp+0xB0], xmm12
0000785dab1d6aa8  vmovaps [rsp+0xC0], xmm13
0000785dab1d6ab1  vmovaps [rsp+0xD0], xmm14
0000785dab1d6aba  vmovaps [rsp+0xE0], xmm15
0000785dab1d6ac3  sub rsp, 0x30
0000785dab1d6ac7  movaps [rsp], xmm9
0000785dab1d6acc  movaps [rsp+0x10], xmm12
0000785dab1d6ad2  movaps [rsp+0x20], xmm10
0000785dab1d6ad8  lea rdi, [rsp]
0000785dab1d6adc  mov esi, 0x00
0000785dab1d6ae1  mov rax, 0x61B13BBD6530
0000785dab1d6aeb  call rax
0000785dab1d6aed  movaps xmm9, [rsp]
0000785dab1d6af2  add rsp, 0x30
0000785dab1d6af6  vmovaps xmm0, [rsp]
0000785dab1d6afb  vmovaps xmm1, [rsp+0x10]
0000785dab1d6b01  vmovaps xmm2, [rsp+0x20]
0000785dab1d6b07  vmovaps xmm3, [rsp+0x30]
0000785dab1d6b0d  vmovaps xmm4, [rsp+0x40]
0000785dab1d6b13  vmovaps xmm5, [rsp+0x50]
0000785dab1d6b19  vmovaps xmm6, [rsp+0x60]
0000785dab1d6b1f  vmovaps xmm7, [rsp+0x70]
0000785dab1d6b25  vmovaps xmm8, [rsp+0x80]
0000785dab1d6b2e  vmovaps xmm10, [rsp+0x90]
0000785dab1d6b37  vmovaps xmm11, [rsp+0xA0]
0000785dab1d6b40  vmovaps xmm12, [rsp+0xB0]
0000785dab1d6b49  vmovaps xmm13, [rsp+0xC0]
0000785dab1d6b52  vmovaps xmm14, [rsp+0xD0]
0000785dab1d6b5b  vmovaps xmm15, [rsp+0xE0]
0000785dab1d6b64  add rsp, 0xF0
0000785dab1d6b6b  pop r11
0000785dab1d6b6d  pop r10
0000785dab1d6b6f  pop r9
0000785dab1d6b71  pop r8
0000785dab1d6b73  pop rsi
0000785dab1d6b74  pop rdi
0000785dab1d6b75  pop rdx
0000785dab1d6b76  pop rcx
0000785dab1d6b77  pop rax
0000785dab1d6b78  add rsp, 0x08
0000785dab1d6b7c  jmp 0x0000785DAB1D59EC
0000785dab1d6b81  sub rsp, 0x08
0000785dab1d6b85  push rax
0000785dab1d6b86  push rcx
0000785dab1d6b87  push rdx
0000785dab1d6b88  push rdi
0000785dab1d6b89  push rsi
0000785dab1d6b8a  push r8
0000785dab1d6b8c  push r9
0000785dab1d6b8e  push r10
0000785dab1d6b90  push r11
0000785dab1d6b92  sub rsp, 0xF0
0000785dab1d6b99  vmovaps [rsp], xmm0
0000785dab1d6b9e  vmovaps [rsp+0x10], xmm1
0000785dab1d6ba4  vmovaps [rsp+0x20], xmm2
0000785dab1d6baa  vmovaps [rsp+0x30], xmm3
0000785dab1d6bb0  vmovaps [rsp+0x40], xmm4
0000785dab1d6bb6  vmovaps [rsp+0x50], xmm5
0000785dab1d6bbc  vmovaps [rsp+0x60], xmm6
0000785dab1d6bc2  vmovaps [rsp+0x70], xmm7
0000785dab1d6bc8  vmovaps [rsp+0x80], xmm8
0000785dab1d6bd1  vmovaps [rsp+0x90], xmm9
0000785dab1d6bda  vmovaps [rsp+0xA0], xmm11
0000785dab1d6be3  vmovaps [rsp+0xB0], xmm12
0000785dab1d6bec  vmovaps [rsp+0xC0], xmm13
0000785dab1d6bf5  vmovaps [rsp+0xD0], xmm14
0000785dab1d6bfe  vmovaps [rsp+0xE0], xmm15
0000785dab1d6c07  sub rsp, 0x30
0000785dab1d6c0b  movaps [rsp], xmm10
0000785dab1d6c10  movaps [rsp+0x10], xmm12
0000785dab1d6c16  movaps [rsp+0x20], xmm11
0000785dab1d6c1c  lea rdi, [rsp]
0000785dab1d6c20  mov esi, 0x00
0000785dab1d6c25  mov rax, 0x61B13BBD6530
0000785dab1d6c2f  call rax
0000785dab1d6c31  movaps xmm10, [rsp]
0000785dab1d6c36  add rsp, 0x30
0000785dab1d6c3a  vmovaps xmm0, [rsp]
0000785dab1d6c3f  vmovaps xmm1, [rsp+0x10]
0000785dab1d6c45  vmovaps xmm2, [rsp+0x20]
0000785dab1d6c4b  vmovaps xmm3, [rsp+0x30]
0000785dab1d6c51  vmovaps xmm4, [rsp+0x40]
0000785dab1d6c57  vmovaps xmm5, [rsp+0x50]
0000785dab1d6c5d  vmovaps xmm6, [rsp+0x60]
0000785dab1d6c63  vmovaps xmm7, [rsp+0x70]
0000785dab1d6c69  vmovaps xmm8, [rsp+0x80]
0000785dab1d6c72  vmovaps xmm9, [rsp+0x90]
0000785dab1d6c7b  vmovaps xmm11, [rsp+0xA0]
0000785dab1d6c84  vmovaps xmm12, [rsp+0xB0]
0000785dab1d6c8d  vmovaps xmm13, [rsp+0xC0]
0000785dab1d6c96  vmovaps xmm14, [rsp+0xD0]
0000785dab1d6c9f  vmovaps xmm15, [rsp+0xE0]
0000785dab1d6ca8  add rsp, 0xF0
0000785dab1d6caf  pop r11
0000785dab1d6cb1  pop r10
0000785dab1d6cb3  pop r9
0000785dab1d6cb5  pop r8
0000785dab1d6cb7  pop rsi
0000785dab1d6cb8  pop rdi
0000785dab1d6cb9  pop rdx
0000785dab1d6cba  pop rcx
0000785dab1d6cbb  pop rax
0000785dab1d6cbc  add rsp, 0x08
0000785dab1d6cc0  jmp 0x0000785DAB1D5A06
0000785dab1d6cc5  sub rsp, 0x08
0000785dab1d6cc9  push rax
0000785dab1d6cca  push rcx
0000785dab1d6ccb  push rdx
0000785dab1d6ccc  push rdi
0000785dab1d6ccd  push rsi
0000785dab1d6cce  push r8
0000785dab1d6cd0  push r9
0000785dab1d6cd2  push r10
0000785dab1d6cd4  push r11
0000785dab1d6cd6  sub rsp, 0xF0
0000785dab1d6cdd  vmovaps [rsp], xmm0
0000785dab1d6ce2  vmovaps [rsp+0x10], xmm1
0000785dab1d6ce8  vmovaps [rsp+0x20], xmm2
0000785dab1d6cee  vmovaps [rsp+0x30], xmm3
0000785dab1d6cf4  vmovaps [rsp+0x40], xmm4
0000785dab1d6cfa  vmovaps [rsp+0x50], xmm5
0000785dab1d6d00  vmovaps [rsp+0x60], xmm7
0000785dab1d6d06  vmovaps [rsp+0x70], xmm8
0000785dab1d6d0c  vmovaps [rsp+0x80], xmm9
0000785dab1d6d15  vmovaps [rsp+0x90], xmm10
0000785dab1d6d1e  vmovaps [rsp+0xA0], xmm11
0000785dab1d6d27  vmovaps [rsp+0xB0], xmm12
0000785dab1d6d30  vmovaps [rsp+0xC0], xmm13
0000785dab1d6d39  vmovaps [rsp+0xD0], xmm14
0000785dab1d6d42  vmovaps [rsp+0xE0], xmm15
0000785dab1d6d4b  sub rsp, 0x30
0000785dab1d6d4f  movaps [rsp], xmm6
0000785dab1d6d53  movaps [rsp+0x10], xmm12
0000785dab1d6d59  movaps [rsp+0x20], xmm11
0000785dab1d6d5f  lea rdi, [rsp]
0000785dab1d6d63  mov esi, 0x00
0000785dab1d6d68  mov rax, 0x61B13BBD6530
0000785dab1d6d72  call rax
0000785dab1d6d74  movaps xmm6, [rsp]
0000785dab1d6d78  add rsp, 0x30
0000785dab1d6d7c  vmovaps xmm0, [rsp]
0000785dab1d6d81  vmovaps xmm1, [rsp+0x10]
0000785dab1d6d87  vmovaps xmm2, [rsp+0x20]
0000785dab1d6d8d  vmovaps xmm3, [rsp+0x30]
0000785dab1d6d93  vmovaps xmm4, [rsp+0x40]
0000785dab1d6d99  vmovaps xmm5, [rsp+0x50]
0000785dab1d6d9f  vmovaps xmm7, [rsp+0x60]
0000785dab1d6da5  vmovaps xmm8, [rsp+0x70]
0000785dab1d6dab  vmovaps xmm9, [rsp+0x80]
0000785dab1d6db4  vmovaps xmm10, [rsp+0x90]
0000785dab1d6dbd  vmovaps xmm11, [rsp+0xA0]
0000785dab1d6dc6  vmovaps xmm12, [rsp+0xB0]
0000785dab1d6dcf  vmovaps xmm13, [rsp+0xC0]
0000785dab1d6dd8  vmovaps xmm14, [rsp+0xD0]
0000785dab1d6de1  vmovaps xmm15, [rsp+0xE0]
0000785dab1d6dea  add rsp, 0xF0
0000785dab1d6df1  pop r11
0000785dab1d6df3  pop r10
0000785dab1d6df5  pop r9
0000785dab1d6df7  pop r8
0000785dab1d6df9  pop rsi
0000785dab1d6dfa  pop rdi
0000785dab1d6dfb  pop rdx
0000785dab1d6dfc  pop rcx
0000785dab1d6dfd  pop rax
0000785dab1d6dfe  add rsp, 0x08
0000785dab1d6e02  jmp 0x0000785DAB1D5A27
0000785dab1d6e07  sub rsp, 0x08
0000785dab1d6e0b  push rax
0000785dab1d6e0c  push rcx
0000785dab1d6e0d  push rdx
0000785dab1d6e0e  push rdi
0000785dab1d6e0f  push rsi
0000785dab1d6e10  push r8
0000785dab1d6e12  push r9
0000785dab1d6e14  push r10
0000785dab1d6e16  push r11
0000785dab1d6e18  sub rsp, 0xF0
0000785dab1d6e1f  vmovaps [rsp], xmm0
0000785dab1d6e24  vmovaps [rsp+0x10], xmm1
0000785dab1d6e2a  vmovaps [rsp+0x20], xmm2
0000785dab1d6e30  vmovaps [rsp+0x30], xmm4
0000785dab1d6e36  vmovaps [rsp+0x40], xmm5
0000785dab1d6e3c  vmovaps [rsp+0x50], xmm6
0000785dab1d6e42  vmovaps [rsp+0x60], xmm7
0000785dab1d6e48  vmovaps [rsp+0x70], xmm8
0000785dab1d6e4e  vmovaps [rsp+0x80], xmm9
0000785dab1d6e57  vmovaps [rsp+0x90], xmm10
0000785dab1d6e60  vmovaps [rsp+0xA0], xmm11
0000785dab1d6e69  vmovaps [rsp+0xB0], xmm12
0000785dab1d6e72  vmovaps [rsp+0xC0], xmm13
0000785dab1d6e7b  vmovaps [rsp+0xD0], xmm14
0000785dab1d6e84  vmovaps [rsp+0xE0], xmm15
0000785dab1d6e8d  sub rsp, 0x30
0000785dab1d6e91  movaps [rsp], xmm3
0000785dab1d6e95  movaps [rsp+0x10], xmm5
0000785dab1d6e9a  movaps [rsp+0x20], xmm4
0000785dab1d6e9f  lea rdi, [rsp]
0000785dab1d6ea3  mov esi, 0x00
0000785dab1d6ea8  mov rax, 0x61B13BBD6530
0000785dab1d6eb2  call rax
0000785dab1d6eb4  movaps xmm3, [rsp]
0000785dab1d6eb8  add rsp, 0x30
0000785dab1d6ebc  vmovaps xmm0, [rsp]
0000785dab1d6ec1  vmovaps xmm1, [rsp+0x10]
0000785dab1d6ec7  vmovaps xmm2, [rsp+0x20]
0000785dab1d6ecd  vmovaps xmm4, [rsp+0x30]
0000785dab1d6ed3  vmovaps xmm5, [rsp+0x40]
0000785dab1d6ed9  vmovaps xmm6, [rsp+0x50]
0000785dab1d6edf  vmovaps xmm7, [rsp+0x60]
0000785dab1d6ee5  vmovaps xmm8, [rsp+0x70]
0000785dab1d6eeb  vmovaps xmm9, [rsp+0x80]
0000785dab1d6ef4  vmovaps xmm10, [rsp+0x90]
0000785dab1d6efd  vmovaps xmm11, [rsp+0xA0]
0000785dab1d6f06  vmovaps xmm12, [rsp+0xB0]
0000785dab1d6f0f  vmovaps xmm13, [rsp+0xC0]
0000785dab1d6f18  vmovaps xmm14, [rsp+0xD0]
0000785dab1d6f21  vmovaps xmm15, [rsp+0xE0]
0000785dab1d6f2a  add rsp, 0xF0
0000785dab1d6f31  pop r11
0000785dab1d6f33  pop r10
0000785dab1d6f35  pop r9
0000785dab1d6f37  pop r8
0000785dab1d6f39  pop rsi
0000785dab1d6f3a  pop rdi
0000785dab1d6f3b  pop rdx
0000785dab1d6f3c  pop rcx
0000785dab1d6f3d  pop rax
0000785dab1d6f3e  add rsp, 0x08
0000785dab1d6f42  jmp 0x0000785DAB1D5A88
0000785dab1d6f47  sub rsp, 0x08
0000785dab1d6f4b  push rax
0000785dab1d6f4c  push rcx
0000785dab1d6f4d  push rdx
0000785dab1d6f4e  push rdi
0000785dab1d6f4f  push rsi
0000785dab1d6f50  push r8
0000785dab1d6f52  push r9
0000785dab1d6f54  push r10
0000785dab1d6f56  push r11
0000785dab1d6f58  sub rsp, 0xF0
0000785dab1d6f5f  vmovaps [rsp], xmm0
0000785dab1d6f64  vmovaps [rsp+0x10], xmm1
0000785dab1d6f6a  vmovaps [rsp+0x20], xmm2
0000785dab1d6f70  vmovaps [rsp+0x30], xmm3
0000785dab1d6f76  vmovaps [rsp+0x40], xmm4
0000785dab1d6f7c  vmovaps [rsp+0x50], xmm6
0000785dab1d6f82  vmovaps [rsp+0x60], xmm7
0000785dab1d6f88  vmovaps [rsp+0x70], xmm8
0000785dab1d6f8e  vmovaps [rsp+0x80], xmm9
0000785dab1d6f97  vmovaps [rsp+0x90], xmm10
0000785dab1d6fa0  vmovaps [rsp+0xA0], xmm11
0000785dab1d6fa9  vmovaps [rsp+0xB0], xmm12
0000785dab1d6fb2  vmovaps [rsp+0xC0], xmm13
0000785dab1d6fbb  vmovaps [rsp+0xD0], xmm14
0000785dab1d6fc4  vmovaps [rsp+0xE0], xmm15
0000785dab1d6fcd  sub rsp, 0x30
0000785dab1d6fd1  movaps [rsp], xmm5
0000785dab1d6fd5  movaps [rsp+0x10], xmm8
0000785dab1d6fdb  movaps [rsp+0x20], xmm15
0000785dab1d6fe1  lea rdi, [rsp]
0000785dab1d6fe5  mov esi, 0x00
0000785dab1d6fea  mov rax, 0x61B13BBD6530
0000785dab1d6ff4  call rax
0000785dab1d6ff6  movaps xmm5, [rsp]
0000785dab1d6ffa  add rsp, 0x30
0000785dab1d6ffe  vmovaps xmm0, [rsp]
0000785dab1d7003  vmovaps xmm1, [rsp+0x10]
0000785dab1d7009  vmovaps xmm2, [rsp+0x20]
0000785dab1d700f  vmovaps xmm3, [rsp+0x30]
0000785dab1d7015  vmovaps xmm4, [rsp+0x40]
0000785dab1d701b  vmovaps xmm6, [rsp+0x50]
0000785dab1d7021  vmovaps xmm7, [rsp+0x60]
0000785dab1d7027  vmovaps xmm8, [rsp+0x70]
0000785dab1d702d  vmovaps xmm9, [rsp+0x80]
0000785dab1d7036  vmovaps xmm10, [rsp+0x90]
0000785dab1d703f  vmovaps xmm11, [rsp+0xA0]
0000785dab1d7048  vmovaps xmm12, [rsp+0xB0]
0000785dab1d7051  vmovaps xmm13, [rsp+0xC0]
0000785dab1d705a  vmovaps xmm14, [rsp+0xD0]
0000785dab1d7063  vmovaps xmm15, [rsp+0xE0]
0000785dab1d706c  add rsp, 0xF0
0000785dab1d7073  pop r11
0000785dab1d7075  pop r10
0000785dab1d7077  pop r9
0000785dab1d7079  pop r8
0000785dab1d707b  pop rsi
0000785dab1d707c  pop rdi
0000785dab1d707d  pop rdx
0000785dab1d707e  pop rcx
0000785dab1d707f  pop rax
0000785dab1d7080  add rsp, 0x08
0000785dab1d7084  jmp 0x0000785DAB1D5AC0
0000785dab1d7089  sub rsp, 0x08
0000785dab1d708d  push rax
0000785dab1d708e  push rcx
0000785dab1d708f  push rdx
0000785dab1d7090  push rdi
0000785dab1d7091  push rsi
0000785dab1d7092  push r8
0000785dab1d7094  push r9
0000785dab1d7096  push r10
0000785dab1d7098  push r11
0000785dab1d709a  sub rsp, 0xF0
0000785dab1d70a1  vmovaps [rsp], xmm0
0000785dab1d70a6  vmovaps [rsp+0x10], xmm1
0000785dab1d70ac  vmovaps [rsp+0x20], xmm2
0000785dab1d70b2  vmovaps [rsp+0x30], xmm3
0000785dab1d70b8  vmovaps [rsp+0x40], xmm5
0000785dab1d70be  vmovaps [rsp+0x50], xmm6
0000785dab1d70c4  vmovaps [rsp+0x60], xmm7
0000785dab1d70ca  vmovaps [rsp+0x70], xmm8
0000785dab1d70d0  vmovaps [rsp+0x80], xmm9
0000785dab1d70d9  vmovaps [rsp+0x90], xmm10
0000785dab1d70e2  vmovaps [rsp+0xA0], xmm11
0000785dab1d70eb  vmovaps [rsp+0xB0], xmm12
0000785dab1d70f4  vmovaps [rsp+0xC0], xmm13
0000785dab1d70fd  vmovaps [rsp+0xD0], xmm14
0000785dab1d7106  vmovaps [rsp+0xE0], xmm15
0000785dab1d710f  sub rsp, 0x30
0000785dab1d7113  movaps [rsp], xmm4
0000785dab1d7117  movaps [rsp+0x10], xmm9
0000785dab1d711d  movaps [rsp+0x20], xmm8
0000785dab1d7123  lea rdi, [rsp]
0000785dab1d7127  mov esi, 0x00
0000785dab1d712c  mov rax, 0x61B13BBD6530
0000785dab1d7136  call rax
0000785dab1d7138  movaps xmm4, [rsp]
0000785dab1d713c  add rsp, 0x30
0000785dab1d7140  vmovaps xmm0, [rsp]
0000785dab1d7145  vmovaps xmm1, [rsp+0x10]
0000785dab1d714b  vmovaps xmm2, [rsp+0x20]
0000785dab1d7151  vmovaps xmm3, [rsp+0x30]
0000785dab1d7157  vmovaps xmm5, [rsp+0x40]
0000785dab1d715d  vmovaps xmm6, [rsp+0x50]
0000785dab1d7163  vmovaps xmm7, [rsp+0x60]
0000785dab1d7169  vmovaps xmm8, [rsp+0x70]
0000785dab1d716f  vmovaps xmm9, [rsp+0x80]
0000785dab1d7178  vmovaps xmm10, [rsp+0x90]
0000785dab1d7181  vmovaps xmm11, [rsp+0xA0]
0000785dab1d718a  vmovaps xmm12, [rsp+0xB0]
0000785dab1d7193  vmovaps xmm13, [rsp+0xC0]
0000785dab1d719c  vmovaps xmm14, [rsp+0xD0]
0000785dab1d71a5  vmovaps xmm15, [rsp+0xE0]
0000785dab1d71ae  add rsp, 0xF0
0000785dab1d71b5  pop r11
0000785dab1d71b7  pop r10
0000785dab1d71b9  pop r9
0000785dab1d71bb  pop r8
0000785dab1d71bd  pop rsi
0000785dab1d71be  pop rdi
0000785dab1d71bf  pop rdx
0000785dab1d71c0  pop rcx
0000785dab1d71c1  pop rax
0000785dab1d71c2  add rsp, 0x08
0000785dab1d71c6  jmp 0x0000785DAB1D5AE1
0000785dab1d71cb  sub rsp, 0x08
0000785dab1d71cf  push rax
0000785dab1d71d0  push rcx
0000785dab1d71d1  push rdx
0000785dab1d71d2  push rdi
0000785dab1d71d3  push rsi
0000785dab1d71d4  push r8
0000785dab1d71d6  push r9
0000785dab1d71d8  push r10
0000785dab1d71da  push r11
0000785dab1d71dc  sub rsp, 0xF0
0000785dab1d71e3  vmovaps [rsp], xmm0
0000785dab1d71e8  vmovaps [rsp+0x10], xmm1
0000785dab1d71ee  vmovaps [rsp+0x20], xmm2
0000785dab1d71f4  vmovaps [rsp+0x30], xmm3
0000785dab1d71fa  vmovaps [rsp+0x40], xmm4
0000785dab1d7200  vmovaps [rsp+0x50], xmm5
0000785dab1d7206  vmovaps [rsp+0x60], xmm6
0000785dab1d720c  vmovaps [rsp+0x70], xmm7
0000785dab1d7212  vmovaps [rsp+0x80], xmm8
0000785dab1d721b  vmovaps [rsp+0x90], xmm10
0000785dab1d7224  vmovaps [rsp+0xA0], xmm11
0000785dab1d722d  vmovaps [rsp+0xB0], xmm12
0000785dab1d7236  vmovaps [rsp+0xC0], xmm13
0000785dab1d723f  vmovaps [rsp+0xD0], xmm14
0000785dab1d7248  vmovaps [rsp+0xE0], xmm15
0000785dab1d7251  sub rsp, 0x30
0000785dab1d7255  movaps [rsp], xmm9
0000785dab1d725a  movaps [rsp+0x10], xmm10
0000785dab1d7260  movaps [rsp+0x20], xmm8
0000785dab1d7266  lea rdi, [rsp]
0000785dab1d726a  mov esi, 0x00
0000785dab1d726f  mov rax, 0x61B13BBD6530
0000785dab1d7279  call rax
0000785dab1d727b  movaps xmm9, [rsp]
0000785dab1d7280  add rsp, 0x30
0000785dab1d7284  vmovaps xmm0, [rsp]
0000785dab1d7289  vmovaps xmm1, [rsp+0x10]
0000785dab1d728f  vmovaps xmm2, [rsp+0x20]
0000785dab1d7295  vmovaps xmm3, [rsp+0x30]
0000785dab1d729b  vmovaps xmm4, [rsp+0x40]
0000785dab1d72a1  vmovaps xmm5, [rsp+0x50]
0000785dab1d72a7  vmovaps xmm6, [rsp+0x60]
0000785dab1d72ad  vmovaps xmm7, [rsp+0x70]
0000785dab1d72b3  vmovaps xmm8, [rsp+0x80]
0000785dab1d72bc  vmovaps xmm10, [rsp+0x90]
0000785dab1d72c5  vmovaps xmm11, [rsp+0xA0]
0000785dab1d72ce  vmovaps xmm12, [rsp+0xB0]
0000785dab1d72d7  vmovaps xmm13, [rsp+0xC0]
0000785dab1d72e0  vmovaps xmm14, [rsp+0xD0]
0000785dab1d72e9  vmovaps xmm15, [rsp+0xE0]
0000785dab1d72f2  add rsp, 0xF0
0000785dab1d72f9  pop r11
0000785dab1d72fb  pop r10
0000785dab1d72fd  pop r9
0000785dab1d72ff  pop r8
0000785dab1d7301  pop rsi
0000785dab1d7302  pop rdi
0000785dab1d7303  pop rdx
0000785dab1d7304  pop rcx
0000785dab1d7305  pop rax
0000785dab1d7306  add rsp, 0x08
0000785dab1d730a  jmp 0x0000785DAB1D5AFB
0000785dab1d730f  call 0x0000785DAB0D64F0
0000785dab1d7314  jmp 0x0000785DAB1D5C15
0000785dab1d7319  call 0x0000785DAB0D64F0
0000785dab1d731e  jmp 0x0000785DAB1D5C2B
0000785dab1d7323  sub rsp, 0x08
0000785dab1d7327  push rax
0000785dab1d7328  push rcx
0000785dab1d7329  push rdx
0000785dab1d732a  push rdi
0000785dab1d732b  push rsi
0000785dab1d732c  push r8
0000785dab1d732e  push r9
0000785dab1d7330  push r10
0000785dab1d7332  push r11
0000785dab1d7334  sub rsp, 0xF0
0000785dab1d733b  vmovaps [rsp], xmm0
0000785dab1d7340  vmovaps [rsp+0x10], xmm2
0000785dab1d7346  vmovaps [rsp+0x20], xmm3
0000785dab1d734c  vmovaps [rsp+0x30], xmm4
0000785dab1d7352  vmovaps [rsp+0x40], xmm5
0000785dab1d7358  vmovaps [rsp+0x50], xmm6
0000785dab1d735e  vmovaps [rsp+0x60], xmm7
0000785dab1d7364  vmovaps [rsp+0x70], xmm8
0000785dab1d736a  vmovaps [rsp+0x80], xmm9
0000785dab1d7373  vmovaps [rsp+0x90], xmm10
0000785dab1d737c  vmovaps [rsp+0xA0], xmm11
0000785dab1d7385  vmovaps [rsp+0xB0], xmm12
0000785dab1d738e  vmovaps [rsp+0xC0], xmm13
0000785dab1d7397  vmovaps [rsp+0xD0], xmm14
0000785dab1d73a0  vmovaps [rsp+0xE0], xmm15
0000785dab1d73a9  sub rsp, 0x30
0000785dab1d73ad  movaps [rsp], xmm1
0000785dab1d73b1  movaps [rsp+0x10], xmm6
0000785dab1d73b6  movaps [rsp+0x20], xmm15
0000785dab1d73bc  lea rdi, [rsp]
0000785dab1d73c0  mov esi, 0x00
0000785dab1d73c5  mov rax, 0x61B13BBD6530
0000785dab1d73cf  call rax
0000785dab1d73d1  movaps xmm1, [rsp]
0000785dab1d73d5  add rsp, 0x30
0000785dab1d73d9  vmovaps xmm0, [rsp]
0000785dab1d73de  vmovaps xmm2, [rsp+0x10]
0000785dab1d73e4  vmovaps xmm3, [rsp+0x20]
0000785dab1d73ea  vmovaps xmm4, [rsp+0x30]
0000785dab1d73f0  vmovaps xmm5, [rsp+0x40]
0000785dab1d73f6  vmovaps xmm6, [rsp+0x50]
0000785dab1d73fc  vmovaps xmm7, [rsp+0x60]
0000785dab1d7402  vmovaps xmm8, [rsp+0x70]
0000785dab1d7408  vmovaps xmm9, [rsp+0x80]
0000785dab1d7411  vmovaps xmm10, [rsp+0x90]
0000785dab1d741a  vmovaps xmm11, [rsp+0xA0]
0000785dab1d7423  vmovaps xmm12, [rsp+0xB0]
0000785dab1d742c  vmovaps xmm13, [rsp+0xC0]
0000785dab1d7435  vmovaps xmm14, [rsp+0xD0]
0000785dab1d743e  vmovaps xmm15, [rsp+0xE0]
0000785dab1d7447  add rsp, 0xF0
0000785dab1d744e  pop r11
0000785dab1d7450  pop r10
0000785dab1d7452  pop r9
0000785dab1d7454  pop r8
0000785dab1d7456  pop rsi
0000785dab1d7457  pop rdi
0000785dab1d7458  pop rdx
0000785dab1d7459  pop rcx
0000785dab1d745a  pop rax
0000785dab1d745b  add rsp, 0x08
0000785dab1d745f  jmp 0x0000785DAB1D5C68
0000785dab1d7464  call 0x0000785DAB0E5820
0000785dab1d7469  jmp 0x0000785DAB1D5C75
0000785dab1d746e  sub rsp, 0x08
0000785dab1d7472  push rax
0000785dab1d7473  push rcx
0000785dab1d7474  push rdx
0000785dab1d7475  push rdi
0000785dab1d7476  push rsi
0000785dab1d7477  push r8
0000785dab1d7479  push r9
0000785dab1d747b  push r10
0000785dab1d747d  push r11
0000785dab1d747f  sub rsp, 0xF0
0000785dab1d7486  vmovaps [rsp], xmm0
0000785dab1d748b  vmovaps [rsp+0x10], xmm1
0000785dab1d7491  vmovaps [rsp+0x20], xmm2
0000785dab1d7497  vmovaps [rsp+0x30], xmm3
0000785dab1d749d  vmovaps [rsp+0x40], xmm4
0000785dab1d74a3  vmovaps [rsp+0x50], xmm5
0000785dab1d74a9  vmovaps [rsp+0x60], xmm6
0000785dab1d74af  vmovaps [rsp+0x70], xmm7
0000785dab1d74b5  vmovaps [rsp+0x80], xmm8
0000785dab1d74be  vmovaps [rsp+0x90], xmm9
0000785dab1d74c7  vmovaps [rsp+0xA0], xmm10
0000785dab1d74d0  vmovaps [rsp+0xB0], xmm11
0000785dab1d74d9  vmovaps [rsp+0xC0], xmm12
0000785dab1d74e2  vmovaps [rsp+0xD0], xmm13
0000785dab1d74eb  vmovaps [rsp+0xE0], xmm15
0000785dab1d74f4  sub rsp, 0x30
0000785dab1d74f8  movaps [rsp], xmm14
0000785dab1d74fd  movaps [rsp+0x10], xmm4
0000785dab1d7502  movaps [rsp+0x20], xmm3
0000785dab1d7507  lea rdi, [rsp]
0000785dab1d750b  mov esi, 0x00
0000785dab1d7510  mov rax, 0x61B13BBD6530
0000785dab1d751a  call rax
0000785dab1d751c  movaps xmm14, [rsp]
0000785dab1d7521  add rsp, 0x30
0000785dab1d7525  vmovaps xmm0, [rsp]
0000785dab1d752a  vmovaps xmm1, [rsp+0x10]
0000785dab1d7530  vmovaps xmm2, [rsp+0x20]
0000785dab1d7536  vmovaps xmm3, [rsp+0x30]
0000785dab1d753c  vmovaps xmm4, [rsp+0x40]
0000785dab1d7542  vmovaps xmm5, [rsp+0x50]
0000785dab1d7548  vmovaps xmm6, [rsp+0x60]
0000785dab1d754e  vmovaps xmm7, [rsp+0x70]
0000785dab1d7554  vmovaps xmm8, [rsp+0x80]
0000785dab1d755d  vmovaps xmm9, [rsp+0x90]
0000785dab1d7566  vmovaps xmm10, [rsp+0xA0]
0000785dab1d756f  vmovaps xmm11, [rsp+0xB0]
0000785dab1d7578  vmovaps xmm12, [rsp+0xC0]
0000785dab1d7581  vmovaps xmm13, [rsp+0xD0]
0000785dab1d758a  vmovaps xmm15, [rsp+0xE0]
0000785dab1d7593  add rsp, 0xF0
0000785dab1d759a  pop r11
0000785dab1d759c  pop r10
0000785dab1d759e  pop r9
0000785dab1d75a0  pop r8
0000785dab1d75a2  pop rsi
0000785dab1d75a3  pop rdi
0000785dab1d75a4  pop rdx
0000785dab1d75a5  pop rcx
0000785dab1d75a6  pop rax
0000785dab1d75a7  add rsp, 0x08
0000785dab1d75ab  jmp 0x0000785DAB1D5C8F
0000785dab1d75b0  sub rsp, 0x08
0000785dab1d75b4  push rax
0000785dab1d75b5  push rcx
0000785dab1d75b6  push rdx
0000785dab1d75b7  push rdi
0000785dab1d75b8  push rsi
0000785dab1d75b9  push r8
0000785dab1d75bb  push r9
0000785dab1d75bd  push r10
0000785dab1d75bf  push r11
0000785dab1d75c1  sub rsp, 0xF0
0000785dab1d75c8  vmovaps [rsp], xmm0
0000785dab1d75cd  vmovaps [rsp+0x10], xmm1
0000785dab1d75d3  vmovaps [rsp+0x20], xmm2
0000785dab1d75d9  vmovaps [rsp+0x30], xmm3
0000785dab1d75df  vmovaps [rsp+0x40], xmm4
0000785dab1d75e5  vmovaps [rsp+0x50], xmm5
0000785dab1d75eb  vmovaps [rsp+0x60], xmm7
0000785dab1d75f1  vmovaps [rsp+0x70], xmm8
0000785dab1d75f7  vmovaps [rsp+0x80], xmm9
0000785dab1d7600  vmovaps [rsp+0x90], xmm10
0000785dab1d7609  vmovaps [rsp+0xA0], xmm11
0000785dab1d7612  vmovaps [rsp+0xB0], xmm12
0000785dab1d761b  vmovaps [rsp+0xC0], xmm13
0000785dab1d7624  vmovaps [rsp+0xD0], xmm14
0000785dab1d762d  vmovaps [rsp+0xE0], xmm15
0000785dab1d7636  sub rsp, 0x30
0000785dab1d763a  movaps [rsp], xmm6
0000785dab1d763e  movaps [rsp+0x10], xmm9
0000785dab1d7644  movaps [rsp+0x20], xmm7
0000785dab1d7649  lea rdi, [rsp]
0000785dab1d764d  mov esi, 0x00
0000785dab1d7652  mov rax, 0x61B13BBD6530
0000785dab1d765c  call rax
0000785dab1d765e  movaps xmm6, [rsp]
0000785dab1d7662  add rsp, 0x30
0000785dab1d7666  vmovaps xmm0, [rsp]
0000785dab1d766b  vmovaps xmm1, [rsp+0x10]
0000785dab1d7671  vmovaps xmm2, [rsp+0x20]
0000785dab1d7677  vmovaps xmm3, [rsp+0x30]
0000785dab1d767d  vmovaps xmm4, [rsp+0x40]
0000785dab1d7683  vmovaps xmm5, [rsp+0x50]
0000785dab1d7689  vmovaps xmm7, [rsp+0x60]
0000785dab1d768f  vmovaps xmm8, [rsp+0x70]
0000785dab1d7695  vmovaps xmm9, [rsp+0x80]
0000785dab1d769e  vmovaps xmm10, [rsp+0x90]
0000785dab1d76a7  vmovaps xmm11, [rsp+0xA0]
0000785dab1d76b0  vmovaps xmm12, [rsp+0xB0]
0000785dab1d76b9  vmovaps xmm13, [rsp+0xC0]
0000785dab1d76c2  vmovaps xmm14, [rsp+0xD0]
0000785dab1d76cb  vmovaps xmm15, [rsp+0xE0]
0000785dab1d76d4  add rsp, 0xF0
0000785dab1d76db  pop r11
0000785dab1d76dd  pop r10
0000785dab1d76df  pop r9
0000785dab1d76e1  pop r8
0000785dab1d76e3  pop rsi
0000785dab1d76e4  pop rdi
0000785dab1d76e5  pop rdx
0000785dab1d76e6  pop rcx
0000785dab1d76e7  pop rax
0000785dab1d76e8  add rsp, 0x08
0000785dab1d76ec  jmp 0x0000785DAB1D5CA7
0000785dab1d76f1  sub rsp, 0x08
0000785dab1d76f5  push rax
0000785dab1d76f6  push rcx
0000785dab1d76f7  push rdx
0000785dab1d76f8  push rdi
0000785dab1d76f9  push rsi
0000785dab1d76fa  push r8
0000785dab1d76fc  push r9
0000785dab1d76fe  push r10
0000785dab1d7700  push r11
0000785dab1d7702  sub rsp, 0xF0
0000785dab1d7709  vmovaps [rsp], xmm0
0000785dab1d770e  vmovaps [rsp+0x10], xmm1
0000785dab1d7714  vmovaps [rsp+0x20], xmm2
0000785dab1d771a  vmovaps [rsp+0x30], xmm3
0000785dab1d7720  vmovaps [rsp+0x40], xmm4
0000785dab1d7726  vmovaps [rsp+0x50], xmm5
0000785dab1d772c  vmovaps [rsp+0x60], xmm6
0000785dab1d7732  vmovaps [rsp+0x70], xmm8
0000785dab1d7738  vmovaps [rsp+0x80], xmm9
0000785dab1d7741  vmovaps [rsp+0x90], xmm10
0000785dab1d774a  vmovaps [rsp+0xA0], xmm11
0000785dab1d7753  vmovaps [rsp+0xB0], xmm12
0000785dab1d775c  vmovaps [rsp+0xC0], xmm13
0000785dab1d7765  vmovaps [rsp+0xD0], xmm14
0000785dab1d776e  vmovaps [rsp+0xE0], xmm15
0000785dab1d7777  sub rsp, 0x30
0000785dab1d777b  movaps [rsp], xmm7
0000785dab1d777f  movaps [rsp+0x10], xmm4
0000785dab1d7784  movaps [rsp+0x20], xmm9
0000785dab1d778a  lea rdi, [rsp]
0000785dab1d778e  mov esi, 0x00
0000785dab1d7793  mov rax, 0x61B13BBD6530
0000785dab1d779d  call rax
0000785dab1d779f  movaps xmm7, [rsp]
0000785dab1d77a3  add rsp, 0x30
0000785dab1d77a7  vmovaps xmm0, [rsp]
0000785dab1d77ac  vmovaps xmm1, [rsp+0x10]
0000785dab1d77b2  vmovaps xmm2, [rsp+0x20]
0000785dab1d77b8  vmovaps xmm3, [rsp+0x30]
0000785dab1d77be  vmovaps xmm4, [rsp+0x40]
0000785dab1d77c4  vmovaps xmm5, [rsp+0x50]
0000785dab1d77ca  vmovaps xmm6, [rsp+0x60]
0000785dab1d77d0  vmovaps xmm8, [rsp+0x70]
0000785dab1d77d6  vmovaps xmm9, [rsp+0x80]
0000785dab1d77df  vmovaps xmm10, [rsp+0x90]
0000785dab1d77e8  vmovaps xmm11, [rsp+0xA0]
0000785dab1d77f1  vmovaps xmm12, [rsp+0xB0]
0000785dab1d77fa  vmovaps xmm13, [rsp+0xC0]
0000785dab1d7803  vmovaps xmm14, [rsp+0xD0]
0000785dab1d780c  vmovaps xmm15, [rsp+0xE0]
0000785dab1d7815  add rsp, 0xF0
0000785dab1d781c  pop r11
0000785dab1d781e  pop r10
0000785dab1d7820  pop r9
0000785dab1d7822  pop r8
0000785dab1d7824  pop rsi
0000785dab1d7825  pop rdi
0000785dab1d7826  pop rdx
0000785dab1d7827  pop rcx
0000785dab1d7828  pop rax
0000785dab1d7829  add rsp, 0x08
0000785dab1d782d  jmp 0x0000785DAB1D5CD4
0000785dab1d7832  sub rsp, 0x08
0000785dab1d7836  push rax
0000785dab1d7837  push rcx
0000785dab1d7838  push rdx
0000785dab1d7839  push rdi
0000785dab1d783a  push rsi
0000785dab1d783b  push r8
0000785dab1d783d  push r9
0000785dab1d783f  push r10
0000785dab1d7841  push r11
0000785dab1d7843  sub rsp, 0xF0
0000785dab1d784a  vmovaps [rsp], xmm0
0000785dab1d784f  vmovaps [rsp+0x10], xmm1
0000785dab1d7855  vmovaps [rsp+0x20], xmm2
0000785dab1d785b  vmovaps [rsp+0x30], xmm3
0000785dab1d7861  vmovaps [rsp+0x40], xmm5
0000785dab1d7867  vmovaps [rsp+0x50], xmm6
0000785dab1d786d  vmovaps [rsp+0x60], xmm7
0000785dab1d7873  vmovaps [rsp+0x70], xmm8
0000785dab1d7879  vmovaps [rsp+0x80], xmm9
0000785dab1d7882  vmovaps [rsp+0x90], xmm10
0000785dab1d788b  vmovaps [rsp+0xA0], xmm11
0000785dab1d7894  vmovaps [rsp+0xB0], xmm12
0000785dab1d789d  vmovaps [rsp+0xC0], xmm13
0000785dab1d78a6  vmovaps [rsp+0xD0], xmm14
0000785dab1d78af  vmovaps [rsp+0xE0], xmm15
0000785dab1d78b8  sub rsp, 0x30
0000785dab1d78bc  movaps [rsp], xmm4
0000785dab1d78c0  movaps [rsp+0x10], xmm15
0000785dab1d78c6  movaps [rsp+0x20], xmm9
0000785dab1d78cc  lea rdi, [rsp]
0000785dab1d78d0  mov esi, 0x00
0000785dab1d78d5  mov rax, 0x61B13BBD6530
0000785dab1d78df  call rax
0000785dab1d78e1  movaps xmm4, [rsp]
0000785dab1d78e5  add rsp, 0x30
0000785dab1d78e9  vmovaps xmm0, [rsp]
0000785dab1d78ee  vmovaps xmm1, [rsp+0x10]
0000785dab1d78f4  vmovaps xmm2, [rsp+0x20]
0000785dab1d78fa  vmovaps xmm3, [rsp+0x30]
0000785dab1d7900  vmovaps xmm5, [rsp+0x40]
0000785dab1d7906  vmovaps xmm6, [rsp+0x50]
0000785dab1d790c  vmovaps xmm7, [rsp+0x60]
0000785dab1d7912  vmovaps xmm8, [rsp+0x70]
0000785dab1d7918  vmovaps xmm9, [rsp+0x80]
0000785dab1d7921  vmovaps xmm10, [rsp+0x90]
0000785dab1d792a  vmovaps xmm11, [rsp+0xA0]
0000785dab1d7933  vmovaps xmm12, [rsp+0xB0]
0000785dab1d793c  vmovaps xmm13, [rsp+0xC0]
0000785dab1d7945  vmovaps xmm14, [rsp+0xD0]
0000785dab1d794e  vmovaps xmm15, [rsp+0xE0]
0000785dab1d7957  add rsp, 0xF0
0000785dab1d795e  pop r11
0000785dab1d7960  pop r10
0000785dab1d7962  pop r9
0000785dab1d7964  pop r8
0000785dab1d7966  pop rsi
0000785dab1d7967  pop rdi
0000785dab1d7968  pop rdx
0000785dab1d7969  pop rcx
0000785dab1d796a  pop rax
0000785dab1d796b  add rsp, 0x08
0000785dab1d796f  jmp 0x0000785DAB1D5CF9
0000785dab1d7974  call 0x0000785DAB0E5820
0000785dab1d7979  jmp 0x0000785DAB1D5D06
0000785dab1d797e  sub rsp, 0x08
0000785dab1d7982  push rax
0000785dab1d7983  push rcx
0000785dab1d7984  push rdx
0000785dab1d7985  push rdi
0000785dab1d7986  push rsi
0000785dab1d7987  push r8
0000785dab1d7989  push r9
0000785dab1d798b  push r10
0000785dab1d798d  push r11
0000785dab1d798f  sub rsp, 0xF0
0000785dab1d7996  vmovaps [rsp], xmm0
0000785dab1d799b  vmovaps [rsp+0x10], xmm1
0000785dab1d79a1  vmovaps [rsp+0x20], xmm2
0000785dab1d79a7  vmovaps [rsp+0x30], xmm4
0000785dab1d79ad  vmovaps [rsp+0x40], xmm5
0000785dab1d79b3  vmovaps [rsp+0x50], xmm6
0000785dab1d79b9  vmovaps [rsp+0x60], xmm7
0000785dab1d79bf  vmovaps [rsp+0x70], xmm8
0000785dab1d79c5  vmovaps [rsp+0x80], xmm9
0000785dab1d79ce  vmovaps [rsp+0x90], xmm10
0000785dab1d79d7  vmovaps [rsp+0xA0], xmm11
0000785dab1d79e0  vmovaps [rsp+0xB0], xmm12
0000785dab1d79e9  vmovaps [rsp+0xC0], xmm13
0000785dab1d79f2  vmovaps [rsp+0xD0], xmm14
0000785dab1d79fb  vmovaps [rsp+0xE0], xmm15
0000785dab1d7a04  sub rsp, 0x30
0000785dab1d7a08  movaps [rsp], xmm3
0000785dab1d7a0c  movaps [rsp+0x10], xmm1
0000785dab1d7a11  movaps [rsp+0x20], xmm9
0000785dab1d7a17  lea rdi, [rsp]
0000785dab1d7a1b  mov esi, 0x00
0000785dab1d7a20  mov rax, 0x61B13BBD6530
0000785dab1d7a2a  call rax
0000785dab1d7a2c  movaps xmm3, [rsp]
0000785dab1d7a30  add rsp, 0x30
0000785dab1d7a34  vmovaps xmm0, [rsp]
0000785dab1d7a39  vmovaps xmm1, [rsp+0x10]
0000785dab1d7a3f  vmovaps xmm2, [rsp+0x20]
0000785dab1d7a45  vmovaps xmm4, [rsp+0x30]
0000785dab1d7a4b  vmovaps xmm5, [rsp+0x40]
0000785dab1d7a51  vmovaps xmm6, [rsp+0x50]
0000785dab1d7a57  vmovaps xmm7, [rsp+0x60]
0000785dab1d7a5d  vmovaps xmm8, [rsp+0x70]
0000785dab1d7a63  vmovaps xmm9, [rsp+0x80]
0000785dab1d7a6c  vmovaps xmm10, [rsp+0x90]
0000785dab1d7a75  vmovaps xmm11, [rsp+0xA0]
0000785dab1d7a7e  vmovaps xmm12, [rsp+0xB0]
0000785dab1d7a87  vmovaps xmm13, [rsp+0xC0]
0000785dab1d7a90  vmovaps xmm14, [rsp+0xD0]
0000785dab1d7a99  vmovaps xmm15, [rsp+0xE0]
0000785dab1d7aa2  add rsp, 0xF0
0000785dab1d7aa9  pop r11
0000785dab1d7aab  pop r10
0000785dab1d7aad  pop r9
0000785dab1d7aaf  pop r8
0000785dab1d7ab1  pop rsi
0000785dab1d7ab2  pop rdi
0000785dab1d7ab3  pop rdx
0000785dab1d7ab4  pop rcx
0000785dab1d7ab5  pop rax
0000785dab1d7ab6  add rsp, 0x08
0000785dab1d7aba  jmp 0x0000785DAB1D5D43
0000785dab1d7abf  sub rsp, 0x08
0000785dab1d7ac3  push rax
0000785dab1d7ac4  push rcx
0000785dab1d7ac5  push rdx
0000785dab1d7ac6  push rdi
0000785dab1d7ac7  push rsi
0000785dab1d7ac8  push r8
0000785dab1d7aca  push r9
0000785dab1d7acc  push r10
0000785dab1d7ace  push r11
0000785dab1d7ad0  sub rsp, 0xF0
0000785dab1d7ad7  vmovaps [rsp], xmm0
0000785dab1d7adc  vmovaps [rsp+0x10], xmm2
0000785dab1d7ae2  vmovaps [rsp+0x20], xmm3
0000785dab1d7ae8  vmovaps [rsp+0x30], xmm4
0000785dab1d7aee  vmovaps [rsp+0x40], xmm5
0000785dab1d7af4  vmovaps [rsp+0x50], xmm6
0000785dab1d7afa  vmovaps [rsp+0x60], xmm7
0000785dab1d7b00  vmovaps [rsp+0x70], xmm8
0000785dab1d7b06  vmovaps [rsp+0x80], xmm9
0000785dab1d7b0f  vmovaps [rsp+0x90], xmm10
0000785dab1d7b18  vmovaps [rsp+0xA0], xmm11
0000785dab1d7b21  vmovaps [rsp+0xB0], xmm12
0000785dab1d7b2a  vmovaps [rsp+0xC0], xmm13
0000785dab1d7b33  vmovaps [rsp+0xD0], xmm14
0000785dab1d7b3c  vmovaps [rsp+0xE0], xmm15
0000785dab1d7b45  sub rsp, 0x30
0000785dab1d7b49  movaps [rsp], xmm1
0000785dab1d7b4d  movaps [rsp+0x10], xmm15
0000785dab1d7b53  movaps [rsp+0x20], xmm9
0000785dab1d7b59  lea rdi, [rsp]
0000785dab1d7b5d  mov esi, 0x00
0000785dab1d7b62  mov rax, 0x61B13BBD6530
0000785dab1d7b6c  call rax
0000785dab1d7b6e  movaps xmm1, [rsp]
0000785dab1d7b72  add rsp, 0x30
0000785dab1d7b76  vmovaps xmm0, [rsp]
0000785dab1d7b7b  vmovaps xmm2, [rsp+0x10]
0000785dab1d7b81  vmovaps xmm3, [rsp+0x20]
0000785dab1d7b87  vmovaps xmm4, [rsp+0x30]
0000785dab1d7b8d  vmovaps xmm5, [rsp+0x40]
0000785dab1d7b93  vmovaps xmm6, [rsp+0x50]
0000785dab1d7b99  vmovaps xmm7, [rsp+0x60]
0000785dab1d7b9f  vmovaps xmm8, [rsp+0x70]
0000785dab1d7ba5  vmovaps xmm9, [rsp+0x80]
0000785dab1d7bae  vmovaps xmm10, [rsp+0x90]
0000785dab1d7bb7  vmovaps xmm11, [rsp+0xA0]
0000785dab1d7bc0  vmovaps xmm12, [rsp+0xB0]
0000785dab1d7bc9  vmovaps xmm13, [rsp+0xC0]
0000785dab1d7bd2  vmovaps xmm14, [rsp+0xD0]
0000785dab1d7bdb  vmovaps xmm15, [rsp+0xE0]
0000785dab1d7be4  add rsp, 0xF0
0000785dab1d7beb  pop r11
0000785dab1d7bed  pop r10
0000785dab1d7bef  pop r9
0000785dab1d7bf1  pop r8
0000785dab1d7bf3  pop rsi
0000785dab1d7bf4  pop rdi
0000785dab1d7bf5  pop rdx
0000785dab1d7bf6  pop rcx
0000785dab1d7bf7  pop rax
0000785dab1d7bf8  add rsp, 0x08
0000785dab1d7bfc  jmp 0x0000785DAB1D5DCB
0000785dab1d7c01  call 0x0000785DAB0E5820
0000785dab1d7c06  jmp 0x0000785DAB1D5DD8
0000785dab1d7c0b  sub rsp, 0x08
0000785dab1d7c0f  push rax
0000785dab1d7c10  push rcx
0000785dab1d7c11  push rdx
0000785dab1d7c12  push rdi
0000785dab1d7c13  push rsi
0000785dab1d7c14  push r8
0000785dab1d7c16  push r9
0000785dab1d7c18  push r10
0000785dab1d7c1a  push r11
0000785dab1d7c1c  sub rsp, 0xF0
0000785dab1d7c23  vmovaps [rsp], xmm0
0000785dab1d7c28  vmovaps [rsp+0x10], xmm2
0000785dab1d7c2e  vmovaps [rsp+0x20], xmm3
0000785dab1d7c34  vmovaps [rsp+0x30], xmm4
0000785dab1d7c3a  vmovaps [rsp+0x40], xmm5
0000785dab1d7c40  vmovaps [rsp+0x50], xmm6
0000785dab1d7c46  vmovaps [rsp+0x60], xmm7
0000785dab1d7c4c  vmovaps [rsp+0x70], xmm8
0000785dab1d7c52  vmovaps [rsp+0x80], xmm9
0000785dab1d7c5b  vmovaps [rsp+0x90], xmm10
0000785dab1d7c64  vmovaps [rsp+0xA0], xmm11
0000785dab1d7c6d  vmovaps [rsp+0xB0], xmm12
0000785dab1d7c76  vmovaps [rsp+0xC0], xmm13
0000785dab1d7c7f  vmovaps [rsp+0xD0], xmm14
0000785dab1d7c88  vmovaps [rsp+0xE0], xmm15
0000785dab1d7c91  sub rsp, 0x30
0000785dab1d7c95  movaps [rsp], xmm1
0000785dab1d7c99  movaps [rsp+0x10], xmm5
0000785dab1d7c9e  movaps [rsp+0x20], xmm7
0000785dab1d7ca3  lea rdi, [rsp]
0000785dab1d7ca7  mov esi, 0x00
0000785dab1d7cac  mov rax, 0x61B13BBD6530
0000785dab1d7cb6  call rax
0000785dab1d7cb8  movaps xmm1, [rsp]
0000785dab1d7cbc  add rsp, 0x30
0000785dab1d7cc0  vmovaps xmm0, [rsp]
0000785dab1d7cc5  vmovaps xmm2, [rsp+0x10]
0000785dab1d7ccb  vmovaps xmm3, [rsp+0x20]
0000785dab1d7cd1  vmovaps xmm4, [rsp+0x30]
0000785dab1d7cd7  vmovaps xmm5, [rsp+0x40]
0000785dab1d7cdd  vmovaps xmm6, [rsp+0x50]
0000785dab1d7ce3  vmovaps xmm7, [rsp+0x60]
0000785dab1d7ce9  vmovaps xmm8, [rsp+0x70]
0000785dab1d7cef  vmovaps xmm9, [rsp+0x80]
0000785dab1d7cf8  vmovaps xmm10, [rsp+0x90]
0000785dab1d7d01  vmovaps xmm11, [rsp+0xA0]
0000785dab1d7d0a  vmovaps xmm12, [rsp+0xB0]
0000785dab1d7d13  vmovaps xmm13, [rsp+0xC0]
0000785dab1d7d1c  vmovaps xmm14, [rsp+0xD0]
0000785dab1d7d25  vmovaps xmm15, [rsp+0xE0]
0000785dab1d7d2e  add rsp, 0xF0
0000785dab1d7d35  pop r11
0000785dab1d7d37  pop r10
0000785dab1d7d39  pop r9
0000785dab1d7d3b  pop r8
0000785dab1d7d3d  pop rsi
0000785dab1d7d3e  pop rdi
0000785dab1d7d3f  pop rdx
0000785dab1d7d40  pop rcx
0000785dab1d7d41  pop rax
0000785dab1d7d42  add rsp, 0x08
0000785dab1d7d46  jmp 0x0000785DAB1D5E7D
0000785dab1d7d4b  sub rsp, 0x08
0000785dab1d7d4f  push rax
0000785dab1d7d50  push rcx
0000785dab1d7d51  push rdx
0000785dab1d7d52  push rdi
0000785dab1d7d53  push rsi
0000785dab1d7d54  push r8
0000785dab1d7d56  push r9
0000785dab1d7d58  push r10
0000785dab1d7d5a  push r11
0000785dab1d7d5c  sub rsp, 0xF0
0000785dab1d7d63  vmovaps [rsp], xmm0
0000785dab1d7d68  vmovaps [rsp+0x10], xmm1
0000785dab1d7d6e  vmovaps [rsp+0x20], xmm2
0000785dab1d7d74  vmovaps [rsp+0x30], xmm3
0000785dab1d7d7a  vmovaps [rsp+0x40], xmm4
0000785dab1d7d80  vmovaps [rsp+0x50], xmm5
0000785dab1d7d86  vmovaps [rsp+0x60], xmm6
0000785dab1d7d8c  vmovaps [rsp+0x70], xmm8
0000785dab1d7d92  vmovaps [rsp+0x80], xmm9
0000785dab1d7d9b  vmovaps [rsp+0x90], xmm10
0000785dab1d7da4  vmovaps [rsp+0xA0], xmm11
0000785dab1d7dad  vmovaps [rsp+0xB0], xmm12
0000785dab1d7db6  vmovaps [rsp+0xC0], xmm13
0000785dab1d7dbf  vmovaps [rsp+0xD0], xmm14
0000785dab1d7dc8  vmovaps [rsp+0xE0], xmm15
0000785dab1d7dd1  sub rsp, 0x30
0000785dab1d7dd5  movaps [rsp], xmm7
0000785dab1d7dd9  movaps [rsp+0x10], xmm5
0000785dab1d7dde  movaps [rsp+0x20], xmm15
0000785dab1d7de4  lea rdi, [rsp]
0000785dab1d7de8  mov esi, 0x00
0000785dab1d7ded  mov rax, 0x61B13BBD6530
0000785dab1d7df7  call rax
0000785dab1d7df9  movaps xmm7, [rsp]
0000785dab1d7dfd  add rsp, 0x30
0000785dab1d7e01  vmovaps xmm0, [rsp]
0000785dab1d7e06  vmovaps xmm1, [rsp+0x10]
0000785dab1d7e0c  vmovaps xmm2, [rsp+0x20]
0000785dab1d7e12  vmovaps xmm3, [rsp+0x30]
0000785dab1d7e18  vmovaps xmm4, [rsp+0x40]
0000785dab1d7e1e  vmovaps xmm5, [rsp+0x50]
0000785dab1d7e24  vmovaps xmm6, [rsp+0x60]
0000785dab1d7e2a  vmovaps xmm8, [rsp+0x70]
0000785dab1d7e30  vmovaps xmm9, [rsp+0x80]
0000785dab1d7e39  vmovaps xmm10, [rsp+0x90]
0000785dab1d7e42  vmovaps xmm11, [rsp+0xA0]
0000785dab1d7e4b  vmovaps xmm12, [rsp+0xB0]
0000785dab1d7e54  vmovaps xmm13, [rsp+0xC0]
0000785dab1d7e5d  vmovaps xmm14, [rsp+0xD0]
0000785dab1d7e66  vmovaps xmm15, [rsp+0xE0]
0000785dab1d7e6f  add rsp, 0xF0
0000785dab1d7e76  pop r11
0000785dab1d7e78  pop r10
0000785dab1d7e7a  pop r9
0000785dab1d7e7c  pop r8
0000785dab1d7e7e  pop rsi
0000785dab1d7e7f  pop rdi
0000785dab1d7e80  pop rdx
0000785dab1d7e81  pop rcx
0000785dab1d7e82  pop rax
0000785dab1d7e83  add rsp, 0x08
0000785dab1d7e87  jmp 0x0000785DAB1D5EB3
0000785dab1d7e8c  call 0x0000785DAB0D64F0
0000785dab1d7e91  jmp 0x0000785DAB1D5EC0
0000785dab1d7e96  sub rsp, 0x08
0000785dab1d7e9a  push rax
0000785dab1d7e9b  push rcx
0000785dab1d7e9c  push rdx
0000785dab1d7e9d  push rdi
0000785dab1d7e9e  push rsi
0000785dab1d7e9f  push r8
0000785dab1d7ea1  push r9
0000785dab1d7ea3  push r10
0000785dab1d7ea5  push r11
0000785dab1d7ea7  sub rsp, 0xF0
0000785dab1d7eae  vmovaps [rsp], xmm0
0000785dab1d7eb3  vmovaps [rsp+0x10], xmm1
0000785dab1d7eb9  vmovaps [rsp+0x20], xmm2
0000785dab1d7ebf  vmovaps [rsp+0x30], xmm3
0000785dab1d7ec5  vmovaps [rsp+0x40], xmm4
0000785dab1d7ecb  vmovaps [rsp+0x50], xmm5
0000785dab1d7ed1  vmovaps [rsp+0x60], xmm6
0000785dab1d7ed7  vmovaps [rsp+0x70], xmm7
0000785dab1d7edd  vmovaps [rsp+0x80], xmm8
0000785dab1d7ee6  vmovaps [rsp+0x90], xmm9
0000785dab1d7eef  vmovaps [rsp+0xA0], xmm10
0000785dab1d7ef8  vmovaps [rsp+0xB0], xmm11
0000785dab1d7f01  vmovaps [rsp+0xC0], xmm12
0000785dab1d7f0a  vmovaps [rsp+0xD0], xmm13
0000785dab1d7f13  vmovaps [rsp+0xE0], xmm14
0000785dab1d7f1c  sub rsp, 0x30
0000785dab1d7f20  movaps [rsp], xmm15
0000785dab1d7f25  movaps [rsp+0x10], xmm5
0000785dab1d7f2a  movaps [rsp+0x20], xmm3
0000785dab1d7f2f  lea rdi, [rsp]
0000785dab1d7f33  mov esi, 0x00
0000785dab1d7f38  mov rax, 0x61B13BBD6530
0000785dab1d7f42  call rax
0000785dab1d7f44  movaps xmm15, [rsp]
0000785dab1d7f49  add rsp, 0x30
0000785dab1d7f4d  vmovaps xmm0, [rsp]
0000785dab1d7f52  vmovaps xmm1, [rsp+0x10]
0000785dab1d7f58  vmovaps xmm2, [rsp+0x20]
0000785dab1d7f5e  vmovaps xmm3, [rsp+0x30]
0000785dab1d7f64  vmovaps xmm4, [rsp+0x40]
0000785dab1d7f6a  vmovaps xmm5, [rsp+0x50]
0000785dab1d7f70  vmovaps xmm6, [rsp+0x60]
0000785dab1d7f76  vmovaps xmm7, [rsp+0x70]
0000785dab1d7f7c  vmovaps xmm8, [rsp+0x80]
0000785dab1d7f85  vmovaps xmm9, [rsp+0x90]
0000785dab1d7f8e  vmovaps xmm10, [rsp+0xA0]
0000785dab1d7f97  vmovaps xmm11, [rsp+0xB0]
0000785dab1d7fa0  vmovaps xmm12, [rsp+0xC0]
0000785dab1d7fa9  vmovaps xmm13, [rsp+0xD0]
0000785dab1d7fb2  vmovaps xmm14, [rsp+0xE0]
0000785dab1d7fbb  add rsp, 0xF0
0000785dab1d7fc2  pop r11
0000785dab1d7fc4  pop r10
0000785dab1d7fc6  pop r9
0000785dab1d7fc8  pop r8
0000785dab1d7fca  pop rsi
0000785dab1d7fcb  pop rdi
0000785dab1d7fcc  pop rdx
0000785dab1d7fcd  pop rcx
0000785dab1d7fce  pop rax
0000785dab1d7fcf  add rsp, 0x08
0000785dab1d7fd3  jmp 0x0000785DAB1D5EE6
0000785dab1d7fd8  sub rsp, 0x08
0000785dab1d7fdc  push rax
0000785dab1d7fdd  push rcx
0000785dab1d7fde  push rdx
0000785dab1d7fdf  push rdi
0000785dab1d7fe0  push rsi
0000785dab1d7fe1  push r8
0000785dab1d7fe3  push r9
0000785dab1d7fe5  push r10
0000785dab1d7fe7  push r11
0000785dab1d7fe9  sub rsp, 0xF0
0000785dab1d7ff0  vmovaps [rsp], xmm0
0000785dab1d7ff5  vmovaps [rsp+0x10], xmm2
0000785dab1d7ffb  vmovaps [rsp+0x20], xmm3
0000785dab1d8001  vmovaps [rsp+0x30], xmm4
0000785dab1d8007  vmovaps [rsp+0x40], xmm5
0000785dab1d800d  vmovaps [rsp+0x50], xmm6
0000785dab1d8013  vmovaps [rsp+0x60], xmm7
0000785dab1d8019  vmovaps [rsp+0x70], xmm8
0000785dab1d801f  vmovaps [rsp+0x80], xmm9
0000785dab1d8028  vmovaps [rsp+0x90], xmm10
0000785dab1d8031  vmovaps [rsp+0xA0], xmm11
0000785dab1d803a  vmovaps [rsp+0xB0], xmm12
0000785dab1d8043  vmovaps [rsp+0xC0], xmm13
0000785dab1d804c  vmovaps [rsp+0xD0], xmm14
0000785dab1d8055  vmovaps [rsp+0xE0], xmm15
0000785dab1d805e  sub rsp, 0x30
0000785dab1d8062  movaps [rsp], xmm1
0000785dab1d8066  movaps [rsp+0x10], xmm5
0000785dab1d806b  movaps [rsp+0x20], xmm4
0000785dab1d8070  lea rdi, [rsp]
0000785dab1d8074  mov esi, 0x00
0000785dab1d8079  mov rax, 0x61B13BBD6530
0000785dab1d8083  call rax
0000785dab1d8085  movaps xmm1, [rsp]
0000785dab1d8089  add rsp, 0x30
0000785dab1d808d  vmovaps xmm0, [rsp]
0000785dab1d8092  vmovaps xmm2, [rsp+0x10]
0000785dab1d8098  vmovaps xmm3, [rsp+0x20]
0000785dab1d809e  vmovaps xmm4, [rsp+0x30]
0000785dab1d80a4  vmovaps xmm5, [rsp+0x40]
0000785dab1d80aa  vmovaps xmm6, [rsp+0x50]
0000785dab1d80b0  vmovaps xmm7, [rsp+0x60]
0000785dab1d80b6  vmovaps xmm8, [rsp+0x70]
0000785dab1d80bc  vmovaps xmm9, [rsp+0x80]
0000785dab1d80c5  vmovaps xmm10, [rsp+0x90]
0000785dab1d80ce  vmovaps xmm11, [rsp+0xA0]
0000785dab1d80d7  vmovaps xmm12, [rsp+0xB0]
0000785dab1d80e0  vmovaps xmm13, [rsp+0xC0]
0000785dab1d80e9  vmovaps xmm14, [rsp+0xD0]
0000785dab1d80f2  vmovaps xmm15, [rsp+0xE0]
0000785dab1d80fb  add rsp, 0xF0
0000785dab1d8102  pop r11
0000785dab1d8104  pop r10
0000785dab1d8106  pop r9
0000785dab1d8108  pop r8
0000785dab1d810a  pop rsi
0000785dab1d810b  pop rdi
0000785dab1d810c  pop rdx
0000785dab1d810d  pop rcx
0000785dab1d810e  pop rax
0000785dab1d810f  add rsp, 0x08
0000785dab1d8113  jmp 0x0000785DAB1D5F06
0000785dab1d8118  sub rsp, 0x08
0000785dab1d811c  push rax
0000785dab1d811d  push rcx
0000785dab1d811e  push rdx
0000785dab1d811f  push rdi
0000785dab1d8120  push rsi
0000785dab1d8121  push r8
0000785dab1d8123  push r9
0000785dab1d8125  push r10
0000785dab1d8127  push r11
0000785dab1d8129  sub rsp, 0xF0
0000785dab1d8130  vmovaps [rsp], xmm0
0000785dab1d8135  vmovaps [rsp+0x10], xmm1
0000785dab1d813b  vmovaps [rsp+0x20], xmm2
0000785dab1d8141  vmovaps [rsp+0x30], xmm3
0000785dab1d8147  vmovaps [rsp+0x40], xmm5
0000785dab1d814d  vmovaps [rsp+0x50], xmm6
0000785dab1d8153  vmovaps [rsp+0x60], xmm7
0000785dab1d8159  vmovaps [rsp+0x70], xmm8
0000785dab1d815f  vmovaps [rsp+0x80], xmm9
0000785dab1d8168  vmovaps [rsp+0x90], xmm10
0000785dab1d8171  vmovaps [rsp+0xA0], xmm11
0000785dab1d817a  vmovaps [rsp+0xB0], xmm12
0000785dab1d8183  vmovaps [rsp+0xC0], xmm13
0000785dab1d818c  vmovaps [rsp+0xD0], xmm14
0000785dab1d8195  vmovaps [rsp+0xE0], xmm15
0000785dab1d819e  sub rsp, 0x30
0000785dab1d81a2  movaps [rsp], xmm4
0000785dab1d81a6  movaps [rsp+0x10], xmm3
0000785dab1d81ab  movaps [rsp+0x20], xmm5
0000785dab1d81b0  lea rdi, [rsp]
0000785dab1d81b4  mov esi, 0x00
0000785dab1d81b9  mov rax, 0x61B13BBD6530
0000785dab1d81c3  call rax
0000785dab1d81c5  movaps xmm4, [rsp]
0000785dab1d81c9  add rsp, 0x30
0000785dab1d81cd  vmovaps xmm0, [rsp]
0000785dab1d81d2  vmovaps xmm1, [rsp+0x10]
0000785dab1d81d8  vmovaps xmm2, [rsp+0x20]
0000785dab1d81de  vmovaps xmm3, [rsp+0x30]
0000785dab1d81e4  vmovaps xmm5, [rsp+0x40]
0000785dab1d81ea  vmovaps xmm6, [rsp+0x50]
0000785dab1d81f0  vmovaps xmm7, [rsp+0x60]
0000785dab1d81f6  vmovaps xmm8, [rsp+0x70]
0000785dab1d81fc  vmovaps xmm9, [rsp+0x80]
0000785dab1d8205  vmovaps xmm10, [rsp+0x90]
0000785dab1d820e  vmovaps xmm11, [rsp+0xA0]
0000785dab1d8217  vmovaps xmm12, [rsp+0xB0]
0000785dab1d8220  vmovaps xmm13, [rsp+0xC0]
0000785dab1d8229  vmovaps xmm14, [rsp+0xD0]
0000785dab1d8232  vmovaps xmm15, [rsp+0xE0]
0000785dab1d823b  add rsp, 0xF0
0000785dab1d8242  pop r11
0000785dab1d8244  pop r10
0000785dab1d8246  pop r9
0000785dab1d8248  pop r8
0000785dab1d824a  pop rsi
0000785dab1d824b  pop rdi
0000785dab1d824c  pop rdx
0000785dab1d824d  pop rcx
0000785dab1d824e  pop rax
0000785dab1d824f  add rsp, 0x08
0000785dab1d8253  jmp 0x0000785DAB1D5F54
0000785dab1d8258  call 0x0000785DAB0D64F0
0000785dab1d825d  jmp 0x0000785DAB1D5F61
0000785dab1d8262  sub rsp, 0x08
0000785dab1d8266  push rax
0000785dab1d8267  push rcx
0000785dab1d8268  push rdx
0000785dab1d8269  push rdi
0000785dab1d826a  push rsi
0000785dab1d826b  push r8
0000785dab1d826d  push r9
0000785dab1d826f  push r10
0000785dab1d8271  push r11
0000785dab1d8273  sub rsp, 0xF0
0000785dab1d827a  vmovaps [rsp], xmm0
0000785dab1d827f  vmovaps [rsp+0x10], xmm1
0000785dab1d8285  vmovaps [rsp+0x20], xmm2
0000785dab1d828b  vmovaps [rsp+0x30], xmm3
0000785dab1d8291  vmovaps [rsp+0x40], xmm4
0000785dab1d8297  vmovaps [rsp+0x50], xmm6
0000785dab1d829d  vmovaps [rsp+0x60], xmm7
0000785dab1d82a3  vmovaps [rsp+0x70], xmm8
0000785dab1d82a9  vmovaps [rsp+0x80], xmm9
0000785dab1d82b2  vmovaps [rsp+0x90], xmm10
0000785dab1d82bb  vmovaps [rsp+0xA0], xmm11
0000785dab1d82c4  vmovaps [rsp+0xB0], xmm12
0000785dab1d82cd  vmovaps [rsp+0xC0], xmm13
0000785dab1d82d6  vmovaps [rsp+0xD0], xmm14
0000785dab1d82df  vmovaps [rsp+0xE0], xmm15
0000785dab1d82e8  sub rsp, 0x30
0000785dab1d82ec  movaps [rsp], xmm5
0000785dab1d82f0  movaps [rsp+0x10], xmm6
0000785dab1d82f5  movaps [rsp+0x20], xmm3
0000785dab1d82fa  lea rdi, [rsp]
0000785dab1d82fe  mov esi, 0x00
0000785dab1d8303  mov rax, 0x61B13BBD6530
0000785dab1d830d  call rax
0000785dab1d830f  movaps xmm5, [rsp]
0000785dab1d8313  add rsp, 0x30
0000785dab1d8317  vmovaps xmm0, [rsp]
0000785dab1d831c  vmovaps xmm1, [rsp+0x10]
0000785dab1d8322  vmovaps xmm2, [rsp+0x20]
0000785dab1d8328  vmovaps xmm3, [rsp+0x30]
0000785dab1d832e  vmovaps xmm4, [rsp+0x40]
0000785dab1d8334  vmovaps xmm6, [rsp+0x50]
0000785dab1d833a  vmovaps xmm7, [rsp+0x60]
0000785dab1d8340  vmovaps xmm8, [rsp+0x70]
0000785dab1d8346  vmovaps xmm9, [rsp+0x80]
0000785dab1d834f  vmovaps xmm10, [rsp+0x90]
0000785dab1d8358  vmovaps xmm11, [rsp+0xA0]
0000785dab1d8361  vmovaps xmm12, [rsp+0xB0]
0000785dab1d836a  vmovaps xmm13, [rsp+0xC0]
0000785dab1d8373  vmovaps xmm14, [rsp+0xD0]
0000785dab1d837c  vmovaps xmm15, [rsp+0xE0]
0000785dab1d8385  add rsp, 0xF0
0000785dab1d838c  pop r11
0000785dab1d838e  pop r10
0000785dab1d8390  pop r9
0000785dab1d8392  pop r8
0000785dab1d8394  pop rsi
0000785dab1d8395  pop rdi
0000785dab1d8396  pop rdx
0000785dab1d8397  pop rcx
0000785dab1d8398  pop rax
0000785dab1d8399  add rsp, 0x08
0000785dab1d839d  jmp 0x0000785DAB1D5F87
0000785dab1d83a2  sub rsp, 0x08
0000785dab1d83a6  push rax
0000785dab1d83a7  push rcx
0000785dab1d83a8  push rdx
0000785dab1d83a9  push rdi
0000785dab1d83aa  push rsi
0000785dab1d83ab  push r8
0000785dab1d83ad  push r9
0000785dab1d83af  push r10
0000785dab1d83b1  push r11
0000785dab1d83b3  sub rsp, 0xF0
0000785dab1d83ba  vmovaps [rsp], xmm0
0000785dab1d83bf  vmovaps [rsp+0x10], xmm1
0000785dab1d83c5  vmovaps [rsp+0x20], xmm2
0000785dab1d83cb  vmovaps [rsp+0x30], xmm3
0000785dab1d83d1  vmovaps [rsp+0x40], xmm4
0000785dab1d83d7  vmovaps [rsp+0x50], xmm5
0000785dab1d83dd  vmovaps [rsp+0x60], xmm7
0000785dab1d83e3  vmovaps [rsp+0x70], xmm8
0000785dab1d83e9  vmovaps [rsp+0x80], xmm9
0000785dab1d83f2  vmovaps [rsp+0x90], xmm10
0000785dab1d83fb  vmovaps [rsp+0xA0], xmm11
0000785dab1d8404  vmovaps [rsp+0xB0], xmm12
0000785dab1d840d  vmovaps [rsp+0xC0], xmm13
0000785dab1d8416  vmovaps [rsp+0xD0], xmm14
0000785dab1d841f  vmovaps [rsp+0xE0], xmm15
0000785dab1d8428  sub rsp, 0x30
0000785dab1d842c  movaps [rsp], xmm6
0000785dab1d8430  movaps [rsp+0x10], xmm9
0000785dab1d8436  movaps [rsp+0x20], xmm1
0000785dab1d843b  lea rdi, [rsp]
0000785dab1d843f  mov esi, 0x00
0000785dab1d8444  mov rax, 0x61B13BBD6530
0000785dab1d844e  call rax
0000785dab1d8450  movaps xmm6, [rsp]
0000785dab1d8454  add rsp, 0x30
0000785dab1d8458  vmovaps xmm0, [rsp]
0000785dab1d845d  vmovaps xmm1, [rsp+0x10]
0000785dab1d8463  vmovaps xmm2, [rsp+0x20]
0000785dab1d8469  vmovaps xmm3, [rsp+0x30]
0000785dab1d846f  vmovaps xmm4, [rsp+0x40]
0000785dab1d8475  vmovaps xmm5, [rsp+0x50]
0000785dab1d847b  vmovaps xmm7, [rsp+0x60]
0000785dab1d8481  vmovaps xmm8, [rsp+0x70]
0000785dab1d8487  vmovaps xmm9, [rsp+0x80]
0000785dab1d8490  vmovaps xmm10, [rsp+0x90]
0000785dab1d8499  vmovaps xmm11, [rsp+0xA0]
0000785dab1d84a2  vmovaps xmm12, [rsp+0xB0]
0000785dab1d84ab  vmovaps xmm13, [rsp+0xC0]
0000785dab1d84b4  vmovaps xmm14, [rsp+0xD0]
0000785dab1d84bd  vmovaps xmm15, [rsp+0xE0]
0000785dab1d84c6  add rsp, 0xF0
0000785dab1d84cd  pop r11
0000785dab1d84cf  pop r10
0000785dab1d84d1  pop r9
0000785dab1d84d3  pop r8
0000785dab1d84d5  pop rsi
0000785dab1d84d6  pop rdi
0000785dab1d84d7  pop rdx
0000785dab1d84d8  pop rcx
0000785dab1d84d9  pop rax
0000785dab1d84da  add rsp, 0x08
0000785dab1d84de  jmp 0x0000785DAB1D5FAB
0000785dab1d84e3  sub rsp, 0x08
0000785dab1d84e7  push rax
0000785dab1d84e8  push rcx
0000785dab1d84e9  push rdx
0000785dab1d84ea  push rdi
0000785dab1d84eb  push rsi
0000785dab1d84ec  push r8
0000785dab1d84ee  push r9
0000785dab1d84f0  push r10
0000785dab1d84f2  push r11
0000785dab1d84f4  sub rsp, 0xF0
0000785dab1d84fb  vmovaps [rsp], xmm0
0000785dab1d8500  vmovaps [rsp+0x10], xmm1
0000785dab1d8506  vmovaps [rsp+0x20], xmm2
0000785dab1d850c  vmovaps [rsp+0x30], xmm3
0000785dab1d8512  vmovaps [rsp+0x40], xmm4
0000785dab1d8518  vmovaps [rsp+0x50], xmm5
0000785dab1d851e  vmovaps [rsp+0x60], xmm6
0000785dab1d8524  vmovaps [rsp+0x70], xmm7
0000785dab1d852a  vmovaps [rsp+0x80], xmm8
0000785dab1d8533  vmovaps [rsp+0x90], xmm10
0000785dab1d853c  vmovaps [rsp+0xA0], xmm11
0000785dab1d8545  vmovaps [rsp+0xB0], xmm12
0000785dab1d854e  vmovaps [rsp+0xC0], xmm13
0000785dab1d8557  vmovaps [rsp+0xD0], xmm14
0000785dab1d8560  vmovaps [rsp+0xE0], xmm15
0000785dab1d8569  sub rsp, 0x30
0000785dab1d856d  movaps [rsp], xmm9
0000785dab1d8572  movaps [rsp+0x10], xmm3
0000785dab1d8577  movaps [rsp+0x20], xmm1
0000785dab1d857c  lea rdi, [rsp]
0000785dab1d8580  mov esi, 0x00
0000785dab1d8585  mov rax, 0x61B13BBD6530
0000785dab1d858f  call rax
0000785dab1d8591  movaps xmm9, [rsp]
0000785dab1d8596  add rsp, 0x30
0000785dab1d859a  vmovaps xmm0, [rsp]
0000785dab1d859f  vmovaps xmm1, [rsp+0x10]
0000785dab1d85a5  vmovaps xmm2, [rsp+0x20]
0000785dab1d85ab  vmovaps xmm3, [rsp+0x30]
0000785dab1d85b1  vmovaps xmm4, [rsp+0x40]
0000785dab1d85b7  vmovaps xmm5, [rsp+0x50]
0000785dab1d85bd  vmovaps xmm6, [rsp+0x60]
0000785dab1d85c3  vmovaps xmm7, [rsp+0x70]
0000785dab1d85c9  vmovaps xmm8, [rsp+0x80]
0000785dab1d85d2  vmovaps xmm10, [rsp+0x90]
0000785dab1d85db  vmovaps xmm11, [rsp+0xA0]
0000785dab1d85e4  vmovaps xmm12, [rsp+0xB0]
0000785dab1d85ed  vmovaps xmm13, [rsp+0xC0]
0000785dab1d85f6  vmovaps xmm14, [rsp+0xD0]
0000785dab1d85ff  vmovaps xmm15, [rsp+0xE0]
0000785dab1d8608  add rsp, 0xF0
0000785dab1d860f  pop r11
0000785dab1d8611  pop r10
0000785dab1d8613  pop r9
0000785dab1d8615  pop r8
0000785dab1d8617  pop rsi
0000785dab1d8618  pop rdi
0000785dab1d8619  pop rdx
0000785dab1d861a  pop rcx
0000785dab1d861b  pop rax
0000785dab1d861c  add rsp, 0x08
0000785dab1d8620  jmp 0x0000785DAB1D5FF7
0000785dab1d8625  call 0x0000785DAB0D64F0
0000785dab1d862a  jmp 0x0000785DAB1D6004
0000785dab1d862f  sub rsp, 0x08
0000785dab1d8633  push rax
0000785dab1d8634  push rcx
0000785dab1d8635  push rdx
0000785dab1d8636  push rdi
0000785dab1d8637  push rsi
0000785dab1d8638  push r8
0000785dab1d863a  push r9
0000785dab1d863c  push r10
0000785dab1d863e  push r11
0000785dab1d8640  sub rsp, 0xF0
0000785dab1d8647  vmovaps [rsp], xmm0
0000785dab1d864c  vmovaps [rsp+0x10], xmm1
0000785dab1d8652  vmovaps [rsp+0x20], xmm2
0000785dab1d8658  vmovaps [rsp+0x30], xmm3
0000785dab1d865e  vmovaps [rsp+0x40], xmm4
0000785dab1d8664  vmovaps [rsp+0x50], xmm5
0000785dab1d866a  vmovaps [rsp+0x60], xmm6
0000785dab1d8670  vmovaps [rsp+0x70], xmm7
0000785dab1d8676  vmovaps [rsp+0x80], xmm8
0000785dab1d867f  vmovaps [rsp+0x90], xmm9
0000785dab1d8688  vmovaps [rsp+0xA0], xmm10
0000785dab1d8691  vmovaps [rsp+0xB0], xmm11
0000785dab1d869a  vmovaps [rsp+0xC0], xmm12
0000785dab1d86a3  vmovaps [rsp+0xD0], xmm13
0000785dab1d86ac  vmovaps [rsp+0xE0], xmm14
0000785dab1d86b5  sub rsp, 0x30
0000785dab1d86b9  movaps [rsp], xmm15
0000785dab1d86be  movaps [rsp+0x10], xmm3
0000785dab1d86c3  movaps [rsp+0x20], xmm7
0000785dab1d86c8  lea rdi, [rsp]
0000785dab1d86cc  mov esi, 0x00
0000785dab1d86d1  mov rax, 0x61B13BBD6530
0000785dab1d86db  call rax
0000785dab1d86dd  movaps xmm15, [rsp]
0000785dab1d86e2  add rsp, 0x30
0000785dab1d86e6  vmovaps xmm0, [rsp]
0000785dab1d86eb  vmovaps xmm1, [rsp+0x10]
0000785dab1d86f1  vmovaps xmm2, [rsp+0x20]
0000785dab1d86f7  vmovaps xmm3, [rsp+0x30]
0000785dab1d86fd  vmovaps xmm4, [rsp+0x40]
0000785dab1d8703  vmovaps xmm5, [rsp+0x50]
0000785dab1d8709  vmovaps xmm6, [rsp+0x60]
0000785dab1d870f  vmovaps xmm7, [rsp+0x70]
0000785dab1d8715  vmovaps xmm8, [rsp+0x80]
0000785dab1d871e  vmovaps xmm9, [rsp+0x90]
0000785dab1d8727  vmovaps xmm10, [rsp+0xA0]
0000785dab1d8730  vmovaps xmm11, [rsp+0xB0]
0000785dab1d8739  vmovaps xmm12, [rsp+0xC0]
0000785dab1d8742  vmovaps xmm13, [rsp+0xD0]
0000785dab1d874b  vmovaps xmm14, [rsp+0xE0]
0000785dab1d8754  add rsp, 0xF0
0000785dab1d875b  pop r11
0000785dab1d875d  pop r10
0000785dab1d875f  pop r9
0000785dab1d8761  pop r8
0000785dab1d8763  pop rsi
0000785dab1d8764  pop rdi
0000785dab1d8765  pop rdx
0000785dab1d8766  pop rcx
0000785dab1d8767  pop rax
0000785dab1d8768  add rsp, 0x08
0000785dab1d876c  jmp 0x0000785DAB1D6030
0000785dab1d8771  sub rsp, 0x08
0000785dab1d8775  push rax
0000785dab1d8776  push rcx
0000785dab1d8777  push rdx
0000785dab1d8778  push rdi
0000785dab1d8779  push rsi
0000785dab1d877a  push r8
0000785dab1d877c  push r9
0000785dab1d877e  push r10
0000785dab1d8780  push r11
0000785dab1d8782  sub rsp, 0xF0
0000785dab1d8789  vmovaps [rsp], xmm0
0000785dab1d878e  vmovaps [rsp+0x10], xmm1
0000785dab1d8794  vmovaps [rsp+0x20], xmm2
0000785dab1d879a  vmovaps [rsp+0x30], xmm4
0000785dab1d87a0  vmovaps [rsp+0x40], xmm5
0000785dab1d87a6  vmovaps [rsp+0x50], xmm6
0000785dab1d87ac  vmovaps [rsp+0x60], xmm7
0000785dab1d87b2  vmovaps [rsp+0x70], xmm8
0000785dab1d87b8  vmovaps [rsp+0x80], xmm9
0000785dab1d87c1  vmovaps [rsp+0x90], xmm10
0000785dab1d87ca  vmovaps [rsp+0xA0], xmm11
0000785dab1d87d3  vmovaps [rsp+0xB0], xmm12
0000785dab1d87dc  vmovaps [rsp+0xC0], xmm13
0000785dab1d87e5  vmovaps [rsp+0xD0], xmm14
0000785dab1d87ee  vmovaps [rsp+0xE0], xmm15
0000785dab1d87f7  sub rsp, 0x30
0000785dab1d87fb  movaps [rsp], xmm3
0000785dab1d87ff  movaps [rsp+0x10], xmm1
0000785dab1d8804  movaps [rsp+0x20], xmm15
0000785dab1d880a  lea rdi, [rsp]
0000785dab1d880e  mov esi, 0x00
0000785dab1d8813  mov rax, 0x61B13BBD6530
0000785dab1d881d  call rax
0000785dab1d881f  movaps xmm3, [rsp]
0000785dab1d8823  add rsp, 0x30
0000785dab1d8827  vmovaps xmm0, [rsp]
0000785dab1d882c  vmovaps xmm1, [rsp+0x10]
0000785dab1d8832  vmovaps xmm2, [rsp+0x20]
0000785dab1d8838  vmovaps xmm4, [rsp+0x30]
0000785dab1d883e  vmovaps xmm5, [rsp+0x40]
0000785dab1d8844  vmovaps xmm6, [rsp+0x50]
0000785dab1d884a  vmovaps xmm7, [rsp+0x60]
0000785dab1d8850  vmovaps xmm8, [rsp+0x70]
0000785dab1d8856  vmovaps xmm9, [rsp+0x80]
0000785dab1d885f  vmovaps xmm10, [rsp+0x90]
0000785dab1d8868  vmovaps xmm11, [rsp+0xA0]
0000785dab1d8871  vmovaps xmm12, [rsp+0xB0]
0000785dab1d887a  vmovaps xmm13, [rsp+0xC0]
0000785dab1d8883  vmovaps xmm14, [rsp+0xD0]
0000785dab1d888c  vmovaps xmm15, [rsp+0xE0]
0000785dab1d8895  add rsp, 0xF0
0000785dab1d889c  pop r11
0000785dab1d889e  pop r10
0000785dab1d88a0  pop r9
0000785dab1d88a2  pop r8
0000785dab1d88a4  pop rsi
0000785dab1d88a5  pop rdi
0000785dab1d88a6  pop rdx
0000785dab1d88a7  pop rcx
0000785dab1d88a8  pop rax
0000785dab1d88a9  add rsp, 0x08
0000785dab1d88ad  jmp 0x0000785DAB1D60BF
0000785dab1d88b2  call 0x0000785DAB0D64F0
0000785dab1d88b7  jmp 0x0000785DAB1D60C9
0000785dab1d88bc  sub rsp, 0x08
0000785dab1d88c0  push rax
0000785dab1d88c1  push rcx
0000785dab1d88c2  push rdx
0000785dab1d88c3  push rdi
0000785dab1d88c4  push rsi
0000785dab1d88c5  push r8
0000785dab1d88c7  push r9
0000785dab1d88c9  push r10
0000785dab1d88cb  push r11
0000785dab1d88cd  sub rsp, 0xF0
0000785dab1d88d4  vmovaps [rsp], xmm0
0000785dab1d88d9  vmovaps [rsp+0x10], xmm1
0000785dab1d88df  vmovaps [rsp+0x20], xmm2
0000785dab1d88e5  vmovaps [rsp+0x30], xmm3
0000785dab1d88eb  vmovaps [rsp+0x40], xmm4
0000785dab1d88f1  vmovaps [rsp+0x50], xmm5
0000785dab1d88f7  vmovaps [rsp+0x60], xmm6
0000785dab1d88fd  vmovaps [rsp+0x70], xmm7
0000785dab1d8903  vmovaps [rsp+0x80], xmm8
0000785dab1d890c  vmovaps [rsp+0x90], xmm9
0000785dab1d8915  vmovaps [rsp+0xA0], xmm10
0000785dab1d891e  vmovaps [rsp+0xB0], xmm11
0000785dab1d8927  vmovaps [rsp+0xC0], xmm12
0000785dab1d8930  vmovaps [rsp+0xD0], xmm13
0000785dab1d8939  vmovaps [rsp+0xE0], xmm14
0000785dab1d8942  sub rsp, 0x30
0000785dab1d8946  movaps [rsp], xmm15
0000785dab1d894b  movaps [rsp+0x10], xmm14
0000785dab1d8951  movaps [rsp+0x20], xmm4
0000785dab1d8956  lea rdi, [rsp]
0000785dab1d895a  mov esi, 0x00
0000785dab1d895f  mov rax, 0x61B13BBD6530
0000785dab1d8969  call rax
0000785dab1d896b  movaps xmm15, [rsp]
0000785dab1d8970  add rsp, 0x30
0000785dab1d8974  vmovaps xmm0, [rsp]
0000785dab1d8979  vmovaps xmm1, [rsp+0x10]
0000785dab1d897f  vmovaps xmm2, [rsp+0x20]
0000785dab1d8985  vmovaps xmm3, [rsp+0x30]
0000785dab1d898b  vmovaps xmm4, [rsp+0x40]
0000785dab1d8991  vmovaps xmm5, [rsp+0x50]
0000785dab1d8997  vmovaps xmm6, [rsp+0x60]
0000785dab1d899d  vmovaps xmm7, [rsp+0x70]
0000785dab1d89a3  vmovaps xmm8, [rsp+0x80]
0000785dab1d89ac  vmovaps xmm9, [rsp+0x90]
0000785dab1d89b5  vmovaps xmm10, [rsp+0xA0]
0000785dab1d89be  vmovaps xmm11, [rsp+0xB0]
0000785dab1d89c7  vmovaps xmm12, [rsp+0xC0]
0000785dab1d89d0  vmovaps xmm13, [rsp+0xD0]
0000785dab1d89d9  vmovaps xmm14, [rsp+0xE0]
0000785dab1d89e2  add rsp, 0xF0
0000785dab1d89e9  pop r11
0000785dab1d89eb  pop r10
0000785dab1d89ed  pop r9
0000785dab1d89ef  pop r8
0000785dab1d89f1  pop rsi
0000785dab1d89f2  pop rdi
0000785dab1d89f3  pop rdx
0000785dab1d89f4  pop rcx
0000785dab1d89f5  pop rax
0000785dab1d89f6  add rsp, 0x08
0000785dab1d89fa  jmp 0x0000785DAB1D60F7
0000785dab1d89ff  sub rsp, 0x08
0000785dab1d8a03  push rax
0000785dab1d8a04  push rcx
0000785dab1d8a05  push rdx
0000785dab1d8a06  push rdi
0000785dab1d8a07  push rsi
0000785dab1d8a08  push r8
0000785dab1d8a0a  push r9
0000785dab1d8a0c  push r10
0000785dab1d8a0e  push r11
0000785dab1d8a10  sub rsp, 0xF0
0000785dab1d8a17  vmovaps [rsp], xmm0
0000785dab1d8a1c  vmovaps [rsp+0x10], xmm1
0000785dab1d8a22  vmovaps [rsp+0x20], xmm2
0000785dab1d8a28  vmovaps [rsp+0x30], xmm3
0000785dab1d8a2e  vmovaps [rsp+0x40], xmm4
0000785dab1d8a34  vmovaps [rsp+0x50], xmm5
0000785dab1d8a3a  vmovaps [rsp+0x60], xmm6
0000785dab1d8a40  vmovaps [rsp+0x70], xmm7
0000785dab1d8a46  vmovaps [rsp+0x80], xmm8
0000785dab1d8a4f  vmovaps [rsp+0x90], xmm9
0000785dab1d8a58  vmovaps [rsp+0xA0], xmm10
0000785dab1d8a61  vmovaps [rsp+0xB0], xmm11
0000785dab1d8a6a  vmovaps [rsp+0xC0], xmm12
0000785dab1d8a73  vmovaps [rsp+0xD0], xmm13
0000785dab1d8a7c  vmovaps [rsp+0xE0], xmm15
0000785dab1d8a85  sub rsp, 0x30
0000785dab1d8a89  movaps [rsp], xmm14
0000785dab1d8a8e  movaps [rsp+0x10], xmm2
0000785dab1d8a93  movaps [rsp+0x20], xmm1
0000785dab1d8a98  lea rdi, [rsp]
0000785dab1d8a9c  mov esi, 0x00
0000785dab1d8aa1  mov rax, 0x61B13BBD6530
0000785dab1d8aab  call rax
0000785dab1d8aad  movaps xmm14, [rsp]
0000785dab1d8ab2  add rsp, 0x30
0000785dab1d8ab6  vmovaps xmm0, [rsp]
0000785dab1d8abb  vmovaps xmm1, [rsp+0x10]
0000785dab1d8ac1  vmovaps xmm2, [rsp+0x20]
0000785dab1d8ac7  vmovaps xmm3, [rsp+0x30]
0000785dab1d8acd  vmovaps xmm4, [rsp+0x40]
0000785dab1d8ad3  vmovaps xmm5, [rsp+0x50]
0000785dab1d8ad9  vmovaps xmm6, [rsp+0x60]
0000785dab1d8adf  vmovaps xmm7, [rsp+0x70]
0000785dab1d8ae5  vmovaps xmm8, [rsp+0x80]
0000785dab1d8aee  vmovaps xmm9, [rsp+0x90]
0000785dab1d8af7  vmovaps xmm10, [rsp+0xA0]
0000785dab1d8b00  vmovaps xmm11, [rsp+0xB0]
0000785dab1d8b09  vmovaps xmm12, [rsp+0xC0]
0000785dab1d8b12  vmovaps xmm13, [rsp+0xD0]
0000785dab1d8b1b  vmovaps xmm15, [rsp+0xE0]
0000785dab1d8b24  add rsp, 0xF0
0000785dab1d8b2b  pop r11
0000785dab1d8b2d  pop r10
0000785dab1d8b2f  pop r9
0000785dab1d8b31  pop r8
0000785dab1d8b33  pop rsi
0000785dab1d8b34  pop rdi
0000785dab1d8b35  pop rdx
0000785dab1d8b36  pop rcx
0000785dab1d8b37  pop rax
0000785dab1d8b38  add rsp, 0x08
0000785dab1d8b3c  jmp 0x0000785DAB1D611D
0000785dab1d8b41  sub rsp, 0x08
0000785dab1d8b45  push rax
0000785dab1d8b46  push rcx
0000785dab1d8b47  push rdx
0000785dab1d8b48  push rdi
0000785dab1d8b49  push rsi
0000785dab1d8b4a  push r8
0000785dab1d8b4c  push r9
0000785dab1d8b4e  push r10
0000785dab1d8b50  push r11
0000785dab1d8b52  sub rsp, 0xF0
0000785dab1d8b59  vmovaps [rsp], xmm0
0000785dab1d8b5e  vmovaps [rsp+0x10], xmm2
0000785dab1d8b64  vmovaps [rsp+0x20], xmm3
0000785dab1d8b6a  vmovaps [rsp+0x30], xmm4
0000785dab1d8b70  vmovaps [rsp+0x40], xmm5
0000785dab1d8b76  vmovaps [rsp+0x50], xmm6
0000785dab1d8b7c  vmovaps [rsp+0x60], xmm7
0000785dab1d8b82  vmovaps [rsp+0x70], xmm8
0000785dab1d8b88  vmovaps [rsp+0x80], xmm9
0000785dab1d8b91  vmovaps [rsp+0x90], xmm10
0000785dab1d8b9a  vmovaps [rsp+0xA0], xmm11
0000785dab1d8ba3  vmovaps [rsp+0xB0], xmm12
0000785dab1d8bac  vmovaps [rsp+0xC0], xmm13
0000785dab1d8bb5  vmovaps [rsp+0xD0], xmm14
0000785dab1d8bbe  vmovaps [rsp+0xE0], xmm15
0000785dab1d8bc7  sub rsp, 0x30
0000785dab1d8bcb  movaps [rsp], xmm1
0000785dab1d8bcf  movaps [rsp+0x10], xmm4
0000785dab1d8bd4  movaps [rsp+0x20], xmm9
0000785dab1d8bda  lea rdi, [rsp]
0000785dab1d8bde  mov esi, 0x00
0000785dab1d8be3  mov rax, 0x61B13BBD6530
0000785dab1d8bed  call rax
0000785dab1d8bef  movaps xmm1, [rsp]
0000785dab1d8bf3  add rsp, 0x30
0000785dab1d8bf7  vmovaps xmm0, [rsp]
0000785dab1d8bfc  vmovaps xmm2, [rsp+0x10]
0000785dab1d8c02  vmovaps xmm3, [rsp+0x20]
0000785dab1d8c08  vmovaps xmm4, [rsp+0x30]
0000785dab1d8c0e  vmovaps xmm5, [rsp+0x40]
0000785dab1d8c14  vmovaps xmm6, [rsp+0x50]
0000785dab1d8c1a  vmovaps xmm7, [rsp+0x60]
0000785dab1d8c20  vmovaps xmm8, [rsp+0x70]
0000785dab1d8c26  vmovaps xmm9, [rsp+0x80]
0000785dab1d8c2f  vmovaps xmm10, [rsp+0x90]
0000785dab1d8c38  vmovaps xmm11, [rsp+0xA0]
0000785dab1d8c41  vmovaps xmm12, [rsp+0xB0]
0000785dab1d8c4a  vmovaps xmm13, [rsp+0xC0]
0000785dab1d8c53  vmovaps xmm14, [rsp+0xD0]
0000785dab1d8c5c  vmovaps xmm15, [rsp+0xE0]
0000785dab1d8c65  add rsp, 0xF0
0000785dab1d8c6c  pop r11
0000785dab1d8c6e  pop r10
0000785dab1d8c70  pop r9
0000785dab1d8c72  pop r8
0000785dab1d8c74  pop rsi
0000785dab1d8c75  pop rdi
0000785dab1d8c76  pop rdx
0000785dab1d8c77  pop rcx
0000785dab1d8c78  pop rax
0000785dab1d8c79  add rsp, 0x08
0000785dab1d8c7d  jmp 0x0000785DAB1D613B
0000785dab1d8c82  sub rsp, 0x08
0000785dab1d8c86  push rax
0000785dab1d8c87  push rcx
0000785dab1d8c88  push rdx
0000785dab1d8c89  push rdi
0000785dab1d8c8a  push rsi
0000785dab1d8c8b  push r8
0000785dab1d8c8d  push r9
0000785dab1d8c8f  push r10
0000785dab1d8c91  push r11
0000785dab1d8c93  sub rsp, 0xF0
0000785dab1d8c9a  vmovaps [rsp], xmm0
0000785dab1d8c9f  vmovaps [rsp+0x10], xmm1
0000785dab1d8ca5  vmovaps [rsp+0x20], xmm2
0000785dab1d8cab  vmovaps [rsp+0x30], xmm3
0000785dab1d8cb1  vmovaps [rsp+0x40], xmm5
0000785dab1d8cb7  vmovaps [rsp+0x50], xmm6
0000785dab1d8cbd  vmovaps [rsp+0x60], xmm7
0000785dab1d8cc3  vmovaps [rsp+0x70], xmm8
0000785dab1d8cc9  vmovaps [rsp+0x80], xmm9
0000785dab1d8cd2  vmovaps [rsp+0x90], xmm10
0000785dab1d8cdb  vmovaps [rsp+0xA0], xmm11
0000785dab1d8ce4  vmovaps [rsp+0xB0], xmm12
0000785dab1d8ced  vmovaps [rsp+0xC0], xmm13
0000785dab1d8cf6  vmovaps [rsp+0xD0], xmm14
0000785dab1d8cff  vmovaps [rsp+0xE0], xmm15
0000785dab1d8d08  sub rsp, 0x30
0000785dab1d8d0c  movaps [rsp], xmm4
0000785dab1d8d10  movaps [rsp+0x10], xmm2
0000785dab1d8d15  movaps [rsp+0x20], xmm9
0000785dab1d8d1b  lea rdi, [rsp]
0000785dab1d8d1f  mov esi, 0x00
0000785dab1d8d24  mov rax, 0x61B13BBD6530
0000785dab1d8d2e  call rax
0000785dab1d8d30  movaps xmm4, [rsp]
0000785dab1d8d34  add rsp, 0x30
0000785dab1d8d38  vmovaps xmm0, [rsp]
0000785dab1d8d3d  vmovaps xmm1, [rsp+0x10]
0000785dab1d8d43  vmovaps xmm2, [rsp+0x20]
0000785dab1d8d49  vmovaps xmm3, [rsp+0x30]
0000785dab1d8d4f  vmovaps xmm5, [rsp+0x40]
0000785dab1d8d55  vmovaps xmm6, [rsp+0x50]
0000785dab1d8d5b  vmovaps xmm7, [rsp+0x60]
0000785dab1d8d61  vmovaps xmm8, [rsp+0x70]
0000785dab1d8d67  vmovaps xmm9, [rsp+0x80]
0000785dab1d8d70  vmovaps xmm10, [rsp+0x90]
0000785dab1d8d79  vmovaps xmm11, [rsp+0xA0]
0000785dab1d8d82  vmovaps xmm12, [rsp+0xB0]
0000785dab1d8d8b  vmovaps xmm13, [rsp+0xC0]
0000785dab1d8d94  vmovaps xmm14, [rsp+0xD0]
0000785dab1d8d9d  vmovaps xmm15, [rsp+0xE0]
0000785dab1d8da6  add rsp, 0xF0
0000785dab1d8dad  pop r11
0000785dab1d8daf  pop r10
0000785dab1d8db1  pop r9
0000785dab1d8db3  pop r8
0000785dab1d8db5  pop rsi
0000785dab1d8db6  pop rdi
0000785dab1d8db7  pop rdx
0000785dab1d8db8  pop rcx
0000785dab1d8db9  pop rax
0000785dab1d8dba  add rsp, 0x08
0000785dab1d8dbe  jmp 0x0000785DAB1D616B
0000785dab1d8dc3  sub rsp, 0x08
0000785dab1d8dc7  push rax
0000785dab1d8dc8  push rcx
0000785dab1d8dc9  push rdx
0000785dab1d8dca  push rdi
0000785dab1d8dcb  push rsi
0000785dab1d8dcc  push r8
0000785dab1d8dce  push r9
0000785dab1d8dd0  push r10
0000785dab1d8dd2  push r11
0000785dab1d8dd4  sub rsp, 0xF0
0000785dab1d8ddb  vmovaps [rsp], xmm0
0000785dab1d8de0  vmovaps [rsp+0x10], xmm1
0000785dab1d8de6  vmovaps [rsp+0x20], xmm2
0000785dab1d8dec  vmovaps [rsp+0x30], xmm3
0000785dab1d8df2  vmovaps [rsp+0x40], xmm4
0000785dab1d8df8  vmovaps [rsp+0x50], xmm5
0000785dab1d8dfe  vmovaps [rsp+0x60], xmm6
0000785dab1d8e04  vmovaps [rsp+0x70], xmm7
0000785dab1d8e0a  vmovaps [rsp+0x80], xmm8
0000785dab1d8e13  vmovaps [rsp+0x90], xmm10
0000785dab1d8e1c  vmovaps [rsp+0xA0], xmm11
0000785dab1d8e25  vmovaps [rsp+0xB0], xmm12
0000785dab1d8e2e  vmovaps [rsp+0xC0], xmm13
0000785dab1d8e37  vmovaps [rsp+0xD0], xmm14
0000785dab1d8e40  vmovaps [rsp+0xE0], xmm15
0000785dab1d8e49  sub rsp, 0x30
0000785dab1d8e4d  movaps [rsp], xmm9
0000785dab1d8e52  movaps [rsp+0x10], xmm2
0000785dab1d8e57  movaps [rsp+0x20], xmm1
0000785dab1d8e5c  lea rdi, [rsp]
0000785dab1d8e60  mov esi, 0x00
0000785dab1d8e65  mov rax, 0x61B13BBD6530
0000785dab1d8e6f  call rax
0000785dab1d8e71  movaps xmm9, [rsp]
0000785dab1d8e76  add rsp, 0x30
0000785dab1d8e7a  vmovaps xmm0, [rsp]
0000785dab1d8e7f  vmovaps xmm1, [rsp+0x10]
0000785dab1d8e85  vmovaps xmm2, [rsp+0x20]
0000785dab1d8e8b  vmovaps xmm3, [rsp+0x30]
0000785dab1d8e91  vmovaps xmm4, [rsp+0x40]
0000785dab1d8e97  vmovaps xmm5, [rsp+0x50]
0000785dab1d8e9d  vmovaps xmm6, [rsp+0x60]
0000785dab1d8ea3  vmovaps xmm7, [rsp+0x70]
0000785dab1d8ea9  vmovaps xmm8, [rsp+0x80]
0000785dab1d8eb2  vmovaps xmm10, [rsp+0x90]
0000785dab1d8ebb  vmovaps xmm11, [rsp+0xA0]
0000785dab1d8ec4  vmovaps xmm12, [rsp+0xB0]
0000785dab1d8ecd  vmovaps xmm13, [rsp+0xC0]
0000785dab1d8ed6  vmovaps xmm14, [rsp+0xD0]
0000785dab1d8edf  vmovaps xmm15, [rsp+0xE0]
0000785dab1d8ee8  add rsp, 0xF0
0000785dab1d8eef  pop r11
0000785dab1d8ef1  pop r10
0000785dab1d8ef3  pop r9
0000785dab1d8ef5  pop r8
0000785dab1d8ef7  pop rsi
0000785dab1d8ef8  pop rdi
0000785dab1d8ef9  pop rdx
0000785dab1d8efa  pop rcx
0000785dab1d8efb  pop rax
0000785dab1d8efc  add rsp, 0x08
0000785dab1d8f00  jmp 0x0000785DAB1D61A1
0000785dab1d8f05  sub rsp, 0x08
0000785dab1d8f09  push rax
0000785dab1d8f0a  push rcx
0000785dab1d8f0b  push rdx
0000785dab1d8f0c  push rdi
0000785dab1d8f0d  push rsi
0000785dab1d8f0e  push r8
0000785dab1d8f10  push r9
0000785dab1d8f12  push r10
0000785dab1d8f14  push r11
0000785dab1d8f16  sub rsp, 0xF0
0000785dab1d8f1d  vmovaps [rsp], xmm0
0000785dab1d8f22  vmovaps [rsp+0x10], xmm2
0000785dab1d8f28  vmovaps [rsp+0x20], xmm3
0000785dab1d8f2e  vmovaps [rsp+0x30], xmm4
0000785dab1d8f34  vmovaps [rsp+0x40], xmm5
0000785dab1d8f3a  vmovaps [rsp+0x50], xmm6
0000785dab1d8f40  vmovaps [rsp+0x60], xmm7
0000785dab1d8f46  vmovaps [rsp+0x70], xmm8
0000785dab1d8f4c  vmovaps [rsp+0x80], xmm9
0000785dab1d8f55  vmovaps [rsp+0x90], xmm10
0000785dab1d8f5e  vmovaps [rsp+0xA0], xmm11
0000785dab1d8f67  vmovaps [rsp+0xB0], xmm12
0000785dab1d8f70  vmovaps [rsp+0xC0], xmm13
0000785dab1d8f79  vmovaps [rsp+0xD0], xmm14
0000785dab1d8f82  vmovaps [rsp+0xE0], xmm15
0000785dab1d8f8b  sub rsp, 0x30
0000785dab1d8f8f  movaps [rsp], xmm1
0000785dab1d8f93  movaps [rsp+0x10], xmm15
0000785dab1d8f99  movaps [rsp+0x20], xmm6
0000785dab1d8f9e  lea rdi, [rsp]
0000785dab1d8fa2  mov esi, 0x00
0000785dab1d8fa7  mov rax, 0x61B13BBD6530
0000785dab1d8fb1  call rax
0000785dab1d8fb3  movaps xmm1, [rsp]
0000785dab1d8fb7  add rsp, 0x30
0000785dab1d8fbb  vmovaps xmm0, [rsp]
0000785dab1d8fc0  vmovaps xmm2, [rsp+0x10]
0000785dab1d8fc6  vmovaps xmm3, [rsp+0x20]
0000785dab1d8fcc  vmovaps xmm4, [rsp+0x30]
0000785dab1d8fd2  vmovaps xmm5, [rsp+0x40]
0000785dab1d8fd8  vmovaps xmm6, [rsp+0x50]
0000785dab1d8fde  vmovaps xmm7, [rsp+0x60]
0000785dab1d8fe4  vmovaps xmm8, [rsp+0x70]
0000785dab1d8fea  vmovaps xmm9, [rsp+0x80]
0000785dab1d8ff3  vmovaps xmm10, [rsp+0x90]
0000785dab1d8ffc  vmovaps xmm11, [rsp+0xA0]
0000785dab1d9005  vmovaps xmm12, [rsp+0xB0]
0000785dab1d900e  vmovaps xmm13, [rsp+0xC0]
0000785dab1d9017  vmovaps xmm14, [rsp+0xD0]
0000785dab1d9020  vmovaps xmm15, [rsp+0xE0]
0000785dab1d9029  add rsp, 0xF0
0000785dab1d9030  pop r11
0000785dab1d9032  pop r10
0000785dab1d9034  pop r9
0000785dab1d9036  pop r8
0000785dab1d9038  pop rsi
0000785dab1d9039  pop rdi
0000785dab1d903a  pop rdx
0000785dab1d903b  pop rcx
0000785dab1d903c  pop rax
0000785dab1d903d  add rsp, 0x08
0000785dab1d9041  jmp 0x0000785DAB1D61C2
0000785dab1d9046  sub rsp, 0x08
0000785dab1d904a  push rax
0000785dab1d904b  push rcx
0000785dab1d904c  push rdx
0000785dab1d904d  push rdi
0000785dab1d904e  push rsi
0000785dab1d904f  push r8
0000785dab1d9051  push r9
0000785dab1d9053  push r10
0000785dab1d9055  push r11
0000785dab1d9057  sub rsp, 0xF0
0000785dab1d905e  vmovaps [rsp], xmm0
0000785dab1d9063  vmovaps [rsp+0x10], xmm1
0000785dab1d9069  vmovaps [rsp+0x20], xmm2
0000785dab1d906f  vmovaps [rsp+0x30], xmm3
0000785dab1d9075  vmovaps [rsp+0x40], xmm4
0000785dab1d907b  vmovaps [rsp+0x50], xmm5
0000785dab1d9081  vmovaps [rsp+0x60], xmm6
0000785dab1d9087  vmovaps [rsp+0x70], xmm7
0000785dab1d908d  vmovaps [rsp+0x80], xmm8
0000785dab1d9096  vmovaps [rsp+0x90], xmm9
0000785dab1d909f  vmovaps [rsp+0xA0], xmm10
0000785dab1d90a8  vmovaps [rsp+0xB0], xmm11
0000785dab1d90b1  vmovaps [rsp+0xC0], xmm12
0000785dab1d90ba  vmovaps [rsp+0xD0], xmm13
0000785dab1d90c3  vmovaps [rsp+0xE0], xmm14
0000785dab1d90cc  sub rsp, 0x30
0000785dab1d90d0  movaps [rsp], xmm15
0000785dab1d90d5  movaps [rsp+0x10], xmm5
0000785dab1d90da  movaps [rsp+0x20], xmm3
0000785dab1d90df  lea rdi, [rsp]
0000785dab1d90e3  mov esi, 0x00
0000785dab1d90e8  mov rax, 0x61B13BBD6530
0000785dab1d90f2  call rax
0000785dab1d90f4  movaps xmm15, [rsp]
0000785dab1d90f9  add rsp, 0x30
0000785dab1d90fd  vmovaps xmm0, [rsp]
0000785dab1d9102  vmovaps xmm1, [rsp+0x10]
0000785dab1d9108  vmovaps xmm2, [rsp+0x20]
0000785dab1d910e  vmovaps xmm3, [rsp+0x30]
0000785dab1d9114  vmovaps xmm4, [rsp+0x40]
0000785dab1d911a  vmovaps xmm5, [rsp+0x50]
0000785dab1d9120  vmovaps xmm6, [rsp+0x60]
0000785dab1d9126  vmovaps xmm7, [rsp+0x70]
0000785dab1d912c  vmovaps xmm8, [rsp+0x80]
0000785dab1d9135  vmovaps xmm9, [rsp+0x90]
0000785dab1d913e  vmovaps xmm10, [rsp+0xA0]
0000785dab1d9147  vmovaps xmm11, [rsp+0xB0]
0000785dab1d9150  vmovaps xmm12, [rsp+0xC0]
0000785dab1d9159  vmovaps xmm13, [rsp+0xD0]
0000785dab1d9162  vmovaps xmm14, [rsp+0xE0]
0000785dab1d916b  add rsp, 0xF0
0000785dab1d9172  pop r11
0000785dab1d9174  pop r10
0000785dab1d9176  pop r9
0000785dab1d9178  pop r8
0000785dab1d917a  pop rsi
0000785dab1d917b  pop rdi
0000785dab1d917c  pop rdx
0000785dab1d917d  pop rcx
0000785dab1d917e  pop rax
0000785dab1d917f  add rsp, 0x08
0000785dab1d9183  jmp 0x0000785DAB1D61DC
0000785dab1d9188  sub rsp, 0x08
0000785dab1d918c  push rax
0000785dab1d918d  push rcx
0000785dab1d918e  push rdx
0000785dab1d918f  push rdi
0000785dab1d9190  push rsi
0000785dab1d9191  push r8
0000785dab1d9193  push r9
0000785dab1d9195  push r10
0000785dab1d9197  push r11
0000785dab1d9199  sub rsp, 0xF0
0000785dab1d91a0  vmovaps [rsp], xmm0
0000785dab1d91a5  vmovaps [rsp+0x10], xmm1
0000785dab1d91ab  vmovaps [rsp+0x20], xmm2
0000785dab1d91b1  vmovaps [rsp+0x30], xmm3
0000785dab1d91b7  vmovaps [rsp+0x40], xmm4
0000785dab1d91bd  vmovaps [rsp+0x50], xmm6
0000785dab1d91c3  vmovaps [rsp+0x60], xmm7
0000785dab1d91c9  vmovaps [rsp+0x70], xmm8
0000785dab1d91cf  vmovaps [rsp+0x80], xmm9
0000785dab1d91d8  vmovaps [rsp+0x90], xmm10
0000785dab1d91e1  vmovaps [rsp+0xA0], xmm11
0000785dab1d91ea  vmovaps [rsp+0xB0], xmm12
0000785dab1d91f3  vmovaps [rsp+0xC0], xmm13
0000785dab1d91fc  vmovaps [rsp+0xD0], xmm14
0000785dab1d9205  vmovaps [rsp+0xE0], xmm15
0000785dab1d920e  sub rsp, 0x30
0000785dab1d9212  movaps [rsp], xmm5
0000785dab1d9216  movaps [rsp+0x10], xmm8
0000785dab1d921c  movaps [rsp+0x20], xmm6
0000785dab1d9221  lea rdi, [rsp]
0000785dab1d9225  mov esi, 0x00
0000785dab1d922a  mov rax, 0x61B13BBD6530
0000785dab1d9234  call rax
0000785dab1d9236  movaps xmm5, [rsp]
0000785dab1d923a  add rsp, 0x30
0000785dab1d923e  vmovaps xmm0, [rsp]
0000785dab1d9243  vmovaps xmm1, [rsp+0x10]
0000785dab1d9249  vmovaps xmm2, [rsp+0x20]
0000785dab1d924f  vmovaps xmm3, [rsp+0x30]
0000785dab1d9255  vmovaps xmm4, [rsp+0x40]
0000785dab1d925b  vmovaps xmm6, [rsp+0x50]
0000785dab1d9261  vmovaps xmm7, [rsp+0x60]
0000785dab1d9267  vmovaps xmm8, [rsp+0x70]
0000785dab1d926d  vmovaps xmm9, [rsp+0x80]
0000785dab1d9276  vmovaps xmm10, [rsp+0x90]
0000785dab1d927f  vmovaps xmm11, [rsp+0xA0]
0000785dab1d9288  vmovaps xmm12, [rsp+0xB0]
0000785dab1d9291  vmovaps xmm13, [rsp+0xC0]
0000785dab1d929a  vmovaps xmm14, [rsp+0xD0]
0000785dab1d92a3  vmovaps xmm15, [rsp+0xE0]
0000785dab1d92ac  add rsp, 0xF0
0000785dab1d92b3  pop r11
0000785dab1d92b5  pop r10
0000785dab1d92b7  pop r9
0000785dab1d92b9  pop r8
0000785dab1d92bb  pop rsi
0000785dab1d92bc  pop rdi
0000785dab1d92bd  pop rdx
0000785dab1d92be  pop rcx
0000785dab1d92bf  pop rax
0000785dab1d92c0  add rsp, 0x08
0000785dab1d92c4  jmp 0x0000785DAB1D6200
0000785dab1d92c9  sub rsp, 0x08
0000785dab1d92cd  push rax
0000785dab1d92ce  push rcx
0000785dab1d92cf  push rdx
0000785dab1d92d0  push rdi
0000785dab1d92d1  push rsi
0000785dab1d92d2  push r8
0000785dab1d92d4  push r9
0000785dab1d92d6  push r10
0000785dab1d92d8  push r11
0000785dab1d92da  sub rsp, 0xF0
0000785dab1d92e1  vmovaps [rsp], xmm0
0000785dab1d92e6  vmovaps [rsp+0x10], xmm1
0000785dab1d92ec  vmovaps [rsp+0x20], xmm2
0000785dab1d92f2  vmovaps [rsp+0x30], xmm3
0000785dab1d92f8  vmovaps [rsp+0x40], xmm4
0000785dab1d92fe  vmovaps [rsp+0x50], xmm5
0000785dab1d9304  vmovaps [rsp+0x60], xmm7
0000785dab1d930a  vmovaps [rsp+0x70], xmm8
0000785dab1d9310  vmovaps [rsp+0x80], xmm9
0000785dab1d9319  vmovaps [rsp+0x90], xmm10
0000785dab1d9322  vmovaps [rsp+0xA0], xmm11
0000785dab1d932b  vmovaps [rsp+0xB0], xmm12
0000785dab1d9334  vmovaps [rsp+0xC0], xmm13
0000785dab1d933d  vmovaps [rsp+0xD0], xmm14
0000785dab1d9346  vmovaps [rsp+0xE0], xmm15
0000785dab1d934f  sub rsp, 0x30
0000785dab1d9353  movaps [rsp], xmm6
0000785dab1d9357  movaps [rsp+0x10], xmm10
0000785dab1d935d  movaps [rsp+0x20], xmm8
0000785dab1d9363  lea rdi, [rsp]
0000785dab1d9367  mov esi, 0x00
0000785dab1d936c  mov rax, 0x61B13BBD6530
0000785dab1d9376  call rax
0000785dab1d9378  movaps xmm6, [rsp]
0000785dab1d937c  add rsp, 0x30
0000785dab1d9380  vmovaps xmm0, [rsp]
0000785dab1d9385  vmovaps xmm1, [rsp+0x10]
0000785dab1d938b  vmovaps xmm2, [rsp+0x20]
0000785dab1d9391  vmovaps xmm3, [rsp+0x30]
0000785dab1d9397  vmovaps xmm4, [rsp+0x40]
0000785dab1d939d  vmovaps xmm5, [rsp+0x50]
0000785dab1d93a3  vmovaps xmm7, [rsp+0x60]
0000785dab1d93a9  vmovaps xmm8, [rsp+0x70]
0000785dab1d93af  vmovaps xmm9, [rsp+0x80]
0000785dab1d93b8  vmovaps xmm10, [rsp+0x90]
0000785dab1d93c1  vmovaps xmm11, [rsp+0xA0]
0000785dab1d93ca  vmovaps xmm12, [rsp+0xB0]
0000785dab1d93d3  vmovaps xmm13, [rsp+0xC0]
0000785dab1d93dc  vmovaps xmm14, [rsp+0xD0]
0000785dab1d93e5  vmovaps xmm15, [rsp+0xE0]
0000785dab1d93ee  add rsp, 0xF0
0000785dab1d93f5  pop r11
0000785dab1d93f7  pop r10
0000785dab1d93f9  pop r9
0000785dab1d93fb  pop r8
0000785dab1d93fd  pop rsi
0000785dab1d93fe  pop rdi
0000785dab1d93ff  pop rdx
0000785dab1d9400  pop rcx
0000785dab1d9401  pop rax
0000785dab1d9402  add rsp, 0x08
0000785dab1d9406  jmp 0x0000785DAB1D6225
0000785dab1d940b  sub rsp, 0x08
0000785dab1d940f  push rax
0000785dab1d9410  push rcx
0000785dab1d9411  push rdx
0000785dab1d9412  push rdi
0000785dab1d9413  push rsi
0000785dab1d9414  push r8
0000785dab1d9416  push r9
0000785dab1d9418  push r10
0000785dab1d941a  push r11
0000785dab1d941c  sub rsp, 0xF0
0000785dab1d9423  vmovaps [rsp], xmm0
0000785dab1d9428  vmovaps [rsp+0x10], xmm1
0000785dab1d942e  vmovaps [rsp+0x20], xmm2
0000785dab1d9434  vmovaps [rsp+0x30], xmm3
0000785dab1d943a  vmovaps [rsp+0x40], xmm4
0000785dab1d9440  vmovaps [rsp+0x50], xmm5
0000785dab1d9446  vmovaps [rsp+0x60], xmm6
0000785dab1d944c  vmovaps [rsp+0x70], xmm7
0000785dab1d9452  vmovaps [rsp+0x80], xmm8
0000785dab1d945b  vmovaps [rsp+0x90], xmm9
0000785dab1d9464  vmovaps [rsp+0xA0], xmm11
0000785dab1d946d  vmovaps [rsp+0xB0], xmm12
0000785dab1d9476  vmovaps [rsp+0xC0], xmm13
0000785dab1d947f  vmovaps [rsp+0xD0], xmm14
0000785dab1d9488  vmovaps [rsp+0xE0], xmm15
0000785dab1d9491  sub rsp, 0x30
0000785dab1d9495  movaps [rsp], xmm10
0000785dab1d949a  movaps [rsp+0x10], xmm8
0000785dab1d94a0  movaps [rsp+0x20], xmm14
0000785dab1d94a6  lea rdi, [rsp]
0000785dab1d94aa  mov esi, 0x00
0000785dab1d94af  mov rax, 0x61B13BBD6530
0000785dab1d94b9  call rax
0000785dab1d94bb  movaps xmm10, [rsp]
0000785dab1d94c0  add rsp, 0x30
0000785dab1d94c4  vmovaps xmm0, [rsp]
0000785dab1d94c9  vmovaps xmm1, [rsp+0x10]
0000785dab1d94cf  vmovaps xmm2, [rsp+0x20]
0000785dab1d94d5  vmovaps xmm3, [rsp+0x30]
0000785dab1d94db  vmovaps xmm4, [rsp+0x40]
0000785dab1d94e1  vmovaps xmm5, [rsp+0x50]
0000785dab1d94e7  vmovaps xmm6, [rsp+0x60]
0000785dab1d94ed  vmovaps xmm7, [rsp+0x70]
0000785dab1d94f3  vmovaps xmm8, [rsp+0x80]
0000785dab1d94fc  vmovaps xmm9, [rsp+0x90]
0000785dab1d9505  vmovaps xmm11, [rsp+0xA0]
0000785dab1d950e  vmovaps xmm12, [rsp+0xB0]
0000785dab1d9517  vmovaps xmm13, [rsp+0xC0]
0000785dab1d9520  vmovaps xmm14, [rsp+0xD0]
0000785dab1d9529  vmovaps xmm15, [rsp+0xE0]
0000785dab1d9532  add rsp, 0xF0
0000785dab1d9539  pop r11
0000785dab1d953b  pop r10
0000785dab1d953d  pop r9
0000785dab1d953f  pop r8
0000785dab1d9541  pop rsi
0000785dab1d9542  pop rdi
0000785dab1d9543  pop rdx
0000785dab1d9544  pop rcx
0000785dab1d9545  pop rax
0000785dab1d9546  add rsp, 0x08
0000785dab1d954a  jmp 0x0000785DAB1D6245
0000785dab1d954f  sub rsp, 0x08
0000785dab1d9553  push rax
0000785dab1d9554  push rcx
0000785dab1d9555  push rdx
0000785dab1d9556  push rdi
0000785dab1d9557  push rsi
0000785dab1d9558  push r8
0000785dab1d955a  push r9
0000785dab1d955c  push r10
0000785dab1d955e  push r11
0000785dab1d9560  sub rsp, 0xF0
0000785dab1d9567  vmovaps [rsp], xmm0
0000785dab1d956c  vmovaps [rsp+0x10], xmm1
0000785dab1d9572  vmovaps [rsp+0x20], xmm2
0000785dab1d9578  vmovaps [rsp+0x30], xmm3
0000785dab1d957e  vmovaps [rsp+0x40], xmm4
0000785dab1d9584  vmovaps [rsp+0x50], xmm5
0000785dab1d958a  vmovaps [rsp+0x60], xmm6
0000785dab1d9590  vmovaps [rsp+0x70], xmm7
0000785dab1d9596  vmovaps [rsp+0x80], xmm8
0000785dab1d959f  vmovaps [rsp+0x90], xmm9
0000785dab1d95a8  vmovaps [rsp+0xA0], xmm10
0000785dab1d95b1  vmovaps [rsp+0xB0], xmm11
0000785dab1d95ba  vmovaps [rsp+0xC0], xmm12
0000785dab1d95c3  vmovaps [rsp+0xD0], xmm13
0000785dab1d95cc  vmovaps [rsp+0xE0], xmm15
0000785dab1d95d5  sub rsp, 0x30
0000785dab1d95d9  movaps [rsp], xmm14
0000785dab1d95de  movaps [rsp+0x10], xmm8
0000785dab1d95e4  movaps [rsp+0x20], xmm4
0000785dab1d95e9  lea rdi, [rsp]
0000785dab1d95ed  mov esi, 0x00
0000785dab1d95f2  mov rax, 0x61B13BBD6530
0000785dab1d95fc  call rax
0000785dab1d95fe  movaps xmm14, [rsp]
0000785dab1d9603  add rsp, 0x30
0000785dab1d9607  vmovaps xmm0, [rsp]
0000785dab1d960c  vmovaps xmm1, [rsp+0x10]
0000785dab1d9612  vmovaps xmm2, [rsp+0x20]
0000785dab1d9618  vmovaps xmm3, [rsp+0x30]
0000785dab1d961e  vmovaps xmm4, [rsp+0x40]
0000785dab1d9624  vmovaps xmm5, [rsp+0x50]
0000785dab1d962a  vmovaps xmm6, [rsp+0x60]
0000785dab1d9630  vmovaps xmm7, [rsp+0x70]
0000785dab1d9636  vmovaps xmm8, [rsp+0x80]
0000785dab1d963f  vmovaps xmm9, [rsp+0x90]
0000785dab1d9648  vmovaps xmm10, [rsp+0xA0]
0000785dab1d9651  vmovaps xmm11, [rsp+0xB0]
0000785dab1d965a  vmovaps xmm12, [rsp+0xC0]
0000785dab1d9663  vmovaps xmm13, [rsp+0xD0]
0000785dab1d966c  vmovaps xmm15, [rsp+0xE0]
0000785dab1d9675  add rsp, 0xF0
0000785dab1d967c  pop r11
0000785dab1d967e  pop r10
0000785dab1d9680  pop r9
0000785dab1d9682  pop r8
0000785dab1d9684  pop rsi
0000785dab1d9685  pop rdi
0000785dab1d9686  pop rdx
0000785dab1d9687  pop rcx
0000785dab1d9688  pop rax
0000785dab1d9689  add rsp, 0x08
0000785dab1d968d  jmp 0x0000785DAB1D6265
0000785dab1d9692  sub rsp, 0x08
0000785dab1d9696  push rax
0000785dab1d9697  push rcx
0000785dab1d9698  push rdx
0000785dab1d9699  push rdi
0000785dab1d969a  push rsi
0000785dab1d969b  push r8
0000785dab1d969d  push r9
0000785dab1d969f  push r10
0000785dab1d96a1  push r11
0000785dab1d96a3  sub rsp, 0xF0
0000785dab1d96aa  vmovaps [rsp], xmm0
0000785dab1d96af  vmovaps [rsp+0x10], xmm1
0000785dab1d96b5  vmovaps [rsp+0x20], xmm2
0000785dab1d96bb  vmovaps [rsp+0x30], xmm3
0000785dab1d96c1  vmovaps [rsp+0x40], xmm5
0000785dab1d96c7  vmovaps [rsp+0x50], xmm6
0000785dab1d96cd  vmovaps [rsp+0x60], xmm7
0000785dab1d96d3  vmovaps [rsp+0x70], xmm8
0000785dab1d96d9  vmovaps [rsp+0x80], xmm9
0000785dab1d96e2  vmovaps [rsp+0x90], xmm10
0000785dab1d96eb  vmovaps [rsp+0xA0], xmm11
0000785dab1d96f4  vmovaps [rsp+0xB0], xmm12
0000785dab1d96fd  vmovaps [rsp+0xC0], xmm13
0000785dab1d9706  vmovaps [rsp+0xD0], xmm14
0000785dab1d970f  vmovaps [rsp+0xE0], xmm15
0000785dab1d9718  sub rsp, 0x30
0000785dab1d971c  movaps [rsp], xmm4
0000785dab1d9720  movaps [rsp+0x10], xmm13
0000785dab1d9726  movaps [rsp+0x20], xmm8
0000785dab1d972c  lea rdi, [rsp]
0000785dab1d9730  mov esi, 0x00
0000785dab1d9735  mov rax, 0x61B13BBD6530
0000785dab1d973f  call rax
0000785dab1d9741  movaps xmm4, [rsp]
0000785dab1d9745  add rsp, 0x30
0000785dab1d9749  vmovaps xmm0, [rsp]
0000785dab1d974e  vmovaps xmm1, [rsp+0x10]
0000785dab1d9754  vmovaps xmm2, [rsp+0x20]
0000785dab1d975a  vmovaps xmm3, [rsp+0x30]
0000785dab1d9760  vmovaps xmm5, [rsp+0x40]
0000785dab1d9766  vmovaps xmm6, [rsp+0x50]
0000785dab1d976c  vmovaps xmm7, [rsp+0x60]
0000785dab1d9772  vmovaps xmm8, [rsp+0x70]
0000785dab1d9778  vmovaps xmm9, [rsp+0x80]
0000785dab1d9781  vmovaps xmm10, [rsp+0x90]
0000785dab1d978a  vmovaps xmm11, [rsp+0xA0]
0000785dab1d9793  vmovaps xmm12, [rsp+0xB0]
0000785dab1d979c  vmovaps xmm13, [rsp+0xC0]
0000785dab1d97a5  vmovaps xmm14, [rsp+0xD0]
0000785dab1d97ae  vmovaps xmm15, [rsp+0xE0]
0000785dab1d97b7  add rsp, 0xF0
0000785dab1d97be  pop r11
0000785dab1d97c0  pop r10
0000785dab1d97c2  pop r9
0000785dab1d97c4  pop r8
0000785dab1d97c6  pop rsi
0000785dab1d97c7  pop rdi
0000785dab1d97c8  pop rdx
0000785dab1d97c9  pop rcx
0000785dab1d97ca  pop rax
0000785dab1d97cb  add rsp, 0x08
0000785dab1d97cf  jmp 0x0000785DAB1D628A
0000785dab1d97d4  sub rsp, 0x08
0000785dab1d97d8  push rax
0000785dab1d97d9  push rcx
0000785dab1d97da  push rdx
0000785dab1d97db  push rdi
0000785dab1d97dc  push rsi
0000785dab1d97dd  push r8
0000785dab1d97df  push r9
0000785dab1d97e1  push r10
0000785dab1d97e3  push r11
0000785dab1d97e5  sub rsp, 0xF0
0000785dab1d97ec  vmovaps [rsp], xmm0
0000785dab1d97f1  vmovaps [rsp+0x10], xmm1
0000785dab1d97f7  vmovaps [rsp+0x20], xmm2
0000785dab1d97fd  vmovaps [rsp+0x30], xmm3
0000785dab1d9803  vmovaps [rsp+0x40], xmm4
0000785dab1d9809  vmovaps [rsp+0x50], xmm5
0000785dab1d980f  vmovaps [rsp+0x60], xmm6
0000785dab1d9815  vmovaps [rsp+0x70], xmm7
0000785dab1d981b  vmovaps [rsp+0x80], xmm8
0000785dab1d9824  vmovaps [rsp+0x90], xmm9
0000785dab1d982d  vmovaps [rsp+0xA0], xmm10
0000785dab1d9836  vmovaps [rsp+0xB0], xmm11
0000785dab1d983f  vmovaps [rsp+0xC0], xmm12
0000785dab1d9848  vmovaps [rsp+0xD0], xmm14
0000785dab1d9851  vmovaps [rsp+0xE0], xmm15
0000785dab1d985a  sub rsp, 0x30
0000785dab1d985e  movaps [rsp], xmm13
0000785dab1d9863  movaps [rsp+0x10], xmm15
0000785dab1d9869  movaps [rsp+0x20], xmm9
0000785dab1d986f  lea rdi, [rsp]
0000785dab1d9873  mov esi, 0x00
0000785dab1d9878  mov rax, 0x61B13BBD6530
0000785dab1d9882  call rax
0000785dab1d9884  movaps xmm13, [rsp]
0000785dab1d9889  add rsp, 0x30
0000785dab1d988d  vmovaps xmm0, [rsp]
0000785dab1d9892  vmovaps xmm1, [rsp+0x10]
0000785dab1d9898  vmovaps xmm2, [rsp+0x20]
0000785dab1d989e  vmovaps xmm3, [rsp+0x30]
0000785dab1d98a4  vmovaps xmm4, [rsp+0x40]
0000785dab1d98aa  vmovaps xmm5, [rsp+0x50]
0000785dab1d98b0  vmovaps xmm6, [rsp+0x60]
0000785dab1d98b6  vmovaps xmm7, [rsp+0x70]
0000785dab1d98bc  vmovaps xmm8, [rsp+0x80]
0000785dab1d98c5  vmovaps xmm9, [rsp+0x90]
0000785dab1d98ce  vmovaps xmm10, [rsp+0xA0]
0000785dab1d98d7  vmovaps xmm11, [rsp+0xB0]
0000785dab1d98e0  vmovaps xmm12, [rsp+0xC0]
0000785dab1d98e9  vmovaps xmm14, [rsp+0xD0]
0000785dab1d98f2  vmovaps xmm15, [rsp+0xE0]
0000785dab1d98fb  add rsp, 0xF0
0000785dab1d9902  pop r11
0000785dab1d9904  pop r10
0000785dab1d9906  pop r9
0000785dab1d9908  pop r8
0000785dab1d990a  pop rsi
0000785dab1d990b  pop rdi
0000785dab1d990c  pop rdx
0000785dab1d990d  pop rcx
0000785dab1d990e  pop rax
0000785dab1d990f  add rsp, 0x08
0000785dab1d9913  jmp 0x0000785DAB1D62A5
0000785dab1d9918  sub rsp, 0x08
0000785dab1d991c  push rax
0000785dab1d991d  push rcx
0000785dab1d991e  push rdx
0000785dab1d991f  push rdi
0000785dab1d9920  push rsi
0000785dab1d9921  push r8
0000785dab1d9923  push r9
0000785dab1d9925  push r10
0000785dab1d9927  push r11
0000785dab1d9929  sub rsp, 0xF0
0000785dab1d9930  vmovaps [rsp], xmm0
0000785dab1d9935  vmovaps [rsp+0x10], xmm1
0000785dab1d993b  vmovaps [rsp+0x20], xmm2
0000785dab1d9941  vmovaps [rsp+0x30], xmm3
0000785dab1d9947  vmovaps [rsp+0x40], xmm4
0000785dab1d994d  vmovaps [rsp+0x50], xmm5
0000785dab1d9953  vmovaps [rsp+0x60], xmm6
0000785dab1d9959  vmovaps [rsp+0x70], xmm7
0000785dab1d995f  vmovaps [rsp+0x80], xmm8
0000785dab1d9968  vmovaps [rsp+0x90], xmm9
0000785dab1d9971  vmovaps [rsp+0xA0], xmm10
0000785dab1d997a  vmovaps [rsp+0xB0], xmm11
0000785dab1d9983  vmovaps [rsp+0xC0], xmm12
0000785dab1d998c  vmovaps [rsp+0xD0], xmm13
0000785dab1d9995  vmovaps [rsp+0xE0], xmm14
0000785dab1d999e  sub rsp, 0x30
0000785dab1d99a2  movaps [rsp], xmm15
0000785dab1d99a7  movaps [rsp+0x10], xmm1
0000785dab1d99ac  movaps [rsp+0x20], xmm5
0000785dab1d99b1  lea rdi, [rsp]
0000785dab1d99b5  mov esi, 0x00
0000785dab1d99ba  mov rax, 0x61B13BBD6530
0000785dab1d99c4  call rax
0000785dab1d99c6  movaps xmm15, [rsp]
0000785dab1d99cb  add rsp, 0x30
0000785dab1d99cf  vmovaps xmm0, [rsp]
0000785dab1d99d4  vmovaps xmm1, [rsp+0x10]
0000785dab1d99da  vmovaps xmm2, [rsp+0x20]
0000785dab1d99e0  vmovaps xmm3, [rsp+0x30]
0000785dab1d99e6  vmovaps xmm4, [rsp+0x40]
0000785dab1d99ec  vmovaps xmm5, [rsp+0x50]
0000785dab1d99f2  vmovaps xmm6, [rsp+0x60]
0000785dab1d99f8  vmovaps xmm7, [rsp+0x70]
0000785dab1d99fe  vmovaps xmm8, [rsp+0x80]
0000785dab1d9a07  vmovaps xmm9, [rsp+0x90]
0000785dab1d9a10  vmovaps xmm10, [rsp+0xA0]
0000785dab1d9a19  vmovaps xmm11, [rsp+0xB0]
0000785dab1d9a22  vmovaps xmm12, [rsp+0xC0]
0000785dab1d9a2b  vmovaps xmm13, [rsp+0xD0]
0000785dab1d9a34  vmovaps xmm14, [rsp+0xE0]
0000785dab1d9a3d  add rsp, 0xF0
0000785dab1d9a44  pop r11
0000785dab1d9a46  pop r10
0000785dab1d9a48  pop r9
0000785dab1d9a4a  pop r8
0000785dab1d9a4c  pop rsi
0000785dab1d9a4d  pop rdi
0000785dab1d9a4e  pop rdx
0000785dab1d9a4f  pop rcx
0000785dab1d9a50  pop rax
0000785dab1d9a51  add rsp, 0x08
0000785dab1d9a55  jmp 0x0000785DAB1D62C0
0000785dab1d9a5a  call 0x0000785DAB0D64F0
0000785dab1d9a5f  jmp 0x0000785DAB1D631B
0000785dab1d9a64  sub rsp, 0x08
0000785dab1d9a68  push rax
0000785dab1d9a69  push rcx
0000785dab1d9a6a  push rdx
0000785dab1d9a6b  push rdi
0000785dab1d9a6c  push rsi
0000785dab1d9a6d  push r8
0000785dab1d9a6f  push r9
0000785dab1d9a71  push r10
0000785dab1d9a73  push r11
0000785dab1d9a75  sub rsp, 0xF0
0000785dab1d9a7c  vmovaps [rsp], xmm0
0000785dab1d9a81  vmovaps [rsp+0x10], xmm1
0000785dab1d9a87  vmovaps [rsp+0x20], xmm2
0000785dab1d9a8d  vmovaps [rsp+0x30], xmm3
0000785dab1d9a93  vmovaps [rsp+0x40], xmm4
0000785dab1d9a99  vmovaps [rsp+0x50], xmm5
0000785dab1d9a9f  vmovaps [rsp+0x60], xmm6
0000785dab1d9aa5  vmovaps [rsp+0x70], xmm7
0000785dab1d9aab  vmovaps [rsp+0x80], xmm8
0000785dab1d9ab4  vmovaps [rsp+0x90], xmm10
0000785dab1d9abd  vmovaps [rsp+0xA0], xmm11
0000785dab1d9ac6  vmovaps [rsp+0xB0], xmm12
0000785dab1d9acf  vmovaps [rsp+0xC0], xmm13
0000785dab1d9ad8  vmovaps [rsp+0xD0], xmm14
0000785dab1d9ae1  vmovaps [rsp+0xE0], xmm15
0000785dab1d9aea  sub rsp, 0x30
0000785dab1d9aee  movaps [rsp], xmm9
0000785dab1d9af3  movaps [rsp+0x10], xmm8
0000785dab1d9af9  movaps [rsp+0x20], xmm11
0000785dab1d9aff  lea rdi, [rsp]
0000785dab1d9b03  mov esi, 0x00
0000785dab1d9b08  mov rax, 0x61B13BBD6530
0000785dab1d9b12  call rax
0000785dab1d9b14  movaps xmm9, [rsp]
0000785dab1d9b19  add rsp, 0x30
0000785dab1d9b1d  vmovaps xmm0, [rsp]
0000785dab1d9b22  vmovaps xmm1, [rsp+0x10]
0000785dab1d9b28  vmovaps xmm2, [rsp+0x20]
0000785dab1d9b2e  vmovaps xmm3, [rsp+0x30]
0000785dab1d9b34  vmovaps xmm4, [rsp+0x40]
0000785dab1d9b3a  vmovaps xmm5, [rsp+0x50]
0000785dab1d9b40  vmovaps xmm6, [rsp+0x60]
0000785dab1d9b46  vmovaps xmm7, [rsp+0x70]
0000785dab1d9b4c  vmovaps xmm8, [rsp+0x80]
0000785dab1d9b55  vmovaps xmm10, [rsp+0x90]
0000785dab1d9b5e  vmovaps xmm11, [rsp+0xA0]
0000785dab1d9b67  vmovaps xmm12, [rsp+0xB0]
0000785dab1d9b70  vmovaps xmm13, [rsp+0xC0]
0000785dab1d9b79  vmovaps xmm14, [rsp+0xD0]
0000785dab1d9b82  vmovaps xmm15, [rsp+0xE0]
0000785dab1d9b8b  add rsp, 0xF0
0000785dab1d9b92  pop r11
0000785dab1d9b94  pop r10
0000785dab1d9b96  pop r9
0000785dab1d9b98  pop r8
0000785dab1d9b9a  pop rsi
0000785dab1d9b9b  pop rdi
0000785dab1d9b9c  pop rdx
0000785dab1d9b9d  pop rcx
0000785dab1d9b9e  pop rax
0000785dab1d9b9f  add rsp, 0x08
0000785dab1d9ba3  jmp 0x0000785DAB1D6352
0000785dab1d9ba8  sub rsp, 0x08
0000785dab1d9bac  push rax
0000785dab1d9bad  push rcx
0000785dab1d9bae  push rdx
0000785dab1d9baf  push rdi
0000785dab1d9bb0  push rsi
0000785dab1d9bb1  push r8
0000785dab1d9bb3  push r9
0000785dab1d9bb5  push r10
0000785dab1d9bb7  push r11
0000785dab1d9bb9  sub rsp, 0xF0
0000785dab1d9bc0  vmovaps [rsp], xmm0
0000785dab1d9bc5  vmovaps [rsp+0x10], xmm1
0000785dab1d9bcb  vmovaps [rsp+0x20], xmm2
0000785dab1d9bd1  vmovaps [rsp+0x30], xmm3
0000785dab1d9bd7  vmovaps [rsp+0x40], xmm4
0000785dab1d9bdd  vmovaps [rsp+0x50], xmm5
0000785dab1d9be3  vmovaps [rsp+0x60], xmm6
0000785dab1d9be9  vmovaps [rsp+0x70], xmm7
0000785dab1d9bef  vmovaps [rsp+0x80], xmm8
0000785dab1d9bf8  vmovaps [rsp+0x90], xmm9
0000785dab1d9c01  vmovaps [rsp+0xA0], xmm10
0000785dab1d9c0a  vmovaps [rsp+0xB0], xmm12
0000785dab1d9c13  vmovaps [rsp+0xC0], xmm13
0000785dab1d9c1c  vmovaps [rsp+0xD0], xmm14
0000785dab1d9c25  vmovaps [rsp+0xE0], xmm15
0000785dab1d9c2e  sub rsp, 0x30
0000785dab1d9c32  movaps [rsp], xmm11
0000785dab1d9c37  movaps [rsp+0x10], xmm10
0000785dab1d9c3d  movaps [rsp+0x20], xmm6
0000785dab1d9c42  lea rdi, [rsp]
0000785dab1d9c46  mov esi, 0x00
0000785dab1d9c4b  mov rax, 0x61B13BBD6530
0000785dab1d9c55  call rax
0000785dab1d9c57  movaps xmm11, [rsp]
0000785dab1d9c5c  add rsp, 0x30
0000785dab1d9c60  vmovaps xmm0, [rsp]
0000785dab1d9c65  vmovaps xmm1, [rsp+0x10]
0000785dab1d9c6b  vmovaps xmm2, [rsp+0x20]
0000785dab1d9c71  vmovaps xmm3, [rsp+0x30]
0000785dab1d9c77  vmovaps xmm4, [rsp+0x40]
0000785dab1d9c7d  vmovaps xmm5, [rsp+0x50]
0000785dab1d9c83  vmovaps xmm6, [rsp+0x60]
0000785dab1d9c89  vmovaps xmm7, [rsp+0x70]
0000785dab1d9c8f  vmovaps xmm8, [rsp+0x80]
0000785dab1d9c98  vmovaps xmm9, [rsp+0x90]
0000785dab1d9ca1  vmovaps xmm10, [rsp+0xA0]
0000785dab1d9caa  vmovaps xmm12, [rsp+0xB0]
0000785dab1d9cb3  vmovaps xmm13, [rsp+0xC0]
0000785dab1d9cbc  vmovaps xmm14, [rsp+0xD0]
0000785dab1d9cc5  vmovaps xmm15, [rsp+0xE0]
0000785dab1d9cce  add rsp, 0xF0
0000785dab1d9cd5  pop r11
0000785dab1d9cd7  pop r10
0000785dab1d9cd9  pop r9
0000785dab1d9cdb  pop r8
0000785dab1d9cdd  pop rsi
0000785dab1d9cde  pop rdi
0000785dab1d9cdf  pop rdx
0000785dab1d9ce0  pop rcx
0000785dab1d9ce1  pop rax
0000785dab1d9ce2  add rsp, 0x08
0000785dab1d9ce6  jmp 0x0000785DAB1D636D
0000785dab1d9ceb  sub rsp, 0x08
0000785dab1d9cef  push rax
0000785dab1d9cf0  push rcx
0000785dab1d9cf1  push rdx
0000785dab1d9cf2  push rdi
0000785dab1d9cf3  push rsi
0000785dab1d9cf4  push r8
0000785dab1d9cf6  push r9
0000785dab1d9cf8  push r10
0000785dab1d9cfa  push r11
0000785dab1d9cfc  sub rsp, 0xF0
0000785dab1d9d03  vmovaps [rsp], xmm0
0000785dab1d9d08  vmovaps [rsp+0x10], xmm1
0000785dab1d9d0e  vmovaps [rsp+0x20], xmm2
0000785dab1d9d14  vmovaps [rsp+0x30], xmm3
0000785dab1d9d1a  vmovaps [rsp+0x40], xmm4
0000785dab1d9d20  vmovaps [rsp+0x50], xmm5
0000785dab1d9d26  vmovaps [rsp+0x60], xmm6
0000785dab1d9d2c  vmovaps [rsp+0x70], xmm7
0000785dab1d9d32  vmovaps [rsp+0x80], xmm8
0000785dab1d9d3b  vmovaps [rsp+0x90], xmm9
0000785dab1d9d44  vmovaps [rsp+0xA0], xmm11
0000785dab1d9d4d  vmovaps [rsp+0xB0], xmm12
0000785dab1d9d56  vmovaps [rsp+0xC0], xmm13
0000785dab1d9d5f  vmovaps [rsp+0xD0], xmm14
0000785dab1d9d68  vmovaps [rsp+0xE0], xmm15
0000785dab1d9d71  sub rsp, 0x30
0000785dab1d9d75  movaps [rsp], xmm10
0000785dab1d9d7a  movaps [rsp+0x10], xmm14
0000785dab1d9d80  movaps [rsp+0x20], xmm4
0000785dab1d9d85  lea rdi, [rsp]
0000785dab1d9d89  mov esi, 0x00
0000785dab1d9d8e  mov rax, 0x61B13BBD6530
0000785dab1d9d98  call rax
0000785dab1d9d9a  movaps xmm10, [rsp]
0000785dab1d9d9f  add rsp, 0x30
0000785dab1d9da3  vmovaps xmm0, [rsp]
0000785dab1d9da8  vmovaps xmm1, [rsp+0x10]
0000785dab1d9dae  vmovaps xmm2, [rsp+0x20]
0000785dab1d9db4  vmovaps xmm3, [rsp+0x30]
0000785dab1d9dba  vmovaps xmm4, [rsp+0x40]
0000785dab1d9dc0  vmovaps xmm5, [rsp+0x50]
0000785dab1d9dc6  vmovaps xmm6, [rsp+0x60]
0000785dab1d9dcc  vmovaps xmm7, [rsp+0x70]
0000785dab1d9dd2  vmovaps xmm8, [rsp+0x80]
0000785dab1d9ddb  vmovaps xmm9, [rsp+0x90]
0000785dab1d9de4  vmovaps xmm11, [rsp+0xA0]
0000785dab1d9ded  vmovaps xmm12, [rsp+0xB0]
0000785dab1d9df6  vmovaps xmm13, [rsp+0xC0]
0000785dab1d9dff  vmovaps xmm14, [rsp+0xD0]
0000785dab1d9e08  vmovaps xmm15, [rsp+0xE0]
0000785dab1d9e11  add rsp, 0xF0
0000785dab1d9e18  pop r11
0000785dab1d9e1a  pop r10
0000785dab1d9e1c  pop r9
0000785dab1d9e1e  pop r8
0000785dab1d9e20  pop rsi
0000785dab1d9e21  pop rdi
0000785dab1d9e22  pop rdx
0000785dab1d9e23  pop rcx
0000785dab1d9e24  pop rax
0000785dab1d9e25  add rsp, 0x08
0000785dab1d9e29  jmp 0x0000785DAB1D6388
0000785dab1d9e2e  sub rsp, 0x08
0000785dab1d9e32  push rax
0000785dab1d9e33  push rcx
0000785dab1d9e34  push rdx
0000785dab1d9e35  push rdi
0000785dab1d9e36  push rsi
0000785dab1d9e37  push r8
0000785dab1d9e39  push r9
0000785dab1d9e3b  push r10
0000785dab1d9e3d  push r11
0000785dab1d9e3f  sub rsp, 0xF0
0000785dab1d9e46  vmovaps [rsp], xmm0
0000785dab1d9e4b  vmovaps [rsp+0x10], xmm1
0000785dab1d9e51  vmovaps [rsp+0x20], xmm2
0000785dab1d9e57  vmovaps [rsp+0x30], xmm3
0000785dab1d9e5d  vmovaps [rsp+0x40], xmm4
0000785dab1d9e63  vmovaps [rsp+0x50], xmm5
0000785dab1d9e69  vmovaps [rsp+0x60], xmm6
0000785dab1d9e6f  vmovaps [rsp+0x70], xmm7
0000785dab1d9e75  vmovaps [rsp+0x80], xmm9
0000785dab1d9e7e  vmovaps [rsp+0x90], xmm10
0000785dab1d9e87  vmovaps [rsp+0xA0], xmm11
0000785dab1d9e90  vmovaps [rsp+0xB0], xmm12
0000785dab1d9e99  vmovaps [rsp+0xC0], xmm13
0000785dab1d9ea2  vmovaps [rsp+0xD0], xmm14
0000785dab1d9eab  vmovaps [rsp+0xE0], xmm15
0000785dab1d9eb4  sub rsp, 0x30
0000785dab1d9eb8  movaps [rsp], xmm8
0000785dab1d9ebd  movaps [rsp+0x10], xmm1
0000785dab1d9ec2  movaps [rsp+0x20], xmm14
0000785dab1d9ec8  lea rdi, [rsp]
0000785dab1d9ecc  mov esi, 0x00
0000785dab1d9ed1  mov rax, 0x61B13BBD6530
0000785dab1d9edb  call rax
0000785dab1d9edd  movaps xmm8, [rsp]
0000785dab1d9ee2  add rsp, 0x30
0000785dab1d9ee6  vmovaps xmm0, [rsp]
0000785dab1d9eeb  vmovaps xmm1, [rsp+0x10]
0000785dab1d9ef1  vmovaps xmm2, [rsp+0x20]
0000785dab1d9ef7  vmovaps xmm3, [rsp+0x30]
0000785dab1d9efd  vmovaps xmm4, [rsp+0x40]
0000785dab1d9f03  vmovaps xmm5, [rsp+0x50]
0000785dab1d9f09  vmovaps xmm6, [rsp+0x60]
0000785dab1d9f0f  vmovaps xmm7, [rsp+0x70]
0000785dab1d9f15  vmovaps xmm9, [rsp+0x80]
0000785dab1d9f1e  vmovaps xmm10, [rsp+0x90]
0000785dab1d9f27  vmovaps xmm11, [rsp+0xA0]
0000785dab1d9f30  vmovaps xmm12, [rsp+0xB0]
0000785dab1d9f39  vmovaps xmm13, [rsp+0xC0]
0000785dab1d9f42  vmovaps xmm14, [rsp+0xD0]
0000785dab1d9f4b  vmovaps xmm15, [rsp+0xE0]
0000785dab1d9f54  add rsp, 0xF0
0000785dab1d9f5b  pop r11
0000785dab1d9f5d  pop r10
0000785dab1d9f5f  pop r9
0000785dab1d9f61  pop r8
0000785dab1d9f63  pop rsi
0000785dab1d9f64  pop rdi
0000785dab1d9f65  pop rdx
0000785dab1d9f66  pop rcx
0000785dab1d9f67  pop rax
0000785dab1d9f68  add rsp, 0x08
0000785dab1d9f6c  jmp 0x0000785DAB1D63AE
0000785dab1d9f71  sub rsp, 0x08
0000785dab1d9f75  push rax
0000785dab1d9f76  push rcx
0000785dab1d9f77  push rdx
0000785dab1d9f78  push rdi
0000785dab1d9f79  push rsi
0000785dab1d9f7a  push r8
0000785dab1d9f7c  push r9
0000785dab1d9f7e  push r10
0000785dab1d9f80  push r11
0000785dab1d9f82  sub rsp, 0xF0
0000785dab1d9f89  vmovaps [rsp], xmm0
0000785dab1d9f8e  vmovaps [rsp+0x10], xmm1
0000785dab1d9f94  vmovaps [rsp+0x20], xmm2
0000785dab1d9f9a  vmovaps [rsp+0x30], xmm3
0000785dab1d9fa0  vmovaps [rsp+0x40], xmm4
0000785dab1d9fa6  vmovaps [rsp+0x50], xmm5
0000785dab1d9fac  vmovaps [rsp+0x60], xmm7
0000785dab1d9fb2  vmovaps [rsp+0x70], xmm8
0000785dab1d9fb8  vmovaps [rsp+0x80], xmm9
0000785dab1d9fc1  vmovaps [rsp+0x90], xmm10
0000785dab1d9fca  vmovaps [rsp+0xA0], xmm11
0000785dab1d9fd3  vmovaps [rsp+0xB0], xmm12
0000785dab1d9fdc  vmovaps [rsp+0xC0], xmm13
0000785dab1d9fe5  vmovaps [rsp+0xD0], xmm14
0000785dab1d9fee  vmovaps [rsp+0xE0], xmm15
0000785dab1d9ff7  sub rsp, 0x30
0000785dab1d9ffb  movaps [rsp], xmm6
0000785dab1d9fff  movaps [rsp+0x10], xmm1
0000785dab1da004  movaps [rsp+0x20], xmm14
0000785dab1da00a  lea rdi, [rsp]
0000785dab1da00e  mov esi, 0x00
0000785dab1da013  mov rax, 0x61B13BBD6530
0000785dab1da01d  call rax
0000785dab1da01f  movaps xmm6, [rsp]
0000785dab1da023  add rsp, 0x30
0000785dab1da027  vmovaps xmm0, [rsp]
0000785dab1da02c  vmovaps xmm1, [rsp+0x10]
0000785dab1da032  vmovaps xmm2, [rsp+0x20]
0000785dab1da038  vmovaps xmm3, [rsp+0x30]
0000785dab1da03e  vmovaps xmm4, [rsp+0x40]
0000785dab1da044  vmovaps xmm5, [rsp+0x50]
0000785dab1da04a  vmovaps xmm7, [rsp+0x60]
0000785dab1da050  vmovaps xmm8, [rsp+0x70]
0000785dab1da056  vmovaps xmm9, [rsp+0x80]
0000785dab1da05f  vmovaps xmm10, [rsp+0x90]
0000785dab1da068  vmovaps xmm11, [rsp+0xA0]
0000785dab1da071  vmovaps xmm12, [rsp+0xB0]
0000785dab1da07a  vmovaps xmm13, [rsp+0xC0]
0000785dab1da083  vmovaps xmm14, [rsp+0xD0]
0000785dab1da08c  vmovaps xmm15, [rsp+0xE0]
0000785dab1da095  add rsp, 0xF0
0000785dab1da09c  pop r11
0000785dab1da09e  pop r10
0000785dab1da0a0  pop r9
0000785dab1da0a2  pop r8
0000785dab1da0a4  pop rsi
0000785dab1da0a5  pop rdi
0000785dab1da0a6  pop rdx
0000785dab1da0a7  pop rcx
0000785dab1da0a8  pop rax
0000785dab1da0a9  add rsp, 0x08
0000785dab1da0ad  jmp 0x0000785DAB1D63DA
0000785dab1da0b2  sub rsp, 0x08
0000785dab1da0b6  push rax
0000785dab1da0b7  push rcx
0000785dab1da0b8  push rdx
0000785dab1da0b9  push rdi
0000785dab1da0ba  push rsi
0000785dab1da0bb  push r8
0000785dab1da0bd  push r9
0000785dab1da0bf  push r10
0000785dab1da0c1  push r11
0000785dab1da0c3  sub rsp, 0xF0
0000785dab1da0ca  vmovaps [rsp], xmm0
0000785dab1da0cf  vmovaps [rsp+0x10], xmm1
0000785dab1da0d5  vmovaps [rsp+0x20], xmm2
0000785dab1da0db  vmovaps [rsp+0x30], xmm3
0000785dab1da0e1  vmovaps [rsp+0x40], xmm4
0000785dab1da0e7  vmovaps [rsp+0x50], xmm5
0000785dab1da0ed  vmovaps [rsp+0x60], xmm6
0000785dab1da0f3  vmovaps [rsp+0x70], xmm7
0000785dab1da0f9  vmovaps [rsp+0x80], xmm8
0000785dab1da102  vmovaps [rsp+0x90], xmm9
0000785dab1da10b  vmovaps [rsp+0xA0], xmm10
0000785dab1da114  vmovaps [rsp+0xB0], xmm11
0000785dab1da11d  vmovaps [rsp+0xC0], xmm12
0000785dab1da126  vmovaps [rsp+0xD0], xmm13
0000785dab1da12f  vmovaps [rsp+0xE0], xmm15
0000785dab1da138  sub rsp, 0x30
0000785dab1da13c  movaps [rsp], xmm14
0000785dab1da141  movaps [rsp+0x10], xmm12
0000785dab1da147  movaps [rsp+0x20], xmm1
0000785dab1da14c  lea rdi, [rsp]
0000785dab1da150  mov esi, 0x00
0000785dab1da155  mov rax, 0x61B13BBD6530
0000785dab1da15f  call rax
0000785dab1da161  movaps xmm14, [rsp]
0000785dab1da166  add rsp, 0x30
0000785dab1da16a  vmovaps xmm0, [rsp]
0000785dab1da16f  vmovaps xmm1, [rsp+0x10]
0000785dab1da175  vmovaps xmm2, [rsp+0x20]
0000785dab1da17b  vmovaps xmm3, [rsp+0x30]
0000785dab1da181  vmovaps xmm4, [rsp+0x40]
0000785dab1da187  vmovaps xmm5, [rsp+0x50]
0000785dab1da18d  vmovaps xmm6, [rsp+0x60]
0000785dab1da193  vmovaps xmm7, [rsp+0x70]
0000785dab1da199  vmovaps xmm8, [rsp+0x80]
0000785dab1da1a2  vmovaps xmm9, [rsp+0x90]
0000785dab1da1ab  vmovaps xmm10, [rsp+0xA0]
0000785dab1da1b4  vmovaps xmm11, [rsp+0xB0]
0000785dab1da1bd  vmovaps xmm12, [rsp+0xC0]
0000785dab1da1c6  vmovaps xmm13, [rsp+0xD0]
0000785dab1da1cf  vmovaps xmm15, [rsp+0xE0]
0000785dab1da1d8  add rsp, 0xF0
0000785dab1da1df  pop r11
0000785dab1da1e1  pop r10
0000785dab1da1e3  pop r9
0000785dab1da1e5  pop r8
0000785dab1da1e7  pop rsi
0000785dab1da1e8  pop rdi
0000785dab1da1e9  pop rdx
0000785dab1da1ea  pop rcx
0000785dab1da1eb  pop rax
0000785dab1da1ec  add rsp, 0x08
0000785dab1da1f0  jmp 0x0000785DAB1D6400
0000785dab1da1f5  sub rsp, 0x08
0000785dab1da1f9  push rax
0000785dab1da1fa  push rcx
0000785dab1da1fb  push rdx
0000785dab1da1fc  push rdi
0000785dab1da1fd  push rsi
0000785dab1da1fe  push r8
0000785dab1da200  push r9
0000785dab1da202  push r10
0000785dab1da204  push r11
0000785dab1da206  sub rsp, 0xF0
0000785dab1da20d  vmovaps [rsp], xmm0
0000785dab1da212  vmovaps [rsp+0x10], xmm2
0000785dab1da218  vmovaps [rsp+0x20], xmm3
0000785dab1da21e  vmovaps [rsp+0x30], xmm4
0000785dab1da224  vmovaps [rsp+0x40], xmm5
0000785dab1da22a  vmovaps [rsp+0x50], xmm6
0000785dab1da230  vmovaps [rsp+0x60], xmm7
0000785dab1da236  vmovaps [rsp+0x70], xmm8
0000785dab1da23c  vmovaps [rsp+0x80], xmm9
0000785dab1da245  vmovaps [rsp+0x90], xmm10
0000785dab1da24e  vmovaps [rsp+0xA0], xmm11
0000785dab1da257  vmovaps [rsp+0xB0], xmm12
0000785dab1da260  vmovaps [rsp+0xC0], xmm13
0000785dab1da269  vmovaps [rsp+0xD0], xmm14
0000785dab1da272  vmovaps [rsp+0xE0], xmm15
0000785dab1da27b  sub rsp, 0x30
0000785dab1da27f  movaps [rsp], xmm1
0000785dab1da283  movaps [rsp+0x10], xmm13
0000785dab1da289  movaps [rsp+0x20], xmm9
0000785dab1da28f  lea rdi, [rsp]
0000785dab1da293  mov esi, 0x00
0000785dab1da298  mov rax, 0x61B13BBD6530
0000785dab1da2a2  call rax
0000785dab1da2a4  movaps xmm1, [rsp]
0000785dab1da2a8  add rsp, 0x30
0000785dab1da2ac  vmovaps xmm0, [rsp]
0000785dab1da2b1  vmovaps xmm2, [rsp+0x10]
0000785dab1da2b7  vmovaps xmm3, [rsp+0x20]
0000785dab1da2bd  vmovaps xmm4, [rsp+0x30]
0000785dab1da2c3  vmovaps xmm5, [rsp+0x40]
0000785dab1da2c9  vmovaps xmm6, [rsp+0x50]
0000785dab1da2cf  vmovaps xmm7, [rsp+0x60]
0000785dab1da2d5  vmovaps xmm8, [rsp+0x70]
0000785dab1da2db  vmovaps xmm9, [rsp+0x80]
0000785dab1da2e4  vmovaps xmm10, [rsp+0x90]
0000785dab1da2ed  vmovaps xmm11, [rsp+0xA0]
0000785dab1da2f6  vmovaps xmm12, [rsp+0xB0]
0000785dab1da2ff  vmovaps xmm13, [rsp+0xC0]
0000785dab1da308  vmovaps xmm14, [rsp+0xD0]
0000785dab1da311  vmovaps xmm15, [rsp+0xE0]
0000785dab1da31a  add rsp, 0xF0
0000785dab1da321  pop r11
0000785dab1da323  pop r10
0000785dab1da325  pop r9
0000785dab1da327  pop r8
0000785dab1da329  pop rsi
0000785dab1da32a  pop rdi
0000785dab1da32b  pop rdx
0000785dab1da32c  pop rcx
0000785dab1da32d  pop rax
0000785dab1da32e  add rsp, 0x08
0000785dab1da332  jmp 0x0000785DAB1D641A
0000785dab1da337  sub rsp, 0x08
0000785dab1da33b  push rax
0000785dab1da33c  push rcx
0000785dab1da33d  push rdx
0000785dab1da33e  push rdi
0000785dab1da33f  push rsi
0000785dab1da340  push r8
0000785dab1da342  push r9
0000785dab1da344  push r10
0000785dab1da346  push r11
0000785dab1da348  sub rsp, 0xF0
0000785dab1da34f  vmovaps [rsp], xmm0
0000785dab1da354  vmovaps [rsp+0x10], xmm1
0000785dab1da35a  vmovaps [rsp+0x20], xmm2
0000785dab1da360  vmovaps [rsp+0x30], xmm3
0000785dab1da366  vmovaps [rsp+0x40], xmm4
0000785dab1da36c  vmovaps [rsp+0x50], xmm5
0000785dab1da372  vmovaps [rsp+0x60], xmm6
0000785dab1da378  vmovaps [rsp+0x70], xmm7
0000785dab1da37e  vmovaps [rsp+0x80], xmm8
0000785dab1da387  vmovaps [rsp+0x90], xmm9
0000785dab1da390  vmovaps [rsp+0xA0], xmm10
0000785dab1da399  vmovaps [rsp+0xB0], xmm11
0000785dab1da3a2  vmovaps [rsp+0xC0], xmm13
0000785dab1da3ab  vmovaps [rsp+0xD0], xmm14
0000785dab1da3b4  vmovaps [rsp+0xE0], xmm15
0000785dab1da3bd  sub rsp, 0x30
0000785dab1da3c1  movaps [rsp], xmm12
0000785dab1da3c6  movaps [rsp+0x10], xmm7
0000785dab1da3cb  movaps [rsp+0x20], xmm13
0000785dab1da3d1  lea rdi, [rsp]
0000785dab1da3d5  mov esi, 0x00
0000785dab1da3da  mov rax, 0x61B13BBD6530
0000785dab1da3e4  call rax
0000785dab1da3e6  movaps xmm12, [rsp]
0000785dab1da3eb  add rsp, 0x30
0000785dab1da3ef  vmovaps xmm0, [rsp]
0000785dab1da3f4  vmovaps xmm1, [rsp+0x10]
0000785dab1da3fa  vmovaps xmm2, [rsp+0x20]
0000785dab1da400  vmovaps xmm3, [rsp+0x30]
0000785dab1da406  vmovaps xmm4, [rsp+0x40]
0000785dab1da40c  vmovaps xmm5, [rsp+0x50]
0000785dab1da412  vmovaps xmm6, [rsp+0x60]
0000785dab1da418  vmovaps xmm7, [rsp+0x70]
0000785dab1da41e  vmovaps xmm8, [rsp+0x80]
0000785dab1da427  vmovaps xmm9, [rsp+0x90]
0000785dab1da430  vmovaps xmm10, [rsp+0xA0]
0000785dab1da439  vmovaps xmm11, [rsp+0xB0]
0000785dab1da442  vmovaps xmm13, [rsp+0xC0]
0000785dab1da44b  vmovaps xmm14, [rsp+0xD0]
0000785dab1da454  vmovaps xmm15, [rsp+0xE0]
0000785dab1da45d  add rsp, 0xF0
0000785dab1da464  pop r11
0000785dab1da466  pop r10
0000785dab1da468  pop r9
0000785dab1da46a  pop r8
0000785dab1da46c  pop rsi
0000785dab1da46d  pop rdi
0000785dab1da46e  pop rdx
0000785dab1da46f  pop rcx
0000785dab1da470  pop rax
0000785dab1da471  add rsp, 0x08
0000785dab1da475  jmp 0x0000785DAB1D6441
0000785dab1da47a  sub rsp, 0x08
0000785dab1da47e  push rax
0000785dab1da47f  push rcx
0000785dab1da480  push rdx
0000785dab1da481  push rdi
0000785dab1da482  push rsi
0000785dab1da483  push r8
0000785dab1da485  push r9
0000785dab1da487  push r10
0000785dab1da489  push r11
0000785dab1da48b  sub rsp, 0xF0
0000785dab1da492  vmovaps [rsp], xmm0
0000785dab1da497  vmovaps [rsp+0x10], xmm1
0000785dab1da49d  vmovaps [rsp+0x20], xmm2
0000785dab1da4a3  vmovaps [rsp+0x30], xmm3
0000785dab1da4a9  vmovaps [rsp+0x40], xmm4
0000785dab1da4af  vmovaps [rsp+0x50], xmm5
0000785dab1da4b5  vmovaps [rsp+0x60], xmm6
0000785dab1da4bb  vmovaps [rsp+0x70], xmm7
0000785dab1da4c1  vmovaps [rsp+0x80], xmm8
0000785dab1da4ca  vmovaps [rsp+0x90], xmm9
0000785dab1da4d3  vmovaps [rsp+0xA0], xmm10
0000785dab1da4dc  vmovaps [rsp+0xB0], xmm11
0000785dab1da4e5  vmovaps [rsp+0xC0], xmm12
0000785dab1da4ee  vmovaps [rsp+0xD0], xmm14
0000785dab1da4f7  vmovaps [rsp+0xE0], xmm15
0000785dab1da500  sub rsp, 0x30
0000785dab1da504  movaps [rsp], xmm13
0000785dab1da509  movaps [rsp+0x10], xmm15
0000785dab1da50f  movaps [rsp+0x20], xmm8
0000785dab1da515  lea rdi, [rsp]
0000785dab1da519  mov esi, 0x00
0000785dab1da51e  mov rax, 0x61B13BBD6530
0000785dab1da528  call rax
0000785dab1da52a  movaps xmm13, [rsp]
0000785dab1da52f  add rsp, 0x30
0000785dab1da533  vmovaps xmm0, [rsp]
0000785dab1da538  vmovaps xmm1, [rsp+0x10]
0000785dab1da53e  vmovaps xmm2, [rsp+0x20]
0000785dab1da544  vmovaps xmm3, [rsp+0x30]
0000785dab1da54a  vmovaps xmm4, [rsp+0x40]
0000785dab1da550  vmovaps xmm5, [rsp+0x50]
0000785dab1da556  vmovaps xmm6, [rsp+0x60]
0000785dab1da55c  vmovaps xmm7, [rsp+0x70]
0000785dab1da562  vmovaps xmm8, [rsp+0x80]
0000785dab1da56b  vmovaps xmm9, [rsp+0x90]
0000785dab1da574  vmovaps xmm10, [rsp+0xA0]
0000785dab1da57d  vmovaps xmm11, [rsp+0xB0]
0000785dab1da586  vmovaps xmm12, [rsp+0xC0]
0000785dab1da58f  vmovaps xmm14, [rsp+0xD0]
0000785dab1da598  vmovaps xmm15, [rsp+0xE0]
0000785dab1da5a1  add rsp, 0xF0
0000785dab1da5a8  pop r11
0000785dab1da5aa  pop r10
0000785dab1da5ac  pop r9
0000785dab1da5ae  pop r8
0000785dab1da5b0  pop rsi
0000785dab1da5b1  pop rdi
0000785dab1da5b2  pop rdx
0000785dab1da5b3  pop rcx
0000785dab1da5b4  pop rax
0000785dab1da5b5  add rsp, 0x08
0000785dab1da5b9  jmp 0x0000785DAB1D645C
0000785dab1da5be  sub rsp, 0x08
0000785dab1da5c2  push rax
0000785dab1da5c3  push rcx
0000785dab1da5c4  push rdx
0000785dab1da5c5  push rdi
0000785dab1da5c6  push rsi
0000785dab1da5c7  push r8
0000785dab1da5c9  push r9
0000785dab1da5cb  push r10
0000785dab1da5cd  push r11
0000785dab1da5cf  sub rsp, 0xF0
0000785dab1da5d6  vmovaps [rsp], xmm0
0000785dab1da5db  vmovaps [rsp+0x10], xmm1
0000785dab1da5e1  vmovaps [rsp+0x20], xmm2
0000785dab1da5e7  vmovaps [rsp+0x30], xmm3
0000785dab1da5ed  vmovaps [rsp+0x40], xmm4
0000785dab1da5f3  vmovaps [rsp+0x50], xmm5
0000785dab1da5f9  vmovaps [rsp+0x60], xmm6
0000785dab1da5ff  vmovaps [rsp+0x70], xmm7
0000785dab1da605  vmovaps [rsp+0x80], xmm9
0000785dab1da60e  vmovaps [rsp+0x90], xmm10
0000785dab1da617  vmovaps [rsp+0xA0], xmm11
0000785dab1da620  vmovaps [rsp+0xB0], xmm12
0000785dab1da629  vmovaps [rsp+0xC0], xmm13
0000785dab1da632  vmovaps [rsp+0xD0], xmm14
0000785dab1da63b  vmovaps [rsp+0xE0], xmm15
0000785dab1da644  sub rsp, 0x30
0000785dab1da648  movaps [rsp], xmm8
0000785dab1da64d  movaps [rsp+0x10], xmm15
0000785dab1da653  movaps [rsp+0x20], xmm9
0000785dab1da659  lea rdi, [rsp]
0000785dab1da65d  mov esi, 0x00
0000785dab1da662  mov rax, 0x61B13BBD6530
0000785dab1da66c  call rax
0000785dab1da66e  movaps xmm8, [rsp]
0000785dab1da673  add rsp, 0x30
0000785dab1da677  vmovaps xmm0, [rsp]
0000785dab1da67c  vmovaps xmm1, [rsp+0x10]
0000785dab1da682  vmovaps xmm2, [rsp+0x20]
0000785dab1da688  vmovaps xmm3, [rsp+0x30]
0000785dab1da68e  vmovaps xmm4, [rsp+0x40]
0000785dab1da694  vmovaps xmm5, [rsp+0x50]
0000785dab1da69a  vmovaps xmm6, [rsp+0x60]
0000785dab1da6a0  vmovaps xmm7, [rsp+0x70]
0000785dab1da6a6  vmovaps xmm9, [rsp+0x80]
0000785dab1da6af  vmovaps xmm10, [rsp+0x90]
0000785dab1da6b8  vmovaps xmm11, [rsp+0xA0]
0000785dab1da6c1  vmovaps xmm12, [rsp+0xB0]
0000785dab1da6ca  vmovaps xmm13, [rsp+0xC0]
0000785dab1da6d3  vmovaps xmm14, [rsp+0xD0]
0000785dab1da6dc  vmovaps xmm15, [rsp+0xE0]
0000785dab1da6e5  add rsp, 0xF0
0000785dab1da6ec  pop r11
0000785dab1da6ee  pop r10
0000785dab1da6f0  pop r9
0000785dab1da6f2  pop r8
0000785dab1da6f4  pop rsi
0000785dab1da6f5  pop rdi
0000785dab1da6f6  pop rdx
0000785dab1da6f7  pop rcx
0000785dab1da6f8  pop rax
0000785dab1da6f9  add rsp, 0x08
0000785dab1da6fd  jmp 0x0000785DAB1D648A
0000785dab1da702  sub rsp, 0x08
0000785dab1da706  push rax
0000785dab1da707  push rcx
0000785dab1da708  push rdx
0000785dab1da709  push rdi
0000785dab1da70a  push rsi
0000785dab1da70b  push r8
0000785dab1da70d  push r9
0000785dab1da70f  push r10
0000785dab1da711  push r11
0000785dab1da713  sub rsp, 0xF0
0000785dab1da71a  vmovaps [rsp], xmm0
0000785dab1da71f  vmovaps [rsp+0x10], xmm1
0000785dab1da725  vmovaps [rsp+0x20], xmm2
0000785dab1da72b  vmovaps [rsp+0x30], xmm3
0000785dab1da731  vmovaps [rsp+0x40], xmm4
0000785dab1da737  vmovaps [rsp+0x50], xmm5
0000785dab1da73d  vmovaps [rsp+0x60], xmm6
0000785dab1da743  vmovaps [rsp+0x70], xmm7
0000785dab1da749  vmovaps [rsp+0x80], xmm8
0000785dab1da752  vmovaps [rsp+0x90], xmm9
0000785dab1da75b  vmovaps [rsp+0xA0], xmm10
0000785dab1da764  vmovaps [rsp+0xB0], xmm11
0000785dab1da76d  vmovaps [rsp+0xC0], xmm12
0000785dab1da776  vmovaps [rsp+0xD0], xmm13
0000785dab1da77f  vmovaps [rsp+0xE0], xmm14
0000785dab1da788  sub rsp, 0x30
0000785dab1da78c  movaps [rsp], xmm15
0000785dab1da791  movaps [rsp+0x10], xmm11
0000785dab1da797  movaps [rsp+0x20], xmm6
0000785dab1da79c  lea rdi, [rsp]
0000785dab1da7a0  mov esi, 0x00
0000785dab1da7a5  mov rax, 0x61B13BBD6530
0000785dab1da7af  call rax
0000785dab1da7b1  movaps xmm15, [rsp]
0000785dab1da7b6  add rsp, 0x30
0000785dab1da7ba  vmovaps xmm0, [rsp]
0000785dab1da7bf  vmovaps xmm1, [rsp+0x10]
0000785dab1da7c5  vmovaps xmm2, [rsp+0x20]
0000785dab1da7cb  vmovaps xmm3, [rsp+0x30]
0000785dab1da7d1  vmovaps xmm4, [rsp+0x40]
0000785dab1da7d7  vmovaps xmm5, [rsp+0x50]
0000785dab1da7dd  vmovaps xmm6, [rsp+0x60]
0000785dab1da7e3  vmovaps xmm7, [rsp+0x70]
0000785dab1da7e9  vmovaps xmm8, [rsp+0x80]
0000785dab1da7f2  vmovaps xmm9, [rsp+0x90]
0000785dab1da7fb  vmovaps xmm10, [rsp+0xA0]
0000785dab1da804  vmovaps xmm11, [rsp+0xB0]
0000785dab1da80d  vmovaps xmm12, [rsp+0xC0]
0000785dab1da816  vmovaps xmm13, [rsp+0xD0]
0000785dab1da81f  vmovaps xmm14, [rsp+0xE0]
0000785dab1da828  add rsp, 0xF0
0000785dab1da82f  pop r11
0000785dab1da831  pop r10
0000785dab1da833  pop r9
0000785dab1da835  pop r8
0000785dab1da837  pop rsi
0000785dab1da838  pop rdi
0000785dab1da839  pop rdx
0000785dab1da83a  pop rcx
0000785dab1da83b  pop rax
0000785dab1da83c  add rsp, 0x08
0000785dab1da840  jmp 0x0000785DAB1D64A5
0000785dab1da845  sub rsp, 0x08
0000785dab1da849  push rax
0000785dab1da84a  push rcx
0000785dab1da84b  push rdx
0000785dab1da84c  push rdi
0000785dab1da84d  push rsi
0000785dab1da84e  push r8
0000785dab1da850  push r9
0000785dab1da852  push r10
0000785dab1da854  push r11
0000785dab1da856  sub rsp, 0xF0
0000785dab1da85d  vmovaps [rsp], xmm0
0000785dab1da862  vmovaps [rsp+0x10], xmm1
0000785dab1da868  vmovaps [rsp+0x20], xmm2
0000785dab1da86e  vmovaps [rsp+0x30], xmm3
0000785dab1da874  vmovaps [rsp+0x40], xmm4
0000785dab1da87a  vmovaps [rsp+0x50], xmm5
0000785dab1da880  vmovaps [rsp+0x60], xmm6
0000785dab1da886  vmovaps [rsp+0x70], xmm8
0000785dab1da88c  vmovaps [rsp+0x80], xmm9
0000785dab1da895  vmovaps [rsp+0x90], xmm10
0000785dab1da89e  vmovaps [rsp+0xA0], xmm11
0000785dab1da8a7  vmovaps [rsp+0xB0], xmm12
0000785dab1da8b0  vmovaps [rsp+0xC0], xmm13
0000785dab1da8b9  vmovaps [rsp+0xD0], xmm14
0000785dab1da8c2  vmovaps [rsp+0xE0], xmm15
0000785dab1da8cb  sub rsp, 0x30
0000785dab1da8cf  movaps [rsp], xmm7
0000785dab1da8d3  movaps [rsp+0x10], xmm11
0000785dab1da8d9  movaps [rsp+0x20], xmm9
0000785dab1da8df  lea rdi, [rsp]
0000785dab1da8e3  mov esi, 0x00
0000785dab1da8e8  mov rax, 0x61B13BBD6530
0000785dab1da8f2  call rax
0000785dab1da8f4  movaps xmm7, [rsp]
0000785dab1da8f8  add rsp, 0x30
0000785dab1da8fc  vmovaps xmm0, [rsp]
0000785dab1da901  vmovaps xmm1, [rsp+0x10]
0000785dab1da907  vmovaps xmm2, [rsp+0x20]
0000785dab1da90d  vmovaps xmm3, [rsp+0x30]
0000785dab1da913  vmovaps xmm4, [rsp+0x40]
0000785dab1da919  vmovaps xmm5, [rsp+0x50]
0000785dab1da91f  vmovaps xmm6, [rsp+0x60]
0000785dab1da925  vmovaps xmm8, [rsp+0x70]
0000785dab1da92b  vmovaps xmm9, [rsp+0x80]
0000785dab1da934  vmovaps xmm10, [rsp+0x90]
0000785dab1da93d  vmovaps xmm11, [rsp+0xA0]
0000785dab1da946  vmovaps xmm12, [rsp+0xB0]
0000785dab1da94f  vmovaps xmm13, [rsp+0xC0]
0000785dab1da958  vmovaps xmm14, [rsp+0xD0]
0000785dab1da961  vmovaps xmm15, [rsp+0xE0]
0000785dab1da96a  add rsp, 0xF0
0000785dab1da971  pop r11
0000785dab1da973  pop r10
0000785dab1da975  pop r9
0000785dab1da977  pop r8
0000785dab1da979  pop rsi
0000785dab1da97a  pop rdi
0000785dab1da97b  pop rdx
0000785dab1da97c  pop rcx
0000785dab1da97d  pop rax
0000785dab1da97e  add rsp, 0x08
0000785dab1da982  jmp 0x0000785DAB1D64D2
0000785dab1da987  sub rsp, 0x08
0000785dab1da98b  push rax
0000785dab1da98c  push rcx
0000785dab1da98d  push rdx
0000785dab1da98e  push rdi
0000785dab1da98f  push rsi
0000785dab1da990  push r8
0000785dab1da992  push r9
0000785dab1da994  push r10
0000785dab1da996  push r11
0000785dab1da998  sub rsp, 0xF0
0000785dab1da99f  vmovaps [rsp], xmm0
0000785dab1da9a4  vmovaps [rsp+0x10], xmm1
0000785dab1da9aa  vmovaps [rsp+0x20], xmm2
0000785dab1da9b0  vmovaps [rsp+0x30], xmm3
0000785dab1da9b6  vmovaps [rsp+0x40], xmm4
0000785dab1da9bc  vmovaps [rsp+0x50], xmm5
0000785dab1da9c2  vmovaps [rsp+0x60], xmm6
0000785dab1da9c8  vmovaps [rsp+0x70], xmm7
0000785dab1da9ce  vmovaps [rsp+0x80], xmm8
0000785dab1da9d7  vmovaps [rsp+0x90], xmm9
0000785dab1da9e0  vmovaps [rsp+0xA0], xmm10
0000785dab1da9e9  vmovaps [rsp+0xB0], xmm12
0000785dab1da9f2  vmovaps [rsp+0xC0], xmm13
0000785dab1da9fb  vmovaps [rsp+0xD0], xmm14
0000785dab1daa04  vmovaps [rsp+0xE0], xmm15
0000785dab1daa0d  sub rsp, 0x30
0000785dab1daa11  movaps [rsp], xmm11
0000785dab1daa16  movaps [rsp+0x10], xmm10
0000785dab1daa1c  movaps [rsp+0x20], xmm14
0000785dab1daa22  lea rdi, [rsp]
0000785dab1daa26  mov esi, 0x00
0000785dab1daa2b  mov rax, 0x61B13BBD6530
0000785dab1daa35  call rax
0000785dab1daa37  movaps xmm11, [rsp]
0000785dab1daa3c  add rsp, 0x30
0000785dab1daa40  vmovaps xmm0, [rsp]
0000785dab1daa45  vmovaps xmm1, [rsp+0x10]
0000785dab1daa4b  vmovaps xmm2, [rsp+0x20]
0000785dab1daa51  vmovaps xmm3, [rsp+0x30]
0000785dab1daa57  vmovaps xmm4, [rsp+0x40]
0000785dab1daa5d  vmovaps xmm5, [rsp+0x50]
0000785dab1daa63  vmovaps xmm6, [rsp+0x60]
0000785dab1daa69  vmovaps xmm7, [rsp+0x70]
0000785dab1daa6f  vmovaps xmm8, [rsp+0x80]
0000785dab1daa78  vmovaps xmm9, [rsp+0x90]
0000785dab1daa81  vmovaps xmm10, [rsp+0xA0]
0000785dab1daa8a  vmovaps xmm12, [rsp+0xB0]
0000785dab1daa93  vmovaps xmm13, [rsp+0xC0]
0000785dab1daa9c  vmovaps xmm14, [rsp+0xD0]
0000785dab1daaa5  vmovaps xmm15, [rsp+0xE0]
0000785dab1daaae  add rsp, 0xF0
0000785dab1daab5  pop r11
0000785dab1daab7  pop r10
0000785dab1daab9  pop r9
0000785dab1daabb  pop r8
0000785dab1daabd  pop rsi
0000785dab1daabe  pop rdi
0000785dab1daabf  pop rdx
0000785dab1daac0  pop rcx
0000785dab1daac1  pop rax
0000785dab1daac2  add rsp, 0x08
0000785dab1daac6  jmp 0x0000785DAB1D64ED
0000785dab1daacb  call 0x0000785DAB0E45A0
0000785dab1daad0  jmp 0x0000785DAB1D64F7
0000785dab1daad5  sub rsp, 0x08
0000785dab1daad9  push rax
0000785dab1daada  push rcx
0000785dab1daadb  push rdx
0000785dab1daadc  push rdi
0000785dab1daadd  push rsi
0000785dab1daade  push r8
0000785dab1daae0  push r9
0000785dab1daae2  push r10
0000785dab1daae4  push r11
0000785dab1daae6  sub rsp, 0xF0
0000785dab1daaed  vmovaps [rsp], xmm0
0000785dab1daaf2  vmovaps [rsp+0x10], xmm1
0000785dab1daaf8  vmovaps [rsp+0x20], xmm2
0000785dab1daafe  vmovaps [rsp+0x30], xmm3
0000785dab1dab04  vmovaps [rsp+0x40], xmm4
0000785dab1dab0a  vmovaps [rsp+0x50], xmm5
0000785dab1dab10  vmovaps [rsp+0x60], xmm6
0000785dab1dab16  vmovaps [rsp+0x70], xmm7
0000785dab1dab1c  vmovaps [rsp+0x80], xmm8
0000785dab1dab25  vmovaps [rsp+0x90], xmm9
0000785dab1dab2e  vmovaps [rsp+0xA0], xmm11
0000785dab1dab37  vmovaps [rsp+0xB0], xmm12
0000785dab1dab40  vmovaps [rsp+0xC0], xmm13
0000785dab1dab49  vmovaps [rsp+0xD0], xmm14
0000785dab1dab52  vmovaps [rsp+0xE0], xmm15
0000785dab1dab5b  sub rsp, 0x30
0000785dab1dab5f  movaps [rsp], xmm10
0000785dab1dab64  movaps [rsp+0x10], xmm1
0000785dab1dab69  movaps [rsp+0x20], xmm12
0000785dab1dab6f  lea rdi, [rsp]
0000785dab1dab73  mov esi, 0x00
0000785dab1dab78  mov rax, 0x61B13BBD6530
0000785dab1dab82  call rax
0000785dab1dab84  movaps xmm10, [rsp]
0000785dab1dab89  add rsp, 0x30
0000785dab1dab8d  vmovaps xmm0, [rsp]
0000785dab1dab92  vmovaps xmm1, [rsp+0x10]
0000785dab1dab98  vmovaps xmm2, [rsp+0x20]
0000785dab1dab9e  vmovaps xmm3, [rsp+0x30]
0000785dab1daba4  vmovaps xmm4, [rsp+0x40]
0000785dab1dabaa  vmovaps xmm5, [rsp+0x50]
0000785dab1dabb0  vmovaps xmm6, [rsp+0x60]
0000785dab1dabb6  vmovaps xmm7, [rsp+0x70]
0000785dab1dabbc  vmovaps xmm8, [rsp+0x80]
0000785dab1dabc5  vmovaps xmm9, [rsp+0x90]
0000785dab1dabce  vmovaps xmm11, [rsp+0xA0]
0000785dab1dabd7  vmovaps xmm12, [rsp+0xB0]
0000785dab1dabe0  vmovaps xmm13, [rsp+0xC0]
0000785dab1dabe9  vmovaps xmm14, [rsp+0xD0]
0000785dab1dabf2  vmovaps xmm15, [rsp+0xE0]
0000785dab1dabfb  add rsp, 0xF0
0000785dab1dac02  pop r11
0000785dab1dac04  pop r10
0000785dab1dac06  pop r9
0000785dab1dac08  pop r8
0000785dab1dac0a  pop rsi
0000785dab1dac0b  pop rdi
0000785dab1dac0c  pop rdx
0000785dab1dac0d  pop rcx
0000785dab1dac0e  pop rax
0000785dab1dac0f  add rsp, 0x08
0000785dab1dac13  jmp 0x0000785DAB1D651A
0000785dab1dac18  sub rsp, 0x08
0000785dab1dac1c  push rax
0000785dab1dac1d  push rcx
0000785dab1dac1e  push rdx
0000785dab1dac1f  push rdi
0000785dab1dac20  push rsi
0000785dab1dac21  push r8
0000785dab1dac23  push r9
0000785dab1dac25  push r10
0000785dab1dac27  push r11
0000785dab1dac29  sub rsp, 0xF0
0000785dab1dac30  vmovaps [rsp], xmm0
0000785dab1dac35  vmovaps [rsp+0x10], xmm1
0000785dab1dac3b  vmovaps [rsp+0x20], xmm2
0000785dab1dac41  vmovaps [rsp+0x30], xmm3
0000785dab1dac47  vmovaps [rsp+0x40], xmm4
0000785dab1dac4d  vmovaps [rsp+0x50], xmm5
0000785dab1dac53  vmovaps [rsp+0x60], xmm6
0000785dab1dac59  vmovaps [rsp+0x70], xmm7
0000785dab1dac5f  vmovaps [rsp+0x80], xmm8
0000785dab1dac68  vmovaps [rsp+0x90], xmm9
0000785dab1dac71  vmovaps [rsp+0xA0], xmm10
0000785dab1dac7a  vmovaps [rsp+0xB0], xmm11
0000785dab1dac83  vmovaps [rsp+0xC0], xmm13
0000785dab1dac8c  vmovaps [rsp+0xD0], xmm14
0000785dab1dac95  vmovaps [rsp+0xE0], xmm15
0000785dab1dac9e  sub rsp, 0x30
0000785dab1daca2  movaps [rsp], xmm12
0000785dab1daca7  movaps [rsp+0x10], xmm14
0000785dab1dacad  movaps [rsp+0x20], xmm1
0000785dab1dacb2  lea rdi, [rsp]
0000785dab1dacb6  mov esi, 0x00
0000785dab1dacbb  mov rax, 0x61B13BBD6530
0000785dab1dacc5  call rax
0000785dab1dacc7  movaps xmm12, [rsp]
0000785dab1daccc  add rsp, 0x30
0000785dab1dacd0  vmovaps xmm0, [rsp]
0000785dab1dacd5  vmovaps xmm1, [rsp+0x10]
0000785dab1dacdb  vmovaps xmm2, [rsp+0x20]
0000785dab1dace1  vmovaps xmm3, [rsp+0x30]
0000785dab1dace7  vmovaps xmm4, [rsp+0x40]
0000785dab1daced  vmovaps xmm5, [rsp+0x50]
0000785dab1dacf3  vmovaps xmm6, [rsp+0x60]
0000785dab1dacf9  vmovaps xmm7, [rsp+0x70]
0000785dab1dacff  vmovaps xmm8, [rsp+0x80]
0000785dab1dad08  vmovaps xmm9, [rsp+0x90]
0000785dab1dad11  vmovaps xmm10, [rsp+0xA0]
0000785dab1dad1a  vmovaps xmm11, [rsp+0xB0]
0000785dab1dad23  vmovaps xmm13, [rsp+0xC0]
0000785dab1dad2c  vmovaps xmm14, [rsp+0xD0]
0000785dab1dad35  vmovaps xmm15, [rsp+0xE0]
0000785dab1dad3e  add rsp, 0xF0
0000785dab1dad45  pop r11
0000785dab1dad47  pop r10
0000785dab1dad49  pop r9
0000785dab1dad4b  pop r8
0000785dab1dad4d  pop rsi
0000785dab1dad4e  pop rdi
0000785dab1dad4f  pop rdx
0000785dab1dad50  pop rcx
0000785dab1dad51  pop rax
0000785dab1dad52  add rsp, 0x08
0000785dab1dad56  jmp 0x0000785DAB1D6549
0000785dab1dad5b  sub rsp, 0x08
0000785dab1dad5f  push rax
0000785dab1dad60  push rcx
0000785dab1dad61  push rdx
0000785dab1dad62  push rdi
0000785dab1dad63  push rsi
0000785dab1dad64  push r8
0000785dab1dad66  push r9
0000785dab1dad68  push r10
0000785dab1dad6a  push r11
0000785dab1dad6c  sub rsp, 0xF0
0000785dab1dad73  vmovaps [rsp], xmm0
0000785dab1dad78  vmovaps [rsp+0x10], xmm1
0000785dab1dad7e  vmovaps [rsp+0x20], xmm2
0000785dab1dad84  vmovaps [rsp+0x30], xmm3
0000785dab1dad8a  vmovaps [rsp+0x40], xmm4
0000785dab1dad90  vmovaps [rsp+0x50], xmm5
0000785dab1dad96  vmovaps [rsp+0x60], xmm6
0000785dab1dad9c  vmovaps [rsp+0x70], xmm7
0000785dab1dada2  vmovaps [rsp+0x80], xmm8
0000785dab1dadab  vmovaps [rsp+0x90], xmm9
0000785dab1dadb4  vmovaps [rsp+0xA0], xmm10
0000785dab1dadbd  vmovaps [rsp+0xB0], xmm11
0000785dab1dadc6  vmovaps [rsp+0xC0], xmm12
0000785dab1dadcf  vmovaps [rsp+0xD0], xmm13
0000785dab1dadd8  vmovaps [rsp+0xE0], xmm15
0000785dab1dade1  sub rsp, 0x30
0000785dab1dade5  movaps [rsp], xmm14
0000785dab1dadea  movaps [rsp+0x10], xmm9
0000785dab1dadf0  movaps [rsp+0x20], xmm1
0000785dab1dadf5  lea rdi, [rsp]
0000785dab1dadf9  mov esi, 0x00
0000785dab1dadfe  mov rax, 0x61B13BBD6530
0000785dab1dae08  call rax
0000785dab1dae0a  movaps xmm14, [rsp]
0000785dab1dae0f  add rsp, 0x30
0000785dab1dae13  vmovaps xmm0, [rsp]
0000785dab1dae18  vmovaps xmm1, [rsp+0x10]
0000785dab1dae1e  vmovaps xmm2, [rsp+0x20]
0000785dab1dae24  vmovaps xmm3, [rsp+0x30]
0000785dab1dae2a  vmovaps xmm4, [rsp+0x40]
0000785dab1dae30  vmovaps xmm5, [rsp+0x50]
0000785dab1dae36  vmovaps xmm6, [rsp+0x60]
0000785dab1dae3c  vmovaps xmm7, [rsp+0x70]
0000785dab1dae42  vmovaps xmm8, [rsp+0x80]
0000785dab1dae4b  vmovaps xmm9, [rsp+0x90]
0000785dab1dae54  vmovaps xmm10, [rsp+0xA0]
0000785dab1dae5d  vmovaps xmm11, [rsp+0xB0]
0000785dab1dae66  vmovaps xmm12, [rsp+0xC0]
0000785dab1dae6f  vmovaps xmm13, [rsp+0xD0]
0000785dab1dae78  vmovaps xmm15, [rsp+0xE0]
0000785dab1dae81  add rsp, 0xF0
0000785dab1dae88  pop r11
0000785dab1dae8a  pop r10
0000785dab1dae8c  pop r9
0000785dab1dae8e  pop r8
0000785dab1dae90  pop rsi
0000785dab1dae91  pop rdi
0000785dab1dae92  pop rdx
0000785dab1dae93  pop rcx
0000785dab1dae94  pop rax
0000785dab1dae95  add rsp, 0x08
0000785dab1dae99  jmp 0x0000785DAB1D6578
0000785dab1dae9e  sub rsp, 0x08
0000785dab1daea2  push rax
0000785dab1daea3  push rcx
0000785dab1daea4  push rdx
0000785dab1daea5  push rdi
0000785dab1daea6  push rsi
0000785dab1daea7  push r8
0000785dab1daea9  push r9
0000785dab1daeab  push r10
0000785dab1daead  push r11
0000785dab1daeaf  sub rsp, 0xF0
0000785dab1daeb6  vmovaps [rsp], xmm0
0000785dab1daebb  vmovaps [rsp+0x10], xmm2
0000785dab1daec1  vmovaps [rsp+0x20], xmm3
0000785dab1daec7  vmovaps [rsp+0x30], xmm4
0000785dab1daecd  vmovaps [rsp+0x40], xmm5
0000785dab1daed3  vmovaps [rsp+0x50], xmm6
0000785dab1daed9  vmovaps [rsp+0x60], xmm7
0000785dab1daedf  vmovaps [rsp+0x70], xmm8
0000785dab1daee5  vmovaps [rsp+0x80], xmm9
0000785dab1daeee  vmovaps [rsp+0x90], xmm10
0000785dab1daef7  vmovaps [rsp+0xA0], xmm11
0000785dab1daf00  vmovaps [rsp+0xB0], xmm12
0000785dab1daf09  vmovaps [rsp+0xC0], xmm13
0000785dab1daf12  vmovaps [rsp+0xD0], xmm14
0000785dab1daf1b  vmovaps [rsp+0xE0], xmm15
0000785dab1daf24  sub rsp, 0x30
0000785dab1daf28  movaps [rsp], xmm1
0000785dab1daf2c  movaps [rsp+0x10], xmm13
0000785dab1daf32  movaps [rsp+0x20], xmm8
0000785dab1daf38  lea rdi, [rsp]
0000785dab1daf3c  mov esi, 0x00
0000785dab1daf41  mov rax, 0x61B13BBD6530
0000785dab1daf4b  call rax
0000785dab1daf4d  movaps xmm1, [rsp]
0000785dab1daf51  add rsp, 0x30
0000785dab1daf55  vmovaps xmm0, [rsp]
0000785dab1daf5a  vmovaps xmm2, [rsp+0x10]
0000785dab1daf60  vmovaps xmm3, [rsp+0x20]
0000785dab1daf66  vmovaps xmm4, [rsp+0x30]
0000785dab1daf6c  vmovaps xmm5, [rsp+0x40]
0000785dab1daf72  vmovaps xmm6, [rsp+0x50]
0000785dab1daf78  vmovaps xmm7, [rsp+0x60]
0000785dab1daf7e  vmovaps xmm8, [rsp+0x70]
0000785dab1daf84  vmovaps xmm9, [rsp+0x80]
0000785dab1daf8d  vmovaps xmm10, [rsp+0x90]
0000785dab1daf96  vmovaps xmm11, [rsp+0xA0]
0000785dab1daf9f  vmovaps xmm12, [rsp+0xB0]
0000785dab1dafa8  vmovaps xmm13, [rsp+0xC0]
0000785dab1dafb1  vmovaps xmm14, [rsp+0xD0]
0000785dab1dafba  vmovaps xmm15, [rsp+0xE0]
0000785dab1dafc3  add rsp, 0xF0
0000785dab1dafca  pop r11
0000785dab1dafcc  pop r10
0000785dab1dafce  pop r9
0000785dab1dafd0  pop r8
0000785dab1dafd2  pop rsi
0000785dab1dafd3  pop rdi
0000785dab1dafd4  pop rdx
0000785dab1dafd5  pop rcx
0000785dab1dafd6  pop rax
0000785dab1dafd7  add rsp, 0x08
0000785dab1dafdb  jmp 0x0000785DAB1D659A
0000785dab1dafe0  call 0x0000785DAB00C260
0000785dab1dafe5  jmp 0x0000785DAB1D65A8
0000785dab1dafea  call 0x0000785DAB0DE950
0000785dab1dafef  jmp 0x0000785DAB1D65B2
0000785dab1daff4  sub rsp, 0x08
0000785dab1daff8  push rax
0000785dab1daff9  push rcx
0000785dab1daffa  push rdx
0000785dab1daffb  push rdi
0000785dab1daffc  push rsi
0000785dab1daffd  push r8
0000785dab1dafff  push r9
0000785dab1db001  push r10
0000785dab1db003  push r11
0000785dab1db005  sub rsp, 0xF0
0000785dab1db00c  vmovaps [rsp], xmm0
0000785dab1db011  vmovaps [rsp+0x10], xmm1
0000785dab1db017  vmovaps [rsp+0x20], xmm2
0000785dab1db01d  vmovaps [rsp+0x30], xmm3
0000785dab1db023  vmovaps [rsp+0x40], xmm4
0000785dab1db029  vmovaps [rsp+0x50], xmm5
0000785dab1db02f  vmovaps [rsp+0x60], xmm6
0000785dab1db035  vmovaps [rsp+0x70], xmm7
0000785dab1db03b  vmovaps [rsp+0x80], xmm9
0000785dab1db044  vmovaps [rsp+0x90], xmm10
0000785dab1db04d  vmovaps [rsp+0xA0], xmm11
0000785dab1db056  vmovaps [rsp+0xB0], xmm12
0000785dab1db05f  vmovaps [rsp+0xC0], xmm13
0000785dab1db068  vmovaps [rsp+0xD0], xmm14
0000785dab1db071  vmovaps [rsp+0xE0], xmm15
0000785dab1db07a  sub rsp, 0x30
0000785dab1db07e  movaps [rsp], xmm8
0000785dab1db083  movaps [rsp+0x10], xmm15
0000785dab1db089  movaps [rsp+0x20], xmm7
0000785dab1db08e  lea rdi, [rsp]
0000785dab1db092  mov esi, 0x00
0000785dab1db097  mov rax, 0x61B13BBD6530
0000785dab1db0a1  call rax
0000785dab1db0a3  movaps xmm8, [rsp]
0000785dab1db0a8  add rsp, 0x30
0000785dab1db0ac  vmovaps xmm0, [rsp]
0000785dab1db0b1  vmovaps xmm1, [rsp+0x10]
0000785dab1db0b7  vmovaps xmm2, [rsp+0x20]
0000785dab1db0bd  vmovaps xmm3, [rsp+0x30]
0000785dab1db0c3  vmovaps xmm4, [rsp+0x40]
0000785dab1db0c9  vmovaps xmm5, [rsp+0x50]
0000785dab1db0cf  vmovaps xmm6, [rsp+0x60]
0000785dab1db0d5  vmovaps xmm7, [rsp+0x70]
0000785dab1db0db  vmovaps xmm9, [rsp+0x80]
0000785dab1db0e4  vmovaps xmm10, [rsp+0x90]
0000785dab1db0ed  vmovaps xmm11, [rsp+0xA0]
0000785dab1db0f6  vmovaps xmm12, [rsp+0xB0]
0000785dab1db0ff  vmovaps xmm13, [rsp+0xC0]
0000785dab1db108  vmovaps xmm14, [rsp+0xD0]
0000785dab1db111  vmovaps xmm15, [rsp+0xE0]
0000785dab1db11a  add rsp, 0xF0
0000785dab1db121  pop r11
0000785dab1db123  pop r10
0000785dab1db125  pop r9
0000785dab1db127  pop r8
0000785dab1db129  pop rsi
0000785dab1db12a  pop rdi
0000785dab1db12b  pop rdx
0000785dab1db12c  pop rcx
0000785dab1db12d  pop rax
0000785dab1db12e  add rsp, 0x08
0000785dab1db132  jmp 0x0000785DAB1D65D4
0000785dab1db137  sub rsp, 0x08
0000785dab1db13b  push rax
0000785dab1db13c  push rcx
0000785dab1db13d  push rdx
0000785dab1db13e  push rdi
0000785dab1db13f  push rsi
0000785dab1db140  push r8
0000785dab1db142  push r9
0000785dab1db144  push r10
0000785dab1db146  push r11
0000785dab1db148  sub rsp, 0xF0
0000785dab1db14f  vmovaps [rsp], xmm0
0000785dab1db154  vmovaps [rsp+0x10], xmm1
0000785dab1db15a  vmovaps [rsp+0x20], xmm2
0000785dab1db160  vmovaps [rsp+0x30], xmm3
0000785dab1db166  vmovaps [rsp+0x40], xmm4
0000785dab1db16c  vmovaps [rsp+0x50], xmm5
0000785dab1db172  vmovaps [rsp+0x60], xmm6
0000785dab1db178  vmovaps [rsp+0x70], xmm8
0000785dab1db17e  vmovaps [rsp+0x80], xmm9
0000785dab1db187  vmovaps [rsp+0x90], xmm10
0000785dab1db190  vmovaps [rsp+0xA0], xmm11
0000785dab1db199  vmovaps [rsp+0xB0], xmm12
0000785dab1db1a2  vmovaps [rsp+0xC0], xmm13
0000785dab1db1ab  vmovaps [rsp+0xD0], xmm14
0000785dab1db1b4  vmovaps [rsp+0xE0], xmm15
0000785dab1db1bd  sub rsp, 0x30
0000785dab1db1c1  movaps [rsp], xmm7
0000785dab1db1c5  movaps [rsp+0x10], xmm9
0000785dab1db1cb  movaps [rsp+0x20], xmm15
0000785dab1db1d1  lea rdi, [rsp]
0000785dab1db1d5  mov esi, 0x00
0000785dab1db1da  mov rax, 0x61B13BBD6530
0000785dab1db1e4  call rax
0000785dab1db1e6  movaps xmm7, [rsp]
0000785dab1db1ea  add rsp, 0x30
0000785dab1db1ee  vmovaps xmm0, [rsp]
0000785dab1db1f3  vmovaps xmm1, [rsp+0x10]
0000785dab1db1f9  vmovaps xmm2, [rsp+0x20]
0000785dab1db1ff  vmovaps xmm3, [rsp+0x30]
0000785dab1db205  vmovaps xmm4, [rsp+0x40]
0000785dab1db20b  vmovaps xmm5, [rsp+0x50]
0000785dab1db211  vmovaps xmm6, [rsp+0x60]
0000785dab1db217  vmovaps xmm8, [rsp+0x70]
0000785dab1db21d  vmovaps xmm9, [rsp+0x80]
0000785dab1db226  vmovaps xmm10, [rsp+0x90]
0000785dab1db22f  vmovaps xmm11, [rsp+0xA0]
0000785dab1db238  vmovaps xmm12, [rsp+0xB0]
0000785dab1db241  vmovaps xmm13, [rsp+0xC0]
0000785dab1db24a  vmovaps xmm14, [rsp+0xD0]
0000785dab1db253  vmovaps xmm15, [rsp+0xE0]
0000785dab1db25c  add rsp, 0xF0
0000785dab1db263  pop r11
0000785dab1db265  pop r10
0000785dab1db267  pop r9
0000785dab1db269  pop r8
0000785dab1db26b  pop rsi
0000785dab1db26c  pop rdi
0000785dab1db26d  pop rdx
0000785dab1db26e  pop rcx
0000785dab1db26f  pop rax
0000785dab1db270  add rsp, 0x08
0000785dab1db274  jmp 0x0000785DAB1D6601
0000785dab1db279  sub rsp, 0x08
0000785dab1db27d  push rax
0000785dab1db27e  push rcx
0000785dab1db27f  push rdx
0000785dab1db280  push rdi
0000785dab1db281  push rsi
0000785dab1db282  push r8
0000785dab1db284  push r9
0000785dab1db286  push r10
0000785dab1db288  push r11
0000785dab1db28a  sub rsp, 0xF0
0000785dab1db291  vmovaps [rsp], xmm0
0000785dab1db296  vmovaps [rsp+0x10], xmm1
0000785dab1db29c  vmovaps [rsp+0x20], xmm2
0000785dab1db2a2  vmovaps [rsp+0x30], xmm3
0000785dab1db2a8  vmovaps [rsp+0x40], xmm4
0000785dab1db2ae  vmovaps [rsp+0x50], xmm5
0000785dab1db2b4  vmovaps [rsp+0x60], xmm6
0000785dab1db2ba  vmovaps [rsp+0x70], xmm7
0000785dab1db2c0  vmovaps [rsp+0x80], xmm8
0000785dab1db2c9  vmovaps [rsp+0x90], xmm10
0000785dab1db2d2  vmovaps [rsp+0xA0], xmm11
0000785dab1db2db  vmovaps [rsp+0xB0], xmm12
0000785dab1db2e4  vmovaps [rsp+0xC0], xmm13
0000785dab1db2ed  vmovaps [rsp+0xD0], xmm14
0000785dab1db2f6  vmovaps [rsp+0xE0], xmm15
0000785dab1db2ff  sub rsp, 0x30
0000785dab1db303  movaps [rsp], xmm9
0000785dab1db308  movaps [rsp+0x10], xmm13
0000785dab1db30e  movaps [rsp+0x20], xmm15
0000785dab1db314  lea rdi, [rsp]
0000785dab1db318  mov esi, 0x00
0000785dab1db31d  mov rax, 0x61B13BBD6530
0000785dab1db327  call rax
0000785dab1db329  movaps xmm9, [rsp]
0000785dab1db32e  add rsp, 0x30
0000785dab1db332  vmovaps xmm0, [rsp]
0000785dab1db337  vmovaps xmm1, [rsp+0x10]
0000785dab1db33d  vmovaps xmm2, [rsp+0x20]
0000785dab1db343  vmovaps xmm3, [rsp+0x30]
0000785dab1db349  vmovaps xmm4, [rsp+0x40]
0000785dab1db34f  vmovaps xmm5, [rsp+0x50]
0000785dab1db355  vmovaps xmm6, [rsp+0x60]
0000785dab1db35b  vmovaps xmm7, [rsp+0x70]
0000785dab1db361  vmovaps xmm8, [rsp+0x80]
0000785dab1db36a  vmovaps xmm10, [rsp+0x90]
0000785dab1db373  vmovaps xmm11, [rsp+0xA0]
0000785dab1db37c  vmovaps xmm12, [rsp+0xB0]
0000785dab1db385  vmovaps xmm13, [rsp+0xC0]
0000785dab1db38e  vmovaps xmm14, [rsp+0xD0]
0000785dab1db397  vmovaps xmm15, [rsp+0xE0]
0000785dab1db3a0  add rsp, 0xF0
0000785dab1db3a7  pop r11
0000785dab1db3a9  pop r10
0000785dab1db3ab  pop r9
0000785dab1db3ad  pop r8
0000785dab1db3af  pop rsi
0000785dab1db3b0  pop rdi
0000785dab1db3b1  pop rdx
0000785dab1db3b2  pop rcx
0000785dab1db3b3  pop rax
0000785dab1db3b4  add rsp, 0x08
0000785dab1db3b8  jmp 0x0000785DAB1D662F
0000785dab1db3bd  sub rsp, 0x08
0000785dab1db3c1  push rax
0000785dab1db3c2  push rcx
0000785dab1db3c3  push rdx
0000785dab1db3c4  push rdi
0000785dab1db3c5  push rsi
0000785dab1db3c6  push r8
0000785dab1db3c8  push r9
0000785dab1db3ca  push r10
0000785dab1db3cc  push r11
0000785dab1db3ce  sub rsp, 0xF0
0000785dab1db3d5  vmovaps [rsp], xmm0
0000785dab1db3da  vmovaps [rsp+0x10], xmm1
0000785dab1db3e0  vmovaps [rsp+0x20], xmm2
0000785dab1db3e6  vmovaps [rsp+0x30], xmm3
0000785dab1db3ec  vmovaps [rsp+0x40], xmm4
0000785dab1db3f2  vmovaps [rsp+0x50], xmm5
0000785dab1db3f8  vmovaps [rsp+0x60], xmm6
0000785dab1db3fe  vmovaps [rsp+0x70], xmm7
0000785dab1db404  vmovaps [rsp+0x80], xmm8
0000785dab1db40d  vmovaps [rsp+0x90], xmm9
0000785dab1db416  vmovaps [rsp+0xA0], xmm10
0000785dab1db41f  vmovaps [rsp+0xB0], xmm11
0000785dab1db428  vmovaps [rsp+0xC0], xmm12
0000785dab1db431  vmovaps [rsp+0xD0], xmm13
0000785dab1db43a  vmovaps [rsp+0xE0], xmm14
0000785dab1db443  sub rsp, 0x30
0000785dab1db447  movaps [rsp], xmm15
0000785dab1db44c  movaps [rsp+0x10], xmm11
0000785dab1db452  movaps [rsp+0x20], xmm12
0000785dab1db458  lea rdi, [rsp]
0000785dab1db45c  mov esi, 0x00
0000785dab1db461  mov rax, 0x61B13BBD6530
0000785dab1db46b  call rax
0000785dab1db46d  movaps xmm15, [rsp]
0000785dab1db472  add rsp, 0x30
0000785dab1db476  vmovaps xmm0, [rsp]
0000785dab1db47b  vmovaps xmm1, [rsp+0x10]
0000785dab1db481  vmovaps xmm2, [rsp+0x20]
0000785dab1db487  vmovaps xmm3, [rsp+0x30]
0000785dab1db48d  vmovaps xmm4, [rsp+0x40]
0000785dab1db493  vmovaps xmm5, [rsp+0x50]
0000785dab1db499  vmovaps xmm6, [rsp+0x60]
0000785dab1db49f  vmovaps xmm7, [rsp+0x70]
0000785dab1db4a5  vmovaps xmm8, [rsp+0x80]
0000785dab1db4ae  vmovaps xmm9, [rsp+0x90]
0000785dab1db4b7  vmovaps xmm10, [rsp+0xA0]
0000785dab1db4c0  vmovaps xmm11, [rsp+0xB0]
0000785dab1db4c9  vmovaps xmm12, [rsp+0xC0]
0000785dab1db4d2  vmovaps xmm13, [rsp+0xD0]
0000785dab1db4db  vmovaps xmm14, [rsp+0xE0]
0000785dab1db4e4  add rsp, 0xF0
0000785dab1db4eb  pop r11
0000785dab1db4ed  pop r10
0000785dab1db4ef  pop r9
0000785dab1db4f1  pop r8
0000785dab1db4f3  pop rsi
0000785dab1db4f4  pop rdi
0000785dab1db4f5  pop rdx
0000785dab1db4f6  pop rcx
0000785dab1db4f7  pop rax
0000785dab1db4f8  add rsp, 0x08
0000785dab1db4fc  jmp 0x0000785DAB1D664A
0000785dab1db501  sub rsp, 0x08
0000785dab1db505  push rax
0000785dab1db506  push rcx
0000785dab1db507  push rdx
0000785dab1db508  push rdi
0000785dab1db509  push rsi
0000785dab1db50a  push r8
0000785dab1db50c  push r9
0000785dab1db50e  push r10
0000785dab1db510  push r11
0000785dab1db512  sub rsp, 0xF0
0000785dab1db519  vmovaps [rsp], xmm0
0000785dab1db51e  vmovaps [rsp+0x10], xmm1
0000785dab1db524  vmovaps [rsp+0x20], xmm2
0000785dab1db52a  vmovaps [rsp+0x30], xmm3
0000785dab1db530  vmovaps [rsp+0x40], xmm4
0000785dab1db536  vmovaps [rsp+0x50], xmm5
0000785dab1db53c  vmovaps [rsp+0x60], xmm6
0000785dab1db542  vmovaps [rsp+0x70], xmm7
0000785dab1db548  vmovaps [rsp+0x80], xmm8
0000785dab1db551  vmovaps [rsp+0x90], xmm9
0000785dab1db55a  vmovaps [rsp+0xA0], xmm10
0000785dab1db563  vmovaps [rsp+0xB0], xmm11
0000785dab1db56c  vmovaps [rsp+0xC0], xmm12
0000785dab1db575  vmovaps [rsp+0xD0], xmm14
0000785dab1db57e  vmovaps [rsp+0xE0], xmm15
0000785dab1db587  sub rsp, 0x30
0000785dab1db58b  movaps [rsp], xmm13
0000785dab1db590  movaps [rsp+0x10], xmm10
0000785dab1db596  movaps [rsp+0x20], xmm14
0000785dab1db59c  lea rdi, [rsp]
0000785dab1db5a0  mov esi, 0x00
0000785dab1db5a5  mov rax, 0x61B13BBD6530
0000785dab1db5af  call rax
0000785dab1db5b1  movaps xmm13, [rsp]
0000785dab1db5b6  add rsp, 0x30
0000785dab1db5ba  vmovaps xmm0, [rsp]
0000785dab1db5bf  vmovaps xmm1, [rsp+0x10]
0000785dab1db5c5  vmovaps xmm2, [rsp+0x20]
0000785dab1db5cb  vmovaps xmm3, [rsp+0x30]
0000785dab1db5d1  vmovaps xmm4, [rsp+0x40]
0000785dab1db5d7  vmovaps xmm5, [rsp+0x50]
0000785dab1db5dd  vmovaps xmm6, [rsp+0x60]
0000785dab1db5e3  vmovaps xmm7, [rsp+0x70]
0000785dab1db5e9  vmovaps xmm8, [rsp+0x80]
0000785dab1db5f2  vmovaps xmm9, [rsp+0x90]
0000785dab1db5fb  vmovaps xmm10, [rsp+0xA0]
0000785dab1db604  vmovaps xmm11, [rsp+0xB0]
0000785dab1db60d  vmovaps xmm12, [rsp+0xC0]
0000785dab1db616  vmovaps xmm14, [rsp+0xD0]
0000785dab1db61f  vmovaps xmm15, [rsp+0xE0]
0000785dab1db628  add rsp, 0xF0
0000785dab1db62f  pop r11
0000785dab1db631  pop r10
0000785dab1db633  pop r9
0000785dab1db635  pop r8
0000785dab1db637  pop rsi
0000785dab1db638  pop rdi
0000785dab1db639  pop rdx
0000785dab1db63a  pop rcx
0000785dab1db63b  pop rax
0000785dab1db63c  add rsp, 0x08
0000785dab1db640  jmp 0x0000785DAB1D666D
0000785dab1db645  sub rsp, 0x08
0000785dab1db649  push rax
0000785dab1db64a  push rcx
0000785dab1db64b  push rdx
0000785dab1db64c  push rdi
0000785dab1db64d  push rsi
0000785dab1db64e  push r8
0000785dab1db650  push r9
0000785dab1db652  push r10
0000785dab1db654  push r11
0000785dab1db656  sub rsp, 0xF0
0000785dab1db65d  vmovaps [rsp], xmm0
0000785dab1db662  vmovaps [rsp+0x10], xmm1
0000785dab1db668  vmovaps [rsp+0x20], xmm2
0000785dab1db66e  vmovaps [rsp+0x30], xmm3
0000785dab1db674  vmovaps [rsp+0x40], xmm4
0000785dab1db67a  vmovaps [rsp+0x50], xmm5
0000785dab1db680  vmovaps [rsp+0x60], xmm6
0000785dab1db686  vmovaps [rsp+0x70], xmm7
0000785dab1db68c  vmovaps [rsp+0x80], xmm8
0000785dab1db695  vmovaps [rsp+0x90], xmm9
0000785dab1db69e  vmovaps [rsp+0xA0], xmm10
0000785dab1db6a7  vmovaps [rsp+0xB0], xmm11
0000785dab1db6b0  vmovaps [rsp+0xC0], xmm12
0000785dab1db6b9  vmovaps [rsp+0xD0], xmm13
0000785dab1db6c2  vmovaps [rsp+0xE0], xmm15
0000785dab1db6cb  sub rsp, 0x30
0000785dab1db6cf  movaps [rsp], xmm14
0000785dab1db6d4  movaps [rsp+0x10], xmm1
0000785dab1db6d9  movaps [rsp+0x20], xmm7
0000785dab1db6de  lea rdi, [rsp]
0000785dab1db6e2  mov esi, 0x00
0000785dab1db6e7  mov rax, 0x61B13BBD6530
0000785dab1db6f1  call rax
0000785dab1db6f3  movaps xmm14, [rsp]
0000785dab1db6f8  add rsp, 0x30
0000785dab1db6fc  vmovaps xmm0, [rsp]
0000785dab1db701  vmovaps xmm1, [rsp+0x10]
0000785dab1db707  vmovaps xmm2, [rsp+0x20]
0000785dab1db70d  vmovaps xmm3, [rsp+0x30]
0000785dab1db713  vmovaps xmm4, [rsp+0x40]
0000785dab1db719  vmovaps xmm5, [rsp+0x50]
0000785dab1db71f  vmovaps xmm6, [rsp+0x60]
0000785dab1db725  vmovaps xmm7, [rsp+0x70]
0000785dab1db72b  vmovaps xmm8, [rsp+0x80]
0000785dab1db734  vmovaps xmm9, [rsp+0x90]
0000785dab1db73d  vmovaps xmm10, [rsp+0xA0]
0000785dab1db746  vmovaps xmm11, [rsp+0xB0]
0000785dab1db74f  vmovaps xmm12, [rsp+0xC0]
0000785dab1db758  vmovaps xmm13, [rsp+0xD0]
0000785dab1db761  vmovaps xmm15, [rsp+0xE0]
0000785dab1db76a  add rsp, 0xF0
0000785dab1db771  pop r11
0000785dab1db773  pop r10
0000785dab1db775  pop r9
0000785dab1db777  pop r8
0000785dab1db779  pop rsi
0000785dab1db77a  pop rdi
0000785dab1db77b  pop rdx
0000785dab1db77c  pop rcx
0000785dab1db77d  pop rax
0000785dab1db77e  add rsp, 0x08
0000785dab1db782  jmp 0x0000785DAB1D6690
0000785dab1db787  sub rsp, 0x08
0000785dab1db78b  push rax
0000785dab1db78c  push rcx
0000785dab1db78d  push rdx
0000785dab1db78e  push rdi
0000785dab1db78f  push rsi
0000785dab1db790  push r8
0000785dab1db792  push r9
0000785dab1db794  push r10
0000785dab1db796  push r11
0000785dab1db798  sub rsp, 0xF0
0000785dab1db79f  vmovaps [rsp], xmm0
0000785dab1db7a4  vmovaps [rsp+0x10], xmm2
0000785dab1db7aa  vmovaps [rsp+0x20], xmm3
0000785dab1db7b0  vmovaps [rsp+0x30], xmm4
0000785dab1db7b6  vmovaps [rsp+0x40], xmm5
0000785dab1db7bc  vmovaps [rsp+0x50], xmm6
0000785dab1db7c2  vmovaps [rsp+0x60], xmm7
0000785dab1db7c8  vmovaps [rsp+0x70], xmm8
0000785dab1db7ce  vmovaps [rsp+0x80], xmm9
0000785dab1db7d7  vmovaps [rsp+0x90], xmm10
0000785dab1db7e0  vmovaps [rsp+0xA0], xmm11
0000785dab1db7e9  vmovaps [rsp+0xB0], xmm12
0000785dab1db7f2  vmovaps [rsp+0xC0], xmm13
0000785dab1db7fb  vmovaps [rsp+0xD0], xmm14
0000785dab1db804  vmovaps [rsp+0xE0], xmm15
0000785dab1db80d  sub rsp, 0x30
0000785dab1db811  movaps [rsp], xmm1
0000785dab1db815  movaps [rsp+0x10], xmm8
0000785dab1db81b  movaps [rsp+0x20], xmm9
0000785dab1db821  lea rdi, [rsp]
0000785dab1db825  mov esi, 0x00
0000785dab1db82a  mov rax, 0x61B13BBD6530
0000785dab1db834  call rax
0000785dab1db836  movaps xmm1, [rsp]
0000785dab1db83a  add rsp, 0x30
0000785dab1db83e  vmovaps xmm0, [rsp]
0000785dab1db843  vmovaps xmm2, [rsp+0x10]
0000785dab1db849  vmovaps xmm3, [rsp+0x20]
0000785dab1db84f  vmovaps xmm4, [rsp+0x30]
0000785dab1db855  vmovaps xmm5, [rsp+0x40]
0000785dab1db85b  vmovaps xmm6, [rsp+0x50]
0000785dab1db861  vmovaps xmm7, [rsp+0x60]
0000785dab1db867  vmovaps xmm8, [rsp+0x70]
0000785dab1db86d  vmovaps xmm9, [rsp+0x80]
0000785dab1db876  vmovaps xmm10, [rsp+0x90]
0000785dab1db87f  vmovaps xmm11, [rsp+0xA0]
0000785dab1db888  vmovaps xmm12, [rsp+0xB0]
0000785dab1db891  vmovaps xmm13, [rsp+0xC0]
0000785dab1db89a  vmovaps xmm14, [rsp+0xD0]
0000785dab1db8a3  vmovaps xmm15, [rsp+0xE0]
0000785dab1db8ac  add rsp, 0xF0
0000785dab1db8b3  pop r11
0000785dab1db8b5  pop r10
0000785dab1db8b7  pop r9
0000785dab1db8b9  pop r8
0000785dab1db8bb  pop rsi
0000785dab1db8bc  pop rdi
0000785dab1db8bd  pop rdx
0000785dab1db8be  pop rcx
0000785dab1db8bf  pop rax
0000785dab1db8c0  add rsp, 0x08
0000785dab1db8c4  jmp 0x0000785DAB1D66B2
0000785dab1db8c9  call 0x0000785DAB0B3E40
0000785dab1db8ce  jmp 0x0000785DAB1D66C0
0000785dab1db8d3  call 0x0000785DAB00C380
0000785dab1db8d8  jmp 0x0000785DAB1D66CA
0000785dab1db8dd  call 0x0000785DAB00D600
0000785dab1db8e2  jmp 0x0000785DAB1D66D4
0000785dab1db8e7  call 0x0000785DAAFFF540
0000785dab1db8ec  jmp 0x0000785DAB1D66DE
0000785dab1db8f1  int3
0000785dab1db8f2  nop [rax+rax*1], ax
0000785dab1db8fb  nop [rax+rax*1], eax
0000785dab1db900  mov eax, [r15+0x48]
0000785dab1db904  lea r14d, [eax+0x01]
0000785dab1db909  mov [rsp+0x10], r14d
0000785dab1db90e  mov r14d, r14d
0000785dab1db911  mov [r15+0x48], r14
0000785dab1db915  xor eax, eax
0000785dab1db917  mov r14d, [rsp+0x10]
0000785dab1db91c  cmp r14d, 0x1F4
0000785dab1db923  cmc
0000785dab1db924  lahf
0000785dab1db925  seto al
0000785dab1db928  mov [r15+0x108], eax
0000785dab1db92f  mov eax, [r15+0x108]
0000785dab1db936  sahf
0000785dab1db937  jnz 0x0000785DAB1DB969
0000785dab1db939  cmp dword ptr [r15+0x318], 0x00
0000785dab1db941  jz 0x0000785DAB1E1AB0
0000785dab1db947  nop [rax+rax*1], ax
0000785dab1db950  nop [rax+rax*1], eax
0000785dab1db958  mov eax, 0x410450
0000785dab1db95d  mov [r15+0x100], rax
0000785dab1db964  jmp 0x0000785DAAFFE110
0000785dab1db969  cmp dword ptr [r15+0x318], 0x00
0000785dab1db971  jz 0x0000785DAB1DB9A0
0000785dab1db977  nop [rax+rax*1], ax
0000785dab1db980  nop [rax+rax*1], eax
0000785dab1db988  mov eax, 0x410274
0000785dab1db98d  mov [r15+0x100], rax
0000785dab1db994  jmp 0x0000785DAAFFE110
0000785dab1db999  int3
0000785dab1db99a  int3
0000785dab1db99b  nop [rax+rax*1], eax
0000785dab1db9a0  mov rax, [r15+0x40]
0000785dab1db9a4  movaps xmm1, [r15+0x1D0]
0000785dab1db9ac  vmovaps [rsp+0x10], xmm1
0000785dab1db9b2  vmovaps xmm15, [rsp+0x10]
0000785dab1db9b8  por xmm1, xmm15
0000785dab1db9bd  movaps xmm14, [r15+0x1A0]
0000785dab1db9c5  vmovaps [rsp+0x10], xmm14
0000785dab1db9cb  vmovaps xmm13, [rsp+0x10]
0000785dab1db9d1  por xmm14, xmm13
0000785dab1db9d6  lea r14, [rax+0x30]
0000785dab1db9da  mov r12, [r13+r14*1]
0000785dab1db9df  lea r14, [rax+0x38]
0000785dab1db9e3  mov r11, [r13+r14*1]
0000785dab1db9e8  movq xmm13, r12
0000785dab1db9ed  movq xmm12, r11
0000785dab1db9f2  movq xmm13, xmm13
0000785dab1db9f7  vmovaps [rsp+0x10], xmm13
0000785dab1db9fd  movq xmm13, xmm13
0000785dab1dba02  movaps [r15+0x130], xmm13
0000785dab1dba0a  movq xmm12, xmm12
0000785dab1dba0f  vmovaps [rsp+0x20], xmm12
0000785dab1dba15  movq xmm12, xmm12
0000785dab1dba1a  movaps [r15+0x280], xmm12
0000785dab1dba22  movaps xmm13, [r15+0x270]
0000785dab1dba2a  vmovaps [rsp+0x30], xmm13
0000785dab1dba30  vmovaps xmm12, [rsp+0x30]
0000785dab1dba36  por xmm13, xmm12
0000785dab1dba3b  lea r14, [rax+0x20]
0000785dab1dba3f  mov r12, [r13+r14*1]
0000785dab1dba44  lea r14, [rax+0x28]
0000785dab1dba48  mov r11, [r13+r14*1]
0000785dab1dba4d  movq xmm12, r12
0000785dab1dba52  movq xmm11, r11
0000785dab1dba57  movq xmm12, xmm12
0000785dab1dba5c  vmovaps [rsp+0x30], xmm12
0000785dab1dba62  movq xmm12, xmm12
0000785dab1dba67  movaps [r15+0x150], xmm12
0000785dab1dba6f  movq xmm11, xmm11
0000785dab1dba74  vmovaps [rsp+0x40], xmm11
0000785dab1dba7a  movq xmm11, xmm11
0000785dab1dba7f  movaps [r15+0x140], xmm11
0000785dab1dba87  lea r14, [rax+0x10]
0000785dab1dba8b  mov r12, [r13+r14*1]
0000785dab1dba90  lea r14, [rax+0x18]
0000785dab1dba94  mov r11, [r13+r14*1]
0000785dab1dba99  movq xmm12, r12
0000785dab1dba9e  movq xmm11, r11
0000785dab1dbaa3  movq xmm12, xmm12
0000785dab1dbaa8  vmovaps [rsp+0x50], xmm12
0000785dab1dbaae  movq xmm12, xmm12
0000785dab1dbab3  movaps [r15+0x170], xmm12
0000785dab1dbabb  movq xmm11, xmm11
0000785dab1dbac0  vmovaps [rsp+0x60], xmm11
0000785dab1dbac6  movq xmm11, xmm11
0000785dab1dbacb  movaps [r15+0x160], xmm11
0000785dab1dbad3  mov r14, [r13+rax*1]
0000785dab1dbad8  vmovq xmm12, r14
0000785dab1dbadd  vpbroadcastq xmm12, xmm12
0000785dab1dbae2  lea r14, [rax+0x08]
0000785dab1dbae6  mov rax, [r13+r14*1]
0000785dab1dbaeb  movq xmm11, rax
0000785dab1dbaf0  movaps [r15+0x230], xmm11
0000785dab1dbaf8  mov rax, [r15+0xF8]
0000785dab1dbaff  lea r14, [rax+0x50]
0000785dab1dbb03  movups xmm11, [r13+r14*1]
0000785dab1dbb09  lea r14, [rax+0x60]
0000785dab1dbb0d  movups xmm10, [r13+r14*1]
0000785dab1dbb13  lea r14, [rax+0x30]
0000785dab1dbb17  movups xmm9, [r13+r14*1]
0000785dab1dbb1d  mov r14, [r15+0x50]
0000785dab1dbb21  mov [r15+0x60], r14
0000785dab1dbb25  mov qword ptr [r15+0x58], 0x40
0000785dab1dbb2d  movaps xmm8, xmm12
0000785dab1dbb31  mulpd xmm8, xmm15
0000785dab1dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000785dab1dbb3c  ptest xmm7, xmm7
0000785dab1dbb41  jnz 0x0000785DAB1DC96A
0000785dab1dbb47  movq xmm15, qword ptr [r15+0x230]
0000785dab1dbb50  vmovaps [rsp+0x70], xmm15
0000785dab1dbb56  vpermilpd xmm15, xmm15, 0x00
0000785dab1dbb5c  movaps xmm7, xmm9
0000785dab1dbb60  mulpd xmm7, xmm15
0000785dab1dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000785dab1dbb6a  ptest xmm6, xmm6
0000785dab1dbb6f  jnz 0x0000785DAB1DCAAE
0000785dab1dbb75  vxorps xmm15, xmm15, xmm15
0000785dab1dbb7a  vpbroadcastq xmm15, xmm15
0000785dab1dbb7f  movaps xmm9, xmm12
0000785dab1dbb83  mulpd xmm9, xmm10
0000785dab1dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000785dab1dbb8e  ptest xmm6, xmm6
0000785dab1dbb93  jnz 0x0000785DAB1DCBF0
0000785dab1dbb99  movaps xmm10, xmm12
0000785dab1dbb9d  mulpd xmm10, xmm11
0000785dab1dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000785dab1dbba8  ptest xmm6, xmm6
0000785dab1dbbad  jnz 0x0000785DAB1DCD34
0000785dab1dbbb3  movaps xmm11, [r15+0x1F0]
0000785dab1dbbbb  movaps xmm6, xmm12
0000785dab1dbbbf  mulpd xmm6, xmm11
0000785dab1dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000785dab1dbbc9  ptest xmm5, xmm5
0000785dab1dbbce  jnz 0x0000785DAB1DCE78
0000785dab1dbbd4  movaps xmm12, [r15+0x2A0]
0000785dab1dbbdc  vmovaps [rsp+0x80], xmm12
0000785dab1dbbe5  vmovaps xmm11, [rsp+0x80]
0000785dab1dbbee  por xmm12, xmm11
0000785dab1dbbf3  movaps xmm11, [r15+0x250]
0000785dab1dbbfb  vmovaps [rsp+0x80], xmm11
0000785dab1dbc04  vmovaps xmm5, [rsp+0x80]
0000785dab1dbc0d  por xmm11, xmm5
0000785dab1dbc12  vmovaps xmm4, [rsp+0x70]
0000785dab1dbc18  vpermilpd xmm4, xmm4, 0x00
0000785dab1dbc1e  movaps xmm3, xmm5
0000785dab1dbc21  mulpd xmm3, xmm4
0000785dab1dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000785dab1dbc2a  ptest xmm2, xmm2
0000785dab1dbc2f  jnz 0x0000785DAB1DCFBA
0000785dab1dbc35  mov [rsp+0x80], rax
0000785dab1dbc3d  xor eax, eax
0000785dab1dbc3f  mov r12d, 0x40
0000785dab1dbc45  mov r11d, 0x200
0000785dab1dbc4b  cmp r12, r11
0000785dab1dbc4e  cmc
0000785dab1dbc4f  lahf
0000785dab1dbc50  seto al
0000785dab1dbc53  mov [r15+0x108], eax
0000785dab1dbc5a  movaps xmm5, xmm8
0000785dab1dbc5e  addpd xmm5, xmm15
0000785dab1dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000785dab1dbc68  ptest xmm4, xmm4
0000785dab1dbc6d  jnz 0x0000785DAB1DD0FA
0000785dab1dbc73  movaps xmm8, [r15+0x1B0]
0000785dab1dbc7b  movaps xmm4, xmm9
0000785dab1dbc7f  addpd xmm4, xmm8
0000785dab1dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000785dab1dbc89  ptest xmm2, xmm2
0000785dab1dbc8e  jnz 0x0000785DAB1DD23C
0000785dab1dbc94  movaps xmm9, xmm10
0000785dab1dbc98  addpd xmm9, xmm8
0000785dab1dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000785dab1dbca3  ptest xmm2, xmm2
0000785dab1dbca8  jnz 0x0000785DAB1DD37E
0000785dab1dbcae  movaps xmm10, [r15+0x2F0]
0000785dab1dbcb6  vmovaps [rsp+0x90], xmm10
0000785dab1dbcbf  vmovaps xmm8, [rsp+0x90]
0000785dab1dbcc8  por xmm10, xmm8
0000785dab1dbccd  movaps xmm8, [r15+0x2E0]
0000785dab1dbcd5  vmovaps [rsp+0x90], xmm8
0000785dab1dbcde  vmovaps xmm2, [rsp+0x90]
0000785dab1dbce7  por xmm8, xmm2
0000785dab1dbcec  movaps xmm2, [r15+0x2D0]
0000785dab1dbcf4  vmovaps [rsp+0x90], xmm2
0000785dab1dbcfd  vmovaps [rsp+0xA0], xmm1
0000785dab1dbd06  vmovaps xmm1, [rsp+0x90]
0000785dab1dbd0f  por xmm2, xmm1
0000785dab1dbd13  movaps xmm1, [r15+0x200]
0000785dab1dbd1b  vmovaps [rsp+0x90], xmm1
0000785dab1dbd24  vmovaps [rsp+0xB0], xmm15
0000785dab1dbd2d  vmovaps xmm15, [rsp+0x90]
0000785dab1dbd36  por xmm1, xmm15
0000785dab1dbd3b  movaps xmm15, [r15+0x1C0]
0000785dab1dbd43  vmovaps [rsp+0x90], xmm15
0000785dab1dbd4c  vmovaps [rsp+0xC0], xmm1
0000785dab1dbd55  vmovaps xmm1, [rsp+0x90]
0000785dab1dbd5e  por xmm15, xmm1
0000785dab1dbd63  movaps xmm1, [r15+0x190]
0000785dab1dbd6b  vmovaps [rsp+0x90], xmm1
0000785dab1dbd74  vmovaps [rsp+0xD0], xmm15
0000785dab1dbd7d  vmovaps xmm15, [rsp+0x90]
0000785dab1dbd86  por xmm1, xmm15
0000785dab1dbd8b  movaps xmm15, [r15+0x300]
0000785dab1dbd93  vmovaps [rsp+0x90], xmm15
0000785dab1dbd9c  vmovaps [rsp+0xE0], xmm1
0000785dab1dbda5  vmovaps xmm1, [rsp+0x90]
0000785dab1dbdae  por xmm15, xmm1
0000785dab1dbdb3  mov rax, [rsp+0x80]
0000785dab1dbdbb  lea r12, [rax+0xA0]
0000785dab1dbdc2  movups xmm1, [r13+r12*1]
0000785dab1dbdc8  lea r12, [rax+0xB0]
0000785dab1dbdcf  vmovaps [rsp+0x80], xmm1
0000785dab1dbdd8  movups xmm1, [r13+r12*1]
0000785dab1dbdde  vmovaps [rsp+0x90], xmm1
0000785dab1dbde7  vmovaps [rsp+0xF0], xmm15
0000785dab1dbdf0  vmovaps xmm15, [rsp+0xB0]
0000785dab1dbdf9  vmovaps [rsp+0xB0], xmm14
0000785dab1dbe02  movaps xmm1, xmm6
0000785dab1dbe05  addpd xmm1, xmm15
0000785dab1dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000785dab1dbe0f  ptest xmm14, xmm14
0000785dab1dbe15  jnz 0x0000785DAB1DD4D6
0000785dab1dbe1b  lea r12, [rax+0xF0]
0000785dab1dbe22  movups xmm15, [r13+r12*1]
0000785dab1dbe28  movaps xmm14, xmm4
0000785dab1dbe2c  addpd xmm14, xmm3
0000785dab1dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000785dab1dbe37  ptest xmm6, xmm6
0000785dab1dbe3c  jnz 0x0000785DAB1DD621
0000785dab1dbe42  movaps xmm6, xmm9
0000785dab1dbe46  addpd xmm6, xmm7
0000785dab1dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000785dab1dbe4f  ptest xmm4, xmm4
0000785dab1dbe54  jnz 0x0000785DAB1DD763
0000785dab1dbe5a  vmovaps xmm9, [rsp+0x70]
0000785dab1dbe60  vpermilpd xmm9, xmm9, 0x00
0000785dab1dbe66  vmovaps xmm4, [rsp+0x90]
0000785dab1dbe6f  movaps xmm7, xmm4
0000785dab1dbe72  mulpd xmm7, xmm9
0000785dab1dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000785dab1dbe7c  ptest xmm3, xmm3
0000785dab1dbe81  jnz 0x0000785DAB1DD8A4
0000785dab1dbe87  vmovaps xmm9, [rsp+0x50]
0000785dab1dbe8d  vpermilpd xmm9, xmm9, 0x00
0000785dab1dbe93  movaps xmm4, xmm15
0000785dab1dbe97  mulpd xmm4, xmm9
0000785dab1dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000785dab1dbea1  ptest xmm3, xmm3
0000785dab1dbea6  jnz 0x0000785DAB1DD9E5
0000785dab1dbeac  lea r12, [rax+0xE0]
0000785dab1dbeb3  movups xmm15, [r13+r12*1]
0000785dab1dbeb9  vmovaps xmm9, [rsp+0x70]
0000785dab1dbebf  vpermilpd xmm9, xmm9, 0x00
0000785dab1dbec5  vmovaps [rsp+0x70], xmm1
0000785dab1dbecb  vmovaps xmm1, [rsp+0x80]
0000785dab1dbed4  vmovaps [rsp+0x80], xmm15
0000785dab1dbedd  movaps xmm3, xmm1
0000785dab1dbee0  mulpd xmm3, xmm9
0000785dab1dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000785dab1dbeea  ptest xmm15, xmm15
0000785dab1dbef0  jnz 0x0000785DAB1DDB31
0000785dab1dbef6  vmovaps xmm1, [rsp+0xF0]
0000785dab1dbeff  vmovaps xmm15, [rsp+0xF0]
0000785dab1dbf08  por xmm1, xmm15
0000785dab1dbf0d  movaps [r15+0x300], xmm1
0000785dab1dbf15  vmovaps xmm15, [rsp+0xE0]
0000785dab1dbf1e  vmovaps xmm9, [rsp+0xE0]
0000785dab1dbf27  por xmm15, xmm9
0000785dab1dbf2c  movaps [r15+0x190], xmm15
0000785dab1dbf34  vmovaps xmm9, [rsp+0x50]
0000785dab1dbf3a  vpermilpd xmm9, xmm9, 0x00
0000785dab1dbf40  vmovaps [rsp+0x90], xmm1
0000785dab1dbf49  vmovaps [rsp+0xE0], xmm15
0000785dab1dbf52  vmovaps xmm15, [rsp+0x80]
0000785dab1dbf5b  vmovaps [rsp+0x80], xmm14
0000785dab1dbf64  movaps xmm1, xmm15
0000785dab1dbf68  mulpd xmm1, xmm9
0000785dab1dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000785dab1dbf72  ptest xmm14, xmm14
0000785dab1dbf78  jnz 0x0000785DAB1DDC72
0000785dab1dbf7e  lea r12, [rax+0x90]
0000785dab1dbf85  movups xmm15, [r13+r12*1]
0000785dab1dbf8b  vmovaps xmm14, [rsp+0xD0]
0000785dab1dbf94  vmovaps xmm9, [rsp+0xD0]
0000785dab1dbf9d  por xmm14, xmm9
0000785dab1dbfa2  movaps [r15+0x1C0], xmm14
0000785dab1dbfaa  vmovaps xmm9, [rsp+0xC0]
0000785dab1dbfb3  vmovaps [rsp+0xD0], xmm1
0000785dab1dbfbc  vmovaps xmm1, [rsp+0xC0]
0000785dab1dbfc5  por xmm9, xmm1
0000785dab1dbfca  movaps [r15+0x200], xmm9
0000785dab1dbfd2  vmovaps [rsp+0xC0], xmm2
0000785dab1dbfdb  vmovaps xmm1, [rsp+0xC0]
0000785dab1dbfe4  por xmm2, xmm1
0000785dab1dbfe8  movaps [r15+0x2D0], xmm2
0000785dab1dbff0  vmovaps [rsp+0xC0], xmm8
0000785dab1dbff9  vmovaps xmm1, [rsp+0xC0]
0000785dab1dc002  por xmm8, xmm1
0000785dab1dc007  movaps [r15+0x2E0], xmm8
0000785dab1dc00f  vmovaps [rsp+0xC0], xmm15
0000785dab1dc018  movaps xmm1, xmm5
0000785dab1dc01b  addpd xmm1, xmm7
0000785dab1dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000785dab1dc024  ptest xmm15, xmm15
0000785dab1dc02a  jnz 0x0000785DAB1DDDBE
0000785dab1dc030  vmovaps xmm15, [rsp+0x50]
0000785dab1dc036  vpermilpd xmm15, xmm15, 0x00
0000785dab1dc03c  vmovaps xmm5, [rsp+0xC0]
0000785dab1dc045  vmovaps [rsp+0xC0], xmm1
0000785dab1dc04e  movaps xmm7, xmm5
0000785dab1dc051  mulpd xmm7, xmm15
0000785dab1dc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000785dab1dc05b  ptest xmm1, xmm1
0000785dab1dc060  jnz 0x0000785DAB1DDEFE
0000785dab1dc066  lea r12, [rax+0x80]
0000785dab1dc06d  movups xmm1, [r13+r12*1]
0000785dab1dc073  vmovaps xmm5, [rsp+0x70]
0000785dab1dc079  vmovaps [rsp+0x70], xmm1
0000785dab1dc07f  movaps xmm15, xmm5
0000785dab1dc083  addpd xmm15, xmm3
0000785dab1dc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000785dab1dc08e  ptest xmm1, xmm1
0000785dab1dc093  jnz 0x0000785DAB1DE049
0000785dab1dc099  vmovaps xmm5, [rsp+0x80]
0000785dab1dc0a2  movaps xmm1, xmm5
0000785dab1dc0a5  addpd xmm1, xmm4
0000785dab1dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000785dab1dc0ae  ptest xmm3, xmm3
0000785dab1dc0b3  jnz 0x0000785DAB1DE18B
0000785dab1dc0b9  vmovaps [rsp+0x80], xmm10
0000785dab1dc0c2  vmovaps xmm5, [rsp+0x80]
0000785dab1dc0cb  por xmm10, xmm5
0000785dab1dc0d0  movaps [r15+0x2F0], xmm10
0000785dab1dc0d8  vmovaps xmm5, [rsp+0x50]
0000785dab1dc0de  vpermilpd xmm5, xmm5, 0x00
0000785dab1dc0e4  vmovaps xmm3, [rsp+0x70]
0000785dab1dc0ea  vmovaps [rsp+0x50], xmm1
0000785dab1dc0f0  movaps xmm4, xmm3
0000785dab1dc0f3  mulpd xmm4, xmm5
0000785dab1dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000785dab1dc0fc  ptest xmm1, xmm1
0000785dab1dc101  jnz 0x0000785DAB1DE2CB
0000785dab1dc107  lea r12, [rax+0xD0]
0000785dab1dc10e  movups xmm1, [r13+r12*1]
0000785dab1dc114  vmovaps xmm3, [rsp+0xD0]
0000785dab1dc11d  vmovaps [rsp+0x70], xmm1
0000785dab1dc123  movaps xmm5, xmm6
0000785dab1dc126  addpd xmm5, xmm3
0000785dab1dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000785dab1dc12f  ptest xmm1, xmm1
0000785dab1dc134  jnz 0x0000785DAB1DE415
0000785dab1dc13a  vmovaps xmm1, [rsp+0x60]
0000785dab1dc140  vpermilpd xmm1, xmm1, 0x00
0000785dab1dc146  movaps xmm6, xmm9
0000785dab1dc14a  mulpd xmm6, xmm1
0000785dab1dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000785dab1dc153  ptest xmm3, xmm3
0000785dab1dc158  jnz 0x0000785DAB1DE555
0000785dab1dc15e  movaps [r15+0x260], xmm6
0000785dab1dc166  vxorps xmm1, xmm1, xmm1
0000785dab1dc16a  vpbroadcastq xmm1, xmm1
0000785dab1dc16f  movaps [r15+0x1B0], xmm1
0000785dab1dc177  vmovaps xmm1, [rsp+0x60]
0000785dab1dc17d  vpermilpd xmm1, xmm1, 0x00
0000785dab1dc183  vmovaps xmm3, [rsp+0x70]
0000785dab1dc189  vmovaps [rsp+0x70], xmm15
0000785dab1dc18f  movaps xmm9, xmm3
0000785dab1dc193  mulpd xmm9, xmm1
0000785dab1dc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000785dab1dc19e  ptest xmm15, xmm15
0000785dab1dc1a4  jnz 0x0000785DAB1DE696
0000785dab1dc1aa  lea r12, [rax+0xC0]
0000785dab1dc1b1  movups xmm1, [r13+r12*1]
0000785dab1dc1b7  vmovaps xmm3, [rsp+0xC0]
0000785dab1dc1c0  vmovaps [rsp+0x80], xmm1
0000785dab1dc1c9  movaps xmm15, xmm3
0000785dab1dc1cd  addpd xmm15, xmm7
0000785dab1dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000785dab1dc1d8  ptest xmm1, xmm1
0000785dab1dc1dd  jnz 0x0000785DAB1DE7E2
0000785dab1dc1e3  vmovaps [rsp+0xC0], xmm13
0000785dab1dc1ec  vmovaps xmm1, [rsp+0xC0]
0000785dab1dc1f5  por xmm13, xmm1
0000785dab1dc1fa  movaps [r15+0x270], xmm13
0000785dab1dc202  vmovaps xmm1, [rsp+0xB0]
0000785dab1dc20b  vmovaps xmm7, [rsp+0xB0]
0000785dab1dc214  por xmm1, xmm7
0000785dab1dc218  movaps [r15+0x1A0], xmm1
0000785dab1dc220  vmovaps xmm1, [rsp+0x60]
0000785dab1dc226  vpermilpd xmm1, xmm1, 0x00
0000785dab1dc22c  vmovaps [rsp+0xB0], xmm1
0000785dab1dc235  vmovaps xmm1, [rsp+0x80]
0000785dab1dc23e  vmovaps [rsp+0x80], xmm15
0000785dab1dc247  vmovaps xmm15, [rsp+0xB0]
0000785dab1dc250  vmovaps [rsp+0xB0], xmm14
0000785dab1dc259  movaps xmm3, xmm1
0000785dab1dc25c  mulpd xmm3, xmm15
0000785dab1dc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000785dab1dc266  ptest xmm14, xmm14
0000785dab1dc26c  jnz 0x0000785DAB1DE924
0000785dab1dc272  lea r12, [rax+0x20]
0000785dab1dc276  movups xmm1, [r13+r12*1]
0000785dab1dc27c  movaps [r15+0x110], xmm1
0000785dab1dc284  vmovaps xmm14, [rsp+0x70]
0000785dab1dc28a  vmovaps [rsp+0x70], xmm1
0000785dab1dc290  movaps xmm15, xmm14
0000785dab1dc294  addpd xmm15, xmm4
0000785dab1dc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000785dab1dc29f  ptest xmm1, xmm1
0000785dab1dc2a4  jnz 0x0000785DAB1DEA6F
0000785dab1dc2aa  vmovaps xmm1, [rsp+0x60]
0000785dab1dc2b0  vpermilpd xmm1, xmm1, 0x00
0000785dab1dc2b6  movaps xmm14, xmm2
0000785dab1dc2ba  mulpd xmm14, xmm1
0000785dab1dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000785dab1dc2c5  ptest xmm4, xmm4
0000785dab1dc2ca  jnz 0x0000785DAB1DEBB2
0000785dab1dc2d0  vmovaps xmm4, [rsp+0x50]
0000785dab1dc2d6  movaps xmm1, xmm4
0000785dab1dc2d9  addpd xmm1, xmm9
0000785dab1dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000785dab1dc2e3  ptest xmm2, xmm2
0000785dab1dc2e8  jnz 0x0000785DAB1DECF4
0000785dab1dc2ee  vmovaps xmm9, [rsp+0x30]
0000785dab1dc2f4  vpermilpd xmm9, xmm9, 0x00
0000785dab1dc2fa  vmovaps xmm2, [rsp+0x70]
0000785dab1dc300  vmovaps [rsp+0x50], xmm1
0000785dab1dc306  movaps xmm4, xmm2
0000785dab1dc309  mulpd xmm4, xmm9
0000785dab1dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000785dab1dc313  ptest xmm1, xmm1
0000785dab1dc318  jnz 0x0000785DAB1DEE35
0000785dab1dc31e  vmovaps xmm1, [rsp+0x30]
0000785dab1dc324  vpermilpd xmm1, xmm1, 0x00
0000785dab1dc32a  vmovaps xmm2, [rsp+0x90]
0000785dab1dc333  vmovaps [rsp+0x60], xmm15
0000785dab1dc339  movaps xmm9, xmm2
0000785dab1dc33d  mulpd xmm9, xmm1
0000785dab1dc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000785dab1dc348  ptest xmm15, xmm15
0000785dab1dc34e  jnz 0x0000785DAB1DEF76
0000785dab1dc354  vmovaps xmm15, [rsp+0x80]
0000785dab1dc35d  movaps xmm1, xmm15
0000785dab1dc361  addpd xmm1, xmm6
0000785dab1dc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000785dab1dc36a  ptest xmm2, xmm2
0000785dab1dc36f  jnz 0x0000785DAB1DF0B8
0000785dab1dc375  movaps xmm15, xmm5
0000785dab1dc379  addpd xmm15, xmm3
0000785dab1dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000785dab1dc384  ptest xmm6, xmm6
0000785dab1dc389  jnz 0x0000785DAB1DF1F9
0000785dab1dc38f  vmovaps xmm6, [rsp+0x30]
0000785dab1dc395  vpermilpd xmm6, xmm6, 0x00
0000785dab1dc39b  movaps xmm5, xmm8
0000785dab1dc39f  mulpd xmm5, xmm6
0000785dab1dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000785dab1dc3a8  ptest xmm3, xmm3
0000785dab1dc3ad  jnz 0x0000785DAB1DF33B
0000785dab1dc3b3  vmovaps xmm8, [rsp+0x30]
0000785dab1dc3b9  vpermilpd xmm8, xmm8, 0x00
0000785dab1dc3bf  movaps xmm6, xmm10
0000785dab1dc3c3  mulpd xmm6, xmm8
0000785dab1dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000785dab1dc3cd  ptest xmm3, xmm3
0000785dab1dc3d2  jnz 0x0000785DAB1DF47C
0000785dab1dc3d8  vmovaps xmm8, [rsp+0x60]
0000785dab1dc3de  movaps xmm10, xmm8
0000785dab1dc3e2  addpd xmm10, xmm14
0000785dab1dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000785dab1dc3ed  ptest xmm3, xmm3
0000785dab1dc3f2  jnz 0x0000785DAB1DF5BE
0000785dab1dc3f8  vmovaps xmm8, [rsp+0x50]
0000785dab1dc3fe  movaps xmm14, xmm8
0000785dab1dc402  addpd xmm14, xmm4
0000785dab1dc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000785dab1dc40d  ptest xmm3, xmm3
0000785dab1dc412  jnz 0x0000785DAB1DF702
0000785dab1dc418  vmovaps xmm8, [rsp+0x40]
0000785dab1dc41e  vpermilpd xmm8, xmm8, 0x00
0000785dab1dc424  movaps xmm4, xmm13
0000785dab1dc428  mulpd xmm4, xmm8
0000785dab1dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000785dab1dc432  ptest xmm3, xmm3
0000785dab1dc437  jnz 0x0000785DAB1DF845
0000785dab1dc43d  movaps xmm13, xmm15
0000785dab1dc441  addpd xmm13, xmm9
0000785dab1dc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000785dab1dc44c  ptest xmm8, xmm8
0000785dab1dc452  jnz 0x0000785DAB1DF987
0000785dab1dc458  movaps xmm15, xmm1
0000785dab1dc45c  addpd xmm15, xmm5
0000785dab1dc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000785dab1dc467  ptest xmm9, xmm9
0000785dab1dc46d  jnz 0x0000785DAB1DFACB
0000785dab1dc473  vmovaps [rsp+0x30], xmm11
0000785dab1dc479  vmovaps xmm1, [rsp+0x30]
0000785dab1dc47f  por xmm11, xmm1
0000785dab1dc484  movaps [r15+0x250], xmm11
0000785dab1dc48c  vmovaps [rsp+0x30], xmm12
0000785dab1dc492  vmovaps xmm1, [rsp+0x30]
0000785dab1dc498  por xmm12, xmm1
0000785dab1dc49d  movaps [r15+0x2A0], xmm12
0000785dab1dc4a5  vmovaps xmm1, [rsp+0xA0]
0000785dab1dc4ae  vmovaps xmm11, [rsp+0xA0]
0000785dab1dc4b7  por xmm1, xmm11
0000785dab1dc4bc  movaps [r15+0x1D0], xmm1
0000785dab1dc4c4  lea r12, [rax+0x40]
0000785dab1dc4c8  movups xmm1, [r13+r12*1]
0000785dab1dc4ce  movaps [r15+0x2C0], xmm1
0000785dab1dc4d6  vmovaps xmm11, [rsp+0x40]
0000785dab1dc4dc  vpermilpd xmm11, xmm11, 0x00
0000785dab1dc4e2  vmovaps xmm8, [rsp+0xE0]
0000785dab1dc4eb  movaps xmm9, xmm8
0000785dab1dc4ef  mulpd xmm9, xmm11
0000785dab1dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000785dab1dc4fa  ptest xmm5, xmm5
0000785dab1dc4ff  jnz 0x0000785DAB1DFC17
0000785dab1dc505  movaps xmm11, xmm10
0000785dab1dc509  addpd xmm11, xmm6
0000785dab1dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000785dab1dc514  ptest xmm8, xmm8
0000785dab1dc51a  jnz 0x0000785DAB1DFD5B
0000785dab1dc520  movaps xmm10, xmm14
0000785dab1dc524  addpd xmm10, xmm4
0000785dab1dc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000785dab1dc52f  ptest xmm8, xmm8
0000785dab1dc535  jnz 0x0000785DAB1DFE9E
0000785dab1dc53b  vmovaps xmm14, [rsp+0x40]
0000785dab1dc541  vpermilpd xmm14, xmm14, 0x00
0000785dab1dc547  movaps xmm8, xmm1
0000785dab1dc54b  mulpd xmm8, xmm14
0000785dab1dc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000785dab1dc556  ptest xmm6, xmm6
0000785dab1dc55b  jnz 0x0000785DAB1DFFE1
0000785dab1dc561  movaps xmm1, [r15+0x2B0]
0000785dab1dc569  vmovaps xmm14, [rsp+0x40]
0000785dab1dc56f  vpermilpd xmm14, xmm14, 0x00
0000785dab1dc575  movaps xmm6, xmm1
0000785dab1dc578  mulpd xmm6, xmm14
0000785dab1dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000785dab1dc582  ptest xmm5, xmm5
0000785dab1dc587  jnz 0x0000785DAB1E0124
0000785dab1dc58d  vmovaps xmm1, [rsp+0x10]
0000785dab1dc593  vpermilpd xmm1, xmm1, 0x00
0000785dab1dc599  movaps xmm14, xmm12
0000785dab1dc59d  mulpd xmm14, xmm1
0000785dab1dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000785dab1dc5a8  ptest xmm5, xmm5
0000785dab1dc5ad  jnz 0x0000785DAB1E0265
0000785dab1dc5b3  movaps xmm1, xmm13
0000785dab1dc5b7  addpd xmm1, xmm9
0000785dab1dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000785dab1dc5c1  ptest xmm12, xmm12
0000785dab1dc5c7  jnz 0x0000785DAB1E03A8
0000785dab1dc5cd  vmovaps xmm13, [rsp+0x10]
0000785dab1dc5d3  vpermilpd xmm13, xmm13, 0x00
0000785dab1dc5d9  movaps xmm12, xmm7
0000785dab1dc5dd  mulpd xmm12, xmm13
0000785dab1dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000785dab1dc5e8  ptest xmm9, xmm9
0000785dab1dc5ee  jnz 0x0000785DAB1E04EA
0000785dab1dc5f4  movaps xmm13, xmm15
0000785dab1dc5f8  addpd xmm13, xmm8
0000785dab1dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000785dab1dc603  ptest xmm9, xmm9
0000785dab1dc609  jnz 0x0000785DAB1E062D
0000785dab1dc60f  movaps xmm15, [r15+0x290]
0000785dab1dc617  vmovaps xmm9, [rsp+0x10]
0000785dab1dc61d  vpermilpd xmm9, xmm9, 0x00
0000785dab1dc623  movaps xmm8, xmm15
0000785dab1dc627  mulpd xmm8, xmm9
0000785dab1dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000785dab1dc632  ptest xmm7, xmm7
0000785dab1dc637  jnz 0x0000785DAB1E0771
0000785dab1dc63d  movaps xmm15, xmm11
0000785dab1dc641  addpd xmm15, xmm6
0000785dab1dc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000785dab1dc64c  ptest xmm9, xmm9
0000785dab1dc652  jnz 0x0000785DAB1E08B5
0000785dab1dc658  movaps xmm11, [r15+0x1E0]
0000785dab1dc660  vmovaps xmm9, [rsp+0x10]
0000785dab1dc666  vpermilpd xmm9, xmm9, 0x00
0000785dab1dc66c  movaps xmm7, xmm11
0000785dab1dc670  mulpd xmm7, xmm9
0000785dab1dc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000785dab1dc67a  ptest xmm6, xmm6
0000785dab1dc67f  jnz 0x0000785DAB1E09F8
0000785dab1dc685  movaps xmm11, xmm10
0000785dab1dc689  addpd xmm11, xmm14
0000785dab1dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000785dab1dc694  ptest xmm9, xmm9
0000785dab1dc69a  jnz 0x0000785DAB1E0B3A
0000785dab1dc6a0  lea r12, [rax+0x70]
0000785dab1dc6a4  movups xmm14, [r13+r12*1]
0000785dab1dc6aa  movaps [r15+0x240], xmm14
0000785dab1dc6b2  movaps xmm10, xmm1
0000785dab1dc6b6  addpd xmm10, xmm12
0000785dab1dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000785dab1dc6c1  ptest xmm9, xmm9
0000785dab1dc6c7  jnz 0x0000785DAB1E0C88
0000785dab1dc6cd  movaps [r15+0x170], xmm10
0000785dab1dc6d5  vmovaps xmm1, [rsp+0x20]
0000785dab1dc6db  vpermilpd xmm1, xmm1, 0x00
0000785dab1dc6e1  movaps xmm12, xmm14
0000785dab1dc6e5  mulpd xmm12, xmm1
0000785dab1dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000785dab1dc6f0  ptest xmm9, xmm9
0000785dab1dc6f6  jnz 0x0000785DAB1E0DCB
0000785dab1dc6fc  vmovaps xmm1, [rsp+0x20]
0000785dab1dc702  vpermilpd xmm1, xmm1, 0x00
0000785dab1dc708  vmovaps xmm9, [rsp+0xB0]
0000785dab1dc711  movaps xmm14, xmm9
0000785dab1dc715  mulpd xmm14, xmm1
0000785dab1dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000785dab1dc720  ptest xmm6, xmm6
0000785dab1dc725  jnz 0x0000785DAB1E0F0E
0000785dab1dc72b  movaps [r15+0x180], xmm14
0000785dab1dc733  movaps xmm1, xmm13
0000785dab1dc737  addpd xmm1, xmm8
0000785dab1dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000785dab1dc741  ptest xmm9, xmm9
0000785dab1dc747  jnz 0x0000785DAB1E1051
0000785dab1dc74d  movaps [r15+0x210], xmm1
0000785dab1dc755  movups xmm13, [r13+rax*1]
0000785dab1dc75b  lea r12, [rax+0x10]
0000785dab1dc75f  movups xmm9, [r13+r12*1]
0000785dab1dc765  movaps [r15+0x230], xmm9
0000785dab1dc76d  movaps xmm8, xmm15
0000785dab1dc771  addpd xmm8, xmm7
0000785dab1dc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000785dab1dc77c  ptest xmm6, xmm6
0000785dab1dc781  jnz 0x0000785DAB1E11A7
0000785dab1dc787  movaps [r15+0x130], xmm8
0000785dab1dc78f  vmovaps xmm15, [rsp+0x20]
0000785dab1dc795  vpermilpd xmm15, xmm15, 0x00
0000785dab1dc79b  movaps xmm7, xmm9
0000785dab1dc79f  mulpd xmm7, xmm15
0000785dab1dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000785dab1dc7a9  ptest xmm6, xmm6
0000785dab1dc7ae  jnz 0x0000785DAB1E12EA
0000785dab1dc7b4  movaps [r15+0x220], xmm7
0000785dab1dc7bc  vmovaps xmm15, [rsp+0x20]
0000785dab1dc7c2  vpermilpd xmm15, xmm15, 0x00
0000785dab1dc7c8  movaps xmm9, xmm13
0000785dab1dc7cc  mulpd xmm9, xmm15
0000785dab1dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000785dab1dc7d7  ptest xmm6, xmm6
0000785dab1dc7dc  jnz 0x0000785DAB1E142C
0000785dab1dc7e2  movaps xmm15, xmm11
0000785dab1dc7e6  addpd xmm15, xmm12
0000785dab1dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000785dab1dc7f1  ptest xmm13, xmm13
0000785dab1dc7f7  jnz 0x0000785DAB1E1570
0000785dab1dc7fd  movaps [r15+0x140], xmm15
0000785dab1dc805  movaps xmm13, xmm10
0000785dab1dc809  addpd xmm13, xmm14
0000785dab1dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000785dab1dc814  ptest xmm12, xmm12
0000785dab1dc81a  jnz 0x0000785DAB1E16B4
0000785dab1dc820  movaps [r15+0x150], xmm13
0000785dab1dc828  movaps xmm14, xmm1
0000785dab1dc82c  addpd xmm14, xmm7
0000785dab1dc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000785dab1dc837  ptest xmm12, xmm12
0000785dab1dc83d  jnz 0x0000785DAB1E17F8
0000785dab1dc843  movaps [r15+0x160], xmm14
0000785dab1dc84b  movaps xmm1, xmm8
0000785dab1dc84f  addpd xmm1, xmm9
0000785dab1dc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000785dab1dc859  ptest xmm12, xmm12
0000785dab1dc85f  jnz 0x0000785DAB1E193A
0000785dab1dc865  movaps [r15+0x120], xmm1
0000785dab1dc86d  movups [r13+r14*1], xmm15
0000785dab1dc873  lea rax, [r14+0x10]
0000785dab1dc877  movups [r13+rax*1], xmm13
0000785dab1dc87d  lea rax, [r14+0x20]
0000785dab1dc881  movups [r13+rax*1], xmm14
0000785dab1dc887  lea rax, [r14+0x30]
0000785dab1dc88b  movups [r13+rax*1], xmm1
0000785dab1dc891  mov eax, [r15+0x108]
0000785dab1dc898  sahf
0000785dab1dc899  jnz 0x0000785DAB1DC8CB
0000785dab1dc89b  cmp dword ptr [r15+0x318], 0x00
0000785dab1dc8a3  jz 0x0000785DAB1DB900
0000785dab1dc8a9  nop [rax+rax*1], ax
0000785dab1dc8b2  nop [rax+rax*1], eax
0000785dab1dc8ba  mov eax, 0x410444
0000785dab1dc8bf  mov [r15+0x100], rax
0000785dab1dc8c6  jmp 0x0000785DAAFFE110
0000785dab1dc8cb  cmp dword ptr [r15+0x318], 0x00
0000785dab1dc8d3  jz 0x0000785DAB1D57E0
0000785dab1dc8d9  nop [rax+rax*1], ax
0000785dab1dc8e2  nop [rax+rax*1], eax
0000785dab1dc8ea  mov eax, 0x410278
0000785dab1dc8ef  mov [r15+0x100], rax
0000785dab1dc8f6  jmp 0x0000785DAAFFE110
0000785dab1dc8fb  int3
0000785dab1dc8fc  call 0x0000785DAB0E27E0
0000785dab1dc901  jmp 0x0000785DAB1DB9DF
0000785dab1dc906  call 0x0000785DAB0E1570
0000785dab1dc90b  jmp 0x0000785DAB1DB9E8
0000785dab1dc910  call 0x0000785DAB0E27E0
0000785dab1dc915  jmp 0x0000785DAB1DBA44
0000785dab1dc91a  call 0x0000785DAB0E1570
0000785dab1dc91f  jmp 0x0000785DAB1DBA4D
0000785dab1dc924  call 0x0000785DAB0E27E0
0000785dab1dc929  jmp 0x0000785DAB1DBA90
0000785dab1dc92e  call 0x0000785DAB0E1570
0000785dab1dc933  jmp 0x0000785DAB1DBA99
0000785dab1dc938  call 0x0000785DAB00DC20
0000785dab1dc93d  jmp 0x0000785DAB1DBAD8
0000785dab1dc942  call 0x0000785DAB0D59C0
0000785dab1dc947  jmp 0x0000785DAB1DBAEB
0000785dab1dc94c  call 0x0000785DAB0E0E30
0000785dab1dc951  jmp 0x0000785DAB1DBB09
0000785dab1dc956  call 0x0000785DAB0DFBC0
0000785dab1dc95b  jmp 0x0000785DAB1DBB13
0000785dab1dc960  call 0x0000785DAB0DE950
0000785dab1dc965  jmp 0x0000785DAB1DBB1D
0000785dab1dc96a  sub rsp, 0x08
0000785dab1dc96e  push rax
0000785dab1dc96f  push rcx
0000785dab1dc970  push rdx
0000785dab1dc971  push rdi
0000785dab1dc972  push rsi
0000785dab1dc973  push r8
0000785dab1dc975  push r9
0000785dab1dc977  push r10
0000785dab1dc979  push r11
0000785dab1dc97b  sub rsp, 0xF0
0000785dab1dc982  vmovaps [rsp], xmm0
0000785dab1dc987  vmovaps [rsp+0x10], xmm1
0000785dab1dc98d  vmovaps [rsp+0x20], xmm2
0000785dab1dc993  vmovaps [rsp+0x30], xmm3
0000785dab1dc999  vmovaps [rsp+0x40], xmm4
0000785dab1dc99f  vmovaps [rsp+0x50], xmm5
0000785dab1dc9a5  vmovaps [rsp+0x60], xmm6
0000785dab1dc9ab  vmovaps [rsp+0x70], xmm7
0000785dab1dc9b1  vmovaps [rsp+0x80], xmm9
0000785dab1dc9ba  vmovaps [rsp+0x90], xmm10
0000785dab1dc9c3  vmovaps [rsp+0xA0], xmm11
0000785dab1dc9cc  vmovaps [rsp+0xB0], xmm12
0000785dab1dc9d5  vmovaps [rsp+0xC0], xmm13
0000785dab1dc9de  vmovaps [rsp+0xD0], xmm14
0000785dab1dc9e7  vmovaps [rsp+0xE0], xmm15
0000785dab1dc9f0  sub rsp, 0x30
0000785dab1dc9f4  movaps [rsp], xmm8
0000785dab1dc9f9  movaps [rsp+0x10], xmm12
0000785dab1dc9ff  movaps [rsp+0x20], xmm15
0000785dab1dca05  lea rdi, [rsp]
0000785dab1dca09  mov esi, 0x00
0000785dab1dca0e  mov rax, 0x61B13BBD6530
0000785dab1dca18  call rax
0000785dab1dca1a  movaps xmm8, [rsp]
0000785dab1dca1f  add rsp, 0x30
0000785dab1dca23  vmovaps xmm0, [rsp]
0000785dab1dca28  vmovaps xmm1, [rsp+0x10]
0000785dab1dca2e  vmovaps xmm2, [rsp+0x20]
0000785dab1dca34  vmovaps xmm3, [rsp+0x30]
0000785dab1dca3a  vmovaps xmm4, [rsp+0x40]
0000785dab1dca40  vmovaps xmm5, [rsp+0x50]
0000785dab1dca46  vmovaps xmm6, [rsp+0x60]
0000785dab1dca4c  vmovaps xmm7, [rsp+0x70]
0000785dab1dca52  vmovaps xmm9, [rsp+0x80]
0000785dab1dca5b  vmovaps xmm10, [rsp+0x90]
0000785dab1dca64  vmovaps xmm11, [rsp+0xA0]
0000785dab1dca6d  vmovaps xmm12, [rsp+0xB0]
0000785dab1dca76  vmovaps xmm13, [rsp+0xC0]
0000785dab1dca7f  vmovaps xmm14, [rsp+0xD0]
0000785dab1dca88  vmovaps xmm15, [rsp+0xE0]
0000785dab1dca91  add rsp, 0xF0
0000785dab1dca98  pop r11
0000785dab1dca9a  pop r10
0000785dab1dca9c  pop r9
0000785dab1dca9e  pop r8
0000785dab1dcaa0  pop rsi
0000785dab1dcaa1  pop rdi
0000785dab1dcaa2  pop rdx
0000785dab1dcaa3  pop rcx
0000785dab1dcaa4  pop rax
0000785dab1dcaa5  add rsp, 0x08
0000785dab1dcaa9  jmp 0x0000785DAB1DBB47
0000785dab1dcaae  sub rsp, 0x08
0000785dab1dcab2  push rax
0000785dab1dcab3  push rcx
0000785dab1dcab4  push rdx
0000785dab1dcab5  push rdi
0000785dab1dcab6  push rsi
0000785dab1dcab7  push r8
0000785dab1dcab9  push r9
0000785dab1dcabb  push r10
0000785dab1dcabd  push r11
0000785dab1dcabf  sub rsp, 0xF0
0000785dab1dcac6  vmovaps [rsp], xmm0
0000785dab1dcacb  vmovaps [rsp+0x10], xmm1
0000785dab1dcad1  vmovaps [rsp+0x20], xmm2
0000785dab1dcad7  vmovaps [rsp+0x30], xmm3
0000785dab1dcadd  vmovaps [rsp+0x40], xmm4
0000785dab1dcae3  vmovaps [rsp+0x50], xmm5
0000785dab1dcae9  vmovaps [rsp+0x60], xmm6
0000785dab1dcaef  vmovaps [rsp+0x70], xmm8
0000785dab1dcaf5  vmovaps [rsp+0x80], xmm9
0000785dab1dcafe  vmovaps [rsp+0x90], xmm10
0000785dab1dcb07  vmovaps [rsp+0xA0], xmm11
0000785dab1dcb10  vmovaps [rsp+0xB0], xmm12
0000785dab1dcb19  vmovaps [rsp+0xC0], xmm13
0000785dab1dcb22  vmovaps [rsp+0xD0], xmm14
0000785dab1dcb2b  vmovaps [rsp+0xE0], xmm15
0000785dab1dcb34  sub rsp, 0x30
0000785dab1dcb38  movaps [rsp], xmm7
0000785dab1dcb3c  movaps [rsp+0x10], xmm9
0000785dab1dcb42  movaps [rsp+0x20], xmm15
0000785dab1dcb48  lea rdi, [rsp]
0000785dab1dcb4c  mov esi, 0x00
0000785dab1dcb51  mov rax, 0x61B13BBD6530
0000785dab1dcb5b  call rax
0000785dab1dcb5d  movaps xmm7, [rsp]
0000785dab1dcb61  add rsp, 0x30
0000785dab1dcb65  vmovaps xmm0, [rsp]
0000785dab1dcb6a  vmovaps xmm1, [rsp+0x10]
0000785dab1dcb70  vmovaps xmm2, [rsp+0x20]
0000785dab1dcb76  vmovaps xmm3, [rsp+0x30]
0000785dab1dcb7c  vmovaps xmm4, [rsp+0x40]
0000785dab1dcb82  vmovaps xmm5, [rsp+0x50]
0000785dab1dcb88  vmovaps xmm6, [rsp+0x60]
0000785dab1dcb8e  vmovaps xmm8, [rsp+0x70]
0000785dab1dcb94  vmovaps xmm9, [rsp+0x80]
0000785dab1dcb9d  vmovaps xmm10, [rsp+0x90]
0000785dab1dcba6  vmovaps xmm11, [rsp+0xA0]
0000785dab1dcbaf  vmovaps xmm12, [rsp+0xB0]
0000785dab1dcbb8  vmovaps xmm13, [rsp+0xC0]
0000785dab1dcbc1  vmovaps xmm14, [rsp+0xD0]
0000785dab1dcbca  vmovaps xmm15, [rsp+0xE0]
0000785dab1dcbd3  add rsp, 0xF0
0000785dab1dcbda  pop r11
0000785dab1dcbdc  pop r10
0000785dab1dcbde  pop r9
0000785dab1dcbe0  pop r8
0000785dab1dcbe2  pop rsi
0000785dab1dcbe3  pop rdi
0000785dab1dcbe4  pop rdx
0000785dab1dcbe5  pop rcx
0000785dab1dcbe6  pop rax
0000785dab1dcbe7  add rsp, 0x08
0000785dab1dcbeb  jmp 0x0000785DAB1DBB75
0000785dab1dcbf0  sub rsp, 0x08
0000785dab1dcbf4  push rax
0000785dab1dcbf5  push rcx
0000785dab1dcbf6  push rdx
0000785dab1dcbf7  push rdi
0000785dab1dcbf8  push rsi
0000785dab1dcbf9  push r8
0000785dab1dcbfb  push r9
0000785dab1dcbfd  push r10
0000785dab1dcbff  push r11
0000785dab1dcc01  sub rsp, 0xF0
0000785dab1dcc08  vmovaps [rsp], xmm0
0000785dab1dcc0d  vmovaps [rsp+0x10], xmm1
0000785dab1dcc13  vmovaps [rsp+0x20], xmm2
0000785dab1dcc19  vmovaps [rsp+0x30], xmm3
0000785dab1dcc1f  vmovaps [rsp+0x40], xmm4
0000785dab1dcc25  vmovaps [rsp+0x50], xmm5
0000785dab1dcc2b  vmovaps [rsp+0x60], xmm6
0000785dab1dcc31  vmovaps [rsp+0x70], xmm7
0000785dab1dcc37  vmovaps [rsp+0x80], xmm8
0000785dab1dcc40  vmovaps [rsp+0x90], xmm10
0000785dab1dcc49  vmovaps [rsp+0xA0], xmm11
0000785dab1dcc52  vmovaps [rsp+0xB0], xmm12
0000785dab1dcc5b  vmovaps [rsp+0xC0], xmm13
0000785dab1dcc64  vmovaps [rsp+0xD0], xmm14
0000785dab1dcc6d  vmovaps [rsp+0xE0], xmm15
0000785dab1dcc76  sub rsp, 0x30
0000785dab1dcc7a  movaps [rsp], xmm9
0000785dab1dcc7f  movaps [rsp+0x10], xmm12
0000785dab1dcc85  movaps [rsp+0x20], xmm10
0000785dab1dcc8b  lea rdi, [rsp]
0000785dab1dcc8f  mov esi, 0x00
0000785dab1dcc94  mov rax, 0x61B13BBD6530
0000785dab1dcc9e  call rax
0000785dab1dcca0  movaps xmm9, [rsp]
0000785dab1dcca5  add rsp, 0x30
0000785dab1dcca9  vmovaps xmm0, [rsp]
0000785dab1dccae  vmovaps xmm1, [rsp+0x10]
0000785dab1dccb4  vmovaps xmm2, [rsp+0x20]
0000785dab1dccba  vmovaps xmm3, [rsp+0x30]
0000785dab1dccc0  vmovaps xmm4, [rsp+0x40]
0000785dab1dccc6  vmovaps xmm5, [rsp+0x50]
0000785dab1dcccc  vmovaps xmm6, [rsp+0x60]
0000785dab1dccd2  vmovaps xmm7, [rsp+0x70]
0000785dab1dccd8  vmovaps xmm8, [rsp+0x80]
0000785dab1dcce1  vmovaps xmm10, [rsp+0x90]
0000785dab1dccea  vmovaps xmm11, [rsp+0xA0]
0000785dab1dccf3  vmovaps xmm12, [rsp+0xB0]
0000785dab1dccfc  vmovaps xmm13, [rsp+0xC0]
0000785dab1dcd05  vmovaps xmm14, [rsp+0xD0]
0000785dab1dcd0e  vmovaps xmm15, [rsp+0xE0]
0000785dab1dcd17  add rsp, 0xF0
0000785dab1dcd1e  pop r11
0000785dab1dcd20  pop r10
0000785dab1dcd22  pop r9
0000785dab1dcd24  pop r8
0000785dab1dcd26  pop rsi
0000785dab1dcd27  pop rdi
0000785dab1dcd28  pop rdx
0000785dab1dcd29  pop rcx
0000785dab1dcd2a  pop rax
0000785dab1dcd2b  add rsp, 0x08
0000785dab1dcd2f  jmp 0x0000785DAB1DBB99
0000785dab1dcd34  sub rsp, 0x08
0000785dab1dcd38  push rax
0000785dab1dcd39  push rcx
0000785dab1dcd3a  push rdx
0000785dab1dcd3b  push rdi
0000785dab1dcd3c  push rsi
0000785dab1dcd3d  push r8
0000785dab1dcd3f  push r9
0000785dab1dcd41  push r10
0000785dab1dcd43  push r11
0000785dab1dcd45  sub rsp, 0xF0
0000785dab1dcd4c  vmovaps [rsp], xmm0
0000785dab1dcd51  vmovaps [rsp+0x10], xmm1
0000785dab1dcd57  vmovaps [rsp+0x20], xmm2
0000785dab1dcd5d  vmovaps [rsp+0x30], xmm3
0000785dab1dcd63  vmovaps [rsp+0x40], xmm4
0000785dab1dcd69  vmovaps [rsp+0x50], xmm5
0000785dab1dcd6f  vmovaps [rsp+0x60], xmm6
0000785dab1dcd75  vmovaps [rsp+0x70], xmm7
0000785dab1dcd7b  vmovaps [rsp+0x80], xmm8
0000785dab1dcd84  vmovaps [rsp+0x90], xmm9
0000785dab1dcd8d  vmovaps [rsp+0xA0], xmm11
0000785dab1dcd96  vmovaps [rsp+0xB0], xmm12
0000785dab1dcd9f  vmovaps [rsp+0xC0], xmm13
0000785dab1dcda8  vmovaps [rsp+0xD0], xmm14
0000785dab1dcdb1  vmovaps [rsp+0xE0], xmm15
0000785dab1dcdba  sub rsp, 0x30
0000785dab1dcdbe  movaps [rsp], xmm10
0000785dab1dcdc3  movaps [rsp+0x10], xmm12
0000785dab1dcdc9  movaps [rsp+0x20], xmm11
0000785dab1dcdcf  lea rdi, [rsp]
0000785dab1dcdd3  mov esi, 0x00
0000785dab1dcdd8  mov rax, 0x61B13BBD6530
0000785dab1dcde2  call rax
0000785dab1dcde4  movaps xmm10, [rsp]
0000785dab1dcde9  add rsp, 0x30
0000785dab1dcded  vmovaps xmm0, [rsp]
0000785dab1dcdf2  vmovaps xmm1, [rsp+0x10]
0000785dab1dcdf8  vmovaps xmm2, [rsp+0x20]
0000785dab1dcdfe  vmovaps xmm3, [rsp+0x30]
0000785dab1dce04  vmovaps xmm4, [rsp+0x40]
0000785dab1dce0a  vmovaps xmm5, [rsp+0x50]
0000785dab1dce10  vmovaps xmm6, [rsp+0x60]
0000785dab1dce16  vmovaps xmm7, [rsp+0x70]
0000785dab1dce1c  vmovaps xmm8, [rsp+0x80]
0000785dab1dce25  vmovaps xmm9, [rsp+0x90]
0000785dab1dce2e  vmovaps xmm11, [rsp+0xA0]
0000785dab1dce37  vmovaps xmm12, [rsp+0xB0]
0000785dab1dce40  vmovaps xmm13, [rsp+0xC0]
0000785dab1dce49  vmovaps xmm14, [rsp+0xD0]
0000785dab1dce52  vmovaps xmm15, [rsp+0xE0]
0000785dab1dce5b  add rsp, 0xF0
0000785dab1dce62  pop r11
0000785dab1dce64  pop r10
0000785dab1dce66  pop r9
0000785dab1dce68  pop r8
0000785dab1dce6a  pop rsi
0000785dab1dce6b  pop rdi
0000785dab1dce6c  pop rdx
0000785dab1dce6d  pop rcx
0000785dab1dce6e  pop rax
0000785dab1dce6f  add rsp, 0x08
0000785dab1dce73  jmp 0x0000785DAB1DBBB3
0000785dab1dce78  sub rsp, 0x08
0000785dab1dce7c  push rax
0000785dab1dce7d  push rcx
0000785dab1dce7e  push rdx
0000785dab1dce7f  push rdi
0000785dab1dce80  push rsi
0000785dab1dce81  push r8
0000785dab1dce83  push r9
0000785dab1dce85  push r10
0000785dab1dce87  push r11
0000785dab1dce89  sub rsp, 0xF0
0000785dab1dce90  vmovaps [rsp], xmm0
0000785dab1dce95  vmovaps [rsp+0x10], xmm1
0000785dab1dce9b  vmovaps [rsp+0x20], xmm2
0000785dab1dcea1  vmovaps [rsp+0x30], xmm3
0000785dab1dcea7  vmovaps [rsp+0x40], xmm4
0000785dab1dcead  vmovaps [rsp+0x50], xmm5
0000785dab1dceb3  vmovaps [rsp+0x60], xmm7
0000785dab1dceb9  vmovaps [rsp+0x70], xmm8
0000785dab1dcebf  vmovaps [rsp+0x80], xmm9
0000785dab1dcec8  vmovaps [rsp+0x90], xmm10
0000785dab1dced1  vmovaps [rsp+0xA0], xmm11
0000785dab1dceda  vmovaps [rsp+0xB0], xmm12
0000785dab1dcee3  vmovaps [rsp+0xC0], xmm13
0000785dab1dceec  vmovaps [rsp+0xD0], xmm14
0000785dab1dcef5  vmovaps [rsp+0xE0], xmm15
0000785dab1dcefe  sub rsp, 0x30
0000785dab1dcf02  movaps [rsp], xmm6
0000785dab1dcf06  movaps [rsp+0x10], xmm12
0000785dab1dcf0c  movaps [rsp+0x20], xmm11
0000785dab1dcf12  lea rdi, [rsp]
0000785dab1dcf16  mov esi, 0x00
0000785dab1dcf1b  mov rax, 0x61B13BBD6530
0000785dab1dcf25  call rax
0000785dab1dcf27  movaps xmm6, [rsp]
0000785dab1dcf2b  add rsp, 0x30
0000785dab1dcf2f  vmovaps xmm0, [rsp]
0000785dab1dcf34  vmovaps xmm1, [rsp+0x10]
0000785dab1dcf3a  vmovaps xmm2, [rsp+0x20]
0000785dab1dcf40  vmovaps xmm3, [rsp+0x30]
0000785dab1dcf46  vmovaps xmm4, [rsp+0x40]
0000785dab1dcf4c  vmovaps xmm5, [rsp+0x50]
0000785dab1dcf52  vmovaps xmm7, [rsp+0x60]
0000785dab1dcf58  vmovaps xmm8, [rsp+0x70]
0000785dab1dcf5e  vmovaps xmm9, [rsp+0x80]
0000785dab1dcf67  vmovaps xmm10, [rsp+0x90]
0000785dab1dcf70  vmovaps xmm11, [rsp+0xA0]
0000785dab1dcf79  vmovaps xmm12, [rsp+0xB0]
0000785dab1dcf82  vmovaps xmm13, [rsp+0xC0]
0000785dab1dcf8b  vmovaps xmm14, [rsp+0xD0]
0000785dab1dcf94  vmovaps xmm15, [rsp+0xE0]
0000785dab1dcf9d  add rsp, 0xF0
0000785dab1dcfa4  pop r11
0000785dab1dcfa6  pop r10
0000785dab1dcfa8  pop r9
0000785dab1dcfaa  pop r8
0000785dab1dcfac  pop rsi
0000785dab1dcfad  pop rdi
0000785dab1dcfae  pop rdx
0000785dab1dcfaf  pop rcx
0000785dab1dcfb0  pop rax
0000785dab1dcfb1  add rsp, 0x08
0000785dab1dcfb5  jmp 0x0000785DAB1DBBD4
0000785dab1dcfba  sub rsp, 0x08
0000785dab1dcfbe  push rax
0000785dab1dcfbf  push rcx
0000785dab1dcfc0  push rdx
0000785dab1dcfc1  push rdi
0000785dab1dcfc2  push rsi
0000785dab1dcfc3  push r8
0000785dab1dcfc5  push r9
0000785dab1dcfc7  push r10
0000785dab1dcfc9  push r11
0000785dab1dcfcb  sub rsp, 0xF0
0000785dab1dcfd2  vmovaps [rsp], xmm0
0000785dab1dcfd7  vmovaps [rsp+0x10], xmm1
0000785dab1dcfdd  vmovaps [rsp+0x20], xmm2
0000785dab1dcfe3  vmovaps [rsp+0x30], xmm4
0000785dab1dcfe9  vmovaps [rsp+0x40], xmm5
0000785dab1dcfef  vmovaps [rsp+0x50], xmm6
0000785dab1dcff5  vmovaps [rsp+0x60], xmm7
0000785dab1dcffb  vmovaps [rsp+0x70], xmm8
0000785dab1dd001  vmovaps [rsp+0x80], xmm9
0000785dab1dd00a  vmovaps [rsp+0x90], xmm10
0000785dab1dd013  vmovaps [rsp+0xA0], xmm11
0000785dab1dd01c  vmovaps [rsp+0xB0], xmm12
0000785dab1dd025  vmovaps [rsp+0xC0], xmm13
0000785dab1dd02e  vmovaps [rsp+0xD0], xmm14
0000785dab1dd037  vmovaps [rsp+0xE0], xmm15
0000785dab1dd040  sub rsp, 0x30
0000785dab1dd044  movaps [rsp], xmm3
0000785dab1dd048  movaps [rsp+0x10], xmm5
0000785dab1dd04d  movaps [rsp+0x20], xmm4
0000785dab1dd052  lea rdi, [rsp]
0000785dab1dd056  mov esi, 0x00
0000785dab1dd05b  mov rax, 0x61B13BBD6530
0000785dab1dd065  call rax
0000785dab1dd067  movaps xmm3, [rsp]
0000785dab1dd06b  add rsp, 0x30
0000785dab1dd06f  vmovaps xmm0, [rsp]
0000785dab1dd074  vmovaps xmm1, [rsp+0x10]
0000785dab1dd07a  vmovaps xmm2, [rsp+0x20]
0000785dab1dd080  vmovaps xmm4, [rsp+0x30]
0000785dab1dd086  vmovaps xmm5, [rsp+0x40]
0000785dab1dd08c  vmovaps xmm6, [rsp+0x50]
0000785dab1dd092  vmovaps xmm7, [rsp+0x60]
0000785dab1dd098  vmovaps xmm8, [rsp+0x70]
0000785dab1dd09e  vmovaps xmm9, [rsp+0x80]
0000785dab1dd0a7  vmovaps xmm10, [rsp+0x90]
0000785dab1dd0b0  vmovaps xmm11, [rsp+0xA0]
0000785dab1dd0b9  vmovaps xmm12, [rsp+0xB0]
0000785dab1dd0c2  vmovaps xmm13, [rsp+0xC0]
0000785dab1dd0cb  vmovaps xmm14, [rsp+0xD0]
0000785dab1dd0d4  vmovaps xmm15, [rsp+0xE0]
0000785dab1dd0dd  add rsp, 0xF0
0000785dab1dd0e4  pop r11
0000785dab1dd0e6  pop r10
0000785dab1dd0e8  pop r9
0000785dab1dd0ea  pop r8
0000785dab1dd0ec  pop rsi
0000785dab1dd0ed  pop rdi
0000785dab1dd0ee  pop rdx
0000785dab1dd0ef  pop rcx
0000785dab1dd0f0  pop rax
0000785dab1dd0f1  add rsp, 0x08
0000785dab1dd0f5  jmp 0x0000785DAB1DBC35
0000785dab1dd0fa  sub rsp, 0x08
0000785dab1dd0fe  push rax
0000785dab1dd0ff  push rcx
0000785dab1dd100  push rdx
0000785dab1dd101  push rdi
0000785dab1dd102  push rsi
0000785dab1dd103  push r8
0000785dab1dd105  push r9
0000785dab1dd107  push r10
0000785dab1dd109  push r11
0000785dab1dd10b  sub rsp, 0xF0
0000785dab1dd112  vmovaps [rsp], xmm0
0000785dab1dd117  vmovaps [rsp+0x10], xmm1
0000785dab1dd11d  vmovaps [rsp+0x20], xmm2
0000785dab1dd123  vmovaps [rsp+0x30], xmm3
0000785dab1dd129  vmovaps [rsp+0x40], xmm4
0000785dab1dd12f  vmovaps [rsp+0x50], xmm6
0000785dab1dd135  vmovaps [rsp+0x60], xmm7
0000785dab1dd13b  vmovaps [rsp+0x70], xmm8
0000785dab1dd141  vmovaps [rsp+0x80], xmm9
0000785dab1dd14a  vmovaps [rsp+0x90], xmm10
0000785dab1dd153  vmovaps [rsp+0xA0], xmm11
0000785dab1dd15c  vmovaps [rsp+0xB0], xmm12
0000785dab1dd165  vmovaps [rsp+0xC0], xmm13
0000785dab1dd16e  vmovaps [rsp+0xD0], xmm14
0000785dab1dd177  vmovaps [rsp+0xE0], xmm15
0000785dab1dd180  sub rsp, 0x30
0000785dab1dd184  movaps [rsp], xmm5
0000785dab1dd188  movaps [rsp+0x10], xmm8
0000785dab1dd18e  movaps [rsp+0x20], xmm15
0000785dab1dd194  lea rdi, [rsp]
0000785dab1dd198  mov esi, 0x00
0000785dab1dd19d  mov rax, 0x61B13BBD6530
0000785dab1dd1a7  call rax
0000785dab1dd1a9  movaps xmm5, [rsp]
0000785dab1dd1ad  add rsp, 0x30
0000785dab1dd1b1  vmovaps xmm0, [rsp]
0000785dab1dd1b6  vmovaps xmm1, [rsp+0x10]
0000785dab1dd1bc  vmovaps xmm2, [rsp+0x20]
0000785dab1dd1c2  vmovaps xmm3, [rsp+0x30]
0000785dab1dd1c8  vmovaps xmm4, [rsp+0x40]
0000785dab1dd1ce  vmovaps xmm6, [rsp+0x50]
0000785dab1dd1d4  vmovaps xmm7, [rsp+0x60]
0000785dab1dd1da  vmovaps xmm8, [rsp+0x70]
0000785dab1dd1e0  vmovaps xmm9, [rsp+0x80]
0000785dab1dd1e9  vmovaps xmm10, [rsp+0x90]
0000785dab1dd1f2  vmovaps xmm11, [rsp+0xA0]
0000785dab1dd1fb  vmovaps xmm12, [rsp+0xB0]
0000785dab1dd204  vmovaps xmm13, [rsp+0xC0]
0000785dab1dd20d  vmovaps xmm14, [rsp+0xD0]
0000785dab1dd216  vmovaps xmm15, [rsp+0xE0]
0000785dab1dd21f  add rsp, 0xF0
0000785dab1dd226  pop r11
0000785dab1dd228  pop r10
0000785dab1dd22a  pop r9
0000785dab1dd22c  pop r8
0000785dab1dd22e  pop rsi
0000785dab1dd22f  pop rdi
0000785dab1dd230  pop rdx
0000785dab1dd231  pop rcx
0000785dab1dd232  pop rax
0000785dab1dd233  add rsp, 0x08
0000785dab1dd237  jmp 0x0000785DAB1DBC73
0000785dab1dd23c  sub rsp, 0x08
0000785dab1dd240  push rax
0000785dab1dd241  push rcx
0000785dab1dd242  push rdx
0000785dab1dd243  push rdi
0000785dab1dd244  push rsi
0000785dab1dd245  push r8
0000785dab1dd247  push r9
0000785dab1dd249  push r10
0000785dab1dd24b  push r11
0000785dab1dd24d  sub rsp, 0xF0
0000785dab1dd254  vmovaps [rsp], xmm0
0000785dab1dd259  vmovaps [rsp+0x10], xmm1
0000785dab1dd25f  vmovaps [rsp+0x20], xmm2
0000785dab1dd265  vmovaps [rsp+0x30], xmm3
0000785dab1dd26b  vmovaps [rsp+0x40], xmm5
0000785dab1dd271  vmovaps [rsp+0x50], xmm6
0000785dab1dd277  vmovaps [rsp+0x60], xmm7
0000785dab1dd27d  vmovaps [rsp+0x70], xmm8
0000785dab1dd283  vmovaps [rsp+0x80], xmm9
0000785dab1dd28c  vmovaps [rsp+0x90], xmm10
0000785dab1dd295  vmovaps [rsp+0xA0], xmm11
0000785dab1dd29e  vmovaps [rsp+0xB0], xmm12
0000785dab1dd2a7  vmovaps [rsp+0xC0], xmm13
0000785dab1dd2b0  vmovaps [rsp+0xD0], xmm14
0000785dab1dd2b9  vmovaps [rsp+0xE0], xmm15
0000785dab1dd2c2  sub rsp, 0x30
0000785dab1dd2c6  movaps [rsp], xmm4
0000785dab1dd2ca  movaps [rsp+0x10], xmm9
0000785dab1dd2d0  movaps [rsp+0x20], xmm8
0000785dab1dd2d6  lea rdi, [rsp]
0000785dab1dd2da  mov esi, 0x00
0000785dab1dd2df  mov rax, 0x61B13BBD6530
0000785dab1dd2e9  call rax
0000785dab1dd2eb  movaps xmm4, [rsp]
0000785dab1dd2ef  add rsp, 0x30
0000785dab1dd2f3  vmovaps xmm0, [rsp]
0000785dab1dd2f8  vmovaps xmm1, [rsp+0x10]
0000785dab1dd2fe  vmovaps xmm2, [rsp+0x20]
0000785dab1dd304  vmovaps xmm3, [rsp+0x30]
0000785dab1dd30a  vmovaps xmm5, [rsp+0x40]
0000785dab1dd310  vmovaps xmm6, [rsp+0x50]
0000785dab1dd316  vmovaps xmm7, [rsp+0x60]
0000785dab1dd31c  vmovaps xmm8, [rsp+0x70]
0000785dab1dd322  vmovaps xmm9, [rsp+0x80]
0000785dab1dd32b  vmovaps xmm10, [rsp+0x90]
0000785dab1dd334  vmovaps xmm11, [rsp+0xA0]
0000785dab1dd33d  vmovaps xmm12, [rsp+0xB0]
0000785dab1dd346  vmovaps xmm13, [rsp+0xC0]
0000785dab1dd34f  vmovaps xmm14, [rsp+0xD0]
0000785dab1dd358  vmovaps xmm15, [rsp+0xE0]
0000785dab1dd361  add rsp, 0xF0
0000785dab1dd368  pop r11
0000785dab1dd36a  pop r10
0000785dab1dd36c  pop r9
0000785dab1dd36e  pop r8
0000785dab1dd370  pop rsi
0000785dab1dd371  pop rdi
0000785dab1dd372  pop rdx
0000785dab1dd373  pop rcx
0000785dab1dd374  pop rax
0000785dab1dd375  add rsp, 0x08
0000785dab1dd379  jmp 0x0000785DAB1DBC94
0000785dab1dd37e  sub rsp, 0x08
0000785dab1dd382  push rax
0000785dab1dd383  push rcx
0000785dab1dd384  push rdx
0000785dab1dd385  push rdi
0000785dab1dd386  push rsi
0000785dab1dd387  push r8
0000785dab1dd389  push r9
0000785dab1dd38b  push r10
0000785dab1dd38d  push r11
0000785dab1dd38f  sub rsp, 0xF0
0000785dab1dd396  vmovaps [rsp], xmm0
0000785dab1dd39b  vmovaps [rsp+0x10], xmm1
0000785dab1dd3a1  vmovaps [rsp+0x20], xmm2
0000785dab1dd3a7  vmovaps [rsp+0x30], xmm3
0000785dab1dd3ad  vmovaps [rsp+0x40], xmm4
0000785dab1dd3b3  vmovaps [rsp+0x50], xmm5
0000785dab1dd3b9  vmovaps [rsp+0x60], xmm6
0000785dab1dd3bf  vmovaps [rsp+0x70], xmm7
0000785dab1dd3c5  vmovaps [rsp+0x80], xmm8
0000785dab1dd3ce  vmovaps [rsp+0x90], xmm10
0000785dab1dd3d7  vmovaps [rsp+0xA0], xmm11
0000785dab1dd3e0  vmovaps [rsp+0xB0], xmm12
0000785dab1dd3e9  vmovaps [rsp+0xC0], xmm13
0000785dab1dd3f2  vmovaps [rsp+0xD0], xmm14
0000785dab1dd3fb  vmovaps [rsp+0xE0], xmm15
0000785dab1dd404  sub rsp, 0x30
0000785dab1dd408  movaps [rsp], xmm9
0000785dab1dd40d  movaps [rsp+0x10], xmm10
0000785dab1dd413  movaps [rsp+0x20], xmm8
0000785dab1dd419  lea rdi, [rsp]
0000785dab1dd41d  mov esi, 0x00
0000785dab1dd422  mov rax, 0x61B13BBD6530
0000785dab1dd42c  call rax
0000785dab1dd42e  movaps xmm9, [rsp]
0000785dab1dd433  add rsp, 0x30
0000785dab1dd437  vmovaps xmm0, [rsp]
0000785dab1dd43c  vmovaps xmm1, [rsp+0x10]
0000785dab1dd442  vmovaps xmm2, [rsp+0x20]
0000785dab1dd448  vmovaps xmm3, [rsp+0x30]
0000785dab1dd44e  vmovaps xmm4, [rsp+0x40]
0000785dab1dd454  vmovaps xmm5, [rsp+0x50]
0000785dab1dd45a  vmovaps xmm6, [rsp+0x60]
0000785dab1dd460  vmovaps xmm7, [rsp+0x70]
0000785dab1dd466  vmovaps xmm8, [rsp+0x80]
0000785dab1dd46f  vmovaps xmm10, [rsp+0x90]
0000785dab1dd478  vmovaps xmm11, [rsp+0xA0]
0000785dab1dd481  vmovaps xmm12, [rsp+0xB0]
0000785dab1dd48a  vmovaps xmm13, [rsp+0xC0]
0000785dab1dd493  vmovaps xmm14, [rsp+0xD0]
0000785dab1dd49c  vmovaps xmm15, [rsp+0xE0]
0000785dab1dd4a5  add rsp, 0xF0
0000785dab1dd4ac  pop r11
0000785dab1dd4ae  pop r10
0000785dab1dd4b0  pop r9
0000785dab1dd4b2  pop r8
0000785dab1dd4b4  pop rsi
0000785dab1dd4b5  pop rdi
0000785dab1dd4b6  pop rdx
0000785dab1dd4b7  pop rcx
0000785dab1dd4b8  pop rax
0000785dab1dd4b9  add rsp, 0x08
0000785dab1dd4bd  jmp 0x0000785DAB1DBCAE
0000785dab1dd4c2  call 0x0000785DAB0B52F0
0000785dab1dd4c7  jmp 0x0000785DAB1DBDC8
0000785dab1dd4cc  call 0x0000785DAB0B52F0
0000785dab1dd4d1  jmp 0x0000785DAB1DBDDE
0000785dab1dd4d6  sub rsp, 0x08
0000785dab1dd4da  push rax
0000785dab1dd4db  push rcx
0000785dab1dd4dc  push rdx
0000785dab1dd4dd  push rdi
0000785dab1dd4de  push rsi
0000785dab1dd4df  push r8
0000785dab1dd4e1  push r9
0000785dab1dd4e3  push r10
0000785dab1dd4e5  push r11
0000785dab1dd4e7  sub rsp, 0xF0
0000785dab1dd4ee  vmovaps [rsp], xmm0
0000785dab1dd4f3  vmovaps [rsp+0x10], xmm2
0000785dab1dd4f9  vmovaps [rsp+0x20], xmm3
0000785dab1dd4ff  vmovaps [rsp+0x30], xmm4
0000785dab1dd505  vmovaps [rsp+0x40], xmm5
0000785dab1dd50b  vmovaps [rsp+0x50], xmm6
0000785dab1dd511  vmovaps [rsp+0x60], xmm7
0000785dab1dd517  vmovaps [rsp+0x70], xmm8
0000785dab1dd51d  vmovaps [rsp+0x80], xmm9
0000785dab1dd526  vmovaps [rsp+0x90], xmm10
0000785dab1dd52f  vmovaps [rsp+0xA0], xmm11
0000785dab1dd538  vmovaps [rsp+0xB0], xmm12
0000785dab1dd541  vmovaps [rsp+0xC0], xmm13
0000785dab1dd54a  vmovaps [rsp+0xD0], xmm14
0000785dab1dd553  vmovaps [rsp+0xE0], xmm15
0000785dab1dd55c  sub rsp, 0x30
0000785dab1dd560  movaps [rsp], xmm1
0000785dab1dd564  movaps [rsp+0x10], xmm6
0000785dab1dd569  movaps [rsp+0x20], xmm15
0000785dab1dd56f  lea rdi, [rsp]
0000785dab1dd573  mov esi, 0x00
0000785dab1dd578  mov rax, 0x61B13BBD6530
0000785dab1dd582  call rax
0000785dab1dd584  movaps xmm1, [rsp]
0000785dab1dd588  add rsp, 0x30
0000785dab1dd58c  vmovaps xmm0, [rsp]
0000785dab1dd591  vmovaps xmm2, [rsp+0x10]
0000785dab1dd597  vmovaps xmm3, [rsp+0x20]
0000785dab1dd59d  vmovaps xmm4, [rsp+0x30]
0000785dab1dd5a3  vmovaps xmm5, [rsp+0x40]
0000785dab1dd5a9  vmovaps xmm6, [rsp+0x50]
0000785dab1dd5af  vmovaps xmm7, [rsp+0x60]
0000785dab1dd5b5  vmovaps xmm8, [rsp+0x70]
0000785dab1dd5bb  vmovaps xmm9, [rsp+0x80]
0000785dab1dd5c4  vmovaps xmm10, [rsp+0x90]
0000785dab1dd5cd  vmovaps xmm11, [rsp+0xA0]
0000785dab1dd5d6  vmovaps xmm12, [rsp+0xB0]
0000785dab1dd5df  vmovaps xmm13, [rsp+0xC0]
0000785dab1dd5e8  vmovaps xmm14, [rsp+0xD0]
0000785dab1dd5f1  vmovaps xmm15, [rsp+0xE0]
0000785dab1dd5fa  add rsp, 0xF0
0000785dab1dd601  pop r11
0000785dab1dd603  pop r10
0000785dab1dd605  pop r9
0000785dab1dd607  pop r8
0000785dab1dd609  pop rsi
0000785dab1dd60a  pop rdi
0000785dab1dd60b  pop rdx
0000785dab1dd60c  pop rcx
0000785dab1dd60d  pop rax
0000785dab1dd60e  add rsp, 0x08
0000785dab1dd612  jmp 0x0000785DAB1DBE1B
0000785dab1dd617  call 0x0000785DAB0C4620
0000785dab1dd61c  jmp 0x0000785DAB1DBE28
0000785dab1dd621  sub rsp, 0x08
0000785dab1dd625  push rax
0000785dab1dd626  push rcx
0000785dab1dd627  push rdx
0000785dab1dd628  push rdi
0000785dab1dd629  push rsi
0000785dab1dd62a  push r8
0000785dab1dd62c  push r9
0000785dab1dd62e  push r10
0000785dab1dd630  push r11
0000785dab1dd632  sub rsp, 0xF0
0000785dab1dd639  vmovaps [rsp], xmm0
0000785dab1dd63e  vmovaps [rsp+0x10], xmm1
0000785dab1dd644  vmovaps [rsp+0x20], xmm2
0000785dab1dd64a  vmovaps [rsp+0x30], xmm3
0000785dab1dd650  vmovaps [rsp+0x40], xmm4
0000785dab1dd656  vmovaps [rsp+0x50], xmm5
0000785dab1dd65c  vmovaps [rsp+0x60], xmm6
0000785dab1dd662  vmovaps [rsp+0x70], xmm7
0000785dab1dd668  vmovaps [rsp+0x80], xmm8
0000785dab1dd671  vmovaps [rsp+0x90], xmm9
0000785dab1dd67a  vmovaps [rsp+0xA0], xmm10
0000785dab1dd683  vmovaps [rsp+0xB0], xmm11
0000785dab1dd68c  vmovaps [rsp+0xC0], xmm12
0000785dab1dd695  vmovaps [rsp+0xD0], xmm13
0000785dab1dd69e  vmovaps [rsp+0xE0], xmm15
0000785dab1dd6a7  sub rsp, 0x30
0000785dab1dd6ab  movaps [rsp], xmm14
0000785dab1dd6b0  movaps [rsp+0x10], xmm4
0000785dab1dd6b5  movaps [rsp+0x20], xmm3
0000785dab1dd6ba  lea rdi, [rsp]
0000785dab1dd6be  mov esi, 0x00
0000785dab1dd6c3  mov rax, 0x61B13BBD6530
0000785dab1dd6cd  call rax
0000785dab1dd6cf  movaps xmm14, [rsp]
0000785dab1dd6d4  add rsp, 0x30
0000785dab1dd6d8  vmovaps xmm0, [rsp]
0000785dab1dd6dd  vmovaps xmm1, [rsp+0x10]
0000785dab1dd6e3  vmovaps xmm2, [rsp+0x20]
0000785dab1dd6e9  vmovaps xmm3, [rsp+0x30]
0000785dab1dd6ef  vmovaps xmm4, [rsp+0x40]
0000785dab1dd6f5  vmovaps xmm5, [rsp+0x50]
0000785dab1dd6fb  vmovaps xmm6, [rsp+0x60]
0000785dab1dd701  vmovaps xmm7, [rsp+0x70]
0000785dab1dd707  vmovaps xmm8, [rsp+0x80]
0000785dab1dd710  vmovaps xmm9, [rsp+0x90]
0000785dab1dd719  vmovaps xmm10, [rsp+0xA0]
0000785dab1dd722  vmovaps xmm11, [rsp+0xB0]
0000785dab1dd72b  vmovaps xmm12, [rsp+0xC0]
0000785dab1dd734  vmovaps xmm13, [rsp+0xD0]
0000785dab1dd73d  vmovaps xmm15, [rsp+0xE0]
0000785dab1dd746  add rsp, 0xF0
0000785dab1dd74d  pop r11
0000785dab1dd74f  pop r10
0000785dab1dd751  pop r9
0000785dab1dd753  pop r8
0000785dab1dd755  pop rsi
0000785dab1dd756  pop rdi
0000785dab1dd757  pop rdx
0000785dab1dd758  pop rcx
0000785dab1dd759  pop rax
0000785dab1dd75a  add rsp, 0x08
0000785dab1dd75e  jmp 0x0000785DAB1DBE42
0000785dab1dd763  sub rsp, 0x08
0000785dab1dd767  push rax
0000785dab1dd768  push rcx
0000785dab1dd769  push rdx
0000785dab1dd76a  push rdi
0000785dab1dd76b  push rsi
0000785dab1dd76c  push r8
0000785dab1dd76e  push r9
0000785dab1dd770  push r10
0000785dab1dd772  push r11
0000785dab1dd774  sub rsp, 0xF0
0000785dab1dd77b  vmovaps [rsp], xmm0
0000785dab1dd780  vmovaps [rsp+0x10], xmm1
0000785dab1dd786  vmovaps [rsp+0x20], xmm2
0000785dab1dd78c  vmovaps [rsp+0x30], xmm3
0000785dab1dd792  vmovaps [rsp+0x40], xmm4
0000785dab1dd798  vmovaps [rsp+0x50], xmm5
0000785dab1dd79e  vmovaps [rsp+0x60], xmm7
0000785dab1dd7a4  vmovaps [rsp+0x70], xmm8
0000785dab1dd7aa  vmovaps [rsp+0x80], xmm9
0000785dab1dd7b3  vmovaps [rsp+0x90], xmm10
0000785dab1dd7bc  vmovaps [rsp+0xA0], xmm11
0000785dab1dd7c5  vmovaps [rsp+0xB0], xmm12
0000785dab1dd7ce  vmovaps [rsp+0xC0], xmm13
0000785dab1dd7d7  vmovaps [rsp+0xD0], xmm14
0000785dab1dd7e0  vmovaps [rsp+0xE0], xmm15
0000785dab1dd7e9  sub rsp, 0x30
0000785dab1dd7ed  movaps [rsp], xmm6
0000785dab1dd7f1  movaps [rsp+0x10], xmm9
0000785dab1dd7f7  movaps [rsp+0x20], xmm7
0000785dab1dd7fc  lea rdi, [rsp]
0000785dab1dd800  mov esi, 0x00
0000785dab1dd805  mov rax, 0x61B13BBD6530
0000785dab1dd80f  call rax
0000785dab1dd811  movaps xmm6, [rsp]
0000785dab1dd815  add rsp, 0x30
0000785dab1dd819  vmovaps xmm0, [rsp]
0000785dab1dd81e  vmovaps xmm1, [rsp+0x10]
0000785dab1dd824  vmovaps xmm2, [rsp+0x20]
0000785dab1dd82a  vmovaps xmm3, [rsp+0x30]
0000785dab1dd830  vmovaps xmm4, [rsp+0x40]
0000785dab1dd836  vmovaps xmm5, [rsp+0x50]
0000785dab1dd83c  vmovaps xmm7, [rsp+0x60]
0000785dab1dd842  vmovaps xmm8, [rsp+0x70]
0000785dab1dd848  vmovaps xmm9, [rsp+0x80]
0000785dab1dd851  vmovaps xmm10, [rsp+0x90]
0000785dab1dd85a  vmovaps xmm11, [rsp+0xA0]
0000785dab1dd863  vmovaps xmm12, [rsp+0xB0]
0000785dab1dd86c  vmovaps xmm13, [rsp+0xC0]
0000785dab1dd875  vmovaps xmm14, [rsp+0xD0]
0000785dab1dd87e  vmovaps xmm15, [rsp+0xE0]
0000785dab1dd887  add rsp, 0xF0
0000785dab1dd88e  pop r11
0000785dab1dd890  pop r10
0000785dab1dd892  pop r9
0000785dab1dd894  pop r8
0000785dab1dd896  pop rsi
0000785dab1dd897  pop rdi
0000785dab1dd898  pop rdx
0000785dab1dd899  pop rcx
0000785dab1dd89a  pop rax
0000785dab1dd89b  add rsp, 0x08
0000785dab1dd89f  jmp 0x0000785DAB1DBE5A
0000785dab1dd8a4  sub rsp, 0x08
0000785dab1dd8a8  push rax
0000785dab1dd8a9  push rcx
0000785dab1dd8aa  push rdx
0000785dab1dd8ab  push rdi
0000785dab1dd8ac  push rsi
0000785dab1dd8ad  push r8
0000785dab1dd8af  push r9
0000785dab1dd8b1  push r10
0000785dab1dd8b3  push r11
0000785dab1dd8b5  sub rsp, 0xF0
0000785dab1dd8bc  vmovaps [rsp], xmm0
0000785dab1dd8c1  vmovaps [rsp+0x10], xmm1
0000785dab1dd8c7  vmovaps [rsp+0x20], xmm2
0000785dab1dd8cd  vmovaps [rsp+0x30], xmm3
0000785dab1dd8d3  vmovaps [rsp+0x40], xmm4
0000785dab1dd8d9  vmovaps [rsp+0x50], xmm5
0000785dab1dd8df  vmovaps [rsp+0x60], xmm6
0000785dab1dd8e5  vmovaps [rsp+0x70], xmm8
0000785dab1dd8eb  vmovaps [rsp+0x80], xmm9
0000785dab1dd8f4  vmovaps [rsp+0x90], xmm10
0000785dab1dd8fd  vmovaps [rsp+0xA0], xmm11
0000785dab1dd906  vmovaps [rsp+0xB0], xmm12
0000785dab1dd90f  vmovaps [rsp+0xC0], xmm13
0000785dab1dd918  vmovaps [rsp+0xD0], xmm14
0000785dab1dd921  vmovaps [rsp+0xE0], xmm15
0000785dab1dd92a  sub rsp, 0x30
0000785dab1dd92e  movaps [rsp], xmm7
0000785dab1dd932  movaps [rsp+0x10], xmm4
0000785dab1dd937  movaps [rsp+0x20], xmm9
0000785dab1dd93d  lea rdi, [rsp]
0000785dab1dd941  mov esi, 0x00
0000785dab1dd946  mov rax, 0x61B13BBD6530
0000785dab1dd950  call rax
0000785dab1dd952  movaps xmm7, [rsp]
0000785dab1dd956  add rsp, 0x30
0000785dab1dd95a  vmovaps xmm0, [rsp]
0000785dab1dd95f  vmovaps xmm1, [rsp+0x10]
0000785dab1dd965  vmovaps xmm2, [rsp+0x20]
0000785dab1dd96b  vmovaps xmm3, [rsp+0x30]
0000785dab1dd971  vmovaps xmm4, [rsp+0x40]
0000785dab1dd977  vmovaps xmm5, [rsp+0x50]
0000785dab1dd97d  vmovaps xmm6, [rsp+0x60]
0000785dab1dd983  vmovaps xmm8, [rsp+0x70]
0000785dab1dd989  vmovaps xmm9, [rsp+0x80]
0000785dab1dd992  vmovaps xmm10, [rsp+0x90]
0000785dab1dd99b  vmovaps xmm11, [rsp+0xA0]
0000785dab1dd9a4  vmovaps xmm12, [rsp+0xB0]
0000785dab1dd9ad  vmovaps xmm13, [rsp+0xC0]
0000785dab1dd9b6  vmovaps xmm14, [rsp+0xD0]
0000785dab1dd9bf  vmovaps xmm15, [rsp+0xE0]
0000785dab1dd9c8  add rsp, 0xF0
0000785dab1dd9cf  pop r11
0000785dab1dd9d1  pop r10
0000785dab1dd9d3  pop r9
0000785dab1dd9d5  pop r8
0000785dab1dd9d7  pop rsi
0000785dab1dd9d8  pop rdi
0000785dab1dd9d9  pop rdx
0000785dab1dd9da  pop rcx
0000785dab1dd9db  pop rax
0000785dab1dd9dc  add rsp, 0x08
0000785dab1dd9e0  jmp 0x0000785DAB1DBE87
0000785dab1dd9e5  sub rsp, 0x08
0000785dab1dd9e9  push rax
0000785dab1dd9ea  push rcx
0000785dab1dd9eb  push rdx
0000785dab1dd9ec  push rdi
0000785dab1dd9ed  push rsi
0000785dab1dd9ee  push r8
0000785dab1dd9f0  push r9
0000785dab1dd9f2  push r10
0000785dab1dd9f4  push r11
0000785dab1dd9f6  sub rsp, 0xF0
0000785dab1dd9fd  vmovaps [rsp], xmm0
0000785dab1dda02  vmovaps [rsp+0x10], xmm1
0000785dab1dda08  vmovaps [rsp+0x20], xmm2
0000785dab1dda0e  vmovaps [rsp+0x30], xmm3
0000785dab1dda14  vmovaps [rsp+0x40], xmm5
0000785dab1dda1a  vmovaps [rsp+0x50], xmm6
0000785dab1dda20  vmovaps [rsp+0x60], xmm7
0000785dab1dda26  vmovaps [rsp+0x70], xmm8
0000785dab1dda2c  vmovaps [rsp+0x80], xmm9
0000785dab1dda35  vmovaps [rsp+0x90], xmm10
0000785dab1dda3e  vmovaps [rsp+0xA0], xmm11
0000785dab1dda47  vmovaps [rsp+0xB0], xmm12
0000785dab1dda50  vmovaps [rsp+0xC0], xmm13
0000785dab1dda59  vmovaps [rsp+0xD0], xmm14
0000785dab1dda62  vmovaps [rsp+0xE0], xmm15
0000785dab1dda6b  sub rsp, 0x30
0000785dab1dda6f  movaps [rsp], xmm4
0000785dab1dda73  movaps [rsp+0x10], xmm15
0000785dab1dda79  movaps [rsp+0x20], xmm9
0000785dab1dda7f  lea rdi, [rsp]
0000785dab1dda83  mov esi, 0x00
0000785dab1dda88  mov rax, 0x61B13BBD6530
0000785dab1dda92  call rax
0000785dab1dda94  movaps xmm4, [rsp]
0000785dab1dda98  add rsp, 0x30
0000785dab1dda9c  vmovaps xmm0, [rsp]
0000785dab1ddaa1  vmovaps xmm1, [rsp+0x10]
0000785dab1ddaa7  vmovaps xmm2, [rsp+0x20]
0000785dab1ddaad  vmovaps xmm3, [rsp+0x30]
0000785dab1ddab3  vmovaps xmm5, [rsp+0x40]
0000785dab1ddab9  vmovaps xmm6, [rsp+0x50]
0000785dab1ddabf  vmovaps xmm7, [rsp+0x60]
0000785dab1ddac5  vmovaps xmm8, [rsp+0x70]
0000785dab1ddacb  vmovaps xmm9, [rsp+0x80]
0000785dab1ddad4  vmovaps xmm10, [rsp+0x90]
0000785dab1ddadd  vmovaps xmm11, [rsp+0xA0]
0000785dab1ddae6  vmovaps xmm12, [rsp+0xB0]
0000785dab1ddaef  vmovaps xmm13, [rsp+0xC0]
0000785dab1ddaf8  vmovaps xmm14, [rsp+0xD0]
0000785dab1ddb01  vmovaps xmm15, [rsp+0xE0]
0000785dab1ddb0a  add rsp, 0xF0
0000785dab1ddb11  pop r11
0000785dab1ddb13  pop r10
0000785dab1ddb15  pop r9
0000785dab1ddb17  pop r8
0000785dab1ddb19  pop rsi
0000785dab1ddb1a  pop rdi
0000785dab1ddb1b  pop rdx
0000785dab1ddb1c  pop rcx
0000785dab1ddb1d  pop rax
0000785dab1ddb1e  add rsp, 0x08
0000785dab1ddb22  jmp 0x0000785DAB1DBEAC
0000785dab1ddb27  call 0x0000785DAB0C4620
0000785dab1ddb2c  jmp 0x0000785DAB1DBEB9
0000785dab1ddb31  sub rsp, 0x08
0000785dab1ddb35  push rax
0000785dab1ddb36  push rcx
0000785dab1ddb37  push rdx
0000785dab1ddb38  push rdi
0000785dab1ddb39  push rsi
0000785dab1ddb3a  push r8
0000785dab1ddb3c  push r9
0000785dab1ddb3e  push r10
0000785dab1ddb40  push r11
0000785dab1ddb42  sub rsp, 0xF0
0000785dab1ddb49  vmovaps [rsp], xmm0
0000785dab1ddb4e  vmovaps [rsp+0x10], xmm1
0000785dab1ddb54  vmovaps [rsp+0x20], xmm2
0000785dab1ddb5a  vmovaps [rsp+0x30], xmm4
0000785dab1ddb60  vmovaps [rsp+0x40], xmm5
0000785dab1ddb66  vmovaps [rsp+0x50], xmm6
0000785dab1ddb6c  vmovaps [rsp+0x60], xmm7
0000785dab1ddb72  vmovaps [rsp+0x70], xmm8
0000785dab1ddb78  vmovaps [rsp+0x80], xmm9
0000785dab1ddb81  vmovaps [rsp+0x90], xmm10
0000785dab1ddb8a  vmovaps [rsp+0xA0], xmm11
0000785dab1ddb93  vmovaps [rsp+0xB0], xmm12
0000785dab1ddb9c  vmovaps [rsp+0xC0], xmm13
0000785dab1ddba5  vmovaps [rsp+0xD0], xmm14
0000785dab1ddbae  vmovaps [rsp+0xE0], xmm15
0000785dab1ddbb7  sub rsp, 0x30
0000785dab1ddbbb  movaps [rsp], xmm3
0000785dab1ddbbf  movaps [rsp+0x10], xmm1
0000785dab1ddbc4  movaps [rsp+0x20], xmm9
0000785dab1ddbca  lea rdi, [rsp]
0000785dab1ddbce  mov esi, 0x00
0000785dab1ddbd3  mov rax, 0x61B13BBD6530
0000785dab1ddbdd  call rax
0000785dab1ddbdf  movaps xmm3, [rsp]
0000785dab1ddbe3  add rsp, 0x30
0000785dab1ddbe7  vmovaps xmm0, [rsp]
0000785dab1ddbec  vmovaps xmm1, [rsp+0x10]
0000785dab1ddbf2  vmovaps xmm2, [rsp+0x20]
0000785dab1ddbf8  vmovaps xmm4, [rsp+0x30]
0000785dab1ddbfe  vmovaps xmm5, [rsp+0x40]
0000785dab1ddc04  vmovaps xmm6, [rsp+0x50]
0000785dab1ddc0a  vmovaps xmm7, [rsp+0x60]
0000785dab1ddc10  vmovaps xmm8, [rsp+0x70]
0000785dab1ddc16  vmovaps xmm9, [rsp+0x80]
0000785dab1ddc1f  vmovaps xmm10, [rsp+0x90]
0000785dab1ddc28  vmovaps xmm11, [rsp+0xA0]
0000785dab1ddc31  vmovaps xmm12, [rsp+0xB0]
0000785dab1ddc3a  vmovaps xmm13, [rsp+0xC0]
0000785dab1ddc43  vmovaps xmm14, [rsp+0xD0]
0000785dab1ddc4c  vmovaps xmm15, [rsp+0xE0]
0000785dab1ddc55  add rsp, 0xF0
0000785dab1ddc5c  pop r11
0000785dab1ddc5e  pop r10
0000785dab1ddc60  pop r9
0000785dab1ddc62  pop r8
0000785dab1ddc64  pop rsi
0000785dab1ddc65  pop rdi
0000785dab1ddc66  pop rdx
0000785dab1ddc67  pop rcx
0000785dab1ddc68  pop rax
0000785dab1ddc69  add rsp, 0x08
0000785dab1ddc6d  jmp 0x0000785DAB1DBEF6
0000785dab1ddc72  sub rsp, 0x08
0000785dab1ddc76  push rax
0000785dab1ddc77  push rcx
0000785dab1ddc78  push rdx
0000785dab1ddc79  push rdi
0000785dab1ddc7a  push rsi
0000785dab1ddc7b  push r8
0000785dab1ddc7d  push r9
0000785dab1ddc7f  push r10
0000785dab1ddc81  push r11
0000785dab1ddc83  sub rsp, 0xF0
0000785dab1ddc8a  vmovaps [rsp], xmm0
0000785dab1ddc8f  vmovaps [rsp+0x10], xmm2
0000785dab1ddc95  vmovaps [rsp+0x20], xmm3
0000785dab1ddc9b  vmovaps [rsp+0x30], xmm4
0000785dab1ddca1  vmovaps [rsp+0x40], xmm5
0000785dab1ddca7  vmovaps [rsp+0x50], xmm6
0000785dab1ddcad  vmovaps [rsp+0x60], xmm7
0000785dab1ddcb3  vmovaps [rsp+0x70], xmm8
0000785dab1ddcb9  vmovaps [rsp+0x80], xmm9
0000785dab1ddcc2  vmovaps [rsp+0x90], xmm10
0000785dab1ddccb  vmovaps [rsp+0xA0], xmm11
0000785dab1ddcd4  vmovaps [rsp+0xB0], xmm12
0000785dab1ddcdd  vmovaps [rsp+0xC0], xmm13
0000785dab1ddce6  vmovaps [rsp+0xD0], xmm14
0000785dab1ddcef  vmovaps [rsp+0xE0], xmm15
0000785dab1ddcf8  sub rsp, 0x30
0000785dab1ddcfc  movaps [rsp], xmm1
0000785dab1ddd00  movaps [rsp+0x10], xmm15
0000785dab1ddd06  movaps [rsp+0x20], xmm9
0000785dab1ddd0c  lea rdi, [rsp]
0000785dab1ddd10  mov esi, 0x00
0000785dab1ddd15  mov rax, 0x61B13BBD6530
0000785dab1ddd1f  call rax
0000785dab1ddd21  movaps xmm1, [rsp]
0000785dab1ddd25  add rsp, 0x30
0000785dab1ddd29  vmovaps xmm0, [rsp]
0000785dab1ddd2e  vmovaps xmm2, [rsp+0x10]
0000785dab1ddd34  vmovaps xmm3, [rsp+0x20]
0000785dab1ddd3a  vmovaps xmm4, [rsp+0x30]
0000785dab1ddd40  vmovaps xmm5, [rsp+0x40]
0000785dab1ddd46  vmovaps xmm6, [rsp+0x50]
0000785dab1ddd4c  vmovaps xmm7, [rsp+0x60]
0000785dab1ddd52  vmovaps xmm8, [rsp+0x70]
0000785dab1ddd58  vmovaps xmm9, [rsp+0x80]
0000785dab1ddd61  vmovaps xmm10, [rsp+0x90]
0000785dab1ddd6a  vmovaps xmm11, [rsp+0xA0]
0000785dab1ddd73  vmovaps xmm12, [rsp+0xB0]
0000785dab1ddd7c  vmovaps xmm13, [rsp+0xC0]
0000785dab1ddd85  vmovaps xmm14, [rsp+0xD0]
0000785dab1ddd8e  vmovaps xmm15, [rsp+0xE0]
0000785dab1ddd97  add rsp, 0xF0
0000785dab1ddd9e  pop r11
0000785dab1ddda0  pop r10
0000785dab1ddda2  pop r9
0000785dab1ddda4  pop r8
0000785dab1ddda6  pop rsi
0000785dab1ddda7  pop rdi
0000785dab1ddda8  pop rdx
0000785dab1ddda9  pop rcx
0000785dab1dddaa  pop rax
0000785dab1dddab  add rsp, 0x08
0000785dab1dddaf  jmp 0x0000785DAB1DBF7E
0000785dab1dddb4  call 0x0000785DAB0C4620
0000785dab1dddb9  jmp 0x0000785DAB1DBF8B
0000785dab1dddbe  sub rsp, 0x08
0000785dab1dddc2  push rax
0000785dab1dddc3  push rcx
0000785dab1dddc4  push rdx
0000785dab1dddc5  push rdi
0000785dab1dddc6  push rsi
0000785dab1dddc7  push r8
0000785dab1dddc9  push r9
0000785dab1dddcb  push r10
0000785dab1dddcd  push r11
0000785dab1dddcf  sub rsp, 0xF0
0000785dab1dddd6  vmovaps [rsp], xmm0
0000785dab1ddddb  vmovaps [rsp+0x10], xmm2
0000785dab1ddde1  vmovaps [rsp+0x20], xmm3
0000785dab1ddde7  vmovaps [rsp+0x30], xmm4
0000785dab1ddded  vmovaps [rsp+0x40], xmm5
0000785dab1dddf3  vmovaps [rsp+0x50], xmm6
0000785dab1dddf9  vmovaps [rsp+0x60], xmm7
0000785dab1dddff  vmovaps [rsp+0x70], xmm8
0000785dab1dde05  vmovaps [rsp+0x80], xmm9
0000785dab1dde0e  vmovaps [rsp+0x90], xmm10
0000785dab1dde17  vmovaps [rsp+0xA0], xmm11
0000785dab1dde20  vmovaps [rsp+0xB0], xmm12
0000785dab1dde29  vmovaps [rsp+0xC0], xmm13
0000785dab1dde32  vmovaps [rsp+0xD0], xmm14
0000785dab1dde3b  vmovaps [rsp+0xE0], xmm15
0000785dab1dde44  sub rsp, 0x30
0000785dab1dde48  movaps [rsp], xmm1
0000785dab1dde4c  movaps [rsp+0x10], xmm5
0000785dab1dde51  movaps [rsp+0x20], xmm7
0000785dab1dde56  lea rdi, [rsp]
0000785dab1dde5a  mov esi, 0x00
0000785dab1dde5f  mov rax, 0x61B13BBD6530
0000785dab1dde69  call rax
0000785dab1dde6b  movaps xmm1, [rsp]
0000785dab1dde6f  add rsp, 0x30
0000785dab1dde73  vmovaps xmm0, [rsp]
0000785dab1dde78  vmovaps xmm2, [rsp+0x10]
0000785dab1dde7e  vmovaps xmm3, [rsp+0x20]
0000785dab1dde84  vmovaps xmm4, [rsp+0x30]
0000785dab1dde8a  vmovaps xmm5, [rsp+0x40]
0000785dab1dde90  vmovaps xmm6, [rsp+0x50]
0000785dab1dde96  vmovaps xmm7, [rsp+0x60]
0000785dab1dde9c  vmovaps xmm8, [rsp+0x70]
0000785dab1ddea2  vmovaps xmm9, [rsp+0x80]
0000785dab1ddeab  vmovaps xmm10, [rsp+0x90]
0000785dab1ddeb4  vmovaps xmm11, [rsp+0xA0]
0000785dab1ddebd  vmovaps xmm12, [rsp+0xB0]
0000785dab1ddec6  vmovaps xmm13, [rsp+0xC0]
0000785dab1ddecf  vmovaps xmm14, [rsp+0xD0]
0000785dab1dded8  vmovaps xmm15, [rsp+0xE0]
0000785dab1ddee1  add rsp, 0xF0
0000785dab1ddee8  pop r11
0000785dab1ddeea  pop r10
0000785dab1ddeec  pop r9
0000785dab1ddeee  pop r8
0000785dab1ddef0  pop rsi
0000785dab1ddef1  pop rdi
0000785dab1ddef2  pop rdx
0000785dab1ddef3  pop rcx
0000785dab1ddef4  pop rax
0000785dab1ddef5  add rsp, 0x08
0000785dab1ddef9  jmp 0x0000785DAB1DC030
0000785dab1ddefe  sub rsp, 0x08
0000785dab1ddf02  push rax
0000785dab1ddf03  push rcx
0000785dab1ddf04  push rdx
0000785dab1ddf05  push rdi
0000785dab1ddf06  push rsi
0000785dab1ddf07  push r8
0000785dab1ddf09  push r9
0000785dab1ddf0b  push r10
0000785dab1ddf0d  push r11
0000785dab1ddf0f  sub rsp, 0xF0
0000785dab1ddf16  vmovaps [rsp], xmm0
0000785dab1ddf1b  vmovaps [rsp+0x10], xmm1
0000785dab1ddf21  vmovaps [rsp+0x20], xmm2
0000785dab1ddf27  vmovaps [rsp+0x30], xmm3
0000785dab1ddf2d  vmovaps [rsp+0x40], xmm4
0000785dab1ddf33  vmovaps [rsp+0x50], xmm5
0000785dab1ddf39  vmovaps [rsp+0x60], xmm6
0000785dab1ddf3f  vmovaps [rsp+0x70], xmm8
0000785dab1ddf45  vmovaps [rsp+0x80], xmm9
0000785dab1ddf4e  vmovaps [rsp+0x90], xmm10
0000785dab1ddf57  vmovaps [rsp+0xA0], xmm11
0000785dab1ddf60  vmovaps [rsp+0xB0], xmm12
0000785dab1ddf69  vmovaps [rsp+0xC0], xmm13
0000785dab1ddf72  vmovaps [rsp+0xD0], xmm14
0000785dab1ddf7b  vmovaps [rsp+0xE0], xmm15
0000785dab1ddf84  sub rsp, 0x30
0000785dab1ddf88  movaps [rsp], xmm7
0000785dab1ddf8c  movaps [rsp+0x10], xmm5
0000785dab1ddf91  movaps [rsp+0x20], xmm15
0000785dab1ddf97  lea rdi, [rsp]
0000785dab1ddf9b  mov esi, 0x00
0000785dab1ddfa0  mov rax, 0x61B13BBD6530
0000785dab1ddfaa  call rax
0000785dab1ddfac  movaps xmm7, [rsp]
0000785dab1ddfb0  add rsp, 0x30
0000785dab1ddfb4  vmovaps xmm0, [rsp]
0000785dab1ddfb9  vmovaps xmm1, [rsp+0x10]
0000785dab1ddfbf  vmovaps xmm2, [rsp+0x20]
0000785dab1ddfc5  vmovaps xmm3, [rsp+0x30]
0000785dab1ddfcb  vmovaps xmm4, [rsp+0x40]
0000785dab1ddfd1  vmovaps xmm5, [rsp+0x50]
0000785dab1ddfd7  vmovaps xmm6, [rsp+0x60]
0000785dab1ddfdd  vmovaps xmm8, [rsp+0x70]
0000785dab1ddfe3  vmovaps xmm9, [rsp+0x80]
0000785dab1ddfec  vmovaps xmm10, [rsp+0x90]
0000785dab1ddff5  vmovaps xmm11, [rsp+0xA0]
0000785dab1ddffe  vmovaps xmm12, [rsp+0xB0]
0000785dab1de007  vmovaps xmm13, [rsp+0xC0]
0000785dab1de010  vmovaps xmm14, [rsp+0xD0]
0000785dab1de019  vmovaps xmm15, [rsp+0xE0]
0000785dab1de022  add rsp, 0xF0
0000785dab1de029  pop r11
0000785dab1de02b  pop r10
0000785dab1de02d  pop r9
0000785dab1de02f  pop r8
0000785dab1de031  pop rsi
0000785dab1de032  pop rdi
0000785dab1de033  pop rdx
0000785dab1de034  pop rcx
0000785dab1de035  pop rax
0000785dab1de036  add rsp, 0x08
0000785dab1de03a  jmp 0x0000785DAB1DC066
0000785dab1de03f  call 0x0000785DAB0B52F0
0000785dab1de044  jmp 0x0000785DAB1DC073
0000785dab1de049  sub rsp, 0x08
0000785dab1de04d  push rax
0000785dab1de04e  push rcx
0000785dab1de04f  push rdx
0000785dab1de050  push rdi
0000785dab1de051  push rsi
0000785dab1de052  push r8
0000785dab1de054  push r9
0000785dab1de056  push r10
0000785dab1de058  push r11
0000785dab1de05a  sub rsp, 0xF0
0000785dab1de061  vmovaps [rsp], xmm0
0000785dab1de066  vmovaps [rsp+0x10], xmm1
0000785dab1de06c  vmovaps [rsp+0x20], xmm2
0000785dab1de072  vmovaps [rsp+0x30], xmm3
0000785dab1de078  vmovaps [rsp+0x40], xmm4
0000785dab1de07e  vmovaps [rsp+0x50], xmm5
0000785dab1de084  vmovaps [rsp+0x60], xmm6
0000785dab1de08a  vmovaps [rsp+0x70], xmm7
0000785dab1de090  vmovaps [rsp+0x80], xmm8
0000785dab1de099  vmovaps [rsp+0x90], xmm9
0000785dab1de0a2  vmovaps [rsp+0xA0], xmm10
0000785dab1de0ab  vmovaps [rsp+0xB0], xmm11
0000785dab1de0b4  vmovaps [rsp+0xC0], xmm12
0000785dab1de0bd  vmovaps [rsp+0xD0], xmm13
0000785dab1de0c6  vmovaps [rsp+0xE0], xmm14
0000785dab1de0cf  sub rsp, 0x30
0000785dab1de0d3  movaps [rsp], xmm15
0000785dab1de0d8  movaps [rsp+0x10], xmm5
0000785dab1de0dd  movaps [rsp+0x20], xmm3
0000785dab1de0e2  lea rdi, [rsp]
0000785dab1de0e6  mov esi, 0x00
0000785dab1de0eb  mov rax, 0x61B13BBD6530
0000785dab1de0f5  call rax
0000785dab1de0f7  movaps xmm15, [rsp]
0000785dab1de0fc  add rsp, 0x30
0000785dab1de100  vmovaps xmm0, [rsp]
0000785dab1de105  vmovaps xmm1, [rsp+0x10]
0000785dab1de10b  vmovaps xmm2, [rsp+0x20]
0000785dab1de111  vmovaps xmm3, [rsp+0x30]
0000785dab1de117  vmovaps xmm4, [rsp+0x40]
0000785dab1de11d  vmovaps xmm5, [rsp+0x50]
0000785dab1de123  vmovaps xmm6, [rsp+0x60]
0000785dab1de129  vmovaps xmm7, [rsp+0x70]
0000785dab1de12f  vmovaps xmm8, [rsp+0x80]
0000785dab1de138  vmovaps xmm9, [rsp+0x90]
0000785dab1de141  vmovaps xmm10, [rsp+0xA0]
0000785dab1de14a  vmovaps xmm11, [rsp+0xB0]
0000785dab1de153  vmovaps xmm12, [rsp+0xC0]
0000785dab1de15c  vmovaps xmm13, [rsp+0xD0]
0000785dab1de165  vmovaps xmm14, [rsp+0xE0]
0000785dab1de16e  add rsp, 0xF0
0000785dab1de175  pop r11
0000785dab1de177  pop r10
0000785dab1de179  pop r9
0000785dab1de17b  pop r8
0000785dab1de17d  pop rsi
0000785dab1de17e  pop rdi
0000785dab1de17f  pop rdx
0000785dab1de180  pop rcx
0000785dab1de181  pop rax
0000785dab1de182  add rsp, 0x08
0000785dab1de186  jmp 0x0000785DAB1DC099
0000785dab1de18b  sub rsp, 0x08
0000785dab1de18f  push rax
0000785dab1de190  push rcx
0000785dab1de191  push rdx
0000785dab1de192  push rdi
0000785dab1de193  push rsi
0000785dab1de194  push r8
0000785dab1de196  push r9
0000785dab1de198  push r10
0000785dab1de19a  push r11
0000785dab1de19c  sub rsp, 0xF0
0000785dab1de1a3  vmovaps [rsp], xmm0
0000785dab1de1a8  vmovaps [rsp+0x10], xmm2
0000785dab1de1ae  vmovaps [rsp+0x20], xmm3
0000785dab1de1b4  vmovaps [rsp+0x30], xmm4
0000785dab1de1ba  vmovaps [rsp+0x40], xmm5
0000785dab1de1c0  vmovaps [rsp+0x50], xmm6
0000785dab1de1c6  vmovaps [rsp+0x60], xmm7
0000785dab1de1cc  vmovaps [rsp+0x70], xmm8
0000785dab1de1d2  vmovaps [rsp+0x80], xmm9
0000785dab1de1db  vmovaps [rsp+0x90], xmm10
0000785dab1de1e4  vmovaps [rsp+0xA0], xmm11
0000785dab1de1ed  vmovaps [rsp+0xB0], xmm12
0000785dab1de1f6  vmovaps [rsp+0xC0], xmm13
0000785dab1de1ff  vmovaps [rsp+0xD0], xmm14
0000785dab1de208  vmovaps [rsp+0xE0], xmm15
0000785dab1de211  sub rsp, 0x30
0000785dab1de215  movaps [rsp], xmm1
0000785dab1de219  movaps [rsp+0x10], xmm5
0000785dab1de21e  movaps [rsp+0x20], xmm4
0000785dab1de223  lea rdi, [rsp]
0000785dab1de227  mov esi, 0x00
0000785dab1de22c  mov rax, 0x61B13BBD6530
0000785dab1de236  call rax
0000785dab1de238  movaps xmm1, [rsp]
0000785dab1de23c  add rsp, 0x30
0000785dab1de240  vmovaps xmm0, [rsp]
0000785dab1de245  vmovaps xmm2, [rsp+0x10]
0000785dab1de24b  vmovaps xmm3, [rsp+0x20]
0000785dab1de251  vmovaps xmm4, [rsp+0x30]
0000785dab1de257  vmovaps xmm5, [rsp+0x40]
0000785dab1de25d  vmovaps xmm6, [rsp+0x50]
0000785dab1de263  vmovaps xmm7, [rsp+0x60]
0000785dab1de269  vmovaps xmm8, [rsp+0x70]
0000785dab1de26f  vmovaps xmm9, [rsp+0x80]
0000785dab1de278  vmovaps xmm10, [rsp+0x90]
0000785dab1de281  vmovaps xmm11, [rsp+0xA0]
0000785dab1de28a  vmovaps xmm12, [rsp+0xB0]
0000785dab1de293  vmovaps xmm13, [rsp+0xC0]
0000785dab1de29c  vmovaps xmm14, [rsp+0xD0]
0000785dab1de2a5  vmovaps xmm15, [rsp+0xE0]
0000785dab1de2ae  add rsp, 0xF0
0000785dab1de2b5  pop r11
0000785dab1de2b7  pop r10
0000785dab1de2b9  pop r9
0000785dab1de2bb  pop r8
0000785dab1de2bd  pop rsi
0000785dab1de2be  pop rdi
0000785dab1de2bf  pop rdx
0000785dab1de2c0  pop rcx
0000785dab1de2c1  pop rax
0000785dab1de2c2  add rsp, 0x08
0000785dab1de2c6  jmp 0x0000785DAB1DC0B9
0000785dab1de2cb  sub rsp, 0x08
0000785dab1de2cf  push rax
0000785dab1de2d0  push rcx
0000785dab1de2d1  push rdx
0000785dab1de2d2  push rdi
0000785dab1de2d3  push rsi
0000785dab1de2d4  push r8
0000785dab1de2d6  push r9
0000785dab1de2d8  push r10
0000785dab1de2da  push r11
0000785dab1de2dc  sub rsp, 0xF0
0000785dab1de2e3  vmovaps [rsp], xmm0
0000785dab1de2e8  vmovaps [rsp+0x10], xmm1
0000785dab1de2ee  vmovaps [rsp+0x20], xmm2
0000785dab1de2f4  vmovaps [rsp+0x30], xmm3
0000785dab1de2fa  vmovaps [rsp+0x40], xmm5
0000785dab1de300  vmovaps [rsp+0x50], xmm6
0000785dab1de306  vmovaps [rsp+0x60], xmm7
0000785dab1de30c  vmovaps [rsp+0x70], xmm8
0000785dab1de312  vmovaps [rsp+0x80], xmm9
0000785dab1de31b  vmovaps [rsp+0x90], xmm10
0000785dab1de324  vmovaps [rsp+0xA0], xmm11
0000785dab1de32d  vmovaps [rsp+0xB0], xmm12
0000785dab1de336  vmovaps [rsp+0xC0], xmm13
0000785dab1de33f  vmovaps [rsp+0xD0], xmm14
0000785dab1de348  vmovaps [rsp+0xE0], xmm15
0000785dab1de351  sub rsp, 0x30
0000785dab1de355  movaps [rsp], xmm4
0000785dab1de359  movaps [rsp+0x10], xmm3
0000785dab1de35e  movaps [rsp+0x20], xmm5
0000785dab1de363  lea rdi, [rsp]
0000785dab1de367  mov esi, 0x00
0000785dab1de36c  mov rax, 0x61B13BBD6530
0000785dab1de376  call rax
0000785dab1de378  movaps xmm4, [rsp]
0000785dab1de37c  add rsp, 0x30
0000785dab1de380  vmovaps xmm0, [rsp]
0000785dab1de385  vmovaps xmm1, [rsp+0x10]
0000785dab1de38b  vmovaps xmm2, [rsp+0x20]
0000785dab1de391  vmovaps xmm3, [rsp+0x30]
0000785dab1de397  vmovaps xmm5, [rsp+0x40]
0000785dab1de39d  vmovaps xmm6, [rsp+0x50]
0000785dab1de3a3  vmovaps xmm7, [rsp+0x60]
0000785dab1de3a9  vmovaps xmm8, [rsp+0x70]
0000785dab1de3af  vmovaps xmm9, [rsp+0x80]
0000785dab1de3b8  vmovaps xmm10, [rsp+0x90]
0000785dab1de3c1  vmovaps xmm11, [rsp+0xA0]
0000785dab1de3ca  vmovaps xmm12, [rsp+0xB0]
0000785dab1de3d3  vmovaps xmm13, [rsp+0xC0]
0000785dab1de3dc  vmovaps xmm14, [rsp+0xD0]
0000785dab1de3e5  vmovaps xmm15, [rsp+0xE0]
0000785dab1de3ee  add rsp, 0xF0
0000785dab1de3f5  pop r11
0000785dab1de3f7  pop r10
0000785dab1de3f9  pop r9
0000785dab1de3fb  pop r8
0000785dab1de3fd  pop rsi
0000785dab1de3fe  pop rdi
0000785dab1de3ff  pop rdx
0000785dab1de400  pop rcx
0000785dab1de401  pop rax
0000785dab1de402  add rsp, 0x08
0000785dab1de406  jmp 0x0000785DAB1DC107
0000785dab1de40b  call 0x0000785DAB0B52F0
0000785dab1de410  jmp 0x0000785DAB1DC114
0000785dab1de415  sub rsp, 0x08
0000785dab1de419  push rax
0000785dab1de41a  push rcx
0000785dab1de41b  push rdx
0000785dab1de41c  push rdi
0000785dab1de41d  push rsi
0000785dab1de41e  push r8
0000785dab1de420  push r9
0000785dab1de422  push r10
0000785dab1de424  push r11
0000785dab1de426  sub rsp, 0xF0
0000785dab1de42d  vmovaps [rsp], xmm0
0000785dab1de432  vmovaps [rsp+0x10], xmm1
0000785dab1de438  vmovaps [rsp+0x20], xmm2
0000785dab1de43e  vmovaps [rsp+0x30], xmm3
0000785dab1de444  vmovaps [rsp+0x40], xmm4
0000785dab1de44a  vmovaps [rsp+0x50], xmm6
0000785dab1de450  vmovaps [rsp+0x60], xmm7
0000785dab1de456  vmovaps [rsp+0x70], xmm8
0000785dab1de45c  vmovaps [rsp+0x80], xmm9
0000785dab1de465  vmovaps [rsp+0x90], xmm10
0000785dab1de46e  vmovaps [rsp+0xA0], xmm11
0000785dab1de477  vmovaps [rsp+0xB0], xmm12
0000785dab1de480  vmovaps [rsp+0xC0], xmm13
0000785dab1de489  vmovaps [rsp+0xD0], xmm14
0000785dab1de492  vmovaps [rsp+0xE0], xmm15
0000785dab1de49b  sub rsp, 0x30
0000785dab1de49f  movaps [rsp], xmm5
0000785dab1de4a3  movaps [rsp+0x10], xmm6
0000785dab1de4a8  movaps [rsp+0x20], xmm3
0000785dab1de4ad  lea rdi, [rsp]
0000785dab1de4b1  mov esi, 0x00
0000785dab1de4b6  mov rax, 0x61B13BBD6530
0000785dab1de4c0  call rax
0000785dab1de4c2  movaps xmm5, [rsp]
0000785dab1de4c6  add rsp, 0x30
0000785dab1de4ca  vmovaps xmm0, [rsp]
0000785dab1de4cf  vmovaps xmm1, [rsp+0x10]
0000785dab1de4d5  vmovaps xmm2, [rsp+0x20]
0000785dab1de4db  vmovaps xmm3, [rsp+0x30]
0000785dab1de4e1  vmovaps xmm4, [rsp+0x40]
0000785dab1de4e7  vmovaps xmm6, [rsp+0x50]
0000785dab1de4ed  vmovaps xmm7, [rsp+0x60]
0000785dab1de4f3  vmovaps xmm8, [rsp+0x70]
0000785dab1de4f9  vmovaps xmm9, [rsp+0x80]
0000785dab1de502  vmovaps xmm10, [rsp+0x90]
0000785dab1de50b  vmovaps xmm11, [rsp+0xA0]
0000785dab1de514  vmovaps xmm12, [rsp+0xB0]
0000785dab1de51d  vmovaps xmm13, [rsp+0xC0]
0000785dab1de526  vmovaps xmm14, [rsp+0xD0]
0000785dab1de52f  vmovaps xmm15, [rsp+0xE0]
0000785dab1de538  add rsp, 0xF0
0000785dab1de53f  pop r11
0000785dab1de541  pop r10
0000785dab1de543  pop r9
0000785dab1de545  pop r8
0000785dab1de547  pop rsi
0000785dab1de548  pop rdi
0000785dab1de549  pop rdx
0000785dab1de54a  pop rcx
0000785dab1de54b  pop rax
0000785dab1de54c  add rsp, 0x08
0000785dab1de550  jmp 0x0000785DAB1DC13A
0000785dab1de555  sub rsp, 0x08
0000785dab1de559  push rax
0000785dab1de55a  push rcx
0000785dab1de55b  push rdx
0000785dab1de55c  push rdi
0000785dab1de55d  push rsi
0000785dab1de55e  push r8
0000785dab1de560  push r9
0000785dab1de562  push r10
0000785dab1de564  push r11
0000785dab1de566  sub rsp, 0xF0
0000785dab1de56d  vmovaps [rsp], xmm0
0000785dab1de572  vmovaps [rsp+0x10], xmm1
0000785dab1de578  vmovaps [rsp+0x20], xmm2
0000785dab1de57e  vmovaps [rsp+0x30], xmm3
0000785dab1de584  vmovaps [rsp+0x40], xmm4
0000785dab1de58a  vmovaps [rsp+0x50], xmm5
0000785dab1de590  vmovaps [rsp+0x60], xmm7
0000785dab1de596  vmovaps [rsp+0x70], xmm8
0000785dab1de59c  vmovaps [rsp+0x80], xmm9
0000785dab1de5a5  vmovaps [rsp+0x90], xmm10
0000785dab1de5ae  vmovaps [rsp+0xA0], xmm11
0000785dab1de5b7  vmovaps [rsp+0xB0], xmm12
0000785dab1de5c0  vmovaps [rsp+0xC0], xmm13
0000785dab1de5c9  vmovaps [rsp+0xD0], xmm14
0000785dab1de5d2  vmovaps [rsp+0xE0], xmm15
0000785dab1de5db  sub rsp, 0x30
0000785dab1de5df  movaps [rsp], xmm6
0000785dab1de5e3  movaps [rsp+0x10], xmm9
0000785dab1de5e9  movaps [rsp+0x20], xmm1
0000785dab1de5ee  lea rdi, [rsp]
0000785dab1de5f2  mov esi, 0x00
0000785dab1de5f7  mov rax, 0x61B13BBD6530
0000785dab1de601  call rax
0000785dab1de603  movaps xmm6, [rsp]
0000785dab1de607  add rsp, 0x30
0000785dab1de60b  vmovaps xmm0, [rsp]
0000785dab1de610  vmovaps xmm1, [rsp+0x10]
0000785dab1de616  vmovaps xmm2, [rsp+0x20]
0000785dab1de61c  vmovaps xmm3, [rsp+0x30]
0000785dab1de622  vmovaps xmm4, [rsp+0x40]
0000785dab1de628  vmovaps xmm5, [rsp+0x50]
0000785dab1de62e  vmovaps xmm7, [rsp+0x60]
0000785dab1de634  vmovaps xmm8, [rsp+0x70]
0000785dab1de63a  vmovaps xmm9, [rsp+0x80]
0000785dab1de643  vmovaps xmm10, [rsp+0x90]
0000785dab1de64c  vmovaps xmm11, [rsp+0xA0]
0000785dab1de655  vmovaps xmm12, [rsp+0xB0]
0000785dab1de65e  vmovaps xmm13, [rsp+0xC0]
0000785dab1de667  vmovaps xmm14, [rsp+0xD0]
0000785dab1de670  vmovaps xmm15, [rsp+0xE0]
0000785dab1de679  add rsp, 0xF0
0000785dab1de680  pop r11
0000785dab1de682  pop r10
0000785dab1de684  pop r9
0000785dab1de686  pop r8
0000785dab1de688  pop rsi
0000785dab1de689  pop rdi
0000785dab1de68a  pop rdx
0000785dab1de68b  pop rcx
0000785dab1de68c  pop rax
0000785dab1de68d  add rsp, 0x08
0000785dab1de691  jmp 0x0000785DAB1DC15E
0000785dab1de696  sub rsp, 0x08
0000785dab1de69a  push rax
0000785dab1de69b  push rcx
0000785dab1de69c  push rdx
0000785dab1de69d  push rdi
0000785dab1de69e  push rsi
0000785dab1de69f  push r8
0000785dab1de6a1  push r9
0000785dab1de6a3  push r10
0000785dab1de6a5  push r11
0000785dab1de6a7  sub rsp, 0xF0
0000785dab1de6ae  vmovaps [rsp], xmm0
0000785dab1de6b3  vmovaps [rsp+0x10], xmm1
0000785dab1de6b9  vmovaps [rsp+0x20], xmm2
0000785dab1de6bf  vmovaps [rsp+0x30], xmm3
0000785dab1de6c5  vmovaps [rsp+0x40], xmm4
0000785dab1de6cb  vmovaps [rsp+0x50], xmm5
0000785dab1de6d1  vmovaps [rsp+0x60], xmm6
0000785dab1de6d7  vmovaps [rsp+0x70], xmm7
0000785dab1de6dd  vmovaps [rsp+0x80], xmm8
0000785dab1de6e6  vmovaps [rsp+0x90], xmm10
0000785dab1de6ef  vmovaps [rsp+0xA0], xmm11
0000785dab1de6f8  vmovaps [rsp+0xB0], xmm12
0000785dab1de701  vmovaps [rsp+0xC0], xmm13
0000785dab1de70a  vmovaps [rsp+0xD0], xmm14
0000785dab1de713  vmovaps [rsp+0xE0], xmm15
0000785dab1de71c  sub rsp, 0x30
0000785dab1de720  movaps [rsp], xmm9
0000785dab1de725  movaps [rsp+0x10], xmm3
0000785dab1de72a  movaps [rsp+0x20], xmm1
0000785dab1de72f  lea rdi, [rsp]
0000785dab1de733  mov esi, 0x00
0000785dab1de738  mov rax, 0x61B13BBD6530
0000785dab1de742  call rax
0000785dab1de744  movaps xmm9, [rsp]
0000785dab1de749  add rsp, 0x30
0000785dab1de74d  vmovaps xmm0, [rsp]
0000785dab1de752  vmovaps xmm1, [rsp+0x10]
0000785dab1de758  vmovaps xmm2, [rsp+0x20]
0000785dab1de75e  vmovaps xmm3, [rsp+0x30]
0000785dab1de764  vmovaps xmm4, [rsp+0x40]
0000785dab1de76a  vmovaps xmm5, [rsp+0x50]
0000785dab1de770  vmovaps xmm6, [rsp+0x60]
0000785dab1de776  vmovaps xmm7, [rsp+0x70]
0000785dab1de77c  vmovaps xmm8, [rsp+0x80]
0000785dab1de785  vmovaps xmm10, [rsp+0x90]
0000785dab1de78e  vmovaps xmm11, [rsp+0xA0]
0000785dab1de797  vmovaps xmm12, [rsp+0xB0]
0000785dab1de7a0  vmovaps xmm13, [rsp+0xC0]
0000785dab1de7a9  vmovaps xmm14, [rsp+0xD0]
0000785dab1de7b2  vmovaps xmm15, [rsp+0xE0]
0000785dab1de7bb  add rsp, 0xF0
0000785dab1de7c2  pop r11
0000785dab1de7c4  pop r10
0000785dab1de7c6  pop r9
0000785dab1de7c8  pop r8
0000785dab1de7ca  pop rsi
0000785dab1de7cb  pop rdi
0000785dab1de7cc  pop rdx
0000785dab1de7cd  pop rcx
0000785dab1de7ce  pop rax
0000785dab1de7cf  add rsp, 0x08
0000785dab1de7d3  jmp 0x0000785DAB1DC1AA
0000785dab1de7d8  call 0x0000785DAB0B52F0
0000785dab1de7dd  jmp 0x0000785DAB1DC1B7
0000785dab1de7e2  sub rsp, 0x08
0000785dab1de7e6  push rax
0000785dab1de7e7  push rcx
0000785dab1de7e8  push rdx
0000785dab1de7e9  push rdi
0000785dab1de7ea  push rsi
0000785dab1de7eb  push r8
0000785dab1de7ed  push r9
0000785dab1de7ef  push r10
0000785dab1de7f1  push r11
0000785dab1de7f3  sub rsp, 0xF0
0000785dab1de7fa  vmovaps [rsp], xmm0
0000785dab1de7ff  vmovaps [rsp+0x10], xmm1
0000785dab1de805  vmovaps [rsp+0x20], xmm2
0000785dab1de80b  vmovaps [rsp+0x30], xmm3
0000785dab1de811  vmovaps [rsp+0x40], xmm4
0000785dab1de817  vmovaps [rsp+0x50], xmm5
0000785dab1de81d  vmovaps [rsp+0x60], xmm6
0000785dab1de823  vmovaps [rsp+0x70], xmm7
0000785dab1de829  vmovaps [rsp+0x80], xmm8
0000785dab1de832  vmovaps [rsp+0x90], xmm9
0000785dab1de83b  vmovaps [rsp+0xA0], xmm10
0000785dab1de844  vmovaps [rsp+0xB0], xmm11
0000785dab1de84d  vmovaps [rsp+0xC0], xmm12
0000785dab1de856  vmovaps [rsp+0xD0], xmm13
0000785dab1de85f  vmovaps [rsp+0xE0], xmm14
0000785dab1de868  sub rsp, 0x30
0000785dab1de86c  movaps [rsp], xmm15
0000785dab1de871  movaps [rsp+0x10], xmm3
0000785dab1de876  movaps [rsp+0x20], xmm7
0000785dab1de87b  lea rdi, [rsp]
0000785dab1de87f  mov esi, 0x00
0000785dab1de884  mov rax, 0x61B13BBD6530
0000785dab1de88e  call rax
0000785dab1de890  movaps xmm15, [rsp]
0000785dab1de895  add rsp, 0x30
0000785dab1de899  vmovaps xmm0, [rsp]
0000785dab1de89e  vmovaps xmm1, [rsp+0x10]
0000785dab1de8a4  vmovaps xmm2, [rsp+0x20]
0000785dab1de8aa  vmovaps xmm3, [rsp+0x30]
0000785dab1de8b0  vmovaps xmm4, [rsp+0x40]
0000785dab1de8b6  vmovaps xmm5, [rsp+0x50]
0000785dab1de8bc  vmovaps xmm6, [rsp+0x60]
0000785dab1de8c2  vmovaps xmm7, [rsp+0x70]
0000785dab1de8c8  vmovaps xmm8, [rsp+0x80]
0000785dab1de8d1  vmovaps xmm9, [rsp+0x90]
0000785dab1de8da  vmovaps xmm10, [rsp+0xA0]
0000785dab1de8e3  vmovaps xmm11, [rsp+0xB0]
0000785dab1de8ec  vmovaps xmm12, [rsp+0xC0]
0000785dab1de8f5  vmovaps xmm13, [rsp+0xD0]
0000785dab1de8fe  vmovaps xmm14, [rsp+0xE0]
0000785dab1de907  add rsp, 0xF0
0000785dab1de90e  pop r11
0000785dab1de910  pop r10
0000785dab1de912  pop r9
0000785dab1de914  pop r8
0000785dab1de916  pop rsi
0000785dab1de917  pop rdi
0000785dab1de918  pop rdx
0000785dab1de919  pop rcx
0000785dab1de91a  pop rax
0000785dab1de91b  add rsp, 0x08
0000785dab1de91f  jmp 0x0000785DAB1DC1E3
0000785dab1de924  sub rsp, 0x08
0000785dab1de928  push rax
0000785dab1de929  push rcx
0000785dab1de92a  push rdx
0000785dab1de92b  push rdi
0000785dab1de92c  push rsi
0000785dab1de92d  push r8
0000785dab1de92f  push r9
0000785dab1de931  push r10
0000785dab1de933  push r11
0000785dab1de935  sub rsp, 0xF0
0000785dab1de93c  vmovaps [rsp], xmm0
0000785dab1de941  vmovaps [rsp+0x10], xmm1
0000785dab1de947  vmovaps [rsp+0x20], xmm2
0000785dab1de94d  vmovaps [rsp+0x30], xmm4
0000785dab1de953  vmovaps [rsp+0x40], xmm5
0000785dab1de959  vmovaps [rsp+0x50], xmm6
0000785dab1de95f  vmovaps [rsp+0x60], xmm7
0000785dab1de965  vmovaps [rsp+0x70], xmm8
0000785dab1de96b  vmovaps [rsp+0x80], xmm9
0000785dab1de974  vmovaps [rsp+0x90], xmm10
0000785dab1de97d  vmovaps [rsp+0xA0], xmm11
0000785dab1de986  vmovaps [rsp+0xB0], xmm12
0000785dab1de98f  vmovaps [rsp+0xC0], xmm13
0000785dab1de998  vmovaps [rsp+0xD0], xmm14
0000785dab1de9a1  vmovaps [rsp+0xE0], xmm15
0000785dab1de9aa  sub rsp, 0x30
0000785dab1de9ae  movaps [rsp], xmm3
0000785dab1de9b2  movaps [rsp+0x10], xmm1
0000785dab1de9b7  movaps [rsp+0x20], xmm15
0000785dab1de9bd  lea rdi, [rsp]
0000785dab1de9c1  mov esi, 0x00
0000785dab1de9c6  mov rax, 0x61B13BBD6530
0000785dab1de9d0  call rax
0000785dab1de9d2  movaps xmm3, [rsp]
0000785dab1de9d6  add rsp, 0x30
0000785dab1de9da  vmovaps xmm0, [rsp]
0000785dab1de9df  vmovaps xmm1, [rsp+0x10]
0000785dab1de9e5  vmovaps xmm2, [rsp+0x20]
0000785dab1de9eb  vmovaps xmm4, [rsp+0x30]
0000785dab1de9f1  vmovaps xmm5, [rsp+0x40]
0000785dab1de9f7  vmovaps xmm6, [rsp+0x50]
0000785dab1de9fd  vmovaps xmm7, [rsp+0x60]
0000785dab1dea03  vmovaps xmm8, [rsp+0x70]
0000785dab1dea09  vmovaps xmm9, [rsp+0x80]
0000785dab1dea12  vmovaps xmm10, [rsp+0x90]
0000785dab1dea1b  vmovaps xmm11, [rsp+0xA0]
0000785dab1dea24  vmovaps xmm12, [rsp+0xB0]
0000785dab1dea2d  vmovaps xmm13, [rsp+0xC0]
0000785dab1dea36  vmovaps xmm14, [rsp+0xD0]
0000785dab1dea3f  vmovaps xmm15, [rsp+0xE0]
0000785dab1dea48  add rsp, 0xF0
0000785dab1dea4f  pop r11
0000785dab1dea51  pop r10
0000785dab1dea53  pop r9
0000785dab1dea55  pop r8
0000785dab1dea57  pop rsi
0000785dab1dea58  pop rdi
0000785dab1dea59  pop rdx
0000785dab1dea5a  pop rcx
0000785dab1dea5b  pop rax
0000785dab1dea5c  add rsp, 0x08
0000785dab1dea60  jmp 0x0000785DAB1DC272
0000785dab1dea65  call 0x0000785DAB0B52F0
0000785dab1dea6a  jmp 0x0000785DAB1DC27C
0000785dab1dea6f  sub rsp, 0x08
0000785dab1dea73  push rax
0000785dab1dea74  push rcx
0000785dab1dea75  push rdx
0000785dab1dea76  push rdi
0000785dab1dea77  push rsi
0000785dab1dea78  push r8
0000785dab1dea7a  push r9
0000785dab1dea7c  push r10
0000785dab1dea7e  push r11
0000785dab1dea80  sub rsp, 0xF0
0000785dab1dea87  vmovaps [rsp], xmm0
0000785dab1dea8c  vmovaps [rsp+0x10], xmm1
0000785dab1dea92  vmovaps [rsp+0x20], xmm2
0000785dab1dea98  vmovaps [rsp+0x30], xmm3
0000785dab1dea9e  vmovaps [rsp+0x40], xmm4
0000785dab1deaa4  vmovaps [rsp+0x50], xmm5
0000785dab1deaaa  vmovaps [rsp+0x60], xmm6
0000785dab1deab0  vmovaps [rsp+0x70], xmm7
0000785dab1deab6  vmovaps [rsp+0x80], xmm8
0000785dab1deabf  vmovaps [rsp+0x90], xmm9
0000785dab1deac8  vmovaps [rsp+0xA0], xmm10
0000785dab1dead1  vmovaps [rsp+0xB0], xmm11
0000785dab1deada  vmovaps [rsp+0xC0], xmm12
0000785dab1deae3  vmovaps [rsp+0xD0], xmm13
0000785dab1deaec  vmovaps [rsp+0xE0], xmm14
0000785dab1deaf5  sub rsp, 0x30
0000785dab1deaf9  movaps [rsp], xmm15
0000785dab1deafe  movaps [rsp+0x10], xmm14
0000785dab1deb04  movaps [rsp+0x20], xmm4
0000785dab1deb09  lea rdi, [rsp]
0000785dab1deb0d  mov esi, 0x00
0000785dab1deb12  mov rax, 0x61B13BBD6530
0000785dab1deb1c  call rax
0000785dab1deb1e  movaps xmm15, [rsp]
0000785dab1deb23  add rsp, 0x30
0000785dab1deb27  vmovaps xmm0, [rsp]
0000785dab1deb2c  vmovaps xmm1, [rsp+0x10]
0000785dab1deb32  vmovaps xmm2, [rsp+0x20]
0000785dab1deb38  vmovaps xmm3, [rsp+0x30]
0000785dab1deb3e  vmovaps xmm4, [rsp+0x40]
0000785dab1deb44  vmovaps xmm5, [rsp+0x50]
0000785dab1deb4a  vmovaps xmm6, [rsp+0x60]
0000785dab1deb50  vmovaps xmm7, [rsp+0x70]
0000785dab1deb56  vmovaps xmm8, [rsp+0x80]
0000785dab1deb5f  vmovaps xmm9, [rsp+0x90]
0000785dab1deb68  vmovaps xmm10, [rsp+0xA0]
0000785dab1deb71  vmovaps xmm11, [rsp+0xB0]
0000785dab1deb7a  vmovaps xmm12, [rsp+0xC0]
0000785dab1deb83  vmovaps xmm13, [rsp+0xD0]
0000785dab1deb8c  vmovaps xmm14, [rsp+0xE0]
0000785dab1deb95  add rsp, 0xF0
0000785dab1deb9c  pop r11
0000785dab1deb9e  pop r10
0000785dab1deba0  pop r9
0000785dab1deba2  pop r8
0000785dab1deba4  pop rsi
0000785dab1deba5  pop rdi
0000785dab1deba6  pop rdx
0000785dab1deba7  pop rcx
0000785dab1deba8  pop rax
0000785dab1deba9  add rsp, 0x08
0000785dab1debad  jmp 0x0000785DAB1DC2AA
0000785dab1debb2  sub rsp, 0x08
0000785dab1debb6  push rax
0000785dab1debb7  push rcx
0000785dab1debb8  push rdx
0000785dab1debb9  push rdi
0000785dab1debba  push rsi
0000785dab1debbb  push r8
0000785dab1debbd  push r9
0000785dab1debbf  push r10
0000785dab1debc1  push r11
0000785dab1debc3  sub rsp, 0xF0
0000785dab1debca  vmovaps [rsp], xmm0
0000785dab1debcf  vmovaps [rsp+0x10], xmm1
0000785dab1debd5  vmovaps [rsp+0x20], xmm2
0000785dab1debdb  vmovaps [rsp+0x30], xmm3
0000785dab1debe1  vmovaps [rsp+0x40], xmm4
0000785dab1debe7  vmovaps [rsp+0x50], xmm5
0000785dab1debed  vmovaps [rsp+0x60], xmm6
0000785dab1debf3  vmovaps [rsp+0x70], xmm7
0000785dab1debf9  vmovaps [rsp+0x80], xmm8
0000785dab1dec02  vmovaps [rsp+0x90], xmm9
0000785dab1dec0b  vmovaps [rsp+0xA0], xmm10
0000785dab1dec14  vmovaps [rsp+0xB0], xmm11
0000785dab1dec1d  vmovaps [rsp+0xC0], xmm12
0000785dab1dec26  vmovaps [rsp+0xD0], xmm13
0000785dab1dec2f  vmovaps [rsp+0xE0], xmm15
0000785dab1dec38  sub rsp, 0x30
0000785dab1dec3c  movaps [rsp], xmm14
0000785dab1dec41  movaps [rsp+0x10], xmm2
0000785dab1dec46  movaps [rsp+0x20], xmm1
0000785dab1dec4b  lea rdi, [rsp]
0000785dab1dec4f  mov esi, 0x00
0000785dab1dec54  mov rax, 0x61B13BBD6530
0000785dab1dec5e  call rax
0000785dab1dec60  movaps xmm14, [rsp]
0000785dab1dec65  add rsp, 0x30
0000785dab1dec69  vmovaps xmm0, [rsp]
0000785dab1dec6e  vmovaps xmm1, [rsp+0x10]
0000785dab1dec74  vmovaps xmm2, [rsp+0x20]
0000785dab1dec7a  vmovaps xmm3, [rsp+0x30]
0000785dab1dec80  vmovaps xmm4, [rsp+0x40]
0000785dab1dec86  vmovaps xmm5, [rsp+0x50]
0000785dab1dec8c  vmovaps xmm6, [rsp+0x60]
0000785dab1dec92  vmovaps xmm7, [rsp+0x70]
0000785dab1dec98  vmovaps xmm8, [rsp+0x80]
0000785dab1deca1  vmovaps xmm9, [rsp+0x90]
0000785dab1decaa  vmovaps xmm10, [rsp+0xA0]
0000785dab1decb3  vmovaps xmm11, [rsp+0xB0]
0000785dab1decbc  vmovaps xmm12, [rsp+0xC0]
0000785dab1decc5  vmovaps xmm13, [rsp+0xD0]
0000785dab1decce  vmovaps xmm15, [rsp+0xE0]
0000785dab1decd7  add rsp, 0xF0
0000785dab1decde  pop r11
0000785dab1dece0  pop r10
0000785dab1dece2  pop r9
0000785dab1dece4  pop r8
0000785dab1dece6  pop rsi
0000785dab1dece7  pop rdi
0000785dab1dece8  pop rdx
0000785dab1dece9  pop rcx
0000785dab1decea  pop rax
0000785dab1deceb  add rsp, 0x08
0000785dab1decef  jmp 0x0000785DAB1DC2D0
0000785dab1decf4  sub rsp, 0x08
0000785dab1decf8  push rax
0000785dab1decf9  push rcx
0000785dab1decfa  push rdx
0000785dab1decfb  push rdi
0000785dab1decfc  push rsi
0000785dab1decfd  push r8
0000785dab1decff  push r9
0000785dab1ded01  push r10
0000785dab1ded03  push r11
0000785dab1ded05  sub rsp, 0xF0
0000785dab1ded0c  vmovaps [rsp], xmm0
0000785dab1ded11  vmovaps [rsp+0x10], xmm2
0000785dab1ded17  vmovaps [rsp+0x20], xmm3
0000785dab1ded1d  vmovaps [rsp+0x30], xmm4
0000785dab1ded23  vmovaps [rsp+0x40], xmm5
0000785dab1ded29  vmovaps [rsp+0x50], xmm6
0000785dab1ded2f  vmovaps [rsp+0x60], xmm7
0000785dab1ded35  vmovaps [rsp+0x70], xmm8
0000785dab1ded3b  vmovaps [rsp+0x80], xmm9
0000785dab1ded44  vmovaps [rsp+0x90], xmm10
0000785dab1ded4d  vmovaps [rsp+0xA0], xmm11
0000785dab1ded56  vmovaps [rsp+0xB0], xmm12
0000785dab1ded5f  vmovaps [rsp+0xC0], xmm13
0000785dab1ded68  vmovaps [rsp+0xD0], xmm14
0000785dab1ded71  vmovaps [rsp+0xE0], xmm15
0000785dab1ded7a  sub rsp, 0x30
0000785dab1ded7e  movaps [rsp], xmm1
0000785dab1ded82  movaps [rsp+0x10], xmm4
0000785dab1ded87  movaps [rsp+0x20], xmm9
0000785dab1ded8d  lea rdi, [rsp]
0000785dab1ded91  mov esi, 0x00
0000785dab1ded96  mov rax, 0x61B13BBD6530
0000785dab1deda0  call rax
0000785dab1deda2  movaps xmm1, [rsp]
0000785dab1deda6  add rsp, 0x30
0000785dab1dedaa  vmovaps xmm0, [rsp]
0000785dab1dedaf  vmovaps xmm2, [rsp+0x10]
0000785dab1dedb5  vmovaps xmm3, [rsp+0x20]
0000785dab1dedbb  vmovaps xmm4, [rsp+0x30]
0000785dab1dedc1  vmovaps xmm5, [rsp+0x40]
0000785dab1dedc7  vmovaps xmm6, [rsp+0x50]
0000785dab1dedcd  vmovaps xmm7, [rsp+0x60]
0000785dab1dedd3  vmovaps xmm8, [rsp+0x70]
0000785dab1dedd9  vmovaps xmm9, [rsp+0x80]
0000785dab1dede2  vmovaps xmm10, [rsp+0x90]
0000785dab1dedeb  vmovaps xmm11, [rsp+0xA0]
0000785dab1dedf4  vmovaps xmm12, [rsp+0xB0]
0000785dab1dedfd  vmovaps xmm13, [rsp+0xC0]
0000785dab1dee06  vmovaps xmm14, [rsp+0xD0]
0000785dab1dee0f  vmovaps xmm15, [rsp+0xE0]
0000785dab1dee18  add rsp, 0xF0
0000785dab1dee1f  pop r11
0000785dab1dee21  pop r10
0000785dab1dee23  pop r9
0000785dab1dee25  pop r8
0000785dab1dee27  pop rsi
0000785dab1dee28  pop rdi
0000785dab1dee29  pop rdx
0000785dab1dee2a  pop rcx
0000785dab1dee2b  pop rax
0000785dab1dee2c  add rsp, 0x08
0000785dab1dee30  jmp 0x0000785DAB1DC2EE
0000785dab1dee35  sub rsp, 0x08
0000785dab1dee39  push rax
0000785dab1dee3a  push rcx
0000785dab1dee3b  push rdx
0000785dab1dee3c  push rdi
0000785dab1dee3d  push rsi
0000785dab1dee3e  push r8
0000785dab1dee40  push r9
0000785dab1dee42  push r10
0000785dab1dee44  push r11
0000785dab1dee46  sub rsp, 0xF0
0000785dab1dee4d  vmovaps [rsp], xmm0
0000785dab1dee52  vmovaps [rsp+0x10], xmm1
0000785dab1dee58  vmovaps [rsp+0x20], xmm2
0000785dab1dee5e  vmovaps [rsp+0x30], xmm3
0000785dab1dee64  vmovaps [rsp+0x40], xmm5
0000785dab1dee6a  vmovaps [rsp+0x50], xmm6
0000785dab1dee70  vmovaps [rsp+0x60], xmm7
0000785dab1dee76  vmovaps [rsp+0x70], xmm8
0000785dab1dee7c  vmovaps [rsp+0x80], xmm9
0000785dab1dee85  vmovaps [rsp+0x90], xmm10
0000785dab1dee8e  vmovaps [rsp+0xA0], xmm11
0000785dab1dee97  vmovaps [rsp+0xB0], xmm12
0000785dab1deea0  vmovaps [rsp+0xC0], xmm13
0000785dab1deea9  vmovaps [rsp+0xD0], xmm14
0000785dab1deeb2  vmovaps [rsp+0xE0], xmm15
0000785dab1deebb  sub rsp, 0x30
0000785dab1deebf  movaps [rsp], xmm4
0000785dab1deec3  movaps [rsp+0x10], xmm2
0000785dab1deec8  movaps [rsp+0x20], xmm9
0000785dab1deece  lea rdi, [rsp]
0000785dab1deed2  mov esi, 0x00
0000785dab1deed7  mov rax, 0x61B13BBD6530
0000785dab1deee1  call rax
0000785dab1deee3  movaps xmm4, [rsp]
0000785dab1deee7  add rsp, 0x30
0000785dab1deeeb  vmovaps xmm0, [rsp]
0000785dab1deef0  vmovaps xmm1, [rsp+0x10]
0000785dab1deef6  vmovaps xmm2, [rsp+0x20]
0000785dab1deefc  vmovaps xmm3, [rsp+0x30]
0000785dab1def02  vmovaps xmm5, [rsp+0x40]
0000785dab1def08  vmovaps xmm6, [rsp+0x50]
0000785dab1def0e  vmovaps xmm7, [rsp+0x60]
0000785dab1def14  vmovaps xmm8, [rsp+0x70]
0000785dab1def1a  vmovaps xmm9, [rsp+0x80]
0000785dab1def23  vmovaps xmm10, [rsp+0x90]
0000785dab1def2c  vmovaps xmm11, [rsp+0xA0]
0000785dab1def35  vmovaps xmm12, [rsp+0xB0]
0000785dab1def3e  vmovaps xmm13, [rsp+0xC0]
0000785dab1def47  vmovaps xmm14, [rsp+0xD0]
0000785dab1def50  vmovaps xmm15, [rsp+0xE0]
0000785dab1def59  add rsp, 0xF0
0000785dab1def60  pop r11
0000785dab1def62  pop r10
0000785dab1def64  pop r9
0000785dab1def66  pop r8
0000785dab1def68  pop rsi
0000785dab1def69  pop rdi
0000785dab1def6a  pop rdx
0000785dab1def6b  pop rcx
0000785dab1def6c  pop rax
0000785dab1def6d  add rsp, 0x08
0000785dab1def71  jmp 0x0000785DAB1DC31E
0000785dab1def76  sub rsp, 0x08
0000785dab1def7a  push rax
0000785dab1def7b  push rcx
0000785dab1def7c  push rdx
0000785dab1def7d  push rdi
0000785dab1def7e  push rsi
0000785dab1def7f  push r8
0000785dab1def81  push r9
0000785dab1def83  push r10
0000785dab1def85  push r11
0000785dab1def87  sub rsp, 0xF0
0000785dab1def8e  vmovaps [rsp], xmm0
0000785dab1def93  vmovaps [rsp+0x10], xmm1
0000785dab1def99  vmovaps [rsp+0x20], xmm2
0000785dab1def9f  vmovaps [rsp+0x30], xmm3
0000785dab1defa5  vmovaps [rsp+0x40], xmm4
0000785dab1defab  vmovaps [rsp+0x50], xmm5
0000785dab1defb1  vmovaps [rsp+0x60], xmm6
0000785dab1defb7  vmovaps [rsp+0x70], xmm7
0000785dab1defbd  vmovaps [rsp+0x80], xmm8
0000785dab1defc6  vmovaps [rsp+0x90], xmm10
0000785dab1defcf  vmovaps [rsp+0xA0], xmm11
0000785dab1defd8  vmovaps [rsp+0xB0], xmm12
0000785dab1defe1  vmovaps [rsp+0xC0], xmm13
0000785dab1defea  vmovaps [rsp+0xD0], xmm14
0000785dab1deff3  vmovaps [rsp+0xE0], xmm15
0000785dab1deffc  sub rsp, 0x30
0000785dab1df000  movaps [rsp], xmm9
0000785dab1df005  movaps [rsp+0x10], xmm2
0000785dab1df00a  movaps [rsp+0x20], xmm1
0000785dab1df00f  lea rdi, [rsp]
0000785dab1df013  mov esi, 0x00
0000785dab1df018  mov rax, 0x61B13BBD6530
0000785dab1df022  call rax
0000785dab1df024  movaps xmm9, [rsp]
0000785dab1df029  add rsp, 0x30
0000785dab1df02d  vmovaps xmm0, [rsp]
0000785dab1df032  vmovaps xmm1, [rsp+0x10]
0000785dab1df038  vmovaps xmm2, [rsp+0x20]
0000785dab1df03e  vmovaps xmm3, [rsp+0x30]
0000785dab1df044  vmovaps xmm4, [rsp+0x40]
0000785dab1df04a  vmovaps xmm5, [rsp+0x50]
0000785dab1df050  vmovaps xmm6, [rsp+0x60]
0000785dab1df056  vmovaps xmm7, [rsp+0x70]
0000785dab1df05c  vmovaps xmm8, [rsp+0x80]
0000785dab1df065  vmovaps xmm10, [rsp+0x90]
0000785dab1df06e  vmovaps xmm11, [rsp+0xA0]
0000785dab1df077  vmovaps xmm12, [rsp+0xB0]
0000785dab1df080  vmovaps xmm13, [rsp+0xC0]
0000785dab1df089  vmovaps xmm14, [rsp+0xD0]
0000785dab1df092  vmovaps xmm15, [rsp+0xE0]
0000785dab1df09b  add rsp, 0xF0
0000785dab1df0a2  pop r11
0000785dab1df0a4  pop r10
0000785dab1df0a6  pop r9
0000785dab1df0a8  pop r8
0000785dab1df0aa  pop rsi
0000785dab1df0ab  pop rdi
0000785dab1df0ac  pop rdx
0000785dab1df0ad  pop rcx
0000785dab1df0ae  pop rax
0000785dab1df0af  add rsp, 0x08
0000785dab1df0b3  jmp 0x0000785DAB1DC354
0000785dab1df0b8  sub rsp, 0x08
0000785dab1df0bc  push rax
0000785dab1df0bd  push rcx
0000785dab1df0be  push rdx
0000785dab1df0bf  push rdi
0000785dab1df0c0  push rsi
0000785dab1df0c1  push r8
0000785dab1df0c3  push r9
0000785dab1df0c5  push r10
0000785dab1df0c7  push r11
0000785dab1df0c9  sub rsp, 0xF0
0000785dab1df0d0  vmovaps [rsp], xmm0
0000785dab1df0d5  vmovaps [rsp+0x10], xmm2
0000785dab1df0db  vmovaps [rsp+0x20], xmm3
0000785dab1df0e1  vmovaps [rsp+0x30], xmm4
0000785dab1df0e7  vmovaps [rsp+0x40], xmm5
0000785dab1df0ed  vmovaps [rsp+0x50], xmm6
0000785dab1df0f3  vmovaps [rsp+0x60], xmm7
0000785dab1df0f9  vmovaps [rsp+0x70], xmm8
0000785dab1df0ff  vmovaps [rsp+0x80], xmm9
0000785dab1df108  vmovaps [rsp+0x90], xmm10
0000785dab1df111  vmovaps [rsp+0xA0], xmm11
0000785dab1df11a  vmovaps [rsp+0xB0], xmm12
0000785dab1df123  vmovaps [rsp+0xC0], xmm13
0000785dab1df12c  vmovaps [rsp+0xD0], xmm14
0000785dab1df135  vmovaps [rsp+0xE0], xmm15
0000785dab1df13e  sub rsp, 0x30
0000785dab1df142  movaps [rsp], xmm1
0000785dab1df146  movaps [rsp+0x10], xmm15
0000785dab1df14c  movaps [rsp+0x20], xmm6
0000785dab1df151  lea rdi, [rsp]
0000785dab1df155  mov esi, 0x00
0000785dab1df15a  mov rax, 0x61B13BBD6530
0000785dab1df164  call rax
0000785dab1df166  movaps xmm1, [rsp]
0000785dab1df16a  add rsp, 0x30
0000785dab1df16e  vmovaps xmm0, [rsp]
0000785dab1df173  vmovaps xmm2, [rsp+0x10]
0000785dab1df179  vmovaps xmm3, [rsp+0x20]
0000785dab1df17f  vmovaps xmm4, [rsp+0x30]
0000785dab1df185  vmovaps xmm5, [rsp+0x40]
0000785dab1df18b  vmovaps xmm6, [rsp+0x50]
0000785dab1df191  vmovaps xmm7, [rsp+0x60]
0000785dab1df197  vmovaps xmm8, [rsp+0x70]
0000785dab1df19d  vmovaps xmm9, [rsp+0x80]
0000785dab1df1a6  vmovaps xmm10, [rsp+0x90]
0000785dab1df1af  vmovaps xmm11, [rsp+0xA0]
0000785dab1df1b8  vmovaps xmm12, [rsp+0xB0]
0000785dab1df1c1  vmovaps xmm13, [rsp+0xC0]
0000785dab1df1ca  vmovaps xmm14, [rsp+0xD0]
0000785dab1df1d3  vmovaps xmm15, [rsp+0xE0]
0000785dab1df1dc  add rsp, 0xF0
0000785dab1df1e3  pop r11
0000785dab1df1e5  pop r10
0000785dab1df1e7  pop r9
0000785dab1df1e9  pop r8
0000785dab1df1eb  pop rsi
0000785dab1df1ec  pop rdi
0000785dab1df1ed  pop rdx
0000785dab1df1ee  pop rcx
0000785dab1df1ef  pop rax
0000785dab1df1f0  add rsp, 0x08
0000785dab1df1f4  jmp 0x0000785DAB1DC375
0000785dab1df1f9  sub rsp, 0x08
0000785dab1df1fd  push rax
0000785dab1df1fe  push rcx
0000785dab1df1ff  push rdx
0000785dab1df200  push rdi
0000785dab1df201  push rsi
0000785dab1df202  push r8
0000785dab1df204  push r9
0000785dab1df206  push r10
0000785dab1df208  push r11
0000785dab1df20a  sub rsp, 0xF0
0000785dab1df211  vmovaps [rsp], xmm0
0000785dab1df216  vmovaps [rsp+0x10], xmm1
0000785dab1df21c  vmovaps [rsp+0x20], xmm2
0000785dab1df222  vmovaps [rsp+0x30], xmm3
0000785dab1df228  vmovaps [rsp+0x40], xmm4
0000785dab1df22e  vmovaps [rsp+0x50], xmm5
0000785dab1df234  vmovaps [rsp+0x60], xmm6
0000785dab1df23a  vmovaps [rsp+0x70], xmm7
0000785dab1df240  vmovaps [rsp+0x80], xmm8
0000785dab1df249  vmovaps [rsp+0x90], xmm9
0000785dab1df252  vmovaps [rsp+0xA0], xmm10
0000785dab1df25b  vmovaps [rsp+0xB0], xmm11
0000785dab1df264  vmovaps [rsp+0xC0], xmm12
0000785dab1df26d  vmovaps [rsp+0xD0], xmm13
0000785dab1df276  vmovaps [rsp+0xE0], xmm14
0000785dab1df27f  sub rsp, 0x30
0000785dab1df283  movaps [rsp], xmm15
0000785dab1df288  movaps [rsp+0x10], xmm5
0000785dab1df28d  movaps [rsp+0x20], xmm3
0000785dab1df292  lea rdi, [rsp]
0000785dab1df296  mov esi, 0x00
0000785dab1df29b  mov rax, 0x61B13BBD6530
0000785dab1df2a5  call rax
0000785dab1df2a7  movaps xmm15, [rsp]
0000785dab1df2ac  add rsp, 0x30
0000785dab1df2b0  vmovaps xmm0, [rsp]
0000785dab1df2b5  vmovaps xmm1, [rsp+0x10]
0000785dab1df2bb  vmovaps xmm2, [rsp+0x20]
0000785dab1df2c1  vmovaps xmm3, [rsp+0x30]
0000785dab1df2c7  vmovaps xmm4, [rsp+0x40]
0000785dab1df2cd  vmovaps xmm5, [rsp+0x50]
0000785dab1df2d3  vmovaps xmm6, [rsp+0x60]
0000785dab1df2d9  vmovaps xmm7, [rsp+0x70]
0000785dab1df2df  vmovaps xmm8, [rsp+0x80]
0000785dab1df2e8  vmovaps xmm9, [rsp+0x90]
0000785dab1df2f1  vmovaps xmm10, [rsp+0xA0]
0000785dab1df2fa  vmovaps xmm11, [rsp+0xB0]
0000785dab1df303  vmovaps xmm12, [rsp+0xC0]
0000785dab1df30c  vmovaps xmm13, [rsp+0xD0]
0000785dab1df315  vmovaps xmm14, [rsp+0xE0]
0000785dab1df31e  add rsp, 0xF0
0000785dab1df325  pop r11
0000785dab1df327  pop r10
0000785dab1df329  pop r9
0000785dab1df32b  pop r8
0000785dab1df32d  pop rsi
0000785dab1df32e  pop rdi
0000785dab1df32f  pop rdx
0000785dab1df330  pop rcx
0000785dab1df331  pop rax
0000785dab1df332  add rsp, 0x08
0000785dab1df336  jmp 0x0000785DAB1DC38F
0000785dab1df33b  sub rsp, 0x08
0000785dab1df33f  push rax
0000785dab1df340  push rcx
0000785dab1df341  push rdx
0000785dab1df342  push rdi
0000785dab1df343  push rsi
0000785dab1df344  push r8
0000785dab1df346  push r9
0000785dab1df348  push r10
0000785dab1df34a  push r11
0000785dab1df34c  sub rsp, 0xF0
0000785dab1df353  vmovaps [rsp], xmm0
0000785dab1df358  vmovaps [rsp+0x10], xmm1
0000785dab1df35e  vmovaps [rsp+0x20], xmm2
0000785dab1df364  vmovaps [rsp+0x30], xmm3
0000785dab1df36a  vmovaps [rsp+0x40], xmm4
0000785dab1df370  vmovaps [rsp+0x50], xmm6
0000785dab1df376  vmovaps [rsp+0x60], xmm7
0000785dab1df37c  vmovaps [rsp+0x70], xmm8
0000785dab1df382  vmovaps [rsp+0x80], xmm9
0000785dab1df38b  vmovaps [rsp+0x90], xmm10
0000785dab1df394  vmovaps [rsp+0xA0], xmm11
0000785dab1df39d  vmovaps [rsp+0xB0], xmm12
0000785dab1df3a6  vmovaps [rsp+0xC0], xmm13
0000785dab1df3af  vmovaps [rsp+0xD0], xmm14
0000785dab1df3b8  vmovaps [rsp+0xE0], xmm15
0000785dab1df3c1  sub rsp, 0x30
0000785dab1df3c5  movaps [rsp], xmm5
0000785dab1df3c9  movaps [rsp+0x10], xmm8
0000785dab1df3cf  movaps [rsp+0x20], xmm6
0000785dab1df3d4  lea rdi, [rsp]
0000785dab1df3d8  mov esi, 0x00
0000785dab1df3dd  mov rax, 0x61B13BBD6530
0000785dab1df3e7  call rax
0000785dab1df3e9  movaps xmm5, [rsp]
0000785dab1df3ed  add rsp, 0x30
0000785dab1df3f1  vmovaps xmm0, [rsp]
0000785dab1df3f6  vmovaps xmm1, [rsp+0x10]
0000785dab1df3fc  vmovaps xmm2, [rsp+0x20]
0000785dab1df402  vmovaps xmm3, [rsp+0x30]
0000785dab1df408  vmovaps xmm4, [rsp+0x40]
0000785dab1df40e  vmovaps xmm6, [rsp+0x50]
0000785dab1df414  vmovaps xmm7, [rsp+0x60]
0000785dab1df41a  vmovaps xmm8, [rsp+0x70]
0000785dab1df420  vmovaps xmm9, [rsp+0x80]
0000785dab1df429  vmovaps xmm10, [rsp+0x90]
0000785dab1df432  vmovaps xmm11, [rsp+0xA0]
0000785dab1df43b  vmovaps xmm12, [rsp+0xB0]
0000785dab1df444  vmovaps xmm13, [rsp+0xC0]
0000785dab1df44d  vmovaps xmm14, [rsp+0xD0]
0000785dab1df456  vmovaps xmm15, [rsp+0xE0]
0000785dab1df45f  add rsp, 0xF0
0000785dab1df466  pop r11
0000785dab1df468  pop r10
0000785dab1df46a  pop r9
0000785dab1df46c  pop r8
0000785dab1df46e  pop rsi
0000785dab1df46f  pop rdi
0000785dab1df470  pop rdx
0000785dab1df471  pop rcx
0000785dab1df472  pop rax
0000785dab1df473  add rsp, 0x08
0000785dab1df477  jmp 0x0000785DAB1DC3B3
0000785dab1df47c  sub rsp, 0x08
0000785dab1df480  push rax
0000785dab1df481  push rcx
0000785dab1df482  push rdx
0000785dab1df483  push rdi
0000785dab1df484  push rsi
0000785dab1df485  push r8
0000785dab1df487  push r9
0000785dab1df489  push r10
0000785dab1df48b  push r11
0000785dab1df48d  sub rsp, 0xF0
0000785dab1df494  vmovaps [rsp], xmm0
0000785dab1df499  vmovaps [rsp+0x10], xmm1
0000785dab1df49f  vmovaps [rsp+0x20], xmm2
0000785dab1df4a5  vmovaps [rsp+0x30], xmm3
0000785dab1df4ab  vmovaps [rsp+0x40], xmm4
0000785dab1df4b1  vmovaps [rsp+0x50], xmm5
0000785dab1df4b7  vmovaps [rsp+0x60], xmm7
0000785dab1df4bd  vmovaps [rsp+0x70], xmm8
0000785dab1df4c3  vmovaps [rsp+0x80], xmm9
0000785dab1df4cc  vmovaps [rsp+0x90], xmm10
0000785dab1df4d5  vmovaps [rsp+0xA0], xmm11
0000785dab1df4de  vmovaps [rsp+0xB0], xmm12
0000785dab1df4e7  vmovaps [rsp+0xC0], xmm13
0000785dab1df4f0  vmovaps [rsp+0xD0], xmm14
0000785dab1df4f9  vmovaps [rsp+0xE0], xmm15
0000785dab1df502  sub rsp, 0x30
0000785dab1df506  movaps [rsp], xmm6
0000785dab1df50a  movaps [rsp+0x10], xmm10
0000785dab1df510  movaps [rsp+0x20], xmm8
0000785dab1df516  lea rdi, [rsp]
0000785dab1df51a  mov esi, 0x00
0000785dab1df51f  mov rax, 0x61B13BBD6530
0000785dab1df529  call rax
0000785dab1df52b  movaps xmm6, [rsp]
0000785dab1df52f  add rsp, 0x30
0000785dab1df533  vmovaps xmm0, [rsp]
0000785dab1df538  vmovaps xmm1, [rsp+0x10]
0000785dab1df53e  vmovaps xmm2, [rsp+0x20]
0000785dab1df544  vmovaps xmm3, [rsp+0x30]
0000785dab1df54a  vmovaps xmm4, [rsp+0x40]
0000785dab1df550  vmovaps xmm5, [rsp+0x50]
0000785dab1df556  vmovaps xmm7, [rsp+0x60]
0000785dab1df55c  vmovaps xmm8, [rsp+0x70]
0000785dab1df562  vmovaps xmm9, [rsp+0x80]
0000785dab1df56b  vmovaps xmm10, [rsp+0x90]
0000785dab1df574  vmovaps xmm11, [rsp+0xA0]
0000785dab1df57d  vmovaps xmm12, [rsp+0xB0]
0000785dab1df586  vmovaps xmm13, [rsp+0xC0]
0000785dab1df58f  vmovaps xmm14, [rsp+0xD0]
0000785dab1df598  vmovaps xmm15, [rsp+0xE0]
0000785dab1df5a1  add rsp, 0xF0
0000785dab1df5a8  pop r11
0000785dab1df5aa  pop r10
0000785dab1df5ac  pop r9
0000785dab1df5ae  pop r8
0000785dab1df5b0  pop rsi
0000785dab1df5b1  pop rdi
0000785dab1df5b2  pop rdx
0000785dab1df5b3  pop rcx
0000785dab1df5b4  pop rax
0000785dab1df5b5  add rsp, 0x08
0000785dab1df5b9  jmp 0x0000785DAB1DC3D8
0000785dab1df5be  sub rsp, 0x08
0000785dab1df5c2  push rax
0000785dab1df5c3  push rcx
0000785dab1df5c4  push rdx
0000785dab1df5c5  push rdi
0000785dab1df5c6  push rsi
0000785dab1df5c7  push r8
0000785dab1df5c9  push r9
0000785dab1df5cb  push r10
0000785dab1df5cd  push r11
0000785dab1df5cf  sub rsp, 0xF0
0000785dab1df5d6  vmovaps [rsp], xmm0
0000785dab1df5db  vmovaps [rsp+0x10], xmm1
0000785dab1df5e1  vmovaps [rsp+0x20], xmm2
0000785dab1df5e7  vmovaps [rsp+0x30], xmm3
0000785dab1df5ed  vmovaps [rsp+0x40], xmm4
0000785dab1df5f3  vmovaps [rsp+0x50], xmm5
0000785dab1df5f9  vmovaps [rsp+0x60], xmm6
0000785dab1df5ff  vmovaps [rsp+0x70], xmm7
0000785dab1df605  vmovaps [rsp+0x80], xmm8
0000785dab1df60e  vmovaps [rsp+0x90], xmm9
0000785dab1df617  vmovaps [rsp+0xA0], xmm11
0000785dab1df620  vmovaps [rsp+0xB0], xmm12
0000785dab1df629  vmovaps [rsp+0xC0], xmm13
0000785dab1df632  vmovaps [rsp+0xD0], xmm14
0000785dab1df63b  vmovaps [rsp+0xE0], xmm15
0000785dab1df644  sub rsp, 0x30
0000785dab1df648  movaps [rsp], xmm10
0000785dab1df64d  movaps [rsp+0x10], xmm8
0000785dab1df653  movaps [rsp+0x20], xmm14
0000785dab1df659  lea rdi, [rsp]
0000785dab1df65d  mov esi, 0x00
0000785dab1df662  mov rax, 0x61B13BBD6530
0000785dab1df66c  call rax
0000785dab1df66e  movaps xmm10, [rsp]
0000785dab1df673  add rsp, 0x30
0000785dab1df677  vmovaps xmm0, [rsp]
0000785dab1df67c  vmovaps xmm1, [rsp+0x10]
0000785dab1df682  vmovaps xmm2, [rsp+0x20]
0000785dab1df688  vmovaps xmm3, [rsp+0x30]
0000785dab1df68e  vmovaps xmm4, [rsp+0x40]
0000785dab1df694  vmovaps xmm5, [rsp+0x50]
0000785dab1df69a  vmovaps xmm6, [rsp+0x60]
0000785dab1df6a0  vmovaps xmm7, [rsp+0x70]
0000785dab1df6a6  vmovaps xmm8, [rsp+0x80]
0000785dab1df6af  vmovaps xmm9, [rsp+0x90]
0000785dab1df6b8  vmovaps xmm11, [rsp+0xA0]
0000785dab1df6c1  vmovaps xmm12, [rsp+0xB0]
0000785dab1df6ca  vmovaps xmm13, [rsp+0xC0]
0000785dab1df6d3  vmovaps xmm14, [rsp+0xD0]
0000785dab1df6dc  vmovaps xmm15, [rsp+0xE0]
0000785dab1df6e5  add rsp, 0xF0
0000785dab1df6ec  pop r11
0000785dab1df6ee  pop r10
0000785dab1df6f0  pop r9
0000785dab1df6f2  pop r8
0000785dab1df6f4  pop rsi
0000785dab1df6f5  pop rdi
0000785dab1df6f6  pop rdx
0000785dab1df6f7  pop rcx
0000785dab1df6f8  pop rax
0000785dab1df6f9  add rsp, 0x08
0000785dab1df6fd  jmp 0x0000785DAB1DC3F8
0000785dab1df702  sub rsp, 0x08
0000785dab1df706  push rax
0000785dab1df707  push rcx
0000785dab1df708  push rdx
0000785dab1df709  push rdi
0000785dab1df70a  push rsi
0000785dab1df70b  push r8
0000785dab1df70d  push r9
0000785dab1df70f  push r10
0000785dab1df711  push r11
0000785dab1df713  sub rsp, 0xF0
0000785dab1df71a  vmovaps [rsp], xmm0
0000785dab1df71f  vmovaps [rsp+0x10], xmm1
0000785dab1df725  vmovaps [rsp+0x20], xmm2
0000785dab1df72b  vmovaps [rsp+0x30], xmm3
0000785dab1df731  vmovaps [rsp+0x40], xmm4
0000785dab1df737  vmovaps [rsp+0x50], xmm5
0000785dab1df73d  vmovaps [rsp+0x60], xmm6
0000785dab1df743  vmovaps [rsp+0x70], xmm7
0000785dab1df749  vmovaps [rsp+0x80], xmm8
0000785dab1df752  vmovaps [rsp+0x90], xmm9
0000785dab1df75b  vmovaps [rsp+0xA0], xmm10
0000785dab1df764  vmovaps [rsp+0xB0], xmm11
0000785dab1df76d  vmovaps [rsp+0xC0], xmm12
0000785dab1df776  vmovaps [rsp+0xD0], xmm13
0000785dab1df77f  vmovaps [rsp+0xE0], xmm15
0000785dab1df788  sub rsp, 0x30
0000785dab1df78c  movaps [rsp], xmm14
0000785dab1df791  movaps [rsp+0x10], xmm8
0000785dab1df797  movaps [rsp+0x20], xmm4
0000785dab1df79c  lea rdi, [rsp]
0000785dab1df7a0  mov esi, 0x00
0000785dab1df7a5  mov rax, 0x61B13BBD6530
0000785dab1df7af  call rax
0000785dab1df7b1  movaps xmm14, [rsp]
0000785dab1df7b6  add rsp, 0x30
0000785dab1df7ba  vmovaps xmm0, [rsp]
0000785dab1df7bf  vmovaps xmm1, [rsp+0x10]
0000785dab1df7c5  vmovaps xmm2, [rsp+0x20]
0000785dab1df7cb  vmovaps xmm3, [rsp+0x30]
0000785dab1df7d1  vmovaps xmm4, [rsp+0x40]
0000785dab1df7d7  vmovaps xmm5, [rsp+0x50]
0000785dab1df7dd  vmovaps xmm6, [rsp+0x60]
0000785dab1df7e3  vmovaps xmm7, [rsp+0x70]
0000785dab1df7e9  vmovaps xmm8, [rsp+0x80]
0000785dab1df7f2  vmovaps xmm9, [rsp+0x90]
0000785dab1df7fb  vmovaps xmm10, [rsp+0xA0]
0000785dab1df804  vmovaps xmm11, [rsp+0xB0]
0000785dab1df80d  vmovaps xmm12, [rsp+0xC0]
0000785dab1df816  vmovaps xmm13, [rsp+0xD0]
0000785dab1df81f  vmovaps xmm15, [rsp+0xE0]
0000785dab1df828  add rsp, 0xF0
0000785dab1df82f  pop r11
0000785dab1df831  pop r10
0000785dab1df833  pop r9
0000785dab1df835  pop r8
0000785dab1df837  pop rsi
0000785dab1df838  pop rdi
0000785dab1df839  pop rdx
0000785dab1df83a  pop rcx
0000785dab1df83b  pop rax
0000785dab1df83c  add rsp, 0x08
0000785dab1df840  jmp 0x0000785DAB1DC418
0000785dab1df845  sub rsp, 0x08
0000785dab1df849  push rax
0000785dab1df84a  push rcx
0000785dab1df84b  push rdx
0000785dab1df84c  push rdi
0000785dab1df84d  push rsi
0000785dab1df84e  push r8
0000785dab1df850  push r9
0000785dab1df852  push r10
0000785dab1df854  push r11
0000785dab1df856  sub rsp, 0xF0
0000785dab1df85d  vmovaps [rsp], xmm0
0000785dab1df862  vmovaps [rsp+0x10], xmm1
0000785dab1df868  vmovaps [rsp+0x20], xmm2
0000785dab1df86e  vmovaps [rsp+0x30], xmm3
0000785dab1df874  vmovaps [rsp+0x40], xmm5
0000785dab1df87a  vmovaps [rsp+0x50], xmm6
0000785dab1df880  vmovaps [rsp+0x60], xmm7
0000785dab1df886  vmovaps [rsp+0x70], xmm8
0000785dab1df88c  vmovaps [rsp+0x80], xmm9
0000785dab1df895  vmovaps [rsp+0x90], xmm10
0000785dab1df89e  vmovaps [rsp+0xA0], xmm11
0000785dab1df8a7  vmovaps [rsp+0xB0], xmm12
0000785dab1df8b0  vmovaps [rsp+0xC0], xmm13
0000785dab1df8b9  vmovaps [rsp+0xD0], xmm14
0000785dab1df8c2  vmovaps [rsp+0xE0], xmm15
0000785dab1df8cb  sub rsp, 0x30
0000785dab1df8cf  movaps [rsp], xmm4
0000785dab1df8d3  movaps [rsp+0x10], xmm13
0000785dab1df8d9  movaps [rsp+0x20], xmm8
0000785dab1df8df  lea rdi, [rsp]
0000785dab1df8e3  mov esi, 0x00
0000785dab1df8e8  mov rax, 0x61B13BBD6530
0000785dab1df8f2  call rax
0000785dab1df8f4  movaps xmm4, [rsp]
0000785dab1df8f8  add rsp, 0x30
0000785dab1df8fc  vmovaps xmm0, [rsp]
0000785dab1df901  vmovaps xmm1, [rsp+0x10]
0000785dab1df907  vmovaps xmm2, [rsp+0x20]
0000785dab1df90d  vmovaps xmm3, [rsp+0x30]
0000785dab1df913  vmovaps xmm5, [rsp+0x40]
0000785dab1df919  vmovaps xmm6, [rsp+0x50]
0000785dab1df91f  vmovaps xmm7, [rsp+0x60]
0000785dab1df925  vmovaps xmm8, [rsp+0x70]
0000785dab1df92b  vmovaps xmm9, [rsp+0x80]
0000785dab1df934  vmovaps xmm10, [rsp+0x90]
0000785dab1df93d  vmovaps xmm11, [rsp+0xA0]
0000785dab1df946  vmovaps xmm12, [rsp+0xB0]
0000785dab1df94f  vmovaps xmm13, [rsp+0xC0]
0000785dab1df958  vmovaps xmm14, [rsp+0xD0]
0000785dab1df961  vmovaps xmm15, [rsp+0xE0]
0000785dab1df96a  add rsp, 0xF0
0000785dab1df971  pop r11
0000785dab1df973  pop r10
0000785dab1df975  pop r9
0000785dab1df977  pop r8
0000785dab1df979  pop rsi
0000785dab1df97a  pop rdi
0000785dab1df97b  pop rdx
0000785dab1df97c  pop rcx
0000785dab1df97d  pop rax
0000785dab1df97e  add rsp, 0x08
0000785dab1df982  jmp 0x0000785DAB1DC43D
0000785dab1df987  sub rsp, 0x08
0000785dab1df98b  push rax
0000785dab1df98c  push rcx
0000785dab1df98d  push rdx
0000785dab1df98e  push rdi
0000785dab1df98f  push rsi
0000785dab1df990  push r8
0000785dab1df992  push r9
0000785dab1df994  push r10
0000785dab1df996  push r11
0000785dab1df998  sub rsp, 0xF0
0000785dab1df99f  vmovaps [rsp], xmm0
0000785dab1df9a4  vmovaps [rsp+0x10], xmm1
0000785dab1df9aa  vmovaps [rsp+0x20], xmm2
0000785dab1df9b0  vmovaps [rsp+0x30], xmm3
0000785dab1df9b6  vmovaps [rsp+0x40], xmm4
0000785dab1df9bc  vmovaps [rsp+0x50], xmm5
0000785dab1df9c2  vmovaps [rsp+0x60], xmm6
0000785dab1df9c8  vmovaps [rsp+0x70], xmm7
0000785dab1df9ce  vmovaps [rsp+0x80], xmm8
0000785dab1df9d7  vmovaps [rsp+0x90], xmm9
0000785dab1df9e0  vmovaps [rsp+0xA0], xmm10
0000785dab1df9e9  vmovaps [rsp+0xB0], xmm11
0000785dab1df9f2  vmovaps [rsp+0xC0], xmm12
0000785dab1df9fb  vmovaps [rsp+0xD0], xmm14
0000785dab1dfa04  vmovaps [rsp+0xE0], xmm15
0000785dab1dfa0d  sub rsp, 0x30
0000785dab1dfa11  movaps [rsp], xmm13
0000785dab1dfa16  movaps [rsp+0x10], xmm15
0000785dab1dfa1c  movaps [rsp+0x20], xmm9
0000785dab1dfa22  lea rdi, [rsp]
0000785dab1dfa26  mov esi, 0x00
0000785dab1dfa2b  mov rax, 0x61B13BBD6530
0000785dab1dfa35  call rax
0000785dab1dfa37  movaps xmm13, [rsp]
0000785dab1dfa3c  add rsp, 0x30
0000785dab1dfa40  vmovaps xmm0, [rsp]
0000785dab1dfa45  vmovaps xmm1, [rsp+0x10]
0000785dab1dfa4b  vmovaps xmm2, [rsp+0x20]
0000785dab1dfa51  vmovaps xmm3, [rsp+0x30]
0000785dab1dfa57  vmovaps xmm4, [rsp+0x40]
0000785dab1dfa5d  vmovaps xmm5, [rsp+0x50]
0000785dab1dfa63  vmovaps xmm6, [rsp+0x60]
0000785dab1dfa69  vmovaps xmm7, [rsp+0x70]
0000785dab1dfa6f  vmovaps xmm8, [rsp+0x80]
0000785dab1dfa78  vmovaps xmm9, [rsp+0x90]
0000785dab1dfa81  vmovaps xmm10, [rsp+0xA0]
0000785dab1dfa8a  vmovaps xmm11, [rsp+0xB0]
0000785dab1dfa93  vmovaps xmm12, [rsp+0xC0]
0000785dab1dfa9c  vmovaps xmm14, [rsp+0xD0]
0000785dab1dfaa5  vmovaps xmm15, [rsp+0xE0]
0000785dab1dfaae  add rsp, 0xF0
0000785dab1dfab5  pop r11
0000785dab1dfab7  pop r10
0000785dab1dfab9  pop r9
0000785dab1dfabb  pop r8
0000785dab1dfabd  pop rsi
0000785dab1dfabe  pop rdi
0000785dab1dfabf  pop rdx
0000785dab1dfac0  pop rcx
0000785dab1dfac1  pop rax
0000785dab1dfac2  add rsp, 0x08
0000785dab1dfac6  jmp 0x0000785DAB1DC458
0000785dab1dfacb  sub rsp, 0x08
0000785dab1dfacf  push rax
0000785dab1dfad0  push rcx
0000785dab1dfad1  push rdx
0000785dab1dfad2  push rdi
0000785dab1dfad3  push rsi
0000785dab1dfad4  push r8
0000785dab1dfad6  push r9
0000785dab1dfad8  push r10
0000785dab1dfada  push r11
0000785dab1dfadc  sub rsp, 0xF0
0000785dab1dfae3  vmovaps [rsp], xmm0
0000785dab1dfae8  vmovaps [rsp+0x10], xmm1
0000785dab1dfaee  vmovaps [rsp+0x20], xmm2
0000785dab1dfaf4  vmovaps [rsp+0x30], xmm3
0000785dab1dfafa  vmovaps [rsp+0x40], xmm4
0000785dab1dfb00  vmovaps [rsp+0x50], xmm5
0000785dab1dfb06  vmovaps [rsp+0x60], xmm6
0000785dab1dfb0c  vmovaps [rsp+0x70], xmm7
0000785dab1dfb12  vmovaps [rsp+0x80], xmm8
0000785dab1dfb1b  vmovaps [rsp+0x90], xmm9
0000785dab1dfb24  vmovaps [rsp+0xA0], xmm10
0000785dab1dfb2d  vmovaps [rsp+0xB0], xmm11
0000785dab1dfb36  vmovaps [rsp+0xC0], xmm12
0000785dab1dfb3f  vmovaps [rsp+0xD0], xmm13
0000785dab1dfb48  vmovaps [rsp+0xE0], xmm14
0000785dab1dfb51  sub rsp, 0x30
0000785dab1dfb55  movaps [rsp], xmm15
0000785dab1dfb5a  movaps [rsp+0x10], xmm1
0000785dab1dfb5f  movaps [rsp+0x20], xmm5
0000785dab1dfb64  lea rdi, [rsp]
0000785dab1dfb68  mov esi, 0x00
0000785dab1dfb6d  mov rax, 0x61B13BBD6530
0000785dab1dfb77  call rax
0000785dab1dfb79  movaps xmm15, [rsp]
0000785dab1dfb7e  add rsp, 0x30
0000785dab1dfb82  vmovaps xmm0, [rsp]
0000785dab1dfb87  vmovaps xmm1, [rsp+0x10]
0000785dab1dfb8d  vmovaps xmm2, [rsp+0x20]
0000785dab1dfb93  vmovaps xmm3, [rsp+0x30]
0000785dab1dfb99  vmovaps xmm4, [rsp+0x40]
0000785dab1dfb9f  vmovaps xmm5, [rsp+0x50]
0000785dab1dfba5  vmovaps xmm6, [rsp+0x60]
0000785dab1dfbab  vmovaps xmm7, [rsp+0x70]
0000785dab1dfbb1  vmovaps xmm8, [rsp+0x80]
0000785dab1dfbba  vmovaps xmm9, [rsp+0x90]
0000785dab1dfbc3  vmovaps xmm10, [rsp+0xA0]
0000785dab1dfbcc  vmovaps xmm11, [rsp+0xB0]
0000785dab1dfbd5  vmovaps xmm12, [rsp+0xC0]
0000785dab1dfbde  vmovaps xmm13, [rsp+0xD0]
0000785dab1dfbe7  vmovaps xmm14, [rsp+0xE0]
0000785dab1dfbf0  add rsp, 0xF0
0000785dab1dfbf7  pop r11
0000785dab1dfbf9  pop r10
0000785dab1dfbfb  pop r9
0000785dab1dfbfd  pop r8
0000785dab1dfbff  pop rsi
0000785dab1dfc00  pop rdi
0000785dab1dfc01  pop rdx
0000785dab1dfc02  pop rcx
0000785dab1dfc03  pop rax
0000785dab1dfc04  add rsp, 0x08
0000785dab1dfc08  jmp 0x0000785DAB1DC473
0000785dab1dfc0d  call 0x0000785DAB0B52F0
0000785dab1dfc12  jmp 0x0000785DAB1DC4CE
0000785dab1dfc17  sub rsp, 0x08
0000785dab1dfc1b  push rax
0000785dab1dfc1c  push rcx
0000785dab1dfc1d  push rdx
0000785dab1dfc1e  push rdi
0000785dab1dfc1f  push rsi
0000785dab1dfc20  push r8
0000785dab1dfc22  push r9
0000785dab1dfc24  push r10
0000785dab1dfc26  push r11
0000785dab1dfc28  sub rsp, 0xF0
0000785dab1dfc2f  vmovaps [rsp], xmm0
0000785dab1dfc34  vmovaps [rsp+0x10], xmm1
0000785dab1dfc3a  vmovaps [rsp+0x20], xmm2
0000785dab1dfc40  vmovaps [rsp+0x30], xmm3
0000785dab1dfc46  vmovaps [rsp+0x40], xmm4
0000785dab1dfc4c  vmovaps [rsp+0x50], xmm5
0000785dab1dfc52  vmovaps [rsp+0x60], xmm6
0000785dab1dfc58  vmovaps [rsp+0x70], xmm7
0000785dab1dfc5e  vmovaps [rsp+0x80], xmm8
0000785dab1dfc67  vmovaps [rsp+0x90], xmm10
0000785dab1dfc70  vmovaps [rsp+0xA0], xmm11
0000785dab1dfc79  vmovaps [rsp+0xB0], xmm12
0000785dab1dfc82  vmovaps [rsp+0xC0], xmm13
0000785dab1dfc8b  vmovaps [rsp+0xD0], xmm14
0000785dab1dfc94  vmovaps [rsp+0xE0], xmm15
0000785dab1dfc9d  sub rsp, 0x30
0000785dab1dfca1  movaps [rsp], xmm9
0000785dab1dfca6  movaps [rsp+0x10], xmm8
0000785dab1dfcac  movaps [rsp+0x20], xmm11
0000785dab1dfcb2  lea rdi, [rsp]
0000785dab1dfcb6  mov esi, 0x00
0000785dab1dfcbb  mov rax, 0x61B13BBD6530
0000785dab1dfcc5  call rax
0000785dab1dfcc7  movaps xmm9, [rsp]
0000785dab1dfccc  add rsp, 0x30
0000785dab1dfcd0  vmovaps xmm0, [rsp]
0000785dab1dfcd5  vmovaps xmm1, [rsp+0x10]
0000785dab1dfcdb  vmovaps xmm2, [rsp+0x20]
0000785dab1dfce1  vmovaps xmm3, [rsp+0x30]
0000785dab1dfce7  vmovaps xmm4, [rsp+0x40]
0000785dab1dfced  vmovaps xmm5, [rsp+0x50]
0000785dab1dfcf3  vmovaps xmm6, [rsp+0x60]
0000785dab1dfcf9  vmovaps xmm7, [rsp+0x70]
0000785dab1dfcff  vmovaps xmm8, [rsp+0x80]
0000785dab1dfd08  vmovaps xmm10, [rsp+0x90]
0000785dab1dfd11  vmovaps xmm11, [rsp+0xA0]
0000785dab1dfd1a  vmovaps xmm12, [rsp+0xB0]
0000785dab1dfd23  vmovaps xmm13, [rsp+0xC0]
0000785dab1dfd2c  vmovaps xmm14, [rsp+0xD0]
0000785dab1dfd35  vmovaps xmm15, [rsp+0xE0]
0000785dab1dfd3e  add rsp, 0xF0
0000785dab1dfd45  pop r11
0000785dab1dfd47  pop r10
0000785dab1dfd49  pop r9
0000785dab1dfd4b  pop r8
0000785dab1dfd4d  pop rsi
0000785dab1dfd4e  pop rdi
0000785dab1dfd4f  pop rdx
0000785dab1dfd50  pop rcx
0000785dab1dfd51  pop rax
0000785dab1dfd52  add rsp, 0x08
0000785dab1dfd56  jmp 0x0000785DAB1DC505
0000785dab1dfd5b  sub rsp, 0x08
0000785dab1dfd5f  push rax
0000785dab1dfd60  push rcx
0000785dab1dfd61  push rdx
0000785dab1dfd62  push rdi
0000785dab1dfd63  push rsi
0000785dab1dfd64  push r8
0000785dab1dfd66  push r9
0000785dab1dfd68  push r10
0000785dab1dfd6a  push r11
0000785dab1dfd6c  sub rsp, 0xF0
0000785dab1dfd73  vmovaps [rsp], xmm0
0000785dab1dfd78  vmovaps [rsp+0x10], xmm1
0000785dab1dfd7e  vmovaps [rsp+0x20], xmm2
0000785dab1dfd84  vmovaps [rsp+0x30], xmm3
0000785dab1dfd8a  vmovaps [rsp+0x40], xmm4
0000785dab1dfd90  vmovaps [rsp+0x50], xmm5
0000785dab1dfd96  vmovaps [rsp+0x60], xmm6
0000785dab1dfd9c  vmovaps [rsp+0x70], xmm7
0000785dab1dfda2  vmovaps [rsp+0x80], xmm8
0000785dab1dfdab  vmovaps [rsp+0x90], xmm9
0000785dab1dfdb4  vmovaps [rsp+0xA0], xmm10
0000785dab1dfdbd  vmovaps [rsp+0xB0], xmm12
0000785dab1dfdc6  vmovaps [rsp+0xC0], xmm13
0000785dab1dfdcf  vmovaps [rsp+0xD0], xmm14
0000785dab1dfdd8  vmovaps [rsp+0xE0], xmm15
0000785dab1dfde1  sub rsp, 0x30
0000785dab1dfde5  movaps [rsp], xmm11
0000785dab1dfdea  movaps [rsp+0x10], xmm10
0000785dab1dfdf0  movaps [rsp+0x20], xmm6
0000785dab1dfdf5  lea rdi, [rsp]
0000785dab1dfdf9  mov esi, 0x00
0000785dab1dfdfe  mov rax, 0x61B13BBD6530
0000785dab1dfe08  call rax
0000785dab1dfe0a  movaps xmm11, [rsp]
0000785dab1dfe0f  add rsp, 0x30
0000785dab1dfe13  vmovaps xmm0, [rsp]
0000785dab1dfe18  vmovaps xmm1, [rsp+0x10]
0000785dab1dfe1e  vmovaps xmm2, [rsp+0x20]
0000785dab1dfe24  vmovaps xmm3, [rsp+0x30]
0000785dab1dfe2a  vmovaps xmm4, [rsp+0x40]
0000785dab1dfe30  vmovaps xmm5, [rsp+0x50]
0000785dab1dfe36  vmovaps xmm6, [rsp+0x60]
0000785dab1dfe3c  vmovaps xmm7, [rsp+0x70]
0000785dab1dfe42  vmovaps xmm8, [rsp+0x80]
0000785dab1dfe4b  vmovaps xmm9, [rsp+0x90]
0000785dab1dfe54  vmovaps xmm10, [rsp+0xA0]
0000785dab1dfe5d  vmovaps xmm12, [rsp+0xB0]
0000785dab1dfe66  vmovaps xmm13, [rsp+0xC0]
0000785dab1dfe6f  vmovaps xmm14, [rsp+0xD0]
0000785dab1dfe78  vmovaps xmm15, [rsp+0xE0]
0000785dab1dfe81  add rsp, 0xF0
0000785dab1dfe88  pop r11
0000785dab1dfe8a  pop r10
0000785dab1dfe8c  pop r9
0000785dab1dfe8e  pop r8
0000785dab1dfe90  pop rsi
0000785dab1dfe91  pop rdi
0000785dab1dfe92  pop rdx
0000785dab1dfe93  pop rcx
0000785dab1dfe94  pop rax
0000785dab1dfe95  add rsp, 0x08
0000785dab1dfe99  jmp 0x0000785DAB1DC520
0000785dab1dfe9e  sub rsp, 0x08
0000785dab1dfea2  push rax
0000785dab1dfea3  push rcx
0000785dab1dfea4  push rdx
0000785dab1dfea5  push rdi
0000785dab1dfea6  push rsi
0000785dab1dfea7  push r8
0000785dab1dfea9  push r9
0000785dab1dfeab  push r10
0000785dab1dfead  push r11
0000785dab1dfeaf  sub rsp, 0xF0
0000785dab1dfeb6  vmovaps [rsp], xmm0
0000785dab1dfebb  vmovaps [rsp+0x10], xmm1
0000785dab1dfec1  vmovaps [rsp+0x20], xmm2
0000785dab1dfec7  vmovaps [rsp+0x30], xmm3
0000785dab1dfecd  vmovaps [rsp+0x40], xmm4
0000785dab1dfed3  vmovaps [rsp+0x50], xmm5
0000785dab1dfed9  vmovaps [rsp+0x60], xmm6
0000785dab1dfedf  vmovaps [rsp+0x70], xmm7
0000785dab1dfee5  vmovaps [rsp+0x80], xmm8
0000785dab1dfeee  vmovaps [rsp+0x90], xmm9
0000785dab1dfef7  vmovaps [rsp+0xA0], xmm11
0000785dab1dff00  vmovaps [rsp+0xB0], xmm12
0000785dab1dff09  vmovaps [rsp+0xC0], xmm13
0000785dab1dff12  vmovaps [rsp+0xD0], xmm14
0000785dab1dff1b  vmovaps [rsp+0xE0], xmm15
0000785dab1dff24  sub rsp, 0x30
0000785dab1dff28  movaps [rsp], xmm10
0000785dab1dff2d  movaps [rsp+0x10], xmm14
0000785dab1dff33  movaps [rsp+0x20], xmm4
0000785dab1dff38  lea rdi, [rsp]
0000785dab1dff3c  mov esi, 0x00
0000785dab1dff41  mov rax, 0x61B13BBD6530
0000785dab1dff4b  call rax
0000785dab1dff4d  movaps xmm10, [rsp]
0000785dab1dff52  add rsp, 0x30
0000785dab1dff56  vmovaps xmm0, [rsp]
0000785dab1dff5b  vmovaps xmm1, [rsp+0x10]
0000785dab1dff61  vmovaps xmm2, [rsp+0x20]
0000785dab1dff67  vmovaps xmm3, [rsp+0x30]
0000785dab1dff6d  vmovaps xmm4, [rsp+0x40]
0000785dab1dff73  vmovaps xmm5, [rsp+0x50]
0000785dab1dff79  vmovaps xmm6, [rsp+0x60]
0000785dab1dff7f  vmovaps xmm7, [rsp+0x70]
0000785dab1dff85  vmovaps xmm8, [rsp+0x80]
0000785dab1dff8e  vmovaps xmm9, [rsp+0x90]
0000785dab1dff97  vmovaps xmm11, [rsp+0xA0]
0000785dab1dffa0  vmovaps xmm12, [rsp+0xB0]
0000785dab1dffa9  vmovaps xmm13, [rsp+0xC0]
0000785dab1dffb2  vmovaps xmm14, [rsp+0xD0]
0000785dab1dffbb  vmovaps xmm15, [rsp+0xE0]
0000785dab1dffc4  add rsp, 0xF0
0000785dab1dffcb  pop r11
0000785dab1dffcd  pop r10
0000785dab1dffcf  pop r9
0000785dab1dffd1  pop r8
0000785dab1dffd3  pop rsi
0000785dab1dffd4  pop rdi
0000785dab1dffd5  pop rdx
0000785dab1dffd6  pop rcx
0000785dab1dffd7  pop rax
0000785dab1dffd8  add rsp, 0x08
0000785dab1dffdc  jmp 0x0000785DAB1DC53B
0000785dab1dffe1  sub rsp, 0x08
0000785dab1dffe5  push rax
0000785dab1dffe6  push rcx
0000785dab1dffe7  push rdx
0000785dab1dffe8  push rdi
0000785dab1dffe9  push rsi
0000785dab1dffea  push r8
0000785dab1dffec  push r9
0000785dab1dffee  push r10
0000785dab1dfff0  push r11
0000785dab1dfff2  sub rsp, 0xF0
0000785dab1dfff9  vmovaps [rsp], xmm0
0000785dab1dfffe  vmovaps [rsp+0x10], xmm1
0000785dab1e0004  vmovaps [rsp+0x20], xmm2
0000785dab1e000a  vmovaps [rsp+0x30], xmm3
0000785dab1e0010  vmovaps [rsp+0x40], xmm4
0000785dab1e0016  vmovaps [rsp+0x50], xmm5
0000785dab1e001c  vmovaps [rsp+0x60], xmm6
0000785dab1e0022  vmovaps [rsp+0x70], xmm7
0000785dab1e0028  vmovaps [rsp+0x80], xmm9
0000785dab1e0031  vmovaps [rsp+0x90], xmm10
0000785dab1e003a  vmovaps [rsp+0xA0], xmm11
0000785dab1e0043  vmovaps [rsp+0xB0], xmm12
0000785dab1e004c  vmovaps [rsp+0xC0], xmm13
0000785dab1e0055  vmovaps [rsp+0xD0], xmm14
0000785dab1e005e  vmovaps [rsp+0xE0], xmm15
0000785dab1e0067  sub rsp, 0x30
0000785dab1e006b  movaps [rsp], xmm8
0000785dab1e0070  movaps [rsp+0x10], xmm1
0000785dab1e0075  movaps [rsp+0x20], xmm14
0000785dab1e007b  lea rdi, [rsp]
0000785dab1e007f  mov esi, 0x00
0000785dab1e0084  mov rax, 0x61B13BBD6530
0000785dab1e008e  call rax
0000785dab1e0090  movaps xmm8, [rsp]
0000785dab1e0095  add rsp, 0x30
0000785dab1e0099  vmovaps xmm0, [rsp]
0000785dab1e009e  vmovaps xmm1, [rsp+0x10]
0000785dab1e00a4  vmovaps xmm2, [rsp+0x20]
0000785dab1e00aa  vmovaps xmm3, [rsp+0x30]
0000785dab1e00b0  vmovaps xmm4, [rsp+0x40]
0000785dab1e00b6  vmovaps xmm5, [rsp+0x50]
0000785dab1e00bc  vmovaps xmm6, [rsp+0x60]
0000785dab1e00c2  vmovaps xmm7, [rsp+0x70]
0000785dab1e00c8  vmovaps xmm9, [rsp+0x80]
0000785dab1e00d1  vmovaps xmm10, [rsp+0x90]
0000785dab1e00da  vmovaps xmm11, [rsp+0xA0]
0000785dab1e00e3  vmovaps xmm12, [rsp+0xB0]
0000785dab1e00ec  vmovaps xmm13, [rsp+0xC0]
0000785dab1e00f5  vmovaps xmm14, [rsp+0xD0]
0000785dab1e00fe  vmovaps xmm15, [rsp+0xE0]
0000785dab1e0107  add rsp, 0xF0
0000785dab1e010e  pop r11
0000785dab1e0110  pop r10
0000785dab1e0112  pop r9
0000785dab1e0114  pop r8
0000785dab1e0116  pop rsi
0000785dab1e0117  pop rdi
0000785dab1e0118  pop rdx
0000785dab1e0119  pop rcx
0000785dab1e011a  pop rax
0000785dab1e011b  add rsp, 0x08
0000785dab1e011f  jmp 0x0000785DAB1DC561
0000785dab1e0124  sub rsp, 0x08
0000785dab1e0128  push rax
0000785dab1e0129  push rcx
0000785dab1e012a  push rdx
0000785dab1e012b  push rdi
0000785dab1e012c  push rsi
0000785dab1e012d  push r8
0000785dab1e012f  push r9
0000785dab1e0131  push r10
0000785dab1e0133  push r11
0000785dab1e0135  sub rsp, 0xF0
0000785dab1e013c  vmovaps [rsp], xmm0
0000785dab1e0141  vmovaps [rsp+0x10], xmm1
0000785dab1e0147  vmovaps [rsp+0x20], xmm2
0000785dab1e014d  vmovaps [rsp+0x30], xmm3
0000785dab1e0153  vmovaps [rsp+0x40], xmm4
0000785dab1e0159  vmovaps [rsp+0x50], xmm5
0000785dab1e015f  vmovaps [rsp+0x60], xmm7
0000785dab1e0165  vmovaps [rsp+0x70], xmm8
0000785dab1e016b  vmovaps [rsp+0x80], xmm9
0000785dab1e0174  vmovaps [rsp+0x90], xmm10
0000785dab1e017d  vmovaps [rsp+0xA0], xmm11
0000785dab1e0186  vmovaps [rsp+0xB0], xmm12
0000785dab1e018f  vmovaps [rsp+0xC0], xmm13
0000785dab1e0198  vmovaps [rsp+0xD0], xmm14
0000785dab1e01a1  vmovaps [rsp+0xE0], xmm15
0000785dab1e01aa  sub rsp, 0x30
0000785dab1e01ae  movaps [rsp], xmm6
0000785dab1e01b2  movaps [rsp+0x10], xmm1
0000785dab1e01b7  movaps [rsp+0x20], xmm14
0000785dab1e01bd  lea rdi, [rsp]
0000785dab1e01c1  mov esi, 0x00
0000785dab1e01c6  mov rax, 0x61B13BBD6530
0000785dab1e01d0  call rax
0000785dab1e01d2  movaps xmm6, [rsp]
0000785dab1e01d6  add rsp, 0x30
0000785dab1e01da  vmovaps xmm0, [rsp]
0000785dab1e01df  vmovaps xmm1, [rsp+0x10]
0000785dab1e01e5  vmovaps xmm2, [rsp+0x20]
0000785dab1e01eb  vmovaps xmm3, [rsp+0x30]
0000785dab1e01f1  vmovaps xmm4, [rsp+0x40]
0000785dab1e01f7  vmovaps xmm5, [rsp+0x50]
0000785dab1e01fd  vmovaps xmm7, [rsp+0x60]
0000785dab1e0203  vmovaps xmm8, [rsp+0x70]
0000785dab1e0209  vmovaps xmm9, [rsp+0x80]
0000785dab1e0212  vmovaps xmm10, [rsp+0x90]
0000785dab1e021b  vmovaps xmm11, [rsp+0xA0]
0000785dab1e0224  vmovaps xmm12, [rsp+0xB0]
0000785dab1e022d  vmovaps xmm13, [rsp+0xC0]
0000785dab1e0236  vmovaps xmm14, [rsp+0xD0]
0000785dab1e023f  vmovaps xmm15, [rsp+0xE0]
0000785dab1e0248  add rsp, 0xF0
0000785dab1e024f  pop r11
0000785dab1e0251  pop r10
0000785dab1e0253  pop r9
0000785dab1e0255  pop r8
0000785dab1e0257  pop rsi
0000785dab1e0258  pop rdi
0000785dab1e0259  pop rdx
0000785dab1e025a  pop rcx
0000785dab1e025b  pop rax
0000785dab1e025c  add rsp, 0x08
0000785dab1e0260  jmp 0x0000785DAB1DC58D
0000785dab1e0265  sub rsp, 0x08
0000785dab1e0269  push rax
0000785dab1e026a  push rcx
0000785dab1e026b  push rdx
0000785dab1e026c  push rdi
0000785dab1e026d  push rsi
0000785dab1e026e  push r8
0000785dab1e0270  push r9
0000785dab1e0272  push r10
0000785dab1e0274  push r11
0000785dab1e0276  sub rsp, 0xF0
0000785dab1e027d  vmovaps [rsp], xmm0
0000785dab1e0282  vmovaps [rsp+0x10], xmm1
0000785dab1e0288  vmovaps [rsp+0x20], xmm2
0000785dab1e028e  vmovaps [rsp+0x30], xmm3
0000785dab1e0294  vmovaps [rsp+0x40], xmm4
0000785dab1e029a  vmovaps [rsp+0x50], xmm5
0000785dab1e02a0  vmovaps [rsp+0x60], xmm6
0000785dab1e02a6  vmovaps [rsp+0x70], xmm7
0000785dab1e02ac  vmovaps [rsp+0x80], xmm8
0000785dab1e02b5  vmovaps [rsp+0x90], xmm9
0000785dab1e02be  vmovaps [rsp+0xA0], xmm10
0000785dab1e02c7  vmovaps [rsp+0xB0], xmm11
0000785dab1e02d0  vmovaps [rsp+0xC0], xmm12
0000785dab1e02d9  vmovaps [rsp+0xD0], xmm13
0000785dab1e02e2  vmovaps [rsp+0xE0], xmm15
0000785dab1e02eb  sub rsp, 0x30
0000785dab1e02ef  movaps [rsp], xmm14
0000785dab1e02f4  movaps [rsp+0x10], xmm12
0000785dab1e02fa  movaps [rsp+0x20], xmm1
0000785dab1e02ff  lea rdi, [rsp]
0000785dab1e0303  mov esi, 0x00
0000785dab1e0308  mov rax, 0x61B13BBD6530
0000785dab1e0312  call rax
0000785dab1e0314  movaps xmm14, [rsp]
0000785dab1e0319  add rsp, 0x30
0000785dab1e031d  vmovaps xmm0, [rsp]
0000785dab1e0322  vmovaps xmm1, [rsp+0x10]
0000785dab1e0328  vmovaps xmm2, [rsp+0x20]
0000785dab1e032e  vmovaps xmm3, [rsp+0x30]
0000785dab1e0334  vmovaps xmm4, [rsp+0x40]
0000785dab1e033a  vmovaps xmm5, [rsp+0x50]
0000785dab1e0340  vmovaps xmm6, [rsp+0x60]
0000785dab1e0346  vmovaps xmm7, [rsp+0x70]
0000785dab1e034c  vmovaps xmm8, [rsp+0x80]
0000785dab1e0355  vmovaps xmm9, [rsp+0x90]
0000785dab1e035e  vmovaps xmm10, [rsp+0xA0]
0000785dab1e0367  vmovaps xmm11, [rsp+0xB0]
0000785dab1e0370  vmovaps xmm12, [rsp+0xC0]
0000785dab1e0379  vmovaps xmm13, [rsp+0xD0]
0000785dab1e0382  vmovaps xmm15, [rsp+0xE0]
0000785dab1e038b  add rsp, 0xF0
0000785dab1e0392  pop r11
0000785dab1e0394  pop r10
0000785dab1e0396  pop r9
0000785dab1e0398  pop r8
0000785dab1e039a  pop rsi
0000785dab1e039b  pop rdi
0000785dab1e039c  pop rdx
0000785dab1e039d  pop rcx
0000785dab1e039e  pop rax
0000785dab1e039f  add rsp, 0x08
0000785dab1e03a3  jmp 0x0000785DAB1DC5B3
0000785dab1e03a8  sub rsp, 0x08
0000785dab1e03ac  push rax
0000785dab1e03ad  push rcx
0000785dab1e03ae  push rdx
0000785dab1e03af  push rdi
0000785dab1e03b0  push rsi
0000785dab1e03b1  push r8
0000785dab1e03b3  push r9
0000785dab1e03b5  push r10
0000785dab1e03b7  push r11
0000785dab1e03b9  sub rsp, 0xF0
0000785dab1e03c0  vmovaps [rsp], xmm0
0000785dab1e03c5  vmovaps [rsp+0x10], xmm2
0000785dab1e03cb  vmovaps [rsp+0x20], xmm3
0000785dab1e03d1  vmovaps [rsp+0x30], xmm4
0000785dab1e03d7  vmovaps [rsp+0x40], xmm5
0000785dab1e03dd  vmovaps [rsp+0x50], xmm6
0000785dab1e03e3  vmovaps [rsp+0x60], xmm7
0000785dab1e03e9  vmovaps [rsp+0x70], xmm8
0000785dab1e03ef  vmovaps [rsp+0x80], xmm9
0000785dab1e03f8  vmovaps [rsp+0x90], xmm10
0000785dab1e0401  vmovaps [rsp+0xA0], xmm11
0000785dab1e040a  vmovaps [rsp+0xB0], xmm12
0000785dab1e0413  vmovaps [rsp+0xC0], xmm13
0000785dab1e041c  vmovaps [rsp+0xD0], xmm14
0000785dab1e0425  vmovaps [rsp+0xE0], xmm15
0000785dab1e042e  sub rsp, 0x30
0000785dab1e0432  movaps [rsp], xmm1
0000785dab1e0436  movaps [rsp+0x10], xmm13
0000785dab1e043c  movaps [rsp+0x20], xmm9
0000785dab1e0442  lea rdi, [rsp]
0000785dab1e0446  mov esi, 0x00
0000785dab1e044b  mov rax, 0x61B13BBD6530
0000785dab1e0455  call rax
0000785dab1e0457  movaps xmm1, [rsp]
0000785dab1e045b  add rsp, 0x30
0000785dab1e045f  vmovaps xmm0, [rsp]
0000785dab1e0464  vmovaps xmm2, [rsp+0x10]
0000785dab1e046a  vmovaps xmm3, [rsp+0x20]
0000785dab1e0470  vmovaps xmm4, [rsp+0x30]
0000785dab1e0476  vmovaps xmm5, [rsp+0x40]
0000785dab1e047c  vmovaps xmm6, [rsp+0x50]
0000785dab1e0482  vmovaps xmm7, [rsp+0x60]
0000785dab1e0488  vmovaps xmm8, [rsp+0x70]
0000785dab1e048e  vmovaps xmm9, [rsp+0x80]
0000785dab1e0497  vmovaps xmm10, [rsp+0x90]
0000785dab1e04a0  vmovaps xmm11, [rsp+0xA0]
0000785dab1e04a9  vmovaps xmm12, [rsp+0xB0]
0000785dab1e04b2  vmovaps xmm13, [rsp+0xC0]
0000785dab1e04bb  vmovaps xmm14, [rsp+0xD0]
0000785dab1e04c4  vmovaps xmm15, [rsp+0xE0]
0000785dab1e04cd  add rsp, 0xF0
0000785dab1e04d4  pop r11
0000785dab1e04d6  pop r10
0000785dab1e04d8  pop r9
0000785dab1e04da  pop r8
0000785dab1e04dc  pop rsi
0000785dab1e04dd  pop rdi
0000785dab1e04de  pop rdx
0000785dab1e04df  pop rcx
0000785dab1e04e0  pop rax
0000785dab1e04e1  add rsp, 0x08
0000785dab1e04e5  jmp 0x0000785DAB1DC5CD
0000785dab1e04ea  sub rsp, 0x08
0000785dab1e04ee  push rax
0000785dab1e04ef  push rcx
0000785dab1e04f0  push rdx
0000785dab1e04f1  push rdi
0000785dab1e04f2  push rsi
0000785dab1e04f3  push r8
0000785dab1e04f5  push r9
0000785dab1e04f7  push r10
0000785dab1e04f9  push r11
0000785dab1e04fb  sub rsp, 0xF0
0000785dab1e0502  vmovaps [rsp], xmm0
0000785dab1e0507  vmovaps [rsp+0x10], xmm1
0000785dab1e050d  vmovaps [rsp+0x20], xmm2
0000785dab1e0513  vmovaps [rsp+0x30], xmm3
0000785dab1e0519  vmovaps [rsp+0x40], xmm4
0000785dab1e051f  vmovaps [rsp+0x50], xmm5
0000785dab1e0525  vmovaps [rsp+0x60], xmm6
0000785dab1e052b  vmovaps [rsp+0x70], xmm7
0000785dab1e0531  vmovaps [rsp+0x80], xmm8
0000785dab1e053a  vmovaps [rsp+0x90], xmm9
0000785dab1e0543  vmovaps [rsp+0xA0], xmm10
0000785dab1e054c  vmovaps [rsp+0xB0], xmm11
0000785dab1e0555  vmovaps [rsp+0xC0], xmm13
0000785dab1e055e  vmovaps [rsp+0xD0], xmm14
0000785dab1e0567  vmovaps [rsp+0xE0], xmm15
0000785dab1e0570  sub rsp, 0x30
0000785dab1e0574  movaps [rsp], xmm12
0000785dab1e0579  movaps [rsp+0x10], xmm7
0000785dab1e057e  movaps [rsp+0x20], xmm13
0000785dab1e0584  lea rdi, [rsp]
0000785dab1e0588  mov esi, 0x00
0000785dab1e058d  mov rax, 0x61B13BBD6530
0000785dab1e0597  call rax
0000785dab1e0599  movaps xmm12, [rsp]
0000785dab1e059e  add rsp, 0x30
0000785dab1e05a2  vmovaps xmm0, [rsp]
0000785dab1e05a7  vmovaps xmm1, [rsp+0x10]
0000785dab1e05ad  vmovaps xmm2, [rsp+0x20]
0000785dab1e05b3  vmovaps xmm3, [rsp+0x30]
0000785dab1e05b9  vmovaps xmm4, [rsp+0x40]
0000785dab1e05bf  vmovaps xmm5, [rsp+0x50]
0000785dab1e05c5  vmovaps xmm6, [rsp+0x60]
0000785dab1e05cb  vmovaps xmm7, [rsp+0x70]
0000785dab1e05d1  vmovaps xmm8, [rsp+0x80]
0000785dab1e05da  vmovaps xmm9, [rsp+0x90]
0000785dab1e05e3  vmovaps xmm10, [rsp+0xA0]
0000785dab1e05ec  vmovaps xmm11, [rsp+0xB0]
0000785dab1e05f5  vmovaps xmm13, [rsp+0xC0]
0000785dab1e05fe  vmovaps xmm14, [rsp+0xD0]
0000785dab1e0607  vmovaps xmm15, [rsp+0xE0]
0000785dab1e0610  add rsp, 0xF0
0000785dab1e0617  pop r11
0000785dab1e0619  pop r10
0000785dab1e061b  pop r9
0000785dab1e061d  pop r8
0000785dab1e061f  pop rsi
0000785dab1e0620  pop rdi
0000785dab1e0621  pop rdx
0000785dab1e0622  pop rcx
0000785dab1e0623  pop rax
0000785dab1e0624  add rsp, 0x08
0000785dab1e0628  jmp 0x0000785DAB1DC5F4
0000785dab1e062d  sub rsp, 0x08
0000785dab1e0631  push rax
0000785dab1e0632  push rcx
0000785dab1e0633  push rdx
0000785dab1e0634  push rdi
0000785dab1e0635  push rsi
0000785dab1e0636  push r8
0000785dab1e0638  push r9
0000785dab1e063a  push r10
0000785dab1e063c  push r11
0000785dab1e063e  sub rsp, 0xF0
0000785dab1e0645  vmovaps [rsp], xmm0
0000785dab1e064a  vmovaps [rsp+0x10], xmm1
0000785dab1e0650  vmovaps [rsp+0x20], xmm2
0000785dab1e0656  vmovaps [rsp+0x30], xmm3
0000785dab1e065c  vmovaps [rsp+0x40], xmm4
0000785dab1e0662  vmovaps [rsp+0x50], xmm5
0000785dab1e0668  vmovaps [rsp+0x60], xmm6
0000785dab1e066e  vmovaps [rsp+0x70], xmm7
0000785dab1e0674  vmovaps [rsp+0x80], xmm8
0000785dab1e067d  vmovaps [rsp+0x90], xmm9
0000785dab1e0686  vmovaps [rsp+0xA0], xmm10
0000785dab1e068f  vmovaps [rsp+0xB0], xmm11
0000785dab1e0698  vmovaps [rsp+0xC0], xmm12
0000785dab1e06a1  vmovaps [rsp+0xD0], xmm14
0000785dab1e06aa  vmovaps [rsp+0xE0], xmm15
0000785dab1e06b3  sub rsp, 0x30
0000785dab1e06b7  movaps [rsp], xmm13
0000785dab1e06bc  movaps [rsp+0x10], xmm15
0000785dab1e06c2  movaps [rsp+0x20], xmm8
0000785dab1e06c8  lea rdi, [rsp]
0000785dab1e06cc  mov esi, 0x00
0000785dab1e06d1  mov rax, 0x61B13BBD6530
0000785dab1e06db  call rax
0000785dab1e06dd  movaps xmm13, [rsp]
0000785dab1e06e2  add rsp, 0x30
0000785dab1e06e6  vmovaps xmm0, [rsp]
0000785dab1e06eb  vmovaps xmm1, [rsp+0x10]
0000785dab1e06f1  vmovaps xmm2, [rsp+0x20]
0000785dab1e06f7  vmovaps xmm3, [rsp+0x30]
0000785dab1e06fd  vmovaps xmm4, [rsp+0x40]
0000785dab1e0703  vmovaps xmm5, [rsp+0x50]
0000785dab1e0709  vmovaps xmm6, [rsp+0x60]
0000785dab1e070f  vmovaps xmm7, [rsp+0x70]
0000785dab1e0715  vmovaps xmm8, [rsp+0x80]
0000785dab1e071e  vmovaps xmm9, [rsp+0x90]
0000785dab1e0727  vmovaps xmm10, [rsp+0xA0]
0000785dab1e0730  vmovaps xmm11, [rsp+0xB0]
0000785dab1e0739  vmovaps xmm12, [rsp+0xC0]
0000785dab1e0742  vmovaps xmm14, [rsp+0xD0]
0000785dab1e074b  vmovaps xmm15, [rsp+0xE0]
0000785dab1e0754  add rsp, 0xF0
0000785dab1e075b  pop r11
0000785dab1e075d  pop r10
0000785dab1e075f  pop r9
0000785dab1e0761  pop r8
0000785dab1e0763  pop rsi
0000785dab1e0764  pop rdi
0000785dab1e0765  pop rdx
0000785dab1e0766  pop rcx
0000785dab1e0767  pop rax
0000785dab1e0768  add rsp, 0x08
0000785dab1e076c  jmp 0x0000785DAB1DC60F
0000785dab1e0771  sub rsp, 0x08
0000785dab1e0775  push rax
0000785dab1e0776  push rcx
0000785dab1e0777  push rdx
0000785dab1e0778  push rdi
0000785dab1e0779  push rsi
0000785dab1e077a  push r8
0000785dab1e077c  push r9
0000785dab1e077e  push r10
0000785dab1e0780  push r11
0000785dab1e0782  sub rsp, 0xF0
0000785dab1e0789  vmovaps [rsp], xmm0
0000785dab1e078e  vmovaps [rsp+0x10], xmm1
0000785dab1e0794  vmovaps [rsp+0x20], xmm2
0000785dab1e079a  vmovaps [rsp+0x30], xmm3
0000785dab1e07a0  vmovaps [rsp+0x40], xmm4
0000785dab1e07a6  vmovaps [rsp+0x50], xmm5
0000785dab1e07ac  vmovaps [rsp+0x60], xmm6
0000785dab1e07b2  vmovaps [rsp+0x70], xmm7
0000785dab1e07b8  vmovaps [rsp+0x80], xmm9
0000785dab1e07c1  vmovaps [rsp+0x90], xmm10
0000785dab1e07ca  vmovaps [rsp+0xA0], xmm11
0000785dab1e07d3  vmovaps [rsp+0xB0], xmm12
0000785dab1e07dc  vmovaps [rsp+0xC0], xmm13
0000785dab1e07e5  vmovaps [rsp+0xD0], xmm14
0000785dab1e07ee  vmovaps [rsp+0xE0], xmm15
0000785dab1e07f7  sub rsp, 0x30
0000785dab1e07fb  movaps [rsp], xmm8
0000785dab1e0800  movaps [rsp+0x10], xmm15
0000785dab1e0806  movaps [rsp+0x20], xmm9
0000785dab1e080c  lea rdi, [rsp]
0000785dab1e0810  mov esi, 0x00
0000785dab1e0815  mov rax, 0x61B13BBD6530
0000785dab1e081f  call rax
0000785dab1e0821  movaps xmm8, [rsp]
0000785dab1e0826  add rsp, 0x30
0000785dab1e082a  vmovaps xmm0, [rsp]
0000785dab1e082f  vmovaps xmm1, [rsp+0x10]
0000785dab1e0835  vmovaps xmm2, [rsp+0x20]
0000785dab1e083b  vmovaps xmm3, [rsp+0x30]
0000785dab1e0841  vmovaps xmm4, [rsp+0x40]
0000785dab1e0847  vmovaps xmm5, [rsp+0x50]
0000785dab1e084d  vmovaps xmm6, [rsp+0x60]
0000785dab1e0853  vmovaps xmm7, [rsp+0x70]
0000785dab1e0859  vmovaps xmm9, [rsp+0x80]
0000785dab1e0862  vmovaps xmm10, [rsp+0x90]
0000785dab1e086b  vmovaps xmm11, [rsp+0xA0]
0000785dab1e0874  vmovaps xmm12, [rsp+0xB0]
0000785dab1e087d  vmovaps xmm13, [rsp+0xC0]
0000785dab1e0886  vmovaps xmm14, [rsp+0xD0]
0000785dab1e088f  vmovaps xmm15, [rsp+0xE0]
0000785dab1e0898  add rsp, 0xF0
0000785dab1e089f  pop r11
0000785dab1e08a1  pop r10
0000785dab1e08a3  pop r9
0000785dab1e08a5  pop r8
0000785dab1e08a7  pop rsi
0000785dab1e08a8  pop rdi
0000785dab1e08a9  pop rdx
0000785dab1e08aa  pop rcx
0000785dab1e08ab  pop rax
0000785dab1e08ac  add rsp, 0x08
0000785dab1e08b0  jmp 0x0000785DAB1DC63D
0000785dab1e08b5  sub rsp, 0x08
0000785dab1e08b9  push rax
0000785dab1e08ba  push rcx
0000785dab1e08bb  push rdx
0000785dab1e08bc  push rdi
0000785dab1e08bd  push rsi
0000785dab1e08be  push r8
0000785dab1e08c0  push r9
0000785dab1e08c2  push r10
0000785dab1e08c4  push r11
0000785dab1e08c6  sub rsp, 0xF0
0000785dab1e08cd  vmovaps [rsp], xmm0
0000785dab1e08d2  vmovaps [rsp+0x10], xmm1
0000785dab1e08d8  vmovaps [rsp+0x20], xmm2
0000785dab1e08de  vmovaps [rsp+0x30], xmm3
0000785dab1e08e4  vmovaps [rsp+0x40], xmm4
0000785dab1e08ea  vmovaps [rsp+0x50], xmm5
0000785dab1e08f0  vmovaps [rsp+0x60], xmm6
0000785dab1e08f6  vmovaps [rsp+0x70], xmm7
0000785dab1e08fc  vmovaps [rsp+0x80], xmm8
0000785dab1e0905  vmovaps [rsp+0x90], xmm9
0000785dab1e090e  vmovaps [rsp+0xA0], xmm10
0000785dab1e0917  vmovaps [rsp+0xB0], xmm11
0000785dab1e0920  vmovaps [rsp+0xC0], xmm12
0000785dab1e0929  vmovaps [rsp+0xD0], xmm13
0000785dab1e0932  vmovaps [rsp+0xE0], xmm14
0000785dab1e093b  sub rsp, 0x30
0000785dab1e093f  movaps [rsp], xmm15
0000785dab1e0944  movaps [rsp+0x10], xmm11
0000785dab1e094a  movaps [rsp+0x20], xmm6
0000785dab1e094f  lea rdi, [rsp]
0000785dab1e0953  mov esi, 0x00
0000785dab1e0958  mov rax, 0x61B13BBD6530
0000785dab1e0962  call rax
0000785dab1e0964  movaps xmm15, [rsp]
0000785dab1e0969  add rsp, 0x30
0000785dab1e096d  vmovaps xmm0, [rsp]
0000785dab1e0972  vmovaps xmm1, [rsp+0x10]
0000785dab1e0978  vmovaps xmm2, [rsp+0x20]
0000785dab1e097e  vmovaps xmm3, [rsp+0x30]
0000785dab1e0984  vmovaps xmm4, [rsp+0x40]
0000785dab1e098a  vmovaps xmm5, [rsp+0x50]
0000785dab1e0990  vmovaps xmm6, [rsp+0x60]
0000785dab1e0996  vmovaps xmm7, [rsp+0x70]
0000785dab1e099c  vmovaps xmm8, [rsp+0x80]
0000785dab1e09a5  vmovaps xmm9, [rsp+0x90]
0000785dab1e09ae  vmovaps xmm10, [rsp+0xA0]
0000785dab1e09b7  vmovaps xmm11, [rsp+0xB0]
0000785dab1e09c0  vmovaps xmm12, [rsp+0xC0]
0000785dab1e09c9  vmovaps xmm13, [rsp+0xD0]
0000785dab1e09d2  vmovaps xmm14, [rsp+0xE0]
0000785dab1e09db  add rsp, 0xF0
0000785dab1e09e2  pop r11
0000785dab1e09e4  pop r10
0000785dab1e09e6  pop r9
0000785dab1e09e8  pop r8
0000785dab1e09ea  pop rsi
0000785dab1e09eb  pop rdi
0000785dab1e09ec  pop rdx
0000785dab1e09ed  pop rcx
0000785dab1e09ee  pop rax
0000785dab1e09ef  add rsp, 0x08
0000785dab1e09f3  jmp 0x0000785DAB1DC658
0000785dab1e09f8  sub rsp, 0x08
0000785dab1e09fc  push rax
0000785dab1e09fd  push rcx
0000785dab1e09fe  push rdx
0000785dab1e09ff  push rdi
0000785dab1e0a00  push rsi
0000785dab1e0a01  push r8
0000785dab1e0a03  push r9
0000785dab1e0a05  push r10
0000785dab1e0a07  push r11
0000785dab1e0a09  sub rsp, 0xF0
0000785dab1e0a10  vmovaps [rsp], xmm0
0000785dab1e0a15  vmovaps [rsp+0x10], xmm1
0000785dab1e0a1b  vmovaps [rsp+0x20], xmm2
0000785dab1e0a21  vmovaps [rsp+0x30], xmm3
0000785dab1e0a27  vmovaps [rsp+0x40], xmm4
0000785dab1e0a2d  vmovaps [rsp+0x50], xmm5
0000785dab1e0a33  vmovaps [rsp+0x60], xmm6
0000785dab1e0a39  vmovaps [rsp+0x70], xmm8
0000785dab1e0a3f  vmovaps [rsp+0x80], xmm9
0000785dab1e0a48  vmovaps [rsp+0x90], xmm10
0000785dab1e0a51  vmovaps [rsp+0xA0], xmm11
0000785dab1e0a5a  vmovaps [rsp+0xB0], xmm12
0000785dab1e0a63  vmovaps [rsp+0xC0], xmm13
0000785dab1e0a6c  vmovaps [rsp+0xD0], xmm14
0000785dab1e0a75  vmovaps [rsp+0xE0], xmm15
0000785dab1e0a7e  sub rsp, 0x30
0000785dab1e0a82  movaps [rsp], xmm7
0000785dab1e0a86  movaps [rsp+0x10], xmm11
0000785dab1e0a8c  movaps [rsp+0x20], xmm9
0000785dab1e0a92  lea rdi, [rsp]
0000785dab1e0a96  mov esi, 0x00
0000785dab1e0a9b  mov rax, 0x61B13BBD6530
0000785dab1e0aa5  call rax
0000785dab1e0aa7  movaps xmm7, [rsp]
0000785dab1e0aab  add rsp, 0x30
0000785dab1e0aaf  vmovaps xmm0, [rsp]
0000785dab1e0ab4  vmovaps xmm1, [rsp+0x10]
0000785dab1e0aba  vmovaps xmm2, [rsp+0x20]
0000785dab1e0ac0  vmovaps xmm3, [rsp+0x30]
0000785dab1e0ac6  vmovaps xmm4, [rsp+0x40]
0000785dab1e0acc  vmovaps xmm5, [rsp+0x50]
0000785dab1e0ad2  vmovaps xmm6, [rsp+0x60]
0000785dab1e0ad8  vmovaps xmm8, [rsp+0x70]
0000785dab1e0ade  vmovaps xmm9, [rsp+0x80]
0000785dab1e0ae7  vmovaps xmm10, [rsp+0x90]
0000785dab1e0af0  vmovaps xmm11, [rsp+0xA0]
0000785dab1e0af9  vmovaps xmm12, [rsp+0xB0]
0000785dab1e0b02  vmovaps xmm13, [rsp+0xC0]
0000785dab1e0b0b  vmovaps xmm14, [rsp+0xD0]
0000785dab1e0b14  vmovaps xmm15, [rsp+0xE0]
0000785dab1e0b1d  add rsp, 0xF0
0000785dab1e0b24  pop r11
0000785dab1e0b26  pop r10
0000785dab1e0b28  pop r9
0000785dab1e0b2a  pop r8
0000785dab1e0b2c  pop rsi
0000785dab1e0b2d  pop rdi
0000785dab1e0b2e  pop rdx
0000785dab1e0b2f  pop rcx
0000785dab1e0b30  pop rax
0000785dab1e0b31  add rsp, 0x08
0000785dab1e0b35  jmp 0x0000785DAB1DC685
0000785dab1e0b3a  sub rsp, 0x08
0000785dab1e0b3e  push rax
0000785dab1e0b3f  push rcx
0000785dab1e0b40  push rdx
0000785dab1e0b41  push rdi
0000785dab1e0b42  push rsi
0000785dab1e0b43  push r8
0000785dab1e0b45  push r9
0000785dab1e0b47  push r10
0000785dab1e0b49  push r11
0000785dab1e0b4b  sub rsp, 0xF0
0000785dab1e0b52  vmovaps [rsp], xmm0
0000785dab1e0b57  vmovaps [rsp+0x10], xmm1
0000785dab1e0b5d  vmovaps [rsp+0x20], xmm2
0000785dab1e0b63  vmovaps [rsp+0x30], xmm3
0000785dab1e0b69  vmovaps [rsp+0x40], xmm4
0000785dab1e0b6f  vmovaps [rsp+0x50], xmm5
0000785dab1e0b75  vmovaps [rsp+0x60], xmm6
0000785dab1e0b7b  vmovaps [rsp+0x70], xmm7
0000785dab1e0b81  vmovaps [rsp+0x80], xmm8
0000785dab1e0b8a  vmovaps [rsp+0x90], xmm9
0000785dab1e0b93  vmovaps [rsp+0xA0], xmm10
0000785dab1e0b9c  vmovaps [rsp+0xB0], xmm12
0000785dab1e0ba5  vmovaps [rsp+0xC0], xmm13
0000785dab1e0bae  vmovaps [rsp+0xD0], xmm14
0000785dab1e0bb7  vmovaps [rsp+0xE0], xmm15
0000785dab1e0bc0  sub rsp, 0x30
0000785dab1e0bc4  movaps [rsp], xmm11
0000785dab1e0bc9  movaps [rsp+0x10], xmm10
0000785dab1e0bcf  movaps [rsp+0x20], xmm14
0000785dab1e0bd5  lea rdi, [rsp]
0000785dab1e0bd9  mov esi, 0x00
0000785dab1e0bde  mov rax, 0x61B13BBD6530
0000785dab1e0be8  call rax
0000785dab1e0bea  movaps xmm11, [rsp]
0000785dab1e0bef  add rsp, 0x30
0000785dab1e0bf3  vmovaps xmm0, [rsp]
0000785dab1e0bf8  vmovaps xmm1, [rsp+0x10]
0000785dab1e0bfe  vmovaps xmm2, [rsp+0x20]
0000785dab1e0c04  vmovaps xmm3, [rsp+0x30]
0000785dab1e0c0a  vmovaps xmm4, [rsp+0x40]
0000785dab1e0c10  vmovaps xmm5, [rsp+0x50]
0000785dab1e0c16  vmovaps xmm6, [rsp+0x60]
0000785dab1e0c1c  vmovaps xmm7, [rsp+0x70]
0000785dab1e0c22  vmovaps xmm8, [rsp+0x80]
0000785dab1e0c2b  vmovaps xmm9, [rsp+0x90]
0000785dab1e0c34  vmovaps xmm10, [rsp+0xA0]
0000785dab1e0c3d  vmovaps xmm12, [rsp+0xB0]
0000785dab1e0c46  vmovaps xmm13, [rsp+0xC0]
0000785dab1e0c4f  vmovaps xmm14, [rsp+0xD0]
0000785dab1e0c58  vmovaps xmm15, [rsp+0xE0]
0000785dab1e0c61  add rsp, 0xF0
0000785dab1e0c68  pop r11
0000785dab1e0c6a  pop r10
0000785dab1e0c6c  pop r9
0000785dab1e0c6e  pop r8
0000785dab1e0c70  pop rsi
0000785dab1e0c71  pop rdi
0000785dab1e0c72  pop rdx
0000785dab1e0c73  pop rcx
0000785dab1e0c74  pop rax
0000785dab1e0c75  add rsp, 0x08
0000785dab1e0c79  jmp 0x0000785DAB1DC6A0
0000785dab1e0c7e  call 0x0000785DAB0C33A0
0000785dab1e0c83  jmp 0x0000785DAB1DC6AA
0000785dab1e0c88  sub rsp, 0x08
0000785dab1e0c8c  push rax
0000785dab1e0c8d  push rcx
0000785dab1e0c8e  push rdx
0000785dab1e0c8f  push rdi
0000785dab1e0c90  push rsi
0000785dab1e0c91  push r8
0000785dab1e0c93  push r9
0000785dab1e0c95  push r10
0000785dab1e0c97  push r11
0000785dab1e0c99  sub rsp, 0xF0
0000785dab1e0ca0  vmovaps [rsp], xmm0
0000785dab1e0ca5  vmovaps [rsp+0x10], xmm1
0000785dab1e0cab  vmovaps [rsp+0x20], xmm2
0000785dab1e0cb1  vmovaps [rsp+0x30], xmm3
0000785dab1e0cb7  vmovaps [rsp+0x40], xmm4
0000785dab1e0cbd  vmovaps [rsp+0x50], xmm5
0000785dab1e0cc3  vmovaps [rsp+0x60], xmm6
0000785dab1e0cc9  vmovaps [rsp+0x70], xmm7
0000785dab1e0ccf  vmovaps [rsp+0x80], xmm8
0000785dab1e0cd8  vmovaps [rsp+0x90], xmm9
0000785dab1e0ce1  vmovaps [rsp+0xA0], xmm11
0000785dab1e0cea  vmovaps [rsp+0xB0], xmm12
0000785dab1e0cf3  vmovaps [rsp+0xC0], xmm13
0000785dab1e0cfc  vmovaps [rsp+0xD0], xmm14
0000785dab1e0d05  vmovaps [rsp+0xE0], xmm15
0000785dab1e0d0e  sub rsp, 0x30
0000785dab1e0d12  movaps [rsp], xmm10
0000785dab1e0d17  movaps [rsp+0x10], xmm1
0000785dab1e0d1c  movaps [rsp+0x20], xmm12
0000785dab1e0d22  lea rdi, [rsp]
0000785dab1e0d26  mov esi, 0x00
0000785dab1e0d2b  mov rax, 0x61B13BBD6530
0000785dab1e0d35  call rax
0000785dab1e0d37  movaps xmm10, [rsp]
0000785dab1e0d3c  add rsp, 0x30
0000785dab1e0d40  vmovaps xmm0, [rsp]
0000785dab1e0d45  vmovaps xmm1, [rsp+0x10]
0000785dab1e0d4b  vmovaps xmm2, [rsp+0x20]
0000785dab1e0d51  vmovaps xmm3, [rsp+0x30]
0000785dab1e0d57  vmovaps xmm4, [rsp+0x40]
0000785dab1e0d5d  vmovaps xmm5, [rsp+0x50]
0000785dab1e0d63  vmovaps xmm6, [rsp+0x60]
0000785dab1e0d69  vmovaps xmm7, [rsp+0x70]
0000785dab1e0d6f  vmovaps xmm8, [rsp+0x80]
0000785dab1e0d78  vmovaps xmm9, [rsp+0x90]
0000785dab1e0d81  vmovaps xmm11, [rsp+0xA0]
0000785dab1e0d8a  vmovaps xmm12, [rsp+0xB0]
0000785dab1e0d93  vmovaps xmm13, [rsp+0xC0]
0000785dab1e0d9c  vmovaps xmm14, [rsp+0xD0]
0000785dab1e0da5  vmovaps xmm15, [rsp+0xE0]
0000785dab1e0dae  add rsp, 0xF0
0000785dab1e0db5  pop r11
0000785dab1e0db7  pop r10
0000785dab1e0db9  pop r9
0000785dab1e0dbb  pop r8
0000785dab1e0dbd  pop rsi
0000785dab1e0dbe  pop rdi
0000785dab1e0dbf  pop rdx
0000785dab1e0dc0  pop rcx
0000785dab1e0dc1  pop rax
0000785dab1e0dc2  add rsp, 0x08
0000785dab1e0dc6  jmp 0x0000785DAB1DC6CD
0000785dab1e0dcb  sub rsp, 0x08
0000785dab1e0dcf  push rax
0000785dab1e0dd0  push rcx
0000785dab1e0dd1  push rdx
0000785dab1e0dd2  push rdi
0000785dab1e0dd3  push rsi
0000785dab1e0dd4  push r8
0000785dab1e0dd6  push r9
0000785dab1e0dd8  push r10
0000785dab1e0dda  push r11
0000785dab1e0ddc  sub rsp, 0xF0
0000785dab1e0de3  vmovaps [rsp], xmm0
0000785dab1e0de8  vmovaps [rsp+0x10], xmm1
0000785dab1e0dee  vmovaps [rsp+0x20], xmm2
0000785dab1e0df4  vmovaps [rsp+0x30], xmm3
0000785dab1e0dfa  vmovaps [rsp+0x40], xmm4
0000785dab1e0e00  vmovaps [rsp+0x50], xmm5
0000785dab1e0e06  vmovaps [rsp+0x60], xmm6
0000785dab1e0e0c  vmovaps [rsp+0x70], xmm7
0000785dab1e0e12  vmovaps [rsp+0x80], xmm8
0000785dab1e0e1b  vmovaps [rsp+0x90], xmm9
0000785dab1e0e24  vmovaps [rsp+0xA0], xmm10
0000785dab1e0e2d  vmovaps [rsp+0xB0], xmm11
0000785dab1e0e36  vmovaps [rsp+0xC0], xmm13
0000785dab1e0e3f  vmovaps [rsp+0xD0], xmm14
0000785dab1e0e48  vmovaps [rsp+0xE0], xmm15
0000785dab1e0e51  sub rsp, 0x30
0000785dab1e0e55  movaps [rsp], xmm12
0000785dab1e0e5a  movaps [rsp+0x10], xmm14
0000785dab1e0e60  movaps [rsp+0x20], xmm1
0000785dab1e0e65  lea rdi, [rsp]
0000785dab1e0e69  mov esi, 0x00
0000785dab1e0e6e  mov rax, 0x61B13BBD6530
0000785dab1e0e78  call rax
0000785dab1e0e7a  movaps xmm12, [rsp]
0000785dab1e0e7f  add rsp, 0x30
0000785dab1e0e83  vmovaps xmm0, [rsp]
0000785dab1e0e88  vmovaps xmm1, [rsp+0x10]
0000785dab1e0e8e  vmovaps xmm2, [rsp+0x20]
0000785dab1e0e94  vmovaps xmm3, [rsp+0x30]
0000785dab1e0e9a  vmovaps xmm4, [rsp+0x40]
0000785dab1e0ea0  vmovaps xmm5, [rsp+0x50]
0000785dab1e0ea6  vmovaps xmm6, [rsp+0x60]
0000785dab1e0eac  vmovaps xmm7, [rsp+0x70]
0000785dab1e0eb2  vmovaps xmm8, [rsp+0x80]
0000785dab1e0ebb  vmovaps xmm9, [rsp+0x90]
0000785dab1e0ec4  vmovaps xmm10, [rsp+0xA0]
0000785dab1e0ecd  vmovaps xmm11, [rsp+0xB0]
0000785dab1e0ed6  vmovaps xmm13, [rsp+0xC0]
0000785dab1e0edf  vmovaps xmm14, [rsp+0xD0]
0000785dab1e0ee8  vmovaps xmm15, [rsp+0xE0]
0000785dab1e0ef1  add rsp, 0xF0
0000785dab1e0ef8  pop r11
0000785dab1e0efa  pop r10
0000785dab1e0efc  pop r9
0000785dab1e0efe  pop r8
0000785dab1e0f00  pop rsi
0000785dab1e0f01  pop rdi
0000785dab1e0f02  pop rdx
0000785dab1e0f03  pop rcx
0000785dab1e0f04  pop rax
0000785dab1e0f05  add rsp, 0x08
0000785dab1e0f09  jmp 0x0000785DAB1DC6FC
0000785dab1e0f0e  sub rsp, 0x08
0000785dab1e0f12  push rax
0000785dab1e0f13  push rcx
0000785dab1e0f14  push rdx
0000785dab1e0f15  push rdi
0000785dab1e0f16  push rsi
0000785dab1e0f17  push r8
0000785dab1e0f19  push r9
0000785dab1e0f1b  push r10
0000785dab1e0f1d  push r11
0000785dab1e0f1f  sub rsp, 0xF0
0000785dab1e0f26  vmovaps [rsp], xmm0
0000785dab1e0f2b  vmovaps [rsp+0x10], xmm1
0000785dab1e0f31  vmovaps [rsp+0x20], xmm2
0000785dab1e0f37  vmovaps [rsp+0x30], xmm3
0000785dab1e0f3d  vmovaps [rsp+0x40], xmm4
0000785dab1e0f43  vmovaps [rsp+0x50], xmm5
0000785dab1e0f49  vmovaps [rsp+0x60], xmm6
0000785dab1e0f4f  vmovaps [rsp+0x70], xmm7
0000785dab1e0f55  vmovaps [rsp+0x80], xmm8
0000785dab1e0f5e  vmovaps [rsp+0x90], xmm9
0000785dab1e0f67  vmovaps [rsp+0xA0], xmm10
0000785dab1e0f70  vmovaps [rsp+0xB0], xmm11
0000785dab1e0f79  vmovaps [rsp+0xC0], xmm12
0000785dab1e0f82  vmovaps [rsp+0xD0], xmm13
0000785dab1e0f8b  vmovaps [rsp+0xE0], xmm15
0000785dab1e0f94  sub rsp, 0x30
0000785dab1e0f98  movaps [rsp], xmm14
0000785dab1e0f9d  movaps [rsp+0x10], xmm9
0000785dab1e0fa3  movaps [rsp+0x20], xmm1
0000785dab1e0fa8  lea rdi, [rsp]
0000785dab1e0fac  mov esi, 0x00
0000785dab1e0fb1  mov rax, 0x61B13BBD6530
0000785dab1e0fbb  call rax
0000785dab1e0fbd  movaps xmm14, [rsp]
0000785dab1e0fc2  add rsp, 0x30
0000785dab1e0fc6  vmovaps xmm0, [rsp]
0000785dab1e0fcb  vmovaps xmm1, [rsp+0x10]
0000785dab1e0fd1  vmovaps xmm2, [rsp+0x20]
0000785dab1e0fd7  vmovaps xmm3, [rsp+0x30]
0000785dab1e0fdd  vmovaps xmm4, [rsp+0x40]
0000785dab1e0fe3  vmovaps xmm5, [rsp+0x50]
0000785dab1e0fe9  vmovaps xmm6, [rsp+0x60]
0000785dab1e0fef  vmovaps xmm7, [rsp+0x70]
0000785dab1e0ff5  vmovaps xmm8, [rsp+0x80]
0000785dab1e0ffe  vmovaps xmm9, [rsp+0x90]
0000785dab1e1007  vmovaps xmm10, [rsp+0xA0]
0000785dab1e1010  vmovaps xmm11, [rsp+0xB0]
0000785dab1e1019  vmovaps xmm12, [rsp+0xC0]
0000785dab1e1022  vmovaps xmm13, [rsp+0xD0]
0000785dab1e102b  vmovaps xmm15, [rsp+0xE0]
0000785dab1e1034  add rsp, 0xF0
0000785dab1e103b  pop r11
0000785dab1e103d  pop r10
0000785dab1e103f  pop r9
0000785dab1e1041  pop r8
0000785dab1e1043  pop rsi
0000785dab1e1044  pop rdi
0000785dab1e1045  pop rdx
0000785dab1e1046  pop rcx
0000785dab1e1047  pop rax
0000785dab1e1048  add rsp, 0x08
0000785dab1e104c  jmp 0x0000785DAB1DC72B
0000785dab1e1051  sub rsp, 0x08
0000785dab1e1055  push rax
0000785dab1e1056  push rcx
0000785dab1e1057  push rdx
0000785dab1e1058  push rdi
0000785dab1e1059  push rsi
0000785dab1e105a  push r8
0000785dab1e105c  push r9
0000785dab1e105e  push r10
0000785dab1e1060  push r11
0000785dab1e1062  sub rsp, 0xF0
0000785dab1e1069  vmovaps [rsp], xmm0
0000785dab1e106e  vmovaps [rsp+0x10], xmm2
0000785dab1e1074  vmovaps [rsp+0x20], xmm3
0000785dab1e107a  vmovaps [rsp+0x30], xmm4
0000785dab1e1080  vmovaps [rsp+0x40], xmm5
0000785dab1e1086  vmovaps [rsp+0x50], xmm6
0000785dab1e108c  vmovaps [rsp+0x60], xmm7
0000785dab1e1092  vmovaps [rsp+0x70], xmm8
0000785dab1e1098  vmovaps [rsp+0x80], xmm9
0000785dab1e10a1  vmovaps [rsp+0x90], xmm10
0000785dab1e10aa  vmovaps [rsp+0xA0], xmm11
0000785dab1e10b3  vmovaps [rsp+0xB0], xmm12
0000785dab1e10bc  vmovaps [rsp+0xC0], xmm13
0000785dab1e10c5  vmovaps [rsp+0xD0], xmm14
0000785dab1e10ce  vmovaps [rsp+0xE0], xmm15
0000785dab1e10d7  sub rsp, 0x30
0000785dab1e10db  movaps [rsp], xmm1
0000785dab1e10df  movaps [rsp+0x10], xmm13
0000785dab1e10e5  movaps [rsp+0x20], xmm8
0000785dab1e10eb  lea rdi, [rsp]
0000785dab1e10ef  mov esi, 0x00
0000785dab1e10f4  mov rax, 0x61B13BBD6530
0000785dab1e10fe  call rax
0000785dab1e1100  movaps xmm1, [rsp]
0000785dab1e1104  add rsp, 0x30
0000785dab1e1108  vmovaps xmm0, [rsp]
0000785dab1e110d  vmovaps xmm2, [rsp+0x10]
0000785dab1e1113  vmovaps xmm3, [rsp+0x20]
0000785dab1e1119  vmovaps xmm4, [rsp+0x30]
0000785dab1e111f  vmovaps xmm5, [rsp+0x40]
0000785dab1e1125  vmovaps xmm6, [rsp+0x50]
0000785dab1e112b  vmovaps xmm7, [rsp+0x60]
0000785dab1e1131  vmovaps xmm8, [rsp+0x70]
0000785dab1e1137  vmovaps xmm9, [rsp+0x80]
0000785dab1e1140  vmovaps xmm10, [rsp+0x90]
0000785dab1e1149  vmovaps xmm11, [rsp+0xA0]
0000785dab1e1152  vmovaps xmm12, [rsp+0xB0]
0000785dab1e115b  vmovaps xmm13, [rsp+0xC0]
0000785dab1e1164  vmovaps xmm14, [rsp+0xD0]
0000785dab1e116d  vmovaps xmm15, [rsp+0xE0]
0000785dab1e1176  add rsp, 0xF0
0000785dab1e117d  pop r11
0000785dab1e117f  pop r10
0000785dab1e1181  pop r9
0000785dab1e1183  pop r8
0000785dab1e1185  pop rsi
0000785dab1e1186  pop rdi
0000785dab1e1187  pop rdx
0000785dab1e1188  pop rcx
0000785dab1e1189  pop rax
0000785dab1e118a  add rsp, 0x08
0000785dab1e118e  jmp 0x0000785DAB1DC74D
0000785dab1e1193  call 0x0000785DAB00C260
0000785dab1e1198  jmp 0x0000785DAB1DC75B
0000785dab1e119d  call 0x0000785DAB0BD750
0000785dab1e11a2  jmp 0x0000785DAB1DC765
0000785dab1e11a7  sub rsp, 0x08
0000785dab1e11ab  push rax
0000785dab1e11ac  push rcx
0000785dab1e11ad  push rdx
0000785dab1e11ae  push rdi
0000785dab1e11af  push rsi
0000785dab1e11b0  push r8
0000785dab1e11b2  push r9
0000785dab1e11b4  push r10
0000785dab1e11b6  push r11
0000785dab1e11b8  sub rsp, 0xF0
0000785dab1e11bf  vmovaps [rsp], xmm0
0000785dab1e11c4  vmovaps [rsp+0x10], xmm1
0000785dab1e11ca  vmovaps [rsp+0x20], xmm2
0000785dab1e11d0  vmovaps [rsp+0x30], xmm3
0000785dab1e11d6  vmovaps [rsp+0x40], xmm4
0000785dab1e11dc  vmovaps [rsp+0x50], xmm5
0000785dab1e11e2  vmovaps [rsp+0x60], xmm6
0000785dab1e11e8  vmovaps [rsp+0x70], xmm7
0000785dab1e11ee  vmovaps [rsp+0x80], xmm9
0000785dab1e11f7  vmovaps [rsp+0x90], xmm10
0000785dab1e1200  vmovaps [rsp+0xA0], xmm11
0000785dab1e1209  vmovaps [rsp+0xB0], xmm12
0000785dab1e1212  vmovaps [rsp+0xC0], xmm13
0000785dab1e121b  vmovaps [rsp+0xD0], xmm14
0000785dab1e1224  vmovaps [rsp+0xE0], xmm15
0000785dab1e122d  sub rsp, 0x30
0000785dab1e1231  movaps [rsp], xmm8
0000785dab1e1236  movaps [rsp+0x10], xmm15
0000785dab1e123c  movaps [rsp+0x20], xmm7
0000785dab1e1241  lea rdi, [rsp]
0000785dab1e1245  mov esi, 0x00
0000785dab1e124a  mov rax, 0x61B13BBD6530
0000785dab1e1254  call rax
0000785dab1e1256  movaps xmm8, [rsp]
0000785dab1e125b  add rsp, 0x30
0000785dab1e125f  vmovaps xmm0, [rsp]
0000785dab1e1264  vmovaps xmm1, [rsp+0x10]
0000785dab1e126a  vmovaps xmm2, [rsp+0x20]
0000785dab1e1270  vmovaps xmm3, [rsp+0x30]
0000785dab1e1276  vmovaps xmm4, [rsp+0x40]
0000785dab1e127c  vmovaps xmm5, [rsp+0x50]
0000785dab1e1282  vmovaps xmm6, [rsp+0x60]
0000785dab1e1288  vmovaps xmm7, [rsp+0x70]
0000785dab1e128e  vmovaps xmm9, [rsp+0x80]
0000785dab1e1297  vmovaps xmm10, [rsp+0x90]
0000785dab1e12a0  vmovaps xmm11, [rsp+0xA0]
0000785dab1e12a9  vmovaps xmm12, [rsp+0xB0]
0000785dab1e12b2  vmovaps xmm13, [rsp+0xC0]
0000785dab1e12bb  vmovaps xmm14, [rsp+0xD0]
0000785dab1e12c4  vmovaps xmm15, [rsp+0xE0]
0000785dab1e12cd  add rsp, 0xF0
0000785dab1e12d4  pop r11
0000785dab1e12d6  pop r10
0000785dab1e12d8  pop r9
0000785dab1e12da  pop r8
0000785dab1e12dc  pop rsi
0000785dab1e12dd  pop rdi
0000785dab1e12de  pop rdx
0000785dab1e12df  pop rcx
0000785dab1e12e0  pop rax
0000785dab1e12e1  add rsp, 0x08
0000785dab1e12e5  jmp 0x0000785DAB1DC787
0000785dab1e12ea  sub rsp, 0x08
0000785dab1e12ee  push rax
0000785dab1e12ef  push rcx
0000785dab1e12f0  push rdx
0000785dab1e12f1  push rdi
0000785dab1e12f2  push rsi
0000785dab1e12f3  push r8
0000785dab1e12f5  push r9
0000785dab1e12f7  push r10
0000785dab1e12f9  push r11
0000785dab1e12fb  sub rsp, 0xF0
0000785dab1e1302  vmovaps [rsp], xmm0
0000785dab1e1307  vmovaps [rsp+0x10], xmm1
0000785dab1e130d  vmovaps [rsp+0x20], xmm2
0000785dab1e1313  vmovaps [rsp+0x30], xmm3
0000785dab1e1319  vmovaps [rsp+0x40], xmm4
0000785dab1e131f  vmovaps [rsp+0x50], xmm5
0000785dab1e1325  vmovaps [rsp+0x60], xmm6
0000785dab1e132b  vmovaps [rsp+0x70], xmm8
0000785dab1e1331  vmovaps [rsp+0x80], xmm9
0000785dab1e133a  vmovaps [rsp+0x90], xmm10
0000785dab1e1343  vmovaps [rsp+0xA0], xmm11
0000785dab1e134c  vmovaps [rsp+0xB0], xmm12
0000785dab1e1355  vmovaps [rsp+0xC0], xmm13
0000785dab1e135e  vmovaps [rsp+0xD0], xmm14
0000785dab1e1367  vmovaps [rsp+0xE0], xmm15
0000785dab1e1370  sub rsp, 0x30
0000785dab1e1374  movaps [rsp], xmm7
0000785dab1e1378  movaps [rsp+0x10], xmm9
0000785dab1e137e  movaps [rsp+0x20], xmm15
0000785dab1e1384  lea rdi, [rsp]
0000785dab1e1388  mov esi, 0x00
0000785dab1e138d  mov rax, 0x61B13BBD6530
0000785dab1e1397  call rax
0000785dab1e1399  movaps xmm7, [rsp]
0000785dab1e139d  add rsp, 0x30
0000785dab1e13a1  vmovaps xmm0, [rsp]
0000785dab1e13a6  vmovaps xmm1, [rsp+0x10]
0000785dab1e13ac  vmovaps xmm2, [rsp+0x20]
0000785dab1e13b2  vmovaps xmm3, [rsp+0x30]
0000785dab1e13b8  vmovaps xmm4, [rsp+0x40]
0000785dab1e13be  vmovaps xmm5, [rsp+0x50]
0000785dab1e13c4  vmovaps xmm6, [rsp+0x60]
0000785dab1e13ca  vmovaps xmm8, [rsp+0x70]
0000785dab1e13d0  vmovaps xmm9, [rsp+0x80]
0000785dab1e13d9  vmovaps xmm10, [rsp+0x90]
0000785dab1e13e2  vmovaps xmm11, [rsp+0xA0]
0000785dab1e13eb  vmovaps xmm12, [rsp+0xB0]
0000785dab1e13f4  vmovaps xmm13, [rsp+0xC0]
0000785dab1e13fd  vmovaps xmm14, [rsp+0xD0]
0000785dab1e1406  vmovaps xmm15, [rsp+0xE0]
0000785dab1e140f  add rsp, 0xF0
0000785dab1e1416  pop r11
0000785dab1e1418  pop r10
0000785dab1e141a  pop r9
0000785dab1e141c  pop r8
0000785dab1e141e  pop rsi
0000785dab1e141f  pop rdi
0000785dab1e1420  pop rdx
0000785dab1e1421  pop rcx
0000785dab1e1422  pop rax
0000785dab1e1423  add rsp, 0x08
0000785dab1e1427  jmp 0x0000785DAB1DC7B4
0000785dab1e142c  sub rsp, 0x08
0000785dab1e1430  push rax
0000785dab1e1431  push rcx
0000785dab1e1432  push rdx
0000785dab1e1433  push rdi
0000785dab1e1434  push rsi
0000785dab1e1435  push r8
0000785dab1e1437  push r9
0000785dab1e1439  push r10
0000785dab1e143b  push r11
0000785dab1e143d  sub rsp, 0xF0
0000785dab1e1444  vmovaps [rsp], xmm0
0000785dab1e1449  vmovaps [rsp+0x10], xmm1
0000785dab1e144f  vmovaps [rsp+0x20], xmm2
0000785dab1e1455  vmovaps [rsp+0x30], xmm3
0000785dab1e145b  vmovaps [rsp+0x40], xmm4
0000785dab1e1461  vmovaps [rsp+0x50], xmm5
0000785dab1e1467  vmovaps [rsp+0x60], xmm6
0000785dab1e146d  vmovaps [rsp+0x70], xmm7
0000785dab1e1473  vmovaps [rsp+0x80], xmm8
0000785dab1e147c  vmovaps [rsp+0x90], xmm10
0000785dab1e1485  vmovaps [rsp+0xA0], xmm11
0000785dab1e148e  vmovaps [rsp+0xB0], xmm12
0000785dab1e1497  vmovaps [rsp+0xC0], xmm13
0000785dab1e14a0  vmovaps [rsp+0xD0], xmm14
0000785dab1e14a9  vmovaps [rsp+0xE0], xmm15
0000785dab1e14b2  sub rsp, 0x30
0000785dab1e14b6  movaps [rsp], xmm9
0000785dab1e14bb  movaps [rsp+0x10], xmm13
0000785dab1e14c1  movaps [rsp+0x20], xmm15
0000785dab1e14c7  lea rdi, [rsp]
0000785dab1e14cb  mov esi, 0x00
0000785dab1e14d0  mov rax, 0x61B13BBD6530
0000785dab1e14da  call rax
0000785dab1e14dc  movaps xmm9, [rsp]
0000785dab1e14e1  add rsp, 0x30
0000785dab1e14e5  vmovaps xmm0, [rsp]
0000785dab1e14ea  vmovaps xmm1, [rsp+0x10]
0000785dab1e14f0  vmovaps xmm2, [rsp+0x20]
0000785dab1e14f6  vmovaps xmm3, [rsp+0x30]
0000785dab1e14fc  vmovaps xmm4, [rsp+0x40]
0000785dab1e1502  vmovaps xmm5, [rsp+0x50]
0000785dab1e1508  vmovaps xmm6, [rsp+0x60]
0000785dab1e150e  vmovaps xmm7, [rsp+0x70]
0000785dab1e1514  vmovaps xmm8, [rsp+0x80]
0000785dab1e151d  vmovaps xmm10, [rsp+0x90]
0000785dab1e1526  vmovaps xmm11, [rsp+0xA0]
0000785dab1e152f  vmovaps xmm12, [rsp+0xB0]
0000785dab1e1538  vmovaps xmm13, [rsp+0xC0]
0000785dab1e1541  vmovaps xmm14, [rsp+0xD0]
0000785dab1e154a  vmovaps xmm15, [rsp+0xE0]
0000785dab1e1553  add rsp, 0xF0
0000785dab1e155a  pop r11
0000785dab1e155c  pop r10
0000785dab1e155e  pop r9
0000785dab1e1560  pop r8
0000785dab1e1562  pop rsi
0000785dab1e1563  pop rdi
0000785dab1e1564  pop rdx
0000785dab1e1565  pop rcx
0000785dab1e1566  pop rax
0000785dab1e1567  add rsp, 0x08
0000785dab1e156b  jmp 0x0000785DAB1DC7E2
0000785dab1e1570  sub rsp, 0x08
0000785dab1e1574  push rax
0000785dab1e1575  push rcx
0000785dab1e1576  push rdx
0000785dab1e1577  push rdi
0000785dab1e1578  push rsi
0000785dab1e1579  push r8
0000785dab1e157b  push r9
0000785dab1e157d  push r10
0000785dab1e157f  push r11
0000785dab1e1581  sub rsp, 0xF0
0000785dab1e1588  vmovaps [rsp], xmm0
0000785dab1e158d  vmovaps [rsp+0x10], xmm1
0000785dab1e1593  vmovaps [rsp+0x20], xmm2
0000785dab1e1599  vmovaps [rsp+0x30], xmm3
0000785dab1e159f  vmovaps [rsp+0x40], xmm4
0000785dab1e15a5  vmovaps [rsp+0x50], xmm5
0000785dab1e15ab  vmovaps [rsp+0x60], xmm6
0000785dab1e15b1  vmovaps [rsp+0x70], xmm7
0000785dab1e15b7  vmovaps [rsp+0x80], xmm8
0000785dab1e15c0  vmovaps [rsp+0x90], xmm9
0000785dab1e15c9  vmovaps [rsp+0xA0], xmm10
0000785dab1e15d2  vmovaps [rsp+0xB0], xmm11
0000785dab1e15db  vmovaps [rsp+0xC0], xmm12
0000785dab1e15e4  vmovaps [rsp+0xD0], xmm13
0000785dab1e15ed  vmovaps [rsp+0xE0], xmm14
0000785dab1e15f6  sub rsp, 0x30
0000785dab1e15fa  movaps [rsp], xmm15
0000785dab1e15ff  movaps [rsp+0x10], xmm11
0000785dab1e1605  movaps [rsp+0x20], xmm12
0000785dab1e160b  lea rdi, [rsp]
0000785dab1e160f  mov esi, 0x00
0000785dab1e1614  mov rax, 0x61B13BBD6530
0000785dab1e161e  call rax
0000785dab1e1620  movaps xmm15, [rsp]
0000785dab1e1625  add rsp, 0x30
0000785dab1e1629  vmovaps xmm0, [rsp]
0000785dab1e162e  vmovaps xmm1, [rsp+0x10]
0000785dab1e1634  vmovaps xmm2, [rsp+0x20]
0000785dab1e163a  vmovaps xmm3, [rsp+0x30]
0000785dab1e1640  vmovaps xmm4, [rsp+0x40]
0000785dab1e1646  vmovaps xmm5, [rsp+0x50]
0000785dab1e164c  vmovaps xmm6, [rsp+0x60]
0000785dab1e1652  vmovaps xmm7, [rsp+0x70]
0000785dab1e1658  vmovaps xmm8, [rsp+0x80]
0000785dab1e1661  vmovaps xmm9, [rsp+0x90]
0000785dab1e166a  vmovaps xmm10, [rsp+0xA0]
0000785dab1e1673  vmovaps xmm11, [rsp+0xB0]
0000785dab1e167c  vmovaps xmm12, [rsp+0xC0]
0000785dab1e1685  vmovaps xmm13, [rsp+0xD0]
0000785dab1e168e  vmovaps xmm14, [rsp+0xE0]
0000785dab1e1697  add rsp, 0xF0
0000785dab1e169e  pop r11
0000785dab1e16a0  pop r10
0000785dab1e16a2  pop r9
0000785dab1e16a4  pop r8
0000785dab1e16a6  pop rsi
0000785dab1e16a7  pop rdi
0000785dab1e16a8  pop rdx
0000785dab1e16a9  pop rcx
0000785dab1e16aa  pop rax
0000785dab1e16ab  add rsp, 0x08
0000785dab1e16af  jmp 0x0000785DAB1DC7FD
0000785dab1e16b4  sub rsp, 0x08
0000785dab1e16b8  push rax
0000785dab1e16b9  push rcx
0000785dab1e16ba  push rdx
0000785dab1e16bb  push rdi
0000785dab1e16bc  push rsi
0000785dab1e16bd  push r8
0000785dab1e16bf  push r9
0000785dab1e16c1  push r10
0000785dab1e16c3  push r11
0000785dab1e16c5  sub rsp, 0xF0
0000785dab1e16cc  vmovaps [rsp], xmm0
0000785dab1e16d1  vmovaps [rsp+0x10], xmm1
0000785dab1e16d7  vmovaps [rsp+0x20], xmm2
0000785dab1e16dd  vmovaps [rsp+0x30], xmm3
0000785dab1e16e3  vmovaps [rsp+0x40], xmm4
0000785dab1e16e9  vmovaps [rsp+0x50], xmm5
0000785dab1e16ef  vmovaps [rsp+0x60], xmm6
0000785dab1e16f5  vmovaps [rsp+0x70], xmm7
0000785dab1e16fb  vmovaps [rsp+0x80], xmm8
0000785dab1e1704  vmovaps [rsp+0x90], xmm9
0000785dab1e170d  vmovaps [rsp+0xA0], xmm10
0000785dab1e1716  vmovaps [rsp+0xB0], xmm11
0000785dab1e171f  vmovaps [rsp+0xC0], xmm12
0000785dab1e1728  vmovaps [rsp+0xD0], xmm14
0000785dab1e1731  vmovaps [rsp+0xE0], xmm15
0000785dab1e173a  sub rsp, 0x30
0000785dab1e173e  movaps [rsp], xmm13
0000785dab1e1743  movaps [rsp+0x10], xmm10
0000785dab1e1749  movaps [rsp+0x20], xmm14
0000785dab1e174f  lea rdi, [rsp]
0000785dab1e1753  mov esi, 0x00
0000785dab1e1758  mov rax, 0x61B13BBD6530
0000785dab1e1762  call rax
0000785dab1e1764  movaps xmm13, [rsp]
0000785dab1e1769  add rsp, 0x30
0000785dab1e176d  vmovaps xmm0, [rsp]
0000785dab1e1772  vmovaps xmm1, [rsp+0x10]
0000785dab1e1778  vmovaps xmm2, [rsp+0x20]
0000785dab1e177e  vmovaps xmm3, [rsp+0x30]
0000785dab1e1784  vmovaps xmm4, [rsp+0x40]
0000785dab1e178a  vmovaps xmm5, [rsp+0x50]
0000785dab1e1790  vmovaps xmm6, [rsp+0x60]
0000785dab1e1796  vmovaps xmm7, [rsp+0x70]
0000785dab1e179c  vmovaps xmm8, [rsp+0x80]
0000785dab1e17a5  vmovaps xmm9, [rsp+0x90]
0000785dab1e17ae  vmovaps xmm10, [rsp+0xA0]
0000785dab1e17b7  vmovaps xmm11, [rsp+0xB0]
0000785dab1e17c0  vmovaps xmm12, [rsp+0xC0]
0000785dab1e17c9  vmovaps xmm14, [rsp+0xD0]
0000785dab1e17d2  vmovaps xmm15, [rsp+0xE0]
0000785dab1e17db  add rsp, 0xF0
0000785dab1e17e2  pop r11
0000785dab1e17e4  pop r10
0000785dab1e17e6  pop r9
0000785dab1e17e8  pop r8
0000785dab1e17ea  pop rsi
0000785dab1e17eb  pop rdi
0000785dab1e17ec  pop rdx
0000785dab1e17ed  pop rcx
0000785dab1e17ee  pop rax
0000785dab1e17ef  add rsp, 0x08
0000785dab1e17f3  jmp 0x0000785DAB1DC820
0000785dab1e17f8  sub rsp, 0x08
0000785dab1e17fc  push rax
0000785dab1e17fd  push rcx
0000785dab1e17fe  push rdx
0000785dab1e17ff  push rdi
0000785dab1e1800  push rsi
0000785dab1e1801  push r8
0000785dab1e1803  push r9
0000785dab1e1805  push r10
0000785dab1e1807  push r11
0000785dab1e1809  sub rsp, 0xF0
0000785dab1e1810  vmovaps [rsp], xmm0
0000785dab1e1815  vmovaps [rsp+0x10], xmm1
0000785dab1e181b  vmovaps [rsp+0x20], xmm2
0000785dab1e1821  vmovaps [rsp+0x30], xmm3
0000785dab1e1827  vmovaps [rsp+0x40], xmm4
0000785dab1e182d  vmovaps [rsp+0x50], xmm5
0000785dab1e1833  vmovaps [rsp+0x60], xmm6
0000785dab1e1839  vmovaps [rsp+0x70], xmm7
0000785dab1e183f  vmovaps [rsp+0x80], xmm8
0000785dab1e1848  vmovaps [rsp+0x90], xmm9
0000785dab1e1851  vmovaps [rsp+0xA0], xmm10
0000785dab1e185a  vmovaps [rsp+0xB0], xmm11
0000785dab1e1863  vmovaps [rsp+0xC0], xmm12
0000785dab1e186c  vmovaps [rsp+0xD0], xmm13
0000785dab1e1875  vmovaps [rsp+0xE0], xmm15
0000785dab1e187e  sub rsp, 0x30
0000785dab1e1882  movaps [rsp], xmm14
0000785dab1e1887  movaps [rsp+0x10], xmm1
0000785dab1e188c  movaps [rsp+0x20], xmm7
0000785dab1e1891  lea rdi, [rsp]
0000785dab1e1895  mov esi, 0x00
0000785dab1e189a  mov rax, 0x61B13BBD6530
0000785dab1e18a4  call rax
0000785dab1e18a6  movaps xmm14, [rsp]
0000785dab1e18ab  add rsp, 0x30
0000785dab1e18af  vmovaps xmm0, [rsp]
0000785dab1e18b4  vmovaps xmm1, [rsp+0x10]
0000785dab1e18ba  vmovaps xmm2, [rsp+0x20]
0000785dab1e18c0  vmovaps xmm3, [rsp+0x30]
0000785dab1e18c6  vmovaps xmm4, [rsp+0x40]
0000785dab1e18cc  vmovaps xmm5, [rsp+0x50]
0000785dab1e18d2  vmovaps xmm6, [rsp+0x60]
0000785dab1e18d8  vmovaps xmm7, [rsp+0x70]
0000785dab1e18de  vmovaps xmm8, [rsp+0x80]
0000785dab1e18e7  vmovaps xmm9, [rsp+0x90]
0000785dab1e18f0  vmovaps xmm10, [rsp+0xA0]
0000785dab1e18f9  vmovaps xmm11, [rsp+0xB0]
0000785dab1e1902  vmovaps xmm12, [rsp+0xC0]
0000785dab1e190b  vmovaps xmm13, [rsp+0xD0]
0000785dab1e1914  vmovaps xmm15, [rsp+0xE0]
0000785dab1e191d  add rsp, 0xF0
0000785dab1e1924  pop r11
0000785dab1e1926  pop r10
0000785dab1e1928  pop r9
0000785dab1e192a  pop r8
0000785dab1e192c  pop rsi
0000785dab1e192d  pop rdi
0000785dab1e192e  pop rdx
0000785dab1e192f  pop rcx
0000785dab1e1930  pop rax
0000785dab1e1931  add rsp, 0x08
0000785dab1e1935  jmp 0x0000785DAB1DC843
0000785dab1e193a  sub rsp, 0x08
0000785dab1e193e  push rax
0000785dab1e193f  push rcx
0000785dab1e1940  push rdx
0000785dab1e1941  push rdi
0000785dab1e1942  push rsi
0000785dab1e1943  push r8
0000785dab1e1945  push r9
0000785dab1e1947  push r10
0000785dab1e1949  push r11
0000785dab1e194b  sub rsp, 0xF0
0000785dab1e1952  vmovaps [rsp], xmm0
0000785dab1e1957  vmovaps [rsp+0x10], xmm2
0000785dab1e195d  vmovaps [rsp+0x20], xmm3
0000785dab1e1963  vmovaps [rsp+0x30], xmm4
0000785dab1e1969  vmovaps [rsp+0x40], xmm5
0000785dab1e196f  vmovaps [rsp+0x50], xmm6
0000785dab1e1975  vmovaps [rsp+0x60], xmm7
0000785dab1e197b  vmovaps [rsp+0x70], xmm8
0000785dab1e1981  vmovaps [rsp+0x80], xmm9
0000785dab1e198a  vmovaps [rsp+0x90], xmm10
0000785dab1e1993  vmovaps [rsp+0xA0], xmm11
0000785dab1e199c  vmovaps [rsp+0xB0], xmm12
0000785dab1e19a5  vmovaps [rsp+0xC0], xmm13
0000785dab1e19ae  vmovaps [rsp+0xD0], xmm14
0000785dab1e19b7  vmovaps [rsp+0xE0], xmm15
0000785dab1e19c0  sub rsp, 0x30
0000785dab1e19c4  movaps [rsp], xmm1
0000785dab1e19c8  movaps [rsp+0x10], xmm8
0000785dab1e19ce  movaps [rsp+0x20], xmm9
0000785dab1e19d4  lea rdi, [rsp]
0000785dab1e19d8  mov esi, 0x00
0000785dab1e19dd  mov rax, 0x61B13BBD6530
0000785dab1e19e7  call rax
0000785dab1e19e9  movaps xmm1, [rsp]
0000785dab1e19ed  add rsp, 0x30
0000785dab1e19f1  vmovaps xmm0, [rsp]
0000785dab1e19f6  vmovaps xmm2, [rsp+0x10]
0000785dab1e19fc  vmovaps xmm3, [rsp+0x20]
0000785dab1e1a02  vmovaps xmm4, [rsp+0x30]
0000785dab1e1a08  vmovaps xmm5, [rsp+0x40]
0000785dab1e1a0e  vmovaps xmm6, [rsp+0x50]
0000785dab1e1a14  vmovaps xmm7, [rsp+0x60]
0000785dab1e1a1a  vmovaps xmm8, [rsp+0x70]
0000785dab1e1a20  vmovaps xmm9, [rsp+0x80]
0000785dab1e1a29  vmovaps xmm10, [rsp+0x90]
0000785dab1e1a32  vmovaps xmm11, [rsp+0xA0]
0000785dab1e1a3b  vmovaps xmm12, [rsp+0xB0]
0000785dab1e1a44  vmovaps xmm13, [rsp+0xC0]
0000785dab1e1a4d  vmovaps xmm14, [rsp+0xD0]
0000785dab1e1a56  vmovaps xmm15, [rsp+0xE0]
0000785dab1e1a5f  add rsp, 0xF0
0000785dab1e1a66  pop r11
0000785dab1e1a68  pop r10
0000785dab1e1a6a  pop r9
0000785dab1e1a6c  pop r8
0000785dab1e1a6e  pop rsi
0000785dab1e1a6f  pop rdi
0000785dab1e1a70  pop rdx
0000785dab1e1a71  pop rcx
0000785dab1e1a72  pop rax
0000785dab1e1a73  add rsp, 0x08
0000785dab1e1a77  jmp 0x0000785DAB1DC865
0000785dab1e1a7c  call 0x0000785DAB0E5940
0000785dab1e1a81  jmp 0x0000785DAB1DC873
0000785dab1e1a86  call 0x0000785DAB00C380
0000785dab1e1a8b  jmp 0x0000785DAB1DC87D
0000785dab1e1a90  call 0x0000785DAB00D600
0000785dab1e1a95  jmp 0x0000785DAB1DC887
0000785dab1e1a9a  call 0x0000785DAAFFF540
0000785dab1e1a9f  jmp 0x0000785DAB1DC891
0000785dab1e1aa4  int3
0000785dab1e1aa5  nop [rax+rax*1], ax
0000785dab1e1aae  nop
0000785dab1e1ab0  mov rax, [r15+0xF8]
0000785dab1e1ab7  lea r14, [rax+0x140]
0000785dab1e1abe  mov r12, [r13+r14*1]
0000785dab1e1ac3  mov [r15+0xE8], r12
0000785dab1e1aca  lea r14, [rax+0x130]
0000785dab1e1ad1  mov r12, [r13+r14*1]
0000785dab1e1ad6  lea r14, [rax+0x138]
0000785dab1e1add  mov r11, [r13+r14*1]
0000785dab1e1ae2  movq xmm1, r12
0000785dab1e1ae7  movq xmm15, r11
0000785dab1e1aec  movq xmm1, xmm1
0000785dab1e1af0  movq xmm1, xmm1
0000785dab1e1af4  movaps [r15+0x1A0], xmm1
0000785dab1e1afc  movq xmm15, xmm15
0000785dab1e1b01  movq xmm15, xmm15
0000785dab1e1b06  movaps [r15+0x190], xmm15
0000785dab1e1b0e  lea r14, [rax+0x120]
0000785dab1e1b15  mov r12, [r13+r14*1]
0000785dab1e1b1a  lea r14, [rax+0x128]
0000785dab1e1b21  mov r11, [r13+r14*1]
0000785dab1e1b26  movq xmm1, r12
0000785dab1e1b2b  movq xmm15, r11
0000785dab1e1b30  movq xmm1, xmm1
0000785dab1e1b34  movq xmm1, xmm1
0000785dab1e1b38  movaps [r15+0x1C0], xmm1
0000785dab1e1b40  movq xmm15, xmm15
0000785dab1e1b45  movq xmm15, xmm15
0000785dab1e1b4a  movaps [r15+0x1B0], xmm15
0000785dab1e1b52  lea r14, [rax+0x110]
0000785dab1e1b59  mov r12, [r13+r14*1]
0000785dab1e1b5e  lea r14, [rax+0x118]
0000785dab1e1b65  mov r11, [r13+r14*1]
0000785dab1e1b6a  movq xmm1, r12
0000785dab1e1b6f  movq xmm15, r11
0000785dab1e1b74  movq xmm1, xmm1
0000785dab1e1b78  movq xmm1, xmm1
0000785dab1e1b7c  movaps [r15+0x1E0], xmm1
0000785dab1e1b84  movq xmm15, xmm15
0000785dab1e1b89  movq xmm15, xmm15
0000785dab1e1b8e  movaps [r15+0x1D0], xmm15
0000785dab1e1b96  lea r14, [rax+0x100]
0000785dab1e1b9d  mov r12, [r13+r14*1]
0000785dab1e1ba2  lea r14, [rax+0x108]
0000785dab1e1ba9  mov r11, [r13+r14*1]
0000785dab1e1bae  movq xmm1, r12
0000785dab1e1bb3  movq xmm15, r11
0000785dab1e1bb8  movq xmm1, xmm1
0000785dab1e1bbc  movq xmm1, xmm1
0000785dab1e1bc0  movaps [r15+0x200], xmm1
0000785dab1e1bc8  movq xmm15, xmm15
0000785dab1e1bcd  movq xmm15, xmm15
0000785dab1e1bd2  movaps [r15+0x1F0], xmm15
0000785dab1e1bda  mov qword ptr [r15+0x40], 0x430000
0000785dab1e1be2  mov r14d, 0x430510
0000785dab1e1be8  mov r12, [r13+r14*1]
0000785dab1e1bed  movq xmm1, r12
0000785dab1e1bf2  lea r14, [rax+0x150]
0000785dab1e1bf9  mov [r15+0xF8], r14
0000785dab1e1c00  mov rax, [r15+0x50]
0000785dab1e1c04  movups xmm15, [r13+rax*1]
0000785dab1e1c0a  movaps [r15+0x120], xmm15
0000785dab1e1c12  mov qword ptr [r15+0x48], 0x10
0000785dab1e1c1a  xor eax, eax
0000785dab1e1c1c  mov r14d, 0x10
0000785dab1e1c22  mov r12d, 0x200
0000785dab1e1c28  cmp r14, r12
0000785dab1e1c2b  cmc
0000785dab1e1c2c  lahf
0000785dab1e1c2d  seto al
0000785dab1e1c30  mov [r15+0x108], eax
0000785dab1e1c37  pextrq rax, xmm15, 0x01
0000785dab1e1c3e  movq xmm14, rax
0000785dab1e1c43  movaps [r15+0x130], xmm14
0000785dab1e1c4b  movq rax, xmm1
0000785dab1e1c50  movq r14, xmm15
0000785dab1e1c55  vmovq xmm1, rax
0000785dab1e1c5a  vmovq xmm15, r14
0000785dab1e1c5f  movaps xmm13, xmm1
0000785dab1e1c63  addsd xmm13, xmm15
0000785dab1e1c68  ucomisd xmm13, xmm13
0000785dab1e1c6d  jp 0x0000785DAB1E1D86
0000785dab1e1c73  movq xmm13, xmm13
0000785dab1e1c78  movq rax, xmm13
0000785dab1e1c7d  movq r14, xmm14
0000785dab1e1c82  vmovq xmm1, rax
0000785dab1e1c87  vmovq xmm15, r14
0000785dab1e1c8c  movaps xmm14, xmm1
0000785dab1e1c90  addsd xmm14, xmm15
0000785dab1e1c95  ucomisd xmm14, xmm14
0000785dab1e1c9a  jp 0x0000785DAB1E1DCE
0000785dab1e1ca0  movq xmm14, xmm14
0000785dab1e1ca5  movaps [r15+0x110], xmm14
0000785dab1e1cad  mov eax, [r15+0x108]
0000785dab1e1cb4  sahf
0000785dab1e1cb5  jnz 0x0000785DAB1E1CE7
0000785dab1e1cb7  cmp dword ptr [r15+0x318], 0x00
0000785dab1e1cbf  jz 0x0000785DAB1E1FE0
0000785dab1e1cc5  nop [rax+rax*1], ax
0000785dab1e1cce  nop [rax+rax*1], eax
0000785dab1e1cd6  mov eax, 0x410490
0000785dab1e1cdb  mov [r15+0x100], rax
0000785dab1e1ce2  jmp 0x0000785DAAFFE110
0000785dab1e1ce7  cmp dword ptr [r15+0x318], 0x00
0000785dab1e1cef  jz 0x0000785DAB1E1E20
0000785dab1e1cf5  nop [rax+rax*1], ax
0000785dab1e1cfe  nop [rax+rax*1], eax
0000785dab1e1d06  mov eax, 0x410474
0000785dab1e1d0b  mov [r15+0x100], rax
0000785dab1e1d12  jmp 0x0000785DAAFFE110
0000785dab1e1d17  int3
0000785dab1e1d18  call 0x0000785DAB0E27E0
0000785dab1e1d1d  jmp 0x0000785DAB1E1AC3
0000785dab1e1d22  call 0x0000785DAB0E27E0
0000785dab1e1d27  jmp 0x0000785DAB1E1AD6
0000785dab1e1d2c  call 0x0000785DAB0E1570
0000785dab1e1d31  jmp 0x0000785DAB1E1AE2
0000785dab1e1d36  call 0x0000785DAB0E27E0
0000785dab1e1d3b  jmp 0x0000785DAB1E1B1A
0000785dab1e1d40  call 0x0000785DAB0E1570
0000785dab1e1d45  jmp 0x0000785DAB1E1B26
0000785dab1e1d4a  call 0x0000785DAB0E27E0
0000785dab1e1d4f  jmp 0x0000785DAB1E1B5E
0000785dab1e1d54  call 0x0000785DAB0E1570
0000785dab1e1d59  jmp 0x0000785DAB1E1B6A
0000785dab1e1d5e  call 0x0000785DAB0E27E0
0000785dab1e1d63  jmp 0x0000785DAB1E1BA2
0000785dab1e1d68  call 0x0000785DAB0E1570
0000785dab1e1d6d  jmp 0x0000785DAB1E1BAE
0000785dab1e1d72  call 0x0000785DAB0E27E0
0000785dab1e1d77  jmp 0x0000785DAB1E1BED
0000785dab1e1d7c  call 0x0000785DAB00E760
0000785dab1e1d81  jmp 0x0000785DAB1E1C0A
0000785dab1e1d86  ucomisd xmm1, xmm15
0000785dab1e1d8b  jp 0x0000785DAB1E1D9A
0000785dab1e1d8d  movaps xmm13, [0x0000785DAADFE060]
0000785dab1e1d95  jmp 0x0000785DAB1E1C73
0000785dab1e1d9a  vxorps xmm0, xmm1, xmm15
0000785dab1e1d9f  pextrw eax, xmm0, 0x03
0000785dab1e1da4  and eax, 0x7FF8
0000785dab1e1da9  cmp eax, 0x08
0000785dab1e1dac  jnz 0x0000785DAB1E1C73
0000785dab1e1db2  movq rax, xmm15
0000785dab1e1db7  shl rax, 0x0D
0000785dab1e1dbb  jbe 0x0000785DAB1E1C73
0000785dab1e1dc1  vorps xmm13, xmm15, [0x0000785DAADFE070]
0000785dab1e1dc9  jmp 0x0000785DAB1E1C73
0000785dab1e1dce  ucomisd xmm1, xmm15
0000785dab1e1dd3  jp 0x0000785DAB1E1DE2
0000785dab1e1dd5  movaps xmm14, [0x0000785DAADFE060]
0000785dab1e1ddd  jmp 0x0000785DAB1E1CA0
0000785dab1e1de2  vxorps xmm0, xmm1, xmm15
0000785dab1e1de7  pextrw eax, xmm0, 0x03
0000785dab1e1dec  and eax, 0x7FF8
0000785dab1e1df1  cmp eax, 0x08
0000785dab1e1df4  jnz 0x0000785DAB1E1CA0
0000785dab1e1dfa  movq rax, xmm15
0000785dab1e1dff  shl rax, 0x0D
0000785dab1e1e03  jbe 0x0000785DAB1E1CA0
0000785dab1e1e09  vorps xmm14, xmm15, [0x0000785DAADFE070]
0000785dab1e1e11  jmp 0x0000785DAB1E1CA0
0000785dab1e1e16  int3
0000785dab1e1e17  nop [rax+rax*1], ax
0000785dab1e1e20  mov rax, [r15+0x48]
0000785dab1e1e24  mov r14, [r15+0x50]
0000785dab1e1e28  lea r12, [r14+rax*1]
0000785dab1e1e2c  movups xmm1, [r13+r12*1]
0000785dab1e1e32  movaps [r15+0x120], xmm1
0000785dab1e1e3a  lea r14, [rax+0x10]
0000785dab1e1e3e  mov [r15+0x48], r14
0000785dab1e1e42  xor eax, eax
0000785dab1e1e44  mov r12d, 0x200
0000785dab1e1e4a  cmp r14, r12
0000785dab1e1e4d  cmc
0000785dab1e1e4e  lahf
0000785dab1e1e4f  seto al
0000785dab1e1e52  mov [r15+0x108], eax
0000785dab1e1e59  pextrq rax, xmm1, 0x01
0000785dab1e1e60  movq xmm15, rax
0000785dab1e1e65  movaps [r15+0x130], xmm15
0000785dab1e1e6d  movaps xmm14, [r15+0x110]
0000785dab1e1e75  movq rax, xmm14
0000785dab1e1e7a  movq r14, xmm1
0000785dab1e1e7f  vmovq xmm1, rax
0000785dab1e1e84  vmovq xmm14, r14
0000785dab1e1e89  movaps xmm13, xmm1
0000785dab1e1e8d  addsd xmm13, xmm14
0000785dab1e1e92  ucomisd xmm13, xmm13
0000785dab1e1e97  jp 0x0000785DAB1E1F4C
0000785dab1e1e9d  movq xmm13, xmm13
0000785dab1e1ea2  movq rax, xmm13
0000785dab1e1ea7  movq r14, xmm15
0000785dab1e1eac  vmovq xmm1, rax
0000785dab1e1eb1  vmovq xmm15, r14
0000785dab1e1eb6  movaps xmm14, xmm1
0000785dab1e1eba  addsd xmm14, xmm15
0000785dab1e1ebf  ucomisd xmm14, xmm14
0000785dab1e1ec4  jp 0x0000785DAB1E1F94
0000785dab1e1eca  movq xmm14, xmm14
0000785dab1e1ecf  movaps [r15+0x110], xmm14
0000785dab1e1ed7  mov eax, [r15+0x108]
0000785dab1e1ede  sahf
0000785dab1e1edf  jnz 0x0000785DAB1E1F11
0000785dab1e1ee1  cmp dword ptr [r15+0x318], 0x00
0000785dab1e1ee9  jz 0x0000785DAB1E1FE0
0000785dab1e1eef  nop [rax+rax*1], ax
0000785dab1e1ef8  nop [rax+rax*1], eax
0000785dab1e1f00  mov eax, 0x410490
0000785dab1e1f05  mov [r15+0x100], rax
0000785dab1e1f0c  jmp 0x0000785DAAFFE110
0000785dab1e1f11  cmp dword ptr [r15+0x318], 0x00
0000785dab1e1f19  jz 0x0000785DAB1E1E20
0000785dab1e1f1f  nop [rax+rax*1], ax
0000785dab1e1f28  nop [rax+rax*1], eax
0000785dab1e1f30  mov eax, 0x410474
0000785dab1e1f35  mov [r15+0x100], rax
0000785dab1e1f3c  jmp 0x0000785DAAFFE110
0000785dab1e1f41  int3
0000785dab1e1f42  call 0x0000785DAB0B52F0
0000785dab1e1f47  jmp 0x0000785DAB1E1E32
0000785dab1e1f4c  ucomisd xmm1, xmm14
0000785dab1e1f51  jp 0x0000785DAB1E1F60
0000785dab1e1f53  movaps xmm13, [0x0000785DAADFE060]
0000785dab1e1f5b  jmp 0x0000785DAB1E1E9D
0000785dab1e1f60  vxorps xmm0, xmm1, xmm14
0000785dab1e1f65  pextrw eax, xmm0, 0x03
0000785dab1e1f6a  and eax, 0x7FF8
0000785dab1e1f6f  cmp eax, 0x08
0000785dab1e1f72  jnz 0x0000785DAB1E1E9D
0000785dab1e1f78  movq rax, xmm14
0000785dab1e1f7d  shl rax, 0x0D
0000785dab1e1f81  jbe 0x0000785DAB1E1E9D
0000785dab1e1f87  vorps xmm13, xmm14, [0x0000785DAADFE070]
0000785dab1e1f8f  jmp 0x0000785DAB1E1E9D
0000785dab1e1f94  ucomisd xmm1, xmm15
0000785dab1e1f99  jp 0x0000785DAB1E1FA8
0000785dab1e1f9b  movaps xmm14, [0x0000785DAADFE060]
0000785dab1e1fa3  jmp 0x0000785DAB1E1ECA
0000785dab1e1fa8  vxorps xmm0, xmm1, xmm15
0000785dab1e1fad  pextrw eax, xmm0, 0x03
0000785dab1e1fb2  and eax, 0x7FF8
0000785dab1e1fb7  cmp eax, 0x08
0000785dab1e1fba  jnz 0x0000785DAB1E1ECA
0000785dab1e1fc0  movq rax, xmm15
0000785dab1e1fc5  shl rax, 0x0D
0000785dab1e1fc9  jbe 0x0000785DAB1E1ECA
0000785dab1e1fcf  vorps xmm14, xmm15, [0x0000785DAADFE070]
0000785dab1e1fd7  jmp 0x0000785DAB1E1ECA
0000785dab1e1fdc  int3
0000785dab1e1fdd  nop [rax], eax
0000785dab1e1fe0  mov rax, [r15+0x40]
0000785dab1e1fe4  lea r14, [rax+0x510]
0000785dab1e1feb  movaps xmm1, [r15+0x110]
0000785dab1e1ff3  movq rax, xmm1
0000785dab1e1ff8  mov [r13+r14*1], rax
0000785dab1e1ffd  mov rax, [r15+0xF0]
0000785dab1e2004  mov [r15+0x100], rax
0000785dab1e200b  jmp 0x0000785DAB1CE5C0
0000785dab1e2010  int3
0000785dab1e2011  call 0x0000785DAB0D5EB0
0000785dab1e2016  jmp 0x0000785DAB1E1FFD
0000785dab1e201b  int3
0000785dab1e201c  nop [rax], eax
0000785dab1e2020  mov qword ptr [r15+0x100], 0x04
0000785dab1e202b  mov esi, 0x00
0000785dab1e2030  mov edx, 0x09
0000785dab1e2035  mov rdi, 0x7FFD17670470
0000785dab1e203f  mov rax, 0x61B13BA69970
0000785dab1e2049  call rax
0000785dab1e204b  cmp dword ptr [r15+0x318], 0x00
0000785dab1e2053  jnz 0x0000785DAAFFE110
0000785dab1e2059  jmp 0x0000785DAAFFE0A0
0000785dab1e205e  int3
0000785dab1e205f  int3
