00007b2e12fce69b  nop [rax+rax*1], eax
00007b2e12fce6a0  mov qword ptr [r15+0x20], 0x420060
00007b2e12fce6a8  mov qword ptr [r15], 0x03
00007b2e12fce6af  xor eax, eax
00007b2e12fce6b1  mov r14d, 0xB71B00
00007b2e12fce6b7  mov r12d, 0x01
00007b2e12fce6bd  sub r14, r12
00007b2e12fce6c0  cmc
00007b2e12fce6c1  lahf
00007b2e12fce6c2  seto al
00007b2e12fce6c5  mov [r15+0x108], eax
00007b2e12fce6cc  mov [r15+0x08], r14
00007b2e12fce6d0  mov eax, [r15+0x108]
00007b2e12fce6d7  sahf
00007b2e12fce6d8  jnz 0x00007B2E12FCE70A
00007b2e12fce6da  cmp dword ptr [r15+0x318], 0x00
00007b2e12fce6e2  jz 0x00007B2E12FCE7F0
00007b2e12fce6e8  nop [rax+rax*1], ax
00007b2e12fce6f1  nop [rax+rax*1], eax
00007b2e12fce6f9  mov eax, 0x41004C
00007b2e12fce6fe  mov [r15+0x100], rax
00007b2e12fce705  jmp 0x00007B2E12DFE110
00007b2e12fce70a  cmp dword ptr [r15+0x318], 0x00
00007b2e12fce712  jz 0x00007B2E12FCE740
00007b2e12fce718  nop [rax+rax*1], ax
00007b2e12fce721  nop [rax+rax*1], eax
00007b2e12fce729  mov eax, 0x41003C
00007b2e12fce72e  mov [r15+0x100], rax
00007b2e12fce735  jmp 0x00007B2E12DFE110
00007b2e12fce73a  int3
00007b2e12fce73b  int3
00007b2e12fce73c  nop [rax], eax
00007b2e12fce740  mov rax, [r15]
00007b2e12fce743  lea r14, [rax+0x03]
00007b2e12fce747  mov [rsp+0x10], r14
00007b2e12fce74c  shr r14, 0x07
00007b2e12fce750  mov rax, [rsp+0x10]
00007b2e12fce755  xor rax, r14
00007b2e12fce758  mov [r15], rax
00007b2e12fce75b  mov rax, [r15+0x08]
00007b2e12fce75f  mov [rsp+0x10], rax
00007b2e12fce764  xor eax, eax
00007b2e12fce766  mov r14, [rsp+0x10]
00007b2e12fce76b  mov r12d, 0x01
00007b2e12fce771  sub r14, r12
00007b2e12fce774  cmc
00007b2e12fce775  lahf
00007b2e12fce776  seto al
00007b2e12fce779  mov [r15+0x108], eax
00007b2e12fce780  mov [r15+0x08], r14
00007b2e12fce784  mov eax, [r15+0x108]
00007b2e12fce78b  sahf
00007b2e12fce78c  jnz 0x00007B2E12FCE7BE
00007b2e12fce78e  cmp dword ptr [r15+0x318], 0x00
00007b2e12fce796  jz 0x00007B2E12FCE7F0
00007b2e12fce79c  nop [rax+rax*1], ax
00007b2e12fce7a5  nop [rax+rax*1], eax
00007b2e12fce7ad  mov eax, 0x41004C
00007b2e12fce7b2  mov [r15+0x100], rax
00007b2e12fce7b9  jmp 0x00007B2E12DFE110
00007b2e12fce7be  cmp dword ptr [r15+0x318], 0x00
00007b2e12fce7c6  jz 0x00007B2E12FCE740
00007b2e12fce7cc  nop [rax+rax*1], ax
00007b2e12fce7d5  nop [rax+rax*1], eax
00007b2e12fce7dd  mov eax, 0x41003C
00007b2e12fce7e2  mov [r15+0x100], rax
00007b2e12fce7e9  jmp 0x00007B2E12DFE110
00007b2e12fce7ee  int3
00007b2e12fce7ef  int3
00007b2e12fce7f0  mov rax, [r15+0x20]
00007b2e12fce7f4  mov r14, [r15]
00007b2e12fce7f7  mov [r13+rax*1], r14
00007b2e12fce7fc  mov rax, [r15+0xF0]
00007b2e12fce803  mov [r15+0x100], rax
00007b2e12fce80a  jmp 0x00007B2E12FCE5C0
00007b2e12fce80f  int3
00007b2e12fce810  call 0x00007B2E12E0E120
00007b2e12fce815  jmp 0x00007B2E12FCE7FC
00007b2e12fce81a  int3
00007b2e12fce81b  nop [rax+rax*1], eax
00007b2e12fce820  mov qword ptr [r15+0x100], 0x04
00007b2e12fce82b  mov esi, 0x00
00007b2e12fce830  mov edx, 0x09
00007b2e12fce835  mov rdi, 0x7FFEE025F640
00007b2e12fce83f  mov rax, 0x641F1CF0B970
00007b2e12fce849  call rax
00007b2e12fce84b  cmp dword ptr [r15+0x318], 0x00
00007b2e12fce853  jnz 0x00007B2E12DFE110
00007b2e12fce859  jmp 0x00007B2E12DFE0A0
00007b2e12fce85e  int3
00007b2e12fce85f  int3
