
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/integer/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

00007eaf9a900000 <.data>:
    7eaf9a900000:	sub    rsp,0x10
    7eaf9a900004:	mov    r13d,0x1b00
    7eaf9a90000a:	mov    r14d,0xb7
    7eaf9a900010:	and    r14d,0xffff
    7eaf9a900017:	mov    rax,r13
    7eaf9a90001a:	movabs rcx,0xffffffff0000ffff
    7eaf9a900024:	and    rax,rcx
    7eaf9a900027:	mov    rdx,r14
    7eaf9a90002a:	shl    rdx,0x10
    7eaf9a90002e:	mov    ecx,0xffff0000
    7eaf9a900033:	and    rdx,rcx
    7eaf9a900036:	or     rax,rdx
    7eaf9a900039:	mov    r15,rax
    7eaf9a90003c:	mov    QWORD PTR [r12+0x8],r15
    7eaf9a900041:	mov    r13d,0x420060
    7eaf9a900047:	mov    QWORD PTR [r12+0x20],r13
    7eaf9a90004c:	mov    r13d,0x0
    7eaf9a900052:	mov    QWORD PTR [r12],r13
    7eaf9a900056:	jmp    0x7eaf9a90005b
    7eaf9a90005b:	mov    r13,QWORD PTR [r12]
    7eaf9a90005f:	add    r13,0x3
    7eaf9a900063:	mov    r14,r13
    7eaf9a900066:	shr    r14,0x7
    7eaf9a90006a:	xor    r13,r14
    7eaf9a90006d:	mov    QWORD PTR [r12],r13
    7eaf9a900071:	mov    r13,QWORD PTR [r12+0x8]
    7eaf9a900076:	sub    r13,0x1
    7eaf9a90007a:	mov    QWORD PTR [r12+0x8],r13
    7eaf9a90007f:	mov    rcx,QWORD PTR [r12+0x380]
    7eaf9a900087:	jrcxz  0x7eaf9a90008e
    7eaf9a900089:	jmp    0x7eaf9a900106
    7eaf9a90008e:	jne    0x7eaf9a90005b
    7eaf9a900094:	mov    r11,rax
    7eaf9a900097:	lahf
    7eaf9a900098:	seto   al
    7eaf9a90009b:	mov    WORD PTR [rsp],ax
    7eaf9a90009f:	mov    rax,r11
    7eaf9a9000a2:	jmp    0x7eaf9a9000a7
    7eaf9a9000a7:	mov    r13,QWORD PTR [r12+0x20]
    7eaf9a9000ac:	mov    r14,QWORD PTR [r12]
    7eaf9a9000b0:	mov    QWORD PTR [r13+0x0],r14
    7eaf9a9000b4:	mov    r13d,0x0
    7eaf9a9000ba:	mov    DWORD PTR [r12+0x32c],r13d
    7eaf9a9000c2:	mov    rcx,QWORD PTR [r12+0x380]
    7eaf9a9000ca:	jrcxz  0x7eaf9a9000d1
    7eaf9a9000cc:	jmp    0x7eaf9a900197
    7eaf9a9000d1:	mov    r13,QWORD PTR [r12+0xf0]
    7eaf9a9000d9:	mov    QWORD PTR [r12+0x100],r13
    7eaf9a9000e1:	mov    r11,QWORD PTR [rsp]
    7eaf9a9000e5:	mov    QWORD PTR [r12+0x398],r11
    7eaf9a9000ed:	mov    rdi,QWORD PTR [r12+0x100]
    7eaf9a9000f5:	add    rsp,0x10
    7eaf9a9000f9:	movabs r11,0x61071a8c8940
    7eaf9a900103:	jmp    r11
    7eaf9a900106:	mov    eax,0x410048
    7eaf9a90010b:	mov    QWORD PTR [r12+0x100],rax
    7eaf9a900113:	push   rdx
    7eaf9a900114:	push   rsi
    7eaf9a900115:	push   r10
    7eaf9a900117:	push   r11
    7eaf9a900119:	mov    r11,rax
    7eaf9a90011c:	lahf
    7eaf9a90011d:	seto   al
    7eaf9a900120:	mov    WORD PTR [rsp+0x20],ax
    7eaf9a900125:	mov    rax,r11
    7eaf9a900128:	mov    rdx,QWORD PTR [rsp+0x20]
    7eaf9a90012d:	mov    r10d,edx
    7eaf9a900130:	and    r10d,0xc000
    7eaf9a900137:	shl    r10d,0x10
    7eaf9a90013b:	mov    r11d,edx
    7eaf9a90013e:	and    r11d,0x100
    7eaf9a900145:	shl    r11d,0x15
    7eaf9a900149:	or     r10d,r11d
    7eaf9a90014c:	and    edx,0x1
    7eaf9a90014f:	shl    edx,0x1c
    7eaf9a900152:	or     r10d,edx
    7eaf9a900155:	btc    r10,0x1d
    7eaf9a90015a:	mov    r11d,0xf0000000
    7eaf9a900160:	and    r11,r10
    7eaf9a900163:	movabs rsi,0xffffffff0fffffff
    7eaf9a90016d:	and    rbx,rsi
    7eaf9a900170:	or     rbx,r11
    7eaf9a900173:	pop    r11
    7eaf9a900175:	pop    r10
    7eaf9a900177:	pop    rsi
    7eaf9a900178:	pop    rdx
    7eaf9a900179:	mov    QWORD PTR [r12+0x108],rbx
    7eaf9a900181:	add    rsp,0x10
    7eaf9a900185:	mov    eax,0xc
    7eaf9a90018a:	movabs r11,0x61071a8c8ca0
    7eaf9a900194:	jmp    r11
    7eaf9a900197:	mov    eax,0x410050
    7eaf9a90019c:	mov    QWORD PTR [r12+0x100],rax
    7eaf9a9001a4:	push   rdx
    7eaf9a9001a5:	push   rsi
    7eaf9a9001a6:	push   r10
    7eaf9a9001a8:	push   r11
    7eaf9a9001aa:	mov    rdx,QWORD PTR [rsp+0x20]
    7eaf9a9001af:	mov    r10d,edx
    7eaf9a9001b2:	and    r10d,0xc000
    7eaf9a9001b9:	shl    r10d,0x10
    7eaf9a9001bd:	mov    r11d,edx
    7eaf9a9001c0:	and    r11d,0x100
    7eaf9a9001c7:	shl    r11d,0x15
    7eaf9a9001cb:	or     r10d,r11d
    7eaf9a9001ce:	and    edx,0x1
    7eaf9a9001d1:	shl    edx,0x1c
    7eaf9a9001d4:	or     r10d,edx
    7eaf9a9001d7:	btc    r10,0x1d
    7eaf9a9001dc:	mov    r11d,0xf0000000
    7eaf9a9001e2:	and    r11,r10
    7eaf9a9001e5:	movabs rsi,0xffffffff0fffffff
    7eaf9a9001ef:	and    rbx,rsi
    7eaf9a9001f2:	or     rbx,r11
    7eaf9a9001f5:	pop    r11
    7eaf9a9001f7:	pop    r10
    7eaf9a9001f9:	pop    rsi
    7eaf9a9001fa:	pop    rdx
    7eaf9a9001fb:	mov    QWORD PTR [r12+0x108],rbx
    7eaf9a900203:	add    rsp,0x10
    7eaf9a900207:	mov    eax,0xc
    7eaf9a90020c:	movabs r11,0x61071a8c8ca0
    7eaf9a900216:	jmp    r11
    7eaf9a900219:	nop    DWORD PTR [rax+0x0]
    7eaf9a900220:	sub    rsp,0x10
    7eaf9a900224:	jmp    0x7eaf9a90005b
    7eaf9a900229:	nop    DWORD PTR [rax+0x0]
    7eaf9a900230:	sub    rsp,0x10
    7eaf9a900234:	mov    r11,QWORD PTR [r12+0x398]
    7eaf9a90023c:	mov    QWORD PTR [rsp],r11
    7eaf9a900240:	jmp    0x7eaf9a9000a7
    7eaf9a900245:	nop
    7eaf9a900246:	nop
    7eaf9a900247:	nop
