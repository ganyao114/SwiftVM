
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/integer/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

00007654eb700000 <.data>:
    7654eb700000:	sub    rsp,0x10
    7654eb700004:	mov    r13d,0x1b00
    7654eb70000a:	mov    r14d,0xb7
    7654eb700010:	and    r14d,0xffff
    7654eb700017:	mov    rax,r13
    7654eb70001a:	movabs rcx,0xffffffff0000ffff
    7654eb700024:	and    rax,rcx
    7654eb700027:	mov    rdx,r14
    7654eb70002a:	shl    rdx,0x10
    7654eb70002e:	mov    ecx,0xffff0000
    7654eb700033:	and    rdx,rcx
    7654eb700036:	or     rax,rdx
    7654eb700039:	mov    r15,rax
    7654eb70003c:	mov    QWORD PTR [r12+0x8],r15
    7654eb700041:	mov    r13d,0x420060
    7654eb700047:	mov    QWORD PTR [r12+0x20],r13
    7654eb70004c:	mov    r13d,0x0
    7654eb700052:	mov    QWORD PTR [r12],r13
    7654eb700056:	jmp    0x7654eb70005b
    7654eb70005b:	mov    r13,QWORD PTR [r12]
    7654eb70005f:	add    r13,0x3
    7654eb700063:	mov    r14,r13
    7654eb700066:	shr    r14,0x7
    7654eb70006a:	xor    r13,r14
    7654eb70006d:	mov    QWORD PTR [r12],r13
    7654eb700071:	mov    r13,QWORD PTR [r12+0x8]
    7654eb700076:	sub    r13,0x1
    7654eb70007a:	mov    QWORD PTR [r12+0x8],r13
    7654eb70007f:	mov    rcx,QWORD PTR [r12+0x380]
    7654eb700087:	jrcxz  0x7654eb70008e
    7654eb700089:	jmp    0x7654eb700106
    7654eb70008e:	jne    0x7654eb70005b
    7654eb700094:	mov    r11,rax
    7654eb700097:	lahf
    7654eb700098:	seto   al
    7654eb70009b:	mov    WORD PTR [rsp],ax
    7654eb70009f:	mov    rax,r11
    7654eb7000a2:	jmp    0x7654eb7000a7
    7654eb7000a7:	mov    r13,QWORD PTR [r12+0x20]
    7654eb7000ac:	mov    r14,QWORD PTR [r12]
    7654eb7000b0:	mov    QWORD PTR [r13+0x0],r14
    7654eb7000b4:	mov    r13d,0x0
    7654eb7000ba:	mov    DWORD PTR [r12+0x32c],r13d
    7654eb7000c2:	mov    rcx,QWORD PTR [r12+0x380]
    7654eb7000ca:	jrcxz  0x7654eb7000d1
    7654eb7000cc:	jmp    0x7654eb700197
    7654eb7000d1:	mov    r13,QWORD PTR [r12+0xf0]
    7654eb7000d9:	mov    QWORD PTR [r12+0x100],r13
    7654eb7000e1:	mov    r11,QWORD PTR [rsp]
    7654eb7000e5:	mov    QWORD PTR [r12+0x398],r11
    7654eb7000ed:	mov    rdi,QWORD PTR [r12+0x100]
    7654eb7000f5:	add    rsp,0x10
    7654eb7000f9:	movabs r11,0x58d121fa3940
    7654eb700103:	jmp    r11
    7654eb700106:	mov    eax,0x410048
    7654eb70010b:	mov    QWORD PTR [r12+0x100],rax
    7654eb700113:	push   rdx
    7654eb700114:	push   rsi
    7654eb700115:	push   r10
    7654eb700117:	push   r11
    7654eb700119:	mov    r11,rax
    7654eb70011c:	lahf
    7654eb70011d:	seto   al
    7654eb700120:	mov    WORD PTR [rsp+0x20],ax
    7654eb700125:	mov    rax,r11
    7654eb700128:	mov    rdx,QWORD PTR [rsp+0x20]
    7654eb70012d:	mov    r10d,edx
    7654eb700130:	and    r10d,0xc000
    7654eb700137:	shl    r10d,0x10
    7654eb70013b:	mov    r11d,edx
    7654eb70013e:	and    r11d,0x100
    7654eb700145:	shl    r11d,0x15
    7654eb700149:	or     r10d,r11d
    7654eb70014c:	and    edx,0x1
    7654eb70014f:	shl    edx,0x1c
    7654eb700152:	or     r10d,edx
    7654eb700155:	btc    r10,0x1d
    7654eb70015a:	mov    r11d,0xf0000000
    7654eb700160:	and    r11,r10
    7654eb700163:	movabs rsi,0xffffffff0fffffff
    7654eb70016d:	and    rbx,rsi
    7654eb700170:	or     rbx,r11
    7654eb700173:	pop    r11
    7654eb700175:	pop    r10
    7654eb700177:	pop    rsi
    7654eb700178:	pop    rdx
    7654eb700179:	mov    QWORD PTR [r12+0x108],rbx
    7654eb700181:	add    rsp,0x10
    7654eb700185:	mov    eax,0xc
    7654eb70018a:	movabs r11,0x58d121fa3ca0
    7654eb700194:	jmp    r11
    7654eb700197:	mov    eax,0x410050
    7654eb70019c:	mov    QWORD PTR [r12+0x100],rax
    7654eb7001a4:	push   rdx
    7654eb7001a5:	push   rsi
    7654eb7001a6:	push   r10
    7654eb7001a8:	push   r11
    7654eb7001aa:	mov    rdx,QWORD PTR [rsp+0x20]
    7654eb7001af:	mov    r10d,edx
    7654eb7001b2:	and    r10d,0xc000
    7654eb7001b9:	shl    r10d,0x10
    7654eb7001bd:	mov    r11d,edx
    7654eb7001c0:	and    r11d,0x100
    7654eb7001c7:	shl    r11d,0x15
    7654eb7001cb:	or     r10d,r11d
    7654eb7001ce:	and    edx,0x1
    7654eb7001d1:	shl    edx,0x1c
    7654eb7001d4:	or     r10d,edx
    7654eb7001d7:	btc    r10,0x1d
    7654eb7001dc:	mov    r11d,0xf0000000
    7654eb7001e2:	and    r11,r10
    7654eb7001e5:	movabs rsi,0xffffffff0fffffff
    7654eb7001ef:	and    rbx,rsi
    7654eb7001f2:	or     rbx,r11
    7654eb7001f5:	pop    r11
    7654eb7001f7:	pop    r10
    7654eb7001f9:	pop    rsi
    7654eb7001fa:	pop    rdx
    7654eb7001fb:	mov    QWORD PTR [r12+0x108],rbx
    7654eb700203:	add    rsp,0x10
    7654eb700207:	mov    eax,0xc
    7654eb70020c:	movabs r11,0x58d121fa3ca0
    7654eb700216:	jmp    r11
    7654eb700219:	nop    DWORD PTR [rax+0x0]
    7654eb700220:	sub    rsp,0x10
    7654eb700224:	jmp    0x7654eb70005b
    7654eb700229:	nop    DWORD PTR [rax+0x0]
    7654eb700230:	sub    rsp,0x10
    7654eb700234:	mov    r11,QWORD PTR [r12+0x398]
    7654eb70023c:	mov    QWORD PTR [rsp],r11
    7654eb700240:	jmp    0x7654eb7000a7
    7654eb700245:	nop
    7654eb700246:	nop
    7654eb700247:	nop
