
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/integer/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

000072665f900000 <.data>:
    72665f900000:	sub    rsp,0x10
    72665f900004:	mov    r13d,0x1b00
    72665f90000a:	mov    r14d,0xb7
    72665f900010:	and    r14d,0xffff
    72665f900017:	mov    rax,r13
    72665f90001a:	movabs rcx,0xffffffff0000ffff
    72665f900024:	and    rax,rcx
    72665f900027:	mov    rdx,r14
    72665f90002a:	shl    rdx,0x10
    72665f90002e:	mov    ecx,0xffff0000
    72665f900033:	and    rdx,rcx
    72665f900036:	or     rax,rdx
    72665f900039:	mov    r15,rax
    72665f90003c:	mov    QWORD PTR [r12+0x8],r15
    72665f900041:	mov    r13d,0x420060
    72665f900047:	mov    QWORD PTR [r12+0x20],r13
    72665f90004c:	mov    r13d,0x0
    72665f900052:	mov    QWORD PTR [r12],r13
    72665f900056:	jmp    0x72665f90005b
    72665f90005b:	mov    r13,QWORD PTR [r12]
    72665f90005f:	add    r13,0x3
    72665f900063:	mov    r14,r13
    72665f900066:	shr    r14,0x7
    72665f90006a:	xor    r13,r14
    72665f90006d:	mov    QWORD PTR [r12],r13
    72665f900071:	mov    r13,QWORD PTR [r12+0x8]
    72665f900076:	sub    r13,0x1
    72665f90007a:	mov    QWORD PTR [r12+0x8],r13
    72665f90007f:	mov    rcx,QWORD PTR [r12+0x380]
    72665f900087:	jrcxz  0x72665f90008e
    72665f900089:	jmp    0x72665f900106
    72665f90008e:	jne    0x72665f90005b
    72665f900094:	mov    r11,rax
    72665f900097:	lahf
    72665f900098:	seto   al
    72665f90009b:	mov    WORD PTR [rsp],ax
    72665f90009f:	mov    rax,r11
    72665f9000a2:	jmp    0x72665f9000a7
    72665f9000a7:	mov    r13,QWORD PTR [r12+0x20]
    72665f9000ac:	mov    r14,QWORD PTR [r12]
    72665f9000b0:	mov    QWORD PTR [r13+0x0],r14
    72665f9000b4:	mov    r13d,0x0
    72665f9000ba:	mov    DWORD PTR [r12+0x32c],r13d
    72665f9000c2:	mov    rcx,QWORD PTR [r12+0x380]
    72665f9000ca:	jrcxz  0x72665f9000d1
    72665f9000cc:	jmp    0x72665f900197
    72665f9000d1:	mov    r13,QWORD PTR [r12+0xf0]
    72665f9000d9:	mov    QWORD PTR [r12+0x100],r13
    72665f9000e1:	mov    r11,QWORD PTR [rsp]
    72665f9000e5:	mov    QWORD PTR [r12+0x398],r11
    72665f9000ed:	mov    rdi,QWORD PTR [r12+0x100]
    72665f9000f5:	add    rsp,0x10
    72665f9000f9:	movabs r11,0x5a3e51bef940
    72665f900103:	jmp    r11
    72665f900106:	mov    eax,0x410048
    72665f90010b:	mov    QWORD PTR [r12+0x100],rax
    72665f900113:	push   rdx
    72665f900114:	push   rsi
    72665f900115:	push   r10
    72665f900117:	push   r11
    72665f900119:	mov    r11,rax
    72665f90011c:	lahf
    72665f90011d:	seto   al
    72665f900120:	mov    WORD PTR [rsp+0x20],ax
    72665f900125:	mov    rax,r11
    72665f900128:	mov    rdx,QWORD PTR [rsp+0x20]
    72665f90012d:	mov    r10d,edx
    72665f900130:	and    r10d,0xc000
    72665f900137:	shl    r10d,0x10
    72665f90013b:	mov    r11d,edx
    72665f90013e:	and    r11d,0x100
    72665f900145:	shl    r11d,0x15
    72665f900149:	or     r10d,r11d
    72665f90014c:	and    edx,0x1
    72665f90014f:	shl    edx,0x1c
    72665f900152:	or     r10d,edx
    72665f900155:	btc    r10,0x1d
    72665f90015a:	mov    r11d,0xf0000000
    72665f900160:	and    r11,r10
    72665f900163:	movabs rsi,0xffffffff0fffffff
    72665f90016d:	and    rbx,rsi
    72665f900170:	or     rbx,r11
    72665f900173:	pop    r11
    72665f900175:	pop    r10
    72665f900177:	pop    rsi
    72665f900178:	pop    rdx
    72665f900179:	mov    QWORD PTR [r12+0x108],rbx
    72665f900181:	add    rsp,0x10
    72665f900185:	mov    eax,0xc
    72665f90018a:	movabs r11,0x5a3e51befca0
    72665f900194:	jmp    r11
    72665f900197:	mov    eax,0x410050
    72665f90019c:	mov    QWORD PTR [r12+0x100],rax
    72665f9001a4:	push   rdx
    72665f9001a5:	push   rsi
    72665f9001a6:	push   r10
    72665f9001a8:	push   r11
    72665f9001aa:	mov    rdx,QWORD PTR [rsp+0x20]
    72665f9001af:	mov    r10d,edx
    72665f9001b2:	and    r10d,0xc000
    72665f9001b9:	shl    r10d,0x10
    72665f9001bd:	mov    r11d,edx
    72665f9001c0:	and    r11d,0x100
    72665f9001c7:	shl    r11d,0x15
    72665f9001cb:	or     r10d,r11d
    72665f9001ce:	and    edx,0x1
    72665f9001d1:	shl    edx,0x1c
    72665f9001d4:	or     r10d,edx
    72665f9001d7:	btc    r10,0x1d
    72665f9001dc:	mov    r11d,0xf0000000
    72665f9001e2:	and    r11,r10
    72665f9001e5:	movabs rsi,0xffffffff0fffffff
    72665f9001ef:	and    rbx,rsi
    72665f9001f2:	or     rbx,r11
    72665f9001f5:	pop    r11
    72665f9001f7:	pop    r10
    72665f9001f9:	pop    rsi
    72665f9001fa:	pop    rdx
    72665f9001fb:	mov    QWORD PTR [r12+0x108],rbx
    72665f900203:	add    rsp,0x10
    72665f900207:	mov    eax,0xc
    72665f90020c:	movabs r11,0x5a3e51befca0
    72665f900216:	jmp    r11
    72665f900219:	nop    DWORD PTR [rax+0x0]
    72665f900220:	sub    rsp,0x10
    72665f900224:	jmp    0x72665f90005b
    72665f900229:	nop    DWORD PTR [rax+0x0]
    72665f900230:	sub    rsp,0x10
    72665f900234:	mov    r11,QWORD PTR [r12+0x398]
    72665f90023c:	mov    QWORD PTR [rsp],r11
    72665f900240:	jmp    0x72665f9000a7
    72665f900245:	nop
    72665f900246:	nop
    72665f900247:	nop
