0000735e0bbce69b  nop [rax+rax*1], eax
0000735e0bbce6a0  mov qword ptr [r15+0x20], 0x420060
0000735e0bbce6a8  mov qword ptr [r15], 0x03
0000735e0bbce6af  xor eax, eax
0000735e0bbce6b1  mov r14d, 0xB71B00
0000735e0bbce6b7  mov r12d, 0x01
0000735e0bbce6bd  sub r14, r12
0000735e0bbce6c0  cmc
0000735e0bbce6c1  lahf
0000735e0bbce6c2  seto al
0000735e0bbce6c5  mov [r15+0x108], eax
0000735e0bbce6cc  mov [r15+0x08], r14
0000735e0bbce6d0  mov eax, [r15+0x108]
0000735e0bbce6d7  sahf
0000735e0bbce6d8  jnz 0x0000735E0BBCE70A
0000735e0bbce6da  cmp dword ptr [r15+0x318], 0x00
0000735e0bbce6e2  jz 0x0000735E0BBCE7F0
0000735e0bbce6e8  nop [rax+rax*1], ax
0000735e0bbce6f1  nop [rax+rax*1], eax
0000735e0bbce6f9  mov eax, 0x41004C
0000735e0bbce6fe  mov [r15+0x100], rax
0000735e0bbce705  jmp 0x0000735E0B9FE110
0000735e0bbce70a  cmp dword ptr [r15+0x318], 0x00
0000735e0bbce712  jz 0x0000735E0BBCE740
0000735e0bbce718  nop [rax+rax*1], ax
0000735e0bbce721  nop [rax+rax*1], eax
0000735e0bbce729  mov eax, 0x41003C
0000735e0bbce72e  mov [r15+0x100], rax
0000735e0bbce735  jmp 0x0000735E0B9FE110
0000735e0bbce73a  int3
0000735e0bbce73b  int3
0000735e0bbce73c  nop [rax], eax
0000735e0bbce740  mov rax, [r15]
0000735e0bbce743  lea r14, [rax+0x03]
0000735e0bbce747  mov [rsp+0x10], r14
0000735e0bbce74c  shr r14, 0x07
0000735e0bbce750  mov rax, [rsp+0x10]
0000735e0bbce755  xor rax, r14
0000735e0bbce758  mov [r15], rax
0000735e0bbce75b  mov rax, [r15+0x08]
0000735e0bbce75f  mov [rsp+0x10], rax
0000735e0bbce764  xor eax, eax
0000735e0bbce766  mov r14, [rsp+0x10]
0000735e0bbce76b  mov r12d, 0x01
0000735e0bbce771  sub r14, r12
0000735e0bbce774  cmc
0000735e0bbce775  lahf
0000735e0bbce776  seto al
0000735e0bbce779  mov [r15+0x108], eax
0000735e0bbce780  mov [r15+0x08], r14
0000735e0bbce784  mov eax, [r15+0x108]
0000735e0bbce78b  sahf
0000735e0bbce78c  jnz 0x0000735E0BBCE7BE
0000735e0bbce78e  cmp dword ptr [r15+0x318], 0x00
0000735e0bbce796  jz 0x0000735E0BBCE7F0
0000735e0bbce79c  nop [rax+rax*1], ax
0000735e0bbce7a5  nop [rax+rax*1], eax
0000735e0bbce7ad  mov eax, 0x41004C
0000735e0bbce7b2  mov [r15+0x100], rax
0000735e0bbce7b9  jmp 0x0000735E0B9FE110
0000735e0bbce7be  cmp dword ptr [r15+0x318], 0x00
0000735e0bbce7c6  jz 0x0000735E0BBCE740
0000735e0bbce7cc  nop [rax+rax*1], ax
0000735e0bbce7d5  nop [rax+rax*1], eax
0000735e0bbce7dd  mov eax, 0x41003C
0000735e0bbce7e2  mov [r15+0x100], rax
0000735e0bbce7e9  jmp 0x0000735E0B9FE110
0000735e0bbce7ee  int3
0000735e0bbce7ef  int3
0000735e0bbce7f0  mov rax, [r15+0x20]
0000735e0bbce7f4  mov r14, [r15]
0000735e0bbce7f7  mov [r13+rax*1], r14
0000735e0bbce7fc  mov rax, [r15+0xF0]
0000735e0bbce803  mov [r15+0x100], rax
0000735e0bbce80a  jmp 0x0000735E0BBCE5C0
0000735e0bbce80f  int3
0000735e0bbce810  call 0x0000735E0BA0E120
0000735e0bbce815  jmp 0x0000735E0BBCE7FC
0000735e0bbce81a  int3
0000735e0bbce81b  nop [rax+rax*1], eax
0000735e0bbce820  mov qword ptr [r15+0x100], 0x04
0000735e0bbce82b  mov esi, 0x00
0000735e0bbce830  mov edx, 0x09
0000735e0bbce835  mov rdi, 0x7FFFE72E1880
0000735e0bbce83f  mov rax, 0x63A2BAB38970
0000735e0bbce849  call rax
0000735e0bbce84b  cmp dword ptr [r15+0x318], 0x00
0000735e0bbce853  jnz 0x0000735E0B9FE110
0000735e0bbce859  jmp 0x0000735E0B9FE0A0
0000735e0bbce85e  int3
0000735e0bbce85f  int3
