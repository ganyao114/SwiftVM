
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/2/3.bin:     file format binary


Disassembly of section .data:

0000730a04100e10 <.data>:
    730a04100e10:	sub    rsp,0x10
    730a04100e14:	mov    r11,QWORD PTR [r12+0x398]
    730a04100e1c:	mov    QWORD PTR [rsp],r11
    730a04100e20:	mov    r13,QWORD PTR [r12+0xf8]
    730a04100e28:	mov    r14,r13
    730a04100e2b:	add    r14,0x168
    730a04100e32:	mov    r15,QWORD PTR [r14]
    730a04100e35:	mov    QWORD PTR [r12+0x40],r15
    730a04100e3a:	add    r13,0x178
    730a04100e41:	mov    r14d,0x0
    730a04100e47:	mov    BYTE PTR [r13+0x0],r14b
    730a04100e4b:	mov    r13d,0x0
    730a04100e51:	mov    DWORD PTR [r12+0x32c],r13d
    730a04100e59:	sub    r15,0x38
    730a04100e5d:	je     0x730a04100e76
    730a04100e63:	mov    r11,rax
    730a04100e66:	lahf
    730a04100e67:	seto   al
    730a04100e6a:	mov    WORD PTR [rsp],ax
    730a04100e6e:	mov    rax,r11
    730a04100e71:	jmp    0x730a04100e89
    730a04100e76:	mov    r11,rax
    730a04100e79:	lahf
    730a04100e7a:	seto   al
    730a04100e7d:	mov    WORD PTR [rsp],ax
    730a04100e81:	mov    rax,r11
    730a04100e84:	jmp    0x730a04100f15
    730a04100e89:	mov    r13,QWORD PTR [r12+0xf8]
    730a04100e91:	mov    r14,r13
    730a04100e94:	add    r14,0x100
    730a04100e9b:	mov    QWORD PTR [r12],r14
    730a04100e9f:	add    r13,0x178
    730a04100ea6:	mov    QWORD PTR [r12+0x8],r13
    730a04100eab:	mov    r13d,0x1
    730a04100eb1:	mov    QWORD PTR [r12+0x10],r13
    730a04100eb6:	mov    r13d,0x4102c8
    730a04100ebc:	mov    QWORD PTR [r12+0xf0],r13
    730a04100ec4:	mov    r13d,0x410728
    730a04100eca:	mov    QWORD PTR [r12+0x100],r13
    730a04100ed2:	mov    r11,QWORD PTR [rsp]
    730a04100ed6:	mov    QWORD PTR [r12+0x398],r11
    730a04100ede:	mov    edi,0x410728
    730a04100ee3:	mov    QWORD PTR [r12+0x100],rdi
    730a04100eeb:	add    rsp,0x10
    730a04100eef:	nop
    730a04100ef0:	jmp    QWORD PTR [rip+0x2]        # 0x730a04100ef8
    730a04100ef6:	xchg   ax,ax
    730a04100ef8:	loopne 0x730a04100edf
    730a04100efa:	(bad)
    730a04100efc:	or     dh,BYTE PTR [rbx+0x0]
    730a04100eff:	add    BYTE PTR [rax],cl
    730a04100f01:	movups xmm0,XMMWORD PTR [rdx+rcx*1]
    730a04100f05:	jae    0x730a04100f07
    730a04100f07:	add    BYTE PTR [rcx-0x45],cl
    730a04100f0a:	rex leave
    730a04100f0c:	ret    0x91a9
    730a04100f0f:	push   rbp
    730a04100f10:	add    BYTE PTR [rax],al
    730a04100f12:	jmp    r11
    730a04100f15:	mov    r13,QWORD PTR [r12+0x98]
    730a04100f1d:	ror    r13,0x3d
    730a04100f21:	and    r13,0xfffffffffffffff8
    730a04100f25:	mov    r14,QWORD PTR [r12+0xf8]
    730a04100f2d:	mov    r15,r14
    730a04100f30:	add    r15,0x100
    730a04100f37:	mov    QWORD PTR [r12],r15
    730a04100f3b:	mov    r15,r14
    730a04100f3e:	add    r15,0x170
    730a04100f45:	mov    QWORD PTR [r12+0x8],r15
    730a04100f4a:	mov    r15d,0x8
    730a04100f50:	mov    QWORD PTR [r12+0x10],r15
    730a04100f55:	movabs rcx,0xff00ff00ff00ff
    730a04100f5f:	mov    r15,r13
    730a04100f62:	and    r15,rcx
    730a04100f65:	shl    r15,0x8
    730a04100f69:	movabs rcx,0xff00ff00ff00ff00
    730a04100f73:	and    r13,rcx
    730a04100f76:	shr    r13,0x8
    730a04100f7a:	or     r13,r15
    730a04100f7d:	movabs rcx,0xffff0000ffff
    730a04100f87:	mov    r15,r13
    730a04100f8a:	and    r15,rcx
    730a04100f8d:	shl    r15,0x10
    730a04100f91:	movabs rcx,0xffff0000ffff0000
    730a04100f9b:	and    r13,rcx
    730a04100f9e:	shr    r13,0x10
    730a04100fa2:	or     r13,r15
    730a04100fa5:	mov    r15,r13
    730a04100fa8:	shl    r15,0x20
    730a04100fac:	shr    r13,0x20
    730a04100fb0:	or     r13,r15
    730a04100fb3:	mov    QWORD PTR [r12+0x40],r13
    730a04100fb8:	add    r14,0x170
    730a04100fbf:	mov    QWORD PTR [r14],r13
    730a04100fc2:	mov    r13d,0x0
    730a04100fc8:	mov    DWORD PTR [r12+0x32c],r13d
    730a04100fd0:	mov    r13d,0x4102f0
    730a04100fd6:	mov    QWORD PTR [r12+0xf0],r13
    730a04100fde:	mov    r13d,0x410728
    730a04100fe4:	mov    QWORD PTR [r12+0x100],r13
    730a04100fec:	mov    r11,QWORD PTR [rsp]
    730a04100ff0:	mov    QWORD PTR [r12+0x398],r11
    730a04100ff8:	mov    edi,0x410728
    730a04100ffd:	mov    QWORD PTR [r12+0x100],rdi
    730a04101005:	add    rsp,0x10
    730a04101009:	nop    DWORD PTR [rax+0x0]
    730a04101010:	jmp    QWORD PTR [rip+0x2]        # 0x730a04101018
    730a04101016:	xchg   ax,ax
    730a04101018:	loopne 0x730a04100fff
    730a0410101a:	(bad)
    730a0410101c:	or     dh,BYTE PTR [rbx+0x0]
    730a0410101f:	add    BYTE PTR [rax],ch
    730a04101021:	adc    BYTE PTR [rax],dl
    730a04101023:	add    al,0xa
    730a04101025:	jae    0x730a04101027
    730a04101027:	add    BYTE PTR [rcx-0x45],cl
    730a0410102a:	rex leave
    730a0410102c:	ret    0x91a9
    730a0410102f:	push   rbp
    730a04101030:	add    BYTE PTR [rax],al
    730a04101032:	jmp    r11
    730a04101035:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04101040:	sub    rsp,0x10
    730a04101044:	mov    r11,QWORD PTR [r12+0x398]
    730a0410104c:	mov    QWORD PTR [rsp],r11
    730a04101050:	jmp    0x730a04100e89
    730a04101055:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04101060:	sub    rsp,0x10
    730a04101064:	mov    r11,QWORD PTR [r12+0x398]
    730a0410106c:	mov    QWORD PTR [rsp],r11
    730a04101070:	jmp    0x730a04100f15
    730a04101075:	nop
    730a04101076:	nop
    730a04101077:	nop
