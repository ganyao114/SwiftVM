
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/1/2.bin:     file format binary


Disassembly of section .data:

00007c479db00b80 <.data>:
    7c479db00b80:	sub    rsp,0x10
    7c479db00b84:	mov    r13d,DWORD PTR [r12+0xa0]
    7c479db00b8c:	sub    r13d,0x1
    7c479db00b90:	mov    QWORD PTR [r12+0xa0],r13
    7c479db00b98:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db00ba0:	jrcxz  0x7c479db00ba7
    7c479db00ba2:	jmp    0x7c479db00d3d
    7c479db00ba7:	jne    0x7c479db00bc0
    7c479db00bad:	mov    r11,rax
    7c479db00bb0:	lahf
    7c479db00bb1:	seto   al
    7c479db00bb4:	mov    WORD PTR [rsp],ax
    7c479db00bb8:	mov    rax,r11
    7c479db00bbb:	jmp    0x7c479db00bd3
    7c479db00bc0:	mov    r11,rax
    7c479db00bc3:	lahf
    7c479db00bc4:	seto   al
    7c479db00bc7:	mov    WORD PTR [rsp],ax
    7c479db00bcb:	mov    rax,r11
    7c479db00bce:	jmp    0x7c479db00ca5
    7c479db00bd3:	mov    r13,QWORD PTR [r12+0xf8]
    7c479db00bdb:	mov    r14,r13
    7c479db00bde:	add    r14,0x120
    7c479db00be5:	mov    r15,QWORD PTR [r14]
    7c479db00be8:	mov    QWORD PTR [r12+0x98],r15
    7c479db00bf0:	mov    r14d,0x80
    7c479db00bf6:	mov    QWORD PTR [r12+0x40],r14
    7c479db00bfb:	mov    r14,r13
    7c479db00bfe:	add    r14,0x100
    7c479db00c05:	mov    QWORD PTR [r12],r14
    7c479db00c09:	mov    r14,r13
    7c479db00c0c:	add    r14,0x17c
    7c479db00c13:	mov    QWORD PTR [r12+0x8],r14
    7c479db00c18:	mov    r14d,0x1
    7c479db00c1e:	mov    QWORD PTR [r12+0x10],r14
    7c479db00c23:	add    r13,0x17c
    7c479db00c2a:	movzx  r14d,BYTE PTR [r12+0x40]
    7c479db00c30:	mov    BYTE PTR [r13+0x0],r14b
    7c479db00c34:	mov    r13d,0x0
    7c479db00c3a:	mov    DWORD PTR [r12+0x32c],r13d
    7c479db00c42:	mov    r13d,0x4102a8
    7c479db00c48:	mov    QWORD PTR [r12+0xf0],r13
    7c479db00c50:	mov    r13d,0x410728
    7c479db00c56:	mov    QWORD PTR [r12+0x100],r13
    7c479db00c5e:	mov    r11,QWORD PTR [rsp]
    7c479db00c62:	mov    QWORD PTR [r12+0x398],r11
    7c479db00c6a:	mov    edi,0x410728
    7c479db00c6f:	mov    QWORD PTR [r12+0x100],rdi
    7c479db00c77:	add    rsp,0x10
    7c479db00c7b:	nop    DWORD PTR [rax+rax*1+0x0]
    7c479db00c80:	jmp    QWORD PTR [rip+0x2]        # 0x7c479db00c88
    7c479db00c86:	xchg   ax,ax
    7c479db00c88:	loopne 0x7c479db00c6f
    7c479db00c8a:	scas   eax,DWORD PTR es:[rdi]
    7c479db00c8b:	popf
    7c479db00c8c:	rex.RXB jl 0x7c479db00c8f
    7c479db00c8f:	add    BYTE PTR [rax+0x479db00c],bl
    7c479db00c95:	jl     0x7c479db00c97
    7c479db00c97:	add    BYTE PTR [rcx-0x45],cl
    7c479db00c9a:	rex jns 0x7c479db00ccf
    7c479db00c9d:	xchg   esi,edi
    7c479db00c9f:	(bad)
    7c479db00ca0:	add    BYTE PTR [rax],al
    7c479db00ca2:	jmp    r11
    7c479db00ca5:	mov    r13,QWORD PTR [r12+0xf8]
    7c479db00cad:	add    r13,0x100
    7c479db00cb4:	mov    QWORD PTR [r12],r13
    7c479db00cb8:	mov    r13d,0x0
    7c479db00cbe:	mov    r14,QWORD PTR [r12+0x98]
    7c479db00cc6:	or     r13,r14
    7c479db00cc9:	mov    QWORD PTR [r12+0x8],r13
    7c479db00cce:	mov    r13d,0x12c
    7c479db00cd4:	mov    QWORD PTR [r12+0x10],r13
    7c479db00cd9:	mov    r13d,0x410284
    7c479db00cdf:	mov    QWORD PTR [r12+0xf0],r13
    7c479db00ce7:	mov    r13d,0x410728
    7c479db00ced:	mov    QWORD PTR [r12+0x100],r13
    7c479db00cf5:	mov    r11,QWORD PTR [rsp]
    7c479db00cf9:	mov    QWORD PTR [r12+0x398],r11
    7c479db00d01:	mov    edi,0x410728
    7c479db00d06:	mov    QWORD PTR [r12+0x100],rdi
    7c479db00d0e:	add    rsp,0x10
    7c479db00d12:	nop    WORD PTR [rax+rax*1+0x0]
    7c479db00d18:	jmp    QWORD PTR [rip+0x2]        # 0x7c479db00d20
    7c479db00d1e:	xchg   ax,ax
    7c479db00d20:	loopne 0x7c479db00d07
    7c479db00d22:	scas   eax,DWORD PTR es:[rdi]
    7c479db00d23:	popf
    7c479db00d24:	rex.RXB jl 0x7c479db00d27
    7c479db00d27:	add    BYTE PTR [rax],dh
    7c479db00d29:	or     eax,0x7c479db0
    7c479db00d2e:	add    BYTE PTR [rax],al
    7c479db00d30:	movabs r11,0x62fe87327940
    7c479db00d3a:	jmp    r11
    7c479db00d3d:	mov    eax,0x410288
    7c479db00d42:	mov    QWORD PTR [r12+0x100],rax
    7c479db00d4a:	push   rdx
    7c479db00d4b:	push   rsi
    7c479db00d4c:	push   r10
    7c479db00d4e:	push   r11
    7c479db00d50:	mov    r11,rax
    7c479db00d53:	lahf
    7c479db00d54:	seto   al
    7c479db00d57:	mov    WORD PTR [rsp+0x20],ax
    7c479db00d5c:	mov    rax,r11
    7c479db00d5f:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db00d64:	mov    r10d,edx
    7c479db00d67:	and    r10d,0xc000
    7c479db00d6e:	shl    r10d,0x10
    7c479db00d72:	mov    r11d,edx
    7c479db00d75:	and    r11d,0x100
    7c479db00d7c:	shl    r11d,0x15
    7c479db00d80:	or     r10d,r11d
    7c479db00d83:	and    edx,0x1
    7c479db00d86:	shl    edx,0x1c
    7c479db00d89:	or     r10d,edx
    7c479db00d8c:	btc    r10,0x1d
    7c479db00d91:	mov    r11d,0xf0000000
    7c479db00d97:	and    r11,r10
    7c479db00d9a:	movabs rsi,0xffffffff0fffffff
    7c479db00da4:	and    rbx,rsi
    7c479db00da7:	or     rbx,r11
    7c479db00daa:	pop    r11
    7c479db00dac:	pop    r10
    7c479db00dae:	pop    rsi
    7c479db00daf:	pop    rdx
    7c479db00db0:	mov    QWORD PTR [r12+0x108],rbx
    7c479db00db8:	add    rsp,0x10
    7c479db00dbc:	mov    eax,0xc
    7c479db00dc1:	movabs r11,0x62fe87327ca0
    7c479db00dcb:	jmp    r11
    7c479db00dce:	xchg   ax,ax
    7c479db00dd0:	sub    rsp,0x10
    7c479db00dd4:	mov    r11,QWORD PTR [r12+0x398]
    7c479db00ddc:	mov    QWORD PTR [rsp],r11
    7c479db00de0:	jmp    0x7c479db00bd3
    7c479db00de5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db00df0:	sub    rsp,0x10
    7c479db00df4:	mov    r11,QWORD PTR [r12+0x398]
    7c479db00dfc:	mov    QWORD PTR [rsp],r11
    7c479db00e00:	jmp    0x7c479db00ca5
    7c479db00e05:	nop
    7c479db00e06:	nop
    7c479db00e07:	nop
