
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

00007c479dafe000 <.data>:
    7c479dafe000:	sub    rsp,0x10
    7c479dafe004:	mov    r11,QWORD PTR [r12+0x398]
    7c479dafe00c:	mov    QWORD PTR [rsp],r11
    7c479dafe010:	mov    r13,QWORD PTR [r12+0xf8]
    7c479dafe018:	sub    r13,0x1e0
    7c479dafe01f:	mov    QWORD PTR [r12+0xf8],r13
    7c479dafe027:	mov    r14d,0x420000
    7c479dafe02d:	mov    QWORD PTR [r12+0x40],r14
    7c479dafe032:	mov    r14d,0x420000
    7c479dafe038:	mov    QWORD PTR [r12+0x48],r14
    7c479dafe03d:	mov    r14,r13
    7c479dafe040:	add    r14,0x1d0
    7c479dafe047:	mov    r15,r14
    7c479dafe04a:	add    r15,0x8
    7c479dafe04e:	mov    rbp,QWORD PTR [r12+0xa0]
    7c479dafe056:	mov    r8,QWORD PTR [r12+0x98]
    7c479dafe05e:	mov    QWORD PTR [r14],rbp
    7c479dafe061:	mov    r14d,0x0
    7c479dafe067:	mov    DWORD PTR [r12+0x32c],r14d
    7c479dafe06f:	mov    QWORD PTR [r15],r8
    7c479dafe072:	mov    r14d,0x420aa0
    7c479dafe078:	movdqu xmm2,XMMWORD PTR [r14]
    7c479dafe07d:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7c479dafe087:	mov    r14d,0x420a30
    7c479dafe08d:	movdqu xmm3,XMMWORD PTR [r14]
    7c479dafe092:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7c479dafe09c:	mov    r14d,0x420ac0
    7c479dafe0a2:	movdqu xmm4,XMMWORD PTR [r14]
    7c479dafe0a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
    7c479dafe0b1:	mov    r14d,0x420a60
    7c479dafe0b7:	movdqu xmm5,XMMWORD PTR [r14]
    7c479dafe0bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
    7c479dafe0c6:	mov    r14d,0x430000
    7c479dafe0cc:	mov    rax,r14
    7c479dafe0cf:	add    rax,0xcd0
    7c479dafe0d5:	mov    QWORD PTR [r12+0x98],rax
    7c479dafe0dd:	mov    r15d,0x420ad0
    7c479dafe0e3:	movdqu xmm6,XMMWORD PTR [r15]
    7c479dafe0e8:	movdqu XMMWORD PTR [r12+0x150],xmm6
    7c479dafe0f2:	mov    r15,QWORD PTR [r12+0x98]
    7c479dafe0fa:	add    r15,0x10
    7c479dafe0fe:	mov    rdi,QWORD PTR [r12+0x98]
    7c479dafe106:	movdqu XMMWORD PTR [rdi],xmm2
    7c479dafe10a:	movdqu XMMWORD PTR [r15],xmm3
    7c479dafe10f:	mov    r15,QWORD PTR [r12+0x98]
    7c479dafe117:	add    r15,0x20
    7c479dafe11b:	mov    rbp,r15
    7c479dafe11e:	add    rbp,0x10
    7c479dafe122:	movdqu XMMWORD PTR [r15],xmm4
    7c479dafe127:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    7c479dafe12c:	mov    r15d,0x420a20
    7c479dafe132:	movdqu xmm4,XMMWORD PTR [r15]
    7c479dafe137:	movdqu XMMWORD PTR [r12+0x130],xmm4
    7c479dafe141:	mov    r15d,0x420a10
    7c479dafe147:	movdqu xmm5,XMMWORD PTR [r15]
    7c479dafe14c:	movdqu XMMWORD PTR [r12+0x140],xmm5
    7c479dafe156:	mov    r15,QWORD PTR [r12+0x98]
    7c479dafe15e:	add    r15,0x100
    7c479dafe165:	mov    rbp,r15
    7c479dafe168:	add    rbp,0x10
    7c479dafe16c:	movdqu XMMWORD PTR [r15],xmm2
    7c479dafe171:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    7c479dafe176:	mov    r15,QWORD PTR [r12+0x98]
    7c479dafe17e:	add    r15,0x40
    7c479dafe182:	mov    rbp,r15
    7c479dafe185:	add    rbp,0x10
    7c479dafe189:	movdqu XMMWORD PTR [r15],xmm6
    7c479dafe18e:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    7c479dafe193:	mov    r15d,0x420a00
    7c479dafe199:	movdqu xmm2,XMMWORD PTR [r15]
    7c479dafe19e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c479dafe1a8:	mov    r15d,0x420a70
    7c479dafe1ae:	movdqu xmm3,XMMWORD PTR [r15]
    7c479dafe1b3:	movdqu XMMWORD PTR [r12+0x150],xmm3
    7c479dafe1bd:	mov    r15d,0xf8d3
    7c479dafe1c3:	mov    QWORD PTR [r12+0x48],r15
    7c479dafe1c8:	mov    r15,QWORD PTR [r12+0x98]
    7c479dafe1d0:	add    r15,0x60
    7c479dafe1d4:	mov    rbp,r15
    7c479dafe1d7:	add    rbp,0x10
    7c479dafe1db:	movdqu XMMWORD PTR [r15],xmm5
    7c479dafe1e0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c479dafe1e5:	mov    r15d,0x420a80
    7c479dafe1eb:	movdqu xmm2,XMMWORD PTR [r15]
    7c479dafe1f0:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c479dafe1fa:	mov    r15d,0x420a50
    7c479dafe200:	movdqu xmm4,XMMWORD PTR [r15]
    7c479dafe205:	movdqu XMMWORD PTR [r12+0x140],xmm4
    7c479dafe20f:	mov    r15d,0xf8d3
    7c479dafe215:	mov    ebp,0x421d
    7c479dafe21a:	and    ebp,0xffff
    7c479dafe220:	mov    rax,r15
    7c479dafe223:	movabs rcx,0xffffffff0000ffff
    7c479dafe22d:	and    rax,rcx
    7c479dafe230:	mov    rdx,rbp
    7c479dafe233:	shl    rdx,0x10
    7c479dafe237:	mov    ecx,0xffff0000
    7c479dafe23c:	and    rdx,rcx
    7c479dafe23f:	or     rax,rdx
    7c479dafe242:	mov    r8d,eax
    7c479dafe245:	mov    QWORD PTR [r12+0x48],r8
    7c479dafe24a:	mov    r15,QWORD PTR [r12+0x98]
    7c479dafe252:	add    r15,0x80
    7c479dafe259:	mov    rbp,r15
    7c479dafe25c:	add    rbp,0x10
    7c479dafe260:	movdqu XMMWORD PTR [r15],xmm3
    7c479dafe265:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c479dafe26a:	mov    r15d,0x420af0
    7c479dafe270:	movdqu xmm2,XMMWORD PTR [r15]
    7c479dafe275:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c479dafe27f:	mov    r15d,0x420b00
    7c479dafe285:	movdqu xmm3,XMMWORD PTR [r15]
    7c479dafe28a:	movdqu XMMWORD PTR [r12+0x150],xmm3
    7c479dafe294:	mov    r15d,0x3e8
    7c479dafe29a:	mov    QWORD PTR [r12+0xa0],r15
    7c479dafe2a2:	mov    r15,QWORD PTR [r12+0x98]
    7c479dafe2aa:	add    r15,0xa0
    7c479dafe2b1:	mov    rbp,r15
    7c479dafe2b4:	add    rbp,0x10
    7c479dafe2b8:	movdqu XMMWORD PTR [r15],xmm4
    7c479dafe2bd:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c479dafe2c2:	mov    r15d,0x420ae0
    7c479dafe2c8:	movdqu xmm2,XMMWORD PTR [r15]
    7c479dafe2cd:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c479dafe2d7:	mov    r15d,0x420a90
    7c479dafe2dd:	movdqu xmm4,XMMWORD PTR [r15]
    7c479dafe2e2:	movdqu XMMWORD PTR [r12+0x140],xmm4
    7c479dafe2ec:	mov    r15,r13
    7c479dafe2ef:	add    r15,0x180
    7c479dafe2f6:	mov    rbp,r15
    7c479dafe2f9:	add    rbp,0x8
    7c479dafe2fd:	mov    r9,QWORD PTR [r12+0x200]
    7c479dafe305:	mov    r14,QWORD PTR [r12+0x1f0]
    7c479dafe30d:	mov    QWORD PTR [r15],r9
    7c479dafe310:	mov    QWORD PTR [rbp+0x0],r14
    7c479dafe314:	mov    r14,QWORD PTR [r12+0x98]
    7c479dafe31c:	add    r14,0xc0
    7c479dafe323:	mov    r15,r14
    7c479dafe326:	add    r15,0x10
    7c479dafe32a:	movdqu XMMWORD PTR [r14],xmm3
    7c479dafe32f:	movdqu XMMWORD PTR [r15],xmm2
    7c479dafe334:	mov    r14d,0x420ab0
    7c479dafe33a:	movdqu xmm2,XMMWORD PTR [r14]
    7c479dafe33f:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c479dafe349:	mov    r14d,0x420b18
    7c479dafe34f:	mov    r15,QWORD PTR [r14]
    7c479dafe352:	mov    r14d,0x0
    7c479dafe358:	mov    QWORD PTR [r12+0x110],r15
    7c479dafe360:	mov    QWORD PTR [r12+0x118],r14
    7c479dafe368:	mov    r14d,0x420b20
    7c479dafe36e:	mov    QWORD PTR [r12+0x40],r14
    7c479dafe373:	mov    r14,QWORD PTR [r12+0x98]
    7c479dafe37b:	add    r14,0xe0
    7c479dafe382:	mov    rbp,r14
    7c479dafe385:	add    rbp,0x10
    7c479dafe389:	movdqu XMMWORD PTR [r14],xmm4
    7c479dafe38e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c479dafe393:	mov    r14d,0x420b80
    7c479dafe399:	movdqu xmm2,XMMWORD PTR [r14]
    7c479dafe39e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c479dafe3a8:	mov    r14,QWORD PTR [r12+0x98]
    7c479dafe3b0:	add    r14,0x120
    7c479dafe3b7:	mov    QWORD PTR [r14],r15
    7c479dafe3ba:	mov    r14d,0x420b60
    7c479dafe3c0:	mov    r15d,0x420b70
    7c479dafe3c6:	movdqu xmm3,XMMWORD PTR [r14]
    7c479dafe3cb:	movdqu xmm4,XMMWORD PTR [r15]
    7c479dafe3d0:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7c479dafe3da:	movdqu XMMWORD PTR [r12+0x110],xmm4
    7c479dafe3e4:	mov    r14,r13
    7c479dafe3e7:	add    r14,0x160
    7c479dafe3ee:	movdqu XMMWORD PTR [r14],xmm2
    7c479dafe3f3:	mov    r14,r13
    7c479dafe3f6:	add    r14,0x190
    7c479dafe3fd:	mov    r15,r14
    7c479dafe400:	add    r15,0x8
    7c479dafe404:	mov    rbp,QWORD PTR [r12+0x1e0]
    7c479dafe40c:	mov    r9,QWORD PTR [r12+0x1d0]
    7c479dafe414:	mov    QWORD PTR [r14],rbp
    7c479dafe417:	mov    QWORD PTR [r15],r9
    7c479dafe41a:	mov    r14,r13
    7c479dafe41d:	add    r14,0x140
    7c479dafe424:	mov    r15,r14
    7c479dafe427:	add    r15,0x10
    7c479dafe42b:	movdqu XMMWORD PTR [r14],xmm3
    7c479dafe430:	movdqu XMMWORD PTR [r15],xmm4
    7c479dafe435:	mov    r14d,0x420b20
    7c479dafe43b:	mov    r15d,0x420b30
    7c479dafe441:	movdqu xmm2,XMMWORD PTR [r14]
    7c479dafe446:	movdqu xmm3,XMMWORD PTR [r15]
    7c479dafe44b:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7c479dafe455:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7c479dafe45f:	mov    r14,r13
    7c479dafe462:	add    r14,0x1a0
    7c479dafe469:	mov    r15,r14
    7c479dafe46c:	add    r15,0x8
    7c479dafe470:	mov    rbp,QWORD PTR [r12+0x1c0]
    7c479dafe478:	mov    r9,QWORD PTR [r12+0x1b0]
    7c479dafe480:	mov    QWORD PTR [r14],rbp
    7c479dafe483:	mov    QWORD PTR [r15],r9
    7c479dafe486:	mov    r14,r13
    7c479dafe489:	add    r14,0x1b0
    7c479dafe490:	mov    r15,r14
    7c479dafe493:	add    r15,0x8
    7c479dafe497:	mov    rbp,QWORD PTR [r12+0x1a0]
    7c479dafe49f:	mov    r9,QWORD PTR [r12+0x190]
    7c479dafe4a7:	mov    QWORD PTR [r14],rbp
    7c479dafe4aa:	mov    QWORD PTR [r15],r9
    7c479dafe4ad:	mov    r14,r13
    7c479dafe4b0:	add    r14,0x100
    7c479dafe4b7:	mov    r15,r14
    7c479dafe4ba:	add    r15,0x10
    7c479dafe4be:	movdqu XMMWORD PTR [r14],xmm2
    7c479dafe4c3:	movdqu XMMWORD PTR [r15],xmm3
    7c479dafe4c8:	mov    r14d,0x420b40
    7c479dafe4ce:	mov    r15d,0x420b50
    7c479dafe4d4:	movdqu xmm2,XMMWORD PTR [r14]
    7c479dafe4d9:	movdqu xmm3,XMMWORD PTR [r15]
    7c479dafe4de:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7c479dafe4e8:	movdqu XMMWORD PTR [r12+0x130],xmm3
    7c479dafe4f2:	mov    r14,r13
    7c479dafe4f5:	add    r14,0x1c0
    7c479dafe4fc:	mov    r15,r14
    7c479dafe4ff:	add    r15,0x8
    7c479dafe503:	mov    rbp,QWORD PTR [r12+0xe8]
    7c479dafe50b:	mov    r9,QWORD PTR [r12+0xf0]
    7c479dafe513:	mov    QWORD PTR [r14],rbp
    7c479dafe516:	mov    QWORD PTR [r15],r9
    7c479dafe519:	mov    r14,QWORD PTR [r12+0x98]
    7c479dafe521:	add    r14,0x128
    7c479dafe528:	mov    DWORD PTR [r14],r8d
    7c479dafe52b:	mov    r14,r13
    7c479dafe52e:	add    r14,0x120
    7c479dafe535:	mov    r15,r14
    7c479dafe538:	add    r15,0x10
    7c479dafe53c:	movdqu XMMWORD PTR [r14],xmm2
    7c479dafe541:	movdqu XMMWORD PTR [r15],xmm3
    7c479dafe546:	add    r13,0x100
    7c479dafe54d:	mov    QWORD PTR [r12],r13
    7c479dafe551:	mov    r13d,0x0
    7c479dafe557:	mov    rcx,QWORD PTR [r12+0x98]
    7c479dafe55f:	or     r13,rcx
    7c479dafe562:	mov    QWORD PTR [r12+0x8],r13
    7c479dafe567:	mov    r13d,0x12c
    7c479dafe56d:	mov    QWORD PTR [r12+0x10],r13
    7c479dafe572:	mov    r13d,0x410284
    7c479dafe578:	mov    QWORD PTR [r12+0xf0],r13
    7c479dafe580:	mov    r13d,0x410728
    7c479dafe586:	mov    QWORD PTR [r12+0x100],r13
    7c479dafe58e:	mov    r11,QWORD PTR [rsp]
    7c479dafe592:	mov    QWORD PTR [r12+0x398],r11
    7c479dafe59a:	mov    edi,0x410728
    7c479dafe59f:	mov    QWORD PTR [r12+0x100],rdi
    7c479dafe5a7:	add    rsp,0x10
    7c479dafe5ab:	nop    DWORD PTR [rax+rax*1+0x0]
    7c479dafe5b0:	jmp    QWORD PTR [rip+0x2]        # 0x7c479dafe5b8
    7c479dafe5b6:	xchg   ax,ax
    7c479dafe5b8:	loopne 0x7c479dafe59f
    7c479dafe5ba:	scas   eax,DWORD PTR es:[rdi]
    7c479dafe5bb:	popf
    7c479dafe5bc:	rex.RXB jl 0x7c479dafe5bf
    7c479dafe5bf:	add    al,cl
    7c479dafe5c1:	in     eax,0xaf
    7c479dafe5c3:	popf
    7c479dafe5c4:	rex.RXB jl 0x7c479dafe5c7
    7c479dafe5c7:	add    BYTE PTR [rcx-0x45],cl
    7c479dafe5ca:	rex jns 0x7c479dafe5ff
    7c479dafe5cd:	xchg   esi,edi
    7c479dafe5cf:	(bad)
    7c479dafe5d0:	add    BYTE PTR [rax],al
    7c479dafe5d2:	jmp    r11
    7c479dafe5d5:	nop
    7c479dafe5d6:	nop
    7c479dafe5d7:	nop
