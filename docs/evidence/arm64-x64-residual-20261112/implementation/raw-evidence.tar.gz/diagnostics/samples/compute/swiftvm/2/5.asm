
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/2/5.bin:     file format binary


Disassembly of section .data:

0000730a04101220 <.data>:
    730a04101220:	sub    rsp,0x10
    730a04101224:	mov    r11,QWORD PTR [r12+0x398]
    730a0410122c:	mov    QWORD PTR [rsp],r11
    730a04101230:	mov    rax,QWORD PTR [r12+0xf8]
    730a04101238:	mov    r14,QWORD PTR [r12+0xf8]
    730a04101240:	add    r14,0x100
    730a04101247:	mov    r15d,DWORD PTR [r14]
    730a0410124a:	mov    QWORD PTR [r12+0x40],r15
    730a0410124f:	mov    r14,QWORD PTR [r12+0xf8]
    730a04101257:	add    r14,0x104
    730a0410125e:	mov    ebp,DWORD PTR [r14]
    730a04101261:	mov    QWORD PTR [r12+0x50],rbp
    730a04101266:	mov    r14d,0x430c90
    730a0410126c:	mov    QWORD PTR [r12+0x48],r14
    730a04101271:	mov    r14,QWORD PTR [r12+0xf8]
    730a04101279:	add    r14,0x108
    730a04101280:	mov    r8d,DWORD PTR [r14]
    730a04101283:	mov    QWORD PTR [r12+0x58],r8
    730a04101288:	mov    r14,QWORD PTR [r12+0xf8]
    730a04101290:	add    r14,0x10c
    730a04101297:	mov    eax,DWORD PTR [r14]
    730a0410129a:	mov    QWORD PTR [r12+0x60],rax
    730a0410129f:	movabs rcx,0xff00ff00ff00ff
    730a041012a9:	mov    r14,r15
    730a041012ac:	and    r14,rcx
    730a041012af:	shl    r14,0x8
    730a041012b3:	movabs rcx,0xff00ff00ff00ff00
    730a041012bd:	mov    r13,r15
    730a041012c0:	and    r13,rcx
    730a041012c3:	shr    r13,0x8
    730a041012c7:	or     r13,r14
    730a041012ca:	movabs rcx,0xffff0000ffff
    730a041012d4:	mov    r14,r13
    730a041012d7:	and    r14,rcx
    730a041012da:	shl    r14,0x10
    730a041012de:	movabs rcx,0xffff0000ffff0000
    730a041012e8:	and    r13,rcx
    730a041012eb:	shr    r13,0x10
    730a041012ef:	or     r13,r14
    730a041012f2:	mov    ecx,0xffffffff
    730a041012f7:	and    r13,rcx
    730a041012fa:	mov    QWORD PTR [r12+0x40],r13
    730a041012ff:	movabs rcx,0xff00ff00ff00ff
    730a04101309:	mov    r14,rbp
    730a0410130c:	and    r14,rcx
    730a0410130f:	shl    r14,0x8
    730a04101313:	movabs rcx,0xff00ff00ff00ff00
    730a0410131d:	mov    r15,rbp
    730a04101320:	and    r15,rcx
    730a04101323:	shr    r15,0x8
    730a04101327:	or     r15,r14
    730a0410132a:	movabs rcx,0xffff0000ffff
    730a04101334:	mov    r14,r15
    730a04101337:	and    r14,rcx
    730a0410133a:	shl    r14,0x10
    730a0410133e:	movabs rcx,0xffff0000ffff0000
    730a04101348:	and    r15,rcx
    730a0410134b:	shr    r15,0x10
    730a0410134f:	or     r15,r14
    730a04101352:	mov    ecx,0xffffffff
    730a04101357:	and    r15,rcx
    730a0410135a:	mov    QWORD PTR [r12+0x50],r15
    730a0410135f:	mov    r14d,0x0
    730a04101365:	mov    QWORD PTR [r12+0xa0],r14
    730a0410136d:	mov    r14d,0x430c90
    730a04101373:	mov    ebp,0x430c94
    730a04101378:	mov    rax,r13
    730a0410137b:	mov    eax,eax
    730a0410137d:	mov    r9d,eax
    730a04101380:	mov    rax,r15
    730a04101383:	mov    eax,eax
    730a04101385:	mov    r13d,eax
    730a04101388:	mov    DWORD PTR [r14],r9d
    730a0410138b:	mov    r14d,0x0
    730a04101391:	mov    DWORD PTR [r12+0x32c],r14d
    730a04101399:	mov    DWORD PTR [rbp+0x0],r13d
    730a0410139d:	movabs rcx,0xff00ff00ff00ff
    730a041013a7:	mov    r13,r8
    730a041013aa:	and    r13,rcx
    730a041013ad:	shl    r13,0x8
    730a041013b1:	movabs rcx,0xff00ff00ff00ff00
    730a041013bb:	mov    r14,r8
    730a041013be:	and    r14,rcx
    730a041013c1:	shr    r14,0x8
    730a041013c5:	or     r14,r13
    730a041013c8:	movabs rcx,0xffff0000ffff
    730a041013d2:	mov    r13,r14
    730a041013d5:	and    r13,rcx
    730a041013d8:	shl    r13,0x10
    730a041013dc:	movabs rcx,0xffff0000ffff0000
    730a041013e6:	and    r14,rcx
    730a041013e9:	shr    r14,0x10
    730a041013ed:	or     r14,r13
    730a041013f0:	mov    ecx,0xffffffff
    730a041013f5:	and    r14,rcx
    730a041013f8:	mov    QWORD PTR [r12+0x40],r14
    730a041013fd:	mov    r13,QWORD PTR [r12+0xf8]
    730a04101405:	add    r13,0x110
    730a0410140c:	mov    r15d,DWORD PTR [r13+0x0]
    730a04101410:	mov    QWORD PTR [r12+0x50],r15
    730a04101415:	movabs rcx,0xff00ff00ff00ff
    730a0410141f:	mov    r13d,DWORD PTR [r12+0x60]
    730a04101424:	and    r13,rcx
    730a04101427:	shl    r13,0x8
    730a0410142b:	movabs rcx,0xff00ff00ff00ff00
    730a04101435:	mov    ebp,DWORD PTR [r12+0x60]
    730a0410143a:	and    rbp,rcx
    730a0410143d:	shr    rbp,0x8
    730a04101441:	or     rbp,r13
    730a04101444:	movabs rcx,0xffff0000ffff
    730a0410144e:	mov    r13,rbp
    730a04101451:	and    r13,rcx
    730a04101454:	shl    r13,0x10
    730a04101458:	movabs rcx,0xffff0000ffff0000
    730a04101462:	and    rbp,rcx
    730a04101465:	shr    rbp,0x10
    730a04101469:	or     rbp,r13
    730a0410146c:	mov    ecx,0xffffffff
    730a04101471:	and    rbp,rcx
    730a04101474:	mov    QWORD PTR [r12+0x58],rbp
    730a04101479:	mov    r13,QWORD PTR [r12+0xf8]
    730a04101481:	add    r13,0x114
    730a04101488:	mov    eax,DWORD PTR [r13+0x0]
    730a0410148c:	mov    QWORD PTR [r12+0x60],rax
    730a04101491:	mov    r13d,0x430000
    730a04101497:	add    r13,0xdfc
    730a0410149e:	mov    QWORD PTR [r12+0x98],r13
    730a041014a6:	mov    r13d,0x430c98
    730a041014ac:	mov    r9d,0x430c9c
    730a041014b2:	mov    rax,r14
    730a041014b5:	mov    eax,eax
    730a041014b7:	mov    r8d,eax
    730a041014ba:	mov    rax,rbp
    730a041014bd:	mov    eax,eax
    730a041014bf:	mov    r14d,eax
    730a041014c2:	mov    DWORD PTR [r13+0x0],r8d
    730a041014c6:	mov    DWORD PTR [r9],r14d
    730a041014c9:	movabs rcx,0xff00ff00ff00ff
    730a041014d3:	mov    r13,r15
    730a041014d6:	and    r13,rcx
    730a041014d9:	shl    r13,0x8
    730a041014dd:	movabs rcx,0xff00ff00ff00ff00
    730a041014e7:	mov    r14,r15
    730a041014ea:	and    r14,rcx
    730a041014ed:	shr    r14,0x8
    730a041014f1:	or     r14,r13
    730a041014f4:	movabs rcx,0xffff0000ffff
    730a041014fe:	mov    r13,r14
    730a04101501:	and    r13,rcx
    730a04101504:	shl    r13,0x10
    730a04101508:	movabs rcx,0xffff0000ffff0000
    730a04101512:	and    r14,rcx
    730a04101515:	shr    r14,0x10
    730a04101519:	or     r14,r13
    730a0410151c:	mov    ecx,0xffffffff
    730a04101521:	and    r14,rcx
    730a04101524:	mov    QWORD PTR [r12+0x40],r14
    730a04101529:	mov    r13,QWORD PTR [r12+0xf8]
    730a04101531:	add    r13,0x118
    730a04101538:	mov    r15d,DWORD PTR [r13+0x0]
    730a0410153c:	mov    QWORD PTR [r12+0x50],r15
    730a04101541:	movabs rcx,0xff00ff00ff00ff
    730a0410154b:	mov    r13d,DWORD PTR [r12+0x60]
    730a04101550:	and    r13,rcx
    730a04101553:	shl    r13,0x8
    730a04101557:	movabs rcx,0xff00ff00ff00ff00
    730a04101561:	mov    ebp,DWORD PTR [r12+0x60]
    730a04101566:	and    rbp,rcx
    730a04101569:	shr    rbp,0x8
    730a0410156d:	or     rbp,r13
    730a04101570:	movabs rcx,0xffff0000ffff
    730a0410157a:	mov    r13,rbp
    730a0410157d:	and    r13,rcx
    730a04101580:	shl    r13,0x10
    730a04101584:	movabs rcx,0xffff0000ffff0000
    730a0410158e:	and    rbp,rcx
    730a04101591:	shr    rbp,0x10
    730a04101595:	or     rbp,r13
    730a04101598:	mov    ecx,0xffffffff
    730a0410159d:	and    rbp,rcx
    730a041015a0:	mov    QWORD PTR [r12+0x58],rbp
    730a041015a5:	mov    r13,QWORD PTR [r12+0xf8]
    730a041015ad:	add    r13,0x11c
    730a041015b4:	mov    eax,DWORD PTR [r13+0x0]
    730a041015b8:	mov    QWORD PTR [r12+0x60],rax
    730a041015bd:	mov    r13d,0x430ca0
    730a041015c3:	mov    r9d,0x430ca4
    730a041015c9:	mov    rax,r14
    730a041015cc:	mov    eax,eax
    730a041015ce:	mov    r8d,eax
    730a041015d1:	mov    rax,rbp
    730a041015d4:	mov    eax,eax
    730a041015d6:	mov    r14d,eax
    730a041015d9:	mov    DWORD PTR [r13+0x0],r8d
    730a041015dd:	mov    DWORD PTR [r9],r14d
    730a041015e0:	movabs rcx,0xff00ff00ff00ff
    730a041015ea:	mov    r13,r15
    730a041015ed:	and    r13,rcx
    730a041015f0:	shl    r13,0x8
    730a041015f4:	movabs rcx,0xff00ff00ff00ff00
    730a041015fe:	mov    r14,r15
    730a04101601:	and    r14,rcx
    730a04101604:	shr    r14,0x8
    730a04101608:	or     r14,r13
    730a0410160b:	movabs rcx,0xffff0000ffff
    730a04101615:	mov    r13,r14
    730a04101618:	and    r13,rcx
    730a0410161b:	shl    r13,0x10
    730a0410161f:	movabs rcx,0xffff0000ffff0000
    730a04101629:	and    r14,rcx
    730a0410162c:	shr    r14,0x10
    730a04101630:	or     r14,r13
    730a04101633:	mov    ecx,0xffffffff
    730a04101638:	and    r14,rcx
    730a0410163b:	mov    QWORD PTR [r12+0x40],r14
    730a04101640:	movabs rcx,0xff00ff00ff00ff
    730a0410164a:	mov    r13d,DWORD PTR [r12+0x60]
    730a0410164f:	and    r13,rcx
    730a04101652:	shl    r13,0x8
    730a04101656:	movabs rcx,0xff00ff00ff00ff00
    730a04101660:	mov    r15d,DWORD PTR [r12+0x60]
    730a04101665:	and    r15,rcx
    730a04101668:	shr    r15,0x8
    730a0410166c:	or     r15,r13
    730a0410166f:	movabs rcx,0xffff0000ffff
    730a04101679:	mov    r13,r15
    730a0410167c:	and    r13,rcx
    730a0410167f:	shl    r13,0x10
    730a04101683:	movabs rcx,0xffff0000ffff0000
    730a0410168d:	and    r15,rcx
    730a04101690:	shr    r15,0x10
    730a04101694:	or     r15,r13
    730a04101697:	mov    ecx,0xffffffff
    730a0410169c:	and    r15,rcx
    730a0410169f:	mov    QWORD PTR [r12+0x50],r15
    730a041016a4:	mov    r13d,0x430ca8
    730a041016aa:	mov    ebp,0x430cac
    730a041016af:	mov    rax,r14
    730a041016b2:	mov    eax,eax
    730a041016b4:	mov    r8d,eax
    730a041016b7:	mov    rax,r15
    730a041016ba:	mov    eax,eax
    730a041016bc:	mov    r14d,eax
    730a041016bf:	mov    DWORD PTR [r13+0x0],r8d
    730a041016c3:	mov    DWORD PTR [rbp+0x0],r14d
    730a041016c7:	mov    r13d,0x11
    730a041016cd:	mov    QWORD PTR [r12],r13
    730a041016d1:	mov    r13d,0x41035c
    730a041016d7:	mov    QWORD PTR [r12+0xf0],r13
    730a041016df:	mov    r13d,0x4109a4
    730a041016e5:	mov    QWORD PTR [r12+0x100],r13
    730a041016ed:	mov    r11,QWORD PTR [rsp]
    730a041016f1:	mov    QWORD PTR [r12+0x398],r11
    730a041016f9:	mov    edi,0x4109a4
    730a041016fe:	mov    QWORD PTR [r12+0x100],rdi
    730a04101706:	add    rsp,0x10
    730a0410170a:	nop    WORD PTR [rax+rax*1+0x0]
    730a04101710:	jmp    QWORD PTR [rip+0x2]        # 0x730a04101718
    730a04101716:	xchg   ax,ax
    730a04101718:	rex (bad)
    730a0410171a:	adc    BYTE PTR [rdx+rcx*1],al
    730a0410171d:	jae    0x730a0410171f
    730a0410171f:	add    BYTE PTR [rax],ch
    730a04101721:	(bad)
    730a04101722:	adc    BYTE PTR [rdx+rcx*1],al
    730a04101725:	jae    0x730a04101727
    730a04101727:	add    BYTE PTR [rcx-0x45],cl
    730a0410172a:	rex leave
    730a0410172c:	ret    0x91a9
    730a0410172f:	push   rbp
    730a04101730:	add    BYTE PTR [rax],al
    730a04101732:	jmp    r11
    730a04101735:	nop
    730a04101736:	nop
    730a04101737:	nop
