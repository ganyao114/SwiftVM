
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/1/1.bin:     file format binary


Disassembly of section .data:

00007c479dafe5e0 <.data>:
    7c479dafe5e0:	sub    rsp,0xc0
    7c479dafe5e7:	mov    r11,QWORD PTR [r12+0x398]
    7c479dafe5ef:	mov    QWORD PTR [rsp+0xb0],r11
    7c479dafe5f7:	mov    r13,QWORD PTR [r12]
    7c479dafe5fb:	mov    r14,r13
    7c479dafe5fe:	add    r14,0x20
    7c479dafe602:	mov    r15,QWORD PTR [r14]
    7c479dafe605:	mov    r14,QWORD PTR [r12+0x10]
    7c479dafe60a:	add    r15,r14
    7c479dafe60d:	mov    QWORD PTR [r12+0x40],r15
    7c479dafe612:	add    r13,0x20
    7c479dafe616:	mov    QWORD PTR [r13+0x0],r15
    7c479dafe61a:	mov    r13d,0x0
    7c479dafe620:	mov    DWORD PTR [r12+0x32c],r13d
    7c479dafe628:	mov    rax,r14
    7c479dafe62b:	test   rax,rax
    7c479dafe62e:	je     0x7c479db00735
    7c479dafe634:	jmp    0x7c479dafe639
    7c479dafe639:	mov    r13,QWORD PTR [r12+0xf8]
    7c479dafe641:	sub    r13,0x150
    7c479dafe648:	mov    QWORD PTR [r12+0xf8],r13
    7c479dafe650:	mov    r14,QWORD PTR [r12]
    7c479dafe654:	mov    r15,r14
    7c479dafe657:	add    r15,0x68
    7c479dafe65b:	mov    rbp,QWORD PTR [r15]
    7c479dafe65e:	mov    QWORD PTR [r12+0x88],rbp
    7c479dafe666:	add    r14,0x28
    7c479dafe66a:	mov    QWORD PTR [r12+0x40],r14
    7c479dafe66f:	mov    QWORD PTR [r12+0x48],r13
    7c479dafe674:	mov    r14d,0x420000
    7c479dafe67a:	add    r14,0xb90
    7c479dafe681:	mov    QWORD PTR [r12+0x50],r14
    7c479dafe686:	mov    r14,r13
    7c479dafe689:	add    r14,0x100
    7c479dafe690:	mov    r15,r14
    7c479dafe693:	add    r15,0x8
    7c479dafe697:	mov    rbp,QWORD PTR [r12+0xe8]
    7c479dafe69f:	mov    r8,QWORD PTR [r12+0xd8]
    7c479dafe6a7:	mov    QWORD PTR [r14],rbp
    7c479dafe6aa:	mov    r14d,0x0
    7c479dafe6b0:	mov    DWORD PTR [r12+0x32c],r14d
    7c479dafe6b8:	mov    QWORD PTR [r15],r8
    7c479dafe6bb:	mov    r14,r13
    7c479dafe6be:	add    r14,0x110
    7c479dafe6c5:	mov    r15,r14
    7c479dafe6c8:	add    r15,0x8
    7c479dafe6cc:	mov    rbp,QWORD PTR [r12+0xd0]
    7c479dafe6d4:	mov    r8,QWORD PTR [r12+0xc8]
    7c479dafe6dc:	mov    QWORD PTR [r14],rbp
    7c479dafe6df:	mov    QWORD PTR [r15],r8
    7c479dafe6e2:	mov    r14,r13
    7c479dafe6e5:	add    r14,0x120
    7c479dafe6ec:	mov    r15,r14
    7c479dafe6ef:	add    r15,0x8
    7c479dafe6f3:	mov    rbp,QWORD PTR [r12+0xc0]
    7c479dafe6fb:	mov    r8,QWORD PTR [r12+0xb8]
    7c479dafe703:	mov    QWORD PTR [r14],rbp
    7c479dafe706:	mov    QWORD PTR [r15],r8
    7c479dafe709:	mov    r14,r13
    7c479dafe70c:	add    r14,0x130
    7c479dafe713:	mov    r15,r14
    7c479dafe716:	add    r15,0x8
    7c479dafe71a:	mov    rbp,QWORD PTR [r12+0xb0]
    7c479dafe722:	mov    r8,QWORD PTR [r12+0xa8]
    7c479dafe72a:	mov    QWORD PTR [r14],rbp
    7c479dafe72d:	mov    QWORD PTR [r15],r8
    7c479dafe730:	add    r13,0x140
    7c479dafe737:	mov    r14,r13
    7c479dafe73a:	add    r14,0x8
    7c479dafe73e:	mov    r15,QWORD PTR [r12+0xa0]
    7c479dafe746:	mov    rbp,QWORD PTR [r12+0x98]
    7c479dafe74e:	mov    QWORD PTR [r13+0x0],r15
    7c479dafe752:	mov    QWORD PTR [r14],rbp
    7c479dafe755:	jmp    0x7c479dafe75a
    7c479dafe75a:	mov    r13,QWORD PTR [r12+0x8]
    7c479dafe75f:	mov    r14,r13
    7c479dafe762:	add    r14,0x1
    7c479dafe766:	movzx  r15d,BYTE PTR [r13+0x0]
    7c479dafe76b:	mov    QWORD PTR [r12+0x58],r15
    7c479dafe770:	mov    QWORD PTR [r12+0x8],r14
    7c479dafe775:	mov    r13,QWORD PTR [r12+0x88]
    7c479dafe77d:	mov    r14,r13
    7c479dafe780:	add    r14,0x1
    7c479dafe784:	mov    QWORD PTR [r12+0x60],r14
    7c479dafe789:	mov    r15,QWORD PTR [r12]
    7c479dafe78d:	mov    rbp,r15
    7c479dafe790:	add    rbp,0x68
    7c479dafe794:	mov    QWORD PTR [rbp+0x0],r14
    7c479dafe798:	mov    r14d,0x0
    7c479dafe79e:	mov    DWORD PTR [r12+0x32c],r14d
    7c479dafe7a6:	mov    r14,r15
    7c479dafe7a9:	add    r14,r13
    7c479dafe7ac:	mov    QWORD PTR [r12+0x60],r14
    7c479dafe7b1:	add    r14,0x28
    7c479dafe7b5:	movzx  r13d,BYTE PTR [r12+0x58]
    7c479dafe7bb:	mov    BYTE PTR [r14],r13b
    7c479dafe7be:	add    r15,0x68
    7c479dafe7c2:	mov    r13,QWORD PTR [r15]
    7c479dafe7c5:	mov    QWORD PTR [r12+0x88],r13
    7c479dafe7cd:	sub    r13,0x40
    7c479dafe7d1:	mov    rcx,QWORD PTR [r12+0x380]
    7c479dafe7d9:	jrcxz  0x7c479dafe7e0
    7c479dafe7db:	jmp    0x7c479db00780
    7c479dafe7e0:	jne    0x7c479dafe7fd
    7c479dafe7e6:	mov    r11,rax
    7c479dafe7e9:	lahf
    7c479dafe7ea:	seto   al
    7c479dafe7ed:	mov    WORD PTR [rsp+0xb0],ax
    7c479dafe7f5:	mov    rax,r11
    7c479dafe7f8:	jmp    0x7c479dafe814
    7c479dafe7fd:	mov    r11,rax
    7c479dafe800:	lahf
    7c479dafe801:	seto   al
    7c479dafe804:	mov    WORD PTR [rsp+0xb0],ax
    7c479dafe80c:	mov    rax,r11
    7c479dafe80f:	jmp    0x7c479db00637
    7c479dafe814:	mov    rax,QWORD PTR [r12+0x40]
    7c479dafe819:	mov    eax,0x0
    7c479dafe81e:	mov    QWORD PTR [rsp+0x18],rax
    7c479dafe823:	mov    eax,0x0
    7c479dafe828:	mov    QWORD PTR [rsp+0x10],rax
    7c479dafe82d:	mov    eax,0x0
    7c479dafe832:	mov    QWORD PTR [rsp+0x8],rax
    7c479dafe837:	mov    eax,0x0
    7c479dafe83c:	mov    QWORD PTR [rsp],rax
    7c479dafe840:	mov    rdi,QWORD PTR [r12+0x40]
    7c479dafe845:	movzx  r9d,BYTE PTR [rdi]
    7c479dafe849:	mov    r13,QWORD PTR [rsp+0x18]
    7c479dafe84e:	or     r13,r9
    7c479dafe851:	mov    r9,QWORD PTR [r12+0x40]
    7c479dafe856:	add    r9,0x1
    7c479dafe85a:	movzx  r8d,BYTE PTR [r9]
    7c479dafe85e:	mov    r9,QWORD PTR [rsp+0x10]
    7c479dafe863:	or     r9,r8
    7c479dafe866:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafe86b:	add    r8,0x2
    7c479dafe86f:	movzx  ebp,BYTE PTR [r8]
    7c479dafe873:	mov    r8,QWORD PTR [rsp+0x8]
    7c479dafe878:	or     r8,rbp
    7c479dafe87b:	mov    rbp,QWORD PTR [r12+0x40]
    7c479dafe880:	add    rbp,0x3
    7c479dafe884:	movzx  r15d,BYTE PTR [rbp+0x0]
    7c479dafe889:	mov    rbp,QWORD PTR [rsp]
    7c479dafe88d:	or     rbp,r15
    7c479dafe890:	mov    r15,QWORD PTR [r12+0x40]
    7c479dafe895:	add    r15,0x4
    7c479dafe899:	movzx  r14d,BYTE PTR [r15]
    7c479dafe89d:	mov    r15,r14
    7c479dafe8a0:	shl    r15,0x8
    7c479dafe8a4:	or     r13,r15
    7c479dafe8a7:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe8ac:	add    r14,0x5
    7c479dafe8b0:	movzx  r15d,BYTE PTR [r14]
    7c479dafe8b4:	mov    r14,r15
    7c479dafe8b7:	shl    r14,0x8
    7c479dafe8bb:	or     r9,r14
    7c479dafe8be:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe8c3:	add    r14,0x6
    7c479dafe8c7:	movzx  r15d,BYTE PTR [r14]
    7c479dafe8cb:	mov    r14,r15
    7c479dafe8ce:	shl    r14,0x8
    7c479dafe8d2:	or     r8,r14
    7c479dafe8d5:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe8da:	add    r14,0x7
    7c479dafe8de:	movzx  r15d,BYTE PTR [r14]
    7c479dafe8e2:	mov    r14,r15
    7c479dafe8e5:	shl    r14,0x8
    7c479dafe8e9:	or     rbp,r14
    7c479dafe8ec:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe8f1:	add    r14,0x8
    7c479dafe8f5:	movzx  r15d,BYTE PTR [r14]
    7c479dafe8f9:	mov    r14,r15
    7c479dafe8fc:	shl    r14,0x10
    7c479dafe900:	or     r13,r14
    7c479dafe903:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe908:	add    r14,0x9
    7c479dafe90c:	movzx  r15d,BYTE PTR [r14]
    7c479dafe910:	mov    r14,r15
    7c479dafe913:	shl    r14,0x10
    7c479dafe917:	or     r9,r14
    7c479dafe91a:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe91f:	add    r14,0xa
    7c479dafe923:	movzx  r15d,BYTE PTR [r14]
    7c479dafe927:	mov    r14,r15
    7c479dafe92a:	shl    r14,0x10
    7c479dafe92e:	or     r8,r14
    7c479dafe931:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe936:	add    r14,0xb
    7c479dafe93a:	movzx  r15d,BYTE PTR [r14]
    7c479dafe93e:	mov    r14,r15
    7c479dafe941:	shl    r14,0x10
    7c479dafe945:	or     rbp,r14
    7c479dafe948:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe94d:	add    r14,0xc
    7c479dafe951:	movzx  r15d,BYTE PTR [r14]
    7c479dafe955:	mov    r14,r15
    7c479dafe958:	shl    r14,0x18
    7c479dafe95c:	or     r13,r14
    7c479dafe95f:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe964:	add    r14,0xd
    7c479dafe968:	movzx  r15d,BYTE PTR [r14]
    7c479dafe96c:	mov    r14,r15
    7c479dafe96f:	shl    r14,0x18
    7c479dafe973:	or     r9,r14
    7c479dafe976:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe97b:	add    r14,0xe
    7c479dafe97f:	movzx  r15d,BYTE PTR [r14]
    7c479dafe983:	mov    r14,r15
    7c479dafe986:	shl    r14,0x18
    7c479dafe98a:	or     r8,r14
    7c479dafe98d:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe992:	add    r14,0xf
    7c479dafe996:	movzx  r15d,BYTE PTR [r14]
    7c479dafe99a:	mov    r14,r15
    7c479dafe99d:	shl    r14,0x18
    7c479dafe9a1:	or     rbp,r14
    7c479dafe9a4:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe9a9:	add    r14,0x10
    7c479dafe9ad:	movzx  r15d,BYTE PTR [r14]
    7c479dafe9b1:	mov    r14,r15
    7c479dafe9b4:	shl    r14,0x20
    7c479dafe9b8:	or     r13,r14
    7c479dafe9bb:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe9c0:	add    r14,0x11
    7c479dafe9c4:	movzx  r15d,BYTE PTR [r14]
    7c479dafe9c8:	mov    r14,r15
    7c479dafe9cb:	shl    r14,0x20
    7c479dafe9cf:	or     r9,r14
    7c479dafe9d2:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe9d7:	add    r14,0x12
    7c479dafe9db:	movzx  r15d,BYTE PTR [r14]
    7c479dafe9df:	mov    r14,r15
    7c479dafe9e2:	shl    r14,0x20
    7c479dafe9e6:	or     r8,r14
    7c479dafe9e9:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafe9ee:	add    r14,0x13
    7c479dafe9f2:	movzx  r15d,BYTE PTR [r14]
    7c479dafe9f6:	mov    r14,r15
    7c479dafe9f9:	shl    r14,0x20
    7c479dafe9fd:	or     rbp,r14
    7c479dafea00:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafea05:	add    r14,0x14
    7c479dafea09:	movzx  r15d,BYTE PTR [r14]
    7c479dafea0d:	mov    r14,r15
    7c479dafea10:	shl    r14,0x28
    7c479dafea14:	or     r13,r14
    7c479dafea17:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafea1c:	add    r14,0x15
    7c479dafea20:	movzx  r15d,BYTE PTR [r14]
    7c479dafea24:	mov    r14,r15
    7c479dafea27:	shl    r14,0x28
    7c479dafea2b:	or     r9,r14
    7c479dafea2e:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafea33:	add    r14,0x16
    7c479dafea37:	movzx  r15d,BYTE PTR [r14]
    7c479dafea3b:	mov    r14,r15
    7c479dafea3e:	shl    r14,0x28
    7c479dafea42:	or     r8,r14
    7c479dafea45:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafea4a:	add    r14,0x17
    7c479dafea4e:	movzx  r15d,BYTE PTR [r14]
    7c479dafea52:	mov    r14,r15
    7c479dafea55:	shl    r14,0x28
    7c479dafea59:	or     rbp,r14
    7c479dafea5c:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafea61:	add    r14,0x18
    7c479dafea65:	movzx  r15d,BYTE PTR [r14]
    7c479dafea69:	mov    r14,r15
    7c479dafea6c:	shl    r14,0x30
    7c479dafea70:	or     r13,r14
    7c479dafea73:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafea78:	add    r14,0x19
    7c479dafea7c:	movzx  r15d,BYTE PTR [r14]
    7c479dafea80:	mov    r14,r15
    7c479dafea83:	shl    r14,0x30
    7c479dafea87:	or     r9,r14
    7c479dafea8a:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafea8f:	add    r14,0x1a
    7c479dafea93:	movzx  r15d,BYTE PTR [r14]
    7c479dafea97:	mov    r14,r15
    7c479dafea9a:	shl    r14,0x30
    7c479dafea9e:	or     r8,r14
    7c479dafeaa1:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafeaa6:	add    r14,0x1b
    7c479dafeaaa:	movzx  r15d,BYTE PTR [r14]
    7c479dafeaae:	mov    r14,r15
    7c479dafeab1:	shl    r14,0x30
    7c479dafeab5:	or     rbp,r14
    7c479dafeab8:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafeabd:	add    r14,0x1c
    7c479dafeac1:	movzx  r15d,BYTE PTR [r14]
    7c479dafeac5:	mov    r14,r15
    7c479dafeac8:	shl    r14,0x38
    7c479dafeacc:	mov    rax,r13
    7c479dafeacf:	or     rax,r14
    7c479dafead2:	mov    QWORD PTR [rsp+0x28],rax
    7c479dafead7:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafeadc:	add    r14,0x1d
    7c479dafeae0:	movzx  r15d,BYTE PTR [r14]
    7c479dafeae4:	mov    r14,r15
    7c479dafeae7:	shl    r14,0x38
    7c479dafeaeb:	mov    rax,r9
    7c479dafeaee:	or     rax,r14
    7c479dafeaf1:	mov    QWORD PTR [rsp+0x38],rax
    7c479dafeaf6:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafeafb:	add    r14,0x1e
    7c479dafeaff:	movzx  r15d,BYTE PTR [r14]
    7c479dafeb03:	mov    r14,r15
    7c479dafeb06:	shl    r14,0x38
    7c479dafeb0a:	mov    rax,r8
    7c479dafeb0d:	or     rax,r14
    7c479dafeb10:	mov    QWORD PTR [rsp+0x30],rax
    7c479dafeb15:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafeb1a:	add    r14,0x1f
    7c479dafeb1e:	movzx  r15d,BYTE PTR [r14]
    7c479dafeb22:	mov    r14,r15
    7c479dafeb25:	shl    r14,0x38
    7c479dafeb29:	mov    rax,rbp
    7c479dafeb2c:	or     rax,r14
    7c479dafeb2f:	mov    QWORD PTR [rsp+0x20],rax
    7c479dafeb34:	mov    r14,QWORD PTR [r12+0x40]
    7c479dafeb39:	add    r14,0x20
    7c479dafeb3d:	movzx  r15d,BYTE PTR [r14]
    7c479dafeb41:	mov    r14,QWORD PTR [rsp+0x18]
    7c479dafeb46:	or     r14,r15
    7c479dafeb49:	mov    r15,QWORD PTR [r12+0x40]
    7c479dafeb4e:	add    r15,0x21
    7c479dafeb52:	movzx  ebp,BYTE PTR [r15]
    7c479dafeb56:	mov    r15,QWORD PTR [rsp+0x10]
    7c479dafeb5b:	or     r15,rbp
    7c479dafeb5e:	mov    rbp,QWORD PTR [r12+0x40]
    7c479dafeb63:	add    rbp,0x22
    7c479dafeb67:	movzx  r13d,BYTE PTR [rbp+0x0]
    7c479dafeb6c:	mov    rbp,QWORD PTR [rsp+0x8]
    7c479dafeb71:	or     rbp,r13
    7c479dafeb74:	mov    r13,QWORD PTR [r12+0x40]
    7c479dafeb79:	add    r13,0x23
    7c479dafeb7d:	movzx  r8d,BYTE PTR [r13+0x0]
    7c479dafeb82:	mov    r13,QWORD PTR [rsp]
    7c479dafeb86:	or     r13,r8
    7c479dafeb89:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafeb8e:	add    r8,0x24
    7c479dafeb92:	movzx  r9d,BYTE PTR [r8]
    7c479dafeb96:	mov    r8,r9
    7c479dafeb99:	shl    r8,0x8
    7c479dafeb9d:	or     r14,r8
    7c479dafeba0:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafeba5:	add    r8,0x25
    7c479dafeba9:	movzx  r9d,BYTE PTR [r8]
    7c479dafebad:	mov    r8,r9
    7c479dafebb0:	shl    r8,0x8
    7c479dafebb4:	or     r15,r8
    7c479dafebb7:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafebbc:	add    r8,0x26
    7c479dafebc0:	movzx  r9d,BYTE PTR [r8]
    7c479dafebc4:	mov    r8,r9
    7c479dafebc7:	shl    r8,0x8
    7c479dafebcb:	or     rbp,r8
    7c479dafebce:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafebd3:	add    r8,0x27
    7c479dafebd7:	movzx  r9d,BYTE PTR [r8]
    7c479dafebdb:	mov    r8,r9
    7c479dafebde:	shl    r8,0x8
    7c479dafebe2:	or     r13,r8
    7c479dafebe5:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafebea:	add    r8,0x28
    7c479dafebee:	movzx  r9d,BYTE PTR [r8]
    7c479dafebf2:	mov    r8,r9
    7c479dafebf5:	shl    r8,0x10
    7c479dafebf9:	or     r14,r8
    7c479dafebfc:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafec01:	add    r8,0x29
    7c479dafec05:	movzx  r9d,BYTE PTR [r8]
    7c479dafec09:	mov    r8,r9
    7c479dafec0c:	shl    r8,0x10
    7c479dafec10:	or     r15,r8
    7c479dafec13:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafec18:	add    r8,0x2a
    7c479dafec1c:	movzx  r9d,BYTE PTR [r8]
    7c479dafec20:	mov    r8,r9
    7c479dafec23:	shl    r8,0x10
    7c479dafec27:	or     rbp,r8
    7c479dafec2a:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafec2f:	add    r8,0x2b
    7c479dafec33:	movzx  r9d,BYTE PTR [r8]
    7c479dafec37:	mov    r8,r9
    7c479dafec3a:	shl    r8,0x10
    7c479dafec3e:	or     r13,r8
    7c479dafec41:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafec46:	add    r8,0x2c
    7c479dafec4a:	movzx  r9d,BYTE PTR [r8]
    7c479dafec4e:	mov    r8,r9
    7c479dafec51:	shl    r8,0x18
    7c479dafec55:	or     r14,r8
    7c479dafec58:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafec5d:	add    r8,0x2d
    7c479dafec61:	movzx  r9d,BYTE PTR [r8]
    7c479dafec65:	mov    r8,r9
    7c479dafec68:	shl    r8,0x18
    7c479dafec6c:	or     r15,r8
    7c479dafec6f:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafec74:	add    r8,0x2e
    7c479dafec78:	movzx  r9d,BYTE PTR [r8]
    7c479dafec7c:	mov    r8,r9
    7c479dafec7f:	shl    r8,0x18
    7c479dafec83:	or     rbp,r8
    7c479dafec86:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafec8b:	add    r8,0x2f
    7c479dafec8f:	movzx  r9d,BYTE PTR [r8]
    7c479dafec93:	mov    r8,r9
    7c479dafec96:	shl    r8,0x18
    7c479dafec9a:	or     r13,r8
    7c479dafec9d:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafeca2:	add    r8,0x30
    7c479dafeca6:	movzx  r9d,BYTE PTR [r8]
    7c479dafecaa:	mov    r8,r9
    7c479dafecad:	shl    r8,0x20
    7c479dafecb1:	or     r14,r8
    7c479dafecb4:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafecb9:	add    r8,0x31
    7c479dafecbd:	movzx  r9d,BYTE PTR [r8]
    7c479dafecc1:	mov    r8,r9
    7c479dafecc4:	shl    r8,0x20
    7c479dafecc8:	or     r15,r8
    7c479dafeccb:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafecd0:	add    r8,0x32
    7c479dafecd4:	movzx  r9d,BYTE PTR [r8]
    7c479dafecd8:	mov    r8,r9
    7c479dafecdb:	shl    r8,0x20
    7c479dafecdf:	or     rbp,r8
    7c479dafece2:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafece7:	add    r8,0x33
    7c479dafeceb:	movzx  r9d,BYTE PTR [r8]
    7c479dafecef:	mov    r8,r9
    7c479dafecf2:	shl    r8,0x20
    7c479dafecf6:	or     r13,r8
    7c479dafecf9:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafecfe:	add    r8,0x34
    7c479dafed02:	movzx  r9d,BYTE PTR [r8]
    7c479dafed06:	mov    r8,r9
    7c479dafed09:	shl    r8,0x28
    7c479dafed0d:	or     r14,r8
    7c479dafed10:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafed15:	add    r8,0x35
    7c479dafed19:	movzx  r9d,BYTE PTR [r8]
    7c479dafed1d:	mov    r8,r9
    7c479dafed20:	shl    r8,0x28
    7c479dafed24:	or     r15,r8
    7c479dafed27:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafed2c:	add    r8,0x36
    7c479dafed30:	movzx  r9d,BYTE PTR [r8]
    7c479dafed34:	mov    r8,r9
    7c479dafed37:	shl    r8,0x28
    7c479dafed3b:	or     rbp,r8
    7c479dafed3e:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafed43:	add    r8,0x37
    7c479dafed47:	movzx  r9d,BYTE PTR [r8]
    7c479dafed4b:	mov    r8,r9
    7c479dafed4e:	shl    r8,0x28
    7c479dafed52:	or     r13,r8
    7c479dafed55:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafed5a:	add    r8,0x38
    7c479dafed5e:	movzx  r9d,BYTE PTR [r8]
    7c479dafed62:	mov    r8,r9
    7c479dafed65:	shl    r8,0x30
    7c479dafed69:	or     r14,r8
    7c479dafed6c:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafed71:	add    r8,0x39
    7c479dafed75:	movzx  r9d,BYTE PTR [r8]
    7c479dafed79:	mov    r8,r9
    7c479dafed7c:	shl    r8,0x30
    7c479dafed80:	or     r15,r8
    7c479dafed83:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafed88:	add    r8,0x3a
    7c479dafed8c:	movzx  r9d,BYTE PTR [r8]
    7c479dafed90:	mov    r8,r9
    7c479dafed93:	shl    r8,0x30
    7c479dafed97:	or     rbp,r8
    7c479dafed9a:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafed9f:	add    r8,0x3b
    7c479dafeda3:	movzx  r9d,BYTE PTR [r8]
    7c479dafeda7:	mov    r8,r9
    7c479dafedaa:	shl    r8,0x30
    7c479dafedae:	or     r13,r8
    7c479dafedb1:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafedb6:	add    r8,0x3c
    7c479dafedba:	movzx  r9d,BYTE PTR [r8]
    7c479dafedbe:	mov    r8,r9
    7c479dafedc1:	shl    r8,0x38
    7c479dafedc5:	or     r14,r8
    7c479dafedc8:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafedcd:	add    r8,0x3d
    7c479dafedd1:	movzx  r9d,BYTE PTR [r8]
    7c479dafedd5:	mov    r8,r9
    7c479dafedd8:	shl    r8,0x38
    7c479dafeddc:	or     r15,r8
    7c479dafeddf:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafede4:	add    r8,0x3e
    7c479dafede8:	movzx  r9d,BYTE PTR [r8]
    7c479dafedec:	mov    r8,r9
    7c479dafedef:	shl    r8,0x38
    7c479dafedf3:	or     rbp,r8
    7c479dafedf6:	mov    r8,QWORD PTR [r12+0x40]
    7c479dafedfb:	add    r8,0x3f
    7c479dafedff:	movzx  r9d,BYTE PTR [r8]
    7c479dafee03:	mov    r8,r9
    7c479dafee06:	shl    r8,0x38
    7c479dafee0a:	mov    rax,r13
    7c479dafee0d:	or     rax,r8
    7c479dafee10:	mov    QWORD PTR [rsp+0x40],rax
    7c479dafee15:	mov    r8d,0x0
    7c479dafee1b:	mov    QWORD PTR [r12+0x58],r8
    7c479dafee20:	mov    r8d,0x0
    7c479dafee26:	mov    r9,QWORD PTR [rsp+0x38]
    7c479dafee2b:	and    r9,0xff
    7c479dafee32:	and    r9,0xffff
    7c479dafee39:	mov    r13,r8
    7c479dafee3c:	or     r13,r9
    7c479dafee3f:	mov    r9,QWORD PTR [rsp+0x38]
    7c479dafee44:	shr    r9,0x8
    7c479dafee48:	and    r9,0xff
    7c479dafee4f:	and    r9,0xffff
    7c479dafee56:	shl    r9,0x10
    7c479dafee5a:	or     r13,r9
    7c479dafee5d:	mov    r9,QWORD PTR [rsp+0x38]
    7c479dafee62:	shr    r9,0x10
    7c479dafee66:	and    r9,0xff
    7c479dafee6d:	and    r9,0xffff
    7c479dafee74:	shl    r9,0x20
    7c479dafee78:	or     r13,r9
    7c479dafee7b:	mov    r9,QWORD PTR [rsp+0x38]
    7c479dafee80:	shr    r9,0x18
    7c479dafee84:	and    r9,0xff
    7c479dafee8b:	and    r9,0xffff
    7c479dafee92:	shl    r9,0x30
    7c479dafee96:	or     r13,r9
    7c479dafee99:	mov    r9,QWORD PTR [rsp+0x38]
    7c479dafee9e:	shr    r9,0x20
    7c479dafeea2:	and    r9,0xff
    7c479dafeea9:	and    r9,0xffff
    7c479dafeeb0:	or     r8,r9
    7c479dafeeb3:	mov    r9,QWORD PTR [rsp+0x38]
    7c479dafeeb8:	shr    r9,0x28
    7c479dafeebc:	and    r9,0xff
    7c479dafeec3:	and    r9,0xffff
    7c479dafeeca:	shl    r9,0x10
    7c479dafeece:	or     r8,r9
    7c479dafeed1:	mov    r9,QWORD PTR [rsp+0x38]
    7c479dafeed6:	shr    r9,0x30
    7c479dafeeda:	and    r9,0xff
    7c479dafeee1:	and    r9,0xffff
    7c479dafeee8:	shl    r9,0x20
    7c479dafeeec:	or     r8,r9
    7c479dafeeef:	mov    r9,QWORD PTR [rsp+0x38]
    7c479dafeef4:	shr    r9,0x38
    7c479dafeef8:	and    r9,0xff
    7c479dafeeff:	and    r9,0xffff
    7c479dafef06:	shl    r9,0x30
    7c479dafef0a:	or     r8,r9
    7c479dafef0d:	mov    QWORD PTR [r12+0x150],r13
    7c479dafef15:	mov    QWORD PTR [r12+0x158],r8
    7c479dafef1d:	mov    r13d,0x0
    7c479dafef23:	mov    r8,QWORD PTR [rsp+0x30]
    7c479dafef28:	and    r8,0xff
    7c479dafef2f:	and    r8,0xffff
    7c479dafef36:	mov    r9,r13
    7c479dafef39:	or     r9,r8
    7c479dafef3c:	mov    r8,QWORD PTR [rsp+0x30]
    7c479dafef41:	shr    r8,0x8
    7c479dafef45:	and    r8,0xff
    7c479dafef4c:	and    r8,0xffff
    7c479dafef53:	shl    r8,0x10
    7c479dafef57:	or     r9,r8
    7c479dafef5a:	mov    r8,QWORD PTR [rsp+0x30]
    7c479dafef5f:	shr    r8,0x10
    7c479dafef63:	and    r8,0xff
    7c479dafef6a:	and    r8,0xffff
    7c479dafef71:	shl    r8,0x20
    7c479dafef75:	or     r9,r8
    7c479dafef78:	mov    r8,QWORD PTR [rsp+0x30]
    7c479dafef7d:	shr    r8,0x18
    7c479dafef81:	and    r8,0xff
    7c479dafef88:	and    r8,0xffff
    7c479dafef8f:	shl    r8,0x30
    7c479dafef93:	mov    rax,r9
    7c479dafef96:	or     rax,r8
    7c479dafef99:	mov    QWORD PTR [rsp+0x50],rax
    7c479dafef9e:	mov    r8,QWORD PTR [rsp+0x30]
    7c479dafefa3:	shr    r8,0x20
    7c479dafefa7:	and    r8,0xff
    7c479dafefae:	and    r8,0xffff
    7c479dafefb5:	or     r13,r8
    7c479dafefb8:	mov    r8,QWORD PTR [rsp+0x30]
    7c479dafefbd:	shr    r8,0x28
    7c479dafefc1:	and    r8,0xff
    7c479dafefc8:	and    r8,0xffff
    7c479dafefcf:	shl    r8,0x10
    7c479dafefd3:	or     r13,r8
    7c479dafefd6:	mov    r8,QWORD PTR [rsp+0x30]
    7c479dafefdb:	shr    r8,0x30
    7c479dafefdf:	and    r8,0xff
    7c479dafefe6:	and    r8,0xffff
    7c479dafefed:	shl    r8,0x20
    7c479dafeff1:	or     r13,r8
    7c479dafeff4:	mov    r8,QWORD PTR [rsp+0x30]
    7c479dafeff9:	shr    r8,0x38
    7c479dafeffd:	and    r8,0xff
    7c479daff004:	and    r8,0xffff
    7c479daff00b:	shl    r8,0x30
    7c479daff00f:	mov    rax,r13
    7c479daff012:	or     rax,r8
    7c479daff015:	mov    QWORD PTR [rsp+0x48],rax
    7c479daff01a:	mov    r8d,0x0
    7c479daff020:	mov    r13,QWORD PTR [rsp+0x28]
    7c479daff025:	and    r13,0xff
    7c479daff02c:	and    r13,0xffff
    7c479daff033:	mov    r9,r8
    7c479daff036:	or     r9,r13
    7c479daff039:	mov    r13,QWORD PTR [rsp+0x28]
    7c479daff03e:	shr    r13,0x8
    7c479daff042:	and    r13,0xff
    7c479daff049:	and    r13,0xffff
    7c479daff050:	shl    r13,0x10
    7c479daff054:	or     r9,r13
    7c479daff057:	mov    r13,QWORD PTR [rsp+0x28]
    7c479daff05c:	shr    r13,0x10
    7c479daff060:	and    r13,0xff
    7c479daff067:	and    r13,0xffff
    7c479daff06e:	shl    r13,0x20
    7c479daff072:	or     r9,r13
    7c479daff075:	mov    r13,QWORD PTR [rsp+0x28]
    7c479daff07a:	shr    r13,0x18
    7c479daff07e:	and    r13,0xff
    7c479daff085:	and    r13,0xffff
    7c479daff08c:	shl    r13,0x30
    7c479daff090:	mov    rax,r9
    7c479daff093:	or     rax,r13
    7c479daff096:	mov    QWORD PTR [rsp+0x58],rax
    7c479daff09b:	mov    r13,QWORD PTR [rsp+0x28]
    7c479daff0a0:	shr    r13,0x20
    7c479daff0a4:	and    r13,0xff
    7c479daff0ab:	and    r13,0xffff
    7c479daff0b2:	or     r8,r13
    7c479daff0b5:	mov    r13,QWORD PTR [rsp+0x28]
    7c479daff0ba:	shr    r13,0x28
    7c479daff0be:	and    r13,0xff
    7c479daff0c5:	and    r13,0xffff
    7c479daff0cc:	shl    r13,0x10
    7c479daff0d0:	or     r8,r13
    7c479daff0d3:	mov    r13,QWORD PTR [rsp+0x28]
    7c479daff0d8:	shr    r13,0x30
    7c479daff0dc:	and    r13,0xff
    7c479daff0e3:	and    r13,0xffff
    7c479daff0ea:	shl    r13,0x20
    7c479daff0ee:	or     r8,r13
    7c479daff0f1:	mov    r13,QWORD PTR [rsp+0x28]
    7c479daff0f6:	shr    r13,0x38
    7c479daff0fa:	and    r13,0xff
    7c479daff101:	and    r13,0xffff
    7c479daff108:	shl    r13,0x30
    7c479daff10c:	mov    rax,r8
    7c479daff10f:	or     rax,r13
    7c479daff112:	mov    QWORD PTR [rsp+0x60],rax
    7c479daff117:	mov    r13d,0x0
    7c479daff11d:	mov    r9,r14
    7c479daff120:	and    r9,0xff
    7c479daff127:	and    r9,0xffff
    7c479daff12e:	mov    r8,r13
    7c479daff131:	or     r8,r9
    7c479daff134:	mov    r9,r14
    7c479daff137:	shr    r9,0x8
    7c479daff13b:	and    r9,0xff
    7c479daff142:	and    r9,0xffff
    7c479daff149:	shl    r9,0x10
    7c479daff14d:	or     r8,r9
    7c479daff150:	mov    r9,r14
    7c479daff153:	shr    r9,0x10
    7c479daff157:	and    r9,0xff
    7c479daff15e:	and    r9,0xffff
    7c479daff165:	shl    r9,0x20
    7c479daff169:	or     r8,r9
    7c479daff16c:	mov    r9,r14
    7c479daff16f:	shr    r9,0x18
    7c479daff173:	and    r9,0xff
    7c479daff17a:	and    r9,0xffff
    7c479daff181:	shl    r9,0x30
    7c479daff185:	mov    rax,r8
    7c479daff188:	or     rax,r9
    7c479daff18b:	mov    QWORD PTR [rsp+0x68],rax
    7c479daff190:	mov    r9,r14
    7c479daff193:	shr    r9,0x20
    7c479daff197:	and    r9,0xff
    7c479daff19e:	and    r9,0xffff
    7c479daff1a5:	or     r13,r9
    7c479daff1a8:	mov    r9,r14
    7c479daff1ab:	shr    r9,0x28
    7c479daff1af:	and    r9,0xff
    7c479daff1b6:	and    r9,0xffff
    7c479daff1bd:	shl    r9,0x10
    7c479daff1c1:	or     r13,r9
    7c479daff1c4:	mov    r9,r14
    7c479daff1c7:	shr    r9,0x30
    7c479daff1cb:	and    r9,0xff
    7c479daff1d2:	and    r9,0xffff
    7c479daff1d9:	shl    r9,0x20
    7c479daff1dd:	or     r13,r9
    7c479daff1e0:	shr    r14,0x38
    7c479daff1e4:	and    r14,0xff
    7c479daff1eb:	and    r14,0xffff
    7c479daff1f2:	shl    r14,0x30
    7c479daff1f6:	or     r13,r14
    7c479daff1f9:	mov    r14d,0x0
    7c479daff1ff:	mov    r9,r15
    7c479daff202:	and    r9,0xff
    7c479daff209:	and    r9,0xffff
    7c479daff210:	mov    r8,r14
    7c479daff213:	or     r8,r9
    7c479daff216:	mov    r9,r15
    7c479daff219:	shr    r9,0x8
    7c479daff21d:	and    r9,0xff
    7c479daff224:	and    r9,0xffff
    7c479daff22b:	shl    r9,0x10
    7c479daff22f:	or     r8,r9
    7c479daff232:	mov    r9,r15
    7c479daff235:	shr    r9,0x10
    7c479daff239:	and    r9,0xff
    7c479daff240:	and    r9,0xffff
    7c479daff247:	shl    r9,0x20
    7c479daff24b:	or     r8,r9
    7c479daff24e:	mov    r9,r15
    7c479daff251:	shr    r9,0x18
    7c479daff255:	and    r9,0xff
    7c479daff25c:	and    r9,0xffff
    7c479daff263:	shl    r9,0x30
    7c479daff267:	or     r8,r9
    7c479daff26a:	mov    r9,r15
    7c479daff26d:	shr    r9,0x20
    7c479daff271:	and    r9,0xff
    7c479daff278:	and    r9,0xffff
    7c479daff27f:	or     r14,r9
    7c479daff282:	mov    r9,r15
    7c479daff285:	shr    r9,0x28
    7c479daff289:	and    r9,0xff
    7c479daff290:	and    r9,0xffff
    7c479daff297:	shl    r9,0x10
    7c479daff29b:	or     r14,r9
    7c479daff29e:	mov    r9,r15
    7c479daff2a1:	shr    r9,0x30
    7c479daff2a5:	and    r9,0xff
    7c479daff2ac:	and    r9,0xffff
    7c479daff2b3:	shl    r9,0x20
    7c479daff2b7:	or     r14,r9
    7c479daff2ba:	shr    r15,0x38
    7c479daff2be:	and    r15,0xff
    7c479daff2c5:	and    r15,0xffff
    7c479daff2cc:	shl    r15,0x30
    7c479daff2d0:	or     r14,r15
    7c479daff2d3:	mov    QWORD PTR [r12+0x210],r8
    7c479daff2db:	mov    QWORD PTR [r12+0x218],r14
    7c479daff2e3:	mov    r14d,0x0
    7c479daff2e9:	mov    r15,rbp
    7c479daff2ec:	and    r15,0xff
    7c479daff2f3:	and    r15,0xffff
    7c479daff2fa:	mov    r8,r14
    7c479daff2fd:	or     r8,r15
    7c479daff300:	mov    r15,rbp
    7c479daff303:	shr    r15,0x8
    7c479daff307:	and    r15,0xff
    7c479daff30e:	and    r15,0xffff
    7c479daff315:	shl    r15,0x10
    7c479daff319:	or     r8,r15
    7c479daff31c:	mov    r15,rbp
    7c479daff31f:	shr    r15,0x10
    7c479daff323:	and    r15,0xff
    7c479daff32a:	and    r15,0xffff
    7c479daff331:	shl    r15,0x20
    7c479daff335:	or     r8,r15
    7c479daff338:	mov    r15,rbp
    7c479daff33b:	shr    r15,0x18
    7c479daff33f:	and    r15,0xff
    7c479daff346:	and    r15,0xffff
    7c479daff34d:	shl    r15,0x30
    7c479daff351:	or     r8,r15
    7c479daff354:	mov    r15,rbp
    7c479daff357:	shr    r15,0x20
    7c479daff35b:	and    r15,0xff
    7c479daff362:	and    r15,0xffff
    7c479daff369:	or     r14,r15
    7c479daff36c:	mov    r15,rbp
    7c479daff36f:	shr    r15,0x28
    7c479daff373:	and    r15,0xff
    7c479daff37a:	and    r15,0xffff
    7c479daff381:	shl    r15,0x10
    7c479daff385:	or     r14,r15
    7c479daff388:	mov    r15,rbp
    7c479daff38b:	shr    r15,0x30
    7c479daff38f:	and    r15,0xff
    7c479daff396:	and    r15,0xffff
    7c479daff39d:	shl    r15,0x20
    7c479daff3a1:	or     r14,r15
    7c479daff3a4:	shr    rbp,0x38
    7c479daff3a8:	and    rbp,0xff
    7c479daff3af:	and    rbp,0xffff
    7c479daff3b6:	shl    rbp,0x30
    7c479daff3ba:	or     r14,rbp
    7c479daff3bd:	mov    r15d,0x0
    7c479daff3c3:	mov    rbp,QWORD PTR [rsp+0x20]
    7c479daff3c8:	and    rbp,0xff
    7c479daff3cf:	and    rbp,0xffff
    7c479daff3d6:	mov    r9,r15
    7c479daff3d9:	or     r9,rbp
    7c479daff3dc:	mov    rbp,QWORD PTR [rsp+0x20]
    7c479daff3e1:	shr    rbp,0x8
    7c479daff3e5:	and    rbp,0xff
    7c479daff3ec:	and    rbp,0xffff
    7c479daff3f3:	shl    rbp,0x10
    7c479daff3f7:	or     r9,rbp
    7c479daff3fa:	mov    rbp,QWORD PTR [rsp+0x20]
    7c479daff3ff:	shr    rbp,0x10
    7c479daff403:	and    rbp,0xff
    7c479daff40a:	and    rbp,0xffff
    7c479daff411:	shl    rbp,0x20
    7c479daff415:	or     r9,rbp
    7c479daff418:	mov    rbp,QWORD PTR [rsp+0x20]
    7c479daff41d:	shr    rbp,0x18
    7c479daff421:	and    rbp,0xff
    7c479daff428:	and    rbp,0xffff
    7c479daff42f:	shl    rbp,0x30
    7c479daff433:	mov    rax,r9
    7c479daff436:	or     rax,rbp
    7c479daff439:	mov    QWORD PTR [rsp+0x78],rax
    7c479daff43e:	mov    rbp,QWORD PTR [rsp+0x20]
    7c479daff443:	shr    rbp,0x20
    7c479daff447:	and    rbp,0xff
    7c479daff44e:	and    rbp,0xffff
    7c479daff455:	or     r15,rbp
    7c479daff458:	mov    rbp,QWORD PTR [rsp+0x20]
    7c479daff45d:	shr    rbp,0x28
    7c479daff461:	and    rbp,0xff
    7c479daff468:	and    rbp,0xffff
    7c479daff46f:	shl    rbp,0x10
    7c479daff473:	or     r15,rbp
    7c479daff476:	mov    rbp,QWORD PTR [rsp+0x20]
    7c479daff47b:	shr    rbp,0x30
    7c479daff47f:	and    rbp,0xff
    7c479daff486:	and    rbp,0xffff
    7c479daff48d:	shl    rbp,0x20
    7c479daff491:	or     r15,rbp
    7c479daff494:	mov    rbp,QWORD PTR [rsp+0x20]
    7c479daff499:	shr    rbp,0x38
    7c479daff49d:	and    rbp,0xff
    7c479daff4a4:	and    rbp,0xffff
    7c479daff4ab:	shl    rbp,0x30
    7c479daff4af:	mov    rax,r15
    7c479daff4b2:	or     rax,rbp
    7c479daff4b5:	mov    QWORD PTR [rsp+0x70],rax
    7c479daff4ba:	mov    rax,QWORD PTR [rsp+0x78]
    7c479daff4bf:	mov    QWORD PTR [r12+0x250],rax
    7c479daff4c7:	mov    rax,QWORD PTR [rsp+0x70]
    7c479daff4cc:	mov    QWORD PTR [r12+0x258],rax
    7c479daff4d4:	mov    ebp,0x0
    7c479daff4d9:	mov    r15,QWORD PTR [rsp+0x40]
    7c479daff4de:	and    r15,0xff
    7c479daff4e5:	and    r15,0xffff
    7c479daff4ec:	mov    r9,rbp
    7c479daff4ef:	or     r9,r15
    7c479daff4f2:	mov    r15,QWORD PTR [rsp+0x40]
    7c479daff4f7:	shr    r15,0x8
    7c479daff4fb:	and    r15,0xff
    7c479daff502:	and    r15,0xffff
    7c479daff509:	shl    r15,0x10
    7c479daff50d:	or     r9,r15
    7c479daff510:	mov    r15,QWORD PTR [rsp+0x40]
    7c479daff515:	shr    r15,0x10
    7c479daff519:	and    r15,0xff
    7c479daff520:	and    r15,0xffff
    7c479daff527:	shl    r15,0x20
    7c479daff52b:	or     r9,r15
    7c479daff52e:	mov    r15,QWORD PTR [rsp+0x40]
    7c479daff533:	shr    r15,0x18
    7c479daff537:	and    r15,0xff
    7c479daff53e:	and    r15,0xffff
    7c479daff545:	shl    r15,0x30
    7c479daff549:	mov    rax,r9
    7c479daff54c:	or     rax,r15
    7c479daff54f:	mov    QWORD PTR [rsp+0x80],rax
    7c479daff557:	mov    r15,QWORD PTR [rsp+0x40]
    7c479daff55c:	shr    r15,0x20
    7c479daff560:	and    r15,0xff
    7c479daff567:	and    r15,0xffff
    7c479daff56e:	or     rbp,r15
    7c479daff571:	mov    r15,QWORD PTR [rsp+0x40]
    7c479daff576:	shr    r15,0x28
    7c479daff57a:	and    r15,0xff
    7c479daff581:	and    r15,0xffff
    7c479daff588:	shl    r15,0x10
    7c479daff58c:	or     rbp,r15
    7c479daff58f:	mov    r15,QWORD PTR [rsp+0x40]
    7c479daff594:	shr    r15,0x30
    7c479daff598:	and    r15,0xff
    7c479daff59f:	and    r15,0xffff
    7c479daff5a6:	shl    r15,0x20
    7c479daff5aa:	or     rbp,r15
    7c479daff5ad:	mov    r15,QWORD PTR [rsp+0x40]
    7c479daff5b2:	shr    r15,0x38
    7c479daff5b6:	and    r15,0xff
    7c479daff5bd:	and    r15,0xffff
    7c479daff5c4:	shl    r15,0x30
    7c479daff5c8:	mov    rax,rbp
    7c479daff5cb:	or     rax,r15
    7c479daff5ce:	mov    QWORD PTR [rsp+0x88],rax
    7c479daff5d6:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    7c479daff5e0:	pxor   xmm0,xmm0
    7c479daff5e4:	movdqa xmm3,xmm0
    7c479daff5e8:	movdqa xmm0,xmm2
    7c479daff5ec:	movdqa xmm1,xmm3
    7c479daff5f0:	punpcklwd xmm0,xmm1
    7c479daff5f4:	movdqa xmm4,xmm0
    7c479daff5f8:	movdqa xmm0,xmm4
    7c479daff5fc:	pslld  xmm0,0x10
    7c479daff601:	movdqa xmm3,xmm0
    7c479daff605:	mov    r15d,0x0
    7c479daff60b:	mov    r9,QWORD PTR [rsp+0x50]
    7c479daff610:	and    r9,0xffff
    7c479daff617:	shl    r9,0x8
    7c479daff61b:	mov    ecx,0xffffffff
    7c479daff620:	and    r9,rcx
    7c479daff623:	mov    rbp,r15
    7c479daff626:	or     rbp,r9
    7c479daff629:	mov    r9,QWORD PTR [rsp+0x50]
    7c479daff62e:	shr    r9,0x10
    7c479daff632:	and    r9,0xffff
    7c479daff639:	shl    r9,0x8
    7c479daff63d:	mov    ecx,0xffffffff
    7c479daff642:	and    r9,rcx
    7c479daff645:	shl    r9,0x20
    7c479daff649:	or     rbp,r9
    7c479daff64c:	mov    r9,QWORD PTR [rsp+0x50]
    7c479daff651:	shr    r9,0x20
    7c479daff655:	and    r9,0xffff
    7c479daff65c:	shl    r9,0x8
    7c479daff660:	mov    ecx,0xffffffff
    7c479daff665:	and    r9,rcx
    7c479daff668:	or     r15,r9
    7c479daff66b:	mov    r9,QWORD PTR [rsp+0x50]
    7c479daff670:	shr    r9,0x30
    7c479daff674:	and    r9,0xffff
    7c479daff67b:	shl    r9,0x8
    7c479daff67f:	mov    ecx,0xffffffff
    7c479daff684:	and    r9,rcx
    7c479daff687:	shl    r9,0x20
    7c479daff68b:	or     r15,r9
    7c479daff68e:	mov    QWORD PTR [r12+0x240],rbp
    7c479daff696:	mov    QWORD PTR [r12+0x248],r15
    7c479daff69e:	mov    r15d,0x0
    7c479daff6a4:	mov    rbp,QWORD PTR [rsp+0x60]
    7c479daff6a9:	and    rbp,0xffff
    7c479daff6b0:	mov    ecx,0xffffffff
    7c479daff6b5:	and    rbp,rcx
    7c479daff6b8:	mov    r9,r15
    7c479daff6bb:	or     r9,rbp
    7c479daff6be:	mov    rbp,QWORD PTR [rsp+0x60]
    7c479daff6c3:	shr    rbp,0x10
    7c479daff6c7:	and    rbp,0xffff
    7c479daff6ce:	mov    ecx,0xffffffff
    7c479daff6d3:	and    rbp,rcx
    7c479daff6d6:	shl    rbp,0x20
    7c479daff6da:	or     r9,rbp
    7c479daff6dd:	mov    rbp,QWORD PTR [rsp+0x60]
    7c479daff6e2:	shr    rbp,0x20
    7c479daff6e6:	and    rbp,0xffff
    7c479daff6ed:	mov    ecx,0xffffffff
    7c479daff6f2:	and    rbp,rcx
    7c479daff6f5:	or     r15,rbp
    7c479daff6f8:	mov    rbp,QWORD PTR [rsp+0x60]
    7c479daff6fd:	shr    rbp,0x30
    7c479daff701:	and    rbp,0xffff
    7c479daff708:	mov    ecx,0xffffffff
    7c479daff70d:	and    rbp,rcx
    7c479daff710:	shl    rbp,0x20
    7c479daff714:	or     r15,rbp
    7c479daff717:	mov    QWORD PTR [r12+0x260],r9
    7c479daff71f:	mov    QWORD PTR [r12+0x268],r15
    7c479daff727:	mov    r15d,0x0
    7c479daff72d:	mov    rbp,r13
    7c479daff730:	and    rbp,0xffff
    7c479daff737:	mov    ecx,0xffffffff
    7c479daff73c:	and    rbp,rcx
    7c479daff73f:	mov    r9,r15
    7c479daff742:	or     r9,rbp
    7c479daff745:	mov    rbp,r13
    7c479daff748:	shr    rbp,0x10
    7c479daff74c:	and    rbp,0xffff
    7c479daff753:	mov    ecx,0xffffffff
    7c479daff758:	and    rbp,rcx
    7c479daff75b:	shl    rbp,0x20
    7c479daff75f:	or     r9,rbp
    7c479daff762:	mov    rbp,r13
    7c479daff765:	shr    rbp,0x20
    7c479daff769:	and    rbp,0xffff
    7c479daff770:	mov    ecx,0xffffffff
    7c479daff775:	and    rbp,rcx
    7c479daff778:	or     r15,rbp
    7c479daff77b:	shr    r13,0x30
    7c479daff77f:	and    r13,0xffff
    7c479daff786:	mov    ecx,0xffffffff
    7c479daff78b:	and    r13,rcx
    7c479daff78e:	shl    r13,0x20
    7c479daff792:	or     r15,r13
    7c479daff795:	mov    QWORD PTR [r12+0x270],r9
    7c479daff79d:	mov    QWORD PTR [r12+0x278],r15
    7c479daff7a5:	mov    r13d,0x0
    7c479daff7ab:	mov    r15,QWORD PTR [rsp+0x58]
    7c479daff7b0:	and    r15,0xffff
    7c479daff7b7:	mov    ecx,0xffffffff
    7c479daff7bc:	and    r15,rcx
    7c479daff7bf:	mov    rbp,r13
    7c479daff7c2:	or     rbp,r15
    7c479daff7c5:	mov    r15,QWORD PTR [rsp+0x58]
    7c479daff7ca:	shr    r15,0x10
    7c479daff7ce:	and    r15,0xffff
    7c479daff7d5:	mov    ecx,0xffffffff
    7c479daff7da:	and    r15,rcx
    7c479daff7dd:	shl    r15,0x20
    7c479daff7e1:	or     rbp,r15
    7c479daff7e4:	mov    r15,QWORD PTR [rsp+0x58]
    7c479daff7e9:	shr    r15,0x20
    7c479daff7ed:	and    r15,0xffff
    7c479daff7f4:	mov    ecx,0xffffffff
    7c479daff7f9:	and    r15,rcx
    7c479daff7fc:	or     r13,r15
    7c479daff7ff:	mov    r15,QWORD PTR [rsp+0x58]
    7c479daff804:	shr    r15,0x30
    7c479daff808:	and    r15,0xffff
    7c479daff80f:	mov    ecx,0xffffffff
    7c479daff814:	and    r15,rcx
    7c479daff817:	shl    r15,0x20
    7c479daff81b:	or     r13,r15
    7c479daff81e:	mov    QWORD PTR [r12+0x170],rbp
    7c479daff826:	mov    QWORD PTR [r12+0x178],r13
    7c479daff82e:	movdqu xmm4,XMMWORD PTR [r12+0x210]
    7c479daff838:	pxor   xmm0,xmm0
    7c479daff83c:	movdqa xmm5,xmm0
    7c479daff840:	movdqa xmm0,xmm4
    7c479daff844:	movdqa xmm1,xmm5
    7c479daff848:	punpckhwd xmm0,xmm1
    7c479daff84c:	movdqa xmm6,xmm0
    7c479daff850:	movdqa xmm0,xmm6
    7c479daff854:	pslld  xmm0,0x10
    7c479daff859:	movdqa xmm5,xmm0
    7c479daff85d:	movdqu XMMWORD PTR [r12+0x280],xmm5
    7c479daff867:	mov    r13d,0x0
    7c479daff86d:	mov    r15,QWORD PTR [rsp+0x68]
    7c479daff872:	and    r15,0xffff
    7c479daff879:	mov    ecx,0xffffffff
    7c479daff87e:	and    r15,rcx
    7c479daff881:	mov    rbp,r13
    7c479daff884:	or     rbp,r15
    7c479daff887:	mov    r15,QWORD PTR [rsp+0x68]
    7c479daff88c:	shr    r15,0x10
    7c479daff890:	and    r15,0xffff
    7c479daff897:	mov    ecx,0xffffffff
    7c479daff89c:	and    r15,rcx
    7c479daff89f:	shl    r15,0x20
    7c479daff8a3:	or     rbp,r15
    7c479daff8a6:	mov    r15,QWORD PTR [rsp+0x68]
    7c479daff8ab:	shr    r15,0x20
    7c479daff8af:	and    r15,0xffff
    7c479daff8b6:	mov    ecx,0xffffffff
    7c479daff8bb:	and    r15,rcx
    7c479daff8be:	or     r13,r15
    7c479daff8c1:	mov    r15,QWORD PTR [rsp+0x68]
    7c479daff8c6:	shr    r15,0x30
    7c479daff8ca:	and    r15,0xffff
    7c479daff8d1:	mov    ecx,0xffffffff
    7c479daff8d6:	and    r15,rcx
    7c479daff8d9:	shl    r15,0x20
    7c479daff8dd:	or     r13,r15
    7c479daff8e0:	mov    QWORD PTR [r12+0x180],rbp
    7c479daff8e8:	mov    QWORD PTR [r12+0x188],r13
    7c479daff8f0:	pxor   xmm0,xmm0
    7c479daff8f4:	movdqa xmm6,xmm0
    7c479daff8f8:	movdqa xmm0,xmm4
    7c479daff8fc:	movdqa xmm1,xmm6
    7c479daff900:	punpcklwd xmm0,xmm1
    7c479daff904:	movdqa xmm7,xmm0
    7c479daff908:	movdqa xmm0,xmm7
    7c479daff90c:	pslld  xmm0,0x10
    7c479daff911:	movdqa xmm4,xmm0
    7c479daff915:	pxor   xmm0,xmm0
    7c479daff919:	movdqa xmm6,xmm0
    7c479daff91d:	movdqa xmm0,xmm2
    7c479daff921:	movdqa xmm1,xmm6
    7c479daff925:	punpckhwd xmm0,xmm1
    7c479daff929:	movdqa xmm7,xmm0
    7c479daff92d:	movdqa xmm0,xmm7
    7c479daff931:	pslld  xmm0,0x10
    7c479daff936:	movdqa xmm2,xmm0
    7c479daff93a:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    7c479daff944:	movdqa xmm1,xmm6
    7c479daff948:	por    xmm3,xmm1
    7c479daff94c:	movdqu XMMWORD PTR [r12+0x230],xmm3
    7c479daff956:	mov    r13d,0x0
    7c479daff95c:	mov    r15,r14
    7c479daff95f:	and    r15,0xffff
    7c479daff966:	shl    r15,0x8
    7c479daff96a:	mov    ecx,0xffffffff
    7c479daff96f:	and    r15,rcx
    7c479daff972:	mov    rbp,r13
    7c479daff975:	or     rbp,r15
    7c479daff978:	mov    r15,r14
    7c479daff97b:	shr    r15,0x10
    7c479daff97f:	and    r15,0xffff
    7c479daff986:	shl    r15,0x8
    7c479daff98a:	mov    ecx,0xffffffff
    7c479daff98f:	and    r15,rcx
    7c479daff992:	shl    r15,0x20
    7c479daff996:	or     rbp,r15
    7c479daff999:	mov    r15,r14
    7c479daff99c:	shr    r15,0x20
    7c479daff9a0:	and    r15,0xffff
    7c479daff9a7:	shl    r15,0x8
    7c479daff9ab:	mov    ecx,0xffffffff
    7c479daff9b0:	and    r15,rcx
    7c479daff9b3:	or     r13,r15
    7c479daff9b6:	shr    r14,0x30
    7c479daff9ba:	and    r14,0xffff
    7c479daff9c1:	shl    r14,0x8
    7c479daff9c5:	mov    ecx,0xffffffff
    7c479daff9ca:	and    r14,rcx
    7c479daff9cd:	shl    r14,0x20
    7c479daff9d1:	or     r13,r14
    7c479daff9d4:	mov    QWORD PTR [r12+0x240],rbp
    7c479daff9dc:	mov    QWORD PTR [r12+0x248],r13
    7c479daff9e4:	mov    r13d,0x0
    7c479daff9ea:	mov    r14,r8
    7c479daff9ed:	and    r14,0xffff
    7c479daff9f4:	shl    r14,0x8
    7c479daff9f8:	mov    ecx,0xffffffff
    7c479daff9fd:	and    r14,rcx
    7c479daffa00:	mov    r15,r13
    7c479daffa03:	or     r15,r14
    7c479daffa06:	mov    r14,r8
    7c479daffa09:	shr    r14,0x10
    7c479daffa0d:	and    r14,0xffff
    7c479daffa14:	shl    r14,0x8
    7c479daffa18:	mov    ecx,0xffffffff
    7c479daffa1d:	and    r14,rcx
    7c479daffa20:	shl    r14,0x20
    7c479daffa24:	or     r15,r14
    7c479daffa27:	mov    r14,r8
    7c479daffa2a:	shr    r14,0x20
    7c479daffa2e:	and    r14,0xffff
    7c479daffa35:	shl    r14,0x8
    7c479daffa39:	mov    ecx,0xffffffff
    7c479daffa3e:	and    r14,rcx
    7c479daffa41:	or     r13,r14
    7c479daffa44:	shr    r8,0x30
    7c479daffa48:	and    r8,0xffff
    7c479daffa4f:	shl    r8,0x8
    7c479daffa53:	mov    ecx,0xffffffff
    7c479daffa58:	and    r8,rcx
    7c479daffa5b:	shl    r8,0x20
    7c479daffa5f:	or     r13,r8
    7c479daffa62:	mov    QWORD PTR [r12+0x220],r15
    7c479daffa6a:	mov    QWORD PTR [r12+0x228],r13
    7c479daffa72:	mov    r13d,0x0
    7c479daffa78:	mov    r14,QWORD PTR [rsp+0x48]
    7c479daffa7d:	and    r14,0xffff
    7c479daffa84:	shl    r14,0x8
    7c479daffa88:	mov    ecx,0xffffffff
    7c479daffa8d:	and    r14,rcx
    7c479daffa90:	mov    r15,r13
    7c479daffa93:	or     r15,r14
    7c479daffa96:	mov    r14,QWORD PTR [rsp+0x48]
    7c479daffa9b:	shr    r14,0x10
    7c479daffa9f:	and    r14,0xffff
    7c479daffaa6:	shl    r14,0x8
    7c479daffaaa:	mov    ecx,0xffffffff
    7c479daffaaf:	and    r14,rcx
    7c479daffab2:	shl    r14,0x20
    7c479daffab6:	or     r15,r14
    7c479daffab9:	mov    r14,QWORD PTR [rsp+0x48]
    7c479daffabe:	shr    r14,0x20
    7c479daffac2:	and    r14,0xffff
    7c479daffac9:	shl    r14,0x8
    7c479daffacd:	mov    ecx,0xffffffff
    7c479daffad2:	and    r14,rcx
    7c479daffad5:	or     r13,r14
    7c479daffad8:	mov    r14,QWORD PTR [rsp+0x48]
    7c479daffadd:	shr    r14,0x30
    7c479daffae1:	and    r14,0xffff
    7c479daffae8:	shl    r14,0x8
    7c479daffaec:	mov    ecx,0xffffffff
    7c479daffaf1:	and    r14,rcx
    7c479daffaf4:	shl    r14,0x20
    7c479daffaf8:	or     r13,r14
    7c479daffafb:	mov    QWORD PTR [r12+0x160],r15
    7c479daffb03:	mov    QWORD PTR [r12+0x168],r13
    7c479daffb0b:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    7c479daffb15:	movdqa xmm0,xmm6
    7c479daffb19:	pslld  xmm0,0x18
    7c479daffb1e:	movdqa xmm7,xmm0
    7c479daffb22:	movdqu XMMWORD PTR [r12+0x170],xmm7
    7c479daffb2c:	movdqu xmm6,XMMWORD PTR [r12+0x270]
    7c479daffb36:	movdqa xmm0,xmm6
    7c479daffb3a:	pslld  xmm0,0x18
    7c479daffb3f:	movdqa xmm8,xmm0
    7c479daffb44:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    7c479daffb4e:	movdqa xmm0,xmm6
    7c479daffb52:	pslld  xmm0,0x18
    7c479daffb57:	movdqa xmm9,xmm0
    7c479daffb5c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    7c479daffb66:	mov    r13d,0x0
    7c479daffb6c:	mov    r14,QWORD PTR [rsp+0x78]
    7c479daffb71:	and    r14,0xffff
    7c479daffb78:	mov    ecx,0xffffffff
    7c479daffb7d:	and    r14,rcx
    7c479daffb80:	mov    r15,r13
    7c479daffb83:	or     r15,r14
    7c479daffb86:	mov    r14,QWORD PTR [rsp+0x78]
    7c479daffb8b:	shr    r14,0x10
    7c479daffb8f:	and    r14,0xffff
    7c479daffb96:	mov    ecx,0xffffffff
    7c479daffb9b:	and    r14,rcx
    7c479daffb9e:	shl    r14,0x20
    7c479daffba2:	or     r15,r14
    7c479daffba5:	mov    r14,QWORD PTR [rsp+0x78]
    7c479daffbaa:	shr    r14,0x20
    7c479daffbae:	and    r14,0xffff
    7c479daffbb5:	mov    ecx,0xffffffff
    7c479daffbba:	and    r14,rcx
    7c479daffbbd:	or     r13,r14
    7c479daffbc0:	mov    r14,QWORD PTR [rsp+0x78]
    7c479daffbc5:	shr    r14,0x30
    7c479daffbc9:	and    r14,0xffff
    7c479daffbd0:	mov    ecx,0xffffffff
    7c479daffbd5:	and    r14,rcx
    7c479daffbd8:	shl    r14,0x20
    7c479daffbdc:	or     r13,r14
    7c479daffbdf:	mov    QWORD PTR [r12+0x140],r15
    7c479daffbe7:	mov    QWORD PTR [r12+0x148],r13
    7c479daffbef:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    7c479daffbf9:	movdqa xmm1,xmm6
    7c479daffbfd:	por    xmm5,xmm1
    7c479daffc01:	movdqu xmm6,XMMWORD PTR [r12+0x220]
    7c479daffc0b:	movdqa xmm1,xmm6
    7c479daffc0f:	por    xmm4,xmm1
    7c479daffc13:	movdqu XMMWORD PTR [r12+0x210],xmm4
    7c479daffc1d:	movdqu xmm6,XMMWORD PTR [r12+0x260]
    7c479daffc27:	movdqa xmm0,xmm6
    7c479daffc2b:	pslld  xmm0,0x18
    7c479daffc30:	movdqa xmm10,xmm0
    7c479daffc35:	movdqu XMMWORD PTR [r12+0x220],xmm10
    7c479daffc3f:	movdqu xmm6,XMMWORD PTR [r12+0x160]
    7c479daffc49:	movdqa xmm1,xmm6
    7c479daffc4d:	por    xmm2,xmm1
    7c479daffc51:	movdqa xmm1,xmm7
    7c479daffc55:	por    xmm3,xmm1
    7c479daffc59:	movdqu XMMWORD PTR [r12+0x160],xmm3
    7c479daffc63:	mov    r13d,0x0
    7c479daffc69:	mov    r14,QWORD PTR [rsp+0x88]
    7c479daffc71:	and    r14,0xffff
    7c479daffc78:	mov    ecx,0xffffffff
    7c479daffc7d:	and    r14,rcx
    7c479daffc80:	mov    r15,r13
    7c479daffc83:	or     r15,r14
    7c479daffc86:	mov    r14,QWORD PTR [rsp+0x88]
    7c479daffc8e:	shr    r14,0x10
    7c479daffc92:	and    r14,0xffff
    7c479daffc99:	mov    ecx,0xffffffff
    7c479daffc9e:	and    r14,rcx
    7c479daffca1:	shl    r14,0x20
    7c479daffca5:	or     r15,r14
    7c479daffca8:	mov    r14,QWORD PTR [rsp+0x88]
    7c479daffcb0:	shr    r14,0x20
    7c479daffcb4:	and    r14,0xffff
    7c479daffcbb:	mov    ecx,0xffffffff
    7c479daffcc0:	and    r14,rcx
    7c479daffcc3:	or     r13,r14
    7c479daffcc6:	mov    r14,QWORD PTR [rsp+0x88]
    7c479daffcce:	shr    r14,0x30
    7c479daffcd2:	and    r14,0xffff
    7c479daffcd9:	mov    ecx,0xffffffff
    7c479daffcde:	and    r14,rcx
    7c479daffce1:	shl    r14,0x20
    7c479daffce5:	or     r13,r14
    7c479daffce8:	mov    QWORD PTR [r12+0x170],r15
    7c479daffcf0:	mov    QWORD PTR [r12+0x178],r13
    7c479daffcf8:	mov    r13d,0x0
    7c479daffcfe:	mov    r14,QWORD PTR [rsp+0x80]
    7c479daffd06:	and    r14,0xffff
    7c479daffd0d:	mov    ecx,0xffffffff
    7c479daffd12:	and    r14,rcx
    7c479daffd15:	mov    r15,r13
    7c479daffd18:	or     r15,r14
    7c479daffd1b:	mov    r14,QWORD PTR [rsp+0x80]
    7c479daffd23:	shr    r14,0x10
    7c479daffd27:	and    r14,0xffff
    7c479daffd2e:	mov    ecx,0xffffffff
    7c479daffd33:	and    r14,rcx
    7c479daffd36:	shl    r14,0x20
    7c479daffd3a:	or     r15,r14
    7c479daffd3d:	mov    r14,QWORD PTR [rsp+0x80]
    7c479daffd45:	shr    r14,0x20
    7c479daffd49:	and    r14,0xffff
    7c479daffd50:	mov    ecx,0xffffffff
    7c479daffd55:	and    r14,rcx
    7c479daffd58:	or     r13,r14
    7c479daffd5b:	mov    r14,QWORD PTR [rsp+0x80]
    7c479daffd63:	shr    r14,0x30
    7c479daffd67:	and    r14,0xffff
    7c479daffd6e:	mov    ecx,0xffffffff
    7c479daffd73:	and    r14,rcx
    7c479daffd76:	shl    r14,0x20
    7c479daffd7a:	or     r13,r14
    7c479daffd7d:	mov    QWORD PTR [r12+0x110],r15
    7c479daffd85:	mov    QWORD PTR [r12+0x118],r13
    7c479daffd8d:	movdqa xmm1,xmm8
    7c479daffd92:	por    xmm5,xmm1
    7c479daffd96:	movdqa xmm1,xmm9
    7c479daffd9b:	por    xmm4,xmm1
    7c479daffd9f:	mov    r13d,0x0
    7c479daffda5:	mov    r14,QWORD PTR [rsp+0x70]
    7c479daffdaa:	and    r14,0xffff
    7c479daffdb1:	mov    ecx,0xffffffff
    7c479daffdb6:	and    r14,rcx
    7c479daffdb9:	mov    r15,r13
    7c479daffdbc:	or     r15,r14
    7c479daffdbf:	mov    r14,QWORD PTR [rsp+0x70]
    7c479daffdc4:	shr    r14,0x10
    7c479daffdc8:	and    r14,0xffff
    7c479daffdcf:	mov    ecx,0xffffffff
    7c479daffdd4:	and    r14,rcx
    7c479daffdd7:	shl    r14,0x20
    7c479daffddb:	or     r15,r14
    7c479daffdde:	mov    r14,QWORD PTR [rsp+0x70]
    7c479daffde3:	shr    r14,0x20
    7c479daffde7:	and    r14,0xffff
    7c479daffdee:	mov    ecx,0xffffffff
    7c479daffdf3:	and    r14,rcx
    7c479daffdf6:	or     r13,r14
    7c479daffdf9:	mov    r14,QWORD PTR [rsp+0x70]
    7c479daffdfe:	shr    r14,0x30
    7c479daffe02:	and    r14,0xffff
    7c479daffe09:	mov    ecx,0xffffffff
    7c479daffe0e:	and    r14,rcx
    7c479daffe11:	shl    r14,0x20
    7c479daffe15:	or     r13,r14
    7c479daffe18:	mov    QWORD PTR [r12+0x180],r15
    7c479daffe20:	mov    QWORD PTR [r12+0x188],r13
    7c479daffe28:	movdqa xmm1,xmm10
    7c479daffe2d:	por    xmm2,xmm1
    7c479daffe31:	movdqu XMMWORD PTR [r12+0x150],xmm2
    7c479daffe3b:	movdqu xmm6,XMMWORD PTR [r12+0x140]
    7c479daffe45:	movdqa xmm1,xmm6
    7c479daffe49:	por    xmm3,xmm1
    7c479daffe4d:	movdqu XMMWORD PTR [r12+0x140],xmm3
    7c479daffe57:	movdqu xmm6,XMMWORD PTR [r12+0x110]
    7c479daffe61:	movdqa xmm1,xmm6
    7c479daffe65:	por    xmm4,xmm1
    7c479daffe69:	movdqu XMMWORD PTR [r12+0x110],xmm4
    7c479daffe73:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    7c479daffe7d:	movdqa xmm1,xmm6
    7c479daffe81:	por    xmm5,xmm1
    7c479daffe85:	movdqu XMMWORD PTR [r12+0x120],xmm5
    7c479daffe8f:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    7c479daffe99:	movdqa xmm1,xmm6
    7c479daffe9d:	por    xmm2,xmm1
    7c479daffea1:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c479daffeab:	mov    r13,QWORD PTR [r12+0xf8]
    7c479daffeb3:	mov    r14,r13
    7c479daffeb6:	add    r14,0x20
    7c479daffeba:	mov    r15,r14
    7c479daffebd:	add    r15,0x10
    7c479daffec1:	movdqu XMMWORD PTR [r14],xmm4
    7c479daffec6:	mov    r14d,0x0
    7c479daffecc:	mov    DWORD PTR [r12+0x32c],r14d
    7c479daffed4:	movdqu XMMWORD PTR [r15],xmm5
    7c479daffed9:	mov    r14,r13
    7c479daffedc:	add    r14,0x10
    7c479daffee0:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7c479daffee6:	movdqu XMMWORD PTR [r14],xmm2
    7c479daffeeb:	mov    r14d,DWORD PTR [r13+0x0]
    7c479daffeef:	mov    QWORD PTR [r12+0x60],r14
    7c479daffef4:	jmp    0x7c479daffef9
    7c479daffef9:	mov    r13,QWORD PTR [r12+0x58]
    7c479daffefe:	mov    r14,QWORD PTR [r12+0x48]
    7c479dafff03:	add    r14,r13
    7c479dafff06:	mov    QWORD PTR [r12+0x68],r14
    7c479dafff0b:	add    r13,0x4
    7c479dafff0f:	mov    QWORD PTR [r12+0x58],r13
    7c479dafff14:	mov    r15,r14
    7c479dafff17:	add    r15,0x4
    7c479dafff1b:	mov    eax,DWORD PTR [r15]
    7c479dafff1e:	mov    QWORD PTR [r12+0x70],rax
    7c479dafff23:	mov    r15,r14
    7c479dafff26:	add    r15,0x38
    7c479dafff2a:	mov    r8d,DWORD PTR [r15]
    7c479dafff2d:	mov    QWORD PTR [r12+0x78],r8
    7c479dafff32:	mov    r15,r14
    7c479dafff35:	add    r15,0x24
    7c479dafff39:	mov    r9d,DWORD PTR [r15]
    7c479dafff3c:	mov    QWORD PTR [r12+0x90],r9
    7c479dafff44:	sub    r13,0xc0
    7c479dafff4b:	setne  BYTE PTR [rsp+0xb8]
    7c479dafff53:	mov    r11,rax
    7c479dafff56:	lahf
    7c479dafff57:	seto   al
    7c479dafff5a:	mov    WORD PTR [rsp+0xb0],ax
    7c479dafff62:	mov    rax,r11
    7c479dafff65:	mov    r13d,DWORD PTR [r12+0x70]
    7c479dafff6a:	mov    r13d,r13d
    7c479dafff6d:	mov    r13d,r13d
    7c479dafff70:	ror    r13d,0x7
    7c479dafff74:	mov    QWORD PTR [r12+0x80],r13
    7c479dafff7c:	mov    r15d,r8d
    7c479dafff7f:	mov    r15d,r15d
    7c479dafff82:	ror    r15d,0x11
    7c479dafff86:	mov    QWORD PTR [r12+0x88],r15
    7c479dafff8e:	mov    ebp,DWORD PTR [r12+0x60]
    7c479dafff93:	add    r9d,ebp
    7c479dafff96:	mov    QWORD PTR [r12+0x60],r9
    7c479dafff9b:	mov    ebp,DWORD PTR [r12+0x70]
    7c479dafffa0:	mov    ebp,ebp
    7c479dafffa2:	mov    ebp,ebp
    7c479dafffa4:	ror    ebp,0x12
    7c479dafffa7:	xor    r13d,ebp
    7c479dafffaa:	mov    QWORD PTR [r12+0x80],r13
    7c479dafffb2:	mov    ebp,r8d
    7c479dafffb5:	mov    ebp,ebp
    7c479dafffb7:	ror    ebp,0x13
    7c479dafffba:	xor    r15d,ebp
    7c479dafffbd:	mov    QWORD PTR [r12+0x88],r15
    7c479dafffc5:	mov    ebp,DWORD PTR [r12+0x70]
    7c479dafffca:	mov    ebp,ebp
    7c479dafffcc:	mov    ebp,ebp
    7c479dafffce:	shr    ebp,0x3
    7c479dafffd1:	xor    r13d,ebp
    7c479dafffd4:	mov    QWORD PTR [r12+0x80],r13
    7c479dafffdc:	mov    r8d,r8d
    7c479dafffdf:	shr    r8d,0xa
    7c479dafffe3:	xor    r15d,r8d
    7c479dafffe6:	mov    QWORD PTR [r12+0x78],r15
    7c479dafffeb:	add    r9d,r13d
    7c479dafffee:	mov    QWORD PTR [r12+0x60],r9
    7c479daffff3:	add    r9d,r15d
    7c479daffff6:	mov    QWORD PTR [r12+0x60],r9
    7c479daffffb:	add    r14,0x40
    7c479dafffff:	mov    DWORD PTR [r14],r9d
    7c479db00002:	mov    r13d,0x0
    7c479db00008:	mov    DWORD PTR [r12+0x32c],r13d
    7c479db00010:	mov    r13d,0x0
    7c479db00016:	mov    ecx,DWORD PTR [r12+0x70]
    7c479db0001b:	mov    ecx,ecx
    7c479db0001d:	mov    r14d,r13d
    7c479db00020:	or     r14d,ecx
    7c479db00023:	mov    QWORD PTR [r12+0x60],r14
    7c479db00028:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db00030:	jrcxz  0x7c479db00037
    7c479db00032:	jmp    0x7c479db0081a
    7c479db00037:	cmp    BYTE PTR [rsp+0xb8],0x0
    7c479db0003f:	jne    0x7c479daffef9
    7c479db00045:	jmp    0x7c479db0004a
    7c479db0004a:	mov    r13,QWORD PTR [r12]
    7c479db0004e:	mov    r14,r13
    7c479db00051:	add    r14,0x4
    7c479db00055:	mov    r15d,DWORD PTR [r13+0x0]
    7c479db00059:	mov    ebp,DWORD PTR [r14]
    7c479db0005c:	mov    QWORD PTR [r12+0x78],r15
    7c479db00061:	mov    QWORD PTR [r12+0x80],rbp
    7c479db00069:	mov    r14,r13
    7c479db0006c:	add    r14,0x8
    7c479db00070:	mov    r8,r14
    7c479db00073:	add    r8,0x4
    7c479db00077:	mov    r9d,DWORD PTR [r14]
    7c479db0007a:	mov    eax,DWORD PTR [r8]
    7c479db0007d:	mov    QWORD PTR [rsp+0x90],rax
    7c479db00085:	mov    QWORD PTR [r12+0x70],r9
    7c479db0008a:	mov    rax,QWORD PTR [rsp+0x90]
    7c479db00092:	mov    QWORD PTR [r12+0x68],rax
    7c479db00097:	mov    r8,r13
    7c479db0009a:	add    r8,0x18
    7c479db0009e:	mov    r14,r8
    7c479db000a1:	add    r14,0x4
    7c479db000a5:	mov    eax,DWORD PTR [r8]
    7c479db000a8:	mov    QWORD PTR [rsp+0x98],rax
    7c479db000b0:	mov    r8d,DWORD PTR [r14]
    7c479db000b3:	mov    rax,QWORD PTR [rsp+0x98]
    7c479db000bb:	mov    QWORD PTR [r12+0x58],rax
    7c479db000c0:	mov    QWORD PTR [r12+0x60],r8
    7c479db000c5:	add    r13,0x10
    7c479db000c9:	mov    r14,r13
    7c479db000cc:	add    r14,0x4
    7c479db000d0:	mov    eax,DWORD PTR [r13+0x0]
    7c479db000d4:	mov    QWORD PTR [rsp+0xa0],rax
    7c479db000dc:	mov    eax,DWORD PTR [r14]
    7c479db000df:	mov    QWORD PTR [rsp+0xa8],rax
    7c479db000e7:	mov    rax,QWORD PTR [rsp+0xa0]
    7c479db000ef:	mov    QWORD PTR [r12+0x18],rax
    7c479db000f4:	mov    rax,QWORD PTR [rsp+0xa8]
    7c479db000fc:	mov    QWORD PTR [r12+0x90],rax
    7c479db00104:	mov    r14d,0x0
    7c479db0010a:	mov    QWORD PTR [r12+0x88],r14
    7c479db00112:	mov    r14d,0x0
    7c479db00118:	mov    r13d,r14d
    7c479db0011b:	or     r13d,r15d
    7c479db0011e:	mov    QWORD PTR [r12+0xa8],r13
    7c479db00126:	mov    r13d,0x0
    7c479db0012c:	mov    r14d,r13d
    7c479db0012f:	or     r14d,ebp
    7c479db00132:	mov    QWORD PTR [r12+0x38],r14
    7c479db00137:	mov    r13d,0x0
    7c479db0013d:	mov    r14d,r13d
    7c479db00140:	or     r14d,r9d
    7c479db00143:	mov    QWORD PTR [r12+0x98],r14
    7c479db0014b:	mov    r13d,0x0
    7c479db00151:	mov    ecx,DWORD PTR [rsp+0x90]
    7c479db00158:	mov    r14d,r13d
    7c479db0015b:	or     r14d,ecx
    7c479db0015e:	mov    QWORD PTR [r12+0x28],r14
    7c479db00163:	mov    r13d,0x0
    7c479db00169:	mov    r14d,r13d
    7c479db0016c:	or     r14d,r8d
    7c479db0016f:	mov    QWORD PTR [r12+0xb0],r14
    7c479db00177:	mov    r13d,0x0
    7c479db0017d:	mov    ecx,DWORD PTR [rsp+0x98]
    7c479db00184:	mov    r14d,r13d
    7c479db00187:	or     r14d,ecx
    7c479db0018a:	mov    QWORD PTR [r12+0xc0],r14
    7c479db00192:	mov    r13d,0x0
    7c479db00198:	mov    ecx,DWORD PTR [rsp+0xa8]
    7c479db0019f:	mov    r14d,r13d
    7c479db001a2:	or     r14d,ecx
    7c479db001a5:	mov    QWORD PTR [r12+0xc8],r14
    7c479db001ad:	mov    r13d,0x0
    7c479db001b3:	mov    ecx,DWORD PTR [rsp+0xa0]
    7c479db001ba:	mov    r14d,r13d
    7c479db001bd:	or     r14d,ecx
    7c479db001c0:	mov    QWORD PTR [r12+0xb8],r14
    7c479db001c8:	jmp    0x7c479db001cd
    7c479db001cd:	mov    r13d,0x0
    7c479db001d3:	mov    r14d,DWORD PTR [r12+0xb8]
    7c479db001db:	mov    eax,r13d
    7c479db001de:	or     eax,r14d
    7c479db001e1:	mov    QWORD PTR [r12+0x30],rax
    7c479db001e6:	mov    r13d,0x0
    7c479db001ec:	mov    ebp,DWORD PTR [r12+0xc0]
    7c479db001f4:	mov    eax,r13d
    7c479db001f7:	or     eax,ebp
    7c479db001f9:	mov    QWORD PTR [r12+0xa0],rax
    7c479db00201:	mov    r13d,0x0
    7c479db00207:	mov    ebp,DWORD PTR [r12+0x28]
    7c479db0020c:	mov    eax,r13d
    7c479db0020f:	or     eax,ebp
    7c479db00211:	mov    QWORD PTR [r12+0xc0],rax
    7c479db00219:	mov    r13d,0x0
    7c479db0021f:	mov    ebp,DWORD PTR [r12+0x98]
    7c479db00227:	mov    eax,r13d
    7c479db0022a:	or     eax,ebp
    7c479db0022c:	mov    QWORD PTR [r12+0x28],rax
    7c479db00231:	mov    r13d,0x0
    7c479db00237:	mov    ebp,DWORD PTR [r12+0x38]
    7c479db0023c:	mov    eax,r13d
    7c479db0023f:	or     eax,ebp
    7c479db00241:	mov    QWORD PTR [r12+0x98],rax
    7c479db00249:	mov    r13d,0x0
    7c479db0024f:	mov    ebp,DWORD PTR [r12+0xa8]
    7c479db00257:	mov    eax,r13d
    7c479db0025a:	or     eax,ebp
    7c479db0025c:	mov    QWORD PTR [r12+0x38],rax
    7c479db00261:	mov    r14d,r14d
    7c479db00264:	ror    r14d,0x6
    7c479db00268:	mov    QWORD PTR [r12+0xb8],r14
    7c479db00270:	mov    r13d,DWORD PTR [r12+0xc8]
    7c479db00278:	mov    ebp,DWORD PTR [r12+0x30]
    7c479db0027d:	mov    ebp,ebp
    7c479db0027f:	and    ebp,r13d
    7c479db00282:	mov    QWORD PTR [r12+0xa8],rbp
    7c479db0028a:	mov    r9d,DWORD PTR [r12+0x38]
    7c479db0028f:	mov    r9d,r9d
    7c479db00292:	mov    r9d,r9d
    7c479db00295:	ror    r9d,0x2
    7c479db00299:	mov    QWORD PTR [r12+0xd0],r9
    7c479db002a1:	mov    r15d,0x0
    7c479db002a7:	mov    eax,r15d
    7c479db002aa:	or     eax,r13d
    7c479db002ad:	mov    QWORD PTR [r12+0x20],rax
    7c479db002b2:	mov    rax,QWORD PTR [r12+0x88]
    7c479db002ba:	mov    r15,QWORD PTR [r12+0x50]
    7c479db002bf:	mov    rcx,QWORD PTR [r12+0x88]
    7c479db002c7:	add    r15,rcx
    7c479db002ca:	mov    r13d,DWORD PTR [r15]
    7c479db002cd:	mov    QWORD PTR [r12+0xc8],r13
    7c479db002d5:	mov    ecx,DWORD PTR [r12+0x30]
    7c479db002da:	mov    ecx,ecx
    7c479db002dc:	mov    r15d,DWORD PTR [r12+0xa0]
    7c479db002e4:	mov    r15d,r15d
    7c479db002e7:	not    rcx
    7c479db002ea:	and    r15d,ecx
    7c479db002ed:	mov    QWORD PTR [r12+0xd8],r15
    7c479db002f5:	mov    r8d,DWORD PTR [r12+0xb0]
    7c479db002fd:	add    ebp,r8d
    7c479db00300:	mov    QWORD PTR [r12+0xa8],rbp
    7c479db00308:	mov    r8d,DWORD PTR [r12+0x30]
    7c479db0030d:	mov    r8d,r8d
    7c479db00310:	mov    r8d,r8d
    7c479db00313:	ror    r8d,0xb
    7c479db00317:	xor    r14d,r8d
    7c479db0031a:	mov    QWORD PTR [r12+0xb0],r14
    7c479db00322:	mov    r8d,DWORD PTR [r12+0x38]
    7c479db00327:	mov    r8d,r8d
    7c479db0032a:	mov    r8d,r8d
    7c479db0032d:	ror    r8d,0xd
    7c479db00331:	xor    r9d,r8d
    7c479db00334:	mov    QWORD PTR [r12+0xd0],r9
    7c479db0033c:	add    ebp,r15d
    7c479db0033f:	mov    QWORD PTR [r12+0xa8],rbp
    7c479db00347:	mov    r15,QWORD PTR [r12+0x48]
    7c479db0034c:	mov    rcx,QWORD PTR [r12+0x88]
    7c479db00354:	add    r15,rcx
    7c479db00357:	mov    r8d,DWORD PTR [r15]
    7c479db0035a:	mov    QWORD PTR [r12+0xb8],r8
    7c479db00362:	mov    ecx,DWORD PTR [r12+0x98]
    7c479db0036a:	mov    ecx,ecx
    7c479db0036c:	mov    eax,DWORD PTR [r12+0x28]
    7c479db00371:	mov    eax,eax
    7c479db00373:	and    eax,ecx
    7c479db00375:	mov    QWORD PTR [r12+0xd8],rax
    7c479db0037d:	add    ebp,r13d
    7c479db00380:	mov    QWORD PTR [r12+0xa8],rbp
    7c479db00388:	mov    ecx,DWORD PTR [r12+0x98]
    7c479db00390:	mov    ecx,ecx
    7c479db00392:	mov    r13d,DWORD PTR [r12+0x28]
    7c479db00397:	mov    r13d,r13d
    7c479db0039a:	xor    r13d,ecx
    7c479db0039d:	mov    QWORD PTR [r12+0xc8],r13
    7c479db003a5:	mov    r15d,DWORD PTR [r12+0x30]
    7c479db003aa:	mov    r15d,r15d
    7c479db003ad:	mov    r15d,r15d
    7c479db003b0:	ror    r15d,0x19
    7c479db003b4:	xor    r14d,r15d
    7c479db003b7:	mov    QWORD PTR [r12+0xb0],r14
    7c479db003bf:	mov    ecx,DWORD PTR [r12+0x38]
    7c479db003c4:	mov    ecx,ecx
    7c479db003c6:	and    r13d,ecx
    7c479db003c9:	mov    QWORD PTR [r12+0xc8],r13
    7c479db003d1:	mov    r15d,DWORD PTR [r12+0x38]
    7c479db003d6:	mov    r15d,r15d
    7c479db003d9:	mov    r15d,r15d
    7c479db003dc:	ror    r15d,0x16
    7c479db003e0:	xor    r9d,r15d
    7c479db003e3:	mov    QWORD PTR [r12+0xd0],r9
    7c479db003eb:	add    ebp,r8d
    7c479db003ee:	mov    QWORD PTR [r12+0xa8],rbp
    7c479db003f6:	mov    ecx,DWORD PTR [r12+0xd8]
    7c479db003fe:	mov    ecx,ecx
    7c479db00400:	xor    r13d,ecx
    7c479db00403:	mov    QWORD PTR [r12+0xb8],r13
    7c479db0040b:	add    ebp,r14d
    7c479db0040e:	mov    QWORD PTR [r12+0xa8],rbp
    7c479db00416:	mov    r14,QWORD PTR [r12+0x88]
    7c479db0041e:	add    r14,0x4
    7c479db00422:	mov    QWORD PTR [r12+0x88],r14
    7c479db0042a:	add    r13d,r9d
    7c479db0042d:	mov    QWORD PTR [r12+0xb0],r13
    7c479db00435:	mov    ecx,DWORD PTR [r12+0xc0]
    7c479db0043d:	mov    ecx,ecx
    7c479db0043f:	mov    r15d,ebp
    7c479db00442:	add    r15d,ecx
    7c479db00445:	mov    QWORD PTR [r12+0xb8],r15
    7c479db0044d:	sub    r14,0x100
    7c479db00454:	setne  BYTE PTR [rsp+0xb8]
    7c479db0045c:	mov    r11,rax
    7c479db0045f:	lahf
    7c479db00460:	seto   al
    7c479db00463:	mov    WORD PTR [rsp+0xb0],ax
    7c479db0046b:	mov    rax,r11
    7c479db0046e:	add    r13d,ebp
    7c479db00471:	mov    QWORD PTR [r12+0xa8],r13
    7c479db00479:	mov    r13d,0x0
    7c479db0047f:	mov    ecx,DWORD PTR [r12+0xa0]
    7c479db00487:	mov    ecx,ecx
    7c479db00489:	mov    r14d,r13d
    7c479db0048c:	or     r14d,ecx
    7c479db0048f:	mov    QWORD PTR [r12+0xb0],r14
    7c479db00497:	mov    r13d,0x0
    7c479db0049d:	mov    ecx,DWORD PTR [r12+0x20]
    7c479db004a2:	mov    ecx,ecx
    7c479db004a4:	mov    r14d,r13d
    7c479db004a7:	or     r14d,ecx
    7c479db004aa:	mov    QWORD PTR [r12+0xc0],r14
    7c479db004b2:	mov    r13d,0x0
    7c479db004b8:	mov    ecx,DWORD PTR [r12+0x30]
    7c479db004bd:	mov    ecx,ecx
    7c479db004bf:	mov    r14d,r13d
    7c479db004c2:	or     r14d,ecx
    7c479db004c5:	mov    QWORD PTR [r12+0xc8],r14
    7c479db004cd:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db004d5:	jrcxz  0x7c479db004dc
    7c479db004d7:	jmp    0x7c479db008a2
    7c479db004dc:	cmp    BYTE PTR [rsp+0xb8],0x0
    7c479db004e4:	jne    0x7c479db001cd
    7c479db004ea:	jmp    0x7c479db004ef
    7c479db004ef:	mov    r13d,DWORD PTR [r12+0x70]
    7c479db004f4:	mov    r14d,DWORD PTR [r12+0x98]
    7c479db004fc:	add    r14d,r13d
    7c479db004ff:	mov    QWORD PTR [r12+0x70],r14
    7c479db00504:	mov    r13d,DWORD PTR [r12+0x68]
    7c479db00509:	mov    r15d,DWORD PTR [r12+0x28]
    7c479db0050e:	add    r15d,r13d
    7c479db00511:	mov    QWORD PTR [r12+0x68],r15
    7c479db00516:	mov    r13d,0x0
    7c479db0051c:	mov    QWORD PTR [r12+0x88],r13
    7c479db00524:	mov    r13d,DWORD PTR [r12+0x78]
    7c479db00529:	mov    ebp,DWORD PTR [r12+0xa8]
    7c479db00531:	add    ebp,r13d
    7c479db00534:	mov    QWORD PTR [r12+0x78],rbp
    7c479db00539:	mov    r13d,DWORD PTR [r12+0x80]
    7c479db00541:	mov    r8d,DWORD PTR [r12+0x38]
    7c479db00546:	add    r8d,r13d
    7c479db00549:	mov    QWORD PTR [r12+0x80],r8
    7c479db00551:	mov    rax,QWORD PTR [r12]
    7c479db00555:	mov    r9,QWORD PTR [r12]
    7c479db00559:	add    r9,0x8
    7c479db0055d:	mov    r13,r9
    7c479db00560:	add    r13,0x4
    7c479db00564:	mov    DWORD PTR [r9],r14d
    7c479db00567:	mov    r14d,0x0
    7c479db0056d:	mov    DWORD PTR [r12+0x32c],r14d
    7c479db00575:	mov    DWORD PTR [r13+0x0],r15d
    7c479db00579:	mov    r13d,DWORD PTR [r12+0x18]
    7c479db0057e:	mov    r14d,DWORD PTR [r12+0xb8]
    7c479db00586:	add    r14d,r13d
    7c479db00589:	mov    QWORD PTR [r12+0x68],r14
    7c479db0058e:	mov    r13d,DWORD PTR [r12+0x90]
    7c479db00596:	mov    r15d,DWORD PTR [r12+0x30]
    7c479db0059b:	add    r15d,r13d
    7c479db0059e:	mov    QWORD PTR [r12+0x70],r15
    7c479db005a3:	mov    r13d,DWORD PTR [r12+0x58]
    7c479db005a8:	mov    r9d,DWORD PTR [r12+0x20]
    7c479db005ad:	mov    eax,r9d
    7c479db005b0:	add    eax,r13d
    7c479db005b3:	mov    QWORD PTR [r12+0x58],rax
    7c479db005b8:	mov    r13d,DWORD PTR [r12+0x60]
    7c479db005bd:	mov    r9d,DWORD PTR [r12+0xa0]
    7c479db005c5:	add    r9d,r13d
    7c479db005c8:	mov    QWORD PTR [r12+0x60],r9
    7c479db005cd:	mov    r13,QWORD PTR [r12]
    7c479db005d1:	add    r13,0x4
    7c479db005d5:	mov    rdi,QWORD PTR [r12]
    7c479db005d9:	mov    DWORD PTR [rdi],ebp
    7c479db005db:	mov    DWORD PTR [r13+0x0],r8d
    7c479db005df:	mov    r13,QWORD PTR [r12]
    7c479db005e3:	add    r13,0x10
    7c479db005e7:	mov    rbp,r13
    7c479db005ea:	add    rbp,0x4
    7c479db005ee:	mov    DWORD PTR [r13+0x0],r14d
    7c479db005f2:	mov    DWORD PTR [rbp+0x0],r15d
    7c479db005f6:	mov    r13,QWORD PTR [r12]
    7c479db005fa:	add    r13,0x18
    7c479db005fe:	mov    r14,r13
    7c479db00601:	add    r14,0x4
    7c479db00605:	mov    eax,DWORD PTR [r12+0x58]
    7c479db0060a:	mov    DWORD PTR [r13+0x0],eax
    7c479db0060e:	mov    DWORD PTR [r14],r9d
    7c479db00611:	mov    r13,QWORD PTR [r12]
    7c479db00615:	add    r13,0x68
    7c479db00619:	mov    r14d,0x0
    7c479db0061f:	mov    QWORD PTR [r13+0x0],r14
    7c479db00623:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db0062b:	jrcxz  0x7c479db00632
    7c479db0062d:	jmp    0x7c479db0092a
    7c479db00632:	jmp    0x7c479db00637
    7c479db00637:	mov    r13,QWORD PTR [r12+0x10]
    7c479db0063c:	sub    r13,0x1
    7c479db00640:	mov    QWORD PTR [r12+0x10],r13
    7c479db00645:	mov    rax,r13
    7c479db00648:	test   rax,rax
    7c479db0064b:	je     0x7c479db00656
    7c479db00651:	jmp    0x7c479dafe75a
    7c479db00656:	mov    r13,QWORD PTR [r12+0xf8]
    7c479db0065e:	mov    r14,r13
    7c479db00661:	add    r14,0x140
    7c479db00668:	mov    r15,r14
    7c479db0066b:	add    r15,0x8
    7c479db0066f:	mov    rbp,QWORD PTR [r14]
    7c479db00672:	mov    r14,QWORD PTR [r15]
    7c479db00675:	mov    QWORD PTR [r12+0xa0],rbp
    7c479db0067d:	mov    QWORD PTR [r12+0x98],r14
    7c479db00685:	mov    r14,r13
    7c479db00688:	add    r14,0x130
    7c479db0068f:	mov    r15,r14
    7c479db00692:	add    r15,0x8
    7c479db00696:	mov    rbp,QWORD PTR [r14]
    7c479db00699:	mov    r14,QWORD PTR [r15]
    7c479db0069c:	mov    QWORD PTR [r12+0xb0],rbp
    7c479db006a4:	mov    QWORD PTR [r12+0xa8],r14
    7c479db006ac:	mov    r14,r13
    7c479db006af:	add    r14,0x120
    7c479db006b6:	mov    r15,r14
    7c479db006b9:	add    r15,0x8
    7c479db006bd:	mov    rbp,QWORD PTR [r14]
    7c479db006c0:	mov    r14,QWORD PTR [r15]
    7c479db006c3:	mov    QWORD PTR [r12+0xc0],rbp
    7c479db006cb:	mov    QWORD PTR [r12+0xb8],r14
    7c479db006d3:	mov    r14,r13
    7c479db006d6:	add    r14,0x110
    7c479db006dd:	mov    r15,r14
    7c479db006e0:	add    r15,0x8
    7c479db006e4:	mov    rbp,QWORD PTR [r14]
    7c479db006e7:	mov    r14,QWORD PTR [r15]
    7c479db006ea:	mov    QWORD PTR [r12+0xd0],rbp
    7c479db006f2:	mov    QWORD PTR [r12+0xc8],r14
    7c479db006fa:	mov    r14,r13
    7c479db006fd:	add    r14,0x100
    7c479db00704:	mov    r15,r14
    7c479db00707:	add    r15,0x8
    7c479db0070b:	mov    rbp,QWORD PTR [r14]
    7c479db0070e:	mov    r14,QWORD PTR [r15]
    7c479db00711:	mov    QWORD PTR [r12+0xe8],rbp
    7c479db00719:	mov    QWORD PTR [r12+0xd8],r14
    7c479db00721:	add    r13,0x150
    7c479db00728:	mov    QWORD PTR [r12+0xf8],r13
    7c479db00730:	jmp    0x7c479db00735
    7c479db00735:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db0073d:	jrcxz  0x7c479db00744
    7c479db0073f:	jmp    0x7c479db009b2
    7c479db00744:	mov    r13,QWORD PTR [r12+0xf0]
    7c479db0074c:	mov    QWORD PTR [r12+0x100],r13
    7c479db00754:	mov    r11,QWORD PTR [rsp+0xb0]
    7c479db0075c:	mov    QWORD PTR [r12+0x398],r11
    7c479db00764:	mov    rdi,QWORD PTR [r12+0x100]
    7c479db0076c:	add    rsp,0xc0
    7c479db00773:	movabs r11,0x62fe87327940
    7c479db0077d:	jmp    r11
    7c479db00780:	mov    eax,0x41078c
    7c479db00785:	mov    QWORD PTR [r12+0x100],rax
    7c479db0078d:	push   rdx
    7c479db0078e:	push   rsi
    7c479db0078f:	push   r10
    7c479db00791:	push   r11
    7c479db00793:	mov    r11,rax
    7c479db00796:	lahf
    7c479db00797:	seto   al
    7c479db0079a:	mov    WORD PTR [rsp+0xd0],ax
    7c479db007a2:	mov    rax,r11
    7c479db007a5:	mov    rdx,QWORD PTR [rsp+0xd0]
    7c479db007ad:	mov    r10d,edx
    7c479db007b0:	and    r10d,0xc000
    7c479db007b7:	shl    r10d,0x10
    7c479db007bb:	mov    r11d,edx
    7c479db007be:	and    r11d,0x100
    7c479db007c5:	shl    r11d,0x15
    7c479db007c9:	or     r10d,r11d
    7c479db007cc:	and    edx,0x1
    7c479db007cf:	shl    edx,0x1c
    7c479db007d2:	or     r10d,edx
    7c479db007d5:	btc    r10,0x1d
    7c479db007da:	mov    r11d,0xf0000000
    7c479db007e0:	and    r11,r10
    7c479db007e3:	movabs rsi,0xffffffff0fffffff
    7c479db007ed:	and    rbx,rsi
    7c479db007f0:	or     rbx,r11
    7c479db007f3:	pop    r11
    7c479db007f5:	pop    r10
    7c479db007f7:	pop    rsi
    7c479db007f8:	pop    rdx
    7c479db007f9:	mov    QWORD PTR [r12+0x108],rbx
    7c479db00801:	add    rsp,0xc0
    7c479db00808:	mov    eax,0xc
    7c479db0080d:	movabs r11,0x62fe87327ca0
    7c479db00817:	jmp    r11
    7c479db0081a:	mov    eax,0x410888
    7c479db0081f:	mov    QWORD PTR [r12+0x100],rax
    7c479db00827:	push   rdx
    7c479db00828:	push   rsi
    7c479db00829:	push   r10
    7c479db0082b:	push   r11
    7c479db0082d:	mov    rdx,QWORD PTR [rsp+0xd0]
    7c479db00835:	mov    r10d,edx
    7c479db00838:	and    r10d,0xc000
    7c479db0083f:	shl    r10d,0x10
    7c479db00843:	mov    r11d,edx
    7c479db00846:	and    r11d,0x100
    7c479db0084d:	shl    r11d,0x15
    7c479db00851:	or     r10d,r11d
    7c479db00854:	and    edx,0x1
    7c479db00857:	shl    edx,0x1c
    7c479db0085a:	or     r10d,edx
    7c479db0085d:	btc    r10,0x1d
    7c479db00862:	mov    r11d,0xf0000000
    7c479db00868:	and    r11,r10
    7c479db0086b:	movabs rsi,0xffffffff0fffffff
    7c479db00875:	and    rbx,rsi
    7c479db00878:	or     rbx,r11
    7c479db0087b:	pop    r11
    7c479db0087d:	pop    r10
    7c479db0087f:	pop    rsi
    7c479db00880:	pop    rdx
    7c479db00881:	mov    QWORD PTR [r12+0x108],rbx
    7c479db00889:	add    rsp,0xc0
    7c479db00890:	mov    eax,0xc
    7c479db00895:	movabs r11,0x62fe87327ca0
    7c479db0089f:	jmp    r11
    7c479db008a2:	mov    eax,0x410948
    7c479db008a7:	mov    QWORD PTR [r12+0x100],rax
    7c479db008af:	push   rdx
    7c479db008b0:	push   rsi
    7c479db008b1:	push   r10
    7c479db008b3:	push   r11
    7c479db008b5:	mov    rdx,QWORD PTR [rsp+0xd0]
    7c479db008bd:	mov    r10d,edx
    7c479db008c0:	and    r10d,0xc000
    7c479db008c7:	shl    r10d,0x10
    7c479db008cb:	mov    r11d,edx
    7c479db008ce:	and    r11d,0x100
    7c479db008d5:	shl    r11d,0x15
    7c479db008d9:	or     r10d,r11d
    7c479db008dc:	and    edx,0x1
    7c479db008df:	shl    edx,0x1c
    7c479db008e2:	or     r10d,edx
    7c479db008e5:	btc    r10,0x1d
    7c479db008ea:	mov    r11d,0xf0000000
    7c479db008f0:	and    r11,r10
    7c479db008f3:	movabs rsi,0xffffffff0fffffff
    7c479db008fd:	and    rbx,rsi
    7c479db00900:	or     rbx,r11
    7c479db00903:	pop    r11
    7c479db00905:	pop    r10
    7c479db00907:	pop    rsi
    7c479db00908:	pop    rdx
    7c479db00909:	mov    QWORD PTR [r12+0x108],rbx
    7c479db00911:	add    rsp,0xc0
    7c479db00918:	mov    eax,0xc
    7c479db0091d:	movabs r11,0x62fe87327ca0
    7c479db00927:	jmp    r11
    7c479db0092a:	mov    eax,0x410984
    7c479db0092f:	mov    QWORD PTR [r12+0x100],rax
    7c479db00937:	push   rdx
    7c479db00938:	push   rsi
    7c479db00939:	push   r10
    7c479db0093b:	push   r11
    7c479db0093d:	mov    rdx,QWORD PTR [rsp+0xd0]
    7c479db00945:	mov    r10d,edx
    7c479db00948:	and    r10d,0xc000
    7c479db0094f:	shl    r10d,0x10
    7c479db00953:	mov    r11d,edx
    7c479db00956:	and    r11d,0x100
    7c479db0095d:	shl    r11d,0x15
    7c479db00961:	or     r10d,r11d
    7c479db00964:	and    edx,0x1
    7c479db00967:	shl    edx,0x1c
    7c479db0096a:	or     r10d,edx
    7c479db0096d:	btc    r10,0x1d
    7c479db00972:	mov    r11d,0xf0000000
    7c479db00978:	and    r11,r10
    7c479db0097b:	movabs rsi,0xffffffff0fffffff
    7c479db00985:	and    rbx,rsi
    7c479db00988:	or     rbx,r11
    7c479db0098b:	pop    r11
    7c479db0098d:	pop    r10
    7c479db0098f:	pop    rsi
    7c479db00990:	pop    rdx
    7c479db00991:	mov    QWORD PTR [r12+0x108],rbx
    7c479db00999:	add    rsp,0xc0
    7c479db009a0:	mov    eax,0xc
    7c479db009a5:	movabs r11,0x62fe87327ca0
    7c479db009af:	jmp    r11
    7c479db009b2:	mov    eax,0x4109a0
    7c479db009b7:	mov    QWORD PTR [r12+0x100],rax
    7c479db009bf:	push   rdx
    7c479db009c0:	push   rsi
    7c479db009c1:	push   r10
    7c479db009c3:	push   r11
    7c479db009c5:	mov    rdx,QWORD PTR [rsp+0xd0]
    7c479db009cd:	mov    r10d,edx
    7c479db009d0:	and    r10d,0xc000
    7c479db009d7:	shl    r10d,0x10
    7c479db009db:	mov    r11d,edx
    7c479db009de:	and    r11d,0x100
    7c479db009e5:	shl    r11d,0x15
    7c479db009e9:	or     r10d,r11d
    7c479db009ec:	and    edx,0x1
    7c479db009ef:	shl    edx,0x1c
    7c479db009f2:	or     r10d,edx
    7c479db009f5:	btc    r10,0x1d
    7c479db009fa:	mov    r11d,0xf0000000
    7c479db00a00:	and    r11,r10
    7c479db00a03:	movabs rsi,0xffffffff0fffffff
    7c479db00a0d:	and    rbx,rsi
    7c479db00a10:	or     rbx,r11
    7c479db00a13:	pop    r11
    7c479db00a15:	pop    r10
    7c479db00a17:	pop    rsi
    7c479db00a18:	pop    rdx
    7c479db00a19:	mov    QWORD PTR [r12+0x108],rbx
    7c479db00a21:	add    rsp,0xc0
    7c479db00a28:	mov    eax,0xc
    7c479db00a2d:	movabs r11,0x62fe87327ca0
    7c479db00a37:	jmp    r11
    7c479db00a3a:	nop    WORD PTR [rax+rax*1+0x0]
    7c479db00a40:	sub    rsp,0xc0
    7c479db00a47:	mov    r11,QWORD PTR [r12+0x398]
    7c479db00a4f:	mov    QWORD PTR [rsp+0xb0],r11
    7c479db00a57:	jmp    0x7c479dafe639
    7c479db00a5c:	nop    DWORD PTR [rax+0x0]
    7c479db00a60:	sub    rsp,0xc0
    7c479db00a67:	mov    r11,QWORD PTR [r12+0x398]
    7c479db00a6f:	mov    QWORD PTR [rsp+0xb0],r11
    7c479db00a77:	jmp    0x7c479dafe75a
    7c479db00a7c:	nop    DWORD PTR [rax+0x0]
    7c479db00a80:	sub    rsp,0xc0
    7c479db00a87:	mov    r11,QWORD PTR [r12+0x398]
    7c479db00a8f:	mov    QWORD PTR [rsp+0xb0],r11
    7c479db00a97:	jmp    0x7c479dafe814
    7c479db00a9c:	nop    DWORD PTR [rax+0x0]
    7c479db00aa0:	sub    rsp,0xc0
    7c479db00aa7:	mov    r11,QWORD PTR [r12+0x398]
    7c479db00aaf:	mov    QWORD PTR [rsp+0xb0],r11
    7c479db00ab7:	jmp    0x7c479daffef9
    7c479db00abc:	nop    DWORD PTR [rax+0x0]
    7c479db00ac0:	sub    rsp,0xc0
    7c479db00ac7:	mov    r11,QWORD PTR [r12+0x398]
    7c479db00acf:	mov    QWORD PTR [rsp+0xb0],r11
    7c479db00ad7:	jmp    0x7c479db0004a
    7c479db00adc:	nop    DWORD PTR [rax+0x0]
    7c479db00ae0:	sub    rsp,0xc0
    7c479db00ae7:	mov    r11,QWORD PTR [r12+0x398]
    7c479db00aef:	mov    QWORD PTR [rsp+0xb0],r11
    7c479db00af7:	jmp    0x7c479db001cd
    7c479db00afc:	nop    DWORD PTR [rax+0x0]
    7c479db00b00:	sub    rsp,0xc0
    7c479db00b07:	mov    r11,QWORD PTR [r12+0x398]
    7c479db00b0f:	mov    QWORD PTR [rsp+0xb0],r11
    7c479db00b17:	jmp    0x7c479db004ef
    7c479db00b1c:	nop    DWORD PTR [rax+0x0]
    7c479db00b20:	sub    rsp,0xc0
    7c479db00b27:	mov    r11,QWORD PTR [r12+0x398]
    7c479db00b2f:	mov    QWORD PTR [rsp+0xb0],r11
    7c479db00b37:	jmp    0x7c479db00637
    7c479db00b3c:	nop    DWORD PTR [rax+0x0]
    7c479db00b40:	sub    rsp,0xc0
    7c479db00b47:	mov    r11,QWORD PTR [r12+0x398]
    7c479db00b4f:	mov    QWORD PTR [rsp+0xb0],r11
    7c479db00b57:	jmp    0x7c479db00656
    7c479db00b5c:	nop    DWORD PTR [rax+0x0]
    7c479db00b60:	sub    rsp,0xc0
    7c479db00b67:	mov    r11,QWORD PTR [r12+0x398]
    7c479db00b6f:	mov    QWORD PTR [rsp+0xb0],r11
    7c479db00b77:	jmp    0x7c479db00735
