
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/0/1.bin:     file format binary


Disassembly of section .data:

000077db492fe5e0 <.data>:
    77db492fe5e0:	sub    rsp,0xc0
    77db492fe5e7:	mov    r11,QWORD PTR [r12+0x398]
    77db492fe5ef:	mov    QWORD PTR [rsp+0xb0],r11
    77db492fe5f7:	mov    r13,QWORD PTR [r12]
    77db492fe5fb:	mov    r14,r13
    77db492fe5fe:	add    r14,0x20
    77db492fe602:	mov    r15,QWORD PTR [r14]
    77db492fe605:	mov    r14,QWORD PTR [r12+0x10]
    77db492fe60a:	add    r15,r14
    77db492fe60d:	mov    QWORD PTR [r12+0x40],r15
    77db492fe612:	add    r13,0x20
    77db492fe616:	mov    QWORD PTR [r13+0x0],r15
    77db492fe61a:	mov    r13d,0x0
    77db492fe620:	mov    DWORD PTR [r12+0x32c],r13d
    77db492fe628:	mov    rax,r14
    77db492fe62b:	test   rax,rax
    77db492fe62e:	je     0x77db49300735
    77db492fe634:	jmp    0x77db492fe639
    77db492fe639:	mov    r13,QWORD PTR [r12+0xf8]
    77db492fe641:	sub    r13,0x150
    77db492fe648:	mov    QWORD PTR [r12+0xf8],r13
    77db492fe650:	mov    r14,QWORD PTR [r12]
    77db492fe654:	mov    r15,r14
    77db492fe657:	add    r15,0x68
    77db492fe65b:	mov    rbp,QWORD PTR [r15]
    77db492fe65e:	mov    QWORD PTR [r12+0x88],rbp
    77db492fe666:	add    r14,0x28
    77db492fe66a:	mov    QWORD PTR [r12+0x40],r14
    77db492fe66f:	mov    QWORD PTR [r12+0x48],r13
    77db492fe674:	mov    r14d,0x420000
    77db492fe67a:	add    r14,0xb90
    77db492fe681:	mov    QWORD PTR [r12+0x50],r14
    77db492fe686:	mov    r14,r13
    77db492fe689:	add    r14,0x100
    77db492fe690:	mov    r15,r14
    77db492fe693:	add    r15,0x8
    77db492fe697:	mov    rbp,QWORD PTR [r12+0xe8]
    77db492fe69f:	mov    r8,QWORD PTR [r12+0xd8]
    77db492fe6a7:	mov    QWORD PTR [r14],rbp
    77db492fe6aa:	mov    r14d,0x0
    77db492fe6b0:	mov    DWORD PTR [r12+0x32c],r14d
    77db492fe6b8:	mov    QWORD PTR [r15],r8
    77db492fe6bb:	mov    r14,r13
    77db492fe6be:	add    r14,0x110
    77db492fe6c5:	mov    r15,r14
    77db492fe6c8:	add    r15,0x8
    77db492fe6cc:	mov    rbp,QWORD PTR [r12+0xd0]
    77db492fe6d4:	mov    r8,QWORD PTR [r12+0xc8]
    77db492fe6dc:	mov    QWORD PTR [r14],rbp
    77db492fe6df:	mov    QWORD PTR [r15],r8
    77db492fe6e2:	mov    r14,r13
    77db492fe6e5:	add    r14,0x120
    77db492fe6ec:	mov    r15,r14
    77db492fe6ef:	add    r15,0x8
    77db492fe6f3:	mov    rbp,QWORD PTR [r12+0xc0]
    77db492fe6fb:	mov    r8,QWORD PTR [r12+0xb8]
    77db492fe703:	mov    QWORD PTR [r14],rbp
    77db492fe706:	mov    QWORD PTR [r15],r8
    77db492fe709:	mov    r14,r13
    77db492fe70c:	add    r14,0x130
    77db492fe713:	mov    r15,r14
    77db492fe716:	add    r15,0x8
    77db492fe71a:	mov    rbp,QWORD PTR [r12+0xb0]
    77db492fe722:	mov    r8,QWORD PTR [r12+0xa8]
    77db492fe72a:	mov    QWORD PTR [r14],rbp
    77db492fe72d:	mov    QWORD PTR [r15],r8
    77db492fe730:	add    r13,0x140
    77db492fe737:	mov    r14,r13
    77db492fe73a:	add    r14,0x8
    77db492fe73e:	mov    r15,QWORD PTR [r12+0xa0]
    77db492fe746:	mov    rbp,QWORD PTR [r12+0x98]
    77db492fe74e:	mov    QWORD PTR [r13+0x0],r15
    77db492fe752:	mov    QWORD PTR [r14],rbp
    77db492fe755:	jmp    0x77db492fe75a
    77db492fe75a:	mov    r13,QWORD PTR [r12+0x8]
    77db492fe75f:	mov    r14,r13
    77db492fe762:	add    r14,0x1
    77db492fe766:	movzx  r15d,BYTE PTR [r13+0x0]
    77db492fe76b:	mov    QWORD PTR [r12+0x58],r15
    77db492fe770:	mov    QWORD PTR [r12+0x8],r14
    77db492fe775:	mov    r13,QWORD PTR [r12+0x88]
    77db492fe77d:	mov    r14,r13
    77db492fe780:	add    r14,0x1
    77db492fe784:	mov    QWORD PTR [r12+0x60],r14
    77db492fe789:	mov    r15,QWORD PTR [r12]
    77db492fe78d:	mov    rbp,r15
    77db492fe790:	add    rbp,0x68
    77db492fe794:	mov    QWORD PTR [rbp+0x0],r14
    77db492fe798:	mov    r14d,0x0
    77db492fe79e:	mov    DWORD PTR [r12+0x32c],r14d
    77db492fe7a6:	mov    r14,r15
    77db492fe7a9:	add    r14,r13
    77db492fe7ac:	mov    QWORD PTR [r12+0x60],r14
    77db492fe7b1:	add    r14,0x28
    77db492fe7b5:	movzx  r13d,BYTE PTR [r12+0x58]
    77db492fe7bb:	mov    BYTE PTR [r14],r13b
    77db492fe7be:	add    r15,0x68
    77db492fe7c2:	mov    r13,QWORD PTR [r15]
    77db492fe7c5:	mov    QWORD PTR [r12+0x88],r13
    77db492fe7cd:	sub    r13,0x40
    77db492fe7d1:	mov    rcx,QWORD PTR [r12+0x380]
    77db492fe7d9:	jrcxz  0x77db492fe7e0
    77db492fe7db:	jmp    0x77db49300780
    77db492fe7e0:	jne    0x77db492fe7fd
    77db492fe7e6:	mov    r11,rax
    77db492fe7e9:	lahf
    77db492fe7ea:	seto   al
    77db492fe7ed:	mov    WORD PTR [rsp+0xb0],ax
    77db492fe7f5:	mov    rax,r11
    77db492fe7f8:	jmp    0x77db492fe814
    77db492fe7fd:	mov    r11,rax
    77db492fe800:	lahf
    77db492fe801:	seto   al
    77db492fe804:	mov    WORD PTR [rsp+0xb0],ax
    77db492fe80c:	mov    rax,r11
    77db492fe80f:	jmp    0x77db49300637
    77db492fe814:	mov    rax,QWORD PTR [r12+0x40]
    77db492fe819:	mov    eax,0x0
    77db492fe81e:	mov    QWORD PTR [rsp+0x18],rax
    77db492fe823:	mov    eax,0x0
    77db492fe828:	mov    QWORD PTR [rsp+0x10],rax
    77db492fe82d:	mov    eax,0x0
    77db492fe832:	mov    QWORD PTR [rsp+0x8],rax
    77db492fe837:	mov    eax,0x0
    77db492fe83c:	mov    QWORD PTR [rsp],rax
    77db492fe840:	mov    rdi,QWORD PTR [r12+0x40]
    77db492fe845:	movzx  r9d,BYTE PTR [rdi]
    77db492fe849:	mov    r13,QWORD PTR [rsp+0x18]
    77db492fe84e:	or     r13,r9
    77db492fe851:	mov    r9,QWORD PTR [r12+0x40]
    77db492fe856:	add    r9,0x1
    77db492fe85a:	movzx  r8d,BYTE PTR [r9]
    77db492fe85e:	mov    r9,QWORD PTR [rsp+0x10]
    77db492fe863:	or     r9,r8
    77db492fe866:	mov    r8,QWORD PTR [r12+0x40]
    77db492fe86b:	add    r8,0x2
    77db492fe86f:	movzx  ebp,BYTE PTR [r8]
    77db492fe873:	mov    r8,QWORD PTR [rsp+0x8]
    77db492fe878:	or     r8,rbp
    77db492fe87b:	mov    rbp,QWORD PTR [r12+0x40]
    77db492fe880:	add    rbp,0x3
    77db492fe884:	movzx  r15d,BYTE PTR [rbp+0x0]
    77db492fe889:	mov    rbp,QWORD PTR [rsp]
    77db492fe88d:	or     rbp,r15
    77db492fe890:	mov    r15,QWORD PTR [r12+0x40]
    77db492fe895:	add    r15,0x4
    77db492fe899:	movzx  r14d,BYTE PTR [r15]
    77db492fe89d:	mov    r15,r14
    77db492fe8a0:	shl    r15,0x8
    77db492fe8a4:	or     r13,r15
    77db492fe8a7:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe8ac:	add    r14,0x5
    77db492fe8b0:	movzx  r15d,BYTE PTR [r14]
    77db492fe8b4:	mov    r14,r15
    77db492fe8b7:	shl    r14,0x8
    77db492fe8bb:	or     r9,r14
    77db492fe8be:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe8c3:	add    r14,0x6
    77db492fe8c7:	movzx  r15d,BYTE PTR [r14]
    77db492fe8cb:	mov    r14,r15
    77db492fe8ce:	shl    r14,0x8
    77db492fe8d2:	or     r8,r14
    77db492fe8d5:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe8da:	add    r14,0x7
    77db492fe8de:	movzx  r15d,BYTE PTR [r14]
    77db492fe8e2:	mov    r14,r15
    77db492fe8e5:	shl    r14,0x8
    77db492fe8e9:	or     rbp,r14
    77db492fe8ec:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe8f1:	add    r14,0x8
    77db492fe8f5:	movzx  r15d,BYTE PTR [r14]
    77db492fe8f9:	mov    r14,r15
    77db492fe8fc:	shl    r14,0x10
    77db492fe900:	or     r13,r14
    77db492fe903:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe908:	add    r14,0x9
    77db492fe90c:	movzx  r15d,BYTE PTR [r14]
    77db492fe910:	mov    r14,r15
    77db492fe913:	shl    r14,0x10
    77db492fe917:	or     r9,r14
    77db492fe91a:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe91f:	add    r14,0xa
    77db492fe923:	movzx  r15d,BYTE PTR [r14]
    77db492fe927:	mov    r14,r15
    77db492fe92a:	shl    r14,0x10
    77db492fe92e:	or     r8,r14
    77db492fe931:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe936:	add    r14,0xb
    77db492fe93a:	movzx  r15d,BYTE PTR [r14]
    77db492fe93e:	mov    r14,r15
    77db492fe941:	shl    r14,0x10
    77db492fe945:	or     rbp,r14
    77db492fe948:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe94d:	add    r14,0xc
    77db492fe951:	movzx  r15d,BYTE PTR [r14]
    77db492fe955:	mov    r14,r15
    77db492fe958:	shl    r14,0x18
    77db492fe95c:	or     r13,r14
    77db492fe95f:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe964:	add    r14,0xd
    77db492fe968:	movzx  r15d,BYTE PTR [r14]
    77db492fe96c:	mov    r14,r15
    77db492fe96f:	shl    r14,0x18
    77db492fe973:	or     r9,r14
    77db492fe976:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe97b:	add    r14,0xe
    77db492fe97f:	movzx  r15d,BYTE PTR [r14]
    77db492fe983:	mov    r14,r15
    77db492fe986:	shl    r14,0x18
    77db492fe98a:	or     r8,r14
    77db492fe98d:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe992:	add    r14,0xf
    77db492fe996:	movzx  r15d,BYTE PTR [r14]
    77db492fe99a:	mov    r14,r15
    77db492fe99d:	shl    r14,0x18
    77db492fe9a1:	or     rbp,r14
    77db492fe9a4:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe9a9:	add    r14,0x10
    77db492fe9ad:	movzx  r15d,BYTE PTR [r14]
    77db492fe9b1:	mov    r14,r15
    77db492fe9b4:	shl    r14,0x20
    77db492fe9b8:	or     r13,r14
    77db492fe9bb:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe9c0:	add    r14,0x11
    77db492fe9c4:	movzx  r15d,BYTE PTR [r14]
    77db492fe9c8:	mov    r14,r15
    77db492fe9cb:	shl    r14,0x20
    77db492fe9cf:	or     r9,r14
    77db492fe9d2:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe9d7:	add    r14,0x12
    77db492fe9db:	movzx  r15d,BYTE PTR [r14]
    77db492fe9df:	mov    r14,r15
    77db492fe9e2:	shl    r14,0x20
    77db492fe9e6:	or     r8,r14
    77db492fe9e9:	mov    r14,QWORD PTR [r12+0x40]
    77db492fe9ee:	add    r14,0x13
    77db492fe9f2:	movzx  r15d,BYTE PTR [r14]
    77db492fe9f6:	mov    r14,r15
    77db492fe9f9:	shl    r14,0x20
    77db492fe9fd:	or     rbp,r14
    77db492fea00:	mov    r14,QWORD PTR [r12+0x40]
    77db492fea05:	add    r14,0x14
    77db492fea09:	movzx  r15d,BYTE PTR [r14]
    77db492fea0d:	mov    r14,r15
    77db492fea10:	shl    r14,0x28
    77db492fea14:	or     r13,r14
    77db492fea17:	mov    r14,QWORD PTR [r12+0x40]
    77db492fea1c:	add    r14,0x15
    77db492fea20:	movzx  r15d,BYTE PTR [r14]
    77db492fea24:	mov    r14,r15
    77db492fea27:	shl    r14,0x28
    77db492fea2b:	or     r9,r14
    77db492fea2e:	mov    r14,QWORD PTR [r12+0x40]
    77db492fea33:	add    r14,0x16
    77db492fea37:	movzx  r15d,BYTE PTR [r14]
    77db492fea3b:	mov    r14,r15
    77db492fea3e:	shl    r14,0x28
    77db492fea42:	or     r8,r14
    77db492fea45:	mov    r14,QWORD PTR [r12+0x40]
    77db492fea4a:	add    r14,0x17
    77db492fea4e:	movzx  r15d,BYTE PTR [r14]
    77db492fea52:	mov    r14,r15
    77db492fea55:	shl    r14,0x28
    77db492fea59:	or     rbp,r14
    77db492fea5c:	mov    r14,QWORD PTR [r12+0x40]
    77db492fea61:	add    r14,0x18
    77db492fea65:	movzx  r15d,BYTE PTR [r14]
    77db492fea69:	mov    r14,r15
    77db492fea6c:	shl    r14,0x30
    77db492fea70:	or     r13,r14
    77db492fea73:	mov    r14,QWORD PTR [r12+0x40]
    77db492fea78:	add    r14,0x19
    77db492fea7c:	movzx  r15d,BYTE PTR [r14]
    77db492fea80:	mov    r14,r15
    77db492fea83:	shl    r14,0x30
    77db492fea87:	or     r9,r14
    77db492fea8a:	mov    r14,QWORD PTR [r12+0x40]
    77db492fea8f:	add    r14,0x1a
    77db492fea93:	movzx  r15d,BYTE PTR [r14]
    77db492fea97:	mov    r14,r15
    77db492fea9a:	shl    r14,0x30
    77db492fea9e:	or     r8,r14
    77db492feaa1:	mov    r14,QWORD PTR [r12+0x40]
    77db492feaa6:	add    r14,0x1b
    77db492feaaa:	movzx  r15d,BYTE PTR [r14]
    77db492feaae:	mov    r14,r15
    77db492feab1:	shl    r14,0x30
    77db492feab5:	or     rbp,r14
    77db492feab8:	mov    r14,QWORD PTR [r12+0x40]
    77db492feabd:	add    r14,0x1c
    77db492feac1:	movzx  r15d,BYTE PTR [r14]
    77db492feac5:	mov    r14,r15
    77db492feac8:	shl    r14,0x38
    77db492feacc:	mov    rax,r13
    77db492feacf:	or     rax,r14
    77db492fead2:	mov    QWORD PTR [rsp+0x28],rax
    77db492fead7:	mov    r14,QWORD PTR [r12+0x40]
    77db492feadc:	add    r14,0x1d
    77db492feae0:	movzx  r15d,BYTE PTR [r14]
    77db492feae4:	mov    r14,r15
    77db492feae7:	shl    r14,0x38
    77db492feaeb:	mov    rax,r9
    77db492feaee:	or     rax,r14
    77db492feaf1:	mov    QWORD PTR [rsp+0x38],rax
    77db492feaf6:	mov    r14,QWORD PTR [r12+0x40]
    77db492feafb:	add    r14,0x1e
    77db492feaff:	movzx  r15d,BYTE PTR [r14]
    77db492feb03:	mov    r14,r15
    77db492feb06:	shl    r14,0x38
    77db492feb0a:	mov    rax,r8
    77db492feb0d:	or     rax,r14
    77db492feb10:	mov    QWORD PTR [rsp+0x30],rax
    77db492feb15:	mov    r14,QWORD PTR [r12+0x40]
    77db492feb1a:	add    r14,0x1f
    77db492feb1e:	movzx  r15d,BYTE PTR [r14]
    77db492feb22:	mov    r14,r15
    77db492feb25:	shl    r14,0x38
    77db492feb29:	mov    rax,rbp
    77db492feb2c:	or     rax,r14
    77db492feb2f:	mov    QWORD PTR [rsp+0x20],rax
    77db492feb34:	mov    r14,QWORD PTR [r12+0x40]
    77db492feb39:	add    r14,0x20
    77db492feb3d:	movzx  r15d,BYTE PTR [r14]
    77db492feb41:	mov    r14,QWORD PTR [rsp+0x18]
    77db492feb46:	or     r14,r15
    77db492feb49:	mov    r15,QWORD PTR [r12+0x40]
    77db492feb4e:	add    r15,0x21
    77db492feb52:	movzx  ebp,BYTE PTR [r15]
    77db492feb56:	mov    r15,QWORD PTR [rsp+0x10]
    77db492feb5b:	or     r15,rbp
    77db492feb5e:	mov    rbp,QWORD PTR [r12+0x40]
    77db492feb63:	add    rbp,0x22
    77db492feb67:	movzx  r13d,BYTE PTR [rbp+0x0]
    77db492feb6c:	mov    rbp,QWORD PTR [rsp+0x8]
    77db492feb71:	or     rbp,r13
    77db492feb74:	mov    r13,QWORD PTR [r12+0x40]
    77db492feb79:	add    r13,0x23
    77db492feb7d:	movzx  r8d,BYTE PTR [r13+0x0]
    77db492feb82:	mov    r13,QWORD PTR [rsp]
    77db492feb86:	or     r13,r8
    77db492feb89:	mov    r8,QWORD PTR [r12+0x40]
    77db492feb8e:	add    r8,0x24
    77db492feb92:	movzx  r9d,BYTE PTR [r8]
    77db492feb96:	mov    r8,r9
    77db492feb99:	shl    r8,0x8
    77db492feb9d:	or     r14,r8
    77db492feba0:	mov    r8,QWORD PTR [r12+0x40]
    77db492feba5:	add    r8,0x25
    77db492feba9:	movzx  r9d,BYTE PTR [r8]
    77db492febad:	mov    r8,r9
    77db492febb0:	shl    r8,0x8
    77db492febb4:	or     r15,r8
    77db492febb7:	mov    r8,QWORD PTR [r12+0x40]
    77db492febbc:	add    r8,0x26
    77db492febc0:	movzx  r9d,BYTE PTR [r8]
    77db492febc4:	mov    r8,r9
    77db492febc7:	shl    r8,0x8
    77db492febcb:	or     rbp,r8
    77db492febce:	mov    r8,QWORD PTR [r12+0x40]
    77db492febd3:	add    r8,0x27
    77db492febd7:	movzx  r9d,BYTE PTR [r8]
    77db492febdb:	mov    r8,r9
    77db492febde:	shl    r8,0x8
    77db492febe2:	or     r13,r8
    77db492febe5:	mov    r8,QWORD PTR [r12+0x40]
    77db492febea:	add    r8,0x28
    77db492febee:	movzx  r9d,BYTE PTR [r8]
    77db492febf2:	mov    r8,r9
    77db492febf5:	shl    r8,0x10
    77db492febf9:	or     r14,r8
    77db492febfc:	mov    r8,QWORD PTR [r12+0x40]
    77db492fec01:	add    r8,0x29
    77db492fec05:	movzx  r9d,BYTE PTR [r8]
    77db492fec09:	mov    r8,r9
    77db492fec0c:	shl    r8,0x10
    77db492fec10:	or     r15,r8
    77db492fec13:	mov    r8,QWORD PTR [r12+0x40]
    77db492fec18:	add    r8,0x2a
    77db492fec1c:	movzx  r9d,BYTE PTR [r8]
    77db492fec20:	mov    r8,r9
    77db492fec23:	shl    r8,0x10
    77db492fec27:	or     rbp,r8
    77db492fec2a:	mov    r8,QWORD PTR [r12+0x40]
    77db492fec2f:	add    r8,0x2b
    77db492fec33:	movzx  r9d,BYTE PTR [r8]
    77db492fec37:	mov    r8,r9
    77db492fec3a:	shl    r8,0x10
    77db492fec3e:	or     r13,r8
    77db492fec41:	mov    r8,QWORD PTR [r12+0x40]
    77db492fec46:	add    r8,0x2c
    77db492fec4a:	movzx  r9d,BYTE PTR [r8]
    77db492fec4e:	mov    r8,r9
    77db492fec51:	shl    r8,0x18
    77db492fec55:	or     r14,r8
    77db492fec58:	mov    r8,QWORD PTR [r12+0x40]
    77db492fec5d:	add    r8,0x2d
    77db492fec61:	movzx  r9d,BYTE PTR [r8]
    77db492fec65:	mov    r8,r9
    77db492fec68:	shl    r8,0x18
    77db492fec6c:	or     r15,r8
    77db492fec6f:	mov    r8,QWORD PTR [r12+0x40]
    77db492fec74:	add    r8,0x2e
    77db492fec78:	movzx  r9d,BYTE PTR [r8]
    77db492fec7c:	mov    r8,r9
    77db492fec7f:	shl    r8,0x18
    77db492fec83:	or     rbp,r8
    77db492fec86:	mov    r8,QWORD PTR [r12+0x40]
    77db492fec8b:	add    r8,0x2f
    77db492fec8f:	movzx  r9d,BYTE PTR [r8]
    77db492fec93:	mov    r8,r9
    77db492fec96:	shl    r8,0x18
    77db492fec9a:	or     r13,r8
    77db492fec9d:	mov    r8,QWORD PTR [r12+0x40]
    77db492feca2:	add    r8,0x30
    77db492feca6:	movzx  r9d,BYTE PTR [r8]
    77db492fecaa:	mov    r8,r9
    77db492fecad:	shl    r8,0x20
    77db492fecb1:	or     r14,r8
    77db492fecb4:	mov    r8,QWORD PTR [r12+0x40]
    77db492fecb9:	add    r8,0x31
    77db492fecbd:	movzx  r9d,BYTE PTR [r8]
    77db492fecc1:	mov    r8,r9
    77db492fecc4:	shl    r8,0x20
    77db492fecc8:	or     r15,r8
    77db492feccb:	mov    r8,QWORD PTR [r12+0x40]
    77db492fecd0:	add    r8,0x32
    77db492fecd4:	movzx  r9d,BYTE PTR [r8]
    77db492fecd8:	mov    r8,r9
    77db492fecdb:	shl    r8,0x20
    77db492fecdf:	or     rbp,r8
    77db492fece2:	mov    r8,QWORD PTR [r12+0x40]
    77db492fece7:	add    r8,0x33
    77db492feceb:	movzx  r9d,BYTE PTR [r8]
    77db492fecef:	mov    r8,r9
    77db492fecf2:	shl    r8,0x20
    77db492fecf6:	or     r13,r8
    77db492fecf9:	mov    r8,QWORD PTR [r12+0x40]
    77db492fecfe:	add    r8,0x34
    77db492fed02:	movzx  r9d,BYTE PTR [r8]
    77db492fed06:	mov    r8,r9
    77db492fed09:	shl    r8,0x28
    77db492fed0d:	or     r14,r8
    77db492fed10:	mov    r8,QWORD PTR [r12+0x40]
    77db492fed15:	add    r8,0x35
    77db492fed19:	movzx  r9d,BYTE PTR [r8]
    77db492fed1d:	mov    r8,r9
    77db492fed20:	shl    r8,0x28
    77db492fed24:	or     r15,r8
    77db492fed27:	mov    r8,QWORD PTR [r12+0x40]
    77db492fed2c:	add    r8,0x36
    77db492fed30:	movzx  r9d,BYTE PTR [r8]
    77db492fed34:	mov    r8,r9
    77db492fed37:	shl    r8,0x28
    77db492fed3b:	or     rbp,r8
    77db492fed3e:	mov    r8,QWORD PTR [r12+0x40]
    77db492fed43:	add    r8,0x37
    77db492fed47:	movzx  r9d,BYTE PTR [r8]
    77db492fed4b:	mov    r8,r9
    77db492fed4e:	shl    r8,0x28
    77db492fed52:	or     r13,r8
    77db492fed55:	mov    r8,QWORD PTR [r12+0x40]
    77db492fed5a:	add    r8,0x38
    77db492fed5e:	movzx  r9d,BYTE PTR [r8]
    77db492fed62:	mov    r8,r9
    77db492fed65:	shl    r8,0x30
    77db492fed69:	or     r14,r8
    77db492fed6c:	mov    r8,QWORD PTR [r12+0x40]
    77db492fed71:	add    r8,0x39
    77db492fed75:	movzx  r9d,BYTE PTR [r8]
    77db492fed79:	mov    r8,r9
    77db492fed7c:	shl    r8,0x30
    77db492fed80:	or     r15,r8
    77db492fed83:	mov    r8,QWORD PTR [r12+0x40]
    77db492fed88:	add    r8,0x3a
    77db492fed8c:	movzx  r9d,BYTE PTR [r8]
    77db492fed90:	mov    r8,r9
    77db492fed93:	shl    r8,0x30
    77db492fed97:	or     rbp,r8
    77db492fed9a:	mov    r8,QWORD PTR [r12+0x40]
    77db492fed9f:	add    r8,0x3b
    77db492feda3:	movzx  r9d,BYTE PTR [r8]
    77db492feda7:	mov    r8,r9
    77db492fedaa:	shl    r8,0x30
    77db492fedae:	or     r13,r8
    77db492fedb1:	mov    r8,QWORD PTR [r12+0x40]
    77db492fedb6:	add    r8,0x3c
    77db492fedba:	movzx  r9d,BYTE PTR [r8]
    77db492fedbe:	mov    r8,r9
    77db492fedc1:	shl    r8,0x38
    77db492fedc5:	or     r14,r8
    77db492fedc8:	mov    r8,QWORD PTR [r12+0x40]
    77db492fedcd:	add    r8,0x3d
    77db492fedd1:	movzx  r9d,BYTE PTR [r8]
    77db492fedd5:	mov    r8,r9
    77db492fedd8:	shl    r8,0x38
    77db492feddc:	or     r15,r8
    77db492feddf:	mov    r8,QWORD PTR [r12+0x40]
    77db492fede4:	add    r8,0x3e
    77db492fede8:	movzx  r9d,BYTE PTR [r8]
    77db492fedec:	mov    r8,r9
    77db492fedef:	shl    r8,0x38
    77db492fedf3:	or     rbp,r8
    77db492fedf6:	mov    r8,QWORD PTR [r12+0x40]
    77db492fedfb:	add    r8,0x3f
    77db492fedff:	movzx  r9d,BYTE PTR [r8]
    77db492fee03:	mov    r8,r9
    77db492fee06:	shl    r8,0x38
    77db492fee0a:	mov    rax,r13
    77db492fee0d:	or     rax,r8
    77db492fee10:	mov    QWORD PTR [rsp+0x40],rax
    77db492fee15:	mov    r8d,0x0
    77db492fee1b:	mov    QWORD PTR [r12+0x58],r8
    77db492fee20:	mov    r8d,0x0
    77db492fee26:	mov    r9,QWORD PTR [rsp+0x38]
    77db492fee2b:	and    r9,0xff
    77db492fee32:	and    r9,0xffff
    77db492fee39:	mov    r13,r8
    77db492fee3c:	or     r13,r9
    77db492fee3f:	mov    r9,QWORD PTR [rsp+0x38]
    77db492fee44:	shr    r9,0x8
    77db492fee48:	and    r9,0xff
    77db492fee4f:	and    r9,0xffff
    77db492fee56:	shl    r9,0x10
    77db492fee5a:	or     r13,r9
    77db492fee5d:	mov    r9,QWORD PTR [rsp+0x38]
    77db492fee62:	shr    r9,0x10
    77db492fee66:	and    r9,0xff
    77db492fee6d:	and    r9,0xffff
    77db492fee74:	shl    r9,0x20
    77db492fee78:	or     r13,r9
    77db492fee7b:	mov    r9,QWORD PTR [rsp+0x38]
    77db492fee80:	shr    r9,0x18
    77db492fee84:	and    r9,0xff
    77db492fee8b:	and    r9,0xffff
    77db492fee92:	shl    r9,0x30
    77db492fee96:	or     r13,r9
    77db492fee99:	mov    r9,QWORD PTR [rsp+0x38]
    77db492fee9e:	shr    r9,0x20
    77db492feea2:	and    r9,0xff
    77db492feea9:	and    r9,0xffff
    77db492feeb0:	or     r8,r9
    77db492feeb3:	mov    r9,QWORD PTR [rsp+0x38]
    77db492feeb8:	shr    r9,0x28
    77db492feebc:	and    r9,0xff
    77db492feec3:	and    r9,0xffff
    77db492feeca:	shl    r9,0x10
    77db492feece:	or     r8,r9
    77db492feed1:	mov    r9,QWORD PTR [rsp+0x38]
    77db492feed6:	shr    r9,0x30
    77db492feeda:	and    r9,0xff
    77db492feee1:	and    r9,0xffff
    77db492feee8:	shl    r9,0x20
    77db492feeec:	or     r8,r9
    77db492feeef:	mov    r9,QWORD PTR [rsp+0x38]
    77db492feef4:	shr    r9,0x38
    77db492feef8:	and    r9,0xff
    77db492feeff:	and    r9,0xffff
    77db492fef06:	shl    r9,0x30
    77db492fef0a:	or     r8,r9
    77db492fef0d:	mov    QWORD PTR [r12+0x150],r13
    77db492fef15:	mov    QWORD PTR [r12+0x158],r8
    77db492fef1d:	mov    r13d,0x0
    77db492fef23:	mov    r8,QWORD PTR [rsp+0x30]
    77db492fef28:	and    r8,0xff
    77db492fef2f:	and    r8,0xffff
    77db492fef36:	mov    r9,r13
    77db492fef39:	or     r9,r8
    77db492fef3c:	mov    r8,QWORD PTR [rsp+0x30]
    77db492fef41:	shr    r8,0x8
    77db492fef45:	and    r8,0xff
    77db492fef4c:	and    r8,0xffff
    77db492fef53:	shl    r8,0x10
    77db492fef57:	or     r9,r8
    77db492fef5a:	mov    r8,QWORD PTR [rsp+0x30]
    77db492fef5f:	shr    r8,0x10
    77db492fef63:	and    r8,0xff
    77db492fef6a:	and    r8,0xffff
    77db492fef71:	shl    r8,0x20
    77db492fef75:	or     r9,r8
    77db492fef78:	mov    r8,QWORD PTR [rsp+0x30]
    77db492fef7d:	shr    r8,0x18
    77db492fef81:	and    r8,0xff
    77db492fef88:	and    r8,0xffff
    77db492fef8f:	shl    r8,0x30
    77db492fef93:	mov    rax,r9
    77db492fef96:	or     rax,r8
    77db492fef99:	mov    QWORD PTR [rsp+0x50],rax
    77db492fef9e:	mov    r8,QWORD PTR [rsp+0x30]
    77db492fefa3:	shr    r8,0x20
    77db492fefa7:	and    r8,0xff
    77db492fefae:	and    r8,0xffff
    77db492fefb5:	or     r13,r8
    77db492fefb8:	mov    r8,QWORD PTR [rsp+0x30]
    77db492fefbd:	shr    r8,0x28
    77db492fefc1:	and    r8,0xff
    77db492fefc8:	and    r8,0xffff
    77db492fefcf:	shl    r8,0x10
    77db492fefd3:	or     r13,r8
    77db492fefd6:	mov    r8,QWORD PTR [rsp+0x30]
    77db492fefdb:	shr    r8,0x30
    77db492fefdf:	and    r8,0xff
    77db492fefe6:	and    r8,0xffff
    77db492fefed:	shl    r8,0x20
    77db492feff1:	or     r13,r8
    77db492feff4:	mov    r8,QWORD PTR [rsp+0x30]
    77db492feff9:	shr    r8,0x38
    77db492feffd:	and    r8,0xff
    77db492ff004:	and    r8,0xffff
    77db492ff00b:	shl    r8,0x30
    77db492ff00f:	mov    rax,r13
    77db492ff012:	or     rax,r8
    77db492ff015:	mov    QWORD PTR [rsp+0x48],rax
    77db492ff01a:	mov    r8d,0x0
    77db492ff020:	mov    r13,QWORD PTR [rsp+0x28]
    77db492ff025:	and    r13,0xff
    77db492ff02c:	and    r13,0xffff
    77db492ff033:	mov    r9,r8
    77db492ff036:	or     r9,r13
    77db492ff039:	mov    r13,QWORD PTR [rsp+0x28]
    77db492ff03e:	shr    r13,0x8
    77db492ff042:	and    r13,0xff
    77db492ff049:	and    r13,0xffff
    77db492ff050:	shl    r13,0x10
    77db492ff054:	or     r9,r13
    77db492ff057:	mov    r13,QWORD PTR [rsp+0x28]
    77db492ff05c:	shr    r13,0x10
    77db492ff060:	and    r13,0xff
    77db492ff067:	and    r13,0xffff
    77db492ff06e:	shl    r13,0x20
    77db492ff072:	or     r9,r13
    77db492ff075:	mov    r13,QWORD PTR [rsp+0x28]
    77db492ff07a:	shr    r13,0x18
    77db492ff07e:	and    r13,0xff
    77db492ff085:	and    r13,0xffff
    77db492ff08c:	shl    r13,0x30
    77db492ff090:	mov    rax,r9
    77db492ff093:	or     rax,r13
    77db492ff096:	mov    QWORD PTR [rsp+0x58],rax
    77db492ff09b:	mov    r13,QWORD PTR [rsp+0x28]
    77db492ff0a0:	shr    r13,0x20
    77db492ff0a4:	and    r13,0xff
    77db492ff0ab:	and    r13,0xffff
    77db492ff0b2:	or     r8,r13
    77db492ff0b5:	mov    r13,QWORD PTR [rsp+0x28]
    77db492ff0ba:	shr    r13,0x28
    77db492ff0be:	and    r13,0xff
    77db492ff0c5:	and    r13,0xffff
    77db492ff0cc:	shl    r13,0x10
    77db492ff0d0:	or     r8,r13
    77db492ff0d3:	mov    r13,QWORD PTR [rsp+0x28]
    77db492ff0d8:	shr    r13,0x30
    77db492ff0dc:	and    r13,0xff
    77db492ff0e3:	and    r13,0xffff
    77db492ff0ea:	shl    r13,0x20
    77db492ff0ee:	or     r8,r13
    77db492ff0f1:	mov    r13,QWORD PTR [rsp+0x28]
    77db492ff0f6:	shr    r13,0x38
    77db492ff0fa:	and    r13,0xff
    77db492ff101:	and    r13,0xffff
    77db492ff108:	shl    r13,0x30
    77db492ff10c:	mov    rax,r8
    77db492ff10f:	or     rax,r13
    77db492ff112:	mov    QWORD PTR [rsp+0x60],rax
    77db492ff117:	mov    r13d,0x0
    77db492ff11d:	mov    r9,r14
    77db492ff120:	and    r9,0xff
    77db492ff127:	and    r9,0xffff
    77db492ff12e:	mov    r8,r13
    77db492ff131:	or     r8,r9
    77db492ff134:	mov    r9,r14
    77db492ff137:	shr    r9,0x8
    77db492ff13b:	and    r9,0xff
    77db492ff142:	and    r9,0xffff
    77db492ff149:	shl    r9,0x10
    77db492ff14d:	or     r8,r9
    77db492ff150:	mov    r9,r14
    77db492ff153:	shr    r9,0x10
    77db492ff157:	and    r9,0xff
    77db492ff15e:	and    r9,0xffff
    77db492ff165:	shl    r9,0x20
    77db492ff169:	or     r8,r9
    77db492ff16c:	mov    r9,r14
    77db492ff16f:	shr    r9,0x18
    77db492ff173:	and    r9,0xff
    77db492ff17a:	and    r9,0xffff
    77db492ff181:	shl    r9,0x30
    77db492ff185:	mov    rax,r8
    77db492ff188:	or     rax,r9
    77db492ff18b:	mov    QWORD PTR [rsp+0x68],rax
    77db492ff190:	mov    r9,r14
    77db492ff193:	shr    r9,0x20
    77db492ff197:	and    r9,0xff
    77db492ff19e:	and    r9,0xffff
    77db492ff1a5:	or     r13,r9
    77db492ff1a8:	mov    r9,r14
    77db492ff1ab:	shr    r9,0x28
    77db492ff1af:	and    r9,0xff
    77db492ff1b6:	and    r9,0xffff
    77db492ff1bd:	shl    r9,0x10
    77db492ff1c1:	or     r13,r9
    77db492ff1c4:	mov    r9,r14
    77db492ff1c7:	shr    r9,0x30
    77db492ff1cb:	and    r9,0xff
    77db492ff1d2:	and    r9,0xffff
    77db492ff1d9:	shl    r9,0x20
    77db492ff1dd:	or     r13,r9
    77db492ff1e0:	shr    r14,0x38
    77db492ff1e4:	and    r14,0xff
    77db492ff1eb:	and    r14,0xffff
    77db492ff1f2:	shl    r14,0x30
    77db492ff1f6:	or     r13,r14
    77db492ff1f9:	mov    r14d,0x0
    77db492ff1ff:	mov    r9,r15
    77db492ff202:	and    r9,0xff
    77db492ff209:	and    r9,0xffff
    77db492ff210:	mov    r8,r14
    77db492ff213:	or     r8,r9
    77db492ff216:	mov    r9,r15
    77db492ff219:	shr    r9,0x8
    77db492ff21d:	and    r9,0xff
    77db492ff224:	and    r9,0xffff
    77db492ff22b:	shl    r9,0x10
    77db492ff22f:	or     r8,r9
    77db492ff232:	mov    r9,r15
    77db492ff235:	shr    r9,0x10
    77db492ff239:	and    r9,0xff
    77db492ff240:	and    r9,0xffff
    77db492ff247:	shl    r9,0x20
    77db492ff24b:	or     r8,r9
    77db492ff24e:	mov    r9,r15
    77db492ff251:	shr    r9,0x18
    77db492ff255:	and    r9,0xff
    77db492ff25c:	and    r9,0xffff
    77db492ff263:	shl    r9,0x30
    77db492ff267:	or     r8,r9
    77db492ff26a:	mov    r9,r15
    77db492ff26d:	shr    r9,0x20
    77db492ff271:	and    r9,0xff
    77db492ff278:	and    r9,0xffff
    77db492ff27f:	or     r14,r9
    77db492ff282:	mov    r9,r15
    77db492ff285:	shr    r9,0x28
    77db492ff289:	and    r9,0xff
    77db492ff290:	and    r9,0xffff
    77db492ff297:	shl    r9,0x10
    77db492ff29b:	or     r14,r9
    77db492ff29e:	mov    r9,r15
    77db492ff2a1:	shr    r9,0x30
    77db492ff2a5:	and    r9,0xff
    77db492ff2ac:	and    r9,0xffff
    77db492ff2b3:	shl    r9,0x20
    77db492ff2b7:	or     r14,r9
    77db492ff2ba:	shr    r15,0x38
    77db492ff2be:	and    r15,0xff
    77db492ff2c5:	and    r15,0xffff
    77db492ff2cc:	shl    r15,0x30
    77db492ff2d0:	or     r14,r15
    77db492ff2d3:	mov    QWORD PTR [r12+0x210],r8
    77db492ff2db:	mov    QWORD PTR [r12+0x218],r14
    77db492ff2e3:	mov    r14d,0x0
    77db492ff2e9:	mov    r15,rbp
    77db492ff2ec:	and    r15,0xff
    77db492ff2f3:	and    r15,0xffff
    77db492ff2fa:	mov    r8,r14
    77db492ff2fd:	or     r8,r15
    77db492ff300:	mov    r15,rbp
    77db492ff303:	shr    r15,0x8
    77db492ff307:	and    r15,0xff
    77db492ff30e:	and    r15,0xffff
    77db492ff315:	shl    r15,0x10
    77db492ff319:	or     r8,r15
    77db492ff31c:	mov    r15,rbp
    77db492ff31f:	shr    r15,0x10
    77db492ff323:	and    r15,0xff
    77db492ff32a:	and    r15,0xffff
    77db492ff331:	shl    r15,0x20
    77db492ff335:	or     r8,r15
    77db492ff338:	mov    r15,rbp
    77db492ff33b:	shr    r15,0x18
    77db492ff33f:	and    r15,0xff
    77db492ff346:	and    r15,0xffff
    77db492ff34d:	shl    r15,0x30
    77db492ff351:	or     r8,r15
    77db492ff354:	mov    r15,rbp
    77db492ff357:	shr    r15,0x20
    77db492ff35b:	and    r15,0xff
    77db492ff362:	and    r15,0xffff
    77db492ff369:	or     r14,r15
    77db492ff36c:	mov    r15,rbp
    77db492ff36f:	shr    r15,0x28
    77db492ff373:	and    r15,0xff
    77db492ff37a:	and    r15,0xffff
    77db492ff381:	shl    r15,0x10
    77db492ff385:	or     r14,r15
    77db492ff388:	mov    r15,rbp
    77db492ff38b:	shr    r15,0x30
    77db492ff38f:	and    r15,0xff
    77db492ff396:	and    r15,0xffff
    77db492ff39d:	shl    r15,0x20
    77db492ff3a1:	or     r14,r15
    77db492ff3a4:	shr    rbp,0x38
    77db492ff3a8:	and    rbp,0xff
    77db492ff3af:	and    rbp,0xffff
    77db492ff3b6:	shl    rbp,0x30
    77db492ff3ba:	or     r14,rbp
    77db492ff3bd:	mov    r15d,0x0
    77db492ff3c3:	mov    rbp,QWORD PTR [rsp+0x20]
    77db492ff3c8:	and    rbp,0xff
    77db492ff3cf:	and    rbp,0xffff
    77db492ff3d6:	mov    r9,r15
    77db492ff3d9:	or     r9,rbp
    77db492ff3dc:	mov    rbp,QWORD PTR [rsp+0x20]
    77db492ff3e1:	shr    rbp,0x8
    77db492ff3e5:	and    rbp,0xff
    77db492ff3ec:	and    rbp,0xffff
    77db492ff3f3:	shl    rbp,0x10
    77db492ff3f7:	or     r9,rbp
    77db492ff3fa:	mov    rbp,QWORD PTR [rsp+0x20]
    77db492ff3ff:	shr    rbp,0x10
    77db492ff403:	and    rbp,0xff
    77db492ff40a:	and    rbp,0xffff
    77db492ff411:	shl    rbp,0x20
    77db492ff415:	or     r9,rbp
    77db492ff418:	mov    rbp,QWORD PTR [rsp+0x20]
    77db492ff41d:	shr    rbp,0x18
    77db492ff421:	and    rbp,0xff
    77db492ff428:	and    rbp,0xffff
    77db492ff42f:	shl    rbp,0x30
    77db492ff433:	mov    rax,r9
    77db492ff436:	or     rax,rbp
    77db492ff439:	mov    QWORD PTR [rsp+0x78],rax
    77db492ff43e:	mov    rbp,QWORD PTR [rsp+0x20]
    77db492ff443:	shr    rbp,0x20
    77db492ff447:	and    rbp,0xff
    77db492ff44e:	and    rbp,0xffff
    77db492ff455:	or     r15,rbp
    77db492ff458:	mov    rbp,QWORD PTR [rsp+0x20]
    77db492ff45d:	shr    rbp,0x28
    77db492ff461:	and    rbp,0xff
    77db492ff468:	and    rbp,0xffff
    77db492ff46f:	shl    rbp,0x10
    77db492ff473:	or     r15,rbp
    77db492ff476:	mov    rbp,QWORD PTR [rsp+0x20]
    77db492ff47b:	shr    rbp,0x30
    77db492ff47f:	and    rbp,0xff
    77db492ff486:	and    rbp,0xffff
    77db492ff48d:	shl    rbp,0x20
    77db492ff491:	or     r15,rbp
    77db492ff494:	mov    rbp,QWORD PTR [rsp+0x20]
    77db492ff499:	shr    rbp,0x38
    77db492ff49d:	and    rbp,0xff
    77db492ff4a4:	and    rbp,0xffff
    77db492ff4ab:	shl    rbp,0x30
    77db492ff4af:	mov    rax,r15
    77db492ff4b2:	or     rax,rbp
    77db492ff4b5:	mov    QWORD PTR [rsp+0x70],rax
    77db492ff4ba:	mov    rax,QWORD PTR [rsp+0x78]
    77db492ff4bf:	mov    QWORD PTR [r12+0x250],rax
    77db492ff4c7:	mov    rax,QWORD PTR [rsp+0x70]
    77db492ff4cc:	mov    QWORD PTR [r12+0x258],rax
    77db492ff4d4:	mov    ebp,0x0
    77db492ff4d9:	mov    r15,QWORD PTR [rsp+0x40]
    77db492ff4de:	and    r15,0xff
    77db492ff4e5:	and    r15,0xffff
    77db492ff4ec:	mov    r9,rbp
    77db492ff4ef:	or     r9,r15
    77db492ff4f2:	mov    r15,QWORD PTR [rsp+0x40]
    77db492ff4f7:	shr    r15,0x8
    77db492ff4fb:	and    r15,0xff
    77db492ff502:	and    r15,0xffff
    77db492ff509:	shl    r15,0x10
    77db492ff50d:	or     r9,r15
    77db492ff510:	mov    r15,QWORD PTR [rsp+0x40]
    77db492ff515:	shr    r15,0x10
    77db492ff519:	and    r15,0xff
    77db492ff520:	and    r15,0xffff
    77db492ff527:	shl    r15,0x20
    77db492ff52b:	or     r9,r15
    77db492ff52e:	mov    r15,QWORD PTR [rsp+0x40]
    77db492ff533:	shr    r15,0x18
    77db492ff537:	and    r15,0xff
    77db492ff53e:	and    r15,0xffff
    77db492ff545:	shl    r15,0x30
    77db492ff549:	mov    rax,r9
    77db492ff54c:	or     rax,r15
    77db492ff54f:	mov    QWORD PTR [rsp+0x80],rax
    77db492ff557:	mov    r15,QWORD PTR [rsp+0x40]
    77db492ff55c:	shr    r15,0x20
    77db492ff560:	and    r15,0xff
    77db492ff567:	and    r15,0xffff
    77db492ff56e:	or     rbp,r15
    77db492ff571:	mov    r15,QWORD PTR [rsp+0x40]
    77db492ff576:	shr    r15,0x28
    77db492ff57a:	and    r15,0xff
    77db492ff581:	and    r15,0xffff
    77db492ff588:	shl    r15,0x10
    77db492ff58c:	or     rbp,r15
    77db492ff58f:	mov    r15,QWORD PTR [rsp+0x40]
    77db492ff594:	shr    r15,0x30
    77db492ff598:	and    r15,0xff
    77db492ff59f:	and    r15,0xffff
    77db492ff5a6:	shl    r15,0x20
    77db492ff5aa:	or     rbp,r15
    77db492ff5ad:	mov    r15,QWORD PTR [rsp+0x40]
    77db492ff5b2:	shr    r15,0x38
    77db492ff5b6:	and    r15,0xff
    77db492ff5bd:	and    r15,0xffff
    77db492ff5c4:	shl    r15,0x30
    77db492ff5c8:	mov    rax,rbp
    77db492ff5cb:	or     rax,r15
    77db492ff5ce:	mov    QWORD PTR [rsp+0x88],rax
    77db492ff5d6:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    77db492ff5e0:	pxor   xmm0,xmm0
    77db492ff5e4:	movdqa xmm3,xmm0
    77db492ff5e8:	movdqa xmm0,xmm2
    77db492ff5ec:	movdqa xmm1,xmm3
    77db492ff5f0:	punpcklwd xmm0,xmm1
    77db492ff5f4:	movdqa xmm4,xmm0
    77db492ff5f8:	movdqa xmm0,xmm4
    77db492ff5fc:	pslld  xmm0,0x10
    77db492ff601:	movdqa xmm3,xmm0
    77db492ff605:	mov    r15d,0x0
    77db492ff60b:	mov    r9,QWORD PTR [rsp+0x50]
    77db492ff610:	and    r9,0xffff
    77db492ff617:	shl    r9,0x8
    77db492ff61b:	mov    ecx,0xffffffff
    77db492ff620:	and    r9,rcx
    77db492ff623:	mov    rbp,r15
    77db492ff626:	or     rbp,r9
    77db492ff629:	mov    r9,QWORD PTR [rsp+0x50]
    77db492ff62e:	shr    r9,0x10
    77db492ff632:	and    r9,0xffff
    77db492ff639:	shl    r9,0x8
    77db492ff63d:	mov    ecx,0xffffffff
    77db492ff642:	and    r9,rcx
    77db492ff645:	shl    r9,0x20
    77db492ff649:	or     rbp,r9
    77db492ff64c:	mov    r9,QWORD PTR [rsp+0x50]
    77db492ff651:	shr    r9,0x20
    77db492ff655:	and    r9,0xffff
    77db492ff65c:	shl    r9,0x8
    77db492ff660:	mov    ecx,0xffffffff
    77db492ff665:	and    r9,rcx
    77db492ff668:	or     r15,r9
    77db492ff66b:	mov    r9,QWORD PTR [rsp+0x50]
    77db492ff670:	shr    r9,0x30
    77db492ff674:	and    r9,0xffff
    77db492ff67b:	shl    r9,0x8
    77db492ff67f:	mov    ecx,0xffffffff
    77db492ff684:	and    r9,rcx
    77db492ff687:	shl    r9,0x20
    77db492ff68b:	or     r15,r9
    77db492ff68e:	mov    QWORD PTR [r12+0x240],rbp
    77db492ff696:	mov    QWORD PTR [r12+0x248],r15
    77db492ff69e:	mov    r15d,0x0
    77db492ff6a4:	mov    rbp,QWORD PTR [rsp+0x60]
    77db492ff6a9:	and    rbp,0xffff
    77db492ff6b0:	mov    ecx,0xffffffff
    77db492ff6b5:	and    rbp,rcx
    77db492ff6b8:	mov    r9,r15
    77db492ff6bb:	or     r9,rbp
    77db492ff6be:	mov    rbp,QWORD PTR [rsp+0x60]
    77db492ff6c3:	shr    rbp,0x10
    77db492ff6c7:	and    rbp,0xffff
    77db492ff6ce:	mov    ecx,0xffffffff
    77db492ff6d3:	and    rbp,rcx
    77db492ff6d6:	shl    rbp,0x20
    77db492ff6da:	or     r9,rbp
    77db492ff6dd:	mov    rbp,QWORD PTR [rsp+0x60]
    77db492ff6e2:	shr    rbp,0x20
    77db492ff6e6:	and    rbp,0xffff
    77db492ff6ed:	mov    ecx,0xffffffff
    77db492ff6f2:	and    rbp,rcx
    77db492ff6f5:	or     r15,rbp
    77db492ff6f8:	mov    rbp,QWORD PTR [rsp+0x60]
    77db492ff6fd:	shr    rbp,0x30
    77db492ff701:	and    rbp,0xffff
    77db492ff708:	mov    ecx,0xffffffff
    77db492ff70d:	and    rbp,rcx
    77db492ff710:	shl    rbp,0x20
    77db492ff714:	or     r15,rbp
    77db492ff717:	mov    QWORD PTR [r12+0x260],r9
    77db492ff71f:	mov    QWORD PTR [r12+0x268],r15
    77db492ff727:	mov    r15d,0x0
    77db492ff72d:	mov    rbp,r13
    77db492ff730:	and    rbp,0xffff
    77db492ff737:	mov    ecx,0xffffffff
    77db492ff73c:	and    rbp,rcx
    77db492ff73f:	mov    r9,r15
    77db492ff742:	or     r9,rbp
    77db492ff745:	mov    rbp,r13
    77db492ff748:	shr    rbp,0x10
    77db492ff74c:	and    rbp,0xffff
    77db492ff753:	mov    ecx,0xffffffff
    77db492ff758:	and    rbp,rcx
    77db492ff75b:	shl    rbp,0x20
    77db492ff75f:	or     r9,rbp
    77db492ff762:	mov    rbp,r13
    77db492ff765:	shr    rbp,0x20
    77db492ff769:	and    rbp,0xffff
    77db492ff770:	mov    ecx,0xffffffff
    77db492ff775:	and    rbp,rcx
    77db492ff778:	or     r15,rbp
    77db492ff77b:	shr    r13,0x30
    77db492ff77f:	and    r13,0xffff
    77db492ff786:	mov    ecx,0xffffffff
    77db492ff78b:	and    r13,rcx
    77db492ff78e:	shl    r13,0x20
    77db492ff792:	or     r15,r13
    77db492ff795:	mov    QWORD PTR [r12+0x270],r9
    77db492ff79d:	mov    QWORD PTR [r12+0x278],r15
    77db492ff7a5:	mov    r13d,0x0
    77db492ff7ab:	mov    r15,QWORD PTR [rsp+0x58]
    77db492ff7b0:	and    r15,0xffff
    77db492ff7b7:	mov    ecx,0xffffffff
    77db492ff7bc:	and    r15,rcx
    77db492ff7bf:	mov    rbp,r13
    77db492ff7c2:	or     rbp,r15
    77db492ff7c5:	mov    r15,QWORD PTR [rsp+0x58]
    77db492ff7ca:	shr    r15,0x10
    77db492ff7ce:	and    r15,0xffff
    77db492ff7d5:	mov    ecx,0xffffffff
    77db492ff7da:	and    r15,rcx
    77db492ff7dd:	shl    r15,0x20
    77db492ff7e1:	or     rbp,r15
    77db492ff7e4:	mov    r15,QWORD PTR [rsp+0x58]
    77db492ff7e9:	shr    r15,0x20
    77db492ff7ed:	and    r15,0xffff
    77db492ff7f4:	mov    ecx,0xffffffff
    77db492ff7f9:	and    r15,rcx
    77db492ff7fc:	or     r13,r15
    77db492ff7ff:	mov    r15,QWORD PTR [rsp+0x58]
    77db492ff804:	shr    r15,0x30
    77db492ff808:	and    r15,0xffff
    77db492ff80f:	mov    ecx,0xffffffff
    77db492ff814:	and    r15,rcx
    77db492ff817:	shl    r15,0x20
    77db492ff81b:	or     r13,r15
    77db492ff81e:	mov    QWORD PTR [r12+0x170],rbp
    77db492ff826:	mov    QWORD PTR [r12+0x178],r13
    77db492ff82e:	movdqu xmm4,XMMWORD PTR [r12+0x210]
    77db492ff838:	pxor   xmm0,xmm0
    77db492ff83c:	movdqa xmm5,xmm0
    77db492ff840:	movdqa xmm0,xmm4
    77db492ff844:	movdqa xmm1,xmm5
    77db492ff848:	punpckhwd xmm0,xmm1
    77db492ff84c:	movdqa xmm6,xmm0
    77db492ff850:	movdqa xmm0,xmm6
    77db492ff854:	pslld  xmm0,0x10
    77db492ff859:	movdqa xmm5,xmm0
    77db492ff85d:	movdqu XMMWORD PTR [r12+0x280],xmm5
    77db492ff867:	mov    r13d,0x0
    77db492ff86d:	mov    r15,QWORD PTR [rsp+0x68]
    77db492ff872:	and    r15,0xffff
    77db492ff879:	mov    ecx,0xffffffff
    77db492ff87e:	and    r15,rcx
    77db492ff881:	mov    rbp,r13
    77db492ff884:	or     rbp,r15
    77db492ff887:	mov    r15,QWORD PTR [rsp+0x68]
    77db492ff88c:	shr    r15,0x10
    77db492ff890:	and    r15,0xffff
    77db492ff897:	mov    ecx,0xffffffff
    77db492ff89c:	and    r15,rcx
    77db492ff89f:	shl    r15,0x20
    77db492ff8a3:	or     rbp,r15
    77db492ff8a6:	mov    r15,QWORD PTR [rsp+0x68]
    77db492ff8ab:	shr    r15,0x20
    77db492ff8af:	and    r15,0xffff
    77db492ff8b6:	mov    ecx,0xffffffff
    77db492ff8bb:	and    r15,rcx
    77db492ff8be:	or     r13,r15
    77db492ff8c1:	mov    r15,QWORD PTR [rsp+0x68]
    77db492ff8c6:	shr    r15,0x30
    77db492ff8ca:	and    r15,0xffff
    77db492ff8d1:	mov    ecx,0xffffffff
    77db492ff8d6:	and    r15,rcx
    77db492ff8d9:	shl    r15,0x20
    77db492ff8dd:	or     r13,r15
    77db492ff8e0:	mov    QWORD PTR [r12+0x180],rbp
    77db492ff8e8:	mov    QWORD PTR [r12+0x188],r13
    77db492ff8f0:	pxor   xmm0,xmm0
    77db492ff8f4:	movdqa xmm6,xmm0
    77db492ff8f8:	movdqa xmm0,xmm4
    77db492ff8fc:	movdqa xmm1,xmm6
    77db492ff900:	punpcklwd xmm0,xmm1
    77db492ff904:	movdqa xmm7,xmm0
    77db492ff908:	movdqa xmm0,xmm7
    77db492ff90c:	pslld  xmm0,0x10
    77db492ff911:	movdqa xmm4,xmm0
    77db492ff915:	pxor   xmm0,xmm0
    77db492ff919:	movdqa xmm6,xmm0
    77db492ff91d:	movdqa xmm0,xmm2
    77db492ff921:	movdqa xmm1,xmm6
    77db492ff925:	punpckhwd xmm0,xmm1
    77db492ff929:	movdqa xmm7,xmm0
    77db492ff92d:	movdqa xmm0,xmm7
    77db492ff931:	pslld  xmm0,0x10
    77db492ff936:	movdqa xmm2,xmm0
    77db492ff93a:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    77db492ff944:	movdqa xmm1,xmm6
    77db492ff948:	por    xmm3,xmm1
    77db492ff94c:	movdqu XMMWORD PTR [r12+0x230],xmm3
    77db492ff956:	mov    r13d,0x0
    77db492ff95c:	mov    r15,r14
    77db492ff95f:	and    r15,0xffff
    77db492ff966:	shl    r15,0x8
    77db492ff96a:	mov    ecx,0xffffffff
    77db492ff96f:	and    r15,rcx
    77db492ff972:	mov    rbp,r13
    77db492ff975:	or     rbp,r15
    77db492ff978:	mov    r15,r14
    77db492ff97b:	shr    r15,0x10
    77db492ff97f:	and    r15,0xffff
    77db492ff986:	shl    r15,0x8
    77db492ff98a:	mov    ecx,0xffffffff
    77db492ff98f:	and    r15,rcx
    77db492ff992:	shl    r15,0x20
    77db492ff996:	or     rbp,r15
    77db492ff999:	mov    r15,r14
    77db492ff99c:	shr    r15,0x20
    77db492ff9a0:	and    r15,0xffff
    77db492ff9a7:	shl    r15,0x8
    77db492ff9ab:	mov    ecx,0xffffffff
    77db492ff9b0:	and    r15,rcx
    77db492ff9b3:	or     r13,r15
    77db492ff9b6:	shr    r14,0x30
    77db492ff9ba:	and    r14,0xffff
    77db492ff9c1:	shl    r14,0x8
    77db492ff9c5:	mov    ecx,0xffffffff
    77db492ff9ca:	and    r14,rcx
    77db492ff9cd:	shl    r14,0x20
    77db492ff9d1:	or     r13,r14
    77db492ff9d4:	mov    QWORD PTR [r12+0x240],rbp
    77db492ff9dc:	mov    QWORD PTR [r12+0x248],r13
    77db492ff9e4:	mov    r13d,0x0
    77db492ff9ea:	mov    r14,r8
    77db492ff9ed:	and    r14,0xffff
    77db492ff9f4:	shl    r14,0x8
    77db492ff9f8:	mov    ecx,0xffffffff
    77db492ff9fd:	and    r14,rcx
    77db492ffa00:	mov    r15,r13
    77db492ffa03:	or     r15,r14
    77db492ffa06:	mov    r14,r8
    77db492ffa09:	shr    r14,0x10
    77db492ffa0d:	and    r14,0xffff
    77db492ffa14:	shl    r14,0x8
    77db492ffa18:	mov    ecx,0xffffffff
    77db492ffa1d:	and    r14,rcx
    77db492ffa20:	shl    r14,0x20
    77db492ffa24:	or     r15,r14
    77db492ffa27:	mov    r14,r8
    77db492ffa2a:	shr    r14,0x20
    77db492ffa2e:	and    r14,0xffff
    77db492ffa35:	shl    r14,0x8
    77db492ffa39:	mov    ecx,0xffffffff
    77db492ffa3e:	and    r14,rcx
    77db492ffa41:	or     r13,r14
    77db492ffa44:	shr    r8,0x30
    77db492ffa48:	and    r8,0xffff
    77db492ffa4f:	shl    r8,0x8
    77db492ffa53:	mov    ecx,0xffffffff
    77db492ffa58:	and    r8,rcx
    77db492ffa5b:	shl    r8,0x20
    77db492ffa5f:	or     r13,r8
    77db492ffa62:	mov    QWORD PTR [r12+0x220],r15
    77db492ffa6a:	mov    QWORD PTR [r12+0x228],r13
    77db492ffa72:	mov    r13d,0x0
    77db492ffa78:	mov    r14,QWORD PTR [rsp+0x48]
    77db492ffa7d:	and    r14,0xffff
    77db492ffa84:	shl    r14,0x8
    77db492ffa88:	mov    ecx,0xffffffff
    77db492ffa8d:	and    r14,rcx
    77db492ffa90:	mov    r15,r13
    77db492ffa93:	or     r15,r14
    77db492ffa96:	mov    r14,QWORD PTR [rsp+0x48]
    77db492ffa9b:	shr    r14,0x10
    77db492ffa9f:	and    r14,0xffff
    77db492ffaa6:	shl    r14,0x8
    77db492ffaaa:	mov    ecx,0xffffffff
    77db492ffaaf:	and    r14,rcx
    77db492ffab2:	shl    r14,0x20
    77db492ffab6:	or     r15,r14
    77db492ffab9:	mov    r14,QWORD PTR [rsp+0x48]
    77db492ffabe:	shr    r14,0x20
    77db492ffac2:	and    r14,0xffff
    77db492ffac9:	shl    r14,0x8
    77db492ffacd:	mov    ecx,0xffffffff
    77db492ffad2:	and    r14,rcx
    77db492ffad5:	or     r13,r14
    77db492ffad8:	mov    r14,QWORD PTR [rsp+0x48]
    77db492ffadd:	shr    r14,0x30
    77db492ffae1:	and    r14,0xffff
    77db492ffae8:	shl    r14,0x8
    77db492ffaec:	mov    ecx,0xffffffff
    77db492ffaf1:	and    r14,rcx
    77db492ffaf4:	shl    r14,0x20
    77db492ffaf8:	or     r13,r14
    77db492ffafb:	mov    QWORD PTR [r12+0x160],r15
    77db492ffb03:	mov    QWORD PTR [r12+0x168],r13
    77db492ffb0b:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    77db492ffb15:	movdqa xmm0,xmm6
    77db492ffb19:	pslld  xmm0,0x18
    77db492ffb1e:	movdqa xmm7,xmm0
    77db492ffb22:	movdqu XMMWORD PTR [r12+0x170],xmm7
    77db492ffb2c:	movdqu xmm6,XMMWORD PTR [r12+0x270]
    77db492ffb36:	movdqa xmm0,xmm6
    77db492ffb3a:	pslld  xmm0,0x18
    77db492ffb3f:	movdqa xmm8,xmm0
    77db492ffb44:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    77db492ffb4e:	movdqa xmm0,xmm6
    77db492ffb52:	pslld  xmm0,0x18
    77db492ffb57:	movdqa xmm9,xmm0
    77db492ffb5c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    77db492ffb66:	mov    r13d,0x0
    77db492ffb6c:	mov    r14,QWORD PTR [rsp+0x78]
    77db492ffb71:	and    r14,0xffff
    77db492ffb78:	mov    ecx,0xffffffff
    77db492ffb7d:	and    r14,rcx
    77db492ffb80:	mov    r15,r13
    77db492ffb83:	or     r15,r14
    77db492ffb86:	mov    r14,QWORD PTR [rsp+0x78]
    77db492ffb8b:	shr    r14,0x10
    77db492ffb8f:	and    r14,0xffff
    77db492ffb96:	mov    ecx,0xffffffff
    77db492ffb9b:	and    r14,rcx
    77db492ffb9e:	shl    r14,0x20
    77db492ffba2:	or     r15,r14
    77db492ffba5:	mov    r14,QWORD PTR [rsp+0x78]
    77db492ffbaa:	shr    r14,0x20
    77db492ffbae:	and    r14,0xffff
    77db492ffbb5:	mov    ecx,0xffffffff
    77db492ffbba:	and    r14,rcx
    77db492ffbbd:	or     r13,r14
    77db492ffbc0:	mov    r14,QWORD PTR [rsp+0x78]
    77db492ffbc5:	shr    r14,0x30
    77db492ffbc9:	and    r14,0xffff
    77db492ffbd0:	mov    ecx,0xffffffff
    77db492ffbd5:	and    r14,rcx
    77db492ffbd8:	shl    r14,0x20
    77db492ffbdc:	or     r13,r14
    77db492ffbdf:	mov    QWORD PTR [r12+0x140],r15
    77db492ffbe7:	mov    QWORD PTR [r12+0x148],r13
    77db492ffbef:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    77db492ffbf9:	movdqa xmm1,xmm6
    77db492ffbfd:	por    xmm5,xmm1
    77db492ffc01:	movdqu xmm6,XMMWORD PTR [r12+0x220]
    77db492ffc0b:	movdqa xmm1,xmm6
    77db492ffc0f:	por    xmm4,xmm1
    77db492ffc13:	movdqu XMMWORD PTR [r12+0x210],xmm4
    77db492ffc1d:	movdqu xmm6,XMMWORD PTR [r12+0x260]
    77db492ffc27:	movdqa xmm0,xmm6
    77db492ffc2b:	pslld  xmm0,0x18
    77db492ffc30:	movdqa xmm10,xmm0
    77db492ffc35:	movdqu XMMWORD PTR [r12+0x220],xmm10
    77db492ffc3f:	movdqu xmm6,XMMWORD PTR [r12+0x160]
    77db492ffc49:	movdqa xmm1,xmm6
    77db492ffc4d:	por    xmm2,xmm1
    77db492ffc51:	movdqa xmm1,xmm7
    77db492ffc55:	por    xmm3,xmm1
    77db492ffc59:	movdqu XMMWORD PTR [r12+0x160],xmm3
    77db492ffc63:	mov    r13d,0x0
    77db492ffc69:	mov    r14,QWORD PTR [rsp+0x88]
    77db492ffc71:	and    r14,0xffff
    77db492ffc78:	mov    ecx,0xffffffff
    77db492ffc7d:	and    r14,rcx
    77db492ffc80:	mov    r15,r13
    77db492ffc83:	or     r15,r14
    77db492ffc86:	mov    r14,QWORD PTR [rsp+0x88]
    77db492ffc8e:	shr    r14,0x10
    77db492ffc92:	and    r14,0xffff
    77db492ffc99:	mov    ecx,0xffffffff
    77db492ffc9e:	and    r14,rcx
    77db492ffca1:	shl    r14,0x20
    77db492ffca5:	or     r15,r14
    77db492ffca8:	mov    r14,QWORD PTR [rsp+0x88]
    77db492ffcb0:	shr    r14,0x20
    77db492ffcb4:	and    r14,0xffff
    77db492ffcbb:	mov    ecx,0xffffffff
    77db492ffcc0:	and    r14,rcx
    77db492ffcc3:	or     r13,r14
    77db492ffcc6:	mov    r14,QWORD PTR [rsp+0x88]
    77db492ffcce:	shr    r14,0x30
    77db492ffcd2:	and    r14,0xffff
    77db492ffcd9:	mov    ecx,0xffffffff
    77db492ffcde:	and    r14,rcx
    77db492ffce1:	shl    r14,0x20
    77db492ffce5:	or     r13,r14
    77db492ffce8:	mov    QWORD PTR [r12+0x170],r15
    77db492ffcf0:	mov    QWORD PTR [r12+0x178],r13
    77db492ffcf8:	mov    r13d,0x0
    77db492ffcfe:	mov    r14,QWORD PTR [rsp+0x80]
    77db492ffd06:	and    r14,0xffff
    77db492ffd0d:	mov    ecx,0xffffffff
    77db492ffd12:	and    r14,rcx
    77db492ffd15:	mov    r15,r13
    77db492ffd18:	or     r15,r14
    77db492ffd1b:	mov    r14,QWORD PTR [rsp+0x80]
    77db492ffd23:	shr    r14,0x10
    77db492ffd27:	and    r14,0xffff
    77db492ffd2e:	mov    ecx,0xffffffff
    77db492ffd33:	and    r14,rcx
    77db492ffd36:	shl    r14,0x20
    77db492ffd3a:	or     r15,r14
    77db492ffd3d:	mov    r14,QWORD PTR [rsp+0x80]
    77db492ffd45:	shr    r14,0x20
    77db492ffd49:	and    r14,0xffff
    77db492ffd50:	mov    ecx,0xffffffff
    77db492ffd55:	and    r14,rcx
    77db492ffd58:	or     r13,r14
    77db492ffd5b:	mov    r14,QWORD PTR [rsp+0x80]
    77db492ffd63:	shr    r14,0x30
    77db492ffd67:	and    r14,0xffff
    77db492ffd6e:	mov    ecx,0xffffffff
    77db492ffd73:	and    r14,rcx
    77db492ffd76:	shl    r14,0x20
    77db492ffd7a:	or     r13,r14
    77db492ffd7d:	mov    QWORD PTR [r12+0x110],r15
    77db492ffd85:	mov    QWORD PTR [r12+0x118],r13
    77db492ffd8d:	movdqa xmm1,xmm8
    77db492ffd92:	por    xmm5,xmm1
    77db492ffd96:	movdqa xmm1,xmm9
    77db492ffd9b:	por    xmm4,xmm1
    77db492ffd9f:	mov    r13d,0x0
    77db492ffda5:	mov    r14,QWORD PTR [rsp+0x70]
    77db492ffdaa:	and    r14,0xffff
    77db492ffdb1:	mov    ecx,0xffffffff
    77db492ffdb6:	and    r14,rcx
    77db492ffdb9:	mov    r15,r13
    77db492ffdbc:	or     r15,r14
    77db492ffdbf:	mov    r14,QWORD PTR [rsp+0x70]
    77db492ffdc4:	shr    r14,0x10
    77db492ffdc8:	and    r14,0xffff
    77db492ffdcf:	mov    ecx,0xffffffff
    77db492ffdd4:	and    r14,rcx
    77db492ffdd7:	shl    r14,0x20
    77db492ffddb:	or     r15,r14
    77db492ffdde:	mov    r14,QWORD PTR [rsp+0x70]
    77db492ffde3:	shr    r14,0x20
    77db492ffde7:	and    r14,0xffff
    77db492ffdee:	mov    ecx,0xffffffff
    77db492ffdf3:	and    r14,rcx
    77db492ffdf6:	or     r13,r14
    77db492ffdf9:	mov    r14,QWORD PTR [rsp+0x70]
    77db492ffdfe:	shr    r14,0x30
    77db492ffe02:	and    r14,0xffff
    77db492ffe09:	mov    ecx,0xffffffff
    77db492ffe0e:	and    r14,rcx
    77db492ffe11:	shl    r14,0x20
    77db492ffe15:	or     r13,r14
    77db492ffe18:	mov    QWORD PTR [r12+0x180],r15
    77db492ffe20:	mov    QWORD PTR [r12+0x188],r13
    77db492ffe28:	movdqa xmm1,xmm10
    77db492ffe2d:	por    xmm2,xmm1
    77db492ffe31:	movdqu XMMWORD PTR [r12+0x150],xmm2
    77db492ffe3b:	movdqu xmm6,XMMWORD PTR [r12+0x140]
    77db492ffe45:	movdqa xmm1,xmm6
    77db492ffe49:	por    xmm3,xmm1
    77db492ffe4d:	movdqu XMMWORD PTR [r12+0x140],xmm3
    77db492ffe57:	movdqu xmm6,XMMWORD PTR [r12+0x110]
    77db492ffe61:	movdqa xmm1,xmm6
    77db492ffe65:	por    xmm4,xmm1
    77db492ffe69:	movdqu XMMWORD PTR [r12+0x110],xmm4
    77db492ffe73:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    77db492ffe7d:	movdqa xmm1,xmm6
    77db492ffe81:	por    xmm5,xmm1
    77db492ffe85:	movdqu XMMWORD PTR [r12+0x120],xmm5
    77db492ffe8f:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    77db492ffe99:	movdqa xmm1,xmm6
    77db492ffe9d:	por    xmm2,xmm1
    77db492ffea1:	movdqu XMMWORD PTR [r12+0x130],xmm2
    77db492ffeab:	mov    r13,QWORD PTR [r12+0xf8]
    77db492ffeb3:	mov    r14,r13
    77db492ffeb6:	add    r14,0x20
    77db492ffeba:	mov    r15,r14
    77db492ffebd:	add    r15,0x10
    77db492ffec1:	movdqu XMMWORD PTR [r14],xmm4
    77db492ffec6:	mov    r14d,0x0
    77db492ffecc:	mov    DWORD PTR [r12+0x32c],r14d
    77db492ffed4:	movdqu XMMWORD PTR [r15],xmm5
    77db492ffed9:	mov    r14,r13
    77db492ffedc:	add    r14,0x10
    77db492ffee0:	movdqu XMMWORD PTR [r13+0x0],xmm3
    77db492ffee6:	movdqu XMMWORD PTR [r14],xmm2
    77db492ffeeb:	mov    r14d,DWORD PTR [r13+0x0]
    77db492ffeef:	mov    QWORD PTR [r12+0x60],r14
    77db492ffef4:	jmp    0x77db492ffef9
    77db492ffef9:	mov    r13,QWORD PTR [r12+0x58]
    77db492ffefe:	mov    r14,QWORD PTR [r12+0x48]
    77db492fff03:	add    r14,r13
    77db492fff06:	mov    QWORD PTR [r12+0x68],r14
    77db492fff0b:	add    r13,0x4
    77db492fff0f:	mov    QWORD PTR [r12+0x58],r13
    77db492fff14:	mov    r15,r14
    77db492fff17:	add    r15,0x4
    77db492fff1b:	mov    eax,DWORD PTR [r15]
    77db492fff1e:	mov    QWORD PTR [r12+0x70],rax
    77db492fff23:	mov    r15,r14
    77db492fff26:	add    r15,0x38
    77db492fff2a:	mov    r8d,DWORD PTR [r15]
    77db492fff2d:	mov    QWORD PTR [r12+0x78],r8
    77db492fff32:	mov    r15,r14
    77db492fff35:	add    r15,0x24
    77db492fff39:	mov    r9d,DWORD PTR [r15]
    77db492fff3c:	mov    QWORD PTR [r12+0x90],r9
    77db492fff44:	sub    r13,0xc0
    77db492fff4b:	setne  BYTE PTR [rsp+0xb8]
    77db492fff53:	mov    r11,rax
    77db492fff56:	lahf
    77db492fff57:	seto   al
    77db492fff5a:	mov    WORD PTR [rsp+0xb0],ax
    77db492fff62:	mov    rax,r11
    77db492fff65:	mov    r13d,DWORD PTR [r12+0x70]
    77db492fff6a:	mov    r13d,r13d
    77db492fff6d:	mov    r13d,r13d
    77db492fff70:	ror    r13d,0x7
    77db492fff74:	mov    QWORD PTR [r12+0x80],r13
    77db492fff7c:	mov    r15d,r8d
    77db492fff7f:	mov    r15d,r15d
    77db492fff82:	ror    r15d,0x11
    77db492fff86:	mov    QWORD PTR [r12+0x88],r15
    77db492fff8e:	mov    ebp,DWORD PTR [r12+0x60]
    77db492fff93:	add    r9d,ebp
    77db492fff96:	mov    QWORD PTR [r12+0x60],r9
    77db492fff9b:	mov    ebp,DWORD PTR [r12+0x70]
    77db492fffa0:	mov    ebp,ebp
    77db492fffa2:	mov    ebp,ebp
    77db492fffa4:	ror    ebp,0x12
    77db492fffa7:	xor    r13d,ebp
    77db492fffaa:	mov    QWORD PTR [r12+0x80],r13
    77db492fffb2:	mov    ebp,r8d
    77db492fffb5:	mov    ebp,ebp
    77db492fffb7:	ror    ebp,0x13
    77db492fffba:	xor    r15d,ebp
    77db492fffbd:	mov    QWORD PTR [r12+0x88],r15
    77db492fffc5:	mov    ebp,DWORD PTR [r12+0x70]
    77db492fffca:	mov    ebp,ebp
    77db492fffcc:	mov    ebp,ebp
    77db492fffce:	shr    ebp,0x3
    77db492fffd1:	xor    r13d,ebp
    77db492fffd4:	mov    QWORD PTR [r12+0x80],r13
    77db492fffdc:	mov    r8d,r8d
    77db492fffdf:	shr    r8d,0xa
    77db492fffe3:	xor    r15d,r8d
    77db492fffe6:	mov    QWORD PTR [r12+0x78],r15
    77db492fffeb:	add    r9d,r13d
    77db492fffee:	mov    QWORD PTR [r12+0x60],r9
    77db492ffff3:	add    r9d,r15d
    77db492ffff6:	mov    QWORD PTR [r12+0x60],r9
    77db492ffffb:	add    r14,0x40
    77db492fffff:	mov    DWORD PTR [r14],r9d
    77db49300002:	mov    r13d,0x0
    77db49300008:	mov    DWORD PTR [r12+0x32c],r13d
    77db49300010:	mov    r13d,0x0
    77db49300016:	mov    ecx,DWORD PTR [r12+0x70]
    77db4930001b:	mov    ecx,ecx
    77db4930001d:	mov    r14d,r13d
    77db49300020:	or     r14d,ecx
    77db49300023:	mov    QWORD PTR [r12+0x60],r14
    77db49300028:	mov    rcx,QWORD PTR [r12+0x380]
    77db49300030:	jrcxz  0x77db49300037
    77db49300032:	jmp    0x77db4930081a
    77db49300037:	cmp    BYTE PTR [rsp+0xb8],0x0
    77db4930003f:	jne    0x77db492ffef9
    77db49300045:	jmp    0x77db4930004a
    77db4930004a:	mov    r13,QWORD PTR [r12]
    77db4930004e:	mov    r14,r13
    77db49300051:	add    r14,0x4
    77db49300055:	mov    r15d,DWORD PTR [r13+0x0]
    77db49300059:	mov    ebp,DWORD PTR [r14]
    77db4930005c:	mov    QWORD PTR [r12+0x78],r15
    77db49300061:	mov    QWORD PTR [r12+0x80],rbp
    77db49300069:	mov    r14,r13
    77db4930006c:	add    r14,0x8
    77db49300070:	mov    r8,r14
    77db49300073:	add    r8,0x4
    77db49300077:	mov    r9d,DWORD PTR [r14]
    77db4930007a:	mov    eax,DWORD PTR [r8]
    77db4930007d:	mov    QWORD PTR [rsp+0x90],rax
    77db49300085:	mov    QWORD PTR [r12+0x70],r9
    77db4930008a:	mov    rax,QWORD PTR [rsp+0x90]
    77db49300092:	mov    QWORD PTR [r12+0x68],rax
    77db49300097:	mov    r8,r13
    77db4930009a:	add    r8,0x18
    77db4930009e:	mov    r14,r8
    77db493000a1:	add    r14,0x4
    77db493000a5:	mov    eax,DWORD PTR [r8]
    77db493000a8:	mov    QWORD PTR [rsp+0x98],rax
    77db493000b0:	mov    r8d,DWORD PTR [r14]
    77db493000b3:	mov    rax,QWORD PTR [rsp+0x98]
    77db493000bb:	mov    QWORD PTR [r12+0x58],rax
    77db493000c0:	mov    QWORD PTR [r12+0x60],r8
    77db493000c5:	add    r13,0x10
    77db493000c9:	mov    r14,r13
    77db493000cc:	add    r14,0x4
    77db493000d0:	mov    eax,DWORD PTR [r13+0x0]
    77db493000d4:	mov    QWORD PTR [rsp+0xa0],rax
    77db493000dc:	mov    eax,DWORD PTR [r14]
    77db493000df:	mov    QWORD PTR [rsp+0xa8],rax
    77db493000e7:	mov    rax,QWORD PTR [rsp+0xa0]
    77db493000ef:	mov    QWORD PTR [r12+0x18],rax
    77db493000f4:	mov    rax,QWORD PTR [rsp+0xa8]
    77db493000fc:	mov    QWORD PTR [r12+0x90],rax
    77db49300104:	mov    r14d,0x0
    77db4930010a:	mov    QWORD PTR [r12+0x88],r14
    77db49300112:	mov    r14d,0x0
    77db49300118:	mov    r13d,r14d
    77db4930011b:	or     r13d,r15d
    77db4930011e:	mov    QWORD PTR [r12+0xa8],r13
    77db49300126:	mov    r13d,0x0
    77db4930012c:	mov    r14d,r13d
    77db4930012f:	or     r14d,ebp
    77db49300132:	mov    QWORD PTR [r12+0x38],r14
    77db49300137:	mov    r13d,0x0
    77db4930013d:	mov    r14d,r13d
    77db49300140:	or     r14d,r9d
    77db49300143:	mov    QWORD PTR [r12+0x98],r14
    77db4930014b:	mov    r13d,0x0
    77db49300151:	mov    ecx,DWORD PTR [rsp+0x90]
    77db49300158:	mov    r14d,r13d
    77db4930015b:	or     r14d,ecx
    77db4930015e:	mov    QWORD PTR [r12+0x28],r14
    77db49300163:	mov    r13d,0x0
    77db49300169:	mov    r14d,r13d
    77db4930016c:	or     r14d,r8d
    77db4930016f:	mov    QWORD PTR [r12+0xb0],r14
    77db49300177:	mov    r13d,0x0
    77db4930017d:	mov    ecx,DWORD PTR [rsp+0x98]
    77db49300184:	mov    r14d,r13d
    77db49300187:	or     r14d,ecx
    77db4930018a:	mov    QWORD PTR [r12+0xc0],r14
    77db49300192:	mov    r13d,0x0
    77db49300198:	mov    ecx,DWORD PTR [rsp+0xa8]
    77db4930019f:	mov    r14d,r13d
    77db493001a2:	or     r14d,ecx
    77db493001a5:	mov    QWORD PTR [r12+0xc8],r14
    77db493001ad:	mov    r13d,0x0
    77db493001b3:	mov    ecx,DWORD PTR [rsp+0xa0]
    77db493001ba:	mov    r14d,r13d
    77db493001bd:	or     r14d,ecx
    77db493001c0:	mov    QWORD PTR [r12+0xb8],r14
    77db493001c8:	jmp    0x77db493001cd
    77db493001cd:	mov    r13d,0x0
    77db493001d3:	mov    r14d,DWORD PTR [r12+0xb8]
    77db493001db:	mov    eax,r13d
    77db493001de:	or     eax,r14d
    77db493001e1:	mov    QWORD PTR [r12+0x30],rax
    77db493001e6:	mov    r13d,0x0
    77db493001ec:	mov    ebp,DWORD PTR [r12+0xc0]
    77db493001f4:	mov    eax,r13d
    77db493001f7:	or     eax,ebp
    77db493001f9:	mov    QWORD PTR [r12+0xa0],rax
    77db49300201:	mov    r13d,0x0
    77db49300207:	mov    ebp,DWORD PTR [r12+0x28]
    77db4930020c:	mov    eax,r13d
    77db4930020f:	or     eax,ebp
    77db49300211:	mov    QWORD PTR [r12+0xc0],rax
    77db49300219:	mov    r13d,0x0
    77db4930021f:	mov    ebp,DWORD PTR [r12+0x98]
    77db49300227:	mov    eax,r13d
    77db4930022a:	or     eax,ebp
    77db4930022c:	mov    QWORD PTR [r12+0x28],rax
    77db49300231:	mov    r13d,0x0
    77db49300237:	mov    ebp,DWORD PTR [r12+0x38]
    77db4930023c:	mov    eax,r13d
    77db4930023f:	or     eax,ebp
    77db49300241:	mov    QWORD PTR [r12+0x98],rax
    77db49300249:	mov    r13d,0x0
    77db4930024f:	mov    ebp,DWORD PTR [r12+0xa8]
    77db49300257:	mov    eax,r13d
    77db4930025a:	or     eax,ebp
    77db4930025c:	mov    QWORD PTR [r12+0x38],rax
    77db49300261:	mov    r14d,r14d
    77db49300264:	ror    r14d,0x6
    77db49300268:	mov    QWORD PTR [r12+0xb8],r14
    77db49300270:	mov    r13d,DWORD PTR [r12+0xc8]
    77db49300278:	mov    ebp,DWORD PTR [r12+0x30]
    77db4930027d:	mov    ebp,ebp
    77db4930027f:	and    ebp,r13d
    77db49300282:	mov    QWORD PTR [r12+0xa8],rbp
    77db4930028a:	mov    r9d,DWORD PTR [r12+0x38]
    77db4930028f:	mov    r9d,r9d
    77db49300292:	mov    r9d,r9d
    77db49300295:	ror    r9d,0x2
    77db49300299:	mov    QWORD PTR [r12+0xd0],r9
    77db493002a1:	mov    r15d,0x0
    77db493002a7:	mov    eax,r15d
    77db493002aa:	or     eax,r13d
    77db493002ad:	mov    QWORD PTR [r12+0x20],rax
    77db493002b2:	mov    rax,QWORD PTR [r12+0x88]
    77db493002ba:	mov    r15,QWORD PTR [r12+0x50]
    77db493002bf:	mov    rcx,QWORD PTR [r12+0x88]
    77db493002c7:	add    r15,rcx
    77db493002ca:	mov    r13d,DWORD PTR [r15]
    77db493002cd:	mov    QWORD PTR [r12+0xc8],r13
    77db493002d5:	mov    ecx,DWORD PTR [r12+0x30]
    77db493002da:	mov    ecx,ecx
    77db493002dc:	mov    r15d,DWORD PTR [r12+0xa0]
    77db493002e4:	mov    r15d,r15d
    77db493002e7:	not    rcx
    77db493002ea:	and    r15d,ecx
    77db493002ed:	mov    QWORD PTR [r12+0xd8],r15
    77db493002f5:	mov    r8d,DWORD PTR [r12+0xb0]
    77db493002fd:	add    ebp,r8d
    77db49300300:	mov    QWORD PTR [r12+0xa8],rbp
    77db49300308:	mov    r8d,DWORD PTR [r12+0x30]
    77db4930030d:	mov    r8d,r8d
    77db49300310:	mov    r8d,r8d
    77db49300313:	ror    r8d,0xb
    77db49300317:	xor    r14d,r8d
    77db4930031a:	mov    QWORD PTR [r12+0xb0],r14
    77db49300322:	mov    r8d,DWORD PTR [r12+0x38]
    77db49300327:	mov    r8d,r8d
    77db4930032a:	mov    r8d,r8d
    77db4930032d:	ror    r8d,0xd
    77db49300331:	xor    r9d,r8d
    77db49300334:	mov    QWORD PTR [r12+0xd0],r9
    77db4930033c:	add    ebp,r15d
    77db4930033f:	mov    QWORD PTR [r12+0xa8],rbp
    77db49300347:	mov    r15,QWORD PTR [r12+0x48]
    77db4930034c:	mov    rcx,QWORD PTR [r12+0x88]
    77db49300354:	add    r15,rcx
    77db49300357:	mov    r8d,DWORD PTR [r15]
    77db4930035a:	mov    QWORD PTR [r12+0xb8],r8
    77db49300362:	mov    ecx,DWORD PTR [r12+0x98]
    77db4930036a:	mov    ecx,ecx
    77db4930036c:	mov    eax,DWORD PTR [r12+0x28]
    77db49300371:	mov    eax,eax
    77db49300373:	and    eax,ecx
    77db49300375:	mov    QWORD PTR [r12+0xd8],rax
    77db4930037d:	add    ebp,r13d
    77db49300380:	mov    QWORD PTR [r12+0xa8],rbp
    77db49300388:	mov    ecx,DWORD PTR [r12+0x98]
    77db49300390:	mov    ecx,ecx
    77db49300392:	mov    r13d,DWORD PTR [r12+0x28]
    77db49300397:	mov    r13d,r13d
    77db4930039a:	xor    r13d,ecx
    77db4930039d:	mov    QWORD PTR [r12+0xc8],r13
    77db493003a5:	mov    r15d,DWORD PTR [r12+0x30]
    77db493003aa:	mov    r15d,r15d
    77db493003ad:	mov    r15d,r15d
    77db493003b0:	ror    r15d,0x19
    77db493003b4:	xor    r14d,r15d
    77db493003b7:	mov    QWORD PTR [r12+0xb0],r14
    77db493003bf:	mov    ecx,DWORD PTR [r12+0x38]
    77db493003c4:	mov    ecx,ecx
    77db493003c6:	and    r13d,ecx
    77db493003c9:	mov    QWORD PTR [r12+0xc8],r13
    77db493003d1:	mov    r15d,DWORD PTR [r12+0x38]
    77db493003d6:	mov    r15d,r15d
    77db493003d9:	mov    r15d,r15d
    77db493003dc:	ror    r15d,0x16
    77db493003e0:	xor    r9d,r15d
    77db493003e3:	mov    QWORD PTR [r12+0xd0],r9
    77db493003eb:	add    ebp,r8d
    77db493003ee:	mov    QWORD PTR [r12+0xa8],rbp
    77db493003f6:	mov    ecx,DWORD PTR [r12+0xd8]
    77db493003fe:	mov    ecx,ecx
    77db49300400:	xor    r13d,ecx
    77db49300403:	mov    QWORD PTR [r12+0xb8],r13
    77db4930040b:	add    ebp,r14d
    77db4930040e:	mov    QWORD PTR [r12+0xa8],rbp
    77db49300416:	mov    r14,QWORD PTR [r12+0x88]
    77db4930041e:	add    r14,0x4
    77db49300422:	mov    QWORD PTR [r12+0x88],r14
    77db4930042a:	add    r13d,r9d
    77db4930042d:	mov    QWORD PTR [r12+0xb0],r13
    77db49300435:	mov    ecx,DWORD PTR [r12+0xc0]
    77db4930043d:	mov    ecx,ecx
    77db4930043f:	mov    r15d,ebp
    77db49300442:	add    r15d,ecx
    77db49300445:	mov    QWORD PTR [r12+0xb8],r15
    77db4930044d:	sub    r14,0x100
    77db49300454:	setne  BYTE PTR [rsp+0xb8]
    77db4930045c:	mov    r11,rax
    77db4930045f:	lahf
    77db49300460:	seto   al
    77db49300463:	mov    WORD PTR [rsp+0xb0],ax
    77db4930046b:	mov    rax,r11
    77db4930046e:	add    r13d,ebp
    77db49300471:	mov    QWORD PTR [r12+0xa8],r13
    77db49300479:	mov    r13d,0x0
    77db4930047f:	mov    ecx,DWORD PTR [r12+0xa0]
    77db49300487:	mov    ecx,ecx
    77db49300489:	mov    r14d,r13d
    77db4930048c:	or     r14d,ecx
    77db4930048f:	mov    QWORD PTR [r12+0xb0],r14
    77db49300497:	mov    r13d,0x0
    77db4930049d:	mov    ecx,DWORD PTR [r12+0x20]
    77db493004a2:	mov    ecx,ecx
    77db493004a4:	mov    r14d,r13d
    77db493004a7:	or     r14d,ecx
    77db493004aa:	mov    QWORD PTR [r12+0xc0],r14
    77db493004b2:	mov    r13d,0x0
    77db493004b8:	mov    ecx,DWORD PTR [r12+0x30]
    77db493004bd:	mov    ecx,ecx
    77db493004bf:	mov    r14d,r13d
    77db493004c2:	or     r14d,ecx
    77db493004c5:	mov    QWORD PTR [r12+0xc8],r14
    77db493004cd:	mov    rcx,QWORD PTR [r12+0x380]
    77db493004d5:	jrcxz  0x77db493004dc
    77db493004d7:	jmp    0x77db493008a2
    77db493004dc:	cmp    BYTE PTR [rsp+0xb8],0x0
    77db493004e4:	jne    0x77db493001cd
    77db493004ea:	jmp    0x77db493004ef
    77db493004ef:	mov    r13d,DWORD PTR [r12+0x70]
    77db493004f4:	mov    r14d,DWORD PTR [r12+0x98]
    77db493004fc:	add    r14d,r13d
    77db493004ff:	mov    QWORD PTR [r12+0x70],r14
    77db49300504:	mov    r13d,DWORD PTR [r12+0x68]
    77db49300509:	mov    r15d,DWORD PTR [r12+0x28]
    77db4930050e:	add    r15d,r13d
    77db49300511:	mov    QWORD PTR [r12+0x68],r15
    77db49300516:	mov    r13d,0x0
    77db4930051c:	mov    QWORD PTR [r12+0x88],r13
    77db49300524:	mov    r13d,DWORD PTR [r12+0x78]
    77db49300529:	mov    ebp,DWORD PTR [r12+0xa8]
    77db49300531:	add    ebp,r13d
    77db49300534:	mov    QWORD PTR [r12+0x78],rbp
    77db49300539:	mov    r13d,DWORD PTR [r12+0x80]
    77db49300541:	mov    r8d,DWORD PTR [r12+0x38]
    77db49300546:	add    r8d,r13d
    77db49300549:	mov    QWORD PTR [r12+0x80],r8
    77db49300551:	mov    rax,QWORD PTR [r12]
    77db49300555:	mov    r9,QWORD PTR [r12]
    77db49300559:	add    r9,0x8
    77db4930055d:	mov    r13,r9
    77db49300560:	add    r13,0x4
    77db49300564:	mov    DWORD PTR [r9],r14d
    77db49300567:	mov    r14d,0x0
    77db4930056d:	mov    DWORD PTR [r12+0x32c],r14d
    77db49300575:	mov    DWORD PTR [r13+0x0],r15d
    77db49300579:	mov    r13d,DWORD PTR [r12+0x18]
    77db4930057e:	mov    r14d,DWORD PTR [r12+0xb8]
    77db49300586:	add    r14d,r13d
    77db49300589:	mov    QWORD PTR [r12+0x68],r14
    77db4930058e:	mov    r13d,DWORD PTR [r12+0x90]
    77db49300596:	mov    r15d,DWORD PTR [r12+0x30]
    77db4930059b:	add    r15d,r13d
    77db4930059e:	mov    QWORD PTR [r12+0x70],r15
    77db493005a3:	mov    r13d,DWORD PTR [r12+0x58]
    77db493005a8:	mov    r9d,DWORD PTR [r12+0x20]
    77db493005ad:	mov    eax,r9d
    77db493005b0:	add    eax,r13d
    77db493005b3:	mov    QWORD PTR [r12+0x58],rax
    77db493005b8:	mov    r13d,DWORD PTR [r12+0x60]
    77db493005bd:	mov    r9d,DWORD PTR [r12+0xa0]
    77db493005c5:	add    r9d,r13d
    77db493005c8:	mov    QWORD PTR [r12+0x60],r9
    77db493005cd:	mov    r13,QWORD PTR [r12]
    77db493005d1:	add    r13,0x4
    77db493005d5:	mov    rdi,QWORD PTR [r12]
    77db493005d9:	mov    DWORD PTR [rdi],ebp
    77db493005db:	mov    DWORD PTR [r13+0x0],r8d
    77db493005df:	mov    r13,QWORD PTR [r12]
    77db493005e3:	add    r13,0x10
    77db493005e7:	mov    rbp,r13
    77db493005ea:	add    rbp,0x4
    77db493005ee:	mov    DWORD PTR [r13+0x0],r14d
    77db493005f2:	mov    DWORD PTR [rbp+0x0],r15d
    77db493005f6:	mov    r13,QWORD PTR [r12]
    77db493005fa:	add    r13,0x18
    77db493005fe:	mov    r14,r13
    77db49300601:	add    r14,0x4
    77db49300605:	mov    eax,DWORD PTR [r12+0x58]
    77db4930060a:	mov    DWORD PTR [r13+0x0],eax
    77db4930060e:	mov    DWORD PTR [r14],r9d
    77db49300611:	mov    r13,QWORD PTR [r12]
    77db49300615:	add    r13,0x68
    77db49300619:	mov    r14d,0x0
    77db4930061f:	mov    QWORD PTR [r13+0x0],r14
    77db49300623:	mov    rcx,QWORD PTR [r12+0x380]
    77db4930062b:	jrcxz  0x77db49300632
    77db4930062d:	jmp    0x77db4930092a
    77db49300632:	jmp    0x77db49300637
    77db49300637:	mov    r13,QWORD PTR [r12+0x10]
    77db4930063c:	sub    r13,0x1
    77db49300640:	mov    QWORD PTR [r12+0x10],r13
    77db49300645:	mov    rax,r13
    77db49300648:	test   rax,rax
    77db4930064b:	je     0x77db49300656
    77db49300651:	jmp    0x77db492fe75a
    77db49300656:	mov    r13,QWORD PTR [r12+0xf8]
    77db4930065e:	mov    r14,r13
    77db49300661:	add    r14,0x140
    77db49300668:	mov    r15,r14
    77db4930066b:	add    r15,0x8
    77db4930066f:	mov    rbp,QWORD PTR [r14]
    77db49300672:	mov    r14,QWORD PTR [r15]
    77db49300675:	mov    QWORD PTR [r12+0xa0],rbp
    77db4930067d:	mov    QWORD PTR [r12+0x98],r14
    77db49300685:	mov    r14,r13
    77db49300688:	add    r14,0x130
    77db4930068f:	mov    r15,r14
    77db49300692:	add    r15,0x8
    77db49300696:	mov    rbp,QWORD PTR [r14]
    77db49300699:	mov    r14,QWORD PTR [r15]
    77db4930069c:	mov    QWORD PTR [r12+0xb0],rbp
    77db493006a4:	mov    QWORD PTR [r12+0xa8],r14
    77db493006ac:	mov    r14,r13
    77db493006af:	add    r14,0x120
    77db493006b6:	mov    r15,r14
    77db493006b9:	add    r15,0x8
    77db493006bd:	mov    rbp,QWORD PTR [r14]
    77db493006c0:	mov    r14,QWORD PTR [r15]
    77db493006c3:	mov    QWORD PTR [r12+0xc0],rbp
    77db493006cb:	mov    QWORD PTR [r12+0xb8],r14
    77db493006d3:	mov    r14,r13
    77db493006d6:	add    r14,0x110
    77db493006dd:	mov    r15,r14
    77db493006e0:	add    r15,0x8
    77db493006e4:	mov    rbp,QWORD PTR [r14]
    77db493006e7:	mov    r14,QWORD PTR [r15]
    77db493006ea:	mov    QWORD PTR [r12+0xd0],rbp
    77db493006f2:	mov    QWORD PTR [r12+0xc8],r14
    77db493006fa:	mov    r14,r13
    77db493006fd:	add    r14,0x100
    77db49300704:	mov    r15,r14
    77db49300707:	add    r15,0x8
    77db4930070b:	mov    rbp,QWORD PTR [r14]
    77db4930070e:	mov    r14,QWORD PTR [r15]
    77db49300711:	mov    QWORD PTR [r12+0xe8],rbp
    77db49300719:	mov    QWORD PTR [r12+0xd8],r14
    77db49300721:	add    r13,0x150
    77db49300728:	mov    QWORD PTR [r12+0xf8],r13
    77db49300730:	jmp    0x77db49300735
    77db49300735:	mov    rcx,QWORD PTR [r12+0x380]
    77db4930073d:	jrcxz  0x77db49300744
    77db4930073f:	jmp    0x77db493009b2
    77db49300744:	mov    r13,QWORD PTR [r12+0xf0]
    77db4930074c:	mov    QWORD PTR [r12+0x100],r13
    77db49300754:	mov    r11,QWORD PTR [rsp+0xb0]
    77db4930075c:	mov    QWORD PTR [r12+0x398],r11
    77db49300764:	mov    rdi,QWORD PTR [r12+0x100]
    77db4930076c:	add    rsp,0xc0
    77db49300773:	movabs r11,0x60ebc8b89940
    77db4930077d:	jmp    r11
    77db49300780:	mov    eax,0x41078c
    77db49300785:	mov    QWORD PTR [r12+0x100],rax
    77db4930078d:	push   rdx
    77db4930078e:	push   rsi
    77db4930078f:	push   r10
    77db49300791:	push   r11
    77db49300793:	mov    r11,rax
    77db49300796:	lahf
    77db49300797:	seto   al
    77db4930079a:	mov    WORD PTR [rsp+0xd0],ax
    77db493007a2:	mov    rax,r11
    77db493007a5:	mov    rdx,QWORD PTR [rsp+0xd0]
    77db493007ad:	mov    r10d,edx
    77db493007b0:	and    r10d,0xc000
    77db493007b7:	shl    r10d,0x10
    77db493007bb:	mov    r11d,edx
    77db493007be:	and    r11d,0x100
    77db493007c5:	shl    r11d,0x15
    77db493007c9:	or     r10d,r11d
    77db493007cc:	and    edx,0x1
    77db493007cf:	shl    edx,0x1c
    77db493007d2:	or     r10d,edx
    77db493007d5:	btc    r10,0x1d
    77db493007da:	mov    r11d,0xf0000000
    77db493007e0:	and    r11,r10
    77db493007e3:	movabs rsi,0xffffffff0fffffff
    77db493007ed:	and    rbx,rsi
    77db493007f0:	or     rbx,r11
    77db493007f3:	pop    r11
    77db493007f5:	pop    r10
    77db493007f7:	pop    rsi
    77db493007f8:	pop    rdx
    77db493007f9:	mov    QWORD PTR [r12+0x108],rbx
    77db49300801:	add    rsp,0xc0
    77db49300808:	mov    eax,0xc
    77db4930080d:	movabs r11,0x60ebc8b89ca0
    77db49300817:	jmp    r11
    77db4930081a:	mov    eax,0x410888
    77db4930081f:	mov    QWORD PTR [r12+0x100],rax
    77db49300827:	push   rdx
    77db49300828:	push   rsi
    77db49300829:	push   r10
    77db4930082b:	push   r11
    77db4930082d:	mov    rdx,QWORD PTR [rsp+0xd0]
    77db49300835:	mov    r10d,edx
    77db49300838:	and    r10d,0xc000
    77db4930083f:	shl    r10d,0x10
    77db49300843:	mov    r11d,edx
    77db49300846:	and    r11d,0x100
    77db4930084d:	shl    r11d,0x15
    77db49300851:	or     r10d,r11d
    77db49300854:	and    edx,0x1
    77db49300857:	shl    edx,0x1c
    77db4930085a:	or     r10d,edx
    77db4930085d:	btc    r10,0x1d
    77db49300862:	mov    r11d,0xf0000000
    77db49300868:	and    r11,r10
    77db4930086b:	movabs rsi,0xffffffff0fffffff
    77db49300875:	and    rbx,rsi
    77db49300878:	or     rbx,r11
    77db4930087b:	pop    r11
    77db4930087d:	pop    r10
    77db4930087f:	pop    rsi
    77db49300880:	pop    rdx
    77db49300881:	mov    QWORD PTR [r12+0x108],rbx
    77db49300889:	add    rsp,0xc0
    77db49300890:	mov    eax,0xc
    77db49300895:	movabs r11,0x60ebc8b89ca0
    77db4930089f:	jmp    r11
    77db493008a2:	mov    eax,0x410948
    77db493008a7:	mov    QWORD PTR [r12+0x100],rax
    77db493008af:	push   rdx
    77db493008b0:	push   rsi
    77db493008b1:	push   r10
    77db493008b3:	push   r11
    77db493008b5:	mov    rdx,QWORD PTR [rsp+0xd0]
    77db493008bd:	mov    r10d,edx
    77db493008c0:	and    r10d,0xc000
    77db493008c7:	shl    r10d,0x10
    77db493008cb:	mov    r11d,edx
    77db493008ce:	and    r11d,0x100
    77db493008d5:	shl    r11d,0x15
    77db493008d9:	or     r10d,r11d
    77db493008dc:	and    edx,0x1
    77db493008df:	shl    edx,0x1c
    77db493008e2:	or     r10d,edx
    77db493008e5:	btc    r10,0x1d
    77db493008ea:	mov    r11d,0xf0000000
    77db493008f0:	and    r11,r10
    77db493008f3:	movabs rsi,0xffffffff0fffffff
    77db493008fd:	and    rbx,rsi
    77db49300900:	or     rbx,r11
    77db49300903:	pop    r11
    77db49300905:	pop    r10
    77db49300907:	pop    rsi
    77db49300908:	pop    rdx
    77db49300909:	mov    QWORD PTR [r12+0x108],rbx
    77db49300911:	add    rsp,0xc0
    77db49300918:	mov    eax,0xc
    77db4930091d:	movabs r11,0x60ebc8b89ca0
    77db49300927:	jmp    r11
    77db4930092a:	mov    eax,0x410984
    77db4930092f:	mov    QWORD PTR [r12+0x100],rax
    77db49300937:	push   rdx
    77db49300938:	push   rsi
    77db49300939:	push   r10
    77db4930093b:	push   r11
    77db4930093d:	mov    rdx,QWORD PTR [rsp+0xd0]
    77db49300945:	mov    r10d,edx
    77db49300948:	and    r10d,0xc000
    77db4930094f:	shl    r10d,0x10
    77db49300953:	mov    r11d,edx
    77db49300956:	and    r11d,0x100
    77db4930095d:	shl    r11d,0x15
    77db49300961:	or     r10d,r11d
    77db49300964:	and    edx,0x1
    77db49300967:	shl    edx,0x1c
    77db4930096a:	or     r10d,edx
    77db4930096d:	btc    r10,0x1d
    77db49300972:	mov    r11d,0xf0000000
    77db49300978:	and    r11,r10
    77db4930097b:	movabs rsi,0xffffffff0fffffff
    77db49300985:	and    rbx,rsi
    77db49300988:	or     rbx,r11
    77db4930098b:	pop    r11
    77db4930098d:	pop    r10
    77db4930098f:	pop    rsi
    77db49300990:	pop    rdx
    77db49300991:	mov    QWORD PTR [r12+0x108],rbx
    77db49300999:	add    rsp,0xc0
    77db493009a0:	mov    eax,0xc
    77db493009a5:	movabs r11,0x60ebc8b89ca0
    77db493009af:	jmp    r11
    77db493009b2:	mov    eax,0x4109a0
    77db493009b7:	mov    QWORD PTR [r12+0x100],rax
    77db493009bf:	push   rdx
    77db493009c0:	push   rsi
    77db493009c1:	push   r10
    77db493009c3:	push   r11
    77db493009c5:	mov    rdx,QWORD PTR [rsp+0xd0]
    77db493009cd:	mov    r10d,edx
    77db493009d0:	and    r10d,0xc000
    77db493009d7:	shl    r10d,0x10
    77db493009db:	mov    r11d,edx
    77db493009de:	and    r11d,0x100
    77db493009e5:	shl    r11d,0x15
    77db493009e9:	or     r10d,r11d
    77db493009ec:	and    edx,0x1
    77db493009ef:	shl    edx,0x1c
    77db493009f2:	or     r10d,edx
    77db493009f5:	btc    r10,0x1d
    77db493009fa:	mov    r11d,0xf0000000
    77db49300a00:	and    r11,r10
    77db49300a03:	movabs rsi,0xffffffff0fffffff
    77db49300a0d:	and    rbx,rsi
    77db49300a10:	or     rbx,r11
    77db49300a13:	pop    r11
    77db49300a15:	pop    r10
    77db49300a17:	pop    rsi
    77db49300a18:	pop    rdx
    77db49300a19:	mov    QWORD PTR [r12+0x108],rbx
    77db49300a21:	add    rsp,0xc0
    77db49300a28:	mov    eax,0xc
    77db49300a2d:	movabs r11,0x60ebc8b89ca0
    77db49300a37:	jmp    r11
    77db49300a3a:	nop    WORD PTR [rax+rax*1+0x0]
    77db49300a40:	sub    rsp,0xc0
    77db49300a47:	mov    r11,QWORD PTR [r12+0x398]
    77db49300a4f:	mov    QWORD PTR [rsp+0xb0],r11
    77db49300a57:	jmp    0x77db492fe639
    77db49300a5c:	nop    DWORD PTR [rax+0x0]
    77db49300a60:	sub    rsp,0xc0
    77db49300a67:	mov    r11,QWORD PTR [r12+0x398]
    77db49300a6f:	mov    QWORD PTR [rsp+0xb0],r11
    77db49300a77:	jmp    0x77db492fe75a
    77db49300a7c:	nop    DWORD PTR [rax+0x0]
    77db49300a80:	sub    rsp,0xc0
    77db49300a87:	mov    r11,QWORD PTR [r12+0x398]
    77db49300a8f:	mov    QWORD PTR [rsp+0xb0],r11
    77db49300a97:	jmp    0x77db492fe814
    77db49300a9c:	nop    DWORD PTR [rax+0x0]
    77db49300aa0:	sub    rsp,0xc0
    77db49300aa7:	mov    r11,QWORD PTR [r12+0x398]
    77db49300aaf:	mov    QWORD PTR [rsp+0xb0],r11
    77db49300ab7:	jmp    0x77db492ffef9
    77db49300abc:	nop    DWORD PTR [rax+0x0]
    77db49300ac0:	sub    rsp,0xc0
    77db49300ac7:	mov    r11,QWORD PTR [r12+0x398]
    77db49300acf:	mov    QWORD PTR [rsp+0xb0],r11
    77db49300ad7:	jmp    0x77db4930004a
    77db49300adc:	nop    DWORD PTR [rax+0x0]
    77db49300ae0:	sub    rsp,0xc0
    77db49300ae7:	mov    r11,QWORD PTR [r12+0x398]
    77db49300aef:	mov    QWORD PTR [rsp+0xb0],r11
    77db49300af7:	jmp    0x77db493001cd
    77db49300afc:	nop    DWORD PTR [rax+0x0]
    77db49300b00:	sub    rsp,0xc0
    77db49300b07:	mov    r11,QWORD PTR [r12+0x398]
    77db49300b0f:	mov    QWORD PTR [rsp+0xb0],r11
    77db49300b17:	jmp    0x77db493004ef
    77db49300b1c:	nop    DWORD PTR [rax+0x0]
    77db49300b20:	sub    rsp,0xc0
    77db49300b27:	mov    r11,QWORD PTR [r12+0x398]
    77db49300b2f:	mov    QWORD PTR [rsp+0xb0],r11
    77db49300b37:	jmp    0x77db49300637
    77db49300b3c:	nop    DWORD PTR [rax+0x0]
    77db49300b40:	sub    rsp,0xc0
    77db49300b47:	mov    r11,QWORD PTR [r12+0x398]
    77db49300b4f:	mov    QWORD PTR [rsp+0xb0],r11
    77db49300b57:	jmp    0x77db49300656
    77db49300b5c:	nop    DWORD PTR [rax+0x0]
    77db49300b60:	sub    rsp,0xc0
    77db49300b67:	mov    r11,QWORD PTR [r12+0x398]
    77db49300b6f:	mov    QWORD PTR [rsp+0xb0],r11
    77db49300b77:	jmp    0x77db49300735
