
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/0/5.bin:     file format binary


Disassembly of section .data:

000077db49301220 <.data>:
    77db49301220:	sub    rsp,0x10
    77db49301224:	mov    r11,QWORD PTR [r12+0x398]
    77db4930122c:	mov    QWORD PTR [rsp],r11
    77db49301230:	mov    rax,QWORD PTR [r12+0xf8]
    77db49301238:	mov    r14,QWORD PTR [r12+0xf8]
    77db49301240:	add    r14,0x100
    77db49301247:	mov    r15d,DWORD PTR [r14]
    77db4930124a:	mov    QWORD PTR [r12+0x40],r15
    77db4930124f:	mov    r14,QWORD PTR [r12+0xf8]
    77db49301257:	add    r14,0x104
    77db4930125e:	mov    ebp,DWORD PTR [r14]
    77db49301261:	mov    QWORD PTR [r12+0x50],rbp
    77db49301266:	mov    r14d,0x430c90
    77db4930126c:	mov    QWORD PTR [r12+0x48],r14
    77db49301271:	mov    r14,QWORD PTR [r12+0xf8]
    77db49301279:	add    r14,0x108
    77db49301280:	mov    r8d,DWORD PTR [r14]
    77db49301283:	mov    QWORD PTR [r12+0x58],r8
    77db49301288:	mov    r14,QWORD PTR [r12+0xf8]
    77db49301290:	add    r14,0x10c
    77db49301297:	mov    eax,DWORD PTR [r14]
    77db4930129a:	mov    QWORD PTR [r12+0x60],rax
    77db4930129f:	movabs rcx,0xff00ff00ff00ff
    77db493012a9:	mov    r14,r15
    77db493012ac:	and    r14,rcx
    77db493012af:	shl    r14,0x8
    77db493012b3:	movabs rcx,0xff00ff00ff00ff00
    77db493012bd:	mov    r13,r15
    77db493012c0:	and    r13,rcx
    77db493012c3:	shr    r13,0x8
    77db493012c7:	or     r13,r14
    77db493012ca:	movabs rcx,0xffff0000ffff
    77db493012d4:	mov    r14,r13
    77db493012d7:	and    r14,rcx
    77db493012da:	shl    r14,0x10
    77db493012de:	movabs rcx,0xffff0000ffff0000
    77db493012e8:	and    r13,rcx
    77db493012eb:	shr    r13,0x10
    77db493012ef:	or     r13,r14
    77db493012f2:	mov    ecx,0xffffffff
    77db493012f7:	and    r13,rcx
    77db493012fa:	mov    QWORD PTR [r12+0x40],r13
    77db493012ff:	movabs rcx,0xff00ff00ff00ff
    77db49301309:	mov    r14,rbp
    77db4930130c:	and    r14,rcx
    77db4930130f:	shl    r14,0x8
    77db49301313:	movabs rcx,0xff00ff00ff00ff00
    77db4930131d:	mov    r15,rbp
    77db49301320:	and    r15,rcx
    77db49301323:	shr    r15,0x8
    77db49301327:	or     r15,r14
    77db4930132a:	movabs rcx,0xffff0000ffff
    77db49301334:	mov    r14,r15
    77db49301337:	and    r14,rcx
    77db4930133a:	shl    r14,0x10
    77db4930133e:	movabs rcx,0xffff0000ffff0000
    77db49301348:	and    r15,rcx
    77db4930134b:	shr    r15,0x10
    77db4930134f:	or     r15,r14
    77db49301352:	mov    ecx,0xffffffff
    77db49301357:	and    r15,rcx
    77db4930135a:	mov    QWORD PTR [r12+0x50],r15
    77db4930135f:	mov    r14d,0x0
    77db49301365:	mov    QWORD PTR [r12+0xa0],r14
    77db4930136d:	mov    r14d,0x430c90
    77db49301373:	mov    ebp,0x430c94
    77db49301378:	mov    rax,r13
    77db4930137b:	mov    eax,eax
    77db4930137d:	mov    r9d,eax
    77db49301380:	mov    rax,r15
    77db49301383:	mov    eax,eax
    77db49301385:	mov    r13d,eax
    77db49301388:	mov    DWORD PTR [r14],r9d
    77db4930138b:	mov    r14d,0x0
    77db49301391:	mov    DWORD PTR [r12+0x32c],r14d
    77db49301399:	mov    DWORD PTR [rbp+0x0],r13d
    77db4930139d:	movabs rcx,0xff00ff00ff00ff
    77db493013a7:	mov    r13,r8
    77db493013aa:	and    r13,rcx
    77db493013ad:	shl    r13,0x8
    77db493013b1:	movabs rcx,0xff00ff00ff00ff00
    77db493013bb:	mov    r14,r8
    77db493013be:	and    r14,rcx
    77db493013c1:	shr    r14,0x8
    77db493013c5:	or     r14,r13
    77db493013c8:	movabs rcx,0xffff0000ffff
    77db493013d2:	mov    r13,r14
    77db493013d5:	and    r13,rcx
    77db493013d8:	shl    r13,0x10
    77db493013dc:	movabs rcx,0xffff0000ffff0000
    77db493013e6:	and    r14,rcx
    77db493013e9:	shr    r14,0x10
    77db493013ed:	or     r14,r13
    77db493013f0:	mov    ecx,0xffffffff
    77db493013f5:	and    r14,rcx
    77db493013f8:	mov    QWORD PTR [r12+0x40],r14
    77db493013fd:	mov    r13,QWORD PTR [r12+0xf8]
    77db49301405:	add    r13,0x110
    77db4930140c:	mov    r15d,DWORD PTR [r13+0x0]
    77db49301410:	mov    QWORD PTR [r12+0x50],r15
    77db49301415:	movabs rcx,0xff00ff00ff00ff
    77db4930141f:	mov    r13d,DWORD PTR [r12+0x60]
    77db49301424:	and    r13,rcx
    77db49301427:	shl    r13,0x8
    77db4930142b:	movabs rcx,0xff00ff00ff00ff00
    77db49301435:	mov    ebp,DWORD PTR [r12+0x60]
    77db4930143a:	and    rbp,rcx
    77db4930143d:	shr    rbp,0x8
    77db49301441:	or     rbp,r13
    77db49301444:	movabs rcx,0xffff0000ffff
    77db4930144e:	mov    r13,rbp
    77db49301451:	and    r13,rcx
    77db49301454:	shl    r13,0x10
    77db49301458:	movabs rcx,0xffff0000ffff0000
    77db49301462:	and    rbp,rcx
    77db49301465:	shr    rbp,0x10
    77db49301469:	or     rbp,r13
    77db4930146c:	mov    ecx,0xffffffff
    77db49301471:	and    rbp,rcx
    77db49301474:	mov    QWORD PTR [r12+0x58],rbp
    77db49301479:	mov    r13,QWORD PTR [r12+0xf8]
    77db49301481:	add    r13,0x114
    77db49301488:	mov    eax,DWORD PTR [r13+0x0]
    77db4930148c:	mov    QWORD PTR [r12+0x60],rax
    77db49301491:	mov    r13d,0x430000
    77db49301497:	add    r13,0xdfc
    77db4930149e:	mov    QWORD PTR [r12+0x98],r13
    77db493014a6:	mov    r13d,0x430c98
    77db493014ac:	mov    r9d,0x430c9c
    77db493014b2:	mov    rax,r14
    77db493014b5:	mov    eax,eax
    77db493014b7:	mov    r8d,eax
    77db493014ba:	mov    rax,rbp
    77db493014bd:	mov    eax,eax
    77db493014bf:	mov    r14d,eax
    77db493014c2:	mov    DWORD PTR [r13+0x0],r8d
    77db493014c6:	mov    DWORD PTR [r9],r14d
    77db493014c9:	movabs rcx,0xff00ff00ff00ff
    77db493014d3:	mov    r13,r15
    77db493014d6:	and    r13,rcx
    77db493014d9:	shl    r13,0x8
    77db493014dd:	movabs rcx,0xff00ff00ff00ff00
    77db493014e7:	mov    r14,r15
    77db493014ea:	and    r14,rcx
    77db493014ed:	shr    r14,0x8
    77db493014f1:	or     r14,r13
    77db493014f4:	movabs rcx,0xffff0000ffff
    77db493014fe:	mov    r13,r14
    77db49301501:	and    r13,rcx
    77db49301504:	shl    r13,0x10
    77db49301508:	movabs rcx,0xffff0000ffff0000
    77db49301512:	and    r14,rcx
    77db49301515:	shr    r14,0x10
    77db49301519:	or     r14,r13
    77db4930151c:	mov    ecx,0xffffffff
    77db49301521:	and    r14,rcx
    77db49301524:	mov    QWORD PTR [r12+0x40],r14
    77db49301529:	mov    r13,QWORD PTR [r12+0xf8]
    77db49301531:	add    r13,0x118
    77db49301538:	mov    r15d,DWORD PTR [r13+0x0]
    77db4930153c:	mov    QWORD PTR [r12+0x50],r15
    77db49301541:	movabs rcx,0xff00ff00ff00ff
    77db4930154b:	mov    r13d,DWORD PTR [r12+0x60]
    77db49301550:	and    r13,rcx
    77db49301553:	shl    r13,0x8
    77db49301557:	movabs rcx,0xff00ff00ff00ff00
    77db49301561:	mov    ebp,DWORD PTR [r12+0x60]
    77db49301566:	and    rbp,rcx
    77db49301569:	shr    rbp,0x8
    77db4930156d:	or     rbp,r13
    77db49301570:	movabs rcx,0xffff0000ffff
    77db4930157a:	mov    r13,rbp
    77db4930157d:	and    r13,rcx
    77db49301580:	shl    r13,0x10
    77db49301584:	movabs rcx,0xffff0000ffff0000
    77db4930158e:	and    rbp,rcx
    77db49301591:	shr    rbp,0x10
    77db49301595:	or     rbp,r13
    77db49301598:	mov    ecx,0xffffffff
    77db4930159d:	and    rbp,rcx
    77db493015a0:	mov    QWORD PTR [r12+0x58],rbp
    77db493015a5:	mov    r13,QWORD PTR [r12+0xf8]
    77db493015ad:	add    r13,0x11c
    77db493015b4:	mov    eax,DWORD PTR [r13+0x0]
    77db493015b8:	mov    QWORD PTR [r12+0x60],rax
    77db493015bd:	mov    r13d,0x430ca0
    77db493015c3:	mov    r9d,0x430ca4
    77db493015c9:	mov    rax,r14
    77db493015cc:	mov    eax,eax
    77db493015ce:	mov    r8d,eax
    77db493015d1:	mov    rax,rbp
    77db493015d4:	mov    eax,eax
    77db493015d6:	mov    r14d,eax
    77db493015d9:	mov    DWORD PTR [r13+0x0],r8d
    77db493015dd:	mov    DWORD PTR [r9],r14d
    77db493015e0:	movabs rcx,0xff00ff00ff00ff
    77db493015ea:	mov    r13,r15
    77db493015ed:	and    r13,rcx
    77db493015f0:	shl    r13,0x8
    77db493015f4:	movabs rcx,0xff00ff00ff00ff00
    77db493015fe:	mov    r14,r15
    77db49301601:	and    r14,rcx
    77db49301604:	shr    r14,0x8
    77db49301608:	or     r14,r13
    77db4930160b:	movabs rcx,0xffff0000ffff
    77db49301615:	mov    r13,r14
    77db49301618:	and    r13,rcx
    77db4930161b:	shl    r13,0x10
    77db4930161f:	movabs rcx,0xffff0000ffff0000
    77db49301629:	and    r14,rcx
    77db4930162c:	shr    r14,0x10
    77db49301630:	or     r14,r13
    77db49301633:	mov    ecx,0xffffffff
    77db49301638:	and    r14,rcx
    77db4930163b:	mov    QWORD PTR [r12+0x40],r14
    77db49301640:	movabs rcx,0xff00ff00ff00ff
    77db4930164a:	mov    r13d,DWORD PTR [r12+0x60]
    77db4930164f:	and    r13,rcx
    77db49301652:	shl    r13,0x8
    77db49301656:	movabs rcx,0xff00ff00ff00ff00
    77db49301660:	mov    r15d,DWORD PTR [r12+0x60]
    77db49301665:	and    r15,rcx
    77db49301668:	shr    r15,0x8
    77db4930166c:	or     r15,r13
    77db4930166f:	movabs rcx,0xffff0000ffff
    77db49301679:	mov    r13,r15
    77db4930167c:	and    r13,rcx
    77db4930167f:	shl    r13,0x10
    77db49301683:	movabs rcx,0xffff0000ffff0000
    77db4930168d:	and    r15,rcx
    77db49301690:	shr    r15,0x10
    77db49301694:	or     r15,r13
    77db49301697:	mov    ecx,0xffffffff
    77db4930169c:	and    r15,rcx
    77db4930169f:	mov    QWORD PTR [r12+0x50],r15
    77db493016a4:	mov    r13d,0x430ca8
    77db493016aa:	mov    ebp,0x430cac
    77db493016af:	mov    rax,r14
    77db493016b2:	mov    eax,eax
    77db493016b4:	mov    r8d,eax
    77db493016b7:	mov    rax,r15
    77db493016ba:	mov    eax,eax
    77db493016bc:	mov    r14d,eax
    77db493016bf:	mov    DWORD PTR [r13+0x0],r8d
    77db493016c3:	mov    DWORD PTR [rbp+0x0],r14d
    77db493016c7:	mov    r13d,0x11
    77db493016cd:	mov    QWORD PTR [r12],r13
    77db493016d1:	mov    r13d,0x41035c
    77db493016d7:	mov    QWORD PTR [r12+0xf0],r13
    77db493016df:	mov    r13d,0x4109a4
    77db493016e5:	mov    QWORD PTR [r12+0x100],r13
    77db493016ed:	mov    r11,QWORD PTR [rsp]
    77db493016f1:	mov    QWORD PTR [r12+0x398],r11
    77db493016f9:	mov    edi,0x4109a4
    77db493016fe:	mov    QWORD PTR [r12+0x100],rdi
    77db49301706:	add    rsp,0x10
    77db4930170a:	nop    WORD PTR [rax+rax*1+0x0]
    77db49301710:	jmp    QWORD PTR [rip+0x2]        # 0x77db49301718
    77db49301716:	xchg   ax,ax
    77db49301718:	rex (bad)
    77db4930171a:	xor    BYTE PTR [rcx-0x25],cl
    77db4930171d:	ja     0x77db4930171f
    77db4930171f:	add    BYTE PTR [rax],ch
    77db49301721:	(bad)
    77db49301722:	xor    BYTE PTR [rcx-0x25],cl
    77db49301725:	ja     0x77db49301727
    77db49301727:	add    BYTE PTR [rcx-0x45],cl
    77db4930172a:	rex cdq
    77db4930172c:	mov    eax,0x60ebc8
    77db49301731:	add    BYTE PTR [rcx-0x1],al
    77db49301734:	jrcxz  0x77db493016c6
    77db49301736:	nop
    77db49301737:	nop
