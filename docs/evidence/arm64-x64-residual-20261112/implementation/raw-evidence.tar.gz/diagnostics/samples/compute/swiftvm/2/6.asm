
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/2/6.bin:     file format binary


Disassembly of section .data:

0000730a04101740 <.data>:
    730a04101740:	sub    rsp,0x10
    730a04101744:	mov    r11,QWORD PTR [r12+0x398]
    730a0410174c:	mov    QWORD PTR [rsp],r11
    730a04101750:	mov    r13d,DWORD PTR [r12]
    730a04101754:	mov    r14d,r13d
    730a04101757:	mov    r14d,r14d
    730a0410175a:	shr    r14d,0x10
    730a0410175e:	xor    r13d,r14d
    730a04101761:	mov    QWORD PTR [r12+0x40],r13
    730a04101766:	mov    r14d,0x352d
    730a0410176c:	mov    QWORD PTR [r12+0x48],r14
    730a04101771:	mov    r14d,0x352d
    730a04101777:	mov    r15d,0x7feb
    730a0410177d:	and    r15d,0xffff
    730a04101784:	mov    rax,r14
    730a04101787:	movabs rcx,0xffffffff0000ffff
    730a04101791:	and    rax,rcx
    730a04101794:	mov    rdx,r15
    730a04101797:	shl    rdx,0x10
    730a0410179b:	mov    ecx,0xffff0000
    730a041017a0:	and    rdx,rcx
    730a041017a3:	or     rax,rdx
    730a041017a6:	mov    ebp,eax
    730a041017a8:	mov    QWORD PTR [r12+0x48],rbp
    730a041017ad:	mov    r14d,0x0
    730a041017b3:	imul   r13d,ebp
    730a041017b7:	mov    r15d,r14d
    730a041017ba:	add    r15d,r13d
    730a041017bd:	mov    QWORD PTR [r12+0x40],r15
    730a041017c2:	mov    r13d,0xa68b
    730a041017c8:	mov    QWORD PTR [r12+0x48],r13
    730a041017cd:	mov    r13d,0xa68b
    730a041017d3:	mov    r14d,0x846c
    730a041017d9:	and    r14d,0xffff
    730a041017e0:	mov    rax,r13
    730a041017e3:	movabs rcx,0xffffffff0000ffff
    730a041017ed:	and    rax,rcx
    730a041017f0:	mov    rdx,r14
    730a041017f3:	shl    rdx,0x10
    730a041017f7:	mov    ecx,0xffff0000
    730a041017fc:	and    rdx,rcx
    730a041017ff:	or     rax,rdx
    730a04101802:	mov    ebp,eax
    730a04101804:	mov    QWORD PTR [r12+0x48],rbp
    730a04101809:	mov    r13d,r15d
    730a0410180c:	mov    r13d,r13d
    730a0410180f:	shr    r13d,0xf
    730a04101813:	xor    r15d,r13d
    730a04101816:	mov    QWORD PTR [r12+0x40],r15
    730a0410181b:	mov    r13d,0x0
    730a04101821:	imul   r15d,ebp
    730a04101825:	mov    r14d,r13d
    730a04101828:	add    r14d,r15d
    730a0410182b:	mov    QWORD PTR [r12+0x40],r14
    730a04101830:	mov    r13d,r14d
    730a04101833:	mov    r13d,r13d
    730a04101836:	shr    r13d,0x10
    730a0410183a:	xor    r14d,r13d
    730a0410183d:	mov    QWORD PTR [r12],r14
    730a04101841:	mov    rcx,QWORD PTR [r12+0x380]
    730a04101849:	jrcxz  0x730a04101850
    730a0410184b:	jmp    0x730a04101885
    730a04101850:	mov    r13,QWORD PTR [r12+0xf0]
    730a04101858:	mov    QWORD PTR [r12+0x100],r13
    730a04101860:	mov    r11,QWORD PTR [rsp]
    730a04101864:	mov    QWORD PTR [r12+0x398],r11
    730a0410186c:	mov    rdi,QWORD PTR [r12+0x100]
    730a04101874:	add    rsp,0x10
    730a04101878:	movabs r11,0x5591a9c2c940
    730a04101882:	jmp    r11
    730a04101885:	mov    eax,0x4109c8
    730a0410188a:	mov    QWORD PTR [r12+0x100],rax
    730a04101892:	push   rdx
    730a04101893:	push   rsi
    730a04101894:	push   r10
    730a04101896:	push   r11
    730a04101898:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410189d:	mov    r10d,edx
    730a041018a0:	and    r10d,0xc000
    730a041018a7:	shl    r10d,0x10
    730a041018ab:	mov    r11d,edx
    730a041018ae:	and    r11d,0x100
    730a041018b5:	shl    r11d,0x15
    730a041018b9:	or     r10d,r11d
    730a041018bc:	and    edx,0x1
    730a041018bf:	shl    edx,0x1c
    730a041018c2:	or     r10d,edx
    730a041018c5:	btc    r10,0x1d
    730a041018ca:	mov    r11d,0xf0000000
    730a041018d0:	and    r11,r10
    730a041018d3:	movabs rsi,0xffffffff0fffffff
    730a041018dd:	and    rbx,rsi
    730a041018e0:	or     rbx,r11
    730a041018e3:	pop    r11
    730a041018e5:	pop    r10
    730a041018e7:	pop    rsi
    730a041018e8:	pop    rdx
    730a041018e9:	mov    QWORD PTR [r12+0x108],rbx
    730a041018f1:	add    rsp,0x10
    730a041018f5:	mov    eax,0xc
    730a041018fa:	movabs r11,0x5591a9c2cca0
    730a04101904:	jmp    r11
    730a04101907:	nop
