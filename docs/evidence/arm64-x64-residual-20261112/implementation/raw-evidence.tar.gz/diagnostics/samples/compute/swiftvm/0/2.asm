
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/0/2.bin:     file format binary


Disassembly of section .data:

000077db49300b80 <.data>:
    77db49300b80:	sub    rsp,0x10
    77db49300b84:	mov    r13d,DWORD PTR [r12+0xa0]
    77db49300b8c:	sub    r13d,0x1
    77db49300b90:	mov    QWORD PTR [r12+0xa0],r13
    77db49300b98:	mov    rcx,QWORD PTR [r12+0x380]
    77db49300ba0:	jrcxz  0x77db49300ba7
    77db49300ba2:	jmp    0x77db49300d3d
    77db49300ba7:	jne    0x77db49300bc0
    77db49300bad:	mov    r11,rax
    77db49300bb0:	lahf
    77db49300bb1:	seto   al
    77db49300bb4:	mov    WORD PTR [rsp],ax
    77db49300bb8:	mov    rax,r11
    77db49300bbb:	jmp    0x77db49300bd3
    77db49300bc0:	mov    r11,rax
    77db49300bc3:	lahf
    77db49300bc4:	seto   al
    77db49300bc7:	mov    WORD PTR [rsp],ax
    77db49300bcb:	mov    rax,r11
    77db49300bce:	jmp    0x77db49300ca5
    77db49300bd3:	mov    r13,QWORD PTR [r12+0xf8]
    77db49300bdb:	mov    r14,r13
    77db49300bde:	add    r14,0x120
    77db49300be5:	mov    r15,QWORD PTR [r14]
    77db49300be8:	mov    QWORD PTR [r12+0x98],r15
    77db49300bf0:	mov    r14d,0x80
    77db49300bf6:	mov    QWORD PTR [r12+0x40],r14
    77db49300bfb:	mov    r14,r13
    77db49300bfe:	add    r14,0x100
    77db49300c05:	mov    QWORD PTR [r12],r14
    77db49300c09:	mov    r14,r13
    77db49300c0c:	add    r14,0x17c
    77db49300c13:	mov    QWORD PTR [r12+0x8],r14
    77db49300c18:	mov    r14d,0x1
    77db49300c1e:	mov    QWORD PTR [r12+0x10],r14
    77db49300c23:	add    r13,0x17c
    77db49300c2a:	movzx  r14d,BYTE PTR [r12+0x40]
    77db49300c30:	mov    BYTE PTR [r13+0x0],r14b
    77db49300c34:	mov    r13d,0x0
    77db49300c3a:	mov    DWORD PTR [r12+0x32c],r13d
    77db49300c42:	mov    r13d,0x4102a8
    77db49300c48:	mov    QWORD PTR [r12+0xf0],r13
    77db49300c50:	mov    r13d,0x410728
    77db49300c56:	mov    QWORD PTR [r12+0x100],r13
    77db49300c5e:	mov    r11,QWORD PTR [rsp]
    77db49300c62:	mov    QWORD PTR [r12+0x398],r11
    77db49300c6a:	mov    edi,0x410728
    77db49300c6f:	mov    QWORD PTR [r12+0x100],rdi
    77db49300c77:	add    rsp,0x10
    77db49300c7b:	nop    DWORD PTR [rax+rax*1+0x0]
    77db49300c80:	jmp    QWORD PTR [rip+0x2]        # 0x77db49300c88
    77db49300c86:	xchg   ax,ax
    77db49300c88:	loopne 0x77db49300c6f
    77db49300c8a:	(bad)
    77db49300c8b:	rex.WB (bad) [r15+0x0]
    77db49300c8f:	add    BYTE PTR [rax-0x24b6cff4],bl
    77db49300c95:	ja     0x77db49300c97
    77db49300c97:	add    BYTE PTR [rcx-0x45],cl
    77db49300c9a:	rex cdq
    77db49300c9c:	mov    eax,0x60ebc8
    77db49300ca1:	add    BYTE PTR [rcx-0x1],al
    77db49300ca4:	jrcxz  0x77db49300cf3
    77db49300ca6:	mov    ebp,DWORD PTR [rsp+0xf8]
    77db49300cad:	add    r13,0x100
    77db49300cb4:	mov    QWORD PTR [r12],r13
    77db49300cb8:	mov    r13d,0x0
    77db49300cbe:	mov    r14,QWORD PTR [r12+0x98]
    77db49300cc6:	or     r13,r14
    77db49300cc9:	mov    QWORD PTR [r12+0x8],r13
    77db49300cce:	mov    r13d,0x12c
    77db49300cd4:	mov    QWORD PTR [r12+0x10],r13
    77db49300cd9:	mov    r13d,0x410284
    77db49300cdf:	mov    QWORD PTR [r12+0xf0],r13
    77db49300ce7:	mov    r13d,0x410728
    77db49300ced:	mov    QWORD PTR [r12+0x100],r13
    77db49300cf5:	mov    r11,QWORD PTR [rsp]
    77db49300cf9:	mov    QWORD PTR [r12+0x398],r11
    77db49300d01:	mov    edi,0x410728
    77db49300d06:	mov    QWORD PTR [r12+0x100],rdi
    77db49300d0e:	add    rsp,0x10
    77db49300d12:	nop    WORD PTR [rax+rax*1+0x0]
    77db49300d18:	jmp    QWORD PTR [rip+0x2]        # 0x77db49300d20
    77db49300d1e:	xchg   ax,ax
    77db49300d20:	loopne 0x77db49300d07
    77db49300d22:	(bad)
    77db49300d23:	rex.WB (bad) [r15+0x0]
    77db49300d27:	add    BYTE PTR [rax],dh
    77db49300d29:	or     eax,0x77db4930
    77db49300d2e:	add    BYTE PTR [rax],al
    77db49300d30:	movabs r11,0x60ebc8b89940
    77db49300d3a:	jmp    r11
    77db49300d3d:	mov    eax,0x410288
    77db49300d42:	mov    QWORD PTR [r12+0x100],rax
    77db49300d4a:	push   rdx
    77db49300d4b:	push   rsi
    77db49300d4c:	push   r10
    77db49300d4e:	push   r11
    77db49300d50:	mov    r11,rax
    77db49300d53:	lahf
    77db49300d54:	seto   al
    77db49300d57:	mov    WORD PTR [rsp+0x20],ax
    77db49300d5c:	mov    rax,r11
    77db49300d5f:	mov    rdx,QWORD PTR [rsp+0x20]
    77db49300d64:	mov    r10d,edx
    77db49300d67:	and    r10d,0xc000
    77db49300d6e:	shl    r10d,0x10
    77db49300d72:	mov    r11d,edx
    77db49300d75:	and    r11d,0x100
    77db49300d7c:	shl    r11d,0x15
    77db49300d80:	or     r10d,r11d
    77db49300d83:	and    edx,0x1
    77db49300d86:	shl    edx,0x1c
    77db49300d89:	or     r10d,edx
    77db49300d8c:	btc    r10,0x1d
    77db49300d91:	mov    r11d,0xf0000000
    77db49300d97:	and    r11,r10
    77db49300d9a:	movabs rsi,0xffffffff0fffffff
    77db49300da4:	and    rbx,rsi
    77db49300da7:	or     rbx,r11
    77db49300daa:	pop    r11
    77db49300dac:	pop    r10
    77db49300dae:	pop    rsi
    77db49300daf:	pop    rdx
    77db49300db0:	mov    QWORD PTR [r12+0x108],rbx
    77db49300db8:	add    rsp,0x10
    77db49300dbc:	mov    eax,0xc
    77db49300dc1:	movabs r11,0x60ebc8b89ca0
    77db49300dcb:	jmp    r11
    77db49300dce:	xchg   ax,ax
    77db49300dd0:	sub    rsp,0x10
    77db49300dd4:	mov    r11,QWORD PTR [r12+0x398]
    77db49300ddc:	mov    QWORD PTR [rsp],r11
    77db49300de0:	jmp    0x77db49300bd3
    77db49300de5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49300df0:	sub    rsp,0x10
    77db49300df4:	mov    r11,QWORD PTR [r12+0x398]
    77db49300dfc:	mov    QWORD PTR [rsp],r11
    77db49300e00:	jmp    0x77db49300ca5
    77db49300e05:	nop
    77db49300e06:	nop
    77db49300e07:	nop
