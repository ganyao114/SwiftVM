
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/2/4.bin:     file format binary


Disassembly of section .data:

0000730a04101080 <.data>:
    730a04101080:	sub    rsp,0x10
    730a04101084:	mov    r11,QWORD PTR [r12+0x398]
    730a0410108c:	mov    QWORD PTR [rsp],r11
    730a04101090:	mov    r13,QWORD PTR [r12+0xf8]
    730a04101098:	add    r13,0x168
    730a0410109f:	mov    r14,QWORD PTR [r13+0x0]
    730a041010a3:	mov    QWORD PTR [r12+0x40],r14
    730a041010a8:	sub    r14,0x38
    730a041010ac:	mov    rcx,QWORD PTR [r12+0x380]
    730a041010b4:	jrcxz  0x730a041010bb
    730a041010b6:	jmp    0x730a0410118d
    730a041010bb:	jne    0x730a041010d4
    730a041010c1:	mov    r11,rax
    730a041010c4:	lahf
    730a041010c5:	seto   al
    730a041010c8:	mov    WORD PTR [rsp],ax
    730a041010cc:	mov    rax,r11
    730a041010cf:	jmp    0x730a041010e7
    730a041010d4:	mov    r11,rax
    730a041010d7:	lahf
    730a041010d8:	seto   al
    730a041010db:	mov    WORD PTR [rsp],ax
    730a041010df:	mov    rax,r11
    730a041010e2:	jmp    0x730a0410113d
    730a041010e7:	mov    r13d,0x4102d4
    730a041010ed:	mov    QWORD PTR [r12+0x100],r13
    730a041010f5:	mov    r11,QWORD PTR [rsp]
    730a041010f9:	mov    QWORD PTR [r12+0x398],r11
    730a04101101:	mov    edi,0x4102d4
    730a04101106:	mov    QWORD PTR [r12+0x100],rdi
    730a0410110e:	add    rsp,0x10
    730a04101112:	nop    WORD PTR [rax+rax*1+0x0]
    730a04101118:	jmp    QWORD PTR [rip+0x2]        # 0x730a04101120
    730a0410111e:	xchg   ax,ax
    730a04101120:	(bad)
    730a04101121:	adc    BYTE PTR [rax],dl
    730a04101123:	add    al,0xa
    730a04101125:	jae    0x730a04101127
    730a04101127:	add    BYTE PTR [rax],dh
    730a04101129:	adc    DWORD PTR [rax],edx
    730a0410112b:	add    al,0xa
    730a0410112d:	jae    0x730a0410112f
    730a0410112f:	add    BYTE PTR [rcx-0x45],cl
    730a04101132:	rex leave
    730a04101134:	ret    0x91a9
    730a04101137:	push   rbp
    730a04101138:	add    BYTE PTR [rax],al
    730a0410113a:	jmp    r11
    730a0410113d:	mov    r13d,0x4102b8
    730a04101143:	mov    QWORD PTR [r12+0x100],r13
    730a0410114b:	mov    r11,QWORD PTR [rsp]
    730a0410114f:	mov    QWORD PTR [r12+0x398],r11
    730a04101157:	mov    edi,0x4102b8
    730a0410115c:	mov    QWORD PTR [r12+0x100],rdi
    730a04101164:	add    rsp,0x10
    730a04101168:	jmp    QWORD PTR [rip+0x2]        # 0x730a04101170
    730a0410116e:	xchg   ax,ax
    730a04101170:	rex adc BYTE PTR [rax],dl
    730a04101173:	add    al,0xa
    730a04101175:	jae    0x730a04101177
    730a04101177:	add    BYTE PTR [rax+0xa041011],al
    730a0410117d:	jae    0x730a0410117f
    730a0410117f:	add    BYTE PTR [rcx-0x45],cl
    730a04101182:	rex leave
    730a04101184:	ret    0x91a9
    730a04101187:	push   rbp
    730a04101188:	add    BYTE PTR [rax],al
    730a0410118a:	jmp    r11
    730a0410118d:	mov    eax,0x4102d0
    730a04101192:	mov    QWORD PTR [r12+0x100],rax
    730a0410119a:	push   rdx
    730a0410119b:	push   rsi
    730a0410119c:	push   r10
    730a0410119e:	push   r11
    730a041011a0:	mov    r11,rax
    730a041011a3:	lahf
    730a041011a4:	seto   al
    730a041011a7:	mov    WORD PTR [rsp+0x20],ax
    730a041011ac:	mov    rax,r11
    730a041011af:	mov    rdx,QWORD PTR [rsp+0x20]
    730a041011b4:	mov    r10d,edx
    730a041011b7:	and    r10d,0xc000
    730a041011be:	shl    r10d,0x10
    730a041011c2:	mov    r11d,edx
    730a041011c5:	and    r11d,0x100
    730a041011cc:	shl    r11d,0x15
    730a041011d0:	or     r10d,r11d
    730a041011d3:	and    edx,0x1
    730a041011d6:	shl    edx,0x1c
    730a041011d9:	or     r10d,edx
    730a041011dc:	btc    r10,0x1d
    730a041011e1:	mov    r11d,0xf0000000
    730a041011e7:	and    r11,r10
    730a041011ea:	movabs rsi,0xffffffff0fffffff
    730a041011f4:	and    rbx,rsi
    730a041011f7:	or     rbx,r11
    730a041011fa:	pop    r11
    730a041011fc:	pop    r10
    730a041011fe:	pop    rsi
    730a041011ff:	pop    rdx
    730a04101200:	mov    QWORD PTR [r12+0x108],rbx
    730a04101208:	add    rsp,0x10
    730a0410120c:	mov    eax,0xc
    730a04101211:	movabs r11,0x5591a9c2cca0
    730a0410121b:	jmp    r11
    730a0410121e:	nop
    730a0410121f:	nop
