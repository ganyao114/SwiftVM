
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/1/7.bin:     file format binary


Disassembly of section .data:

00007c479db01910 <.data>:
    7c479db01910:	sub    rsp,0x10
    7c479db01914:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0191c:	mov    QWORD PTR [rsp],r11
    7c479db01920:	mov    r13,QWORD PTR [r12+0xa0]
    7c479db01928:	mov    r14,r13
    7c479db0192b:	shl    r14,0x2
    7c479db0192f:	mov    r15,QWORD PTR [r12+0x98]
    7c479db01937:	add    r15,r14
    7c479db0193a:	mov    r14d,DWORD PTR [r12]
    7c479db0193e:	mov    DWORD PTR [r15],r14d
    7c479db01941:	mov    r14d,0x0
    7c479db01947:	mov    DWORD PTR [r12+0x32c],r14d
    7c479db0194f:	add    r13,0x1
    7c479db01953:	mov    QWORD PTR [r12+0xa0],r13
    7c479db0195b:	sub    r13,0x400
    7c479db01962:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db0196a:	jrcxz  0x7c479db01971
    7c479db0196c:	jmp    0x7c479db01d4d
    7c479db01971:	jne    0x7c479db0198a
    7c479db01977:	mov    r11,rax
    7c479db0197a:	lahf
    7c479db0197b:	seto   al
    7c479db0197e:	mov    WORD PTR [rsp],ax
    7c479db01982:	mov    rax,r11
    7c479db01985:	jmp    0x7c479db0199d
    7c479db0198a:	mov    r11,rax
    7c479db0198d:	lahf
    7c479db0198e:	seto   al
    7c479db01991:	mov    WORD PTR [rsp],ax
    7c479db01995:	mov    rax,r11
    7c479db01998:	jmp    0x7c479db01cdd
    7c479db0199d:	mov    r13d,0x1
    7c479db019a3:	mov    QWORD PTR [r12+0x40],r13
    7c479db019a8:	mov    r11,rax
    7c479db019ab:	movzx  eax,WORD PTR [rsp]
    7c479db019af:	add    al,0x7f
    7c479db019b1:	sahf
    7c479db019b2:	mov    rax,r11
    7c479db019b5:	jmp    0x7c479db019ba
    7c479db019ba:	mov    r13,QWORD PTR [r12+0x40]
    7c479db019bf:	mov    r14,r13
    7c479db019c2:	lea    r14,[r14*4+0x0]
    7c479db019ca:	mov    r15,QWORD PTR [r12+0x98]
    7c479db019d2:	mov    r11,rax
    7c479db019d5:	lahf
    7c479db019d6:	seto   al
    7c479db019d9:	mov    WORD PTR [rsp],ax
    7c479db019dd:	mov    rax,r11
    7c479db019e0:	add    r15,r14
    7c479db019e3:	mov    r14d,DWORD PTR [r15]
    7c479db019e6:	mov    QWORD PTR [r12+0x48],r14
    7c479db019eb:	mov    r14d,0x0
    7c479db019f1:	or     r14,r13
    7c479db019f4:	mov    QWORD PTR [r12+0x50],r14
    7c479db019f9:	jmp    0x7c479db019fe
    7c479db019fe:	mov    r13d,DWORD PTR [r12+0x50]
    7c479db01a03:	sub    r13d,0x1
    7c479db01a07:	mov    QWORD PTR [r12+0x58],r13
    7c479db01a0c:	mov    ecx,0xffffffff
    7c479db01a11:	mov    r14,r13
    7c479db01a14:	and    r14,rcx
    7c479db01a17:	shl    r14,0x2
    7c479db01a1b:	mov    r13,QWORD PTR [r12+0x98]
    7c479db01a23:	add    r13,r14
    7c479db01a26:	mov    r14d,DWORD PTR [r13+0x0]
    7c479db01a2a:	mov    QWORD PTR [r12+0x60],r14
    7c479db01a2f:	mov    r13d,DWORD PTR [r12+0x48]
    7c479db01a34:	sub    r14d,r13d
    7c479db01a37:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db01a3f:	jrcxz  0x7c479db01a46
    7c479db01a41:	jmp    0x7c479db01dde
    7c479db01a46:	jbe    0x7c479db01a5f
    7c479db01a4c:	mov    r11,rax
    7c479db01a4f:	lahf
    7c479db01a50:	seto   al
    7c479db01a53:	mov    WORD PTR [rsp],ax
    7c479db01a57:	mov    rax,r11
    7c479db01a5a:	jmp    0x7c479db01a72
    7c479db01a5f:	mov    r11,rax
    7c479db01a62:	lahf
    7c479db01a63:	seto   al
    7c479db01a66:	mov    WORD PTR [rsp],ax
    7c479db01a6a:	mov    rax,r11
    7c479db01a6d:	jmp    0x7c479db01af1
    7c479db01a72:	mov    r13,QWORD PTR [r12+0x50]
    7c479db01a77:	mov    r14,r13
    7c479db01a7a:	shl    r14,0x2
    7c479db01a7e:	mov    r15,QWORD PTR [r12+0x98]
    7c479db01a86:	add    r15,r14
    7c479db01a89:	mov    r14d,DWORD PTR [r12+0x60]
    7c479db01a8e:	mov    DWORD PTR [r15],r14d
    7c479db01a91:	mov    r14d,0x0
    7c479db01a97:	mov    DWORD PTR [r12+0x32c],r14d
    7c479db01a9f:	sub    r13,0x1
    7c479db01aa3:	mov    QWORD PTR [r12+0x50],r13
    7c479db01aa8:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db01ab0:	jrcxz  0x7c479db01ab7
    7c479db01ab2:	jmp    0x7c479db01e6f
    7c479db01ab7:	mov    r13,QWORD PTR [r12+0x58]
    7c479db01abc:	mov    rax,r13
    7c479db01abf:	test   rax,rax
    7c479db01ac2:	jne    0x7c479db019fe
    7c479db01ac8:	jmp    0x7c479db01acd
    7c479db01acd:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db01ad5:	jrcxz  0x7c479db01adc
    7c479db01ad7:	jmp    0x7c479db01ef1
    7c479db01adc:	jmp    0x7c479db01ae1
    7c479db01ae1:	mov    r13d,0x0
    7c479db01ae7:	mov    QWORD PTR [r12+0x50],r13
    7c479db01aec:	jmp    0x7c479db01af1
    7c479db01af1:	mov    r13,QWORD PTR [r12+0x40]
    7c479db01af6:	add    r13,0x1
    7c479db01afa:	mov    QWORD PTR [r12+0x40],r13
    7c479db01aff:	mov    r14,QWORD PTR [r12+0x50]
    7c479db01b04:	mov    ecx,0xffffffff
    7c479db01b09:	and    r14,rcx
    7c479db01b0c:	shl    r14,0x2
    7c479db01b10:	mov    r15,QWORD PTR [r12+0x98]
    7c479db01b18:	add    r15,r14
    7c479db01b1b:	mov    r14d,DWORD PTR [r12+0x48]
    7c479db01b20:	mov    DWORD PTR [r15],r14d
    7c479db01b23:	mov    r14d,0x0
    7c479db01b29:	mov    DWORD PTR [r12+0x32c],r14d
    7c479db01b31:	sub    r13,0x400
    7c479db01b38:	jne    0x7c479db019ba
    7c479db01b3e:	mov    r11,rax
    7c479db01b41:	lahf
    7c479db01b42:	seto   al
    7c479db01b45:	mov    WORD PTR [rsp],ax
    7c479db01b49:	mov    rax,r11
    7c479db01b4c:	jmp    0x7c479db01b51
    7c479db01b51:	mov    r13d,0x430000
    7c479db01b57:	mov    QWORD PTR [r12+0x40],r13
    7c479db01b5c:	mov    r13d,0x0
    7c479db01b62:	mov    QWORD PTR [r12+0x58],r13
    7c479db01b67:	mov    r13d,0x0
    7c479db01b6d:	mov    QWORD PTR [r12+0x50],r13
    7c479db01b72:	mov    r13d,0x430cb0
    7c479db01b78:	mov    r14,QWORD PTR [r13+0x0]
    7c479db01b7c:	mov    QWORD PTR [r12+0x48],r14
    7c479db01b81:	jmp    0x7c479db01b86
    7c479db01b86:	mov    r13,QWORD PTR [r12+0x58]
    7c479db01b8b:	mov    r14,r13
    7c479db01b8e:	shl    r14,0x2
    7c479db01b92:	mov    r15,QWORD PTR [r12+0x98]
    7c479db01b9a:	add    r15,r14
    7c479db01b9d:	mov    QWORD PTR [r12+0x60],r15
    7c479db01ba2:	mov    r14,r15
    7c479db01ba5:	add    r14,0x4
    7c479db01ba9:	mov    ebp,DWORD PTR [r15]
    7c479db01bac:	mov    r15d,DWORD PTR [r14]
    7c479db01baf:	mov    QWORD PTR [r12+0x60],r15
    7c479db01bb4:	mov    r14,rbp
    7c479db01bb7:	imul   r14,r13
    7c479db01bbb:	mov    r8,rbp
    7c479db01bbe:	add    r8,r14
    7c479db01bc1:	mov    QWORD PTR [r12+0x68],r8
    7c479db01bc6:	add    r13,0x2
    7c479db01bca:	mov    QWORD PTR [r12+0x58],r13
    7c479db01bcf:	mov    r14,r13
    7c479db01bd2:	sub    r14,0x400
    7c479db01bd9:	mov    r14,QWORD PTR [r12+0x50]
    7c479db01bde:	setne  BYTE PTR [rsp+0x8]
    7c479db01be3:	mov    r11,rax
    7c479db01be6:	lahf
    7c479db01be7:	seto   al
    7c479db01bea:	mov    WORD PTR [rsp],ax
    7c479db01bee:	mov    rax,r11
    7c479db01bf1:	imul   r13,r15
    7c479db01bf5:	add    r14,r13
    7c479db01bf8:	mov    QWORD PTR [r12+0x50],r14
    7c479db01bfd:	mov    r13,QWORD PTR [r12+0x48]
    7c479db01c02:	add    r8,r13
    7c479db01c05:	mov    QWORD PTR [r12+0x48],r8
    7c479db01c0a:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db01c12:	jrcxz  0x7c479db01c19
    7c479db01c14:	jmp    0x7c479db01f73
    7c479db01c19:	cmp    BYTE PTR [rsp+0x8],0x0
    7c479db01c1e:	jne    0x7c479db01b86
    7c479db01c24:	jmp    0x7c479db01c29
    7c479db01c29:	mov    r13d,0x0
    7c479db01c2f:	mov    QWORD PTR [r12+0x98],r13
    7c479db01c37:	mov    r13,QWORD PTR [r12+0x48]
    7c479db01c3c:	mov    r14,QWORD PTR [r12+0x50]
    7c479db01c41:	add    r14,r13
    7c479db01c44:	mov    QWORD PTR [r12+0x48],r14
    7c479db01c49:	mov    r13d,0x1
    7c479db01c4f:	mov    QWORD PTR [r12],r13
    7c479db01c53:	mov    r13,QWORD PTR [r12+0x40]
    7c479db01c58:	add    r13,0xcb0
    7c479db01c5f:	mov    QWORD PTR [r13+0x0],r14
    7c479db01c63:	mov    r13d,0x0
    7c479db01c69:	mov    DWORD PTR [r12+0x32c],r13d
    7c479db01c71:	mov    r13d,0x1
    7c479db01c77:	mov    QWORD PTR [r12],r13
    7c479db01c7b:	mov    r13d,0x4103f8
    7c479db01c81:	mov    QWORD PTR [r12+0xf0],r13
    7c479db01c89:	mov    r13d,0x4109a4
    7c479db01c8f:	mov    QWORD PTR [r12+0x100],r13
    7c479db01c97:	mov    r11,QWORD PTR [rsp]
    7c479db01c9b:	mov    QWORD PTR [r12+0x398],r11
    7c479db01ca3:	mov    edi,0x4109a4
    7c479db01ca8:	mov    QWORD PTR [r12+0x100],rdi
    7c479db01cb0:	add    rsp,0x10
    7c479db01cb4:	nop    DWORD PTR [rax+0x0]
    7c479db01cb8:	jmp    QWORD PTR [rip+0x2]        # 0x7c479db01cc0
    7c479db01cbe:	xchg   ax,ax
    7c479db01cc0:	rex (bad)
    7c479db01cc2:	mov    al,0x9d
    7c479db01cc4:	rex.RXB jl 0x7c479db01cc7
    7c479db01cc7:	add    al,dl
    7c479db01cc9:	sbb    al,0xb0
    7c479db01ccb:	popf
    7c479db01ccc:	rex.RXB jl 0x7c479db01ccf
    7c479db01ccf:	add    BYTE PTR [rcx-0x45],cl
    7c479db01cd2:	rex jns 0x7c479db01d07
    7c479db01cd5:	xchg   esi,edi
    7c479db01cd7:	(bad)
    7c479db01cd8:	add    BYTE PTR [rax],al
    7c479db01cda:	jmp    r11
    7c479db01cdd:	mov    r13d,DWORD PTR [r12+0xa0]
    7c479db01ce5:	add    r13d,0x11
    7c479db01ce9:	mov    QWORD PTR [r12],r13
    7c479db01ced:	mov    r13d,0x41035c
    7c479db01cf3:	mov    QWORD PTR [r12+0xf0],r13
    7c479db01cfb:	mov    r13d,0x4109a4
    7c479db01d01:	mov    QWORD PTR [r12+0x100],r13
    7c479db01d09:	mov    r11,QWORD PTR [rsp]
    7c479db01d0d:	mov    QWORD PTR [r12+0x398],r11
    7c479db01d15:	mov    edi,0x4109a4
    7c479db01d1a:	mov    QWORD PTR [r12+0x100],rdi
    7c479db01d22:	add    rsp,0x10
    7c479db01d26:	xchg   ax,ax
    7c479db01d28:	jmp    QWORD PTR [rip+0x2]        # 0x7c479db01d30
    7c479db01d2e:	xchg   ax,ax
    7c479db01d30:	rex (bad)
    7c479db01d32:	mov    al,0x9d
    7c479db01d34:	rex.RXB jl 0x7c479db01d37
    7c479db01d37:	add    BYTE PTR [rax+0x1d],al
    7c479db01d3a:	mov    al,0x9d
    7c479db01d3c:	rex.RXB jl 0x7c479db01d3f
    7c479db01d3f:	add    BYTE PTR [rcx-0x45],cl
    7c479db01d42:	rex jns 0x7c479db01d77
    7c479db01d45:	xchg   esi,edi
    7c479db01d47:	(bad)
    7c479db01d48:	add    BYTE PTR [rax],al
    7c479db01d4a:	jmp    r11
    7c479db01d4d:	mov    eax,0x410368
    7c479db01d52:	mov    QWORD PTR [r12+0x100],rax
    7c479db01d5a:	push   rdx
    7c479db01d5b:	push   rsi
    7c479db01d5c:	push   r10
    7c479db01d5e:	push   r11
    7c479db01d60:	mov    r11,rax
    7c479db01d63:	lahf
    7c479db01d64:	seto   al
    7c479db01d67:	mov    WORD PTR [rsp+0x20],ax
    7c479db01d6c:	mov    rax,r11
    7c479db01d6f:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db01d74:	mov    r10d,edx
    7c479db01d77:	and    r10d,0xc000
    7c479db01d7e:	shl    r10d,0x10
    7c479db01d82:	mov    r11d,edx
    7c479db01d85:	and    r11d,0x100
    7c479db01d8c:	shl    r11d,0x15
    7c479db01d90:	or     r10d,r11d
    7c479db01d93:	and    edx,0x1
    7c479db01d96:	shl    edx,0x1c
    7c479db01d99:	or     r10d,edx
    7c479db01d9c:	btc    r10,0x1d
    7c479db01da1:	mov    r11d,0xf0000000
    7c479db01da7:	and    r11,r10
    7c479db01daa:	movabs rsi,0xffffffff0fffffff
    7c479db01db4:	and    rbx,rsi
    7c479db01db7:	or     rbx,r11
    7c479db01dba:	pop    r11
    7c479db01dbc:	pop    r10
    7c479db01dbe:	pop    rsi
    7c479db01dbf:	pop    rdx
    7c479db01dc0:	mov    QWORD PTR [r12+0x108],rbx
    7c479db01dc8:	add    rsp,0x10
    7c479db01dcc:	mov    eax,0xc
    7c479db01dd1:	movabs r11,0x62fe87327ca0
    7c479db01ddb:	jmp    r11
    7c479db01dde:	mov    eax,0x41039c
    7c479db01de3:	mov    QWORD PTR [r12+0x100],rax
    7c479db01deb:	push   rdx
    7c479db01dec:	push   rsi
    7c479db01ded:	push   r10
    7c479db01def:	push   r11
    7c479db01df1:	mov    r11,rax
    7c479db01df4:	lahf
    7c479db01df5:	seto   al
    7c479db01df8:	mov    WORD PTR [rsp+0x20],ax
    7c479db01dfd:	mov    rax,r11
    7c479db01e00:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db01e05:	mov    r10d,edx
    7c479db01e08:	and    r10d,0xc000
    7c479db01e0f:	shl    r10d,0x10
    7c479db01e13:	mov    r11d,edx
    7c479db01e16:	and    r11d,0x100
    7c479db01e1d:	shl    r11d,0x15
    7c479db01e21:	or     r10d,r11d
    7c479db01e24:	and    edx,0x1
    7c479db01e27:	shl    edx,0x1c
    7c479db01e2a:	or     r10d,edx
    7c479db01e2d:	btc    r10,0x1d
    7c479db01e32:	mov    r11d,0xf0000000
    7c479db01e38:	and    r11,r10
    7c479db01e3b:	movabs rsi,0xffffffff0fffffff
    7c479db01e45:	and    rbx,rsi
    7c479db01e48:	or     rbx,r11
    7c479db01e4b:	pop    r11
    7c479db01e4d:	pop    r10
    7c479db01e4f:	pop    rsi
    7c479db01e50:	pop    rdx
    7c479db01e51:	mov    QWORD PTR [r12+0x108],rbx
    7c479db01e59:	add    rsp,0x10
    7c479db01e5d:	mov    eax,0xc
    7c479db01e62:	movabs r11,0x62fe87327ca0
    7c479db01e6c:	jmp    r11
    7c479db01e6f:	mov    eax,0x4103a8
    7c479db01e74:	mov    QWORD PTR [r12+0x100],rax
    7c479db01e7c:	push   rdx
    7c479db01e7d:	push   rsi
    7c479db01e7e:	push   r10
    7c479db01e80:	push   r11
    7c479db01e82:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db01e87:	mov    r10d,edx
    7c479db01e8a:	and    r10d,0xc000
    7c479db01e91:	shl    r10d,0x10
    7c479db01e95:	mov    r11d,edx
    7c479db01e98:	and    r11d,0x100
    7c479db01e9f:	shl    r11d,0x15
    7c479db01ea3:	or     r10d,r11d
    7c479db01ea6:	and    edx,0x1
    7c479db01ea9:	shl    edx,0x1c
    7c479db01eac:	or     r10d,edx
    7c479db01eaf:	btc    r10,0x1d
    7c479db01eb4:	mov    r11d,0xf0000000
    7c479db01eba:	and    r11,r10
    7c479db01ebd:	movabs rsi,0xffffffff0fffffff
    7c479db01ec7:	and    rbx,rsi
    7c479db01eca:	or     rbx,r11
    7c479db01ecd:	pop    r11
    7c479db01ecf:	pop    r10
    7c479db01ed1:	pop    rsi
    7c479db01ed2:	pop    rdx
    7c479db01ed3:	mov    QWORD PTR [r12+0x108],rbx
    7c479db01edb:	add    rsp,0x10
    7c479db01edf:	mov    eax,0xc
    7c479db01ee4:	movabs r11,0x62fe87327ca0
    7c479db01eee:	jmp    r11
    7c479db01ef1:	mov    eax,0x4103ac
    7c479db01ef6:	mov    QWORD PTR [r12+0x100],rax
    7c479db01efe:	push   rdx
    7c479db01eff:	push   rsi
    7c479db01f00:	push   r10
    7c479db01f02:	push   r11
    7c479db01f04:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db01f09:	mov    r10d,edx
    7c479db01f0c:	and    r10d,0xc000
    7c479db01f13:	shl    r10d,0x10
    7c479db01f17:	mov    r11d,edx
    7c479db01f1a:	and    r11d,0x100
    7c479db01f21:	shl    r11d,0x15
    7c479db01f25:	or     r10d,r11d
    7c479db01f28:	and    edx,0x1
    7c479db01f2b:	shl    edx,0x1c
    7c479db01f2e:	or     r10d,edx
    7c479db01f31:	btc    r10,0x1d
    7c479db01f36:	mov    r11d,0xf0000000
    7c479db01f3c:	and    r11,r10
    7c479db01f3f:	movabs rsi,0xffffffff0fffffff
    7c479db01f49:	and    rbx,rsi
    7c479db01f4c:	or     rbx,r11
    7c479db01f4f:	pop    r11
    7c479db01f51:	pop    r10
    7c479db01f53:	pop    rsi
    7c479db01f54:	pop    rdx
    7c479db01f55:	mov    QWORD PTR [r12+0x108],rbx
    7c479db01f5d:	add    rsp,0x10
    7c479db01f61:	mov    eax,0xc
    7c479db01f66:	movabs r11,0x62fe87327ca0
    7c479db01f70:	jmp    r11
    7c479db01f73:	mov    eax,0x4103dc
    7c479db01f78:	mov    QWORD PTR [r12+0x100],rax
    7c479db01f80:	push   rdx
    7c479db01f81:	push   rsi
    7c479db01f82:	push   r10
    7c479db01f84:	push   r11
    7c479db01f86:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db01f8b:	mov    r10d,edx
    7c479db01f8e:	and    r10d,0xc000
    7c479db01f95:	shl    r10d,0x10
    7c479db01f99:	mov    r11d,edx
    7c479db01f9c:	and    r11d,0x100
    7c479db01fa3:	shl    r11d,0x15
    7c479db01fa7:	or     r10d,r11d
    7c479db01faa:	and    edx,0x1
    7c479db01fad:	shl    edx,0x1c
    7c479db01fb0:	or     r10d,edx
    7c479db01fb3:	btc    r10,0x1d
    7c479db01fb8:	mov    r11d,0xf0000000
    7c479db01fbe:	and    r11,r10
    7c479db01fc1:	movabs rsi,0xffffffff0fffffff
    7c479db01fcb:	and    rbx,rsi
    7c479db01fce:	or     rbx,r11
    7c479db01fd1:	pop    r11
    7c479db01fd3:	pop    r10
    7c479db01fd5:	pop    rsi
    7c479db01fd6:	pop    rdx
    7c479db01fd7:	mov    QWORD PTR [r12+0x108],rbx
    7c479db01fdf:	add    rsp,0x10
    7c479db01fe3:	mov    eax,0xc
    7c479db01fe8:	movabs r11,0x62fe87327ca0
    7c479db01ff2:	jmp    r11
    7c479db01ff5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db02000:	sub    rsp,0x10
    7c479db02004:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0200c:	mov    QWORD PTR [rsp],r11
    7c479db02010:	jmp    0x7c479db0199d
    7c479db02015:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db02020:	sub    rsp,0x10
    7c479db02024:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0202c:	mov    QWORD PTR [rsp],r11
    7c479db02030:	mov    r11,rax
    7c479db02033:	movzx  eax,WORD PTR [rsp]
    7c479db02037:	add    al,0x7f
    7c479db02039:	sahf
    7c479db0203a:	mov    rax,r11
    7c479db0203d:	jmp    0x7c479db019ba
    7c479db02042:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db02050:	sub    rsp,0x10
    7c479db02054:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0205c:	mov    QWORD PTR [rsp],r11
    7c479db02060:	jmp    0x7c479db019fe
    7c479db02065:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db02070:	sub    rsp,0x10
    7c479db02074:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0207c:	mov    QWORD PTR [rsp],r11
    7c479db02080:	jmp    0x7c479db01a72
    7c479db02085:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db02090:	sub    rsp,0x10
    7c479db02094:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0209c:	mov    QWORD PTR [rsp],r11
    7c479db020a0:	jmp    0x7c479db01acd
    7c479db020a5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db020b0:	sub    rsp,0x10
    7c479db020b4:	mov    r11,QWORD PTR [r12+0x398]
    7c479db020bc:	mov    QWORD PTR [rsp],r11
    7c479db020c0:	jmp    0x7c479db01ae1
    7c479db020c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db020d0:	sub    rsp,0x10
    7c479db020d4:	mov    r11,QWORD PTR [r12+0x398]
    7c479db020dc:	mov    QWORD PTR [rsp],r11
    7c479db020e0:	jmp    0x7c479db01af1
    7c479db020e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db020f0:	sub    rsp,0x10
    7c479db020f4:	mov    r11,QWORD PTR [r12+0x398]
    7c479db020fc:	mov    QWORD PTR [rsp],r11
    7c479db02100:	jmp    0x7c479db01b51
    7c479db02105:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db02110:	sub    rsp,0x10
    7c479db02114:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0211c:	mov    QWORD PTR [rsp],r11
    7c479db02120:	jmp    0x7c479db01b86
    7c479db02125:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db02130:	sub    rsp,0x10
    7c479db02134:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0213c:	mov    QWORD PTR [rsp],r11
    7c479db02140:	jmp    0x7c479db01c29
    7c479db02145:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db02150:	sub    rsp,0x10
    7c479db02154:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0215c:	mov    QWORD PTR [rsp],r11
    7c479db02160:	jmp    0x7c479db01cdd
    7c479db02165:	nop
    7c479db02166:	nop
    7c479db02167:	nop
