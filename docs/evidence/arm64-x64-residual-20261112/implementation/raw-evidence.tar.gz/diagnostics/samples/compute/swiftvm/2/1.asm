
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/2/1.bin:     file format binary


Disassembly of section .data:

0000730a040fe5e0 <.data>:
    730a040fe5e0:	sub    rsp,0xc0
    730a040fe5e7:	mov    r11,QWORD PTR [r12+0x398]
    730a040fe5ef:	mov    QWORD PTR [rsp+0xb0],r11
    730a040fe5f7:	mov    r13,QWORD PTR [r12]
    730a040fe5fb:	mov    r14,r13
    730a040fe5fe:	add    r14,0x20
    730a040fe602:	mov    r15,QWORD PTR [r14]
    730a040fe605:	mov    r14,QWORD PTR [r12+0x10]
    730a040fe60a:	add    r15,r14
    730a040fe60d:	mov    QWORD PTR [r12+0x40],r15
    730a040fe612:	add    r13,0x20
    730a040fe616:	mov    QWORD PTR [r13+0x0],r15
    730a040fe61a:	mov    r13d,0x0
    730a040fe620:	mov    DWORD PTR [r12+0x32c],r13d
    730a040fe628:	mov    rax,r14
    730a040fe62b:	test   rax,rax
    730a040fe62e:	je     0x730a04100735
    730a040fe634:	jmp    0x730a040fe639
    730a040fe639:	mov    r13,QWORD PTR [r12+0xf8]
    730a040fe641:	sub    r13,0x150
    730a040fe648:	mov    QWORD PTR [r12+0xf8],r13
    730a040fe650:	mov    r14,QWORD PTR [r12]
    730a040fe654:	mov    r15,r14
    730a040fe657:	add    r15,0x68
    730a040fe65b:	mov    rbp,QWORD PTR [r15]
    730a040fe65e:	mov    QWORD PTR [r12+0x88],rbp
    730a040fe666:	add    r14,0x28
    730a040fe66a:	mov    QWORD PTR [r12+0x40],r14
    730a040fe66f:	mov    QWORD PTR [r12+0x48],r13
    730a040fe674:	mov    r14d,0x420000
    730a040fe67a:	add    r14,0xb90
    730a040fe681:	mov    QWORD PTR [r12+0x50],r14
    730a040fe686:	mov    r14,r13
    730a040fe689:	add    r14,0x100
    730a040fe690:	mov    r15,r14
    730a040fe693:	add    r15,0x8
    730a040fe697:	mov    rbp,QWORD PTR [r12+0xe8]
    730a040fe69f:	mov    r8,QWORD PTR [r12+0xd8]
    730a040fe6a7:	mov    QWORD PTR [r14],rbp
    730a040fe6aa:	mov    r14d,0x0
    730a040fe6b0:	mov    DWORD PTR [r12+0x32c],r14d
    730a040fe6b8:	mov    QWORD PTR [r15],r8
    730a040fe6bb:	mov    r14,r13
    730a040fe6be:	add    r14,0x110
    730a040fe6c5:	mov    r15,r14
    730a040fe6c8:	add    r15,0x8
    730a040fe6cc:	mov    rbp,QWORD PTR [r12+0xd0]
    730a040fe6d4:	mov    r8,QWORD PTR [r12+0xc8]
    730a040fe6dc:	mov    QWORD PTR [r14],rbp
    730a040fe6df:	mov    QWORD PTR [r15],r8
    730a040fe6e2:	mov    r14,r13
    730a040fe6e5:	add    r14,0x120
    730a040fe6ec:	mov    r15,r14
    730a040fe6ef:	add    r15,0x8
    730a040fe6f3:	mov    rbp,QWORD PTR [r12+0xc0]
    730a040fe6fb:	mov    r8,QWORD PTR [r12+0xb8]
    730a040fe703:	mov    QWORD PTR [r14],rbp
    730a040fe706:	mov    QWORD PTR [r15],r8
    730a040fe709:	mov    r14,r13
    730a040fe70c:	add    r14,0x130
    730a040fe713:	mov    r15,r14
    730a040fe716:	add    r15,0x8
    730a040fe71a:	mov    rbp,QWORD PTR [r12+0xb0]
    730a040fe722:	mov    r8,QWORD PTR [r12+0xa8]
    730a040fe72a:	mov    QWORD PTR [r14],rbp
    730a040fe72d:	mov    QWORD PTR [r15],r8
    730a040fe730:	add    r13,0x140
    730a040fe737:	mov    r14,r13
    730a040fe73a:	add    r14,0x8
    730a040fe73e:	mov    r15,QWORD PTR [r12+0xa0]
    730a040fe746:	mov    rbp,QWORD PTR [r12+0x98]
    730a040fe74e:	mov    QWORD PTR [r13+0x0],r15
    730a040fe752:	mov    QWORD PTR [r14],rbp
    730a040fe755:	jmp    0x730a040fe75a
    730a040fe75a:	mov    r13,QWORD PTR [r12+0x8]
    730a040fe75f:	mov    r14,r13
    730a040fe762:	add    r14,0x1
    730a040fe766:	movzx  r15d,BYTE PTR [r13+0x0]
    730a040fe76b:	mov    QWORD PTR [r12+0x58],r15
    730a040fe770:	mov    QWORD PTR [r12+0x8],r14
    730a040fe775:	mov    r13,QWORD PTR [r12+0x88]
    730a040fe77d:	mov    r14,r13
    730a040fe780:	add    r14,0x1
    730a040fe784:	mov    QWORD PTR [r12+0x60],r14
    730a040fe789:	mov    r15,QWORD PTR [r12]
    730a040fe78d:	mov    rbp,r15
    730a040fe790:	add    rbp,0x68
    730a040fe794:	mov    QWORD PTR [rbp+0x0],r14
    730a040fe798:	mov    r14d,0x0
    730a040fe79e:	mov    DWORD PTR [r12+0x32c],r14d
    730a040fe7a6:	mov    r14,r15
    730a040fe7a9:	add    r14,r13
    730a040fe7ac:	mov    QWORD PTR [r12+0x60],r14
    730a040fe7b1:	add    r14,0x28
    730a040fe7b5:	movzx  r13d,BYTE PTR [r12+0x58]
    730a040fe7bb:	mov    BYTE PTR [r14],r13b
    730a040fe7be:	add    r15,0x68
    730a040fe7c2:	mov    r13,QWORD PTR [r15]
    730a040fe7c5:	mov    QWORD PTR [r12+0x88],r13
    730a040fe7cd:	sub    r13,0x40
    730a040fe7d1:	mov    rcx,QWORD PTR [r12+0x380]
    730a040fe7d9:	jrcxz  0x730a040fe7e0
    730a040fe7db:	jmp    0x730a04100780
    730a040fe7e0:	jne    0x730a040fe7fd
    730a040fe7e6:	mov    r11,rax
    730a040fe7e9:	lahf
    730a040fe7ea:	seto   al
    730a040fe7ed:	mov    WORD PTR [rsp+0xb0],ax
    730a040fe7f5:	mov    rax,r11
    730a040fe7f8:	jmp    0x730a040fe814
    730a040fe7fd:	mov    r11,rax
    730a040fe800:	lahf
    730a040fe801:	seto   al
    730a040fe804:	mov    WORD PTR [rsp+0xb0],ax
    730a040fe80c:	mov    rax,r11
    730a040fe80f:	jmp    0x730a04100637
    730a040fe814:	mov    rax,QWORD PTR [r12+0x40]
    730a040fe819:	mov    eax,0x0
    730a040fe81e:	mov    QWORD PTR [rsp+0x18],rax
    730a040fe823:	mov    eax,0x0
    730a040fe828:	mov    QWORD PTR [rsp+0x10],rax
    730a040fe82d:	mov    eax,0x0
    730a040fe832:	mov    QWORD PTR [rsp+0x8],rax
    730a040fe837:	mov    eax,0x0
    730a040fe83c:	mov    QWORD PTR [rsp],rax
    730a040fe840:	mov    rdi,QWORD PTR [r12+0x40]
    730a040fe845:	movzx  r9d,BYTE PTR [rdi]
    730a040fe849:	mov    r13,QWORD PTR [rsp+0x18]
    730a040fe84e:	or     r13,r9
    730a040fe851:	mov    r9,QWORD PTR [r12+0x40]
    730a040fe856:	add    r9,0x1
    730a040fe85a:	movzx  r8d,BYTE PTR [r9]
    730a040fe85e:	mov    r9,QWORD PTR [rsp+0x10]
    730a040fe863:	or     r9,r8
    730a040fe866:	mov    r8,QWORD PTR [r12+0x40]
    730a040fe86b:	add    r8,0x2
    730a040fe86f:	movzx  ebp,BYTE PTR [r8]
    730a040fe873:	mov    r8,QWORD PTR [rsp+0x8]
    730a040fe878:	or     r8,rbp
    730a040fe87b:	mov    rbp,QWORD PTR [r12+0x40]
    730a040fe880:	add    rbp,0x3
    730a040fe884:	movzx  r15d,BYTE PTR [rbp+0x0]
    730a040fe889:	mov    rbp,QWORD PTR [rsp]
    730a040fe88d:	or     rbp,r15
    730a040fe890:	mov    r15,QWORD PTR [r12+0x40]
    730a040fe895:	add    r15,0x4
    730a040fe899:	movzx  r14d,BYTE PTR [r15]
    730a040fe89d:	mov    r15,r14
    730a040fe8a0:	shl    r15,0x8
    730a040fe8a4:	or     r13,r15
    730a040fe8a7:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe8ac:	add    r14,0x5
    730a040fe8b0:	movzx  r15d,BYTE PTR [r14]
    730a040fe8b4:	mov    r14,r15
    730a040fe8b7:	shl    r14,0x8
    730a040fe8bb:	or     r9,r14
    730a040fe8be:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe8c3:	add    r14,0x6
    730a040fe8c7:	movzx  r15d,BYTE PTR [r14]
    730a040fe8cb:	mov    r14,r15
    730a040fe8ce:	shl    r14,0x8
    730a040fe8d2:	or     r8,r14
    730a040fe8d5:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe8da:	add    r14,0x7
    730a040fe8de:	movzx  r15d,BYTE PTR [r14]
    730a040fe8e2:	mov    r14,r15
    730a040fe8e5:	shl    r14,0x8
    730a040fe8e9:	or     rbp,r14
    730a040fe8ec:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe8f1:	add    r14,0x8
    730a040fe8f5:	movzx  r15d,BYTE PTR [r14]
    730a040fe8f9:	mov    r14,r15
    730a040fe8fc:	shl    r14,0x10
    730a040fe900:	or     r13,r14
    730a040fe903:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe908:	add    r14,0x9
    730a040fe90c:	movzx  r15d,BYTE PTR [r14]
    730a040fe910:	mov    r14,r15
    730a040fe913:	shl    r14,0x10
    730a040fe917:	or     r9,r14
    730a040fe91a:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe91f:	add    r14,0xa
    730a040fe923:	movzx  r15d,BYTE PTR [r14]
    730a040fe927:	mov    r14,r15
    730a040fe92a:	shl    r14,0x10
    730a040fe92e:	or     r8,r14
    730a040fe931:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe936:	add    r14,0xb
    730a040fe93a:	movzx  r15d,BYTE PTR [r14]
    730a040fe93e:	mov    r14,r15
    730a040fe941:	shl    r14,0x10
    730a040fe945:	or     rbp,r14
    730a040fe948:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe94d:	add    r14,0xc
    730a040fe951:	movzx  r15d,BYTE PTR [r14]
    730a040fe955:	mov    r14,r15
    730a040fe958:	shl    r14,0x18
    730a040fe95c:	or     r13,r14
    730a040fe95f:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe964:	add    r14,0xd
    730a040fe968:	movzx  r15d,BYTE PTR [r14]
    730a040fe96c:	mov    r14,r15
    730a040fe96f:	shl    r14,0x18
    730a040fe973:	or     r9,r14
    730a040fe976:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe97b:	add    r14,0xe
    730a040fe97f:	movzx  r15d,BYTE PTR [r14]
    730a040fe983:	mov    r14,r15
    730a040fe986:	shl    r14,0x18
    730a040fe98a:	or     r8,r14
    730a040fe98d:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe992:	add    r14,0xf
    730a040fe996:	movzx  r15d,BYTE PTR [r14]
    730a040fe99a:	mov    r14,r15
    730a040fe99d:	shl    r14,0x18
    730a040fe9a1:	or     rbp,r14
    730a040fe9a4:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe9a9:	add    r14,0x10
    730a040fe9ad:	movzx  r15d,BYTE PTR [r14]
    730a040fe9b1:	mov    r14,r15
    730a040fe9b4:	shl    r14,0x20
    730a040fe9b8:	or     r13,r14
    730a040fe9bb:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe9c0:	add    r14,0x11
    730a040fe9c4:	movzx  r15d,BYTE PTR [r14]
    730a040fe9c8:	mov    r14,r15
    730a040fe9cb:	shl    r14,0x20
    730a040fe9cf:	or     r9,r14
    730a040fe9d2:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe9d7:	add    r14,0x12
    730a040fe9db:	movzx  r15d,BYTE PTR [r14]
    730a040fe9df:	mov    r14,r15
    730a040fe9e2:	shl    r14,0x20
    730a040fe9e6:	or     r8,r14
    730a040fe9e9:	mov    r14,QWORD PTR [r12+0x40]
    730a040fe9ee:	add    r14,0x13
    730a040fe9f2:	movzx  r15d,BYTE PTR [r14]
    730a040fe9f6:	mov    r14,r15
    730a040fe9f9:	shl    r14,0x20
    730a040fe9fd:	or     rbp,r14
    730a040fea00:	mov    r14,QWORD PTR [r12+0x40]
    730a040fea05:	add    r14,0x14
    730a040fea09:	movzx  r15d,BYTE PTR [r14]
    730a040fea0d:	mov    r14,r15
    730a040fea10:	shl    r14,0x28
    730a040fea14:	or     r13,r14
    730a040fea17:	mov    r14,QWORD PTR [r12+0x40]
    730a040fea1c:	add    r14,0x15
    730a040fea20:	movzx  r15d,BYTE PTR [r14]
    730a040fea24:	mov    r14,r15
    730a040fea27:	shl    r14,0x28
    730a040fea2b:	or     r9,r14
    730a040fea2e:	mov    r14,QWORD PTR [r12+0x40]
    730a040fea33:	add    r14,0x16
    730a040fea37:	movzx  r15d,BYTE PTR [r14]
    730a040fea3b:	mov    r14,r15
    730a040fea3e:	shl    r14,0x28
    730a040fea42:	or     r8,r14
    730a040fea45:	mov    r14,QWORD PTR [r12+0x40]
    730a040fea4a:	add    r14,0x17
    730a040fea4e:	movzx  r15d,BYTE PTR [r14]
    730a040fea52:	mov    r14,r15
    730a040fea55:	shl    r14,0x28
    730a040fea59:	or     rbp,r14
    730a040fea5c:	mov    r14,QWORD PTR [r12+0x40]
    730a040fea61:	add    r14,0x18
    730a040fea65:	movzx  r15d,BYTE PTR [r14]
    730a040fea69:	mov    r14,r15
    730a040fea6c:	shl    r14,0x30
    730a040fea70:	or     r13,r14
    730a040fea73:	mov    r14,QWORD PTR [r12+0x40]
    730a040fea78:	add    r14,0x19
    730a040fea7c:	movzx  r15d,BYTE PTR [r14]
    730a040fea80:	mov    r14,r15
    730a040fea83:	shl    r14,0x30
    730a040fea87:	or     r9,r14
    730a040fea8a:	mov    r14,QWORD PTR [r12+0x40]
    730a040fea8f:	add    r14,0x1a
    730a040fea93:	movzx  r15d,BYTE PTR [r14]
    730a040fea97:	mov    r14,r15
    730a040fea9a:	shl    r14,0x30
    730a040fea9e:	or     r8,r14
    730a040feaa1:	mov    r14,QWORD PTR [r12+0x40]
    730a040feaa6:	add    r14,0x1b
    730a040feaaa:	movzx  r15d,BYTE PTR [r14]
    730a040feaae:	mov    r14,r15
    730a040feab1:	shl    r14,0x30
    730a040feab5:	or     rbp,r14
    730a040feab8:	mov    r14,QWORD PTR [r12+0x40]
    730a040feabd:	add    r14,0x1c
    730a040feac1:	movzx  r15d,BYTE PTR [r14]
    730a040feac5:	mov    r14,r15
    730a040feac8:	shl    r14,0x38
    730a040feacc:	mov    rax,r13
    730a040feacf:	or     rax,r14
    730a040fead2:	mov    QWORD PTR [rsp+0x28],rax
    730a040fead7:	mov    r14,QWORD PTR [r12+0x40]
    730a040feadc:	add    r14,0x1d
    730a040feae0:	movzx  r15d,BYTE PTR [r14]
    730a040feae4:	mov    r14,r15
    730a040feae7:	shl    r14,0x38
    730a040feaeb:	mov    rax,r9
    730a040feaee:	or     rax,r14
    730a040feaf1:	mov    QWORD PTR [rsp+0x38],rax
    730a040feaf6:	mov    r14,QWORD PTR [r12+0x40]
    730a040feafb:	add    r14,0x1e
    730a040feaff:	movzx  r15d,BYTE PTR [r14]
    730a040feb03:	mov    r14,r15
    730a040feb06:	shl    r14,0x38
    730a040feb0a:	mov    rax,r8
    730a040feb0d:	or     rax,r14
    730a040feb10:	mov    QWORD PTR [rsp+0x30],rax
    730a040feb15:	mov    r14,QWORD PTR [r12+0x40]
    730a040feb1a:	add    r14,0x1f
    730a040feb1e:	movzx  r15d,BYTE PTR [r14]
    730a040feb22:	mov    r14,r15
    730a040feb25:	shl    r14,0x38
    730a040feb29:	mov    rax,rbp
    730a040feb2c:	or     rax,r14
    730a040feb2f:	mov    QWORD PTR [rsp+0x20],rax
    730a040feb34:	mov    r14,QWORD PTR [r12+0x40]
    730a040feb39:	add    r14,0x20
    730a040feb3d:	movzx  r15d,BYTE PTR [r14]
    730a040feb41:	mov    r14,QWORD PTR [rsp+0x18]
    730a040feb46:	or     r14,r15
    730a040feb49:	mov    r15,QWORD PTR [r12+0x40]
    730a040feb4e:	add    r15,0x21
    730a040feb52:	movzx  ebp,BYTE PTR [r15]
    730a040feb56:	mov    r15,QWORD PTR [rsp+0x10]
    730a040feb5b:	or     r15,rbp
    730a040feb5e:	mov    rbp,QWORD PTR [r12+0x40]
    730a040feb63:	add    rbp,0x22
    730a040feb67:	movzx  r13d,BYTE PTR [rbp+0x0]
    730a040feb6c:	mov    rbp,QWORD PTR [rsp+0x8]
    730a040feb71:	or     rbp,r13
    730a040feb74:	mov    r13,QWORD PTR [r12+0x40]
    730a040feb79:	add    r13,0x23
    730a040feb7d:	movzx  r8d,BYTE PTR [r13+0x0]
    730a040feb82:	mov    r13,QWORD PTR [rsp]
    730a040feb86:	or     r13,r8
    730a040feb89:	mov    r8,QWORD PTR [r12+0x40]
    730a040feb8e:	add    r8,0x24
    730a040feb92:	movzx  r9d,BYTE PTR [r8]
    730a040feb96:	mov    r8,r9
    730a040feb99:	shl    r8,0x8
    730a040feb9d:	or     r14,r8
    730a040feba0:	mov    r8,QWORD PTR [r12+0x40]
    730a040feba5:	add    r8,0x25
    730a040feba9:	movzx  r9d,BYTE PTR [r8]
    730a040febad:	mov    r8,r9
    730a040febb0:	shl    r8,0x8
    730a040febb4:	or     r15,r8
    730a040febb7:	mov    r8,QWORD PTR [r12+0x40]
    730a040febbc:	add    r8,0x26
    730a040febc0:	movzx  r9d,BYTE PTR [r8]
    730a040febc4:	mov    r8,r9
    730a040febc7:	shl    r8,0x8
    730a040febcb:	or     rbp,r8
    730a040febce:	mov    r8,QWORD PTR [r12+0x40]
    730a040febd3:	add    r8,0x27
    730a040febd7:	movzx  r9d,BYTE PTR [r8]
    730a040febdb:	mov    r8,r9
    730a040febde:	shl    r8,0x8
    730a040febe2:	or     r13,r8
    730a040febe5:	mov    r8,QWORD PTR [r12+0x40]
    730a040febea:	add    r8,0x28
    730a040febee:	movzx  r9d,BYTE PTR [r8]
    730a040febf2:	mov    r8,r9
    730a040febf5:	shl    r8,0x10
    730a040febf9:	or     r14,r8
    730a040febfc:	mov    r8,QWORD PTR [r12+0x40]
    730a040fec01:	add    r8,0x29
    730a040fec05:	movzx  r9d,BYTE PTR [r8]
    730a040fec09:	mov    r8,r9
    730a040fec0c:	shl    r8,0x10
    730a040fec10:	or     r15,r8
    730a040fec13:	mov    r8,QWORD PTR [r12+0x40]
    730a040fec18:	add    r8,0x2a
    730a040fec1c:	movzx  r9d,BYTE PTR [r8]
    730a040fec20:	mov    r8,r9
    730a040fec23:	shl    r8,0x10
    730a040fec27:	or     rbp,r8
    730a040fec2a:	mov    r8,QWORD PTR [r12+0x40]
    730a040fec2f:	add    r8,0x2b
    730a040fec33:	movzx  r9d,BYTE PTR [r8]
    730a040fec37:	mov    r8,r9
    730a040fec3a:	shl    r8,0x10
    730a040fec3e:	or     r13,r8
    730a040fec41:	mov    r8,QWORD PTR [r12+0x40]
    730a040fec46:	add    r8,0x2c
    730a040fec4a:	movzx  r9d,BYTE PTR [r8]
    730a040fec4e:	mov    r8,r9
    730a040fec51:	shl    r8,0x18
    730a040fec55:	or     r14,r8
    730a040fec58:	mov    r8,QWORD PTR [r12+0x40]
    730a040fec5d:	add    r8,0x2d
    730a040fec61:	movzx  r9d,BYTE PTR [r8]
    730a040fec65:	mov    r8,r9
    730a040fec68:	shl    r8,0x18
    730a040fec6c:	or     r15,r8
    730a040fec6f:	mov    r8,QWORD PTR [r12+0x40]
    730a040fec74:	add    r8,0x2e
    730a040fec78:	movzx  r9d,BYTE PTR [r8]
    730a040fec7c:	mov    r8,r9
    730a040fec7f:	shl    r8,0x18
    730a040fec83:	or     rbp,r8
    730a040fec86:	mov    r8,QWORD PTR [r12+0x40]
    730a040fec8b:	add    r8,0x2f
    730a040fec8f:	movzx  r9d,BYTE PTR [r8]
    730a040fec93:	mov    r8,r9
    730a040fec96:	shl    r8,0x18
    730a040fec9a:	or     r13,r8
    730a040fec9d:	mov    r8,QWORD PTR [r12+0x40]
    730a040feca2:	add    r8,0x30
    730a040feca6:	movzx  r9d,BYTE PTR [r8]
    730a040fecaa:	mov    r8,r9
    730a040fecad:	shl    r8,0x20
    730a040fecb1:	or     r14,r8
    730a040fecb4:	mov    r8,QWORD PTR [r12+0x40]
    730a040fecb9:	add    r8,0x31
    730a040fecbd:	movzx  r9d,BYTE PTR [r8]
    730a040fecc1:	mov    r8,r9
    730a040fecc4:	shl    r8,0x20
    730a040fecc8:	or     r15,r8
    730a040feccb:	mov    r8,QWORD PTR [r12+0x40]
    730a040fecd0:	add    r8,0x32
    730a040fecd4:	movzx  r9d,BYTE PTR [r8]
    730a040fecd8:	mov    r8,r9
    730a040fecdb:	shl    r8,0x20
    730a040fecdf:	or     rbp,r8
    730a040fece2:	mov    r8,QWORD PTR [r12+0x40]
    730a040fece7:	add    r8,0x33
    730a040feceb:	movzx  r9d,BYTE PTR [r8]
    730a040fecef:	mov    r8,r9
    730a040fecf2:	shl    r8,0x20
    730a040fecf6:	or     r13,r8
    730a040fecf9:	mov    r8,QWORD PTR [r12+0x40]
    730a040fecfe:	add    r8,0x34
    730a040fed02:	movzx  r9d,BYTE PTR [r8]
    730a040fed06:	mov    r8,r9
    730a040fed09:	shl    r8,0x28
    730a040fed0d:	or     r14,r8
    730a040fed10:	mov    r8,QWORD PTR [r12+0x40]
    730a040fed15:	add    r8,0x35
    730a040fed19:	movzx  r9d,BYTE PTR [r8]
    730a040fed1d:	mov    r8,r9
    730a040fed20:	shl    r8,0x28
    730a040fed24:	or     r15,r8
    730a040fed27:	mov    r8,QWORD PTR [r12+0x40]
    730a040fed2c:	add    r8,0x36
    730a040fed30:	movzx  r9d,BYTE PTR [r8]
    730a040fed34:	mov    r8,r9
    730a040fed37:	shl    r8,0x28
    730a040fed3b:	or     rbp,r8
    730a040fed3e:	mov    r8,QWORD PTR [r12+0x40]
    730a040fed43:	add    r8,0x37
    730a040fed47:	movzx  r9d,BYTE PTR [r8]
    730a040fed4b:	mov    r8,r9
    730a040fed4e:	shl    r8,0x28
    730a040fed52:	or     r13,r8
    730a040fed55:	mov    r8,QWORD PTR [r12+0x40]
    730a040fed5a:	add    r8,0x38
    730a040fed5e:	movzx  r9d,BYTE PTR [r8]
    730a040fed62:	mov    r8,r9
    730a040fed65:	shl    r8,0x30
    730a040fed69:	or     r14,r8
    730a040fed6c:	mov    r8,QWORD PTR [r12+0x40]
    730a040fed71:	add    r8,0x39
    730a040fed75:	movzx  r9d,BYTE PTR [r8]
    730a040fed79:	mov    r8,r9
    730a040fed7c:	shl    r8,0x30
    730a040fed80:	or     r15,r8
    730a040fed83:	mov    r8,QWORD PTR [r12+0x40]
    730a040fed88:	add    r8,0x3a
    730a040fed8c:	movzx  r9d,BYTE PTR [r8]
    730a040fed90:	mov    r8,r9
    730a040fed93:	shl    r8,0x30
    730a040fed97:	or     rbp,r8
    730a040fed9a:	mov    r8,QWORD PTR [r12+0x40]
    730a040fed9f:	add    r8,0x3b
    730a040feda3:	movzx  r9d,BYTE PTR [r8]
    730a040feda7:	mov    r8,r9
    730a040fedaa:	shl    r8,0x30
    730a040fedae:	or     r13,r8
    730a040fedb1:	mov    r8,QWORD PTR [r12+0x40]
    730a040fedb6:	add    r8,0x3c
    730a040fedba:	movzx  r9d,BYTE PTR [r8]
    730a040fedbe:	mov    r8,r9
    730a040fedc1:	shl    r8,0x38
    730a040fedc5:	or     r14,r8
    730a040fedc8:	mov    r8,QWORD PTR [r12+0x40]
    730a040fedcd:	add    r8,0x3d
    730a040fedd1:	movzx  r9d,BYTE PTR [r8]
    730a040fedd5:	mov    r8,r9
    730a040fedd8:	shl    r8,0x38
    730a040feddc:	or     r15,r8
    730a040feddf:	mov    r8,QWORD PTR [r12+0x40]
    730a040fede4:	add    r8,0x3e
    730a040fede8:	movzx  r9d,BYTE PTR [r8]
    730a040fedec:	mov    r8,r9
    730a040fedef:	shl    r8,0x38
    730a040fedf3:	or     rbp,r8
    730a040fedf6:	mov    r8,QWORD PTR [r12+0x40]
    730a040fedfb:	add    r8,0x3f
    730a040fedff:	movzx  r9d,BYTE PTR [r8]
    730a040fee03:	mov    r8,r9
    730a040fee06:	shl    r8,0x38
    730a040fee0a:	mov    rax,r13
    730a040fee0d:	or     rax,r8
    730a040fee10:	mov    QWORD PTR [rsp+0x40],rax
    730a040fee15:	mov    r8d,0x0
    730a040fee1b:	mov    QWORD PTR [r12+0x58],r8
    730a040fee20:	mov    r8d,0x0
    730a040fee26:	mov    r9,QWORD PTR [rsp+0x38]
    730a040fee2b:	and    r9,0xff
    730a040fee32:	and    r9,0xffff
    730a040fee39:	mov    r13,r8
    730a040fee3c:	or     r13,r9
    730a040fee3f:	mov    r9,QWORD PTR [rsp+0x38]
    730a040fee44:	shr    r9,0x8
    730a040fee48:	and    r9,0xff
    730a040fee4f:	and    r9,0xffff
    730a040fee56:	shl    r9,0x10
    730a040fee5a:	or     r13,r9
    730a040fee5d:	mov    r9,QWORD PTR [rsp+0x38]
    730a040fee62:	shr    r9,0x10
    730a040fee66:	and    r9,0xff
    730a040fee6d:	and    r9,0xffff
    730a040fee74:	shl    r9,0x20
    730a040fee78:	or     r13,r9
    730a040fee7b:	mov    r9,QWORD PTR [rsp+0x38]
    730a040fee80:	shr    r9,0x18
    730a040fee84:	and    r9,0xff
    730a040fee8b:	and    r9,0xffff
    730a040fee92:	shl    r9,0x30
    730a040fee96:	or     r13,r9
    730a040fee99:	mov    r9,QWORD PTR [rsp+0x38]
    730a040fee9e:	shr    r9,0x20
    730a040feea2:	and    r9,0xff
    730a040feea9:	and    r9,0xffff
    730a040feeb0:	or     r8,r9
    730a040feeb3:	mov    r9,QWORD PTR [rsp+0x38]
    730a040feeb8:	shr    r9,0x28
    730a040feebc:	and    r9,0xff
    730a040feec3:	and    r9,0xffff
    730a040feeca:	shl    r9,0x10
    730a040feece:	or     r8,r9
    730a040feed1:	mov    r9,QWORD PTR [rsp+0x38]
    730a040feed6:	shr    r9,0x30
    730a040feeda:	and    r9,0xff
    730a040feee1:	and    r9,0xffff
    730a040feee8:	shl    r9,0x20
    730a040feeec:	or     r8,r9
    730a040feeef:	mov    r9,QWORD PTR [rsp+0x38]
    730a040feef4:	shr    r9,0x38
    730a040feef8:	and    r9,0xff
    730a040feeff:	and    r9,0xffff
    730a040fef06:	shl    r9,0x30
    730a040fef0a:	or     r8,r9
    730a040fef0d:	mov    QWORD PTR [r12+0x150],r13
    730a040fef15:	mov    QWORD PTR [r12+0x158],r8
    730a040fef1d:	mov    r13d,0x0
    730a040fef23:	mov    r8,QWORD PTR [rsp+0x30]
    730a040fef28:	and    r8,0xff
    730a040fef2f:	and    r8,0xffff
    730a040fef36:	mov    r9,r13
    730a040fef39:	or     r9,r8
    730a040fef3c:	mov    r8,QWORD PTR [rsp+0x30]
    730a040fef41:	shr    r8,0x8
    730a040fef45:	and    r8,0xff
    730a040fef4c:	and    r8,0xffff
    730a040fef53:	shl    r8,0x10
    730a040fef57:	or     r9,r8
    730a040fef5a:	mov    r8,QWORD PTR [rsp+0x30]
    730a040fef5f:	shr    r8,0x10
    730a040fef63:	and    r8,0xff
    730a040fef6a:	and    r8,0xffff
    730a040fef71:	shl    r8,0x20
    730a040fef75:	or     r9,r8
    730a040fef78:	mov    r8,QWORD PTR [rsp+0x30]
    730a040fef7d:	shr    r8,0x18
    730a040fef81:	and    r8,0xff
    730a040fef88:	and    r8,0xffff
    730a040fef8f:	shl    r8,0x30
    730a040fef93:	mov    rax,r9
    730a040fef96:	or     rax,r8
    730a040fef99:	mov    QWORD PTR [rsp+0x50],rax
    730a040fef9e:	mov    r8,QWORD PTR [rsp+0x30]
    730a040fefa3:	shr    r8,0x20
    730a040fefa7:	and    r8,0xff
    730a040fefae:	and    r8,0xffff
    730a040fefb5:	or     r13,r8
    730a040fefb8:	mov    r8,QWORD PTR [rsp+0x30]
    730a040fefbd:	shr    r8,0x28
    730a040fefc1:	and    r8,0xff
    730a040fefc8:	and    r8,0xffff
    730a040fefcf:	shl    r8,0x10
    730a040fefd3:	or     r13,r8
    730a040fefd6:	mov    r8,QWORD PTR [rsp+0x30]
    730a040fefdb:	shr    r8,0x30
    730a040fefdf:	and    r8,0xff
    730a040fefe6:	and    r8,0xffff
    730a040fefed:	shl    r8,0x20
    730a040feff1:	or     r13,r8
    730a040feff4:	mov    r8,QWORD PTR [rsp+0x30]
    730a040feff9:	shr    r8,0x38
    730a040feffd:	and    r8,0xff
    730a040ff004:	and    r8,0xffff
    730a040ff00b:	shl    r8,0x30
    730a040ff00f:	mov    rax,r13
    730a040ff012:	or     rax,r8
    730a040ff015:	mov    QWORD PTR [rsp+0x48],rax
    730a040ff01a:	mov    r8d,0x0
    730a040ff020:	mov    r13,QWORD PTR [rsp+0x28]
    730a040ff025:	and    r13,0xff
    730a040ff02c:	and    r13,0xffff
    730a040ff033:	mov    r9,r8
    730a040ff036:	or     r9,r13
    730a040ff039:	mov    r13,QWORD PTR [rsp+0x28]
    730a040ff03e:	shr    r13,0x8
    730a040ff042:	and    r13,0xff
    730a040ff049:	and    r13,0xffff
    730a040ff050:	shl    r13,0x10
    730a040ff054:	or     r9,r13
    730a040ff057:	mov    r13,QWORD PTR [rsp+0x28]
    730a040ff05c:	shr    r13,0x10
    730a040ff060:	and    r13,0xff
    730a040ff067:	and    r13,0xffff
    730a040ff06e:	shl    r13,0x20
    730a040ff072:	or     r9,r13
    730a040ff075:	mov    r13,QWORD PTR [rsp+0x28]
    730a040ff07a:	shr    r13,0x18
    730a040ff07e:	and    r13,0xff
    730a040ff085:	and    r13,0xffff
    730a040ff08c:	shl    r13,0x30
    730a040ff090:	mov    rax,r9
    730a040ff093:	or     rax,r13
    730a040ff096:	mov    QWORD PTR [rsp+0x58],rax
    730a040ff09b:	mov    r13,QWORD PTR [rsp+0x28]
    730a040ff0a0:	shr    r13,0x20
    730a040ff0a4:	and    r13,0xff
    730a040ff0ab:	and    r13,0xffff
    730a040ff0b2:	or     r8,r13
    730a040ff0b5:	mov    r13,QWORD PTR [rsp+0x28]
    730a040ff0ba:	shr    r13,0x28
    730a040ff0be:	and    r13,0xff
    730a040ff0c5:	and    r13,0xffff
    730a040ff0cc:	shl    r13,0x10
    730a040ff0d0:	or     r8,r13
    730a040ff0d3:	mov    r13,QWORD PTR [rsp+0x28]
    730a040ff0d8:	shr    r13,0x30
    730a040ff0dc:	and    r13,0xff
    730a040ff0e3:	and    r13,0xffff
    730a040ff0ea:	shl    r13,0x20
    730a040ff0ee:	or     r8,r13
    730a040ff0f1:	mov    r13,QWORD PTR [rsp+0x28]
    730a040ff0f6:	shr    r13,0x38
    730a040ff0fa:	and    r13,0xff
    730a040ff101:	and    r13,0xffff
    730a040ff108:	shl    r13,0x30
    730a040ff10c:	mov    rax,r8
    730a040ff10f:	or     rax,r13
    730a040ff112:	mov    QWORD PTR [rsp+0x60],rax
    730a040ff117:	mov    r13d,0x0
    730a040ff11d:	mov    r9,r14
    730a040ff120:	and    r9,0xff
    730a040ff127:	and    r9,0xffff
    730a040ff12e:	mov    r8,r13
    730a040ff131:	or     r8,r9
    730a040ff134:	mov    r9,r14
    730a040ff137:	shr    r9,0x8
    730a040ff13b:	and    r9,0xff
    730a040ff142:	and    r9,0xffff
    730a040ff149:	shl    r9,0x10
    730a040ff14d:	or     r8,r9
    730a040ff150:	mov    r9,r14
    730a040ff153:	shr    r9,0x10
    730a040ff157:	and    r9,0xff
    730a040ff15e:	and    r9,0xffff
    730a040ff165:	shl    r9,0x20
    730a040ff169:	or     r8,r9
    730a040ff16c:	mov    r9,r14
    730a040ff16f:	shr    r9,0x18
    730a040ff173:	and    r9,0xff
    730a040ff17a:	and    r9,0xffff
    730a040ff181:	shl    r9,0x30
    730a040ff185:	mov    rax,r8
    730a040ff188:	or     rax,r9
    730a040ff18b:	mov    QWORD PTR [rsp+0x68],rax
    730a040ff190:	mov    r9,r14
    730a040ff193:	shr    r9,0x20
    730a040ff197:	and    r9,0xff
    730a040ff19e:	and    r9,0xffff
    730a040ff1a5:	or     r13,r9
    730a040ff1a8:	mov    r9,r14
    730a040ff1ab:	shr    r9,0x28
    730a040ff1af:	and    r9,0xff
    730a040ff1b6:	and    r9,0xffff
    730a040ff1bd:	shl    r9,0x10
    730a040ff1c1:	or     r13,r9
    730a040ff1c4:	mov    r9,r14
    730a040ff1c7:	shr    r9,0x30
    730a040ff1cb:	and    r9,0xff
    730a040ff1d2:	and    r9,0xffff
    730a040ff1d9:	shl    r9,0x20
    730a040ff1dd:	or     r13,r9
    730a040ff1e0:	shr    r14,0x38
    730a040ff1e4:	and    r14,0xff
    730a040ff1eb:	and    r14,0xffff
    730a040ff1f2:	shl    r14,0x30
    730a040ff1f6:	or     r13,r14
    730a040ff1f9:	mov    r14d,0x0
    730a040ff1ff:	mov    r9,r15
    730a040ff202:	and    r9,0xff
    730a040ff209:	and    r9,0xffff
    730a040ff210:	mov    r8,r14
    730a040ff213:	or     r8,r9
    730a040ff216:	mov    r9,r15
    730a040ff219:	shr    r9,0x8
    730a040ff21d:	and    r9,0xff
    730a040ff224:	and    r9,0xffff
    730a040ff22b:	shl    r9,0x10
    730a040ff22f:	or     r8,r9
    730a040ff232:	mov    r9,r15
    730a040ff235:	shr    r9,0x10
    730a040ff239:	and    r9,0xff
    730a040ff240:	and    r9,0xffff
    730a040ff247:	shl    r9,0x20
    730a040ff24b:	or     r8,r9
    730a040ff24e:	mov    r9,r15
    730a040ff251:	shr    r9,0x18
    730a040ff255:	and    r9,0xff
    730a040ff25c:	and    r9,0xffff
    730a040ff263:	shl    r9,0x30
    730a040ff267:	or     r8,r9
    730a040ff26a:	mov    r9,r15
    730a040ff26d:	shr    r9,0x20
    730a040ff271:	and    r9,0xff
    730a040ff278:	and    r9,0xffff
    730a040ff27f:	or     r14,r9
    730a040ff282:	mov    r9,r15
    730a040ff285:	shr    r9,0x28
    730a040ff289:	and    r9,0xff
    730a040ff290:	and    r9,0xffff
    730a040ff297:	shl    r9,0x10
    730a040ff29b:	or     r14,r9
    730a040ff29e:	mov    r9,r15
    730a040ff2a1:	shr    r9,0x30
    730a040ff2a5:	and    r9,0xff
    730a040ff2ac:	and    r9,0xffff
    730a040ff2b3:	shl    r9,0x20
    730a040ff2b7:	or     r14,r9
    730a040ff2ba:	shr    r15,0x38
    730a040ff2be:	and    r15,0xff
    730a040ff2c5:	and    r15,0xffff
    730a040ff2cc:	shl    r15,0x30
    730a040ff2d0:	or     r14,r15
    730a040ff2d3:	mov    QWORD PTR [r12+0x210],r8
    730a040ff2db:	mov    QWORD PTR [r12+0x218],r14
    730a040ff2e3:	mov    r14d,0x0
    730a040ff2e9:	mov    r15,rbp
    730a040ff2ec:	and    r15,0xff
    730a040ff2f3:	and    r15,0xffff
    730a040ff2fa:	mov    r8,r14
    730a040ff2fd:	or     r8,r15
    730a040ff300:	mov    r15,rbp
    730a040ff303:	shr    r15,0x8
    730a040ff307:	and    r15,0xff
    730a040ff30e:	and    r15,0xffff
    730a040ff315:	shl    r15,0x10
    730a040ff319:	or     r8,r15
    730a040ff31c:	mov    r15,rbp
    730a040ff31f:	shr    r15,0x10
    730a040ff323:	and    r15,0xff
    730a040ff32a:	and    r15,0xffff
    730a040ff331:	shl    r15,0x20
    730a040ff335:	or     r8,r15
    730a040ff338:	mov    r15,rbp
    730a040ff33b:	shr    r15,0x18
    730a040ff33f:	and    r15,0xff
    730a040ff346:	and    r15,0xffff
    730a040ff34d:	shl    r15,0x30
    730a040ff351:	or     r8,r15
    730a040ff354:	mov    r15,rbp
    730a040ff357:	shr    r15,0x20
    730a040ff35b:	and    r15,0xff
    730a040ff362:	and    r15,0xffff
    730a040ff369:	or     r14,r15
    730a040ff36c:	mov    r15,rbp
    730a040ff36f:	shr    r15,0x28
    730a040ff373:	and    r15,0xff
    730a040ff37a:	and    r15,0xffff
    730a040ff381:	shl    r15,0x10
    730a040ff385:	or     r14,r15
    730a040ff388:	mov    r15,rbp
    730a040ff38b:	shr    r15,0x30
    730a040ff38f:	and    r15,0xff
    730a040ff396:	and    r15,0xffff
    730a040ff39d:	shl    r15,0x20
    730a040ff3a1:	or     r14,r15
    730a040ff3a4:	shr    rbp,0x38
    730a040ff3a8:	and    rbp,0xff
    730a040ff3af:	and    rbp,0xffff
    730a040ff3b6:	shl    rbp,0x30
    730a040ff3ba:	or     r14,rbp
    730a040ff3bd:	mov    r15d,0x0
    730a040ff3c3:	mov    rbp,QWORD PTR [rsp+0x20]
    730a040ff3c8:	and    rbp,0xff
    730a040ff3cf:	and    rbp,0xffff
    730a040ff3d6:	mov    r9,r15
    730a040ff3d9:	or     r9,rbp
    730a040ff3dc:	mov    rbp,QWORD PTR [rsp+0x20]
    730a040ff3e1:	shr    rbp,0x8
    730a040ff3e5:	and    rbp,0xff
    730a040ff3ec:	and    rbp,0xffff
    730a040ff3f3:	shl    rbp,0x10
    730a040ff3f7:	or     r9,rbp
    730a040ff3fa:	mov    rbp,QWORD PTR [rsp+0x20]
    730a040ff3ff:	shr    rbp,0x10
    730a040ff403:	and    rbp,0xff
    730a040ff40a:	and    rbp,0xffff
    730a040ff411:	shl    rbp,0x20
    730a040ff415:	or     r9,rbp
    730a040ff418:	mov    rbp,QWORD PTR [rsp+0x20]
    730a040ff41d:	shr    rbp,0x18
    730a040ff421:	and    rbp,0xff
    730a040ff428:	and    rbp,0xffff
    730a040ff42f:	shl    rbp,0x30
    730a040ff433:	mov    rax,r9
    730a040ff436:	or     rax,rbp
    730a040ff439:	mov    QWORD PTR [rsp+0x78],rax
    730a040ff43e:	mov    rbp,QWORD PTR [rsp+0x20]
    730a040ff443:	shr    rbp,0x20
    730a040ff447:	and    rbp,0xff
    730a040ff44e:	and    rbp,0xffff
    730a040ff455:	or     r15,rbp
    730a040ff458:	mov    rbp,QWORD PTR [rsp+0x20]
    730a040ff45d:	shr    rbp,0x28
    730a040ff461:	and    rbp,0xff
    730a040ff468:	and    rbp,0xffff
    730a040ff46f:	shl    rbp,0x10
    730a040ff473:	or     r15,rbp
    730a040ff476:	mov    rbp,QWORD PTR [rsp+0x20]
    730a040ff47b:	shr    rbp,0x30
    730a040ff47f:	and    rbp,0xff
    730a040ff486:	and    rbp,0xffff
    730a040ff48d:	shl    rbp,0x20
    730a040ff491:	or     r15,rbp
    730a040ff494:	mov    rbp,QWORD PTR [rsp+0x20]
    730a040ff499:	shr    rbp,0x38
    730a040ff49d:	and    rbp,0xff
    730a040ff4a4:	and    rbp,0xffff
    730a040ff4ab:	shl    rbp,0x30
    730a040ff4af:	mov    rax,r15
    730a040ff4b2:	or     rax,rbp
    730a040ff4b5:	mov    QWORD PTR [rsp+0x70],rax
    730a040ff4ba:	mov    rax,QWORD PTR [rsp+0x78]
    730a040ff4bf:	mov    QWORD PTR [r12+0x250],rax
    730a040ff4c7:	mov    rax,QWORD PTR [rsp+0x70]
    730a040ff4cc:	mov    QWORD PTR [r12+0x258],rax
    730a040ff4d4:	mov    ebp,0x0
    730a040ff4d9:	mov    r15,QWORD PTR [rsp+0x40]
    730a040ff4de:	and    r15,0xff
    730a040ff4e5:	and    r15,0xffff
    730a040ff4ec:	mov    r9,rbp
    730a040ff4ef:	or     r9,r15
    730a040ff4f2:	mov    r15,QWORD PTR [rsp+0x40]
    730a040ff4f7:	shr    r15,0x8
    730a040ff4fb:	and    r15,0xff
    730a040ff502:	and    r15,0xffff
    730a040ff509:	shl    r15,0x10
    730a040ff50d:	or     r9,r15
    730a040ff510:	mov    r15,QWORD PTR [rsp+0x40]
    730a040ff515:	shr    r15,0x10
    730a040ff519:	and    r15,0xff
    730a040ff520:	and    r15,0xffff
    730a040ff527:	shl    r15,0x20
    730a040ff52b:	or     r9,r15
    730a040ff52e:	mov    r15,QWORD PTR [rsp+0x40]
    730a040ff533:	shr    r15,0x18
    730a040ff537:	and    r15,0xff
    730a040ff53e:	and    r15,0xffff
    730a040ff545:	shl    r15,0x30
    730a040ff549:	mov    rax,r9
    730a040ff54c:	or     rax,r15
    730a040ff54f:	mov    QWORD PTR [rsp+0x80],rax
    730a040ff557:	mov    r15,QWORD PTR [rsp+0x40]
    730a040ff55c:	shr    r15,0x20
    730a040ff560:	and    r15,0xff
    730a040ff567:	and    r15,0xffff
    730a040ff56e:	or     rbp,r15
    730a040ff571:	mov    r15,QWORD PTR [rsp+0x40]
    730a040ff576:	shr    r15,0x28
    730a040ff57a:	and    r15,0xff
    730a040ff581:	and    r15,0xffff
    730a040ff588:	shl    r15,0x10
    730a040ff58c:	or     rbp,r15
    730a040ff58f:	mov    r15,QWORD PTR [rsp+0x40]
    730a040ff594:	shr    r15,0x30
    730a040ff598:	and    r15,0xff
    730a040ff59f:	and    r15,0xffff
    730a040ff5a6:	shl    r15,0x20
    730a040ff5aa:	or     rbp,r15
    730a040ff5ad:	mov    r15,QWORD PTR [rsp+0x40]
    730a040ff5b2:	shr    r15,0x38
    730a040ff5b6:	and    r15,0xff
    730a040ff5bd:	and    r15,0xffff
    730a040ff5c4:	shl    r15,0x30
    730a040ff5c8:	mov    rax,rbp
    730a040ff5cb:	or     rax,r15
    730a040ff5ce:	mov    QWORD PTR [rsp+0x88],rax
    730a040ff5d6:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    730a040ff5e0:	pxor   xmm0,xmm0
    730a040ff5e4:	movdqa xmm3,xmm0
    730a040ff5e8:	movdqa xmm0,xmm2
    730a040ff5ec:	movdqa xmm1,xmm3
    730a040ff5f0:	punpcklwd xmm0,xmm1
    730a040ff5f4:	movdqa xmm4,xmm0
    730a040ff5f8:	movdqa xmm0,xmm4
    730a040ff5fc:	pslld  xmm0,0x10
    730a040ff601:	movdqa xmm3,xmm0
    730a040ff605:	mov    r15d,0x0
    730a040ff60b:	mov    r9,QWORD PTR [rsp+0x50]
    730a040ff610:	and    r9,0xffff
    730a040ff617:	shl    r9,0x8
    730a040ff61b:	mov    ecx,0xffffffff
    730a040ff620:	and    r9,rcx
    730a040ff623:	mov    rbp,r15
    730a040ff626:	or     rbp,r9
    730a040ff629:	mov    r9,QWORD PTR [rsp+0x50]
    730a040ff62e:	shr    r9,0x10
    730a040ff632:	and    r9,0xffff
    730a040ff639:	shl    r9,0x8
    730a040ff63d:	mov    ecx,0xffffffff
    730a040ff642:	and    r9,rcx
    730a040ff645:	shl    r9,0x20
    730a040ff649:	or     rbp,r9
    730a040ff64c:	mov    r9,QWORD PTR [rsp+0x50]
    730a040ff651:	shr    r9,0x20
    730a040ff655:	and    r9,0xffff
    730a040ff65c:	shl    r9,0x8
    730a040ff660:	mov    ecx,0xffffffff
    730a040ff665:	and    r9,rcx
    730a040ff668:	or     r15,r9
    730a040ff66b:	mov    r9,QWORD PTR [rsp+0x50]
    730a040ff670:	shr    r9,0x30
    730a040ff674:	and    r9,0xffff
    730a040ff67b:	shl    r9,0x8
    730a040ff67f:	mov    ecx,0xffffffff
    730a040ff684:	and    r9,rcx
    730a040ff687:	shl    r9,0x20
    730a040ff68b:	or     r15,r9
    730a040ff68e:	mov    QWORD PTR [r12+0x240],rbp
    730a040ff696:	mov    QWORD PTR [r12+0x248],r15
    730a040ff69e:	mov    r15d,0x0
    730a040ff6a4:	mov    rbp,QWORD PTR [rsp+0x60]
    730a040ff6a9:	and    rbp,0xffff
    730a040ff6b0:	mov    ecx,0xffffffff
    730a040ff6b5:	and    rbp,rcx
    730a040ff6b8:	mov    r9,r15
    730a040ff6bb:	or     r9,rbp
    730a040ff6be:	mov    rbp,QWORD PTR [rsp+0x60]
    730a040ff6c3:	shr    rbp,0x10
    730a040ff6c7:	and    rbp,0xffff
    730a040ff6ce:	mov    ecx,0xffffffff
    730a040ff6d3:	and    rbp,rcx
    730a040ff6d6:	shl    rbp,0x20
    730a040ff6da:	or     r9,rbp
    730a040ff6dd:	mov    rbp,QWORD PTR [rsp+0x60]
    730a040ff6e2:	shr    rbp,0x20
    730a040ff6e6:	and    rbp,0xffff
    730a040ff6ed:	mov    ecx,0xffffffff
    730a040ff6f2:	and    rbp,rcx
    730a040ff6f5:	or     r15,rbp
    730a040ff6f8:	mov    rbp,QWORD PTR [rsp+0x60]
    730a040ff6fd:	shr    rbp,0x30
    730a040ff701:	and    rbp,0xffff
    730a040ff708:	mov    ecx,0xffffffff
    730a040ff70d:	and    rbp,rcx
    730a040ff710:	shl    rbp,0x20
    730a040ff714:	or     r15,rbp
    730a040ff717:	mov    QWORD PTR [r12+0x260],r9
    730a040ff71f:	mov    QWORD PTR [r12+0x268],r15
    730a040ff727:	mov    r15d,0x0
    730a040ff72d:	mov    rbp,r13
    730a040ff730:	and    rbp,0xffff
    730a040ff737:	mov    ecx,0xffffffff
    730a040ff73c:	and    rbp,rcx
    730a040ff73f:	mov    r9,r15
    730a040ff742:	or     r9,rbp
    730a040ff745:	mov    rbp,r13
    730a040ff748:	shr    rbp,0x10
    730a040ff74c:	and    rbp,0xffff
    730a040ff753:	mov    ecx,0xffffffff
    730a040ff758:	and    rbp,rcx
    730a040ff75b:	shl    rbp,0x20
    730a040ff75f:	or     r9,rbp
    730a040ff762:	mov    rbp,r13
    730a040ff765:	shr    rbp,0x20
    730a040ff769:	and    rbp,0xffff
    730a040ff770:	mov    ecx,0xffffffff
    730a040ff775:	and    rbp,rcx
    730a040ff778:	or     r15,rbp
    730a040ff77b:	shr    r13,0x30
    730a040ff77f:	and    r13,0xffff
    730a040ff786:	mov    ecx,0xffffffff
    730a040ff78b:	and    r13,rcx
    730a040ff78e:	shl    r13,0x20
    730a040ff792:	or     r15,r13
    730a040ff795:	mov    QWORD PTR [r12+0x270],r9
    730a040ff79d:	mov    QWORD PTR [r12+0x278],r15
    730a040ff7a5:	mov    r13d,0x0
    730a040ff7ab:	mov    r15,QWORD PTR [rsp+0x58]
    730a040ff7b0:	and    r15,0xffff
    730a040ff7b7:	mov    ecx,0xffffffff
    730a040ff7bc:	and    r15,rcx
    730a040ff7bf:	mov    rbp,r13
    730a040ff7c2:	or     rbp,r15
    730a040ff7c5:	mov    r15,QWORD PTR [rsp+0x58]
    730a040ff7ca:	shr    r15,0x10
    730a040ff7ce:	and    r15,0xffff
    730a040ff7d5:	mov    ecx,0xffffffff
    730a040ff7da:	and    r15,rcx
    730a040ff7dd:	shl    r15,0x20
    730a040ff7e1:	or     rbp,r15
    730a040ff7e4:	mov    r15,QWORD PTR [rsp+0x58]
    730a040ff7e9:	shr    r15,0x20
    730a040ff7ed:	and    r15,0xffff
    730a040ff7f4:	mov    ecx,0xffffffff
    730a040ff7f9:	and    r15,rcx
    730a040ff7fc:	or     r13,r15
    730a040ff7ff:	mov    r15,QWORD PTR [rsp+0x58]
    730a040ff804:	shr    r15,0x30
    730a040ff808:	and    r15,0xffff
    730a040ff80f:	mov    ecx,0xffffffff
    730a040ff814:	and    r15,rcx
    730a040ff817:	shl    r15,0x20
    730a040ff81b:	or     r13,r15
    730a040ff81e:	mov    QWORD PTR [r12+0x170],rbp
    730a040ff826:	mov    QWORD PTR [r12+0x178],r13
    730a040ff82e:	movdqu xmm4,XMMWORD PTR [r12+0x210]
    730a040ff838:	pxor   xmm0,xmm0
    730a040ff83c:	movdqa xmm5,xmm0
    730a040ff840:	movdqa xmm0,xmm4
    730a040ff844:	movdqa xmm1,xmm5
    730a040ff848:	punpckhwd xmm0,xmm1
    730a040ff84c:	movdqa xmm6,xmm0
    730a040ff850:	movdqa xmm0,xmm6
    730a040ff854:	pslld  xmm0,0x10
    730a040ff859:	movdqa xmm5,xmm0
    730a040ff85d:	movdqu XMMWORD PTR [r12+0x280],xmm5
    730a040ff867:	mov    r13d,0x0
    730a040ff86d:	mov    r15,QWORD PTR [rsp+0x68]
    730a040ff872:	and    r15,0xffff
    730a040ff879:	mov    ecx,0xffffffff
    730a040ff87e:	and    r15,rcx
    730a040ff881:	mov    rbp,r13
    730a040ff884:	or     rbp,r15
    730a040ff887:	mov    r15,QWORD PTR [rsp+0x68]
    730a040ff88c:	shr    r15,0x10
    730a040ff890:	and    r15,0xffff
    730a040ff897:	mov    ecx,0xffffffff
    730a040ff89c:	and    r15,rcx
    730a040ff89f:	shl    r15,0x20
    730a040ff8a3:	or     rbp,r15
    730a040ff8a6:	mov    r15,QWORD PTR [rsp+0x68]
    730a040ff8ab:	shr    r15,0x20
    730a040ff8af:	and    r15,0xffff
    730a040ff8b6:	mov    ecx,0xffffffff
    730a040ff8bb:	and    r15,rcx
    730a040ff8be:	or     r13,r15
    730a040ff8c1:	mov    r15,QWORD PTR [rsp+0x68]
    730a040ff8c6:	shr    r15,0x30
    730a040ff8ca:	and    r15,0xffff
    730a040ff8d1:	mov    ecx,0xffffffff
    730a040ff8d6:	and    r15,rcx
    730a040ff8d9:	shl    r15,0x20
    730a040ff8dd:	or     r13,r15
    730a040ff8e0:	mov    QWORD PTR [r12+0x180],rbp
    730a040ff8e8:	mov    QWORD PTR [r12+0x188],r13
    730a040ff8f0:	pxor   xmm0,xmm0
    730a040ff8f4:	movdqa xmm6,xmm0
    730a040ff8f8:	movdqa xmm0,xmm4
    730a040ff8fc:	movdqa xmm1,xmm6
    730a040ff900:	punpcklwd xmm0,xmm1
    730a040ff904:	movdqa xmm7,xmm0
    730a040ff908:	movdqa xmm0,xmm7
    730a040ff90c:	pslld  xmm0,0x10
    730a040ff911:	movdqa xmm4,xmm0
    730a040ff915:	pxor   xmm0,xmm0
    730a040ff919:	movdqa xmm6,xmm0
    730a040ff91d:	movdqa xmm0,xmm2
    730a040ff921:	movdqa xmm1,xmm6
    730a040ff925:	punpckhwd xmm0,xmm1
    730a040ff929:	movdqa xmm7,xmm0
    730a040ff92d:	movdqa xmm0,xmm7
    730a040ff931:	pslld  xmm0,0x10
    730a040ff936:	movdqa xmm2,xmm0
    730a040ff93a:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    730a040ff944:	movdqa xmm1,xmm6
    730a040ff948:	por    xmm3,xmm1
    730a040ff94c:	movdqu XMMWORD PTR [r12+0x230],xmm3
    730a040ff956:	mov    r13d,0x0
    730a040ff95c:	mov    r15,r14
    730a040ff95f:	and    r15,0xffff
    730a040ff966:	shl    r15,0x8
    730a040ff96a:	mov    ecx,0xffffffff
    730a040ff96f:	and    r15,rcx
    730a040ff972:	mov    rbp,r13
    730a040ff975:	or     rbp,r15
    730a040ff978:	mov    r15,r14
    730a040ff97b:	shr    r15,0x10
    730a040ff97f:	and    r15,0xffff
    730a040ff986:	shl    r15,0x8
    730a040ff98a:	mov    ecx,0xffffffff
    730a040ff98f:	and    r15,rcx
    730a040ff992:	shl    r15,0x20
    730a040ff996:	or     rbp,r15
    730a040ff999:	mov    r15,r14
    730a040ff99c:	shr    r15,0x20
    730a040ff9a0:	and    r15,0xffff
    730a040ff9a7:	shl    r15,0x8
    730a040ff9ab:	mov    ecx,0xffffffff
    730a040ff9b0:	and    r15,rcx
    730a040ff9b3:	or     r13,r15
    730a040ff9b6:	shr    r14,0x30
    730a040ff9ba:	and    r14,0xffff
    730a040ff9c1:	shl    r14,0x8
    730a040ff9c5:	mov    ecx,0xffffffff
    730a040ff9ca:	and    r14,rcx
    730a040ff9cd:	shl    r14,0x20
    730a040ff9d1:	or     r13,r14
    730a040ff9d4:	mov    QWORD PTR [r12+0x240],rbp
    730a040ff9dc:	mov    QWORD PTR [r12+0x248],r13
    730a040ff9e4:	mov    r13d,0x0
    730a040ff9ea:	mov    r14,r8
    730a040ff9ed:	and    r14,0xffff
    730a040ff9f4:	shl    r14,0x8
    730a040ff9f8:	mov    ecx,0xffffffff
    730a040ff9fd:	and    r14,rcx
    730a040ffa00:	mov    r15,r13
    730a040ffa03:	or     r15,r14
    730a040ffa06:	mov    r14,r8
    730a040ffa09:	shr    r14,0x10
    730a040ffa0d:	and    r14,0xffff
    730a040ffa14:	shl    r14,0x8
    730a040ffa18:	mov    ecx,0xffffffff
    730a040ffa1d:	and    r14,rcx
    730a040ffa20:	shl    r14,0x20
    730a040ffa24:	or     r15,r14
    730a040ffa27:	mov    r14,r8
    730a040ffa2a:	shr    r14,0x20
    730a040ffa2e:	and    r14,0xffff
    730a040ffa35:	shl    r14,0x8
    730a040ffa39:	mov    ecx,0xffffffff
    730a040ffa3e:	and    r14,rcx
    730a040ffa41:	or     r13,r14
    730a040ffa44:	shr    r8,0x30
    730a040ffa48:	and    r8,0xffff
    730a040ffa4f:	shl    r8,0x8
    730a040ffa53:	mov    ecx,0xffffffff
    730a040ffa58:	and    r8,rcx
    730a040ffa5b:	shl    r8,0x20
    730a040ffa5f:	or     r13,r8
    730a040ffa62:	mov    QWORD PTR [r12+0x220],r15
    730a040ffa6a:	mov    QWORD PTR [r12+0x228],r13
    730a040ffa72:	mov    r13d,0x0
    730a040ffa78:	mov    r14,QWORD PTR [rsp+0x48]
    730a040ffa7d:	and    r14,0xffff
    730a040ffa84:	shl    r14,0x8
    730a040ffa88:	mov    ecx,0xffffffff
    730a040ffa8d:	and    r14,rcx
    730a040ffa90:	mov    r15,r13
    730a040ffa93:	or     r15,r14
    730a040ffa96:	mov    r14,QWORD PTR [rsp+0x48]
    730a040ffa9b:	shr    r14,0x10
    730a040ffa9f:	and    r14,0xffff
    730a040ffaa6:	shl    r14,0x8
    730a040ffaaa:	mov    ecx,0xffffffff
    730a040ffaaf:	and    r14,rcx
    730a040ffab2:	shl    r14,0x20
    730a040ffab6:	or     r15,r14
    730a040ffab9:	mov    r14,QWORD PTR [rsp+0x48]
    730a040ffabe:	shr    r14,0x20
    730a040ffac2:	and    r14,0xffff
    730a040ffac9:	shl    r14,0x8
    730a040ffacd:	mov    ecx,0xffffffff
    730a040ffad2:	and    r14,rcx
    730a040ffad5:	or     r13,r14
    730a040ffad8:	mov    r14,QWORD PTR [rsp+0x48]
    730a040ffadd:	shr    r14,0x30
    730a040ffae1:	and    r14,0xffff
    730a040ffae8:	shl    r14,0x8
    730a040ffaec:	mov    ecx,0xffffffff
    730a040ffaf1:	and    r14,rcx
    730a040ffaf4:	shl    r14,0x20
    730a040ffaf8:	or     r13,r14
    730a040ffafb:	mov    QWORD PTR [r12+0x160],r15
    730a040ffb03:	mov    QWORD PTR [r12+0x168],r13
    730a040ffb0b:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    730a040ffb15:	movdqa xmm0,xmm6
    730a040ffb19:	pslld  xmm0,0x18
    730a040ffb1e:	movdqa xmm7,xmm0
    730a040ffb22:	movdqu XMMWORD PTR [r12+0x170],xmm7
    730a040ffb2c:	movdqu xmm6,XMMWORD PTR [r12+0x270]
    730a040ffb36:	movdqa xmm0,xmm6
    730a040ffb3a:	pslld  xmm0,0x18
    730a040ffb3f:	movdqa xmm8,xmm0
    730a040ffb44:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    730a040ffb4e:	movdqa xmm0,xmm6
    730a040ffb52:	pslld  xmm0,0x18
    730a040ffb57:	movdqa xmm9,xmm0
    730a040ffb5c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    730a040ffb66:	mov    r13d,0x0
    730a040ffb6c:	mov    r14,QWORD PTR [rsp+0x78]
    730a040ffb71:	and    r14,0xffff
    730a040ffb78:	mov    ecx,0xffffffff
    730a040ffb7d:	and    r14,rcx
    730a040ffb80:	mov    r15,r13
    730a040ffb83:	or     r15,r14
    730a040ffb86:	mov    r14,QWORD PTR [rsp+0x78]
    730a040ffb8b:	shr    r14,0x10
    730a040ffb8f:	and    r14,0xffff
    730a040ffb96:	mov    ecx,0xffffffff
    730a040ffb9b:	and    r14,rcx
    730a040ffb9e:	shl    r14,0x20
    730a040ffba2:	or     r15,r14
    730a040ffba5:	mov    r14,QWORD PTR [rsp+0x78]
    730a040ffbaa:	shr    r14,0x20
    730a040ffbae:	and    r14,0xffff
    730a040ffbb5:	mov    ecx,0xffffffff
    730a040ffbba:	and    r14,rcx
    730a040ffbbd:	or     r13,r14
    730a040ffbc0:	mov    r14,QWORD PTR [rsp+0x78]
    730a040ffbc5:	shr    r14,0x30
    730a040ffbc9:	and    r14,0xffff
    730a040ffbd0:	mov    ecx,0xffffffff
    730a040ffbd5:	and    r14,rcx
    730a040ffbd8:	shl    r14,0x20
    730a040ffbdc:	or     r13,r14
    730a040ffbdf:	mov    QWORD PTR [r12+0x140],r15
    730a040ffbe7:	mov    QWORD PTR [r12+0x148],r13
    730a040ffbef:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    730a040ffbf9:	movdqa xmm1,xmm6
    730a040ffbfd:	por    xmm5,xmm1
    730a040ffc01:	movdqu xmm6,XMMWORD PTR [r12+0x220]
    730a040ffc0b:	movdqa xmm1,xmm6
    730a040ffc0f:	por    xmm4,xmm1
    730a040ffc13:	movdqu XMMWORD PTR [r12+0x210],xmm4
    730a040ffc1d:	movdqu xmm6,XMMWORD PTR [r12+0x260]
    730a040ffc27:	movdqa xmm0,xmm6
    730a040ffc2b:	pslld  xmm0,0x18
    730a040ffc30:	movdqa xmm10,xmm0
    730a040ffc35:	movdqu XMMWORD PTR [r12+0x220],xmm10
    730a040ffc3f:	movdqu xmm6,XMMWORD PTR [r12+0x160]
    730a040ffc49:	movdqa xmm1,xmm6
    730a040ffc4d:	por    xmm2,xmm1
    730a040ffc51:	movdqa xmm1,xmm7
    730a040ffc55:	por    xmm3,xmm1
    730a040ffc59:	movdqu XMMWORD PTR [r12+0x160],xmm3
    730a040ffc63:	mov    r13d,0x0
    730a040ffc69:	mov    r14,QWORD PTR [rsp+0x88]
    730a040ffc71:	and    r14,0xffff
    730a040ffc78:	mov    ecx,0xffffffff
    730a040ffc7d:	and    r14,rcx
    730a040ffc80:	mov    r15,r13
    730a040ffc83:	or     r15,r14
    730a040ffc86:	mov    r14,QWORD PTR [rsp+0x88]
    730a040ffc8e:	shr    r14,0x10
    730a040ffc92:	and    r14,0xffff
    730a040ffc99:	mov    ecx,0xffffffff
    730a040ffc9e:	and    r14,rcx
    730a040ffca1:	shl    r14,0x20
    730a040ffca5:	or     r15,r14
    730a040ffca8:	mov    r14,QWORD PTR [rsp+0x88]
    730a040ffcb0:	shr    r14,0x20
    730a040ffcb4:	and    r14,0xffff
    730a040ffcbb:	mov    ecx,0xffffffff
    730a040ffcc0:	and    r14,rcx
    730a040ffcc3:	or     r13,r14
    730a040ffcc6:	mov    r14,QWORD PTR [rsp+0x88]
    730a040ffcce:	shr    r14,0x30
    730a040ffcd2:	and    r14,0xffff
    730a040ffcd9:	mov    ecx,0xffffffff
    730a040ffcde:	and    r14,rcx
    730a040ffce1:	shl    r14,0x20
    730a040ffce5:	or     r13,r14
    730a040ffce8:	mov    QWORD PTR [r12+0x170],r15
    730a040ffcf0:	mov    QWORD PTR [r12+0x178],r13
    730a040ffcf8:	mov    r13d,0x0
    730a040ffcfe:	mov    r14,QWORD PTR [rsp+0x80]
    730a040ffd06:	and    r14,0xffff
    730a040ffd0d:	mov    ecx,0xffffffff
    730a040ffd12:	and    r14,rcx
    730a040ffd15:	mov    r15,r13
    730a040ffd18:	or     r15,r14
    730a040ffd1b:	mov    r14,QWORD PTR [rsp+0x80]
    730a040ffd23:	shr    r14,0x10
    730a040ffd27:	and    r14,0xffff
    730a040ffd2e:	mov    ecx,0xffffffff
    730a040ffd33:	and    r14,rcx
    730a040ffd36:	shl    r14,0x20
    730a040ffd3a:	or     r15,r14
    730a040ffd3d:	mov    r14,QWORD PTR [rsp+0x80]
    730a040ffd45:	shr    r14,0x20
    730a040ffd49:	and    r14,0xffff
    730a040ffd50:	mov    ecx,0xffffffff
    730a040ffd55:	and    r14,rcx
    730a040ffd58:	or     r13,r14
    730a040ffd5b:	mov    r14,QWORD PTR [rsp+0x80]
    730a040ffd63:	shr    r14,0x30
    730a040ffd67:	and    r14,0xffff
    730a040ffd6e:	mov    ecx,0xffffffff
    730a040ffd73:	and    r14,rcx
    730a040ffd76:	shl    r14,0x20
    730a040ffd7a:	or     r13,r14
    730a040ffd7d:	mov    QWORD PTR [r12+0x110],r15
    730a040ffd85:	mov    QWORD PTR [r12+0x118],r13
    730a040ffd8d:	movdqa xmm1,xmm8
    730a040ffd92:	por    xmm5,xmm1
    730a040ffd96:	movdqa xmm1,xmm9
    730a040ffd9b:	por    xmm4,xmm1
    730a040ffd9f:	mov    r13d,0x0
    730a040ffda5:	mov    r14,QWORD PTR [rsp+0x70]
    730a040ffdaa:	and    r14,0xffff
    730a040ffdb1:	mov    ecx,0xffffffff
    730a040ffdb6:	and    r14,rcx
    730a040ffdb9:	mov    r15,r13
    730a040ffdbc:	or     r15,r14
    730a040ffdbf:	mov    r14,QWORD PTR [rsp+0x70]
    730a040ffdc4:	shr    r14,0x10
    730a040ffdc8:	and    r14,0xffff
    730a040ffdcf:	mov    ecx,0xffffffff
    730a040ffdd4:	and    r14,rcx
    730a040ffdd7:	shl    r14,0x20
    730a040ffddb:	or     r15,r14
    730a040ffdde:	mov    r14,QWORD PTR [rsp+0x70]
    730a040ffde3:	shr    r14,0x20
    730a040ffde7:	and    r14,0xffff
    730a040ffdee:	mov    ecx,0xffffffff
    730a040ffdf3:	and    r14,rcx
    730a040ffdf6:	or     r13,r14
    730a040ffdf9:	mov    r14,QWORD PTR [rsp+0x70]
    730a040ffdfe:	shr    r14,0x30
    730a040ffe02:	and    r14,0xffff
    730a040ffe09:	mov    ecx,0xffffffff
    730a040ffe0e:	and    r14,rcx
    730a040ffe11:	shl    r14,0x20
    730a040ffe15:	or     r13,r14
    730a040ffe18:	mov    QWORD PTR [r12+0x180],r15
    730a040ffe20:	mov    QWORD PTR [r12+0x188],r13
    730a040ffe28:	movdqa xmm1,xmm10
    730a040ffe2d:	por    xmm2,xmm1
    730a040ffe31:	movdqu XMMWORD PTR [r12+0x150],xmm2
    730a040ffe3b:	movdqu xmm6,XMMWORD PTR [r12+0x140]
    730a040ffe45:	movdqa xmm1,xmm6
    730a040ffe49:	por    xmm3,xmm1
    730a040ffe4d:	movdqu XMMWORD PTR [r12+0x140],xmm3
    730a040ffe57:	movdqu xmm6,XMMWORD PTR [r12+0x110]
    730a040ffe61:	movdqa xmm1,xmm6
    730a040ffe65:	por    xmm4,xmm1
    730a040ffe69:	movdqu XMMWORD PTR [r12+0x110],xmm4
    730a040ffe73:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    730a040ffe7d:	movdqa xmm1,xmm6
    730a040ffe81:	por    xmm5,xmm1
    730a040ffe85:	movdqu XMMWORD PTR [r12+0x120],xmm5
    730a040ffe8f:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    730a040ffe99:	movdqa xmm1,xmm6
    730a040ffe9d:	por    xmm2,xmm1
    730a040ffea1:	movdqu XMMWORD PTR [r12+0x130],xmm2
    730a040ffeab:	mov    r13,QWORD PTR [r12+0xf8]
    730a040ffeb3:	mov    r14,r13
    730a040ffeb6:	add    r14,0x20
    730a040ffeba:	mov    r15,r14
    730a040ffebd:	add    r15,0x10
    730a040ffec1:	movdqu XMMWORD PTR [r14],xmm4
    730a040ffec6:	mov    r14d,0x0
    730a040ffecc:	mov    DWORD PTR [r12+0x32c],r14d
    730a040ffed4:	movdqu XMMWORD PTR [r15],xmm5
    730a040ffed9:	mov    r14,r13
    730a040ffedc:	add    r14,0x10
    730a040ffee0:	movdqu XMMWORD PTR [r13+0x0],xmm3
    730a040ffee6:	movdqu XMMWORD PTR [r14],xmm2
    730a040ffeeb:	mov    r14d,DWORD PTR [r13+0x0]
    730a040ffeef:	mov    QWORD PTR [r12+0x60],r14
    730a040ffef4:	jmp    0x730a040ffef9
    730a040ffef9:	mov    r13,QWORD PTR [r12+0x58]
    730a040ffefe:	mov    r14,QWORD PTR [r12+0x48]
    730a040fff03:	add    r14,r13
    730a040fff06:	mov    QWORD PTR [r12+0x68],r14
    730a040fff0b:	add    r13,0x4
    730a040fff0f:	mov    QWORD PTR [r12+0x58],r13
    730a040fff14:	mov    r15,r14
    730a040fff17:	add    r15,0x4
    730a040fff1b:	mov    eax,DWORD PTR [r15]
    730a040fff1e:	mov    QWORD PTR [r12+0x70],rax
    730a040fff23:	mov    r15,r14
    730a040fff26:	add    r15,0x38
    730a040fff2a:	mov    r8d,DWORD PTR [r15]
    730a040fff2d:	mov    QWORD PTR [r12+0x78],r8
    730a040fff32:	mov    r15,r14
    730a040fff35:	add    r15,0x24
    730a040fff39:	mov    r9d,DWORD PTR [r15]
    730a040fff3c:	mov    QWORD PTR [r12+0x90],r9
    730a040fff44:	sub    r13,0xc0
    730a040fff4b:	setne  BYTE PTR [rsp+0xb8]
    730a040fff53:	mov    r11,rax
    730a040fff56:	lahf
    730a040fff57:	seto   al
    730a040fff5a:	mov    WORD PTR [rsp+0xb0],ax
    730a040fff62:	mov    rax,r11
    730a040fff65:	mov    r13d,DWORD PTR [r12+0x70]
    730a040fff6a:	mov    r13d,r13d
    730a040fff6d:	mov    r13d,r13d
    730a040fff70:	ror    r13d,0x7
    730a040fff74:	mov    QWORD PTR [r12+0x80],r13
    730a040fff7c:	mov    r15d,r8d
    730a040fff7f:	mov    r15d,r15d
    730a040fff82:	ror    r15d,0x11
    730a040fff86:	mov    QWORD PTR [r12+0x88],r15
    730a040fff8e:	mov    ebp,DWORD PTR [r12+0x60]
    730a040fff93:	add    r9d,ebp
    730a040fff96:	mov    QWORD PTR [r12+0x60],r9
    730a040fff9b:	mov    ebp,DWORD PTR [r12+0x70]
    730a040fffa0:	mov    ebp,ebp
    730a040fffa2:	mov    ebp,ebp
    730a040fffa4:	ror    ebp,0x12
    730a040fffa7:	xor    r13d,ebp
    730a040fffaa:	mov    QWORD PTR [r12+0x80],r13
    730a040fffb2:	mov    ebp,r8d
    730a040fffb5:	mov    ebp,ebp
    730a040fffb7:	ror    ebp,0x13
    730a040fffba:	xor    r15d,ebp
    730a040fffbd:	mov    QWORD PTR [r12+0x88],r15
    730a040fffc5:	mov    ebp,DWORD PTR [r12+0x70]
    730a040fffca:	mov    ebp,ebp
    730a040fffcc:	mov    ebp,ebp
    730a040fffce:	shr    ebp,0x3
    730a040fffd1:	xor    r13d,ebp
    730a040fffd4:	mov    QWORD PTR [r12+0x80],r13
    730a040fffdc:	mov    r8d,r8d
    730a040fffdf:	shr    r8d,0xa
    730a040fffe3:	xor    r15d,r8d
    730a040fffe6:	mov    QWORD PTR [r12+0x78],r15
    730a040fffeb:	add    r9d,r13d
    730a040fffee:	mov    QWORD PTR [r12+0x60],r9
    730a040ffff3:	add    r9d,r15d
    730a040ffff6:	mov    QWORD PTR [r12+0x60],r9
    730a040ffffb:	add    r14,0x40
    730a040fffff:	mov    DWORD PTR [r14],r9d
    730a04100002:	mov    r13d,0x0
    730a04100008:	mov    DWORD PTR [r12+0x32c],r13d
    730a04100010:	mov    r13d,0x0
    730a04100016:	mov    ecx,DWORD PTR [r12+0x70]
    730a0410001b:	mov    ecx,ecx
    730a0410001d:	mov    r14d,r13d
    730a04100020:	or     r14d,ecx
    730a04100023:	mov    QWORD PTR [r12+0x60],r14
    730a04100028:	mov    rcx,QWORD PTR [r12+0x380]
    730a04100030:	jrcxz  0x730a04100037
    730a04100032:	jmp    0x730a0410081a
    730a04100037:	cmp    BYTE PTR [rsp+0xb8],0x0
    730a0410003f:	jne    0x730a040ffef9
    730a04100045:	jmp    0x730a0410004a
    730a0410004a:	mov    r13,QWORD PTR [r12]
    730a0410004e:	mov    r14,r13
    730a04100051:	add    r14,0x4
    730a04100055:	mov    r15d,DWORD PTR [r13+0x0]
    730a04100059:	mov    ebp,DWORD PTR [r14]
    730a0410005c:	mov    QWORD PTR [r12+0x78],r15
    730a04100061:	mov    QWORD PTR [r12+0x80],rbp
    730a04100069:	mov    r14,r13
    730a0410006c:	add    r14,0x8
    730a04100070:	mov    r8,r14
    730a04100073:	add    r8,0x4
    730a04100077:	mov    r9d,DWORD PTR [r14]
    730a0410007a:	mov    eax,DWORD PTR [r8]
    730a0410007d:	mov    QWORD PTR [rsp+0x90],rax
    730a04100085:	mov    QWORD PTR [r12+0x70],r9
    730a0410008a:	mov    rax,QWORD PTR [rsp+0x90]
    730a04100092:	mov    QWORD PTR [r12+0x68],rax
    730a04100097:	mov    r8,r13
    730a0410009a:	add    r8,0x18
    730a0410009e:	mov    r14,r8
    730a041000a1:	add    r14,0x4
    730a041000a5:	mov    eax,DWORD PTR [r8]
    730a041000a8:	mov    QWORD PTR [rsp+0x98],rax
    730a041000b0:	mov    r8d,DWORD PTR [r14]
    730a041000b3:	mov    rax,QWORD PTR [rsp+0x98]
    730a041000bb:	mov    QWORD PTR [r12+0x58],rax
    730a041000c0:	mov    QWORD PTR [r12+0x60],r8
    730a041000c5:	add    r13,0x10
    730a041000c9:	mov    r14,r13
    730a041000cc:	add    r14,0x4
    730a041000d0:	mov    eax,DWORD PTR [r13+0x0]
    730a041000d4:	mov    QWORD PTR [rsp+0xa0],rax
    730a041000dc:	mov    eax,DWORD PTR [r14]
    730a041000df:	mov    QWORD PTR [rsp+0xa8],rax
    730a041000e7:	mov    rax,QWORD PTR [rsp+0xa0]
    730a041000ef:	mov    QWORD PTR [r12+0x18],rax
    730a041000f4:	mov    rax,QWORD PTR [rsp+0xa8]
    730a041000fc:	mov    QWORD PTR [r12+0x90],rax
    730a04100104:	mov    r14d,0x0
    730a0410010a:	mov    QWORD PTR [r12+0x88],r14
    730a04100112:	mov    r14d,0x0
    730a04100118:	mov    r13d,r14d
    730a0410011b:	or     r13d,r15d
    730a0410011e:	mov    QWORD PTR [r12+0xa8],r13
    730a04100126:	mov    r13d,0x0
    730a0410012c:	mov    r14d,r13d
    730a0410012f:	or     r14d,ebp
    730a04100132:	mov    QWORD PTR [r12+0x38],r14
    730a04100137:	mov    r13d,0x0
    730a0410013d:	mov    r14d,r13d
    730a04100140:	or     r14d,r9d
    730a04100143:	mov    QWORD PTR [r12+0x98],r14
    730a0410014b:	mov    r13d,0x0
    730a04100151:	mov    ecx,DWORD PTR [rsp+0x90]
    730a04100158:	mov    r14d,r13d
    730a0410015b:	or     r14d,ecx
    730a0410015e:	mov    QWORD PTR [r12+0x28],r14
    730a04100163:	mov    r13d,0x0
    730a04100169:	mov    r14d,r13d
    730a0410016c:	or     r14d,r8d
    730a0410016f:	mov    QWORD PTR [r12+0xb0],r14
    730a04100177:	mov    r13d,0x0
    730a0410017d:	mov    ecx,DWORD PTR [rsp+0x98]
    730a04100184:	mov    r14d,r13d
    730a04100187:	or     r14d,ecx
    730a0410018a:	mov    QWORD PTR [r12+0xc0],r14
    730a04100192:	mov    r13d,0x0
    730a04100198:	mov    ecx,DWORD PTR [rsp+0xa8]
    730a0410019f:	mov    r14d,r13d
    730a041001a2:	or     r14d,ecx
    730a041001a5:	mov    QWORD PTR [r12+0xc8],r14
    730a041001ad:	mov    r13d,0x0
    730a041001b3:	mov    ecx,DWORD PTR [rsp+0xa0]
    730a041001ba:	mov    r14d,r13d
    730a041001bd:	or     r14d,ecx
    730a041001c0:	mov    QWORD PTR [r12+0xb8],r14
    730a041001c8:	jmp    0x730a041001cd
    730a041001cd:	mov    r13d,0x0
    730a041001d3:	mov    r14d,DWORD PTR [r12+0xb8]
    730a041001db:	mov    eax,r13d
    730a041001de:	or     eax,r14d
    730a041001e1:	mov    QWORD PTR [r12+0x30],rax
    730a041001e6:	mov    r13d,0x0
    730a041001ec:	mov    ebp,DWORD PTR [r12+0xc0]
    730a041001f4:	mov    eax,r13d
    730a041001f7:	or     eax,ebp
    730a041001f9:	mov    QWORD PTR [r12+0xa0],rax
    730a04100201:	mov    r13d,0x0
    730a04100207:	mov    ebp,DWORD PTR [r12+0x28]
    730a0410020c:	mov    eax,r13d
    730a0410020f:	or     eax,ebp
    730a04100211:	mov    QWORD PTR [r12+0xc0],rax
    730a04100219:	mov    r13d,0x0
    730a0410021f:	mov    ebp,DWORD PTR [r12+0x98]
    730a04100227:	mov    eax,r13d
    730a0410022a:	or     eax,ebp
    730a0410022c:	mov    QWORD PTR [r12+0x28],rax
    730a04100231:	mov    r13d,0x0
    730a04100237:	mov    ebp,DWORD PTR [r12+0x38]
    730a0410023c:	mov    eax,r13d
    730a0410023f:	or     eax,ebp
    730a04100241:	mov    QWORD PTR [r12+0x98],rax
    730a04100249:	mov    r13d,0x0
    730a0410024f:	mov    ebp,DWORD PTR [r12+0xa8]
    730a04100257:	mov    eax,r13d
    730a0410025a:	or     eax,ebp
    730a0410025c:	mov    QWORD PTR [r12+0x38],rax
    730a04100261:	mov    r14d,r14d
    730a04100264:	ror    r14d,0x6
    730a04100268:	mov    QWORD PTR [r12+0xb8],r14
    730a04100270:	mov    r13d,DWORD PTR [r12+0xc8]
    730a04100278:	mov    ebp,DWORD PTR [r12+0x30]
    730a0410027d:	mov    ebp,ebp
    730a0410027f:	and    ebp,r13d
    730a04100282:	mov    QWORD PTR [r12+0xa8],rbp
    730a0410028a:	mov    r9d,DWORD PTR [r12+0x38]
    730a0410028f:	mov    r9d,r9d
    730a04100292:	mov    r9d,r9d
    730a04100295:	ror    r9d,0x2
    730a04100299:	mov    QWORD PTR [r12+0xd0],r9
    730a041002a1:	mov    r15d,0x0
    730a041002a7:	mov    eax,r15d
    730a041002aa:	or     eax,r13d
    730a041002ad:	mov    QWORD PTR [r12+0x20],rax
    730a041002b2:	mov    rax,QWORD PTR [r12+0x88]
    730a041002ba:	mov    r15,QWORD PTR [r12+0x50]
    730a041002bf:	mov    rcx,QWORD PTR [r12+0x88]
    730a041002c7:	add    r15,rcx
    730a041002ca:	mov    r13d,DWORD PTR [r15]
    730a041002cd:	mov    QWORD PTR [r12+0xc8],r13
    730a041002d5:	mov    ecx,DWORD PTR [r12+0x30]
    730a041002da:	mov    ecx,ecx
    730a041002dc:	mov    r15d,DWORD PTR [r12+0xa0]
    730a041002e4:	mov    r15d,r15d
    730a041002e7:	not    rcx
    730a041002ea:	and    r15d,ecx
    730a041002ed:	mov    QWORD PTR [r12+0xd8],r15
    730a041002f5:	mov    r8d,DWORD PTR [r12+0xb0]
    730a041002fd:	add    ebp,r8d
    730a04100300:	mov    QWORD PTR [r12+0xa8],rbp
    730a04100308:	mov    r8d,DWORD PTR [r12+0x30]
    730a0410030d:	mov    r8d,r8d
    730a04100310:	mov    r8d,r8d
    730a04100313:	ror    r8d,0xb
    730a04100317:	xor    r14d,r8d
    730a0410031a:	mov    QWORD PTR [r12+0xb0],r14
    730a04100322:	mov    r8d,DWORD PTR [r12+0x38]
    730a04100327:	mov    r8d,r8d
    730a0410032a:	mov    r8d,r8d
    730a0410032d:	ror    r8d,0xd
    730a04100331:	xor    r9d,r8d
    730a04100334:	mov    QWORD PTR [r12+0xd0],r9
    730a0410033c:	add    ebp,r15d
    730a0410033f:	mov    QWORD PTR [r12+0xa8],rbp
    730a04100347:	mov    r15,QWORD PTR [r12+0x48]
    730a0410034c:	mov    rcx,QWORD PTR [r12+0x88]
    730a04100354:	add    r15,rcx
    730a04100357:	mov    r8d,DWORD PTR [r15]
    730a0410035a:	mov    QWORD PTR [r12+0xb8],r8
    730a04100362:	mov    ecx,DWORD PTR [r12+0x98]
    730a0410036a:	mov    ecx,ecx
    730a0410036c:	mov    eax,DWORD PTR [r12+0x28]
    730a04100371:	mov    eax,eax
    730a04100373:	and    eax,ecx
    730a04100375:	mov    QWORD PTR [r12+0xd8],rax
    730a0410037d:	add    ebp,r13d
    730a04100380:	mov    QWORD PTR [r12+0xa8],rbp
    730a04100388:	mov    ecx,DWORD PTR [r12+0x98]
    730a04100390:	mov    ecx,ecx
    730a04100392:	mov    r13d,DWORD PTR [r12+0x28]
    730a04100397:	mov    r13d,r13d
    730a0410039a:	xor    r13d,ecx
    730a0410039d:	mov    QWORD PTR [r12+0xc8],r13
    730a041003a5:	mov    r15d,DWORD PTR [r12+0x30]
    730a041003aa:	mov    r15d,r15d
    730a041003ad:	mov    r15d,r15d
    730a041003b0:	ror    r15d,0x19
    730a041003b4:	xor    r14d,r15d
    730a041003b7:	mov    QWORD PTR [r12+0xb0],r14
    730a041003bf:	mov    ecx,DWORD PTR [r12+0x38]
    730a041003c4:	mov    ecx,ecx
    730a041003c6:	and    r13d,ecx
    730a041003c9:	mov    QWORD PTR [r12+0xc8],r13
    730a041003d1:	mov    r15d,DWORD PTR [r12+0x38]
    730a041003d6:	mov    r15d,r15d
    730a041003d9:	mov    r15d,r15d
    730a041003dc:	ror    r15d,0x16
    730a041003e0:	xor    r9d,r15d
    730a041003e3:	mov    QWORD PTR [r12+0xd0],r9
    730a041003eb:	add    ebp,r8d
    730a041003ee:	mov    QWORD PTR [r12+0xa8],rbp
    730a041003f6:	mov    ecx,DWORD PTR [r12+0xd8]
    730a041003fe:	mov    ecx,ecx
    730a04100400:	xor    r13d,ecx
    730a04100403:	mov    QWORD PTR [r12+0xb8],r13
    730a0410040b:	add    ebp,r14d
    730a0410040e:	mov    QWORD PTR [r12+0xa8],rbp
    730a04100416:	mov    r14,QWORD PTR [r12+0x88]
    730a0410041e:	add    r14,0x4
    730a04100422:	mov    QWORD PTR [r12+0x88],r14
    730a0410042a:	add    r13d,r9d
    730a0410042d:	mov    QWORD PTR [r12+0xb0],r13
    730a04100435:	mov    ecx,DWORD PTR [r12+0xc0]
    730a0410043d:	mov    ecx,ecx
    730a0410043f:	mov    r15d,ebp
    730a04100442:	add    r15d,ecx
    730a04100445:	mov    QWORD PTR [r12+0xb8],r15
    730a0410044d:	sub    r14,0x100
    730a04100454:	setne  BYTE PTR [rsp+0xb8]
    730a0410045c:	mov    r11,rax
    730a0410045f:	lahf
    730a04100460:	seto   al
    730a04100463:	mov    WORD PTR [rsp+0xb0],ax
    730a0410046b:	mov    rax,r11
    730a0410046e:	add    r13d,ebp
    730a04100471:	mov    QWORD PTR [r12+0xa8],r13
    730a04100479:	mov    r13d,0x0
    730a0410047f:	mov    ecx,DWORD PTR [r12+0xa0]
    730a04100487:	mov    ecx,ecx
    730a04100489:	mov    r14d,r13d
    730a0410048c:	or     r14d,ecx
    730a0410048f:	mov    QWORD PTR [r12+0xb0],r14
    730a04100497:	mov    r13d,0x0
    730a0410049d:	mov    ecx,DWORD PTR [r12+0x20]
    730a041004a2:	mov    ecx,ecx
    730a041004a4:	mov    r14d,r13d
    730a041004a7:	or     r14d,ecx
    730a041004aa:	mov    QWORD PTR [r12+0xc0],r14
    730a041004b2:	mov    r13d,0x0
    730a041004b8:	mov    ecx,DWORD PTR [r12+0x30]
    730a041004bd:	mov    ecx,ecx
    730a041004bf:	mov    r14d,r13d
    730a041004c2:	or     r14d,ecx
    730a041004c5:	mov    QWORD PTR [r12+0xc8],r14
    730a041004cd:	mov    rcx,QWORD PTR [r12+0x380]
    730a041004d5:	jrcxz  0x730a041004dc
    730a041004d7:	jmp    0x730a041008a2
    730a041004dc:	cmp    BYTE PTR [rsp+0xb8],0x0
    730a041004e4:	jne    0x730a041001cd
    730a041004ea:	jmp    0x730a041004ef
    730a041004ef:	mov    r13d,DWORD PTR [r12+0x70]
    730a041004f4:	mov    r14d,DWORD PTR [r12+0x98]
    730a041004fc:	add    r14d,r13d
    730a041004ff:	mov    QWORD PTR [r12+0x70],r14
    730a04100504:	mov    r13d,DWORD PTR [r12+0x68]
    730a04100509:	mov    r15d,DWORD PTR [r12+0x28]
    730a0410050e:	add    r15d,r13d
    730a04100511:	mov    QWORD PTR [r12+0x68],r15
    730a04100516:	mov    r13d,0x0
    730a0410051c:	mov    QWORD PTR [r12+0x88],r13
    730a04100524:	mov    r13d,DWORD PTR [r12+0x78]
    730a04100529:	mov    ebp,DWORD PTR [r12+0xa8]
    730a04100531:	add    ebp,r13d
    730a04100534:	mov    QWORD PTR [r12+0x78],rbp
    730a04100539:	mov    r13d,DWORD PTR [r12+0x80]
    730a04100541:	mov    r8d,DWORD PTR [r12+0x38]
    730a04100546:	add    r8d,r13d
    730a04100549:	mov    QWORD PTR [r12+0x80],r8
    730a04100551:	mov    rax,QWORD PTR [r12]
    730a04100555:	mov    r9,QWORD PTR [r12]
    730a04100559:	add    r9,0x8
    730a0410055d:	mov    r13,r9
    730a04100560:	add    r13,0x4
    730a04100564:	mov    DWORD PTR [r9],r14d
    730a04100567:	mov    r14d,0x0
    730a0410056d:	mov    DWORD PTR [r12+0x32c],r14d
    730a04100575:	mov    DWORD PTR [r13+0x0],r15d
    730a04100579:	mov    r13d,DWORD PTR [r12+0x18]
    730a0410057e:	mov    r14d,DWORD PTR [r12+0xb8]
    730a04100586:	add    r14d,r13d
    730a04100589:	mov    QWORD PTR [r12+0x68],r14
    730a0410058e:	mov    r13d,DWORD PTR [r12+0x90]
    730a04100596:	mov    r15d,DWORD PTR [r12+0x30]
    730a0410059b:	add    r15d,r13d
    730a0410059e:	mov    QWORD PTR [r12+0x70],r15
    730a041005a3:	mov    r13d,DWORD PTR [r12+0x58]
    730a041005a8:	mov    r9d,DWORD PTR [r12+0x20]
    730a041005ad:	mov    eax,r9d
    730a041005b0:	add    eax,r13d
    730a041005b3:	mov    QWORD PTR [r12+0x58],rax
    730a041005b8:	mov    r13d,DWORD PTR [r12+0x60]
    730a041005bd:	mov    r9d,DWORD PTR [r12+0xa0]
    730a041005c5:	add    r9d,r13d
    730a041005c8:	mov    QWORD PTR [r12+0x60],r9
    730a041005cd:	mov    r13,QWORD PTR [r12]
    730a041005d1:	add    r13,0x4
    730a041005d5:	mov    rdi,QWORD PTR [r12]
    730a041005d9:	mov    DWORD PTR [rdi],ebp
    730a041005db:	mov    DWORD PTR [r13+0x0],r8d
    730a041005df:	mov    r13,QWORD PTR [r12]
    730a041005e3:	add    r13,0x10
    730a041005e7:	mov    rbp,r13
    730a041005ea:	add    rbp,0x4
    730a041005ee:	mov    DWORD PTR [r13+0x0],r14d
    730a041005f2:	mov    DWORD PTR [rbp+0x0],r15d
    730a041005f6:	mov    r13,QWORD PTR [r12]
    730a041005fa:	add    r13,0x18
    730a041005fe:	mov    r14,r13
    730a04100601:	add    r14,0x4
    730a04100605:	mov    eax,DWORD PTR [r12+0x58]
    730a0410060a:	mov    DWORD PTR [r13+0x0],eax
    730a0410060e:	mov    DWORD PTR [r14],r9d
    730a04100611:	mov    r13,QWORD PTR [r12]
    730a04100615:	add    r13,0x68
    730a04100619:	mov    r14d,0x0
    730a0410061f:	mov    QWORD PTR [r13+0x0],r14
    730a04100623:	mov    rcx,QWORD PTR [r12+0x380]
    730a0410062b:	jrcxz  0x730a04100632
    730a0410062d:	jmp    0x730a0410092a
    730a04100632:	jmp    0x730a04100637
    730a04100637:	mov    r13,QWORD PTR [r12+0x10]
    730a0410063c:	sub    r13,0x1
    730a04100640:	mov    QWORD PTR [r12+0x10],r13
    730a04100645:	mov    rax,r13
    730a04100648:	test   rax,rax
    730a0410064b:	je     0x730a04100656
    730a04100651:	jmp    0x730a040fe75a
    730a04100656:	mov    r13,QWORD PTR [r12+0xf8]
    730a0410065e:	mov    r14,r13
    730a04100661:	add    r14,0x140
    730a04100668:	mov    r15,r14
    730a0410066b:	add    r15,0x8
    730a0410066f:	mov    rbp,QWORD PTR [r14]
    730a04100672:	mov    r14,QWORD PTR [r15]
    730a04100675:	mov    QWORD PTR [r12+0xa0],rbp
    730a0410067d:	mov    QWORD PTR [r12+0x98],r14
    730a04100685:	mov    r14,r13
    730a04100688:	add    r14,0x130
    730a0410068f:	mov    r15,r14
    730a04100692:	add    r15,0x8
    730a04100696:	mov    rbp,QWORD PTR [r14]
    730a04100699:	mov    r14,QWORD PTR [r15]
    730a0410069c:	mov    QWORD PTR [r12+0xb0],rbp
    730a041006a4:	mov    QWORD PTR [r12+0xa8],r14
    730a041006ac:	mov    r14,r13
    730a041006af:	add    r14,0x120
    730a041006b6:	mov    r15,r14
    730a041006b9:	add    r15,0x8
    730a041006bd:	mov    rbp,QWORD PTR [r14]
    730a041006c0:	mov    r14,QWORD PTR [r15]
    730a041006c3:	mov    QWORD PTR [r12+0xc0],rbp
    730a041006cb:	mov    QWORD PTR [r12+0xb8],r14
    730a041006d3:	mov    r14,r13
    730a041006d6:	add    r14,0x110
    730a041006dd:	mov    r15,r14
    730a041006e0:	add    r15,0x8
    730a041006e4:	mov    rbp,QWORD PTR [r14]
    730a041006e7:	mov    r14,QWORD PTR [r15]
    730a041006ea:	mov    QWORD PTR [r12+0xd0],rbp
    730a041006f2:	mov    QWORD PTR [r12+0xc8],r14
    730a041006fa:	mov    r14,r13
    730a041006fd:	add    r14,0x100
    730a04100704:	mov    r15,r14
    730a04100707:	add    r15,0x8
    730a0410070b:	mov    rbp,QWORD PTR [r14]
    730a0410070e:	mov    r14,QWORD PTR [r15]
    730a04100711:	mov    QWORD PTR [r12+0xe8],rbp
    730a04100719:	mov    QWORD PTR [r12+0xd8],r14
    730a04100721:	add    r13,0x150
    730a04100728:	mov    QWORD PTR [r12+0xf8],r13
    730a04100730:	jmp    0x730a04100735
    730a04100735:	mov    rcx,QWORD PTR [r12+0x380]
    730a0410073d:	jrcxz  0x730a04100744
    730a0410073f:	jmp    0x730a041009b2
    730a04100744:	mov    r13,QWORD PTR [r12+0xf0]
    730a0410074c:	mov    QWORD PTR [r12+0x100],r13
    730a04100754:	mov    r11,QWORD PTR [rsp+0xb0]
    730a0410075c:	mov    QWORD PTR [r12+0x398],r11
    730a04100764:	mov    rdi,QWORD PTR [r12+0x100]
    730a0410076c:	add    rsp,0xc0
    730a04100773:	movabs r11,0x5591a9c2c940
    730a0410077d:	jmp    r11
    730a04100780:	mov    eax,0x41078c
    730a04100785:	mov    QWORD PTR [r12+0x100],rax
    730a0410078d:	push   rdx
    730a0410078e:	push   rsi
    730a0410078f:	push   r10
    730a04100791:	push   r11
    730a04100793:	mov    r11,rax
    730a04100796:	lahf
    730a04100797:	seto   al
    730a0410079a:	mov    WORD PTR [rsp+0xd0],ax
    730a041007a2:	mov    rax,r11
    730a041007a5:	mov    rdx,QWORD PTR [rsp+0xd0]
    730a041007ad:	mov    r10d,edx
    730a041007b0:	and    r10d,0xc000
    730a041007b7:	shl    r10d,0x10
    730a041007bb:	mov    r11d,edx
    730a041007be:	and    r11d,0x100
    730a041007c5:	shl    r11d,0x15
    730a041007c9:	or     r10d,r11d
    730a041007cc:	and    edx,0x1
    730a041007cf:	shl    edx,0x1c
    730a041007d2:	or     r10d,edx
    730a041007d5:	btc    r10,0x1d
    730a041007da:	mov    r11d,0xf0000000
    730a041007e0:	and    r11,r10
    730a041007e3:	movabs rsi,0xffffffff0fffffff
    730a041007ed:	and    rbx,rsi
    730a041007f0:	or     rbx,r11
    730a041007f3:	pop    r11
    730a041007f5:	pop    r10
    730a041007f7:	pop    rsi
    730a041007f8:	pop    rdx
    730a041007f9:	mov    QWORD PTR [r12+0x108],rbx
    730a04100801:	add    rsp,0xc0
    730a04100808:	mov    eax,0xc
    730a0410080d:	movabs r11,0x5591a9c2cca0
    730a04100817:	jmp    r11
    730a0410081a:	mov    eax,0x410888
    730a0410081f:	mov    QWORD PTR [r12+0x100],rax
    730a04100827:	push   rdx
    730a04100828:	push   rsi
    730a04100829:	push   r10
    730a0410082b:	push   r11
    730a0410082d:	mov    rdx,QWORD PTR [rsp+0xd0]
    730a04100835:	mov    r10d,edx
    730a04100838:	and    r10d,0xc000
    730a0410083f:	shl    r10d,0x10
    730a04100843:	mov    r11d,edx
    730a04100846:	and    r11d,0x100
    730a0410084d:	shl    r11d,0x15
    730a04100851:	or     r10d,r11d
    730a04100854:	and    edx,0x1
    730a04100857:	shl    edx,0x1c
    730a0410085a:	or     r10d,edx
    730a0410085d:	btc    r10,0x1d
    730a04100862:	mov    r11d,0xf0000000
    730a04100868:	and    r11,r10
    730a0410086b:	movabs rsi,0xffffffff0fffffff
    730a04100875:	and    rbx,rsi
    730a04100878:	or     rbx,r11
    730a0410087b:	pop    r11
    730a0410087d:	pop    r10
    730a0410087f:	pop    rsi
    730a04100880:	pop    rdx
    730a04100881:	mov    QWORD PTR [r12+0x108],rbx
    730a04100889:	add    rsp,0xc0
    730a04100890:	mov    eax,0xc
    730a04100895:	movabs r11,0x5591a9c2cca0
    730a0410089f:	jmp    r11
    730a041008a2:	mov    eax,0x410948
    730a041008a7:	mov    QWORD PTR [r12+0x100],rax
    730a041008af:	push   rdx
    730a041008b0:	push   rsi
    730a041008b1:	push   r10
    730a041008b3:	push   r11
    730a041008b5:	mov    rdx,QWORD PTR [rsp+0xd0]
    730a041008bd:	mov    r10d,edx
    730a041008c0:	and    r10d,0xc000
    730a041008c7:	shl    r10d,0x10
    730a041008cb:	mov    r11d,edx
    730a041008ce:	and    r11d,0x100
    730a041008d5:	shl    r11d,0x15
    730a041008d9:	or     r10d,r11d
    730a041008dc:	and    edx,0x1
    730a041008df:	shl    edx,0x1c
    730a041008e2:	or     r10d,edx
    730a041008e5:	btc    r10,0x1d
    730a041008ea:	mov    r11d,0xf0000000
    730a041008f0:	and    r11,r10
    730a041008f3:	movabs rsi,0xffffffff0fffffff
    730a041008fd:	and    rbx,rsi
    730a04100900:	or     rbx,r11
    730a04100903:	pop    r11
    730a04100905:	pop    r10
    730a04100907:	pop    rsi
    730a04100908:	pop    rdx
    730a04100909:	mov    QWORD PTR [r12+0x108],rbx
    730a04100911:	add    rsp,0xc0
    730a04100918:	mov    eax,0xc
    730a0410091d:	movabs r11,0x5591a9c2cca0
    730a04100927:	jmp    r11
    730a0410092a:	mov    eax,0x410984
    730a0410092f:	mov    QWORD PTR [r12+0x100],rax
    730a04100937:	push   rdx
    730a04100938:	push   rsi
    730a04100939:	push   r10
    730a0410093b:	push   r11
    730a0410093d:	mov    rdx,QWORD PTR [rsp+0xd0]
    730a04100945:	mov    r10d,edx
    730a04100948:	and    r10d,0xc000
    730a0410094f:	shl    r10d,0x10
    730a04100953:	mov    r11d,edx
    730a04100956:	and    r11d,0x100
    730a0410095d:	shl    r11d,0x15
    730a04100961:	or     r10d,r11d
    730a04100964:	and    edx,0x1
    730a04100967:	shl    edx,0x1c
    730a0410096a:	or     r10d,edx
    730a0410096d:	btc    r10,0x1d
    730a04100972:	mov    r11d,0xf0000000
    730a04100978:	and    r11,r10
    730a0410097b:	movabs rsi,0xffffffff0fffffff
    730a04100985:	and    rbx,rsi
    730a04100988:	or     rbx,r11
    730a0410098b:	pop    r11
    730a0410098d:	pop    r10
    730a0410098f:	pop    rsi
    730a04100990:	pop    rdx
    730a04100991:	mov    QWORD PTR [r12+0x108],rbx
    730a04100999:	add    rsp,0xc0
    730a041009a0:	mov    eax,0xc
    730a041009a5:	movabs r11,0x5591a9c2cca0
    730a041009af:	jmp    r11
    730a041009b2:	mov    eax,0x4109a0
    730a041009b7:	mov    QWORD PTR [r12+0x100],rax
    730a041009bf:	push   rdx
    730a041009c0:	push   rsi
    730a041009c1:	push   r10
    730a041009c3:	push   r11
    730a041009c5:	mov    rdx,QWORD PTR [rsp+0xd0]
    730a041009cd:	mov    r10d,edx
    730a041009d0:	and    r10d,0xc000
    730a041009d7:	shl    r10d,0x10
    730a041009db:	mov    r11d,edx
    730a041009de:	and    r11d,0x100
    730a041009e5:	shl    r11d,0x15
    730a041009e9:	or     r10d,r11d
    730a041009ec:	and    edx,0x1
    730a041009ef:	shl    edx,0x1c
    730a041009f2:	or     r10d,edx
    730a041009f5:	btc    r10,0x1d
    730a041009fa:	mov    r11d,0xf0000000
    730a04100a00:	and    r11,r10
    730a04100a03:	movabs rsi,0xffffffff0fffffff
    730a04100a0d:	and    rbx,rsi
    730a04100a10:	or     rbx,r11
    730a04100a13:	pop    r11
    730a04100a15:	pop    r10
    730a04100a17:	pop    rsi
    730a04100a18:	pop    rdx
    730a04100a19:	mov    QWORD PTR [r12+0x108],rbx
    730a04100a21:	add    rsp,0xc0
    730a04100a28:	mov    eax,0xc
    730a04100a2d:	movabs r11,0x5591a9c2cca0
    730a04100a37:	jmp    r11
    730a04100a3a:	nop    WORD PTR [rax+rax*1+0x0]
    730a04100a40:	sub    rsp,0xc0
    730a04100a47:	mov    r11,QWORD PTR [r12+0x398]
    730a04100a4f:	mov    QWORD PTR [rsp+0xb0],r11
    730a04100a57:	jmp    0x730a040fe639
    730a04100a5c:	nop    DWORD PTR [rax+0x0]
    730a04100a60:	sub    rsp,0xc0
    730a04100a67:	mov    r11,QWORD PTR [r12+0x398]
    730a04100a6f:	mov    QWORD PTR [rsp+0xb0],r11
    730a04100a77:	jmp    0x730a040fe75a
    730a04100a7c:	nop    DWORD PTR [rax+0x0]
    730a04100a80:	sub    rsp,0xc0
    730a04100a87:	mov    r11,QWORD PTR [r12+0x398]
    730a04100a8f:	mov    QWORD PTR [rsp+0xb0],r11
    730a04100a97:	jmp    0x730a040fe814
    730a04100a9c:	nop    DWORD PTR [rax+0x0]
    730a04100aa0:	sub    rsp,0xc0
    730a04100aa7:	mov    r11,QWORD PTR [r12+0x398]
    730a04100aaf:	mov    QWORD PTR [rsp+0xb0],r11
    730a04100ab7:	jmp    0x730a040ffef9
    730a04100abc:	nop    DWORD PTR [rax+0x0]
    730a04100ac0:	sub    rsp,0xc0
    730a04100ac7:	mov    r11,QWORD PTR [r12+0x398]
    730a04100acf:	mov    QWORD PTR [rsp+0xb0],r11
    730a04100ad7:	jmp    0x730a0410004a
    730a04100adc:	nop    DWORD PTR [rax+0x0]
    730a04100ae0:	sub    rsp,0xc0
    730a04100ae7:	mov    r11,QWORD PTR [r12+0x398]
    730a04100aef:	mov    QWORD PTR [rsp+0xb0],r11
    730a04100af7:	jmp    0x730a041001cd
    730a04100afc:	nop    DWORD PTR [rax+0x0]
    730a04100b00:	sub    rsp,0xc0
    730a04100b07:	mov    r11,QWORD PTR [r12+0x398]
    730a04100b0f:	mov    QWORD PTR [rsp+0xb0],r11
    730a04100b17:	jmp    0x730a041004ef
    730a04100b1c:	nop    DWORD PTR [rax+0x0]
    730a04100b20:	sub    rsp,0xc0
    730a04100b27:	mov    r11,QWORD PTR [r12+0x398]
    730a04100b2f:	mov    QWORD PTR [rsp+0xb0],r11
    730a04100b37:	jmp    0x730a04100637
    730a04100b3c:	nop    DWORD PTR [rax+0x0]
    730a04100b40:	sub    rsp,0xc0
    730a04100b47:	mov    r11,QWORD PTR [r12+0x398]
    730a04100b4f:	mov    QWORD PTR [rsp+0xb0],r11
    730a04100b57:	jmp    0x730a04100656
    730a04100b5c:	nop    DWORD PTR [rax+0x0]
    730a04100b60:	sub    rsp,0xc0
    730a04100b67:	mov    r11,QWORD PTR [r12+0x398]
    730a04100b6f:	mov    QWORD PTR [rsp+0xb0],r11
    730a04100b77:	jmp    0x730a04100735
