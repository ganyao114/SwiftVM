
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/0/3.bin:     file format binary


Disassembly of section .data:

000077db49300e10 <.data>:
    77db49300e10:	sub    rsp,0x10
    77db49300e14:	mov    r11,QWORD PTR [r12+0x398]
    77db49300e1c:	mov    QWORD PTR [rsp],r11
    77db49300e20:	mov    r13,QWORD PTR [r12+0xf8]
    77db49300e28:	mov    r14,r13
    77db49300e2b:	add    r14,0x168
    77db49300e32:	mov    r15,QWORD PTR [r14]
    77db49300e35:	mov    QWORD PTR [r12+0x40],r15
    77db49300e3a:	add    r13,0x178
    77db49300e41:	mov    r14d,0x0
    77db49300e47:	mov    BYTE PTR [r13+0x0],r14b
    77db49300e4b:	mov    r13d,0x0
    77db49300e51:	mov    DWORD PTR [r12+0x32c],r13d
    77db49300e59:	sub    r15,0x38
    77db49300e5d:	je     0x77db49300e76
    77db49300e63:	mov    r11,rax
    77db49300e66:	lahf
    77db49300e67:	seto   al
    77db49300e6a:	mov    WORD PTR [rsp],ax
    77db49300e6e:	mov    rax,r11
    77db49300e71:	jmp    0x77db49300e89
    77db49300e76:	mov    r11,rax
    77db49300e79:	lahf
    77db49300e7a:	seto   al
    77db49300e7d:	mov    WORD PTR [rsp],ax
    77db49300e81:	mov    rax,r11
    77db49300e84:	jmp    0x77db49300f15
    77db49300e89:	mov    r13,QWORD PTR [r12+0xf8]
    77db49300e91:	mov    r14,r13
    77db49300e94:	add    r14,0x100
    77db49300e9b:	mov    QWORD PTR [r12],r14
    77db49300e9f:	add    r13,0x178
    77db49300ea6:	mov    QWORD PTR [r12+0x8],r13
    77db49300eab:	mov    r13d,0x1
    77db49300eb1:	mov    QWORD PTR [r12+0x10],r13
    77db49300eb6:	mov    r13d,0x4102c8
    77db49300ebc:	mov    QWORD PTR [r12+0xf0],r13
    77db49300ec4:	mov    r13d,0x410728
    77db49300eca:	mov    QWORD PTR [r12+0x100],r13
    77db49300ed2:	mov    r11,QWORD PTR [rsp]
    77db49300ed6:	mov    QWORD PTR [r12+0x398],r11
    77db49300ede:	mov    edi,0x410728
    77db49300ee3:	mov    QWORD PTR [r12+0x100],rdi
    77db49300eeb:	add    rsp,0x10
    77db49300eef:	nop
    77db49300ef0:	jmp    QWORD PTR [rip+0x2]        # 0x77db49300ef8
    77db49300ef6:	xchg   ax,ax
    77db49300ef8:	loopne 0x77db49300edf
    77db49300efa:	(bad)
    77db49300efb:	rex.WB (bad) [r15+0x0]
    77db49300eff:	add    BYTE PTR [rax],cl
    77db49300f01:	wrmsr
    77db49300f03:	rex.WB (bad) [r15+0x0]
    77db49300f07:	add    BYTE PTR [rcx-0x45],cl
    77db49300f0a:	rex cdq
    77db49300f0c:	mov    eax,0x60ebc8
    77db49300f11:	add    BYTE PTR [rcx-0x1],al
    77db49300f14:	jrcxz  0x77db49300f63
    77db49300f16:	mov    ebp,DWORD PTR [rsp+0x98]
    77db49300f1d:	ror    r13,0x3d
    77db49300f21:	and    r13,0xfffffffffffffff8
    77db49300f25:	mov    r14,QWORD PTR [r12+0xf8]
    77db49300f2d:	mov    r15,r14
    77db49300f30:	add    r15,0x100
    77db49300f37:	mov    QWORD PTR [r12],r15
    77db49300f3b:	mov    r15,r14
    77db49300f3e:	add    r15,0x170
    77db49300f45:	mov    QWORD PTR [r12+0x8],r15
    77db49300f4a:	mov    r15d,0x8
    77db49300f50:	mov    QWORD PTR [r12+0x10],r15
    77db49300f55:	movabs rcx,0xff00ff00ff00ff
    77db49300f5f:	mov    r15,r13
    77db49300f62:	and    r15,rcx
    77db49300f65:	shl    r15,0x8
    77db49300f69:	movabs rcx,0xff00ff00ff00ff00
    77db49300f73:	and    r13,rcx
    77db49300f76:	shr    r13,0x8
    77db49300f7a:	or     r13,r15
    77db49300f7d:	movabs rcx,0xffff0000ffff
    77db49300f87:	mov    r15,r13
    77db49300f8a:	and    r15,rcx
    77db49300f8d:	shl    r15,0x10
    77db49300f91:	movabs rcx,0xffff0000ffff0000
    77db49300f9b:	and    r13,rcx
    77db49300f9e:	shr    r13,0x10
    77db49300fa2:	or     r13,r15
    77db49300fa5:	mov    r15,r13
    77db49300fa8:	shl    r15,0x20
    77db49300fac:	shr    r13,0x20
    77db49300fb0:	or     r13,r15
    77db49300fb3:	mov    QWORD PTR [r12+0x40],r13
    77db49300fb8:	add    r14,0x170
    77db49300fbf:	mov    QWORD PTR [r14],r13
    77db49300fc2:	mov    r13d,0x0
    77db49300fc8:	mov    DWORD PTR [r12+0x32c],r13d
    77db49300fd0:	mov    r13d,0x4102f0
    77db49300fd6:	mov    QWORD PTR [r12+0xf0],r13
    77db49300fde:	mov    r13d,0x410728
    77db49300fe4:	mov    QWORD PTR [r12+0x100],r13
    77db49300fec:	mov    r11,QWORD PTR [rsp]
    77db49300ff0:	mov    QWORD PTR [r12+0x398],r11
    77db49300ff8:	mov    edi,0x410728
    77db49300ffd:	mov    QWORD PTR [r12+0x100],rdi
    77db49301005:	add    rsp,0x10
    77db49301009:	nop    DWORD PTR [rax+0x0]
    77db49301010:	jmp    QWORD PTR [rip+0x2]        # 0x77db49301018
    77db49301016:	xchg   ax,ax
    77db49301018:	loopne 0x77db49300fff
    77db4930101a:	(bad)
    77db4930101b:	rex.WB (bad) [r15+0x0]
    77db4930101f:	add    BYTE PTR [rax],ch
    77db49301021:	adc    BYTE PTR [rax],dh
    77db49301023:	rex.WB (bad) [r15+0x0]
    77db49301027:	add    BYTE PTR [rcx-0x45],cl
    77db4930102a:	rex cdq
    77db4930102c:	mov    eax,0x60ebc8
    77db49301031:	add    BYTE PTR [rcx-0x1],al
    77db49301034:	jrcxz  0x77db4930109c
    77db49301036:	data16 nop WORD PTR [rax+rax*1+0x0]
    77db49301040:	sub    rsp,0x10
    77db49301044:	mov    r11,QWORD PTR [r12+0x398]
    77db4930104c:	mov    QWORD PTR [rsp],r11
    77db49301050:	jmp    0x77db49300e89
    77db49301055:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49301060:	sub    rsp,0x10
    77db49301064:	mov    r11,QWORD PTR [r12+0x398]
    77db4930106c:	mov    QWORD PTR [rsp],r11
    77db49301070:	jmp    0x77db49300f15
    77db49301075:	nop
    77db49301076:	nop
    77db49301077:	nop
