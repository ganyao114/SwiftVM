
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/1/6.bin:     file format binary


Disassembly of section .data:

00007c479db01740 <.data>:
    7c479db01740:	sub    rsp,0x10
    7c479db01744:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0174c:	mov    QWORD PTR [rsp],r11
    7c479db01750:	mov    r13d,DWORD PTR [r12]
    7c479db01754:	mov    r14d,r13d
    7c479db01757:	mov    r14d,r14d
    7c479db0175a:	shr    r14d,0x10
    7c479db0175e:	xor    r13d,r14d
    7c479db01761:	mov    QWORD PTR [r12+0x40],r13
    7c479db01766:	mov    r14d,0x352d
    7c479db0176c:	mov    QWORD PTR [r12+0x48],r14
    7c479db01771:	mov    r14d,0x352d
    7c479db01777:	mov    r15d,0x7feb
    7c479db0177d:	and    r15d,0xffff
    7c479db01784:	mov    rax,r14
    7c479db01787:	movabs rcx,0xffffffff0000ffff
    7c479db01791:	and    rax,rcx
    7c479db01794:	mov    rdx,r15
    7c479db01797:	shl    rdx,0x10
    7c479db0179b:	mov    ecx,0xffff0000
    7c479db017a0:	and    rdx,rcx
    7c479db017a3:	or     rax,rdx
    7c479db017a6:	mov    ebp,eax
    7c479db017a8:	mov    QWORD PTR [r12+0x48],rbp
    7c479db017ad:	mov    r14d,0x0
    7c479db017b3:	imul   r13d,ebp
    7c479db017b7:	mov    r15d,r14d
    7c479db017ba:	add    r15d,r13d
    7c479db017bd:	mov    QWORD PTR [r12+0x40],r15
    7c479db017c2:	mov    r13d,0xa68b
    7c479db017c8:	mov    QWORD PTR [r12+0x48],r13
    7c479db017cd:	mov    r13d,0xa68b
    7c479db017d3:	mov    r14d,0x846c
    7c479db017d9:	and    r14d,0xffff
    7c479db017e0:	mov    rax,r13
    7c479db017e3:	movabs rcx,0xffffffff0000ffff
    7c479db017ed:	and    rax,rcx
    7c479db017f0:	mov    rdx,r14
    7c479db017f3:	shl    rdx,0x10
    7c479db017f7:	mov    ecx,0xffff0000
    7c479db017fc:	and    rdx,rcx
    7c479db017ff:	or     rax,rdx
    7c479db01802:	mov    ebp,eax
    7c479db01804:	mov    QWORD PTR [r12+0x48],rbp
    7c479db01809:	mov    r13d,r15d
    7c479db0180c:	mov    r13d,r13d
    7c479db0180f:	shr    r13d,0xf
    7c479db01813:	xor    r15d,r13d
    7c479db01816:	mov    QWORD PTR [r12+0x40],r15
    7c479db0181b:	mov    r13d,0x0
    7c479db01821:	imul   r15d,ebp
    7c479db01825:	mov    r14d,r13d
    7c479db01828:	add    r14d,r15d
    7c479db0182b:	mov    QWORD PTR [r12+0x40],r14
    7c479db01830:	mov    r13d,r14d
    7c479db01833:	mov    r13d,r13d
    7c479db01836:	shr    r13d,0x10
    7c479db0183a:	xor    r14d,r13d
    7c479db0183d:	mov    QWORD PTR [r12],r14
    7c479db01841:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db01849:	jrcxz  0x7c479db01850
    7c479db0184b:	jmp    0x7c479db01885
    7c479db01850:	mov    r13,QWORD PTR [r12+0xf0]
    7c479db01858:	mov    QWORD PTR [r12+0x100],r13
    7c479db01860:	mov    r11,QWORD PTR [rsp]
    7c479db01864:	mov    QWORD PTR [r12+0x398],r11
    7c479db0186c:	mov    rdi,QWORD PTR [r12+0x100]
    7c479db01874:	add    rsp,0x10
    7c479db01878:	movabs r11,0x62fe87327940
    7c479db01882:	jmp    r11
    7c479db01885:	mov    eax,0x4109c8
    7c479db0188a:	mov    QWORD PTR [r12+0x100],rax
    7c479db01892:	push   rdx
    7c479db01893:	push   rsi
    7c479db01894:	push   r10
    7c479db01896:	push   r11
    7c479db01898:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0189d:	mov    r10d,edx
    7c479db018a0:	and    r10d,0xc000
    7c479db018a7:	shl    r10d,0x10
    7c479db018ab:	mov    r11d,edx
    7c479db018ae:	and    r11d,0x100
    7c479db018b5:	shl    r11d,0x15
    7c479db018b9:	or     r10d,r11d
    7c479db018bc:	and    edx,0x1
    7c479db018bf:	shl    edx,0x1c
    7c479db018c2:	or     r10d,edx
    7c479db018c5:	btc    r10,0x1d
    7c479db018ca:	mov    r11d,0xf0000000
    7c479db018d0:	and    r11,r10
    7c479db018d3:	movabs rsi,0xffffffff0fffffff
    7c479db018dd:	and    rbx,rsi
    7c479db018e0:	or     rbx,r11
    7c479db018e3:	pop    r11
    7c479db018e5:	pop    r10
    7c479db018e7:	pop    rsi
    7c479db018e8:	pop    rdx
    7c479db018e9:	mov    QWORD PTR [r12+0x108],rbx
    7c479db018f1:	add    rsp,0x10
    7c479db018f5:	mov    eax,0xc
    7c479db018fa:	movabs r11,0x62fe87327ca0
    7c479db01904:	jmp    r11
    7c479db01907:	nop
