
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/0/4.bin:     file format binary


Disassembly of section .data:

000077db49301080 <.data>:
    77db49301080:	sub    rsp,0x10
    77db49301084:	mov    r11,QWORD PTR [r12+0x398]
    77db4930108c:	mov    QWORD PTR [rsp],r11
    77db49301090:	mov    r13,QWORD PTR [r12+0xf8]
    77db49301098:	add    r13,0x168
    77db4930109f:	mov    r14,QWORD PTR [r13+0x0]
    77db493010a3:	mov    QWORD PTR [r12+0x40],r14
    77db493010a8:	sub    r14,0x38
    77db493010ac:	mov    rcx,QWORD PTR [r12+0x380]
    77db493010b4:	jrcxz  0x77db493010bb
    77db493010b6:	jmp    0x77db4930118d
    77db493010bb:	jne    0x77db493010d4
    77db493010c1:	mov    r11,rax
    77db493010c4:	lahf
    77db493010c5:	seto   al
    77db493010c8:	mov    WORD PTR [rsp],ax
    77db493010cc:	mov    rax,r11
    77db493010cf:	jmp    0x77db493010e7
    77db493010d4:	mov    r11,rax
    77db493010d7:	lahf
    77db493010d8:	seto   al
    77db493010db:	mov    WORD PTR [rsp],ax
    77db493010df:	mov    rax,r11
    77db493010e2:	jmp    0x77db4930113d
    77db493010e7:	mov    r13d,0x4102d4
    77db493010ed:	mov    QWORD PTR [r12+0x100],r13
    77db493010f5:	mov    r11,QWORD PTR [rsp]
    77db493010f9:	mov    QWORD PTR [r12+0x398],r11
    77db49301101:	mov    edi,0x4102d4
    77db49301106:	mov    QWORD PTR [r12+0x100],rdi
    77db4930110e:	add    rsp,0x10
    77db49301112:	nop    WORD PTR [rax+rax*1+0x0]
    77db49301118:	jmp    QWORD PTR [rip+0x2]        # 0x77db49301120
    77db4930111e:	xchg   ax,ax
    77db49301120:	(bad)
    77db49301121:	adc    BYTE PTR [rax],dh
    77db49301123:	rex.WB (bad) [r15+0x0]
    77db49301127:	add    BYTE PTR [rax],dh
    77db49301129:	adc    DWORD PTR [rax],esi
    77db4930112b:	rex.WB (bad) [r15+0x0]
    77db4930112f:	add    BYTE PTR [rcx-0x45],cl
    77db49301132:	rex cdq
    77db49301134:	mov    eax,0x60ebc8
    77db49301139:	add    BYTE PTR [rcx-0x1],al
    77db4930113c:	jrcxz  0x77db4930117f
    77db4930113e:	mov    ebp,0x4102b8
    77db49301143:	mov    QWORD PTR [r12+0x100],r13
    77db4930114b:	mov    r11,QWORD PTR [rsp]
    77db4930114f:	mov    QWORD PTR [r12+0x398],r11
    77db49301157:	mov    edi,0x4102b8
    77db4930115c:	mov    QWORD PTR [r12+0x100],rdi
    77db49301164:	add    rsp,0x10
    77db49301168:	jmp    QWORD PTR [rip+0x2]        # 0x77db49301170
    77db4930116e:	xchg   ax,ax
    77db49301170:	adc    BYTE PTR [rax],sil
    77db49301173:	rex.WB (bad) [r15+0x0]
    77db49301177:	add    BYTE PTR [rax-0x24b6cfef],al
    77db4930117d:	ja     0x77db4930117f
    77db4930117f:	add    BYTE PTR [rcx-0x45],cl
    77db49301182:	rex cdq
    77db49301184:	mov    eax,0x60ebc8
    77db49301189:	add    BYTE PTR [rcx-0x1],al
    77db4930118c:	jrcxz  0x77db49301146
    77db4930118e:	rol    BYTE PTR [rdx],1
    77db49301190:	add    BYTE PTR [r9-0x77],cl
    77db49301194:	test   BYTE PTR [rax+rax*1],ah
    77db49301197:	add    DWORD PTR [rax],eax
    77db49301199:	add    BYTE PTR [rdx+0x56],dl
    77db4930119c:	push   r10
    77db4930119e:	push   r11
    77db493011a0:	mov    r11,rax
    77db493011a3:	lahf
    77db493011a4:	seto   al
    77db493011a7:	mov    WORD PTR [rsp+0x20],ax
    77db493011ac:	mov    rax,r11
    77db493011af:	mov    rdx,QWORD PTR [rsp+0x20]
    77db493011b4:	mov    r10d,edx
    77db493011b7:	and    r10d,0xc000
    77db493011be:	shl    r10d,0x10
    77db493011c2:	mov    r11d,edx
    77db493011c5:	and    r11d,0x100
    77db493011cc:	shl    r11d,0x15
    77db493011d0:	or     r10d,r11d
    77db493011d3:	and    edx,0x1
    77db493011d6:	shl    edx,0x1c
    77db493011d9:	or     r10d,edx
    77db493011dc:	btc    r10,0x1d
    77db493011e1:	mov    r11d,0xf0000000
    77db493011e7:	and    r11,r10
    77db493011ea:	movabs rsi,0xffffffff0fffffff
    77db493011f4:	and    rbx,rsi
    77db493011f7:	or     rbx,r11
    77db493011fa:	pop    r11
    77db493011fc:	pop    r10
    77db493011fe:	pop    rsi
    77db493011ff:	pop    rdx
    77db49301200:	mov    QWORD PTR [r12+0x108],rbx
    77db49301208:	add    rsp,0x10
    77db4930120c:	mov    eax,0xc
    77db49301211:	movabs r11,0x60ebc8b89ca0
    77db4930121b:	jmp    r11
    77db4930121e:	nop
    77db4930121f:	nop
