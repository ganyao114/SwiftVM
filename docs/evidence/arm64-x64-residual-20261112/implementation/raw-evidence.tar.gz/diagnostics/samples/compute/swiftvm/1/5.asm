
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/1/5.bin:     file format binary


Disassembly of section .data:

00007c479db01220 <.data>:
    7c479db01220:	sub    rsp,0x10
    7c479db01224:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0122c:	mov    QWORD PTR [rsp],r11
    7c479db01230:	mov    rax,QWORD PTR [r12+0xf8]
    7c479db01238:	mov    r14,QWORD PTR [r12+0xf8]
    7c479db01240:	add    r14,0x100
    7c479db01247:	mov    r15d,DWORD PTR [r14]
    7c479db0124a:	mov    QWORD PTR [r12+0x40],r15
    7c479db0124f:	mov    r14,QWORD PTR [r12+0xf8]
    7c479db01257:	add    r14,0x104
    7c479db0125e:	mov    ebp,DWORD PTR [r14]
    7c479db01261:	mov    QWORD PTR [r12+0x50],rbp
    7c479db01266:	mov    r14d,0x430c90
    7c479db0126c:	mov    QWORD PTR [r12+0x48],r14
    7c479db01271:	mov    r14,QWORD PTR [r12+0xf8]
    7c479db01279:	add    r14,0x108
    7c479db01280:	mov    r8d,DWORD PTR [r14]
    7c479db01283:	mov    QWORD PTR [r12+0x58],r8
    7c479db01288:	mov    r14,QWORD PTR [r12+0xf8]
    7c479db01290:	add    r14,0x10c
    7c479db01297:	mov    eax,DWORD PTR [r14]
    7c479db0129a:	mov    QWORD PTR [r12+0x60],rax
    7c479db0129f:	movabs rcx,0xff00ff00ff00ff
    7c479db012a9:	mov    r14,r15
    7c479db012ac:	and    r14,rcx
    7c479db012af:	shl    r14,0x8
    7c479db012b3:	movabs rcx,0xff00ff00ff00ff00
    7c479db012bd:	mov    r13,r15
    7c479db012c0:	and    r13,rcx
    7c479db012c3:	shr    r13,0x8
    7c479db012c7:	or     r13,r14
    7c479db012ca:	movabs rcx,0xffff0000ffff
    7c479db012d4:	mov    r14,r13
    7c479db012d7:	and    r14,rcx
    7c479db012da:	shl    r14,0x10
    7c479db012de:	movabs rcx,0xffff0000ffff0000
    7c479db012e8:	and    r13,rcx
    7c479db012eb:	shr    r13,0x10
    7c479db012ef:	or     r13,r14
    7c479db012f2:	mov    ecx,0xffffffff
    7c479db012f7:	and    r13,rcx
    7c479db012fa:	mov    QWORD PTR [r12+0x40],r13
    7c479db012ff:	movabs rcx,0xff00ff00ff00ff
    7c479db01309:	mov    r14,rbp
    7c479db0130c:	and    r14,rcx
    7c479db0130f:	shl    r14,0x8
    7c479db01313:	movabs rcx,0xff00ff00ff00ff00
    7c479db0131d:	mov    r15,rbp
    7c479db01320:	and    r15,rcx
    7c479db01323:	shr    r15,0x8
    7c479db01327:	or     r15,r14
    7c479db0132a:	movabs rcx,0xffff0000ffff
    7c479db01334:	mov    r14,r15
    7c479db01337:	and    r14,rcx
    7c479db0133a:	shl    r14,0x10
    7c479db0133e:	movabs rcx,0xffff0000ffff0000
    7c479db01348:	and    r15,rcx
    7c479db0134b:	shr    r15,0x10
    7c479db0134f:	or     r15,r14
    7c479db01352:	mov    ecx,0xffffffff
    7c479db01357:	and    r15,rcx
    7c479db0135a:	mov    QWORD PTR [r12+0x50],r15
    7c479db0135f:	mov    r14d,0x0
    7c479db01365:	mov    QWORD PTR [r12+0xa0],r14
    7c479db0136d:	mov    r14d,0x430c90
    7c479db01373:	mov    ebp,0x430c94
    7c479db01378:	mov    rax,r13
    7c479db0137b:	mov    eax,eax
    7c479db0137d:	mov    r9d,eax
    7c479db01380:	mov    rax,r15
    7c479db01383:	mov    eax,eax
    7c479db01385:	mov    r13d,eax
    7c479db01388:	mov    DWORD PTR [r14],r9d
    7c479db0138b:	mov    r14d,0x0
    7c479db01391:	mov    DWORD PTR [r12+0x32c],r14d
    7c479db01399:	mov    DWORD PTR [rbp+0x0],r13d
    7c479db0139d:	movabs rcx,0xff00ff00ff00ff
    7c479db013a7:	mov    r13,r8
    7c479db013aa:	and    r13,rcx
    7c479db013ad:	shl    r13,0x8
    7c479db013b1:	movabs rcx,0xff00ff00ff00ff00
    7c479db013bb:	mov    r14,r8
    7c479db013be:	and    r14,rcx
    7c479db013c1:	shr    r14,0x8
    7c479db013c5:	or     r14,r13
    7c479db013c8:	movabs rcx,0xffff0000ffff
    7c479db013d2:	mov    r13,r14
    7c479db013d5:	and    r13,rcx
    7c479db013d8:	shl    r13,0x10
    7c479db013dc:	movabs rcx,0xffff0000ffff0000
    7c479db013e6:	and    r14,rcx
    7c479db013e9:	shr    r14,0x10
    7c479db013ed:	or     r14,r13
    7c479db013f0:	mov    ecx,0xffffffff
    7c479db013f5:	and    r14,rcx
    7c479db013f8:	mov    QWORD PTR [r12+0x40],r14
    7c479db013fd:	mov    r13,QWORD PTR [r12+0xf8]
    7c479db01405:	add    r13,0x110
    7c479db0140c:	mov    r15d,DWORD PTR [r13+0x0]
    7c479db01410:	mov    QWORD PTR [r12+0x50],r15
    7c479db01415:	movabs rcx,0xff00ff00ff00ff
    7c479db0141f:	mov    r13d,DWORD PTR [r12+0x60]
    7c479db01424:	and    r13,rcx
    7c479db01427:	shl    r13,0x8
    7c479db0142b:	movabs rcx,0xff00ff00ff00ff00
    7c479db01435:	mov    ebp,DWORD PTR [r12+0x60]
    7c479db0143a:	and    rbp,rcx
    7c479db0143d:	shr    rbp,0x8
    7c479db01441:	or     rbp,r13
    7c479db01444:	movabs rcx,0xffff0000ffff
    7c479db0144e:	mov    r13,rbp
    7c479db01451:	and    r13,rcx
    7c479db01454:	shl    r13,0x10
    7c479db01458:	movabs rcx,0xffff0000ffff0000
    7c479db01462:	and    rbp,rcx
    7c479db01465:	shr    rbp,0x10
    7c479db01469:	or     rbp,r13
    7c479db0146c:	mov    ecx,0xffffffff
    7c479db01471:	and    rbp,rcx
    7c479db01474:	mov    QWORD PTR [r12+0x58],rbp
    7c479db01479:	mov    r13,QWORD PTR [r12+0xf8]
    7c479db01481:	add    r13,0x114
    7c479db01488:	mov    eax,DWORD PTR [r13+0x0]
    7c479db0148c:	mov    QWORD PTR [r12+0x60],rax
    7c479db01491:	mov    r13d,0x430000
    7c479db01497:	add    r13,0xdfc
    7c479db0149e:	mov    QWORD PTR [r12+0x98],r13
    7c479db014a6:	mov    r13d,0x430c98
    7c479db014ac:	mov    r9d,0x430c9c
    7c479db014b2:	mov    rax,r14
    7c479db014b5:	mov    eax,eax
    7c479db014b7:	mov    r8d,eax
    7c479db014ba:	mov    rax,rbp
    7c479db014bd:	mov    eax,eax
    7c479db014bf:	mov    r14d,eax
    7c479db014c2:	mov    DWORD PTR [r13+0x0],r8d
    7c479db014c6:	mov    DWORD PTR [r9],r14d
    7c479db014c9:	movabs rcx,0xff00ff00ff00ff
    7c479db014d3:	mov    r13,r15
    7c479db014d6:	and    r13,rcx
    7c479db014d9:	shl    r13,0x8
    7c479db014dd:	movabs rcx,0xff00ff00ff00ff00
    7c479db014e7:	mov    r14,r15
    7c479db014ea:	and    r14,rcx
    7c479db014ed:	shr    r14,0x8
    7c479db014f1:	or     r14,r13
    7c479db014f4:	movabs rcx,0xffff0000ffff
    7c479db014fe:	mov    r13,r14
    7c479db01501:	and    r13,rcx
    7c479db01504:	shl    r13,0x10
    7c479db01508:	movabs rcx,0xffff0000ffff0000
    7c479db01512:	and    r14,rcx
    7c479db01515:	shr    r14,0x10
    7c479db01519:	or     r14,r13
    7c479db0151c:	mov    ecx,0xffffffff
    7c479db01521:	and    r14,rcx
    7c479db01524:	mov    QWORD PTR [r12+0x40],r14
    7c479db01529:	mov    r13,QWORD PTR [r12+0xf8]
    7c479db01531:	add    r13,0x118
    7c479db01538:	mov    r15d,DWORD PTR [r13+0x0]
    7c479db0153c:	mov    QWORD PTR [r12+0x50],r15
    7c479db01541:	movabs rcx,0xff00ff00ff00ff
    7c479db0154b:	mov    r13d,DWORD PTR [r12+0x60]
    7c479db01550:	and    r13,rcx
    7c479db01553:	shl    r13,0x8
    7c479db01557:	movabs rcx,0xff00ff00ff00ff00
    7c479db01561:	mov    ebp,DWORD PTR [r12+0x60]
    7c479db01566:	and    rbp,rcx
    7c479db01569:	shr    rbp,0x8
    7c479db0156d:	or     rbp,r13
    7c479db01570:	movabs rcx,0xffff0000ffff
    7c479db0157a:	mov    r13,rbp
    7c479db0157d:	and    r13,rcx
    7c479db01580:	shl    r13,0x10
    7c479db01584:	movabs rcx,0xffff0000ffff0000
    7c479db0158e:	and    rbp,rcx
    7c479db01591:	shr    rbp,0x10
    7c479db01595:	or     rbp,r13
    7c479db01598:	mov    ecx,0xffffffff
    7c479db0159d:	and    rbp,rcx
    7c479db015a0:	mov    QWORD PTR [r12+0x58],rbp
    7c479db015a5:	mov    r13,QWORD PTR [r12+0xf8]
    7c479db015ad:	add    r13,0x11c
    7c479db015b4:	mov    eax,DWORD PTR [r13+0x0]
    7c479db015b8:	mov    QWORD PTR [r12+0x60],rax
    7c479db015bd:	mov    r13d,0x430ca0
    7c479db015c3:	mov    r9d,0x430ca4
    7c479db015c9:	mov    rax,r14
    7c479db015cc:	mov    eax,eax
    7c479db015ce:	mov    r8d,eax
    7c479db015d1:	mov    rax,rbp
    7c479db015d4:	mov    eax,eax
    7c479db015d6:	mov    r14d,eax
    7c479db015d9:	mov    DWORD PTR [r13+0x0],r8d
    7c479db015dd:	mov    DWORD PTR [r9],r14d
    7c479db015e0:	movabs rcx,0xff00ff00ff00ff
    7c479db015ea:	mov    r13,r15
    7c479db015ed:	and    r13,rcx
    7c479db015f0:	shl    r13,0x8
    7c479db015f4:	movabs rcx,0xff00ff00ff00ff00
    7c479db015fe:	mov    r14,r15
    7c479db01601:	and    r14,rcx
    7c479db01604:	shr    r14,0x8
    7c479db01608:	or     r14,r13
    7c479db0160b:	movabs rcx,0xffff0000ffff
    7c479db01615:	mov    r13,r14
    7c479db01618:	and    r13,rcx
    7c479db0161b:	shl    r13,0x10
    7c479db0161f:	movabs rcx,0xffff0000ffff0000
    7c479db01629:	and    r14,rcx
    7c479db0162c:	shr    r14,0x10
    7c479db01630:	or     r14,r13
    7c479db01633:	mov    ecx,0xffffffff
    7c479db01638:	and    r14,rcx
    7c479db0163b:	mov    QWORD PTR [r12+0x40],r14
    7c479db01640:	movabs rcx,0xff00ff00ff00ff
    7c479db0164a:	mov    r13d,DWORD PTR [r12+0x60]
    7c479db0164f:	and    r13,rcx
    7c479db01652:	shl    r13,0x8
    7c479db01656:	movabs rcx,0xff00ff00ff00ff00
    7c479db01660:	mov    r15d,DWORD PTR [r12+0x60]
    7c479db01665:	and    r15,rcx
    7c479db01668:	shr    r15,0x8
    7c479db0166c:	or     r15,r13
    7c479db0166f:	movabs rcx,0xffff0000ffff
    7c479db01679:	mov    r13,r15
    7c479db0167c:	and    r13,rcx
    7c479db0167f:	shl    r13,0x10
    7c479db01683:	movabs rcx,0xffff0000ffff0000
    7c479db0168d:	and    r15,rcx
    7c479db01690:	shr    r15,0x10
    7c479db01694:	or     r15,r13
    7c479db01697:	mov    ecx,0xffffffff
    7c479db0169c:	and    r15,rcx
    7c479db0169f:	mov    QWORD PTR [r12+0x50],r15
    7c479db016a4:	mov    r13d,0x430ca8
    7c479db016aa:	mov    ebp,0x430cac
    7c479db016af:	mov    rax,r14
    7c479db016b2:	mov    eax,eax
    7c479db016b4:	mov    r8d,eax
    7c479db016b7:	mov    rax,r15
    7c479db016ba:	mov    eax,eax
    7c479db016bc:	mov    r14d,eax
    7c479db016bf:	mov    DWORD PTR [r13+0x0],r8d
    7c479db016c3:	mov    DWORD PTR [rbp+0x0],r14d
    7c479db016c7:	mov    r13d,0x11
    7c479db016cd:	mov    QWORD PTR [r12],r13
    7c479db016d1:	mov    r13d,0x41035c
    7c479db016d7:	mov    QWORD PTR [r12+0xf0],r13
    7c479db016df:	mov    r13d,0x4109a4
    7c479db016e5:	mov    QWORD PTR [r12+0x100],r13
    7c479db016ed:	mov    r11,QWORD PTR [rsp]
    7c479db016f1:	mov    QWORD PTR [r12+0x398],r11
    7c479db016f9:	mov    edi,0x4109a4
    7c479db016fe:	mov    QWORD PTR [r12+0x100],rdi
    7c479db01706:	add    rsp,0x10
    7c479db0170a:	nop    WORD PTR [rax+rax*1+0x0]
    7c479db01710:	jmp    QWORD PTR [rip+0x2]        # 0x7c479db01718
    7c479db01716:	xchg   ax,ax
    7c479db01718:	rex (bad)
    7c479db0171a:	mov    al,0x9d
    7c479db0171c:	rex.RXB jl 0x7c479db0171f
    7c479db0171f:	add    BYTE PTR [rax],ch
    7c479db01721:	(bad)
    7c479db01722:	mov    al,0x9d
    7c479db01724:	rex.RXB jl 0x7c479db01727
    7c479db01727:	add    BYTE PTR [rcx-0x45],cl
    7c479db0172a:	rex jns 0x7c479db0175f
    7c479db0172d:	xchg   esi,edi
    7c479db0172f:	(bad)
    7c479db01730:	add    BYTE PTR [rax],al
    7c479db01732:	jmp    r11
    7c479db01735:	nop
    7c479db01736:	nop
    7c479db01737:	nop
