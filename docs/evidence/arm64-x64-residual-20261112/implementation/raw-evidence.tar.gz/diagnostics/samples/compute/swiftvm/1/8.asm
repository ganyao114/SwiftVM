
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/1/8.bin:     file format binary


Disassembly of section .data:

00007c479db02170 <.data>:
    7c479db02170:	sub    rsp,0x150
    7c479db02177:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0217f:	mov    QWORD PTR [rsp],r11
    7c479db02183:	cmp    DWORD PTR [r12+0x310],0x0
    7c479db0218c:	je     0x7c479db02217
    7c479db02192:	push   rdx
    7c479db02193:	push   rsi
    7c479db02194:	push   r10
    7c479db02196:	push   r11
    7c479db02198:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0219d:	mov    r10d,edx
    7c479db021a0:	and    r10d,0xc000
    7c479db021a7:	shl    r10d,0x10
    7c479db021ab:	mov    r11d,edx
    7c479db021ae:	and    r11d,0x100
    7c479db021b5:	shl    r11d,0x15
    7c479db021b9:	or     r10d,r11d
    7c479db021bc:	and    edx,0x1
    7c479db021bf:	shl    edx,0x1c
    7c479db021c2:	or     r10d,edx
    7c479db021c5:	btc    r10,0x1d
    7c479db021ca:	mov    r11d,0xf0000000
    7c479db021d0:	and    r11,r10
    7c479db021d3:	movabs rsi,0xffffffff0fffffff
    7c479db021dd:	and    rbx,rsi
    7c479db021e0:	or     rbx,r11
    7c479db021e3:	pop    r11
    7c479db021e5:	pop    r10
    7c479db021e7:	pop    rsi
    7c479db021e8:	pop    rdx
    7c479db021e9:	mov    QWORD PTR [r12+0x108],rbx
    7c479db021f1:	mov    eax,0x4103f8
    7c479db021f6:	mov    QWORD PTR [r12+0x100],rax
    7c479db021fe:	add    rsp,0x150
    7c479db02205:	mov    eax,0x3
    7c479db0220a:	movabs r11,0x62fe87327ca0
    7c479db02214:	jmp    r11
    7c479db02217:	mov    r13d,DWORD PTR [r12+0x98]
    7c479db0221f:	add    r13d,0x1
    7c479db02223:	mov    QWORD PTR [r12+0x98],r13
    7c479db0222b:	sub    r13d,0x10000
    7c479db02232:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db0223a:	jrcxz  0x7c479db02241
    7c479db0223c:	jmp    0x7c479db0bbf5
    7c479db02241:	jne    0x7c479db0225a
    7c479db02247:	mov    r11,rax
    7c479db0224a:	lahf
    7c479db0224b:	seto   al
    7c479db0224e:	mov    WORD PTR [rsp],ax
    7c479db02252:	mov    rax,r11
    7c479db02255:	jmp    0x7c479db0226d
    7c479db0225a:	mov    r11,rax
    7c479db0225d:	lahf
    7c479db0225e:	seto   al
    7c479db02261:	mov    WORD PTR [rsp],ax
    7c479db02265:	mov    rax,r11
    7c479db02268:	jmp    0x7c479db04d43
    7c479db0226d:	mov    r13d,0x420000
    7c479db02273:	mov    QWORD PTR [r12+0x40],r13
    7c479db02278:	movabs r13,0x100000001
    7c479db02282:	mov    r14d,0x0
    7c479db02288:	mov    QWORD PTR [r12+0x110],r13
    7c479db02290:	mov    QWORD PTR [r12+0x118],r14
    7c479db02298:	movabs r13,0x3fa0000000000000
    7c479db022a2:	mov    QWORD PTR [r12+0x50],r13
    7c479db022a7:	mov    r13d,0x420b10
    7c479db022ad:	mov    r14,QWORD PTR [r13+0x0]
    7c479db022b1:	mov    r13d,0x0
    7c479db022b7:	mov    QWORD PTR [r12+0x120],r14
    7c479db022bf:	mov    QWORD PTR [r12+0x128],r13
    7c479db022c7:	movabs r13,0x4100000041
    7c479db022d1:	mov    r14d,0x0
    7c479db022d7:	mov    QWORD PTR [r12+0x140],r13
    7c479db022df:	mov    QWORD PTR [r12+0x148],r14
    7c479db022e7:	movabs r13,0x3fc0000000000000
    7c479db022f1:	movabs r14,0x3fc0000000000000
    7c479db022fb:	mov    QWORD PTR [r12+0x150],r13
    7c479db02303:	mov    QWORD PTR [r12+0x158],r14
    7c479db0230b:	movabs r13,0x200000002
    7c479db02315:	mov    r14d,0x0
    7c479db0231b:	mov    QWORD PTR [r12+0x160],r13
    7c479db02323:	mov    QWORD PTR [r12+0x168],r14
    7c479db0232b:	movabs r13,0x3fa0000000000000
    7c479db02335:	mov    QWORD PTR [r12+0x130],r13
    7c479db0233d:	mov    QWORD PTR [r12+0x138],r13
    7c479db02345:	mov    r13d,0x2
    7c479db0234b:	mov    QWORD PTR [r12+0x170],r13
    7c479db02353:	mov    QWORD PTR [r12+0x178],r13
    7c479db0235b:	mov    r13d,0x420000
    7c479db02361:	mov    QWORD PTR [r12+0x40],r13
    7c479db02366:	mov    r13d,0x430000
    7c479db0236c:	mov    QWORD PTR [r12+0x50],r13
    7c479db02371:	mov    r13d,0x420a40
    7c479db02377:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c479db0237d:	movdqu XMMWORD PTR [r12+0x180],xmm2
    7c479db02387:	mov    r13d,0x0
    7c479db0238d:	mov    QWORD PTR [r12+0x48],r13
    7c479db02392:	mov    r13d,0x431000
    7c479db02398:	add    r13,0xe00
    7c479db0239f:	mov    QWORD PTR [r12+0x40],r13
    7c479db023a4:	mov    r13d,0x430cb8
    7c479db023aa:	mov    r14d,DWORD PTR [r12]
    7c479db023ae:	mov    DWORD PTR [r13+0x0],r14d
    7c479db023b2:	mov    r13d,0x0
    7c479db023b8:	mov    DWORD PTR [r12+0x32c],r13d
    7c479db023c0:	mov    r13d,0x432000
    7c479db023c6:	mov    QWORD PTR [r12+0x50],r13
    7c479db023cb:	mov    r11,rax
    7c479db023ce:	movzx  eax,WORD PTR [rsp]
    7c479db023d2:	add    al,0x7f
    7c479db023d4:	sahf
    7c479db023d5:	mov    rax,r11
    7c479db023d8:	jmp    0x7c479db023dd
    7c479db023dd:	mov    r13,QWORD PTR [r12+0x180]
    7c479db023e5:	mov    r14,QWORD PTR [r12+0x188]
    7c479db023ed:	mov    r15d,0x0
    7c479db023f3:	mov    r11,rax
    7c479db023f6:	lahf
    7c479db023f7:	seto   al
    7c479db023fa:	mov    WORD PTR [rsp],ax
    7c479db023fe:	mov    rax,r11
    7c479db02401:	mov    ecx,0xffffffff
    7c479db02406:	and    r13,rcx
    7c479db02409:	mov    rbp,r15
    7c479db0240c:	or     rbp,r13
    7c479db0240f:	mov    ecx,0xffffffff
    7c479db02414:	and    r14,rcx
    7c479db02417:	shl    r14,0x20
    7c479db0241b:	or     rbp,r14
    7c479db0241e:	mov    QWORD PTR [r12+0x210],rbp
    7c479db02426:	mov    QWORD PTR [r12+0x218],r15
    7c479db0242e:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    7c479db02438:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    7c479db02442:	movdqa xmm1,xmm3
    7c479db02446:	psubd  xmm2,xmm1
    7c479db0244a:	movdqa xmm14,xmm2
    7c479db0244f:	movdqa xmm1,xmm14
    7c479db02454:	movq   rax,xmm1
    7c479db02459:	mov    r13,rax
    7c479db0245c:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    7c479db02466:	movdqu xmm4,XMMWORD PTR [r12+0x170]
    7c479db02470:	movdqa xmm1,xmm4
    7c479db02474:	paddq  xmm2,xmm1
    7c479db02478:	movdqu XMMWORD PTR [r12+0x180],xmm2
    7c479db02482:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    7c479db0248c:	movdqa xmm1,xmm2
    7c479db02490:	paddd  xmm3,xmm1
    7c479db02494:	movdqa xmm14,xmm3
    7c479db02499:	movdqa xmm1,xmm14
    7c479db0249e:	movq   rax,xmm1
    7c479db024a3:	mov    r14,rax
    7c479db024a6:	mov    r15d,0x0
    7c479db024ac:	mov    QWORD PTR [r12+0x120],r14
    7c479db024b4:	mov    QWORD PTR [r12+0x128],r15
    7c479db024bc:	mov    r14d,0x0
    7c479db024c2:	mov    ecx,0xffffffff
    7c479db024c7:	mov    r15,r13
    7c479db024ca:	and    r15,rcx
    7c479db024cd:	mov    rbp,r14
    7c479db024d0:	or     rbp,r15
    7c479db024d3:	shr    r13,0x20
    7c479db024d7:	mov    ecx,0xffffffff
    7c479db024dc:	and    r13,rcx
    7c479db024df:	or     r14,r13
    7c479db024e2:	mov    QWORD PTR [r12+0x220],rbp
    7c479db024ea:	mov    QWORD PTR [r12+0x228],r14
    7c479db024f2:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    7c479db024fc:	movdqu xmm3,XMMWORD PTR [r12+0x110]
    7c479db02506:	movdqa xmm1,xmm3
    7c479db0250a:	paddd  xmm2,xmm1
    7c479db0250e:	movdqa xmm14,xmm2
    7c479db02513:	movdqa xmm1,xmm14
    7c479db02518:	movq   rax,xmm1
    7c479db0251d:	mov    r13,rax
    7c479db02520:	mov    r14d,0x0
    7c479db02526:	mov    QWORD PTR [r12+0x210],r13
    7c479db0252e:	mov    QWORD PTR [r12+0x218],r14
    7c479db02536:	lea    r13,[r12]
    7c479db0253a:	movabs r14,0xb6e61da31
    7c479db02544:	mov    r15d,0x410468
    7c479db0254a:	mov    rdx,QWORD PTR [rsp]
    7c479db0254e:	mov    r10d,edx
    7c479db02551:	and    r10d,0xc000
    7c479db02558:	shl    r10d,0x10
    7c479db0255c:	mov    r11d,edx
    7c479db0255f:	and    r11d,0x100
    7c479db02566:	shl    r11d,0x15
    7c479db0256a:	or     r10d,r11d
    7c479db0256d:	and    edx,0x1
    7c479db02570:	shl    edx,0x1c
    7c479db02573:	or     r10d,edx
    7c479db02576:	btc    r10,0x1d
    7c479db0257b:	mov    r11d,0xf0000000
    7c479db02581:	and    r11,r10
    7c479db02584:	movabs rsi,0xffffffff0fffffff
    7c479db0258e:	and    rbx,rsi
    7c479db02591:	or     rbx,r11
    7c479db02594:	mov    QWORD PTR [r12+0x378],0x3
    7c479db025a0:	mov    QWORD PTR [r12+0x108],rbx
    7c479db025a8:	stmxcsr DWORD PTR [r12-0x28]
    7c479db025ae:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db025b3:	test   r10d,0x3f
    7c479db025ba:	je     0x7c479db025df
    7c479db025c0:	mov    r11d,r10d
    7c479db025c3:	shr    r10d,1
    7c479db025c6:	and    r10d,0x1e
    7c479db025ca:	and    r11d,0x1
    7c479db025ce:	or     r10d,r11d
    7c479db025d1:	or     DWORD PTR [r12+0x314],r10d
    7c479db025d9:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db025df:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db025e5:	movabs r11,0x62fe871895e0
    7c479db025ef:	mov    rdi,r13
    7c479db025f2:	mov    rsi,r14
    7c479db025f5:	mov    rdx,r15
    7c479db025f8:	call   r11
    7c479db025fb:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db02601:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db02609:	mov    QWORD PTR [r12+0x378],0x2
    7c479db02615:	mov    rbp,rax
    7c479db02618:	mov    r13,QWORD PTR [r12+0x210]
    7c479db02620:	mov    r14d,0x0
    7c479db02626:	mov    ecx,0xffffffff
    7c479db0262b:	mov    r15,r13
    7c479db0262e:	and    r15,rcx
    7c479db02631:	mov    rbp,r14
    7c479db02634:	or     rbp,r15
    7c479db02637:	shr    r13,0x20
    7c479db0263b:	mov    ecx,0xffffffff
    7c479db02640:	and    r13,rcx
    7c479db02643:	or     r14,r13
    7c479db02646:	mov    QWORD PTR [r12+0x210],rbp
    7c479db0264e:	mov    QWORD PTR [r12+0x218],r14
    7c479db02656:	lea    r13,[r12]
    7c479db0265a:	movabs r14,0xb6e61da10
    7c479db02664:	mov    r15d,0x410470
    7c479db0266a:	mov    QWORD PTR [r12+0x378],0x3
    7c479db02676:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0267e:	stmxcsr DWORD PTR [r12-0x28]
    7c479db02684:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db02689:	test   r10d,0x3f
    7c479db02690:	je     0x7c479db026b5
    7c479db02696:	mov    r11d,r10d
    7c479db02699:	shr    r10d,1
    7c479db0269c:	and    r10d,0x1e
    7c479db026a0:	and    r11d,0x1
    7c479db026a4:	or     r10d,r11d
    7c479db026a7:	or     DWORD PTR [r12+0x314],r10d
    7c479db026af:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db026b5:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db026bb:	movabs r11,0x62fe871895e0
    7c479db026c5:	mov    rdi,r13
    7c479db026c8:	mov    rsi,r14
    7c479db026cb:	mov    rdx,r15
    7c479db026ce:	call   r11
    7c479db026d1:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db026d7:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db026df:	mov    QWORD PTR [r12+0x378],0x2
    7c479db026eb:	mov    rbp,rax
    7c479db026ee:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    7c479db026f8:	movdqu xmm3,XMMWORD PTR [r12+0x150]
    7c479db02702:	movdqa xmm0,xmm2
    7c479db02706:	movdqa xmm1,xmm3
    7c479db0270a:	mulpd  xmm0,xmm1
    7c479db0270e:	movdqa xmm14,xmm0
    7c479db02713:	movdqu xmm15,XMMWORD PTR [rip+0x9f34]        # 0x7c479db0c650
    7c479db0271c:	pand   xmm14,xmm15
    7c479db02721:	movdqu xmm15,XMMWORD PTR [rip+0x9f36]        # 0x7c479db0c660
    7c479db0272a:	pcmpeqq xmm14,xmm15
    7c479db02730:	movdqa xmm15,xmm0
    7c479db02735:	cmpunordpd xmm15,xmm0
    7c479db0273b:	por    xmm14,xmm15
    7c479db02740:	pmovmskb ecx,xmm14
    7c479db02745:	jrcxz  0x7c479db0274c
    7c479db02747:	jmp    0x7c479db04dbd
    7c479db0274c:	movdqa xmm4,xmm0
    7c479db02750:	movdqu XMMWORD PTR [r12+0x220],xmm4
    7c479db0275a:	mov    r13,QWORD PTR [r12+0x48]
    7c479db0275f:	mov    r14,QWORD PTR [r12+0x50]
    7c479db02764:	add    r14,r13
    7c479db02767:	movdqu XMMWORD PTR [r14],xmm4
    7c479db0276c:	mov    r14d,0x0
    7c479db02772:	mov    DWORD PTR [r12+0x32c],r14d
    7c479db0277a:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    7c479db02784:	movdqu xmm3,XMMWORD PTR [r12+0x130]
    7c479db0278e:	movdqa xmm0,xmm2
    7c479db02792:	movdqa xmm1,xmm3
    7c479db02796:	mulpd  xmm0,xmm1
    7c479db0279a:	movdqa xmm14,xmm0
    7c479db0279f:	movdqu xmm15,XMMWORD PTR [rip+0x9ea8]        # 0x7c479db0c650
    7c479db027a8:	pand   xmm14,xmm15
    7c479db027ad:	movdqu xmm15,XMMWORD PTR [rip+0x9eaa]        # 0x7c479db0c660
    7c479db027b6:	pcmpeqq xmm14,xmm15
    7c479db027bc:	movdqa xmm15,xmm0
    7c479db027c1:	cmpunordpd xmm15,xmm0
    7c479db027c7:	por    xmm14,xmm15
    7c479db027cc:	pmovmskb ecx,xmm14
    7c479db027d1:	jrcxz  0x7c479db027d8
    7c479db027d3:	jmp    0x7c479db04de1
    7c479db027d8:	movdqa xmm4,xmm0
    7c479db027dc:	movdqu XMMWORD PTR [r12+0x210],xmm4
    7c479db027e6:	mov    r14,QWORD PTR [r12+0x40]
    7c479db027eb:	add    r14,r13
    7c479db027ee:	movdqu XMMWORD PTR [r14],xmm4
    7c479db027f3:	add    r13,0x10
    7c479db027f7:	mov    QWORD PTR [r12+0x48],r13
    7c479db027fc:	sub    r13,0x200
    7c479db02803:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db0280b:	jrcxz  0x7c479db02812
    7c479db0280d:	jmp    0x7c479db0bc89
    7c479db02812:	jne    0x7c479db023dd
    7c479db02818:	mov    r11,rax
    7c479db0281b:	lahf
    7c479db0281c:	seto   al
    7c479db0281f:	mov    WORD PTR [rsp],ax
    7c479db02823:	mov    rax,r11
    7c479db02826:	jmp    0x7c479db0282b
    7c479db0282b:	mov    r13,QWORD PTR [r12+0x50]
    7c479db02830:	mov    r14,r13
    7c479db02833:	add    r14,0x80
    7c479db0283a:	mov    r15,r14
    7c479db0283d:	add    r15,0x10
    7c479db02841:	movdqu xmm2,XMMWORD PTR [r14]
    7c479db02846:	movdqu xmm3,XMMWORD PTR [r15]
    7c479db0284b:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c479db02855:	movdqu XMMWORD PTR [r12+0x110],xmm3
    7c479db0285f:	mov    r14d,0x0
    7c479db02865:	mov    r15d,0x0
    7c479db0286b:	mov    QWORD PTR [r12+0x1b0],r14
    7c479db02873:	mov    QWORD PTR [r12+0x1b8],r15
    7c479db0287b:	mov    r14,r13
    7c479db0287e:	add    r14,0x40
    7c479db02882:	mov    r15,r14
    7c479db02885:	add    r15,0x10
    7c479db02889:	movdqu xmm4,XMMWORD PTR [r14]
    7c479db0288e:	movdqu xmm5,XMMWORD PTR [r15]
    7c479db02893:	movdqu XMMWORD PTR [r12+0x250],xmm4
    7c479db0289d:	movdqu XMMWORD PTR [r12+0x120],xmm5
    7c479db028a7:	mov    r14d,0x0
    7c479db028ad:	mov    QWORD PTR [r12+0x48],r14
    7c479db028b2:	mov    r14,r13
    7c479db028b5:	add    r14,0x10
    7c479db028b9:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    7c479db028bf:	movdqu xmm6,XMMWORD PTR [r14]
    7c479db028c4:	movdqu XMMWORD PTR [r12+0x170],xmm4
    7c479db028ce:	movdqu XMMWORD PTR [r12+0x180],xmm6
    7c479db028d8:	mov    r14,QWORD PTR [r12+0xf8]
    7c479db028e0:	mov    r15,r14
    7c479db028e3:	add    r15,0xe0
    7c479db028ea:	mov    rbp,r15
    7c479db028ed:	add    rbp,0x10
    7c479db028f1:	movdqu XMMWORD PTR [r15],xmm3
    7c479db028f6:	mov    r15d,0x0
    7c479db028fc:	mov    DWORD PTR [r12+0x32c],r15d
    7c479db02904:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c479db02909:	mov    r15,r13
    7c479db0290c:	add    r15,0xc0
    7c479db02913:	mov    rbp,r15
    7c479db02916:	add    rbp,0x10
    7c479db0291a:	movdqu xmm2,XMMWORD PTR [r15]
    7c479db0291f:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c479db02924:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7c479db0292e:	movdqu XMMWORD PTR [r12+0x110],xmm3
    7c479db02938:	mov    r15,r13
    7c479db0293b:	add    r15,0x140
    7c479db02942:	mov    rbp,r15
    7c479db02945:	add    rbp,0x10
    7c479db02949:	movdqu xmm7,XMMWORD PTR [r15]
    7c479db0294e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    7c479db02954:	movdqu XMMWORD PTR [r12+0x270],xmm7
    7c479db0295e:	movdqu XMMWORD PTR [r12+0x190],xmm8
    7c479db02968:	mov    r15,r13
    7c479db0296b:	add    r15,0x180
    7c479db02972:	mov    rbp,r15
    7c479db02975:	add    rbp,0x10
    7c479db02979:	movdqu xmm7,XMMWORD PTR [r15]
    7c479db0297e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    7c479db02984:	movdqu XMMWORD PTR [r12+0x2a0],xmm7
    7c479db0298e:	movdqu XMMWORD PTR [r12+0x1a0],xmm8
    7c479db02998:	mov    r15,r14
    7c479db0299b:	add    r15,0xc0
    7c479db029a2:	mov    rbp,r15
    7c479db029a5:	add    rbp,0x10
    7c479db029a9:	movdqu XMMWORD PTR [r15],xmm3
    7c479db029ae:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c479db029b3:	mov    r15,r13
    7c479db029b6:	add    r15,0x100
    7c479db029bd:	mov    rbp,r15
    7c479db029c0:	add    rbp,0x10
    7c479db029c4:	movdqu xmm2,XMMWORD PTR [r15]
    7c479db029c9:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c479db029ce:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7c479db029d8:	movdqu XMMWORD PTR [r12+0x300],xmm3
    7c479db029e2:	mov    r15,r13
    7c479db029e5:	add    r15,0x1c0
    7c479db029ec:	mov    rbp,r15
    7c479db029ef:	add    rbp,0x10
    7c479db029f3:	movdqu xmm3,XMMWORD PTR [r15]
    7c479db029f8:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    7c479db029fd:	movdqu XMMWORD PTR [r12+0x240],xmm3
    7c479db02a07:	movdqu XMMWORD PTR [r12+0x1c0],xmm7
    7c479db02a11:	mov    r15,r13
    7c479db02a14:	add    r15,0x20
    7c479db02a18:	mov    rbp,r15
    7c479db02a1b:	add    rbp,0x10
    7c479db02a1f:	movdqu xmm7,XMMWORD PTR [r15]
    7c479db02a24:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    7c479db02a2a:	movdqu XMMWORD PTR [r12+0x1d0],xmm7
    7c479db02a34:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
    7c479db02a3e:	mov    r15,r14
    7c479db02a41:	add    r15,0x20
    7c479db02a45:	mov    rbp,r15
    7c479db02a48:	add    rbp,0x10
    7c479db02a4c:	movdqu XMMWORD PTR [r15],xmm2
    7c479db02a51:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    7c479db02a56:	mov    r15,r13
    7c479db02a59:	add    r15,0x60
    7c479db02a5d:	mov    rbp,r15
    7c479db02a60:	add    rbp,0x10
    7c479db02a64:	movdqu xmm2,XMMWORD PTR [r15]
    7c479db02a69:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    7c479db02a6e:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7c479db02a78:	movdqu XMMWORD PTR [r12+0x120],xmm5
    7c479db02a82:	mov    r15,r14
    7c479db02a85:	add    r15,0x60
    7c479db02a89:	mov    rbp,r15
    7c479db02a8c:	add    rbp,0x10
    7c479db02a90:	movdqu XMMWORD PTR [r15],xmm4
    7c479db02a95:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    7c479db02a9a:	mov    r15,r13
    7c479db02a9d:	add    r15,0xe0
    7c479db02aa4:	mov    rbp,r15
    7c479db02aa7:	add    rbp,0x10
    7c479db02aab:	movdqu xmm3,XMMWORD PTR [r15]
    7c479db02ab0:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    7c479db02ab5:	movdqu XMMWORD PTR [r12+0x200],xmm3
    7c479db02abf:	movdqu XMMWORD PTR [r12+0x2d0],xmm4
    7c479db02ac9:	mov    r15,r13
    7c479db02acc:	add    r15,0x120
    7c479db02ad3:	mov    rbp,r15
    7c479db02ad6:	add    rbp,0x10
    7c479db02ada:	movdqu xmm3,XMMWORD PTR [r15]
    7c479db02adf:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    7c479db02ae4:	movdqu XMMWORD PTR [r12+0x2e0],xmm3
    7c479db02aee:	movdqu XMMWORD PTR [r12+0x2f0],xmm4
    7c479db02af8:	mov    r15,r14
    7c479db02afb:	add    r15,0xa0
    7c479db02b02:	mov    rbp,r15
    7c479db02b05:	add    rbp,0x10
    7c479db02b09:	movdqu XMMWORD PTR [r15],xmm5
    7c479db02b0e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c479db02b13:	mov    r15,r13
    7c479db02b16:	add    r15,0xa0
    7c479db02b1d:	mov    rbp,r15
    7c479db02b20:	add    rbp,0x10
    7c479db02b24:	movdqu xmm2,XMMWORD PTR [r15]
    7c479db02b29:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7c479db02b2e:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7c479db02b38:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7c479db02b42:	mov    r15,r13
    7c479db02b45:	add    r15,0x160
    7c479db02b4c:	mov    rbp,r15
    7c479db02b4f:	add    rbp,0x10
    7c479db02b53:	movdqu xmm4,XMMWORD PTR [r15]
    7c479db02b58:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    7c479db02b5d:	movdqu XMMWORD PTR [r12+0x2c0],xmm4
    7c479db02b67:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
    7c479db02b71:	mov    r15,r13
    7c479db02b74:	add    r15,0x1a0
    7c479db02b7b:	mov    rbp,r15
    7c479db02b7e:	add    rbp,0x10
    7c479db02b82:	movdqu xmm5,XMMWORD PTR [r15]
    7c479db02b87:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    7c479db02b8c:	movdqu XMMWORD PTR [r12+0x290],xmm5
    7c479db02b96:	movdqu XMMWORD PTR [r12+0x1e0],xmm7
    7c479db02ba0:	mov    r15,r14
    7c479db02ba3:	add    r15,0x80
    7c479db02baa:	mov    rbp,r15
    7c479db02bad:	add    rbp,0x10
    7c479db02bb1:	movdqu XMMWORD PTR [r15],xmm3
    7c479db02bb6:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7c479db02bbb:	add    r13,0x1e0
    7c479db02bc2:	mov    r15,r13
    7c479db02bc5:	add    r15,0x10
    7c479db02bc9:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7c479db02bcf:	movdqu xmm3,XMMWORD PTR [r15]
    7c479db02bd4:	movdqu XMMWORD PTR [r12+0x230],xmm2
    7c479db02bde:	movdqu XMMWORD PTR [r12+0x280],xmm3
    7c479db02be8:	mov    r13d,0x432000
    7c479db02bee:	add    r13,0x200
    7c479db02bf5:	mov    QWORD PTR [r12+0x50],r13
    7c479db02bfa:	mov    r13,r14
    7c479db02bfd:	add    r13,0x40
    7c479db02c01:	mov    r15,r13
    7c479db02c04:	add    r15,0x10
    7c479db02c08:	movdqu XMMWORD PTR [r13+0x0],xmm4
    7c479db02c0e:	movdqu XMMWORD PTR [r15],xmm6
    7c479db02c13:	mov    r13,r14
    7c479db02c16:	add    r13,0x10
    7c479db02c1a:	movdqu XMMWORD PTR [r14],xmm3
    7c479db02c1f:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c479db02c25:	mov    r11,rax
    7c479db02c28:	movzx  eax,WORD PTR [rsp]
    7c479db02c2c:	add    al,0x7f
    7c479db02c2e:	sahf
    7c479db02c2f:	mov    rax,r11
    7c479db02c32:	jmp    0x7c479db02c37
    7c479db02c37:	mov    r13d,0x0
    7c479db02c3d:	mov    QWORD PTR [r12+0x58],r13
    7c479db02c42:	mov    r11,rax
    7c479db02c45:	lahf
    7c479db02c46:	seto   al
    7c479db02c49:	mov    WORD PTR [rsp],ax
    7c479db02c4d:	mov    rax,r11
    7c479db02c50:	jmp    0x7c479db02c55
    7c479db02c55:	mov    r13,QWORD PTR [r12+0x58]
    7c479db02c5a:	mov    r14,QWORD PTR [r12+0x40]
    7c479db02c5f:	add    r14,r13
    7c479db02c62:	mov    QWORD PTR [r12+0x60],r14
    7c479db02c67:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    7c479db02c71:	movdqa xmm0,xmm2
    7c479db02c75:	movdqa xmm1,xmm2
    7c479db02c79:	por    xmm0,xmm1
    7c479db02c7d:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    7c479db02c87:	movdqu xmm4,XMMWORD PTR [r12+0x1a0]
    7c479db02c91:	movdqa xmm0,xmm4
    7c479db02c95:	movdqa xmm1,xmm4
    7c479db02c99:	por    xmm0,xmm1
    7c479db02c9d:	movdqu XMMWORD PTR [r12+0x120],xmm0
    7c479db02ca7:	mov    r15,r14
    7c479db02caa:	add    r15,0x30
    7c479db02cae:	mov    rbp,r15
    7c479db02cb1:	add    rbp,0x8
    7c479db02cb5:	mov    r8,QWORD PTR [r15]
    7c479db02cb8:	mov    r15,QWORD PTR [rbp+0x0]
    7c479db02cbc:	mov    ebp,0x0
    7c479db02cc1:	mov    QWORD PTR [r12+0x130],r8
    7c479db02cc9:	mov    QWORD PTR [r12+0x138],rbp
    7c479db02cd1:	mov    ebp,0x0
    7c479db02cd6:	mov    QWORD PTR [r12+0x280],r15
    7c479db02cde:	mov    QWORD PTR [r12+0x288],rbp
    7c479db02ce6:	movdqu xmm5,XMMWORD PTR [r12+0x270]
    7c479db02cf0:	movdqa xmm0,xmm5
    7c479db02cf4:	movdqa xmm1,xmm5
    7c479db02cf8:	por    xmm0,xmm1
    7c479db02cfc:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    7c479db02d06:	mov    r15,r14
    7c479db02d09:	add    r15,0x20
    7c479db02d0d:	mov    rbp,r15
    7c479db02d10:	add    rbp,0x8
    7c479db02d14:	mov    r8,QWORD PTR [r15]
    7c479db02d17:	mov    r15,QWORD PTR [rbp+0x0]
    7c479db02d1b:	mov    ebp,0x0
    7c479db02d20:	mov    QWORD PTR [r12+0x150],r8
    7c479db02d28:	mov    QWORD PTR [r12+0x158],rbp
    7c479db02d30:	mov    ebp,0x0
    7c479db02d35:	mov    QWORD PTR [r12+0x140],r15
    7c479db02d3d:	mov    QWORD PTR [r12+0x148],rbp
    7c479db02d45:	mov    r15,r14
    7c479db02d48:	add    r15,0x10
    7c479db02d4c:	mov    rbp,r15
    7c479db02d4f:	add    rbp,0x8
    7c479db02d53:	mov    r8,QWORD PTR [r15]
    7c479db02d56:	mov    r15,QWORD PTR [rbp+0x0]
    7c479db02d5a:	mov    ebp,0x0
    7c479db02d5f:	mov    QWORD PTR [r12+0x170],r8
    7c479db02d67:	mov    QWORD PTR [r12+0x178],rbp
    7c479db02d6f:	mov    ebp,0x0
    7c479db02d74:	mov    QWORD PTR [r12+0x160],r15
    7c479db02d7c:	mov    QWORD PTR [r12+0x168],rbp
    7c479db02d84:	mov    r15d,0x8
    7c479db02d8a:	mov    rbp,QWORD PTR [r14]
    7c479db02d8d:	mov    QWORD PTR [r12+0x180],rbp
    7c479db02d95:	mov    QWORD PTR [r12+0x188],rbp
    7c479db02d9d:	add    r14,r15
    7c479db02da0:	mov    QWORD PTR [r12+0x60],r14
    7c479db02da5:	mov    r15,QWORD PTR [r14]
    7c479db02da8:	mov    r14d,0x0
    7c479db02dae:	mov    QWORD PTR [r12+0x230],r15
    7c479db02db6:	mov    QWORD PTR [r12+0x238],r14
    7c479db02dbe:	mov    r14,QWORD PTR [r12+0xf8]
    7c479db02dc6:	mov    r15,r14
    7c479db02dc9:	add    r15,0x50
    7c479db02dcd:	mov    rbp,r15
    7c479db02dd0:	add    rbp,0x10
    7c479db02dd4:	movdqu xmm6,XMMWORD PTR [r15]
    7c479db02dd9:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    7c479db02dde:	movdqu XMMWORD PTR [r12+0x220],xmm6
    7c479db02de8:	movdqu XMMWORD PTR [r12+0x210],xmm7
    7c479db02df2:	mov    r15,r14
    7c479db02df5:	add    r15,0x30
    7c479db02df9:	movdqu xmm8,XMMWORD PTR [r15]
    7c479db02dfe:	movdqu XMMWORD PTR [r12+0x110],xmm8
    7c479db02e08:	mov    r15,QWORD PTR [r12+0x50]
    7c479db02e0d:	add    r15,r13
    7c479db02e10:	mov    QWORD PTR [r12+0x60],r15
    7c479db02e15:	add    r13,0x40
    7c479db02e19:	mov    QWORD PTR [r12+0x58],r13
    7c479db02e1e:	movdqu xmm9,XMMWORD PTR [r12+0x180]
    7c479db02e28:	movdqa xmm0,xmm9
    7c479db02e2d:	movdqa xmm1,xmm2
    7c479db02e31:	mulpd  xmm0,xmm1
    7c479db02e35:	movdqa xmm14,xmm0
    7c479db02e3a:	movdqu xmm15,XMMWORD PTR [rip+0x980d]        # 0x7c479db0c650
    7c479db02e43:	pand   xmm14,xmm15
    7c479db02e48:	movdqu xmm15,XMMWORD PTR [rip+0x980f]        # 0x7c479db0c660
    7c479db02e51:	pcmpeqq xmm14,xmm15
    7c479db02e57:	movdqa xmm15,xmm0
    7c479db02e5c:	cmpunordpd xmm15,xmm0
    7c479db02e62:	por    xmm14,xmm15
    7c479db02e67:	pmovmskb ecx,xmm14
    7c479db02e6c:	jrcxz  0x7c479db02e73
    7c479db02e6e:	jmp    0x7c479db04e05
    7c479db02e73:	movdqa xmm10,xmm0
    7c479db02e78:	movdqu xmm2,XMMWORD PTR [r12+0x230]
    7c479db02e82:	movdqa xmm0,xmm8
    7c479db02e87:	movdqa xmm1,xmm2
    7c479db02e8b:	pshufd xmm1,xmm1,0x44
    7c479db02e90:	mulpd  xmm0,xmm1
    7c479db02e94:	movdqa xmm14,xmm0
    7c479db02e99:	movdqu xmm15,XMMWORD PTR [rip+0x97ae]        # 0x7c479db0c650
    7c479db02ea2:	pand   xmm14,xmm15
    7c479db02ea7:	movdqu xmm15,XMMWORD PTR [rip+0x97b0]        # 0x7c479db0c660
    7c479db02eb0:	pcmpeqq xmm14,xmm15
    7c479db02eb6:	movdqa xmm15,xmm0
    7c479db02ebb:	cmpunordpd xmm15,xmm0
    7c479db02ec1:	por    xmm14,xmm15
    7c479db02ec6:	pmovmskb ecx,xmm14
    7c479db02ecb:	jrcxz  0x7c479db02ed2
    7c479db02ecd:	jmp    0x7c479db04e2a
    7c479db02ed2:	movdqa xmm11,xmm0
    7c479db02ed7:	movdqu XMMWORD PTR [r12+0x260],xmm11
    7c479db02ee1:	mov    ebp,0x0
    7c479db02ee6:	mov    r8d,0x0
    7c479db02eec:	mov    QWORD PTR [r12+0x110],rbp
    7c479db02ef4:	mov    QWORD PTR [r12+0x118],r8
    7c479db02efc:	movdqa xmm0,xmm9
    7c479db02f01:	movdqa xmm1,xmm7
    7c479db02f05:	mulpd  xmm0,xmm1
    7c479db02f09:	movdqa xmm14,xmm0
    7c479db02f0e:	movdqu xmm15,XMMWORD PTR [rip+0x9739]        # 0x7c479db0c650
    7c479db02f17:	pand   xmm14,xmm15
    7c479db02f1c:	movdqu xmm15,XMMWORD PTR [rip+0x973b]        # 0x7c479db0c660
    7c479db02f25:	pcmpeqq xmm14,xmm15
    7c479db02f2b:	movdqa xmm15,xmm0
    7c479db02f30:	cmpunordpd xmm15,xmm0
    7c479db02f36:	por    xmm14,xmm15
    7c479db02f3b:	pmovmskb ecx,xmm14
    7c479db02f40:	jrcxz  0x7c479db02f47
    7c479db02f42:	jmp    0x7c479db04e4f
    7c479db02f47:	movdqa xmm8,xmm0
    7c479db02f4c:	movdqa xmm0,xmm9
    7c479db02f51:	movdqa xmm1,xmm6
    7c479db02f55:	mulpd  xmm0,xmm1
    7c479db02f59:	movdqa xmm14,xmm0
    7c479db02f5e:	movdqu xmm15,XMMWORD PTR [rip+0x96e9]        # 0x7c479db0c650
    7c479db02f67:	pand   xmm14,xmm15
    7c479db02f6c:	movdqu xmm15,XMMWORD PTR [rip+0x96eb]        # 0x7c479db0c660
    7c479db02f75:	pcmpeqq xmm14,xmm15
    7c479db02f7b:	movdqa xmm15,xmm0
    7c479db02f80:	cmpunordpd xmm15,xmm0
    7c479db02f86:	por    xmm14,xmm15
    7c479db02f8b:	pmovmskb ecx,xmm14
    7c479db02f90:	jrcxz  0x7c479db02f97
    7c479db02f92:	jmp    0x7c479db04e74
    7c479db02f97:	movdqa xmm7,xmm0
    7c479db02f9b:	movdqu xmm6,XMMWORD PTR [r12+0x1f0]
    7c479db02fa5:	movdqa xmm0,xmm9
    7c479db02faa:	movdqa xmm1,xmm6
    7c479db02fae:	mulpd  xmm0,xmm1
    7c479db02fb2:	movdqa xmm14,xmm0
    7c479db02fb7:	movdqu xmm15,XMMWORD PTR [rip+0x9690]        # 0x7c479db0c650
    7c479db02fc0:	pand   xmm14,xmm15
    7c479db02fc5:	movdqu xmm15,XMMWORD PTR [rip+0x9692]        # 0x7c479db0c660
    7c479db02fce:	pcmpeqq xmm14,xmm15
    7c479db02fd4:	movdqa xmm15,xmm0
    7c479db02fd9:	cmpunordpd xmm15,xmm0
    7c479db02fdf:	por    xmm14,xmm15
    7c479db02fe4:	pmovmskb ecx,xmm14
    7c479db02fe9:	jrcxz  0x7c479db02ff0
    7c479db02feb:	jmp    0x7c479db04e99
    7c479db02ff0:	movdqa xmm12,xmm0
    7c479db02ff5:	movdqu XMMWORD PTR [r12+0x180],xmm12
    7c479db02fff:	movdqu xmm6,XMMWORD PTR [r12+0x2a0]
    7c479db03009:	movdqa xmm0,xmm6
    7c479db0300d:	movdqa xmm1,xmm6
    7c479db03011:	por    xmm0,xmm1
    7c479db03015:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    7c479db0301f:	movdqu xmm9,XMMWORD PTR [r12+0x250]
    7c479db03029:	movdqa xmm0,xmm9
    7c479db0302e:	movdqa xmm1,xmm9
    7c479db03033:	por    xmm0,xmm1
    7c479db03037:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    7c479db03041:	movdqa xmm0,xmm9
    7c479db03046:	movdqa xmm1,xmm2
    7c479db0304a:	pshufd xmm1,xmm1,0x44
    7c479db0304f:	mulpd  xmm0,xmm1
    7c479db03053:	movdqa xmm14,xmm0
    7c479db03058:	movdqu xmm15,XMMWORD PTR [rip+0x95ef]        # 0x7c479db0c650
    7c479db03061:	pand   xmm14,xmm15
    7c479db03066:	movdqu xmm15,XMMWORD PTR [rip+0x95f1]        # 0x7c479db0c660
    7c479db0306f:	pcmpeqq xmm14,xmm15
    7c479db03075:	movdqa xmm15,xmm0
    7c479db0307a:	cmpunordpd xmm15,xmm0
    7c479db03080:	por    xmm14,xmm15
    7c479db03085:	pmovmskb ecx,xmm14
    7c479db0308a:	jrcxz  0x7c479db03091
    7c479db0308c:	jmp    0x7c479db04ebe
    7c479db03091:	movdqa xmm4,xmm0
    7c479db03095:	movdqu XMMWORD PTR [r12+0x250],xmm4
    7c479db0309f:	sub    r13,0x200
    7c479db030a6:	movdqu xmm9,XMMWORD PTR [r12+0x110]
    7c479db030b0:	movdqa xmm0,xmm10
    7c479db030b5:	movdqa xmm1,xmm9
    7c479db030ba:	addpd  xmm0,xmm1
    7c479db030be:	movdqa xmm14,xmm0
    7c479db030c3:	movdqu xmm15,XMMWORD PTR [rip+0x9584]        # 0x7c479db0c650
    7c479db030cc:	pand   xmm14,xmm15
    7c479db030d1:	movdqu xmm15,XMMWORD PTR [rip+0x9586]        # 0x7c479db0c660
    7c479db030da:	pcmpeqq xmm14,xmm15
    7c479db030e0:	movdqa xmm15,xmm0
    7c479db030e5:	cmpunordpd xmm15,xmm0
    7c479db030eb:	por    xmm14,xmm15
    7c479db030f0:	pmovmskb ecx,xmm14
    7c479db030f5:	jrcxz  0x7c479db030fc
    7c479db030f7:	jmp    0x7c479db04ee3
    7c479db030fc:	movdqu XMMWORD PTR [r12+0x240],xmm0
    7c479db03106:	movdqu xmm10,XMMWORD PTR [r12+0x1b0]
    7c479db03110:	movdqa xmm0,xmm8
    7c479db03115:	movdqa xmm1,xmm10
    7c479db0311a:	addpd  xmm0,xmm1
    7c479db0311e:	movdqa xmm14,xmm0
    7c479db03123:	movdqu xmm15,XMMWORD PTR [rip+0x9524]        # 0x7c479db0c650
    7c479db0312c:	pand   xmm14,xmm15
    7c479db03131:	movdqu xmm15,XMMWORD PTR [rip+0x9526]        # 0x7c479db0c660
    7c479db0313a:	pcmpeqq xmm14,xmm15
    7c479db03140:	movdqa xmm15,xmm0
    7c479db03145:	cmpunordpd xmm15,xmm0
    7c479db0314b:	por    xmm14,xmm15
    7c479db03150:	pmovmskb ecx,xmm14
    7c479db03155:	jrcxz  0x7c479db0315c
    7c479db03157:	jmp    0x7c479db04f24
    7c479db0315c:	movdqa xmm6,xmm0
    7c479db03160:	movdqu XMMWORD PTR [r12+0x210],xmm6
    7c479db0316a:	movdqa xmm0,xmm7
    7c479db0316e:	movdqa xmm1,xmm10
    7c479db03173:	addpd  xmm0,xmm1
    7c479db03177:	movdqa xmm14,xmm0
    7c479db0317c:	movdqu xmm15,XMMWORD PTR [rip+0x94cb]        # 0x7c479db0c650
    7c479db03185:	pand   xmm14,xmm15
    7c479db0318a:	movdqu xmm15,XMMWORD PTR [rip+0x94cd]        # 0x7c479db0c660
    7c479db03193:	pcmpeqq xmm14,xmm15
    7c479db03199:	movdqa xmm15,xmm0
    7c479db0319e:	cmpunordpd xmm15,xmm0
    7c479db031a4:	por    xmm14,xmm15
    7c479db031a9:	pmovmskb ecx,xmm14
    7c479db031ae:	jrcxz  0x7c479db031b5
    7c479db031b0:	jmp    0x7c479db04f65
    7c479db031b5:	movdqa xmm8,xmm0
    7c479db031ba:	movdqu XMMWORD PTR [r12+0x220],xmm8
    7c479db031c4:	movdqu xmm7,XMMWORD PTR [r12+0x2f0]
    7c479db031ce:	setne  BYTE PTR [rsp+0x8]
    7c479db031d3:	mov    r11,rax
    7c479db031d6:	lahf
    7c479db031d7:	seto   al
    7c479db031da:	mov    WORD PTR [rsp],ax
    7c479db031de:	mov    rax,r11
    7c479db031e1:	movdqa xmm0,xmm7
    7c479db031e5:	movdqa xmm1,xmm7
    7c479db031e9:	por    xmm0,xmm1
    7c479db031ed:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    7c479db031f7:	movdqu xmm10,XMMWORD PTR [r12+0x2e0]
    7c479db03201:	movdqa xmm0,xmm10
    7c479db03206:	movdqa xmm1,xmm10
    7c479db0320b:	por    xmm0,xmm1
    7c479db0320f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    7c479db03219:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    7c479db03223:	movdqa xmm0,xmm13
    7c479db03228:	movdqa xmm1,xmm13
    7c479db0322d:	por    xmm0,xmm1
    7c479db03231:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    7c479db0323b:	movdqu xmm5,XMMWORD PTR [r12+0x200]
    7c479db03245:	movdqa xmm0,xmm5
    7c479db03249:	movdqa xmm1,xmm5
    7c479db0324d:	por    xmm0,xmm1
    7c479db03251:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    7c479db0325b:	movdqu xmm7,XMMWORD PTR [r12+0x1c0]
    7c479db03265:	movdqa xmm1,xmm7
    7c479db03269:	por    xmm7,xmm1
    7c479db0326d:	movdqu XMMWORD PTR [r12+0x200],xmm7
    7c479db03277:	movdqu xmm3,XMMWORD PTR [r12+0x190]
    7c479db03281:	movdqa xmm1,xmm3
    7c479db03285:	por    xmm3,xmm1
    7c479db03289:	movdqu XMMWORD PTR [r12+0x1c0],xmm3
    7c479db03293:	movdqu xmm10,XMMWORD PTR [r12+0x300]
    7c479db0329d:	movdqa xmm1,xmm10
    7c479db032a2:	por    xmm10,xmm1
    7c479db032a7:	movdqu XMMWORD PTR [r12+0x190],xmm10
    7c479db032b1:	mov    r13,r14
    7c479db032b4:	add    r13,0xa0
    7c479db032bb:	mov    rbp,r13
    7c479db032be:	add    rbp,0x10
    7c479db032c2:	movdqu xmm13,XMMWORD PTR [r13+0x0]
    7c479db032c8:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    7c479db032cd:	movdqu XMMWORD PTR [r12+0x300],xmm13
    7c479db032d7:	movdqu XMMWORD PTR [r12+0x270],xmm5
    7c479db032e1:	movdqa xmm0,xmm12
    7c479db032e6:	movdqa xmm1,xmm9
    7c479db032eb:	addpd  xmm0,xmm1
    7c479db032ef:	movdqa xmm14,xmm0
    7c479db032f4:	movdqu xmm15,XMMWORD PTR [rip+0x9353]        # 0x7c479db0c650
    7c479db032fd:	pand   xmm14,xmm15
    7c479db03302:	movdqu xmm15,XMMWORD PTR [rip+0x9355]        # 0x7c479db0c660
    7c479db0330b:	pcmpeqq xmm14,xmm15
    7c479db03311:	movdqa xmm15,xmm0
    7c479db03316:	cmpunordpd xmm15,xmm0
    7c479db0331c:	por    xmm14,xmm15
    7c479db03321:	pmovmskb ecx,xmm14
    7c479db03326:	jrcxz  0x7c479db0332d
    7c479db03328:	jmp    0x7c479db04fa5
    7c479db0332d:	movdqu XMMWORD PTR [r12+0x180],xmm0
    7c479db03337:	mov    r13,r14
    7c479db0333a:	add    r13,0xf0
    7c479db03341:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    7c479db03347:	movdqu XMMWORD PTR [r12+0x110],xmm9
    7c479db03351:	movdqa xmm0,xmm6
    7c479db03355:	movdqa xmm1,xmm4
    7c479db03359:	addpd  xmm0,xmm1
    7c479db0335d:	movdqa xmm14,xmm0
    7c479db03362:	movdqu xmm15,XMMWORD PTR [rip+0x92e5]        # 0x7c479db0c650
    7c479db0336b:	pand   xmm14,xmm15
    7c479db03370:	movdqu xmm15,XMMWORD PTR [rip+0x92e7]        # 0x7c479db0c660
    7c479db03379:	pcmpeqq xmm14,xmm15
    7c479db0337f:	movdqa xmm15,xmm0
    7c479db03384:	cmpunordpd xmm15,xmm0
    7c479db0338a:	por    xmm14,xmm15
    7c479db0338f:	pmovmskb ecx,xmm14
    7c479db03394:	jrcxz  0x7c479db0339b
    7c479db03396:	jmp    0x7c479db04fcb
    7c479db0339b:	movdqa xmm12,xmm0
    7c479db033a0:	movdqu XMMWORD PTR [r12+0x210],xmm12
    7c479db033aa:	movdqa xmm0,xmm8
    7c479db033af:	movdqa xmm1,xmm11
    7c479db033b4:	addpd  xmm0,xmm1
    7c479db033b8:	movdqa xmm14,xmm0
    7c479db033bd:	movdqu xmm15,XMMWORD PTR [rip+0x928a]        # 0x7c479db0c650
    7c479db033c6:	pand   xmm14,xmm15
    7c479db033cb:	movdqu xmm15,XMMWORD PTR [rip+0x928c]        # 0x7c479db0c660
    7c479db033d4:	pcmpeqq xmm14,xmm15
    7c479db033da:	movdqa xmm15,xmm0
    7c479db033df:	cmpunordpd xmm15,xmm0
    7c479db033e5:	por    xmm14,xmm15
    7c479db033ea:	pmovmskb ecx,xmm14
    7c479db033ef:	jrcxz  0x7c479db033f6
    7c479db033f1:	jmp    0x7c479db04fef
    7c479db033f6:	movdqa xmm4,xmm0
    7c479db033fa:	movdqu XMMWORD PTR [r12+0x220],xmm4
    7c479db03404:	movdqa xmm0,xmm5
    7c479db03408:	movdqa xmm1,xmm2
    7c479db0340c:	pshufd xmm1,xmm1,0x44
    7c479db03411:	mulpd  xmm0,xmm1
    7c479db03415:	movdqa xmm14,xmm0
    7c479db0341a:	movdqu xmm15,XMMWORD PTR [rip+0x922d]        # 0x7c479db0c650
    7c479db03423:	pand   xmm14,xmm15
    7c479db03428:	movdqu xmm15,XMMWORD PTR [rip+0x922f]        # 0x7c479db0c660
    7c479db03431:	pcmpeqq xmm14,xmm15
    7c479db03437:	movdqa xmm15,xmm0
    7c479db0343c:	cmpunordpd xmm15,xmm0
    7c479db03442:	por    xmm14,xmm15
    7c479db03447:	pmovmskb ecx,xmm14
    7c479db0344c:	jrcxz  0x7c479db03453
    7c479db0344e:	jmp    0x7c479db05015
    7c479db03453:	movdqa xmm6,xmm0
    7c479db03457:	movdqu XMMWORD PTR [r12+0x270],xmm6
    7c479db03461:	movdqu xmm5,XMMWORD PTR [r12+0x170]
    7c479db0346b:	movdqa xmm0,xmm9
    7c479db03470:	movdqa xmm1,xmm5
    7c479db03474:	pshufd xmm1,xmm1,0x44
    7c479db03479:	mulpd  xmm0,xmm1
    7c479db0347d:	movdqa xmm14,xmm0
    7c479db03482:	movdqu xmm15,XMMWORD PTR [rip+0x91c5]        # 0x7c479db0c650
    7c479db0348b:	pand   xmm14,xmm15
    7c479db03490:	movdqu xmm15,XMMWORD PTR [rip+0x91c7]        # 0x7c479db0c660
    7c479db03499:	pcmpeqq xmm14,xmm15
    7c479db0349f:	movdqa xmm15,xmm0
    7c479db034a4:	cmpunordpd xmm15,xmm0
    7c479db034aa:	por    xmm14,xmm15
    7c479db034af:	pmovmskb ecx,xmm14
    7c479db034b4:	jrcxz  0x7c479db034bb
    7c479db034b6:	jmp    0x7c479db05039
    7c479db034bb:	movdqa xmm8,xmm0
    7c479db034c0:	movdqu XMMWORD PTR [r12+0x250],xmm8
    7c479db034ca:	mov    r13,r14
    7c479db034cd:	add    r13,0xe0
    7c479db034d4:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    7c479db034da:	movdqu XMMWORD PTR [r12+0x110],xmm9
    7c479db034e4:	movdqa xmm0,xmm13
    7c479db034e9:	movdqa xmm1,xmm2
    7c479db034ed:	pshufd xmm1,xmm1,0x44
    7c479db034f2:	mulpd  xmm0,xmm1
    7c479db034f6:	movdqa xmm14,xmm0
    7c479db034fb:	movdqu xmm15,XMMWORD PTR [rip+0x914c]        # 0x7c479db0c650
    7c479db03504:	pand   xmm14,xmm15
    7c479db03509:	movdqu xmm15,XMMWORD PTR [rip+0x914e]        # 0x7c479db0c660
    7c479db03512:	pcmpeqq xmm14,xmm15
    7c479db03518:	movdqa xmm15,xmm0
    7c479db0351d:	cmpunordpd xmm15,xmm0
    7c479db03523:	por    xmm14,xmm15
    7c479db03528:	pmovmskb ecx,xmm14
    7c479db0352d:	jrcxz  0x7c479db03534
    7c479db0352f:	jmp    0x7c479db0505e
    7c479db03534:	movdqa xmm11,xmm0
    7c479db03539:	movdqu XMMWORD PTR [r12+0x230],xmm11
    7c479db03543:	movdqa xmm0,xmm10
    7c479db03548:	movdqa xmm1,xmm10
    7c479db0354d:	por    xmm0,xmm1
    7c479db03551:	movdqu XMMWORD PTR [r12+0x300],xmm0
    7c479db0355b:	movdqa xmm0,xmm3
    7c479db0355f:	movdqa xmm1,xmm3
    7c479db03563:	por    xmm0,xmm1
    7c479db03567:	movdqu XMMWORD PTR [r12+0x190],xmm0
    7c479db03571:	movdqa xmm0,xmm9
    7c479db03576:	movdqa xmm1,xmm5
    7c479db0357a:	pshufd xmm1,xmm1,0x44
    7c479db0357f:	mulpd  xmm0,xmm1
    7c479db03583:	movdqa xmm14,xmm0
    7c479db03588:	movdqu xmm15,XMMWORD PTR [rip+0x90bf]        # 0x7c479db0c650
    7c479db03591:	pand   xmm14,xmm15
    7c479db03596:	movdqu xmm15,XMMWORD PTR [rip+0x90c1]        # 0x7c479db0c660
    7c479db0359f:	pcmpeqq xmm14,xmm15
    7c479db035a5:	movdqa xmm15,xmm0
    7c479db035aa:	cmpunordpd xmm15,xmm0
    7c479db035b0:	por    xmm14,xmm15
    7c479db035b5:	pmovmskb ecx,xmm14
    7c479db035ba:	jrcxz  0x7c479db035c1
    7c479db035bc:	jmp    0x7c479db05083
    7c479db035c1:	movdqa xmm2,xmm0
    7c479db035c5:	movdqu XMMWORD PTR [r12+0x260],xmm2
    7c479db035cf:	mov    r13,r14
    7c479db035d2:	add    r13,0x90
    7c479db035d9:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    7c479db035df:	movdqu XMMWORD PTR [r12+0x110],xmm9
    7c479db035e9:	movdqa xmm0,xmm7
    7c479db035ed:	movdqa xmm1,xmm7
    7c479db035f1:	por    xmm0,xmm1
    7c479db035f5:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    7c479db035ff:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    7c479db03609:	movdqu xmm1,XMMWORD PTR [r12+0x2d0]
    7c479db03613:	por    xmm13,xmm1
    7c479db03618:	movdqu XMMWORD PTR [r12+0x200],xmm13
    7c479db03622:	movdqu xmm7,XMMWORD PTR [r12+0x2e0]
    7c479db0362c:	movdqu xmm1,XMMWORD PTR [r12+0x2e0]
    7c479db03636:	por    xmm7,xmm1
    7c479db0363a:	movdqu XMMWORD PTR [r12+0x2d0],xmm7
    7c479db03644:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7c479db0364e:	movdqu xmm1,XMMWORD PTR [r12+0x2f0]
    7c479db03658:	por    xmm0,xmm1
    7c479db0365c:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    7c479db03666:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c479db03670:	movdqa xmm1,xmm6
    7c479db03674:	addpd  xmm0,xmm1
    7c479db03678:	movdqa xmm14,xmm0
    7c479db0367d:	movdqu xmm15,XMMWORD PTR [rip+0x8fca]        # 0x7c479db0c650
    7c479db03686:	pand   xmm14,xmm15
    7c479db0368b:	movdqu xmm15,XMMWORD PTR [rip+0x8fcc]        # 0x7c479db0c660
    7c479db03694:	pcmpeqq xmm14,xmm15
    7c479db0369a:	movdqa xmm15,xmm0
    7c479db0369f:	cmpunordpd xmm15,xmm0
    7c479db036a5:	por    xmm14,xmm15
    7c479db036aa:	pmovmskb ecx,xmm14
    7c479db036af:	jrcxz  0x7c479db036b6
    7c479db036b1:	jmp    0x7c479db050a8
    7c479db036b6:	movdqa xmm3,xmm0
    7c479db036ba:	movdqu XMMWORD PTR [r12+0x240],xmm3
    7c479db036c4:	movdqa xmm0,xmm9
    7c479db036c9:	movdqa xmm1,xmm5
    7c479db036cd:	pshufd xmm1,xmm1,0x44
    7c479db036d2:	mulpd  xmm0,xmm1
    7c479db036d6:	movdqa xmm14,xmm0
    7c479db036db:	movdqu xmm15,XMMWORD PTR [rip+0x8f6c]        # 0x7c479db0c650
    7c479db036e4:	pand   xmm14,xmm15
    7c479db036e9:	movdqu xmm15,XMMWORD PTR [rip+0x8f6e]        # 0x7c479db0c660
    7c479db036f2:	pcmpeqq xmm14,xmm15
    7c479db036f8:	movdqa xmm15,xmm0
    7c479db036fd:	cmpunordpd xmm15,xmm0
    7c479db03703:	por    xmm14,xmm15
    7c479db03708:	pmovmskb ecx,xmm14
    7c479db0370d:	jrcxz  0x7c479db03714
    7c479db0370f:	jmp    0x7c479db050d2
    7c479db03714:	movdqa xmm6,xmm0
    7c479db03718:	movdqu XMMWORD PTR [r12+0x270],xmm6
    7c479db03722:	mov    r13,r14
    7c479db03725:	add    r13,0x80
    7c479db0372c:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    7c479db03732:	movdqu XMMWORD PTR [r12+0x110],xmm9
    7c479db0373c:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c479db03746:	movdqa xmm1,xmm11
    7c479db0374b:	addpd  xmm0,xmm1
    7c479db0374f:	movdqa xmm14,xmm0
    7c479db03754:	movdqu xmm15,XMMWORD PTR [rip+0x8ef3]        # 0x7c479db0c650
    7c479db0375d:	pand   xmm14,xmm15
    7c479db03762:	movdqu xmm15,XMMWORD PTR [rip+0x8ef5]        # 0x7c479db0c660
    7c479db0376b:	pcmpeqq xmm14,xmm15
    7c479db03771:	movdqa xmm15,xmm0
    7c479db03776:	cmpunordpd xmm15,xmm0
    7c479db0377c:	por    xmm14,xmm15
    7c479db03781:	pmovmskb ecx,xmm14
    7c479db03786:	jrcxz  0x7c479db0378d
    7c479db03788:	jmp    0x7c479db050f7
    7c479db0378d:	movdqa xmm10,xmm0
    7c479db03792:	movdqu XMMWORD PTR [r12+0x180],xmm10
    7c479db0379c:	movdqa xmm0,xmm12
    7c479db037a1:	movdqa xmm1,xmm8
    7c479db037a6:	addpd  xmm0,xmm1
    7c479db037aa:	movdqa xmm14,xmm0
    7c479db037af:	movdqu xmm15,XMMWORD PTR [rip+0x8e98]        # 0x7c479db0c650
    7c479db037b8:	pand   xmm14,xmm15
    7c479db037bd:	movdqu xmm15,XMMWORD PTR [rip+0x8e9a]        # 0x7c479db0c660
    7c479db037c6:	pcmpeqq xmm14,xmm15
    7c479db037cc:	movdqa xmm15,xmm0
    7c479db037d1:	cmpunordpd xmm15,xmm0
    7c479db037d7:	por    xmm14,xmm15
    7c479db037dc:	pmovmskb ecx,xmm14
    7c479db037e1:	jrcxz  0x7c479db037e8
    7c479db037e3:	jmp    0x7c479db05122
    7c479db037e8:	movdqa xmm11,xmm0
    7c479db037ed:	movdqu XMMWORD PTR [r12+0x210],xmm11
    7c479db037f7:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    7c479db03801:	movdqu xmm1,XMMWORD PTR [r12+0x1b0]
    7c479db0380b:	por    xmm0,xmm1
    7c479db0380f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    7c479db03819:	movdqa xmm0,xmm9
    7c479db0381e:	movdqa xmm1,xmm5
    7c479db03822:	pshufd xmm1,xmm1,0x44
    7c479db03827:	mulpd  xmm0,xmm1
    7c479db0382b:	movdqa xmm14,xmm0
    7c479db03830:	movdqu xmm15,XMMWORD PTR [rip+0x8e17]        # 0x7c479db0c650
    7c479db03839:	pand   xmm14,xmm15
    7c479db0383e:	movdqu xmm15,XMMWORD PTR [rip+0x8e19]        # 0x7c479db0c660
    7c479db03847:	pcmpeqq xmm14,xmm15
    7c479db0384d:	movdqa xmm15,xmm0
    7c479db03852:	cmpunordpd xmm15,xmm0
    7c479db03858:	por    xmm14,xmm15
    7c479db0385d:	pmovmskb ecx,xmm14
    7c479db03862:	jrcxz  0x7c479db03869
    7c479db03864:	jmp    0x7c479db05148
    7c479db03869:	movdqa xmm12,xmm0
    7c479db0386e:	movdqu XMMWORD PTR [r12+0x170],xmm12
    7c479db03878:	mov    r13,r14
    7c479db0387b:	add    r13,0xd0
    7c479db03882:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    7c479db03888:	movdqu XMMWORD PTR [r12+0x110],xmm5
    7c479db03892:	movdqa xmm0,xmm4
    7c479db03896:	movdqa xmm1,xmm2
    7c479db0389a:	addpd  xmm0,xmm1
    7c479db0389e:	movdqa xmm14,xmm0
    7c479db038a3:	movdqu xmm15,XMMWORD PTR [rip+0x8da4]        # 0x7c479db0c650
    7c479db038ac:	pand   xmm14,xmm15
    7c479db038b1:	movdqu xmm15,XMMWORD PTR [rip+0x8da6]        # 0x7c479db0c660
    7c479db038ba:	pcmpeqq xmm14,xmm15
    7c479db038c0:	movdqa xmm15,xmm0
    7c479db038c5:	cmpunordpd xmm15,xmm0
    7c479db038cb:	por    xmm14,xmm15
    7c479db038d0:	pmovmskb ecx,xmm14
    7c479db038d5:	jrcxz  0x7c479db038dc
    7c479db038d7:	jmp    0x7c479db0516d
    7c479db038dc:	movdqa xmm9,xmm0
    7c479db038e1:	movdqu XMMWORD PTR [r12+0x220],xmm9
    7c479db038eb:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    7c479db038f5:	movdqa xmm0,xmm13
    7c479db038fa:	movdqa xmm1,xmm2
    7c479db038fe:	pshufd xmm1,xmm1,0x44
    7c479db03903:	mulpd  xmm0,xmm1
    7c479db03907:	movdqa xmm14,xmm0
    7c479db0390c:	movdqu xmm15,XMMWORD PTR [rip+0x8d3b]        # 0x7c479db0c650
    7c479db03915:	pand   xmm14,xmm15
    7c479db0391a:	movdqu xmm15,XMMWORD PTR [rip+0x8d3d]        # 0x7c479db0c660
    7c479db03923:	pcmpeqq xmm14,xmm15
    7c479db03929:	movdqa xmm15,xmm0
    7c479db0392e:	cmpunordpd xmm15,xmm0
    7c479db03934:	por    xmm14,xmm15
    7c479db03939:	pmovmskb ecx,xmm14
    7c479db0393e:	jrcxz  0x7c479db03945
    7c479db03940:	jmp    0x7c479db05191
    7c479db03945:	movdqa xmm4,xmm0
    7c479db03949:	movdqu XMMWORD PTR [r12+0x260],xmm4
    7c479db03953:	mov    r13d,0x0
    7c479db03959:	mov    ebp,0x0
    7c479db0395e:	mov    QWORD PTR [r12+0x1b0],r13
    7c479db03966:	mov    QWORD PTR [r12+0x1b8],rbp
    7c479db0396e:	movdqa xmm0,xmm5
    7c479db03972:	movdqa xmm1,xmm2
    7c479db03976:	pshufd xmm1,xmm1,0x44
    7c479db0397b:	mulpd  xmm0,xmm1
    7c479db0397f:	movdqa xmm14,xmm0
    7c479db03984:	movdqu xmm15,XMMWORD PTR [rip+0x8cc3]        # 0x7c479db0c650
    7c479db0398d:	pand   xmm14,xmm15
    7c479db03992:	movdqu xmm15,XMMWORD PTR [rip+0x8cc5]        # 0x7c479db0c660
    7c479db0399b:	pcmpeqq xmm14,xmm15
    7c479db039a1:	movdqa xmm15,xmm0
    7c479db039a6:	cmpunordpd xmm15,xmm0
    7c479db039ac:	por    xmm14,xmm15
    7c479db039b1:	pmovmskb ecx,xmm14
    7c479db039b6:	jrcxz  0x7c479db039bd
    7c479db039b8:	jmp    0x7c479db051b6
    7c479db039bd:	movdqa xmm13,xmm0
    7c479db039c2:	movdqu XMMWORD PTR [r12+0x230],xmm13
    7c479db039cc:	mov    r13,r14
    7c479db039cf:	add    r13,0xc0
    7c479db039d6:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    7c479db039dc:	movdqu XMMWORD PTR [r12+0x110],xmm5
    7c479db039e6:	movdqa xmm0,xmm3
    7c479db039ea:	movdqa xmm1,xmm6
    7c479db039ee:	addpd  xmm0,xmm1
    7c479db039f2:	movdqa xmm14,xmm0
    7c479db039f7:	movdqu xmm15,XMMWORD PTR [rip+0x8c50]        # 0x7c479db0c650
    7c479db03a00:	pand   xmm14,xmm15
    7c479db03a05:	movdqu xmm15,XMMWORD PTR [rip+0x8c52]        # 0x7c479db0c660
    7c479db03a0e:	pcmpeqq xmm14,xmm15
    7c479db03a14:	movdqa xmm15,xmm0
    7c479db03a19:	cmpunordpd xmm15,xmm0
    7c479db03a1f:	por    xmm14,xmm15
    7c479db03a24:	pmovmskb ecx,xmm14
    7c479db03a29:	jrcxz  0x7c479db03a30
    7c479db03a2b:	jmp    0x7c479db051da
    7c479db03a30:	movdqa xmm8,xmm0
    7c479db03a35:	movdqu XMMWORD PTR [r12+0x240],xmm8
    7c479db03a3f:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    7c479db03a49:	movdqu xmm1,XMMWORD PTR [r12+0x1a0]
    7c479db03a53:	por    xmm0,xmm1
    7c479db03a57:	movdqu XMMWORD PTR [r12+0x270],xmm0
    7c479db03a61:	movdqu xmm6,XMMWORD PTR [r12+0x120]
    7c479db03a6b:	movdqu xmm1,XMMWORD PTR [r12+0x120]
    7c479db03a75:	por    xmm6,xmm1
    7c479db03a79:	movdqu XMMWORD PTR [r12+0x1a0],xmm6
    7c479db03a83:	movdqa xmm0,xmm5
    7c479db03a87:	movdqa xmm1,xmm2
    7c479db03a8b:	pshufd xmm1,xmm1,0x44
    7c479db03a90:	mulpd  xmm0,xmm1
    7c479db03a94:	movdqa xmm14,xmm0
    7c479db03a99:	movdqu xmm15,XMMWORD PTR [rip+0x8bae]        # 0x7c479db0c650
    7c479db03aa2:	pand   xmm14,xmm15
    7c479db03aa7:	movdqu xmm15,XMMWORD PTR [rip+0x8bb0]        # 0x7c479db0c660
    7c479db03ab0:	pcmpeqq xmm14,xmm15
    7c479db03ab6:	movdqa xmm15,xmm0
    7c479db03abb:	cmpunordpd xmm15,xmm0
    7c479db03ac1:	por    xmm14,xmm15
    7c479db03ac6:	pmovmskb ecx,xmm14
    7c479db03acb:	jrcxz  0x7c479db03ad2
    7c479db03acd:	jmp    0x7c479db051fe
    7c479db03ad2:	movdqa xmm6,xmm0
    7c479db03ad6:	movdqu XMMWORD PTR [r12+0x250],xmm6
    7c479db03ae0:	mov    r13,r14
    7c479db03ae3:	add    r13,0x20
    7c479db03ae7:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    7c479db03aed:	movdqu XMMWORD PTR [r12+0x110],xmm5
    7c479db03af7:	movdqa xmm0,xmm10
    7c479db03afc:	movdqa xmm1,xmm12
    7c479db03b01:	addpd  xmm0,xmm1
    7c479db03b05:	movdqa xmm14,xmm0
    7c479db03b0a:	movdqu xmm15,XMMWORD PTR [rip+0x8b3d]        # 0x7c479db0c650
    7c479db03b13:	pand   xmm14,xmm15
    7c479db03b18:	movdqu xmm15,XMMWORD PTR [rip+0x8b3f]        # 0x7c479db0c660
    7c479db03b21:	pcmpeqq xmm14,xmm15
    7c479db03b27:	movdqa xmm15,xmm0
    7c479db03b2c:	cmpunordpd xmm15,xmm0
    7c479db03b32:	por    xmm14,xmm15
    7c479db03b37:	pmovmskb ecx,xmm14
    7c479db03b3c:	jrcxz  0x7c479db03b43
    7c479db03b3e:	jmp    0x7c479db05222
    7c479db03b43:	movdqa xmm3,xmm0
    7c479db03b47:	movdqa xmm0,xmm7
    7c479db03b4b:	movdqa xmm1,xmm2
    7c479db03b4f:	pshufd xmm1,xmm1,0x44
    7c479db03b54:	mulpd  xmm0,xmm1
    7c479db03b58:	movdqa xmm14,xmm0
    7c479db03b5d:	movdqu xmm15,XMMWORD PTR [rip+0x8aea]        # 0x7c479db0c650
    7c479db03b66:	pand   xmm14,xmm15
    7c479db03b6b:	movdqu xmm15,XMMWORD PTR [rip+0x8aec]        # 0x7c479db0c660
    7c479db03b74:	pcmpeqq xmm14,xmm15
    7c479db03b7a:	movdqa xmm15,xmm0
    7c479db03b7f:	cmpunordpd xmm15,xmm0
    7c479db03b85:	por    xmm14,xmm15
    7c479db03b8a:	pmovmskb ecx,xmm14
    7c479db03b8f:	jrcxz  0x7c479db03b96
    7c479db03b91:	jmp    0x7c479db05248
    7c479db03b96:	movdqa xmm10,xmm0
    7c479db03b9b:	movdqa xmm0,xmm11
    7c479db03ba0:	movdqa xmm1,xmm13
    7c479db03ba5:	addpd  xmm0,xmm1
    7c479db03ba9:	movdqa xmm14,xmm0
    7c479db03bae:	movdqu xmm15,XMMWORD PTR [rip+0x8a99]        # 0x7c479db0c650
    7c479db03bb7:	pand   xmm14,xmm15
    7c479db03bbc:	movdqu xmm15,XMMWORD PTR [rip+0x8a9b]        # 0x7c479db0c660
    7c479db03bc5:	pcmpeqq xmm14,xmm15
    7c479db03bcb:	movdqa xmm15,xmm0
    7c479db03bd0:	cmpunordpd xmm15,xmm0
    7c479db03bd6:	por    xmm14,xmm15
    7c479db03bdb:	pmovmskb ecx,xmm14
    7c479db03be0:	jrcxz  0x7c479db03be7
    7c479db03be2:	jmp    0x7c479db0526c
    7c479db03be7:	movdqa xmm2,xmm0
    7c479db03beb:	movdqu xmm7,XMMWORD PTR [r12+0x150]
    7c479db03bf5:	movdqa xmm0,xmm5
    7c479db03bf9:	movdqa xmm1,xmm7
    7c479db03bfd:	pshufd xmm1,xmm1,0x44
    7c479db03c02:	mulpd  xmm0,xmm1
    7c479db03c06:	movdqa xmm14,xmm0
    7c479db03c0b:	movdqu xmm15,XMMWORD PTR [rip+0x8a3c]        # 0x7c479db0c650
    7c479db03c14:	pand   xmm14,xmm15
    7c479db03c19:	movdqu xmm15,XMMWORD PTR [rip+0x8a3e]        # 0x7c479db0c660
    7c479db03c22:	pcmpeqq xmm14,xmm15
    7c479db03c28:	movdqa xmm15,xmm0
    7c479db03c2d:	cmpunordpd xmm15,xmm0
    7c479db03c33:	por    xmm14,xmm15
    7c479db03c38:	pmovmskb ecx,xmm14
    7c479db03c3d:	jrcxz  0x7c479db03c44
    7c479db03c3f:	jmp    0x7c479db05292
    7c479db03c44:	movdqa xmm11,xmm0
    7c479db03c49:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    7c479db03c53:	movdqa xmm1,xmm7
    7c479db03c57:	pshufd xmm1,xmm1,0x44
    7c479db03c5c:	mulpd  xmm0,xmm1
    7c479db03c60:	movdqa xmm14,xmm0
    7c479db03c65:	movdqu xmm15,XMMWORD PTR [rip+0x89e2]        # 0x7c479db0c650
    7c479db03c6e:	pand   xmm14,xmm15
    7c479db03c73:	movdqu xmm15,XMMWORD PTR [rip+0x89e4]        # 0x7c479db0c660
    7c479db03c7c:	pcmpeqq xmm14,xmm15
    7c479db03c82:	movdqa xmm15,xmm0
    7c479db03c87:	cmpunordpd xmm15,xmm0
    7c479db03c8d:	por    xmm14,xmm15
    7c479db03c92:	pmovmskb ecx,xmm14
    7c479db03c97:	jrcxz  0x7c479db03c9e
    7c479db03c99:	jmp    0x7c479db052b6
    7c479db03c9e:	movdqa xmm5,xmm0
    7c479db03ca2:	movdqa xmm0,xmm8
    7c479db03ca7:	movdqa xmm1,xmm4
    7c479db03cab:	addpd  xmm0,xmm1
    7c479db03caf:	movdqa xmm14,xmm0
    7c479db03cb4:	movdqu xmm15,XMMWORD PTR [rip+0x8993]        # 0x7c479db0c650
    7c479db03cbd:	pand   xmm14,xmm15
    7c479db03cc2:	movdqu xmm15,XMMWORD PTR [rip+0x8995]        # 0x7c479db0c660
    7c479db03ccb:	pcmpeqq xmm14,xmm15
    7c479db03cd1:	movdqa xmm15,xmm0
    7c479db03cd6:	cmpunordpd xmm15,xmm0
    7c479db03cdc:	por    xmm14,xmm15
    7c479db03ce1:	pmovmskb ecx,xmm14
    7c479db03ce6:	jrcxz  0x7c479db03ced
    7c479db03ce8:	jmp    0x7c479db052e0
    7c479db03ced:	movdqa xmm12,xmm0
    7c479db03cf2:	movdqu XMMWORD PTR [r12+0x240],xmm12
    7c479db03cfc:	movdqa xmm0,xmm9
    7c479db03d01:	movdqa xmm1,xmm6
    7c479db03d05:	addpd  xmm0,xmm1
    7c479db03d09:	movdqa xmm14,xmm0
    7c479db03d0e:	movdqu xmm15,XMMWORD PTR [rip+0x8939]        # 0x7c479db0c650
    7c479db03d17:	pand   xmm14,xmm15
    7c479db03d1c:	movdqu xmm15,XMMWORD PTR [rip+0x893b]        # 0x7c479db0c660
    7c479db03d25:	pcmpeqq xmm14,xmm15
    7c479db03d2b:	movdqa xmm15,xmm0
    7c479db03d30:	cmpunordpd xmm15,xmm0
    7c479db03d36:	por    xmm14,xmm15
    7c479db03d3b:	pmovmskb ecx,xmm14
    7c479db03d40:	jrcxz  0x7c479db03d47
    7c479db03d42:	jmp    0x7c479db05305
    7c479db03d47:	movdqa xmm4,xmm0
    7c479db03d4b:	movdqu XMMWORD PTR [r12+0x220],xmm4
    7c479db03d55:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    7c479db03d5f:	movdqa xmm1,xmm7
    7c479db03d63:	pshufd xmm1,xmm1,0x44
    7c479db03d68:	mulpd  xmm0,xmm1
    7c479db03d6c:	movdqa xmm14,xmm0
    7c479db03d71:	movdqu xmm15,XMMWORD PTR [rip+0x88d6]        # 0x7c479db0c650
    7c479db03d7a:	pand   xmm14,xmm15
    7c479db03d7f:	movdqu xmm15,XMMWORD PTR [rip+0x88d8]        # 0x7c479db0c660
    7c479db03d88:	pcmpeqq xmm14,xmm15
    7c479db03d8e:	movdqa xmm15,xmm0
    7c479db03d93:	cmpunordpd xmm15,xmm0
    7c479db03d99:	por    xmm14,xmm15
    7c479db03d9e:	pmovmskb ecx,xmm14
    7c479db03da3:	jrcxz  0x7c479db03daa
    7c479db03da5:	jmp    0x7c479db0532a
    7c479db03daa:	movdqa xmm6,xmm0
    7c479db03dae:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7c479db03db8:	movdqa xmm1,xmm7
    7c479db03dbc:	pshufd xmm1,xmm1,0x44
    7c479db03dc1:	mulpd  xmm0,xmm1
    7c479db03dc5:	movdqa xmm14,xmm0
    7c479db03dca:	movdqu xmm15,XMMWORD PTR [rip+0x887d]        # 0x7c479db0c650
    7c479db03dd3:	pand   xmm14,xmm15
    7c479db03dd8:	movdqu xmm15,XMMWORD PTR [rip+0x887f]        # 0x7c479db0c660
    7c479db03de1:	pcmpeqq xmm14,xmm15
    7c479db03de7:	movdqa xmm15,xmm0
    7c479db03dec:	cmpunordpd xmm15,xmm0
    7c479db03df2:	por    xmm14,xmm15
    7c479db03df7:	pmovmskb ecx,xmm14
    7c479db03dfc:	jrcxz  0x7c479db03e03
    7c479db03dfe:	jmp    0x7c479db05354
    7c479db03e03:	movdqa xmm8,xmm0
    7c479db03e08:	movdqu XMMWORD PTR [r12+0x150],xmm8
    7c479db03e12:	movdqa xmm0,xmm3
    7c479db03e16:	movdqa xmm1,xmm10
    7c479db03e1b:	addpd  xmm0,xmm1
    7c479db03e1f:	movdqa xmm14,xmm0
    7c479db03e24:	movdqu xmm15,XMMWORD PTR [rip+0x8823]        # 0x7c479db0c650
    7c479db03e2d:	pand   xmm14,xmm15
    7c479db03e32:	movdqu xmm15,XMMWORD PTR [rip+0x8825]        # 0x7c479db0c660
    7c479db03e3b:	pcmpeqq xmm14,xmm15
    7c479db03e41:	movdqa xmm15,xmm0
    7c479db03e46:	cmpunordpd xmm15,xmm0
    7c479db03e4c:	por    xmm14,xmm15
    7c479db03e51:	pmovmskb ecx,xmm14
    7c479db03e56:	jrcxz  0x7c479db03e5d
    7c479db03e58:	jmp    0x7c479db0537e
    7c479db03e5d:	movdqa xmm7,xmm0
    7c479db03e61:	movdqu XMMWORD PTR [r12+0x160],xmm7
    7c479db03e6b:	movdqa xmm0,xmm2
    7c479db03e6f:	movdqa xmm1,xmm11
    7c479db03e74:	addpd  xmm0,xmm1
    7c479db03e78:	movdqa xmm14,xmm0
    7c479db03e7d:	movdqu xmm15,XMMWORD PTR [rip+0x87ca]        # 0x7c479db0c650
    7c479db03e86:	pand   xmm14,xmm15
    7c479db03e8b:	movdqu xmm15,XMMWORD PTR [rip+0x87cc]        # 0x7c479db0c660
    7c479db03e94:	pcmpeqq xmm14,xmm15
    7c479db03e9a:	movdqa xmm15,xmm0
    7c479db03e9f:	cmpunordpd xmm15,xmm0
    7c479db03ea5:	por    xmm14,xmm15
    7c479db03eaa:	pmovmskb ecx,xmm14
    7c479db03eaf:	jrcxz  0x7c479db03eb6
    7c479db03eb1:	jmp    0x7c479db053a3
    7c479db03eb6:	movdqa xmm3,xmm0
    7c479db03eba:	movdqu XMMWORD PTR [r12+0x170],xmm3
    7c479db03ec4:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    7c479db03ece:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7c479db03ed8:	movdqa xmm1,xmm2
    7c479db03edc:	pshufd xmm1,xmm1,0x44
    7c479db03ee1:	mulpd  xmm0,xmm1
    7c479db03ee5:	movdqa xmm14,xmm0
    7c479db03eea:	movdqu xmm15,XMMWORD PTR [rip+0x875d]        # 0x7c479db0c650
    7c479db03ef3:	pand   xmm14,xmm15
    7c479db03ef8:	movdqu xmm15,XMMWORD PTR [rip+0x875f]        # 0x7c479db0c660
    7c479db03f01:	pcmpeqq xmm14,xmm15
    7c479db03f07:	movdqa xmm15,xmm0
    7c479db03f0c:	cmpunordpd xmm15,xmm0
    7c479db03f12:	por    xmm14,xmm15
    7c479db03f17:	pmovmskb ecx,xmm14
    7c479db03f1c:	jrcxz  0x7c479db03f23
    7c479db03f1e:	jmp    0x7c479db053c8
    7c479db03f23:	movdqa xmm9,xmm0
    7c479db03f28:	movdqu XMMWORD PTR [r12+0x180],xmm9
    7c479db03f32:	movdqa xmm0,xmm4
    7c479db03f36:	movdqa xmm1,xmm5
    7c479db03f3a:	addpd  xmm0,xmm1
    7c479db03f3e:	movdqa xmm14,xmm0
    7c479db03f43:	movdqu xmm15,XMMWORD PTR [rip+0x8704]        # 0x7c479db0c650
    7c479db03f4c:	pand   xmm14,xmm15
    7c479db03f51:	movdqu xmm15,XMMWORD PTR [rip+0x8706]        # 0x7c479db0c660
    7c479db03f5a:	pcmpeqq xmm14,xmm15
    7c479db03f60:	movdqa xmm15,xmm0
    7c479db03f65:	cmpunordpd xmm15,xmm0
    7c479db03f6b:	por    xmm14,xmm15
    7c479db03f70:	pmovmskb ecx,xmm14
    7c479db03f75:	jrcxz  0x7c479db03f7c
    7c479db03f77:	jmp    0x7c479db053f2
    7c479db03f7c:	movdqa xmm10,xmm0
    7c479db03f81:	movdqu XMMWORD PTR [r12+0x210],xmm10
    7c479db03f8b:	movdqa xmm0,xmm12
    7c479db03f90:	movdqa xmm1,xmm6
    7c479db03f94:	addpd  xmm0,xmm1
    7c479db03f98:	movdqa xmm14,xmm0
    7c479db03f9d:	movdqu xmm15,XMMWORD PTR [rip+0x86aa]        # 0x7c479db0c650
    7c479db03fa6:	pand   xmm14,xmm15
    7c479db03fab:	movdqu xmm15,XMMWORD PTR [rip+0x86ac]        # 0x7c479db0c660
    7c479db03fb4:	pcmpeqq xmm14,xmm15
    7c479db03fba:	movdqa xmm15,xmm0
    7c479db03fbf:	cmpunordpd xmm15,xmm0
    7c479db03fc5:	por    xmm14,xmm15
    7c479db03fca:	pmovmskb ecx,xmm14
    7c479db03fcf:	jrcxz  0x7c479db03fd6
    7c479db03fd1:	jmp    0x7c479db05416
    7c479db03fd6:	movdqa xmm4,xmm0
    7c479db03fda:	movdqu XMMWORD PTR [r12+0x230],xmm4
    7c479db03fe4:	movdqu xmm5,XMMWORD PTR [r12+0x2a0]
    7c479db03fee:	movdqu xmm1,XMMWORD PTR [r12+0x2a0]
    7c479db03ff8:	por    xmm5,xmm1
    7c479db03ffc:	movdqu XMMWORD PTR [r12+0x250],xmm5
    7c479db04006:	movdqu xmm5,XMMWORD PTR [r12+0x1d0]
    7c479db04010:	movdqu xmm1,XMMWORD PTR [r12+0x1d0]
    7c479db0401a:	por    xmm5,xmm1
    7c479db0401e:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    7c479db04028:	movdqu xmm6,XMMWORD PTR [r12+0x2c0]
    7c479db04032:	movdqu xmm1,XMMWORD PTR [r12+0x2c0]
    7c479db0403c:	por    xmm6,xmm1
    7c479db04040:	movdqu XMMWORD PTR [r12+0x1d0],xmm6
    7c479db0404a:	mov    r13,r14
    7c479db0404d:	add    r13,0x40
    7c479db04051:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    7c479db04057:	movdqu XMMWORD PTR [r12+0x2c0],xmm6
    7c479db04061:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    7c479db0406b:	movdqa xmm1,xmm2
    7c479db0406f:	pshufd xmm1,xmm1,0x44
    7c479db04074:	mulpd  xmm0,xmm1
    7c479db04078:	movdqa xmm14,xmm0
    7c479db0407d:	movdqu xmm15,XMMWORD PTR [rip+0x85ca]        # 0x7c479db0c650
    7c479db04086:	pand   xmm14,xmm15
    7c479db0408b:	movdqu xmm15,XMMWORD PTR [rip+0x85cc]        # 0x7c479db0c660
    7c479db04094:	pcmpeqq xmm14,xmm15
    7c479db0409a:	movdqa xmm15,xmm0
    7c479db0409f:	cmpunordpd xmm15,xmm0
    7c479db040a5:	por    xmm14,xmm15
    7c479db040aa:	pmovmskb ecx,xmm14
    7c479db040af:	jrcxz  0x7c479db040b6
    7c479db040b1:	jmp    0x7c479db0543b
    7c479db040b6:	movdqa xmm11,xmm0
    7c479db040bb:	movdqa xmm0,xmm7
    7c479db040bf:	movdqa xmm1,xmm8
    7c479db040c4:	addpd  xmm0,xmm1
    7c479db040c8:	movdqa xmm14,xmm0
    7c479db040cd:	movdqu xmm15,XMMWORD PTR [rip+0x857a]        # 0x7c479db0c650
    7c479db040d6:	pand   xmm14,xmm15
    7c479db040db:	movdqu xmm15,XMMWORD PTR [rip+0x857c]        # 0x7c479db0c660
    7c479db040e4:	pcmpeqq xmm14,xmm15
    7c479db040ea:	movdqa xmm15,xmm0
    7c479db040ef:	cmpunordpd xmm15,xmm0
    7c479db040f5:	por    xmm14,xmm15
    7c479db040fa:	pmovmskb ecx,xmm14
    7c479db040ff:	jrcxz  0x7c479db04106
    7c479db04101:	jmp    0x7c479db05465
    7c479db04106:	movdqa xmm12,xmm0
    7c479db0410b:	movdqa xmm0,xmm3
    7c479db0410f:	movdqa xmm1,xmm9
    7c479db04114:	addpd  xmm0,xmm1
    7c479db04118:	movdqa xmm14,xmm0
    7c479db0411d:	movdqu xmm15,XMMWORD PTR [rip+0x852a]        # 0x7c479db0c650
    7c479db04126:	pand   xmm14,xmm15
    7c479db0412b:	movdqu xmm15,XMMWORD PTR [rip+0x852c]        # 0x7c479db0c660
    7c479db04134:	pcmpeqq xmm14,xmm15
    7c479db0413a:	movdqa xmm15,xmm0
    7c479db0413f:	cmpunordpd xmm15,xmm0
    7c479db04145:	por    xmm14,xmm15
    7c479db0414a:	pmovmskb ecx,xmm14
    7c479db0414f:	jrcxz  0x7c479db04156
    7c479db04151:	jmp    0x7c479db0548a
    7c479db04156:	movdqa xmm7,xmm0
    7c479db0415a:	movdqu XMMWORD PTR [r12+0x160],xmm7
    7c479db04164:	movdqa xmm0,xmm6
    7c479db04168:	movdqa xmm1,xmm2
    7c479db0416c:	pshufd xmm1,xmm1,0x44
    7c479db04171:	mulpd  xmm0,xmm1
    7c479db04175:	movdqa xmm14,xmm0
    7c479db0417a:	movdqu xmm15,XMMWORD PTR [rip+0x84cd]        # 0x7c479db0c650
    7c479db04183:	pand   xmm14,xmm15
    7c479db04188:	movdqu xmm15,XMMWORD PTR [rip+0x84cf]        # 0x7c479db0c660
    7c479db04191:	pcmpeqq xmm14,xmm15
    7c479db04197:	movdqa xmm15,xmm0
    7c479db0419c:	cmpunordpd xmm15,xmm0
    7c479db041a2:	por    xmm14,xmm15
    7c479db041a7:	pmovmskb ecx,xmm14
    7c479db041ac:	jrcxz  0x7c479db041b3
    7c479db041ae:	jmp    0x7c479db054af
    7c479db041b3:	movdqa xmm3,xmm0
    7c479db041b7:	movdqu XMMWORD PTR [r12+0x240],xmm3
    7c479db041c1:	movdqu xmm6,XMMWORD PTR [r12+0x2b0]
    7c479db041cb:	movdqa xmm0,xmm6
    7c479db041cf:	movdqa xmm1,xmm2
    7c479db041d3:	pshufd xmm1,xmm1,0x44
    7c479db041d8:	mulpd  xmm0,xmm1
    7c479db041dc:	movdqa xmm14,xmm0
    7c479db041e1:	movdqu xmm15,XMMWORD PTR [rip+0x8466]        # 0x7c479db0c650
    7c479db041ea:	pand   xmm14,xmm15
    7c479db041ef:	movdqu xmm15,XMMWORD PTR [rip+0x8468]        # 0x7c479db0c660
    7c479db041f8:	pcmpeqq xmm14,xmm15
    7c479db041fe:	movdqa xmm15,xmm0
    7c479db04203:	cmpunordpd xmm15,xmm0
    7c479db04209:	por    xmm14,xmm15
    7c479db0420e:	pmovmskb ecx,xmm14
    7c479db04213:	jrcxz  0x7c479db0421a
    7c479db04215:	jmp    0x7c479db054d3
    7c479db0421a:	movdqa xmm8,xmm0
    7c479db0421f:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    7c479db04229:	movdqa xmm0,xmm5
    7c479db0422d:	movdqa xmm1,xmm2
    7c479db04231:	pshufd xmm1,xmm1,0x44
    7c479db04236:	mulpd  xmm0,xmm1
    7c479db0423a:	movdqa xmm14,xmm0
    7c479db0423f:	movdqu xmm15,XMMWORD PTR [rip+0x8408]        # 0x7c479db0c650
    7c479db04248:	pand   xmm14,xmm15
    7c479db0424d:	movdqu xmm15,XMMWORD PTR [rip+0x840a]        # 0x7c479db0c660
    7c479db04256:	pcmpeqq xmm14,xmm15
    7c479db0425c:	movdqa xmm15,xmm0
    7c479db04261:	cmpunordpd xmm15,xmm0
    7c479db04267:	por    xmm14,xmm15
    7c479db0426c:	pmovmskb ecx,xmm14
    7c479db04271:	jrcxz  0x7c479db04278
    7c479db04273:	jmp    0x7c479db054f7
    7c479db04278:	movdqa xmm6,xmm0
    7c479db0427c:	movdqu XMMWORD PTR [r12+0x170],xmm6
    7c479db04286:	movdqa xmm0,xmm10
    7c479db0428b:	movdqa xmm1,xmm11
    7c479db04290:	addpd  xmm0,xmm1
    7c479db04294:	movdqa xmm14,xmm0
    7c479db04299:	movdqu xmm15,XMMWORD PTR [rip+0x83ae]        # 0x7c479db0c650
    7c479db042a2:	pand   xmm14,xmm15
    7c479db042a7:	movdqu xmm15,XMMWORD PTR [rip+0x83b0]        # 0x7c479db0c660
    7c479db042b0:	pcmpeqq xmm14,xmm15
    7c479db042b6:	movdqa xmm15,xmm0
    7c479db042bb:	cmpunordpd xmm15,xmm0
    7c479db042c1:	por    xmm14,xmm15
    7c479db042c6:	pmovmskb ecx,xmm14
    7c479db042cb:	jrcxz  0x7c479db042d2
    7c479db042cd:	jmp    0x7c479db0551b
    7c479db042d2:	movdqa xmm5,xmm0
    7c479db042d6:	movdqu XMMWORD PTR [r12+0x180],xmm5
    7c479db042e0:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c479db042ea:	movdqa xmm1,xmm2
    7c479db042ee:	pshufd xmm1,xmm1,0x44
    7c479db042f3:	mulpd  xmm0,xmm1
    7c479db042f7:	movdqa xmm14,xmm0
    7c479db042fc:	movdqu xmm15,XMMWORD PTR [rip+0x834b]        # 0x7c479db0c650
    7c479db04305:	pand   xmm14,xmm15
    7c479db0430a:	movdqu xmm15,XMMWORD PTR [rip+0x834d]        # 0x7c479db0c660
    7c479db04313:	pcmpeqq xmm14,xmm15
    7c479db04319:	movdqa xmm15,xmm0
    7c479db0431e:	cmpunordpd xmm15,xmm0
    7c479db04324:	por    xmm14,xmm15
    7c479db04329:	pmovmskb ecx,xmm14
    7c479db0432e:	jrcxz  0x7c479db04335
    7c479db04330:	jmp    0x7c479db05541
    7c479db04335:	movdqa xmm9,xmm0
    7c479db0433a:	movdqu XMMWORD PTR [r12+0x210],xmm9
    7c479db04344:	movdqa xmm0,xmm4
    7c479db04348:	movdqa xmm1,xmm3
    7c479db0434c:	addpd  xmm0,xmm1
    7c479db04350:	movdqa xmm14,xmm0
    7c479db04355:	movdqu xmm15,XMMWORD PTR [rip+0x82f2]        # 0x7c479db0c650
    7c479db0435e:	pand   xmm14,xmm15
    7c479db04363:	movdqu xmm15,XMMWORD PTR [rip+0x82f4]        # 0x7c479db0c660
    7c479db0436c:	pcmpeqq xmm14,xmm15
    7c479db04372:	movdqa xmm15,xmm0
    7c479db04377:	cmpunordpd xmm15,xmm0
    7c479db0437d:	por    xmm14,xmm15
    7c479db04382:	pmovmskb ecx,xmm14
    7c479db04387:	jrcxz  0x7c479db0438e
    7c479db04389:	jmp    0x7c479db0556b
    7c479db0438e:	movdqa xmm10,xmm0
    7c479db04393:	movdqu XMMWORD PTR [r12+0x220],xmm10
    7c479db0439d:	movdqu xmm3,XMMWORD PTR [r12+0x290]
    7c479db043a7:	movdqa xmm0,xmm3
    7c479db043ab:	movdqa xmm1,xmm2
    7c479db043af:	pshufd xmm1,xmm1,0x44
    7c479db043b4:	mulpd  xmm0,xmm1
    7c479db043b8:	movdqa xmm14,xmm0
    7c479db043bd:	movdqu xmm15,XMMWORD PTR [rip+0x828a]        # 0x7c479db0c650
    7c479db043c6:	pand   xmm14,xmm15
    7c479db043cb:	movdqu xmm15,XMMWORD PTR [rip+0x828c]        # 0x7c479db0c660
    7c479db043d4:	pcmpeqq xmm14,xmm15
    7c479db043da:	movdqa xmm15,xmm0
    7c479db043df:	cmpunordpd xmm15,xmm0
    7c479db043e5:	por    xmm14,xmm15
    7c479db043ea:	pmovmskb ecx,xmm14
    7c479db043ef:	jrcxz  0x7c479db043f6
    7c479db043f1:	jmp    0x7c479db0558f
    7c479db043f6:	movdqa xmm4,xmm0
    7c479db043fa:	movdqu XMMWORD PTR [r12+0x230],xmm4
    7c479db04404:	movdqa xmm0,xmm12
    7c479db04409:	movdqa xmm1,xmm8
    7c479db0440e:	addpd  xmm0,xmm1
    7c479db04412:	movdqa xmm14,xmm0
    7c479db04417:	movdqu xmm15,XMMWORD PTR [rip+0x8230]        # 0x7c479db0c650
    7c479db04420:	pand   xmm14,xmm15
    7c479db04425:	movdqu xmm15,XMMWORD PTR [rip+0x8232]        # 0x7c479db0c660
    7c479db0442e:	pcmpeqq xmm14,xmm15
    7c479db04434:	movdqa xmm15,xmm0
    7c479db04439:	cmpunordpd xmm15,xmm0
    7c479db0443f:	por    xmm14,xmm15
    7c479db04444:	pmovmskb ecx,xmm14
    7c479db04449:	jrcxz  0x7c479db04450
    7c479db0444b:	jmp    0x7c479db055b3
    7c479db04450:	movdqa xmm3,xmm0
    7c479db04454:	movdqu XMMWORD PTR [r12+0x140],xmm3
    7c479db0445e:	movdqu xmm8,XMMWORD PTR [r12+0x1e0]
    7c479db04468:	movdqa xmm0,xmm8
    7c479db0446d:	movdqa xmm1,xmm2
    7c479db04471:	pshufd xmm1,xmm1,0x44
    7c479db04476:	mulpd  xmm0,xmm1
    7c479db0447a:	movdqa xmm14,xmm0
    7c479db0447f:	movdqu xmm15,XMMWORD PTR [rip+0x81c8]        # 0x7c479db0c650
    7c479db04488:	pand   xmm14,xmm15
    7c479db0448d:	movdqu xmm15,XMMWORD PTR [rip+0x81ca]        # 0x7c479db0c660
    7c479db04496:	pcmpeqq xmm14,xmm15
    7c479db0449c:	movdqa xmm15,xmm0
    7c479db044a1:	cmpunordpd xmm15,xmm0
    7c479db044a7:	por    xmm14,xmm15
    7c479db044ac:	pmovmskb ecx,xmm14
    7c479db044b1:	jrcxz  0x7c479db044b8
    7c479db044b3:	jmp    0x7c479db055d9
    7c479db044b8:	movdqa xmm11,xmm0
    7c479db044bd:	movdqu XMMWORD PTR [r12+0x130],xmm11
    7c479db044c7:	movdqa xmm0,xmm7
    7c479db044cb:	movdqa xmm1,xmm6
    7c479db044cf:	addpd  xmm0,xmm1
    7c479db044d3:	movdqa xmm14,xmm0
    7c479db044d8:	movdqu xmm15,XMMWORD PTR [rip+0x816f]        # 0x7c479db0c650
    7c479db044e1:	pand   xmm14,xmm15
    7c479db044e6:	movdqu xmm15,XMMWORD PTR [rip+0x8171]        # 0x7c479db0c660
    7c479db044ef:	pcmpeqq xmm14,xmm15
    7c479db044f5:	movdqa xmm15,xmm0
    7c479db044fa:	cmpunordpd xmm15,xmm0
    7c479db04500:	por    xmm14,xmm15
    7c479db04505:	pmovmskb ecx,xmm14
    7c479db0450a:	jrcxz  0x7c479db04511
    7c479db0450c:	jmp    0x7c479db055fe
    7c479db04511:	movdqa xmm2,xmm0
    7c479db04515:	movdqu XMMWORD PTR [r12+0x150],xmm2
    7c479db0451f:	mov    r13,r14
    7c479db04522:	add    r13,0x70
    7c479db04526:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    7c479db0452c:	movdqu XMMWORD PTR [r12+0x240],xmm6
    7c479db04536:	movdqa xmm0,xmm5
    7c479db0453a:	movdqa xmm1,xmm9
    7c479db0453f:	addpd  xmm0,xmm1
    7c479db04543:	movdqa xmm14,xmm0
    7c479db04548:	movdqu xmm15,XMMWORD PTR [rip+0x80ff]        # 0x7c479db0c650
    7c479db04551:	pand   xmm14,xmm15
    7c479db04556:	movdqu xmm15,XMMWORD PTR [rip+0x8101]        # 0x7c479db0c660
    7c479db0455f:	pcmpeqq xmm14,xmm15
    7c479db04565:	movdqa xmm15,xmm0
    7c479db0456a:	cmpunordpd xmm15,xmm0
    7c479db04570:	por    xmm14,xmm15
    7c479db04575:	pmovmskb ecx,xmm14
    7c479db0457a:	jrcxz  0x7c479db04581
    7c479db0457c:	jmp    0x7c479db05622
    7c479db04581:	movdqa xmm7,xmm0
    7c479db04585:	movdqu XMMWORD PTR [r12+0x170],xmm7
    7c479db0458f:	movdqu xmm5,XMMWORD PTR [r12+0x280]
    7c479db04599:	movdqa xmm0,xmm6
    7c479db0459d:	movdqa xmm1,xmm5
    7c479db045a1:	pshufd xmm1,xmm1,0x44
    7c479db045a6:	mulpd  xmm0,xmm1
    7c479db045aa:	movdqa xmm14,xmm0
    7c479db045af:	movdqu xmm15,XMMWORD PTR [rip+0x8098]        # 0x7c479db0c650
    7c479db045b8:	pand   xmm14,xmm15
    7c479db045bd:	movdqu xmm15,XMMWORD PTR [rip+0x809a]        # 0x7c479db0c660
    7c479db045c6:	pcmpeqq xmm14,xmm15
    7c479db045cc:	movdqa xmm15,xmm0
    7c479db045d1:	cmpunordpd xmm15,xmm0
    7c479db045d7:	por    xmm14,xmm15
    7c479db045dc:	pmovmskb ecx,xmm14
    7c479db045e1:	jrcxz  0x7c479db045e8
    7c479db045e3:	jmp    0x7c479db05647
    7c479db045e8:	movdqa xmm8,xmm0
    7c479db045ed:	movdqu XMMWORD PTR [r12+0x160],xmm8
    7c479db045f7:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7c479db04601:	movdqa xmm1,xmm5
    7c479db04605:	pshufd xmm1,xmm1,0x44
    7c479db0460a:	mulpd  xmm0,xmm1
    7c479db0460e:	movdqa xmm14,xmm0
    7c479db04613:	movdqu xmm15,XMMWORD PTR [rip+0x8034]        # 0x7c479db0c650
    7c479db0461c:	pand   xmm14,xmm15
    7c479db04621:	movdqu xmm15,XMMWORD PTR [rip+0x8036]        # 0x7c479db0c660
    7c479db0462a:	pcmpeqq xmm14,xmm15
    7c479db04630:	movdqa xmm15,xmm0
    7c479db04635:	cmpunordpd xmm15,xmm0
    7c479db0463b:	por    xmm14,xmm15
    7c479db04640:	pmovmskb ecx,xmm14
    7c479db04645:	jrcxz  0x7c479db0464c
    7c479db04647:	jmp    0x7c479db0566b
    7c479db0464c:	movdqa xmm6,xmm0
    7c479db04650:	movdqu XMMWORD PTR [r12+0x180],xmm6
    7c479db0465a:	movdqa xmm0,xmm10
    7c479db0465f:	movdqa xmm1,xmm4
    7c479db04663:	addpd  xmm0,xmm1
    7c479db04667:	movdqa xmm14,xmm0
    7c479db0466c:	movdqu xmm15,XMMWORD PTR [rip+0x7fdb]        # 0x7c479db0c650
    7c479db04675:	pand   xmm14,xmm15
    7c479db0467a:	movdqu xmm15,XMMWORD PTR [rip+0x7fdd]        # 0x7c479db0c660
    7c479db04683:	pcmpeqq xmm14,xmm15
    7c479db04689:	movdqa xmm15,xmm0
    7c479db0468e:	cmpunordpd xmm15,xmm0
    7c479db04694:	por    xmm14,xmm15
    7c479db04699:	pmovmskb ecx,xmm14
    7c479db0469e:	jrcxz  0x7c479db046a5
    7c479db046a0:	jmp    0x7c479db05695
    7c479db046a5:	movdqa xmm9,xmm0
    7c479db046aa:	movdqu XMMWORD PTR [r12+0x210],xmm9
    7c479db046b4:	mov    r13,r14
    7c479db046b7:	add    r13,0x10
    7c479db046bb:	movdqu xmm4,XMMWORD PTR [r14]
    7c479db046c0:	movdqu xmm10,XMMWORD PTR [r13+0x0]
    7c479db046c6:	movdqu XMMWORD PTR [r12+0x230],xmm10
    7c479db046d0:	movdqa xmm0,xmm3
    7c479db046d4:	movdqa xmm1,xmm11
    7c479db046d9:	addpd  xmm0,xmm1
    7c479db046dd:	movdqa xmm14,xmm0
    7c479db046e2:	movdqu xmm15,XMMWORD PTR [rip+0x7f65]        # 0x7c479db0c650
    7c479db046eb:	pand   xmm14,xmm15
    7c479db046f0:	movdqu xmm15,XMMWORD PTR [rip+0x7f67]        # 0x7c479db0c660
    7c479db046f9:	pcmpeqq xmm14,xmm15
    7c479db046ff:	movdqa xmm15,xmm0
    7c479db04704:	cmpunordpd xmm15,xmm0
    7c479db0470a:	por    xmm14,xmm15
    7c479db0470f:	pmovmskb ecx,xmm14
    7c479db04714:	jrcxz  0x7c479db0471b
    7c479db04716:	jmp    0x7c479db056ba
    7c479db0471b:	movdqa xmm12,xmm0
    7c479db04720:	movdqu XMMWORD PTR [r12+0x130],xmm12
    7c479db0472a:	movdqa xmm0,xmm10
    7c479db0472f:	movdqa xmm1,xmm5
    7c479db04733:	pshufd xmm1,xmm1,0x44
    7c479db04738:	mulpd  xmm0,xmm1
    7c479db0473c:	movdqa xmm14,xmm0
    7c479db04741:	movdqu xmm15,XMMWORD PTR [rip+0x7f06]        # 0x7c479db0c650
    7c479db0474a:	pand   xmm14,xmm15
    7c479db0474f:	movdqu xmm15,XMMWORD PTR [rip+0x7f08]        # 0x7c479db0c660
    7c479db04758:	pcmpeqq xmm14,xmm15
    7c479db0475e:	movdqa xmm15,xmm0
    7c479db04763:	cmpunordpd xmm15,xmm0
    7c479db04769:	por    xmm14,xmm15
    7c479db0476e:	pmovmskb ecx,xmm14
    7c479db04773:	jrcxz  0x7c479db0477a
    7c479db04775:	jmp    0x7c479db056df
    7c479db0477a:	movdqa xmm3,xmm0
    7c479db0477e:	movdqu XMMWORD PTR [r12+0x220],xmm3
    7c479db04788:	movdqa xmm0,xmm4
    7c479db0478c:	movdqa xmm1,xmm5
    7c479db04790:	pshufd xmm1,xmm1,0x44
    7c479db04795:	mulpd  xmm0,xmm1
    7c479db04799:	movdqa xmm14,xmm0
    7c479db0479e:	movdqu xmm15,XMMWORD PTR [rip+0x7ea9]        # 0x7c479db0c650
    7c479db047a7:	pand   xmm14,xmm15
    7c479db047ac:	movdqu xmm15,XMMWORD PTR [rip+0x7eab]        # 0x7c479db0c660
    7c479db047b5:	pcmpeqq xmm14,xmm15
    7c479db047bb:	movdqa xmm15,xmm0
    7c479db047c0:	cmpunordpd xmm15,xmm0
    7c479db047c6:	por    xmm14,xmm15
    7c479db047cb:	pmovmskb ecx,xmm14
    7c479db047d0:	jrcxz  0x7c479db047d7
    7c479db047d2:	jmp    0x7c479db05704
    7c479db047d7:	movdqa xmm10,xmm0
    7c479db047dc:	movdqa xmm0,xmm2
    7c479db047e0:	movdqa xmm1,xmm8
    7c479db047e5:	addpd  xmm0,xmm1
    7c479db047e9:	movdqa xmm14,xmm0
    7c479db047ee:	movdqu xmm15,XMMWORD PTR [rip+0x7e59]        # 0x7c479db0c650
    7c479db047f7:	pand   xmm14,xmm15
    7c479db047fc:	movdqu xmm15,XMMWORD PTR [rip+0x7e5b]        # 0x7c479db0c660
    7c479db04805:	pcmpeqq xmm14,xmm15
    7c479db0480b:	movdqa xmm15,xmm0
    7c479db04810:	cmpunordpd xmm15,xmm0
    7c479db04816:	por    xmm14,xmm15
    7c479db0481b:	pmovmskb ecx,xmm14
    7c479db04820:	jrcxz  0x7c479db04827
    7c479db04822:	jmp    0x7c479db05728
    7c479db04827:	movdqa xmm4,xmm0
    7c479db0482b:	movdqu XMMWORD PTR [r12+0x140],xmm4
    7c479db04835:	movdqa xmm0,xmm7
    7c479db04839:	movdqa xmm1,xmm6
    7c479db0483d:	addpd  xmm0,xmm1
    7c479db04841:	movdqa xmm14,xmm0
    7c479db04846:	movdqu xmm15,XMMWORD PTR [rip+0x7e01]        # 0x7c479db0c650
    7c479db0484f:	pand   xmm14,xmm15
    7c479db04854:	movdqu xmm15,XMMWORD PTR [rip+0x7e03]        # 0x7c479db0c660
    7c479db0485d:	pcmpeqq xmm14,xmm15
    7c479db04863:	movdqa xmm15,xmm0
    7c479db04868:	cmpunordpd xmm15,xmm0
    7c479db0486e:	por    xmm14,xmm15
    7c479db04873:	pmovmskb ecx,xmm14
    7c479db04878:	jrcxz  0x7c479db0487f
    7c479db0487a:	jmp    0x7c479db0574d
    7c479db0487f:	movdqa xmm2,xmm0
    7c479db04883:	movdqu XMMWORD PTR [r12+0x150],xmm2
    7c479db0488d:	movdqa xmm0,xmm9
    7c479db04892:	movdqa xmm1,xmm3
    7c479db04896:	addpd  xmm0,xmm1
    7c479db0489a:	movdqa xmm14,xmm0
    7c479db0489f:	movdqu xmm15,XMMWORD PTR [rip+0x7da8]        # 0x7c479db0c650
    7c479db048a8:	pand   xmm14,xmm15
    7c479db048ad:	movdqu xmm15,XMMWORD PTR [rip+0x7daa]        # 0x7c479db0c660
    7c479db048b6:	pcmpeqq xmm14,xmm15
    7c479db048bc:	movdqa xmm15,xmm0
    7c479db048c1:	cmpunordpd xmm15,xmm0
    7c479db048c7:	por    xmm14,xmm15
    7c479db048cc:	pmovmskb ecx,xmm14
    7c479db048d1:	jrcxz  0x7c479db048d8
    7c479db048d3:	jmp    0x7c479db05771
    7c479db048d8:	movdqa xmm5,xmm0
    7c479db048dc:	movdqu XMMWORD PTR [r12+0x160],xmm5
    7c479db048e6:	movdqa xmm0,xmm12
    7c479db048eb:	movdqa xmm1,xmm10
    7c479db048f0:	addpd  xmm0,xmm1
    7c479db048f4:	movdqa xmm14,xmm0
    7c479db048f9:	movdqu xmm15,XMMWORD PTR [rip+0x7d4e]        # 0x7c479db0c650
    7c479db04902:	pand   xmm14,xmm15
    7c479db04907:	movdqu xmm15,XMMWORD PTR [rip+0x7d50]        # 0x7c479db0c660
    7c479db04910:	pcmpeqq xmm14,xmm15
    7c479db04916:	movdqa xmm15,xmm0
    7c479db0491b:	cmpunordpd xmm15,xmm0
    7c479db04921:	por    xmm14,xmm15
    7c479db04926:	pmovmskb ecx,xmm14
    7c479db0492b:	jrcxz  0x7c479db04932
    7c479db0492d:	jmp    0x7c479db05796
    7c479db04932:	movdqa xmm3,xmm0
    7c479db04936:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7c479db04940:	mov    r13,r15
    7c479db04943:	add    r13,0x10
    7c479db04947:	movdqu XMMWORD PTR [r15],xmm4
    7c479db0494c:	mov    r14d,0x0
    7c479db04952:	mov    DWORD PTR [r12+0x32c],r14d
    7c479db0495a:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7c479db04960:	add    r15,0x20
    7c479db04964:	mov    r13,r15
    7c479db04967:	add    r13,0x10
    7c479db0496b:	movdqu XMMWORD PTR [r15],xmm5
    7c479db04970:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7c479db04976:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db0497e:	jrcxz  0x7c479db04985
    7c479db04980:	jmp    0x7c479db0bd1d
    7c479db04985:	cmp    BYTE PTR [rsp+0x8],0x0
    7c479db0498a:	jne    0x7c479db02c55
    7c479db04990:	jmp    0x7c479db04995
    7c479db04995:	mov    r13d,DWORD PTR [r12+0x48]
    7c479db0499a:	add    r13d,0x1
    7c479db0499e:	mov    QWORD PTR [r12+0x48],r13
    7c479db049a3:	sub    r13d,0x1f4
    7c479db049aa:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db049b2:	jrcxz  0x7c479db049b9
    7c479db049b4:	jmp    0x7c479db0bda2
    7c479db049b9:	jne    0x7c479db02c37
    7c479db049bf:	mov    r11,rax
    7c479db049c2:	lahf
    7c479db049c3:	seto   al
    7c479db049c6:	mov    WORD PTR [rsp],ax
    7c479db049ca:	mov    rax,r11
    7c479db049cd:	jmp    0x7c479db049d2
    7c479db049d2:	mov    r13d,0x430000
    7c479db049d8:	mov    QWORD PTR [r12+0x40],r13
    7c479db049dd:	mov    r13d,0x0
    7c479db049e3:	mov    QWORD PTR [r12+0x48],r13
    7c479db049e8:	mov    r13d,0x430cc0
    7c479db049ee:	mov    r14,QWORD PTR [r13+0x0]
    7c479db049f2:	mov    r13d,0x0
    7c479db049f8:	mov    QWORD PTR [r12+0x110],r14
    7c479db04a00:	mov    QWORD PTR [r12+0x118],r13
    7c479db04a08:	jmp    0x7c479db04a0d
    7c479db04a0d:	mov    r13,QWORD PTR [r12+0x48]
    7c479db04a12:	mov    r14,QWORD PTR [r12+0x50]
    7c479db04a17:	add    r14,r13
    7c479db04a1a:	movdqu xmm2,XMMWORD PTR [r14]
    7c479db04a1f:	movdqu XMMWORD PTR [r12+0x120],xmm2
    7c479db04a29:	add    r13,0x10
    7c479db04a2d:	mov    QWORD PTR [r12+0x48],r13
    7c479db04a32:	sub    r13,0x200
    7c479db04a39:	mov    r13,QWORD PTR [r12+0x128]
    7c479db04a41:	mov    r14d,0x0
    7c479db04a47:	mov    QWORD PTR [r12+0x130],r13
    7c479db04a4f:	mov    QWORD PTR [r12+0x138],r14
    7c479db04a57:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    7c479db04a61:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    7c479db04a6b:	movdqa xmm0,xmm2
    7c479db04a6f:	movdqa xmm1,xmm3
    7c479db04a73:	movq   xmm0,xmm0
    7c479db04a77:	movq   xmm1,xmm1
    7c479db04a7b:	addsd  xmm0,xmm1
    7c479db04a7f:	movdqa xmm14,xmm0
    7c479db04a84:	movdqu xmm15,XMMWORD PTR [rip+0x7bc3]        # 0x7c479db0c650
    7c479db04a8d:	pand   xmm14,xmm15
    7c479db04a92:	movdqu xmm15,XMMWORD PTR [rip+0x7bc5]        # 0x7c479db0c660
    7c479db04a9b:	pcmpeqq xmm14,xmm15
    7c479db04aa1:	movdqa xmm15,xmm0
    7c479db04aa6:	cmpunordpd xmm15,xmm0
    7c479db04aac:	por    xmm14,xmm15
    7c479db04ab1:	pmovmskb ecx,xmm14
    7c479db04ab6:	jrcxz  0x7c479db04abd
    7c479db04ab8:	jmp    0x7c479db057bc
    7c479db04abd:	movdqa xmm4,xmm0
    7c479db04ac1:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    7c479db04acb:	movdqa xmm0,xmm4
    7c479db04acf:	movdqa xmm1,xmm2
    7c479db04ad3:	movq   xmm0,xmm0
    7c479db04ad7:	movq   xmm1,xmm1
    7c479db04adb:	addsd  xmm0,xmm1
    7c479db04adf:	movdqa xmm14,xmm0
    7c479db04ae4:	movdqu xmm15,XMMWORD PTR [rip+0x7b63]        # 0x7c479db0c650
    7c479db04aed:	pand   xmm14,xmm15
    7c479db04af2:	movdqu xmm15,XMMWORD PTR [rip+0x7b65]        # 0x7c479db0c660
    7c479db04afb:	pcmpeqq xmm14,xmm15
    7c479db04b01:	movdqa xmm15,xmm0
    7c479db04b06:	cmpunordpd xmm15,xmm0
    7c479db04b0c:	por    xmm14,xmm15
    7c479db04b11:	pmovmskb ecx,xmm14
    7c479db04b16:	jrcxz  0x7c479db04b1d
    7c479db04b18:	jmp    0x7c479db057fb
    7c479db04b1d:	movdqa xmm3,xmm0
    7c479db04b21:	movdqu XMMWORD PTR [r12+0x110],xmm3
    7c479db04b2b:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db04b33:	jrcxz  0x7c479db04b3a
    7c479db04b35:	jmp    0x7c479db0be36
    7c479db04b3a:	jne    0x7c479db04b53
    7c479db04b40:	mov    r11,rax
    7c479db04b43:	lahf
    7c479db04b44:	seto   al
    7c479db04b47:	mov    WORD PTR [rsp],ax
    7c479db04b4b:	mov    rax,r11
    7c479db04b4e:	jmp    0x7c479db04b66
    7c479db04b53:	mov    r11,rax
    7c479db04b56:	lahf
    7c479db04b57:	seto   al
    7c479db04b5a:	mov    WORD PTR [rsp],ax
    7c479db04b5e:	mov    rax,r11
    7c479db04b61:	jmp    0x7c479db04a0d
    7c479db04b66:	mov    r13,QWORD PTR [r12+0xf8]
    7c479db04b6e:	mov    r14,r13
    7c479db04b71:	add    r14,0x1d0
    7c479db04b78:	mov    r15,r14
    7c479db04b7b:	add    r15,0x8
    7c479db04b7f:	mov    rbp,QWORD PTR [r14]
    7c479db04b82:	mov    r14,QWORD PTR [r15]
    7c479db04b85:	mov    QWORD PTR [r12+0xa0],rbp
    7c479db04b8d:	mov    QWORD PTR [r12+0x98],r14
    7c479db04b95:	mov    r14,QWORD PTR [r12+0x40]
    7c479db04b9a:	add    r14,0xcc0
    7c479db04ba1:	mov    r15,QWORD PTR [r12+0x110]
    7c479db04ba9:	mov    QWORD PTR [r14],r15
    7c479db04bac:	mov    r14d,0x0
    7c479db04bb2:	mov    DWORD PTR [r12+0x32c],r14d
    7c479db04bba:	mov    r14,r13
    7c479db04bbd:	add    r14,0x1c0
    7c479db04bc4:	mov    r15,r14
    7c479db04bc7:	add    r15,0x8
    7c479db04bcb:	mov    rbp,QWORD PTR [r14]
    7c479db04bce:	mov    r14,QWORD PTR [r15]
    7c479db04bd1:	mov    QWORD PTR [r12+0xe8],rbp
    7c479db04bd9:	mov    QWORD PTR [r12+0xf0],r14
    7c479db04be1:	mov    r14,r13
    7c479db04be4:	add    r14,0x1b0
    7c479db04beb:	mov    r15,r14
    7c479db04bee:	add    r15,0x8
    7c479db04bf2:	mov    rbp,QWORD PTR [r14]
    7c479db04bf5:	mov    r14,QWORD PTR [r15]
    7c479db04bf8:	mov    r15d,0x0
    7c479db04bfe:	mov    QWORD PTR [r12+0x1a0],rbp
    7c479db04c06:	mov    QWORD PTR [r12+0x1a8],r15
    7c479db04c0e:	mov    r15d,0x0
    7c479db04c14:	mov    QWORD PTR [r12+0x190],r14
    7c479db04c1c:	mov    QWORD PTR [r12+0x198],r15
    7c479db04c24:	mov    r14,r13
    7c479db04c27:	add    r14,0x1a0
    7c479db04c2e:	mov    r15,r14
    7c479db04c31:	add    r15,0x8
    7c479db04c35:	mov    rbp,QWORD PTR [r14]
    7c479db04c38:	mov    r14,QWORD PTR [r15]
    7c479db04c3b:	mov    r15d,0x0
    7c479db04c41:	mov    QWORD PTR [r12+0x1c0],rbp
    7c479db04c49:	mov    QWORD PTR [r12+0x1c8],r15
    7c479db04c51:	mov    r15d,0x0
    7c479db04c57:	mov    QWORD PTR [r12+0x1b0],r14
    7c479db04c5f:	mov    QWORD PTR [r12+0x1b8],r15
    7c479db04c67:	mov    r14,r13
    7c479db04c6a:	add    r14,0x190
    7c479db04c71:	mov    r15,r14
    7c479db04c74:	add    r15,0x8
    7c479db04c78:	mov    rbp,QWORD PTR [r14]
    7c479db04c7b:	mov    r14,QWORD PTR [r15]
    7c479db04c7e:	mov    r15d,0x0
    7c479db04c84:	mov    QWORD PTR [r12+0x1e0],rbp
    7c479db04c8c:	mov    QWORD PTR [r12+0x1e8],r15
    7c479db04c94:	mov    r15d,0x0
    7c479db04c9a:	mov    QWORD PTR [r12+0x1d0],r14
    7c479db04ca2:	mov    QWORD PTR [r12+0x1d8],r15
    7c479db04caa:	mov    r14,r13
    7c479db04cad:	add    r14,0x180
    7c479db04cb4:	mov    r15,r14
    7c479db04cb7:	add    r15,0x8
    7c479db04cbb:	mov    rbp,QWORD PTR [r14]
    7c479db04cbe:	mov    r14,QWORD PTR [r15]
    7c479db04cc1:	mov    r15d,0x0
    7c479db04cc7:	mov    QWORD PTR [r12+0x200],rbp
    7c479db04ccf:	mov    QWORD PTR [r12+0x208],r15
    7c479db04cd7:	mov    r15d,0x0
    7c479db04cdd:	mov    QWORD PTR [r12+0x1f0],r14
    7c479db04ce5:	mov    QWORD PTR [r12+0x1f8],r15
    7c479db04ced:	add    r13,0x1e0
    7c479db04cf4:	mov    QWORD PTR [r12+0xf8],r13
    7c479db04cfc:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db04d04:	jrcxz  0x7c479db04d0b
    7c479db04d06:	jmp    0x7c479db0beca
    7c479db04d0b:	mov    r13,QWORD PTR [r12+0xf0]
    7c479db04d13:	mov    QWORD PTR [r12+0x100],r13
    7c479db04d1b:	mov    r11,QWORD PTR [rsp]
    7c479db04d1f:	mov    QWORD PTR [r12+0x398],r11
    7c479db04d27:	mov    rdi,QWORD PTR [r12+0x100]
    7c479db04d2f:	add    rsp,0x150
    7c479db04d36:	movabs r11,0x62fe87327940
    7c479db04d40:	jmp    r11
    7c479db04d43:	mov    r13d,DWORD PTR [r12+0x98]
    7c479db04d4b:	mov    r14d,DWORD PTR [r12]
    7c479db04d4f:	add    r14d,r13d
    7c479db04d52:	mov    QWORD PTR [r12],r14
    7c479db04d56:	mov    r13d,0x4103f8
    7c479db04d5c:	mov    QWORD PTR [r12+0xf0],r13
    7c479db04d64:	mov    r13d,0x4109a4
    7c479db04d6a:	mov    QWORD PTR [r12+0x100],r13
    7c479db04d72:	mov    r11,QWORD PTR [rsp]
    7c479db04d76:	mov    QWORD PTR [r12+0x398],r11
    7c479db04d7e:	mov    edi,0x4109a4
    7c479db04d83:	mov    QWORD PTR [r12+0x100],rdi
    7c479db04d8b:	add    rsp,0x150
    7c479db04d92:	nop    WORD PTR [rax+rax*1+0x0]
    7c479db04d98:	jmp    QWORD PTR [rip+0x2]        # 0x7c479db04da0
    7c479db04d9e:	xchg   ax,ax
    7c479db04da0:	rex (bad)
    7c479db04da2:	mov    al,0x9d
    7c479db04da4:	rex.RXB jl 0x7c479db04da7
    7c479db04da7:	add    BYTE PTR [rax+0x479db04d],dh
    7c479db04dad:	jl     0x7c479db04daf
    7c479db04daf:	add    BYTE PTR [rcx-0x45],cl
    7c479db04db2:	rex jns 0x7c479db04de7
    7c479db04db5:	xchg   esi,edi
    7c479db04db7:	(bad)
    7c479db04db8:	add    BYTE PTR [rax],al
    7c479db04dba:	jmp    r11
    7c479db04dbd:	movdqa xmm0,xmm2
    7c479db04dc1:	movdqa xmm1,xmm3
    7c479db04dc5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db04dce:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db04dd7:	call   0x7c479db05840
    7c479db04ddc:	jmp    0x7c479db0274c
    7c479db04de1:	movdqa xmm0,xmm2
    7c479db04de5:	movdqa xmm1,xmm3
    7c479db04de9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db04df2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db04dfb:	call   0x7c479db05840
    7c479db04e00:	jmp    0x7c479db027d8
    7c479db04e05:	movdqa xmm0,xmm9
    7c479db04e0a:	movdqa xmm1,xmm2
    7c479db04e0e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db04e17:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db04e20:	call   0x7c479db05910
    7c479db04e25:	jmp    0x7c479db02e73
    7c479db04e2a:	movdqa xmm0,xmm8
    7c479db04e2f:	movdqa xmm1,xmm2
    7c479db04e33:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db04e3c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db04e45:	call   0x7c479db05a20
    7c479db04e4a:	jmp    0x7c479db02ed2
    7c479db04e4f:	movdqa xmm0,xmm9
    7c479db04e54:	movdqa xmm1,xmm7
    7c479db04e58:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db04e61:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db04e6a:	call   0x7c479db05b40
    7c479db04e6f:	jmp    0x7c479db02f47
    7c479db04e74:	movdqa xmm0,xmm9
    7c479db04e79:	movdqa xmm1,xmm6
    7c479db04e7d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db04e86:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db04e8f:	call   0x7c479db05c60
    7c479db04e94:	jmp    0x7c479db02f97
    7c479db04e99:	movdqa xmm0,xmm9
    7c479db04e9e:	movdqa xmm1,xmm6
    7c479db04ea2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db04eab:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db04eb4:	call   0x7c479db05d80
    7c479db04eb9:	jmp    0x7c479db02ff0
    7c479db04ebe:	movdqa xmm0,xmm9
    7c479db04ec3:	movdqa xmm1,xmm2
    7c479db04ec7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db04ed0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db04ed9:	call   0x7c479db05eb0
    7c479db04ede:	jmp    0x7c479db03091
    7c479db04ee3:	mov    r11,rax
    7c479db04ee6:	lahf
    7c479db04ee7:	seto   al
    7c479db04eea:	mov    WORD PTR [rsp],ax
    7c479db04eee:	mov    rax,r11
    7c479db04ef1:	movdqa xmm0,xmm10
    7c479db04ef6:	movdqa xmm1,xmm9
    7c479db04efb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db04f04:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db04f0d:	call   0x7c479db05ff0
    7c479db04f12:	mov    r11,rax
    7c479db04f15:	movzx  eax,WORD PTR [rsp]
    7c479db04f19:	add    al,0x7f
    7c479db04f1b:	sahf
    7c479db04f1c:	mov    rax,r11
    7c479db04f1f:	jmp    0x7c479db030fc
    7c479db04f24:	mov    r11,rax
    7c479db04f27:	lahf
    7c479db04f28:	seto   al
    7c479db04f2b:	mov    WORD PTR [rsp],ax
    7c479db04f2f:	mov    rax,r11
    7c479db04f32:	movdqa xmm0,xmm8
    7c479db04f37:	movdqa xmm1,xmm10
    7c479db04f3c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db04f45:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db04f4e:	call   0x7c479db05ff0
    7c479db04f53:	mov    r11,rax
    7c479db04f56:	movzx  eax,WORD PTR [rsp]
    7c479db04f5a:	add    al,0x7f
    7c479db04f5c:	sahf
    7c479db04f5d:	mov    rax,r11
    7c479db04f60:	jmp    0x7c479db0315c
    7c479db04f65:	mov    r11,rax
    7c479db04f68:	lahf
    7c479db04f69:	seto   al
    7c479db04f6c:	mov    WORD PTR [rsp],ax
    7c479db04f70:	mov    rax,r11
    7c479db04f73:	movdqa xmm0,xmm7
    7c479db04f77:	movdqa xmm1,xmm10
    7c479db04f7c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db04f85:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db04f8e:	call   0x7c479db061c0
    7c479db04f93:	mov    r11,rax
    7c479db04f96:	movzx  eax,WORD PTR [rsp]
    7c479db04f9a:	add    al,0x7f
    7c479db04f9c:	sahf
    7c479db04f9d:	mov    rax,r11
    7c479db04fa0:	jmp    0x7c479db031b5
    7c479db04fa5:	movdqa xmm0,xmm12
    7c479db04faa:	movdqa xmm1,xmm9
    7c479db04faf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db04fb8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db04fc1:	call   0x7c479db06380
    7c479db04fc6:	jmp    0x7c479db0332d
    7c479db04fcb:	movdqa xmm0,xmm6
    7c479db04fcf:	movdqa xmm1,xmm4
    7c479db04fd3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db04fdc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db04fe5:	call   0x7c479db06580
    7c479db04fea:	jmp    0x7c479db0339b
    7c479db04fef:	movdqa xmm0,xmm8
    7c479db04ff4:	movdqa xmm1,xmm11
    7c479db04ff9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05002:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db0500b:	call   0x7c479db06770
    7c479db05010:	jmp    0x7c479db033f6
    7c479db05015:	movdqa xmm0,xmm5
    7c479db05019:	movdqa xmm1,xmm2
    7c479db0501d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05026:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db0502f:	call   0x7c479db06960
    7c479db05034:	jmp    0x7c479db03453
    7c479db05039:	movdqa xmm0,xmm9
    7c479db0503e:	movdqa xmm1,xmm5
    7c479db05042:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0504b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05054:	call   0x7c479db06b30
    7c479db05059:	jmp    0x7c479db034bb
    7c479db0505e:	movdqa xmm0,xmm13
    7c479db05063:	movdqa xmm1,xmm2
    7c479db05067:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05070:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05079:	call   0x7c479db06d10
    7c479db0507e:	jmp    0x7c479db03534
    7c479db05083:	movdqa xmm0,xmm9
    7c479db05088:	movdqa xmm1,xmm5
    7c479db0508c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05095:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db0509e:	call   0x7c479db06f00
    7c479db050a3:	jmp    0x7c479db035c1
    7c479db050a8:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7c479db050b2:	movdqa xmm1,xmm6
    7c479db050b6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db050bf:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db050c8:	call   0x7c479db070c0
    7c479db050cd:	jmp    0x7c479db036b6
    7c479db050d2:	movdqa xmm0,xmm9
    7c479db050d7:	movdqa xmm1,xmm5
    7c479db050db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db050e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db050ed:	call   0x7c479db072a0
    7c479db050f2:	jmp    0x7c479db03714
    7c479db050f7:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7c479db05101:	movdqa xmm1,xmm11
    7c479db05106:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0510f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05118:	call   0x7c479db07480
    7c479db0511d:	jmp    0x7c479db0378d
    7c479db05122:	movdqa xmm0,xmm12
    7c479db05127:	movdqa xmm1,xmm8
    7c479db0512c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05135:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db0513e:	call   0x7c479db07670
    7c479db05143:	jmp    0x7c479db037e8
    7c479db05148:	movdqa xmm0,xmm9
    7c479db0514d:	movdqa xmm1,xmm5
    7c479db05151:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0515a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05163:	call   0x7c479db07860
    7c479db05168:	jmp    0x7c479db03869
    7c479db0516d:	movdqa xmm0,xmm4
    7c479db05171:	movdqa xmm1,xmm2
    7c479db05175:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0517e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05187:	call   0x7c479db07a40
    7c479db0518c:	jmp    0x7c479db038dc
    7c479db05191:	movdqa xmm0,xmm13
    7c479db05196:	movdqa xmm1,xmm2
    7c479db0519a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db051a3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db051ac:	call   0x7c479db07c20
    7c479db051b1:	jmp    0x7c479db03945
    7c479db051b6:	movdqa xmm0,xmm5
    7c479db051ba:	movdqa xmm1,xmm2
    7c479db051be:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db051c7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db051d0:	call   0x7c479db07e00
    7c479db051d5:	jmp    0x7c479db039bd
    7c479db051da:	movdqa xmm0,xmm3
    7c479db051de:	movdqa xmm1,xmm6
    7c479db051e2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db051eb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db051f4:	call   0x7c479db07fe0
    7c479db051f9:	jmp    0x7c479db03a30
    7c479db051fe:	movdqa xmm0,xmm5
    7c479db05202:	movdqa xmm1,xmm2
    7c479db05206:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0520f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05218:	call   0x7c479db081d0
    7c479db0521d:	jmp    0x7c479db03ad2
    7c479db05222:	movdqa xmm0,xmm10
    7c479db05227:	movdqa xmm1,xmm12
    7c479db0522c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05235:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db0523e:	call   0x7c479db083c0
    7c479db05243:	jmp    0x7c479db03b43
    7c479db05248:	movdqa xmm0,xmm7
    7c479db0524c:	movdqa xmm1,xmm2
    7c479db05250:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05259:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05262:	call   0x7c479db085c0
    7c479db05267:	jmp    0x7c479db03b96
    7c479db0526c:	movdqa xmm0,xmm11
    7c479db05271:	movdqa xmm1,xmm13
    7c479db05276:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0527f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05288:	call   0x7c479db087a0
    7c479db0528d:	jmp    0x7c479db03be7
    7c479db05292:	movdqa xmm0,xmm5
    7c479db05296:	movdqa xmm1,xmm7
    7c479db0529a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db052a3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db052ac:	call   0x7c479db08980
    7c479db052b1:	jmp    0x7c479db03c44
    7c479db052b6:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    7c479db052c0:	movdqa xmm1,xmm7
    7c479db052c4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db052cd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db052d6:	call   0x7c479db08b50
    7c479db052db:	jmp    0x7c479db03c9e
    7c479db052e0:	movdqa xmm0,xmm8
    7c479db052e5:	movdqa xmm1,xmm4
    7c479db052e9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db052f2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db052fb:	call   0x7c479db08d20
    7c479db05300:	jmp    0x7c479db03ced
    7c479db05305:	movdqa xmm0,xmm9
    7c479db0530a:	movdqa xmm1,xmm6
    7c479db0530e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05317:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05320:	call   0x7c479db08f00
    7c479db05325:	jmp    0x7c479db03d47
    7c479db0532a:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    7c479db05334:	movdqa xmm1,xmm7
    7c479db05338:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05341:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db0534a:	call   0x7c479db090d0
    7c479db0534f:	jmp    0x7c479db03daa
    7c479db05354:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7c479db0535e:	movdqa xmm1,xmm7
    7c479db05362:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0536b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05374:	call   0x7c479db09290
    7c479db05379:	jmp    0x7c479db03e03
    7c479db0537e:	movdqa xmm0,xmm3
    7c479db05382:	movdqa xmm1,xmm10
    7c479db05387:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05390:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05399:	call   0x7c479db09460
    7c479db0539e:	jmp    0x7c479db03e5d
    7c479db053a3:	movdqa xmm0,xmm2
    7c479db053a7:	movdqa xmm1,xmm11
    7c479db053ac:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db053b5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db053be:	call   0x7c479db09630
    7c479db053c3:	jmp    0x7c479db03eb6
    7c479db053c8:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    7c479db053d2:	movdqa xmm1,xmm2
    7c479db053d6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db053df:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db053e8:	call   0x7c479db097f0
    7c479db053ed:	jmp    0x7c479db03f23
    7c479db053f2:	movdqa xmm0,xmm4
    7c479db053f6:	movdqa xmm1,xmm5
    7c479db053fa:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05403:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db0540c:	call   0x7c479db099a0
    7c479db05411:	jmp    0x7c479db03f7c
    7c479db05416:	movdqa xmm0,xmm12
    7c479db0541b:	movdqa xmm1,xmm6
    7c479db0541f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05428:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05431:	call   0x7c479db09b70
    7c479db05436:	jmp    0x7c479db03fd6
    7c479db0543b:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    7c479db05445:	movdqa xmm1,xmm2
    7c479db05449:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05452:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db0545b:	call   0x7c479db08980
    7c479db05460:	jmp    0x7c479db040b6
    7c479db05465:	movdqa xmm0,xmm7
    7c479db05469:	movdqa xmm1,xmm8
    7c479db0546e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05477:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05480:	call   0x7c479db08d20
    7c479db05485:	jmp    0x7c479db04106
    7c479db0548a:	movdqa xmm0,xmm3
    7c479db0548e:	movdqa xmm1,xmm9
    7c479db05493:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0549c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db054a5:	call   0x7c479db09d30
    7c479db054aa:	jmp    0x7c479db04156
    7c479db054af:	movdqa xmm0,xmm6
    7c479db054b3:	movdqa xmm1,xmm2
    7c479db054b7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db054c0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db054c9:	call   0x7c479db09f00
    7c479db054ce:	jmp    0x7c479db041b3
    7c479db054d3:	movdqa xmm0,xmm6
    7c479db054d7:	movdqa xmm1,xmm2
    7c479db054db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db054e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db054ed:	call   0x7c479db09290
    7c479db054f2:	jmp    0x7c479db0421a
    7c479db054f7:	movdqa xmm0,xmm5
    7c479db054fb:	movdqa xmm1,xmm2
    7c479db054ff:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05508:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05511:	call   0x7c479db0a0c0
    7c479db05516:	jmp    0x7c479db04278
    7c479db0551b:	movdqa xmm0,xmm10
    7c479db05520:	movdqa xmm1,xmm11
    7c479db05525:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0552e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05537:	call   0x7c479db0a290
    7c479db0553c:	jmp    0x7c479db042d2
    7c479db05541:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7c479db0554b:	movdqa xmm1,xmm2
    7c479db0554f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05558:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05561:	call   0x7c479db097f0
    7c479db05566:	jmp    0x7c479db04335
    7c479db0556b:	movdqa xmm0,xmm4
    7c479db0556f:	movdqa xmm1,xmm3
    7c479db05573:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0557c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05585:	call   0x7c479db099a0
    7c479db0558a:	jmp    0x7c479db0438e
    7c479db0558f:	movdqa xmm0,xmm3
    7c479db05593:	movdqa xmm1,xmm2
    7c479db05597:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db055a0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db055a9:	call   0x7c479db0a460
    7c479db055ae:	jmp    0x7c479db043f6
    7c479db055b3:	movdqa xmm0,xmm12
    7c479db055b8:	movdqa xmm1,xmm8
    7c479db055bd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db055c6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db055cf:	call   0x7c479db0a630
    7c479db055d4:	jmp    0x7c479db04450
    7c479db055d9:	movdqa xmm0,xmm8
    7c479db055de:	movdqa xmm1,xmm2
    7c479db055e2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db055eb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db055f4:	call   0x7c479db08980
    7c479db055f9:	jmp    0x7c479db044b8
    7c479db055fe:	movdqa xmm0,xmm7
    7c479db05602:	movdqa xmm1,xmm6
    7c479db05606:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0560f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05618:	call   0x7c479db0a800
    7c479db0561d:	jmp    0x7c479db04511
    7c479db05622:	movdqa xmm0,xmm5
    7c479db05626:	movdqa xmm1,xmm9
    7c479db0562b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05634:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db0563d:	call   0x7c479db0a9c0
    7c479db05642:	jmp    0x7c479db04581
    7c479db05647:	movdqa xmm0,xmm6
    7c479db0564b:	movdqa xmm1,xmm5
    7c479db0564f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05658:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05661:	call   0x7c479db0ab80
    7c479db05666:	jmp    0x7c479db045e8
    7c479db0566b:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7c479db05675:	movdqa xmm1,xmm5
    7c479db05679:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05682:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db0568b:	call   0x7c479db0ad30
    7c479db05690:	jmp    0x7c479db0464c
    7c479db05695:	movdqa xmm0,xmm10
    7c479db0569a:	movdqa xmm1,xmm4
    7c479db0569e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db056a7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db056b0:	call   0x7c479db0aef0
    7c479db056b5:	jmp    0x7c479db046a5
    7c479db056ba:	movdqa xmm0,xmm3
    7c479db056be:	movdqa xmm1,xmm11
    7c479db056c3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db056cc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db056d5:	call   0x7c479db08d20
    7c479db056da:	jmp    0x7c479db0471b
    7c479db056df:	movdqa xmm0,xmm10
    7c479db056e4:	movdqa xmm1,xmm5
    7c479db056e8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db056f1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db056fa:	call   0x7c479db0b0c0
    7c479db056ff:	jmp    0x7c479db0477a
    7c479db05704:	movdqa xmm0,xmm4
    7c479db05708:	movdqa xmm1,xmm5
    7c479db0570c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05715:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db0571e:	call   0x7c479db0b290
    7c479db05723:	jmp    0x7c479db047d7
    7c479db05728:	movdqa xmm0,xmm2
    7c479db0572c:	movdqa xmm1,xmm8
    7c479db05731:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0573a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05743:	call   0x7c479db09b70
    7c479db05748:	jmp    0x7c479db04827
    7c479db0574d:	movdqa xmm0,xmm7
    7c479db05751:	movdqa xmm1,xmm6
    7c479db05755:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0575e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05767:	call   0x7c479db0b460
    7c479db0576c:	jmp    0x7c479db0487f
    7c479db05771:	movdqa xmm0,xmm9
    7c479db05776:	movdqa xmm1,xmm3
    7c479db0577a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db05783:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db0578c:	call   0x7c479db0b610
    7c479db05791:	jmp    0x7c479db048d8
    7c479db05796:	movdqa xmm0,xmm12
    7c479db0579b:	movdqa xmm1,xmm10
    7c479db057a0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db057a9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db057b2:	call   0x7c479db0b7b0
    7c479db057b7:	jmp    0x7c479db04932
    7c479db057bc:	mov    r11,rax
    7c479db057bf:	lahf
    7c479db057c0:	seto   al
    7c479db057c3:	mov    WORD PTR [rsp],ax
    7c479db057c7:	mov    rax,r11
    7c479db057ca:	movdqa xmm0,xmm2
    7c479db057ce:	movdqa xmm1,xmm3
    7c479db057d2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db057db:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db057e4:	call   0x7c479db0b940
    7c479db057e9:	mov    r11,rax
    7c479db057ec:	movzx  eax,WORD PTR [rsp]
    7c479db057f0:	add    al,0x7f
    7c479db057f2:	sahf
    7c479db057f3:	mov    rax,r11
    7c479db057f6:	jmp    0x7c479db04abd
    7c479db057fb:	mov    r11,rax
    7c479db057fe:	lahf
    7c479db057ff:	seto   al
    7c479db05802:	mov    WORD PTR [rsp],ax
    7c479db05806:	mov    rax,r11
    7c479db05809:	movdqa xmm0,xmm4
    7c479db0580d:	movdqa xmm1,xmm2
    7c479db05811:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7c479db0581a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7c479db05823:	call   0x7c479db0baa0
    7c479db05828:	mov    r11,rax
    7c479db0582b:	movzx  eax,WORD PTR [rsp]
    7c479db0582f:	add    al,0x7f
    7c479db05831:	sahf
    7c479db05832:	mov    rax,r11
    7c479db05835:	jmp    0x7c479db04b1d
    7c479db0583a:	nop    WORD PTR [rax+rax*1+0x0]
    7c479db05840:	sub    rsp,0x8
    7c479db05844:	mov    QWORD PTR [r12+0x378],0x3
    7c479db05850:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db05856:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0585c:	mov    QWORD PTR [r12+0x108],rbx
    7c479db05864:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0586a:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0586f:	test   r10d,0x3f
    7c479db05876:	je     0x7c479db0589b
    7c479db0587c:	mov    r11d,r10d
    7c479db0587f:	shr    r10d,1
    7c479db05882:	and    r10d,0x1e
    7c479db05886:	and    r11d,0x1
    7c479db0588a:	or     r10d,r11d
    7c479db0588d:	or     DWORD PTR [r12+0x314],r10d
    7c479db05895:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0589b:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db058a1:	lea    rdi,[rsp+0x110]
    7c479db058a9:	lea    rsi,[rsp+0xf0]
    7c479db058b1:	lea    rdx,[rsp+0x100]
    7c479db058b9:	mov    ecx,0x16
    7c479db058be:	mov    r8d,0x0
    7c479db058c4:	lea    r9,[r12+0x314]
    7c479db058cc:	movabs r11,0x62fe8718e650
    7c479db058d6:	call   r11
    7c479db058d9:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db058df:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db058e5:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db058eb:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db058f3:	mov    QWORD PTR [r12+0x378],0x2
    7c479db058ff:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db05908:	add    rsp,0x8
    7c479db0590c:	ret
    7c479db0590d:	nop    DWORD PTR [rax]
    7c479db05910:	sub    rsp,0x8
    7c479db05914:	mov    QWORD PTR [r12+0x378],0x3
    7c479db05920:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db05926:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0592c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db05932:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db0593c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db05946:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0594e:	stmxcsr DWORD PTR [r12-0x28]
    7c479db05954:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db05959:	test   r10d,0x3f
    7c479db05960:	je     0x7c479db05985
    7c479db05966:	mov    r11d,r10d
    7c479db05969:	shr    r10d,1
    7c479db0596c:	and    r10d,0x1e
    7c479db05970:	and    r11d,0x1
    7c479db05974:	or     r10d,r11d
    7c479db05977:	or     DWORD PTR [r12+0x314],r10d
    7c479db0597f:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db05985:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0598b:	lea    rdi,[rsp+0x110]
    7c479db05993:	lea    rsi,[rsp+0xf0]
    7c479db0599b:	lea    rdx,[rsp+0x100]
    7c479db059a3:	mov    ecx,0x16
    7c479db059a8:	mov    r8d,0x0
    7c479db059ae:	lea    r9,[r12+0x314]
    7c479db059b6:	movabs r11,0x62fe8718e650
    7c479db059c0:	call   r11
    7c479db059c3:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db059c9:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db059cf:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db059d5:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db059db:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db059e5:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db059ef:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db059f7:	mov    QWORD PTR [r12+0x378],0x2
    7c479db05a03:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db05a0c:	add    rsp,0x8
    7c479db05a10:	ret
    7c479db05a11:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db05a20:	sub    rsp,0x8
    7c479db05a24:	mov    QWORD PTR [r12+0x378],0x3
    7c479db05a30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db05a36:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db05a3c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db05a42:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db05a4c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db05a56:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db05a60:	mov    QWORD PTR [r12+0x108],rbx
    7c479db05a68:	stmxcsr DWORD PTR [r12-0x28]
    7c479db05a6e:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db05a73:	test   r10d,0x3f
    7c479db05a7a:	je     0x7c479db05a9f
    7c479db05a80:	mov    r11d,r10d
    7c479db05a83:	shr    r10d,1
    7c479db05a86:	and    r10d,0x1e
    7c479db05a8a:	and    r11d,0x1
    7c479db05a8e:	or     r10d,r11d
    7c479db05a91:	or     DWORD PTR [r12+0x314],r10d
    7c479db05a99:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db05a9f:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db05aa5:	lea    rdi,[rsp+0x110]
    7c479db05aad:	lea    rsi,[rsp+0xf0]
    7c479db05ab5:	lea    rdx,[rsp+0x100]
    7c479db05abd:	mov    ecx,0x56
    7c479db05ac2:	mov    r8d,0x0
    7c479db05ac8:	lea    r9,[r12+0x314]
    7c479db05ad0:	movabs r11,0x62fe8718e650
    7c479db05ada:	call   r11
    7c479db05add:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db05ae3:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db05ae9:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db05aef:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db05af5:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db05aff:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db05b09:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db05b13:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db05b1b:	mov    QWORD PTR [r12+0x378],0x2
    7c479db05b27:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db05b30:	add    rsp,0x8
    7c479db05b34:	ret
    7c479db05b35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db05b40:	sub    rsp,0x8
    7c479db05b44:	mov    QWORD PTR [r12+0x378],0x3
    7c479db05b50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db05b56:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db05b5c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db05b62:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db05b6c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db05b76:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db05b80:	mov    QWORD PTR [r12+0x108],rbx
    7c479db05b88:	stmxcsr DWORD PTR [r12-0x28]
    7c479db05b8e:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db05b93:	test   r10d,0x3f
    7c479db05b9a:	je     0x7c479db05bbf
    7c479db05ba0:	mov    r11d,r10d
    7c479db05ba3:	shr    r10d,1
    7c479db05ba6:	and    r10d,0x1e
    7c479db05baa:	and    r11d,0x1
    7c479db05bae:	or     r10d,r11d
    7c479db05bb1:	or     DWORD PTR [r12+0x314],r10d
    7c479db05bb9:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db05bbf:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db05bc5:	lea    rdi,[rsp+0x110]
    7c479db05bcd:	lea    rsi,[rsp+0xf0]
    7c479db05bd5:	lea    rdx,[rsp+0x100]
    7c479db05bdd:	mov    ecx,0x16
    7c479db05be2:	mov    r8d,0x0
    7c479db05be8:	lea    r9,[r12+0x314]
    7c479db05bf0:	movabs r11,0x62fe8718e650
    7c479db05bfa:	call   r11
    7c479db05bfd:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db05c03:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db05c09:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db05c0f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db05c15:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db05c1f:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db05c29:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db05c33:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db05c3b:	mov    QWORD PTR [r12+0x378],0x2
    7c479db05c47:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db05c50:	add    rsp,0x8
    7c479db05c54:	ret
    7c479db05c55:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db05c60:	sub    rsp,0x8
    7c479db05c64:	mov    QWORD PTR [r12+0x378],0x3
    7c479db05c70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db05c76:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db05c7c:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db05c86:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db05c90:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db05c9a:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db05ca4:	mov    QWORD PTR [r12+0x108],rbx
    7c479db05cac:	stmxcsr DWORD PTR [r12-0x28]
    7c479db05cb2:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db05cb7:	test   r10d,0x3f
    7c479db05cbe:	je     0x7c479db05ce3
    7c479db05cc4:	mov    r11d,r10d
    7c479db05cc7:	shr    r10d,1
    7c479db05cca:	and    r10d,0x1e
    7c479db05cce:	and    r11d,0x1
    7c479db05cd2:	or     r10d,r11d
    7c479db05cd5:	or     DWORD PTR [r12+0x314],r10d
    7c479db05cdd:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db05ce3:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db05ce9:	lea    rdi,[rsp+0x110]
    7c479db05cf1:	lea    rsi,[rsp+0xf0]
    7c479db05cf9:	lea    rdx,[rsp+0x100]
    7c479db05d01:	mov    ecx,0x16
    7c479db05d06:	mov    r8d,0x0
    7c479db05d0c:	lea    r9,[r12+0x314]
    7c479db05d14:	movabs r11,0x62fe8718e650
    7c479db05d1e:	call   r11
    7c479db05d21:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db05d27:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db05d2d:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db05d33:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db05d3d:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db05d47:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db05d51:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db05d5b:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db05d63:	mov    QWORD PTR [r12+0x378],0x2
    7c479db05d6f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db05d78:	add    rsp,0x8
    7c479db05d7c:	ret
    7c479db05d7d:	nop    DWORD PTR [rax]
    7c479db05d80:	sub    rsp,0x8
    7c479db05d84:	mov    QWORD PTR [r12+0x378],0x3
    7c479db05d90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db05d96:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db05d9c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db05da2:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db05dac:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db05db6:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db05dc0:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db05dca:	mov    QWORD PTR [r12+0x108],rbx
    7c479db05dd2:	stmxcsr DWORD PTR [r12-0x28]
    7c479db05dd8:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db05ddd:	test   r10d,0x3f
    7c479db05de4:	je     0x7c479db05e09
    7c479db05dea:	mov    r11d,r10d
    7c479db05ded:	shr    r10d,1
    7c479db05df0:	and    r10d,0x1e
    7c479db05df4:	and    r11d,0x1
    7c479db05df8:	or     r10d,r11d
    7c479db05dfb:	or     DWORD PTR [r12+0x314],r10d
    7c479db05e03:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db05e09:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db05e0f:	lea    rdi,[rsp+0x110]
    7c479db05e17:	lea    rsi,[rsp+0xf0]
    7c479db05e1f:	lea    rdx,[rsp+0x100]
    7c479db05e27:	mov    ecx,0x16
    7c479db05e2c:	mov    r8d,0x0
    7c479db05e32:	lea    r9,[r12+0x314]
    7c479db05e3a:	movabs r11,0x62fe8718e650
    7c479db05e44:	call   r11
    7c479db05e47:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db05e4d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db05e53:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db05e59:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db05e5f:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db05e69:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db05e73:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db05e7d:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db05e87:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db05e8f:	mov    QWORD PTR [r12+0x378],0x2
    7c479db05e9b:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db05ea4:	add    rsp,0x8
    7c479db05ea8:	ret
    7c479db05ea9:	nop    DWORD PTR [rax+0x0]
    7c479db05eb0:	sub    rsp,0x8
    7c479db05eb4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db05ec0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db05ec6:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db05ecc:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db05ed6:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db05ee0:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db05eea:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db05ef4:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db05efe:	mov    QWORD PTR [r12+0x108],rbx
    7c479db05f06:	stmxcsr DWORD PTR [r12-0x28]
    7c479db05f0c:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db05f11:	test   r10d,0x3f
    7c479db05f18:	je     0x7c479db05f3d
    7c479db05f1e:	mov    r11d,r10d
    7c479db05f21:	shr    r10d,1
    7c479db05f24:	and    r10d,0x1e
    7c479db05f28:	and    r11d,0x1
    7c479db05f2c:	or     r10d,r11d
    7c479db05f2f:	or     DWORD PTR [r12+0x314],r10d
    7c479db05f37:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db05f3d:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db05f43:	lea    rdi,[rsp+0x110]
    7c479db05f4b:	lea    rsi,[rsp+0xf0]
    7c479db05f53:	lea    rdx,[rsp+0x100]
    7c479db05f5b:	mov    ecx,0x56
    7c479db05f60:	mov    r8d,0x0
    7c479db05f66:	lea    r9,[r12+0x314]
    7c479db05f6e:	movabs r11,0x62fe8718e650
    7c479db05f78:	call   r11
    7c479db05f7b:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db05f81:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db05f87:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db05f8d:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db05f97:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db05fa1:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db05fab:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db05fb5:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db05fbf:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db05fc7:	mov    QWORD PTR [r12+0x378],0x2
    7c479db05fd3:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db05fdc:	add    rsp,0x8
    7c479db05fe0:	ret
    7c479db05fe1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db05ff0:	sub    rsp,0x8
    7c479db05ff4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db06000:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db06006:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0600c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db06012:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db0601c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db06026:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db06030:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db0603a:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db06044:	push   rdx
    7c479db06045:	push   rsi
    7c479db06046:	push   r10
    7c479db06048:	push   r11
    7c479db0604a:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0604f:	mov    r10d,edx
    7c479db06052:	and    r10d,0xc000
    7c479db06059:	shl    r10d,0x10
    7c479db0605d:	mov    r11d,edx
    7c479db06060:	and    r11d,0x100
    7c479db06067:	shl    r11d,0x15
    7c479db0606b:	or     r10d,r11d
    7c479db0606e:	and    edx,0x1
    7c479db06071:	shl    edx,0x1c
    7c479db06074:	or     r10d,edx
    7c479db06077:	btc    r10,0x1d
    7c479db0607c:	mov    r11d,0xf0000000
    7c479db06082:	and    r11,r10
    7c479db06085:	movabs rsi,0xffffffff0fffffff
    7c479db0608f:	and    rbx,rsi
    7c479db06092:	or     rbx,r11
    7c479db06095:	pop    r11
    7c479db06097:	pop    r10
    7c479db06099:	pop    rsi
    7c479db0609a:	pop    rdx
    7c479db0609b:	mov    QWORD PTR [r12+0x108],rbx
    7c479db060a3:	stmxcsr DWORD PTR [r12-0x28]
    7c479db060a9:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db060ae:	test   r10d,0x3f
    7c479db060b5:	je     0x7c479db060da
    7c479db060bb:	mov    r11d,r10d
    7c479db060be:	shr    r10d,1
    7c479db060c1:	and    r10d,0x1e
    7c479db060c5:	and    r11d,0x1
    7c479db060c9:	or     r10d,r11d
    7c479db060cc:	or     DWORD PTR [r12+0x314],r10d
    7c479db060d4:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db060da:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db060e0:	lea    rdi,[rsp+0x110]
    7c479db060e8:	lea    rsi,[rsp+0xf0]
    7c479db060f0:	lea    rdx,[rsp+0x100]
    7c479db060f8:	mov    ecx,0x14
    7c479db060fd:	mov    r8d,0x0
    7c479db06103:	lea    r9,[r12+0x314]
    7c479db0610b:	movabs r11,0x62fe8718e650
    7c479db06115:	call   r11
    7c479db06118:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0611e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db06124:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0612a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db06130:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db0613a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db06144:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0614e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db06158:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db06162:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0616a:	mov    QWORD PTR [r12+0x378],0x2
    7c479db06176:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0617f:	mov    rdx,rbx
    7c479db06182:	shr    rdx,0x10
    7c479db06186:	and    edx,0xc000
    7c479db0618c:	mov    rax,rbx
    7c479db0618f:	shr    rax,0x15
    7c479db06193:	and    eax,0x100
    7c479db06198:	xor    eax,0x100
    7c479db0619d:	or     edx,eax
    7c479db0619f:	mov    rax,rbx
    7c479db061a2:	shr    rax,0x1c
    7c479db061a6:	and    eax,0x1
    7c479db061a9:	or     edx,eax
    7c479db061ab:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db061b0:	add    rsp,0x8
    7c479db061b4:	ret
    7c479db061b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db061c0:	sub    rsp,0x8
    7c479db061c4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db061d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db061d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db061dc:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db061e2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db061e8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db061f2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db061fc:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db06206:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db06210:	push   rdx
    7c479db06211:	push   rsi
    7c479db06212:	push   r10
    7c479db06214:	push   r11
    7c479db06216:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0621b:	mov    r10d,edx
    7c479db0621e:	and    r10d,0xc000
    7c479db06225:	shl    r10d,0x10
    7c479db06229:	mov    r11d,edx
    7c479db0622c:	and    r11d,0x100
    7c479db06233:	shl    r11d,0x15
    7c479db06237:	or     r10d,r11d
    7c479db0623a:	and    edx,0x1
    7c479db0623d:	shl    edx,0x1c
    7c479db06240:	or     r10d,edx
    7c479db06243:	btc    r10,0x1d
    7c479db06248:	mov    r11d,0xf0000000
    7c479db0624e:	and    r11,r10
    7c479db06251:	movabs rsi,0xffffffff0fffffff
    7c479db0625b:	and    rbx,rsi
    7c479db0625e:	or     rbx,r11
    7c479db06261:	pop    r11
    7c479db06263:	pop    r10
    7c479db06265:	pop    rsi
    7c479db06266:	pop    rdx
    7c479db06267:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0626f:	stmxcsr DWORD PTR [r12-0x28]
    7c479db06275:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0627a:	test   r10d,0x3f
    7c479db06281:	je     0x7c479db062a6
    7c479db06287:	mov    r11d,r10d
    7c479db0628a:	shr    r10d,1
    7c479db0628d:	and    r10d,0x1e
    7c479db06291:	and    r11d,0x1
    7c479db06295:	or     r10d,r11d
    7c479db06298:	or     DWORD PTR [r12+0x314],r10d
    7c479db062a0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db062a6:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db062ac:	lea    rdi,[rsp+0x110]
    7c479db062b4:	lea    rsi,[rsp+0xf0]
    7c479db062bc:	lea    rdx,[rsp+0x100]
    7c479db062c4:	mov    ecx,0x14
    7c479db062c9:	mov    r8d,0x0
    7c479db062cf:	lea    r9,[r12+0x314]
    7c479db062d7:	movabs r11,0x62fe8718e650
    7c479db062e1:	call   r11
    7c479db062e4:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db062ea:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db062f0:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db062f6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db062fc:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db06302:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0630c:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db06316:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db06320:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0632a:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db06332:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0633e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db06347:	mov    rdx,rbx
    7c479db0634a:	shr    rdx,0x10
    7c479db0634e:	and    edx,0xc000
    7c479db06354:	mov    rax,rbx
    7c479db06357:	shr    rax,0x15
    7c479db0635b:	and    eax,0x100
    7c479db06360:	xor    eax,0x100
    7c479db06365:	or     edx,eax
    7c479db06367:	mov    rax,rbx
    7c479db0636a:	shr    rax,0x1c
    7c479db0636e:	and    eax,0x1
    7c479db06371:	or     edx,eax
    7c479db06373:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db06378:	add    rsp,0x8
    7c479db0637c:	ret
    7c479db0637d:	nop    DWORD PTR [rax]
    7c479db06380:	sub    rsp,0x8
    7c479db06384:	mov    QWORD PTR [r12+0x378],0x3
    7c479db06390:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db06396:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0639c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db063a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db063a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db063ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db063b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db063be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db063c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db063d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db063dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db063e6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db063f0:	push   rdx
    7c479db063f1:	push   rsi
    7c479db063f2:	push   r10
    7c479db063f4:	push   r11
    7c479db063f6:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db063fb:	mov    r10d,edx
    7c479db063fe:	and    r10d,0xc000
    7c479db06405:	shl    r10d,0x10
    7c479db06409:	mov    r11d,edx
    7c479db0640c:	and    r11d,0x100
    7c479db06413:	shl    r11d,0x15
    7c479db06417:	or     r10d,r11d
    7c479db0641a:	and    edx,0x1
    7c479db0641d:	shl    edx,0x1c
    7c479db06420:	or     r10d,edx
    7c479db06423:	btc    r10,0x1d
    7c479db06428:	mov    r11d,0xf0000000
    7c479db0642e:	and    r11,r10
    7c479db06431:	movabs rsi,0xffffffff0fffffff
    7c479db0643b:	and    rbx,rsi
    7c479db0643e:	or     rbx,r11
    7c479db06441:	pop    r11
    7c479db06443:	pop    r10
    7c479db06445:	pop    rsi
    7c479db06446:	pop    rdx
    7c479db06447:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0644f:	stmxcsr DWORD PTR [r12-0x28]
    7c479db06455:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0645a:	test   r10d,0x3f
    7c479db06461:	je     0x7c479db06486
    7c479db06467:	mov    r11d,r10d
    7c479db0646a:	shr    r10d,1
    7c479db0646d:	and    r10d,0x1e
    7c479db06471:	and    r11d,0x1
    7c479db06475:	or     r10d,r11d
    7c479db06478:	or     DWORD PTR [r12+0x314],r10d
    7c479db06480:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db06486:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0648c:	lea    rdi,[rsp+0x110]
    7c479db06494:	lea    rsi,[rsp+0xf0]
    7c479db0649c:	lea    rdx,[rsp+0x100]
    7c479db064a4:	mov    ecx,0x14
    7c479db064a9:	mov    r8d,0x0
    7c479db064af:	lea    r9,[r12+0x314]
    7c479db064b7:	movabs r11,0x62fe8718e650
    7c479db064c1:	call   r11
    7c479db064c4:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db064ca:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db064d0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db064d6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db064dc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db064e2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db064e8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db064ee:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db064f8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db06502:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0650c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db06516:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db06520:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db0652a:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db06532:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0653e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db06547:	mov    rdx,rbx
    7c479db0654a:	shr    rdx,0x10
    7c479db0654e:	and    edx,0xc000
    7c479db06554:	mov    rax,rbx
    7c479db06557:	shr    rax,0x15
    7c479db0655b:	and    eax,0x100
    7c479db06560:	xor    eax,0x100
    7c479db06565:	or     edx,eax
    7c479db06567:	mov    rax,rbx
    7c479db0656a:	shr    rax,0x1c
    7c479db0656e:	and    eax,0x1
    7c479db06571:	or     edx,eax
    7c479db06573:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db06578:	add    rsp,0x8
    7c479db0657c:	ret
    7c479db0657d:	nop    DWORD PTR [rax]
    7c479db06580:	sub    rsp,0x8
    7c479db06584:	mov    QWORD PTR [r12+0x378],0x3
    7c479db06590:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db06596:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0659c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db065a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db065a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db065ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db065b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db065be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db065c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db065d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db065dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db065e6:	push   rdx
    7c479db065e7:	push   rsi
    7c479db065e8:	push   r10
    7c479db065ea:	push   r11
    7c479db065ec:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db065f1:	mov    r10d,edx
    7c479db065f4:	and    r10d,0xc000
    7c479db065fb:	shl    r10d,0x10
    7c479db065ff:	mov    r11d,edx
    7c479db06602:	and    r11d,0x100
    7c479db06609:	shl    r11d,0x15
    7c479db0660d:	or     r10d,r11d
    7c479db06610:	and    edx,0x1
    7c479db06613:	shl    edx,0x1c
    7c479db06616:	or     r10d,edx
    7c479db06619:	btc    r10,0x1d
    7c479db0661e:	mov    r11d,0xf0000000
    7c479db06624:	and    r11,r10
    7c479db06627:	movabs rsi,0xffffffff0fffffff
    7c479db06631:	and    rbx,rsi
    7c479db06634:	or     rbx,r11
    7c479db06637:	pop    r11
    7c479db06639:	pop    r10
    7c479db0663b:	pop    rsi
    7c479db0663c:	pop    rdx
    7c479db0663d:	mov    QWORD PTR [r12+0x108],rbx
    7c479db06645:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0664b:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db06650:	test   r10d,0x3f
    7c479db06657:	je     0x7c479db0667c
    7c479db0665d:	mov    r11d,r10d
    7c479db06660:	shr    r10d,1
    7c479db06663:	and    r10d,0x1e
    7c479db06667:	and    r11d,0x1
    7c479db0666b:	or     r10d,r11d
    7c479db0666e:	or     DWORD PTR [r12+0x314],r10d
    7c479db06676:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0667c:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db06682:	lea    rdi,[rsp+0x110]
    7c479db0668a:	lea    rsi,[rsp+0xf0]
    7c479db06692:	lea    rdx,[rsp+0x100]
    7c479db0669a:	mov    ecx,0x14
    7c479db0669f:	mov    r8d,0x0
    7c479db066a5:	lea    r9,[r12+0x314]
    7c479db066ad:	movabs r11,0x62fe8718e650
    7c479db066b7:	call   r11
    7c479db066ba:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db066c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db066c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db066cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db066d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db066d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db066de:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db066e4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db066ee:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db066f8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db06702:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db0670c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db06716:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0671e:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0672a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db06733:	mov    rdx,rbx
    7c479db06736:	shr    rdx,0x10
    7c479db0673a:	and    edx,0xc000
    7c479db06740:	mov    rax,rbx
    7c479db06743:	shr    rax,0x15
    7c479db06747:	and    eax,0x100
    7c479db0674c:	xor    eax,0x100
    7c479db06751:	or     edx,eax
    7c479db06753:	mov    rax,rbx
    7c479db06756:	shr    rax,0x1c
    7c479db0675a:	and    eax,0x1
    7c479db0675d:	or     edx,eax
    7c479db0675f:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db06764:	add    rsp,0x8
    7c479db06768:	ret
    7c479db06769:	nop    DWORD PTR [rax+0x0]
    7c479db06770:	sub    rsp,0x8
    7c479db06774:	mov    QWORD PTR [r12+0x378],0x3
    7c479db06780:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db06786:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0678c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db06792:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db06798:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db067a2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db067ac:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db067b6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db067c0:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db067ca:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db067d4:	push   rdx
    7c479db067d5:	push   rsi
    7c479db067d6:	push   r10
    7c479db067d8:	push   r11
    7c479db067da:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db067df:	mov    r10d,edx
    7c479db067e2:	and    r10d,0xc000
    7c479db067e9:	shl    r10d,0x10
    7c479db067ed:	mov    r11d,edx
    7c479db067f0:	and    r11d,0x100
    7c479db067f7:	shl    r11d,0x15
    7c479db067fb:	or     r10d,r11d
    7c479db067fe:	and    edx,0x1
    7c479db06801:	shl    edx,0x1c
    7c479db06804:	or     r10d,edx
    7c479db06807:	btc    r10,0x1d
    7c479db0680c:	mov    r11d,0xf0000000
    7c479db06812:	and    r11,r10
    7c479db06815:	movabs rsi,0xffffffff0fffffff
    7c479db0681f:	and    rbx,rsi
    7c479db06822:	or     rbx,r11
    7c479db06825:	pop    r11
    7c479db06827:	pop    r10
    7c479db06829:	pop    rsi
    7c479db0682a:	pop    rdx
    7c479db0682b:	mov    QWORD PTR [r12+0x108],rbx
    7c479db06833:	stmxcsr DWORD PTR [r12-0x28]
    7c479db06839:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0683e:	test   r10d,0x3f
    7c479db06845:	je     0x7c479db0686a
    7c479db0684b:	mov    r11d,r10d
    7c479db0684e:	shr    r10d,1
    7c479db06851:	and    r10d,0x1e
    7c479db06855:	and    r11d,0x1
    7c479db06859:	or     r10d,r11d
    7c479db0685c:	or     DWORD PTR [r12+0x314],r10d
    7c479db06864:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0686a:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db06870:	lea    rdi,[rsp+0x110]
    7c479db06878:	lea    rsi,[rsp+0xf0]
    7c479db06880:	lea    rdx,[rsp+0x100]
    7c479db06888:	mov    ecx,0x14
    7c479db0688d:	mov    r8d,0x0
    7c479db06893:	lea    r9,[r12+0x314]
    7c479db0689b:	movabs r11,0x62fe8718e650
    7c479db068a5:	call   r11
    7c479db068a8:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db068ae:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db068b4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db068ba:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db068c0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db068c6:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db068d0:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db068da:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db068e4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db068ee:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db068f8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db06902:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0690a:	mov    QWORD PTR [r12+0x378],0x2
    7c479db06916:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0691f:	mov    rdx,rbx
    7c479db06922:	shr    rdx,0x10
    7c479db06926:	and    edx,0xc000
    7c479db0692c:	mov    rax,rbx
    7c479db0692f:	shr    rax,0x15
    7c479db06933:	and    eax,0x100
    7c479db06938:	xor    eax,0x100
    7c479db0693d:	or     edx,eax
    7c479db0693f:	mov    rax,rbx
    7c479db06942:	shr    rax,0x1c
    7c479db06946:	and    eax,0x1
    7c479db06949:	or     edx,eax
    7c479db0694b:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db06950:	add    rsp,0x8
    7c479db06954:	ret
    7c479db06955:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db06960:	sub    rsp,0x8
    7c479db06964:	mov    QWORD PTR [r12+0x378],0x3
    7c479db06970:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db06976:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0697c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db06982:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db06988:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db0698e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db06998:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db069a2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db069ac:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db069b6:	push   rdx
    7c479db069b7:	push   rsi
    7c479db069b8:	push   r10
    7c479db069ba:	push   r11
    7c479db069bc:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db069c1:	mov    r10d,edx
    7c479db069c4:	and    r10d,0xc000
    7c479db069cb:	shl    r10d,0x10
    7c479db069cf:	mov    r11d,edx
    7c479db069d2:	and    r11d,0x100
    7c479db069d9:	shl    r11d,0x15
    7c479db069dd:	or     r10d,r11d
    7c479db069e0:	and    edx,0x1
    7c479db069e3:	shl    edx,0x1c
    7c479db069e6:	or     r10d,edx
    7c479db069e9:	btc    r10,0x1d
    7c479db069ee:	mov    r11d,0xf0000000
    7c479db069f4:	and    r11,r10
    7c479db069f7:	movabs rsi,0xffffffff0fffffff
    7c479db06a01:	and    rbx,rsi
    7c479db06a04:	or     rbx,r11
    7c479db06a07:	pop    r11
    7c479db06a09:	pop    r10
    7c479db06a0b:	pop    rsi
    7c479db06a0c:	pop    rdx
    7c479db06a0d:	mov    QWORD PTR [r12+0x108],rbx
    7c479db06a15:	stmxcsr DWORD PTR [r12-0x28]
    7c479db06a1b:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db06a20:	test   r10d,0x3f
    7c479db06a27:	je     0x7c479db06a4c
    7c479db06a2d:	mov    r11d,r10d
    7c479db06a30:	shr    r10d,1
    7c479db06a33:	and    r10d,0x1e
    7c479db06a37:	and    r11d,0x1
    7c479db06a3b:	or     r10d,r11d
    7c479db06a3e:	or     DWORD PTR [r12+0x314],r10d
    7c479db06a46:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db06a4c:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db06a52:	lea    rdi,[rsp+0x110]
    7c479db06a5a:	lea    rsi,[rsp+0xf0]
    7c479db06a62:	lea    rdx,[rsp+0x100]
    7c479db06a6a:	mov    ecx,0x56
    7c479db06a6f:	mov    r8d,0x0
    7c479db06a75:	lea    r9,[r12+0x314]
    7c479db06a7d:	movabs r11,0x62fe8718e650
    7c479db06a87:	call   r11
    7c479db06a8a:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db06a90:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db06a96:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db06a9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db06aa2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db06aa8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db06aae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db06ab8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db06ac2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db06acc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db06ad6:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db06ade:	mov    QWORD PTR [r12+0x378],0x2
    7c479db06aea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db06af3:	mov    rdx,rbx
    7c479db06af6:	shr    rdx,0x10
    7c479db06afa:	and    edx,0xc000
    7c479db06b00:	mov    rax,rbx
    7c479db06b03:	shr    rax,0x15
    7c479db06b07:	and    eax,0x100
    7c479db06b0c:	xor    eax,0x100
    7c479db06b11:	or     edx,eax
    7c479db06b13:	mov    rax,rbx
    7c479db06b16:	shr    rax,0x1c
    7c479db06b1a:	and    eax,0x1
    7c479db06b1d:	or     edx,eax
    7c479db06b1f:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db06b24:	add    rsp,0x8
    7c479db06b28:	ret
    7c479db06b29:	nop    DWORD PTR [rax+0x0]
    7c479db06b30:	sub    rsp,0x8
    7c479db06b34:	mov    QWORD PTR [r12+0x378],0x3
    7c479db06b40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db06b46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db06b4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db06b52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db06b58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db06b5e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db06b64:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db06b6e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db06b78:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db06b82:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db06b8c:	push   rdx
    7c479db06b8d:	push   rsi
    7c479db06b8e:	push   r10
    7c479db06b90:	push   r11
    7c479db06b92:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db06b97:	mov    r10d,edx
    7c479db06b9a:	and    r10d,0xc000
    7c479db06ba1:	shl    r10d,0x10
    7c479db06ba5:	mov    r11d,edx
    7c479db06ba8:	and    r11d,0x100
    7c479db06baf:	shl    r11d,0x15
    7c479db06bb3:	or     r10d,r11d
    7c479db06bb6:	and    edx,0x1
    7c479db06bb9:	shl    edx,0x1c
    7c479db06bbc:	or     r10d,edx
    7c479db06bbf:	btc    r10,0x1d
    7c479db06bc4:	mov    r11d,0xf0000000
    7c479db06bca:	and    r11,r10
    7c479db06bcd:	movabs rsi,0xffffffff0fffffff
    7c479db06bd7:	and    rbx,rsi
    7c479db06bda:	or     rbx,r11
    7c479db06bdd:	pop    r11
    7c479db06bdf:	pop    r10
    7c479db06be1:	pop    rsi
    7c479db06be2:	pop    rdx
    7c479db06be3:	mov    QWORD PTR [r12+0x108],rbx
    7c479db06beb:	stmxcsr DWORD PTR [r12-0x28]
    7c479db06bf1:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db06bf6:	test   r10d,0x3f
    7c479db06bfd:	je     0x7c479db06c22
    7c479db06c03:	mov    r11d,r10d
    7c479db06c06:	shr    r10d,1
    7c479db06c09:	and    r10d,0x1e
    7c479db06c0d:	and    r11d,0x1
    7c479db06c11:	or     r10d,r11d
    7c479db06c14:	or     DWORD PTR [r12+0x314],r10d
    7c479db06c1c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db06c22:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db06c28:	lea    rdi,[rsp+0x110]
    7c479db06c30:	lea    rsi,[rsp+0xf0]
    7c479db06c38:	lea    rdx,[rsp+0x100]
    7c479db06c40:	mov    ecx,0x56
    7c479db06c45:	mov    r8d,0x0
    7c479db06c4b:	lea    r9,[r12+0x314]
    7c479db06c53:	movabs r11,0x62fe8718e650
    7c479db06c5d:	call   r11
    7c479db06c60:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db06c66:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db06c6c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db06c72:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db06c78:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db06c7e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db06c84:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db06c8a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db06c94:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db06c9e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db06ca8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db06cb2:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db06cba:	mov    QWORD PTR [r12+0x378],0x2
    7c479db06cc6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db06ccf:	mov    rdx,rbx
    7c479db06cd2:	shr    rdx,0x10
    7c479db06cd6:	and    edx,0xc000
    7c479db06cdc:	mov    rax,rbx
    7c479db06cdf:	shr    rax,0x15
    7c479db06ce3:	and    eax,0x100
    7c479db06ce8:	xor    eax,0x100
    7c479db06ced:	or     edx,eax
    7c479db06cef:	mov    rax,rbx
    7c479db06cf2:	shr    rax,0x1c
    7c479db06cf6:	and    eax,0x1
    7c479db06cf9:	or     edx,eax
    7c479db06cfb:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db06d00:	add    rsp,0x8
    7c479db06d04:	ret
    7c479db06d05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db06d10:	sub    rsp,0x8
    7c479db06d14:	mov    QWORD PTR [r12+0x378],0x3
    7c479db06d20:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db06d26:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db06d2c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db06d32:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db06d38:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db06d3e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db06d44:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db06d4e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db06d58:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db06d62:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db06d6c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db06d76:	push   rdx
    7c479db06d77:	push   rsi
    7c479db06d78:	push   r10
    7c479db06d7a:	push   r11
    7c479db06d7c:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db06d81:	mov    r10d,edx
    7c479db06d84:	and    r10d,0xc000
    7c479db06d8b:	shl    r10d,0x10
    7c479db06d8f:	mov    r11d,edx
    7c479db06d92:	and    r11d,0x100
    7c479db06d99:	shl    r11d,0x15
    7c479db06d9d:	or     r10d,r11d
    7c479db06da0:	and    edx,0x1
    7c479db06da3:	shl    edx,0x1c
    7c479db06da6:	or     r10d,edx
    7c479db06da9:	btc    r10,0x1d
    7c479db06dae:	mov    r11d,0xf0000000
    7c479db06db4:	and    r11,r10
    7c479db06db7:	movabs rsi,0xffffffff0fffffff
    7c479db06dc1:	and    rbx,rsi
    7c479db06dc4:	or     rbx,r11
    7c479db06dc7:	pop    r11
    7c479db06dc9:	pop    r10
    7c479db06dcb:	pop    rsi
    7c479db06dcc:	pop    rdx
    7c479db06dcd:	mov    QWORD PTR [r12+0x108],rbx
    7c479db06dd5:	stmxcsr DWORD PTR [r12-0x28]
    7c479db06ddb:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db06de0:	test   r10d,0x3f
    7c479db06de7:	je     0x7c479db06e0c
    7c479db06ded:	mov    r11d,r10d
    7c479db06df0:	shr    r10d,1
    7c479db06df3:	and    r10d,0x1e
    7c479db06df7:	and    r11d,0x1
    7c479db06dfb:	or     r10d,r11d
    7c479db06dfe:	or     DWORD PTR [r12+0x314],r10d
    7c479db06e06:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db06e0c:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db06e12:	lea    rdi,[rsp+0x110]
    7c479db06e1a:	lea    rsi,[rsp+0xf0]
    7c479db06e22:	lea    rdx,[rsp+0x100]
    7c479db06e2a:	mov    ecx,0x56
    7c479db06e2f:	mov    r8d,0x0
    7c479db06e35:	lea    r9,[r12+0x314]
    7c479db06e3d:	movabs r11,0x62fe8718e650
    7c479db06e47:	call   r11
    7c479db06e4a:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db06e50:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db06e56:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db06e5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db06e62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db06e68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db06e6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db06e74:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db06e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db06e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db06e92:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db06e9c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db06ea6:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db06eae:	mov    QWORD PTR [r12+0x378],0x2
    7c479db06eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db06ec3:	mov    rdx,rbx
    7c479db06ec6:	shr    rdx,0x10
    7c479db06eca:	and    edx,0xc000
    7c479db06ed0:	mov    rax,rbx
    7c479db06ed3:	shr    rax,0x15
    7c479db06ed7:	and    eax,0x100
    7c479db06edc:	xor    eax,0x100
    7c479db06ee1:	or     edx,eax
    7c479db06ee3:	mov    rax,rbx
    7c479db06ee6:	shr    rax,0x1c
    7c479db06eea:	and    eax,0x1
    7c479db06eed:	or     edx,eax
    7c479db06eef:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db06ef4:	add    rsp,0x8
    7c479db06ef8:	ret
    7c479db06ef9:	nop    DWORD PTR [rax+0x0]
    7c479db06f00:	sub    rsp,0x8
    7c479db06f04:	mov    QWORD PTR [r12+0x378],0x3
    7c479db06f10:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db06f16:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db06f1c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db06f22:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db06f28:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db06f32:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db06f3c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db06f46:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db06f50:	push   rdx
    7c479db06f51:	push   rsi
    7c479db06f52:	push   r10
    7c479db06f54:	push   r11
    7c479db06f56:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db06f5b:	mov    r10d,edx
    7c479db06f5e:	and    r10d,0xc000
    7c479db06f65:	shl    r10d,0x10
    7c479db06f69:	mov    r11d,edx
    7c479db06f6c:	and    r11d,0x100
    7c479db06f73:	shl    r11d,0x15
    7c479db06f77:	or     r10d,r11d
    7c479db06f7a:	and    edx,0x1
    7c479db06f7d:	shl    edx,0x1c
    7c479db06f80:	or     r10d,edx
    7c479db06f83:	btc    r10,0x1d
    7c479db06f88:	mov    r11d,0xf0000000
    7c479db06f8e:	and    r11,r10
    7c479db06f91:	movabs rsi,0xffffffff0fffffff
    7c479db06f9b:	and    rbx,rsi
    7c479db06f9e:	or     rbx,r11
    7c479db06fa1:	pop    r11
    7c479db06fa3:	pop    r10
    7c479db06fa5:	pop    rsi
    7c479db06fa6:	pop    rdx
    7c479db06fa7:	mov    QWORD PTR [r12+0x108],rbx
    7c479db06faf:	stmxcsr DWORD PTR [r12-0x28]
    7c479db06fb5:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db06fba:	test   r10d,0x3f
    7c479db06fc1:	je     0x7c479db06fe6
    7c479db06fc7:	mov    r11d,r10d
    7c479db06fca:	shr    r10d,1
    7c479db06fcd:	and    r10d,0x1e
    7c479db06fd1:	and    r11d,0x1
    7c479db06fd5:	or     r10d,r11d
    7c479db06fd8:	or     DWORD PTR [r12+0x314],r10d
    7c479db06fe0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db06fe6:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db06fec:	lea    rdi,[rsp+0x110]
    7c479db06ff4:	lea    rsi,[rsp+0xf0]
    7c479db06ffc:	lea    rdx,[rsp+0x100]
    7c479db07004:	mov    ecx,0x56
    7c479db07009:	mov    r8d,0x0
    7c479db0700f:	lea    r9,[r12+0x314]
    7c479db07017:	movabs r11,0x62fe8718e650
    7c479db07021:	call   r11
    7c479db07024:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0702a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db07030:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db07036:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0703c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db07042:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db0704c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db07056:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db07060:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0706a:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db07072:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0707e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db07087:	mov    rdx,rbx
    7c479db0708a:	shr    rdx,0x10
    7c479db0708e:	and    edx,0xc000
    7c479db07094:	mov    rax,rbx
    7c479db07097:	shr    rax,0x15
    7c479db0709b:	and    eax,0x100
    7c479db070a0:	xor    eax,0x100
    7c479db070a5:	or     edx,eax
    7c479db070a7:	mov    rax,rbx
    7c479db070aa:	shr    rax,0x1c
    7c479db070ae:	and    eax,0x1
    7c479db070b1:	or     edx,eax
    7c479db070b3:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db070b8:	add    rsp,0x8
    7c479db070bc:	ret
    7c479db070bd:	nop    DWORD PTR [rax]
    7c479db070c0:	sub    rsp,0x8
    7c479db070c4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db070d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db070d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db070dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db070e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db070e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db070ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db070f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db07102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db0710c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db07116:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db07120:	push   rdx
    7c479db07121:	push   rsi
    7c479db07122:	push   r10
    7c479db07124:	push   r11
    7c479db07126:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0712b:	mov    r10d,edx
    7c479db0712e:	and    r10d,0xc000
    7c479db07135:	shl    r10d,0x10
    7c479db07139:	mov    r11d,edx
    7c479db0713c:	and    r11d,0x100
    7c479db07143:	shl    r11d,0x15
    7c479db07147:	or     r10d,r11d
    7c479db0714a:	and    edx,0x1
    7c479db0714d:	shl    edx,0x1c
    7c479db07150:	or     r10d,edx
    7c479db07153:	btc    r10,0x1d
    7c479db07158:	mov    r11d,0xf0000000
    7c479db0715e:	and    r11,r10
    7c479db07161:	movabs rsi,0xffffffff0fffffff
    7c479db0716b:	and    rbx,rsi
    7c479db0716e:	or     rbx,r11
    7c479db07171:	pop    r11
    7c479db07173:	pop    r10
    7c479db07175:	pop    rsi
    7c479db07176:	pop    rdx
    7c479db07177:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0717f:	stmxcsr DWORD PTR [r12-0x28]
    7c479db07185:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0718a:	test   r10d,0x3f
    7c479db07191:	je     0x7c479db071b6
    7c479db07197:	mov    r11d,r10d
    7c479db0719a:	shr    r10d,1
    7c479db0719d:	and    r10d,0x1e
    7c479db071a1:	and    r11d,0x1
    7c479db071a5:	or     r10d,r11d
    7c479db071a8:	or     DWORD PTR [r12+0x314],r10d
    7c479db071b0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db071b6:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db071bc:	lea    rdi,[rsp+0x110]
    7c479db071c4:	lea    rsi,[rsp+0xf0]
    7c479db071cc:	lea    rdx,[rsp+0x100]
    7c479db071d4:	mov    ecx,0x14
    7c479db071d9:	mov    r8d,0x0
    7c479db071df:	lea    r9,[r12+0x314]
    7c479db071e7:	movabs r11,0x62fe8718e650
    7c479db071f1:	call   r11
    7c479db071f4:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db071fa:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db07200:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db07206:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0720c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db07212:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db07218:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db07222:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0722c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db07236:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db07240:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db0724a:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db07252:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0725e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db07267:	mov    rdx,rbx
    7c479db0726a:	shr    rdx,0x10
    7c479db0726e:	and    edx,0xc000
    7c479db07274:	mov    rax,rbx
    7c479db07277:	shr    rax,0x15
    7c479db0727b:	and    eax,0x100
    7c479db07280:	xor    eax,0x100
    7c479db07285:	or     edx,eax
    7c479db07287:	mov    rax,rbx
    7c479db0728a:	shr    rax,0x1c
    7c479db0728e:	and    eax,0x1
    7c479db07291:	or     edx,eax
    7c479db07293:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db07298:	add    rsp,0x8
    7c479db0729c:	ret
    7c479db0729d:	nop    DWORD PTR [rax]
    7c479db072a0:	sub    rsp,0x8
    7c479db072a4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db072b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db072b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db072bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db072c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db072c8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db072ce:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db072d8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db072e2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db072ec:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db072f6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db07300:	push   rdx
    7c479db07301:	push   rsi
    7c479db07302:	push   r10
    7c479db07304:	push   r11
    7c479db07306:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0730b:	mov    r10d,edx
    7c479db0730e:	and    r10d,0xc000
    7c479db07315:	shl    r10d,0x10
    7c479db07319:	mov    r11d,edx
    7c479db0731c:	and    r11d,0x100
    7c479db07323:	shl    r11d,0x15
    7c479db07327:	or     r10d,r11d
    7c479db0732a:	and    edx,0x1
    7c479db0732d:	shl    edx,0x1c
    7c479db07330:	or     r10d,edx
    7c479db07333:	btc    r10,0x1d
    7c479db07338:	mov    r11d,0xf0000000
    7c479db0733e:	and    r11,r10
    7c479db07341:	movabs rsi,0xffffffff0fffffff
    7c479db0734b:	and    rbx,rsi
    7c479db0734e:	or     rbx,r11
    7c479db07351:	pop    r11
    7c479db07353:	pop    r10
    7c479db07355:	pop    rsi
    7c479db07356:	pop    rdx
    7c479db07357:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0735f:	stmxcsr DWORD PTR [r12-0x28]
    7c479db07365:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0736a:	test   r10d,0x3f
    7c479db07371:	je     0x7c479db07396
    7c479db07377:	mov    r11d,r10d
    7c479db0737a:	shr    r10d,1
    7c479db0737d:	and    r10d,0x1e
    7c479db07381:	and    r11d,0x1
    7c479db07385:	or     r10d,r11d
    7c479db07388:	or     DWORD PTR [r12+0x314],r10d
    7c479db07390:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db07396:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0739c:	lea    rdi,[rsp+0x110]
    7c479db073a4:	lea    rsi,[rsp+0xf0]
    7c479db073ac:	lea    rdx,[rsp+0x100]
    7c479db073b4:	mov    ecx,0x56
    7c479db073b9:	mov    r8d,0x0
    7c479db073bf:	lea    r9,[r12+0x314]
    7c479db073c7:	movabs r11,0x62fe8718e650
    7c479db073d1:	call   r11
    7c479db073d4:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db073da:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db073e0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db073e6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db073ec:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db073f2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db073f8:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db07402:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0740c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db07416:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db07420:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db0742a:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db07432:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0743e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db07447:	mov    rdx,rbx
    7c479db0744a:	shr    rdx,0x10
    7c479db0744e:	and    edx,0xc000
    7c479db07454:	mov    rax,rbx
    7c479db07457:	shr    rax,0x15
    7c479db0745b:	and    eax,0x100
    7c479db07460:	xor    eax,0x100
    7c479db07465:	or     edx,eax
    7c479db07467:	mov    rax,rbx
    7c479db0746a:	shr    rax,0x1c
    7c479db0746e:	and    eax,0x1
    7c479db07471:	or     edx,eax
    7c479db07473:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db07478:	add    rsp,0x8
    7c479db0747c:	ret
    7c479db0747d:	nop    DWORD PTR [rax]
    7c479db07480:	sub    rsp,0x8
    7c479db07484:	mov    QWORD PTR [r12+0x378],0x3
    7c479db07490:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db07496:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0749c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db074a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db074a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db074ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db074b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db074be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db074c8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db074d2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db074dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db074e6:	push   rdx
    7c479db074e7:	push   rsi
    7c479db074e8:	push   r10
    7c479db074ea:	push   r11
    7c479db074ec:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db074f1:	mov    r10d,edx
    7c479db074f4:	and    r10d,0xc000
    7c479db074fb:	shl    r10d,0x10
    7c479db074ff:	mov    r11d,edx
    7c479db07502:	and    r11d,0x100
    7c479db07509:	shl    r11d,0x15
    7c479db0750d:	or     r10d,r11d
    7c479db07510:	and    edx,0x1
    7c479db07513:	shl    edx,0x1c
    7c479db07516:	or     r10d,edx
    7c479db07519:	btc    r10,0x1d
    7c479db0751e:	mov    r11d,0xf0000000
    7c479db07524:	and    r11,r10
    7c479db07527:	movabs rsi,0xffffffff0fffffff
    7c479db07531:	and    rbx,rsi
    7c479db07534:	or     rbx,r11
    7c479db07537:	pop    r11
    7c479db07539:	pop    r10
    7c479db0753b:	pop    rsi
    7c479db0753c:	pop    rdx
    7c479db0753d:	mov    QWORD PTR [r12+0x108],rbx
    7c479db07545:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0754b:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db07550:	test   r10d,0x3f
    7c479db07557:	je     0x7c479db0757c
    7c479db0755d:	mov    r11d,r10d
    7c479db07560:	shr    r10d,1
    7c479db07563:	and    r10d,0x1e
    7c479db07567:	and    r11d,0x1
    7c479db0756b:	or     r10d,r11d
    7c479db0756e:	or     DWORD PTR [r12+0x314],r10d
    7c479db07576:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0757c:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db07582:	lea    rdi,[rsp+0x110]
    7c479db0758a:	lea    rsi,[rsp+0xf0]
    7c479db07592:	lea    rdx,[rsp+0x100]
    7c479db0759a:	mov    ecx,0x14
    7c479db0759f:	mov    r8d,0x0
    7c479db075a5:	lea    r9,[r12+0x314]
    7c479db075ad:	movabs r11,0x62fe8718e650
    7c479db075b7:	call   r11
    7c479db075ba:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db075c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db075c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db075cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db075d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db075d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db075de:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db075e4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db075ee:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db075f8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db07602:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0760c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db07616:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0761e:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0762a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db07633:	mov    rdx,rbx
    7c479db07636:	shr    rdx,0x10
    7c479db0763a:	and    edx,0xc000
    7c479db07640:	mov    rax,rbx
    7c479db07643:	shr    rax,0x15
    7c479db07647:	and    eax,0x100
    7c479db0764c:	xor    eax,0x100
    7c479db07651:	or     edx,eax
    7c479db07653:	mov    rax,rbx
    7c479db07656:	shr    rax,0x1c
    7c479db0765a:	and    eax,0x1
    7c479db0765d:	or     edx,eax
    7c479db0765f:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db07664:	add    rsp,0x8
    7c479db07668:	ret
    7c479db07669:	nop    DWORD PTR [rax+0x0]
    7c479db07670:	sub    rsp,0x8
    7c479db07674:	mov    QWORD PTR [r12+0x378],0x3
    7c479db07680:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db07686:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0768c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db07692:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db07698:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0769e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db076a4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db076ae:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db076b8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db076c2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db076cc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db076d6:	push   rdx
    7c479db076d7:	push   rsi
    7c479db076d8:	push   r10
    7c479db076da:	push   r11
    7c479db076dc:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db076e1:	mov    r10d,edx
    7c479db076e4:	and    r10d,0xc000
    7c479db076eb:	shl    r10d,0x10
    7c479db076ef:	mov    r11d,edx
    7c479db076f2:	and    r11d,0x100
    7c479db076f9:	shl    r11d,0x15
    7c479db076fd:	or     r10d,r11d
    7c479db07700:	and    edx,0x1
    7c479db07703:	shl    edx,0x1c
    7c479db07706:	or     r10d,edx
    7c479db07709:	btc    r10,0x1d
    7c479db0770e:	mov    r11d,0xf0000000
    7c479db07714:	and    r11,r10
    7c479db07717:	movabs rsi,0xffffffff0fffffff
    7c479db07721:	and    rbx,rsi
    7c479db07724:	or     rbx,r11
    7c479db07727:	pop    r11
    7c479db07729:	pop    r10
    7c479db0772b:	pop    rsi
    7c479db0772c:	pop    rdx
    7c479db0772d:	mov    QWORD PTR [r12+0x108],rbx
    7c479db07735:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0773b:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db07740:	test   r10d,0x3f
    7c479db07747:	je     0x7c479db0776c
    7c479db0774d:	mov    r11d,r10d
    7c479db07750:	shr    r10d,1
    7c479db07753:	and    r10d,0x1e
    7c479db07757:	and    r11d,0x1
    7c479db0775b:	or     r10d,r11d
    7c479db0775e:	or     DWORD PTR [r12+0x314],r10d
    7c479db07766:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0776c:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db07772:	lea    rdi,[rsp+0x110]
    7c479db0777a:	lea    rsi,[rsp+0xf0]
    7c479db07782:	lea    rdx,[rsp+0x100]
    7c479db0778a:	mov    ecx,0x14
    7c479db0778f:	mov    r8d,0x0
    7c479db07795:	lea    r9,[r12+0x314]
    7c479db0779d:	movabs r11,0x62fe8718e650
    7c479db077a7:	call   r11
    7c479db077aa:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db077b0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db077b6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db077bc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db077c2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db077c8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db077ce:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db077d4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db077de:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db077e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db077f2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db077fc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db07806:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0780e:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0781a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db07823:	mov    rdx,rbx
    7c479db07826:	shr    rdx,0x10
    7c479db0782a:	and    edx,0xc000
    7c479db07830:	mov    rax,rbx
    7c479db07833:	shr    rax,0x15
    7c479db07837:	and    eax,0x100
    7c479db0783c:	xor    eax,0x100
    7c479db07841:	or     edx,eax
    7c479db07843:	mov    rax,rbx
    7c479db07846:	shr    rax,0x1c
    7c479db0784a:	and    eax,0x1
    7c479db0784d:	or     edx,eax
    7c479db0784f:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db07854:	add    rsp,0x8
    7c479db07858:	ret
    7c479db07859:	nop    DWORD PTR [rax+0x0]
    7c479db07860:	sub    rsp,0x8
    7c479db07864:	mov    QWORD PTR [r12+0x378],0x3
    7c479db07870:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db07876:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0787c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db07882:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db07888:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0788e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db07894:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db0789e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db078a8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db078b2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db078bc:	push   rdx
    7c479db078bd:	push   rsi
    7c479db078be:	push   r10
    7c479db078c0:	push   r11
    7c479db078c2:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db078c7:	mov    r10d,edx
    7c479db078ca:	and    r10d,0xc000
    7c479db078d1:	shl    r10d,0x10
    7c479db078d5:	mov    r11d,edx
    7c479db078d8:	and    r11d,0x100
    7c479db078df:	shl    r11d,0x15
    7c479db078e3:	or     r10d,r11d
    7c479db078e6:	and    edx,0x1
    7c479db078e9:	shl    edx,0x1c
    7c479db078ec:	or     r10d,edx
    7c479db078ef:	btc    r10,0x1d
    7c479db078f4:	mov    r11d,0xf0000000
    7c479db078fa:	and    r11,r10
    7c479db078fd:	movabs rsi,0xffffffff0fffffff
    7c479db07907:	and    rbx,rsi
    7c479db0790a:	or     rbx,r11
    7c479db0790d:	pop    r11
    7c479db0790f:	pop    r10
    7c479db07911:	pop    rsi
    7c479db07912:	pop    rdx
    7c479db07913:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0791b:	stmxcsr DWORD PTR [r12-0x28]
    7c479db07921:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db07926:	test   r10d,0x3f
    7c479db0792d:	je     0x7c479db07952
    7c479db07933:	mov    r11d,r10d
    7c479db07936:	shr    r10d,1
    7c479db07939:	and    r10d,0x1e
    7c479db0793d:	and    r11d,0x1
    7c479db07941:	or     r10d,r11d
    7c479db07944:	or     DWORD PTR [r12+0x314],r10d
    7c479db0794c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db07952:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db07958:	lea    rdi,[rsp+0x110]
    7c479db07960:	lea    rsi,[rsp+0xf0]
    7c479db07968:	lea    rdx,[rsp+0x100]
    7c479db07970:	mov    ecx,0x56
    7c479db07975:	mov    r8d,0x0
    7c479db0797b:	lea    r9,[r12+0x314]
    7c479db07983:	movabs r11,0x62fe8718e650
    7c479db0798d:	call   r11
    7c479db07990:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db07996:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0799c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db079a2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db079a8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db079ae:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db079b4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db079ba:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db079c4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db079ce:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db079d8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db079e2:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db079ea:	mov    QWORD PTR [r12+0x378],0x2
    7c479db079f6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db079ff:	mov    rdx,rbx
    7c479db07a02:	shr    rdx,0x10
    7c479db07a06:	and    edx,0xc000
    7c479db07a0c:	mov    rax,rbx
    7c479db07a0f:	shr    rax,0x15
    7c479db07a13:	and    eax,0x100
    7c479db07a18:	xor    eax,0x100
    7c479db07a1d:	or     edx,eax
    7c479db07a1f:	mov    rax,rbx
    7c479db07a22:	shr    rax,0x1c
    7c479db07a26:	and    eax,0x1
    7c479db07a29:	or     edx,eax
    7c479db07a2b:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db07a30:	add    rsp,0x8
    7c479db07a34:	ret
    7c479db07a35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db07a40:	sub    rsp,0x8
    7c479db07a44:	mov    QWORD PTR [r12+0x378],0x3
    7c479db07a50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db07a56:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db07a5c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db07a62:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db07a68:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db07a6e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db07a74:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db07a7e:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db07a88:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db07a92:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db07a9c:	push   rdx
    7c479db07a9d:	push   rsi
    7c479db07a9e:	push   r10
    7c479db07aa0:	push   r11
    7c479db07aa2:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db07aa7:	mov    r10d,edx
    7c479db07aaa:	and    r10d,0xc000
    7c479db07ab1:	shl    r10d,0x10
    7c479db07ab5:	mov    r11d,edx
    7c479db07ab8:	and    r11d,0x100
    7c479db07abf:	shl    r11d,0x15
    7c479db07ac3:	or     r10d,r11d
    7c479db07ac6:	and    edx,0x1
    7c479db07ac9:	shl    edx,0x1c
    7c479db07acc:	or     r10d,edx
    7c479db07acf:	btc    r10,0x1d
    7c479db07ad4:	mov    r11d,0xf0000000
    7c479db07ada:	and    r11,r10
    7c479db07add:	movabs rsi,0xffffffff0fffffff
    7c479db07ae7:	and    rbx,rsi
    7c479db07aea:	or     rbx,r11
    7c479db07aed:	pop    r11
    7c479db07aef:	pop    r10
    7c479db07af1:	pop    rsi
    7c479db07af2:	pop    rdx
    7c479db07af3:	mov    QWORD PTR [r12+0x108],rbx
    7c479db07afb:	stmxcsr DWORD PTR [r12-0x28]
    7c479db07b01:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db07b06:	test   r10d,0x3f
    7c479db07b0d:	je     0x7c479db07b32
    7c479db07b13:	mov    r11d,r10d
    7c479db07b16:	shr    r10d,1
    7c479db07b19:	and    r10d,0x1e
    7c479db07b1d:	and    r11d,0x1
    7c479db07b21:	or     r10d,r11d
    7c479db07b24:	or     DWORD PTR [r12+0x314],r10d
    7c479db07b2c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db07b32:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db07b38:	lea    rdi,[rsp+0x110]
    7c479db07b40:	lea    rsi,[rsp+0xf0]
    7c479db07b48:	lea    rdx,[rsp+0x100]
    7c479db07b50:	mov    ecx,0x14
    7c479db07b55:	mov    r8d,0x0
    7c479db07b5b:	lea    r9,[r12+0x314]
    7c479db07b63:	movabs r11,0x62fe8718e650
    7c479db07b6d:	call   r11
    7c479db07b70:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db07b76:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db07b7c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db07b82:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db07b88:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db07b8e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db07b94:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db07b9a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db07ba4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db07bae:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db07bb8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db07bc2:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db07bca:	mov    QWORD PTR [r12+0x378],0x2
    7c479db07bd6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db07bdf:	mov    rdx,rbx
    7c479db07be2:	shr    rdx,0x10
    7c479db07be6:	and    edx,0xc000
    7c479db07bec:	mov    rax,rbx
    7c479db07bef:	shr    rax,0x15
    7c479db07bf3:	and    eax,0x100
    7c479db07bf8:	xor    eax,0x100
    7c479db07bfd:	or     edx,eax
    7c479db07bff:	mov    rax,rbx
    7c479db07c02:	shr    rax,0x1c
    7c479db07c06:	and    eax,0x1
    7c479db07c09:	or     edx,eax
    7c479db07c0b:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db07c10:	add    rsp,0x8
    7c479db07c14:	ret
    7c479db07c15:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db07c20:	sub    rsp,0x8
    7c479db07c24:	mov    QWORD PTR [r12+0x378],0x3
    7c479db07c30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db07c36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db07c3c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db07c42:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db07c48:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db07c4e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db07c58:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db07c62:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db07c6c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db07c76:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db07c80:	push   rdx
    7c479db07c81:	push   rsi
    7c479db07c82:	push   r10
    7c479db07c84:	push   r11
    7c479db07c86:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db07c8b:	mov    r10d,edx
    7c479db07c8e:	and    r10d,0xc000
    7c479db07c95:	shl    r10d,0x10
    7c479db07c99:	mov    r11d,edx
    7c479db07c9c:	and    r11d,0x100
    7c479db07ca3:	shl    r11d,0x15
    7c479db07ca7:	or     r10d,r11d
    7c479db07caa:	and    edx,0x1
    7c479db07cad:	shl    edx,0x1c
    7c479db07cb0:	or     r10d,edx
    7c479db07cb3:	btc    r10,0x1d
    7c479db07cb8:	mov    r11d,0xf0000000
    7c479db07cbe:	and    r11,r10
    7c479db07cc1:	movabs rsi,0xffffffff0fffffff
    7c479db07ccb:	and    rbx,rsi
    7c479db07cce:	or     rbx,r11
    7c479db07cd1:	pop    r11
    7c479db07cd3:	pop    r10
    7c479db07cd5:	pop    rsi
    7c479db07cd6:	pop    rdx
    7c479db07cd7:	mov    QWORD PTR [r12+0x108],rbx
    7c479db07cdf:	stmxcsr DWORD PTR [r12-0x28]
    7c479db07ce5:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db07cea:	test   r10d,0x3f
    7c479db07cf1:	je     0x7c479db07d16
    7c479db07cf7:	mov    r11d,r10d
    7c479db07cfa:	shr    r10d,1
    7c479db07cfd:	and    r10d,0x1e
    7c479db07d01:	and    r11d,0x1
    7c479db07d05:	or     r10d,r11d
    7c479db07d08:	or     DWORD PTR [r12+0x314],r10d
    7c479db07d10:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db07d16:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db07d1c:	lea    rdi,[rsp+0x110]
    7c479db07d24:	lea    rsi,[rsp+0xf0]
    7c479db07d2c:	lea    rdx,[rsp+0x100]
    7c479db07d34:	mov    ecx,0x56
    7c479db07d39:	mov    r8d,0x0
    7c479db07d3f:	lea    r9,[r12+0x314]
    7c479db07d47:	movabs r11,0x62fe8718e650
    7c479db07d51:	call   r11
    7c479db07d54:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db07d5a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db07d60:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db07d66:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db07d6c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db07d72:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db07d78:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db07d82:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db07d8c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db07d96:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db07da0:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db07daa:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db07db2:	mov    QWORD PTR [r12+0x378],0x2
    7c479db07dbe:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db07dc7:	mov    rdx,rbx
    7c479db07dca:	shr    rdx,0x10
    7c479db07dce:	and    edx,0xc000
    7c479db07dd4:	mov    rax,rbx
    7c479db07dd7:	shr    rax,0x15
    7c479db07ddb:	and    eax,0x100
    7c479db07de0:	xor    eax,0x100
    7c479db07de5:	or     edx,eax
    7c479db07de7:	mov    rax,rbx
    7c479db07dea:	shr    rax,0x1c
    7c479db07dee:	and    eax,0x1
    7c479db07df1:	or     edx,eax
    7c479db07df3:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db07df8:	add    rsp,0x8
    7c479db07dfc:	ret
    7c479db07dfd:	nop    DWORD PTR [rax]
    7c479db07e00:	sub    rsp,0x8
    7c479db07e04:	mov    QWORD PTR [r12+0x378],0x3
    7c479db07e10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db07e16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db07e1c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db07e22:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db07e28:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db07e2e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db07e34:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db07e3e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db07e48:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db07e52:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db07e5c:	push   rdx
    7c479db07e5d:	push   rsi
    7c479db07e5e:	push   r10
    7c479db07e60:	push   r11
    7c479db07e62:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db07e67:	mov    r10d,edx
    7c479db07e6a:	and    r10d,0xc000
    7c479db07e71:	shl    r10d,0x10
    7c479db07e75:	mov    r11d,edx
    7c479db07e78:	and    r11d,0x100
    7c479db07e7f:	shl    r11d,0x15
    7c479db07e83:	or     r10d,r11d
    7c479db07e86:	and    edx,0x1
    7c479db07e89:	shl    edx,0x1c
    7c479db07e8c:	or     r10d,edx
    7c479db07e8f:	btc    r10,0x1d
    7c479db07e94:	mov    r11d,0xf0000000
    7c479db07e9a:	and    r11,r10
    7c479db07e9d:	movabs rsi,0xffffffff0fffffff
    7c479db07ea7:	and    rbx,rsi
    7c479db07eaa:	or     rbx,r11
    7c479db07ead:	pop    r11
    7c479db07eaf:	pop    r10
    7c479db07eb1:	pop    rsi
    7c479db07eb2:	pop    rdx
    7c479db07eb3:	mov    QWORD PTR [r12+0x108],rbx
    7c479db07ebb:	stmxcsr DWORD PTR [r12-0x28]
    7c479db07ec1:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db07ec6:	test   r10d,0x3f
    7c479db07ecd:	je     0x7c479db07ef2
    7c479db07ed3:	mov    r11d,r10d
    7c479db07ed6:	shr    r10d,1
    7c479db07ed9:	and    r10d,0x1e
    7c479db07edd:	and    r11d,0x1
    7c479db07ee1:	or     r10d,r11d
    7c479db07ee4:	or     DWORD PTR [r12+0x314],r10d
    7c479db07eec:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db07ef2:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db07ef8:	lea    rdi,[rsp+0x110]
    7c479db07f00:	lea    rsi,[rsp+0xf0]
    7c479db07f08:	lea    rdx,[rsp+0x100]
    7c479db07f10:	mov    ecx,0x56
    7c479db07f15:	mov    r8d,0x0
    7c479db07f1b:	lea    r9,[r12+0x314]
    7c479db07f23:	movabs r11,0x62fe8718e650
    7c479db07f2d:	call   r11
    7c479db07f30:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db07f36:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db07f3c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db07f42:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db07f48:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db07f4e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db07f54:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db07f5a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db07f64:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db07f6e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db07f78:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db07f82:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db07f8a:	mov    QWORD PTR [r12+0x378],0x2
    7c479db07f96:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db07f9f:	mov    rdx,rbx
    7c479db07fa2:	shr    rdx,0x10
    7c479db07fa6:	and    edx,0xc000
    7c479db07fac:	mov    rax,rbx
    7c479db07faf:	shr    rax,0x15
    7c479db07fb3:	and    eax,0x100
    7c479db07fb8:	xor    eax,0x100
    7c479db07fbd:	or     edx,eax
    7c479db07fbf:	mov    rax,rbx
    7c479db07fc2:	shr    rax,0x1c
    7c479db07fc6:	and    eax,0x1
    7c479db07fc9:	or     edx,eax
    7c479db07fcb:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db07fd0:	add    rsp,0x8
    7c479db07fd4:	ret
    7c479db07fd5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db07fe0:	sub    rsp,0x8
    7c479db07fe4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db07ff0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db07ff6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db07ffc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db08002:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db08008:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0800e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db08014:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db0801e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db08028:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db08032:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db0803c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db08046:	push   rdx
    7c479db08047:	push   rsi
    7c479db08048:	push   r10
    7c479db0804a:	push   r11
    7c479db0804c:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db08051:	mov    r10d,edx
    7c479db08054:	and    r10d,0xc000
    7c479db0805b:	shl    r10d,0x10
    7c479db0805f:	mov    r11d,edx
    7c479db08062:	and    r11d,0x100
    7c479db08069:	shl    r11d,0x15
    7c479db0806d:	or     r10d,r11d
    7c479db08070:	and    edx,0x1
    7c479db08073:	shl    edx,0x1c
    7c479db08076:	or     r10d,edx
    7c479db08079:	btc    r10,0x1d
    7c479db0807e:	mov    r11d,0xf0000000
    7c479db08084:	and    r11,r10
    7c479db08087:	movabs rsi,0xffffffff0fffffff
    7c479db08091:	and    rbx,rsi
    7c479db08094:	or     rbx,r11
    7c479db08097:	pop    r11
    7c479db08099:	pop    r10
    7c479db0809b:	pop    rsi
    7c479db0809c:	pop    rdx
    7c479db0809d:	mov    QWORD PTR [r12+0x108],rbx
    7c479db080a5:	stmxcsr DWORD PTR [r12-0x28]
    7c479db080ab:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db080b0:	test   r10d,0x3f
    7c479db080b7:	je     0x7c479db080dc
    7c479db080bd:	mov    r11d,r10d
    7c479db080c0:	shr    r10d,1
    7c479db080c3:	and    r10d,0x1e
    7c479db080c7:	and    r11d,0x1
    7c479db080cb:	or     r10d,r11d
    7c479db080ce:	or     DWORD PTR [r12+0x314],r10d
    7c479db080d6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db080dc:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db080e2:	lea    rdi,[rsp+0x110]
    7c479db080ea:	lea    rsi,[rsp+0xf0]
    7c479db080f2:	lea    rdx,[rsp+0x100]
    7c479db080fa:	mov    ecx,0x14
    7c479db080ff:	mov    r8d,0x0
    7c479db08105:	lea    r9,[r12+0x314]
    7c479db0810d:	movabs r11,0x62fe8718e650
    7c479db08117:	call   r11
    7c479db0811a:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db08120:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db08126:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0812c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db08132:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db08138:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0813e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db08144:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0814e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db08158:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db08162:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0816c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db08176:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0817e:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0818a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db08193:	mov    rdx,rbx
    7c479db08196:	shr    rdx,0x10
    7c479db0819a:	and    edx,0xc000
    7c479db081a0:	mov    rax,rbx
    7c479db081a3:	shr    rax,0x15
    7c479db081a7:	and    eax,0x100
    7c479db081ac:	xor    eax,0x100
    7c479db081b1:	or     edx,eax
    7c479db081b3:	mov    rax,rbx
    7c479db081b6:	shr    rax,0x1c
    7c479db081ba:	and    eax,0x1
    7c479db081bd:	or     edx,eax
    7c479db081bf:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db081c4:	add    rsp,0x8
    7c479db081c8:	ret
    7c479db081c9:	nop    DWORD PTR [rax+0x0]
    7c479db081d0:	sub    rsp,0x8
    7c479db081d4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db081e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db081e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db081ec:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db081f2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db081f8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db08202:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db0820c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db08216:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db08220:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db0822a:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db08234:	push   rdx
    7c479db08235:	push   rsi
    7c479db08236:	push   r10
    7c479db08238:	push   r11
    7c479db0823a:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0823f:	mov    r10d,edx
    7c479db08242:	and    r10d,0xc000
    7c479db08249:	shl    r10d,0x10
    7c479db0824d:	mov    r11d,edx
    7c479db08250:	and    r11d,0x100
    7c479db08257:	shl    r11d,0x15
    7c479db0825b:	or     r10d,r11d
    7c479db0825e:	and    edx,0x1
    7c479db08261:	shl    edx,0x1c
    7c479db08264:	or     r10d,edx
    7c479db08267:	btc    r10,0x1d
    7c479db0826c:	mov    r11d,0xf0000000
    7c479db08272:	and    r11,r10
    7c479db08275:	movabs rsi,0xffffffff0fffffff
    7c479db0827f:	and    rbx,rsi
    7c479db08282:	or     rbx,r11
    7c479db08285:	pop    r11
    7c479db08287:	pop    r10
    7c479db08289:	pop    rsi
    7c479db0828a:	pop    rdx
    7c479db0828b:	mov    QWORD PTR [r12+0x108],rbx
    7c479db08293:	stmxcsr DWORD PTR [r12-0x28]
    7c479db08299:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0829e:	test   r10d,0x3f
    7c479db082a5:	je     0x7c479db082ca
    7c479db082ab:	mov    r11d,r10d
    7c479db082ae:	shr    r10d,1
    7c479db082b1:	and    r10d,0x1e
    7c479db082b5:	and    r11d,0x1
    7c479db082b9:	or     r10d,r11d
    7c479db082bc:	or     DWORD PTR [r12+0x314],r10d
    7c479db082c4:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db082ca:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db082d0:	lea    rdi,[rsp+0x110]
    7c479db082d8:	lea    rsi,[rsp+0xf0]
    7c479db082e0:	lea    rdx,[rsp+0x100]
    7c479db082e8:	mov    ecx,0x56
    7c479db082ed:	mov    r8d,0x0
    7c479db082f3:	lea    r9,[r12+0x314]
    7c479db082fb:	movabs r11,0x62fe8718e650
    7c479db08305:	call   r11
    7c479db08308:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0830e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db08314:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0831a:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db08320:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db08326:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db08330:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0833a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db08344:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db0834e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db08358:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db08362:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0836a:	mov    QWORD PTR [r12+0x378],0x2
    7c479db08376:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0837f:	mov    rdx,rbx
    7c479db08382:	shr    rdx,0x10
    7c479db08386:	and    edx,0xc000
    7c479db0838c:	mov    rax,rbx
    7c479db0838f:	shr    rax,0x15
    7c479db08393:	and    eax,0x100
    7c479db08398:	xor    eax,0x100
    7c479db0839d:	or     edx,eax
    7c479db0839f:	mov    rax,rbx
    7c479db083a2:	shr    rax,0x1c
    7c479db083a6:	and    eax,0x1
    7c479db083a9:	or     edx,eax
    7c479db083ab:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db083b0:	add    rsp,0x8
    7c479db083b4:	ret
    7c479db083b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db083c0:	sub    rsp,0x8
    7c479db083c4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db083d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db083d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db083dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db083e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db083e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db083ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db083f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db08402:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0840c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db08416:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db08420:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db0842a:	push   rdx
    7c479db0842b:	push   rsi
    7c479db0842c:	push   r10
    7c479db0842e:	push   r11
    7c479db08430:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db08435:	mov    r10d,edx
    7c479db08438:	and    r10d,0xc000
    7c479db0843f:	shl    r10d,0x10
    7c479db08443:	mov    r11d,edx
    7c479db08446:	and    r11d,0x100
    7c479db0844d:	shl    r11d,0x15
    7c479db08451:	or     r10d,r11d
    7c479db08454:	and    edx,0x1
    7c479db08457:	shl    edx,0x1c
    7c479db0845a:	or     r10d,edx
    7c479db0845d:	btc    r10,0x1d
    7c479db08462:	mov    r11d,0xf0000000
    7c479db08468:	and    r11,r10
    7c479db0846b:	movabs rsi,0xffffffff0fffffff
    7c479db08475:	and    rbx,rsi
    7c479db08478:	or     rbx,r11
    7c479db0847b:	pop    r11
    7c479db0847d:	pop    r10
    7c479db0847f:	pop    rsi
    7c479db08480:	pop    rdx
    7c479db08481:	mov    QWORD PTR [r12+0x108],rbx
    7c479db08489:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0848f:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db08494:	test   r10d,0x3f
    7c479db0849b:	je     0x7c479db084c0
    7c479db084a1:	mov    r11d,r10d
    7c479db084a4:	shr    r10d,1
    7c479db084a7:	and    r10d,0x1e
    7c479db084ab:	and    r11d,0x1
    7c479db084af:	or     r10d,r11d
    7c479db084b2:	or     DWORD PTR [r12+0x314],r10d
    7c479db084ba:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db084c0:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db084c6:	lea    rdi,[rsp+0x110]
    7c479db084ce:	lea    rsi,[rsp+0xf0]
    7c479db084d6:	lea    rdx,[rsp+0x100]
    7c479db084de:	mov    ecx,0x14
    7c479db084e3:	mov    r8d,0x0
    7c479db084e9:	lea    r9,[r12+0x314]
    7c479db084f1:	movabs r11,0x62fe8718e650
    7c479db084fb:	call   r11
    7c479db084fe:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db08504:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0850a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db08510:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db08516:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0851c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db08522:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db0852c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db08536:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db08540:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db0854a:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db08554:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db0855e:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db08566:	mov    QWORD PTR [r12+0x378],0x2
    7c479db08572:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0857b:	mov    rdx,rbx
    7c479db0857e:	shr    rdx,0x10
    7c479db08582:	and    edx,0xc000
    7c479db08588:	mov    rax,rbx
    7c479db0858b:	shr    rax,0x15
    7c479db0858f:	and    eax,0x100
    7c479db08594:	xor    eax,0x100
    7c479db08599:	or     edx,eax
    7c479db0859b:	mov    rax,rbx
    7c479db0859e:	shr    rax,0x1c
    7c479db085a2:	and    eax,0x1
    7c479db085a5:	or     edx,eax
    7c479db085a7:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db085ac:	add    rsp,0x8
    7c479db085b0:	ret
    7c479db085b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db085c0:	sub    rsp,0x8
    7c479db085c4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db085d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db085d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db085dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db085e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db085e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db085ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db085f4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db085fe:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db08608:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db08612:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db0861c:	push   rdx
    7c479db0861d:	push   rsi
    7c479db0861e:	push   r10
    7c479db08620:	push   r11
    7c479db08622:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db08627:	mov    r10d,edx
    7c479db0862a:	and    r10d,0xc000
    7c479db08631:	shl    r10d,0x10
    7c479db08635:	mov    r11d,edx
    7c479db08638:	and    r11d,0x100
    7c479db0863f:	shl    r11d,0x15
    7c479db08643:	or     r10d,r11d
    7c479db08646:	and    edx,0x1
    7c479db08649:	shl    edx,0x1c
    7c479db0864c:	or     r10d,edx
    7c479db0864f:	btc    r10,0x1d
    7c479db08654:	mov    r11d,0xf0000000
    7c479db0865a:	and    r11,r10
    7c479db0865d:	movabs rsi,0xffffffff0fffffff
    7c479db08667:	and    rbx,rsi
    7c479db0866a:	or     rbx,r11
    7c479db0866d:	pop    r11
    7c479db0866f:	pop    r10
    7c479db08671:	pop    rsi
    7c479db08672:	pop    rdx
    7c479db08673:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0867b:	stmxcsr DWORD PTR [r12-0x28]
    7c479db08681:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db08686:	test   r10d,0x3f
    7c479db0868d:	je     0x7c479db086b2
    7c479db08693:	mov    r11d,r10d
    7c479db08696:	shr    r10d,1
    7c479db08699:	and    r10d,0x1e
    7c479db0869d:	and    r11d,0x1
    7c479db086a1:	or     r10d,r11d
    7c479db086a4:	or     DWORD PTR [r12+0x314],r10d
    7c479db086ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db086b2:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db086b8:	lea    rdi,[rsp+0x110]
    7c479db086c0:	lea    rsi,[rsp+0xf0]
    7c479db086c8:	lea    rdx,[rsp+0x100]
    7c479db086d0:	mov    ecx,0x56
    7c479db086d5:	mov    r8d,0x0
    7c479db086db:	lea    r9,[r12+0x314]
    7c479db086e3:	movabs r11,0x62fe8718e650
    7c479db086ed:	call   r11
    7c479db086f0:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db086f6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db086fc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db08702:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db08708:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0870e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db08714:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0871a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db08724:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0872e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db08738:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db08742:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0874a:	mov    QWORD PTR [r12+0x378],0x2
    7c479db08756:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0875f:	mov    rdx,rbx
    7c479db08762:	shr    rdx,0x10
    7c479db08766:	and    edx,0xc000
    7c479db0876c:	mov    rax,rbx
    7c479db0876f:	shr    rax,0x15
    7c479db08773:	and    eax,0x100
    7c479db08778:	xor    eax,0x100
    7c479db0877d:	or     edx,eax
    7c479db0877f:	mov    rax,rbx
    7c479db08782:	shr    rax,0x1c
    7c479db08786:	and    eax,0x1
    7c479db08789:	or     edx,eax
    7c479db0878b:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db08790:	add    rsp,0x8
    7c479db08794:	ret
    7c479db08795:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db087a0:	sub    rsp,0x8
    7c479db087a4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db087b0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db087b6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db087bc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db087c2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db087c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db087d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db087dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db087e6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db087f0:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    7c479db087fa:	push   rdx
    7c479db087fb:	push   rsi
    7c479db087fc:	push   r10
    7c479db087fe:	push   r11
    7c479db08800:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db08805:	mov    r10d,edx
    7c479db08808:	and    r10d,0xc000
    7c479db0880f:	shl    r10d,0x10
    7c479db08813:	mov    r11d,edx
    7c479db08816:	and    r11d,0x100
    7c479db0881d:	shl    r11d,0x15
    7c479db08821:	or     r10d,r11d
    7c479db08824:	and    edx,0x1
    7c479db08827:	shl    edx,0x1c
    7c479db0882a:	or     r10d,edx
    7c479db0882d:	btc    r10,0x1d
    7c479db08832:	mov    r11d,0xf0000000
    7c479db08838:	and    r11,r10
    7c479db0883b:	movabs rsi,0xffffffff0fffffff
    7c479db08845:	and    rbx,rsi
    7c479db08848:	or     rbx,r11
    7c479db0884b:	pop    r11
    7c479db0884d:	pop    r10
    7c479db0884f:	pop    rsi
    7c479db08850:	pop    rdx
    7c479db08851:	mov    QWORD PTR [r12+0x108],rbx
    7c479db08859:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0885f:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db08864:	test   r10d,0x3f
    7c479db0886b:	je     0x7c479db08890
    7c479db08871:	mov    r11d,r10d
    7c479db08874:	shr    r10d,1
    7c479db08877:	and    r10d,0x1e
    7c479db0887b:	and    r11d,0x1
    7c479db0887f:	or     r10d,r11d
    7c479db08882:	or     DWORD PTR [r12+0x314],r10d
    7c479db0888a:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db08890:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db08896:	lea    rdi,[rsp+0x110]
    7c479db0889e:	lea    rsi,[rsp+0xf0]
    7c479db088a6:	lea    rdx,[rsp+0x100]
    7c479db088ae:	mov    ecx,0x14
    7c479db088b3:	mov    r8d,0x0
    7c479db088b9:	lea    r9,[r12+0x314]
    7c479db088c1:	movabs r11,0x62fe8718e650
    7c479db088cb:	call   r11
    7c479db088ce:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db088d4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db088da:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db088e0:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db088e6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db088ec:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db088f6:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db08900:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0890a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db08914:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    7c479db0891e:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db08926:	mov    QWORD PTR [r12+0x378],0x2
    7c479db08932:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0893b:	mov    rdx,rbx
    7c479db0893e:	shr    rdx,0x10
    7c479db08942:	and    edx,0xc000
    7c479db08948:	mov    rax,rbx
    7c479db0894b:	shr    rax,0x15
    7c479db0894f:	and    eax,0x100
    7c479db08954:	xor    eax,0x100
    7c479db08959:	or     edx,eax
    7c479db0895b:	mov    rax,rbx
    7c479db0895e:	shr    rax,0x1c
    7c479db08962:	and    eax,0x1
    7c479db08965:	or     edx,eax
    7c479db08967:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0896c:	add    rsp,0x8
    7c479db08970:	ret
    7c479db08971:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db08980:	sub    rsp,0x8
    7c479db08984:	mov    QWORD PTR [r12+0x378],0x3
    7c479db08990:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db08996:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0899c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db089a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db089a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db089ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db089b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db089be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db089c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db089d2:	push   rdx
    7c479db089d3:	push   rsi
    7c479db089d4:	push   r10
    7c479db089d6:	push   r11
    7c479db089d8:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db089dd:	mov    r10d,edx
    7c479db089e0:	and    r10d,0xc000
    7c479db089e7:	shl    r10d,0x10
    7c479db089eb:	mov    r11d,edx
    7c479db089ee:	and    r11d,0x100
    7c479db089f5:	shl    r11d,0x15
    7c479db089f9:	or     r10d,r11d
    7c479db089fc:	and    edx,0x1
    7c479db089ff:	shl    edx,0x1c
    7c479db08a02:	or     r10d,edx
    7c479db08a05:	btc    r10,0x1d
    7c479db08a0a:	mov    r11d,0xf0000000
    7c479db08a10:	and    r11,r10
    7c479db08a13:	movabs rsi,0xffffffff0fffffff
    7c479db08a1d:	and    rbx,rsi
    7c479db08a20:	or     rbx,r11
    7c479db08a23:	pop    r11
    7c479db08a25:	pop    r10
    7c479db08a27:	pop    rsi
    7c479db08a28:	pop    rdx
    7c479db08a29:	mov    QWORD PTR [r12+0x108],rbx
    7c479db08a31:	stmxcsr DWORD PTR [r12-0x28]
    7c479db08a37:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db08a3c:	test   r10d,0x3f
    7c479db08a43:	je     0x7c479db08a68
    7c479db08a49:	mov    r11d,r10d
    7c479db08a4c:	shr    r10d,1
    7c479db08a4f:	and    r10d,0x1e
    7c479db08a53:	and    r11d,0x1
    7c479db08a57:	or     r10d,r11d
    7c479db08a5a:	or     DWORD PTR [r12+0x314],r10d
    7c479db08a62:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db08a68:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db08a6e:	lea    rdi,[rsp+0x110]
    7c479db08a76:	lea    rsi,[rsp+0xf0]
    7c479db08a7e:	lea    rdx,[rsp+0x100]
    7c479db08a86:	mov    ecx,0x56
    7c479db08a8b:	mov    r8d,0x0
    7c479db08a91:	lea    r9,[r12+0x314]
    7c479db08a99:	movabs r11,0x62fe8718e650
    7c479db08aa3:	call   r11
    7c479db08aa6:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db08aac:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db08ab2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db08ab8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db08abe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db08ac4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db08aca:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db08ad0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db08ada:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db08ae4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db08aee:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db08af6:	mov    QWORD PTR [r12+0x378],0x2
    7c479db08b02:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db08b0b:	mov    rdx,rbx
    7c479db08b0e:	shr    rdx,0x10
    7c479db08b12:	and    edx,0xc000
    7c479db08b18:	mov    rax,rbx
    7c479db08b1b:	shr    rax,0x15
    7c479db08b1f:	and    eax,0x100
    7c479db08b24:	xor    eax,0x100
    7c479db08b29:	or     edx,eax
    7c479db08b2b:	mov    rax,rbx
    7c479db08b2e:	shr    rax,0x1c
    7c479db08b32:	and    eax,0x1
    7c479db08b35:	or     edx,eax
    7c479db08b37:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db08b3c:	add    rsp,0x8
    7c479db08b40:	ret
    7c479db08b41:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db08b50:	sub    rsp,0x8
    7c479db08b54:	mov    QWORD PTR [r12+0x378],0x3
    7c479db08b60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db08b66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db08b6c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db08b72:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db08b78:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db08b7e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db08b88:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db08b92:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db08b9c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db08ba6:	push   rdx
    7c479db08ba7:	push   rsi
    7c479db08ba8:	push   r10
    7c479db08baa:	push   r11
    7c479db08bac:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db08bb1:	mov    r10d,edx
    7c479db08bb4:	and    r10d,0xc000
    7c479db08bbb:	shl    r10d,0x10
    7c479db08bbf:	mov    r11d,edx
    7c479db08bc2:	and    r11d,0x100
    7c479db08bc9:	shl    r11d,0x15
    7c479db08bcd:	or     r10d,r11d
    7c479db08bd0:	and    edx,0x1
    7c479db08bd3:	shl    edx,0x1c
    7c479db08bd6:	or     r10d,edx
    7c479db08bd9:	btc    r10,0x1d
    7c479db08bde:	mov    r11d,0xf0000000
    7c479db08be4:	and    r11,r10
    7c479db08be7:	movabs rsi,0xffffffff0fffffff
    7c479db08bf1:	and    rbx,rsi
    7c479db08bf4:	or     rbx,r11
    7c479db08bf7:	pop    r11
    7c479db08bf9:	pop    r10
    7c479db08bfb:	pop    rsi
    7c479db08bfc:	pop    rdx
    7c479db08bfd:	mov    QWORD PTR [r12+0x108],rbx
    7c479db08c05:	stmxcsr DWORD PTR [r12-0x28]
    7c479db08c0b:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db08c10:	test   r10d,0x3f
    7c479db08c17:	je     0x7c479db08c3c
    7c479db08c1d:	mov    r11d,r10d
    7c479db08c20:	shr    r10d,1
    7c479db08c23:	and    r10d,0x1e
    7c479db08c27:	and    r11d,0x1
    7c479db08c2b:	or     r10d,r11d
    7c479db08c2e:	or     DWORD PTR [r12+0x314],r10d
    7c479db08c36:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db08c3c:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db08c42:	lea    rdi,[rsp+0x110]
    7c479db08c4a:	lea    rsi,[rsp+0xf0]
    7c479db08c52:	lea    rdx,[rsp+0x100]
    7c479db08c5a:	mov    ecx,0x56
    7c479db08c5f:	mov    r8d,0x0
    7c479db08c65:	lea    r9,[r12+0x314]
    7c479db08c6d:	movabs r11,0x62fe8718e650
    7c479db08c77:	call   r11
    7c479db08c7a:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db08c80:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db08c86:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db08c8c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db08c92:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db08c98:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db08c9e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db08ca8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db08cb2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db08cbc:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db08cc6:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db08cce:	mov    QWORD PTR [r12+0x378],0x2
    7c479db08cda:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db08ce3:	mov    rdx,rbx
    7c479db08ce6:	shr    rdx,0x10
    7c479db08cea:	and    edx,0xc000
    7c479db08cf0:	mov    rax,rbx
    7c479db08cf3:	shr    rax,0x15
    7c479db08cf7:	and    eax,0x100
    7c479db08cfc:	xor    eax,0x100
    7c479db08d01:	or     edx,eax
    7c479db08d03:	mov    rax,rbx
    7c479db08d06:	shr    rax,0x1c
    7c479db08d0a:	and    eax,0x1
    7c479db08d0d:	or     edx,eax
    7c479db08d0f:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db08d14:	add    rsp,0x8
    7c479db08d18:	ret
    7c479db08d19:	nop    DWORD PTR [rax+0x0]
    7c479db08d20:	sub    rsp,0x8
    7c479db08d24:	mov    QWORD PTR [r12+0x378],0x3
    7c479db08d30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db08d36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db08d3c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db08d42:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db08d48:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db08d4e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db08d54:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db08d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db08d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db08d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db08d7c:	push   rdx
    7c479db08d7d:	push   rsi
    7c479db08d7e:	push   r10
    7c479db08d80:	push   r11
    7c479db08d82:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db08d87:	mov    r10d,edx
    7c479db08d8a:	and    r10d,0xc000
    7c479db08d91:	shl    r10d,0x10
    7c479db08d95:	mov    r11d,edx
    7c479db08d98:	and    r11d,0x100
    7c479db08d9f:	shl    r11d,0x15
    7c479db08da3:	or     r10d,r11d
    7c479db08da6:	and    edx,0x1
    7c479db08da9:	shl    edx,0x1c
    7c479db08dac:	or     r10d,edx
    7c479db08daf:	btc    r10,0x1d
    7c479db08db4:	mov    r11d,0xf0000000
    7c479db08dba:	and    r11,r10
    7c479db08dbd:	movabs rsi,0xffffffff0fffffff
    7c479db08dc7:	and    rbx,rsi
    7c479db08dca:	or     rbx,r11
    7c479db08dcd:	pop    r11
    7c479db08dcf:	pop    r10
    7c479db08dd1:	pop    rsi
    7c479db08dd2:	pop    rdx
    7c479db08dd3:	mov    QWORD PTR [r12+0x108],rbx
    7c479db08ddb:	stmxcsr DWORD PTR [r12-0x28]
    7c479db08de1:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db08de6:	test   r10d,0x3f
    7c479db08ded:	je     0x7c479db08e12
    7c479db08df3:	mov    r11d,r10d
    7c479db08df6:	shr    r10d,1
    7c479db08df9:	and    r10d,0x1e
    7c479db08dfd:	and    r11d,0x1
    7c479db08e01:	or     r10d,r11d
    7c479db08e04:	or     DWORD PTR [r12+0x314],r10d
    7c479db08e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db08e12:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db08e18:	lea    rdi,[rsp+0x110]
    7c479db08e20:	lea    rsi,[rsp+0xf0]
    7c479db08e28:	lea    rdx,[rsp+0x100]
    7c479db08e30:	mov    ecx,0x14
    7c479db08e35:	mov    r8d,0x0
    7c479db08e3b:	lea    r9,[r12+0x314]
    7c479db08e43:	movabs r11,0x62fe8718e650
    7c479db08e4d:	call   r11
    7c479db08e50:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db08e56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db08e5c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db08e62:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db08e68:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db08e6e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db08e74:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db08e7a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db08e84:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db08e8e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db08e98:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db08ea2:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db08eaa:	mov    QWORD PTR [r12+0x378],0x2
    7c479db08eb6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db08ebf:	mov    rdx,rbx
    7c479db08ec2:	shr    rdx,0x10
    7c479db08ec6:	and    edx,0xc000
    7c479db08ecc:	mov    rax,rbx
    7c479db08ecf:	shr    rax,0x15
    7c479db08ed3:	and    eax,0x100
    7c479db08ed8:	xor    eax,0x100
    7c479db08edd:	or     edx,eax
    7c479db08edf:	mov    rax,rbx
    7c479db08ee2:	shr    rax,0x1c
    7c479db08ee6:	and    eax,0x1
    7c479db08ee9:	or     edx,eax
    7c479db08eeb:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db08ef0:	add    rsp,0x8
    7c479db08ef4:	ret
    7c479db08ef5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db08f00:	sub    rsp,0x8
    7c479db08f04:	mov    QWORD PTR [r12+0x378],0x3
    7c479db08f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db08f16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db08f1c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db08f22:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db08f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db08f2e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db08f38:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db08f42:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db08f4c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db08f56:	push   rdx
    7c479db08f57:	push   rsi
    7c479db08f58:	push   r10
    7c479db08f5a:	push   r11
    7c479db08f5c:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db08f61:	mov    r10d,edx
    7c479db08f64:	and    r10d,0xc000
    7c479db08f6b:	shl    r10d,0x10
    7c479db08f6f:	mov    r11d,edx
    7c479db08f72:	and    r11d,0x100
    7c479db08f79:	shl    r11d,0x15
    7c479db08f7d:	or     r10d,r11d
    7c479db08f80:	and    edx,0x1
    7c479db08f83:	shl    edx,0x1c
    7c479db08f86:	or     r10d,edx
    7c479db08f89:	btc    r10,0x1d
    7c479db08f8e:	mov    r11d,0xf0000000
    7c479db08f94:	and    r11,r10
    7c479db08f97:	movabs rsi,0xffffffff0fffffff
    7c479db08fa1:	and    rbx,rsi
    7c479db08fa4:	or     rbx,r11
    7c479db08fa7:	pop    r11
    7c479db08fa9:	pop    r10
    7c479db08fab:	pop    rsi
    7c479db08fac:	pop    rdx
    7c479db08fad:	mov    QWORD PTR [r12+0x108],rbx
    7c479db08fb5:	stmxcsr DWORD PTR [r12-0x28]
    7c479db08fbb:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db08fc0:	test   r10d,0x3f
    7c479db08fc7:	je     0x7c479db08fec
    7c479db08fcd:	mov    r11d,r10d
    7c479db08fd0:	shr    r10d,1
    7c479db08fd3:	and    r10d,0x1e
    7c479db08fd7:	and    r11d,0x1
    7c479db08fdb:	or     r10d,r11d
    7c479db08fde:	or     DWORD PTR [r12+0x314],r10d
    7c479db08fe6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db08fec:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db08ff2:	lea    rdi,[rsp+0x110]
    7c479db08ffa:	lea    rsi,[rsp+0xf0]
    7c479db09002:	lea    rdx,[rsp+0x100]
    7c479db0900a:	mov    ecx,0x14
    7c479db0900f:	mov    r8d,0x0
    7c479db09015:	lea    r9,[r12+0x314]
    7c479db0901d:	movabs r11,0x62fe8718e650
    7c479db09027:	call   r11
    7c479db0902a:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db09030:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db09036:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0903c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db09042:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db09048:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0904e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db09058:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db09062:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db0906c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db09076:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0907e:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0908a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db09093:	mov    rdx,rbx
    7c479db09096:	shr    rdx,0x10
    7c479db0909a:	and    edx,0xc000
    7c479db090a0:	mov    rax,rbx
    7c479db090a3:	shr    rax,0x15
    7c479db090a7:	and    eax,0x100
    7c479db090ac:	xor    eax,0x100
    7c479db090b1:	or     edx,eax
    7c479db090b3:	mov    rax,rbx
    7c479db090b6:	shr    rax,0x1c
    7c479db090ba:	and    eax,0x1
    7c479db090bd:	or     edx,eax
    7c479db090bf:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db090c4:	add    rsp,0x8
    7c479db090c8:	ret
    7c479db090c9:	nop    DWORD PTR [rax+0x0]
    7c479db090d0:	sub    rsp,0x8
    7c479db090d4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db090e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db090e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db090ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db090f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db090f8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db090fe:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db09108:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db09112:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db0911c:	push   rdx
    7c479db0911d:	push   rsi
    7c479db0911e:	push   r10
    7c479db09120:	push   r11
    7c479db09122:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db09127:	mov    r10d,edx
    7c479db0912a:	and    r10d,0xc000
    7c479db09131:	shl    r10d,0x10
    7c479db09135:	mov    r11d,edx
    7c479db09138:	and    r11d,0x100
    7c479db0913f:	shl    r11d,0x15
    7c479db09143:	or     r10d,r11d
    7c479db09146:	and    edx,0x1
    7c479db09149:	shl    edx,0x1c
    7c479db0914c:	or     r10d,edx
    7c479db0914f:	btc    r10,0x1d
    7c479db09154:	mov    r11d,0xf0000000
    7c479db0915a:	and    r11,r10
    7c479db0915d:	movabs rsi,0xffffffff0fffffff
    7c479db09167:	and    rbx,rsi
    7c479db0916a:	or     rbx,r11
    7c479db0916d:	pop    r11
    7c479db0916f:	pop    r10
    7c479db09171:	pop    rsi
    7c479db09172:	pop    rdx
    7c479db09173:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0917b:	stmxcsr DWORD PTR [r12-0x28]
    7c479db09181:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db09186:	test   r10d,0x3f
    7c479db0918d:	je     0x7c479db091b2
    7c479db09193:	mov    r11d,r10d
    7c479db09196:	shr    r10d,1
    7c479db09199:	and    r10d,0x1e
    7c479db0919d:	and    r11d,0x1
    7c479db091a1:	or     r10d,r11d
    7c479db091a4:	or     DWORD PTR [r12+0x314],r10d
    7c479db091ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db091b2:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db091b8:	lea    rdi,[rsp+0x110]
    7c479db091c0:	lea    rsi,[rsp+0xf0]
    7c479db091c8:	lea    rdx,[rsp+0x100]
    7c479db091d0:	mov    ecx,0x56
    7c479db091d5:	mov    r8d,0x0
    7c479db091db:	lea    r9,[r12+0x314]
    7c479db091e3:	movabs r11,0x62fe8718e650
    7c479db091ed:	call   r11
    7c479db091f0:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db091f6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db091fc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db09202:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db09208:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0920e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db09214:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0921e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db09228:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db09232:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0923a:	mov    QWORD PTR [r12+0x378],0x2
    7c479db09246:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0924f:	mov    rdx,rbx
    7c479db09252:	shr    rdx,0x10
    7c479db09256:	and    edx,0xc000
    7c479db0925c:	mov    rax,rbx
    7c479db0925f:	shr    rax,0x15
    7c479db09263:	and    eax,0x100
    7c479db09268:	xor    eax,0x100
    7c479db0926d:	or     edx,eax
    7c479db0926f:	mov    rax,rbx
    7c479db09272:	shr    rax,0x1c
    7c479db09276:	and    eax,0x1
    7c479db09279:	or     edx,eax
    7c479db0927b:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db09280:	add    rsp,0x8
    7c479db09284:	ret
    7c479db09285:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db09290:	sub    rsp,0x8
    7c479db09294:	mov    QWORD PTR [r12+0x378],0x3
    7c479db092a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db092a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db092ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db092b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db092b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db092be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db092c4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db092ce:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db092d8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db092e2:	push   rdx
    7c479db092e3:	push   rsi
    7c479db092e4:	push   r10
    7c479db092e6:	push   r11
    7c479db092e8:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db092ed:	mov    r10d,edx
    7c479db092f0:	and    r10d,0xc000
    7c479db092f7:	shl    r10d,0x10
    7c479db092fb:	mov    r11d,edx
    7c479db092fe:	and    r11d,0x100
    7c479db09305:	shl    r11d,0x15
    7c479db09309:	or     r10d,r11d
    7c479db0930c:	and    edx,0x1
    7c479db0930f:	shl    edx,0x1c
    7c479db09312:	or     r10d,edx
    7c479db09315:	btc    r10,0x1d
    7c479db0931a:	mov    r11d,0xf0000000
    7c479db09320:	and    r11,r10
    7c479db09323:	movabs rsi,0xffffffff0fffffff
    7c479db0932d:	and    rbx,rsi
    7c479db09330:	or     rbx,r11
    7c479db09333:	pop    r11
    7c479db09335:	pop    r10
    7c479db09337:	pop    rsi
    7c479db09338:	pop    rdx
    7c479db09339:	mov    QWORD PTR [r12+0x108],rbx
    7c479db09341:	stmxcsr DWORD PTR [r12-0x28]
    7c479db09347:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0934c:	test   r10d,0x3f
    7c479db09353:	je     0x7c479db09378
    7c479db09359:	mov    r11d,r10d
    7c479db0935c:	shr    r10d,1
    7c479db0935f:	and    r10d,0x1e
    7c479db09363:	and    r11d,0x1
    7c479db09367:	or     r10d,r11d
    7c479db0936a:	or     DWORD PTR [r12+0x314],r10d
    7c479db09372:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db09378:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0937e:	lea    rdi,[rsp+0x110]
    7c479db09386:	lea    rsi,[rsp+0xf0]
    7c479db0938e:	lea    rdx,[rsp+0x100]
    7c479db09396:	mov    ecx,0x56
    7c479db0939b:	mov    r8d,0x0
    7c479db093a1:	lea    r9,[r12+0x314]
    7c479db093a9:	movabs r11,0x62fe8718e650
    7c479db093b3:	call   r11
    7c479db093b6:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db093bc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db093c2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db093c8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db093ce:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db093d4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db093da:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db093e0:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db093ea:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db093f4:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db093fe:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db09406:	mov    QWORD PTR [r12+0x378],0x2
    7c479db09412:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0941b:	mov    rdx,rbx
    7c479db0941e:	shr    rdx,0x10
    7c479db09422:	and    edx,0xc000
    7c479db09428:	mov    rax,rbx
    7c479db0942b:	shr    rax,0x15
    7c479db0942f:	and    eax,0x100
    7c479db09434:	xor    eax,0x100
    7c479db09439:	or     edx,eax
    7c479db0943b:	mov    rax,rbx
    7c479db0943e:	shr    rax,0x1c
    7c479db09442:	and    eax,0x1
    7c479db09445:	or     edx,eax
    7c479db09447:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0944c:	add    rsp,0x8
    7c479db09450:	ret
    7c479db09451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db09460:	sub    rsp,0x8
    7c479db09464:	mov    QWORD PTR [r12+0x378],0x3
    7c479db09470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db09476:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0947c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db09482:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db09488:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0948e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db09498:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db094a2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db094ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db094b6:	push   rdx
    7c479db094b7:	push   rsi
    7c479db094b8:	push   r10
    7c479db094ba:	push   r11
    7c479db094bc:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db094c1:	mov    r10d,edx
    7c479db094c4:	and    r10d,0xc000
    7c479db094cb:	shl    r10d,0x10
    7c479db094cf:	mov    r11d,edx
    7c479db094d2:	and    r11d,0x100
    7c479db094d9:	shl    r11d,0x15
    7c479db094dd:	or     r10d,r11d
    7c479db094e0:	and    edx,0x1
    7c479db094e3:	shl    edx,0x1c
    7c479db094e6:	or     r10d,edx
    7c479db094e9:	btc    r10,0x1d
    7c479db094ee:	mov    r11d,0xf0000000
    7c479db094f4:	and    r11,r10
    7c479db094f7:	movabs rsi,0xffffffff0fffffff
    7c479db09501:	and    rbx,rsi
    7c479db09504:	or     rbx,r11
    7c479db09507:	pop    r11
    7c479db09509:	pop    r10
    7c479db0950b:	pop    rsi
    7c479db0950c:	pop    rdx
    7c479db0950d:	mov    QWORD PTR [r12+0x108],rbx
    7c479db09515:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0951b:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db09520:	test   r10d,0x3f
    7c479db09527:	je     0x7c479db0954c
    7c479db0952d:	mov    r11d,r10d
    7c479db09530:	shr    r10d,1
    7c479db09533:	and    r10d,0x1e
    7c479db09537:	and    r11d,0x1
    7c479db0953b:	or     r10d,r11d
    7c479db0953e:	or     DWORD PTR [r12+0x314],r10d
    7c479db09546:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0954c:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db09552:	lea    rdi,[rsp+0x110]
    7c479db0955a:	lea    rsi,[rsp+0xf0]
    7c479db09562:	lea    rdx,[rsp+0x100]
    7c479db0956a:	mov    ecx,0x14
    7c479db0956f:	mov    r8d,0x0
    7c479db09575:	lea    r9,[r12+0x314]
    7c479db0957d:	movabs r11,0x62fe8718e650
    7c479db09587:	call   r11
    7c479db0958a:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db09590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db09596:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0959c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db095a2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db095a8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db095ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db095b8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db095c2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db095cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db095d6:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db095de:	mov    QWORD PTR [r12+0x378],0x2
    7c479db095ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db095f3:	mov    rdx,rbx
    7c479db095f6:	shr    rdx,0x10
    7c479db095fa:	and    edx,0xc000
    7c479db09600:	mov    rax,rbx
    7c479db09603:	shr    rax,0x15
    7c479db09607:	and    eax,0x100
    7c479db0960c:	xor    eax,0x100
    7c479db09611:	or     edx,eax
    7c479db09613:	mov    rax,rbx
    7c479db09616:	shr    rax,0x1c
    7c479db0961a:	and    eax,0x1
    7c479db0961d:	or     edx,eax
    7c479db0961f:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db09624:	add    rsp,0x8
    7c479db09628:	ret
    7c479db09629:	nop    DWORD PTR [rax+0x0]
    7c479db09630:	sub    rsp,0x8
    7c479db09634:	mov    QWORD PTR [r12+0x378],0x3
    7c479db09640:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db09646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0964c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db09652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db09658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db0965e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db09668:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db09672:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db0967c:	push   rdx
    7c479db0967d:	push   rsi
    7c479db0967e:	push   r10
    7c479db09680:	push   r11
    7c479db09682:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db09687:	mov    r10d,edx
    7c479db0968a:	and    r10d,0xc000
    7c479db09691:	shl    r10d,0x10
    7c479db09695:	mov    r11d,edx
    7c479db09698:	and    r11d,0x100
    7c479db0969f:	shl    r11d,0x15
    7c479db096a3:	or     r10d,r11d
    7c479db096a6:	and    edx,0x1
    7c479db096a9:	shl    edx,0x1c
    7c479db096ac:	or     r10d,edx
    7c479db096af:	btc    r10,0x1d
    7c479db096b4:	mov    r11d,0xf0000000
    7c479db096ba:	and    r11,r10
    7c479db096bd:	movabs rsi,0xffffffff0fffffff
    7c479db096c7:	and    rbx,rsi
    7c479db096ca:	or     rbx,r11
    7c479db096cd:	pop    r11
    7c479db096cf:	pop    r10
    7c479db096d1:	pop    rsi
    7c479db096d2:	pop    rdx
    7c479db096d3:	mov    QWORD PTR [r12+0x108],rbx
    7c479db096db:	stmxcsr DWORD PTR [r12-0x28]
    7c479db096e1:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db096e6:	test   r10d,0x3f
    7c479db096ed:	je     0x7c479db09712
    7c479db096f3:	mov    r11d,r10d
    7c479db096f6:	shr    r10d,1
    7c479db096f9:	and    r10d,0x1e
    7c479db096fd:	and    r11d,0x1
    7c479db09701:	or     r10d,r11d
    7c479db09704:	or     DWORD PTR [r12+0x314],r10d
    7c479db0970c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db09712:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db09718:	lea    rdi,[rsp+0x110]
    7c479db09720:	lea    rsi,[rsp+0xf0]
    7c479db09728:	lea    rdx,[rsp+0x100]
    7c479db09730:	mov    ecx,0x14
    7c479db09735:	mov    r8d,0x0
    7c479db0973b:	lea    r9,[r12+0x314]
    7c479db09743:	movabs r11,0x62fe8718e650
    7c479db0974d:	call   r11
    7c479db09750:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db09756:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0975c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db09762:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db09768:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0976e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db09774:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db0977e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db09788:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db09792:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0979a:	mov    QWORD PTR [r12+0x378],0x2
    7c479db097a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db097af:	mov    rdx,rbx
    7c479db097b2:	shr    rdx,0x10
    7c479db097b6:	and    edx,0xc000
    7c479db097bc:	mov    rax,rbx
    7c479db097bf:	shr    rax,0x15
    7c479db097c3:	and    eax,0x100
    7c479db097c8:	xor    eax,0x100
    7c479db097cd:	or     edx,eax
    7c479db097cf:	mov    rax,rbx
    7c479db097d2:	shr    rax,0x1c
    7c479db097d6:	and    eax,0x1
    7c479db097d9:	or     edx,eax
    7c479db097db:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db097e0:	add    rsp,0x8
    7c479db097e4:	ret
    7c479db097e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db097f0:	sub    rsp,0x8
    7c479db097f4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db09800:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db09806:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0980c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db09812:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db09818:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0981e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db09824:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db0982e:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db09838:	push   rdx
    7c479db09839:	push   rsi
    7c479db0983a:	push   r10
    7c479db0983c:	push   r11
    7c479db0983e:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db09843:	mov    r10d,edx
    7c479db09846:	and    r10d,0xc000
    7c479db0984d:	shl    r10d,0x10
    7c479db09851:	mov    r11d,edx
    7c479db09854:	and    r11d,0x100
    7c479db0985b:	shl    r11d,0x15
    7c479db0985f:	or     r10d,r11d
    7c479db09862:	and    edx,0x1
    7c479db09865:	shl    edx,0x1c
    7c479db09868:	or     r10d,edx
    7c479db0986b:	btc    r10,0x1d
    7c479db09870:	mov    r11d,0xf0000000
    7c479db09876:	and    r11,r10
    7c479db09879:	movabs rsi,0xffffffff0fffffff
    7c479db09883:	and    rbx,rsi
    7c479db09886:	or     rbx,r11
    7c479db09889:	pop    r11
    7c479db0988b:	pop    r10
    7c479db0988d:	pop    rsi
    7c479db0988e:	pop    rdx
    7c479db0988f:	mov    QWORD PTR [r12+0x108],rbx
    7c479db09897:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0989d:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db098a2:	test   r10d,0x3f
    7c479db098a9:	je     0x7c479db098ce
    7c479db098af:	mov    r11d,r10d
    7c479db098b2:	shr    r10d,1
    7c479db098b5:	and    r10d,0x1e
    7c479db098b9:	and    r11d,0x1
    7c479db098bd:	or     r10d,r11d
    7c479db098c0:	or     DWORD PTR [r12+0x314],r10d
    7c479db098c8:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db098ce:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db098d4:	lea    rdi,[rsp+0x110]
    7c479db098dc:	lea    rsi,[rsp+0xf0]
    7c479db098e4:	lea    rdx,[rsp+0x100]
    7c479db098ec:	mov    ecx,0x56
    7c479db098f1:	mov    r8d,0x0
    7c479db098f7:	lea    r9,[r12+0x314]
    7c479db098ff:	movabs r11,0x62fe8718e650
    7c479db09909:	call   r11
    7c479db0990c:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db09912:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db09918:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0991e:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db09924:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0992a:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db09930:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db09936:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db09940:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0994a:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db09952:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0995e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db09967:	mov    rdx,rbx
    7c479db0996a:	shr    rdx,0x10
    7c479db0996e:	and    edx,0xc000
    7c479db09974:	mov    rax,rbx
    7c479db09977:	shr    rax,0x15
    7c479db0997b:	and    eax,0x100
    7c479db09980:	xor    eax,0x100
    7c479db09985:	or     edx,eax
    7c479db09987:	mov    rax,rbx
    7c479db0998a:	shr    rax,0x1c
    7c479db0998e:	and    eax,0x1
    7c479db09991:	or     edx,eax
    7c479db09993:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db09998:	add    rsp,0x8
    7c479db0999c:	ret
    7c479db0999d:	nop    DWORD PTR [rax]
    7c479db099a0:	sub    rsp,0x8
    7c479db099a4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db099b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db099b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db099bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db099c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db099c8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db099ce:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db099d4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db099de:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db099e8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db099f2:	push   rdx
    7c479db099f3:	push   rsi
    7c479db099f4:	push   r10
    7c479db099f6:	push   r11
    7c479db099f8:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db099fd:	mov    r10d,edx
    7c479db09a00:	and    r10d,0xc000
    7c479db09a07:	shl    r10d,0x10
    7c479db09a0b:	mov    r11d,edx
    7c479db09a0e:	and    r11d,0x100
    7c479db09a15:	shl    r11d,0x15
    7c479db09a19:	or     r10d,r11d
    7c479db09a1c:	and    edx,0x1
    7c479db09a1f:	shl    edx,0x1c
    7c479db09a22:	or     r10d,edx
    7c479db09a25:	btc    r10,0x1d
    7c479db09a2a:	mov    r11d,0xf0000000
    7c479db09a30:	and    r11,r10
    7c479db09a33:	movabs rsi,0xffffffff0fffffff
    7c479db09a3d:	and    rbx,rsi
    7c479db09a40:	or     rbx,r11
    7c479db09a43:	pop    r11
    7c479db09a45:	pop    r10
    7c479db09a47:	pop    rsi
    7c479db09a48:	pop    rdx
    7c479db09a49:	mov    QWORD PTR [r12+0x108],rbx
    7c479db09a51:	stmxcsr DWORD PTR [r12-0x28]
    7c479db09a57:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db09a5c:	test   r10d,0x3f
    7c479db09a63:	je     0x7c479db09a88
    7c479db09a69:	mov    r11d,r10d
    7c479db09a6c:	shr    r10d,1
    7c479db09a6f:	and    r10d,0x1e
    7c479db09a73:	and    r11d,0x1
    7c479db09a77:	or     r10d,r11d
    7c479db09a7a:	or     DWORD PTR [r12+0x314],r10d
    7c479db09a82:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db09a88:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db09a8e:	lea    rdi,[rsp+0x110]
    7c479db09a96:	lea    rsi,[rsp+0xf0]
    7c479db09a9e:	lea    rdx,[rsp+0x100]
    7c479db09aa6:	mov    ecx,0x14
    7c479db09aab:	mov    r8d,0x0
    7c479db09ab1:	lea    r9,[r12+0x314]
    7c479db09ab9:	movabs r11,0x62fe8718e650
    7c479db09ac3:	call   r11
    7c479db09ac6:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db09acc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db09ad2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db09ad8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db09ade:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db09ae4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db09aea:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db09af0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db09afa:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db09b04:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db09b0e:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db09b16:	mov    QWORD PTR [r12+0x378],0x2
    7c479db09b22:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db09b2b:	mov    rdx,rbx
    7c479db09b2e:	shr    rdx,0x10
    7c479db09b32:	and    edx,0xc000
    7c479db09b38:	mov    rax,rbx
    7c479db09b3b:	shr    rax,0x15
    7c479db09b3f:	and    eax,0x100
    7c479db09b44:	xor    eax,0x100
    7c479db09b49:	or     edx,eax
    7c479db09b4b:	mov    rax,rbx
    7c479db09b4e:	shr    rax,0x1c
    7c479db09b52:	and    eax,0x1
    7c479db09b55:	or     edx,eax
    7c479db09b57:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db09b5c:	add    rsp,0x8
    7c479db09b60:	ret
    7c479db09b61:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db09b70:	sub    rsp,0x8
    7c479db09b74:	mov    QWORD PTR [r12+0x378],0x3
    7c479db09b80:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db09b86:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db09b8c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db09b92:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db09b98:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db09ba2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db09bac:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db09bb6:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db09bc0:	push   rdx
    7c479db09bc1:	push   rsi
    7c479db09bc2:	push   r10
    7c479db09bc4:	push   r11
    7c479db09bc6:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db09bcb:	mov    r10d,edx
    7c479db09bce:	and    r10d,0xc000
    7c479db09bd5:	shl    r10d,0x10
    7c479db09bd9:	mov    r11d,edx
    7c479db09bdc:	and    r11d,0x100
    7c479db09be3:	shl    r11d,0x15
    7c479db09be7:	or     r10d,r11d
    7c479db09bea:	and    edx,0x1
    7c479db09bed:	shl    edx,0x1c
    7c479db09bf0:	or     r10d,edx
    7c479db09bf3:	btc    r10,0x1d
    7c479db09bf8:	mov    r11d,0xf0000000
    7c479db09bfe:	and    r11,r10
    7c479db09c01:	movabs rsi,0xffffffff0fffffff
    7c479db09c0b:	and    rbx,rsi
    7c479db09c0e:	or     rbx,r11
    7c479db09c11:	pop    r11
    7c479db09c13:	pop    r10
    7c479db09c15:	pop    rsi
    7c479db09c16:	pop    rdx
    7c479db09c17:	mov    QWORD PTR [r12+0x108],rbx
    7c479db09c1f:	stmxcsr DWORD PTR [r12-0x28]
    7c479db09c25:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db09c2a:	test   r10d,0x3f
    7c479db09c31:	je     0x7c479db09c56
    7c479db09c37:	mov    r11d,r10d
    7c479db09c3a:	shr    r10d,1
    7c479db09c3d:	and    r10d,0x1e
    7c479db09c41:	and    r11d,0x1
    7c479db09c45:	or     r10d,r11d
    7c479db09c48:	or     DWORD PTR [r12+0x314],r10d
    7c479db09c50:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db09c56:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db09c5c:	lea    rdi,[rsp+0x110]
    7c479db09c64:	lea    rsi,[rsp+0xf0]
    7c479db09c6c:	lea    rdx,[rsp+0x100]
    7c479db09c74:	mov    ecx,0x14
    7c479db09c79:	mov    r8d,0x0
    7c479db09c7f:	lea    r9,[r12+0x314]
    7c479db09c87:	movabs r11,0x62fe8718e650
    7c479db09c91:	call   r11
    7c479db09c94:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db09c9a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db09ca0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db09ca6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db09cac:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db09cb2:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db09cbc:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db09cc6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db09cd0:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db09cda:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db09ce2:	mov    QWORD PTR [r12+0x378],0x2
    7c479db09cee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db09cf7:	mov    rdx,rbx
    7c479db09cfa:	shr    rdx,0x10
    7c479db09cfe:	and    edx,0xc000
    7c479db09d04:	mov    rax,rbx
    7c479db09d07:	shr    rax,0x15
    7c479db09d0b:	and    eax,0x100
    7c479db09d10:	xor    eax,0x100
    7c479db09d15:	or     edx,eax
    7c479db09d17:	mov    rax,rbx
    7c479db09d1a:	shr    rax,0x1c
    7c479db09d1e:	and    eax,0x1
    7c479db09d21:	or     edx,eax
    7c479db09d23:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db09d28:	add    rsp,0x8
    7c479db09d2c:	ret
    7c479db09d2d:	nop    DWORD PTR [rax]
    7c479db09d30:	sub    rsp,0x8
    7c479db09d34:	mov    QWORD PTR [r12+0x378],0x3
    7c479db09d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db09d46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db09d4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db09d52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db09d58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db09d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db09d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db09d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db09d7c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db09d86:	push   rdx
    7c479db09d87:	push   rsi
    7c479db09d88:	push   r10
    7c479db09d8a:	push   r11
    7c479db09d8c:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db09d91:	mov    r10d,edx
    7c479db09d94:	and    r10d,0xc000
    7c479db09d9b:	shl    r10d,0x10
    7c479db09d9f:	mov    r11d,edx
    7c479db09da2:	and    r11d,0x100
    7c479db09da9:	shl    r11d,0x15
    7c479db09dad:	or     r10d,r11d
    7c479db09db0:	and    edx,0x1
    7c479db09db3:	shl    edx,0x1c
    7c479db09db6:	or     r10d,edx
    7c479db09db9:	btc    r10,0x1d
    7c479db09dbe:	mov    r11d,0xf0000000
    7c479db09dc4:	and    r11,r10
    7c479db09dc7:	movabs rsi,0xffffffff0fffffff
    7c479db09dd1:	and    rbx,rsi
    7c479db09dd4:	or     rbx,r11
    7c479db09dd7:	pop    r11
    7c479db09dd9:	pop    r10
    7c479db09ddb:	pop    rsi
    7c479db09ddc:	pop    rdx
    7c479db09ddd:	mov    QWORD PTR [r12+0x108],rbx
    7c479db09de5:	stmxcsr DWORD PTR [r12-0x28]
    7c479db09deb:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db09df0:	test   r10d,0x3f
    7c479db09df7:	je     0x7c479db09e1c
    7c479db09dfd:	mov    r11d,r10d
    7c479db09e00:	shr    r10d,1
    7c479db09e03:	and    r10d,0x1e
    7c479db09e07:	and    r11d,0x1
    7c479db09e0b:	or     r10d,r11d
    7c479db09e0e:	or     DWORD PTR [r12+0x314],r10d
    7c479db09e16:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db09e1c:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db09e22:	lea    rdi,[rsp+0x110]
    7c479db09e2a:	lea    rsi,[rsp+0xf0]
    7c479db09e32:	lea    rdx,[rsp+0x100]
    7c479db09e3a:	mov    ecx,0x14
    7c479db09e3f:	mov    r8d,0x0
    7c479db09e45:	lea    r9,[r12+0x314]
    7c479db09e4d:	movabs r11,0x62fe8718e650
    7c479db09e57:	call   r11
    7c479db09e5a:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db09e60:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db09e66:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db09e6c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db09e72:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db09e78:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db09e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db09e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db09e92:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db09e9c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db09ea6:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db09eae:	mov    QWORD PTR [r12+0x378],0x2
    7c479db09eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db09ec3:	mov    rdx,rbx
    7c479db09ec6:	shr    rdx,0x10
    7c479db09eca:	and    edx,0xc000
    7c479db09ed0:	mov    rax,rbx
    7c479db09ed3:	shr    rax,0x15
    7c479db09ed7:	and    eax,0x100
    7c479db09edc:	xor    eax,0x100
    7c479db09ee1:	or     edx,eax
    7c479db09ee3:	mov    rax,rbx
    7c479db09ee6:	shr    rax,0x1c
    7c479db09eea:	and    eax,0x1
    7c479db09eed:	or     edx,eax
    7c479db09eef:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db09ef4:	add    rsp,0x8
    7c479db09ef8:	ret
    7c479db09ef9:	nop    DWORD PTR [rax+0x0]
    7c479db09f00:	sub    rsp,0x8
    7c479db09f04:	mov    QWORD PTR [r12+0x378],0x3
    7c479db09f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db09f16:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db09f1c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db09f22:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db09f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db09f2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db09f38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db09f42:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db09f4c:	push   rdx
    7c479db09f4d:	push   rsi
    7c479db09f4e:	push   r10
    7c479db09f50:	push   r11
    7c479db09f52:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db09f57:	mov    r10d,edx
    7c479db09f5a:	and    r10d,0xc000
    7c479db09f61:	shl    r10d,0x10
    7c479db09f65:	mov    r11d,edx
    7c479db09f68:	and    r11d,0x100
    7c479db09f6f:	shl    r11d,0x15
    7c479db09f73:	or     r10d,r11d
    7c479db09f76:	and    edx,0x1
    7c479db09f79:	shl    edx,0x1c
    7c479db09f7c:	or     r10d,edx
    7c479db09f7f:	btc    r10,0x1d
    7c479db09f84:	mov    r11d,0xf0000000
    7c479db09f8a:	and    r11,r10
    7c479db09f8d:	movabs rsi,0xffffffff0fffffff
    7c479db09f97:	and    rbx,rsi
    7c479db09f9a:	or     rbx,r11
    7c479db09f9d:	pop    r11
    7c479db09f9f:	pop    r10
    7c479db09fa1:	pop    rsi
    7c479db09fa2:	pop    rdx
    7c479db09fa3:	mov    QWORD PTR [r12+0x108],rbx
    7c479db09fab:	stmxcsr DWORD PTR [r12-0x28]
    7c479db09fb1:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db09fb6:	test   r10d,0x3f
    7c479db09fbd:	je     0x7c479db09fe2
    7c479db09fc3:	mov    r11d,r10d
    7c479db09fc6:	shr    r10d,1
    7c479db09fc9:	and    r10d,0x1e
    7c479db09fcd:	and    r11d,0x1
    7c479db09fd1:	or     r10d,r11d
    7c479db09fd4:	or     DWORD PTR [r12+0x314],r10d
    7c479db09fdc:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db09fe2:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db09fe8:	lea    rdi,[rsp+0x110]
    7c479db09ff0:	lea    rsi,[rsp+0xf0]
    7c479db09ff8:	lea    rdx,[rsp+0x100]
    7c479db0a000:	mov    ecx,0x56
    7c479db0a005:	mov    r8d,0x0
    7c479db0a00b:	lea    r9,[r12+0x314]
    7c479db0a013:	movabs r11,0x62fe8718e650
    7c479db0a01d:	call   r11
    7c479db0a020:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0a026:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0a02c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0a032:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0a038:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0a03e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0a044:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0a04e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db0a058:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0a062:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0a06a:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0a076:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0a07f:	mov    rdx,rbx
    7c479db0a082:	shr    rdx,0x10
    7c479db0a086:	and    edx,0xc000
    7c479db0a08c:	mov    rax,rbx
    7c479db0a08f:	shr    rax,0x15
    7c479db0a093:	and    eax,0x100
    7c479db0a098:	xor    eax,0x100
    7c479db0a09d:	or     edx,eax
    7c479db0a09f:	mov    rax,rbx
    7c479db0a0a2:	shr    rax,0x1c
    7c479db0a0a6:	and    eax,0x1
    7c479db0a0a9:	or     edx,eax
    7c479db0a0ab:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0a0b0:	add    rsp,0x8
    7c479db0a0b4:	ret
    7c479db0a0b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db0a0c0:	sub    rsp,0x8
    7c479db0a0c4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0a0d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0a0d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0a0dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0a0e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db0a0e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db0a0ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db0a0f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0a102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db0a10c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db0a116:	push   rdx
    7c479db0a117:	push   rsi
    7c479db0a118:	push   r10
    7c479db0a11a:	push   r11
    7c479db0a11c:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0a121:	mov    r10d,edx
    7c479db0a124:	and    r10d,0xc000
    7c479db0a12b:	shl    r10d,0x10
    7c479db0a12f:	mov    r11d,edx
    7c479db0a132:	and    r11d,0x100
    7c479db0a139:	shl    r11d,0x15
    7c479db0a13d:	or     r10d,r11d
    7c479db0a140:	and    edx,0x1
    7c479db0a143:	shl    edx,0x1c
    7c479db0a146:	or     r10d,edx
    7c479db0a149:	btc    r10,0x1d
    7c479db0a14e:	mov    r11d,0xf0000000
    7c479db0a154:	and    r11,r10
    7c479db0a157:	movabs rsi,0xffffffff0fffffff
    7c479db0a161:	and    rbx,rsi
    7c479db0a164:	or     rbx,r11
    7c479db0a167:	pop    r11
    7c479db0a169:	pop    r10
    7c479db0a16b:	pop    rsi
    7c479db0a16c:	pop    rdx
    7c479db0a16d:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0a175:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0a17b:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0a180:	test   r10d,0x3f
    7c479db0a187:	je     0x7c479db0a1ac
    7c479db0a18d:	mov    r11d,r10d
    7c479db0a190:	shr    r10d,1
    7c479db0a193:	and    r10d,0x1e
    7c479db0a197:	and    r11d,0x1
    7c479db0a19b:	or     r10d,r11d
    7c479db0a19e:	or     DWORD PTR [r12+0x314],r10d
    7c479db0a1a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0a1ac:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0a1b2:	lea    rdi,[rsp+0x110]
    7c479db0a1ba:	lea    rsi,[rsp+0xf0]
    7c479db0a1c2:	lea    rdx,[rsp+0x100]
    7c479db0a1ca:	mov    ecx,0x56
    7c479db0a1cf:	mov    r8d,0x0
    7c479db0a1d5:	lea    r9,[r12+0x314]
    7c479db0a1dd:	movabs r11,0x62fe8718e650
    7c479db0a1e7:	call   r11
    7c479db0a1ea:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0a1f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0a1f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0a1fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0a202:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0a208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0a20e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db0a218:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0a222:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db0a22c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0a236:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0a23e:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0a24a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0a253:	mov    rdx,rbx
    7c479db0a256:	shr    rdx,0x10
    7c479db0a25a:	and    edx,0xc000
    7c479db0a260:	mov    rax,rbx
    7c479db0a263:	shr    rax,0x15
    7c479db0a267:	and    eax,0x100
    7c479db0a26c:	xor    eax,0x100
    7c479db0a271:	or     edx,eax
    7c479db0a273:	mov    rax,rbx
    7c479db0a276:	shr    rax,0x1c
    7c479db0a27a:	and    eax,0x1
    7c479db0a27d:	or     edx,eax
    7c479db0a27f:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0a284:	add    rsp,0x8
    7c479db0a288:	ret
    7c479db0a289:	nop    DWORD PTR [rax+0x0]
    7c479db0a290:	sub    rsp,0x8
    7c479db0a294:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0a2a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0a2a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0a2ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0a2b2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0a2b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db0a2be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db0a2c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0a2d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db0a2dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db0a2e6:	push   rdx
    7c479db0a2e7:	push   rsi
    7c479db0a2e8:	push   r10
    7c479db0a2ea:	push   r11
    7c479db0a2ec:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0a2f1:	mov    r10d,edx
    7c479db0a2f4:	and    r10d,0xc000
    7c479db0a2fb:	shl    r10d,0x10
    7c479db0a2ff:	mov    r11d,edx
    7c479db0a302:	and    r11d,0x100
    7c479db0a309:	shl    r11d,0x15
    7c479db0a30d:	or     r10d,r11d
    7c479db0a310:	and    edx,0x1
    7c479db0a313:	shl    edx,0x1c
    7c479db0a316:	or     r10d,edx
    7c479db0a319:	btc    r10,0x1d
    7c479db0a31e:	mov    r11d,0xf0000000
    7c479db0a324:	and    r11,r10
    7c479db0a327:	movabs rsi,0xffffffff0fffffff
    7c479db0a331:	and    rbx,rsi
    7c479db0a334:	or     rbx,r11
    7c479db0a337:	pop    r11
    7c479db0a339:	pop    r10
    7c479db0a33b:	pop    rsi
    7c479db0a33c:	pop    rdx
    7c479db0a33d:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0a345:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0a34b:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0a350:	test   r10d,0x3f
    7c479db0a357:	je     0x7c479db0a37c
    7c479db0a35d:	mov    r11d,r10d
    7c479db0a360:	shr    r10d,1
    7c479db0a363:	and    r10d,0x1e
    7c479db0a367:	and    r11d,0x1
    7c479db0a36b:	or     r10d,r11d
    7c479db0a36e:	or     DWORD PTR [r12+0x314],r10d
    7c479db0a376:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0a37c:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0a382:	lea    rdi,[rsp+0x110]
    7c479db0a38a:	lea    rsi,[rsp+0xf0]
    7c479db0a392:	lea    rdx,[rsp+0x100]
    7c479db0a39a:	mov    ecx,0x14
    7c479db0a39f:	mov    r8d,0x0
    7c479db0a3a5:	lea    r9,[r12+0x314]
    7c479db0a3ad:	movabs r11,0x62fe8718e650
    7c479db0a3b7:	call   r11
    7c479db0a3ba:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0a3c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0a3c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0a3cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0a3d2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0a3d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0a3de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db0a3e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0a3f2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db0a3fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0a406:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0a40e:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0a41a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0a423:	mov    rdx,rbx
    7c479db0a426:	shr    rdx,0x10
    7c479db0a42a:	and    edx,0xc000
    7c479db0a430:	mov    rax,rbx
    7c479db0a433:	shr    rax,0x15
    7c479db0a437:	and    eax,0x100
    7c479db0a43c:	xor    eax,0x100
    7c479db0a441:	or     edx,eax
    7c479db0a443:	mov    rax,rbx
    7c479db0a446:	shr    rax,0x1c
    7c479db0a44a:	and    eax,0x1
    7c479db0a44d:	or     edx,eax
    7c479db0a44f:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0a454:	add    rsp,0x8
    7c479db0a458:	ret
    7c479db0a459:	nop    DWORD PTR [rax+0x0]
    7c479db0a460:	sub    rsp,0x8
    7c479db0a464:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0a470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0a476:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0a47c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db0a482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0a488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db0a48e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db0a498:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db0a4a2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0a4ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db0a4b6:	push   rdx
    7c479db0a4b7:	push   rsi
    7c479db0a4b8:	push   r10
    7c479db0a4ba:	push   r11
    7c479db0a4bc:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0a4c1:	mov    r10d,edx
    7c479db0a4c4:	and    r10d,0xc000
    7c479db0a4cb:	shl    r10d,0x10
    7c479db0a4cf:	mov    r11d,edx
    7c479db0a4d2:	and    r11d,0x100
    7c479db0a4d9:	shl    r11d,0x15
    7c479db0a4dd:	or     r10d,r11d
    7c479db0a4e0:	and    edx,0x1
    7c479db0a4e3:	shl    edx,0x1c
    7c479db0a4e6:	or     r10d,edx
    7c479db0a4e9:	btc    r10,0x1d
    7c479db0a4ee:	mov    r11d,0xf0000000
    7c479db0a4f4:	and    r11,r10
    7c479db0a4f7:	movabs rsi,0xffffffff0fffffff
    7c479db0a501:	and    rbx,rsi
    7c479db0a504:	or     rbx,r11
    7c479db0a507:	pop    r11
    7c479db0a509:	pop    r10
    7c479db0a50b:	pop    rsi
    7c479db0a50c:	pop    rdx
    7c479db0a50d:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0a515:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0a51b:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0a520:	test   r10d,0x3f
    7c479db0a527:	je     0x7c479db0a54c
    7c479db0a52d:	mov    r11d,r10d
    7c479db0a530:	shr    r10d,1
    7c479db0a533:	and    r10d,0x1e
    7c479db0a537:	and    r11d,0x1
    7c479db0a53b:	or     r10d,r11d
    7c479db0a53e:	or     DWORD PTR [r12+0x314],r10d
    7c479db0a546:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0a54c:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0a552:	lea    rdi,[rsp+0x110]
    7c479db0a55a:	lea    rsi,[rsp+0xf0]
    7c479db0a562:	lea    rdx,[rsp+0x100]
    7c479db0a56a:	mov    ecx,0x56
    7c479db0a56f:	mov    r8d,0x0
    7c479db0a575:	lea    r9,[r12+0x314]
    7c479db0a57d:	movabs r11,0x62fe8718e650
    7c479db0a587:	call   r11
    7c479db0a58a:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0a590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0a596:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0a59c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0a5a2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0a5a8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0a5ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db0a5b8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0a5c2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0a5cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0a5d6:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0a5de:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0a5ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0a5f3:	mov    rdx,rbx
    7c479db0a5f6:	shr    rdx,0x10
    7c479db0a5fa:	and    edx,0xc000
    7c479db0a600:	mov    rax,rbx
    7c479db0a603:	shr    rax,0x15
    7c479db0a607:	and    eax,0x100
    7c479db0a60c:	xor    eax,0x100
    7c479db0a611:	or     edx,eax
    7c479db0a613:	mov    rax,rbx
    7c479db0a616:	shr    rax,0x1c
    7c479db0a61a:	and    eax,0x1
    7c479db0a61d:	or     edx,eax
    7c479db0a61f:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0a624:	add    rsp,0x8
    7c479db0a628:	ret
    7c479db0a629:	nop    DWORD PTR [rax+0x0]
    7c479db0a630:	sub    rsp,0x8
    7c479db0a634:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0a640:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0a646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0a64c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db0a652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0a658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db0a65e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db0a668:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db0a672:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0a67c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db0a686:	push   rdx
    7c479db0a687:	push   rsi
    7c479db0a688:	push   r10
    7c479db0a68a:	push   r11
    7c479db0a68c:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0a691:	mov    r10d,edx
    7c479db0a694:	and    r10d,0xc000
    7c479db0a69b:	shl    r10d,0x10
    7c479db0a69f:	mov    r11d,edx
    7c479db0a6a2:	and    r11d,0x100
    7c479db0a6a9:	shl    r11d,0x15
    7c479db0a6ad:	or     r10d,r11d
    7c479db0a6b0:	and    edx,0x1
    7c479db0a6b3:	shl    edx,0x1c
    7c479db0a6b6:	or     r10d,edx
    7c479db0a6b9:	btc    r10,0x1d
    7c479db0a6be:	mov    r11d,0xf0000000
    7c479db0a6c4:	and    r11,r10
    7c479db0a6c7:	movabs rsi,0xffffffff0fffffff
    7c479db0a6d1:	and    rbx,rsi
    7c479db0a6d4:	or     rbx,r11
    7c479db0a6d7:	pop    r11
    7c479db0a6d9:	pop    r10
    7c479db0a6db:	pop    rsi
    7c479db0a6dc:	pop    rdx
    7c479db0a6dd:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0a6e5:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0a6eb:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0a6f0:	test   r10d,0x3f
    7c479db0a6f7:	je     0x7c479db0a71c
    7c479db0a6fd:	mov    r11d,r10d
    7c479db0a700:	shr    r10d,1
    7c479db0a703:	and    r10d,0x1e
    7c479db0a707:	and    r11d,0x1
    7c479db0a70b:	or     r10d,r11d
    7c479db0a70e:	or     DWORD PTR [r12+0x314],r10d
    7c479db0a716:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0a71c:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0a722:	lea    rdi,[rsp+0x110]
    7c479db0a72a:	lea    rsi,[rsp+0xf0]
    7c479db0a732:	lea    rdx,[rsp+0x100]
    7c479db0a73a:	mov    ecx,0x14
    7c479db0a73f:	mov    r8d,0x0
    7c479db0a745:	lea    r9,[r12+0x314]
    7c479db0a74d:	movabs r11,0x62fe8718e650
    7c479db0a757:	call   r11
    7c479db0a75a:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0a760:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0a766:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0a76c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0a772:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0a778:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0a77e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db0a788:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0a792:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0a79c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0a7a6:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0a7ae:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0a7ba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0a7c3:	mov    rdx,rbx
    7c479db0a7c6:	shr    rdx,0x10
    7c479db0a7ca:	and    edx,0xc000
    7c479db0a7d0:	mov    rax,rbx
    7c479db0a7d3:	shr    rax,0x15
    7c479db0a7d7:	and    eax,0x100
    7c479db0a7dc:	xor    eax,0x100
    7c479db0a7e1:	or     edx,eax
    7c479db0a7e3:	mov    rax,rbx
    7c479db0a7e6:	shr    rax,0x1c
    7c479db0a7ea:	and    eax,0x1
    7c479db0a7ed:	or     edx,eax
    7c479db0a7ef:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0a7f4:	add    rsp,0x8
    7c479db0a7f8:	ret
    7c479db0a7f9:	nop    DWORD PTR [rax+0x0]
    7c479db0a800:	sub    rsp,0x8
    7c479db0a804:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0a810:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0a816:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0a81c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db0a822:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0a828:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db0a82e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db0a838:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0a842:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db0a84c:	push   rdx
    7c479db0a84d:	push   rsi
    7c479db0a84e:	push   r10
    7c479db0a850:	push   r11
    7c479db0a852:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0a857:	mov    r10d,edx
    7c479db0a85a:	and    r10d,0xc000
    7c479db0a861:	shl    r10d,0x10
    7c479db0a865:	mov    r11d,edx
    7c479db0a868:	and    r11d,0x100
    7c479db0a86f:	shl    r11d,0x15
    7c479db0a873:	or     r10d,r11d
    7c479db0a876:	and    edx,0x1
    7c479db0a879:	shl    edx,0x1c
    7c479db0a87c:	or     r10d,edx
    7c479db0a87f:	btc    r10,0x1d
    7c479db0a884:	mov    r11d,0xf0000000
    7c479db0a88a:	and    r11,r10
    7c479db0a88d:	movabs rsi,0xffffffff0fffffff
    7c479db0a897:	and    rbx,rsi
    7c479db0a89a:	or     rbx,r11
    7c479db0a89d:	pop    r11
    7c479db0a89f:	pop    r10
    7c479db0a8a1:	pop    rsi
    7c479db0a8a2:	pop    rdx
    7c479db0a8a3:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0a8ab:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0a8b1:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0a8b6:	test   r10d,0x3f
    7c479db0a8bd:	je     0x7c479db0a8e2
    7c479db0a8c3:	mov    r11d,r10d
    7c479db0a8c6:	shr    r10d,1
    7c479db0a8c9:	and    r10d,0x1e
    7c479db0a8cd:	and    r11d,0x1
    7c479db0a8d1:	or     r10d,r11d
    7c479db0a8d4:	or     DWORD PTR [r12+0x314],r10d
    7c479db0a8dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0a8e2:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0a8e8:	lea    rdi,[rsp+0x110]
    7c479db0a8f0:	lea    rsi,[rsp+0xf0]
    7c479db0a8f8:	lea    rdx,[rsp+0x100]
    7c479db0a900:	mov    ecx,0x14
    7c479db0a905:	mov    r8d,0x0
    7c479db0a90b:	lea    r9,[r12+0x314]
    7c479db0a913:	movabs r11,0x62fe8718e650
    7c479db0a91d:	call   r11
    7c479db0a920:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0a926:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0a92c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0a932:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0a938:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0a93e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0a944:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0a94e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0a958:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db0a962:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0a96a:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0a976:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0a97f:	mov    rdx,rbx
    7c479db0a982:	shr    rdx,0x10
    7c479db0a986:	and    edx,0xc000
    7c479db0a98c:	mov    rax,rbx
    7c479db0a98f:	shr    rax,0x15
    7c479db0a993:	and    eax,0x100
    7c479db0a998:	xor    eax,0x100
    7c479db0a99d:	or     edx,eax
    7c479db0a99f:	mov    rax,rbx
    7c479db0a9a2:	shr    rax,0x1c
    7c479db0a9a6:	and    eax,0x1
    7c479db0a9a9:	or     edx,eax
    7c479db0a9ab:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0a9b0:	add    rsp,0x8
    7c479db0a9b4:	ret
    7c479db0a9b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db0a9c0:	sub    rsp,0x8
    7c479db0a9c4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0a9d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0a9d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0a9dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0a9e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db0a9e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0a9ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db0a9f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0aa02:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db0aa0c:	push   rdx
    7c479db0aa0d:	push   rsi
    7c479db0aa0e:	push   r10
    7c479db0aa10:	push   r11
    7c479db0aa12:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0aa17:	mov    r10d,edx
    7c479db0aa1a:	and    r10d,0xc000
    7c479db0aa21:	shl    r10d,0x10
    7c479db0aa25:	mov    r11d,edx
    7c479db0aa28:	and    r11d,0x100
    7c479db0aa2f:	shl    r11d,0x15
    7c479db0aa33:	or     r10d,r11d
    7c479db0aa36:	and    edx,0x1
    7c479db0aa39:	shl    edx,0x1c
    7c479db0aa3c:	or     r10d,edx
    7c479db0aa3f:	btc    r10,0x1d
    7c479db0aa44:	mov    r11d,0xf0000000
    7c479db0aa4a:	and    r11,r10
    7c479db0aa4d:	movabs rsi,0xffffffff0fffffff
    7c479db0aa57:	and    rbx,rsi
    7c479db0aa5a:	or     rbx,r11
    7c479db0aa5d:	pop    r11
    7c479db0aa5f:	pop    r10
    7c479db0aa61:	pop    rsi
    7c479db0aa62:	pop    rdx
    7c479db0aa63:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0aa6b:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0aa71:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0aa76:	test   r10d,0x3f
    7c479db0aa7d:	je     0x7c479db0aaa2
    7c479db0aa83:	mov    r11d,r10d
    7c479db0aa86:	shr    r10d,1
    7c479db0aa89:	and    r10d,0x1e
    7c479db0aa8d:	and    r11d,0x1
    7c479db0aa91:	or     r10d,r11d
    7c479db0aa94:	or     DWORD PTR [r12+0x314],r10d
    7c479db0aa9c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0aaa2:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0aaa8:	lea    rdi,[rsp+0x110]
    7c479db0aab0:	lea    rsi,[rsp+0xf0]
    7c479db0aab8:	lea    rdx,[rsp+0x100]
    7c479db0aac0:	mov    ecx,0x14
    7c479db0aac5:	mov    r8d,0x0
    7c479db0aacb:	lea    r9,[r12+0x314]
    7c479db0aad3:	movabs r11,0x62fe8718e650
    7c479db0aadd:	call   r11
    7c479db0aae0:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0aae6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0aaec:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0aaf2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0aaf8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0aafe:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0ab04:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0ab0e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0ab18:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db0ab22:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0ab2a:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0ab36:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0ab3f:	mov    rdx,rbx
    7c479db0ab42:	shr    rdx,0x10
    7c479db0ab46:	and    edx,0xc000
    7c479db0ab4c:	mov    rax,rbx
    7c479db0ab4f:	shr    rax,0x15
    7c479db0ab53:	and    eax,0x100
    7c479db0ab58:	xor    eax,0x100
    7c479db0ab5d:	or     edx,eax
    7c479db0ab5f:	mov    rax,rbx
    7c479db0ab62:	shr    rax,0x1c
    7c479db0ab66:	and    eax,0x1
    7c479db0ab69:	or     edx,eax
    7c479db0ab6b:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0ab70:	add    rsp,0x8
    7c479db0ab74:	ret
    7c479db0ab75:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db0ab80:	sub    rsp,0x8
    7c479db0ab84:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0ab90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0ab96:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0ab9c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0aba2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db0aba8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0abae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db0abb4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0abbe:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db0abc8:	push   rdx
    7c479db0abc9:	push   rsi
    7c479db0abca:	push   r10
    7c479db0abcc:	push   r11
    7c479db0abce:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0abd3:	mov    r10d,edx
    7c479db0abd6:	and    r10d,0xc000
    7c479db0abdd:	shl    r10d,0x10
    7c479db0abe1:	mov    r11d,edx
    7c479db0abe4:	and    r11d,0x100
    7c479db0abeb:	shl    r11d,0x15
    7c479db0abef:	or     r10d,r11d
    7c479db0abf2:	and    edx,0x1
    7c479db0abf5:	shl    edx,0x1c
    7c479db0abf8:	or     r10d,edx
    7c479db0abfb:	btc    r10,0x1d
    7c479db0ac00:	mov    r11d,0xf0000000
    7c479db0ac06:	and    r11,r10
    7c479db0ac09:	movabs rsi,0xffffffff0fffffff
    7c479db0ac13:	and    rbx,rsi
    7c479db0ac16:	or     rbx,r11
    7c479db0ac19:	pop    r11
    7c479db0ac1b:	pop    r10
    7c479db0ac1d:	pop    rsi
    7c479db0ac1e:	pop    rdx
    7c479db0ac1f:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0ac27:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0ac2d:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0ac32:	test   r10d,0x3f
    7c479db0ac39:	je     0x7c479db0ac5e
    7c479db0ac3f:	mov    r11d,r10d
    7c479db0ac42:	shr    r10d,1
    7c479db0ac45:	and    r10d,0x1e
    7c479db0ac49:	and    r11d,0x1
    7c479db0ac4d:	or     r10d,r11d
    7c479db0ac50:	or     DWORD PTR [r12+0x314],r10d
    7c479db0ac58:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0ac5e:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0ac64:	lea    rdi,[rsp+0x110]
    7c479db0ac6c:	lea    rsi,[rsp+0xf0]
    7c479db0ac74:	lea    rdx,[rsp+0x100]
    7c479db0ac7c:	mov    ecx,0x56
    7c479db0ac81:	mov    r8d,0x0
    7c479db0ac87:	lea    r9,[r12+0x314]
    7c479db0ac8f:	movabs r11,0x62fe8718e650
    7c479db0ac99:	call   r11
    7c479db0ac9c:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0aca2:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0aca8:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0acae:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0acb4:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0acba:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0acc0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0acc6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0acd0:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db0acda:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0ace2:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0acee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0acf7:	mov    rdx,rbx
    7c479db0acfa:	shr    rdx,0x10
    7c479db0acfe:	and    edx,0xc000
    7c479db0ad04:	mov    rax,rbx
    7c479db0ad07:	shr    rax,0x15
    7c479db0ad0b:	and    eax,0x100
    7c479db0ad10:	xor    eax,0x100
    7c479db0ad15:	or     edx,eax
    7c479db0ad17:	mov    rax,rbx
    7c479db0ad1a:	shr    rax,0x1c
    7c479db0ad1e:	and    eax,0x1
    7c479db0ad21:	or     edx,eax
    7c479db0ad23:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0ad28:	add    rsp,0x8
    7c479db0ad2c:	ret
    7c479db0ad2d:	nop    DWORD PTR [rax]
    7c479db0ad30:	sub    rsp,0x8
    7c479db0ad34:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0ad40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0ad46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0ad4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0ad52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db0ad58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db0ad5e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db0ad68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0ad72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db0ad7c:	push   rdx
    7c479db0ad7d:	push   rsi
    7c479db0ad7e:	push   r10
    7c479db0ad80:	push   r11
    7c479db0ad82:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0ad87:	mov    r10d,edx
    7c479db0ad8a:	and    r10d,0xc000
    7c479db0ad91:	shl    r10d,0x10
    7c479db0ad95:	mov    r11d,edx
    7c479db0ad98:	and    r11d,0x100
    7c479db0ad9f:	shl    r11d,0x15
    7c479db0ada3:	or     r10d,r11d
    7c479db0ada6:	and    edx,0x1
    7c479db0ada9:	shl    edx,0x1c
    7c479db0adac:	or     r10d,edx
    7c479db0adaf:	btc    r10,0x1d
    7c479db0adb4:	mov    r11d,0xf0000000
    7c479db0adba:	and    r11,r10
    7c479db0adbd:	movabs rsi,0xffffffff0fffffff
    7c479db0adc7:	and    rbx,rsi
    7c479db0adca:	or     rbx,r11
    7c479db0adcd:	pop    r11
    7c479db0adcf:	pop    r10
    7c479db0add1:	pop    rsi
    7c479db0add2:	pop    rdx
    7c479db0add3:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0addb:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0ade1:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0ade6:	test   r10d,0x3f
    7c479db0aded:	je     0x7c479db0ae12
    7c479db0adf3:	mov    r11d,r10d
    7c479db0adf6:	shr    r10d,1
    7c479db0adf9:	and    r10d,0x1e
    7c479db0adfd:	and    r11d,0x1
    7c479db0ae01:	or     r10d,r11d
    7c479db0ae04:	or     DWORD PTR [r12+0x314],r10d
    7c479db0ae0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0ae12:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0ae18:	lea    rdi,[rsp+0x110]
    7c479db0ae20:	lea    rsi,[rsp+0xf0]
    7c479db0ae28:	lea    rdx,[rsp+0x100]
    7c479db0ae30:	mov    ecx,0x56
    7c479db0ae35:	mov    r8d,0x0
    7c479db0ae3b:	lea    r9,[r12+0x314]
    7c479db0ae43:	movabs r11,0x62fe8718e650
    7c479db0ae4d:	call   r11
    7c479db0ae50:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0ae56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0ae5c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0ae62:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0ae68:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0ae6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0ae74:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db0ae7e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0ae88:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db0ae92:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0ae9a:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0aea6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0aeaf:	mov    rdx,rbx
    7c479db0aeb2:	shr    rdx,0x10
    7c479db0aeb6:	and    edx,0xc000
    7c479db0aebc:	mov    rax,rbx
    7c479db0aebf:	shr    rax,0x15
    7c479db0aec3:	and    eax,0x100
    7c479db0aec8:	xor    eax,0x100
    7c479db0aecd:	or     edx,eax
    7c479db0aecf:	mov    rax,rbx
    7c479db0aed2:	shr    rax,0x1c
    7c479db0aed6:	and    eax,0x1
    7c479db0aed9:	or     edx,eax
    7c479db0aedb:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0aee0:	add    rsp,0x8
    7c479db0aee4:	ret
    7c479db0aee5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db0aef0:	sub    rsp,0x8
    7c479db0aef4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0af00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0af06:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0af0c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0af12:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db0af18:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0af1e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db0af24:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db0af2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0af38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    7c479db0af42:	push   rdx
    7c479db0af43:	push   rsi
    7c479db0af44:	push   r10
    7c479db0af46:	push   r11
    7c479db0af48:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0af4d:	mov    r10d,edx
    7c479db0af50:	and    r10d,0xc000
    7c479db0af57:	shl    r10d,0x10
    7c479db0af5b:	mov    r11d,edx
    7c479db0af5e:	and    r11d,0x100
    7c479db0af65:	shl    r11d,0x15
    7c479db0af69:	or     r10d,r11d
    7c479db0af6c:	and    edx,0x1
    7c479db0af6f:	shl    edx,0x1c
    7c479db0af72:	or     r10d,edx
    7c479db0af75:	btc    r10,0x1d
    7c479db0af7a:	mov    r11d,0xf0000000
    7c479db0af80:	and    r11,r10
    7c479db0af83:	movabs rsi,0xffffffff0fffffff
    7c479db0af8d:	and    rbx,rsi
    7c479db0af90:	or     rbx,r11
    7c479db0af93:	pop    r11
    7c479db0af95:	pop    r10
    7c479db0af97:	pop    rsi
    7c479db0af98:	pop    rdx
    7c479db0af99:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0afa1:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0afa7:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0afac:	test   r10d,0x3f
    7c479db0afb3:	je     0x7c479db0afd8
    7c479db0afb9:	mov    r11d,r10d
    7c479db0afbc:	shr    r10d,1
    7c479db0afbf:	and    r10d,0x1e
    7c479db0afc3:	and    r11d,0x1
    7c479db0afc7:	or     r10d,r11d
    7c479db0afca:	or     DWORD PTR [r12+0x314],r10d
    7c479db0afd2:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0afd8:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0afde:	lea    rdi,[rsp+0x110]
    7c479db0afe6:	lea    rsi,[rsp+0xf0]
    7c479db0afee:	lea    rdx,[rsp+0x100]
    7c479db0aff6:	mov    ecx,0x14
    7c479db0affb:	mov    r8d,0x0
    7c479db0b001:	lea    r9,[r12+0x314]
    7c479db0b009:	movabs r11,0x62fe8718e650
    7c479db0b013:	call   r11
    7c479db0b016:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0b01c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0b022:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0b028:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0b02e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0b034:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0b03a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0b040:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db0b04a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0b054:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    7c479db0b05e:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0b066:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0b072:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0b07b:	mov    rdx,rbx
    7c479db0b07e:	shr    rdx,0x10
    7c479db0b082:	and    edx,0xc000
    7c479db0b088:	mov    rax,rbx
    7c479db0b08b:	shr    rax,0x15
    7c479db0b08f:	and    eax,0x100
    7c479db0b094:	xor    eax,0x100
    7c479db0b099:	or     edx,eax
    7c479db0b09b:	mov    rax,rbx
    7c479db0b09e:	shr    rax,0x1c
    7c479db0b0a2:	and    eax,0x1
    7c479db0b0a5:	or     edx,eax
    7c479db0b0a7:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0b0ac:	add    rsp,0x8
    7c479db0b0b0:	ret
    7c479db0b0b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db0b0c0:	sub    rsp,0x8
    7c479db0b0c4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0b0d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0b0d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0b0dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db0b0e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0b0e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db0b0ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db0b0f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db0b102:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0b10c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db0b116:	push   rdx
    7c479db0b117:	push   rsi
    7c479db0b118:	push   r10
    7c479db0b11a:	push   r11
    7c479db0b11c:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0b121:	mov    r10d,edx
    7c479db0b124:	and    r10d,0xc000
    7c479db0b12b:	shl    r10d,0x10
    7c479db0b12f:	mov    r11d,edx
    7c479db0b132:	and    r11d,0x100
    7c479db0b139:	shl    r11d,0x15
    7c479db0b13d:	or     r10d,r11d
    7c479db0b140:	and    edx,0x1
    7c479db0b143:	shl    edx,0x1c
    7c479db0b146:	or     r10d,edx
    7c479db0b149:	btc    r10,0x1d
    7c479db0b14e:	mov    r11d,0xf0000000
    7c479db0b154:	and    r11,r10
    7c479db0b157:	movabs rsi,0xffffffff0fffffff
    7c479db0b161:	and    rbx,rsi
    7c479db0b164:	or     rbx,r11
    7c479db0b167:	pop    r11
    7c479db0b169:	pop    r10
    7c479db0b16b:	pop    rsi
    7c479db0b16c:	pop    rdx
    7c479db0b16d:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0b175:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0b17b:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0b180:	test   r10d,0x3f
    7c479db0b187:	je     0x7c479db0b1ac
    7c479db0b18d:	mov    r11d,r10d
    7c479db0b190:	shr    r10d,1
    7c479db0b193:	and    r10d,0x1e
    7c479db0b197:	and    r11d,0x1
    7c479db0b19b:	or     r10d,r11d
    7c479db0b19e:	or     DWORD PTR [r12+0x314],r10d
    7c479db0b1a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0b1ac:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0b1b2:	lea    rdi,[rsp+0x110]
    7c479db0b1ba:	lea    rsi,[rsp+0xf0]
    7c479db0b1c2:	lea    rdx,[rsp+0x100]
    7c479db0b1ca:	mov    ecx,0x56
    7c479db0b1cf:	mov    r8d,0x0
    7c479db0b1d5:	lea    r9,[r12+0x314]
    7c479db0b1dd:	movabs r11,0x62fe8718e650
    7c479db0b1e7:	call   r11
    7c479db0b1ea:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0b1f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0b1f6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0b1fc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0b202:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0b208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0b20e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db0b218:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0b222:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0b22c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0b236:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0b23e:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0b24a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0b253:	mov    rdx,rbx
    7c479db0b256:	shr    rdx,0x10
    7c479db0b25a:	and    edx,0xc000
    7c479db0b260:	mov    rax,rbx
    7c479db0b263:	shr    rax,0x15
    7c479db0b267:	and    eax,0x100
    7c479db0b26c:	xor    eax,0x100
    7c479db0b271:	or     edx,eax
    7c479db0b273:	mov    rax,rbx
    7c479db0b276:	shr    rax,0x1c
    7c479db0b27a:	and    eax,0x1
    7c479db0b27d:	or     edx,eax
    7c479db0b27f:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0b284:	add    rsp,0x8
    7c479db0b288:	ret
    7c479db0b289:	nop    DWORD PTR [rax+0x0]
    7c479db0b290:	sub    rsp,0x8
    7c479db0b294:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0b2a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0b2a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0b2ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0b2b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db0b2b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0b2be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db0b2c4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    7c479db0b2ce:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db0b2d8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db0b2e2:	push   rdx
    7c479db0b2e3:	push   rsi
    7c479db0b2e4:	push   r10
    7c479db0b2e6:	push   r11
    7c479db0b2e8:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0b2ed:	mov    r10d,edx
    7c479db0b2f0:	and    r10d,0xc000
    7c479db0b2f7:	shl    r10d,0x10
    7c479db0b2fb:	mov    r11d,edx
    7c479db0b2fe:	and    r11d,0x100
    7c479db0b305:	shl    r11d,0x15
    7c479db0b309:	or     r10d,r11d
    7c479db0b30c:	and    edx,0x1
    7c479db0b30f:	shl    edx,0x1c
    7c479db0b312:	or     r10d,edx
    7c479db0b315:	btc    r10,0x1d
    7c479db0b31a:	mov    r11d,0xf0000000
    7c479db0b320:	and    r11,r10
    7c479db0b323:	movabs rsi,0xffffffff0fffffff
    7c479db0b32d:	and    rbx,rsi
    7c479db0b330:	or     rbx,r11
    7c479db0b333:	pop    r11
    7c479db0b335:	pop    r10
    7c479db0b337:	pop    rsi
    7c479db0b338:	pop    rdx
    7c479db0b339:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0b341:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0b347:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0b34c:	test   r10d,0x3f
    7c479db0b353:	je     0x7c479db0b378
    7c479db0b359:	mov    r11d,r10d
    7c479db0b35c:	shr    r10d,1
    7c479db0b35f:	and    r10d,0x1e
    7c479db0b363:	and    r11d,0x1
    7c479db0b367:	or     r10d,r11d
    7c479db0b36a:	or     DWORD PTR [r12+0x314],r10d
    7c479db0b372:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0b378:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0b37e:	lea    rdi,[rsp+0x110]
    7c479db0b386:	lea    rsi,[rsp+0xf0]
    7c479db0b38e:	lea    rdx,[rsp+0x100]
    7c479db0b396:	mov    ecx,0x56
    7c479db0b39b:	mov    r8d,0x0
    7c479db0b3a1:	lea    r9,[r12+0x314]
    7c479db0b3a9:	movabs r11,0x62fe8718e650
    7c479db0b3b3:	call   r11
    7c479db0b3b6:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0b3bc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0b3c2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0b3c8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0b3ce:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0b3d4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0b3da:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0b3e0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    7c479db0b3ea:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0b3f4:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0b3fe:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0b406:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0b412:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0b41b:	mov    rdx,rbx
    7c479db0b41e:	shr    rdx,0x10
    7c479db0b422:	and    edx,0xc000
    7c479db0b428:	mov    rax,rbx
    7c479db0b42b:	shr    rax,0x15
    7c479db0b42f:	and    eax,0x100
    7c479db0b434:	xor    eax,0x100
    7c479db0b439:	or     edx,eax
    7c479db0b43b:	mov    rax,rbx
    7c479db0b43e:	shr    rax,0x1c
    7c479db0b442:	and    eax,0x1
    7c479db0b445:	or     edx,eax
    7c479db0b447:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0b44c:	add    rsp,0x8
    7c479db0b450:	ret
    7c479db0b451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db0b460:	sub    rsp,0x8
    7c479db0b464:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0b470:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0b476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0b47c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    7c479db0b482:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    7c479db0b488:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db0b492:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0b49c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db0b4a6:	push   rdx
    7c479db0b4a7:	push   rsi
    7c479db0b4a8:	push   r10
    7c479db0b4aa:	push   r11
    7c479db0b4ac:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0b4b1:	mov    r10d,edx
    7c479db0b4b4:	and    r10d,0xc000
    7c479db0b4bb:	shl    r10d,0x10
    7c479db0b4bf:	mov    r11d,edx
    7c479db0b4c2:	and    r11d,0x100
    7c479db0b4c9:	shl    r11d,0x15
    7c479db0b4cd:	or     r10d,r11d
    7c479db0b4d0:	and    edx,0x1
    7c479db0b4d3:	shl    edx,0x1c
    7c479db0b4d6:	or     r10d,edx
    7c479db0b4d9:	btc    r10,0x1d
    7c479db0b4de:	mov    r11d,0xf0000000
    7c479db0b4e4:	and    r11,r10
    7c479db0b4e7:	movabs rsi,0xffffffff0fffffff
    7c479db0b4f1:	and    rbx,rsi
    7c479db0b4f4:	or     rbx,r11
    7c479db0b4f7:	pop    r11
    7c479db0b4f9:	pop    r10
    7c479db0b4fb:	pop    rsi
    7c479db0b4fc:	pop    rdx
    7c479db0b4fd:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0b505:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0b50b:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0b510:	test   r10d,0x3f
    7c479db0b517:	je     0x7c479db0b53c
    7c479db0b51d:	mov    r11d,r10d
    7c479db0b520:	shr    r10d,1
    7c479db0b523:	and    r10d,0x1e
    7c479db0b527:	and    r11d,0x1
    7c479db0b52b:	or     r10d,r11d
    7c479db0b52e:	or     DWORD PTR [r12+0x314],r10d
    7c479db0b536:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0b53c:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0b542:	lea    rdi,[rsp+0x110]
    7c479db0b54a:	lea    rsi,[rsp+0xf0]
    7c479db0b552:	lea    rdx,[rsp+0x100]
    7c479db0b55a:	mov    ecx,0x14
    7c479db0b55f:	mov    r8d,0x0
    7c479db0b565:	lea    r9,[r12+0x314]
    7c479db0b56d:	movabs r11,0x62fe8718e650
    7c479db0b577:	call   r11
    7c479db0b57a:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0b580:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0b586:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0b58c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    7c479db0b592:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    7c479db0b598:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0b5a2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0b5ac:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0b5b6:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0b5be:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0b5ca:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0b5d3:	mov    rdx,rbx
    7c479db0b5d6:	shr    rdx,0x10
    7c479db0b5da:	and    edx,0xc000
    7c479db0b5e0:	mov    rax,rbx
    7c479db0b5e3:	shr    rax,0x15
    7c479db0b5e7:	and    eax,0x100
    7c479db0b5ec:	xor    eax,0x100
    7c479db0b5f1:	or     edx,eax
    7c479db0b5f3:	mov    rax,rbx
    7c479db0b5f6:	shr    rax,0x1c
    7c479db0b5fa:	and    eax,0x1
    7c479db0b5fd:	or     edx,eax
    7c479db0b5ff:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0b604:	add    rsp,0x8
    7c479db0b608:	ret
    7c479db0b609:	nop    DWORD PTR [rax+0x0]
    7c479db0b610:	sub    rsp,0x8
    7c479db0b614:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0b620:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0b626:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0b62c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0b632:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    7c479db0b63c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0b646:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db0b650:	push   rdx
    7c479db0b651:	push   rsi
    7c479db0b652:	push   r10
    7c479db0b654:	push   r11
    7c479db0b656:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0b65b:	mov    r10d,edx
    7c479db0b65e:	and    r10d,0xc000
    7c479db0b665:	shl    r10d,0x10
    7c479db0b669:	mov    r11d,edx
    7c479db0b66c:	and    r11d,0x100
    7c479db0b673:	shl    r11d,0x15
    7c479db0b677:	or     r10d,r11d
    7c479db0b67a:	and    edx,0x1
    7c479db0b67d:	shl    edx,0x1c
    7c479db0b680:	or     r10d,edx
    7c479db0b683:	btc    r10,0x1d
    7c479db0b688:	mov    r11d,0xf0000000
    7c479db0b68e:	and    r11,r10
    7c479db0b691:	movabs rsi,0xffffffff0fffffff
    7c479db0b69b:	and    rbx,rsi
    7c479db0b69e:	or     rbx,r11
    7c479db0b6a1:	pop    r11
    7c479db0b6a3:	pop    r10
    7c479db0b6a5:	pop    rsi
    7c479db0b6a6:	pop    rdx
    7c479db0b6a7:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0b6af:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0b6b5:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0b6ba:	test   r10d,0x3f
    7c479db0b6c1:	je     0x7c479db0b6e6
    7c479db0b6c7:	mov    r11d,r10d
    7c479db0b6ca:	shr    r10d,1
    7c479db0b6cd:	and    r10d,0x1e
    7c479db0b6d1:	and    r11d,0x1
    7c479db0b6d5:	or     r10d,r11d
    7c479db0b6d8:	or     DWORD PTR [r12+0x314],r10d
    7c479db0b6e0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0b6e6:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0b6ec:	lea    rdi,[rsp+0x110]
    7c479db0b6f4:	lea    rsi,[rsp+0xf0]
    7c479db0b6fc:	lea    rdx,[rsp+0x100]
    7c479db0b704:	mov    ecx,0x14
    7c479db0b709:	mov    r8d,0x0
    7c479db0b70f:	lea    r9,[r12+0x314]
    7c479db0b717:	movabs r11,0x62fe8718e650
    7c479db0b721:	call   r11
    7c479db0b724:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0b72a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0b730:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0b736:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0b73c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    7c479db0b746:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0b750:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0b75a:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0b762:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0b76e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0b777:	mov    rdx,rbx
    7c479db0b77a:	shr    rdx,0x10
    7c479db0b77e:	and    edx,0xc000
    7c479db0b784:	mov    rax,rbx
    7c479db0b787:	shr    rax,0x15
    7c479db0b78b:	and    eax,0x100
    7c479db0b790:	xor    eax,0x100
    7c479db0b795:	or     edx,eax
    7c479db0b797:	mov    rax,rbx
    7c479db0b79a:	shr    rax,0x1c
    7c479db0b79e:	and    eax,0x1
    7c479db0b7a1:	or     edx,eax
    7c479db0b7a3:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0b7a8:	add    rsp,0x8
    7c479db0b7ac:	ret
    7c479db0b7ad:	nop    DWORD PTR [rax]
    7c479db0b7b0:	sub    rsp,0x8
    7c479db0b7b4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0b7c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0b7c6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0b7cc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    7c479db0b7d2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    7c479db0b7dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    7c479db0b7e6:	push   rdx
    7c479db0b7e7:	push   rsi
    7c479db0b7e8:	push   r10
    7c479db0b7ea:	push   r11
    7c479db0b7ec:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0b7f1:	mov    r10d,edx
    7c479db0b7f4:	and    r10d,0xc000
    7c479db0b7fb:	shl    r10d,0x10
    7c479db0b7ff:	mov    r11d,edx
    7c479db0b802:	and    r11d,0x100
    7c479db0b809:	shl    r11d,0x15
    7c479db0b80d:	or     r10d,r11d
    7c479db0b810:	and    edx,0x1
    7c479db0b813:	shl    edx,0x1c
    7c479db0b816:	or     r10d,edx
    7c479db0b819:	btc    r10,0x1d
    7c479db0b81e:	mov    r11d,0xf0000000
    7c479db0b824:	and    r11,r10
    7c479db0b827:	movabs rsi,0xffffffff0fffffff
    7c479db0b831:	and    rbx,rsi
    7c479db0b834:	or     rbx,r11
    7c479db0b837:	pop    r11
    7c479db0b839:	pop    r10
    7c479db0b83b:	pop    rsi
    7c479db0b83c:	pop    rdx
    7c479db0b83d:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0b845:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0b84b:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0b850:	test   r10d,0x3f
    7c479db0b857:	je     0x7c479db0b87c
    7c479db0b85d:	mov    r11d,r10d
    7c479db0b860:	shr    r10d,1
    7c479db0b863:	and    r10d,0x1e
    7c479db0b867:	and    r11d,0x1
    7c479db0b86b:	or     r10d,r11d
    7c479db0b86e:	or     DWORD PTR [r12+0x314],r10d
    7c479db0b876:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0b87c:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0b882:	lea    rdi,[rsp+0x110]
    7c479db0b88a:	lea    rsi,[rsp+0xf0]
    7c479db0b892:	lea    rdx,[rsp+0x100]
    7c479db0b89a:	mov    ecx,0x14
    7c479db0b89f:	mov    r8d,0x0
    7c479db0b8a5:	lea    r9,[r12+0x314]
    7c479db0b8ad:	movabs r11,0x62fe8718e650
    7c479db0b8b7:	call   r11
    7c479db0b8ba:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0b8c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0b8c6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0b8cc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    7c479db0b8d2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    7c479db0b8dc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    7c479db0b8e6:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0b8ee:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0b8fa:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0b903:	mov    rdx,rbx
    7c479db0b906:	shr    rdx,0x10
    7c479db0b90a:	and    edx,0xc000
    7c479db0b910:	mov    rax,rbx
    7c479db0b913:	shr    rax,0x15
    7c479db0b917:	and    eax,0x100
    7c479db0b91c:	xor    eax,0x100
    7c479db0b921:	or     edx,eax
    7c479db0b923:	mov    rax,rbx
    7c479db0b926:	shr    rax,0x1c
    7c479db0b92a:	and    eax,0x1
    7c479db0b92d:	or     edx,eax
    7c479db0b92f:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0b934:	add    rsp,0x8
    7c479db0b938:	ret
    7c479db0b939:	nop    DWORD PTR [rax+0x0]
    7c479db0b940:	sub    rsp,0x8
    7c479db0b944:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0b950:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0b956:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7c479db0b95c:	push   rdx
    7c479db0b95d:	push   rsi
    7c479db0b95e:	push   r10
    7c479db0b960:	push   r11
    7c479db0b962:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0b967:	mov    r10d,edx
    7c479db0b96a:	and    r10d,0xc000
    7c479db0b971:	shl    r10d,0x10
    7c479db0b975:	mov    r11d,edx
    7c479db0b978:	and    r11d,0x100
    7c479db0b97f:	shl    r11d,0x15
    7c479db0b983:	or     r10d,r11d
    7c479db0b986:	and    edx,0x1
    7c479db0b989:	shl    edx,0x1c
    7c479db0b98c:	or     r10d,edx
    7c479db0b98f:	btc    r10,0x1d
    7c479db0b994:	mov    r11d,0xf0000000
    7c479db0b99a:	and    r11,r10
    7c479db0b99d:	movabs rsi,0xffffffff0fffffff
    7c479db0b9a7:	and    rbx,rsi
    7c479db0b9aa:	or     rbx,r11
    7c479db0b9ad:	pop    r11
    7c479db0b9af:	pop    r10
    7c479db0b9b1:	pop    rsi
    7c479db0b9b2:	pop    rdx
    7c479db0b9b3:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0b9bb:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0b9c1:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0b9c6:	test   r10d,0x3f
    7c479db0b9cd:	je     0x7c479db0b9f2
    7c479db0b9d3:	mov    r11d,r10d
    7c479db0b9d6:	shr    r10d,1
    7c479db0b9d9:	and    r10d,0x1e
    7c479db0b9dd:	and    r11d,0x1
    7c479db0b9e1:	or     r10d,r11d
    7c479db0b9e4:	or     DWORD PTR [r12+0x314],r10d
    7c479db0b9ec:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0b9f2:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0b9f8:	lea    rdi,[rsp+0x110]
    7c479db0ba00:	lea    rsi,[rsp+0xf0]
    7c479db0ba08:	lea    rdx,[rsp+0x100]
    7c479db0ba10:	mov    ecx,0xc
    7c479db0ba15:	mov    r8d,0x0
    7c479db0ba1b:	lea    r9,[r12+0x314]
    7c479db0ba23:	movabs r11,0x62fe8718e650
    7c479db0ba2d:	call   r11
    7c479db0ba30:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0ba36:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0ba3c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7c479db0ba42:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0ba4a:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0ba56:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0ba5f:	mov    rdx,rbx
    7c479db0ba62:	shr    rdx,0x10
    7c479db0ba66:	and    edx,0xc000
    7c479db0ba6c:	mov    rax,rbx
    7c479db0ba6f:	shr    rax,0x15
    7c479db0ba73:	and    eax,0x100
    7c479db0ba78:	xor    eax,0x100
    7c479db0ba7d:	or     edx,eax
    7c479db0ba7f:	mov    rax,rbx
    7c479db0ba82:	shr    rax,0x1c
    7c479db0ba86:	and    eax,0x1
    7c479db0ba89:	or     edx,eax
    7c479db0ba8b:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0ba90:	add    rsp,0x8
    7c479db0ba94:	ret
    7c479db0ba95:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db0baa0:	sub    rsp,0x8
    7c479db0baa4:	mov    QWORD PTR [r12+0x378],0x3
    7c479db0bab0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7c479db0bab6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7c479db0babc:	push   rdx
    7c479db0babd:	push   rsi
    7c479db0babe:	push   r10
    7c479db0bac0:	push   r11
    7c479db0bac2:	mov    rdx,QWORD PTR [rsp+0x30]
    7c479db0bac7:	mov    r10d,edx
    7c479db0baca:	and    r10d,0xc000
    7c479db0bad1:	shl    r10d,0x10
    7c479db0bad5:	mov    r11d,edx
    7c479db0bad8:	and    r11d,0x100
    7c479db0badf:	shl    r11d,0x15
    7c479db0bae3:	or     r10d,r11d
    7c479db0bae6:	and    edx,0x1
    7c479db0bae9:	shl    edx,0x1c
    7c479db0baec:	or     r10d,edx
    7c479db0baef:	btc    r10,0x1d
    7c479db0baf4:	mov    r11d,0xf0000000
    7c479db0bafa:	and    r11,r10
    7c479db0bafd:	movabs rsi,0xffffffff0fffffff
    7c479db0bb07:	and    rbx,rsi
    7c479db0bb0a:	or     rbx,r11
    7c479db0bb0d:	pop    r11
    7c479db0bb0f:	pop    r10
    7c479db0bb11:	pop    rsi
    7c479db0bb12:	pop    rdx
    7c479db0bb13:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0bb1b:	stmxcsr DWORD PTR [r12-0x28]
    7c479db0bb21:	mov    r10d,DWORD PTR [r12-0x28]
    7c479db0bb26:	test   r10d,0x3f
    7c479db0bb2d:	je     0x7c479db0bb52
    7c479db0bb33:	mov    r11d,r10d
    7c479db0bb36:	shr    r10d,1
    7c479db0bb39:	and    r10d,0x1e
    7c479db0bb3d:	and    r11d,0x1
    7c479db0bb41:	or     r10d,r11d
    7c479db0bb44:	or     DWORD PTR [r12+0x314],r10d
    7c479db0bb4c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7c479db0bb52:	ldmxcsr DWORD PTR [r12-0x38]
    7c479db0bb58:	lea    rdi,[rsp+0x110]
    7c479db0bb60:	lea    rsi,[rsp+0xf0]
    7c479db0bb68:	lea    rdx,[rsp+0x100]
    7c479db0bb70:	mov    ecx,0xc
    7c479db0bb75:	mov    r8d,0x0
    7c479db0bb7b:	lea    r9,[r12+0x314]
    7c479db0bb83:	movabs r11,0x62fe8718e650
    7c479db0bb8d:	call   r11
    7c479db0bb90:	ldmxcsr DWORD PTR [r12-0x28]
    7c479db0bb96:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7c479db0bb9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7c479db0bba2:	mov    rbx,QWORD PTR [r12+0x108]
    7c479db0bbaa:	mov    QWORD PTR [r12+0x378],0x2
    7c479db0bbb6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7c479db0bbbf:	mov    rdx,rbx
    7c479db0bbc2:	shr    rdx,0x10
    7c479db0bbc6:	and    edx,0xc000
    7c479db0bbcc:	mov    rax,rbx
    7c479db0bbcf:	shr    rax,0x15
    7c479db0bbd3:	and    eax,0x100
    7c479db0bbd8:	xor    eax,0x100
    7c479db0bbdd:	or     edx,eax
    7c479db0bbdf:	mov    rax,rbx
    7c479db0bbe2:	shr    rax,0x1c
    7c479db0bbe6:	and    eax,0x1
    7c479db0bbe9:	or     edx,eax
    7c479db0bbeb:	mov    QWORD PTR [rsp+0x10],rdx
    7c479db0bbf0:	add    rsp,0x8
    7c479db0bbf4:	ret
    7c479db0bbf5:	mov    eax,0x410400
    7c479db0bbfa:	mov    QWORD PTR [r12+0x100],rax
    7c479db0bc02:	push   rdx
    7c479db0bc03:	push   rsi
    7c479db0bc04:	push   r10
    7c479db0bc06:	push   r11
    7c479db0bc08:	mov    r11,rax
    7c479db0bc0b:	lahf
    7c479db0bc0c:	seto   al
    7c479db0bc0f:	mov    WORD PTR [rsp+0x20],ax
    7c479db0bc14:	mov    rax,r11
    7c479db0bc17:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0bc1c:	mov    r10d,edx
    7c479db0bc1f:	and    r10d,0xc000
    7c479db0bc26:	shl    r10d,0x10
    7c479db0bc2a:	mov    r11d,edx
    7c479db0bc2d:	and    r11d,0x100
    7c479db0bc34:	shl    r11d,0x15
    7c479db0bc38:	or     r10d,r11d
    7c479db0bc3b:	and    edx,0x1
    7c479db0bc3e:	shl    edx,0x1c
    7c479db0bc41:	or     r10d,edx
    7c479db0bc44:	btc    r10,0x1d
    7c479db0bc49:	mov    r11d,0xf0000000
    7c479db0bc4f:	and    r11,r10
    7c479db0bc52:	movabs rsi,0xffffffff0fffffff
    7c479db0bc5c:	and    rbx,rsi
    7c479db0bc5f:	or     rbx,r11
    7c479db0bc62:	pop    r11
    7c479db0bc64:	pop    r10
    7c479db0bc66:	pop    rsi
    7c479db0bc67:	pop    rdx
    7c479db0bc68:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0bc70:	add    rsp,0x150
    7c479db0bc77:	mov    eax,0xc
    7c479db0bc7c:	movabs r11,0x62fe87327ca0
    7c479db0bc86:	jmp    r11
    7c479db0bc89:	mov    eax,0x41048c
    7c479db0bc8e:	mov    QWORD PTR [r12+0x100],rax
    7c479db0bc96:	push   rdx
    7c479db0bc97:	push   rsi
    7c479db0bc98:	push   r10
    7c479db0bc9a:	push   r11
    7c479db0bc9c:	mov    r11,rax
    7c479db0bc9f:	lahf
    7c479db0bca0:	seto   al
    7c479db0bca3:	mov    WORD PTR [rsp+0x20],ax
    7c479db0bca8:	mov    rax,r11
    7c479db0bcab:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0bcb0:	mov    r10d,edx
    7c479db0bcb3:	and    r10d,0xc000
    7c479db0bcba:	shl    r10d,0x10
    7c479db0bcbe:	mov    r11d,edx
    7c479db0bcc1:	and    r11d,0x100
    7c479db0bcc8:	shl    r11d,0x15
    7c479db0bccc:	or     r10d,r11d
    7c479db0bccf:	and    edx,0x1
    7c479db0bcd2:	shl    edx,0x1c
    7c479db0bcd5:	or     r10d,edx
    7c479db0bcd8:	btc    r10,0x1d
    7c479db0bcdd:	mov    r11d,0xf0000000
    7c479db0bce3:	and    r11,r10
    7c479db0bce6:	movabs rsi,0xffffffff0fffffff
    7c479db0bcf0:	and    rbx,rsi
    7c479db0bcf3:	or     rbx,r11
    7c479db0bcf6:	pop    r11
    7c479db0bcf8:	pop    r10
    7c479db0bcfa:	pop    rsi
    7c479db0bcfb:	pop    rdx
    7c479db0bcfc:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0bd04:	add    rsp,0x150
    7c479db0bd0b:	mov    eax,0xc
    7c479db0bd10:	movabs r11,0x62fe87327ca0
    7c479db0bd1a:	jmp    r11
    7c479db0bd1d:	mov    eax,0x4106cc
    7c479db0bd22:	mov    QWORD PTR [r12+0x100],rax
    7c479db0bd2a:	push   rdx
    7c479db0bd2b:	push   rsi
    7c479db0bd2c:	push   r10
    7c479db0bd2e:	push   r11
    7c479db0bd30:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0bd35:	mov    r10d,edx
    7c479db0bd38:	and    r10d,0xc000
    7c479db0bd3f:	shl    r10d,0x10
    7c479db0bd43:	mov    r11d,edx
    7c479db0bd46:	and    r11d,0x100
    7c479db0bd4d:	shl    r11d,0x15
    7c479db0bd51:	or     r10d,r11d
    7c479db0bd54:	and    edx,0x1
    7c479db0bd57:	shl    edx,0x1c
    7c479db0bd5a:	or     r10d,edx
    7c479db0bd5d:	btc    r10,0x1d
    7c479db0bd62:	mov    r11d,0xf0000000
    7c479db0bd68:	and    r11,r10
    7c479db0bd6b:	movabs rsi,0xffffffff0fffffff
    7c479db0bd75:	and    rbx,rsi
    7c479db0bd78:	or     rbx,r11
    7c479db0bd7b:	pop    r11
    7c479db0bd7d:	pop    r10
    7c479db0bd7f:	pop    rsi
    7c479db0bd80:	pop    rdx
    7c479db0bd81:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0bd89:	add    rsp,0x150
    7c479db0bd90:	mov    eax,0xc
    7c479db0bd95:	movabs r11,0x62fe87327ca0
    7c479db0bd9f:	jmp    r11
    7c479db0bda2:	mov    eax,0x4106d8
    7c479db0bda7:	mov    QWORD PTR [r12+0x100],rax
    7c479db0bdaf:	push   rdx
    7c479db0bdb0:	push   rsi
    7c479db0bdb1:	push   r10
    7c479db0bdb3:	push   r11
    7c479db0bdb5:	mov    r11,rax
    7c479db0bdb8:	lahf
    7c479db0bdb9:	seto   al
    7c479db0bdbc:	mov    WORD PTR [rsp+0x20],ax
    7c479db0bdc1:	mov    rax,r11
    7c479db0bdc4:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0bdc9:	mov    r10d,edx
    7c479db0bdcc:	and    r10d,0xc000
    7c479db0bdd3:	shl    r10d,0x10
    7c479db0bdd7:	mov    r11d,edx
    7c479db0bdda:	and    r11d,0x100
    7c479db0bde1:	shl    r11d,0x15
    7c479db0bde5:	or     r10d,r11d
    7c479db0bde8:	and    edx,0x1
    7c479db0bdeb:	shl    edx,0x1c
    7c479db0bdee:	or     r10d,edx
    7c479db0bdf1:	btc    r10,0x1d
    7c479db0bdf6:	mov    r11d,0xf0000000
    7c479db0bdfc:	and    r11,r10
    7c479db0bdff:	movabs rsi,0xffffffff0fffffff
    7c479db0be09:	and    rbx,rsi
    7c479db0be0c:	or     rbx,r11
    7c479db0be0f:	pop    r11
    7c479db0be11:	pop    r10
    7c479db0be13:	pop    rsi
    7c479db0be14:	pop    rdx
    7c479db0be15:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0be1d:	add    rsp,0x150
    7c479db0be24:	mov    eax,0xc
    7c479db0be29:	movabs r11,0x62fe87327ca0
    7c479db0be33:	jmp    r11
    7c479db0be36:	mov    eax,0x410700
    7c479db0be3b:	mov    QWORD PTR [r12+0x100],rax
    7c479db0be43:	push   rdx
    7c479db0be44:	push   rsi
    7c479db0be45:	push   r10
    7c479db0be47:	push   r11
    7c479db0be49:	mov    r11,rax
    7c479db0be4c:	lahf
    7c479db0be4d:	seto   al
    7c479db0be50:	mov    WORD PTR [rsp+0x20],ax
    7c479db0be55:	mov    rax,r11
    7c479db0be58:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0be5d:	mov    r10d,edx
    7c479db0be60:	and    r10d,0xc000
    7c479db0be67:	shl    r10d,0x10
    7c479db0be6b:	mov    r11d,edx
    7c479db0be6e:	and    r11d,0x100
    7c479db0be75:	shl    r11d,0x15
    7c479db0be79:	or     r10d,r11d
    7c479db0be7c:	and    edx,0x1
    7c479db0be7f:	shl    edx,0x1c
    7c479db0be82:	or     r10d,edx
    7c479db0be85:	btc    r10,0x1d
    7c479db0be8a:	mov    r11d,0xf0000000
    7c479db0be90:	and    r11,r10
    7c479db0be93:	movabs rsi,0xffffffff0fffffff
    7c479db0be9d:	and    rbx,rsi
    7c479db0bea0:	or     rbx,r11
    7c479db0bea3:	pop    r11
    7c479db0bea5:	pop    r10
    7c479db0bea7:	pop    rsi
    7c479db0bea8:	pop    rdx
    7c479db0bea9:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0beb1:	add    rsp,0x150
    7c479db0beb8:	mov    eax,0xc
    7c479db0bebd:	movabs r11,0x62fe87327ca0
    7c479db0bec7:	jmp    r11
    7c479db0beca:	mov    eax,0x410724
    7c479db0becf:	mov    QWORD PTR [r12+0x100],rax
    7c479db0bed7:	push   rdx
    7c479db0bed8:	push   rsi
    7c479db0bed9:	push   r10
    7c479db0bedb:	push   r11
    7c479db0bedd:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0bee2:	mov    r10d,edx
    7c479db0bee5:	and    r10d,0xc000
    7c479db0beec:	shl    r10d,0x10
    7c479db0bef0:	mov    r11d,edx
    7c479db0bef3:	and    r11d,0x100
    7c479db0befa:	shl    r11d,0x15
    7c479db0befe:	or     r10d,r11d
    7c479db0bf01:	and    edx,0x1
    7c479db0bf04:	shl    edx,0x1c
    7c479db0bf07:	or     r10d,edx
    7c479db0bf0a:	btc    r10,0x1d
    7c479db0bf0f:	mov    r11d,0xf0000000
    7c479db0bf15:	and    r11,r10
    7c479db0bf18:	movabs rsi,0xffffffff0fffffff
    7c479db0bf22:	and    rbx,rsi
    7c479db0bf25:	or     rbx,r11
    7c479db0bf28:	pop    r11
    7c479db0bf2a:	pop    r10
    7c479db0bf2c:	pop    rsi
    7c479db0bf2d:	pop    rdx
    7c479db0bf2e:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0bf36:	add    rsp,0x150
    7c479db0bf3d:	mov    eax,0xc
    7c479db0bf42:	movabs r11,0x62fe87327ca0
    7c479db0bf4c:	jmp    r11
    7c479db0bf4f:	nop
    7c479db0bf50:	sub    rsp,0x150
    7c479db0bf57:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0bf5f:	mov    QWORD PTR [rsp],r11
    7c479db0bf63:	cmp    DWORD PTR [r12+0x310],0x0
    7c479db0bf6c:	je     0x7c479db0bff7
    7c479db0bf72:	push   rdx
    7c479db0bf73:	push   rsi
    7c479db0bf74:	push   r10
    7c479db0bf76:	push   r11
    7c479db0bf78:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0bf7d:	mov    r10d,edx
    7c479db0bf80:	and    r10d,0xc000
    7c479db0bf87:	shl    r10d,0x10
    7c479db0bf8b:	mov    r11d,edx
    7c479db0bf8e:	and    r11d,0x100
    7c479db0bf95:	shl    r11d,0x15
    7c479db0bf99:	or     r10d,r11d
    7c479db0bf9c:	and    edx,0x1
    7c479db0bf9f:	shl    edx,0x1c
    7c479db0bfa2:	or     r10d,edx
    7c479db0bfa5:	btc    r10,0x1d
    7c479db0bfaa:	mov    r11d,0xf0000000
    7c479db0bfb0:	and    r11,r10
    7c479db0bfb3:	movabs rsi,0xffffffff0fffffff
    7c479db0bfbd:	and    rbx,rsi
    7c479db0bfc0:	or     rbx,r11
    7c479db0bfc3:	pop    r11
    7c479db0bfc5:	pop    r10
    7c479db0bfc7:	pop    rsi
    7c479db0bfc8:	pop    rdx
    7c479db0bfc9:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0bfd1:	mov    eax,0x410404
    7c479db0bfd6:	mov    QWORD PTR [r12+0x100],rax
    7c479db0bfde:	add    rsp,0x150
    7c479db0bfe5:	mov    eax,0x3
    7c479db0bfea:	movabs r11,0x62fe87327ca0
    7c479db0bff4:	jmp    r11
    7c479db0bff7:	jmp    0x7c479db0226d
    7c479db0bffc:	nop    DWORD PTR [rax+0x0]
    7c479db0c000:	sub    rsp,0x150
    7c479db0c007:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0c00f:	mov    QWORD PTR [rsp],r11
    7c479db0c013:	cmp    DWORD PTR [r12+0x310],0x0
    7c479db0c01c:	je     0x7c479db0c0a7
    7c479db0c022:	push   rdx
    7c479db0c023:	push   rsi
    7c479db0c024:	push   r10
    7c479db0c026:	push   r11
    7c479db0c028:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0c02d:	mov    r10d,edx
    7c479db0c030:	and    r10d,0xc000
    7c479db0c037:	shl    r10d,0x10
    7c479db0c03b:	mov    r11d,edx
    7c479db0c03e:	and    r11d,0x100
    7c479db0c045:	shl    r11d,0x15
    7c479db0c049:	or     r10d,r11d
    7c479db0c04c:	and    edx,0x1
    7c479db0c04f:	shl    edx,0x1c
    7c479db0c052:	or     r10d,edx
    7c479db0c055:	btc    r10,0x1d
    7c479db0c05a:	mov    r11d,0xf0000000
    7c479db0c060:	and    r11,r10
    7c479db0c063:	movabs rsi,0xffffffff0fffffff
    7c479db0c06d:	and    rbx,rsi
    7c479db0c070:	or     rbx,r11
    7c479db0c073:	pop    r11
    7c479db0c075:	pop    r10
    7c479db0c077:	pop    rsi
    7c479db0c078:	pop    rdx
    7c479db0c079:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0c081:	mov    eax,0x410450
    7c479db0c086:	mov    QWORD PTR [r12+0x100],rax
    7c479db0c08e:	add    rsp,0x150
    7c479db0c095:	mov    eax,0x3
    7c479db0c09a:	movabs r11,0x62fe87327ca0
    7c479db0c0a4:	jmp    r11
    7c479db0c0a7:	mov    r11,rax
    7c479db0c0aa:	movzx  eax,WORD PTR [rsp]
    7c479db0c0ae:	add    al,0x7f
    7c479db0c0b0:	sahf
    7c479db0c0b1:	mov    rax,r11
    7c479db0c0b4:	jmp    0x7c479db023dd
    7c479db0c0b9:	nop    DWORD PTR [rax+0x0]
    7c479db0c0c0:	sub    rsp,0x150
    7c479db0c0c7:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0c0cf:	mov    QWORD PTR [rsp],r11
    7c479db0c0d3:	cmp    DWORD PTR [r12+0x310],0x0
    7c479db0c0dc:	je     0x7c479db0c167
    7c479db0c0e2:	push   rdx
    7c479db0c0e3:	push   rsi
    7c479db0c0e4:	push   r10
    7c479db0c0e6:	push   r11
    7c479db0c0e8:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0c0ed:	mov    r10d,edx
    7c479db0c0f0:	and    r10d,0xc000
    7c479db0c0f7:	shl    r10d,0x10
    7c479db0c0fb:	mov    r11d,edx
    7c479db0c0fe:	and    r11d,0x100
    7c479db0c105:	shl    r11d,0x15
    7c479db0c109:	or     r10d,r11d
    7c479db0c10c:	and    edx,0x1
    7c479db0c10f:	shl    edx,0x1c
    7c479db0c112:	or     r10d,edx
    7c479db0c115:	btc    r10,0x1d
    7c479db0c11a:	mov    r11d,0xf0000000
    7c479db0c120:	and    r11,r10
    7c479db0c123:	movabs rsi,0xffffffff0fffffff
    7c479db0c12d:	and    rbx,rsi
    7c479db0c130:	or     rbx,r11
    7c479db0c133:	pop    r11
    7c479db0c135:	pop    r10
    7c479db0c137:	pop    rsi
    7c479db0c138:	pop    rdx
    7c479db0c139:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0c141:	mov    eax,0x410490
    7c479db0c146:	mov    QWORD PTR [r12+0x100],rax
    7c479db0c14e:	add    rsp,0x150
    7c479db0c155:	mov    eax,0x3
    7c479db0c15a:	movabs r11,0x62fe87327ca0
    7c479db0c164:	jmp    r11
    7c479db0c167:	jmp    0x7c479db0282b
    7c479db0c16c:	nop    DWORD PTR [rax+0x0]
    7c479db0c170:	sub    rsp,0x150
    7c479db0c177:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0c17f:	mov    QWORD PTR [rsp],r11
    7c479db0c183:	cmp    DWORD PTR [r12+0x310],0x0
    7c479db0c18c:	je     0x7c479db0c217
    7c479db0c192:	push   rdx
    7c479db0c193:	push   rsi
    7c479db0c194:	push   r10
    7c479db0c196:	push   r11
    7c479db0c198:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0c19d:	mov    r10d,edx
    7c479db0c1a0:	and    r10d,0xc000
    7c479db0c1a7:	shl    r10d,0x10
    7c479db0c1ab:	mov    r11d,edx
    7c479db0c1ae:	and    r11d,0x100
    7c479db0c1b5:	shl    r11d,0x15
    7c479db0c1b9:	or     r10d,r11d
    7c479db0c1bc:	and    edx,0x1
    7c479db0c1bf:	shl    edx,0x1c
    7c479db0c1c2:	or     r10d,edx
    7c479db0c1c5:	btc    r10,0x1d
    7c479db0c1ca:	mov    r11d,0xf0000000
    7c479db0c1d0:	and    r11,r10
    7c479db0c1d3:	movabs rsi,0xffffffff0fffffff
    7c479db0c1dd:	and    rbx,rsi
    7c479db0c1e0:	or     rbx,r11
    7c479db0c1e3:	pop    r11
    7c479db0c1e5:	pop    r10
    7c479db0c1e7:	pop    rsi
    7c479db0c1e8:	pop    rdx
    7c479db0c1e9:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0c1f1:	mov    eax,0x410500
    7c479db0c1f6:	mov    QWORD PTR [r12+0x100],rax
    7c479db0c1fe:	add    rsp,0x150
    7c479db0c205:	mov    eax,0x3
    7c479db0c20a:	movabs r11,0x62fe87327ca0
    7c479db0c214:	jmp    r11
    7c479db0c217:	mov    r11,rax
    7c479db0c21a:	movzx  eax,WORD PTR [rsp]
    7c479db0c21e:	add    al,0x7f
    7c479db0c220:	sahf
    7c479db0c221:	mov    rax,r11
    7c479db0c224:	jmp    0x7c479db02c37
    7c479db0c229:	nop    DWORD PTR [rax+0x0]
    7c479db0c230:	sub    rsp,0x150
    7c479db0c237:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0c23f:	mov    QWORD PTR [rsp],r11
    7c479db0c243:	cmp    DWORD PTR [r12+0x310],0x0
    7c479db0c24c:	je     0x7c479db0c2d7
    7c479db0c252:	push   rdx
    7c479db0c253:	push   rsi
    7c479db0c254:	push   r10
    7c479db0c256:	push   r11
    7c479db0c258:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0c25d:	mov    r10d,edx
    7c479db0c260:	and    r10d,0xc000
    7c479db0c267:	shl    r10d,0x10
    7c479db0c26b:	mov    r11d,edx
    7c479db0c26e:	and    r11d,0x100
    7c479db0c275:	shl    r11d,0x15
    7c479db0c279:	or     r10d,r11d
    7c479db0c27c:	and    edx,0x1
    7c479db0c27f:	shl    edx,0x1c
    7c479db0c282:	or     r10d,edx
    7c479db0c285:	btc    r10,0x1d
    7c479db0c28a:	mov    r11d,0xf0000000
    7c479db0c290:	and    r11,r10
    7c479db0c293:	movabs rsi,0xffffffff0fffffff
    7c479db0c29d:	and    rbx,rsi
    7c479db0c2a0:	or     rbx,r11
    7c479db0c2a3:	pop    r11
    7c479db0c2a5:	pop    r10
    7c479db0c2a7:	pop    rsi
    7c479db0c2a8:	pop    rdx
    7c479db0c2a9:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0c2b1:	mov    eax,0x410504
    7c479db0c2b6:	mov    QWORD PTR [r12+0x100],rax
    7c479db0c2be:	add    rsp,0x150
    7c479db0c2c5:	mov    eax,0x3
    7c479db0c2ca:	movabs r11,0x62fe87327ca0
    7c479db0c2d4:	jmp    r11
    7c479db0c2d7:	jmp    0x7c479db02c55
    7c479db0c2dc:	nop    DWORD PTR [rax+0x0]
    7c479db0c2e0:	sub    rsp,0x150
    7c479db0c2e7:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0c2ef:	mov    QWORD PTR [rsp],r11
    7c479db0c2f3:	cmp    DWORD PTR [r12+0x310],0x0
    7c479db0c2fc:	je     0x7c479db0c387
    7c479db0c302:	push   rdx
    7c479db0c303:	push   rsi
    7c479db0c304:	push   r10
    7c479db0c306:	push   r11
    7c479db0c308:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0c30d:	mov    r10d,edx
    7c479db0c310:	and    r10d,0xc000
    7c479db0c317:	shl    r10d,0x10
    7c479db0c31b:	mov    r11d,edx
    7c479db0c31e:	and    r11d,0x100
    7c479db0c325:	shl    r11d,0x15
    7c479db0c329:	or     r10d,r11d
    7c479db0c32c:	and    edx,0x1
    7c479db0c32f:	shl    edx,0x1c
    7c479db0c332:	or     r10d,edx
    7c479db0c335:	btc    r10,0x1d
    7c479db0c33a:	mov    r11d,0xf0000000
    7c479db0c340:	and    r11,r10
    7c479db0c343:	movabs rsi,0xffffffff0fffffff
    7c479db0c34d:	and    rbx,rsi
    7c479db0c350:	or     rbx,r11
    7c479db0c353:	pop    r11
    7c479db0c355:	pop    r10
    7c479db0c357:	pop    rsi
    7c479db0c358:	pop    rdx
    7c479db0c359:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0c361:	mov    eax,0x4106d0
    7c479db0c366:	mov    QWORD PTR [r12+0x100],rax
    7c479db0c36e:	add    rsp,0x150
    7c479db0c375:	mov    eax,0x3
    7c479db0c37a:	movabs r11,0x62fe87327ca0
    7c479db0c384:	jmp    r11
    7c479db0c387:	jmp    0x7c479db04995
    7c479db0c38c:	nop    DWORD PTR [rax+0x0]
    7c479db0c390:	sub    rsp,0x150
    7c479db0c397:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0c39f:	mov    QWORD PTR [rsp],r11
    7c479db0c3a3:	cmp    DWORD PTR [r12+0x310],0x0
    7c479db0c3ac:	je     0x7c479db0c437
    7c479db0c3b2:	push   rdx
    7c479db0c3b3:	push   rsi
    7c479db0c3b4:	push   r10
    7c479db0c3b6:	push   r11
    7c479db0c3b8:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0c3bd:	mov    r10d,edx
    7c479db0c3c0:	and    r10d,0xc000
    7c479db0c3c7:	shl    r10d,0x10
    7c479db0c3cb:	mov    r11d,edx
    7c479db0c3ce:	and    r11d,0x100
    7c479db0c3d5:	shl    r11d,0x15
    7c479db0c3d9:	or     r10d,r11d
    7c479db0c3dc:	and    edx,0x1
    7c479db0c3df:	shl    edx,0x1c
    7c479db0c3e2:	or     r10d,edx
    7c479db0c3e5:	btc    r10,0x1d
    7c479db0c3ea:	mov    r11d,0xf0000000
    7c479db0c3f0:	and    r11,r10
    7c479db0c3f3:	movabs rsi,0xffffffff0fffffff
    7c479db0c3fd:	and    rbx,rsi
    7c479db0c400:	or     rbx,r11
    7c479db0c403:	pop    r11
    7c479db0c405:	pop    r10
    7c479db0c407:	pop    rsi
    7c479db0c408:	pop    rdx
    7c479db0c409:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0c411:	mov    eax,0x4106dc
    7c479db0c416:	mov    QWORD PTR [r12+0x100],rax
    7c479db0c41e:	add    rsp,0x150
    7c479db0c425:	mov    eax,0x3
    7c479db0c42a:	movabs r11,0x62fe87327ca0
    7c479db0c434:	jmp    r11
    7c479db0c437:	jmp    0x7c479db049d2
    7c479db0c43c:	nop    DWORD PTR [rax+0x0]
    7c479db0c440:	sub    rsp,0x150
    7c479db0c447:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0c44f:	mov    QWORD PTR [rsp],r11
    7c479db0c453:	cmp    DWORD PTR [r12+0x310],0x0
    7c479db0c45c:	je     0x7c479db0c4e7
    7c479db0c462:	push   rdx
    7c479db0c463:	push   rsi
    7c479db0c464:	push   r10
    7c479db0c466:	push   r11
    7c479db0c468:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0c46d:	mov    r10d,edx
    7c479db0c470:	and    r10d,0xc000
    7c479db0c477:	shl    r10d,0x10
    7c479db0c47b:	mov    r11d,edx
    7c479db0c47e:	and    r11d,0x100
    7c479db0c485:	shl    r11d,0x15
    7c479db0c489:	or     r10d,r11d
    7c479db0c48c:	and    edx,0x1
    7c479db0c48f:	shl    edx,0x1c
    7c479db0c492:	or     r10d,edx
    7c479db0c495:	btc    r10,0x1d
    7c479db0c49a:	mov    r11d,0xf0000000
    7c479db0c4a0:	and    r11,r10
    7c479db0c4a3:	movabs rsi,0xffffffff0fffffff
    7c479db0c4ad:	and    rbx,rsi
    7c479db0c4b0:	or     rbx,r11
    7c479db0c4b3:	pop    r11
    7c479db0c4b5:	pop    r10
    7c479db0c4b7:	pop    rsi
    7c479db0c4b8:	pop    rdx
    7c479db0c4b9:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0c4c1:	mov    eax,0x4106e8
    7c479db0c4c6:	mov    QWORD PTR [r12+0x100],rax
    7c479db0c4ce:	add    rsp,0x150
    7c479db0c4d5:	mov    eax,0x3
    7c479db0c4da:	movabs r11,0x62fe87327ca0
    7c479db0c4e4:	jmp    r11
    7c479db0c4e7:	jmp    0x7c479db04a0d
    7c479db0c4ec:	nop    DWORD PTR [rax+0x0]
    7c479db0c4f0:	sub    rsp,0x150
    7c479db0c4f7:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0c4ff:	mov    QWORD PTR [rsp],r11
    7c479db0c503:	cmp    DWORD PTR [r12+0x310],0x0
    7c479db0c50c:	je     0x7c479db0c597
    7c479db0c512:	push   rdx
    7c479db0c513:	push   rsi
    7c479db0c514:	push   r10
    7c479db0c516:	push   r11
    7c479db0c518:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0c51d:	mov    r10d,edx
    7c479db0c520:	and    r10d,0xc000
    7c479db0c527:	shl    r10d,0x10
    7c479db0c52b:	mov    r11d,edx
    7c479db0c52e:	and    r11d,0x100
    7c479db0c535:	shl    r11d,0x15
    7c479db0c539:	or     r10d,r11d
    7c479db0c53c:	and    edx,0x1
    7c479db0c53f:	shl    edx,0x1c
    7c479db0c542:	or     r10d,edx
    7c479db0c545:	btc    r10,0x1d
    7c479db0c54a:	mov    r11d,0xf0000000
    7c479db0c550:	and    r11,r10
    7c479db0c553:	movabs rsi,0xffffffff0fffffff
    7c479db0c55d:	and    rbx,rsi
    7c479db0c560:	or     rbx,r11
    7c479db0c563:	pop    r11
    7c479db0c565:	pop    r10
    7c479db0c567:	pop    rsi
    7c479db0c568:	pop    rdx
    7c479db0c569:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0c571:	mov    eax,0x410704
    7c479db0c576:	mov    QWORD PTR [r12+0x100],rax
    7c479db0c57e:	add    rsp,0x150
    7c479db0c585:	mov    eax,0x3
    7c479db0c58a:	movabs r11,0x62fe87327ca0
    7c479db0c594:	jmp    r11
    7c479db0c597:	jmp    0x7c479db04b66
    7c479db0c59c:	nop    DWORD PTR [rax+0x0]
    7c479db0c5a0:	sub    rsp,0x150
    7c479db0c5a7:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0c5af:	mov    QWORD PTR [rsp],r11
    7c479db0c5b3:	cmp    DWORD PTR [r12+0x310],0x0
    7c479db0c5bc:	je     0x7c479db0c647
    7c479db0c5c2:	push   rdx
    7c479db0c5c3:	push   rsi
    7c479db0c5c4:	push   r10
    7c479db0c5c6:	push   r11
    7c479db0c5c8:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db0c5cd:	mov    r10d,edx
    7c479db0c5d0:	and    r10d,0xc000
    7c479db0c5d7:	shl    r10d,0x10
    7c479db0c5db:	mov    r11d,edx
    7c479db0c5de:	and    r11d,0x100
    7c479db0c5e5:	shl    r11d,0x15
    7c479db0c5e9:	or     r10d,r11d
    7c479db0c5ec:	and    edx,0x1
    7c479db0c5ef:	shl    edx,0x1c
    7c479db0c5f2:	or     r10d,edx
    7c479db0c5f5:	btc    r10,0x1d
    7c479db0c5fa:	mov    r11d,0xf0000000
    7c479db0c600:	and    r11,r10
    7c479db0c603:	movabs rsi,0xffffffff0fffffff
    7c479db0c60d:	and    rbx,rsi
    7c479db0c610:	or     rbx,r11
    7c479db0c613:	pop    r11
    7c479db0c615:	pop    r10
    7c479db0c617:	pop    rsi
    7c479db0c618:	pop    rdx
    7c479db0c619:	mov    QWORD PTR [r12+0x108],rbx
    7c479db0c621:	mov    eax,0x4103f0
    7c479db0c626:	mov    QWORD PTR [r12+0x100],rax
    7c479db0c62e:	add    rsp,0x150
    7c479db0c635:	mov    eax,0x3
    7c479db0c63a:	movabs r11,0x62fe87327ca0
    7c479db0c644:	jmp    r11
    7c479db0c647:	jmp    0x7c479db04d43
    7c479db0c64c:	nop    DWORD PTR [rax+0x0]
    7c479db0c650:	(bad)
    7c479db0c651:	(bad)
    7c479db0c652:	(bad)
    7c479db0c653:	(bad)
    7c479db0c654:	(bad)
    7c479db0c655:	(bad)
    7c479db0c656:	(bad)
    7c479db0c657:	jg     0x7c479db0c658
    7c479db0c659:	(bad)
    7c479db0c65a:	(bad)
    7c479db0c65b:	(bad)
    7c479db0c65c:	(bad)
    7c479db0c65d:	(bad)
    7c479db0c65e:	(bad)
    7c479db0c65f:	jg     0x7c479db0c661
    7c479db0c661:	add    BYTE PTR [rax],al
    7c479db0c663:	add    BYTE PTR [rax],al
    7c479db0c665:	add    BYTE PTR [rax],dl
    7c479db0c667:	add    BYTE PTR [rax],al
    7c479db0c669:	add    BYTE PTR [rax],al
    7c479db0c66b:	add    BYTE PTR [rax],al
    7c479db0c66d:	add    BYTE PTR [rax],dl
	...
