
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

000077db492fe000 <.data>:
    77db492fe000:	sub    rsp,0x10
    77db492fe004:	mov    r11,QWORD PTR [r12+0x398]
    77db492fe00c:	mov    QWORD PTR [rsp],r11
    77db492fe010:	mov    r13,QWORD PTR [r12+0xf8]
    77db492fe018:	sub    r13,0x1e0
    77db492fe01f:	mov    QWORD PTR [r12+0xf8],r13
    77db492fe027:	mov    r14d,0x420000
    77db492fe02d:	mov    QWORD PTR [r12+0x40],r14
    77db492fe032:	mov    r14d,0x420000
    77db492fe038:	mov    QWORD PTR [r12+0x48],r14
    77db492fe03d:	mov    r14,r13
    77db492fe040:	add    r14,0x1d0
    77db492fe047:	mov    r15,r14
    77db492fe04a:	add    r15,0x8
    77db492fe04e:	mov    rbp,QWORD PTR [r12+0xa0]
    77db492fe056:	mov    r8,QWORD PTR [r12+0x98]
    77db492fe05e:	mov    QWORD PTR [r14],rbp
    77db492fe061:	mov    r14d,0x0
    77db492fe067:	mov    DWORD PTR [r12+0x32c],r14d
    77db492fe06f:	mov    QWORD PTR [r15],r8
    77db492fe072:	mov    r14d,0x420aa0
    77db492fe078:	movdqu xmm2,XMMWORD PTR [r14]
    77db492fe07d:	movdqu XMMWORD PTR [r12+0x110],xmm2
    77db492fe087:	mov    r14d,0x420a30
    77db492fe08d:	movdqu xmm3,XMMWORD PTR [r14]
    77db492fe092:	movdqu XMMWORD PTR [r12+0x120],xmm3
    77db492fe09c:	mov    r14d,0x420ac0
    77db492fe0a2:	movdqu xmm4,XMMWORD PTR [r14]
    77db492fe0a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
    77db492fe0b1:	mov    r14d,0x420a60
    77db492fe0b7:	movdqu xmm5,XMMWORD PTR [r14]
    77db492fe0bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
    77db492fe0c6:	mov    r14d,0x430000
    77db492fe0cc:	mov    rax,r14
    77db492fe0cf:	add    rax,0xcd0
    77db492fe0d5:	mov    QWORD PTR [r12+0x98],rax
    77db492fe0dd:	mov    r15d,0x420ad0
    77db492fe0e3:	movdqu xmm6,XMMWORD PTR [r15]
    77db492fe0e8:	movdqu XMMWORD PTR [r12+0x150],xmm6
    77db492fe0f2:	mov    r15,QWORD PTR [r12+0x98]
    77db492fe0fa:	add    r15,0x10
    77db492fe0fe:	mov    rdi,QWORD PTR [r12+0x98]
    77db492fe106:	movdqu XMMWORD PTR [rdi],xmm2
    77db492fe10a:	movdqu XMMWORD PTR [r15],xmm3
    77db492fe10f:	mov    r15,QWORD PTR [r12+0x98]
    77db492fe117:	add    r15,0x20
    77db492fe11b:	mov    rbp,r15
    77db492fe11e:	add    rbp,0x10
    77db492fe122:	movdqu XMMWORD PTR [r15],xmm4
    77db492fe127:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    77db492fe12c:	mov    r15d,0x420a20
    77db492fe132:	movdqu xmm4,XMMWORD PTR [r15]
    77db492fe137:	movdqu XMMWORD PTR [r12+0x130],xmm4
    77db492fe141:	mov    r15d,0x420a10
    77db492fe147:	movdqu xmm5,XMMWORD PTR [r15]
    77db492fe14c:	movdqu XMMWORD PTR [r12+0x140],xmm5
    77db492fe156:	mov    r15,QWORD PTR [r12+0x98]
    77db492fe15e:	add    r15,0x100
    77db492fe165:	mov    rbp,r15
    77db492fe168:	add    rbp,0x10
    77db492fe16c:	movdqu XMMWORD PTR [r15],xmm2
    77db492fe171:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    77db492fe176:	mov    r15,QWORD PTR [r12+0x98]
    77db492fe17e:	add    r15,0x40
    77db492fe182:	mov    rbp,r15
    77db492fe185:	add    rbp,0x10
    77db492fe189:	movdqu XMMWORD PTR [r15],xmm6
    77db492fe18e:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    77db492fe193:	mov    r15d,0x420a00
    77db492fe199:	movdqu xmm2,XMMWORD PTR [r15]
    77db492fe19e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    77db492fe1a8:	mov    r15d,0x420a70
    77db492fe1ae:	movdqu xmm3,XMMWORD PTR [r15]
    77db492fe1b3:	movdqu XMMWORD PTR [r12+0x150],xmm3
    77db492fe1bd:	mov    r15d,0xf8d3
    77db492fe1c3:	mov    QWORD PTR [r12+0x48],r15
    77db492fe1c8:	mov    r15,QWORD PTR [r12+0x98]
    77db492fe1d0:	add    r15,0x60
    77db492fe1d4:	mov    rbp,r15
    77db492fe1d7:	add    rbp,0x10
    77db492fe1db:	movdqu XMMWORD PTR [r15],xmm5
    77db492fe1e0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    77db492fe1e5:	mov    r15d,0x420a80
    77db492fe1eb:	movdqu xmm2,XMMWORD PTR [r15]
    77db492fe1f0:	movdqu XMMWORD PTR [r12+0x130],xmm2
    77db492fe1fa:	mov    r15d,0x420a50
    77db492fe200:	movdqu xmm4,XMMWORD PTR [r15]
    77db492fe205:	movdqu XMMWORD PTR [r12+0x140],xmm4
    77db492fe20f:	mov    r15d,0xf8d3
    77db492fe215:	mov    ebp,0x421d
    77db492fe21a:	and    ebp,0xffff
    77db492fe220:	mov    rax,r15
    77db492fe223:	movabs rcx,0xffffffff0000ffff
    77db492fe22d:	and    rax,rcx
    77db492fe230:	mov    rdx,rbp
    77db492fe233:	shl    rdx,0x10
    77db492fe237:	mov    ecx,0xffff0000
    77db492fe23c:	and    rdx,rcx
    77db492fe23f:	or     rax,rdx
    77db492fe242:	mov    r8d,eax
    77db492fe245:	mov    QWORD PTR [r12+0x48],r8
    77db492fe24a:	mov    r15,QWORD PTR [r12+0x98]
    77db492fe252:	add    r15,0x80
    77db492fe259:	mov    rbp,r15
    77db492fe25c:	add    rbp,0x10
    77db492fe260:	movdqu XMMWORD PTR [r15],xmm3
    77db492fe265:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    77db492fe26a:	mov    r15d,0x420af0
    77db492fe270:	movdqu xmm2,XMMWORD PTR [r15]
    77db492fe275:	movdqu XMMWORD PTR [r12+0x130],xmm2
    77db492fe27f:	mov    r15d,0x420b00
    77db492fe285:	movdqu xmm3,XMMWORD PTR [r15]
    77db492fe28a:	movdqu XMMWORD PTR [r12+0x150],xmm3
    77db492fe294:	mov    r15d,0x3e8
    77db492fe29a:	mov    QWORD PTR [r12+0xa0],r15
    77db492fe2a2:	mov    r15,QWORD PTR [r12+0x98]
    77db492fe2aa:	add    r15,0xa0
    77db492fe2b1:	mov    rbp,r15
    77db492fe2b4:	add    rbp,0x10
    77db492fe2b8:	movdqu XMMWORD PTR [r15],xmm4
    77db492fe2bd:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    77db492fe2c2:	mov    r15d,0x420ae0
    77db492fe2c8:	movdqu xmm2,XMMWORD PTR [r15]
    77db492fe2cd:	movdqu XMMWORD PTR [r12+0x130],xmm2
    77db492fe2d7:	mov    r15d,0x420a90
    77db492fe2dd:	movdqu xmm4,XMMWORD PTR [r15]
    77db492fe2e2:	movdqu XMMWORD PTR [r12+0x140],xmm4
    77db492fe2ec:	mov    r15,r13
    77db492fe2ef:	add    r15,0x180
    77db492fe2f6:	mov    rbp,r15
    77db492fe2f9:	add    rbp,0x8
    77db492fe2fd:	mov    r9,QWORD PTR [r12+0x200]
    77db492fe305:	mov    r14,QWORD PTR [r12+0x1f0]
    77db492fe30d:	mov    QWORD PTR [r15],r9
    77db492fe310:	mov    QWORD PTR [rbp+0x0],r14
    77db492fe314:	mov    r14,QWORD PTR [r12+0x98]
    77db492fe31c:	add    r14,0xc0
    77db492fe323:	mov    r15,r14
    77db492fe326:	add    r15,0x10
    77db492fe32a:	movdqu XMMWORD PTR [r14],xmm3
    77db492fe32f:	movdqu XMMWORD PTR [r15],xmm2
    77db492fe334:	mov    r14d,0x420ab0
    77db492fe33a:	movdqu xmm2,XMMWORD PTR [r14]
    77db492fe33f:	movdqu XMMWORD PTR [r12+0x130],xmm2
    77db492fe349:	mov    r14d,0x420b18
    77db492fe34f:	mov    r15,QWORD PTR [r14]
    77db492fe352:	mov    r14d,0x0
    77db492fe358:	mov    QWORD PTR [r12+0x110],r15
    77db492fe360:	mov    QWORD PTR [r12+0x118],r14
    77db492fe368:	mov    r14d,0x420b20
    77db492fe36e:	mov    QWORD PTR [r12+0x40],r14
    77db492fe373:	mov    r14,QWORD PTR [r12+0x98]
    77db492fe37b:	add    r14,0xe0
    77db492fe382:	mov    rbp,r14
    77db492fe385:	add    rbp,0x10
    77db492fe389:	movdqu XMMWORD PTR [r14],xmm4
    77db492fe38e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    77db492fe393:	mov    r14d,0x420b80
    77db492fe399:	movdqu xmm2,XMMWORD PTR [r14]
    77db492fe39e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    77db492fe3a8:	mov    r14,QWORD PTR [r12+0x98]
    77db492fe3b0:	add    r14,0x120
    77db492fe3b7:	mov    QWORD PTR [r14],r15
    77db492fe3ba:	mov    r14d,0x420b60
    77db492fe3c0:	mov    r15d,0x420b70
    77db492fe3c6:	movdqu xmm3,XMMWORD PTR [r14]
    77db492fe3cb:	movdqu xmm4,XMMWORD PTR [r15]
    77db492fe3d0:	movdqu XMMWORD PTR [r12+0x120],xmm3
    77db492fe3da:	movdqu XMMWORD PTR [r12+0x110],xmm4
    77db492fe3e4:	mov    r14,r13
    77db492fe3e7:	add    r14,0x160
    77db492fe3ee:	movdqu XMMWORD PTR [r14],xmm2
    77db492fe3f3:	mov    r14,r13
    77db492fe3f6:	add    r14,0x190
    77db492fe3fd:	mov    r15,r14
    77db492fe400:	add    r15,0x8
    77db492fe404:	mov    rbp,QWORD PTR [r12+0x1e0]
    77db492fe40c:	mov    r9,QWORD PTR [r12+0x1d0]
    77db492fe414:	mov    QWORD PTR [r14],rbp
    77db492fe417:	mov    QWORD PTR [r15],r9
    77db492fe41a:	mov    r14,r13
    77db492fe41d:	add    r14,0x140
    77db492fe424:	mov    r15,r14
    77db492fe427:	add    r15,0x10
    77db492fe42b:	movdqu XMMWORD PTR [r14],xmm3
    77db492fe430:	movdqu XMMWORD PTR [r15],xmm4
    77db492fe435:	mov    r14d,0x420b20
    77db492fe43b:	mov    r15d,0x420b30
    77db492fe441:	movdqu xmm2,XMMWORD PTR [r14]
    77db492fe446:	movdqu xmm3,XMMWORD PTR [r15]
    77db492fe44b:	movdqu XMMWORD PTR [r12+0x110],xmm2
    77db492fe455:	movdqu XMMWORD PTR [r12+0x120],xmm3
    77db492fe45f:	mov    r14,r13
    77db492fe462:	add    r14,0x1a0
    77db492fe469:	mov    r15,r14
    77db492fe46c:	add    r15,0x8
    77db492fe470:	mov    rbp,QWORD PTR [r12+0x1c0]
    77db492fe478:	mov    r9,QWORD PTR [r12+0x1b0]
    77db492fe480:	mov    QWORD PTR [r14],rbp
    77db492fe483:	mov    QWORD PTR [r15],r9
    77db492fe486:	mov    r14,r13
    77db492fe489:	add    r14,0x1b0
    77db492fe490:	mov    r15,r14
    77db492fe493:	add    r15,0x8
    77db492fe497:	mov    rbp,QWORD PTR [r12+0x1a0]
    77db492fe49f:	mov    r9,QWORD PTR [r12+0x190]
    77db492fe4a7:	mov    QWORD PTR [r14],rbp
    77db492fe4aa:	mov    QWORD PTR [r15],r9
    77db492fe4ad:	mov    r14,r13
    77db492fe4b0:	add    r14,0x100
    77db492fe4b7:	mov    r15,r14
    77db492fe4ba:	add    r15,0x10
    77db492fe4be:	movdqu XMMWORD PTR [r14],xmm2
    77db492fe4c3:	movdqu XMMWORD PTR [r15],xmm3
    77db492fe4c8:	mov    r14d,0x420b40
    77db492fe4ce:	mov    r15d,0x420b50
    77db492fe4d4:	movdqu xmm2,XMMWORD PTR [r14]
    77db492fe4d9:	movdqu xmm3,XMMWORD PTR [r15]
    77db492fe4de:	movdqu XMMWORD PTR [r12+0x110],xmm2
    77db492fe4e8:	movdqu XMMWORD PTR [r12+0x130],xmm3
    77db492fe4f2:	mov    r14,r13
    77db492fe4f5:	add    r14,0x1c0
    77db492fe4fc:	mov    r15,r14
    77db492fe4ff:	add    r15,0x8
    77db492fe503:	mov    rbp,QWORD PTR [r12+0xe8]
    77db492fe50b:	mov    r9,QWORD PTR [r12+0xf0]
    77db492fe513:	mov    QWORD PTR [r14],rbp
    77db492fe516:	mov    QWORD PTR [r15],r9
    77db492fe519:	mov    r14,QWORD PTR [r12+0x98]
    77db492fe521:	add    r14,0x128
    77db492fe528:	mov    DWORD PTR [r14],r8d
    77db492fe52b:	mov    r14,r13
    77db492fe52e:	add    r14,0x120
    77db492fe535:	mov    r15,r14
    77db492fe538:	add    r15,0x10
    77db492fe53c:	movdqu XMMWORD PTR [r14],xmm2
    77db492fe541:	movdqu XMMWORD PTR [r15],xmm3
    77db492fe546:	add    r13,0x100
    77db492fe54d:	mov    QWORD PTR [r12],r13
    77db492fe551:	mov    r13d,0x0
    77db492fe557:	mov    rcx,QWORD PTR [r12+0x98]
    77db492fe55f:	or     r13,rcx
    77db492fe562:	mov    QWORD PTR [r12+0x8],r13
    77db492fe567:	mov    r13d,0x12c
    77db492fe56d:	mov    QWORD PTR [r12+0x10],r13
    77db492fe572:	mov    r13d,0x410284
    77db492fe578:	mov    QWORD PTR [r12+0xf0],r13
    77db492fe580:	mov    r13d,0x410728
    77db492fe586:	mov    QWORD PTR [r12+0x100],r13
    77db492fe58e:	mov    r11,QWORD PTR [rsp]
    77db492fe592:	mov    QWORD PTR [r12+0x398],r11
    77db492fe59a:	mov    edi,0x410728
    77db492fe59f:	mov    QWORD PTR [r12+0x100],rdi
    77db492fe5a7:	add    rsp,0x10
    77db492fe5ab:	nop    DWORD PTR [rax+rax*1+0x0]
    77db492fe5b0:	jmp    QWORD PTR [rip+0x2]        # 0x77db492fe5b8
    77db492fe5b6:	xchg   ax,ax
    77db492fe5b8:	loopne 0x77db492fe59f
    77db492fe5ba:	(bad)
    77db492fe5bb:	rex.WB (bad) [r15+0x0]
    77db492fe5bf:	add    al,cl
    77db492fe5c1:	in     eax,0x2f
    77db492fe5c3:	rex.WB (bad) [r15+0x0]
    77db492fe5c7:	add    BYTE PTR [rcx-0x45],cl
    77db492fe5ca:	rex cdq
    77db492fe5cc:	mov    eax,0x60ebc8
    77db492fe5d1:	add    BYTE PTR [rcx-0x1],al
    77db492fe5d4:	jrcxz  0x77db492fe566
    77db492fe5d6:	nop
    77db492fe5d7:	nop
