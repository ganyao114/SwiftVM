
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/0/6.bin:     file format binary


Disassembly of section .data:

000077db49301740 <.data>:
    77db49301740:	sub    rsp,0x10
    77db49301744:	mov    r11,QWORD PTR [r12+0x398]
    77db4930174c:	mov    QWORD PTR [rsp],r11
    77db49301750:	mov    r13d,DWORD PTR [r12]
    77db49301754:	mov    r14d,r13d
    77db49301757:	mov    r14d,r14d
    77db4930175a:	shr    r14d,0x10
    77db4930175e:	xor    r13d,r14d
    77db49301761:	mov    QWORD PTR [r12+0x40],r13
    77db49301766:	mov    r14d,0x352d
    77db4930176c:	mov    QWORD PTR [r12+0x48],r14
    77db49301771:	mov    r14d,0x352d
    77db49301777:	mov    r15d,0x7feb
    77db4930177d:	and    r15d,0xffff
    77db49301784:	mov    rax,r14
    77db49301787:	movabs rcx,0xffffffff0000ffff
    77db49301791:	and    rax,rcx
    77db49301794:	mov    rdx,r15
    77db49301797:	shl    rdx,0x10
    77db4930179b:	mov    ecx,0xffff0000
    77db493017a0:	and    rdx,rcx
    77db493017a3:	or     rax,rdx
    77db493017a6:	mov    ebp,eax
    77db493017a8:	mov    QWORD PTR [r12+0x48],rbp
    77db493017ad:	mov    r14d,0x0
    77db493017b3:	imul   r13d,ebp
    77db493017b7:	mov    r15d,r14d
    77db493017ba:	add    r15d,r13d
    77db493017bd:	mov    QWORD PTR [r12+0x40],r15
    77db493017c2:	mov    r13d,0xa68b
    77db493017c8:	mov    QWORD PTR [r12+0x48],r13
    77db493017cd:	mov    r13d,0xa68b
    77db493017d3:	mov    r14d,0x846c
    77db493017d9:	and    r14d,0xffff
    77db493017e0:	mov    rax,r13
    77db493017e3:	movabs rcx,0xffffffff0000ffff
    77db493017ed:	and    rax,rcx
    77db493017f0:	mov    rdx,r14
    77db493017f3:	shl    rdx,0x10
    77db493017f7:	mov    ecx,0xffff0000
    77db493017fc:	and    rdx,rcx
    77db493017ff:	or     rax,rdx
    77db49301802:	mov    ebp,eax
    77db49301804:	mov    QWORD PTR [r12+0x48],rbp
    77db49301809:	mov    r13d,r15d
    77db4930180c:	mov    r13d,r13d
    77db4930180f:	shr    r13d,0xf
    77db49301813:	xor    r15d,r13d
    77db49301816:	mov    QWORD PTR [r12+0x40],r15
    77db4930181b:	mov    r13d,0x0
    77db49301821:	imul   r15d,ebp
    77db49301825:	mov    r14d,r13d
    77db49301828:	add    r14d,r15d
    77db4930182b:	mov    QWORD PTR [r12+0x40],r14
    77db49301830:	mov    r13d,r14d
    77db49301833:	mov    r13d,r13d
    77db49301836:	shr    r13d,0x10
    77db4930183a:	xor    r14d,r13d
    77db4930183d:	mov    QWORD PTR [r12],r14
    77db49301841:	mov    rcx,QWORD PTR [r12+0x380]
    77db49301849:	jrcxz  0x77db49301850
    77db4930184b:	jmp    0x77db49301885
    77db49301850:	mov    r13,QWORD PTR [r12+0xf0]
    77db49301858:	mov    QWORD PTR [r12+0x100],r13
    77db49301860:	mov    r11,QWORD PTR [rsp]
    77db49301864:	mov    QWORD PTR [r12+0x398],r11
    77db4930186c:	mov    rdi,QWORD PTR [r12+0x100]
    77db49301874:	add    rsp,0x10
    77db49301878:	movabs r11,0x60ebc8b89940
    77db49301882:	jmp    r11
    77db49301885:	mov    eax,0x4109c8
    77db4930188a:	mov    QWORD PTR [r12+0x100],rax
    77db49301892:	push   rdx
    77db49301893:	push   rsi
    77db49301894:	push   r10
    77db49301896:	push   r11
    77db49301898:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930189d:	mov    r10d,edx
    77db493018a0:	and    r10d,0xc000
    77db493018a7:	shl    r10d,0x10
    77db493018ab:	mov    r11d,edx
    77db493018ae:	and    r11d,0x100
    77db493018b5:	shl    r11d,0x15
    77db493018b9:	or     r10d,r11d
    77db493018bc:	and    edx,0x1
    77db493018bf:	shl    edx,0x1c
    77db493018c2:	or     r10d,edx
    77db493018c5:	btc    r10,0x1d
    77db493018ca:	mov    r11d,0xf0000000
    77db493018d0:	and    r11,r10
    77db493018d3:	movabs rsi,0xffffffff0fffffff
    77db493018dd:	and    rbx,rsi
    77db493018e0:	or     rbx,r11
    77db493018e3:	pop    r11
    77db493018e5:	pop    r10
    77db493018e7:	pop    rsi
    77db493018e8:	pop    rdx
    77db493018e9:	mov    QWORD PTR [r12+0x108],rbx
    77db493018f1:	add    rsp,0x10
    77db493018f5:	mov    eax,0xc
    77db493018fa:	movabs r11,0x60ebc8b89ca0
    77db49301904:	jmp    r11
    77db49301907:	nop
