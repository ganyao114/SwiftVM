
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/0/8.bin:     file format binary


Disassembly of section .data:

000077db49302170 <.data>:
    77db49302170:	sub    rsp,0x150
    77db49302177:	mov    r11,QWORD PTR [r12+0x398]
    77db4930217f:	mov    QWORD PTR [rsp],r11
    77db49302183:	cmp    DWORD PTR [r12+0x310],0x0
    77db4930218c:	je     0x77db49302217
    77db49302192:	push   rdx
    77db49302193:	push   rsi
    77db49302194:	push   r10
    77db49302196:	push   r11
    77db49302198:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930219d:	mov    r10d,edx
    77db493021a0:	and    r10d,0xc000
    77db493021a7:	shl    r10d,0x10
    77db493021ab:	mov    r11d,edx
    77db493021ae:	and    r11d,0x100
    77db493021b5:	shl    r11d,0x15
    77db493021b9:	or     r10d,r11d
    77db493021bc:	and    edx,0x1
    77db493021bf:	shl    edx,0x1c
    77db493021c2:	or     r10d,edx
    77db493021c5:	btc    r10,0x1d
    77db493021ca:	mov    r11d,0xf0000000
    77db493021d0:	and    r11,r10
    77db493021d3:	movabs rsi,0xffffffff0fffffff
    77db493021dd:	and    rbx,rsi
    77db493021e0:	or     rbx,r11
    77db493021e3:	pop    r11
    77db493021e5:	pop    r10
    77db493021e7:	pop    rsi
    77db493021e8:	pop    rdx
    77db493021e9:	mov    QWORD PTR [r12+0x108],rbx
    77db493021f1:	mov    eax,0x4103f8
    77db493021f6:	mov    QWORD PTR [r12+0x100],rax
    77db493021fe:	add    rsp,0x150
    77db49302205:	mov    eax,0x3
    77db4930220a:	movabs r11,0x60ebc8b89ca0
    77db49302214:	jmp    r11
    77db49302217:	mov    r13d,DWORD PTR [r12+0x98]
    77db4930221f:	add    r13d,0x1
    77db49302223:	mov    QWORD PTR [r12+0x98],r13
    77db4930222b:	sub    r13d,0x10000
    77db49302232:	mov    rcx,QWORD PTR [r12+0x380]
    77db4930223a:	jrcxz  0x77db49302241
    77db4930223c:	jmp    0x77db4930bbf5
    77db49302241:	jne    0x77db4930225a
    77db49302247:	mov    r11,rax
    77db4930224a:	lahf
    77db4930224b:	seto   al
    77db4930224e:	mov    WORD PTR [rsp],ax
    77db49302252:	mov    rax,r11
    77db49302255:	jmp    0x77db4930226d
    77db4930225a:	mov    r11,rax
    77db4930225d:	lahf
    77db4930225e:	seto   al
    77db49302261:	mov    WORD PTR [rsp],ax
    77db49302265:	mov    rax,r11
    77db49302268:	jmp    0x77db49304d43
    77db4930226d:	mov    r13d,0x420000
    77db49302273:	mov    QWORD PTR [r12+0x40],r13
    77db49302278:	movabs r13,0x100000001
    77db49302282:	mov    r14d,0x0
    77db49302288:	mov    QWORD PTR [r12+0x110],r13
    77db49302290:	mov    QWORD PTR [r12+0x118],r14
    77db49302298:	movabs r13,0x3fa0000000000000
    77db493022a2:	mov    QWORD PTR [r12+0x50],r13
    77db493022a7:	mov    r13d,0x420b10
    77db493022ad:	mov    r14,QWORD PTR [r13+0x0]
    77db493022b1:	mov    r13d,0x0
    77db493022b7:	mov    QWORD PTR [r12+0x120],r14
    77db493022bf:	mov    QWORD PTR [r12+0x128],r13
    77db493022c7:	movabs r13,0x4100000041
    77db493022d1:	mov    r14d,0x0
    77db493022d7:	mov    QWORD PTR [r12+0x140],r13
    77db493022df:	mov    QWORD PTR [r12+0x148],r14
    77db493022e7:	movabs r13,0x3fc0000000000000
    77db493022f1:	movabs r14,0x3fc0000000000000
    77db493022fb:	mov    QWORD PTR [r12+0x150],r13
    77db49302303:	mov    QWORD PTR [r12+0x158],r14
    77db4930230b:	movabs r13,0x200000002
    77db49302315:	mov    r14d,0x0
    77db4930231b:	mov    QWORD PTR [r12+0x160],r13
    77db49302323:	mov    QWORD PTR [r12+0x168],r14
    77db4930232b:	movabs r13,0x3fa0000000000000
    77db49302335:	mov    QWORD PTR [r12+0x130],r13
    77db4930233d:	mov    QWORD PTR [r12+0x138],r13
    77db49302345:	mov    r13d,0x2
    77db4930234b:	mov    QWORD PTR [r12+0x170],r13
    77db49302353:	mov    QWORD PTR [r12+0x178],r13
    77db4930235b:	mov    r13d,0x420000
    77db49302361:	mov    QWORD PTR [r12+0x40],r13
    77db49302366:	mov    r13d,0x430000
    77db4930236c:	mov    QWORD PTR [r12+0x50],r13
    77db49302371:	mov    r13d,0x420a40
    77db49302377:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    77db4930237d:	movdqu XMMWORD PTR [r12+0x180],xmm2
    77db49302387:	mov    r13d,0x0
    77db4930238d:	mov    QWORD PTR [r12+0x48],r13
    77db49302392:	mov    r13d,0x431000
    77db49302398:	add    r13,0xe00
    77db4930239f:	mov    QWORD PTR [r12+0x40],r13
    77db493023a4:	mov    r13d,0x430cb8
    77db493023aa:	mov    r14d,DWORD PTR [r12]
    77db493023ae:	mov    DWORD PTR [r13+0x0],r14d
    77db493023b2:	mov    r13d,0x0
    77db493023b8:	mov    DWORD PTR [r12+0x32c],r13d
    77db493023c0:	mov    r13d,0x432000
    77db493023c6:	mov    QWORD PTR [r12+0x50],r13
    77db493023cb:	mov    r11,rax
    77db493023ce:	movzx  eax,WORD PTR [rsp]
    77db493023d2:	add    al,0x7f
    77db493023d4:	sahf
    77db493023d5:	mov    rax,r11
    77db493023d8:	jmp    0x77db493023dd
    77db493023dd:	mov    r13,QWORD PTR [r12+0x180]
    77db493023e5:	mov    r14,QWORD PTR [r12+0x188]
    77db493023ed:	mov    r15d,0x0
    77db493023f3:	mov    r11,rax
    77db493023f6:	lahf
    77db493023f7:	seto   al
    77db493023fa:	mov    WORD PTR [rsp],ax
    77db493023fe:	mov    rax,r11
    77db49302401:	mov    ecx,0xffffffff
    77db49302406:	and    r13,rcx
    77db49302409:	mov    rbp,r15
    77db4930240c:	or     rbp,r13
    77db4930240f:	mov    ecx,0xffffffff
    77db49302414:	and    r14,rcx
    77db49302417:	shl    r14,0x20
    77db4930241b:	or     rbp,r14
    77db4930241e:	mov    QWORD PTR [r12+0x210],rbp
    77db49302426:	mov    QWORD PTR [r12+0x218],r15
    77db4930242e:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    77db49302438:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    77db49302442:	movdqa xmm1,xmm3
    77db49302446:	psubd  xmm2,xmm1
    77db4930244a:	movdqa xmm14,xmm2
    77db4930244f:	movdqa xmm1,xmm14
    77db49302454:	movq   rax,xmm1
    77db49302459:	mov    r13,rax
    77db4930245c:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    77db49302466:	movdqu xmm4,XMMWORD PTR [r12+0x170]
    77db49302470:	movdqa xmm1,xmm4
    77db49302474:	paddq  xmm2,xmm1
    77db49302478:	movdqu XMMWORD PTR [r12+0x180],xmm2
    77db49302482:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    77db4930248c:	movdqa xmm1,xmm2
    77db49302490:	paddd  xmm3,xmm1
    77db49302494:	movdqa xmm14,xmm3
    77db49302499:	movdqa xmm1,xmm14
    77db4930249e:	movq   rax,xmm1
    77db493024a3:	mov    r14,rax
    77db493024a6:	mov    r15d,0x0
    77db493024ac:	mov    QWORD PTR [r12+0x120],r14
    77db493024b4:	mov    QWORD PTR [r12+0x128],r15
    77db493024bc:	mov    r14d,0x0
    77db493024c2:	mov    ecx,0xffffffff
    77db493024c7:	mov    r15,r13
    77db493024ca:	and    r15,rcx
    77db493024cd:	mov    rbp,r14
    77db493024d0:	or     rbp,r15
    77db493024d3:	shr    r13,0x20
    77db493024d7:	mov    ecx,0xffffffff
    77db493024dc:	and    r13,rcx
    77db493024df:	or     r14,r13
    77db493024e2:	mov    QWORD PTR [r12+0x220],rbp
    77db493024ea:	mov    QWORD PTR [r12+0x228],r14
    77db493024f2:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    77db493024fc:	movdqu xmm3,XMMWORD PTR [r12+0x110]
    77db49302506:	movdqa xmm1,xmm3
    77db4930250a:	paddd  xmm2,xmm1
    77db4930250e:	movdqa xmm14,xmm2
    77db49302513:	movdqa xmm1,xmm14
    77db49302518:	movq   rax,xmm1
    77db4930251d:	mov    r13,rax
    77db49302520:	mov    r14d,0x0
    77db49302526:	mov    QWORD PTR [r12+0x210],r13
    77db4930252e:	mov    QWORD PTR [r12+0x218],r14
    77db49302536:	lea    r13,[r12]
    77db4930253a:	movabs r14,0xb6e61da31
    77db49302544:	mov    r15d,0x410468
    77db4930254a:	mov    rdx,QWORD PTR [rsp]
    77db4930254e:	mov    r10d,edx
    77db49302551:	and    r10d,0xc000
    77db49302558:	shl    r10d,0x10
    77db4930255c:	mov    r11d,edx
    77db4930255f:	and    r11d,0x100
    77db49302566:	shl    r11d,0x15
    77db4930256a:	or     r10d,r11d
    77db4930256d:	and    edx,0x1
    77db49302570:	shl    edx,0x1c
    77db49302573:	or     r10d,edx
    77db49302576:	btc    r10,0x1d
    77db4930257b:	mov    r11d,0xf0000000
    77db49302581:	and    r11,r10
    77db49302584:	movabs rsi,0xffffffff0fffffff
    77db4930258e:	and    rbx,rsi
    77db49302591:	or     rbx,r11
    77db49302594:	mov    QWORD PTR [r12+0x378],0x3
    77db493025a0:	mov    QWORD PTR [r12+0x108],rbx
    77db493025a8:	stmxcsr DWORD PTR [r12-0x28]
    77db493025ae:	mov    r10d,DWORD PTR [r12-0x28]
    77db493025b3:	test   r10d,0x3f
    77db493025ba:	je     0x77db493025df
    77db493025c0:	mov    r11d,r10d
    77db493025c3:	shr    r10d,1
    77db493025c6:	and    r10d,0x1e
    77db493025ca:	and    r11d,0x1
    77db493025ce:	or     r10d,r11d
    77db493025d1:	or     DWORD PTR [r12+0x314],r10d
    77db493025d9:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db493025df:	ldmxcsr DWORD PTR [r12-0x38]
    77db493025e5:	movabs r11,0x60ebc89eb5e0
    77db493025ef:	mov    rdi,r13
    77db493025f2:	mov    rsi,r14
    77db493025f5:	mov    rdx,r15
    77db493025f8:	call   r11
    77db493025fb:	ldmxcsr DWORD PTR [r12-0x28]
    77db49302601:	mov    rbx,QWORD PTR [r12+0x108]
    77db49302609:	mov    QWORD PTR [r12+0x378],0x2
    77db49302615:	mov    rbp,rax
    77db49302618:	mov    r13,QWORD PTR [r12+0x210]
    77db49302620:	mov    r14d,0x0
    77db49302626:	mov    ecx,0xffffffff
    77db4930262b:	mov    r15,r13
    77db4930262e:	and    r15,rcx
    77db49302631:	mov    rbp,r14
    77db49302634:	or     rbp,r15
    77db49302637:	shr    r13,0x20
    77db4930263b:	mov    ecx,0xffffffff
    77db49302640:	and    r13,rcx
    77db49302643:	or     r14,r13
    77db49302646:	mov    QWORD PTR [r12+0x210],rbp
    77db4930264e:	mov    QWORD PTR [r12+0x218],r14
    77db49302656:	lea    r13,[r12]
    77db4930265a:	movabs r14,0xb6e61da10
    77db49302664:	mov    r15d,0x410470
    77db4930266a:	mov    QWORD PTR [r12+0x378],0x3
    77db49302676:	mov    QWORD PTR [r12+0x108],rbx
    77db4930267e:	stmxcsr DWORD PTR [r12-0x28]
    77db49302684:	mov    r10d,DWORD PTR [r12-0x28]
    77db49302689:	test   r10d,0x3f
    77db49302690:	je     0x77db493026b5
    77db49302696:	mov    r11d,r10d
    77db49302699:	shr    r10d,1
    77db4930269c:	and    r10d,0x1e
    77db493026a0:	and    r11d,0x1
    77db493026a4:	or     r10d,r11d
    77db493026a7:	or     DWORD PTR [r12+0x314],r10d
    77db493026af:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db493026b5:	ldmxcsr DWORD PTR [r12-0x38]
    77db493026bb:	movabs r11,0x60ebc89eb5e0
    77db493026c5:	mov    rdi,r13
    77db493026c8:	mov    rsi,r14
    77db493026cb:	mov    rdx,r15
    77db493026ce:	call   r11
    77db493026d1:	ldmxcsr DWORD PTR [r12-0x28]
    77db493026d7:	mov    rbx,QWORD PTR [r12+0x108]
    77db493026df:	mov    QWORD PTR [r12+0x378],0x2
    77db493026eb:	mov    rbp,rax
    77db493026ee:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    77db493026f8:	movdqu xmm3,XMMWORD PTR [r12+0x150]
    77db49302702:	movdqa xmm0,xmm2
    77db49302706:	movdqa xmm1,xmm3
    77db4930270a:	mulpd  xmm0,xmm1
    77db4930270e:	movdqa xmm14,xmm0
    77db49302713:	movdqu xmm15,XMMWORD PTR [rip+0x9f34]        # 0x77db4930c650
    77db4930271c:	pand   xmm14,xmm15
    77db49302721:	movdqu xmm15,XMMWORD PTR [rip+0x9f36]        # 0x77db4930c660
    77db4930272a:	pcmpeqq xmm14,xmm15
    77db49302730:	movdqa xmm15,xmm0
    77db49302735:	cmpunordpd xmm15,xmm0
    77db4930273b:	por    xmm14,xmm15
    77db49302740:	pmovmskb ecx,xmm14
    77db49302745:	jrcxz  0x77db4930274c
    77db49302747:	jmp    0x77db49304dbd
    77db4930274c:	movdqa xmm4,xmm0
    77db49302750:	movdqu XMMWORD PTR [r12+0x220],xmm4
    77db4930275a:	mov    r13,QWORD PTR [r12+0x48]
    77db4930275f:	mov    r14,QWORD PTR [r12+0x50]
    77db49302764:	add    r14,r13
    77db49302767:	movdqu XMMWORD PTR [r14],xmm4
    77db4930276c:	mov    r14d,0x0
    77db49302772:	mov    DWORD PTR [r12+0x32c],r14d
    77db4930277a:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    77db49302784:	movdqu xmm3,XMMWORD PTR [r12+0x130]
    77db4930278e:	movdqa xmm0,xmm2
    77db49302792:	movdqa xmm1,xmm3
    77db49302796:	mulpd  xmm0,xmm1
    77db4930279a:	movdqa xmm14,xmm0
    77db4930279f:	movdqu xmm15,XMMWORD PTR [rip+0x9ea8]        # 0x77db4930c650
    77db493027a8:	pand   xmm14,xmm15
    77db493027ad:	movdqu xmm15,XMMWORD PTR [rip+0x9eaa]        # 0x77db4930c660
    77db493027b6:	pcmpeqq xmm14,xmm15
    77db493027bc:	movdqa xmm15,xmm0
    77db493027c1:	cmpunordpd xmm15,xmm0
    77db493027c7:	por    xmm14,xmm15
    77db493027cc:	pmovmskb ecx,xmm14
    77db493027d1:	jrcxz  0x77db493027d8
    77db493027d3:	jmp    0x77db49304de1
    77db493027d8:	movdqa xmm4,xmm0
    77db493027dc:	movdqu XMMWORD PTR [r12+0x210],xmm4
    77db493027e6:	mov    r14,QWORD PTR [r12+0x40]
    77db493027eb:	add    r14,r13
    77db493027ee:	movdqu XMMWORD PTR [r14],xmm4
    77db493027f3:	add    r13,0x10
    77db493027f7:	mov    QWORD PTR [r12+0x48],r13
    77db493027fc:	sub    r13,0x200
    77db49302803:	mov    rcx,QWORD PTR [r12+0x380]
    77db4930280b:	jrcxz  0x77db49302812
    77db4930280d:	jmp    0x77db4930bc89
    77db49302812:	jne    0x77db493023dd
    77db49302818:	mov    r11,rax
    77db4930281b:	lahf
    77db4930281c:	seto   al
    77db4930281f:	mov    WORD PTR [rsp],ax
    77db49302823:	mov    rax,r11
    77db49302826:	jmp    0x77db4930282b
    77db4930282b:	mov    r13,QWORD PTR [r12+0x50]
    77db49302830:	mov    r14,r13
    77db49302833:	add    r14,0x80
    77db4930283a:	mov    r15,r14
    77db4930283d:	add    r15,0x10
    77db49302841:	movdqu xmm2,XMMWORD PTR [r14]
    77db49302846:	movdqu xmm3,XMMWORD PTR [r15]
    77db4930284b:	movdqu XMMWORD PTR [r12+0x130],xmm2
    77db49302855:	movdqu XMMWORD PTR [r12+0x110],xmm3
    77db4930285f:	mov    r14d,0x0
    77db49302865:	mov    r15d,0x0
    77db4930286b:	mov    QWORD PTR [r12+0x1b0],r14
    77db49302873:	mov    QWORD PTR [r12+0x1b8],r15
    77db4930287b:	mov    r14,r13
    77db4930287e:	add    r14,0x40
    77db49302882:	mov    r15,r14
    77db49302885:	add    r15,0x10
    77db49302889:	movdqu xmm4,XMMWORD PTR [r14]
    77db4930288e:	movdqu xmm5,XMMWORD PTR [r15]
    77db49302893:	movdqu XMMWORD PTR [r12+0x250],xmm4
    77db4930289d:	movdqu XMMWORD PTR [r12+0x120],xmm5
    77db493028a7:	mov    r14d,0x0
    77db493028ad:	mov    QWORD PTR [r12+0x48],r14
    77db493028b2:	mov    r14,r13
    77db493028b5:	add    r14,0x10
    77db493028b9:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    77db493028bf:	movdqu xmm6,XMMWORD PTR [r14]
    77db493028c4:	movdqu XMMWORD PTR [r12+0x170],xmm4
    77db493028ce:	movdqu XMMWORD PTR [r12+0x180],xmm6
    77db493028d8:	mov    r14,QWORD PTR [r12+0xf8]
    77db493028e0:	mov    r15,r14
    77db493028e3:	add    r15,0xe0
    77db493028ea:	mov    rbp,r15
    77db493028ed:	add    rbp,0x10
    77db493028f1:	movdqu XMMWORD PTR [r15],xmm3
    77db493028f6:	mov    r15d,0x0
    77db493028fc:	mov    DWORD PTR [r12+0x32c],r15d
    77db49302904:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    77db49302909:	mov    r15,r13
    77db4930290c:	add    r15,0xc0
    77db49302913:	mov    rbp,r15
    77db49302916:	add    rbp,0x10
    77db4930291a:	movdqu xmm2,XMMWORD PTR [r15]
    77db4930291f:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    77db49302924:	movdqu XMMWORD PTR [r12+0x130],xmm2
    77db4930292e:	movdqu XMMWORD PTR [r12+0x110],xmm3
    77db49302938:	mov    r15,r13
    77db4930293b:	add    r15,0x140
    77db49302942:	mov    rbp,r15
    77db49302945:	add    rbp,0x10
    77db49302949:	movdqu xmm7,XMMWORD PTR [r15]
    77db4930294e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    77db49302954:	movdqu XMMWORD PTR [r12+0x270],xmm7
    77db4930295e:	movdqu XMMWORD PTR [r12+0x190],xmm8
    77db49302968:	mov    r15,r13
    77db4930296b:	add    r15,0x180
    77db49302972:	mov    rbp,r15
    77db49302975:	add    rbp,0x10
    77db49302979:	movdqu xmm7,XMMWORD PTR [r15]
    77db4930297e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    77db49302984:	movdqu XMMWORD PTR [r12+0x2a0],xmm7
    77db4930298e:	movdqu XMMWORD PTR [r12+0x1a0],xmm8
    77db49302998:	mov    r15,r14
    77db4930299b:	add    r15,0xc0
    77db493029a2:	mov    rbp,r15
    77db493029a5:	add    rbp,0x10
    77db493029a9:	movdqu XMMWORD PTR [r15],xmm3
    77db493029ae:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    77db493029b3:	mov    r15,r13
    77db493029b6:	add    r15,0x100
    77db493029bd:	mov    rbp,r15
    77db493029c0:	add    rbp,0x10
    77db493029c4:	movdqu xmm2,XMMWORD PTR [r15]
    77db493029c9:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    77db493029ce:	movdqu XMMWORD PTR [r12+0x110],xmm2
    77db493029d8:	movdqu XMMWORD PTR [r12+0x300],xmm3
    77db493029e2:	mov    r15,r13
    77db493029e5:	add    r15,0x1c0
    77db493029ec:	mov    rbp,r15
    77db493029ef:	add    rbp,0x10
    77db493029f3:	movdqu xmm3,XMMWORD PTR [r15]
    77db493029f8:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    77db493029fd:	movdqu XMMWORD PTR [r12+0x240],xmm3
    77db49302a07:	movdqu XMMWORD PTR [r12+0x1c0],xmm7
    77db49302a11:	mov    r15,r13
    77db49302a14:	add    r15,0x20
    77db49302a18:	mov    rbp,r15
    77db49302a1b:	add    rbp,0x10
    77db49302a1f:	movdqu xmm7,XMMWORD PTR [r15]
    77db49302a24:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    77db49302a2a:	movdqu XMMWORD PTR [r12+0x1d0],xmm7
    77db49302a34:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
    77db49302a3e:	mov    r15,r14
    77db49302a41:	add    r15,0x20
    77db49302a45:	mov    rbp,r15
    77db49302a48:	add    rbp,0x10
    77db49302a4c:	movdqu XMMWORD PTR [r15],xmm2
    77db49302a51:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    77db49302a56:	mov    r15,r13
    77db49302a59:	add    r15,0x60
    77db49302a5d:	mov    rbp,r15
    77db49302a60:	add    rbp,0x10
    77db49302a64:	movdqu xmm2,XMMWORD PTR [r15]
    77db49302a69:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    77db49302a6e:	movdqu XMMWORD PTR [r12+0x110],xmm2
    77db49302a78:	movdqu XMMWORD PTR [r12+0x120],xmm5
    77db49302a82:	mov    r15,r14
    77db49302a85:	add    r15,0x60
    77db49302a89:	mov    rbp,r15
    77db49302a8c:	add    rbp,0x10
    77db49302a90:	movdqu XMMWORD PTR [r15],xmm4
    77db49302a95:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    77db49302a9a:	mov    r15,r13
    77db49302a9d:	add    r15,0xe0
    77db49302aa4:	mov    rbp,r15
    77db49302aa7:	add    rbp,0x10
    77db49302aab:	movdqu xmm3,XMMWORD PTR [r15]
    77db49302ab0:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    77db49302ab5:	movdqu XMMWORD PTR [r12+0x200],xmm3
    77db49302abf:	movdqu XMMWORD PTR [r12+0x2d0],xmm4
    77db49302ac9:	mov    r15,r13
    77db49302acc:	add    r15,0x120
    77db49302ad3:	mov    rbp,r15
    77db49302ad6:	add    rbp,0x10
    77db49302ada:	movdqu xmm3,XMMWORD PTR [r15]
    77db49302adf:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    77db49302ae4:	movdqu XMMWORD PTR [r12+0x2e0],xmm3
    77db49302aee:	movdqu XMMWORD PTR [r12+0x2f0],xmm4
    77db49302af8:	mov    r15,r14
    77db49302afb:	add    r15,0xa0
    77db49302b02:	mov    rbp,r15
    77db49302b05:	add    rbp,0x10
    77db49302b09:	movdqu XMMWORD PTR [r15],xmm5
    77db49302b0e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    77db49302b13:	mov    r15,r13
    77db49302b16:	add    r15,0xa0
    77db49302b1d:	mov    rbp,r15
    77db49302b20:	add    rbp,0x10
    77db49302b24:	movdqu xmm2,XMMWORD PTR [r15]
    77db49302b29:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    77db49302b2e:	movdqu XMMWORD PTR [r12+0x110],xmm2
    77db49302b38:	movdqu XMMWORD PTR [r12+0x120],xmm3
    77db49302b42:	mov    r15,r13
    77db49302b45:	add    r15,0x160
    77db49302b4c:	mov    rbp,r15
    77db49302b4f:	add    rbp,0x10
    77db49302b53:	movdqu xmm4,XMMWORD PTR [r15]
    77db49302b58:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    77db49302b5d:	movdqu XMMWORD PTR [r12+0x2c0],xmm4
    77db49302b67:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
    77db49302b71:	mov    r15,r13
    77db49302b74:	add    r15,0x1a0
    77db49302b7b:	mov    rbp,r15
    77db49302b7e:	add    rbp,0x10
    77db49302b82:	movdqu xmm5,XMMWORD PTR [r15]
    77db49302b87:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    77db49302b8c:	movdqu XMMWORD PTR [r12+0x290],xmm5
    77db49302b96:	movdqu XMMWORD PTR [r12+0x1e0],xmm7
    77db49302ba0:	mov    r15,r14
    77db49302ba3:	add    r15,0x80
    77db49302baa:	mov    rbp,r15
    77db49302bad:	add    rbp,0x10
    77db49302bb1:	movdqu XMMWORD PTR [r15],xmm3
    77db49302bb6:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    77db49302bbb:	add    r13,0x1e0
    77db49302bc2:	mov    r15,r13
    77db49302bc5:	add    r15,0x10
    77db49302bc9:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    77db49302bcf:	movdqu xmm3,XMMWORD PTR [r15]
    77db49302bd4:	movdqu XMMWORD PTR [r12+0x230],xmm2
    77db49302bde:	movdqu XMMWORD PTR [r12+0x280],xmm3
    77db49302be8:	mov    r13d,0x432000
    77db49302bee:	add    r13,0x200
    77db49302bf5:	mov    QWORD PTR [r12+0x50],r13
    77db49302bfa:	mov    r13,r14
    77db49302bfd:	add    r13,0x40
    77db49302c01:	mov    r15,r13
    77db49302c04:	add    r15,0x10
    77db49302c08:	movdqu XMMWORD PTR [r13+0x0],xmm4
    77db49302c0e:	movdqu XMMWORD PTR [r15],xmm6
    77db49302c13:	mov    r13,r14
    77db49302c16:	add    r13,0x10
    77db49302c1a:	movdqu XMMWORD PTR [r14],xmm3
    77db49302c1f:	movdqu XMMWORD PTR [r13+0x0],xmm2
    77db49302c25:	mov    r11,rax
    77db49302c28:	movzx  eax,WORD PTR [rsp]
    77db49302c2c:	add    al,0x7f
    77db49302c2e:	sahf
    77db49302c2f:	mov    rax,r11
    77db49302c32:	jmp    0x77db49302c37
    77db49302c37:	mov    r13d,0x0
    77db49302c3d:	mov    QWORD PTR [r12+0x58],r13
    77db49302c42:	mov    r11,rax
    77db49302c45:	lahf
    77db49302c46:	seto   al
    77db49302c49:	mov    WORD PTR [rsp],ax
    77db49302c4d:	mov    rax,r11
    77db49302c50:	jmp    0x77db49302c55
    77db49302c55:	mov    r13,QWORD PTR [r12+0x58]
    77db49302c5a:	mov    r14,QWORD PTR [r12+0x40]
    77db49302c5f:	add    r14,r13
    77db49302c62:	mov    QWORD PTR [r12+0x60],r14
    77db49302c67:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    77db49302c71:	movdqa xmm0,xmm2
    77db49302c75:	movdqa xmm1,xmm2
    77db49302c79:	por    xmm0,xmm1
    77db49302c7d:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    77db49302c87:	movdqu xmm4,XMMWORD PTR [r12+0x1a0]
    77db49302c91:	movdqa xmm0,xmm4
    77db49302c95:	movdqa xmm1,xmm4
    77db49302c99:	por    xmm0,xmm1
    77db49302c9d:	movdqu XMMWORD PTR [r12+0x120],xmm0
    77db49302ca7:	mov    r15,r14
    77db49302caa:	add    r15,0x30
    77db49302cae:	mov    rbp,r15
    77db49302cb1:	add    rbp,0x8
    77db49302cb5:	mov    r8,QWORD PTR [r15]
    77db49302cb8:	mov    r15,QWORD PTR [rbp+0x0]
    77db49302cbc:	mov    ebp,0x0
    77db49302cc1:	mov    QWORD PTR [r12+0x130],r8
    77db49302cc9:	mov    QWORD PTR [r12+0x138],rbp
    77db49302cd1:	mov    ebp,0x0
    77db49302cd6:	mov    QWORD PTR [r12+0x280],r15
    77db49302cde:	mov    QWORD PTR [r12+0x288],rbp
    77db49302ce6:	movdqu xmm5,XMMWORD PTR [r12+0x270]
    77db49302cf0:	movdqa xmm0,xmm5
    77db49302cf4:	movdqa xmm1,xmm5
    77db49302cf8:	por    xmm0,xmm1
    77db49302cfc:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    77db49302d06:	mov    r15,r14
    77db49302d09:	add    r15,0x20
    77db49302d0d:	mov    rbp,r15
    77db49302d10:	add    rbp,0x8
    77db49302d14:	mov    r8,QWORD PTR [r15]
    77db49302d17:	mov    r15,QWORD PTR [rbp+0x0]
    77db49302d1b:	mov    ebp,0x0
    77db49302d20:	mov    QWORD PTR [r12+0x150],r8
    77db49302d28:	mov    QWORD PTR [r12+0x158],rbp
    77db49302d30:	mov    ebp,0x0
    77db49302d35:	mov    QWORD PTR [r12+0x140],r15
    77db49302d3d:	mov    QWORD PTR [r12+0x148],rbp
    77db49302d45:	mov    r15,r14
    77db49302d48:	add    r15,0x10
    77db49302d4c:	mov    rbp,r15
    77db49302d4f:	add    rbp,0x8
    77db49302d53:	mov    r8,QWORD PTR [r15]
    77db49302d56:	mov    r15,QWORD PTR [rbp+0x0]
    77db49302d5a:	mov    ebp,0x0
    77db49302d5f:	mov    QWORD PTR [r12+0x170],r8
    77db49302d67:	mov    QWORD PTR [r12+0x178],rbp
    77db49302d6f:	mov    ebp,0x0
    77db49302d74:	mov    QWORD PTR [r12+0x160],r15
    77db49302d7c:	mov    QWORD PTR [r12+0x168],rbp
    77db49302d84:	mov    r15d,0x8
    77db49302d8a:	mov    rbp,QWORD PTR [r14]
    77db49302d8d:	mov    QWORD PTR [r12+0x180],rbp
    77db49302d95:	mov    QWORD PTR [r12+0x188],rbp
    77db49302d9d:	add    r14,r15
    77db49302da0:	mov    QWORD PTR [r12+0x60],r14
    77db49302da5:	mov    r15,QWORD PTR [r14]
    77db49302da8:	mov    r14d,0x0
    77db49302dae:	mov    QWORD PTR [r12+0x230],r15
    77db49302db6:	mov    QWORD PTR [r12+0x238],r14
    77db49302dbe:	mov    r14,QWORD PTR [r12+0xf8]
    77db49302dc6:	mov    r15,r14
    77db49302dc9:	add    r15,0x50
    77db49302dcd:	mov    rbp,r15
    77db49302dd0:	add    rbp,0x10
    77db49302dd4:	movdqu xmm6,XMMWORD PTR [r15]
    77db49302dd9:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    77db49302dde:	movdqu XMMWORD PTR [r12+0x220],xmm6
    77db49302de8:	movdqu XMMWORD PTR [r12+0x210],xmm7
    77db49302df2:	mov    r15,r14
    77db49302df5:	add    r15,0x30
    77db49302df9:	movdqu xmm8,XMMWORD PTR [r15]
    77db49302dfe:	movdqu XMMWORD PTR [r12+0x110],xmm8
    77db49302e08:	mov    r15,QWORD PTR [r12+0x50]
    77db49302e0d:	add    r15,r13
    77db49302e10:	mov    QWORD PTR [r12+0x60],r15
    77db49302e15:	add    r13,0x40
    77db49302e19:	mov    QWORD PTR [r12+0x58],r13
    77db49302e1e:	movdqu xmm9,XMMWORD PTR [r12+0x180]
    77db49302e28:	movdqa xmm0,xmm9
    77db49302e2d:	movdqa xmm1,xmm2
    77db49302e31:	mulpd  xmm0,xmm1
    77db49302e35:	movdqa xmm14,xmm0
    77db49302e3a:	movdqu xmm15,XMMWORD PTR [rip+0x980d]        # 0x77db4930c650
    77db49302e43:	pand   xmm14,xmm15
    77db49302e48:	movdqu xmm15,XMMWORD PTR [rip+0x980f]        # 0x77db4930c660
    77db49302e51:	pcmpeqq xmm14,xmm15
    77db49302e57:	movdqa xmm15,xmm0
    77db49302e5c:	cmpunordpd xmm15,xmm0
    77db49302e62:	por    xmm14,xmm15
    77db49302e67:	pmovmskb ecx,xmm14
    77db49302e6c:	jrcxz  0x77db49302e73
    77db49302e6e:	jmp    0x77db49304e05
    77db49302e73:	movdqa xmm10,xmm0
    77db49302e78:	movdqu xmm2,XMMWORD PTR [r12+0x230]
    77db49302e82:	movdqa xmm0,xmm8
    77db49302e87:	movdqa xmm1,xmm2
    77db49302e8b:	pshufd xmm1,xmm1,0x44
    77db49302e90:	mulpd  xmm0,xmm1
    77db49302e94:	movdqa xmm14,xmm0
    77db49302e99:	movdqu xmm15,XMMWORD PTR [rip+0x97ae]        # 0x77db4930c650
    77db49302ea2:	pand   xmm14,xmm15
    77db49302ea7:	movdqu xmm15,XMMWORD PTR [rip+0x97b0]        # 0x77db4930c660
    77db49302eb0:	pcmpeqq xmm14,xmm15
    77db49302eb6:	movdqa xmm15,xmm0
    77db49302ebb:	cmpunordpd xmm15,xmm0
    77db49302ec1:	por    xmm14,xmm15
    77db49302ec6:	pmovmskb ecx,xmm14
    77db49302ecb:	jrcxz  0x77db49302ed2
    77db49302ecd:	jmp    0x77db49304e2a
    77db49302ed2:	movdqa xmm11,xmm0
    77db49302ed7:	movdqu XMMWORD PTR [r12+0x260],xmm11
    77db49302ee1:	mov    ebp,0x0
    77db49302ee6:	mov    r8d,0x0
    77db49302eec:	mov    QWORD PTR [r12+0x110],rbp
    77db49302ef4:	mov    QWORD PTR [r12+0x118],r8
    77db49302efc:	movdqa xmm0,xmm9
    77db49302f01:	movdqa xmm1,xmm7
    77db49302f05:	mulpd  xmm0,xmm1
    77db49302f09:	movdqa xmm14,xmm0
    77db49302f0e:	movdqu xmm15,XMMWORD PTR [rip+0x9739]        # 0x77db4930c650
    77db49302f17:	pand   xmm14,xmm15
    77db49302f1c:	movdqu xmm15,XMMWORD PTR [rip+0x973b]        # 0x77db4930c660
    77db49302f25:	pcmpeqq xmm14,xmm15
    77db49302f2b:	movdqa xmm15,xmm0
    77db49302f30:	cmpunordpd xmm15,xmm0
    77db49302f36:	por    xmm14,xmm15
    77db49302f3b:	pmovmskb ecx,xmm14
    77db49302f40:	jrcxz  0x77db49302f47
    77db49302f42:	jmp    0x77db49304e4f
    77db49302f47:	movdqa xmm8,xmm0
    77db49302f4c:	movdqa xmm0,xmm9
    77db49302f51:	movdqa xmm1,xmm6
    77db49302f55:	mulpd  xmm0,xmm1
    77db49302f59:	movdqa xmm14,xmm0
    77db49302f5e:	movdqu xmm15,XMMWORD PTR [rip+0x96e9]        # 0x77db4930c650
    77db49302f67:	pand   xmm14,xmm15
    77db49302f6c:	movdqu xmm15,XMMWORD PTR [rip+0x96eb]        # 0x77db4930c660
    77db49302f75:	pcmpeqq xmm14,xmm15
    77db49302f7b:	movdqa xmm15,xmm0
    77db49302f80:	cmpunordpd xmm15,xmm0
    77db49302f86:	por    xmm14,xmm15
    77db49302f8b:	pmovmskb ecx,xmm14
    77db49302f90:	jrcxz  0x77db49302f97
    77db49302f92:	jmp    0x77db49304e74
    77db49302f97:	movdqa xmm7,xmm0
    77db49302f9b:	movdqu xmm6,XMMWORD PTR [r12+0x1f0]
    77db49302fa5:	movdqa xmm0,xmm9
    77db49302faa:	movdqa xmm1,xmm6
    77db49302fae:	mulpd  xmm0,xmm1
    77db49302fb2:	movdqa xmm14,xmm0
    77db49302fb7:	movdqu xmm15,XMMWORD PTR [rip+0x9690]        # 0x77db4930c650
    77db49302fc0:	pand   xmm14,xmm15
    77db49302fc5:	movdqu xmm15,XMMWORD PTR [rip+0x9692]        # 0x77db4930c660
    77db49302fce:	pcmpeqq xmm14,xmm15
    77db49302fd4:	movdqa xmm15,xmm0
    77db49302fd9:	cmpunordpd xmm15,xmm0
    77db49302fdf:	por    xmm14,xmm15
    77db49302fe4:	pmovmskb ecx,xmm14
    77db49302fe9:	jrcxz  0x77db49302ff0
    77db49302feb:	jmp    0x77db49304e99
    77db49302ff0:	movdqa xmm12,xmm0
    77db49302ff5:	movdqu XMMWORD PTR [r12+0x180],xmm12
    77db49302fff:	movdqu xmm6,XMMWORD PTR [r12+0x2a0]
    77db49303009:	movdqa xmm0,xmm6
    77db4930300d:	movdqa xmm1,xmm6
    77db49303011:	por    xmm0,xmm1
    77db49303015:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    77db4930301f:	movdqu xmm9,XMMWORD PTR [r12+0x250]
    77db49303029:	movdqa xmm0,xmm9
    77db4930302e:	movdqa xmm1,xmm9
    77db49303033:	por    xmm0,xmm1
    77db49303037:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    77db49303041:	movdqa xmm0,xmm9
    77db49303046:	movdqa xmm1,xmm2
    77db4930304a:	pshufd xmm1,xmm1,0x44
    77db4930304f:	mulpd  xmm0,xmm1
    77db49303053:	movdqa xmm14,xmm0
    77db49303058:	movdqu xmm15,XMMWORD PTR [rip+0x95ef]        # 0x77db4930c650
    77db49303061:	pand   xmm14,xmm15
    77db49303066:	movdqu xmm15,XMMWORD PTR [rip+0x95f1]        # 0x77db4930c660
    77db4930306f:	pcmpeqq xmm14,xmm15
    77db49303075:	movdqa xmm15,xmm0
    77db4930307a:	cmpunordpd xmm15,xmm0
    77db49303080:	por    xmm14,xmm15
    77db49303085:	pmovmskb ecx,xmm14
    77db4930308a:	jrcxz  0x77db49303091
    77db4930308c:	jmp    0x77db49304ebe
    77db49303091:	movdqa xmm4,xmm0
    77db49303095:	movdqu XMMWORD PTR [r12+0x250],xmm4
    77db4930309f:	sub    r13,0x200
    77db493030a6:	movdqu xmm9,XMMWORD PTR [r12+0x110]
    77db493030b0:	movdqa xmm0,xmm10
    77db493030b5:	movdqa xmm1,xmm9
    77db493030ba:	addpd  xmm0,xmm1
    77db493030be:	movdqa xmm14,xmm0
    77db493030c3:	movdqu xmm15,XMMWORD PTR [rip+0x9584]        # 0x77db4930c650
    77db493030cc:	pand   xmm14,xmm15
    77db493030d1:	movdqu xmm15,XMMWORD PTR [rip+0x9586]        # 0x77db4930c660
    77db493030da:	pcmpeqq xmm14,xmm15
    77db493030e0:	movdqa xmm15,xmm0
    77db493030e5:	cmpunordpd xmm15,xmm0
    77db493030eb:	por    xmm14,xmm15
    77db493030f0:	pmovmskb ecx,xmm14
    77db493030f5:	jrcxz  0x77db493030fc
    77db493030f7:	jmp    0x77db49304ee3
    77db493030fc:	movdqu XMMWORD PTR [r12+0x240],xmm0
    77db49303106:	movdqu xmm10,XMMWORD PTR [r12+0x1b0]
    77db49303110:	movdqa xmm0,xmm8
    77db49303115:	movdqa xmm1,xmm10
    77db4930311a:	addpd  xmm0,xmm1
    77db4930311e:	movdqa xmm14,xmm0
    77db49303123:	movdqu xmm15,XMMWORD PTR [rip+0x9524]        # 0x77db4930c650
    77db4930312c:	pand   xmm14,xmm15
    77db49303131:	movdqu xmm15,XMMWORD PTR [rip+0x9526]        # 0x77db4930c660
    77db4930313a:	pcmpeqq xmm14,xmm15
    77db49303140:	movdqa xmm15,xmm0
    77db49303145:	cmpunordpd xmm15,xmm0
    77db4930314b:	por    xmm14,xmm15
    77db49303150:	pmovmskb ecx,xmm14
    77db49303155:	jrcxz  0x77db4930315c
    77db49303157:	jmp    0x77db49304f24
    77db4930315c:	movdqa xmm6,xmm0
    77db49303160:	movdqu XMMWORD PTR [r12+0x210],xmm6
    77db4930316a:	movdqa xmm0,xmm7
    77db4930316e:	movdqa xmm1,xmm10
    77db49303173:	addpd  xmm0,xmm1
    77db49303177:	movdqa xmm14,xmm0
    77db4930317c:	movdqu xmm15,XMMWORD PTR [rip+0x94cb]        # 0x77db4930c650
    77db49303185:	pand   xmm14,xmm15
    77db4930318a:	movdqu xmm15,XMMWORD PTR [rip+0x94cd]        # 0x77db4930c660
    77db49303193:	pcmpeqq xmm14,xmm15
    77db49303199:	movdqa xmm15,xmm0
    77db4930319e:	cmpunordpd xmm15,xmm0
    77db493031a4:	por    xmm14,xmm15
    77db493031a9:	pmovmskb ecx,xmm14
    77db493031ae:	jrcxz  0x77db493031b5
    77db493031b0:	jmp    0x77db49304f65
    77db493031b5:	movdqa xmm8,xmm0
    77db493031ba:	movdqu XMMWORD PTR [r12+0x220],xmm8
    77db493031c4:	movdqu xmm7,XMMWORD PTR [r12+0x2f0]
    77db493031ce:	setne  BYTE PTR [rsp+0x8]
    77db493031d3:	mov    r11,rax
    77db493031d6:	lahf
    77db493031d7:	seto   al
    77db493031da:	mov    WORD PTR [rsp],ax
    77db493031de:	mov    rax,r11
    77db493031e1:	movdqa xmm0,xmm7
    77db493031e5:	movdqa xmm1,xmm7
    77db493031e9:	por    xmm0,xmm1
    77db493031ed:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    77db493031f7:	movdqu xmm10,XMMWORD PTR [r12+0x2e0]
    77db49303201:	movdqa xmm0,xmm10
    77db49303206:	movdqa xmm1,xmm10
    77db4930320b:	por    xmm0,xmm1
    77db4930320f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    77db49303219:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    77db49303223:	movdqa xmm0,xmm13
    77db49303228:	movdqa xmm1,xmm13
    77db4930322d:	por    xmm0,xmm1
    77db49303231:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    77db4930323b:	movdqu xmm5,XMMWORD PTR [r12+0x200]
    77db49303245:	movdqa xmm0,xmm5
    77db49303249:	movdqa xmm1,xmm5
    77db4930324d:	por    xmm0,xmm1
    77db49303251:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    77db4930325b:	movdqu xmm7,XMMWORD PTR [r12+0x1c0]
    77db49303265:	movdqa xmm1,xmm7
    77db49303269:	por    xmm7,xmm1
    77db4930326d:	movdqu XMMWORD PTR [r12+0x200],xmm7
    77db49303277:	movdqu xmm3,XMMWORD PTR [r12+0x190]
    77db49303281:	movdqa xmm1,xmm3
    77db49303285:	por    xmm3,xmm1
    77db49303289:	movdqu XMMWORD PTR [r12+0x1c0],xmm3
    77db49303293:	movdqu xmm10,XMMWORD PTR [r12+0x300]
    77db4930329d:	movdqa xmm1,xmm10
    77db493032a2:	por    xmm10,xmm1
    77db493032a7:	movdqu XMMWORD PTR [r12+0x190],xmm10
    77db493032b1:	mov    r13,r14
    77db493032b4:	add    r13,0xa0
    77db493032bb:	mov    rbp,r13
    77db493032be:	add    rbp,0x10
    77db493032c2:	movdqu xmm13,XMMWORD PTR [r13+0x0]
    77db493032c8:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    77db493032cd:	movdqu XMMWORD PTR [r12+0x300],xmm13
    77db493032d7:	movdqu XMMWORD PTR [r12+0x270],xmm5
    77db493032e1:	movdqa xmm0,xmm12
    77db493032e6:	movdqa xmm1,xmm9
    77db493032eb:	addpd  xmm0,xmm1
    77db493032ef:	movdqa xmm14,xmm0
    77db493032f4:	movdqu xmm15,XMMWORD PTR [rip+0x9353]        # 0x77db4930c650
    77db493032fd:	pand   xmm14,xmm15
    77db49303302:	movdqu xmm15,XMMWORD PTR [rip+0x9355]        # 0x77db4930c660
    77db4930330b:	pcmpeqq xmm14,xmm15
    77db49303311:	movdqa xmm15,xmm0
    77db49303316:	cmpunordpd xmm15,xmm0
    77db4930331c:	por    xmm14,xmm15
    77db49303321:	pmovmskb ecx,xmm14
    77db49303326:	jrcxz  0x77db4930332d
    77db49303328:	jmp    0x77db49304fa5
    77db4930332d:	movdqu XMMWORD PTR [r12+0x180],xmm0
    77db49303337:	mov    r13,r14
    77db4930333a:	add    r13,0xf0
    77db49303341:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    77db49303347:	movdqu XMMWORD PTR [r12+0x110],xmm9
    77db49303351:	movdqa xmm0,xmm6
    77db49303355:	movdqa xmm1,xmm4
    77db49303359:	addpd  xmm0,xmm1
    77db4930335d:	movdqa xmm14,xmm0
    77db49303362:	movdqu xmm15,XMMWORD PTR [rip+0x92e5]        # 0x77db4930c650
    77db4930336b:	pand   xmm14,xmm15
    77db49303370:	movdqu xmm15,XMMWORD PTR [rip+0x92e7]        # 0x77db4930c660
    77db49303379:	pcmpeqq xmm14,xmm15
    77db4930337f:	movdqa xmm15,xmm0
    77db49303384:	cmpunordpd xmm15,xmm0
    77db4930338a:	por    xmm14,xmm15
    77db4930338f:	pmovmskb ecx,xmm14
    77db49303394:	jrcxz  0x77db4930339b
    77db49303396:	jmp    0x77db49304fcb
    77db4930339b:	movdqa xmm12,xmm0
    77db493033a0:	movdqu XMMWORD PTR [r12+0x210],xmm12
    77db493033aa:	movdqa xmm0,xmm8
    77db493033af:	movdqa xmm1,xmm11
    77db493033b4:	addpd  xmm0,xmm1
    77db493033b8:	movdqa xmm14,xmm0
    77db493033bd:	movdqu xmm15,XMMWORD PTR [rip+0x928a]        # 0x77db4930c650
    77db493033c6:	pand   xmm14,xmm15
    77db493033cb:	movdqu xmm15,XMMWORD PTR [rip+0x928c]        # 0x77db4930c660
    77db493033d4:	pcmpeqq xmm14,xmm15
    77db493033da:	movdqa xmm15,xmm0
    77db493033df:	cmpunordpd xmm15,xmm0
    77db493033e5:	por    xmm14,xmm15
    77db493033ea:	pmovmskb ecx,xmm14
    77db493033ef:	jrcxz  0x77db493033f6
    77db493033f1:	jmp    0x77db49304fef
    77db493033f6:	movdqa xmm4,xmm0
    77db493033fa:	movdqu XMMWORD PTR [r12+0x220],xmm4
    77db49303404:	movdqa xmm0,xmm5
    77db49303408:	movdqa xmm1,xmm2
    77db4930340c:	pshufd xmm1,xmm1,0x44
    77db49303411:	mulpd  xmm0,xmm1
    77db49303415:	movdqa xmm14,xmm0
    77db4930341a:	movdqu xmm15,XMMWORD PTR [rip+0x922d]        # 0x77db4930c650
    77db49303423:	pand   xmm14,xmm15
    77db49303428:	movdqu xmm15,XMMWORD PTR [rip+0x922f]        # 0x77db4930c660
    77db49303431:	pcmpeqq xmm14,xmm15
    77db49303437:	movdqa xmm15,xmm0
    77db4930343c:	cmpunordpd xmm15,xmm0
    77db49303442:	por    xmm14,xmm15
    77db49303447:	pmovmskb ecx,xmm14
    77db4930344c:	jrcxz  0x77db49303453
    77db4930344e:	jmp    0x77db49305015
    77db49303453:	movdqa xmm6,xmm0
    77db49303457:	movdqu XMMWORD PTR [r12+0x270],xmm6
    77db49303461:	movdqu xmm5,XMMWORD PTR [r12+0x170]
    77db4930346b:	movdqa xmm0,xmm9
    77db49303470:	movdqa xmm1,xmm5
    77db49303474:	pshufd xmm1,xmm1,0x44
    77db49303479:	mulpd  xmm0,xmm1
    77db4930347d:	movdqa xmm14,xmm0
    77db49303482:	movdqu xmm15,XMMWORD PTR [rip+0x91c5]        # 0x77db4930c650
    77db4930348b:	pand   xmm14,xmm15
    77db49303490:	movdqu xmm15,XMMWORD PTR [rip+0x91c7]        # 0x77db4930c660
    77db49303499:	pcmpeqq xmm14,xmm15
    77db4930349f:	movdqa xmm15,xmm0
    77db493034a4:	cmpunordpd xmm15,xmm0
    77db493034aa:	por    xmm14,xmm15
    77db493034af:	pmovmskb ecx,xmm14
    77db493034b4:	jrcxz  0x77db493034bb
    77db493034b6:	jmp    0x77db49305039
    77db493034bb:	movdqa xmm8,xmm0
    77db493034c0:	movdqu XMMWORD PTR [r12+0x250],xmm8
    77db493034ca:	mov    r13,r14
    77db493034cd:	add    r13,0xe0
    77db493034d4:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    77db493034da:	movdqu XMMWORD PTR [r12+0x110],xmm9
    77db493034e4:	movdqa xmm0,xmm13
    77db493034e9:	movdqa xmm1,xmm2
    77db493034ed:	pshufd xmm1,xmm1,0x44
    77db493034f2:	mulpd  xmm0,xmm1
    77db493034f6:	movdqa xmm14,xmm0
    77db493034fb:	movdqu xmm15,XMMWORD PTR [rip+0x914c]        # 0x77db4930c650
    77db49303504:	pand   xmm14,xmm15
    77db49303509:	movdqu xmm15,XMMWORD PTR [rip+0x914e]        # 0x77db4930c660
    77db49303512:	pcmpeqq xmm14,xmm15
    77db49303518:	movdqa xmm15,xmm0
    77db4930351d:	cmpunordpd xmm15,xmm0
    77db49303523:	por    xmm14,xmm15
    77db49303528:	pmovmskb ecx,xmm14
    77db4930352d:	jrcxz  0x77db49303534
    77db4930352f:	jmp    0x77db4930505e
    77db49303534:	movdqa xmm11,xmm0
    77db49303539:	movdqu XMMWORD PTR [r12+0x230],xmm11
    77db49303543:	movdqa xmm0,xmm10
    77db49303548:	movdqa xmm1,xmm10
    77db4930354d:	por    xmm0,xmm1
    77db49303551:	movdqu XMMWORD PTR [r12+0x300],xmm0
    77db4930355b:	movdqa xmm0,xmm3
    77db4930355f:	movdqa xmm1,xmm3
    77db49303563:	por    xmm0,xmm1
    77db49303567:	movdqu XMMWORD PTR [r12+0x190],xmm0
    77db49303571:	movdqa xmm0,xmm9
    77db49303576:	movdqa xmm1,xmm5
    77db4930357a:	pshufd xmm1,xmm1,0x44
    77db4930357f:	mulpd  xmm0,xmm1
    77db49303583:	movdqa xmm14,xmm0
    77db49303588:	movdqu xmm15,XMMWORD PTR [rip+0x90bf]        # 0x77db4930c650
    77db49303591:	pand   xmm14,xmm15
    77db49303596:	movdqu xmm15,XMMWORD PTR [rip+0x90c1]        # 0x77db4930c660
    77db4930359f:	pcmpeqq xmm14,xmm15
    77db493035a5:	movdqa xmm15,xmm0
    77db493035aa:	cmpunordpd xmm15,xmm0
    77db493035b0:	por    xmm14,xmm15
    77db493035b5:	pmovmskb ecx,xmm14
    77db493035ba:	jrcxz  0x77db493035c1
    77db493035bc:	jmp    0x77db49305083
    77db493035c1:	movdqa xmm2,xmm0
    77db493035c5:	movdqu XMMWORD PTR [r12+0x260],xmm2
    77db493035cf:	mov    r13,r14
    77db493035d2:	add    r13,0x90
    77db493035d9:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    77db493035df:	movdqu XMMWORD PTR [r12+0x110],xmm9
    77db493035e9:	movdqa xmm0,xmm7
    77db493035ed:	movdqa xmm1,xmm7
    77db493035f1:	por    xmm0,xmm1
    77db493035f5:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    77db493035ff:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    77db49303609:	movdqu xmm1,XMMWORD PTR [r12+0x2d0]
    77db49303613:	por    xmm13,xmm1
    77db49303618:	movdqu XMMWORD PTR [r12+0x200],xmm13
    77db49303622:	movdqu xmm7,XMMWORD PTR [r12+0x2e0]
    77db4930362c:	movdqu xmm1,XMMWORD PTR [r12+0x2e0]
    77db49303636:	por    xmm7,xmm1
    77db4930363a:	movdqu XMMWORD PTR [r12+0x2d0],xmm7
    77db49303644:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    77db4930364e:	movdqu xmm1,XMMWORD PTR [r12+0x2f0]
    77db49303658:	por    xmm0,xmm1
    77db4930365c:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    77db49303666:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    77db49303670:	movdqa xmm1,xmm6
    77db49303674:	addpd  xmm0,xmm1
    77db49303678:	movdqa xmm14,xmm0
    77db4930367d:	movdqu xmm15,XMMWORD PTR [rip+0x8fca]        # 0x77db4930c650
    77db49303686:	pand   xmm14,xmm15
    77db4930368b:	movdqu xmm15,XMMWORD PTR [rip+0x8fcc]        # 0x77db4930c660
    77db49303694:	pcmpeqq xmm14,xmm15
    77db4930369a:	movdqa xmm15,xmm0
    77db4930369f:	cmpunordpd xmm15,xmm0
    77db493036a5:	por    xmm14,xmm15
    77db493036aa:	pmovmskb ecx,xmm14
    77db493036af:	jrcxz  0x77db493036b6
    77db493036b1:	jmp    0x77db493050a8
    77db493036b6:	movdqa xmm3,xmm0
    77db493036ba:	movdqu XMMWORD PTR [r12+0x240],xmm3
    77db493036c4:	movdqa xmm0,xmm9
    77db493036c9:	movdqa xmm1,xmm5
    77db493036cd:	pshufd xmm1,xmm1,0x44
    77db493036d2:	mulpd  xmm0,xmm1
    77db493036d6:	movdqa xmm14,xmm0
    77db493036db:	movdqu xmm15,XMMWORD PTR [rip+0x8f6c]        # 0x77db4930c650
    77db493036e4:	pand   xmm14,xmm15
    77db493036e9:	movdqu xmm15,XMMWORD PTR [rip+0x8f6e]        # 0x77db4930c660
    77db493036f2:	pcmpeqq xmm14,xmm15
    77db493036f8:	movdqa xmm15,xmm0
    77db493036fd:	cmpunordpd xmm15,xmm0
    77db49303703:	por    xmm14,xmm15
    77db49303708:	pmovmskb ecx,xmm14
    77db4930370d:	jrcxz  0x77db49303714
    77db4930370f:	jmp    0x77db493050d2
    77db49303714:	movdqa xmm6,xmm0
    77db49303718:	movdqu XMMWORD PTR [r12+0x270],xmm6
    77db49303722:	mov    r13,r14
    77db49303725:	add    r13,0x80
    77db4930372c:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    77db49303732:	movdqu XMMWORD PTR [r12+0x110],xmm9
    77db4930373c:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    77db49303746:	movdqa xmm1,xmm11
    77db4930374b:	addpd  xmm0,xmm1
    77db4930374f:	movdqa xmm14,xmm0
    77db49303754:	movdqu xmm15,XMMWORD PTR [rip+0x8ef3]        # 0x77db4930c650
    77db4930375d:	pand   xmm14,xmm15
    77db49303762:	movdqu xmm15,XMMWORD PTR [rip+0x8ef5]        # 0x77db4930c660
    77db4930376b:	pcmpeqq xmm14,xmm15
    77db49303771:	movdqa xmm15,xmm0
    77db49303776:	cmpunordpd xmm15,xmm0
    77db4930377c:	por    xmm14,xmm15
    77db49303781:	pmovmskb ecx,xmm14
    77db49303786:	jrcxz  0x77db4930378d
    77db49303788:	jmp    0x77db493050f7
    77db4930378d:	movdqa xmm10,xmm0
    77db49303792:	movdqu XMMWORD PTR [r12+0x180],xmm10
    77db4930379c:	movdqa xmm0,xmm12
    77db493037a1:	movdqa xmm1,xmm8
    77db493037a6:	addpd  xmm0,xmm1
    77db493037aa:	movdqa xmm14,xmm0
    77db493037af:	movdqu xmm15,XMMWORD PTR [rip+0x8e98]        # 0x77db4930c650
    77db493037b8:	pand   xmm14,xmm15
    77db493037bd:	movdqu xmm15,XMMWORD PTR [rip+0x8e9a]        # 0x77db4930c660
    77db493037c6:	pcmpeqq xmm14,xmm15
    77db493037cc:	movdqa xmm15,xmm0
    77db493037d1:	cmpunordpd xmm15,xmm0
    77db493037d7:	por    xmm14,xmm15
    77db493037dc:	pmovmskb ecx,xmm14
    77db493037e1:	jrcxz  0x77db493037e8
    77db493037e3:	jmp    0x77db49305122
    77db493037e8:	movdqa xmm11,xmm0
    77db493037ed:	movdqu XMMWORD PTR [r12+0x210],xmm11
    77db493037f7:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    77db49303801:	movdqu xmm1,XMMWORD PTR [r12+0x1b0]
    77db4930380b:	por    xmm0,xmm1
    77db4930380f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    77db49303819:	movdqa xmm0,xmm9
    77db4930381e:	movdqa xmm1,xmm5
    77db49303822:	pshufd xmm1,xmm1,0x44
    77db49303827:	mulpd  xmm0,xmm1
    77db4930382b:	movdqa xmm14,xmm0
    77db49303830:	movdqu xmm15,XMMWORD PTR [rip+0x8e17]        # 0x77db4930c650
    77db49303839:	pand   xmm14,xmm15
    77db4930383e:	movdqu xmm15,XMMWORD PTR [rip+0x8e19]        # 0x77db4930c660
    77db49303847:	pcmpeqq xmm14,xmm15
    77db4930384d:	movdqa xmm15,xmm0
    77db49303852:	cmpunordpd xmm15,xmm0
    77db49303858:	por    xmm14,xmm15
    77db4930385d:	pmovmskb ecx,xmm14
    77db49303862:	jrcxz  0x77db49303869
    77db49303864:	jmp    0x77db49305148
    77db49303869:	movdqa xmm12,xmm0
    77db4930386e:	movdqu XMMWORD PTR [r12+0x170],xmm12
    77db49303878:	mov    r13,r14
    77db4930387b:	add    r13,0xd0
    77db49303882:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    77db49303888:	movdqu XMMWORD PTR [r12+0x110],xmm5
    77db49303892:	movdqa xmm0,xmm4
    77db49303896:	movdqa xmm1,xmm2
    77db4930389a:	addpd  xmm0,xmm1
    77db4930389e:	movdqa xmm14,xmm0
    77db493038a3:	movdqu xmm15,XMMWORD PTR [rip+0x8da4]        # 0x77db4930c650
    77db493038ac:	pand   xmm14,xmm15
    77db493038b1:	movdqu xmm15,XMMWORD PTR [rip+0x8da6]        # 0x77db4930c660
    77db493038ba:	pcmpeqq xmm14,xmm15
    77db493038c0:	movdqa xmm15,xmm0
    77db493038c5:	cmpunordpd xmm15,xmm0
    77db493038cb:	por    xmm14,xmm15
    77db493038d0:	pmovmskb ecx,xmm14
    77db493038d5:	jrcxz  0x77db493038dc
    77db493038d7:	jmp    0x77db4930516d
    77db493038dc:	movdqa xmm9,xmm0
    77db493038e1:	movdqu XMMWORD PTR [r12+0x220],xmm9
    77db493038eb:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    77db493038f5:	movdqa xmm0,xmm13
    77db493038fa:	movdqa xmm1,xmm2
    77db493038fe:	pshufd xmm1,xmm1,0x44
    77db49303903:	mulpd  xmm0,xmm1
    77db49303907:	movdqa xmm14,xmm0
    77db4930390c:	movdqu xmm15,XMMWORD PTR [rip+0x8d3b]        # 0x77db4930c650
    77db49303915:	pand   xmm14,xmm15
    77db4930391a:	movdqu xmm15,XMMWORD PTR [rip+0x8d3d]        # 0x77db4930c660
    77db49303923:	pcmpeqq xmm14,xmm15
    77db49303929:	movdqa xmm15,xmm0
    77db4930392e:	cmpunordpd xmm15,xmm0
    77db49303934:	por    xmm14,xmm15
    77db49303939:	pmovmskb ecx,xmm14
    77db4930393e:	jrcxz  0x77db49303945
    77db49303940:	jmp    0x77db49305191
    77db49303945:	movdqa xmm4,xmm0
    77db49303949:	movdqu XMMWORD PTR [r12+0x260],xmm4
    77db49303953:	mov    r13d,0x0
    77db49303959:	mov    ebp,0x0
    77db4930395e:	mov    QWORD PTR [r12+0x1b0],r13
    77db49303966:	mov    QWORD PTR [r12+0x1b8],rbp
    77db4930396e:	movdqa xmm0,xmm5
    77db49303972:	movdqa xmm1,xmm2
    77db49303976:	pshufd xmm1,xmm1,0x44
    77db4930397b:	mulpd  xmm0,xmm1
    77db4930397f:	movdqa xmm14,xmm0
    77db49303984:	movdqu xmm15,XMMWORD PTR [rip+0x8cc3]        # 0x77db4930c650
    77db4930398d:	pand   xmm14,xmm15
    77db49303992:	movdqu xmm15,XMMWORD PTR [rip+0x8cc5]        # 0x77db4930c660
    77db4930399b:	pcmpeqq xmm14,xmm15
    77db493039a1:	movdqa xmm15,xmm0
    77db493039a6:	cmpunordpd xmm15,xmm0
    77db493039ac:	por    xmm14,xmm15
    77db493039b1:	pmovmskb ecx,xmm14
    77db493039b6:	jrcxz  0x77db493039bd
    77db493039b8:	jmp    0x77db493051b6
    77db493039bd:	movdqa xmm13,xmm0
    77db493039c2:	movdqu XMMWORD PTR [r12+0x230],xmm13
    77db493039cc:	mov    r13,r14
    77db493039cf:	add    r13,0xc0
    77db493039d6:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    77db493039dc:	movdqu XMMWORD PTR [r12+0x110],xmm5
    77db493039e6:	movdqa xmm0,xmm3
    77db493039ea:	movdqa xmm1,xmm6
    77db493039ee:	addpd  xmm0,xmm1
    77db493039f2:	movdqa xmm14,xmm0
    77db493039f7:	movdqu xmm15,XMMWORD PTR [rip+0x8c50]        # 0x77db4930c650
    77db49303a00:	pand   xmm14,xmm15
    77db49303a05:	movdqu xmm15,XMMWORD PTR [rip+0x8c52]        # 0x77db4930c660
    77db49303a0e:	pcmpeqq xmm14,xmm15
    77db49303a14:	movdqa xmm15,xmm0
    77db49303a19:	cmpunordpd xmm15,xmm0
    77db49303a1f:	por    xmm14,xmm15
    77db49303a24:	pmovmskb ecx,xmm14
    77db49303a29:	jrcxz  0x77db49303a30
    77db49303a2b:	jmp    0x77db493051da
    77db49303a30:	movdqa xmm8,xmm0
    77db49303a35:	movdqu XMMWORD PTR [r12+0x240],xmm8
    77db49303a3f:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    77db49303a49:	movdqu xmm1,XMMWORD PTR [r12+0x1a0]
    77db49303a53:	por    xmm0,xmm1
    77db49303a57:	movdqu XMMWORD PTR [r12+0x270],xmm0
    77db49303a61:	movdqu xmm6,XMMWORD PTR [r12+0x120]
    77db49303a6b:	movdqu xmm1,XMMWORD PTR [r12+0x120]
    77db49303a75:	por    xmm6,xmm1
    77db49303a79:	movdqu XMMWORD PTR [r12+0x1a0],xmm6
    77db49303a83:	movdqa xmm0,xmm5
    77db49303a87:	movdqa xmm1,xmm2
    77db49303a8b:	pshufd xmm1,xmm1,0x44
    77db49303a90:	mulpd  xmm0,xmm1
    77db49303a94:	movdqa xmm14,xmm0
    77db49303a99:	movdqu xmm15,XMMWORD PTR [rip+0x8bae]        # 0x77db4930c650
    77db49303aa2:	pand   xmm14,xmm15
    77db49303aa7:	movdqu xmm15,XMMWORD PTR [rip+0x8bb0]        # 0x77db4930c660
    77db49303ab0:	pcmpeqq xmm14,xmm15
    77db49303ab6:	movdqa xmm15,xmm0
    77db49303abb:	cmpunordpd xmm15,xmm0
    77db49303ac1:	por    xmm14,xmm15
    77db49303ac6:	pmovmskb ecx,xmm14
    77db49303acb:	jrcxz  0x77db49303ad2
    77db49303acd:	jmp    0x77db493051fe
    77db49303ad2:	movdqa xmm6,xmm0
    77db49303ad6:	movdqu XMMWORD PTR [r12+0x250],xmm6
    77db49303ae0:	mov    r13,r14
    77db49303ae3:	add    r13,0x20
    77db49303ae7:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    77db49303aed:	movdqu XMMWORD PTR [r12+0x110],xmm5
    77db49303af7:	movdqa xmm0,xmm10
    77db49303afc:	movdqa xmm1,xmm12
    77db49303b01:	addpd  xmm0,xmm1
    77db49303b05:	movdqa xmm14,xmm0
    77db49303b0a:	movdqu xmm15,XMMWORD PTR [rip+0x8b3d]        # 0x77db4930c650
    77db49303b13:	pand   xmm14,xmm15
    77db49303b18:	movdqu xmm15,XMMWORD PTR [rip+0x8b3f]        # 0x77db4930c660
    77db49303b21:	pcmpeqq xmm14,xmm15
    77db49303b27:	movdqa xmm15,xmm0
    77db49303b2c:	cmpunordpd xmm15,xmm0
    77db49303b32:	por    xmm14,xmm15
    77db49303b37:	pmovmskb ecx,xmm14
    77db49303b3c:	jrcxz  0x77db49303b43
    77db49303b3e:	jmp    0x77db49305222
    77db49303b43:	movdqa xmm3,xmm0
    77db49303b47:	movdqa xmm0,xmm7
    77db49303b4b:	movdqa xmm1,xmm2
    77db49303b4f:	pshufd xmm1,xmm1,0x44
    77db49303b54:	mulpd  xmm0,xmm1
    77db49303b58:	movdqa xmm14,xmm0
    77db49303b5d:	movdqu xmm15,XMMWORD PTR [rip+0x8aea]        # 0x77db4930c650
    77db49303b66:	pand   xmm14,xmm15
    77db49303b6b:	movdqu xmm15,XMMWORD PTR [rip+0x8aec]        # 0x77db4930c660
    77db49303b74:	pcmpeqq xmm14,xmm15
    77db49303b7a:	movdqa xmm15,xmm0
    77db49303b7f:	cmpunordpd xmm15,xmm0
    77db49303b85:	por    xmm14,xmm15
    77db49303b8a:	pmovmskb ecx,xmm14
    77db49303b8f:	jrcxz  0x77db49303b96
    77db49303b91:	jmp    0x77db49305248
    77db49303b96:	movdqa xmm10,xmm0
    77db49303b9b:	movdqa xmm0,xmm11
    77db49303ba0:	movdqa xmm1,xmm13
    77db49303ba5:	addpd  xmm0,xmm1
    77db49303ba9:	movdqa xmm14,xmm0
    77db49303bae:	movdqu xmm15,XMMWORD PTR [rip+0x8a99]        # 0x77db4930c650
    77db49303bb7:	pand   xmm14,xmm15
    77db49303bbc:	movdqu xmm15,XMMWORD PTR [rip+0x8a9b]        # 0x77db4930c660
    77db49303bc5:	pcmpeqq xmm14,xmm15
    77db49303bcb:	movdqa xmm15,xmm0
    77db49303bd0:	cmpunordpd xmm15,xmm0
    77db49303bd6:	por    xmm14,xmm15
    77db49303bdb:	pmovmskb ecx,xmm14
    77db49303be0:	jrcxz  0x77db49303be7
    77db49303be2:	jmp    0x77db4930526c
    77db49303be7:	movdqa xmm2,xmm0
    77db49303beb:	movdqu xmm7,XMMWORD PTR [r12+0x150]
    77db49303bf5:	movdqa xmm0,xmm5
    77db49303bf9:	movdqa xmm1,xmm7
    77db49303bfd:	pshufd xmm1,xmm1,0x44
    77db49303c02:	mulpd  xmm0,xmm1
    77db49303c06:	movdqa xmm14,xmm0
    77db49303c0b:	movdqu xmm15,XMMWORD PTR [rip+0x8a3c]        # 0x77db4930c650
    77db49303c14:	pand   xmm14,xmm15
    77db49303c19:	movdqu xmm15,XMMWORD PTR [rip+0x8a3e]        # 0x77db4930c660
    77db49303c22:	pcmpeqq xmm14,xmm15
    77db49303c28:	movdqa xmm15,xmm0
    77db49303c2d:	cmpunordpd xmm15,xmm0
    77db49303c33:	por    xmm14,xmm15
    77db49303c38:	pmovmskb ecx,xmm14
    77db49303c3d:	jrcxz  0x77db49303c44
    77db49303c3f:	jmp    0x77db49305292
    77db49303c44:	movdqa xmm11,xmm0
    77db49303c49:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    77db49303c53:	movdqa xmm1,xmm7
    77db49303c57:	pshufd xmm1,xmm1,0x44
    77db49303c5c:	mulpd  xmm0,xmm1
    77db49303c60:	movdqa xmm14,xmm0
    77db49303c65:	movdqu xmm15,XMMWORD PTR [rip+0x89e2]        # 0x77db4930c650
    77db49303c6e:	pand   xmm14,xmm15
    77db49303c73:	movdqu xmm15,XMMWORD PTR [rip+0x89e4]        # 0x77db4930c660
    77db49303c7c:	pcmpeqq xmm14,xmm15
    77db49303c82:	movdqa xmm15,xmm0
    77db49303c87:	cmpunordpd xmm15,xmm0
    77db49303c8d:	por    xmm14,xmm15
    77db49303c92:	pmovmskb ecx,xmm14
    77db49303c97:	jrcxz  0x77db49303c9e
    77db49303c99:	jmp    0x77db493052b6
    77db49303c9e:	movdqa xmm5,xmm0
    77db49303ca2:	movdqa xmm0,xmm8
    77db49303ca7:	movdqa xmm1,xmm4
    77db49303cab:	addpd  xmm0,xmm1
    77db49303caf:	movdqa xmm14,xmm0
    77db49303cb4:	movdqu xmm15,XMMWORD PTR [rip+0x8993]        # 0x77db4930c650
    77db49303cbd:	pand   xmm14,xmm15
    77db49303cc2:	movdqu xmm15,XMMWORD PTR [rip+0x8995]        # 0x77db4930c660
    77db49303ccb:	pcmpeqq xmm14,xmm15
    77db49303cd1:	movdqa xmm15,xmm0
    77db49303cd6:	cmpunordpd xmm15,xmm0
    77db49303cdc:	por    xmm14,xmm15
    77db49303ce1:	pmovmskb ecx,xmm14
    77db49303ce6:	jrcxz  0x77db49303ced
    77db49303ce8:	jmp    0x77db493052e0
    77db49303ced:	movdqa xmm12,xmm0
    77db49303cf2:	movdqu XMMWORD PTR [r12+0x240],xmm12
    77db49303cfc:	movdqa xmm0,xmm9
    77db49303d01:	movdqa xmm1,xmm6
    77db49303d05:	addpd  xmm0,xmm1
    77db49303d09:	movdqa xmm14,xmm0
    77db49303d0e:	movdqu xmm15,XMMWORD PTR [rip+0x8939]        # 0x77db4930c650
    77db49303d17:	pand   xmm14,xmm15
    77db49303d1c:	movdqu xmm15,XMMWORD PTR [rip+0x893b]        # 0x77db4930c660
    77db49303d25:	pcmpeqq xmm14,xmm15
    77db49303d2b:	movdqa xmm15,xmm0
    77db49303d30:	cmpunordpd xmm15,xmm0
    77db49303d36:	por    xmm14,xmm15
    77db49303d3b:	pmovmskb ecx,xmm14
    77db49303d40:	jrcxz  0x77db49303d47
    77db49303d42:	jmp    0x77db49305305
    77db49303d47:	movdqa xmm4,xmm0
    77db49303d4b:	movdqu XMMWORD PTR [r12+0x220],xmm4
    77db49303d55:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    77db49303d5f:	movdqa xmm1,xmm7
    77db49303d63:	pshufd xmm1,xmm1,0x44
    77db49303d68:	mulpd  xmm0,xmm1
    77db49303d6c:	movdqa xmm14,xmm0
    77db49303d71:	movdqu xmm15,XMMWORD PTR [rip+0x88d6]        # 0x77db4930c650
    77db49303d7a:	pand   xmm14,xmm15
    77db49303d7f:	movdqu xmm15,XMMWORD PTR [rip+0x88d8]        # 0x77db4930c660
    77db49303d88:	pcmpeqq xmm14,xmm15
    77db49303d8e:	movdqa xmm15,xmm0
    77db49303d93:	cmpunordpd xmm15,xmm0
    77db49303d99:	por    xmm14,xmm15
    77db49303d9e:	pmovmskb ecx,xmm14
    77db49303da3:	jrcxz  0x77db49303daa
    77db49303da5:	jmp    0x77db4930532a
    77db49303daa:	movdqa xmm6,xmm0
    77db49303dae:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    77db49303db8:	movdqa xmm1,xmm7
    77db49303dbc:	pshufd xmm1,xmm1,0x44
    77db49303dc1:	mulpd  xmm0,xmm1
    77db49303dc5:	movdqa xmm14,xmm0
    77db49303dca:	movdqu xmm15,XMMWORD PTR [rip+0x887d]        # 0x77db4930c650
    77db49303dd3:	pand   xmm14,xmm15
    77db49303dd8:	movdqu xmm15,XMMWORD PTR [rip+0x887f]        # 0x77db4930c660
    77db49303de1:	pcmpeqq xmm14,xmm15
    77db49303de7:	movdqa xmm15,xmm0
    77db49303dec:	cmpunordpd xmm15,xmm0
    77db49303df2:	por    xmm14,xmm15
    77db49303df7:	pmovmskb ecx,xmm14
    77db49303dfc:	jrcxz  0x77db49303e03
    77db49303dfe:	jmp    0x77db49305354
    77db49303e03:	movdqa xmm8,xmm0
    77db49303e08:	movdqu XMMWORD PTR [r12+0x150],xmm8
    77db49303e12:	movdqa xmm0,xmm3
    77db49303e16:	movdqa xmm1,xmm10
    77db49303e1b:	addpd  xmm0,xmm1
    77db49303e1f:	movdqa xmm14,xmm0
    77db49303e24:	movdqu xmm15,XMMWORD PTR [rip+0x8823]        # 0x77db4930c650
    77db49303e2d:	pand   xmm14,xmm15
    77db49303e32:	movdqu xmm15,XMMWORD PTR [rip+0x8825]        # 0x77db4930c660
    77db49303e3b:	pcmpeqq xmm14,xmm15
    77db49303e41:	movdqa xmm15,xmm0
    77db49303e46:	cmpunordpd xmm15,xmm0
    77db49303e4c:	por    xmm14,xmm15
    77db49303e51:	pmovmskb ecx,xmm14
    77db49303e56:	jrcxz  0x77db49303e5d
    77db49303e58:	jmp    0x77db4930537e
    77db49303e5d:	movdqa xmm7,xmm0
    77db49303e61:	movdqu XMMWORD PTR [r12+0x160],xmm7
    77db49303e6b:	movdqa xmm0,xmm2
    77db49303e6f:	movdqa xmm1,xmm11
    77db49303e74:	addpd  xmm0,xmm1
    77db49303e78:	movdqa xmm14,xmm0
    77db49303e7d:	movdqu xmm15,XMMWORD PTR [rip+0x87ca]        # 0x77db4930c650
    77db49303e86:	pand   xmm14,xmm15
    77db49303e8b:	movdqu xmm15,XMMWORD PTR [rip+0x87cc]        # 0x77db4930c660
    77db49303e94:	pcmpeqq xmm14,xmm15
    77db49303e9a:	movdqa xmm15,xmm0
    77db49303e9f:	cmpunordpd xmm15,xmm0
    77db49303ea5:	por    xmm14,xmm15
    77db49303eaa:	pmovmskb ecx,xmm14
    77db49303eaf:	jrcxz  0x77db49303eb6
    77db49303eb1:	jmp    0x77db493053a3
    77db49303eb6:	movdqa xmm3,xmm0
    77db49303eba:	movdqu XMMWORD PTR [r12+0x170],xmm3
    77db49303ec4:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    77db49303ece:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    77db49303ed8:	movdqa xmm1,xmm2
    77db49303edc:	pshufd xmm1,xmm1,0x44
    77db49303ee1:	mulpd  xmm0,xmm1
    77db49303ee5:	movdqa xmm14,xmm0
    77db49303eea:	movdqu xmm15,XMMWORD PTR [rip+0x875d]        # 0x77db4930c650
    77db49303ef3:	pand   xmm14,xmm15
    77db49303ef8:	movdqu xmm15,XMMWORD PTR [rip+0x875f]        # 0x77db4930c660
    77db49303f01:	pcmpeqq xmm14,xmm15
    77db49303f07:	movdqa xmm15,xmm0
    77db49303f0c:	cmpunordpd xmm15,xmm0
    77db49303f12:	por    xmm14,xmm15
    77db49303f17:	pmovmskb ecx,xmm14
    77db49303f1c:	jrcxz  0x77db49303f23
    77db49303f1e:	jmp    0x77db493053c8
    77db49303f23:	movdqa xmm9,xmm0
    77db49303f28:	movdqu XMMWORD PTR [r12+0x180],xmm9
    77db49303f32:	movdqa xmm0,xmm4
    77db49303f36:	movdqa xmm1,xmm5
    77db49303f3a:	addpd  xmm0,xmm1
    77db49303f3e:	movdqa xmm14,xmm0
    77db49303f43:	movdqu xmm15,XMMWORD PTR [rip+0x8704]        # 0x77db4930c650
    77db49303f4c:	pand   xmm14,xmm15
    77db49303f51:	movdqu xmm15,XMMWORD PTR [rip+0x8706]        # 0x77db4930c660
    77db49303f5a:	pcmpeqq xmm14,xmm15
    77db49303f60:	movdqa xmm15,xmm0
    77db49303f65:	cmpunordpd xmm15,xmm0
    77db49303f6b:	por    xmm14,xmm15
    77db49303f70:	pmovmskb ecx,xmm14
    77db49303f75:	jrcxz  0x77db49303f7c
    77db49303f77:	jmp    0x77db493053f2
    77db49303f7c:	movdqa xmm10,xmm0
    77db49303f81:	movdqu XMMWORD PTR [r12+0x210],xmm10
    77db49303f8b:	movdqa xmm0,xmm12
    77db49303f90:	movdqa xmm1,xmm6
    77db49303f94:	addpd  xmm0,xmm1
    77db49303f98:	movdqa xmm14,xmm0
    77db49303f9d:	movdqu xmm15,XMMWORD PTR [rip+0x86aa]        # 0x77db4930c650
    77db49303fa6:	pand   xmm14,xmm15
    77db49303fab:	movdqu xmm15,XMMWORD PTR [rip+0x86ac]        # 0x77db4930c660
    77db49303fb4:	pcmpeqq xmm14,xmm15
    77db49303fba:	movdqa xmm15,xmm0
    77db49303fbf:	cmpunordpd xmm15,xmm0
    77db49303fc5:	por    xmm14,xmm15
    77db49303fca:	pmovmskb ecx,xmm14
    77db49303fcf:	jrcxz  0x77db49303fd6
    77db49303fd1:	jmp    0x77db49305416
    77db49303fd6:	movdqa xmm4,xmm0
    77db49303fda:	movdqu XMMWORD PTR [r12+0x230],xmm4
    77db49303fe4:	movdqu xmm5,XMMWORD PTR [r12+0x2a0]
    77db49303fee:	movdqu xmm1,XMMWORD PTR [r12+0x2a0]
    77db49303ff8:	por    xmm5,xmm1
    77db49303ffc:	movdqu XMMWORD PTR [r12+0x250],xmm5
    77db49304006:	movdqu xmm5,XMMWORD PTR [r12+0x1d0]
    77db49304010:	movdqu xmm1,XMMWORD PTR [r12+0x1d0]
    77db4930401a:	por    xmm5,xmm1
    77db4930401e:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    77db49304028:	movdqu xmm6,XMMWORD PTR [r12+0x2c0]
    77db49304032:	movdqu xmm1,XMMWORD PTR [r12+0x2c0]
    77db4930403c:	por    xmm6,xmm1
    77db49304040:	movdqu XMMWORD PTR [r12+0x1d0],xmm6
    77db4930404a:	mov    r13,r14
    77db4930404d:	add    r13,0x40
    77db49304051:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    77db49304057:	movdqu XMMWORD PTR [r12+0x2c0],xmm6
    77db49304061:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    77db4930406b:	movdqa xmm1,xmm2
    77db4930406f:	pshufd xmm1,xmm1,0x44
    77db49304074:	mulpd  xmm0,xmm1
    77db49304078:	movdqa xmm14,xmm0
    77db4930407d:	movdqu xmm15,XMMWORD PTR [rip+0x85ca]        # 0x77db4930c650
    77db49304086:	pand   xmm14,xmm15
    77db4930408b:	movdqu xmm15,XMMWORD PTR [rip+0x85cc]        # 0x77db4930c660
    77db49304094:	pcmpeqq xmm14,xmm15
    77db4930409a:	movdqa xmm15,xmm0
    77db4930409f:	cmpunordpd xmm15,xmm0
    77db493040a5:	por    xmm14,xmm15
    77db493040aa:	pmovmskb ecx,xmm14
    77db493040af:	jrcxz  0x77db493040b6
    77db493040b1:	jmp    0x77db4930543b
    77db493040b6:	movdqa xmm11,xmm0
    77db493040bb:	movdqa xmm0,xmm7
    77db493040bf:	movdqa xmm1,xmm8
    77db493040c4:	addpd  xmm0,xmm1
    77db493040c8:	movdqa xmm14,xmm0
    77db493040cd:	movdqu xmm15,XMMWORD PTR [rip+0x857a]        # 0x77db4930c650
    77db493040d6:	pand   xmm14,xmm15
    77db493040db:	movdqu xmm15,XMMWORD PTR [rip+0x857c]        # 0x77db4930c660
    77db493040e4:	pcmpeqq xmm14,xmm15
    77db493040ea:	movdqa xmm15,xmm0
    77db493040ef:	cmpunordpd xmm15,xmm0
    77db493040f5:	por    xmm14,xmm15
    77db493040fa:	pmovmskb ecx,xmm14
    77db493040ff:	jrcxz  0x77db49304106
    77db49304101:	jmp    0x77db49305465
    77db49304106:	movdqa xmm12,xmm0
    77db4930410b:	movdqa xmm0,xmm3
    77db4930410f:	movdqa xmm1,xmm9
    77db49304114:	addpd  xmm0,xmm1
    77db49304118:	movdqa xmm14,xmm0
    77db4930411d:	movdqu xmm15,XMMWORD PTR [rip+0x852a]        # 0x77db4930c650
    77db49304126:	pand   xmm14,xmm15
    77db4930412b:	movdqu xmm15,XMMWORD PTR [rip+0x852c]        # 0x77db4930c660
    77db49304134:	pcmpeqq xmm14,xmm15
    77db4930413a:	movdqa xmm15,xmm0
    77db4930413f:	cmpunordpd xmm15,xmm0
    77db49304145:	por    xmm14,xmm15
    77db4930414a:	pmovmskb ecx,xmm14
    77db4930414f:	jrcxz  0x77db49304156
    77db49304151:	jmp    0x77db4930548a
    77db49304156:	movdqa xmm7,xmm0
    77db4930415a:	movdqu XMMWORD PTR [r12+0x160],xmm7
    77db49304164:	movdqa xmm0,xmm6
    77db49304168:	movdqa xmm1,xmm2
    77db4930416c:	pshufd xmm1,xmm1,0x44
    77db49304171:	mulpd  xmm0,xmm1
    77db49304175:	movdqa xmm14,xmm0
    77db4930417a:	movdqu xmm15,XMMWORD PTR [rip+0x84cd]        # 0x77db4930c650
    77db49304183:	pand   xmm14,xmm15
    77db49304188:	movdqu xmm15,XMMWORD PTR [rip+0x84cf]        # 0x77db4930c660
    77db49304191:	pcmpeqq xmm14,xmm15
    77db49304197:	movdqa xmm15,xmm0
    77db4930419c:	cmpunordpd xmm15,xmm0
    77db493041a2:	por    xmm14,xmm15
    77db493041a7:	pmovmskb ecx,xmm14
    77db493041ac:	jrcxz  0x77db493041b3
    77db493041ae:	jmp    0x77db493054af
    77db493041b3:	movdqa xmm3,xmm0
    77db493041b7:	movdqu XMMWORD PTR [r12+0x240],xmm3
    77db493041c1:	movdqu xmm6,XMMWORD PTR [r12+0x2b0]
    77db493041cb:	movdqa xmm0,xmm6
    77db493041cf:	movdqa xmm1,xmm2
    77db493041d3:	pshufd xmm1,xmm1,0x44
    77db493041d8:	mulpd  xmm0,xmm1
    77db493041dc:	movdqa xmm14,xmm0
    77db493041e1:	movdqu xmm15,XMMWORD PTR [rip+0x8466]        # 0x77db4930c650
    77db493041ea:	pand   xmm14,xmm15
    77db493041ef:	movdqu xmm15,XMMWORD PTR [rip+0x8468]        # 0x77db4930c660
    77db493041f8:	pcmpeqq xmm14,xmm15
    77db493041fe:	movdqa xmm15,xmm0
    77db49304203:	cmpunordpd xmm15,xmm0
    77db49304209:	por    xmm14,xmm15
    77db4930420e:	pmovmskb ecx,xmm14
    77db49304213:	jrcxz  0x77db4930421a
    77db49304215:	jmp    0x77db493054d3
    77db4930421a:	movdqa xmm8,xmm0
    77db4930421f:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    77db49304229:	movdqa xmm0,xmm5
    77db4930422d:	movdqa xmm1,xmm2
    77db49304231:	pshufd xmm1,xmm1,0x44
    77db49304236:	mulpd  xmm0,xmm1
    77db4930423a:	movdqa xmm14,xmm0
    77db4930423f:	movdqu xmm15,XMMWORD PTR [rip+0x8408]        # 0x77db4930c650
    77db49304248:	pand   xmm14,xmm15
    77db4930424d:	movdqu xmm15,XMMWORD PTR [rip+0x840a]        # 0x77db4930c660
    77db49304256:	pcmpeqq xmm14,xmm15
    77db4930425c:	movdqa xmm15,xmm0
    77db49304261:	cmpunordpd xmm15,xmm0
    77db49304267:	por    xmm14,xmm15
    77db4930426c:	pmovmskb ecx,xmm14
    77db49304271:	jrcxz  0x77db49304278
    77db49304273:	jmp    0x77db493054f7
    77db49304278:	movdqa xmm6,xmm0
    77db4930427c:	movdqu XMMWORD PTR [r12+0x170],xmm6
    77db49304286:	movdqa xmm0,xmm10
    77db4930428b:	movdqa xmm1,xmm11
    77db49304290:	addpd  xmm0,xmm1
    77db49304294:	movdqa xmm14,xmm0
    77db49304299:	movdqu xmm15,XMMWORD PTR [rip+0x83ae]        # 0x77db4930c650
    77db493042a2:	pand   xmm14,xmm15
    77db493042a7:	movdqu xmm15,XMMWORD PTR [rip+0x83b0]        # 0x77db4930c660
    77db493042b0:	pcmpeqq xmm14,xmm15
    77db493042b6:	movdqa xmm15,xmm0
    77db493042bb:	cmpunordpd xmm15,xmm0
    77db493042c1:	por    xmm14,xmm15
    77db493042c6:	pmovmskb ecx,xmm14
    77db493042cb:	jrcxz  0x77db493042d2
    77db493042cd:	jmp    0x77db4930551b
    77db493042d2:	movdqa xmm5,xmm0
    77db493042d6:	movdqu XMMWORD PTR [r12+0x180],xmm5
    77db493042e0:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    77db493042ea:	movdqa xmm1,xmm2
    77db493042ee:	pshufd xmm1,xmm1,0x44
    77db493042f3:	mulpd  xmm0,xmm1
    77db493042f7:	movdqa xmm14,xmm0
    77db493042fc:	movdqu xmm15,XMMWORD PTR [rip+0x834b]        # 0x77db4930c650
    77db49304305:	pand   xmm14,xmm15
    77db4930430a:	movdqu xmm15,XMMWORD PTR [rip+0x834d]        # 0x77db4930c660
    77db49304313:	pcmpeqq xmm14,xmm15
    77db49304319:	movdqa xmm15,xmm0
    77db4930431e:	cmpunordpd xmm15,xmm0
    77db49304324:	por    xmm14,xmm15
    77db49304329:	pmovmskb ecx,xmm14
    77db4930432e:	jrcxz  0x77db49304335
    77db49304330:	jmp    0x77db49305541
    77db49304335:	movdqa xmm9,xmm0
    77db4930433a:	movdqu XMMWORD PTR [r12+0x210],xmm9
    77db49304344:	movdqa xmm0,xmm4
    77db49304348:	movdqa xmm1,xmm3
    77db4930434c:	addpd  xmm0,xmm1
    77db49304350:	movdqa xmm14,xmm0
    77db49304355:	movdqu xmm15,XMMWORD PTR [rip+0x82f2]        # 0x77db4930c650
    77db4930435e:	pand   xmm14,xmm15
    77db49304363:	movdqu xmm15,XMMWORD PTR [rip+0x82f4]        # 0x77db4930c660
    77db4930436c:	pcmpeqq xmm14,xmm15
    77db49304372:	movdqa xmm15,xmm0
    77db49304377:	cmpunordpd xmm15,xmm0
    77db4930437d:	por    xmm14,xmm15
    77db49304382:	pmovmskb ecx,xmm14
    77db49304387:	jrcxz  0x77db4930438e
    77db49304389:	jmp    0x77db4930556b
    77db4930438e:	movdqa xmm10,xmm0
    77db49304393:	movdqu XMMWORD PTR [r12+0x220],xmm10
    77db4930439d:	movdqu xmm3,XMMWORD PTR [r12+0x290]
    77db493043a7:	movdqa xmm0,xmm3
    77db493043ab:	movdqa xmm1,xmm2
    77db493043af:	pshufd xmm1,xmm1,0x44
    77db493043b4:	mulpd  xmm0,xmm1
    77db493043b8:	movdqa xmm14,xmm0
    77db493043bd:	movdqu xmm15,XMMWORD PTR [rip+0x828a]        # 0x77db4930c650
    77db493043c6:	pand   xmm14,xmm15
    77db493043cb:	movdqu xmm15,XMMWORD PTR [rip+0x828c]        # 0x77db4930c660
    77db493043d4:	pcmpeqq xmm14,xmm15
    77db493043da:	movdqa xmm15,xmm0
    77db493043df:	cmpunordpd xmm15,xmm0
    77db493043e5:	por    xmm14,xmm15
    77db493043ea:	pmovmskb ecx,xmm14
    77db493043ef:	jrcxz  0x77db493043f6
    77db493043f1:	jmp    0x77db4930558f
    77db493043f6:	movdqa xmm4,xmm0
    77db493043fa:	movdqu XMMWORD PTR [r12+0x230],xmm4
    77db49304404:	movdqa xmm0,xmm12
    77db49304409:	movdqa xmm1,xmm8
    77db4930440e:	addpd  xmm0,xmm1
    77db49304412:	movdqa xmm14,xmm0
    77db49304417:	movdqu xmm15,XMMWORD PTR [rip+0x8230]        # 0x77db4930c650
    77db49304420:	pand   xmm14,xmm15
    77db49304425:	movdqu xmm15,XMMWORD PTR [rip+0x8232]        # 0x77db4930c660
    77db4930442e:	pcmpeqq xmm14,xmm15
    77db49304434:	movdqa xmm15,xmm0
    77db49304439:	cmpunordpd xmm15,xmm0
    77db4930443f:	por    xmm14,xmm15
    77db49304444:	pmovmskb ecx,xmm14
    77db49304449:	jrcxz  0x77db49304450
    77db4930444b:	jmp    0x77db493055b3
    77db49304450:	movdqa xmm3,xmm0
    77db49304454:	movdqu XMMWORD PTR [r12+0x140],xmm3
    77db4930445e:	movdqu xmm8,XMMWORD PTR [r12+0x1e0]
    77db49304468:	movdqa xmm0,xmm8
    77db4930446d:	movdqa xmm1,xmm2
    77db49304471:	pshufd xmm1,xmm1,0x44
    77db49304476:	mulpd  xmm0,xmm1
    77db4930447a:	movdqa xmm14,xmm0
    77db4930447f:	movdqu xmm15,XMMWORD PTR [rip+0x81c8]        # 0x77db4930c650
    77db49304488:	pand   xmm14,xmm15
    77db4930448d:	movdqu xmm15,XMMWORD PTR [rip+0x81ca]        # 0x77db4930c660
    77db49304496:	pcmpeqq xmm14,xmm15
    77db4930449c:	movdqa xmm15,xmm0
    77db493044a1:	cmpunordpd xmm15,xmm0
    77db493044a7:	por    xmm14,xmm15
    77db493044ac:	pmovmskb ecx,xmm14
    77db493044b1:	jrcxz  0x77db493044b8
    77db493044b3:	jmp    0x77db493055d9
    77db493044b8:	movdqa xmm11,xmm0
    77db493044bd:	movdqu XMMWORD PTR [r12+0x130],xmm11
    77db493044c7:	movdqa xmm0,xmm7
    77db493044cb:	movdqa xmm1,xmm6
    77db493044cf:	addpd  xmm0,xmm1
    77db493044d3:	movdqa xmm14,xmm0
    77db493044d8:	movdqu xmm15,XMMWORD PTR [rip+0x816f]        # 0x77db4930c650
    77db493044e1:	pand   xmm14,xmm15
    77db493044e6:	movdqu xmm15,XMMWORD PTR [rip+0x8171]        # 0x77db4930c660
    77db493044ef:	pcmpeqq xmm14,xmm15
    77db493044f5:	movdqa xmm15,xmm0
    77db493044fa:	cmpunordpd xmm15,xmm0
    77db49304500:	por    xmm14,xmm15
    77db49304505:	pmovmskb ecx,xmm14
    77db4930450a:	jrcxz  0x77db49304511
    77db4930450c:	jmp    0x77db493055fe
    77db49304511:	movdqa xmm2,xmm0
    77db49304515:	movdqu XMMWORD PTR [r12+0x150],xmm2
    77db4930451f:	mov    r13,r14
    77db49304522:	add    r13,0x70
    77db49304526:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    77db4930452c:	movdqu XMMWORD PTR [r12+0x240],xmm6
    77db49304536:	movdqa xmm0,xmm5
    77db4930453a:	movdqa xmm1,xmm9
    77db4930453f:	addpd  xmm0,xmm1
    77db49304543:	movdqa xmm14,xmm0
    77db49304548:	movdqu xmm15,XMMWORD PTR [rip+0x80ff]        # 0x77db4930c650
    77db49304551:	pand   xmm14,xmm15
    77db49304556:	movdqu xmm15,XMMWORD PTR [rip+0x8101]        # 0x77db4930c660
    77db4930455f:	pcmpeqq xmm14,xmm15
    77db49304565:	movdqa xmm15,xmm0
    77db4930456a:	cmpunordpd xmm15,xmm0
    77db49304570:	por    xmm14,xmm15
    77db49304575:	pmovmskb ecx,xmm14
    77db4930457a:	jrcxz  0x77db49304581
    77db4930457c:	jmp    0x77db49305622
    77db49304581:	movdqa xmm7,xmm0
    77db49304585:	movdqu XMMWORD PTR [r12+0x170],xmm7
    77db4930458f:	movdqu xmm5,XMMWORD PTR [r12+0x280]
    77db49304599:	movdqa xmm0,xmm6
    77db4930459d:	movdqa xmm1,xmm5
    77db493045a1:	pshufd xmm1,xmm1,0x44
    77db493045a6:	mulpd  xmm0,xmm1
    77db493045aa:	movdqa xmm14,xmm0
    77db493045af:	movdqu xmm15,XMMWORD PTR [rip+0x8098]        # 0x77db4930c650
    77db493045b8:	pand   xmm14,xmm15
    77db493045bd:	movdqu xmm15,XMMWORD PTR [rip+0x809a]        # 0x77db4930c660
    77db493045c6:	pcmpeqq xmm14,xmm15
    77db493045cc:	movdqa xmm15,xmm0
    77db493045d1:	cmpunordpd xmm15,xmm0
    77db493045d7:	por    xmm14,xmm15
    77db493045dc:	pmovmskb ecx,xmm14
    77db493045e1:	jrcxz  0x77db493045e8
    77db493045e3:	jmp    0x77db49305647
    77db493045e8:	movdqa xmm8,xmm0
    77db493045ed:	movdqu XMMWORD PTR [r12+0x160],xmm8
    77db493045f7:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    77db49304601:	movdqa xmm1,xmm5
    77db49304605:	pshufd xmm1,xmm1,0x44
    77db4930460a:	mulpd  xmm0,xmm1
    77db4930460e:	movdqa xmm14,xmm0
    77db49304613:	movdqu xmm15,XMMWORD PTR [rip+0x8034]        # 0x77db4930c650
    77db4930461c:	pand   xmm14,xmm15
    77db49304621:	movdqu xmm15,XMMWORD PTR [rip+0x8036]        # 0x77db4930c660
    77db4930462a:	pcmpeqq xmm14,xmm15
    77db49304630:	movdqa xmm15,xmm0
    77db49304635:	cmpunordpd xmm15,xmm0
    77db4930463b:	por    xmm14,xmm15
    77db49304640:	pmovmskb ecx,xmm14
    77db49304645:	jrcxz  0x77db4930464c
    77db49304647:	jmp    0x77db4930566b
    77db4930464c:	movdqa xmm6,xmm0
    77db49304650:	movdqu XMMWORD PTR [r12+0x180],xmm6
    77db4930465a:	movdqa xmm0,xmm10
    77db4930465f:	movdqa xmm1,xmm4
    77db49304663:	addpd  xmm0,xmm1
    77db49304667:	movdqa xmm14,xmm0
    77db4930466c:	movdqu xmm15,XMMWORD PTR [rip+0x7fdb]        # 0x77db4930c650
    77db49304675:	pand   xmm14,xmm15
    77db4930467a:	movdqu xmm15,XMMWORD PTR [rip+0x7fdd]        # 0x77db4930c660
    77db49304683:	pcmpeqq xmm14,xmm15
    77db49304689:	movdqa xmm15,xmm0
    77db4930468e:	cmpunordpd xmm15,xmm0
    77db49304694:	por    xmm14,xmm15
    77db49304699:	pmovmskb ecx,xmm14
    77db4930469e:	jrcxz  0x77db493046a5
    77db493046a0:	jmp    0x77db49305695
    77db493046a5:	movdqa xmm9,xmm0
    77db493046aa:	movdqu XMMWORD PTR [r12+0x210],xmm9
    77db493046b4:	mov    r13,r14
    77db493046b7:	add    r13,0x10
    77db493046bb:	movdqu xmm4,XMMWORD PTR [r14]
    77db493046c0:	movdqu xmm10,XMMWORD PTR [r13+0x0]
    77db493046c6:	movdqu XMMWORD PTR [r12+0x230],xmm10
    77db493046d0:	movdqa xmm0,xmm3
    77db493046d4:	movdqa xmm1,xmm11
    77db493046d9:	addpd  xmm0,xmm1
    77db493046dd:	movdqa xmm14,xmm0
    77db493046e2:	movdqu xmm15,XMMWORD PTR [rip+0x7f65]        # 0x77db4930c650
    77db493046eb:	pand   xmm14,xmm15
    77db493046f0:	movdqu xmm15,XMMWORD PTR [rip+0x7f67]        # 0x77db4930c660
    77db493046f9:	pcmpeqq xmm14,xmm15
    77db493046ff:	movdqa xmm15,xmm0
    77db49304704:	cmpunordpd xmm15,xmm0
    77db4930470a:	por    xmm14,xmm15
    77db4930470f:	pmovmskb ecx,xmm14
    77db49304714:	jrcxz  0x77db4930471b
    77db49304716:	jmp    0x77db493056ba
    77db4930471b:	movdqa xmm12,xmm0
    77db49304720:	movdqu XMMWORD PTR [r12+0x130],xmm12
    77db4930472a:	movdqa xmm0,xmm10
    77db4930472f:	movdqa xmm1,xmm5
    77db49304733:	pshufd xmm1,xmm1,0x44
    77db49304738:	mulpd  xmm0,xmm1
    77db4930473c:	movdqa xmm14,xmm0
    77db49304741:	movdqu xmm15,XMMWORD PTR [rip+0x7f06]        # 0x77db4930c650
    77db4930474a:	pand   xmm14,xmm15
    77db4930474f:	movdqu xmm15,XMMWORD PTR [rip+0x7f08]        # 0x77db4930c660
    77db49304758:	pcmpeqq xmm14,xmm15
    77db4930475e:	movdqa xmm15,xmm0
    77db49304763:	cmpunordpd xmm15,xmm0
    77db49304769:	por    xmm14,xmm15
    77db4930476e:	pmovmskb ecx,xmm14
    77db49304773:	jrcxz  0x77db4930477a
    77db49304775:	jmp    0x77db493056df
    77db4930477a:	movdqa xmm3,xmm0
    77db4930477e:	movdqu XMMWORD PTR [r12+0x220],xmm3
    77db49304788:	movdqa xmm0,xmm4
    77db4930478c:	movdqa xmm1,xmm5
    77db49304790:	pshufd xmm1,xmm1,0x44
    77db49304795:	mulpd  xmm0,xmm1
    77db49304799:	movdqa xmm14,xmm0
    77db4930479e:	movdqu xmm15,XMMWORD PTR [rip+0x7ea9]        # 0x77db4930c650
    77db493047a7:	pand   xmm14,xmm15
    77db493047ac:	movdqu xmm15,XMMWORD PTR [rip+0x7eab]        # 0x77db4930c660
    77db493047b5:	pcmpeqq xmm14,xmm15
    77db493047bb:	movdqa xmm15,xmm0
    77db493047c0:	cmpunordpd xmm15,xmm0
    77db493047c6:	por    xmm14,xmm15
    77db493047cb:	pmovmskb ecx,xmm14
    77db493047d0:	jrcxz  0x77db493047d7
    77db493047d2:	jmp    0x77db49305704
    77db493047d7:	movdqa xmm10,xmm0
    77db493047dc:	movdqa xmm0,xmm2
    77db493047e0:	movdqa xmm1,xmm8
    77db493047e5:	addpd  xmm0,xmm1
    77db493047e9:	movdqa xmm14,xmm0
    77db493047ee:	movdqu xmm15,XMMWORD PTR [rip+0x7e59]        # 0x77db4930c650
    77db493047f7:	pand   xmm14,xmm15
    77db493047fc:	movdqu xmm15,XMMWORD PTR [rip+0x7e5b]        # 0x77db4930c660
    77db49304805:	pcmpeqq xmm14,xmm15
    77db4930480b:	movdqa xmm15,xmm0
    77db49304810:	cmpunordpd xmm15,xmm0
    77db49304816:	por    xmm14,xmm15
    77db4930481b:	pmovmskb ecx,xmm14
    77db49304820:	jrcxz  0x77db49304827
    77db49304822:	jmp    0x77db49305728
    77db49304827:	movdqa xmm4,xmm0
    77db4930482b:	movdqu XMMWORD PTR [r12+0x140],xmm4
    77db49304835:	movdqa xmm0,xmm7
    77db49304839:	movdqa xmm1,xmm6
    77db4930483d:	addpd  xmm0,xmm1
    77db49304841:	movdqa xmm14,xmm0
    77db49304846:	movdqu xmm15,XMMWORD PTR [rip+0x7e01]        # 0x77db4930c650
    77db4930484f:	pand   xmm14,xmm15
    77db49304854:	movdqu xmm15,XMMWORD PTR [rip+0x7e03]        # 0x77db4930c660
    77db4930485d:	pcmpeqq xmm14,xmm15
    77db49304863:	movdqa xmm15,xmm0
    77db49304868:	cmpunordpd xmm15,xmm0
    77db4930486e:	por    xmm14,xmm15
    77db49304873:	pmovmskb ecx,xmm14
    77db49304878:	jrcxz  0x77db4930487f
    77db4930487a:	jmp    0x77db4930574d
    77db4930487f:	movdqa xmm2,xmm0
    77db49304883:	movdqu XMMWORD PTR [r12+0x150],xmm2
    77db4930488d:	movdqa xmm0,xmm9
    77db49304892:	movdqa xmm1,xmm3
    77db49304896:	addpd  xmm0,xmm1
    77db4930489a:	movdqa xmm14,xmm0
    77db4930489f:	movdqu xmm15,XMMWORD PTR [rip+0x7da8]        # 0x77db4930c650
    77db493048a8:	pand   xmm14,xmm15
    77db493048ad:	movdqu xmm15,XMMWORD PTR [rip+0x7daa]        # 0x77db4930c660
    77db493048b6:	pcmpeqq xmm14,xmm15
    77db493048bc:	movdqa xmm15,xmm0
    77db493048c1:	cmpunordpd xmm15,xmm0
    77db493048c7:	por    xmm14,xmm15
    77db493048cc:	pmovmskb ecx,xmm14
    77db493048d1:	jrcxz  0x77db493048d8
    77db493048d3:	jmp    0x77db49305771
    77db493048d8:	movdqa xmm5,xmm0
    77db493048dc:	movdqu XMMWORD PTR [r12+0x160],xmm5
    77db493048e6:	movdqa xmm0,xmm12
    77db493048eb:	movdqa xmm1,xmm10
    77db493048f0:	addpd  xmm0,xmm1
    77db493048f4:	movdqa xmm14,xmm0
    77db493048f9:	movdqu xmm15,XMMWORD PTR [rip+0x7d4e]        # 0x77db4930c650
    77db49304902:	pand   xmm14,xmm15
    77db49304907:	movdqu xmm15,XMMWORD PTR [rip+0x7d50]        # 0x77db4930c660
    77db49304910:	pcmpeqq xmm14,xmm15
    77db49304916:	movdqa xmm15,xmm0
    77db4930491b:	cmpunordpd xmm15,xmm0
    77db49304921:	por    xmm14,xmm15
    77db49304926:	pmovmskb ecx,xmm14
    77db4930492b:	jrcxz  0x77db49304932
    77db4930492d:	jmp    0x77db49305796
    77db49304932:	movdqa xmm3,xmm0
    77db49304936:	movdqu XMMWORD PTR [r12+0x120],xmm3
    77db49304940:	mov    r13,r15
    77db49304943:	add    r13,0x10
    77db49304947:	movdqu XMMWORD PTR [r15],xmm4
    77db4930494c:	mov    r14d,0x0
    77db49304952:	mov    DWORD PTR [r12+0x32c],r14d
    77db4930495a:	movdqu XMMWORD PTR [r13+0x0],xmm2
    77db49304960:	add    r15,0x20
    77db49304964:	mov    r13,r15
    77db49304967:	add    r13,0x10
    77db4930496b:	movdqu XMMWORD PTR [r15],xmm5
    77db49304970:	movdqu XMMWORD PTR [r13+0x0],xmm3
    77db49304976:	mov    rcx,QWORD PTR [r12+0x380]
    77db4930497e:	jrcxz  0x77db49304985
    77db49304980:	jmp    0x77db4930bd1d
    77db49304985:	cmp    BYTE PTR [rsp+0x8],0x0
    77db4930498a:	jne    0x77db49302c55
    77db49304990:	jmp    0x77db49304995
    77db49304995:	mov    r13d,DWORD PTR [r12+0x48]
    77db4930499a:	add    r13d,0x1
    77db4930499e:	mov    QWORD PTR [r12+0x48],r13
    77db493049a3:	sub    r13d,0x1f4
    77db493049aa:	mov    rcx,QWORD PTR [r12+0x380]
    77db493049b2:	jrcxz  0x77db493049b9
    77db493049b4:	jmp    0x77db4930bda2
    77db493049b9:	jne    0x77db49302c37
    77db493049bf:	mov    r11,rax
    77db493049c2:	lahf
    77db493049c3:	seto   al
    77db493049c6:	mov    WORD PTR [rsp],ax
    77db493049ca:	mov    rax,r11
    77db493049cd:	jmp    0x77db493049d2
    77db493049d2:	mov    r13d,0x430000
    77db493049d8:	mov    QWORD PTR [r12+0x40],r13
    77db493049dd:	mov    r13d,0x0
    77db493049e3:	mov    QWORD PTR [r12+0x48],r13
    77db493049e8:	mov    r13d,0x430cc0
    77db493049ee:	mov    r14,QWORD PTR [r13+0x0]
    77db493049f2:	mov    r13d,0x0
    77db493049f8:	mov    QWORD PTR [r12+0x110],r14
    77db49304a00:	mov    QWORD PTR [r12+0x118],r13
    77db49304a08:	jmp    0x77db49304a0d
    77db49304a0d:	mov    r13,QWORD PTR [r12+0x48]
    77db49304a12:	mov    r14,QWORD PTR [r12+0x50]
    77db49304a17:	add    r14,r13
    77db49304a1a:	movdqu xmm2,XMMWORD PTR [r14]
    77db49304a1f:	movdqu XMMWORD PTR [r12+0x120],xmm2
    77db49304a29:	add    r13,0x10
    77db49304a2d:	mov    QWORD PTR [r12+0x48],r13
    77db49304a32:	sub    r13,0x200
    77db49304a39:	mov    r13,QWORD PTR [r12+0x128]
    77db49304a41:	mov    r14d,0x0
    77db49304a47:	mov    QWORD PTR [r12+0x130],r13
    77db49304a4f:	mov    QWORD PTR [r12+0x138],r14
    77db49304a57:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    77db49304a61:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    77db49304a6b:	movdqa xmm0,xmm2
    77db49304a6f:	movdqa xmm1,xmm3
    77db49304a73:	movq   xmm0,xmm0
    77db49304a77:	movq   xmm1,xmm1
    77db49304a7b:	addsd  xmm0,xmm1
    77db49304a7f:	movdqa xmm14,xmm0
    77db49304a84:	movdqu xmm15,XMMWORD PTR [rip+0x7bc3]        # 0x77db4930c650
    77db49304a8d:	pand   xmm14,xmm15
    77db49304a92:	movdqu xmm15,XMMWORD PTR [rip+0x7bc5]        # 0x77db4930c660
    77db49304a9b:	pcmpeqq xmm14,xmm15
    77db49304aa1:	movdqa xmm15,xmm0
    77db49304aa6:	cmpunordpd xmm15,xmm0
    77db49304aac:	por    xmm14,xmm15
    77db49304ab1:	pmovmskb ecx,xmm14
    77db49304ab6:	jrcxz  0x77db49304abd
    77db49304ab8:	jmp    0x77db493057bc
    77db49304abd:	movdqa xmm4,xmm0
    77db49304ac1:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    77db49304acb:	movdqa xmm0,xmm4
    77db49304acf:	movdqa xmm1,xmm2
    77db49304ad3:	movq   xmm0,xmm0
    77db49304ad7:	movq   xmm1,xmm1
    77db49304adb:	addsd  xmm0,xmm1
    77db49304adf:	movdqa xmm14,xmm0
    77db49304ae4:	movdqu xmm15,XMMWORD PTR [rip+0x7b63]        # 0x77db4930c650
    77db49304aed:	pand   xmm14,xmm15
    77db49304af2:	movdqu xmm15,XMMWORD PTR [rip+0x7b65]        # 0x77db4930c660
    77db49304afb:	pcmpeqq xmm14,xmm15
    77db49304b01:	movdqa xmm15,xmm0
    77db49304b06:	cmpunordpd xmm15,xmm0
    77db49304b0c:	por    xmm14,xmm15
    77db49304b11:	pmovmskb ecx,xmm14
    77db49304b16:	jrcxz  0x77db49304b1d
    77db49304b18:	jmp    0x77db493057fb
    77db49304b1d:	movdqa xmm3,xmm0
    77db49304b21:	movdqu XMMWORD PTR [r12+0x110],xmm3
    77db49304b2b:	mov    rcx,QWORD PTR [r12+0x380]
    77db49304b33:	jrcxz  0x77db49304b3a
    77db49304b35:	jmp    0x77db4930be36
    77db49304b3a:	jne    0x77db49304b53
    77db49304b40:	mov    r11,rax
    77db49304b43:	lahf
    77db49304b44:	seto   al
    77db49304b47:	mov    WORD PTR [rsp],ax
    77db49304b4b:	mov    rax,r11
    77db49304b4e:	jmp    0x77db49304b66
    77db49304b53:	mov    r11,rax
    77db49304b56:	lahf
    77db49304b57:	seto   al
    77db49304b5a:	mov    WORD PTR [rsp],ax
    77db49304b5e:	mov    rax,r11
    77db49304b61:	jmp    0x77db49304a0d
    77db49304b66:	mov    r13,QWORD PTR [r12+0xf8]
    77db49304b6e:	mov    r14,r13
    77db49304b71:	add    r14,0x1d0
    77db49304b78:	mov    r15,r14
    77db49304b7b:	add    r15,0x8
    77db49304b7f:	mov    rbp,QWORD PTR [r14]
    77db49304b82:	mov    r14,QWORD PTR [r15]
    77db49304b85:	mov    QWORD PTR [r12+0xa0],rbp
    77db49304b8d:	mov    QWORD PTR [r12+0x98],r14
    77db49304b95:	mov    r14,QWORD PTR [r12+0x40]
    77db49304b9a:	add    r14,0xcc0
    77db49304ba1:	mov    r15,QWORD PTR [r12+0x110]
    77db49304ba9:	mov    QWORD PTR [r14],r15
    77db49304bac:	mov    r14d,0x0
    77db49304bb2:	mov    DWORD PTR [r12+0x32c],r14d
    77db49304bba:	mov    r14,r13
    77db49304bbd:	add    r14,0x1c0
    77db49304bc4:	mov    r15,r14
    77db49304bc7:	add    r15,0x8
    77db49304bcb:	mov    rbp,QWORD PTR [r14]
    77db49304bce:	mov    r14,QWORD PTR [r15]
    77db49304bd1:	mov    QWORD PTR [r12+0xe8],rbp
    77db49304bd9:	mov    QWORD PTR [r12+0xf0],r14
    77db49304be1:	mov    r14,r13
    77db49304be4:	add    r14,0x1b0
    77db49304beb:	mov    r15,r14
    77db49304bee:	add    r15,0x8
    77db49304bf2:	mov    rbp,QWORD PTR [r14]
    77db49304bf5:	mov    r14,QWORD PTR [r15]
    77db49304bf8:	mov    r15d,0x0
    77db49304bfe:	mov    QWORD PTR [r12+0x1a0],rbp
    77db49304c06:	mov    QWORD PTR [r12+0x1a8],r15
    77db49304c0e:	mov    r15d,0x0
    77db49304c14:	mov    QWORD PTR [r12+0x190],r14
    77db49304c1c:	mov    QWORD PTR [r12+0x198],r15
    77db49304c24:	mov    r14,r13
    77db49304c27:	add    r14,0x1a0
    77db49304c2e:	mov    r15,r14
    77db49304c31:	add    r15,0x8
    77db49304c35:	mov    rbp,QWORD PTR [r14]
    77db49304c38:	mov    r14,QWORD PTR [r15]
    77db49304c3b:	mov    r15d,0x0
    77db49304c41:	mov    QWORD PTR [r12+0x1c0],rbp
    77db49304c49:	mov    QWORD PTR [r12+0x1c8],r15
    77db49304c51:	mov    r15d,0x0
    77db49304c57:	mov    QWORD PTR [r12+0x1b0],r14
    77db49304c5f:	mov    QWORD PTR [r12+0x1b8],r15
    77db49304c67:	mov    r14,r13
    77db49304c6a:	add    r14,0x190
    77db49304c71:	mov    r15,r14
    77db49304c74:	add    r15,0x8
    77db49304c78:	mov    rbp,QWORD PTR [r14]
    77db49304c7b:	mov    r14,QWORD PTR [r15]
    77db49304c7e:	mov    r15d,0x0
    77db49304c84:	mov    QWORD PTR [r12+0x1e0],rbp
    77db49304c8c:	mov    QWORD PTR [r12+0x1e8],r15
    77db49304c94:	mov    r15d,0x0
    77db49304c9a:	mov    QWORD PTR [r12+0x1d0],r14
    77db49304ca2:	mov    QWORD PTR [r12+0x1d8],r15
    77db49304caa:	mov    r14,r13
    77db49304cad:	add    r14,0x180
    77db49304cb4:	mov    r15,r14
    77db49304cb7:	add    r15,0x8
    77db49304cbb:	mov    rbp,QWORD PTR [r14]
    77db49304cbe:	mov    r14,QWORD PTR [r15]
    77db49304cc1:	mov    r15d,0x0
    77db49304cc7:	mov    QWORD PTR [r12+0x200],rbp
    77db49304ccf:	mov    QWORD PTR [r12+0x208],r15
    77db49304cd7:	mov    r15d,0x0
    77db49304cdd:	mov    QWORD PTR [r12+0x1f0],r14
    77db49304ce5:	mov    QWORD PTR [r12+0x1f8],r15
    77db49304ced:	add    r13,0x1e0
    77db49304cf4:	mov    QWORD PTR [r12+0xf8],r13
    77db49304cfc:	mov    rcx,QWORD PTR [r12+0x380]
    77db49304d04:	jrcxz  0x77db49304d0b
    77db49304d06:	jmp    0x77db4930beca
    77db49304d0b:	mov    r13,QWORD PTR [r12+0xf0]
    77db49304d13:	mov    QWORD PTR [r12+0x100],r13
    77db49304d1b:	mov    r11,QWORD PTR [rsp]
    77db49304d1f:	mov    QWORD PTR [r12+0x398],r11
    77db49304d27:	mov    rdi,QWORD PTR [r12+0x100]
    77db49304d2f:	add    rsp,0x150
    77db49304d36:	movabs r11,0x60ebc8b89940
    77db49304d40:	jmp    r11
    77db49304d43:	mov    r13d,DWORD PTR [r12+0x98]
    77db49304d4b:	mov    r14d,DWORD PTR [r12]
    77db49304d4f:	add    r14d,r13d
    77db49304d52:	mov    QWORD PTR [r12],r14
    77db49304d56:	mov    r13d,0x4103f8
    77db49304d5c:	mov    QWORD PTR [r12+0xf0],r13
    77db49304d64:	mov    r13d,0x4109a4
    77db49304d6a:	mov    QWORD PTR [r12+0x100],r13
    77db49304d72:	mov    r11,QWORD PTR [rsp]
    77db49304d76:	mov    QWORD PTR [r12+0x398],r11
    77db49304d7e:	mov    edi,0x4109a4
    77db49304d83:	mov    QWORD PTR [r12+0x100],rdi
    77db49304d8b:	add    rsp,0x150
    77db49304d92:	nop    WORD PTR [rax+rax*1+0x0]
    77db49304d98:	jmp    QWORD PTR [rip+0x2]        # 0x77db49304da0
    77db49304d9e:	xchg   ax,ax
    77db49304da0:	rex (bad)
    77db49304da2:	xor    BYTE PTR [rcx-0x25],cl
    77db49304da5:	ja     0x77db49304da7
    77db49304da7:	add    BYTE PTR [rax-0x24b6cfb3],dh
    77db49304dad:	ja     0x77db49304daf
    77db49304daf:	add    BYTE PTR [rcx-0x45],cl
    77db49304db2:	rex cdq
    77db49304db4:	mov    eax,0x60ebc8
    77db49304db9:	add    BYTE PTR [rcx-0x1],al
    77db49304dbc:	jrcxz  0x77db49304e24
    77db49304dbe:	movq   mm0,mm2
    77db49304dc1:	movdqa xmm1,xmm3
    77db49304dc5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49304dce:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49304dd7:	call   0x77db49305840
    77db49304ddc:	jmp    0x77db4930274c
    77db49304de1:	movdqa xmm0,xmm2
    77db49304de5:	movdqa xmm1,xmm3
    77db49304de9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49304df2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49304dfb:	call   0x77db49305840
    77db49304e00:	jmp    0x77db493027d8
    77db49304e05:	movdqa xmm0,xmm9
    77db49304e0a:	movdqa xmm1,xmm2
    77db49304e0e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49304e17:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49304e20:	call   0x77db49305910
    77db49304e25:	jmp    0x77db49302e73
    77db49304e2a:	movdqa xmm0,xmm8
    77db49304e2f:	movdqa xmm1,xmm2
    77db49304e33:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49304e3c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49304e45:	call   0x77db49305a20
    77db49304e4a:	jmp    0x77db49302ed2
    77db49304e4f:	movdqa xmm0,xmm9
    77db49304e54:	movdqa xmm1,xmm7
    77db49304e58:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49304e61:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49304e6a:	call   0x77db49305b40
    77db49304e6f:	jmp    0x77db49302f47
    77db49304e74:	movdqa xmm0,xmm9
    77db49304e79:	movdqa xmm1,xmm6
    77db49304e7d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49304e86:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49304e8f:	call   0x77db49305c60
    77db49304e94:	jmp    0x77db49302f97
    77db49304e99:	movdqa xmm0,xmm9
    77db49304e9e:	movdqa xmm1,xmm6
    77db49304ea2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49304eab:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49304eb4:	call   0x77db49305d80
    77db49304eb9:	jmp    0x77db49302ff0
    77db49304ebe:	movdqa xmm0,xmm9
    77db49304ec3:	movdqa xmm1,xmm2
    77db49304ec7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49304ed0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49304ed9:	call   0x77db49305eb0
    77db49304ede:	jmp    0x77db49303091
    77db49304ee3:	mov    r11,rax
    77db49304ee6:	lahf
    77db49304ee7:	seto   al
    77db49304eea:	mov    WORD PTR [rsp],ax
    77db49304eee:	mov    rax,r11
    77db49304ef1:	movdqa xmm0,xmm10
    77db49304ef6:	movdqa xmm1,xmm9
    77db49304efb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49304f04:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49304f0d:	call   0x77db49305ff0
    77db49304f12:	mov    r11,rax
    77db49304f15:	movzx  eax,WORD PTR [rsp]
    77db49304f19:	add    al,0x7f
    77db49304f1b:	sahf
    77db49304f1c:	mov    rax,r11
    77db49304f1f:	jmp    0x77db493030fc
    77db49304f24:	mov    r11,rax
    77db49304f27:	lahf
    77db49304f28:	seto   al
    77db49304f2b:	mov    WORD PTR [rsp],ax
    77db49304f2f:	mov    rax,r11
    77db49304f32:	movdqa xmm0,xmm8
    77db49304f37:	movdqa xmm1,xmm10
    77db49304f3c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49304f45:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49304f4e:	call   0x77db49305ff0
    77db49304f53:	mov    r11,rax
    77db49304f56:	movzx  eax,WORD PTR [rsp]
    77db49304f5a:	add    al,0x7f
    77db49304f5c:	sahf
    77db49304f5d:	mov    rax,r11
    77db49304f60:	jmp    0x77db4930315c
    77db49304f65:	mov    r11,rax
    77db49304f68:	lahf
    77db49304f69:	seto   al
    77db49304f6c:	mov    WORD PTR [rsp],ax
    77db49304f70:	mov    rax,r11
    77db49304f73:	movdqa xmm0,xmm7
    77db49304f77:	movdqa xmm1,xmm10
    77db49304f7c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49304f85:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49304f8e:	call   0x77db493061c0
    77db49304f93:	mov    r11,rax
    77db49304f96:	movzx  eax,WORD PTR [rsp]
    77db49304f9a:	add    al,0x7f
    77db49304f9c:	sahf
    77db49304f9d:	mov    rax,r11
    77db49304fa0:	jmp    0x77db493031b5
    77db49304fa5:	movdqa xmm0,xmm12
    77db49304faa:	movdqa xmm1,xmm9
    77db49304faf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49304fb8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49304fc1:	call   0x77db49306380
    77db49304fc6:	jmp    0x77db4930332d
    77db49304fcb:	movdqa xmm0,xmm6
    77db49304fcf:	movdqa xmm1,xmm4
    77db49304fd3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49304fdc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49304fe5:	call   0x77db49306580
    77db49304fea:	jmp    0x77db4930339b
    77db49304fef:	movdqa xmm0,xmm8
    77db49304ff4:	movdqa xmm1,xmm11
    77db49304ff9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305002:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db4930500b:	call   0x77db49306770
    77db49305010:	jmp    0x77db493033f6
    77db49305015:	movdqa xmm0,xmm5
    77db49305019:	movdqa xmm1,xmm2
    77db4930501d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305026:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db4930502f:	call   0x77db49306960
    77db49305034:	jmp    0x77db49303453
    77db49305039:	movdqa xmm0,xmm9
    77db4930503e:	movdqa xmm1,xmm5
    77db49305042:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930504b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305054:	call   0x77db49306b30
    77db49305059:	jmp    0x77db493034bb
    77db4930505e:	movdqa xmm0,xmm13
    77db49305063:	movdqa xmm1,xmm2
    77db49305067:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305070:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305079:	call   0x77db49306d10
    77db4930507e:	jmp    0x77db49303534
    77db49305083:	movdqa xmm0,xmm9
    77db49305088:	movdqa xmm1,xmm5
    77db4930508c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305095:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db4930509e:	call   0x77db49306f00
    77db493050a3:	jmp    0x77db493035c1
    77db493050a8:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    77db493050b2:	movdqa xmm1,xmm6
    77db493050b6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493050bf:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493050c8:	call   0x77db493070c0
    77db493050cd:	jmp    0x77db493036b6
    77db493050d2:	movdqa xmm0,xmm9
    77db493050d7:	movdqa xmm1,xmm5
    77db493050db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493050e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493050ed:	call   0x77db493072a0
    77db493050f2:	jmp    0x77db49303714
    77db493050f7:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    77db49305101:	movdqa xmm1,xmm11
    77db49305106:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930510f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305118:	call   0x77db49307480
    77db4930511d:	jmp    0x77db4930378d
    77db49305122:	movdqa xmm0,xmm12
    77db49305127:	movdqa xmm1,xmm8
    77db4930512c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305135:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db4930513e:	call   0x77db49307670
    77db49305143:	jmp    0x77db493037e8
    77db49305148:	movdqa xmm0,xmm9
    77db4930514d:	movdqa xmm1,xmm5
    77db49305151:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930515a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305163:	call   0x77db49307860
    77db49305168:	jmp    0x77db49303869
    77db4930516d:	movdqa xmm0,xmm4
    77db49305171:	movdqa xmm1,xmm2
    77db49305175:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930517e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305187:	call   0x77db49307a40
    77db4930518c:	jmp    0x77db493038dc
    77db49305191:	movdqa xmm0,xmm13
    77db49305196:	movdqa xmm1,xmm2
    77db4930519a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493051a3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493051ac:	call   0x77db49307c20
    77db493051b1:	jmp    0x77db49303945
    77db493051b6:	movdqa xmm0,xmm5
    77db493051ba:	movdqa xmm1,xmm2
    77db493051be:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493051c7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493051d0:	call   0x77db49307e00
    77db493051d5:	jmp    0x77db493039bd
    77db493051da:	movdqa xmm0,xmm3
    77db493051de:	movdqa xmm1,xmm6
    77db493051e2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493051eb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493051f4:	call   0x77db49307fe0
    77db493051f9:	jmp    0x77db49303a30
    77db493051fe:	movdqa xmm0,xmm5
    77db49305202:	movdqa xmm1,xmm2
    77db49305206:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930520f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305218:	call   0x77db493081d0
    77db4930521d:	jmp    0x77db49303ad2
    77db49305222:	movdqa xmm0,xmm10
    77db49305227:	movdqa xmm1,xmm12
    77db4930522c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305235:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db4930523e:	call   0x77db493083c0
    77db49305243:	jmp    0x77db49303b43
    77db49305248:	movdqa xmm0,xmm7
    77db4930524c:	movdqa xmm1,xmm2
    77db49305250:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305259:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305262:	call   0x77db493085c0
    77db49305267:	jmp    0x77db49303b96
    77db4930526c:	movdqa xmm0,xmm11
    77db49305271:	movdqa xmm1,xmm13
    77db49305276:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930527f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305288:	call   0x77db493087a0
    77db4930528d:	jmp    0x77db49303be7
    77db49305292:	movdqa xmm0,xmm5
    77db49305296:	movdqa xmm1,xmm7
    77db4930529a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493052a3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493052ac:	call   0x77db49308980
    77db493052b1:	jmp    0x77db49303c44
    77db493052b6:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    77db493052c0:	movdqa xmm1,xmm7
    77db493052c4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493052cd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493052d6:	call   0x77db49308b50
    77db493052db:	jmp    0x77db49303c9e
    77db493052e0:	movdqa xmm0,xmm8
    77db493052e5:	movdqa xmm1,xmm4
    77db493052e9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493052f2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493052fb:	call   0x77db49308d20
    77db49305300:	jmp    0x77db49303ced
    77db49305305:	movdqa xmm0,xmm9
    77db4930530a:	movdqa xmm1,xmm6
    77db4930530e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305317:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305320:	call   0x77db49308f00
    77db49305325:	jmp    0x77db49303d47
    77db4930532a:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    77db49305334:	movdqa xmm1,xmm7
    77db49305338:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305341:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db4930534a:	call   0x77db493090d0
    77db4930534f:	jmp    0x77db49303daa
    77db49305354:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    77db4930535e:	movdqa xmm1,xmm7
    77db49305362:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930536b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305374:	call   0x77db49309290
    77db49305379:	jmp    0x77db49303e03
    77db4930537e:	movdqa xmm0,xmm3
    77db49305382:	movdqa xmm1,xmm10
    77db49305387:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305390:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305399:	call   0x77db49309460
    77db4930539e:	jmp    0x77db49303e5d
    77db493053a3:	movdqa xmm0,xmm2
    77db493053a7:	movdqa xmm1,xmm11
    77db493053ac:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493053b5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493053be:	call   0x77db49309630
    77db493053c3:	jmp    0x77db49303eb6
    77db493053c8:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    77db493053d2:	movdqa xmm1,xmm2
    77db493053d6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493053df:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493053e8:	call   0x77db493097f0
    77db493053ed:	jmp    0x77db49303f23
    77db493053f2:	movdqa xmm0,xmm4
    77db493053f6:	movdqa xmm1,xmm5
    77db493053fa:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305403:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db4930540c:	call   0x77db493099a0
    77db49305411:	jmp    0x77db49303f7c
    77db49305416:	movdqa xmm0,xmm12
    77db4930541b:	movdqa xmm1,xmm6
    77db4930541f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305428:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305431:	call   0x77db49309b70
    77db49305436:	jmp    0x77db49303fd6
    77db4930543b:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    77db49305445:	movdqa xmm1,xmm2
    77db49305449:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305452:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db4930545b:	call   0x77db49308980
    77db49305460:	jmp    0x77db493040b6
    77db49305465:	movdqa xmm0,xmm7
    77db49305469:	movdqa xmm1,xmm8
    77db4930546e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305477:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305480:	call   0x77db49308d20
    77db49305485:	jmp    0x77db49304106
    77db4930548a:	movdqa xmm0,xmm3
    77db4930548e:	movdqa xmm1,xmm9
    77db49305493:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930549c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493054a5:	call   0x77db49309d30
    77db493054aa:	jmp    0x77db49304156
    77db493054af:	movdqa xmm0,xmm6
    77db493054b3:	movdqa xmm1,xmm2
    77db493054b7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493054c0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493054c9:	call   0x77db49309f00
    77db493054ce:	jmp    0x77db493041b3
    77db493054d3:	movdqa xmm0,xmm6
    77db493054d7:	movdqa xmm1,xmm2
    77db493054db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493054e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493054ed:	call   0x77db49309290
    77db493054f2:	jmp    0x77db4930421a
    77db493054f7:	movdqa xmm0,xmm5
    77db493054fb:	movdqa xmm1,xmm2
    77db493054ff:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305508:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305511:	call   0x77db4930a0c0
    77db49305516:	jmp    0x77db49304278
    77db4930551b:	movdqa xmm0,xmm10
    77db49305520:	movdqa xmm1,xmm11
    77db49305525:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930552e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305537:	call   0x77db4930a290
    77db4930553c:	jmp    0x77db493042d2
    77db49305541:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    77db4930554b:	movdqa xmm1,xmm2
    77db4930554f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305558:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305561:	call   0x77db493097f0
    77db49305566:	jmp    0x77db49304335
    77db4930556b:	movdqa xmm0,xmm4
    77db4930556f:	movdqa xmm1,xmm3
    77db49305573:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930557c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305585:	call   0x77db493099a0
    77db4930558a:	jmp    0x77db4930438e
    77db4930558f:	movdqa xmm0,xmm3
    77db49305593:	movdqa xmm1,xmm2
    77db49305597:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493055a0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493055a9:	call   0x77db4930a460
    77db493055ae:	jmp    0x77db493043f6
    77db493055b3:	movdqa xmm0,xmm12
    77db493055b8:	movdqa xmm1,xmm8
    77db493055bd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493055c6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493055cf:	call   0x77db4930a630
    77db493055d4:	jmp    0x77db49304450
    77db493055d9:	movdqa xmm0,xmm8
    77db493055de:	movdqa xmm1,xmm2
    77db493055e2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493055eb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493055f4:	call   0x77db49308980
    77db493055f9:	jmp    0x77db493044b8
    77db493055fe:	movdqa xmm0,xmm7
    77db49305602:	movdqa xmm1,xmm6
    77db49305606:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930560f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305618:	call   0x77db4930a800
    77db4930561d:	jmp    0x77db49304511
    77db49305622:	movdqa xmm0,xmm5
    77db49305626:	movdqa xmm1,xmm9
    77db4930562b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305634:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db4930563d:	call   0x77db4930a9c0
    77db49305642:	jmp    0x77db49304581
    77db49305647:	movdqa xmm0,xmm6
    77db4930564b:	movdqa xmm1,xmm5
    77db4930564f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305658:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305661:	call   0x77db4930ab80
    77db49305666:	jmp    0x77db493045e8
    77db4930566b:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    77db49305675:	movdqa xmm1,xmm5
    77db49305679:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305682:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db4930568b:	call   0x77db4930ad30
    77db49305690:	jmp    0x77db4930464c
    77db49305695:	movdqa xmm0,xmm10
    77db4930569a:	movdqa xmm1,xmm4
    77db4930569e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493056a7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493056b0:	call   0x77db4930aef0
    77db493056b5:	jmp    0x77db493046a5
    77db493056ba:	movdqa xmm0,xmm3
    77db493056be:	movdqa xmm1,xmm11
    77db493056c3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493056cc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493056d5:	call   0x77db49308d20
    77db493056da:	jmp    0x77db4930471b
    77db493056df:	movdqa xmm0,xmm10
    77db493056e4:	movdqa xmm1,xmm5
    77db493056e8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493056f1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493056fa:	call   0x77db4930b0c0
    77db493056ff:	jmp    0x77db4930477a
    77db49305704:	movdqa xmm0,xmm4
    77db49305708:	movdqa xmm1,xmm5
    77db4930570c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305715:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db4930571e:	call   0x77db4930b290
    77db49305723:	jmp    0x77db493047d7
    77db49305728:	movdqa xmm0,xmm2
    77db4930572c:	movdqa xmm1,xmm8
    77db49305731:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930573a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305743:	call   0x77db49309b70
    77db49305748:	jmp    0x77db49304827
    77db4930574d:	movdqa xmm0,xmm7
    77db49305751:	movdqa xmm1,xmm6
    77db49305755:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930575e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305767:	call   0x77db4930b460
    77db4930576c:	jmp    0x77db4930487f
    77db49305771:	movdqa xmm0,xmm9
    77db49305776:	movdqa xmm1,xmm3
    77db4930577a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db49305783:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db4930578c:	call   0x77db4930b610
    77db49305791:	jmp    0x77db493048d8
    77db49305796:	movdqa xmm0,xmm12
    77db4930579b:	movdqa xmm1,xmm10
    77db493057a0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493057a9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493057b2:	call   0x77db4930b7b0
    77db493057b7:	jmp    0x77db49304932
    77db493057bc:	mov    r11,rax
    77db493057bf:	lahf
    77db493057c0:	seto   al
    77db493057c3:	mov    WORD PTR [rsp],ax
    77db493057c7:	mov    rax,r11
    77db493057ca:	movdqa xmm0,xmm2
    77db493057ce:	movdqa xmm1,xmm3
    77db493057d2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db493057db:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db493057e4:	call   0x77db4930b940
    77db493057e9:	mov    r11,rax
    77db493057ec:	movzx  eax,WORD PTR [rsp]
    77db493057f0:	add    al,0x7f
    77db493057f2:	sahf
    77db493057f3:	mov    rax,r11
    77db493057f6:	jmp    0x77db49304abd
    77db493057fb:	mov    r11,rax
    77db493057fe:	lahf
    77db493057ff:	seto   al
    77db49305802:	mov    WORD PTR [rsp],ax
    77db49305806:	mov    rax,r11
    77db49305809:	movdqa xmm0,xmm4
    77db4930580d:	movdqa xmm1,xmm2
    77db49305811:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    77db4930581a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    77db49305823:	call   0x77db4930baa0
    77db49305828:	mov    r11,rax
    77db4930582b:	movzx  eax,WORD PTR [rsp]
    77db4930582f:	add    al,0x7f
    77db49305831:	sahf
    77db49305832:	mov    rax,r11
    77db49305835:	jmp    0x77db49304b1d
    77db4930583a:	nop    WORD PTR [rax+rax*1+0x0]
    77db49305840:	sub    rsp,0x8
    77db49305844:	mov    QWORD PTR [r12+0x378],0x3
    77db49305850:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49305856:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930585c:	mov    QWORD PTR [r12+0x108],rbx
    77db49305864:	stmxcsr DWORD PTR [r12-0x28]
    77db4930586a:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930586f:	test   r10d,0x3f
    77db49305876:	je     0x77db4930589b
    77db4930587c:	mov    r11d,r10d
    77db4930587f:	shr    r10d,1
    77db49305882:	and    r10d,0x1e
    77db49305886:	and    r11d,0x1
    77db4930588a:	or     r10d,r11d
    77db4930588d:	or     DWORD PTR [r12+0x314],r10d
    77db49305895:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930589b:	ldmxcsr DWORD PTR [r12-0x38]
    77db493058a1:	lea    rdi,[rsp+0x110]
    77db493058a9:	lea    rsi,[rsp+0xf0]
    77db493058b1:	lea    rdx,[rsp+0x100]
    77db493058b9:	mov    ecx,0x16
    77db493058be:	mov    r8d,0x0
    77db493058c4:	lea    r9,[r12+0x314]
    77db493058cc:	movabs r11,0x60ebc89f0650
    77db493058d6:	call   r11
    77db493058d9:	ldmxcsr DWORD PTR [r12-0x28]
    77db493058df:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db493058e5:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db493058eb:	mov    rbx,QWORD PTR [r12+0x108]
    77db493058f3:	mov    QWORD PTR [r12+0x378],0x2
    77db493058ff:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49305908:	add    rsp,0x8
    77db4930590c:	ret
    77db4930590d:	nop    DWORD PTR [rax]
    77db49305910:	sub    rsp,0x8
    77db49305914:	mov    QWORD PTR [r12+0x378],0x3
    77db49305920:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49305926:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930592c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49305932:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db4930593c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49305946:	mov    QWORD PTR [r12+0x108],rbx
    77db4930594e:	stmxcsr DWORD PTR [r12-0x28]
    77db49305954:	mov    r10d,DWORD PTR [r12-0x28]
    77db49305959:	test   r10d,0x3f
    77db49305960:	je     0x77db49305985
    77db49305966:	mov    r11d,r10d
    77db49305969:	shr    r10d,1
    77db4930596c:	and    r10d,0x1e
    77db49305970:	and    r11d,0x1
    77db49305974:	or     r10d,r11d
    77db49305977:	or     DWORD PTR [r12+0x314],r10d
    77db4930597f:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49305985:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930598b:	lea    rdi,[rsp+0x110]
    77db49305993:	lea    rsi,[rsp+0xf0]
    77db4930599b:	lea    rdx,[rsp+0x100]
    77db493059a3:	mov    ecx,0x16
    77db493059a8:	mov    r8d,0x0
    77db493059ae:	lea    r9,[r12+0x314]
    77db493059b6:	movabs r11,0x60ebc89f0650
    77db493059c0:	call   r11
    77db493059c3:	ldmxcsr DWORD PTR [r12-0x28]
    77db493059c9:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db493059cf:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db493059d5:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db493059db:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db493059e5:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db493059ef:	mov    rbx,QWORD PTR [r12+0x108]
    77db493059f7:	mov    QWORD PTR [r12+0x378],0x2
    77db49305a03:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49305a0c:	add    rsp,0x8
    77db49305a10:	ret
    77db49305a11:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49305a20:	sub    rsp,0x8
    77db49305a24:	mov    QWORD PTR [r12+0x378],0x3
    77db49305a30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49305a36:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49305a3c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49305a42:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db49305a4c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49305a56:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49305a60:	mov    QWORD PTR [r12+0x108],rbx
    77db49305a68:	stmxcsr DWORD PTR [r12-0x28]
    77db49305a6e:	mov    r10d,DWORD PTR [r12-0x28]
    77db49305a73:	test   r10d,0x3f
    77db49305a7a:	je     0x77db49305a9f
    77db49305a80:	mov    r11d,r10d
    77db49305a83:	shr    r10d,1
    77db49305a86:	and    r10d,0x1e
    77db49305a8a:	and    r11d,0x1
    77db49305a8e:	or     r10d,r11d
    77db49305a91:	or     DWORD PTR [r12+0x314],r10d
    77db49305a99:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49305a9f:	ldmxcsr DWORD PTR [r12-0x38]
    77db49305aa5:	lea    rdi,[rsp+0x110]
    77db49305aad:	lea    rsi,[rsp+0xf0]
    77db49305ab5:	lea    rdx,[rsp+0x100]
    77db49305abd:	mov    ecx,0x56
    77db49305ac2:	mov    r8d,0x0
    77db49305ac8:	lea    r9,[r12+0x314]
    77db49305ad0:	movabs r11,0x60ebc89f0650
    77db49305ada:	call   r11
    77db49305add:	ldmxcsr DWORD PTR [r12-0x28]
    77db49305ae3:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49305ae9:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49305aef:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49305af5:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49305aff:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49305b09:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49305b13:	mov    rbx,QWORD PTR [r12+0x108]
    77db49305b1b:	mov    QWORD PTR [r12+0x378],0x2
    77db49305b27:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49305b30:	add    rsp,0x8
    77db49305b34:	ret
    77db49305b35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49305b40:	sub    rsp,0x8
    77db49305b44:	mov    QWORD PTR [r12+0x378],0x3
    77db49305b50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49305b56:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49305b5c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49305b62:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49305b6c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49305b76:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49305b80:	mov    QWORD PTR [r12+0x108],rbx
    77db49305b88:	stmxcsr DWORD PTR [r12-0x28]
    77db49305b8e:	mov    r10d,DWORD PTR [r12-0x28]
    77db49305b93:	test   r10d,0x3f
    77db49305b9a:	je     0x77db49305bbf
    77db49305ba0:	mov    r11d,r10d
    77db49305ba3:	shr    r10d,1
    77db49305ba6:	and    r10d,0x1e
    77db49305baa:	and    r11d,0x1
    77db49305bae:	or     r10d,r11d
    77db49305bb1:	or     DWORD PTR [r12+0x314],r10d
    77db49305bb9:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49305bbf:	ldmxcsr DWORD PTR [r12-0x38]
    77db49305bc5:	lea    rdi,[rsp+0x110]
    77db49305bcd:	lea    rsi,[rsp+0xf0]
    77db49305bd5:	lea    rdx,[rsp+0x100]
    77db49305bdd:	mov    ecx,0x16
    77db49305be2:	mov    r8d,0x0
    77db49305be8:	lea    r9,[r12+0x314]
    77db49305bf0:	movabs r11,0x60ebc89f0650
    77db49305bfa:	call   r11
    77db49305bfd:	ldmxcsr DWORD PTR [r12-0x28]
    77db49305c03:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49305c09:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49305c0f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49305c15:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49305c1f:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49305c29:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49305c33:	mov    rbx,QWORD PTR [r12+0x108]
    77db49305c3b:	mov    QWORD PTR [r12+0x378],0x2
    77db49305c47:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49305c50:	add    rsp,0x8
    77db49305c54:	ret
    77db49305c55:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49305c60:	sub    rsp,0x8
    77db49305c64:	mov    QWORD PTR [r12+0x378],0x3
    77db49305c70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49305c76:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49305c7c:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db49305c86:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49305c90:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49305c9a:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49305ca4:	mov    QWORD PTR [r12+0x108],rbx
    77db49305cac:	stmxcsr DWORD PTR [r12-0x28]
    77db49305cb2:	mov    r10d,DWORD PTR [r12-0x28]
    77db49305cb7:	test   r10d,0x3f
    77db49305cbe:	je     0x77db49305ce3
    77db49305cc4:	mov    r11d,r10d
    77db49305cc7:	shr    r10d,1
    77db49305cca:	and    r10d,0x1e
    77db49305cce:	and    r11d,0x1
    77db49305cd2:	or     r10d,r11d
    77db49305cd5:	or     DWORD PTR [r12+0x314],r10d
    77db49305cdd:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49305ce3:	ldmxcsr DWORD PTR [r12-0x38]
    77db49305ce9:	lea    rdi,[rsp+0x110]
    77db49305cf1:	lea    rsi,[rsp+0xf0]
    77db49305cf9:	lea    rdx,[rsp+0x100]
    77db49305d01:	mov    ecx,0x16
    77db49305d06:	mov    r8d,0x0
    77db49305d0c:	lea    r9,[r12+0x314]
    77db49305d14:	movabs r11,0x60ebc89f0650
    77db49305d1e:	call   r11
    77db49305d21:	ldmxcsr DWORD PTR [r12-0x28]
    77db49305d27:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49305d2d:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49305d33:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49305d3d:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49305d47:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49305d51:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49305d5b:	mov    rbx,QWORD PTR [r12+0x108]
    77db49305d63:	mov    QWORD PTR [r12+0x378],0x2
    77db49305d6f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49305d78:	add    rsp,0x8
    77db49305d7c:	ret
    77db49305d7d:	nop    DWORD PTR [rax]
    77db49305d80:	sub    rsp,0x8
    77db49305d84:	mov    QWORD PTR [r12+0x378],0x3
    77db49305d90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49305d96:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49305d9c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49305da2:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db49305dac:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49305db6:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49305dc0:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49305dca:	mov    QWORD PTR [r12+0x108],rbx
    77db49305dd2:	stmxcsr DWORD PTR [r12-0x28]
    77db49305dd8:	mov    r10d,DWORD PTR [r12-0x28]
    77db49305ddd:	test   r10d,0x3f
    77db49305de4:	je     0x77db49305e09
    77db49305dea:	mov    r11d,r10d
    77db49305ded:	shr    r10d,1
    77db49305df0:	and    r10d,0x1e
    77db49305df4:	and    r11d,0x1
    77db49305df8:	or     r10d,r11d
    77db49305dfb:	or     DWORD PTR [r12+0x314],r10d
    77db49305e03:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49305e09:	ldmxcsr DWORD PTR [r12-0x38]
    77db49305e0f:	lea    rdi,[rsp+0x110]
    77db49305e17:	lea    rsi,[rsp+0xf0]
    77db49305e1f:	lea    rdx,[rsp+0x100]
    77db49305e27:	mov    ecx,0x16
    77db49305e2c:	mov    r8d,0x0
    77db49305e32:	lea    r9,[r12+0x314]
    77db49305e3a:	movabs r11,0x60ebc89f0650
    77db49305e44:	call   r11
    77db49305e47:	ldmxcsr DWORD PTR [r12-0x28]
    77db49305e4d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49305e53:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49305e59:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49305e5f:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49305e69:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49305e73:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49305e7d:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49305e87:	mov    rbx,QWORD PTR [r12+0x108]
    77db49305e8f:	mov    QWORD PTR [r12+0x378],0x2
    77db49305e9b:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49305ea4:	add    rsp,0x8
    77db49305ea8:	ret
    77db49305ea9:	nop    DWORD PTR [rax+0x0]
    77db49305eb0:	sub    rsp,0x8
    77db49305eb4:	mov    QWORD PTR [r12+0x378],0x3
    77db49305ec0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49305ec6:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49305ecc:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db49305ed6:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49305ee0:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49305eea:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49305ef4:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49305efe:	mov    QWORD PTR [r12+0x108],rbx
    77db49305f06:	stmxcsr DWORD PTR [r12-0x28]
    77db49305f0c:	mov    r10d,DWORD PTR [r12-0x28]
    77db49305f11:	test   r10d,0x3f
    77db49305f18:	je     0x77db49305f3d
    77db49305f1e:	mov    r11d,r10d
    77db49305f21:	shr    r10d,1
    77db49305f24:	and    r10d,0x1e
    77db49305f28:	and    r11d,0x1
    77db49305f2c:	or     r10d,r11d
    77db49305f2f:	or     DWORD PTR [r12+0x314],r10d
    77db49305f37:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49305f3d:	ldmxcsr DWORD PTR [r12-0x38]
    77db49305f43:	lea    rdi,[rsp+0x110]
    77db49305f4b:	lea    rsi,[rsp+0xf0]
    77db49305f53:	lea    rdx,[rsp+0x100]
    77db49305f5b:	mov    ecx,0x56
    77db49305f60:	mov    r8d,0x0
    77db49305f66:	lea    r9,[r12+0x314]
    77db49305f6e:	movabs r11,0x60ebc89f0650
    77db49305f78:	call   r11
    77db49305f7b:	ldmxcsr DWORD PTR [r12-0x28]
    77db49305f81:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49305f87:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49305f8d:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49305f97:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49305fa1:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49305fab:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49305fb5:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49305fbf:	mov    rbx,QWORD PTR [r12+0x108]
    77db49305fc7:	mov    QWORD PTR [r12+0x378],0x2
    77db49305fd3:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49305fdc:	add    rsp,0x8
    77db49305fe0:	ret
    77db49305fe1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49305ff0:	sub    rsp,0x8
    77db49305ff4:	mov    QWORD PTR [r12+0x378],0x3
    77db49306000:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49306006:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930600c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49306012:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db4930601c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49306026:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49306030:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db4930603a:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49306044:	push   rdx
    77db49306045:	push   rsi
    77db49306046:	push   r10
    77db49306048:	push   r11
    77db4930604a:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930604f:	mov    r10d,edx
    77db49306052:	and    r10d,0xc000
    77db49306059:	shl    r10d,0x10
    77db4930605d:	mov    r11d,edx
    77db49306060:	and    r11d,0x100
    77db49306067:	shl    r11d,0x15
    77db4930606b:	or     r10d,r11d
    77db4930606e:	and    edx,0x1
    77db49306071:	shl    edx,0x1c
    77db49306074:	or     r10d,edx
    77db49306077:	btc    r10,0x1d
    77db4930607c:	mov    r11d,0xf0000000
    77db49306082:	and    r11,r10
    77db49306085:	movabs rsi,0xffffffff0fffffff
    77db4930608f:	and    rbx,rsi
    77db49306092:	or     rbx,r11
    77db49306095:	pop    r11
    77db49306097:	pop    r10
    77db49306099:	pop    rsi
    77db4930609a:	pop    rdx
    77db4930609b:	mov    QWORD PTR [r12+0x108],rbx
    77db493060a3:	stmxcsr DWORD PTR [r12-0x28]
    77db493060a9:	mov    r10d,DWORD PTR [r12-0x28]
    77db493060ae:	test   r10d,0x3f
    77db493060b5:	je     0x77db493060da
    77db493060bb:	mov    r11d,r10d
    77db493060be:	shr    r10d,1
    77db493060c1:	and    r10d,0x1e
    77db493060c5:	and    r11d,0x1
    77db493060c9:	or     r10d,r11d
    77db493060cc:	or     DWORD PTR [r12+0x314],r10d
    77db493060d4:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db493060da:	ldmxcsr DWORD PTR [r12-0x38]
    77db493060e0:	lea    rdi,[rsp+0x110]
    77db493060e8:	lea    rsi,[rsp+0xf0]
    77db493060f0:	lea    rdx,[rsp+0x100]
    77db493060f8:	mov    ecx,0x14
    77db493060fd:	mov    r8d,0x0
    77db49306103:	lea    r9,[r12+0x314]
    77db4930610b:	movabs r11,0x60ebc89f0650
    77db49306115:	call   r11
    77db49306118:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930611e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49306124:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930612a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49306130:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db4930613a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49306144:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930614e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49306158:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49306162:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930616a:	mov    QWORD PTR [r12+0x378],0x2
    77db49306176:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930617f:	mov    rdx,rbx
    77db49306182:	shr    rdx,0x10
    77db49306186:	and    edx,0xc000
    77db4930618c:	mov    rax,rbx
    77db4930618f:	shr    rax,0x15
    77db49306193:	and    eax,0x100
    77db49306198:	xor    eax,0x100
    77db4930619d:	or     edx,eax
    77db4930619f:	mov    rax,rbx
    77db493061a2:	shr    rax,0x1c
    77db493061a6:	and    eax,0x1
    77db493061a9:	or     edx,eax
    77db493061ab:	mov    QWORD PTR [rsp+0x10],rdx
    77db493061b0:	add    rsp,0x8
    77db493061b4:	ret
    77db493061b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db493061c0:	sub    rsp,0x8
    77db493061c4:	mov    QWORD PTR [r12+0x378],0x3
    77db493061d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db493061d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493061dc:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db493061e2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493061e8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db493061f2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db493061fc:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49306206:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49306210:	push   rdx
    77db49306211:	push   rsi
    77db49306212:	push   r10
    77db49306214:	push   r11
    77db49306216:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930621b:	mov    r10d,edx
    77db4930621e:	and    r10d,0xc000
    77db49306225:	shl    r10d,0x10
    77db49306229:	mov    r11d,edx
    77db4930622c:	and    r11d,0x100
    77db49306233:	shl    r11d,0x15
    77db49306237:	or     r10d,r11d
    77db4930623a:	and    edx,0x1
    77db4930623d:	shl    edx,0x1c
    77db49306240:	or     r10d,edx
    77db49306243:	btc    r10,0x1d
    77db49306248:	mov    r11d,0xf0000000
    77db4930624e:	and    r11,r10
    77db49306251:	movabs rsi,0xffffffff0fffffff
    77db4930625b:	and    rbx,rsi
    77db4930625e:	or     rbx,r11
    77db49306261:	pop    r11
    77db49306263:	pop    r10
    77db49306265:	pop    rsi
    77db49306266:	pop    rdx
    77db49306267:	mov    QWORD PTR [r12+0x108],rbx
    77db4930626f:	stmxcsr DWORD PTR [r12-0x28]
    77db49306275:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930627a:	test   r10d,0x3f
    77db49306281:	je     0x77db493062a6
    77db49306287:	mov    r11d,r10d
    77db4930628a:	shr    r10d,1
    77db4930628d:	and    r10d,0x1e
    77db49306291:	and    r11d,0x1
    77db49306295:	or     r10d,r11d
    77db49306298:	or     DWORD PTR [r12+0x314],r10d
    77db493062a0:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db493062a6:	ldmxcsr DWORD PTR [r12-0x38]
    77db493062ac:	lea    rdi,[rsp+0x110]
    77db493062b4:	lea    rsi,[rsp+0xf0]
    77db493062bc:	lea    rdx,[rsp+0x100]
    77db493062c4:	mov    ecx,0x14
    77db493062c9:	mov    r8d,0x0
    77db493062cf:	lea    r9,[r12+0x314]
    77db493062d7:	movabs r11,0x60ebc89f0650
    77db493062e1:	call   r11
    77db493062e4:	ldmxcsr DWORD PTR [r12-0x28]
    77db493062ea:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db493062f0:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db493062f6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db493062fc:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49306302:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930630c:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49306316:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49306320:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930632a:	mov    rbx,QWORD PTR [r12+0x108]
    77db49306332:	mov    QWORD PTR [r12+0x378],0x2
    77db4930633e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49306347:	mov    rdx,rbx
    77db4930634a:	shr    rdx,0x10
    77db4930634e:	and    edx,0xc000
    77db49306354:	mov    rax,rbx
    77db49306357:	shr    rax,0x15
    77db4930635b:	and    eax,0x100
    77db49306360:	xor    eax,0x100
    77db49306365:	or     edx,eax
    77db49306367:	mov    rax,rbx
    77db4930636a:	shr    rax,0x1c
    77db4930636e:	and    eax,0x1
    77db49306371:	or     edx,eax
    77db49306373:	mov    QWORD PTR [rsp+0x10],rdx
    77db49306378:	add    rsp,0x8
    77db4930637c:	ret
    77db4930637d:	nop    DWORD PTR [rax]
    77db49306380:	sub    rsp,0x8
    77db49306384:	mov    QWORD PTR [r12+0x378],0x3
    77db49306390:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49306396:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930639c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493063a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db493063a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db493063ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493063b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db493063be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db493063c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db493063d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db493063dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db493063e6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db493063f0:	push   rdx
    77db493063f1:	push   rsi
    77db493063f2:	push   r10
    77db493063f4:	push   r11
    77db493063f6:	mov    rdx,QWORD PTR [rsp+0x30]
    77db493063fb:	mov    r10d,edx
    77db493063fe:	and    r10d,0xc000
    77db49306405:	shl    r10d,0x10
    77db49306409:	mov    r11d,edx
    77db4930640c:	and    r11d,0x100
    77db49306413:	shl    r11d,0x15
    77db49306417:	or     r10d,r11d
    77db4930641a:	and    edx,0x1
    77db4930641d:	shl    edx,0x1c
    77db49306420:	or     r10d,edx
    77db49306423:	btc    r10,0x1d
    77db49306428:	mov    r11d,0xf0000000
    77db4930642e:	and    r11,r10
    77db49306431:	movabs rsi,0xffffffff0fffffff
    77db4930643b:	and    rbx,rsi
    77db4930643e:	or     rbx,r11
    77db49306441:	pop    r11
    77db49306443:	pop    r10
    77db49306445:	pop    rsi
    77db49306446:	pop    rdx
    77db49306447:	mov    QWORD PTR [r12+0x108],rbx
    77db4930644f:	stmxcsr DWORD PTR [r12-0x28]
    77db49306455:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930645a:	test   r10d,0x3f
    77db49306461:	je     0x77db49306486
    77db49306467:	mov    r11d,r10d
    77db4930646a:	shr    r10d,1
    77db4930646d:	and    r10d,0x1e
    77db49306471:	and    r11d,0x1
    77db49306475:	or     r10d,r11d
    77db49306478:	or     DWORD PTR [r12+0x314],r10d
    77db49306480:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49306486:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930648c:	lea    rdi,[rsp+0x110]
    77db49306494:	lea    rsi,[rsp+0xf0]
    77db4930649c:	lea    rdx,[rsp+0x100]
    77db493064a4:	mov    ecx,0x14
    77db493064a9:	mov    r8d,0x0
    77db493064af:	lea    r9,[r12+0x314]
    77db493064b7:	movabs r11,0x60ebc89f0650
    77db493064c1:	call   r11
    77db493064c4:	ldmxcsr DWORD PTR [r12-0x28]
    77db493064ca:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db493064d0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db493064d6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db493064dc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db493064e2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db493064e8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db493064ee:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db493064f8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49306502:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930650c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49306516:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49306520:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db4930652a:	mov    rbx,QWORD PTR [r12+0x108]
    77db49306532:	mov    QWORD PTR [r12+0x378],0x2
    77db4930653e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49306547:	mov    rdx,rbx
    77db4930654a:	shr    rdx,0x10
    77db4930654e:	and    edx,0xc000
    77db49306554:	mov    rax,rbx
    77db49306557:	shr    rax,0x15
    77db4930655b:	and    eax,0x100
    77db49306560:	xor    eax,0x100
    77db49306565:	or     edx,eax
    77db49306567:	mov    rax,rbx
    77db4930656a:	shr    rax,0x1c
    77db4930656e:	and    eax,0x1
    77db49306571:	or     edx,eax
    77db49306573:	mov    QWORD PTR [rsp+0x10],rdx
    77db49306578:	add    rsp,0x8
    77db4930657c:	ret
    77db4930657d:	nop    DWORD PTR [rax]
    77db49306580:	sub    rsp,0x8
    77db49306584:	mov    QWORD PTR [r12+0x378],0x3
    77db49306590:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49306596:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930659c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493065a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db493065a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db493065ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493065b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db493065be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db493065c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db493065d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db493065dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db493065e6:	push   rdx
    77db493065e7:	push   rsi
    77db493065e8:	push   r10
    77db493065ea:	push   r11
    77db493065ec:	mov    rdx,QWORD PTR [rsp+0x30]
    77db493065f1:	mov    r10d,edx
    77db493065f4:	and    r10d,0xc000
    77db493065fb:	shl    r10d,0x10
    77db493065ff:	mov    r11d,edx
    77db49306602:	and    r11d,0x100
    77db49306609:	shl    r11d,0x15
    77db4930660d:	or     r10d,r11d
    77db49306610:	and    edx,0x1
    77db49306613:	shl    edx,0x1c
    77db49306616:	or     r10d,edx
    77db49306619:	btc    r10,0x1d
    77db4930661e:	mov    r11d,0xf0000000
    77db49306624:	and    r11,r10
    77db49306627:	movabs rsi,0xffffffff0fffffff
    77db49306631:	and    rbx,rsi
    77db49306634:	or     rbx,r11
    77db49306637:	pop    r11
    77db49306639:	pop    r10
    77db4930663b:	pop    rsi
    77db4930663c:	pop    rdx
    77db4930663d:	mov    QWORD PTR [r12+0x108],rbx
    77db49306645:	stmxcsr DWORD PTR [r12-0x28]
    77db4930664b:	mov    r10d,DWORD PTR [r12-0x28]
    77db49306650:	test   r10d,0x3f
    77db49306657:	je     0x77db4930667c
    77db4930665d:	mov    r11d,r10d
    77db49306660:	shr    r10d,1
    77db49306663:	and    r10d,0x1e
    77db49306667:	and    r11d,0x1
    77db4930666b:	or     r10d,r11d
    77db4930666e:	or     DWORD PTR [r12+0x314],r10d
    77db49306676:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930667c:	ldmxcsr DWORD PTR [r12-0x38]
    77db49306682:	lea    rdi,[rsp+0x110]
    77db4930668a:	lea    rsi,[rsp+0xf0]
    77db49306692:	lea    rdx,[rsp+0x100]
    77db4930669a:	mov    ecx,0x14
    77db4930669f:	mov    r8d,0x0
    77db493066a5:	lea    r9,[r12+0x314]
    77db493066ad:	movabs r11,0x60ebc89f0650
    77db493066b7:	call   r11
    77db493066ba:	ldmxcsr DWORD PTR [r12-0x28]
    77db493066c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db493066c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db493066cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db493066d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db493066d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db493066de:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db493066e4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db493066ee:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db493066f8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49306702:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db4930670c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db49306716:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930671e:	mov    QWORD PTR [r12+0x378],0x2
    77db4930672a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49306733:	mov    rdx,rbx
    77db49306736:	shr    rdx,0x10
    77db4930673a:	and    edx,0xc000
    77db49306740:	mov    rax,rbx
    77db49306743:	shr    rax,0x15
    77db49306747:	and    eax,0x100
    77db4930674c:	xor    eax,0x100
    77db49306751:	or     edx,eax
    77db49306753:	mov    rax,rbx
    77db49306756:	shr    rax,0x1c
    77db4930675a:	and    eax,0x1
    77db4930675d:	or     edx,eax
    77db4930675f:	mov    QWORD PTR [rsp+0x10],rdx
    77db49306764:	add    rsp,0x8
    77db49306768:	ret
    77db49306769:	nop    DWORD PTR [rax+0x0]
    77db49306770:	sub    rsp,0x8
    77db49306774:	mov    QWORD PTR [r12+0x378],0x3
    77db49306780:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49306786:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930678c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49306792:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49306798:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db493067a2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db493067ac:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db493067b6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db493067c0:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db493067ca:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db493067d4:	push   rdx
    77db493067d5:	push   rsi
    77db493067d6:	push   r10
    77db493067d8:	push   r11
    77db493067da:	mov    rdx,QWORD PTR [rsp+0x30]
    77db493067df:	mov    r10d,edx
    77db493067e2:	and    r10d,0xc000
    77db493067e9:	shl    r10d,0x10
    77db493067ed:	mov    r11d,edx
    77db493067f0:	and    r11d,0x100
    77db493067f7:	shl    r11d,0x15
    77db493067fb:	or     r10d,r11d
    77db493067fe:	and    edx,0x1
    77db49306801:	shl    edx,0x1c
    77db49306804:	or     r10d,edx
    77db49306807:	btc    r10,0x1d
    77db4930680c:	mov    r11d,0xf0000000
    77db49306812:	and    r11,r10
    77db49306815:	movabs rsi,0xffffffff0fffffff
    77db4930681f:	and    rbx,rsi
    77db49306822:	or     rbx,r11
    77db49306825:	pop    r11
    77db49306827:	pop    r10
    77db49306829:	pop    rsi
    77db4930682a:	pop    rdx
    77db4930682b:	mov    QWORD PTR [r12+0x108],rbx
    77db49306833:	stmxcsr DWORD PTR [r12-0x28]
    77db49306839:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930683e:	test   r10d,0x3f
    77db49306845:	je     0x77db4930686a
    77db4930684b:	mov    r11d,r10d
    77db4930684e:	shr    r10d,1
    77db49306851:	and    r10d,0x1e
    77db49306855:	and    r11d,0x1
    77db49306859:	or     r10d,r11d
    77db4930685c:	or     DWORD PTR [r12+0x314],r10d
    77db49306864:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930686a:	ldmxcsr DWORD PTR [r12-0x38]
    77db49306870:	lea    rdi,[rsp+0x110]
    77db49306878:	lea    rsi,[rsp+0xf0]
    77db49306880:	lea    rdx,[rsp+0x100]
    77db49306888:	mov    ecx,0x14
    77db4930688d:	mov    r8d,0x0
    77db49306893:	lea    r9,[r12+0x314]
    77db4930689b:	movabs r11,0x60ebc89f0650
    77db493068a5:	call   r11
    77db493068a8:	ldmxcsr DWORD PTR [r12-0x28]
    77db493068ae:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db493068b4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db493068ba:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db493068c0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db493068c6:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db493068d0:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db493068da:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db493068e4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db493068ee:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db493068f8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db49306902:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930690a:	mov    QWORD PTR [r12+0x378],0x2
    77db49306916:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930691f:	mov    rdx,rbx
    77db49306922:	shr    rdx,0x10
    77db49306926:	and    edx,0xc000
    77db4930692c:	mov    rax,rbx
    77db4930692f:	shr    rax,0x15
    77db49306933:	and    eax,0x100
    77db49306938:	xor    eax,0x100
    77db4930693d:	or     edx,eax
    77db4930693f:	mov    rax,rbx
    77db49306942:	shr    rax,0x1c
    77db49306946:	and    eax,0x1
    77db49306949:	or     edx,eax
    77db4930694b:	mov    QWORD PTR [rsp+0x10],rdx
    77db49306950:	add    rsp,0x8
    77db49306954:	ret
    77db49306955:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49306960:	sub    rsp,0x8
    77db49306964:	mov    QWORD PTR [r12+0x378],0x3
    77db49306970:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49306976:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930697c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49306982:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49306988:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db4930698e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49306998:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db493069a2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db493069ac:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db493069b6:	push   rdx
    77db493069b7:	push   rsi
    77db493069b8:	push   r10
    77db493069ba:	push   r11
    77db493069bc:	mov    rdx,QWORD PTR [rsp+0x30]
    77db493069c1:	mov    r10d,edx
    77db493069c4:	and    r10d,0xc000
    77db493069cb:	shl    r10d,0x10
    77db493069cf:	mov    r11d,edx
    77db493069d2:	and    r11d,0x100
    77db493069d9:	shl    r11d,0x15
    77db493069dd:	or     r10d,r11d
    77db493069e0:	and    edx,0x1
    77db493069e3:	shl    edx,0x1c
    77db493069e6:	or     r10d,edx
    77db493069e9:	btc    r10,0x1d
    77db493069ee:	mov    r11d,0xf0000000
    77db493069f4:	and    r11,r10
    77db493069f7:	movabs rsi,0xffffffff0fffffff
    77db49306a01:	and    rbx,rsi
    77db49306a04:	or     rbx,r11
    77db49306a07:	pop    r11
    77db49306a09:	pop    r10
    77db49306a0b:	pop    rsi
    77db49306a0c:	pop    rdx
    77db49306a0d:	mov    QWORD PTR [r12+0x108],rbx
    77db49306a15:	stmxcsr DWORD PTR [r12-0x28]
    77db49306a1b:	mov    r10d,DWORD PTR [r12-0x28]
    77db49306a20:	test   r10d,0x3f
    77db49306a27:	je     0x77db49306a4c
    77db49306a2d:	mov    r11d,r10d
    77db49306a30:	shr    r10d,1
    77db49306a33:	and    r10d,0x1e
    77db49306a37:	and    r11d,0x1
    77db49306a3b:	or     r10d,r11d
    77db49306a3e:	or     DWORD PTR [r12+0x314],r10d
    77db49306a46:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49306a4c:	ldmxcsr DWORD PTR [r12-0x38]
    77db49306a52:	lea    rdi,[rsp+0x110]
    77db49306a5a:	lea    rsi,[rsp+0xf0]
    77db49306a62:	lea    rdx,[rsp+0x100]
    77db49306a6a:	mov    ecx,0x56
    77db49306a6f:	mov    r8d,0x0
    77db49306a75:	lea    r9,[r12+0x314]
    77db49306a7d:	movabs r11,0x60ebc89f0650
    77db49306a87:	call   r11
    77db49306a8a:	ldmxcsr DWORD PTR [r12-0x28]
    77db49306a90:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49306a96:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49306a9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49306aa2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49306aa8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49306aae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49306ab8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49306ac2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49306acc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db49306ad6:	mov    rbx,QWORD PTR [r12+0x108]
    77db49306ade:	mov    QWORD PTR [r12+0x378],0x2
    77db49306aea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49306af3:	mov    rdx,rbx
    77db49306af6:	shr    rdx,0x10
    77db49306afa:	and    edx,0xc000
    77db49306b00:	mov    rax,rbx
    77db49306b03:	shr    rax,0x15
    77db49306b07:	and    eax,0x100
    77db49306b0c:	xor    eax,0x100
    77db49306b11:	or     edx,eax
    77db49306b13:	mov    rax,rbx
    77db49306b16:	shr    rax,0x1c
    77db49306b1a:	and    eax,0x1
    77db49306b1d:	or     edx,eax
    77db49306b1f:	mov    QWORD PTR [rsp+0x10],rdx
    77db49306b24:	add    rsp,0x8
    77db49306b28:	ret
    77db49306b29:	nop    DWORD PTR [rax+0x0]
    77db49306b30:	sub    rsp,0x8
    77db49306b34:	mov    QWORD PTR [r12+0x378],0x3
    77db49306b40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49306b46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db49306b4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49306b52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49306b58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49306b5e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49306b64:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49306b6e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49306b78:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49306b82:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db49306b8c:	push   rdx
    77db49306b8d:	push   rsi
    77db49306b8e:	push   r10
    77db49306b90:	push   r11
    77db49306b92:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49306b97:	mov    r10d,edx
    77db49306b9a:	and    r10d,0xc000
    77db49306ba1:	shl    r10d,0x10
    77db49306ba5:	mov    r11d,edx
    77db49306ba8:	and    r11d,0x100
    77db49306baf:	shl    r11d,0x15
    77db49306bb3:	or     r10d,r11d
    77db49306bb6:	and    edx,0x1
    77db49306bb9:	shl    edx,0x1c
    77db49306bbc:	or     r10d,edx
    77db49306bbf:	btc    r10,0x1d
    77db49306bc4:	mov    r11d,0xf0000000
    77db49306bca:	and    r11,r10
    77db49306bcd:	movabs rsi,0xffffffff0fffffff
    77db49306bd7:	and    rbx,rsi
    77db49306bda:	or     rbx,r11
    77db49306bdd:	pop    r11
    77db49306bdf:	pop    r10
    77db49306be1:	pop    rsi
    77db49306be2:	pop    rdx
    77db49306be3:	mov    QWORD PTR [r12+0x108],rbx
    77db49306beb:	stmxcsr DWORD PTR [r12-0x28]
    77db49306bf1:	mov    r10d,DWORD PTR [r12-0x28]
    77db49306bf6:	test   r10d,0x3f
    77db49306bfd:	je     0x77db49306c22
    77db49306c03:	mov    r11d,r10d
    77db49306c06:	shr    r10d,1
    77db49306c09:	and    r10d,0x1e
    77db49306c0d:	and    r11d,0x1
    77db49306c11:	or     r10d,r11d
    77db49306c14:	or     DWORD PTR [r12+0x314],r10d
    77db49306c1c:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49306c22:	ldmxcsr DWORD PTR [r12-0x38]
    77db49306c28:	lea    rdi,[rsp+0x110]
    77db49306c30:	lea    rsi,[rsp+0xf0]
    77db49306c38:	lea    rdx,[rsp+0x100]
    77db49306c40:	mov    ecx,0x56
    77db49306c45:	mov    r8d,0x0
    77db49306c4b:	lea    r9,[r12+0x314]
    77db49306c53:	movabs r11,0x60ebc89f0650
    77db49306c5d:	call   r11
    77db49306c60:	ldmxcsr DWORD PTR [r12-0x28]
    77db49306c66:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49306c6c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49306c72:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49306c78:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49306c7e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49306c84:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49306c8a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49306c94:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49306c9e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49306ca8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db49306cb2:	mov    rbx,QWORD PTR [r12+0x108]
    77db49306cba:	mov    QWORD PTR [r12+0x378],0x2
    77db49306cc6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49306ccf:	mov    rdx,rbx
    77db49306cd2:	shr    rdx,0x10
    77db49306cd6:	and    edx,0xc000
    77db49306cdc:	mov    rax,rbx
    77db49306cdf:	shr    rax,0x15
    77db49306ce3:	and    eax,0x100
    77db49306ce8:	xor    eax,0x100
    77db49306ced:	or     edx,eax
    77db49306cef:	mov    rax,rbx
    77db49306cf2:	shr    rax,0x1c
    77db49306cf6:	and    eax,0x1
    77db49306cf9:	or     edx,eax
    77db49306cfb:	mov    QWORD PTR [rsp+0x10],rdx
    77db49306d00:	add    rsp,0x8
    77db49306d04:	ret
    77db49306d05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49306d10:	sub    rsp,0x8
    77db49306d14:	mov    QWORD PTR [r12+0x378],0x3
    77db49306d20:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49306d26:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db49306d2c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49306d32:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49306d38:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49306d3e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49306d44:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db49306d4e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49306d58:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49306d62:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49306d6c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db49306d76:	push   rdx
    77db49306d77:	push   rsi
    77db49306d78:	push   r10
    77db49306d7a:	push   r11
    77db49306d7c:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49306d81:	mov    r10d,edx
    77db49306d84:	and    r10d,0xc000
    77db49306d8b:	shl    r10d,0x10
    77db49306d8f:	mov    r11d,edx
    77db49306d92:	and    r11d,0x100
    77db49306d99:	shl    r11d,0x15
    77db49306d9d:	or     r10d,r11d
    77db49306da0:	and    edx,0x1
    77db49306da3:	shl    edx,0x1c
    77db49306da6:	or     r10d,edx
    77db49306da9:	btc    r10,0x1d
    77db49306dae:	mov    r11d,0xf0000000
    77db49306db4:	and    r11,r10
    77db49306db7:	movabs rsi,0xffffffff0fffffff
    77db49306dc1:	and    rbx,rsi
    77db49306dc4:	or     rbx,r11
    77db49306dc7:	pop    r11
    77db49306dc9:	pop    r10
    77db49306dcb:	pop    rsi
    77db49306dcc:	pop    rdx
    77db49306dcd:	mov    QWORD PTR [r12+0x108],rbx
    77db49306dd5:	stmxcsr DWORD PTR [r12-0x28]
    77db49306ddb:	mov    r10d,DWORD PTR [r12-0x28]
    77db49306de0:	test   r10d,0x3f
    77db49306de7:	je     0x77db49306e0c
    77db49306ded:	mov    r11d,r10d
    77db49306df0:	shr    r10d,1
    77db49306df3:	and    r10d,0x1e
    77db49306df7:	and    r11d,0x1
    77db49306dfb:	or     r10d,r11d
    77db49306dfe:	or     DWORD PTR [r12+0x314],r10d
    77db49306e06:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49306e0c:	ldmxcsr DWORD PTR [r12-0x38]
    77db49306e12:	lea    rdi,[rsp+0x110]
    77db49306e1a:	lea    rsi,[rsp+0xf0]
    77db49306e22:	lea    rdx,[rsp+0x100]
    77db49306e2a:	mov    ecx,0x56
    77db49306e2f:	mov    r8d,0x0
    77db49306e35:	lea    r9,[r12+0x314]
    77db49306e3d:	movabs r11,0x60ebc89f0650
    77db49306e47:	call   r11
    77db49306e4a:	ldmxcsr DWORD PTR [r12-0x28]
    77db49306e50:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49306e56:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49306e5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49306e62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49306e68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49306e6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49306e74:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49306e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49306e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49306e92:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49306e9c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db49306ea6:	mov    rbx,QWORD PTR [r12+0x108]
    77db49306eae:	mov    QWORD PTR [r12+0x378],0x2
    77db49306eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49306ec3:	mov    rdx,rbx
    77db49306ec6:	shr    rdx,0x10
    77db49306eca:	and    edx,0xc000
    77db49306ed0:	mov    rax,rbx
    77db49306ed3:	shr    rax,0x15
    77db49306ed7:	and    eax,0x100
    77db49306edc:	xor    eax,0x100
    77db49306ee1:	or     edx,eax
    77db49306ee3:	mov    rax,rbx
    77db49306ee6:	shr    rax,0x1c
    77db49306eea:	and    eax,0x1
    77db49306eed:	or     edx,eax
    77db49306eef:	mov    QWORD PTR [rsp+0x10],rdx
    77db49306ef4:	add    rsp,0x8
    77db49306ef8:	ret
    77db49306ef9:	nop    DWORD PTR [rax+0x0]
    77db49306f00:	sub    rsp,0x8
    77db49306f04:	mov    QWORD PTR [r12+0x378],0x3
    77db49306f10:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49306f16:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49306f1c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49306f22:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49306f28:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db49306f32:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49306f3c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49306f46:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49306f50:	push   rdx
    77db49306f51:	push   rsi
    77db49306f52:	push   r10
    77db49306f54:	push   r11
    77db49306f56:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49306f5b:	mov    r10d,edx
    77db49306f5e:	and    r10d,0xc000
    77db49306f65:	shl    r10d,0x10
    77db49306f69:	mov    r11d,edx
    77db49306f6c:	and    r11d,0x100
    77db49306f73:	shl    r11d,0x15
    77db49306f77:	or     r10d,r11d
    77db49306f7a:	and    edx,0x1
    77db49306f7d:	shl    edx,0x1c
    77db49306f80:	or     r10d,edx
    77db49306f83:	btc    r10,0x1d
    77db49306f88:	mov    r11d,0xf0000000
    77db49306f8e:	and    r11,r10
    77db49306f91:	movabs rsi,0xffffffff0fffffff
    77db49306f9b:	and    rbx,rsi
    77db49306f9e:	or     rbx,r11
    77db49306fa1:	pop    r11
    77db49306fa3:	pop    r10
    77db49306fa5:	pop    rsi
    77db49306fa6:	pop    rdx
    77db49306fa7:	mov    QWORD PTR [r12+0x108],rbx
    77db49306faf:	stmxcsr DWORD PTR [r12-0x28]
    77db49306fb5:	mov    r10d,DWORD PTR [r12-0x28]
    77db49306fba:	test   r10d,0x3f
    77db49306fc1:	je     0x77db49306fe6
    77db49306fc7:	mov    r11d,r10d
    77db49306fca:	shr    r10d,1
    77db49306fcd:	and    r10d,0x1e
    77db49306fd1:	and    r11d,0x1
    77db49306fd5:	or     r10d,r11d
    77db49306fd8:	or     DWORD PTR [r12+0x314],r10d
    77db49306fe0:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49306fe6:	ldmxcsr DWORD PTR [r12-0x38]
    77db49306fec:	lea    rdi,[rsp+0x110]
    77db49306ff4:	lea    rsi,[rsp+0xf0]
    77db49306ffc:	lea    rdx,[rsp+0x100]
    77db49307004:	mov    ecx,0x56
    77db49307009:	mov    r8d,0x0
    77db4930700f:	lea    r9,[r12+0x314]
    77db49307017:	movabs r11,0x60ebc89f0650
    77db49307021:	call   r11
    77db49307024:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930702a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49307030:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49307036:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930703c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49307042:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db4930704c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49307056:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49307060:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930706a:	mov    rbx,QWORD PTR [r12+0x108]
    77db49307072:	mov    QWORD PTR [r12+0x378],0x2
    77db4930707e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49307087:	mov    rdx,rbx
    77db4930708a:	shr    rdx,0x10
    77db4930708e:	and    edx,0xc000
    77db49307094:	mov    rax,rbx
    77db49307097:	shr    rax,0x15
    77db4930709b:	and    eax,0x100
    77db493070a0:	xor    eax,0x100
    77db493070a5:	or     edx,eax
    77db493070a7:	mov    rax,rbx
    77db493070aa:	shr    rax,0x1c
    77db493070ae:	and    eax,0x1
    77db493070b1:	or     edx,eax
    77db493070b3:	mov    QWORD PTR [rsp+0x10],rdx
    77db493070b8:	add    rsp,0x8
    77db493070bc:	ret
    77db493070bd:	nop    DWORD PTR [rax]
    77db493070c0:	sub    rsp,0x8
    77db493070c4:	mov    QWORD PTR [r12+0x378],0x3
    77db493070d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db493070d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493070dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db493070e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db493070e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493070ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db493070f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49307102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db4930710c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49307116:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db49307120:	push   rdx
    77db49307121:	push   rsi
    77db49307122:	push   r10
    77db49307124:	push   r11
    77db49307126:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930712b:	mov    r10d,edx
    77db4930712e:	and    r10d,0xc000
    77db49307135:	shl    r10d,0x10
    77db49307139:	mov    r11d,edx
    77db4930713c:	and    r11d,0x100
    77db49307143:	shl    r11d,0x15
    77db49307147:	or     r10d,r11d
    77db4930714a:	and    edx,0x1
    77db4930714d:	shl    edx,0x1c
    77db49307150:	or     r10d,edx
    77db49307153:	btc    r10,0x1d
    77db49307158:	mov    r11d,0xf0000000
    77db4930715e:	and    r11,r10
    77db49307161:	movabs rsi,0xffffffff0fffffff
    77db4930716b:	and    rbx,rsi
    77db4930716e:	or     rbx,r11
    77db49307171:	pop    r11
    77db49307173:	pop    r10
    77db49307175:	pop    rsi
    77db49307176:	pop    rdx
    77db49307177:	mov    QWORD PTR [r12+0x108],rbx
    77db4930717f:	stmxcsr DWORD PTR [r12-0x28]
    77db49307185:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930718a:	test   r10d,0x3f
    77db49307191:	je     0x77db493071b6
    77db49307197:	mov    r11d,r10d
    77db4930719a:	shr    r10d,1
    77db4930719d:	and    r10d,0x1e
    77db493071a1:	and    r11d,0x1
    77db493071a5:	or     r10d,r11d
    77db493071a8:	or     DWORD PTR [r12+0x314],r10d
    77db493071b0:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db493071b6:	ldmxcsr DWORD PTR [r12-0x38]
    77db493071bc:	lea    rdi,[rsp+0x110]
    77db493071c4:	lea    rsi,[rsp+0xf0]
    77db493071cc:	lea    rdx,[rsp+0x100]
    77db493071d4:	mov    ecx,0x14
    77db493071d9:	mov    r8d,0x0
    77db493071df:	lea    r9,[r12+0x314]
    77db493071e7:	movabs r11,0x60ebc89f0650
    77db493071f1:	call   r11
    77db493071f4:	ldmxcsr DWORD PTR [r12-0x28]
    77db493071fa:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49307200:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49307206:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930720c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49307212:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49307218:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49307222:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930722c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49307236:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49307240:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db4930724a:	mov    rbx,QWORD PTR [r12+0x108]
    77db49307252:	mov    QWORD PTR [r12+0x378],0x2
    77db4930725e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49307267:	mov    rdx,rbx
    77db4930726a:	shr    rdx,0x10
    77db4930726e:	and    edx,0xc000
    77db49307274:	mov    rax,rbx
    77db49307277:	shr    rax,0x15
    77db4930727b:	and    eax,0x100
    77db49307280:	xor    eax,0x100
    77db49307285:	or     edx,eax
    77db49307287:	mov    rax,rbx
    77db4930728a:	shr    rax,0x1c
    77db4930728e:	and    eax,0x1
    77db49307291:	or     edx,eax
    77db49307293:	mov    QWORD PTR [rsp+0x10],rdx
    77db49307298:	add    rsp,0x8
    77db4930729c:	ret
    77db4930729d:	nop    DWORD PTR [rax]
    77db493072a0:	sub    rsp,0x8
    77db493072a4:	mov    QWORD PTR [r12+0x378],0x3
    77db493072b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db493072b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db493072bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493072c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db493072c8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493072ce:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db493072d8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db493072e2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db493072ec:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db493072f6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db49307300:	push   rdx
    77db49307301:	push   rsi
    77db49307302:	push   r10
    77db49307304:	push   r11
    77db49307306:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930730b:	mov    r10d,edx
    77db4930730e:	and    r10d,0xc000
    77db49307315:	shl    r10d,0x10
    77db49307319:	mov    r11d,edx
    77db4930731c:	and    r11d,0x100
    77db49307323:	shl    r11d,0x15
    77db49307327:	or     r10d,r11d
    77db4930732a:	and    edx,0x1
    77db4930732d:	shl    edx,0x1c
    77db49307330:	or     r10d,edx
    77db49307333:	btc    r10,0x1d
    77db49307338:	mov    r11d,0xf0000000
    77db4930733e:	and    r11,r10
    77db49307341:	movabs rsi,0xffffffff0fffffff
    77db4930734b:	and    rbx,rsi
    77db4930734e:	or     rbx,r11
    77db49307351:	pop    r11
    77db49307353:	pop    r10
    77db49307355:	pop    rsi
    77db49307356:	pop    rdx
    77db49307357:	mov    QWORD PTR [r12+0x108],rbx
    77db4930735f:	stmxcsr DWORD PTR [r12-0x28]
    77db49307365:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930736a:	test   r10d,0x3f
    77db49307371:	je     0x77db49307396
    77db49307377:	mov    r11d,r10d
    77db4930737a:	shr    r10d,1
    77db4930737d:	and    r10d,0x1e
    77db49307381:	and    r11d,0x1
    77db49307385:	or     r10d,r11d
    77db49307388:	or     DWORD PTR [r12+0x314],r10d
    77db49307390:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49307396:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930739c:	lea    rdi,[rsp+0x110]
    77db493073a4:	lea    rsi,[rsp+0xf0]
    77db493073ac:	lea    rdx,[rsp+0x100]
    77db493073b4:	mov    ecx,0x56
    77db493073b9:	mov    r8d,0x0
    77db493073bf:	lea    r9,[r12+0x314]
    77db493073c7:	movabs r11,0x60ebc89f0650
    77db493073d1:	call   r11
    77db493073d4:	ldmxcsr DWORD PTR [r12-0x28]
    77db493073da:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db493073e0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db493073e6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db493073ec:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db493073f2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db493073f8:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49307402:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930740c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49307416:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49307420:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db4930742a:	mov    rbx,QWORD PTR [r12+0x108]
    77db49307432:	mov    QWORD PTR [r12+0x378],0x2
    77db4930743e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49307447:	mov    rdx,rbx
    77db4930744a:	shr    rdx,0x10
    77db4930744e:	and    edx,0xc000
    77db49307454:	mov    rax,rbx
    77db49307457:	shr    rax,0x15
    77db4930745b:	and    eax,0x100
    77db49307460:	xor    eax,0x100
    77db49307465:	or     edx,eax
    77db49307467:	mov    rax,rbx
    77db4930746a:	shr    rax,0x1c
    77db4930746e:	and    eax,0x1
    77db49307471:	or     edx,eax
    77db49307473:	mov    QWORD PTR [rsp+0x10],rdx
    77db49307478:	add    rsp,0x8
    77db4930747c:	ret
    77db4930747d:	nop    DWORD PTR [rax]
    77db49307480:	sub    rsp,0x8
    77db49307484:	mov    QWORD PTR [r12+0x378],0x3
    77db49307490:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49307496:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930749c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493074a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db493074a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db493074ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493074b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db493074be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db493074c8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db493074d2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db493074dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db493074e6:	push   rdx
    77db493074e7:	push   rsi
    77db493074e8:	push   r10
    77db493074ea:	push   r11
    77db493074ec:	mov    rdx,QWORD PTR [rsp+0x30]
    77db493074f1:	mov    r10d,edx
    77db493074f4:	and    r10d,0xc000
    77db493074fb:	shl    r10d,0x10
    77db493074ff:	mov    r11d,edx
    77db49307502:	and    r11d,0x100
    77db49307509:	shl    r11d,0x15
    77db4930750d:	or     r10d,r11d
    77db49307510:	and    edx,0x1
    77db49307513:	shl    edx,0x1c
    77db49307516:	or     r10d,edx
    77db49307519:	btc    r10,0x1d
    77db4930751e:	mov    r11d,0xf0000000
    77db49307524:	and    r11,r10
    77db49307527:	movabs rsi,0xffffffff0fffffff
    77db49307531:	and    rbx,rsi
    77db49307534:	or     rbx,r11
    77db49307537:	pop    r11
    77db49307539:	pop    r10
    77db4930753b:	pop    rsi
    77db4930753c:	pop    rdx
    77db4930753d:	mov    QWORD PTR [r12+0x108],rbx
    77db49307545:	stmxcsr DWORD PTR [r12-0x28]
    77db4930754b:	mov    r10d,DWORD PTR [r12-0x28]
    77db49307550:	test   r10d,0x3f
    77db49307557:	je     0x77db4930757c
    77db4930755d:	mov    r11d,r10d
    77db49307560:	shr    r10d,1
    77db49307563:	and    r10d,0x1e
    77db49307567:	and    r11d,0x1
    77db4930756b:	or     r10d,r11d
    77db4930756e:	or     DWORD PTR [r12+0x314],r10d
    77db49307576:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930757c:	ldmxcsr DWORD PTR [r12-0x38]
    77db49307582:	lea    rdi,[rsp+0x110]
    77db4930758a:	lea    rsi,[rsp+0xf0]
    77db49307592:	lea    rdx,[rsp+0x100]
    77db4930759a:	mov    ecx,0x14
    77db4930759f:	mov    r8d,0x0
    77db493075a5:	lea    r9,[r12+0x314]
    77db493075ad:	movabs r11,0x60ebc89f0650
    77db493075b7:	call   r11
    77db493075ba:	ldmxcsr DWORD PTR [r12-0x28]
    77db493075c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db493075c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db493075cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db493075d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db493075d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db493075de:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db493075e4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db493075ee:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db493075f8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49307602:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930760c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db49307616:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930761e:	mov    QWORD PTR [r12+0x378],0x2
    77db4930762a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49307633:	mov    rdx,rbx
    77db49307636:	shr    rdx,0x10
    77db4930763a:	and    edx,0xc000
    77db49307640:	mov    rax,rbx
    77db49307643:	shr    rax,0x15
    77db49307647:	and    eax,0x100
    77db4930764c:	xor    eax,0x100
    77db49307651:	or     edx,eax
    77db49307653:	mov    rax,rbx
    77db49307656:	shr    rax,0x1c
    77db4930765a:	and    eax,0x1
    77db4930765d:	or     edx,eax
    77db4930765f:	mov    QWORD PTR [rsp+0x10],rdx
    77db49307664:	add    rsp,0x8
    77db49307668:	ret
    77db49307669:	nop    DWORD PTR [rax+0x0]
    77db49307670:	sub    rsp,0x8
    77db49307674:	mov    QWORD PTR [r12+0x378],0x3
    77db49307680:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49307686:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930768c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49307692:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49307698:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930769e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493076a4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db493076ae:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db493076b8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db493076c2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db493076cc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db493076d6:	push   rdx
    77db493076d7:	push   rsi
    77db493076d8:	push   r10
    77db493076da:	push   r11
    77db493076dc:	mov    rdx,QWORD PTR [rsp+0x30]
    77db493076e1:	mov    r10d,edx
    77db493076e4:	and    r10d,0xc000
    77db493076eb:	shl    r10d,0x10
    77db493076ef:	mov    r11d,edx
    77db493076f2:	and    r11d,0x100
    77db493076f9:	shl    r11d,0x15
    77db493076fd:	or     r10d,r11d
    77db49307700:	and    edx,0x1
    77db49307703:	shl    edx,0x1c
    77db49307706:	or     r10d,edx
    77db49307709:	btc    r10,0x1d
    77db4930770e:	mov    r11d,0xf0000000
    77db49307714:	and    r11,r10
    77db49307717:	movabs rsi,0xffffffff0fffffff
    77db49307721:	and    rbx,rsi
    77db49307724:	or     rbx,r11
    77db49307727:	pop    r11
    77db49307729:	pop    r10
    77db4930772b:	pop    rsi
    77db4930772c:	pop    rdx
    77db4930772d:	mov    QWORD PTR [r12+0x108],rbx
    77db49307735:	stmxcsr DWORD PTR [r12-0x28]
    77db4930773b:	mov    r10d,DWORD PTR [r12-0x28]
    77db49307740:	test   r10d,0x3f
    77db49307747:	je     0x77db4930776c
    77db4930774d:	mov    r11d,r10d
    77db49307750:	shr    r10d,1
    77db49307753:	and    r10d,0x1e
    77db49307757:	and    r11d,0x1
    77db4930775b:	or     r10d,r11d
    77db4930775e:	or     DWORD PTR [r12+0x314],r10d
    77db49307766:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930776c:	ldmxcsr DWORD PTR [r12-0x38]
    77db49307772:	lea    rdi,[rsp+0x110]
    77db4930777a:	lea    rsi,[rsp+0xf0]
    77db49307782:	lea    rdx,[rsp+0x100]
    77db4930778a:	mov    ecx,0x14
    77db4930778f:	mov    r8d,0x0
    77db49307795:	lea    r9,[r12+0x314]
    77db4930779d:	movabs r11,0x60ebc89f0650
    77db493077a7:	call   r11
    77db493077aa:	ldmxcsr DWORD PTR [r12-0x28]
    77db493077b0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db493077b6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db493077bc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db493077c2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db493077c8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db493077ce:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db493077d4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db493077de:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db493077e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db493077f2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db493077fc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db49307806:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930780e:	mov    QWORD PTR [r12+0x378],0x2
    77db4930781a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49307823:	mov    rdx,rbx
    77db49307826:	shr    rdx,0x10
    77db4930782a:	and    edx,0xc000
    77db49307830:	mov    rax,rbx
    77db49307833:	shr    rax,0x15
    77db49307837:	and    eax,0x100
    77db4930783c:	xor    eax,0x100
    77db49307841:	or     edx,eax
    77db49307843:	mov    rax,rbx
    77db49307846:	shr    rax,0x1c
    77db4930784a:	and    eax,0x1
    77db4930784d:	or     edx,eax
    77db4930784f:	mov    QWORD PTR [rsp+0x10],rdx
    77db49307854:	add    rsp,0x8
    77db49307858:	ret
    77db49307859:	nop    DWORD PTR [rax+0x0]
    77db49307860:	sub    rsp,0x8
    77db49307864:	mov    QWORD PTR [r12+0x378],0x3
    77db49307870:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49307876:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930787c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49307882:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49307888:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930788e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49307894:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db4930789e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db493078a8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db493078b2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db493078bc:	push   rdx
    77db493078bd:	push   rsi
    77db493078be:	push   r10
    77db493078c0:	push   r11
    77db493078c2:	mov    rdx,QWORD PTR [rsp+0x30]
    77db493078c7:	mov    r10d,edx
    77db493078ca:	and    r10d,0xc000
    77db493078d1:	shl    r10d,0x10
    77db493078d5:	mov    r11d,edx
    77db493078d8:	and    r11d,0x100
    77db493078df:	shl    r11d,0x15
    77db493078e3:	or     r10d,r11d
    77db493078e6:	and    edx,0x1
    77db493078e9:	shl    edx,0x1c
    77db493078ec:	or     r10d,edx
    77db493078ef:	btc    r10,0x1d
    77db493078f4:	mov    r11d,0xf0000000
    77db493078fa:	and    r11,r10
    77db493078fd:	movabs rsi,0xffffffff0fffffff
    77db49307907:	and    rbx,rsi
    77db4930790a:	or     rbx,r11
    77db4930790d:	pop    r11
    77db4930790f:	pop    r10
    77db49307911:	pop    rsi
    77db49307912:	pop    rdx
    77db49307913:	mov    QWORD PTR [r12+0x108],rbx
    77db4930791b:	stmxcsr DWORD PTR [r12-0x28]
    77db49307921:	mov    r10d,DWORD PTR [r12-0x28]
    77db49307926:	test   r10d,0x3f
    77db4930792d:	je     0x77db49307952
    77db49307933:	mov    r11d,r10d
    77db49307936:	shr    r10d,1
    77db49307939:	and    r10d,0x1e
    77db4930793d:	and    r11d,0x1
    77db49307941:	or     r10d,r11d
    77db49307944:	or     DWORD PTR [r12+0x314],r10d
    77db4930794c:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49307952:	ldmxcsr DWORD PTR [r12-0x38]
    77db49307958:	lea    rdi,[rsp+0x110]
    77db49307960:	lea    rsi,[rsp+0xf0]
    77db49307968:	lea    rdx,[rsp+0x100]
    77db49307970:	mov    ecx,0x56
    77db49307975:	mov    r8d,0x0
    77db4930797b:	lea    r9,[r12+0x314]
    77db49307983:	movabs r11,0x60ebc89f0650
    77db4930798d:	call   r11
    77db49307990:	ldmxcsr DWORD PTR [r12-0x28]
    77db49307996:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930799c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db493079a2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db493079a8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db493079ae:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db493079b4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db493079ba:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db493079c4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db493079ce:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db493079d8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db493079e2:	mov    rbx,QWORD PTR [r12+0x108]
    77db493079ea:	mov    QWORD PTR [r12+0x378],0x2
    77db493079f6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db493079ff:	mov    rdx,rbx
    77db49307a02:	shr    rdx,0x10
    77db49307a06:	and    edx,0xc000
    77db49307a0c:	mov    rax,rbx
    77db49307a0f:	shr    rax,0x15
    77db49307a13:	and    eax,0x100
    77db49307a18:	xor    eax,0x100
    77db49307a1d:	or     edx,eax
    77db49307a1f:	mov    rax,rbx
    77db49307a22:	shr    rax,0x1c
    77db49307a26:	and    eax,0x1
    77db49307a29:	or     edx,eax
    77db49307a2b:	mov    QWORD PTR [rsp+0x10],rdx
    77db49307a30:	add    rsp,0x8
    77db49307a34:	ret
    77db49307a35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49307a40:	sub    rsp,0x8
    77db49307a44:	mov    QWORD PTR [r12+0x378],0x3
    77db49307a50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49307a56:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db49307a5c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49307a62:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49307a68:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49307a6e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49307a74:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49307a7e:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49307a88:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49307a92:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db49307a9c:	push   rdx
    77db49307a9d:	push   rsi
    77db49307a9e:	push   r10
    77db49307aa0:	push   r11
    77db49307aa2:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49307aa7:	mov    r10d,edx
    77db49307aaa:	and    r10d,0xc000
    77db49307ab1:	shl    r10d,0x10
    77db49307ab5:	mov    r11d,edx
    77db49307ab8:	and    r11d,0x100
    77db49307abf:	shl    r11d,0x15
    77db49307ac3:	or     r10d,r11d
    77db49307ac6:	and    edx,0x1
    77db49307ac9:	shl    edx,0x1c
    77db49307acc:	or     r10d,edx
    77db49307acf:	btc    r10,0x1d
    77db49307ad4:	mov    r11d,0xf0000000
    77db49307ada:	and    r11,r10
    77db49307add:	movabs rsi,0xffffffff0fffffff
    77db49307ae7:	and    rbx,rsi
    77db49307aea:	or     rbx,r11
    77db49307aed:	pop    r11
    77db49307aef:	pop    r10
    77db49307af1:	pop    rsi
    77db49307af2:	pop    rdx
    77db49307af3:	mov    QWORD PTR [r12+0x108],rbx
    77db49307afb:	stmxcsr DWORD PTR [r12-0x28]
    77db49307b01:	mov    r10d,DWORD PTR [r12-0x28]
    77db49307b06:	test   r10d,0x3f
    77db49307b0d:	je     0x77db49307b32
    77db49307b13:	mov    r11d,r10d
    77db49307b16:	shr    r10d,1
    77db49307b19:	and    r10d,0x1e
    77db49307b1d:	and    r11d,0x1
    77db49307b21:	or     r10d,r11d
    77db49307b24:	or     DWORD PTR [r12+0x314],r10d
    77db49307b2c:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49307b32:	ldmxcsr DWORD PTR [r12-0x38]
    77db49307b38:	lea    rdi,[rsp+0x110]
    77db49307b40:	lea    rsi,[rsp+0xf0]
    77db49307b48:	lea    rdx,[rsp+0x100]
    77db49307b50:	mov    ecx,0x14
    77db49307b55:	mov    r8d,0x0
    77db49307b5b:	lea    r9,[r12+0x314]
    77db49307b63:	movabs r11,0x60ebc89f0650
    77db49307b6d:	call   r11
    77db49307b70:	ldmxcsr DWORD PTR [r12-0x28]
    77db49307b76:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49307b7c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49307b82:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49307b88:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49307b8e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49307b94:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49307b9a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49307ba4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49307bae:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49307bb8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db49307bc2:	mov    rbx,QWORD PTR [r12+0x108]
    77db49307bca:	mov    QWORD PTR [r12+0x378],0x2
    77db49307bd6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49307bdf:	mov    rdx,rbx
    77db49307be2:	shr    rdx,0x10
    77db49307be6:	and    edx,0xc000
    77db49307bec:	mov    rax,rbx
    77db49307bef:	shr    rax,0x15
    77db49307bf3:	and    eax,0x100
    77db49307bf8:	xor    eax,0x100
    77db49307bfd:	or     edx,eax
    77db49307bff:	mov    rax,rbx
    77db49307c02:	shr    rax,0x1c
    77db49307c06:	and    eax,0x1
    77db49307c09:	or     edx,eax
    77db49307c0b:	mov    QWORD PTR [rsp+0x10],rdx
    77db49307c10:	add    rsp,0x8
    77db49307c14:	ret
    77db49307c15:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49307c20:	sub    rsp,0x8
    77db49307c24:	mov    QWORD PTR [r12+0x378],0x3
    77db49307c30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49307c36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db49307c3c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49307c42:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49307c48:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49307c4e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49307c58:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49307c62:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49307c6c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49307c76:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db49307c80:	push   rdx
    77db49307c81:	push   rsi
    77db49307c82:	push   r10
    77db49307c84:	push   r11
    77db49307c86:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49307c8b:	mov    r10d,edx
    77db49307c8e:	and    r10d,0xc000
    77db49307c95:	shl    r10d,0x10
    77db49307c99:	mov    r11d,edx
    77db49307c9c:	and    r11d,0x100
    77db49307ca3:	shl    r11d,0x15
    77db49307ca7:	or     r10d,r11d
    77db49307caa:	and    edx,0x1
    77db49307cad:	shl    edx,0x1c
    77db49307cb0:	or     r10d,edx
    77db49307cb3:	btc    r10,0x1d
    77db49307cb8:	mov    r11d,0xf0000000
    77db49307cbe:	and    r11,r10
    77db49307cc1:	movabs rsi,0xffffffff0fffffff
    77db49307ccb:	and    rbx,rsi
    77db49307cce:	or     rbx,r11
    77db49307cd1:	pop    r11
    77db49307cd3:	pop    r10
    77db49307cd5:	pop    rsi
    77db49307cd6:	pop    rdx
    77db49307cd7:	mov    QWORD PTR [r12+0x108],rbx
    77db49307cdf:	stmxcsr DWORD PTR [r12-0x28]
    77db49307ce5:	mov    r10d,DWORD PTR [r12-0x28]
    77db49307cea:	test   r10d,0x3f
    77db49307cf1:	je     0x77db49307d16
    77db49307cf7:	mov    r11d,r10d
    77db49307cfa:	shr    r10d,1
    77db49307cfd:	and    r10d,0x1e
    77db49307d01:	and    r11d,0x1
    77db49307d05:	or     r10d,r11d
    77db49307d08:	or     DWORD PTR [r12+0x314],r10d
    77db49307d10:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49307d16:	ldmxcsr DWORD PTR [r12-0x38]
    77db49307d1c:	lea    rdi,[rsp+0x110]
    77db49307d24:	lea    rsi,[rsp+0xf0]
    77db49307d2c:	lea    rdx,[rsp+0x100]
    77db49307d34:	mov    ecx,0x56
    77db49307d39:	mov    r8d,0x0
    77db49307d3f:	lea    r9,[r12+0x314]
    77db49307d47:	movabs r11,0x60ebc89f0650
    77db49307d51:	call   r11
    77db49307d54:	ldmxcsr DWORD PTR [r12-0x28]
    77db49307d5a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49307d60:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49307d66:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49307d6c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49307d72:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49307d78:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49307d82:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49307d8c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49307d96:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49307da0:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db49307daa:	mov    rbx,QWORD PTR [r12+0x108]
    77db49307db2:	mov    QWORD PTR [r12+0x378],0x2
    77db49307dbe:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49307dc7:	mov    rdx,rbx
    77db49307dca:	shr    rdx,0x10
    77db49307dce:	and    edx,0xc000
    77db49307dd4:	mov    rax,rbx
    77db49307dd7:	shr    rax,0x15
    77db49307ddb:	and    eax,0x100
    77db49307de0:	xor    eax,0x100
    77db49307de5:	or     edx,eax
    77db49307de7:	mov    rax,rbx
    77db49307dea:	shr    rax,0x1c
    77db49307dee:	and    eax,0x1
    77db49307df1:	or     edx,eax
    77db49307df3:	mov    QWORD PTR [rsp+0x10],rdx
    77db49307df8:	add    rsp,0x8
    77db49307dfc:	ret
    77db49307dfd:	nop    DWORD PTR [rax]
    77db49307e00:	sub    rsp,0x8
    77db49307e04:	mov    QWORD PTR [r12+0x378],0x3
    77db49307e10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49307e16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db49307e1c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49307e22:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49307e28:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49307e2e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49307e34:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49307e3e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49307e48:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49307e52:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49307e5c:	push   rdx
    77db49307e5d:	push   rsi
    77db49307e5e:	push   r10
    77db49307e60:	push   r11
    77db49307e62:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49307e67:	mov    r10d,edx
    77db49307e6a:	and    r10d,0xc000
    77db49307e71:	shl    r10d,0x10
    77db49307e75:	mov    r11d,edx
    77db49307e78:	and    r11d,0x100
    77db49307e7f:	shl    r11d,0x15
    77db49307e83:	or     r10d,r11d
    77db49307e86:	and    edx,0x1
    77db49307e89:	shl    edx,0x1c
    77db49307e8c:	or     r10d,edx
    77db49307e8f:	btc    r10,0x1d
    77db49307e94:	mov    r11d,0xf0000000
    77db49307e9a:	and    r11,r10
    77db49307e9d:	movabs rsi,0xffffffff0fffffff
    77db49307ea7:	and    rbx,rsi
    77db49307eaa:	or     rbx,r11
    77db49307ead:	pop    r11
    77db49307eaf:	pop    r10
    77db49307eb1:	pop    rsi
    77db49307eb2:	pop    rdx
    77db49307eb3:	mov    QWORD PTR [r12+0x108],rbx
    77db49307ebb:	stmxcsr DWORD PTR [r12-0x28]
    77db49307ec1:	mov    r10d,DWORD PTR [r12-0x28]
    77db49307ec6:	test   r10d,0x3f
    77db49307ecd:	je     0x77db49307ef2
    77db49307ed3:	mov    r11d,r10d
    77db49307ed6:	shr    r10d,1
    77db49307ed9:	and    r10d,0x1e
    77db49307edd:	and    r11d,0x1
    77db49307ee1:	or     r10d,r11d
    77db49307ee4:	or     DWORD PTR [r12+0x314],r10d
    77db49307eec:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49307ef2:	ldmxcsr DWORD PTR [r12-0x38]
    77db49307ef8:	lea    rdi,[rsp+0x110]
    77db49307f00:	lea    rsi,[rsp+0xf0]
    77db49307f08:	lea    rdx,[rsp+0x100]
    77db49307f10:	mov    ecx,0x56
    77db49307f15:	mov    r8d,0x0
    77db49307f1b:	lea    r9,[r12+0x314]
    77db49307f23:	movabs r11,0x60ebc89f0650
    77db49307f2d:	call   r11
    77db49307f30:	ldmxcsr DWORD PTR [r12-0x28]
    77db49307f36:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49307f3c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49307f42:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49307f48:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49307f4e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49307f54:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49307f5a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49307f64:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49307f6e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49307f78:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49307f82:	mov    rbx,QWORD PTR [r12+0x108]
    77db49307f8a:	mov    QWORD PTR [r12+0x378],0x2
    77db49307f96:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49307f9f:	mov    rdx,rbx
    77db49307fa2:	shr    rdx,0x10
    77db49307fa6:	and    edx,0xc000
    77db49307fac:	mov    rax,rbx
    77db49307faf:	shr    rax,0x15
    77db49307fb3:	and    eax,0x100
    77db49307fb8:	xor    eax,0x100
    77db49307fbd:	or     edx,eax
    77db49307fbf:	mov    rax,rbx
    77db49307fc2:	shr    rax,0x1c
    77db49307fc6:	and    eax,0x1
    77db49307fc9:	or     edx,eax
    77db49307fcb:	mov    QWORD PTR [rsp+0x10],rdx
    77db49307fd0:	add    rsp,0x8
    77db49307fd4:	ret
    77db49307fd5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49307fe0:	sub    rsp,0x8
    77db49307fe4:	mov    QWORD PTR [r12+0x378],0x3
    77db49307ff0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49307ff6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db49307ffc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49308002:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49308008:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930800e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49308014:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db4930801e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49308028:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49308032:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db4930803c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db49308046:	push   rdx
    77db49308047:	push   rsi
    77db49308048:	push   r10
    77db4930804a:	push   r11
    77db4930804c:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49308051:	mov    r10d,edx
    77db49308054:	and    r10d,0xc000
    77db4930805b:	shl    r10d,0x10
    77db4930805f:	mov    r11d,edx
    77db49308062:	and    r11d,0x100
    77db49308069:	shl    r11d,0x15
    77db4930806d:	or     r10d,r11d
    77db49308070:	and    edx,0x1
    77db49308073:	shl    edx,0x1c
    77db49308076:	or     r10d,edx
    77db49308079:	btc    r10,0x1d
    77db4930807e:	mov    r11d,0xf0000000
    77db49308084:	and    r11,r10
    77db49308087:	movabs rsi,0xffffffff0fffffff
    77db49308091:	and    rbx,rsi
    77db49308094:	or     rbx,r11
    77db49308097:	pop    r11
    77db49308099:	pop    r10
    77db4930809b:	pop    rsi
    77db4930809c:	pop    rdx
    77db4930809d:	mov    QWORD PTR [r12+0x108],rbx
    77db493080a5:	stmxcsr DWORD PTR [r12-0x28]
    77db493080ab:	mov    r10d,DWORD PTR [r12-0x28]
    77db493080b0:	test   r10d,0x3f
    77db493080b7:	je     0x77db493080dc
    77db493080bd:	mov    r11d,r10d
    77db493080c0:	shr    r10d,1
    77db493080c3:	and    r10d,0x1e
    77db493080c7:	and    r11d,0x1
    77db493080cb:	or     r10d,r11d
    77db493080ce:	or     DWORD PTR [r12+0x314],r10d
    77db493080d6:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db493080dc:	ldmxcsr DWORD PTR [r12-0x38]
    77db493080e2:	lea    rdi,[rsp+0x110]
    77db493080ea:	lea    rsi,[rsp+0xf0]
    77db493080f2:	lea    rdx,[rsp+0x100]
    77db493080fa:	mov    ecx,0x14
    77db493080ff:	mov    r8d,0x0
    77db49308105:	lea    r9,[r12+0x314]
    77db4930810d:	movabs r11,0x60ebc89f0650
    77db49308117:	call   r11
    77db4930811a:	ldmxcsr DWORD PTR [r12-0x28]
    77db49308120:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49308126:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930812c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49308132:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49308138:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930813e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49308144:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930814e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49308158:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49308162:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930816c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db49308176:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930817e:	mov    QWORD PTR [r12+0x378],0x2
    77db4930818a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49308193:	mov    rdx,rbx
    77db49308196:	shr    rdx,0x10
    77db4930819a:	and    edx,0xc000
    77db493081a0:	mov    rax,rbx
    77db493081a3:	shr    rax,0x15
    77db493081a7:	and    eax,0x100
    77db493081ac:	xor    eax,0x100
    77db493081b1:	or     edx,eax
    77db493081b3:	mov    rax,rbx
    77db493081b6:	shr    rax,0x1c
    77db493081ba:	and    eax,0x1
    77db493081bd:	or     edx,eax
    77db493081bf:	mov    QWORD PTR [rsp+0x10],rdx
    77db493081c4:	add    rsp,0x8
    77db493081c8:	ret
    77db493081c9:	nop    DWORD PTR [rax+0x0]
    77db493081d0:	sub    rsp,0x8
    77db493081d4:	mov    QWORD PTR [r12+0x378],0x3
    77db493081e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db493081e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493081ec:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db493081f2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493081f8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db49308202:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db4930820c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49308216:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49308220:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db4930822a:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db49308234:	push   rdx
    77db49308235:	push   rsi
    77db49308236:	push   r10
    77db49308238:	push   r11
    77db4930823a:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930823f:	mov    r10d,edx
    77db49308242:	and    r10d,0xc000
    77db49308249:	shl    r10d,0x10
    77db4930824d:	mov    r11d,edx
    77db49308250:	and    r11d,0x100
    77db49308257:	shl    r11d,0x15
    77db4930825b:	or     r10d,r11d
    77db4930825e:	and    edx,0x1
    77db49308261:	shl    edx,0x1c
    77db49308264:	or     r10d,edx
    77db49308267:	btc    r10,0x1d
    77db4930826c:	mov    r11d,0xf0000000
    77db49308272:	and    r11,r10
    77db49308275:	movabs rsi,0xffffffff0fffffff
    77db4930827f:	and    rbx,rsi
    77db49308282:	or     rbx,r11
    77db49308285:	pop    r11
    77db49308287:	pop    r10
    77db49308289:	pop    rsi
    77db4930828a:	pop    rdx
    77db4930828b:	mov    QWORD PTR [r12+0x108],rbx
    77db49308293:	stmxcsr DWORD PTR [r12-0x28]
    77db49308299:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930829e:	test   r10d,0x3f
    77db493082a5:	je     0x77db493082ca
    77db493082ab:	mov    r11d,r10d
    77db493082ae:	shr    r10d,1
    77db493082b1:	and    r10d,0x1e
    77db493082b5:	and    r11d,0x1
    77db493082b9:	or     r10d,r11d
    77db493082bc:	or     DWORD PTR [r12+0x314],r10d
    77db493082c4:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db493082ca:	ldmxcsr DWORD PTR [r12-0x38]
    77db493082d0:	lea    rdi,[rsp+0x110]
    77db493082d8:	lea    rsi,[rsp+0xf0]
    77db493082e0:	lea    rdx,[rsp+0x100]
    77db493082e8:	mov    ecx,0x56
    77db493082ed:	mov    r8d,0x0
    77db493082f3:	lea    r9,[r12+0x314]
    77db493082fb:	movabs r11,0x60ebc89f0650
    77db49308305:	call   r11
    77db49308308:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930830e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49308314:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930831a:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49308320:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49308326:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49308330:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930833a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49308344:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db4930834e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49308358:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db49308362:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930836a:	mov    QWORD PTR [r12+0x378],0x2
    77db49308376:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930837f:	mov    rdx,rbx
    77db49308382:	shr    rdx,0x10
    77db49308386:	and    edx,0xc000
    77db4930838c:	mov    rax,rbx
    77db4930838f:	shr    rax,0x15
    77db49308393:	and    eax,0x100
    77db49308398:	xor    eax,0x100
    77db4930839d:	or     edx,eax
    77db4930839f:	mov    rax,rbx
    77db493083a2:	shr    rax,0x1c
    77db493083a6:	and    eax,0x1
    77db493083a9:	or     edx,eax
    77db493083ab:	mov    QWORD PTR [rsp+0x10],rdx
    77db493083b0:	add    rsp,0x8
    77db493083b4:	ret
    77db493083b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db493083c0:	sub    rsp,0x8
    77db493083c4:	mov    QWORD PTR [r12+0x378],0x3
    77db493083d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db493083d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493083dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db493083e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db493083e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493083ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db493083f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49308402:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930840c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49308416:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49308420:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db4930842a:	push   rdx
    77db4930842b:	push   rsi
    77db4930842c:	push   r10
    77db4930842e:	push   r11
    77db49308430:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49308435:	mov    r10d,edx
    77db49308438:	and    r10d,0xc000
    77db4930843f:	shl    r10d,0x10
    77db49308443:	mov    r11d,edx
    77db49308446:	and    r11d,0x100
    77db4930844d:	shl    r11d,0x15
    77db49308451:	or     r10d,r11d
    77db49308454:	and    edx,0x1
    77db49308457:	shl    edx,0x1c
    77db4930845a:	or     r10d,edx
    77db4930845d:	btc    r10,0x1d
    77db49308462:	mov    r11d,0xf0000000
    77db49308468:	and    r11,r10
    77db4930846b:	movabs rsi,0xffffffff0fffffff
    77db49308475:	and    rbx,rsi
    77db49308478:	or     rbx,r11
    77db4930847b:	pop    r11
    77db4930847d:	pop    r10
    77db4930847f:	pop    rsi
    77db49308480:	pop    rdx
    77db49308481:	mov    QWORD PTR [r12+0x108],rbx
    77db49308489:	stmxcsr DWORD PTR [r12-0x28]
    77db4930848f:	mov    r10d,DWORD PTR [r12-0x28]
    77db49308494:	test   r10d,0x3f
    77db4930849b:	je     0x77db493084c0
    77db493084a1:	mov    r11d,r10d
    77db493084a4:	shr    r10d,1
    77db493084a7:	and    r10d,0x1e
    77db493084ab:	and    r11d,0x1
    77db493084af:	or     r10d,r11d
    77db493084b2:	or     DWORD PTR [r12+0x314],r10d
    77db493084ba:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db493084c0:	ldmxcsr DWORD PTR [r12-0x38]
    77db493084c6:	lea    rdi,[rsp+0x110]
    77db493084ce:	lea    rsi,[rsp+0xf0]
    77db493084d6:	lea    rdx,[rsp+0x100]
    77db493084de:	mov    ecx,0x14
    77db493084e3:	mov    r8d,0x0
    77db493084e9:	lea    r9,[r12+0x314]
    77db493084f1:	movabs r11,0x60ebc89f0650
    77db493084fb:	call   r11
    77db493084fe:	ldmxcsr DWORD PTR [r12-0x28]
    77db49308504:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930850a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49308510:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49308516:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930851c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49308522:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db4930852c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49308536:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49308540:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db4930854a:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49308554:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db4930855e:	mov    rbx,QWORD PTR [r12+0x108]
    77db49308566:	mov    QWORD PTR [r12+0x378],0x2
    77db49308572:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930857b:	mov    rdx,rbx
    77db4930857e:	shr    rdx,0x10
    77db49308582:	and    edx,0xc000
    77db49308588:	mov    rax,rbx
    77db4930858b:	shr    rax,0x15
    77db4930858f:	and    eax,0x100
    77db49308594:	xor    eax,0x100
    77db49308599:	or     edx,eax
    77db4930859b:	mov    rax,rbx
    77db4930859e:	shr    rax,0x1c
    77db493085a2:	and    eax,0x1
    77db493085a5:	or     edx,eax
    77db493085a7:	mov    QWORD PTR [rsp+0x10],rdx
    77db493085ac:	add    rsp,0x8
    77db493085b0:	ret
    77db493085b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db493085c0:	sub    rsp,0x8
    77db493085c4:	mov    QWORD PTR [r12+0x378],0x3
    77db493085d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db493085d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db493085dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493085e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db493085e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db493085ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493085f4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db493085fe:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49308608:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49308612:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db4930861c:	push   rdx
    77db4930861d:	push   rsi
    77db4930861e:	push   r10
    77db49308620:	push   r11
    77db49308622:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49308627:	mov    r10d,edx
    77db4930862a:	and    r10d,0xc000
    77db49308631:	shl    r10d,0x10
    77db49308635:	mov    r11d,edx
    77db49308638:	and    r11d,0x100
    77db4930863f:	shl    r11d,0x15
    77db49308643:	or     r10d,r11d
    77db49308646:	and    edx,0x1
    77db49308649:	shl    edx,0x1c
    77db4930864c:	or     r10d,edx
    77db4930864f:	btc    r10,0x1d
    77db49308654:	mov    r11d,0xf0000000
    77db4930865a:	and    r11,r10
    77db4930865d:	movabs rsi,0xffffffff0fffffff
    77db49308667:	and    rbx,rsi
    77db4930866a:	or     rbx,r11
    77db4930866d:	pop    r11
    77db4930866f:	pop    r10
    77db49308671:	pop    rsi
    77db49308672:	pop    rdx
    77db49308673:	mov    QWORD PTR [r12+0x108],rbx
    77db4930867b:	stmxcsr DWORD PTR [r12-0x28]
    77db49308681:	mov    r10d,DWORD PTR [r12-0x28]
    77db49308686:	test   r10d,0x3f
    77db4930868d:	je     0x77db493086b2
    77db49308693:	mov    r11d,r10d
    77db49308696:	shr    r10d,1
    77db49308699:	and    r10d,0x1e
    77db4930869d:	and    r11d,0x1
    77db493086a1:	or     r10d,r11d
    77db493086a4:	or     DWORD PTR [r12+0x314],r10d
    77db493086ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db493086b2:	ldmxcsr DWORD PTR [r12-0x38]
    77db493086b8:	lea    rdi,[rsp+0x110]
    77db493086c0:	lea    rsi,[rsp+0xf0]
    77db493086c8:	lea    rdx,[rsp+0x100]
    77db493086d0:	mov    ecx,0x56
    77db493086d5:	mov    r8d,0x0
    77db493086db:	lea    r9,[r12+0x314]
    77db493086e3:	movabs r11,0x60ebc89f0650
    77db493086ed:	call   r11
    77db493086f0:	ldmxcsr DWORD PTR [r12-0x28]
    77db493086f6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db493086fc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49308702:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49308708:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930870e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49308714:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930871a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49308724:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930872e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49308738:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db49308742:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930874a:	mov    QWORD PTR [r12+0x378],0x2
    77db49308756:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930875f:	mov    rdx,rbx
    77db49308762:	shr    rdx,0x10
    77db49308766:	and    edx,0xc000
    77db4930876c:	mov    rax,rbx
    77db4930876f:	shr    rax,0x15
    77db49308773:	and    eax,0x100
    77db49308778:	xor    eax,0x100
    77db4930877d:	or     edx,eax
    77db4930877f:	mov    rax,rbx
    77db49308782:	shr    rax,0x1c
    77db49308786:	and    eax,0x1
    77db49308789:	or     edx,eax
    77db4930878b:	mov    QWORD PTR [rsp+0x10],rdx
    77db49308790:	add    rsp,0x8
    77db49308794:	ret
    77db49308795:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db493087a0:	sub    rsp,0x8
    77db493087a4:	mov    QWORD PTR [r12+0x378],0x3
    77db493087b0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db493087b6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493087bc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db493087c2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db493087c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db493087d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db493087dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db493087e6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db493087f0:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    77db493087fa:	push   rdx
    77db493087fb:	push   rsi
    77db493087fc:	push   r10
    77db493087fe:	push   r11
    77db49308800:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49308805:	mov    r10d,edx
    77db49308808:	and    r10d,0xc000
    77db4930880f:	shl    r10d,0x10
    77db49308813:	mov    r11d,edx
    77db49308816:	and    r11d,0x100
    77db4930881d:	shl    r11d,0x15
    77db49308821:	or     r10d,r11d
    77db49308824:	and    edx,0x1
    77db49308827:	shl    edx,0x1c
    77db4930882a:	or     r10d,edx
    77db4930882d:	btc    r10,0x1d
    77db49308832:	mov    r11d,0xf0000000
    77db49308838:	and    r11,r10
    77db4930883b:	movabs rsi,0xffffffff0fffffff
    77db49308845:	and    rbx,rsi
    77db49308848:	or     rbx,r11
    77db4930884b:	pop    r11
    77db4930884d:	pop    r10
    77db4930884f:	pop    rsi
    77db49308850:	pop    rdx
    77db49308851:	mov    QWORD PTR [r12+0x108],rbx
    77db49308859:	stmxcsr DWORD PTR [r12-0x28]
    77db4930885f:	mov    r10d,DWORD PTR [r12-0x28]
    77db49308864:	test   r10d,0x3f
    77db4930886b:	je     0x77db49308890
    77db49308871:	mov    r11d,r10d
    77db49308874:	shr    r10d,1
    77db49308877:	and    r10d,0x1e
    77db4930887b:	and    r11d,0x1
    77db4930887f:	or     r10d,r11d
    77db49308882:	or     DWORD PTR [r12+0x314],r10d
    77db4930888a:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49308890:	ldmxcsr DWORD PTR [r12-0x38]
    77db49308896:	lea    rdi,[rsp+0x110]
    77db4930889e:	lea    rsi,[rsp+0xf0]
    77db493088a6:	lea    rdx,[rsp+0x100]
    77db493088ae:	mov    ecx,0x14
    77db493088b3:	mov    r8d,0x0
    77db493088b9:	lea    r9,[r12+0x314]
    77db493088c1:	movabs r11,0x60ebc89f0650
    77db493088cb:	call   r11
    77db493088ce:	ldmxcsr DWORD PTR [r12-0x28]
    77db493088d4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db493088da:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db493088e0:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db493088e6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db493088ec:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db493088f6:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49308900:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930890a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49308914:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    77db4930891e:	mov    rbx,QWORD PTR [r12+0x108]
    77db49308926:	mov    QWORD PTR [r12+0x378],0x2
    77db49308932:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930893b:	mov    rdx,rbx
    77db4930893e:	shr    rdx,0x10
    77db49308942:	and    edx,0xc000
    77db49308948:	mov    rax,rbx
    77db4930894b:	shr    rax,0x15
    77db4930894f:	and    eax,0x100
    77db49308954:	xor    eax,0x100
    77db49308959:	or     edx,eax
    77db4930895b:	mov    rax,rbx
    77db4930895e:	shr    rax,0x1c
    77db49308962:	and    eax,0x1
    77db49308965:	or     edx,eax
    77db49308967:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930896c:	add    rsp,0x8
    77db49308970:	ret
    77db49308971:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49308980:	sub    rsp,0x8
    77db49308984:	mov    QWORD PTR [r12+0x378],0x3
    77db49308990:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49308996:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930899c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493089a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db493089a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db493089ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493089b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db493089be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db493089c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db493089d2:	push   rdx
    77db493089d3:	push   rsi
    77db493089d4:	push   r10
    77db493089d6:	push   r11
    77db493089d8:	mov    rdx,QWORD PTR [rsp+0x30]
    77db493089dd:	mov    r10d,edx
    77db493089e0:	and    r10d,0xc000
    77db493089e7:	shl    r10d,0x10
    77db493089eb:	mov    r11d,edx
    77db493089ee:	and    r11d,0x100
    77db493089f5:	shl    r11d,0x15
    77db493089f9:	or     r10d,r11d
    77db493089fc:	and    edx,0x1
    77db493089ff:	shl    edx,0x1c
    77db49308a02:	or     r10d,edx
    77db49308a05:	btc    r10,0x1d
    77db49308a0a:	mov    r11d,0xf0000000
    77db49308a10:	and    r11,r10
    77db49308a13:	movabs rsi,0xffffffff0fffffff
    77db49308a1d:	and    rbx,rsi
    77db49308a20:	or     rbx,r11
    77db49308a23:	pop    r11
    77db49308a25:	pop    r10
    77db49308a27:	pop    rsi
    77db49308a28:	pop    rdx
    77db49308a29:	mov    QWORD PTR [r12+0x108],rbx
    77db49308a31:	stmxcsr DWORD PTR [r12-0x28]
    77db49308a37:	mov    r10d,DWORD PTR [r12-0x28]
    77db49308a3c:	test   r10d,0x3f
    77db49308a43:	je     0x77db49308a68
    77db49308a49:	mov    r11d,r10d
    77db49308a4c:	shr    r10d,1
    77db49308a4f:	and    r10d,0x1e
    77db49308a53:	and    r11d,0x1
    77db49308a57:	or     r10d,r11d
    77db49308a5a:	or     DWORD PTR [r12+0x314],r10d
    77db49308a62:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49308a68:	ldmxcsr DWORD PTR [r12-0x38]
    77db49308a6e:	lea    rdi,[rsp+0x110]
    77db49308a76:	lea    rsi,[rsp+0xf0]
    77db49308a7e:	lea    rdx,[rsp+0x100]
    77db49308a86:	mov    ecx,0x56
    77db49308a8b:	mov    r8d,0x0
    77db49308a91:	lea    r9,[r12+0x314]
    77db49308a99:	movabs r11,0x60ebc89f0650
    77db49308aa3:	call   r11
    77db49308aa6:	ldmxcsr DWORD PTR [r12-0x28]
    77db49308aac:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49308ab2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49308ab8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49308abe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49308ac4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49308aca:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49308ad0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49308ada:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49308ae4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49308aee:	mov    rbx,QWORD PTR [r12+0x108]
    77db49308af6:	mov    QWORD PTR [r12+0x378],0x2
    77db49308b02:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49308b0b:	mov    rdx,rbx
    77db49308b0e:	shr    rdx,0x10
    77db49308b12:	and    edx,0xc000
    77db49308b18:	mov    rax,rbx
    77db49308b1b:	shr    rax,0x15
    77db49308b1f:	and    eax,0x100
    77db49308b24:	xor    eax,0x100
    77db49308b29:	or     edx,eax
    77db49308b2b:	mov    rax,rbx
    77db49308b2e:	shr    rax,0x1c
    77db49308b32:	and    eax,0x1
    77db49308b35:	or     edx,eax
    77db49308b37:	mov    QWORD PTR [rsp+0x10],rdx
    77db49308b3c:	add    rsp,0x8
    77db49308b40:	ret
    77db49308b41:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49308b50:	sub    rsp,0x8
    77db49308b54:	mov    QWORD PTR [r12+0x378],0x3
    77db49308b60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49308b66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db49308b6c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49308b72:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49308b78:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49308b7e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db49308b88:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49308b92:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49308b9c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49308ba6:	push   rdx
    77db49308ba7:	push   rsi
    77db49308ba8:	push   r10
    77db49308baa:	push   r11
    77db49308bac:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49308bb1:	mov    r10d,edx
    77db49308bb4:	and    r10d,0xc000
    77db49308bbb:	shl    r10d,0x10
    77db49308bbf:	mov    r11d,edx
    77db49308bc2:	and    r11d,0x100
    77db49308bc9:	shl    r11d,0x15
    77db49308bcd:	or     r10d,r11d
    77db49308bd0:	and    edx,0x1
    77db49308bd3:	shl    edx,0x1c
    77db49308bd6:	or     r10d,edx
    77db49308bd9:	btc    r10,0x1d
    77db49308bde:	mov    r11d,0xf0000000
    77db49308be4:	and    r11,r10
    77db49308be7:	movabs rsi,0xffffffff0fffffff
    77db49308bf1:	and    rbx,rsi
    77db49308bf4:	or     rbx,r11
    77db49308bf7:	pop    r11
    77db49308bf9:	pop    r10
    77db49308bfb:	pop    rsi
    77db49308bfc:	pop    rdx
    77db49308bfd:	mov    QWORD PTR [r12+0x108],rbx
    77db49308c05:	stmxcsr DWORD PTR [r12-0x28]
    77db49308c0b:	mov    r10d,DWORD PTR [r12-0x28]
    77db49308c10:	test   r10d,0x3f
    77db49308c17:	je     0x77db49308c3c
    77db49308c1d:	mov    r11d,r10d
    77db49308c20:	shr    r10d,1
    77db49308c23:	and    r10d,0x1e
    77db49308c27:	and    r11d,0x1
    77db49308c2b:	or     r10d,r11d
    77db49308c2e:	or     DWORD PTR [r12+0x314],r10d
    77db49308c36:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49308c3c:	ldmxcsr DWORD PTR [r12-0x38]
    77db49308c42:	lea    rdi,[rsp+0x110]
    77db49308c4a:	lea    rsi,[rsp+0xf0]
    77db49308c52:	lea    rdx,[rsp+0x100]
    77db49308c5a:	mov    ecx,0x56
    77db49308c5f:	mov    r8d,0x0
    77db49308c65:	lea    r9,[r12+0x314]
    77db49308c6d:	movabs r11,0x60ebc89f0650
    77db49308c77:	call   r11
    77db49308c7a:	ldmxcsr DWORD PTR [r12-0x28]
    77db49308c80:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49308c86:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49308c8c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49308c92:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49308c98:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49308c9e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49308ca8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49308cb2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49308cbc:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49308cc6:	mov    rbx,QWORD PTR [r12+0x108]
    77db49308cce:	mov    QWORD PTR [r12+0x378],0x2
    77db49308cda:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49308ce3:	mov    rdx,rbx
    77db49308ce6:	shr    rdx,0x10
    77db49308cea:	and    edx,0xc000
    77db49308cf0:	mov    rax,rbx
    77db49308cf3:	shr    rax,0x15
    77db49308cf7:	and    eax,0x100
    77db49308cfc:	xor    eax,0x100
    77db49308d01:	or     edx,eax
    77db49308d03:	mov    rax,rbx
    77db49308d06:	shr    rax,0x1c
    77db49308d0a:	and    eax,0x1
    77db49308d0d:	or     edx,eax
    77db49308d0f:	mov    QWORD PTR [rsp+0x10],rdx
    77db49308d14:	add    rsp,0x8
    77db49308d18:	ret
    77db49308d19:	nop    DWORD PTR [rax+0x0]
    77db49308d20:	sub    rsp,0x8
    77db49308d24:	mov    QWORD PTR [r12+0x378],0x3
    77db49308d30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49308d36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db49308d3c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49308d42:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49308d48:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49308d4e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49308d54:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db49308d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49308d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49308d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49308d7c:	push   rdx
    77db49308d7d:	push   rsi
    77db49308d7e:	push   r10
    77db49308d80:	push   r11
    77db49308d82:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49308d87:	mov    r10d,edx
    77db49308d8a:	and    r10d,0xc000
    77db49308d91:	shl    r10d,0x10
    77db49308d95:	mov    r11d,edx
    77db49308d98:	and    r11d,0x100
    77db49308d9f:	shl    r11d,0x15
    77db49308da3:	or     r10d,r11d
    77db49308da6:	and    edx,0x1
    77db49308da9:	shl    edx,0x1c
    77db49308dac:	or     r10d,edx
    77db49308daf:	btc    r10,0x1d
    77db49308db4:	mov    r11d,0xf0000000
    77db49308dba:	and    r11,r10
    77db49308dbd:	movabs rsi,0xffffffff0fffffff
    77db49308dc7:	and    rbx,rsi
    77db49308dca:	or     rbx,r11
    77db49308dcd:	pop    r11
    77db49308dcf:	pop    r10
    77db49308dd1:	pop    rsi
    77db49308dd2:	pop    rdx
    77db49308dd3:	mov    QWORD PTR [r12+0x108],rbx
    77db49308ddb:	stmxcsr DWORD PTR [r12-0x28]
    77db49308de1:	mov    r10d,DWORD PTR [r12-0x28]
    77db49308de6:	test   r10d,0x3f
    77db49308ded:	je     0x77db49308e12
    77db49308df3:	mov    r11d,r10d
    77db49308df6:	shr    r10d,1
    77db49308df9:	and    r10d,0x1e
    77db49308dfd:	and    r11d,0x1
    77db49308e01:	or     r10d,r11d
    77db49308e04:	or     DWORD PTR [r12+0x314],r10d
    77db49308e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49308e12:	ldmxcsr DWORD PTR [r12-0x38]
    77db49308e18:	lea    rdi,[rsp+0x110]
    77db49308e20:	lea    rsi,[rsp+0xf0]
    77db49308e28:	lea    rdx,[rsp+0x100]
    77db49308e30:	mov    ecx,0x14
    77db49308e35:	mov    r8d,0x0
    77db49308e3b:	lea    r9,[r12+0x314]
    77db49308e43:	movabs r11,0x60ebc89f0650
    77db49308e4d:	call   r11
    77db49308e50:	ldmxcsr DWORD PTR [r12-0x28]
    77db49308e56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49308e5c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49308e62:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49308e68:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49308e6e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49308e74:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49308e7a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49308e84:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49308e8e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49308e98:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49308ea2:	mov    rbx,QWORD PTR [r12+0x108]
    77db49308eaa:	mov    QWORD PTR [r12+0x378],0x2
    77db49308eb6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49308ebf:	mov    rdx,rbx
    77db49308ec2:	shr    rdx,0x10
    77db49308ec6:	and    edx,0xc000
    77db49308ecc:	mov    rax,rbx
    77db49308ecf:	shr    rax,0x15
    77db49308ed3:	and    eax,0x100
    77db49308ed8:	xor    eax,0x100
    77db49308edd:	or     edx,eax
    77db49308edf:	mov    rax,rbx
    77db49308ee2:	shr    rax,0x1c
    77db49308ee6:	and    eax,0x1
    77db49308ee9:	or     edx,eax
    77db49308eeb:	mov    QWORD PTR [rsp+0x10],rdx
    77db49308ef0:	add    rsp,0x8
    77db49308ef4:	ret
    77db49308ef5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49308f00:	sub    rsp,0x8
    77db49308f04:	mov    QWORD PTR [r12+0x378],0x3
    77db49308f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49308f16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db49308f1c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49308f22:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49308f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49308f2e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49308f38:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49308f42:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49308f4c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49308f56:	push   rdx
    77db49308f57:	push   rsi
    77db49308f58:	push   r10
    77db49308f5a:	push   r11
    77db49308f5c:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49308f61:	mov    r10d,edx
    77db49308f64:	and    r10d,0xc000
    77db49308f6b:	shl    r10d,0x10
    77db49308f6f:	mov    r11d,edx
    77db49308f72:	and    r11d,0x100
    77db49308f79:	shl    r11d,0x15
    77db49308f7d:	or     r10d,r11d
    77db49308f80:	and    edx,0x1
    77db49308f83:	shl    edx,0x1c
    77db49308f86:	or     r10d,edx
    77db49308f89:	btc    r10,0x1d
    77db49308f8e:	mov    r11d,0xf0000000
    77db49308f94:	and    r11,r10
    77db49308f97:	movabs rsi,0xffffffff0fffffff
    77db49308fa1:	and    rbx,rsi
    77db49308fa4:	or     rbx,r11
    77db49308fa7:	pop    r11
    77db49308fa9:	pop    r10
    77db49308fab:	pop    rsi
    77db49308fac:	pop    rdx
    77db49308fad:	mov    QWORD PTR [r12+0x108],rbx
    77db49308fb5:	stmxcsr DWORD PTR [r12-0x28]
    77db49308fbb:	mov    r10d,DWORD PTR [r12-0x28]
    77db49308fc0:	test   r10d,0x3f
    77db49308fc7:	je     0x77db49308fec
    77db49308fcd:	mov    r11d,r10d
    77db49308fd0:	shr    r10d,1
    77db49308fd3:	and    r10d,0x1e
    77db49308fd7:	and    r11d,0x1
    77db49308fdb:	or     r10d,r11d
    77db49308fde:	or     DWORD PTR [r12+0x314],r10d
    77db49308fe6:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49308fec:	ldmxcsr DWORD PTR [r12-0x38]
    77db49308ff2:	lea    rdi,[rsp+0x110]
    77db49308ffa:	lea    rsi,[rsp+0xf0]
    77db49309002:	lea    rdx,[rsp+0x100]
    77db4930900a:	mov    ecx,0x14
    77db4930900f:	mov    r8d,0x0
    77db49309015:	lea    r9,[r12+0x314]
    77db4930901d:	movabs r11,0x60ebc89f0650
    77db49309027:	call   r11
    77db4930902a:	ldmxcsr DWORD PTR [r12-0x28]
    77db49309030:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49309036:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930903c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49309042:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49309048:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930904e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49309058:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49309062:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db4930906c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49309076:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930907e:	mov    QWORD PTR [r12+0x378],0x2
    77db4930908a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49309093:	mov    rdx,rbx
    77db49309096:	shr    rdx,0x10
    77db4930909a:	and    edx,0xc000
    77db493090a0:	mov    rax,rbx
    77db493090a3:	shr    rax,0x15
    77db493090a7:	and    eax,0x100
    77db493090ac:	xor    eax,0x100
    77db493090b1:	or     edx,eax
    77db493090b3:	mov    rax,rbx
    77db493090b6:	shr    rax,0x1c
    77db493090ba:	and    eax,0x1
    77db493090bd:	or     edx,eax
    77db493090bf:	mov    QWORD PTR [rsp+0x10],rdx
    77db493090c4:	add    rsp,0x8
    77db493090c8:	ret
    77db493090c9:	nop    DWORD PTR [rax+0x0]
    77db493090d0:	sub    rsp,0x8
    77db493090d4:	mov    QWORD PTR [r12+0x378],0x3
    77db493090e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db493090e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db493090ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493090f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db493090f8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493090fe:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49309108:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49309112:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db4930911c:	push   rdx
    77db4930911d:	push   rsi
    77db4930911e:	push   r10
    77db49309120:	push   r11
    77db49309122:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49309127:	mov    r10d,edx
    77db4930912a:	and    r10d,0xc000
    77db49309131:	shl    r10d,0x10
    77db49309135:	mov    r11d,edx
    77db49309138:	and    r11d,0x100
    77db4930913f:	shl    r11d,0x15
    77db49309143:	or     r10d,r11d
    77db49309146:	and    edx,0x1
    77db49309149:	shl    edx,0x1c
    77db4930914c:	or     r10d,edx
    77db4930914f:	btc    r10,0x1d
    77db49309154:	mov    r11d,0xf0000000
    77db4930915a:	and    r11,r10
    77db4930915d:	movabs rsi,0xffffffff0fffffff
    77db49309167:	and    rbx,rsi
    77db4930916a:	or     rbx,r11
    77db4930916d:	pop    r11
    77db4930916f:	pop    r10
    77db49309171:	pop    rsi
    77db49309172:	pop    rdx
    77db49309173:	mov    QWORD PTR [r12+0x108],rbx
    77db4930917b:	stmxcsr DWORD PTR [r12-0x28]
    77db49309181:	mov    r10d,DWORD PTR [r12-0x28]
    77db49309186:	test   r10d,0x3f
    77db4930918d:	je     0x77db493091b2
    77db49309193:	mov    r11d,r10d
    77db49309196:	shr    r10d,1
    77db49309199:	and    r10d,0x1e
    77db4930919d:	and    r11d,0x1
    77db493091a1:	or     r10d,r11d
    77db493091a4:	or     DWORD PTR [r12+0x314],r10d
    77db493091ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db493091b2:	ldmxcsr DWORD PTR [r12-0x38]
    77db493091b8:	lea    rdi,[rsp+0x110]
    77db493091c0:	lea    rsi,[rsp+0xf0]
    77db493091c8:	lea    rdx,[rsp+0x100]
    77db493091d0:	mov    ecx,0x56
    77db493091d5:	mov    r8d,0x0
    77db493091db:	lea    r9,[r12+0x314]
    77db493091e3:	movabs r11,0x60ebc89f0650
    77db493091ed:	call   r11
    77db493091f0:	ldmxcsr DWORD PTR [r12-0x28]
    77db493091f6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db493091fc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49309202:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49309208:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930920e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49309214:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930921e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49309228:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49309232:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930923a:	mov    QWORD PTR [r12+0x378],0x2
    77db49309246:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930924f:	mov    rdx,rbx
    77db49309252:	shr    rdx,0x10
    77db49309256:	and    edx,0xc000
    77db4930925c:	mov    rax,rbx
    77db4930925f:	shr    rax,0x15
    77db49309263:	and    eax,0x100
    77db49309268:	xor    eax,0x100
    77db4930926d:	or     edx,eax
    77db4930926f:	mov    rax,rbx
    77db49309272:	shr    rax,0x1c
    77db49309276:	and    eax,0x1
    77db49309279:	or     edx,eax
    77db4930927b:	mov    QWORD PTR [rsp+0x10],rdx
    77db49309280:	add    rsp,0x8
    77db49309284:	ret
    77db49309285:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49309290:	sub    rsp,0x8
    77db49309294:	mov    QWORD PTR [r12+0x378],0x3
    77db493092a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db493092a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db493092ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493092b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db493092b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db493092be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493092c4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db493092ce:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db493092d8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db493092e2:	push   rdx
    77db493092e3:	push   rsi
    77db493092e4:	push   r10
    77db493092e6:	push   r11
    77db493092e8:	mov    rdx,QWORD PTR [rsp+0x30]
    77db493092ed:	mov    r10d,edx
    77db493092f0:	and    r10d,0xc000
    77db493092f7:	shl    r10d,0x10
    77db493092fb:	mov    r11d,edx
    77db493092fe:	and    r11d,0x100
    77db49309305:	shl    r11d,0x15
    77db49309309:	or     r10d,r11d
    77db4930930c:	and    edx,0x1
    77db4930930f:	shl    edx,0x1c
    77db49309312:	or     r10d,edx
    77db49309315:	btc    r10,0x1d
    77db4930931a:	mov    r11d,0xf0000000
    77db49309320:	and    r11,r10
    77db49309323:	movabs rsi,0xffffffff0fffffff
    77db4930932d:	and    rbx,rsi
    77db49309330:	or     rbx,r11
    77db49309333:	pop    r11
    77db49309335:	pop    r10
    77db49309337:	pop    rsi
    77db49309338:	pop    rdx
    77db49309339:	mov    QWORD PTR [r12+0x108],rbx
    77db49309341:	stmxcsr DWORD PTR [r12-0x28]
    77db49309347:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930934c:	test   r10d,0x3f
    77db49309353:	je     0x77db49309378
    77db49309359:	mov    r11d,r10d
    77db4930935c:	shr    r10d,1
    77db4930935f:	and    r10d,0x1e
    77db49309363:	and    r11d,0x1
    77db49309367:	or     r10d,r11d
    77db4930936a:	or     DWORD PTR [r12+0x314],r10d
    77db49309372:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49309378:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930937e:	lea    rdi,[rsp+0x110]
    77db49309386:	lea    rsi,[rsp+0xf0]
    77db4930938e:	lea    rdx,[rsp+0x100]
    77db49309396:	mov    ecx,0x56
    77db4930939b:	mov    r8d,0x0
    77db493093a1:	lea    r9,[r12+0x314]
    77db493093a9:	movabs r11,0x60ebc89f0650
    77db493093b3:	call   r11
    77db493093b6:	ldmxcsr DWORD PTR [r12-0x28]
    77db493093bc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db493093c2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db493093c8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db493093ce:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db493093d4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db493093da:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db493093e0:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db493093ea:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db493093f4:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db493093fe:	mov    rbx,QWORD PTR [r12+0x108]
    77db49309406:	mov    QWORD PTR [r12+0x378],0x2
    77db49309412:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930941b:	mov    rdx,rbx
    77db4930941e:	shr    rdx,0x10
    77db49309422:	and    edx,0xc000
    77db49309428:	mov    rax,rbx
    77db4930942b:	shr    rax,0x15
    77db4930942f:	and    eax,0x100
    77db49309434:	xor    eax,0x100
    77db49309439:	or     edx,eax
    77db4930943b:	mov    rax,rbx
    77db4930943e:	shr    rax,0x1c
    77db49309442:	and    eax,0x1
    77db49309445:	or     edx,eax
    77db49309447:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930944c:	add    rsp,0x8
    77db49309450:	ret
    77db49309451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49309460:	sub    rsp,0x8
    77db49309464:	mov    QWORD PTR [r12+0x378],0x3
    77db49309470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49309476:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930947c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49309482:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49309488:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930948e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db49309498:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db493094a2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db493094ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db493094b6:	push   rdx
    77db493094b7:	push   rsi
    77db493094b8:	push   r10
    77db493094ba:	push   r11
    77db493094bc:	mov    rdx,QWORD PTR [rsp+0x30]
    77db493094c1:	mov    r10d,edx
    77db493094c4:	and    r10d,0xc000
    77db493094cb:	shl    r10d,0x10
    77db493094cf:	mov    r11d,edx
    77db493094d2:	and    r11d,0x100
    77db493094d9:	shl    r11d,0x15
    77db493094dd:	or     r10d,r11d
    77db493094e0:	and    edx,0x1
    77db493094e3:	shl    edx,0x1c
    77db493094e6:	or     r10d,edx
    77db493094e9:	btc    r10,0x1d
    77db493094ee:	mov    r11d,0xf0000000
    77db493094f4:	and    r11,r10
    77db493094f7:	movabs rsi,0xffffffff0fffffff
    77db49309501:	and    rbx,rsi
    77db49309504:	or     rbx,r11
    77db49309507:	pop    r11
    77db49309509:	pop    r10
    77db4930950b:	pop    rsi
    77db4930950c:	pop    rdx
    77db4930950d:	mov    QWORD PTR [r12+0x108],rbx
    77db49309515:	stmxcsr DWORD PTR [r12-0x28]
    77db4930951b:	mov    r10d,DWORD PTR [r12-0x28]
    77db49309520:	test   r10d,0x3f
    77db49309527:	je     0x77db4930954c
    77db4930952d:	mov    r11d,r10d
    77db49309530:	shr    r10d,1
    77db49309533:	and    r10d,0x1e
    77db49309537:	and    r11d,0x1
    77db4930953b:	or     r10d,r11d
    77db4930953e:	or     DWORD PTR [r12+0x314],r10d
    77db49309546:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930954c:	ldmxcsr DWORD PTR [r12-0x38]
    77db49309552:	lea    rdi,[rsp+0x110]
    77db4930955a:	lea    rsi,[rsp+0xf0]
    77db49309562:	lea    rdx,[rsp+0x100]
    77db4930956a:	mov    ecx,0x14
    77db4930956f:	mov    r8d,0x0
    77db49309575:	lea    r9,[r12+0x314]
    77db4930957d:	movabs r11,0x60ebc89f0650
    77db49309587:	call   r11
    77db4930958a:	ldmxcsr DWORD PTR [r12-0x28]
    77db49309590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49309596:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930959c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db493095a2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db493095a8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db493095ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db493095b8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db493095c2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db493095cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db493095d6:	mov    rbx,QWORD PTR [r12+0x108]
    77db493095de:	mov    QWORD PTR [r12+0x378],0x2
    77db493095ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db493095f3:	mov    rdx,rbx
    77db493095f6:	shr    rdx,0x10
    77db493095fa:	and    edx,0xc000
    77db49309600:	mov    rax,rbx
    77db49309603:	shr    rax,0x15
    77db49309607:	and    eax,0x100
    77db4930960c:	xor    eax,0x100
    77db49309611:	or     edx,eax
    77db49309613:	mov    rax,rbx
    77db49309616:	shr    rax,0x1c
    77db4930961a:	and    eax,0x1
    77db4930961d:	or     edx,eax
    77db4930961f:	mov    QWORD PTR [rsp+0x10],rdx
    77db49309624:	add    rsp,0x8
    77db49309628:	ret
    77db49309629:	nop    DWORD PTR [rax+0x0]
    77db49309630:	sub    rsp,0x8
    77db49309634:	mov    QWORD PTR [r12+0x378],0x3
    77db49309640:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49309646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930964c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49309652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49309658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db4930965e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db49309668:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49309672:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db4930967c:	push   rdx
    77db4930967d:	push   rsi
    77db4930967e:	push   r10
    77db49309680:	push   r11
    77db49309682:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49309687:	mov    r10d,edx
    77db4930968a:	and    r10d,0xc000
    77db49309691:	shl    r10d,0x10
    77db49309695:	mov    r11d,edx
    77db49309698:	and    r11d,0x100
    77db4930969f:	shl    r11d,0x15
    77db493096a3:	or     r10d,r11d
    77db493096a6:	and    edx,0x1
    77db493096a9:	shl    edx,0x1c
    77db493096ac:	or     r10d,edx
    77db493096af:	btc    r10,0x1d
    77db493096b4:	mov    r11d,0xf0000000
    77db493096ba:	and    r11,r10
    77db493096bd:	movabs rsi,0xffffffff0fffffff
    77db493096c7:	and    rbx,rsi
    77db493096ca:	or     rbx,r11
    77db493096cd:	pop    r11
    77db493096cf:	pop    r10
    77db493096d1:	pop    rsi
    77db493096d2:	pop    rdx
    77db493096d3:	mov    QWORD PTR [r12+0x108],rbx
    77db493096db:	stmxcsr DWORD PTR [r12-0x28]
    77db493096e1:	mov    r10d,DWORD PTR [r12-0x28]
    77db493096e6:	test   r10d,0x3f
    77db493096ed:	je     0x77db49309712
    77db493096f3:	mov    r11d,r10d
    77db493096f6:	shr    r10d,1
    77db493096f9:	and    r10d,0x1e
    77db493096fd:	and    r11d,0x1
    77db49309701:	or     r10d,r11d
    77db49309704:	or     DWORD PTR [r12+0x314],r10d
    77db4930970c:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49309712:	ldmxcsr DWORD PTR [r12-0x38]
    77db49309718:	lea    rdi,[rsp+0x110]
    77db49309720:	lea    rsi,[rsp+0xf0]
    77db49309728:	lea    rdx,[rsp+0x100]
    77db49309730:	mov    ecx,0x14
    77db49309735:	mov    r8d,0x0
    77db4930973b:	lea    r9,[r12+0x314]
    77db49309743:	movabs r11,0x60ebc89f0650
    77db4930974d:	call   r11
    77db49309750:	ldmxcsr DWORD PTR [r12-0x28]
    77db49309756:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930975c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49309762:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49309768:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930976e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49309774:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db4930977e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49309788:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49309792:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930979a:	mov    QWORD PTR [r12+0x378],0x2
    77db493097a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db493097af:	mov    rdx,rbx
    77db493097b2:	shr    rdx,0x10
    77db493097b6:	and    edx,0xc000
    77db493097bc:	mov    rax,rbx
    77db493097bf:	shr    rax,0x15
    77db493097c3:	and    eax,0x100
    77db493097c8:	xor    eax,0x100
    77db493097cd:	or     edx,eax
    77db493097cf:	mov    rax,rbx
    77db493097d2:	shr    rax,0x1c
    77db493097d6:	and    eax,0x1
    77db493097d9:	or     edx,eax
    77db493097db:	mov    QWORD PTR [rsp+0x10],rdx
    77db493097e0:	add    rsp,0x8
    77db493097e4:	ret
    77db493097e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db493097f0:	sub    rsp,0x8
    77db493097f4:	mov    QWORD PTR [r12+0x378],0x3
    77db49309800:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49309806:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930980c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49309812:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49309818:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930981e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49309824:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db4930982e:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49309838:	push   rdx
    77db49309839:	push   rsi
    77db4930983a:	push   r10
    77db4930983c:	push   r11
    77db4930983e:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49309843:	mov    r10d,edx
    77db49309846:	and    r10d,0xc000
    77db4930984d:	shl    r10d,0x10
    77db49309851:	mov    r11d,edx
    77db49309854:	and    r11d,0x100
    77db4930985b:	shl    r11d,0x15
    77db4930985f:	or     r10d,r11d
    77db49309862:	and    edx,0x1
    77db49309865:	shl    edx,0x1c
    77db49309868:	or     r10d,edx
    77db4930986b:	btc    r10,0x1d
    77db49309870:	mov    r11d,0xf0000000
    77db49309876:	and    r11,r10
    77db49309879:	movabs rsi,0xffffffff0fffffff
    77db49309883:	and    rbx,rsi
    77db49309886:	or     rbx,r11
    77db49309889:	pop    r11
    77db4930988b:	pop    r10
    77db4930988d:	pop    rsi
    77db4930988e:	pop    rdx
    77db4930988f:	mov    QWORD PTR [r12+0x108],rbx
    77db49309897:	stmxcsr DWORD PTR [r12-0x28]
    77db4930989d:	mov    r10d,DWORD PTR [r12-0x28]
    77db493098a2:	test   r10d,0x3f
    77db493098a9:	je     0x77db493098ce
    77db493098af:	mov    r11d,r10d
    77db493098b2:	shr    r10d,1
    77db493098b5:	and    r10d,0x1e
    77db493098b9:	and    r11d,0x1
    77db493098bd:	or     r10d,r11d
    77db493098c0:	or     DWORD PTR [r12+0x314],r10d
    77db493098c8:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db493098ce:	ldmxcsr DWORD PTR [r12-0x38]
    77db493098d4:	lea    rdi,[rsp+0x110]
    77db493098dc:	lea    rsi,[rsp+0xf0]
    77db493098e4:	lea    rdx,[rsp+0x100]
    77db493098ec:	mov    ecx,0x56
    77db493098f1:	mov    r8d,0x0
    77db493098f7:	lea    r9,[r12+0x314]
    77db493098ff:	movabs r11,0x60ebc89f0650
    77db49309909:	call   r11
    77db4930990c:	ldmxcsr DWORD PTR [r12-0x28]
    77db49309912:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49309918:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930991e:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49309924:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930992a:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49309930:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49309936:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49309940:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930994a:	mov    rbx,QWORD PTR [r12+0x108]
    77db49309952:	mov    QWORD PTR [r12+0x378],0x2
    77db4930995e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49309967:	mov    rdx,rbx
    77db4930996a:	shr    rdx,0x10
    77db4930996e:	and    edx,0xc000
    77db49309974:	mov    rax,rbx
    77db49309977:	shr    rax,0x15
    77db4930997b:	and    eax,0x100
    77db49309980:	xor    eax,0x100
    77db49309985:	or     edx,eax
    77db49309987:	mov    rax,rbx
    77db4930998a:	shr    rax,0x1c
    77db4930998e:	and    eax,0x1
    77db49309991:	or     edx,eax
    77db49309993:	mov    QWORD PTR [rsp+0x10],rdx
    77db49309998:	add    rsp,0x8
    77db4930999c:	ret
    77db4930999d:	nop    DWORD PTR [rax]
    77db493099a0:	sub    rsp,0x8
    77db493099a4:	mov    QWORD PTR [r12+0x378],0x3
    77db493099b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db493099b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db493099bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db493099c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db493099c8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db493099ce:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db493099d4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db493099de:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db493099e8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db493099f2:	push   rdx
    77db493099f3:	push   rsi
    77db493099f4:	push   r10
    77db493099f6:	push   r11
    77db493099f8:	mov    rdx,QWORD PTR [rsp+0x30]
    77db493099fd:	mov    r10d,edx
    77db49309a00:	and    r10d,0xc000
    77db49309a07:	shl    r10d,0x10
    77db49309a0b:	mov    r11d,edx
    77db49309a0e:	and    r11d,0x100
    77db49309a15:	shl    r11d,0x15
    77db49309a19:	or     r10d,r11d
    77db49309a1c:	and    edx,0x1
    77db49309a1f:	shl    edx,0x1c
    77db49309a22:	or     r10d,edx
    77db49309a25:	btc    r10,0x1d
    77db49309a2a:	mov    r11d,0xf0000000
    77db49309a30:	and    r11,r10
    77db49309a33:	movabs rsi,0xffffffff0fffffff
    77db49309a3d:	and    rbx,rsi
    77db49309a40:	or     rbx,r11
    77db49309a43:	pop    r11
    77db49309a45:	pop    r10
    77db49309a47:	pop    rsi
    77db49309a48:	pop    rdx
    77db49309a49:	mov    QWORD PTR [r12+0x108],rbx
    77db49309a51:	stmxcsr DWORD PTR [r12-0x28]
    77db49309a57:	mov    r10d,DWORD PTR [r12-0x28]
    77db49309a5c:	test   r10d,0x3f
    77db49309a63:	je     0x77db49309a88
    77db49309a69:	mov    r11d,r10d
    77db49309a6c:	shr    r10d,1
    77db49309a6f:	and    r10d,0x1e
    77db49309a73:	and    r11d,0x1
    77db49309a77:	or     r10d,r11d
    77db49309a7a:	or     DWORD PTR [r12+0x314],r10d
    77db49309a82:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49309a88:	ldmxcsr DWORD PTR [r12-0x38]
    77db49309a8e:	lea    rdi,[rsp+0x110]
    77db49309a96:	lea    rsi,[rsp+0xf0]
    77db49309a9e:	lea    rdx,[rsp+0x100]
    77db49309aa6:	mov    ecx,0x14
    77db49309aab:	mov    r8d,0x0
    77db49309ab1:	lea    r9,[r12+0x314]
    77db49309ab9:	movabs r11,0x60ebc89f0650
    77db49309ac3:	call   r11
    77db49309ac6:	ldmxcsr DWORD PTR [r12-0x28]
    77db49309acc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49309ad2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49309ad8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49309ade:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49309ae4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49309aea:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49309af0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49309afa:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49309b04:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49309b0e:	mov    rbx,QWORD PTR [r12+0x108]
    77db49309b16:	mov    QWORD PTR [r12+0x378],0x2
    77db49309b22:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49309b2b:	mov    rdx,rbx
    77db49309b2e:	shr    rdx,0x10
    77db49309b32:	and    edx,0xc000
    77db49309b38:	mov    rax,rbx
    77db49309b3b:	shr    rax,0x15
    77db49309b3f:	and    eax,0x100
    77db49309b44:	xor    eax,0x100
    77db49309b49:	or     edx,eax
    77db49309b4b:	mov    rax,rbx
    77db49309b4e:	shr    rax,0x1c
    77db49309b52:	and    eax,0x1
    77db49309b55:	or     edx,eax
    77db49309b57:	mov    QWORD PTR [rsp+0x10],rdx
    77db49309b5c:	add    rsp,0x8
    77db49309b60:	ret
    77db49309b61:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49309b70:	sub    rsp,0x8
    77db49309b74:	mov    QWORD PTR [r12+0x378],0x3
    77db49309b80:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49309b86:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db49309b8c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49309b92:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49309b98:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db49309ba2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49309bac:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49309bb6:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49309bc0:	push   rdx
    77db49309bc1:	push   rsi
    77db49309bc2:	push   r10
    77db49309bc4:	push   r11
    77db49309bc6:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49309bcb:	mov    r10d,edx
    77db49309bce:	and    r10d,0xc000
    77db49309bd5:	shl    r10d,0x10
    77db49309bd9:	mov    r11d,edx
    77db49309bdc:	and    r11d,0x100
    77db49309be3:	shl    r11d,0x15
    77db49309be7:	or     r10d,r11d
    77db49309bea:	and    edx,0x1
    77db49309bed:	shl    edx,0x1c
    77db49309bf0:	or     r10d,edx
    77db49309bf3:	btc    r10,0x1d
    77db49309bf8:	mov    r11d,0xf0000000
    77db49309bfe:	and    r11,r10
    77db49309c01:	movabs rsi,0xffffffff0fffffff
    77db49309c0b:	and    rbx,rsi
    77db49309c0e:	or     rbx,r11
    77db49309c11:	pop    r11
    77db49309c13:	pop    r10
    77db49309c15:	pop    rsi
    77db49309c16:	pop    rdx
    77db49309c17:	mov    QWORD PTR [r12+0x108],rbx
    77db49309c1f:	stmxcsr DWORD PTR [r12-0x28]
    77db49309c25:	mov    r10d,DWORD PTR [r12-0x28]
    77db49309c2a:	test   r10d,0x3f
    77db49309c31:	je     0x77db49309c56
    77db49309c37:	mov    r11d,r10d
    77db49309c3a:	shr    r10d,1
    77db49309c3d:	and    r10d,0x1e
    77db49309c41:	and    r11d,0x1
    77db49309c45:	or     r10d,r11d
    77db49309c48:	or     DWORD PTR [r12+0x314],r10d
    77db49309c50:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49309c56:	ldmxcsr DWORD PTR [r12-0x38]
    77db49309c5c:	lea    rdi,[rsp+0x110]
    77db49309c64:	lea    rsi,[rsp+0xf0]
    77db49309c6c:	lea    rdx,[rsp+0x100]
    77db49309c74:	mov    ecx,0x14
    77db49309c79:	mov    r8d,0x0
    77db49309c7f:	lea    r9,[r12+0x314]
    77db49309c87:	movabs r11,0x60ebc89f0650
    77db49309c91:	call   r11
    77db49309c94:	ldmxcsr DWORD PTR [r12-0x28]
    77db49309c9a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49309ca0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49309ca6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49309cac:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db49309cb2:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db49309cbc:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49309cc6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49309cd0:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49309cda:	mov    rbx,QWORD PTR [r12+0x108]
    77db49309ce2:	mov    QWORD PTR [r12+0x378],0x2
    77db49309cee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49309cf7:	mov    rdx,rbx
    77db49309cfa:	shr    rdx,0x10
    77db49309cfe:	and    edx,0xc000
    77db49309d04:	mov    rax,rbx
    77db49309d07:	shr    rax,0x15
    77db49309d0b:	and    eax,0x100
    77db49309d10:	xor    eax,0x100
    77db49309d15:	or     edx,eax
    77db49309d17:	mov    rax,rbx
    77db49309d1a:	shr    rax,0x1c
    77db49309d1e:	and    eax,0x1
    77db49309d21:	or     edx,eax
    77db49309d23:	mov    QWORD PTR [rsp+0x10],rdx
    77db49309d28:	add    rsp,0x8
    77db49309d2c:	ret
    77db49309d2d:	nop    DWORD PTR [rax]
    77db49309d30:	sub    rsp,0x8
    77db49309d34:	mov    QWORD PTR [r12+0x378],0x3
    77db49309d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49309d46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db49309d4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49309d52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49309d58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49309d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db49309d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49309d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49309d7c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49309d86:	push   rdx
    77db49309d87:	push   rsi
    77db49309d88:	push   r10
    77db49309d8a:	push   r11
    77db49309d8c:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49309d91:	mov    r10d,edx
    77db49309d94:	and    r10d,0xc000
    77db49309d9b:	shl    r10d,0x10
    77db49309d9f:	mov    r11d,edx
    77db49309da2:	and    r11d,0x100
    77db49309da9:	shl    r11d,0x15
    77db49309dad:	or     r10d,r11d
    77db49309db0:	and    edx,0x1
    77db49309db3:	shl    edx,0x1c
    77db49309db6:	or     r10d,edx
    77db49309db9:	btc    r10,0x1d
    77db49309dbe:	mov    r11d,0xf0000000
    77db49309dc4:	and    r11,r10
    77db49309dc7:	movabs rsi,0xffffffff0fffffff
    77db49309dd1:	and    rbx,rsi
    77db49309dd4:	or     rbx,r11
    77db49309dd7:	pop    r11
    77db49309dd9:	pop    r10
    77db49309ddb:	pop    rsi
    77db49309ddc:	pop    rdx
    77db49309ddd:	mov    QWORD PTR [r12+0x108],rbx
    77db49309de5:	stmxcsr DWORD PTR [r12-0x28]
    77db49309deb:	mov    r10d,DWORD PTR [r12-0x28]
    77db49309df0:	test   r10d,0x3f
    77db49309df7:	je     0x77db49309e1c
    77db49309dfd:	mov    r11d,r10d
    77db49309e00:	shr    r10d,1
    77db49309e03:	and    r10d,0x1e
    77db49309e07:	and    r11d,0x1
    77db49309e0b:	or     r10d,r11d
    77db49309e0e:	or     DWORD PTR [r12+0x314],r10d
    77db49309e16:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49309e1c:	ldmxcsr DWORD PTR [r12-0x38]
    77db49309e22:	lea    rdi,[rsp+0x110]
    77db49309e2a:	lea    rsi,[rsp+0xf0]
    77db49309e32:	lea    rdx,[rsp+0x100]
    77db49309e3a:	mov    ecx,0x14
    77db49309e3f:	mov    r8d,0x0
    77db49309e45:	lea    r9,[r12+0x314]
    77db49309e4d:	movabs r11,0x60ebc89f0650
    77db49309e57:	call   r11
    77db49309e5a:	ldmxcsr DWORD PTR [r12-0x28]
    77db49309e60:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db49309e66:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db49309e6c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db49309e72:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db49309e78:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db49309e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db49309e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db49309e92:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db49309e9c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db49309ea6:	mov    rbx,QWORD PTR [r12+0x108]
    77db49309eae:	mov    QWORD PTR [r12+0x378],0x2
    77db49309eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db49309ec3:	mov    rdx,rbx
    77db49309ec6:	shr    rdx,0x10
    77db49309eca:	and    edx,0xc000
    77db49309ed0:	mov    rax,rbx
    77db49309ed3:	shr    rax,0x15
    77db49309ed7:	and    eax,0x100
    77db49309edc:	xor    eax,0x100
    77db49309ee1:	or     edx,eax
    77db49309ee3:	mov    rax,rbx
    77db49309ee6:	shr    rax,0x1c
    77db49309eea:	and    eax,0x1
    77db49309eed:	or     edx,eax
    77db49309eef:	mov    QWORD PTR [rsp+0x10],rdx
    77db49309ef4:	add    rsp,0x8
    77db49309ef8:	ret
    77db49309ef9:	nop    DWORD PTR [rax+0x0]
    77db49309f00:	sub    rsp,0x8
    77db49309f04:	mov    QWORD PTR [r12+0x378],0x3
    77db49309f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db49309f16:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db49309f1c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db49309f22:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db49309f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db49309f2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db49309f38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db49309f42:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db49309f4c:	push   rdx
    77db49309f4d:	push   rsi
    77db49309f4e:	push   r10
    77db49309f50:	push   r11
    77db49309f52:	mov    rdx,QWORD PTR [rsp+0x30]
    77db49309f57:	mov    r10d,edx
    77db49309f5a:	and    r10d,0xc000
    77db49309f61:	shl    r10d,0x10
    77db49309f65:	mov    r11d,edx
    77db49309f68:	and    r11d,0x100
    77db49309f6f:	shl    r11d,0x15
    77db49309f73:	or     r10d,r11d
    77db49309f76:	and    edx,0x1
    77db49309f79:	shl    edx,0x1c
    77db49309f7c:	or     r10d,edx
    77db49309f7f:	btc    r10,0x1d
    77db49309f84:	mov    r11d,0xf0000000
    77db49309f8a:	and    r11,r10
    77db49309f8d:	movabs rsi,0xffffffff0fffffff
    77db49309f97:	and    rbx,rsi
    77db49309f9a:	or     rbx,r11
    77db49309f9d:	pop    r11
    77db49309f9f:	pop    r10
    77db49309fa1:	pop    rsi
    77db49309fa2:	pop    rdx
    77db49309fa3:	mov    QWORD PTR [r12+0x108],rbx
    77db49309fab:	stmxcsr DWORD PTR [r12-0x28]
    77db49309fb1:	mov    r10d,DWORD PTR [r12-0x28]
    77db49309fb6:	test   r10d,0x3f
    77db49309fbd:	je     0x77db49309fe2
    77db49309fc3:	mov    r11d,r10d
    77db49309fc6:	shr    r10d,1
    77db49309fc9:	and    r10d,0x1e
    77db49309fcd:	and    r11d,0x1
    77db49309fd1:	or     r10d,r11d
    77db49309fd4:	or     DWORD PTR [r12+0x314],r10d
    77db49309fdc:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db49309fe2:	ldmxcsr DWORD PTR [r12-0x38]
    77db49309fe8:	lea    rdi,[rsp+0x110]
    77db49309ff0:	lea    rsi,[rsp+0xf0]
    77db49309ff8:	lea    rdx,[rsp+0x100]
    77db4930a000:	mov    ecx,0x56
    77db4930a005:	mov    r8d,0x0
    77db4930a00b:	lea    r9,[r12+0x314]
    77db4930a013:	movabs r11,0x60ebc89f0650
    77db4930a01d:	call   r11
    77db4930a020:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930a026:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930a02c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930a032:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930a038:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930a03e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930a044:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930a04e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db4930a058:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930a062:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930a06a:	mov    QWORD PTR [r12+0x378],0x2
    77db4930a076:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930a07f:	mov    rdx,rbx
    77db4930a082:	shr    rdx,0x10
    77db4930a086:	and    edx,0xc000
    77db4930a08c:	mov    rax,rbx
    77db4930a08f:	shr    rax,0x15
    77db4930a093:	and    eax,0x100
    77db4930a098:	xor    eax,0x100
    77db4930a09d:	or     edx,eax
    77db4930a09f:	mov    rax,rbx
    77db4930a0a2:	shr    rax,0x1c
    77db4930a0a6:	and    eax,0x1
    77db4930a0a9:	or     edx,eax
    77db4930a0ab:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930a0b0:	add    rsp,0x8
    77db4930a0b4:	ret
    77db4930a0b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db4930a0c0:	sub    rsp,0x8
    77db4930a0c4:	mov    QWORD PTR [r12+0x378],0x3
    77db4930a0d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930a0d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930a0dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930a0e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db4930a0e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db4930a0ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db4930a0f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930a102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db4930a10c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db4930a116:	push   rdx
    77db4930a117:	push   rsi
    77db4930a118:	push   r10
    77db4930a11a:	push   r11
    77db4930a11c:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930a121:	mov    r10d,edx
    77db4930a124:	and    r10d,0xc000
    77db4930a12b:	shl    r10d,0x10
    77db4930a12f:	mov    r11d,edx
    77db4930a132:	and    r11d,0x100
    77db4930a139:	shl    r11d,0x15
    77db4930a13d:	or     r10d,r11d
    77db4930a140:	and    edx,0x1
    77db4930a143:	shl    edx,0x1c
    77db4930a146:	or     r10d,edx
    77db4930a149:	btc    r10,0x1d
    77db4930a14e:	mov    r11d,0xf0000000
    77db4930a154:	and    r11,r10
    77db4930a157:	movabs rsi,0xffffffff0fffffff
    77db4930a161:	and    rbx,rsi
    77db4930a164:	or     rbx,r11
    77db4930a167:	pop    r11
    77db4930a169:	pop    r10
    77db4930a16b:	pop    rsi
    77db4930a16c:	pop    rdx
    77db4930a16d:	mov    QWORD PTR [r12+0x108],rbx
    77db4930a175:	stmxcsr DWORD PTR [r12-0x28]
    77db4930a17b:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930a180:	test   r10d,0x3f
    77db4930a187:	je     0x77db4930a1ac
    77db4930a18d:	mov    r11d,r10d
    77db4930a190:	shr    r10d,1
    77db4930a193:	and    r10d,0x1e
    77db4930a197:	and    r11d,0x1
    77db4930a19b:	or     r10d,r11d
    77db4930a19e:	or     DWORD PTR [r12+0x314],r10d
    77db4930a1a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930a1ac:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930a1b2:	lea    rdi,[rsp+0x110]
    77db4930a1ba:	lea    rsi,[rsp+0xf0]
    77db4930a1c2:	lea    rdx,[rsp+0x100]
    77db4930a1ca:	mov    ecx,0x56
    77db4930a1cf:	mov    r8d,0x0
    77db4930a1d5:	lea    r9,[r12+0x314]
    77db4930a1dd:	movabs r11,0x60ebc89f0650
    77db4930a1e7:	call   r11
    77db4930a1ea:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930a1f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930a1f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930a1fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930a202:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930a208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930a20e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db4930a218:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930a222:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db4930a22c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930a236:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930a23e:	mov    QWORD PTR [r12+0x378],0x2
    77db4930a24a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930a253:	mov    rdx,rbx
    77db4930a256:	shr    rdx,0x10
    77db4930a25a:	and    edx,0xc000
    77db4930a260:	mov    rax,rbx
    77db4930a263:	shr    rax,0x15
    77db4930a267:	and    eax,0x100
    77db4930a26c:	xor    eax,0x100
    77db4930a271:	or     edx,eax
    77db4930a273:	mov    rax,rbx
    77db4930a276:	shr    rax,0x1c
    77db4930a27a:	and    eax,0x1
    77db4930a27d:	or     edx,eax
    77db4930a27f:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930a284:	add    rsp,0x8
    77db4930a288:	ret
    77db4930a289:	nop    DWORD PTR [rax+0x0]
    77db4930a290:	sub    rsp,0x8
    77db4930a294:	mov    QWORD PTR [r12+0x378],0x3
    77db4930a2a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930a2a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930a2ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930a2b2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930a2b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db4930a2be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db4930a2c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930a2d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db4930a2dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db4930a2e6:	push   rdx
    77db4930a2e7:	push   rsi
    77db4930a2e8:	push   r10
    77db4930a2ea:	push   r11
    77db4930a2ec:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930a2f1:	mov    r10d,edx
    77db4930a2f4:	and    r10d,0xc000
    77db4930a2fb:	shl    r10d,0x10
    77db4930a2ff:	mov    r11d,edx
    77db4930a302:	and    r11d,0x100
    77db4930a309:	shl    r11d,0x15
    77db4930a30d:	or     r10d,r11d
    77db4930a310:	and    edx,0x1
    77db4930a313:	shl    edx,0x1c
    77db4930a316:	or     r10d,edx
    77db4930a319:	btc    r10,0x1d
    77db4930a31e:	mov    r11d,0xf0000000
    77db4930a324:	and    r11,r10
    77db4930a327:	movabs rsi,0xffffffff0fffffff
    77db4930a331:	and    rbx,rsi
    77db4930a334:	or     rbx,r11
    77db4930a337:	pop    r11
    77db4930a339:	pop    r10
    77db4930a33b:	pop    rsi
    77db4930a33c:	pop    rdx
    77db4930a33d:	mov    QWORD PTR [r12+0x108],rbx
    77db4930a345:	stmxcsr DWORD PTR [r12-0x28]
    77db4930a34b:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930a350:	test   r10d,0x3f
    77db4930a357:	je     0x77db4930a37c
    77db4930a35d:	mov    r11d,r10d
    77db4930a360:	shr    r10d,1
    77db4930a363:	and    r10d,0x1e
    77db4930a367:	and    r11d,0x1
    77db4930a36b:	or     r10d,r11d
    77db4930a36e:	or     DWORD PTR [r12+0x314],r10d
    77db4930a376:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930a37c:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930a382:	lea    rdi,[rsp+0x110]
    77db4930a38a:	lea    rsi,[rsp+0xf0]
    77db4930a392:	lea    rdx,[rsp+0x100]
    77db4930a39a:	mov    ecx,0x14
    77db4930a39f:	mov    r8d,0x0
    77db4930a3a5:	lea    r9,[r12+0x314]
    77db4930a3ad:	movabs r11,0x60ebc89f0650
    77db4930a3b7:	call   r11
    77db4930a3ba:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930a3c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930a3c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930a3cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930a3d2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930a3d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930a3de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db4930a3e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930a3f2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db4930a3fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930a406:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930a40e:	mov    QWORD PTR [r12+0x378],0x2
    77db4930a41a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930a423:	mov    rdx,rbx
    77db4930a426:	shr    rdx,0x10
    77db4930a42a:	and    edx,0xc000
    77db4930a430:	mov    rax,rbx
    77db4930a433:	shr    rax,0x15
    77db4930a437:	and    eax,0x100
    77db4930a43c:	xor    eax,0x100
    77db4930a441:	or     edx,eax
    77db4930a443:	mov    rax,rbx
    77db4930a446:	shr    rax,0x1c
    77db4930a44a:	and    eax,0x1
    77db4930a44d:	or     edx,eax
    77db4930a44f:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930a454:	add    rsp,0x8
    77db4930a458:	ret
    77db4930a459:	nop    DWORD PTR [rax+0x0]
    77db4930a460:	sub    rsp,0x8
    77db4930a464:	mov    QWORD PTR [r12+0x378],0x3
    77db4930a470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930a476:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930a47c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db4930a482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930a488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db4930a48e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db4930a498:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db4930a4a2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930a4ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db4930a4b6:	push   rdx
    77db4930a4b7:	push   rsi
    77db4930a4b8:	push   r10
    77db4930a4ba:	push   r11
    77db4930a4bc:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930a4c1:	mov    r10d,edx
    77db4930a4c4:	and    r10d,0xc000
    77db4930a4cb:	shl    r10d,0x10
    77db4930a4cf:	mov    r11d,edx
    77db4930a4d2:	and    r11d,0x100
    77db4930a4d9:	shl    r11d,0x15
    77db4930a4dd:	or     r10d,r11d
    77db4930a4e0:	and    edx,0x1
    77db4930a4e3:	shl    edx,0x1c
    77db4930a4e6:	or     r10d,edx
    77db4930a4e9:	btc    r10,0x1d
    77db4930a4ee:	mov    r11d,0xf0000000
    77db4930a4f4:	and    r11,r10
    77db4930a4f7:	movabs rsi,0xffffffff0fffffff
    77db4930a501:	and    rbx,rsi
    77db4930a504:	or     rbx,r11
    77db4930a507:	pop    r11
    77db4930a509:	pop    r10
    77db4930a50b:	pop    rsi
    77db4930a50c:	pop    rdx
    77db4930a50d:	mov    QWORD PTR [r12+0x108],rbx
    77db4930a515:	stmxcsr DWORD PTR [r12-0x28]
    77db4930a51b:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930a520:	test   r10d,0x3f
    77db4930a527:	je     0x77db4930a54c
    77db4930a52d:	mov    r11d,r10d
    77db4930a530:	shr    r10d,1
    77db4930a533:	and    r10d,0x1e
    77db4930a537:	and    r11d,0x1
    77db4930a53b:	or     r10d,r11d
    77db4930a53e:	or     DWORD PTR [r12+0x314],r10d
    77db4930a546:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930a54c:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930a552:	lea    rdi,[rsp+0x110]
    77db4930a55a:	lea    rsi,[rsp+0xf0]
    77db4930a562:	lea    rdx,[rsp+0x100]
    77db4930a56a:	mov    ecx,0x56
    77db4930a56f:	mov    r8d,0x0
    77db4930a575:	lea    r9,[r12+0x314]
    77db4930a57d:	movabs r11,0x60ebc89f0650
    77db4930a587:	call   r11
    77db4930a58a:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930a590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930a596:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930a59c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930a5a2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930a5a8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930a5ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db4930a5b8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930a5c2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930a5cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930a5d6:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930a5de:	mov    QWORD PTR [r12+0x378],0x2
    77db4930a5ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930a5f3:	mov    rdx,rbx
    77db4930a5f6:	shr    rdx,0x10
    77db4930a5fa:	and    edx,0xc000
    77db4930a600:	mov    rax,rbx
    77db4930a603:	shr    rax,0x15
    77db4930a607:	and    eax,0x100
    77db4930a60c:	xor    eax,0x100
    77db4930a611:	or     edx,eax
    77db4930a613:	mov    rax,rbx
    77db4930a616:	shr    rax,0x1c
    77db4930a61a:	and    eax,0x1
    77db4930a61d:	or     edx,eax
    77db4930a61f:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930a624:	add    rsp,0x8
    77db4930a628:	ret
    77db4930a629:	nop    DWORD PTR [rax+0x0]
    77db4930a630:	sub    rsp,0x8
    77db4930a634:	mov    QWORD PTR [r12+0x378],0x3
    77db4930a640:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930a646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930a64c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db4930a652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930a658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db4930a65e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db4930a668:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db4930a672:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930a67c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db4930a686:	push   rdx
    77db4930a687:	push   rsi
    77db4930a688:	push   r10
    77db4930a68a:	push   r11
    77db4930a68c:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930a691:	mov    r10d,edx
    77db4930a694:	and    r10d,0xc000
    77db4930a69b:	shl    r10d,0x10
    77db4930a69f:	mov    r11d,edx
    77db4930a6a2:	and    r11d,0x100
    77db4930a6a9:	shl    r11d,0x15
    77db4930a6ad:	or     r10d,r11d
    77db4930a6b0:	and    edx,0x1
    77db4930a6b3:	shl    edx,0x1c
    77db4930a6b6:	or     r10d,edx
    77db4930a6b9:	btc    r10,0x1d
    77db4930a6be:	mov    r11d,0xf0000000
    77db4930a6c4:	and    r11,r10
    77db4930a6c7:	movabs rsi,0xffffffff0fffffff
    77db4930a6d1:	and    rbx,rsi
    77db4930a6d4:	or     rbx,r11
    77db4930a6d7:	pop    r11
    77db4930a6d9:	pop    r10
    77db4930a6db:	pop    rsi
    77db4930a6dc:	pop    rdx
    77db4930a6dd:	mov    QWORD PTR [r12+0x108],rbx
    77db4930a6e5:	stmxcsr DWORD PTR [r12-0x28]
    77db4930a6eb:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930a6f0:	test   r10d,0x3f
    77db4930a6f7:	je     0x77db4930a71c
    77db4930a6fd:	mov    r11d,r10d
    77db4930a700:	shr    r10d,1
    77db4930a703:	and    r10d,0x1e
    77db4930a707:	and    r11d,0x1
    77db4930a70b:	or     r10d,r11d
    77db4930a70e:	or     DWORD PTR [r12+0x314],r10d
    77db4930a716:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930a71c:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930a722:	lea    rdi,[rsp+0x110]
    77db4930a72a:	lea    rsi,[rsp+0xf0]
    77db4930a732:	lea    rdx,[rsp+0x100]
    77db4930a73a:	mov    ecx,0x14
    77db4930a73f:	mov    r8d,0x0
    77db4930a745:	lea    r9,[r12+0x314]
    77db4930a74d:	movabs r11,0x60ebc89f0650
    77db4930a757:	call   r11
    77db4930a75a:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930a760:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930a766:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930a76c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930a772:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930a778:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930a77e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db4930a788:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930a792:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930a79c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930a7a6:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930a7ae:	mov    QWORD PTR [r12+0x378],0x2
    77db4930a7ba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930a7c3:	mov    rdx,rbx
    77db4930a7c6:	shr    rdx,0x10
    77db4930a7ca:	and    edx,0xc000
    77db4930a7d0:	mov    rax,rbx
    77db4930a7d3:	shr    rax,0x15
    77db4930a7d7:	and    eax,0x100
    77db4930a7dc:	xor    eax,0x100
    77db4930a7e1:	or     edx,eax
    77db4930a7e3:	mov    rax,rbx
    77db4930a7e6:	shr    rax,0x1c
    77db4930a7ea:	and    eax,0x1
    77db4930a7ed:	or     edx,eax
    77db4930a7ef:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930a7f4:	add    rsp,0x8
    77db4930a7f8:	ret
    77db4930a7f9:	nop    DWORD PTR [rax+0x0]
    77db4930a800:	sub    rsp,0x8
    77db4930a804:	mov    QWORD PTR [r12+0x378],0x3
    77db4930a810:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930a816:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930a81c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db4930a822:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930a828:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db4930a82e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db4930a838:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930a842:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db4930a84c:	push   rdx
    77db4930a84d:	push   rsi
    77db4930a84e:	push   r10
    77db4930a850:	push   r11
    77db4930a852:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930a857:	mov    r10d,edx
    77db4930a85a:	and    r10d,0xc000
    77db4930a861:	shl    r10d,0x10
    77db4930a865:	mov    r11d,edx
    77db4930a868:	and    r11d,0x100
    77db4930a86f:	shl    r11d,0x15
    77db4930a873:	or     r10d,r11d
    77db4930a876:	and    edx,0x1
    77db4930a879:	shl    edx,0x1c
    77db4930a87c:	or     r10d,edx
    77db4930a87f:	btc    r10,0x1d
    77db4930a884:	mov    r11d,0xf0000000
    77db4930a88a:	and    r11,r10
    77db4930a88d:	movabs rsi,0xffffffff0fffffff
    77db4930a897:	and    rbx,rsi
    77db4930a89a:	or     rbx,r11
    77db4930a89d:	pop    r11
    77db4930a89f:	pop    r10
    77db4930a8a1:	pop    rsi
    77db4930a8a2:	pop    rdx
    77db4930a8a3:	mov    QWORD PTR [r12+0x108],rbx
    77db4930a8ab:	stmxcsr DWORD PTR [r12-0x28]
    77db4930a8b1:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930a8b6:	test   r10d,0x3f
    77db4930a8bd:	je     0x77db4930a8e2
    77db4930a8c3:	mov    r11d,r10d
    77db4930a8c6:	shr    r10d,1
    77db4930a8c9:	and    r10d,0x1e
    77db4930a8cd:	and    r11d,0x1
    77db4930a8d1:	or     r10d,r11d
    77db4930a8d4:	or     DWORD PTR [r12+0x314],r10d
    77db4930a8dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930a8e2:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930a8e8:	lea    rdi,[rsp+0x110]
    77db4930a8f0:	lea    rsi,[rsp+0xf0]
    77db4930a8f8:	lea    rdx,[rsp+0x100]
    77db4930a900:	mov    ecx,0x14
    77db4930a905:	mov    r8d,0x0
    77db4930a90b:	lea    r9,[r12+0x314]
    77db4930a913:	movabs r11,0x60ebc89f0650
    77db4930a91d:	call   r11
    77db4930a920:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930a926:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930a92c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930a932:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930a938:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930a93e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930a944:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930a94e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930a958:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db4930a962:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930a96a:	mov    QWORD PTR [r12+0x378],0x2
    77db4930a976:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930a97f:	mov    rdx,rbx
    77db4930a982:	shr    rdx,0x10
    77db4930a986:	and    edx,0xc000
    77db4930a98c:	mov    rax,rbx
    77db4930a98f:	shr    rax,0x15
    77db4930a993:	and    eax,0x100
    77db4930a998:	xor    eax,0x100
    77db4930a99d:	or     edx,eax
    77db4930a99f:	mov    rax,rbx
    77db4930a9a2:	shr    rax,0x1c
    77db4930a9a6:	and    eax,0x1
    77db4930a9a9:	or     edx,eax
    77db4930a9ab:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930a9b0:	add    rsp,0x8
    77db4930a9b4:	ret
    77db4930a9b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db4930a9c0:	sub    rsp,0x8
    77db4930a9c4:	mov    QWORD PTR [r12+0x378],0x3
    77db4930a9d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930a9d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930a9dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930a9e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db4930a9e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930a9ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db4930a9f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930aa02:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db4930aa0c:	push   rdx
    77db4930aa0d:	push   rsi
    77db4930aa0e:	push   r10
    77db4930aa10:	push   r11
    77db4930aa12:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930aa17:	mov    r10d,edx
    77db4930aa1a:	and    r10d,0xc000
    77db4930aa21:	shl    r10d,0x10
    77db4930aa25:	mov    r11d,edx
    77db4930aa28:	and    r11d,0x100
    77db4930aa2f:	shl    r11d,0x15
    77db4930aa33:	or     r10d,r11d
    77db4930aa36:	and    edx,0x1
    77db4930aa39:	shl    edx,0x1c
    77db4930aa3c:	or     r10d,edx
    77db4930aa3f:	btc    r10,0x1d
    77db4930aa44:	mov    r11d,0xf0000000
    77db4930aa4a:	and    r11,r10
    77db4930aa4d:	movabs rsi,0xffffffff0fffffff
    77db4930aa57:	and    rbx,rsi
    77db4930aa5a:	or     rbx,r11
    77db4930aa5d:	pop    r11
    77db4930aa5f:	pop    r10
    77db4930aa61:	pop    rsi
    77db4930aa62:	pop    rdx
    77db4930aa63:	mov    QWORD PTR [r12+0x108],rbx
    77db4930aa6b:	stmxcsr DWORD PTR [r12-0x28]
    77db4930aa71:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930aa76:	test   r10d,0x3f
    77db4930aa7d:	je     0x77db4930aaa2
    77db4930aa83:	mov    r11d,r10d
    77db4930aa86:	shr    r10d,1
    77db4930aa89:	and    r10d,0x1e
    77db4930aa8d:	and    r11d,0x1
    77db4930aa91:	or     r10d,r11d
    77db4930aa94:	or     DWORD PTR [r12+0x314],r10d
    77db4930aa9c:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930aaa2:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930aaa8:	lea    rdi,[rsp+0x110]
    77db4930aab0:	lea    rsi,[rsp+0xf0]
    77db4930aab8:	lea    rdx,[rsp+0x100]
    77db4930aac0:	mov    ecx,0x14
    77db4930aac5:	mov    r8d,0x0
    77db4930aacb:	lea    r9,[r12+0x314]
    77db4930aad3:	movabs r11,0x60ebc89f0650
    77db4930aadd:	call   r11
    77db4930aae0:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930aae6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930aaec:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930aaf2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930aaf8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930aafe:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930ab04:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930ab0e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930ab18:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db4930ab22:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930ab2a:	mov    QWORD PTR [r12+0x378],0x2
    77db4930ab36:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930ab3f:	mov    rdx,rbx
    77db4930ab42:	shr    rdx,0x10
    77db4930ab46:	and    edx,0xc000
    77db4930ab4c:	mov    rax,rbx
    77db4930ab4f:	shr    rax,0x15
    77db4930ab53:	and    eax,0x100
    77db4930ab58:	xor    eax,0x100
    77db4930ab5d:	or     edx,eax
    77db4930ab5f:	mov    rax,rbx
    77db4930ab62:	shr    rax,0x1c
    77db4930ab66:	and    eax,0x1
    77db4930ab69:	or     edx,eax
    77db4930ab6b:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930ab70:	add    rsp,0x8
    77db4930ab74:	ret
    77db4930ab75:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db4930ab80:	sub    rsp,0x8
    77db4930ab84:	mov    QWORD PTR [r12+0x378],0x3
    77db4930ab90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930ab96:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930ab9c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930aba2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db4930aba8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930abae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db4930abb4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930abbe:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db4930abc8:	push   rdx
    77db4930abc9:	push   rsi
    77db4930abca:	push   r10
    77db4930abcc:	push   r11
    77db4930abce:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930abd3:	mov    r10d,edx
    77db4930abd6:	and    r10d,0xc000
    77db4930abdd:	shl    r10d,0x10
    77db4930abe1:	mov    r11d,edx
    77db4930abe4:	and    r11d,0x100
    77db4930abeb:	shl    r11d,0x15
    77db4930abef:	or     r10d,r11d
    77db4930abf2:	and    edx,0x1
    77db4930abf5:	shl    edx,0x1c
    77db4930abf8:	or     r10d,edx
    77db4930abfb:	btc    r10,0x1d
    77db4930ac00:	mov    r11d,0xf0000000
    77db4930ac06:	and    r11,r10
    77db4930ac09:	movabs rsi,0xffffffff0fffffff
    77db4930ac13:	and    rbx,rsi
    77db4930ac16:	or     rbx,r11
    77db4930ac19:	pop    r11
    77db4930ac1b:	pop    r10
    77db4930ac1d:	pop    rsi
    77db4930ac1e:	pop    rdx
    77db4930ac1f:	mov    QWORD PTR [r12+0x108],rbx
    77db4930ac27:	stmxcsr DWORD PTR [r12-0x28]
    77db4930ac2d:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930ac32:	test   r10d,0x3f
    77db4930ac39:	je     0x77db4930ac5e
    77db4930ac3f:	mov    r11d,r10d
    77db4930ac42:	shr    r10d,1
    77db4930ac45:	and    r10d,0x1e
    77db4930ac49:	and    r11d,0x1
    77db4930ac4d:	or     r10d,r11d
    77db4930ac50:	or     DWORD PTR [r12+0x314],r10d
    77db4930ac58:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930ac5e:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930ac64:	lea    rdi,[rsp+0x110]
    77db4930ac6c:	lea    rsi,[rsp+0xf0]
    77db4930ac74:	lea    rdx,[rsp+0x100]
    77db4930ac7c:	mov    ecx,0x56
    77db4930ac81:	mov    r8d,0x0
    77db4930ac87:	lea    r9,[r12+0x314]
    77db4930ac8f:	movabs r11,0x60ebc89f0650
    77db4930ac99:	call   r11
    77db4930ac9c:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930aca2:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930aca8:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930acae:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930acb4:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930acba:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930acc0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930acc6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930acd0:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db4930acda:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930ace2:	mov    QWORD PTR [r12+0x378],0x2
    77db4930acee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930acf7:	mov    rdx,rbx
    77db4930acfa:	shr    rdx,0x10
    77db4930acfe:	and    edx,0xc000
    77db4930ad04:	mov    rax,rbx
    77db4930ad07:	shr    rax,0x15
    77db4930ad0b:	and    eax,0x100
    77db4930ad10:	xor    eax,0x100
    77db4930ad15:	or     edx,eax
    77db4930ad17:	mov    rax,rbx
    77db4930ad1a:	shr    rax,0x1c
    77db4930ad1e:	and    eax,0x1
    77db4930ad21:	or     edx,eax
    77db4930ad23:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930ad28:	add    rsp,0x8
    77db4930ad2c:	ret
    77db4930ad2d:	nop    DWORD PTR [rax]
    77db4930ad30:	sub    rsp,0x8
    77db4930ad34:	mov    QWORD PTR [r12+0x378],0x3
    77db4930ad40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930ad46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930ad4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930ad52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db4930ad58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db4930ad5e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db4930ad68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930ad72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db4930ad7c:	push   rdx
    77db4930ad7d:	push   rsi
    77db4930ad7e:	push   r10
    77db4930ad80:	push   r11
    77db4930ad82:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930ad87:	mov    r10d,edx
    77db4930ad8a:	and    r10d,0xc000
    77db4930ad91:	shl    r10d,0x10
    77db4930ad95:	mov    r11d,edx
    77db4930ad98:	and    r11d,0x100
    77db4930ad9f:	shl    r11d,0x15
    77db4930ada3:	or     r10d,r11d
    77db4930ada6:	and    edx,0x1
    77db4930ada9:	shl    edx,0x1c
    77db4930adac:	or     r10d,edx
    77db4930adaf:	btc    r10,0x1d
    77db4930adb4:	mov    r11d,0xf0000000
    77db4930adba:	and    r11,r10
    77db4930adbd:	movabs rsi,0xffffffff0fffffff
    77db4930adc7:	and    rbx,rsi
    77db4930adca:	or     rbx,r11
    77db4930adcd:	pop    r11
    77db4930adcf:	pop    r10
    77db4930add1:	pop    rsi
    77db4930add2:	pop    rdx
    77db4930add3:	mov    QWORD PTR [r12+0x108],rbx
    77db4930addb:	stmxcsr DWORD PTR [r12-0x28]
    77db4930ade1:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930ade6:	test   r10d,0x3f
    77db4930aded:	je     0x77db4930ae12
    77db4930adf3:	mov    r11d,r10d
    77db4930adf6:	shr    r10d,1
    77db4930adf9:	and    r10d,0x1e
    77db4930adfd:	and    r11d,0x1
    77db4930ae01:	or     r10d,r11d
    77db4930ae04:	or     DWORD PTR [r12+0x314],r10d
    77db4930ae0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930ae12:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930ae18:	lea    rdi,[rsp+0x110]
    77db4930ae20:	lea    rsi,[rsp+0xf0]
    77db4930ae28:	lea    rdx,[rsp+0x100]
    77db4930ae30:	mov    ecx,0x56
    77db4930ae35:	mov    r8d,0x0
    77db4930ae3b:	lea    r9,[r12+0x314]
    77db4930ae43:	movabs r11,0x60ebc89f0650
    77db4930ae4d:	call   r11
    77db4930ae50:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930ae56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930ae5c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930ae62:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930ae68:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930ae6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930ae74:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db4930ae7e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930ae88:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db4930ae92:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930ae9a:	mov    QWORD PTR [r12+0x378],0x2
    77db4930aea6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930aeaf:	mov    rdx,rbx
    77db4930aeb2:	shr    rdx,0x10
    77db4930aeb6:	and    edx,0xc000
    77db4930aebc:	mov    rax,rbx
    77db4930aebf:	shr    rax,0x15
    77db4930aec3:	and    eax,0x100
    77db4930aec8:	xor    eax,0x100
    77db4930aecd:	or     edx,eax
    77db4930aecf:	mov    rax,rbx
    77db4930aed2:	shr    rax,0x1c
    77db4930aed6:	and    eax,0x1
    77db4930aed9:	or     edx,eax
    77db4930aedb:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930aee0:	add    rsp,0x8
    77db4930aee4:	ret
    77db4930aee5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db4930aef0:	sub    rsp,0x8
    77db4930aef4:	mov    QWORD PTR [r12+0x378],0x3
    77db4930af00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930af06:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930af0c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930af12:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db4930af18:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930af1e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db4930af24:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db4930af2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930af38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    77db4930af42:	push   rdx
    77db4930af43:	push   rsi
    77db4930af44:	push   r10
    77db4930af46:	push   r11
    77db4930af48:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930af4d:	mov    r10d,edx
    77db4930af50:	and    r10d,0xc000
    77db4930af57:	shl    r10d,0x10
    77db4930af5b:	mov    r11d,edx
    77db4930af5e:	and    r11d,0x100
    77db4930af65:	shl    r11d,0x15
    77db4930af69:	or     r10d,r11d
    77db4930af6c:	and    edx,0x1
    77db4930af6f:	shl    edx,0x1c
    77db4930af72:	or     r10d,edx
    77db4930af75:	btc    r10,0x1d
    77db4930af7a:	mov    r11d,0xf0000000
    77db4930af80:	and    r11,r10
    77db4930af83:	movabs rsi,0xffffffff0fffffff
    77db4930af8d:	and    rbx,rsi
    77db4930af90:	or     rbx,r11
    77db4930af93:	pop    r11
    77db4930af95:	pop    r10
    77db4930af97:	pop    rsi
    77db4930af98:	pop    rdx
    77db4930af99:	mov    QWORD PTR [r12+0x108],rbx
    77db4930afa1:	stmxcsr DWORD PTR [r12-0x28]
    77db4930afa7:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930afac:	test   r10d,0x3f
    77db4930afb3:	je     0x77db4930afd8
    77db4930afb9:	mov    r11d,r10d
    77db4930afbc:	shr    r10d,1
    77db4930afbf:	and    r10d,0x1e
    77db4930afc3:	and    r11d,0x1
    77db4930afc7:	or     r10d,r11d
    77db4930afca:	or     DWORD PTR [r12+0x314],r10d
    77db4930afd2:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930afd8:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930afde:	lea    rdi,[rsp+0x110]
    77db4930afe6:	lea    rsi,[rsp+0xf0]
    77db4930afee:	lea    rdx,[rsp+0x100]
    77db4930aff6:	mov    ecx,0x14
    77db4930affb:	mov    r8d,0x0
    77db4930b001:	lea    r9,[r12+0x314]
    77db4930b009:	movabs r11,0x60ebc89f0650
    77db4930b013:	call   r11
    77db4930b016:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930b01c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930b022:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930b028:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930b02e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930b034:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930b03a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930b040:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db4930b04a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930b054:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    77db4930b05e:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930b066:	mov    QWORD PTR [r12+0x378],0x2
    77db4930b072:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930b07b:	mov    rdx,rbx
    77db4930b07e:	shr    rdx,0x10
    77db4930b082:	and    edx,0xc000
    77db4930b088:	mov    rax,rbx
    77db4930b08b:	shr    rax,0x15
    77db4930b08f:	and    eax,0x100
    77db4930b094:	xor    eax,0x100
    77db4930b099:	or     edx,eax
    77db4930b09b:	mov    rax,rbx
    77db4930b09e:	shr    rax,0x1c
    77db4930b0a2:	and    eax,0x1
    77db4930b0a5:	or     edx,eax
    77db4930b0a7:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930b0ac:	add    rsp,0x8
    77db4930b0b0:	ret
    77db4930b0b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db4930b0c0:	sub    rsp,0x8
    77db4930b0c4:	mov    QWORD PTR [r12+0x378],0x3
    77db4930b0d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930b0d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930b0dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db4930b0e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930b0e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db4930b0ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db4930b0f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db4930b102:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930b10c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db4930b116:	push   rdx
    77db4930b117:	push   rsi
    77db4930b118:	push   r10
    77db4930b11a:	push   r11
    77db4930b11c:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930b121:	mov    r10d,edx
    77db4930b124:	and    r10d,0xc000
    77db4930b12b:	shl    r10d,0x10
    77db4930b12f:	mov    r11d,edx
    77db4930b132:	and    r11d,0x100
    77db4930b139:	shl    r11d,0x15
    77db4930b13d:	or     r10d,r11d
    77db4930b140:	and    edx,0x1
    77db4930b143:	shl    edx,0x1c
    77db4930b146:	or     r10d,edx
    77db4930b149:	btc    r10,0x1d
    77db4930b14e:	mov    r11d,0xf0000000
    77db4930b154:	and    r11,r10
    77db4930b157:	movabs rsi,0xffffffff0fffffff
    77db4930b161:	and    rbx,rsi
    77db4930b164:	or     rbx,r11
    77db4930b167:	pop    r11
    77db4930b169:	pop    r10
    77db4930b16b:	pop    rsi
    77db4930b16c:	pop    rdx
    77db4930b16d:	mov    QWORD PTR [r12+0x108],rbx
    77db4930b175:	stmxcsr DWORD PTR [r12-0x28]
    77db4930b17b:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930b180:	test   r10d,0x3f
    77db4930b187:	je     0x77db4930b1ac
    77db4930b18d:	mov    r11d,r10d
    77db4930b190:	shr    r10d,1
    77db4930b193:	and    r10d,0x1e
    77db4930b197:	and    r11d,0x1
    77db4930b19b:	or     r10d,r11d
    77db4930b19e:	or     DWORD PTR [r12+0x314],r10d
    77db4930b1a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930b1ac:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930b1b2:	lea    rdi,[rsp+0x110]
    77db4930b1ba:	lea    rsi,[rsp+0xf0]
    77db4930b1c2:	lea    rdx,[rsp+0x100]
    77db4930b1ca:	mov    ecx,0x56
    77db4930b1cf:	mov    r8d,0x0
    77db4930b1d5:	lea    r9,[r12+0x314]
    77db4930b1dd:	movabs r11,0x60ebc89f0650
    77db4930b1e7:	call   r11
    77db4930b1ea:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930b1f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930b1f6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930b1fc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930b202:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930b208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930b20e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db4930b218:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930b222:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930b22c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930b236:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930b23e:	mov    QWORD PTR [r12+0x378],0x2
    77db4930b24a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930b253:	mov    rdx,rbx
    77db4930b256:	shr    rdx,0x10
    77db4930b25a:	and    edx,0xc000
    77db4930b260:	mov    rax,rbx
    77db4930b263:	shr    rax,0x15
    77db4930b267:	and    eax,0x100
    77db4930b26c:	xor    eax,0x100
    77db4930b271:	or     edx,eax
    77db4930b273:	mov    rax,rbx
    77db4930b276:	shr    rax,0x1c
    77db4930b27a:	and    eax,0x1
    77db4930b27d:	or     edx,eax
    77db4930b27f:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930b284:	add    rsp,0x8
    77db4930b288:	ret
    77db4930b289:	nop    DWORD PTR [rax+0x0]
    77db4930b290:	sub    rsp,0x8
    77db4930b294:	mov    QWORD PTR [r12+0x378],0x3
    77db4930b2a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930b2a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930b2ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930b2b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db4930b2b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930b2be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db4930b2c4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    77db4930b2ce:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db4930b2d8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db4930b2e2:	push   rdx
    77db4930b2e3:	push   rsi
    77db4930b2e4:	push   r10
    77db4930b2e6:	push   r11
    77db4930b2e8:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930b2ed:	mov    r10d,edx
    77db4930b2f0:	and    r10d,0xc000
    77db4930b2f7:	shl    r10d,0x10
    77db4930b2fb:	mov    r11d,edx
    77db4930b2fe:	and    r11d,0x100
    77db4930b305:	shl    r11d,0x15
    77db4930b309:	or     r10d,r11d
    77db4930b30c:	and    edx,0x1
    77db4930b30f:	shl    edx,0x1c
    77db4930b312:	or     r10d,edx
    77db4930b315:	btc    r10,0x1d
    77db4930b31a:	mov    r11d,0xf0000000
    77db4930b320:	and    r11,r10
    77db4930b323:	movabs rsi,0xffffffff0fffffff
    77db4930b32d:	and    rbx,rsi
    77db4930b330:	or     rbx,r11
    77db4930b333:	pop    r11
    77db4930b335:	pop    r10
    77db4930b337:	pop    rsi
    77db4930b338:	pop    rdx
    77db4930b339:	mov    QWORD PTR [r12+0x108],rbx
    77db4930b341:	stmxcsr DWORD PTR [r12-0x28]
    77db4930b347:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930b34c:	test   r10d,0x3f
    77db4930b353:	je     0x77db4930b378
    77db4930b359:	mov    r11d,r10d
    77db4930b35c:	shr    r10d,1
    77db4930b35f:	and    r10d,0x1e
    77db4930b363:	and    r11d,0x1
    77db4930b367:	or     r10d,r11d
    77db4930b36a:	or     DWORD PTR [r12+0x314],r10d
    77db4930b372:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930b378:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930b37e:	lea    rdi,[rsp+0x110]
    77db4930b386:	lea    rsi,[rsp+0xf0]
    77db4930b38e:	lea    rdx,[rsp+0x100]
    77db4930b396:	mov    ecx,0x56
    77db4930b39b:	mov    r8d,0x0
    77db4930b3a1:	lea    r9,[r12+0x314]
    77db4930b3a9:	movabs r11,0x60ebc89f0650
    77db4930b3b3:	call   r11
    77db4930b3b6:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930b3bc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930b3c2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930b3c8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930b3ce:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930b3d4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930b3da:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930b3e0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    77db4930b3ea:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930b3f4:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930b3fe:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930b406:	mov    QWORD PTR [r12+0x378],0x2
    77db4930b412:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930b41b:	mov    rdx,rbx
    77db4930b41e:	shr    rdx,0x10
    77db4930b422:	and    edx,0xc000
    77db4930b428:	mov    rax,rbx
    77db4930b42b:	shr    rax,0x15
    77db4930b42f:	and    eax,0x100
    77db4930b434:	xor    eax,0x100
    77db4930b439:	or     edx,eax
    77db4930b43b:	mov    rax,rbx
    77db4930b43e:	shr    rax,0x1c
    77db4930b442:	and    eax,0x1
    77db4930b445:	or     edx,eax
    77db4930b447:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930b44c:	add    rsp,0x8
    77db4930b450:	ret
    77db4930b451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db4930b460:	sub    rsp,0x8
    77db4930b464:	mov    QWORD PTR [r12+0x378],0x3
    77db4930b470:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930b476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930b47c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    77db4930b482:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    77db4930b488:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db4930b492:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930b49c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db4930b4a6:	push   rdx
    77db4930b4a7:	push   rsi
    77db4930b4a8:	push   r10
    77db4930b4aa:	push   r11
    77db4930b4ac:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930b4b1:	mov    r10d,edx
    77db4930b4b4:	and    r10d,0xc000
    77db4930b4bb:	shl    r10d,0x10
    77db4930b4bf:	mov    r11d,edx
    77db4930b4c2:	and    r11d,0x100
    77db4930b4c9:	shl    r11d,0x15
    77db4930b4cd:	or     r10d,r11d
    77db4930b4d0:	and    edx,0x1
    77db4930b4d3:	shl    edx,0x1c
    77db4930b4d6:	or     r10d,edx
    77db4930b4d9:	btc    r10,0x1d
    77db4930b4de:	mov    r11d,0xf0000000
    77db4930b4e4:	and    r11,r10
    77db4930b4e7:	movabs rsi,0xffffffff0fffffff
    77db4930b4f1:	and    rbx,rsi
    77db4930b4f4:	or     rbx,r11
    77db4930b4f7:	pop    r11
    77db4930b4f9:	pop    r10
    77db4930b4fb:	pop    rsi
    77db4930b4fc:	pop    rdx
    77db4930b4fd:	mov    QWORD PTR [r12+0x108],rbx
    77db4930b505:	stmxcsr DWORD PTR [r12-0x28]
    77db4930b50b:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930b510:	test   r10d,0x3f
    77db4930b517:	je     0x77db4930b53c
    77db4930b51d:	mov    r11d,r10d
    77db4930b520:	shr    r10d,1
    77db4930b523:	and    r10d,0x1e
    77db4930b527:	and    r11d,0x1
    77db4930b52b:	or     r10d,r11d
    77db4930b52e:	or     DWORD PTR [r12+0x314],r10d
    77db4930b536:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930b53c:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930b542:	lea    rdi,[rsp+0x110]
    77db4930b54a:	lea    rsi,[rsp+0xf0]
    77db4930b552:	lea    rdx,[rsp+0x100]
    77db4930b55a:	mov    ecx,0x14
    77db4930b55f:	mov    r8d,0x0
    77db4930b565:	lea    r9,[r12+0x314]
    77db4930b56d:	movabs r11,0x60ebc89f0650
    77db4930b577:	call   r11
    77db4930b57a:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930b580:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930b586:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930b58c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    77db4930b592:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    77db4930b598:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930b5a2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930b5ac:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930b5b6:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930b5be:	mov    QWORD PTR [r12+0x378],0x2
    77db4930b5ca:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930b5d3:	mov    rdx,rbx
    77db4930b5d6:	shr    rdx,0x10
    77db4930b5da:	and    edx,0xc000
    77db4930b5e0:	mov    rax,rbx
    77db4930b5e3:	shr    rax,0x15
    77db4930b5e7:	and    eax,0x100
    77db4930b5ec:	xor    eax,0x100
    77db4930b5f1:	or     edx,eax
    77db4930b5f3:	mov    rax,rbx
    77db4930b5f6:	shr    rax,0x1c
    77db4930b5fa:	and    eax,0x1
    77db4930b5fd:	or     edx,eax
    77db4930b5ff:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930b604:	add    rsp,0x8
    77db4930b608:	ret
    77db4930b609:	nop    DWORD PTR [rax+0x0]
    77db4930b610:	sub    rsp,0x8
    77db4930b614:	mov    QWORD PTR [r12+0x378],0x3
    77db4930b620:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930b626:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930b62c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930b632:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    77db4930b63c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930b646:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db4930b650:	push   rdx
    77db4930b651:	push   rsi
    77db4930b652:	push   r10
    77db4930b654:	push   r11
    77db4930b656:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930b65b:	mov    r10d,edx
    77db4930b65e:	and    r10d,0xc000
    77db4930b665:	shl    r10d,0x10
    77db4930b669:	mov    r11d,edx
    77db4930b66c:	and    r11d,0x100
    77db4930b673:	shl    r11d,0x15
    77db4930b677:	or     r10d,r11d
    77db4930b67a:	and    edx,0x1
    77db4930b67d:	shl    edx,0x1c
    77db4930b680:	or     r10d,edx
    77db4930b683:	btc    r10,0x1d
    77db4930b688:	mov    r11d,0xf0000000
    77db4930b68e:	and    r11,r10
    77db4930b691:	movabs rsi,0xffffffff0fffffff
    77db4930b69b:	and    rbx,rsi
    77db4930b69e:	or     rbx,r11
    77db4930b6a1:	pop    r11
    77db4930b6a3:	pop    r10
    77db4930b6a5:	pop    rsi
    77db4930b6a6:	pop    rdx
    77db4930b6a7:	mov    QWORD PTR [r12+0x108],rbx
    77db4930b6af:	stmxcsr DWORD PTR [r12-0x28]
    77db4930b6b5:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930b6ba:	test   r10d,0x3f
    77db4930b6c1:	je     0x77db4930b6e6
    77db4930b6c7:	mov    r11d,r10d
    77db4930b6ca:	shr    r10d,1
    77db4930b6cd:	and    r10d,0x1e
    77db4930b6d1:	and    r11d,0x1
    77db4930b6d5:	or     r10d,r11d
    77db4930b6d8:	or     DWORD PTR [r12+0x314],r10d
    77db4930b6e0:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930b6e6:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930b6ec:	lea    rdi,[rsp+0x110]
    77db4930b6f4:	lea    rsi,[rsp+0xf0]
    77db4930b6fc:	lea    rdx,[rsp+0x100]
    77db4930b704:	mov    ecx,0x14
    77db4930b709:	mov    r8d,0x0
    77db4930b70f:	lea    r9,[r12+0x314]
    77db4930b717:	movabs r11,0x60ebc89f0650
    77db4930b721:	call   r11
    77db4930b724:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930b72a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930b730:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930b736:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930b73c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    77db4930b746:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930b750:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930b75a:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930b762:	mov    QWORD PTR [r12+0x378],0x2
    77db4930b76e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930b777:	mov    rdx,rbx
    77db4930b77a:	shr    rdx,0x10
    77db4930b77e:	and    edx,0xc000
    77db4930b784:	mov    rax,rbx
    77db4930b787:	shr    rax,0x15
    77db4930b78b:	and    eax,0x100
    77db4930b790:	xor    eax,0x100
    77db4930b795:	or     edx,eax
    77db4930b797:	mov    rax,rbx
    77db4930b79a:	shr    rax,0x1c
    77db4930b79e:	and    eax,0x1
    77db4930b7a1:	or     edx,eax
    77db4930b7a3:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930b7a8:	add    rsp,0x8
    77db4930b7ac:	ret
    77db4930b7ad:	nop    DWORD PTR [rax]
    77db4930b7b0:	sub    rsp,0x8
    77db4930b7b4:	mov    QWORD PTR [r12+0x378],0x3
    77db4930b7c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930b7c6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930b7cc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    77db4930b7d2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    77db4930b7dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    77db4930b7e6:	push   rdx
    77db4930b7e7:	push   rsi
    77db4930b7e8:	push   r10
    77db4930b7ea:	push   r11
    77db4930b7ec:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930b7f1:	mov    r10d,edx
    77db4930b7f4:	and    r10d,0xc000
    77db4930b7fb:	shl    r10d,0x10
    77db4930b7ff:	mov    r11d,edx
    77db4930b802:	and    r11d,0x100
    77db4930b809:	shl    r11d,0x15
    77db4930b80d:	or     r10d,r11d
    77db4930b810:	and    edx,0x1
    77db4930b813:	shl    edx,0x1c
    77db4930b816:	or     r10d,edx
    77db4930b819:	btc    r10,0x1d
    77db4930b81e:	mov    r11d,0xf0000000
    77db4930b824:	and    r11,r10
    77db4930b827:	movabs rsi,0xffffffff0fffffff
    77db4930b831:	and    rbx,rsi
    77db4930b834:	or     rbx,r11
    77db4930b837:	pop    r11
    77db4930b839:	pop    r10
    77db4930b83b:	pop    rsi
    77db4930b83c:	pop    rdx
    77db4930b83d:	mov    QWORD PTR [r12+0x108],rbx
    77db4930b845:	stmxcsr DWORD PTR [r12-0x28]
    77db4930b84b:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930b850:	test   r10d,0x3f
    77db4930b857:	je     0x77db4930b87c
    77db4930b85d:	mov    r11d,r10d
    77db4930b860:	shr    r10d,1
    77db4930b863:	and    r10d,0x1e
    77db4930b867:	and    r11d,0x1
    77db4930b86b:	or     r10d,r11d
    77db4930b86e:	or     DWORD PTR [r12+0x314],r10d
    77db4930b876:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930b87c:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930b882:	lea    rdi,[rsp+0x110]
    77db4930b88a:	lea    rsi,[rsp+0xf0]
    77db4930b892:	lea    rdx,[rsp+0x100]
    77db4930b89a:	mov    ecx,0x14
    77db4930b89f:	mov    r8d,0x0
    77db4930b8a5:	lea    r9,[r12+0x314]
    77db4930b8ad:	movabs r11,0x60ebc89f0650
    77db4930b8b7:	call   r11
    77db4930b8ba:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930b8c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930b8c6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930b8cc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    77db4930b8d2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    77db4930b8dc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    77db4930b8e6:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930b8ee:	mov    QWORD PTR [r12+0x378],0x2
    77db4930b8fa:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930b903:	mov    rdx,rbx
    77db4930b906:	shr    rdx,0x10
    77db4930b90a:	and    edx,0xc000
    77db4930b910:	mov    rax,rbx
    77db4930b913:	shr    rax,0x15
    77db4930b917:	and    eax,0x100
    77db4930b91c:	xor    eax,0x100
    77db4930b921:	or     edx,eax
    77db4930b923:	mov    rax,rbx
    77db4930b926:	shr    rax,0x1c
    77db4930b92a:	and    eax,0x1
    77db4930b92d:	or     edx,eax
    77db4930b92f:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930b934:	add    rsp,0x8
    77db4930b938:	ret
    77db4930b939:	nop    DWORD PTR [rax+0x0]
    77db4930b940:	sub    rsp,0x8
    77db4930b944:	mov    QWORD PTR [r12+0x378],0x3
    77db4930b950:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930b956:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    77db4930b95c:	push   rdx
    77db4930b95d:	push   rsi
    77db4930b95e:	push   r10
    77db4930b960:	push   r11
    77db4930b962:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930b967:	mov    r10d,edx
    77db4930b96a:	and    r10d,0xc000
    77db4930b971:	shl    r10d,0x10
    77db4930b975:	mov    r11d,edx
    77db4930b978:	and    r11d,0x100
    77db4930b97f:	shl    r11d,0x15
    77db4930b983:	or     r10d,r11d
    77db4930b986:	and    edx,0x1
    77db4930b989:	shl    edx,0x1c
    77db4930b98c:	or     r10d,edx
    77db4930b98f:	btc    r10,0x1d
    77db4930b994:	mov    r11d,0xf0000000
    77db4930b99a:	and    r11,r10
    77db4930b99d:	movabs rsi,0xffffffff0fffffff
    77db4930b9a7:	and    rbx,rsi
    77db4930b9aa:	or     rbx,r11
    77db4930b9ad:	pop    r11
    77db4930b9af:	pop    r10
    77db4930b9b1:	pop    rsi
    77db4930b9b2:	pop    rdx
    77db4930b9b3:	mov    QWORD PTR [r12+0x108],rbx
    77db4930b9bb:	stmxcsr DWORD PTR [r12-0x28]
    77db4930b9c1:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930b9c6:	test   r10d,0x3f
    77db4930b9cd:	je     0x77db4930b9f2
    77db4930b9d3:	mov    r11d,r10d
    77db4930b9d6:	shr    r10d,1
    77db4930b9d9:	and    r10d,0x1e
    77db4930b9dd:	and    r11d,0x1
    77db4930b9e1:	or     r10d,r11d
    77db4930b9e4:	or     DWORD PTR [r12+0x314],r10d
    77db4930b9ec:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930b9f2:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930b9f8:	lea    rdi,[rsp+0x110]
    77db4930ba00:	lea    rsi,[rsp+0xf0]
    77db4930ba08:	lea    rdx,[rsp+0x100]
    77db4930ba10:	mov    ecx,0xc
    77db4930ba15:	mov    r8d,0x0
    77db4930ba1b:	lea    r9,[r12+0x314]
    77db4930ba23:	movabs r11,0x60ebc89f0650
    77db4930ba2d:	call   r11
    77db4930ba30:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930ba36:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930ba3c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    77db4930ba42:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930ba4a:	mov    QWORD PTR [r12+0x378],0x2
    77db4930ba56:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930ba5f:	mov    rdx,rbx
    77db4930ba62:	shr    rdx,0x10
    77db4930ba66:	and    edx,0xc000
    77db4930ba6c:	mov    rax,rbx
    77db4930ba6f:	shr    rax,0x15
    77db4930ba73:	and    eax,0x100
    77db4930ba78:	xor    eax,0x100
    77db4930ba7d:	or     edx,eax
    77db4930ba7f:	mov    rax,rbx
    77db4930ba82:	shr    rax,0x1c
    77db4930ba86:	and    eax,0x1
    77db4930ba89:	or     edx,eax
    77db4930ba8b:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930ba90:	add    rsp,0x8
    77db4930ba94:	ret
    77db4930ba95:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db4930baa0:	sub    rsp,0x8
    77db4930baa4:	mov    QWORD PTR [r12+0x378],0x3
    77db4930bab0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    77db4930bab6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    77db4930babc:	push   rdx
    77db4930babd:	push   rsi
    77db4930babe:	push   r10
    77db4930bac0:	push   r11
    77db4930bac2:	mov    rdx,QWORD PTR [rsp+0x30]
    77db4930bac7:	mov    r10d,edx
    77db4930baca:	and    r10d,0xc000
    77db4930bad1:	shl    r10d,0x10
    77db4930bad5:	mov    r11d,edx
    77db4930bad8:	and    r11d,0x100
    77db4930badf:	shl    r11d,0x15
    77db4930bae3:	or     r10d,r11d
    77db4930bae6:	and    edx,0x1
    77db4930bae9:	shl    edx,0x1c
    77db4930baec:	or     r10d,edx
    77db4930baef:	btc    r10,0x1d
    77db4930baf4:	mov    r11d,0xf0000000
    77db4930bafa:	and    r11,r10
    77db4930bafd:	movabs rsi,0xffffffff0fffffff
    77db4930bb07:	and    rbx,rsi
    77db4930bb0a:	or     rbx,r11
    77db4930bb0d:	pop    r11
    77db4930bb0f:	pop    r10
    77db4930bb11:	pop    rsi
    77db4930bb12:	pop    rdx
    77db4930bb13:	mov    QWORD PTR [r12+0x108],rbx
    77db4930bb1b:	stmxcsr DWORD PTR [r12-0x28]
    77db4930bb21:	mov    r10d,DWORD PTR [r12-0x28]
    77db4930bb26:	test   r10d,0x3f
    77db4930bb2d:	je     0x77db4930bb52
    77db4930bb33:	mov    r11d,r10d
    77db4930bb36:	shr    r10d,1
    77db4930bb39:	and    r10d,0x1e
    77db4930bb3d:	and    r11d,0x1
    77db4930bb41:	or     r10d,r11d
    77db4930bb44:	or     DWORD PTR [r12+0x314],r10d
    77db4930bb4c:	and    DWORD PTR [r12-0x28],0xffffffc0
    77db4930bb52:	ldmxcsr DWORD PTR [r12-0x38]
    77db4930bb58:	lea    rdi,[rsp+0x110]
    77db4930bb60:	lea    rsi,[rsp+0xf0]
    77db4930bb68:	lea    rdx,[rsp+0x100]
    77db4930bb70:	mov    ecx,0xc
    77db4930bb75:	mov    r8d,0x0
    77db4930bb7b:	lea    r9,[r12+0x314]
    77db4930bb83:	movabs r11,0x60ebc89f0650
    77db4930bb8d:	call   r11
    77db4930bb90:	ldmxcsr DWORD PTR [r12-0x28]
    77db4930bb96:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    77db4930bb9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    77db4930bba2:	mov    rbx,QWORD PTR [r12+0x108]
    77db4930bbaa:	mov    QWORD PTR [r12+0x378],0x2
    77db4930bbb6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    77db4930bbbf:	mov    rdx,rbx
    77db4930bbc2:	shr    rdx,0x10
    77db4930bbc6:	and    edx,0xc000
    77db4930bbcc:	mov    rax,rbx
    77db4930bbcf:	shr    rax,0x15
    77db4930bbd3:	and    eax,0x100
    77db4930bbd8:	xor    eax,0x100
    77db4930bbdd:	or     edx,eax
    77db4930bbdf:	mov    rax,rbx
    77db4930bbe2:	shr    rax,0x1c
    77db4930bbe6:	and    eax,0x1
    77db4930bbe9:	or     edx,eax
    77db4930bbeb:	mov    QWORD PTR [rsp+0x10],rdx
    77db4930bbf0:	add    rsp,0x8
    77db4930bbf4:	ret
    77db4930bbf5:	mov    eax,0x410400
    77db4930bbfa:	mov    QWORD PTR [r12+0x100],rax
    77db4930bc02:	push   rdx
    77db4930bc03:	push   rsi
    77db4930bc04:	push   r10
    77db4930bc06:	push   r11
    77db4930bc08:	mov    r11,rax
    77db4930bc0b:	lahf
    77db4930bc0c:	seto   al
    77db4930bc0f:	mov    WORD PTR [rsp+0x20],ax
    77db4930bc14:	mov    rax,r11
    77db4930bc17:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930bc1c:	mov    r10d,edx
    77db4930bc1f:	and    r10d,0xc000
    77db4930bc26:	shl    r10d,0x10
    77db4930bc2a:	mov    r11d,edx
    77db4930bc2d:	and    r11d,0x100
    77db4930bc34:	shl    r11d,0x15
    77db4930bc38:	or     r10d,r11d
    77db4930bc3b:	and    edx,0x1
    77db4930bc3e:	shl    edx,0x1c
    77db4930bc41:	or     r10d,edx
    77db4930bc44:	btc    r10,0x1d
    77db4930bc49:	mov    r11d,0xf0000000
    77db4930bc4f:	and    r11,r10
    77db4930bc52:	movabs rsi,0xffffffff0fffffff
    77db4930bc5c:	and    rbx,rsi
    77db4930bc5f:	or     rbx,r11
    77db4930bc62:	pop    r11
    77db4930bc64:	pop    r10
    77db4930bc66:	pop    rsi
    77db4930bc67:	pop    rdx
    77db4930bc68:	mov    QWORD PTR [r12+0x108],rbx
    77db4930bc70:	add    rsp,0x150
    77db4930bc77:	mov    eax,0xc
    77db4930bc7c:	movabs r11,0x60ebc8b89ca0
    77db4930bc86:	jmp    r11
    77db4930bc89:	mov    eax,0x41048c
    77db4930bc8e:	mov    QWORD PTR [r12+0x100],rax
    77db4930bc96:	push   rdx
    77db4930bc97:	push   rsi
    77db4930bc98:	push   r10
    77db4930bc9a:	push   r11
    77db4930bc9c:	mov    r11,rax
    77db4930bc9f:	lahf
    77db4930bca0:	seto   al
    77db4930bca3:	mov    WORD PTR [rsp+0x20],ax
    77db4930bca8:	mov    rax,r11
    77db4930bcab:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930bcb0:	mov    r10d,edx
    77db4930bcb3:	and    r10d,0xc000
    77db4930bcba:	shl    r10d,0x10
    77db4930bcbe:	mov    r11d,edx
    77db4930bcc1:	and    r11d,0x100
    77db4930bcc8:	shl    r11d,0x15
    77db4930bccc:	or     r10d,r11d
    77db4930bccf:	and    edx,0x1
    77db4930bcd2:	shl    edx,0x1c
    77db4930bcd5:	or     r10d,edx
    77db4930bcd8:	btc    r10,0x1d
    77db4930bcdd:	mov    r11d,0xf0000000
    77db4930bce3:	and    r11,r10
    77db4930bce6:	movabs rsi,0xffffffff0fffffff
    77db4930bcf0:	and    rbx,rsi
    77db4930bcf3:	or     rbx,r11
    77db4930bcf6:	pop    r11
    77db4930bcf8:	pop    r10
    77db4930bcfa:	pop    rsi
    77db4930bcfb:	pop    rdx
    77db4930bcfc:	mov    QWORD PTR [r12+0x108],rbx
    77db4930bd04:	add    rsp,0x150
    77db4930bd0b:	mov    eax,0xc
    77db4930bd10:	movabs r11,0x60ebc8b89ca0
    77db4930bd1a:	jmp    r11
    77db4930bd1d:	mov    eax,0x4106cc
    77db4930bd22:	mov    QWORD PTR [r12+0x100],rax
    77db4930bd2a:	push   rdx
    77db4930bd2b:	push   rsi
    77db4930bd2c:	push   r10
    77db4930bd2e:	push   r11
    77db4930bd30:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930bd35:	mov    r10d,edx
    77db4930bd38:	and    r10d,0xc000
    77db4930bd3f:	shl    r10d,0x10
    77db4930bd43:	mov    r11d,edx
    77db4930bd46:	and    r11d,0x100
    77db4930bd4d:	shl    r11d,0x15
    77db4930bd51:	or     r10d,r11d
    77db4930bd54:	and    edx,0x1
    77db4930bd57:	shl    edx,0x1c
    77db4930bd5a:	or     r10d,edx
    77db4930bd5d:	btc    r10,0x1d
    77db4930bd62:	mov    r11d,0xf0000000
    77db4930bd68:	and    r11,r10
    77db4930bd6b:	movabs rsi,0xffffffff0fffffff
    77db4930bd75:	and    rbx,rsi
    77db4930bd78:	or     rbx,r11
    77db4930bd7b:	pop    r11
    77db4930bd7d:	pop    r10
    77db4930bd7f:	pop    rsi
    77db4930bd80:	pop    rdx
    77db4930bd81:	mov    QWORD PTR [r12+0x108],rbx
    77db4930bd89:	add    rsp,0x150
    77db4930bd90:	mov    eax,0xc
    77db4930bd95:	movabs r11,0x60ebc8b89ca0
    77db4930bd9f:	jmp    r11
    77db4930bda2:	mov    eax,0x4106d8
    77db4930bda7:	mov    QWORD PTR [r12+0x100],rax
    77db4930bdaf:	push   rdx
    77db4930bdb0:	push   rsi
    77db4930bdb1:	push   r10
    77db4930bdb3:	push   r11
    77db4930bdb5:	mov    r11,rax
    77db4930bdb8:	lahf
    77db4930bdb9:	seto   al
    77db4930bdbc:	mov    WORD PTR [rsp+0x20],ax
    77db4930bdc1:	mov    rax,r11
    77db4930bdc4:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930bdc9:	mov    r10d,edx
    77db4930bdcc:	and    r10d,0xc000
    77db4930bdd3:	shl    r10d,0x10
    77db4930bdd7:	mov    r11d,edx
    77db4930bdda:	and    r11d,0x100
    77db4930bde1:	shl    r11d,0x15
    77db4930bde5:	or     r10d,r11d
    77db4930bde8:	and    edx,0x1
    77db4930bdeb:	shl    edx,0x1c
    77db4930bdee:	or     r10d,edx
    77db4930bdf1:	btc    r10,0x1d
    77db4930bdf6:	mov    r11d,0xf0000000
    77db4930bdfc:	and    r11,r10
    77db4930bdff:	movabs rsi,0xffffffff0fffffff
    77db4930be09:	and    rbx,rsi
    77db4930be0c:	or     rbx,r11
    77db4930be0f:	pop    r11
    77db4930be11:	pop    r10
    77db4930be13:	pop    rsi
    77db4930be14:	pop    rdx
    77db4930be15:	mov    QWORD PTR [r12+0x108],rbx
    77db4930be1d:	add    rsp,0x150
    77db4930be24:	mov    eax,0xc
    77db4930be29:	movabs r11,0x60ebc8b89ca0
    77db4930be33:	jmp    r11
    77db4930be36:	mov    eax,0x410700
    77db4930be3b:	mov    QWORD PTR [r12+0x100],rax
    77db4930be43:	push   rdx
    77db4930be44:	push   rsi
    77db4930be45:	push   r10
    77db4930be47:	push   r11
    77db4930be49:	mov    r11,rax
    77db4930be4c:	lahf
    77db4930be4d:	seto   al
    77db4930be50:	mov    WORD PTR [rsp+0x20],ax
    77db4930be55:	mov    rax,r11
    77db4930be58:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930be5d:	mov    r10d,edx
    77db4930be60:	and    r10d,0xc000
    77db4930be67:	shl    r10d,0x10
    77db4930be6b:	mov    r11d,edx
    77db4930be6e:	and    r11d,0x100
    77db4930be75:	shl    r11d,0x15
    77db4930be79:	or     r10d,r11d
    77db4930be7c:	and    edx,0x1
    77db4930be7f:	shl    edx,0x1c
    77db4930be82:	or     r10d,edx
    77db4930be85:	btc    r10,0x1d
    77db4930be8a:	mov    r11d,0xf0000000
    77db4930be90:	and    r11,r10
    77db4930be93:	movabs rsi,0xffffffff0fffffff
    77db4930be9d:	and    rbx,rsi
    77db4930bea0:	or     rbx,r11
    77db4930bea3:	pop    r11
    77db4930bea5:	pop    r10
    77db4930bea7:	pop    rsi
    77db4930bea8:	pop    rdx
    77db4930bea9:	mov    QWORD PTR [r12+0x108],rbx
    77db4930beb1:	add    rsp,0x150
    77db4930beb8:	mov    eax,0xc
    77db4930bebd:	movabs r11,0x60ebc8b89ca0
    77db4930bec7:	jmp    r11
    77db4930beca:	mov    eax,0x410724
    77db4930becf:	mov    QWORD PTR [r12+0x100],rax
    77db4930bed7:	push   rdx
    77db4930bed8:	push   rsi
    77db4930bed9:	push   r10
    77db4930bedb:	push   r11
    77db4930bedd:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930bee2:	mov    r10d,edx
    77db4930bee5:	and    r10d,0xc000
    77db4930beec:	shl    r10d,0x10
    77db4930bef0:	mov    r11d,edx
    77db4930bef3:	and    r11d,0x100
    77db4930befa:	shl    r11d,0x15
    77db4930befe:	or     r10d,r11d
    77db4930bf01:	and    edx,0x1
    77db4930bf04:	shl    edx,0x1c
    77db4930bf07:	or     r10d,edx
    77db4930bf0a:	btc    r10,0x1d
    77db4930bf0f:	mov    r11d,0xf0000000
    77db4930bf15:	and    r11,r10
    77db4930bf18:	movabs rsi,0xffffffff0fffffff
    77db4930bf22:	and    rbx,rsi
    77db4930bf25:	or     rbx,r11
    77db4930bf28:	pop    r11
    77db4930bf2a:	pop    r10
    77db4930bf2c:	pop    rsi
    77db4930bf2d:	pop    rdx
    77db4930bf2e:	mov    QWORD PTR [r12+0x108],rbx
    77db4930bf36:	add    rsp,0x150
    77db4930bf3d:	mov    eax,0xc
    77db4930bf42:	movabs r11,0x60ebc8b89ca0
    77db4930bf4c:	jmp    r11
    77db4930bf4f:	nop
    77db4930bf50:	sub    rsp,0x150
    77db4930bf57:	mov    r11,QWORD PTR [r12+0x398]
    77db4930bf5f:	mov    QWORD PTR [rsp],r11
    77db4930bf63:	cmp    DWORD PTR [r12+0x310],0x0
    77db4930bf6c:	je     0x77db4930bff7
    77db4930bf72:	push   rdx
    77db4930bf73:	push   rsi
    77db4930bf74:	push   r10
    77db4930bf76:	push   r11
    77db4930bf78:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930bf7d:	mov    r10d,edx
    77db4930bf80:	and    r10d,0xc000
    77db4930bf87:	shl    r10d,0x10
    77db4930bf8b:	mov    r11d,edx
    77db4930bf8e:	and    r11d,0x100
    77db4930bf95:	shl    r11d,0x15
    77db4930bf99:	or     r10d,r11d
    77db4930bf9c:	and    edx,0x1
    77db4930bf9f:	shl    edx,0x1c
    77db4930bfa2:	or     r10d,edx
    77db4930bfa5:	btc    r10,0x1d
    77db4930bfaa:	mov    r11d,0xf0000000
    77db4930bfb0:	and    r11,r10
    77db4930bfb3:	movabs rsi,0xffffffff0fffffff
    77db4930bfbd:	and    rbx,rsi
    77db4930bfc0:	or     rbx,r11
    77db4930bfc3:	pop    r11
    77db4930bfc5:	pop    r10
    77db4930bfc7:	pop    rsi
    77db4930bfc8:	pop    rdx
    77db4930bfc9:	mov    QWORD PTR [r12+0x108],rbx
    77db4930bfd1:	mov    eax,0x410404
    77db4930bfd6:	mov    QWORD PTR [r12+0x100],rax
    77db4930bfde:	add    rsp,0x150
    77db4930bfe5:	mov    eax,0x3
    77db4930bfea:	movabs r11,0x60ebc8b89ca0
    77db4930bff4:	jmp    r11
    77db4930bff7:	jmp    0x77db4930226d
    77db4930bffc:	nop    DWORD PTR [rax+0x0]
    77db4930c000:	sub    rsp,0x150
    77db4930c007:	mov    r11,QWORD PTR [r12+0x398]
    77db4930c00f:	mov    QWORD PTR [rsp],r11
    77db4930c013:	cmp    DWORD PTR [r12+0x310],0x0
    77db4930c01c:	je     0x77db4930c0a7
    77db4930c022:	push   rdx
    77db4930c023:	push   rsi
    77db4930c024:	push   r10
    77db4930c026:	push   r11
    77db4930c028:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930c02d:	mov    r10d,edx
    77db4930c030:	and    r10d,0xc000
    77db4930c037:	shl    r10d,0x10
    77db4930c03b:	mov    r11d,edx
    77db4930c03e:	and    r11d,0x100
    77db4930c045:	shl    r11d,0x15
    77db4930c049:	or     r10d,r11d
    77db4930c04c:	and    edx,0x1
    77db4930c04f:	shl    edx,0x1c
    77db4930c052:	or     r10d,edx
    77db4930c055:	btc    r10,0x1d
    77db4930c05a:	mov    r11d,0xf0000000
    77db4930c060:	and    r11,r10
    77db4930c063:	movabs rsi,0xffffffff0fffffff
    77db4930c06d:	and    rbx,rsi
    77db4930c070:	or     rbx,r11
    77db4930c073:	pop    r11
    77db4930c075:	pop    r10
    77db4930c077:	pop    rsi
    77db4930c078:	pop    rdx
    77db4930c079:	mov    QWORD PTR [r12+0x108],rbx
    77db4930c081:	mov    eax,0x410450
    77db4930c086:	mov    QWORD PTR [r12+0x100],rax
    77db4930c08e:	add    rsp,0x150
    77db4930c095:	mov    eax,0x3
    77db4930c09a:	movabs r11,0x60ebc8b89ca0
    77db4930c0a4:	jmp    r11
    77db4930c0a7:	mov    r11,rax
    77db4930c0aa:	movzx  eax,WORD PTR [rsp]
    77db4930c0ae:	add    al,0x7f
    77db4930c0b0:	sahf
    77db4930c0b1:	mov    rax,r11
    77db4930c0b4:	jmp    0x77db493023dd
    77db4930c0b9:	nop    DWORD PTR [rax+0x0]
    77db4930c0c0:	sub    rsp,0x150
    77db4930c0c7:	mov    r11,QWORD PTR [r12+0x398]
    77db4930c0cf:	mov    QWORD PTR [rsp],r11
    77db4930c0d3:	cmp    DWORD PTR [r12+0x310],0x0
    77db4930c0dc:	je     0x77db4930c167
    77db4930c0e2:	push   rdx
    77db4930c0e3:	push   rsi
    77db4930c0e4:	push   r10
    77db4930c0e6:	push   r11
    77db4930c0e8:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930c0ed:	mov    r10d,edx
    77db4930c0f0:	and    r10d,0xc000
    77db4930c0f7:	shl    r10d,0x10
    77db4930c0fb:	mov    r11d,edx
    77db4930c0fe:	and    r11d,0x100
    77db4930c105:	shl    r11d,0x15
    77db4930c109:	or     r10d,r11d
    77db4930c10c:	and    edx,0x1
    77db4930c10f:	shl    edx,0x1c
    77db4930c112:	or     r10d,edx
    77db4930c115:	btc    r10,0x1d
    77db4930c11a:	mov    r11d,0xf0000000
    77db4930c120:	and    r11,r10
    77db4930c123:	movabs rsi,0xffffffff0fffffff
    77db4930c12d:	and    rbx,rsi
    77db4930c130:	or     rbx,r11
    77db4930c133:	pop    r11
    77db4930c135:	pop    r10
    77db4930c137:	pop    rsi
    77db4930c138:	pop    rdx
    77db4930c139:	mov    QWORD PTR [r12+0x108],rbx
    77db4930c141:	mov    eax,0x410490
    77db4930c146:	mov    QWORD PTR [r12+0x100],rax
    77db4930c14e:	add    rsp,0x150
    77db4930c155:	mov    eax,0x3
    77db4930c15a:	movabs r11,0x60ebc8b89ca0
    77db4930c164:	jmp    r11
    77db4930c167:	jmp    0x77db4930282b
    77db4930c16c:	nop    DWORD PTR [rax+0x0]
    77db4930c170:	sub    rsp,0x150
    77db4930c177:	mov    r11,QWORD PTR [r12+0x398]
    77db4930c17f:	mov    QWORD PTR [rsp],r11
    77db4930c183:	cmp    DWORD PTR [r12+0x310],0x0
    77db4930c18c:	je     0x77db4930c217
    77db4930c192:	push   rdx
    77db4930c193:	push   rsi
    77db4930c194:	push   r10
    77db4930c196:	push   r11
    77db4930c198:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930c19d:	mov    r10d,edx
    77db4930c1a0:	and    r10d,0xc000
    77db4930c1a7:	shl    r10d,0x10
    77db4930c1ab:	mov    r11d,edx
    77db4930c1ae:	and    r11d,0x100
    77db4930c1b5:	shl    r11d,0x15
    77db4930c1b9:	or     r10d,r11d
    77db4930c1bc:	and    edx,0x1
    77db4930c1bf:	shl    edx,0x1c
    77db4930c1c2:	or     r10d,edx
    77db4930c1c5:	btc    r10,0x1d
    77db4930c1ca:	mov    r11d,0xf0000000
    77db4930c1d0:	and    r11,r10
    77db4930c1d3:	movabs rsi,0xffffffff0fffffff
    77db4930c1dd:	and    rbx,rsi
    77db4930c1e0:	or     rbx,r11
    77db4930c1e3:	pop    r11
    77db4930c1e5:	pop    r10
    77db4930c1e7:	pop    rsi
    77db4930c1e8:	pop    rdx
    77db4930c1e9:	mov    QWORD PTR [r12+0x108],rbx
    77db4930c1f1:	mov    eax,0x410500
    77db4930c1f6:	mov    QWORD PTR [r12+0x100],rax
    77db4930c1fe:	add    rsp,0x150
    77db4930c205:	mov    eax,0x3
    77db4930c20a:	movabs r11,0x60ebc8b89ca0
    77db4930c214:	jmp    r11
    77db4930c217:	mov    r11,rax
    77db4930c21a:	movzx  eax,WORD PTR [rsp]
    77db4930c21e:	add    al,0x7f
    77db4930c220:	sahf
    77db4930c221:	mov    rax,r11
    77db4930c224:	jmp    0x77db49302c37
    77db4930c229:	nop    DWORD PTR [rax+0x0]
    77db4930c230:	sub    rsp,0x150
    77db4930c237:	mov    r11,QWORD PTR [r12+0x398]
    77db4930c23f:	mov    QWORD PTR [rsp],r11
    77db4930c243:	cmp    DWORD PTR [r12+0x310],0x0
    77db4930c24c:	je     0x77db4930c2d7
    77db4930c252:	push   rdx
    77db4930c253:	push   rsi
    77db4930c254:	push   r10
    77db4930c256:	push   r11
    77db4930c258:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930c25d:	mov    r10d,edx
    77db4930c260:	and    r10d,0xc000
    77db4930c267:	shl    r10d,0x10
    77db4930c26b:	mov    r11d,edx
    77db4930c26e:	and    r11d,0x100
    77db4930c275:	shl    r11d,0x15
    77db4930c279:	or     r10d,r11d
    77db4930c27c:	and    edx,0x1
    77db4930c27f:	shl    edx,0x1c
    77db4930c282:	or     r10d,edx
    77db4930c285:	btc    r10,0x1d
    77db4930c28a:	mov    r11d,0xf0000000
    77db4930c290:	and    r11,r10
    77db4930c293:	movabs rsi,0xffffffff0fffffff
    77db4930c29d:	and    rbx,rsi
    77db4930c2a0:	or     rbx,r11
    77db4930c2a3:	pop    r11
    77db4930c2a5:	pop    r10
    77db4930c2a7:	pop    rsi
    77db4930c2a8:	pop    rdx
    77db4930c2a9:	mov    QWORD PTR [r12+0x108],rbx
    77db4930c2b1:	mov    eax,0x410504
    77db4930c2b6:	mov    QWORD PTR [r12+0x100],rax
    77db4930c2be:	add    rsp,0x150
    77db4930c2c5:	mov    eax,0x3
    77db4930c2ca:	movabs r11,0x60ebc8b89ca0
    77db4930c2d4:	jmp    r11
    77db4930c2d7:	jmp    0x77db49302c55
    77db4930c2dc:	nop    DWORD PTR [rax+0x0]
    77db4930c2e0:	sub    rsp,0x150
    77db4930c2e7:	mov    r11,QWORD PTR [r12+0x398]
    77db4930c2ef:	mov    QWORD PTR [rsp],r11
    77db4930c2f3:	cmp    DWORD PTR [r12+0x310],0x0
    77db4930c2fc:	je     0x77db4930c387
    77db4930c302:	push   rdx
    77db4930c303:	push   rsi
    77db4930c304:	push   r10
    77db4930c306:	push   r11
    77db4930c308:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930c30d:	mov    r10d,edx
    77db4930c310:	and    r10d,0xc000
    77db4930c317:	shl    r10d,0x10
    77db4930c31b:	mov    r11d,edx
    77db4930c31e:	and    r11d,0x100
    77db4930c325:	shl    r11d,0x15
    77db4930c329:	or     r10d,r11d
    77db4930c32c:	and    edx,0x1
    77db4930c32f:	shl    edx,0x1c
    77db4930c332:	or     r10d,edx
    77db4930c335:	btc    r10,0x1d
    77db4930c33a:	mov    r11d,0xf0000000
    77db4930c340:	and    r11,r10
    77db4930c343:	movabs rsi,0xffffffff0fffffff
    77db4930c34d:	and    rbx,rsi
    77db4930c350:	or     rbx,r11
    77db4930c353:	pop    r11
    77db4930c355:	pop    r10
    77db4930c357:	pop    rsi
    77db4930c358:	pop    rdx
    77db4930c359:	mov    QWORD PTR [r12+0x108],rbx
    77db4930c361:	mov    eax,0x4106d0
    77db4930c366:	mov    QWORD PTR [r12+0x100],rax
    77db4930c36e:	add    rsp,0x150
    77db4930c375:	mov    eax,0x3
    77db4930c37a:	movabs r11,0x60ebc8b89ca0
    77db4930c384:	jmp    r11
    77db4930c387:	jmp    0x77db49304995
    77db4930c38c:	nop    DWORD PTR [rax+0x0]
    77db4930c390:	sub    rsp,0x150
    77db4930c397:	mov    r11,QWORD PTR [r12+0x398]
    77db4930c39f:	mov    QWORD PTR [rsp],r11
    77db4930c3a3:	cmp    DWORD PTR [r12+0x310],0x0
    77db4930c3ac:	je     0x77db4930c437
    77db4930c3b2:	push   rdx
    77db4930c3b3:	push   rsi
    77db4930c3b4:	push   r10
    77db4930c3b6:	push   r11
    77db4930c3b8:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930c3bd:	mov    r10d,edx
    77db4930c3c0:	and    r10d,0xc000
    77db4930c3c7:	shl    r10d,0x10
    77db4930c3cb:	mov    r11d,edx
    77db4930c3ce:	and    r11d,0x100
    77db4930c3d5:	shl    r11d,0x15
    77db4930c3d9:	or     r10d,r11d
    77db4930c3dc:	and    edx,0x1
    77db4930c3df:	shl    edx,0x1c
    77db4930c3e2:	or     r10d,edx
    77db4930c3e5:	btc    r10,0x1d
    77db4930c3ea:	mov    r11d,0xf0000000
    77db4930c3f0:	and    r11,r10
    77db4930c3f3:	movabs rsi,0xffffffff0fffffff
    77db4930c3fd:	and    rbx,rsi
    77db4930c400:	or     rbx,r11
    77db4930c403:	pop    r11
    77db4930c405:	pop    r10
    77db4930c407:	pop    rsi
    77db4930c408:	pop    rdx
    77db4930c409:	mov    QWORD PTR [r12+0x108],rbx
    77db4930c411:	mov    eax,0x4106dc
    77db4930c416:	mov    QWORD PTR [r12+0x100],rax
    77db4930c41e:	add    rsp,0x150
    77db4930c425:	mov    eax,0x3
    77db4930c42a:	movabs r11,0x60ebc8b89ca0
    77db4930c434:	jmp    r11
    77db4930c437:	jmp    0x77db493049d2
    77db4930c43c:	nop    DWORD PTR [rax+0x0]
    77db4930c440:	sub    rsp,0x150
    77db4930c447:	mov    r11,QWORD PTR [r12+0x398]
    77db4930c44f:	mov    QWORD PTR [rsp],r11
    77db4930c453:	cmp    DWORD PTR [r12+0x310],0x0
    77db4930c45c:	je     0x77db4930c4e7
    77db4930c462:	push   rdx
    77db4930c463:	push   rsi
    77db4930c464:	push   r10
    77db4930c466:	push   r11
    77db4930c468:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930c46d:	mov    r10d,edx
    77db4930c470:	and    r10d,0xc000
    77db4930c477:	shl    r10d,0x10
    77db4930c47b:	mov    r11d,edx
    77db4930c47e:	and    r11d,0x100
    77db4930c485:	shl    r11d,0x15
    77db4930c489:	or     r10d,r11d
    77db4930c48c:	and    edx,0x1
    77db4930c48f:	shl    edx,0x1c
    77db4930c492:	or     r10d,edx
    77db4930c495:	btc    r10,0x1d
    77db4930c49a:	mov    r11d,0xf0000000
    77db4930c4a0:	and    r11,r10
    77db4930c4a3:	movabs rsi,0xffffffff0fffffff
    77db4930c4ad:	and    rbx,rsi
    77db4930c4b0:	or     rbx,r11
    77db4930c4b3:	pop    r11
    77db4930c4b5:	pop    r10
    77db4930c4b7:	pop    rsi
    77db4930c4b8:	pop    rdx
    77db4930c4b9:	mov    QWORD PTR [r12+0x108],rbx
    77db4930c4c1:	mov    eax,0x4106e8
    77db4930c4c6:	mov    QWORD PTR [r12+0x100],rax
    77db4930c4ce:	add    rsp,0x150
    77db4930c4d5:	mov    eax,0x3
    77db4930c4da:	movabs r11,0x60ebc8b89ca0
    77db4930c4e4:	jmp    r11
    77db4930c4e7:	jmp    0x77db49304a0d
    77db4930c4ec:	nop    DWORD PTR [rax+0x0]
    77db4930c4f0:	sub    rsp,0x150
    77db4930c4f7:	mov    r11,QWORD PTR [r12+0x398]
    77db4930c4ff:	mov    QWORD PTR [rsp],r11
    77db4930c503:	cmp    DWORD PTR [r12+0x310],0x0
    77db4930c50c:	je     0x77db4930c597
    77db4930c512:	push   rdx
    77db4930c513:	push   rsi
    77db4930c514:	push   r10
    77db4930c516:	push   r11
    77db4930c518:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930c51d:	mov    r10d,edx
    77db4930c520:	and    r10d,0xc000
    77db4930c527:	shl    r10d,0x10
    77db4930c52b:	mov    r11d,edx
    77db4930c52e:	and    r11d,0x100
    77db4930c535:	shl    r11d,0x15
    77db4930c539:	or     r10d,r11d
    77db4930c53c:	and    edx,0x1
    77db4930c53f:	shl    edx,0x1c
    77db4930c542:	or     r10d,edx
    77db4930c545:	btc    r10,0x1d
    77db4930c54a:	mov    r11d,0xf0000000
    77db4930c550:	and    r11,r10
    77db4930c553:	movabs rsi,0xffffffff0fffffff
    77db4930c55d:	and    rbx,rsi
    77db4930c560:	or     rbx,r11
    77db4930c563:	pop    r11
    77db4930c565:	pop    r10
    77db4930c567:	pop    rsi
    77db4930c568:	pop    rdx
    77db4930c569:	mov    QWORD PTR [r12+0x108],rbx
    77db4930c571:	mov    eax,0x410704
    77db4930c576:	mov    QWORD PTR [r12+0x100],rax
    77db4930c57e:	add    rsp,0x150
    77db4930c585:	mov    eax,0x3
    77db4930c58a:	movabs r11,0x60ebc8b89ca0
    77db4930c594:	jmp    r11
    77db4930c597:	jmp    0x77db49304b66
    77db4930c59c:	nop    DWORD PTR [rax+0x0]
    77db4930c5a0:	sub    rsp,0x150
    77db4930c5a7:	mov    r11,QWORD PTR [r12+0x398]
    77db4930c5af:	mov    QWORD PTR [rsp],r11
    77db4930c5b3:	cmp    DWORD PTR [r12+0x310],0x0
    77db4930c5bc:	je     0x77db4930c647
    77db4930c5c2:	push   rdx
    77db4930c5c3:	push   rsi
    77db4930c5c4:	push   r10
    77db4930c5c6:	push   r11
    77db4930c5c8:	mov    rdx,QWORD PTR [rsp+0x20]
    77db4930c5cd:	mov    r10d,edx
    77db4930c5d0:	and    r10d,0xc000
    77db4930c5d7:	shl    r10d,0x10
    77db4930c5db:	mov    r11d,edx
    77db4930c5de:	and    r11d,0x100
    77db4930c5e5:	shl    r11d,0x15
    77db4930c5e9:	or     r10d,r11d
    77db4930c5ec:	and    edx,0x1
    77db4930c5ef:	shl    edx,0x1c
    77db4930c5f2:	or     r10d,edx
    77db4930c5f5:	btc    r10,0x1d
    77db4930c5fa:	mov    r11d,0xf0000000
    77db4930c600:	and    r11,r10
    77db4930c603:	movabs rsi,0xffffffff0fffffff
    77db4930c60d:	and    rbx,rsi
    77db4930c610:	or     rbx,r11
    77db4930c613:	pop    r11
    77db4930c615:	pop    r10
    77db4930c617:	pop    rsi
    77db4930c618:	pop    rdx
    77db4930c619:	mov    QWORD PTR [r12+0x108],rbx
    77db4930c621:	mov    eax,0x4103f0
    77db4930c626:	mov    QWORD PTR [r12+0x100],rax
    77db4930c62e:	add    rsp,0x150
    77db4930c635:	mov    eax,0x3
    77db4930c63a:	movabs r11,0x60ebc8b89ca0
    77db4930c644:	jmp    r11
    77db4930c647:	jmp    0x77db49304d43
    77db4930c64c:	nop    DWORD PTR [rax+0x0]
    77db4930c650:	(bad)
    77db4930c651:	(bad)
    77db4930c652:	(bad)
    77db4930c653:	(bad)
    77db4930c654:	(bad)
    77db4930c655:	(bad)
    77db4930c656:	(bad)
    77db4930c657:	jg     0x77db4930c658
    77db4930c659:	(bad)
    77db4930c65a:	(bad)
    77db4930c65b:	(bad)
    77db4930c65c:	(bad)
    77db4930c65d:	(bad)
    77db4930c65e:	(bad)
    77db4930c65f:	jg     0x77db4930c661
    77db4930c661:	add    BYTE PTR [rax],al
    77db4930c663:	add    BYTE PTR [rax],al
    77db4930c665:	add    BYTE PTR [rax],dl
    77db4930c667:	add    BYTE PTR [rax],al
    77db4930c669:	add    BYTE PTR [rax],al
    77db4930c66b:	add    BYTE PTR [rax],al
    77db4930c66d:	add    BYTE PTR [rax],dl
	...
