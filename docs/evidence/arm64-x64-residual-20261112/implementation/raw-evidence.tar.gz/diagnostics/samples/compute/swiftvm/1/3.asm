
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/1/3.bin:     file format binary


Disassembly of section .data:

00007c479db00e10 <.data>:
    7c479db00e10:	sub    rsp,0x10
    7c479db00e14:	mov    r11,QWORD PTR [r12+0x398]
    7c479db00e1c:	mov    QWORD PTR [rsp],r11
    7c479db00e20:	mov    r13,QWORD PTR [r12+0xf8]
    7c479db00e28:	mov    r14,r13
    7c479db00e2b:	add    r14,0x168
    7c479db00e32:	mov    r15,QWORD PTR [r14]
    7c479db00e35:	mov    QWORD PTR [r12+0x40],r15
    7c479db00e3a:	add    r13,0x178
    7c479db00e41:	mov    r14d,0x0
    7c479db00e47:	mov    BYTE PTR [r13+0x0],r14b
    7c479db00e4b:	mov    r13d,0x0
    7c479db00e51:	mov    DWORD PTR [r12+0x32c],r13d
    7c479db00e59:	sub    r15,0x38
    7c479db00e5d:	je     0x7c479db00e76
    7c479db00e63:	mov    r11,rax
    7c479db00e66:	lahf
    7c479db00e67:	seto   al
    7c479db00e6a:	mov    WORD PTR [rsp],ax
    7c479db00e6e:	mov    rax,r11
    7c479db00e71:	jmp    0x7c479db00e89
    7c479db00e76:	mov    r11,rax
    7c479db00e79:	lahf
    7c479db00e7a:	seto   al
    7c479db00e7d:	mov    WORD PTR [rsp],ax
    7c479db00e81:	mov    rax,r11
    7c479db00e84:	jmp    0x7c479db00f15
    7c479db00e89:	mov    r13,QWORD PTR [r12+0xf8]
    7c479db00e91:	mov    r14,r13
    7c479db00e94:	add    r14,0x100
    7c479db00e9b:	mov    QWORD PTR [r12],r14
    7c479db00e9f:	add    r13,0x178
    7c479db00ea6:	mov    QWORD PTR [r12+0x8],r13
    7c479db00eab:	mov    r13d,0x1
    7c479db00eb1:	mov    QWORD PTR [r12+0x10],r13
    7c479db00eb6:	mov    r13d,0x4102c8
    7c479db00ebc:	mov    QWORD PTR [r12+0xf0],r13
    7c479db00ec4:	mov    r13d,0x410728
    7c479db00eca:	mov    QWORD PTR [r12+0x100],r13
    7c479db00ed2:	mov    r11,QWORD PTR [rsp]
    7c479db00ed6:	mov    QWORD PTR [r12+0x398],r11
    7c479db00ede:	mov    edi,0x410728
    7c479db00ee3:	mov    QWORD PTR [r12+0x100],rdi
    7c479db00eeb:	add    rsp,0x10
    7c479db00eef:	nop
    7c479db00ef0:	jmp    QWORD PTR [rip+0x2]        # 0x7c479db00ef8
    7c479db00ef6:	xchg   ax,ax
    7c479db00ef8:	loopne 0x7c479db00edf
    7c479db00efa:	scas   eax,DWORD PTR es:[rdi]
    7c479db00efb:	popf
    7c479db00efc:	rex.RXB jl 0x7c479db00eff
    7c479db00eff:	add    BYTE PTR [rax],cl
    7c479db00f01:	cmpxchg BYTE PTR [rbp+0x7c47],bl
    7c479db00f08:	movabs r11,0x62fe87327940
    7c479db00f12:	jmp    r11
    7c479db00f15:	mov    r13,QWORD PTR [r12+0x98]
    7c479db00f1d:	ror    r13,0x3d
    7c479db00f21:	and    r13,0xfffffffffffffff8
    7c479db00f25:	mov    r14,QWORD PTR [r12+0xf8]
    7c479db00f2d:	mov    r15,r14
    7c479db00f30:	add    r15,0x100
    7c479db00f37:	mov    QWORD PTR [r12],r15
    7c479db00f3b:	mov    r15,r14
    7c479db00f3e:	add    r15,0x170
    7c479db00f45:	mov    QWORD PTR [r12+0x8],r15
    7c479db00f4a:	mov    r15d,0x8
    7c479db00f50:	mov    QWORD PTR [r12+0x10],r15
    7c479db00f55:	movabs rcx,0xff00ff00ff00ff
    7c479db00f5f:	mov    r15,r13
    7c479db00f62:	and    r15,rcx
    7c479db00f65:	shl    r15,0x8
    7c479db00f69:	movabs rcx,0xff00ff00ff00ff00
    7c479db00f73:	and    r13,rcx
    7c479db00f76:	shr    r13,0x8
    7c479db00f7a:	or     r13,r15
    7c479db00f7d:	movabs rcx,0xffff0000ffff
    7c479db00f87:	mov    r15,r13
    7c479db00f8a:	and    r15,rcx
    7c479db00f8d:	shl    r15,0x10
    7c479db00f91:	movabs rcx,0xffff0000ffff0000
    7c479db00f9b:	and    r13,rcx
    7c479db00f9e:	shr    r13,0x10
    7c479db00fa2:	or     r13,r15
    7c479db00fa5:	mov    r15,r13
    7c479db00fa8:	shl    r15,0x20
    7c479db00fac:	shr    r13,0x20
    7c479db00fb0:	or     r13,r15
    7c479db00fb3:	mov    QWORD PTR [r12+0x40],r13
    7c479db00fb8:	add    r14,0x170
    7c479db00fbf:	mov    QWORD PTR [r14],r13
    7c479db00fc2:	mov    r13d,0x0
    7c479db00fc8:	mov    DWORD PTR [r12+0x32c],r13d
    7c479db00fd0:	mov    r13d,0x4102f0
    7c479db00fd6:	mov    QWORD PTR [r12+0xf0],r13
    7c479db00fde:	mov    r13d,0x410728
    7c479db00fe4:	mov    QWORD PTR [r12+0x100],r13
    7c479db00fec:	mov    r11,QWORD PTR [rsp]
    7c479db00ff0:	mov    QWORD PTR [r12+0x398],r11
    7c479db00ff8:	mov    edi,0x410728
    7c479db00ffd:	mov    QWORD PTR [r12+0x100],rdi
    7c479db01005:	add    rsp,0x10
    7c479db01009:	nop    DWORD PTR [rax+0x0]
    7c479db01010:	jmp    QWORD PTR [rip+0x2]        # 0x7c479db01018
    7c479db01016:	xchg   ax,ax
    7c479db01018:	loopne 0x7c479db00fff
    7c479db0101a:	scas   eax,DWORD PTR es:[rdi]
    7c479db0101b:	popf
    7c479db0101c:	rex.RXB jl 0x7c479db0101f
    7c479db0101f:	add    BYTE PTR [rax],ch
    7c479db01021:	adc    BYTE PTR [rax+0x7c479d],dh
    7c479db01027:	add    BYTE PTR [rcx-0x45],cl
    7c479db0102a:	rex jns 0x7c479db0105f
    7c479db0102d:	xchg   esi,edi
    7c479db0102f:	(bad)
    7c479db01030:	add    BYTE PTR [rax],al
    7c479db01032:	jmp    r11
    7c479db01035:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db01040:	sub    rsp,0x10
    7c479db01044:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0104c:	mov    QWORD PTR [rsp],r11
    7c479db01050:	jmp    0x7c479db00e89
    7c479db01055:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7c479db01060:	sub    rsp,0x10
    7c479db01064:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0106c:	mov    QWORD PTR [rsp],r11
    7c479db01070:	jmp    0x7c479db00f15
    7c479db01075:	nop
    7c479db01076:	nop
    7c479db01077:	nop
