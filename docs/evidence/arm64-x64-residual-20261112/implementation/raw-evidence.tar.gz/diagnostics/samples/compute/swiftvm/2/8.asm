
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/2/8.bin:     file format binary


Disassembly of section .data:

0000730a04102170 <.data>:
    730a04102170:	sub    rsp,0x150
    730a04102177:	mov    r11,QWORD PTR [r12+0x398]
    730a0410217f:	mov    QWORD PTR [rsp],r11
    730a04102183:	cmp    DWORD PTR [r12+0x310],0x0
    730a0410218c:	je     0x730a04102217
    730a04102192:	push   rdx
    730a04102193:	push   rsi
    730a04102194:	push   r10
    730a04102196:	push   r11
    730a04102198:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410219d:	mov    r10d,edx
    730a041021a0:	and    r10d,0xc000
    730a041021a7:	shl    r10d,0x10
    730a041021ab:	mov    r11d,edx
    730a041021ae:	and    r11d,0x100
    730a041021b5:	shl    r11d,0x15
    730a041021b9:	or     r10d,r11d
    730a041021bc:	and    edx,0x1
    730a041021bf:	shl    edx,0x1c
    730a041021c2:	or     r10d,edx
    730a041021c5:	btc    r10,0x1d
    730a041021ca:	mov    r11d,0xf0000000
    730a041021d0:	and    r11,r10
    730a041021d3:	movabs rsi,0xffffffff0fffffff
    730a041021dd:	and    rbx,rsi
    730a041021e0:	or     rbx,r11
    730a041021e3:	pop    r11
    730a041021e5:	pop    r10
    730a041021e7:	pop    rsi
    730a041021e8:	pop    rdx
    730a041021e9:	mov    QWORD PTR [r12+0x108],rbx
    730a041021f1:	mov    eax,0x4103f8
    730a041021f6:	mov    QWORD PTR [r12+0x100],rax
    730a041021fe:	add    rsp,0x150
    730a04102205:	mov    eax,0x3
    730a0410220a:	movabs r11,0x5591a9c2cca0
    730a04102214:	jmp    r11
    730a04102217:	mov    r13d,DWORD PTR [r12+0x98]
    730a0410221f:	add    r13d,0x1
    730a04102223:	mov    QWORD PTR [r12+0x98],r13
    730a0410222b:	sub    r13d,0x10000
    730a04102232:	mov    rcx,QWORD PTR [r12+0x380]
    730a0410223a:	jrcxz  0x730a04102241
    730a0410223c:	jmp    0x730a0410bbf5
    730a04102241:	jne    0x730a0410225a
    730a04102247:	mov    r11,rax
    730a0410224a:	lahf
    730a0410224b:	seto   al
    730a0410224e:	mov    WORD PTR [rsp],ax
    730a04102252:	mov    rax,r11
    730a04102255:	jmp    0x730a0410226d
    730a0410225a:	mov    r11,rax
    730a0410225d:	lahf
    730a0410225e:	seto   al
    730a04102261:	mov    WORD PTR [rsp],ax
    730a04102265:	mov    rax,r11
    730a04102268:	jmp    0x730a04104d43
    730a0410226d:	mov    r13d,0x420000
    730a04102273:	mov    QWORD PTR [r12+0x40],r13
    730a04102278:	movabs r13,0x100000001
    730a04102282:	mov    r14d,0x0
    730a04102288:	mov    QWORD PTR [r12+0x110],r13
    730a04102290:	mov    QWORD PTR [r12+0x118],r14
    730a04102298:	movabs r13,0x3fa0000000000000
    730a041022a2:	mov    QWORD PTR [r12+0x50],r13
    730a041022a7:	mov    r13d,0x420b10
    730a041022ad:	mov    r14,QWORD PTR [r13+0x0]
    730a041022b1:	mov    r13d,0x0
    730a041022b7:	mov    QWORD PTR [r12+0x120],r14
    730a041022bf:	mov    QWORD PTR [r12+0x128],r13
    730a041022c7:	movabs r13,0x4100000041
    730a041022d1:	mov    r14d,0x0
    730a041022d7:	mov    QWORD PTR [r12+0x140],r13
    730a041022df:	mov    QWORD PTR [r12+0x148],r14
    730a041022e7:	movabs r13,0x3fc0000000000000
    730a041022f1:	movabs r14,0x3fc0000000000000
    730a041022fb:	mov    QWORD PTR [r12+0x150],r13
    730a04102303:	mov    QWORD PTR [r12+0x158],r14
    730a0410230b:	movabs r13,0x200000002
    730a04102315:	mov    r14d,0x0
    730a0410231b:	mov    QWORD PTR [r12+0x160],r13
    730a04102323:	mov    QWORD PTR [r12+0x168],r14
    730a0410232b:	movabs r13,0x3fa0000000000000
    730a04102335:	mov    QWORD PTR [r12+0x130],r13
    730a0410233d:	mov    QWORD PTR [r12+0x138],r13
    730a04102345:	mov    r13d,0x2
    730a0410234b:	mov    QWORD PTR [r12+0x170],r13
    730a04102353:	mov    QWORD PTR [r12+0x178],r13
    730a0410235b:	mov    r13d,0x420000
    730a04102361:	mov    QWORD PTR [r12+0x40],r13
    730a04102366:	mov    r13d,0x430000
    730a0410236c:	mov    QWORD PTR [r12+0x50],r13
    730a04102371:	mov    r13d,0x420a40
    730a04102377:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    730a0410237d:	movdqu XMMWORD PTR [r12+0x180],xmm2
    730a04102387:	mov    r13d,0x0
    730a0410238d:	mov    QWORD PTR [r12+0x48],r13
    730a04102392:	mov    r13d,0x431000
    730a04102398:	add    r13,0xe00
    730a0410239f:	mov    QWORD PTR [r12+0x40],r13
    730a041023a4:	mov    r13d,0x430cb8
    730a041023aa:	mov    r14d,DWORD PTR [r12]
    730a041023ae:	mov    DWORD PTR [r13+0x0],r14d
    730a041023b2:	mov    r13d,0x0
    730a041023b8:	mov    DWORD PTR [r12+0x32c],r13d
    730a041023c0:	mov    r13d,0x432000
    730a041023c6:	mov    QWORD PTR [r12+0x50],r13
    730a041023cb:	mov    r11,rax
    730a041023ce:	movzx  eax,WORD PTR [rsp]
    730a041023d2:	add    al,0x7f
    730a041023d4:	sahf
    730a041023d5:	mov    rax,r11
    730a041023d8:	jmp    0x730a041023dd
    730a041023dd:	mov    r13,QWORD PTR [r12+0x180]
    730a041023e5:	mov    r14,QWORD PTR [r12+0x188]
    730a041023ed:	mov    r15d,0x0
    730a041023f3:	mov    r11,rax
    730a041023f6:	lahf
    730a041023f7:	seto   al
    730a041023fa:	mov    WORD PTR [rsp],ax
    730a041023fe:	mov    rax,r11
    730a04102401:	mov    ecx,0xffffffff
    730a04102406:	and    r13,rcx
    730a04102409:	mov    rbp,r15
    730a0410240c:	or     rbp,r13
    730a0410240f:	mov    ecx,0xffffffff
    730a04102414:	and    r14,rcx
    730a04102417:	shl    r14,0x20
    730a0410241b:	or     rbp,r14
    730a0410241e:	mov    QWORD PTR [r12+0x210],rbp
    730a04102426:	mov    QWORD PTR [r12+0x218],r15
    730a0410242e:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    730a04102438:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    730a04102442:	movdqa xmm1,xmm3
    730a04102446:	psubd  xmm2,xmm1
    730a0410244a:	movdqa xmm14,xmm2
    730a0410244f:	movdqa xmm1,xmm14
    730a04102454:	movq   rax,xmm1
    730a04102459:	mov    r13,rax
    730a0410245c:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    730a04102466:	movdqu xmm4,XMMWORD PTR [r12+0x170]
    730a04102470:	movdqa xmm1,xmm4
    730a04102474:	paddq  xmm2,xmm1
    730a04102478:	movdqu XMMWORD PTR [r12+0x180],xmm2
    730a04102482:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    730a0410248c:	movdqa xmm1,xmm2
    730a04102490:	paddd  xmm3,xmm1
    730a04102494:	movdqa xmm14,xmm3
    730a04102499:	movdqa xmm1,xmm14
    730a0410249e:	movq   rax,xmm1
    730a041024a3:	mov    r14,rax
    730a041024a6:	mov    r15d,0x0
    730a041024ac:	mov    QWORD PTR [r12+0x120],r14
    730a041024b4:	mov    QWORD PTR [r12+0x128],r15
    730a041024bc:	mov    r14d,0x0
    730a041024c2:	mov    ecx,0xffffffff
    730a041024c7:	mov    r15,r13
    730a041024ca:	and    r15,rcx
    730a041024cd:	mov    rbp,r14
    730a041024d0:	or     rbp,r15
    730a041024d3:	shr    r13,0x20
    730a041024d7:	mov    ecx,0xffffffff
    730a041024dc:	and    r13,rcx
    730a041024df:	or     r14,r13
    730a041024e2:	mov    QWORD PTR [r12+0x220],rbp
    730a041024ea:	mov    QWORD PTR [r12+0x228],r14
    730a041024f2:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    730a041024fc:	movdqu xmm3,XMMWORD PTR [r12+0x110]
    730a04102506:	movdqa xmm1,xmm3
    730a0410250a:	paddd  xmm2,xmm1
    730a0410250e:	movdqa xmm14,xmm2
    730a04102513:	movdqa xmm1,xmm14
    730a04102518:	movq   rax,xmm1
    730a0410251d:	mov    r13,rax
    730a04102520:	mov    r14d,0x0
    730a04102526:	mov    QWORD PTR [r12+0x210],r13
    730a0410252e:	mov    QWORD PTR [r12+0x218],r14
    730a04102536:	lea    r13,[r12]
    730a0410253a:	movabs r14,0xb6e61da31
    730a04102544:	mov    r15d,0x410468
    730a0410254a:	mov    rdx,QWORD PTR [rsp]
    730a0410254e:	mov    r10d,edx
    730a04102551:	and    r10d,0xc000
    730a04102558:	shl    r10d,0x10
    730a0410255c:	mov    r11d,edx
    730a0410255f:	and    r11d,0x100
    730a04102566:	shl    r11d,0x15
    730a0410256a:	or     r10d,r11d
    730a0410256d:	and    edx,0x1
    730a04102570:	shl    edx,0x1c
    730a04102573:	or     r10d,edx
    730a04102576:	btc    r10,0x1d
    730a0410257b:	mov    r11d,0xf0000000
    730a04102581:	and    r11,r10
    730a04102584:	movabs rsi,0xffffffff0fffffff
    730a0410258e:	and    rbx,rsi
    730a04102591:	or     rbx,r11
    730a04102594:	mov    QWORD PTR [r12+0x378],0x3
    730a041025a0:	mov    QWORD PTR [r12+0x108],rbx
    730a041025a8:	stmxcsr DWORD PTR [r12-0x28]
    730a041025ae:	mov    r10d,DWORD PTR [r12-0x28]
    730a041025b3:	test   r10d,0x3f
    730a041025ba:	je     0x730a041025df
    730a041025c0:	mov    r11d,r10d
    730a041025c3:	shr    r10d,1
    730a041025c6:	and    r10d,0x1e
    730a041025ca:	and    r11d,0x1
    730a041025ce:	or     r10d,r11d
    730a041025d1:	or     DWORD PTR [r12+0x314],r10d
    730a041025d9:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a041025df:	ldmxcsr DWORD PTR [r12-0x38]
    730a041025e5:	movabs r11,0x5591a9a8e5e0
    730a041025ef:	mov    rdi,r13
    730a041025f2:	mov    rsi,r14
    730a041025f5:	mov    rdx,r15
    730a041025f8:	call   r11
    730a041025fb:	ldmxcsr DWORD PTR [r12-0x28]
    730a04102601:	mov    rbx,QWORD PTR [r12+0x108]
    730a04102609:	mov    QWORD PTR [r12+0x378],0x2
    730a04102615:	mov    rbp,rax
    730a04102618:	mov    r13,QWORD PTR [r12+0x210]
    730a04102620:	mov    r14d,0x0
    730a04102626:	mov    ecx,0xffffffff
    730a0410262b:	mov    r15,r13
    730a0410262e:	and    r15,rcx
    730a04102631:	mov    rbp,r14
    730a04102634:	or     rbp,r15
    730a04102637:	shr    r13,0x20
    730a0410263b:	mov    ecx,0xffffffff
    730a04102640:	and    r13,rcx
    730a04102643:	or     r14,r13
    730a04102646:	mov    QWORD PTR [r12+0x210],rbp
    730a0410264e:	mov    QWORD PTR [r12+0x218],r14
    730a04102656:	lea    r13,[r12]
    730a0410265a:	movabs r14,0xb6e61da10
    730a04102664:	mov    r15d,0x410470
    730a0410266a:	mov    QWORD PTR [r12+0x378],0x3
    730a04102676:	mov    QWORD PTR [r12+0x108],rbx
    730a0410267e:	stmxcsr DWORD PTR [r12-0x28]
    730a04102684:	mov    r10d,DWORD PTR [r12-0x28]
    730a04102689:	test   r10d,0x3f
    730a04102690:	je     0x730a041026b5
    730a04102696:	mov    r11d,r10d
    730a04102699:	shr    r10d,1
    730a0410269c:	and    r10d,0x1e
    730a041026a0:	and    r11d,0x1
    730a041026a4:	or     r10d,r11d
    730a041026a7:	or     DWORD PTR [r12+0x314],r10d
    730a041026af:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a041026b5:	ldmxcsr DWORD PTR [r12-0x38]
    730a041026bb:	movabs r11,0x5591a9a8e5e0
    730a041026c5:	mov    rdi,r13
    730a041026c8:	mov    rsi,r14
    730a041026cb:	mov    rdx,r15
    730a041026ce:	call   r11
    730a041026d1:	ldmxcsr DWORD PTR [r12-0x28]
    730a041026d7:	mov    rbx,QWORD PTR [r12+0x108]
    730a041026df:	mov    QWORD PTR [r12+0x378],0x2
    730a041026eb:	mov    rbp,rax
    730a041026ee:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    730a041026f8:	movdqu xmm3,XMMWORD PTR [r12+0x150]
    730a04102702:	movdqa xmm0,xmm2
    730a04102706:	movdqa xmm1,xmm3
    730a0410270a:	mulpd  xmm0,xmm1
    730a0410270e:	movdqa xmm14,xmm0
    730a04102713:	movdqu xmm15,XMMWORD PTR [rip+0x9f34]        # 0x730a0410c650
    730a0410271c:	pand   xmm14,xmm15
    730a04102721:	movdqu xmm15,XMMWORD PTR [rip+0x9f36]        # 0x730a0410c660
    730a0410272a:	pcmpeqq xmm14,xmm15
    730a04102730:	movdqa xmm15,xmm0
    730a04102735:	cmpunordpd xmm15,xmm0
    730a0410273b:	por    xmm14,xmm15
    730a04102740:	pmovmskb ecx,xmm14
    730a04102745:	jrcxz  0x730a0410274c
    730a04102747:	jmp    0x730a04104dbd
    730a0410274c:	movdqa xmm4,xmm0
    730a04102750:	movdqu XMMWORD PTR [r12+0x220],xmm4
    730a0410275a:	mov    r13,QWORD PTR [r12+0x48]
    730a0410275f:	mov    r14,QWORD PTR [r12+0x50]
    730a04102764:	add    r14,r13
    730a04102767:	movdqu XMMWORD PTR [r14],xmm4
    730a0410276c:	mov    r14d,0x0
    730a04102772:	mov    DWORD PTR [r12+0x32c],r14d
    730a0410277a:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    730a04102784:	movdqu xmm3,XMMWORD PTR [r12+0x130]
    730a0410278e:	movdqa xmm0,xmm2
    730a04102792:	movdqa xmm1,xmm3
    730a04102796:	mulpd  xmm0,xmm1
    730a0410279a:	movdqa xmm14,xmm0
    730a0410279f:	movdqu xmm15,XMMWORD PTR [rip+0x9ea8]        # 0x730a0410c650
    730a041027a8:	pand   xmm14,xmm15
    730a041027ad:	movdqu xmm15,XMMWORD PTR [rip+0x9eaa]        # 0x730a0410c660
    730a041027b6:	pcmpeqq xmm14,xmm15
    730a041027bc:	movdqa xmm15,xmm0
    730a041027c1:	cmpunordpd xmm15,xmm0
    730a041027c7:	por    xmm14,xmm15
    730a041027cc:	pmovmskb ecx,xmm14
    730a041027d1:	jrcxz  0x730a041027d8
    730a041027d3:	jmp    0x730a04104de1
    730a041027d8:	movdqa xmm4,xmm0
    730a041027dc:	movdqu XMMWORD PTR [r12+0x210],xmm4
    730a041027e6:	mov    r14,QWORD PTR [r12+0x40]
    730a041027eb:	add    r14,r13
    730a041027ee:	movdqu XMMWORD PTR [r14],xmm4
    730a041027f3:	add    r13,0x10
    730a041027f7:	mov    QWORD PTR [r12+0x48],r13
    730a041027fc:	sub    r13,0x200
    730a04102803:	mov    rcx,QWORD PTR [r12+0x380]
    730a0410280b:	jrcxz  0x730a04102812
    730a0410280d:	jmp    0x730a0410bc89
    730a04102812:	jne    0x730a041023dd
    730a04102818:	mov    r11,rax
    730a0410281b:	lahf
    730a0410281c:	seto   al
    730a0410281f:	mov    WORD PTR [rsp],ax
    730a04102823:	mov    rax,r11
    730a04102826:	jmp    0x730a0410282b
    730a0410282b:	mov    r13,QWORD PTR [r12+0x50]
    730a04102830:	mov    r14,r13
    730a04102833:	add    r14,0x80
    730a0410283a:	mov    r15,r14
    730a0410283d:	add    r15,0x10
    730a04102841:	movdqu xmm2,XMMWORD PTR [r14]
    730a04102846:	movdqu xmm3,XMMWORD PTR [r15]
    730a0410284b:	movdqu XMMWORD PTR [r12+0x130],xmm2
    730a04102855:	movdqu XMMWORD PTR [r12+0x110],xmm3
    730a0410285f:	mov    r14d,0x0
    730a04102865:	mov    r15d,0x0
    730a0410286b:	mov    QWORD PTR [r12+0x1b0],r14
    730a04102873:	mov    QWORD PTR [r12+0x1b8],r15
    730a0410287b:	mov    r14,r13
    730a0410287e:	add    r14,0x40
    730a04102882:	mov    r15,r14
    730a04102885:	add    r15,0x10
    730a04102889:	movdqu xmm4,XMMWORD PTR [r14]
    730a0410288e:	movdqu xmm5,XMMWORD PTR [r15]
    730a04102893:	movdqu XMMWORD PTR [r12+0x250],xmm4
    730a0410289d:	movdqu XMMWORD PTR [r12+0x120],xmm5
    730a041028a7:	mov    r14d,0x0
    730a041028ad:	mov    QWORD PTR [r12+0x48],r14
    730a041028b2:	mov    r14,r13
    730a041028b5:	add    r14,0x10
    730a041028b9:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    730a041028bf:	movdqu xmm6,XMMWORD PTR [r14]
    730a041028c4:	movdqu XMMWORD PTR [r12+0x170],xmm4
    730a041028ce:	movdqu XMMWORD PTR [r12+0x180],xmm6
    730a041028d8:	mov    r14,QWORD PTR [r12+0xf8]
    730a041028e0:	mov    r15,r14
    730a041028e3:	add    r15,0xe0
    730a041028ea:	mov    rbp,r15
    730a041028ed:	add    rbp,0x10
    730a041028f1:	movdqu XMMWORD PTR [r15],xmm3
    730a041028f6:	mov    r15d,0x0
    730a041028fc:	mov    DWORD PTR [r12+0x32c],r15d
    730a04102904:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    730a04102909:	mov    r15,r13
    730a0410290c:	add    r15,0xc0
    730a04102913:	mov    rbp,r15
    730a04102916:	add    rbp,0x10
    730a0410291a:	movdqu xmm2,XMMWORD PTR [r15]
    730a0410291f:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    730a04102924:	movdqu XMMWORD PTR [r12+0x130],xmm2
    730a0410292e:	movdqu XMMWORD PTR [r12+0x110],xmm3
    730a04102938:	mov    r15,r13
    730a0410293b:	add    r15,0x140
    730a04102942:	mov    rbp,r15
    730a04102945:	add    rbp,0x10
    730a04102949:	movdqu xmm7,XMMWORD PTR [r15]
    730a0410294e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    730a04102954:	movdqu XMMWORD PTR [r12+0x270],xmm7
    730a0410295e:	movdqu XMMWORD PTR [r12+0x190],xmm8
    730a04102968:	mov    r15,r13
    730a0410296b:	add    r15,0x180
    730a04102972:	mov    rbp,r15
    730a04102975:	add    rbp,0x10
    730a04102979:	movdqu xmm7,XMMWORD PTR [r15]
    730a0410297e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    730a04102984:	movdqu XMMWORD PTR [r12+0x2a0],xmm7
    730a0410298e:	movdqu XMMWORD PTR [r12+0x1a0],xmm8
    730a04102998:	mov    r15,r14
    730a0410299b:	add    r15,0xc0
    730a041029a2:	mov    rbp,r15
    730a041029a5:	add    rbp,0x10
    730a041029a9:	movdqu XMMWORD PTR [r15],xmm3
    730a041029ae:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    730a041029b3:	mov    r15,r13
    730a041029b6:	add    r15,0x100
    730a041029bd:	mov    rbp,r15
    730a041029c0:	add    rbp,0x10
    730a041029c4:	movdqu xmm2,XMMWORD PTR [r15]
    730a041029c9:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    730a041029ce:	movdqu XMMWORD PTR [r12+0x110],xmm2
    730a041029d8:	movdqu XMMWORD PTR [r12+0x300],xmm3
    730a041029e2:	mov    r15,r13
    730a041029e5:	add    r15,0x1c0
    730a041029ec:	mov    rbp,r15
    730a041029ef:	add    rbp,0x10
    730a041029f3:	movdqu xmm3,XMMWORD PTR [r15]
    730a041029f8:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    730a041029fd:	movdqu XMMWORD PTR [r12+0x240],xmm3
    730a04102a07:	movdqu XMMWORD PTR [r12+0x1c0],xmm7
    730a04102a11:	mov    r15,r13
    730a04102a14:	add    r15,0x20
    730a04102a18:	mov    rbp,r15
    730a04102a1b:	add    rbp,0x10
    730a04102a1f:	movdqu xmm7,XMMWORD PTR [r15]
    730a04102a24:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    730a04102a2a:	movdqu XMMWORD PTR [r12+0x1d0],xmm7
    730a04102a34:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
    730a04102a3e:	mov    r15,r14
    730a04102a41:	add    r15,0x20
    730a04102a45:	mov    rbp,r15
    730a04102a48:	add    rbp,0x10
    730a04102a4c:	movdqu XMMWORD PTR [r15],xmm2
    730a04102a51:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    730a04102a56:	mov    r15,r13
    730a04102a59:	add    r15,0x60
    730a04102a5d:	mov    rbp,r15
    730a04102a60:	add    rbp,0x10
    730a04102a64:	movdqu xmm2,XMMWORD PTR [r15]
    730a04102a69:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    730a04102a6e:	movdqu XMMWORD PTR [r12+0x110],xmm2
    730a04102a78:	movdqu XMMWORD PTR [r12+0x120],xmm5
    730a04102a82:	mov    r15,r14
    730a04102a85:	add    r15,0x60
    730a04102a89:	mov    rbp,r15
    730a04102a8c:	add    rbp,0x10
    730a04102a90:	movdqu XMMWORD PTR [r15],xmm4
    730a04102a95:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    730a04102a9a:	mov    r15,r13
    730a04102a9d:	add    r15,0xe0
    730a04102aa4:	mov    rbp,r15
    730a04102aa7:	add    rbp,0x10
    730a04102aab:	movdqu xmm3,XMMWORD PTR [r15]
    730a04102ab0:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    730a04102ab5:	movdqu XMMWORD PTR [r12+0x200],xmm3
    730a04102abf:	movdqu XMMWORD PTR [r12+0x2d0],xmm4
    730a04102ac9:	mov    r15,r13
    730a04102acc:	add    r15,0x120
    730a04102ad3:	mov    rbp,r15
    730a04102ad6:	add    rbp,0x10
    730a04102ada:	movdqu xmm3,XMMWORD PTR [r15]
    730a04102adf:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    730a04102ae4:	movdqu XMMWORD PTR [r12+0x2e0],xmm3
    730a04102aee:	movdqu XMMWORD PTR [r12+0x2f0],xmm4
    730a04102af8:	mov    r15,r14
    730a04102afb:	add    r15,0xa0
    730a04102b02:	mov    rbp,r15
    730a04102b05:	add    rbp,0x10
    730a04102b09:	movdqu XMMWORD PTR [r15],xmm5
    730a04102b0e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    730a04102b13:	mov    r15,r13
    730a04102b16:	add    r15,0xa0
    730a04102b1d:	mov    rbp,r15
    730a04102b20:	add    rbp,0x10
    730a04102b24:	movdqu xmm2,XMMWORD PTR [r15]
    730a04102b29:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    730a04102b2e:	movdqu XMMWORD PTR [r12+0x110],xmm2
    730a04102b38:	movdqu XMMWORD PTR [r12+0x120],xmm3
    730a04102b42:	mov    r15,r13
    730a04102b45:	add    r15,0x160
    730a04102b4c:	mov    rbp,r15
    730a04102b4f:	add    rbp,0x10
    730a04102b53:	movdqu xmm4,XMMWORD PTR [r15]
    730a04102b58:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    730a04102b5d:	movdqu XMMWORD PTR [r12+0x2c0],xmm4
    730a04102b67:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
    730a04102b71:	mov    r15,r13
    730a04102b74:	add    r15,0x1a0
    730a04102b7b:	mov    rbp,r15
    730a04102b7e:	add    rbp,0x10
    730a04102b82:	movdqu xmm5,XMMWORD PTR [r15]
    730a04102b87:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    730a04102b8c:	movdqu XMMWORD PTR [r12+0x290],xmm5
    730a04102b96:	movdqu XMMWORD PTR [r12+0x1e0],xmm7
    730a04102ba0:	mov    r15,r14
    730a04102ba3:	add    r15,0x80
    730a04102baa:	mov    rbp,r15
    730a04102bad:	add    rbp,0x10
    730a04102bb1:	movdqu XMMWORD PTR [r15],xmm3
    730a04102bb6:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    730a04102bbb:	add    r13,0x1e0
    730a04102bc2:	mov    r15,r13
    730a04102bc5:	add    r15,0x10
    730a04102bc9:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    730a04102bcf:	movdqu xmm3,XMMWORD PTR [r15]
    730a04102bd4:	movdqu XMMWORD PTR [r12+0x230],xmm2
    730a04102bde:	movdqu XMMWORD PTR [r12+0x280],xmm3
    730a04102be8:	mov    r13d,0x432000
    730a04102bee:	add    r13,0x200
    730a04102bf5:	mov    QWORD PTR [r12+0x50],r13
    730a04102bfa:	mov    r13,r14
    730a04102bfd:	add    r13,0x40
    730a04102c01:	mov    r15,r13
    730a04102c04:	add    r15,0x10
    730a04102c08:	movdqu XMMWORD PTR [r13+0x0],xmm4
    730a04102c0e:	movdqu XMMWORD PTR [r15],xmm6
    730a04102c13:	mov    r13,r14
    730a04102c16:	add    r13,0x10
    730a04102c1a:	movdqu XMMWORD PTR [r14],xmm3
    730a04102c1f:	movdqu XMMWORD PTR [r13+0x0],xmm2
    730a04102c25:	mov    r11,rax
    730a04102c28:	movzx  eax,WORD PTR [rsp]
    730a04102c2c:	add    al,0x7f
    730a04102c2e:	sahf
    730a04102c2f:	mov    rax,r11
    730a04102c32:	jmp    0x730a04102c37
    730a04102c37:	mov    r13d,0x0
    730a04102c3d:	mov    QWORD PTR [r12+0x58],r13
    730a04102c42:	mov    r11,rax
    730a04102c45:	lahf
    730a04102c46:	seto   al
    730a04102c49:	mov    WORD PTR [rsp],ax
    730a04102c4d:	mov    rax,r11
    730a04102c50:	jmp    0x730a04102c55
    730a04102c55:	mov    r13,QWORD PTR [r12+0x58]
    730a04102c5a:	mov    r14,QWORD PTR [r12+0x40]
    730a04102c5f:	add    r14,r13
    730a04102c62:	mov    QWORD PTR [r12+0x60],r14
    730a04102c67:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    730a04102c71:	movdqa xmm0,xmm2
    730a04102c75:	movdqa xmm1,xmm2
    730a04102c79:	por    xmm0,xmm1
    730a04102c7d:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    730a04102c87:	movdqu xmm4,XMMWORD PTR [r12+0x1a0]
    730a04102c91:	movdqa xmm0,xmm4
    730a04102c95:	movdqa xmm1,xmm4
    730a04102c99:	por    xmm0,xmm1
    730a04102c9d:	movdqu XMMWORD PTR [r12+0x120],xmm0
    730a04102ca7:	mov    r15,r14
    730a04102caa:	add    r15,0x30
    730a04102cae:	mov    rbp,r15
    730a04102cb1:	add    rbp,0x8
    730a04102cb5:	mov    r8,QWORD PTR [r15]
    730a04102cb8:	mov    r15,QWORD PTR [rbp+0x0]
    730a04102cbc:	mov    ebp,0x0
    730a04102cc1:	mov    QWORD PTR [r12+0x130],r8
    730a04102cc9:	mov    QWORD PTR [r12+0x138],rbp
    730a04102cd1:	mov    ebp,0x0
    730a04102cd6:	mov    QWORD PTR [r12+0x280],r15
    730a04102cde:	mov    QWORD PTR [r12+0x288],rbp
    730a04102ce6:	movdqu xmm5,XMMWORD PTR [r12+0x270]
    730a04102cf0:	movdqa xmm0,xmm5
    730a04102cf4:	movdqa xmm1,xmm5
    730a04102cf8:	por    xmm0,xmm1
    730a04102cfc:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    730a04102d06:	mov    r15,r14
    730a04102d09:	add    r15,0x20
    730a04102d0d:	mov    rbp,r15
    730a04102d10:	add    rbp,0x8
    730a04102d14:	mov    r8,QWORD PTR [r15]
    730a04102d17:	mov    r15,QWORD PTR [rbp+0x0]
    730a04102d1b:	mov    ebp,0x0
    730a04102d20:	mov    QWORD PTR [r12+0x150],r8
    730a04102d28:	mov    QWORD PTR [r12+0x158],rbp
    730a04102d30:	mov    ebp,0x0
    730a04102d35:	mov    QWORD PTR [r12+0x140],r15
    730a04102d3d:	mov    QWORD PTR [r12+0x148],rbp
    730a04102d45:	mov    r15,r14
    730a04102d48:	add    r15,0x10
    730a04102d4c:	mov    rbp,r15
    730a04102d4f:	add    rbp,0x8
    730a04102d53:	mov    r8,QWORD PTR [r15]
    730a04102d56:	mov    r15,QWORD PTR [rbp+0x0]
    730a04102d5a:	mov    ebp,0x0
    730a04102d5f:	mov    QWORD PTR [r12+0x170],r8
    730a04102d67:	mov    QWORD PTR [r12+0x178],rbp
    730a04102d6f:	mov    ebp,0x0
    730a04102d74:	mov    QWORD PTR [r12+0x160],r15
    730a04102d7c:	mov    QWORD PTR [r12+0x168],rbp
    730a04102d84:	mov    r15d,0x8
    730a04102d8a:	mov    rbp,QWORD PTR [r14]
    730a04102d8d:	mov    QWORD PTR [r12+0x180],rbp
    730a04102d95:	mov    QWORD PTR [r12+0x188],rbp
    730a04102d9d:	add    r14,r15
    730a04102da0:	mov    QWORD PTR [r12+0x60],r14
    730a04102da5:	mov    r15,QWORD PTR [r14]
    730a04102da8:	mov    r14d,0x0
    730a04102dae:	mov    QWORD PTR [r12+0x230],r15
    730a04102db6:	mov    QWORD PTR [r12+0x238],r14
    730a04102dbe:	mov    r14,QWORD PTR [r12+0xf8]
    730a04102dc6:	mov    r15,r14
    730a04102dc9:	add    r15,0x50
    730a04102dcd:	mov    rbp,r15
    730a04102dd0:	add    rbp,0x10
    730a04102dd4:	movdqu xmm6,XMMWORD PTR [r15]
    730a04102dd9:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    730a04102dde:	movdqu XMMWORD PTR [r12+0x220],xmm6
    730a04102de8:	movdqu XMMWORD PTR [r12+0x210],xmm7
    730a04102df2:	mov    r15,r14
    730a04102df5:	add    r15,0x30
    730a04102df9:	movdqu xmm8,XMMWORD PTR [r15]
    730a04102dfe:	movdqu XMMWORD PTR [r12+0x110],xmm8
    730a04102e08:	mov    r15,QWORD PTR [r12+0x50]
    730a04102e0d:	add    r15,r13
    730a04102e10:	mov    QWORD PTR [r12+0x60],r15
    730a04102e15:	add    r13,0x40
    730a04102e19:	mov    QWORD PTR [r12+0x58],r13
    730a04102e1e:	movdqu xmm9,XMMWORD PTR [r12+0x180]
    730a04102e28:	movdqa xmm0,xmm9
    730a04102e2d:	movdqa xmm1,xmm2
    730a04102e31:	mulpd  xmm0,xmm1
    730a04102e35:	movdqa xmm14,xmm0
    730a04102e3a:	movdqu xmm15,XMMWORD PTR [rip+0x980d]        # 0x730a0410c650
    730a04102e43:	pand   xmm14,xmm15
    730a04102e48:	movdqu xmm15,XMMWORD PTR [rip+0x980f]        # 0x730a0410c660
    730a04102e51:	pcmpeqq xmm14,xmm15
    730a04102e57:	movdqa xmm15,xmm0
    730a04102e5c:	cmpunordpd xmm15,xmm0
    730a04102e62:	por    xmm14,xmm15
    730a04102e67:	pmovmskb ecx,xmm14
    730a04102e6c:	jrcxz  0x730a04102e73
    730a04102e6e:	jmp    0x730a04104e05
    730a04102e73:	movdqa xmm10,xmm0
    730a04102e78:	movdqu xmm2,XMMWORD PTR [r12+0x230]
    730a04102e82:	movdqa xmm0,xmm8
    730a04102e87:	movdqa xmm1,xmm2
    730a04102e8b:	pshufd xmm1,xmm1,0x44
    730a04102e90:	mulpd  xmm0,xmm1
    730a04102e94:	movdqa xmm14,xmm0
    730a04102e99:	movdqu xmm15,XMMWORD PTR [rip+0x97ae]        # 0x730a0410c650
    730a04102ea2:	pand   xmm14,xmm15
    730a04102ea7:	movdqu xmm15,XMMWORD PTR [rip+0x97b0]        # 0x730a0410c660
    730a04102eb0:	pcmpeqq xmm14,xmm15
    730a04102eb6:	movdqa xmm15,xmm0
    730a04102ebb:	cmpunordpd xmm15,xmm0
    730a04102ec1:	por    xmm14,xmm15
    730a04102ec6:	pmovmskb ecx,xmm14
    730a04102ecb:	jrcxz  0x730a04102ed2
    730a04102ecd:	jmp    0x730a04104e2a
    730a04102ed2:	movdqa xmm11,xmm0
    730a04102ed7:	movdqu XMMWORD PTR [r12+0x260],xmm11
    730a04102ee1:	mov    ebp,0x0
    730a04102ee6:	mov    r8d,0x0
    730a04102eec:	mov    QWORD PTR [r12+0x110],rbp
    730a04102ef4:	mov    QWORD PTR [r12+0x118],r8
    730a04102efc:	movdqa xmm0,xmm9
    730a04102f01:	movdqa xmm1,xmm7
    730a04102f05:	mulpd  xmm0,xmm1
    730a04102f09:	movdqa xmm14,xmm0
    730a04102f0e:	movdqu xmm15,XMMWORD PTR [rip+0x9739]        # 0x730a0410c650
    730a04102f17:	pand   xmm14,xmm15
    730a04102f1c:	movdqu xmm15,XMMWORD PTR [rip+0x973b]        # 0x730a0410c660
    730a04102f25:	pcmpeqq xmm14,xmm15
    730a04102f2b:	movdqa xmm15,xmm0
    730a04102f30:	cmpunordpd xmm15,xmm0
    730a04102f36:	por    xmm14,xmm15
    730a04102f3b:	pmovmskb ecx,xmm14
    730a04102f40:	jrcxz  0x730a04102f47
    730a04102f42:	jmp    0x730a04104e4f
    730a04102f47:	movdqa xmm8,xmm0
    730a04102f4c:	movdqa xmm0,xmm9
    730a04102f51:	movdqa xmm1,xmm6
    730a04102f55:	mulpd  xmm0,xmm1
    730a04102f59:	movdqa xmm14,xmm0
    730a04102f5e:	movdqu xmm15,XMMWORD PTR [rip+0x96e9]        # 0x730a0410c650
    730a04102f67:	pand   xmm14,xmm15
    730a04102f6c:	movdqu xmm15,XMMWORD PTR [rip+0x96eb]        # 0x730a0410c660
    730a04102f75:	pcmpeqq xmm14,xmm15
    730a04102f7b:	movdqa xmm15,xmm0
    730a04102f80:	cmpunordpd xmm15,xmm0
    730a04102f86:	por    xmm14,xmm15
    730a04102f8b:	pmovmskb ecx,xmm14
    730a04102f90:	jrcxz  0x730a04102f97
    730a04102f92:	jmp    0x730a04104e74
    730a04102f97:	movdqa xmm7,xmm0
    730a04102f9b:	movdqu xmm6,XMMWORD PTR [r12+0x1f0]
    730a04102fa5:	movdqa xmm0,xmm9
    730a04102faa:	movdqa xmm1,xmm6
    730a04102fae:	mulpd  xmm0,xmm1
    730a04102fb2:	movdqa xmm14,xmm0
    730a04102fb7:	movdqu xmm15,XMMWORD PTR [rip+0x9690]        # 0x730a0410c650
    730a04102fc0:	pand   xmm14,xmm15
    730a04102fc5:	movdqu xmm15,XMMWORD PTR [rip+0x9692]        # 0x730a0410c660
    730a04102fce:	pcmpeqq xmm14,xmm15
    730a04102fd4:	movdqa xmm15,xmm0
    730a04102fd9:	cmpunordpd xmm15,xmm0
    730a04102fdf:	por    xmm14,xmm15
    730a04102fe4:	pmovmskb ecx,xmm14
    730a04102fe9:	jrcxz  0x730a04102ff0
    730a04102feb:	jmp    0x730a04104e99
    730a04102ff0:	movdqa xmm12,xmm0
    730a04102ff5:	movdqu XMMWORD PTR [r12+0x180],xmm12
    730a04102fff:	movdqu xmm6,XMMWORD PTR [r12+0x2a0]
    730a04103009:	movdqa xmm0,xmm6
    730a0410300d:	movdqa xmm1,xmm6
    730a04103011:	por    xmm0,xmm1
    730a04103015:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    730a0410301f:	movdqu xmm9,XMMWORD PTR [r12+0x250]
    730a04103029:	movdqa xmm0,xmm9
    730a0410302e:	movdqa xmm1,xmm9
    730a04103033:	por    xmm0,xmm1
    730a04103037:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    730a04103041:	movdqa xmm0,xmm9
    730a04103046:	movdqa xmm1,xmm2
    730a0410304a:	pshufd xmm1,xmm1,0x44
    730a0410304f:	mulpd  xmm0,xmm1
    730a04103053:	movdqa xmm14,xmm0
    730a04103058:	movdqu xmm15,XMMWORD PTR [rip+0x95ef]        # 0x730a0410c650
    730a04103061:	pand   xmm14,xmm15
    730a04103066:	movdqu xmm15,XMMWORD PTR [rip+0x95f1]        # 0x730a0410c660
    730a0410306f:	pcmpeqq xmm14,xmm15
    730a04103075:	movdqa xmm15,xmm0
    730a0410307a:	cmpunordpd xmm15,xmm0
    730a04103080:	por    xmm14,xmm15
    730a04103085:	pmovmskb ecx,xmm14
    730a0410308a:	jrcxz  0x730a04103091
    730a0410308c:	jmp    0x730a04104ebe
    730a04103091:	movdqa xmm4,xmm0
    730a04103095:	movdqu XMMWORD PTR [r12+0x250],xmm4
    730a0410309f:	sub    r13,0x200
    730a041030a6:	movdqu xmm9,XMMWORD PTR [r12+0x110]
    730a041030b0:	movdqa xmm0,xmm10
    730a041030b5:	movdqa xmm1,xmm9
    730a041030ba:	addpd  xmm0,xmm1
    730a041030be:	movdqa xmm14,xmm0
    730a041030c3:	movdqu xmm15,XMMWORD PTR [rip+0x9584]        # 0x730a0410c650
    730a041030cc:	pand   xmm14,xmm15
    730a041030d1:	movdqu xmm15,XMMWORD PTR [rip+0x9586]        # 0x730a0410c660
    730a041030da:	pcmpeqq xmm14,xmm15
    730a041030e0:	movdqa xmm15,xmm0
    730a041030e5:	cmpunordpd xmm15,xmm0
    730a041030eb:	por    xmm14,xmm15
    730a041030f0:	pmovmskb ecx,xmm14
    730a041030f5:	jrcxz  0x730a041030fc
    730a041030f7:	jmp    0x730a04104ee3
    730a041030fc:	movdqu XMMWORD PTR [r12+0x240],xmm0
    730a04103106:	movdqu xmm10,XMMWORD PTR [r12+0x1b0]
    730a04103110:	movdqa xmm0,xmm8
    730a04103115:	movdqa xmm1,xmm10
    730a0410311a:	addpd  xmm0,xmm1
    730a0410311e:	movdqa xmm14,xmm0
    730a04103123:	movdqu xmm15,XMMWORD PTR [rip+0x9524]        # 0x730a0410c650
    730a0410312c:	pand   xmm14,xmm15
    730a04103131:	movdqu xmm15,XMMWORD PTR [rip+0x9526]        # 0x730a0410c660
    730a0410313a:	pcmpeqq xmm14,xmm15
    730a04103140:	movdqa xmm15,xmm0
    730a04103145:	cmpunordpd xmm15,xmm0
    730a0410314b:	por    xmm14,xmm15
    730a04103150:	pmovmskb ecx,xmm14
    730a04103155:	jrcxz  0x730a0410315c
    730a04103157:	jmp    0x730a04104f24
    730a0410315c:	movdqa xmm6,xmm0
    730a04103160:	movdqu XMMWORD PTR [r12+0x210],xmm6
    730a0410316a:	movdqa xmm0,xmm7
    730a0410316e:	movdqa xmm1,xmm10
    730a04103173:	addpd  xmm0,xmm1
    730a04103177:	movdqa xmm14,xmm0
    730a0410317c:	movdqu xmm15,XMMWORD PTR [rip+0x94cb]        # 0x730a0410c650
    730a04103185:	pand   xmm14,xmm15
    730a0410318a:	movdqu xmm15,XMMWORD PTR [rip+0x94cd]        # 0x730a0410c660
    730a04103193:	pcmpeqq xmm14,xmm15
    730a04103199:	movdqa xmm15,xmm0
    730a0410319e:	cmpunordpd xmm15,xmm0
    730a041031a4:	por    xmm14,xmm15
    730a041031a9:	pmovmskb ecx,xmm14
    730a041031ae:	jrcxz  0x730a041031b5
    730a041031b0:	jmp    0x730a04104f65
    730a041031b5:	movdqa xmm8,xmm0
    730a041031ba:	movdqu XMMWORD PTR [r12+0x220],xmm8
    730a041031c4:	movdqu xmm7,XMMWORD PTR [r12+0x2f0]
    730a041031ce:	setne  BYTE PTR [rsp+0x8]
    730a041031d3:	mov    r11,rax
    730a041031d6:	lahf
    730a041031d7:	seto   al
    730a041031da:	mov    WORD PTR [rsp],ax
    730a041031de:	mov    rax,r11
    730a041031e1:	movdqa xmm0,xmm7
    730a041031e5:	movdqa xmm1,xmm7
    730a041031e9:	por    xmm0,xmm1
    730a041031ed:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    730a041031f7:	movdqu xmm10,XMMWORD PTR [r12+0x2e0]
    730a04103201:	movdqa xmm0,xmm10
    730a04103206:	movdqa xmm1,xmm10
    730a0410320b:	por    xmm0,xmm1
    730a0410320f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    730a04103219:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    730a04103223:	movdqa xmm0,xmm13
    730a04103228:	movdqa xmm1,xmm13
    730a0410322d:	por    xmm0,xmm1
    730a04103231:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    730a0410323b:	movdqu xmm5,XMMWORD PTR [r12+0x200]
    730a04103245:	movdqa xmm0,xmm5
    730a04103249:	movdqa xmm1,xmm5
    730a0410324d:	por    xmm0,xmm1
    730a04103251:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    730a0410325b:	movdqu xmm7,XMMWORD PTR [r12+0x1c0]
    730a04103265:	movdqa xmm1,xmm7
    730a04103269:	por    xmm7,xmm1
    730a0410326d:	movdqu XMMWORD PTR [r12+0x200],xmm7
    730a04103277:	movdqu xmm3,XMMWORD PTR [r12+0x190]
    730a04103281:	movdqa xmm1,xmm3
    730a04103285:	por    xmm3,xmm1
    730a04103289:	movdqu XMMWORD PTR [r12+0x1c0],xmm3
    730a04103293:	movdqu xmm10,XMMWORD PTR [r12+0x300]
    730a0410329d:	movdqa xmm1,xmm10
    730a041032a2:	por    xmm10,xmm1
    730a041032a7:	movdqu XMMWORD PTR [r12+0x190],xmm10
    730a041032b1:	mov    r13,r14
    730a041032b4:	add    r13,0xa0
    730a041032bb:	mov    rbp,r13
    730a041032be:	add    rbp,0x10
    730a041032c2:	movdqu xmm13,XMMWORD PTR [r13+0x0]
    730a041032c8:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    730a041032cd:	movdqu XMMWORD PTR [r12+0x300],xmm13
    730a041032d7:	movdqu XMMWORD PTR [r12+0x270],xmm5
    730a041032e1:	movdqa xmm0,xmm12
    730a041032e6:	movdqa xmm1,xmm9
    730a041032eb:	addpd  xmm0,xmm1
    730a041032ef:	movdqa xmm14,xmm0
    730a041032f4:	movdqu xmm15,XMMWORD PTR [rip+0x9353]        # 0x730a0410c650
    730a041032fd:	pand   xmm14,xmm15
    730a04103302:	movdqu xmm15,XMMWORD PTR [rip+0x9355]        # 0x730a0410c660
    730a0410330b:	pcmpeqq xmm14,xmm15
    730a04103311:	movdqa xmm15,xmm0
    730a04103316:	cmpunordpd xmm15,xmm0
    730a0410331c:	por    xmm14,xmm15
    730a04103321:	pmovmskb ecx,xmm14
    730a04103326:	jrcxz  0x730a0410332d
    730a04103328:	jmp    0x730a04104fa5
    730a0410332d:	movdqu XMMWORD PTR [r12+0x180],xmm0
    730a04103337:	mov    r13,r14
    730a0410333a:	add    r13,0xf0
    730a04103341:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    730a04103347:	movdqu XMMWORD PTR [r12+0x110],xmm9
    730a04103351:	movdqa xmm0,xmm6
    730a04103355:	movdqa xmm1,xmm4
    730a04103359:	addpd  xmm0,xmm1
    730a0410335d:	movdqa xmm14,xmm0
    730a04103362:	movdqu xmm15,XMMWORD PTR [rip+0x92e5]        # 0x730a0410c650
    730a0410336b:	pand   xmm14,xmm15
    730a04103370:	movdqu xmm15,XMMWORD PTR [rip+0x92e7]        # 0x730a0410c660
    730a04103379:	pcmpeqq xmm14,xmm15
    730a0410337f:	movdqa xmm15,xmm0
    730a04103384:	cmpunordpd xmm15,xmm0
    730a0410338a:	por    xmm14,xmm15
    730a0410338f:	pmovmskb ecx,xmm14
    730a04103394:	jrcxz  0x730a0410339b
    730a04103396:	jmp    0x730a04104fcb
    730a0410339b:	movdqa xmm12,xmm0
    730a041033a0:	movdqu XMMWORD PTR [r12+0x210],xmm12
    730a041033aa:	movdqa xmm0,xmm8
    730a041033af:	movdqa xmm1,xmm11
    730a041033b4:	addpd  xmm0,xmm1
    730a041033b8:	movdqa xmm14,xmm0
    730a041033bd:	movdqu xmm15,XMMWORD PTR [rip+0x928a]        # 0x730a0410c650
    730a041033c6:	pand   xmm14,xmm15
    730a041033cb:	movdqu xmm15,XMMWORD PTR [rip+0x928c]        # 0x730a0410c660
    730a041033d4:	pcmpeqq xmm14,xmm15
    730a041033da:	movdqa xmm15,xmm0
    730a041033df:	cmpunordpd xmm15,xmm0
    730a041033e5:	por    xmm14,xmm15
    730a041033ea:	pmovmskb ecx,xmm14
    730a041033ef:	jrcxz  0x730a041033f6
    730a041033f1:	jmp    0x730a04104fef
    730a041033f6:	movdqa xmm4,xmm0
    730a041033fa:	movdqu XMMWORD PTR [r12+0x220],xmm4
    730a04103404:	movdqa xmm0,xmm5
    730a04103408:	movdqa xmm1,xmm2
    730a0410340c:	pshufd xmm1,xmm1,0x44
    730a04103411:	mulpd  xmm0,xmm1
    730a04103415:	movdqa xmm14,xmm0
    730a0410341a:	movdqu xmm15,XMMWORD PTR [rip+0x922d]        # 0x730a0410c650
    730a04103423:	pand   xmm14,xmm15
    730a04103428:	movdqu xmm15,XMMWORD PTR [rip+0x922f]        # 0x730a0410c660
    730a04103431:	pcmpeqq xmm14,xmm15
    730a04103437:	movdqa xmm15,xmm0
    730a0410343c:	cmpunordpd xmm15,xmm0
    730a04103442:	por    xmm14,xmm15
    730a04103447:	pmovmskb ecx,xmm14
    730a0410344c:	jrcxz  0x730a04103453
    730a0410344e:	jmp    0x730a04105015
    730a04103453:	movdqa xmm6,xmm0
    730a04103457:	movdqu XMMWORD PTR [r12+0x270],xmm6
    730a04103461:	movdqu xmm5,XMMWORD PTR [r12+0x170]
    730a0410346b:	movdqa xmm0,xmm9
    730a04103470:	movdqa xmm1,xmm5
    730a04103474:	pshufd xmm1,xmm1,0x44
    730a04103479:	mulpd  xmm0,xmm1
    730a0410347d:	movdqa xmm14,xmm0
    730a04103482:	movdqu xmm15,XMMWORD PTR [rip+0x91c5]        # 0x730a0410c650
    730a0410348b:	pand   xmm14,xmm15
    730a04103490:	movdqu xmm15,XMMWORD PTR [rip+0x91c7]        # 0x730a0410c660
    730a04103499:	pcmpeqq xmm14,xmm15
    730a0410349f:	movdqa xmm15,xmm0
    730a041034a4:	cmpunordpd xmm15,xmm0
    730a041034aa:	por    xmm14,xmm15
    730a041034af:	pmovmskb ecx,xmm14
    730a041034b4:	jrcxz  0x730a041034bb
    730a041034b6:	jmp    0x730a04105039
    730a041034bb:	movdqa xmm8,xmm0
    730a041034c0:	movdqu XMMWORD PTR [r12+0x250],xmm8
    730a041034ca:	mov    r13,r14
    730a041034cd:	add    r13,0xe0
    730a041034d4:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    730a041034da:	movdqu XMMWORD PTR [r12+0x110],xmm9
    730a041034e4:	movdqa xmm0,xmm13
    730a041034e9:	movdqa xmm1,xmm2
    730a041034ed:	pshufd xmm1,xmm1,0x44
    730a041034f2:	mulpd  xmm0,xmm1
    730a041034f6:	movdqa xmm14,xmm0
    730a041034fb:	movdqu xmm15,XMMWORD PTR [rip+0x914c]        # 0x730a0410c650
    730a04103504:	pand   xmm14,xmm15
    730a04103509:	movdqu xmm15,XMMWORD PTR [rip+0x914e]        # 0x730a0410c660
    730a04103512:	pcmpeqq xmm14,xmm15
    730a04103518:	movdqa xmm15,xmm0
    730a0410351d:	cmpunordpd xmm15,xmm0
    730a04103523:	por    xmm14,xmm15
    730a04103528:	pmovmskb ecx,xmm14
    730a0410352d:	jrcxz  0x730a04103534
    730a0410352f:	jmp    0x730a0410505e
    730a04103534:	movdqa xmm11,xmm0
    730a04103539:	movdqu XMMWORD PTR [r12+0x230],xmm11
    730a04103543:	movdqa xmm0,xmm10
    730a04103548:	movdqa xmm1,xmm10
    730a0410354d:	por    xmm0,xmm1
    730a04103551:	movdqu XMMWORD PTR [r12+0x300],xmm0
    730a0410355b:	movdqa xmm0,xmm3
    730a0410355f:	movdqa xmm1,xmm3
    730a04103563:	por    xmm0,xmm1
    730a04103567:	movdqu XMMWORD PTR [r12+0x190],xmm0
    730a04103571:	movdqa xmm0,xmm9
    730a04103576:	movdqa xmm1,xmm5
    730a0410357a:	pshufd xmm1,xmm1,0x44
    730a0410357f:	mulpd  xmm0,xmm1
    730a04103583:	movdqa xmm14,xmm0
    730a04103588:	movdqu xmm15,XMMWORD PTR [rip+0x90bf]        # 0x730a0410c650
    730a04103591:	pand   xmm14,xmm15
    730a04103596:	movdqu xmm15,XMMWORD PTR [rip+0x90c1]        # 0x730a0410c660
    730a0410359f:	pcmpeqq xmm14,xmm15
    730a041035a5:	movdqa xmm15,xmm0
    730a041035aa:	cmpunordpd xmm15,xmm0
    730a041035b0:	por    xmm14,xmm15
    730a041035b5:	pmovmskb ecx,xmm14
    730a041035ba:	jrcxz  0x730a041035c1
    730a041035bc:	jmp    0x730a04105083
    730a041035c1:	movdqa xmm2,xmm0
    730a041035c5:	movdqu XMMWORD PTR [r12+0x260],xmm2
    730a041035cf:	mov    r13,r14
    730a041035d2:	add    r13,0x90
    730a041035d9:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    730a041035df:	movdqu XMMWORD PTR [r12+0x110],xmm9
    730a041035e9:	movdqa xmm0,xmm7
    730a041035ed:	movdqa xmm1,xmm7
    730a041035f1:	por    xmm0,xmm1
    730a041035f5:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    730a041035ff:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    730a04103609:	movdqu xmm1,XMMWORD PTR [r12+0x2d0]
    730a04103613:	por    xmm13,xmm1
    730a04103618:	movdqu XMMWORD PTR [r12+0x200],xmm13
    730a04103622:	movdqu xmm7,XMMWORD PTR [r12+0x2e0]
    730a0410362c:	movdqu xmm1,XMMWORD PTR [r12+0x2e0]
    730a04103636:	por    xmm7,xmm1
    730a0410363a:	movdqu XMMWORD PTR [r12+0x2d0],xmm7
    730a04103644:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    730a0410364e:	movdqu xmm1,XMMWORD PTR [r12+0x2f0]
    730a04103658:	por    xmm0,xmm1
    730a0410365c:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    730a04103666:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    730a04103670:	movdqa xmm1,xmm6
    730a04103674:	addpd  xmm0,xmm1
    730a04103678:	movdqa xmm14,xmm0
    730a0410367d:	movdqu xmm15,XMMWORD PTR [rip+0x8fca]        # 0x730a0410c650
    730a04103686:	pand   xmm14,xmm15
    730a0410368b:	movdqu xmm15,XMMWORD PTR [rip+0x8fcc]        # 0x730a0410c660
    730a04103694:	pcmpeqq xmm14,xmm15
    730a0410369a:	movdqa xmm15,xmm0
    730a0410369f:	cmpunordpd xmm15,xmm0
    730a041036a5:	por    xmm14,xmm15
    730a041036aa:	pmovmskb ecx,xmm14
    730a041036af:	jrcxz  0x730a041036b6
    730a041036b1:	jmp    0x730a041050a8
    730a041036b6:	movdqa xmm3,xmm0
    730a041036ba:	movdqu XMMWORD PTR [r12+0x240],xmm3
    730a041036c4:	movdqa xmm0,xmm9
    730a041036c9:	movdqa xmm1,xmm5
    730a041036cd:	pshufd xmm1,xmm1,0x44
    730a041036d2:	mulpd  xmm0,xmm1
    730a041036d6:	movdqa xmm14,xmm0
    730a041036db:	movdqu xmm15,XMMWORD PTR [rip+0x8f6c]        # 0x730a0410c650
    730a041036e4:	pand   xmm14,xmm15
    730a041036e9:	movdqu xmm15,XMMWORD PTR [rip+0x8f6e]        # 0x730a0410c660
    730a041036f2:	pcmpeqq xmm14,xmm15
    730a041036f8:	movdqa xmm15,xmm0
    730a041036fd:	cmpunordpd xmm15,xmm0
    730a04103703:	por    xmm14,xmm15
    730a04103708:	pmovmskb ecx,xmm14
    730a0410370d:	jrcxz  0x730a04103714
    730a0410370f:	jmp    0x730a041050d2
    730a04103714:	movdqa xmm6,xmm0
    730a04103718:	movdqu XMMWORD PTR [r12+0x270],xmm6
    730a04103722:	mov    r13,r14
    730a04103725:	add    r13,0x80
    730a0410372c:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    730a04103732:	movdqu XMMWORD PTR [r12+0x110],xmm9
    730a0410373c:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    730a04103746:	movdqa xmm1,xmm11
    730a0410374b:	addpd  xmm0,xmm1
    730a0410374f:	movdqa xmm14,xmm0
    730a04103754:	movdqu xmm15,XMMWORD PTR [rip+0x8ef3]        # 0x730a0410c650
    730a0410375d:	pand   xmm14,xmm15
    730a04103762:	movdqu xmm15,XMMWORD PTR [rip+0x8ef5]        # 0x730a0410c660
    730a0410376b:	pcmpeqq xmm14,xmm15
    730a04103771:	movdqa xmm15,xmm0
    730a04103776:	cmpunordpd xmm15,xmm0
    730a0410377c:	por    xmm14,xmm15
    730a04103781:	pmovmskb ecx,xmm14
    730a04103786:	jrcxz  0x730a0410378d
    730a04103788:	jmp    0x730a041050f7
    730a0410378d:	movdqa xmm10,xmm0
    730a04103792:	movdqu XMMWORD PTR [r12+0x180],xmm10
    730a0410379c:	movdqa xmm0,xmm12
    730a041037a1:	movdqa xmm1,xmm8
    730a041037a6:	addpd  xmm0,xmm1
    730a041037aa:	movdqa xmm14,xmm0
    730a041037af:	movdqu xmm15,XMMWORD PTR [rip+0x8e98]        # 0x730a0410c650
    730a041037b8:	pand   xmm14,xmm15
    730a041037bd:	movdqu xmm15,XMMWORD PTR [rip+0x8e9a]        # 0x730a0410c660
    730a041037c6:	pcmpeqq xmm14,xmm15
    730a041037cc:	movdqa xmm15,xmm0
    730a041037d1:	cmpunordpd xmm15,xmm0
    730a041037d7:	por    xmm14,xmm15
    730a041037dc:	pmovmskb ecx,xmm14
    730a041037e1:	jrcxz  0x730a041037e8
    730a041037e3:	jmp    0x730a04105122
    730a041037e8:	movdqa xmm11,xmm0
    730a041037ed:	movdqu XMMWORD PTR [r12+0x210],xmm11
    730a041037f7:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    730a04103801:	movdqu xmm1,XMMWORD PTR [r12+0x1b0]
    730a0410380b:	por    xmm0,xmm1
    730a0410380f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    730a04103819:	movdqa xmm0,xmm9
    730a0410381e:	movdqa xmm1,xmm5
    730a04103822:	pshufd xmm1,xmm1,0x44
    730a04103827:	mulpd  xmm0,xmm1
    730a0410382b:	movdqa xmm14,xmm0
    730a04103830:	movdqu xmm15,XMMWORD PTR [rip+0x8e17]        # 0x730a0410c650
    730a04103839:	pand   xmm14,xmm15
    730a0410383e:	movdqu xmm15,XMMWORD PTR [rip+0x8e19]        # 0x730a0410c660
    730a04103847:	pcmpeqq xmm14,xmm15
    730a0410384d:	movdqa xmm15,xmm0
    730a04103852:	cmpunordpd xmm15,xmm0
    730a04103858:	por    xmm14,xmm15
    730a0410385d:	pmovmskb ecx,xmm14
    730a04103862:	jrcxz  0x730a04103869
    730a04103864:	jmp    0x730a04105148
    730a04103869:	movdqa xmm12,xmm0
    730a0410386e:	movdqu XMMWORD PTR [r12+0x170],xmm12
    730a04103878:	mov    r13,r14
    730a0410387b:	add    r13,0xd0
    730a04103882:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    730a04103888:	movdqu XMMWORD PTR [r12+0x110],xmm5
    730a04103892:	movdqa xmm0,xmm4
    730a04103896:	movdqa xmm1,xmm2
    730a0410389a:	addpd  xmm0,xmm1
    730a0410389e:	movdqa xmm14,xmm0
    730a041038a3:	movdqu xmm15,XMMWORD PTR [rip+0x8da4]        # 0x730a0410c650
    730a041038ac:	pand   xmm14,xmm15
    730a041038b1:	movdqu xmm15,XMMWORD PTR [rip+0x8da6]        # 0x730a0410c660
    730a041038ba:	pcmpeqq xmm14,xmm15
    730a041038c0:	movdqa xmm15,xmm0
    730a041038c5:	cmpunordpd xmm15,xmm0
    730a041038cb:	por    xmm14,xmm15
    730a041038d0:	pmovmskb ecx,xmm14
    730a041038d5:	jrcxz  0x730a041038dc
    730a041038d7:	jmp    0x730a0410516d
    730a041038dc:	movdqa xmm9,xmm0
    730a041038e1:	movdqu XMMWORD PTR [r12+0x220],xmm9
    730a041038eb:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    730a041038f5:	movdqa xmm0,xmm13
    730a041038fa:	movdqa xmm1,xmm2
    730a041038fe:	pshufd xmm1,xmm1,0x44
    730a04103903:	mulpd  xmm0,xmm1
    730a04103907:	movdqa xmm14,xmm0
    730a0410390c:	movdqu xmm15,XMMWORD PTR [rip+0x8d3b]        # 0x730a0410c650
    730a04103915:	pand   xmm14,xmm15
    730a0410391a:	movdqu xmm15,XMMWORD PTR [rip+0x8d3d]        # 0x730a0410c660
    730a04103923:	pcmpeqq xmm14,xmm15
    730a04103929:	movdqa xmm15,xmm0
    730a0410392e:	cmpunordpd xmm15,xmm0
    730a04103934:	por    xmm14,xmm15
    730a04103939:	pmovmskb ecx,xmm14
    730a0410393e:	jrcxz  0x730a04103945
    730a04103940:	jmp    0x730a04105191
    730a04103945:	movdqa xmm4,xmm0
    730a04103949:	movdqu XMMWORD PTR [r12+0x260],xmm4
    730a04103953:	mov    r13d,0x0
    730a04103959:	mov    ebp,0x0
    730a0410395e:	mov    QWORD PTR [r12+0x1b0],r13
    730a04103966:	mov    QWORD PTR [r12+0x1b8],rbp
    730a0410396e:	movdqa xmm0,xmm5
    730a04103972:	movdqa xmm1,xmm2
    730a04103976:	pshufd xmm1,xmm1,0x44
    730a0410397b:	mulpd  xmm0,xmm1
    730a0410397f:	movdqa xmm14,xmm0
    730a04103984:	movdqu xmm15,XMMWORD PTR [rip+0x8cc3]        # 0x730a0410c650
    730a0410398d:	pand   xmm14,xmm15
    730a04103992:	movdqu xmm15,XMMWORD PTR [rip+0x8cc5]        # 0x730a0410c660
    730a0410399b:	pcmpeqq xmm14,xmm15
    730a041039a1:	movdqa xmm15,xmm0
    730a041039a6:	cmpunordpd xmm15,xmm0
    730a041039ac:	por    xmm14,xmm15
    730a041039b1:	pmovmskb ecx,xmm14
    730a041039b6:	jrcxz  0x730a041039bd
    730a041039b8:	jmp    0x730a041051b6
    730a041039bd:	movdqa xmm13,xmm0
    730a041039c2:	movdqu XMMWORD PTR [r12+0x230],xmm13
    730a041039cc:	mov    r13,r14
    730a041039cf:	add    r13,0xc0
    730a041039d6:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    730a041039dc:	movdqu XMMWORD PTR [r12+0x110],xmm5
    730a041039e6:	movdqa xmm0,xmm3
    730a041039ea:	movdqa xmm1,xmm6
    730a041039ee:	addpd  xmm0,xmm1
    730a041039f2:	movdqa xmm14,xmm0
    730a041039f7:	movdqu xmm15,XMMWORD PTR [rip+0x8c50]        # 0x730a0410c650
    730a04103a00:	pand   xmm14,xmm15
    730a04103a05:	movdqu xmm15,XMMWORD PTR [rip+0x8c52]        # 0x730a0410c660
    730a04103a0e:	pcmpeqq xmm14,xmm15
    730a04103a14:	movdqa xmm15,xmm0
    730a04103a19:	cmpunordpd xmm15,xmm0
    730a04103a1f:	por    xmm14,xmm15
    730a04103a24:	pmovmskb ecx,xmm14
    730a04103a29:	jrcxz  0x730a04103a30
    730a04103a2b:	jmp    0x730a041051da
    730a04103a30:	movdqa xmm8,xmm0
    730a04103a35:	movdqu XMMWORD PTR [r12+0x240],xmm8
    730a04103a3f:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    730a04103a49:	movdqu xmm1,XMMWORD PTR [r12+0x1a0]
    730a04103a53:	por    xmm0,xmm1
    730a04103a57:	movdqu XMMWORD PTR [r12+0x270],xmm0
    730a04103a61:	movdqu xmm6,XMMWORD PTR [r12+0x120]
    730a04103a6b:	movdqu xmm1,XMMWORD PTR [r12+0x120]
    730a04103a75:	por    xmm6,xmm1
    730a04103a79:	movdqu XMMWORD PTR [r12+0x1a0],xmm6
    730a04103a83:	movdqa xmm0,xmm5
    730a04103a87:	movdqa xmm1,xmm2
    730a04103a8b:	pshufd xmm1,xmm1,0x44
    730a04103a90:	mulpd  xmm0,xmm1
    730a04103a94:	movdqa xmm14,xmm0
    730a04103a99:	movdqu xmm15,XMMWORD PTR [rip+0x8bae]        # 0x730a0410c650
    730a04103aa2:	pand   xmm14,xmm15
    730a04103aa7:	movdqu xmm15,XMMWORD PTR [rip+0x8bb0]        # 0x730a0410c660
    730a04103ab0:	pcmpeqq xmm14,xmm15
    730a04103ab6:	movdqa xmm15,xmm0
    730a04103abb:	cmpunordpd xmm15,xmm0
    730a04103ac1:	por    xmm14,xmm15
    730a04103ac6:	pmovmskb ecx,xmm14
    730a04103acb:	jrcxz  0x730a04103ad2
    730a04103acd:	jmp    0x730a041051fe
    730a04103ad2:	movdqa xmm6,xmm0
    730a04103ad6:	movdqu XMMWORD PTR [r12+0x250],xmm6
    730a04103ae0:	mov    r13,r14
    730a04103ae3:	add    r13,0x20
    730a04103ae7:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    730a04103aed:	movdqu XMMWORD PTR [r12+0x110],xmm5
    730a04103af7:	movdqa xmm0,xmm10
    730a04103afc:	movdqa xmm1,xmm12
    730a04103b01:	addpd  xmm0,xmm1
    730a04103b05:	movdqa xmm14,xmm0
    730a04103b0a:	movdqu xmm15,XMMWORD PTR [rip+0x8b3d]        # 0x730a0410c650
    730a04103b13:	pand   xmm14,xmm15
    730a04103b18:	movdqu xmm15,XMMWORD PTR [rip+0x8b3f]        # 0x730a0410c660
    730a04103b21:	pcmpeqq xmm14,xmm15
    730a04103b27:	movdqa xmm15,xmm0
    730a04103b2c:	cmpunordpd xmm15,xmm0
    730a04103b32:	por    xmm14,xmm15
    730a04103b37:	pmovmskb ecx,xmm14
    730a04103b3c:	jrcxz  0x730a04103b43
    730a04103b3e:	jmp    0x730a04105222
    730a04103b43:	movdqa xmm3,xmm0
    730a04103b47:	movdqa xmm0,xmm7
    730a04103b4b:	movdqa xmm1,xmm2
    730a04103b4f:	pshufd xmm1,xmm1,0x44
    730a04103b54:	mulpd  xmm0,xmm1
    730a04103b58:	movdqa xmm14,xmm0
    730a04103b5d:	movdqu xmm15,XMMWORD PTR [rip+0x8aea]        # 0x730a0410c650
    730a04103b66:	pand   xmm14,xmm15
    730a04103b6b:	movdqu xmm15,XMMWORD PTR [rip+0x8aec]        # 0x730a0410c660
    730a04103b74:	pcmpeqq xmm14,xmm15
    730a04103b7a:	movdqa xmm15,xmm0
    730a04103b7f:	cmpunordpd xmm15,xmm0
    730a04103b85:	por    xmm14,xmm15
    730a04103b8a:	pmovmskb ecx,xmm14
    730a04103b8f:	jrcxz  0x730a04103b96
    730a04103b91:	jmp    0x730a04105248
    730a04103b96:	movdqa xmm10,xmm0
    730a04103b9b:	movdqa xmm0,xmm11
    730a04103ba0:	movdqa xmm1,xmm13
    730a04103ba5:	addpd  xmm0,xmm1
    730a04103ba9:	movdqa xmm14,xmm0
    730a04103bae:	movdqu xmm15,XMMWORD PTR [rip+0x8a99]        # 0x730a0410c650
    730a04103bb7:	pand   xmm14,xmm15
    730a04103bbc:	movdqu xmm15,XMMWORD PTR [rip+0x8a9b]        # 0x730a0410c660
    730a04103bc5:	pcmpeqq xmm14,xmm15
    730a04103bcb:	movdqa xmm15,xmm0
    730a04103bd0:	cmpunordpd xmm15,xmm0
    730a04103bd6:	por    xmm14,xmm15
    730a04103bdb:	pmovmskb ecx,xmm14
    730a04103be0:	jrcxz  0x730a04103be7
    730a04103be2:	jmp    0x730a0410526c
    730a04103be7:	movdqa xmm2,xmm0
    730a04103beb:	movdqu xmm7,XMMWORD PTR [r12+0x150]
    730a04103bf5:	movdqa xmm0,xmm5
    730a04103bf9:	movdqa xmm1,xmm7
    730a04103bfd:	pshufd xmm1,xmm1,0x44
    730a04103c02:	mulpd  xmm0,xmm1
    730a04103c06:	movdqa xmm14,xmm0
    730a04103c0b:	movdqu xmm15,XMMWORD PTR [rip+0x8a3c]        # 0x730a0410c650
    730a04103c14:	pand   xmm14,xmm15
    730a04103c19:	movdqu xmm15,XMMWORD PTR [rip+0x8a3e]        # 0x730a0410c660
    730a04103c22:	pcmpeqq xmm14,xmm15
    730a04103c28:	movdqa xmm15,xmm0
    730a04103c2d:	cmpunordpd xmm15,xmm0
    730a04103c33:	por    xmm14,xmm15
    730a04103c38:	pmovmskb ecx,xmm14
    730a04103c3d:	jrcxz  0x730a04103c44
    730a04103c3f:	jmp    0x730a04105292
    730a04103c44:	movdqa xmm11,xmm0
    730a04103c49:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    730a04103c53:	movdqa xmm1,xmm7
    730a04103c57:	pshufd xmm1,xmm1,0x44
    730a04103c5c:	mulpd  xmm0,xmm1
    730a04103c60:	movdqa xmm14,xmm0
    730a04103c65:	movdqu xmm15,XMMWORD PTR [rip+0x89e2]        # 0x730a0410c650
    730a04103c6e:	pand   xmm14,xmm15
    730a04103c73:	movdqu xmm15,XMMWORD PTR [rip+0x89e4]        # 0x730a0410c660
    730a04103c7c:	pcmpeqq xmm14,xmm15
    730a04103c82:	movdqa xmm15,xmm0
    730a04103c87:	cmpunordpd xmm15,xmm0
    730a04103c8d:	por    xmm14,xmm15
    730a04103c92:	pmovmskb ecx,xmm14
    730a04103c97:	jrcxz  0x730a04103c9e
    730a04103c99:	jmp    0x730a041052b6
    730a04103c9e:	movdqa xmm5,xmm0
    730a04103ca2:	movdqa xmm0,xmm8
    730a04103ca7:	movdqa xmm1,xmm4
    730a04103cab:	addpd  xmm0,xmm1
    730a04103caf:	movdqa xmm14,xmm0
    730a04103cb4:	movdqu xmm15,XMMWORD PTR [rip+0x8993]        # 0x730a0410c650
    730a04103cbd:	pand   xmm14,xmm15
    730a04103cc2:	movdqu xmm15,XMMWORD PTR [rip+0x8995]        # 0x730a0410c660
    730a04103ccb:	pcmpeqq xmm14,xmm15
    730a04103cd1:	movdqa xmm15,xmm0
    730a04103cd6:	cmpunordpd xmm15,xmm0
    730a04103cdc:	por    xmm14,xmm15
    730a04103ce1:	pmovmskb ecx,xmm14
    730a04103ce6:	jrcxz  0x730a04103ced
    730a04103ce8:	jmp    0x730a041052e0
    730a04103ced:	movdqa xmm12,xmm0
    730a04103cf2:	movdqu XMMWORD PTR [r12+0x240],xmm12
    730a04103cfc:	movdqa xmm0,xmm9
    730a04103d01:	movdqa xmm1,xmm6
    730a04103d05:	addpd  xmm0,xmm1
    730a04103d09:	movdqa xmm14,xmm0
    730a04103d0e:	movdqu xmm15,XMMWORD PTR [rip+0x8939]        # 0x730a0410c650
    730a04103d17:	pand   xmm14,xmm15
    730a04103d1c:	movdqu xmm15,XMMWORD PTR [rip+0x893b]        # 0x730a0410c660
    730a04103d25:	pcmpeqq xmm14,xmm15
    730a04103d2b:	movdqa xmm15,xmm0
    730a04103d30:	cmpunordpd xmm15,xmm0
    730a04103d36:	por    xmm14,xmm15
    730a04103d3b:	pmovmskb ecx,xmm14
    730a04103d40:	jrcxz  0x730a04103d47
    730a04103d42:	jmp    0x730a04105305
    730a04103d47:	movdqa xmm4,xmm0
    730a04103d4b:	movdqu XMMWORD PTR [r12+0x220],xmm4
    730a04103d55:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    730a04103d5f:	movdqa xmm1,xmm7
    730a04103d63:	pshufd xmm1,xmm1,0x44
    730a04103d68:	mulpd  xmm0,xmm1
    730a04103d6c:	movdqa xmm14,xmm0
    730a04103d71:	movdqu xmm15,XMMWORD PTR [rip+0x88d6]        # 0x730a0410c650
    730a04103d7a:	pand   xmm14,xmm15
    730a04103d7f:	movdqu xmm15,XMMWORD PTR [rip+0x88d8]        # 0x730a0410c660
    730a04103d88:	pcmpeqq xmm14,xmm15
    730a04103d8e:	movdqa xmm15,xmm0
    730a04103d93:	cmpunordpd xmm15,xmm0
    730a04103d99:	por    xmm14,xmm15
    730a04103d9e:	pmovmskb ecx,xmm14
    730a04103da3:	jrcxz  0x730a04103daa
    730a04103da5:	jmp    0x730a0410532a
    730a04103daa:	movdqa xmm6,xmm0
    730a04103dae:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    730a04103db8:	movdqa xmm1,xmm7
    730a04103dbc:	pshufd xmm1,xmm1,0x44
    730a04103dc1:	mulpd  xmm0,xmm1
    730a04103dc5:	movdqa xmm14,xmm0
    730a04103dca:	movdqu xmm15,XMMWORD PTR [rip+0x887d]        # 0x730a0410c650
    730a04103dd3:	pand   xmm14,xmm15
    730a04103dd8:	movdqu xmm15,XMMWORD PTR [rip+0x887f]        # 0x730a0410c660
    730a04103de1:	pcmpeqq xmm14,xmm15
    730a04103de7:	movdqa xmm15,xmm0
    730a04103dec:	cmpunordpd xmm15,xmm0
    730a04103df2:	por    xmm14,xmm15
    730a04103df7:	pmovmskb ecx,xmm14
    730a04103dfc:	jrcxz  0x730a04103e03
    730a04103dfe:	jmp    0x730a04105354
    730a04103e03:	movdqa xmm8,xmm0
    730a04103e08:	movdqu XMMWORD PTR [r12+0x150],xmm8
    730a04103e12:	movdqa xmm0,xmm3
    730a04103e16:	movdqa xmm1,xmm10
    730a04103e1b:	addpd  xmm0,xmm1
    730a04103e1f:	movdqa xmm14,xmm0
    730a04103e24:	movdqu xmm15,XMMWORD PTR [rip+0x8823]        # 0x730a0410c650
    730a04103e2d:	pand   xmm14,xmm15
    730a04103e32:	movdqu xmm15,XMMWORD PTR [rip+0x8825]        # 0x730a0410c660
    730a04103e3b:	pcmpeqq xmm14,xmm15
    730a04103e41:	movdqa xmm15,xmm0
    730a04103e46:	cmpunordpd xmm15,xmm0
    730a04103e4c:	por    xmm14,xmm15
    730a04103e51:	pmovmskb ecx,xmm14
    730a04103e56:	jrcxz  0x730a04103e5d
    730a04103e58:	jmp    0x730a0410537e
    730a04103e5d:	movdqa xmm7,xmm0
    730a04103e61:	movdqu XMMWORD PTR [r12+0x160],xmm7
    730a04103e6b:	movdqa xmm0,xmm2
    730a04103e6f:	movdqa xmm1,xmm11
    730a04103e74:	addpd  xmm0,xmm1
    730a04103e78:	movdqa xmm14,xmm0
    730a04103e7d:	movdqu xmm15,XMMWORD PTR [rip+0x87ca]        # 0x730a0410c650
    730a04103e86:	pand   xmm14,xmm15
    730a04103e8b:	movdqu xmm15,XMMWORD PTR [rip+0x87cc]        # 0x730a0410c660
    730a04103e94:	pcmpeqq xmm14,xmm15
    730a04103e9a:	movdqa xmm15,xmm0
    730a04103e9f:	cmpunordpd xmm15,xmm0
    730a04103ea5:	por    xmm14,xmm15
    730a04103eaa:	pmovmskb ecx,xmm14
    730a04103eaf:	jrcxz  0x730a04103eb6
    730a04103eb1:	jmp    0x730a041053a3
    730a04103eb6:	movdqa xmm3,xmm0
    730a04103eba:	movdqu XMMWORD PTR [r12+0x170],xmm3
    730a04103ec4:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    730a04103ece:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    730a04103ed8:	movdqa xmm1,xmm2
    730a04103edc:	pshufd xmm1,xmm1,0x44
    730a04103ee1:	mulpd  xmm0,xmm1
    730a04103ee5:	movdqa xmm14,xmm0
    730a04103eea:	movdqu xmm15,XMMWORD PTR [rip+0x875d]        # 0x730a0410c650
    730a04103ef3:	pand   xmm14,xmm15
    730a04103ef8:	movdqu xmm15,XMMWORD PTR [rip+0x875f]        # 0x730a0410c660
    730a04103f01:	pcmpeqq xmm14,xmm15
    730a04103f07:	movdqa xmm15,xmm0
    730a04103f0c:	cmpunordpd xmm15,xmm0
    730a04103f12:	por    xmm14,xmm15
    730a04103f17:	pmovmskb ecx,xmm14
    730a04103f1c:	jrcxz  0x730a04103f23
    730a04103f1e:	jmp    0x730a041053c8
    730a04103f23:	movdqa xmm9,xmm0
    730a04103f28:	movdqu XMMWORD PTR [r12+0x180],xmm9
    730a04103f32:	movdqa xmm0,xmm4
    730a04103f36:	movdqa xmm1,xmm5
    730a04103f3a:	addpd  xmm0,xmm1
    730a04103f3e:	movdqa xmm14,xmm0
    730a04103f43:	movdqu xmm15,XMMWORD PTR [rip+0x8704]        # 0x730a0410c650
    730a04103f4c:	pand   xmm14,xmm15
    730a04103f51:	movdqu xmm15,XMMWORD PTR [rip+0x8706]        # 0x730a0410c660
    730a04103f5a:	pcmpeqq xmm14,xmm15
    730a04103f60:	movdqa xmm15,xmm0
    730a04103f65:	cmpunordpd xmm15,xmm0
    730a04103f6b:	por    xmm14,xmm15
    730a04103f70:	pmovmskb ecx,xmm14
    730a04103f75:	jrcxz  0x730a04103f7c
    730a04103f77:	jmp    0x730a041053f2
    730a04103f7c:	movdqa xmm10,xmm0
    730a04103f81:	movdqu XMMWORD PTR [r12+0x210],xmm10
    730a04103f8b:	movdqa xmm0,xmm12
    730a04103f90:	movdqa xmm1,xmm6
    730a04103f94:	addpd  xmm0,xmm1
    730a04103f98:	movdqa xmm14,xmm0
    730a04103f9d:	movdqu xmm15,XMMWORD PTR [rip+0x86aa]        # 0x730a0410c650
    730a04103fa6:	pand   xmm14,xmm15
    730a04103fab:	movdqu xmm15,XMMWORD PTR [rip+0x86ac]        # 0x730a0410c660
    730a04103fb4:	pcmpeqq xmm14,xmm15
    730a04103fba:	movdqa xmm15,xmm0
    730a04103fbf:	cmpunordpd xmm15,xmm0
    730a04103fc5:	por    xmm14,xmm15
    730a04103fca:	pmovmskb ecx,xmm14
    730a04103fcf:	jrcxz  0x730a04103fd6
    730a04103fd1:	jmp    0x730a04105416
    730a04103fd6:	movdqa xmm4,xmm0
    730a04103fda:	movdqu XMMWORD PTR [r12+0x230],xmm4
    730a04103fe4:	movdqu xmm5,XMMWORD PTR [r12+0x2a0]
    730a04103fee:	movdqu xmm1,XMMWORD PTR [r12+0x2a0]
    730a04103ff8:	por    xmm5,xmm1
    730a04103ffc:	movdqu XMMWORD PTR [r12+0x250],xmm5
    730a04104006:	movdqu xmm5,XMMWORD PTR [r12+0x1d0]
    730a04104010:	movdqu xmm1,XMMWORD PTR [r12+0x1d0]
    730a0410401a:	por    xmm5,xmm1
    730a0410401e:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    730a04104028:	movdqu xmm6,XMMWORD PTR [r12+0x2c0]
    730a04104032:	movdqu xmm1,XMMWORD PTR [r12+0x2c0]
    730a0410403c:	por    xmm6,xmm1
    730a04104040:	movdqu XMMWORD PTR [r12+0x1d0],xmm6
    730a0410404a:	mov    r13,r14
    730a0410404d:	add    r13,0x40
    730a04104051:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    730a04104057:	movdqu XMMWORD PTR [r12+0x2c0],xmm6
    730a04104061:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    730a0410406b:	movdqa xmm1,xmm2
    730a0410406f:	pshufd xmm1,xmm1,0x44
    730a04104074:	mulpd  xmm0,xmm1
    730a04104078:	movdqa xmm14,xmm0
    730a0410407d:	movdqu xmm15,XMMWORD PTR [rip+0x85ca]        # 0x730a0410c650
    730a04104086:	pand   xmm14,xmm15
    730a0410408b:	movdqu xmm15,XMMWORD PTR [rip+0x85cc]        # 0x730a0410c660
    730a04104094:	pcmpeqq xmm14,xmm15
    730a0410409a:	movdqa xmm15,xmm0
    730a0410409f:	cmpunordpd xmm15,xmm0
    730a041040a5:	por    xmm14,xmm15
    730a041040aa:	pmovmskb ecx,xmm14
    730a041040af:	jrcxz  0x730a041040b6
    730a041040b1:	jmp    0x730a0410543b
    730a041040b6:	movdqa xmm11,xmm0
    730a041040bb:	movdqa xmm0,xmm7
    730a041040bf:	movdqa xmm1,xmm8
    730a041040c4:	addpd  xmm0,xmm1
    730a041040c8:	movdqa xmm14,xmm0
    730a041040cd:	movdqu xmm15,XMMWORD PTR [rip+0x857a]        # 0x730a0410c650
    730a041040d6:	pand   xmm14,xmm15
    730a041040db:	movdqu xmm15,XMMWORD PTR [rip+0x857c]        # 0x730a0410c660
    730a041040e4:	pcmpeqq xmm14,xmm15
    730a041040ea:	movdqa xmm15,xmm0
    730a041040ef:	cmpunordpd xmm15,xmm0
    730a041040f5:	por    xmm14,xmm15
    730a041040fa:	pmovmskb ecx,xmm14
    730a041040ff:	jrcxz  0x730a04104106
    730a04104101:	jmp    0x730a04105465
    730a04104106:	movdqa xmm12,xmm0
    730a0410410b:	movdqa xmm0,xmm3
    730a0410410f:	movdqa xmm1,xmm9
    730a04104114:	addpd  xmm0,xmm1
    730a04104118:	movdqa xmm14,xmm0
    730a0410411d:	movdqu xmm15,XMMWORD PTR [rip+0x852a]        # 0x730a0410c650
    730a04104126:	pand   xmm14,xmm15
    730a0410412b:	movdqu xmm15,XMMWORD PTR [rip+0x852c]        # 0x730a0410c660
    730a04104134:	pcmpeqq xmm14,xmm15
    730a0410413a:	movdqa xmm15,xmm0
    730a0410413f:	cmpunordpd xmm15,xmm0
    730a04104145:	por    xmm14,xmm15
    730a0410414a:	pmovmskb ecx,xmm14
    730a0410414f:	jrcxz  0x730a04104156
    730a04104151:	jmp    0x730a0410548a
    730a04104156:	movdqa xmm7,xmm0
    730a0410415a:	movdqu XMMWORD PTR [r12+0x160],xmm7
    730a04104164:	movdqa xmm0,xmm6
    730a04104168:	movdqa xmm1,xmm2
    730a0410416c:	pshufd xmm1,xmm1,0x44
    730a04104171:	mulpd  xmm0,xmm1
    730a04104175:	movdqa xmm14,xmm0
    730a0410417a:	movdqu xmm15,XMMWORD PTR [rip+0x84cd]        # 0x730a0410c650
    730a04104183:	pand   xmm14,xmm15
    730a04104188:	movdqu xmm15,XMMWORD PTR [rip+0x84cf]        # 0x730a0410c660
    730a04104191:	pcmpeqq xmm14,xmm15
    730a04104197:	movdqa xmm15,xmm0
    730a0410419c:	cmpunordpd xmm15,xmm0
    730a041041a2:	por    xmm14,xmm15
    730a041041a7:	pmovmskb ecx,xmm14
    730a041041ac:	jrcxz  0x730a041041b3
    730a041041ae:	jmp    0x730a041054af
    730a041041b3:	movdqa xmm3,xmm0
    730a041041b7:	movdqu XMMWORD PTR [r12+0x240],xmm3
    730a041041c1:	movdqu xmm6,XMMWORD PTR [r12+0x2b0]
    730a041041cb:	movdqa xmm0,xmm6
    730a041041cf:	movdqa xmm1,xmm2
    730a041041d3:	pshufd xmm1,xmm1,0x44
    730a041041d8:	mulpd  xmm0,xmm1
    730a041041dc:	movdqa xmm14,xmm0
    730a041041e1:	movdqu xmm15,XMMWORD PTR [rip+0x8466]        # 0x730a0410c650
    730a041041ea:	pand   xmm14,xmm15
    730a041041ef:	movdqu xmm15,XMMWORD PTR [rip+0x8468]        # 0x730a0410c660
    730a041041f8:	pcmpeqq xmm14,xmm15
    730a041041fe:	movdqa xmm15,xmm0
    730a04104203:	cmpunordpd xmm15,xmm0
    730a04104209:	por    xmm14,xmm15
    730a0410420e:	pmovmskb ecx,xmm14
    730a04104213:	jrcxz  0x730a0410421a
    730a04104215:	jmp    0x730a041054d3
    730a0410421a:	movdqa xmm8,xmm0
    730a0410421f:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    730a04104229:	movdqa xmm0,xmm5
    730a0410422d:	movdqa xmm1,xmm2
    730a04104231:	pshufd xmm1,xmm1,0x44
    730a04104236:	mulpd  xmm0,xmm1
    730a0410423a:	movdqa xmm14,xmm0
    730a0410423f:	movdqu xmm15,XMMWORD PTR [rip+0x8408]        # 0x730a0410c650
    730a04104248:	pand   xmm14,xmm15
    730a0410424d:	movdqu xmm15,XMMWORD PTR [rip+0x840a]        # 0x730a0410c660
    730a04104256:	pcmpeqq xmm14,xmm15
    730a0410425c:	movdqa xmm15,xmm0
    730a04104261:	cmpunordpd xmm15,xmm0
    730a04104267:	por    xmm14,xmm15
    730a0410426c:	pmovmskb ecx,xmm14
    730a04104271:	jrcxz  0x730a04104278
    730a04104273:	jmp    0x730a041054f7
    730a04104278:	movdqa xmm6,xmm0
    730a0410427c:	movdqu XMMWORD PTR [r12+0x170],xmm6
    730a04104286:	movdqa xmm0,xmm10
    730a0410428b:	movdqa xmm1,xmm11
    730a04104290:	addpd  xmm0,xmm1
    730a04104294:	movdqa xmm14,xmm0
    730a04104299:	movdqu xmm15,XMMWORD PTR [rip+0x83ae]        # 0x730a0410c650
    730a041042a2:	pand   xmm14,xmm15
    730a041042a7:	movdqu xmm15,XMMWORD PTR [rip+0x83b0]        # 0x730a0410c660
    730a041042b0:	pcmpeqq xmm14,xmm15
    730a041042b6:	movdqa xmm15,xmm0
    730a041042bb:	cmpunordpd xmm15,xmm0
    730a041042c1:	por    xmm14,xmm15
    730a041042c6:	pmovmskb ecx,xmm14
    730a041042cb:	jrcxz  0x730a041042d2
    730a041042cd:	jmp    0x730a0410551b
    730a041042d2:	movdqa xmm5,xmm0
    730a041042d6:	movdqu XMMWORD PTR [r12+0x180],xmm5
    730a041042e0:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    730a041042ea:	movdqa xmm1,xmm2
    730a041042ee:	pshufd xmm1,xmm1,0x44
    730a041042f3:	mulpd  xmm0,xmm1
    730a041042f7:	movdqa xmm14,xmm0
    730a041042fc:	movdqu xmm15,XMMWORD PTR [rip+0x834b]        # 0x730a0410c650
    730a04104305:	pand   xmm14,xmm15
    730a0410430a:	movdqu xmm15,XMMWORD PTR [rip+0x834d]        # 0x730a0410c660
    730a04104313:	pcmpeqq xmm14,xmm15
    730a04104319:	movdqa xmm15,xmm0
    730a0410431e:	cmpunordpd xmm15,xmm0
    730a04104324:	por    xmm14,xmm15
    730a04104329:	pmovmskb ecx,xmm14
    730a0410432e:	jrcxz  0x730a04104335
    730a04104330:	jmp    0x730a04105541
    730a04104335:	movdqa xmm9,xmm0
    730a0410433a:	movdqu XMMWORD PTR [r12+0x210],xmm9
    730a04104344:	movdqa xmm0,xmm4
    730a04104348:	movdqa xmm1,xmm3
    730a0410434c:	addpd  xmm0,xmm1
    730a04104350:	movdqa xmm14,xmm0
    730a04104355:	movdqu xmm15,XMMWORD PTR [rip+0x82f2]        # 0x730a0410c650
    730a0410435e:	pand   xmm14,xmm15
    730a04104363:	movdqu xmm15,XMMWORD PTR [rip+0x82f4]        # 0x730a0410c660
    730a0410436c:	pcmpeqq xmm14,xmm15
    730a04104372:	movdqa xmm15,xmm0
    730a04104377:	cmpunordpd xmm15,xmm0
    730a0410437d:	por    xmm14,xmm15
    730a04104382:	pmovmskb ecx,xmm14
    730a04104387:	jrcxz  0x730a0410438e
    730a04104389:	jmp    0x730a0410556b
    730a0410438e:	movdqa xmm10,xmm0
    730a04104393:	movdqu XMMWORD PTR [r12+0x220],xmm10
    730a0410439d:	movdqu xmm3,XMMWORD PTR [r12+0x290]
    730a041043a7:	movdqa xmm0,xmm3
    730a041043ab:	movdqa xmm1,xmm2
    730a041043af:	pshufd xmm1,xmm1,0x44
    730a041043b4:	mulpd  xmm0,xmm1
    730a041043b8:	movdqa xmm14,xmm0
    730a041043bd:	movdqu xmm15,XMMWORD PTR [rip+0x828a]        # 0x730a0410c650
    730a041043c6:	pand   xmm14,xmm15
    730a041043cb:	movdqu xmm15,XMMWORD PTR [rip+0x828c]        # 0x730a0410c660
    730a041043d4:	pcmpeqq xmm14,xmm15
    730a041043da:	movdqa xmm15,xmm0
    730a041043df:	cmpunordpd xmm15,xmm0
    730a041043e5:	por    xmm14,xmm15
    730a041043ea:	pmovmskb ecx,xmm14
    730a041043ef:	jrcxz  0x730a041043f6
    730a041043f1:	jmp    0x730a0410558f
    730a041043f6:	movdqa xmm4,xmm0
    730a041043fa:	movdqu XMMWORD PTR [r12+0x230],xmm4
    730a04104404:	movdqa xmm0,xmm12
    730a04104409:	movdqa xmm1,xmm8
    730a0410440e:	addpd  xmm0,xmm1
    730a04104412:	movdqa xmm14,xmm0
    730a04104417:	movdqu xmm15,XMMWORD PTR [rip+0x8230]        # 0x730a0410c650
    730a04104420:	pand   xmm14,xmm15
    730a04104425:	movdqu xmm15,XMMWORD PTR [rip+0x8232]        # 0x730a0410c660
    730a0410442e:	pcmpeqq xmm14,xmm15
    730a04104434:	movdqa xmm15,xmm0
    730a04104439:	cmpunordpd xmm15,xmm0
    730a0410443f:	por    xmm14,xmm15
    730a04104444:	pmovmskb ecx,xmm14
    730a04104449:	jrcxz  0x730a04104450
    730a0410444b:	jmp    0x730a041055b3
    730a04104450:	movdqa xmm3,xmm0
    730a04104454:	movdqu XMMWORD PTR [r12+0x140],xmm3
    730a0410445e:	movdqu xmm8,XMMWORD PTR [r12+0x1e0]
    730a04104468:	movdqa xmm0,xmm8
    730a0410446d:	movdqa xmm1,xmm2
    730a04104471:	pshufd xmm1,xmm1,0x44
    730a04104476:	mulpd  xmm0,xmm1
    730a0410447a:	movdqa xmm14,xmm0
    730a0410447f:	movdqu xmm15,XMMWORD PTR [rip+0x81c8]        # 0x730a0410c650
    730a04104488:	pand   xmm14,xmm15
    730a0410448d:	movdqu xmm15,XMMWORD PTR [rip+0x81ca]        # 0x730a0410c660
    730a04104496:	pcmpeqq xmm14,xmm15
    730a0410449c:	movdqa xmm15,xmm0
    730a041044a1:	cmpunordpd xmm15,xmm0
    730a041044a7:	por    xmm14,xmm15
    730a041044ac:	pmovmskb ecx,xmm14
    730a041044b1:	jrcxz  0x730a041044b8
    730a041044b3:	jmp    0x730a041055d9
    730a041044b8:	movdqa xmm11,xmm0
    730a041044bd:	movdqu XMMWORD PTR [r12+0x130],xmm11
    730a041044c7:	movdqa xmm0,xmm7
    730a041044cb:	movdqa xmm1,xmm6
    730a041044cf:	addpd  xmm0,xmm1
    730a041044d3:	movdqa xmm14,xmm0
    730a041044d8:	movdqu xmm15,XMMWORD PTR [rip+0x816f]        # 0x730a0410c650
    730a041044e1:	pand   xmm14,xmm15
    730a041044e6:	movdqu xmm15,XMMWORD PTR [rip+0x8171]        # 0x730a0410c660
    730a041044ef:	pcmpeqq xmm14,xmm15
    730a041044f5:	movdqa xmm15,xmm0
    730a041044fa:	cmpunordpd xmm15,xmm0
    730a04104500:	por    xmm14,xmm15
    730a04104505:	pmovmskb ecx,xmm14
    730a0410450a:	jrcxz  0x730a04104511
    730a0410450c:	jmp    0x730a041055fe
    730a04104511:	movdqa xmm2,xmm0
    730a04104515:	movdqu XMMWORD PTR [r12+0x150],xmm2
    730a0410451f:	mov    r13,r14
    730a04104522:	add    r13,0x70
    730a04104526:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    730a0410452c:	movdqu XMMWORD PTR [r12+0x240],xmm6
    730a04104536:	movdqa xmm0,xmm5
    730a0410453a:	movdqa xmm1,xmm9
    730a0410453f:	addpd  xmm0,xmm1
    730a04104543:	movdqa xmm14,xmm0
    730a04104548:	movdqu xmm15,XMMWORD PTR [rip+0x80ff]        # 0x730a0410c650
    730a04104551:	pand   xmm14,xmm15
    730a04104556:	movdqu xmm15,XMMWORD PTR [rip+0x8101]        # 0x730a0410c660
    730a0410455f:	pcmpeqq xmm14,xmm15
    730a04104565:	movdqa xmm15,xmm0
    730a0410456a:	cmpunordpd xmm15,xmm0
    730a04104570:	por    xmm14,xmm15
    730a04104575:	pmovmskb ecx,xmm14
    730a0410457a:	jrcxz  0x730a04104581
    730a0410457c:	jmp    0x730a04105622
    730a04104581:	movdqa xmm7,xmm0
    730a04104585:	movdqu XMMWORD PTR [r12+0x170],xmm7
    730a0410458f:	movdqu xmm5,XMMWORD PTR [r12+0x280]
    730a04104599:	movdqa xmm0,xmm6
    730a0410459d:	movdqa xmm1,xmm5
    730a041045a1:	pshufd xmm1,xmm1,0x44
    730a041045a6:	mulpd  xmm0,xmm1
    730a041045aa:	movdqa xmm14,xmm0
    730a041045af:	movdqu xmm15,XMMWORD PTR [rip+0x8098]        # 0x730a0410c650
    730a041045b8:	pand   xmm14,xmm15
    730a041045bd:	movdqu xmm15,XMMWORD PTR [rip+0x809a]        # 0x730a0410c660
    730a041045c6:	pcmpeqq xmm14,xmm15
    730a041045cc:	movdqa xmm15,xmm0
    730a041045d1:	cmpunordpd xmm15,xmm0
    730a041045d7:	por    xmm14,xmm15
    730a041045dc:	pmovmskb ecx,xmm14
    730a041045e1:	jrcxz  0x730a041045e8
    730a041045e3:	jmp    0x730a04105647
    730a041045e8:	movdqa xmm8,xmm0
    730a041045ed:	movdqu XMMWORD PTR [r12+0x160],xmm8
    730a041045f7:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    730a04104601:	movdqa xmm1,xmm5
    730a04104605:	pshufd xmm1,xmm1,0x44
    730a0410460a:	mulpd  xmm0,xmm1
    730a0410460e:	movdqa xmm14,xmm0
    730a04104613:	movdqu xmm15,XMMWORD PTR [rip+0x8034]        # 0x730a0410c650
    730a0410461c:	pand   xmm14,xmm15
    730a04104621:	movdqu xmm15,XMMWORD PTR [rip+0x8036]        # 0x730a0410c660
    730a0410462a:	pcmpeqq xmm14,xmm15
    730a04104630:	movdqa xmm15,xmm0
    730a04104635:	cmpunordpd xmm15,xmm0
    730a0410463b:	por    xmm14,xmm15
    730a04104640:	pmovmskb ecx,xmm14
    730a04104645:	jrcxz  0x730a0410464c
    730a04104647:	jmp    0x730a0410566b
    730a0410464c:	movdqa xmm6,xmm0
    730a04104650:	movdqu XMMWORD PTR [r12+0x180],xmm6
    730a0410465a:	movdqa xmm0,xmm10
    730a0410465f:	movdqa xmm1,xmm4
    730a04104663:	addpd  xmm0,xmm1
    730a04104667:	movdqa xmm14,xmm0
    730a0410466c:	movdqu xmm15,XMMWORD PTR [rip+0x7fdb]        # 0x730a0410c650
    730a04104675:	pand   xmm14,xmm15
    730a0410467a:	movdqu xmm15,XMMWORD PTR [rip+0x7fdd]        # 0x730a0410c660
    730a04104683:	pcmpeqq xmm14,xmm15
    730a04104689:	movdqa xmm15,xmm0
    730a0410468e:	cmpunordpd xmm15,xmm0
    730a04104694:	por    xmm14,xmm15
    730a04104699:	pmovmskb ecx,xmm14
    730a0410469e:	jrcxz  0x730a041046a5
    730a041046a0:	jmp    0x730a04105695
    730a041046a5:	movdqa xmm9,xmm0
    730a041046aa:	movdqu XMMWORD PTR [r12+0x210],xmm9
    730a041046b4:	mov    r13,r14
    730a041046b7:	add    r13,0x10
    730a041046bb:	movdqu xmm4,XMMWORD PTR [r14]
    730a041046c0:	movdqu xmm10,XMMWORD PTR [r13+0x0]
    730a041046c6:	movdqu XMMWORD PTR [r12+0x230],xmm10
    730a041046d0:	movdqa xmm0,xmm3
    730a041046d4:	movdqa xmm1,xmm11
    730a041046d9:	addpd  xmm0,xmm1
    730a041046dd:	movdqa xmm14,xmm0
    730a041046e2:	movdqu xmm15,XMMWORD PTR [rip+0x7f65]        # 0x730a0410c650
    730a041046eb:	pand   xmm14,xmm15
    730a041046f0:	movdqu xmm15,XMMWORD PTR [rip+0x7f67]        # 0x730a0410c660
    730a041046f9:	pcmpeqq xmm14,xmm15
    730a041046ff:	movdqa xmm15,xmm0
    730a04104704:	cmpunordpd xmm15,xmm0
    730a0410470a:	por    xmm14,xmm15
    730a0410470f:	pmovmskb ecx,xmm14
    730a04104714:	jrcxz  0x730a0410471b
    730a04104716:	jmp    0x730a041056ba
    730a0410471b:	movdqa xmm12,xmm0
    730a04104720:	movdqu XMMWORD PTR [r12+0x130],xmm12
    730a0410472a:	movdqa xmm0,xmm10
    730a0410472f:	movdqa xmm1,xmm5
    730a04104733:	pshufd xmm1,xmm1,0x44
    730a04104738:	mulpd  xmm0,xmm1
    730a0410473c:	movdqa xmm14,xmm0
    730a04104741:	movdqu xmm15,XMMWORD PTR [rip+0x7f06]        # 0x730a0410c650
    730a0410474a:	pand   xmm14,xmm15
    730a0410474f:	movdqu xmm15,XMMWORD PTR [rip+0x7f08]        # 0x730a0410c660
    730a04104758:	pcmpeqq xmm14,xmm15
    730a0410475e:	movdqa xmm15,xmm0
    730a04104763:	cmpunordpd xmm15,xmm0
    730a04104769:	por    xmm14,xmm15
    730a0410476e:	pmovmskb ecx,xmm14
    730a04104773:	jrcxz  0x730a0410477a
    730a04104775:	jmp    0x730a041056df
    730a0410477a:	movdqa xmm3,xmm0
    730a0410477e:	movdqu XMMWORD PTR [r12+0x220],xmm3
    730a04104788:	movdqa xmm0,xmm4
    730a0410478c:	movdqa xmm1,xmm5
    730a04104790:	pshufd xmm1,xmm1,0x44
    730a04104795:	mulpd  xmm0,xmm1
    730a04104799:	movdqa xmm14,xmm0
    730a0410479e:	movdqu xmm15,XMMWORD PTR [rip+0x7ea9]        # 0x730a0410c650
    730a041047a7:	pand   xmm14,xmm15
    730a041047ac:	movdqu xmm15,XMMWORD PTR [rip+0x7eab]        # 0x730a0410c660
    730a041047b5:	pcmpeqq xmm14,xmm15
    730a041047bb:	movdqa xmm15,xmm0
    730a041047c0:	cmpunordpd xmm15,xmm0
    730a041047c6:	por    xmm14,xmm15
    730a041047cb:	pmovmskb ecx,xmm14
    730a041047d0:	jrcxz  0x730a041047d7
    730a041047d2:	jmp    0x730a04105704
    730a041047d7:	movdqa xmm10,xmm0
    730a041047dc:	movdqa xmm0,xmm2
    730a041047e0:	movdqa xmm1,xmm8
    730a041047e5:	addpd  xmm0,xmm1
    730a041047e9:	movdqa xmm14,xmm0
    730a041047ee:	movdqu xmm15,XMMWORD PTR [rip+0x7e59]        # 0x730a0410c650
    730a041047f7:	pand   xmm14,xmm15
    730a041047fc:	movdqu xmm15,XMMWORD PTR [rip+0x7e5b]        # 0x730a0410c660
    730a04104805:	pcmpeqq xmm14,xmm15
    730a0410480b:	movdqa xmm15,xmm0
    730a04104810:	cmpunordpd xmm15,xmm0
    730a04104816:	por    xmm14,xmm15
    730a0410481b:	pmovmskb ecx,xmm14
    730a04104820:	jrcxz  0x730a04104827
    730a04104822:	jmp    0x730a04105728
    730a04104827:	movdqa xmm4,xmm0
    730a0410482b:	movdqu XMMWORD PTR [r12+0x140],xmm4
    730a04104835:	movdqa xmm0,xmm7
    730a04104839:	movdqa xmm1,xmm6
    730a0410483d:	addpd  xmm0,xmm1
    730a04104841:	movdqa xmm14,xmm0
    730a04104846:	movdqu xmm15,XMMWORD PTR [rip+0x7e01]        # 0x730a0410c650
    730a0410484f:	pand   xmm14,xmm15
    730a04104854:	movdqu xmm15,XMMWORD PTR [rip+0x7e03]        # 0x730a0410c660
    730a0410485d:	pcmpeqq xmm14,xmm15
    730a04104863:	movdqa xmm15,xmm0
    730a04104868:	cmpunordpd xmm15,xmm0
    730a0410486e:	por    xmm14,xmm15
    730a04104873:	pmovmskb ecx,xmm14
    730a04104878:	jrcxz  0x730a0410487f
    730a0410487a:	jmp    0x730a0410574d
    730a0410487f:	movdqa xmm2,xmm0
    730a04104883:	movdqu XMMWORD PTR [r12+0x150],xmm2
    730a0410488d:	movdqa xmm0,xmm9
    730a04104892:	movdqa xmm1,xmm3
    730a04104896:	addpd  xmm0,xmm1
    730a0410489a:	movdqa xmm14,xmm0
    730a0410489f:	movdqu xmm15,XMMWORD PTR [rip+0x7da8]        # 0x730a0410c650
    730a041048a8:	pand   xmm14,xmm15
    730a041048ad:	movdqu xmm15,XMMWORD PTR [rip+0x7daa]        # 0x730a0410c660
    730a041048b6:	pcmpeqq xmm14,xmm15
    730a041048bc:	movdqa xmm15,xmm0
    730a041048c1:	cmpunordpd xmm15,xmm0
    730a041048c7:	por    xmm14,xmm15
    730a041048cc:	pmovmskb ecx,xmm14
    730a041048d1:	jrcxz  0x730a041048d8
    730a041048d3:	jmp    0x730a04105771
    730a041048d8:	movdqa xmm5,xmm0
    730a041048dc:	movdqu XMMWORD PTR [r12+0x160],xmm5
    730a041048e6:	movdqa xmm0,xmm12
    730a041048eb:	movdqa xmm1,xmm10
    730a041048f0:	addpd  xmm0,xmm1
    730a041048f4:	movdqa xmm14,xmm0
    730a041048f9:	movdqu xmm15,XMMWORD PTR [rip+0x7d4e]        # 0x730a0410c650
    730a04104902:	pand   xmm14,xmm15
    730a04104907:	movdqu xmm15,XMMWORD PTR [rip+0x7d50]        # 0x730a0410c660
    730a04104910:	pcmpeqq xmm14,xmm15
    730a04104916:	movdqa xmm15,xmm0
    730a0410491b:	cmpunordpd xmm15,xmm0
    730a04104921:	por    xmm14,xmm15
    730a04104926:	pmovmskb ecx,xmm14
    730a0410492b:	jrcxz  0x730a04104932
    730a0410492d:	jmp    0x730a04105796
    730a04104932:	movdqa xmm3,xmm0
    730a04104936:	movdqu XMMWORD PTR [r12+0x120],xmm3
    730a04104940:	mov    r13,r15
    730a04104943:	add    r13,0x10
    730a04104947:	movdqu XMMWORD PTR [r15],xmm4
    730a0410494c:	mov    r14d,0x0
    730a04104952:	mov    DWORD PTR [r12+0x32c],r14d
    730a0410495a:	movdqu XMMWORD PTR [r13+0x0],xmm2
    730a04104960:	add    r15,0x20
    730a04104964:	mov    r13,r15
    730a04104967:	add    r13,0x10
    730a0410496b:	movdqu XMMWORD PTR [r15],xmm5
    730a04104970:	movdqu XMMWORD PTR [r13+0x0],xmm3
    730a04104976:	mov    rcx,QWORD PTR [r12+0x380]
    730a0410497e:	jrcxz  0x730a04104985
    730a04104980:	jmp    0x730a0410bd1d
    730a04104985:	cmp    BYTE PTR [rsp+0x8],0x0
    730a0410498a:	jne    0x730a04102c55
    730a04104990:	jmp    0x730a04104995
    730a04104995:	mov    r13d,DWORD PTR [r12+0x48]
    730a0410499a:	add    r13d,0x1
    730a0410499e:	mov    QWORD PTR [r12+0x48],r13
    730a041049a3:	sub    r13d,0x1f4
    730a041049aa:	mov    rcx,QWORD PTR [r12+0x380]
    730a041049b2:	jrcxz  0x730a041049b9
    730a041049b4:	jmp    0x730a0410bda2
    730a041049b9:	jne    0x730a04102c37
    730a041049bf:	mov    r11,rax
    730a041049c2:	lahf
    730a041049c3:	seto   al
    730a041049c6:	mov    WORD PTR [rsp],ax
    730a041049ca:	mov    rax,r11
    730a041049cd:	jmp    0x730a041049d2
    730a041049d2:	mov    r13d,0x430000
    730a041049d8:	mov    QWORD PTR [r12+0x40],r13
    730a041049dd:	mov    r13d,0x0
    730a041049e3:	mov    QWORD PTR [r12+0x48],r13
    730a041049e8:	mov    r13d,0x430cc0
    730a041049ee:	mov    r14,QWORD PTR [r13+0x0]
    730a041049f2:	mov    r13d,0x0
    730a041049f8:	mov    QWORD PTR [r12+0x110],r14
    730a04104a00:	mov    QWORD PTR [r12+0x118],r13
    730a04104a08:	jmp    0x730a04104a0d
    730a04104a0d:	mov    r13,QWORD PTR [r12+0x48]
    730a04104a12:	mov    r14,QWORD PTR [r12+0x50]
    730a04104a17:	add    r14,r13
    730a04104a1a:	movdqu xmm2,XMMWORD PTR [r14]
    730a04104a1f:	movdqu XMMWORD PTR [r12+0x120],xmm2
    730a04104a29:	add    r13,0x10
    730a04104a2d:	mov    QWORD PTR [r12+0x48],r13
    730a04104a32:	sub    r13,0x200
    730a04104a39:	mov    r13,QWORD PTR [r12+0x128]
    730a04104a41:	mov    r14d,0x0
    730a04104a47:	mov    QWORD PTR [r12+0x130],r13
    730a04104a4f:	mov    QWORD PTR [r12+0x138],r14
    730a04104a57:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    730a04104a61:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    730a04104a6b:	movdqa xmm0,xmm2
    730a04104a6f:	movdqa xmm1,xmm3
    730a04104a73:	movq   xmm0,xmm0
    730a04104a77:	movq   xmm1,xmm1
    730a04104a7b:	addsd  xmm0,xmm1
    730a04104a7f:	movdqa xmm14,xmm0
    730a04104a84:	movdqu xmm15,XMMWORD PTR [rip+0x7bc3]        # 0x730a0410c650
    730a04104a8d:	pand   xmm14,xmm15
    730a04104a92:	movdqu xmm15,XMMWORD PTR [rip+0x7bc5]        # 0x730a0410c660
    730a04104a9b:	pcmpeqq xmm14,xmm15
    730a04104aa1:	movdqa xmm15,xmm0
    730a04104aa6:	cmpunordpd xmm15,xmm0
    730a04104aac:	por    xmm14,xmm15
    730a04104ab1:	pmovmskb ecx,xmm14
    730a04104ab6:	jrcxz  0x730a04104abd
    730a04104ab8:	jmp    0x730a041057bc
    730a04104abd:	movdqa xmm4,xmm0
    730a04104ac1:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    730a04104acb:	movdqa xmm0,xmm4
    730a04104acf:	movdqa xmm1,xmm2
    730a04104ad3:	movq   xmm0,xmm0
    730a04104ad7:	movq   xmm1,xmm1
    730a04104adb:	addsd  xmm0,xmm1
    730a04104adf:	movdqa xmm14,xmm0
    730a04104ae4:	movdqu xmm15,XMMWORD PTR [rip+0x7b63]        # 0x730a0410c650
    730a04104aed:	pand   xmm14,xmm15
    730a04104af2:	movdqu xmm15,XMMWORD PTR [rip+0x7b65]        # 0x730a0410c660
    730a04104afb:	pcmpeqq xmm14,xmm15
    730a04104b01:	movdqa xmm15,xmm0
    730a04104b06:	cmpunordpd xmm15,xmm0
    730a04104b0c:	por    xmm14,xmm15
    730a04104b11:	pmovmskb ecx,xmm14
    730a04104b16:	jrcxz  0x730a04104b1d
    730a04104b18:	jmp    0x730a041057fb
    730a04104b1d:	movdqa xmm3,xmm0
    730a04104b21:	movdqu XMMWORD PTR [r12+0x110],xmm3
    730a04104b2b:	mov    rcx,QWORD PTR [r12+0x380]
    730a04104b33:	jrcxz  0x730a04104b3a
    730a04104b35:	jmp    0x730a0410be36
    730a04104b3a:	jne    0x730a04104b53
    730a04104b40:	mov    r11,rax
    730a04104b43:	lahf
    730a04104b44:	seto   al
    730a04104b47:	mov    WORD PTR [rsp],ax
    730a04104b4b:	mov    rax,r11
    730a04104b4e:	jmp    0x730a04104b66
    730a04104b53:	mov    r11,rax
    730a04104b56:	lahf
    730a04104b57:	seto   al
    730a04104b5a:	mov    WORD PTR [rsp],ax
    730a04104b5e:	mov    rax,r11
    730a04104b61:	jmp    0x730a04104a0d
    730a04104b66:	mov    r13,QWORD PTR [r12+0xf8]
    730a04104b6e:	mov    r14,r13
    730a04104b71:	add    r14,0x1d0
    730a04104b78:	mov    r15,r14
    730a04104b7b:	add    r15,0x8
    730a04104b7f:	mov    rbp,QWORD PTR [r14]
    730a04104b82:	mov    r14,QWORD PTR [r15]
    730a04104b85:	mov    QWORD PTR [r12+0xa0],rbp
    730a04104b8d:	mov    QWORD PTR [r12+0x98],r14
    730a04104b95:	mov    r14,QWORD PTR [r12+0x40]
    730a04104b9a:	add    r14,0xcc0
    730a04104ba1:	mov    r15,QWORD PTR [r12+0x110]
    730a04104ba9:	mov    QWORD PTR [r14],r15
    730a04104bac:	mov    r14d,0x0
    730a04104bb2:	mov    DWORD PTR [r12+0x32c],r14d
    730a04104bba:	mov    r14,r13
    730a04104bbd:	add    r14,0x1c0
    730a04104bc4:	mov    r15,r14
    730a04104bc7:	add    r15,0x8
    730a04104bcb:	mov    rbp,QWORD PTR [r14]
    730a04104bce:	mov    r14,QWORD PTR [r15]
    730a04104bd1:	mov    QWORD PTR [r12+0xe8],rbp
    730a04104bd9:	mov    QWORD PTR [r12+0xf0],r14
    730a04104be1:	mov    r14,r13
    730a04104be4:	add    r14,0x1b0
    730a04104beb:	mov    r15,r14
    730a04104bee:	add    r15,0x8
    730a04104bf2:	mov    rbp,QWORD PTR [r14]
    730a04104bf5:	mov    r14,QWORD PTR [r15]
    730a04104bf8:	mov    r15d,0x0
    730a04104bfe:	mov    QWORD PTR [r12+0x1a0],rbp
    730a04104c06:	mov    QWORD PTR [r12+0x1a8],r15
    730a04104c0e:	mov    r15d,0x0
    730a04104c14:	mov    QWORD PTR [r12+0x190],r14
    730a04104c1c:	mov    QWORD PTR [r12+0x198],r15
    730a04104c24:	mov    r14,r13
    730a04104c27:	add    r14,0x1a0
    730a04104c2e:	mov    r15,r14
    730a04104c31:	add    r15,0x8
    730a04104c35:	mov    rbp,QWORD PTR [r14]
    730a04104c38:	mov    r14,QWORD PTR [r15]
    730a04104c3b:	mov    r15d,0x0
    730a04104c41:	mov    QWORD PTR [r12+0x1c0],rbp
    730a04104c49:	mov    QWORD PTR [r12+0x1c8],r15
    730a04104c51:	mov    r15d,0x0
    730a04104c57:	mov    QWORD PTR [r12+0x1b0],r14
    730a04104c5f:	mov    QWORD PTR [r12+0x1b8],r15
    730a04104c67:	mov    r14,r13
    730a04104c6a:	add    r14,0x190
    730a04104c71:	mov    r15,r14
    730a04104c74:	add    r15,0x8
    730a04104c78:	mov    rbp,QWORD PTR [r14]
    730a04104c7b:	mov    r14,QWORD PTR [r15]
    730a04104c7e:	mov    r15d,0x0
    730a04104c84:	mov    QWORD PTR [r12+0x1e0],rbp
    730a04104c8c:	mov    QWORD PTR [r12+0x1e8],r15
    730a04104c94:	mov    r15d,0x0
    730a04104c9a:	mov    QWORD PTR [r12+0x1d0],r14
    730a04104ca2:	mov    QWORD PTR [r12+0x1d8],r15
    730a04104caa:	mov    r14,r13
    730a04104cad:	add    r14,0x180
    730a04104cb4:	mov    r15,r14
    730a04104cb7:	add    r15,0x8
    730a04104cbb:	mov    rbp,QWORD PTR [r14]
    730a04104cbe:	mov    r14,QWORD PTR [r15]
    730a04104cc1:	mov    r15d,0x0
    730a04104cc7:	mov    QWORD PTR [r12+0x200],rbp
    730a04104ccf:	mov    QWORD PTR [r12+0x208],r15
    730a04104cd7:	mov    r15d,0x0
    730a04104cdd:	mov    QWORD PTR [r12+0x1f0],r14
    730a04104ce5:	mov    QWORD PTR [r12+0x1f8],r15
    730a04104ced:	add    r13,0x1e0
    730a04104cf4:	mov    QWORD PTR [r12+0xf8],r13
    730a04104cfc:	mov    rcx,QWORD PTR [r12+0x380]
    730a04104d04:	jrcxz  0x730a04104d0b
    730a04104d06:	jmp    0x730a0410beca
    730a04104d0b:	mov    r13,QWORD PTR [r12+0xf0]
    730a04104d13:	mov    QWORD PTR [r12+0x100],r13
    730a04104d1b:	mov    r11,QWORD PTR [rsp]
    730a04104d1f:	mov    QWORD PTR [r12+0x398],r11
    730a04104d27:	mov    rdi,QWORD PTR [r12+0x100]
    730a04104d2f:	add    rsp,0x150
    730a04104d36:	movabs r11,0x5591a9c2c940
    730a04104d40:	jmp    r11
    730a04104d43:	mov    r13d,DWORD PTR [r12+0x98]
    730a04104d4b:	mov    r14d,DWORD PTR [r12]
    730a04104d4f:	add    r14d,r13d
    730a04104d52:	mov    QWORD PTR [r12],r14
    730a04104d56:	mov    r13d,0x4103f8
    730a04104d5c:	mov    QWORD PTR [r12+0xf0],r13
    730a04104d64:	mov    r13d,0x4109a4
    730a04104d6a:	mov    QWORD PTR [r12+0x100],r13
    730a04104d72:	mov    r11,QWORD PTR [rsp]
    730a04104d76:	mov    QWORD PTR [r12+0x398],r11
    730a04104d7e:	mov    edi,0x4109a4
    730a04104d83:	mov    QWORD PTR [r12+0x100],rdi
    730a04104d8b:	add    rsp,0x150
    730a04104d92:	nop    WORD PTR [rax+rax*1+0x0]
    730a04104d98:	jmp    QWORD PTR [rip+0x2]        # 0x730a04104da0
    730a04104d9e:	xchg   ax,ax
    730a04104da0:	rex (bad)
    730a04104da2:	adc    BYTE PTR [rdx+rcx*1],al
    730a04104da5:	jae    0x730a04104da7
    730a04104da7:	add    BYTE PTR [rax+0xa04104d],dh
    730a04104dad:	jae    0x730a04104daf
    730a04104daf:	add    BYTE PTR [rcx-0x45],cl
    730a04104db2:	rex leave
    730a04104db4:	ret    0x91a9
    730a04104db7:	push   rbp
    730a04104db8:	add    BYTE PTR [rax],al
    730a04104dba:	jmp    r11
    730a04104dbd:	movdqa xmm0,xmm2
    730a04104dc1:	movdqa xmm1,xmm3
    730a04104dc5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04104dce:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04104dd7:	call   0x730a04105840
    730a04104ddc:	jmp    0x730a0410274c
    730a04104de1:	movdqa xmm0,xmm2
    730a04104de5:	movdqa xmm1,xmm3
    730a04104de9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04104df2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04104dfb:	call   0x730a04105840
    730a04104e00:	jmp    0x730a041027d8
    730a04104e05:	movdqa xmm0,xmm9
    730a04104e0a:	movdqa xmm1,xmm2
    730a04104e0e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04104e17:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04104e20:	call   0x730a04105910
    730a04104e25:	jmp    0x730a04102e73
    730a04104e2a:	movdqa xmm0,xmm8
    730a04104e2f:	movdqa xmm1,xmm2
    730a04104e33:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04104e3c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04104e45:	call   0x730a04105a20
    730a04104e4a:	jmp    0x730a04102ed2
    730a04104e4f:	movdqa xmm0,xmm9
    730a04104e54:	movdqa xmm1,xmm7
    730a04104e58:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04104e61:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04104e6a:	call   0x730a04105b40
    730a04104e6f:	jmp    0x730a04102f47
    730a04104e74:	movdqa xmm0,xmm9
    730a04104e79:	movdqa xmm1,xmm6
    730a04104e7d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04104e86:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04104e8f:	call   0x730a04105c60
    730a04104e94:	jmp    0x730a04102f97
    730a04104e99:	movdqa xmm0,xmm9
    730a04104e9e:	movdqa xmm1,xmm6
    730a04104ea2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04104eab:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04104eb4:	call   0x730a04105d80
    730a04104eb9:	jmp    0x730a04102ff0
    730a04104ebe:	movdqa xmm0,xmm9
    730a04104ec3:	movdqa xmm1,xmm2
    730a04104ec7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04104ed0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04104ed9:	call   0x730a04105eb0
    730a04104ede:	jmp    0x730a04103091
    730a04104ee3:	mov    r11,rax
    730a04104ee6:	lahf
    730a04104ee7:	seto   al
    730a04104eea:	mov    WORD PTR [rsp],ax
    730a04104eee:	mov    rax,r11
    730a04104ef1:	movdqa xmm0,xmm10
    730a04104ef6:	movdqa xmm1,xmm9
    730a04104efb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04104f04:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04104f0d:	call   0x730a04105ff0
    730a04104f12:	mov    r11,rax
    730a04104f15:	movzx  eax,WORD PTR [rsp]
    730a04104f19:	add    al,0x7f
    730a04104f1b:	sahf
    730a04104f1c:	mov    rax,r11
    730a04104f1f:	jmp    0x730a041030fc
    730a04104f24:	mov    r11,rax
    730a04104f27:	lahf
    730a04104f28:	seto   al
    730a04104f2b:	mov    WORD PTR [rsp],ax
    730a04104f2f:	mov    rax,r11
    730a04104f32:	movdqa xmm0,xmm8
    730a04104f37:	movdqa xmm1,xmm10
    730a04104f3c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04104f45:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04104f4e:	call   0x730a04105ff0
    730a04104f53:	mov    r11,rax
    730a04104f56:	movzx  eax,WORD PTR [rsp]
    730a04104f5a:	add    al,0x7f
    730a04104f5c:	sahf
    730a04104f5d:	mov    rax,r11
    730a04104f60:	jmp    0x730a0410315c
    730a04104f65:	mov    r11,rax
    730a04104f68:	lahf
    730a04104f69:	seto   al
    730a04104f6c:	mov    WORD PTR [rsp],ax
    730a04104f70:	mov    rax,r11
    730a04104f73:	movdqa xmm0,xmm7
    730a04104f77:	movdqa xmm1,xmm10
    730a04104f7c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04104f85:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04104f8e:	call   0x730a041061c0
    730a04104f93:	mov    r11,rax
    730a04104f96:	movzx  eax,WORD PTR [rsp]
    730a04104f9a:	add    al,0x7f
    730a04104f9c:	sahf
    730a04104f9d:	mov    rax,r11
    730a04104fa0:	jmp    0x730a041031b5
    730a04104fa5:	movdqa xmm0,xmm12
    730a04104faa:	movdqa xmm1,xmm9
    730a04104faf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04104fb8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04104fc1:	call   0x730a04106380
    730a04104fc6:	jmp    0x730a0410332d
    730a04104fcb:	movdqa xmm0,xmm6
    730a04104fcf:	movdqa xmm1,xmm4
    730a04104fd3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04104fdc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04104fe5:	call   0x730a04106580
    730a04104fea:	jmp    0x730a0410339b
    730a04104fef:	movdqa xmm0,xmm8
    730a04104ff4:	movdqa xmm1,xmm11
    730a04104ff9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105002:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a0410500b:	call   0x730a04106770
    730a04105010:	jmp    0x730a041033f6
    730a04105015:	movdqa xmm0,xmm5
    730a04105019:	movdqa xmm1,xmm2
    730a0410501d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105026:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a0410502f:	call   0x730a04106960
    730a04105034:	jmp    0x730a04103453
    730a04105039:	movdqa xmm0,xmm9
    730a0410503e:	movdqa xmm1,xmm5
    730a04105042:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410504b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105054:	call   0x730a04106b30
    730a04105059:	jmp    0x730a041034bb
    730a0410505e:	movdqa xmm0,xmm13
    730a04105063:	movdqa xmm1,xmm2
    730a04105067:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105070:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105079:	call   0x730a04106d10
    730a0410507e:	jmp    0x730a04103534
    730a04105083:	movdqa xmm0,xmm9
    730a04105088:	movdqa xmm1,xmm5
    730a0410508c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105095:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a0410509e:	call   0x730a04106f00
    730a041050a3:	jmp    0x730a041035c1
    730a041050a8:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    730a041050b2:	movdqa xmm1,xmm6
    730a041050b6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041050bf:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041050c8:	call   0x730a041070c0
    730a041050cd:	jmp    0x730a041036b6
    730a041050d2:	movdqa xmm0,xmm9
    730a041050d7:	movdqa xmm1,xmm5
    730a041050db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041050e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041050ed:	call   0x730a041072a0
    730a041050f2:	jmp    0x730a04103714
    730a041050f7:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    730a04105101:	movdqa xmm1,xmm11
    730a04105106:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410510f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105118:	call   0x730a04107480
    730a0410511d:	jmp    0x730a0410378d
    730a04105122:	movdqa xmm0,xmm12
    730a04105127:	movdqa xmm1,xmm8
    730a0410512c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105135:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a0410513e:	call   0x730a04107670
    730a04105143:	jmp    0x730a041037e8
    730a04105148:	movdqa xmm0,xmm9
    730a0410514d:	movdqa xmm1,xmm5
    730a04105151:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410515a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105163:	call   0x730a04107860
    730a04105168:	jmp    0x730a04103869
    730a0410516d:	movdqa xmm0,xmm4
    730a04105171:	movdqa xmm1,xmm2
    730a04105175:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410517e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105187:	call   0x730a04107a40
    730a0410518c:	jmp    0x730a041038dc
    730a04105191:	movdqa xmm0,xmm13
    730a04105196:	movdqa xmm1,xmm2
    730a0410519a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041051a3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041051ac:	call   0x730a04107c20
    730a041051b1:	jmp    0x730a04103945
    730a041051b6:	movdqa xmm0,xmm5
    730a041051ba:	movdqa xmm1,xmm2
    730a041051be:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041051c7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041051d0:	call   0x730a04107e00
    730a041051d5:	jmp    0x730a041039bd
    730a041051da:	movdqa xmm0,xmm3
    730a041051de:	movdqa xmm1,xmm6
    730a041051e2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041051eb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041051f4:	call   0x730a04107fe0
    730a041051f9:	jmp    0x730a04103a30
    730a041051fe:	movdqa xmm0,xmm5
    730a04105202:	movdqa xmm1,xmm2
    730a04105206:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410520f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105218:	call   0x730a041081d0
    730a0410521d:	jmp    0x730a04103ad2
    730a04105222:	movdqa xmm0,xmm10
    730a04105227:	movdqa xmm1,xmm12
    730a0410522c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105235:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a0410523e:	call   0x730a041083c0
    730a04105243:	jmp    0x730a04103b43
    730a04105248:	movdqa xmm0,xmm7
    730a0410524c:	movdqa xmm1,xmm2
    730a04105250:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105259:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105262:	call   0x730a041085c0
    730a04105267:	jmp    0x730a04103b96
    730a0410526c:	movdqa xmm0,xmm11
    730a04105271:	movdqa xmm1,xmm13
    730a04105276:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410527f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105288:	call   0x730a041087a0
    730a0410528d:	jmp    0x730a04103be7
    730a04105292:	movdqa xmm0,xmm5
    730a04105296:	movdqa xmm1,xmm7
    730a0410529a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041052a3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041052ac:	call   0x730a04108980
    730a041052b1:	jmp    0x730a04103c44
    730a041052b6:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    730a041052c0:	movdqa xmm1,xmm7
    730a041052c4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041052cd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041052d6:	call   0x730a04108b50
    730a041052db:	jmp    0x730a04103c9e
    730a041052e0:	movdqa xmm0,xmm8
    730a041052e5:	movdqa xmm1,xmm4
    730a041052e9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041052f2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041052fb:	call   0x730a04108d20
    730a04105300:	jmp    0x730a04103ced
    730a04105305:	movdqa xmm0,xmm9
    730a0410530a:	movdqa xmm1,xmm6
    730a0410530e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105317:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105320:	call   0x730a04108f00
    730a04105325:	jmp    0x730a04103d47
    730a0410532a:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    730a04105334:	movdqa xmm1,xmm7
    730a04105338:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105341:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a0410534a:	call   0x730a041090d0
    730a0410534f:	jmp    0x730a04103daa
    730a04105354:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    730a0410535e:	movdqa xmm1,xmm7
    730a04105362:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410536b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105374:	call   0x730a04109290
    730a04105379:	jmp    0x730a04103e03
    730a0410537e:	movdqa xmm0,xmm3
    730a04105382:	movdqa xmm1,xmm10
    730a04105387:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105390:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105399:	call   0x730a04109460
    730a0410539e:	jmp    0x730a04103e5d
    730a041053a3:	movdqa xmm0,xmm2
    730a041053a7:	movdqa xmm1,xmm11
    730a041053ac:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041053b5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041053be:	call   0x730a04109630
    730a041053c3:	jmp    0x730a04103eb6
    730a041053c8:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    730a041053d2:	movdqa xmm1,xmm2
    730a041053d6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041053df:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041053e8:	call   0x730a041097f0
    730a041053ed:	jmp    0x730a04103f23
    730a041053f2:	movdqa xmm0,xmm4
    730a041053f6:	movdqa xmm1,xmm5
    730a041053fa:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105403:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a0410540c:	call   0x730a041099a0
    730a04105411:	jmp    0x730a04103f7c
    730a04105416:	movdqa xmm0,xmm12
    730a0410541b:	movdqa xmm1,xmm6
    730a0410541f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105428:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105431:	call   0x730a04109b70
    730a04105436:	jmp    0x730a04103fd6
    730a0410543b:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    730a04105445:	movdqa xmm1,xmm2
    730a04105449:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105452:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a0410545b:	call   0x730a04108980
    730a04105460:	jmp    0x730a041040b6
    730a04105465:	movdqa xmm0,xmm7
    730a04105469:	movdqa xmm1,xmm8
    730a0410546e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105477:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105480:	call   0x730a04108d20
    730a04105485:	jmp    0x730a04104106
    730a0410548a:	movdqa xmm0,xmm3
    730a0410548e:	movdqa xmm1,xmm9
    730a04105493:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410549c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041054a5:	call   0x730a04109d30
    730a041054aa:	jmp    0x730a04104156
    730a041054af:	movdqa xmm0,xmm6
    730a041054b3:	movdqa xmm1,xmm2
    730a041054b7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041054c0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041054c9:	call   0x730a04109f00
    730a041054ce:	jmp    0x730a041041b3
    730a041054d3:	movdqa xmm0,xmm6
    730a041054d7:	movdqa xmm1,xmm2
    730a041054db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041054e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041054ed:	call   0x730a04109290
    730a041054f2:	jmp    0x730a0410421a
    730a041054f7:	movdqa xmm0,xmm5
    730a041054fb:	movdqa xmm1,xmm2
    730a041054ff:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105508:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105511:	call   0x730a0410a0c0
    730a04105516:	jmp    0x730a04104278
    730a0410551b:	movdqa xmm0,xmm10
    730a04105520:	movdqa xmm1,xmm11
    730a04105525:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410552e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105537:	call   0x730a0410a290
    730a0410553c:	jmp    0x730a041042d2
    730a04105541:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    730a0410554b:	movdqa xmm1,xmm2
    730a0410554f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105558:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105561:	call   0x730a041097f0
    730a04105566:	jmp    0x730a04104335
    730a0410556b:	movdqa xmm0,xmm4
    730a0410556f:	movdqa xmm1,xmm3
    730a04105573:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410557c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105585:	call   0x730a041099a0
    730a0410558a:	jmp    0x730a0410438e
    730a0410558f:	movdqa xmm0,xmm3
    730a04105593:	movdqa xmm1,xmm2
    730a04105597:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041055a0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041055a9:	call   0x730a0410a460
    730a041055ae:	jmp    0x730a041043f6
    730a041055b3:	movdqa xmm0,xmm12
    730a041055b8:	movdqa xmm1,xmm8
    730a041055bd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041055c6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041055cf:	call   0x730a0410a630
    730a041055d4:	jmp    0x730a04104450
    730a041055d9:	movdqa xmm0,xmm8
    730a041055de:	movdqa xmm1,xmm2
    730a041055e2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041055eb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041055f4:	call   0x730a04108980
    730a041055f9:	jmp    0x730a041044b8
    730a041055fe:	movdqa xmm0,xmm7
    730a04105602:	movdqa xmm1,xmm6
    730a04105606:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410560f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105618:	call   0x730a0410a800
    730a0410561d:	jmp    0x730a04104511
    730a04105622:	movdqa xmm0,xmm5
    730a04105626:	movdqa xmm1,xmm9
    730a0410562b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105634:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a0410563d:	call   0x730a0410a9c0
    730a04105642:	jmp    0x730a04104581
    730a04105647:	movdqa xmm0,xmm6
    730a0410564b:	movdqa xmm1,xmm5
    730a0410564f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105658:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105661:	call   0x730a0410ab80
    730a04105666:	jmp    0x730a041045e8
    730a0410566b:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    730a04105675:	movdqa xmm1,xmm5
    730a04105679:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105682:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a0410568b:	call   0x730a0410ad30
    730a04105690:	jmp    0x730a0410464c
    730a04105695:	movdqa xmm0,xmm10
    730a0410569a:	movdqa xmm1,xmm4
    730a0410569e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041056a7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041056b0:	call   0x730a0410aef0
    730a041056b5:	jmp    0x730a041046a5
    730a041056ba:	movdqa xmm0,xmm3
    730a041056be:	movdqa xmm1,xmm11
    730a041056c3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041056cc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041056d5:	call   0x730a04108d20
    730a041056da:	jmp    0x730a0410471b
    730a041056df:	movdqa xmm0,xmm10
    730a041056e4:	movdqa xmm1,xmm5
    730a041056e8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041056f1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041056fa:	call   0x730a0410b0c0
    730a041056ff:	jmp    0x730a0410477a
    730a04105704:	movdqa xmm0,xmm4
    730a04105708:	movdqa xmm1,xmm5
    730a0410570c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105715:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a0410571e:	call   0x730a0410b290
    730a04105723:	jmp    0x730a041047d7
    730a04105728:	movdqa xmm0,xmm2
    730a0410572c:	movdqa xmm1,xmm8
    730a04105731:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410573a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105743:	call   0x730a04109b70
    730a04105748:	jmp    0x730a04104827
    730a0410574d:	movdqa xmm0,xmm7
    730a04105751:	movdqa xmm1,xmm6
    730a04105755:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410575e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105767:	call   0x730a0410b460
    730a0410576c:	jmp    0x730a0410487f
    730a04105771:	movdqa xmm0,xmm9
    730a04105776:	movdqa xmm1,xmm3
    730a0410577a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a04105783:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a0410578c:	call   0x730a0410b610
    730a04105791:	jmp    0x730a041048d8
    730a04105796:	movdqa xmm0,xmm12
    730a0410579b:	movdqa xmm1,xmm10
    730a041057a0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041057a9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041057b2:	call   0x730a0410b7b0
    730a041057b7:	jmp    0x730a04104932
    730a041057bc:	mov    r11,rax
    730a041057bf:	lahf
    730a041057c0:	seto   al
    730a041057c3:	mov    WORD PTR [rsp],ax
    730a041057c7:	mov    rax,r11
    730a041057ca:	movdqa xmm0,xmm2
    730a041057ce:	movdqa xmm1,xmm3
    730a041057d2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a041057db:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a041057e4:	call   0x730a0410b940
    730a041057e9:	mov    r11,rax
    730a041057ec:	movzx  eax,WORD PTR [rsp]
    730a041057f0:	add    al,0x7f
    730a041057f2:	sahf
    730a041057f3:	mov    rax,r11
    730a041057f6:	jmp    0x730a04104abd
    730a041057fb:	mov    r11,rax
    730a041057fe:	lahf
    730a041057ff:	seto   al
    730a04105802:	mov    WORD PTR [rsp],ax
    730a04105806:	mov    rax,r11
    730a04105809:	movdqa xmm0,xmm4
    730a0410580d:	movdqa xmm1,xmm2
    730a04105811:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    730a0410581a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    730a04105823:	call   0x730a0410baa0
    730a04105828:	mov    r11,rax
    730a0410582b:	movzx  eax,WORD PTR [rsp]
    730a0410582f:	add    al,0x7f
    730a04105831:	sahf
    730a04105832:	mov    rax,r11
    730a04105835:	jmp    0x730a04104b1d
    730a0410583a:	nop    WORD PTR [rax+rax*1+0x0]
    730a04105840:	sub    rsp,0x8
    730a04105844:	mov    QWORD PTR [r12+0x378],0x3
    730a04105850:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04105856:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410585c:	mov    QWORD PTR [r12+0x108],rbx
    730a04105864:	stmxcsr DWORD PTR [r12-0x28]
    730a0410586a:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410586f:	test   r10d,0x3f
    730a04105876:	je     0x730a0410589b
    730a0410587c:	mov    r11d,r10d
    730a0410587f:	shr    r10d,1
    730a04105882:	and    r10d,0x1e
    730a04105886:	and    r11d,0x1
    730a0410588a:	or     r10d,r11d
    730a0410588d:	or     DWORD PTR [r12+0x314],r10d
    730a04105895:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410589b:	ldmxcsr DWORD PTR [r12-0x38]
    730a041058a1:	lea    rdi,[rsp+0x110]
    730a041058a9:	lea    rsi,[rsp+0xf0]
    730a041058b1:	lea    rdx,[rsp+0x100]
    730a041058b9:	mov    ecx,0x16
    730a041058be:	mov    r8d,0x0
    730a041058c4:	lea    r9,[r12+0x314]
    730a041058cc:	movabs r11,0x5591a9a93650
    730a041058d6:	call   r11
    730a041058d9:	ldmxcsr DWORD PTR [r12-0x28]
    730a041058df:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a041058e5:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a041058eb:	mov    rbx,QWORD PTR [r12+0x108]
    730a041058f3:	mov    QWORD PTR [r12+0x378],0x2
    730a041058ff:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04105908:	add    rsp,0x8
    730a0410590c:	ret
    730a0410590d:	nop    DWORD PTR [rax]
    730a04105910:	sub    rsp,0x8
    730a04105914:	mov    QWORD PTR [r12+0x378],0x3
    730a04105920:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04105926:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410592c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04105932:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a0410593c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04105946:	mov    QWORD PTR [r12+0x108],rbx
    730a0410594e:	stmxcsr DWORD PTR [r12-0x28]
    730a04105954:	mov    r10d,DWORD PTR [r12-0x28]
    730a04105959:	test   r10d,0x3f
    730a04105960:	je     0x730a04105985
    730a04105966:	mov    r11d,r10d
    730a04105969:	shr    r10d,1
    730a0410596c:	and    r10d,0x1e
    730a04105970:	and    r11d,0x1
    730a04105974:	or     r10d,r11d
    730a04105977:	or     DWORD PTR [r12+0x314],r10d
    730a0410597f:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04105985:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410598b:	lea    rdi,[rsp+0x110]
    730a04105993:	lea    rsi,[rsp+0xf0]
    730a0410599b:	lea    rdx,[rsp+0x100]
    730a041059a3:	mov    ecx,0x16
    730a041059a8:	mov    r8d,0x0
    730a041059ae:	lea    r9,[r12+0x314]
    730a041059b6:	movabs r11,0x5591a9a93650
    730a041059c0:	call   r11
    730a041059c3:	ldmxcsr DWORD PTR [r12-0x28]
    730a041059c9:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a041059cf:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a041059d5:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a041059db:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a041059e5:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a041059ef:	mov    rbx,QWORD PTR [r12+0x108]
    730a041059f7:	mov    QWORD PTR [r12+0x378],0x2
    730a04105a03:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04105a0c:	add    rsp,0x8
    730a04105a10:	ret
    730a04105a11:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04105a20:	sub    rsp,0x8
    730a04105a24:	mov    QWORD PTR [r12+0x378],0x3
    730a04105a30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04105a36:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04105a3c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04105a42:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a04105a4c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04105a56:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04105a60:	mov    QWORD PTR [r12+0x108],rbx
    730a04105a68:	stmxcsr DWORD PTR [r12-0x28]
    730a04105a6e:	mov    r10d,DWORD PTR [r12-0x28]
    730a04105a73:	test   r10d,0x3f
    730a04105a7a:	je     0x730a04105a9f
    730a04105a80:	mov    r11d,r10d
    730a04105a83:	shr    r10d,1
    730a04105a86:	and    r10d,0x1e
    730a04105a8a:	and    r11d,0x1
    730a04105a8e:	or     r10d,r11d
    730a04105a91:	or     DWORD PTR [r12+0x314],r10d
    730a04105a99:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04105a9f:	ldmxcsr DWORD PTR [r12-0x38]
    730a04105aa5:	lea    rdi,[rsp+0x110]
    730a04105aad:	lea    rsi,[rsp+0xf0]
    730a04105ab5:	lea    rdx,[rsp+0x100]
    730a04105abd:	mov    ecx,0x56
    730a04105ac2:	mov    r8d,0x0
    730a04105ac8:	lea    r9,[r12+0x314]
    730a04105ad0:	movabs r11,0x5591a9a93650
    730a04105ada:	call   r11
    730a04105add:	ldmxcsr DWORD PTR [r12-0x28]
    730a04105ae3:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04105ae9:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04105aef:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04105af5:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04105aff:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04105b09:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04105b13:	mov    rbx,QWORD PTR [r12+0x108]
    730a04105b1b:	mov    QWORD PTR [r12+0x378],0x2
    730a04105b27:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04105b30:	add    rsp,0x8
    730a04105b34:	ret
    730a04105b35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04105b40:	sub    rsp,0x8
    730a04105b44:	mov    QWORD PTR [r12+0x378],0x3
    730a04105b50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04105b56:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04105b5c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04105b62:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04105b6c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04105b76:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04105b80:	mov    QWORD PTR [r12+0x108],rbx
    730a04105b88:	stmxcsr DWORD PTR [r12-0x28]
    730a04105b8e:	mov    r10d,DWORD PTR [r12-0x28]
    730a04105b93:	test   r10d,0x3f
    730a04105b9a:	je     0x730a04105bbf
    730a04105ba0:	mov    r11d,r10d
    730a04105ba3:	shr    r10d,1
    730a04105ba6:	and    r10d,0x1e
    730a04105baa:	and    r11d,0x1
    730a04105bae:	or     r10d,r11d
    730a04105bb1:	or     DWORD PTR [r12+0x314],r10d
    730a04105bb9:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04105bbf:	ldmxcsr DWORD PTR [r12-0x38]
    730a04105bc5:	lea    rdi,[rsp+0x110]
    730a04105bcd:	lea    rsi,[rsp+0xf0]
    730a04105bd5:	lea    rdx,[rsp+0x100]
    730a04105bdd:	mov    ecx,0x16
    730a04105be2:	mov    r8d,0x0
    730a04105be8:	lea    r9,[r12+0x314]
    730a04105bf0:	movabs r11,0x5591a9a93650
    730a04105bfa:	call   r11
    730a04105bfd:	ldmxcsr DWORD PTR [r12-0x28]
    730a04105c03:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04105c09:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04105c0f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04105c15:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04105c1f:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04105c29:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04105c33:	mov    rbx,QWORD PTR [r12+0x108]
    730a04105c3b:	mov    QWORD PTR [r12+0x378],0x2
    730a04105c47:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04105c50:	add    rsp,0x8
    730a04105c54:	ret
    730a04105c55:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04105c60:	sub    rsp,0x8
    730a04105c64:	mov    QWORD PTR [r12+0x378],0x3
    730a04105c70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04105c76:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04105c7c:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a04105c86:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04105c90:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04105c9a:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04105ca4:	mov    QWORD PTR [r12+0x108],rbx
    730a04105cac:	stmxcsr DWORD PTR [r12-0x28]
    730a04105cb2:	mov    r10d,DWORD PTR [r12-0x28]
    730a04105cb7:	test   r10d,0x3f
    730a04105cbe:	je     0x730a04105ce3
    730a04105cc4:	mov    r11d,r10d
    730a04105cc7:	shr    r10d,1
    730a04105cca:	and    r10d,0x1e
    730a04105cce:	and    r11d,0x1
    730a04105cd2:	or     r10d,r11d
    730a04105cd5:	or     DWORD PTR [r12+0x314],r10d
    730a04105cdd:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04105ce3:	ldmxcsr DWORD PTR [r12-0x38]
    730a04105ce9:	lea    rdi,[rsp+0x110]
    730a04105cf1:	lea    rsi,[rsp+0xf0]
    730a04105cf9:	lea    rdx,[rsp+0x100]
    730a04105d01:	mov    ecx,0x16
    730a04105d06:	mov    r8d,0x0
    730a04105d0c:	lea    r9,[r12+0x314]
    730a04105d14:	movabs r11,0x5591a9a93650
    730a04105d1e:	call   r11
    730a04105d21:	ldmxcsr DWORD PTR [r12-0x28]
    730a04105d27:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04105d2d:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04105d33:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04105d3d:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04105d47:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04105d51:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04105d5b:	mov    rbx,QWORD PTR [r12+0x108]
    730a04105d63:	mov    QWORD PTR [r12+0x378],0x2
    730a04105d6f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04105d78:	add    rsp,0x8
    730a04105d7c:	ret
    730a04105d7d:	nop    DWORD PTR [rax]
    730a04105d80:	sub    rsp,0x8
    730a04105d84:	mov    QWORD PTR [r12+0x378],0x3
    730a04105d90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04105d96:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04105d9c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04105da2:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a04105dac:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04105db6:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04105dc0:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04105dca:	mov    QWORD PTR [r12+0x108],rbx
    730a04105dd2:	stmxcsr DWORD PTR [r12-0x28]
    730a04105dd8:	mov    r10d,DWORD PTR [r12-0x28]
    730a04105ddd:	test   r10d,0x3f
    730a04105de4:	je     0x730a04105e09
    730a04105dea:	mov    r11d,r10d
    730a04105ded:	shr    r10d,1
    730a04105df0:	and    r10d,0x1e
    730a04105df4:	and    r11d,0x1
    730a04105df8:	or     r10d,r11d
    730a04105dfb:	or     DWORD PTR [r12+0x314],r10d
    730a04105e03:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04105e09:	ldmxcsr DWORD PTR [r12-0x38]
    730a04105e0f:	lea    rdi,[rsp+0x110]
    730a04105e17:	lea    rsi,[rsp+0xf0]
    730a04105e1f:	lea    rdx,[rsp+0x100]
    730a04105e27:	mov    ecx,0x16
    730a04105e2c:	mov    r8d,0x0
    730a04105e32:	lea    r9,[r12+0x314]
    730a04105e3a:	movabs r11,0x5591a9a93650
    730a04105e44:	call   r11
    730a04105e47:	ldmxcsr DWORD PTR [r12-0x28]
    730a04105e4d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04105e53:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04105e59:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04105e5f:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04105e69:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04105e73:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04105e7d:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04105e87:	mov    rbx,QWORD PTR [r12+0x108]
    730a04105e8f:	mov    QWORD PTR [r12+0x378],0x2
    730a04105e9b:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04105ea4:	add    rsp,0x8
    730a04105ea8:	ret
    730a04105ea9:	nop    DWORD PTR [rax+0x0]
    730a04105eb0:	sub    rsp,0x8
    730a04105eb4:	mov    QWORD PTR [r12+0x378],0x3
    730a04105ec0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04105ec6:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04105ecc:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a04105ed6:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04105ee0:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04105eea:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04105ef4:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04105efe:	mov    QWORD PTR [r12+0x108],rbx
    730a04105f06:	stmxcsr DWORD PTR [r12-0x28]
    730a04105f0c:	mov    r10d,DWORD PTR [r12-0x28]
    730a04105f11:	test   r10d,0x3f
    730a04105f18:	je     0x730a04105f3d
    730a04105f1e:	mov    r11d,r10d
    730a04105f21:	shr    r10d,1
    730a04105f24:	and    r10d,0x1e
    730a04105f28:	and    r11d,0x1
    730a04105f2c:	or     r10d,r11d
    730a04105f2f:	or     DWORD PTR [r12+0x314],r10d
    730a04105f37:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04105f3d:	ldmxcsr DWORD PTR [r12-0x38]
    730a04105f43:	lea    rdi,[rsp+0x110]
    730a04105f4b:	lea    rsi,[rsp+0xf0]
    730a04105f53:	lea    rdx,[rsp+0x100]
    730a04105f5b:	mov    ecx,0x56
    730a04105f60:	mov    r8d,0x0
    730a04105f66:	lea    r9,[r12+0x314]
    730a04105f6e:	movabs r11,0x5591a9a93650
    730a04105f78:	call   r11
    730a04105f7b:	ldmxcsr DWORD PTR [r12-0x28]
    730a04105f81:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04105f87:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04105f8d:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04105f97:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04105fa1:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04105fab:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04105fb5:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04105fbf:	mov    rbx,QWORD PTR [r12+0x108]
    730a04105fc7:	mov    QWORD PTR [r12+0x378],0x2
    730a04105fd3:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04105fdc:	add    rsp,0x8
    730a04105fe0:	ret
    730a04105fe1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04105ff0:	sub    rsp,0x8
    730a04105ff4:	mov    QWORD PTR [r12+0x378],0x3
    730a04106000:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04106006:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410600c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04106012:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a0410601c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04106026:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04106030:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a0410603a:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04106044:	push   rdx
    730a04106045:	push   rsi
    730a04106046:	push   r10
    730a04106048:	push   r11
    730a0410604a:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410604f:	mov    r10d,edx
    730a04106052:	and    r10d,0xc000
    730a04106059:	shl    r10d,0x10
    730a0410605d:	mov    r11d,edx
    730a04106060:	and    r11d,0x100
    730a04106067:	shl    r11d,0x15
    730a0410606b:	or     r10d,r11d
    730a0410606e:	and    edx,0x1
    730a04106071:	shl    edx,0x1c
    730a04106074:	or     r10d,edx
    730a04106077:	btc    r10,0x1d
    730a0410607c:	mov    r11d,0xf0000000
    730a04106082:	and    r11,r10
    730a04106085:	movabs rsi,0xffffffff0fffffff
    730a0410608f:	and    rbx,rsi
    730a04106092:	or     rbx,r11
    730a04106095:	pop    r11
    730a04106097:	pop    r10
    730a04106099:	pop    rsi
    730a0410609a:	pop    rdx
    730a0410609b:	mov    QWORD PTR [r12+0x108],rbx
    730a041060a3:	stmxcsr DWORD PTR [r12-0x28]
    730a041060a9:	mov    r10d,DWORD PTR [r12-0x28]
    730a041060ae:	test   r10d,0x3f
    730a041060b5:	je     0x730a041060da
    730a041060bb:	mov    r11d,r10d
    730a041060be:	shr    r10d,1
    730a041060c1:	and    r10d,0x1e
    730a041060c5:	and    r11d,0x1
    730a041060c9:	or     r10d,r11d
    730a041060cc:	or     DWORD PTR [r12+0x314],r10d
    730a041060d4:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a041060da:	ldmxcsr DWORD PTR [r12-0x38]
    730a041060e0:	lea    rdi,[rsp+0x110]
    730a041060e8:	lea    rsi,[rsp+0xf0]
    730a041060f0:	lea    rdx,[rsp+0x100]
    730a041060f8:	mov    ecx,0x14
    730a041060fd:	mov    r8d,0x0
    730a04106103:	lea    r9,[r12+0x314]
    730a0410610b:	movabs r11,0x5591a9a93650
    730a04106115:	call   r11
    730a04106118:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410611e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04106124:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410612a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04106130:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a0410613a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04106144:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410614e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04106158:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04106162:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410616a:	mov    QWORD PTR [r12+0x378],0x2
    730a04106176:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410617f:	mov    rdx,rbx
    730a04106182:	shr    rdx,0x10
    730a04106186:	and    edx,0xc000
    730a0410618c:	mov    rax,rbx
    730a0410618f:	shr    rax,0x15
    730a04106193:	and    eax,0x100
    730a04106198:	xor    eax,0x100
    730a0410619d:	or     edx,eax
    730a0410619f:	mov    rax,rbx
    730a041061a2:	shr    rax,0x1c
    730a041061a6:	and    eax,0x1
    730a041061a9:	or     edx,eax
    730a041061ab:	mov    QWORD PTR [rsp+0x10],rdx
    730a041061b0:	add    rsp,0x8
    730a041061b4:	ret
    730a041061b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a041061c0:	sub    rsp,0x8
    730a041061c4:	mov    QWORD PTR [r12+0x378],0x3
    730a041061d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a041061d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041061dc:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a041061e2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041061e8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a041061f2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a041061fc:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04106206:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04106210:	push   rdx
    730a04106211:	push   rsi
    730a04106212:	push   r10
    730a04106214:	push   r11
    730a04106216:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410621b:	mov    r10d,edx
    730a0410621e:	and    r10d,0xc000
    730a04106225:	shl    r10d,0x10
    730a04106229:	mov    r11d,edx
    730a0410622c:	and    r11d,0x100
    730a04106233:	shl    r11d,0x15
    730a04106237:	or     r10d,r11d
    730a0410623a:	and    edx,0x1
    730a0410623d:	shl    edx,0x1c
    730a04106240:	or     r10d,edx
    730a04106243:	btc    r10,0x1d
    730a04106248:	mov    r11d,0xf0000000
    730a0410624e:	and    r11,r10
    730a04106251:	movabs rsi,0xffffffff0fffffff
    730a0410625b:	and    rbx,rsi
    730a0410625e:	or     rbx,r11
    730a04106261:	pop    r11
    730a04106263:	pop    r10
    730a04106265:	pop    rsi
    730a04106266:	pop    rdx
    730a04106267:	mov    QWORD PTR [r12+0x108],rbx
    730a0410626f:	stmxcsr DWORD PTR [r12-0x28]
    730a04106275:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410627a:	test   r10d,0x3f
    730a04106281:	je     0x730a041062a6
    730a04106287:	mov    r11d,r10d
    730a0410628a:	shr    r10d,1
    730a0410628d:	and    r10d,0x1e
    730a04106291:	and    r11d,0x1
    730a04106295:	or     r10d,r11d
    730a04106298:	or     DWORD PTR [r12+0x314],r10d
    730a041062a0:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a041062a6:	ldmxcsr DWORD PTR [r12-0x38]
    730a041062ac:	lea    rdi,[rsp+0x110]
    730a041062b4:	lea    rsi,[rsp+0xf0]
    730a041062bc:	lea    rdx,[rsp+0x100]
    730a041062c4:	mov    ecx,0x14
    730a041062c9:	mov    r8d,0x0
    730a041062cf:	lea    r9,[r12+0x314]
    730a041062d7:	movabs r11,0x5591a9a93650
    730a041062e1:	call   r11
    730a041062e4:	ldmxcsr DWORD PTR [r12-0x28]
    730a041062ea:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a041062f0:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a041062f6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a041062fc:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04106302:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410630c:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04106316:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04106320:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410632a:	mov    rbx,QWORD PTR [r12+0x108]
    730a04106332:	mov    QWORD PTR [r12+0x378],0x2
    730a0410633e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04106347:	mov    rdx,rbx
    730a0410634a:	shr    rdx,0x10
    730a0410634e:	and    edx,0xc000
    730a04106354:	mov    rax,rbx
    730a04106357:	shr    rax,0x15
    730a0410635b:	and    eax,0x100
    730a04106360:	xor    eax,0x100
    730a04106365:	or     edx,eax
    730a04106367:	mov    rax,rbx
    730a0410636a:	shr    rax,0x1c
    730a0410636e:	and    eax,0x1
    730a04106371:	or     edx,eax
    730a04106373:	mov    QWORD PTR [rsp+0x10],rdx
    730a04106378:	add    rsp,0x8
    730a0410637c:	ret
    730a0410637d:	nop    DWORD PTR [rax]
    730a04106380:	sub    rsp,0x8
    730a04106384:	mov    QWORD PTR [r12+0x378],0x3
    730a04106390:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04106396:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410639c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041063a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a041063a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a041063ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041063b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a041063be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a041063c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a041063d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a041063dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a041063e6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a041063f0:	push   rdx
    730a041063f1:	push   rsi
    730a041063f2:	push   r10
    730a041063f4:	push   r11
    730a041063f6:	mov    rdx,QWORD PTR [rsp+0x30]
    730a041063fb:	mov    r10d,edx
    730a041063fe:	and    r10d,0xc000
    730a04106405:	shl    r10d,0x10
    730a04106409:	mov    r11d,edx
    730a0410640c:	and    r11d,0x100
    730a04106413:	shl    r11d,0x15
    730a04106417:	or     r10d,r11d
    730a0410641a:	and    edx,0x1
    730a0410641d:	shl    edx,0x1c
    730a04106420:	or     r10d,edx
    730a04106423:	btc    r10,0x1d
    730a04106428:	mov    r11d,0xf0000000
    730a0410642e:	and    r11,r10
    730a04106431:	movabs rsi,0xffffffff0fffffff
    730a0410643b:	and    rbx,rsi
    730a0410643e:	or     rbx,r11
    730a04106441:	pop    r11
    730a04106443:	pop    r10
    730a04106445:	pop    rsi
    730a04106446:	pop    rdx
    730a04106447:	mov    QWORD PTR [r12+0x108],rbx
    730a0410644f:	stmxcsr DWORD PTR [r12-0x28]
    730a04106455:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410645a:	test   r10d,0x3f
    730a04106461:	je     0x730a04106486
    730a04106467:	mov    r11d,r10d
    730a0410646a:	shr    r10d,1
    730a0410646d:	and    r10d,0x1e
    730a04106471:	and    r11d,0x1
    730a04106475:	or     r10d,r11d
    730a04106478:	or     DWORD PTR [r12+0x314],r10d
    730a04106480:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04106486:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410648c:	lea    rdi,[rsp+0x110]
    730a04106494:	lea    rsi,[rsp+0xf0]
    730a0410649c:	lea    rdx,[rsp+0x100]
    730a041064a4:	mov    ecx,0x14
    730a041064a9:	mov    r8d,0x0
    730a041064af:	lea    r9,[r12+0x314]
    730a041064b7:	movabs r11,0x5591a9a93650
    730a041064c1:	call   r11
    730a041064c4:	ldmxcsr DWORD PTR [r12-0x28]
    730a041064ca:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a041064d0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a041064d6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a041064dc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a041064e2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a041064e8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a041064ee:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a041064f8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04106502:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410650c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04106516:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04106520:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a0410652a:	mov    rbx,QWORD PTR [r12+0x108]
    730a04106532:	mov    QWORD PTR [r12+0x378],0x2
    730a0410653e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04106547:	mov    rdx,rbx
    730a0410654a:	shr    rdx,0x10
    730a0410654e:	and    edx,0xc000
    730a04106554:	mov    rax,rbx
    730a04106557:	shr    rax,0x15
    730a0410655b:	and    eax,0x100
    730a04106560:	xor    eax,0x100
    730a04106565:	or     edx,eax
    730a04106567:	mov    rax,rbx
    730a0410656a:	shr    rax,0x1c
    730a0410656e:	and    eax,0x1
    730a04106571:	or     edx,eax
    730a04106573:	mov    QWORD PTR [rsp+0x10],rdx
    730a04106578:	add    rsp,0x8
    730a0410657c:	ret
    730a0410657d:	nop    DWORD PTR [rax]
    730a04106580:	sub    rsp,0x8
    730a04106584:	mov    QWORD PTR [r12+0x378],0x3
    730a04106590:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04106596:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410659c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041065a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a041065a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a041065ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041065b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a041065be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a041065c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a041065d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a041065dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a041065e6:	push   rdx
    730a041065e7:	push   rsi
    730a041065e8:	push   r10
    730a041065ea:	push   r11
    730a041065ec:	mov    rdx,QWORD PTR [rsp+0x30]
    730a041065f1:	mov    r10d,edx
    730a041065f4:	and    r10d,0xc000
    730a041065fb:	shl    r10d,0x10
    730a041065ff:	mov    r11d,edx
    730a04106602:	and    r11d,0x100
    730a04106609:	shl    r11d,0x15
    730a0410660d:	or     r10d,r11d
    730a04106610:	and    edx,0x1
    730a04106613:	shl    edx,0x1c
    730a04106616:	or     r10d,edx
    730a04106619:	btc    r10,0x1d
    730a0410661e:	mov    r11d,0xf0000000
    730a04106624:	and    r11,r10
    730a04106627:	movabs rsi,0xffffffff0fffffff
    730a04106631:	and    rbx,rsi
    730a04106634:	or     rbx,r11
    730a04106637:	pop    r11
    730a04106639:	pop    r10
    730a0410663b:	pop    rsi
    730a0410663c:	pop    rdx
    730a0410663d:	mov    QWORD PTR [r12+0x108],rbx
    730a04106645:	stmxcsr DWORD PTR [r12-0x28]
    730a0410664b:	mov    r10d,DWORD PTR [r12-0x28]
    730a04106650:	test   r10d,0x3f
    730a04106657:	je     0x730a0410667c
    730a0410665d:	mov    r11d,r10d
    730a04106660:	shr    r10d,1
    730a04106663:	and    r10d,0x1e
    730a04106667:	and    r11d,0x1
    730a0410666b:	or     r10d,r11d
    730a0410666e:	or     DWORD PTR [r12+0x314],r10d
    730a04106676:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410667c:	ldmxcsr DWORD PTR [r12-0x38]
    730a04106682:	lea    rdi,[rsp+0x110]
    730a0410668a:	lea    rsi,[rsp+0xf0]
    730a04106692:	lea    rdx,[rsp+0x100]
    730a0410669a:	mov    ecx,0x14
    730a0410669f:	mov    r8d,0x0
    730a041066a5:	lea    r9,[r12+0x314]
    730a041066ad:	movabs r11,0x5591a9a93650
    730a041066b7:	call   r11
    730a041066ba:	ldmxcsr DWORD PTR [r12-0x28]
    730a041066c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a041066c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a041066cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a041066d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a041066d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a041066de:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a041066e4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a041066ee:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a041066f8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04106702:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a0410670c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a04106716:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410671e:	mov    QWORD PTR [r12+0x378],0x2
    730a0410672a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04106733:	mov    rdx,rbx
    730a04106736:	shr    rdx,0x10
    730a0410673a:	and    edx,0xc000
    730a04106740:	mov    rax,rbx
    730a04106743:	shr    rax,0x15
    730a04106747:	and    eax,0x100
    730a0410674c:	xor    eax,0x100
    730a04106751:	or     edx,eax
    730a04106753:	mov    rax,rbx
    730a04106756:	shr    rax,0x1c
    730a0410675a:	and    eax,0x1
    730a0410675d:	or     edx,eax
    730a0410675f:	mov    QWORD PTR [rsp+0x10],rdx
    730a04106764:	add    rsp,0x8
    730a04106768:	ret
    730a04106769:	nop    DWORD PTR [rax+0x0]
    730a04106770:	sub    rsp,0x8
    730a04106774:	mov    QWORD PTR [r12+0x378],0x3
    730a04106780:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04106786:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410678c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04106792:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04106798:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a041067a2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a041067ac:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a041067b6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a041067c0:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a041067ca:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a041067d4:	push   rdx
    730a041067d5:	push   rsi
    730a041067d6:	push   r10
    730a041067d8:	push   r11
    730a041067da:	mov    rdx,QWORD PTR [rsp+0x30]
    730a041067df:	mov    r10d,edx
    730a041067e2:	and    r10d,0xc000
    730a041067e9:	shl    r10d,0x10
    730a041067ed:	mov    r11d,edx
    730a041067f0:	and    r11d,0x100
    730a041067f7:	shl    r11d,0x15
    730a041067fb:	or     r10d,r11d
    730a041067fe:	and    edx,0x1
    730a04106801:	shl    edx,0x1c
    730a04106804:	or     r10d,edx
    730a04106807:	btc    r10,0x1d
    730a0410680c:	mov    r11d,0xf0000000
    730a04106812:	and    r11,r10
    730a04106815:	movabs rsi,0xffffffff0fffffff
    730a0410681f:	and    rbx,rsi
    730a04106822:	or     rbx,r11
    730a04106825:	pop    r11
    730a04106827:	pop    r10
    730a04106829:	pop    rsi
    730a0410682a:	pop    rdx
    730a0410682b:	mov    QWORD PTR [r12+0x108],rbx
    730a04106833:	stmxcsr DWORD PTR [r12-0x28]
    730a04106839:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410683e:	test   r10d,0x3f
    730a04106845:	je     0x730a0410686a
    730a0410684b:	mov    r11d,r10d
    730a0410684e:	shr    r10d,1
    730a04106851:	and    r10d,0x1e
    730a04106855:	and    r11d,0x1
    730a04106859:	or     r10d,r11d
    730a0410685c:	or     DWORD PTR [r12+0x314],r10d
    730a04106864:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410686a:	ldmxcsr DWORD PTR [r12-0x38]
    730a04106870:	lea    rdi,[rsp+0x110]
    730a04106878:	lea    rsi,[rsp+0xf0]
    730a04106880:	lea    rdx,[rsp+0x100]
    730a04106888:	mov    ecx,0x14
    730a0410688d:	mov    r8d,0x0
    730a04106893:	lea    r9,[r12+0x314]
    730a0410689b:	movabs r11,0x5591a9a93650
    730a041068a5:	call   r11
    730a041068a8:	ldmxcsr DWORD PTR [r12-0x28]
    730a041068ae:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a041068b4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a041068ba:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a041068c0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a041068c6:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a041068d0:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a041068da:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a041068e4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a041068ee:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a041068f8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a04106902:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410690a:	mov    QWORD PTR [r12+0x378],0x2
    730a04106916:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410691f:	mov    rdx,rbx
    730a04106922:	shr    rdx,0x10
    730a04106926:	and    edx,0xc000
    730a0410692c:	mov    rax,rbx
    730a0410692f:	shr    rax,0x15
    730a04106933:	and    eax,0x100
    730a04106938:	xor    eax,0x100
    730a0410693d:	or     edx,eax
    730a0410693f:	mov    rax,rbx
    730a04106942:	shr    rax,0x1c
    730a04106946:	and    eax,0x1
    730a04106949:	or     edx,eax
    730a0410694b:	mov    QWORD PTR [rsp+0x10],rdx
    730a04106950:	add    rsp,0x8
    730a04106954:	ret
    730a04106955:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04106960:	sub    rsp,0x8
    730a04106964:	mov    QWORD PTR [r12+0x378],0x3
    730a04106970:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04106976:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410697c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04106982:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04106988:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a0410698e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04106998:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a041069a2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a041069ac:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a041069b6:	push   rdx
    730a041069b7:	push   rsi
    730a041069b8:	push   r10
    730a041069ba:	push   r11
    730a041069bc:	mov    rdx,QWORD PTR [rsp+0x30]
    730a041069c1:	mov    r10d,edx
    730a041069c4:	and    r10d,0xc000
    730a041069cb:	shl    r10d,0x10
    730a041069cf:	mov    r11d,edx
    730a041069d2:	and    r11d,0x100
    730a041069d9:	shl    r11d,0x15
    730a041069dd:	or     r10d,r11d
    730a041069e0:	and    edx,0x1
    730a041069e3:	shl    edx,0x1c
    730a041069e6:	or     r10d,edx
    730a041069e9:	btc    r10,0x1d
    730a041069ee:	mov    r11d,0xf0000000
    730a041069f4:	and    r11,r10
    730a041069f7:	movabs rsi,0xffffffff0fffffff
    730a04106a01:	and    rbx,rsi
    730a04106a04:	or     rbx,r11
    730a04106a07:	pop    r11
    730a04106a09:	pop    r10
    730a04106a0b:	pop    rsi
    730a04106a0c:	pop    rdx
    730a04106a0d:	mov    QWORD PTR [r12+0x108],rbx
    730a04106a15:	stmxcsr DWORD PTR [r12-0x28]
    730a04106a1b:	mov    r10d,DWORD PTR [r12-0x28]
    730a04106a20:	test   r10d,0x3f
    730a04106a27:	je     0x730a04106a4c
    730a04106a2d:	mov    r11d,r10d
    730a04106a30:	shr    r10d,1
    730a04106a33:	and    r10d,0x1e
    730a04106a37:	and    r11d,0x1
    730a04106a3b:	or     r10d,r11d
    730a04106a3e:	or     DWORD PTR [r12+0x314],r10d
    730a04106a46:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04106a4c:	ldmxcsr DWORD PTR [r12-0x38]
    730a04106a52:	lea    rdi,[rsp+0x110]
    730a04106a5a:	lea    rsi,[rsp+0xf0]
    730a04106a62:	lea    rdx,[rsp+0x100]
    730a04106a6a:	mov    ecx,0x56
    730a04106a6f:	mov    r8d,0x0
    730a04106a75:	lea    r9,[r12+0x314]
    730a04106a7d:	movabs r11,0x5591a9a93650
    730a04106a87:	call   r11
    730a04106a8a:	ldmxcsr DWORD PTR [r12-0x28]
    730a04106a90:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04106a96:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04106a9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04106aa2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04106aa8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04106aae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04106ab8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04106ac2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04106acc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a04106ad6:	mov    rbx,QWORD PTR [r12+0x108]
    730a04106ade:	mov    QWORD PTR [r12+0x378],0x2
    730a04106aea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04106af3:	mov    rdx,rbx
    730a04106af6:	shr    rdx,0x10
    730a04106afa:	and    edx,0xc000
    730a04106b00:	mov    rax,rbx
    730a04106b03:	shr    rax,0x15
    730a04106b07:	and    eax,0x100
    730a04106b0c:	xor    eax,0x100
    730a04106b11:	or     edx,eax
    730a04106b13:	mov    rax,rbx
    730a04106b16:	shr    rax,0x1c
    730a04106b1a:	and    eax,0x1
    730a04106b1d:	or     edx,eax
    730a04106b1f:	mov    QWORD PTR [rsp+0x10],rdx
    730a04106b24:	add    rsp,0x8
    730a04106b28:	ret
    730a04106b29:	nop    DWORD PTR [rax+0x0]
    730a04106b30:	sub    rsp,0x8
    730a04106b34:	mov    QWORD PTR [r12+0x378],0x3
    730a04106b40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04106b46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a04106b4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04106b52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04106b58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04106b5e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04106b64:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04106b6e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04106b78:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04106b82:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a04106b8c:	push   rdx
    730a04106b8d:	push   rsi
    730a04106b8e:	push   r10
    730a04106b90:	push   r11
    730a04106b92:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04106b97:	mov    r10d,edx
    730a04106b9a:	and    r10d,0xc000
    730a04106ba1:	shl    r10d,0x10
    730a04106ba5:	mov    r11d,edx
    730a04106ba8:	and    r11d,0x100
    730a04106baf:	shl    r11d,0x15
    730a04106bb3:	or     r10d,r11d
    730a04106bb6:	and    edx,0x1
    730a04106bb9:	shl    edx,0x1c
    730a04106bbc:	or     r10d,edx
    730a04106bbf:	btc    r10,0x1d
    730a04106bc4:	mov    r11d,0xf0000000
    730a04106bca:	and    r11,r10
    730a04106bcd:	movabs rsi,0xffffffff0fffffff
    730a04106bd7:	and    rbx,rsi
    730a04106bda:	or     rbx,r11
    730a04106bdd:	pop    r11
    730a04106bdf:	pop    r10
    730a04106be1:	pop    rsi
    730a04106be2:	pop    rdx
    730a04106be3:	mov    QWORD PTR [r12+0x108],rbx
    730a04106beb:	stmxcsr DWORD PTR [r12-0x28]
    730a04106bf1:	mov    r10d,DWORD PTR [r12-0x28]
    730a04106bf6:	test   r10d,0x3f
    730a04106bfd:	je     0x730a04106c22
    730a04106c03:	mov    r11d,r10d
    730a04106c06:	shr    r10d,1
    730a04106c09:	and    r10d,0x1e
    730a04106c0d:	and    r11d,0x1
    730a04106c11:	or     r10d,r11d
    730a04106c14:	or     DWORD PTR [r12+0x314],r10d
    730a04106c1c:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04106c22:	ldmxcsr DWORD PTR [r12-0x38]
    730a04106c28:	lea    rdi,[rsp+0x110]
    730a04106c30:	lea    rsi,[rsp+0xf0]
    730a04106c38:	lea    rdx,[rsp+0x100]
    730a04106c40:	mov    ecx,0x56
    730a04106c45:	mov    r8d,0x0
    730a04106c4b:	lea    r9,[r12+0x314]
    730a04106c53:	movabs r11,0x5591a9a93650
    730a04106c5d:	call   r11
    730a04106c60:	ldmxcsr DWORD PTR [r12-0x28]
    730a04106c66:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04106c6c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04106c72:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04106c78:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04106c7e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04106c84:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04106c8a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04106c94:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04106c9e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04106ca8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a04106cb2:	mov    rbx,QWORD PTR [r12+0x108]
    730a04106cba:	mov    QWORD PTR [r12+0x378],0x2
    730a04106cc6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04106ccf:	mov    rdx,rbx
    730a04106cd2:	shr    rdx,0x10
    730a04106cd6:	and    edx,0xc000
    730a04106cdc:	mov    rax,rbx
    730a04106cdf:	shr    rax,0x15
    730a04106ce3:	and    eax,0x100
    730a04106ce8:	xor    eax,0x100
    730a04106ced:	or     edx,eax
    730a04106cef:	mov    rax,rbx
    730a04106cf2:	shr    rax,0x1c
    730a04106cf6:	and    eax,0x1
    730a04106cf9:	or     edx,eax
    730a04106cfb:	mov    QWORD PTR [rsp+0x10],rdx
    730a04106d00:	add    rsp,0x8
    730a04106d04:	ret
    730a04106d05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04106d10:	sub    rsp,0x8
    730a04106d14:	mov    QWORD PTR [r12+0x378],0x3
    730a04106d20:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04106d26:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a04106d2c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04106d32:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04106d38:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04106d3e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04106d44:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a04106d4e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04106d58:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04106d62:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04106d6c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a04106d76:	push   rdx
    730a04106d77:	push   rsi
    730a04106d78:	push   r10
    730a04106d7a:	push   r11
    730a04106d7c:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04106d81:	mov    r10d,edx
    730a04106d84:	and    r10d,0xc000
    730a04106d8b:	shl    r10d,0x10
    730a04106d8f:	mov    r11d,edx
    730a04106d92:	and    r11d,0x100
    730a04106d99:	shl    r11d,0x15
    730a04106d9d:	or     r10d,r11d
    730a04106da0:	and    edx,0x1
    730a04106da3:	shl    edx,0x1c
    730a04106da6:	or     r10d,edx
    730a04106da9:	btc    r10,0x1d
    730a04106dae:	mov    r11d,0xf0000000
    730a04106db4:	and    r11,r10
    730a04106db7:	movabs rsi,0xffffffff0fffffff
    730a04106dc1:	and    rbx,rsi
    730a04106dc4:	or     rbx,r11
    730a04106dc7:	pop    r11
    730a04106dc9:	pop    r10
    730a04106dcb:	pop    rsi
    730a04106dcc:	pop    rdx
    730a04106dcd:	mov    QWORD PTR [r12+0x108],rbx
    730a04106dd5:	stmxcsr DWORD PTR [r12-0x28]
    730a04106ddb:	mov    r10d,DWORD PTR [r12-0x28]
    730a04106de0:	test   r10d,0x3f
    730a04106de7:	je     0x730a04106e0c
    730a04106ded:	mov    r11d,r10d
    730a04106df0:	shr    r10d,1
    730a04106df3:	and    r10d,0x1e
    730a04106df7:	and    r11d,0x1
    730a04106dfb:	or     r10d,r11d
    730a04106dfe:	or     DWORD PTR [r12+0x314],r10d
    730a04106e06:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04106e0c:	ldmxcsr DWORD PTR [r12-0x38]
    730a04106e12:	lea    rdi,[rsp+0x110]
    730a04106e1a:	lea    rsi,[rsp+0xf0]
    730a04106e22:	lea    rdx,[rsp+0x100]
    730a04106e2a:	mov    ecx,0x56
    730a04106e2f:	mov    r8d,0x0
    730a04106e35:	lea    r9,[r12+0x314]
    730a04106e3d:	movabs r11,0x5591a9a93650
    730a04106e47:	call   r11
    730a04106e4a:	ldmxcsr DWORD PTR [r12-0x28]
    730a04106e50:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04106e56:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04106e5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04106e62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04106e68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04106e6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04106e74:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04106e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04106e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04106e92:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04106e9c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a04106ea6:	mov    rbx,QWORD PTR [r12+0x108]
    730a04106eae:	mov    QWORD PTR [r12+0x378],0x2
    730a04106eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04106ec3:	mov    rdx,rbx
    730a04106ec6:	shr    rdx,0x10
    730a04106eca:	and    edx,0xc000
    730a04106ed0:	mov    rax,rbx
    730a04106ed3:	shr    rax,0x15
    730a04106ed7:	and    eax,0x100
    730a04106edc:	xor    eax,0x100
    730a04106ee1:	or     edx,eax
    730a04106ee3:	mov    rax,rbx
    730a04106ee6:	shr    rax,0x1c
    730a04106eea:	and    eax,0x1
    730a04106eed:	or     edx,eax
    730a04106eef:	mov    QWORD PTR [rsp+0x10],rdx
    730a04106ef4:	add    rsp,0x8
    730a04106ef8:	ret
    730a04106ef9:	nop    DWORD PTR [rax+0x0]
    730a04106f00:	sub    rsp,0x8
    730a04106f04:	mov    QWORD PTR [r12+0x378],0x3
    730a04106f10:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04106f16:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04106f1c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04106f22:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04106f28:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a04106f32:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04106f3c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04106f46:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04106f50:	push   rdx
    730a04106f51:	push   rsi
    730a04106f52:	push   r10
    730a04106f54:	push   r11
    730a04106f56:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04106f5b:	mov    r10d,edx
    730a04106f5e:	and    r10d,0xc000
    730a04106f65:	shl    r10d,0x10
    730a04106f69:	mov    r11d,edx
    730a04106f6c:	and    r11d,0x100
    730a04106f73:	shl    r11d,0x15
    730a04106f77:	or     r10d,r11d
    730a04106f7a:	and    edx,0x1
    730a04106f7d:	shl    edx,0x1c
    730a04106f80:	or     r10d,edx
    730a04106f83:	btc    r10,0x1d
    730a04106f88:	mov    r11d,0xf0000000
    730a04106f8e:	and    r11,r10
    730a04106f91:	movabs rsi,0xffffffff0fffffff
    730a04106f9b:	and    rbx,rsi
    730a04106f9e:	or     rbx,r11
    730a04106fa1:	pop    r11
    730a04106fa3:	pop    r10
    730a04106fa5:	pop    rsi
    730a04106fa6:	pop    rdx
    730a04106fa7:	mov    QWORD PTR [r12+0x108],rbx
    730a04106faf:	stmxcsr DWORD PTR [r12-0x28]
    730a04106fb5:	mov    r10d,DWORD PTR [r12-0x28]
    730a04106fba:	test   r10d,0x3f
    730a04106fc1:	je     0x730a04106fe6
    730a04106fc7:	mov    r11d,r10d
    730a04106fca:	shr    r10d,1
    730a04106fcd:	and    r10d,0x1e
    730a04106fd1:	and    r11d,0x1
    730a04106fd5:	or     r10d,r11d
    730a04106fd8:	or     DWORD PTR [r12+0x314],r10d
    730a04106fe0:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04106fe6:	ldmxcsr DWORD PTR [r12-0x38]
    730a04106fec:	lea    rdi,[rsp+0x110]
    730a04106ff4:	lea    rsi,[rsp+0xf0]
    730a04106ffc:	lea    rdx,[rsp+0x100]
    730a04107004:	mov    ecx,0x56
    730a04107009:	mov    r8d,0x0
    730a0410700f:	lea    r9,[r12+0x314]
    730a04107017:	movabs r11,0x5591a9a93650
    730a04107021:	call   r11
    730a04107024:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410702a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04107030:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04107036:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410703c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04107042:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a0410704c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04107056:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04107060:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410706a:	mov    rbx,QWORD PTR [r12+0x108]
    730a04107072:	mov    QWORD PTR [r12+0x378],0x2
    730a0410707e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04107087:	mov    rdx,rbx
    730a0410708a:	shr    rdx,0x10
    730a0410708e:	and    edx,0xc000
    730a04107094:	mov    rax,rbx
    730a04107097:	shr    rax,0x15
    730a0410709b:	and    eax,0x100
    730a041070a0:	xor    eax,0x100
    730a041070a5:	or     edx,eax
    730a041070a7:	mov    rax,rbx
    730a041070aa:	shr    rax,0x1c
    730a041070ae:	and    eax,0x1
    730a041070b1:	or     edx,eax
    730a041070b3:	mov    QWORD PTR [rsp+0x10],rdx
    730a041070b8:	add    rsp,0x8
    730a041070bc:	ret
    730a041070bd:	nop    DWORD PTR [rax]
    730a041070c0:	sub    rsp,0x8
    730a041070c4:	mov    QWORD PTR [r12+0x378],0x3
    730a041070d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a041070d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041070dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a041070e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a041070e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041070ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a041070f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04107102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a0410710c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04107116:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a04107120:	push   rdx
    730a04107121:	push   rsi
    730a04107122:	push   r10
    730a04107124:	push   r11
    730a04107126:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410712b:	mov    r10d,edx
    730a0410712e:	and    r10d,0xc000
    730a04107135:	shl    r10d,0x10
    730a04107139:	mov    r11d,edx
    730a0410713c:	and    r11d,0x100
    730a04107143:	shl    r11d,0x15
    730a04107147:	or     r10d,r11d
    730a0410714a:	and    edx,0x1
    730a0410714d:	shl    edx,0x1c
    730a04107150:	or     r10d,edx
    730a04107153:	btc    r10,0x1d
    730a04107158:	mov    r11d,0xf0000000
    730a0410715e:	and    r11,r10
    730a04107161:	movabs rsi,0xffffffff0fffffff
    730a0410716b:	and    rbx,rsi
    730a0410716e:	or     rbx,r11
    730a04107171:	pop    r11
    730a04107173:	pop    r10
    730a04107175:	pop    rsi
    730a04107176:	pop    rdx
    730a04107177:	mov    QWORD PTR [r12+0x108],rbx
    730a0410717f:	stmxcsr DWORD PTR [r12-0x28]
    730a04107185:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410718a:	test   r10d,0x3f
    730a04107191:	je     0x730a041071b6
    730a04107197:	mov    r11d,r10d
    730a0410719a:	shr    r10d,1
    730a0410719d:	and    r10d,0x1e
    730a041071a1:	and    r11d,0x1
    730a041071a5:	or     r10d,r11d
    730a041071a8:	or     DWORD PTR [r12+0x314],r10d
    730a041071b0:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a041071b6:	ldmxcsr DWORD PTR [r12-0x38]
    730a041071bc:	lea    rdi,[rsp+0x110]
    730a041071c4:	lea    rsi,[rsp+0xf0]
    730a041071cc:	lea    rdx,[rsp+0x100]
    730a041071d4:	mov    ecx,0x14
    730a041071d9:	mov    r8d,0x0
    730a041071df:	lea    r9,[r12+0x314]
    730a041071e7:	movabs r11,0x5591a9a93650
    730a041071f1:	call   r11
    730a041071f4:	ldmxcsr DWORD PTR [r12-0x28]
    730a041071fa:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04107200:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04107206:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410720c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04107212:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04107218:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04107222:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410722c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04107236:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04107240:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a0410724a:	mov    rbx,QWORD PTR [r12+0x108]
    730a04107252:	mov    QWORD PTR [r12+0x378],0x2
    730a0410725e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04107267:	mov    rdx,rbx
    730a0410726a:	shr    rdx,0x10
    730a0410726e:	and    edx,0xc000
    730a04107274:	mov    rax,rbx
    730a04107277:	shr    rax,0x15
    730a0410727b:	and    eax,0x100
    730a04107280:	xor    eax,0x100
    730a04107285:	or     edx,eax
    730a04107287:	mov    rax,rbx
    730a0410728a:	shr    rax,0x1c
    730a0410728e:	and    eax,0x1
    730a04107291:	or     edx,eax
    730a04107293:	mov    QWORD PTR [rsp+0x10],rdx
    730a04107298:	add    rsp,0x8
    730a0410729c:	ret
    730a0410729d:	nop    DWORD PTR [rax]
    730a041072a0:	sub    rsp,0x8
    730a041072a4:	mov    QWORD PTR [r12+0x378],0x3
    730a041072b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a041072b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a041072bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041072c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a041072c8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041072ce:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a041072d8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a041072e2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a041072ec:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a041072f6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a04107300:	push   rdx
    730a04107301:	push   rsi
    730a04107302:	push   r10
    730a04107304:	push   r11
    730a04107306:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410730b:	mov    r10d,edx
    730a0410730e:	and    r10d,0xc000
    730a04107315:	shl    r10d,0x10
    730a04107319:	mov    r11d,edx
    730a0410731c:	and    r11d,0x100
    730a04107323:	shl    r11d,0x15
    730a04107327:	or     r10d,r11d
    730a0410732a:	and    edx,0x1
    730a0410732d:	shl    edx,0x1c
    730a04107330:	or     r10d,edx
    730a04107333:	btc    r10,0x1d
    730a04107338:	mov    r11d,0xf0000000
    730a0410733e:	and    r11,r10
    730a04107341:	movabs rsi,0xffffffff0fffffff
    730a0410734b:	and    rbx,rsi
    730a0410734e:	or     rbx,r11
    730a04107351:	pop    r11
    730a04107353:	pop    r10
    730a04107355:	pop    rsi
    730a04107356:	pop    rdx
    730a04107357:	mov    QWORD PTR [r12+0x108],rbx
    730a0410735f:	stmxcsr DWORD PTR [r12-0x28]
    730a04107365:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410736a:	test   r10d,0x3f
    730a04107371:	je     0x730a04107396
    730a04107377:	mov    r11d,r10d
    730a0410737a:	shr    r10d,1
    730a0410737d:	and    r10d,0x1e
    730a04107381:	and    r11d,0x1
    730a04107385:	or     r10d,r11d
    730a04107388:	or     DWORD PTR [r12+0x314],r10d
    730a04107390:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04107396:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410739c:	lea    rdi,[rsp+0x110]
    730a041073a4:	lea    rsi,[rsp+0xf0]
    730a041073ac:	lea    rdx,[rsp+0x100]
    730a041073b4:	mov    ecx,0x56
    730a041073b9:	mov    r8d,0x0
    730a041073bf:	lea    r9,[r12+0x314]
    730a041073c7:	movabs r11,0x5591a9a93650
    730a041073d1:	call   r11
    730a041073d4:	ldmxcsr DWORD PTR [r12-0x28]
    730a041073da:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a041073e0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a041073e6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a041073ec:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a041073f2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a041073f8:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04107402:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410740c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04107416:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04107420:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a0410742a:	mov    rbx,QWORD PTR [r12+0x108]
    730a04107432:	mov    QWORD PTR [r12+0x378],0x2
    730a0410743e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04107447:	mov    rdx,rbx
    730a0410744a:	shr    rdx,0x10
    730a0410744e:	and    edx,0xc000
    730a04107454:	mov    rax,rbx
    730a04107457:	shr    rax,0x15
    730a0410745b:	and    eax,0x100
    730a04107460:	xor    eax,0x100
    730a04107465:	or     edx,eax
    730a04107467:	mov    rax,rbx
    730a0410746a:	shr    rax,0x1c
    730a0410746e:	and    eax,0x1
    730a04107471:	or     edx,eax
    730a04107473:	mov    QWORD PTR [rsp+0x10],rdx
    730a04107478:	add    rsp,0x8
    730a0410747c:	ret
    730a0410747d:	nop    DWORD PTR [rax]
    730a04107480:	sub    rsp,0x8
    730a04107484:	mov    QWORD PTR [r12+0x378],0x3
    730a04107490:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04107496:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410749c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041074a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a041074a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a041074ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041074b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a041074be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a041074c8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a041074d2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a041074dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a041074e6:	push   rdx
    730a041074e7:	push   rsi
    730a041074e8:	push   r10
    730a041074ea:	push   r11
    730a041074ec:	mov    rdx,QWORD PTR [rsp+0x30]
    730a041074f1:	mov    r10d,edx
    730a041074f4:	and    r10d,0xc000
    730a041074fb:	shl    r10d,0x10
    730a041074ff:	mov    r11d,edx
    730a04107502:	and    r11d,0x100
    730a04107509:	shl    r11d,0x15
    730a0410750d:	or     r10d,r11d
    730a04107510:	and    edx,0x1
    730a04107513:	shl    edx,0x1c
    730a04107516:	or     r10d,edx
    730a04107519:	btc    r10,0x1d
    730a0410751e:	mov    r11d,0xf0000000
    730a04107524:	and    r11,r10
    730a04107527:	movabs rsi,0xffffffff0fffffff
    730a04107531:	and    rbx,rsi
    730a04107534:	or     rbx,r11
    730a04107537:	pop    r11
    730a04107539:	pop    r10
    730a0410753b:	pop    rsi
    730a0410753c:	pop    rdx
    730a0410753d:	mov    QWORD PTR [r12+0x108],rbx
    730a04107545:	stmxcsr DWORD PTR [r12-0x28]
    730a0410754b:	mov    r10d,DWORD PTR [r12-0x28]
    730a04107550:	test   r10d,0x3f
    730a04107557:	je     0x730a0410757c
    730a0410755d:	mov    r11d,r10d
    730a04107560:	shr    r10d,1
    730a04107563:	and    r10d,0x1e
    730a04107567:	and    r11d,0x1
    730a0410756b:	or     r10d,r11d
    730a0410756e:	or     DWORD PTR [r12+0x314],r10d
    730a04107576:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410757c:	ldmxcsr DWORD PTR [r12-0x38]
    730a04107582:	lea    rdi,[rsp+0x110]
    730a0410758a:	lea    rsi,[rsp+0xf0]
    730a04107592:	lea    rdx,[rsp+0x100]
    730a0410759a:	mov    ecx,0x14
    730a0410759f:	mov    r8d,0x0
    730a041075a5:	lea    r9,[r12+0x314]
    730a041075ad:	movabs r11,0x5591a9a93650
    730a041075b7:	call   r11
    730a041075ba:	ldmxcsr DWORD PTR [r12-0x28]
    730a041075c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a041075c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a041075cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a041075d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a041075d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a041075de:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a041075e4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a041075ee:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a041075f8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04107602:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410760c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a04107616:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410761e:	mov    QWORD PTR [r12+0x378],0x2
    730a0410762a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04107633:	mov    rdx,rbx
    730a04107636:	shr    rdx,0x10
    730a0410763a:	and    edx,0xc000
    730a04107640:	mov    rax,rbx
    730a04107643:	shr    rax,0x15
    730a04107647:	and    eax,0x100
    730a0410764c:	xor    eax,0x100
    730a04107651:	or     edx,eax
    730a04107653:	mov    rax,rbx
    730a04107656:	shr    rax,0x1c
    730a0410765a:	and    eax,0x1
    730a0410765d:	or     edx,eax
    730a0410765f:	mov    QWORD PTR [rsp+0x10],rdx
    730a04107664:	add    rsp,0x8
    730a04107668:	ret
    730a04107669:	nop    DWORD PTR [rax+0x0]
    730a04107670:	sub    rsp,0x8
    730a04107674:	mov    QWORD PTR [r12+0x378],0x3
    730a04107680:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04107686:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410768c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04107692:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04107698:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410769e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041076a4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a041076ae:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a041076b8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a041076c2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a041076cc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a041076d6:	push   rdx
    730a041076d7:	push   rsi
    730a041076d8:	push   r10
    730a041076da:	push   r11
    730a041076dc:	mov    rdx,QWORD PTR [rsp+0x30]
    730a041076e1:	mov    r10d,edx
    730a041076e4:	and    r10d,0xc000
    730a041076eb:	shl    r10d,0x10
    730a041076ef:	mov    r11d,edx
    730a041076f2:	and    r11d,0x100
    730a041076f9:	shl    r11d,0x15
    730a041076fd:	or     r10d,r11d
    730a04107700:	and    edx,0x1
    730a04107703:	shl    edx,0x1c
    730a04107706:	or     r10d,edx
    730a04107709:	btc    r10,0x1d
    730a0410770e:	mov    r11d,0xf0000000
    730a04107714:	and    r11,r10
    730a04107717:	movabs rsi,0xffffffff0fffffff
    730a04107721:	and    rbx,rsi
    730a04107724:	or     rbx,r11
    730a04107727:	pop    r11
    730a04107729:	pop    r10
    730a0410772b:	pop    rsi
    730a0410772c:	pop    rdx
    730a0410772d:	mov    QWORD PTR [r12+0x108],rbx
    730a04107735:	stmxcsr DWORD PTR [r12-0x28]
    730a0410773b:	mov    r10d,DWORD PTR [r12-0x28]
    730a04107740:	test   r10d,0x3f
    730a04107747:	je     0x730a0410776c
    730a0410774d:	mov    r11d,r10d
    730a04107750:	shr    r10d,1
    730a04107753:	and    r10d,0x1e
    730a04107757:	and    r11d,0x1
    730a0410775b:	or     r10d,r11d
    730a0410775e:	or     DWORD PTR [r12+0x314],r10d
    730a04107766:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410776c:	ldmxcsr DWORD PTR [r12-0x38]
    730a04107772:	lea    rdi,[rsp+0x110]
    730a0410777a:	lea    rsi,[rsp+0xf0]
    730a04107782:	lea    rdx,[rsp+0x100]
    730a0410778a:	mov    ecx,0x14
    730a0410778f:	mov    r8d,0x0
    730a04107795:	lea    r9,[r12+0x314]
    730a0410779d:	movabs r11,0x5591a9a93650
    730a041077a7:	call   r11
    730a041077aa:	ldmxcsr DWORD PTR [r12-0x28]
    730a041077b0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a041077b6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a041077bc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a041077c2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a041077c8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a041077ce:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a041077d4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a041077de:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a041077e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a041077f2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a041077fc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a04107806:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410780e:	mov    QWORD PTR [r12+0x378],0x2
    730a0410781a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04107823:	mov    rdx,rbx
    730a04107826:	shr    rdx,0x10
    730a0410782a:	and    edx,0xc000
    730a04107830:	mov    rax,rbx
    730a04107833:	shr    rax,0x15
    730a04107837:	and    eax,0x100
    730a0410783c:	xor    eax,0x100
    730a04107841:	or     edx,eax
    730a04107843:	mov    rax,rbx
    730a04107846:	shr    rax,0x1c
    730a0410784a:	and    eax,0x1
    730a0410784d:	or     edx,eax
    730a0410784f:	mov    QWORD PTR [rsp+0x10],rdx
    730a04107854:	add    rsp,0x8
    730a04107858:	ret
    730a04107859:	nop    DWORD PTR [rax+0x0]
    730a04107860:	sub    rsp,0x8
    730a04107864:	mov    QWORD PTR [r12+0x378],0x3
    730a04107870:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04107876:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410787c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04107882:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04107888:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410788e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04107894:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a0410789e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a041078a8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a041078b2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a041078bc:	push   rdx
    730a041078bd:	push   rsi
    730a041078be:	push   r10
    730a041078c0:	push   r11
    730a041078c2:	mov    rdx,QWORD PTR [rsp+0x30]
    730a041078c7:	mov    r10d,edx
    730a041078ca:	and    r10d,0xc000
    730a041078d1:	shl    r10d,0x10
    730a041078d5:	mov    r11d,edx
    730a041078d8:	and    r11d,0x100
    730a041078df:	shl    r11d,0x15
    730a041078e3:	or     r10d,r11d
    730a041078e6:	and    edx,0x1
    730a041078e9:	shl    edx,0x1c
    730a041078ec:	or     r10d,edx
    730a041078ef:	btc    r10,0x1d
    730a041078f4:	mov    r11d,0xf0000000
    730a041078fa:	and    r11,r10
    730a041078fd:	movabs rsi,0xffffffff0fffffff
    730a04107907:	and    rbx,rsi
    730a0410790a:	or     rbx,r11
    730a0410790d:	pop    r11
    730a0410790f:	pop    r10
    730a04107911:	pop    rsi
    730a04107912:	pop    rdx
    730a04107913:	mov    QWORD PTR [r12+0x108],rbx
    730a0410791b:	stmxcsr DWORD PTR [r12-0x28]
    730a04107921:	mov    r10d,DWORD PTR [r12-0x28]
    730a04107926:	test   r10d,0x3f
    730a0410792d:	je     0x730a04107952
    730a04107933:	mov    r11d,r10d
    730a04107936:	shr    r10d,1
    730a04107939:	and    r10d,0x1e
    730a0410793d:	and    r11d,0x1
    730a04107941:	or     r10d,r11d
    730a04107944:	or     DWORD PTR [r12+0x314],r10d
    730a0410794c:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04107952:	ldmxcsr DWORD PTR [r12-0x38]
    730a04107958:	lea    rdi,[rsp+0x110]
    730a04107960:	lea    rsi,[rsp+0xf0]
    730a04107968:	lea    rdx,[rsp+0x100]
    730a04107970:	mov    ecx,0x56
    730a04107975:	mov    r8d,0x0
    730a0410797b:	lea    r9,[r12+0x314]
    730a04107983:	movabs r11,0x5591a9a93650
    730a0410798d:	call   r11
    730a04107990:	ldmxcsr DWORD PTR [r12-0x28]
    730a04107996:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410799c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a041079a2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a041079a8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a041079ae:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a041079b4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a041079ba:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a041079c4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a041079ce:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a041079d8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a041079e2:	mov    rbx,QWORD PTR [r12+0x108]
    730a041079ea:	mov    QWORD PTR [r12+0x378],0x2
    730a041079f6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a041079ff:	mov    rdx,rbx
    730a04107a02:	shr    rdx,0x10
    730a04107a06:	and    edx,0xc000
    730a04107a0c:	mov    rax,rbx
    730a04107a0f:	shr    rax,0x15
    730a04107a13:	and    eax,0x100
    730a04107a18:	xor    eax,0x100
    730a04107a1d:	or     edx,eax
    730a04107a1f:	mov    rax,rbx
    730a04107a22:	shr    rax,0x1c
    730a04107a26:	and    eax,0x1
    730a04107a29:	or     edx,eax
    730a04107a2b:	mov    QWORD PTR [rsp+0x10],rdx
    730a04107a30:	add    rsp,0x8
    730a04107a34:	ret
    730a04107a35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04107a40:	sub    rsp,0x8
    730a04107a44:	mov    QWORD PTR [r12+0x378],0x3
    730a04107a50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04107a56:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a04107a5c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04107a62:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04107a68:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04107a6e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04107a74:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04107a7e:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04107a88:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04107a92:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a04107a9c:	push   rdx
    730a04107a9d:	push   rsi
    730a04107a9e:	push   r10
    730a04107aa0:	push   r11
    730a04107aa2:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04107aa7:	mov    r10d,edx
    730a04107aaa:	and    r10d,0xc000
    730a04107ab1:	shl    r10d,0x10
    730a04107ab5:	mov    r11d,edx
    730a04107ab8:	and    r11d,0x100
    730a04107abf:	shl    r11d,0x15
    730a04107ac3:	or     r10d,r11d
    730a04107ac6:	and    edx,0x1
    730a04107ac9:	shl    edx,0x1c
    730a04107acc:	or     r10d,edx
    730a04107acf:	btc    r10,0x1d
    730a04107ad4:	mov    r11d,0xf0000000
    730a04107ada:	and    r11,r10
    730a04107add:	movabs rsi,0xffffffff0fffffff
    730a04107ae7:	and    rbx,rsi
    730a04107aea:	or     rbx,r11
    730a04107aed:	pop    r11
    730a04107aef:	pop    r10
    730a04107af1:	pop    rsi
    730a04107af2:	pop    rdx
    730a04107af3:	mov    QWORD PTR [r12+0x108],rbx
    730a04107afb:	stmxcsr DWORD PTR [r12-0x28]
    730a04107b01:	mov    r10d,DWORD PTR [r12-0x28]
    730a04107b06:	test   r10d,0x3f
    730a04107b0d:	je     0x730a04107b32
    730a04107b13:	mov    r11d,r10d
    730a04107b16:	shr    r10d,1
    730a04107b19:	and    r10d,0x1e
    730a04107b1d:	and    r11d,0x1
    730a04107b21:	or     r10d,r11d
    730a04107b24:	or     DWORD PTR [r12+0x314],r10d
    730a04107b2c:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04107b32:	ldmxcsr DWORD PTR [r12-0x38]
    730a04107b38:	lea    rdi,[rsp+0x110]
    730a04107b40:	lea    rsi,[rsp+0xf0]
    730a04107b48:	lea    rdx,[rsp+0x100]
    730a04107b50:	mov    ecx,0x14
    730a04107b55:	mov    r8d,0x0
    730a04107b5b:	lea    r9,[r12+0x314]
    730a04107b63:	movabs r11,0x5591a9a93650
    730a04107b6d:	call   r11
    730a04107b70:	ldmxcsr DWORD PTR [r12-0x28]
    730a04107b76:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04107b7c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04107b82:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04107b88:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04107b8e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04107b94:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04107b9a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04107ba4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04107bae:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04107bb8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a04107bc2:	mov    rbx,QWORD PTR [r12+0x108]
    730a04107bca:	mov    QWORD PTR [r12+0x378],0x2
    730a04107bd6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04107bdf:	mov    rdx,rbx
    730a04107be2:	shr    rdx,0x10
    730a04107be6:	and    edx,0xc000
    730a04107bec:	mov    rax,rbx
    730a04107bef:	shr    rax,0x15
    730a04107bf3:	and    eax,0x100
    730a04107bf8:	xor    eax,0x100
    730a04107bfd:	or     edx,eax
    730a04107bff:	mov    rax,rbx
    730a04107c02:	shr    rax,0x1c
    730a04107c06:	and    eax,0x1
    730a04107c09:	or     edx,eax
    730a04107c0b:	mov    QWORD PTR [rsp+0x10],rdx
    730a04107c10:	add    rsp,0x8
    730a04107c14:	ret
    730a04107c15:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04107c20:	sub    rsp,0x8
    730a04107c24:	mov    QWORD PTR [r12+0x378],0x3
    730a04107c30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04107c36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a04107c3c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04107c42:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04107c48:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04107c4e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04107c58:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04107c62:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04107c6c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04107c76:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a04107c80:	push   rdx
    730a04107c81:	push   rsi
    730a04107c82:	push   r10
    730a04107c84:	push   r11
    730a04107c86:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04107c8b:	mov    r10d,edx
    730a04107c8e:	and    r10d,0xc000
    730a04107c95:	shl    r10d,0x10
    730a04107c99:	mov    r11d,edx
    730a04107c9c:	and    r11d,0x100
    730a04107ca3:	shl    r11d,0x15
    730a04107ca7:	or     r10d,r11d
    730a04107caa:	and    edx,0x1
    730a04107cad:	shl    edx,0x1c
    730a04107cb0:	or     r10d,edx
    730a04107cb3:	btc    r10,0x1d
    730a04107cb8:	mov    r11d,0xf0000000
    730a04107cbe:	and    r11,r10
    730a04107cc1:	movabs rsi,0xffffffff0fffffff
    730a04107ccb:	and    rbx,rsi
    730a04107cce:	or     rbx,r11
    730a04107cd1:	pop    r11
    730a04107cd3:	pop    r10
    730a04107cd5:	pop    rsi
    730a04107cd6:	pop    rdx
    730a04107cd7:	mov    QWORD PTR [r12+0x108],rbx
    730a04107cdf:	stmxcsr DWORD PTR [r12-0x28]
    730a04107ce5:	mov    r10d,DWORD PTR [r12-0x28]
    730a04107cea:	test   r10d,0x3f
    730a04107cf1:	je     0x730a04107d16
    730a04107cf7:	mov    r11d,r10d
    730a04107cfa:	shr    r10d,1
    730a04107cfd:	and    r10d,0x1e
    730a04107d01:	and    r11d,0x1
    730a04107d05:	or     r10d,r11d
    730a04107d08:	or     DWORD PTR [r12+0x314],r10d
    730a04107d10:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04107d16:	ldmxcsr DWORD PTR [r12-0x38]
    730a04107d1c:	lea    rdi,[rsp+0x110]
    730a04107d24:	lea    rsi,[rsp+0xf0]
    730a04107d2c:	lea    rdx,[rsp+0x100]
    730a04107d34:	mov    ecx,0x56
    730a04107d39:	mov    r8d,0x0
    730a04107d3f:	lea    r9,[r12+0x314]
    730a04107d47:	movabs r11,0x5591a9a93650
    730a04107d51:	call   r11
    730a04107d54:	ldmxcsr DWORD PTR [r12-0x28]
    730a04107d5a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04107d60:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04107d66:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04107d6c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04107d72:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04107d78:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04107d82:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04107d8c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04107d96:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04107da0:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a04107daa:	mov    rbx,QWORD PTR [r12+0x108]
    730a04107db2:	mov    QWORD PTR [r12+0x378],0x2
    730a04107dbe:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04107dc7:	mov    rdx,rbx
    730a04107dca:	shr    rdx,0x10
    730a04107dce:	and    edx,0xc000
    730a04107dd4:	mov    rax,rbx
    730a04107dd7:	shr    rax,0x15
    730a04107ddb:	and    eax,0x100
    730a04107de0:	xor    eax,0x100
    730a04107de5:	or     edx,eax
    730a04107de7:	mov    rax,rbx
    730a04107dea:	shr    rax,0x1c
    730a04107dee:	and    eax,0x1
    730a04107df1:	or     edx,eax
    730a04107df3:	mov    QWORD PTR [rsp+0x10],rdx
    730a04107df8:	add    rsp,0x8
    730a04107dfc:	ret
    730a04107dfd:	nop    DWORD PTR [rax]
    730a04107e00:	sub    rsp,0x8
    730a04107e04:	mov    QWORD PTR [r12+0x378],0x3
    730a04107e10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04107e16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a04107e1c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04107e22:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04107e28:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04107e2e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04107e34:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04107e3e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04107e48:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04107e52:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04107e5c:	push   rdx
    730a04107e5d:	push   rsi
    730a04107e5e:	push   r10
    730a04107e60:	push   r11
    730a04107e62:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04107e67:	mov    r10d,edx
    730a04107e6a:	and    r10d,0xc000
    730a04107e71:	shl    r10d,0x10
    730a04107e75:	mov    r11d,edx
    730a04107e78:	and    r11d,0x100
    730a04107e7f:	shl    r11d,0x15
    730a04107e83:	or     r10d,r11d
    730a04107e86:	and    edx,0x1
    730a04107e89:	shl    edx,0x1c
    730a04107e8c:	or     r10d,edx
    730a04107e8f:	btc    r10,0x1d
    730a04107e94:	mov    r11d,0xf0000000
    730a04107e9a:	and    r11,r10
    730a04107e9d:	movabs rsi,0xffffffff0fffffff
    730a04107ea7:	and    rbx,rsi
    730a04107eaa:	or     rbx,r11
    730a04107ead:	pop    r11
    730a04107eaf:	pop    r10
    730a04107eb1:	pop    rsi
    730a04107eb2:	pop    rdx
    730a04107eb3:	mov    QWORD PTR [r12+0x108],rbx
    730a04107ebb:	stmxcsr DWORD PTR [r12-0x28]
    730a04107ec1:	mov    r10d,DWORD PTR [r12-0x28]
    730a04107ec6:	test   r10d,0x3f
    730a04107ecd:	je     0x730a04107ef2
    730a04107ed3:	mov    r11d,r10d
    730a04107ed6:	shr    r10d,1
    730a04107ed9:	and    r10d,0x1e
    730a04107edd:	and    r11d,0x1
    730a04107ee1:	or     r10d,r11d
    730a04107ee4:	or     DWORD PTR [r12+0x314],r10d
    730a04107eec:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04107ef2:	ldmxcsr DWORD PTR [r12-0x38]
    730a04107ef8:	lea    rdi,[rsp+0x110]
    730a04107f00:	lea    rsi,[rsp+0xf0]
    730a04107f08:	lea    rdx,[rsp+0x100]
    730a04107f10:	mov    ecx,0x56
    730a04107f15:	mov    r8d,0x0
    730a04107f1b:	lea    r9,[r12+0x314]
    730a04107f23:	movabs r11,0x5591a9a93650
    730a04107f2d:	call   r11
    730a04107f30:	ldmxcsr DWORD PTR [r12-0x28]
    730a04107f36:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04107f3c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04107f42:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04107f48:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04107f4e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04107f54:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04107f5a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04107f64:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04107f6e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04107f78:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04107f82:	mov    rbx,QWORD PTR [r12+0x108]
    730a04107f8a:	mov    QWORD PTR [r12+0x378],0x2
    730a04107f96:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04107f9f:	mov    rdx,rbx
    730a04107fa2:	shr    rdx,0x10
    730a04107fa6:	and    edx,0xc000
    730a04107fac:	mov    rax,rbx
    730a04107faf:	shr    rax,0x15
    730a04107fb3:	and    eax,0x100
    730a04107fb8:	xor    eax,0x100
    730a04107fbd:	or     edx,eax
    730a04107fbf:	mov    rax,rbx
    730a04107fc2:	shr    rax,0x1c
    730a04107fc6:	and    eax,0x1
    730a04107fc9:	or     edx,eax
    730a04107fcb:	mov    QWORD PTR [rsp+0x10],rdx
    730a04107fd0:	add    rsp,0x8
    730a04107fd4:	ret
    730a04107fd5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04107fe0:	sub    rsp,0x8
    730a04107fe4:	mov    QWORD PTR [r12+0x378],0x3
    730a04107ff0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04107ff6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a04107ffc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04108002:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04108008:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410800e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04108014:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a0410801e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04108028:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04108032:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a0410803c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a04108046:	push   rdx
    730a04108047:	push   rsi
    730a04108048:	push   r10
    730a0410804a:	push   r11
    730a0410804c:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04108051:	mov    r10d,edx
    730a04108054:	and    r10d,0xc000
    730a0410805b:	shl    r10d,0x10
    730a0410805f:	mov    r11d,edx
    730a04108062:	and    r11d,0x100
    730a04108069:	shl    r11d,0x15
    730a0410806d:	or     r10d,r11d
    730a04108070:	and    edx,0x1
    730a04108073:	shl    edx,0x1c
    730a04108076:	or     r10d,edx
    730a04108079:	btc    r10,0x1d
    730a0410807e:	mov    r11d,0xf0000000
    730a04108084:	and    r11,r10
    730a04108087:	movabs rsi,0xffffffff0fffffff
    730a04108091:	and    rbx,rsi
    730a04108094:	or     rbx,r11
    730a04108097:	pop    r11
    730a04108099:	pop    r10
    730a0410809b:	pop    rsi
    730a0410809c:	pop    rdx
    730a0410809d:	mov    QWORD PTR [r12+0x108],rbx
    730a041080a5:	stmxcsr DWORD PTR [r12-0x28]
    730a041080ab:	mov    r10d,DWORD PTR [r12-0x28]
    730a041080b0:	test   r10d,0x3f
    730a041080b7:	je     0x730a041080dc
    730a041080bd:	mov    r11d,r10d
    730a041080c0:	shr    r10d,1
    730a041080c3:	and    r10d,0x1e
    730a041080c7:	and    r11d,0x1
    730a041080cb:	or     r10d,r11d
    730a041080ce:	or     DWORD PTR [r12+0x314],r10d
    730a041080d6:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a041080dc:	ldmxcsr DWORD PTR [r12-0x38]
    730a041080e2:	lea    rdi,[rsp+0x110]
    730a041080ea:	lea    rsi,[rsp+0xf0]
    730a041080f2:	lea    rdx,[rsp+0x100]
    730a041080fa:	mov    ecx,0x14
    730a041080ff:	mov    r8d,0x0
    730a04108105:	lea    r9,[r12+0x314]
    730a0410810d:	movabs r11,0x5591a9a93650
    730a04108117:	call   r11
    730a0410811a:	ldmxcsr DWORD PTR [r12-0x28]
    730a04108120:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04108126:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410812c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04108132:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04108138:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410813e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04108144:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410814e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04108158:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04108162:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410816c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a04108176:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410817e:	mov    QWORD PTR [r12+0x378],0x2
    730a0410818a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04108193:	mov    rdx,rbx
    730a04108196:	shr    rdx,0x10
    730a0410819a:	and    edx,0xc000
    730a041081a0:	mov    rax,rbx
    730a041081a3:	shr    rax,0x15
    730a041081a7:	and    eax,0x100
    730a041081ac:	xor    eax,0x100
    730a041081b1:	or     edx,eax
    730a041081b3:	mov    rax,rbx
    730a041081b6:	shr    rax,0x1c
    730a041081ba:	and    eax,0x1
    730a041081bd:	or     edx,eax
    730a041081bf:	mov    QWORD PTR [rsp+0x10],rdx
    730a041081c4:	add    rsp,0x8
    730a041081c8:	ret
    730a041081c9:	nop    DWORD PTR [rax+0x0]
    730a041081d0:	sub    rsp,0x8
    730a041081d4:	mov    QWORD PTR [r12+0x378],0x3
    730a041081e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a041081e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041081ec:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a041081f2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041081f8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a04108202:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a0410820c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04108216:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04108220:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a0410822a:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a04108234:	push   rdx
    730a04108235:	push   rsi
    730a04108236:	push   r10
    730a04108238:	push   r11
    730a0410823a:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410823f:	mov    r10d,edx
    730a04108242:	and    r10d,0xc000
    730a04108249:	shl    r10d,0x10
    730a0410824d:	mov    r11d,edx
    730a04108250:	and    r11d,0x100
    730a04108257:	shl    r11d,0x15
    730a0410825b:	or     r10d,r11d
    730a0410825e:	and    edx,0x1
    730a04108261:	shl    edx,0x1c
    730a04108264:	or     r10d,edx
    730a04108267:	btc    r10,0x1d
    730a0410826c:	mov    r11d,0xf0000000
    730a04108272:	and    r11,r10
    730a04108275:	movabs rsi,0xffffffff0fffffff
    730a0410827f:	and    rbx,rsi
    730a04108282:	or     rbx,r11
    730a04108285:	pop    r11
    730a04108287:	pop    r10
    730a04108289:	pop    rsi
    730a0410828a:	pop    rdx
    730a0410828b:	mov    QWORD PTR [r12+0x108],rbx
    730a04108293:	stmxcsr DWORD PTR [r12-0x28]
    730a04108299:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410829e:	test   r10d,0x3f
    730a041082a5:	je     0x730a041082ca
    730a041082ab:	mov    r11d,r10d
    730a041082ae:	shr    r10d,1
    730a041082b1:	and    r10d,0x1e
    730a041082b5:	and    r11d,0x1
    730a041082b9:	or     r10d,r11d
    730a041082bc:	or     DWORD PTR [r12+0x314],r10d
    730a041082c4:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a041082ca:	ldmxcsr DWORD PTR [r12-0x38]
    730a041082d0:	lea    rdi,[rsp+0x110]
    730a041082d8:	lea    rsi,[rsp+0xf0]
    730a041082e0:	lea    rdx,[rsp+0x100]
    730a041082e8:	mov    ecx,0x56
    730a041082ed:	mov    r8d,0x0
    730a041082f3:	lea    r9,[r12+0x314]
    730a041082fb:	movabs r11,0x5591a9a93650
    730a04108305:	call   r11
    730a04108308:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410830e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04108314:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410831a:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04108320:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04108326:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04108330:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410833a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04108344:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a0410834e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04108358:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a04108362:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410836a:	mov    QWORD PTR [r12+0x378],0x2
    730a04108376:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410837f:	mov    rdx,rbx
    730a04108382:	shr    rdx,0x10
    730a04108386:	and    edx,0xc000
    730a0410838c:	mov    rax,rbx
    730a0410838f:	shr    rax,0x15
    730a04108393:	and    eax,0x100
    730a04108398:	xor    eax,0x100
    730a0410839d:	or     edx,eax
    730a0410839f:	mov    rax,rbx
    730a041083a2:	shr    rax,0x1c
    730a041083a6:	and    eax,0x1
    730a041083a9:	or     edx,eax
    730a041083ab:	mov    QWORD PTR [rsp+0x10],rdx
    730a041083b0:	add    rsp,0x8
    730a041083b4:	ret
    730a041083b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a041083c0:	sub    rsp,0x8
    730a041083c4:	mov    QWORD PTR [r12+0x378],0x3
    730a041083d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a041083d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041083dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a041083e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a041083e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041083ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a041083f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04108402:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410840c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04108416:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04108420:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a0410842a:	push   rdx
    730a0410842b:	push   rsi
    730a0410842c:	push   r10
    730a0410842e:	push   r11
    730a04108430:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04108435:	mov    r10d,edx
    730a04108438:	and    r10d,0xc000
    730a0410843f:	shl    r10d,0x10
    730a04108443:	mov    r11d,edx
    730a04108446:	and    r11d,0x100
    730a0410844d:	shl    r11d,0x15
    730a04108451:	or     r10d,r11d
    730a04108454:	and    edx,0x1
    730a04108457:	shl    edx,0x1c
    730a0410845a:	or     r10d,edx
    730a0410845d:	btc    r10,0x1d
    730a04108462:	mov    r11d,0xf0000000
    730a04108468:	and    r11,r10
    730a0410846b:	movabs rsi,0xffffffff0fffffff
    730a04108475:	and    rbx,rsi
    730a04108478:	or     rbx,r11
    730a0410847b:	pop    r11
    730a0410847d:	pop    r10
    730a0410847f:	pop    rsi
    730a04108480:	pop    rdx
    730a04108481:	mov    QWORD PTR [r12+0x108],rbx
    730a04108489:	stmxcsr DWORD PTR [r12-0x28]
    730a0410848f:	mov    r10d,DWORD PTR [r12-0x28]
    730a04108494:	test   r10d,0x3f
    730a0410849b:	je     0x730a041084c0
    730a041084a1:	mov    r11d,r10d
    730a041084a4:	shr    r10d,1
    730a041084a7:	and    r10d,0x1e
    730a041084ab:	and    r11d,0x1
    730a041084af:	or     r10d,r11d
    730a041084b2:	or     DWORD PTR [r12+0x314],r10d
    730a041084ba:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a041084c0:	ldmxcsr DWORD PTR [r12-0x38]
    730a041084c6:	lea    rdi,[rsp+0x110]
    730a041084ce:	lea    rsi,[rsp+0xf0]
    730a041084d6:	lea    rdx,[rsp+0x100]
    730a041084de:	mov    ecx,0x14
    730a041084e3:	mov    r8d,0x0
    730a041084e9:	lea    r9,[r12+0x314]
    730a041084f1:	movabs r11,0x5591a9a93650
    730a041084fb:	call   r11
    730a041084fe:	ldmxcsr DWORD PTR [r12-0x28]
    730a04108504:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410850a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04108510:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04108516:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410851c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04108522:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a0410852c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04108536:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04108540:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a0410854a:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04108554:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a0410855e:	mov    rbx,QWORD PTR [r12+0x108]
    730a04108566:	mov    QWORD PTR [r12+0x378],0x2
    730a04108572:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410857b:	mov    rdx,rbx
    730a0410857e:	shr    rdx,0x10
    730a04108582:	and    edx,0xc000
    730a04108588:	mov    rax,rbx
    730a0410858b:	shr    rax,0x15
    730a0410858f:	and    eax,0x100
    730a04108594:	xor    eax,0x100
    730a04108599:	or     edx,eax
    730a0410859b:	mov    rax,rbx
    730a0410859e:	shr    rax,0x1c
    730a041085a2:	and    eax,0x1
    730a041085a5:	or     edx,eax
    730a041085a7:	mov    QWORD PTR [rsp+0x10],rdx
    730a041085ac:	add    rsp,0x8
    730a041085b0:	ret
    730a041085b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a041085c0:	sub    rsp,0x8
    730a041085c4:	mov    QWORD PTR [r12+0x378],0x3
    730a041085d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a041085d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a041085dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041085e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a041085e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a041085ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041085f4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a041085fe:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04108608:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04108612:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a0410861c:	push   rdx
    730a0410861d:	push   rsi
    730a0410861e:	push   r10
    730a04108620:	push   r11
    730a04108622:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04108627:	mov    r10d,edx
    730a0410862a:	and    r10d,0xc000
    730a04108631:	shl    r10d,0x10
    730a04108635:	mov    r11d,edx
    730a04108638:	and    r11d,0x100
    730a0410863f:	shl    r11d,0x15
    730a04108643:	or     r10d,r11d
    730a04108646:	and    edx,0x1
    730a04108649:	shl    edx,0x1c
    730a0410864c:	or     r10d,edx
    730a0410864f:	btc    r10,0x1d
    730a04108654:	mov    r11d,0xf0000000
    730a0410865a:	and    r11,r10
    730a0410865d:	movabs rsi,0xffffffff0fffffff
    730a04108667:	and    rbx,rsi
    730a0410866a:	or     rbx,r11
    730a0410866d:	pop    r11
    730a0410866f:	pop    r10
    730a04108671:	pop    rsi
    730a04108672:	pop    rdx
    730a04108673:	mov    QWORD PTR [r12+0x108],rbx
    730a0410867b:	stmxcsr DWORD PTR [r12-0x28]
    730a04108681:	mov    r10d,DWORD PTR [r12-0x28]
    730a04108686:	test   r10d,0x3f
    730a0410868d:	je     0x730a041086b2
    730a04108693:	mov    r11d,r10d
    730a04108696:	shr    r10d,1
    730a04108699:	and    r10d,0x1e
    730a0410869d:	and    r11d,0x1
    730a041086a1:	or     r10d,r11d
    730a041086a4:	or     DWORD PTR [r12+0x314],r10d
    730a041086ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a041086b2:	ldmxcsr DWORD PTR [r12-0x38]
    730a041086b8:	lea    rdi,[rsp+0x110]
    730a041086c0:	lea    rsi,[rsp+0xf0]
    730a041086c8:	lea    rdx,[rsp+0x100]
    730a041086d0:	mov    ecx,0x56
    730a041086d5:	mov    r8d,0x0
    730a041086db:	lea    r9,[r12+0x314]
    730a041086e3:	movabs r11,0x5591a9a93650
    730a041086ed:	call   r11
    730a041086f0:	ldmxcsr DWORD PTR [r12-0x28]
    730a041086f6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a041086fc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04108702:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04108708:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410870e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04108714:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410871a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04108724:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410872e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04108738:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a04108742:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410874a:	mov    QWORD PTR [r12+0x378],0x2
    730a04108756:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410875f:	mov    rdx,rbx
    730a04108762:	shr    rdx,0x10
    730a04108766:	and    edx,0xc000
    730a0410876c:	mov    rax,rbx
    730a0410876f:	shr    rax,0x15
    730a04108773:	and    eax,0x100
    730a04108778:	xor    eax,0x100
    730a0410877d:	or     edx,eax
    730a0410877f:	mov    rax,rbx
    730a04108782:	shr    rax,0x1c
    730a04108786:	and    eax,0x1
    730a04108789:	or     edx,eax
    730a0410878b:	mov    QWORD PTR [rsp+0x10],rdx
    730a04108790:	add    rsp,0x8
    730a04108794:	ret
    730a04108795:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a041087a0:	sub    rsp,0x8
    730a041087a4:	mov    QWORD PTR [r12+0x378],0x3
    730a041087b0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a041087b6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041087bc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a041087c2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a041087c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a041087d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a041087dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a041087e6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a041087f0:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    730a041087fa:	push   rdx
    730a041087fb:	push   rsi
    730a041087fc:	push   r10
    730a041087fe:	push   r11
    730a04108800:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04108805:	mov    r10d,edx
    730a04108808:	and    r10d,0xc000
    730a0410880f:	shl    r10d,0x10
    730a04108813:	mov    r11d,edx
    730a04108816:	and    r11d,0x100
    730a0410881d:	shl    r11d,0x15
    730a04108821:	or     r10d,r11d
    730a04108824:	and    edx,0x1
    730a04108827:	shl    edx,0x1c
    730a0410882a:	or     r10d,edx
    730a0410882d:	btc    r10,0x1d
    730a04108832:	mov    r11d,0xf0000000
    730a04108838:	and    r11,r10
    730a0410883b:	movabs rsi,0xffffffff0fffffff
    730a04108845:	and    rbx,rsi
    730a04108848:	or     rbx,r11
    730a0410884b:	pop    r11
    730a0410884d:	pop    r10
    730a0410884f:	pop    rsi
    730a04108850:	pop    rdx
    730a04108851:	mov    QWORD PTR [r12+0x108],rbx
    730a04108859:	stmxcsr DWORD PTR [r12-0x28]
    730a0410885f:	mov    r10d,DWORD PTR [r12-0x28]
    730a04108864:	test   r10d,0x3f
    730a0410886b:	je     0x730a04108890
    730a04108871:	mov    r11d,r10d
    730a04108874:	shr    r10d,1
    730a04108877:	and    r10d,0x1e
    730a0410887b:	and    r11d,0x1
    730a0410887f:	or     r10d,r11d
    730a04108882:	or     DWORD PTR [r12+0x314],r10d
    730a0410888a:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04108890:	ldmxcsr DWORD PTR [r12-0x38]
    730a04108896:	lea    rdi,[rsp+0x110]
    730a0410889e:	lea    rsi,[rsp+0xf0]
    730a041088a6:	lea    rdx,[rsp+0x100]
    730a041088ae:	mov    ecx,0x14
    730a041088b3:	mov    r8d,0x0
    730a041088b9:	lea    r9,[r12+0x314]
    730a041088c1:	movabs r11,0x5591a9a93650
    730a041088cb:	call   r11
    730a041088ce:	ldmxcsr DWORD PTR [r12-0x28]
    730a041088d4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a041088da:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a041088e0:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a041088e6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a041088ec:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a041088f6:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04108900:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410890a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04108914:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    730a0410891e:	mov    rbx,QWORD PTR [r12+0x108]
    730a04108926:	mov    QWORD PTR [r12+0x378],0x2
    730a04108932:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410893b:	mov    rdx,rbx
    730a0410893e:	shr    rdx,0x10
    730a04108942:	and    edx,0xc000
    730a04108948:	mov    rax,rbx
    730a0410894b:	shr    rax,0x15
    730a0410894f:	and    eax,0x100
    730a04108954:	xor    eax,0x100
    730a04108959:	or     edx,eax
    730a0410895b:	mov    rax,rbx
    730a0410895e:	shr    rax,0x1c
    730a04108962:	and    eax,0x1
    730a04108965:	or     edx,eax
    730a04108967:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410896c:	add    rsp,0x8
    730a04108970:	ret
    730a04108971:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04108980:	sub    rsp,0x8
    730a04108984:	mov    QWORD PTR [r12+0x378],0x3
    730a04108990:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04108996:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410899c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041089a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a041089a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a041089ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041089b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a041089be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a041089c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a041089d2:	push   rdx
    730a041089d3:	push   rsi
    730a041089d4:	push   r10
    730a041089d6:	push   r11
    730a041089d8:	mov    rdx,QWORD PTR [rsp+0x30]
    730a041089dd:	mov    r10d,edx
    730a041089e0:	and    r10d,0xc000
    730a041089e7:	shl    r10d,0x10
    730a041089eb:	mov    r11d,edx
    730a041089ee:	and    r11d,0x100
    730a041089f5:	shl    r11d,0x15
    730a041089f9:	or     r10d,r11d
    730a041089fc:	and    edx,0x1
    730a041089ff:	shl    edx,0x1c
    730a04108a02:	or     r10d,edx
    730a04108a05:	btc    r10,0x1d
    730a04108a0a:	mov    r11d,0xf0000000
    730a04108a10:	and    r11,r10
    730a04108a13:	movabs rsi,0xffffffff0fffffff
    730a04108a1d:	and    rbx,rsi
    730a04108a20:	or     rbx,r11
    730a04108a23:	pop    r11
    730a04108a25:	pop    r10
    730a04108a27:	pop    rsi
    730a04108a28:	pop    rdx
    730a04108a29:	mov    QWORD PTR [r12+0x108],rbx
    730a04108a31:	stmxcsr DWORD PTR [r12-0x28]
    730a04108a37:	mov    r10d,DWORD PTR [r12-0x28]
    730a04108a3c:	test   r10d,0x3f
    730a04108a43:	je     0x730a04108a68
    730a04108a49:	mov    r11d,r10d
    730a04108a4c:	shr    r10d,1
    730a04108a4f:	and    r10d,0x1e
    730a04108a53:	and    r11d,0x1
    730a04108a57:	or     r10d,r11d
    730a04108a5a:	or     DWORD PTR [r12+0x314],r10d
    730a04108a62:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04108a68:	ldmxcsr DWORD PTR [r12-0x38]
    730a04108a6e:	lea    rdi,[rsp+0x110]
    730a04108a76:	lea    rsi,[rsp+0xf0]
    730a04108a7e:	lea    rdx,[rsp+0x100]
    730a04108a86:	mov    ecx,0x56
    730a04108a8b:	mov    r8d,0x0
    730a04108a91:	lea    r9,[r12+0x314]
    730a04108a99:	movabs r11,0x5591a9a93650
    730a04108aa3:	call   r11
    730a04108aa6:	ldmxcsr DWORD PTR [r12-0x28]
    730a04108aac:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04108ab2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04108ab8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04108abe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04108ac4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04108aca:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04108ad0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04108ada:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04108ae4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04108aee:	mov    rbx,QWORD PTR [r12+0x108]
    730a04108af6:	mov    QWORD PTR [r12+0x378],0x2
    730a04108b02:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04108b0b:	mov    rdx,rbx
    730a04108b0e:	shr    rdx,0x10
    730a04108b12:	and    edx,0xc000
    730a04108b18:	mov    rax,rbx
    730a04108b1b:	shr    rax,0x15
    730a04108b1f:	and    eax,0x100
    730a04108b24:	xor    eax,0x100
    730a04108b29:	or     edx,eax
    730a04108b2b:	mov    rax,rbx
    730a04108b2e:	shr    rax,0x1c
    730a04108b32:	and    eax,0x1
    730a04108b35:	or     edx,eax
    730a04108b37:	mov    QWORD PTR [rsp+0x10],rdx
    730a04108b3c:	add    rsp,0x8
    730a04108b40:	ret
    730a04108b41:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04108b50:	sub    rsp,0x8
    730a04108b54:	mov    QWORD PTR [r12+0x378],0x3
    730a04108b60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04108b66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a04108b6c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04108b72:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04108b78:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04108b7e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a04108b88:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04108b92:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04108b9c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04108ba6:	push   rdx
    730a04108ba7:	push   rsi
    730a04108ba8:	push   r10
    730a04108baa:	push   r11
    730a04108bac:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04108bb1:	mov    r10d,edx
    730a04108bb4:	and    r10d,0xc000
    730a04108bbb:	shl    r10d,0x10
    730a04108bbf:	mov    r11d,edx
    730a04108bc2:	and    r11d,0x100
    730a04108bc9:	shl    r11d,0x15
    730a04108bcd:	or     r10d,r11d
    730a04108bd0:	and    edx,0x1
    730a04108bd3:	shl    edx,0x1c
    730a04108bd6:	or     r10d,edx
    730a04108bd9:	btc    r10,0x1d
    730a04108bde:	mov    r11d,0xf0000000
    730a04108be4:	and    r11,r10
    730a04108be7:	movabs rsi,0xffffffff0fffffff
    730a04108bf1:	and    rbx,rsi
    730a04108bf4:	or     rbx,r11
    730a04108bf7:	pop    r11
    730a04108bf9:	pop    r10
    730a04108bfb:	pop    rsi
    730a04108bfc:	pop    rdx
    730a04108bfd:	mov    QWORD PTR [r12+0x108],rbx
    730a04108c05:	stmxcsr DWORD PTR [r12-0x28]
    730a04108c0b:	mov    r10d,DWORD PTR [r12-0x28]
    730a04108c10:	test   r10d,0x3f
    730a04108c17:	je     0x730a04108c3c
    730a04108c1d:	mov    r11d,r10d
    730a04108c20:	shr    r10d,1
    730a04108c23:	and    r10d,0x1e
    730a04108c27:	and    r11d,0x1
    730a04108c2b:	or     r10d,r11d
    730a04108c2e:	or     DWORD PTR [r12+0x314],r10d
    730a04108c36:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04108c3c:	ldmxcsr DWORD PTR [r12-0x38]
    730a04108c42:	lea    rdi,[rsp+0x110]
    730a04108c4a:	lea    rsi,[rsp+0xf0]
    730a04108c52:	lea    rdx,[rsp+0x100]
    730a04108c5a:	mov    ecx,0x56
    730a04108c5f:	mov    r8d,0x0
    730a04108c65:	lea    r9,[r12+0x314]
    730a04108c6d:	movabs r11,0x5591a9a93650
    730a04108c77:	call   r11
    730a04108c7a:	ldmxcsr DWORD PTR [r12-0x28]
    730a04108c80:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04108c86:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04108c8c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04108c92:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04108c98:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04108c9e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04108ca8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04108cb2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04108cbc:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04108cc6:	mov    rbx,QWORD PTR [r12+0x108]
    730a04108cce:	mov    QWORD PTR [r12+0x378],0x2
    730a04108cda:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04108ce3:	mov    rdx,rbx
    730a04108ce6:	shr    rdx,0x10
    730a04108cea:	and    edx,0xc000
    730a04108cf0:	mov    rax,rbx
    730a04108cf3:	shr    rax,0x15
    730a04108cf7:	and    eax,0x100
    730a04108cfc:	xor    eax,0x100
    730a04108d01:	or     edx,eax
    730a04108d03:	mov    rax,rbx
    730a04108d06:	shr    rax,0x1c
    730a04108d0a:	and    eax,0x1
    730a04108d0d:	or     edx,eax
    730a04108d0f:	mov    QWORD PTR [rsp+0x10],rdx
    730a04108d14:	add    rsp,0x8
    730a04108d18:	ret
    730a04108d19:	nop    DWORD PTR [rax+0x0]
    730a04108d20:	sub    rsp,0x8
    730a04108d24:	mov    QWORD PTR [r12+0x378],0x3
    730a04108d30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04108d36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a04108d3c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04108d42:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04108d48:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04108d4e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04108d54:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a04108d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04108d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04108d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04108d7c:	push   rdx
    730a04108d7d:	push   rsi
    730a04108d7e:	push   r10
    730a04108d80:	push   r11
    730a04108d82:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04108d87:	mov    r10d,edx
    730a04108d8a:	and    r10d,0xc000
    730a04108d91:	shl    r10d,0x10
    730a04108d95:	mov    r11d,edx
    730a04108d98:	and    r11d,0x100
    730a04108d9f:	shl    r11d,0x15
    730a04108da3:	or     r10d,r11d
    730a04108da6:	and    edx,0x1
    730a04108da9:	shl    edx,0x1c
    730a04108dac:	or     r10d,edx
    730a04108daf:	btc    r10,0x1d
    730a04108db4:	mov    r11d,0xf0000000
    730a04108dba:	and    r11,r10
    730a04108dbd:	movabs rsi,0xffffffff0fffffff
    730a04108dc7:	and    rbx,rsi
    730a04108dca:	or     rbx,r11
    730a04108dcd:	pop    r11
    730a04108dcf:	pop    r10
    730a04108dd1:	pop    rsi
    730a04108dd2:	pop    rdx
    730a04108dd3:	mov    QWORD PTR [r12+0x108],rbx
    730a04108ddb:	stmxcsr DWORD PTR [r12-0x28]
    730a04108de1:	mov    r10d,DWORD PTR [r12-0x28]
    730a04108de6:	test   r10d,0x3f
    730a04108ded:	je     0x730a04108e12
    730a04108df3:	mov    r11d,r10d
    730a04108df6:	shr    r10d,1
    730a04108df9:	and    r10d,0x1e
    730a04108dfd:	and    r11d,0x1
    730a04108e01:	or     r10d,r11d
    730a04108e04:	or     DWORD PTR [r12+0x314],r10d
    730a04108e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04108e12:	ldmxcsr DWORD PTR [r12-0x38]
    730a04108e18:	lea    rdi,[rsp+0x110]
    730a04108e20:	lea    rsi,[rsp+0xf0]
    730a04108e28:	lea    rdx,[rsp+0x100]
    730a04108e30:	mov    ecx,0x14
    730a04108e35:	mov    r8d,0x0
    730a04108e3b:	lea    r9,[r12+0x314]
    730a04108e43:	movabs r11,0x5591a9a93650
    730a04108e4d:	call   r11
    730a04108e50:	ldmxcsr DWORD PTR [r12-0x28]
    730a04108e56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04108e5c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04108e62:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04108e68:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04108e6e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04108e74:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04108e7a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04108e84:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04108e8e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04108e98:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04108ea2:	mov    rbx,QWORD PTR [r12+0x108]
    730a04108eaa:	mov    QWORD PTR [r12+0x378],0x2
    730a04108eb6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04108ebf:	mov    rdx,rbx
    730a04108ec2:	shr    rdx,0x10
    730a04108ec6:	and    edx,0xc000
    730a04108ecc:	mov    rax,rbx
    730a04108ecf:	shr    rax,0x15
    730a04108ed3:	and    eax,0x100
    730a04108ed8:	xor    eax,0x100
    730a04108edd:	or     edx,eax
    730a04108edf:	mov    rax,rbx
    730a04108ee2:	shr    rax,0x1c
    730a04108ee6:	and    eax,0x1
    730a04108ee9:	or     edx,eax
    730a04108eeb:	mov    QWORD PTR [rsp+0x10],rdx
    730a04108ef0:	add    rsp,0x8
    730a04108ef4:	ret
    730a04108ef5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04108f00:	sub    rsp,0x8
    730a04108f04:	mov    QWORD PTR [r12+0x378],0x3
    730a04108f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04108f16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a04108f1c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04108f22:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04108f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04108f2e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04108f38:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04108f42:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04108f4c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04108f56:	push   rdx
    730a04108f57:	push   rsi
    730a04108f58:	push   r10
    730a04108f5a:	push   r11
    730a04108f5c:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04108f61:	mov    r10d,edx
    730a04108f64:	and    r10d,0xc000
    730a04108f6b:	shl    r10d,0x10
    730a04108f6f:	mov    r11d,edx
    730a04108f72:	and    r11d,0x100
    730a04108f79:	shl    r11d,0x15
    730a04108f7d:	or     r10d,r11d
    730a04108f80:	and    edx,0x1
    730a04108f83:	shl    edx,0x1c
    730a04108f86:	or     r10d,edx
    730a04108f89:	btc    r10,0x1d
    730a04108f8e:	mov    r11d,0xf0000000
    730a04108f94:	and    r11,r10
    730a04108f97:	movabs rsi,0xffffffff0fffffff
    730a04108fa1:	and    rbx,rsi
    730a04108fa4:	or     rbx,r11
    730a04108fa7:	pop    r11
    730a04108fa9:	pop    r10
    730a04108fab:	pop    rsi
    730a04108fac:	pop    rdx
    730a04108fad:	mov    QWORD PTR [r12+0x108],rbx
    730a04108fb5:	stmxcsr DWORD PTR [r12-0x28]
    730a04108fbb:	mov    r10d,DWORD PTR [r12-0x28]
    730a04108fc0:	test   r10d,0x3f
    730a04108fc7:	je     0x730a04108fec
    730a04108fcd:	mov    r11d,r10d
    730a04108fd0:	shr    r10d,1
    730a04108fd3:	and    r10d,0x1e
    730a04108fd7:	and    r11d,0x1
    730a04108fdb:	or     r10d,r11d
    730a04108fde:	or     DWORD PTR [r12+0x314],r10d
    730a04108fe6:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04108fec:	ldmxcsr DWORD PTR [r12-0x38]
    730a04108ff2:	lea    rdi,[rsp+0x110]
    730a04108ffa:	lea    rsi,[rsp+0xf0]
    730a04109002:	lea    rdx,[rsp+0x100]
    730a0410900a:	mov    ecx,0x14
    730a0410900f:	mov    r8d,0x0
    730a04109015:	lea    r9,[r12+0x314]
    730a0410901d:	movabs r11,0x5591a9a93650
    730a04109027:	call   r11
    730a0410902a:	ldmxcsr DWORD PTR [r12-0x28]
    730a04109030:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04109036:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410903c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04109042:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04109048:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410904e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04109058:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04109062:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a0410906c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04109076:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410907e:	mov    QWORD PTR [r12+0x378],0x2
    730a0410908a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04109093:	mov    rdx,rbx
    730a04109096:	shr    rdx,0x10
    730a0410909a:	and    edx,0xc000
    730a041090a0:	mov    rax,rbx
    730a041090a3:	shr    rax,0x15
    730a041090a7:	and    eax,0x100
    730a041090ac:	xor    eax,0x100
    730a041090b1:	or     edx,eax
    730a041090b3:	mov    rax,rbx
    730a041090b6:	shr    rax,0x1c
    730a041090ba:	and    eax,0x1
    730a041090bd:	or     edx,eax
    730a041090bf:	mov    QWORD PTR [rsp+0x10],rdx
    730a041090c4:	add    rsp,0x8
    730a041090c8:	ret
    730a041090c9:	nop    DWORD PTR [rax+0x0]
    730a041090d0:	sub    rsp,0x8
    730a041090d4:	mov    QWORD PTR [r12+0x378],0x3
    730a041090e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a041090e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a041090ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041090f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a041090f8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041090fe:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04109108:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04109112:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a0410911c:	push   rdx
    730a0410911d:	push   rsi
    730a0410911e:	push   r10
    730a04109120:	push   r11
    730a04109122:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04109127:	mov    r10d,edx
    730a0410912a:	and    r10d,0xc000
    730a04109131:	shl    r10d,0x10
    730a04109135:	mov    r11d,edx
    730a04109138:	and    r11d,0x100
    730a0410913f:	shl    r11d,0x15
    730a04109143:	or     r10d,r11d
    730a04109146:	and    edx,0x1
    730a04109149:	shl    edx,0x1c
    730a0410914c:	or     r10d,edx
    730a0410914f:	btc    r10,0x1d
    730a04109154:	mov    r11d,0xf0000000
    730a0410915a:	and    r11,r10
    730a0410915d:	movabs rsi,0xffffffff0fffffff
    730a04109167:	and    rbx,rsi
    730a0410916a:	or     rbx,r11
    730a0410916d:	pop    r11
    730a0410916f:	pop    r10
    730a04109171:	pop    rsi
    730a04109172:	pop    rdx
    730a04109173:	mov    QWORD PTR [r12+0x108],rbx
    730a0410917b:	stmxcsr DWORD PTR [r12-0x28]
    730a04109181:	mov    r10d,DWORD PTR [r12-0x28]
    730a04109186:	test   r10d,0x3f
    730a0410918d:	je     0x730a041091b2
    730a04109193:	mov    r11d,r10d
    730a04109196:	shr    r10d,1
    730a04109199:	and    r10d,0x1e
    730a0410919d:	and    r11d,0x1
    730a041091a1:	or     r10d,r11d
    730a041091a4:	or     DWORD PTR [r12+0x314],r10d
    730a041091ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a041091b2:	ldmxcsr DWORD PTR [r12-0x38]
    730a041091b8:	lea    rdi,[rsp+0x110]
    730a041091c0:	lea    rsi,[rsp+0xf0]
    730a041091c8:	lea    rdx,[rsp+0x100]
    730a041091d0:	mov    ecx,0x56
    730a041091d5:	mov    r8d,0x0
    730a041091db:	lea    r9,[r12+0x314]
    730a041091e3:	movabs r11,0x5591a9a93650
    730a041091ed:	call   r11
    730a041091f0:	ldmxcsr DWORD PTR [r12-0x28]
    730a041091f6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a041091fc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04109202:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04109208:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410920e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04109214:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410921e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04109228:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04109232:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410923a:	mov    QWORD PTR [r12+0x378],0x2
    730a04109246:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410924f:	mov    rdx,rbx
    730a04109252:	shr    rdx,0x10
    730a04109256:	and    edx,0xc000
    730a0410925c:	mov    rax,rbx
    730a0410925f:	shr    rax,0x15
    730a04109263:	and    eax,0x100
    730a04109268:	xor    eax,0x100
    730a0410926d:	or     edx,eax
    730a0410926f:	mov    rax,rbx
    730a04109272:	shr    rax,0x1c
    730a04109276:	and    eax,0x1
    730a04109279:	or     edx,eax
    730a0410927b:	mov    QWORD PTR [rsp+0x10],rdx
    730a04109280:	add    rsp,0x8
    730a04109284:	ret
    730a04109285:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04109290:	sub    rsp,0x8
    730a04109294:	mov    QWORD PTR [r12+0x378],0x3
    730a041092a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a041092a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a041092ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041092b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a041092b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a041092be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041092c4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a041092ce:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a041092d8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a041092e2:	push   rdx
    730a041092e3:	push   rsi
    730a041092e4:	push   r10
    730a041092e6:	push   r11
    730a041092e8:	mov    rdx,QWORD PTR [rsp+0x30]
    730a041092ed:	mov    r10d,edx
    730a041092f0:	and    r10d,0xc000
    730a041092f7:	shl    r10d,0x10
    730a041092fb:	mov    r11d,edx
    730a041092fe:	and    r11d,0x100
    730a04109305:	shl    r11d,0x15
    730a04109309:	or     r10d,r11d
    730a0410930c:	and    edx,0x1
    730a0410930f:	shl    edx,0x1c
    730a04109312:	or     r10d,edx
    730a04109315:	btc    r10,0x1d
    730a0410931a:	mov    r11d,0xf0000000
    730a04109320:	and    r11,r10
    730a04109323:	movabs rsi,0xffffffff0fffffff
    730a0410932d:	and    rbx,rsi
    730a04109330:	or     rbx,r11
    730a04109333:	pop    r11
    730a04109335:	pop    r10
    730a04109337:	pop    rsi
    730a04109338:	pop    rdx
    730a04109339:	mov    QWORD PTR [r12+0x108],rbx
    730a04109341:	stmxcsr DWORD PTR [r12-0x28]
    730a04109347:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410934c:	test   r10d,0x3f
    730a04109353:	je     0x730a04109378
    730a04109359:	mov    r11d,r10d
    730a0410935c:	shr    r10d,1
    730a0410935f:	and    r10d,0x1e
    730a04109363:	and    r11d,0x1
    730a04109367:	or     r10d,r11d
    730a0410936a:	or     DWORD PTR [r12+0x314],r10d
    730a04109372:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04109378:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410937e:	lea    rdi,[rsp+0x110]
    730a04109386:	lea    rsi,[rsp+0xf0]
    730a0410938e:	lea    rdx,[rsp+0x100]
    730a04109396:	mov    ecx,0x56
    730a0410939b:	mov    r8d,0x0
    730a041093a1:	lea    r9,[r12+0x314]
    730a041093a9:	movabs r11,0x5591a9a93650
    730a041093b3:	call   r11
    730a041093b6:	ldmxcsr DWORD PTR [r12-0x28]
    730a041093bc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a041093c2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a041093c8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a041093ce:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a041093d4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a041093da:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a041093e0:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a041093ea:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a041093f4:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a041093fe:	mov    rbx,QWORD PTR [r12+0x108]
    730a04109406:	mov    QWORD PTR [r12+0x378],0x2
    730a04109412:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410941b:	mov    rdx,rbx
    730a0410941e:	shr    rdx,0x10
    730a04109422:	and    edx,0xc000
    730a04109428:	mov    rax,rbx
    730a0410942b:	shr    rax,0x15
    730a0410942f:	and    eax,0x100
    730a04109434:	xor    eax,0x100
    730a04109439:	or     edx,eax
    730a0410943b:	mov    rax,rbx
    730a0410943e:	shr    rax,0x1c
    730a04109442:	and    eax,0x1
    730a04109445:	or     edx,eax
    730a04109447:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410944c:	add    rsp,0x8
    730a04109450:	ret
    730a04109451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04109460:	sub    rsp,0x8
    730a04109464:	mov    QWORD PTR [r12+0x378],0x3
    730a04109470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04109476:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410947c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04109482:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04109488:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410948e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a04109498:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a041094a2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a041094ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a041094b6:	push   rdx
    730a041094b7:	push   rsi
    730a041094b8:	push   r10
    730a041094ba:	push   r11
    730a041094bc:	mov    rdx,QWORD PTR [rsp+0x30]
    730a041094c1:	mov    r10d,edx
    730a041094c4:	and    r10d,0xc000
    730a041094cb:	shl    r10d,0x10
    730a041094cf:	mov    r11d,edx
    730a041094d2:	and    r11d,0x100
    730a041094d9:	shl    r11d,0x15
    730a041094dd:	or     r10d,r11d
    730a041094e0:	and    edx,0x1
    730a041094e3:	shl    edx,0x1c
    730a041094e6:	or     r10d,edx
    730a041094e9:	btc    r10,0x1d
    730a041094ee:	mov    r11d,0xf0000000
    730a041094f4:	and    r11,r10
    730a041094f7:	movabs rsi,0xffffffff0fffffff
    730a04109501:	and    rbx,rsi
    730a04109504:	or     rbx,r11
    730a04109507:	pop    r11
    730a04109509:	pop    r10
    730a0410950b:	pop    rsi
    730a0410950c:	pop    rdx
    730a0410950d:	mov    QWORD PTR [r12+0x108],rbx
    730a04109515:	stmxcsr DWORD PTR [r12-0x28]
    730a0410951b:	mov    r10d,DWORD PTR [r12-0x28]
    730a04109520:	test   r10d,0x3f
    730a04109527:	je     0x730a0410954c
    730a0410952d:	mov    r11d,r10d
    730a04109530:	shr    r10d,1
    730a04109533:	and    r10d,0x1e
    730a04109537:	and    r11d,0x1
    730a0410953b:	or     r10d,r11d
    730a0410953e:	or     DWORD PTR [r12+0x314],r10d
    730a04109546:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410954c:	ldmxcsr DWORD PTR [r12-0x38]
    730a04109552:	lea    rdi,[rsp+0x110]
    730a0410955a:	lea    rsi,[rsp+0xf0]
    730a04109562:	lea    rdx,[rsp+0x100]
    730a0410956a:	mov    ecx,0x14
    730a0410956f:	mov    r8d,0x0
    730a04109575:	lea    r9,[r12+0x314]
    730a0410957d:	movabs r11,0x5591a9a93650
    730a04109587:	call   r11
    730a0410958a:	ldmxcsr DWORD PTR [r12-0x28]
    730a04109590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04109596:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410959c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a041095a2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a041095a8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a041095ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a041095b8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a041095c2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a041095cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a041095d6:	mov    rbx,QWORD PTR [r12+0x108]
    730a041095de:	mov    QWORD PTR [r12+0x378],0x2
    730a041095ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a041095f3:	mov    rdx,rbx
    730a041095f6:	shr    rdx,0x10
    730a041095fa:	and    edx,0xc000
    730a04109600:	mov    rax,rbx
    730a04109603:	shr    rax,0x15
    730a04109607:	and    eax,0x100
    730a0410960c:	xor    eax,0x100
    730a04109611:	or     edx,eax
    730a04109613:	mov    rax,rbx
    730a04109616:	shr    rax,0x1c
    730a0410961a:	and    eax,0x1
    730a0410961d:	or     edx,eax
    730a0410961f:	mov    QWORD PTR [rsp+0x10],rdx
    730a04109624:	add    rsp,0x8
    730a04109628:	ret
    730a04109629:	nop    DWORD PTR [rax+0x0]
    730a04109630:	sub    rsp,0x8
    730a04109634:	mov    QWORD PTR [r12+0x378],0x3
    730a04109640:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04109646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410964c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04109652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04109658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a0410965e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a04109668:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04109672:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a0410967c:	push   rdx
    730a0410967d:	push   rsi
    730a0410967e:	push   r10
    730a04109680:	push   r11
    730a04109682:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04109687:	mov    r10d,edx
    730a0410968a:	and    r10d,0xc000
    730a04109691:	shl    r10d,0x10
    730a04109695:	mov    r11d,edx
    730a04109698:	and    r11d,0x100
    730a0410969f:	shl    r11d,0x15
    730a041096a3:	or     r10d,r11d
    730a041096a6:	and    edx,0x1
    730a041096a9:	shl    edx,0x1c
    730a041096ac:	or     r10d,edx
    730a041096af:	btc    r10,0x1d
    730a041096b4:	mov    r11d,0xf0000000
    730a041096ba:	and    r11,r10
    730a041096bd:	movabs rsi,0xffffffff0fffffff
    730a041096c7:	and    rbx,rsi
    730a041096ca:	or     rbx,r11
    730a041096cd:	pop    r11
    730a041096cf:	pop    r10
    730a041096d1:	pop    rsi
    730a041096d2:	pop    rdx
    730a041096d3:	mov    QWORD PTR [r12+0x108],rbx
    730a041096db:	stmxcsr DWORD PTR [r12-0x28]
    730a041096e1:	mov    r10d,DWORD PTR [r12-0x28]
    730a041096e6:	test   r10d,0x3f
    730a041096ed:	je     0x730a04109712
    730a041096f3:	mov    r11d,r10d
    730a041096f6:	shr    r10d,1
    730a041096f9:	and    r10d,0x1e
    730a041096fd:	and    r11d,0x1
    730a04109701:	or     r10d,r11d
    730a04109704:	or     DWORD PTR [r12+0x314],r10d
    730a0410970c:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04109712:	ldmxcsr DWORD PTR [r12-0x38]
    730a04109718:	lea    rdi,[rsp+0x110]
    730a04109720:	lea    rsi,[rsp+0xf0]
    730a04109728:	lea    rdx,[rsp+0x100]
    730a04109730:	mov    ecx,0x14
    730a04109735:	mov    r8d,0x0
    730a0410973b:	lea    r9,[r12+0x314]
    730a04109743:	movabs r11,0x5591a9a93650
    730a0410974d:	call   r11
    730a04109750:	ldmxcsr DWORD PTR [r12-0x28]
    730a04109756:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410975c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04109762:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04109768:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410976e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04109774:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a0410977e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04109788:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04109792:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410979a:	mov    QWORD PTR [r12+0x378],0x2
    730a041097a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a041097af:	mov    rdx,rbx
    730a041097b2:	shr    rdx,0x10
    730a041097b6:	and    edx,0xc000
    730a041097bc:	mov    rax,rbx
    730a041097bf:	shr    rax,0x15
    730a041097c3:	and    eax,0x100
    730a041097c8:	xor    eax,0x100
    730a041097cd:	or     edx,eax
    730a041097cf:	mov    rax,rbx
    730a041097d2:	shr    rax,0x1c
    730a041097d6:	and    eax,0x1
    730a041097d9:	or     edx,eax
    730a041097db:	mov    QWORD PTR [rsp+0x10],rdx
    730a041097e0:	add    rsp,0x8
    730a041097e4:	ret
    730a041097e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a041097f0:	sub    rsp,0x8
    730a041097f4:	mov    QWORD PTR [r12+0x378],0x3
    730a04109800:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04109806:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410980c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04109812:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04109818:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410981e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04109824:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a0410982e:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04109838:	push   rdx
    730a04109839:	push   rsi
    730a0410983a:	push   r10
    730a0410983c:	push   r11
    730a0410983e:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04109843:	mov    r10d,edx
    730a04109846:	and    r10d,0xc000
    730a0410984d:	shl    r10d,0x10
    730a04109851:	mov    r11d,edx
    730a04109854:	and    r11d,0x100
    730a0410985b:	shl    r11d,0x15
    730a0410985f:	or     r10d,r11d
    730a04109862:	and    edx,0x1
    730a04109865:	shl    edx,0x1c
    730a04109868:	or     r10d,edx
    730a0410986b:	btc    r10,0x1d
    730a04109870:	mov    r11d,0xf0000000
    730a04109876:	and    r11,r10
    730a04109879:	movabs rsi,0xffffffff0fffffff
    730a04109883:	and    rbx,rsi
    730a04109886:	or     rbx,r11
    730a04109889:	pop    r11
    730a0410988b:	pop    r10
    730a0410988d:	pop    rsi
    730a0410988e:	pop    rdx
    730a0410988f:	mov    QWORD PTR [r12+0x108],rbx
    730a04109897:	stmxcsr DWORD PTR [r12-0x28]
    730a0410989d:	mov    r10d,DWORD PTR [r12-0x28]
    730a041098a2:	test   r10d,0x3f
    730a041098a9:	je     0x730a041098ce
    730a041098af:	mov    r11d,r10d
    730a041098b2:	shr    r10d,1
    730a041098b5:	and    r10d,0x1e
    730a041098b9:	and    r11d,0x1
    730a041098bd:	or     r10d,r11d
    730a041098c0:	or     DWORD PTR [r12+0x314],r10d
    730a041098c8:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a041098ce:	ldmxcsr DWORD PTR [r12-0x38]
    730a041098d4:	lea    rdi,[rsp+0x110]
    730a041098dc:	lea    rsi,[rsp+0xf0]
    730a041098e4:	lea    rdx,[rsp+0x100]
    730a041098ec:	mov    ecx,0x56
    730a041098f1:	mov    r8d,0x0
    730a041098f7:	lea    r9,[r12+0x314]
    730a041098ff:	movabs r11,0x5591a9a93650
    730a04109909:	call   r11
    730a0410990c:	ldmxcsr DWORD PTR [r12-0x28]
    730a04109912:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04109918:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410991e:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04109924:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410992a:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04109930:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04109936:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04109940:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410994a:	mov    rbx,QWORD PTR [r12+0x108]
    730a04109952:	mov    QWORD PTR [r12+0x378],0x2
    730a0410995e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04109967:	mov    rdx,rbx
    730a0410996a:	shr    rdx,0x10
    730a0410996e:	and    edx,0xc000
    730a04109974:	mov    rax,rbx
    730a04109977:	shr    rax,0x15
    730a0410997b:	and    eax,0x100
    730a04109980:	xor    eax,0x100
    730a04109985:	or     edx,eax
    730a04109987:	mov    rax,rbx
    730a0410998a:	shr    rax,0x1c
    730a0410998e:	and    eax,0x1
    730a04109991:	or     edx,eax
    730a04109993:	mov    QWORD PTR [rsp+0x10],rdx
    730a04109998:	add    rsp,0x8
    730a0410999c:	ret
    730a0410999d:	nop    DWORD PTR [rax]
    730a041099a0:	sub    rsp,0x8
    730a041099a4:	mov    QWORD PTR [r12+0x378],0x3
    730a041099b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a041099b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a041099bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a041099c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a041099c8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a041099ce:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a041099d4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a041099de:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a041099e8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a041099f2:	push   rdx
    730a041099f3:	push   rsi
    730a041099f4:	push   r10
    730a041099f6:	push   r11
    730a041099f8:	mov    rdx,QWORD PTR [rsp+0x30]
    730a041099fd:	mov    r10d,edx
    730a04109a00:	and    r10d,0xc000
    730a04109a07:	shl    r10d,0x10
    730a04109a0b:	mov    r11d,edx
    730a04109a0e:	and    r11d,0x100
    730a04109a15:	shl    r11d,0x15
    730a04109a19:	or     r10d,r11d
    730a04109a1c:	and    edx,0x1
    730a04109a1f:	shl    edx,0x1c
    730a04109a22:	or     r10d,edx
    730a04109a25:	btc    r10,0x1d
    730a04109a2a:	mov    r11d,0xf0000000
    730a04109a30:	and    r11,r10
    730a04109a33:	movabs rsi,0xffffffff0fffffff
    730a04109a3d:	and    rbx,rsi
    730a04109a40:	or     rbx,r11
    730a04109a43:	pop    r11
    730a04109a45:	pop    r10
    730a04109a47:	pop    rsi
    730a04109a48:	pop    rdx
    730a04109a49:	mov    QWORD PTR [r12+0x108],rbx
    730a04109a51:	stmxcsr DWORD PTR [r12-0x28]
    730a04109a57:	mov    r10d,DWORD PTR [r12-0x28]
    730a04109a5c:	test   r10d,0x3f
    730a04109a63:	je     0x730a04109a88
    730a04109a69:	mov    r11d,r10d
    730a04109a6c:	shr    r10d,1
    730a04109a6f:	and    r10d,0x1e
    730a04109a73:	and    r11d,0x1
    730a04109a77:	or     r10d,r11d
    730a04109a7a:	or     DWORD PTR [r12+0x314],r10d
    730a04109a82:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04109a88:	ldmxcsr DWORD PTR [r12-0x38]
    730a04109a8e:	lea    rdi,[rsp+0x110]
    730a04109a96:	lea    rsi,[rsp+0xf0]
    730a04109a9e:	lea    rdx,[rsp+0x100]
    730a04109aa6:	mov    ecx,0x14
    730a04109aab:	mov    r8d,0x0
    730a04109ab1:	lea    r9,[r12+0x314]
    730a04109ab9:	movabs r11,0x5591a9a93650
    730a04109ac3:	call   r11
    730a04109ac6:	ldmxcsr DWORD PTR [r12-0x28]
    730a04109acc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04109ad2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04109ad8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04109ade:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04109ae4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04109aea:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04109af0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04109afa:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04109b04:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04109b0e:	mov    rbx,QWORD PTR [r12+0x108]
    730a04109b16:	mov    QWORD PTR [r12+0x378],0x2
    730a04109b22:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04109b2b:	mov    rdx,rbx
    730a04109b2e:	shr    rdx,0x10
    730a04109b32:	and    edx,0xc000
    730a04109b38:	mov    rax,rbx
    730a04109b3b:	shr    rax,0x15
    730a04109b3f:	and    eax,0x100
    730a04109b44:	xor    eax,0x100
    730a04109b49:	or     edx,eax
    730a04109b4b:	mov    rax,rbx
    730a04109b4e:	shr    rax,0x1c
    730a04109b52:	and    eax,0x1
    730a04109b55:	or     edx,eax
    730a04109b57:	mov    QWORD PTR [rsp+0x10],rdx
    730a04109b5c:	add    rsp,0x8
    730a04109b60:	ret
    730a04109b61:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04109b70:	sub    rsp,0x8
    730a04109b74:	mov    QWORD PTR [r12+0x378],0x3
    730a04109b80:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04109b86:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a04109b8c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04109b92:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04109b98:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a04109ba2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04109bac:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04109bb6:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04109bc0:	push   rdx
    730a04109bc1:	push   rsi
    730a04109bc2:	push   r10
    730a04109bc4:	push   r11
    730a04109bc6:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04109bcb:	mov    r10d,edx
    730a04109bce:	and    r10d,0xc000
    730a04109bd5:	shl    r10d,0x10
    730a04109bd9:	mov    r11d,edx
    730a04109bdc:	and    r11d,0x100
    730a04109be3:	shl    r11d,0x15
    730a04109be7:	or     r10d,r11d
    730a04109bea:	and    edx,0x1
    730a04109bed:	shl    edx,0x1c
    730a04109bf0:	or     r10d,edx
    730a04109bf3:	btc    r10,0x1d
    730a04109bf8:	mov    r11d,0xf0000000
    730a04109bfe:	and    r11,r10
    730a04109c01:	movabs rsi,0xffffffff0fffffff
    730a04109c0b:	and    rbx,rsi
    730a04109c0e:	or     rbx,r11
    730a04109c11:	pop    r11
    730a04109c13:	pop    r10
    730a04109c15:	pop    rsi
    730a04109c16:	pop    rdx
    730a04109c17:	mov    QWORD PTR [r12+0x108],rbx
    730a04109c1f:	stmxcsr DWORD PTR [r12-0x28]
    730a04109c25:	mov    r10d,DWORD PTR [r12-0x28]
    730a04109c2a:	test   r10d,0x3f
    730a04109c31:	je     0x730a04109c56
    730a04109c37:	mov    r11d,r10d
    730a04109c3a:	shr    r10d,1
    730a04109c3d:	and    r10d,0x1e
    730a04109c41:	and    r11d,0x1
    730a04109c45:	or     r10d,r11d
    730a04109c48:	or     DWORD PTR [r12+0x314],r10d
    730a04109c50:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04109c56:	ldmxcsr DWORD PTR [r12-0x38]
    730a04109c5c:	lea    rdi,[rsp+0x110]
    730a04109c64:	lea    rsi,[rsp+0xf0]
    730a04109c6c:	lea    rdx,[rsp+0x100]
    730a04109c74:	mov    ecx,0x14
    730a04109c79:	mov    r8d,0x0
    730a04109c7f:	lea    r9,[r12+0x314]
    730a04109c87:	movabs r11,0x5591a9a93650
    730a04109c91:	call   r11
    730a04109c94:	ldmxcsr DWORD PTR [r12-0x28]
    730a04109c9a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04109ca0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04109ca6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04109cac:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a04109cb2:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a04109cbc:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04109cc6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04109cd0:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04109cda:	mov    rbx,QWORD PTR [r12+0x108]
    730a04109ce2:	mov    QWORD PTR [r12+0x378],0x2
    730a04109cee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04109cf7:	mov    rdx,rbx
    730a04109cfa:	shr    rdx,0x10
    730a04109cfe:	and    edx,0xc000
    730a04109d04:	mov    rax,rbx
    730a04109d07:	shr    rax,0x15
    730a04109d0b:	and    eax,0x100
    730a04109d10:	xor    eax,0x100
    730a04109d15:	or     edx,eax
    730a04109d17:	mov    rax,rbx
    730a04109d1a:	shr    rax,0x1c
    730a04109d1e:	and    eax,0x1
    730a04109d21:	or     edx,eax
    730a04109d23:	mov    QWORD PTR [rsp+0x10],rdx
    730a04109d28:	add    rsp,0x8
    730a04109d2c:	ret
    730a04109d2d:	nop    DWORD PTR [rax]
    730a04109d30:	sub    rsp,0x8
    730a04109d34:	mov    QWORD PTR [r12+0x378],0x3
    730a04109d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04109d46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a04109d4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04109d52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04109d58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04109d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a04109d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04109d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04109d7c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04109d86:	push   rdx
    730a04109d87:	push   rsi
    730a04109d88:	push   r10
    730a04109d8a:	push   r11
    730a04109d8c:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04109d91:	mov    r10d,edx
    730a04109d94:	and    r10d,0xc000
    730a04109d9b:	shl    r10d,0x10
    730a04109d9f:	mov    r11d,edx
    730a04109da2:	and    r11d,0x100
    730a04109da9:	shl    r11d,0x15
    730a04109dad:	or     r10d,r11d
    730a04109db0:	and    edx,0x1
    730a04109db3:	shl    edx,0x1c
    730a04109db6:	or     r10d,edx
    730a04109db9:	btc    r10,0x1d
    730a04109dbe:	mov    r11d,0xf0000000
    730a04109dc4:	and    r11,r10
    730a04109dc7:	movabs rsi,0xffffffff0fffffff
    730a04109dd1:	and    rbx,rsi
    730a04109dd4:	or     rbx,r11
    730a04109dd7:	pop    r11
    730a04109dd9:	pop    r10
    730a04109ddb:	pop    rsi
    730a04109ddc:	pop    rdx
    730a04109ddd:	mov    QWORD PTR [r12+0x108],rbx
    730a04109de5:	stmxcsr DWORD PTR [r12-0x28]
    730a04109deb:	mov    r10d,DWORD PTR [r12-0x28]
    730a04109df0:	test   r10d,0x3f
    730a04109df7:	je     0x730a04109e1c
    730a04109dfd:	mov    r11d,r10d
    730a04109e00:	shr    r10d,1
    730a04109e03:	and    r10d,0x1e
    730a04109e07:	and    r11d,0x1
    730a04109e0b:	or     r10d,r11d
    730a04109e0e:	or     DWORD PTR [r12+0x314],r10d
    730a04109e16:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04109e1c:	ldmxcsr DWORD PTR [r12-0x38]
    730a04109e22:	lea    rdi,[rsp+0x110]
    730a04109e2a:	lea    rsi,[rsp+0xf0]
    730a04109e32:	lea    rdx,[rsp+0x100]
    730a04109e3a:	mov    ecx,0x14
    730a04109e3f:	mov    r8d,0x0
    730a04109e45:	lea    r9,[r12+0x314]
    730a04109e4d:	movabs r11,0x5591a9a93650
    730a04109e57:	call   r11
    730a04109e5a:	ldmxcsr DWORD PTR [r12-0x28]
    730a04109e60:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a04109e66:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a04109e6c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a04109e72:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a04109e78:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a04109e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a04109e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a04109e92:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a04109e9c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a04109ea6:	mov    rbx,QWORD PTR [r12+0x108]
    730a04109eae:	mov    QWORD PTR [r12+0x378],0x2
    730a04109eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a04109ec3:	mov    rdx,rbx
    730a04109ec6:	shr    rdx,0x10
    730a04109eca:	and    edx,0xc000
    730a04109ed0:	mov    rax,rbx
    730a04109ed3:	shr    rax,0x15
    730a04109ed7:	and    eax,0x100
    730a04109edc:	xor    eax,0x100
    730a04109ee1:	or     edx,eax
    730a04109ee3:	mov    rax,rbx
    730a04109ee6:	shr    rax,0x1c
    730a04109eea:	and    eax,0x1
    730a04109eed:	or     edx,eax
    730a04109eef:	mov    QWORD PTR [rsp+0x10],rdx
    730a04109ef4:	add    rsp,0x8
    730a04109ef8:	ret
    730a04109ef9:	nop    DWORD PTR [rax+0x0]
    730a04109f00:	sub    rsp,0x8
    730a04109f04:	mov    QWORD PTR [r12+0x378],0x3
    730a04109f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a04109f16:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a04109f1c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a04109f22:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a04109f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a04109f2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a04109f38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a04109f42:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a04109f4c:	push   rdx
    730a04109f4d:	push   rsi
    730a04109f4e:	push   r10
    730a04109f50:	push   r11
    730a04109f52:	mov    rdx,QWORD PTR [rsp+0x30]
    730a04109f57:	mov    r10d,edx
    730a04109f5a:	and    r10d,0xc000
    730a04109f61:	shl    r10d,0x10
    730a04109f65:	mov    r11d,edx
    730a04109f68:	and    r11d,0x100
    730a04109f6f:	shl    r11d,0x15
    730a04109f73:	or     r10d,r11d
    730a04109f76:	and    edx,0x1
    730a04109f79:	shl    edx,0x1c
    730a04109f7c:	or     r10d,edx
    730a04109f7f:	btc    r10,0x1d
    730a04109f84:	mov    r11d,0xf0000000
    730a04109f8a:	and    r11,r10
    730a04109f8d:	movabs rsi,0xffffffff0fffffff
    730a04109f97:	and    rbx,rsi
    730a04109f9a:	or     rbx,r11
    730a04109f9d:	pop    r11
    730a04109f9f:	pop    r10
    730a04109fa1:	pop    rsi
    730a04109fa2:	pop    rdx
    730a04109fa3:	mov    QWORD PTR [r12+0x108],rbx
    730a04109fab:	stmxcsr DWORD PTR [r12-0x28]
    730a04109fb1:	mov    r10d,DWORD PTR [r12-0x28]
    730a04109fb6:	test   r10d,0x3f
    730a04109fbd:	je     0x730a04109fe2
    730a04109fc3:	mov    r11d,r10d
    730a04109fc6:	shr    r10d,1
    730a04109fc9:	and    r10d,0x1e
    730a04109fcd:	and    r11d,0x1
    730a04109fd1:	or     r10d,r11d
    730a04109fd4:	or     DWORD PTR [r12+0x314],r10d
    730a04109fdc:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a04109fe2:	ldmxcsr DWORD PTR [r12-0x38]
    730a04109fe8:	lea    rdi,[rsp+0x110]
    730a04109ff0:	lea    rsi,[rsp+0xf0]
    730a04109ff8:	lea    rdx,[rsp+0x100]
    730a0410a000:	mov    ecx,0x56
    730a0410a005:	mov    r8d,0x0
    730a0410a00b:	lea    r9,[r12+0x314]
    730a0410a013:	movabs r11,0x5591a9a93650
    730a0410a01d:	call   r11
    730a0410a020:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410a026:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410a02c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410a032:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410a038:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410a03e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410a044:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410a04e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a0410a058:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410a062:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410a06a:	mov    QWORD PTR [r12+0x378],0x2
    730a0410a076:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410a07f:	mov    rdx,rbx
    730a0410a082:	shr    rdx,0x10
    730a0410a086:	and    edx,0xc000
    730a0410a08c:	mov    rax,rbx
    730a0410a08f:	shr    rax,0x15
    730a0410a093:	and    eax,0x100
    730a0410a098:	xor    eax,0x100
    730a0410a09d:	or     edx,eax
    730a0410a09f:	mov    rax,rbx
    730a0410a0a2:	shr    rax,0x1c
    730a0410a0a6:	and    eax,0x1
    730a0410a0a9:	or     edx,eax
    730a0410a0ab:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410a0b0:	add    rsp,0x8
    730a0410a0b4:	ret
    730a0410a0b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a0410a0c0:	sub    rsp,0x8
    730a0410a0c4:	mov    QWORD PTR [r12+0x378],0x3
    730a0410a0d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410a0d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410a0dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410a0e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a0410a0e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a0410a0ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a0410a0f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410a102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a0410a10c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a0410a116:	push   rdx
    730a0410a117:	push   rsi
    730a0410a118:	push   r10
    730a0410a11a:	push   r11
    730a0410a11c:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410a121:	mov    r10d,edx
    730a0410a124:	and    r10d,0xc000
    730a0410a12b:	shl    r10d,0x10
    730a0410a12f:	mov    r11d,edx
    730a0410a132:	and    r11d,0x100
    730a0410a139:	shl    r11d,0x15
    730a0410a13d:	or     r10d,r11d
    730a0410a140:	and    edx,0x1
    730a0410a143:	shl    edx,0x1c
    730a0410a146:	or     r10d,edx
    730a0410a149:	btc    r10,0x1d
    730a0410a14e:	mov    r11d,0xf0000000
    730a0410a154:	and    r11,r10
    730a0410a157:	movabs rsi,0xffffffff0fffffff
    730a0410a161:	and    rbx,rsi
    730a0410a164:	or     rbx,r11
    730a0410a167:	pop    r11
    730a0410a169:	pop    r10
    730a0410a16b:	pop    rsi
    730a0410a16c:	pop    rdx
    730a0410a16d:	mov    QWORD PTR [r12+0x108],rbx
    730a0410a175:	stmxcsr DWORD PTR [r12-0x28]
    730a0410a17b:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410a180:	test   r10d,0x3f
    730a0410a187:	je     0x730a0410a1ac
    730a0410a18d:	mov    r11d,r10d
    730a0410a190:	shr    r10d,1
    730a0410a193:	and    r10d,0x1e
    730a0410a197:	and    r11d,0x1
    730a0410a19b:	or     r10d,r11d
    730a0410a19e:	or     DWORD PTR [r12+0x314],r10d
    730a0410a1a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410a1ac:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410a1b2:	lea    rdi,[rsp+0x110]
    730a0410a1ba:	lea    rsi,[rsp+0xf0]
    730a0410a1c2:	lea    rdx,[rsp+0x100]
    730a0410a1ca:	mov    ecx,0x56
    730a0410a1cf:	mov    r8d,0x0
    730a0410a1d5:	lea    r9,[r12+0x314]
    730a0410a1dd:	movabs r11,0x5591a9a93650
    730a0410a1e7:	call   r11
    730a0410a1ea:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410a1f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410a1f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410a1fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410a202:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410a208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410a20e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a0410a218:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410a222:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a0410a22c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410a236:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410a23e:	mov    QWORD PTR [r12+0x378],0x2
    730a0410a24a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410a253:	mov    rdx,rbx
    730a0410a256:	shr    rdx,0x10
    730a0410a25a:	and    edx,0xc000
    730a0410a260:	mov    rax,rbx
    730a0410a263:	shr    rax,0x15
    730a0410a267:	and    eax,0x100
    730a0410a26c:	xor    eax,0x100
    730a0410a271:	or     edx,eax
    730a0410a273:	mov    rax,rbx
    730a0410a276:	shr    rax,0x1c
    730a0410a27a:	and    eax,0x1
    730a0410a27d:	or     edx,eax
    730a0410a27f:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410a284:	add    rsp,0x8
    730a0410a288:	ret
    730a0410a289:	nop    DWORD PTR [rax+0x0]
    730a0410a290:	sub    rsp,0x8
    730a0410a294:	mov    QWORD PTR [r12+0x378],0x3
    730a0410a2a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410a2a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410a2ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410a2b2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410a2b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a0410a2be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a0410a2c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410a2d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a0410a2dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a0410a2e6:	push   rdx
    730a0410a2e7:	push   rsi
    730a0410a2e8:	push   r10
    730a0410a2ea:	push   r11
    730a0410a2ec:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410a2f1:	mov    r10d,edx
    730a0410a2f4:	and    r10d,0xc000
    730a0410a2fb:	shl    r10d,0x10
    730a0410a2ff:	mov    r11d,edx
    730a0410a302:	and    r11d,0x100
    730a0410a309:	shl    r11d,0x15
    730a0410a30d:	or     r10d,r11d
    730a0410a310:	and    edx,0x1
    730a0410a313:	shl    edx,0x1c
    730a0410a316:	or     r10d,edx
    730a0410a319:	btc    r10,0x1d
    730a0410a31e:	mov    r11d,0xf0000000
    730a0410a324:	and    r11,r10
    730a0410a327:	movabs rsi,0xffffffff0fffffff
    730a0410a331:	and    rbx,rsi
    730a0410a334:	or     rbx,r11
    730a0410a337:	pop    r11
    730a0410a339:	pop    r10
    730a0410a33b:	pop    rsi
    730a0410a33c:	pop    rdx
    730a0410a33d:	mov    QWORD PTR [r12+0x108],rbx
    730a0410a345:	stmxcsr DWORD PTR [r12-0x28]
    730a0410a34b:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410a350:	test   r10d,0x3f
    730a0410a357:	je     0x730a0410a37c
    730a0410a35d:	mov    r11d,r10d
    730a0410a360:	shr    r10d,1
    730a0410a363:	and    r10d,0x1e
    730a0410a367:	and    r11d,0x1
    730a0410a36b:	or     r10d,r11d
    730a0410a36e:	or     DWORD PTR [r12+0x314],r10d
    730a0410a376:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410a37c:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410a382:	lea    rdi,[rsp+0x110]
    730a0410a38a:	lea    rsi,[rsp+0xf0]
    730a0410a392:	lea    rdx,[rsp+0x100]
    730a0410a39a:	mov    ecx,0x14
    730a0410a39f:	mov    r8d,0x0
    730a0410a3a5:	lea    r9,[r12+0x314]
    730a0410a3ad:	movabs r11,0x5591a9a93650
    730a0410a3b7:	call   r11
    730a0410a3ba:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410a3c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410a3c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410a3cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410a3d2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410a3d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410a3de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a0410a3e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410a3f2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a0410a3fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410a406:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410a40e:	mov    QWORD PTR [r12+0x378],0x2
    730a0410a41a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410a423:	mov    rdx,rbx
    730a0410a426:	shr    rdx,0x10
    730a0410a42a:	and    edx,0xc000
    730a0410a430:	mov    rax,rbx
    730a0410a433:	shr    rax,0x15
    730a0410a437:	and    eax,0x100
    730a0410a43c:	xor    eax,0x100
    730a0410a441:	or     edx,eax
    730a0410a443:	mov    rax,rbx
    730a0410a446:	shr    rax,0x1c
    730a0410a44a:	and    eax,0x1
    730a0410a44d:	or     edx,eax
    730a0410a44f:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410a454:	add    rsp,0x8
    730a0410a458:	ret
    730a0410a459:	nop    DWORD PTR [rax+0x0]
    730a0410a460:	sub    rsp,0x8
    730a0410a464:	mov    QWORD PTR [r12+0x378],0x3
    730a0410a470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410a476:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410a47c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a0410a482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410a488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a0410a48e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a0410a498:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a0410a4a2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410a4ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a0410a4b6:	push   rdx
    730a0410a4b7:	push   rsi
    730a0410a4b8:	push   r10
    730a0410a4ba:	push   r11
    730a0410a4bc:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410a4c1:	mov    r10d,edx
    730a0410a4c4:	and    r10d,0xc000
    730a0410a4cb:	shl    r10d,0x10
    730a0410a4cf:	mov    r11d,edx
    730a0410a4d2:	and    r11d,0x100
    730a0410a4d9:	shl    r11d,0x15
    730a0410a4dd:	or     r10d,r11d
    730a0410a4e0:	and    edx,0x1
    730a0410a4e3:	shl    edx,0x1c
    730a0410a4e6:	or     r10d,edx
    730a0410a4e9:	btc    r10,0x1d
    730a0410a4ee:	mov    r11d,0xf0000000
    730a0410a4f4:	and    r11,r10
    730a0410a4f7:	movabs rsi,0xffffffff0fffffff
    730a0410a501:	and    rbx,rsi
    730a0410a504:	or     rbx,r11
    730a0410a507:	pop    r11
    730a0410a509:	pop    r10
    730a0410a50b:	pop    rsi
    730a0410a50c:	pop    rdx
    730a0410a50d:	mov    QWORD PTR [r12+0x108],rbx
    730a0410a515:	stmxcsr DWORD PTR [r12-0x28]
    730a0410a51b:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410a520:	test   r10d,0x3f
    730a0410a527:	je     0x730a0410a54c
    730a0410a52d:	mov    r11d,r10d
    730a0410a530:	shr    r10d,1
    730a0410a533:	and    r10d,0x1e
    730a0410a537:	and    r11d,0x1
    730a0410a53b:	or     r10d,r11d
    730a0410a53e:	or     DWORD PTR [r12+0x314],r10d
    730a0410a546:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410a54c:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410a552:	lea    rdi,[rsp+0x110]
    730a0410a55a:	lea    rsi,[rsp+0xf0]
    730a0410a562:	lea    rdx,[rsp+0x100]
    730a0410a56a:	mov    ecx,0x56
    730a0410a56f:	mov    r8d,0x0
    730a0410a575:	lea    r9,[r12+0x314]
    730a0410a57d:	movabs r11,0x5591a9a93650
    730a0410a587:	call   r11
    730a0410a58a:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410a590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410a596:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410a59c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410a5a2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410a5a8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410a5ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a0410a5b8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410a5c2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410a5cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410a5d6:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410a5de:	mov    QWORD PTR [r12+0x378],0x2
    730a0410a5ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410a5f3:	mov    rdx,rbx
    730a0410a5f6:	shr    rdx,0x10
    730a0410a5fa:	and    edx,0xc000
    730a0410a600:	mov    rax,rbx
    730a0410a603:	shr    rax,0x15
    730a0410a607:	and    eax,0x100
    730a0410a60c:	xor    eax,0x100
    730a0410a611:	or     edx,eax
    730a0410a613:	mov    rax,rbx
    730a0410a616:	shr    rax,0x1c
    730a0410a61a:	and    eax,0x1
    730a0410a61d:	or     edx,eax
    730a0410a61f:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410a624:	add    rsp,0x8
    730a0410a628:	ret
    730a0410a629:	nop    DWORD PTR [rax+0x0]
    730a0410a630:	sub    rsp,0x8
    730a0410a634:	mov    QWORD PTR [r12+0x378],0x3
    730a0410a640:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410a646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410a64c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a0410a652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410a658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a0410a65e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a0410a668:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a0410a672:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410a67c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a0410a686:	push   rdx
    730a0410a687:	push   rsi
    730a0410a688:	push   r10
    730a0410a68a:	push   r11
    730a0410a68c:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410a691:	mov    r10d,edx
    730a0410a694:	and    r10d,0xc000
    730a0410a69b:	shl    r10d,0x10
    730a0410a69f:	mov    r11d,edx
    730a0410a6a2:	and    r11d,0x100
    730a0410a6a9:	shl    r11d,0x15
    730a0410a6ad:	or     r10d,r11d
    730a0410a6b0:	and    edx,0x1
    730a0410a6b3:	shl    edx,0x1c
    730a0410a6b6:	or     r10d,edx
    730a0410a6b9:	btc    r10,0x1d
    730a0410a6be:	mov    r11d,0xf0000000
    730a0410a6c4:	and    r11,r10
    730a0410a6c7:	movabs rsi,0xffffffff0fffffff
    730a0410a6d1:	and    rbx,rsi
    730a0410a6d4:	or     rbx,r11
    730a0410a6d7:	pop    r11
    730a0410a6d9:	pop    r10
    730a0410a6db:	pop    rsi
    730a0410a6dc:	pop    rdx
    730a0410a6dd:	mov    QWORD PTR [r12+0x108],rbx
    730a0410a6e5:	stmxcsr DWORD PTR [r12-0x28]
    730a0410a6eb:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410a6f0:	test   r10d,0x3f
    730a0410a6f7:	je     0x730a0410a71c
    730a0410a6fd:	mov    r11d,r10d
    730a0410a700:	shr    r10d,1
    730a0410a703:	and    r10d,0x1e
    730a0410a707:	and    r11d,0x1
    730a0410a70b:	or     r10d,r11d
    730a0410a70e:	or     DWORD PTR [r12+0x314],r10d
    730a0410a716:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410a71c:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410a722:	lea    rdi,[rsp+0x110]
    730a0410a72a:	lea    rsi,[rsp+0xf0]
    730a0410a732:	lea    rdx,[rsp+0x100]
    730a0410a73a:	mov    ecx,0x14
    730a0410a73f:	mov    r8d,0x0
    730a0410a745:	lea    r9,[r12+0x314]
    730a0410a74d:	movabs r11,0x5591a9a93650
    730a0410a757:	call   r11
    730a0410a75a:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410a760:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410a766:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410a76c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410a772:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410a778:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410a77e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a0410a788:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410a792:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410a79c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410a7a6:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410a7ae:	mov    QWORD PTR [r12+0x378],0x2
    730a0410a7ba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410a7c3:	mov    rdx,rbx
    730a0410a7c6:	shr    rdx,0x10
    730a0410a7ca:	and    edx,0xc000
    730a0410a7d0:	mov    rax,rbx
    730a0410a7d3:	shr    rax,0x15
    730a0410a7d7:	and    eax,0x100
    730a0410a7dc:	xor    eax,0x100
    730a0410a7e1:	or     edx,eax
    730a0410a7e3:	mov    rax,rbx
    730a0410a7e6:	shr    rax,0x1c
    730a0410a7ea:	and    eax,0x1
    730a0410a7ed:	or     edx,eax
    730a0410a7ef:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410a7f4:	add    rsp,0x8
    730a0410a7f8:	ret
    730a0410a7f9:	nop    DWORD PTR [rax+0x0]
    730a0410a800:	sub    rsp,0x8
    730a0410a804:	mov    QWORD PTR [r12+0x378],0x3
    730a0410a810:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410a816:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410a81c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a0410a822:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410a828:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a0410a82e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a0410a838:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410a842:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a0410a84c:	push   rdx
    730a0410a84d:	push   rsi
    730a0410a84e:	push   r10
    730a0410a850:	push   r11
    730a0410a852:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410a857:	mov    r10d,edx
    730a0410a85a:	and    r10d,0xc000
    730a0410a861:	shl    r10d,0x10
    730a0410a865:	mov    r11d,edx
    730a0410a868:	and    r11d,0x100
    730a0410a86f:	shl    r11d,0x15
    730a0410a873:	or     r10d,r11d
    730a0410a876:	and    edx,0x1
    730a0410a879:	shl    edx,0x1c
    730a0410a87c:	or     r10d,edx
    730a0410a87f:	btc    r10,0x1d
    730a0410a884:	mov    r11d,0xf0000000
    730a0410a88a:	and    r11,r10
    730a0410a88d:	movabs rsi,0xffffffff0fffffff
    730a0410a897:	and    rbx,rsi
    730a0410a89a:	or     rbx,r11
    730a0410a89d:	pop    r11
    730a0410a89f:	pop    r10
    730a0410a8a1:	pop    rsi
    730a0410a8a2:	pop    rdx
    730a0410a8a3:	mov    QWORD PTR [r12+0x108],rbx
    730a0410a8ab:	stmxcsr DWORD PTR [r12-0x28]
    730a0410a8b1:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410a8b6:	test   r10d,0x3f
    730a0410a8bd:	je     0x730a0410a8e2
    730a0410a8c3:	mov    r11d,r10d
    730a0410a8c6:	shr    r10d,1
    730a0410a8c9:	and    r10d,0x1e
    730a0410a8cd:	and    r11d,0x1
    730a0410a8d1:	or     r10d,r11d
    730a0410a8d4:	or     DWORD PTR [r12+0x314],r10d
    730a0410a8dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410a8e2:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410a8e8:	lea    rdi,[rsp+0x110]
    730a0410a8f0:	lea    rsi,[rsp+0xf0]
    730a0410a8f8:	lea    rdx,[rsp+0x100]
    730a0410a900:	mov    ecx,0x14
    730a0410a905:	mov    r8d,0x0
    730a0410a90b:	lea    r9,[r12+0x314]
    730a0410a913:	movabs r11,0x5591a9a93650
    730a0410a91d:	call   r11
    730a0410a920:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410a926:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410a92c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410a932:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410a938:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410a93e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410a944:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410a94e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410a958:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a0410a962:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410a96a:	mov    QWORD PTR [r12+0x378],0x2
    730a0410a976:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410a97f:	mov    rdx,rbx
    730a0410a982:	shr    rdx,0x10
    730a0410a986:	and    edx,0xc000
    730a0410a98c:	mov    rax,rbx
    730a0410a98f:	shr    rax,0x15
    730a0410a993:	and    eax,0x100
    730a0410a998:	xor    eax,0x100
    730a0410a99d:	or     edx,eax
    730a0410a99f:	mov    rax,rbx
    730a0410a9a2:	shr    rax,0x1c
    730a0410a9a6:	and    eax,0x1
    730a0410a9a9:	or     edx,eax
    730a0410a9ab:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410a9b0:	add    rsp,0x8
    730a0410a9b4:	ret
    730a0410a9b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a0410a9c0:	sub    rsp,0x8
    730a0410a9c4:	mov    QWORD PTR [r12+0x378],0x3
    730a0410a9d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410a9d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410a9dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410a9e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a0410a9e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410a9ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a0410a9f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410aa02:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a0410aa0c:	push   rdx
    730a0410aa0d:	push   rsi
    730a0410aa0e:	push   r10
    730a0410aa10:	push   r11
    730a0410aa12:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410aa17:	mov    r10d,edx
    730a0410aa1a:	and    r10d,0xc000
    730a0410aa21:	shl    r10d,0x10
    730a0410aa25:	mov    r11d,edx
    730a0410aa28:	and    r11d,0x100
    730a0410aa2f:	shl    r11d,0x15
    730a0410aa33:	or     r10d,r11d
    730a0410aa36:	and    edx,0x1
    730a0410aa39:	shl    edx,0x1c
    730a0410aa3c:	or     r10d,edx
    730a0410aa3f:	btc    r10,0x1d
    730a0410aa44:	mov    r11d,0xf0000000
    730a0410aa4a:	and    r11,r10
    730a0410aa4d:	movabs rsi,0xffffffff0fffffff
    730a0410aa57:	and    rbx,rsi
    730a0410aa5a:	or     rbx,r11
    730a0410aa5d:	pop    r11
    730a0410aa5f:	pop    r10
    730a0410aa61:	pop    rsi
    730a0410aa62:	pop    rdx
    730a0410aa63:	mov    QWORD PTR [r12+0x108],rbx
    730a0410aa6b:	stmxcsr DWORD PTR [r12-0x28]
    730a0410aa71:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410aa76:	test   r10d,0x3f
    730a0410aa7d:	je     0x730a0410aaa2
    730a0410aa83:	mov    r11d,r10d
    730a0410aa86:	shr    r10d,1
    730a0410aa89:	and    r10d,0x1e
    730a0410aa8d:	and    r11d,0x1
    730a0410aa91:	or     r10d,r11d
    730a0410aa94:	or     DWORD PTR [r12+0x314],r10d
    730a0410aa9c:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410aaa2:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410aaa8:	lea    rdi,[rsp+0x110]
    730a0410aab0:	lea    rsi,[rsp+0xf0]
    730a0410aab8:	lea    rdx,[rsp+0x100]
    730a0410aac0:	mov    ecx,0x14
    730a0410aac5:	mov    r8d,0x0
    730a0410aacb:	lea    r9,[r12+0x314]
    730a0410aad3:	movabs r11,0x5591a9a93650
    730a0410aadd:	call   r11
    730a0410aae0:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410aae6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410aaec:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410aaf2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410aaf8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410aafe:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410ab04:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410ab0e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410ab18:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a0410ab22:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410ab2a:	mov    QWORD PTR [r12+0x378],0x2
    730a0410ab36:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410ab3f:	mov    rdx,rbx
    730a0410ab42:	shr    rdx,0x10
    730a0410ab46:	and    edx,0xc000
    730a0410ab4c:	mov    rax,rbx
    730a0410ab4f:	shr    rax,0x15
    730a0410ab53:	and    eax,0x100
    730a0410ab58:	xor    eax,0x100
    730a0410ab5d:	or     edx,eax
    730a0410ab5f:	mov    rax,rbx
    730a0410ab62:	shr    rax,0x1c
    730a0410ab66:	and    eax,0x1
    730a0410ab69:	or     edx,eax
    730a0410ab6b:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410ab70:	add    rsp,0x8
    730a0410ab74:	ret
    730a0410ab75:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a0410ab80:	sub    rsp,0x8
    730a0410ab84:	mov    QWORD PTR [r12+0x378],0x3
    730a0410ab90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410ab96:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410ab9c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410aba2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a0410aba8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410abae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a0410abb4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410abbe:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a0410abc8:	push   rdx
    730a0410abc9:	push   rsi
    730a0410abca:	push   r10
    730a0410abcc:	push   r11
    730a0410abce:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410abd3:	mov    r10d,edx
    730a0410abd6:	and    r10d,0xc000
    730a0410abdd:	shl    r10d,0x10
    730a0410abe1:	mov    r11d,edx
    730a0410abe4:	and    r11d,0x100
    730a0410abeb:	shl    r11d,0x15
    730a0410abef:	or     r10d,r11d
    730a0410abf2:	and    edx,0x1
    730a0410abf5:	shl    edx,0x1c
    730a0410abf8:	or     r10d,edx
    730a0410abfb:	btc    r10,0x1d
    730a0410ac00:	mov    r11d,0xf0000000
    730a0410ac06:	and    r11,r10
    730a0410ac09:	movabs rsi,0xffffffff0fffffff
    730a0410ac13:	and    rbx,rsi
    730a0410ac16:	or     rbx,r11
    730a0410ac19:	pop    r11
    730a0410ac1b:	pop    r10
    730a0410ac1d:	pop    rsi
    730a0410ac1e:	pop    rdx
    730a0410ac1f:	mov    QWORD PTR [r12+0x108],rbx
    730a0410ac27:	stmxcsr DWORD PTR [r12-0x28]
    730a0410ac2d:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410ac32:	test   r10d,0x3f
    730a0410ac39:	je     0x730a0410ac5e
    730a0410ac3f:	mov    r11d,r10d
    730a0410ac42:	shr    r10d,1
    730a0410ac45:	and    r10d,0x1e
    730a0410ac49:	and    r11d,0x1
    730a0410ac4d:	or     r10d,r11d
    730a0410ac50:	or     DWORD PTR [r12+0x314],r10d
    730a0410ac58:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410ac5e:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410ac64:	lea    rdi,[rsp+0x110]
    730a0410ac6c:	lea    rsi,[rsp+0xf0]
    730a0410ac74:	lea    rdx,[rsp+0x100]
    730a0410ac7c:	mov    ecx,0x56
    730a0410ac81:	mov    r8d,0x0
    730a0410ac87:	lea    r9,[r12+0x314]
    730a0410ac8f:	movabs r11,0x5591a9a93650
    730a0410ac99:	call   r11
    730a0410ac9c:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410aca2:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410aca8:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410acae:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410acb4:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410acba:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410acc0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410acc6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410acd0:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a0410acda:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410ace2:	mov    QWORD PTR [r12+0x378],0x2
    730a0410acee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410acf7:	mov    rdx,rbx
    730a0410acfa:	shr    rdx,0x10
    730a0410acfe:	and    edx,0xc000
    730a0410ad04:	mov    rax,rbx
    730a0410ad07:	shr    rax,0x15
    730a0410ad0b:	and    eax,0x100
    730a0410ad10:	xor    eax,0x100
    730a0410ad15:	or     edx,eax
    730a0410ad17:	mov    rax,rbx
    730a0410ad1a:	shr    rax,0x1c
    730a0410ad1e:	and    eax,0x1
    730a0410ad21:	or     edx,eax
    730a0410ad23:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410ad28:	add    rsp,0x8
    730a0410ad2c:	ret
    730a0410ad2d:	nop    DWORD PTR [rax]
    730a0410ad30:	sub    rsp,0x8
    730a0410ad34:	mov    QWORD PTR [r12+0x378],0x3
    730a0410ad40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410ad46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410ad4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410ad52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a0410ad58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a0410ad5e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a0410ad68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410ad72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a0410ad7c:	push   rdx
    730a0410ad7d:	push   rsi
    730a0410ad7e:	push   r10
    730a0410ad80:	push   r11
    730a0410ad82:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410ad87:	mov    r10d,edx
    730a0410ad8a:	and    r10d,0xc000
    730a0410ad91:	shl    r10d,0x10
    730a0410ad95:	mov    r11d,edx
    730a0410ad98:	and    r11d,0x100
    730a0410ad9f:	shl    r11d,0x15
    730a0410ada3:	or     r10d,r11d
    730a0410ada6:	and    edx,0x1
    730a0410ada9:	shl    edx,0x1c
    730a0410adac:	or     r10d,edx
    730a0410adaf:	btc    r10,0x1d
    730a0410adb4:	mov    r11d,0xf0000000
    730a0410adba:	and    r11,r10
    730a0410adbd:	movabs rsi,0xffffffff0fffffff
    730a0410adc7:	and    rbx,rsi
    730a0410adca:	or     rbx,r11
    730a0410adcd:	pop    r11
    730a0410adcf:	pop    r10
    730a0410add1:	pop    rsi
    730a0410add2:	pop    rdx
    730a0410add3:	mov    QWORD PTR [r12+0x108],rbx
    730a0410addb:	stmxcsr DWORD PTR [r12-0x28]
    730a0410ade1:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410ade6:	test   r10d,0x3f
    730a0410aded:	je     0x730a0410ae12
    730a0410adf3:	mov    r11d,r10d
    730a0410adf6:	shr    r10d,1
    730a0410adf9:	and    r10d,0x1e
    730a0410adfd:	and    r11d,0x1
    730a0410ae01:	or     r10d,r11d
    730a0410ae04:	or     DWORD PTR [r12+0x314],r10d
    730a0410ae0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410ae12:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410ae18:	lea    rdi,[rsp+0x110]
    730a0410ae20:	lea    rsi,[rsp+0xf0]
    730a0410ae28:	lea    rdx,[rsp+0x100]
    730a0410ae30:	mov    ecx,0x56
    730a0410ae35:	mov    r8d,0x0
    730a0410ae3b:	lea    r9,[r12+0x314]
    730a0410ae43:	movabs r11,0x5591a9a93650
    730a0410ae4d:	call   r11
    730a0410ae50:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410ae56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410ae5c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410ae62:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410ae68:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410ae6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410ae74:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a0410ae7e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410ae88:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a0410ae92:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410ae9a:	mov    QWORD PTR [r12+0x378],0x2
    730a0410aea6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410aeaf:	mov    rdx,rbx
    730a0410aeb2:	shr    rdx,0x10
    730a0410aeb6:	and    edx,0xc000
    730a0410aebc:	mov    rax,rbx
    730a0410aebf:	shr    rax,0x15
    730a0410aec3:	and    eax,0x100
    730a0410aec8:	xor    eax,0x100
    730a0410aecd:	or     edx,eax
    730a0410aecf:	mov    rax,rbx
    730a0410aed2:	shr    rax,0x1c
    730a0410aed6:	and    eax,0x1
    730a0410aed9:	or     edx,eax
    730a0410aedb:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410aee0:	add    rsp,0x8
    730a0410aee4:	ret
    730a0410aee5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a0410aef0:	sub    rsp,0x8
    730a0410aef4:	mov    QWORD PTR [r12+0x378],0x3
    730a0410af00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410af06:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410af0c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410af12:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a0410af18:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410af1e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a0410af24:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a0410af2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410af38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    730a0410af42:	push   rdx
    730a0410af43:	push   rsi
    730a0410af44:	push   r10
    730a0410af46:	push   r11
    730a0410af48:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410af4d:	mov    r10d,edx
    730a0410af50:	and    r10d,0xc000
    730a0410af57:	shl    r10d,0x10
    730a0410af5b:	mov    r11d,edx
    730a0410af5e:	and    r11d,0x100
    730a0410af65:	shl    r11d,0x15
    730a0410af69:	or     r10d,r11d
    730a0410af6c:	and    edx,0x1
    730a0410af6f:	shl    edx,0x1c
    730a0410af72:	or     r10d,edx
    730a0410af75:	btc    r10,0x1d
    730a0410af7a:	mov    r11d,0xf0000000
    730a0410af80:	and    r11,r10
    730a0410af83:	movabs rsi,0xffffffff0fffffff
    730a0410af8d:	and    rbx,rsi
    730a0410af90:	or     rbx,r11
    730a0410af93:	pop    r11
    730a0410af95:	pop    r10
    730a0410af97:	pop    rsi
    730a0410af98:	pop    rdx
    730a0410af99:	mov    QWORD PTR [r12+0x108],rbx
    730a0410afa1:	stmxcsr DWORD PTR [r12-0x28]
    730a0410afa7:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410afac:	test   r10d,0x3f
    730a0410afb3:	je     0x730a0410afd8
    730a0410afb9:	mov    r11d,r10d
    730a0410afbc:	shr    r10d,1
    730a0410afbf:	and    r10d,0x1e
    730a0410afc3:	and    r11d,0x1
    730a0410afc7:	or     r10d,r11d
    730a0410afca:	or     DWORD PTR [r12+0x314],r10d
    730a0410afd2:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410afd8:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410afde:	lea    rdi,[rsp+0x110]
    730a0410afe6:	lea    rsi,[rsp+0xf0]
    730a0410afee:	lea    rdx,[rsp+0x100]
    730a0410aff6:	mov    ecx,0x14
    730a0410affb:	mov    r8d,0x0
    730a0410b001:	lea    r9,[r12+0x314]
    730a0410b009:	movabs r11,0x5591a9a93650
    730a0410b013:	call   r11
    730a0410b016:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410b01c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410b022:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410b028:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410b02e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410b034:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410b03a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410b040:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a0410b04a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410b054:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    730a0410b05e:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410b066:	mov    QWORD PTR [r12+0x378],0x2
    730a0410b072:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410b07b:	mov    rdx,rbx
    730a0410b07e:	shr    rdx,0x10
    730a0410b082:	and    edx,0xc000
    730a0410b088:	mov    rax,rbx
    730a0410b08b:	shr    rax,0x15
    730a0410b08f:	and    eax,0x100
    730a0410b094:	xor    eax,0x100
    730a0410b099:	or     edx,eax
    730a0410b09b:	mov    rax,rbx
    730a0410b09e:	shr    rax,0x1c
    730a0410b0a2:	and    eax,0x1
    730a0410b0a5:	or     edx,eax
    730a0410b0a7:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410b0ac:	add    rsp,0x8
    730a0410b0b0:	ret
    730a0410b0b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a0410b0c0:	sub    rsp,0x8
    730a0410b0c4:	mov    QWORD PTR [r12+0x378],0x3
    730a0410b0d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410b0d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410b0dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a0410b0e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410b0e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a0410b0ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a0410b0f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a0410b102:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410b10c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a0410b116:	push   rdx
    730a0410b117:	push   rsi
    730a0410b118:	push   r10
    730a0410b11a:	push   r11
    730a0410b11c:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410b121:	mov    r10d,edx
    730a0410b124:	and    r10d,0xc000
    730a0410b12b:	shl    r10d,0x10
    730a0410b12f:	mov    r11d,edx
    730a0410b132:	and    r11d,0x100
    730a0410b139:	shl    r11d,0x15
    730a0410b13d:	or     r10d,r11d
    730a0410b140:	and    edx,0x1
    730a0410b143:	shl    edx,0x1c
    730a0410b146:	or     r10d,edx
    730a0410b149:	btc    r10,0x1d
    730a0410b14e:	mov    r11d,0xf0000000
    730a0410b154:	and    r11,r10
    730a0410b157:	movabs rsi,0xffffffff0fffffff
    730a0410b161:	and    rbx,rsi
    730a0410b164:	or     rbx,r11
    730a0410b167:	pop    r11
    730a0410b169:	pop    r10
    730a0410b16b:	pop    rsi
    730a0410b16c:	pop    rdx
    730a0410b16d:	mov    QWORD PTR [r12+0x108],rbx
    730a0410b175:	stmxcsr DWORD PTR [r12-0x28]
    730a0410b17b:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410b180:	test   r10d,0x3f
    730a0410b187:	je     0x730a0410b1ac
    730a0410b18d:	mov    r11d,r10d
    730a0410b190:	shr    r10d,1
    730a0410b193:	and    r10d,0x1e
    730a0410b197:	and    r11d,0x1
    730a0410b19b:	or     r10d,r11d
    730a0410b19e:	or     DWORD PTR [r12+0x314],r10d
    730a0410b1a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410b1ac:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410b1b2:	lea    rdi,[rsp+0x110]
    730a0410b1ba:	lea    rsi,[rsp+0xf0]
    730a0410b1c2:	lea    rdx,[rsp+0x100]
    730a0410b1ca:	mov    ecx,0x56
    730a0410b1cf:	mov    r8d,0x0
    730a0410b1d5:	lea    r9,[r12+0x314]
    730a0410b1dd:	movabs r11,0x5591a9a93650
    730a0410b1e7:	call   r11
    730a0410b1ea:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410b1f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410b1f6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410b1fc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410b202:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410b208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410b20e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a0410b218:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410b222:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410b22c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410b236:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410b23e:	mov    QWORD PTR [r12+0x378],0x2
    730a0410b24a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410b253:	mov    rdx,rbx
    730a0410b256:	shr    rdx,0x10
    730a0410b25a:	and    edx,0xc000
    730a0410b260:	mov    rax,rbx
    730a0410b263:	shr    rax,0x15
    730a0410b267:	and    eax,0x100
    730a0410b26c:	xor    eax,0x100
    730a0410b271:	or     edx,eax
    730a0410b273:	mov    rax,rbx
    730a0410b276:	shr    rax,0x1c
    730a0410b27a:	and    eax,0x1
    730a0410b27d:	or     edx,eax
    730a0410b27f:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410b284:	add    rsp,0x8
    730a0410b288:	ret
    730a0410b289:	nop    DWORD PTR [rax+0x0]
    730a0410b290:	sub    rsp,0x8
    730a0410b294:	mov    QWORD PTR [r12+0x378],0x3
    730a0410b2a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410b2a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410b2ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410b2b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a0410b2b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410b2be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a0410b2c4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    730a0410b2ce:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a0410b2d8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a0410b2e2:	push   rdx
    730a0410b2e3:	push   rsi
    730a0410b2e4:	push   r10
    730a0410b2e6:	push   r11
    730a0410b2e8:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410b2ed:	mov    r10d,edx
    730a0410b2f0:	and    r10d,0xc000
    730a0410b2f7:	shl    r10d,0x10
    730a0410b2fb:	mov    r11d,edx
    730a0410b2fe:	and    r11d,0x100
    730a0410b305:	shl    r11d,0x15
    730a0410b309:	or     r10d,r11d
    730a0410b30c:	and    edx,0x1
    730a0410b30f:	shl    edx,0x1c
    730a0410b312:	or     r10d,edx
    730a0410b315:	btc    r10,0x1d
    730a0410b31a:	mov    r11d,0xf0000000
    730a0410b320:	and    r11,r10
    730a0410b323:	movabs rsi,0xffffffff0fffffff
    730a0410b32d:	and    rbx,rsi
    730a0410b330:	or     rbx,r11
    730a0410b333:	pop    r11
    730a0410b335:	pop    r10
    730a0410b337:	pop    rsi
    730a0410b338:	pop    rdx
    730a0410b339:	mov    QWORD PTR [r12+0x108],rbx
    730a0410b341:	stmxcsr DWORD PTR [r12-0x28]
    730a0410b347:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410b34c:	test   r10d,0x3f
    730a0410b353:	je     0x730a0410b378
    730a0410b359:	mov    r11d,r10d
    730a0410b35c:	shr    r10d,1
    730a0410b35f:	and    r10d,0x1e
    730a0410b363:	and    r11d,0x1
    730a0410b367:	or     r10d,r11d
    730a0410b36a:	or     DWORD PTR [r12+0x314],r10d
    730a0410b372:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410b378:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410b37e:	lea    rdi,[rsp+0x110]
    730a0410b386:	lea    rsi,[rsp+0xf0]
    730a0410b38e:	lea    rdx,[rsp+0x100]
    730a0410b396:	mov    ecx,0x56
    730a0410b39b:	mov    r8d,0x0
    730a0410b3a1:	lea    r9,[r12+0x314]
    730a0410b3a9:	movabs r11,0x5591a9a93650
    730a0410b3b3:	call   r11
    730a0410b3b6:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410b3bc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410b3c2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410b3c8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410b3ce:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410b3d4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410b3da:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410b3e0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    730a0410b3ea:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410b3f4:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410b3fe:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410b406:	mov    QWORD PTR [r12+0x378],0x2
    730a0410b412:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410b41b:	mov    rdx,rbx
    730a0410b41e:	shr    rdx,0x10
    730a0410b422:	and    edx,0xc000
    730a0410b428:	mov    rax,rbx
    730a0410b42b:	shr    rax,0x15
    730a0410b42f:	and    eax,0x100
    730a0410b434:	xor    eax,0x100
    730a0410b439:	or     edx,eax
    730a0410b43b:	mov    rax,rbx
    730a0410b43e:	shr    rax,0x1c
    730a0410b442:	and    eax,0x1
    730a0410b445:	or     edx,eax
    730a0410b447:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410b44c:	add    rsp,0x8
    730a0410b450:	ret
    730a0410b451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a0410b460:	sub    rsp,0x8
    730a0410b464:	mov    QWORD PTR [r12+0x378],0x3
    730a0410b470:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410b476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410b47c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    730a0410b482:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    730a0410b488:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a0410b492:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410b49c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a0410b4a6:	push   rdx
    730a0410b4a7:	push   rsi
    730a0410b4a8:	push   r10
    730a0410b4aa:	push   r11
    730a0410b4ac:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410b4b1:	mov    r10d,edx
    730a0410b4b4:	and    r10d,0xc000
    730a0410b4bb:	shl    r10d,0x10
    730a0410b4bf:	mov    r11d,edx
    730a0410b4c2:	and    r11d,0x100
    730a0410b4c9:	shl    r11d,0x15
    730a0410b4cd:	or     r10d,r11d
    730a0410b4d0:	and    edx,0x1
    730a0410b4d3:	shl    edx,0x1c
    730a0410b4d6:	or     r10d,edx
    730a0410b4d9:	btc    r10,0x1d
    730a0410b4de:	mov    r11d,0xf0000000
    730a0410b4e4:	and    r11,r10
    730a0410b4e7:	movabs rsi,0xffffffff0fffffff
    730a0410b4f1:	and    rbx,rsi
    730a0410b4f4:	or     rbx,r11
    730a0410b4f7:	pop    r11
    730a0410b4f9:	pop    r10
    730a0410b4fb:	pop    rsi
    730a0410b4fc:	pop    rdx
    730a0410b4fd:	mov    QWORD PTR [r12+0x108],rbx
    730a0410b505:	stmxcsr DWORD PTR [r12-0x28]
    730a0410b50b:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410b510:	test   r10d,0x3f
    730a0410b517:	je     0x730a0410b53c
    730a0410b51d:	mov    r11d,r10d
    730a0410b520:	shr    r10d,1
    730a0410b523:	and    r10d,0x1e
    730a0410b527:	and    r11d,0x1
    730a0410b52b:	or     r10d,r11d
    730a0410b52e:	or     DWORD PTR [r12+0x314],r10d
    730a0410b536:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410b53c:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410b542:	lea    rdi,[rsp+0x110]
    730a0410b54a:	lea    rsi,[rsp+0xf0]
    730a0410b552:	lea    rdx,[rsp+0x100]
    730a0410b55a:	mov    ecx,0x14
    730a0410b55f:	mov    r8d,0x0
    730a0410b565:	lea    r9,[r12+0x314]
    730a0410b56d:	movabs r11,0x5591a9a93650
    730a0410b577:	call   r11
    730a0410b57a:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410b580:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410b586:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410b58c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    730a0410b592:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    730a0410b598:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410b5a2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410b5ac:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410b5b6:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410b5be:	mov    QWORD PTR [r12+0x378],0x2
    730a0410b5ca:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410b5d3:	mov    rdx,rbx
    730a0410b5d6:	shr    rdx,0x10
    730a0410b5da:	and    edx,0xc000
    730a0410b5e0:	mov    rax,rbx
    730a0410b5e3:	shr    rax,0x15
    730a0410b5e7:	and    eax,0x100
    730a0410b5ec:	xor    eax,0x100
    730a0410b5f1:	or     edx,eax
    730a0410b5f3:	mov    rax,rbx
    730a0410b5f6:	shr    rax,0x1c
    730a0410b5fa:	and    eax,0x1
    730a0410b5fd:	or     edx,eax
    730a0410b5ff:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410b604:	add    rsp,0x8
    730a0410b608:	ret
    730a0410b609:	nop    DWORD PTR [rax+0x0]
    730a0410b610:	sub    rsp,0x8
    730a0410b614:	mov    QWORD PTR [r12+0x378],0x3
    730a0410b620:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410b626:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410b62c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410b632:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    730a0410b63c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410b646:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a0410b650:	push   rdx
    730a0410b651:	push   rsi
    730a0410b652:	push   r10
    730a0410b654:	push   r11
    730a0410b656:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410b65b:	mov    r10d,edx
    730a0410b65e:	and    r10d,0xc000
    730a0410b665:	shl    r10d,0x10
    730a0410b669:	mov    r11d,edx
    730a0410b66c:	and    r11d,0x100
    730a0410b673:	shl    r11d,0x15
    730a0410b677:	or     r10d,r11d
    730a0410b67a:	and    edx,0x1
    730a0410b67d:	shl    edx,0x1c
    730a0410b680:	or     r10d,edx
    730a0410b683:	btc    r10,0x1d
    730a0410b688:	mov    r11d,0xf0000000
    730a0410b68e:	and    r11,r10
    730a0410b691:	movabs rsi,0xffffffff0fffffff
    730a0410b69b:	and    rbx,rsi
    730a0410b69e:	or     rbx,r11
    730a0410b6a1:	pop    r11
    730a0410b6a3:	pop    r10
    730a0410b6a5:	pop    rsi
    730a0410b6a6:	pop    rdx
    730a0410b6a7:	mov    QWORD PTR [r12+0x108],rbx
    730a0410b6af:	stmxcsr DWORD PTR [r12-0x28]
    730a0410b6b5:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410b6ba:	test   r10d,0x3f
    730a0410b6c1:	je     0x730a0410b6e6
    730a0410b6c7:	mov    r11d,r10d
    730a0410b6ca:	shr    r10d,1
    730a0410b6cd:	and    r10d,0x1e
    730a0410b6d1:	and    r11d,0x1
    730a0410b6d5:	or     r10d,r11d
    730a0410b6d8:	or     DWORD PTR [r12+0x314],r10d
    730a0410b6e0:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410b6e6:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410b6ec:	lea    rdi,[rsp+0x110]
    730a0410b6f4:	lea    rsi,[rsp+0xf0]
    730a0410b6fc:	lea    rdx,[rsp+0x100]
    730a0410b704:	mov    ecx,0x14
    730a0410b709:	mov    r8d,0x0
    730a0410b70f:	lea    r9,[r12+0x314]
    730a0410b717:	movabs r11,0x5591a9a93650
    730a0410b721:	call   r11
    730a0410b724:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410b72a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410b730:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410b736:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410b73c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    730a0410b746:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410b750:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410b75a:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410b762:	mov    QWORD PTR [r12+0x378],0x2
    730a0410b76e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410b777:	mov    rdx,rbx
    730a0410b77a:	shr    rdx,0x10
    730a0410b77e:	and    edx,0xc000
    730a0410b784:	mov    rax,rbx
    730a0410b787:	shr    rax,0x15
    730a0410b78b:	and    eax,0x100
    730a0410b790:	xor    eax,0x100
    730a0410b795:	or     edx,eax
    730a0410b797:	mov    rax,rbx
    730a0410b79a:	shr    rax,0x1c
    730a0410b79e:	and    eax,0x1
    730a0410b7a1:	or     edx,eax
    730a0410b7a3:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410b7a8:	add    rsp,0x8
    730a0410b7ac:	ret
    730a0410b7ad:	nop    DWORD PTR [rax]
    730a0410b7b0:	sub    rsp,0x8
    730a0410b7b4:	mov    QWORD PTR [r12+0x378],0x3
    730a0410b7c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410b7c6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410b7cc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    730a0410b7d2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    730a0410b7dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    730a0410b7e6:	push   rdx
    730a0410b7e7:	push   rsi
    730a0410b7e8:	push   r10
    730a0410b7ea:	push   r11
    730a0410b7ec:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410b7f1:	mov    r10d,edx
    730a0410b7f4:	and    r10d,0xc000
    730a0410b7fb:	shl    r10d,0x10
    730a0410b7ff:	mov    r11d,edx
    730a0410b802:	and    r11d,0x100
    730a0410b809:	shl    r11d,0x15
    730a0410b80d:	or     r10d,r11d
    730a0410b810:	and    edx,0x1
    730a0410b813:	shl    edx,0x1c
    730a0410b816:	or     r10d,edx
    730a0410b819:	btc    r10,0x1d
    730a0410b81e:	mov    r11d,0xf0000000
    730a0410b824:	and    r11,r10
    730a0410b827:	movabs rsi,0xffffffff0fffffff
    730a0410b831:	and    rbx,rsi
    730a0410b834:	or     rbx,r11
    730a0410b837:	pop    r11
    730a0410b839:	pop    r10
    730a0410b83b:	pop    rsi
    730a0410b83c:	pop    rdx
    730a0410b83d:	mov    QWORD PTR [r12+0x108],rbx
    730a0410b845:	stmxcsr DWORD PTR [r12-0x28]
    730a0410b84b:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410b850:	test   r10d,0x3f
    730a0410b857:	je     0x730a0410b87c
    730a0410b85d:	mov    r11d,r10d
    730a0410b860:	shr    r10d,1
    730a0410b863:	and    r10d,0x1e
    730a0410b867:	and    r11d,0x1
    730a0410b86b:	or     r10d,r11d
    730a0410b86e:	or     DWORD PTR [r12+0x314],r10d
    730a0410b876:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410b87c:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410b882:	lea    rdi,[rsp+0x110]
    730a0410b88a:	lea    rsi,[rsp+0xf0]
    730a0410b892:	lea    rdx,[rsp+0x100]
    730a0410b89a:	mov    ecx,0x14
    730a0410b89f:	mov    r8d,0x0
    730a0410b8a5:	lea    r9,[r12+0x314]
    730a0410b8ad:	movabs r11,0x5591a9a93650
    730a0410b8b7:	call   r11
    730a0410b8ba:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410b8c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410b8c6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410b8cc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    730a0410b8d2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    730a0410b8dc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    730a0410b8e6:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410b8ee:	mov    QWORD PTR [r12+0x378],0x2
    730a0410b8fa:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410b903:	mov    rdx,rbx
    730a0410b906:	shr    rdx,0x10
    730a0410b90a:	and    edx,0xc000
    730a0410b910:	mov    rax,rbx
    730a0410b913:	shr    rax,0x15
    730a0410b917:	and    eax,0x100
    730a0410b91c:	xor    eax,0x100
    730a0410b921:	or     edx,eax
    730a0410b923:	mov    rax,rbx
    730a0410b926:	shr    rax,0x1c
    730a0410b92a:	and    eax,0x1
    730a0410b92d:	or     edx,eax
    730a0410b92f:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410b934:	add    rsp,0x8
    730a0410b938:	ret
    730a0410b939:	nop    DWORD PTR [rax+0x0]
    730a0410b940:	sub    rsp,0x8
    730a0410b944:	mov    QWORD PTR [r12+0x378],0x3
    730a0410b950:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410b956:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    730a0410b95c:	push   rdx
    730a0410b95d:	push   rsi
    730a0410b95e:	push   r10
    730a0410b960:	push   r11
    730a0410b962:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410b967:	mov    r10d,edx
    730a0410b96a:	and    r10d,0xc000
    730a0410b971:	shl    r10d,0x10
    730a0410b975:	mov    r11d,edx
    730a0410b978:	and    r11d,0x100
    730a0410b97f:	shl    r11d,0x15
    730a0410b983:	or     r10d,r11d
    730a0410b986:	and    edx,0x1
    730a0410b989:	shl    edx,0x1c
    730a0410b98c:	or     r10d,edx
    730a0410b98f:	btc    r10,0x1d
    730a0410b994:	mov    r11d,0xf0000000
    730a0410b99a:	and    r11,r10
    730a0410b99d:	movabs rsi,0xffffffff0fffffff
    730a0410b9a7:	and    rbx,rsi
    730a0410b9aa:	or     rbx,r11
    730a0410b9ad:	pop    r11
    730a0410b9af:	pop    r10
    730a0410b9b1:	pop    rsi
    730a0410b9b2:	pop    rdx
    730a0410b9b3:	mov    QWORD PTR [r12+0x108],rbx
    730a0410b9bb:	stmxcsr DWORD PTR [r12-0x28]
    730a0410b9c1:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410b9c6:	test   r10d,0x3f
    730a0410b9cd:	je     0x730a0410b9f2
    730a0410b9d3:	mov    r11d,r10d
    730a0410b9d6:	shr    r10d,1
    730a0410b9d9:	and    r10d,0x1e
    730a0410b9dd:	and    r11d,0x1
    730a0410b9e1:	or     r10d,r11d
    730a0410b9e4:	or     DWORD PTR [r12+0x314],r10d
    730a0410b9ec:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410b9f2:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410b9f8:	lea    rdi,[rsp+0x110]
    730a0410ba00:	lea    rsi,[rsp+0xf0]
    730a0410ba08:	lea    rdx,[rsp+0x100]
    730a0410ba10:	mov    ecx,0xc
    730a0410ba15:	mov    r8d,0x0
    730a0410ba1b:	lea    r9,[r12+0x314]
    730a0410ba23:	movabs r11,0x5591a9a93650
    730a0410ba2d:	call   r11
    730a0410ba30:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410ba36:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410ba3c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    730a0410ba42:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410ba4a:	mov    QWORD PTR [r12+0x378],0x2
    730a0410ba56:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410ba5f:	mov    rdx,rbx
    730a0410ba62:	shr    rdx,0x10
    730a0410ba66:	and    edx,0xc000
    730a0410ba6c:	mov    rax,rbx
    730a0410ba6f:	shr    rax,0x15
    730a0410ba73:	and    eax,0x100
    730a0410ba78:	xor    eax,0x100
    730a0410ba7d:	or     edx,eax
    730a0410ba7f:	mov    rax,rbx
    730a0410ba82:	shr    rax,0x1c
    730a0410ba86:	and    eax,0x1
    730a0410ba89:	or     edx,eax
    730a0410ba8b:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410ba90:	add    rsp,0x8
    730a0410ba94:	ret
    730a0410ba95:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a0410baa0:	sub    rsp,0x8
    730a0410baa4:	mov    QWORD PTR [r12+0x378],0x3
    730a0410bab0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    730a0410bab6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    730a0410babc:	push   rdx
    730a0410babd:	push   rsi
    730a0410babe:	push   r10
    730a0410bac0:	push   r11
    730a0410bac2:	mov    rdx,QWORD PTR [rsp+0x30]
    730a0410bac7:	mov    r10d,edx
    730a0410baca:	and    r10d,0xc000
    730a0410bad1:	shl    r10d,0x10
    730a0410bad5:	mov    r11d,edx
    730a0410bad8:	and    r11d,0x100
    730a0410badf:	shl    r11d,0x15
    730a0410bae3:	or     r10d,r11d
    730a0410bae6:	and    edx,0x1
    730a0410bae9:	shl    edx,0x1c
    730a0410baec:	or     r10d,edx
    730a0410baef:	btc    r10,0x1d
    730a0410baf4:	mov    r11d,0xf0000000
    730a0410bafa:	and    r11,r10
    730a0410bafd:	movabs rsi,0xffffffff0fffffff
    730a0410bb07:	and    rbx,rsi
    730a0410bb0a:	or     rbx,r11
    730a0410bb0d:	pop    r11
    730a0410bb0f:	pop    r10
    730a0410bb11:	pop    rsi
    730a0410bb12:	pop    rdx
    730a0410bb13:	mov    QWORD PTR [r12+0x108],rbx
    730a0410bb1b:	stmxcsr DWORD PTR [r12-0x28]
    730a0410bb21:	mov    r10d,DWORD PTR [r12-0x28]
    730a0410bb26:	test   r10d,0x3f
    730a0410bb2d:	je     0x730a0410bb52
    730a0410bb33:	mov    r11d,r10d
    730a0410bb36:	shr    r10d,1
    730a0410bb39:	and    r10d,0x1e
    730a0410bb3d:	and    r11d,0x1
    730a0410bb41:	or     r10d,r11d
    730a0410bb44:	or     DWORD PTR [r12+0x314],r10d
    730a0410bb4c:	and    DWORD PTR [r12-0x28],0xffffffc0
    730a0410bb52:	ldmxcsr DWORD PTR [r12-0x38]
    730a0410bb58:	lea    rdi,[rsp+0x110]
    730a0410bb60:	lea    rsi,[rsp+0xf0]
    730a0410bb68:	lea    rdx,[rsp+0x100]
    730a0410bb70:	mov    ecx,0xc
    730a0410bb75:	mov    r8d,0x0
    730a0410bb7b:	lea    r9,[r12+0x314]
    730a0410bb83:	movabs r11,0x5591a9a93650
    730a0410bb8d:	call   r11
    730a0410bb90:	ldmxcsr DWORD PTR [r12-0x28]
    730a0410bb96:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    730a0410bb9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    730a0410bba2:	mov    rbx,QWORD PTR [r12+0x108]
    730a0410bbaa:	mov    QWORD PTR [r12+0x378],0x2
    730a0410bbb6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    730a0410bbbf:	mov    rdx,rbx
    730a0410bbc2:	shr    rdx,0x10
    730a0410bbc6:	and    edx,0xc000
    730a0410bbcc:	mov    rax,rbx
    730a0410bbcf:	shr    rax,0x15
    730a0410bbd3:	and    eax,0x100
    730a0410bbd8:	xor    eax,0x100
    730a0410bbdd:	or     edx,eax
    730a0410bbdf:	mov    rax,rbx
    730a0410bbe2:	shr    rax,0x1c
    730a0410bbe6:	and    eax,0x1
    730a0410bbe9:	or     edx,eax
    730a0410bbeb:	mov    QWORD PTR [rsp+0x10],rdx
    730a0410bbf0:	add    rsp,0x8
    730a0410bbf4:	ret
    730a0410bbf5:	mov    eax,0x410400
    730a0410bbfa:	mov    QWORD PTR [r12+0x100],rax
    730a0410bc02:	push   rdx
    730a0410bc03:	push   rsi
    730a0410bc04:	push   r10
    730a0410bc06:	push   r11
    730a0410bc08:	mov    r11,rax
    730a0410bc0b:	lahf
    730a0410bc0c:	seto   al
    730a0410bc0f:	mov    WORD PTR [rsp+0x20],ax
    730a0410bc14:	mov    rax,r11
    730a0410bc17:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410bc1c:	mov    r10d,edx
    730a0410bc1f:	and    r10d,0xc000
    730a0410bc26:	shl    r10d,0x10
    730a0410bc2a:	mov    r11d,edx
    730a0410bc2d:	and    r11d,0x100
    730a0410bc34:	shl    r11d,0x15
    730a0410bc38:	or     r10d,r11d
    730a0410bc3b:	and    edx,0x1
    730a0410bc3e:	shl    edx,0x1c
    730a0410bc41:	or     r10d,edx
    730a0410bc44:	btc    r10,0x1d
    730a0410bc49:	mov    r11d,0xf0000000
    730a0410bc4f:	and    r11,r10
    730a0410bc52:	movabs rsi,0xffffffff0fffffff
    730a0410bc5c:	and    rbx,rsi
    730a0410bc5f:	or     rbx,r11
    730a0410bc62:	pop    r11
    730a0410bc64:	pop    r10
    730a0410bc66:	pop    rsi
    730a0410bc67:	pop    rdx
    730a0410bc68:	mov    QWORD PTR [r12+0x108],rbx
    730a0410bc70:	add    rsp,0x150
    730a0410bc77:	mov    eax,0xc
    730a0410bc7c:	movabs r11,0x5591a9c2cca0
    730a0410bc86:	jmp    r11
    730a0410bc89:	mov    eax,0x41048c
    730a0410bc8e:	mov    QWORD PTR [r12+0x100],rax
    730a0410bc96:	push   rdx
    730a0410bc97:	push   rsi
    730a0410bc98:	push   r10
    730a0410bc9a:	push   r11
    730a0410bc9c:	mov    r11,rax
    730a0410bc9f:	lahf
    730a0410bca0:	seto   al
    730a0410bca3:	mov    WORD PTR [rsp+0x20],ax
    730a0410bca8:	mov    rax,r11
    730a0410bcab:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410bcb0:	mov    r10d,edx
    730a0410bcb3:	and    r10d,0xc000
    730a0410bcba:	shl    r10d,0x10
    730a0410bcbe:	mov    r11d,edx
    730a0410bcc1:	and    r11d,0x100
    730a0410bcc8:	shl    r11d,0x15
    730a0410bccc:	or     r10d,r11d
    730a0410bccf:	and    edx,0x1
    730a0410bcd2:	shl    edx,0x1c
    730a0410bcd5:	or     r10d,edx
    730a0410bcd8:	btc    r10,0x1d
    730a0410bcdd:	mov    r11d,0xf0000000
    730a0410bce3:	and    r11,r10
    730a0410bce6:	movabs rsi,0xffffffff0fffffff
    730a0410bcf0:	and    rbx,rsi
    730a0410bcf3:	or     rbx,r11
    730a0410bcf6:	pop    r11
    730a0410bcf8:	pop    r10
    730a0410bcfa:	pop    rsi
    730a0410bcfb:	pop    rdx
    730a0410bcfc:	mov    QWORD PTR [r12+0x108],rbx
    730a0410bd04:	add    rsp,0x150
    730a0410bd0b:	mov    eax,0xc
    730a0410bd10:	movabs r11,0x5591a9c2cca0
    730a0410bd1a:	jmp    r11
    730a0410bd1d:	mov    eax,0x4106cc
    730a0410bd22:	mov    QWORD PTR [r12+0x100],rax
    730a0410bd2a:	push   rdx
    730a0410bd2b:	push   rsi
    730a0410bd2c:	push   r10
    730a0410bd2e:	push   r11
    730a0410bd30:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410bd35:	mov    r10d,edx
    730a0410bd38:	and    r10d,0xc000
    730a0410bd3f:	shl    r10d,0x10
    730a0410bd43:	mov    r11d,edx
    730a0410bd46:	and    r11d,0x100
    730a0410bd4d:	shl    r11d,0x15
    730a0410bd51:	or     r10d,r11d
    730a0410bd54:	and    edx,0x1
    730a0410bd57:	shl    edx,0x1c
    730a0410bd5a:	or     r10d,edx
    730a0410bd5d:	btc    r10,0x1d
    730a0410bd62:	mov    r11d,0xf0000000
    730a0410bd68:	and    r11,r10
    730a0410bd6b:	movabs rsi,0xffffffff0fffffff
    730a0410bd75:	and    rbx,rsi
    730a0410bd78:	or     rbx,r11
    730a0410bd7b:	pop    r11
    730a0410bd7d:	pop    r10
    730a0410bd7f:	pop    rsi
    730a0410bd80:	pop    rdx
    730a0410bd81:	mov    QWORD PTR [r12+0x108],rbx
    730a0410bd89:	add    rsp,0x150
    730a0410bd90:	mov    eax,0xc
    730a0410bd95:	movabs r11,0x5591a9c2cca0
    730a0410bd9f:	jmp    r11
    730a0410bda2:	mov    eax,0x4106d8
    730a0410bda7:	mov    QWORD PTR [r12+0x100],rax
    730a0410bdaf:	push   rdx
    730a0410bdb0:	push   rsi
    730a0410bdb1:	push   r10
    730a0410bdb3:	push   r11
    730a0410bdb5:	mov    r11,rax
    730a0410bdb8:	lahf
    730a0410bdb9:	seto   al
    730a0410bdbc:	mov    WORD PTR [rsp+0x20],ax
    730a0410bdc1:	mov    rax,r11
    730a0410bdc4:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410bdc9:	mov    r10d,edx
    730a0410bdcc:	and    r10d,0xc000
    730a0410bdd3:	shl    r10d,0x10
    730a0410bdd7:	mov    r11d,edx
    730a0410bdda:	and    r11d,0x100
    730a0410bde1:	shl    r11d,0x15
    730a0410bde5:	or     r10d,r11d
    730a0410bde8:	and    edx,0x1
    730a0410bdeb:	shl    edx,0x1c
    730a0410bdee:	or     r10d,edx
    730a0410bdf1:	btc    r10,0x1d
    730a0410bdf6:	mov    r11d,0xf0000000
    730a0410bdfc:	and    r11,r10
    730a0410bdff:	movabs rsi,0xffffffff0fffffff
    730a0410be09:	and    rbx,rsi
    730a0410be0c:	or     rbx,r11
    730a0410be0f:	pop    r11
    730a0410be11:	pop    r10
    730a0410be13:	pop    rsi
    730a0410be14:	pop    rdx
    730a0410be15:	mov    QWORD PTR [r12+0x108],rbx
    730a0410be1d:	add    rsp,0x150
    730a0410be24:	mov    eax,0xc
    730a0410be29:	movabs r11,0x5591a9c2cca0
    730a0410be33:	jmp    r11
    730a0410be36:	mov    eax,0x410700
    730a0410be3b:	mov    QWORD PTR [r12+0x100],rax
    730a0410be43:	push   rdx
    730a0410be44:	push   rsi
    730a0410be45:	push   r10
    730a0410be47:	push   r11
    730a0410be49:	mov    r11,rax
    730a0410be4c:	lahf
    730a0410be4d:	seto   al
    730a0410be50:	mov    WORD PTR [rsp+0x20],ax
    730a0410be55:	mov    rax,r11
    730a0410be58:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410be5d:	mov    r10d,edx
    730a0410be60:	and    r10d,0xc000
    730a0410be67:	shl    r10d,0x10
    730a0410be6b:	mov    r11d,edx
    730a0410be6e:	and    r11d,0x100
    730a0410be75:	shl    r11d,0x15
    730a0410be79:	or     r10d,r11d
    730a0410be7c:	and    edx,0x1
    730a0410be7f:	shl    edx,0x1c
    730a0410be82:	or     r10d,edx
    730a0410be85:	btc    r10,0x1d
    730a0410be8a:	mov    r11d,0xf0000000
    730a0410be90:	and    r11,r10
    730a0410be93:	movabs rsi,0xffffffff0fffffff
    730a0410be9d:	and    rbx,rsi
    730a0410bea0:	or     rbx,r11
    730a0410bea3:	pop    r11
    730a0410bea5:	pop    r10
    730a0410bea7:	pop    rsi
    730a0410bea8:	pop    rdx
    730a0410bea9:	mov    QWORD PTR [r12+0x108],rbx
    730a0410beb1:	add    rsp,0x150
    730a0410beb8:	mov    eax,0xc
    730a0410bebd:	movabs r11,0x5591a9c2cca0
    730a0410bec7:	jmp    r11
    730a0410beca:	mov    eax,0x410724
    730a0410becf:	mov    QWORD PTR [r12+0x100],rax
    730a0410bed7:	push   rdx
    730a0410bed8:	push   rsi
    730a0410bed9:	push   r10
    730a0410bedb:	push   r11
    730a0410bedd:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410bee2:	mov    r10d,edx
    730a0410bee5:	and    r10d,0xc000
    730a0410beec:	shl    r10d,0x10
    730a0410bef0:	mov    r11d,edx
    730a0410bef3:	and    r11d,0x100
    730a0410befa:	shl    r11d,0x15
    730a0410befe:	or     r10d,r11d
    730a0410bf01:	and    edx,0x1
    730a0410bf04:	shl    edx,0x1c
    730a0410bf07:	or     r10d,edx
    730a0410bf0a:	btc    r10,0x1d
    730a0410bf0f:	mov    r11d,0xf0000000
    730a0410bf15:	and    r11,r10
    730a0410bf18:	movabs rsi,0xffffffff0fffffff
    730a0410bf22:	and    rbx,rsi
    730a0410bf25:	or     rbx,r11
    730a0410bf28:	pop    r11
    730a0410bf2a:	pop    r10
    730a0410bf2c:	pop    rsi
    730a0410bf2d:	pop    rdx
    730a0410bf2e:	mov    QWORD PTR [r12+0x108],rbx
    730a0410bf36:	add    rsp,0x150
    730a0410bf3d:	mov    eax,0xc
    730a0410bf42:	movabs r11,0x5591a9c2cca0
    730a0410bf4c:	jmp    r11
    730a0410bf4f:	nop
    730a0410bf50:	sub    rsp,0x150
    730a0410bf57:	mov    r11,QWORD PTR [r12+0x398]
    730a0410bf5f:	mov    QWORD PTR [rsp],r11
    730a0410bf63:	cmp    DWORD PTR [r12+0x310],0x0
    730a0410bf6c:	je     0x730a0410bff7
    730a0410bf72:	push   rdx
    730a0410bf73:	push   rsi
    730a0410bf74:	push   r10
    730a0410bf76:	push   r11
    730a0410bf78:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410bf7d:	mov    r10d,edx
    730a0410bf80:	and    r10d,0xc000
    730a0410bf87:	shl    r10d,0x10
    730a0410bf8b:	mov    r11d,edx
    730a0410bf8e:	and    r11d,0x100
    730a0410bf95:	shl    r11d,0x15
    730a0410bf99:	or     r10d,r11d
    730a0410bf9c:	and    edx,0x1
    730a0410bf9f:	shl    edx,0x1c
    730a0410bfa2:	or     r10d,edx
    730a0410bfa5:	btc    r10,0x1d
    730a0410bfaa:	mov    r11d,0xf0000000
    730a0410bfb0:	and    r11,r10
    730a0410bfb3:	movabs rsi,0xffffffff0fffffff
    730a0410bfbd:	and    rbx,rsi
    730a0410bfc0:	or     rbx,r11
    730a0410bfc3:	pop    r11
    730a0410bfc5:	pop    r10
    730a0410bfc7:	pop    rsi
    730a0410bfc8:	pop    rdx
    730a0410bfc9:	mov    QWORD PTR [r12+0x108],rbx
    730a0410bfd1:	mov    eax,0x410404
    730a0410bfd6:	mov    QWORD PTR [r12+0x100],rax
    730a0410bfde:	add    rsp,0x150
    730a0410bfe5:	mov    eax,0x3
    730a0410bfea:	movabs r11,0x5591a9c2cca0
    730a0410bff4:	jmp    r11
    730a0410bff7:	jmp    0x730a0410226d
    730a0410bffc:	nop    DWORD PTR [rax+0x0]
    730a0410c000:	sub    rsp,0x150
    730a0410c007:	mov    r11,QWORD PTR [r12+0x398]
    730a0410c00f:	mov    QWORD PTR [rsp],r11
    730a0410c013:	cmp    DWORD PTR [r12+0x310],0x0
    730a0410c01c:	je     0x730a0410c0a7
    730a0410c022:	push   rdx
    730a0410c023:	push   rsi
    730a0410c024:	push   r10
    730a0410c026:	push   r11
    730a0410c028:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410c02d:	mov    r10d,edx
    730a0410c030:	and    r10d,0xc000
    730a0410c037:	shl    r10d,0x10
    730a0410c03b:	mov    r11d,edx
    730a0410c03e:	and    r11d,0x100
    730a0410c045:	shl    r11d,0x15
    730a0410c049:	or     r10d,r11d
    730a0410c04c:	and    edx,0x1
    730a0410c04f:	shl    edx,0x1c
    730a0410c052:	or     r10d,edx
    730a0410c055:	btc    r10,0x1d
    730a0410c05a:	mov    r11d,0xf0000000
    730a0410c060:	and    r11,r10
    730a0410c063:	movabs rsi,0xffffffff0fffffff
    730a0410c06d:	and    rbx,rsi
    730a0410c070:	or     rbx,r11
    730a0410c073:	pop    r11
    730a0410c075:	pop    r10
    730a0410c077:	pop    rsi
    730a0410c078:	pop    rdx
    730a0410c079:	mov    QWORD PTR [r12+0x108],rbx
    730a0410c081:	mov    eax,0x410450
    730a0410c086:	mov    QWORD PTR [r12+0x100],rax
    730a0410c08e:	add    rsp,0x150
    730a0410c095:	mov    eax,0x3
    730a0410c09a:	movabs r11,0x5591a9c2cca0
    730a0410c0a4:	jmp    r11
    730a0410c0a7:	mov    r11,rax
    730a0410c0aa:	movzx  eax,WORD PTR [rsp]
    730a0410c0ae:	add    al,0x7f
    730a0410c0b0:	sahf
    730a0410c0b1:	mov    rax,r11
    730a0410c0b4:	jmp    0x730a041023dd
    730a0410c0b9:	nop    DWORD PTR [rax+0x0]
    730a0410c0c0:	sub    rsp,0x150
    730a0410c0c7:	mov    r11,QWORD PTR [r12+0x398]
    730a0410c0cf:	mov    QWORD PTR [rsp],r11
    730a0410c0d3:	cmp    DWORD PTR [r12+0x310],0x0
    730a0410c0dc:	je     0x730a0410c167
    730a0410c0e2:	push   rdx
    730a0410c0e3:	push   rsi
    730a0410c0e4:	push   r10
    730a0410c0e6:	push   r11
    730a0410c0e8:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410c0ed:	mov    r10d,edx
    730a0410c0f0:	and    r10d,0xc000
    730a0410c0f7:	shl    r10d,0x10
    730a0410c0fb:	mov    r11d,edx
    730a0410c0fe:	and    r11d,0x100
    730a0410c105:	shl    r11d,0x15
    730a0410c109:	or     r10d,r11d
    730a0410c10c:	and    edx,0x1
    730a0410c10f:	shl    edx,0x1c
    730a0410c112:	or     r10d,edx
    730a0410c115:	btc    r10,0x1d
    730a0410c11a:	mov    r11d,0xf0000000
    730a0410c120:	and    r11,r10
    730a0410c123:	movabs rsi,0xffffffff0fffffff
    730a0410c12d:	and    rbx,rsi
    730a0410c130:	or     rbx,r11
    730a0410c133:	pop    r11
    730a0410c135:	pop    r10
    730a0410c137:	pop    rsi
    730a0410c138:	pop    rdx
    730a0410c139:	mov    QWORD PTR [r12+0x108],rbx
    730a0410c141:	mov    eax,0x410490
    730a0410c146:	mov    QWORD PTR [r12+0x100],rax
    730a0410c14e:	add    rsp,0x150
    730a0410c155:	mov    eax,0x3
    730a0410c15a:	movabs r11,0x5591a9c2cca0
    730a0410c164:	jmp    r11
    730a0410c167:	jmp    0x730a0410282b
    730a0410c16c:	nop    DWORD PTR [rax+0x0]
    730a0410c170:	sub    rsp,0x150
    730a0410c177:	mov    r11,QWORD PTR [r12+0x398]
    730a0410c17f:	mov    QWORD PTR [rsp],r11
    730a0410c183:	cmp    DWORD PTR [r12+0x310],0x0
    730a0410c18c:	je     0x730a0410c217
    730a0410c192:	push   rdx
    730a0410c193:	push   rsi
    730a0410c194:	push   r10
    730a0410c196:	push   r11
    730a0410c198:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410c19d:	mov    r10d,edx
    730a0410c1a0:	and    r10d,0xc000
    730a0410c1a7:	shl    r10d,0x10
    730a0410c1ab:	mov    r11d,edx
    730a0410c1ae:	and    r11d,0x100
    730a0410c1b5:	shl    r11d,0x15
    730a0410c1b9:	or     r10d,r11d
    730a0410c1bc:	and    edx,0x1
    730a0410c1bf:	shl    edx,0x1c
    730a0410c1c2:	or     r10d,edx
    730a0410c1c5:	btc    r10,0x1d
    730a0410c1ca:	mov    r11d,0xf0000000
    730a0410c1d0:	and    r11,r10
    730a0410c1d3:	movabs rsi,0xffffffff0fffffff
    730a0410c1dd:	and    rbx,rsi
    730a0410c1e0:	or     rbx,r11
    730a0410c1e3:	pop    r11
    730a0410c1e5:	pop    r10
    730a0410c1e7:	pop    rsi
    730a0410c1e8:	pop    rdx
    730a0410c1e9:	mov    QWORD PTR [r12+0x108],rbx
    730a0410c1f1:	mov    eax,0x410500
    730a0410c1f6:	mov    QWORD PTR [r12+0x100],rax
    730a0410c1fe:	add    rsp,0x150
    730a0410c205:	mov    eax,0x3
    730a0410c20a:	movabs r11,0x5591a9c2cca0
    730a0410c214:	jmp    r11
    730a0410c217:	mov    r11,rax
    730a0410c21a:	movzx  eax,WORD PTR [rsp]
    730a0410c21e:	add    al,0x7f
    730a0410c220:	sahf
    730a0410c221:	mov    rax,r11
    730a0410c224:	jmp    0x730a04102c37
    730a0410c229:	nop    DWORD PTR [rax+0x0]
    730a0410c230:	sub    rsp,0x150
    730a0410c237:	mov    r11,QWORD PTR [r12+0x398]
    730a0410c23f:	mov    QWORD PTR [rsp],r11
    730a0410c243:	cmp    DWORD PTR [r12+0x310],0x0
    730a0410c24c:	je     0x730a0410c2d7
    730a0410c252:	push   rdx
    730a0410c253:	push   rsi
    730a0410c254:	push   r10
    730a0410c256:	push   r11
    730a0410c258:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410c25d:	mov    r10d,edx
    730a0410c260:	and    r10d,0xc000
    730a0410c267:	shl    r10d,0x10
    730a0410c26b:	mov    r11d,edx
    730a0410c26e:	and    r11d,0x100
    730a0410c275:	shl    r11d,0x15
    730a0410c279:	or     r10d,r11d
    730a0410c27c:	and    edx,0x1
    730a0410c27f:	shl    edx,0x1c
    730a0410c282:	or     r10d,edx
    730a0410c285:	btc    r10,0x1d
    730a0410c28a:	mov    r11d,0xf0000000
    730a0410c290:	and    r11,r10
    730a0410c293:	movabs rsi,0xffffffff0fffffff
    730a0410c29d:	and    rbx,rsi
    730a0410c2a0:	or     rbx,r11
    730a0410c2a3:	pop    r11
    730a0410c2a5:	pop    r10
    730a0410c2a7:	pop    rsi
    730a0410c2a8:	pop    rdx
    730a0410c2a9:	mov    QWORD PTR [r12+0x108],rbx
    730a0410c2b1:	mov    eax,0x410504
    730a0410c2b6:	mov    QWORD PTR [r12+0x100],rax
    730a0410c2be:	add    rsp,0x150
    730a0410c2c5:	mov    eax,0x3
    730a0410c2ca:	movabs r11,0x5591a9c2cca0
    730a0410c2d4:	jmp    r11
    730a0410c2d7:	jmp    0x730a04102c55
    730a0410c2dc:	nop    DWORD PTR [rax+0x0]
    730a0410c2e0:	sub    rsp,0x150
    730a0410c2e7:	mov    r11,QWORD PTR [r12+0x398]
    730a0410c2ef:	mov    QWORD PTR [rsp],r11
    730a0410c2f3:	cmp    DWORD PTR [r12+0x310],0x0
    730a0410c2fc:	je     0x730a0410c387
    730a0410c302:	push   rdx
    730a0410c303:	push   rsi
    730a0410c304:	push   r10
    730a0410c306:	push   r11
    730a0410c308:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410c30d:	mov    r10d,edx
    730a0410c310:	and    r10d,0xc000
    730a0410c317:	shl    r10d,0x10
    730a0410c31b:	mov    r11d,edx
    730a0410c31e:	and    r11d,0x100
    730a0410c325:	shl    r11d,0x15
    730a0410c329:	or     r10d,r11d
    730a0410c32c:	and    edx,0x1
    730a0410c32f:	shl    edx,0x1c
    730a0410c332:	or     r10d,edx
    730a0410c335:	btc    r10,0x1d
    730a0410c33a:	mov    r11d,0xf0000000
    730a0410c340:	and    r11,r10
    730a0410c343:	movabs rsi,0xffffffff0fffffff
    730a0410c34d:	and    rbx,rsi
    730a0410c350:	or     rbx,r11
    730a0410c353:	pop    r11
    730a0410c355:	pop    r10
    730a0410c357:	pop    rsi
    730a0410c358:	pop    rdx
    730a0410c359:	mov    QWORD PTR [r12+0x108],rbx
    730a0410c361:	mov    eax,0x4106d0
    730a0410c366:	mov    QWORD PTR [r12+0x100],rax
    730a0410c36e:	add    rsp,0x150
    730a0410c375:	mov    eax,0x3
    730a0410c37a:	movabs r11,0x5591a9c2cca0
    730a0410c384:	jmp    r11
    730a0410c387:	jmp    0x730a04104995
    730a0410c38c:	nop    DWORD PTR [rax+0x0]
    730a0410c390:	sub    rsp,0x150
    730a0410c397:	mov    r11,QWORD PTR [r12+0x398]
    730a0410c39f:	mov    QWORD PTR [rsp],r11
    730a0410c3a3:	cmp    DWORD PTR [r12+0x310],0x0
    730a0410c3ac:	je     0x730a0410c437
    730a0410c3b2:	push   rdx
    730a0410c3b3:	push   rsi
    730a0410c3b4:	push   r10
    730a0410c3b6:	push   r11
    730a0410c3b8:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410c3bd:	mov    r10d,edx
    730a0410c3c0:	and    r10d,0xc000
    730a0410c3c7:	shl    r10d,0x10
    730a0410c3cb:	mov    r11d,edx
    730a0410c3ce:	and    r11d,0x100
    730a0410c3d5:	shl    r11d,0x15
    730a0410c3d9:	or     r10d,r11d
    730a0410c3dc:	and    edx,0x1
    730a0410c3df:	shl    edx,0x1c
    730a0410c3e2:	or     r10d,edx
    730a0410c3e5:	btc    r10,0x1d
    730a0410c3ea:	mov    r11d,0xf0000000
    730a0410c3f0:	and    r11,r10
    730a0410c3f3:	movabs rsi,0xffffffff0fffffff
    730a0410c3fd:	and    rbx,rsi
    730a0410c400:	or     rbx,r11
    730a0410c403:	pop    r11
    730a0410c405:	pop    r10
    730a0410c407:	pop    rsi
    730a0410c408:	pop    rdx
    730a0410c409:	mov    QWORD PTR [r12+0x108],rbx
    730a0410c411:	mov    eax,0x4106dc
    730a0410c416:	mov    QWORD PTR [r12+0x100],rax
    730a0410c41e:	add    rsp,0x150
    730a0410c425:	mov    eax,0x3
    730a0410c42a:	movabs r11,0x5591a9c2cca0
    730a0410c434:	jmp    r11
    730a0410c437:	jmp    0x730a041049d2
    730a0410c43c:	nop    DWORD PTR [rax+0x0]
    730a0410c440:	sub    rsp,0x150
    730a0410c447:	mov    r11,QWORD PTR [r12+0x398]
    730a0410c44f:	mov    QWORD PTR [rsp],r11
    730a0410c453:	cmp    DWORD PTR [r12+0x310],0x0
    730a0410c45c:	je     0x730a0410c4e7
    730a0410c462:	push   rdx
    730a0410c463:	push   rsi
    730a0410c464:	push   r10
    730a0410c466:	push   r11
    730a0410c468:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410c46d:	mov    r10d,edx
    730a0410c470:	and    r10d,0xc000
    730a0410c477:	shl    r10d,0x10
    730a0410c47b:	mov    r11d,edx
    730a0410c47e:	and    r11d,0x100
    730a0410c485:	shl    r11d,0x15
    730a0410c489:	or     r10d,r11d
    730a0410c48c:	and    edx,0x1
    730a0410c48f:	shl    edx,0x1c
    730a0410c492:	or     r10d,edx
    730a0410c495:	btc    r10,0x1d
    730a0410c49a:	mov    r11d,0xf0000000
    730a0410c4a0:	and    r11,r10
    730a0410c4a3:	movabs rsi,0xffffffff0fffffff
    730a0410c4ad:	and    rbx,rsi
    730a0410c4b0:	or     rbx,r11
    730a0410c4b3:	pop    r11
    730a0410c4b5:	pop    r10
    730a0410c4b7:	pop    rsi
    730a0410c4b8:	pop    rdx
    730a0410c4b9:	mov    QWORD PTR [r12+0x108],rbx
    730a0410c4c1:	mov    eax,0x4106e8
    730a0410c4c6:	mov    QWORD PTR [r12+0x100],rax
    730a0410c4ce:	add    rsp,0x150
    730a0410c4d5:	mov    eax,0x3
    730a0410c4da:	movabs r11,0x5591a9c2cca0
    730a0410c4e4:	jmp    r11
    730a0410c4e7:	jmp    0x730a04104a0d
    730a0410c4ec:	nop    DWORD PTR [rax+0x0]
    730a0410c4f0:	sub    rsp,0x150
    730a0410c4f7:	mov    r11,QWORD PTR [r12+0x398]
    730a0410c4ff:	mov    QWORD PTR [rsp],r11
    730a0410c503:	cmp    DWORD PTR [r12+0x310],0x0
    730a0410c50c:	je     0x730a0410c597
    730a0410c512:	push   rdx
    730a0410c513:	push   rsi
    730a0410c514:	push   r10
    730a0410c516:	push   r11
    730a0410c518:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410c51d:	mov    r10d,edx
    730a0410c520:	and    r10d,0xc000
    730a0410c527:	shl    r10d,0x10
    730a0410c52b:	mov    r11d,edx
    730a0410c52e:	and    r11d,0x100
    730a0410c535:	shl    r11d,0x15
    730a0410c539:	or     r10d,r11d
    730a0410c53c:	and    edx,0x1
    730a0410c53f:	shl    edx,0x1c
    730a0410c542:	or     r10d,edx
    730a0410c545:	btc    r10,0x1d
    730a0410c54a:	mov    r11d,0xf0000000
    730a0410c550:	and    r11,r10
    730a0410c553:	movabs rsi,0xffffffff0fffffff
    730a0410c55d:	and    rbx,rsi
    730a0410c560:	or     rbx,r11
    730a0410c563:	pop    r11
    730a0410c565:	pop    r10
    730a0410c567:	pop    rsi
    730a0410c568:	pop    rdx
    730a0410c569:	mov    QWORD PTR [r12+0x108],rbx
    730a0410c571:	mov    eax,0x410704
    730a0410c576:	mov    QWORD PTR [r12+0x100],rax
    730a0410c57e:	add    rsp,0x150
    730a0410c585:	mov    eax,0x3
    730a0410c58a:	movabs r11,0x5591a9c2cca0
    730a0410c594:	jmp    r11
    730a0410c597:	jmp    0x730a04104b66
    730a0410c59c:	nop    DWORD PTR [rax+0x0]
    730a0410c5a0:	sub    rsp,0x150
    730a0410c5a7:	mov    r11,QWORD PTR [r12+0x398]
    730a0410c5af:	mov    QWORD PTR [rsp],r11
    730a0410c5b3:	cmp    DWORD PTR [r12+0x310],0x0
    730a0410c5bc:	je     0x730a0410c647
    730a0410c5c2:	push   rdx
    730a0410c5c3:	push   rsi
    730a0410c5c4:	push   r10
    730a0410c5c6:	push   r11
    730a0410c5c8:	mov    rdx,QWORD PTR [rsp+0x20]
    730a0410c5cd:	mov    r10d,edx
    730a0410c5d0:	and    r10d,0xc000
    730a0410c5d7:	shl    r10d,0x10
    730a0410c5db:	mov    r11d,edx
    730a0410c5de:	and    r11d,0x100
    730a0410c5e5:	shl    r11d,0x15
    730a0410c5e9:	or     r10d,r11d
    730a0410c5ec:	and    edx,0x1
    730a0410c5ef:	shl    edx,0x1c
    730a0410c5f2:	or     r10d,edx
    730a0410c5f5:	btc    r10,0x1d
    730a0410c5fa:	mov    r11d,0xf0000000
    730a0410c600:	and    r11,r10
    730a0410c603:	movabs rsi,0xffffffff0fffffff
    730a0410c60d:	and    rbx,rsi
    730a0410c610:	or     rbx,r11
    730a0410c613:	pop    r11
    730a0410c615:	pop    r10
    730a0410c617:	pop    rsi
    730a0410c618:	pop    rdx
    730a0410c619:	mov    QWORD PTR [r12+0x108],rbx
    730a0410c621:	mov    eax,0x4103f0
    730a0410c626:	mov    QWORD PTR [r12+0x100],rax
    730a0410c62e:	add    rsp,0x150
    730a0410c635:	mov    eax,0x3
    730a0410c63a:	movabs r11,0x5591a9c2cca0
    730a0410c644:	jmp    r11
    730a0410c647:	jmp    0x730a04104d43
    730a0410c64c:	nop    DWORD PTR [rax+0x0]
    730a0410c650:	(bad)
    730a0410c651:	(bad)
    730a0410c652:	(bad)
    730a0410c653:	(bad)
    730a0410c654:	(bad)
    730a0410c655:	(bad)
    730a0410c656:	(bad)
    730a0410c657:	jg     0x730a0410c658
    730a0410c659:	(bad)
    730a0410c65a:	(bad)
    730a0410c65b:	(bad)
    730a0410c65c:	(bad)
    730a0410c65d:	(bad)
    730a0410c65e:	(bad)
    730a0410c65f:	jg     0x730a0410c661
    730a0410c661:	add    BYTE PTR [rax],al
    730a0410c663:	add    BYTE PTR [rax],al
    730a0410c665:	add    BYTE PTR [rax],dl
    730a0410c667:	add    BYTE PTR [rax],al
    730a0410c669:	add    BYTE PTR [rax],al
    730a0410c66b:	add    BYTE PTR [rax],al
    730a0410c66d:	add    BYTE PTR [rax],dl
	...
