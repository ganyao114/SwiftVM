
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

0000730a040fe000 <.data>:
    730a040fe000:	sub    rsp,0x10
    730a040fe004:	mov    r11,QWORD PTR [r12+0x398]
    730a040fe00c:	mov    QWORD PTR [rsp],r11
    730a040fe010:	mov    r13,QWORD PTR [r12+0xf8]
    730a040fe018:	sub    r13,0x1e0
    730a040fe01f:	mov    QWORD PTR [r12+0xf8],r13
    730a040fe027:	mov    r14d,0x420000
    730a040fe02d:	mov    QWORD PTR [r12+0x40],r14
    730a040fe032:	mov    r14d,0x420000
    730a040fe038:	mov    QWORD PTR [r12+0x48],r14
    730a040fe03d:	mov    r14,r13
    730a040fe040:	add    r14,0x1d0
    730a040fe047:	mov    r15,r14
    730a040fe04a:	add    r15,0x8
    730a040fe04e:	mov    rbp,QWORD PTR [r12+0xa0]
    730a040fe056:	mov    r8,QWORD PTR [r12+0x98]
    730a040fe05e:	mov    QWORD PTR [r14],rbp
    730a040fe061:	mov    r14d,0x0
    730a040fe067:	mov    DWORD PTR [r12+0x32c],r14d
    730a040fe06f:	mov    QWORD PTR [r15],r8
    730a040fe072:	mov    r14d,0x420aa0
    730a040fe078:	movdqu xmm2,XMMWORD PTR [r14]
    730a040fe07d:	movdqu XMMWORD PTR [r12+0x110],xmm2
    730a040fe087:	mov    r14d,0x420a30
    730a040fe08d:	movdqu xmm3,XMMWORD PTR [r14]
    730a040fe092:	movdqu XMMWORD PTR [r12+0x120],xmm3
    730a040fe09c:	mov    r14d,0x420ac0
    730a040fe0a2:	movdqu xmm4,XMMWORD PTR [r14]
    730a040fe0a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
    730a040fe0b1:	mov    r14d,0x420a60
    730a040fe0b7:	movdqu xmm5,XMMWORD PTR [r14]
    730a040fe0bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
    730a040fe0c6:	mov    r14d,0x430000
    730a040fe0cc:	mov    rax,r14
    730a040fe0cf:	add    rax,0xcd0
    730a040fe0d5:	mov    QWORD PTR [r12+0x98],rax
    730a040fe0dd:	mov    r15d,0x420ad0
    730a040fe0e3:	movdqu xmm6,XMMWORD PTR [r15]
    730a040fe0e8:	movdqu XMMWORD PTR [r12+0x150],xmm6
    730a040fe0f2:	mov    r15,QWORD PTR [r12+0x98]
    730a040fe0fa:	add    r15,0x10
    730a040fe0fe:	mov    rdi,QWORD PTR [r12+0x98]
    730a040fe106:	movdqu XMMWORD PTR [rdi],xmm2
    730a040fe10a:	movdqu XMMWORD PTR [r15],xmm3
    730a040fe10f:	mov    r15,QWORD PTR [r12+0x98]
    730a040fe117:	add    r15,0x20
    730a040fe11b:	mov    rbp,r15
    730a040fe11e:	add    rbp,0x10
    730a040fe122:	movdqu XMMWORD PTR [r15],xmm4
    730a040fe127:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    730a040fe12c:	mov    r15d,0x420a20
    730a040fe132:	movdqu xmm4,XMMWORD PTR [r15]
    730a040fe137:	movdqu XMMWORD PTR [r12+0x130],xmm4
    730a040fe141:	mov    r15d,0x420a10
    730a040fe147:	movdqu xmm5,XMMWORD PTR [r15]
    730a040fe14c:	movdqu XMMWORD PTR [r12+0x140],xmm5
    730a040fe156:	mov    r15,QWORD PTR [r12+0x98]
    730a040fe15e:	add    r15,0x100
    730a040fe165:	mov    rbp,r15
    730a040fe168:	add    rbp,0x10
    730a040fe16c:	movdqu XMMWORD PTR [r15],xmm2
    730a040fe171:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    730a040fe176:	mov    r15,QWORD PTR [r12+0x98]
    730a040fe17e:	add    r15,0x40
    730a040fe182:	mov    rbp,r15
    730a040fe185:	add    rbp,0x10
    730a040fe189:	movdqu XMMWORD PTR [r15],xmm6
    730a040fe18e:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    730a040fe193:	mov    r15d,0x420a00
    730a040fe199:	movdqu xmm2,XMMWORD PTR [r15]
    730a040fe19e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    730a040fe1a8:	mov    r15d,0x420a70
    730a040fe1ae:	movdqu xmm3,XMMWORD PTR [r15]
    730a040fe1b3:	movdqu XMMWORD PTR [r12+0x150],xmm3
    730a040fe1bd:	mov    r15d,0xf8d3
    730a040fe1c3:	mov    QWORD PTR [r12+0x48],r15
    730a040fe1c8:	mov    r15,QWORD PTR [r12+0x98]
    730a040fe1d0:	add    r15,0x60
    730a040fe1d4:	mov    rbp,r15
    730a040fe1d7:	add    rbp,0x10
    730a040fe1db:	movdqu XMMWORD PTR [r15],xmm5
    730a040fe1e0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    730a040fe1e5:	mov    r15d,0x420a80
    730a040fe1eb:	movdqu xmm2,XMMWORD PTR [r15]
    730a040fe1f0:	movdqu XMMWORD PTR [r12+0x130],xmm2
    730a040fe1fa:	mov    r15d,0x420a50
    730a040fe200:	movdqu xmm4,XMMWORD PTR [r15]
    730a040fe205:	movdqu XMMWORD PTR [r12+0x140],xmm4
    730a040fe20f:	mov    r15d,0xf8d3
    730a040fe215:	mov    ebp,0x421d
    730a040fe21a:	and    ebp,0xffff
    730a040fe220:	mov    rax,r15
    730a040fe223:	movabs rcx,0xffffffff0000ffff
    730a040fe22d:	and    rax,rcx
    730a040fe230:	mov    rdx,rbp
    730a040fe233:	shl    rdx,0x10
    730a040fe237:	mov    ecx,0xffff0000
    730a040fe23c:	and    rdx,rcx
    730a040fe23f:	or     rax,rdx
    730a040fe242:	mov    r8d,eax
    730a040fe245:	mov    QWORD PTR [r12+0x48],r8
    730a040fe24a:	mov    r15,QWORD PTR [r12+0x98]
    730a040fe252:	add    r15,0x80
    730a040fe259:	mov    rbp,r15
    730a040fe25c:	add    rbp,0x10
    730a040fe260:	movdqu XMMWORD PTR [r15],xmm3
    730a040fe265:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    730a040fe26a:	mov    r15d,0x420af0
    730a040fe270:	movdqu xmm2,XMMWORD PTR [r15]
    730a040fe275:	movdqu XMMWORD PTR [r12+0x130],xmm2
    730a040fe27f:	mov    r15d,0x420b00
    730a040fe285:	movdqu xmm3,XMMWORD PTR [r15]
    730a040fe28a:	movdqu XMMWORD PTR [r12+0x150],xmm3
    730a040fe294:	mov    r15d,0x3e8
    730a040fe29a:	mov    QWORD PTR [r12+0xa0],r15
    730a040fe2a2:	mov    r15,QWORD PTR [r12+0x98]
    730a040fe2aa:	add    r15,0xa0
    730a040fe2b1:	mov    rbp,r15
    730a040fe2b4:	add    rbp,0x10
    730a040fe2b8:	movdqu XMMWORD PTR [r15],xmm4
    730a040fe2bd:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    730a040fe2c2:	mov    r15d,0x420ae0
    730a040fe2c8:	movdqu xmm2,XMMWORD PTR [r15]
    730a040fe2cd:	movdqu XMMWORD PTR [r12+0x130],xmm2
    730a040fe2d7:	mov    r15d,0x420a90
    730a040fe2dd:	movdqu xmm4,XMMWORD PTR [r15]
    730a040fe2e2:	movdqu XMMWORD PTR [r12+0x140],xmm4
    730a040fe2ec:	mov    r15,r13
    730a040fe2ef:	add    r15,0x180
    730a040fe2f6:	mov    rbp,r15
    730a040fe2f9:	add    rbp,0x8
    730a040fe2fd:	mov    r9,QWORD PTR [r12+0x200]
    730a040fe305:	mov    r14,QWORD PTR [r12+0x1f0]
    730a040fe30d:	mov    QWORD PTR [r15],r9
    730a040fe310:	mov    QWORD PTR [rbp+0x0],r14
    730a040fe314:	mov    r14,QWORD PTR [r12+0x98]
    730a040fe31c:	add    r14,0xc0
    730a040fe323:	mov    r15,r14
    730a040fe326:	add    r15,0x10
    730a040fe32a:	movdqu XMMWORD PTR [r14],xmm3
    730a040fe32f:	movdqu XMMWORD PTR [r15],xmm2
    730a040fe334:	mov    r14d,0x420ab0
    730a040fe33a:	movdqu xmm2,XMMWORD PTR [r14]
    730a040fe33f:	movdqu XMMWORD PTR [r12+0x130],xmm2
    730a040fe349:	mov    r14d,0x420b18
    730a040fe34f:	mov    r15,QWORD PTR [r14]
    730a040fe352:	mov    r14d,0x0
    730a040fe358:	mov    QWORD PTR [r12+0x110],r15
    730a040fe360:	mov    QWORD PTR [r12+0x118],r14
    730a040fe368:	mov    r14d,0x420b20
    730a040fe36e:	mov    QWORD PTR [r12+0x40],r14
    730a040fe373:	mov    r14,QWORD PTR [r12+0x98]
    730a040fe37b:	add    r14,0xe0
    730a040fe382:	mov    rbp,r14
    730a040fe385:	add    rbp,0x10
    730a040fe389:	movdqu XMMWORD PTR [r14],xmm4
    730a040fe38e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    730a040fe393:	mov    r14d,0x420b80
    730a040fe399:	movdqu xmm2,XMMWORD PTR [r14]
    730a040fe39e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    730a040fe3a8:	mov    r14,QWORD PTR [r12+0x98]
    730a040fe3b0:	add    r14,0x120
    730a040fe3b7:	mov    QWORD PTR [r14],r15
    730a040fe3ba:	mov    r14d,0x420b60
    730a040fe3c0:	mov    r15d,0x420b70
    730a040fe3c6:	movdqu xmm3,XMMWORD PTR [r14]
    730a040fe3cb:	movdqu xmm4,XMMWORD PTR [r15]
    730a040fe3d0:	movdqu XMMWORD PTR [r12+0x120],xmm3
    730a040fe3da:	movdqu XMMWORD PTR [r12+0x110],xmm4
    730a040fe3e4:	mov    r14,r13
    730a040fe3e7:	add    r14,0x160
    730a040fe3ee:	movdqu XMMWORD PTR [r14],xmm2
    730a040fe3f3:	mov    r14,r13
    730a040fe3f6:	add    r14,0x190
    730a040fe3fd:	mov    r15,r14
    730a040fe400:	add    r15,0x8
    730a040fe404:	mov    rbp,QWORD PTR [r12+0x1e0]
    730a040fe40c:	mov    r9,QWORD PTR [r12+0x1d0]
    730a040fe414:	mov    QWORD PTR [r14],rbp
    730a040fe417:	mov    QWORD PTR [r15],r9
    730a040fe41a:	mov    r14,r13
    730a040fe41d:	add    r14,0x140
    730a040fe424:	mov    r15,r14
    730a040fe427:	add    r15,0x10
    730a040fe42b:	movdqu XMMWORD PTR [r14],xmm3
    730a040fe430:	movdqu XMMWORD PTR [r15],xmm4
    730a040fe435:	mov    r14d,0x420b20
    730a040fe43b:	mov    r15d,0x420b30
    730a040fe441:	movdqu xmm2,XMMWORD PTR [r14]
    730a040fe446:	movdqu xmm3,XMMWORD PTR [r15]
    730a040fe44b:	movdqu XMMWORD PTR [r12+0x110],xmm2
    730a040fe455:	movdqu XMMWORD PTR [r12+0x120],xmm3
    730a040fe45f:	mov    r14,r13
    730a040fe462:	add    r14,0x1a0
    730a040fe469:	mov    r15,r14
    730a040fe46c:	add    r15,0x8
    730a040fe470:	mov    rbp,QWORD PTR [r12+0x1c0]
    730a040fe478:	mov    r9,QWORD PTR [r12+0x1b0]
    730a040fe480:	mov    QWORD PTR [r14],rbp
    730a040fe483:	mov    QWORD PTR [r15],r9
    730a040fe486:	mov    r14,r13
    730a040fe489:	add    r14,0x1b0
    730a040fe490:	mov    r15,r14
    730a040fe493:	add    r15,0x8
    730a040fe497:	mov    rbp,QWORD PTR [r12+0x1a0]
    730a040fe49f:	mov    r9,QWORD PTR [r12+0x190]
    730a040fe4a7:	mov    QWORD PTR [r14],rbp
    730a040fe4aa:	mov    QWORD PTR [r15],r9
    730a040fe4ad:	mov    r14,r13
    730a040fe4b0:	add    r14,0x100
    730a040fe4b7:	mov    r15,r14
    730a040fe4ba:	add    r15,0x10
    730a040fe4be:	movdqu XMMWORD PTR [r14],xmm2
    730a040fe4c3:	movdqu XMMWORD PTR [r15],xmm3
    730a040fe4c8:	mov    r14d,0x420b40
    730a040fe4ce:	mov    r15d,0x420b50
    730a040fe4d4:	movdqu xmm2,XMMWORD PTR [r14]
    730a040fe4d9:	movdqu xmm3,XMMWORD PTR [r15]
    730a040fe4de:	movdqu XMMWORD PTR [r12+0x110],xmm2
    730a040fe4e8:	movdqu XMMWORD PTR [r12+0x130],xmm3
    730a040fe4f2:	mov    r14,r13
    730a040fe4f5:	add    r14,0x1c0
    730a040fe4fc:	mov    r15,r14
    730a040fe4ff:	add    r15,0x8
    730a040fe503:	mov    rbp,QWORD PTR [r12+0xe8]
    730a040fe50b:	mov    r9,QWORD PTR [r12+0xf0]
    730a040fe513:	mov    QWORD PTR [r14],rbp
    730a040fe516:	mov    QWORD PTR [r15],r9
    730a040fe519:	mov    r14,QWORD PTR [r12+0x98]
    730a040fe521:	add    r14,0x128
    730a040fe528:	mov    DWORD PTR [r14],r8d
    730a040fe52b:	mov    r14,r13
    730a040fe52e:	add    r14,0x120
    730a040fe535:	mov    r15,r14
    730a040fe538:	add    r15,0x10
    730a040fe53c:	movdqu XMMWORD PTR [r14],xmm2
    730a040fe541:	movdqu XMMWORD PTR [r15],xmm3
    730a040fe546:	add    r13,0x100
    730a040fe54d:	mov    QWORD PTR [r12],r13
    730a040fe551:	mov    r13d,0x0
    730a040fe557:	mov    rcx,QWORD PTR [r12+0x98]
    730a040fe55f:	or     r13,rcx
    730a040fe562:	mov    QWORD PTR [r12+0x8],r13
    730a040fe567:	mov    r13d,0x12c
    730a040fe56d:	mov    QWORD PTR [r12+0x10],r13
    730a040fe572:	mov    r13d,0x410284
    730a040fe578:	mov    QWORD PTR [r12+0xf0],r13
    730a040fe580:	mov    r13d,0x410728
    730a040fe586:	mov    QWORD PTR [r12+0x100],r13
    730a040fe58e:	mov    r11,QWORD PTR [rsp]
    730a040fe592:	mov    QWORD PTR [r12+0x398],r11
    730a040fe59a:	mov    edi,0x410728
    730a040fe59f:	mov    QWORD PTR [r12+0x100],rdi
    730a040fe5a7:	add    rsp,0x10
    730a040fe5ab:	nop    DWORD PTR [rax+rax*1+0x0]
    730a040fe5b0:	jmp    QWORD PTR [rip+0x2]        # 0x730a040fe5b8
    730a040fe5b6:	xchg   ax,ax
    730a040fe5b8:	loopne 0x730a040fe59f
    730a040fe5ba:	(bad)
    730a040fe5bc:	or     dh,BYTE PTR [rbx+0x0]
    730a040fe5bf:	add    al,cl
    730a040fe5c1:	in     eax,0xf
    730a040fe5c3:	add    al,0xa
    730a040fe5c5:	jae    0x730a040fe5c7
    730a040fe5c7:	add    BYTE PTR [rcx-0x45],cl
    730a040fe5ca:	rex leave
    730a040fe5cc:	ret    0x91a9
    730a040fe5cf:	push   rbp
    730a040fe5d0:	add    BYTE PTR [rax],al
    730a040fe5d2:	jmp    r11
    730a040fe5d5:	nop
    730a040fe5d6:	nop
    730a040fe5d7:	nop
