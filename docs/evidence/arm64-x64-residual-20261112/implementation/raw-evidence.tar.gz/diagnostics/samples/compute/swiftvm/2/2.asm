
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/2/2.bin:     file format binary


Disassembly of section .data:

0000730a04100b80 <.data>:
    730a04100b80:	sub    rsp,0x10
    730a04100b84:	mov    r13d,DWORD PTR [r12+0xa0]
    730a04100b8c:	sub    r13d,0x1
    730a04100b90:	mov    QWORD PTR [r12+0xa0],r13
    730a04100b98:	mov    rcx,QWORD PTR [r12+0x380]
    730a04100ba0:	jrcxz  0x730a04100ba7
    730a04100ba2:	jmp    0x730a04100d3d
    730a04100ba7:	jne    0x730a04100bc0
    730a04100bad:	mov    r11,rax
    730a04100bb0:	lahf
    730a04100bb1:	seto   al
    730a04100bb4:	mov    WORD PTR [rsp],ax
    730a04100bb8:	mov    rax,r11
    730a04100bbb:	jmp    0x730a04100bd3
    730a04100bc0:	mov    r11,rax
    730a04100bc3:	lahf
    730a04100bc4:	seto   al
    730a04100bc7:	mov    WORD PTR [rsp],ax
    730a04100bcb:	mov    rax,r11
    730a04100bce:	jmp    0x730a04100ca5
    730a04100bd3:	mov    r13,QWORD PTR [r12+0xf8]
    730a04100bdb:	mov    r14,r13
    730a04100bde:	add    r14,0x120
    730a04100be5:	mov    r15,QWORD PTR [r14]
    730a04100be8:	mov    QWORD PTR [r12+0x98],r15
    730a04100bf0:	mov    r14d,0x80
    730a04100bf6:	mov    QWORD PTR [r12+0x40],r14
    730a04100bfb:	mov    r14,r13
    730a04100bfe:	add    r14,0x100
    730a04100c05:	mov    QWORD PTR [r12],r14
    730a04100c09:	mov    r14,r13
    730a04100c0c:	add    r14,0x17c
    730a04100c13:	mov    QWORD PTR [r12+0x8],r14
    730a04100c18:	mov    r14d,0x1
    730a04100c1e:	mov    QWORD PTR [r12+0x10],r14
    730a04100c23:	add    r13,0x17c
    730a04100c2a:	movzx  r14d,BYTE PTR [r12+0x40]
    730a04100c30:	mov    BYTE PTR [r13+0x0],r14b
    730a04100c34:	mov    r13d,0x0
    730a04100c3a:	mov    DWORD PTR [r12+0x32c],r13d
    730a04100c42:	mov    r13d,0x4102a8
    730a04100c48:	mov    QWORD PTR [r12+0xf0],r13
    730a04100c50:	mov    r13d,0x410728
    730a04100c56:	mov    QWORD PTR [r12+0x100],r13
    730a04100c5e:	mov    r11,QWORD PTR [rsp]
    730a04100c62:	mov    QWORD PTR [r12+0x398],r11
    730a04100c6a:	mov    edi,0x410728
    730a04100c6f:	mov    QWORD PTR [r12+0x100],rdi
    730a04100c77:	add    rsp,0x10
    730a04100c7b:	nop    DWORD PTR [rax+rax*1+0x0]
    730a04100c80:	jmp    QWORD PTR [rip+0x2]        # 0x730a04100c88
    730a04100c86:	xchg   ax,ax
    730a04100c88:	loopne 0x730a04100c6f
    730a04100c8a:	(bad)
    730a04100c8c:	or     dh,BYTE PTR [rbx+0x0]
    730a04100c8f:	add    BYTE PTR [rax+0xa04100c],bl
    730a04100c95:	jae    0x730a04100c97
    730a04100c97:	add    BYTE PTR [rcx-0x45],cl
    730a04100c9a:	rex leave
    730a04100c9c:	ret    0x91a9
    730a04100c9f:	push   rbp
    730a04100ca0:	add    BYTE PTR [rax],al
    730a04100ca2:	jmp    r11
    730a04100ca5:	mov    r13,QWORD PTR [r12+0xf8]
    730a04100cad:	add    r13,0x100
    730a04100cb4:	mov    QWORD PTR [r12],r13
    730a04100cb8:	mov    r13d,0x0
    730a04100cbe:	mov    r14,QWORD PTR [r12+0x98]
    730a04100cc6:	or     r13,r14
    730a04100cc9:	mov    QWORD PTR [r12+0x8],r13
    730a04100cce:	mov    r13d,0x12c
    730a04100cd4:	mov    QWORD PTR [r12+0x10],r13
    730a04100cd9:	mov    r13d,0x410284
    730a04100cdf:	mov    QWORD PTR [r12+0xf0],r13
    730a04100ce7:	mov    r13d,0x410728
    730a04100ced:	mov    QWORD PTR [r12+0x100],r13
    730a04100cf5:	mov    r11,QWORD PTR [rsp]
    730a04100cf9:	mov    QWORD PTR [r12+0x398],r11
    730a04100d01:	mov    edi,0x410728
    730a04100d06:	mov    QWORD PTR [r12+0x100],rdi
    730a04100d0e:	add    rsp,0x10
    730a04100d12:	nop    WORD PTR [rax+rax*1+0x0]
    730a04100d18:	jmp    QWORD PTR [rip+0x2]        # 0x730a04100d20
    730a04100d1e:	xchg   ax,ax
    730a04100d20:	loopne 0x730a04100d07
    730a04100d22:	(bad)
    730a04100d24:	or     dh,BYTE PTR [rbx+0x0]
    730a04100d27:	add    BYTE PTR [rax],dh
    730a04100d29:	or     eax,0x730a0410
    730a04100d2e:	add    BYTE PTR [rax],al
    730a04100d30:	movabs r11,0x5591a9c2c940
    730a04100d3a:	jmp    r11
    730a04100d3d:	mov    eax,0x410288
    730a04100d42:	mov    QWORD PTR [r12+0x100],rax
    730a04100d4a:	push   rdx
    730a04100d4b:	push   rsi
    730a04100d4c:	push   r10
    730a04100d4e:	push   r11
    730a04100d50:	mov    r11,rax
    730a04100d53:	lahf
    730a04100d54:	seto   al
    730a04100d57:	mov    WORD PTR [rsp+0x20],ax
    730a04100d5c:	mov    rax,r11
    730a04100d5f:	mov    rdx,QWORD PTR [rsp+0x20]
    730a04100d64:	mov    r10d,edx
    730a04100d67:	and    r10d,0xc000
    730a04100d6e:	shl    r10d,0x10
    730a04100d72:	mov    r11d,edx
    730a04100d75:	and    r11d,0x100
    730a04100d7c:	shl    r11d,0x15
    730a04100d80:	or     r10d,r11d
    730a04100d83:	and    edx,0x1
    730a04100d86:	shl    edx,0x1c
    730a04100d89:	or     r10d,edx
    730a04100d8c:	btc    r10,0x1d
    730a04100d91:	mov    r11d,0xf0000000
    730a04100d97:	and    r11,r10
    730a04100d9a:	movabs rsi,0xffffffff0fffffff
    730a04100da4:	and    rbx,rsi
    730a04100da7:	or     rbx,r11
    730a04100daa:	pop    r11
    730a04100dac:	pop    r10
    730a04100dae:	pop    rsi
    730a04100daf:	pop    rdx
    730a04100db0:	mov    QWORD PTR [r12+0x108],rbx
    730a04100db8:	add    rsp,0x10
    730a04100dbc:	mov    eax,0xc
    730a04100dc1:	movabs r11,0x5591a9c2cca0
    730a04100dcb:	jmp    r11
    730a04100dce:	xchg   ax,ax
    730a04100dd0:	sub    rsp,0x10
    730a04100dd4:	mov    r11,QWORD PTR [r12+0x398]
    730a04100ddc:	mov    QWORD PTR [rsp],r11
    730a04100de0:	jmp    0x730a04100bd3
    730a04100de5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04100df0:	sub    rsp,0x10
    730a04100df4:	mov    r11,QWORD PTR [r12+0x398]
    730a04100dfc:	mov    QWORD PTR [rsp],r11
    730a04100e00:	jmp    0x730a04100ca5
    730a04100e05:	nop
    730a04100e06:	nop
    730a04100e07:	nop
