
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/0/7.bin:     file format binary


Disassembly of section .data:

000077db49301910 <.data>:
    77db49301910:	sub    rsp,0x10
    77db49301914:	mov    r11,QWORD PTR [r12+0x398]
    77db4930191c:	mov    QWORD PTR [rsp],r11
    77db49301920:	mov    r13,QWORD PTR [r12+0xa0]
    77db49301928:	mov    r14,r13
    77db4930192b:	shl    r14,0x2
    77db4930192f:	mov    r15,QWORD PTR [r12+0x98]
    77db49301937:	add    r15,r14
    77db4930193a:	mov    r14d,DWORD PTR [r12]
    77db4930193e:	mov    DWORD PTR [r15],r14d
    77db49301941:	mov    r14d,0x0
    77db49301947:	mov    DWORD PTR [r12+0x32c],r14d
    77db4930194f:	add    r13,0x1
    77db49301953:	mov    QWORD PTR [r12+0xa0],r13
    77db4930195b:	sub    r13,0x400
    77db49301962:	mov    rcx,QWORD PTR [r12+0x380]
    77db4930196a:	jrcxz  0x77db49301971
    77db4930196c:	jmp    0x77db49301d4d
    77db49301971:	jne    0x77db4930198a
    77db49301977:	mov    r11,rax
    77db4930197a:	lahf
    77db4930197b:	seto   al
    77db4930197e:	mov    WORD PTR [rsp],ax
    77db49301982:	mov    rax,r11
    77db49301985:	jmp    0x77db4930199d
    77db4930198a:	mov    r11,rax
    77db4930198d:	lahf
    77db4930198e:	seto   al
    77db49301991:	mov    WORD PTR [rsp],ax
    77db49301995:	mov    rax,r11
    77db49301998:	jmp    0x77db49301cdd
    77db4930199d:	mov    r13d,0x1
    77db493019a3:	mov    QWORD PTR [r12+0x40],r13
    77db493019a8:	mov    r11,rax
    77db493019ab:	movzx  eax,WORD PTR [rsp]
    77db493019af:	add    al,0x7f
    77db493019b1:	sahf
    77db493019b2:	mov    rax,r11
    77db493019b5:	jmp    0x77db493019ba
    77db493019ba:	mov    r13,QWORD PTR [r12+0x40]
    77db493019bf:	mov    r14,r13
    77db493019c2:	lea    r14,[r14*4+0x0]
    77db493019ca:	mov    r15,QWORD PTR [r12+0x98]
    77db493019d2:	mov    r11,rax
    77db493019d5:	lahf
    77db493019d6:	seto   al
    77db493019d9:	mov    WORD PTR [rsp],ax
    77db493019dd:	mov    rax,r11
    77db493019e0:	add    r15,r14
    77db493019e3:	mov    r14d,DWORD PTR [r15]
    77db493019e6:	mov    QWORD PTR [r12+0x48],r14
    77db493019eb:	mov    r14d,0x0
    77db493019f1:	or     r14,r13
    77db493019f4:	mov    QWORD PTR [r12+0x50],r14
    77db493019f9:	jmp    0x77db493019fe
    77db493019fe:	mov    r13d,DWORD PTR [r12+0x50]
    77db49301a03:	sub    r13d,0x1
    77db49301a07:	mov    QWORD PTR [r12+0x58],r13
    77db49301a0c:	mov    ecx,0xffffffff
    77db49301a11:	mov    r14,r13
    77db49301a14:	and    r14,rcx
    77db49301a17:	shl    r14,0x2
    77db49301a1b:	mov    r13,QWORD PTR [r12+0x98]
    77db49301a23:	add    r13,r14
    77db49301a26:	mov    r14d,DWORD PTR [r13+0x0]
    77db49301a2a:	mov    QWORD PTR [r12+0x60],r14
    77db49301a2f:	mov    r13d,DWORD PTR [r12+0x48]
    77db49301a34:	sub    r14d,r13d
    77db49301a37:	mov    rcx,QWORD PTR [r12+0x380]
    77db49301a3f:	jrcxz  0x77db49301a46
    77db49301a41:	jmp    0x77db49301dde
    77db49301a46:	jbe    0x77db49301a5f
    77db49301a4c:	mov    r11,rax
    77db49301a4f:	lahf
    77db49301a50:	seto   al
    77db49301a53:	mov    WORD PTR [rsp],ax
    77db49301a57:	mov    rax,r11
    77db49301a5a:	jmp    0x77db49301a72
    77db49301a5f:	mov    r11,rax
    77db49301a62:	lahf
    77db49301a63:	seto   al
    77db49301a66:	mov    WORD PTR [rsp],ax
    77db49301a6a:	mov    rax,r11
    77db49301a6d:	jmp    0x77db49301af1
    77db49301a72:	mov    r13,QWORD PTR [r12+0x50]
    77db49301a77:	mov    r14,r13
    77db49301a7a:	shl    r14,0x2
    77db49301a7e:	mov    r15,QWORD PTR [r12+0x98]
    77db49301a86:	add    r15,r14
    77db49301a89:	mov    r14d,DWORD PTR [r12+0x60]
    77db49301a8e:	mov    DWORD PTR [r15],r14d
    77db49301a91:	mov    r14d,0x0
    77db49301a97:	mov    DWORD PTR [r12+0x32c],r14d
    77db49301a9f:	sub    r13,0x1
    77db49301aa3:	mov    QWORD PTR [r12+0x50],r13
    77db49301aa8:	mov    rcx,QWORD PTR [r12+0x380]
    77db49301ab0:	jrcxz  0x77db49301ab7
    77db49301ab2:	jmp    0x77db49301e6f
    77db49301ab7:	mov    r13,QWORD PTR [r12+0x58]
    77db49301abc:	mov    rax,r13
    77db49301abf:	test   rax,rax
    77db49301ac2:	jne    0x77db493019fe
    77db49301ac8:	jmp    0x77db49301acd
    77db49301acd:	mov    rcx,QWORD PTR [r12+0x380]
    77db49301ad5:	jrcxz  0x77db49301adc
    77db49301ad7:	jmp    0x77db49301ef1
    77db49301adc:	jmp    0x77db49301ae1
    77db49301ae1:	mov    r13d,0x0
    77db49301ae7:	mov    QWORD PTR [r12+0x50],r13
    77db49301aec:	jmp    0x77db49301af1
    77db49301af1:	mov    r13,QWORD PTR [r12+0x40]
    77db49301af6:	add    r13,0x1
    77db49301afa:	mov    QWORD PTR [r12+0x40],r13
    77db49301aff:	mov    r14,QWORD PTR [r12+0x50]
    77db49301b04:	mov    ecx,0xffffffff
    77db49301b09:	and    r14,rcx
    77db49301b0c:	shl    r14,0x2
    77db49301b10:	mov    r15,QWORD PTR [r12+0x98]
    77db49301b18:	add    r15,r14
    77db49301b1b:	mov    r14d,DWORD PTR [r12+0x48]
    77db49301b20:	mov    DWORD PTR [r15],r14d
    77db49301b23:	mov    r14d,0x0
    77db49301b29:	mov    DWORD PTR [r12+0x32c],r14d
    77db49301b31:	sub    r13,0x400
    77db49301b38:	jne    0x77db493019ba
    77db49301b3e:	mov    r11,rax
    77db49301b41:	lahf
    77db49301b42:	seto   al
    77db49301b45:	mov    WORD PTR [rsp],ax
    77db49301b49:	mov    rax,r11
    77db49301b4c:	jmp    0x77db49301b51
    77db49301b51:	mov    r13d,0x430000
    77db49301b57:	mov    QWORD PTR [r12+0x40],r13
    77db49301b5c:	mov    r13d,0x0
    77db49301b62:	mov    QWORD PTR [r12+0x58],r13
    77db49301b67:	mov    r13d,0x0
    77db49301b6d:	mov    QWORD PTR [r12+0x50],r13
    77db49301b72:	mov    r13d,0x430cb0
    77db49301b78:	mov    r14,QWORD PTR [r13+0x0]
    77db49301b7c:	mov    QWORD PTR [r12+0x48],r14
    77db49301b81:	jmp    0x77db49301b86
    77db49301b86:	mov    r13,QWORD PTR [r12+0x58]
    77db49301b8b:	mov    r14,r13
    77db49301b8e:	shl    r14,0x2
    77db49301b92:	mov    r15,QWORD PTR [r12+0x98]
    77db49301b9a:	add    r15,r14
    77db49301b9d:	mov    QWORD PTR [r12+0x60],r15
    77db49301ba2:	mov    r14,r15
    77db49301ba5:	add    r14,0x4
    77db49301ba9:	mov    ebp,DWORD PTR [r15]
    77db49301bac:	mov    r15d,DWORD PTR [r14]
    77db49301baf:	mov    QWORD PTR [r12+0x60],r15
    77db49301bb4:	mov    r14,rbp
    77db49301bb7:	imul   r14,r13
    77db49301bbb:	mov    r8,rbp
    77db49301bbe:	add    r8,r14
    77db49301bc1:	mov    QWORD PTR [r12+0x68],r8
    77db49301bc6:	add    r13,0x2
    77db49301bca:	mov    QWORD PTR [r12+0x58],r13
    77db49301bcf:	mov    r14,r13
    77db49301bd2:	sub    r14,0x400
    77db49301bd9:	mov    r14,QWORD PTR [r12+0x50]
    77db49301bde:	setne  BYTE PTR [rsp+0x8]
    77db49301be3:	mov    r11,rax
    77db49301be6:	lahf
    77db49301be7:	seto   al
    77db49301bea:	mov    WORD PTR [rsp],ax
    77db49301bee:	mov    rax,r11
    77db49301bf1:	imul   r13,r15
    77db49301bf5:	add    r14,r13
    77db49301bf8:	mov    QWORD PTR [r12+0x50],r14
    77db49301bfd:	mov    r13,QWORD PTR [r12+0x48]
    77db49301c02:	add    r8,r13
    77db49301c05:	mov    QWORD PTR [r12+0x48],r8
    77db49301c0a:	mov    rcx,QWORD PTR [r12+0x380]
    77db49301c12:	jrcxz  0x77db49301c19
    77db49301c14:	jmp    0x77db49301f73
    77db49301c19:	cmp    BYTE PTR [rsp+0x8],0x0
    77db49301c1e:	jne    0x77db49301b86
    77db49301c24:	jmp    0x77db49301c29
    77db49301c29:	mov    r13d,0x0
    77db49301c2f:	mov    QWORD PTR [r12+0x98],r13
    77db49301c37:	mov    r13,QWORD PTR [r12+0x48]
    77db49301c3c:	mov    r14,QWORD PTR [r12+0x50]
    77db49301c41:	add    r14,r13
    77db49301c44:	mov    QWORD PTR [r12+0x48],r14
    77db49301c49:	mov    r13d,0x1
    77db49301c4f:	mov    QWORD PTR [r12],r13
    77db49301c53:	mov    r13,QWORD PTR [r12+0x40]
    77db49301c58:	add    r13,0xcb0
    77db49301c5f:	mov    QWORD PTR [r13+0x0],r14
    77db49301c63:	mov    r13d,0x0
    77db49301c69:	mov    DWORD PTR [r12+0x32c],r13d
    77db49301c71:	mov    r13d,0x1
    77db49301c77:	mov    QWORD PTR [r12],r13
    77db49301c7b:	mov    r13d,0x4103f8
    77db49301c81:	mov    QWORD PTR [r12+0xf0],r13
    77db49301c89:	mov    r13d,0x4109a4
    77db49301c8f:	mov    QWORD PTR [r12+0x100],r13
    77db49301c97:	mov    r11,QWORD PTR [rsp]
    77db49301c9b:	mov    QWORD PTR [r12+0x398],r11
    77db49301ca3:	mov    edi,0x4109a4
    77db49301ca8:	mov    QWORD PTR [r12+0x100],rdi
    77db49301cb0:	add    rsp,0x10
    77db49301cb4:	nop    DWORD PTR [rax+0x0]
    77db49301cb8:	jmp    QWORD PTR [rip+0x2]        # 0x77db49301cc0
    77db49301cbe:	xchg   ax,ax
    77db49301cc0:	rex (bad)
    77db49301cc2:	xor    BYTE PTR [rcx-0x25],cl
    77db49301cc5:	ja     0x77db49301cc7
    77db49301cc7:	add    al,dl
    77db49301cc9:	sbb    al,0x30
    77db49301ccb:	rex.WB (bad) [r15+0x0]
    77db49301ccf:	add    BYTE PTR [rcx-0x45],cl
    77db49301cd2:	rex cdq
    77db49301cd4:	mov    eax,0x60ebc8
    77db49301cd9:	add    BYTE PTR [rcx-0x1],al
    77db49301cdc:	jrcxz  0x77db49301d23
    77db49301cde:	mov    ebp,DWORD PTR [rsp+0xa0]
    77db49301ce5:	add    r13d,0x11
    77db49301ce9:	mov    QWORD PTR [r12],r13
    77db49301ced:	mov    r13d,0x41035c
    77db49301cf3:	mov    QWORD PTR [r12+0xf0],r13
    77db49301cfb:	mov    r13d,0x4109a4
    77db49301d01:	mov    QWORD PTR [r12+0x100],r13
    77db49301d09:	mov    r11,QWORD PTR [rsp]
    77db49301d0d:	mov    QWORD PTR [r12+0x398],r11
    77db49301d15:	mov    edi,0x4109a4
    77db49301d1a:	mov    QWORD PTR [r12+0x100],rdi
    77db49301d22:	add    rsp,0x10
    77db49301d26:	xchg   ax,ax
    77db49301d28:	jmp    QWORD PTR [rip+0x2]        # 0x77db49301d30
    77db49301d2e:	xchg   ax,ax
    77db49301d30:	rex (bad)
    77db49301d32:	xor    BYTE PTR [rcx-0x25],cl
    77db49301d35:	ja     0x77db49301d37
    77db49301d37:	add    BYTE PTR [rax+0x1d],al
    77db49301d3a:	xor    BYTE PTR [rcx-0x25],cl
    77db49301d3d:	ja     0x77db49301d3f
    77db49301d3f:	add    BYTE PTR [rcx-0x45],cl
    77db49301d42:	rex cdq
    77db49301d44:	mov    eax,0x60ebc8
    77db49301d49:	add    BYTE PTR [rcx-0x1],al
    77db49301d4c:	jrcxz  0x77db49301d06
    77db49301d4e:	push   0x49004103
    77db49301d53:	mov    DWORD PTR [rsp+0x100],eax
    77db49301d5a:	push   rdx
    77db49301d5b:	push   rsi
    77db49301d5c:	push   r10
    77db49301d5e:	push   r11
    77db49301d60:	mov    r11,rax
    77db49301d63:	lahf
    77db49301d64:	seto   al
    77db49301d67:	mov    WORD PTR [rsp+0x20],ax
    77db49301d6c:	mov    rax,r11
    77db49301d6f:	mov    rdx,QWORD PTR [rsp+0x20]
    77db49301d74:	mov    r10d,edx
    77db49301d77:	and    r10d,0xc000
    77db49301d7e:	shl    r10d,0x10
    77db49301d82:	mov    r11d,edx
    77db49301d85:	and    r11d,0x100
    77db49301d8c:	shl    r11d,0x15
    77db49301d90:	or     r10d,r11d
    77db49301d93:	and    edx,0x1
    77db49301d96:	shl    edx,0x1c
    77db49301d99:	or     r10d,edx
    77db49301d9c:	btc    r10,0x1d
    77db49301da1:	mov    r11d,0xf0000000
    77db49301da7:	and    r11,r10
    77db49301daa:	movabs rsi,0xffffffff0fffffff
    77db49301db4:	and    rbx,rsi
    77db49301db7:	or     rbx,r11
    77db49301dba:	pop    r11
    77db49301dbc:	pop    r10
    77db49301dbe:	pop    rsi
    77db49301dbf:	pop    rdx
    77db49301dc0:	mov    QWORD PTR [r12+0x108],rbx
    77db49301dc8:	add    rsp,0x10
    77db49301dcc:	mov    eax,0xc
    77db49301dd1:	movabs r11,0x60ebc8b89ca0
    77db49301ddb:	jmp    r11
    77db49301dde:	mov    eax,0x41039c
    77db49301de3:	mov    QWORD PTR [r12+0x100],rax
    77db49301deb:	push   rdx
    77db49301dec:	push   rsi
    77db49301ded:	push   r10
    77db49301def:	push   r11
    77db49301df1:	mov    r11,rax
    77db49301df4:	lahf
    77db49301df5:	seto   al
    77db49301df8:	mov    WORD PTR [rsp+0x20],ax
    77db49301dfd:	mov    rax,r11
    77db49301e00:	mov    rdx,QWORD PTR [rsp+0x20]
    77db49301e05:	mov    r10d,edx
    77db49301e08:	and    r10d,0xc000
    77db49301e0f:	shl    r10d,0x10
    77db49301e13:	mov    r11d,edx
    77db49301e16:	and    r11d,0x100
    77db49301e1d:	shl    r11d,0x15
    77db49301e21:	or     r10d,r11d
    77db49301e24:	and    edx,0x1
    77db49301e27:	shl    edx,0x1c
    77db49301e2a:	or     r10d,edx
    77db49301e2d:	btc    r10,0x1d
    77db49301e32:	mov    r11d,0xf0000000
    77db49301e38:	and    r11,r10
    77db49301e3b:	movabs rsi,0xffffffff0fffffff
    77db49301e45:	and    rbx,rsi
    77db49301e48:	or     rbx,r11
    77db49301e4b:	pop    r11
    77db49301e4d:	pop    r10
    77db49301e4f:	pop    rsi
    77db49301e50:	pop    rdx
    77db49301e51:	mov    QWORD PTR [r12+0x108],rbx
    77db49301e59:	add    rsp,0x10
    77db49301e5d:	mov    eax,0xc
    77db49301e62:	movabs r11,0x60ebc8b89ca0
    77db49301e6c:	jmp    r11
    77db49301e6f:	mov    eax,0x4103a8
    77db49301e74:	mov    QWORD PTR [r12+0x100],rax
    77db49301e7c:	push   rdx
    77db49301e7d:	push   rsi
    77db49301e7e:	push   r10
    77db49301e80:	push   r11
    77db49301e82:	mov    rdx,QWORD PTR [rsp+0x20]
    77db49301e87:	mov    r10d,edx
    77db49301e8a:	and    r10d,0xc000
    77db49301e91:	shl    r10d,0x10
    77db49301e95:	mov    r11d,edx
    77db49301e98:	and    r11d,0x100
    77db49301e9f:	shl    r11d,0x15
    77db49301ea3:	or     r10d,r11d
    77db49301ea6:	and    edx,0x1
    77db49301ea9:	shl    edx,0x1c
    77db49301eac:	or     r10d,edx
    77db49301eaf:	btc    r10,0x1d
    77db49301eb4:	mov    r11d,0xf0000000
    77db49301eba:	and    r11,r10
    77db49301ebd:	movabs rsi,0xffffffff0fffffff
    77db49301ec7:	and    rbx,rsi
    77db49301eca:	or     rbx,r11
    77db49301ecd:	pop    r11
    77db49301ecf:	pop    r10
    77db49301ed1:	pop    rsi
    77db49301ed2:	pop    rdx
    77db49301ed3:	mov    QWORD PTR [r12+0x108],rbx
    77db49301edb:	add    rsp,0x10
    77db49301edf:	mov    eax,0xc
    77db49301ee4:	movabs r11,0x60ebc8b89ca0
    77db49301eee:	jmp    r11
    77db49301ef1:	mov    eax,0x4103ac
    77db49301ef6:	mov    QWORD PTR [r12+0x100],rax
    77db49301efe:	push   rdx
    77db49301eff:	push   rsi
    77db49301f00:	push   r10
    77db49301f02:	push   r11
    77db49301f04:	mov    rdx,QWORD PTR [rsp+0x20]
    77db49301f09:	mov    r10d,edx
    77db49301f0c:	and    r10d,0xc000
    77db49301f13:	shl    r10d,0x10
    77db49301f17:	mov    r11d,edx
    77db49301f1a:	and    r11d,0x100
    77db49301f21:	shl    r11d,0x15
    77db49301f25:	or     r10d,r11d
    77db49301f28:	and    edx,0x1
    77db49301f2b:	shl    edx,0x1c
    77db49301f2e:	or     r10d,edx
    77db49301f31:	btc    r10,0x1d
    77db49301f36:	mov    r11d,0xf0000000
    77db49301f3c:	and    r11,r10
    77db49301f3f:	movabs rsi,0xffffffff0fffffff
    77db49301f49:	and    rbx,rsi
    77db49301f4c:	or     rbx,r11
    77db49301f4f:	pop    r11
    77db49301f51:	pop    r10
    77db49301f53:	pop    rsi
    77db49301f54:	pop    rdx
    77db49301f55:	mov    QWORD PTR [r12+0x108],rbx
    77db49301f5d:	add    rsp,0x10
    77db49301f61:	mov    eax,0xc
    77db49301f66:	movabs r11,0x60ebc8b89ca0
    77db49301f70:	jmp    r11
    77db49301f73:	mov    eax,0x4103dc
    77db49301f78:	mov    QWORD PTR [r12+0x100],rax
    77db49301f80:	push   rdx
    77db49301f81:	push   rsi
    77db49301f82:	push   r10
    77db49301f84:	push   r11
    77db49301f86:	mov    rdx,QWORD PTR [rsp+0x20]
    77db49301f8b:	mov    r10d,edx
    77db49301f8e:	and    r10d,0xc000
    77db49301f95:	shl    r10d,0x10
    77db49301f99:	mov    r11d,edx
    77db49301f9c:	and    r11d,0x100
    77db49301fa3:	shl    r11d,0x15
    77db49301fa7:	or     r10d,r11d
    77db49301faa:	and    edx,0x1
    77db49301fad:	shl    edx,0x1c
    77db49301fb0:	or     r10d,edx
    77db49301fb3:	btc    r10,0x1d
    77db49301fb8:	mov    r11d,0xf0000000
    77db49301fbe:	and    r11,r10
    77db49301fc1:	movabs rsi,0xffffffff0fffffff
    77db49301fcb:	and    rbx,rsi
    77db49301fce:	or     rbx,r11
    77db49301fd1:	pop    r11
    77db49301fd3:	pop    r10
    77db49301fd5:	pop    rsi
    77db49301fd6:	pop    rdx
    77db49301fd7:	mov    QWORD PTR [r12+0x108],rbx
    77db49301fdf:	add    rsp,0x10
    77db49301fe3:	mov    eax,0xc
    77db49301fe8:	movabs r11,0x60ebc8b89ca0
    77db49301ff2:	jmp    r11
    77db49301ff5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49302000:	sub    rsp,0x10
    77db49302004:	mov    r11,QWORD PTR [r12+0x398]
    77db4930200c:	mov    QWORD PTR [rsp],r11
    77db49302010:	jmp    0x77db4930199d
    77db49302015:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49302020:	sub    rsp,0x10
    77db49302024:	mov    r11,QWORD PTR [r12+0x398]
    77db4930202c:	mov    QWORD PTR [rsp],r11
    77db49302030:	mov    r11,rax
    77db49302033:	movzx  eax,WORD PTR [rsp]
    77db49302037:	add    al,0x7f
    77db49302039:	sahf
    77db4930203a:	mov    rax,r11
    77db4930203d:	jmp    0x77db493019ba
    77db49302042:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49302050:	sub    rsp,0x10
    77db49302054:	mov    r11,QWORD PTR [r12+0x398]
    77db4930205c:	mov    QWORD PTR [rsp],r11
    77db49302060:	jmp    0x77db493019fe
    77db49302065:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49302070:	sub    rsp,0x10
    77db49302074:	mov    r11,QWORD PTR [r12+0x398]
    77db4930207c:	mov    QWORD PTR [rsp],r11
    77db49302080:	jmp    0x77db49301a72
    77db49302085:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49302090:	sub    rsp,0x10
    77db49302094:	mov    r11,QWORD PTR [r12+0x398]
    77db4930209c:	mov    QWORD PTR [rsp],r11
    77db493020a0:	jmp    0x77db49301acd
    77db493020a5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db493020b0:	sub    rsp,0x10
    77db493020b4:	mov    r11,QWORD PTR [r12+0x398]
    77db493020bc:	mov    QWORD PTR [rsp],r11
    77db493020c0:	jmp    0x77db49301ae1
    77db493020c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db493020d0:	sub    rsp,0x10
    77db493020d4:	mov    r11,QWORD PTR [r12+0x398]
    77db493020dc:	mov    QWORD PTR [rsp],r11
    77db493020e0:	jmp    0x77db49301af1
    77db493020e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db493020f0:	sub    rsp,0x10
    77db493020f4:	mov    r11,QWORD PTR [r12+0x398]
    77db493020fc:	mov    QWORD PTR [rsp],r11
    77db49302100:	jmp    0x77db49301b51
    77db49302105:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49302110:	sub    rsp,0x10
    77db49302114:	mov    r11,QWORD PTR [r12+0x398]
    77db4930211c:	mov    QWORD PTR [rsp],r11
    77db49302120:	jmp    0x77db49301b86
    77db49302125:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49302130:	sub    rsp,0x10
    77db49302134:	mov    r11,QWORD PTR [r12+0x398]
    77db4930213c:	mov    QWORD PTR [rsp],r11
    77db49302140:	jmp    0x77db49301c29
    77db49302145:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    77db49302150:	sub    rsp,0x10
    77db49302154:	mov    r11,QWORD PTR [r12+0x398]
    77db4930215c:	mov    QWORD PTR [rsp],r11
    77db49302160:	jmp    0x77db49301cdd
    77db49302165:	nop
    77db49302166:	nop
    77db49302167:	nop
