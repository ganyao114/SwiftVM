
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/1/4.bin:     file format binary


Disassembly of section .data:

00007c479db01080 <.data>:
    7c479db01080:	sub    rsp,0x10
    7c479db01084:	mov    r11,QWORD PTR [r12+0x398]
    7c479db0108c:	mov    QWORD PTR [rsp],r11
    7c479db01090:	mov    r13,QWORD PTR [r12+0xf8]
    7c479db01098:	add    r13,0x168
    7c479db0109f:	mov    r14,QWORD PTR [r13+0x0]
    7c479db010a3:	mov    QWORD PTR [r12+0x40],r14
    7c479db010a8:	sub    r14,0x38
    7c479db010ac:	mov    rcx,QWORD PTR [r12+0x380]
    7c479db010b4:	jrcxz  0x7c479db010bb
    7c479db010b6:	jmp    0x7c479db0118d
    7c479db010bb:	jne    0x7c479db010d4
    7c479db010c1:	mov    r11,rax
    7c479db010c4:	lahf
    7c479db010c5:	seto   al
    7c479db010c8:	mov    WORD PTR [rsp],ax
    7c479db010cc:	mov    rax,r11
    7c479db010cf:	jmp    0x7c479db010e7
    7c479db010d4:	mov    r11,rax
    7c479db010d7:	lahf
    7c479db010d8:	seto   al
    7c479db010db:	mov    WORD PTR [rsp],ax
    7c479db010df:	mov    rax,r11
    7c479db010e2:	jmp    0x7c479db0113d
    7c479db010e7:	mov    r13d,0x4102d4
    7c479db010ed:	mov    QWORD PTR [r12+0x100],r13
    7c479db010f5:	mov    r11,QWORD PTR [rsp]
    7c479db010f9:	mov    QWORD PTR [r12+0x398],r11
    7c479db01101:	mov    edi,0x4102d4
    7c479db01106:	mov    QWORD PTR [r12+0x100],rdi
    7c479db0110e:	add    rsp,0x10
    7c479db01112:	nop    WORD PTR [rax+rax*1+0x0]
    7c479db01118:	jmp    QWORD PTR [rip+0x2]        # 0x7c479db01120
    7c479db0111e:	xchg   ax,ax
    7c479db01120:	(bad)
    7c479db01121:	adc    BYTE PTR [rax+0x7c479d],dh
    7c479db01127:	add    BYTE PTR [rax],dh
    7c479db01129:	adc    DWORD PTR [rax+0x7c479d],esi
    7c479db0112f:	add    BYTE PTR [rcx-0x45],cl
    7c479db01132:	rex jns 0x7c479db01167
    7c479db01135:	xchg   esi,edi
    7c479db01137:	(bad)
    7c479db01138:	add    BYTE PTR [rax],al
    7c479db0113a:	jmp    r11
    7c479db0113d:	mov    r13d,0x4102b8
    7c479db01143:	mov    QWORD PTR [r12+0x100],r13
    7c479db0114b:	mov    r11,QWORD PTR [rsp]
    7c479db0114f:	mov    QWORD PTR [r12+0x398],r11
    7c479db01157:	mov    edi,0x4102b8
    7c479db0115c:	mov    QWORD PTR [r12+0x100],rdi
    7c479db01164:	add    rsp,0x10
    7c479db01168:	jmp    QWORD PTR [rip+0x2]        # 0x7c479db01170
    7c479db0116e:	xchg   ax,ax
    7c479db01170:	adc    BYTE PTR [rax+0x7c479d],sil
    7c479db01177:	add    BYTE PTR [rax+0x479db011],al
    7c479db0117d:	jl     0x7c479db0117f
    7c479db0117f:	add    BYTE PTR [rcx-0x45],cl
    7c479db01182:	rex jns 0x7c479db011b7
    7c479db01185:	xchg   esi,edi
    7c479db01187:	(bad)
    7c479db01188:	add    BYTE PTR [rax],al
    7c479db0118a:	jmp    r11
    7c479db0118d:	mov    eax,0x4102d0
    7c479db01192:	mov    QWORD PTR [r12+0x100],rax
    7c479db0119a:	push   rdx
    7c479db0119b:	push   rsi
    7c479db0119c:	push   r10
    7c479db0119e:	push   r11
    7c479db011a0:	mov    r11,rax
    7c479db011a3:	lahf
    7c479db011a4:	seto   al
    7c479db011a7:	mov    WORD PTR [rsp+0x20],ax
    7c479db011ac:	mov    rax,r11
    7c479db011af:	mov    rdx,QWORD PTR [rsp+0x20]
    7c479db011b4:	mov    r10d,edx
    7c479db011b7:	and    r10d,0xc000
    7c479db011be:	shl    r10d,0x10
    7c479db011c2:	mov    r11d,edx
    7c479db011c5:	and    r11d,0x100
    7c479db011cc:	shl    r11d,0x15
    7c479db011d0:	or     r10d,r11d
    7c479db011d3:	and    edx,0x1
    7c479db011d6:	shl    edx,0x1c
    7c479db011d9:	or     r10d,edx
    7c479db011dc:	btc    r10,0x1d
    7c479db011e1:	mov    r11d,0xf0000000
    7c479db011e7:	and    r11,r10
    7c479db011ea:	movabs rsi,0xffffffff0fffffff
    7c479db011f4:	and    rbx,rsi
    7c479db011f7:	or     rbx,r11
    7c479db011fa:	pop    r11
    7c479db011fc:	pop    r10
    7c479db011fe:	pop    rsi
    7c479db011ff:	pop    rdx
    7c479db01200:	mov    QWORD PTR [r12+0x108],rbx
    7c479db01208:	add    rsp,0x10
    7c479db0120c:	mov    eax,0xc
    7c479db01211:	movabs r11,0x62fe87327ca0
    7c479db0121b:	jmp    r11
    7c479db0121e:	nop
    7c479db0121f:	nop
