
/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112/final-samples/compute/swiftvm/2/7.bin:     file format binary


Disassembly of section .data:

0000730a04101910 <.data>:
    730a04101910:	sub    rsp,0x10
    730a04101914:	mov    r11,QWORD PTR [r12+0x398]
    730a0410191c:	mov    QWORD PTR [rsp],r11
    730a04101920:	mov    r13,QWORD PTR [r12+0xa0]
    730a04101928:	mov    r14,r13
    730a0410192b:	shl    r14,0x2
    730a0410192f:	mov    r15,QWORD PTR [r12+0x98]
    730a04101937:	add    r15,r14
    730a0410193a:	mov    r14d,DWORD PTR [r12]
    730a0410193e:	mov    DWORD PTR [r15],r14d
    730a04101941:	mov    r14d,0x0
    730a04101947:	mov    DWORD PTR [r12+0x32c],r14d
    730a0410194f:	add    r13,0x1
    730a04101953:	mov    QWORD PTR [r12+0xa0],r13
    730a0410195b:	sub    r13,0x400
    730a04101962:	mov    rcx,QWORD PTR [r12+0x380]
    730a0410196a:	jrcxz  0x730a04101971
    730a0410196c:	jmp    0x730a04101d4d
    730a04101971:	jne    0x730a0410198a
    730a04101977:	mov    r11,rax
    730a0410197a:	lahf
    730a0410197b:	seto   al
    730a0410197e:	mov    WORD PTR [rsp],ax
    730a04101982:	mov    rax,r11
    730a04101985:	jmp    0x730a0410199d
    730a0410198a:	mov    r11,rax
    730a0410198d:	lahf
    730a0410198e:	seto   al
    730a04101991:	mov    WORD PTR [rsp],ax
    730a04101995:	mov    rax,r11
    730a04101998:	jmp    0x730a04101cdd
    730a0410199d:	mov    r13d,0x1
    730a041019a3:	mov    QWORD PTR [r12+0x40],r13
    730a041019a8:	mov    r11,rax
    730a041019ab:	movzx  eax,WORD PTR [rsp]
    730a041019af:	add    al,0x7f
    730a041019b1:	sahf
    730a041019b2:	mov    rax,r11
    730a041019b5:	jmp    0x730a041019ba
    730a041019ba:	mov    r13,QWORD PTR [r12+0x40]
    730a041019bf:	mov    r14,r13
    730a041019c2:	lea    r14,[r14*4+0x0]
    730a041019ca:	mov    r15,QWORD PTR [r12+0x98]
    730a041019d2:	mov    r11,rax
    730a041019d5:	lahf
    730a041019d6:	seto   al
    730a041019d9:	mov    WORD PTR [rsp],ax
    730a041019dd:	mov    rax,r11
    730a041019e0:	add    r15,r14
    730a041019e3:	mov    r14d,DWORD PTR [r15]
    730a041019e6:	mov    QWORD PTR [r12+0x48],r14
    730a041019eb:	mov    r14d,0x0
    730a041019f1:	or     r14,r13
    730a041019f4:	mov    QWORD PTR [r12+0x50],r14
    730a041019f9:	jmp    0x730a041019fe
    730a041019fe:	mov    r13d,DWORD PTR [r12+0x50]
    730a04101a03:	sub    r13d,0x1
    730a04101a07:	mov    QWORD PTR [r12+0x58],r13
    730a04101a0c:	mov    ecx,0xffffffff
    730a04101a11:	mov    r14,r13
    730a04101a14:	and    r14,rcx
    730a04101a17:	shl    r14,0x2
    730a04101a1b:	mov    r13,QWORD PTR [r12+0x98]
    730a04101a23:	add    r13,r14
    730a04101a26:	mov    r14d,DWORD PTR [r13+0x0]
    730a04101a2a:	mov    QWORD PTR [r12+0x60],r14
    730a04101a2f:	mov    r13d,DWORD PTR [r12+0x48]
    730a04101a34:	sub    r14d,r13d
    730a04101a37:	mov    rcx,QWORD PTR [r12+0x380]
    730a04101a3f:	jrcxz  0x730a04101a46
    730a04101a41:	jmp    0x730a04101dde
    730a04101a46:	jbe    0x730a04101a5f
    730a04101a4c:	mov    r11,rax
    730a04101a4f:	lahf
    730a04101a50:	seto   al
    730a04101a53:	mov    WORD PTR [rsp],ax
    730a04101a57:	mov    rax,r11
    730a04101a5a:	jmp    0x730a04101a72
    730a04101a5f:	mov    r11,rax
    730a04101a62:	lahf
    730a04101a63:	seto   al
    730a04101a66:	mov    WORD PTR [rsp],ax
    730a04101a6a:	mov    rax,r11
    730a04101a6d:	jmp    0x730a04101af1
    730a04101a72:	mov    r13,QWORD PTR [r12+0x50]
    730a04101a77:	mov    r14,r13
    730a04101a7a:	shl    r14,0x2
    730a04101a7e:	mov    r15,QWORD PTR [r12+0x98]
    730a04101a86:	add    r15,r14
    730a04101a89:	mov    r14d,DWORD PTR [r12+0x60]
    730a04101a8e:	mov    DWORD PTR [r15],r14d
    730a04101a91:	mov    r14d,0x0
    730a04101a97:	mov    DWORD PTR [r12+0x32c],r14d
    730a04101a9f:	sub    r13,0x1
    730a04101aa3:	mov    QWORD PTR [r12+0x50],r13
    730a04101aa8:	mov    rcx,QWORD PTR [r12+0x380]
    730a04101ab0:	jrcxz  0x730a04101ab7
    730a04101ab2:	jmp    0x730a04101e6f
    730a04101ab7:	mov    r13,QWORD PTR [r12+0x58]
    730a04101abc:	mov    rax,r13
    730a04101abf:	test   rax,rax
    730a04101ac2:	jne    0x730a041019fe
    730a04101ac8:	jmp    0x730a04101acd
    730a04101acd:	mov    rcx,QWORD PTR [r12+0x380]
    730a04101ad5:	jrcxz  0x730a04101adc
    730a04101ad7:	jmp    0x730a04101ef1
    730a04101adc:	jmp    0x730a04101ae1
    730a04101ae1:	mov    r13d,0x0
    730a04101ae7:	mov    QWORD PTR [r12+0x50],r13
    730a04101aec:	jmp    0x730a04101af1
    730a04101af1:	mov    r13,QWORD PTR [r12+0x40]
    730a04101af6:	add    r13,0x1
    730a04101afa:	mov    QWORD PTR [r12+0x40],r13
    730a04101aff:	mov    r14,QWORD PTR [r12+0x50]
    730a04101b04:	mov    ecx,0xffffffff
    730a04101b09:	and    r14,rcx
    730a04101b0c:	shl    r14,0x2
    730a04101b10:	mov    r15,QWORD PTR [r12+0x98]
    730a04101b18:	add    r15,r14
    730a04101b1b:	mov    r14d,DWORD PTR [r12+0x48]
    730a04101b20:	mov    DWORD PTR [r15],r14d
    730a04101b23:	mov    r14d,0x0
    730a04101b29:	mov    DWORD PTR [r12+0x32c],r14d
    730a04101b31:	sub    r13,0x400
    730a04101b38:	jne    0x730a041019ba
    730a04101b3e:	mov    r11,rax
    730a04101b41:	lahf
    730a04101b42:	seto   al
    730a04101b45:	mov    WORD PTR [rsp],ax
    730a04101b49:	mov    rax,r11
    730a04101b4c:	jmp    0x730a04101b51
    730a04101b51:	mov    r13d,0x430000
    730a04101b57:	mov    QWORD PTR [r12+0x40],r13
    730a04101b5c:	mov    r13d,0x0
    730a04101b62:	mov    QWORD PTR [r12+0x58],r13
    730a04101b67:	mov    r13d,0x0
    730a04101b6d:	mov    QWORD PTR [r12+0x50],r13
    730a04101b72:	mov    r13d,0x430cb0
    730a04101b78:	mov    r14,QWORD PTR [r13+0x0]
    730a04101b7c:	mov    QWORD PTR [r12+0x48],r14
    730a04101b81:	jmp    0x730a04101b86
    730a04101b86:	mov    r13,QWORD PTR [r12+0x58]
    730a04101b8b:	mov    r14,r13
    730a04101b8e:	shl    r14,0x2
    730a04101b92:	mov    r15,QWORD PTR [r12+0x98]
    730a04101b9a:	add    r15,r14
    730a04101b9d:	mov    QWORD PTR [r12+0x60],r15
    730a04101ba2:	mov    r14,r15
    730a04101ba5:	add    r14,0x4
    730a04101ba9:	mov    ebp,DWORD PTR [r15]
    730a04101bac:	mov    r15d,DWORD PTR [r14]
    730a04101baf:	mov    QWORD PTR [r12+0x60],r15
    730a04101bb4:	mov    r14,rbp
    730a04101bb7:	imul   r14,r13
    730a04101bbb:	mov    r8,rbp
    730a04101bbe:	add    r8,r14
    730a04101bc1:	mov    QWORD PTR [r12+0x68],r8
    730a04101bc6:	add    r13,0x2
    730a04101bca:	mov    QWORD PTR [r12+0x58],r13
    730a04101bcf:	mov    r14,r13
    730a04101bd2:	sub    r14,0x400
    730a04101bd9:	mov    r14,QWORD PTR [r12+0x50]
    730a04101bde:	setne  BYTE PTR [rsp+0x8]
    730a04101be3:	mov    r11,rax
    730a04101be6:	lahf
    730a04101be7:	seto   al
    730a04101bea:	mov    WORD PTR [rsp],ax
    730a04101bee:	mov    rax,r11
    730a04101bf1:	imul   r13,r15
    730a04101bf5:	add    r14,r13
    730a04101bf8:	mov    QWORD PTR [r12+0x50],r14
    730a04101bfd:	mov    r13,QWORD PTR [r12+0x48]
    730a04101c02:	add    r8,r13
    730a04101c05:	mov    QWORD PTR [r12+0x48],r8
    730a04101c0a:	mov    rcx,QWORD PTR [r12+0x380]
    730a04101c12:	jrcxz  0x730a04101c19
    730a04101c14:	jmp    0x730a04101f73
    730a04101c19:	cmp    BYTE PTR [rsp+0x8],0x0
    730a04101c1e:	jne    0x730a04101b86
    730a04101c24:	jmp    0x730a04101c29
    730a04101c29:	mov    r13d,0x0
    730a04101c2f:	mov    QWORD PTR [r12+0x98],r13
    730a04101c37:	mov    r13,QWORD PTR [r12+0x48]
    730a04101c3c:	mov    r14,QWORD PTR [r12+0x50]
    730a04101c41:	add    r14,r13
    730a04101c44:	mov    QWORD PTR [r12+0x48],r14
    730a04101c49:	mov    r13d,0x1
    730a04101c4f:	mov    QWORD PTR [r12],r13
    730a04101c53:	mov    r13,QWORD PTR [r12+0x40]
    730a04101c58:	add    r13,0xcb0
    730a04101c5f:	mov    QWORD PTR [r13+0x0],r14
    730a04101c63:	mov    r13d,0x0
    730a04101c69:	mov    DWORD PTR [r12+0x32c],r13d
    730a04101c71:	mov    r13d,0x1
    730a04101c77:	mov    QWORD PTR [r12],r13
    730a04101c7b:	mov    r13d,0x4103f8
    730a04101c81:	mov    QWORD PTR [r12+0xf0],r13
    730a04101c89:	mov    r13d,0x4109a4
    730a04101c8f:	mov    QWORD PTR [r12+0x100],r13
    730a04101c97:	mov    r11,QWORD PTR [rsp]
    730a04101c9b:	mov    QWORD PTR [r12+0x398],r11
    730a04101ca3:	mov    edi,0x4109a4
    730a04101ca8:	mov    QWORD PTR [r12+0x100],rdi
    730a04101cb0:	add    rsp,0x10
    730a04101cb4:	nop    DWORD PTR [rax+0x0]
    730a04101cb8:	jmp    QWORD PTR [rip+0x2]        # 0x730a04101cc0
    730a04101cbe:	xchg   ax,ax
    730a04101cc0:	rex (bad)
    730a04101cc2:	adc    BYTE PTR [rdx+rcx*1],al
    730a04101cc5:	jae    0x730a04101cc7
    730a04101cc7:	add    al,dl
    730a04101cc9:	sbb    al,0x10
    730a04101ccb:	add    al,0xa
    730a04101ccd:	jae    0x730a04101ccf
    730a04101ccf:	add    BYTE PTR [rcx-0x45],cl
    730a04101cd2:	rex leave
    730a04101cd4:	ret    0x91a9
    730a04101cd7:	push   rbp
    730a04101cd8:	add    BYTE PTR [rax],al
    730a04101cda:	jmp    r11
    730a04101cdd:	mov    r13d,DWORD PTR [r12+0xa0]
    730a04101ce5:	add    r13d,0x11
    730a04101ce9:	mov    QWORD PTR [r12],r13
    730a04101ced:	mov    r13d,0x41035c
    730a04101cf3:	mov    QWORD PTR [r12+0xf0],r13
    730a04101cfb:	mov    r13d,0x4109a4
    730a04101d01:	mov    QWORD PTR [r12+0x100],r13
    730a04101d09:	mov    r11,QWORD PTR [rsp]
    730a04101d0d:	mov    QWORD PTR [r12+0x398],r11
    730a04101d15:	mov    edi,0x4109a4
    730a04101d1a:	mov    QWORD PTR [r12+0x100],rdi
    730a04101d22:	add    rsp,0x10
    730a04101d26:	xchg   ax,ax
    730a04101d28:	jmp    QWORD PTR [rip+0x2]        # 0x730a04101d30
    730a04101d2e:	xchg   ax,ax
    730a04101d30:	rex (bad)
    730a04101d32:	adc    BYTE PTR [rdx+rcx*1],al
    730a04101d35:	jae    0x730a04101d37
    730a04101d37:	add    BYTE PTR [rax+0x1d],al
    730a04101d3a:	adc    BYTE PTR [rdx+rcx*1],al
    730a04101d3d:	jae    0x730a04101d3f
    730a04101d3f:	add    BYTE PTR [rcx-0x45],cl
    730a04101d42:	rex leave
    730a04101d44:	ret    0x91a9
    730a04101d47:	push   rbp
    730a04101d48:	add    BYTE PTR [rax],al
    730a04101d4a:	jmp    r11
    730a04101d4d:	mov    eax,0x410368
    730a04101d52:	mov    QWORD PTR [r12+0x100],rax
    730a04101d5a:	push   rdx
    730a04101d5b:	push   rsi
    730a04101d5c:	push   r10
    730a04101d5e:	push   r11
    730a04101d60:	mov    r11,rax
    730a04101d63:	lahf
    730a04101d64:	seto   al
    730a04101d67:	mov    WORD PTR [rsp+0x20],ax
    730a04101d6c:	mov    rax,r11
    730a04101d6f:	mov    rdx,QWORD PTR [rsp+0x20]
    730a04101d74:	mov    r10d,edx
    730a04101d77:	and    r10d,0xc000
    730a04101d7e:	shl    r10d,0x10
    730a04101d82:	mov    r11d,edx
    730a04101d85:	and    r11d,0x100
    730a04101d8c:	shl    r11d,0x15
    730a04101d90:	or     r10d,r11d
    730a04101d93:	and    edx,0x1
    730a04101d96:	shl    edx,0x1c
    730a04101d99:	or     r10d,edx
    730a04101d9c:	btc    r10,0x1d
    730a04101da1:	mov    r11d,0xf0000000
    730a04101da7:	and    r11,r10
    730a04101daa:	movabs rsi,0xffffffff0fffffff
    730a04101db4:	and    rbx,rsi
    730a04101db7:	or     rbx,r11
    730a04101dba:	pop    r11
    730a04101dbc:	pop    r10
    730a04101dbe:	pop    rsi
    730a04101dbf:	pop    rdx
    730a04101dc0:	mov    QWORD PTR [r12+0x108],rbx
    730a04101dc8:	add    rsp,0x10
    730a04101dcc:	mov    eax,0xc
    730a04101dd1:	movabs r11,0x5591a9c2cca0
    730a04101ddb:	jmp    r11
    730a04101dde:	mov    eax,0x41039c
    730a04101de3:	mov    QWORD PTR [r12+0x100],rax
    730a04101deb:	push   rdx
    730a04101dec:	push   rsi
    730a04101ded:	push   r10
    730a04101def:	push   r11
    730a04101df1:	mov    r11,rax
    730a04101df4:	lahf
    730a04101df5:	seto   al
    730a04101df8:	mov    WORD PTR [rsp+0x20],ax
    730a04101dfd:	mov    rax,r11
    730a04101e00:	mov    rdx,QWORD PTR [rsp+0x20]
    730a04101e05:	mov    r10d,edx
    730a04101e08:	and    r10d,0xc000
    730a04101e0f:	shl    r10d,0x10
    730a04101e13:	mov    r11d,edx
    730a04101e16:	and    r11d,0x100
    730a04101e1d:	shl    r11d,0x15
    730a04101e21:	or     r10d,r11d
    730a04101e24:	and    edx,0x1
    730a04101e27:	shl    edx,0x1c
    730a04101e2a:	or     r10d,edx
    730a04101e2d:	btc    r10,0x1d
    730a04101e32:	mov    r11d,0xf0000000
    730a04101e38:	and    r11,r10
    730a04101e3b:	movabs rsi,0xffffffff0fffffff
    730a04101e45:	and    rbx,rsi
    730a04101e48:	or     rbx,r11
    730a04101e4b:	pop    r11
    730a04101e4d:	pop    r10
    730a04101e4f:	pop    rsi
    730a04101e50:	pop    rdx
    730a04101e51:	mov    QWORD PTR [r12+0x108],rbx
    730a04101e59:	add    rsp,0x10
    730a04101e5d:	mov    eax,0xc
    730a04101e62:	movabs r11,0x5591a9c2cca0
    730a04101e6c:	jmp    r11
    730a04101e6f:	mov    eax,0x4103a8
    730a04101e74:	mov    QWORD PTR [r12+0x100],rax
    730a04101e7c:	push   rdx
    730a04101e7d:	push   rsi
    730a04101e7e:	push   r10
    730a04101e80:	push   r11
    730a04101e82:	mov    rdx,QWORD PTR [rsp+0x20]
    730a04101e87:	mov    r10d,edx
    730a04101e8a:	and    r10d,0xc000
    730a04101e91:	shl    r10d,0x10
    730a04101e95:	mov    r11d,edx
    730a04101e98:	and    r11d,0x100
    730a04101e9f:	shl    r11d,0x15
    730a04101ea3:	or     r10d,r11d
    730a04101ea6:	and    edx,0x1
    730a04101ea9:	shl    edx,0x1c
    730a04101eac:	or     r10d,edx
    730a04101eaf:	btc    r10,0x1d
    730a04101eb4:	mov    r11d,0xf0000000
    730a04101eba:	and    r11,r10
    730a04101ebd:	movabs rsi,0xffffffff0fffffff
    730a04101ec7:	and    rbx,rsi
    730a04101eca:	or     rbx,r11
    730a04101ecd:	pop    r11
    730a04101ecf:	pop    r10
    730a04101ed1:	pop    rsi
    730a04101ed2:	pop    rdx
    730a04101ed3:	mov    QWORD PTR [r12+0x108],rbx
    730a04101edb:	add    rsp,0x10
    730a04101edf:	mov    eax,0xc
    730a04101ee4:	movabs r11,0x5591a9c2cca0
    730a04101eee:	jmp    r11
    730a04101ef1:	mov    eax,0x4103ac
    730a04101ef6:	mov    QWORD PTR [r12+0x100],rax
    730a04101efe:	push   rdx
    730a04101eff:	push   rsi
    730a04101f00:	push   r10
    730a04101f02:	push   r11
    730a04101f04:	mov    rdx,QWORD PTR [rsp+0x20]
    730a04101f09:	mov    r10d,edx
    730a04101f0c:	and    r10d,0xc000
    730a04101f13:	shl    r10d,0x10
    730a04101f17:	mov    r11d,edx
    730a04101f1a:	and    r11d,0x100
    730a04101f21:	shl    r11d,0x15
    730a04101f25:	or     r10d,r11d
    730a04101f28:	and    edx,0x1
    730a04101f2b:	shl    edx,0x1c
    730a04101f2e:	or     r10d,edx
    730a04101f31:	btc    r10,0x1d
    730a04101f36:	mov    r11d,0xf0000000
    730a04101f3c:	and    r11,r10
    730a04101f3f:	movabs rsi,0xffffffff0fffffff
    730a04101f49:	and    rbx,rsi
    730a04101f4c:	or     rbx,r11
    730a04101f4f:	pop    r11
    730a04101f51:	pop    r10
    730a04101f53:	pop    rsi
    730a04101f54:	pop    rdx
    730a04101f55:	mov    QWORD PTR [r12+0x108],rbx
    730a04101f5d:	add    rsp,0x10
    730a04101f61:	mov    eax,0xc
    730a04101f66:	movabs r11,0x5591a9c2cca0
    730a04101f70:	jmp    r11
    730a04101f73:	mov    eax,0x4103dc
    730a04101f78:	mov    QWORD PTR [r12+0x100],rax
    730a04101f80:	push   rdx
    730a04101f81:	push   rsi
    730a04101f82:	push   r10
    730a04101f84:	push   r11
    730a04101f86:	mov    rdx,QWORD PTR [rsp+0x20]
    730a04101f8b:	mov    r10d,edx
    730a04101f8e:	and    r10d,0xc000
    730a04101f95:	shl    r10d,0x10
    730a04101f99:	mov    r11d,edx
    730a04101f9c:	and    r11d,0x100
    730a04101fa3:	shl    r11d,0x15
    730a04101fa7:	or     r10d,r11d
    730a04101faa:	and    edx,0x1
    730a04101fad:	shl    edx,0x1c
    730a04101fb0:	or     r10d,edx
    730a04101fb3:	btc    r10,0x1d
    730a04101fb8:	mov    r11d,0xf0000000
    730a04101fbe:	and    r11,r10
    730a04101fc1:	movabs rsi,0xffffffff0fffffff
    730a04101fcb:	and    rbx,rsi
    730a04101fce:	or     rbx,r11
    730a04101fd1:	pop    r11
    730a04101fd3:	pop    r10
    730a04101fd5:	pop    rsi
    730a04101fd6:	pop    rdx
    730a04101fd7:	mov    QWORD PTR [r12+0x108],rbx
    730a04101fdf:	add    rsp,0x10
    730a04101fe3:	mov    eax,0xc
    730a04101fe8:	movabs r11,0x5591a9c2cca0
    730a04101ff2:	jmp    r11
    730a04101ff5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04102000:	sub    rsp,0x10
    730a04102004:	mov    r11,QWORD PTR [r12+0x398]
    730a0410200c:	mov    QWORD PTR [rsp],r11
    730a04102010:	jmp    0x730a0410199d
    730a04102015:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04102020:	sub    rsp,0x10
    730a04102024:	mov    r11,QWORD PTR [r12+0x398]
    730a0410202c:	mov    QWORD PTR [rsp],r11
    730a04102030:	mov    r11,rax
    730a04102033:	movzx  eax,WORD PTR [rsp]
    730a04102037:	add    al,0x7f
    730a04102039:	sahf
    730a0410203a:	mov    rax,r11
    730a0410203d:	jmp    0x730a041019ba
    730a04102042:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04102050:	sub    rsp,0x10
    730a04102054:	mov    r11,QWORD PTR [r12+0x398]
    730a0410205c:	mov    QWORD PTR [rsp],r11
    730a04102060:	jmp    0x730a041019fe
    730a04102065:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04102070:	sub    rsp,0x10
    730a04102074:	mov    r11,QWORD PTR [r12+0x398]
    730a0410207c:	mov    QWORD PTR [rsp],r11
    730a04102080:	jmp    0x730a04101a72
    730a04102085:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04102090:	sub    rsp,0x10
    730a04102094:	mov    r11,QWORD PTR [r12+0x398]
    730a0410209c:	mov    QWORD PTR [rsp],r11
    730a041020a0:	jmp    0x730a04101acd
    730a041020a5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a041020b0:	sub    rsp,0x10
    730a041020b4:	mov    r11,QWORD PTR [r12+0x398]
    730a041020bc:	mov    QWORD PTR [rsp],r11
    730a041020c0:	jmp    0x730a04101ae1
    730a041020c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a041020d0:	sub    rsp,0x10
    730a041020d4:	mov    r11,QWORD PTR [r12+0x398]
    730a041020dc:	mov    QWORD PTR [rsp],r11
    730a041020e0:	jmp    0x730a04101af1
    730a041020e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a041020f0:	sub    rsp,0x10
    730a041020f4:	mov    r11,QWORD PTR [r12+0x398]
    730a041020fc:	mov    QWORD PTR [rsp],r11
    730a04102100:	jmp    0x730a04101b51
    730a04102105:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04102110:	sub    rsp,0x10
    730a04102114:	mov    r11,QWORD PTR [r12+0x398]
    730a0410211c:	mov    QWORD PTR [rsp],r11
    730a04102120:	jmp    0x730a04101b86
    730a04102125:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04102130:	sub    rsp,0x10
    730a04102134:	mov    r11,QWORD PTR [r12+0x398]
    730a0410213c:	mov    QWORD PTR [rsp],r11
    730a04102140:	jmp    0x730a04101c29
    730a04102145:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    730a04102150:	sub    rsp,0x10
    730a04102154:	mov    r11,QWORD PTR [r12+0x398]
    730a0410215c:	mov    QWORD PTR [rsp],r11
    730a04102160:	jmp    0x730a04101cdd
    730a04102165:	nop
    730a04102166:	nop
    730a04102167:	nop
