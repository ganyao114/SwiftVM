from pathlib import Path
import subprocess,json
w=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112');m=json.loads((w/'final-tools-build.json').read_text())
for name in ['final-probe','cache8-no-backing','cache128-no-backing']:
 x=m[name]
 with (w/(name+'-build.log')).open('w') as f:p=subprocess.run(x['argv'],cwd=x['cwd'],stdout=f,stderr=f)
 if p.returncode:raise RuntimeError(name)
 print('rebuilt',name,flush=True)
for script,log in [('measure-cache.py','cache-comparison-release.log'),('measure-pmu.py','final-pmu.log'),('measure-samples.py','final-samples.log')]:
 with (w/log).open('w') as f:p=subprocess.run(['python3',str(w/script)],stdout=f,stderr=f)
 if p.returncode:raise RuntimeError(script)
 print('refreshed',script,flush=True)
prior=json.loads((w/'pre-diagnostic-options-proof/cache-comparison-release.json').read_text())
new=json.loads((w/'cache-comparison-release.json').read_text())
assert prior['workloads']==new['workloads']
(w/'diagnostic-options-proof.json').write_text(json.dumps({'matched_allocation_counts':True,'workloads':list(new['workloads']),'fields_added':['numeric_control','fpsr']},indent=2)+'\n')
print('allocation counters match with full state field exclusions',flush=True)
