from pathlib import Path
import shutil, hashlib, json
r=Path('/mnt/d/Dev/SwiftVM'); w=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112')
prior=w/'prior-d2a-measurements'; metadata={}
for name,build in [('compare','svm_arm64_compare_bench'),('linux','svm_rebuild_linux'),('aot','svm_aot'),('correctness','svm_correctness')]:
    dest=w/('final_'+name)
    if not (prior/dest.name).exists(): shutil.copy2(dest,prior/dest.name)
    temp=dest.with_suffix('.next'); shutil.copy2(r/'build/host'/build,temp); temp.replace(dest)
    metadata[name]={'path':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}
header=r/'build/host/generated/svm/code_build_id.h'
shutil.copy2(header,w/'final_code_build_id.h')
metadata['code_build_id_header']=header.read_text()
(w/'final-build.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata))
