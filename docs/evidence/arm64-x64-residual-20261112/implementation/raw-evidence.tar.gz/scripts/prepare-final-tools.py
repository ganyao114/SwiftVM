from pathlib import Path
import json,subprocess,shutil,hashlib
r=Path('/mnt/d/Dev/SwiftVM');w=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112');old=Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112')
out=w/'final-pmu';out.mkdir(exist_ok=True)
s=(old/'final-pmu/diagnostic_runner.cpp').read_text().replace('gap::Wrap(backend);','gap::pinned_slots = options.pins; gap::Wrap(backend);')
source=out/'diagnostic_runner.cpp';source.write_text(s)
metadata={}
def build(name,argv,cwd):
 with (w/(name+'-build.log')).open('w') as f:p=subprocess.run(argv,cwd=cwd,stdout=f,stderr=f)
 if p.returncode:raise RuntimeError((w/(name+'-build.log')).read_text()[-2500:])
 metadata[name]={'cwd':str(cwd),'argv':argv}
 print('built',name,flush=True)
cmd=json.loads((old/'final-pmu/build.json').read_text())['commands']['swiftvm']['argv']
cmd=[str(source) if x.endswith('diagnostic_runner.cpp') else x for x in cmd];cmd[cmd.index('-o')+1]=str(out/'swiftvm_gap_probe')
build('final-probe',cmd,r/'build/host')
shutil.copy2(old/'final-pmu/dynarmic_gap_probe',out/'dynarmic_gap_probe')
prior=subprocess.check_output(['git','-C',str(r),'show','HEAD:source/runtime/ir/passes/rewrite.cpp'],text=True)
current=(r/'source/runtime/ir/passes/rewrite.cpp').read_text();a=prior.index('struct UniformEntry {');b=prior.index('\nstd::uint32_t CachedBytes',a);c=current.index('struct UniformEntry {');d=current.index('\nstd::uint32_t CachedBytes',c)
p=w/'final-rewrite-cache8.cpp';p.write_text(current[:c]+prior[a:b]+current[d:]);obj=w/'final-rewrite-cache8.o'
compile=['c++','-std=c++20','-O3','-DNDEBUG','-flto=auto','-I'+str(r/'source'),'-I'+str(r/'source/runtime/ir/passes'),'-c',str(p),'-o',str(obj)];build('final-cache8-object',compile,r)
p=w/'final-allocate-no-backing.cpp';p.write_text((r/'source/runtime/backend/x64/allocate.cpp').read_text().replace('        AnalyzeUniformBacking();','        // Diagnostic variant with uniform backing disabled.'))
alloc=w/'final-allocate-no-backing.o';compile=['c++','-std=c++20','-O3','-DNDEBUG','-flto=auto','-I'+str(r/'source'),'-I'+str(r/'source/runtime/backend/x64'),'-c',str(p),'-o',str(alloc)];build('final-no-backing-object',compile,r)
for name,objects in [('cache8-no-backing',[obj,alloc]),('cache128-no-backing',[alloc])]:
 variant=list(cmd);variant[variant.index('-o')+1]=str(w/(name+'_probe'));i=variant.index('libsvm_execution.a');variant[i:i]=[str(o) for o in objects];build(name,variant,r/'build/host')
for name in ['scaling','domain-probe']:
 if name=='domain-probe':shutil.copy2(old/'domain-probe.cpp',w/'domain-probe.cpp')
 argv=json.loads((old/(name+'-build.json')).read_text())['argv'];argv=[str(w/x.split('/')[-1]) if x==str(old/name) or x==str(old/(name+'.cpp')) else x for x in argv]
 build(name,argv,r/'build/host')
(w/'final-tools-build.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('all final tools built')
