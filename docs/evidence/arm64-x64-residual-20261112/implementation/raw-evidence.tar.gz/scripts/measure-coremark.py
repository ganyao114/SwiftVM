from pathlib import Path
import subprocess,json,os,re,statistics,sys
w=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112');sys.path.insert(0,'/mnt/d/Dev/SwiftVM/tools');import bench_dynarmic as b
os.sched_setaffinity(0,{2});guest=w/'coremark-warm/coremark-linux-x86_64'
runners={'old52':Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/baseline_linux'),'baseline':w/'baseline_linux','candidate':w/'final_linux'}
arguments=['0','0','0x66','500','7','1','2000'];native=subprocess.run([str(guest),*arguments],capture_output=True,check=True)
crcs=re.findall(rb'(?:seedcrc|\[0\]crc\w+)\s*:\s*(0x[0-9a-f]+)',native.stdout);assert len(crcs)==10
result={'samples':31,'warmup_invocations':1,'timed_invocations':1,'iterations':500,'tick_unit':'microseconds','runners':{k:{'path':str(p),'sha256':b.digest(p)} for k,p in runners.items()},'guest':{'path':str(guest),'sha256':b.digest(guest),'argv':arguments},'native_stdout':native.stdout.decode(),'measurements':{k:[] for k in runners}}
for sample in range(31):
 order=list(runners);order=order[sample%3:]+order[:sample%3]
 if sample%2:order.reverse()
 for key in order:
  p=subprocess.run([str(runners[key]),'--scope','function','--pin-slots','0',str(guest),*arguments],capture_output=True,timeout=90)
  assert p.returncode==0,p.stderr[-1500:];assert re.findall(rb'(?:seedcrc|\[0\]crc\w+)\s*:\s*(0x[0-9a-f]+)',p.stdout)==crcs,(key,p.stdout)
  ticks=[int(x) for x in re.findall(rb'Total ticks\s*:\s*(\d+)',p.stdout)];assert len(ticks)==2
  metrics=next(json.loads(s) for s in p.stderr.decode().splitlines() if 'measurement_kind' in s);assert not metrics['interpreted_steps'] and not metrics['fallbacks']
  result['measurements'][key].append({'warm_ticks_us':ticks[-1],'first_ticks_us':ticks[0],'metrics':metrics,'stdout':p.stdout.decode()})
result['medians_us']={k:statistics.median(v['warm_ticks_us'] for v in rows) for k,rows in result['measurements'].items()}
result['candidate_over']={k:b.distribution([a['warm_ticks_us']/c['warm_ticks_us'] for a,c in zip(result['measurements']['candidate'],result['measurements'][k])]) for k in ['old52','baseline']}
(w/'coremark-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(result['medians_us'],result['candidate_over'],flush=True)
