from pathlib import Path
import collections,json,re,sys
r=Path('/mnt/d/Dev/SwiftVM');w=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112');dest=r/'docs/evidence/arm64-x64-residual-20261112/implementation'
s=json.loads((dest/'summary.json').read_text());sys.path.insert(0,str(r/'tools'));import summarize_dynarmic_gap as diag
for name,load in s['benchmarks']['workloads'].items():assert load['candidate_over']['baseline']['median']<=1.02,name
assert s['compile_cost']['medians']['candidate']['compile_ns']/s['compile_cost']['medians']['baseline']['compile_ns']<=1.03
assert s['coremark']['candidate_over']['old52']['median']<=1
assert s['benchmarks']['runners']['candidate']['sha256']==s['build']['compare']['sha256']
assert s['validation']['arm']['binary_sha256']==s['build']['correctness']['sha256']
shapes={}
def save(name,unit,path,**extra):
 data={'unit':unit,'instructions':len(path),'path':path,**extra};shapes[name]=data
 start=path[0][0];text=f'{name}, unit {unit}, {len(path)} ordinary-path instructions\n'
 text+='\n'.join(f'+{a-start:04x} {t}' for a,t in path)+'\n';(dest/f'{name}-hot-paths.txt').write_text(text)

folder=w/'final-pmu/records/compute-matrix/candidate/0';candidates=[]
for row in (folder/'maps.tsv').read_text().splitlines():
 unit,*unused=row.split();code=diag.disassemble(folder/f'{unit}.bin')
 for end,t in code:
  m=re.match(r'jne\s+0x([0-9a-f]+)$',t)
  if not m:continue
  begin=int(m[1],16)
  if begin>=end:continue
  count=sum(t.split()[0] in ['addpd','mulpd','subpd','addps','mulps','subps'] for a,t in code if begin<=a<=end)
  if count==64:candidates.append((end-begin,unit,code,begin,end))
_,unit,code,begin,end=min(candidates,key=lambda x:x[0]);entries=dict(code);nxt={a:code[i+1][0] for i,(a,t) in enumerate(code[:-1])};cursor=begin;path=[]
for step in range(4096):
 t=entries[cursor];path.append((cursor,t))
 if cursor==end:break
 m=re.match(r'jrcxz\s+0x([0-9a-f]+)$',t);cursor=int(m[1],16) if m else nxt[cursor]
else:raise RuntimeError('matrix loop')
assert len(path)/64<=20
assert not any(t.split()[0] in ['stmxcsr','ldmxcsr'] for a,t in path)
save('matrix',unit,path,packed_operations=64,instructions_per_packed=len(path)/64)

folder=w/'final-pmu/records/compute-sort/candidate/0';found=False
for row in (folder/'maps.tsv').read_text().splitlines():
 unit,*unused=row.split();code=diag.disassemble(folder/f'{unit}.bin');entries=dict(code);nxt={a:code[i+1][0] for i,(a,t) in enumerate(code[:-1])}
 for i,(end,t) in enumerate(code):
  if not re.match(r'(ja|jbe|jg|jle)\s',t):continue
  starts=[a for a,t in code[max(0,i-12):i] if t.split()[0] in ['cmp','sub']]
  if not starts:continue
  cursor=starts[-1];path=[]
  for step in range(16):
   t=entries[cursor];path.append((cursor,t))
   if cursor==end:break
   m=re.match(r'jrcxz\s+0x([0-9a-f]+)$',t);cursor=int(m[1],16) if m else nxt[cursor]
  if cursor!=end:continue
  assert len(path)<=4
  save('sort',unit,path);found=True;break
 if found:break
assert found
for name in ['memory','fp']:
 path=s['hot_paths'][name]['candidate']['path'];assert not any(t.split()[0] in ['pushf','popf','stmxcsr','ldmxcsr'] for a,t in path)
assert not any(s['static_instructions']['compute-sha']['candidate'].get(m,0) for m in ['pushf','popf'])
assert s['hot_paths']['memory']['candidate']['instructions']<=15
s['hot_shape_validation']=shapes
s['gates']={'all_15_paired_hot_medians_le_1_02':True,'cold_compile_total_le_1_03':True,'x86_coremark_le_old52':True,'matrix_hot_instructions_per_packed_le_20':True,'sort_compare_branch_instructions_le_4':True,'memory_hot_instructions_le_15':True}
(dest/'summary.json').write_text(json.dumps(s,indent=2)+'\n');(w/'hot-shape-validation.json').write_text(json.dumps(shapes,indent=2)+'\n')
print('all performance and code-shape gates passed', {n:x['instructions'] for n,x in shapes.items()})
