from pathlib import Path
import json,sys,os
W=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112');sys.path.insert(0,'/mnt/d/Dev/SwiftVM/tools');import bench_dynarmic as b
os.sched_setaffinity(0,{2});guests=json.loads((W/'final-bench-summary.json').read_text())['workloads'];rows={}
for name in ['integer','memory','shift','fp','compute','compute-matrix','compute-sha','compute-sort']:
 rows[name]={}
 for key in ['swiftvm','dynarmic']:
  rows[name][key]=[]
  for i in range(3):
   d=W/'final-samples'/name/key/str(i);d.mkdir(parents=True,exist_ok=False);os.environ['SVM_GAP_OUT']=str(d);os.environ['SVM_GAP_SAMPLE']='1'
   row=b.launch(W/'final-pmu'/f'{key}_gap_probe',{'engine':key,'scope':'function' if key=='swiftvm' else 'block','pins':0},guests[name]['guest'],60);row['directory']=str(d);rows[name][key].append(row)
 (W/'sample-runs.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,'sampled',flush=True)
