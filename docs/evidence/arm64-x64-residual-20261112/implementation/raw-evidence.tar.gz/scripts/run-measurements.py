from pathlib import Path
import json,subprocess,hashlib,time,os
w=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112');os.sched_setaffinity(0,{2});records=[]
for script,log in [('measure-final.py','final-bench.log'),('measure-compile.py','compile-program.log'),('measure-cache.py','cache-comparison-release.log'),('measure-pmu.py','final-pmu.log'),('measure-samples.py','final-samples.log'),('measure-supplementary.py','supplementary.log'),('measure-coremark.py','coremark-final.log')]:
 print('starting',script,flush=True);start=time.time()
 with (w/log).open('w') as f:p=subprocess.run(['python3',str(w/script)],stdout=f,stderr=f)
 records.append({'script':script,'source_sha256':hashlib.sha256((w/script).read_bytes()).hexdigest(),'start_unix':start,'end_unix':time.time(),'exit_code':p.returncode});(w/'measurement-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 if p.returncode:raise RuntimeError((w/log).read_text()[-3000:])
 print('completed',script,flush=True)
for kind,base in [('baseline',Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/scaling')),('candidate',w/'scaling')]:
 for sample in range(3):
  with (w/f'scaling-{kind}-{sample}.jsonl').open('w') as f:subprocess.run([str(base)],stdout=f,check=True)
for sample in range(9):
 with (w/f'domain-probe-final-{sample}.jsonl').open('w') as f:subprocess.run([str(w/'domain-probe')],stdout=f,check=True)
print('all measurements complete',flush=True)
