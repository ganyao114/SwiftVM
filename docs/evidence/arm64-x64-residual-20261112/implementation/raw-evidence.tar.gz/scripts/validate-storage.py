from pathlib import Path
import subprocess,concurrent.futures,time,json
w=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112')
def run(item):
    name,argv=item
    with (w/('validation-'+name+'-storage.log')).open('w') as f: p=subprocess.run(argv,stdout=f,stderr=f)
    print(name,p.returncode,flush=True)
    return {'name':name,'argv':argv,'exit_code':p.returncode}
items=[('arm',['python3',str(w/'validate-final.py')]),('x86',['python3',str(w/'validate-x86-final.py')]),('programs',['taskset','-c','6','python3',str(w/'verify-final.py'),'programs'])]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: results=list(pool.map(run,items))
(w/'validation-storage-commands.json').write_text(json.dumps(results,indent=2)+'\n')
if any(x['exit_code'] for x in results): raise SystemExit(1)
