from pathlib import Path
import json
r=Path('/mnt/d/Dev/SwiftVM'); w=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112')
e=r/'docs/evidence/arm64-x64-residual-20261112/implementation'
s=json.loads((e/'summary.json').read_text()); b=s['benchmarks']; c=s['compile_cost']['medians']; cm=s['coremark']
def table(head,rows):
 return '\n'.join(['| '+' | '.join(head)+' |','| '+' | '.join(['---']*len(head))+' |']+['| '+' | '.join(str(v) for v in row)+' |' for row in rows])
def spread(x): return f"{x['median']:.3f} [{x['q1']:.3f}, {x['q3']:.3f}]"
names={'integer':'整数','memory':'访存','shift':'移位','fp':'浮点','compute':'综合计算','fp-u8':'浮点展开 ×8','compute-matrix':'向量矩阵','compute-matrix-scalar':'标量矩阵','compute-sha':'SHA','compute-sort':'排序','cond':'复合条件','cmpsep':'分离比较与分支','fpmix':'混合浮点','compute-fma':'综合计算 FMA','matrix-fma':'矩阵 FMA'}
values={}; rows=[]
for name,x in b['workloads'].items():
 m=x['medians_ns']; rows.append([names[name],f"{m['baseline']/1e6:.3f}",f"{m['candidate']/1e6:.3f}",f"{m['dynarmic']/1e6:.3f}",spread(x['candidate_over']['baseline'])])
values['BENCHMARKS']=table(['负载','基线 ms','候选 ms','Dynarmic ms','配对候选／基线中位数 [Q1, Q3]'],rows)
values['COREMARK']=f"最终 31 组配对的 x86 CoreMark elapsed time 中位数为旧基线 {cm['medians_us']['old52']/1000:.3f} ms、机制基线 {cm['medians_us']['baseline']/1000:.3f} ms、候选 {cm['medians_us']['candidate']/1000:.3f} ms。候选／旧基线为 {spread(cm['candidate_over']['old52'])}，候选／机制基线为 {spread(cm['candidate_over']['baseline'])}。"
rows=[]
for name,x in s['cache']['workloads'].items():
 if name not in ['compute','compute-sha','compute-matrix','compute-fma','matrix-fma']: continue
 rows.append([names[name]]+[f"{x[k]['uniform_loads']}／{x[k]['stack_spills']}／{x[k]['uniform_rematerialized']}" for k in ['cache8-no-backing','cache128-no-backing','cache128-backing']])
values['UNIFORM']=table(['负载','8 项，无 uniform 支撑','128 项，无 uniform 支撑','128 项，有 uniform 支撑'],rows)
values['HOT_PATHS']=table(['循环','基线指令／轮','候选指令／轮'],[[names[n],x['baseline']['instructions'],x['candidate']['instructions']] for n,x in s['hot_paths'].items()])
rows=[]
for key,label in [('frontend_ns','Frontend'),('optimize_ns','Optimize'),('backend_ns','Backend'),('publication_ns','Publication'),('compile_ns','冷编译总计')]:
 a,z=c['baseline'][key],c['candidate'][key];rows.append([label,f'{a/1000:.1f}',f'{z/1000:.1f}',f'{(z/a-1)*100:+.1f}%'])
values['COMPILE_COST']=table(['阶段','基线 μs','候选 μs','变化'],rows)+f"\n\n两者均产生 {c['candidate']['compile_attempts']} 次编译请求。发布代码量为 {c['baseline']['native_bytes']:,} → {c['candidate']['native_bytes']:,} 字节。总冷编译比值为 {c['candidate']['compile_ns']/c['baseline']['compile_ns']:.3f}，方案验收线为 1.03。Backend 变化单独保留，反映新增原生覆盖、flags 需求和 uniform 稳定性分析的成本。"
values['SCALING']=table(['规模 probe','N μs','2N μs','4N μs'],[[name]+[f"{x['median_compile_ns']/1000:.1f}" for x in rows] for name,rows in s['scaling']['candidate'].items()])
code_id=s['build']['code_build_id_header'].split('"')[1]
values['BUILD_ID']=f"候选 `CodeBuildId` 为 `{code_id}`。源代码指纹、宿主能力和数值域共同参与缓存身份。最终 runner、缓存和 AOT 采用同一候选构建身份，`NativeRunContext` 的字段布局沿用机制基线。[manifest](evidence/arm64-x64-residual-20261112/implementation/manifest.json)"
rows=[]
for name,items in s['scaling']['candidate'].items():
 old=s['scaling']['baseline'][name]
 rows.append([name]+[f"{a['median_compile_ns']/1000:.1f}／{z['median_compile_ns']/1000:.1f}" for a,z in zip(old,items)])
values['SCALING']=table(['规模 probe','N μs，基线／候选','2N μs，基线／候选','4N μs，基线／候选'],rows)+'\n\nN 为 256，2N 为 512，4N 为 1,024。4N 的候选／基线为 1.057—1.165，规模增长保持近线性。该组沿用裸编译接口，FP 与 cold probe 使用兼容区间路径，保留全部原始序列。'
shape=s['hot_shape_validation'];rows=[]
for name in ['fp','compute-matrix','compute-sha','compute-sort']:
 load=b['workloads'][name];counts=s['static_instructions'][name]
 rows.append([names[name]]+[load['compile'][k]['native_bytes'] for k in ['baseline','candidate']]+[f"{counts['baseline'].get(m,0)}／{counts['candidate'].get(m,0)}" for m in ['ldmxcsr','stmxcsr']])
values['HOT_ANALYSIS']=f"矩阵内层每轮有 64 条 packed 运算，普通路径共 {shape['matrix']['instructions']} 条宿主指令，平均 {shape['matrix']['instructions_per_packed']:.2f} 条／运算，热区 MXCSR 存取为零。排序比较分支路径为 SUB、事件指针装载、JRCXZ、JBE，共 4 条，原先的布尔链消除。SHA 全部发布单元和访存热循环均无 PUSHF／POPF。[矩阵热路径](evidence/arm64-x64-residual-20261112/implementation/matrix-hot-paths.txt)、[排序分支](evidence/arm64-x64-residual-20261112/implementation/sort-hot-paths.txt)\n\n下表同时计入完整单元的入口、冷路径和常量池，MXCSR 指令数量按静态反汇编统计。\n\n"+table(['负载','基线代码字节','候选代码字节','LDMXCSR 基线／候选','STMXCSR 基线／候选'],rows)+'\n\n向量矩阵的冷区与调用点保护增加发布代码量，热循环的区间切换已消除。PMU、IP 样本与冷热区二进制共同归档。'

p=r/'docs/arm64-x64-residual-optimization-results-2026-11-12.md'; text=p.read_text()
for name,value in values.items():
 marker='<!-- '+name+' -->'; assert marker in text,name;text=text.replace(marker,value)
p.write_text(text)
print('inserted',len(values),'result sections')
