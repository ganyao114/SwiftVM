from pathlib import Path
import collections, hashlib, json, re, statistics, sys, xml.etree.ElementTree as ET
r=Path('/mnt/d/Dev/SwiftVM'); w=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112')
dest=r/'docs/evidence/arm64-x64-residual-20261112/implementation'; dest.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(r/'tools')); import bench_dynarmic as bench; import summarize_dynarmic_gap as diag

def read(name): return json.loads((w/name).read_text())
def write(path,data): path.write_text(json.dumps(data,indent=2)+'\n')

correctness=read('final-correctness-summary.json')
assert sum(x['total'] for x in correctness['configs'].values())==57168
assert all(x['failures']==0 and x['native_executed']==x['total'] for x in correctness['configs'].values())
x86={scope:read(f'x86-{scope}-raw-diff.json') for scope in ['block','function']}
assert all(x['total']==639 and not x['mismatches'] for x in x86.values())
programs=read('final-programs-summary.json'); assert all(len(x['runs'])==8 for x in programs['programs'].values())
xml=ET.parse(w/'ctest-final.xml').getroot(); cases=list(xml.iter('testcase'))
skipped=[x.attrib['name'] for x in cases if x.find('skipped') is not None]
assert len(cases)==38 and len(skipped)==7 and not list(xml.iter('failure')) and not list(xml.iter('error'))
measure=read('final-bench-summary.json'); pmu=read('final-pmu-summary.json'); compile_cost=read('compile-program-summary.json'); coremark=read('coremark-summary.json')
for load in measure['workloads'].values():
 assert bench.digest(Path(load['guest']['path']))==load['guest']['sha256']
 for rows in load['measurements'].values():
  assert len(rows)==31
  assert all(x['output_verified'] and x['warm_cache_verified'] and x['fallbacks']==x['interpreted_steps']==x['data_callbacks']==0 for x in rows)
for load in pmu['workloads'].values():
 for rows in load['measurements'].values():
  assert len(rows)==7
  assert all(c['enabled_ns']==c['running_ns'] and c['running_ns']>0 for x in rows for c in x['pmu'])

profile_input={'configs':{k:{'engine':k} for k in ['swiftvm','dynarmic']},'workloads':{}}
for name,engines in read('sample-runs.json').items():
 profile_input['workloads'][name]={'measurements':{k:[{'output_directory':x['directory']} for x in rows] for k,rows in engines.items()}}
 assert all(len(rows)==3 for rows in engines.values())
write(w/'final-pmu/profile-summary.json',profile_input)
write(w/'final-pmu/build.json',{'runners':{k:{'path':str(w/'final-pmu'/f'{k}_gap_probe')} for k in ['swiftvm','dynarmic']}})
profiles=diag.profile_summary(w/'final-pmu'); assert all(x['lost']==0 for engines in profiles.values() for x in engines.values())

scaling={}
for kind in ['baseline','candidate']:
 groups=collections.defaultdict(list)
 for p in sorted(w.glob(f'scaling-{kind}-*.jsonl')):
  for line in p.read_text().splitlines():
   x=json.loads(line); assert x['output_verified'];x['median_compile_ns']=statistics.median(x['sequence_ns'])/x['requests_per_sample']; groups[(x['kind'],x['count'])].append(x)
 scaling[kind]={}
 for (name,count),rows in groups.items():
  assert len(rows)==3
  scaling[kind].setdefault(name,[]).append({'count':count,'median_compile_ns':statistics.median(x['median_compile_ns'] for x in rows),'native_bytes':statistics.median(x['native_bytes'] for x in rows),'actual_spills':statistics.median(x['actual_spills'] for x in rows)})
write(w/'scaling-summary.json',scaling)

domains={};groups=collections.defaultdict(list)
for p in sorted(w.glob('domain-probe-final-*.jsonl')):
 for line in p.read_text().splitlines():
  x=json.loads(line); assert x['output_verified'];groups[x['sequence']].append(x)
for name,rows in groups.items():
 assert len(rows)==9
 last=[x['steps'][-1] for x in rows]
 additional=[x['steps'][-1]['compile_attempts']-x['steps'][31]['compile_attempts'] for x in rows]
 assert not any(additional)
 fields=['compile_attempts','compile_ns','frontend_ns','optimize_ns','backend_ns','publication_ns','native_bytes','domains_created','switches','switch_ns']
 domains[name]={'medians':{k:statistics.median(x[k] for x in last) for k in fields},'second_pass_additional_compiles':additional}
write(w/'fp-domains-summary.json',domains)

static={};hot={}
for name in pmu['workloads']:
 static[name]={}
 for key in ['baseline','candidate']:
  folder=w/'final-pmu/records'/name/key/'0'; counts=collections.Counter()
  for line in (folder/'maps.tsv').read_text().splitlines():
   unit,start,size,pc=line.split(); instructions=diag.disassemble(folder/f'{unit}.bin'); counts.update(text.split()[0] for addr,text in instructions)
   if name not in ['integer','memory','shift','fp']:continue
   entries=dict(instructions);next_pc={instructions[i][0]:instructions[i+1][0] for i in range(len(instructions)-1)}
   loops=[(addr,int(m[1],16)) for addr,text in instructions if (m:=re.match(r'(?:jne|je)\s+0x([0-9a-f]+)$',text)) and int(m[1],16)<addr]
   if not loops: continue
   end,begin=min(loops);walk=[];cursor=begin
   for step in range(512):
    text=entries[cursor];walk.append((cursor,text))
    if cursor==end:break
    event=re.match(r'(je|jrcxz)\s+0x([0-9a-f]+)$',text)
    cursor=int(event[2],16) if event else next_pc[cursor]
   else:raise RuntimeError('hot loop convergence')
   hot.setdefault(name,{})[key]={'instructions':len(walk),'unit':unit,'path':walk}
  static[name][key]=dict(counts)
write(w/'static-instructions.json',static);write(w/'hot-paths.json',hot)
for name,engines in hot.items():
 lines=[]
 for key,x in engines.items():
  lines.append(f'{key}, {x["instructions"]} instructions per taken iteration');begin=x['path'][0][0]
  lines.extend(f'+{addr-begin:04x}  {text}' for addr,text in x['path']);lines.append('')
 (dest/f'{name}-hot-paths.txt').write_text('\n'.join(lines)+'\n')
summary={'build':read('final-build.json'),'validation':{'arm':correctness,'x86_full_field_baseline':x86,'ctest':{'passed':31,'skipped':skipped},'programs':programs},'benchmarks':measure,'compile_cost':compile_cost,'coremark':coremark,'cache':read('cache-comparison-release.json'),'pmu':pmu,'profiles':profiles,'supplementary':read('supplementary-summary.json'),'scaling':scaling,'fp_domains':domains,'static_instructions':static,'hot_paths':hot}
write(dest/'summary.json',summary)
print('validation and PMU gates passed')
for name,x in measure['workloads'].items():print(name,x['medians_ns'],x['candidate_over']['baseline'])
print('compile',compile_cost['medians']); print('coremark',coremark['medians_us'],coremark['candidate_over']);print('hot', {n:{k:v['instructions'] for k,v in e.items()} for n,e in hot.items()})
