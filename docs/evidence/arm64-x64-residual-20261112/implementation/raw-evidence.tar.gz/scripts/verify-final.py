from pathlib import Path
import argparse, hashlib, json, os, statistics, subprocess, sys
ROOT=Path('/mnt/d/Dev/SwiftVM')
WORK=Path.home()/'.cache/SwiftVM/arm64-x64-residual-impl-20261112'
ORIGINAL=Path.home()/'.cache/SwiftVM/dynarmic-bench-20261111'
GAP=Path.home()/'.cache/SwiftVM/dynarmic-gap-20261111'
PRIOR=Path.home()/'.cache/SwiftVM/wsl-arm-x64-20261111'
sys.path.insert(0,str(ROOT/'tools'))
import bench_dynarmic as bench
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def run_program(command,expected):
 p=subprocess.run([str(x) for x in command],capture_output=True,timeout=180)
 if p.returncode or p.stdout!=expected:raise RuntimeError(str(command)+': '+p.stderr.decode(errors='replace')[-1500:])
 return next(json.loads(line) for line in p.stderr.decode().splitlines() if '"measurement_kind"' in line)
def controls():
 os.sched_setaffinity(0,{2})
 guests=json.loads((GAP/'guests.json').read_text())
 names=['fp-u8','memory-u8','compute-matrix','compute-matrix-scalar','compute-full-scalar','compute-sha','compute-sort']
 runners={'baseline':ORIGINAL/'runners/svm_arm64_compare_bench','candidate':WORK/'final_compare','dynarmic':ORIGINAL/'runners/dynarmic_arm64_compare_bench'}
 result={'samples':31,'runners':{k:{'path':str(v),'sha256':bench.digest(v)} for k,v in runners.items()},'workloads':{}}
 for name in names:
  guest=guests[name];assert bench.digest(Path(guest['path']))==guest['sha256']
  reference=subprocess.run([str(PRIOR/'qemu-packages/root/usr/bin/qemu-aarch64'),guest['path']],capture_output=True,check=True,timeout=60)
  assert reference.stdout==bytes.fromhex(guest['expected_hex'])
  rows={k:[] for k in runners}
  for sample in range(31):
   order=list(runners);order=order[sample%3:]+order[:sample%3]
   if sample%2:order.reverse()
   for key in order:
    conf={'engine':'dynarmic' if key=='dynarmic' else 'swiftvm','scope':'block' if key=='dynarmic' else 'function','pins':0}
    rows[key].append(bench.launch(runners[key],conf,guest,3))
  medians={k:statistics.median(x['warm_median_ns'] for x in v) for k,v in rows.items()}
  result['workloads'][name]={'guest':guest,'measurements':rows,'medians_ns':medians,'candidate_over_baseline':bench.distribution([a['warm_median_ns']/b['warm_median_ns'] for a,b in zip(rows['candidate'],rows['baseline'])])}
  save(WORK/'final-controls-summary.json',result);print(name,medians,flush=True)
def pmu():
 os.sched_setaffinity(0,{2})
 prior=json.loads((ORIGINAL/'final/summary.json').read_text())
 guests={k:v['guest'] for k,v in prior['workloads'].items()}
 control=json.loads((GAP/'guests.json').read_text())
 guests.update({k:control[k] for k in ['fp-u8','memory-u8','compute-matrix','compute-matrix-scalar','compute-sha','compute-sort']})
 runners={'candidate':WORK/'final-pmu/swiftvm_gap_probe','baseline':GAP/'swiftvm_gap_probe','dynarmic':WORK/'final-pmu/dynarmic_gap_probe'}
 result={'samples':7,'runners':{k:{'path':str(v),'sha256':bench.digest(v)} for k,v in runners.items()},'workloads':{}}
 for name,guest in guests.items():
  rows={k:[] for k in runners}
  for sample in range(7):
   order=list(runners);order=order[sample%3:]+order[:sample%3]
   if sample%2:order.reverse()
   for key in order:
    d=WORK/'final-pmu/records'/name/key/str(sample);d.mkdir(parents=True,exist_ok=False)
    os.environ['SVM_GAP_OUT']=str(d);os.environ.pop('SVM_GAP_SAMPLE',None)
    conf={'engine':'dynarmic' if key=='dynarmic' else 'swiftvm','scope':'block' if key=='dynarmic' else 'function','pins':0}
    row=bench.launch(runners[key],conf,guest,3);counters=json.loads((d/'pmu.json').read_text())
    assert len(counters)==4 and all(p['enabled_ns']==p['running_ns'] and p['running_ns']>0 for p in counters)
    row['pmu']=counters;row['output_directory']=str(d);rows[key].append(row)
  medians={}
  for key,items in rows.items():
   sample=items[0]['pmu'][1]
   medians[key]={field:statistics.median(statistics.median(p[field] for p in x['pmu'][1:]) for x in items) for field in sample if field not in ['run'] and isinstance(sample[field],(int,float))}
  result['workloads'][name]={'guest':guest,'measurements':rows,'medians':medians}
  save(WORK/'final-pmu-summary.json',result);print(name,'instructions',{k:v['instructions'] for k,v in medians.items()},flush=True)
def programs():
 os.sched_setaffinity(0,{6})
 result={'runners':{k:bench.digest(WORK/k) for k in ['final_linux','final_aot']},'programs':{}}
 for isa in ['arm64','arm32','thumb']:
  guest=ROOT/'build/wsl-arm-x64/compiled-programs'/isa
  qemu=PRIOR/'qemu-packages/root/usr/bin'/('qemu-aarch64' if isa=='arm64' else 'qemu-arm')
  expected=subprocess.run([str(qemu),str(guest)],capture_output=True,timeout=90,check=True).stdout
  assert len(expected)==56 and expected[:32]==hashlib.sha256(bytes((i*37+11)&255 for i in range(300))*1000).digest()
  row={'guest_sha256':bench.digest(guest),'expected_hex':expected.hex(),'runs':{}}
  for scope in ['block','function']:
   for engine,pins in [('jit',0),('mixed',0),('interpreter',0),('jit',2)]:
    j=run_program([WORK/'final_linux','--scope',scope,'--engine',engine,'--pin-slots',pins,guest],expected)
    if engine=='jit':assert not j['interpreted_steps'] and not j['fallbacks'] and j['pinned_uniform_slots']==pins
    row['runs'][f'{scope}/{engine}/pin{pins}']=j
  cache=WORK/f'complete-release-validation-cache-{isa}';cache.mkdir(mode=0o700,exist_ok=False)
  command=[WORK/'final_linux','--scope','function','--cache-dir',cache,guest]
  cold=run_program(command,expected);warm=run_program(command,expected)
  assert cold['disk_cache_writes'] and warm['disk_cache_hits'] and not warm['compile_attempts'] and not warm['interpreted_steps']
  artifact=WORK/f'complete-release-validation-{isa}.aot'
  p=subprocess.run([str(x) for x in [WORK/'final_aot','compile',guest,'-o',artifact,'--scope','function','--max','16','--no-sweep']],capture_output=True,timeout=90)
  assert not p.returncode,p.stderr.decode()[-1500:]
  aot=run_program([WORK/'final_aot','run','--aot',artifact,'--scope','function'],expected)
  assert aot['aot_units_loaded'] and not aot['interpreted_steps'] and not aot['fallbacks']
  row['persistence']={'cold':cold,'warm':warm,'aot':aot,'artifact_sha256':bench.digest(artifact)}
  result['programs'][isa]=row;save(WORK/'final-programs-summary.json',result);print(isa,'8 configurations, disk cache and AOT passed',flush=True)
stage=sys.argv[1]
{'controls':controls,'pmu':pmu,'programs':programs}[stage]()

