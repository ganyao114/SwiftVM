from pathlib import Path
import json,os,statistics,sys
R=Path('/mnt/d/Dev/SwiftVM');W=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112');B=Path('/home/proton/.cache/SwiftVM/arm64-x64-opt4-20261111')
sys.path.insert(0,str(R/'tools'));import bench_dynarmic as b
os.sched_setaffinity(0,{2});guests=json.loads((W/'final-bench-summary.json').read_text())['workloads']
runners={'baseline':Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/swiftvm_gap_probe'),'candidate':W/'final-pmu/swiftvm_gap_probe','dynarmic':W/'final-pmu/dynarmic_gap_probe'}
res={'samples':7,'affinity':[2],'runners':{k:{'path':str(v),'sha256':b.digest(v)} for k,v in runners.items()},'workloads':{}}
for name in ['integer','memory','shift','fp','compute','fp-u8','compute-matrix','compute-matrix-scalar','compute-sha','compute-sort']:
 rows={k:[] for k in runners}
 for sample in range(7):
  order=list(runners);order=order[sample%3:]+order[:sample%3]
  if sample%2:order.reverse()
  for key in order:
   d=W/'final-pmu/records'/name/key/str(sample);d.mkdir(parents=True,exist_ok=False);os.environ['SVM_GAP_OUT']=str(d);os.environ.pop('SVM_GAP_SAMPLE',None)
   row=b.launch(runners[key],{'engine':'dynarmic' if key=='dynarmic' else 'swiftvm','scope':'block' if key=='dynarmic' else 'function','pins':0},guests[name]['guest'],3)
   pmu=json.loads((d/'pmu.json').read_text());assert len(pmu)==4 and all(x['enabled_ns']==x['running_ns'] and x['running_ns']>0 for x in pmu)
   row['pmu']=pmu;row['output_directory']=str(d);rows[key].append(row)
 med={k:{field:statistics.median(statistics.median(p[field] for p in x['pmu'][1:]) for x in v) for field in ['instructions','cycles','branches','branch_misses']} for k,v in rows.items()}
 res['workloads'][name]={'guest':guests[name]['guest'],'measurements':rows,'medians':med};(W/'final-pmu-summary.json').write_text(json.dumps(res,indent=2)+'\n')
 print(name, {k:v['instructions'] for k,v in med.items()},flush=True)
