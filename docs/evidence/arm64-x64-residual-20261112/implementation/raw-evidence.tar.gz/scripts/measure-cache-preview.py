from pathlib import Path
import json,os,sys
w=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112');sys.path.insert(0,'/mnt/d/Dev/SwiftVM/tools');import bench_dynarmic as b
os.sched_setaffinity(0,{2})
g={k:v['guest'] for k,v in json.loads(Path('/home/proton/.cache/SwiftVM/dynarmic-bench-20261111/final/summary.json').read_text())['workloads'].items()};g.update(json.loads(Path('/home/proton/.cache/SwiftVM/dynarmic-gap-20261111/guests.json').read_text()));g.update(json.loads((w/'guests/guests.json').read_text()))
runners={'cache8-no-backing':w/'cache8-no-backing_probe','cache128-no-backing':w/'cache128-no-backing_probe','cache128-backing':w/'final-pmu/swiftvm_gap_probe'}
res={'runners':{k:{'path':str(p),'sha256':b.digest(p)} for k,p in runners.items()},'workloads':{}}
for name in ['compute','compute-sha','compute-matrix','compute-sort','memory','compute-fma','matrix-fma']:
 res['workloads'][name]={}
 for key,runner in runners.items():
  d=w/'cache-comparison-alias-preview'/name/key;d.mkdir(parents=True,exist_ok=False);os.environ['SVM_GAP_OUT']=str(d);os.environ.pop('SVM_GAP_SAMPLE',None)
  b.launch(runner,{'engine':'swiftvm','scope':'function','pins':0},g[name],1)
  rows=[[int(v) for v in line.split()] for line in (d/'units.tsv').read_text().splitlines()]
  res['workloads'][name][key]={'units':rows,'stack_spills':sum(v[7] for v in rows),'uniform_loads':sum(v[8] for v in rows),'uniform_rematerialized':sum(v[9] for v in rows),'native_bytes':sum(v[4] for v in rows)}
 print(name,{k:{a:b for a,b in v.items() if a!='units'} for k,v in res['workloads'][name].items()},flush=True)
 (w/'cache-comparison-alias-preview.json').write_text(json.dumps(res,indent=2)+'\n')
