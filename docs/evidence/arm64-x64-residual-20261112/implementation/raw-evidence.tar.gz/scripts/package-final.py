from pathlib import Path
import hashlib,json,platform,shutil,subprocess,tarfile
r=Path('/mnt/d/Dev/SwiftVM');w=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112')
old=Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112');prior=Path('/home/proton/.cache/SwiftVM/wsl-arm-x64-20261111');opt4=Path('/home/proton/.cache/SwiftVM/arm64-x64-opt4-20261111');dyn=Path('/home/proton/.cache/SwiftVM/dynarmic-bench-20261111')
dest=r/'docs/evidence/arm64-x64-residual-20261112/implementation';dest.mkdir(parents=True,exist_ok=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for data in iter(lambda:f.read(1024*1024),b''):h.update(data)
 return h.hexdigest()
def write(p,value):p.write_text(json.dumps(value,indent=2)+'\n')
git=['git','-c','core.autocrlf=true','-C',str(r)]
subprocess.run(git+['diff','--check'],check=True)
(w/'source.patch').write_bytes(subprocess.check_output(git+['diff','--binary','HEAD']))
tracked=subprocess.check_output(git+['ls-files','-z'],text=True).split('\0');new=subprocess.check_output(git+['ls-files','--others','--exclude-standard','-z'],text=True).split('\0')
source_paths=sorted({n for n in tracked+new if n and (n.startswith(('source/','benchmarks/','tools/','cmake/')) or n=='CMakeLists.txt') and (r/n).is_file()})
write(w/'source-sha256.json',{n:digest(r/n) for n in source_paths})
new_sources=[n for n in new if n.startswith(('source/','benchmarks/','tools/')) and (r/n).is_file()]
build={}
for target in ['svm_arm64_compare_bench','svm_rebuild_linux','svm_aot','svm_correctness']:
 build[target]=subprocess.check_output(['ninja','-t','commands',target],cwd=r/'build/host',text=True).splitlines()[-1]
write(w/'build-commands.json',build);shutil.copy2(r/'build/host/CMakeCache.txt',w/'CMakeCache.txt')
(w/'ctest-commands.json').write_text(subprocess.check_output(['ctest','--show-only=json-v1'],cwd=r/'build/host',text=True))
assert (r/'build/host/generated/svm/code_build_id.h').read_bytes()==(w/'final_code_build_id.h').read_bytes()
runners={}
paths={n:w/n for n in ['baseline_compare','baseline_linux','baseline_aot','baseline_correctness','final_compare','final_linux','final_aot','final_correctness','scaling','domain-probe','cache8-no-backing_probe','cache128-no-backing_probe','pre-policy_linux','packed_linux']}
paths.update({'old52_linux':old/'baseline_linux','swiftvm_gap_probe':w/'final-pmu/swiftvm_gap_probe','dynarmic_gap_probe':w/'final-pmu/dynarmic_gap_probe','dynarmic_compare':dyn/'runners/dynarmic_arm64_compare_bench','baseline_scaling':old/'scaling'})
for n,p in paths.items():runners[n]={'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size}
frozen=json.loads((w/'final-build.json').read_text())
for n in ['compare','linux','aot','correctness']: assert runners['final_'+n]['sha256']==frozen[n]['sha256']
provenance={'git_head':subprocess.check_output(git+['rev-parse','HEAD'],text=True).strip(),'source_state':'working tree refactor over ba00658d, source.patch plus new source files','new_source_files':new_sources,'code_build_id_header':(w/'final_code_build_id.h').read_text(),'source_patch_sha256':digest(w/'source.patch'),'runners':runners,'environment':{'platform':platform.platform(),'compiler':subprocess.check_output(['c++','--version'],text=True).splitlines()[0],'cmake':subprocess.check_output(['cmake','--version'],text=True).splitlines()[0],'ninja':subprocess.check_output(['ninja','--version'],text=True).strip(),'cpu':next(x.split(':',1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name')),'build':'Release, SVM_ENABLE_IPO=ON','wsl_distribution':'ProtonHM','measurement_affinity':[2]},'references':{'mechanism_production_commit':'98e4d829','diagnostic_harness_commit':'0297f745','dynarmic_commit':'9d4582339990d4eae53f1dc7160686920fc2075c','coremark_commit':subprocess.check_output(['git','-C',str(w/'coremark'),'rev-parse','HEAD'],text=True).strip(),'coremark_measurement':'500 iterations, one full invocation warmup and one timed invocation, compare elapsed microseconds and CRCs','qemu':{n:{'path':str(prior/'qemu-packages/root/usr/bin'/n),'sha256':digest(prior/'qemu-packages/root/usr/bin'/n)} for n in ['qemu-aarch64','qemu-arm']}},'reproduction':{'repo':str(r),'work':str(w),'build':['cmake','--build','build/host','-j','8'],'test_environment':{'SVM_TEST_SCRATCH':str(w/'test-scratch')},'scripts':['validate-storage.py','run-measurements.py','analyze-final.py','package-final.py']}}
write(w/'provenance.json',provenance)
archive=dest/'raw-evidence.tar.gz'; index=[];seen=set()
def add(p,name):
 name=str(name)
 if name in seen:return
 seen.add(name)
 if p.is_dir():
  children=sorted(x for x in p.rglob('*') if x.is_file() and 'native-corpus' not in x.relative_to(p).parts)
  for x in children:tar.add(x,arcname=str(Path(name)/x.relative_to(p)),recursive=False)
  index.append({'name':name,'files':len(children),'uncompressed_bytes':sum(x.stat().st_size for x in children)})
 elif p.is_file():
  tar.add(p,arcname=name,recursive=False);index.append({'name':name,'files':1,'uncompressed_bytes':p.stat().st_size})
 else:raise RuntimeError(f'missing evidence {p}')
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 add(w/'provenance.json','provenance.json');add(dest/'summary.json','results/summary.json')
 for p in sorted(dest.glob('*-hot-paths.txt')):add(p,Path('results')/p.name)
 for n in ['source.patch','source-sha256.json','CMakeCache.txt','build-commands.json','final_code_build_id.h']:add(w/n,Path('source')/n)
 for n in new_sources:add(r/n,Path('source/new-files')/n)
 for p in sorted(w.glob('*.py')):add(p,Path('scripts')/p.name)
 for n in ['scaling.cpp','domain-probe.cpp','final-rewrite-cache8.cpp','final-allocate-no-backing.cpp','final-tools-build.json','final-build.json','ctest-commands.json','validation-storage-commands.json','measurement-commands.json']:
  add(w/n,Path('scripts')/n)
 for n,p in paths.items():add(p,Path('runners')/n)
 for n in ['qemu-aarch64','qemu-arm']:add(prior/'qemu-packages/root/usr/bin'/n,Path('runners')/n)
 for n in ['ctest-final.xml','ctest-final.log','storage-focused.log','alias-focused.log','gates.log','analysis-final.log','hot-shape-validation.json','final-correctness-summary.json','x86-regression-summary.json','x86-block-raw-diff.json','x86-function-raw-diff.json','final-programs-summary.json','final-bench-summary.json','final-pmu-summary.json','sample-runs.json','compile-program-summary.json','supplementary-summary.json','coremark-summary.json','cache-comparison-release.json','scaling-summary.json','fp-domains-summary.json','static-instructions.json','hot-paths.json','validation-arm-storage.log','validation-x86-storage.log','validation-programs-storage.log','validation-storage.log','final-bench.log','compile-program.log','cache-comparison-release.log','final-pmu.log','final-samples.log','supplementary.log','coremark-final.log','measurements.log','build-storage2.log','build-final-alias.log','final-tools.log','coremark-policy.json','coremark-policy-provenance.json']:
  add(w/n,Path('results')/n)
 for pattern in ['scaling-baseline-*.jsonl','scaling-candidate-*.jsonl','domain-probe-final-*.jsonl']:
  for p in sorted(w.glob(pattern)):add(p,Path('results')/p.name)
 add(w/'final-pmu','diagnostics/pmu');add(w/'final-samples','diagnostics/samples');add(w/'cache-comparison-release','diagnostics/cache')
 add(w/'final-correctness-complete','correctness/arm-actual');add(w/'x86-final-complete','correctness/x86-actual')
 for n in ['x86-baseline','x86-corpus']:add(old/n,Path('correctness')/n)
 for n,p in [('basic-arm64-corpus',prior/'corpus/arm64'),('basic-arm32-corpus',prior/'corpus/arm32'),('basic-arm64-oracle',prior/'post-fp-matrix/oracle/arm64'),('basic-arm32-oracle',prior/'post-fp-matrix/oracle/arm32'),('fp-corpus',prior/'fp-corpus'),('fp-oracle',prior/'fp-validation/oracle'),('neon-corpus',opt4/'neon-corpus'),('neon-oracle',opt4/'neon-oracle')]:add(p,Path('correctness')/n)
 for n,row in json.loads((w/'final-bench-summary.json').read_text())['workloads'].items():add(Path(row['guest']['path']),Path('guests/benchmarks')/n)
 add(w/'guests','guests/generated');add(w/'coremark-warm','guests/coremark-build')
 for p in sorted((w/'coremark').glob('core*')):
  if p.is_file() and p.suffix in ['.c','.h']:add(p,Path('guests/coremark-source')/p.name)
 for n in ['LICENSE.md','README.md']:
  if (w/'coremark'/n).exists():add(w/'coremark'/n,Path('guests/coremark-source')/n)
 for isa in ['arm64','arm32','thumb']:
  add(r/'build/wsl-arm-x64/compiled-programs'/isa,Path('guests/full-programs')/isa)
  add(w/f'complete-release-validation-{isa}.aot',Path('persistence')/f'{isa}.aot')
  add(w/f'complete-release-validation-cache-{isa}',Path('persistence')/f'cache-{isa}')
 for n in ['arm64-x64-residual-optimization-plan-2026-11-12.md','arm64-x64-residual-optimization-results-2026-11-12.md']:add(r/'docs'/n,Path('documents')/n)
shutil.copy2(w/'ctest-final.xml',dest/'ctest-final.xml');write(dest/'archive-index.json',index)
manifest={'provenance':provenance,'archive':{'path':archive.name,'sha256':digest(archive),'bytes':archive.stat().st_size},'files':{p.name:{'sha256':digest(p),'bytes':p.stat().st_size} for p in sorted(dest.iterdir()) if p.is_file() and p.name!='manifest.json'}}
write(dest/'manifest.json',manifest)
print(json.dumps({'archive_bytes':archive.stat().st_size,'sha256':manifest['archive']['sha256'],'groups':len(index),'raw_files':sum(x['files'] for x in index)}))
