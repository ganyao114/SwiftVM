from pathlib import Path
import json,os,statistics,sys
ROOT=Path('/mnt/d/Dev/SwiftVM');W=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112');O=Path('/home/proton/.cache/SwiftVM/dynarmic-bench-20261111');G=Path('/home/proton/.cache/SwiftVM/dynarmic-gap-20261111')
sys.path.insert(0,str(ROOT/'tools'));import bench_dynarmic as b
os.sched_setaffinity(0,{2})
guests={k:v['guest'] for k,v in json.loads((O/'final/summary.json').read_text())['workloads'].items()}
guests.update(json.loads((G/'guests.json').read_text()));guests.update(json.loads((W/'guests/guests.json').read_text()))
runners={'baseline':W/'baseline_compare','candidate':W/'final_compare','dynarmic':O/'runners/dynarmic_arm64_compare_bench'}
result={'samples':31,'warm_repeats':3,'affinity':[2],'runners':{k:{'path':str(v),'sha256':b.digest(v)} for k,v in runners.items()},'workloads':{}}
for name in ['integer','memory','shift','fp','compute','fp-u8','compute-matrix','compute-matrix-scalar','compute-sha','compute-sort','cond','cmpsep','fpmix','compute-fma','matrix-fma']:
 guest=guests[name];assert b.digest(Path(guest['path']))==guest['sha256'];rows={k:[] for k in runners}
 for sample in range(31):
  order=list(runners);order=order[sample%3:]+order[:sample%3]
  if sample%2:order.reverse()
  for key in order:
   config={'engine':'dynarmic' if key=='dynarmic' else 'swiftvm','scope':'block' if key=='dynarmic' else 'function','pins':0}
   rows[key].append(b.launch(runners[key],config,guest,3))
 med={k:statistics.median(x['warm_median_ns'] for x in v) for k,v in rows.items()}
 comp={k:{field:statistics.median(x[field] for x in v) for field in ['swiftvm_compile_ns','compile_observations','native_bytes','frontend_ns','optimize_ns','backend_ns','publication_ns'] if field in v[0]} for k,v in rows.items()}
 paired={k:b.distribution([a['warm_median_ns']/c['warm_median_ns'] for a,c in zip(rows['candidate'],rows[k])]) for k in ['baseline','dynarmic']}
 result['workloads'][name]={'guest':guest,'measurements':rows,'medians_ns':med,'compile':comp,'candidate_over':paired}
 (W/'final-bench-summary.json').write_text(json.dumps(result,indent=2)+'\n')
 print(name,med, 'compile', {k:v.get('swiftvm_compile_ns') for k,v in comp.items()},flush=True)
