from pathlib import Path
import json,os,statistics,sys
R=Path('/mnt/d/Dev/SwiftVM');W=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112')
sys.path.insert(0,str(R/'tools'));import bench_dynarmic as b
os.sched_setaffinity(0,{2})
guests=json.loads((W/'final-bench-summary.json').read_text())['workloads']
runners={'baseline':W/'baseline_compare','candidate':W/'final_compare'}
result={'samples':9,'warm_repeats':3,'affinity':[2],'runners':{k:{'path':str(v),'sha256':b.digest(v)} for k,v in runners.items()},'workloads':{}}
for name in ['integer','memory','shift','fp','compute']:
 result['workloads'][name]={}
 for scope,pins in [('block',0),('block',2),('function',2)]:
  rows={k:[] for k in runners}
  for sample in range(9):
   for key in (['candidate','baseline'] if sample%2 else ['baseline','candidate']):
    rows[key].append(b.launch(runners[key],{'engine':'swiftvm','scope':scope,'pins':pins},guests[name]['guest'],3))
  med={k:statistics.median(x['warm_median_ns'] for x in v) for k,v in rows.items()}
  result['workloads'][name][f'{scope}/pin{pins}']={'measurements':rows,'medians_ns':med,'paired':b.distribution([a['warm_median_ns']/c['warm_median_ns'] for a,c in zip(rows['candidate'],rows['baseline'])])}
  (W/'supplementary-summary.json').write_text(json.dumps(result,indent=2)+'\n')
  print(name,scope,pins,med,flush=True)
