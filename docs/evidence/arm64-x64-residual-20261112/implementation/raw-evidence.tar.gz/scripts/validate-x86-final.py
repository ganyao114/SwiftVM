from pathlib import Path
import json,os,subprocess,shutil,collections
W=Path('/home/proton/.cache/SwiftVM/arm64-x64-residual-impl-20261112');os.sched_setaffinity(0,{8});summary={}
for scope in ['block','function']:
 out=W/'x86-final-complete'/scope;out.mkdir(parents=True,exist_ok=True);config=Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/x86-baseline')/scope/'config.json'
 with (out/'worker.log').open('w') as f:
  p=subprocess.run([str(W/'final_correctness'),'worker','--input-dir',str(Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/x86-corpus')),'--output-dir',str(out/'actual'),'--config',str(config)],stdout=f,stderr=f,timeout=300)
 assert not p.returncode,p.returncode
 subset=out/'native-corpus';subset.mkdir(exist_ok=True);baseline=Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/x86-baseline')/scope/'actual';rejected=[]
 for case in sorted((Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/x86-corpus')).glob('*.svmcase')):
  old=json.loads((baseline/(case.stem+'.json')).read_text());new=json.loads((out/'actual'/(case.stem+'.json')).read_text())
  if old['native_executed']:shutil.copy2(case,subset/case.name)
  else:
   fields=['outcome','state','memory','service','fault_pc','fault_address','fault_access','fault_kind','fault_width']
   assert all(old.get(k)==new.get(k) for k in fields),(case.name,'non-native result changed')
   rejected.append({'case':case.name,'outcome':new['outcome'],'stage':new['stage'],'error':new.get('error')})
 p=subprocess.run([str(W/'batch_compare'),str(subset),str(baseline),str(out/'actual'),str(out/'comparisons.jsonl')],capture_output=True,text=True,timeout=120)
 assert p.returncode in [0,1],p.stderr
 row=json.loads(p.stdout);row['unchanged_non_native']=rejected;summary[scope]=row
 (W/'x86-regression-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(scope,{k:v for k,v in row.items() if k!='unchanged_non_native'},'unchanged nonnative',len(rejected),flush=True)

fields=['outcome','state','memory','service','fault_pc','fault_address','fault_access','fault_kind','fault_width']
for scope in ['block','function']:
 baseline=Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/x86-baseline')/scope/'actual';candidate=W/'x86-final-complete'/scope/'actual';mismatches=[];native=0
 for path in sorted(baseline.glob('*.json')):
  old=json.loads(path.read_text());new=json.loads((candidate/path.name).read_text());native+=bool(new['native_executed'])
  diff=[field for field in fields if old.get(field)!=new.get(field)]
  if diff:mismatches.append({'case':path.name,'fields':diff})
 row={'total':len(list(baseline.glob('*.json'))),'native':native,'compared_fields':fields,'mismatches':mismatches}
 (W/f'x86-{scope}-raw-diff.json').write_text(json.dumps(row,indent=2)+'\n')
 assert not mismatches,(scope,mismatches)
 print(scope,'all 639 full outcomes equal',flush=True)
