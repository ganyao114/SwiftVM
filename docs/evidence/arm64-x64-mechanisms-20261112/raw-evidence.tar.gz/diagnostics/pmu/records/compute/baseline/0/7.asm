
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute/baseline/0/7.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13,QWORD PTR [r12+0xa0]
   8:	mov    r14,r13
   b:	shl    r14,0x2
   f:	mov    r15,QWORD PTR [r12+0x98]
  17:	mov    rcx,r14
  1a:	mov    rbp,r15
  1d:	add    rbp,rcx
  20:	mov    r14d,DWORD PTR [r12]
  24:	mov    DWORD PTR [rbp+0x0],r14d
  28:	mov    r14d,0x0
  2e:	mov    DWORD PTR [r12+0x32c],r14d
  36:	mov    r14,r13
  39:	add    r14,0x1
  3d:	mov    QWORD PTR [r12+0xa0],r14
  45:	mov    r13,r14
  48:	sub    r13,0x400
  4f:	pushf
  50:	pop    rdx
  51:	mov    r10d,edx
  54:	and    r10d,0xc0
  5b:	shl    r10d,0x18
  5f:	mov    r11d,edx
  62:	and    r11d,0x1
  66:	shl    r11d,0x1d
  6a:	or     r10d,r11d
  6d:	mov    r11d,edx
  70:	and    r11d,0x800
  77:	shl    r11d,0x11
  7b:	or     r10d,r11d
  7e:	mov    r11d,0xf0000000
  84:	and    r11,r10
  87:	movabs rsi,0xffffffff0fffffff
  91:	and    rbx,rsi
  94:	or     rbx,r11
  97:	btc    rbx,0x1d
  9c:	cmp    QWORD PTR [r12+0x380],0x0
  a5:	je     0xd2
  ab:	mov    eax,0x410368
  b0:	mov    QWORD PTR [r12+0x100],rax
  b8:	mov    QWORD PTR [r12+0x108],rbx
  c0:	mov    eax,0xc
  c5:	movabs r11,0x5b99604255f0
  cf:	jmp    r11
  d2:	test   ebx,0x40000000
  d8:	je     0x625
  de:	jmp    0xe3
  e3:	mov    r13d,0x1
  e9:	mov    QWORD PTR [r12+0x40],r13
  ee:	jmp    0xf3
  f3:	mov    r13,QWORD PTR [r12+0x40]
  f8:	mov    r14,r13
  fb:	shl    r14,0x2
  ff:	mov    r15,QWORD PTR [r12+0x98]
 107:	mov    rcx,r14
 10a:	mov    rbp,r15
 10d:	add    rbp,rcx
 110:	mov    r14d,DWORD PTR [rbp+0x0]
 114:	mov    QWORD PTR [r12+0x48],r14
 119:	mov    r14d,0x0
 11f:	mov    rcx,r13
 122:	mov    r15,r14
 125:	or     r15,rcx
 128:	mov    QWORD PTR [r12+0x50],r15
 12d:	jmp    0x132
 132:	mov    r13d,DWORD PTR [r12+0x50]
 137:	mov    r14d,r13d
 13a:	sub    r14d,0x1
 13e:	mov    QWORD PTR [r12+0x58],r14
 143:	mov    ecx,0xffffffff
 148:	mov    r13,r14
 14b:	and    r13,rcx
 14e:	mov    r14,r13
 151:	shl    r14,0x2
 155:	mov    r13,QWORD PTR [r12+0x98]
 15d:	mov    rcx,r14
 160:	mov    r15,r13
 163:	add    r15,rcx
 166:	mov    r13d,DWORD PTR [r15]
 169:	mov    QWORD PTR [r12+0x60],r13
 16e:	mov    r14d,DWORD PTR [r12+0x48]
 173:	mov    ecx,r14d
 176:	mov    r15d,r13d
 179:	sub    r15d,ecx
 17c:	pushf
 17d:	pop    rdx
 17e:	mov    r10d,edx
 181:	and    r10d,0xc0
 188:	shl    r10d,0x18
 18c:	mov    r11d,edx
 18f:	and    r11d,0x1
 193:	shl    r11d,0x1d
 197:	or     r10d,r11d
 19a:	mov    r11d,edx
 19d:	and    r11d,0x800
 1a4:	shl    r11d,0x11
 1a8:	or     r10d,r11d
 1ab:	mov    r11d,0xf0000000
 1b1:	and    r11,r10
 1b4:	movabs rsi,0xffffffff0fffffff
 1be:	and    rbx,rsi
 1c1:	or     rbx,r11
 1c4:	btc    rbx,0x1d
 1c9:	cmp    QWORD PTR [r12+0x380],0x0
 1d2:	je     0x1ff
 1d8:	mov    eax,0x41039c
 1dd:	mov    QWORD PTR [r12+0x100],rax
 1e5:	mov    QWORD PTR [r12+0x108],rbx
 1ed:	mov    eax,0xc
 1f2:	movabs r11,0x5b99604255f0
 1fc:	jmp    r11
 1ff:	mov    eax,0x40000000
 204:	and    rax,rbx
 207:	test   rax,rax
 20a:	setne  al
 20d:	movzx  eax,al
 210:	and    eax,0x1
 213:	mov    r13,rax
 216:	mov    eax,0x20000000
 21b:	and    rax,rbx
 21e:	test   rax,rax
 221:	setne  al
 224:	movzx  eax,al
 227:	xor    eax,0x1
 22a:	and    eax,0x1
 22d:	mov    r14,rax
 230:	mov    rcx,r13
 233:	and    ecx,0xff
 239:	mov    r15,r14
 23c:	and    r15d,0xff
 243:	or     r15,rcx
 246:	and    r15d,0xff
 24d:	mov    rax,r15
 250:	and    eax,0xff
 255:	test   rax,rax
 258:	jne    0x34f
 25e:	jmp    0x263
 263:	mov    r13,QWORD PTR [r12+0x50]
 268:	mov    r14,r13
 26b:	shl    r14,0x2
 26f:	mov    r15,QWORD PTR [r12+0x98]
 277:	mov    rcx,r14
 27a:	mov    rbp,r15
 27d:	add    rbp,rcx
 280:	mov    r14d,DWORD PTR [r12+0x60]
 285:	mov    DWORD PTR [rbp+0x0],r14d
 289:	mov    r14d,0x0
 28f:	mov    DWORD PTR [r12+0x32c],r14d
 297:	mov    r14,r13
 29a:	sub    r14,0x1
 29e:	mov    QWORD PTR [r12+0x50],r14
 2a3:	cmp    QWORD PTR [r12+0x380],0x0
 2ac:	je     0x2d9
 2b2:	mov    eax,0x4103a8
 2b7:	mov    QWORD PTR [r12+0x100],rax
 2bf:	mov    QWORD PTR [r12+0x108],rbx
 2c7:	mov    eax,0xc
 2cc:	movabs r11,0x5b99604255f0
 2d6:	jmp    r11
 2d9:	mov    r13,QWORD PTR [r12+0x58]
 2de:	mov    rax,r13
 2e1:	test   rax,rax
 2e4:	setne  al
 2e7:	movzx  eax,al
 2ea:	and    eax,0x1
 2ed:	mov    r14,rax
 2f0:	mov    rax,r14
 2f3:	and    eax,0x1
 2f6:	test   rax,rax
 2f9:	jne    0x132
 2ff:	jmp    0x304
 304:	cmp    QWORD PTR [r12+0x380],0x0
 30d:	je     0x33a
 313:	mov    eax,0x4103ac
 318:	mov    QWORD PTR [r12+0x100],rax
 320:	mov    QWORD PTR [r12+0x108],rbx
 328:	mov    eax,0xc
 32d:	movabs r11,0x5b99604255f0
 337:	jmp    r11
 33a:	jmp    0x33f
 33f:	mov    r13d,0x0
 345:	mov    QWORD PTR [r12+0x50],r13
 34a:	jmp    0x34f
 34f:	mov    r13,QWORD PTR [r12+0x40]
 354:	mov    r14,r13
 357:	add    r14,0x1
 35b:	mov    QWORD PTR [r12+0x40],r14
 360:	mov    r13,QWORD PTR [r12+0x50]
 365:	mov    ecx,0xffffffff
 36a:	mov    r15,r13
 36d:	and    r15,rcx
 370:	mov    r13,r15
 373:	shl    r13,0x2
 377:	mov    r15,QWORD PTR [r12+0x98]
 37f:	mov    rcx,r13
 382:	mov    rbp,r15
 385:	add    rbp,rcx
 388:	mov    r13d,DWORD PTR [r12+0x48]
 38d:	mov    DWORD PTR [rbp+0x0],r13d
 391:	mov    r13d,0x0
 397:	mov    DWORD PTR [r12+0x32c],r13d
 39f:	mov    r13,r14
 3a2:	sub    r13,0x400
 3a9:	pushf
 3aa:	pop    rdx
 3ab:	mov    r10d,edx
 3ae:	and    r10d,0xc0
 3b5:	shl    r10d,0x18
 3b9:	mov    r11d,edx
 3bc:	and    r11d,0x1
 3c0:	shl    r11d,0x1d
 3c4:	or     r10d,r11d
 3c7:	mov    r11d,edx
 3ca:	and    r11d,0x800
 3d1:	shl    r11d,0x11
 3d5:	or     r10d,r11d
 3d8:	mov    r11d,0xf0000000
 3de:	and    r11,r10
 3e1:	movabs rsi,0xffffffff0fffffff
 3eb:	and    rbx,rsi
 3ee:	or     rbx,r11
 3f1:	btc    rbx,0x1d
 3f6:	test   ebx,0x40000000
 3fc:	jne    0x407
 402:	jmp    0xf3
 407:	mov    r13d,0x430000
 40d:	mov    QWORD PTR [r12+0x40],r13
 412:	mov    r13d,0x0
 418:	mov    QWORD PTR [r12+0x58],r13
 41d:	mov    r13d,0x0
 423:	mov    QWORD PTR [r12+0x50],r13
 428:	mov    r13d,0x430cb0
 42e:	mov    r14,QWORD PTR [r13+0x0]
 432:	mov    QWORD PTR [r12+0x48],r14
 437:	jmp    0x43c
 43c:	mov    r13,QWORD PTR [r12+0x58]
 441:	mov    r14,r13
 444:	shl    r14,0x2
 448:	mov    r15,QWORD PTR [r12+0x98]
 450:	mov    rcx,r14
 453:	mov    rbp,r15
 456:	add    rbp,rcx
 459:	mov    QWORD PTR [r12+0x60],rbp
 45e:	mov    r14,rbp
 461:	add    r14,0x4
 465:	mov    r15d,DWORD PTR [rbp+0x0]
 469:	mov    ebp,DWORD PTR [r14]
 46c:	mov    QWORD PTR [r12+0x68],r15
 471:	mov    QWORD PTR [r12+0x60],rbp
 476:	mov    rax,r15
 479:	mov    rcx,r13
 47c:	imul   rax,rcx
 480:	mov    r14,rax
 483:	mov    rcx,r14
 486:	mov    r8,r15
 489:	add    r8,rcx
 48c:	mov    QWORD PTR [r12+0x68],r8
 491:	mov    r14,r13
 494:	add    r14,0x2
 498:	mov    QWORD PTR [r12+0x58],r14
 49d:	mov    r13,r14
 4a0:	sub    r13,0x400
 4a7:	pushf
 4a8:	pop    rdx
 4a9:	mov    r10d,edx
 4ac:	and    r10d,0xc0
 4b3:	shl    r10d,0x18
 4b7:	mov    r11d,edx
 4ba:	and    r11d,0x1
 4be:	shl    r11d,0x1d
 4c2:	or     r10d,r11d
 4c5:	mov    r11d,edx
 4c8:	and    r11d,0x800
 4cf:	shl    r11d,0x11
 4d3:	or     r10d,r11d
 4d6:	mov    r11d,0xf0000000
 4dc:	and    r11,r10
 4df:	movabs rsi,0xffffffff0fffffff
 4e9:	and    rbx,rsi
 4ec:	or     rbx,r11
 4ef:	btc    rbx,0x1d
 4f4:	mov    r13,QWORD PTR [r12+0x50]
 4f9:	mov    rax,r14
 4fc:	mov    rcx,rbp
 4ff:	imul   rax,rcx
 503:	mov    r15,rax
 506:	mov    rcx,r15
 509:	mov    r14,r13
 50c:	add    r14,rcx
 50f:	mov    QWORD PTR [r12+0x50],r14
 514:	mov    r13,QWORD PTR [r12+0x48]
 519:	mov    rcx,r13
 51c:	mov    r14,r8
 51f:	add    r14,rcx
 522:	mov    QWORD PTR [r12+0x48],r14
 527:	cmp    QWORD PTR [r12+0x380],0x0
 530:	je     0x55d
 536:	mov    eax,0x4103dc
 53b:	mov    QWORD PTR [r12+0x100],rax
 543:	mov    QWORD PTR [r12+0x108],rbx
 54b:	mov    eax,0xc
 550:	movabs r11,0x5b99604255f0
 55a:	jmp    r11
 55d:	test   ebx,0x40000000
 563:	je     0x43c
 569:	jmp    0x56e
 56e:	mov    r13d,0x0
 574:	mov    QWORD PTR [r12+0x98],r13
 57c:	mov    r13,QWORD PTR [r12+0x48]
 581:	mov    r14,QWORD PTR [r12+0x50]
 586:	mov    rcx,r13
 589:	mov    r15,r14
 58c:	add    r15,rcx
 58f:	mov    QWORD PTR [r12+0x48],r15
 594:	mov    r13d,0x1
 59a:	mov    QWORD PTR [r12],r13
 59e:	mov    r13,QWORD PTR [r12+0x40]
 5a3:	mov    r14,r13
 5a6:	add    r14,0xcb0
 5ad:	mov    QWORD PTR [r14],r15
 5b0:	mov    r13d,0x0
 5b6:	mov    DWORD PTR [r12+0x32c],r13d
 5be:	mov    r13d,0x1
 5c4:	mov    QWORD PTR [r12],r13
 5c8:	mov    r13d,0x4103f8
 5ce:	mov    QWORD PTR [r12+0xf0],r13
 5d6:	mov    r13d,0x4109a4
 5dc:	mov    QWORD PTR [r12+0x100],r13
 5e4:	mov    QWORD PTR [r12+0x108],rbx
 5ec:	mov    edi,0x4109a4
 5f1:	mov    QWORD PTR [r12+0x100],rdi
 5f9:	nop    DWORD PTR [rax+0x0]
 600:	jmp    QWORD PTR [rip+0x2]        # 0x608
 606:	xchg   ax,ax
 608:	xor    BYTE PTR [rcx],ch
 60a:	nop
 60b:	(bad)
 60c:	fidiv  WORD PTR [rax+rax*1+0x0]
 610:	fdiv   DWORD PTR [rax]
 612:	nop
 613:	(bad)
 614:	fidiv  WORD PTR [rax+rax*1+0x0]
 618:	movabs r11,0x5b9960425370
 622:	jmp    r11
 625:	mov    r13d,DWORD PTR [r12+0xa0]
 62d:	mov    r14d,r13d
 630:	add    r14d,0x11
 634:	mov    QWORD PTR [r12],r14
 638:	mov    r13d,0x41035c
 63e:	mov    QWORD PTR [r12+0xf0],r13
 646:	mov    r13d,0x4109a4
 64c:	mov    QWORD PTR [r12+0x100],r13
 654:	mov    QWORD PTR [r12+0x108],rbx
 65c:	mov    edi,0x4109a4
 661:	mov    QWORD PTR [r12+0x100],rdi
 669:	nop    DWORD PTR [rax+0x0]
 670:	jmp    QWORD PTR [rip+0x2]        # 0x678
 676:	xchg   ax,ax
 678:	xor    BYTE PTR [rcx],ch
 67a:	nop
 67b:	(bad)
 67c:	fidiv  WORD PTR [rax+rax*1+0x0]
 680:	xor    QWORD PTR [rax+0x74de06],rdx
 687:	add    BYTE PTR [rcx-0x45],cl
 68a:	jo     0x6df
 68c:	rex.X (bad)
 68e:	cdq
 68f:	pop    rbx
 690:	add    BYTE PTR [rax],al
 692:	jmp    r11
 695:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 6a0:	jmp    0xe3
 6a5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 6b0:	jmp    0xf3
 6b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 6c0:	jmp    0x132
 6c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 6d0:	jmp    0x263
 6d5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 6e0:	jmp    0x304
 6e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 6f0:	jmp    0x33f
 6f5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 700:	jmp    0x34f
 705:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 710:	jmp    0x407
 715:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 720:	jmp    0x43c
 725:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 730:	jmp    0x56e
 735:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 740:	jmp    0x625
 745:	nop
 746:	nop
 747:	nop
