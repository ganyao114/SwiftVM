
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute/candidate/0/7.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp],r11
  10:	mov    r13,QWORD PTR [r12+0xa0]
  18:	mov    r14,r13
  1b:	shl    r14,0x2
  1f:	mov    r15,QWORD PTR [r12+0x98]
  27:	mov    rcx,r14
  2a:	add    r15,rcx
  2d:	mov    r14d,DWORD PTR [r12]
  31:	mov    DWORD PTR [r15],r14d
  34:	mov    r14d,0x0
  3a:	mov    DWORD PTR [r12+0x32c],r14d
  42:	add    r13,0x1
  46:	mov    QWORD PTR [r12+0xa0],r13
  4e:	sub    r13,0x400
  55:	mov    rcx,QWORD PTR [r12+0x380]
  5d:	jrcxz  0x64
  5f:	jmp    0x455
  64:	pushf
  65:	pop    r11
  67:	mov    QWORD PTR [rsp],r11
  6b:	jne    0x3e5
  71:	jmp    0x76
  76:	mov    r13d,0x1
  7c:	mov    QWORD PTR [r12+0x40],r13
  81:	jmp    0x86
  86:	mov    r13,QWORD PTR [r12+0x40]
  8b:	mov    r14,r13
  8e:	shl    r14,0x2
  92:	mov    r15,QWORD PTR [r12+0x98]
  9a:	mov    rcx,r14
  9d:	add    r15,rcx
  a0:	mov    r14d,DWORD PTR [r15]
  a3:	mov    QWORD PTR [r12+0x48],r14
  a8:	mov    r14d,0x0
  ae:	mov    rcx,r13
  b1:	or     r14,rcx
  b4:	mov    QWORD PTR [r12+0x50],r14
  b9:	jmp    0xbe
  be:	mov    r13d,DWORD PTR [r12+0x50]
  c3:	sub    r13d,0x1
  c7:	mov    QWORD PTR [r12+0x58],r13
  cc:	mov    ecx,0xffffffff
  d1:	mov    r14,r13
  d4:	and    r14,rcx
  d7:	shl    r14,0x2
  db:	mov    r13,QWORD PTR [r12+0x98]
  e3:	mov    rcx,r14
  e6:	add    r13,rcx
  e9:	mov    r14d,DWORD PTR [r13+0x0]
  ed:	mov    QWORD PTR [r12+0x60],r14
  f2:	mov    r13d,DWORD PTR [r12+0x48]
  f7:	mov    ecx,r13d
  fa:	sub    r14d,ecx
  fd:	mov    rcx,QWORD PTR [r12+0x380]
 105:	jrcxz  0x10c
 107:	jmp    0x4e4
 10c:	sete   al
 10f:	movzx  eax,al
 112:	mov    r13,rax
 115:	setb   al
 118:	movzx  eax,al
 11b:	mov    r14,rax
 11e:	pushf
 11f:	pop    r11
 121:	mov    QWORD PTR [rsp],r11
 125:	mov    rcx,r13
 128:	and    ecx,0xff
 12e:	mov    r15,r14
 131:	and    r15d,0xff
 138:	or     r15,rcx
 13b:	and    r15d,0xff
 142:	mov    rax,r15
 145:	and    eax,0xff
 14a:	test   rax,rax
 14d:	jne    0x1ef
 153:	jmp    0x158
 158:	mov    r13,QWORD PTR [r12+0x50]
 15d:	mov    r14,r13
 160:	shl    r14,0x2
 164:	mov    r15,QWORD PTR [r12+0x98]
 16c:	mov    rcx,r14
 16f:	add    r15,rcx
 172:	mov    r14d,DWORD PTR [r12+0x60]
 177:	mov    DWORD PTR [r15],r14d
 17a:	mov    r14d,0x0
 180:	mov    DWORD PTR [r12+0x32c],r14d
 188:	sub    r13,0x1
 18c:	mov    QWORD PTR [r12+0x50],r13
 191:	mov    rcx,QWORD PTR [r12+0x380]
 199:	jrcxz  0x1a0
 19b:	jmp    0x573
 1a0:	mov    r13,QWORD PTR [r12+0x58]
 1a5:	mov    rax,r13
 1a8:	test   rax,rax
 1ab:	setne  al
 1ae:	movzx  eax,al
 1b1:	and    eax,0x1
 1b4:	mov    r14,rax
 1b7:	mov    rax,r14
 1ba:	and    eax,0x1
 1bd:	test   rax,rax
 1c0:	jne    0xbe
 1c6:	jmp    0x1cb
 1cb:	mov    rcx,QWORD PTR [r12+0x380]
 1d3:	jrcxz  0x1da
 1d5:	jmp    0x5fa
 1da:	jmp    0x1df
 1df:	mov    r13d,0x0
 1e5:	mov    QWORD PTR [r12+0x50],r13
 1ea:	jmp    0x1ef
 1ef:	mov    r13,QWORD PTR [r12+0x40]
 1f4:	add    r13,0x1
 1f8:	mov    QWORD PTR [r12+0x40],r13
 1fd:	mov    r14,QWORD PTR [r12+0x50]
 202:	mov    ecx,0xffffffff
 207:	and    r14,rcx
 20a:	shl    r14,0x2
 20e:	mov    r15,QWORD PTR [r12+0x98]
 216:	mov    rcx,r14
 219:	add    r15,rcx
 21c:	mov    r14d,DWORD PTR [r12+0x48]
 221:	mov    DWORD PTR [r15],r14d
 224:	mov    r14d,0x0
 22a:	mov    DWORD PTR [r12+0x32c],r14d
 232:	sub    r13,0x400
 239:	pushf
 23a:	pop    r11
 23c:	mov    QWORD PTR [rsp],r11
 240:	je     0x24b
 246:	jmp    0x86
 24b:	mov    r13d,0x430000
 251:	mov    QWORD PTR [r12+0x40],r13
 256:	mov    r13d,0x0
 25c:	mov    QWORD PTR [r12+0x58],r13
 261:	mov    r13d,0x0
 267:	mov    QWORD PTR [r12+0x50],r13
 26c:	mov    r13d,0x430cb0
 272:	mov    r14,QWORD PTR [r13+0x0]
 276:	mov    QWORD PTR [r12+0x48],r14
 27b:	jmp    0x280
 280:	mov    r13,QWORD PTR [r12+0x58]
 285:	mov    r14,r13
 288:	shl    r14,0x2
 28c:	mov    r15,QWORD PTR [r12+0x98]
 294:	mov    rcx,r14
 297:	add    r15,rcx
 29a:	mov    QWORD PTR [r12+0x60],r15
 29f:	mov    r14,r15
 2a2:	add    r14,0x4
 2a6:	mov    ebp,DWORD PTR [r15]
 2a9:	mov    r15d,DWORD PTR [r14]
 2ac:	mov    QWORD PTR [r12+0x60],r15
 2b1:	mov    rax,rbp
 2b4:	mov    rcx,r13
 2b7:	imul   rax,rcx
 2bb:	mov    r14,rax
 2be:	mov    rcx,r14
 2c1:	mov    r8,rbp
 2c4:	add    r8,rcx
 2c7:	mov    QWORD PTR [r12+0x68],r8
 2cc:	add    r13,0x2
 2d0:	mov    QWORD PTR [r12+0x58],r13
 2d5:	mov    r14,r13
 2d8:	sub    r14,0x400
 2df:	mov    r14,QWORD PTR [r12+0x50]
 2e4:	pushf
 2e5:	pop    r11
 2e7:	mov    QWORD PTR [rsp],r11
 2eb:	mov    rax,r13
 2ee:	mov    rcx,r15
 2f1:	imul   rax,rcx
 2f5:	mov    rbp,rax
 2f8:	mov    rcx,rbp
 2fb:	add    r14,rcx
 2fe:	mov    QWORD PTR [r12+0x50],r14
 303:	mov    r13,QWORD PTR [r12+0x48]
 308:	mov    rcx,r13
 30b:	add    r8,rcx
 30e:	mov    QWORD PTR [r12+0x48],r8
 313:	mov    rcx,QWORD PTR [r12+0x380]
 31b:	jrcxz  0x322
 31d:	jmp    0x681
 322:	push   QWORD PTR [rsp]
 325:	popf
 326:	jne    0x280
 32c:	jmp    0x331
 331:	mov    r13d,0x0
 337:	mov    QWORD PTR [r12+0x98],r13
 33f:	mov    r13,QWORD PTR [r12+0x48]
 344:	mov    r14,QWORD PTR [r12+0x50]
 349:	mov    rcx,r13
 34c:	add    r14,rcx
 34f:	mov    QWORD PTR [r12+0x48],r14
 354:	mov    r13d,0x1
 35a:	mov    QWORD PTR [r12],r13
 35e:	mov    r13,QWORD PTR [r12+0x40]
 363:	add    r13,0xcb0
 36a:	mov    QWORD PTR [r13+0x0],r14
 36e:	mov    r13d,0x0
 374:	mov    DWORD PTR [r12+0x32c],r13d
 37c:	mov    r13d,0x1
 382:	mov    QWORD PTR [r12],r13
 386:	mov    r13d,0x4103f8
 38c:	mov    QWORD PTR [r12+0xf0],r13
 394:	mov    r13d,0x4109a4
 39a:	mov    QWORD PTR [r12+0x100],r13
 3a2:	mov    r11,QWORD PTR [rsp]
 3a6:	mov    QWORD PTR [r12+0x398],r11
 3ae:	mov    edi,0x4109a4
 3b3:	mov    QWORD PTR [r12+0x100],rdi
 3bb:	add    rsp,0x10
 3bf:	nop
 3c0:	jmp    QWORD PTR [rip+0x2]        # 0x3c8
 3c6:	xchg   ax,ax
 3c8:	nop
 3c9:	and    eax,edx
 3cb:	jno    0x420
 3cd:	ja     0x3cf
 3cf:	add    BYTE PTR [rax+0x27],ch
 3d2:	shl    BYTE PTR [rcx+0x53],1
 3d5:	ja     0x3d7
 3d7:	add    BYTE PTR [rcx-0x45],cl
 3da:	movabs al,ds:0x4100005dd1457460
 3e3:	jmp    rbx
 3e5:	mov    r13d,DWORD PTR [r12+0xa0]
 3ed:	add    r13d,0x11
 3f1:	mov    QWORD PTR [r12],r13
 3f5:	mov    r13d,0x41035c
 3fb:	mov    QWORD PTR [r12+0xf0],r13
 403:	mov    r13d,0x4109a4
 409:	mov    QWORD PTR [r12+0x100],r13
 411:	mov    r11,QWORD PTR [rsp]
 415:	mov    QWORD PTR [r12+0x398],r11
 41d:	mov    edi,0x4109a4
 422:	mov    QWORD PTR [r12+0x100],rdi
 42a:	add    rsp,0x10
 42e:	xchg   ax,ax
 430:	jmp    QWORD PTR [rip+0x2]        # 0x438
 436:	xchg   ax,ax
 438:	nop
 439:	and    eax,edx
 43b:	jno    0x490
 43d:	ja     0x43f
 43f:	add    al,bl
 441:	(bad)
 442:	shl    BYTE PTR [rcx+0x53],1
 445:	ja     0x447
 447:	add    BYTE PTR [rcx-0x45],cl
 44a:	movabs al,ds:0x4100005dd1457460
 453:	jmp    rbx
 455:	mov    eax,0x410368
 45a:	mov    QWORD PTR [r12+0x100],rax
 462:	push   rdx
 463:	push   rsi
 464:	push   r10
 466:	push   r11
 468:	pushf
 469:	pop    r11
 46b:	mov    QWORD PTR [rsp+0x20],r11
 470:	mov    rdx,QWORD PTR [rsp+0x20]
 475:	mov    r10d,edx
 478:	and    r10d,0xc0
 47f:	shl    r10d,0x18
 483:	mov    r11d,edx
 486:	and    r11d,0x1
 48a:	shl    r11d,0x1d
 48e:	or     r10d,r11d
 491:	mov    r11d,edx
 494:	and    r11d,0x800
 49b:	shl    r11d,0x11
 49f:	or     r10d,r11d
 4a2:	btc    r10,0x1d
 4a7:	mov    r11d,0xf0000000
 4ad:	and    r11,r10
 4b0:	movabs rsi,0xffffffff0fffffff
 4ba:	and    rbx,rsi
 4bd:	or     rbx,r11
 4c0:	pop    r11
 4c2:	pop    r10
 4c4:	pop    rsi
 4c5:	pop    rdx
 4c6:	mov    QWORD PTR [r12+0x108],rbx
 4ce:	add    rsp,0x10
 4d2:	mov    eax,0xc
 4d7:	movabs r11,0x5dd145746390
 4e1:	jmp    r11
 4e4:	mov    eax,0x41039c
 4e9:	mov    QWORD PTR [r12+0x100],rax
 4f1:	push   rdx
 4f2:	push   rsi
 4f3:	push   r10
 4f5:	push   r11
 4f7:	pushf
 4f8:	pop    r11
 4fa:	mov    QWORD PTR [rsp+0x20],r11
 4ff:	mov    rdx,QWORD PTR [rsp+0x20]
 504:	mov    r10d,edx
 507:	and    r10d,0xc0
 50e:	shl    r10d,0x18
 512:	mov    r11d,edx
 515:	and    r11d,0x1
 519:	shl    r11d,0x1d
 51d:	or     r10d,r11d
 520:	mov    r11d,edx
 523:	and    r11d,0x800
 52a:	shl    r11d,0x11
 52e:	or     r10d,r11d
 531:	btc    r10,0x1d
 536:	mov    r11d,0xf0000000
 53c:	and    r11,r10
 53f:	movabs rsi,0xffffffff0fffffff
 549:	and    rbx,rsi
 54c:	or     rbx,r11
 54f:	pop    r11
 551:	pop    r10
 553:	pop    rsi
 554:	pop    rdx
 555:	mov    QWORD PTR [r12+0x108],rbx
 55d:	add    rsp,0x10
 561:	mov    eax,0xc
 566:	movabs r11,0x5dd145746390
 570:	jmp    r11
 573:	mov    eax,0x4103a8
 578:	mov    QWORD PTR [r12+0x100],rax
 580:	push   rdx
 581:	push   rsi
 582:	push   r10
 584:	push   r11
 586:	mov    rdx,QWORD PTR [rsp+0x20]
 58b:	mov    r10d,edx
 58e:	and    r10d,0xc0
 595:	shl    r10d,0x18
 599:	mov    r11d,edx
 59c:	and    r11d,0x1
 5a0:	shl    r11d,0x1d
 5a4:	or     r10d,r11d
 5a7:	mov    r11d,edx
 5aa:	and    r11d,0x800
 5b1:	shl    r11d,0x11
 5b5:	or     r10d,r11d
 5b8:	btc    r10,0x1d
 5bd:	mov    r11d,0xf0000000
 5c3:	and    r11,r10
 5c6:	movabs rsi,0xffffffff0fffffff
 5d0:	and    rbx,rsi
 5d3:	or     rbx,r11
 5d6:	pop    r11
 5d8:	pop    r10
 5da:	pop    rsi
 5db:	pop    rdx
 5dc:	mov    QWORD PTR [r12+0x108],rbx
 5e4:	add    rsp,0x10
 5e8:	mov    eax,0xc
 5ed:	movabs r11,0x5dd145746390
 5f7:	jmp    r11
 5fa:	mov    eax,0x4103ac
 5ff:	mov    QWORD PTR [r12+0x100],rax
 607:	push   rdx
 608:	push   rsi
 609:	push   r10
 60b:	push   r11
 60d:	mov    rdx,QWORD PTR [rsp+0x20]
 612:	mov    r10d,edx
 615:	and    r10d,0xc0
 61c:	shl    r10d,0x18
 620:	mov    r11d,edx
 623:	and    r11d,0x1
 627:	shl    r11d,0x1d
 62b:	or     r10d,r11d
 62e:	mov    r11d,edx
 631:	and    r11d,0x800
 638:	shl    r11d,0x11
 63c:	or     r10d,r11d
 63f:	btc    r10,0x1d
 644:	mov    r11d,0xf0000000
 64a:	and    r11,r10
 64d:	movabs rsi,0xffffffff0fffffff
 657:	and    rbx,rsi
 65a:	or     rbx,r11
 65d:	pop    r11
 65f:	pop    r10
 661:	pop    rsi
 662:	pop    rdx
 663:	mov    QWORD PTR [r12+0x108],rbx
 66b:	add    rsp,0x10
 66f:	mov    eax,0xc
 674:	movabs r11,0x5dd145746390
 67e:	jmp    r11
 681:	mov    eax,0x4103dc
 686:	mov    QWORD PTR [r12+0x100],rax
 68e:	push   rdx
 68f:	push   rsi
 690:	push   r10
 692:	push   r11
 694:	mov    rdx,QWORD PTR [rsp+0x20]
 699:	mov    r10d,edx
 69c:	and    r10d,0xc0
 6a3:	shl    r10d,0x18
 6a7:	mov    r11d,edx
 6aa:	and    r11d,0x1
 6ae:	shl    r11d,0x1d
 6b2:	or     r10d,r11d
 6b5:	mov    r11d,edx
 6b8:	and    r11d,0x800
 6bf:	shl    r11d,0x11
 6c3:	or     r10d,r11d
 6c6:	btc    r10,0x1d
 6cb:	mov    r11d,0xf0000000
 6d1:	and    r11,r10
 6d4:	movabs rsi,0xffffffff0fffffff
 6de:	and    rbx,rsi
 6e1:	or     rbx,r11
 6e4:	pop    r11
 6e6:	pop    r10
 6e8:	pop    rsi
 6e9:	pop    rdx
 6ea:	mov    QWORD PTR [r12+0x108],rbx
 6f2:	add    rsp,0x10
 6f6:	mov    eax,0xc
 6fb:	movabs r11,0x5dd145746390
 705:	jmp    r11
 708:	nop    DWORD PTR [rax+rax*1+0x0]
 710:	sub    rsp,0x10
 714:	mov    r11,QWORD PTR [r12+0x398]
 71c:	mov    QWORD PTR [rsp],r11
 720:	jmp    0x76
 725:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 730:	sub    rsp,0x10
 734:	mov    r11,QWORD PTR [r12+0x398]
 73c:	mov    QWORD PTR [rsp],r11
 740:	jmp    0x86
 745:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 750:	sub    rsp,0x10
 754:	mov    r11,QWORD PTR [r12+0x398]
 75c:	mov    QWORD PTR [rsp],r11
 760:	jmp    0xbe
 765:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 770:	sub    rsp,0x10
 774:	mov    r11,QWORD PTR [r12+0x398]
 77c:	mov    QWORD PTR [rsp],r11
 780:	jmp    0x158
 785:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 790:	sub    rsp,0x10
 794:	mov    r11,QWORD PTR [r12+0x398]
 79c:	mov    QWORD PTR [rsp],r11
 7a0:	jmp    0x1cb
 7a5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 7b0:	sub    rsp,0x10
 7b4:	mov    r11,QWORD PTR [r12+0x398]
 7bc:	mov    QWORD PTR [rsp],r11
 7c0:	jmp    0x1df
 7c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 7d0:	sub    rsp,0x10
 7d4:	mov    r11,QWORD PTR [r12+0x398]
 7dc:	mov    QWORD PTR [rsp],r11
 7e0:	jmp    0x1ef
 7e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 7f0:	sub    rsp,0x10
 7f4:	mov    r11,QWORD PTR [r12+0x398]
 7fc:	mov    QWORD PTR [rsp],r11
 800:	jmp    0x24b
 805:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 810:	sub    rsp,0x10
 814:	mov    r11,QWORD PTR [r12+0x398]
 81c:	mov    QWORD PTR [rsp],r11
 820:	jmp    0x280
 825:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 830:	sub    rsp,0x10
 834:	mov    r11,QWORD PTR [r12+0x398]
 83c:	mov    QWORD PTR [rsp],r11
 840:	jmp    0x331
 845:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 850:	sub    rsp,0x10
 854:	mov    r11,QWORD PTR [r12+0x398]
 85c:	mov    QWORD PTR [rsp],r11
 860:	jmp    0x3e5
 865:	nop
 866:	nop
 867:	nop
