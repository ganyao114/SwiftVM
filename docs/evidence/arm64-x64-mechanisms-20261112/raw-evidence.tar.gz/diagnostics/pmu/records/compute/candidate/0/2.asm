
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute/candidate/0/2.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r13d,DWORD PTR [r12+0xa0]
   c:	sub    r13d,0x1
  10:	mov    QWORD PTR [r12+0xa0],r13
  18:	mov    rcx,QWORD PTR [r12+0x380]
  20:	jrcxz  0x27
  22:	jmp    0x1a5
  27:	pushf
  28:	pop    r11
  2a:	mov    QWORD PTR [rsp],r11
  2e:	jne    0x10d
  34:	jmp    0x39
  39:	mov    r13,QWORD PTR [r12+0xf8]
  41:	mov    r14,r13
  44:	add    r14,0x120
  4b:	mov    r15,QWORD PTR [r14]
  4e:	mov    QWORD PTR [r12+0x98],r15
  56:	mov    r14d,0x80
  5c:	mov    QWORD PTR [r12+0x40],r14
  61:	mov    r14,r13
  64:	add    r14,0x100
  6b:	mov    QWORD PTR [r12],r14
  6f:	mov    r14,r13
  72:	add    r14,0x17c
  79:	mov    QWORD PTR [r12+0x8],r14
  7e:	mov    r14d,0x1
  84:	mov    QWORD PTR [r12+0x10],r14
  89:	add    r13,0x17c
  90:	movzx  r14d,BYTE PTR [r12+0x40]
  96:	mov    BYTE PTR [r13+0x0],r14b
  9a:	mov    r13d,0x0
  a0:	mov    DWORD PTR [r12+0x32c],r13d
  a8:	mov    r13d,0x4102a8
  ae:	mov    QWORD PTR [r12+0xf0],r13
  b6:	mov    r13d,0x410728
  bc:	mov    QWORD PTR [r12+0x100],r13
  c4:	mov    r11,QWORD PTR [rsp]
  c8:	mov    QWORD PTR [r12+0x398],r11
  d0:	mov    edi,0x410728
  d5:	mov    QWORD PTR [r12+0x100],rdi
  dd:	add    rsp,0x10
  e1:	nop    DWORD PTR [rax+0x0]
  e8:	jmp    QWORD PTR [rip+0x2]        # 0xf0
  ee:	xchg   ax,ax
  f0:	(bad)
  f1:	jmp    0x775372c5
  f6:	add    BYTE PTR [rax],al
  f8:	jo     0x110
  fa:	shl    BYTE PTR [rcx+0x53],1
  fd:	ja     0xff
  ff:	add    BYTE PTR [rcx-0x45],cl
 102:	movabs al,ds:0x4100005dd1457460
 10b:	jmp    rbx
 10d:	mov    r13,QWORD PTR [r12+0xf8]
 115:	add    r13,0x100
 11c:	mov    QWORD PTR [r12],r13
 120:	mov    r13d,0x0
 126:	mov    r14,QWORD PTR [r12+0x98]
 12e:	mov    rcx,r14
 131:	or     r13,rcx
 134:	mov    QWORD PTR [r12+0x8],r13
 139:	mov    r13d,0x12c
 13f:	mov    QWORD PTR [r12+0x10],r13
 144:	mov    r13d,0x410284
 14a:	mov    QWORD PTR [r12+0xf0],r13
 152:	mov    r13d,0x410728
 158:	mov    QWORD PTR [r12+0x100],r13
 160:	mov    r11,QWORD PTR [rsp]
 164:	mov    QWORD PTR [r12+0x398],r11
 16c:	mov    edi,0x410728
 171:	mov    QWORD PTR [r12+0x100],rdi
 179:	add    rsp,0x10
 17d:	nop    DWORD PTR [rax]
 180:	jmp    QWORD PTR [rip+0x2]        # 0x188
 186:	xchg   ax,ax
 188:	(bad)
 189:	jmp    0x7753735d
 18e:	add    BYTE PTR [rax],al
 190:	or     BYTE PTR [rdi],dl
 192:	shl    BYTE PTR [rcx+0x53],1
 195:	ja     0x197
 197:	add    BYTE PTR [rcx-0x45],cl
 19a:	movabs al,ds:0x4100005dd1457460
 1a3:	jmp    rbx
 1a5:	mov    eax,0x410288
 1aa:	mov    QWORD PTR [r12+0x100],rax
 1b2:	push   rdx
 1b3:	push   rsi
 1b4:	push   r10
 1b6:	push   r11
 1b8:	pushf
 1b9:	pop    r11
 1bb:	mov    QWORD PTR [rsp+0x20],r11
 1c0:	mov    rdx,QWORD PTR [rsp+0x20]
 1c5:	mov    r10d,edx
 1c8:	and    r10d,0xc0
 1cf:	shl    r10d,0x18
 1d3:	mov    r11d,edx
 1d6:	and    r11d,0x1
 1da:	shl    r11d,0x1d
 1de:	or     r10d,r11d
 1e1:	mov    r11d,edx
 1e4:	and    r11d,0x800
 1eb:	shl    r11d,0x11
 1ef:	or     r10d,r11d
 1f2:	btc    r10,0x1d
 1f7:	mov    r11d,0xf0000000
 1fd:	and    r11,r10
 200:	movabs rsi,0xffffffff0fffffff
 20a:	and    rbx,rsi
 20d:	or     rbx,r11
 210:	pop    r11
 212:	pop    r10
 214:	pop    rsi
 215:	pop    rdx
 216:	mov    QWORD PTR [r12+0x108],rbx
 21e:	add    rsp,0x10
 222:	mov    eax,0xc
 227:	movabs r11,0x5dd145746390
 231:	jmp    r11
 234:	data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
 240:	sub    rsp,0x10
 244:	mov    r11,QWORD PTR [r12+0x398]
 24c:	mov    QWORD PTR [rsp],r11
 250:	jmp    0x39
 255:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 260:	sub    rsp,0x10
 264:	mov    r11,QWORD PTR [r12+0x398]
 26c:	mov    QWORD PTR [rsp],r11
 270:	jmp    0x10d
 275:	nop
 276:	nop
 277:	nop
