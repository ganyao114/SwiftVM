
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute/candidate/0/5.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x20
   4:	mov    r11,QWORD PTR [r12+0x398]
   c:	mov    QWORD PTR [rsp+0x10],r11
  11:	mov    r13,QWORD PTR [r12+0xf8]
  19:	mov    r14,r13
  1c:	add    r14,0x100
  23:	mov    r15d,DWORD PTR [r14]
  26:	mov    QWORD PTR [r12+0x40],r15
  2b:	mov    r14,r13
  2e:	add    r14,0x104
  35:	mov    ebp,DWORD PTR [r14]
  38:	mov    QWORD PTR [r12+0x50],rbp
  3d:	mov    r14d,0x430c90
  43:	mov    QWORD PTR [r12+0x48],r14
  48:	mov    r14,r13
  4b:	add    r14,0x108
  52:	mov    r8d,DWORD PTR [r14]
  55:	mov    QWORD PTR [r12+0x58],r8
  5a:	add    r13,0x10c
  61:	mov    r14d,DWORD PTR [r13+0x0]
  65:	mov    QWORD PTR [r12+0x60],r14
  6a:	movabs rcx,0xff00ff00ff00ff
  74:	mov    r13,r15
  77:	and    r13,rcx
  7a:	shl    r13,0x8
  7e:	movabs rcx,0xff00ff00ff00ff00
  88:	mov    r14,r15
  8b:	and    r14,rcx
  8e:	shr    r14,0x8
  92:	mov    rcx,r13
  95:	or     r14,rcx
  98:	movabs rcx,0xffff0000ffff
  a2:	mov    r13,r14
  a5:	and    r13,rcx
  a8:	shl    r13,0x10
  ac:	movabs rcx,0xffff0000ffff0000
  b6:	and    r14,rcx
  b9:	shr    r14,0x10
  bd:	mov    rcx,r13
  c0:	or     r14,rcx
  c3:	mov    ecx,0xffffffff
  c8:	and    r14,rcx
  cb:	mov    QWORD PTR [r12+0x40],r14
  d0:	movabs rcx,0xff00ff00ff00ff
  da:	mov    r13,rbp
  dd:	and    r13,rcx
  e0:	shl    r13,0x8
  e4:	movabs rcx,0xff00ff00ff00ff00
  ee:	mov    r15,rbp
  f1:	and    r15,rcx
  f4:	shr    r15,0x8
  f8:	mov    rcx,r13
  fb:	or     r15,rcx
  fe:	movabs rcx,0xffff0000ffff
 108:	mov    r13,r15
 10b:	and    r13,rcx
 10e:	shl    r13,0x10
 112:	movabs rcx,0xffff0000ffff0000
 11c:	and    r15,rcx
 11f:	shr    r15,0x10
 123:	mov    rcx,r13
 126:	or     r15,rcx
 129:	mov    ecx,0xffffffff
 12e:	and    r15,rcx
 131:	mov    QWORD PTR [r12+0x50],r15
 136:	mov    r13d,0x0
 13c:	mov    QWORD PTR [r12+0xa0],r13
 144:	mov    r13d,0x430c90
 14a:	mov    ebp,0x430c94
 14f:	mov    rax,r14
 152:	mov    eax,eax
 154:	mov    r8d,eax
 157:	mov    rax,r15
 15a:	mov    eax,eax
 15c:	mov    r14d,eax
 15f:	mov    DWORD PTR [r13+0x0],r8d
 163:	mov    r13d,0x0
 169:	mov    DWORD PTR [r12+0x32c],r13d
 171:	mov    DWORD PTR [rbp+0x0],r14d
 175:	mov    r13d,0x0
 17b:	mov    DWORD PTR [r12+0x32c],r13d
 183:	mov    r13d,DWORD PTR [r12+0x58]
 188:	movabs rcx,0xff00ff00ff00ff
 192:	mov    r14,r13
 195:	and    r14,rcx
 198:	shl    r14,0x8
 19c:	movabs rcx,0xff00ff00ff00ff00
 1a6:	mov    r15,r13
 1a9:	and    r15,rcx
 1ac:	shr    r15,0x8
 1b0:	mov    rcx,r14
 1b3:	or     r15,rcx
 1b6:	movabs rcx,0xffff0000ffff
 1c0:	mov    r13,r15
 1c3:	and    r13,rcx
 1c6:	shl    r13,0x10
 1ca:	movabs rcx,0xffff0000ffff0000
 1d4:	and    r15,rcx
 1d7:	shr    r15,0x10
 1db:	mov    rcx,r13
 1de:	or     r15,rcx
 1e1:	mov    ecx,0xffffffff
 1e6:	and    r15,rcx
 1e9:	mov    QWORD PTR [r12+0x40],r15
 1ee:	mov    r13,QWORD PTR [r12+0xf8]
 1f6:	mov    r14,r13
 1f9:	add    r14,0x110
 200:	mov    ebp,DWORD PTR [r14]
 203:	mov    QWORD PTR [r12+0x50],rbp
 208:	mov    r14d,DWORD PTR [r12+0x60]
 20d:	movabs rcx,0xff00ff00ff00ff
 217:	mov    rbp,r14
 21a:	and    rbp,rcx
 21d:	shl    rbp,0x8
 221:	movabs rcx,0xff00ff00ff00ff00
 22b:	mov    r8,r14
 22e:	and    r8,rcx
 231:	shr    r8,0x8
 235:	mov    rcx,rbp
 238:	or     r8,rcx
 23b:	movabs rcx,0xffff0000ffff
 245:	mov    r14,r8
 248:	and    r14,rcx
 24b:	shl    r14,0x10
 24f:	movabs rcx,0xffff0000ffff0000
 259:	and    r8,rcx
 25c:	shr    r8,0x10
 260:	mov    rcx,r14
 263:	or     r8,rcx
 266:	mov    ecx,0xffffffff
 26b:	and    r8,rcx
 26e:	mov    QWORD PTR [r12+0x58],r8
 273:	add    r13,0x114
 27a:	mov    r14d,DWORD PTR [r13+0x0]
 27e:	mov    QWORD PTR [r12+0x60],r14
 283:	mov    r13d,0x430000
 289:	add    r13,0xdfc
 290:	mov    QWORD PTR [r12+0x98],r13
 298:	mov    r13,QWORD PTR [r12+0x48]
 29d:	add    r13,0x8
 2a1:	mov    r14,r13
 2a4:	add    r14,0x4
 2a8:	mov    rax,r15
 2ab:	mov    eax,eax
 2ad:	mov    ebp,eax
 2af:	mov    rax,r8
 2b2:	mov    eax,eax
 2b4:	mov    r15d,eax
 2b7:	mov    DWORD PTR [r13+0x0],ebp
 2bb:	mov    r13d,0x0
 2c1:	mov    DWORD PTR [r12+0x32c],r13d
 2c9:	mov    DWORD PTR [r14],r15d
 2cc:	mov    r13d,0x0
 2d2:	mov    DWORD PTR [r12+0x32c],r13d
 2da:	mov    r13d,DWORD PTR [r12+0x50]
 2df:	movabs rcx,0xff00ff00ff00ff
 2e9:	mov    r14,r13
 2ec:	and    r14,rcx
 2ef:	shl    r14,0x8
 2f3:	movabs rcx,0xff00ff00ff00ff00
 2fd:	mov    r15,r13
 300:	and    r15,rcx
 303:	shr    r15,0x8
 307:	mov    rcx,r14
 30a:	or     r15,rcx
 30d:	movabs rcx,0xffff0000ffff
 317:	mov    r13,r15
 31a:	and    r13,rcx
 31d:	shl    r13,0x10
 321:	movabs rcx,0xffff0000ffff0000
 32b:	and    r15,rcx
 32e:	shr    r15,0x10
 332:	mov    rcx,r13
 335:	or     r15,rcx
 338:	mov    ecx,0xffffffff
 33d:	and    r15,rcx
 340:	mov    QWORD PTR [r12+0x40],r15
 345:	mov    r13,QWORD PTR [r12+0xf8]
 34d:	mov    r14,r13
 350:	add    r14,0x118
 357:	mov    ebp,DWORD PTR [r14]
 35a:	mov    QWORD PTR [r12+0x50],rbp
 35f:	mov    r14d,DWORD PTR [r12+0x60]
 364:	movabs rcx,0xff00ff00ff00ff
 36e:	mov    r8,r14
 371:	and    r8,rcx
 374:	shl    r8,0x8
 378:	movabs rcx,0xff00ff00ff00ff00
 382:	mov    r9,r14
 385:	and    r9,rcx
 388:	shr    r9,0x8
 38c:	mov    rcx,r8
 38f:	or     r9,rcx
 392:	movabs rcx,0xffff0000ffff
 39c:	mov    r14,r9
 39f:	and    r14,rcx
 3a2:	shl    r14,0x10
 3a6:	movabs rcx,0xffff0000ffff0000
 3b0:	and    r9,rcx
 3b3:	shr    r9,0x10
 3b7:	mov    rcx,r14
 3ba:	or     r9,rcx
 3bd:	mov    ecx,0xffffffff
 3c2:	and    r9,rcx
 3c5:	mov    QWORD PTR [r12+0x58],r9
 3ca:	add    r13,0x11c
 3d1:	mov    eax,DWORD PTR [r13+0x0]
 3d5:	mov    QWORD PTR [rsp+0x8],rax
 3da:	mov    rax,QWORD PTR [rsp+0x8]
 3df:	mov    QWORD PTR [r12+0x60],rax
 3e4:	mov    rax,QWORD PTR [r12+0x48]
 3e9:	mov    QWORD PTR [rsp],rax
 3ed:	mov    r8,QWORD PTR [rsp]
 3f1:	add    r8,0x10
 3f5:	mov    r13,r8
 3f8:	add    r13,0x4
 3fc:	mov    rax,r15
 3ff:	mov    eax,eax
 401:	mov    r14d,eax
 404:	mov    rax,r9
 407:	mov    eax,eax
 409:	mov    r15d,eax
 40c:	mov    DWORD PTR [r8],r14d
 40f:	mov    r14d,0x0
 415:	mov    DWORD PTR [r12+0x32c],r14d
 41d:	mov    DWORD PTR [r13+0x0],r15d
 421:	mov    r13d,0x0
 427:	mov    DWORD PTR [r12+0x32c],r13d
 42f:	movabs rcx,0xff00ff00ff00ff
 439:	mov    r13,rbp
 43c:	and    r13,rcx
 43f:	shl    r13,0x8
 443:	movabs rcx,0xff00ff00ff00ff00
 44d:	mov    r14,rbp
 450:	and    r14,rcx
 453:	shr    r14,0x8
 457:	mov    rcx,r13
 45a:	or     r14,rcx
 45d:	movabs rcx,0xffff0000ffff
 467:	mov    r13,r14
 46a:	and    r13,rcx
 46d:	shl    r13,0x10
 471:	movabs rcx,0xffff0000ffff0000
 47b:	and    r14,rcx
 47e:	shr    r14,0x10
 482:	mov    rcx,r13
 485:	or     r14,rcx
 488:	mov    ecx,0xffffffff
 48d:	and    r14,rcx
 490:	mov    QWORD PTR [r12+0x40],r14
 495:	movabs rcx,0xff00ff00ff00ff
 49f:	mov    r13,QWORD PTR [rsp+0x8]
 4a4:	and    r13,rcx
 4a7:	shl    r13,0x8
 4ab:	movabs rcx,0xff00ff00ff00ff00
 4b5:	mov    r15,QWORD PTR [rsp+0x8]
 4ba:	and    r15,rcx
 4bd:	shr    r15,0x8
 4c1:	mov    rcx,r13
 4c4:	or     r15,rcx
 4c7:	movabs rcx,0xffff0000ffff
 4d1:	mov    r13,r15
 4d4:	and    r13,rcx
 4d7:	shl    r13,0x10
 4db:	movabs rcx,0xffff0000ffff0000
 4e5:	and    r15,rcx
 4e8:	shr    r15,0x10
 4ec:	mov    rcx,r13
 4ef:	or     r15,rcx
 4f2:	mov    ecx,0xffffffff
 4f7:	and    r15,rcx
 4fa:	mov    QWORD PTR [r12+0x50],r15
 4ff:	mov    r13,QWORD PTR [rsp]
 503:	add    r13,0x18
 507:	mov    rbp,r13
 50a:	add    rbp,0x4
 50e:	mov    rax,r14
 511:	mov    eax,eax
 513:	mov    r8d,eax
 516:	mov    rax,r15
 519:	mov    eax,eax
 51b:	mov    r14d,eax
 51e:	mov    DWORD PTR [r13+0x0],r8d
 522:	mov    r13d,0x0
 528:	mov    DWORD PTR [r12+0x32c],r13d
 530:	mov    DWORD PTR [rbp+0x0],r14d
 534:	mov    r13d,0x0
 53a:	mov    DWORD PTR [r12+0x32c],r13d
 542:	mov    r13d,DWORD PTR [r12+0xa0]
 54a:	add    r13d,0x11
 54e:	mov    QWORD PTR [r12],r13
 552:	mov    r13d,0x41035c
 558:	mov    QWORD PTR [r12+0xf0],r13
 560:	mov    r13d,0x4109a4
 566:	mov    QWORD PTR [r12+0x100],r13
 56e:	mov    r11,QWORD PTR [rsp+0x10]
 573:	mov    QWORD PTR [r12+0x398],r11
 57b:	mov    edi,0x4109a4
 580:	mov    QWORD PTR [r12+0x100],rdi
 588:	add    rsp,0x20
 58c:	nop    DWORD PTR [rax+0x0]
 590:	jmp    QWORD PTR [rip+0x2]        # 0x598
 596:	xchg   ax,ax
 598:	nop
 599:	and    eax,edx
 59b:	jno    0x5f0
 59d:	ja     0x59f
 59f:	add    BYTE PTR [rax+0x21],bh
 5a2:	shl    BYTE PTR [rcx+0x53],1
 5a5:	ja     0x5a7
 5a7:	add    BYTE PTR [rcx-0x45],cl
 5aa:	movabs al,ds:0x4100005dd1457460
 5b3:	jmp    rbx
 5b5:	nop
 5b6:	nop
 5b7:	nop
