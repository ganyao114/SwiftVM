00007d55df7ce69b  nop [rax+rax*1], eax
00007d55df7ce6a0  mov rax, [r15+0xF8]
00007d55df7ce6a7  lea r14, [rax-0x1E0]
00007d55df7ce6ae  mov [r15+0xF8], r14
00007d55df7ce6b5  lea rax, [r14+0x1D0]
00007d55df7ce6bc  mov r12, [r15+0xA0]
00007d55df7ce6c3  mov r11, [r15+0x98]
00007d55df7ce6ca  mov [r13+rax*1], r12
00007d55df7ce6cf  lea rax, [r14+0x1D8]
00007d55df7ce6d6  mov [r13+rax*1], r11
00007d55df7ce6db  mov eax, 0x420AA0
00007d55df7ce6e0  movups xmm1, [r13+rax*1]
00007d55df7ce6e6  mov eax, 0x420A30
00007d55df7ce6eb  movups xmm15, [r13+rax*1]
00007d55df7ce6f1  mov eax, 0x420AC0
00007d55df7ce6f6  movups xmm14, [r13+rax*1]
00007d55df7ce6fc  mov eax, 0x420A60
00007d55df7ce701  movups xmm13, [r13+rax*1]
00007d55df7ce707  mov qword ptr [r15+0x98], 0x430CD0
00007d55df7ce712  mov eax, 0x420AD0
00007d55df7ce717  movups xmm12, [r13+rax*1]
00007d55df7ce71d  mov eax, 0x430CD0
00007d55df7ce722  movups [r13+rax*1], xmm1
00007d55df7ce728  mov eax, 0x430CE0
00007d55df7ce72d  movups [r13+rax*1], xmm15
00007d55df7ce733  mov eax, 0x430CF0
00007d55df7ce738  movups [r13+rax*1], xmm14
00007d55df7ce73e  mov eax, 0x430D00
00007d55df7ce743  movups [r13+rax*1], xmm13
00007d55df7ce749  mov eax, 0x420A20
00007d55df7ce74e  movups xmm14, [r13+rax*1]
00007d55df7ce754  mov eax, 0x420A10
00007d55df7ce759  movups xmm13, [r13+rax*1]
00007d55df7ce75f  mov eax, 0x430DD0
00007d55df7ce764  movups [r13+rax*1], xmm1
00007d55df7ce76a  mov eax, 0x430DE0
00007d55df7ce76f  movups [r13+rax*1], xmm15
00007d55df7ce775  mov eax, 0x430D10
00007d55df7ce77a  movups [r13+rax*1], xmm12
00007d55df7ce780  mov eax, 0x430D20
00007d55df7ce785  movups [r13+rax*1], xmm14
00007d55df7ce78b  mov eax, 0x420A00
00007d55df7ce790  movups xmm1, [r13+rax*1]
00007d55df7ce796  mov eax, 0x420A70
00007d55df7ce79b  movups xmm15, [r13+rax*1]
00007d55df7ce7a1  mov eax, 0x430D30
00007d55df7ce7a6  movups [r13+rax*1], xmm13
00007d55df7ce7ac  mov eax, 0x430D40
00007d55df7ce7b1  movups [r13+rax*1], xmm1
00007d55df7ce7b7  mov eax, 0x420A80
00007d55df7ce7bc  movups xmm1, [r13+rax*1]
00007d55df7ce7c2  mov eax, 0x420A50
00007d55df7ce7c7  movups xmm14, [r13+rax*1]
00007d55df7ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007d55df7ce7d5  mov eax, 0x430D50
00007d55df7ce7da  movups [r13+rax*1], xmm15
00007d55df7ce7e0  mov eax, 0x430D60
00007d55df7ce7e5  movups [r13+rax*1], xmm1
00007d55df7ce7eb  mov eax, 0x420AF0
00007d55df7ce7f0  movups xmm1, [r13+rax*1]
00007d55df7ce7f6  mov eax, 0x420B00
00007d55df7ce7fb  movups xmm15, [r13+rax*1]
00007d55df7ce801  movaps [r15+0x150], xmm15
00007d55df7ce809  mov qword ptr [r15+0xA0], 0x3E8
00007d55df7ce814  mov eax, 0x430D70
00007d55df7ce819  movups [r13+rax*1], xmm14
00007d55df7ce81f  mov eax, 0x430D80
00007d55df7ce824  movups [r13+rax*1], xmm1
00007d55df7ce82a  mov eax, 0x420AE0
00007d55df7ce82f  movups xmm1, [r13+rax*1]
00007d55df7ce835  mov eax, 0x420A90
00007d55df7ce83a  movups xmm14, [r13+rax*1]
00007d55df7ce840  movaps [r15+0x140], xmm14
00007d55df7ce848  lea rax, [r14+0x180]
00007d55df7ce84f  movq xmm13, qword ptr [r15+0x200]
00007d55df7ce858  movq xmm12, qword ptr [r15+0x1F0]
00007d55df7ce861  movq r12, xmm13
00007d55df7ce866  movq r11, xmm12
00007d55df7ce86b  mov [r13+rax*1], r12
00007d55df7ce870  lea rax, [r14+0x188]
00007d55df7ce877  mov [r13+rax*1], r11
00007d55df7ce87c  mov eax, 0x430D90
00007d55df7ce881  movups [r13+rax*1], xmm15
00007d55df7ce887  mov eax, 0x430DA0
00007d55df7ce88c  movups [r13+rax*1], xmm1
00007d55df7ce892  mov eax, 0x420AB0
00007d55df7ce897  movups xmm1, [r13+rax*1]
00007d55df7ce89d  mov eax, 0x420B18
00007d55df7ce8a2  mov r12, [r13+rax*1]
00007d55df7ce8a7  movq xmm15, r12
00007d55df7ce8ac  mov qword ptr [r15+0x40], 0x420B20
00007d55df7ce8b4  mov eax, 0x430DB0
00007d55df7ce8b9  movups [r13+rax*1], xmm14
00007d55df7ce8bf  mov eax, 0x430DC0
00007d55df7ce8c4  movups [r13+rax*1], xmm1
00007d55df7ce8ca  mov eax, 0x420B80
00007d55df7ce8cf  movups xmm1, [r13+rax*1]
00007d55df7ce8d5  movq rax, xmm15
00007d55df7ce8da  mov r12d, 0x430DF0
00007d55df7ce8e0  mov [r13+r12*1], rax
00007d55df7ce8e5  mov eax, 0x420B60
00007d55df7ce8ea  movups xmm15, [r13+rax*1]
00007d55df7ce8f0  mov eax, 0x420B70
00007d55df7ce8f5  movups xmm14, [r13+rax*1]
00007d55df7ce8fb  lea rax, [r14+0x160]
00007d55df7ce902  movups [r13+rax*1], xmm1
00007d55df7ce908  lea rax, [r14+0x190]
00007d55df7ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007d55df7ce918  movq xmm13, qword ptr [r15+0x1D0]
00007d55df7ce921  movq r12, xmm1
00007d55df7ce926  movq r11, xmm13
00007d55df7ce92b  mov [r13+rax*1], r12
00007d55df7ce930  lea rax, [r14+0x198]
00007d55df7ce937  mov [r13+rax*1], r11
00007d55df7ce93c  lea rax, [r14+0x140]
00007d55df7ce943  movups [r13+rax*1], xmm15
00007d55df7ce949  lea rax, [r14+0x150]
00007d55df7ce950  movups [r13+rax*1], xmm14
00007d55df7ce956  mov eax, 0x420B20
00007d55df7ce95b  movups xmm1, [r13+rax*1]
00007d55df7ce961  mov eax, 0x420B30
00007d55df7ce966  movups xmm15, [r13+rax*1]
00007d55df7ce96c  movaps [r15+0x120], xmm15
00007d55df7ce974  lea rax, [r14+0x1A0]
00007d55df7ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007d55df7ce984  movq xmm13, qword ptr [r15+0x1B0]
00007d55df7ce98d  movq r12, xmm14
00007d55df7ce992  movq r11, xmm13
00007d55df7ce997  mov [r13+rax*1], r12
00007d55df7ce99c  lea rax, [r14+0x1A8]
00007d55df7ce9a3  mov [r13+rax*1], r11
00007d55df7ce9a8  lea rax, [r14+0x1B0]
00007d55df7ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007d55df7ce9b8  movq xmm13, qword ptr [r15+0x190]
00007d55df7ce9c1  movq r12, xmm14
00007d55df7ce9c6  movq r11, xmm13
00007d55df7ce9cb  mov [r13+rax*1], r12
00007d55df7ce9d0  lea rax, [r14+0x1B8]
00007d55df7ce9d7  mov [r13+rax*1], r11
00007d55df7ce9dc  lea rax, [r14+0x100]
00007d55df7ce9e3  movups [r13+rax*1], xmm1
00007d55df7ce9e9  lea rax, [r14+0x110]
00007d55df7ce9f0  movups [r13+rax*1], xmm15
00007d55df7ce9f6  mov eax, 0x420B40
00007d55df7ce9fb  movups xmm1, [r13+rax*1]
00007d55df7cea01  mov eax, 0x420B50
00007d55df7cea06  movups xmm15, [r13+rax*1]
00007d55df7cea0c  movaps [r15+0x110], xmm1
00007d55df7cea14  movaps [r15+0x130], xmm15
00007d55df7cea1c  lea rax, [r14+0x1C0]
00007d55df7cea23  mov r12, [r15+0xE8]
00007d55df7cea2a  mov r11, [r15+0xF0]
00007d55df7cea31  mov [r13+rax*1], r12
00007d55df7cea36  lea rax, [r14+0x1C8]
00007d55df7cea3d  mov [r13+rax*1], r11
00007d55df7cea42  mov eax, 0x430DF8
00007d55df7cea47  mov r12d, 0x421DF8D3
00007d55df7cea4d  mov [r13+rax*1], r12d
00007d55df7cea52  lea rax, [r14+0x120]
00007d55df7cea59  movups [r13+rax*1], xmm1
00007d55df7cea5f  lea rax, [r14+0x130]
00007d55df7cea66  movups [r13+rax*1], xmm15
00007d55df7cea6c  lea rax, [r14+0x100]
00007d55df7cea73  mov [r15], rax
00007d55df7cea76  mov qword ptr [r15+0x08], 0x430CD0
00007d55df7cea7e  mov qword ptr [r15+0x10], 0x12C
00007d55df7cea86  mov qword ptr [r15+0xF0], 0x410284
00007d55df7cea91  mov r14d, [r15+0x320]
00007d55df7cea98  mov eax, 0x410284
00007d55df7cea9d  mov rcx, 0x7D55DF7D07C0
00007d55df7ceaa7  mov [r15+r14*8+0x328], rax
00007d55df7ceaaf  mov [r15+r14*8+0x368], rcx
00007d55df7ceab7  add r14d, 0x01
00007d55df7ceabb  and r14d, 0x07
00007d55df7ceabf  mov [r15+0x320], r14d
00007d55df7ceac6  cmp dword ptr [r15+0x318], 0x00
00007d55df7ceace  jz 0x00007D55DF7CED70
00007d55df7cead4  nop [rax+rax*1], ax
00007d55df7ceadd  nop [rax+rax*1], eax
00007d55df7ceae5  mov eax, 0x410728
00007d55df7ceaea  mov [r15+0x100], rax
00007d55df7ceaf1  jmp 0x00007D55DF5FE110
00007d55df7ceaf6  int3
00007d55df7ceaf7  call 0x00007D55DF60BC20
00007d55df7ceafc  jmp 0x00007D55DF7CE6CF
00007d55df7ceb01  call 0x00007D55DF60A9A0
00007d55df7ceb06  jmp 0x00007D55DF7CE6DB
00007d55df7ceb0b  call 0x00007D55DF5FF430
00007d55df7ceb10  jmp 0x00007D55DF7CE6E6
00007d55df7ceb15  call 0x00007D55DF60E760
00007d55df7ceb1a  jmp 0x00007D55DF7CE6F1
00007d55df7ceb1f  call 0x00007D55DF60D4E0
00007d55df7ceb24  jmp 0x00007D55DF7CE6FC
00007d55df7ceb29  call 0x00007D55DF60C260
00007d55df7ceb2e  jmp 0x00007D55DF7CE707
00007d55df7ceb33  call 0x00007D55DF60AFE0
00007d55df7ceb38  jmp 0x00007D55DF7CE71D
00007d55df7ceb3d  call 0x00007D55DF5FF540
00007d55df7ceb42  jmp 0x00007D55DF7CE728
00007d55df7ceb47  call 0x00007D55DF60E880
00007d55df7ceb4c  jmp 0x00007D55DF7CE733
00007d55df7ceb51  call 0x00007D55DF60D600
00007d55df7ceb56  jmp 0x00007D55DF7CE73E
00007d55df7ceb5b  call 0x00007D55DF60C380
00007d55df7ceb60  jmp 0x00007D55DF7CE749
00007d55df7ceb65  call 0x00007D55DF60D4E0
00007d55df7ceb6a  jmp 0x00007D55DF7CE754
00007d55df7ceb6f  call 0x00007D55DF60C260
00007d55df7ceb74  jmp 0x00007D55DF7CE75F
00007d55df7ceb79  call 0x00007D55DF5FF540
00007d55df7ceb7e  jmp 0x00007D55DF7CE76A
00007d55df7ceb83  call 0x00007D55DF60E880
00007d55df7ceb88  jmp 0x00007D55DF7CE775
00007d55df7ceb8d  call 0x00007D55DF60B100
00007d55df7ceb92  jmp 0x00007D55DF7CE780
00007d55df7ceb97  call 0x00007D55DF60D600
00007d55df7ceb9c  jmp 0x00007D55DF7CE78B
00007d55df7ceba1  call 0x00007D55DF5FF430
00007d55df7ceba6  jmp 0x00007D55DF7CE796
00007d55df7cebab  call 0x00007D55DF60E760
00007d55df7cebb0  jmp 0x00007D55DF7CE7A1
00007d55df7cebb5  call 0x00007D55DF60C380
00007d55df7cebba  jmp 0x00007D55DF7CE7AC
00007d55df7cebbf  call 0x00007D55DF5FF540
00007d55df7cebc4  jmp 0x00007D55DF7CE7B7
00007d55df7cebc9  call 0x00007D55DF5FF430
00007d55df7cebce  jmp 0x00007D55DF7CE7C2
00007d55df7cebd3  call 0x00007D55DF60D4E0
00007d55df7cebd8  jmp 0x00007D55DF7CE7CD
00007d55df7cebdd  call 0x00007D55DF60E880
00007d55df7cebe2  jmp 0x00007D55DF7CE7E0
00007d55df7cebe7  call 0x00007D55DF5FF540
00007d55df7cebec  jmp 0x00007D55DF7CE7EB
00007d55df7cebf1  call 0x00007D55DF5FF430
00007d55df7cebf6  jmp 0x00007D55DF7CE7F6
00007d55df7cebfb  call 0x00007D55DF60E760
00007d55df7cec00  jmp 0x00007D55DF7CE801
00007d55df7cec05  call 0x00007D55DF60D600
00007d55df7cec0a  jmp 0x00007D55DF7CE81F
00007d55df7cec0f  call 0x00007D55DF5FF540
00007d55df7cec14  jmp 0x00007D55DF7CE82A
00007d55df7cec19  call 0x00007D55DF5FF430
00007d55df7cec1e  jmp 0x00007D55DF7CE835
00007d55df7cec23  call 0x00007D55DF60D4E0
00007d55df7cec28  jmp 0x00007D55DF7CE840
00007d55df7cec2d  call 0x00007D55DF60BC20
00007d55df7cec32  jmp 0x00007D55DF7CE870
00007d55df7cec37  call 0x00007D55DF60A9A0
00007d55df7cec3c  jmp 0x00007D55DF7CE87C
00007d55df7cec41  call 0x00007D55DF60E880
00007d55df7cec46  jmp 0x00007D55DF7CE887
00007d55df7cec4b  call 0x00007D55DF5FF540
00007d55df7cec50  jmp 0x00007D55DF7CE892
00007d55df7cec55  call 0x00007D55DF5FF430
00007d55df7cec5a  jmp 0x00007D55DF7CE89D
00007d55df7cec5f  call 0x00007D55DF60B720
00007d55df7cec64  jmp 0x00007D55DF7CE8A7
00007d55df7cec69  call 0x00007D55DF60D600
00007d55df7cec6e  jmp 0x00007D55DF7CE8BF
00007d55df7cec73  call 0x00007D55DF5FF540
00007d55df7cec78  jmp 0x00007D55DF7CE8CA
00007d55df7cec7d  call 0x00007D55DF5FF430
00007d55df7cec82  jmp 0x00007D55DF7CE8D5
00007d55df7cec87  call 0x00007D55DF6B4CB0
00007d55df7cec8c  jmp 0x00007D55DF7CE8E5
00007d55df7cec91  call 0x00007D55DF60E760
00007d55df7cec96  jmp 0x00007D55DF7CE8F0
00007d55df7cec9b  call 0x00007D55DF60D4E0
00007d55df7ceca0  jmp 0x00007D55DF7CE8FB
00007d55df7ceca5  call 0x00007D55DF5FF540
00007d55df7cecaa  jmp 0x00007D55DF7CE908
00007d55df7cecaf  call 0x00007D55DF60BC20
00007d55df7cecb4  jmp 0x00007D55DF7CE930
00007d55df7cecb9  call 0x00007D55DF60A9A0
00007d55df7cecbe  jmp 0x00007D55DF7CE93C
00007d55df7cecc3  call 0x00007D55DF60E880
00007d55df7cecc8  jmp 0x00007D55DF7CE949
00007d55df7ceccd  call 0x00007D55DF60D600
00007d55df7cecd2  jmp 0x00007D55DF7CE956
00007d55df7cecd7  call 0x00007D55DF5FF430
00007d55df7cecdc  jmp 0x00007D55DF7CE961
00007d55df7cece1  call 0x00007D55DF60E760
00007d55df7cece6  jmp 0x00007D55DF7CE96C
00007d55df7ceceb  call 0x00007D55DF60BC20
00007d55df7cecf0  jmp 0x00007D55DF7CE99C
00007d55df7cecf5  call 0x00007D55DF60A9A0
00007d55df7cecfa  jmp 0x00007D55DF7CE9A8
00007d55df7cecff  call 0x00007D55DF60BC20
00007d55df7ced04  jmp 0x00007D55DF7CE9D0
00007d55df7ced09  call 0x00007D55DF60A9A0
00007d55df7ced0e  jmp 0x00007D55DF7CE9DC
00007d55df7ced13  call 0x00007D55DF5FF540
00007d55df7ced18  jmp 0x00007D55DF7CE9E9
00007d55df7ced1d  call 0x00007D55DF60E880
00007d55df7ced22  jmp 0x00007D55DF7CE9F6
00007d55df7ced27  call 0x00007D55DF5FF430
00007d55df7ced2c  jmp 0x00007D55DF7CEA01
00007d55df7ced31  call 0x00007D55DF60E760
00007d55df7ced36  jmp 0x00007D55DF7CEA0C
00007d55df7ced3b  call 0x00007D55DF60BC20
00007d55df7ced40  jmp 0x00007D55DF7CEA36
00007d55df7ced45  call 0x00007D55DF60A9A0
00007d55df7ced4a  jmp 0x00007D55DF7CEA42
00007d55df7ced4f  call 0x00007D55DF60BAE0
00007d55df7ced54  jmp 0x00007D55DF7CEA52
00007d55df7ced59  call 0x00007D55DF5FF540
00007d55df7ced5e  jmp 0x00007D55DF7CEA5F
00007d55df7ced63  call 0x00007D55DF60E880
00007d55df7ced68  jmp 0x00007D55DF7CEA6C
00007d55df7ced6d  int3
00007d55df7ced6e  nop
00007d55df7ced70  mov rax, [r15]
00007d55df7ced73  lea r14, [rax+0x20]
00007d55df7ced77  mov r12, [r13+r14*1]
00007d55df7ced7c  mov r14, [r15+0x10]
00007d55df7ced80  lea r11, [r12+r14*1]
00007d55df7ced84  mov [r15+0x40], r11
00007d55df7ced88  lea r12, [rax+0x20]
00007d55df7ced8c  mov [r13+r12*1], r11
00007d55df7ced91  test r14, r14
00007d55df7ced94  setz r14b
00007d55df7ced98  movzx r14, r14b
00007d55df7ced9c  mov [rsp+0x414], r14b
00007d55df7ceda4  cmp byte ptr [rsp+0x414], 0x00
00007d55df7cedac  jz 0x00007D55DF7CEDDE
00007d55df7cedae  cmp dword ptr [r15+0x318], 0x00
00007d55df7cedb6  mov eax, 0x4109A0
00007d55df7cedbb  mov [r15+0x100], rax
00007d55df7cedc2  jz 0x00007D55DF5FE0A0
00007d55df7cedc8  nop [rax+rax*1], eax
00007d55df7cedcd  mov eax, 0x4109A0
00007d55df7cedd2  mov [r15+0x100], rax
00007d55df7cedd9  jmp 0x00007D55DF5FE110
00007d55df7cedde  cmp dword ptr [r15+0x318], 0x00
00007d55df7cede6  jz 0x00007D55DF7CEE30
00007d55df7cedec  nop [rax+rax*1], ax
00007d55df7cedf5  nop [rax+rax*1], eax
00007d55df7cedfd  mov eax, 0x410738
00007d55df7cee02  mov [r15+0x100], rax
00007d55df7cee09  jmp 0x00007D55DF5FE110
00007d55df7cee0e  int3
00007d55df7cee0f  call 0x00007D55DF6E27E0
00007d55df7cee14  jmp 0x00007D55DF7CED7C
00007d55df7cee19  call 0x00007D55DF6C0860
00007d55df7cee1e  jmp 0x00007D55DF7CED91
00007d55df7cee23  int3
00007d55df7cee24  nop [rax+rax*1], ax
00007d55df7cee2d  nop [rax], eax
00007d55df7cee30  mov rax, [r15+0xF8]
00007d55df7cee37  lea r14, [rax-0x150]
00007d55df7cee3e  mov [r15+0xF8], r14
00007d55df7cee45  mov rax, [r15]
00007d55df7cee48  lea r12, [rax+0x68]
00007d55df7cee4c  mov r11, [r13+r12*1]
00007d55df7cee51  mov [r15+0x88], r11
00007d55df7cee58  lea r12, [rax+0x28]
00007d55df7cee5c  mov [r15+0x40], r12
00007d55df7cee60  mov [r15+0x48], r14
00007d55df7cee64  mov qword ptr [r15+0x50], 0x420B90
00007d55df7cee6c  lea rax, [r14+0x100]
00007d55df7cee73  mov r12, [r15+0xE8]
00007d55df7cee7a  mov r11, [r15+0xD8]
00007d55df7cee81  mov [r13+rax*1], r12
00007d55df7cee86  lea rax, [r14+0x108]
00007d55df7cee8d  mov [r13+rax*1], r11
00007d55df7cee92  lea rax, [r14+0x110]
00007d55df7cee99  mov r12, [r15+0xD0]
00007d55df7ceea0  mov r11, [r15+0xC8]
00007d55df7ceea7  mov [r13+rax*1], r12
00007d55df7ceeac  lea rax, [r14+0x118]
00007d55df7ceeb3  mov [r13+rax*1], r11
00007d55df7ceeb8  lea rax, [r14+0x120]
00007d55df7ceebf  mov r12, [r15+0xC0]
00007d55df7ceec6  mov r11, [r15+0xB8]
00007d55df7ceecd  mov [r13+rax*1], r12
00007d55df7ceed2  lea rax, [r14+0x128]
00007d55df7ceed9  mov [r13+rax*1], r11
00007d55df7ceede  lea rax, [r14+0x130]
00007d55df7ceee5  mov r12, [r15+0xB0]
00007d55df7ceeec  mov r11, [r15+0xA8]
00007d55df7ceef3  mov [r13+rax*1], r12
00007d55df7ceef8  lea rax, [r14+0x138]
00007d55df7ceeff  mov [r13+rax*1], r11
00007d55df7cef04  lea rax, [r14+0x140]
00007d55df7cef0b  mov r12, [r15+0xA0]
00007d55df7cef12  mov r11, [r15+0x98]
00007d55df7cef19  mov [r13+rax*1], r12
00007d55df7cef1e  lea rax, [r14+0x148]
00007d55df7cef25  mov [r13+rax*1], r11
00007d55df7cef2a  cmp dword ptr [r15+0x318], 0x00
00007d55df7cef32  jz 0x00007D55DF7CEFD0
00007d55df7cef38  nop [rax+rax*1], ax
00007d55df7cef41  nop [rax+rax*1], eax
00007d55df7cef49  mov eax, 0x410770
00007d55df7cef4e  mov [r15+0x100], rax
00007d55df7cef55  jmp 0x00007D55DF5FE110
00007d55df7cef5a  int3
00007d55df7cef5b  call 0x00007D55DF6C0370
00007d55df7cef60  jmp 0x00007D55DF7CEE51
00007d55df7cef65  call 0x00007D55DF60BC20
00007d55df7cef6a  jmp 0x00007D55DF7CEE86
00007d55df7cef6f  call 0x00007D55DF60A9A0
00007d55df7cef74  jmp 0x00007D55DF7CEE92
00007d55df7cef79  call 0x00007D55DF60BC20
00007d55df7cef7e  jmp 0x00007D55DF7CEEAC
00007d55df7cef83  call 0x00007D55DF60A9A0
00007d55df7cef88  jmp 0x00007D55DF7CEEB8
00007d55df7cef8d  call 0x00007D55DF60BC20
00007d55df7cef92  jmp 0x00007D55DF7CEED2
00007d55df7cef97  call 0x00007D55DF60A9A0
00007d55df7cef9c  jmp 0x00007D55DF7CEEDE
00007d55df7cefa1  call 0x00007D55DF60BC20
00007d55df7cefa6  jmp 0x00007D55DF7CEEF8
00007d55df7cefab  call 0x00007D55DF60A9A0
00007d55df7cefb0  jmp 0x00007D55DF7CEF04
00007d55df7cefb5  call 0x00007D55DF60BC20
00007d55df7cefba  jmp 0x00007D55DF7CEF1E
00007d55df7cefbf  call 0x00007D55DF60A9A0
00007d55df7cefc4  jmp 0x00007D55DF7CEF2A
00007d55df7cefc9  int3
00007d55df7cefca  nop [rax+rax*1], ax
00007d55df7cefd0  mov rax, [r15+0x08]
00007d55df7cefd4  movzx r14d, byte ptr [r13+rax*1]
00007d55df7cefda  movzx r14d, r14b
00007d55df7cefde  mov [rsp+0x10], r14d
00007d55df7cefe3  mov r14d, r14d
00007d55df7cefe6  mov [r15+0x58], r14
00007d55df7cefea  lea r14, [rax+0x01]
00007d55df7cefee  mov [r15+0x08], r14
00007d55df7ceff2  mov rax, [r15+0x88]
00007d55df7ceff9  lea r14, [rax+0x01]
00007d55df7ceffd  mov r12, [r15]
00007d55df7cf000  lea r11, [r12+0x68]
00007d55df7cf005  mov [r13+r11*1], r14
00007d55df7cf00a  lea r14, [r12+rax*1]
00007d55df7cf00e  mov [r15+0x60], r14
00007d55df7cf012  lea rax, [r14+0x28]
00007d55df7cf016  mov r11d, [rsp+0x10]
00007d55df7cf01b  movzx r14d, r11b
00007d55df7cf01f  mov [r13+rax*1], r14b
00007d55df7cf024  lea rax, [r12+0x68]
00007d55df7cf029  mov r14, [r13+rax*1]
00007d55df7cf02e  mov [r15+0x88], r14
00007d55df7cf035  xor eax, eax
00007d55df7cf037  mov r12d, 0x40
00007d55df7cf03d  cmp r14, r12
00007d55df7cf040  cmc
00007d55df7cf041  lahf
00007d55df7cf042  seto al
00007d55df7cf045  mov [r15+0x108], eax
00007d55df7cf04c  mov eax, [r15+0x108]
00007d55df7cf053  sahf
00007d55df7cf054  jnz 0x00007D55DF7CF086
00007d55df7cf056  cmp dword ptr [r15+0x318], 0x00
00007d55df7cf05e  jz 0x00007D55DF7CF170
00007d55df7cf064  nop [rax+rax*1], ax
00007d55df7cf06d  nop [rax+rax*1], eax
00007d55df7cf075  mov eax, 0x410790
00007d55df7cf07a  mov [r15+0x100], rax
00007d55df7cf081  jmp 0x00007D55DF5FE110
00007d55df7cf086  cmp dword ptr [r15+0x318], 0x00
00007d55df7cf08e  jz 0x00007D55DF7CF0E0
00007d55df7cf094  nop [rax+rax*1], ax
00007d55df7cf09d  nop [rax+rax*1], eax
00007d55df7cf0a5  mov eax, 0x410768
00007d55df7cf0aa  mov [r15+0x100], rax
00007d55df7cf0b1  jmp 0x00007D55DF5FE110
00007d55df7cf0b6  int3
00007d55df7cf0b7  call 0x00007D55DF60D860
00007d55df7cf0bc  jmp 0x00007D55DF7CEFDA
00007d55df7cf0c1  call 0x00007D55DF6B36E0
00007d55df7cf0c6  jmp 0x00007D55DF7CF00A
00007d55df7cf0cb  call 0x00007D55DF60DD60
00007d55df7cf0d0  jmp 0x00007D55DF7CF024
00007d55df7cf0d5  call 0x00007D55DF60DC20
00007d55df7cf0da  jmp 0x00007D55DF7CF02E
00007d55df7cf0df  int3
00007d55df7cf0e0  mov rax, [r15+0x10]
00007d55df7cf0e4  lea r14, [rax-0x01]
00007d55df7cf0e8  mov [r15+0x10], r14
00007d55df7cf0ec  test r14, r14
00007d55df7cf0ef  setz r14b
00007d55df7cf0f3  movzx r14, r14b
00007d55df7cf0f7  mov [rsp+0x414], r14b
00007d55df7cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007d55df7cf107  jz 0x00007D55DF7CF139
00007d55df7cf109  cmp dword ptr [r15+0x318], 0x00
00007d55df7cf111  jz 0x00007D55DF7D0670
00007d55df7cf117  nop [rax+rax*1], ax
00007d55df7cf120  nop [rax+rax*1], eax
00007d55df7cf128  mov eax, 0x410988
00007d55df7cf12d  mov [r15+0x100], rax
00007d55df7cf134  jmp 0x00007D55DF5FE110
00007d55df7cf139  cmp dword ptr [r15+0x318], 0x00
00007d55df7cf141  jz 0x00007D55DF7CEFD0
00007d55df7cf147  nop [rax+rax*1], ax
00007d55df7cf150  nop [rax+rax*1], eax
00007d55df7cf158  mov eax, 0x410770
00007d55df7cf15d  mov [r15+0x100], rax
00007d55df7cf164  jmp 0x00007D55DF5FE110
00007d55df7cf169  int3
00007d55df7cf16a  int3
00007d55df7cf16b  nop [rax+rax*1], eax
00007d55df7cf170  mov rax, [r15+0x40]
00007d55df7cf174  movzx r14d, byte ptr [r13+rax*1]
00007d55df7cf17a  movaps xmm1, [r15+0x110]
00007d55df7cf182  pinsrb xmm1, r14d, 0x00
00007d55df7cf189  lea r14, [rax+0x01]
00007d55df7cf18d  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf193  movaps xmm15, [r15+0x120]
00007d55df7cf19b  pinsrb xmm15, r12d, 0x00
00007d55df7cf1a2  lea r14, [rax+0x02]
00007d55df7cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf1ac  movaps xmm14, [r15+0x130]
00007d55df7cf1b4  pinsrb xmm14, r12d, 0x00
00007d55df7cf1bb  lea r14, [rax+0x03]
00007d55df7cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf1c5  movaps xmm13, [r15+0x140]
00007d55df7cf1cd  pinsrb xmm13, r12d, 0x00
00007d55df7cf1d4  lea r14, [rax+0x04]
00007d55df7cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf1de  pinsrb xmm1, r12d, 0x01
00007d55df7cf1e5  lea r14, [rax+0x05]
00007d55df7cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf1ef  pinsrb xmm15, r12d, 0x01
00007d55df7cf1f6  lea r14, [rax+0x06]
00007d55df7cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf200  pinsrb xmm14, r12d, 0x01
00007d55df7cf207  lea r14, [rax+0x07]
00007d55df7cf20b  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf211  pinsrb xmm13, r12d, 0x01
00007d55df7cf218  lea r14, [rax+0x08]
00007d55df7cf21c  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf222  pinsrb xmm1, r12d, 0x02
00007d55df7cf229  lea r14, [rax+0x09]
00007d55df7cf22d  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf233  pinsrb xmm15, r12d, 0x02
00007d55df7cf23a  lea r14, [rax+0x0A]
00007d55df7cf23e  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf244  pinsrb xmm14, r12d, 0x02
00007d55df7cf24b  lea r14, [rax+0x0B]
00007d55df7cf24f  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf255  pinsrb xmm13, r12d, 0x02
00007d55df7cf25c  lea r14, [rax+0x0C]
00007d55df7cf260  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf266  pinsrb xmm1, r12d, 0x03
00007d55df7cf26d  lea r14, [rax+0x0D]
00007d55df7cf271  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf277  pinsrb xmm15, r12d, 0x03
00007d55df7cf27e  lea r14, [rax+0x0E]
00007d55df7cf282  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf288  pinsrb xmm14, r12d, 0x03
00007d55df7cf28f  lea r14, [rax+0x0F]
00007d55df7cf293  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf299  pinsrb xmm13, r12d, 0x03
00007d55df7cf2a0  lea r14, [rax+0x10]
00007d55df7cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf2aa  pinsrb xmm1, r12d, 0x04
00007d55df7cf2b1  lea r14, [rax+0x11]
00007d55df7cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf2bb  pinsrb xmm15, r12d, 0x04
00007d55df7cf2c2  lea r14, [rax+0x12]
00007d55df7cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf2cc  pinsrb xmm14, r12d, 0x04
00007d55df7cf2d3  lea r14, [rax+0x13]
00007d55df7cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf2dd  pinsrb xmm13, r12d, 0x04
00007d55df7cf2e4  lea r14, [rax+0x14]
00007d55df7cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf2ee  pinsrb xmm1, r12d, 0x05
00007d55df7cf2f5  lea r14, [rax+0x15]
00007d55df7cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf2ff  pinsrb xmm15, r12d, 0x05
00007d55df7cf306  lea r14, [rax+0x16]
00007d55df7cf30a  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf310  pinsrb xmm14, r12d, 0x05
00007d55df7cf317  lea r14, [rax+0x17]
00007d55df7cf31b  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf321  pinsrb xmm13, r12d, 0x05
00007d55df7cf328  lea r14, [rax+0x18]
00007d55df7cf32c  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf332  pinsrb xmm1, r12d, 0x06
00007d55df7cf339  lea r14, [rax+0x19]
00007d55df7cf33d  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf343  pinsrb xmm15, r12d, 0x06
00007d55df7cf34a  lea r14, [rax+0x1A]
00007d55df7cf34e  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf354  pinsrb xmm14, r12d, 0x06
00007d55df7cf35b  lea r14, [rax+0x1B]
00007d55df7cf35f  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf365  pinsrb xmm13, r12d, 0x06
00007d55df7cf36c  lea r14, [rax+0x1C]
00007d55df7cf370  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf376  pinsrb xmm1, r12d, 0x07
00007d55df7cf37d  lea r14, [rax+0x1D]
00007d55df7cf381  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf387  pinsrb xmm15, r12d, 0x07
00007d55df7cf38e  lea r14, [rax+0x1E]
00007d55df7cf392  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf398  pinsrb xmm14, r12d, 0x07
00007d55df7cf39f  lea r14, [rax+0x1F]
00007d55df7cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf3a9  pinsrb xmm13, r12d, 0x07
00007d55df7cf3b0  lea r14, [rax+0x20]
00007d55df7cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf3ba  pinsrb xmm1, r12d, 0x08
00007d55df7cf3c1  lea r14, [rax+0x21]
00007d55df7cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf3cb  pinsrb xmm15, r12d, 0x08
00007d55df7cf3d2  lea r14, [rax+0x22]
00007d55df7cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf3dc  pinsrb xmm14, r12d, 0x08
00007d55df7cf3e3  lea r14, [rax+0x23]
00007d55df7cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf3ed  pinsrb xmm13, r12d, 0x08
00007d55df7cf3f4  lea r14, [rax+0x24]
00007d55df7cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf3fe  pinsrb xmm1, r12d, 0x09
00007d55df7cf405  lea r14, [rax+0x25]
00007d55df7cf409  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf40f  pinsrb xmm15, r12d, 0x09
00007d55df7cf416  lea r14, [rax+0x26]
00007d55df7cf41a  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf420  pinsrb xmm14, r12d, 0x09
00007d55df7cf427  lea r14, [rax+0x27]
00007d55df7cf42b  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf431  pinsrb xmm13, r12d, 0x09
00007d55df7cf438  lea r14, [rax+0x28]
00007d55df7cf43c  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf442  pinsrb xmm1, r12d, 0x0A
00007d55df7cf449  lea r14, [rax+0x29]
00007d55df7cf44d  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf453  pinsrb xmm15, r12d, 0x0A
00007d55df7cf45a  lea r14, [rax+0x2A]
00007d55df7cf45e  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf464  pinsrb xmm14, r12d, 0x0A
00007d55df7cf46b  lea r14, [rax+0x2B]
00007d55df7cf46f  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf475  pinsrb xmm13, r12d, 0x0A
00007d55df7cf47c  lea r14, [rax+0x2C]
00007d55df7cf480  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf486  pinsrb xmm1, r12d, 0x0B
00007d55df7cf48d  lea r14, [rax+0x2D]
00007d55df7cf491  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf497  pinsrb xmm15, r12d, 0x0B
00007d55df7cf49e  lea r14, [rax+0x2E]
00007d55df7cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf4a8  pinsrb xmm14, r12d, 0x0B
00007d55df7cf4af  lea r14, [rax+0x2F]
00007d55df7cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf4b9  pinsrb xmm13, r12d, 0x0B
00007d55df7cf4c0  lea r14, [rax+0x30]
00007d55df7cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf4ca  pinsrb xmm1, r12d, 0x0C
00007d55df7cf4d1  lea r14, [rax+0x31]
00007d55df7cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf4db  pinsrb xmm15, r12d, 0x0C
00007d55df7cf4e2  lea r14, [rax+0x32]
00007d55df7cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf4ec  pinsrb xmm14, r12d, 0x0C
00007d55df7cf4f3  lea r14, [rax+0x33]
00007d55df7cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf4fd  pinsrb xmm13, r12d, 0x0C
00007d55df7cf504  lea r14, [rax+0x34]
00007d55df7cf508  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf50e  pinsrb xmm1, r12d, 0x0D
00007d55df7cf515  lea r14, [rax+0x35]
00007d55df7cf519  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf51f  pinsrb xmm15, r12d, 0x0D
00007d55df7cf526  lea r14, [rax+0x36]
00007d55df7cf52a  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf530  pinsrb xmm14, r12d, 0x0D
00007d55df7cf537  lea r14, [rax+0x37]
00007d55df7cf53b  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf541  pinsrb xmm13, r12d, 0x0D
00007d55df7cf548  lea r14, [rax+0x38]
00007d55df7cf54c  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf552  pinsrb xmm1, r12d, 0x0E
00007d55df7cf559  lea r14, [rax+0x39]
00007d55df7cf55d  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf563  pinsrb xmm15, r12d, 0x0E
00007d55df7cf56a  lea r14, [rax+0x3A]
00007d55df7cf56e  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf574  pinsrb xmm14, r12d, 0x0E
00007d55df7cf57b  lea r14, [rax+0x3B]
00007d55df7cf57f  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf585  pinsrb xmm13, r12d, 0x0E
00007d55df7cf58c  lea r14, [rax+0x3C]
00007d55df7cf590  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf596  pinsrb xmm1, r12d, 0x0F
00007d55df7cf59d  movaps [r15+0x110], xmm1
00007d55df7cf5a5  lea r14, [rax+0x3D]
00007d55df7cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf5af  pinsrb xmm15, r12d, 0x0F
00007d55df7cf5b6  movaps [r15+0x120], xmm15
00007d55df7cf5be  lea r14, [rax+0x3E]
00007d55df7cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007d55df7cf5c8  pinsrb xmm14, r12d, 0x0F
00007d55df7cf5cf  movaps [r15+0x130], xmm14
00007d55df7cf5d7  lea r14, [rax+0x3F]
00007d55df7cf5db  movzx eax, byte ptr [r13+r14*1]
00007d55df7cf5e1  pinsrb xmm13, eax, 0x0F
00007d55df7cf5e8  movaps [r15+0x140], xmm13
00007d55df7cf5f0  movq xmm1, qword ptr [r15+0x120]
00007d55df7cf5f9  pmovzxbw xmm1, xmm1
00007d55df7cf5fe  psllw xmm1, 0x00
00007d55df7cf603  movaps [r15+0x150], xmm1
00007d55df7cf60b  movq xmm1, qword ptr [r15+0x130]
00007d55df7cf614  pmovzxbw xmm1, xmm1
00007d55df7cf619  psllw xmm1, 0x00
00007d55df7cf61e  movaps [r15+0x160], xmm1
00007d55df7cf626  movq xmm1, qword ptr [r15+0x110]
00007d55df7cf62f  pmovzxbw xmm1, xmm1
00007d55df7cf634  psllw xmm1, 0x00
00007d55df7cf639  movaps [r15+0x170], xmm1
00007d55df7cf641  movaps xmm15, [r15+0x110]
00007d55df7cf649  pextrq rax, xmm15, 0x01
00007d55df7cf650  movq xmm15, rax
00007d55df7cf655  pmovzxbw xmm15, xmm15
00007d55df7cf65b  psllw xmm15, 0x00
00007d55df7cf661  movaps [r15+0x180], xmm15
00007d55df7cf669  movaps xmm14, [r15+0x120]
00007d55df7cf671  pextrq rax, xmm14, 0x01
00007d55df7cf678  movq xmm14, rax
00007d55df7cf67d  pmovzxbw xmm14, xmm14
00007d55df7cf683  psllw xmm14, 0x00
00007d55df7cf689  movaps [r15+0x210], xmm14
00007d55df7cf691  movaps xmm13, [r15+0x130]
00007d55df7cf699  pextrq rax, xmm13, 0x01
00007d55df7cf6a0  movq xmm13, rax
00007d55df7cf6a5  pmovzxbw xmm13, xmm13
00007d55df7cf6ab  psllw xmm13, 0x00
00007d55df7cf6b1  movaps [r15+0x220], xmm13
00007d55df7cf6b9  movq xmm12, qword ptr [r15+0x140]
00007d55df7cf6c2  pmovzxbw xmm12, xmm12
00007d55df7cf6c8  psllw xmm12, 0x00
00007d55df7cf6ce  movaps [r15+0x250], xmm12
00007d55df7cf6d6  movaps xmm12, [r15+0x140]
00007d55df7cf6de  pextrq rax, xmm12, 0x01
00007d55df7cf6e5  movq xmm12, rax
00007d55df7cf6ea  pmovzxbw xmm12, xmm12
00007d55df7cf6f0  psllw xmm12, 0x00
00007d55df7cf6f6  movaps [r15+0x110], xmm12
00007d55df7cf6fe  movq xmm11, qword ptr [r15+0x150]
00007d55df7cf707  pmovzxwd xmm11, xmm11
00007d55df7cf70d  pslld xmm11, 0x10
00007d55df7cf713  movq xmm10, qword ptr [r15+0x160]
00007d55df7cf71c  pmovzxwd xmm10, xmm10
00007d55df7cf722  pslld xmm10, 0x08
00007d55df7cf728  pextrq rax, xmm1, 0x01
00007d55df7cf72f  movq xmm1, rax
00007d55df7cf734  pmovzxwd xmm1, xmm1
00007d55df7cf739  pslld xmm1, 0x00
00007d55df7cf73e  movaps [r15+0x260], xmm1
00007d55df7cf746  pextrq rax, xmm15, 0x01
00007d55df7cf74d  movq xmm15, rax
00007d55df7cf752  pmovzxwd xmm15, xmm15
00007d55df7cf758  pslld xmm15, 0x00
00007d55df7cf75e  movaps [r15+0x270], xmm15
00007d55df7cf766  movq xmm9, qword ptr [r15+0x170]
00007d55df7cf76f  pmovzxwd xmm9, xmm9
00007d55df7cf775  pslld xmm9, 0x00
00007d55df7cf77b  pextrq rax, xmm14, 0x01
00007d55df7cf782  movq xmm14, rax
00007d55df7cf787  pmovzxwd xmm14, xmm14
00007d55df7cf78d  pslld xmm14, 0x10
00007d55df7cf793  movaps [r15+0x280], xmm14
00007d55df7cf79b  movq xmm8, qword ptr [r15+0x180]
00007d55df7cf7a4  pmovzxwd xmm8, xmm8
00007d55df7cf7aa  pslld xmm8, 0x00
00007d55df7cf7b0  movq xmm7, qword ptr [r15+0x210]
00007d55df7cf7b9  pmovzxwd xmm7, xmm7
00007d55df7cf7be  pslld xmm7, 0x10
00007d55df7cf7c3  movaps xmm6, [r15+0x150]
00007d55df7cf7cb  pextrq rax, xmm6, 0x01
00007d55df7cf7d2  movq xmm6, rax
00007d55df7cf7d7  pmovzxwd xmm6, xmm6
00007d55df7cf7dc  pslld xmm6, 0x10
00007d55df7cf7e1  por xmm11, xmm10
00007d55df7cf7e6  movaps [r15+0x230], xmm11
00007d55df7cf7ee  pextrq rax, xmm13, 0x01
00007d55df7cf7f5  movq xmm13, rax
00007d55df7cf7fa  pmovzxwd xmm13, xmm13
00007d55df7cf800  pslld xmm13, 0x08
00007d55df7cf806  movaps [r15+0x240], xmm13
00007d55df7cf80e  movq xmm10, qword ptr [r15+0x220]
00007d55df7cf817  pmovzxwd xmm10, xmm10
00007d55df7cf81d  pslld xmm10, 0x08
00007d55df7cf823  movaps xmm5, [r15+0x160]
00007d55df7cf82b  pextrq rax, xmm5, 0x01
00007d55df7cf832  movq xmm5, rax
00007d55df7cf837  pmovzxwd xmm5, xmm5
00007d55df7cf83c  pslld xmm5, 0x08
00007d55df7cf841  pslld xmm9, 0x18
00007d55df7cf847  pslld xmm15, 0x18
00007d55df7cf84d  pslld xmm8, 0x18
00007d55df7cf853  movq xmm4, qword ptr [r15+0x250]
00007d55df7cf85c  pmovzxwd xmm4, xmm4
00007d55df7cf861  pslld xmm4, 0x00
00007d55df7cf866  por xmm14, xmm13
00007d55df7cf86b  por xmm7, xmm10
00007d55df7cf870  movaps [r15+0x210], xmm7
00007d55df7cf878  pslld xmm1, 0x18
00007d55df7cf87d  movaps [r15+0x220], xmm1
00007d55df7cf885  por xmm6, xmm5
00007d55df7cf889  por xmm11, xmm9
00007d55df7cf88e  movaps [r15+0x160], xmm11
00007d55df7cf896  pextrq rax, xmm12, 0x01
00007d55df7cf89d  movq xmm13, rax
00007d55df7cf8a2  pmovzxwd xmm13, xmm13
00007d55df7cf8a8  pslld xmm13, 0x00
00007d55df7cf8ae  movaps [r15+0x170], xmm13
00007d55df7cf8b6  movq xmm12, qword ptr [r15+0x110]
00007d55df7cf8bf  pmovzxwd xmm12, xmm12
00007d55df7cf8c5  pslld xmm12, 0x00
00007d55df7cf8cb  por xmm14, xmm15
00007d55df7cf8d0  por xmm7, xmm8
00007d55df7cf8d5  movaps xmm15, [r15+0x250]
00007d55df7cf8dd  pextrq rax, xmm15, 0x01
00007d55df7cf8e4  movq xmm15, rax
00007d55df7cf8e9  pmovzxwd xmm15, xmm15
00007d55df7cf8ef  pslld xmm15, 0x00
00007d55df7cf8f5  movaps [r15+0x180], xmm15
00007d55df7cf8fd  por xmm6, xmm1
00007d55df7cf901  movaps [r15+0x150], xmm6
00007d55df7cf909  por xmm11, xmm4
00007d55df7cf90e  movaps [r15+0x140], xmm11
00007d55df7cf916  por xmm7, xmm12
00007d55df7cf91b  movaps [r15+0x110], xmm7
00007d55df7cf923  por xmm14, xmm13
00007d55df7cf928  movaps [r15+0x120], xmm14
00007d55df7cf930  por xmm6, xmm15
00007d55df7cf935  movaps [r15+0x130], xmm6
00007d55df7cf93d  mov rax, [r15+0xF8]
00007d55df7cf944  lea r14, [rax+0x20]
00007d55df7cf948  movups [r13+r14*1], xmm7
00007d55df7cf94e  lea r14, [rax+0x30]
00007d55df7cf952  movups [r13+r14*1], xmm14
00007d55df7cf958  movups [r13+rax*1], xmm11
00007d55df7cf95e  lea r14, [rax+0x10]
00007d55df7cf962  movups [r13+r14*1], xmm6
00007d55df7cf968  mov r14d, [r13+rax*1]
00007d55df7cf96d  mov rax, [r15+0x48]
00007d55df7cf971  mov [r15+0x68], rax
00007d55df7cf975  mov qword ptr [r15+0x58], 0x04
00007d55df7cf97d  lea r12, [rax+0x04]
00007d55df7cf981  mov r11d, [r13+r12*1]
00007d55df7cf986  mov [rsp+0x10], r11d
00007d55df7cf98b  mov r11d, r11d
00007d55df7cf98e  mov [r15+0x70], r11
00007d55df7cf992  lea r12, [rax+0x38]
00007d55df7cf996  mov r11d, [r13+r12*1]
00007d55df7cf99b  lea r12, [rax+0x24]
00007d55df7cf99f  mov r10d, [r13+r12*1]
00007d55df7cf9a4  mov [rsp+0x20], r10d
00007d55df7cf9a9  mov r10d, r10d
00007d55df7cf9ac  mov [r15+0x90], r10
00007d55df7cf9b3  mov [rsp+0x30], rax
00007d55df7cf9b8  xor eax, eax
00007d55df7cf9ba  mov r12d, 0x04
00007d55df7cf9c0  mov r10d, 0xC0
00007d55df7cf9c6  cmp r12, r10
00007d55df7cf9c9  cmc
00007d55df7cf9ca  lahf
00007d55df7cf9cb  seto al
00007d55df7cf9ce  mov [r15+0x108], eax
00007d55df7cf9d5  mov eax, [rsp+0x10]
00007d55df7cf9d9  mov r12d, [rsp+0x10]
00007d55df7cf9de  shrd eax, r12d, 0x07
00007d55df7cf9e3  mov [rsp+0x10], r11d
00007d55df7cf9e8  mov r10d, [rsp+0x10]
00007d55df7cf9ed  shrd r11d, r10d, 0x11
00007d55df7cf9f2  mov r9d, [rsp+0x20]
00007d55df7cf9f7  lea r8d, [r9d+r14d*1]
00007d55df7cf9fc  rorx r14d, r12d, 0x12
00007d55df7cfa02  xor eax, r14d
00007d55df7cfa05  rorx r14d, r10d, 0x13
00007d55df7cfa0b  xor r11d, r14d
00007d55df7cfa0e  mov [rsp+0x10], r11d
00007d55df7cfa13  mov r11d, r11d
00007d55df7cfa16  mov [r15+0x88], r11
00007d55df7cfa1d  mov [rsp+0x20], r12d
00007d55df7cfa22  shr r12d, 0x03
00007d55df7cfa26  xor eax, r12d
00007d55df7cfa29  mov [rsp+0x40], eax
00007d55df7cfa2d  mov eax, eax
00007d55df7cfa2f  mov [r15+0x80], rax
00007d55df7cfa36  shr r10d, 0x0A
00007d55df7cfa3a  mov eax, [rsp+0x10]
00007d55df7cfa3e  xor eax, r10d
00007d55df7cfa41  mov [rsp+0x10], eax
00007d55df7cfa45  mov eax, eax
00007d55df7cfa47  mov [r15+0x78], rax
00007d55df7cfa4b  mov eax, [rsp+0x40]
00007d55df7cfa4f  lea r14d, [r8d+eax*1]
00007d55df7cfa54  mov eax, [rsp+0x10]
00007d55df7cfa58  lea r12d, [r14d+eax*1]
00007d55df7cfa5d  mov rax, [rsp+0x30]
00007d55df7cfa62  lea r14, [rax+0x40]
00007d55df7cfa66  mov [r13+r14*1], r12d
00007d55df7cfa6b  mov eax, [rsp+0x20]
00007d55df7cfa6f  mov eax, eax
00007d55df7cfa71  mov [r15+0x60], rax
00007d55df7cfa75  mov eax, [r15+0x108]
00007d55df7cfa7c  sahf
00007d55df7cfa7d  jnz 0x00007D55DF7CFAAF
00007d55df7cfa7f  cmp dword ptr [r15+0x318], 0x00
00007d55df7cfa87  jz 0x00007D55DF7CFF70
00007d55df7cfa8d  nop [rax+rax*1], ax
00007d55df7cfa96  nop [rax+rax*1], eax
00007d55df7cfa9e  mov eax, 0x41088C
00007d55df7cfaa3  mov [r15+0x100], rax
00007d55df7cfaaa  jmp 0x00007D55DF5FE110
00007d55df7cfaaf  cmp dword ptr [r15+0x318], 0x00
00007d55df7cfab7  jz 0x00007D55DF7CFDC0
00007d55df7cfabd  nop [rax+rax*1], ax
00007d55df7cfac6  nop [rax+rax*1], eax
00007d55df7cface  mov eax, 0x410844
00007d55df7cfad3  mov [r15+0x100], rax
00007d55df7cfada  jmp 0x00007D55DF5FE110
00007d55df7cfadf  int3
00007d55df7cfae0  call 0x00007D55DF60D860
00007d55df7cfae5  jmp 0x00007D55DF7CF17A
00007d55df7cfaea  call 0x00007D55DF6E2420
00007d55df7cfaef  jmp 0x00007D55DF7CF193
00007d55df7cfaf4  call 0x00007D55DF6E2420
00007d55df7cfaf9  jmp 0x00007D55DF7CF1AC
00007d55df7cfafe  call 0x00007D55DF6E2420
00007d55df7cfb03  jmp 0x00007D55DF7CF1C5
00007d55df7cfb08  call 0x00007D55DF6E2420
00007d55df7cfb0d  jmp 0x00007D55DF7CF1DE
00007d55df7cfb12  call 0x00007D55DF6E2420
00007d55df7cfb17  jmp 0x00007D55DF7CF1EF
00007d55df7cfb1c  call 0x00007D55DF6E2420
00007d55df7cfb21  jmp 0x00007D55DF7CF200
00007d55df7cfb26  call 0x00007D55DF6E2420
00007d55df7cfb2b  jmp 0x00007D55DF7CF211
00007d55df7cfb30  call 0x00007D55DF6E2420
00007d55df7cfb35  jmp 0x00007D55DF7CF222
00007d55df7cfb3a  call 0x00007D55DF6E2420
00007d55df7cfb3f  jmp 0x00007D55DF7CF233
00007d55df7cfb44  call 0x00007D55DF6E2420
00007d55df7cfb49  jmp 0x00007D55DF7CF244
00007d55df7cfb4e  call 0x00007D55DF6E2420
00007d55df7cfb53  jmp 0x00007D55DF7CF255
00007d55df7cfb58  call 0x00007D55DF6E2420
00007d55df7cfb5d  jmp 0x00007D55DF7CF266
00007d55df7cfb62  call 0x00007D55DF6E2420
00007d55df7cfb67  jmp 0x00007D55DF7CF277
00007d55df7cfb6c  call 0x00007D55DF6E2420
00007d55df7cfb71  jmp 0x00007D55DF7CF288
00007d55df7cfb76  call 0x00007D55DF6E2420
00007d55df7cfb7b  jmp 0x00007D55DF7CF299
00007d55df7cfb80  call 0x00007D55DF6E2420
00007d55df7cfb85  jmp 0x00007D55DF7CF2AA
00007d55df7cfb8a  call 0x00007D55DF6E2420
00007d55df7cfb8f  jmp 0x00007D55DF7CF2BB
00007d55df7cfb94  call 0x00007D55DF6E2420
00007d55df7cfb99  jmp 0x00007D55DF7CF2CC
00007d55df7cfb9e  call 0x00007D55DF6E2420
00007d55df7cfba3  jmp 0x00007D55DF7CF2DD
00007d55df7cfba8  call 0x00007D55DF6E2420
00007d55df7cfbad  jmp 0x00007D55DF7CF2EE
00007d55df7cfbb2  call 0x00007D55DF6E2420
00007d55df7cfbb7  jmp 0x00007D55DF7CF2FF
00007d55df7cfbbc  call 0x00007D55DF6E2420
00007d55df7cfbc1  jmp 0x00007D55DF7CF310
00007d55df7cfbc6  call 0x00007D55DF6E2420
00007d55df7cfbcb  jmp 0x00007D55DF7CF321
00007d55df7cfbd0  call 0x00007D55DF6E2420
00007d55df7cfbd5  jmp 0x00007D55DF7CF332
00007d55df7cfbda  call 0x00007D55DF6E2420
00007d55df7cfbdf  jmp 0x00007D55DF7CF343
00007d55df7cfbe4  call 0x00007D55DF6E2420
00007d55df7cfbe9  jmp 0x00007D55DF7CF354
00007d55df7cfbee  call 0x00007D55DF6E2420
00007d55df7cfbf3  jmp 0x00007D55DF7CF365
00007d55df7cfbf8  call 0x00007D55DF6E2420
00007d55df7cfbfd  jmp 0x00007D55DF7CF376
00007d55df7cfc02  call 0x00007D55DF6E2420
00007d55df7cfc07  jmp 0x00007D55DF7CF387
00007d55df7cfc0c  call 0x00007D55DF6E2420
00007d55df7cfc11  jmp 0x00007D55DF7CF398
00007d55df7cfc16  call 0x00007D55DF6E2420
00007d55df7cfc1b  jmp 0x00007D55DF7CF3A9
00007d55df7cfc20  call 0x00007D55DF6E2420
00007d55df7cfc25  jmp 0x00007D55DF7CF3BA
00007d55df7cfc2a  call 0x00007D55DF6E2420
00007d55df7cfc2f  jmp 0x00007D55DF7CF3CB
00007d55df7cfc34  call 0x00007D55DF6E2420
00007d55df7cfc39  jmp 0x00007D55DF7CF3DC
00007d55df7cfc3e  call 0x00007D55DF6E2420
00007d55df7cfc43  jmp 0x00007D55DF7CF3ED
00007d55df7cfc48  call 0x00007D55DF6E2420
00007d55df7cfc4d  jmp 0x00007D55DF7CF3FE
00007d55df7cfc52  call 0x00007D55DF6E2420
00007d55df7cfc57  jmp 0x00007D55DF7CF40F
00007d55df7cfc5c  call 0x00007D55DF6E2420
00007d55df7cfc61  jmp 0x00007D55DF7CF420
00007d55df7cfc66  call 0x00007D55DF6E2420
00007d55df7cfc6b  jmp 0x00007D55DF7CF431
00007d55df7cfc70  call 0x00007D55DF6E2420
00007d55df7cfc75  jmp 0x00007D55DF7CF442
00007d55df7cfc7a  call 0x00007D55DF6E2420
00007d55df7cfc7f  jmp 0x00007D55DF7CF453
00007d55df7cfc84  call 0x00007D55DF6E2420
00007d55df7cfc89  jmp 0x00007D55DF7CF464
00007d55df7cfc8e  call 0x00007D55DF6E2420
00007d55df7cfc93  jmp 0x00007D55DF7CF475
00007d55df7cfc98  call 0x00007D55DF6E2420
00007d55df7cfc9d  jmp 0x00007D55DF7CF486
00007d55df7cfca2  call 0x00007D55DF6E2420
00007d55df7cfca7  jmp 0x00007D55DF7CF497
00007d55df7cfcac  call 0x00007D55DF6E2420
00007d55df7cfcb1  jmp 0x00007D55DF7CF4A8
00007d55df7cfcb6  call 0x00007D55DF6E2420
00007d55df7cfcbb  jmp 0x00007D55DF7CF4B9
00007d55df7cfcc0  call 0x00007D55DF6E2420
00007d55df7cfcc5  jmp 0x00007D55DF7CF4CA
00007d55df7cfcca  call 0x00007D55DF6E2420
00007d55df7cfccf  jmp 0x00007D55DF7CF4DB
00007d55df7cfcd4  call 0x00007D55DF6E2420
00007d55df7cfcd9  jmp 0x00007D55DF7CF4EC
00007d55df7cfcde  call 0x00007D55DF6E2420
00007d55df7cfce3  jmp 0x00007D55DF7CF4FD
00007d55df7cfce8  call 0x00007D55DF6E2420
00007d55df7cfced  jmp 0x00007D55DF7CF50E
00007d55df7cfcf2  call 0x00007D55DF6E2420
00007d55df7cfcf7  jmp 0x00007D55DF7CF51F
00007d55df7cfcfc  call 0x00007D55DF6E2420
00007d55df7cfd01  jmp 0x00007D55DF7CF530
00007d55df7cfd06  call 0x00007D55DF6E2420
00007d55df7cfd0b  jmp 0x00007D55DF7CF541
00007d55df7cfd10  call 0x00007D55DF6E2420
00007d55df7cfd15  jmp 0x00007D55DF7CF552
00007d55df7cfd1a  call 0x00007D55DF6E2420
00007d55df7cfd1f  jmp 0x00007D55DF7CF563
00007d55df7cfd24  call 0x00007D55DF6E2420
00007d55df7cfd29  jmp 0x00007D55DF7CF574
00007d55df7cfd2e  call 0x00007D55DF6E2420
00007d55df7cfd33  jmp 0x00007D55DF7CF585
00007d55df7cfd38  call 0x00007D55DF6E2420
00007d55df7cfd3d  jmp 0x00007D55DF7CF596
00007d55df7cfd42  call 0x00007D55DF6E2420
00007d55df7cfd47  jmp 0x00007D55DF7CF5AF
00007d55df7cfd4c  call 0x00007D55DF6E2420
00007d55df7cfd51  jmp 0x00007D55DF7CF5C8
00007d55df7cfd56  call 0x00007D55DF6D5610
00007d55df7cfd5b  jmp 0x00007D55DF7CF5E1
00007d55df7cfd60  call 0x00007D55DF6DC580
00007d55df7cfd65  jmp 0x00007D55DF7CF94E
00007d55df7cfd6a  call 0x00007D55DF6E46C0
00007d55df7cfd6f  jmp 0x00007D55DF7CF958
00007d55df7cfd74  call 0x00007D55DF609E90
00007d55df7cfd79  jmp 0x00007D55DF7CF95E
00007d55df7cfd7e  call 0x00007D55DF6DB310
00007d55df7cfd83  jmp 0x00007D55DF7CF968
00007d55df7cfd88  call 0x00007D55DF60DAE0
00007d55df7cfd8d  jmp 0x00007D55DF7CF96D
00007d55df7cfd92  call 0x00007D55DF6C0230
00007d55df7cfd97  jmp 0x00007D55DF7CF986
00007d55df7cfd9c  call 0x00007D55DF6C0230
00007d55df7cfda1  jmp 0x00007D55DF7CF99B
00007d55df7cfda6  call 0x00007D55DF6BEFC0
00007d55df7cfdab  jmp 0x00007D55DF7CF9A4
00007d55df7cfdb0  call 0x00007D55DF6E2BA0
00007d55df7cfdb5  jmp 0x00007D55DF7CFA6B
00007d55df7cfdba  int3
00007d55df7cfdbb  nop [rax+rax*1], eax
00007d55df7cfdc0  mov rax, [r15+0x48]
00007d55df7cfdc4  mov r14, [r15+0x58]
00007d55df7cfdc8  lea r12, [rax+r14*1]
00007d55df7cfdcc  mov [r15+0x68], r12
00007d55df7cfdd0  lea rax, [r14+0x04]
00007d55df7cfdd4  mov [r15+0x58], rax
00007d55df7cfdd8  lea r14, [r12+0x04]
00007d55df7cfddd  mov r11d, [r13+r14*1]
00007d55df7cfde2  mov [rsp+0x10], r11d
00007d55df7cfde7  mov r11d, r11d
00007d55df7cfdea  mov [r15+0x70], r11
00007d55df7cfdee  lea r14, [r12+0x38]
00007d55df7cfdf3  mov r11d, [r13+r14*1]
00007d55df7cfdf8  lea r14, [r12+0x24]
00007d55df7cfdfd  mov r10d, [r13+r14*1]
00007d55df7cfe02  mov [rsp+0x20], r10d
00007d55df7cfe07  mov r10d, r10d
00007d55df7cfe0a  mov [r15+0x90], r10
00007d55df7cfe11  mov [rsp+0x30], rax
00007d55df7cfe16  xor eax, eax
00007d55df7cfe18  mov r14, [rsp+0x30]
00007d55df7cfe1d  mov r10d, 0xC0
00007d55df7cfe23  cmp r14, r10
00007d55df7cfe26  cmc
00007d55df7cfe27  lahf
00007d55df7cfe28  seto al
00007d55df7cfe2b  mov [r15+0x108], eax
00007d55df7cfe32  mov eax, [rsp+0x10]
00007d55df7cfe36  mov r14d, [rsp+0x10]
00007d55df7cfe3b  shrd eax, r14d, 0x07
00007d55df7cfe40  mov [rsp+0x10], r11d
00007d55df7cfe45  mov r10d, [rsp+0x10]
00007d55df7cfe4a  shrd r11d, r10d, 0x11
00007d55df7cfe4f  mov r9d, [r15+0x60]
00007d55df7cfe53  mov r8d, [rsp+0x20]
00007d55df7cfe58  lea ebp, [r8d+r9d*1]
00007d55df7cfe5d  rorx r9d, r14d, 0x12
00007d55df7cfe63  xor eax, r9d
00007d55df7cfe66  rorx r9d, r10d, 0x13
00007d55df7cfe6c  xor r11d, r9d
00007d55df7cfe6f  mov [rsp+0x10], r11d
00007d55df7cfe74  mov r11d, r11d
00007d55df7cfe77  mov [r15+0x88], r11
00007d55df7cfe7e  mov [rsp+0x20], r14d
00007d55df7cfe83  shr r14d, 0x03
00007d55df7cfe87  xor eax, r14d
00007d55df7cfe8a  mov [rsp+0x30], eax
00007d55df7cfe8e  mov eax, eax
00007d55df7cfe90  mov [r15+0x80], rax
00007d55df7cfe97  shr r10d, 0x0A
00007d55df7cfe9b  mov eax, [rsp+0x10]
00007d55df7cfe9f  xor eax, r10d
00007d55df7cfea2  mov [rsp+0x10], eax
00007d55df7cfea6  mov eax, eax
00007d55df7cfea8  mov [r15+0x78], rax
00007d55df7cfeac  mov eax, [rsp+0x30]
00007d55df7cfeb0  lea r14d, [ebp+eax*1]
00007d55df7cfeb6  mov eax, [rsp+0x10]
00007d55df7cfeba  lea r11d, [r14d+eax*1]
00007d55df7cfebf  lea rax, [r12+0x40]
00007d55df7cfec4  mov [r13+rax*1], r11d
00007d55df7cfec9  mov eax, [rsp+0x20]
00007d55df7cfecd  mov eax, eax
00007d55df7cfecf  mov [r15+0x60], rax
00007d55df7cfed3  mov eax, [r15+0x108]
00007d55df7cfeda  sahf
00007d55df7cfedb  jnz 0x00007D55DF7CFF0D
00007d55df7cfedd  cmp dword ptr [r15+0x318], 0x00
00007d55df7cfee5  jz 0x00007D55DF7CFF70
00007d55df7cfeeb  nop [rax+rax*1], ax
00007d55df7cfef4  nop [rax+rax*1], eax
00007d55df7cfefc  mov eax, 0x41088C
00007d55df7cff01  mov [r15+0x100], rax
00007d55df7cff08  jmp 0x00007D55DF5FE110
00007d55df7cff0d  cmp dword ptr [r15+0x318], 0x00
00007d55df7cff15  jz 0x00007D55DF7CFDC0
00007d55df7cff1b  nop [rax+rax*1], ax
00007d55df7cff24  nop [rax+rax*1], eax
00007d55df7cff2c  mov eax, 0x410844
00007d55df7cff31  mov [r15+0x100], rax
00007d55df7cff38  jmp 0x00007D55DF5FE110
00007d55df7cff3d  int3
00007d55df7cff3e  call 0x00007D55DF6E1430
00007d55df7cff43  jmp 0x00007D55DF7CFDE2
00007d55df7cff48  call 0x00007D55DF6E1430
00007d55df7cff4d  jmp 0x00007D55DF7CFDF8
00007d55df7cff52  call 0x00007D55DF6E01C0
00007d55df7cff57  jmp 0x00007D55DF7CFE02
00007d55df7cff5c  call 0x00007D55DF60A860
00007d55df7cff61  jmp 0x00007D55DF7CFEC9
00007d55df7cff66  int3
00007d55df7cff67  nop [rax+rax*1], ax
00007d55df7cff70  mov rax, [r15]
00007d55df7cff73  mov r14d, [r13+rax*1]
00007d55df7cff78  lea r12, [rax+0x04]
00007d55df7cff7c  mov r11d, [r13+r12*1]
00007d55df7cff81  mov [rsp+0x10], r14d
00007d55df7cff86  mov r14d, r14d
00007d55df7cff89  mov [r15+0x78], r14
00007d55df7cff8d  mov [rsp+0x20], r11d
00007d55df7cff92  mov r11d, r11d
00007d55df7cff95  mov [r15+0x80], r11
00007d55df7cff9c  lea r14, [rax+0x08]
00007d55df7cffa0  mov r12d, [r13+r14*1]
00007d55df7cffa5  lea r14, [rax+0x0C]
00007d55df7cffa9  mov r11d, [r13+r14*1]
00007d55df7cffae  mov [rsp+0x30], r12d
00007d55df7cffb3  mov r12d, r12d
00007d55df7cffb6  mov [r15+0x70], r12
00007d55df7cffba  mov [rsp+0x40], r11d
00007d55df7cffbf  mov r11d, r11d
00007d55df7cffc2  mov [r15+0x68], r11
00007d55df7cffc6  lea r14, [rax+0x18]
00007d55df7cffca  mov r12d, [r13+r14*1]
00007d55df7cffcf  lea r14, [rax+0x1C]
00007d55df7cffd3  mov r11d, [r13+r14*1]
00007d55df7cffd8  mov [rsp+0x50], r12d
00007d55df7cffdd  mov r12d, r12d
00007d55df7cffe0  mov [r15+0x58], r12
00007d55df7cffe4  mov [rsp+0x60], r11d
00007d55df7cffe9  mov r11d, r11d
00007d55df7cffec  mov [r15+0x60], r11
00007d55df7cfff0  lea r14, [rax+0x10]
00007d55df7cfff4  mov r12d, [r13+r14*1]
00007d55df7cfff9  lea r14, [rax+0x14]
00007d55df7cfffd  mov eax, [r13+r14*1]
00007d55df7d0002  mov [rsp+0x70], r12d
00007d55df7d0007  mov r12d, r12d
00007d55df7d000a  mov [r15+0x18], r12
00007d55df7d000e  mov [rsp+0x80], eax
00007d55df7d0015  mov eax, eax
00007d55df7d0017  mov [r15+0x90], rax
00007d55df7d001e  mov eax, [rsp+0x70]
00007d55df7d0022  mov eax, eax
00007d55df7d0024  mov [r15+0x30], rax
00007d55df7d0028  mov eax, [rsp+0x50]
00007d55df7d002c  mov eax, eax
00007d55df7d002e  mov [r15+0xA0], rax
00007d55df7d0035  mov eax, [rsp+0x30]
00007d55df7d0039  mov eax, eax
00007d55df7d003b  mov [r15+0x28], rax
00007d55df7d003f  mov eax, [rsp+0x20]
00007d55df7d0043  mov eax, eax
00007d55df7d0045  mov [r15+0x98], rax
00007d55df7d004c  mov eax, [rsp+0x10]
00007d55df7d0050  mov eax, eax
00007d55df7d0052  mov [r15+0x38], rax
00007d55df7d0056  mov eax, [rsp+0x70]
00007d55df7d005a  mov r14d, [rsp+0x70]
00007d55df7d005f  shrd eax, r14d, 0x06
00007d55df7d0064  mov [rsp+0x70], r14d
00007d55df7d0069  mov r12d, [rsp+0x80]
00007d55df7d0071  and r14d, r12d
00007d55df7d0074  mov r11d, [rsp+0x10]
00007d55df7d0079  mov r10d, [rsp+0x10]
00007d55df7d007e  shrd r11d, r10d, 0x02
00007d55df7d0083  mov [rsp+0x10], r12d
00007d55df7d0088  mov r12d, r12d
00007d55df7d008b  mov [r15+0x20], r12
00007d55df7d008f  mov r12, [r15+0x50]
00007d55df7d0093  mov r9d, [r13+r12*1]
00007d55df7d0098  mov r12d, [rsp+0x50]
00007d55df7d009d  mov r8d, [rsp+0x70]
00007d55df7d00a2  andn ebp, r8d, r12d
00007d55df7d00a7  mov edi, [rsp+0x60]
00007d55df7d00ab  lea esi, [r14d+edi*1]
00007d55df7d00b0  rorx r14d, r8d, 0x0B
00007d55df7d00b6  xor eax, r14d
00007d55df7d00b9  rorx r14d, r10d, 0x0D
00007d55df7d00bf  xor r11d, r14d
00007d55df7d00c2  lea edi, [esi+ebp*1]
00007d55df7d00c6  mov r14, [r15+0x48]
00007d55df7d00ca  mov ebp, [r13+r14*1]
00007d55df7d00cf  mov r14d, [rsp+0x30]
00007d55df7d00d4  mov esi, [rsp+0x20]
00007d55df7d00d8  and r14d, esi
00007d55df7d00db  mov [rsp+0x20], r14d
00007d55df7d00e0  mov r14d, r14d
00007d55df7d00e3  mov [r15+0xD8], r14
00007d55df7d00ea  lea r14d, [edi+r9d*1]
00007d55df7d00ef  mov r9d, [rsp+0x30]
00007d55df7d00f4  xor r9d, esi
00007d55df7d00f7  rorx edi, r8d, 0x19
00007d55df7d00fd  xor eax, edi
00007d55df7d00ff  and r9d, r10d
00007d55df7d0102  rorx edi, r10d, 0x16
00007d55df7d0108  xor r11d, edi
00007d55df7d010b  mov [rsp+0x30], r11d
00007d55df7d0110  mov r11d, r11d
00007d55df7d0113  mov [r15+0xD0], r11
00007d55df7d011a  lea r11d, [r14d+ebp*1]
00007d55df7d011f  mov r10d, [rsp+0x20]
00007d55df7d0124  xor r9d, r10d
00007d55df7d0127  lea r14d, [r11d+eax*1]
00007d55df7d012c  mov qword ptr [r15+0x88], 0x04
00007d55df7d0137  mov eax, [rsp+0x30]
00007d55df7d013b  lea r11d, [r9d+eax*1]
00007d55df7d0140  mov eax, [rsp+0x40]
00007d55df7d0144  lea r10d, [r14d+eax*1]
00007d55df7d0149  mov r10d, r10d
00007d55df7d014c  mov [r15+0xB8], r10
00007d55df7d0153  xor eax, eax
00007d55df7d0155  mov r10d, 0x04
00007d55df7d015b  mov r9d, 0x100
00007d55df7d0161  cmp r10, r9
00007d55df7d0164  cmc
00007d55df7d0165  lahf
00007d55df7d0166  seto al
00007d55df7d0169  mov [r15+0x108], eax
00007d55df7d0170  lea eax, [r11d+r14d*1]
00007d55df7d0175  mov eax, eax
00007d55df7d0177  mov [r15+0xA8], rax
00007d55df7d017e  mov r12d, r12d
00007d55df7d0181  mov [r15+0xB0], r12
00007d55df7d0188  mov eax, [rsp+0x10]
00007d55df7d018c  mov eax, eax
00007d55df7d018e  mov [r15+0xC0], rax
00007d55df7d0195  mov r8d, r8d
00007d55df7d0198  mov [r15+0xC8], r8
00007d55df7d019f  mov eax, [r15+0x108]
00007d55df7d01a6  sahf
00007d55df7d01a7  jnz 0x00007D55DF7D01D9
00007d55df7d01a9  cmp dword ptr [r15+0x318], 0x00
00007d55df7d01b1  jz 0x00007D55DF7D04A0
00007d55df7d01b7  nop [rax+rax*1], ax
00007d55df7d01c0  nop [rax+rax*1], eax
00007d55df7d01c8  mov eax, 0x41094C
00007d55df7d01cd  mov [r15+0x100], rax
00007d55df7d01d4  jmp 0x00007D55DF5FE110
00007d55df7d01d9  cmp dword ptr [r15+0x318], 0x00
00007d55df7d01e1  jz 0x00007D55DF7D0270
00007d55df7d01e7  nop [rax+rax*1], ax
00007d55df7d01f0  nop [rax+rax*1], eax
00007d55df7d01f8  mov eax, 0x4108C0
00007d55df7d01fd  mov [r15+0x100], rax
00007d55df7d0204  jmp 0x00007D55DF5FE110
00007d55df7d0209  int3
00007d55df7d020a  call 0x00007D55DF60DAE0
00007d55df7d020f  jmp 0x00007D55DF7CFF78
00007d55df7d0214  call 0x00007D55DF6C0230
00007d55df7d0219  jmp 0x00007D55DF7CFF81
00007d55df7d021e  call 0x00007D55DF6E26A0
00007d55df7d0223  jmp 0x00007D55DF7CFFA5
00007d55df7d0228  call 0x00007D55DF6E1430
00007d55df7d022d  jmp 0x00007D55DF7CFFAE
00007d55df7d0232  call 0x00007D55DF6E26A0
00007d55df7d0237  jmp 0x00007D55DF7CFFCF
00007d55df7d023c  call 0x00007D55DF6E1430
00007d55df7d0241  jmp 0x00007D55DF7CFFD8
00007d55df7d0246  call 0x00007D55DF6E26A0
00007d55df7d024b  jmp 0x00007D55DF7CFFF9
00007d55df7d0250  call 0x00007D55DF6D5890
00007d55df7d0255  jmp 0x00007D55DF7D0002
00007d55df7d025a  call 0x00007D55DF6BDD50
00007d55df7d025f  jmp 0x00007D55DF7D0098
00007d55df7d0264  call 0x00007D55DF6DA580
00007d55df7d0269  jmp 0x00007D55DF7D00CF
00007d55df7d026e  int3
00007d55df7d026f  nop
00007d55df7d0270  mov eax, [r15+0xB8]
00007d55df7d0277  mov [rsp+0x10], eax
00007d55df7d027b  mov eax, eax
00007d55df7d027d  mov [r15+0x30], rax
00007d55df7d0281  mov eax, [r15+0xC0]
00007d55df7d0288  mov [rsp+0x20], eax
00007d55df7d028c  mov eax, eax
00007d55df7d028e  mov [r15+0xA0], rax
00007d55df7d0295  mov eax, [r15+0x28]
00007d55df7d0299  mov r14d, [r15+0x98]
00007d55df7d02a0  mov [rsp+0x30], r14d
00007d55df7d02a5  mov r14d, r14d
00007d55df7d02a8  mov [r15+0x28], r14
00007d55df7d02ac  mov r14d, [r15+0x38]
00007d55df7d02b0  mov [rsp+0x40], r14d
00007d55df7d02b5  mov r14d, r14d
00007d55df7d02b8  mov [r15+0x98], r14
00007d55df7d02bf  mov r14d, [r15+0xA8]
00007d55df7d02c6  mov [rsp+0x50], r14d
00007d55df7d02cb  mov r14d, r14d
00007d55df7d02ce  mov [r15+0x38], r14
00007d55df7d02d2  mov r14d, [rsp+0x10]
00007d55df7d02d7  mov r12d, [rsp+0x10]
00007d55df7d02dc  shrd r14d, r12d, 0x06
00007d55df7d02e1  mov r11d, [r15+0xC8]
00007d55df7d02e8  mov [rsp+0x10], r12d
00007d55df7d02ed  and r12d, r11d
00007d55df7d02f0  mov r10d, [rsp+0x50]
00007d55df7d02f5  mov r9d, [rsp+0x50]
00007d55df7d02fa  shrd r10d, r9d, 0x02
00007d55df7d02ff  mov [rsp+0x50], r11d
00007d55df7d0304  mov r11d, r11d
00007d55df7d0307  mov [r15+0x20], r11
00007d55df7d030b  mov r11, [r15+0x88]
00007d55df7d0312  mov r8, [r15+0x50]
00007d55df7d0316  lea rbp, [r8+r11*1]
00007d55df7d031a  mov r8d, [r13+rbp*1]
00007d55df7d031f  mov ebp, [rsp+0x20]
00007d55df7d0323  mov edi, [rsp+0x10]
00007d55df7d0327  andn esi, edi, ebp
00007d55df7d032c  mov edx, [r15+0xB0]
00007d55df7d0333  lea ecx, [r12d+edx*1]
00007d55df7d0338  rorx r12d, edi, 0x0B
00007d55df7d033e  xor r14d, r12d
00007d55df7d0341  rorx r12d, r9d, 0x0D
00007d55df7d0347  xor r10d, r12d
00007d55df7d034a  lea r12d, [ecx+esi*1]
00007d55df7d034f  mov rsi, [r15+0x48]
00007d55df7d0353  lea rdx, [rsi+r11*1]
00007d55df7d0357  mov esi, [r13+rdx*1]
00007d55df7d035c  mov edx, [rsp+0x30]
00007d55df7d0360  mov ecx, [rsp+0x40]
00007d55df7d0364  and edx, ecx
00007d55df7d0366  mov [rsp+0x10], edx
00007d55df7d036a  mov edx, edx
00007d55df7d036c  mov [r15+0xD8], rdx
00007d55df7d0373  lea edx, [r12d+r8d*1]
00007d55df7d0378  mov r12d, [rsp+0x30]
00007d55df7d037d  xor r12d, ecx
00007d55df7d0380  rorx r8d, edi, 0x19
00007d55df7d0386  xor r14d, r8d
00007d55df7d0389  and r12d, r9d
00007d55df7d038c  rorx r8d, r9d, 0x16
00007d55df7d0392  xor r10d, r8d
00007d55df7d0395  mov [rsp+0x20], r10d
00007d55df7d039a  mov r10d, r10d
00007d55df7d039d  mov [r15+0xD0], r10
00007d55df7d03a4  lea r10d, [edx+esi*1]
00007d55df7d03a9  mov r9d, [rsp+0x10]
00007d55df7d03ae  xor r12d, r9d
00007d55df7d03b1  lea r9d, [r10d+r14d*1]
00007d55df7d03b6  lea r14, [r11+0x04]
00007d55df7d03ba  mov [r15+0x88], r14
00007d55df7d03c1  mov r11d, [rsp+0x20]
00007d55df7d03c6  lea r10d, [r12d+r11d*1]
00007d55df7d03cb  lea r11d, [r9d+eax*1]
00007d55df7d03d0  mov r11d, r11d
00007d55df7d03d3  mov [r15+0xB8], r11
00007d55df7d03da  xor eax, eax
00007d55df7d03dc  mov r12d, 0x100
00007d55df7d03e2  cmp r14, r12
00007d55df7d03e5  cmc
00007d55df7d03e6  lahf
00007d55df7d03e7  seto al
00007d55df7d03ea  mov [r15+0x108], eax
00007d55df7d03f1  lea eax, [r10d+r9d*1]
00007d55df7d03f6  mov eax, eax
00007d55df7d03f8  mov [r15+0xA8], rax
00007d55df7d03ff  mov ebp, ebp
00007d55df7d0401  mov [r15+0xB0], rbp
00007d55df7d0408  mov eax, [rsp+0x50]
00007d55df7d040c  mov eax, eax
00007d55df7d040e  mov [r15+0xC0], rax
00007d55df7d0415  mov edi, edi
00007d55df7d0417  mov [r15+0xC8], rdi
00007d55df7d041e  mov eax, [r15+0x108]
00007d55df7d0425  sahf
00007d55df7d0426  jnz 0x00007D55DF7D0458
00007d55df7d0428  cmp dword ptr [r15+0x318], 0x00
00007d55df7d0430  jz 0x00007D55DF7D04A0
00007d55df7d0436  nop [rax+rax*1], ax
00007d55df7d043f  nop [rax+rax*1], eax
00007d55df7d0447  mov eax, 0x41094C
00007d55df7d044c  mov [r15+0x100], rax
00007d55df7d0453  jmp 0x00007D55DF5FE110
00007d55df7d0458  cmp dword ptr [r15+0x318], 0x00
00007d55df7d0460  jz 0x00007D55DF7D0270
00007d55df7d0466  nop [rax+rax*1], ax
00007d55df7d046f  nop [rax+rax*1], eax
00007d55df7d0477  mov eax, 0x4108C0
00007d55df7d047c  mov [r15+0x100], rax
00007d55df7d0483  jmp 0x00007D55DF5FE110
00007d55df7d0488  int3
00007d55df7d0489  call 0x00007D55DF649010
00007d55df7d048e  jmp 0x00007D55DF7D031F
00007d55df7d0493  call 0x00007D55DF625930
00007d55df7d0498  jmp 0x00007D55DF7D035C
00007d55df7d049d  int3
00007d55df7d049e  nop
00007d55df7d04a0  mov eax, [r15+0x98]
00007d55df7d04a7  mov r14d, [r15+0x70]
00007d55df7d04ab  lea r12d, [eax+r14d*1]
00007d55df7d04b0  mov eax, [r15+0x28]
00007d55df7d04b4  mov r14d, [r15+0x68]
00007d55df7d04b8  lea r11d, [eax+r14d*1]
00007d55df7d04bd  mov qword ptr [r15+0x88], 0x00
00007d55df7d04c8  mov eax, [r15+0xA8]
00007d55df7d04cf  mov r14d, [r15+0x78]
00007d55df7d04d3  lea r10d, [eax+r14d*1]
00007d55df7d04d8  mov [rsp+0x10], r10d
00007d55df7d04dd  mov r10d, r10d
00007d55df7d04e0  mov [r15+0x78], r10
00007d55df7d04e4  mov eax, [r15+0x38]
00007d55df7d04e8  mov r14d, [r15+0x80]
00007d55df7d04ef  lea r10d, [eax+r14d*1]
00007d55df7d04f4  mov [rsp+0x20], r10d
00007d55df7d04f9  mov r10d, r10d
00007d55df7d04fc  mov [r15+0x80], r10
00007d55df7d0503  mov rax, [r15]
00007d55df7d0506  lea r14, [rax+0x08]
00007d55df7d050a  mov [r13+r14*1], r12d
00007d55df7d050f  lea r14, [rax+0x0C]
00007d55df7d0513  mov [r13+r14*1], r11d
00007d55df7d0518  mov r14d, [r15+0xB8]
00007d55df7d051f  mov r12d, [r15+0x18]
00007d55df7d0523  lea r11d, [r14d+r12d*1]
00007d55df7d0528  mov [rsp+0x30], r11d
00007d55df7d052d  mov r11d, r11d
00007d55df7d0530  mov [r15+0x68], r11
00007d55df7d0534  mov r14d, [r15+0x30]
00007d55df7d0538  mov r12d, [r15+0x90]
00007d55df7d053f  lea r11d, [r14d+r12d*1]
00007d55df7d0544  mov [rsp+0x40], r11d
00007d55df7d0549  mov r11d, r11d
00007d55df7d054c  mov [r15+0x70], r11
00007d55df7d0550  mov r14d, [r15+0x20]
00007d55df7d0554  mov r12d, [r15+0x58]
00007d55df7d0558  lea r11d, [r14d+r12d*1]
00007d55df7d055d  mov [rsp+0x50], r11d
00007d55df7d0562  mov r11d, r11d
00007d55df7d0565  mov [r15+0x58], r11
00007d55df7d0569  mov r14d, [r15+0xA0]
00007d55df7d0570  mov r12d, [r15+0x60]
00007d55df7d0574  lea r11d, [r14d+r12d*1]
00007d55df7d0579  mov [rsp+0x60], r11d
00007d55df7d057e  mov r11d, r11d
00007d55df7d0581  mov [r15+0x60], r11
00007d55df7d0585  mov r14d, [rsp+0x10]
00007d55df7d058a  mov [r13+rax*1], r14d
00007d55df7d058f  lea r14, [rax+0x04]
00007d55df7d0593  mov r12d, [rsp+0x20]
00007d55df7d0598  mov [r13+r14*1], r12d
00007d55df7d059d  lea r14, [rax+0x10]
00007d55df7d05a1  mov r12d, [rsp+0x30]
00007d55df7d05a6  mov [r13+r14*1], r12d
00007d55df7d05ab  lea r14, [rax+0x14]
00007d55df7d05af  mov r12d, [rsp+0x40]
00007d55df7d05b4  mov [r13+r14*1], r12d
00007d55df7d05b9  lea r14, [rax+0x18]
00007d55df7d05bd  mov r12d, [rsp+0x50]
00007d55df7d05c2  mov [r13+r14*1], r12d
00007d55df7d05c7  lea r14, [rax+0x1C]
00007d55df7d05cb  mov r12d, [rsp+0x60]
00007d55df7d05d0  mov [r13+r14*1], r12d
00007d55df7d05d5  lea r14, [rax+0x68]
00007d55df7d05d9  xor eax, eax
00007d55df7d05db  mov [r13+r14*1], rax
00007d55df7d05e0  cmp dword ptr [r15+0x318], 0x00
00007d55df7d05e8  jz 0x00007D55DF7CF0E0
00007d55df7d05ee  nop [rax+rax*1], ax
00007d55df7d05f7  nop [rax+rax*1], eax
00007d55df7d05ff  mov eax, 0x410768
00007d55df7d0604  mov [r15+0x100], rax
00007d55df7d060b  jmp 0x00007D55DF5FE110
00007d55df7d0610  int3
00007d55df7d0611  call 0x00007D55DF6E2BA0
00007d55df7d0616  jmp 0x00007D55DF7D050F
00007d55df7d061b  call 0x00007D55DF6E1920
00007d55df7d0620  jmp 0x00007D55DF7D0518
00007d55df7d0625  call 0x00007D55DF60DFE0
00007d55df7d062a  jmp 0x00007D55DF7D058F
00007d55df7d062f  call 0x00007D55DF6E2BA0
00007d55df7d0634  jmp 0x00007D55DF7D059D
00007d55df7d0639  call 0x00007D55DF6E2BA0
00007d55df7d063e  jmp 0x00007D55DF7D05AB
00007d55df7d0643  call 0x00007D55DF6E2BA0
00007d55df7d0648  jmp 0x00007D55DF7D05B9
00007d55df7d064d  call 0x00007D55DF6E2BA0
00007d55df7d0652  jmp 0x00007D55DF7D05C7
00007d55df7d0657  call 0x00007D55DF6E2BA0
00007d55df7d065c  jmp 0x00007D55DF7D05D5
00007d55df7d0661  call 0x00007D55DF6D5EB0
00007d55df7d0666  jmp 0x00007D55DF7D05E0
00007d55df7d066b  int3
00007d55df7d066c  nop [rax], eax
00007d55df7d0670  mov rax, [r15+0xF8]
00007d55df7d0677  lea r14, [rax+0x140]
00007d55df7d067e  mov r12, [r13+r14*1]
00007d55df7d0683  lea r14, [rax+0x148]
00007d55df7d068a  mov r11, [r13+r14*1]
00007d55df7d068f  mov [r15+0xA0], r12
00007d55df7d0696  mov [r15+0x98], r11
00007d55df7d069d  lea r14, [rax+0x130]
00007d55df7d06a4  mov r12, [r13+r14*1]
00007d55df7d06a9  lea r14, [rax+0x138]
00007d55df7d06b0  mov r11, [r13+r14*1]
00007d55df7d06b5  mov [r15+0xB0], r12
00007d55df7d06bc  mov [r15+0xA8], r11
00007d55df7d06c3  lea r14, [rax+0x120]
00007d55df7d06ca  mov r12, [r13+r14*1]
00007d55df7d06cf  lea r14, [rax+0x128]
00007d55df7d06d6  mov r11, [r13+r14*1]
00007d55df7d06db  mov [r15+0xC0], r12
00007d55df7d06e2  mov [r15+0xB8], r11
00007d55df7d06e9  lea r14, [rax+0x110]
00007d55df7d06f0  mov r12, [r13+r14*1]
00007d55df7d06f5  lea r14, [rax+0x118]
00007d55df7d06fc  mov r11, [r13+r14*1]
00007d55df7d0701  mov [r15+0xD0], r12
00007d55df7d0708  mov [r15+0xC8], r11
00007d55df7d070f  lea r14, [rax+0x100]
00007d55df7d0716  mov r12, [r13+r14*1]
00007d55df7d071b  lea r14, [rax+0x108]
00007d55df7d0722  mov r11, [r13+r14*1]
00007d55df7d0727  mov [r15+0xE8], r12
00007d55df7d072e  mov [r15+0xD8], r11
00007d55df7d0735  lea r14, [rax+0x150]
00007d55df7d073c  mov [r15+0xF8], r14
00007d55df7d0743  mov rax, [r15+0xF0]
00007d55df7d074a  mov [r15+0x100], rax
00007d55df7d0751  jmp 0x00007D55DF7CE5C0
00007d55df7d0756  int3
00007d55df7d0757  call 0x00007D55DF6E27E0
00007d55df7d075c  jmp 0x00007D55DF7D0683
00007d55df7d0761  call 0x00007D55DF6E1570
00007d55df7d0766  jmp 0x00007D55DF7D068F
00007d55df7d076b  call 0x00007D55DF6E27E0
00007d55df7d0770  jmp 0x00007D55DF7D06A9
00007d55df7d0775  call 0x00007D55DF6E1570
00007d55df7d077a  jmp 0x00007D55DF7D06B5
00007d55df7d077f  call 0x00007D55DF6E27E0
00007d55df7d0784  jmp 0x00007D55DF7D06CF
00007d55df7d0789  call 0x00007D55DF6E1570
00007d55df7d078e  jmp 0x00007D55DF7D06DB
00007d55df7d0793  call 0x00007D55DF6E27E0
00007d55df7d0798  jmp 0x00007D55DF7D06F5
00007d55df7d079d  call 0x00007D55DF6E1570
00007d55df7d07a2  jmp 0x00007D55DF7D0701
00007d55df7d07a7  call 0x00007D55DF6E27E0
00007d55df7d07ac  jmp 0x00007D55DF7D071B
00007d55df7d07b1  call 0x00007D55DF6E1570
00007d55df7d07b6  jmp 0x00007D55DF7D0727
00007d55df7d07bb  int3
00007d55df7d07bc  nop [rax], eax
00007d55df7d07c0  mov eax, [r15+0xA0]
00007d55df7d07c7  mov [rsp+0x10], eax
00007d55df7d07cb  xor eax, eax
00007d55df7d07cd  mov r14d, [rsp+0x10]
00007d55df7d07d2  sub r14d, 0x01
00007d55df7d07d6  cmc
00007d55df7d07d7  lahf
00007d55df7d07d8  seto al
00007d55df7d07db  mov [r15+0x108], eax
00007d55df7d07e2  mov r14d, r14d
00007d55df7d07e5  mov [r15+0xA0], r14
00007d55df7d07ec  mov eax, [r15+0x108]
00007d55df7d07f3  sahf
00007d55df7d07f4  jnz 0x00007D55DF7D0826
00007d55df7d07f6  cmp dword ptr [r15+0x318], 0x00
00007d55df7d07fe  jz 0x00007D55DF7D0900
00007d55df7d0804  nop [rax+rax*1], ax
00007d55df7d080d  nop [rax+rax*1], eax
00007d55df7d0815  mov eax, 0x41028C
00007d55df7d081a  mov [r15+0x100], rax
00007d55df7d0821  jmp 0x00007D55DF5FE110
00007d55df7d0826  cmp dword ptr [r15+0x318], 0x00
00007d55df7d082e  jz 0x00007D55DF7D0860
00007d55df7d0834  nop [rax+rax*1], ax
00007d55df7d083d  nop [rax+rax*1], eax
00007d55df7d0845  mov eax, 0x410274
00007d55df7d084a  mov [r15+0x100], rax
00007d55df7d0851  jmp 0x00007D55DF5FE110
00007d55df7d0856  int3
00007d55df7d0857  int3
00007d55df7d0858  nop [rax+rax*1], eax
00007d55df7d0860  mov rax, [r15+0xF8]
00007d55df7d0867  lea r14, [rax+0x100]
00007d55df7d086e  mov [r15], r14
00007d55df7d0871  mov rax, [r15+0x98]
00007d55df7d0878  mov [r15+0x08], rax
00007d55df7d087c  mov qword ptr [r15+0x10], 0x12C
00007d55df7d0884  mov qword ptr [r15+0xF0], 0x410284
00007d55df7d088f  mov r14d, [r15+0x320]
00007d55df7d0896  mov eax, 0x410284
00007d55df7d089b  mov rcx, 0x7D55DF7D07C0
00007d55df7d08a5  mov [r15+r14*8+0x328], rax
00007d55df7d08ad  mov [r15+r14*8+0x368], rcx
00007d55df7d08b5  add r14d, 0x01
00007d55df7d08b9  and r14d, 0x07
00007d55df7d08bd  mov [r15+0x320], r14d
00007d55df7d08c4  cmp dword ptr [r15+0x318], 0x00
00007d55df7d08cc  jz 0x00007D55DF7CED70
00007d55df7d08d2  nop [rax+rax*1], ax
00007d55df7d08db  nop [rax+rax*1], eax
00007d55df7d08e3  mov eax, 0x410728
00007d55df7d08e8  mov [r15+0x100], rax
00007d55df7d08ef  jmp 0x00007D55DF5FE110
00007d55df7d08f4  int3
00007d55df7d08f5  int3
00007d55df7d08f6  nop [rax+rax*1], ax
00007d55df7d08ff  nop
00007d55df7d0900  mov rax, [r15+0xF8]
00007d55df7d0907  lea r14, [rax+0x120]
00007d55df7d090e  mov r12, [r13+r14*1]
00007d55df7d0913  mov [r15+0x98], r12
00007d55df7d091a  mov qword ptr [r15+0x40], 0x80
00007d55df7d0922  lea r14, [rax+0x100]
00007d55df7d0929  mov [r15], r14
00007d55df7d092c  lea r14, [rax+0x17C]
00007d55df7d0933  mov [r15+0x08], r14
00007d55df7d0937  mov qword ptr [r15+0x10], 0x01
00007d55df7d093f  lea r14, [rax+0x17C]
00007d55df7d0946  mov eax, 0x80
00007d55df7d094b  mov [r13+r14*1], al
00007d55df7d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007d55df7d095b  mov r14d, [r15+0x320]
00007d55df7d0962  mov eax, 0x4102A8
00007d55df7d0967  mov rcx, 0x7D55DF7D09E0
00007d55df7d0971  mov [r15+r14*8+0x328], rax
00007d55df7d0979  mov [r15+r14*8+0x368], rcx
00007d55df7d0981  add r14d, 0x01
00007d55df7d0985  and r14d, 0x07
00007d55df7d0989  mov [r15+0x320], r14d
00007d55df7d0990  cmp dword ptr [r15+0x318], 0x00
00007d55df7d0998  jz 0x00007D55DF7CED70
00007d55df7d099e  nop [rax+rax*1], ax
00007d55df7d09a7  nop [rax+rax*1], eax
00007d55df7d09af  mov eax, 0x410728
00007d55df7d09b4  mov [r15+0x100], rax
00007d55df7d09bb  jmp 0x00007D55DF5FE110
00007d55df7d09c0  int3
00007d55df7d09c1  call 0x00007D55DF6E27E0
00007d55df7d09c6  jmp 0x00007D55DF7D0913
00007d55df7d09cb  call 0x00007D55DF6D5AF0
00007d55df7d09d0  jmp 0x00007D55DF7D0950
00007d55df7d09d5  int3
00007d55df7d09d6  nop [rax+rax*1], ax
00007d55df7d09df  nop
00007d55df7d09e0  mov rax, [r15+0xF8]
00007d55df7d09e7  lea r14, [rax+0x168]
00007d55df7d09ee  mov r12, [r13+r14*1]
00007d55df7d09f3  mov [r15+0x40], r12
00007d55df7d09f7  lea r14, [rax+0x178]
00007d55df7d09fe  xor eax, eax
00007d55df7d0a00  mov [r13+r14*1], al
00007d55df7d0a05  xor eax, eax
00007d55df7d0a07  mov r14d, 0x38
00007d55df7d0a0d  cmp r12, r14
00007d55df7d0a10  cmc
00007d55df7d0a11  lahf
00007d55df7d0a12  seto al
00007d55df7d0a15  mov [r15+0x108], eax
00007d55df7d0a1c  mov eax, [r15+0x108]
00007d55df7d0a23  sahf
00007d55df7d0a24  jz 0x00007D55DF7D0A56
00007d55df7d0a26  cmp dword ptr [r15+0x318], 0x00
00007d55df7d0a2e  jz 0x00007D55DF7D0AA0
00007d55df7d0a34  nop [rax+rax*1], ax
00007d55df7d0a3d  nop [rax+rax*1], eax
00007d55df7d0a45  mov eax, 0x4102B8
00007d55df7d0a4a  mov [r15+0x100], rax
00007d55df7d0a51  jmp 0x00007D55DF5FE110
00007d55df7d0a56  cmp dword ptr [r15+0x318], 0x00
00007d55df7d0a5e  jz 0x00007D55DF7D0BF0
00007d55df7d0a64  nop [rax+rax*1], ax
00007d55df7d0a6d  nop [rax+rax*1], eax
00007d55df7d0a75  mov eax, 0x4102D4
00007d55df7d0a7a  mov [r15+0x100], rax
00007d55df7d0a81  jmp 0x00007D55DF5FE110
00007d55df7d0a86  int3
00007d55df7d0a87  call 0x00007D55DF6E27E0
00007d55df7d0a8c  jmp 0x00007D55DF7D09F3
00007d55df7d0a91  call 0x00007D55DF6D5AF0
00007d55df7d0a96  jmp 0x00007D55DF7D0A05
00007d55df7d0a9b  int3
00007d55df7d0a9c  nop [rax], eax
00007d55df7d0aa0  mov rax, [r15+0xF8]
00007d55df7d0aa7  lea r14, [rax+0x100]
00007d55df7d0aae  mov [r15], r14
00007d55df7d0ab1  lea r14, [rax+0x178]
00007d55df7d0ab8  mov [r15+0x08], r14
00007d55df7d0abc  mov qword ptr [r15+0x10], 0x01
00007d55df7d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007d55df7d0acf  mov r14d, [r15+0x320]
00007d55df7d0ad6  mov eax, 0x4102C8
00007d55df7d0adb  mov rcx, 0x7D55DF7D0B40
00007d55df7d0ae5  mov [r15+r14*8+0x328], rax
00007d55df7d0aed  mov [r15+r14*8+0x368], rcx
00007d55df7d0af5  add r14d, 0x01
00007d55df7d0af9  and r14d, 0x07
00007d55df7d0afd  mov [r15+0x320], r14d
00007d55df7d0b04  cmp dword ptr [r15+0x318], 0x00
00007d55df7d0b0c  jz 0x00007D55DF7CED70
00007d55df7d0b12  nop [rax+rax*1], ax
00007d55df7d0b1b  nop [rax+rax*1], eax
00007d55df7d0b23  mov eax, 0x410728
00007d55df7d0b28  mov [r15+0x100], rax
00007d55df7d0b2f  jmp 0x00007D55DF5FE110
00007d55df7d0b34  int3
00007d55df7d0b35  int3
00007d55df7d0b36  nop [rax+rax*1], ax
00007d55df7d0b3f  nop
00007d55df7d0b40  mov rax, [r15+0xF8]
00007d55df7d0b47  lea r14, [rax+0x168]
00007d55df7d0b4e  mov rax, [r13+r14*1]
00007d55df7d0b53  mov [r15+0x40], rax
00007d55df7d0b57  mov [rsp+0x10], rax
00007d55df7d0b5c  xor eax, eax
00007d55df7d0b5e  mov r14, [rsp+0x10]
00007d55df7d0b63  mov r12d, 0x38
00007d55df7d0b69  cmp r14, r12
00007d55df7d0b6c  cmc
00007d55df7d0b6d  lahf
00007d55df7d0b6e  seto al
00007d55df7d0b71  mov [r15+0x108], eax
00007d55df7d0b78  mov eax, [r15+0x108]
00007d55df7d0b7f  sahf
00007d55df7d0b80  jnz 0x00007D55DF7D0BB2
00007d55df7d0b82  cmp dword ptr [r15+0x318], 0x00
00007d55df7d0b8a  jz 0x00007D55DF7D0BF0
00007d55df7d0b90  nop [rax+rax*1], ax
00007d55df7d0b99  nop [rax+rax*1], eax
00007d55df7d0ba1  mov eax, 0x4102D4
00007d55df7d0ba6  mov [r15+0x100], rax
00007d55df7d0bad  jmp 0x00007D55DF5FE110
00007d55df7d0bb2  cmp dword ptr [r15+0x318], 0x00
00007d55df7d0bba  jz 0x00007D55DF7D0AA0
00007d55df7d0bc0  nop [rax+rax*1], ax
00007d55df7d0bc9  nop [rax+rax*1], eax
00007d55df7d0bd1  mov eax, 0x4102B8
00007d55df7d0bd6  mov [r15+0x100], rax
00007d55df7d0bdd  jmp 0x00007D55DF5FE110
00007d55df7d0be2  int3
00007d55df7d0be3  call 0x00007D55DF6D59C0
00007d55df7d0be8  jmp 0x00007D55DF7D0B53
00007d55df7d0bed  int3
00007d55df7d0bee  nop
00007d55df7d0bf0  mov rax, [r15+0x98]
00007d55df7d0bf7  rorx r14, rax, 0x3D
00007d55df7d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007d55df7d0c01  mov rax, [r15+0xF8]
00007d55df7d0c08  lea r12, [rax+0x100]
00007d55df7d0c0f  mov [r15], r12
00007d55df7d0c12  lea r12, [rax+0x170]
00007d55df7d0c19  mov [r15+0x08], r12
00007d55df7d0c1d  mov qword ptr [r15+0x10], 0x08
00007d55df7d0c25  bswap r14
00007d55df7d0c28  mov [r15+0x40], r14
00007d55df7d0c2c  lea r12, [rax+0x170]
00007d55df7d0c33  mov [r13+r12*1], r14
00007d55df7d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007d55df7d0c43  mov r14d, [r15+0x320]
00007d55df7d0c4a  mov eax, 0x4102F0
00007d55df7d0c4f  mov rcx, 0x7D55DF7D0CC0
00007d55df7d0c59  mov [r15+r14*8+0x328], rax
00007d55df7d0c61  mov [r15+r14*8+0x368], rcx
00007d55df7d0c69  add r14d, 0x01
00007d55df7d0c6d  and r14d, 0x07
00007d55df7d0c71  mov [r15+0x320], r14d
00007d55df7d0c78  cmp dword ptr [r15+0x318], 0x00
00007d55df7d0c80  jz 0x00007D55DF7CED70
00007d55df7d0c86  nop [rax+rax*1], ax
00007d55df7d0c8f  nop [rax+rax*1], eax
00007d55df7d0c97  mov eax, 0x410728
00007d55df7d0c9c  mov [r15+0x100], rax
00007d55df7d0ca3  jmp 0x00007D55DF5FE110
00007d55df7d0ca8  int3
00007d55df7d0ca9  call 0x00007D55DF6C3FE0
00007d55df7d0cae  jmp 0x00007D55DF7D0C38
00007d55df7d0cb3  int3
00007d55df7d0cb4  nop [rax+rax*1], ax
00007d55df7d0cbd  nop [rax], eax
00007d55df7d0cc0  mov rax, [r15+0xF8]
00007d55df7d0cc7  lea r14, [rax+0x100]
00007d55df7d0cce  mov r12d, [r13+r14*1]
00007d55df7d0cd3  lea r14, [rax+0x104]
00007d55df7d0cda  mov r11d, [r13+r14*1]
00007d55df7d0cdf  mov qword ptr [r15+0x48], 0x430C90
00007d55df7d0ce7  lea r14, [rax+0x108]
00007d55df7d0cee  mov r10d, [r13+r14*1]
00007d55df7d0cf3  lea r14, [rax+0x10C]
00007d55df7d0cfa  mov r9d, [r13+r14*1]
00007d55df7d0cff  bswap r12d
00007d55df7d0d02  bswap r11d
00007d55df7d0d05  mov qword ptr [r15+0xA0], 0x00
00007d55df7d0d10  mov r14d, 0x430C90
00007d55df7d0d16  mov [r13+r14*1], r12d
00007d55df7d0d1b  mov r14d, 0x430C94
00007d55df7d0d21  mov [r13+r14*1], r11d
00007d55df7d0d26  bswap r10d
00007d55df7d0d29  lea r14, [rax+0x110]
00007d55df7d0d30  mov r12d, [r13+r14*1]
00007d55df7d0d35  bswap r9d
00007d55df7d0d38  lea r14, [rax+0x114]
00007d55df7d0d3f  mov r11d, [r13+r14*1]
00007d55df7d0d44  mov qword ptr [r15+0x98], 0x430DFC
00007d55df7d0d4f  mov r14d, 0x430C98
00007d55df7d0d55  mov [r13+r14*1], r10d
00007d55df7d0d5a  mov r14d, 0x430C9C
00007d55df7d0d60  mov [r13+r14*1], r9d
00007d55df7d0d65  bswap r12d
00007d55df7d0d68  lea r14, [rax+0x118]
00007d55df7d0d6f  mov r10d, [r13+r14*1]
00007d55df7d0d74  bswap r11d
00007d55df7d0d77  mov [rsp+0x10], r11d
00007d55df7d0d7c  mov r11d, r11d
00007d55df7d0d7f  mov [r15+0x58], r11
00007d55df7d0d83  lea r14, [rax+0x11C]
00007d55df7d0d8a  mov eax, [r13+r14*1]
00007d55df7d0d8f  mov [rsp+0x20], eax
00007d55df7d0d93  mov eax, eax
00007d55df7d0d95  mov [r15+0x60], rax
00007d55df7d0d99  mov eax, 0x430CA0
00007d55df7d0d9e  mov [r13+rax*1], r12d
00007d55df7d0da3  mov eax, 0x430CA4
00007d55df7d0da8  mov r14d, [rsp+0x10]
00007d55df7d0dad  mov [r13+rax*1], r14d
00007d55df7d0db2  bswap r10d
00007d55df7d0db5  mov [rsp+0x10], r10d
00007d55df7d0dba  mov r10d, r10d
00007d55df7d0dbd  mov [r15+0x40], r10
00007d55df7d0dc1  mov eax, [rsp+0x20]
00007d55df7d0dc5  bswap eax
00007d55df7d0dc7  mov [rsp+0x20], eax
00007d55df7d0dcb  mov eax, eax
00007d55df7d0dcd  mov [r15+0x50], rax
00007d55df7d0dd1  mov eax, 0x430CA8
00007d55df7d0dd6  mov r14d, [rsp+0x10]
00007d55df7d0ddb  mov [r13+rax*1], r14d
00007d55df7d0de0  mov eax, 0x430CAC
00007d55df7d0de5  mov r14d, [rsp+0x20]
00007d55df7d0dea  mov [r13+rax*1], r14d
00007d55df7d0def  mov eax, [r15+0xA0]
00007d55df7d0df6  lea r14d, [eax+0x11]
00007d55df7d0dfb  mov r14d, r14d
00007d55df7d0dfe  mov [r15], r14
00007d55df7d0e01  mov qword ptr [r15+0xF0], 0x41035C
00007d55df7d0e0c  mov r14d, [r15+0x320]
00007d55df7d0e13  mov eax, 0x41035C
00007d55df7d0e18  mov rcx, 0x7D55DF7D0F90
00007d55df7d0e22  mov [r15+r14*8+0x328], rax
00007d55df7d0e2a  mov [r15+r14*8+0x368], rcx
00007d55df7d0e32  add r14d, 0x01
00007d55df7d0e36  and r14d, 0x07
00007d55df7d0e3a  mov [r15+0x320], r14d
00007d55df7d0e41  cmp dword ptr [r15+0x318], 0x00
00007d55df7d0e49  jz 0x00007D55DF7D0F20
00007d55df7d0e4f  nop [rax+rax*1], ax
00007d55df7d0e58  nop [rax+rax*1], eax
00007d55df7d0e60  mov eax, 0x4109A4
00007d55df7d0e65  mov [r15+0x100], rax
00007d55df7d0e6c  jmp 0x00007D55DF5FE110
00007d55df7d0e71  int3
00007d55df7d0e72  call 0x00007D55DF6E26A0
00007d55df7d0e77  jmp 0x00007D55DF7D0CD3
00007d55df7d0e7c  call 0x00007D55DF6E1430
00007d55df7d0e81  jmp 0x00007D55DF7D0CDF
00007d55df7d0e86  call 0x00007D55DF6E01C0
00007d55df7d0e8b  jmp 0x00007D55DF7D0CF3
00007d55df7d0e90  call 0x00007D55DF6DEF50
00007d55df7d0e95  jmp 0x00007D55DF7D0CFF
00007d55df7d0e9a  call 0x00007D55DF6E2BA0
00007d55df7d0e9f  jmp 0x00007D55DF7D0D1B
00007d55df7d0ea4  call 0x00007D55DF6E1920
00007d55df7d0ea9  jmp 0x00007D55DF7D0D26
00007d55df7d0eae  call 0x00007D55DF6E26A0
00007d55df7d0eb3  jmp 0x00007D55DF7D0D35
00007d55df7d0eb8  call 0x00007D55DF6E1430
00007d55df7d0ebd  jmp 0x00007D55DF7D0D44
00007d55df7d0ec2  call 0x00007D55DF6E06B0
00007d55df7d0ec7  jmp 0x00007D55DF7D0D5A
00007d55df7d0ecc  call 0x00007D55DF6DF440
00007d55df7d0ed1  jmp 0x00007D55DF7D0D65
00007d55df7d0ed6  call 0x00007D55DF6E01C0
00007d55df7d0edb  jmp 0x00007D55DF7D0D74
00007d55df7d0ee0  call 0x00007D55DF6D5890
00007d55df7d0ee5  jmp 0x00007D55DF7D0D8F
00007d55df7d0eea  call 0x00007D55DF60BAE0
00007d55df7d0eef  jmp 0x00007D55DF7D0DA3
00007d55df7d0ef4  call 0x00007D55DF60DFE0
00007d55df7d0ef9  jmp 0x00007D55DF7D0DB2
00007d55df7d0efe  call 0x00007D55DF60DFE0
00007d55df7d0f03  jmp 0x00007D55DF7D0DE0
00007d55df7d0f08  call 0x00007D55DF60DFE0
00007d55df7d0f0d  jmp 0x00007D55DF7D0DEF
00007d55df7d0f12  int3
00007d55df7d0f13  nop [rax+rax*1], ax
00007d55df7d0f1c  nop [rax], eax
00007d55df7d0f20  mov eax, [r15]
00007d55df7d0f23  mov [rsp+0x10], eax
00007d55df7d0f27  shr eax, 0x10
00007d55df7d0f2a  mov r14d, [rsp+0x10]
00007d55df7d0f2f  xor r14d, eax
00007d55df7d0f32  imul r14d, r14d, 0x7FEB352D
00007d55df7d0f39  mov eax, 0x846CA68B
00007d55df7d0f3e  mov eax, eax
00007d55df7d0f40  mov [r15+0x48], rax
00007d55df7d0f44  mov [rsp+0x10], r14d
00007d55df7d0f49  shr r14d, 0x0F
00007d55df7d0f4d  mov eax, [rsp+0x10]
00007d55df7d0f51  xor eax, r14d
00007d55df7d0f54  imul eax, eax, 0x846CA68B
00007d55df7d0f5a  mov [rsp+0x10], eax
00007d55df7d0f5e  mov eax, eax
00007d55df7d0f60  mov [r15+0x40], rax
00007d55df7d0f64  mov eax, [rsp+0x10]
00007d55df7d0f68  shr eax, 0x10
00007d55df7d0f6b  mov r14d, [rsp+0x10]
00007d55df7d0f70  xor r14d, eax
00007d55df7d0f73  mov r14d, r14d
00007d55df7d0f76  mov [r15], r14
00007d55df7d0f79  mov rax, [r15+0xF0]
00007d55df7d0f80  mov [r15+0x100], rax
00007d55df7d0f87  jmp 0x00007D55DF7CE5C0
00007d55df7d0f8c  int3
00007d55df7d0f8d  int3
00007d55df7d0f8e  nop
00007d55df7d0f90  mov rax, [r15+0xA0]
00007d55df7d0f97  mov [rsp+0x10], rax
00007d55df7d0f9c  shl rax, 0x02
00007d55df7d0fa0  mov r14, [r15+0x98]
00007d55df7d0fa7  lea r12, [r14+rax*1]
00007d55df7d0fab  mov eax, [r15]
00007d55df7d0fae  mov [r13+r12*1], eax
00007d55df7d0fb3  mov rax, [rsp+0x10]
00007d55df7d0fb8  lea r14, [rax+0x01]
00007d55df7d0fbc  mov [r15+0xA0], r14
00007d55df7d0fc3  xor eax, eax
00007d55df7d0fc5  mov r12d, 0x400
00007d55df7d0fcb  cmp r14, r12
00007d55df7d0fce  cmc
00007d55df7d0fcf  lahf
00007d55df7d0fd0  seto al
00007d55df7d0fd3  mov [r15+0x108], eax
00007d55df7d0fda  mov eax, [r15+0x108]
00007d55df7d0fe1  sahf
00007d55df7d0fe2  jnz 0x00007D55DF7D1014
00007d55df7d0fe4  cmp dword ptr [r15+0x318], 0x00
00007d55df7d0fec  jz 0x00007D55DF7D10E0
00007d55df7d0ff2  nop [rax+rax*1], ax
00007d55df7d0ffb  nop [rax+rax*1], eax
00007d55df7d1003  mov eax, 0x41036C
00007d55df7d1008  mov [r15+0x100], rax
00007d55df7d100f  jmp 0x00007D55DF5FE110
00007d55df7d1014  cmp dword ptr [r15+0x318], 0x00
00007d55df7d101c  jz 0x00007D55DF7D1050
00007d55df7d1022  nop [rax+rax*1], ax
00007d55df7d102b  nop [rax+rax*1], eax
00007d55df7d1033  mov eax, 0x410354
00007d55df7d1038  mov [r15+0x100], rax
00007d55df7d103f  jmp 0x00007D55DF5FE110
00007d55df7d1044  int3
00007d55df7d1045  call 0x00007D55DF6B4B70
00007d55df7d104a  jmp 0x00007D55DF7D0FB3
00007d55df7d104f  int3
00007d55df7d1050  mov eax, [r15+0xA0]
00007d55df7d1057  lea r14d, [eax+0x11]
00007d55df7d105c  mov r14d, r14d
00007d55df7d105f  mov [r15], r14
00007d55df7d1062  mov qword ptr [r15+0xF0], 0x41035C
00007d55df7d106d  mov r14d, [r15+0x320]
00007d55df7d1074  mov eax, 0x41035C
00007d55df7d1079  mov rcx, 0x7D55DF7D0F90
00007d55df7d1083  mov [r15+r14*8+0x328], rax
00007d55df7d108b  mov [r15+r14*8+0x368], rcx
00007d55df7d1093  add r14d, 0x01
00007d55df7d1097  and r14d, 0x07
00007d55df7d109b  mov [r15+0x320], r14d
00007d55df7d10a2  cmp dword ptr [r15+0x318], 0x00
00007d55df7d10aa  jz 0x00007D55DF7D0F20
00007d55df7d10b0  nop [rax+rax*1], ax
00007d55df7d10b9  nop [rax+rax*1], eax
00007d55df7d10c1  mov eax, 0x4109A4
00007d55df7d10c6  mov [r15+0x100], rax
00007d55df7d10cd  jmp 0x00007D55DF5FE110
00007d55df7d10d2  int3
00007d55df7d10d3  int3
00007d55df7d10d4  nop [rax+rax*1], ax
00007d55df7d10dd  nop [rax], eax
00007d55df7d10e0  mov qword ptr [r15+0x40], 0x01
00007d55df7d10e8  cmp dword ptr [r15+0x318], 0x00
00007d55df7d10f0  jz 0x00007D55DF7D1120
00007d55df7d10f6  nop [rax+rax*1], ax
00007d55df7d10ff  nop [rax+rax*1], eax
00007d55df7d1107  mov eax, 0x410388
00007d55df7d110c  mov [r15+0x100], rax
00007d55df7d1113  jmp 0x00007D55DF5FE110
00007d55df7d1118  int3
00007d55df7d1119  int3
00007d55df7d111a  nop [rax+rax*1], ax
00007d55df7d1120  mov rax, [r15+0x40]
00007d55df7d1124  mov [rsp+0x10], rax
00007d55df7d1129  shl rax, 0x02
00007d55df7d112d  mov r14, [r15+0x98]
00007d55df7d1134  lea r12, [r14+rax*1]
00007d55df7d1138  mov eax, [r13+r12*1]
00007d55df7d113d  mov [rsp+0x20], eax
00007d55df7d1141  mov eax, eax
00007d55df7d1143  mov [r15+0x48], rax
00007d55df7d1147  mov rax, [rsp+0x10]
00007d55df7d114c  mov [r15+0x50], rax
00007d55df7d1150  mov eax, [r15+0x50]
00007d55df7d1154  lea r12d, [eax-0x01]
00007d55df7d1159  mov r12d, r12d
00007d55df7d115c  mov [r15+0x58], r12
00007d55df7d1160  mov rax, [r15+0x58]
00007d55df7d1164  mov r12d, eax
00007d55df7d1167  mov r12d, r12d
00007d55df7d116a  shl r12, 0x02
00007d55df7d116e  lea rax, [r14+r12*1]
00007d55df7d1172  mov r14d, [r13+rax*1]
00007d55df7d1177  mov [rsp+0x10], r14d
00007d55df7d117c  mov r14d, r14d
00007d55df7d117f  mov [r15+0x60], r14
00007d55df7d1183  xor eax, eax
00007d55df7d1185  mov r14d, [rsp+0x10]
00007d55df7d118a  mov r12d, [rsp+0x20]
00007d55df7d118f  cmp r14d, r12d
00007d55df7d1192  cmc
00007d55df7d1193  lahf
00007d55df7d1194  seto al
00007d55df7d1197  mov [r15+0x108], eax
00007d55df7d119e  mov eax, [r15+0x108]
00007d55df7d11a5  sahf
00007d55df7d11a6  cmc
00007d55df7d11a7  jbe 0x00007D55DF7D11D9
00007d55df7d11a9  cmp dword ptr [r15+0x318], 0x00
00007d55df7d11b1  jz 0x00007D55DF7D1220
00007d55df7d11b7  nop [rax+rax*1], ax
00007d55df7d11c0  nop [rax+rax*1], eax
00007d55df7d11c8  mov eax, 0x4103A0
00007d55df7d11cd  mov [r15+0x100], rax
00007d55df7d11d4  jmp 0x00007D55DF5FE110
00007d55df7d11d9  cmp dword ptr [r15+0x318], 0x00
00007d55df7d11e1  jz 0x00007D55DF7D14C0
00007d55df7d11e7  nop [rax+rax*1], ax
00007d55df7d11f0  nop [rax+rax*1], eax
00007d55df7d11f8  mov eax, 0x410378
00007d55df7d11fd  mov [r15+0x100], rax
00007d55df7d1204  jmp 0x00007D55DF5FE110
00007d55df7d1209  int3
00007d55df7d120a  call 0x00007D55DF6B4690
00007d55df7d120f  jmp 0x00007D55DF7D113D
00007d55df7d1214  call 0x00007D55DF60DAE0
00007d55df7d1219  jmp 0x00007D55DF7D1177
00007d55df7d121e  int3
00007d55df7d121f  nop
00007d55df7d1220  mov rax, [r15+0x50]
00007d55df7d1224  mov [rsp+0x10], rax
00007d55df7d1229  shl rax, 0x02
00007d55df7d122d  mov r14, [r15+0x98]
00007d55df7d1234  lea r12, [r14+rax*1]
00007d55df7d1238  mov eax, [r15+0x60]
00007d55df7d123c  mov [r13+r12*1], eax
00007d55df7d1241  mov rax, [rsp+0x10]
00007d55df7d1246  lea r14, [rax-0x01]
00007d55df7d124a  mov [r15+0x50], r14
00007d55df7d124e  mov rax, [r15+0x58]
00007d55df7d1252  test rax, rax
00007d55df7d1255  setz al
00007d55df7d1258  movzx rax, al
00007d55df7d125c  mov [rsp+0x414], al
00007d55df7d1263  cmp byte ptr [rsp+0x414], 0x00
00007d55df7d126b  jz 0x00007D55DF7D129D
00007d55df7d126d  cmp dword ptr [r15+0x318], 0x00
00007d55df7d1275  jz 0x00007D55DF7D12E0
00007d55df7d127b  nop [rax+rax*1], ax
00007d55df7d1284  nop [rax+rax*1], eax
00007d55df7d128c  mov eax, 0x4103AC
00007d55df7d1291  mov [r15+0x100], rax
00007d55df7d1298  jmp 0x00007D55DF5FE110
00007d55df7d129d  cmp dword ptr [r15+0x318], 0x00
00007d55df7d12a5  jz 0x00007D55DF7D13E0
00007d55df7d12ab  nop [rax+rax*1], ax
00007d55df7d12b4  nop [rax+rax*1], eax
00007d55df7d12bc  mov eax, 0x410390
00007d55df7d12c1  mov [r15+0x100], rax
00007d55df7d12c8  jmp 0x00007D55DF5FE110
00007d55df7d12cd  int3
00007d55df7d12ce  call 0x00007D55DF6B4B70
00007d55df7d12d3  jmp 0x00007D55DF7D1241
00007d55df7d12d8  int3
00007d55df7d12d9  nop [rax], eax
00007d55df7d12e0  cmp dword ptr [r15+0x318], 0x00
00007d55df7d12e8  jz 0x00007D55DF7D1320
00007d55df7d12ee  nop [rax+rax*1], ax
00007d55df7d12f7  nop [rax+rax*1], eax
00007d55df7d12ff  mov eax, 0x410374
00007d55df7d1304  mov [r15+0x100], rax
00007d55df7d130b  jmp 0x00007D55DF5FE110
00007d55df7d1310  int3
00007d55df7d1311  int3
00007d55df7d1312  nop [rax+rax*1], ax
00007d55df7d131b  nop [rax+rax*1], eax
00007d55df7d1320  mov qword ptr [r15+0x50], 0x00
00007d55df7d1328  mov rax, [r15+0x40]
00007d55df7d132c  lea r14, [rax+0x01]
00007d55df7d1330  mov [r15+0x40], r14
00007d55df7d1334  mov rax, [r15+0x98]
00007d55df7d133b  mov r12d, [r15+0x48]
00007d55df7d133f  mov [r13+rax*1], r12d
00007d55df7d1344  xor eax, eax
00007d55df7d1346  mov r12d, 0x400
00007d55df7d134c  cmp r14, r12
00007d55df7d134f  cmc
00007d55df7d1350  lahf
00007d55df7d1351  seto al
00007d55df7d1354  mov [r15+0x108], eax
00007d55df7d135b  mov eax, [r15+0x108]
00007d55df7d1362  sahf
00007d55df7d1363  jz 0x00007D55DF7D1395
00007d55df7d1365  cmp dword ptr [r15+0x318], 0x00
00007d55df7d136d  jz 0x00007D55DF7D1120
00007d55df7d1373  nop [rax+rax*1], ax
00007d55df7d137c  nop [rax+rax*1], eax
00007d55df7d1384  mov eax, 0x410388
00007d55df7d1389  mov [r15+0x100], rax
00007d55df7d1390  jmp 0x00007D55DF5FE110
00007d55df7d1395  cmp dword ptr [r15+0x318], 0x00
00007d55df7d139d  jz 0x00007D55DF7D1580
00007d55df7d13a3  nop [rax+rax*1], ax
00007d55df7d13ac  nop [rax+rax*1], eax
00007d55df7d13b4  mov eax, 0x4103B0
00007d55df7d13b9  mov [r15+0x100], rax
00007d55df7d13c0  jmp 0x00007D55DF5FE110
00007d55df7d13c5  int3
00007d55df7d13c6  call 0x00007D55DF60BAE0
00007d55df7d13cb  jmp 0x00007D55DF7D1344
00007d55df7d13d0  int3
00007d55df7d13d1  nop [rax+rax*1], ax
00007d55df7d13da  nop [rax+rax*1], ax
00007d55df7d13e0  mov eax, [r15+0x50]
00007d55df7d13e4  lea r14d, [eax-0x01]
00007d55df7d13e9  mov r14d, r14d
00007d55df7d13ec  mov [r15+0x58], r14
00007d55df7d13f0  mov rax, [r15+0x58]
00007d55df7d13f4  mov r14d, eax
00007d55df7d13f7  mov r14d, r14d
00007d55df7d13fa  shl r14, 0x02
00007d55df7d13fe  mov rax, [r15+0x98]
00007d55df7d1405  lea r12, [rax+r14*1]
00007d55df7d1409  mov eax, [r13+r12*1]
00007d55df7d140e  mov [rsp+0x10], eax
00007d55df7d1412  mov eax, eax
00007d55df7d1414  mov [r15+0x60], rax
00007d55df7d1418  mov eax, [r15+0x48]
00007d55df7d141c  mov [rsp+0x20], eax
00007d55df7d1420  xor eax, eax
00007d55df7d1422  mov r14d, [rsp+0x10]
00007d55df7d1427  mov r12d, [rsp+0x20]
00007d55df7d142c  cmp r14d, r12d
00007d55df7d142f  cmc
00007d55df7d1430  lahf
00007d55df7d1431  seto al
00007d55df7d1434  mov [r15+0x108], eax
00007d55df7d143b  mov eax, [r15+0x108]
00007d55df7d1442  sahf
00007d55df7d1443  cmc
00007d55df7d1444  jbe 0x00007D55DF7D1476
00007d55df7d1446  cmp dword ptr [r15+0x318], 0x00
00007d55df7d144e  jz 0x00007D55DF7D1220
00007d55df7d1454  nop [rax+rax*1], ax
00007d55df7d145d  nop [rax+rax*1], eax
00007d55df7d1465  mov eax, 0x4103A0
00007d55df7d146a  mov [r15+0x100], rax
00007d55df7d1471  jmp 0x00007D55DF5FE110
00007d55df7d1476  cmp dword ptr [r15+0x318], 0x00
00007d55df7d147e  jz 0x00007D55DF7D14C0
00007d55df7d1484  nop [rax+rax*1], ax
00007d55df7d148d  nop [rax+rax*1], eax
00007d55df7d1495  mov eax, 0x410378
00007d55df7d149a  mov [r15+0x100], rax
00007d55df7d14a1  jmp 0x00007D55DF5FE110
00007d55df7d14a6  int3
00007d55df7d14a7  call 0x00007D55DF6B4690
00007d55df7d14ac  jmp 0x00007D55DF7D140E
00007d55df7d14b1  int3
00007d55df7d14b2  nop [rax+rax*1], ax
00007d55df7d14bb  nop [rax+rax*1], eax
00007d55df7d14c0  mov rax, [r15+0x40]
00007d55df7d14c4  lea r14, [rax+0x01]
00007d55df7d14c8  mov [r15+0x40], r14
00007d55df7d14cc  mov rax, [r15+0x50]
00007d55df7d14d0  mov r12d, eax
00007d55df7d14d3  mov r12d, r12d
00007d55df7d14d6  shl r12, 0x02
00007d55df7d14da  mov rax, [r15+0x98]
00007d55df7d14e1  lea r11, [rax+r12*1]
00007d55df7d14e5  mov eax, [r15+0x48]
00007d55df7d14e9  mov [r13+r11*1], eax
00007d55df7d14ee  xor eax, eax
00007d55df7d14f0  mov r12d, 0x400
00007d55df7d14f6  cmp r14, r12
00007d55df7d14f9  cmc
00007d55df7d14fa  lahf
00007d55df7d14fb  seto al
00007d55df7d14fe  mov [r15+0x108], eax
00007d55df7d1505  mov eax, [r15+0x108]
00007d55df7d150c  sahf
00007d55df7d150d  jz 0x00007D55DF7D153F
00007d55df7d150f  cmp dword ptr [r15+0x318], 0x00
00007d55df7d1517  jz 0x00007D55DF7D1120
00007d55df7d151d  nop [rax+rax*1], ax
00007d55df7d1526  nop [rax+rax*1], eax
00007d55df7d152e  mov eax, 0x410388
00007d55df7d1533  mov [r15+0x100], rax
00007d55df7d153a  jmp 0x00007D55DF5FE110
00007d55df7d153f  cmp dword ptr [r15+0x318], 0x00
00007d55df7d1547  jz 0x00007D55DF7D1580
00007d55df7d154d  nop [rax+rax*1], ax
00007d55df7d1556  nop [rax+rax*1], eax
00007d55df7d155e  mov eax, 0x4103B0
00007d55df7d1563  mov [r15+0x100], rax
00007d55df7d156a  jmp 0x00007D55DF5FE110
00007d55df7d156f  int3
00007d55df7d1570  call 0x00007D55DF6A4270
00007d55df7d1575  jmp 0x00007D55DF7D14EE
00007d55df7d157a  int3
00007d55df7d157b  nop [rax+rax*1], eax
00007d55df7d1580  mov qword ptr [r15+0x40], 0x430000
00007d55df7d1588  mov eax, 0x430CB0
00007d55df7d158d  mov r14, [r13+rax*1]
00007d55df7d1592  mov rax, [r15+0x98]
00007d55df7d1599  mov r12d, [r13+rax*1]
00007d55df7d159e  lea r11, [rax+0x04]
00007d55df7d15a2  mov eax, [r13+r11*1]
00007d55df7d15a7  mov r12d, r12d
00007d55df7d15aa  mov [r15+0x68], r12
00007d55df7d15ae  mov eax, eax
00007d55df7d15b0  mov [r15+0x60], rax
00007d55df7d15b4  mov rax, [r15+0x68]
00007d55df7d15b8  mov [r15+0x68], rax
00007d55df7d15bc  mov qword ptr [r15+0x58], 0x02
00007d55df7d15c4  mov [rsp+0x10], rax
00007d55df7d15c9  xor eax, eax
00007d55df7d15cb  mov r12d, 0x02
00007d55df7d15d1  mov r11d, 0x400
00007d55df7d15d7  cmp r12, r11
00007d55df7d15da  cmc
00007d55df7d15db  lahf
00007d55df7d15dc  seto al
00007d55df7d15df  mov [r15+0x108], eax
00007d55df7d15e6  mov rax, [r15+0x60]
00007d55df7d15ea  mov r12d, 0x02
00007d55df7d15f0  imul rax, r12
00007d55df7d15f4  mov [r15+0x50], rax
00007d55df7d15f8  mov rax, [rsp+0x10]
00007d55df7d15fd  lea r12, [rax+r14*1]
00007d55df7d1601  mov [r15+0x48], r12
00007d55df7d1605  mov eax, [r15+0x108]
00007d55df7d160c  sahf
00007d55df7d160d  jnz 0x00007D55DF7D163F
00007d55df7d160f  cmp dword ptr [r15+0x318], 0x00
00007d55df7d1617  jz 0x00007D55DF7D17B0
00007d55df7d161d  nop [rax+rax*1], ax
00007d55df7d1626  nop [rax+rax*1], eax
00007d55df7d162e  mov eax, 0x4103E0
00007d55df7d1633  mov [r15+0x100], rax
00007d55df7d163a  jmp 0x00007D55DF5FE110
00007d55df7d163f  cmp dword ptr [r15+0x318], 0x00
00007d55df7d1647  jz 0x00007D55DF7D1690
00007d55df7d164d  nop [rax+rax*1], ax
00007d55df7d1656  nop [rax+rax*1], eax
00007d55df7d165e  mov eax, 0x4103C0
00007d55df7d1663  mov [r15+0x100], rax
00007d55df7d166a  jmp 0x00007D55DF5FE110
00007d55df7d166f  int3
00007d55df7d1670  call 0x00007D55DF60DC20
00007d55df7d1675  jmp 0x00007D55DF7D1592
00007d55df7d167a  call 0x00007D55DF60B5E0
00007d55df7d167f  jmp 0x00007D55DF7D159E
00007d55df7d1684  call 0x00007D55DF6A3D90
00007d55df7d1689  jmp 0x00007D55DF7D15A7
00007d55df7d168e  int3
00007d55df7d168f  nop
00007d55df7d1690  mov rax, [r15+0x98]
00007d55df7d1697  mov r14, [r15+0x58]
00007d55df7d169b  mov [rsp+0x10], r14
00007d55df7d16a0  shl r14, 0x02
00007d55df7d16a4  lea r12, [rax+r14*1]
00007d55df7d16a8  mov eax, [r13+r12*1]
00007d55df7d16ad  lea r14, [r12+0x04]
00007d55df7d16b2  mov r12d, [r13+r14*1]
00007d55df7d16b7  mov eax, eax
00007d55df7d16b9  mov [r15+0x68], rax
00007d55df7d16bd  mov r12d, r12d
00007d55df7d16c0  mov [r15+0x60], r12
00007d55df7d16c4  mov rax, [r15+0x68]
00007d55df7d16c8  mov [rsp+0x20], rax
00007d55df7d16cd  mov r14, [rsp+0x10]
00007d55df7d16d2  imul rax, r14
00007d55df7d16d6  mov r12, [rsp+0x20]
00007d55df7d16db  lea r11, [r12+rax*1]
00007d55df7d16df  mov [r15+0x68], r11
00007d55df7d16e3  lea rax, [r14+0x02]
00007d55df7d16e7  mov [r15+0x58], rax
00007d55df7d16eb  mov [rsp+0x10], rax
00007d55df7d16f0  xor eax, eax
00007d55df7d16f2  mov r14, [rsp+0x10]
00007d55df7d16f7  mov r12d, 0x400
00007d55df7d16fd  cmp r14, r12
00007d55df7d1700  cmc
00007d55df7d1701  lahf
00007d55df7d1702  seto al
00007d55df7d1705  mov [r15+0x108], eax
00007d55df7d170c  mov rax, [r15+0x50]
00007d55df7d1710  mov r12, [r15+0x60]
00007d55df7d1714  imul r14, r12
00007d55df7d1718  lea r12, [rax+r14*1]
00007d55df7d171c  mov [r15+0x50], r12
00007d55df7d1720  mov rax, [r15+0x48]
00007d55df7d1724  lea r14, [r11+rax*1]
00007d55df7d1728  mov [r15+0x48], r14
00007d55df7d172c  mov eax, [r15+0x108]
00007d55df7d1733  sahf
00007d55df7d1734  jnz 0x00007D55DF7D1766
00007d55df7d1736  cmp dword ptr [r15+0x318], 0x00
00007d55df7d173e  jz 0x00007D55DF7D17B0
00007d55df7d1744  nop [rax+rax*1], ax
00007d55df7d174d  nop [rax+rax*1], eax
00007d55df7d1755  mov eax, 0x4103E0
00007d55df7d175a  mov [r15+0x100], rax
00007d55df7d1761  jmp 0x00007D55DF5FE110
00007d55df7d1766  cmp dword ptr [r15+0x318], 0x00
00007d55df7d176e  jz 0x00007D55DF7D1690
00007d55df7d1774  nop [rax+rax*1], ax
00007d55df7d177d  nop [rax+rax*1], eax
00007d55df7d1785  mov eax, 0x4103C0
00007d55df7d178a  mov [r15+0x100], rax
00007d55df7d1791  jmp 0x00007D55DF5FE110
00007d55df7d1796  int3
00007d55df7d1797  call 0x00007D55DF6B4690
00007d55df7d179c  jmp 0x00007D55DF7D16AD
00007d55df7d17a1  call 0x00007D55DF6E26A0
00007d55df7d17a6  jmp 0x00007D55DF7D16B7
00007d55df7d17ab  int3
00007d55df7d17ac  nop [rax], eax
00007d55df7d17b0  mov qword ptr [r15+0x98], 0x00
00007d55df7d17bb  mov rax, [r15+0x50]
00007d55df7d17bf  mov r14, [r15+0x48]
00007d55df7d17c3  lea r12, [rax+r14*1]
00007d55df7d17c7  mov [r15+0x48], r12
00007d55df7d17cb  mov rax, [r15+0x40]
00007d55df7d17cf  lea r14, [rax+0xCB0]
00007d55df7d17d6  mov [r13+r14*1], r12
00007d55df7d17db  mov qword ptr [r15], 0x01
00007d55df7d17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007d55df7d17ed  mov r14d, [r15+0x320]
00007d55df7d17f4  mov eax, 0x4103F8
00007d55df7d17f9  mov rcx, 0x7D55DF7D1860
00007d55df7d1803  mov [r15+r14*8+0x328], rax
00007d55df7d180b  mov [r15+r14*8+0x368], rcx
00007d55df7d1813  add r14d, 0x01
00007d55df7d1817  and r14d, 0x07
00007d55df7d181b  mov [r15+0x320], r14d
00007d55df7d1822  cmp dword ptr [r15+0x318], 0x00
00007d55df7d182a  jz 0x00007D55DF7D0F20
00007d55df7d1830  nop [rax+rax*1], ax
00007d55df7d1839  nop [rax+rax*1], eax
00007d55df7d1841  mov eax, 0x4109A4
00007d55df7d1846  mov [r15+0x100], rax
00007d55df7d184d  jmp 0x00007D55DF5FE110
00007d55df7d1852  int3
00007d55df7d1853  call 0x00007D55DF6E2CE0
00007d55df7d1858  jmp 0x00007D55DF7D17DB
00007d55df7d185d  int3
00007d55df7d185e  nop
00007d55df7d1860  mov eax, [r15+0x98]
00007d55df7d1867  lea r14d, [eax+0x01]
00007d55df7d186c  mov [rsp+0x10], r14d
00007d55df7d1871  mov r14d, r14d
00007d55df7d1874  mov [r15+0x98], r14
00007d55df7d187b  xor eax, eax
00007d55df7d187d  mov r14d, [rsp+0x10]
00007d55df7d1882  cmp r14d, 0x10000
00007d55df7d1889  cmc
00007d55df7d188a  lahf
00007d55df7d188b  seto al
00007d55df7d188e  mov [r15+0x108], eax
00007d55df7d1895  mov eax, [r15+0x108]
00007d55df7d189c  sahf
00007d55df7d189d  jnz 0x00007D55DF7D18CF
00007d55df7d189f  cmp dword ptr [r15+0x318], 0x00
00007d55df7d18a7  jz 0x00007D55DF7D19A0
00007d55df7d18ad  nop [rax+rax*1], ax
00007d55df7d18b6  nop [rax+rax*1], eax
00007d55df7d18be  mov eax, 0x410404
00007d55df7d18c3  mov [r15+0x100], rax
00007d55df7d18ca  jmp 0x00007D55DF5FE110
00007d55df7d18cf  cmp dword ptr [r15+0x318], 0x00
00007d55df7d18d7  jz 0x00007D55DF7D1910
00007d55df7d18dd  nop [rax+rax*1], ax
00007d55df7d18e6  nop [rax+rax*1], eax
00007d55df7d18ee  mov eax, 0x4103F0
00007d55df7d18f3  mov [r15+0x100], rax
00007d55df7d18fa  jmp 0x00007D55DF5FE110
00007d55df7d18ff  int3
00007d55df7d1900  int3
00007d55df7d1901  nop [rax+rax*1], ax
00007d55df7d190a  nop [rax+rax*1], ax
00007d55df7d1910  mov eax, [r15]
00007d55df7d1913  mov r14d, [r15+0x98]
00007d55df7d191a  lea r12d, [eax+r14d*1]
00007d55df7d191f  mov r12d, r12d
00007d55df7d1922  mov [r15], r12
00007d55df7d1925  mov qword ptr [r15+0xF0], 0x4103F8
00007d55df7d1930  mov r14d, [r15+0x320]
00007d55df7d1937  mov eax, 0x4103F8
00007d55df7d193c  mov rcx, 0x7D55DF7D1860
00007d55df7d1946  mov [r15+r14*8+0x328], rax
00007d55df7d194e  mov [r15+r14*8+0x368], rcx
00007d55df7d1956  add r14d, 0x01
00007d55df7d195a  and r14d, 0x07
00007d55df7d195e  mov [r15+0x320], r14d
00007d55df7d1965  cmp dword ptr [r15+0x318], 0x00
00007d55df7d196d  jz 0x00007D55DF7D0F20
00007d55df7d1973  nop [rax+rax*1], ax
00007d55df7d197c  nop [rax+rax*1], eax
00007d55df7d1984  mov eax, 0x4109A4
00007d55df7d1989  mov [r15+0x100], rax
00007d55df7d1990  jmp 0x00007D55DF5FE110
00007d55df7d1995  int3
00007d55df7d1996  int3
00007d55df7d1997  nop [rax+rax*1], ax
00007d55df7d19a0  vmovaps xmm1, [0x00007D55DF3FE010]
00007d55df7d19a8  movq xmm1, xmm1
00007d55df7d19ac  movaps [r15+0x110], xmm1
00007d55df7d19b4  mov eax, 0x420B10
00007d55df7d19b9  mov r14, [r13+rax*1]
00007d55df7d19be  movq xmm1, r14
00007d55df7d19c3  movaps [r15+0x120], xmm1
00007d55df7d19cb  vmovaps xmm1, [0x00007D55DF3FE020]
00007d55df7d19d3  movq xmm1, xmm1
00007d55df7d19d7  movaps [r15+0x140], xmm1
00007d55df7d19df  vmovaps xmm1, [0x00007D55DF3FE030]
00007d55df7d19e7  vpbroadcastq xmm1, xmm1
00007d55df7d19ec  movaps [r15+0x150], xmm1
00007d55df7d19f4  mov qword ptr [r15+0x40], 0x02
00007d55df7d19fc  vmovaps xmm15, [0x00007D55DF3FE040]
00007d55df7d1a04  movq xmm15, xmm15
00007d55df7d1a09  movaps [r15+0x160], xmm15
00007d55df7d1a11  vmovaps xmm15, [0x00007D55DF3FE050]
00007d55df7d1a19  vpbroadcastq xmm15, xmm15
00007d55df7d1a1e  movaps [r15+0x130], xmm15
00007d55df7d1a26  mov rax, [r15+0x40]
00007d55df7d1a2a  vmovq xmm14, rax
00007d55df7d1a2f  vpbroadcastq xmm14, xmm14
00007d55df7d1a34  movaps [r15+0x170], xmm14
00007d55df7d1a3c  mov eax, 0x420A40
00007d55df7d1a41  movups xmm13, [r13+rax*1]
00007d55df7d1a47  mov qword ptr [r15+0x40], 0x431E00
00007d55df7d1a4f  mov eax, [r15]
00007d55df7d1a52  mov r14d, 0x430CB8
00007d55df7d1a58  mov [r13+r14*1], eax
00007d55df7d1a5d  mov qword ptr [r15+0x50], 0x432000
00007d55df7d1a65  vpmovqd xmm12, xmm13
00007d55df7d1a6b  pxor xmm11, xmm11
00007d55df7d1a70  punpcklqdq xmm12, xmm11
00007d55df7d1a75  movaps [r15+0x210], xmm12
00007d55df7d1a7d  movq xmm12, qword ptr [r15+0x140]
00007d55df7d1a86  movq xmm11, qword ptr [r15+0x120]
00007d55df7d1a8f  psubd xmm12, xmm11
00007d55df7d1a94  movq xmm12, xmm12
00007d55df7d1a99  paddq xmm13, xmm14
00007d55df7d1a9e  movaps [r15+0x180], xmm13
00007d55df7d1aa6  movq xmm14, qword ptr [r15+0x160]
00007d55df7d1aaf  paddd xmm11, xmm14
00007d55df7d1ab4  movq xmm11, xmm11
00007d55df7d1ab9  movq xmm11, xmm11
00007d55df7d1abe  movaps [r15+0x120], xmm11
00007d55df7d1ac6  pmovzxdq xmm12, xmm12
00007d55df7d1acc  psllq xmm12, 0x00
00007d55df7d1ad2  movq xmm14, qword ptr [r15+0x210]
00007d55df7d1adb  movq xmm13, qword ptr [r15+0x110]
00007d55df7d1ae4  paddd xmm14, xmm13
00007d55df7d1ae9  movq xmm14, xmm14
00007d55df7d1aee  vcvtuqq2pd xmm12, xmm12
00007d55df7d1af4  pmovzxdq xmm14, xmm14
00007d55df7d1afa  psllq xmm14, 0x00
00007d55df7d1b00  vcvtuqq2pd xmm14, xmm14
00007d55df7d1b06  movaps xmm13, xmm12
00007d55df7d1b0a  mulpd xmm13, xmm1
00007d55df7d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007d55df7d1b15  ptest xmm11, xmm11
00007d55df7d1b1b  jnz 0x00007D55DF7D1C0F
00007d55df7d1b21  movaps [r15+0x220], xmm13
00007d55df7d1b29  mov eax, 0x432000
00007d55df7d1b2e  movups [r13+rax*1], xmm13
00007d55df7d1b34  movaps xmm1, xmm14
00007d55df7d1b38  mulpd xmm1, xmm15
00007d55df7d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007d55df7d1b42  ptest xmm13, xmm13
00007d55df7d1b48  jnz 0x00007D55DF7D1D5C
00007d55df7d1b4e  movaps [r15+0x210], xmm1
00007d55df7d1b56  mov eax, 0x431E00
00007d55df7d1b5b  movups [r13+rax*1], xmm1
00007d55df7d1b61  mov qword ptr [r15+0x48], 0x10
00007d55df7d1b69  xor eax, eax
00007d55df7d1b6b  mov r14d, 0x10
00007d55df7d1b71  mov r12d, 0x200
00007d55df7d1b77  cmp r14, r12
00007d55df7d1b7a  cmc
00007d55df7d1b7b  lahf
00007d55df7d1b7c  seto al
00007d55df7d1b7f  mov [r15+0x108], eax
00007d55df7d1b86  mov eax, [r15+0x108]
00007d55df7d1b8d  sahf
00007d55df7d1b8e  jnz 0x00007D55DF7D1BC0
00007d55df7d1b90  cmp dword ptr [r15+0x318], 0x00
00007d55df7d1b98  jz 0x00007D55DF7D2300
00007d55df7d1b9e  nop [rax+rax*1], ax
00007d55df7d1ba7  nop [rax+rax*1], eax
00007d55df7d1baf  mov eax, 0x410490
00007d55df7d1bb4  mov [r15+0x100], rax
00007d55df7d1bbb  jmp 0x00007D55DF5FE110
00007d55df7d1bc0  cmp dword ptr [r15+0x318], 0x00
00007d55df7d1bc8  jz 0x00007D55DF7D1EB0
00007d55df7d1bce  nop [rax+rax*1], ax
00007d55df7d1bd7  nop [rax+rax*1], eax
00007d55df7d1bdf  mov eax, 0x410450
00007d55df7d1be4  mov [r15+0x100], rax
00007d55df7d1beb  jmp 0x00007D55DF5FE110
00007d55df7d1bf0  int3
00007d55df7d1bf1  call 0x00007D55DF60DC20
00007d55df7d1bf6  jmp 0x00007D55DF7D19BE
00007d55df7d1bfb  call 0x00007D55DF60C260
00007d55df7d1c00  jmp 0x00007D55DF7D1A47
00007d55df7d1c05  call 0x00007D55DF6D5D70
00007d55df7d1c0a  jmp 0x00007D55DF7D1A5D
00007d55df7d1c0f  sub rsp, 0x08
00007d55df7d1c13  push rax
00007d55df7d1c14  push rcx
00007d55df7d1c15  push rdx
00007d55df7d1c16  push rdi
00007d55df7d1c17  push rsi
00007d55df7d1c18  push r8
00007d55df7d1c1a  push r9
00007d55df7d1c1c  push r10
00007d55df7d1c1e  push r11
00007d55df7d1c20  sub rsp, 0xF0
00007d55df7d1c27  vmovaps [rsp], xmm0
00007d55df7d1c2c  vmovaps [rsp+0x10], xmm1
00007d55df7d1c32  vmovaps [rsp+0x20], xmm2
00007d55df7d1c38  vmovaps [rsp+0x30], xmm3
00007d55df7d1c3e  vmovaps [rsp+0x40], xmm4
00007d55df7d1c44  vmovaps [rsp+0x50], xmm5
00007d55df7d1c4a  vmovaps [rsp+0x60], xmm6
00007d55df7d1c50  vmovaps [rsp+0x70], xmm7
00007d55df7d1c56  vmovaps [rsp+0x80], xmm8
00007d55df7d1c5f  vmovaps [rsp+0x90], xmm9
00007d55df7d1c68  vmovaps [rsp+0xA0], xmm10
00007d55df7d1c71  vmovaps [rsp+0xB0], xmm11
00007d55df7d1c7a  vmovaps [rsp+0xC0], xmm12
00007d55df7d1c83  vmovaps [rsp+0xD0], xmm14
00007d55df7d1c8c  vmovaps [rsp+0xE0], xmm15
00007d55df7d1c95  sub rsp, 0x30
00007d55df7d1c99  movaps [rsp], xmm13
00007d55df7d1c9e  movaps [rsp+0x10], xmm12
00007d55df7d1ca4  movaps [rsp+0x20], xmm1
00007d55df7d1ca9  lea rdi, [rsp]
00007d55df7d1cad  mov esi, 0x00
00007d55df7d1cb2  mov rax, 0x5BB8433D8530
00007d55df7d1cbc  call rax
00007d55df7d1cbe  movaps xmm13, [rsp]
00007d55df7d1cc3  add rsp, 0x30
00007d55df7d1cc7  vmovaps xmm0, [rsp]
00007d55df7d1ccc  vmovaps xmm1, [rsp+0x10]
00007d55df7d1cd2  vmovaps xmm2, [rsp+0x20]
00007d55df7d1cd8  vmovaps xmm3, [rsp+0x30]
00007d55df7d1cde  vmovaps xmm4, [rsp+0x40]
00007d55df7d1ce4  vmovaps xmm5, [rsp+0x50]
00007d55df7d1cea  vmovaps xmm6, [rsp+0x60]
00007d55df7d1cf0  vmovaps xmm7, [rsp+0x70]
00007d55df7d1cf6  vmovaps xmm8, [rsp+0x80]
00007d55df7d1cff  vmovaps xmm9, [rsp+0x90]
00007d55df7d1d08  vmovaps xmm10, [rsp+0xA0]
00007d55df7d1d11  vmovaps xmm11, [rsp+0xB0]
00007d55df7d1d1a  vmovaps xmm12, [rsp+0xC0]
00007d55df7d1d23  vmovaps xmm14, [rsp+0xD0]
00007d55df7d1d2c  vmovaps xmm15, [rsp+0xE0]
00007d55df7d1d35  add rsp, 0xF0
00007d55df7d1d3c  pop r11
00007d55df7d1d3e  pop r10
00007d55df7d1d40  pop r9
00007d55df7d1d42  pop r8
00007d55df7d1d44  pop rsi
00007d55df7d1d45  pop rdi
00007d55df7d1d46  pop rdx
00007d55df7d1d47  pop rcx
00007d55df7d1d48  pop rax
00007d55df7d1d49  add rsp, 0x08
00007d55df7d1d4d  jmp 0x00007D55DF7D1B21
00007d55df7d1d52  call 0x00007D55DF60C380
00007d55df7d1d57  jmp 0x00007D55DF7D1B34
00007d55df7d1d5c  sub rsp, 0x08
00007d55df7d1d60  push rax
00007d55df7d1d61  push rcx
00007d55df7d1d62  push rdx
00007d55df7d1d63  push rdi
00007d55df7d1d64  push rsi
00007d55df7d1d65  push r8
00007d55df7d1d67  push r9
00007d55df7d1d69  push r10
00007d55df7d1d6b  push r11
00007d55df7d1d6d  sub rsp, 0xF0
00007d55df7d1d74  vmovaps [rsp], xmm0
00007d55df7d1d79  vmovaps [rsp+0x10], xmm2
00007d55df7d1d7f  vmovaps [rsp+0x20], xmm3
00007d55df7d1d85  vmovaps [rsp+0x30], xmm4
00007d55df7d1d8b  vmovaps [rsp+0x40], xmm5
00007d55df7d1d91  vmovaps [rsp+0x50], xmm6
00007d55df7d1d97  vmovaps [rsp+0x60], xmm7
00007d55df7d1d9d  vmovaps [rsp+0x70], xmm8
00007d55df7d1da3  vmovaps [rsp+0x80], xmm9
00007d55df7d1dac  vmovaps [rsp+0x90], xmm10
00007d55df7d1db5  vmovaps [rsp+0xA0], xmm11
00007d55df7d1dbe  vmovaps [rsp+0xB0], xmm12
00007d55df7d1dc7  vmovaps [rsp+0xC0], xmm13
00007d55df7d1dd0  vmovaps [rsp+0xD0], xmm14
00007d55df7d1dd9  vmovaps [rsp+0xE0], xmm15
00007d55df7d1de2  sub rsp, 0x30
00007d55df7d1de6  movaps [rsp], xmm1
00007d55df7d1dea  movaps [rsp+0x10], xmm14
00007d55df7d1df0  movaps [rsp+0x20], xmm15
00007d55df7d1df6  lea rdi, [rsp]
00007d55df7d1dfa  mov esi, 0x00
00007d55df7d1dff  mov rax, 0x5BB8433D8530
00007d55df7d1e09  call rax
00007d55df7d1e0b  movaps xmm1, [rsp]
00007d55df7d1e0f  add rsp, 0x30
00007d55df7d1e13  vmovaps xmm0, [rsp]
00007d55df7d1e18  vmovaps xmm2, [rsp+0x10]
00007d55df7d1e1e  vmovaps xmm3, [rsp+0x20]
00007d55df7d1e24  vmovaps xmm4, [rsp+0x30]
00007d55df7d1e2a  vmovaps xmm5, [rsp+0x40]
00007d55df7d1e30  vmovaps xmm6, [rsp+0x50]
00007d55df7d1e36  vmovaps xmm7, [rsp+0x60]
00007d55df7d1e3c  vmovaps xmm8, [rsp+0x70]
00007d55df7d1e42  vmovaps xmm9, [rsp+0x80]
00007d55df7d1e4b  vmovaps xmm10, [rsp+0x90]
00007d55df7d1e54  vmovaps xmm11, [rsp+0xA0]
00007d55df7d1e5d  vmovaps xmm12, [rsp+0xB0]
00007d55df7d1e66  vmovaps xmm13, [rsp+0xC0]
00007d55df7d1e6f  vmovaps xmm14, [rsp+0xD0]
00007d55df7d1e78  vmovaps xmm15, [rsp+0xE0]
00007d55df7d1e81  add rsp, 0xF0
00007d55df7d1e88  pop r11
00007d55df7d1e8a  pop r10
00007d55df7d1e8c  pop r9
00007d55df7d1e8e  pop r8
00007d55df7d1e90  pop rsi
00007d55df7d1e91  pop rdi
00007d55df7d1e92  pop rdx
00007d55df7d1e93  pop rcx
00007d55df7d1e94  pop rax
00007d55df7d1e95  add rsp, 0x08
00007d55df7d1e99  jmp 0x00007D55DF7D1B4E
00007d55df7d1e9e  call 0x00007D55DF5FF540
00007d55df7d1ea3  jmp 0x00007D55DF7D1B61
00007d55df7d1ea8  int3
00007d55df7d1ea9  nop [rax], eax
00007d55df7d1eb0  movaps xmm1, [r15+0x180]
00007d55df7d1eb8  vpmovqd xmm15, xmm1
00007d55df7d1ebe  pxor xmm14, xmm14
00007d55df7d1ec3  punpcklqdq xmm15, xmm14
00007d55df7d1ec8  movaps [r15+0x210], xmm15
00007d55df7d1ed0  movq xmm15, qword ptr [r15+0x140]
00007d55df7d1ed9  movq xmm14, qword ptr [r15+0x120]
00007d55df7d1ee2  psubd xmm15, xmm14
00007d55df7d1ee7  movq xmm15, xmm15
00007d55df7d1eec  movaps xmm13, [r15+0x170]
00007d55df7d1ef4  paddq xmm1, xmm13
00007d55df7d1ef9  movaps [r15+0x180], xmm1
00007d55df7d1f01  movq xmm1, qword ptr [r15+0x160]
00007d55df7d1f0a  paddd xmm14, xmm1
00007d55df7d1f0f  movq xmm14, xmm14
00007d55df7d1f14  movq xmm14, xmm14
00007d55df7d1f19  movaps [r15+0x120], xmm14
00007d55df7d1f21  pmovzxdq xmm15, xmm15
00007d55df7d1f27  psllq xmm15, 0x00
00007d55df7d1f2d  movq xmm1, qword ptr [r15+0x210]
00007d55df7d1f36  movq xmm14, qword ptr [r15+0x110]
00007d55df7d1f3f  paddd xmm1, xmm14
00007d55df7d1f44  movq xmm1, xmm1
00007d55df7d1f48  vcvtuqq2pd xmm15, xmm15
00007d55df7d1f4e  pmovzxdq xmm1, xmm1
00007d55df7d1f53  psllq xmm1, 0x00
00007d55df7d1f58  vcvtuqq2pd xmm1, xmm1
00007d55df7d1f5e  movaps xmm14, [r15+0x150]
00007d55df7d1f66  movaps xmm13, xmm15
00007d55df7d1f6a  mulpd xmm13, xmm14
00007d55df7d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007d55df7d1f75  ptest xmm12, xmm12
00007d55df7d1f7b  jnz 0x00007D55DF7D205E
00007d55df7d1f81  movaps [r15+0x220], xmm13
00007d55df7d1f89  mov rax, [r15+0x48]
00007d55df7d1f8d  mov r14, [r15+0x50]
00007d55df7d1f91  lea r12, [r14+rax*1]
00007d55df7d1f95  movups [r13+r12*1], xmm13
00007d55df7d1f9b  movaps xmm15, [r15+0x130]
00007d55df7d1fa3  movaps xmm14, xmm1
00007d55df7d1fa7  mulpd xmm14, xmm15
00007d55df7d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007d55df7d1fb2  ptest xmm13, xmm13
00007d55df7d1fb8  jnz 0x00007D55DF7D21AC
00007d55df7d1fbe  movaps [r15+0x210], xmm14
00007d55df7d1fc6  mov r14, [r15+0x40]
00007d55df7d1fca  lea r12, [r14+rax*1]
00007d55df7d1fce  movups [r13+r12*1], xmm14
00007d55df7d1fd4  lea r14, [rax+0x10]
00007d55df7d1fd8  mov [r15+0x48], r14
00007d55df7d1fdc  xor eax, eax
00007d55df7d1fde  mov r12d, 0x200
00007d55df7d1fe4  cmp r14, r12
00007d55df7d1fe7  cmc
00007d55df7d1fe8  lahf
00007d55df7d1fe9  seto al
00007d55df7d1fec  mov [r15+0x108], eax
00007d55df7d1ff3  mov eax, [r15+0x108]
00007d55df7d1ffa  sahf
00007d55df7d1ffb  jnz 0x00007D55DF7D202D
00007d55df7d1ffd  cmp dword ptr [r15+0x318], 0x00
00007d55df7d2005  jz 0x00007D55DF7D2300
00007d55df7d200b  nop [rax+rax*1], ax
00007d55df7d2014  nop [rax+rax*1], eax
00007d55df7d201c  mov eax, 0x410490
00007d55df7d2021  mov [r15+0x100], rax
00007d55df7d2028  jmp 0x00007D55DF5FE110
00007d55df7d202d  cmp dword ptr [r15+0x318], 0x00
00007d55df7d2035  jz 0x00007D55DF7D1EB0
00007d55df7d203b  nop [rax+rax*1], ax
00007d55df7d2044  nop [rax+rax*1], eax
00007d55df7d204c  mov eax, 0x410450
00007d55df7d2051  mov [r15+0x100], rax
00007d55df7d2058  jmp 0x00007D55DF5FE110
00007d55df7d205d  int3
00007d55df7d205e  sub rsp, 0x08
00007d55df7d2062  push rax
00007d55df7d2063  push rcx
00007d55df7d2064  push rdx
00007d55df7d2065  push rdi
00007d55df7d2066  push rsi
00007d55df7d2067  push r8
00007d55df7d2069  push r9
00007d55df7d206b  push r10
00007d55df7d206d  push r11
00007d55df7d206f  sub rsp, 0xF0
00007d55df7d2076  vmovaps [rsp], xmm0
00007d55df7d207b  vmovaps [rsp+0x10], xmm1
00007d55df7d2081  vmovaps [rsp+0x20], xmm2
00007d55df7d2087  vmovaps [rsp+0x30], xmm3
00007d55df7d208d  vmovaps [rsp+0x40], xmm4
00007d55df7d2093  vmovaps [rsp+0x50], xmm5
00007d55df7d2099  vmovaps [rsp+0x60], xmm6
00007d55df7d209f  vmovaps [rsp+0x70], xmm7
00007d55df7d20a5  vmovaps [rsp+0x80], xmm8
00007d55df7d20ae  vmovaps [rsp+0x90], xmm9
00007d55df7d20b7  vmovaps [rsp+0xA0], xmm10
00007d55df7d20c0  vmovaps [rsp+0xB0], xmm11
00007d55df7d20c9  vmovaps [rsp+0xC0], xmm12
00007d55df7d20d2  vmovaps [rsp+0xD0], xmm14
00007d55df7d20db  vmovaps [rsp+0xE0], xmm15
00007d55df7d20e4  sub rsp, 0x30
00007d55df7d20e8  movaps [rsp], xmm13
00007d55df7d20ed  movaps [rsp+0x10], xmm15
00007d55df7d20f3  movaps [rsp+0x20], xmm14
00007d55df7d20f9  lea rdi, [rsp]
00007d55df7d20fd  mov esi, 0x00
00007d55df7d2102  mov rax, 0x5BB8433D8530
00007d55df7d210c  call rax
00007d55df7d210e  movaps xmm13, [rsp]
00007d55df7d2113  add rsp, 0x30
00007d55df7d2117  vmovaps xmm0, [rsp]
00007d55df7d211c  vmovaps xmm1, [rsp+0x10]
00007d55df7d2122  vmovaps xmm2, [rsp+0x20]
00007d55df7d2128  vmovaps xmm3, [rsp+0x30]
00007d55df7d212e  vmovaps xmm4, [rsp+0x40]
00007d55df7d2134  vmovaps xmm5, [rsp+0x50]
00007d55df7d213a  vmovaps xmm6, [rsp+0x60]
00007d55df7d2140  vmovaps xmm7, [rsp+0x70]
00007d55df7d2146  vmovaps xmm8, [rsp+0x80]
00007d55df7d214f  vmovaps xmm9, [rsp+0x90]
00007d55df7d2158  vmovaps xmm10, [rsp+0xA0]
00007d55df7d2161  vmovaps xmm11, [rsp+0xB0]
00007d55df7d216a  vmovaps xmm12, [rsp+0xC0]
00007d55df7d2173  vmovaps xmm14, [rsp+0xD0]
00007d55df7d217c  vmovaps xmm15, [rsp+0xE0]
00007d55df7d2185  add rsp, 0xF0
00007d55df7d218c  pop r11
00007d55df7d218e  pop r10
00007d55df7d2190  pop r9
00007d55df7d2192  pop r8
00007d55df7d2194  pop rsi
00007d55df7d2195  pop rdi
00007d55df7d2196  pop rdx
00007d55df7d2197  pop rcx
00007d55df7d2198  pop rax
00007d55df7d2199  add rsp, 0x08
00007d55df7d219d  jmp 0x00007D55DF7D1F81
00007d55df7d21a2  call 0x00007D55DF6C2240
00007d55df7d21a7  jmp 0x00007D55DF7D1F9B
00007d55df7d21ac  sub rsp, 0x08
00007d55df7d21b0  push rax
00007d55df7d21b1  push rcx
00007d55df7d21b2  push rdx
00007d55df7d21b3  push rdi
00007d55df7d21b4  push rsi
00007d55df7d21b5  push r8
00007d55df7d21b7  push r9
00007d55df7d21b9  push r10
00007d55df7d21bb  push r11
00007d55df7d21bd  sub rsp, 0xF0
00007d55df7d21c4  vmovaps [rsp], xmm0
00007d55df7d21c9  vmovaps [rsp+0x10], xmm1
00007d55df7d21cf  vmovaps [rsp+0x20], xmm2
00007d55df7d21d5  vmovaps [rsp+0x30], xmm3
00007d55df7d21db  vmovaps [rsp+0x40], xmm4
00007d55df7d21e1  vmovaps [rsp+0x50], xmm5
00007d55df7d21e7  vmovaps [rsp+0x60], xmm6
00007d55df7d21ed  vmovaps [rsp+0x70], xmm7
00007d55df7d21f3  vmovaps [rsp+0x80], xmm8
00007d55df7d21fc  vmovaps [rsp+0x90], xmm9
00007d55df7d2205  vmovaps [rsp+0xA0], xmm10
00007d55df7d220e  vmovaps [rsp+0xB0], xmm11
00007d55df7d2217  vmovaps [rsp+0xC0], xmm12
00007d55df7d2220  vmovaps [rsp+0xD0], xmm13
00007d55df7d2229  vmovaps [rsp+0xE0], xmm15
00007d55df7d2232  sub rsp, 0x30
00007d55df7d2236  movaps [rsp], xmm14
00007d55df7d223b  movaps [rsp+0x10], xmm1
00007d55df7d2240  movaps [rsp+0x20], xmm15
00007d55df7d2246  lea rdi, [rsp]
00007d55df7d224a  mov esi, 0x00
00007d55df7d224f  mov rax, 0x5BB8433D8530
00007d55df7d2259  call rax
00007d55df7d225b  movaps xmm14, [rsp]
00007d55df7d2260  add rsp, 0x30
00007d55df7d2264  vmovaps xmm0, [rsp]
00007d55df7d2269  vmovaps xmm1, [rsp+0x10]
00007d55df7d226f  vmovaps xmm2, [rsp+0x20]
00007d55df7d2275  vmovaps xmm3, [rsp+0x30]
00007d55df7d227b  vmovaps xmm4, [rsp+0x40]
00007d55df7d2281  vmovaps xmm5, [rsp+0x50]
00007d55df7d2287  vmovaps xmm6, [rsp+0x60]
00007d55df7d228d  vmovaps xmm7, [rsp+0x70]
00007d55df7d2293  vmovaps xmm8, [rsp+0x80]
00007d55df7d229c  vmovaps xmm9, [rsp+0x90]
00007d55df7d22a5  vmovaps xmm10, [rsp+0xA0]
00007d55df7d22ae  vmovaps xmm11, [rsp+0xB0]
00007d55df7d22b7  vmovaps xmm12, [rsp+0xC0]
00007d55df7d22c0  vmovaps xmm13, [rsp+0xD0]
00007d55df7d22c9  vmovaps xmm15, [rsp+0xE0]
00007d55df7d22d2  add rsp, 0xF0
00007d55df7d22d9  pop r11
00007d55df7d22db  pop r10
00007d55df7d22dd  pop r9
00007d55df7d22df  pop r8
00007d55df7d22e1  pop rsi
00007d55df7d22e2  pop rdi
00007d55df7d22e3  pop rdx
00007d55df7d22e4  pop rcx
00007d55df7d22e5  pop rax
00007d55df7d22e6  add rsp, 0x08
00007d55df7d22ea  jmp 0x00007D55DF7D1FBE
00007d55df7d22ef  call 0x00007D55DF6C34C0
00007d55df7d22f4  jmp 0x00007D55DF7D1FD4
00007d55df7d22f9  int3
00007d55df7d22fa  nop [rax+rax*1], ax
00007d55df7d2300  mov rax, [r15+0x50]
00007d55df7d2304  lea r14, [rax+0x80]
00007d55df7d230b  movups xmm1, [r13+r14*1]
00007d55df7d2311  lea r14, [rax+0x90]
00007d55df7d2318  movups xmm15, [r13+r14*1]
00007d55df7d231e  vxorps xmm14, xmm14, xmm14
00007d55df7d2323  vpbroadcastq xmm14, xmm14
00007d55df7d2328  lea r14, [rax+0x40]
00007d55df7d232c  movups xmm13, [r13+r14*1]
00007d55df7d2332  lea r14, [rax+0x50]
00007d55df7d2336  movups xmm12, [r13+r14*1]
00007d55df7d233c  mov qword ptr [r15+0x48], 0x00
00007d55df7d2344  movups xmm11, [r13+rax*1]
00007d55df7d234a  lea r14, [rax+0x10]
00007d55df7d234e  movups xmm10, [r13+r14*1]
00007d55df7d2354  mov r14, [r15+0xF8]
00007d55df7d235b  lea r12, [r14+0xE0]
00007d55df7d2362  movups [r13+r12*1], xmm15
00007d55df7d2368  lea r12, [r14+0xF0]
00007d55df7d236f  movups [r13+r12*1], xmm1
00007d55df7d2375  lea r12, [rax+0xC0]
00007d55df7d237c  movups xmm1, [r13+r12*1]
00007d55df7d2382  lea r12, [rax+0xD0]
00007d55df7d2389  movups xmm15, [r13+r12*1]
00007d55df7d238f  lea r12, [rax+0x140]
00007d55df7d2396  movups xmm9, [r13+r12*1]
00007d55df7d239c  lea r12, [rax+0x150]
00007d55df7d23a3  movups xmm8, [r13+r12*1]
00007d55df7d23a9  lea r12, [rax+0x180]
00007d55df7d23b0  movups xmm7, [r13+r12*1]
00007d55df7d23b6  lea r12, [rax+0x190]
00007d55df7d23bd  movups xmm6, [r13+r12*1]
00007d55df7d23c3  lea r12, [r14+0xC0]
00007d55df7d23ca  movups [r13+r12*1], xmm15
00007d55df7d23d0  lea r12, [r14+0xD0]
00007d55df7d23d7  movups [r13+r12*1], xmm1
00007d55df7d23dd  lea r12, [rax+0x100]
00007d55df7d23e4  movups xmm1, [r13+r12*1]
00007d55df7d23ea  lea r12, [rax+0x110]
00007d55df7d23f1  movups xmm15, [r13+r12*1]
00007d55df7d23f7  lea r12, [rax+0x1C0]
00007d55df7d23fe  movups xmm5, [r13+r12*1]
00007d55df7d2404  lea r12, [rax+0x1D0]
00007d55df7d240b  movups xmm4, [r13+r12*1]
00007d55df7d2411  lea r12, [rax+0x20]
00007d55df7d2415  movups xmm3, [r13+r12*1]
00007d55df7d241b  lea r12, [rax+0x30]
00007d55df7d241f  movups xmm2, [r13+r12*1]
00007d55df7d2425  movaps [r15+0x1F0], xmm2
00007d55df7d242d  lea r12, [r14+0x20]
00007d55df7d2431  movups [r13+r12*1], xmm1
00007d55df7d2437  lea r12, [r14+0x30]
00007d55df7d243b  movups [r13+r12*1], xmm12
00007d55df7d2441  lea r12, [rax+0x60]
00007d55df7d2445  movups xmm1, [r13+r12*1]
00007d55df7d244b  lea r12, [rax+0x70]
00007d55df7d244f  movups xmm12, [r13+r12*1]
00007d55df7d2455  lea r12, [r14+0x60]
00007d55df7d2459  movups [r13+r12*1], xmm11
00007d55df7d245f  lea r12, [r14+0x70]
00007d55df7d2463  movups [r13+r12*1], xmm5
00007d55df7d2469  lea r12, [rax+0xE0]
00007d55df7d2470  movups xmm11, [r13+r12*1]
00007d55df7d2476  lea r12, [rax+0xF0]
00007d55df7d247d  movups xmm5, [r13+r12*1]
00007d55df7d2483  lea r12, [rax+0x120]
00007d55df7d248a  vmovaps [rsp+0x10], xmm1
00007d55df7d2490  movups xmm1, [r13+r12*1]
00007d55df7d2496  lea r12, [rax+0x130]
00007d55df7d249d  vmovaps [rsp+0x20], xmm1
00007d55df7d24a3  movups xmm1, [r13+r12*1]
00007d55df7d24a9  lea r12, [r14+0xA0]
00007d55df7d24b0  movups [r13+r12*1], xmm12
00007d55df7d24b6  lea r12, [r14+0xB0]
00007d55df7d24bd  vmovaps xmm12, [rsp+0x10]
00007d55df7d24c3  movups [r13+r12*1], xmm12
00007d55df7d24c9  lea r12, [rax+0xA0]
00007d55df7d24d0  movups xmm12, [r13+r12*1]
00007d55df7d24d6  lea r12, [rax+0xB0]
00007d55df7d24dd  vmovaps [rsp+0x10], xmm1
00007d55df7d24e3  movups xmm1, [r13+r12*1]
00007d55df7d24e9  lea r12, [rax+0x160]
00007d55df7d24f0  vmovaps [rsp+0x30], xmm1
00007d55df7d24f6  movups xmm1, [r13+r12*1]
00007d55df7d24fc  lea r12, [rax+0x170]
00007d55df7d2503  vmovaps [rsp+0x40], xmm1
00007d55df7d2509  movups xmm1, [r13+r12*1]
00007d55df7d250f  movaps [r15+0x2B0], xmm1
00007d55df7d2517  lea r12, [rax+0x1A0]
00007d55df7d251e  vmovaps [rsp+0x50], xmm1
00007d55df7d2524  movups xmm1, [r13+r12*1]
00007d55df7d252a  lea r12, [rax+0x1B0]
00007d55df7d2531  vmovaps [rsp+0x60], xmm1
00007d55df7d2537  movups xmm1, [r13+r12*1]
00007d55df7d253d  vmovaps [rsp+0x70], xmm1
00007d55df7d2543  vmovaps xmm1, [rsp+0x60]
00007d55df7d2549  movaps [r15+0x290], xmm1
00007d55df7d2551  vmovaps [rsp+0x60], xmm1
00007d55df7d2557  vmovaps xmm1, [rsp+0x70]
00007d55df7d255d  movaps [r15+0x1E0], xmm1
00007d55df7d2565  lea r12, [r14+0x80]
00007d55df7d256c  vmovaps [rsp+0x70], xmm1
00007d55df7d2572  vmovaps xmm1, [rsp+0x30]
00007d55df7d2578  movups [r13+r12*1], xmm1
00007d55df7d257e  lea r12, [r14+0x90]
00007d55df7d2585  movups [r13+r12*1], xmm12
00007d55df7d258b  lea r12, [rax+0x1E0]
00007d55df7d2592  movups xmm1, [r13+r12*1]
00007d55df7d2598  lea r12, [rax+0x1F0]
00007d55df7d259f  movups xmm12, [r13+r12*1]
00007d55df7d25a5  mov qword ptr [r15+0x50], 0x432200
00007d55df7d25ad  lea rax, [r14+0x40]
00007d55df7d25b1  vmovaps [rsp+0x30], xmm1
00007d55df7d25b7  vmovaps xmm1, [rsp+0x40]
00007d55df7d25bd  movups [r13+rax*1], xmm1
00007d55df7d25c3  lea rax, [r14+0x50]
00007d55df7d25c7  movups [r13+rax*1], xmm10
00007d55df7d25cd  movups [r13+r14*1], xmm12
00007d55df7d25d3  lea rax, [r14+0x10]
00007d55df7d25d7  vmovaps xmm1, [rsp+0x30]
00007d55df7d25dd  movups [r13+rax*1], xmm1
00007d55df7d25e3  mov rax, [r15+0x40]
00007d55df7d25e7  vmovaps [rsp+0x30], xmm3
00007d55df7d25ed  vmovaps xmm1, [rsp+0x30]
00007d55df7d25f3  por xmm3, xmm1
00007d55df7d25f7  vmovaps [rsp+0x30], xmm6
00007d55df7d25fd  vmovaps xmm12, [rsp+0x30]
00007d55df7d2603  por xmm6, xmm12
00007d55df7d2608  lea r12, [rax+0x30]
00007d55df7d260c  mov r11, [r13+r12*1]
00007d55df7d2611  lea r12, [rax+0x38]
00007d55df7d2615  mov r10, [r13+r12*1]
00007d55df7d261a  movq xmm12, r11
00007d55df7d261f  movq xmm10, r10
00007d55df7d2624  movq xmm12, xmm12
00007d55df7d2629  vmovaps [rsp+0x30], xmm12
00007d55df7d262f  movq xmm12, xmm12
00007d55df7d2634  movaps [r15+0x130], xmm12
00007d55df7d263c  movq xmm10, xmm10
00007d55df7d2641  vmovaps [rsp+0x40], xmm10
00007d55df7d2647  movq xmm10, xmm10
00007d55df7d264c  movaps [r15+0x280], xmm10
00007d55df7d2654  vmovaps [rsp+0x80], xmm9
00007d55df7d265d  vmovaps xmm12, [rsp+0x80]
00007d55df7d2666  por xmm9, xmm12
00007d55df7d266b  lea r12, [rax+0x20]
00007d55df7d266f  mov r11, [r13+r12*1]
00007d55df7d2674  lea r12, [rax+0x28]
00007d55df7d2678  mov r10, [r13+r12*1]
00007d55df7d267d  movq xmm12, r11
00007d55df7d2682  movq xmm10, r10
00007d55df7d2687  movq xmm12, xmm12
00007d55df7d268c  vmovaps [rsp+0x80], xmm12
00007d55df7d2695  movq xmm12, xmm12
00007d55df7d269a  movaps [r15+0x150], xmm12
00007d55df7d26a2  movq xmm10, xmm10
00007d55df7d26a7  vmovaps [rsp+0x90], xmm10
00007d55df7d26b0  movq xmm10, xmm10
00007d55df7d26b5  movaps [r15+0x140], xmm10
00007d55df7d26bd  lea r12, [rax+0x10]
00007d55df7d26c1  mov r11, [r13+r12*1]
00007d55df7d26c6  lea r12, [rax+0x18]
00007d55df7d26ca  mov r10, [r13+r12*1]
00007d55df7d26cf  movq xmm12, r11
00007d55df7d26d4  movq xmm10, r10
00007d55df7d26d9  movq xmm12, xmm12
00007d55df7d26de  vmovaps [rsp+0xA0], xmm12
00007d55df7d26e7  movq xmm12, xmm12
00007d55df7d26ec  movaps [r15+0x170], xmm12
00007d55df7d26f4  movq xmm10, xmm10
00007d55df7d26f9  vmovaps [rsp+0xB0], xmm10
00007d55df7d2702  movq xmm10, xmm10
00007d55df7d2707  movaps [r15+0x160], xmm10
00007d55df7d270f  mov r12, [r13+rax*1]
00007d55df7d2714  vmovq xmm12, r12
00007d55df7d2719  vpbroadcastq xmm12, xmm12
00007d55df7d271e  lea r12, [rax+0x08]
00007d55df7d2722  mov rax, [r13+r12*1]
00007d55df7d2727  movq xmm10, rax
00007d55df7d272c  movaps [r15+0x230], xmm10
00007d55df7d2734  lea rax, [r14+0x50]
00007d55df7d2738  movups xmm10, [r13+rax*1]
00007d55df7d273e  lea rax, [r14+0x60]
00007d55df7d2742  vmovaps [rsp+0xC0], xmm1
00007d55df7d274b  movups xmm1, [r13+rax*1]
00007d55df7d2751  lea rax, [r14+0x30]
00007d55df7d2755  vmovaps [rsp+0xD0], xmm1
00007d55df7d275e  movups xmm1, [r13+rax*1]
00007d55df7d2764  mov qword ptr [r15+0x60], 0x432200
00007d55df7d276c  mov qword ptr [r15+0x58], 0x40
00007d55df7d2774  vmovaps [rsp+0xE0], xmm1
00007d55df7d277d  vmovaps [rsp+0xF0], xmm15
00007d55df7d2786  vmovaps xmm15, [rsp+0xC0]
00007d55df7d278f  vmovaps [rsp+0xC0], xmm14
00007d55df7d2798  movaps xmm1, xmm12
00007d55df7d279c  mulpd xmm1, xmm15
00007d55df7d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007d55df7d27a6  ptest xmm14, xmm14
00007d55df7d27ac  jnz 0x00007D55DF7D3863
00007d55df7d27b2  movq xmm15, qword ptr [r15+0x230]
00007d55df7d27bb  vmovaps [rsp+0x100], xmm15
00007d55df7d27c4  vpermilpd xmm15, xmm15, 0x00
00007d55df7d27ca  vmovaps [rsp+0x110], xmm1
00007d55df7d27d3  vmovaps xmm1, [rsp+0xE0]
00007d55df7d27dc  vmovaps [rsp+0xE0], xmm13
00007d55df7d27e5  movaps xmm14, xmm1
00007d55df7d27e9  mulpd xmm14, xmm15
00007d55df7d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007d55df7d27f4  ptest xmm13, xmm13
00007d55df7d27fa  jnz 0x00007D55DF7D39A5
00007d55df7d2800  vxorps xmm1, xmm1, xmm1
00007d55df7d2804  vpbroadcastq xmm1, xmm1
00007d55df7d2809  vmovaps xmm13, [rsp+0xD0]
00007d55df7d2812  vmovaps [rsp+0xD0], xmm1
00007d55df7d281b  movaps xmm15, xmm12
00007d55df7d281f  mulpd xmm15, xmm13
00007d55df7d2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007d55df7d282a  ptest xmm1, xmm1
00007d55df7d282f  jnz 0x00007D55DF7D3AE8
00007d55df7d2835  movaps xmm1, xmm12
00007d55df7d2839  mulpd xmm1, xmm10
00007d55df7d283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007d55df7d2843  ptest xmm13, xmm13
00007d55df7d2849  jnz 0x00007D55DF7D3C2C
00007d55df7d284f  movaps xmm13, xmm12
00007d55df7d2853  mulpd xmm13, xmm2
00007d55df7d2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007d55df7d285e  ptest xmm10, xmm10
00007d55df7d2864  jnz 0x00007D55DF7D3D6E
00007d55df7d286a  vmovaps [rsp+0x120], xmm7
00007d55df7d2873  vmovaps xmm12, [rsp+0x120]
00007d55df7d287c  por xmm7, xmm12
00007d55df7d2881  vmovaps xmm12, [rsp+0xE0]
00007d55df7d288a  vmovaps xmm10, [rsp+0xE0]
00007d55df7d2893  por xmm12, xmm10
00007d55df7d2898  vmovaps xmm2, [rsp+0x100]
00007d55df7d28a1  vpermilpd xmm2, xmm2, 0x00
00007d55df7d28a7  vmovaps [rsp+0xE0], xmm1
00007d55df7d28b0  vmovaps [rsp+0x120], xmm15
00007d55df7d28b9  movaps xmm1, xmm10
00007d55df7d28bd  mulpd xmm1, xmm2
00007d55df7d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007d55df7d28c6  ptest xmm15, xmm15
00007d55df7d28cc  jnz 0x00007D55DF7D3EB1
00007d55df7d28d2  xor eax, eax
00007d55df7d28d4  mov r12d, 0x40
00007d55df7d28da  mov r11d, 0x200
00007d55df7d28e0  cmp r12, r11
00007d55df7d28e3  cmc
00007d55df7d28e4  lahf
00007d55df7d28e5  seto al
00007d55df7d28e8  mov [r15+0x108], eax
00007d55df7d28ef  vmovaps xmm10, [rsp+0x110]
00007d55df7d28f8  vmovaps xmm2, [rsp+0xD0]
00007d55df7d2901  vmovaps [rsp+0xD0], xmm1
00007d55df7d290a  movaps xmm15, xmm10
00007d55df7d290e  addpd xmm15, xmm2
00007d55df7d2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007d55df7d2919  ptest xmm1, xmm1
00007d55df7d291e  jnz 0x00007D55DF7D3FF2
00007d55df7d2924  vmovaps xmm10, [rsp+0x120]
00007d55df7d292d  vmovaps [rsp+0x110], xmm15
00007d55df7d2936  vmovaps xmm15, [rsp+0xC0]
00007d55df7d293f  vmovaps [rsp+0xC0], xmm14
00007d55df7d2948  movaps xmm1, xmm10
00007d55df7d294c  addpd xmm1, xmm15
00007d55df7d2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007d55df7d2956  ptest xmm14, xmm14
00007d55df7d295c  jnz 0x00007D55DF7D4135
00007d55df7d2962  vmovaps xmm10, [rsp+0xE0]
00007d55df7d296b  vmovaps [rsp+0xE0], xmm1
00007d55df7d2974  movaps xmm14, xmm10
00007d55df7d2978  addpd xmm14, xmm15
00007d55df7d297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007d55df7d2983  ptest xmm1, xmm1
00007d55df7d2988  jnz 0x00007D55DF7D4277
00007d55df7d298e  vmovaps xmm1, [rsp+0x10]
00007d55df7d2994  vmovaps xmm15, [rsp+0x10]
00007d55df7d299a  por xmm1, xmm15
00007d55df7d299f  vmovaps xmm15, [rsp+0x20]
00007d55df7d29a5  vmovaps xmm10, [rsp+0x20]
00007d55df7d29ab  por xmm15, xmm10
00007d55df7d29b0  vmovaps [rsp+0x10], xmm5
00007d55df7d29b6  vmovaps xmm10, [rsp+0x10]
00007d55df7d29bc  por xmm5, xmm10
00007d55df7d29c1  vmovaps [rsp+0x10], xmm11
00007d55df7d29c7  vmovaps xmm10, [rsp+0x10]
00007d55df7d29cd  por xmm11, xmm10
00007d55df7d29d2  vmovaps [rsp+0x10], xmm4
00007d55df7d29d8  vmovaps xmm10, [rsp+0x10]
00007d55df7d29de  por xmm4, xmm10
00007d55df7d29e3  vmovaps [rsp+0x10], xmm8
00007d55df7d29e9  vmovaps xmm10, [rsp+0x10]
00007d55df7d29ef  por xmm8, xmm10
00007d55df7d29f4  vmovaps xmm10, [rsp+0xF0]
00007d55df7d29fd  vmovaps [rsp+0x10], xmm1
00007d55df7d2a03  vmovaps xmm1, [rsp+0xF0]
00007d55df7d2a0c  por xmm10, xmm1
00007d55df7d2a11  lea rax, [r14+0xA0]
00007d55df7d2a18  movups xmm1, [r13+rax*1]
00007d55df7d2a1e  lea rax, [r14+0xB0]
00007d55df7d2a25  vmovaps [rsp+0x20], xmm1
00007d55df7d2a2b  movups xmm1, [r13+rax*1]
00007d55df7d2a31  vmovaps [rsp+0xF0], xmm1
00007d55df7d2a3a  vmovaps [rsp+0x120], xmm15
00007d55df7d2a43  movaps xmm1, xmm13
00007d55df7d2a47  addpd xmm1, xmm2
00007d55df7d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007d55df7d2a50  ptest xmm15, xmm15
00007d55df7d2a56  jnz 0x00007D55DF7D43CF
00007d55df7d2a5c  lea rax, [r14+0xF0]
00007d55df7d2a63  movups xmm15, [r13+rax*1]
00007d55df7d2a69  vmovaps xmm2, [rsp+0xE0]
00007d55df7d2a72  vmovaps [rsp+0xE0], xmm1
00007d55df7d2a7b  vmovaps xmm1, [rsp+0xD0]
00007d55df7d2a84  vmovaps [rsp+0xD0], xmm15
00007d55df7d2a8d  movaps xmm13, xmm2
00007d55df7d2a91  addpd xmm13, xmm1
00007d55df7d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007d55df7d2a9c  ptest xmm15, xmm15
00007d55df7d2aa2  jnz 0x00007D55DF7D451A
00007d55df7d2aa8  vmovaps xmm15, [rsp+0xC0]
00007d55df7d2ab1  movaps xmm1, xmm14
00007d55df7d2ab5  addpd xmm1, xmm15
00007d55df7d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007d55df7d2abf  ptest xmm2, xmm2
00007d55df7d2ac4  jnz 0x00007D55DF7D465C
00007d55df7d2aca  vmovaps xmm15, [rsp+0x100]
00007d55df7d2ad3  vpermilpd xmm15, xmm15, 0x00
00007d55df7d2ad9  vmovaps xmm2, [rsp+0xF0]
00007d55df7d2ae2  vmovaps [rsp+0xC0], xmm1
00007d55df7d2aeb  movaps xmm14, xmm2
00007d55df7d2aef  mulpd xmm14, xmm15
00007d55df7d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007d55df7d2afa  ptest xmm1, xmm1
00007d55df7d2aff  jnz 0x00007D55DF7D479E
00007d55df7d2b05  vmovaps xmm1, [rsp+0xA0]
00007d55df7d2b0e  vpermilpd xmm1, xmm1, 0x00
00007d55df7d2b14  vmovaps xmm2, [rsp+0xD0]
00007d55df7d2b1d  vmovaps [rsp+0xD0], xmm14
00007d55df7d2b26  movaps xmm15, xmm2
00007d55df7d2b2a  mulpd xmm15, xmm1
00007d55df7d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007d55df7d2b35  ptest xmm14, xmm14
00007d55df7d2b3b  jnz 0x00007D55DF7D48E1
00007d55df7d2b41  lea rax, [r14+0xE0]
00007d55df7d2b48  movups xmm1, [r13+rax*1]
00007d55df7d2b4e  vmovaps xmm14, [rsp+0x100]
00007d55df7d2b57  vpermilpd xmm14, xmm14, 0x00
00007d55df7d2b5d  vmovaps [rsp+0xF0], xmm1
00007d55df7d2b66  vmovaps xmm1, [rsp+0x20]
00007d55df7d2b6c  vmovaps [rsp+0x20], xmm15
00007d55df7d2b72  movaps xmm2, xmm1
00007d55df7d2b75  mulpd xmm2, xmm14
00007d55df7d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007d55df7d2b7f  ptest xmm15, xmm15
00007d55df7d2b85  jnz 0x00007D55DF7D4A2D
00007d55df7d2b8b  vmovaps [rsp+0x100], xmm10
00007d55df7d2b94  vmovaps xmm1, [rsp+0x100]
00007d55df7d2b9d  por xmm10, xmm1
00007d55df7d2ba2  movaps [r15+0x300], xmm10
00007d55df7d2baa  vmovaps [rsp+0x100], xmm8
00007d55df7d2bb3  vmovaps xmm1, [rsp+0x100]
00007d55df7d2bbc  por xmm8, xmm1
00007d55df7d2bc1  movaps [r15+0x190], xmm8
00007d55df7d2bc9  vmovaps xmm1, [rsp+0xA0]
00007d55df7d2bd2  vpermilpd xmm1, xmm1, 0x00
00007d55df7d2bd8  vmovaps xmm14, [rsp+0xF0]
00007d55df7d2be1  vmovaps [rsp+0xF0], xmm13
00007d55df7d2bea  movaps xmm15, xmm14
00007d55df7d2bee  mulpd xmm15, xmm1
00007d55df7d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007d55df7d2bf9  ptest xmm13, xmm13
00007d55df7d2bff  jnz 0x00007D55DF7D4B6E
00007d55df7d2c05  lea rax, [r14+0x90]
00007d55df7d2c0c  movups xmm1, [r13+rax*1]
00007d55df7d2c12  vmovaps [rsp+0x100], xmm4
00007d55df7d2c1b  vmovaps xmm14, [rsp+0x100]
00007d55df7d2c24  por xmm4, xmm14
00007d55df7d2c29  movaps [r15+0x1C0], xmm4
00007d55df7d2c31  vmovaps [rsp+0x100], xmm11
00007d55df7d2c3a  vmovaps xmm14, [rsp+0x100]
00007d55df7d2c43  por xmm11, xmm14
00007d55df7d2c48  movaps [r15+0x200], xmm11
00007d55df7d2c50  vmovaps [rsp+0x100], xmm5
00007d55df7d2c59  vmovaps xmm14, [rsp+0x100]
00007d55df7d2c62  por xmm5, xmm14
00007d55df7d2c67  movaps [r15+0x2D0], xmm5
00007d55df7d2c6f  vmovaps xmm14, [rsp+0x120]
00007d55df7d2c78  vmovaps xmm13, [rsp+0x120]
00007d55df7d2c81  por xmm14, xmm13
00007d55df7d2c86  movaps [r15+0x2E0], xmm14
00007d55df7d2c8e  vmovaps [rsp+0x100], xmm1
00007d55df7d2c97  vmovaps xmm1, [rsp+0x110]
00007d55df7d2ca0  vmovaps [rsp+0x110], xmm15
00007d55df7d2ca9  vmovaps xmm15, [rsp+0xD0]
00007d55df7d2cb2  vmovaps [rsp+0xD0], xmm14
00007d55df7d2cbb  movaps xmm13, xmm1
00007d55df7d2cbf  addpd xmm13, xmm15
00007d55df7d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007d55df7d2cca  ptest xmm14, xmm14
00007d55df7d2cd0  jnz 0x00007D55DF7D4CBB
00007d55df7d2cd6  vmovaps xmm1, [rsp+0xA0]
00007d55df7d2cdf  vpermilpd xmm1, xmm1, 0x00
00007d55df7d2ce5  vmovaps xmm14, [rsp+0x100]
00007d55df7d2cee  vmovaps [rsp+0x100], xmm13
00007d55df7d2cf7  movaps xmm15, xmm14
00007d55df7d2cfb  mulpd xmm15, xmm1
00007d55df7d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007d55df7d2d06  ptest xmm13, xmm13
00007d55df7d2d0c  jnz 0x00007D55DF7D4DFE
00007d55df7d2d12  lea rax, [r14+0x80]
00007d55df7d2d19  movups xmm1, [r13+rax*1]
00007d55df7d2d1f  vmovaps xmm13, [rsp+0xE0]
00007d55df7d2d28  vmovaps [rsp+0xE0], xmm1
00007d55df7d2d31  movaps xmm14, xmm13
00007d55df7d2d35  addpd xmm14, xmm2
00007d55df7d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007d55df7d2d40  ptest xmm1, xmm1
00007d55df7d2d45  jnz 0x00007D55DF7D4F4B
00007d55df7d2d4b  vmovaps xmm13, [rsp+0xF0]
00007d55df7d2d54  vmovaps xmm2, [rsp+0x20]
00007d55df7d2d5a  vmovaps [rsp+0x20], xmm15
00007d55df7d2d60  movaps xmm1, xmm13
00007d55df7d2d64  addpd xmm1, xmm2
00007d55df7d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007d55df7d2d6d  ptest xmm15, xmm15
00007d55df7d2d73  jnz 0x00007D55DF7D508E
00007d55df7d2d79  vmovaps xmm15, [rsp+0x10]
00007d55df7d2d7f  vmovaps xmm13, [rsp+0x10]
00007d55df7d2d85  por xmm15, xmm13
00007d55df7d2d8a  movaps [r15+0x2F0], xmm15
00007d55df7d2d92  vmovaps xmm13, [rsp+0xA0]
00007d55df7d2d9b  vpermilpd xmm13, xmm13, 0x00
00007d55df7d2da1  vmovaps [rsp+0x10], xmm1
00007d55df7d2da7  vmovaps xmm1, [rsp+0xE0]
00007d55df7d2db0  vmovaps [rsp+0xA0], xmm15
00007d55df7d2db9  movaps xmm2, xmm1
00007d55df7d2dbc  mulpd xmm2, xmm13
00007d55df7d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007d55df7d2dc6  ptest xmm15, xmm15
00007d55df7d2dcc  jnz 0x00007D55DF7D51CF
00007d55df7d2dd2  lea rax, [r14+0xD0]
00007d55df7d2dd9  movups xmm1, [r13+rax*1]
00007d55df7d2ddf  vmovaps xmm13, [rsp+0xC0]
00007d55df7d2de8  vmovaps [rsp+0xC0], xmm1
00007d55df7d2df1  vmovaps xmm1, [rsp+0x110]
00007d55df7d2dfa  vmovaps [rsp+0xE0], xmm14
00007d55df7d2e03  movaps xmm15, xmm13
00007d55df7d2e07  addpd xmm15, xmm1
00007d55df7d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007d55df7d2e12  ptest xmm14, xmm14
00007d55df7d2e18  jnz 0x00007D55DF7D531A
00007d55df7d2e1e  vmovaps xmm1, [rsp+0xB0]
00007d55df7d2e27  vpermilpd xmm1, xmm1, 0x00
00007d55df7d2e2d  movaps xmm14, xmm11
00007d55df7d2e31  mulpd xmm14, xmm1
00007d55df7d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007d55df7d2e3c  ptest xmm13, xmm13
00007d55df7d2e42  jnz 0x00007D55DF7D545D
00007d55df7d2e48  movaps [r15+0x260], xmm14
00007d55df7d2e50  vxorps xmm1, xmm1, xmm1
00007d55df7d2e54  vpbroadcastq xmm1, xmm1
00007d55df7d2e59  movaps [r15+0x1B0], xmm1
00007d55df7d2e61  vmovaps xmm1, [rsp+0xB0]
00007d55df7d2e6a  vpermilpd xmm1, xmm1, 0x00
00007d55df7d2e70  vmovaps xmm11, [rsp+0xC0]
00007d55df7d2e79  vmovaps [rsp+0xC0], xmm15
00007d55df7d2e82  movaps xmm13, xmm11
00007d55df7d2e86  mulpd xmm13, xmm1
00007d55df7d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007d55df7d2e91  ptest xmm15, xmm15
00007d55df7d2e97  jnz 0x00007D55DF7D55A0
00007d55df7d2e9d  lea rax, [r14+0xC0]
00007d55df7d2ea4  movups xmm1, [r13+rax*1]
00007d55df7d2eaa  vmovaps xmm11, [rsp+0x100]
00007d55df7d2eb3  vmovaps [rsp+0xF0], xmm1
00007d55df7d2ebc  vmovaps xmm1, [rsp+0x20]
00007d55df7d2ec2  vmovaps [rsp+0x20], xmm14
00007d55df7d2ec8  movaps xmm15, xmm11
00007d55df7d2ecc  addpd xmm15, xmm1
00007d55df7d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007d55df7d2ed7  ptest xmm14, xmm14
00007d55df7d2edd  jnz 0x00007D55DF7D56ED
00007d55df7d2ee3  vmovaps [rsp+0x100], xmm9
00007d55df7d2eec  vmovaps xmm1, [rsp+0x100]
00007d55df7d2ef5  por xmm9, xmm1
00007d55df7d2efa  movaps [r15+0x270], xmm9
00007d55df7d2f02  vmovaps [rsp+0x100], xmm6
00007d55df7d2f0b  vmovaps xmm1, [rsp+0x100]
00007d55df7d2f14  por xmm6, xmm1
00007d55df7d2f18  movaps [r15+0x1A0], xmm6
00007d55df7d2f20  vmovaps xmm14, [rsp+0xB0]
00007d55df7d2f29  vpermilpd xmm14, xmm14, 0x00
00007d55df7d2f2f  vmovaps xmm6, [rsp+0xF0]
00007d55df7d2f38  vmovaps [rsp+0xF0], xmm1
00007d55df7d2f41  movaps xmm11, xmm6
00007d55df7d2f45  mulpd xmm11, xmm14
00007d55df7d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007d55df7d2f50  ptest xmm1, xmm1
00007d55df7d2f55  jnz 0x00007D55DF7D5830
00007d55df7d2f5b  lea rax, [r14+0x20]
00007d55df7d2f5f  movups xmm1, [r13+rax*1]
00007d55df7d2f65  movaps [r15+0x110], xmm1
00007d55df7d2f6d  vmovaps xmm6, [rsp+0xE0]
00007d55df7d2f76  vmovaps [rsp+0xE0], xmm1
00007d55df7d2f7f  movaps xmm14, xmm6
00007d55df7d2f83  addpd xmm14, xmm2
00007d55df7d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007d55df7d2f8e  ptest xmm1, xmm1
00007d55df7d2f93  jnz 0x00007D55DF7D597D
00007d55df7d2f99  vmovaps xmm1, [rsp+0xB0]
00007d55df7d2fa2  vpermilpd xmm1, xmm1, 0x00
00007d55df7d2fa8  movaps xmm6, xmm5
00007d55df7d2fab  mulpd xmm6, xmm1
00007d55df7d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007d55df7d2fb4  ptest xmm2, xmm2
00007d55df7d2fb9  jnz 0x00007D55DF7D5ABF
00007d55df7d2fbf  vmovaps xmm5, [rsp+0x10]
00007d55df7d2fc5  movaps xmm1, xmm5
00007d55df7d2fc8  addpd xmm1, xmm13
00007d55df7d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007d55df7d2fd2  ptest xmm2, xmm2
00007d55df7d2fd7  jnz 0x00007D55DF7D5BFF
00007d55df7d2fdd  vmovaps xmm13, [rsp+0x80]
00007d55df7d2fe6  vpermilpd xmm13, xmm13, 0x00
00007d55df7d2fec  vmovaps xmm2, [rsp+0xE0]
00007d55df7d2ff5  vmovaps [rsp+0x10], xmm1
00007d55df7d2ffb  movaps xmm5, xmm2
00007d55df7d2ffe  mulpd xmm5, xmm13
00007d55df7d3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007d55df7d3008  ptest xmm1, xmm1
00007d55df7d300d  jnz 0x00007D55DF7D5D40
00007d55df7d3013  vmovaps xmm1, [rsp+0x80]
00007d55df7d301c  vpermilpd xmm1, xmm1, 0x00
00007d55df7d3022  movaps xmm13, xmm10
00007d55df7d3026  mulpd xmm13, xmm1
00007d55df7d302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007d55df7d3031  ptest xmm2, xmm2
00007d55df7d3036  jnz 0x00007D55DF7D5E81
00007d55df7d303c  vmovaps xmm10, [rsp+0x20]
00007d55df7d3042  movaps xmm1, xmm15
00007d55df7d3046  addpd xmm1, xmm10
00007d55df7d304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d55df7d3050  ptest xmm2, xmm2
00007d55df7d3055  jnz 0x00007D55DF7D5FC4
00007d55df7d305b  vmovaps xmm10, [rsp+0xC0]
00007d55df7d3064  movaps xmm15, xmm10
00007d55df7d3068  addpd xmm15, xmm11
00007d55df7d306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007d55df7d3073  ptest xmm2, xmm2
00007d55df7d3078  jnz 0x00007D55DF7D6106
00007d55df7d307e  vmovaps xmm11, [rsp+0x80]
00007d55df7d3087  vpermilpd xmm11, xmm11, 0x00
00007d55df7d308d  vmovaps xmm2, [rsp+0xD0]
00007d55df7d3096  vmovaps [rsp+0x20], xmm1
00007d55df7d309c  movaps xmm10, xmm2
00007d55df7d30a0  mulpd xmm10, xmm11
00007d55df7d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007d55df7d30ab  ptest xmm1, xmm1
00007d55df7d30b0  jnz 0x00007D55DF7D624A
00007d55df7d30b6  vmovaps xmm1, [rsp+0x80]
00007d55df7d30bf  vpermilpd xmm1, xmm1, 0x00
00007d55df7d30c5  vmovaps xmm2, [rsp+0xA0]
00007d55df7d30ce  vmovaps [rsp+0x80], xmm15
00007d55df7d30d7  movaps xmm11, xmm2
00007d55df7d30db  mulpd xmm11, xmm1
00007d55df7d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007d55df7d30e6  ptest xmm15, xmm15
00007d55df7d30ec  jnz 0x00007D55DF7D638D
00007d55df7d30f2  movaps xmm1, xmm14
00007d55df7d30f6  addpd xmm1, xmm6
00007d55df7d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007d55df7d30ff  ptest xmm15, xmm15
00007d55df7d3105  jnz 0x00007D55DF7D64CF
00007d55df7d310b  vmovaps xmm14, [rsp+0x10]
00007d55df7d3111  movaps xmm15, xmm14
00007d55df7d3115  addpd xmm15, xmm5
00007d55df7d311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007d55df7d3120  ptest xmm6, xmm6
00007d55df7d3125  jnz 0x00007D55DF7D6610
00007d55df7d312b  vmovaps xmm14, [rsp+0x90]
00007d55df7d3134  vpermilpd xmm14, xmm14, 0x00
00007d55df7d313a  movaps xmm6, xmm9
00007d55df7d313e  mulpd xmm6, xmm14
00007d55df7d3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007d55df7d3148  ptest xmm5, xmm5
00007d55df7d314d  jnz 0x00007D55DF7D6753
00007d55df7d3153  vmovaps xmm9, [rsp+0x80]
00007d55df7d315c  movaps xmm14, xmm9
00007d55df7d3160  addpd xmm14, xmm13
00007d55df7d3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007d55df7d316b  ptest xmm5, xmm5
00007d55df7d3170  jnz 0x00007D55DF7D6895
00007d55df7d3176  vmovaps xmm9, [rsp+0x20]
00007d55df7d317c  movaps xmm13, xmm9
00007d55df7d3180  addpd xmm13, xmm10
00007d55df7d3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007d55df7d318b  ptest xmm5, xmm5
00007d55df7d3190  jnz 0x00007D55DF7D69D9
00007d55df7d3196  vmovaps [rsp+0x10], xmm12
00007d55df7d319c  vmovaps xmm10, [rsp+0x10]
00007d55df7d31a2  por xmm12, xmm10
00007d55df7d31a7  movaps [r15+0x250], xmm12
00007d55df7d31af  vmovaps [rsp+0x10], xmm7
00007d55df7d31b5  vmovaps xmm12, [rsp+0x10]
00007d55df7d31bb  por xmm7, xmm12
00007d55df7d31c0  movaps [r15+0x2A0], xmm7
00007d55df7d31c8  vmovaps [rsp+0x10], xmm3
00007d55df7d31ce  vmovaps xmm12, [rsp+0x10]
00007d55df7d31d4  por xmm3, xmm12
00007d55df7d31d9  movaps [r15+0x1D0], xmm3
00007d55df7d31e1  lea rax, [r14+0x40]
00007d55df7d31e5  movups xmm12, [r13+rax*1]
00007d55df7d31eb  movaps [r15+0x2C0], xmm12
00007d55df7d31f3  vmovaps xmm10, [rsp+0x90]
00007d55df7d31fc  vpermilpd xmm10, xmm10, 0x00
00007d55df7d3202  movaps xmm9, xmm8
00007d55df7d3206  mulpd xmm9, xmm10
00007d55df7d320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007d55df7d3211  ptest xmm5, xmm5
00007d55df7d3216  jnz 0x00007D55DF7D6B27
00007d55df7d321c  movaps xmm10, xmm1
00007d55df7d3220  addpd xmm10, xmm11
00007d55df7d3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007d55df7d322b  ptest xmm8, xmm8
00007d55df7d3231  jnz 0x00007D55DF7D6C6B
00007d55df7d3237  movaps xmm1, xmm15
00007d55df7d323b  addpd xmm1, xmm6
00007d55df7d323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007d55df7d3244  ptest xmm11, xmm11
00007d55df7d324a  jnz 0x00007D55DF7D6DAE
00007d55df7d3250  vmovaps xmm15, [rsp+0x90]
00007d55df7d3259  vpermilpd xmm15, xmm15, 0x00
00007d55df7d325f  movaps xmm11, xmm12
00007d55df7d3263  mulpd xmm11, xmm15
00007d55df7d3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007d55df7d326e  ptest xmm8, xmm8
00007d55df7d3274  jnz 0x00007D55DF7D6EEF
00007d55df7d327a  vmovaps xmm15, [rsp+0x90]
00007d55df7d3283  vpermilpd xmm15, xmm15, 0x00
00007d55df7d3289  vmovaps xmm8, [rsp+0x50]
00007d55df7d328f  movaps xmm12, xmm8
00007d55df7d3293  mulpd xmm12, xmm15
00007d55df7d3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007d55df7d329e  ptest xmm6, xmm6
00007d55df7d32a3  jnz 0x00007D55DF7D7033
00007d55df7d32a9  vmovaps xmm15, [rsp+0x30]
00007d55df7d32af  vpermilpd xmm15, xmm15, 0x00
00007d55df7d32b5  movaps xmm8, xmm7
00007d55df7d32b9  mulpd xmm8, xmm15
00007d55df7d32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007d55df7d32c4  ptest xmm6, xmm6
00007d55df7d32c9  jnz 0x00007D55DF7D7177
00007d55df7d32cf  movaps xmm15, xmm14
00007d55df7d32d3  addpd xmm15, xmm9
00007d55df7d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007d55df7d32de  ptest xmm7, xmm7
00007d55df7d32e3  jnz 0x00007D55DF7D72BA
00007d55df7d32e9  vmovaps xmm14, [rsp+0x30]
00007d55df7d32ef  vpermilpd xmm14, xmm14, 0x00
00007d55df7d32f5  vmovaps xmm7, [rsp+0xF0]
00007d55df7d32fe  movaps xmm9, xmm7
00007d55df7d3302  mulpd xmm9, xmm14
00007d55df7d3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007d55df7d330d  ptest xmm6, xmm6
00007d55df7d3312  jnz 0x00007D55DF7D73FE
00007d55df7d3318  movaps xmm14, xmm13
00007d55df7d331c  addpd xmm14, xmm11
00007d55df7d3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007d55df7d3327  ptest xmm7, xmm7
00007d55df7d332c  jnz 0x00007D55DF7D7541
00007d55df7d3332  vmovaps xmm13, [rsp+0x30]
00007d55df7d3338  vpermilpd xmm13, xmm13, 0x00
00007d55df7d333e  vmovaps xmm7, [rsp+0x60]
00007d55df7d3344  movaps xmm11, xmm7
00007d55df7d3348  mulpd xmm11, xmm13
00007d55df7d334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007d55df7d3353  ptest xmm6, xmm6
00007d55df7d3358  jnz 0x00007D55DF7D7685
00007d55df7d335e  movaps xmm13, xmm10
00007d55df7d3362  addpd xmm13, xmm12
00007d55df7d3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007d55df7d336d  ptest xmm7, xmm7
00007d55df7d3372  jnz 0x00007D55DF7D77C8
00007d55df7d3378  vmovaps xmm12, [rsp+0x30]
00007d55df7d337e  vpermilpd xmm12, xmm12, 0x00
00007d55df7d3384  vmovaps xmm7, [rsp+0x70]
00007d55df7d338a  movaps xmm10, xmm7
00007d55df7d338e  mulpd xmm10, xmm12
00007d55df7d3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007d55df7d3399  ptest xmm6, xmm6
00007d55df7d339e  jnz 0x00007D55DF7D790C
00007d55df7d33a4  movaps xmm12, xmm1
00007d55df7d33a8  addpd xmm12, xmm8
00007d55df7d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007d55df7d33b3  ptest xmm7, xmm7
00007d55df7d33b8  jnz 0x00007D55DF7D7A4F
00007d55df7d33be  lea rax, [r14+0x70]
00007d55df7d33c2  movups xmm1, [r13+rax*1]
00007d55df7d33c8  movaps [r15+0x240], xmm1
00007d55df7d33d0  movaps xmm8, xmm15
00007d55df7d33d4  addpd xmm8, xmm9
00007d55df7d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007d55df7d33df  ptest xmm7, xmm7
00007d55df7d33e4  jnz 0x00007D55DF7D7B9C
00007d55df7d33ea  movaps [r15+0x170], xmm8
00007d55df7d33f2  vmovaps xmm15, [rsp+0x40]
00007d55df7d33f8  vpermilpd xmm15, xmm15, 0x00
00007d55df7d33fe  movaps xmm9, xmm1
00007d55df7d3402  mulpd xmm9, xmm15
00007d55df7d3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007d55df7d340d  ptest xmm7, xmm7
00007d55df7d3412  jnz 0x00007D55DF7D7CE0
00007d55df7d3418  vmovaps xmm1, [rsp+0x40]
00007d55df7d341e  vpermilpd xmm1, xmm1, 0x00
00007d55df7d3424  movaps xmm15, xmm4
00007d55df7d3428  mulpd xmm15, xmm1
00007d55df7d342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007d55df7d3433  ptest xmm7, xmm7
00007d55df7d3438  jnz 0x00007D55DF7D7E23
00007d55df7d343e  movaps [r15+0x180], xmm15
00007d55df7d3446  movaps xmm1, xmm14
00007d55df7d344a  addpd xmm1, xmm11
00007d55df7d344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007d55df7d3454  ptest xmm7, xmm7
00007d55df7d3459  jnz 0x00007D55DF7D7F65
00007d55df7d345f  movaps [r15+0x210], xmm1
00007d55df7d3467  movups xmm14, [r13+r14*1]
00007d55df7d346d  lea rax, [r14+0x10]
00007d55df7d3471  movups xmm11, [r13+rax*1]
00007d55df7d3477  movaps [r15+0x230], xmm11
00007d55df7d347f  movaps xmm7, xmm13
00007d55df7d3483  addpd xmm7, xmm10
00007d55df7d3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007d55df7d348d  ptest xmm6, xmm6
00007d55df7d3492  jnz 0x00007D55DF7D80BB
00007d55df7d3498  movaps [r15+0x130], xmm7
00007d55df7d34a0  vmovaps xmm13, [rsp+0x40]
00007d55df7d34a6  vpermilpd xmm13, xmm13, 0x00
00007d55df7d34ac  movaps xmm10, xmm11
00007d55df7d34b0  mulpd xmm10, xmm13
00007d55df7d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d55df7d34bb  ptest xmm6, xmm6
00007d55df7d34c0  jnz 0x00007D55DF7D81FD
00007d55df7d34c6  movaps [r15+0x220], xmm10
00007d55df7d34ce  vmovaps xmm13, [rsp+0x40]
00007d55df7d34d4  vpermilpd xmm13, xmm13, 0x00
00007d55df7d34da  movaps xmm11, xmm14
00007d55df7d34de  mulpd xmm11, xmm13
00007d55df7d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007d55df7d34e9  ptest xmm6, xmm6
00007d55df7d34ee  jnz 0x00007D55DF7D8341
00007d55df7d34f4  movaps xmm14, xmm12
00007d55df7d34f8  addpd xmm14, xmm9
00007d55df7d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007d55df7d3503  ptest xmm13, xmm13
00007d55df7d3509  jnz 0x00007D55DF7D8485
00007d55df7d350f  movaps [r15+0x140], xmm14
00007d55df7d3517  movaps xmm13, xmm8
00007d55df7d351b  addpd xmm13, xmm15
00007d55df7d3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007d55df7d3526  ptest xmm12, xmm12
00007d55df7d352c  jnz 0x00007D55DF7D85C9
00007d55df7d3532  movaps [r15+0x150], xmm13
00007d55df7d353a  movaps xmm15, xmm1
00007d55df7d353e  addpd xmm15, xmm10
00007d55df7d3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007d55df7d3549  ptest xmm12, xmm12
00007d55df7d354f  jnz 0x00007D55DF7D870D
00007d55df7d3555  movaps [r15+0x160], xmm15
00007d55df7d355d  movaps xmm1, xmm7
00007d55df7d3560  addpd xmm1, xmm11
00007d55df7d3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007d55df7d356a  ptest xmm12, xmm12
00007d55df7d3570  jnz 0x00007D55DF7D8850
00007d55df7d3576  movaps [r15+0x120], xmm1
00007d55df7d357e  mov eax, 0x432200
00007d55df7d3583  movups [r13+rax*1], xmm14
00007d55df7d3589  mov eax, 0x432210
00007d55df7d358e  movups [r13+rax*1], xmm13
00007d55df7d3594  mov eax, 0x432220
00007d55df7d3599  movups [r13+rax*1], xmm15
00007d55df7d359f  mov eax, 0x432230
00007d55df7d35a4  movups [r13+rax*1], xmm1
00007d55df7d35aa  mov eax, [r15+0x108]
00007d55df7d35b1  sahf
00007d55df7d35b2  jnz 0x00007D55DF7D35E4
00007d55df7d35b4  cmp dword ptr [r15+0x318], 0x00
00007d55df7d35bc  jz 0x00007D55DF7DEAE0
00007d55df7d35c2  nop [rax+rax*1], ax
00007d55df7d35cb  nop [rax+rax*1], eax
00007d55df7d35d3  mov eax, 0x4106D0
00007d55df7d35d8  mov [r15+0x100], rax
00007d55df7d35df  jmp 0x00007D55DF5FE110
00007d55df7d35e4  cmp dword ptr [r15+0x318], 0x00
00007d55df7d35ec  jz 0x00007D55DF7D89C0
00007d55df7d35f2  nop [rax+rax*1], ax
00007d55df7d35fb  nop [rax+rax*1], eax
00007d55df7d3603  mov eax, 0x410504
00007d55df7d3608  mov [r15+0x100], rax
00007d55df7d360f  jmp 0x00007D55DF5FE110
00007d55df7d3614  int3
00007d55df7d3615  call 0x00007D55DF6D64F0
00007d55df7d361a  jmp 0x00007D55DF7D2311
00007d55df7d361f  call 0x00007D55DF6E5820
00007d55df7d3624  jmp 0x00007D55DF7D231E
00007d55df7d3629  call 0x00007D55DF6E3320
00007d55df7d362e  jmp 0x00007D55DF7D2332
00007d55df7d3633  call 0x00007D55DF6E20A0
00007d55df7d3638  jmp 0x00007D55DF7D233C
00007d55df7d363d  call 0x00007D55DF609D70
00007d55df7d3642  jmp 0x00007D55DF7D234A
00007d55df7d3647  call 0x00007D55DF6DFBC0
00007d55df7d364c  jmp 0x00007D55DF7D2354
00007d55df7d3651  call 0x00007D55DF6C4740
00007d55df7d3656  jmp 0x00007D55DF7D2368
00007d55df7d365b  call 0x00007D55DF6B5400
00007d55df7d3660  jmp 0x00007D55DF7D2375
00007d55df7d3665  call 0x00007D55DF6B52F0
00007d55df7d366a  jmp 0x00007D55DF7D2382
00007d55df7d366f  call 0x00007D55DF6C4620
00007d55df7d3674  jmp 0x00007D55DF7D238F
00007d55df7d3679  call 0x00007D55DF6BD750
00007d55df7d367e  jmp 0x00007D55DF7D239C
00007d55df7d3683  call 0x00007D55DF6BC4E0
00007d55df7d3688  jmp 0x00007D55DF7D23A9
00007d55df7d368d  call 0x00007D55DF6BB270
00007d55df7d3692  jmp 0x00007D55DF7D23B6
00007d55df7d3697  call 0x00007D55DF6BA000
00007d55df7d369c  jmp 0x00007D55DF7D23C3
00007d55df7d36a1  call 0x00007D55DF6C4740
00007d55df7d36a6  jmp 0x00007D55DF7D23D0
00007d55df7d36ab  call 0x00007D55DF6B5400
00007d55df7d36b0  jmp 0x00007D55DF7D23DD
00007d55df7d36b5  call 0x00007D55DF6B52F0
00007d55df7d36ba  jmp 0x00007D55DF7D23EA
00007d55df7d36bf  call 0x00007D55DF6C4620
00007d55df7d36c4  jmp 0x00007D55DF7D23F7
00007d55df7d36c9  call 0x00007D55DF6B8D90
00007d55df7d36ce  jmp 0x00007D55DF7D2404
00007d55df7d36d3  call 0x00007D55DF6B8A20
00007d55df7d36d8  jmp 0x00007D55DF7D2411
00007d55df7d36dd  call 0x00007D55DF6B77B0
00007d55df7d36e2  jmp 0x00007D55DF7D241B
00007d55df7d36e7  call 0x00007D55DF6B6550
00007d55df7d36ec  jmp 0x00007D55DF7D2425
00007d55df7d36f1  call 0x00007D55DF6B5400
00007d55df7d36f6  jmp 0x00007D55DF7D2437
00007d55df7d36fb  call 0x00007D55DF6C0FC0
00007d55df7d3700  jmp 0x00007D55DF7D2441
00007d55df7d3705  call 0x00007D55DF6B52F0
00007d55df7d370a  jmp 0x00007D55DF7D244B
00007d55df7d370f  call 0x00007D55DF6C0EA0
00007d55df7d3714  jmp 0x00007D55DF7D2455
00007d55df7d3719  call 0x00007D55DF6BFD50
00007d55df7d371e  jmp 0x00007D55DF7D245F
00007d55df7d3723  call 0x00007D55DF6B8EA0
00007d55df7d3728  jmp 0x00007D55DF7D2469
00007d55df7d372d  call 0x00007D55DF6BFC30
00007d55df7d3732  jmp 0x00007D55DF7D2476
00007d55df7d3737  call 0x00007D55DF6B8D90
00007d55df7d373c  jmp 0x00007D55DF7D2483
00007d55df7d3741  call 0x00007D55DF6B52F0
00007d55df7d3746  jmp 0x00007D55DF7D2496
00007d55df7d374b  call 0x00007D55DF6B52F0
00007d55df7d3750  jmp 0x00007D55DF7D24A9
00007d55df7d3755  call 0x00007D55DF6C0FC0
00007d55df7d375a  jmp 0x00007D55DF7D24B6
00007d55df7d375f  call 0x00007D55DF6C0FC0
00007d55df7d3764  jmp 0x00007D55DF7D24C9
00007d55df7d3769  call 0x00007D55DF6C0EA0
00007d55df7d376e  jmp 0x00007D55DF7D24D6
00007d55df7d3773  call 0x00007D55DF6B52F0
00007d55df7d3778  jmp 0x00007D55DF7D24E9
00007d55df7d377d  call 0x00007D55DF6B52F0
00007d55df7d3782  jmp 0x00007D55DF7D24FC
00007d55df7d3787  call 0x00007D55DF6B52F0
00007d55df7d378c  jmp 0x00007D55DF7D250F
00007d55df7d3791  call 0x00007D55DF6B52F0
00007d55df7d3796  jmp 0x00007D55DF7D252A
00007d55df7d379b  call 0x00007D55DF6B52F0
00007d55df7d37a0  jmp 0x00007D55DF7D253D
00007d55df7d37a5  call 0x00007D55DF6B5400
00007d55df7d37aa  jmp 0x00007D55DF7D257E
00007d55df7d37af  call 0x00007D55DF6C0FC0
00007d55df7d37b4  jmp 0x00007D55DF7D258B
00007d55df7d37b9  call 0x00007D55DF6B52F0
00007d55df7d37be  jmp 0x00007D55DF7D2598
00007d55df7d37c3  call 0x00007D55DF6C0EA0
00007d55df7d37c8  jmp 0x00007D55DF7D25A5
00007d55df7d37cd  call 0x00007D55DF5FF540
00007d55df7d37d2  jmp 0x00007D55DF7D25C3
00007d55df7d37d7  call 0x00007D55DF608C20
00007d55df7d37dc  jmp 0x00007D55DF7D25CD
00007d55df7d37e1  call 0x00007D55DF6E21C0
00007d55df7d37e6  jmp 0x00007D55DF7D25D3
00007d55df7d37eb  call 0x00007D55DF5FF540
00007d55df7d37f0  jmp 0x00007D55DF7D25E3
00007d55df7d37f5  call 0x00007D55DF6C0370
00007d55df7d37fa  jmp 0x00007D55DF7D2611
00007d55df7d37ff  call 0x00007D55DF6BF100
00007d55df7d3804  jmp 0x00007D55DF7D261A
00007d55df7d3809  call 0x00007D55DF6C0370
00007d55df7d380e  jmp 0x00007D55DF7D2674
00007d55df7d3813  call 0x00007D55DF6BF100
00007d55df7d3818  jmp 0x00007D55DF7D267D
00007d55df7d381d  call 0x00007D55DF6C0370
00007d55df7d3822  jmp 0x00007D55DF7D26C6
00007d55df7d3827  call 0x00007D55DF6BF100
00007d55df7d382c  jmp 0x00007D55DF7D26CF
00007d55df7d3831  call 0x00007D55DF60B720
00007d55df7d3836  jmp 0x00007D55DF7D2714
00007d55df7d383b  call 0x00007D55DF6B47C0
00007d55df7d3840  jmp 0x00007D55DF7D2727
00007d55df7d3845  call 0x00007D55DF608B00
00007d55df7d384a  jmp 0x00007D55DF7D273E
00007d55df7d384f  call 0x00007D55DF5FF430
00007d55df7d3854  jmp 0x00007D55DF7D2751
00007d55df7d3859  call 0x00007D55DF5FF430
00007d55df7d385e  jmp 0x00007D55DF7D2764
00007d55df7d3863  sub rsp, 0x08
00007d55df7d3867  push rax
00007d55df7d3868  push rcx
00007d55df7d3869  push rdx
00007d55df7d386a  push rdi
00007d55df7d386b  push rsi
00007d55df7d386c  push r8
00007d55df7d386e  push r9
00007d55df7d3870  push r10
00007d55df7d3872  push r11
00007d55df7d3874  sub rsp, 0xF0
00007d55df7d387b  vmovaps [rsp], xmm0
00007d55df7d3880  vmovaps [rsp+0x10], xmm2
00007d55df7d3886  vmovaps [rsp+0x20], xmm3
00007d55df7d388c  vmovaps [rsp+0x30], xmm4
00007d55df7d3892  vmovaps [rsp+0x40], xmm5
00007d55df7d3898  vmovaps [rsp+0x50], xmm6
00007d55df7d389e  vmovaps [rsp+0x60], xmm7
00007d55df7d38a4  vmovaps [rsp+0x70], xmm8
00007d55df7d38aa  vmovaps [rsp+0x80], xmm9
00007d55df7d38b3  vmovaps [rsp+0x90], xmm10
00007d55df7d38bc  vmovaps [rsp+0xA0], xmm11
00007d55df7d38c5  vmovaps [rsp+0xB0], xmm12
00007d55df7d38ce  vmovaps [rsp+0xC0], xmm13
00007d55df7d38d7  vmovaps [rsp+0xD0], xmm14
00007d55df7d38e0  vmovaps [rsp+0xE0], xmm15
00007d55df7d38e9  sub rsp, 0x30
00007d55df7d38ed  movaps [rsp], xmm1
00007d55df7d38f1  movaps [rsp+0x10], xmm12
00007d55df7d38f7  movaps [rsp+0x20], xmm15
00007d55df7d38fd  lea rdi, [rsp]
00007d55df7d3901  mov esi, 0x00
00007d55df7d3906  mov rax, 0x5BB8433D8530
00007d55df7d3910  call rax
00007d55df7d3912  movaps xmm1, [rsp]
00007d55df7d3916  add rsp, 0x30
00007d55df7d391a  vmovaps xmm0, [rsp]
00007d55df7d391f  vmovaps xmm2, [rsp+0x10]
00007d55df7d3925  vmovaps xmm3, [rsp+0x20]
00007d55df7d392b  vmovaps xmm4, [rsp+0x30]
00007d55df7d3931  vmovaps xmm5, [rsp+0x40]
00007d55df7d3937  vmovaps xmm6, [rsp+0x50]
00007d55df7d393d  vmovaps xmm7, [rsp+0x60]
00007d55df7d3943  vmovaps xmm8, [rsp+0x70]
00007d55df7d3949  vmovaps xmm9, [rsp+0x80]
00007d55df7d3952  vmovaps xmm10, [rsp+0x90]
00007d55df7d395b  vmovaps xmm11, [rsp+0xA0]
00007d55df7d3964  vmovaps xmm12, [rsp+0xB0]
00007d55df7d396d  vmovaps xmm13, [rsp+0xC0]
00007d55df7d3976  vmovaps xmm14, [rsp+0xD0]
00007d55df7d397f  vmovaps xmm15, [rsp+0xE0]
00007d55df7d3988  add rsp, 0xF0
00007d55df7d398f  pop r11
00007d55df7d3991  pop r10
00007d55df7d3993  pop r9
00007d55df7d3995  pop r8
00007d55df7d3997  pop rsi
00007d55df7d3998  pop rdi
00007d55df7d3999  pop rdx
00007d55df7d399a  pop rcx
00007d55df7d399b  pop rax
00007d55df7d399c  add rsp, 0x08
00007d55df7d39a0  jmp 0x00007D55DF7D27B2
00007d55df7d39a5  sub rsp, 0x08
00007d55df7d39a9  push rax
00007d55df7d39aa  push rcx
00007d55df7d39ab  push rdx
00007d55df7d39ac  push rdi
00007d55df7d39ad  push rsi
00007d55df7d39ae  push r8
00007d55df7d39b0  push r9
00007d55df7d39b2  push r10
00007d55df7d39b4  push r11
00007d55df7d39b6  sub rsp, 0xF0
00007d55df7d39bd  vmovaps [rsp], xmm0
00007d55df7d39c2  vmovaps [rsp+0x10], xmm1
00007d55df7d39c8  vmovaps [rsp+0x20], xmm2
00007d55df7d39ce  vmovaps [rsp+0x30], xmm3
00007d55df7d39d4  vmovaps [rsp+0x40], xmm4
00007d55df7d39da  vmovaps [rsp+0x50], xmm5
00007d55df7d39e0  vmovaps [rsp+0x60], xmm6
00007d55df7d39e6  vmovaps [rsp+0x70], xmm7
00007d55df7d39ec  vmovaps [rsp+0x80], xmm8
00007d55df7d39f5  vmovaps [rsp+0x90], xmm9
00007d55df7d39fe  vmovaps [rsp+0xA0], xmm10
00007d55df7d3a07  vmovaps [rsp+0xB0], xmm11
00007d55df7d3a10  vmovaps [rsp+0xC0], xmm12
00007d55df7d3a19  vmovaps [rsp+0xD0], xmm13
00007d55df7d3a22  vmovaps [rsp+0xE0], xmm15
00007d55df7d3a2b  sub rsp, 0x30
00007d55df7d3a2f  movaps [rsp], xmm14
00007d55df7d3a34  movaps [rsp+0x10], xmm1
00007d55df7d3a39  movaps [rsp+0x20], xmm15
00007d55df7d3a3f  lea rdi, [rsp]
00007d55df7d3a43  mov esi, 0x00
00007d55df7d3a48  mov rax, 0x5BB8433D8530
00007d55df7d3a52  call rax
00007d55df7d3a54  movaps xmm14, [rsp]
00007d55df7d3a59  add rsp, 0x30
00007d55df7d3a5d  vmovaps xmm0, [rsp]
00007d55df7d3a62  vmovaps xmm1, [rsp+0x10]
00007d55df7d3a68  vmovaps xmm2, [rsp+0x20]
00007d55df7d3a6e  vmovaps xmm3, [rsp+0x30]
00007d55df7d3a74  vmovaps xmm4, [rsp+0x40]
00007d55df7d3a7a  vmovaps xmm5, [rsp+0x50]
00007d55df7d3a80  vmovaps xmm6, [rsp+0x60]
00007d55df7d3a86  vmovaps xmm7, [rsp+0x70]
00007d55df7d3a8c  vmovaps xmm8, [rsp+0x80]
00007d55df7d3a95  vmovaps xmm9, [rsp+0x90]
00007d55df7d3a9e  vmovaps xmm10, [rsp+0xA0]
00007d55df7d3aa7  vmovaps xmm11, [rsp+0xB0]
00007d55df7d3ab0  vmovaps xmm12, [rsp+0xC0]
00007d55df7d3ab9  vmovaps xmm13, [rsp+0xD0]
00007d55df7d3ac2  vmovaps xmm15, [rsp+0xE0]
00007d55df7d3acb  add rsp, 0xF0
00007d55df7d3ad2  pop r11
00007d55df7d3ad4  pop r10
00007d55df7d3ad6  pop r9
00007d55df7d3ad8  pop r8
00007d55df7d3ada  pop rsi
00007d55df7d3adb  pop rdi
00007d55df7d3adc  pop rdx
00007d55df7d3add  pop rcx
00007d55df7d3ade  pop rax
00007d55df7d3adf  add rsp, 0x08
00007d55df7d3ae3  jmp 0x00007D55DF7D2800
00007d55df7d3ae8  sub rsp, 0x08
00007d55df7d3aec  push rax
00007d55df7d3aed  push rcx
00007d55df7d3aee  push rdx
00007d55df7d3aef  push rdi
00007d55df7d3af0  push rsi
00007d55df7d3af1  push r8
00007d55df7d3af3  push r9
00007d55df7d3af5  push r10
00007d55df7d3af7  push r11
00007d55df7d3af9  sub rsp, 0xF0
00007d55df7d3b00  vmovaps [rsp], xmm0
00007d55df7d3b05  vmovaps [rsp+0x10], xmm1
00007d55df7d3b0b  vmovaps [rsp+0x20], xmm2
00007d55df7d3b11  vmovaps [rsp+0x30], xmm3
00007d55df7d3b17  vmovaps [rsp+0x40], xmm4
00007d55df7d3b1d  vmovaps [rsp+0x50], xmm5
00007d55df7d3b23  vmovaps [rsp+0x60], xmm6
00007d55df7d3b29  vmovaps [rsp+0x70], xmm7
00007d55df7d3b2f  vmovaps [rsp+0x80], xmm8
00007d55df7d3b38  vmovaps [rsp+0x90], xmm9
00007d55df7d3b41  vmovaps [rsp+0xA0], xmm10
00007d55df7d3b4a  vmovaps [rsp+0xB0], xmm11
00007d55df7d3b53  vmovaps [rsp+0xC0], xmm12
00007d55df7d3b5c  vmovaps [rsp+0xD0], xmm13
00007d55df7d3b65  vmovaps [rsp+0xE0], xmm14
00007d55df7d3b6e  sub rsp, 0x30
00007d55df7d3b72  movaps [rsp], xmm15
00007d55df7d3b77  movaps [rsp+0x10], xmm12
00007d55df7d3b7d  movaps [rsp+0x20], xmm13
00007d55df7d3b83  lea rdi, [rsp]
00007d55df7d3b87  mov esi, 0x00
00007d55df7d3b8c  mov rax, 0x5BB8433D8530
00007d55df7d3b96  call rax
00007d55df7d3b98  movaps xmm15, [rsp]
00007d55df7d3b9d  add rsp, 0x30
00007d55df7d3ba1  vmovaps xmm0, [rsp]
00007d55df7d3ba6  vmovaps xmm1, [rsp+0x10]
00007d55df7d3bac  vmovaps xmm2, [rsp+0x20]
00007d55df7d3bb2  vmovaps xmm3, [rsp+0x30]
00007d55df7d3bb8  vmovaps xmm4, [rsp+0x40]
00007d55df7d3bbe  vmovaps xmm5, [rsp+0x50]
00007d55df7d3bc4  vmovaps xmm6, [rsp+0x60]
00007d55df7d3bca  vmovaps xmm7, [rsp+0x70]
00007d55df7d3bd0  vmovaps xmm8, [rsp+0x80]
00007d55df7d3bd9  vmovaps xmm9, [rsp+0x90]
00007d55df7d3be2  vmovaps xmm10, [rsp+0xA0]
00007d55df7d3beb  vmovaps xmm11, [rsp+0xB0]
00007d55df7d3bf4  vmovaps xmm12, [rsp+0xC0]
00007d55df7d3bfd  vmovaps xmm13, [rsp+0xD0]
00007d55df7d3c06  vmovaps xmm14, [rsp+0xE0]
00007d55df7d3c0f  add rsp, 0xF0
00007d55df7d3c16  pop r11
00007d55df7d3c18  pop r10
00007d55df7d3c1a  pop r9
00007d55df7d3c1c  pop r8
00007d55df7d3c1e  pop rsi
00007d55df7d3c1f  pop rdi
00007d55df7d3c20  pop rdx
00007d55df7d3c21  pop rcx
00007d55df7d3c22  pop rax
00007d55df7d3c23  add rsp, 0x08
00007d55df7d3c27  jmp 0x00007D55DF7D2835
00007d55df7d3c2c  sub rsp, 0x08
00007d55df7d3c30  push rax
00007d55df7d3c31  push rcx
00007d55df7d3c32  push rdx
00007d55df7d3c33  push rdi
00007d55df7d3c34  push rsi
00007d55df7d3c35  push r8
00007d55df7d3c37  push r9
00007d55df7d3c39  push r10
00007d55df7d3c3b  push r11
00007d55df7d3c3d  sub rsp, 0xF0
00007d55df7d3c44  vmovaps [rsp], xmm0
00007d55df7d3c49  vmovaps [rsp+0x10], xmm2
00007d55df7d3c4f  vmovaps [rsp+0x20], xmm3
00007d55df7d3c55  vmovaps [rsp+0x30], xmm4
00007d55df7d3c5b  vmovaps [rsp+0x40], xmm5
00007d55df7d3c61  vmovaps [rsp+0x50], xmm6
00007d55df7d3c67  vmovaps [rsp+0x60], xmm7
00007d55df7d3c6d  vmovaps [rsp+0x70], xmm8
00007d55df7d3c73  vmovaps [rsp+0x80], xmm9
00007d55df7d3c7c  vmovaps [rsp+0x90], xmm10
00007d55df7d3c85  vmovaps [rsp+0xA0], xmm11
00007d55df7d3c8e  vmovaps [rsp+0xB0], xmm12
00007d55df7d3c97  vmovaps [rsp+0xC0], xmm13
00007d55df7d3ca0  vmovaps [rsp+0xD0], xmm14
00007d55df7d3ca9  vmovaps [rsp+0xE0], xmm15
00007d55df7d3cb2  sub rsp, 0x30
00007d55df7d3cb6  movaps [rsp], xmm1
00007d55df7d3cba  movaps [rsp+0x10], xmm12
00007d55df7d3cc0  movaps [rsp+0x20], xmm10
00007d55df7d3cc6  lea rdi, [rsp]
00007d55df7d3cca  mov esi, 0x00
00007d55df7d3ccf  mov rax, 0x5BB8433D8530
00007d55df7d3cd9  call rax
00007d55df7d3cdb  movaps xmm1, [rsp]
00007d55df7d3cdf  add rsp, 0x30
00007d55df7d3ce3  vmovaps xmm0, [rsp]
00007d55df7d3ce8  vmovaps xmm2, [rsp+0x10]
00007d55df7d3cee  vmovaps xmm3, [rsp+0x20]
00007d55df7d3cf4  vmovaps xmm4, [rsp+0x30]
00007d55df7d3cfa  vmovaps xmm5, [rsp+0x40]
00007d55df7d3d00  vmovaps xmm6, [rsp+0x50]
00007d55df7d3d06  vmovaps xmm7, [rsp+0x60]
00007d55df7d3d0c  vmovaps xmm8, [rsp+0x70]
00007d55df7d3d12  vmovaps xmm9, [rsp+0x80]
00007d55df7d3d1b  vmovaps xmm10, [rsp+0x90]
00007d55df7d3d24  vmovaps xmm11, [rsp+0xA0]
00007d55df7d3d2d  vmovaps xmm12, [rsp+0xB0]
00007d55df7d3d36  vmovaps xmm13, [rsp+0xC0]
00007d55df7d3d3f  vmovaps xmm14, [rsp+0xD0]
00007d55df7d3d48  vmovaps xmm15, [rsp+0xE0]
00007d55df7d3d51  add rsp, 0xF0
00007d55df7d3d58  pop r11
00007d55df7d3d5a  pop r10
00007d55df7d3d5c  pop r9
00007d55df7d3d5e  pop r8
00007d55df7d3d60  pop rsi
00007d55df7d3d61  pop rdi
00007d55df7d3d62  pop rdx
00007d55df7d3d63  pop rcx
00007d55df7d3d64  pop rax
00007d55df7d3d65  add rsp, 0x08
00007d55df7d3d69  jmp 0x00007D55DF7D284F
00007d55df7d3d6e  sub rsp, 0x08
00007d55df7d3d72  push rax
00007d55df7d3d73  push rcx
00007d55df7d3d74  push rdx
00007d55df7d3d75  push rdi
00007d55df7d3d76  push rsi
00007d55df7d3d77  push r8
00007d55df7d3d79  push r9
00007d55df7d3d7b  push r10
00007d55df7d3d7d  push r11
00007d55df7d3d7f  sub rsp, 0xF0
00007d55df7d3d86  vmovaps [rsp], xmm0
00007d55df7d3d8b  vmovaps [rsp+0x10], xmm1
00007d55df7d3d91  vmovaps [rsp+0x20], xmm2
00007d55df7d3d97  vmovaps [rsp+0x30], xmm3
00007d55df7d3d9d  vmovaps [rsp+0x40], xmm4
00007d55df7d3da3  vmovaps [rsp+0x50], xmm5
00007d55df7d3da9  vmovaps [rsp+0x60], xmm6
00007d55df7d3daf  vmovaps [rsp+0x70], xmm7
00007d55df7d3db5  vmovaps [rsp+0x80], xmm8
00007d55df7d3dbe  vmovaps [rsp+0x90], xmm9
00007d55df7d3dc7  vmovaps [rsp+0xA0], xmm10
00007d55df7d3dd0  vmovaps [rsp+0xB0], xmm11
00007d55df7d3dd9  vmovaps [rsp+0xC0], xmm12
00007d55df7d3de2  vmovaps [rsp+0xD0], xmm14
00007d55df7d3deb  vmovaps [rsp+0xE0], xmm15
00007d55df7d3df4  sub rsp, 0x30
00007d55df7d3df8  movaps [rsp], xmm13
00007d55df7d3dfd  movaps [rsp+0x10], xmm12
00007d55df7d3e03  movaps [rsp+0x20], xmm2
00007d55df7d3e08  lea rdi, [rsp]
00007d55df7d3e0c  mov esi, 0x00
00007d55df7d3e11  mov rax, 0x5BB8433D8530
00007d55df7d3e1b  call rax
00007d55df7d3e1d  movaps xmm13, [rsp]
00007d55df7d3e22  add rsp, 0x30
00007d55df7d3e26  vmovaps xmm0, [rsp]
00007d55df7d3e2b  vmovaps xmm1, [rsp+0x10]
00007d55df7d3e31  vmovaps xmm2, [rsp+0x20]
00007d55df7d3e37  vmovaps xmm3, [rsp+0x30]
00007d55df7d3e3d  vmovaps xmm4, [rsp+0x40]
00007d55df7d3e43  vmovaps xmm5, [rsp+0x50]
00007d55df7d3e49  vmovaps xmm6, [rsp+0x60]
00007d55df7d3e4f  vmovaps xmm7, [rsp+0x70]
00007d55df7d3e55  vmovaps xmm8, [rsp+0x80]
00007d55df7d3e5e  vmovaps xmm9, [rsp+0x90]
00007d55df7d3e67  vmovaps xmm10, [rsp+0xA0]
00007d55df7d3e70  vmovaps xmm11, [rsp+0xB0]
00007d55df7d3e79  vmovaps xmm12, [rsp+0xC0]
00007d55df7d3e82  vmovaps xmm14, [rsp+0xD0]
00007d55df7d3e8b  vmovaps xmm15, [rsp+0xE0]
00007d55df7d3e94  add rsp, 0xF0
00007d55df7d3e9b  pop r11
00007d55df7d3e9d  pop r10
00007d55df7d3e9f  pop r9
00007d55df7d3ea1  pop r8
00007d55df7d3ea3  pop rsi
00007d55df7d3ea4  pop rdi
00007d55df7d3ea5  pop rdx
00007d55df7d3ea6  pop rcx
00007d55df7d3ea7  pop rax
00007d55df7d3ea8  add rsp, 0x08
00007d55df7d3eac  jmp 0x00007D55DF7D286A
00007d55df7d3eb1  sub rsp, 0x08
00007d55df7d3eb5  push rax
00007d55df7d3eb6  push rcx
00007d55df7d3eb7  push rdx
00007d55df7d3eb8  push rdi
00007d55df7d3eb9  push rsi
00007d55df7d3eba  push r8
00007d55df7d3ebc  push r9
00007d55df7d3ebe  push r10
00007d55df7d3ec0  push r11
00007d55df7d3ec2  sub rsp, 0xF0
00007d55df7d3ec9  vmovaps [rsp], xmm0
00007d55df7d3ece  vmovaps [rsp+0x10], xmm2
00007d55df7d3ed4  vmovaps [rsp+0x20], xmm3
00007d55df7d3eda  vmovaps [rsp+0x30], xmm4
00007d55df7d3ee0  vmovaps [rsp+0x40], xmm5
00007d55df7d3ee6  vmovaps [rsp+0x50], xmm6
00007d55df7d3eec  vmovaps [rsp+0x60], xmm7
00007d55df7d3ef2  vmovaps [rsp+0x70], xmm8
00007d55df7d3ef8  vmovaps [rsp+0x80], xmm9
00007d55df7d3f01  vmovaps [rsp+0x90], xmm10
00007d55df7d3f0a  vmovaps [rsp+0xA0], xmm11
00007d55df7d3f13  vmovaps [rsp+0xB0], xmm12
00007d55df7d3f1c  vmovaps [rsp+0xC0], xmm13
00007d55df7d3f25  vmovaps [rsp+0xD0], xmm14
00007d55df7d3f2e  vmovaps [rsp+0xE0], xmm15
00007d55df7d3f37  sub rsp, 0x30
00007d55df7d3f3b  movaps [rsp], xmm1
00007d55df7d3f3f  movaps [rsp+0x10], xmm10
00007d55df7d3f45  movaps [rsp+0x20], xmm2
00007d55df7d3f4a  lea rdi, [rsp]
00007d55df7d3f4e  mov esi, 0x00
00007d55df7d3f53  mov rax, 0x5BB8433D8530
00007d55df7d3f5d  call rax
00007d55df7d3f5f  movaps xmm1, [rsp]
00007d55df7d3f63  add rsp, 0x30
00007d55df7d3f67  vmovaps xmm0, [rsp]
00007d55df7d3f6c  vmovaps xmm2, [rsp+0x10]
00007d55df7d3f72  vmovaps xmm3, [rsp+0x20]
00007d55df7d3f78  vmovaps xmm4, [rsp+0x30]
00007d55df7d3f7e  vmovaps xmm5, [rsp+0x40]
00007d55df7d3f84  vmovaps xmm6, [rsp+0x50]
00007d55df7d3f8a  vmovaps xmm7, [rsp+0x60]
00007d55df7d3f90  vmovaps xmm8, [rsp+0x70]
00007d55df7d3f96  vmovaps xmm9, [rsp+0x80]
00007d55df7d3f9f  vmovaps xmm10, [rsp+0x90]
00007d55df7d3fa8  vmovaps xmm11, [rsp+0xA0]
00007d55df7d3fb1  vmovaps xmm12, [rsp+0xB0]
00007d55df7d3fba  vmovaps xmm13, [rsp+0xC0]
00007d55df7d3fc3  vmovaps xmm14, [rsp+0xD0]
00007d55df7d3fcc  vmovaps xmm15, [rsp+0xE0]
00007d55df7d3fd5  add rsp, 0xF0
00007d55df7d3fdc  pop r11
00007d55df7d3fde  pop r10
00007d55df7d3fe0  pop r9
00007d55df7d3fe2  pop r8
00007d55df7d3fe4  pop rsi
00007d55df7d3fe5  pop rdi
00007d55df7d3fe6  pop rdx
00007d55df7d3fe7  pop rcx
00007d55df7d3fe8  pop rax
00007d55df7d3fe9  add rsp, 0x08
00007d55df7d3fed  jmp 0x00007D55DF7D28D2
00007d55df7d3ff2  sub rsp, 0x08
00007d55df7d3ff6  push rax
00007d55df7d3ff7  push rcx
00007d55df7d3ff8  push rdx
00007d55df7d3ff9  push rdi
00007d55df7d3ffa  push rsi
00007d55df7d3ffb  push r8
00007d55df7d3ffd  push r9
00007d55df7d3fff  push r10
00007d55df7d4001  push r11
00007d55df7d4003  sub rsp, 0xF0
00007d55df7d400a  vmovaps [rsp], xmm0
00007d55df7d400f  vmovaps [rsp+0x10], xmm1
00007d55df7d4015  vmovaps [rsp+0x20], xmm2
00007d55df7d401b  vmovaps [rsp+0x30], xmm3
00007d55df7d4021  vmovaps [rsp+0x40], xmm4
00007d55df7d4027  vmovaps [rsp+0x50], xmm5
00007d55df7d402d  vmovaps [rsp+0x60], xmm6
00007d55df7d4033  vmovaps [rsp+0x70], xmm7
00007d55df7d4039  vmovaps [rsp+0x80], xmm8
00007d55df7d4042  vmovaps [rsp+0x90], xmm9
00007d55df7d404b  vmovaps [rsp+0xA0], xmm10
00007d55df7d4054  vmovaps [rsp+0xB0], xmm11
00007d55df7d405d  vmovaps [rsp+0xC0], xmm12
00007d55df7d4066  vmovaps [rsp+0xD0], xmm13
00007d55df7d406f  vmovaps [rsp+0xE0], xmm14
00007d55df7d4078  sub rsp, 0x30
00007d55df7d407c  movaps [rsp], xmm15
00007d55df7d4081  movaps [rsp+0x10], xmm10
00007d55df7d4087  movaps [rsp+0x20], xmm2
00007d55df7d408c  lea rdi, [rsp]
00007d55df7d4090  mov esi, 0x00
00007d55df7d4095  mov rax, 0x5BB8433D8530
00007d55df7d409f  call rax
00007d55df7d40a1  movaps xmm15, [rsp]
00007d55df7d40a6  add rsp, 0x30
00007d55df7d40aa  vmovaps xmm0, [rsp]
00007d55df7d40af  vmovaps xmm1, [rsp+0x10]
00007d55df7d40b5  vmovaps xmm2, [rsp+0x20]
00007d55df7d40bb  vmovaps xmm3, [rsp+0x30]
00007d55df7d40c1  vmovaps xmm4, [rsp+0x40]
00007d55df7d40c7  vmovaps xmm5, [rsp+0x50]
00007d55df7d40cd  vmovaps xmm6, [rsp+0x60]
00007d55df7d40d3  vmovaps xmm7, [rsp+0x70]
00007d55df7d40d9  vmovaps xmm8, [rsp+0x80]
00007d55df7d40e2  vmovaps xmm9, [rsp+0x90]
00007d55df7d40eb  vmovaps xmm10, [rsp+0xA0]
00007d55df7d40f4  vmovaps xmm11, [rsp+0xB0]
00007d55df7d40fd  vmovaps xmm12, [rsp+0xC0]
00007d55df7d4106  vmovaps xmm13, [rsp+0xD0]
00007d55df7d410f  vmovaps xmm14, [rsp+0xE0]
00007d55df7d4118  add rsp, 0xF0
00007d55df7d411f  pop r11
00007d55df7d4121  pop r10
00007d55df7d4123  pop r9
00007d55df7d4125  pop r8
00007d55df7d4127  pop rsi
00007d55df7d4128  pop rdi
00007d55df7d4129  pop rdx
00007d55df7d412a  pop rcx
00007d55df7d412b  pop rax
00007d55df7d412c  add rsp, 0x08
00007d55df7d4130  jmp 0x00007D55DF7D2924
00007d55df7d4135  sub rsp, 0x08
00007d55df7d4139  push rax
00007d55df7d413a  push rcx
00007d55df7d413b  push rdx
00007d55df7d413c  push rdi
00007d55df7d413d  push rsi
00007d55df7d413e  push r8
00007d55df7d4140  push r9
00007d55df7d4142  push r10
00007d55df7d4144  push r11
00007d55df7d4146  sub rsp, 0xF0
00007d55df7d414d  vmovaps [rsp], xmm0
00007d55df7d4152  vmovaps [rsp+0x10], xmm2
00007d55df7d4158  vmovaps [rsp+0x20], xmm3
00007d55df7d415e  vmovaps [rsp+0x30], xmm4
00007d55df7d4164  vmovaps [rsp+0x40], xmm5
00007d55df7d416a  vmovaps [rsp+0x50], xmm6
00007d55df7d4170  vmovaps [rsp+0x60], xmm7
00007d55df7d4176  vmovaps [rsp+0x70], xmm8
00007d55df7d417c  vmovaps [rsp+0x80], xmm9
00007d55df7d4185  vmovaps [rsp+0x90], xmm10
00007d55df7d418e  vmovaps [rsp+0xA0], xmm11
00007d55df7d4197  vmovaps [rsp+0xB0], xmm12
00007d55df7d41a0  vmovaps [rsp+0xC0], xmm13
00007d55df7d41a9  vmovaps [rsp+0xD0], xmm14
00007d55df7d41b2  vmovaps [rsp+0xE0], xmm15
00007d55df7d41bb  sub rsp, 0x30
00007d55df7d41bf  movaps [rsp], xmm1
00007d55df7d41c3  movaps [rsp+0x10], xmm10
00007d55df7d41c9  movaps [rsp+0x20], xmm15
00007d55df7d41cf  lea rdi, [rsp]
00007d55df7d41d3  mov esi, 0x00
00007d55df7d41d8  mov rax, 0x5BB8433D8530
00007d55df7d41e2  call rax
00007d55df7d41e4  movaps xmm1, [rsp]
00007d55df7d41e8  add rsp, 0x30
00007d55df7d41ec  vmovaps xmm0, [rsp]
00007d55df7d41f1  vmovaps xmm2, [rsp+0x10]
00007d55df7d41f7  vmovaps xmm3, [rsp+0x20]
00007d55df7d41fd  vmovaps xmm4, [rsp+0x30]
00007d55df7d4203  vmovaps xmm5, [rsp+0x40]
00007d55df7d4209  vmovaps xmm6, [rsp+0x50]
00007d55df7d420f  vmovaps xmm7, [rsp+0x60]
00007d55df7d4215  vmovaps xmm8, [rsp+0x70]
00007d55df7d421b  vmovaps xmm9, [rsp+0x80]
00007d55df7d4224  vmovaps xmm10, [rsp+0x90]
00007d55df7d422d  vmovaps xmm11, [rsp+0xA0]
00007d55df7d4236  vmovaps xmm12, [rsp+0xB0]
00007d55df7d423f  vmovaps xmm13, [rsp+0xC0]
00007d55df7d4248  vmovaps xmm14, [rsp+0xD0]
00007d55df7d4251  vmovaps xmm15, [rsp+0xE0]
00007d55df7d425a  add rsp, 0xF0
00007d55df7d4261  pop r11
00007d55df7d4263  pop r10
00007d55df7d4265  pop r9
00007d55df7d4267  pop r8
00007d55df7d4269  pop rsi
00007d55df7d426a  pop rdi
00007d55df7d426b  pop rdx
00007d55df7d426c  pop rcx
00007d55df7d426d  pop rax
00007d55df7d426e  add rsp, 0x08
00007d55df7d4272  jmp 0x00007D55DF7D2962
00007d55df7d4277  sub rsp, 0x08
00007d55df7d427b  push rax
00007d55df7d427c  push rcx
00007d55df7d427d  push rdx
00007d55df7d427e  push rdi
00007d55df7d427f  push rsi
00007d55df7d4280  push r8
00007d55df7d4282  push r9
00007d55df7d4284  push r10
00007d55df7d4286  push r11
00007d55df7d4288  sub rsp, 0xF0
00007d55df7d428f  vmovaps [rsp], xmm0
00007d55df7d4294  vmovaps [rsp+0x10], xmm1
00007d55df7d429a  vmovaps [rsp+0x20], xmm2
00007d55df7d42a0  vmovaps [rsp+0x30], xmm3
00007d55df7d42a6  vmovaps [rsp+0x40], xmm4
00007d55df7d42ac  vmovaps [rsp+0x50], xmm5
00007d55df7d42b2  vmovaps [rsp+0x60], xmm6
00007d55df7d42b8  vmovaps [rsp+0x70], xmm7
00007d55df7d42be  vmovaps [rsp+0x80], xmm8
00007d55df7d42c7  vmovaps [rsp+0x90], xmm9
00007d55df7d42d0  vmovaps [rsp+0xA0], xmm10
00007d55df7d42d9  vmovaps [rsp+0xB0], xmm11
00007d55df7d42e2  vmovaps [rsp+0xC0], xmm12
00007d55df7d42eb  vmovaps [rsp+0xD0], xmm13
00007d55df7d42f4  vmovaps [rsp+0xE0], xmm15
00007d55df7d42fd  sub rsp, 0x30
00007d55df7d4301  movaps [rsp], xmm14
00007d55df7d4306  movaps [rsp+0x10], xmm10
00007d55df7d430c  movaps [rsp+0x20], xmm15
00007d55df7d4312  lea rdi, [rsp]
00007d55df7d4316  mov esi, 0x00
00007d55df7d431b  mov rax, 0x5BB8433D8530
00007d55df7d4325  call rax
00007d55df7d4327  movaps xmm14, [rsp]
00007d55df7d432c  add rsp, 0x30
00007d55df7d4330  vmovaps xmm0, [rsp]
00007d55df7d4335  vmovaps xmm1, [rsp+0x10]
00007d55df7d433b  vmovaps xmm2, [rsp+0x20]
00007d55df7d4341  vmovaps xmm3, [rsp+0x30]
00007d55df7d4347  vmovaps xmm4, [rsp+0x40]
00007d55df7d434d  vmovaps xmm5, [rsp+0x50]
00007d55df7d4353  vmovaps xmm6, [rsp+0x60]
00007d55df7d4359  vmovaps xmm7, [rsp+0x70]
00007d55df7d435f  vmovaps xmm8, [rsp+0x80]
00007d55df7d4368  vmovaps xmm9, [rsp+0x90]
00007d55df7d4371  vmovaps xmm10, [rsp+0xA0]
00007d55df7d437a  vmovaps xmm11, [rsp+0xB0]
00007d55df7d4383  vmovaps xmm12, [rsp+0xC0]
00007d55df7d438c  vmovaps xmm13, [rsp+0xD0]
00007d55df7d4395  vmovaps xmm15, [rsp+0xE0]
00007d55df7d439e  add rsp, 0xF0
00007d55df7d43a5  pop r11
00007d55df7d43a7  pop r10
00007d55df7d43a9  pop r9
00007d55df7d43ab  pop r8
00007d55df7d43ad  pop rsi
00007d55df7d43ae  pop rdi
00007d55df7d43af  pop rdx
00007d55df7d43b0  pop rcx
00007d55df7d43b1  pop rax
00007d55df7d43b2  add rsp, 0x08
00007d55df7d43b6  jmp 0x00007D55DF7D298E
00007d55df7d43bb  call 0x00007D55DF5FF430
00007d55df7d43c0  jmp 0x00007D55DF7D2A1E
00007d55df7d43c5  call 0x00007D55DF5FF430
00007d55df7d43ca  jmp 0x00007D55DF7D2A31
00007d55df7d43cf  sub rsp, 0x08
00007d55df7d43d3  push rax
00007d55df7d43d4  push rcx
00007d55df7d43d5  push rdx
00007d55df7d43d6  push rdi
00007d55df7d43d7  push rsi
00007d55df7d43d8  push r8
00007d55df7d43da  push r9
00007d55df7d43dc  push r10
00007d55df7d43de  push r11
00007d55df7d43e0  sub rsp, 0xF0
00007d55df7d43e7  vmovaps [rsp], xmm0
00007d55df7d43ec  vmovaps [rsp+0x10], xmm2
00007d55df7d43f2  vmovaps [rsp+0x20], xmm3
00007d55df7d43f8  vmovaps [rsp+0x30], xmm4
00007d55df7d43fe  vmovaps [rsp+0x40], xmm5
00007d55df7d4404  vmovaps [rsp+0x50], xmm6
00007d55df7d440a  vmovaps [rsp+0x60], xmm7
00007d55df7d4410  vmovaps [rsp+0x70], xmm8
00007d55df7d4416  vmovaps [rsp+0x80], xmm9
00007d55df7d441f  vmovaps [rsp+0x90], xmm10
00007d55df7d4428  vmovaps [rsp+0xA0], xmm11
00007d55df7d4431  vmovaps [rsp+0xB0], xmm12
00007d55df7d443a  vmovaps [rsp+0xC0], xmm13
00007d55df7d4443  vmovaps [rsp+0xD0], xmm14
00007d55df7d444c  vmovaps [rsp+0xE0], xmm15
00007d55df7d4455  sub rsp, 0x30
00007d55df7d4459  movaps [rsp], xmm1
00007d55df7d445d  movaps [rsp+0x10], xmm13
00007d55df7d4463  movaps [rsp+0x20], xmm2
00007d55df7d4468  lea rdi, [rsp]
00007d55df7d446c  mov esi, 0x00
00007d55df7d4471  mov rax, 0x5BB8433D8530
00007d55df7d447b  call rax
00007d55df7d447d  movaps xmm1, [rsp]
00007d55df7d4481  add rsp, 0x30
00007d55df7d4485  vmovaps xmm0, [rsp]
00007d55df7d448a  vmovaps xmm2, [rsp+0x10]
00007d55df7d4490  vmovaps xmm3, [rsp+0x20]
00007d55df7d4496  vmovaps xmm4, [rsp+0x30]
00007d55df7d449c  vmovaps xmm5, [rsp+0x40]
00007d55df7d44a2  vmovaps xmm6, [rsp+0x50]
00007d55df7d44a8  vmovaps xmm7, [rsp+0x60]
00007d55df7d44ae  vmovaps xmm8, [rsp+0x70]
00007d55df7d44b4  vmovaps xmm9, [rsp+0x80]
00007d55df7d44bd  vmovaps xmm10, [rsp+0x90]
00007d55df7d44c6  vmovaps xmm11, [rsp+0xA0]
00007d55df7d44cf  vmovaps xmm12, [rsp+0xB0]
00007d55df7d44d8  vmovaps xmm13, [rsp+0xC0]
00007d55df7d44e1  vmovaps xmm14, [rsp+0xD0]
00007d55df7d44ea  vmovaps xmm15, [rsp+0xE0]
00007d55df7d44f3  add rsp, 0xF0
00007d55df7d44fa  pop r11
00007d55df7d44fc  pop r10
00007d55df7d44fe  pop r9
00007d55df7d4500  pop r8
00007d55df7d4502  pop rsi
00007d55df7d4503  pop rdi
00007d55df7d4504  pop rdx
00007d55df7d4505  pop rcx
00007d55df7d4506  pop rax
00007d55df7d4507  add rsp, 0x08
00007d55df7d450b  jmp 0x00007D55DF7D2A5C
00007d55df7d4510  call 0x00007D55DF60E760
00007d55df7d4515  jmp 0x00007D55DF7D2A69
00007d55df7d451a  sub rsp, 0x08
00007d55df7d451e  push rax
00007d55df7d451f  push rcx
00007d55df7d4520  push rdx
00007d55df7d4521  push rdi
00007d55df7d4522  push rsi
00007d55df7d4523  push r8
00007d55df7d4525  push r9
00007d55df7d4527  push r10
00007d55df7d4529  push r11
00007d55df7d452b  sub rsp, 0xF0
00007d55df7d4532  vmovaps [rsp], xmm0
00007d55df7d4537  vmovaps [rsp+0x10], xmm1
00007d55df7d453d  vmovaps [rsp+0x20], xmm2
00007d55df7d4543  vmovaps [rsp+0x30], xmm3
00007d55df7d4549  vmovaps [rsp+0x40], xmm4
00007d55df7d454f  vmovaps [rsp+0x50], xmm5
00007d55df7d4555  vmovaps [rsp+0x60], xmm6
00007d55df7d455b  vmovaps [rsp+0x70], xmm7
00007d55df7d4561  vmovaps [rsp+0x80], xmm8
00007d55df7d456a  vmovaps [rsp+0x90], xmm9
00007d55df7d4573  vmovaps [rsp+0xA0], xmm10
00007d55df7d457c  vmovaps [rsp+0xB0], xmm11
00007d55df7d4585  vmovaps [rsp+0xC0], xmm12
00007d55df7d458e  vmovaps [rsp+0xD0], xmm14
00007d55df7d4597  vmovaps [rsp+0xE0], xmm15
00007d55df7d45a0  sub rsp, 0x30
00007d55df7d45a4  movaps [rsp], xmm13
00007d55df7d45a9  movaps [rsp+0x10], xmm2
00007d55df7d45ae  movaps [rsp+0x20], xmm1
00007d55df7d45b3  lea rdi, [rsp]
00007d55df7d45b7  mov esi, 0x00
00007d55df7d45bc  mov rax, 0x5BB8433D8530
00007d55df7d45c6  call rax
00007d55df7d45c8  movaps xmm13, [rsp]
00007d55df7d45cd  add rsp, 0x30
00007d55df7d45d1  vmovaps xmm0, [rsp]
00007d55df7d45d6  vmovaps xmm1, [rsp+0x10]
00007d55df7d45dc  vmovaps xmm2, [rsp+0x20]
00007d55df7d45e2  vmovaps xmm3, [rsp+0x30]
00007d55df7d45e8  vmovaps xmm4, [rsp+0x40]
00007d55df7d45ee  vmovaps xmm5, [rsp+0x50]
00007d55df7d45f4  vmovaps xmm6, [rsp+0x60]
00007d55df7d45fa  vmovaps xmm7, [rsp+0x70]
00007d55df7d4600  vmovaps xmm8, [rsp+0x80]
00007d55df7d4609  vmovaps xmm9, [rsp+0x90]
00007d55df7d4612  vmovaps xmm10, [rsp+0xA0]
00007d55df7d461b  vmovaps xmm11, [rsp+0xB0]
00007d55df7d4624  vmovaps xmm12, [rsp+0xC0]
00007d55df7d462d  vmovaps xmm14, [rsp+0xD0]
00007d55df7d4636  vmovaps xmm15, [rsp+0xE0]
00007d55df7d463f  add rsp, 0xF0
00007d55df7d4646  pop r11
00007d55df7d4648  pop r10
00007d55df7d464a  pop r9
00007d55df7d464c  pop r8
00007d55df7d464e  pop rsi
00007d55df7d464f  pop rdi
00007d55df7d4650  pop rdx
00007d55df7d4651  pop rcx
00007d55df7d4652  pop rax
00007d55df7d4653  add rsp, 0x08
00007d55df7d4657  jmp 0x00007D55DF7D2AA8
00007d55df7d465c  sub rsp, 0x08
00007d55df7d4660  push rax
00007d55df7d4661  push rcx
00007d55df7d4662  push rdx
00007d55df7d4663  push rdi
00007d55df7d4664  push rsi
00007d55df7d4665  push r8
00007d55df7d4667  push r9
00007d55df7d4669  push r10
00007d55df7d466b  push r11
00007d55df7d466d  sub rsp, 0xF0
00007d55df7d4674  vmovaps [rsp], xmm0
00007d55df7d4679  vmovaps [rsp+0x10], xmm2
00007d55df7d467f  vmovaps [rsp+0x20], xmm3
00007d55df7d4685  vmovaps [rsp+0x30], xmm4
00007d55df7d468b  vmovaps [rsp+0x40], xmm5
00007d55df7d4691  vmovaps [rsp+0x50], xmm6
00007d55df7d4697  vmovaps [rsp+0x60], xmm7
00007d55df7d469d  vmovaps [rsp+0x70], xmm8
00007d55df7d46a3  vmovaps [rsp+0x80], xmm9
00007d55df7d46ac  vmovaps [rsp+0x90], xmm10
00007d55df7d46b5  vmovaps [rsp+0xA0], xmm11
00007d55df7d46be  vmovaps [rsp+0xB0], xmm12
00007d55df7d46c7  vmovaps [rsp+0xC0], xmm13
00007d55df7d46d0  vmovaps [rsp+0xD0], xmm14
00007d55df7d46d9  vmovaps [rsp+0xE0], xmm15
00007d55df7d46e2  sub rsp, 0x30
00007d55df7d46e6  movaps [rsp], xmm1
00007d55df7d46ea  movaps [rsp+0x10], xmm14
00007d55df7d46f0  movaps [rsp+0x20], xmm15
00007d55df7d46f6  lea rdi, [rsp]
00007d55df7d46fa  mov esi, 0x00
00007d55df7d46ff  mov rax, 0x5BB8433D8530
00007d55df7d4709  call rax
00007d55df7d470b  movaps xmm1, [rsp]
00007d55df7d470f  add rsp, 0x30
00007d55df7d4713  vmovaps xmm0, [rsp]
00007d55df7d4718  vmovaps xmm2, [rsp+0x10]
00007d55df7d471e  vmovaps xmm3, [rsp+0x20]
00007d55df7d4724  vmovaps xmm4, [rsp+0x30]
00007d55df7d472a  vmovaps xmm5, [rsp+0x40]
00007d55df7d4730  vmovaps xmm6, [rsp+0x50]
00007d55df7d4736  vmovaps xmm7, [rsp+0x60]
00007d55df7d473c  vmovaps xmm8, [rsp+0x70]
00007d55df7d4742  vmovaps xmm9, [rsp+0x80]
00007d55df7d474b  vmovaps xmm10, [rsp+0x90]
00007d55df7d4754  vmovaps xmm11, [rsp+0xA0]
00007d55df7d475d  vmovaps xmm12, [rsp+0xB0]
00007d55df7d4766  vmovaps xmm13, [rsp+0xC0]
00007d55df7d476f  vmovaps xmm14, [rsp+0xD0]
00007d55df7d4778  vmovaps xmm15, [rsp+0xE0]
00007d55df7d4781  add rsp, 0xF0
00007d55df7d4788  pop r11
00007d55df7d478a  pop r10
00007d55df7d478c  pop r9
00007d55df7d478e  pop r8
00007d55df7d4790  pop rsi
00007d55df7d4791  pop rdi
00007d55df7d4792  pop rdx
00007d55df7d4793  pop rcx
00007d55df7d4794  pop rax
00007d55df7d4795  add rsp, 0x08
00007d55df7d4799  jmp 0x00007D55DF7D2ACA
00007d55df7d479e  sub rsp, 0x08
00007d55df7d47a2  push rax
00007d55df7d47a3  push rcx
00007d55df7d47a4  push rdx
00007d55df7d47a5  push rdi
00007d55df7d47a6  push rsi
00007d55df7d47a7  push r8
00007d55df7d47a9  push r9
00007d55df7d47ab  push r10
00007d55df7d47ad  push r11
00007d55df7d47af  sub rsp, 0xF0
00007d55df7d47b6  vmovaps [rsp], xmm0
00007d55df7d47bb  vmovaps [rsp+0x10], xmm1
00007d55df7d47c1  vmovaps [rsp+0x20], xmm2
00007d55df7d47c7  vmovaps [rsp+0x30], xmm3
00007d55df7d47cd  vmovaps [rsp+0x40], xmm4
00007d55df7d47d3  vmovaps [rsp+0x50], xmm5
00007d55df7d47d9  vmovaps [rsp+0x60], xmm6
00007d55df7d47df  vmovaps [rsp+0x70], xmm7
00007d55df7d47e5  vmovaps [rsp+0x80], xmm8
00007d55df7d47ee  vmovaps [rsp+0x90], xmm9
00007d55df7d47f7  vmovaps [rsp+0xA0], xmm10
00007d55df7d4800  vmovaps [rsp+0xB0], xmm11
00007d55df7d4809  vmovaps [rsp+0xC0], xmm12
00007d55df7d4812  vmovaps [rsp+0xD0], xmm13
00007d55df7d481b  vmovaps [rsp+0xE0], xmm15
00007d55df7d4824  sub rsp, 0x30
00007d55df7d4828  movaps [rsp], xmm14
00007d55df7d482d  movaps [rsp+0x10], xmm2
00007d55df7d4832  movaps [rsp+0x20], xmm15
00007d55df7d4838  lea rdi, [rsp]
00007d55df7d483c  mov esi, 0x00
00007d55df7d4841  mov rax, 0x5BB8433D8530
00007d55df7d484b  call rax
00007d55df7d484d  movaps xmm14, [rsp]
00007d55df7d4852  add rsp, 0x30
00007d55df7d4856  vmovaps xmm0, [rsp]
00007d55df7d485b  vmovaps xmm1, [rsp+0x10]
00007d55df7d4861  vmovaps xmm2, [rsp+0x20]
00007d55df7d4867  vmovaps xmm3, [rsp+0x30]
00007d55df7d486d  vmovaps xmm4, [rsp+0x40]
00007d55df7d4873  vmovaps xmm5, [rsp+0x50]
00007d55df7d4879  vmovaps xmm6, [rsp+0x60]
00007d55df7d487f  vmovaps xmm7, [rsp+0x70]
00007d55df7d4885  vmovaps xmm8, [rsp+0x80]
00007d55df7d488e  vmovaps xmm9, [rsp+0x90]
00007d55df7d4897  vmovaps xmm10, [rsp+0xA0]
00007d55df7d48a0  vmovaps xmm11, [rsp+0xB0]
00007d55df7d48a9  vmovaps xmm12, [rsp+0xC0]
00007d55df7d48b2  vmovaps xmm13, [rsp+0xD0]
00007d55df7d48bb  vmovaps xmm15, [rsp+0xE0]
00007d55df7d48c4  add rsp, 0xF0
00007d55df7d48cb  pop r11
00007d55df7d48cd  pop r10
00007d55df7d48cf  pop r9
00007d55df7d48d1  pop r8
00007d55df7d48d3  pop rsi
00007d55df7d48d4  pop rdi
00007d55df7d48d5  pop rdx
00007d55df7d48d6  pop rcx
00007d55df7d48d7  pop rax
00007d55df7d48d8  add rsp, 0x08
00007d55df7d48dc  jmp 0x00007D55DF7D2B05
00007d55df7d48e1  sub rsp, 0x08
00007d55df7d48e5  push rax
00007d55df7d48e6  push rcx
00007d55df7d48e7  push rdx
00007d55df7d48e8  push rdi
00007d55df7d48e9  push rsi
00007d55df7d48ea  push r8
00007d55df7d48ec  push r9
00007d55df7d48ee  push r10
00007d55df7d48f0  push r11
00007d55df7d48f2  sub rsp, 0xF0
00007d55df7d48f9  vmovaps [rsp], xmm0
00007d55df7d48fe  vmovaps [rsp+0x10], xmm1
00007d55df7d4904  vmovaps [rsp+0x20], xmm2
00007d55df7d490a  vmovaps [rsp+0x30], xmm3
00007d55df7d4910  vmovaps [rsp+0x40], xmm4
00007d55df7d4916  vmovaps [rsp+0x50], xmm5
00007d55df7d491c  vmovaps [rsp+0x60], xmm6
00007d55df7d4922  vmovaps [rsp+0x70], xmm7
00007d55df7d4928  vmovaps [rsp+0x80], xmm8
00007d55df7d4931  vmovaps [rsp+0x90], xmm9
00007d55df7d493a  vmovaps [rsp+0xA0], xmm10
00007d55df7d4943  vmovaps [rsp+0xB0], xmm11
00007d55df7d494c  vmovaps [rsp+0xC0], xmm12
00007d55df7d4955  vmovaps [rsp+0xD0], xmm13
00007d55df7d495e  vmovaps [rsp+0xE0], xmm14
00007d55df7d4967  sub rsp, 0x30
00007d55df7d496b  movaps [rsp], xmm15
00007d55df7d4970  movaps [rsp+0x10], xmm2
00007d55df7d4975  movaps [rsp+0x20], xmm1
00007d55df7d497a  lea rdi, [rsp]
00007d55df7d497e  mov esi, 0x00
00007d55df7d4983  mov rax, 0x5BB8433D8530
00007d55df7d498d  call rax
00007d55df7d498f  movaps xmm15, [rsp]
00007d55df7d4994  add rsp, 0x30
00007d55df7d4998  vmovaps xmm0, [rsp]
00007d55df7d499d  vmovaps xmm1, [rsp+0x10]
00007d55df7d49a3  vmovaps xmm2, [rsp+0x20]
00007d55df7d49a9  vmovaps xmm3, [rsp+0x30]
00007d55df7d49af  vmovaps xmm4, [rsp+0x40]
00007d55df7d49b5  vmovaps xmm5, [rsp+0x50]
00007d55df7d49bb  vmovaps xmm6, [rsp+0x60]
00007d55df7d49c1  vmovaps xmm7, [rsp+0x70]
00007d55df7d49c7  vmovaps xmm8, [rsp+0x80]
00007d55df7d49d0  vmovaps xmm9, [rsp+0x90]
00007d55df7d49d9  vmovaps xmm10, [rsp+0xA0]
00007d55df7d49e2  vmovaps xmm11, [rsp+0xB0]
00007d55df7d49eb  vmovaps xmm12, [rsp+0xC0]
00007d55df7d49f4  vmovaps xmm13, [rsp+0xD0]
00007d55df7d49fd  vmovaps xmm14, [rsp+0xE0]
00007d55df7d4a06  add rsp, 0xF0
00007d55df7d4a0d  pop r11
00007d55df7d4a0f  pop r10
00007d55df7d4a11  pop r9
00007d55df7d4a13  pop r8
00007d55df7d4a15  pop rsi
00007d55df7d4a16  pop rdi
00007d55df7d4a17  pop rdx
00007d55df7d4a18  pop rcx
00007d55df7d4a19  pop rax
00007d55df7d4a1a  add rsp, 0x08
00007d55df7d4a1e  jmp 0x00007D55DF7D2B41
00007d55df7d4a23  call 0x00007D55DF5FF430
00007d55df7d4a28  jmp 0x00007D55DF7D2B4E
00007d55df7d4a2d  sub rsp, 0x08
00007d55df7d4a31  push rax
00007d55df7d4a32  push rcx
00007d55df7d4a33  push rdx
00007d55df7d4a34  push rdi
00007d55df7d4a35  push rsi
00007d55df7d4a36  push r8
00007d55df7d4a38  push r9
00007d55df7d4a3a  push r10
00007d55df7d4a3c  push r11
00007d55df7d4a3e  sub rsp, 0xF0
00007d55df7d4a45  vmovaps [rsp], xmm0
00007d55df7d4a4a  vmovaps [rsp+0x10], xmm1
00007d55df7d4a50  vmovaps [rsp+0x20], xmm3
00007d55df7d4a56  vmovaps [rsp+0x30], xmm4
00007d55df7d4a5c  vmovaps [rsp+0x40], xmm5
00007d55df7d4a62  vmovaps [rsp+0x50], xmm6
00007d55df7d4a68  vmovaps [rsp+0x60], xmm7
00007d55df7d4a6e  vmovaps [rsp+0x70], xmm8
00007d55df7d4a74  vmovaps [rsp+0x80], xmm9
00007d55df7d4a7d  vmovaps [rsp+0x90], xmm10
00007d55df7d4a86  vmovaps [rsp+0xA0], xmm11
00007d55df7d4a8f  vmovaps [rsp+0xB0], xmm12
00007d55df7d4a98  vmovaps [rsp+0xC0], xmm13
00007d55df7d4aa1  vmovaps [rsp+0xD0], xmm14
00007d55df7d4aaa  vmovaps [rsp+0xE0], xmm15
00007d55df7d4ab3  sub rsp, 0x30
00007d55df7d4ab7  movaps [rsp], xmm2
00007d55df7d4abb  movaps [rsp+0x10], xmm1
00007d55df7d4ac0  movaps [rsp+0x20], xmm14
00007d55df7d4ac6  lea rdi, [rsp]
00007d55df7d4aca  mov esi, 0x00
00007d55df7d4acf  mov rax, 0x5BB8433D8530
00007d55df7d4ad9  call rax
00007d55df7d4adb  movaps xmm2, [rsp]
00007d55df7d4adf  add rsp, 0x30
00007d55df7d4ae3  vmovaps xmm0, [rsp]
00007d55df7d4ae8  vmovaps xmm1, [rsp+0x10]
00007d55df7d4aee  vmovaps xmm3, [rsp+0x20]
00007d55df7d4af4  vmovaps xmm4, [rsp+0x30]
00007d55df7d4afa  vmovaps xmm5, [rsp+0x40]
00007d55df7d4b00  vmovaps xmm6, [rsp+0x50]
00007d55df7d4b06  vmovaps xmm7, [rsp+0x60]
00007d55df7d4b0c  vmovaps xmm8, [rsp+0x70]
00007d55df7d4b12  vmovaps xmm9, [rsp+0x80]
00007d55df7d4b1b  vmovaps xmm10, [rsp+0x90]
00007d55df7d4b24  vmovaps xmm11, [rsp+0xA0]
00007d55df7d4b2d  vmovaps xmm12, [rsp+0xB0]
00007d55df7d4b36  vmovaps xmm13, [rsp+0xC0]
00007d55df7d4b3f  vmovaps xmm14, [rsp+0xD0]
00007d55df7d4b48  vmovaps xmm15, [rsp+0xE0]
00007d55df7d4b51  add rsp, 0xF0
00007d55df7d4b58  pop r11
00007d55df7d4b5a  pop r10
00007d55df7d4b5c  pop r9
00007d55df7d4b5e  pop r8
00007d55df7d4b60  pop rsi
00007d55df7d4b61  pop rdi
00007d55df7d4b62  pop rdx
00007d55df7d4b63  pop rcx
00007d55df7d4b64  pop rax
00007d55df7d4b65  add rsp, 0x08
00007d55df7d4b69  jmp 0x00007D55DF7D2B8B
00007d55df7d4b6e  sub rsp, 0x08
00007d55df7d4b72  push rax
00007d55df7d4b73  push rcx
00007d55df7d4b74  push rdx
00007d55df7d4b75  push rdi
00007d55df7d4b76  push rsi
00007d55df7d4b77  push r8
00007d55df7d4b79  push r9
00007d55df7d4b7b  push r10
00007d55df7d4b7d  push r11
00007d55df7d4b7f  sub rsp, 0xF0
00007d55df7d4b86  vmovaps [rsp], xmm0
00007d55df7d4b8b  vmovaps [rsp+0x10], xmm1
00007d55df7d4b91  vmovaps [rsp+0x20], xmm2
00007d55df7d4b97  vmovaps [rsp+0x30], xmm3
00007d55df7d4b9d  vmovaps [rsp+0x40], xmm4
00007d55df7d4ba3  vmovaps [rsp+0x50], xmm5
00007d55df7d4ba9  vmovaps [rsp+0x60], xmm6
00007d55df7d4baf  vmovaps [rsp+0x70], xmm7
00007d55df7d4bb5  vmovaps [rsp+0x80], xmm8
00007d55df7d4bbe  vmovaps [rsp+0x90], xmm9
00007d55df7d4bc7  vmovaps [rsp+0xA0], xmm10
00007d55df7d4bd0  vmovaps [rsp+0xB0], xmm11
00007d55df7d4bd9  vmovaps [rsp+0xC0], xmm12
00007d55df7d4be2  vmovaps [rsp+0xD0], xmm13
00007d55df7d4beb  vmovaps [rsp+0xE0], xmm14
00007d55df7d4bf4  sub rsp, 0x30
00007d55df7d4bf8  movaps [rsp], xmm15
00007d55df7d4bfd  movaps [rsp+0x10], xmm14
00007d55df7d4c03  movaps [rsp+0x20], xmm1
00007d55df7d4c08  lea rdi, [rsp]
00007d55df7d4c0c  mov esi, 0x00
00007d55df7d4c11  mov rax, 0x5BB8433D8530
00007d55df7d4c1b  call rax
00007d55df7d4c1d  movaps xmm15, [rsp]
00007d55df7d4c22  add rsp, 0x30
00007d55df7d4c26  vmovaps xmm0, [rsp]
00007d55df7d4c2b  vmovaps xmm1, [rsp+0x10]
00007d55df7d4c31  vmovaps xmm2, [rsp+0x20]
00007d55df7d4c37  vmovaps xmm3, [rsp+0x30]
00007d55df7d4c3d  vmovaps xmm4, [rsp+0x40]
00007d55df7d4c43  vmovaps xmm5, [rsp+0x50]
00007d55df7d4c49  vmovaps xmm6, [rsp+0x60]
00007d55df7d4c4f  vmovaps xmm7, [rsp+0x70]
00007d55df7d4c55  vmovaps xmm8, [rsp+0x80]
00007d55df7d4c5e  vmovaps xmm9, [rsp+0x90]
00007d55df7d4c67  vmovaps xmm10, [rsp+0xA0]
00007d55df7d4c70  vmovaps xmm11, [rsp+0xB0]
00007d55df7d4c79  vmovaps xmm12, [rsp+0xC0]
00007d55df7d4c82  vmovaps xmm13, [rsp+0xD0]
00007d55df7d4c8b  vmovaps xmm14, [rsp+0xE0]
00007d55df7d4c94  add rsp, 0xF0
00007d55df7d4c9b  pop r11
00007d55df7d4c9d  pop r10
00007d55df7d4c9f  pop r9
00007d55df7d4ca1  pop r8
00007d55df7d4ca3  pop rsi
00007d55df7d4ca4  pop rdi
00007d55df7d4ca5  pop rdx
00007d55df7d4ca6  pop rcx
00007d55df7d4ca7  pop rax
00007d55df7d4ca8  add rsp, 0x08
00007d55df7d4cac  jmp 0x00007D55DF7D2C05
00007d55df7d4cb1  call 0x00007D55DF5FF430
00007d55df7d4cb6  jmp 0x00007D55DF7D2C12
00007d55df7d4cbb  sub rsp, 0x08
00007d55df7d4cbf  push rax
00007d55df7d4cc0  push rcx
00007d55df7d4cc1  push rdx
00007d55df7d4cc2  push rdi
00007d55df7d4cc3  push rsi
00007d55df7d4cc4  push r8
00007d55df7d4cc6  push r9
00007d55df7d4cc8  push r10
00007d55df7d4cca  push r11
00007d55df7d4ccc  sub rsp, 0xF0
00007d55df7d4cd3  vmovaps [rsp], xmm0
00007d55df7d4cd8  vmovaps [rsp+0x10], xmm1
00007d55df7d4cde  vmovaps [rsp+0x20], xmm2
00007d55df7d4ce4  vmovaps [rsp+0x30], xmm3
00007d55df7d4cea  vmovaps [rsp+0x40], xmm4
00007d55df7d4cf0  vmovaps [rsp+0x50], xmm5
00007d55df7d4cf6  vmovaps [rsp+0x60], xmm6
00007d55df7d4cfc  vmovaps [rsp+0x70], xmm7
00007d55df7d4d02  vmovaps [rsp+0x80], xmm8
00007d55df7d4d0b  vmovaps [rsp+0x90], xmm9
00007d55df7d4d14  vmovaps [rsp+0xA0], xmm10
00007d55df7d4d1d  vmovaps [rsp+0xB0], xmm11
00007d55df7d4d26  vmovaps [rsp+0xC0], xmm12
00007d55df7d4d2f  vmovaps [rsp+0xD0], xmm14
00007d55df7d4d38  vmovaps [rsp+0xE0], xmm15
00007d55df7d4d41  sub rsp, 0x30
00007d55df7d4d45  movaps [rsp], xmm13
00007d55df7d4d4a  movaps [rsp+0x10], xmm1
00007d55df7d4d4f  movaps [rsp+0x20], xmm15
00007d55df7d4d55  lea rdi, [rsp]
00007d55df7d4d59  mov esi, 0x00
00007d55df7d4d5e  mov rax, 0x5BB8433D8530
00007d55df7d4d68  call rax
00007d55df7d4d6a  movaps xmm13, [rsp]
00007d55df7d4d6f  add rsp, 0x30
00007d55df7d4d73  vmovaps xmm0, [rsp]
00007d55df7d4d78  vmovaps xmm1, [rsp+0x10]
00007d55df7d4d7e  vmovaps xmm2, [rsp+0x20]
00007d55df7d4d84  vmovaps xmm3, [rsp+0x30]
00007d55df7d4d8a  vmovaps xmm4, [rsp+0x40]
00007d55df7d4d90  vmovaps xmm5, [rsp+0x50]
00007d55df7d4d96  vmovaps xmm6, [rsp+0x60]
00007d55df7d4d9c  vmovaps xmm7, [rsp+0x70]
00007d55df7d4da2  vmovaps xmm8, [rsp+0x80]
00007d55df7d4dab  vmovaps xmm9, [rsp+0x90]
00007d55df7d4db4  vmovaps xmm10, [rsp+0xA0]
00007d55df7d4dbd  vmovaps xmm11, [rsp+0xB0]
00007d55df7d4dc6  vmovaps xmm12, [rsp+0xC0]
00007d55df7d4dcf  vmovaps xmm14, [rsp+0xD0]
00007d55df7d4dd8  vmovaps xmm15, [rsp+0xE0]
00007d55df7d4de1  add rsp, 0xF0
00007d55df7d4de8  pop r11
00007d55df7d4dea  pop r10
00007d55df7d4dec  pop r9
00007d55df7d4dee  pop r8
00007d55df7d4df0  pop rsi
00007d55df7d4df1  pop rdi
00007d55df7d4df2  pop rdx
00007d55df7d4df3  pop rcx
00007d55df7d4df4  pop rax
00007d55df7d4df5  add rsp, 0x08
00007d55df7d4df9  jmp 0x00007D55DF7D2CD6
00007d55df7d4dfe  sub rsp, 0x08
00007d55df7d4e02  push rax
00007d55df7d4e03  push rcx
00007d55df7d4e04  push rdx
00007d55df7d4e05  push rdi
00007d55df7d4e06  push rsi
00007d55df7d4e07  push r8
00007d55df7d4e09  push r9
00007d55df7d4e0b  push r10
00007d55df7d4e0d  push r11
00007d55df7d4e0f  sub rsp, 0xF0
00007d55df7d4e16  vmovaps [rsp], xmm0
00007d55df7d4e1b  vmovaps [rsp+0x10], xmm1
00007d55df7d4e21  vmovaps [rsp+0x20], xmm2
00007d55df7d4e27  vmovaps [rsp+0x30], xmm3
00007d55df7d4e2d  vmovaps [rsp+0x40], xmm4
00007d55df7d4e33  vmovaps [rsp+0x50], xmm5
00007d55df7d4e39  vmovaps [rsp+0x60], xmm6
00007d55df7d4e3f  vmovaps [rsp+0x70], xmm7
00007d55df7d4e45  vmovaps [rsp+0x80], xmm8
00007d55df7d4e4e  vmovaps [rsp+0x90], xmm9
00007d55df7d4e57  vmovaps [rsp+0xA0], xmm10
00007d55df7d4e60  vmovaps [rsp+0xB0], xmm11
00007d55df7d4e69  vmovaps [rsp+0xC0], xmm12
00007d55df7d4e72  vmovaps [rsp+0xD0], xmm13
00007d55df7d4e7b  vmovaps [rsp+0xE0], xmm14
00007d55df7d4e84  sub rsp, 0x30
00007d55df7d4e88  movaps [rsp], xmm15
00007d55df7d4e8d  movaps [rsp+0x10], xmm14
00007d55df7d4e93  movaps [rsp+0x20], xmm1
00007d55df7d4e98  lea rdi, [rsp]
00007d55df7d4e9c  mov esi, 0x00
00007d55df7d4ea1  mov rax, 0x5BB8433D8530
00007d55df7d4eab  call rax
00007d55df7d4ead  movaps xmm15, [rsp]
00007d55df7d4eb2  add rsp, 0x30
00007d55df7d4eb6  vmovaps xmm0, [rsp]
00007d55df7d4ebb  vmovaps xmm1, [rsp+0x10]
00007d55df7d4ec1  vmovaps xmm2, [rsp+0x20]
00007d55df7d4ec7  vmovaps xmm3, [rsp+0x30]
00007d55df7d4ecd  vmovaps xmm4, [rsp+0x40]
00007d55df7d4ed3  vmovaps xmm5, [rsp+0x50]
00007d55df7d4ed9  vmovaps xmm6, [rsp+0x60]
00007d55df7d4edf  vmovaps xmm7, [rsp+0x70]
00007d55df7d4ee5  vmovaps xmm8, [rsp+0x80]
00007d55df7d4eee  vmovaps xmm9, [rsp+0x90]
00007d55df7d4ef7  vmovaps xmm10, [rsp+0xA0]
00007d55df7d4f00  vmovaps xmm11, [rsp+0xB0]
00007d55df7d4f09  vmovaps xmm12, [rsp+0xC0]
00007d55df7d4f12  vmovaps xmm13, [rsp+0xD0]
00007d55df7d4f1b  vmovaps xmm14, [rsp+0xE0]
00007d55df7d4f24  add rsp, 0xF0
00007d55df7d4f2b  pop r11
00007d55df7d4f2d  pop r10
00007d55df7d4f2f  pop r9
00007d55df7d4f31  pop r8
00007d55df7d4f33  pop rsi
00007d55df7d4f34  pop rdi
00007d55df7d4f35  pop rdx
00007d55df7d4f36  pop rcx
00007d55df7d4f37  pop rax
00007d55df7d4f38  add rsp, 0x08
00007d55df7d4f3c  jmp 0x00007D55DF7D2D12
00007d55df7d4f41  call 0x00007D55DF5FF430
00007d55df7d4f46  jmp 0x00007D55DF7D2D1F
00007d55df7d4f4b  sub rsp, 0x08
00007d55df7d4f4f  push rax
00007d55df7d4f50  push rcx
00007d55df7d4f51  push rdx
00007d55df7d4f52  push rdi
00007d55df7d4f53  push rsi
00007d55df7d4f54  push r8
00007d55df7d4f56  push r9
00007d55df7d4f58  push r10
00007d55df7d4f5a  push r11
00007d55df7d4f5c  sub rsp, 0xF0
00007d55df7d4f63  vmovaps [rsp], xmm0
00007d55df7d4f68  vmovaps [rsp+0x10], xmm1
00007d55df7d4f6e  vmovaps [rsp+0x20], xmm2
00007d55df7d4f74  vmovaps [rsp+0x30], xmm3
00007d55df7d4f7a  vmovaps [rsp+0x40], xmm4
00007d55df7d4f80  vmovaps [rsp+0x50], xmm5
00007d55df7d4f86  vmovaps [rsp+0x60], xmm6
00007d55df7d4f8c  vmovaps [rsp+0x70], xmm7
00007d55df7d4f92  vmovaps [rsp+0x80], xmm8
00007d55df7d4f9b  vmovaps [rsp+0x90], xmm9
00007d55df7d4fa4  vmovaps [rsp+0xA0], xmm10
00007d55df7d4fad  vmovaps [rsp+0xB0], xmm11
00007d55df7d4fb6  vmovaps [rsp+0xC0], xmm12
00007d55df7d4fbf  vmovaps [rsp+0xD0], xmm13
00007d55df7d4fc8  vmovaps [rsp+0xE0], xmm15
00007d55df7d4fd1  sub rsp, 0x30
00007d55df7d4fd5  movaps [rsp], xmm14
00007d55df7d4fda  movaps [rsp+0x10], xmm13
00007d55df7d4fe0  movaps [rsp+0x20], xmm2
00007d55df7d4fe5  lea rdi, [rsp]
00007d55df7d4fe9  mov esi, 0x00
00007d55df7d4fee  mov rax, 0x5BB8433D8530
00007d55df7d4ff8  call rax
00007d55df7d4ffa  movaps xmm14, [rsp]
00007d55df7d4fff  add rsp, 0x30
00007d55df7d5003  vmovaps xmm0, [rsp]
00007d55df7d5008  vmovaps xmm1, [rsp+0x10]
00007d55df7d500e  vmovaps xmm2, [rsp+0x20]
00007d55df7d5014  vmovaps xmm3, [rsp+0x30]
00007d55df7d501a  vmovaps xmm4, [rsp+0x40]
00007d55df7d5020  vmovaps xmm5, [rsp+0x50]
00007d55df7d5026  vmovaps xmm6, [rsp+0x60]
00007d55df7d502c  vmovaps xmm7, [rsp+0x70]
00007d55df7d5032  vmovaps xmm8, [rsp+0x80]
00007d55df7d503b  vmovaps xmm9, [rsp+0x90]
00007d55df7d5044  vmovaps xmm10, [rsp+0xA0]
00007d55df7d504d  vmovaps xmm11, [rsp+0xB0]
00007d55df7d5056  vmovaps xmm12, [rsp+0xC0]
00007d55df7d505f  vmovaps xmm13, [rsp+0xD0]
00007d55df7d5068  vmovaps xmm15, [rsp+0xE0]
00007d55df7d5071  add rsp, 0xF0
00007d55df7d5078  pop r11
00007d55df7d507a  pop r10
00007d55df7d507c  pop r9
00007d55df7d507e  pop r8
00007d55df7d5080  pop rsi
00007d55df7d5081  pop rdi
00007d55df7d5082  pop rdx
00007d55df7d5083  pop rcx
00007d55df7d5084  pop rax
00007d55df7d5085  add rsp, 0x08
00007d55df7d5089  jmp 0x00007D55DF7D2D4B
00007d55df7d508e  sub rsp, 0x08
00007d55df7d5092  push rax
00007d55df7d5093  push rcx
00007d55df7d5094  push rdx
00007d55df7d5095  push rdi
00007d55df7d5096  push rsi
00007d55df7d5097  push r8
00007d55df7d5099  push r9
00007d55df7d509b  push r10
00007d55df7d509d  push r11
00007d55df7d509f  sub rsp, 0xF0
00007d55df7d50a6  vmovaps [rsp], xmm0
00007d55df7d50ab  vmovaps [rsp+0x10], xmm2
00007d55df7d50b1  vmovaps [rsp+0x20], xmm3
00007d55df7d50b7  vmovaps [rsp+0x30], xmm4
00007d55df7d50bd  vmovaps [rsp+0x40], xmm5
00007d55df7d50c3  vmovaps [rsp+0x50], xmm6
00007d55df7d50c9  vmovaps [rsp+0x60], xmm7
00007d55df7d50cf  vmovaps [rsp+0x70], xmm8
00007d55df7d50d5  vmovaps [rsp+0x80], xmm9
00007d55df7d50de  vmovaps [rsp+0x90], xmm10
00007d55df7d50e7  vmovaps [rsp+0xA0], xmm11
00007d55df7d50f0  vmovaps [rsp+0xB0], xmm12
00007d55df7d50f9  vmovaps [rsp+0xC0], xmm13
00007d55df7d5102  vmovaps [rsp+0xD0], xmm14
00007d55df7d510b  vmovaps [rsp+0xE0], xmm15
00007d55df7d5114  sub rsp, 0x30
00007d55df7d5118  movaps [rsp], xmm1
00007d55df7d511c  movaps [rsp+0x10], xmm13
00007d55df7d5122  movaps [rsp+0x20], xmm2
00007d55df7d5127  lea rdi, [rsp]
00007d55df7d512b  mov esi, 0x00
00007d55df7d5130  mov rax, 0x5BB8433D8530
00007d55df7d513a  call rax
00007d55df7d513c  movaps xmm1, [rsp]
00007d55df7d5140  add rsp, 0x30
00007d55df7d5144  vmovaps xmm0, [rsp]
00007d55df7d5149  vmovaps xmm2, [rsp+0x10]
00007d55df7d514f  vmovaps xmm3, [rsp+0x20]
00007d55df7d5155  vmovaps xmm4, [rsp+0x30]
00007d55df7d515b  vmovaps xmm5, [rsp+0x40]
00007d55df7d5161  vmovaps xmm6, [rsp+0x50]
00007d55df7d5167  vmovaps xmm7, [rsp+0x60]
00007d55df7d516d  vmovaps xmm8, [rsp+0x70]
00007d55df7d5173  vmovaps xmm9, [rsp+0x80]
00007d55df7d517c  vmovaps xmm10, [rsp+0x90]
00007d55df7d5185  vmovaps xmm11, [rsp+0xA0]
00007d55df7d518e  vmovaps xmm12, [rsp+0xB0]
00007d55df7d5197  vmovaps xmm13, [rsp+0xC0]
00007d55df7d51a0  vmovaps xmm14, [rsp+0xD0]
00007d55df7d51a9  vmovaps xmm15, [rsp+0xE0]
00007d55df7d51b2  add rsp, 0xF0
00007d55df7d51b9  pop r11
00007d55df7d51bb  pop r10
00007d55df7d51bd  pop r9
00007d55df7d51bf  pop r8
00007d55df7d51c1  pop rsi
00007d55df7d51c2  pop rdi
00007d55df7d51c3  pop rdx
00007d55df7d51c4  pop rcx
00007d55df7d51c5  pop rax
00007d55df7d51c6  add rsp, 0x08
00007d55df7d51ca  jmp 0x00007D55DF7D2D79
00007d55df7d51cf  sub rsp, 0x08
00007d55df7d51d3  push rax
00007d55df7d51d4  push rcx
00007d55df7d51d5  push rdx
00007d55df7d51d6  push rdi
00007d55df7d51d7  push rsi
00007d55df7d51d8  push r8
00007d55df7d51da  push r9
00007d55df7d51dc  push r10
00007d55df7d51de  push r11
00007d55df7d51e0  sub rsp, 0xF0
00007d55df7d51e7  vmovaps [rsp], xmm0
00007d55df7d51ec  vmovaps [rsp+0x10], xmm1
00007d55df7d51f2  vmovaps [rsp+0x20], xmm3
00007d55df7d51f8  vmovaps [rsp+0x30], xmm4
00007d55df7d51fe  vmovaps [rsp+0x40], xmm5
00007d55df7d5204  vmovaps [rsp+0x50], xmm6
00007d55df7d520a  vmovaps [rsp+0x60], xmm7
00007d55df7d5210  vmovaps [rsp+0x70], xmm8
00007d55df7d5216  vmovaps [rsp+0x80], xmm9
00007d55df7d521f  vmovaps [rsp+0x90], xmm10
00007d55df7d5228  vmovaps [rsp+0xA0], xmm11
00007d55df7d5231  vmovaps [rsp+0xB0], xmm12
00007d55df7d523a  vmovaps [rsp+0xC0], xmm13
00007d55df7d5243  vmovaps [rsp+0xD0], xmm14
00007d55df7d524c  vmovaps [rsp+0xE0], xmm15
00007d55df7d5255  sub rsp, 0x30
00007d55df7d5259  movaps [rsp], xmm2
00007d55df7d525d  movaps [rsp+0x10], xmm1
00007d55df7d5262  movaps [rsp+0x20], xmm13
00007d55df7d5268  lea rdi, [rsp]
00007d55df7d526c  mov esi, 0x00
00007d55df7d5271  mov rax, 0x5BB8433D8530
00007d55df7d527b  call rax
00007d55df7d527d  movaps xmm2, [rsp]
00007d55df7d5281  add rsp, 0x30
00007d55df7d5285  vmovaps xmm0, [rsp]
00007d55df7d528a  vmovaps xmm1, [rsp+0x10]
00007d55df7d5290  vmovaps xmm3, [rsp+0x20]
00007d55df7d5296  vmovaps xmm4, [rsp+0x30]
00007d55df7d529c  vmovaps xmm5, [rsp+0x40]
00007d55df7d52a2  vmovaps xmm6, [rsp+0x50]
00007d55df7d52a8  vmovaps xmm7, [rsp+0x60]
00007d55df7d52ae  vmovaps xmm8, [rsp+0x70]
00007d55df7d52b4  vmovaps xmm9, [rsp+0x80]
00007d55df7d52bd  vmovaps xmm10, [rsp+0x90]
00007d55df7d52c6  vmovaps xmm11, [rsp+0xA0]
00007d55df7d52cf  vmovaps xmm12, [rsp+0xB0]
00007d55df7d52d8  vmovaps xmm13, [rsp+0xC0]
00007d55df7d52e1  vmovaps xmm14, [rsp+0xD0]
00007d55df7d52ea  vmovaps xmm15, [rsp+0xE0]
00007d55df7d52f3  add rsp, 0xF0
00007d55df7d52fa  pop r11
00007d55df7d52fc  pop r10
00007d55df7d52fe  pop r9
00007d55df7d5300  pop r8
00007d55df7d5302  pop rsi
00007d55df7d5303  pop rdi
00007d55df7d5304  pop rdx
00007d55df7d5305  pop rcx
00007d55df7d5306  pop rax
00007d55df7d5307  add rsp, 0x08
00007d55df7d530b  jmp 0x00007D55DF7D2DD2
00007d55df7d5310  call 0x00007D55DF5FF430
00007d55df7d5315  jmp 0x00007D55DF7D2DDF
00007d55df7d531a  sub rsp, 0x08
00007d55df7d531e  push rax
00007d55df7d531f  push rcx
00007d55df7d5320  push rdx
00007d55df7d5321  push rdi
00007d55df7d5322  push rsi
00007d55df7d5323  push r8
00007d55df7d5325  push r9
00007d55df7d5327  push r10
00007d55df7d5329  push r11
00007d55df7d532b  sub rsp, 0xF0
00007d55df7d5332  vmovaps [rsp], xmm0
00007d55df7d5337  vmovaps [rsp+0x10], xmm1
00007d55df7d533d  vmovaps [rsp+0x20], xmm2
00007d55df7d5343  vmovaps [rsp+0x30], xmm3
00007d55df7d5349  vmovaps [rsp+0x40], xmm4
00007d55df7d534f  vmovaps [rsp+0x50], xmm5
00007d55df7d5355  vmovaps [rsp+0x60], xmm6
00007d55df7d535b  vmovaps [rsp+0x70], xmm7
00007d55df7d5361  vmovaps [rsp+0x80], xmm8
00007d55df7d536a  vmovaps [rsp+0x90], xmm9
00007d55df7d5373  vmovaps [rsp+0xA0], xmm10
00007d55df7d537c  vmovaps [rsp+0xB0], xmm11
00007d55df7d5385  vmovaps [rsp+0xC0], xmm12
00007d55df7d538e  vmovaps [rsp+0xD0], xmm13
00007d55df7d5397  vmovaps [rsp+0xE0], xmm14
00007d55df7d53a0  sub rsp, 0x30
00007d55df7d53a4  movaps [rsp], xmm15
00007d55df7d53a9  movaps [rsp+0x10], xmm13
00007d55df7d53af  movaps [rsp+0x20], xmm1
00007d55df7d53b4  lea rdi, [rsp]
00007d55df7d53b8  mov esi, 0x00
00007d55df7d53bd  mov rax, 0x5BB8433D8530
00007d55df7d53c7  call rax
00007d55df7d53c9  movaps xmm15, [rsp]
00007d55df7d53ce  add rsp, 0x30
00007d55df7d53d2  vmovaps xmm0, [rsp]
00007d55df7d53d7  vmovaps xmm1, [rsp+0x10]
00007d55df7d53dd  vmovaps xmm2, [rsp+0x20]
00007d55df7d53e3  vmovaps xmm3, [rsp+0x30]
00007d55df7d53e9  vmovaps xmm4, [rsp+0x40]
00007d55df7d53ef  vmovaps xmm5, [rsp+0x50]
00007d55df7d53f5  vmovaps xmm6, [rsp+0x60]
00007d55df7d53fb  vmovaps xmm7, [rsp+0x70]
00007d55df7d5401  vmovaps xmm8, [rsp+0x80]
00007d55df7d540a  vmovaps xmm9, [rsp+0x90]
00007d55df7d5413  vmovaps xmm10, [rsp+0xA0]
00007d55df7d541c  vmovaps xmm11, [rsp+0xB0]
00007d55df7d5425  vmovaps xmm12, [rsp+0xC0]
00007d55df7d542e  vmovaps xmm13, [rsp+0xD0]
00007d55df7d5437  vmovaps xmm14, [rsp+0xE0]
00007d55df7d5440  add rsp, 0xF0
00007d55df7d5447  pop r11
00007d55df7d5449  pop r10
00007d55df7d544b  pop r9
00007d55df7d544d  pop r8
00007d55df7d544f  pop rsi
00007d55df7d5450  pop rdi
00007d55df7d5451  pop rdx
00007d55df7d5452  pop rcx
00007d55df7d5453  pop rax
00007d55df7d5454  add rsp, 0x08
00007d55df7d5458  jmp 0x00007D55DF7D2E1E
00007d55df7d545d  sub rsp, 0x08
00007d55df7d5461  push rax
00007d55df7d5462  push rcx
00007d55df7d5463  push rdx
00007d55df7d5464  push rdi
00007d55df7d5465  push rsi
00007d55df7d5466  push r8
00007d55df7d5468  push r9
00007d55df7d546a  push r10
00007d55df7d546c  push r11
00007d55df7d546e  sub rsp, 0xF0
00007d55df7d5475  vmovaps [rsp], xmm0
00007d55df7d547a  vmovaps [rsp+0x10], xmm1
00007d55df7d5480  vmovaps [rsp+0x20], xmm2
00007d55df7d5486  vmovaps [rsp+0x30], xmm3
00007d55df7d548c  vmovaps [rsp+0x40], xmm4
00007d55df7d5492  vmovaps [rsp+0x50], xmm5
00007d55df7d5498  vmovaps [rsp+0x60], xmm6
00007d55df7d549e  vmovaps [rsp+0x70], xmm7
00007d55df7d54a4  vmovaps [rsp+0x80], xmm8
00007d55df7d54ad  vmovaps [rsp+0x90], xmm9
00007d55df7d54b6  vmovaps [rsp+0xA0], xmm10
00007d55df7d54bf  vmovaps [rsp+0xB0], xmm11
00007d55df7d54c8  vmovaps [rsp+0xC0], xmm12
00007d55df7d54d1  vmovaps [rsp+0xD0], xmm13
00007d55df7d54da  vmovaps [rsp+0xE0], xmm15
00007d55df7d54e3  sub rsp, 0x30
00007d55df7d54e7  movaps [rsp], xmm14
00007d55df7d54ec  movaps [rsp+0x10], xmm11
00007d55df7d54f2  movaps [rsp+0x20], xmm1
00007d55df7d54f7  lea rdi, [rsp]
00007d55df7d54fb  mov esi, 0x00
00007d55df7d5500  mov rax, 0x5BB8433D8530
00007d55df7d550a  call rax
00007d55df7d550c  movaps xmm14, [rsp]
00007d55df7d5511  add rsp, 0x30
00007d55df7d5515  vmovaps xmm0, [rsp]
00007d55df7d551a  vmovaps xmm1, [rsp+0x10]
00007d55df7d5520  vmovaps xmm2, [rsp+0x20]
00007d55df7d5526  vmovaps xmm3, [rsp+0x30]
00007d55df7d552c  vmovaps xmm4, [rsp+0x40]
00007d55df7d5532  vmovaps xmm5, [rsp+0x50]
00007d55df7d5538  vmovaps xmm6, [rsp+0x60]
00007d55df7d553e  vmovaps xmm7, [rsp+0x70]
00007d55df7d5544  vmovaps xmm8, [rsp+0x80]
00007d55df7d554d  vmovaps xmm9, [rsp+0x90]
00007d55df7d5556  vmovaps xmm10, [rsp+0xA0]
00007d55df7d555f  vmovaps xmm11, [rsp+0xB0]
00007d55df7d5568  vmovaps xmm12, [rsp+0xC0]
00007d55df7d5571  vmovaps xmm13, [rsp+0xD0]
00007d55df7d557a  vmovaps xmm15, [rsp+0xE0]
00007d55df7d5583  add rsp, 0xF0
00007d55df7d558a  pop r11
00007d55df7d558c  pop r10
00007d55df7d558e  pop r9
00007d55df7d5590  pop r8
00007d55df7d5592  pop rsi
00007d55df7d5593  pop rdi
00007d55df7d5594  pop rdx
00007d55df7d5595  pop rcx
00007d55df7d5596  pop rax
00007d55df7d5597  add rsp, 0x08
00007d55df7d559b  jmp 0x00007D55DF7D2E48
00007d55df7d55a0  sub rsp, 0x08
00007d55df7d55a4  push rax
00007d55df7d55a5  push rcx
00007d55df7d55a6  push rdx
00007d55df7d55a7  push rdi
00007d55df7d55a8  push rsi
00007d55df7d55a9  push r8
00007d55df7d55ab  push r9
00007d55df7d55ad  push r10
00007d55df7d55af  push r11
00007d55df7d55b1  sub rsp, 0xF0
00007d55df7d55b8  vmovaps [rsp], xmm0
00007d55df7d55bd  vmovaps [rsp+0x10], xmm1
00007d55df7d55c3  vmovaps [rsp+0x20], xmm2
00007d55df7d55c9  vmovaps [rsp+0x30], xmm3
00007d55df7d55cf  vmovaps [rsp+0x40], xmm4
00007d55df7d55d5  vmovaps [rsp+0x50], xmm5
00007d55df7d55db  vmovaps [rsp+0x60], xmm6
00007d55df7d55e1  vmovaps [rsp+0x70], xmm7
00007d55df7d55e7  vmovaps [rsp+0x80], xmm8
00007d55df7d55f0  vmovaps [rsp+0x90], xmm9
00007d55df7d55f9  vmovaps [rsp+0xA0], xmm10
00007d55df7d5602  vmovaps [rsp+0xB0], xmm11
00007d55df7d560b  vmovaps [rsp+0xC0], xmm12
00007d55df7d5614  vmovaps [rsp+0xD0], xmm14
00007d55df7d561d  vmovaps [rsp+0xE0], xmm15
00007d55df7d5626  sub rsp, 0x30
00007d55df7d562a  movaps [rsp], xmm13
00007d55df7d562f  movaps [rsp+0x10], xmm11
00007d55df7d5635  movaps [rsp+0x20], xmm1
00007d55df7d563a  lea rdi, [rsp]
00007d55df7d563e  mov esi, 0x00
00007d55df7d5643  mov rax, 0x5BB8433D8530
00007d55df7d564d  call rax
00007d55df7d564f  movaps xmm13, [rsp]
00007d55df7d5654  add rsp, 0x30
00007d55df7d5658  vmovaps xmm0, [rsp]
00007d55df7d565d  vmovaps xmm1, [rsp+0x10]
00007d55df7d5663  vmovaps xmm2, [rsp+0x20]
00007d55df7d5669  vmovaps xmm3, [rsp+0x30]
00007d55df7d566f  vmovaps xmm4, [rsp+0x40]
00007d55df7d5675  vmovaps xmm5, [rsp+0x50]
00007d55df7d567b  vmovaps xmm6, [rsp+0x60]
00007d55df7d5681  vmovaps xmm7, [rsp+0x70]
00007d55df7d5687  vmovaps xmm8, [rsp+0x80]
00007d55df7d5690  vmovaps xmm9, [rsp+0x90]
00007d55df7d5699  vmovaps xmm10, [rsp+0xA0]
00007d55df7d56a2  vmovaps xmm11, [rsp+0xB0]
00007d55df7d56ab  vmovaps xmm12, [rsp+0xC0]
00007d55df7d56b4  vmovaps xmm14, [rsp+0xD0]
00007d55df7d56bd  vmovaps xmm15, [rsp+0xE0]
00007d55df7d56c6  add rsp, 0xF0
00007d55df7d56cd  pop r11
00007d55df7d56cf  pop r10
00007d55df7d56d1  pop r9
00007d55df7d56d3  pop r8
00007d55df7d56d5  pop rsi
00007d55df7d56d6  pop rdi
00007d55df7d56d7  pop rdx
00007d55df7d56d8  pop rcx
00007d55df7d56d9  pop rax
00007d55df7d56da  add rsp, 0x08
00007d55df7d56de  jmp 0x00007D55DF7D2E9D
00007d55df7d56e3  call 0x00007D55DF5FF430
00007d55df7d56e8  jmp 0x00007D55DF7D2EAA
00007d55df7d56ed  sub rsp, 0x08
00007d55df7d56f1  push rax
00007d55df7d56f2  push rcx
00007d55df7d56f3  push rdx
00007d55df7d56f4  push rdi
00007d55df7d56f5  push rsi
00007d55df7d56f6  push r8
00007d55df7d56f8  push r9
00007d55df7d56fa  push r10
00007d55df7d56fc  push r11
00007d55df7d56fe  sub rsp, 0xF0
00007d55df7d5705  vmovaps [rsp], xmm0
00007d55df7d570a  vmovaps [rsp+0x10], xmm1
00007d55df7d5710  vmovaps [rsp+0x20], xmm2
00007d55df7d5716  vmovaps [rsp+0x30], xmm3
00007d55df7d571c  vmovaps [rsp+0x40], xmm4
00007d55df7d5722  vmovaps [rsp+0x50], xmm5
00007d55df7d5728  vmovaps [rsp+0x60], xmm6
00007d55df7d572e  vmovaps [rsp+0x70], xmm7
00007d55df7d5734  vmovaps [rsp+0x80], xmm8
00007d55df7d573d  vmovaps [rsp+0x90], xmm9
00007d55df7d5746  vmovaps [rsp+0xA0], xmm10
00007d55df7d574f  vmovaps [rsp+0xB0], xmm11
00007d55df7d5758  vmovaps [rsp+0xC0], xmm12
00007d55df7d5761  vmovaps [rsp+0xD0], xmm13
00007d55df7d576a  vmovaps [rsp+0xE0], xmm14
00007d55df7d5773  sub rsp, 0x30
00007d55df7d5777  movaps [rsp], xmm15
00007d55df7d577c  movaps [rsp+0x10], xmm11
00007d55df7d5782  movaps [rsp+0x20], xmm1
00007d55df7d5787  lea rdi, [rsp]
00007d55df7d578b  mov esi, 0x00
00007d55df7d5790  mov rax, 0x5BB8433D8530
00007d55df7d579a  call rax
00007d55df7d579c  movaps xmm15, [rsp]
00007d55df7d57a1  add rsp, 0x30
00007d55df7d57a5  vmovaps xmm0, [rsp]
00007d55df7d57aa  vmovaps xmm1, [rsp+0x10]
00007d55df7d57b0  vmovaps xmm2, [rsp+0x20]
00007d55df7d57b6  vmovaps xmm3, [rsp+0x30]
00007d55df7d57bc  vmovaps xmm4, [rsp+0x40]
00007d55df7d57c2  vmovaps xmm5, [rsp+0x50]
00007d55df7d57c8  vmovaps xmm6, [rsp+0x60]
00007d55df7d57ce  vmovaps xmm7, [rsp+0x70]
00007d55df7d57d4  vmovaps xmm8, [rsp+0x80]
00007d55df7d57dd  vmovaps xmm9, [rsp+0x90]
00007d55df7d57e6  vmovaps xmm10, [rsp+0xA0]
00007d55df7d57ef  vmovaps xmm11, [rsp+0xB0]
00007d55df7d57f8  vmovaps xmm12, [rsp+0xC0]
00007d55df7d5801  vmovaps xmm13, [rsp+0xD0]
00007d55df7d580a  vmovaps xmm14, [rsp+0xE0]
00007d55df7d5813  add rsp, 0xF0
00007d55df7d581a  pop r11
00007d55df7d581c  pop r10
00007d55df7d581e  pop r9
00007d55df7d5820  pop r8
00007d55df7d5822  pop rsi
00007d55df7d5823  pop rdi
00007d55df7d5824  pop rdx
00007d55df7d5825  pop rcx
00007d55df7d5826  pop rax
00007d55df7d5827  add rsp, 0x08
00007d55df7d582b  jmp 0x00007D55DF7D2EE3
00007d55df7d5830  sub rsp, 0x08
00007d55df7d5834  push rax
00007d55df7d5835  push rcx
00007d55df7d5836  push rdx
00007d55df7d5837  push rdi
00007d55df7d5838  push rsi
00007d55df7d5839  push r8
00007d55df7d583b  push r9
00007d55df7d583d  push r10
00007d55df7d583f  push r11
00007d55df7d5841  sub rsp, 0xF0
00007d55df7d5848  vmovaps [rsp], xmm0
00007d55df7d584d  vmovaps [rsp+0x10], xmm1
00007d55df7d5853  vmovaps [rsp+0x20], xmm2
00007d55df7d5859  vmovaps [rsp+0x30], xmm3
00007d55df7d585f  vmovaps [rsp+0x40], xmm4
00007d55df7d5865  vmovaps [rsp+0x50], xmm5
00007d55df7d586b  vmovaps [rsp+0x60], xmm6
00007d55df7d5871  vmovaps [rsp+0x70], xmm7
00007d55df7d5877  vmovaps [rsp+0x80], xmm8
00007d55df7d5880  vmovaps [rsp+0x90], xmm9
00007d55df7d5889  vmovaps [rsp+0xA0], xmm10
00007d55df7d5892  vmovaps [rsp+0xB0], xmm12
00007d55df7d589b  vmovaps [rsp+0xC0], xmm13
00007d55df7d58a4  vmovaps [rsp+0xD0], xmm14
00007d55df7d58ad  vmovaps [rsp+0xE0], xmm15
00007d55df7d58b6  sub rsp, 0x30
00007d55df7d58ba  movaps [rsp], xmm11
00007d55df7d58bf  movaps [rsp+0x10], xmm6
00007d55df7d58c4  movaps [rsp+0x20], xmm14
00007d55df7d58ca  lea rdi, [rsp]
00007d55df7d58ce  mov esi, 0x00
00007d55df7d58d3  mov rax, 0x5BB8433D8530
00007d55df7d58dd  call rax
00007d55df7d58df  movaps xmm11, [rsp]
00007d55df7d58e4  add rsp, 0x30
00007d55df7d58e8  vmovaps xmm0, [rsp]
00007d55df7d58ed  vmovaps xmm1, [rsp+0x10]
00007d55df7d58f3  vmovaps xmm2, [rsp+0x20]
00007d55df7d58f9  vmovaps xmm3, [rsp+0x30]
00007d55df7d58ff  vmovaps xmm4, [rsp+0x40]
00007d55df7d5905  vmovaps xmm5, [rsp+0x50]
00007d55df7d590b  vmovaps xmm6, [rsp+0x60]
00007d55df7d5911  vmovaps xmm7, [rsp+0x70]
00007d55df7d5917  vmovaps xmm8, [rsp+0x80]
00007d55df7d5920  vmovaps xmm9, [rsp+0x90]
00007d55df7d5929  vmovaps xmm10, [rsp+0xA0]
00007d55df7d5932  vmovaps xmm12, [rsp+0xB0]
00007d55df7d593b  vmovaps xmm13, [rsp+0xC0]
00007d55df7d5944  vmovaps xmm14, [rsp+0xD0]
00007d55df7d594d  vmovaps xmm15, [rsp+0xE0]
00007d55df7d5956  add rsp, 0xF0
00007d55df7d595d  pop r11
00007d55df7d595f  pop r10
00007d55df7d5961  pop r9
00007d55df7d5963  pop r8
00007d55df7d5965  pop rsi
00007d55df7d5966  pop rdi
00007d55df7d5967  pop rdx
00007d55df7d5968  pop rcx
00007d55df7d5969  pop rax
00007d55df7d596a  add rsp, 0x08
00007d55df7d596e  jmp 0x00007D55DF7D2F5B
00007d55df7d5973  call 0x00007D55DF5FF430
00007d55df7d5978  jmp 0x00007D55DF7D2F65
00007d55df7d597d  sub rsp, 0x08
00007d55df7d5981  push rax
00007d55df7d5982  push rcx
00007d55df7d5983  push rdx
00007d55df7d5984  push rdi
00007d55df7d5985  push rsi
00007d55df7d5986  push r8
00007d55df7d5988  push r9
00007d55df7d598a  push r10
00007d55df7d598c  push r11
00007d55df7d598e  sub rsp, 0xF0
00007d55df7d5995  vmovaps [rsp], xmm0
00007d55df7d599a  vmovaps [rsp+0x10], xmm1
00007d55df7d59a0  vmovaps [rsp+0x20], xmm2
00007d55df7d59a6  vmovaps [rsp+0x30], xmm3
00007d55df7d59ac  vmovaps [rsp+0x40], xmm4
00007d55df7d59b2  vmovaps [rsp+0x50], xmm5
00007d55df7d59b8  vmovaps [rsp+0x60], xmm6
00007d55df7d59be  vmovaps [rsp+0x70], xmm7
00007d55df7d59c4  vmovaps [rsp+0x80], xmm8
00007d55df7d59cd  vmovaps [rsp+0x90], xmm9
00007d55df7d59d6  vmovaps [rsp+0xA0], xmm10
00007d55df7d59df  vmovaps [rsp+0xB0], xmm11
00007d55df7d59e8  vmovaps [rsp+0xC0], xmm12
00007d55df7d59f1  vmovaps [rsp+0xD0], xmm13
00007d55df7d59fa  vmovaps [rsp+0xE0], xmm15
00007d55df7d5a03  sub rsp, 0x30
00007d55df7d5a07  movaps [rsp], xmm14
00007d55df7d5a0c  movaps [rsp+0x10], xmm6
00007d55df7d5a11  movaps [rsp+0x20], xmm2
00007d55df7d5a16  lea rdi, [rsp]
00007d55df7d5a1a  mov esi, 0x00
00007d55df7d5a1f  mov rax, 0x5BB8433D8530
00007d55df7d5a29  call rax
00007d55df7d5a2b  movaps xmm14, [rsp]
00007d55df7d5a30  add rsp, 0x30
00007d55df7d5a34  vmovaps xmm0, [rsp]
00007d55df7d5a39  vmovaps xmm1, [rsp+0x10]
00007d55df7d5a3f  vmovaps xmm2, [rsp+0x20]
00007d55df7d5a45  vmovaps xmm3, [rsp+0x30]
00007d55df7d5a4b  vmovaps xmm4, [rsp+0x40]
00007d55df7d5a51  vmovaps xmm5, [rsp+0x50]
00007d55df7d5a57  vmovaps xmm6, [rsp+0x60]
00007d55df7d5a5d  vmovaps xmm7, [rsp+0x70]
00007d55df7d5a63  vmovaps xmm8, [rsp+0x80]
00007d55df7d5a6c  vmovaps xmm9, [rsp+0x90]
00007d55df7d5a75  vmovaps xmm10, [rsp+0xA0]
00007d55df7d5a7e  vmovaps xmm11, [rsp+0xB0]
00007d55df7d5a87  vmovaps xmm12, [rsp+0xC0]
00007d55df7d5a90  vmovaps xmm13, [rsp+0xD0]
00007d55df7d5a99  vmovaps xmm15, [rsp+0xE0]
00007d55df7d5aa2  add rsp, 0xF0
00007d55df7d5aa9  pop r11
00007d55df7d5aab  pop r10
00007d55df7d5aad  pop r9
00007d55df7d5aaf  pop r8
00007d55df7d5ab1  pop rsi
00007d55df7d5ab2  pop rdi
00007d55df7d5ab3  pop rdx
00007d55df7d5ab4  pop rcx
00007d55df7d5ab5  pop rax
00007d55df7d5ab6  add rsp, 0x08
00007d55df7d5aba  jmp 0x00007D55DF7D2F99
00007d55df7d5abf  sub rsp, 0x08
00007d55df7d5ac3  push rax
00007d55df7d5ac4  push rcx
00007d55df7d5ac5  push rdx
00007d55df7d5ac6  push rdi
00007d55df7d5ac7  push rsi
00007d55df7d5ac8  push r8
00007d55df7d5aca  push r9
00007d55df7d5acc  push r10
00007d55df7d5ace  push r11
00007d55df7d5ad0  sub rsp, 0xF0
00007d55df7d5ad7  vmovaps [rsp], xmm0
00007d55df7d5adc  vmovaps [rsp+0x10], xmm1
00007d55df7d5ae2  vmovaps [rsp+0x20], xmm2
00007d55df7d5ae8  vmovaps [rsp+0x30], xmm3
00007d55df7d5aee  vmovaps [rsp+0x40], xmm4
00007d55df7d5af4  vmovaps [rsp+0x50], xmm5
00007d55df7d5afa  vmovaps [rsp+0x60], xmm7
00007d55df7d5b00  vmovaps [rsp+0x70], xmm8
00007d55df7d5b06  vmovaps [rsp+0x80], xmm9
00007d55df7d5b0f  vmovaps [rsp+0x90], xmm10
00007d55df7d5b18  vmovaps [rsp+0xA0], xmm11
00007d55df7d5b21  vmovaps [rsp+0xB0], xmm12
00007d55df7d5b2a  vmovaps [rsp+0xC0], xmm13
00007d55df7d5b33  vmovaps [rsp+0xD0], xmm14
00007d55df7d5b3c  vmovaps [rsp+0xE0], xmm15
00007d55df7d5b45  sub rsp, 0x30
00007d55df7d5b49  movaps [rsp], xmm6
00007d55df7d5b4d  movaps [rsp+0x10], xmm5
00007d55df7d5b52  movaps [rsp+0x20], xmm1
00007d55df7d5b57  lea rdi, [rsp]
00007d55df7d5b5b  mov esi, 0x00
00007d55df7d5b60  mov rax, 0x5BB8433D8530
00007d55df7d5b6a  call rax
00007d55df7d5b6c  movaps xmm6, [rsp]
00007d55df7d5b70  add rsp, 0x30
00007d55df7d5b74  vmovaps xmm0, [rsp]
00007d55df7d5b79  vmovaps xmm1, [rsp+0x10]
00007d55df7d5b7f  vmovaps xmm2, [rsp+0x20]
00007d55df7d5b85  vmovaps xmm3, [rsp+0x30]
00007d55df7d5b8b  vmovaps xmm4, [rsp+0x40]
00007d55df7d5b91  vmovaps xmm5, [rsp+0x50]
00007d55df7d5b97  vmovaps xmm7, [rsp+0x60]
00007d55df7d5b9d  vmovaps xmm8, [rsp+0x70]
00007d55df7d5ba3  vmovaps xmm9, [rsp+0x80]
00007d55df7d5bac  vmovaps xmm10, [rsp+0x90]
00007d55df7d5bb5  vmovaps xmm11, [rsp+0xA0]
00007d55df7d5bbe  vmovaps xmm12, [rsp+0xB0]
00007d55df7d5bc7  vmovaps xmm13, [rsp+0xC0]
00007d55df7d5bd0  vmovaps xmm14, [rsp+0xD0]
00007d55df7d5bd9  vmovaps xmm15, [rsp+0xE0]
00007d55df7d5be2  add rsp, 0xF0
00007d55df7d5be9  pop r11
00007d55df7d5beb  pop r10
00007d55df7d5bed  pop r9
00007d55df7d5bef  pop r8
00007d55df7d5bf1  pop rsi
00007d55df7d5bf2  pop rdi
00007d55df7d5bf3  pop rdx
00007d55df7d5bf4  pop rcx
00007d55df7d5bf5  pop rax
00007d55df7d5bf6  add rsp, 0x08
00007d55df7d5bfa  jmp 0x00007D55DF7D2FBF
00007d55df7d5bff  sub rsp, 0x08
00007d55df7d5c03  push rax
00007d55df7d5c04  push rcx
00007d55df7d5c05  push rdx
00007d55df7d5c06  push rdi
00007d55df7d5c07  push rsi
00007d55df7d5c08  push r8
00007d55df7d5c0a  push r9
00007d55df7d5c0c  push r10
00007d55df7d5c0e  push r11
00007d55df7d5c10  sub rsp, 0xF0
00007d55df7d5c17  vmovaps [rsp], xmm0
00007d55df7d5c1c  vmovaps [rsp+0x10], xmm2
00007d55df7d5c22  vmovaps [rsp+0x20], xmm3
00007d55df7d5c28  vmovaps [rsp+0x30], xmm4
00007d55df7d5c2e  vmovaps [rsp+0x40], xmm5
00007d55df7d5c34  vmovaps [rsp+0x50], xmm6
00007d55df7d5c3a  vmovaps [rsp+0x60], xmm7
00007d55df7d5c40  vmovaps [rsp+0x70], xmm8
00007d55df7d5c46  vmovaps [rsp+0x80], xmm9
00007d55df7d5c4f  vmovaps [rsp+0x90], xmm10
00007d55df7d5c58  vmovaps [rsp+0xA0], xmm11
00007d55df7d5c61  vmovaps [rsp+0xB0], xmm12
00007d55df7d5c6a  vmovaps [rsp+0xC0], xmm13
00007d55df7d5c73  vmovaps [rsp+0xD0], xmm14
00007d55df7d5c7c  vmovaps [rsp+0xE0], xmm15
00007d55df7d5c85  sub rsp, 0x30
00007d55df7d5c89  movaps [rsp], xmm1
00007d55df7d5c8d  movaps [rsp+0x10], xmm5
00007d55df7d5c92  movaps [rsp+0x20], xmm13
00007d55df7d5c98  lea rdi, [rsp]
00007d55df7d5c9c  mov esi, 0x00
00007d55df7d5ca1  mov rax, 0x5BB8433D8530
00007d55df7d5cab  call rax
00007d55df7d5cad  movaps xmm1, [rsp]
00007d55df7d5cb1  add rsp, 0x30
00007d55df7d5cb5  vmovaps xmm0, [rsp]
00007d55df7d5cba  vmovaps xmm2, [rsp+0x10]
00007d55df7d5cc0  vmovaps xmm3, [rsp+0x20]
00007d55df7d5cc6  vmovaps xmm4, [rsp+0x30]
00007d55df7d5ccc  vmovaps xmm5, [rsp+0x40]
00007d55df7d5cd2  vmovaps xmm6, [rsp+0x50]
00007d55df7d5cd8  vmovaps xmm7, [rsp+0x60]
00007d55df7d5cde  vmovaps xmm8, [rsp+0x70]
00007d55df7d5ce4  vmovaps xmm9, [rsp+0x80]
00007d55df7d5ced  vmovaps xmm10, [rsp+0x90]
00007d55df7d5cf6  vmovaps xmm11, [rsp+0xA0]
00007d55df7d5cff  vmovaps xmm12, [rsp+0xB0]
00007d55df7d5d08  vmovaps xmm13, [rsp+0xC0]
00007d55df7d5d11  vmovaps xmm14, [rsp+0xD0]
00007d55df7d5d1a  vmovaps xmm15, [rsp+0xE0]
00007d55df7d5d23  add rsp, 0xF0
00007d55df7d5d2a  pop r11
00007d55df7d5d2c  pop r10
00007d55df7d5d2e  pop r9
00007d55df7d5d30  pop r8
00007d55df7d5d32  pop rsi
00007d55df7d5d33  pop rdi
00007d55df7d5d34  pop rdx
00007d55df7d5d35  pop rcx
00007d55df7d5d36  pop rax
00007d55df7d5d37  add rsp, 0x08
00007d55df7d5d3b  jmp 0x00007D55DF7D2FDD
00007d55df7d5d40  sub rsp, 0x08
00007d55df7d5d44  push rax
00007d55df7d5d45  push rcx
00007d55df7d5d46  push rdx
00007d55df7d5d47  push rdi
00007d55df7d5d48  push rsi
00007d55df7d5d49  push r8
00007d55df7d5d4b  push r9
00007d55df7d5d4d  push r10
00007d55df7d5d4f  push r11
00007d55df7d5d51  sub rsp, 0xF0
00007d55df7d5d58  vmovaps [rsp], xmm0
00007d55df7d5d5d  vmovaps [rsp+0x10], xmm1
00007d55df7d5d63  vmovaps [rsp+0x20], xmm2
00007d55df7d5d69  vmovaps [rsp+0x30], xmm3
00007d55df7d5d6f  vmovaps [rsp+0x40], xmm4
00007d55df7d5d75  vmovaps [rsp+0x50], xmm6
00007d55df7d5d7b  vmovaps [rsp+0x60], xmm7
00007d55df7d5d81  vmovaps [rsp+0x70], xmm8
00007d55df7d5d87  vmovaps [rsp+0x80], xmm9
00007d55df7d5d90  vmovaps [rsp+0x90], xmm10
00007d55df7d5d99  vmovaps [rsp+0xA0], xmm11
00007d55df7d5da2  vmovaps [rsp+0xB0], xmm12
00007d55df7d5dab  vmovaps [rsp+0xC0], xmm13
00007d55df7d5db4  vmovaps [rsp+0xD0], xmm14
00007d55df7d5dbd  vmovaps [rsp+0xE0], xmm15
00007d55df7d5dc6  sub rsp, 0x30
00007d55df7d5dca  movaps [rsp], xmm5
00007d55df7d5dce  movaps [rsp+0x10], xmm2
00007d55df7d5dd3  movaps [rsp+0x20], xmm13
00007d55df7d5dd9  lea rdi, [rsp]
00007d55df7d5ddd  mov esi, 0x00
00007d55df7d5de2  mov rax, 0x5BB8433D8530
00007d55df7d5dec  call rax
00007d55df7d5dee  movaps xmm5, [rsp]
00007d55df7d5df2  add rsp, 0x30
00007d55df7d5df6  vmovaps xmm0, [rsp]
00007d55df7d5dfb  vmovaps xmm1, [rsp+0x10]
00007d55df7d5e01  vmovaps xmm2, [rsp+0x20]
00007d55df7d5e07  vmovaps xmm3, [rsp+0x30]
00007d55df7d5e0d  vmovaps xmm4, [rsp+0x40]
00007d55df7d5e13  vmovaps xmm6, [rsp+0x50]
00007d55df7d5e19  vmovaps xmm7, [rsp+0x60]
00007d55df7d5e1f  vmovaps xmm8, [rsp+0x70]
00007d55df7d5e25  vmovaps xmm9, [rsp+0x80]
00007d55df7d5e2e  vmovaps xmm10, [rsp+0x90]
00007d55df7d5e37  vmovaps xmm11, [rsp+0xA0]
00007d55df7d5e40  vmovaps xmm12, [rsp+0xB0]
00007d55df7d5e49  vmovaps xmm13, [rsp+0xC0]
00007d55df7d5e52  vmovaps xmm14, [rsp+0xD0]
00007d55df7d5e5b  vmovaps xmm15, [rsp+0xE0]
00007d55df7d5e64  add rsp, 0xF0
00007d55df7d5e6b  pop r11
00007d55df7d5e6d  pop r10
00007d55df7d5e6f  pop r9
00007d55df7d5e71  pop r8
00007d55df7d5e73  pop rsi
00007d55df7d5e74  pop rdi
00007d55df7d5e75  pop rdx
00007d55df7d5e76  pop rcx
00007d55df7d5e77  pop rax
00007d55df7d5e78  add rsp, 0x08
00007d55df7d5e7c  jmp 0x00007D55DF7D3013
00007d55df7d5e81  sub rsp, 0x08
00007d55df7d5e85  push rax
00007d55df7d5e86  push rcx
00007d55df7d5e87  push rdx
00007d55df7d5e88  push rdi
00007d55df7d5e89  push rsi
00007d55df7d5e8a  push r8
00007d55df7d5e8c  push r9
00007d55df7d5e8e  push r10
00007d55df7d5e90  push r11
00007d55df7d5e92  sub rsp, 0xF0
00007d55df7d5e99  vmovaps [rsp], xmm0
00007d55df7d5e9e  vmovaps [rsp+0x10], xmm1
00007d55df7d5ea4  vmovaps [rsp+0x20], xmm2
00007d55df7d5eaa  vmovaps [rsp+0x30], xmm3
00007d55df7d5eb0  vmovaps [rsp+0x40], xmm4
00007d55df7d5eb6  vmovaps [rsp+0x50], xmm5
00007d55df7d5ebc  vmovaps [rsp+0x60], xmm6
00007d55df7d5ec2  vmovaps [rsp+0x70], xmm7
00007d55df7d5ec8  vmovaps [rsp+0x80], xmm8
00007d55df7d5ed1  vmovaps [rsp+0x90], xmm9
00007d55df7d5eda  vmovaps [rsp+0xA0], xmm10
00007d55df7d5ee3  vmovaps [rsp+0xB0], xmm11
00007d55df7d5eec  vmovaps [rsp+0xC0], xmm12
00007d55df7d5ef5  vmovaps [rsp+0xD0], xmm14
00007d55df7d5efe  vmovaps [rsp+0xE0], xmm15
00007d55df7d5f07  sub rsp, 0x30
00007d55df7d5f0b  movaps [rsp], xmm13
00007d55df7d5f10  movaps [rsp+0x10], xmm10
00007d55df7d5f16  movaps [rsp+0x20], xmm1
00007d55df7d5f1b  lea rdi, [rsp]
00007d55df7d5f1f  mov esi, 0x00
00007d55df7d5f24  mov rax, 0x5BB8433D8530
00007d55df7d5f2e  call rax
00007d55df7d5f30  movaps xmm13, [rsp]
00007d55df7d5f35  add rsp, 0x30
00007d55df7d5f39  vmovaps xmm0, [rsp]
00007d55df7d5f3e  vmovaps xmm1, [rsp+0x10]
00007d55df7d5f44  vmovaps xmm2, [rsp+0x20]
00007d55df7d5f4a  vmovaps xmm3, [rsp+0x30]
00007d55df7d5f50  vmovaps xmm4, [rsp+0x40]
00007d55df7d5f56  vmovaps xmm5, [rsp+0x50]
00007d55df7d5f5c  vmovaps xmm6, [rsp+0x60]
00007d55df7d5f62  vmovaps xmm7, [rsp+0x70]
00007d55df7d5f68  vmovaps xmm8, [rsp+0x80]
00007d55df7d5f71  vmovaps xmm9, [rsp+0x90]
00007d55df7d5f7a  vmovaps xmm10, [rsp+0xA0]
00007d55df7d5f83  vmovaps xmm11, [rsp+0xB0]
00007d55df7d5f8c  vmovaps xmm12, [rsp+0xC0]
00007d55df7d5f95  vmovaps xmm14, [rsp+0xD0]
00007d55df7d5f9e  vmovaps xmm15, [rsp+0xE0]
00007d55df7d5fa7  add rsp, 0xF0
00007d55df7d5fae  pop r11
00007d55df7d5fb0  pop r10
00007d55df7d5fb2  pop r9
00007d55df7d5fb4  pop r8
00007d55df7d5fb6  pop rsi
00007d55df7d5fb7  pop rdi
00007d55df7d5fb8  pop rdx
00007d55df7d5fb9  pop rcx
00007d55df7d5fba  pop rax
00007d55df7d5fbb  add rsp, 0x08
00007d55df7d5fbf  jmp 0x00007D55DF7D303C
00007d55df7d5fc4  sub rsp, 0x08
00007d55df7d5fc8  push rax
00007d55df7d5fc9  push rcx
00007d55df7d5fca  push rdx
00007d55df7d5fcb  push rdi
00007d55df7d5fcc  push rsi
00007d55df7d5fcd  push r8
00007d55df7d5fcf  push r9
00007d55df7d5fd1  push r10
00007d55df7d5fd3  push r11
00007d55df7d5fd5  sub rsp, 0xF0
00007d55df7d5fdc  vmovaps [rsp], xmm0
00007d55df7d5fe1  vmovaps [rsp+0x10], xmm2
00007d55df7d5fe7  vmovaps [rsp+0x20], xmm3
00007d55df7d5fed  vmovaps [rsp+0x30], xmm4
00007d55df7d5ff3  vmovaps [rsp+0x40], xmm5
00007d55df7d5ff9  vmovaps [rsp+0x50], xmm6
00007d55df7d5fff  vmovaps [rsp+0x60], xmm7
00007d55df7d6005  vmovaps [rsp+0x70], xmm8
00007d55df7d600b  vmovaps [rsp+0x80], xmm9
00007d55df7d6014  vmovaps [rsp+0x90], xmm10
00007d55df7d601d  vmovaps [rsp+0xA0], xmm11
00007d55df7d6026  vmovaps [rsp+0xB0], xmm12
00007d55df7d602f  vmovaps [rsp+0xC0], xmm13
00007d55df7d6038  vmovaps [rsp+0xD0], xmm14
00007d55df7d6041  vmovaps [rsp+0xE0], xmm15
00007d55df7d604a  sub rsp, 0x30
00007d55df7d604e  movaps [rsp], xmm1
00007d55df7d6052  movaps [rsp+0x10], xmm15
00007d55df7d6058  movaps [rsp+0x20], xmm10
00007d55df7d605e  lea rdi, [rsp]
00007d55df7d6062  mov esi, 0x00
00007d55df7d6067  mov rax, 0x5BB8433D8530
00007d55df7d6071  call rax
00007d55df7d6073  movaps xmm1, [rsp]
00007d55df7d6077  add rsp, 0x30
00007d55df7d607b  vmovaps xmm0, [rsp]
00007d55df7d6080  vmovaps xmm2, [rsp+0x10]
00007d55df7d6086  vmovaps xmm3, [rsp+0x20]
00007d55df7d608c  vmovaps xmm4, [rsp+0x30]
00007d55df7d6092  vmovaps xmm5, [rsp+0x40]
00007d55df7d6098  vmovaps xmm6, [rsp+0x50]
00007d55df7d609e  vmovaps xmm7, [rsp+0x60]
00007d55df7d60a4  vmovaps xmm8, [rsp+0x70]
00007d55df7d60aa  vmovaps xmm9, [rsp+0x80]
00007d55df7d60b3  vmovaps xmm10, [rsp+0x90]
00007d55df7d60bc  vmovaps xmm11, [rsp+0xA0]
00007d55df7d60c5  vmovaps xmm12, [rsp+0xB0]
00007d55df7d60ce  vmovaps xmm13, [rsp+0xC0]
00007d55df7d60d7  vmovaps xmm14, [rsp+0xD0]
00007d55df7d60e0  vmovaps xmm15, [rsp+0xE0]
00007d55df7d60e9  add rsp, 0xF0
00007d55df7d60f0  pop r11
00007d55df7d60f2  pop r10
00007d55df7d60f4  pop r9
00007d55df7d60f6  pop r8
00007d55df7d60f8  pop rsi
00007d55df7d60f9  pop rdi
00007d55df7d60fa  pop rdx
00007d55df7d60fb  pop rcx
00007d55df7d60fc  pop rax
00007d55df7d60fd  add rsp, 0x08
00007d55df7d6101  jmp 0x00007D55DF7D305B
00007d55df7d6106  sub rsp, 0x08
00007d55df7d610a  push rax
00007d55df7d610b  push rcx
00007d55df7d610c  push rdx
00007d55df7d610d  push rdi
00007d55df7d610e  push rsi
00007d55df7d610f  push r8
00007d55df7d6111  push r9
00007d55df7d6113  push r10
00007d55df7d6115  push r11
00007d55df7d6117  sub rsp, 0xF0
00007d55df7d611e  vmovaps [rsp], xmm0
00007d55df7d6123  vmovaps [rsp+0x10], xmm1
00007d55df7d6129  vmovaps [rsp+0x20], xmm2
00007d55df7d612f  vmovaps [rsp+0x30], xmm3
00007d55df7d6135  vmovaps [rsp+0x40], xmm4
00007d55df7d613b  vmovaps [rsp+0x50], xmm5
00007d55df7d6141  vmovaps [rsp+0x60], xmm6
00007d55df7d6147  vmovaps [rsp+0x70], xmm7
00007d55df7d614d  vmovaps [rsp+0x80], xmm8
00007d55df7d6156  vmovaps [rsp+0x90], xmm9
00007d55df7d615f  vmovaps [rsp+0xA0], xmm10
00007d55df7d6168  vmovaps [rsp+0xB0], xmm11
00007d55df7d6171  vmovaps [rsp+0xC0], xmm12
00007d55df7d617a  vmovaps [rsp+0xD0], xmm13
00007d55df7d6183  vmovaps [rsp+0xE0], xmm14
00007d55df7d618c  sub rsp, 0x30
00007d55df7d6190  movaps [rsp], xmm15
00007d55df7d6195  movaps [rsp+0x10], xmm10
00007d55df7d619b  movaps [rsp+0x20], xmm11
00007d55df7d61a1  lea rdi, [rsp]
00007d55df7d61a5  mov esi, 0x00
00007d55df7d61aa  mov rax, 0x5BB8433D8530
00007d55df7d61b4  call rax
00007d55df7d61b6  movaps xmm15, [rsp]
00007d55df7d61bb  add rsp, 0x30
00007d55df7d61bf  vmovaps xmm0, [rsp]
00007d55df7d61c4  vmovaps xmm1, [rsp+0x10]
00007d55df7d61ca  vmovaps xmm2, [rsp+0x20]
00007d55df7d61d0  vmovaps xmm3, [rsp+0x30]
00007d55df7d61d6  vmovaps xmm4, [rsp+0x40]
00007d55df7d61dc  vmovaps xmm5, [rsp+0x50]
00007d55df7d61e2  vmovaps xmm6, [rsp+0x60]
00007d55df7d61e8  vmovaps xmm7, [rsp+0x70]
00007d55df7d61ee  vmovaps xmm8, [rsp+0x80]
00007d55df7d61f7  vmovaps xmm9, [rsp+0x90]
00007d55df7d6200  vmovaps xmm10, [rsp+0xA0]
00007d55df7d6209  vmovaps xmm11, [rsp+0xB0]
00007d55df7d6212  vmovaps xmm12, [rsp+0xC0]
00007d55df7d621b  vmovaps xmm13, [rsp+0xD0]
00007d55df7d6224  vmovaps xmm14, [rsp+0xE0]
00007d55df7d622d  add rsp, 0xF0
00007d55df7d6234  pop r11
00007d55df7d6236  pop r10
00007d55df7d6238  pop r9
00007d55df7d623a  pop r8
00007d55df7d623c  pop rsi
00007d55df7d623d  pop rdi
00007d55df7d623e  pop rdx
00007d55df7d623f  pop rcx
00007d55df7d6240  pop rax
00007d55df7d6241  add rsp, 0x08
00007d55df7d6245  jmp 0x00007D55DF7D307E
00007d55df7d624a  sub rsp, 0x08
00007d55df7d624e  push rax
00007d55df7d624f  push rcx
00007d55df7d6250  push rdx
00007d55df7d6251  push rdi
00007d55df7d6252  push rsi
00007d55df7d6253  push r8
00007d55df7d6255  push r9
00007d55df7d6257  push r10
00007d55df7d6259  push r11
00007d55df7d625b  sub rsp, 0xF0
00007d55df7d6262  vmovaps [rsp], xmm0
00007d55df7d6267  vmovaps [rsp+0x10], xmm1
00007d55df7d626d  vmovaps [rsp+0x20], xmm2
00007d55df7d6273  vmovaps [rsp+0x30], xmm3
00007d55df7d6279  vmovaps [rsp+0x40], xmm4
00007d55df7d627f  vmovaps [rsp+0x50], xmm5
00007d55df7d6285  vmovaps [rsp+0x60], xmm6
00007d55df7d628b  vmovaps [rsp+0x70], xmm7
00007d55df7d6291  vmovaps [rsp+0x80], xmm8
00007d55df7d629a  vmovaps [rsp+0x90], xmm9
00007d55df7d62a3  vmovaps [rsp+0xA0], xmm11
00007d55df7d62ac  vmovaps [rsp+0xB0], xmm12
00007d55df7d62b5  vmovaps [rsp+0xC0], xmm13
00007d55df7d62be  vmovaps [rsp+0xD0], xmm14
00007d55df7d62c7  vmovaps [rsp+0xE0], xmm15
00007d55df7d62d0  sub rsp, 0x30
00007d55df7d62d4  movaps [rsp], xmm10
00007d55df7d62d9  movaps [rsp+0x10], xmm2
00007d55df7d62de  movaps [rsp+0x20], xmm11
00007d55df7d62e4  lea rdi, [rsp]
00007d55df7d62e8  mov esi, 0x00
00007d55df7d62ed  mov rax, 0x5BB8433D8530
00007d55df7d62f7  call rax
00007d55df7d62f9  movaps xmm10, [rsp]
00007d55df7d62fe  add rsp, 0x30
00007d55df7d6302  vmovaps xmm0, [rsp]
00007d55df7d6307  vmovaps xmm1, [rsp+0x10]
00007d55df7d630d  vmovaps xmm2, [rsp+0x20]
00007d55df7d6313  vmovaps xmm3, [rsp+0x30]
00007d55df7d6319  vmovaps xmm4, [rsp+0x40]
00007d55df7d631f  vmovaps xmm5, [rsp+0x50]
00007d55df7d6325  vmovaps xmm6, [rsp+0x60]
00007d55df7d632b  vmovaps xmm7, [rsp+0x70]
00007d55df7d6331  vmovaps xmm8, [rsp+0x80]
00007d55df7d633a  vmovaps xmm9, [rsp+0x90]
00007d55df7d6343  vmovaps xmm11, [rsp+0xA0]
00007d55df7d634c  vmovaps xmm12, [rsp+0xB0]
00007d55df7d6355  vmovaps xmm13, [rsp+0xC0]
00007d55df7d635e  vmovaps xmm14, [rsp+0xD0]
00007d55df7d6367  vmovaps xmm15, [rsp+0xE0]
00007d55df7d6370  add rsp, 0xF0
00007d55df7d6377  pop r11
00007d55df7d6379  pop r10
00007d55df7d637b  pop r9
00007d55df7d637d  pop r8
00007d55df7d637f  pop rsi
00007d55df7d6380  pop rdi
00007d55df7d6381  pop rdx
00007d55df7d6382  pop rcx
00007d55df7d6383  pop rax
00007d55df7d6384  add rsp, 0x08
00007d55df7d6388  jmp 0x00007D55DF7D30B6
00007d55df7d638d  sub rsp, 0x08
00007d55df7d6391  push rax
00007d55df7d6392  push rcx
00007d55df7d6393  push rdx
00007d55df7d6394  push rdi
00007d55df7d6395  push rsi
00007d55df7d6396  push r8
00007d55df7d6398  push r9
00007d55df7d639a  push r10
00007d55df7d639c  push r11
00007d55df7d639e  sub rsp, 0xF0
00007d55df7d63a5  vmovaps [rsp], xmm0
00007d55df7d63aa  vmovaps [rsp+0x10], xmm1
00007d55df7d63b0  vmovaps [rsp+0x20], xmm2
00007d55df7d63b6  vmovaps [rsp+0x30], xmm3
00007d55df7d63bc  vmovaps [rsp+0x40], xmm4
00007d55df7d63c2  vmovaps [rsp+0x50], xmm5
00007d55df7d63c8  vmovaps [rsp+0x60], xmm6
00007d55df7d63ce  vmovaps [rsp+0x70], xmm7
00007d55df7d63d4  vmovaps [rsp+0x80], xmm8
00007d55df7d63dd  vmovaps [rsp+0x90], xmm9
00007d55df7d63e6  vmovaps [rsp+0xA0], xmm10
00007d55df7d63ef  vmovaps [rsp+0xB0], xmm12
00007d55df7d63f8  vmovaps [rsp+0xC0], xmm13
00007d55df7d6401  vmovaps [rsp+0xD0], xmm14
00007d55df7d640a  vmovaps [rsp+0xE0], xmm15
00007d55df7d6413  sub rsp, 0x30
00007d55df7d6417  movaps [rsp], xmm11
00007d55df7d641c  movaps [rsp+0x10], xmm2
00007d55df7d6421  movaps [rsp+0x20], xmm1
00007d55df7d6426  lea rdi, [rsp]
00007d55df7d642a  mov esi, 0x00
00007d55df7d642f  mov rax, 0x5BB8433D8530
00007d55df7d6439  call rax
00007d55df7d643b  movaps xmm11, [rsp]
00007d55df7d6440  add rsp, 0x30
00007d55df7d6444  vmovaps xmm0, [rsp]
00007d55df7d6449  vmovaps xmm1, [rsp+0x10]
00007d55df7d644f  vmovaps xmm2, [rsp+0x20]
00007d55df7d6455  vmovaps xmm3, [rsp+0x30]
00007d55df7d645b  vmovaps xmm4, [rsp+0x40]
00007d55df7d6461  vmovaps xmm5, [rsp+0x50]
00007d55df7d6467  vmovaps xmm6, [rsp+0x60]
00007d55df7d646d  vmovaps xmm7, [rsp+0x70]
00007d55df7d6473  vmovaps xmm8, [rsp+0x80]
00007d55df7d647c  vmovaps xmm9, [rsp+0x90]
00007d55df7d6485  vmovaps xmm10, [rsp+0xA0]
00007d55df7d648e  vmovaps xmm12, [rsp+0xB0]
00007d55df7d6497  vmovaps xmm13, [rsp+0xC0]
00007d55df7d64a0  vmovaps xmm14, [rsp+0xD0]
00007d55df7d64a9  vmovaps xmm15, [rsp+0xE0]
00007d55df7d64b2  add rsp, 0xF0
00007d55df7d64b9  pop r11
00007d55df7d64bb  pop r10
00007d55df7d64bd  pop r9
00007d55df7d64bf  pop r8
00007d55df7d64c1  pop rsi
00007d55df7d64c2  pop rdi
00007d55df7d64c3  pop rdx
00007d55df7d64c4  pop rcx
00007d55df7d64c5  pop rax
00007d55df7d64c6  add rsp, 0x08
00007d55df7d64ca  jmp 0x00007D55DF7D30F2
00007d55df7d64cf  sub rsp, 0x08
00007d55df7d64d3  push rax
00007d55df7d64d4  push rcx
00007d55df7d64d5  push rdx
00007d55df7d64d6  push rdi
00007d55df7d64d7  push rsi
00007d55df7d64d8  push r8
00007d55df7d64da  push r9
00007d55df7d64dc  push r10
00007d55df7d64de  push r11
00007d55df7d64e0  sub rsp, 0xF0
00007d55df7d64e7  vmovaps [rsp], xmm0
00007d55df7d64ec  vmovaps [rsp+0x10], xmm2
00007d55df7d64f2  vmovaps [rsp+0x20], xmm3
00007d55df7d64f8  vmovaps [rsp+0x30], xmm4
00007d55df7d64fe  vmovaps [rsp+0x40], xmm5
00007d55df7d6504  vmovaps [rsp+0x50], xmm6
00007d55df7d650a  vmovaps [rsp+0x60], xmm7
00007d55df7d6510  vmovaps [rsp+0x70], xmm8
00007d55df7d6516  vmovaps [rsp+0x80], xmm9
00007d55df7d651f  vmovaps [rsp+0x90], xmm10
00007d55df7d6528  vmovaps [rsp+0xA0], xmm11
00007d55df7d6531  vmovaps [rsp+0xB0], xmm12
00007d55df7d653a  vmovaps [rsp+0xC0], xmm13
00007d55df7d6543  vmovaps [rsp+0xD0], xmm14
00007d55df7d654c  vmovaps [rsp+0xE0], xmm15
00007d55df7d6555  sub rsp, 0x30
00007d55df7d6559  movaps [rsp], xmm1
00007d55df7d655d  movaps [rsp+0x10], xmm14
00007d55df7d6563  movaps [rsp+0x20], xmm6
00007d55df7d6568  lea rdi, [rsp]
00007d55df7d656c  mov esi, 0x00
00007d55df7d6571  mov rax, 0x5BB8433D8530
00007d55df7d657b  call rax
00007d55df7d657d  movaps xmm1, [rsp]
00007d55df7d6581  add rsp, 0x30
00007d55df7d6585  vmovaps xmm0, [rsp]
00007d55df7d658a  vmovaps xmm2, [rsp+0x10]
00007d55df7d6590  vmovaps xmm3, [rsp+0x20]
00007d55df7d6596  vmovaps xmm4, [rsp+0x30]
00007d55df7d659c  vmovaps xmm5, [rsp+0x40]
00007d55df7d65a2  vmovaps xmm6, [rsp+0x50]
00007d55df7d65a8  vmovaps xmm7, [rsp+0x60]
00007d55df7d65ae  vmovaps xmm8, [rsp+0x70]
00007d55df7d65b4  vmovaps xmm9, [rsp+0x80]
00007d55df7d65bd  vmovaps xmm10, [rsp+0x90]
00007d55df7d65c6  vmovaps xmm11, [rsp+0xA0]
00007d55df7d65cf  vmovaps xmm12, [rsp+0xB0]
00007d55df7d65d8  vmovaps xmm13, [rsp+0xC0]
00007d55df7d65e1  vmovaps xmm14, [rsp+0xD0]
00007d55df7d65ea  vmovaps xmm15, [rsp+0xE0]
00007d55df7d65f3  add rsp, 0xF0
00007d55df7d65fa  pop r11
00007d55df7d65fc  pop r10
00007d55df7d65fe  pop r9
00007d55df7d6600  pop r8
00007d55df7d6602  pop rsi
00007d55df7d6603  pop rdi
00007d55df7d6604  pop rdx
00007d55df7d6605  pop rcx
00007d55df7d6606  pop rax
00007d55df7d6607  add rsp, 0x08
00007d55df7d660b  jmp 0x00007D55DF7D310B
00007d55df7d6610  sub rsp, 0x08
00007d55df7d6614  push rax
00007d55df7d6615  push rcx
00007d55df7d6616  push rdx
00007d55df7d6617  push rdi
00007d55df7d6618  push rsi
00007d55df7d6619  push r8
00007d55df7d661b  push r9
00007d55df7d661d  push r10
00007d55df7d661f  push r11
00007d55df7d6621  sub rsp, 0xF0
00007d55df7d6628  vmovaps [rsp], xmm0
00007d55df7d662d  vmovaps [rsp+0x10], xmm1
00007d55df7d6633  vmovaps [rsp+0x20], xmm2
00007d55df7d6639  vmovaps [rsp+0x30], xmm3
00007d55df7d663f  vmovaps [rsp+0x40], xmm4
00007d55df7d6645  vmovaps [rsp+0x50], xmm5
00007d55df7d664b  vmovaps [rsp+0x60], xmm6
00007d55df7d6651  vmovaps [rsp+0x70], xmm7
00007d55df7d6657  vmovaps [rsp+0x80], xmm8
00007d55df7d6660  vmovaps [rsp+0x90], xmm9
00007d55df7d6669  vmovaps [rsp+0xA0], xmm10
00007d55df7d6672  vmovaps [rsp+0xB0], xmm11
00007d55df7d667b  vmovaps [rsp+0xC0], xmm12
00007d55df7d6684  vmovaps [rsp+0xD0], xmm13
00007d55df7d668d  vmovaps [rsp+0xE0], xmm14
00007d55df7d6696  sub rsp, 0x30
00007d55df7d669a  movaps [rsp], xmm15
00007d55df7d669f  movaps [rsp+0x10], xmm14
00007d55df7d66a5  movaps [rsp+0x20], xmm5
00007d55df7d66aa  lea rdi, [rsp]
00007d55df7d66ae  mov esi, 0x00
00007d55df7d66b3  mov rax, 0x5BB8433D8530
00007d55df7d66bd  call rax
00007d55df7d66bf  movaps xmm15, [rsp]
00007d55df7d66c4  add rsp, 0x30
00007d55df7d66c8  vmovaps xmm0, [rsp]
00007d55df7d66cd  vmovaps xmm1, [rsp+0x10]
00007d55df7d66d3  vmovaps xmm2, [rsp+0x20]
00007d55df7d66d9  vmovaps xmm3, [rsp+0x30]
00007d55df7d66df  vmovaps xmm4, [rsp+0x40]
00007d55df7d66e5  vmovaps xmm5, [rsp+0x50]
00007d55df7d66eb  vmovaps xmm6, [rsp+0x60]
00007d55df7d66f1  vmovaps xmm7, [rsp+0x70]
00007d55df7d66f7  vmovaps xmm8, [rsp+0x80]
00007d55df7d6700  vmovaps xmm9, [rsp+0x90]
00007d55df7d6709  vmovaps xmm10, [rsp+0xA0]
00007d55df7d6712  vmovaps xmm11, [rsp+0xB0]
00007d55df7d671b  vmovaps xmm12, [rsp+0xC0]
00007d55df7d6724  vmovaps xmm13, [rsp+0xD0]
00007d55df7d672d  vmovaps xmm14, [rsp+0xE0]
00007d55df7d6736  add rsp, 0xF0
00007d55df7d673d  pop r11
00007d55df7d673f  pop r10
00007d55df7d6741  pop r9
00007d55df7d6743  pop r8
00007d55df7d6745  pop rsi
00007d55df7d6746  pop rdi
00007d55df7d6747  pop rdx
00007d55df7d6748  pop rcx
00007d55df7d6749  pop rax
00007d55df7d674a  add rsp, 0x08
00007d55df7d674e  jmp 0x00007D55DF7D312B
00007d55df7d6753  sub rsp, 0x08
00007d55df7d6757  push rax
00007d55df7d6758  push rcx
00007d55df7d6759  push rdx
00007d55df7d675a  push rdi
00007d55df7d675b  push rsi
00007d55df7d675c  push r8
00007d55df7d675e  push r9
00007d55df7d6760  push r10
00007d55df7d6762  push r11
00007d55df7d6764  sub rsp, 0xF0
00007d55df7d676b  vmovaps [rsp], xmm0
00007d55df7d6770  vmovaps [rsp+0x10], xmm1
00007d55df7d6776  vmovaps [rsp+0x20], xmm2
00007d55df7d677c  vmovaps [rsp+0x30], xmm3
00007d55df7d6782  vmovaps [rsp+0x40], xmm4
00007d55df7d6788  vmovaps [rsp+0x50], xmm5
00007d55df7d678e  vmovaps [rsp+0x60], xmm7
00007d55df7d6794  vmovaps [rsp+0x70], xmm8
00007d55df7d679a  vmovaps [rsp+0x80], xmm9
00007d55df7d67a3  vmovaps [rsp+0x90], xmm10
00007d55df7d67ac  vmovaps [rsp+0xA0], xmm11
00007d55df7d67b5  vmovaps [rsp+0xB0], xmm12
00007d55df7d67be  vmovaps [rsp+0xC0], xmm13
00007d55df7d67c7  vmovaps [rsp+0xD0], xmm14
00007d55df7d67d0  vmovaps [rsp+0xE0], xmm15
00007d55df7d67d9  sub rsp, 0x30
00007d55df7d67dd  movaps [rsp], xmm6
00007d55df7d67e1  movaps [rsp+0x10], xmm9
00007d55df7d67e7  movaps [rsp+0x20], xmm14
00007d55df7d67ed  lea rdi, [rsp]
00007d55df7d67f1  mov esi, 0x00
00007d55df7d67f6  mov rax, 0x5BB8433D8530
00007d55df7d6800  call rax
00007d55df7d6802  movaps xmm6, [rsp]
00007d55df7d6806  add rsp, 0x30
00007d55df7d680a  vmovaps xmm0, [rsp]
00007d55df7d680f  vmovaps xmm1, [rsp+0x10]
00007d55df7d6815  vmovaps xmm2, [rsp+0x20]
00007d55df7d681b  vmovaps xmm3, [rsp+0x30]
00007d55df7d6821  vmovaps xmm4, [rsp+0x40]
00007d55df7d6827  vmovaps xmm5, [rsp+0x50]
00007d55df7d682d  vmovaps xmm7, [rsp+0x60]
00007d55df7d6833  vmovaps xmm8, [rsp+0x70]
00007d55df7d6839  vmovaps xmm9, [rsp+0x80]
00007d55df7d6842  vmovaps xmm10, [rsp+0x90]
00007d55df7d684b  vmovaps xmm11, [rsp+0xA0]
00007d55df7d6854  vmovaps xmm12, [rsp+0xB0]
00007d55df7d685d  vmovaps xmm13, [rsp+0xC0]
00007d55df7d6866  vmovaps xmm14, [rsp+0xD0]
00007d55df7d686f  vmovaps xmm15, [rsp+0xE0]
00007d55df7d6878  add rsp, 0xF0
00007d55df7d687f  pop r11
00007d55df7d6881  pop r10
00007d55df7d6883  pop r9
00007d55df7d6885  pop r8
00007d55df7d6887  pop rsi
00007d55df7d6888  pop rdi
00007d55df7d6889  pop rdx
00007d55df7d688a  pop rcx
00007d55df7d688b  pop rax
00007d55df7d688c  add rsp, 0x08
00007d55df7d6890  jmp 0x00007D55DF7D3153
00007d55df7d6895  sub rsp, 0x08
00007d55df7d6899  push rax
00007d55df7d689a  push rcx
00007d55df7d689b  push rdx
00007d55df7d689c  push rdi
00007d55df7d689d  push rsi
00007d55df7d689e  push r8
00007d55df7d68a0  push r9
00007d55df7d68a2  push r10
00007d55df7d68a4  push r11
00007d55df7d68a6  sub rsp, 0xF0
00007d55df7d68ad  vmovaps [rsp], xmm0
00007d55df7d68b2  vmovaps [rsp+0x10], xmm1
00007d55df7d68b8  vmovaps [rsp+0x20], xmm2
00007d55df7d68be  vmovaps [rsp+0x30], xmm3
00007d55df7d68c4  vmovaps [rsp+0x40], xmm4
00007d55df7d68ca  vmovaps [rsp+0x50], xmm5
00007d55df7d68d0  vmovaps [rsp+0x60], xmm6
00007d55df7d68d6  vmovaps [rsp+0x70], xmm7
00007d55df7d68dc  vmovaps [rsp+0x80], xmm8
00007d55df7d68e5  vmovaps [rsp+0x90], xmm9
00007d55df7d68ee  vmovaps [rsp+0xA0], xmm10
00007d55df7d68f7  vmovaps [rsp+0xB0], xmm11
00007d55df7d6900  vmovaps [rsp+0xC0], xmm12
00007d55df7d6909  vmovaps [rsp+0xD0], xmm13
00007d55df7d6912  vmovaps [rsp+0xE0], xmm15
00007d55df7d691b  sub rsp, 0x30
00007d55df7d691f  movaps [rsp], xmm14
00007d55df7d6924  movaps [rsp+0x10], xmm9
00007d55df7d692a  movaps [rsp+0x20], xmm13
00007d55df7d6930  lea rdi, [rsp]
00007d55df7d6934  mov esi, 0x00
00007d55df7d6939  mov rax, 0x5BB8433D8530
00007d55df7d6943  call rax
00007d55df7d6945  movaps xmm14, [rsp]
00007d55df7d694a  add rsp, 0x30
00007d55df7d694e  vmovaps xmm0, [rsp]
00007d55df7d6953  vmovaps xmm1, [rsp+0x10]
00007d55df7d6959  vmovaps xmm2, [rsp+0x20]
00007d55df7d695f  vmovaps xmm3, [rsp+0x30]
00007d55df7d6965  vmovaps xmm4, [rsp+0x40]
00007d55df7d696b  vmovaps xmm5, [rsp+0x50]
00007d55df7d6971  vmovaps xmm6, [rsp+0x60]
00007d55df7d6977  vmovaps xmm7, [rsp+0x70]
00007d55df7d697d  vmovaps xmm8, [rsp+0x80]
00007d55df7d6986  vmovaps xmm9, [rsp+0x90]
00007d55df7d698f  vmovaps xmm10, [rsp+0xA0]
00007d55df7d6998  vmovaps xmm11, [rsp+0xB0]
00007d55df7d69a1  vmovaps xmm12, [rsp+0xC0]
00007d55df7d69aa  vmovaps xmm13, [rsp+0xD0]
00007d55df7d69b3  vmovaps xmm15, [rsp+0xE0]
00007d55df7d69bc  add rsp, 0xF0
00007d55df7d69c3  pop r11
00007d55df7d69c5  pop r10
00007d55df7d69c7  pop r9
00007d55df7d69c9  pop r8
00007d55df7d69cb  pop rsi
00007d55df7d69cc  pop rdi
00007d55df7d69cd  pop rdx
00007d55df7d69ce  pop rcx
00007d55df7d69cf  pop rax
00007d55df7d69d0  add rsp, 0x08
00007d55df7d69d4  jmp 0x00007D55DF7D3176
00007d55df7d69d9  sub rsp, 0x08
00007d55df7d69dd  push rax
00007d55df7d69de  push rcx
00007d55df7d69df  push rdx
00007d55df7d69e0  push rdi
00007d55df7d69e1  push rsi
00007d55df7d69e2  push r8
00007d55df7d69e4  push r9
00007d55df7d69e6  push r10
00007d55df7d69e8  push r11
00007d55df7d69ea  sub rsp, 0xF0
00007d55df7d69f1  vmovaps [rsp], xmm0
00007d55df7d69f6  vmovaps [rsp+0x10], xmm1
00007d55df7d69fc  vmovaps [rsp+0x20], xmm2
00007d55df7d6a02  vmovaps [rsp+0x30], xmm3
00007d55df7d6a08  vmovaps [rsp+0x40], xmm4
00007d55df7d6a0e  vmovaps [rsp+0x50], xmm5
00007d55df7d6a14  vmovaps [rsp+0x60], xmm6
00007d55df7d6a1a  vmovaps [rsp+0x70], xmm7
00007d55df7d6a20  vmovaps [rsp+0x80], xmm8
00007d55df7d6a29  vmovaps [rsp+0x90], xmm9
00007d55df7d6a32  vmovaps [rsp+0xA0], xmm10
00007d55df7d6a3b  vmovaps [rsp+0xB0], xmm11
00007d55df7d6a44  vmovaps [rsp+0xC0], xmm12
00007d55df7d6a4d  vmovaps [rsp+0xD0], xmm14
00007d55df7d6a56  vmovaps [rsp+0xE0], xmm15
00007d55df7d6a5f  sub rsp, 0x30
00007d55df7d6a63  movaps [rsp], xmm13
00007d55df7d6a68  movaps [rsp+0x10], xmm9
00007d55df7d6a6e  movaps [rsp+0x20], xmm10
00007d55df7d6a74  lea rdi, [rsp]
00007d55df7d6a78  mov esi, 0x00
00007d55df7d6a7d  mov rax, 0x5BB8433D8530
00007d55df7d6a87  call rax
00007d55df7d6a89  movaps xmm13, [rsp]
00007d55df7d6a8e  add rsp, 0x30
00007d55df7d6a92  vmovaps xmm0, [rsp]
00007d55df7d6a97  vmovaps xmm1, [rsp+0x10]
00007d55df7d6a9d  vmovaps xmm2, [rsp+0x20]
00007d55df7d6aa3  vmovaps xmm3, [rsp+0x30]
00007d55df7d6aa9  vmovaps xmm4, [rsp+0x40]
00007d55df7d6aaf  vmovaps xmm5, [rsp+0x50]
00007d55df7d6ab5  vmovaps xmm6, [rsp+0x60]
00007d55df7d6abb  vmovaps xmm7, [rsp+0x70]
00007d55df7d6ac1  vmovaps xmm8, [rsp+0x80]
00007d55df7d6aca  vmovaps xmm9, [rsp+0x90]
00007d55df7d6ad3  vmovaps xmm10, [rsp+0xA0]
00007d55df7d6adc  vmovaps xmm11, [rsp+0xB0]
00007d55df7d6ae5  vmovaps xmm12, [rsp+0xC0]
00007d55df7d6aee  vmovaps xmm14, [rsp+0xD0]
00007d55df7d6af7  vmovaps xmm15, [rsp+0xE0]
00007d55df7d6b00  add rsp, 0xF0
00007d55df7d6b07  pop r11
00007d55df7d6b09  pop r10
00007d55df7d6b0b  pop r9
00007d55df7d6b0d  pop r8
00007d55df7d6b0f  pop rsi
00007d55df7d6b10  pop rdi
00007d55df7d6b11  pop rdx
00007d55df7d6b12  pop rcx
00007d55df7d6b13  pop rax
00007d55df7d6b14  add rsp, 0x08
00007d55df7d6b18  jmp 0x00007D55DF7D3196
00007d55df7d6b1d  call 0x00007D55DF60AFE0
00007d55df7d6b22  jmp 0x00007D55DF7D31EB
00007d55df7d6b27  sub rsp, 0x08
00007d55df7d6b2b  push rax
00007d55df7d6b2c  push rcx
00007d55df7d6b2d  push rdx
00007d55df7d6b2e  push rdi
00007d55df7d6b2f  push rsi
00007d55df7d6b30  push r8
00007d55df7d6b32  push r9
00007d55df7d6b34  push r10
00007d55df7d6b36  push r11
00007d55df7d6b38  sub rsp, 0xF0
00007d55df7d6b3f  vmovaps [rsp], xmm0
00007d55df7d6b44  vmovaps [rsp+0x10], xmm1
00007d55df7d6b4a  vmovaps [rsp+0x20], xmm2
00007d55df7d6b50  vmovaps [rsp+0x30], xmm3
00007d55df7d6b56  vmovaps [rsp+0x40], xmm4
00007d55df7d6b5c  vmovaps [rsp+0x50], xmm5
00007d55df7d6b62  vmovaps [rsp+0x60], xmm6
00007d55df7d6b68  vmovaps [rsp+0x70], xmm7
00007d55df7d6b6e  vmovaps [rsp+0x80], xmm8
00007d55df7d6b77  vmovaps [rsp+0x90], xmm10
00007d55df7d6b80  vmovaps [rsp+0xA0], xmm11
00007d55df7d6b89  vmovaps [rsp+0xB0], xmm12
00007d55df7d6b92  vmovaps [rsp+0xC0], xmm13
00007d55df7d6b9b  vmovaps [rsp+0xD0], xmm14
00007d55df7d6ba4  vmovaps [rsp+0xE0], xmm15
00007d55df7d6bad  sub rsp, 0x30
00007d55df7d6bb1  movaps [rsp], xmm9
00007d55df7d6bb6  movaps [rsp+0x10], xmm8
00007d55df7d6bbc  movaps [rsp+0x20], xmm10
00007d55df7d6bc2  lea rdi, [rsp]
00007d55df7d6bc6  mov esi, 0x00
00007d55df7d6bcb  mov rax, 0x5BB8433D8530
00007d55df7d6bd5  call rax
00007d55df7d6bd7  movaps xmm9, [rsp]
00007d55df7d6bdc  add rsp, 0x30
00007d55df7d6be0  vmovaps xmm0, [rsp]
00007d55df7d6be5  vmovaps xmm1, [rsp+0x10]
00007d55df7d6beb  vmovaps xmm2, [rsp+0x20]
00007d55df7d6bf1  vmovaps xmm3, [rsp+0x30]
00007d55df7d6bf7  vmovaps xmm4, [rsp+0x40]
00007d55df7d6bfd  vmovaps xmm5, [rsp+0x50]
00007d55df7d6c03  vmovaps xmm6, [rsp+0x60]
00007d55df7d6c09  vmovaps xmm7, [rsp+0x70]
00007d55df7d6c0f  vmovaps xmm8, [rsp+0x80]
00007d55df7d6c18  vmovaps xmm10, [rsp+0x90]
00007d55df7d6c21  vmovaps xmm11, [rsp+0xA0]
00007d55df7d6c2a  vmovaps xmm12, [rsp+0xB0]
00007d55df7d6c33  vmovaps xmm13, [rsp+0xC0]
00007d55df7d6c3c  vmovaps xmm14, [rsp+0xD0]
00007d55df7d6c45  vmovaps xmm15, [rsp+0xE0]
00007d55df7d6c4e  add rsp, 0xF0
00007d55df7d6c55  pop r11
00007d55df7d6c57  pop r10
00007d55df7d6c59  pop r9
00007d55df7d6c5b  pop r8
00007d55df7d6c5d  pop rsi
00007d55df7d6c5e  pop rdi
00007d55df7d6c5f  pop rdx
00007d55df7d6c60  pop rcx
00007d55df7d6c61  pop rax
00007d55df7d6c62  add rsp, 0x08
00007d55df7d6c66  jmp 0x00007D55DF7D321C
00007d55df7d6c6b  sub rsp, 0x08
00007d55df7d6c6f  push rax
00007d55df7d6c70  push rcx
00007d55df7d6c71  push rdx
00007d55df7d6c72  push rdi
00007d55df7d6c73  push rsi
00007d55df7d6c74  push r8
00007d55df7d6c76  push r9
00007d55df7d6c78  push r10
00007d55df7d6c7a  push r11
00007d55df7d6c7c  sub rsp, 0xF0
00007d55df7d6c83  vmovaps [rsp], xmm0
00007d55df7d6c88  vmovaps [rsp+0x10], xmm1
00007d55df7d6c8e  vmovaps [rsp+0x20], xmm2
00007d55df7d6c94  vmovaps [rsp+0x30], xmm3
00007d55df7d6c9a  vmovaps [rsp+0x40], xmm4
00007d55df7d6ca0  vmovaps [rsp+0x50], xmm5
00007d55df7d6ca6  vmovaps [rsp+0x60], xmm6
00007d55df7d6cac  vmovaps [rsp+0x70], xmm7
00007d55df7d6cb2  vmovaps [rsp+0x80], xmm8
00007d55df7d6cbb  vmovaps [rsp+0x90], xmm9
00007d55df7d6cc4  vmovaps [rsp+0xA0], xmm11
00007d55df7d6ccd  vmovaps [rsp+0xB0], xmm12
00007d55df7d6cd6  vmovaps [rsp+0xC0], xmm13
00007d55df7d6cdf  vmovaps [rsp+0xD0], xmm14
00007d55df7d6ce8  vmovaps [rsp+0xE0], xmm15
00007d55df7d6cf1  sub rsp, 0x30
00007d55df7d6cf5  movaps [rsp], xmm10
00007d55df7d6cfa  movaps [rsp+0x10], xmm1
00007d55df7d6cff  movaps [rsp+0x20], xmm11
00007d55df7d6d05  lea rdi, [rsp]
00007d55df7d6d09  mov esi, 0x00
00007d55df7d6d0e  mov rax, 0x5BB8433D8530
00007d55df7d6d18  call rax
00007d55df7d6d1a  movaps xmm10, [rsp]
00007d55df7d6d1f  add rsp, 0x30
00007d55df7d6d23  vmovaps xmm0, [rsp]
00007d55df7d6d28  vmovaps xmm1, [rsp+0x10]
00007d55df7d6d2e  vmovaps xmm2, [rsp+0x20]
00007d55df7d6d34  vmovaps xmm3, [rsp+0x30]
00007d55df7d6d3a  vmovaps xmm4, [rsp+0x40]
00007d55df7d6d40  vmovaps xmm5, [rsp+0x50]
00007d55df7d6d46  vmovaps xmm6, [rsp+0x60]
00007d55df7d6d4c  vmovaps xmm7, [rsp+0x70]
00007d55df7d6d52  vmovaps xmm8, [rsp+0x80]
00007d55df7d6d5b  vmovaps xmm9, [rsp+0x90]
00007d55df7d6d64  vmovaps xmm11, [rsp+0xA0]
00007d55df7d6d6d  vmovaps xmm12, [rsp+0xB0]
00007d55df7d6d76  vmovaps xmm13, [rsp+0xC0]
00007d55df7d6d7f  vmovaps xmm14, [rsp+0xD0]
00007d55df7d6d88  vmovaps xmm15, [rsp+0xE0]
00007d55df7d6d91  add rsp, 0xF0
00007d55df7d6d98  pop r11
00007d55df7d6d9a  pop r10
00007d55df7d6d9c  pop r9
00007d55df7d6d9e  pop r8
00007d55df7d6da0  pop rsi
00007d55df7d6da1  pop rdi
00007d55df7d6da2  pop rdx
00007d55df7d6da3  pop rcx
00007d55df7d6da4  pop rax
00007d55df7d6da5  add rsp, 0x08
00007d55df7d6da9  jmp 0x00007D55DF7D3237
00007d55df7d6dae  sub rsp, 0x08
00007d55df7d6db2  push rax
00007d55df7d6db3  push rcx
00007d55df7d6db4  push rdx
00007d55df7d6db5  push rdi
00007d55df7d6db6  push rsi
00007d55df7d6db7  push r8
00007d55df7d6db9  push r9
00007d55df7d6dbb  push r10
00007d55df7d6dbd  push r11
00007d55df7d6dbf  sub rsp, 0xF0
00007d55df7d6dc6  vmovaps [rsp], xmm0
00007d55df7d6dcb  vmovaps [rsp+0x10], xmm2
00007d55df7d6dd1  vmovaps [rsp+0x20], xmm3
00007d55df7d6dd7  vmovaps [rsp+0x30], xmm4
00007d55df7d6ddd  vmovaps [rsp+0x40], xmm5
00007d55df7d6de3  vmovaps [rsp+0x50], xmm6
00007d55df7d6de9  vmovaps [rsp+0x60], xmm7
00007d55df7d6def  vmovaps [rsp+0x70], xmm8
00007d55df7d6df5  vmovaps [rsp+0x80], xmm9
00007d55df7d6dfe  vmovaps [rsp+0x90], xmm10
00007d55df7d6e07  vmovaps [rsp+0xA0], xmm11
00007d55df7d6e10  vmovaps [rsp+0xB0], xmm12
00007d55df7d6e19  vmovaps [rsp+0xC0], xmm13
00007d55df7d6e22  vmovaps [rsp+0xD0], xmm14
00007d55df7d6e2b  vmovaps [rsp+0xE0], xmm15
00007d55df7d6e34  sub rsp, 0x30
00007d55df7d6e38  movaps [rsp], xmm1
00007d55df7d6e3c  movaps [rsp+0x10], xmm15
00007d55df7d6e42  movaps [rsp+0x20], xmm6
00007d55df7d6e47  lea rdi, [rsp]
00007d55df7d6e4b  mov esi, 0x00
00007d55df7d6e50  mov rax, 0x5BB8433D8530
00007d55df7d6e5a  call rax
00007d55df7d6e5c  movaps xmm1, [rsp]
00007d55df7d6e60  add rsp, 0x30
00007d55df7d6e64  vmovaps xmm0, [rsp]
00007d55df7d6e69  vmovaps xmm2, [rsp+0x10]
00007d55df7d6e6f  vmovaps xmm3, [rsp+0x20]
00007d55df7d6e75  vmovaps xmm4, [rsp+0x30]
00007d55df7d6e7b  vmovaps xmm5, [rsp+0x40]
00007d55df7d6e81  vmovaps xmm6, [rsp+0x50]
00007d55df7d6e87  vmovaps xmm7, [rsp+0x60]
00007d55df7d6e8d  vmovaps xmm8, [rsp+0x70]
00007d55df7d6e93  vmovaps xmm9, [rsp+0x80]
00007d55df7d6e9c  vmovaps xmm10, [rsp+0x90]
00007d55df7d6ea5  vmovaps xmm11, [rsp+0xA0]
00007d55df7d6eae  vmovaps xmm12, [rsp+0xB0]
00007d55df7d6eb7  vmovaps xmm13, [rsp+0xC0]
00007d55df7d6ec0  vmovaps xmm14, [rsp+0xD0]
00007d55df7d6ec9  vmovaps xmm15, [rsp+0xE0]
00007d55df7d6ed2  add rsp, 0xF0
00007d55df7d6ed9  pop r11
00007d55df7d6edb  pop r10
00007d55df7d6edd  pop r9
00007d55df7d6edf  pop r8
00007d55df7d6ee1  pop rsi
00007d55df7d6ee2  pop rdi
00007d55df7d6ee3  pop rdx
00007d55df7d6ee4  pop rcx
00007d55df7d6ee5  pop rax
00007d55df7d6ee6  add rsp, 0x08
00007d55df7d6eea  jmp 0x00007D55DF7D3250
00007d55df7d6eef  sub rsp, 0x08
00007d55df7d6ef3  push rax
00007d55df7d6ef4  push rcx
00007d55df7d6ef5  push rdx
00007d55df7d6ef6  push rdi
00007d55df7d6ef7  push rsi
00007d55df7d6ef8  push r8
00007d55df7d6efa  push r9
00007d55df7d6efc  push r10
00007d55df7d6efe  push r11
00007d55df7d6f00  sub rsp, 0xF0
00007d55df7d6f07  vmovaps [rsp], xmm0
00007d55df7d6f0c  vmovaps [rsp+0x10], xmm1
00007d55df7d6f12  vmovaps [rsp+0x20], xmm2
00007d55df7d6f18  vmovaps [rsp+0x30], xmm3
00007d55df7d6f1e  vmovaps [rsp+0x40], xmm4
00007d55df7d6f24  vmovaps [rsp+0x50], xmm5
00007d55df7d6f2a  vmovaps [rsp+0x60], xmm6
00007d55df7d6f30  vmovaps [rsp+0x70], xmm7
00007d55df7d6f36  vmovaps [rsp+0x80], xmm8
00007d55df7d6f3f  vmovaps [rsp+0x90], xmm9
00007d55df7d6f48  vmovaps [rsp+0xA0], xmm10
00007d55df7d6f51  vmovaps [rsp+0xB0], xmm12
00007d55df7d6f5a  vmovaps [rsp+0xC0], xmm13
00007d55df7d6f63  vmovaps [rsp+0xD0], xmm14
00007d55df7d6f6c  vmovaps [rsp+0xE0], xmm15
00007d55df7d6f75  sub rsp, 0x30
00007d55df7d6f79  movaps [rsp], xmm11
00007d55df7d6f7e  movaps [rsp+0x10], xmm12
00007d55df7d6f84  movaps [rsp+0x20], xmm15
00007d55df7d6f8a  lea rdi, [rsp]
00007d55df7d6f8e  mov esi, 0x00
00007d55df7d6f93  mov rax, 0x5BB8433D8530
00007d55df7d6f9d  call rax
00007d55df7d6f9f  movaps xmm11, [rsp]
00007d55df7d6fa4  add rsp, 0x30
00007d55df7d6fa8  vmovaps xmm0, [rsp]
00007d55df7d6fad  vmovaps xmm1, [rsp+0x10]
00007d55df7d6fb3  vmovaps xmm2, [rsp+0x20]
00007d55df7d6fb9  vmovaps xmm3, [rsp+0x30]
00007d55df7d6fbf  vmovaps xmm4, [rsp+0x40]
00007d55df7d6fc5  vmovaps xmm5, [rsp+0x50]
00007d55df7d6fcb  vmovaps xmm6, [rsp+0x60]
00007d55df7d6fd1  vmovaps xmm7, [rsp+0x70]
00007d55df7d6fd7  vmovaps xmm8, [rsp+0x80]
00007d55df7d6fe0  vmovaps xmm9, [rsp+0x90]
00007d55df7d6fe9  vmovaps xmm10, [rsp+0xA0]
00007d55df7d6ff2  vmovaps xmm12, [rsp+0xB0]
00007d55df7d6ffb  vmovaps xmm13, [rsp+0xC0]
00007d55df7d7004  vmovaps xmm14, [rsp+0xD0]
00007d55df7d700d  vmovaps xmm15, [rsp+0xE0]
00007d55df7d7016  add rsp, 0xF0
00007d55df7d701d  pop r11
00007d55df7d701f  pop r10
00007d55df7d7021  pop r9
00007d55df7d7023  pop r8
00007d55df7d7025  pop rsi
00007d55df7d7026  pop rdi
00007d55df7d7027  pop rdx
00007d55df7d7028  pop rcx
00007d55df7d7029  pop rax
00007d55df7d702a  add rsp, 0x08
00007d55df7d702e  jmp 0x00007D55DF7D327A
00007d55df7d7033  sub rsp, 0x08
00007d55df7d7037  push rax
00007d55df7d7038  push rcx
00007d55df7d7039  push rdx
00007d55df7d703a  push rdi
00007d55df7d703b  push rsi
00007d55df7d703c  push r8
00007d55df7d703e  push r9
00007d55df7d7040  push r10
00007d55df7d7042  push r11
00007d55df7d7044  sub rsp, 0xF0
00007d55df7d704b  vmovaps [rsp], xmm0
00007d55df7d7050  vmovaps [rsp+0x10], xmm1
00007d55df7d7056  vmovaps [rsp+0x20], xmm2
00007d55df7d705c  vmovaps [rsp+0x30], xmm3
00007d55df7d7062  vmovaps [rsp+0x40], xmm4
00007d55df7d7068  vmovaps [rsp+0x50], xmm5
00007d55df7d706e  vmovaps [rsp+0x60], xmm6
00007d55df7d7074  vmovaps [rsp+0x70], xmm7
00007d55df7d707a  vmovaps [rsp+0x80], xmm8
00007d55df7d7083  vmovaps [rsp+0x90], xmm9
00007d55df7d708c  vmovaps [rsp+0xA0], xmm10
00007d55df7d7095  vmovaps [rsp+0xB0], xmm11
00007d55df7d709e  vmovaps [rsp+0xC0], xmm13
00007d55df7d70a7  vmovaps [rsp+0xD0], xmm14
00007d55df7d70b0  vmovaps [rsp+0xE0], xmm15
00007d55df7d70b9  sub rsp, 0x30
00007d55df7d70bd  movaps [rsp], xmm12
00007d55df7d70c2  movaps [rsp+0x10], xmm8
00007d55df7d70c8  movaps [rsp+0x20], xmm15
00007d55df7d70ce  lea rdi, [rsp]
00007d55df7d70d2  mov esi, 0x00
00007d55df7d70d7  mov rax, 0x5BB8433D8530
00007d55df7d70e1  call rax
00007d55df7d70e3  movaps xmm12, [rsp]
00007d55df7d70e8  add rsp, 0x30
00007d55df7d70ec  vmovaps xmm0, [rsp]
00007d55df7d70f1  vmovaps xmm1, [rsp+0x10]
00007d55df7d70f7  vmovaps xmm2, [rsp+0x20]
00007d55df7d70fd  vmovaps xmm3, [rsp+0x30]
00007d55df7d7103  vmovaps xmm4, [rsp+0x40]
00007d55df7d7109  vmovaps xmm5, [rsp+0x50]
00007d55df7d710f  vmovaps xmm6, [rsp+0x60]
00007d55df7d7115  vmovaps xmm7, [rsp+0x70]
00007d55df7d711b  vmovaps xmm8, [rsp+0x80]
00007d55df7d7124  vmovaps xmm9, [rsp+0x90]
00007d55df7d712d  vmovaps xmm10, [rsp+0xA0]
00007d55df7d7136  vmovaps xmm11, [rsp+0xB0]
00007d55df7d713f  vmovaps xmm13, [rsp+0xC0]
00007d55df7d7148  vmovaps xmm14, [rsp+0xD0]
00007d55df7d7151  vmovaps xmm15, [rsp+0xE0]
00007d55df7d715a  add rsp, 0xF0
00007d55df7d7161  pop r11
00007d55df7d7163  pop r10
00007d55df7d7165  pop r9
00007d55df7d7167  pop r8
00007d55df7d7169  pop rsi
00007d55df7d716a  pop rdi
00007d55df7d716b  pop rdx
00007d55df7d716c  pop rcx
00007d55df7d716d  pop rax
00007d55df7d716e  add rsp, 0x08
00007d55df7d7172  jmp 0x00007D55DF7D32A9
00007d55df7d7177  sub rsp, 0x08
00007d55df7d717b  push rax
00007d55df7d717c  push rcx
00007d55df7d717d  push rdx
00007d55df7d717e  push rdi
00007d55df7d717f  push rsi
00007d55df7d7180  push r8
00007d55df7d7182  push r9
00007d55df7d7184  push r10
00007d55df7d7186  push r11
00007d55df7d7188  sub rsp, 0xF0
00007d55df7d718f  vmovaps [rsp], xmm0
00007d55df7d7194  vmovaps [rsp+0x10], xmm1
00007d55df7d719a  vmovaps [rsp+0x20], xmm2
00007d55df7d71a0  vmovaps [rsp+0x30], xmm3
00007d55df7d71a6  vmovaps [rsp+0x40], xmm4
00007d55df7d71ac  vmovaps [rsp+0x50], xmm5
00007d55df7d71b2  vmovaps [rsp+0x60], xmm6
00007d55df7d71b8  vmovaps [rsp+0x70], xmm7
00007d55df7d71be  vmovaps [rsp+0x80], xmm9
00007d55df7d71c7  vmovaps [rsp+0x90], xmm10
00007d55df7d71d0  vmovaps [rsp+0xA0], xmm11
00007d55df7d71d9  vmovaps [rsp+0xB0], xmm12
00007d55df7d71e2  vmovaps [rsp+0xC0], xmm13
00007d55df7d71eb  vmovaps [rsp+0xD0], xmm14
00007d55df7d71f4  vmovaps [rsp+0xE0], xmm15
00007d55df7d71fd  sub rsp, 0x30
00007d55df7d7201  movaps [rsp], xmm8
00007d55df7d7206  movaps [rsp+0x10], xmm7
00007d55df7d720b  movaps [rsp+0x20], xmm15
00007d55df7d7211  lea rdi, [rsp]
00007d55df7d7215  mov esi, 0x00
00007d55df7d721a  mov rax, 0x5BB8433D8530
00007d55df7d7224  call rax
00007d55df7d7226  movaps xmm8, [rsp]
00007d55df7d722b  add rsp, 0x30
00007d55df7d722f  vmovaps xmm0, [rsp]
00007d55df7d7234  vmovaps xmm1, [rsp+0x10]
00007d55df7d723a  vmovaps xmm2, [rsp+0x20]
00007d55df7d7240  vmovaps xmm3, [rsp+0x30]
00007d55df7d7246  vmovaps xmm4, [rsp+0x40]
00007d55df7d724c  vmovaps xmm5, [rsp+0x50]
00007d55df7d7252  vmovaps xmm6, [rsp+0x60]
00007d55df7d7258  vmovaps xmm7, [rsp+0x70]
00007d55df7d725e  vmovaps xmm9, [rsp+0x80]
00007d55df7d7267  vmovaps xmm10, [rsp+0x90]
00007d55df7d7270  vmovaps xmm11, [rsp+0xA0]
00007d55df7d7279  vmovaps xmm12, [rsp+0xB0]
00007d55df7d7282  vmovaps xmm13, [rsp+0xC0]
00007d55df7d728b  vmovaps xmm14, [rsp+0xD0]
00007d55df7d7294  vmovaps xmm15, [rsp+0xE0]
00007d55df7d729d  add rsp, 0xF0
00007d55df7d72a4  pop r11
00007d55df7d72a6  pop r10
00007d55df7d72a8  pop r9
00007d55df7d72aa  pop r8
00007d55df7d72ac  pop rsi
00007d55df7d72ad  pop rdi
00007d55df7d72ae  pop rdx
00007d55df7d72af  pop rcx
00007d55df7d72b0  pop rax
00007d55df7d72b1  add rsp, 0x08
00007d55df7d72b5  jmp 0x00007D55DF7D32CF
00007d55df7d72ba  sub rsp, 0x08
00007d55df7d72be  push rax
00007d55df7d72bf  push rcx
00007d55df7d72c0  push rdx
00007d55df7d72c1  push rdi
00007d55df7d72c2  push rsi
00007d55df7d72c3  push r8
00007d55df7d72c5  push r9
00007d55df7d72c7  push r10
00007d55df7d72c9  push r11
00007d55df7d72cb  sub rsp, 0xF0
00007d55df7d72d2  vmovaps [rsp], xmm0
00007d55df7d72d7  vmovaps [rsp+0x10], xmm1
00007d55df7d72dd  vmovaps [rsp+0x20], xmm2
00007d55df7d72e3  vmovaps [rsp+0x30], xmm3
00007d55df7d72e9  vmovaps [rsp+0x40], xmm4
00007d55df7d72ef  vmovaps [rsp+0x50], xmm5
00007d55df7d72f5  vmovaps [rsp+0x60], xmm6
00007d55df7d72fb  vmovaps [rsp+0x70], xmm7
00007d55df7d7301  vmovaps [rsp+0x80], xmm8
00007d55df7d730a  vmovaps [rsp+0x90], xmm9
00007d55df7d7313  vmovaps [rsp+0xA0], xmm10
00007d55df7d731c  vmovaps [rsp+0xB0], xmm11
00007d55df7d7325  vmovaps [rsp+0xC0], xmm12
00007d55df7d732e  vmovaps [rsp+0xD0], xmm13
00007d55df7d7337  vmovaps [rsp+0xE0], xmm14
00007d55df7d7340  sub rsp, 0x30
00007d55df7d7344  movaps [rsp], xmm15
00007d55df7d7349  movaps [rsp+0x10], xmm14
00007d55df7d734f  movaps [rsp+0x20], xmm9
00007d55df7d7355  lea rdi, [rsp]
00007d55df7d7359  mov esi, 0x00
00007d55df7d735e  mov rax, 0x5BB8433D8530
00007d55df7d7368  call rax
00007d55df7d736a  movaps xmm15, [rsp]
00007d55df7d736f  add rsp, 0x30
00007d55df7d7373  vmovaps xmm0, [rsp]
00007d55df7d7378  vmovaps xmm1, [rsp+0x10]
00007d55df7d737e  vmovaps xmm2, [rsp+0x20]
00007d55df7d7384  vmovaps xmm3, [rsp+0x30]
00007d55df7d738a  vmovaps xmm4, [rsp+0x40]
00007d55df7d7390  vmovaps xmm5, [rsp+0x50]
00007d55df7d7396  vmovaps xmm6, [rsp+0x60]
00007d55df7d739c  vmovaps xmm7, [rsp+0x70]
00007d55df7d73a2  vmovaps xmm8, [rsp+0x80]
00007d55df7d73ab  vmovaps xmm9, [rsp+0x90]
00007d55df7d73b4  vmovaps xmm10, [rsp+0xA0]
00007d55df7d73bd  vmovaps xmm11, [rsp+0xB0]
00007d55df7d73c6  vmovaps xmm12, [rsp+0xC0]
00007d55df7d73cf  vmovaps xmm13, [rsp+0xD0]
00007d55df7d73d8  vmovaps xmm14, [rsp+0xE0]
00007d55df7d73e1  add rsp, 0xF0
00007d55df7d73e8  pop r11
00007d55df7d73ea  pop r10
00007d55df7d73ec  pop r9
00007d55df7d73ee  pop r8
00007d55df7d73f0  pop rsi
00007d55df7d73f1  pop rdi
00007d55df7d73f2  pop rdx
00007d55df7d73f3  pop rcx
00007d55df7d73f4  pop rax
00007d55df7d73f5  add rsp, 0x08
00007d55df7d73f9  jmp 0x00007D55DF7D32E9
00007d55df7d73fe  sub rsp, 0x08
00007d55df7d7402  push rax
00007d55df7d7403  push rcx
00007d55df7d7404  push rdx
00007d55df7d7405  push rdi
00007d55df7d7406  push rsi
00007d55df7d7407  push r8
00007d55df7d7409  push r9
00007d55df7d740b  push r10
00007d55df7d740d  push r11
00007d55df7d740f  sub rsp, 0xF0
00007d55df7d7416  vmovaps [rsp], xmm0
00007d55df7d741b  vmovaps [rsp+0x10], xmm1
00007d55df7d7421  vmovaps [rsp+0x20], xmm2
00007d55df7d7427  vmovaps [rsp+0x30], xmm3
00007d55df7d742d  vmovaps [rsp+0x40], xmm4
00007d55df7d7433  vmovaps [rsp+0x50], xmm5
00007d55df7d7439  vmovaps [rsp+0x60], xmm6
00007d55df7d743f  vmovaps [rsp+0x70], xmm7
00007d55df7d7445  vmovaps [rsp+0x80], xmm8
00007d55df7d744e  vmovaps [rsp+0x90], xmm10
00007d55df7d7457  vmovaps [rsp+0xA0], xmm11
00007d55df7d7460  vmovaps [rsp+0xB0], xmm12
00007d55df7d7469  vmovaps [rsp+0xC0], xmm13
00007d55df7d7472  vmovaps [rsp+0xD0], xmm14
00007d55df7d747b  vmovaps [rsp+0xE0], xmm15
00007d55df7d7484  sub rsp, 0x30
00007d55df7d7488  movaps [rsp], xmm9
00007d55df7d748d  movaps [rsp+0x10], xmm7
00007d55df7d7492  movaps [rsp+0x20], xmm14
00007d55df7d7498  lea rdi, [rsp]
00007d55df7d749c  mov esi, 0x00
00007d55df7d74a1  mov rax, 0x5BB8433D8530
00007d55df7d74ab  call rax
00007d55df7d74ad  movaps xmm9, [rsp]
00007d55df7d74b2  add rsp, 0x30
00007d55df7d74b6  vmovaps xmm0, [rsp]
00007d55df7d74bb  vmovaps xmm1, [rsp+0x10]
00007d55df7d74c1  vmovaps xmm2, [rsp+0x20]
00007d55df7d74c7  vmovaps xmm3, [rsp+0x30]
00007d55df7d74cd  vmovaps xmm4, [rsp+0x40]
00007d55df7d74d3  vmovaps xmm5, [rsp+0x50]
00007d55df7d74d9  vmovaps xmm6, [rsp+0x60]
00007d55df7d74df  vmovaps xmm7, [rsp+0x70]
00007d55df7d74e5  vmovaps xmm8, [rsp+0x80]
00007d55df7d74ee  vmovaps xmm10, [rsp+0x90]
00007d55df7d74f7  vmovaps xmm11, [rsp+0xA0]
00007d55df7d7500  vmovaps xmm12, [rsp+0xB0]
00007d55df7d7509  vmovaps xmm13, [rsp+0xC0]
00007d55df7d7512  vmovaps xmm14, [rsp+0xD0]
00007d55df7d751b  vmovaps xmm15, [rsp+0xE0]
00007d55df7d7524  add rsp, 0xF0
00007d55df7d752b  pop r11
00007d55df7d752d  pop r10
00007d55df7d752f  pop r9
00007d55df7d7531  pop r8
00007d55df7d7533  pop rsi
00007d55df7d7534  pop rdi
00007d55df7d7535  pop rdx
00007d55df7d7536  pop rcx
00007d55df7d7537  pop rax
00007d55df7d7538  add rsp, 0x08
00007d55df7d753c  jmp 0x00007D55DF7D3318
00007d55df7d7541  sub rsp, 0x08
00007d55df7d7545  push rax
00007d55df7d7546  push rcx
00007d55df7d7547  push rdx
00007d55df7d7548  push rdi
00007d55df7d7549  push rsi
00007d55df7d754a  push r8
00007d55df7d754c  push r9
00007d55df7d754e  push r10
00007d55df7d7550  push r11
00007d55df7d7552  sub rsp, 0xF0
00007d55df7d7559  vmovaps [rsp], xmm0
00007d55df7d755e  vmovaps [rsp+0x10], xmm1
00007d55df7d7564  vmovaps [rsp+0x20], xmm2
00007d55df7d756a  vmovaps [rsp+0x30], xmm3
00007d55df7d7570  vmovaps [rsp+0x40], xmm4
00007d55df7d7576  vmovaps [rsp+0x50], xmm5
00007d55df7d757c  vmovaps [rsp+0x60], xmm6
00007d55df7d7582  vmovaps [rsp+0x70], xmm7
00007d55df7d7588  vmovaps [rsp+0x80], xmm8
00007d55df7d7591  vmovaps [rsp+0x90], xmm9
00007d55df7d759a  vmovaps [rsp+0xA0], xmm10
00007d55df7d75a3  vmovaps [rsp+0xB0], xmm11
00007d55df7d75ac  vmovaps [rsp+0xC0], xmm12
00007d55df7d75b5  vmovaps [rsp+0xD0], xmm13
00007d55df7d75be  vmovaps [rsp+0xE0], xmm15
00007d55df7d75c7  sub rsp, 0x30
00007d55df7d75cb  movaps [rsp], xmm14
00007d55df7d75d0  movaps [rsp+0x10], xmm13
00007d55df7d75d6  movaps [rsp+0x20], xmm11
00007d55df7d75dc  lea rdi, [rsp]
00007d55df7d75e0  mov esi, 0x00
00007d55df7d75e5  mov rax, 0x5BB8433D8530
00007d55df7d75ef  call rax
00007d55df7d75f1  movaps xmm14, [rsp]
00007d55df7d75f6  add rsp, 0x30
00007d55df7d75fa  vmovaps xmm0, [rsp]
00007d55df7d75ff  vmovaps xmm1, [rsp+0x10]
00007d55df7d7605  vmovaps xmm2, [rsp+0x20]
00007d55df7d760b  vmovaps xmm3, [rsp+0x30]
00007d55df7d7611  vmovaps xmm4, [rsp+0x40]
00007d55df7d7617  vmovaps xmm5, [rsp+0x50]
00007d55df7d761d  vmovaps xmm6, [rsp+0x60]
00007d55df7d7623  vmovaps xmm7, [rsp+0x70]
00007d55df7d7629  vmovaps xmm8, [rsp+0x80]
00007d55df7d7632  vmovaps xmm9, [rsp+0x90]
00007d55df7d763b  vmovaps xmm10, [rsp+0xA0]
00007d55df7d7644  vmovaps xmm11, [rsp+0xB0]
00007d55df7d764d  vmovaps xmm12, [rsp+0xC0]
00007d55df7d7656  vmovaps xmm13, [rsp+0xD0]
00007d55df7d765f  vmovaps xmm15, [rsp+0xE0]
00007d55df7d7668  add rsp, 0xF0
00007d55df7d766f  pop r11
00007d55df7d7671  pop r10
00007d55df7d7673  pop r9
00007d55df7d7675  pop r8
00007d55df7d7677  pop rsi
00007d55df7d7678  pop rdi
00007d55df7d7679  pop rdx
00007d55df7d767a  pop rcx
00007d55df7d767b  pop rax
00007d55df7d767c  add rsp, 0x08
00007d55df7d7680  jmp 0x00007D55DF7D3332
00007d55df7d7685  sub rsp, 0x08
00007d55df7d7689  push rax
00007d55df7d768a  push rcx
00007d55df7d768b  push rdx
00007d55df7d768c  push rdi
00007d55df7d768d  push rsi
00007d55df7d768e  push r8
00007d55df7d7690  push r9
00007d55df7d7692  push r10
00007d55df7d7694  push r11
00007d55df7d7696  sub rsp, 0xF0
00007d55df7d769d  vmovaps [rsp], xmm0
00007d55df7d76a2  vmovaps [rsp+0x10], xmm1
00007d55df7d76a8  vmovaps [rsp+0x20], xmm2
00007d55df7d76ae  vmovaps [rsp+0x30], xmm3
00007d55df7d76b4  vmovaps [rsp+0x40], xmm4
00007d55df7d76ba  vmovaps [rsp+0x50], xmm5
00007d55df7d76c0  vmovaps [rsp+0x60], xmm6
00007d55df7d76c6  vmovaps [rsp+0x70], xmm7
00007d55df7d76cc  vmovaps [rsp+0x80], xmm8
00007d55df7d76d5  vmovaps [rsp+0x90], xmm9
00007d55df7d76de  vmovaps [rsp+0xA0], xmm10
00007d55df7d76e7  vmovaps [rsp+0xB0], xmm12
00007d55df7d76f0  vmovaps [rsp+0xC0], xmm13
00007d55df7d76f9  vmovaps [rsp+0xD0], xmm14
00007d55df7d7702  vmovaps [rsp+0xE0], xmm15
00007d55df7d770b  sub rsp, 0x30
00007d55df7d770f  movaps [rsp], xmm11
00007d55df7d7714  movaps [rsp+0x10], xmm7
00007d55df7d7719  movaps [rsp+0x20], xmm13
00007d55df7d771f  lea rdi, [rsp]
00007d55df7d7723  mov esi, 0x00
00007d55df7d7728  mov rax, 0x5BB8433D8530
00007d55df7d7732  call rax
00007d55df7d7734  movaps xmm11, [rsp]
00007d55df7d7739  add rsp, 0x30
00007d55df7d773d  vmovaps xmm0, [rsp]
00007d55df7d7742  vmovaps xmm1, [rsp+0x10]
00007d55df7d7748  vmovaps xmm2, [rsp+0x20]
00007d55df7d774e  vmovaps xmm3, [rsp+0x30]
00007d55df7d7754  vmovaps xmm4, [rsp+0x40]
00007d55df7d775a  vmovaps xmm5, [rsp+0x50]
00007d55df7d7760  vmovaps xmm6, [rsp+0x60]
00007d55df7d7766  vmovaps xmm7, [rsp+0x70]
00007d55df7d776c  vmovaps xmm8, [rsp+0x80]
00007d55df7d7775  vmovaps xmm9, [rsp+0x90]
00007d55df7d777e  vmovaps xmm10, [rsp+0xA0]
00007d55df7d7787  vmovaps xmm12, [rsp+0xB0]
00007d55df7d7790  vmovaps xmm13, [rsp+0xC0]
00007d55df7d7799  vmovaps xmm14, [rsp+0xD0]
00007d55df7d77a2  vmovaps xmm15, [rsp+0xE0]
00007d55df7d77ab  add rsp, 0xF0
00007d55df7d77b2  pop r11
00007d55df7d77b4  pop r10
00007d55df7d77b6  pop r9
00007d55df7d77b8  pop r8
00007d55df7d77ba  pop rsi
00007d55df7d77bb  pop rdi
00007d55df7d77bc  pop rdx
00007d55df7d77bd  pop rcx
00007d55df7d77be  pop rax
00007d55df7d77bf  add rsp, 0x08
00007d55df7d77c3  jmp 0x00007D55DF7D335E
00007d55df7d77c8  sub rsp, 0x08
00007d55df7d77cc  push rax
00007d55df7d77cd  push rcx
00007d55df7d77ce  push rdx
00007d55df7d77cf  push rdi
00007d55df7d77d0  push rsi
00007d55df7d77d1  push r8
00007d55df7d77d3  push r9
00007d55df7d77d5  push r10
00007d55df7d77d7  push r11
00007d55df7d77d9  sub rsp, 0xF0
00007d55df7d77e0  vmovaps [rsp], xmm0
00007d55df7d77e5  vmovaps [rsp+0x10], xmm1
00007d55df7d77eb  vmovaps [rsp+0x20], xmm2
00007d55df7d77f1  vmovaps [rsp+0x30], xmm3
00007d55df7d77f7  vmovaps [rsp+0x40], xmm4
00007d55df7d77fd  vmovaps [rsp+0x50], xmm5
00007d55df7d7803  vmovaps [rsp+0x60], xmm6
00007d55df7d7809  vmovaps [rsp+0x70], xmm7
00007d55df7d780f  vmovaps [rsp+0x80], xmm8
00007d55df7d7818  vmovaps [rsp+0x90], xmm9
00007d55df7d7821  vmovaps [rsp+0xA0], xmm10
00007d55df7d782a  vmovaps [rsp+0xB0], xmm11
00007d55df7d7833  vmovaps [rsp+0xC0], xmm12
00007d55df7d783c  vmovaps [rsp+0xD0], xmm14
00007d55df7d7845  vmovaps [rsp+0xE0], xmm15
00007d55df7d784e  sub rsp, 0x30
00007d55df7d7852  movaps [rsp], xmm13
00007d55df7d7857  movaps [rsp+0x10], xmm10
00007d55df7d785d  movaps [rsp+0x20], xmm12
00007d55df7d7863  lea rdi, [rsp]
00007d55df7d7867  mov esi, 0x00
00007d55df7d786c  mov rax, 0x5BB8433D8530
00007d55df7d7876  call rax
00007d55df7d7878  movaps xmm13, [rsp]
00007d55df7d787d  add rsp, 0x30
00007d55df7d7881  vmovaps xmm0, [rsp]
00007d55df7d7886  vmovaps xmm1, [rsp+0x10]
00007d55df7d788c  vmovaps xmm2, [rsp+0x20]
00007d55df7d7892  vmovaps xmm3, [rsp+0x30]
00007d55df7d7898  vmovaps xmm4, [rsp+0x40]
00007d55df7d789e  vmovaps xmm5, [rsp+0x50]
00007d55df7d78a4  vmovaps xmm6, [rsp+0x60]
00007d55df7d78aa  vmovaps xmm7, [rsp+0x70]
00007d55df7d78b0  vmovaps xmm8, [rsp+0x80]
00007d55df7d78b9  vmovaps xmm9, [rsp+0x90]
00007d55df7d78c2  vmovaps xmm10, [rsp+0xA0]
00007d55df7d78cb  vmovaps xmm11, [rsp+0xB0]
00007d55df7d78d4  vmovaps xmm12, [rsp+0xC0]
00007d55df7d78dd  vmovaps xmm14, [rsp+0xD0]
00007d55df7d78e6  vmovaps xmm15, [rsp+0xE0]
00007d55df7d78ef  add rsp, 0xF0
00007d55df7d78f6  pop r11
00007d55df7d78f8  pop r10
00007d55df7d78fa  pop r9
00007d55df7d78fc  pop r8
00007d55df7d78fe  pop rsi
00007d55df7d78ff  pop rdi
00007d55df7d7900  pop rdx
00007d55df7d7901  pop rcx
00007d55df7d7902  pop rax
00007d55df7d7903  add rsp, 0x08
00007d55df7d7907  jmp 0x00007D55DF7D3378
00007d55df7d790c  sub rsp, 0x08
00007d55df7d7910  push rax
00007d55df7d7911  push rcx
00007d55df7d7912  push rdx
00007d55df7d7913  push rdi
00007d55df7d7914  push rsi
00007d55df7d7915  push r8
00007d55df7d7917  push r9
00007d55df7d7919  push r10
00007d55df7d791b  push r11
00007d55df7d791d  sub rsp, 0xF0
00007d55df7d7924  vmovaps [rsp], xmm0
00007d55df7d7929  vmovaps [rsp+0x10], xmm1
00007d55df7d792f  vmovaps [rsp+0x20], xmm2
00007d55df7d7935  vmovaps [rsp+0x30], xmm3
00007d55df7d793b  vmovaps [rsp+0x40], xmm4
00007d55df7d7941  vmovaps [rsp+0x50], xmm5
00007d55df7d7947  vmovaps [rsp+0x60], xmm6
00007d55df7d794d  vmovaps [rsp+0x70], xmm7
00007d55df7d7953  vmovaps [rsp+0x80], xmm8
00007d55df7d795c  vmovaps [rsp+0x90], xmm9
00007d55df7d7965  vmovaps [rsp+0xA0], xmm11
00007d55df7d796e  vmovaps [rsp+0xB0], xmm12
00007d55df7d7977  vmovaps [rsp+0xC0], xmm13
00007d55df7d7980  vmovaps [rsp+0xD0], xmm14
00007d55df7d7989  vmovaps [rsp+0xE0], xmm15
00007d55df7d7992  sub rsp, 0x30
00007d55df7d7996  movaps [rsp], xmm10
00007d55df7d799b  movaps [rsp+0x10], xmm7
00007d55df7d79a0  movaps [rsp+0x20], xmm12
00007d55df7d79a6  lea rdi, [rsp]
00007d55df7d79aa  mov esi, 0x00
00007d55df7d79af  mov rax, 0x5BB8433D8530
00007d55df7d79b9  call rax
00007d55df7d79bb  movaps xmm10, [rsp]
00007d55df7d79c0  add rsp, 0x30
00007d55df7d79c4  vmovaps xmm0, [rsp]
00007d55df7d79c9  vmovaps xmm1, [rsp+0x10]
00007d55df7d79cf  vmovaps xmm2, [rsp+0x20]
00007d55df7d79d5  vmovaps xmm3, [rsp+0x30]
00007d55df7d79db  vmovaps xmm4, [rsp+0x40]
00007d55df7d79e1  vmovaps xmm5, [rsp+0x50]
00007d55df7d79e7  vmovaps xmm6, [rsp+0x60]
00007d55df7d79ed  vmovaps xmm7, [rsp+0x70]
00007d55df7d79f3  vmovaps xmm8, [rsp+0x80]
00007d55df7d79fc  vmovaps xmm9, [rsp+0x90]
00007d55df7d7a05  vmovaps xmm11, [rsp+0xA0]
00007d55df7d7a0e  vmovaps xmm12, [rsp+0xB0]
00007d55df7d7a17  vmovaps xmm13, [rsp+0xC0]
00007d55df7d7a20  vmovaps xmm14, [rsp+0xD0]
00007d55df7d7a29  vmovaps xmm15, [rsp+0xE0]
00007d55df7d7a32  add rsp, 0xF0
00007d55df7d7a39  pop r11
00007d55df7d7a3b  pop r10
00007d55df7d7a3d  pop r9
00007d55df7d7a3f  pop r8
00007d55df7d7a41  pop rsi
00007d55df7d7a42  pop rdi
00007d55df7d7a43  pop rdx
00007d55df7d7a44  pop rcx
00007d55df7d7a45  pop rax
00007d55df7d7a46  add rsp, 0x08
00007d55df7d7a4a  jmp 0x00007D55DF7D33A4
00007d55df7d7a4f  sub rsp, 0x08
00007d55df7d7a53  push rax
00007d55df7d7a54  push rcx
00007d55df7d7a55  push rdx
00007d55df7d7a56  push rdi
00007d55df7d7a57  push rsi
00007d55df7d7a58  push r8
00007d55df7d7a5a  push r9
00007d55df7d7a5c  push r10
00007d55df7d7a5e  push r11
00007d55df7d7a60  sub rsp, 0xF0
00007d55df7d7a67  vmovaps [rsp], xmm0
00007d55df7d7a6c  vmovaps [rsp+0x10], xmm1
00007d55df7d7a72  vmovaps [rsp+0x20], xmm2
00007d55df7d7a78  vmovaps [rsp+0x30], xmm3
00007d55df7d7a7e  vmovaps [rsp+0x40], xmm4
00007d55df7d7a84  vmovaps [rsp+0x50], xmm5
00007d55df7d7a8a  vmovaps [rsp+0x60], xmm6
00007d55df7d7a90  vmovaps [rsp+0x70], xmm7
00007d55df7d7a96  vmovaps [rsp+0x80], xmm8
00007d55df7d7a9f  vmovaps [rsp+0x90], xmm9
00007d55df7d7aa8  vmovaps [rsp+0xA0], xmm10
00007d55df7d7ab1  vmovaps [rsp+0xB0], xmm11
00007d55df7d7aba  vmovaps [rsp+0xC0], xmm13
00007d55df7d7ac3  vmovaps [rsp+0xD0], xmm14
00007d55df7d7acc  vmovaps [rsp+0xE0], xmm15
00007d55df7d7ad5  sub rsp, 0x30
00007d55df7d7ad9  movaps [rsp], xmm12
00007d55df7d7ade  movaps [rsp+0x10], xmm1
00007d55df7d7ae3  movaps [rsp+0x20], xmm8
00007d55df7d7ae9  lea rdi, [rsp]
00007d55df7d7aed  mov esi, 0x00
00007d55df7d7af2  mov rax, 0x5BB8433D8530
00007d55df7d7afc  call rax
00007d55df7d7afe  movaps xmm12, [rsp]
00007d55df7d7b03  add rsp, 0x30
00007d55df7d7b07  vmovaps xmm0, [rsp]
00007d55df7d7b0c  vmovaps xmm1, [rsp+0x10]
00007d55df7d7b12  vmovaps xmm2, [rsp+0x20]
00007d55df7d7b18  vmovaps xmm3, [rsp+0x30]
00007d55df7d7b1e  vmovaps xmm4, [rsp+0x40]
00007d55df7d7b24  vmovaps xmm5, [rsp+0x50]
00007d55df7d7b2a  vmovaps xmm6, [rsp+0x60]
00007d55df7d7b30  vmovaps xmm7, [rsp+0x70]
00007d55df7d7b36  vmovaps xmm8, [rsp+0x80]
00007d55df7d7b3f  vmovaps xmm9, [rsp+0x90]
00007d55df7d7b48  vmovaps xmm10, [rsp+0xA0]
00007d55df7d7b51  vmovaps xmm11, [rsp+0xB0]
00007d55df7d7b5a  vmovaps xmm13, [rsp+0xC0]
00007d55df7d7b63  vmovaps xmm14, [rsp+0xD0]
00007d55df7d7b6c  vmovaps xmm15, [rsp+0xE0]
00007d55df7d7b75  add rsp, 0xF0
00007d55df7d7b7c  pop r11
00007d55df7d7b7e  pop r10
00007d55df7d7b80  pop r9
00007d55df7d7b82  pop r8
00007d55df7d7b84  pop rsi
00007d55df7d7b85  pop rdi
00007d55df7d7b86  pop rdx
00007d55df7d7b87  pop rcx
00007d55df7d7b88  pop rax
00007d55df7d7b89  add rsp, 0x08
00007d55df7d7b8d  jmp 0x00007D55DF7D33BE
00007d55df7d7b92  call 0x00007D55DF5FF430
00007d55df7d7b97  jmp 0x00007D55DF7D33C8
00007d55df7d7b9c  sub rsp, 0x08
00007d55df7d7ba0  push rax
00007d55df7d7ba1  push rcx
00007d55df7d7ba2  push rdx
00007d55df7d7ba3  push rdi
00007d55df7d7ba4  push rsi
00007d55df7d7ba5  push r8
00007d55df7d7ba7  push r9
00007d55df7d7ba9  push r10
00007d55df7d7bab  push r11
00007d55df7d7bad  sub rsp, 0xF0
00007d55df7d7bb4  vmovaps [rsp], xmm0
00007d55df7d7bb9  vmovaps [rsp+0x10], xmm1
00007d55df7d7bbf  vmovaps [rsp+0x20], xmm2
00007d55df7d7bc5  vmovaps [rsp+0x30], xmm3
00007d55df7d7bcb  vmovaps [rsp+0x40], xmm4
00007d55df7d7bd1  vmovaps [rsp+0x50], xmm5
00007d55df7d7bd7  vmovaps [rsp+0x60], xmm6
00007d55df7d7bdd  vmovaps [rsp+0x70], xmm7
00007d55df7d7be3  vmovaps [rsp+0x80], xmm9
00007d55df7d7bec  vmovaps [rsp+0x90], xmm10
00007d55df7d7bf5  vmovaps [rsp+0xA0], xmm11
00007d55df7d7bfe  vmovaps [rsp+0xB0], xmm12
00007d55df7d7c07  vmovaps [rsp+0xC0], xmm13
00007d55df7d7c10  vmovaps [rsp+0xD0], xmm14
00007d55df7d7c19  vmovaps [rsp+0xE0], xmm15
00007d55df7d7c22  sub rsp, 0x30
00007d55df7d7c26  movaps [rsp], xmm8
00007d55df7d7c2b  movaps [rsp+0x10], xmm15
00007d55df7d7c31  movaps [rsp+0x20], xmm9
00007d55df7d7c37  lea rdi, [rsp]
00007d55df7d7c3b  mov esi, 0x00
00007d55df7d7c40  mov rax, 0x5BB8433D8530
00007d55df7d7c4a  call rax
00007d55df7d7c4c  movaps xmm8, [rsp]
00007d55df7d7c51  add rsp, 0x30
00007d55df7d7c55  vmovaps xmm0, [rsp]
00007d55df7d7c5a  vmovaps xmm1, [rsp+0x10]
00007d55df7d7c60  vmovaps xmm2, [rsp+0x20]
00007d55df7d7c66  vmovaps xmm3, [rsp+0x30]
00007d55df7d7c6c  vmovaps xmm4, [rsp+0x40]
00007d55df7d7c72  vmovaps xmm5, [rsp+0x50]
00007d55df7d7c78  vmovaps xmm6, [rsp+0x60]
00007d55df7d7c7e  vmovaps xmm7, [rsp+0x70]
00007d55df7d7c84  vmovaps xmm9, [rsp+0x80]
00007d55df7d7c8d  vmovaps xmm10, [rsp+0x90]
00007d55df7d7c96  vmovaps xmm11, [rsp+0xA0]
00007d55df7d7c9f  vmovaps xmm12, [rsp+0xB0]
00007d55df7d7ca8  vmovaps xmm13, [rsp+0xC0]
00007d55df7d7cb1  vmovaps xmm14, [rsp+0xD0]
00007d55df7d7cba  vmovaps xmm15, [rsp+0xE0]
00007d55df7d7cc3  add rsp, 0xF0
00007d55df7d7cca  pop r11
00007d55df7d7ccc  pop r10
00007d55df7d7cce  pop r9
00007d55df7d7cd0  pop r8
00007d55df7d7cd2  pop rsi
00007d55df7d7cd3  pop rdi
00007d55df7d7cd4  pop rdx
00007d55df7d7cd5  pop rcx
00007d55df7d7cd6  pop rax
00007d55df7d7cd7  add rsp, 0x08
00007d55df7d7cdb  jmp 0x00007D55DF7D33EA
00007d55df7d7ce0  sub rsp, 0x08
00007d55df7d7ce4  push rax
00007d55df7d7ce5  push rcx
00007d55df7d7ce6  push rdx
00007d55df7d7ce7  push rdi
00007d55df7d7ce8  push rsi
00007d55df7d7ce9  push r8
00007d55df7d7ceb  push r9
00007d55df7d7ced  push r10
00007d55df7d7cef  push r11
00007d55df7d7cf1  sub rsp, 0xF0
00007d55df7d7cf8  vmovaps [rsp], xmm0
00007d55df7d7cfd  vmovaps [rsp+0x10], xmm1
00007d55df7d7d03  vmovaps [rsp+0x20], xmm2
00007d55df7d7d09  vmovaps [rsp+0x30], xmm3
00007d55df7d7d0f  vmovaps [rsp+0x40], xmm4
00007d55df7d7d15  vmovaps [rsp+0x50], xmm5
00007d55df7d7d1b  vmovaps [rsp+0x60], xmm6
00007d55df7d7d21  vmovaps [rsp+0x70], xmm7
00007d55df7d7d27  vmovaps [rsp+0x80], xmm8
00007d55df7d7d30  vmovaps [rsp+0x90], xmm10
00007d55df7d7d39  vmovaps [rsp+0xA0], xmm11
00007d55df7d7d42  vmovaps [rsp+0xB0], xmm12
00007d55df7d7d4b  vmovaps [rsp+0xC0], xmm13
00007d55df7d7d54  vmovaps [rsp+0xD0], xmm14
00007d55df7d7d5d  vmovaps [rsp+0xE0], xmm15
00007d55df7d7d66  sub rsp, 0x30
00007d55df7d7d6a  movaps [rsp], xmm9
00007d55df7d7d6f  movaps [rsp+0x10], xmm1
00007d55df7d7d74  movaps [rsp+0x20], xmm15
00007d55df7d7d7a  lea rdi, [rsp]
00007d55df7d7d7e  mov esi, 0x00
00007d55df7d7d83  mov rax, 0x5BB8433D8530
00007d55df7d7d8d  call rax
00007d55df7d7d8f  movaps xmm9, [rsp]
00007d55df7d7d94  add rsp, 0x30
00007d55df7d7d98  vmovaps xmm0, [rsp]
00007d55df7d7d9d  vmovaps xmm1, [rsp+0x10]
00007d55df7d7da3  vmovaps xmm2, [rsp+0x20]
00007d55df7d7da9  vmovaps xmm3, [rsp+0x30]
00007d55df7d7daf  vmovaps xmm4, [rsp+0x40]
00007d55df7d7db5  vmovaps xmm5, [rsp+0x50]
00007d55df7d7dbb  vmovaps xmm6, [rsp+0x60]
00007d55df7d7dc1  vmovaps xmm7, [rsp+0x70]
00007d55df7d7dc7  vmovaps xmm8, [rsp+0x80]
00007d55df7d7dd0  vmovaps xmm10, [rsp+0x90]
00007d55df7d7dd9  vmovaps xmm11, [rsp+0xA0]
00007d55df7d7de2  vmovaps xmm12, [rsp+0xB0]
00007d55df7d7deb  vmovaps xmm13, [rsp+0xC0]
00007d55df7d7df4  vmovaps xmm14, [rsp+0xD0]
00007d55df7d7dfd  vmovaps xmm15, [rsp+0xE0]
00007d55df7d7e06  add rsp, 0xF0
00007d55df7d7e0d  pop r11
00007d55df7d7e0f  pop r10
00007d55df7d7e11  pop r9
00007d55df7d7e13  pop r8
00007d55df7d7e15  pop rsi
00007d55df7d7e16  pop rdi
00007d55df7d7e17  pop rdx
00007d55df7d7e18  pop rcx
00007d55df7d7e19  pop rax
00007d55df7d7e1a  add rsp, 0x08
00007d55df7d7e1e  jmp 0x00007D55DF7D3418
00007d55df7d7e23  sub rsp, 0x08
00007d55df7d7e27  push rax
00007d55df7d7e28  push rcx
00007d55df7d7e29  push rdx
00007d55df7d7e2a  push rdi
00007d55df7d7e2b  push rsi
00007d55df7d7e2c  push r8
00007d55df7d7e2e  push r9
00007d55df7d7e30  push r10
00007d55df7d7e32  push r11
00007d55df7d7e34  sub rsp, 0xF0
00007d55df7d7e3b  vmovaps [rsp], xmm0
00007d55df7d7e40  vmovaps [rsp+0x10], xmm1
00007d55df7d7e46  vmovaps [rsp+0x20], xmm2
00007d55df7d7e4c  vmovaps [rsp+0x30], xmm3
00007d55df7d7e52  vmovaps [rsp+0x40], xmm4
00007d55df7d7e58  vmovaps [rsp+0x50], xmm5
00007d55df7d7e5e  vmovaps [rsp+0x60], xmm6
00007d55df7d7e64  vmovaps [rsp+0x70], xmm7
00007d55df7d7e6a  vmovaps [rsp+0x80], xmm8
00007d55df7d7e73  vmovaps [rsp+0x90], xmm9
00007d55df7d7e7c  vmovaps [rsp+0xA0], xmm10
00007d55df7d7e85  vmovaps [rsp+0xB0], xmm11
00007d55df7d7e8e  vmovaps [rsp+0xC0], xmm12
00007d55df7d7e97  vmovaps [rsp+0xD0], xmm13
00007d55df7d7ea0  vmovaps [rsp+0xE0], xmm14
00007d55df7d7ea9  sub rsp, 0x30
00007d55df7d7ead  movaps [rsp], xmm15
00007d55df7d7eb2  movaps [rsp+0x10], xmm4
00007d55df7d7eb7  movaps [rsp+0x20], xmm1
00007d55df7d7ebc  lea rdi, [rsp]
00007d55df7d7ec0  mov esi, 0x00
00007d55df7d7ec5  mov rax, 0x5BB8433D8530
00007d55df7d7ecf  call rax
00007d55df7d7ed1  movaps xmm15, [rsp]
00007d55df7d7ed6  add rsp, 0x30
00007d55df7d7eda  vmovaps xmm0, [rsp]
00007d55df7d7edf  vmovaps xmm1, [rsp+0x10]
00007d55df7d7ee5  vmovaps xmm2, [rsp+0x20]
00007d55df7d7eeb  vmovaps xmm3, [rsp+0x30]
00007d55df7d7ef1  vmovaps xmm4, [rsp+0x40]
00007d55df7d7ef7  vmovaps xmm5, [rsp+0x50]
00007d55df7d7efd  vmovaps xmm6, [rsp+0x60]
00007d55df7d7f03  vmovaps xmm7, [rsp+0x70]
00007d55df7d7f09  vmovaps xmm8, [rsp+0x80]
00007d55df7d7f12  vmovaps xmm9, [rsp+0x90]
00007d55df7d7f1b  vmovaps xmm10, [rsp+0xA0]
00007d55df7d7f24  vmovaps xmm11, [rsp+0xB0]
00007d55df7d7f2d  vmovaps xmm12, [rsp+0xC0]
00007d55df7d7f36  vmovaps xmm13, [rsp+0xD0]
00007d55df7d7f3f  vmovaps xmm14, [rsp+0xE0]
00007d55df7d7f48  add rsp, 0xF0
00007d55df7d7f4f  pop r11
00007d55df7d7f51  pop r10
00007d55df7d7f53  pop r9
00007d55df7d7f55  pop r8
00007d55df7d7f57  pop rsi
00007d55df7d7f58  pop rdi
00007d55df7d7f59  pop rdx
00007d55df7d7f5a  pop rcx
00007d55df7d7f5b  pop rax
00007d55df7d7f5c  add rsp, 0x08
00007d55df7d7f60  jmp 0x00007D55DF7D343E
00007d55df7d7f65  sub rsp, 0x08
00007d55df7d7f69  push rax
00007d55df7d7f6a  push rcx
00007d55df7d7f6b  push rdx
00007d55df7d7f6c  push rdi
00007d55df7d7f6d  push rsi
00007d55df7d7f6e  push r8
00007d55df7d7f70  push r9
00007d55df7d7f72  push r10
00007d55df7d7f74  push r11
00007d55df7d7f76  sub rsp, 0xF0
00007d55df7d7f7d  vmovaps [rsp], xmm0
00007d55df7d7f82  vmovaps [rsp+0x10], xmm2
00007d55df7d7f88  vmovaps [rsp+0x20], xmm3
00007d55df7d7f8e  vmovaps [rsp+0x30], xmm4
00007d55df7d7f94  vmovaps [rsp+0x40], xmm5
00007d55df7d7f9a  vmovaps [rsp+0x50], xmm6
00007d55df7d7fa0  vmovaps [rsp+0x60], xmm7
00007d55df7d7fa6  vmovaps [rsp+0x70], xmm8
00007d55df7d7fac  vmovaps [rsp+0x80], xmm9
00007d55df7d7fb5  vmovaps [rsp+0x90], xmm10
00007d55df7d7fbe  vmovaps [rsp+0xA0], xmm11
00007d55df7d7fc7  vmovaps [rsp+0xB0], xmm12
00007d55df7d7fd0  vmovaps [rsp+0xC0], xmm13
00007d55df7d7fd9  vmovaps [rsp+0xD0], xmm14
00007d55df7d7fe2  vmovaps [rsp+0xE0], xmm15
00007d55df7d7feb  sub rsp, 0x30
00007d55df7d7fef  movaps [rsp], xmm1
00007d55df7d7ff3  movaps [rsp+0x10], xmm14
00007d55df7d7ff9  movaps [rsp+0x20], xmm11
00007d55df7d7fff  lea rdi, [rsp]
00007d55df7d8003  mov esi, 0x00
00007d55df7d8008  mov rax, 0x5BB8433D8530
00007d55df7d8012  call rax
00007d55df7d8014  movaps xmm1, [rsp]
00007d55df7d8018  add rsp, 0x30
00007d55df7d801c  vmovaps xmm0, [rsp]
00007d55df7d8021  vmovaps xmm2, [rsp+0x10]
00007d55df7d8027  vmovaps xmm3, [rsp+0x20]
00007d55df7d802d  vmovaps xmm4, [rsp+0x30]
00007d55df7d8033  vmovaps xmm5, [rsp+0x40]
00007d55df7d8039  vmovaps xmm6, [rsp+0x50]
00007d55df7d803f  vmovaps xmm7, [rsp+0x60]
00007d55df7d8045  vmovaps xmm8, [rsp+0x70]
00007d55df7d804b  vmovaps xmm9, [rsp+0x80]
00007d55df7d8054  vmovaps xmm10, [rsp+0x90]
00007d55df7d805d  vmovaps xmm11, [rsp+0xA0]
00007d55df7d8066  vmovaps xmm12, [rsp+0xB0]
00007d55df7d806f  vmovaps xmm13, [rsp+0xC0]
00007d55df7d8078  vmovaps xmm14, [rsp+0xD0]
00007d55df7d8081  vmovaps xmm15, [rsp+0xE0]
00007d55df7d808a  add rsp, 0xF0
00007d55df7d8091  pop r11
00007d55df7d8093  pop r10
00007d55df7d8095  pop r9
00007d55df7d8097  pop r8
00007d55df7d8099  pop rsi
00007d55df7d809a  pop rdi
00007d55df7d809b  pop rdx
00007d55df7d809c  pop rcx
00007d55df7d809d  pop rax
00007d55df7d809e  add rsp, 0x08
00007d55df7d80a2  jmp 0x00007D55DF7D345F
00007d55df7d80a7  call 0x00007D55DF6E45A0
00007d55df7d80ac  jmp 0x00007D55DF7D346D
00007d55df7d80b1  call 0x00007D55DF609D70
00007d55df7d80b6  jmp 0x00007D55DF7D3477
00007d55df7d80bb  sub rsp, 0x08
00007d55df7d80bf  push rax
00007d55df7d80c0  push rcx
00007d55df7d80c1  push rdx
00007d55df7d80c2  push rdi
00007d55df7d80c3  push rsi
00007d55df7d80c4  push r8
00007d55df7d80c6  push r9
00007d55df7d80c8  push r10
00007d55df7d80ca  push r11
00007d55df7d80cc  sub rsp, 0xF0
00007d55df7d80d3  vmovaps [rsp], xmm0
00007d55df7d80d8  vmovaps [rsp+0x10], xmm1
00007d55df7d80de  vmovaps [rsp+0x20], xmm2
00007d55df7d80e4  vmovaps [rsp+0x30], xmm3
00007d55df7d80ea  vmovaps [rsp+0x40], xmm4
00007d55df7d80f0  vmovaps [rsp+0x50], xmm5
00007d55df7d80f6  vmovaps [rsp+0x60], xmm6
00007d55df7d80fc  vmovaps [rsp+0x70], xmm8
00007d55df7d8102  vmovaps [rsp+0x80], xmm9
00007d55df7d810b  vmovaps [rsp+0x90], xmm10
00007d55df7d8114  vmovaps [rsp+0xA0], xmm11
00007d55df7d811d  vmovaps [rsp+0xB0], xmm12
00007d55df7d8126  vmovaps [rsp+0xC0], xmm13
00007d55df7d812f  vmovaps [rsp+0xD0], xmm14
00007d55df7d8138  vmovaps [rsp+0xE0], xmm15
00007d55df7d8141  sub rsp, 0x30
00007d55df7d8145  movaps [rsp], xmm7
00007d55df7d8149  movaps [rsp+0x10], xmm13
00007d55df7d814f  movaps [rsp+0x20], xmm10
00007d55df7d8155  lea rdi, [rsp]
00007d55df7d8159  mov esi, 0x00
00007d55df7d815e  mov rax, 0x5BB8433D8530
00007d55df7d8168  call rax
00007d55df7d816a  movaps xmm7, [rsp]
00007d55df7d816e  add rsp, 0x30
00007d55df7d8172  vmovaps xmm0, [rsp]
00007d55df7d8177  vmovaps xmm1, [rsp+0x10]
00007d55df7d817d  vmovaps xmm2, [rsp+0x20]
00007d55df7d8183  vmovaps xmm3, [rsp+0x30]
00007d55df7d8189  vmovaps xmm4, [rsp+0x40]
00007d55df7d818f  vmovaps xmm5, [rsp+0x50]
00007d55df7d8195  vmovaps xmm6, [rsp+0x60]
00007d55df7d819b  vmovaps xmm8, [rsp+0x70]
00007d55df7d81a1  vmovaps xmm9, [rsp+0x80]
00007d55df7d81aa  vmovaps xmm10, [rsp+0x90]
00007d55df7d81b3  vmovaps xmm11, [rsp+0xA0]
00007d55df7d81bc  vmovaps xmm12, [rsp+0xB0]
00007d55df7d81c5  vmovaps xmm13, [rsp+0xC0]
00007d55df7d81ce  vmovaps xmm14, [rsp+0xD0]
00007d55df7d81d7  vmovaps xmm15, [rsp+0xE0]
00007d55df7d81e0  add rsp, 0xF0
00007d55df7d81e7  pop r11
00007d55df7d81e9  pop r10
00007d55df7d81eb  pop r9
00007d55df7d81ed  pop r8
00007d55df7d81ef  pop rsi
00007d55df7d81f0  pop rdi
00007d55df7d81f1  pop rdx
00007d55df7d81f2  pop rcx
00007d55df7d81f3  pop rax
00007d55df7d81f4  add rsp, 0x08
00007d55df7d81f8  jmp 0x00007D55DF7D3498
00007d55df7d81fd  sub rsp, 0x08
00007d55df7d8201  push rax
00007d55df7d8202  push rcx
00007d55df7d8203  push rdx
00007d55df7d8204  push rdi
00007d55df7d8205  push rsi
00007d55df7d8206  push r8
00007d55df7d8208  push r9
00007d55df7d820a  push r10
00007d55df7d820c  push r11
00007d55df7d820e  sub rsp, 0xF0
00007d55df7d8215  vmovaps [rsp], xmm0
00007d55df7d821a  vmovaps [rsp+0x10], xmm1
00007d55df7d8220  vmovaps [rsp+0x20], xmm2
00007d55df7d8226  vmovaps [rsp+0x30], xmm3
00007d55df7d822c  vmovaps [rsp+0x40], xmm4
00007d55df7d8232  vmovaps [rsp+0x50], xmm5
00007d55df7d8238  vmovaps [rsp+0x60], xmm6
00007d55df7d823e  vmovaps [rsp+0x70], xmm7
00007d55df7d8244  vmovaps [rsp+0x80], xmm8
00007d55df7d824d  vmovaps [rsp+0x90], xmm9
00007d55df7d8256  vmovaps [rsp+0xA0], xmm11
00007d55df7d825f  vmovaps [rsp+0xB0], xmm12
00007d55df7d8268  vmovaps [rsp+0xC0], xmm13
00007d55df7d8271  vmovaps [rsp+0xD0], xmm14
00007d55df7d827a  vmovaps [rsp+0xE0], xmm15
00007d55df7d8283  sub rsp, 0x30
00007d55df7d8287  movaps [rsp], xmm10
00007d55df7d828c  movaps [rsp+0x10], xmm11
00007d55df7d8292  movaps [rsp+0x20], xmm13
00007d55df7d8298  lea rdi, [rsp]
00007d55df7d829c  mov esi, 0x00
00007d55df7d82a1  mov rax, 0x5BB8433D8530
00007d55df7d82ab  call rax
00007d55df7d82ad  movaps xmm10, [rsp]
00007d55df7d82b2  add rsp, 0x30
00007d55df7d82b6  vmovaps xmm0, [rsp]
00007d55df7d82bb  vmovaps xmm1, [rsp+0x10]
00007d55df7d82c1  vmovaps xmm2, [rsp+0x20]
00007d55df7d82c7  vmovaps xmm3, [rsp+0x30]
00007d55df7d82cd  vmovaps xmm4, [rsp+0x40]
00007d55df7d82d3  vmovaps xmm5, [rsp+0x50]
00007d55df7d82d9  vmovaps xmm6, [rsp+0x60]
00007d55df7d82df  vmovaps xmm7, [rsp+0x70]
00007d55df7d82e5  vmovaps xmm8, [rsp+0x80]
00007d55df7d82ee  vmovaps xmm9, [rsp+0x90]
00007d55df7d82f7  vmovaps xmm11, [rsp+0xA0]
00007d55df7d8300  vmovaps xmm12, [rsp+0xB0]
00007d55df7d8309  vmovaps xmm13, [rsp+0xC0]
00007d55df7d8312  vmovaps xmm14, [rsp+0xD0]
00007d55df7d831b  vmovaps xmm15, [rsp+0xE0]
00007d55df7d8324  add rsp, 0xF0
00007d55df7d832b  pop r11
00007d55df7d832d  pop r10
00007d55df7d832f  pop r9
00007d55df7d8331  pop r8
00007d55df7d8333  pop rsi
00007d55df7d8334  pop rdi
00007d55df7d8335  pop rdx
00007d55df7d8336  pop rcx
00007d55df7d8337  pop rax
00007d55df7d8338  add rsp, 0x08
00007d55df7d833c  jmp 0x00007D55DF7D34C6
00007d55df7d8341  sub rsp, 0x08
00007d55df7d8345  push rax
00007d55df7d8346  push rcx
00007d55df7d8347  push rdx
00007d55df7d8348  push rdi
00007d55df7d8349  push rsi
00007d55df7d834a  push r8
00007d55df7d834c  push r9
00007d55df7d834e  push r10
00007d55df7d8350  push r11
00007d55df7d8352  sub rsp, 0xF0
00007d55df7d8359  vmovaps [rsp], xmm0
00007d55df7d835e  vmovaps [rsp+0x10], xmm1
00007d55df7d8364  vmovaps [rsp+0x20], xmm2
00007d55df7d836a  vmovaps [rsp+0x30], xmm3
00007d55df7d8370  vmovaps [rsp+0x40], xmm4
00007d55df7d8376  vmovaps [rsp+0x50], xmm5
00007d55df7d837c  vmovaps [rsp+0x60], xmm6
00007d55df7d8382  vmovaps [rsp+0x70], xmm7
00007d55df7d8388  vmovaps [rsp+0x80], xmm8
00007d55df7d8391  vmovaps [rsp+0x90], xmm9
00007d55df7d839a  vmovaps [rsp+0xA0], xmm10
00007d55df7d83a3  vmovaps [rsp+0xB0], xmm12
00007d55df7d83ac  vmovaps [rsp+0xC0], xmm13
00007d55df7d83b5  vmovaps [rsp+0xD0], xmm14
00007d55df7d83be  vmovaps [rsp+0xE0], xmm15
00007d55df7d83c7  sub rsp, 0x30
00007d55df7d83cb  movaps [rsp], xmm11
00007d55df7d83d0  movaps [rsp+0x10], xmm14
00007d55df7d83d6  movaps [rsp+0x20], xmm13
00007d55df7d83dc  lea rdi, [rsp]
00007d55df7d83e0  mov esi, 0x00
00007d55df7d83e5  mov rax, 0x5BB8433D8530
00007d55df7d83ef  call rax
00007d55df7d83f1  movaps xmm11, [rsp]
00007d55df7d83f6  add rsp, 0x30
00007d55df7d83fa  vmovaps xmm0, [rsp]
00007d55df7d83ff  vmovaps xmm1, [rsp+0x10]
00007d55df7d8405  vmovaps xmm2, [rsp+0x20]
00007d55df7d840b  vmovaps xmm3, [rsp+0x30]
00007d55df7d8411  vmovaps xmm4, [rsp+0x40]
00007d55df7d8417  vmovaps xmm5, [rsp+0x50]
00007d55df7d841d  vmovaps xmm6, [rsp+0x60]
00007d55df7d8423  vmovaps xmm7, [rsp+0x70]
00007d55df7d8429  vmovaps xmm8, [rsp+0x80]
00007d55df7d8432  vmovaps xmm9, [rsp+0x90]
00007d55df7d843b  vmovaps xmm10, [rsp+0xA0]
00007d55df7d8444  vmovaps xmm12, [rsp+0xB0]
00007d55df7d844d  vmovaps xmm13, [rsp+0xC0]
00007d55df7d8456  vmovaps xmm14, [rsp+0xD0]
00007d55df7d845f  vmovaps xmm15, [rsp+0xE0]
00007d55df7d8468  add rsp, 0xF0
00007d55df7d846f  pop r11
00007d55df7d8471  pop r10
00007d55df7d8473  pop r9
00007d55df7d8475  pop r8
00007d55df7d8477  pop rsi
00007d55df7d8478  pop rdi
00007d55df7d8479  pop rdx
00007d55df7d847a  pop rcx
00007d55df7d847b  pop rax
00007d55df7d847c  add rsp, 0x08
00007d55df7d8480  jmp 0x00007D55DF7D34F4
00007d55df7d8485  sub rsp, 0x08
00007d55df7d8489  push rax
00007d55df7d848a  push rcx
00007d55df7d848b  push rdx
00007d55df7d848c  push rdi
00007d55df7d848d  push rsi
00007d55df7d848e  push r8
00007d55df7d8490  push r9
00007d55df7d8492  push r10
00007d55df7d8494  push r11
00007d55df7d8496  sub rsp, 0xF0
00007d55df7d849d  vmovaps [rsp], xmm0
00007d55df7d84a2  vmovaps [rsp+0x10], xmm1
00007d55df7d84a8  vmovaps [rsp+0x20], xmm2
00007d55df7d84ae  vmovaps [rsp+0x30], xmm3
00007d55df7d84b4  vmovaps [rsp+0x40], xmm4
00007d55df7d84ba  vmovaps [rsp+0x50], xmm5
00007d55df7d84c0  vmovaps [rsp+0x60], xmm6
00007d55df7d84c6  vmovaps [rsp+0x70], xmm7
00007d55df7d84cc  vmovaps [rsp+0x80], xmm8
00007d55df7d84d5  vmovaps [rsp+0x90], xmm9
00007d55df7d84de  vmovaps [rsp+0xA0], xmm10
00007d55df7d84e7  vmovaps [rsp+0xB0], xmm11
00007d55df7d84f0  vmovaps [rsp+0xC0], xmm12
00007d55df7d84f9  vmovaps [rsp+0xD0], xmm13
00007d55df7d8502  vmovaps [rsp+0xE0], xmm15
00007d55df7d850b  sub rsp, 0x30
00007d55df7d850f  movaps [rsp], xmm14
00007d55df7d8514  movaps [rsp+0x10], xmm12
00007d55df7d851a  movaps [rsp+0x20], xmm9
00007d55df7d8520  lea rdi, [rsp]
00007d55df7d8524  mov esi, 0x00
00007d55df7d8529  mov rax, 0x5BB8433D8530
00007d55df7d8533  call rax
00007d55df7d8535  movaps xmm14, [rsp]
00007d55df7d853a  add rsp, 0x30
00007d55df7d853e  vmovaps xmm0, [rsp]
00007d55df7d8543  vmovaps xmm1, [rsp+0x10]
00007d55df7d8549  vmovaps xmm2, [rsp+0x20]
00007d55df7d854f  vmovaps xmm3, [rsp+0x30]
00007d55df7d8555  vmovaps xmm4, [rsp+0x40]
00007d55df7d855b  vmovaps xmm5, [rsp+0x50]
00007d55df7d8561  vmovaps xmm6, [rsp+0x60]
00007d55df7d8567  vmovaps xmm7, [rsp+0x70]
00007d55df7d856d  vmovaps xmm8, [rsp+0x80]
00007d55df7d8576  vmovaps xmm9, [rsp+0x90]
00007d55df7d857f  vmovaps xmm10, [rsp+0xA0]
00007d55df7d8588  vmovaps xmm11, [rsp+0xB0]
00007d55df7d8591  vmovaps xmm12, [rsp+0xC0]
00007d55df7d859a  vmovaps xmm13, [rsp+0xD0]
00007d55df7d85a3  vmovaps xmm15, [rsp+0xE0]
00007d55df7d85ac  add rsp, 0xF0
00007d55df7d85b3  pop r11
00007d55df7d85b5  pop r10
00007d55df7d85b7  pop r9
00007d55df7d85b9  pop r8
00007d55df7d85bb  pop rsi
00007d55df7d85bc  pop rdi
00007d55df7d85bd  pop rdx
00007d55df7d85be  pop rcx
00007d55df7d85bf  pop rax
00007d55df7d85c0  add rsp, 0x08
00007d55df7d85c4  jmp 0x00007D55DF7D350F
00007d55df7d85c9  sub rsp, 0x08
00007d55df7d85cd  push rax
00007d55df7d85ce  push rcx
00007d55df7d85cf  push rdx
00007d55df7d85d0  push rdi
00007d55df7d85d1  push rsi
00007d55df7d85d2  push r8
00007d55df7d85d4  push r9
00007d55df7d85d6  push r10
00007d55df7d85d8  push r11
00007d55df7d85da  sub rsp, 0xF0
00007d55df7d85e1  vmovaps [rsp], xmm0
00007d55df7d85e6  vmovaps [rsp+0x10], xmm1
00007d55df7d85ec  vmovaps [rsp+0x20], xmm2
00007d55df7d85f2  vmovaps [rsp+0x30], xmm3
00007d55df7d85f8  vmovaps [rsp+0x40], xmm4
00007d55df7d85fe  vmovaps [rsp+0x50], xmm5
00007d55df7d8604  vmovaps [rsp+0x60], xmm6
00007d55df7d860a  vmovaps [rsp+0x70], xmm7
00007d55df7d8610  vmovaps [rsp+0x80], xmm8
00007d55df7d8619  vmovaps [rsp+0x90], xmm9
00007d55df7d8622  vmovaps [rsp+0xA0], xmm10
00007d55df7d862b  vmovaps [rsp+0xB0], xmm11
00007d55df7d8634  vmovaps [rsp+0xC0], xmm12
00007d55df7d863d  vmovaps [rsp+0xD0], xmm14
00007d55df7d8646  vmovaps [rsp+0xE0], xmm15
00007d55df7d864f  sub rsp, 0x30
00007d55df7d8653  movaps [rsp], xmm13
00007d55df7d8658  movaps [rsp+0x10], xmm8
00007d55df7d865e  movaps [rsp+0x20], xmm15
00007d55df7d8664  lea rdi, [rsp]
00007d55df7d8668  mov esi, 0x00
00007d55df7d866d  mov rax, 0x5BB8433D8530
00007d55df7d8677  call rax
00007d55df7d8679  movaps xmm13, [rsp]
00007d55df7d867e  add rsp, 0x30
00007d55df7d8682  vmovaps xmm0, [rsp]
00007d55df7d8687  vmovaps xmm1, [rsp+0x10]
00007d55df7d868d  vmovaps xmm2, [rsp+0x20]
00007d55df7d8693  vmovaps xmm3, [rsp+0x30]
00007d55df7d8699  vmovaps xmm4, [rsp+0x40]
00007d55df7d869f  vmovaps xmm5, [rsp+0x50]
00007d55df7d86a5  vmovaps xmm6, [rsp+0x60]
00007d55df7d86ab  vmovaps xmm7, [rsp+0x70]
00007d55df7d86b1  vmovaps xmm8, [rsp+0x80]
00007d55df7d86ba  vmovaps xmm9, [rsp+0x90]
00007d55df7d86c3  vmovaps xmm10, [rsp+0xA0]
00007d55df7d86cc  vmovaps xmm11, [rsp+0xB0]
00007d55df7d86d5  vmovaps xmm12, [rsp+0xC0]
00007d55df7d86de  vmovaps xmm14, [rsp+0xD0]
00007d55df7d86e7  vmovaps xmm15, [rsp+0xE0]
00007d55df7d86f0  add rsp, 0xF0
00007d55df7d86f7  pop r11
00007d55df7d86f9  pop r10
00007d55df7d86fb  pop r9
00007d55df7d86fd  pop r8
00007d55df7d86ff  pop rsi
00007d55df7d8700  pop rdi
00007d55df7d8701  pop rdx
00007d55df7d8702  pop rcx
00007d55df7d8703  pop rax
00007d55df7d8704  add rsp, 0x08
00007d55df7d8708  jmp 0x00007D55DF7D3532
00007d55df7d870d  sub rsp, 0x08
00007d55df7d8711  push rax
00007d55df7d8712  push rcx
00007d55df7d8713  push rdx
00007d55df7d8714  push rdi
00007d55df7d8715  push rsi
00007d55df7d8716  push r8
00007d55df7d8718  push r9
00007d55df7d871a  push r10
00007d55df7d871c  push r11
00007d55df7d871e  sub rsp, 0xF0
00007d55df7d8725  vmovaps [rsp], xmm0
00007d55df7d872a  vmovaps [rsp+0x10], xmm1
00007d55df7d8730  vmovaps [rsp+0x20], xmm2
00007d55df7d8736  vmovaps [rsp+0x30], xmm3
00007d55df7d873c  vmovaps [rsp+0x40], xmm4
00007d55df7d8742  vmovaps [rsp+0x50], xmm5
00007d55df7d8748  vmovaps [rsp+0x60], xmm6
00007d55df7d874e  vmovaps [rsp+0x70], xmm7
00007d55df7d8754  vmovaps [rsp+0x80], xmm8
00007d55df7d875d  vmovaps [rsp+0x90], xmm9
00007d55df7d8766  vmovaps [rsp+0xA0], xmm10
00007d55df7d876f  vmovaps [rsp+0xB0], xmm11
00007d55df7d8778  vmovaps [rsp+0xC0], xmm12
00007d55df7d8781  vmovaps [rsp+0xD0], xmm13
00007d55df7d878a  vmovaps [rsp+0xE0], xmm14
00007d55df7d8793  sub rsp, 0x30
00007d55df7d8797  movaps [rsp], xmm15
00007d55df7d879c  movaps [rsp+0x10], xmm1
00007d55df7d87a1  movaps [rsp+0x20], xmm10
00007d55df7d87a7  lea rdi, [rsp]
00007d55df7d87ab  mov esi, 0x00
00007d55df7d87b0  mov rax, 0x5BB8433D8530
00007d55df7d87ba  call rax
00007d55df7d87bc  movaps xmm15, [rsp]
00007d55df7d87c1  add rsp, 0x30
00007d55df7d87c5  vmovaps xmm0, [rsp]
00007d55df7d87ca  vmovaps xmm1, [rsp+0x10]
00007d55df7d87d0  vmovaps xmm2, [rsp+0x20]
00007d55df7d87d6  vmovaps xmm3, [rsp+0x30]
00007d55df7d87dc  vmovaps xmm4, [rsp+0x40]
00007d55df7d87e2  vmovaps xmm5, [rsp+0x50]
00007d55df7d87e8  vmovaps xmm6, [rsp+0x60]
00007d55df7d87ee  vmovaps xmm7, [rsp+0x70]
00007d55df7d87f4  vmovaps xmm8, [rsp+0x80]
00007d55df7d87fd  vmovaps xmm9, [rsp+0x90]
00007d55df7d8806  vmovaps xmm10, [rsp+0xA0]
00007d55df7d880f  vmovaps xmm11, [rsp+0xB0]
00007d55df7d8818  vmovaps xmm12, [rsp+0xC0]
00007d55df7d8821  vmovaps xmm13, [rsp+0xD0]
00007d55df7d882a  vmovaps xmm14, [rsp+0xE0]
00007d55df7d8833  add rsp, 0xF0
00007d55df7d883a  pop r11
00007d55df7d883c  pop r10
00007d55df7d883e  pop r9
00007d55df7d8840  pop r8
00007d55df7d8842  pop rsi
00007d55df7d8843  pop rdi
00007d55df7d8844  pop rdx
00007d55df7d8845  pop rcx
00007d55df7d8846  pop rax
00007d55df7d8847  add rsp, 0x08
00007d55df7d884b  jmp 0x00007D55DF7D3555
00007d55df7d8850  sub rsp, 0x08
00007d55df7d8854  push rax
00007d55df7d8855  push rcx
00007d55df7d8856  push rdx
00007d55df7d8857  push rdi
00007d55df7d8858  push rsi
00007d55df7d8859  push r8
00007d55df7d885b  push r9
00007d55df7d885d  push r10
00007d55df7d885f  push r11
00007d55df7d8861  sub rsp, 0xF0
00007d55df7d8868  vmovaps [rsp], xmm0
00007d55df7d886d  vmovaps [rsp+0x10], xmm2
00007d55df7d8873  vmovaps [rsp+0x20], xmm3
00007d55df7d8879  vmovaps [rsp+0x30], xmm4
00007d55df7d887f  vmovaps [rsp+0x40], xmm5
00007d55df7d8885  vmovaps [rsp+0x50], xmm6
00007d55df7d888b  vmovaps [rsp+0x60], xmm7
00007d55df7d8891  vmovaps [rsp+0x70], xmm8
00007d55df7d8897  vmovaps [rsp+0x80], xmm9
00007d55df7d88a0  vmovaps [rsp+0x90], xmm10
00007d55df7d88a9  vmovaps [rsp+0xA0], xmm11
00007d55df7d88b2  vmovaps [rsp+0xB0], xmm12
00007d55df7d88bb  vmovaps [rsp+0xC0], xmm13
00007d55df7d88c4  vmovaps [rsp+0xD0], xmm14
00007d55df7d88cd  vmovaps [rsp+0xE0], xmm15
00007d55df7d88d6  sub rsp, 0x30
00007d55df7d88da  movaps [rsp], xmm1
00007d55df7d88de  movaps [rsp+0x10], xmm7
00007d55df7d88e3  movaps [rsp+0x20], xmm11
00007d55df7d88e9  lea rdi, [rsp]
00007d55df7d88ed  mov esi, 0x00
00007d55df7d88f2  mov rax, 0x5BB8433D8530
00007d55df7d88fc  call rax
00007d55df7d88fe  movaps xmm1, [rsp]
00007d55df7d8902  add rsp, 0x30
00007d55df7d8906  vmovaps xmm0, [rsp]
00007d55df7d890b  vmovaps xmm2, [rsp+0x10]
00007d55df7d8911  vmovaps xmm3, [rsp+0x20]
00007d55df7d8917  vmovaps xmm4, [rsp+0x30]
00007d55df7d891d  vmovaps xmm5, [rsp+0x40]
00007d55df7d8923  vmovaps xmm6, [rsp+0x50]
00007d55df7d8929  vmovaps xmm7, [rsp+0x60]
00007d55df7d892f  vmovaps xmm8, [rsp+0x70]
00007d55df7d8935  vmovaps xmm9, [rsp+0x80]
00007d55df7d893e  vmovaps xmm10, [rsp+0x90]
00007d55df7d8947  vmovaps xmm11, [rsp+0xA0]
00007d55df7d8950  vmovaps xmm12, [rsp+0xB0]
00007d55df7d8959  vmovaps xmm13, [rsp+0xC0]
00007d55df7d8962  vmovaps xmm14, [rsp+0xD0]
00007d55df7d896b  vmovaps xmm15, [rsp+0xE0]
00007d55df7d8974  add rsp, 0xF0
00007d55df7d897b  pop r11
00007d55df7d897d  pop r10
00007d55df7d897f  pop r9
00007d55df7d8981  pop r8
00007d55df7d8983  pop rsi
00007d55df7d8984  pop rdi
00007d55df7d8985  pop rdx
00007d55df7d8986  pop rcx
00007d55df7d8987  pop rax
00007d55df7d8988  add rsp, 0x08
00007d55df7d898c  jmp 0x00007D55DF7D3576
00007d55df7d8991  call 0x00007D55DF60D600
00007d55df7d8996  jmp 0x00007D55DF7D3589
00007d55df7d899b  call 0x00007D55DF60C380
00007d55df7d89a0  jmp 0x00007D55DF7D3594
00007d55df7d89a5  call 0x00007D55DF60E880
00007d55df7d89aa  jmp 0x00007D55DF7D359F
00007d55df7d89af  call 0x00007D55DF5FF540
00007d55df7d89b4  jmp 0x00007D55DF7D35AA
00007d55df7d89b9  int3
00007d55df7d89ba  nop [rax+rax*1], ax
00007d55df7d89c0  mov rax, [r15+0x40]
00007d55df7d89c4  mov r14, [r15+0x58]
00007d55df7d89c8  lea r12, [rax+r14*1]
00007d55df7d89cc  movaps xmm1, [r15+0x1D0]
00007d55df7d89d4  vmovaps [rsp+0x10], xmm1
00007d55df7d89da  vmovaps xmm15, [rsp+0x10]
00007d55df7d89e0  por xmm1, xmm15
00007d55df7d89e5  movaps xmm14, [r15+0x1A0]
00007d55df7d89ed  vmovaps [rsp+0x10], xmm14
00007d55df7d89f3  vmovaps xmm13, [rsp+0x10]
00007d55df7d89f9  por xmm14, xmm13
00007d55df7d89fe  lea rax, [r12+0x30]
00007d55df7d8a03  mov r11, [r13+rax*1]
00007d55df7d8a08  lea rax, [r12+0x38]
00007d55df7d8a0d  mov r10, [r13+rax*1]
00007d55df7d8a12  movq xmm13, r11
00007d55df7d8a17  movq xmm12, r10
00007d55df7d8a1c  movq xmm13, xmm13
00007d55df7d8a21  vmovaps [rsp+0x10], xmm13
00007d55df7d8a27  movq xmm13, xmm13
00007d55df7d8a2c  movaps [r15+0x130], xmm13
00007d55df7d8a34  movq xmm12, xmm12
00007d55df7d8a39  vmovaps [rsp+0x20], xmm12
00007d55df7d8a3f  movq xmm12, xmm12
00007d55df7d8a44  movaps [r15+0x280], xmm12
00007d55df7d8a4c  movaps xmm13, [r15+0x270]
00007d55df7d8a54  vmovaps [rsp+0x30], xmm13
00007d55df7d8a5a  vmovaps xmm12, [rsp+0x30]
00007d55df7d8a60  por xmm13, xmm12
00007d55df7d8a65  lea rax, [r12+0x20]
00007d55df7d8a6a  mov r11, [r13+rax*1]
00007d55df7d8a6f  lea rax, [r12+0x28]
00007d55df7d8a74  mov r10, [r13+rax*1]
00007d55df7d8a79  movq xmm12, r11
00007d55df7d8a7e  movq xmm11, r10
00007d55df7d8a83  movq xmm12, xmm12
00007d55df7d8a88  vmovaps [rsp+0x30], xmm12
00007d55df7d8a8e  movq xmm12, xmm12
00007d55df7d8a93  movaps [r15+0x150], xmm12
00007d55df7d8a9b  movq xmm11, xmm11
00007d55df7d8aa0  vmovaps [rsp+0x40], xmm11
00007d55df7d8aa6  movq xmm11, xmm11
00007d55df7d8aab  movaps [r15+0x140], xmm11
00007d55df7d8ab3  lea rax, [r12+0x10]
00007d55df7d8ab8  mov r11, [r13+rax*1]
00007d55df7d8abd  lea rax, [r12+0x18]
00007d55df7d8ac2  mov r10, [r13+rax*1]
00007d55df7d8ac7  movq xmm12, r11
00007d55df7d8acc  movq xmm11, r10
00007d55df7d8ad1  movq xmm12, xmm12
00007d55df7d8ad6  vmovaps [rsp+0x50], xmm12
00007d55df7d8adc  movq xmm12, xmm12
00007d55df7d8ae1  movaps [r15+0x170], xmm12
00007d55df7d8ae9  movq xmm11, xmm11
00007d55df7d8aee  vmovaps [rsp+0x60], xmm11
00007d55df7d8af4  movq xmm11, xmm11
00007d55df7d8af9  movaps [r15+0x160], xmm11
00007d55df7d8b01  mov rax, [r13+r12*1]
00007d55df7d8b06  vmovq xmm12, rax
00007d55df7d8b0b  vpbroadcastq xmm12, xmm12
00007d55df7d8b10  lea rax, [r12+0x08]
00007d55df7d8b15  mov r12, [r13+rax*1]
00007d55df7d8b1a  movq xmm11, r12
00007d55df7d8b1f  movaps [r15+0x230], xmm11
00007d55df7d8b27  mov rax, [r15+0xF8]
00007d55df7d8b2e  lea r12, [rax+0x50]
00007d55df7d8b32  movups xmm11, [r13+r12*1]
00007d55df7d8b38  lea r12, [rax+0x60]
00007d55df7d8b3c  movups xmm10, [r13+r12*1]
00007d55df7d8b42  lea r12, [rax+0x30]
00007d55df7d8b46  movups xmm9, [r13+r12*1]
00007d55df7d8b4c  mov r12, [r15+0x50]
00007d55df7d8b50  lea r11, [r12+r14*1]
00007d55df7d8b54  mov [r15+0x60], r11
00007d55df7d8b58  lea r12, [r14+0x40]
00007d55df7d8b5c  mov [r15+0x58], r12
00007d55df7d8b60  movaps xmm8, xmm12
00007d55df7d8b64  mulpd xmm8, xmm15
00007d55df7d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007d55df7d8b6f  ptest xmm7, xmm7
00007d55df7d8b74  jnz 0x00007D55DF7D9997
00007d55df7d8b7a  movq xmm15, qword ptr [r15+0x230]
00007d55df7d8b83  vmovaps [rsp+0x70], xmm15
00007d55df7d8b89  vpermilpd xmm15, xmm15, 0x00
00007d55df7d8b8f  movaps xmm7, xmm9
00007d55df7d8b93  mulpd xmm7, xmm15
00007d55df7d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007d55df7d8b9d  ptest xmm6, xmm6
00007d55df7d8ba2  jnz 0x00007D55DF7D9ADB
00007d55df7d8ba8  vxorps xmm15, xmm15, xmm15
00007d55df7d8bad  vpbroadcastq xmm15, xmm15
00007d55df7d8bb2  movaps xmm9, xmm12
00007d55df7d8bb6  mulpd xmm9, xmm10
00007d55df7d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007d55df7d8bc1  ptest xmm6, xmm6
00007d55df7d8bc6  jnz 0x00007D55DF7D9C1D
00007d55df7d8bcc  movaps xmm10, xmm12
00007d55df7d8bd0  mulpd xmm10, xmm11
00007d55df7d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d55df7d8bdb  ptest xmm6, xmm6
00007d55df7d8be0  jnz 0x00007D55DF7D9D61
00007d55df7d8be6  movaps xmm11, [r15+0x1F0]
00007d55df7d8bee  movaps xmm6, xmm12
00007d55df7d8bf2  mulpd xmm6, xmm11
00007d55df7d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007d55df7d8bfc  ptest xmm5, xmm5
00007d55df7d8c01  jnz 0x00007D55DF7D9EA5
00007d55df7d8c07  movaps xmm12, [r15+0x2A0]
00007d55df7d8c0f  vmovaps [rsp+0x80], xmm12
00007d55df7d8c18  vmovaps xmm11, [rsp+0x80]
00007d55df7d8c21  por xmm12, xmm11
00007d55df7d8c26  movaps xmm11, [r15+0x250]
00007d55df7d8c2e  vmovaps [rsp+0x80], xmm11
00007d55df7d8c37  vmovaps xmm5, [rsp+0x80]
00007d55df7d8c40  por xmm11, xmm5
00007d55df7d8c45  vmovaps xmm4, [rsp+0x70]
00007d55df7d8c4b  vpermilpd xmm4, xmm4, 0x00
00007d55df7d8c51  movaps xmm3, xmm5
00007d55df7d8c54  mulpd xmm3, xmm4
00007d55df7d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007d55df7d8c5d  ptest xmm2, xmm2
00007d55df7d8c62  jnz 0x00007D55DF7D9FE7
00007d55df7d8c68  mov [rsp+0x80], rax
00007d55df7d8c70  xor eax, eax
00007d55df7d8c72  mov r14d, 0x200
00007d55df7d8c78  cmp r12, r14
00007d55df7d8c7b  cmc
00007d55df7d8c7c  lahf
00007d55df7d8c7d  seto al
00007d55df7d8c80  mov [r15+0x108], eax
00007d55df7d8c87  movaps xmm5, xmm8
00007d55df7d8c8b  addpd xmm5, xmm15
00007d55df7d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007d55df7d8c95  ptest xmm4, xmm4
00007d55df7d8c9a  jnz 0x00007D55DF7DA127
00007d55df7d8ca0  movaps xmm8, [r15+0x1B0]
00007d55df7d8ca8  movaps xmm4, xmm9
00007d55df7d8cac  addpd xmm4, xmm8
00007d55df7d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007d55df7d8cb6  ptest xmm2, xmm2
00007d55df7d8cbb  jnz 0x00007D55DF7DA269
00007d55df7d8cc1  movaps xmm9, xmm10
00007d55df7d8cc5  addpd xmm9, xmm8
00007d55df7d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007d55df7d8cd0  ptest xmm2, xmm2
00007d55df7d8cd5  jnz 0x00007D55DF7DA3AB
00007d55df7d8cdb  movaps xmm10, [r15+0x2F0]
00007d55df7d8ce3  vmovaps [rsp+0x90], xmm10
00007d55df7d8cec  vmovaps xmm8, [rsp+0x90]
00007d55df7d8cf5  por xmm10, xmm8
00007d55df7d8cfa  movaps xmm8, [r15+0x2E0]
00007d55df7d8d02  vmovaps [rsp+0x90], xmm8
00007d55df7d8d0b  vmovaps xmm2, [rsp+0x90]
00007d55df7d8d14  por xmm8, xmm2
00007d55df7d8d19  movaps xmm2, [r15+0x2D0]
00007d55df7d8d21  vmovaps [rsp+0x90], xmm2
00007d55df7d8d2a  vmovaps [rsp+0xA0], xmm1
00007d55df7d8d33  vmovaps xmm1, [rsp+0x90]
00007d55df7d8d3c  por xmm2, xmm1
00007d55df7d8d40  movaps xmm1, [r15+0x200]
00007d55df7d8d48  vmovaps [rsp+0x90], xmm1
00007d55df7d8d51  vmovaps [rsp+0xB0], xmm15
00007d55df7d8d5a  vmovaps xmm15, [rsp+0x90]
00007d55df7d8d63  por xmm1, xmm15
00007d55df7d8d68  movaps xmm15, [r15+0x1C0]
00007d55df7d8d70  vmovaps [rsp+0x90], xmm15
00007d55df7d8d79  vmovaps [rsp+0xC0], xmm1
00007d55df7d8d82  vmovaps xmm1, [rsp+0x90]
00007d55df7d8d8b  por xmm15, xmm1
00007d55df7d8d90  movaps xmm1, [r15+0x190]
00007d55df7d8d98  vmovaps [rsp+0x90], xmm1
00007d55df7d8da1  vmovaps [rsp+0xD0], xmm15
00007d55df7d8daa  vmovaps xmm15, [rsp+0x90]
00007d55df7d8db3  por xmm1, xmm15
00007d55df7d8db8  movaps xmm15, [r15+0x300]
00007d55df7d8dc0  vmovaps [rsp+0x90], xmm15
00007d55df7d8dc9  vmovaps [rsp+0xE0], xmm1
00007d55df7d8dd2  vmovaps xmm1, [rsp+0x90]
00007d55df7d8ddb  por xmm15, xmm1
00007d55df7d8de0  mov rax, [rsp+0x80]
00007d55df7d8de8  lea r14, [rax+0xA0]
00007d55df7d8def  movups xmm1, [r13+r14*1]
00007d55df7d8df5  lea r14, [rax+0xB0]
00007d55df7d8dfc  vmovaps [rsp+0x80], xmm1
00007d55df7d8e05  movups xmm1, [r13+r14*1]
00007d55df7d8e0b  vmovaps [rsp+0x90], xmm1
00007d55df7d8e14  vmovaps [rsp+0xF0], xmm15
00007d55df7d8e1d  vmovaps xmm15, [rsp+0xB0]
00007d55df7d8e26  vmovaps [rsp+0xB0], xmm14
00007d55df7d8e2f  movaps xmm1, xmm6
00007d55df7d8e32  addpd xmm1, xmm15
00007d55df7d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007d55df7d8e3c  ptest xmm14, xmm14
00007d55df7d8e42  jnz 0x00007D55DF7DA503
00007d55df7d8e48  lea r14, [rax+0xF0]
00007d55df7d8e4f  movups xmm15, [r13+r14*1]
00007d55df7d8e55  movaps xmm14, xmm4
00007d55df7d8e59  addpd xmm14, xmm3
00007d55df7d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007d55df7d8e64  ptest xmm6, xmm6
00007d55df7d8e69  jnz 0x00007D55DF7DA64E
00007d55df7d8e6f  movaps xmm6, xmm9
00007d55df7d8e73  addpd xmm6, xmm7
00007d55df7d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007d55df7d8e7c  ptest xmm4, xmm4
00007d55df7d8e81  jnz 0x00007D55DF7DA790
00007d55df7d8e87  vmovaps xmm9, [rsp+0x70]
00007d55df7d8e8d  vpermilpd xmm9, xmm9, 0x00
00007d55df7d8e93  vmovaps xmm4, [rsp+0x90]
00007d55df7d8e9c  movaps xmm7, xmm4
00007d55df7d8e9f  mulpd xmm7, xmm9
00007d55df7d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007d55df7d8ea9  ptest xmm3, xmm3
00007d55df7d8eae  jnz 0x00007D55DF7DA8D1
00007d55df7d8eb4  vmovaps xmm9, [rsp+0x50]
00007d55df7d8eba  vpermilpd xmm9, xmm9, 0x00
00007d55df7d8ec0  movaps xmm4, xmm15
00007d55df7d8ec4  mulpd xmm4, xmm9
00007d55df7d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007d55df7d8ece  ptest xmm3, xmm3
00007d55df7d8ed3  jnz 0x00007D55DF7DAA12
00007d55df7d8ed9  lea r14, [rax+0xE0]
00007d55df7d8ee0  movups xmm15, [r13+r14*1]
00007d55df7d8ee6  vmovaps xmm9, [rsp+0x70]
00007d55df7d8eec  vpermilpd xmm9, xmm9, 0x00
00007d55df7d8ef2  vmovaps [rsp+0x70], xmm1
00007d55df7d8ef8  vmovaps xmm1, [rsp+0x80]
00007d55df7d8f01  vmovaps [rsp+0x80], xmm15
00007d55df7d8f0a  movaps xmm3, xmm1
00007d55df7d8f0d  mulpd xmm3, xmm9
00007d55df7d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007d55df7d8f17  ptest xmm15, xmm15
00007d55df7d8f1d  jnz 0x00007D55DF7DAB5E
00007d55df7d8f23  vmovaps xmm1, [rsp+0xF0]
00007d55df7d8f2c  vmovaps xmm15, [rsp+0xF0]
00007d55df7d8f35  por xmm1, xmm15
00007d55df7d8f3a  movaps [r15+0x300], xmm1
00007d55df7d8f42  vmovaps xmm15, [rsp+0xE0]
00007d55df7d8f4b  vmovaps xmm9, [rsp+0xE0]
00007d55df7d8f54  por xmm15, xmm9
00007d55df7d8f59  movaps [r15+0x190], xmm15
00007d55df7d8f61  vmovaps xmm9, [rsp+0x50]
00007d55df7d8f67  vpermilpd xmm9, xmm9, 0x00
00007d55df7d8f6d  vmovaps [rsp+0x90], xmm1
00007d55df7d8f76  vmovaps [rsp+0xE0], xmm15
00007d55df7d8f7f  vmovaps xmm15, [rsp+0x80]
00007d55df7d8f88  vmovaps [rsp+0x80], xmm14
00007d55df7d8f91  movaps xmm1, xmm15
00007d55df7d8f95  mulpd xmm1, xmm9
00007d55df7d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007d55df7d8f9f  ptest xmm14, xmm14
00007d55df7d8fa5  jnz 0x00007D55DF7DAC9F
00007d55df7d8fab  lea r14, [rax+0x90]
00007d55df7d8fb2  movups xmm15, [r13+r14*1]
00007d55df7d8fb8  vmovaps xmm14, [rsp+0xD0]
00007d55df7d8fc1  vmovaps xmm9, [rsp+0xD0]
00007d55df7d8fca  por xmm14, xmm9
00007d55df7d8fcf  movaps [r15+0x1C0], xmm14
00007d55df7d8fd7  vmovaps xmm9, [rsp+0xC0]
00007d55df7d8fe0  vmovaps [rsp+0xD0], xmm1
00007d55df7d8fe9  vmovaps xmm1, [rsp+0xC0]
00007d55df7d8ff2  por xmm9, xmm1
00007d55df7d8ff7  movaps [r15+0x200], xmm9
00007d55df7d8fff  vmovaps [rsp+0xC0], xmm2
00007d55df7d9008  vmovaps xmm1, [rsp+0xC0]
00007d55df7d9011  por xmm2, xmm1
00007d55df7d9015  movaps [r15+0x2D0], xmm2
00007d55df7d901d  vmovaps [rsp+0xC0], xmm8
00007d55df7d9026  vmovaps xmm1, [rsp+0xC0]
00007d55df7d902f  por xmm8, xmm1
00007d55df7d9034  movaps [r15+0x2E0], xmm8
00007d55df7d903c  vmovaps [rsp+0xC0], xmm15
00007d55df7d9045  movaps xmm1, xmm5
00007d55df7d9048  addpd xmm1, xmm7
00007d55df7d904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007d55df7d9051  ptest xmm15, xmm15
00007d55df7d9057  jnz 0x00007D55DF7DADEB
00007d55df7d905d  vmovaps xmm15, [rsp+0x50]
00007d55df7d9063  vpermilpd xmm15, xmm15, 0x00
00007d55df7d9069  vmovaps xmm5, [rsp+0xC0]
00007d55df7d9072  vmovaps [rsp+0xC0], xmm1
00007d55df7d907b  movaps xmm7, xmm5
00007d55df7d907e  mulpd xmm7, xmm15
00007d55df7d9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007d55df7d9088  ptest xmm1, xmm1
00007d55df7d908d  jnz 0x00007D55DF7DAF2B
00007d55df7d9093  lea r14, [rax+0x80]
00007d55df7d909a  movups xmm1, [r13+r14*1]
00007d55df7d90a0  vmovaps xmm5, [rsp+0x70]
00007d55df7d90a6  vmovaps [rsp+0x70], xmm1
00007d55df7d90ac  movaps xmm15, xmm5
00007d55df7d90b0  addpd xmm15, xmm3
00007d55df7d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d55df7d90bb  ptest xmm1, xmm1
00007d55df7d90c0  jnz 0x00007D55DF7DB076
00007d55df7d90c6  vmovaps xmm5, [rsp+0x80]
00007d55df7d90cf  movaps xmm1, xmm5
00007d55df7d90d2  addpd xmm1, xmm4
00007d55df7d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007d55df7d90db  ptest xmm3, xmm3
00007d55df7d90e0  jnz 0x00007D55DF7DB1B8
00007d55df7d90e6  vmovaps [rsp+0x80], xmm10
00007d55df7d90ef  vmovaps xmm5, [rsp+0x80]
00007d55df7d90f8  por xmm10, xmm5
00007d55df7d90fd  movaps [r15+0x2F0], xmm10
00007d55df7d9105  vmovaps xmm5, [rsp+0x50]
00007d55df7d910b  vpermilpd xmm5, xmm5, 0x00
00007d55df7d9111  vmovaps xmm3, [rsp+0x70]
00007d55df7d9117  vmovaps [rsp+0x50], xmm1
00007d55df7d911d  movaps xmm4, xmm3
00007d55df7d9120  mulpd xmm4, xmm5
00007d55df7d9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007d55df7d9129  ptest xmm1, xmm1
00007d55df7d912e  jnz 0x00007D55DF7DB2F8
00007d55df7d9134  lea r14, [rax+0xD0]
00007d55df7d913b  movups xmm1, [r13+r14*1]
00007d55df7d9141  vmovaps xmm3, [rsp+0xD0]
00007d55df7d914a  vmovaps [rsp+0x70], xmm1
00007d55df7d9150  movaps xmm5, xmm6
00007d55df7d9153  addpd xmm5, xmm3
00007d55df7d9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007d55df7d915c  ptest xmm1, xmm1
00007d55df7d9161  jnz 0x00007D55DF7DB442
00007d55df7d9167  vmovaps xmm1, [rsp+0x60]
00007d55df7d916d  vpermilpd xmm1, xmm1, 0x00
00007d55df7d9173  movaps xmm6, xmm9
00007d55df7d9177  mulpd xmm6, xmm1
00007d55df7d917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007d55df7d9180  ptest xmm3, xmm3
00007d55df7d9185  jnz 0x00007D55DF7DB582
00007d55df7d918b  movaps [r15+0x260], xmm6
00007d55df7d9193  vxorps xmm1, xmm1, xmm1
00007d55df7d9197  vpbroadcastq xmm1, xmm1
00007d55df7d919c  movaps [r15+0x1B0], xmm1
00007d55df7d91a4  vmovaps xmm1, [rsp+0x60]
00007d55df7d91aa  vpermilpd xmm1, xmm1, 0x00
00007d55df7d91b0  vmovaps xmm3, [rsp+0x70]
00007d55df7d91b6  vmovaps [rsp+0x70], xmm15
00007d55df7d91bc  movaps xmm9, xmm3
00007d55df7d91c0  mulpd xmm9, xmm1
00007d55df7d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007d55df7d91cb  ptest xmm15, xmm15
00007d55df7d91d1  jnz 0x00007D55DF7DB6C3
00007d55df7d91d7  lea r14, [rax+0xC0]
00007d55df7d91de  movups xmm1, [r13+r14*1]
00007d55df7d91e4  vmovaps xmm3, [rsp+0xC0]
00007d55df7d91ed  vmovaps [rsp+0x80], xmm1
00007d55df7d91f6  movaps xmm15, xmm3
00007d55df7d91fa  addpd xmm15, xmm7
00007d55df7d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007d55df7d9205  ptest xmm1, xmm1
00007d55df7d920a  jnz 0x00007D55DF7DB80F
00007d55df7d9210  vmovaps [rsp+0xC0], xmm13
00007d55df7d9219  vmovaps xmm1, [rsp+0xC0]
00007d55df7d9222  por xmm13, xmm1
00007d55df7d9227  movaps [r15+0x270], xmm13
00007d55df7d922f  vmovaps xmm1, [rsp+0xB0]
00007d55df7d9238  vmovaps xmm7, [rsp+0xB0]
00007d55df7d9241  por xmm1, xmm7
00007d55df7d9245  movaps [r15+0x1A0], xmm1
00007d55df7d924d  vmovaps xmm1, [rsp+0x60]
00007d55df7d9253  vpermilpd xmm1, xmm1, 0x00
00007d55df7d9259  vmovaps [rsp+0xB0], xmm1
00007d55df7d9262  vmovaps xmm1, [rsp+0x80]
00007d55df7d926b  vmovaps [rsp+0x80], xmm15
00007d55df7d9274  vmovaps xmm15, [rsp+0xB0]
00007d55df7d927d  vmovaps [rsp+0xB0], xmm14
00007d55df7d9286  movaps xmm3, xmm1
00007d55df7d9289  mulpd xmm3, xmm15
00007d55df7d928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007d55df7d9293  ptest xmm14, xmm14
00007d55df7d9299  jnz 0x00007D55DF7DB951
00007d55df7d929f  lea r14, [rax+0x20]
00007d55df7d92a3  movups xmm1, [r13+r14*1]
00007d55df7d92a9  movaps [r15+0x110], xmm1
00007d55df7d92b1  vmovaps xmm14, [rsp+0x70]
00007d55df7d92b7  vmovaps [rsp+0x70], xmm1
00007d55df7d92bd  movaps xmm15, xmm14
00007d55df7d92c1  addpd xmm15, xmm4
00007d55df7d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007d55df7d92cc  ptest xmm1, xmm1
00007d55df7d92d1  jnz 0x00007D55DF7DBA9C
00007d55df7d92d7  vmovaps xmm1, [rsp+0x60]
00007d55df7d92dd  vpermilpd xmm1, xmm1, 0x00
00007d55df7d92e3  movaps xmm14, xmm2
00007d55df7d92e7  mulpd xmm14, xmm1
00007d55df7d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007d55df7d92f2  ptest xmm4, xmm4
00007d55df7d92f7  jnz 0x00007D55DF7DBBDF
00007d55df7d92fd  vmovaps xmm4, [rsp+0x50]
00007d55df7d9303  movaps xmm1, xmm4
00007d55df7d9306  addpd xmm1, xmm9
00007d55df7d930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d55df7d9310  ptest xmm2, xmm2
00007d55df7d9315  jnz 0x00007D55DF7DBD21
00007d55df7d931b  vmovaps xmm9, [rsp+0x30]
00007d55df7d9321  vpermilpd xmm9, xmm9, 0x00
00007d55df7d9327  vmovaps xmm2, [rsp+0x70]
00007d55df7d932d  vmovaps [rsp+0x50], xmm1
00007d55df7d9333  movaps xmm4, xmm2
00007d55df7d9336  mulpd xmm4, xmm9
00007d55df7d933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007d55df7d9340  ptest xmm1, xmm1
00007d55df7d9345  jnz 0x00007D55DF7DBE62
00007d55df7d934b  vmovaps xmm1, [rsp+0x30]
00007d55df7d9351  vpermilpd xmm1, xmm1, 0x00
00007d55df7d9357  vmovaps xmm2, [rsp+0x90]
00007d55df7d9360  vmovaps [rsp+0x60], xmm15
00007d55df7d9366  movaps xmm9, xmm2
00007d55df7d936a  mulpd xmm9, xmm1
00007d55df7d936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007d55df7d9375  ptest xmm15, xmm15
00007d55df7d937b  jnz 0x00007D55DF7DBFA3
00007d55df7d9381  vmovaps xmm15, [rsp+0x80]
00007d55df7d938a  movaps xmm1, xmm15
00007d55df7d938e  addpd xmm1, xmm6
00007d55df7d9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007d55df7d9397  ptest xmm2, xmm2
00007d55df7d939c  jnz 0x00007D55DF7DC0E5
00007d55df7d93a2  movaps xmm15, xmm5
00007d55df7d93a6  addpd xmm15, xmm3
00007d55df7d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007d55df7d93b1  ptest xmm6, xmm6
00007d55df7d93b6  jnz 0x00007D55DF7DC226
00007d55df7d93bc  vmovaps xmm6, [rsp+0x30]
00007d55df7d93c2  vpermilpd xmm6, xmm6, 0x00
00007d55df7d93c8  movaps xmm5, xmm8
00007d55df7d93cc  mulpd xmm5, xmm6
00007d55df7d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007d55df7d93d5  ptest xmm3, xmm3
00007d55df7d93da  jnz 0x00007D55DF7DC368
00007d55df7d93e0  vmovaps xmm8, [rsp+0x30]
00007d55df7d93e6  vpermilpd xmm8, xmm8, 0x00
00007d55df7d93ec  movaps xmm6, xmm10
00007d55df7d93f0  mulpd xmm6, xmm8
00007d55df7d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007d55df7d93fa  ptest xmm3, xmm3
00007d55df7d93ff  jnz 0x00007D55DF7DC4A9
00007d55df7d9405  vmovaps xmm8, [rsp+0x60]
00007d55df7d940b  movaps xmm10, xmm8
00007d55df7d940f  addpd xmm10, xmm14
00007d55df7d9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007d55df7d941a  ptest xmm3, xmm3
00007d55df7d941f  jnz 0x00007D55DF7DC5EB
00007d55df7d9425  vmovaps xmm8, [rsp+0x50]
00007d55df7d942b  movaps xmm14, xmm8
00007d55df7d942f  addpd xmm14, xmm4
00007d55df7d9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007d55df7d943a  ptest xmm3, xmm3
00007d55df7d943f  jnz 0x00007D55DF7DC72F
00007d55df7d9445  vmovaps xmm8, [rsp+0x40]
00007d55df7d944b  vpermilpd xmm8, xmm8, 0x00
00007d55df7d9451  movaps xmm4, xmm13
00007d55df7d9455  mulpd xmm4, xmm8
00007d55df7d945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007d55df7d945f  ptest xmm3, xmm3
00007d55df7d9464  jnz 0x00007D55DF7DC872
00007d55df7d946a  movaps xmm13, xmm15
00007d55df7d946e  addpd xmm13, xmm9
00007d55df7d9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007d55df7d9479  ptest xmm8, xmm8
00007d55df7d947f  jnz 0x00007D55DF7DC9B4
00007d55df7d9485  movaps xmm15, xmm1
00007d55df7d9489  addpd xmm15, xmm5
00007d55df7d948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007d55df7d9494  ptest xmm9, xmm9
00007d55df7d949a  jnz 0x00007D55DF7DCAF8
00007d55df7d94a0  vmovaps [rsp+0x30], xmm11
00007d55df7d94a6  vmovaps xmm1, [rsp+0x30]
00007d55df7d94ac  por xmm11, xmm1
00007d55df7d94b1  movaps [r15+0x250], xmm11
00007d55df7d94b9  vmovaps [rsp+0x30], xmm12
00007d55df7d94bf  vmovaps xmm1, [rsp+0x30]
00007d55df7d94c5  por xmm12, xmm1
00007d55df7d94ca  movaps [r15+0x2A0], xmm12
00007d55df7d94d2  vmovaps xmm1, [rsp+0xA0]
00007d55df7d94db  vmovaps xmm11, [rsp+0xA0]
00007d55df7d94e4  por xmm1, xmm11
00007d55df7d94e9  movaps [r15+0x1D0], xmm1
00007d55df7d94f1  lea r14, [rax+0x40]
00007d55df7d94f5  movups xmm1, [r13+r14*1]
00007d55df7d94fb  movaps [r15+0x2C0], xmm1
00007d55df7d9503  vmovaps xmm11, [rsp+0x40]
00007d55df7d9509  vpermilpd xmm11, xmm11, 0x00
00007d55df7d950f  vmovaps xmm8, [rsp+0xE0]
00007d55df7d9518  movaps xmm9, xmm8
00007d55df7d951c  mulpd xmm9, xmm11
00007d55df7d9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007d55df7d9527  ptest xmm5, xmm5
00007d55df7d952c  jnz 0x00007D55DF7DCC44
00007d55df7d9532  movaps xmm11, xmm10
00007d55df7d9536  addpd xmm11, xmm6
00007d55df7d953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007d55df7d9541  ptest xmm8, xmm8
00007d55df7d9547  jnz 0x00007D55DF7DCD88
00007d55df7d954d  movaps xmm10, xmm14
00007d55df7d9551  addpd xmm10, xmm4
00007d55df7d9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007d55df7d955c  ptest xmm8, xmm8
00007d55df7d9562  jnz 0x00007D55DF7DCECB
00007d55df7d9568  vmovaps xmm14, [rsp+0x40]
00007d55df7d956e  vpermilpd xmm14, xmm14, 0x00
00007d55df7d9574  movaps xmm8, xmm1
00007d55df7d9578  mulpd xmm8, xmm14
00007d55df7d957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007d55df7d9583  ptest xmm6, xmm6
00007d55df7d9588  jnz 0x00007D55DF7DD00E
00007d55df7d958e  movaps xmm1, [r15+0x2B0]
00007d55df7d9596  vmovaps xmm14, [rsp+0x40]
00007d55df7d959c  vpermilpd xmm14, xmm14, 0x00
00007d55df7d95a2  movaps xmm6, xmm1
00007d55df7d95a5  mulpd xmm6, xmm14
00007d55df7d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007d55df7d95af  ptest xmm5, xmm5
00007d55df7d95b4  jnz 0x00007D55DF7DD151
00007d55df7d95ba  vmovaps xmm1, [rsp+0x10]
00007d55df7d95c0  vpermilpd xmm1, xmm1, 0x00
00007d55df7d95c6  movaps xmm14, xmm12
00007d55df7d95ca  mulpd xmm14, xmm1
00007d55df7d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007d55df7d95d5  ptest xmm5, xmm5
00007d55df7d95da  jnz 0x00007D55DF7DD292
00007d55df7d95e0  movaps xmm1, xmm13
00007d55df7d95e4  addpd xmm1, xmm9
00007d55df7d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007d55df7d95ee  ptest xmm12, xmm12
00007d55df7d95f4  jnz 0x00007D55DF7DD3D5
00007d55df7d95fa  vmovaps xmm13, [rsp+0x10]
00007d55df7d9600  vpermilpd xmm13, xmm13, 0x00
00007d55df7d9606  movaps xmm12, xmm7
00007d55df7d960a  mulpd xmm12, xmm13
00007d55df7d960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007d55df7d9615  ptest xmm9, xmm9
00007d55df7d961b  jnz 0x00007D55DF7DD517
00007d55df7d9621  movaps xmm13, xmm15
00007d55df7d9625  addpd xmm13, xmm8
00007d55df7d962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007d55df7d9630  ptest xmm9, xmm9
00007d55df7d9636  jnz 0x00007D55DF7DD65A
00007d55df7d963c  movaps xmm15, [r15+0x290]
00007d55df7d9644  vmovaps xmm9, [rsp+0x10]
00007d55df7d964a  vpermilpd xmm9, xmm9, 0x00
00007d55df7d9650  movaps xmm8, xmm15
00007d55df7d9654  mulpd xmm8, xmm9
00007d55df7d9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007d55df7d965f  ptest xmm7, xmm7
00007d55df7d9664  jnz 0x00007D55DF7DD79E
00007d55df7d966a  movaps xmm15, xmm11
00007d55df7d966e  addpd xmm15, xmm6
00007d55df7d9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007d55df7d9679  ptest xmm9, xmm9
00007d55df7d967f  jnz 0x00007D55DF7DD8E2
00007d55df7d9685  movaps xmm11, [r15+0x1E0]
00007d55df7d968d  vmovaps xmm9, [rsp+0x10]
00007d55df7d9693  vpermilpd xmm9, xmm9, 0x00
00007d55df7d9699  movaps xmm7, xmm11
00007d55df7d969d  mulpd xmm7, xmm9
00007d55df7d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007d55df7d96a7  ptest xmm6, xmm6
00007d55df7d96ac  jnz 0x00007D55DF7DDA25
00007d55df7d96b2  movaps xmm11, xmm10
00007d55df7d96b6  addpd xmm11, xmm14
00007d55df7d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007d55df7d96c1  ptest xmm9, xmm9
00007d55df7d96c7  jnz 0x00007D55DF7DDB67
00007d55df7d96cd  lea r14, [rax+0x70]
00007d55df7d96d1  movups xmm14, [r13+r14*1]
00007d55df7d96d7  movaps [r15+0x240], xmm14
00007d55df7d96df  movaps xmm10, xmm1
00007d55df7d96e3  addpd xmm10, xmm12
00007d55df7d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007d55df7d96ee  ptest xmm9, xmm9
00007d55df7d96f4  jnz 0x00007D55DF7DDCB5
00007d55df7d96fa  movaps [r15+0x170], xmm10
00007d55df7d9702  vmovaps xmm1, [rsp+0x20]
00007d55df7d9708  vpermilpd xmm1, xmm1, 0x00
00007d55df7d970e  movaps xmm12, xmm14
00007d55df7d9712  mulpd xmm12, xmm1
00007d55df7d9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007d55df7d971d  ptest xmm9, xmm9
00007d55df7d9723  jnz 0x00007D55DF7DDDF8
00007d55df7d9729  vmovaps xmm1, [rsp+0x20]
00007d55df7d972f  vpermilpd xmm1, xmm1, 0x00
00007d55df7d9735  vmovaps xmm9, [rsp+0xB0]
00007d55df7d973e  movaps xmm14, xmm9
00007d55df7d9742  mulpd xmm14, xmm1
00007d55df7d9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007d55df7d974d  ptest xmm6, xmm6
00007d55df7d9752  jnz 0x00007D55DF7DDF3B
00007d55df7d9758  movaps [r15+0x180], xmm14
00007d55df7d9760  movaps xmm1, xmm13
00007d55df7d9764  addpd xmm1, xmm8
00007d55df7d9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007d55df7d976e  ptest xmm9, xmm9
00007d55df7d9774  jnz 0x00007D55DF7DE07E
00007d55df7d977a  movaps [r15+0x210], xmm1
00007d55df7d9782  movups xmm13, [r13+rax*1]
00007d55df7d9788  lea r14, [rax+0x10]
00007d55df7d978c  movups xmm9, [r13+r14*1]
00007d55df7d9792  movaps [r15+0x230], xmm9
00007d55df7d979a  movaps xmm8, xmm15
00007d55df7d979e  addpd xmm8, xmm7
00007d55df7d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007d55df7d97a9  ptest xmm6, xmm6
00007d55df7d97ae  jnz 0x00007D55DF7DE1D4
00007d55df7d97b4  movaps [r15+0x130], xmm8
00007d55df7d97bc  vmovaps xmm15, [rsp+0x20]
00007d55df7d97c2  vpermilpd xmm15, xmm15, 0x00
00007d55df7d97c8  movaps xmm7, xmm9
00007d55df7d97cc  mulpd xmm7, xmm15
00007d55df7d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007d55df7d97d6  ptest xmm6, xmm6
00007d55df7d97db  jnz 0x00007D55DF7DE317
00007d55df7d97e1  movaps [r15+0x220], xmm7
00007d55df7d97e9  vmovaps xmm15, [rsp+0x20]
00007d55df7d97ef  vpermilpd xmm15, xmm15, 0x00
00007d55df7d97f5  movaps xmm9, xmm13
00007d55df7d97f9  mulpd xmm9, xmm15
00007d55df7d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007d55df7d9804  ptest xmm6, xmm6
00007d55df7d9809  jnz 0x00007D55DF7DE459
00007d55df7d980f  movaps xmm15, xmm11
00007d55df7d9813  addpd xmm15, xmm12
00007d55df7d9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007d55df7d981e  ptest xmm13, xmm13
00007d55df7d9824  jnz 0x00007D55DF7DE59D
00007d55df7d982a  movaps [r15+0x140], xmm15
00007d55df7d9832  movaps xmm13, xmm10
00007d55df7d9836  addpd xmm13, xmm14
00007d55df7d983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007d55df7d9841  ptest xmm12, xmm12
00007d55df7d9847  jnz 0x00007D55DF7DE6E1
00007d55df7d984d  movaps [r15+0x150], xmm13
00007d55df7d9855  movaps xmm14, xmm1
00007d55df7d9859  addpd xmm14, xmm7
00007d55df7d985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007d55df7d9864  ptest xmm12, xmm12
00007d55df7d986a  jnz 0x00007D55DF7DE825
00007d55df7d9870  movaps [r15+0x160], xmm14
00007d55df7d9878  movaps xmm1, xmm8
00007d55df7d987c  addpd xmm1, xmm9
00007d55df7d9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007d55df7d9886  ptest xmm12, xmm12
00007d55df7d988c  jnz 0x00007D55DF7DE967
00007d55df7d9892  movaps [r15+0x120], xmm1
00007d55df7d989a  movups [r13+r11*1], xmm15
00007d55df7d98a0  lea rax, [r11+0x10]
00007d55df7d98a4  movups [r13+rax*1], xmm13
00007d55df7d98aa  lea rax, [r11+0x20]
00007d55df7d98ae  movups [r13+rax*1], xmm14
00007d55df7d98b4  lea rax, [r11+0x30]
00007d55df7d98b8  movups [r13+rax*1], xmm1
00007d55df7d98be  mov eax, [r15+0x108]
00007d55df7d98c5  sahf
00007d55df7d98c6  jnz 0x00007D55DF7D98F8
00007d55df7d98c8  cmp dword ptr [r15+0x318], 0x00
00007d55df7d98d0  jz 0x00007D55DF7DEAE0
00007d55df7d98d6  nop [rax+rax*1], ax
00007d55df7d98df  nop [rax+rax*1], eax
00007d55df7d98e7  mov eax, 0x4106D0
00007d55df7d98ec  mov [r15+0x100], rax
00007d55df7d98f3  jmp 0x00007D55DF5FE110
00007d55df7d98f8  cmp dword ptr [r15+0x318], 0x00
00007d55df7d9900  jz 0x00007D55DF7D89C0
00007d55df7d9906  nop [rax+rax*1], ax
00007d55df7d990f  nop [rax+rax*1], eax
00007d55df7d9917  mov eax, 0x410504
00007d55df7d991c  mov [r15+0x100], rax
00007d55df7d9923  jmp 0x00007D55DF5FE110
00007d55df7d9928  int3
00007d55df7d9929  call 0x00007D55DF60A4B0
00007d55df7d992e  jmp 0x00007D55DF7D8A08
00007d55df7d9933  call 0x00007D55DF609240
00007d55df7d9938  jmp 0x00007D55DF7D8A12
00007d55df7d993d  call 0x00007D55DF60A4B0
00007d55df7d9942  jmp 0x00007D55DF7D8A6F
00007d55df7d9947  call 0x00007D55DF609240
00007d55df7d994c  jmp 0x00007D55DF7D8A79
00007d55df7d9951  call 0x00007D55DF60A4B0
00007d55df7d9956  jmp 0x00007D55DF7D8ABD
00007d55df7d995b  call 0x00007D55DF609240
00007d55df7d9960  jmp 0x00007D55DF7D8AC7
00007d55df7d9965  call 0x00007D55DF6B47C0
00007d55df7d996a  jmp 0x00007D55DF7D8B06
00007d55df7d996f  call 0x00007D55DF60B720
00007d55df7d9974  jmp 0x00007D55DF7D8B1A
00007d55df7d9979  call 0x00007D55DF6BFC30
00007d55df7d997e  jmp 0x00007D55DF7D8B38
00007d55df7d9983  call 0x00007D55DF6BE9C0
00007d55df7d9988  jmp 0x00007D55DF7D8B42
00007d55df7d998d  call 0x00007D55DF6BD750
00007d55df7d9992  jmp 0x00007D55DF7D8B4C
00007d55df7d9997  sub rsp, 0x08
00007d55df7d999b  push rax
00007d55df7d999c  push rcx
00007d55df7d999d  push rdx
00007d55df7d999e  push rdi
00007d55df7d999f  push rsi
00007d55df7d99a0  push r8
00007d55df7d99a2  push r9
00007d55df7d99a4  push r10
00007d55df7d99a6  push r11
00007d55df7d99a8  sub rsp, 0xF0
00007d55df7d99af  vmovaps [rsp], xmm0
00007d55df7d99b4  vmovaps [rsp+0x10], xmm1
00007d55df7d99ba  vmovaps [rsp+0x20], xmm2
00007d55df7d99c0  vmovaps [rsp+0x30], xmm3
00007d55df7d99c6  vmovaps [rsp+0x40], xmm4
00007d55df7d99cc  vmovaps [rsp+0x50], xmm5
00007d55df7d99d2  vmovaps [rsp+0x60], xmm6
00007d55df7d99d8  vmovaps [rsp+0x70], xmm7
00007d55df7d99de  vmovaps [rsp+0x80], xmm9
00007d55df7d99e7  vmovaps [rsp+0x90], xmm10
00007d55df7d99f0  vmovaps [rsp+0xA0], xmm11
00007d55df7d99f9  vmovaps [rsp+0xB0], xmm12
00007d55df7d9a02  vmovaps [rsp+0xC0], xmm13
00007d55df7d9a0b  vmovaps [rsp+0xD0], xmm14
00007d55df7d9a14  vmovaps [rsp+0xE0], xmm15
00007d55df7d9a1d  sub rsp, 0x30
00007d55df7d9a21  movaps [rsp], xmm8
00007d55df7d9a26  movaps [rsp+0x10], xmm12
00007d55df7d9a2c  movaps [rsp+0x20], xmm15
00007d55df7d9a32  lea rdi, [rsp]
00007d55df7d9a36  mov esi, 0x00
00007d55df7d9a3b  mov rax, 0x5BB8433D8530
00007d55df7d9a45  call rax
00007d55df7d9a47  movaps xmm8, [rsp]
00007d55df7d9a4c  add rsp, 0x30
00007d55df7d9a50  vmovaps xmm0, [rsp]
00007d55df7d9a55  vmovaps xmm1, [rsp+0x10]
00007d55df7d9a5b  vmovaps xmm2, [rsp+0x20]
00007d55df7d9a61  vmovaps xmm3, [rsp+0x30]
00007d55df7d9a67  vmovaps xmm4, [rsp+0x40]
00007d55df7d9a6d  vmovaps xmm5, [rsp+0x50]
00007d55df7d9a73  vmovaps xmm6, [rsp+0x60]
00007d55df7d9a79  vmovaps xmm7, [rsp+0x70]
00007d55df7d9a7f  vmovaps xmm9, [rsp+0x80]
00007d55df7d9a88  vmovaps xmm10, [rsp+0x90]
00007d55df7d9a91  vmovaps xmm11, [rsp+0xA0]
00007d55df7d9a9a  vmovaps xmm12, [rsp+0xB0]
00007d55df7d9aa3  vmovaps xmm13, [rsp+0xC0]
00007d55df7d9aac  vmovaps xmm14, [rsp+0xD0]
00007d55df7d9ab5  vmovaps xmm15, [rsp+0xE0]
00007d55df7d9abe  add rsp, 0xF0
00007d55df7d9ac5  pop r11
00007d55df7d9ac7  pop r10
00007d55df7d9ac9  pop r9
00007d55df7d9acb  pop r8
00007d55df7d9acd  pop rsi
00007d55df7d9ace  pop rdi
00007d55df7d9acf  pop rdx
00007d55df7d9ad0  pop rcx
00007d55df7d9ad1  pop rax
00007d55df7d9ad2  add rsp, 0x08
00007d55df7d9ad6  jmp 0x00007D55DF7D8B7A
00007d55df7d9adb  sub rsp, 0x08
00007d55df7d9adf  push rax
00007d55df7d9ae0  push rcx
00007d55df7d9ae1  push rdx
00007d55df7d9ae2  push rdi
00007d55df7d9ae3  push rsi
00007d55df7d9ae4  push r8
00007d55df7d9ae6  push r9
00007d55df7d9ae8  push r10
00007d55df7d9aea  push r11
00007d55df7d9aec  sub rsp, 0xF0
00007d55df7d9af3  vmovaps [rsp], xmm0
00007d55df7d9af8  vmovaps [rsp+0x10], xmm1
00007d55df7d9afe  vmovaps [rsp+0x20], xmm2
00007d55df7d9b04  vmovaps [rsp+0x30], xmm3
00007d55df7d9b0a  vmovaps [rsp+0x40], xmm4
00007d55df7d9b10  vmovaps [rsp+0x50], xmm5
00007d55df7d9b16  vmovaps [rsp+0x60], xmm6
00007d55df7d9b1c  vmovaps [rsp+0x70], xmm8
00007d55df7d9b22  vmovaps [rsp+0x80], xmm9
00007d55df7d9b2b  vmovaps [rsp+0x90], xmm10
00007d55df7d9b34  vmovaps [rsp+0xA0], xmm11
00007d55df7d9b3d  vmovaps [rsp+0xB0], xmm12
00007d55df7d9b46  vmovaps [rsp+0xC0], xmm13
00007d55df7d9b4f  vmovaps [rsp+0xD0], xmm14
00007d55df7d9b58  vmovaps [rsp+0xE0], xmm15
00007d55df7d9b61  sub rsp, 0x30
00007d55df7d9b65  movaps [rsp], xmm7
00007d55df7d9b69  movaps [rsp+0x10], xmm9
00007d55df7d9b6f  movaps [rsp+0x20], xmm15
00007d55df7d9b75  lea rdi, [rsp]
00007d55df7d9b79  mov esi, 0x00
00007d55df7d9b7e  mov rax, 0x5BB8433D8530
00007d55df7d9b88  call rax
00007d55df7d9b8a  movaps xmm7, [rsp]
00007d55df7d9b8e  add rsp, 0x30
00007d55df7d9b92  vmovaps xmm0, [rsp]
00007d55df7d9b97  vmovaps xmm1, [rsp+0x10]
00007d55df7d9b9d  vmovaps xmm2, [rsp+0x20]
00007d55df7d9ba3  vmovaps xmm3, [rsp+0x30]
00007d55df7d9ba9  vmovaps xmm4, [rsp+0x40]
00007d55df7d9baf  vmovaps xmm5, [rsp+0x50]
00007d55df7d9bb5  vmovaps xmm6, [rsp+0x60]
00007d55df7d9bbb  vmovaps xmm8, [rsp+0x70]
00007d55df7d9bc1  vmovaps xmm9, [rsp+0x80]
00007d55df7d9bca  vmovaps xmm10, [rsp+0x90]
00007d55df7d9bd3  vmovaps xmm11, [rsp+0xA0]
00007d55df7d9bdc  vmovaps xmm12, [rsp+0xB0]
00007d55df7d9be5  vmovaps xmm13, [rsp+0xC0]
00007d55df7d9bee  vmovaps xmm14, [rsp+0xD0]
00007d55df7d9bf7  vmovaps xmm15, [rsp+0xE0]
00007d55df7d9c00  add rsp, 0xF0
00007d55df7d9c07  pop r11
00007d55df7d9c09  pop r10
00007d55df7d9c0b  pop r9
00007d55df7d9c0d  pop r8
00007d55df7d9c0f  pop rsi
00007d55df7d9c10  pop rdi
00007d55df7d9c11  pop rdx
00007d55df7d9c12  pop rcx
00007d55df7d9c13  pop rax
00007d55df7d9c14  add rsp, 0x08
00007d55df7d9c18  jmp 0x00007D55DF7D8BA8
00007d55df7d9c1d  sub rsp, 0x08
00007d55df7d9c21  push rax
00007d55df7d9c22  push rcx
00007d55df7d9c23  push rdx
00007d55df7d9c24  push rdi
00007d55df7d9c25  push rsi
00007d55df7d9c26  push r8
00007d55df7d9c28  push r9
00007d55df7d9c2a  push r10
00007d55df7d9c2c  push r11
00007d55df7d9c2e  sub rsp, 0xF0
00007d55df7d9c35  vmovaps [rsp], xmm0
00007d55df7d9c3a  vmovaps [rsp+0x10], xmm1
00007d55df7d9c40  vmovaps [rsp+0x20], xmm2
00007d55df7d9c46  vmovaps [rsp+0x30], xmm3
00007d55df7d9c4c  vmovaps [rsp+0x40], xmm4
00007d55df7d9c52  vmovaps [rsp+0x50], xmm5
00007d55df7d9c58  vmovaps [rsp+0x60], xmm6
00007d55df7d9c5e  vmovaps [rsp+0x70], xmm7
00007d55df7d9c64  vmovaps [rsp+0x80], xmm8
00007d55df7d9c6d  vmovaps [rsp+0x90], xmm10
00007d55df7d9c76  vmovaps [rsp+0xA0], xmm11
00007d55df7d9c7f  vmovaps [rsp+0xB0], xmm12
00007d55df7d9c88  vmovaps [rsp+0xC0], xmm13
00007d55df7d9c91  vmovaps [rsp+0xD0], xmm14
00007d55df7d9c9a  vmovaps [rsp+0xE0], xmm15
00007d55df7d9ca3  sub rsp, 0x30
00007d55df7d9ca7  movaps [rsp], xmm9
00007d55df7d9cac  movaps [rsp+0x10], xmm12
00007d55df7d9cb2  movaps [rsp+0x20], xmm10
00007d55df7d9cb8  lea rdi, [rsp]
00007d55df7d9cbc  mov esi, 0x00
00007d55df7d9cc1  mov rax, 0x5BB8433D8530
00007d55df7d9ccb  call rax
00007d55df7d9ccd  movaps xmm9, [rsp]
00007d55df7d9cd2  add rsp, 0x30
00007d55df7d9cd6  vmovaps xmm0, [rsp]
00007d55df7d9cdb  vmovaps xmm1, [rsp+0x10]
00007d55df7d9ce1  vmovaps xmm2, [rsp+0x20]
00007d55df7d9ce7  vmovaps xmm3, [rsp+0x30]
00007d55df7d9ced  vmovaps xmm4, [rsp+0x40]
00007d55df7d9cf3  vmovaps xmm5, [rsp+0x50]
00007d55df7d9cf9  vmovaps xmm6, [rsp+0x60]
00007d55df7d9cff  vmovaps xmm7, [rsp+0x70]
00007d55df7d9d05  vmovaps xmm8, [rsp+0x80]
00007d55df7d9d0e  vmovaps xmm10, [rsp+0x90]
00007d55df7d9d17  vmovaps xmm11, [rsp+0xA0]
00007d55df7d9d20  vmovaps xmm12, [rsp+0xB0]
00007d55df7d9d29  vmovaps xmm13, [rsp+0xC0]
00007d55df7d9d32  vmovaps xmm14, [rsp+0xD0]
00007d55df7d9d3b  vmovaps xmm15, [rsp+0xE0]
00007d55df7d9d44  add rsp, 0xF0
00007d55df7d9d4b  pop r11
00007d55df7d9d4d  pop r10
00007d55df7d9d4f  pop r9
00007d55df7d9d51  pop r8
00007d55df7d9d53  pop rsi
00007d55df7d9d54  pop rdi
00007d55df7d9d55  pop rdx
00007d55df7d9d56  pop rcx
00007d55df7d9d57  pop rax
00007d55df7d9d58  add rsp, 0x08
00007d55df7d9d5c  jmp 0x00007D55DF7D8BCC
00007d55df7d9d61  sub rsp, 0x08
00007d55df7d9d65  push rax
00007d55df7d9d66  push rcx
00007d55df7d9d67  push rdx
00007d55df7d9d68  push rdi
00007d55df7d9d69  push rsi
00007d55df7d9d6a  push r8
00007d55df7d9d6c  push r9
00007d55df7d9d6e  push r10
00007d55df7d9d70  push r11
00007d55df7d9d72  sub rsp, 0xF0
00007d55df7d9d79  vmovaps [rsp], xmm0
00007d55df7d9d7e  vmovaps [rsp+0x10], xmm1
00007d55df7d9d84  vmovaps [rsp+0x20], xmm2
00007d55df7d9d8a  vmovaps [rsp+0x30], xmm3
00007d55df7d9d90  vmovaps [rsp+0x40], xmm4
00007d55df7d9d96  vmovaps [rsp+0x50], xmm5
00007d55df7d9d9c  vmovaps [rsp+0x60], xmm6
00007d55df7d9da2  vmovaps [rsp+0x70], xmm7
00007d55df7d9da8  vmovaps [rsp+0x80], xmm8
00007d55df7d9db1  vmovaps [rsp+0x90], xmm9
00007d55df7d9dba  vmovaps [rsp+0xA0], xmm11
00007d55df7d9dc3  vmovaps [rsp+0xB0], xmm12
00007d55df7d9dcc  vmovaps [rsp+0xC0], xmm13
00007d55df7d9dd5  vmovaps [rsp+0xD0], xmm14
00007d55df7d9dde  vmovaps [rsp+0xE0], xmm15
00007d55df7d9de7  sub rsp, 0x30
00007d55df7d9deb  movaps [rsp], xmm10
00007d55df7d9df0  movaps [rsp+0x10], xmm12
00007d55df7d9df6  movaps [rsp+0x20], xmm11
00007d55df7d9dfc  lea rdi, [rsp]
00007d55df7d9e00  mov esi, 0x00
00007d55df7d9e05  mov rax, 0x5BB8433D8530
00007d55df7d9e0f  call rax
00007d55df7d9e11  movaps xmm10, [rsp]
00007d55df7d9e16  add rsp, 0x30
00007d55df7d9e1a  vmovaps xmm0, [rsp]
00007d55df7d9e1f  vmovaps xmm1, [rsp+0x10]
00007d55df7d9e25  vmovaps xmm2, [rsp+0x20]
00007d55df7d9e2b  vmovaps xmm3, [rsp+0x30]
00007d55df7d9e31  vmovaps xmm4, [rsp+0x40]
00007d55df7d9e37  vmovaps xmm5, [rsp+0x50]
00007d55df7d9e3d  vmovaps xmm6, [rsp+0x60]
00007d55df7d9e43  vmovaps xmm7, [rsp+0x70]
00007d55df7d9e49  vmovaps xmm8, [rsp+0x80]
00007d55df7d9e52  vmovaps xmm9, [rsp+0x90]
00007d55df7d9e5b  vmovaps xmm11, [rsp+0xA0]
00007d55df7d9e64  vmovaps xmm12, [rsp+0xB0]
00007d55df7d9e6d  vmovaps xmm13, [rsp+0xC0]
00007d55df7d9e76  vmovaps xmm14, [rsp+0xD0]
00007d55df7d9e7f  vmovaps xmm15, [rsp+0xE0]
00007d55df7d9e88  add rsp, 0xF0
00007d55df7d9e8f  pop r11
00007d55df7d9e91  pop r10
00007d55df7d9e93  pop r9
00007d55df7d9e95  pop r8
00007d55df7d9e97  pop rsi
00007d55df7d9e98  pop rdi
00007d55df7d9e99  pop rdx
00007d55df7d9e9a  pop rcx
00007d55df7d9e9b  pop rax
00007d55df7d9e9c  add rsp, 0x08
00007d55df7d9ea0  jmp 0x00007D55DF7D8BE6
00007d55df7d9ea5  sub rsp, 0x08
00007d55df7d9ea9  push rax
00007d55df7d9eaa  push rcx
00007d55df7d9eab  push rdx
00007d55df7d9eac  push rdi
00007d55df7d9ead  push rsi
00007d55df7d9eae  push r8
00007d55df7d9eb0  push r9
00007d55df7d9eb2  push r10
00007d55df7d9eb4  push r11
00007d55df7d9eb6  sub rsp, 0xF0
00007d55df7d9ebd  vmovaps [rsp], xmm0
00007d55df7d9ec2  vmovaps [rsp+0x10], xmm1
00007d55df7d9ec8  vmovaps [rsp+0x20], xmm2
00007d55df7d9ece  vmovaps [rsp+0x30], xmm3
00007d55df7d9ed4  vmovaps [rsp+0x40], xmm4
00007d55df7d9eda  vmovaps [rsp+0x50], xmm5
00007d55df7d9ee0  vmovaps [rsp+0x60], xmm7
00007d55df7d9ee6  vmovaps [rsp+0x70], xmm8
00007d55df7d9eec  vmovaps [rsp+0x80], xmm9
00007d55df7d9ef5  vmovaps [rsp+0x90], xmm10
00007d55df7d9efe  vmovaps [rsp+0xA0], xmm11
00007d55df7d9f07  vmovaps [rsp+0xB0], xmm12
00007d55df7d9f10  vmovaps [rsp+0xC0], xmm13
00007d55df7d9f19  vmovaps [rsp+0xD0], xmm14
00007d55df7d9f22  vmovaps [rsp+0xE0], xmm15
00007d55df7d9f2b  sub rsp, 0x30
00007d55df7d9f2f  movaps [rsp], xmm6
00007d55df7d9f33  movaps [rsp+0x10], xmm12
00007d55df7d9f39  movaps [rsp+0x20], xmm11
00007d55df7d9f3f  lea rdi, [rsp]
00007d55df7d9f43  mov esi, 0x00
00007d55df7d9f48  mov rax, 0x5BB8433D8530
00007d55df7d9f52  call rax
00007d55df7d9f54  movaps xmm6, [rsp]
00007d55df7d9f58  add rsp, 0x30
00007d55df7d9f5c  vmovaps xmm0, [rsp]
00007d55df7d9f61  vmovaps xmm1, [rsp+0x10]
00007d55df7d9f67  vmovaps xmm2, [rsp+0x20]
00007d55df7d9f6d  vmovaps xmm3, [rsp+0x30]
00007d55df7d9f73  vmovaps xmm4, [rsp+0x40]
00007d55df7d9f79  vmovaps xmm5, [rsp+0x50]
00007d55df7d9f7f  vmovaps xmm7, [rsp+0x60]
00007d55df7d9f85  vmovaps xmm8, [rsp+0x70]
00007d55df7d9f8b  vmovaps xmm9, [rsp+0x80]
00007d55df7d9f94  vmovaps xmm10, [rsp+0x90]
00007d55df7d9f9d  vmovaps xmm11, [rsp+0xA0]
00007d55df7d9fa6  vmovaps xmm12, [rsp+0xB0]
00007d55df7d9faf  vmovaps xmm13, [rsp+0xC0]
00007d55df7d9fb8  vmovaps xmm14, [rsp+0xD0]
00007d55df7d9fc1  vmovaps xmm15, [rsp+0xE0]
00007d55df7d9fca  add rsp, 0xF0
00007d55df7d9fd1  pop r11
00007d55df7d9fd3  pop r10
00007d55df7d9fd5  pop r9
00007d55df7d9fd7  pop r8
00007d55df7d9fd9  pop rsi
00007d55df7d9fda  pop rdi
00007d55df7d9fdb  pop rdx
00007d55df7d9fdc  pop rcx
00007d55df7d9fdd  pop rax
00007d55df7d9fde  add rsp, 0x08
00007d55df7d9fe2  jmp 0x00007D55DF7D8C07
00007d55df7d9fe7  sub rsp, 0x08
00007d55df7d9feb  push rax
00007d55df7d9fec  push rcx
00007d55df7d9fed  push rdx
00007d55df7d9fee  push rdi
00007d55df7d9fef  push rsi
00007d55df7d9ff0  push r8
00007d55df7d9ff2  push r9
00007d55df7d9ff4  push r10
00007d55df7d9ff6  push r11
00007d55df7d9ff8  sub rsp, 0xF0
00007d55df7d9fff  vmovaps [rsp], xmm0
00007d55df7da004  vmovaps [rsp+0x10], xmm1
00007d55df7da00a  vmovaps [rsp+0x20], xmm2
00007d55df7da010  vmovaps [rsp+0x30], xmm4
00007d55df7da016  vmovaps [rsp+0x40], xmm5
00007d55df7da01c  vmovaps [rsp+0x50], xmm6
00007d55df7da022  vmovaps [rsp+0x60], xmm7
00007d55df7da028  vmovaps [rsp+0x70], xmm8
00007d55df7da02e  vmovaps [rsp+0x80], xmm9
00007d55df7da037  vmovaps [rsp+0x90], xmm10
00007d55df7da040  vmovaps [rsp+0xA0], xmm11
00007d55df7da049  vmovaps [rsp+0xB0], xmm12
00007d55df7da052  vmovaps [rsp+0xC0], xmm13
00007d55df7da05b  vmovaps [rsp+0xD0], xmm14
00007d55df7da064  vmovaps [rsp+0xE0], xmm15
00007d55df7da06d  sub rsp, 0x30
00007d55df7da071  movaps [rsp], xmm3
00007d55df7da075  movaps [rsp+0x10], xmm5
00007d55df7da07a  movaps [rsp+0x20], xmm4
00007d55df7da07f  lea rdi, [rsp]
00007d55df7da083  mov esi, 0x00
00007d55df7da088  mov rax, 0x5BB8433D8530
00007d55df7da092  call rax
00007d55df7da094  movaps xmm3, [rsp]
00007d55df7da098  add rsp, 0x30
00007d55df7da09c  vmovaps xmm0, [rsp]
00007d55df7da0a1  vmovaps xmm1, [rsp+0x10]
00007d55df7da0a7  vmovaps xmm2, [rsp+0x20]
00007d55df7da0ad  vmovaps xmm4, [rsp+0x30]
00007d55df7da0b3  vmovaps xmm5, [rsp+0x40]
00007d55df7da0b9  vmovaps xmm6, [rsp+0x50]
00007d55df7da0bf  vmovaps xmm7, [rsp+0x60]
00007d55df7da0c5  vmovaps xmm8, [rsp+0x70]
00007d55df7da0cb  vmovaps xmm9, [rsp+0x80]
00007d55df7da0d4  vmovaps xmm10, [rsp+0x90]
00007d55df7da0dd  vmovaps xmm11, [rsp+0xA0]
00007d55df7da0e6  vmovaps xmm12, [rsp+0xB0]
00007d55df7da0ef  vmovaps xmm13, [rsp+0xC0]
00007d55df7da0f8  vmovaps xmm14, [rsp+0xD0]
00007d55df7da101  vmovaps xmm15, [rsp+0xE0]
00007d55df7da10a  add rsp, 0xF0
00007d55df7da111  pop r11
00007d55df7da113  pop r10
00007d55df7da115  pop r9
00007d55df7da117  pop r8
00007d55df7da119  pop rsi
00007d55df7da11a  pop rdi
00007d55df7da11b  pop rdx
00007d55df7da11c  pop rcx
00007d55df7da11d  pop rax
00007d55df7da11e  add rsp, 0x08
00007d55df7da122  jmp 0x00007D55DF7D8C68
00007d55df7da127  sub rsp, 0x08
00007d55df7da12b  push rax
00007d55df7da12c  push rcx
00007d55df7da12d  push rdx
00007d55df7da12e  push rdi
00007d55df7da12f  push rsi
00007d55df7da130  push r8
00007d55df7da132  push r9
00007d55df7da134  push r10
00007d55df7da136  push r11
00007d55df7da138  sub rsp, 0xF0
00007d55df7da13f  vmovaps [rsp], xmm0
00007d55df7da144  vmovaps [rsp+0x10], xmm1
00007d55df7da14a  vmovaps [rsp+0x20], xmm2
00007d55df7da150  vmovaps [rsp+0x30], xmm3
00007d55df7da156  vmovaps [rsp+0x40], xmm4
00007d55df7da15c  vmovaps [rsp+0x50], xmm6
00007d55df7da162  vmovaps [rsp+0x60], xmm7
00007d55df7da168  vmovaps [rsp+0x70], xmm8
00007d55df7da16e  vmovaps [rsp+0x80], xmm9
00007d55df7da177  vmovaps [rsp+0x90], xmm10
00007d55df7da180  vmovaps [rsp+0xA0], xmm11
00007d55df7da189  vmovaps [rsp+0xB0], xmm12
00007d55df7da192  vmovaps [rsp+0xC0], xmm13
00007d55df7da19b  vmovaps [rsp+0xD0], xmm14
00007d55df7da1a4  vmovaps [rsp+0xE0], xmm15
00007d55df7da1ad  sub rsp, 0x30
00007d55df7da1b1  movaps [rsp], xmm5
00007d55df7da1b5  movaps [rsp+0x10], xmm8
00007d55df7da1bb  movaps [rsp+0x20], xmm15
00007d55df7da1c1  lea rdi, [rsp]
00007d55df7da1c5  mov esi, 0x00
00007d55df7da1ca  mov rax, 0x5BB8433D8530
00007d55df7da1d4  call rax
00007d55df7da1d6  movaps xmm5, [rsp]
00007d55df7da1da  add rsp, 0x30
00007d55df7da1de  vmovaps xmm0, [rsp]
00007d55df7da1e3  vmovaps xmm1, [rsp+0x10]
00007d55df7da1e9  vmovaps xmm2, [rsp+0x20]
00007d55df7da1ef  vmovaps xmm3, [rsp+0x30]
00007d55df7da1f5  vmovaps xmm4, [rsp+0x40]
00007d55df7da1fb  vmovaps xmm6, [rsp+0x50]
00007d55df7da201  vmovaps xmm7, [rsp+0x60]
00007d55df7da207  vmovaps xmm8, [rsp+0x70]
00007d55df7da20d  vmovaps xmm9, [rsp+0x80]
00007d55df7da216  vmovaps xmm10, [rsp+0x90]
00007d55df7da21f  vmovaps xmm11, [rsp+0xA0]
00007d55df7da228  vmovaps xmm12, [rsp+0xB0]
00007d55df7da231  vmovaps xmm13, [rsp+0xC0]
00007d55df7da23a  vmovaps xmm14, [rsp+0xD0]
00007d55df7da243  vmovaps xmm15, [rsp+0xE0]
00007d55df7da24c  add rsp, 0xF0
00007d55df7da253  pop r11
00007d55df7da255  pop r10
00007d55df7da257  pop r9
00007d55df7da259  pop r8
00007d55df7da25b  pop rsi
00007d55df7da25c  pop rdi
00007d55df7da25d  pop rdx
00007d55df7da25e  pop rcx
00007d55df7da25f  pop rax
00007d55df7da260  add rsp, 0x08
00007d55df7da264  jmp 0x00007D55DF7D8CA0
00007d55df7da269  sub rsp, 0x08
00007d55df7da26d  push rax
00007d55df7da26e  push rcx
00007d55df7da26f  push rdx
00007d55df7da270  push rdi
00007d55df7da271  push rsi
00007d55df7da272  push r8
00007d55df7da274  push r9
00007d55df7da276  push r10
00007d55df7da278  push r11
00007d55df7da27a  sub rsp, 0xF0
00007d55df7da281  vmovaps [rsp], xmm0
00007d55df7da286  vmovaps [rsp+0x10], xmm1
00007d55df7da28c  vmovaps [rsp+0x20], xmm2
00007d55df7da292  vmovaps [rsp+0x30], xmm3
00007d55df7da298  vmovaps [rsp+0x40], xmm5
00007d55df7da29e  vmovaps [rsp+0x50], xmm6
00007d55df7da2a4  vmovaps [rsp+0x60], xmm7
00007d55df7da2aa  vmovaps [rsp+0x70], xmm8
00007d55df7da2b0  vmovaps [rsp+0x80], xmm9
00007d55df7da2b9  vmovaps [rsp+0x90], xmm10
00007d55df7da2c2  vmovaps [rsp+0xA0], xmm11
00007d55df7da2cb  vmovaps [rsp+0xB0], xmm12
00007d55df7da2d4  vmovaps [rsp+0xC0], xmm13
00007d55df7da2dd  vmovaps [rsp+0xD0], xmm14
00007d55df7da2e6  vmovaps [rsp+0xE0], xmm15
00007d55df7da2ef  sub rsp, 0x30
00007d55df7da2f3  movaps [rsp], xmm4
00007d55df7da2f7  movaps [rsp+0x10], xmm9
00007d55df7da2fd  movaps [rsp+0x20], xmm8
00007d55df7da303  lea rdi, [rsp]
00007d55df7da307  mov esi, 0x00
00007d55df7da30c  mov rax, 0x5BB8433D8530
00007d55df7da316  call rax
00007d55df7da318  movaps xmm4, [rsp]
00007d55df7da31c  add rsp, 0x30
00007d55df7da320  vmovaps xmm0, [rsp]
00007d55df7da325  vmovaps xmm1, [rsp+0x10]
00007d55df7da32b  vmovaps xmm2, [rsp+0x20]
00007d55df7da331  vmovaps xmm3, [rsp+0x30]
00007d55df7da337  vmovaps xmm5, [rsp+0x40]
00007d55df7da33d  vmovaps xmm6, [rsp+0x50]
00007d55df7da343  vmovaps xmm7, [rsp+0x60]
00007d55df7da349  vmovaps xmm8, [rsp+0x70]
00007d55df7da34f  vmovaps xmm9, [rsp+0x80]
00007d55df7da358  vmovaps xmm10, [rsp+0x90]
00007d55df7da361  vmovaps xmm11, [rsp+0xA0]
00007d55df7da36a  vmovaps xmm12, [rsp+0xB0]
00007d55df7da373  vmovaps xmm13, [rsp+0xC0]
00007d55df7da37c  vmovaps xmm14, [rsp+0xD0]
00007d55df7da385  vmovaps xmm15, [rsp+0xE0]
00007d55df7da38e  add rsp, 0xF0
00007d55df7da395  pop r11
00007d55df7da397  pop r10
00007d55df7da399  pop r9
00007d55df7da39b  pop r8
00007d55df7da39d  pop rsi
00007d55df7da39e  pop rdi
00007d55df7da39f  pop rdx
00007d55df7da3a0  pop rcx
00007d55df7da3a1  pop rax
00007d55df7da3a2  add rsp, 0x08
00007d55df7da3a6  jmp 0x00007D55DF7D8CC1
00007d55df7da3ab  sub rsp, 0x08
00007d55df7da3af  push rax
00007d55df7da3b0  push rcx
00007d55df7da3b1  push rdx
00007d55df7da3b2  push rdi
00007d55df7da3b3  push rsi
00007d55df7da3b4  push r8
00007d55df7da3b6  push r9
00007d55df7da3b8  push r10
00007d55df7da3ba  push r11
00007d55df7da3bc  sub rsp, 0xF0
00007d55df7da3c3  vmovaps [rsp], xmm0
00007d55df7da3c8  vmovaps [rsp+0x10], xmm1
00007d55df7da3ce  vmovaps [rsp+0x20], xmm2
00007d55df7da3d4  vmovaps [rsp+0x30], xmm3
00007d55df7da3da  vmovaps [rsp+0x40], xmm4
00007d55df7da3e0  vmovaps [rsp+0x50], xmm5
00007d55df7da3e6  vmovaps [rsp+0x60], xmm6
00007d55df7da3ec  vmovaps [rsp+0x70], xmm7
00007d55df7da3f2  vmovaps [rsp+0x80], xmm8
00007d55df7da3fb  vmovaps [rsp+0x90], xmm10
00007d55df7da404  vmovaps [rsp+0xA0], xmm11
00007d55df7da40d  vmovaps [rsp+0xB0], xmm12
00007d55df7da416  vmovaps [rsp+0xC0], xmm13
00007d55df7da41f  vmovaps [rsp+0xD0], xmm14
00007d55df7da428  vmovaps [rsp+0xE0], xmm15
00007d55df7da431  sub rsp, 0x30
00007d55df7da435  movaps [rsp], xmm9
00007d55df7da43a  movaps [rsp+0x10], xmm10
00007d55df7da440  movaps [rsp+0x20], xmm8
00007d55df7da446  lea rdi, [rsp]
00007d55df7da44a  mov esi, 0x00
00007d55df7da44f  mov rax, 0x5BB8433D8530
00007d55df7da459  call rax
00007d55df7da45b  movaps xmm9, [rsp]
00007d55df7da460  add rsp, 0x30
00007d55df7da464  vmovaps xmm0, [rsp]
00007d55df7da469  vmovaps xmm1, [rsp+0x10]
00007d55df7da46f  vmovaps xmm2, [rsp+0x20]
00007d55df7da475  vmovaps xmm3, [rsp+0x30]
00007d55df7da47b  vmovaps xmm4, [rsp+0x40]
00007d55df7da481  vmovaps xmm5, [rsp+0x50]
00007d55df7da487  vmovaps xmm6, [rsp+0x60]
00007d55df7da48d  vmovaps xmm7, [rsp+0x70]
00007d55df7da493  vmovaps xmm8, [rsp+0x80]
00007d55df7da49c  vmovaps xmm10, [rsp+0x90]
00007d55df7da4a5  vmovaps xmm11, [rsp+0xA0]
00007d55df7da4ae  vmovaps xmm12, [rsp+0xB0]
00007d55df7da4b7  vmovaps xmm13, [rsp+0xC0]
00007d55df7da4c0  vmovaps xmm14, [rsp+0xD0]
00007d55df7da4c9  vmovaps xmm15, [rsp+0xE0]
00007d55df7da4d2  add rsp, 0xF0
00007d55df7da4d9  pop r11
00007d55df7da4db  pop r10
00007d55df7da4dd  pop r9
00007d55df7da4df  pop r8
00007d55df7da4e1  pop rsi
00007d55df7da4e2  pop rdi
00007d55df7da4e3  pop rdx
00007d55df7da4e4  pop rcx
00007d55df7da4e5  pop rax
00007d55df7da4e6  add rsp, 0x08
00007d55df7da4ea  jmp 0x00007D55DF7D8CDB
00007d55df7da4ef  call 0x00007D55DF6D64F0
00007d55df7da4f4  jmp 0x00007D55DF7D8DF5
00007d55df7da4f9  call 0x00007D55DF6D64F0
00007d55df7da4fe  jmp 0x00007D55DF7D8E0B
00007d55df7da503  sub rsp, 0x08
00007d55df7da507  push rax
00007d55df7da508  push rcx
00007d55df7da509  push rdx
00007d55df7da50a  push rdi
00007d55df7da50b  push rsi
00007d55df7da50c  push r8
00007d55df7da50e  push r9
00007d55df7da510  push r10
00007d55df7da512  push r11
00007d55df7da514  sub rsp, 0xF0
00007d55df7da51b  vmovaps [rsp], xmm0
00007d55df7da520  vmovaps [rsp+0x10], xmm2
00007d55df7da526  vmovaps [rsp+0x20], xmm3
00007d55df7da52c  vmovaps [rsp+0x30], xmm4
00007d55df7da532  vmovaps [rsp+0x40], xmm5
00007d55df7da538  vmovaps [rsp+0x50], xmm6
00007d55df7da53e  vmovaps [rsp+0x60], xmm7
00007d55df7da544  vmovaps [rsp+0x70], xmm8
00007d55df7da54a  vmovaps [rsp+0x80], xmm9
00007d55df7da553  vmovaps [rsp+0x90], xmm10
00007d55df7da55c  vmovaps [rsp+0xA0], xmm11
00007d55df7da565  vmovaps [rsp+0xB0], xmm12
00007d55df7da56e  vmovaps [rsp+0xC0], xmm13
00007d55df7da577  vmovaps [rsp+0xD0], xmm14
00007d55df7da580  vmovaps [rsp+0xE0], xmm15
00007d55df7da589  sub rsp, 0x30
00007d55df7da58d  movaps [rsp], xmm1
00007d55df7da591  movaps [rsp+0x10], xmm6
00007d55df7da596  movaps [rsp+0x20], xmm15
00007d55df7da59c  lea rdi, [rsp]
00007d55df7da5a0  mov esi, 0x00
00007d55df7da5a5  mov rax, 0x5BB8433D8530
00007d55df7da5af  call rax
00007d55df7da5b1  movaps xmm1, [rsp]
00007d55df7da5b5  add rsp, 0x30
00007d55df7da5b9  vmovaps xmm0, [rsp]
00007d55df7da5be  vmovaps xmm2, [rsp+0x10]
00007d55df7da5c4  vmovaps xmm3, [rsp+0x20]
00007d55df7da5ca  vmovaps xmm4, [rsp+0x30]
00007d55df7da5d0  vmovaps xmm5, [rsp+0x40]
00007d55df7da5d6  vmovaps xmm6, [rsp+0x50]
00007d55df7da5dc  vmovaps xmm7, [rsp+0x60]
00007d55df7da5e2  vmovaps xmm8, [rsp+0x70]
00007d55df7da5e8  vmovaps xmm9, [rsp+0x80]
00007d55df7da5f1  vmovaps xmm10, [rsp+0x90]
00007d55df7da5fa  vmovaps xmm11, [rsp+0xA0]
00007d55df7da603  vmovaps xmm12, [rsp+0xB0]
00007d55df7da60c  vmovaps xmm13, [rsp+0xC0]
00007d55df7da615  vmovaps xmm14, [rsp+0xD0]
00007d55df7da61e  vmovaps xmm15, [rsp+0xE0]
00007d55df7da627  add rsp, 0xF0
00007d55df7da62e  pop r11
00007d55df7da630  pop r10
00007d55df7da632  pop r9
00007d55df7da634  pop r8
00007d55df7da636  pop rsi
00007d55df7da637  pop rdi
00007d55df7da638  pop rdx
00007d55df7da639  pop rcx
00007d55df7da63a  pop rax
00007d55df7da63b  add rsp, 0x08
00007d55df7da63f  jmp 0x00007D55DF7D8E48
00007d55df7da644  call 0x00007D55DF6E5820
00007d55df7da649  jmp 0x00007D55DF7D8E55
00007d55df7da64e  sub rsp, 0x08
00007d55df7da652  push rax
00007d55df7da653  push rcx
00007d55df7da654  push rdx
00007d55df7da655  push rdi
00007d55df7da656  push rsi
00007d55df7da657  push r8
00007d55df7da659  push r9
00007d55df7da65b  push r10
00007d55df7da65d  push r11
00007d55df7da65f  sub rsp, 0xF0
00007d55df7da666  vmovaps [rsp], xmm0
00007d55df7da66b  vmovaps [rsp+0x10], xmm1
00007d55df7da671  vmovaps [rsp+0x20], xmm2
00007d55df7da677  vmovaps [rsp+0x30], xmm3
00007d55df7da67d  vmovaps [rsp+0x40], xmm4
00007d55df7da683  vmovaps [rsp+0x50], xmm5
00007d55df7da689  vmovaps [rsp+0x60], xmm6
00007d55df7da68f  vmovaps [rsp+0x70], xmm7
00007d55df7da695  vmovaps [rsp+0x80], xmm8
00007d55df7da69e  vmovaps [rsp+0x90], xmm9
00007d55df7da6a7  vmovaps [rsp+0xA0], xmm10
00007d55df7da6b0  vmovaps [rsp+0xB0], xmm11
00007d55df7da6b9  vmovaps [rsp+0xC0], xmm12
00007d55df7da6c2  vmovaps [rsp+0xD0], xmm13
00007d55df7da6cb  vmovaps [rsp+0xE0], xmm15
00007d55df7da6d4  sub rsp, 0x30
00007d55df7da6d8  movaps [rsp], xmm14
00007d55df7da6dd  movaps [rsp+0x10], xmm4
00007d55df7da6e2  movaps [rsp+0x20], xmm3
00007d55df7da6e7  lea rdi, [rsp]
00007d55df7da6eb  mov esi, 0x00
00007d55df7da6f0  mov rax, 0x5BB8433D8530
00007d55df7da6fa  call rax
00007d55df7da6fc  movaps xmm14, [rsp]
00007d55df7da701  add rsp, 0x30
00007d55df7da705  vmovaps xmm0, [rsp]
00007d55df7da70a  vmovaps xmm1, [rsp+0x10]
00007d55df7da710  vmovaps xmm2, [rsp+0x20]
00007d55df7da716  vmovaps xmm3, [rsp+0x30]
00007d55df7da71c  vmovaps xmm4, [rsp+0x40]
00007d55df7da722  vmovaps xmm5, [rsp+0x50]
00007d55df7da728  vmovaps xmm6, [rsp+0x60]
00007d55df7da72e  vmovaps xmm7, [rsp+0x70]
00007d55df7da734  vmovaps xmm8, [rsp+0x80]
00007d55df7da73d  vmovaps xmm9, [rsp+0x90]
00007d55df7da746  vmovaps xmm10, [rsp+0xA0]
00007d55df7da74f  vmovaps xmm11, [rsp+0xB0]
00007d55df7da758  vmovaps xmm12, [rsp+0xC0]
00007d55df7da761  vmovaps xmm13, [rsp+0xD0]
00007d55df7da76a  vmovaps xmm15, [rsp+0xE0]
00007d55df7da773  add rsp, 0xF0
00007d55df7da77a  pop r11
00007d55df7da77c  pop r10
00007d55df7da77e  pop r9
00007d55df7da780  pop r8
00007d55df7da782  pop rsi
00007d55df7da783  pop rdi
00007d55df7da784  pop rdx
00007d55df7da785  pop rcx
00007d55df7da786  pop rax
00007d55df7da787  add rsp, 0x08
00007d55df7da78b  jmp 0x00007D55DF7D8E6F
00007d55df7da790  sub rsp, 0x08
00007d55df7da794  push rax
00007d55df7da795  push rcx
00007d55df7da796  push rdx
00007d55df7da797  push rdi
00007d55df7da798  push rsi
00007d55df7da799  push r8
00007d55df7da79b  push r9
00007d55df7da79d  push r10
00007d55df7da79f  push r11
00007d55df7da7a1  sub rsp, 0xF0
00007d55df7da7a8  vmovaps [rsp], xmm0
00007d55df7da7ad  vmovaps [rsp+0x10], xmm1
00007d55df7da7b3  vmovaps [rsp+0x20], xmm2
00007d55df7da7b9  vmovaps [rsp+0x30], xmm3
00007d55df7da7bf  vmovaps [rsp+0x40], xmm4
00007d55df7da7c5  vmovaps [rsp+0x50], xmm5
00007d55df7da7cb  vmovaps [rsp+0x60], xmm7
00007d55df7da7d1  vmovaps [rsp+0x70], xmm8
00007d55df7da7d7  vmovaps [rsp+0x80], xmm9
00007d55df7da7e0  vmovaps [rsp+0x90], xmm10
00007d55df7da7e9  vmovaps [rsp+0xA0], xmm11
00007d55df7da7f2  vmovaps [rsp+0xB0], xmm12
00007d55df7da7fb  vmovaps [rsp+0xC0], xmm13
00007d55df7da804  vmovaps [rsp+0xD0], xmm14
00007d55df7da80d  vmovaps [rsp+0xE0], xmm15
00007d55df7da816  sub rsp, 0x30
00007d55df7da81a  movaps [rsp], xmm6
00007d55df7da81e  movaps [rsp+0x10], xmm9
00007d55df7da824  movaps [rsp+0x20], xmm7
00007d55df7da829  lea rdi, [rsp]
00007d55df7da82d  mov esi, 0x00
00007d55df7da832  mov rax, 0x5BB8433D8530
00007d55df7da83c  call rax
00007d55df7da83e  movaps xmm6, [rsp]
00007d55df7da842  add rsp, 0x30
00007d55df7da846  vmovaps xmm0, [rsp]
00007d55df7da84b  vmovaps xmm1, [rsp+0x10]
00007d55df7da851  vmovaps xmm2, [rsp+0x20]
00007d55df7da857  vmovaps xmm3, [rsp+0x30]
00007d55df7da85d  vmovaps xmm4, [rsp+0x40]
00007d55df7da863  vmovaps xmm5, [rsp+0x50]
00007d55df7da869  vmovaps xmm7, [rsp+0x60]
00007d55df7da86f  vmovaps xmm8, [rsp+0x70]
00007d55df7da875  vmovaps xmm9, [rsp+0x80]
00007d55df7da87e  vmovaps xmm10, [rsp+0x90]
00007d55df7da887  vmovaps xmm11, [rsp+0xA0]
00007d55df7da890  vmovaps xmm12, [rsp+0xB0]
00007d55df7da899  vmovaps xmm13, [rsp+0xC0]
00007d55df7da8a2  vmovaps xmm14, [rsp+0xD0]
00007d55df7da8ab  vmovaps xmm15, [rsp+0xE0]
00007d55df7da8b4  add rsp, 0xF0
00007d55df7da8bb  pop r11
00007d55df7da8bd  pop r10
00007d55df7da8bf  pop r9
00007d55df7da8c1  pop r8
00007d55df7da8c3  pop rsi
00007d55df7da8c4  pop rdi
00007d55df7da8c5  pop rdx
00007d55df7da8c6  pop rcx
00007d55df7da8c7  pop rax
00007d55df7da8c8  add rsp, 0x08
00007d55df7da8cc  jmp 0x00007D55DF7D8E87
00007d55df7da8d1  sub rsp, 0x08
00007d55df7da8d5  push rax
00007d55df7da8d6  push rcx
00007d55df7da8d7  push rdx
00007d55df7da8d8  push rdi
00007d55df7da8d9  push rsi
00007d55df7da8da  push r8
00007d55df7da8dc  push r9
00007d55df7da8de  push r10
00007d55df7da8e0  push r11
00007d55df7da8e2  sub rsp, 0xF0
00007d55df7da8e9  vmovaps [rsp], xmm0
00007d55df7da8ee  vmovaps [rsp+0x10], xmm1
00007d55df7da8f4  vmovaps [rsp+0x20], xmm2
00007d55df7da8fa  vmovaps [rsp+0x30], xmm3
00007d55df7da900  vmovaps [rsp+0x40], xmm4
00007d55df7da906  vmovaps [rsp+0x50], xmm5
00007d55df7da90c  vmovaps [rsp+0x60], xmm6
00007d55df7da912  vmovaps [rsp+0x70], xmm8
00007d55df7da918  vmovaps [rsp+0x80], xmm9
00007d55df7da921  vmovaps [rsp+0x90], xmm10
00007d55df7da92a  vmovaps [rsp+0xA0], xmm11
00007d55df7da933  vmovaps [rsp+0xB0], xmm12
00007d55df7da93c  vmovaps [rsp+0xC0], xmm13
00007d55df7da945  vmovaps [rsp+0xD0], xmm14
00007d55df7da94e  vmovaps [rsp+0xE0], xmm15
00007d55df7da957  sub rsp, 0x30
00007d55df7da95b  movaps [rsp], xmm7
00007d55df7da95f  movaps [rsp+0x10], xmm4
00007d55df7da964  movaps [rsp+0x20], xmm9
00007d55df7da96a  lea rdi, [rsp]
00007d55df7da96e  mov esi, 0x00
00007d55df7da973  mov rax, 0x5BB8433D8530
00007d55df7da97d  call rax
00007d55df7da97f  movaps xmm7, [rsp]
00007d55df7da983  add rsp, 0x30
00007d55df7da987  vmovaps xmm0, [rsp]
00007d55df7da98c  vmovaps xmm1, [rsp+0x10]
00007d55df7da992  vmovaps xmm2, [rsp+0x20]
00007d55df7da998  vmovaps xmm3, [rsp+0x30]
00007d55df7da99e  vmovaps xmm4, [rsp+0x40]
00007d55df7da9a4  vmovaps xmm5, [rsp+0x50]
00007d55df7da9aa  vmovaps xmm6, [rsp+0x60]
00007d55df7da9b0  vmovaps xmm8, [rsp+0x70]
00007d55df7da9b6  vmovaps xmm9, [rsp+0x80]
00007d55df7da9bf  vmovaps xmm10, [rsp+0x90]
00007d55df7da9c8  vmovaps xmm11, [rsp+0xA0]
00007d55df7da9d1  vmovaps xmm12, [rsp+0xB0]
00007d55df7da9da  vmovaps xmm13, [rsp+0xC0]
00007d55df7da9e3  vmovaps xmm14, [rsp+0xD0]
00007d55df7da9ec  vmovaps xmm15, [rsp+0xE0]
00007d55df7da9f5  add rsp, 0xF0
00007d55df7da9fc  pop r11
00007d55df7da9fe  pop r10
00007d55df7daa00  pop r9
00007d55df7daa02  pop r8
00007d55df7daa04  pop rsi
00007d55df7daa05  pop rdi
00007d55df7daa06  pop rdx
00007d55df7daa07  pop rcx
00007d55df7daa08  pop rax
00007d55df7daa09  add rsp, 0x08
00007d55df7daa0d  jmp 0x00007D55DF7D8EB4
00007d55df7daa12  sub rsp, 0x08
00007d55df7daa16  push rax
00007d55df7daa17  push rcx
00007d55df7daa18  push rdx
00007d55df7daa19  push rdi
00007d55df7daa1a  push rsi
00007d55df7daa1b  push r8
00007d55df7daa1d  push r9
00007d55df7daa1f  push r10
00007d55df7daa21  push r11
00007d55df7daa23  sub rsp, 0xF0
00007d55df7daa2a  vmovaps [rsp], xmm0
00007d55df7daa2f  vmovaps [rsp+0x10], xmm1
00007d55df7daa35  vmovaps [rsp+0x20], xmm2
00007d55df7daa3b  vmovaps [rsp+0x30], xmm3
00007d55df7daa41  vmovaps [rsp+0x40], xmm5
00007d55df7daa47  vmovaps [rsp+0x50], xmm6
00007d55df7daa4d  vmovaps [rsp+0x60], xmm7
00007d55df7daa53  vmovaps [rsp+0x70], xmm8
00007d55df7daa59  vmovaps [rsp+0x80], xmm9
00007d55df7daa62  vmovaps [rsp+0x90], xmm10
00007d55df7daa6b  vmovaps [rsp+0xA0], xmm11
00007d55df7daa74  vmovaps [rsp+0xB0], xmm12
00007d55df7daa7d  vmovaps [rsp+0xC0], xmm13
00007d55df7daa86  vmovaps [rsp+0xD0], xmm14
00007d55df7daa8f  vmovaps [rsp+0xE0], xmm15
00007d55df7daa98  sub rsp, 0x30
00007d55df7daa9c  movaps [rsp], xmm4
00007d55df7daaa0  movaps [rsp+0x10], xmm15
00007d55df7daaa6  movaps [rsp+0x20], xmm9
00007d55df7daaac  lea rdi, [rsp]
00007d55df7daab0  mov esi, 0x00
00007d55df7daab5  mov rax, 0x5BB8433D8530
00007d55df7daabf  call rax
00007d55df7daac1  movaps xmm4, [rsp]
00007d55df7daac5  add rsp, 0x30
00007d55df7daac9  vmovaps xmm0, [rsp]
00007d55df7daace  vmovaps xmm1, [rsp+0x10]
00007d55df7daad4  vmovaps xmm2, [rsp+0x20]
00007d55df7daada  vmovaps xmm3, [rsp+0x30]
00007d55df7daae0  vmovaps xmm5, [rsp+0x40]
00007d55df7daae6  vmovaps xmm6, [rsp+0x50]
00007d55df7daaec  vmovaps xmm7, [rsp+0x60]
00007d55df7daaf2  vmovaps xmm8, [rsp+0x70]
00007d55df7daaf8  vmovaps xmm9, [rsp+0x80]
00007d55df7dab01  vmovaps xmm10, [rsp+0x90]
00007d55df7dab0a  vmovaps xmm11, [rsp+0xA0]
00007d55df7dab13  vmovaps xmm12, [rsp+0xB0]
00007d55df7dab1c  vmovaps xmm13, [rsp+0xC0]
00007d55df7dab25  vmovaps xmm14, [rsp+0xD0]
00007d55df7dab2e  vmovaps xmm15, [rsp+0xE0]
00007d55df7dab37  add rsp, 0xF0
00007d55df7dab3e  pop r11
00007d55df7dab40  pop r10
00007d55df7dab42  pop r9
00007d55df7dab44  pop r8
00007d55df7dab46  pop rsi
00007d55df7dab47  pop rdi
00007d55df7dab48  pop rdx
00007d55df7dab49  pop rcx
00007d55df7dab4a  pop rax
00007d55df7dab4b  add rsp, 0x08
00007d55df7dab4f  jmp 0x00007D55DF7D8ED9
00007d55df7dab54  call 0x00007D55DF6E5820
00007d55df7dab59  jmp 0x00007D55DF7D8EE6
00007d55df7dab5e  sub rsp, 0x08
00007d55df7dab62  push rax
00007d55df7dab63  push rcx
00007d55df7dab64  push rdx
00007d55df7dab65  push rdi
00007d55df7dab66  push rsi
00007d55df7dab67  push r8
00007d55df7dab69  push r9
00007d55df7dab6b  push r10
00007d55df7dab6d  push r11
00007d55df7dab6f  sub rsp, 0xF0
00007d55df7dab76  vmovaps [rsp], xmm0
00007d55df7dab7b  vmovaps [rsp+0x10], xmm1
00007d55df7dab81  vmovaps [rsp+0x20], xmm2
00007d55df7dab87  vmovaps [rsp+0x30], xmm4
00007d55df7dab8d  vmovaps [rsp+0x40], xmm5
00007d55df7dab93  vmovaps [rsp+0x50], xmm6
00007d55df7dab99  vmovaps [rsp+0x60], xmm7
00007d55df7dab9f  vmovaps [rsp+0x70], xmm8
00007d55df7daba5  vmovaps [rsp+0x80], xmm9
00007d55df7dabae  vmovaps [rsp+0x90], xmm10
00007d55df7dabb7  vmovaps [rsp+0xA0], xmm11
00007d55df7dabc0  vmovaps [rsp+0xB0], xmm12
00007d55df7dabc9  vmovaps [rsp+0xC0], xmm13
00007d55df7dabd2  vmovaps [rsp+0xD0], xmm14
00007d55df7dabdb  vmovaps [rsp+0xE0], xmm15
00007d55df7dabe4  sub rsp, 0x30
00007d55df7dabe8  movaps [rsp], xmm3
00007d55df7dabec  movaps [rsp+0x10], xmm1
00007d55df7dabf1  movaps [rsp+0x20], xmm9
00007d55df7dabf7  lea rdi, [rsp]
00007d55df7dabfb  mov esi, 0x00
00007d55df7dac00  mov rax, 0x5BB8433D8530
00007d55df7dac0a  call rax
00007d55df7dac0c  movaps xmm3, [rsp]
00007d55df7dac10  add rsp, 0x30
00007d55df7dac14  vmovaps xmm0, [rsp]
00007d55df7dac19  vmovaps xmm1, [rsp+0x10]
00007d55df7dac1f  vmovaps xmm2, [rsp+0x20]
00007d55df7dac25  vmovaps xmm4, [rsp+0x30]
00007d55df7dac2b  vmovaps xmm5, [rsp+0x40]
00007d55df7dac31  vmovaps xmm6, [rsp+0x50]
00007d55df7dac37  vmovaps xmm7, [rsp+0x60]
00007d55df7dac3d  vmovaps xmm8, [rsp+0x70]
00007d55df7dac43  vmovaps xmm9, [rsp+0x80]
00007d55df7dac4c  vmovaps xmm10, [rsp+0x90]
00007d55df7dac55  vmovaps xmm11, [rsp+0xA0]
00007d55df7dac5e  vmovaps xmm12, [rsp+0xB0]
00007d55df7dac67  vmovaps xmm13, [rsp+0xC0]
00007d55df7dac70  vmovaps xmm14, [rsp+0xD0]
00007d55df7dac79  vmovaps xmm15, [rsp+0xE0]
00007d55df7dac82  add rsp, 0xF0
00007d55df7dac89  pop r11
00007d55df7dac8b  pop r10
00007d55df7dac8d  pop r9
00007d55df7dac8f  pop r8
00007d55df7dac91  pop rsi
00007d55df7dac92  pop rdi
00007d55df7dac93  pop rdx
00007d55df7dac94  pop rcx
00007d55df7dac95  pop rax
00007d55df7dac96  add rsp, 0x08
00007d55df7dac9a  jmp 0x00007D55DF7D8F23
00007d55df7dac9f  sub rsp, 0x08
00007d55df7daca3  push rax
00007d55df7daca4  push rcx
00007d55df7daca5  push rdx
00007d55df7daca6  push rdi
00007d55df7daca7  push rsi
00007d55df7daca8  push r8
00007d55df7dacaa  push r9
00007d55df7dacac  push r10
00007d55df7dacae  push r11
00007d55df7dacb0  sub rsp, 0xF0
00007d55df7dacb7  vmovaps [rsp], xmm0
00007d55df7dacbc  vmovaps [rsp+0x10], xmm2
00007d55df7dacc2  vmovaps [rsp+0x20], xmm3
00007d55df7dacc8  vmovaps [rsp+0x30], xmm4
00007d55df7dacce  vmovaps [rsp+0x40], xmm5
00007d55df7dacd4  vmovaps [rsp+0x50], xmm6
00007d55df7dacda  vmovaps [rsp+0x60], xmm7
00007d55df7dace0  vmovaps [rsp+0x70], xmm8
00007d55df7dace6  vmovaps [rsp+0x80], xmm9
00007d55df7dacef  vmovaps [rsp+0x90], xmm10
00007d55df7dacf8  vmovaps [rsp+0xA0], xmm11
00007d55df7dad01  vmovaps [rsp+0xB0], xmm12
00007d55df7dad0a  vmovaps [rsp+0xC0], xmm13
00007d55df7dad13  vmovaps [rsp+0xD0], xmm14
00007d55df7dad1c  vmovaps [rsp+0xE0], xmm15
00007d55df7dad25  sub rsp, 0x30
00007d55df7dad29  movaps [rsp], xmm1
00007d55df7dad2d  movaps [rsp+0x10], xmm15
00007d55df7dad33  movaps [rsp+0x20], xmm9
00007d55df7dad39  lea rdi, [rsp]
00007d55df7dad3d  mov esi, 0x00
00007d55df7dad42  mov rax, 0x5BB8433D8530
00007d55df7dad4c  call rax
00007d55df7dad4e  movaps xmm1, [rsp]
00007d55df7dad52  add rsp, 0x30
00007d55df7dad56  vmovaps xmm0, [rsp]
00007d55df7dad5b  vmovaps xmm2, [rsp+0x10]
00007d55df7dad61  vmovaps xmm3, [rsp+0x20]
00007d55df7dad67  vmovaps xmm4, [rsp+0x30]
00007d55df7dad6d  vmovaps xmm5, [rsp+0x40]
00007d55df7dad73  vmovaps xmm6, [rsp+0x50]
00007d55df7dad79  vmovaps xmm7, [rsp+0x60]
00007d55df7dad7f  vmovaps xmm8, [rsp+0x70]
00007d55df7dad85  vmovaps xmm9, [rsp+0x80]
00007d55df7dad8e  vmovaps xmm10, [rsp+0x90]
00007d55df7dad97  vmovaps xmm11, [rsp+0xA0]
00007d55df7dada0  vmovaps xmm12, [rsp+0xB0]
00007d55df7dada9  vmovaps xmm13, [rsp+0xC0]
00007d55df7dadb2  vmovaps xmm14, [rsp+0xD0]
00007d55df7dadbb  vmovaps xmm15, [rsp+0xE0]
00007d55df7dadc4  add rsp, 0xF0
00007d55df7dadcb  pop r11
00007d55df7dadcd  pop r10
00007d55df7dadcf  pop r9
00007d55df7dadd1  pop r8
00007d55df7dadd3  pop rsi
00007d55df7dadd4  pop rdi
00007d55df7dadd5  pop rdx
00007d55df7dadd6  pop rcx
00007d55df7dadd7  pop rax
00007d55df7dadd8  add rsp, 0x08
00007d55df7daddc  jmp 0x00007D55DF7D8FAB
00007d55df7dade1  call 0x00007D55DF6E5820
00007d55df7dade6  jmp 0x00007D55DF7D8FB8
00007d55df7dadeb  sub rsp, 0x08
00007d55df7dadef  push rax
00007d55df7dadf0  push rcx
00007d55df7dadf1  push rdx
00007d55df7dadf2  push rdi
00007d55df7dadf3  push rsi
00007d55df7dadf4  push r8
00007d55df7dadf6  push r9
00007d55df7dadf8  push r10
00007d55df7dadfa  push r11
00007d55df7dadfc  sub rsp, 0xF0
00007d55df7dae03  vmovaps [rsp], xmm0
00007d55df7dae08  vmovaps [rsp+0x10], xmm2
00007d55df7dae0e  vmovaps [rsp+0x20], xmm3
00007d55df7dae14  vmovaps [rsp+0x30], xmm4
00007d55df7dae1a  vmovaps [rsp+0x40], xmm5
00007d55df7dae20  vmovaps [rsp+0x50], xmm6
00007d55df7dae26  vmovaps [rsp+0x60], xmm7
00007d55df7dae2c  vmovaps [rsp+0x70], xmm8
00007d55df7dae32  vmovaps [rsp+0x80], xmm9
00007d55df7dae3b  vmovaps [rsp+0x90], xmm10
00007d55df7dae44  vmovaps [rsp+0xA0], xmm11
00007d55df7dae4d  vmovaps [rsp+0xB0], xmm12
00007d55df7dae56  vmovaps [rsp+0xC0], xmm13
00007d55df7dae5f  vmovaps [rsp+0xD0], xmm14
00007d55df7dae68  vmovaps [rsp+0xE0], xmm15
00007d55df7dae71  sub rsp, 0x30
00007d55df7dae75  movaps [rsp], xmm1
00007d55df7dae79  movaps [rsp+0x10], xmm5
00007d55df7dae7e  movaps [rsp+0x20], xmm7
00007d55df7dae83  lea rdi, [rsp]
00007d55df7dae87  mov esi, 0x00
00007d55df7dae8c  mov rax, 0x5BB8433D8530
00007d55df7dae96  call rax
00007d55df7dae98  movaps xmm1, [rsp]
00007d55df7dae9c  add rsp, 0x30
00007d55df7daea0  vmovaps xmm0, [rsp]
00007d55df7daea5  vmovaps xmm2, [rsp+0x10]
00007d55df7daeab  vmovaps xmm3, [rsp+0x20]
00007d55df7daeb1  vmovaps xmm4, [rsp+0x30]
00007d55df7daeb7  vmovaps xmm5, [rsp+0x40]
00007d55df7daebd  vmovaps xmm6, [rsp+0x50]
00007d55df7daec3  vmovaps xmm7, [rsp+0x60]
00007d55df7daec9  vmovaps xmm8, [rsp+0x70]
00007d55df7daecf  vmovaps xmm9, [rsp+0x80]
00007d55df7daed8  vmovaps xmm10, [rsp+0x90]
00007d55df7daee1  vmovaps xmm11, [rsp+0xA0]
00007d55df7daeea  vmovaps xmm12, [rsp+0xB0]
00007d55df7daef3  vmovaps xmm13, [rsp+0xC0]
00007d55df7daefc  vmovaps xmm14, [rsp+0xD0]
00007d55df7daf05  vmovaps xmm15, [rsp+0xE0]
00007d55df7daf0e  add rsp, 0xF0
00007d55df7daf15  pop r11
00007d55df7daf17  pop r10
00007d55df7daf19  pop r9
00007d55df7daf1b  pop r8
00007d55df7daf1d  pop rsi
00007d55df7daf1e  pop rdi
00007d55df7daf1f  pop rdx
00007d55df7daf20  pop rcx
00007d55df7daf21  pop rax
00007d55df7daf22  add rsp, 0x08
00007d55df7daf26  jmp 0x00007D55DF7D905D
00007d55df7daf2b  sub rsp, 0x08
00007d55df7daf2f  push rax
00007d55df7daf30  push rcx
00007d55df7daf31  push rdx
00007d55df7daf32  push rdi
00007d55df7daf33  push rsi
00007d55df7daf34  push r8
00007d55df7daf36  push r9
00007d55df7daf38  push r10
00007d55df7daf3a  push r11
00007d55df7daf3c  sub rsp, 0xF0
00007d55df7daf43  vmovaps [rsp], xmm0
00007d55df7daf48  vmovaps [rsp+0x10], xmm1
00007d55df7daf4e  vmovaps [rsp+0x20], xmm2
00007d55df7daf54  vmovaps [rsp+0x30], xmm3
00007d55df7daf5a  vmovaps [rsp+0x40], xmm4
00007d55df7daf60  vmovaps [rsp+0x50], xmm5
00007d55df7daf66  vmovaps [rsp+0x60], xmm6
00007d55df7daf6c  vmovaps [rsp+0x70], xmm8
00007d55df7daf72  vmovaps [rsp+0x80], xmm9
00007d55df7daf7b  vmovaps [rsp+0x90], xmm10
00007d55df7daf84  vmovaps [rsp+0xA0], xmm11
00007d55df7daf8d  vmovaps [rsp+0xB0], xmm12
00007d55df7daf96  vmovaps [rsp+0xC0], xmm13
00007d55df7daf9f  vmovaps [rsp+0xD0], xmm14
00007d55df7dafa8  vmovaps [rsp+0xE0], xmm15
00007d55df7dafb1  sub rsp, 0x30
00007d55df7dafb5  movaps [rsp], xmm7
00007d55df7dafb9  movaps [rsp+0x10], xmm5
00007d55df7dafbe  movaps [rsp+0x20], xmm15
00007d55df7dafc4  lea rdi, [rsp]
00007d55df7dafc8  mov esi, 0x00
00007d55df7dafcd  mov rax, 0x5BB8433D8530
00007d55df7dafd7  call rax
00007d55df7dafd9  movaps xmm7, [rsp]
00007d55df7dafdd  add rsp, 0x30
00007d55df7dafe1  vmovaps xmm0, [rsp]
00007d55df7dafe6  vmovaps xmm1, [rsp+0x10]
00007d55df7dafec  vmovaps xmm2, [rsp+0x20]
00007d55df7daff2  vmovaps xmm3, [rsp+0x30]
00007d55df7daff8  vmovaps xmm4, [rsp+0x40]
00007d55df7daffe  vmovaps xmm5, [rsp+0x50]
00007d55df7db004  vmovaps xmm6, [rsp+0x60]
00007d55df7db00a  vmovaps xmm8, [rsp+0x70]
00007d55df7db010  vmovaps xmm9, [rsp+0x80]
00007d55df7db019  vmovaps xmm10, [rsp+0x90]
00007d55df7db022  vmovaps xmm11, [rsp+0xA0]
00007d55df7db02b  vmovaps xmm12, [rsp+0xB0]
00007d55df7db034  vmovaps xmm13, [rsp+0xC0]
00007d55df7db03d  vmovaps xmm14, [rsp+0xD0]
00007d55df7db046  vmovaps xmm15, [rsp+0xE0]
00007d55df7db04f  add rsp, 0xF0
00007d55df7db056  pop r11
00007d55df7db058  pop r10
00007d55df7db05a  pop r9
00007d55df7db05c  pop r8
00007d55df7db05e  pop rsi
00007d55df7db05f  pop rdi
00007d55df7db060  pop rdx
00007d55df7db061  pop rcx
00007d55df7db062  pop rax
00007d55df7db063  add rsp, 0x08
00007d55df7db067  jmp 0x00007D55DF7D9093
00007d55df7db06c  call 0x00007D55DF6D64F0
00007d55df7db071  jmp 0x00007D55DF7D90A0
00007d55df7db076  sub rsp, 0x08
00007d55df7db07a  push rax
00007d55df7db07b  push rcx
00007d55df7db07c  push rdx
00007d55df7db07d  push rdi
00007d55df7db07e  push rsi
00007d55df7db07f  push r8
00007d55df7db081  push r9
00007d55df7db083  push r10
00007d55df7db085  push r11
00007d55df7db087  sub rsp, 0xF0
00007d55df7db08e  vmovaps [rsp], xmm0
00007d55df7db093  vmovaps [rsp+0x10], xmm1
00007d55df7db099  vmovaps [rsp+0x20], xmm2
00007d55df7db09f  vmovaps [rsp+0x30], xmm3
00007d55df7db0a5  vmovaps [rsp+0x40], xmm4
00007d55df7db0ab  vmovaps [rsp+0x50], xmm5
00007d55df7db0b1  vmovaps [rsp+0x60], xmm6
00007d55df7db0b7  vmovaps [rsp+0x70], xmm7
00007d55df7db0bd  vmovaps [rsp+0x80], xmm8
00007d55df7db0c6  vmovaps [rsp+0x90], xmm9
00007d55df7db0cf  vmovaps [rsp+0xA0], xmm10
00007d55df7db0d8  vmovaps [rsp+0xB0], xmm11
00007d55df7db0e1  vmovaps [rsp+0xC0], xmm12
00007d55df7db0ea  vmovaps [rsp+0xD0], xmm13
00007d55df7db0f3  vmovaps [rsp+0xE0], xmm14
00007d55df7db0fc  sub rsp, 0x30
00007d55df7db100  movaps [rsp], xmm15
00007d55df7db105  movaps [rsp+0x10], xmm5
00007d55df7db10a  movaps [rsp+0x20], xmm3
00007d55df7db10f  lea rdi, [rsp]
00007d55df7db113  mov esi, 0x00
00007d55df7db118  mov rax, 0x5BB8433D8530
00007d55df7db122  call rax
00007d55df7db124  movaps xmm15, [rsp]
00007d55df7db129  add rsp, 0x30
00007d55df7db12d  vmovaps xmm0, [rsp]
00007d55df7db132  vmovaps xmm1, [rsp+0x10]
00007d55df7db138  vmovaps xmm2, [rsp+0x20]
00007d55df7db13e  vmovaps xmm3, [rsp+0x30]
00007d55df7db144  vmovaps xmm4, [rsp+0x40]
00007d55df7db14a  vmovaps xmm5, [rsp+0x50]
00007d55df7db150  vmovaps xmm6, [rsp+0x60]
00007d55df7db156  vmovaps xmm7, [rsp+0x70]
00007d55df7db15c  vmovaps xmm8, [rsp+0x80]
00007d55df7db165  vmovaps xmm9, [rsp+0x90]
00007d55df7db16e  vmovaps xmm10, [rsp+0xA0]
00007d55df7db177  vmovaps xmm11, [rsp+0xB0]
00007d55df7db180  vmovaps xmm12, [rsp+0xC0]
00007d55df7db189  vmovaps xmm13, [rsp+0xD0]
00007d55df7db192  vmovaps xmm14, [rsp+0xE0]
00007d55df7db19b  add rsp, 0xF0
00007d55df7db1a2  pop r11
00007d55df7db1a4  pop r10
00007d55df7db1a6  pop r9
00007d55df7db1a8  pop r8
00007d55df7db1aa  pop rsi
00007d55df7db1ab  pop rdi
00007d55df7db1ac  pop rdx
00007d55df7db1ad  pop rcx
00007d55df7db1ae  pop rax
00007d55df7db1af  add rsp, 0x08
00007d55df7db1b3  jmp 0x00007D55DF7D90C6
00007d55df7db1b8  sub rsp, 0x08
00007d55df7db1bc  push rax
00007d55df7db1bd  push rcx
00007d55df7db1be  push rdx
00007d55df7db1bf  push rdi
00007d55df7db1c0  push rsi
00007d55df7db1c1  push r8
00007d55df7db1c3  push r9
00007d55df7db1c5  push r10
00007d55df7db1c7  push r11
00007d55df7db1c9  sub rsp, 0xF0
00007d55df7db1d0  vmovaps [rsp], xmm0
00007d55df7db1d5  vmovaps [rsp+0x10], xmm2
00007d55df7db1db  vmovaps [rsp+0x20], xmm3
00007d55df7db1e1  vmovaps [rsp+0x30], xmm4
00007d55df7db1e7  vmovaps [rsp+0x40], xmm5
00007d55df7db1ed  vmovaps [rsp+0x50], xmm6
00007d55df7db1f3  vmovaps [rsp+0x60], xmm7
00007d55df7db1f9  vmovaps [rsp+0x70], xmm8
00007d55df7db1ff  vmovaps [rsp+0x80], xmm9
00007d55df7db208  vmovaps [rsp+0x90], xmm10
00007d55df7db211  vmovaps [rsp+0xA0], xmm11
00007d55df7db21a  vmovaps [rsp+0xB0], xmm12
00007d55df7db223  vmovaps [rsp+0xC0], xmm13
00007d55df7db22c  vmovaps [rsp+0xD0], xmm14
00007d55df7db235  vmovaps [rsp+0xE0], xmm15
00007d55df7db23e  sub rsp, 0x30
00007d55df7db242  movaps [rsp], xmm1
00007d55df7db246  movaps [rsp+0x10], xmm5
00007d55df7db24b  movaps [rsp+0x20], xmm4
00007d55df7db250  lea rdi, [rsp]
00007d55df7db254  mov esi, 0x00
00007d55df7db259  mov rax, 0x5BB8433D8530
00007d55df7db263  call rax
00007d55df7db265  movaps xmm1, [rsp]
00007d55df7db269  add rsp, 0x30
00007d55df7db26d  vmovaps xmm0, [rsp]
00007d55df7db272  vmovaps xmm2, [rsp+0x10]
00007d55df7db278  vmovaps xmm3, [rsp+0x20]
00007d55df7db27e  vmovaps xmm4, [rsp+0x30]
00007d55df7db284  vmovaps xmm5, [rsp+0x40]
00007d55df7db28a  vmovaps xmm6, [rsp+0x50]
00007d55df7db290  vmovaps xmm7, [rsp+0x60]
00007d55df7db296  vmovaps xmm8, [rsp+0x70]
00007d55df7db29c  vmovaps xmm9, [rsp+0x80]
00007d55df7db2a5  vmovaps xmm10, [rsp+0x90]
00007d55df7db2ae  vmovaps xmm11, [rsp+0xA0]
00007d55df7db2b7  vmovaps xmm12, [rsp+0xB0]
00007d55df7db2c0  vmovaps xmm13, [rsp+0xC0]
00007d55df7db2c9  vmovaps xmm14, [rsp+0xD0]
00007d55df7db2d2  vmovaps xmm15, [rsp+0xE0]
00007d55df7db2db  add rsp, 0xF0
00007d55df7db2e2  pop r11
00007d55df7db2e4  pop r10
00007d55df7db2e6  pop r9
00007d55df7db2e8  pop r8
00007d55df7db2ea  pop rsi
00007d55df7db2eb  pop rdi
00007d55df7db2ec  pop rdx
00007d55df7db2ed  pop rcx
00007d55df7db2ee  pop rax
00007d55df7db2ef  add rsp, 0x08
00007d55df7db2f3  jmp 0x00007D55DF7D90E6
00007d55df7db2f8  sub rsp, 0x08
00007d55df7db2fc  push rax
00007d55df7db2fd  push rcx
00007d55df7db2fe  push rdx
00007d55df7db2ff  push rdi
00007d55df7db300  push rsi
00007d55df7db301  push r8
00007d55df7db303  push r9
00007d55df7db305  push r10
00007d55df7db307  push r11
00007d55df7db309  sub rsp, 0xF0
00007d55df7db310  vmovaps [rsp], xmm0
00007d55df7db315  vmovaps [rsp+0x10], xmm1
00007d55df7db31b  vmovaps [rsp+0x20], xmm2
00007d55df7db321  vmovaps [rsp+0x30], xmm3
00007d55df7db327  vmovaps [rsp+0x40], xmm5
00007d55df7db32d  vmovaps [rsp+0x50], xmm6
00007d55df7db333  vmovaps [rsp+0x60], xmm7
00007d55df7db339  vmovaps [rsp+0x70], xmm8
00007d55df7db33f  vmovaps [rsp+0x80], xmm9
00007d55df7db348  vmovaps [rsp+0x90], xmm10
00007d55df7db351  vmovaps [rsp+0xA0], xmm11
00007d55df7db35a  vmovaps [rsp+0xB0], xmm12
00007d55df7db363  vmovaps [rsp+0xC0], xmm13
00007d55df7db36c  vmovaps [rsp+0xD0], xmm14
00007d55df7db375  vmovaps [rsp+0xE0], xmm15
00007d55df7db37e  sub rsp, 0x30
00007d55df7db382  movaps [rsp], xmm4
00007d55df7db386  movaps [rsp+0x10], xmm3
00007d55df7db38b  movaps [rsp+0x20], xmm5
00007d55df7db390  lea rdi, [rsp]
00007d55df7db394  mov esi, 0x00
00007d55df7db399  mov rax, 0x5BB8433D8530
00007d55df7db3a3  call rax
00007d55df7db3a5  movaps xmm4, [rsp]
00007d55df7db3a9  add rsp, 0x30
00007d55df7db3ad  vmovaps xmm0, [rsp]
00007d55df7db3b2  vmovaps xmm1, [rsp+0x10]
00007d55df7db3b8  vmovaps xmm2, [rsp+0x20]
00007d55df7db3be  vmovaps xmm3, [rsp+0x30]
00007d55df7db3c4  vmovaps xmm5, [rsp+0x40]
00007d55df7db3ca  vmovaps xmm6, [rsp+0x50]
00007d55df7db3d0  vmovaps xmm7, [rsp+0x60]
00007d55df7db3d6  vmovaps xmm8, [rsp+0x70]
00007d55df7db3dc  vmovaps xmm9, [rsp+0x80]
00007d55df7db3e5  vmovaps xmm10, [rsp+0x90]
00007d55df7db3ee  vmovaps xmm11, [rsp+0xA0]
00007d55df7db3f7  vmovaps xmm12, [rsp+0xB0]
00007d55df7db400  vmovaps xmm13, [rsp+0xC0]
00007d55df7db409  vmovaps xmm14, [rsp+0xD0]
00007d55df7db412  vmovaps xmm15, [rsp+0xE0]
00007d55df7db41b  add rsp, 0xF0
00007d55df7db422  pop r11
00007d55df7db424  pop r10
00007d55df7db426  pop r9
00007d55df7db428  pop r8
00007d55df7db42a  pop rsi
00007d55df7db42b  pop rdi
00007d55df7db42c  pop rdx
00007d55df7db42d  pop rcx
00007d55df7db42e  pop rax
00007d55df7db42f  add rsp, 0x08
00007d55df7db433  jmp 0x00007D55DF7D9134
00007d55df7db438  call 0x00007D55DF6D64F0
00007d55df7db43d  jmp 0x00007D55DF7D9141
00007d55df7db442  sub rsp, 0x08
00007d55df7db446  push rax
00007d55df7db447  push rcx
00007d55df7db448  push rdx
00007d55df7db449  push rdi
00007d55df7db44a  push rsi
00007d55df7db44b  push r8
00007d55df7db44d  push r9
00007d55df7db44f  push r10
00007d55df7db451  push r11
00007d55df7db453  sub rsp, 0xF0
00007d55df7db45a  vmovaps [rsp], xmm0
00007d55df7db45f  vmovaps [rsp+0x10], xmm1
00007d55df7db465  vmovaps [rsp+0x20], xmm2
00007d55df7db46b  vmovaps [rsp+0x30], xmm3
00007d55df7db471  vmovaps [rsp+0x40], xmm4
00007d55df7db477  vmovaps [rsp+0x50], xmm6
00007d55df7db47d  vmovaps [rsp+0x60], xmm7
00007d55df7db483  vmovaps [rsp+0x70], xmm8
00007d55df7db489  vmovaps [rsp+0x80], xmm9
00007d55df7db492  vmovaps [rsp+0x90], xmm10
00007d55df7db49b  vmovaps [rsp+0xA0], xmm11
00007d55df7db4a4  vmovaps [rsp+0xB0], xmm12
00007d55df7db4ad  vmovaps [rsp+0xC0], xmm13
00007d55df7db4b6  vmovaps [rsp+0xD0], xmm14
00007d55df7db4bf  vmovaps [rsp+0xE0], xmm15
00007d55df7db4c8  sub rsp, 0x30
00007d55df7db4cc  movaps [rsp], xmm5
00007d55df7db4d0  movaps [rsp+0x10], xmm6
00007d55df7db4d5  movaps [rsp+0x20], xmm3
00007d55df7db4da  lea rdi, [rsp]
00007d55df7db4de  mov esi, 0x00
00007d55df7db4e3  mov rax, 0x5BB8433D8530
00007d55df7db4ed  call rax
00007d55df7db4ef  movaps xmm5, [rsp]
00007d55df7db4f3  add rsp, 0x30
00007d55df7db4f7  vmovaps xmm0, [rsp]
00007d55df7db4fc  vmovaps xmm1, [rsp+0x10]
00007d55df7db502  vmovaps xmm2, [rsp+0x20]
00007d55df7db508  vmovaps xmm3, [rsp+0x30]
00007d55df7db50e  vmovaps xmm4, [rsp+0x40]
00007d55df7db514  vmovaps xmm6, [rsp+0x50]
00007d55df7db51a  vmovaps xmm7, [rsp+0x60]
00007d55df7db520  vmovaps xmm8, [rsp+0x70]
00007d55df7db526  vmovaps xmm9, [rsp+0x80]
00007d55df7db52f  vmovaps xmm10, [rsp+0x90]
00007d55df7db538  vmovaps xmm11, [rsp+0xA0]
00007d55df7db541  vmovaps xmm12, [rsp+0xB0]
00007d55df7db54a  vmovaps xmm13, [rsp+0xC0]
00007d55df7db553  vmovaps xmm14, [rsp+0xD0]
00007d55df7db55c  vmovaps xmm15, [rsp+0xE0]
00007d55df7db565  add rsp, 0xF0
00007d55df7db56c  pop r11
00007d55df7db56e  pop r10
00007d55df7db570  pop r9
00007d55df7db572  pop r8
00007d55df7db574  pop rsi
00007d55df7db575  pop rdi
00007d55df7db576  pop rdx
00007d55df7db577  pop rcx
00007d55df7db578  pop rax
00007d55df7db579  add rsp, 0x08
00007d55df7db57d  jmp 0x00007D55DF7D9167
00007d55df7db582  sub rsp, 0x08
00007d55df7db586  push rax
00007d55df7db587  push rcx
00007d55df7db588  push rdx
00007d55df7db589  push rdi
00007d55df7db58a  push rsi
00007d55df7db58b  push r8
00007d55df7db58d  push r9
00007d55df7db58f  push r10
00007d55df7db591  push r11
00007d55df7db593  sub rsp, 0xF0
00007d55df7db59a  vmovaps [rsp], xmm0
00007d55df7db59f  vmovaps [rsp+0x10], xmm1
00007d55df7db5a5  vmovaps [rsp+0x20], xmm2
00007d55df7db5ab  vmovaps [rsp+0x30], xmm3
00007d55df7db5b1  vmovaps [rsp+0x40], xmm4
00007d55df7db5b7  vmovaps [rsp+0x50], xmm5
00007d55df7db5bd  vmovaps [rsp+0x60], xmm7
00007d55df7db5c3  vmovaps [rsp+0x70], xmm8
00007d55df7db5c9  vmovaps [rsp+0x80], xmm9
00007d55df7db5d2  vmovaps [rsp+0x90], xmm10
00007d55df7db5db  vmovaps [rsp+0xA0], xmm11
00007d55df7db5e4  vmovaps [rsp+0xB0], xmm12
00007d55df7db5ed  vmovaps [rsp+0xC0], xmm13
00007d55df7db5f6  vmovaps [rsp+0xD0], xmm14
00007d55df7db5ff  vmovaps [rsp+0xE0], xmm15
00007d55df7db608  sub rsp, 0x30
00007d55df7db60c  movaps [rsp], xmm6
00007d55df7db610  movaps [rsp+0x10], xmm9
00007d55df7db616  movaps [rsp+0x20], xmm1
00007d55df7db61b  lea rdi, [rsp]
00007d55df7db61f  mov esi, 0x00
00007d55df7db624  mov rax, 0x5BB8433D8530
00007d55df7db62e  call rax
00007d55df7db630  movaps xmm6, [rsp]
00007d55df7db634  add rsp, 0x30
00007d55df7db638  vmovaps xmm0, [rsp]
00007d55df7db63d  vmovaps xmm1, [rsp+0x10]
00007d55df7db643  vmovaps xmm2, [rsp+0x20]
00007d55df7db649  vmovaps xmm3, [rsp+0x30]
00007d55df7db64f  vmovaps xmm4, [rsp+0x40]
00007d55df7db655  vmovaps xmm5, [rsp+0x50]
00007d55df7db65b  vmovaps xmm7, [rsp+0x60]
00007d55df7db661  vmovaps xmm8, [rsp+0x70]
00007d55df7db667  vmovaps xmm9, [rsp+0x80]
00007d55df7db670  vmovaps xmm10, [rsp+0x90]
00007d55df7db679  vmovaps xmm11, [rsp+0xA0]
00007d55df7db682  vmovaps xmm12, [rsp+0xB0]
00007d55df7db68b  vmovaps xmm13, [rsp+0xC0]
00007d55df7db694  vmovaps xmm14, [rsp+0xD0]
00007d55df7db69d  vmovaps xmm15, [rsp+0xE0]
00007d55df7db6a6  add rsp, 0xF0
00007d55df7db6ad  pop r11
00007d55df7db6af  pop r10
00007d55df7db6b1  pop r9
00007d55df7db6b3  pop r8
00007d55df7db6b5  pop rsi
00007d55df7db6b6  pop rdi
00007d55df7db6b7  pop rdx
00007d55df7db6b8  pop rcx
00007d55df7db6b9  pop rax
00007d55df7db6ba  add rsp, 0x08
00007d55df7db6be  jmp 0x00007D55DF7D918B
00007d55df7db6c3  sub rsp, 0x08
00007d55df7db6c7  push rax
00007d55df7db6c8  push rcx
00007d55df7db6c9  push rdx
00007d55df7db6ca  push rdi
00007d55df7db6cb  push rsi
00007d55df7db6cc  push r8
00007d55df7db6ce  push r9
00007d55df7db6d0  push r10
00007d55df7db6d2  push r11
00007d55df7db6d4  sub rsp, 0xF0
00007d55df7db6db  vmovaps [rsp], xmm0
00007d55df7db6e0  vmovaps [rsp+0x10], xmm1
00007d55df7db6e6  vmovaps [rsp+0x20], xmm2
00007d55df7db6ec  vmovaps [rsp+0x30], xmm3
00007d55df7db6f2  vmovaps [rsp+0x40], xmm4
00007d55df7db6f8  vmovaps [rsp+0x50], xmm5
00007d55df7db6fe  vmovaps [rsp+0x60], xmm6
00007d55df7db704  vmovaps [rsp+0x70], xmm7
00007d55df7db70a  vmovaps [rsp+0x80], xmm8
00007d55df7db713  vmovaps [rsp+0x90], xmm10
00007d55df7db71c  vmovaps [rsp+0xA0], xmm11
00007d55df7db725  vmovaps [rsp+0xB0], xmm12
00007d55df7db72e  vmovaps [rsp+0xC0], xmm13
00007d55df7db737  vmovaps [rsp+0xD0], xmm14
00007d55df7db740  vmovaps [rsp+0xE0], xmm15
00007d55df7db749  sub rsp, 0x30
00007d55df7db74d  movaps [rsp], xmm9
00007d55df7db752  movaps [rsp+0x10], xmm3
00007d55df7db757  movaps [rsp+0x20], xmm1
00007d55df7db75c  lea rdi, [rsp]
00007d55df7db760  mov esi, 0x00
00007d55df7db765  mov rax, 0x5BB8433D8530
00007d55df7db76f  call rax
00007d55df7db771  movaps xmm9, [rsp]
00007d55df7db776  add rsp, 0x30
00007d55df7db77a  vmovaps xmm0, [rsp]
00007d55df7db77f  vmovaps xmm1, [rsp+0x10]
00007d55df7db785  vmovaps xmm2, [rsp+0x20]
00007d55df7db78b  vmovaps xmm3, [rsp+0x30]
00007d55df7db791  vmovaps xmm4, [rsp+0x40]
00007d55df7db797  vmovaps xmm5, [rsp+0x50]
00007d55df7db79d  vmovaps xmm6, [rsp+0x60]
00007d55df7db7a3  vmovaps xmm7, [rsp+0x70]
00007d55df7db7a9  vmovaps xmm8, [rsp+0x80]
00007d55df7db7b2  vmovaps xmm10, [rsp+0x90]
00007d55df7db7bb  vmovaps xmm11, [rsp+0xA0]
00007d55df7db7c4  vmovaps xmm12, [rsp+0xB0]
00007d55df7db7cd  vmovaps xmm13, [rsp+0xC0]
00007d55df7db7d6  vmovaps xmm14, [rsp+0xD0]
00007d55df7db7df  vmovaps xmm15, [rsp+0xE0]
00007d55df7db7e8  add rsp, 0xF0
00007d55df7db7ef  pop r11
00007d55df7db7f1  pop r10
00007d55df7db7f3  pop r9
00007d55df7db7f5  pop r8
00007d55df7db7f7  pop rsi
00007d55df7db7f8  pop rdi
00007d55df7db7f9  pop rdx
00007d55df7db7fa  pop rcx
00007d55df7db7fb  pop rax
00007d55df7db7fc  add rsp, 0x08
00007d55df7db800  jmp 0x00007D55DF7D91D7
00007d55df7db805  call 0x00007D55DF6D64F0
00007d55df7db80a  jmp 0x00007D55DF7D91E4
00007d55df7db80f  sub rsp, 0x08
00007d55df7db813  push rax
00007d55df7db814  push rcx
00007d55df7db815  push rdx
00007d55df7db816  push rdi
00007d55df7db817  push rsi
00007d55df7db818  push r8
00007d55df7db81a  push r9
00007d55df7db81c  push r10
00007d55df7db81e  push r11
00007d55df7db820  sub rsp, 0xF0
00007d55df7db827  vmovaps [rsp], xmm0
00007d55df7db82c  vmovaps [rsp+0x10], xmm1
00007d55df7db832  vmovaps [rsp+0x20], xmm2
00007d55df7db838  vmovaps [rsp+0x30], xmm3
00007d55df7db83e  vmovaps [rsp+0x40], xmm4
00007d55df7db844  vmovaps [rsp+0x50], xmm5
00007d55df7db84a  vmovaps [rsp+0x60], xmm6
00007d55df7db850  vmovaps [rsp+0x70], xmm7
00007d55df7db856  vmovaps [rsp+0x80], xmm8
00007d55df7db85f  vmovaps [rsp+0x90], xmm9
00007d55df7db868  vmovaps [rsp+0xA0], xmm10
00007d55df7db871  vmovaps [rsp+0xB0], xmm11
00007d55df7db87a  vmovaps [rsp+0xC0], xmm12
00007d55df7db883  vmovaps [rsp+0xD0], xmm13
00007d55df7db88c  vmovaps [rsp+0xE0], xmm14
00007d55df7db895  sub rsp, 0x30
00007d55df7db899  movaps [rsp], xmm15
00007d55df7db89e  movaps [rsp+0x10], xmm3
00007d55df7db8a3  movaps [rsp+0x20], xmm7
00007d55df7db8a8  lea rdi, [rsp]
00007d55df7db8ac  mov esi, 0x00
00007d55df7db8b1  mov rax, 0x5BB8433D8530
00007d55df7db8bb  call rax
00007d55df7db8bd  movaps xmm15, [rsp]
00007d55df7db8c2  add rsp, 0x30
00007d55df7db8c6  vmovaps xmm0, [rsp]
00007d55df7db8cb  vmovaps xmm1, [rsp+0x10]
00007d55df7db8d1  vmovaps xmm2, [rsp+0x20]
00007d55df7db8d7  vmovaps xmm3, [rsp+0x30]
00007d55df7db8dd  vmovaps xmm4, [rsp+0x40]
00007d55df7db8e3  vmovaps xmm5, [rsp+0x50]
00007d55df7db8e9  vmovaps xmm6, [rsp+0x60]
00007d55df7db8ef  vmovaps xmm7, [rsp+0x70]
00007d55df7db8f5  vmovaps xmm8, [rsp+0x80]
00007d55df7db8fe  vmovaps xmm9, [rsp+0x90]
00007d55df7db907  vmovaps xmm10, [rsp+0xA0]
00007d55df7db910  vmovaps xmm11, [rsp+0xB0]
00007d55df7db919  vmovaps xmm12, [rsp+0xC0]
00007d55df7db922  vmovaps xmm13, [rsp+0xD0]
00007d55df7db92b  vmovaps xmm14, [rsp+0xE0]
00007d55df7db934  add rsp, 0xF0
00007d55df7db93b  pop r11
00007d55df7db93d  pop r10
00007d55df7db93f  pop r9
00007d55df7db941  pop r8
00007d55df7db943  pop rsi
00007d55df7db944  pop rdi
00007d55df7db945  pop rdx
00007d55df7db946  pop rcx
00007d55df7db947  pop rax
00007d55df7db948  add rsp, 0x08
00007d55df7db94c  jmp 0x00007D55DF7D9210
00007d55df7db951  sub rsp, 0x08
00007d55df7db955  push rax
00007d55df7db956  push rcx
00007d55df7db957  push rdx
00007d55df7db958  push rdi
00007d55df7db959  push rsi
00007d55df7db95a  push r8
00007d55df7db95c  push r9
00007d55df7db95e  push r10
00007d55df7db960  push r11
00007d55df7db962  sub rsp, 0xF0
00007d55df7db969  vmovaps [rsp], xmm0
00007d55df7db96e  vmovaps [rsp+0x10], xmm1
00007d55df7db974  vmovaps [rsp+0x20], xmm2
00007d55df7db97a  vmovaps [rsp+0x30], xmm4
00007d55df7db980  vmovaps [rsp+0x40], xmm5
00007d55df7db986  vmovaps [rsp+0x50], xmm6
00007d55df7db98c  vmovaps [rsp+0x60], xmm7
00007d55df7db992  vmovaps [rsp+0x70], xmm8
00007d55df7db998  vmovaps [rsp+0x80], xmm9
00007d55df7db9a1  vmovaps [rsp+0x90], xmm10
00007d55df7db9aa  vmovaps [rsp+0xA0], xmm11
00007d55df7db9b3  vmovaps [rsp+0xB0], xmm12
00007d55df7db9bc  vmovaps [rsp+0xC0], xmm13
00007d55df7db9c5  vmovaps [rsp+0xD0], xmm14
00007d55df7db9ce  vmovaps [rsp+0xE0], xmm15
00007d55df7db9d7  sub rsp, 0x30
00007d55df7db9db  movaps [rsp], xmm3
00007d55df7db9df  movaps [rsp+0x10], xmm1
00007d55df7db9e4  movaps [rsp+0x20], xmm15
00007d55df7db9ea  lea rdi, [rsp]
00007d55df7db9ee  mov esi, 0x00
00007d55df7db9f3  mov rax, 0x5BB8433D8530
00007d55df7db9fd  call rax
00007d55df7db9ff  movaps xmm3, [rsp]
00007d55df7dba03  add rsp, 0x30
00007d55df7dba07  vmovaps xmm0, [rsp]
00007d55df7dba0c  vmovaps xmm1, [rsp+0x10]
00007d55df7dba12  vmovaps xmm2, [rsp+0x20]
00007d55df7dba18  vmovaps xmm4, [rsp+0x30]
00007d55df7dba1e  vmovaps xmm5, [rsp+0x40]
00007d55df7dba24  vmovaps xmm6, [rsp+0x50]
00007d55df7dba2a  vmovaps xmm7, [rsp+0x60]
00007d55df7dba30  vmovaps xmm8, [rsp+0x70]
00007d55df7dba36  vmovaps xmm9, [rsp+0x80]
00007d55df7dba3f  vmovaps xmm10, [rsp+0x90]
00007d55df7dba48  vmovaps xmm11, [rsp+0xA0]
00007d55df7dba51  vmovaps xmm12, [rsp+0xB0]
00007d55df7dba5a  vmovaps xmm13, [rsp+0xC0]
00007d55df7dba63  vmovaps xmm14, [rsp+0xD0]
00007d55df7dba6c  vmovaps xmm15, [rsp+0xE0]
00007d55df7dba75  add rsp, 0xF0
00007d55df7dba7c  pop r11
00007d55df7dba7e  pop r10
00007d55df7dba80  pop r9
00007d55df7dba82  pop r8
00007d55df7dba84  pop rsi
00007d55df7dba85  pop rdi
00007d55df7dba86  pop rdx
00007d55df7dba87  pop rcx
00007d55df7dba88  pop rax
00007d55df7dba89  add rsp, 0x08
00007d55df7dba8d  jmp 0x00007D55DF7D929F
00007d55df7dba92  call 0x00007D55DF6D64F0
00007d55df7dba97  jmp 0x00007D55DF7D92A9
00007d55df7dba9c  sub rsp, 0x08
00007d55df7dbaa0  push rax
00007d55df7dbaa1  push rcx
00007d55df7dbaa2  push rdx
00007d55df7dbaa3  push rdi
00007d55df7dbaa4  push rsi
00007d55df7dbaa5  push r8
00007d55df7dbaa7  push r9
00007d55df7dbaa9  push r10
00007d55df7dbaab  push r11
00007d55df7dbaad  sub rsp, 0xF0
00007d55df7dbab4  vmovaps [rsp], xmm0
00007d55df7dbab9  vmovaps [rsp+0x10], xmm1
00007d55df7dbabf  vmovaps [rsp+0x20], xmm2
00007d55df7dbac5  vmovaps [rsp+0x30], xmm3
00007d55df7dbacb  vmovaps [rsp+0x40], xmm4
00007d55df7dbad1  vmovaps [rsp+0x50], xmm5
00007d55df7dbad7  vmovaps [rsp+0x60], xmm6
00007d55df7dbadd  vmovaps [rsp+0x70], xmm7
00007d55df7dbae3  vmovaps [rsp+0x80], xmm8
00007d55df7dbaec  vmovaps [rsp+0x90], xmm9
00007d55df7dbaf5  vmovaps [rsp+0xA0], xmm10
00007d55df7dbafe  vmovaps [rsp+0xB0], xmm11
00007d55df7dbb07  vmovaps [rsp+0xC0], xmm12
00007d55df7dbb10  vmovaps [rsp+0xD0], xmm13
00007d55df7dbb19  vmovaps [rsp+0xE0], xmm14
00007d55df7dbb22  sub rsp, 0x30
00007d55df7dbb26  movaps [rsp], xmm15
00007d55df7dbb2b  movaps [rsp+0x10], xmm14
00007d55df7dbb31  movaps [rsp+0x20], xmm4
00007d55df7dbb36  lea rdi, [rsp]
00007d55df7dbb3a  mov esi, 0x00
00007d55df7dbb3f  mov rax, 0x5BB8433D8530
00007d55df7dbb49  call rax
00007d55df7dbb4b  movaps xmm15, [rsp]
00007d55df7dbb50  add rsp, 0x30
00007d55df7dbb54  vmovaps xmm0, [rsp]
00007d55df7dbb59  vmovaps xmm1, [rsp+0x10]
00007d55df7dbb5f  vmovaps xmm2, [rsp+0x20]
00007d55df7dbb65  vmovaps xmm3, [rsp+0x30]
00007d55df7dbb6b  vmovaps xmm4, [rsp+0x40]
00007d55df7dbb71  vmovaps xmm5, [rsp+0x50]
00007d55df7dbb77  vmovaps xmm6, [rsp+0x60]
00007d55df7dbb7d  vmovaps xmm7, [rsp+0x70]
00007d55df7dbb83  vmovaps xmm8, [rsp+0x80]
00007d55df7dbb8c  vmovaps xmm9, [rsp+0x90]
00007d55df7dbb95  vmovaps xmm10, [rsp+0xA0]
00007d55df7dbb9e  vmovaps xmm11, [rsp+0xB0]
00007d55df7dbba7  vmovaps xmm12, [rsp+0xC0]
00007d55df7dbbb0  vmovaps xmm13, [rsp+0xD0]
00007d55df7dbbb9  vmovaps xmm14, [rsp+0xE0]
00007d55df7dbbc2  add rsp, 0xF0
00007d55df7dbbc9  pop r11
00007d55df7dbbcb  pop r10
00007d55df7dbbcd  pop r9
00007d55df7dbbcf  pop r8
00007d55df7dbbd1  pop rsi
00007d55df7dbbd2  pop rdi
00007d55df7dbbd3  pop rdx
00007d55df7dbbd4  pop rcx
00007d55df7dbbd5  pop rax
00007d55df7dbbd6  add rsp, 0x08
00007d55df7dbbda  jmp 0x00007D55DF7D92D7
00007d55df7dbbdf  sub rsp, 0x08
00007d55df7dbbe3  push rax
00007d55df7dbbe4  push rcx
00007d55df7dbbe5  push rdx
00007d55df7dbbe6  push rdi
00007d55df7dbbe7  push rsi
00007d55df7dbbe8  push r8
00007d55df7dbbea  push r9
00007d55df7dbbec  push r10
00007d55df7dbbee  push r11
00007d55df7dbbf0  sub rsp, 0xF0
00007d55df7dbbf7  vmovaps [rsp], xmm0
00007d55df7dbbfc  vmovaps [rsp+0x10], xmm1
00007d55df7dbc02  vmovaps [rsp+0x20], xmm2
00007d55df7dbc08  vmovaps [rsp+0x30], xmm3
00007d55df7dbc0e  vmovaps [rsp+0x40], xmm4
00007d55df7dbc14  vmovaps [rsp+0x50], xmm5
00007d55df7dbc1a  vmovaps [rsp+0x60], xmm6
00007d55df7dbc20  vmovaps [rsp+0x70], xmm7
00007d55df7dbc26  vmovaps [rsp+0x80], xmm8
00007d55df7dbc2f  vmovaps [rsp+0x90], xmm9
00007d55df7dbc38  vmovaps [rsp+0xA0], xmm10
00007d55df7dbc41  vmovaps [rsp+0xB0], xmm11
00007d55df7dbc4a  vmovaps [rsp+0xC0], xmm12
00007d55df7dbc53  vmovaps [rsp+0xD0], xmm13
00007d55df7dbc5c  vmovaps [rsp+0xE0], xmm15
00007d55df7dbc65  sub rsp, 0x30
00007d55df7dbc69  movaps [rsp], xmm14
00007d55df7dbc6e  movaps [rsp+0x10], xmm2
00007d55df7dbc73  movaps [rsp+0x20], xmm1
00007d55df7dbc78  lea rdi, [rsp]
00007d55df7dbc7c  mov esi, 0x00
00007d55df7dbc81  mov rax, 0x5BB8433D8530
00007d55df7dbc8b  call rax
00007d55df7dbc8d  movaps xmm14, [rsp]
00007d55df7dbc92  add rsp, 0x30
00007d55df7dbc96  vmovaps xmm0, [rsp]
00007d55df7dbc9b  vmovaps xmm1, [rsp+0x10]
00007d55df7dbca1  vmovaps xmm2, [rsp+0x20]
00007d55df7dbca7  vmovaps xmm3, [rsp+0x30]
00007d55df7dbcad  vmovaps xmm4, [rsp+0x40]
00007d55df7dbcb3  vmovaps xmm5, [rsp+0x50]
00007d55df7dbcb9  vmovaps xmm6, [rsp+0x60]
00007d55df7dbcbf  vmovaps xmm7, [rsp+0x70]
00007d55df7dbcc5  vmovaps xmm8, [rsp+0x80]
00007d55df7dbcce  vmovaps xmm9, [rsp+0x90]
00007d55df7dbcd7  vmovaps xmm10, [rsp+0xA0]
00007d55df7dbce0  vmovaps xmm11, [rsp+0xB0]
00007d55df7dbce9  vmovaps xmm12, [rsp+0xC0]
00007d55df7dbcf2  vmovaps xmm13, [rsp+0xD0]
00007d55df7dbcfb  vmovaps xmm15, [rsp+0xE0]
00007d55df7dbd04  add rsp, 0xF0
00007d55df7dbd0b  pop r11
00007d55df7dbd0d  pop r10
00007d55df7dbd0f  pop r9
00007d55df7dbd11  pop r8
00007d55df7dbd13  pop rsi
00007d55df7dbd14  pop rdi
00007d55df7dbd15  pop rdx
00007d55df7dbd16  pop rcx
00007d55df7dbd17  pop rax
00007d55df7dbd18  add rsp, 0x08
00007d55df7dbd1c  jmp 0x00007D55DF7D92FD
00007d55df7dbd21  sub rsp, 0x08
00007d55df7dbd25  push rax
00007d55df7dbd26  push rcx
00007d55df7dbd27  push rdx
00007d55df7dbd28  push rdi
00007d55df7dbd29  push rsi
00007d55df7dbd2a  push r8
00007d55df7dbd2c  push r9
00007d55df7dbd2e  push r10
00007d55df7dbd30  push r11
00007d55df7dbd32  sub rsp, 0xF0
00007d55df7dbd39  vmovaps [rsp], xmm0
00007d55df7dbd3e  vmovaps [rsp+0x10], xmm2
00007d55df7dbd44  vmovaps [rsp+0x20], xmm3
00007d55df7dbd4a  vmovaps [rsp+0x30], xmm4
00007d55df7dbd50  vmovaps [rsp+0x40], xmm5
00007d55df7dbd56  vmovaps [rsp+0x50], xmm6
00007d55df7dbd5c  vmovaps [rsp+0x60], xmm7
00007d55df7dbd62  vmovaps [rsp+0x70], xmm8
00007d55df7dbd68  vmovaps [rsp+0x80], xmm9
00007d55df7dbd71  vmovaps [rsp+0x90], xmm10
00007d55df7dbd7a  vmovaps [rsp+0xA0], xmm11
00007d55df7dbd83  vmovaps [rsp+0xB0], xmm12
00007d55df7dbd8c  vmovaps [rsp+0xC0], xmm13
00007d55df7dbd95  vmovaps [rsp+0xD0], xmm14
00007d55df7dbd9e  vmovaps [rsp+0xE0], xmm15
00007d55df7dbda7  sub rsp, 0x30
00007d55df7dbdab  movaps [rsp], xmm1
00007d55df7dbdaf  movaps [rsp+0x10], xmm4
00007d55df7dbdb4  movaps [rsp+0x20], xmm9
00007d55df7dbdba  lea rdi, [rsp]
00007d55df7dbdbe  mov esi, 0x00
00007d55df7dbdc3  mov rax, 0x5BB8433D8530
00007d55df7dbdcd  call rax
00007d55df7dbdcf  movaps xmm1, [rsp]
00007d55df7dbdd3  add rsp, 0x30
00007d55df7dbdd7  vmovaps xmm0, [rsp]
00007d55df7dbddc  vmovaps xmm2, [rsp+0x10]
00007d55df7dbde2  vmovaps xmm3, [rsp+0x20]
00007d55df7dbde8  vmovaps xmm4, [rsp+0x30]
00007d55df7dbdee  vmovaps xmm5, [rsp+0x40]
00007d55df7dbdf4  vmovaps xmm6, [rsp+0x50]
00007d55df7dbdfa  vmovaps xmm7, [rsp+0x60]
00007d55df7dbe00  vmovaps xmm8, [rsp+0x70]
00007d55df7dbe06  vmovaps xmm9, [rsp+0x80]
00007d55df7dbe0f  vmovaps xmm10, [rsp+0x90]
00007d55df7dbe18  vmovaps xmm11, [rsp+0xA0]
00007d55df7dbe21  vmovaps xmm12, [rsp+0xB0]
00007d55df7dbe2a  vmovaps xmm13, [rsp+0xC0]
00007d55df7dbe33  vmovaps xmm14, [rsp+0xD0]
00007d55df7dbe3c  vmovaps xmm15, [rsp+0xE0]
00007d55df7dbe45  add rsp, 0xF0
00007d55df7dbe4c  pop r11
00007d55df7dbe4e  pop r10
00007d55df7dbe50  pop r9
00007d55df7dbe52  pop r8
00007d55df7dbe54  pop rsi
00007d55df7dbe55  pop rdi
00007d55df7dbe56  pop rdx
00007d55df7dbe57  pop rcx
00007d55df7dbe58  pop rax
00007d55df7dbe59  add rsp, 0x08
00007d55df7dbe5d  jmp 0x00007D55DF7D931B
00007d55df7dbe62  sub rsp, 0x08
00007d55df7dbe66  push rax
00007d55df7dbe67  push rcx
00007d55df7dbe68  push rdx
00007d55df7dbe69  push rdi
00007d55df7dbe6a  push rsi
00007d55df7dbe6b  push r8
00007d55df7dbe6d  push r9
00007d55df7dbe6f  push r10
00007d55df7dbe71  push r11
00007d55df7dbe73  sub rsp, 0xF0
00007d55df7dbe7a  vmovaps [rsp], xmm0
00007d55df7dbe7f  vmovaps [rsp+0x10], xmm1
00007d55df7dbe85  vmovaps [rsp+0x20], xmm2
00007d55df7dbe8b  vmovaps [rsp+0x30], xmm3
00007d55df7dbe91  vmovaps [rsp+0x40], xmm5
00007d55df7dbe97  vmovaps [rsp+0x50], xmm6
00007d55df7dbe9d  vmovaps [rsp+0x60], xmm7
00007d55df7dbea3  vmovaps [rsp+0x70], xmm8
00007d55df7dbea9  vmovaps [rsp+0x80], xmm9
00007d55df7dbeb2  vmovaps [rsp+0x90], xmm10
00007d55df7dbebb  vmovaps [rsp+0xA0], xmm11
00007d55df7dbec4  vmovaps [rsp+0xB0], xmm12
00007d55df7dbecd  vmovaps [rsp+0xC0], xmm13
00007d55df7dbed6  vmovaps [rsp+0xD0], xmm14
00007d55df7dbedf  vmovaps [rsp+0xE0], xmm15
00007d55df7dbee8  sub rsp, 0x30
00007d55df7dbeec  movaps [rsp], xmm4
00007d55df7dbef0  movaps [rsp+0x10], xmm2
00007d55df7dbef5  movaps [rsp+0x20], xmm9
00007d55df7dbefb  lea rdi, [rsp]
00007d55df7dbeff  mov esi, 0x00
00007d55df7dbf04  mov rax, 0x5BB8433D8530
00007d55df7dbf0e  call rax
00007d55df7dbf10  movaps xmm4, [rsp]
00007d55df7dbf14  add rsp, 0x30
00007d55df7dbf18  vmovaps xmm0, [rsp]
00007d55df7dbf1d  vmovaps xmm1, [rsp+0x10]
00007d55df7dbf23  vmovaps xmm2, [rsp+0x20]
00007d55df7dbf29  vmovaps xmm3, [rsp+0x30]
00007d55df7dbf2f  vmovaps xmm5, [rsp+0x40]
00007d55df7dbf35  vmovaps xmm6, [rsp+0x50]
00007d55df7dbf3b  vmovaps xmm7, [rsp+0x60]
00007d55df7dbf41  vmovaps xmm8, [rsp+0x70]
00007d55df7dbf47  vmovaps xmm9, [rsp+0x80]
00007d55df7dbf50  vmovaps xmm10, [rsp+0x90]
00007d55df7dbf59  vmovaps xmm11, [rsp+0xA0]
00007d55df7dbf62  vmovaps xmm12, [rsp+0xB0]
00007d55df7dbf6b  vmovaps xmm13, [rsp+0xC0]
00007d55df7dbf74  vmovaps xmm14, [rsp+0xD0]
00007d55df7dbf7d  vmovaps xmm15, [rsp+0xE0]
00007d55df7dbf86  add rsp, 0xF0
00007d55df7dbf8d  pop r11
00007d55df7dbf8f  pop r10
00007d55df7dbf91  pop r9
00007d55df7dbf93  pop r8
00007d55df7dbf95  pop rsi
00007d55df7dbf96  pop rdi
00007d55df7dbf97  pop rdx
00007d55df7dbf98  pop rcx
00007d55df7dbf99  pop rax
00007d55df7dbf9a  add rsp, 0x08
00007d55df7dbf9e  jmp 0x00007D55DF7D934B
00007d55df7dbfa3  sub rsp, 0x08
00007d55df7dbfa7  push rax
00007d55df7dbfa8  push rcx
00007d55df7dbfa9  push rdx
00007d55df7dbfaa  push rdi
00007d55df7dbfab  push rsi
00007d55df7dbfac  push r8
00007d55df7dbfae  push r9
00007d55df7dbfb0  push r10
00007d55df7dbfb2  push r11
00007d55df7dbfb4  sub rsp, 0xF0
00007d55df7dbfbb  vmovaps [rsp], xmm0
00007d55df7dbfc0  vmovaps [rsp+0x10], xmm1
00007d55df7dbfc6  vmovaps [rsp+0x20], xmm2
00007d55df7dbfcc  vmovaps [rsp+0x30], xmm3
00007d55df7dbfd2  vmovaps [rsp+0x40], xmm4
00007d55df7dbfd8  vmovaps [rsp+0x50], xmm5
00007d55df7dbfde  vmovaps [rsp+0x60], xmm6
00007d55df7dbfe4  vmovaps [rsp+0x70], xmm7
00007d55df7dbfea  vmovaps [rsp+0x80], xmm8
00007d55df7dbff3  vmovaps [rsp+0x90], xmm10
00007d55df7dbffc  vmovaps [rsp+0xA0], xmm11
00007d55df7dc005  vmovaps [rsp+0xB0], xmm12
00007d55df7dc00e  vmovaps [rsp+0xC0], xmm13
00007d55df7dc017  vmovaps [rsp+0xD0], xmm14
00007d55df7dc020  vmovaps [rsp+0xE0], xmm15
00007d55df7dc029  sub rsp, 0x30
00007d55df7dc02d  movaps [rsp], xmm9
00007d55df7dc032  movaps [rsp+0x10], xmm2
00007d55df7dc037  movaps [rsp+0x20], xmm1
00007d55df7dc03c  lea rdi, [rsp]
00007d55df7dc040  mov esi, 0x00
00007d55df7dc045  mov rax, 0x5BB8433D8530
00007d55df7dc04f  call rax
00007d55df7dc051  movaps xmm9, [rsp]
00007d55df7dc056  add rsp, 0x30
00007d55df7dc05a  vmovaps xmm0, [rsp]
00007d55df7dc05f  vmovaps xmm1, [rsp+0x10]
00007d55df7dc065  vmovaps xmm2, [rsp+0x20]
00007d55df7dc06b  vmovaps xmm3, [rsp+0x30]
00007d55df7dc071  vmovaps xmm4, [rsp+0x40]
00007d55df7dc077  vmovaps xmm5, [rsp+0x50]
00007d55df7dc07d  vmovaps xmm6, [rsp+0x60]
00007d55df7dc083  vmovaps xmm7, [rsp+0x70]
00007d55df7dc089  vmovaps xmm8, [rsp+0x80]
00007d55df7dc092  vmovaps xmm10, [rsp+0x90]
00007d55df7dc09b  vmovaps xmm11, [rsp+0xA0]
00007d55df7dc0a4  vmovaps xmm12, [rsp+0xB0]
00007d55df7dc0ad  vmovaps xmm13, [rsp+0xC0]
00007d55df7dc0b6  vmovaps xmm14, [rsp+0xD0]
00007d55df7dc0bf  vmovaps xmm15, [rsp+0xE0]
00007d55df7dc0c8  add rsp, 0xF0
00007d55df7dc0cf  pop r11
00007d55df7dc0d1  pop r10
00007d55df7dc0d3  pop r9
00007d55df7dc0d5  pop r8
00007d55df7dc0d7  pop rsi
00007d55df7dc0d8  pop rdi
00007d55df7dc0d9  pop rdx
00007d55df7dc0da  pop rcx
00007d55df7dc0db  pop rax
00007d55df7dc0dc  add rsp, 0x08
00007d55df7dc0e0  jmp 0x00007D55DF7D9381
00007d55df7dc0e5  sub rsp, 0x08
00007d55df7dc0e9  push rax
00007d55df7dc0ea  push rcx
00007d55df7dc0eb  push rdx
00007d55df7dc0ec  push rdi
00007d55df7dc0ed  push rsi
00007d55df7dc0ee  push r8
00007d55df7dc0f0  push r9
00007d55df7dc0f2  push r10
00007d55df7dc0f4  push r11
00007d55df7dc0f6  sub rsp, 0xF0
00007d55df7dc0fd  vmovaps [rsp], xmm0
00007d55df7dc102  vmovaps [rsp+0x10], xmm2
00007d55df7dc108  vmovaps [rsp+0x20], xmm3
00007d55df7dc10e  vmovaps [rsp+0x30], xmm4
00007d55df7dc114  vmovaps [rsp+0x40], xmm5
00007d55df7dc11a  vmovaps [rsp+0x50], xmm6
00007d55df7dc120  vmovaps [rsp+0x60], xmm7
00007d55df7dc126  vmovaps [rsp+0x70], xmm8
00007d55df7dc12c  vmovaps [rsp+0x80], xmm9
00007d55df7dc135  vmovaps [rsp+0x90], xmm10
00007d55df7dc13e  vmovaps [rsp+0xA0], xmm11
00007d55df7dc147  vmovaps [rsp+0xB0], xmm12
00007d55df7dc150  vmovaps [rsp+0xC0], xmm13
00007d55df7dc159  vmovaps [rsp+0xD0], xmm14
00007d55df7dc162  vmovaps [rsp+0xE0], xmm15
00007d55df7dc16b  sub rsp, 0x30
00007d55df7dc16f  movaps [rsp], xmm1
00007d55df7dc173  movaps [rsp+0x10], xmm15
00007d55df7dc179  movaps [rsp+0x20], xmm6
00007d55df7dc17e  lea rdi, [rsp]
00007d55df7dc182  mov esi, 0x00
00007d55df7dc187  mov rax, 0x5BB8433D8530
00007d55df7dc191  call rax
00007d55df7dc193  movaps xmm1, [rsp]
00007d55df7dc197  add rsp, 0x30
00007d55df7dc19b  vmovaps xmm0, [rsp]
00007d55df7dc1a0  vmovaps xmm2, [rsp+0x10]
00007d55df7dc1a6  vmovaps xmm3, [rsp+0x20]
00007d55df7dc1ac  vmovaps xmm4, [rsp+0x30]
00007d55df7dc1b2  vmovaps xmm5, [rsp+0x40]
00007d55df7dc1b8  vmovaps xmm6, [rsp+0x50]
00007d55df7dc1be  vmovaps xmm7, [rsp+0x60]
00007d55df7dc1c4  vmovaps xmm8, [rsp+0x70]
00007d55df7dc1ca  vmovaps xmm9, [rsp+0x80]
00007d55df7dc1d3  vmovaps xmm10, [rsp+0x90]
00007d55df7dc1dc  vmovaps xmm11, [rsp+0xA0]
00007d55df7dc1e5  vmovaps xmm12, [rsp+0xB0]
00007d55df7dc1ee  vmovaps xmm13, [rsp+0xC0]
00007d55df7dc1f7  vmovaps xmm14, [rsp+0xD0]
00007d55df7dc200  vmovaps xmm15, [rsp+0xE0]
00007d55df7dc209  add rsp, 0xF0
00007d55df7dc210  pop r11
00007d55df7dc212  pop r10
00007d55df7dc214  pop r9
00007d55df7dc216  pop r8
00007d55df7dc218  pop rsi
00007d55df7dc219  pop rdi
00007d55df7dc21a  pop rdx
00007d55df7dc21b  pop rcx
00007d55df7dc21c  pop rax
00007d55df7dc21d  add rsp, 0x08
00007d55df7dc221  jmp 0x00007D55DF7D93A2
00007d55df7dc226  sub rsp, 0x08
00007d55df7dc22a  push rax
00007d55df7dc22b  push rcx
00007d55df7dc22c  push rdx
00007d55df7dc22d  push rdi
00007d55df7dc22e  push rsi
00007d55df7dc22f  push r8
00007d55df7dc231  push r9
00007d55df7dc233  push r10
00007d55df7dc235  push r11
00007d55df7dc237  sub rsp, 0xF0
00007d55df7dc23e  vmovaps [rsp], xmm0
00007d55df7dc243  vmovaps [rsp+0x10], xmm1
00007d55df7dc249  vmovaps [rsp+0x20], xmm2
00007d55df7dc24f  vmovaps [rsp+0x30], xmm3
00007d55df7dc255  vmovaps [rsp+0x40], xmm4
00007d55df7dc25b  vmovaps [rsp+0x50], xmm5
00007d55df7dc261  vmovaps [rsp+0x60], xmm6
00007d55df7dc267  vmovaps [rsp+0x70], xmm7
00007d55df7dc26d  vmovaps [rsp+0x80], xmm8
00007d55df7dc276  vmovaps [rsp+0x90], xmm9
00007d55df7dc27f  vmovaps [rsp+0xA0], xmm10
00007d55df7dc288  vmovaps [rsp+0xB0], xmm11
00007d55df7dc291  vmovaps [rsp+0xC0], xmm12
00007d55df7dc29a  vmovaps [rsp+0xD0], xmm13
00007d55df7dc2a3  vmovaps [rsp+0xE0], xmm14
00007d55df7dc2ac  sub rsp, 0x30
00007d55df7dc2b0  movaps [rsp], xmm15
00007d55df7dc2b5  movaps [rsp+0x10], xmm5
00007d55df7dc2ba  movaps [rsp+0x20], xmm3
00007d55df7dc2bf  lea rdi, [rsp]
00007d55df7dc2c3  mov esi, 0x00
00007d55df7dc2c8  mov rax, 0x5BB8433D8530
00007d55df7dc2d2  call rax
00007d55df7dc2d4  movaps xmm15, [rsp]
00007d55df7dc2d9  add rsp, 0x30
00007d55df7dc2dd  vmovaps xmm0, [rsp]
00007d55df7dc2e2  vmovaps xmm1, [rsp+0x10]
00007d55df7dc2e8  vmovaps xmm2, [rsp+0x20]
00007d55df7dc2ee  vmovaps xmm3, [rsp+0x30]
00007d55df7dc2f4  vmovaps xmm4, [rsp+0x40]
00007d55df7dc2fa  vmovaps xmm5, [rsp+0x50]
00007d55df7dc300  vmovaps xmm6, [rsp+0x60]
00007d55df7dc306  vmovaps xmm7, [rsp+0x70]
00007d55df7dc30c  vmovaps xmm8, [rsp+0x80]
00007d55df7dc315  vmovaps xmm9, [rsp+0x90]
00007d55df7dc31e  vmovaps xmm10, [rsp+0xA0]
00007d55df7dc327  vmovaps xmm11, [rsp+0xB0]
00007d55df7dc330  vmovaps xmm12, [rsp+0xC0]
00007d55df7dc339  vmovaps xmm13, [rsp+0xD0]
00007d55df7dc342  vmovaps xmm14, [rsp+0xE0]
00007d55df7dc34b  add rsp, 0xF0
00007d55df7dc352  pop r11
00007d55df7dc354  pop r10
00007d55df7dc356  pop r9
00007d55df7dc358  pop r8
00007d55df7dc35a  pop rsi
00007d55df7dc35b  pop rdi
00007d55df7dc35c  pop rdx
00007d55df7dc35d  pop rcx
00007d55df7dc35e  pop rax
00007d55df7dc35f  add rsp, 0x08
00007d55df7dc363  jmp 0x00007D55DF7D93BC
00007d55df7dc368  sub rsp, 0x08
00007d55df7dc36c  push rax
00007d55df7dc36d  push rcx
00007d55df7dc36e  push rdx
00007d55df7dc36f  push rdi
00007d55df7dc370  push rsi
00007d55df7dc371  push r8
00007d55df7dc373  push r9
00007d55df7dc375  push r10
00007d55df7dc377  push r11
00007d55df7dc379  sub rsp, 0xF0
00007d55df7dc380  vmovaps [rsp], xmm0
00007d55df7dc385  vmovaps [rsp+0x10], xmm1
00007d55df7dc38b  vmovaps [rsp+0x20], xmm2
00007d55df7dc391  vmovaps [rsp+0x30], xmm3
00007d55df7dc397  vmovaps [rsp+0x40], xmm4
00007d55df7dc39d  vmovaps [rsp+0x50], xmm6
00007d55df7dc3a3  vmovaps [rsp+0x60], xmm7
00007d55df7dc3a9  vmovaps [rsp+0x70], xmm8
00007d55df7dc3af  vmovaps [rsp+0x80], xmm9
00007d55df7dc3b8  vmovaps [rsp+0x90], xmm10
00007d55df7dc3c1  vmovaps [rsp+0xA0], xmm11
00007d55df7dc3ca  vmovaps [rsp+0xB0], xmm12
00007d55df7dc3d3  vmovaps [rsp+0xC0], xmm13
00007d55df7dc3dc  vmovaps [rsp+0xD0], xmm14
00007d55df7dc3e5  vmovaps [rsp+0xE0], xmm15
00007d55df7dc3ee  sub rsp, 0x30
00007d55df7dc3f2  movaps [rsp], xmm5
00007d55df7dc3f6  movaps [rsp+0x10], xmm8
00007d55df7dc3fc  movaps [rsp+0x20], xmm6
00007d55df7dc401  lea rdi, [rsp]
00007d55df7dc405  mov esi, 0x00
00007d55df7dc40a  mov rax, 0x5BB8433D8530
00007d55df7dc414  call rax
00007d55df7dc416  movaps xmm5, [rsp]
00007d55df7dc41a  add rsp, 0x30
00007d55df7dc41e  vmovaps xmm0, [rsp]
00007d55df7dc423  vmovaps xmm1, [rsp+0x10]
00007d55df7dc429  vmovaps xmm2, [rsp+0x20]
00007d55df7dc42f  vmovaps xmm3, [rsp+0x30]
00007d55df7dc435  vmovaps xmm4, [rsp+0x40]
00007d55df7dc43b  vmovaps xmm6, [rsp+0x50]
00007d55df7dc441  vmovaps xmm7, [rsp+0x60]
00007d55df7dc447  vmovaps xmm8, [rsp+0x70]
00007d55df7dc44d  vmovaps xmm9, [rsp+0x80]
00007d55df7dc456  vmovaps xmm10, [rsp+0x90]
00007d55df7dc45f  vmovaps xmm11, [rsp+0xA0]
00007d55df7dc468  vmovaps xmm12, [rsp+0xB0]
00007d55df7dc471  vmovaps xmm13, [rsp+0xC0]
00007d55df7dc47a  vmovaps xmm14, [rsp+0xD0]
00007d55df7dc483  vmovaps xmm15, [rsp+0xE0]
00007d55df7dc48c  add rsp, 0xF0
00007d55df7dc493  pop r11
00007d55df7dc495  pop r10
00007d55df7dc497  pop r9
00007d55df7dc499  pop r8
00007d55df7dc49b  pop rsi
00007d55df7dc49c  pop rdi
00007d55df7dc49d  pop rdx
00007d55df7dc49e  pop rcx
00007d55df7dc49f  pop rax
00007d55df7dc4a0  add rsp, 0x08
00007d55df7dc4a4  jmp 0x00007D55DF7D93E0
00007d55df7dc4a9  sub rsp, 0x08
00007d55df7dc4ad  push rax
00007d55df7dc4ae  push rcx
00007d55df7dc4af  push rdx
00007d55df7dc4b0  push rdi
00007d55df7dc4b1  push rsi
00007d55df7dc4b2  push r8
00007d55df7dc4b4  push r9
00007d55df7dc4b6  push r10
00007d55df7dc4b8  push r11
00007d55df7dc4ba  sub rsp, 0xF0
00007d55df7dc4c1  vmovaps [rsp], xmm0
00007d55df7dc4c6  vmovaps [rsp+0x10], xmm1
00007d55df7dc4cc  vmovaps [rsp+0x20], xmm2
00007d55df7dc4d2  vmovaps [rsp+0x30], xmm3
00007d55df7dc4d8  vmovaps [rsp+0x40], xmm4
00007d55df7dc4de  vmovaps [rsp+0x50], xmm5
00007d55df7dc4e4  vmovaps [rsp+0x60], xmm7
00007d55df7dc4ea  vmovaps [rsp+0x70], xmm8
00007d55df7dc4f0  vmovaps [rsp+0x80], xmm9
00007d55df7dc4f9  vmovaps [rsp+0x90], xmm10
00007d55df7dc502  vmovaps [rsp+0xA0], xmm11
00007d55df7dc50b  vmovaps [rsp+0xB0], xmm12
00007d55df7dc514  vmovaps [rsp+0xC0], xmm13
00007d55df7dc51d  vmovaps [rsp+0xD0], xmm14
00007d55df7dc526  vmovaps [rsp+0xE0], xmm15
00007d55df7dc52f  sub rsp, 0x30
00007d55df7dc533  movaps [rsp], xmm6
00007d55df7dc537  movaps [rsp+0x10], xmm10
00007d55df7dc53d  movaps [rsp+0x20], xmm8
00007d55df7dc543  lea rdi, [rsp]
00007d55df7dc547  mov esi, 0x00
00007d55df7dc54c  mov rax, 0x5BB8433D8530
00007d55df7dc556  call rax
00007d55df7dc558  movaps xmm6, [rsp]
00007d55df7dc55c  add rsp, 0x30
00007d55df7dc560  vmovaps xmm0, [rsp]
00007d55df7dc565  vmovaps xmm1, [rsp+0x10]
00007d55df7dc56b  vmovaps xmm2, [rsp+0x20]
00007d55df7dc571  vmovaps xmm3, [rsp+0x30]
00007d55df7dc577  vmovaps xmm4, [rsp+0x40]
00007d55df7dc57d  vmovaps xmm5, [rsp+0x50]
00007d55df7dc583  vmovaps xmm7, [rsp+0x60]
00007d55df7dc589  vmovaps xmm8, [rsp+0x70]
00007d55df7dc58f  vmovaps xmm9, [rsp+0x80]
00007d55df7dc598  vmovaps xmm10, [rsp+0x90]
00007d55df7dc5a1  vmovaps xmm11, [rsp+0xA0]
00007d55df7dc5aa  vmovaps xmm12, [rsp+0xB0]
00007d55df7dc5b3  vmovaps xmm13, [rsp+0xC0]
00007d55df7dc5bc  vmovaps xmm14, [rsp+0xD0]
00007d55df7dc5c5  vmovaps xmm15, [rsp+0xE0]
00007d55df7dc5ce  add rsp, 0xF0
00007d55df7dc5d5  pop r11
00007d55df7dc5d7  pop r10
00007d55df7dc5d9  pop r9
00007d55df7dc5db  pop r8
00007d55df7dc5dd  pop rsi
00007d55df7dc5de  pop rdi
00007d55df7dc5df  pop rdx
00007d55df7dc5e0  pop rcx
00007d55df7dc5e1  pop rax
00007d55df7dc5e2  add rsp, 0x08
00007d55df7dc5e6  jmp 0x00007D55DF7D9405
00007d55df7dc5eb  sub rsp, 0x08
00007d55df7dc5ef  push rax
00007d55df7dc5f0  push rcx
00007d55df7dc5f1  push rdx
00007d55df7dc5f2  push rdi
00007d55df7dc5f3  push rsi
00007d55df7dc5f4  push r8
00007d55df7dc5f6  push r9
00007d55df7dc5f8  push r10
00007d55df7dc5fa  push r11
00007d55df7dc5fc  sub rsp, 0xF0
00007d55df7dc603  vmovaps [rsp], xmm0
00007d55df7dc608  vmovaps [rsp+0x10], xmm1
00007d55df7dc60e  vmovaps [rsp+0x20], xmm2
00007d55df7dc614  vmovaps [rsp+0x30], xmm3
00007d55df7dc61a  vmovaps [rsp+0x40], xmm4
00007d55df7dc620  vmovaps [rsp+0x50], xmm5
00007d55df7dc626  vmovaps [rsp+0x60], xmm6
00007d55df7dc62c  vmovaps [rsp+0x70], xmm7
00007d55df7dc632  vmovaps [rsp+0x80], xmm8
00007d55df7dc63b  vmovaps [rsp+0x90], xmm9
00007d55df7dc644  vmovaps [rsp+0xA0], xmm11
00007d55df7dc64d  vmovaps [rsp+0xB0], xmm12
00007d55df7dc656  vmovaps [rsp+0xC0], xmm13
00007d55df7dc65f  vmovaps [rsp+0xD0], xmm14
00007d55df7dc668  vmovaps [rsp+0xE0], xmm15
00007d55df7dc671  sub rsp, 0x30
00007d55df7dc675  movaps [rsp], xmm10
00007d55df7dc67a  movaps [rsp+0x10], xmm8
00007d55df7dc680  movaps [rsp+0x20], xmm14
00007d55df7dc686  lea rdi, [rsp]
00007d55df7dc68a  mov esi, 0x00
00007d55df7dc68f  mov rax, 0x5BB8433D8530
00007d55df7dc699  call rax
00007d55df7dc69b  movaps xmm10, [rsp]
00007d55df7dc6a0  add rsp, 0x30
00007d55df7dc6a4  vmovaps xmm0, [rsp]
00007d55df7dc6a9  vmovaps xmm1, [rsp+0x10]
00007d55df7dc6af  vmovaps xmm2, [rsp+0x20]
00007d55df7dc6b5  vmovaps xmm3, [rsp+0x30]
00007d55df7dc6bb  vmovaps xmm4, [rsp+0x40]
00007d55df7dc6c1  vmovaps xmm5, [rsp+0x50]
00007d55df7dc6c7  vmovaps xmm6, [rsp+0x60]
00007d55df7dc6cd  vmovaps xmm7, [rsp+0x70]
00007d55df7dc6d3  vmovaps xmm8, [rsp+0x80]
00007d55df7dc6dc  vmovaps xmm9, [rsp+0x90]
00007d55df7dc6e5  vmovaps xmm11, [rsp+0xA0]
00007d55df7dc6ee  vmovaps xmm12, [rsp+0xB0]
00007d55df7dc6f7  vmovaps xmm13, [rsp+0xC0]
00007d55df7dc700  vmovaps xmm14, [rsp+0xD0]
00007d55df7dc709  vmovaps xmm15, [rsp+0xE0]
00007d55df7dc712  add rsp, 0xF0
00007d55df7dc719  pop r11
00007d55df7dc71b  pop r10
00007d55df7dc71d  pop r9
00007d55df7dc71f  pop r8
00007d55df7dc721  pop rsi
00007d55df7dc722  pop rdi
00007d55df7dc723  pop rdx
00007d55df7dc724  pop rcx
00007d55df7dc725  pop rax
00007d55df7dc726  add rsp, 0x08
00007d55df7dc72a  jmp 0x00007D55DF7D9425
00007d55df7dc72f  sub rsp, 0x08
00007d55df7dc733  push rax
00007d55df7dc734  push rcx
00007d55df7dc735  push rdx
00007d55df7dc736  push rdi
00007d55df7dc737  push rsi
00007d55df7dc738  push r8
00007d55df7dc73a  push r9
00007d55df7dc73c  push r10
00007d55df7dc73e  push r11
00007d55df7dc740  sub rsp, 0xF0
00007d55df7dc747  vmovaps [rsp], xmm0
00007d55df7dc74c  vmovaps [rsp+0x10], xmm1
00007d55df7dc752  vmovaps [rsp+0x20], xmm2
00007d55df7dc758  vmovaps [rsp+0x30], xmm3
00007d55df7dc75e  vmovaps [rsp+0x40], xmm4
00007d55df7dc764  vmovaps [rsp+0x50], xmm5
00007d55df7dc76a  vmovaps [rsp+0x60], xmm6
00007d55df7dc770  vmovaps [rsp+0x70], xmm7
00007d55df7dc776  vmovaps [rsp+0x80], xmm8
00007d55df7dc77f  vmovaps [rsp+0x90], xmm9
00007d55df7dc788  vmovaps [rsp+0xA0], xmm10
00007d55df7dc791  vmovaps [rsp+0xB0], xmm11
00007d55df7dc79a  vmovaps [rsp+0xC0], xmm12
00007d55df7dc7a3  vmovaps [rsp+0xD0], xmm13
00007d55df7dc7ac  vmovaps [rsp+0xE0], xmm15
00007d55df7dc7b5  sub rsp, 0x30
00007d55df7dc7b9  movaps [rsp], xmm14
00007d55df7dc7be  movaps [rsp+0x10], xmm8
00007d55df7dc7c4  movaps [rsp+0x20], xmm4
00007d55df7dc7c9  lea rdi, [rsp]
00007d55df7dc7cd  mov esi, 0x00
00007d55df7dc7d2  mov rax, 0x5BB8433D8530
00007d55df7dc7dc  call rax
00007d55df7dc7de  movaps xmm14, [rsp]
00007d55df7dc7e3  add rsp, 0x30
00007d55df7dc7e7  vmovaps xmm0, [rsp]
00007d55df7dc7ec  vmovaps xmm1, [rsp+0x10]
00007d55df7dc7f2  vmovaps xmm2, [rsp+0x20]
00007d55df7dc7f8  vmovaps xmm3, [rsp+0x30]
00007d55df7dc7fe  vmovaps xmm4, [rsp+0x40]
00007d55df7dc804  vmovaps xmm5, [rsp+0x50]
00007d55df7dc80a  vmovaps xmm6, [rsp+0x60]
00007d55df7dc810  vmovaps xmm7, [rsp+0x70]
00007d55df7dc816  vmovaps xmm8, [rsp+0x80]
00007d55df7dc81f  vmovaps xmm9, [rsp+0x90]
00007d55df7dc828  vmovaps xmm10, [rsp+0xA0]
00007d55df7dc831  vmovaps xmm11, [rsp+0xB0]
00007d55df7dc83a  vmovaps xmm12, [rsp+0xC0]
00007d55df7dc843  vmovaps xmm13, [rsp+0xD0]
00007d55df7dc84c  vmovaps xmm15, [rsp+0xE0]
00007d55df7dc855  add rsp, 0xF0
00007d55df7dc85c  pop r11
00007d55df7dc85e  pop r10
00007d55df7dc860  pop r9
00007d55df7dc862  pop r8
00007d55df7dc864  pop rsi
00007d55df7dc865  pop rdi
00007d55df7dc866  pop rdx
00007d55df7dc867  pop rcx
00007d55df7dc868  pop rax
00007d55df7dc869  add rsp, 0x08
00007d55df7dc86d  jmp 0x00007D55DF7D9445
00007d55df7dc872  sub rsp, 0x08
00007d55df7dc876  push rax
00007d55df7dc877  push rcx
00007d55df7dc878  push rdx
00007d55df7dc879  push rdi
00007d55df7dc87a  push rsi
00007d55df7dc87b  push r8
00007d55df7dc87d  push r9
00007d55df7dc87f  push r10
00007d55df7dc881  push r11
00007d55df7dc883  sub rsp, 0xF0
00007d55df7dc88a  vmovaps [rsp], xmm0
00007d55df7dc88f  vmovaps [rsp+0x10], xmm1
00007d55df7dc895  vmovaps [rsp+0x20], xmm2
00007d55df7dc89b  vmovaps [rsp+0x30], xmm3
00007d55df7dc8a1  vmovaps [rsp+0x40], xmm5
00007d55df7dc8a7  vmovaps [rsp+0x50], xmm6
00007d55df7dc8ad  vmovaps [rsp+0x60], xmm7
00007d55df7dc8b3  vmovaps [rsp+0x70], xmm8
00007d55df7dc8b9  vmovaps [rsp+0x80], xmm9
00007d55df7dc8c2  vmovaps [rsp+0x90], xmm10
00007d55df7dc8cb  vmovaps [rsp+0xA0], xmm11
00007d55df7dc8d4  vmovaps [rsp+0xB0], xmm12
00007d55df7dc8dd  vmovaps [rsp+0xC0], xmm13
00007d55df7dc8e6  vmovaps [rsp+0xD0], xmm14
00007d55df7dc8ef  vmovaps [rsp+0xE0], xmm15
00007d55df7dc8f8  sub rsp, 0x30
00007d55df7dc8fc  movaps [rsp], xmm4
00007d55df7dc900  movaps [rsp+0x10], xmm13
00007d55df7dc906  movaps [rsp+0x20], xmm8
00007d55df7dc90c  lea rdi, [rsp]
00007d55df7dc910  mov esi, 0x00
00007d55df7dc915  mov rax, 0x5BB8433D8530
00007d55df7dc91f  call rax
00007d55df7dc921  movaps xmm4, [rsp]
00007d55df7dc925  add rsp, 0x30
00007d55df7dc929  vmovaps xmm0, [rsp]
00007d55df7dc92e  vmovaps xmm1, [rsp+0x10]
00007d55df7dc934  vmovaps xmm2, [rsp+0x20]
00007d55df7dc93a  vmovaps xmm3, [rsp+0x30]
00007d55df7dc940  vmovaps xmm5, [rsp+0x40]
00007d55df7dc946  vmovaps xmm6, [rsp+0x50]
00007d55df7dc94c  vmovaps xmm7, [rsp+0x60]
00007d55df7dc952  vmovaps xmm8, [rsp+0x70]
00007d55df7dc958  vmovaps xmm9, [rsp+0x80]
00007d55df7dc961  vmovaps xmm10, [rsp+0x90]
00007d55df7dc96a  vmovaps xmm11, [rsp+0xA0]
00007d55df7dc973  vmovaps xmm12, [rsp+0xB0]
00007d55df7dc97c  vmovaps xmm13, [rsp+0xC0]
00007d55df7dc985  vmovaps xmm14, [rsp+0xD0]
00007d55df7dc98e  vmovaps xmm15, [rsp+0xE0]
00007d55df7dc997  add rsp, 0xF0
00007d55df7dc99e  pop r11
00007d55df7dc9a0  pop r10
00007d55df7dc9a2  pop r9
00007d55df7dc9a4  pop r8
00007d55df7dc9a6  pop rsi
00007d55df7dc9a7  pop rdi
00007d55df7dc9a8  pop rdx
00007d55df7dc9a9  pop rcx
00007d55df7dc9aa  pop rax
00007d55df7dc9ab  add rsp, 0x08
00007d55df7dc9af  jmp 0x00007D55DF7D946A
00007d55df7dc9b4  sub rsp, 0x08
00007d55df7dc9b8  push rax
00007d55df7dc9b9  push rcx
00007d55df7dc9ba  push rdx
00007d55df7dc9bb  push rdi
00007d55df7dc9bc  push rsi
00007d55df7dc9bd  push r8
00007d55df7dc9bf  push r9
00007d55df7dc9c1  push r10
00007d55df7dc9c3  push r11
00007d55df7dc9c5  sub rsp, 0xF0
00007d55df7dc9cc  vmovaps [rsp], xmm0
00007d55df7dc9d1  vmovaps [rsp+0x10], xmm1
00007d55df7dc9d7  vmovaps [rsp+0x20], xmm2
00007d55df7dc9dd  vmovaps [rsp+0x30], xmm3
00007d55df7dc9e3  vmovaps [rsp+0x40], xmm4
00007d55df7dc9e9  vmovaps [rsp+0x50], xmm5
00007d55df7dc9ef  vmovaps [rsp+0x60], xmm6
00007d55df7dc9f5  vmovaps [rsp+0x70], xmm7
00007d55df7dc9fb  vmovaps [rsp+0x80], xmm8
00007d55df7dca04  vmovaps [rsp+0x90], xmm9
00007d55df7dca0d  vmovaps [rsp+0xA0], xmm10
00007d55df7dca16  vmovaps [rsp+0xB0], xmm11
00007d55df7dca1f  vmovaps [rsp+0xC0], xmm12
00007d55df7dca28  vmovaps [rsp+0xD0], xmm14
00007d55df7dca31  vmovaps [rsp+0xE0], xmm15
00007d55df7dca3a  sub rsp, 0x30
00007d55df7dca3e  movaps [rsp], xmm13
00007d55df7dca43  movaps [rsp+0x10], xmm15
00007d55df7dca49  movaps [rsp+0x20], xmm9
00007d55df7dca4f  lea rdi, [rsp]
00007d55df7dca53  mov esi, 0x00
00007d55df7dca58  mov rax, 0x5BB8433D8530
00007d55df7dca62  call rax
00007d55df7dca64  movaps xmm13, [rsp]
00007d55df7dca69  add rsp, 0x30
00007d55df7dca6d  vmovaps xmm0, [rsp]
00007d55df7dca72  vmovaps xmm1, [rsp+0x10]
00007d55df7dca78  vmovaps xmm2, [rsp+0x20]
00007d55df7dca7e  vmovaps xmm3, [rsp+0x30]
00007d55df7dca84  vmovaps xmm4, [rsp+0x40]
00007d55df7dca8a  vmovaps xmm5, [rsp+0x50]
00007d55df7dca90  vmovaps xmm6, [rsp+0x60]
00007d55df7dca96  vmovaps xmm7, [rsp+0x70]
00007d55df7dca9c  vmovaps xmm8, [rsp+0x80]
00007d55df7dcaa5  vmovaps xmm9, [rsp+0x90]
00007d55df7dcaae  vmovaps xmm10, [rsp+0xA0]
00007d55df7dcab7  vmovaps xmm11, [rsp+0xB0]
00007d55df7dcac0  vmovaps xmm12, [rsp+0xC0]
00007d55df7dcac9  vmovaps xmm14, [rsp+0xD0]
00007d55df7dcad2  vmovaps xmm15, [rsp+0xE0]
00007d55df7dcadb  add rsp, 0xF0
00007d55df7dcae2  pop r11
00007d55df7dcae4  pop r10
00007d55df7dcae6  pop r9
00007d55df7dcae8  pop r8
00007d55df7dcaea  pop rsi
00007d55df7dcaeb  pop rdi
00007d55df7dcaec  pop rdx
00007d55df7dcaed  pop rcx
00007d55df7dcaee  pop rax
00007d55df7dcaef  add rsp, 0x08
00007d55df7dcaf3  jmp 0x00007D55DF7D9485
00007d55df7dcaf8  sub rsp, 0x08
00007d55df7dcafc  push rax
00007d55df7dcafd  push rcx
00007d55df7dcafe  push rdx
00007d55df7dcaff  push rdi
00007d55df7dcb00  push rsi
00007d55df7dcb01  push r8
00007d55df7dcb03  push r9
00007d55df7dcb05  push r10
00007d55df7dcb07  push r11
00007d55df7dcb09  sub rsp, 0xF0
00007d55df7dcb10  vmovaps [rsp], xmm0
00007d55df7dcb15  vmovaps [rsp+0x10], xmm1
00007d55df7dcb1b  vmovaps [rsp+0x20], xmm2
00007d55df7dcb21  vmovaps [rsp+0x30], xmm3
00007d55df7dcb27  vmovaps [rsp+0x40], xmm4
00007d55df7dcb2d  vmovaps [rsp+0x50], xmm5
00007d55df7dcb33  vmovaps [rsp+0x60], xmm6
00007d55df7dcb39  vmovaps [rsp+0x70], xmm7
00007d55df7dcb3f  vmovaps [rsp+0x80], xmm8
00007d55df7dcb48  vmovaps [rsp+0x90], xmm9
00007d55df7dcb51  vmovaps [rsp+0xA0], xmm10
00007d55df7dcb5a  vmovaps [rsp+0xB0], xmm11
00007d55df7dcb63  vmovaps [rsp+0xC0], xmm12
00007d55df7dcb6c  vmovaps [rsp+0xD0], xmm13
00007d55df7dcb75  vmovaps [rsp+0xE0], xmm14
00007d55df7dcb7e  sub rsp, 0x30
00007d55df7dcb82  movaps [rsp], xmm15
00007d55df7dcb87  movaps [rsp+0x10], xmm1
00007d55df7dcb8c  movaps [rsp+0x20], xmm5
00007d55df7dcb91  lea rdi, [rsp]
00007d55df7dcb95  mov esi, 0x00
00007d55df7dcb9a  mov rax, 0x5BB8433D8530
00007d55df7dcba4  call rax
00007d55df7dcba6  movaps xmm15, [rsp]
00007d55df7dcbab  add rsp, 0x30
00007d55df7dcbaf  vmovaps xmm0, [rsp]
00007d55df7dcbb4  vmovaps xmm1, [rsp+0x10]
00007d55df7dcbba  vmovaps xmm2, [rsp+0x20]
00007d55df7dcbc0  vmovaps xmm3, [rsp+0x30]
00007d55df7dcbc6  vmovaps xmm4, [rsp+0x40]
00007d55df7dcbcc  vmovaps xmm5, [rsp+0x50]
00007d55df7dcbd2  vmovaps xmm6, [rsp+0x60]
00007d55df7dcbd8  vmovaps xmm7, [rsp+0x70]
00007d55df7dcbde  vmovaps xmm8, [rsp+0x80]
00007d55df7dcbe7  vmovaps xmm9, [rsp+0x90]
00007d55df7dcbf0  vmovaps xmm10, [rsp+0xA0]
00007d55df7dcbf9  vmovaps xmm11, [rsp+0xB0]
00007d55df7dcc02  vmovaps xmm12, [rsp+0xC0]
00007d55df7dcc0b  vmovaps xmm13, [rsp+0xD0]
00007d55df7dcc14  vmovaps xmm14, [rsp+0xE0]
00007d55df7dcc1d  add rsp, 0xF0
00007d55df7dcc24  pop r11
00007d55df7dcc26  pop r10
00007d55df7dcc28  pop r9
00007d55df7dcc2a  pop r8
00007d55df7dcc2c  pop rsi
00007d55df7dcc2d  pop rdi
00007d55df7dcc2e  pop rdx
00007d55df7dcc2f  pop rcx
00007d55df7dcc30  pop rax
00007d55df7dcc31  add rsp, 0x08
00007d55df7dcc35  jmp 0x00007D55DF7D94A0
00007d55df7dcc3a  call 0x00007D55DF6D64F0
00007d55df7dcc3f  jmp 0x00007D55DF7D94FB
00007d55df7dcc44  sub rsp, 0x08
00007d55df7dcc48  push rax
00007d55df7dcc49  push rcx
00007d55df7dcc4a  push rdx
00007d55df7dcc4b  push rdi
00007d55df7dcc4c  push rsi
00007d55df7dcc4d  push r8
00007d55df7dcc4f  push r9
00007d55df7dcc51  push r10
00007d55df7dcc53  push r11
00007d55df7dcc55  sub rsp, 0xF0
00007d55df7dcc5c  vmovaps [rsp], xmm0
00007d55df7dcc61  vmovaps [rsp+0x10], xmm1
00007d55df7dcc67  vmovaps [rsp+0x20], xmm2
00007d55df7dcc6d  vmovaps [rsp+0x30], xmm3
00007d55df7dcc73  vmovaps [rsp+0x40], xmm4
00007d55df7dcc79  vmovaps [rsp+0x50], xmm5
00007d55df7dcc7f  vmovaps [rsp+0x60], xmm6
00007d55df7dcc85  vmovaps [rsp+0x70], xmm7
00007d55df7dcc8b  vmovaps [rsp+0x80], xmm8
00007d55df7dcc94  vmovaps [rsp+0x90], xmm10
00007d55df7dcc9d  vmovaps [rsp+0xA0], xmm11
00007d55df7dcca6  vmovaps [rsp+0xB0], xmm12
00007d55df7dccaf  vmovaps [rsp+0xC0], xmm13
00007d55df7dccb8  vmovaps [rsp+0xD0], xmm14
00007d55df7dccc1  vmovaps [rsp+0xE0], xmm15
00007d55df7dccca  sub rsp, 0x30
00007d55df7dccce  movaps [rsp], xmm9
00007d55df7dccd3  movaps [rsp+0x10], xmm8
00007d55df7dccd9  movaps [rsp+0x20], xmm11
00007d55df7dccdf  lea rdi, [rsp]
00007d55df7dcce3  mov esi, 0x00
00007d55df7dcce8  mov rax, 0x5BB8433D8530
00007d55df7dccf2  call rax
00007d55df7dccf4  movaps xmm9, [rsp]
00007d55df7dccf9  add rsp, 0x30
00007d55df7dccfd  vmovaps xmm0, [rsp]
00007d55df7dcd02  vmovaps xmm1, [rsp+0x10]
00007d55df7dcd08  vmovaps xmm2, [rsp+0x20]
00007d55df7dcd0e  vmovaps xmm3, [rsp+0x30]
00007d55df7dcd14  vmovaps xmm4, [rsp+0x40]
00007d55df7dcd1a  vmovaps xmm5, [rsp+0x50]
00007d55df7dcd20  vmovaps xmm6, [rsp+0x60]
00007d55df7dcd26  vmovaps xmm7, [rsp+0x70]
00007d55df7dcd2c  vmovaps xmm8, [rsp+0x80]
00007d55df7dcd35  vmovaps xmm10, [rsp+0x90]
00007d55df7dcd3e  vmovaps xmm11, [rsp+0xA0]
00007d55df7dcd47  vmovaps xmm12, [rsp+0xB0]
00007d55df7dcd50  vmovaps xmm13, [rsp+0xC0]
00007d55df7dcd59  vmovaps xmm14, [rsp+0xD0]
00007d55df7dcd62  vmovaps xmm15, [rsp+0xE0]
00007d55df7dcd6b  add rsp, 0xF0
00007d55df7dcd72  pop r11
00007d55df7dcd74  pop r10
00007d55df7dcd76  pop r9
00007d55df7dcd78  pop r8
00007d55df7dcd7a  pop rsi
00007d55df7dcd7b  pop rdi
00007d55df7dcd7c  pop rdx
00007d55df7dcd7d  pop rcx
00007d55df7dcd7e  pop rax
00007d55df7dcd7f  add rsp, 0x08
00007d55df7dcd83  jmp 0x00007D55DF7D9532
00007d55df7dcd88  sub rsp, 0x08
00007d55df7dcd8c  push rax
00007d55df7dcd8d  push rcx
00007d55df7dcd8e  push rdx
00007d55df7dcd8f  push rdi
00007d55df7dcd90  push rsi
00007d55df7dcd91  push r8
00007d55df7dcd93  push r9
00007d55df7dcd95  push r10
00007d55df7dcd97  push r11
00007d55df7dcd99  sub rsp, 0xF0
00007d55df7dcda0  vmovaps [rsp], xmm0
00007d55df7dcda5  vmovaps [rsp+0x10], xmm1
00007d55df7dcdab  vmovaps [rsp+0x20], xmm2
00007d55df7dcdb1  vmovaps [rsp+0x30], xmm3
00007d55df7dcdb7  vmovaps [rsp+0x40], xmm4
00007d55df7dcdbd  vmovaps [rsp+0x50], xmm5
00007d55df7dcdc3  vmovaps [rsp+0x60], xmm6
00007d55df7dcdc9  vmovaps [rsp+0x70], xmm7
00007d55df7dcdcf  vmovaps [rsp+0x80], xmm8
00007d55df7dcdd8  vmovaps [rsp+0x90], xmm9
00007d55df7dcde1  vmovaps [rsp+0xA0], xmm10
00007d55df7dcdea  vmovaps [rsp+0xB0], xmm12
00007d55df7dcdf3  vmovaps [rsp+0xC0], xmm13
00007d55df7dcdfc  vmovaps [rsp+0xD0], xmm14
00007d55df7dce05  vmovaps [rsp+0xE0], xmm15
00007d55df7dce0e  sub rsp, 0x30
00007d55df7dce12  movaps [rsp], xmm11
00007d55df7dce17  movaps [rsp+0x10], xmm10
00007d55df7dce1d  movaps [rsp+0x20], xmm6
00007d55df7dce22  lea rdi, [rsp]
00007d55df7dce26  mov esi, 0x00
00007d55df7dce2b  mov rax, 0x5BB8433D8530
00007d55df7dce35  call rax
00007d55df7dce37  movaps xmm11, [rsp]
00007d55df7dce3c  add rsp, 0x30
00007d55df7dce40  vmovaps xmm0, [rsp]
00007d55df7dce45  vmovaps xmm1, [rsp+0x10]
00007d55df7dce4b  vmovaps xmm2, [rsp+0x20]
00007d55df7dce51  vmovaps xmm3, [rsp+0x30]
00007d55df7dce57  vmovaps xmm4, [rsp+0x40]
00007d55df7dce5d  vmovaps xmm5, [rsp+0x50]
00007d55df7dce63  vmovaps xmm6, [rsp+0x60]
00007d55df7dce69  vmovaps xmm7, [rsp+0x70]
00007d55df7dce6f  vmovaps xmm8, [rsp+0x80]
00007d55df7dce78  vmovaps xmm9, [rsp+0x90]
00007d55df7dce81  vmovaps xmm10, [rsp+0xA0]
00007d55df7dce8a  vmovaps xmm12, [rsp+0xB0]
00007d55df7dce93  vmovaps xmm13, [rsp+0xC0]
00007d55df7dce9c  vmovaps xmm14, [rsp+0xD0]
00007d55df7dcea5  vmovaps xmm15, [rsp+0xE0]
00007d55df7dceae  add rsp, 0xF0
00007d55df7dceb5  pop r11
00007d55df7dceb7  pop r10
00007d55df7dceb9  pop r9
00007d55df7dcebb  pop r8
00007d55df7dcebd  pop rsi
00007d55df7dcebe  pop rdi
00007d55df7dcebf  pop rdx
00007d55df7dcec0  pop rcx
00007d55df7dcec1  pop rax
00007d55df7dcec2  add rsp, 0x08
00007d55df7dcec6  jmp 0x00007D55DF7D954D
00007d55df7dcecb  sub rsp, 0x08
00007d55df7dcecf  push rax
00007d55df7dced0  push rcx
00007d55df7dced1  push rdx
00007d55df7dced2  push rdi
00007d55df7dced3  push rsi
00007d55df7dced4  push r8
00007d55df7dced6  push r9
00007d55df7dced8  push r10
00007d55df7dceda  push r11
00007d55df7dcedc  sub rsp, 0xF0
00007d55df7dcee3  vmovaps [rsp], xmm0
00007d55df7dcee8  vmovaps [rsp+0x10], xmm1
00007d55df7dceee  vmovaps [rsp+0x20], xmm2
00007d55df7dcef4  vmovaps [rsp+0x30], xmm3
00007d55df7dcefa  vmovaps [rsp+0x40], xmm4
00007d55df7dcf00  vmovaps [rsp+0x50], xmm5
00007d55df7dcf06  vmovaps [rsp+0x60], xmm6
00007d55df7dcf0c  vmovaps [rsp+0x70], xmm7
00007d55df7dcf12  vmovaps [rsp+0x80], xmm8
00007d55df7dcf1b  vmovaps [rsp+0x90], xmm9
00007d55df7dcf24  vmovaps [rsp+0xA0], xmm11
00007d55df7dcf2d  vmovaps [rsp+0xB0], xmm12
00007d55df7dcf36  vmovaps [rsp+0xC0], xmm13
00007d55df7dcf3f  vmovaps [rsp+0xD0], xmm14
00007d55df7dcf48  vmovaps [rsp+0xE0], xmm15
00007d55df7dcf51  sub rsp, 0x30
00007d55df7dcf55  movaps [rsp], xmm10
00007d55df7dcf5a  movaps [rsp+0x10], xmm14
00007d55df7dcf60  movaps [rsp+0x20], xmm4
00007d55df7dcf65  lea rdi, [rsp]
00007d55df7dcf69  mov esi, 0x00
00007d55df7dcf6e  mov rax, 0x5BB8433D8530
00007d55df7dcf78  call rax
00007d55df7dcf7a  movaps xmm10, [rsp]
00007d55df7dcf7f  add rsp, 0x30
00007d55df7dcf83  vmovaps xmm0, [rsp]
00007d55df7dcf88  vmovaps xmm1, [rsp+0x10]
00007d55df7dcf8e  vmovaps xmm2, [rsp+0x20]
00007d55df7dcf94  vmovaps xmm3, [rsp+0x30]
00007d55df7dcf9a  vmovaps xmm4, [rsp+0x40]
00007d55df7dcfa0  vmovaps xmm5, [rsp+0x50]
00007d55df7dcfa6  vmovaps xmm6, [rsp+0x60]
00007d55df7dcfac  vmovaps xmm7, [rsp+0x70]
00007d55df7dcfb2  vmovaps xmm8, [rsp+0x80]
00007d55df7dcfbb  vmovaps xmm9, [rsp+0x90]
00007d55df7dcfc4  vmovaps xmm11, [rsp+0xA0]
00007d55df7dcfcd  vmovaps xmm12, [rsp+0xB0]
00007d55df7dcfd6  vmovaps xmm13, [rsp+0xC0]
00007d55df7dcfdf  vmovaps xmm14, [rsp+0xD0]
00007d55df7dcfe8  vmovaps xmm15, [rsp+0xE0]
00007d55df7dcff1  add rsp, 0xF0
00007d55df7dcff8  pop r11
00007d55df7dcffa  pop r10
00007d55df7dcffc  pop r9
00007d55df7dcffe  pop r8
00007d55df7dd000  pop rsi
00007d55df7dd001  pop rdi
00007d55df7dd002  pop rdx
00007d55df7dd003  pop rcx
00007d55df7dd004  pop rax
00007d55df7dd005  add rsp, 0x08
00007d55df7dd009  jmp 0x00007D55DF7D9568
00007d55df7dd00e  sub rsp, 0x08
00007d55df7dd012  push rax
00007d55df7dd013  push rcx
00007d55df7dd014  push rdx
00007d55df7dd015  push rdi
00007d55df7dd016  push rsi
00007d55df7dd017  push r8
00007d55df7dd019  push r9
00007d55df7dd01b  push r10
00007d55df7dd01d  push r11
00007d55df7dd01f  sub rsp, 0xF0
00007d55df7dd026  vmovaps [rsp], xmm0
00007d55df7dd02b  vmovaps [rsp+0x10], xmm1
00007d55df7dd031  vmovaps [rsp+0x20], xmm2
00007d55df7dd037  vmovaps [rsp+0x30], xmm3
00007d55df7dd03d  vmovaps [rsp+0x40], xmm4
00007d55df7dd043  vmovaps [rsp+0x50], xmm5
00007d55df7dd049  vmovaps [rsp+0x60], xmm6
00007d55df7dd04f  vmovaps [rsp+0x70], xmm7
00007d55df7dd055  vmovaps [rsp+0x80], xmm9
00007d55df7dd05e  vmovaps [rsp+0x90], xmm10
00007d55df7dd067  vmovaps [rsp+0xA0], xmm11
00007d55df7dd070  vmovaps [rsp+0xB0], xmm12
00007d55df7dd079  vmovaps [rsp+0xC0], xmm13
00007d55df7dd082  vmovaps [rsp+0xD0], xmm14
00007d55df7dd08b  vmovaps [rsp+0xE0], xmm15
00007d55df7dd094  sub rsp, 0x30
00007d55df7dd098  movaps [rsp], xmm8
00007d55df7dd09d  movaps [rsp+0x10], xmm1
00007d55df7dd0a2  movaps [rsp+0x20], xmm14
00007d55df7dd0a8  lea rdi, [rsp]
00007d55df7dd0ac  mov esi, 0x00
00007d55df7dd0b1  mov rax, 0x5BB8433D8530
00007d55df7dd0bb  call rax
00007d55df7dd0bd  movaps xmm8, [rsp]
00007d55df7dd0c2  add rsp, 0x30
00007d55df7dd0c6  vmovaps xmm0, [rsp]
00007d55df7dd0cb  vmovaps xmm1, [rsp+0x10]
00007d55df7dd0d1  vmovaps xmm2, [rsp+0x20]
00007d55df7dd0d7  vmovaps xmm3, [rsp+0x30]
00007d55df7dd0dd  vmovaps xmm4, [rsp+0x40]
00007d55df7dd0e3  vmovaps xmm5, [rsp+0x50]
00007d55df7dd0e9  vmovaps xmm6, [rsp+0x60]
00007d55df7dd0ef  vmovaps xmm7, [rsp+0x70]
00007d55df7dd0f5  vmovaps xmm9, [rsp+0x80]
00007d55df7dd0fe  vmovaps xmm10, [rsp+0x90]
00007d55df7dd107  vmovaps xmm11, [rsp+0xA0]
00007d55df7dd110  vmovaps xmm12, [rsp+0xB0]
00007d55df7dd119  vmovaps xmm13, [rsp+0xC0]
00007d55df7dd122  vmovaps xmm14, [rsp+0xD0]
00007d55df7dd12b  vmovaps xmm15, [rsp+0xE0]
00007d55df7dd134  add rsp, 0xF0
00007d55df7dd13b  pop r11
00007d55df7dd13d  pop r10
00007d55df7dd13f  pop r9
00007d55df7dd141  pop r8
00007d55df7dd143  pop rsi
00007d55df7dd144  pop rdi
00007d55df7dd145  pop rdx
00007d55df7dd146  pop rcx
00007d55df7dd147  pop rax
00007d55df7dd148  add rsp, 0x08
00007d55df7dd14c  jmp 0x00007D55DF7D958E
00007d55df7dd151  sub rsp, 0x08
00007d55df7dd155  push rax
00007d55df7dd156  push rcx
00007d55df7dd157  push rdx
00007d55df7dd158  push rdi
00007d55df7dd159  push rsi
00007d55df7dd15a  push r8
00007d55df7dd15c  push r9
00007d55df7dd15e  push r10
00007d55df7dd160  push r11
00007d55df7dd162  sub rsp, 0xF0
00007d55df7dd169  vmovaps [rsp], xmm0
00007d55df7dd16e  vmovaps [rsp+0x10], xmm1
00007d55df7dd174  vmovaps [rsp+0x20], xmm2
00007d55df7dd17a  vmovaps [rsp+0x30], xmm3
00007d55df7dd180  vmovaps [rsp+0x40], xmm4
00007d55df7dd186  vmovaps [rsp+0x50], xmm5
00007d55df7dd18c  vmovaps [rsp+0x60], xmm7
00007d55df7dd192  vmovaps [rsp+0x70], xmm8
00007d55df7dd198  vmovaps [rsp+0x80], xmm9
00007d55df7dd1a1  vmovaps [rsp+0x90], xmm10
00007d55df7dd1aa  vmovaps [rsp+0xA0], xmm11
00007d55df7dd1b3  vmovaps [rsp+0xB0], xmm12
00007d55df7dd1bc  vmovaps [rsp+0xC0], xmm13
00007d55df7dd1c5  vmovaps [rsp+0xD0], xmm14
00007d55df7dd1ce  vmovaps [rsp+0xE0], xmm15
00007d55df7dd1d7  sub rsp, 0x30
00007d55df7dd1db  movaps [rsp], xmm6
00007d55df7dd1df  movaps [rsp+0x10], xmm1
00007d55df7dd1e4  movaps [rsp+0x20], xmm14
00007d55df7dd1ea  lea rdi, [rsp]
00007d55df7dd1ee  mov esi, 0x00
00007d55df7dd1f3  mov rax, 0x5BB8433D8530
00007d55df7dd1fd  call rax
00007d55df7dd1ff  movaps xmm6, [rsp]
00007d55df7dd203  add rsp, 0x30
00007d55df7dd207  vmovaps xmm0, [rsp]
00007d55df7dd20c  vmovaps xmm1, [rsp+0x10]
00007d55df7dd212  vmovaps xmm2, [rsp+0x20]
00007d55df7dd218  vmovaps xmm3, [rsp+0x30]
00007d55df7dd21e  vmovaps xmm4, [rsp+0x40]
00007d55df7dd224  vmovaps xmm5, [rsp+0x50]
00007d55df7dd22a  vmovaps xmm7, [rsp+0x60]
00007d55df7dd230  vmovaps xmm8, [rsp+0x70]
00007d55df7dd236  vmovaps xmm9, [rsp+0x80]
00007d55df7dd23f  vmovaps xmm10, [rsp+0x90]
00007d55df7dd248  vmovaps xmm11, [rsp+0xA0]
00007d55df7dd251  vmovaps xmm12, [rsp+0xB0]
00007d55df7dd25a  vmovaps xmm13, [rsp+0xC0]
00007d55df7dd263  vmovaps xmm14, [rsp+0xD0]
00007d55df7dd26c  vmovaps xmm15, [rsp+0xE0]
00007d55df7dd275  add rsp, 0xF0
00007d55df7dd27c  pop r11
00007d55df7dd27e  pop r10
00007d55df7dd280  pop r9
00007d55df7dd282  pop r8
00007d55df7dd284  pop rsi
00007d55df7dd285  pop rdi
00007d55df7dd286  pop rdx
00007d55df7dd287  pop rcx
00007d55df7dd288  pop rax
00007d55df7dd289  add rsp, 0x08
00007d55df7dd28d  jmp 0x00007D55DF7D95BA
00007d55df7dd292  sub rsp, 0x08
00007d55df7dd296  push rax
00007d55df7dd297  push rcx
00007d55df7dd298  push rdx
00007d55df7dd299  push rdi
00007d55df7dd29a  push rsi
00007d55df7dd29b  push r8
00007d55df7dd29d  push r9
00007d55df7dd29f  push r10
00007d55df7dd2a1  push r11
00007d55df7dd2a3  sub rsp, 0xF0
00007d55df7dd2aa  vmovaps [rsp], xmm0
00007d55df7dd2af  vmovaps [rsp+0x10], xmm1
00007d55df7dd2b5  vmovaps [rsp+0x20], xmm2
00007d55df7dd2bb  vmovaps [rsp+0x30], xmm3
00007d55df7dd2c1  vmovaps [rsp+0x40], xmm4
00007d55df7dd2c7  vmovaps [rsp+0x50], xmm5
00007d55df7dd2cd  vmovaps [rsp+0x60], xmm6
00007d55df7dd2d3  vmovaps [rsp+0x70], xmm7
00007d55df7dd2d9  vmovaps [rsp+0x80], xmm8
00007d55df7dd2e2  vmovaps [rsp+0x90], xmm9
00007d55df7dd2eb  vmovaps [rsp+0xA0], xmm10
00007d55df7dd2f4  vmovaps [rsp+0xB0], xmm11
00007d55df7dd2fd  vmovaps [rsp+0xC0], xmm12
00007d55df7dd306  vmovaps [rsp+0xD0], xmm13
00007d55df7dd30f  vmovaps [rsp+0xE0], xmm15
00007d55df7dd318  sub rsp, 0x30
00007d55df7dd31c  movaps [rsp], xmm14
00007d55df7dd321  movaps [rsp+0x10], xmm12
00007d55df7dd327  movaps [rsp+0x20], xmm1
00007d55df7dd32c  lea rdi, [rsp]
00007d55df7dd330  mov esi, 0x00
00007d55df7dd335  mov rax, 0x5BB8433D8530
00007d55df7dd33f  call rax
00007d55df7dd341  movaps xmm14, [rsp]
00007d55df7dd346  add rsp, 0x30
00007d55df7dd34a  vmovaps xmm0, [rsp]
00007d55df7dd34f  vmovaps xmm1, [rsp+0x10]
00007d55df7dd355  vmovaps xmm2, [rsp+0x20]
00007d55df7dd35b  vmovaps xmm3, [rsp+0x30]
00007d55df7dd361  vmovaps xmm4, [rsp+0x40]
00007d55df7dd367  vmovaps xmm5, [rsp+0x50]
00007d55df7dd36d  vmovaps xmm6, [rsp+0x60]
00007d55df7dd373  vmovaps xmm7, [rsp+0x70]
00007d55df7dd379  vmovaps xmm8, [rsp+0x80]
00007d55df7dd382  vmovaps xmm9, [rsp+0x90]
00007d55df7dd38b  vmovaps xmm10, [rsp+0xA0]
00007d55df7dd394  vmovaps xmm11, [rsp+0xB0]
00007d55df7dd39d  vmovaps xmm12, [rsp+0xC0]
00007d55df7dd3a6  vmovaps xmm13, [rsp+0xD0]
00007d55df7dd3af  vmovaps xmm15, [rsp+0xE0]
00007d55df7dd3b8  add rsp, 0xF0
00007d55df7dd3bf  pop r11
00007d55df7dd3c1  pop r10
00007d55df7dd3c3  pop r9
00007d55df7dd3c5  pop r8
00007d55df7dd3c7  pop rsi
00007d55df7dd3c8  pop rdi
00007d55df7dd3c9  pop rdx
00007d55df7dd3ca  pop rcx
00007d55df7dd3cb  pop rax
00007d55df7dd3cc  add rsp, 0x08
00007d55df7dd3d0  jmp 0x00007D55DF7D95E0
00007d55df7dd3d5  sub rsp, 0x08
00007d55df7dd3d9  push rax
00007d55df7dd3da  push rcx
00007d55df7dd3db  push rdx
00007d55df7dd3dc  push rdi
00007d55df7dd3dd  push rsi
00007d55df7dd3de  push r8
00007d55df7dd3e0  push r9
00007d55df7dd3e2  push r10
00007d55df7dd3e4  push r11
00007d55df7dd3e6  sub rsp, 0xF0
00007d55df7dd3ed  vmovaps [rsp], xmm0
00007d55df7dd3f2  vmovaps [rsp+0x10], xmm2
00007d55df7dd3f8  vmovaps [rsp+0x20], xmm3
00007d55df7dd3fe  vmovaps [rsp+0x30], xmm4
00007d55df7dd404  vmovaps [rsp+0x40], xmm5
00007d55df7dd40a  vmovaps [rsp+0x50], xmm6
00007d55df7dd410  vmovaps [rsp+0x60], xmm7
00007d55df7dd416  vmovaps [rsp+0x70], xmm8
00007d55df7dd41c  vmovaps [rsp+0x80], xmm9
00007d55df7dd425  vmovaps [rsp+0x90], xmm10
00007d55df7dd42e  vmovaps [rsp+0xA0], xmm11
00007d55df7dd437  vmovaps [rsp+0xB0], xmm12
00007d55df7dd440  vmovaps [rsp+0xC0], xmm13
00007d55df7dd449  vmovaps [rsp+0xD0], xmm14
00007d55df7dd452  vmovaps [rsp+0xE0], xmm15
00007d55df7dd45b  sub rsp, 0x30
00007d55df7dd45f  movaps [rsp], xmm1
00007d55df7dd463  movaps [rsp+0x10], xmm13
00007d55df7dd469  movaps [rsp+0x20], xmm9
00007d55df7dd46f  lea rdi, [rsp]
00007d55df7dd473  mov esi, 0x00
00007d55df7dd478  mov rax, 0x5BB8433D8530
00007d55df7dd482  call rax
00007d55df7dd484  movaps xmm1, [rsp]
00007d55df7dd488  add rsp, 0x30
00007d55df7dd48c  vmovaps xmm0, [rsp]
00007d55df7dd491  vmovaps xmm2, [rsp+0x10]
00007d55df7dd497  vmovaps xmm3, [rsp+0x20]
00007d55df7dd49d  vmovaps xmm4, [rsp+0x30]
00007d55df7dd4a3  vmovaps xmm5, [rsp+0x40]
00007d55df7dd4a9  vmovaps xmm6, [rsp+0x50]
00007d55df7dd4af  vmovaps xmm7, [rsp+0x60]
00007d55df7dd4b5  vmovaps xmm8, [rsp+0x70]
00007d55df7dd4bb  vmovaps xmm9, [rsp+0x80]
00007d55df7dd4c4  vmovaps xmm10, [rsp+0x90]
00007d55df7dd4cd  vmovaps xmm11, [rsp+0xA0]
00007d55df7dd4d6  vmovaps xmm12, [rsp+0xB0]
00007d55df7dd4df  vmovaps xmm13, [rsp+0xC0]
00007d55df7dd4e8  vmovaps xmm14, [rsp+0xD0]
00007d55df7dd4f1  vmovaps xmm15, [rsp+0xE0]
00007d55df7dd4fa  add rsp, 0xF0
00007d55df7dd501  pop r11
00007d55df7dd503  pop r10
00007d55df7dd505  pop r9
00007d55df7dd507  pop r8
00007d55df7dd509  pop rsi
00007d55df7dd50a  pop rdi
00007d55df7dd50b  pop rdx
00007d55df7dd50c  pop rcx
00007d55df7dd50d  pop rax
00007d55df7dd50e  add rsp, 0x08
00007d55df7dd512  jmp 0x00007D55DF7D95FA
00007d55df7dd517  sub rsp, 0x08
00007d55df7dd51b  push rax
00007d55df7dd51c  push rcx
00007d55df7dd51d  push rdx
00007d55df7dd51e  push rdi
00007d55df7dd51f  push rsi
00007d55df7dd520  push r8
00007d55df7dd522  push r9
00007d55df7dd524  push r10
00007d55df7dd526  push r11
00007d55df7dd528  sub rsp, 0xF0
00007d55df7dd52f  vmovaps [rsp], xmm0
00007d55df7dd534  vmovaps [rsp+0x10], xmm1
00007d55df7dd53a  vmovaps [rsp+0x20], xmm2
00007d55df7dd540  vmovaps [rsp+0x30], xmm3
00007d55df7dd546  vmovaps [rsp+0x40], xmm4
00007d55df7dd54c  vmovaps [rsp+0x50], xmm5
00007d55df7dd552  vmovaps [rsp+0x60], xmm6
00007d55df7dd558  vmovaps [rsp+0x70], xmm7
00007d55df7dd55e  vmovaps [rsp+0x80], xmm8
00007d55df7dd567  vmovaps [rsp+0x90], xmm9
00007d55df7dd570  vmovaps [rsp+0xA0], xmm10
00007d55df7dd579  vmovaps [rsp+0xB0], xmm11
00007d55df7dd582  vmovaps [rsp+0xC0], xmm13
00007d55df7dd58b  vmovaps [rsp+0xD0], xmm14
00007d55df7dd594  vmovaps [rsp+0xE0], xmm15
00007d55df7dd59d  sub rsp, 0x30
00007d55df7dd5a1  movaps [rsp], xmm12
00007d55df7dd5a6  movaps [rsp+0x10], xmm7
00007d55df7dd5ab  movaps [rsp+0x20], xmm13
00007d55df7dd5b1  lea rdi, [rsp]
00007d55df7dd5b5  mov esi, 0x00
00007d55df7dd5ba  mov rax, 0x5BB8433D8530
00007d55df7dd5c4  call rax
00007d55df7dd5c6  movaps xmm12, [rsp]
00007d55df7dd5cb  add rsp, 0x30
00007d55df7dd5cf  vmovaps xmm0, [rsp]
00007d55df7dd5d4  vmovaps xmm1, [rsp+0x10]
00007d55df7dd5da  vmovaps xmm2, [rsp+0x20]
00007d55df7dd5e0  vmovaps xmm3, [rsp+0x30]
00007d55df7dd5e6  vmovaps xmm4, [rsp+0x40]
00007d55df7dd5ec  vmovaps xmm5, [rsp+0x50]
00007d55df7dd5f2  vmovaps xmm6, [rsp+0x60]
00007d55df7dd5f8  vmovaps xmm7, [rsp+0x70]
00007d55df7dd5fe  vmovaps xmm8, [rsp+0x80]
00007d55df7dd607  vmovaps xmm9, [rsp+0x90]
00007d55df7dd610  vmovaps xmm10, [rsp+0xA0]
00007d55df7dd619  vmovaps xmm11, [rsp+0xB0]
00007d55df7dd622  vmovaps xmm13, [rsp+0xC0]
00007d55df7dd62b  vmovaps xmm14, [rsp+0xD0]
00007d55df7dd634  vmovaps xmm15, [rsp+0xE0]
00007d55df7dd63d  add rsp, 0xF0
00007d55df7dd644  pop r11
00007d55df7dd646  pop r10
00007d55df7dd648  pop r9
00007d55df7dd64a  pop r8
00007d55df7dd64c  pop rsi
00007d55df7dd64d  pop rdi
00007d55df7dd64e  pop rdx
00007d55df7dd64f  pop rcx
00007d55df7dd650  pop rax
00007d55df7dd651  add rsp, 0x08
00007d55df7dd655  jmp 0x00007D55DF7D9621
00007d55df7dd65a  sub rsp, 0x08
00007d55df7dd65e  push rax
00007d55df7dd65f  push rcx
00007d55df7dd660  push rdx
00007d55df7dd661  push rdi
00007d55df7dd662  push rsi
00007d55df7dd663  push r8
00007d55df7dd665  push r9
00007d55df7dd667  push r10
00007d55df7dd669  push r11
00007d55df7dd66b  sub rsp, 0xF0
00007d55df7dd672  vmovaps [rsp], xmm0
00007d55df7dd677  vmovaps [rsp+0x10], xmm1
00007d55df7dd67d  vmovaps [rsp+0x20], xmm2
00007d55df7dd683  vmovaps [rsp+0x30], xmm3
00007d55df7dd689  vmovaps [rsp+0x40], xmm4
00007d55df7dd68f  vmovaps [rsp+0x50], xmm5
00007d55df7dd695  vmovaps [rsp+0x60], xmm6
00007d55df7dd69b  vmovaps [rsp+0x70], xmm7
00007d55df7dd6a1  vmovaps [rsp+0x80], xmm8
00007d55df7dd6aa  vmovaps [rsp+0x90], xmm9
00007d55df7dd6b3  vmovaps [rsp+0xA0], xmm10
00007d55df7dd6bc  vmovaps [rsp+0xB0], xmm11
00007d55df7dd6c5  vmovaps [rsp+0xC0], xmm12
00007d55df7dd6ce  vmovaps [rsp+0xD0], xmm14
00007d55df7dd6d7  vmovaps [rsp+0xE0], xmm15
00007d55df7dd6e0  sub rsp, 0x30
00007d55df7dd6e4  movaps [rsp], xmm13
00007d55df7dd6e9  movaps [rsp+0x10], xmm15
00007d55df7dd6ef  movaps [rsp+0x20], xmm8
00007d55df7dd6f5  lea rdi, [rsp]
00007d55df7dd6f9  mov esi, 0x00
00007d55df7dd6fe  mov rax, 0x5BB8433D8530
00007d55df7dd708  call rax
00007d55df7dd70a  movaps xmm13, [rsp]
00007d55df7dd70f  add rsp, 0x30
00007d55df7dd713  vmovaps xmm0, [rsp]
00007d55df7dd718  vmovaps xmm1, [rsp+0x10]
00007d55df7dd71e  vmovaps xmm2, [rsp+0x20]
00007d55df7dd724  vmovaps xmm3, [rsp+0x30]
00007d55df7dd72a  vmovaps xmm4, [rsp+0x40]
00007d55df7dd730  vmovaps xmm5, [rsp+0x50]
00007d55df7dd736  vmovaps xmm6, [rsp+0x60]
00007d55df7dd73c  vmovaps xmm7, [rsp+0x70]
00007d55df7dd742  vmovaps xmm8, [rsp+0x80]
00007d55df7dd74b  vmovaps xmm9, [rsp+0x90]
00007d55df7dd754  vmovaps xmm10, [rsp+0xA0]
00007d55df7dd75d  vmovaps xmm11, [rsp+0xB0]
00007d55df7dd766  vmovaps xmm12, [rsp+0xC0]
00007d55df7dd76f  vmovaps xmm14, [rsp+0xD0]
00007d55df7dd778  vmovaps xmm15, [rsp+0xE0]
00007d55df7dd781  add rsp, 0xF0
00007d55df7dd788  pop r11
00007d55df7dd78a  pop r10
00007d55df7dd78c  pop r9
00007d55df7dd78e  pop r8
00007d55df7dd790  pop rsi
00007d55df7dd791  pop rdi
00007d55df7dd792  pop rdx
00007d55df7dd793  pop rcx
00007d55df7dd794  pop rax
00007d55df7dd795  add rsp, 0x08
00007d55df7dd799  jmp 0x00007D55DF7D963C
00007d55df7dd79e  sub rsp, 0x08
00007d55df7dd7a2  push rax
00007d55df7dd7a3  push rcx
00007d55df7dd7a4  push rdx
00007d55df7dd7a5  push rdi
00007d55df7dd7a6  push rsi
00007d55df7dd7a7  push r8
00007d55df7dd7a9  push r9
00007d55df7dd7ab  push r10
00007d55df7dd7ad  push r11
00007d55df7dd7af  sub rsp, 0xF0
00007d55df7dd7b6  vmovaps [rsp], xmm0
00007d55df7dd7bb  vmovaps [rsp+0x10], xmm1
00007d55df7dd7c1  vmovaps [rsp+0x20], xmm2
00007d55df7dd7c7  vmovaps [rsp+0x30], xmm3
00007d55df7dd7cd  vmovaps [rsp+0x40], xmm4
00007d55df7dd7d3  vmovaps [rsp+0x50], xmm5
00007d55df7dd7d9  vmovaps [rsp+0x60], xmm6
00007d55df7dd7df  vmovaps [rsp+0x70], xmm7
00007d55df7dd7e5  vmovaps [rsp+0x80], xmm9
00007d55df7dd7ee  vmovaps [rsp+0x90], xmm10
00007d55df7dd7f7  vmovaps [rsp+0xA0], xmm11
00007d55df7dd800  vmovaps [rsp+0xB0], xmm12
00007d55df7dd809  vmovaps [rsp+0xC0], xmm13
00007d55df7dd812  vmovaps [rsp+0xD0], xmm14
00007d55df7dd81b  vmovaps [rsp+0xE0], xmm15
00007d55df7dd824  sub rsp, 0x30
00007d55df7dd828  movaps [rsp], xmm8
00007d55df7dd82d  movaps [rsp+0x10], xmm15
00007d55df7dd833  movaps [rsp+0x20], xmm9
00007d55df7dd839  lea rdi, [rsp]
00007d55df7dd83d  mov esi, 0x00
00007d55df7dd842  mov rax, 0x5BB8433D8530
00007d55df7dd84c  call rax
00007d55df7dd84e  movaps xmm8, [rsp]
00007d55df7dd853  add rsp, 0x30
00007d55df7dd857  vmovaps xmm0, [rsp]
00007d55df7dd85c  vmovaps xmm1, [rsp+0x10]
00007d55df7dd862  vmovaps xmm2, [rsp+0x20]
00007d55df7dd868  vmovaps xmm3, [rsp+0x30]
00007d55df7dd86e  vmovaps xmm4, [rsp+0x40]
00007d55df7dd874  vmovaps xmm5, [rsp+0x50]
00007d55df7dd87a  vmovaps xmm6, [rsp+0x60]
00007d55df7dd880  vmovaps xmm7, [rsp+0x70]
00007d55df7dd886  vmovaps xmm9, [rsp+0x80]
00007d55df7dd88f  vmovaps xmm10, [rsp+0x90]
00007d55df7dd898  vmovaps xmm11, [rsp+0xA0]
00007d55df7dd8a1  vmovaps xmm12, [rsp+0xB0]
00007d55df7dd8aa  vmovaps xmm13, [rsp+0xC0]
00007d55df7dd8b3  vmovaps xmm14, [rsp+0xD0]
00007d55df7dd8bc  vmovaps xmm15, [rsp+0xE0]
00007d55df7dd8c5  add rsp, 0xF0
00007d55df7dd8cc  pop r11
00007d55df7dd8ce  pop r10
00007d55df7dd8d0  pop r9
00007d55df7dd8d2  pop r8
00007d55df7dd8d4  pop rsi
00007d55df7dd8d5  pop rdi
00007d55df7dd8d6  pop rdx
00007d55df7dd8d7  pop rcx
00007d55df7dd8d8  pop rax
00007d55df7dd8d9  add rsp, 0x08
00007d55df7dd8dd  jmp 0x00007D55DF7D966A
00007d55df7dd8e2  sub rsp, 0x08
00007d55df7dd8e6  push rax
00007d55df7dd8e7  push rcx
00007d55df7dd8e8  push rdx
00007d55df7dd8e9  push rdi
00007d55df7dd8ea  push rsi
00007d55df7dd8eb  push r8
00007d55df7dd8ed  push r9
00007d55df7dd8ef  push r10
00007d55df7dd8f1  push r11
00007d55df7dd8f3  sub rsp, 0xF0
00007d55df7dd8fa  vmovaps [rsp], xmm0
00007d55df7dd8ff  vmovaps [rsp+0x10], xmm1
00007d55df7dd905  vmovaps [rsp+0x20], xmm2
00007d55df7dd90b  vmovaps [rsp+0x30], xmm3
00007d55df7dd911  vmovaps [rsp+0x40], xmm4
00007d55df7dd917  vmovaps [rsp+0x50], xmm5
00007d55df7dd91d  vmovaps [rsp+0x60], xmm6
00007d55df7dd923  vmovaps [rsp+0x70], xmm7
00007d55df7dd929  vmovaps [rsp+0x80], xmm8
00007d55df7dd932  vmovaps [rsp+0x90], xmm9
00007d55df7dd93b  vmovaps [rsp+0xA0], xmm10
00007d55df7dd944  vmovaps [rsp+0xB0], xmm11
00007d55df7dd94d  vmovaps [rsp+0xC0], xmm12
00007d55df7dd956  vmovaps [rsp+0xD0], xmm13
00007d55df7dd95f  vmovaps [rsp+0xE0], xmm14
00007d55df7dd968  sub rsp, 0x30
00007d55df7dd96c  movaps [rsp], xmm15
00007d55df7dd971  movaps [rsp+0x10], xmm11
00007d55df7dd977  movaps [rsp+0x20], xmm6
00007d55df7dd97c  lea rdi, [rsp]
00007d55df7dd980  mov esi, 0x00
00007d55df7dd985  mov rax, 0x5BB8433D8530
00007d55df7dd98f  call rax
00007d55df7dd991  movaps xmm15, [rsp]
00007d55df7dd996  add rsp, 0x30
00007d55df7dd99a  vmovaps xmm0, [rsp]
00007d55df7dd99f  vmovaps xmm1, [rsp+0x10]
00007d55df7dd9a5  vmovaps xmm2, [rsp+0x20]
00007d55df7dd9ab  vmovaps xmm3, [rsp+0x30]
00007d55df7dd9b1  vmovaps xmm4, [rsp+0x40]
00007d55df7dd9b7  vmovaps xmm5, [rsp+0x50]
00007d55df7dd9bd  vmovaps xmm6, [rsp+0x60]
00007d55df7dd9c3  vmovaps xmm7, [rsp+0x70]
00007d55df7dd9c9  vmovaps xmm8, [rsp+0x80]
00007d55df7dd9d2  vmovaps xmm9, [rsp+0x90]
00007d55df7dd9db  vmovaps xmm10, [rsp+0xA0]
00007d55df7dd9e4  vmovaps xmm11, [rsp+0xB0]
00007d55df7dd9ed  vmovaps xmm12, [rsp+0xC0]
00007d55df7dd9f6  vmovaps xmm13, [rsp+0xD0]
00007d55df7dd9ff  vmovaps xmm14, [rsp+0xE0]
00007d55df7dda08  add rsp, 0xF0
00007d55df7dda0f  pop r11
00007d55df7dda11  pop r10
00007d55df7dda13  pop r9
00007d55df7dda15  pop r8
00007d55df7dda17  pop rsi
00007d55df7dda18  pop rdi
00007d55df7dda19  pop rdx
00007d55df7dda1a  pop rcx
00007d55df7dda1b  pop rax
00007d55df7dda1c  add rsp, 0x08
00007d55df7dda20  jmp 0x00007D55DF7D9685
00007d55df7dda25  sub rsp, 0x08
00007d55df7dda29  push rax
00007d55df7dda2a  push rcx
00007d55df7dda2b  push rdx
00007d55df7dda2c  push rdi
00007d55df7dda2d  push rsi
00007d55df7dda2e  push r8
00007d55df7dda30  push r9
00007d55df7dda32  push r10
00007d55df7dda34  push r11
00007d55df7dda36  sub rsp, 0xF0
00007d55df7dda3d  vmovaps [rsp], xmm0
00007d55df7dda42  vmovaps [rsp+0x10], xmm1
00007d55df7dda48  vmovaps [rsp+0x20], xmm2
00007d55df7dda4e  vmovaps [rsp+0x30], xmm3
00007d55df7dda54  vmovaps [rsp+0x40], xmm4
00007d55df7dda5a  vmovaps [rsp+0x50], xmm5
00007d55df7dda60  vmovaps [rsp+0x60], xmm6
00007d55df7dda66  vmovaps [rsp+0x70], xmm8
00007d55df7dda6c  vmovaps [rsp+0x80], xmm9
00007d55df7dda75  vmovaps [rsp+0x90], xmm10
00007d55df7dda7e  vmovaps [rsp+0xA0], xmm11
00007d55df7dda87  vmovaps [rsp+0xB0], xmm12
00007d55df7dda90  vmovaps [rsp+0xC0], xmm13
00007d55df7dda99  vmovaps [rsp+0xD0], xmm14
00007d55df7ddaa2  vmovaps [rsp+0xE0], xmm15
00007d55df7ddaab  sub rsp, 0x30
00007d55df7ddaaf  movaps [rsp], xmm7
00007d55df7ddab3  movaps [rsp+0x10], xmm11
00007d55df7ddab9  movaps [rsp+0x20], xmm9
00007d55df7ddabf  lea rdi, [rsp]
00007d55df7ddac3  mov esi, 0x00
00007d55df7ddac8  mov rax, 0x5BB8433D8530
00007d55df7ddad2  call rax
00007d55df7ddad4  movaps xmm7, [rsp]
00007d55df7ddad8  add rsp, 0x30
00007d55df7ddadc  vmovaps xmm0, [rsp]
00007d55df7ddae1  vmovaps xmm1, [rsp+0x10]
00007d55df7ddae7  vmovaps xmm2, [rsp+0x20]
00007d55df7ddaed  vmovaps xmm3, [rsp+0x30]
00007d55df7ddaf3  vmovaps xmm4, [rsp+0x40]
00007d55df7ddaf9  vmovaps xmm5, [rsp+0x50]
00007d55df7ddaff  vmovaps xmm6, [rsp+0x60]
00007d55df7ddb05  vmovaps xmm8, [rsp+0x70]
00007d55df7ddb0b  vmovaps xmm9, [rsp+0x80]
00007d55df7ddb14  vmovaps xmm10, [rsp+0x90]
00007d55df7ddb1d  vmovaps xmm11, [rsp+0xA0]
00007d55df7ddb26  vmovaps xmm12, [rsp+0xB0]
00007d55df7ddb2f  vmovaps xmm13, [rsp+0xC0]
00007d55df7ddb38  vmovaps xmm14, [rsp+0xD0]
00007d55df7ddb41  vmovaps xmm15, [rsp+0xE0]
00007d55df7ddb4a  add rsp, 0xF0
00007d55df7ddb51  pop r11
00007d55df7ddb53  pop r10
00007d55df7ddb55  pop r9
00007d55df7ddb57  pop r8
00007d55df7ddb59  pop rsi
00007d55df7ddb5a  pop rdi
00007d55df7ddb5b  pop rdx
00007d55df7ddb5c  pop rcx
00007d55df7ddb5d  pop rax
00007d55df7ddb5e  add rsp, 0x08
00007d55df7ddb62  jmp 0x00007D55DF7D96B2
00007d55df7ddb67  sub rsp, 0x08
00007d55df7ddb6b  push rax
00007d55df7ddb6c  push rcx
00007d55df7ddb6d  push rdx
00007d55df7ddb6e  push rdi
00007d55df7ddb6f  push rsi
00007d55df7ddb70  push r8
00007d55df7ddb72  push r9
00007d55df7ddb74  push r10
00007d55df7ddb76  push r11
00007d55df7ddb78  sub rsp, 0xF0
00007d55df7ddb7f  vmovaps [rsp], xmm0
00007d55df7ddb84  vmovaps [rsp+0x10], xmm1
00007d55df7ddb8a  vmovaps [rsp+0x20], xmm2
00007d55df7ddb90  vmovaps [rsp+0x30], xmm3
00007d55df7ddb96  vmovaps [rsp+0x40], xmm4
00007d55df7ddb9c  vmovaps [rsp+0x50], xmm5
00007d55df7ddba2  vmovaps [rsp+0x60], xmm6
00007d55df7ddba8  vmovaps [rsp+0x70], xmm7
00007d55df7ddbae  vmovaps [rsp+0x80], xmm8
00007d55df7ddbb7  vmovaps [rsp+0x90], xmm9
00007d55df7ddbc0  vmovaps [rsp+0xA0], xmm10
00007d55df7ddbc9  vmovaps [rsp+0xB0], xmm12
00007d55df7ddbd2  vmovaps [rsp+0xC0], xmm13
00007d55df7ddbdb  vmovaps [rsp+0xD0], xmm14
00007d55df7ddbe4  vmovaps [rsp+0xE0], xmm15
00007d55df7ddbed  sub rsp, 0x30
00007d55df7ddbf1  movaps [rsp], xmm11
00007d55df7ddbf6  movaps [rsp+0x10], xmm10
00007d55df7ddbfc  movaps [rsp+0x20], xmm14
00007d55df7ddc02  lea rdi, [rsp]
00007d55df7ddc06  mov esi, 0x00
00007d55df7ddc0b  mov rax, 0x5BB8433D8530
00007d55df7ddc15  call rax
00007d55df7ddc17  movaps xmm11, [rsp]
00007d55df7ddc1c  add rsp, 0x30
00007d55df7ddc20  vmovaps xmm0, [rsp]
00007d55df7ddc25  vmovaps xmm1, [rsp+0x10]
00007d55df7ddc2b  vmovaps xmm2, [rsp+0x20]
00007d55df7ddc31  vmovaps xmm3, [rsp+0x30]
00007d55df7ddc37  vmovaps xmm4, [rsp+0x40]
00007d55df7ddc3d  vmovaps xmm5, [rsp+0x50]
00007d55df7ddc43  vmovaps xmm6, [rsp+0x60]
00007d55df7ddc49  vmovaps xmm7, [rsp+0x70]
00007d55df7ddc4f  vmovaps xmm8, [rsp+0x80]
00007d55df7ddc58  vmovaps xmm9, [rsp+0x90]
00007d55df7ddc61  vmovaps xmm10, [rsp+0xA0]
00007d55df7ddc6a  vmovaps xmm12, [rsp+0xB0]
00007d55df7ddc73  vmovaps xmm13, [rsp+0xC0]
00007d55df7ddc7c  vmovaps xmm14, [rsp+0xD0]
00007d55df7ddc85  vmovaps xmm15, [rsp+0xE0]
00007d55df7ddc8e  add rsp, 0xF0
00007d55df7ddc95  pop r11
00007d55df7ddc97  pop r10
00007d55df7ddc99  pop r9
00007d55df7ddc9b  pop r8
00007d55df7ddc9d  pop rsi
00007d55df7ddc9e  pop rdi
00007d55df7ddc9f  pop rdx
00007d55df7ddca0  pop rcx
00007d55df7ddca1  pop rax
00007d55df7ddca2  add rsp, 0x08
00007d55df7ddca6  jmp 0x00007D55DF7D96CD
00007d55df7ddcab  call 0x00007D55DF6E45A0
00007d55df7ddcb0  jmp 0x00007D55DF7D96D7
00007d55df7ddcb5  sub rsp, 0x08
00007d55df7ddcb9  push rax
00007d55df7ddcba  push rcx
00007d55df7ddcbb  push rdx
00007d55df7ddcbc  push rdi
00007d55df7ddcbd  push rsi
00007d55df7ddcbe  push r8
00007d55df7ddcc0  push r9
00007d55df7ddcc2  push r10
00007d55df7ddcc4  push r11
00007d55df7ddcc6  sub rsp, 0xF0
00007d55df7ddccd  vmovaps [rsp], xmm0
00007d55df7ddcd2  vmovaps [rsp+0x10], xmm1
00007d55df7ddcd8  vmovaps [rsp+0x20], xmm2
00007d55df7ddcde  vmovaps [rsp+0x30], xmm3
00007d55df7ddce4  vmovaps [rsp+0x40], xmm4
00007d55df7ddcea  vmovaps [rsp+0x50], xmm5
00007d55df7ddcf0  vmovaps [rsp+0x60], xmm6
00007d55df7ddcf6  vmovaps [rsp+0x70], xmm7
00007d55df7ddcfc  vmovaps [rsp+0x80], xmm8
00007d55df7ddd05  vmovaps [rsp+0x90], xmm9
00007d55df7ddd0e  vmovaps [rsp+0xA0], xmm11
00007d55df7ddd17  vmovaps [rsp+0xB0], xmm12
00007d55df7ddd20  vmovaps [rsp+0xC0], xmm13
00007d55df7ddd29  vmovaps [rsp+0xD0], xmm14
00007d55df7ddd32  vmovaps [rsp+0xE0], xmm15
00007d55df7ddd3b  sub rsp, 0x30
00007d55df7ddd3f  movaps [rsp], xmm10
00007d55df7ddd44  movaps [rsp+0x10], xmm1
00007d55df7ddd49  movaps [rsp+0x20], xmm12
00007d55df7ddd4f  lea rdi, [rsp]
00007d55df7ddd53  mov esi, 0x00
00007d55df7ddd58  mov rax, 0x5BB8433D8530
00007d55df7ddd62  call rax
00007d55df7ddd64  movaps xmm10, [rsp]
00007d55df7ddd69  add rsp, 0x30
00007d55df7ddd6d  vmovaps xmm0, [rsp]
00007d55df7ddd72  vmovaps xmm1, [rsp+0x10]
00007d55df7ddd78  vmovaps xmm2, [rsp+0x20]
00007d55df7ddd7e  vmovaps xmm3, [rsp+0x30]
00007d55df7ddd84  vmovaps xmm4, [rsp+0x40]
00007d55df7ddd8a  vmovaps xmm5, [rsp+0x50]
00007d55df7ddd90  vmovaps xmm6, [rsp+0x60]
00007d55df7ddd96  vmovaps xmm7, [rsp+0x70]
00007d55df7ddd9c  vmovaps xmm8, [rsp+0x80]
00007d55df7ddda5  vmovaps xmm9, [rsp+0x90]
00007d55df7dddae  vmovaps xmm11, [rsp+0xA0]
00007d55df7dddb7  vmovaps xmm12, [rsp+0xB0]
00007d55df7dddc0  vmovaps xmm13, [rsp+0xC0]
00007d55df7dddc9  vmovaps xmm14, [rsp+0xD0]
00007d55df7dddd2  vmovaps xmm15, [rsp+0xE0]
00007d55df7ddddb  add rsp, 0xF0
00007d55df7ddde2  pop r11
00007d55df7ddde4  pop r10
00007d55df7ddde6  pop r9
00007d55df7ddde8  pop r8
00007d55df7dddea  pop rsi
00007d55df7dddeb  pop rdi
00007d55df7dddec  pop rdx
00007d55df7ddded  pop rcx
00007d55df7dddee  pop rax
00007d55df7dddef  add rsp, 0x08
00007d55df7dddf3  jmp 0x00007D55DF7D96FA
00007d55df7dddf8  sub rsp, 0x08
00007d55df7dddfc  push rax
00007d55df7dddfd  push rcx
00007d55df7dddfe  push rdx
00007d55df7dddff  push rdi
00007d55df7dde00  push rsi
00007d55df7dde01  push r8
00007d55df7dde03  push r9
00007d55df7dde05  push r10
00007d55df7dde07  push r11
00007d55df7dde09  sub rsp, 0xF0
00007d55df7dde10  vmovaps [rsp], xmm0
00007d55df7dde15  vmovaps [rsp+0x10], xmm1
00007d55df7dde1b  vmovaps [rsp+0x20], xmm2
00007d55df7dde21  vmovaps [rsp+0x30], xmm3
00007d55df7dde27  vmovaps [rsp+0x40], xmm4
00007d55df7dde2d  vmovaps [rsp+0x50], xmm5
00007d55df7dde33  vmovaps [rsp+0x60], xmm6
00007d55df7dde39  vmovaps [rsp+0x70], xmm7
00007d55df7dde3f  vmovaps [rsp+0x80], xmm8
00007d55df7dde48  vmovaps [rsp+0x90], xmm9
00007d55df7dde51  vmovaps [rsp+0xA0], xmm10
00007d55df7dde5a  vmovaps [rsp+0xB0], xmm11
00007d55df7dde63  vmovaps [rsp+0xC0], xmm13
00007d55df7dde6c  vmovaps [rsp+0xD0], xmm14
00007d55df7dde75  vmovaps [rsp+0xE0], xmm15
00007d55df7dde7e  sub rsp, 0x30
00007d55df7dde82  movaps [rsp], xmm12
00007d55df7dde87  movaps [rsp+0x10], xmm14
00007d55df7dde8d  movaps [rsp+0x20], xmm1
00007d55df7dde92  lea rdi, [rsp]
00007d55df7dde96  mov esi, 0x00
00007d55df7dde9b  mov rax, 0x5BB8433D8530
00007d55df7ddea5  call rax
00007d55df7ddea7  movaps xmm12, [rsp]
00007d55df7ddeac  add rsp, 0x30
00007d55df7ddeb0  vmovaps xmm0, [rsp]
00007d55df7ddeb5  vmovaps xmm1, [rsp+0x10]
00007d55df7ddebb  vmovaps xmm2, [rsp+0x20]
00007d55df7ddec1  vmovaps xmm3, [rsp+0x30]
00007d55df7ddec7  vmovaps xmm4, [rsp+0x40]
00007d55df7ddecd  vmovaps xmm5, [rsp+0x50]
00007d55df7dded3  vmovaps xmm6, [rsp+0x60]
00007d55df7dded9  vmovaps xmm7, [rsp+0x70]
00007d55df7ddedf  vmovaps xmm8, [rsp+0x80]
00007d55df7ddee8  vmovaps xmm9, [rsp+0x90]
00007d55df7ddef1  vmovaps xmm10, [rsp+0xA0]
00007d55df7ddefa  vmovaps xmm11, [rsp+0xB0]
00007d55df7ddf03  vmovaps xmm13, [rsp+0xC0]
00007d55df7ddf0c  vmovaps xmm14, [rsp+0xD0]
00007d55df7ddf15  vmovaps xmm15, [rsp+0xE0]
00007d55df7ddf1e  add rsp, 0xF0
00007d55df7ddf25  pop r11
00007d55df7ddf27  pop r10
00007d55df7ddf29  pop r9
00007d55df7ddf2b  pop r8
00007d55df7ddf2d  pop rsi
00007d55df7ddf2e  pop rdi
00007d55df7ddf2f  pop rdx
00007d55df7ddf30  pop rcx
00007d55df7ddf31  pop rax
00007d55df7ddf32  add rsp, 0x08
00007d55df7ddf36  jmp 0x00007D55DF7D9729
00007d55df7ddf3b  sub rsp, 0x08
00007d55df7ddf3f  push rax
00007d55df7ddf40  push rcx
00007d55df7ddf41  push rdx
00007d55df7ddf42  push rdi
00007d55df7ddf43  push rsi
00007d55df7ddf44  push r8
00007d55df7ddf46  push r9
00007d55df7ddf48  push r10
00007d55df7ddf4a  push r11
00007d55df7ddf4c  sub rsp, 0xF0
00007d55df7ddf53  vmovaps [rsp], xmm0
00007d55df7ddf58  vmovaps [rsp+0x10], xmm1
00007d55df7ddf5e  vmovaps [rsp+0x20], xmm2
00007d55df7ddf64  vmovaps [rsp+0x30], xmm3
00007d55df7ddf6a  vmovaps [rsp+0x40], xmm4
00007d55df7ddf70  vmovaps [rsp+0x50], xmm5
00007d55df7ddf76  vmovaps [rsp+0x60], xmm6
00007d55df7ddf7c  vmovaps [rsp+0x70], xmm7
00007d55df7ddf82  vmovaps [rsp+0x80], xmm8
00007d55df7ddf8b  vmovaps [rsp+0x90], xmm9
00007d55df7ddf94  vmovaps [rsp+0xA0], xmm10
00007d55df7ddf9d  vmovaps [rsp+0xB0], xmm11
00007d55df7ddfa6  vmovaps [rsp+0xC0], xmm12
00007d55df7ddfaf  vmovaps [rsp+0xD0], xmm13
00007d55df7ddfb8  vmovaps [rsp+0xE0], xmm15
00007d55df7ddfc1  sub rsp, 0x30
00007d55df7ddfc5  movaps [rsp], xmm14
00007d55df7ddfca  movaps [rsp+0x10], xmm9
00007d55df7ddfd0  movaps [rsp+0x20], xmm1
00007d55df7ddfd5  lea rdi, [rsp]
00007d55df7ddfd9  mov esi, 0x00
00007d55df7ddfde  mov rax, 0x5BB8433D8530
00007d55df7ddfe8  call rax
00007d55df7ddfea  movaps xmm14, [rsp]
00007d55df7ddfef  add rsp, 0x30
00007d55df7ddff3  vmovaps xmm0, [rsp]
00007d55df7ddff8  vmovaps xmm1, [rsp+0x10]
00007d55df7ddffe  vmovaps xmm2, [rsp+0x20]
00007d55df7de004  vmovaps xmm3, [rsp+0x30]
00007d55df7de00a  vmovaps xmm4, [rsp+0x40]
00007d55df7de010  vmovaps xmm5, [rsp+0x50]
00007d55df7de016  vmovaps xmm6, [rsp+0x60]
00007d55df7de01c  vmovaps xmm7, [rsp+0x70]
00007d55df7de022  vmovaps xmm8, [rsp+0x80]
00007d55df7de02b  vmovaps xmm9, [rsp+0x90]
00007d55df7de034  vmovaps xmm10, [rsp+0xA0]
00007d55df7de03d  vmovaps xmm11, [rsp+0xB0]
00007d55df7de046  vmovaps xmm12, [rsp+0xC0]
00007d55df7de04f  vmovaps xmm13, [rsp+0xD0]
00007d55df7de058  vmovaps xmm15, [rsp+0xE0]
00007d55df7de061  add rsp, 0xF0
00007d55df7de068  pop r11
00007d55df7de06a  pop r10
00007d55df7de06c  pop r9
00007d55df7de06e  pop r8
00007d55df7de070  pop rsi
00007d55df7de071  pop rdi
00007d55df7de072  pop rdx
00007d55df7de073  pop rcx
00007d55df7de074  pop rax
00007d55df7de075  add rsp, 0x08
00007d55df7de079  jmp 0x00007D55DF7D9758
00007d55df7de07e  sub rsp, 0x08
00007d55df7de082  push rax
00007d55df7de083  push rcx
00007d55df7de084  push rdx
00007d55df7de085  push rdi
00007d55df7de086  push rsi
00007d55df7de087  push r8
00007d55df7de089  push r9
00007d55df7de08b  push r10
00007d55df7de08d  push r11
00007d55df7de08f  sub rsp, 0xF0
00007d55df7de096  vmovaps [rsp], xmm0
00007d55df7de09b  vmovaps [rsp+0x10], xmm2
00007d55df7de0a1  vmovaps [rsp+0x20], xmm3
00007d55df7de0a7  vmovaps [rsp+0x30], xmm4
00007d55df7de0ad  vmovaps [rsp+0x40], xmm5
00007d55df7de0b3  vmovaps [rsp+0x50], xmm6
00007d55df7de0b9  vmovaps [rsp+0x60], xmm7
00007d55df7de0bf  vmovaps [rsp+0x70], xmm8
00007d55df7de0c5  vmovaps [rsp+0x80], xmm9
00007d55df7de0ce  vmovaps [rsp+0x90], xmm10
00007d55df7de0d7  vmovaps [rsp+0xA0], xmm11
00007d55df7de0e0  vmovaps [rsp+0xB0], xmm12
00007d55df7de0e9  vmovaps [rsp+0xC0], xmm13
00007d55df7de0f2  vmovaps [rsp+0xD0], xmm14
00007d55df7de0fb  vmovaps [rsp+0xE0], xmm15
00007d55df7de104  sub rsp, 0x30
00007d55df7de108  movaps [rsp], xmm1
00007d55df7de10c  movaps [rsp+0x10], xmm13
00007d55df7de112  movaps [rsp+0x20], xmm8
00007d55df7de118  lea rdi, [rsp]
00007d55df7de11c  mov esi, 0x00
00007d55df7de121  mov rax, 0x5BB8433D8530
00007d55df7de12b  call rax
00007d55df7de12d  movaps xmm1, [rsp]
00007d55df7de131  add rsp, 0x30
00007d55df7de135  vmovaps xmm0, [rsp]
00007d55df7de13a  vmovaps xmm2, [rsp+0x10]
00007d55df7de140  vmovaps xmm3, [rsp+0x20]
00007d55df7de146  vmovaps xmm4, [rsp+0x30]
00007d55df7de14c  vmovaps xmm5, [rsp+0x40]
00007d55df7de152  vmovaps xmm6, [rsp+0x50]
00007d55df7de158  vmovaps xmm7, [rsp+0x60]
00007d55df7de15e  vmovaps xmm8, [rsp+0x70]
00007d55df7de164  vmovaps xmm9, [rsp+0x80]
00007d55df7de16d  vmovaps xmm10, [rsp+0x90]
00007d55df7de176  vmovaps xmm11, [rsp+0xA0]
00007d55df7de17f  vmovaps xmm12, [rsp+0xB0]
00007d55df7de188  vmovaps xmm13, [rsp+0xC0]
00007d55df7de191  vmovaps xmm14, [rsp+0xD0]
00007d55df7de19a  vmovaps xmm15, [rsp+0xE0]
00007d55df7de1a3  add rsp, 0xF0
00007d55df7de1aa  pop r11
00007d55df7de1ac  pop r10
00007d55df7de1ae  pop r9
00007d55df7de1b0  pop r8
00007d55df7de1b2  pop rsi
00007d55df7de1b3  pop rdi
00007d55df7de1b4  pop rdx
00007d55df7de1b5  pop rcx
00007d55df7de1b6  pop rax
00007d55df7de1b7  add rsp, 0x08
00007d55df7de1bb  jmp 0x00007D55DF7D977A
00007d55df7de1c0  call 0x00007D55DF60C260
00007d55df7de1c5  jmp 0x00007D55DF7D9788
00007d55df7de1ca  call 0x00007D55DF6DE950
00007d55df7de1cf  jmp 0x00007D55DF7D9792
00007d55df7de1d4  sub rsp, 0x08
00007d55df7de1d8  push rax
00007d55df7de1d9  push rcx
00007d55df7de1da  push rdx
00007d55df7de1db  push rdi
00007d55df7de1dc  push rsi
00007d55df7de1dd  push r8
00007d55df7de1df  push r9
00007d55df7de1e1  push r10
00007d55df7de1e3  push r11
00007d55df7de1e5  sub rsp, 0xF0
00007d55df7de1ec  vmovaps [rsp], xmm0
00007d55df7de1f1  vmovaps [rsp+0x10], xmm1
00007d55df7de1f7  vmovaps [rsp+0x20], xmm2
00007d55df7de1fd  vmovaps [rsp+0x30], xmm3
00007d55df7de203  vmovaps [rsp+0x40], xmm4
00007d55df7de209  vmovaps [rsp+0x50], xmm5
00007d55df7de20f  vmovaps [rsp+0x60], xmm6
00007d55df7de215  vmovaps [rsp+0x70], xmm7
00007d55df7de21b  vmovaps [rsp+0x80], xmm9
00007d55df7de224  vmovaps [rsp+0x90], xmm10
00007d55df7de22d  vmovaps [rsp+0xA0], xmm11
00007d55df7de236  vmovaps [rsp+0xB0], xmm12
00007d55df7de23f  vmovaps [rsp+0xC0], xmm13
00007d55df7de248  vmovaps [rsp+0xD0], xmm14
00007d55df7de251  vmovaps [rsp+0xE0], xmm15
00007d55df7de25a  sub rsp, 0x30
00007d55df7de25e  movaps [rsp], xmm8
00007d55df7de263  movaps [rsp+0x10], xmm15
00007d55df7de269  movaps [rsp+0x20], xmm7
00007d55df7de26e  lea rdi, [rsp]
00007d55df7de272  mov esi, 0x00
00007d55df7de277  mov rax, 0x5BB8433D8530
00007d55df7de281  call rax
00007d55df7de283  movaps xmm8, [rsp]
00007d55df7de288  add rsp, 0x30
00007d55df7de28c  vmovaps xmm0, [rsp]
00007d55df7de291  vmovaps xmm1, [rsp+0x10]
00007d55df7de297  vmovaps xmm2, [rsp+0x20]
00007d55df7de29d  vmovaps xmm3, [rsp+0x30]
00007d55df7de2a3  vmovaps xmm4, [rsp+0x40]
00007d55df7de2a9  vmovaps xmm5, [rsp+0x50]
00007d55df7de2af  vmovaps xmm6, [rsp+0x60]
00007d55df7de2b5  vmovaps xmm7, [rsp+0x70]
00007d55df7de2bb  vmovaps xmm9, [rsp+0x80]
00007d55df7de2c4  vmovaps xmm10, [rsp+0x90]
00007d55df7de2cd  vmovaps xmm11, [rsp+0xA0]
00007d55df7de2d6  vmovaps xmm12, [rsp+0xB0]
00007d55df7de2df  vmovaps xmm13, [rsp+0xC0]
00007d55df7de2e8  vmovaps xmm14, [rsp+0xD0]
00007d55df7de2f1  vmovaps xmm15, [rsp+0xE0]
00007d55df7de2fa  add rsp, 0xF0
00007d55df7de301  pop r11
00007d55df7de303  pop r10
00007d55df7de305  pop r9
00007d55df7de307  pop r8
00007d55df7de309  pop rsi
00007d55df7de30a  pop rdi
00007d55df7de30b  pop rdx
00007d55df7de30c  pop rcx
00007d55df7de30d  pop rax
00007d55df7de30e  add rsp, 0x08
00007d55df7de312  jmp 0x00007D55DF7D97B4
00007d55df7de317  sub rsp, 0x08
00007d55df7de31b  push rax
00007d55df7de31c  push rcx
00007d55df7de31d  push rdx
00007d55df7de31e  push rdi
00007d55df7de31f  push rsi
00007d55df7de320  push r8
00007d55df7de322  push r9
00007d55df7de324  push r10
00007d55df7de326  push r11
00007d55df7de328  sub rsp, 0xF0
00007d55df7de32f  vmovaps [rsp], xmm0
00007d55df7de334  vmovaps [rsp+0x10], xmm1
00007d55df7de33a  vmovaps [rsp+0x20], xmm2
00007d55df7de340  vmovaps [rsp+0x30], xmm3
00007d55df7de346  vmovaps [rsp+0x40], xmm4
00007d55df7de34c  vmovaps [rsp+0x50], xmm5
00007d55df7de352  vmovaps [rsp+0x60], xmm6
00007d55df7de358  vmovaps [rsp+0x70], xmm8
00007d55df7de35e  vmovaps [rsp+0x80], xmm9
00007d55df7de367  vmovaps [rsp+0x90], xmm10
00007d55df7de370  vmovaps [rsp+0xA0], xmm11
00007d55df7de379  vmovaps [rsp+0xB0], xmm12
00007d55df7de382  vmovaps [rsp+0xC0], xmm13
00007d55df7de38b  vmovaps [rsp+0xD0], xmm14
00007d55df7de394  vmovaps [rsp+0xE0], xmm15
00007d55df7de39d  sub rsp, 0x30
00007d55df7de3a1  movaps [rsp], xmm7
00007d55df7de3a5  movaps [rsp+0x10], xmm9
00007d55df7de3ab  movaps [rsp+0x20], xmm15
00007d55df7de3b1  lea rdi, [rsp]
00007d55df7de3b5  mov esi, 0x00
00007d55df7de3ba  mov rax, 0x5BB8433D8530
00007d55df7de3c4  call rax
00007d55df7de3c6  movaps xmm7, [rsp]
00007d55df7de3ca  add rsp, 0x30
00007d55df7de3ce  vmovaps xmm0, [rsp]
00007d55df7de3d3  vmovaps xmm1, [rsp+0x10]
00007d55df7de3d9  vmovaps xmm2, [rsp+0x20]
00007d55df7de3df  vmovaps xmm3, [rsp+0x30]
00007d55df7de3e5  vmovaps xmm4, [rsp+0x40]
00007d55df7de3eb  vmovaps xmm5, [rsp+0x50]
00007d55df7de3f1  vmovaps xmm6, [rsp+0x60]
00007d55df7de3f7  vmovaps xmm8, [rsp+0x70]
00007d55df7de3fd  vmovaps xmm9, [rsp+0x80]
00007d55df7de406  vmovaps xmm10, [rsp+0x90]
00007d55df7de40f  vmovaps xmm11, [rsp+0xA0]
00007d55df7de418  vmovaps xmm12, [rsp+0xB0]
00007d55df7de421  vmovaps xmm13, [rsp+0xC0]
00007d55df7de42a  vmovaps xmm14, [rsp+0xD0]
00007d55df7de433  vmovaps xmm15, [rsp+0xE0]
00007d55df7de43c  add rsp, 0xF0
00007d55df7de443  pop r11
00007d55df7de445  pop r10
00007d55df7de447  pop r9
00007d55df7de449  pop r8
00007d55df7de44b  pop rsi
00007d55df7de44c  pop rdi
00007d55df7de44d  pop rdx
00007d55df7de44e  pop rcx
00007d55df7de44f  pop rax
00007d55df7de450  add rsp, 0x08
00007d55df7de454  jmp 0x00007D55DF7D97E1
00007d55df7de459  sub rsp, 0x08
00007d55df7de45d  push rax
00007d55df7de45e  push rcx
00007d55df7de45f  push rdx
00007d55df7de460  push rdi
00007d55df7de461  push rsi
00007d55df7de462  push r8
00007d55df7de464  push r9
00007d55df7de466  push r10
00007d55df7de468  push r11
00007d55df7de46a  sub rsp, 0xF0
00007d55df7de471  vmovaps [rsp], xmm0
00007d55df7de476  vmovaps [rsp+0x10], xmm1
00007d55df7de47c  vmovaps [rsp+0x20], xmm2
00007d55df7de482  vmovaps [rsp+0x30], xmm3
00007d55df7de488  vmovaps [rsp+0x40], xmm4
00007d55df7de48e  vmovaps [rsp+0x50], xmm5
00007d55df7de494  vmovaps [rsp+0x60], xmm6
00007d55df7de49a  vmovaps [rsp+0x70], xmm7
00007d55df7de4a0  vmovaps [rsp+0x80], xmm8
00007d55df7de4a9  vmovaps [rsp+0x90], xmm10
00007d55df7de4b2  vmovaps [rsp+0xA0], xmm11
00007d55df7de4bb  vmovaps [rsp+0xB0], xmm12
00007d55df7de4c4  vmovaps [rsp+0xC0], xmm13
00007d55df7de4cd  vmovaps [rsp+0xD0], xmm14
00007d55df7de4d6  vmovaps [rsp+0xE0], xmm15
00007d55df7de4df  sub rsp, 0x30
00007d55df7de4e3  movaps [rsp], xmm9
00007d55df7de4e8  movaps [rsp+0x10], xmm13
00007d55df7de4ee  movaps [rsp+0x20], xmm15
00007d55df7de4f4  lea rdi, [rsp]
00007d55df7de4f8  mov esi, 0x00
00007d55df7de4fd  mov rax, 0x5BB8433D8530
00007d55df7de507  call rax
00007d55df7de509  movaps xmm9, [rsp]
00007d55df7de50e  add rsp, 0x30
00007d55df7de512  vmovaps xmm0, [rsp]
00007d55df7de517  vmovaps xmm1, [rsp+0x10]
00007d55df7de51d  vmovaps xmm2, [rsp+0x20]
00007d55df7de523  vmovaps xmm3, [rsp+0x30]
00007d55df7de529  vmovaps xmm4, [rsp+0x40]
00007d55df7de52f  vmovaps xmm5, [rsp+0x50]
00007d55df7de535  vmovaps xmm6, [rsp+0x60]
00007d55df7de53b  vmovaps xmm7, [rsp+0x70]
00007d55df7de541  vmovaps xmm8, [rsp+0x80]
00007d55df7de54a  vmovaps xmm10, [rsp+0x90]
00007d55df7de553  vmovaps xmm11, [rsp+0xA0]
00007d55df7de55c  vmovaps xmm12, [rsp+0xB0]
00007d55df7de565  vmovaps xmm13, [rsp+0xC0]
00007d55df7de56e  vmovaps xmm14, [rsp+0xD0]
00007d55df7de577  vmovaps xmm15, [rsp+0xE0]
00007d55df7de580  add rsp, 0xF0
00007d55df7de587  pop r11
00007d55df7de589  pop r10
00007d55df7de58b  pop r9
00007d55df7de58d  pop r8
00007d55df7de58f  pop rsi
00007d55df7de590  pop rdi
00007d55df7de591  pop rdx
00007d55df7de592  pop rcx
00007d55df7de593  pop rax
00007d55df7de594  add rsp, 0x08
00007d55df7de598  jmp 0x00007D55DF7D980F
00007d55df7de59d  sub rsp, 0x08
00007d55df7de5a1  push rax
00007d55df7de5a2  push rcx
00007d55df7de5a3  push rdx
00007d55df7de5a4  push rdi
00007d55df7de5a5  push rsi
00007d55df7de5a6  push r8
00007d55df7de5a8  push r9
00007d55df7de5aa  push r10
00007d55df7de5ac  push r11
00007d55df7de5ae  sub rsp, 0xF0
00007d55df7de5b5  vmovaps [rsp], xmm0
00007d55df7de5ba  vmovaps [rsp+0x10], xmm1
00007d55df7de5c0  vmovaps [rsp+0x20], xmm2
00007d55df7de5c6  vmovaps [rsp+0x30], xmm3
00007d55df7de5cc  vmovaps [rsp+0x40], xmm4
00007d55df7de5d2  vmovaps [rsp+0x50], xmm5
00007d55df7de5d8  vmovaps [rsp+0x60], xmm6
00007d55df7de5de  vmovaps [rsp+0x70], xmm7
00007d55df7de5e4  vmovaps [rsp+0x80], xmm8
00007d55df7de5ed  vmovaps [rsp+0x90], xmm9
00007d55df7de5f6  vmovaps [rsp+0xA0], xmm10
00007d55df7de5ff  vmovaps [rsp+0xB0], xmm11
00007d55df7de608  vmovaps [rsp+0xC0], xmm12
00007d55df7de611  vmovaps [rsp+0xD0], xmm13
00007d55df7de61a  vmovaps [rsp+0xE0], xmm14
00007d55df7de623  sub rsp, 0x30
00007d55df7de627  movaps [rsp], xmm15
00007d55df7de62c  movaps [rsp+0x10], xmm11
00007d55df7de632  movaps [rsp+0x20], xmm12
00007d55df7de638  lea rdi, [rsp]
00007d55df7de63c  mov esi, 0x00
00007d55df7de641  mov rax, 0x5BB8433D8530
00007d55df7de64b  call rax
00007d55df7de64d  movaps xmm15, [rsp]
00007d55df7de652  add rsp, 0x30
00007d55df7de656  vmovaps xmm0, [rsp]
00007d55df7de65b  vmovaps xmm1, [rsp+0x10]
00007d55df7de661  vmovaps xmm2, [rsp+0x20]
00007d55df7de667  vmovaps xmm3, [rsp+0x30]
00007d55df7de66d  vmovaps xmm4, [rsp+0x40]
00007d55df7de673  vmovaps xmm5, [rsp+0x50]
00007d55df7de679  vmovaps xmm6, [rsp+0x60]
00007d55df7de67f  vmovaps xmm7, [rsp+0x70]
00007d55df7de685  vmovaps xmm8, [rsp+0x80]
00007d55df7de68e  vmovaps xmm9, [rsp+0x90]
00007d55df7de697  vmovaps xmm10, [rsp+0xA0]
00007d55df7de6a0  vmovaps xmm11, [rsp+0xB0]
00007d55df7de6a9  vmovaps xmm12, [rsp+0xC0]
00007d55df7de6b2  vmovaps xmm13, [rsp+0xD0]
00007d55df7de6bb  vmovaps xmm14, [rsp+0xE0]
00007d55df7de6c4  add rsp, 0xF0
00007d55df7de6cb  pop r11
00007d55df7de6cd  pop r10
00007d55df7de6cf  pop r9
00007d55df7de6d1  pop r8
00007d55df7de6d3  pop rsi
00007d55df7de6d4  pop rdi
00007d55df7de6d5  pop rdx
00007d55df7de6d6  pop rcx
00007d55df7de6d7  pop rax
00007d55df7de6d8  add rsp, 0x08
00007d55df7de6dc  jmp 0x00007D55DF7D982A
00007d55df7de6e1  sub rsp, 0x08
00007d55df7de6e5  push rax
00007d55df7de6e6  push rcx
00007d55df7de6e7  push rdx
00007d55df7de6e8  push rdi
00007d55df7de6e9  push rsi
00007d55df7de6ea  push r8
00007d55df7de6ec  push r9
00007d55df7de6ee  push r10
00007d55df7de6f0  push r11
00007d55df7de6f2  sub rsp, 0xF0
00007d55df7de6f9  vmovaps [rsp], xmm0
00007d55df7de6fe  vmovaps [rsp+0x10], xmm1
00007d55df7de704  vmovaps [rsp+0x20], xmm2
00007d55df7de70a  vmovaps [rsp+0x30], xmm3
00007d55df7de710  vmovaps [rsp+0x40], xmm4
00007d55df7de716  vmovaps [rsp+0x50], xmm5
00007d55df7de71c  vmovaps [rsp+0x60], xmm6
00007d55df7de722  vmovaps [rsp+0x70], xmm7
00007d55df7de728  vmovaps [rsp+0x80], xmm8
00007d55df7de731  vmovaps [rsp+0x90], xmm9
00007d55df7de73a  vmovaps [rsp+0xA0], xmm10
00007d55df7de743  vmovaps [rsp+0xB0], xmm11
00007d55df7de74c  vmovaps [rsp+0xC0], xmm12
00007d55df7de755  vmovaps [rsp+0xD0], xmm14
00007d55df7de75e  vmovaps [rsp+0xE0], xmm15
00007d55df7de767  sub rsp, 0x30
00007d55df7de76b  movaps [rsp], xmm13
00007d55df7de770  movaps [rsp+0x10], xmm10
00007d55df7de776  movaps [rsp+0x20], xmm14
00007d55df7de77c  lea rdi, [rsp]
00007d55df7de780  mov esi, 0x00
00007d55df7de785  mov rax, 0x5BB8433D8530
00007d55df7de78f  call rax
00007d55df7de791  movaps xmm13, [rsp]
00007d55df7de796  add rsp, 0x30
00007d55df7de79a  vmovaps xmm0, [rsp]
00007d55df7de79f  vmovaps xmm1, [rsp+0x10]
00007d55df7de7a5  vmovaps xmm2, [rsp+0x20]
00007d55df7de7ab  vmovaps xmm3, [rsp+0x30]
00007d55df7de7b1  vmovaps xmm4, [rsp+0x40]
00007d55df7de7b7  vmovaps xmm5, [rsp+0x50]
00007d55df7de7bd  vmovaps xmm6, [rsp+0x60]
00007d55df7de7c3  vmovaps xmm7, [rsp+0x70]
00007d55df7de7c9  vmovaps xmm8, [rsp+0x80]
00007d55df7de7d2  vmovaps xmm9, [rsp+0x90]
00007d55df7de7db  vmovaps xmm10, [rsp+0xA0]
00007d55df7de7e4  vmovaps xmm11, [rsp+0xB0]
00007d55df7de7ed  vmovaps xmm12, [rsp+0xC0]
00007d55df7de7f6  vmovaps xmm14, [rsp+0xD0]
00007d55df7de7ff  vmovaps xmm15, [rsp+0xE0]
00007d55df7de808  add rsp, 0xF0
00007d55df7de80f  pop r11
00007d55df7de811  pop r10
00007d55df7de813  pop r9
00007d55df7de815  pop r8
00007d55df7de817  pop rsi
00007d55df7de818  pop rdi
00007d55df7de819  pop rdx
00007d55df7de81a  pop rcx
00007d55df7de81b  pop rax
00007d55df7de81c  add rsp, 0x08
00007d55df7de820  jmp 0x00007D55DF7D984D
00007d55df7de825  sub rsp, 0x08
00007d55df7de829  push rax
00007d55df7de82a  push rcx
00007d55df7de82b  push rdx
00007d55df7de82c  push rdi
00007d55df7de82d  push rsi
00007d55df7de82e  push r8
00007d55df7de830  push r9
00007d55df7de832  push r10
00007d55df7de834  push r11
00007d55df7de836  sub rsp, 0xF0
00007d55df7de83d  vmovaps [rsp], xmm0
00007d55df7de842  vmovaps [rsp+0x10], xmm1
00007d55df7de848  vmovaps [rsp+0x20], xmm2
00007d55df7de84e  vmovaps [rsp+0x30], xmm3
00007d55df7de854  vmovaps [rsp+0x40], xmm4
00007d55df7de85a  vmovaps [rsp+0x50], xmm5
00007d55df7de860  vmovaps [rsp+0x60], xmm6
00007d55df7de866  vmovaps [rsp+0x70], xmm7
00007d55df7de86c  vmovaps [rsp+0x80], xmm8
00007d55df7de875  vmovaps [rsp+0x90], xmm9
00007d55df7de87e  vmovaps [rsp+0xA0], xmm10
00007d55df7de887  vmovaps [rsp+0xB0], xmm11
00007d55df7de890  vmovaps [rsp+0xC0], xmm12
00007d55df7de899  vmovaps [rsp+0xD0], xmm13
00007d55df7de8a2  vmovaps [rsp+0xE0], xmm15
00007d55df7de8ab  sub rsp, 0x30
00007d55df7de8af  movaps [rsp], xmm14
00007d55df7de8b4  movaps [rsp+0x10], xmm1
00007d55df7de8b9  movaps [rsp+0x20], xmm7
00007d55df7de8be  lea rdi, [rsp]
00007d55df7de8c2  mov esi, 0x00
00007d55df7de8c7  mov rax, 0x5BB8433D8530
00007d55df7de8d1  call rax
00007d55df7de8d3  movaps xmm14, [rsp]
00007d55df7de8d8  add rsp, 0x30
00007d55df7de8dc  vmovaps xmm0, [rsp]
00007d55df7de8e1  vmovaps xmm1, [rsp+0x10]
00007d55df7de8e7  vmovaps xmm2, [rsp+0x20]
00007d55df7de8ed  vmovaps xmm3, [rsp+0x30]
00007d55df7de8f3  vmovaps xmm4, [rsp+0x40]
00007d55df7de8f9  vmovaps xmm5, [rsp+0x50]
00007d55df7de8ff  vmovaps xmm6, [rsp+0x60]
00007d55df7de905  vmovaps xmm7, [rsp+0x70]
00007d55df7de90b  vmovaps xmm8, [rsp+0x80]
00007d55df7de914  vmovaps xmm9, [rsp+0x90]
00007d55df7de91d  vmovaps xmm10, [rsp+0xA0]
00007d55df7de926  vmovaps xmm11, [rsp+0xB0]
00007d55df7de92f  vmovaps xmm12, [rsp+0xC0]
00007d55df7de938  vmovaps xmm13, [rsp+0xD0]
00007d55df7de941  vmovaps xmm15, [rsp+0xE0]
00007d55df7de94a  add rsp, 0xF0
00007d55df7de951  pop r11
00007d55df7de953  pop r10
00007d55df7de955  pop r9
00007d55df7de957  pop r8
00007d55df7de959  pop rsi
00007d55df7de95a  pop rdi
00007d55df7de95b  pop rdx
00007d55df7de95c  pop rcx
00007d55df7de95d  pop rax
00007d55df7de95e  add rsp, 0x08
00007d55df7de962  jmp 0x00007D55DF7D9870
00007d55df7de967  sub rsp, 0x08
00007d55df7de96b  push rax
00007d55df7de96c  push rcx
00007d55df7de96d  push rdx
00007d55df7de96e  push rdi
00007d55df7de96f  push rsi
00007d55df7de970  push r8
00007d55df7de972  push r9
00007d55df7de974  push r10
00007d55df7de976  push r11
00007d55df7de978  sub rsp, 0xF0
00007d55df7de97f  vmovaps [rsp], xmm0
00007d55df7de984  vmovaps [rsp+0x10], xmm2
00007d55df7de98a  vmovaps [rsp+0x20], xmm3
00007d55df7de990  vmovaps [rsp+0x30], xmm4
00007d55df7de996  vmovaps [rsp+0x40], xmm5
00007d55df7de99c  vmovaps [rsp+0x50], xmm6
00007d55df7de9a2  vmovaps [rsp+0x60], xmm7
00007d55df7de9a8  vmovaps [rsp+0x70], xmm8
00007d55df7de9ae  vmovaps [rsp+0x80], xmm9
00007d55df7de9b7  vmovaps [rsp+0x90], xmm10
00007d55df7de9c0  vmovaps [rsp+0xA0], xmm11
00007d55df7de9c9  vmovaps [rsp+0xB0], xmm12
00007d55df7de9d2  vmovaps [rsp+0xC0], xmm13
00007d55df7de9db  vmovaps [rsp+0xD0], xmm14
00007d55df7de9e4  vmovaps [rsp+0xE0], xmm15
00007d55df7de9ed  sub rsp, 0x30
00007d55df7de9f1  movaps [rsp], xmm1
00007d55df7de9f5  movaps [rsp+0x10], xmm8
00007d55df7de9fb  movaps [rsp+0x20], xmm9
00007d55df7dea01  lea rdi, [rsp]
00007d55df7dea05  mov esi, 0x00
00007d55df7dea0a  mov rax, 0x5BB8433D8530
00007d55df7dea14  call rax
00007d55df7dea16  movaps xmm1, [rsp]
00007d55df7dea1a  add rsp, 0x30
00007d55df7dea1e  vmovaps xmm0, [rsp]
00007d55df7dea23  vmovaps xmm2, [rsp+0x10]
00007d55df7dea29  vmovaps xmm3, [rsp+0x20]
00007d55df7dea2f  vmovaps xmm4, [rsp+0x30]
00007d55df7dea35  vmovaps xmm5, [rsp+0x40]
00007d55df7dea3b  vmovaps xmm6, [rsp+0x50]
00007d55df7dea41  vmovaps xmm7, [rsp+0x60]
00007d55df7dea47  vmovaps xmm8, [rsp+0x70]
00007d55df7dea4d  vmovaps xmm9, [rsp+0x80]
00007d55df7dea56  vmovaps xmm10, [rsp+0x90]
00007d55df7dea5f  vmovaps xmm11, [rsp+0xA0]
00007d55df7dea68  vmovaps xmm12, [rsp+0xB0]
00007d55df7dea71  vmovaps xmm13, [rsp+0xC0]
00007d55df7dea7a  vmovaps xmm14, [rsp+0xD0]
00007d55df7dea83  vmovaps xmm15, [rsp+0xE0]
00007d55df7dea8c  add rsp, 0xF0
00007d55df7dea93  pop r11
00007d55df7dea95  pop r10
00007d55df7dea97  pop r9
00007d55df7dea99  pop r8
00007d55df7dea9b  pop rsi
00007d55df7dea9c  pop rdi
00007d55df7dea9d  pop rdx
00007d55df7dea9e  pop rcx
00007d55df7dea9f  pop rax
00007d55df7deaa0  add rsp, 0x08
00007d55df7deaa4  jmp 0x00007D55DF7D9892
00007d55df7deaa9  call 0x00007D55DF6B3E40
00007d55df7deaae  jmp 0x00007D55DF7D98A0
00007d55df7deab3  call 0x00007D55DF60C380
00007d55df7deab8  jmp 0x00007D55DF7D98AA
00007d55df7deabd  call 0x00007D55DF60D600
00007d55df7deac2  jmp 0x00007D55DF7D98B4
00007d55df7deac7  call 0x00007D55DF5FF540
00007d55df7deacc  jmp 0x00007D55DF7D98BE
00007d55df7dead1  int3
00007d55df7dead2  nop [rax+rax*1], ax
00007d55df7deadb  nop [rax+rax*1], eax
00007d55df7deae0  mov eax, [r15+0x48]
00007d55df7deae4  lea r14d, [eax+0x01]
00007d55df7deae9  mov [rsp+0x10], r14d
00007d55df7deaee  mov r14d, r14d
00007d55df7deaf1  mov [r15+0x48], r14
00007d55df7deaf5  xor eax, eax
00007d55df7deaf7  mov r14d, [rsp+0x10]
00007d55df7deafc  cmp r14d, 0x1F4
00007d55df7deb03  cmc
00007d55df7deb04  lahf
00007d55df7deb05  seto al
00007d55df7deb08  mov [r15+0x108], eax
00007d55df7deb0f  mov eax, [r15+0x108]
00007d55df7deb16  sahf
00007d55df7deb17  jnz 0x00007D55DF7DEB49
00007d55df7deb19  cmp dword ptr [r15+0x318], 0x00
00007d55df7deb21  jz 0x00007D55DF7E4C90
00007d55df7deb27  nop [rax+rax*1], ax
00007d55df7deb30  nop [rax+rax*1], eax
00007d55df7deb38  mov eax, 0x4106DC
00007d55df7deb3d  mov [r15+0x100], rax
00007d55df7deb44  jmp 0x00007D55DF5FE110
00007d55df7deb49  cmp dword ptr [r15+0x318], 0x00
00007d55df7deb51  jz 0x00007D55DF7DEB80
00007d55df7deb57  nop [rax+rax*1], ax
00007d55df7deb60  nop [rax+rax*1], eax
00007d55df7deb68  mov eax, 0x410500
00007d55df7deb6d  mov [r15+0x100], rax
00007d55df7deb74  jmp 0x00007D55DF5FE110
00007d55df7deb79  int3
00007d55df7deb7a  int3
00007d55df7deb7b  nop [rax+rax*1], eax
00007d55df7deb80  mov rax, [r15+0x40]
00007d55df7deb84  movaps xmm1, [r15+0x1D0]
00007d55df7deb8c  vmovaps [rsp+0x10], xmm1
00007d55df7deb92  vmovaps xmm15, [rsp+0x10]
00007d55df7deb98  por xmm1, xmm15
00007d55df7deb9d  movaps xmm14, [r15+0x1A0]
00007d55df7deba5  vmovaps [rsp+0x10], xmm14
00007d55df7debab  vmovaps xmm13, [rsp+0x10]
00007d55df7debb1  por xmm14, xmm13
00007d55df7debb6  lea r14, [rax+0x30]
00007d55df7debba  mov r12, [r13+r14*1]
00007d55df7debbf  lea r14, [rax+0x38]
00007d55df7debc3  mov r11, [r13+r14*1]
00007d55df7debc8  movq xmm13, r12
00007d55df7debcd  movq xmm12, r11
00007d55df7debd2  movq xmm13, xmm13
00007d55df7debd7  vmovaps [rsp+0x10], xmm13
00007d55df7debdd  movq xmm13, xmm13
00007d55df7debe2  movaps [r15+0x130], xmm13
00007d55df7debea  movq xmm12, xmm12
00007d55df7debef  vmovaps [rsp+0x20], xmm12
00007d55df7debf5  movq xmm12, xmm12
00007d55df7debfa  movaps [r15+0x280], xmm12
00007d55df7dec02  movaps xmm13, [r15+0x270]
00007d55df7dec0a  vmovaps [rsp+0x30], xmm13
00007d55df7dec10  vmovaps xmm12, [rsp+0x30]
00007d55df7dec16  por xmm13, xmm12
00007d55df7dec1b  lea r14, [rax+0x20]
00007d55df7dec1f  mov r12, [r13+r14*1]
00007d55df7dec24  lea r14, [rax+0x28]
00007d55df7dec28  mov r11, [r13+r14*1]
00007d55df7dec2d  movq xmm12, r12
00007d55df7dec32  movq xmm11, r11
00007d55df7dec37  movq xmm12, xmm12
00007d55df7dec3c  vmovaps [rsp+0x30], xmm12
00007d55df7dec42  movq xmm12, xmm12
00007d55df7dec47  movaps [r15+0x150], xmm12
00007d55df7dec4f  movq xmm11, xmm11
00007d55df7dec54  vmovaps [rsp+0x40], xmm11
00007d55df7dec5a  movq xmm11, xmm11
00007d55df7dec5f  movaps [r15+0x140], xmm11
00007d55df7dec67  lea r14, [rax+0x10]
00007d55df7dec6b  mov r12, [r13+r14*1]
00007d55df7dec70  lea r14, [rax+0x18]
00007d55df7dec74  mov r11, [r13+r14*1]
00007d55df7dec79  movq xmm12, r12
00007d55df7dec7e  movq xmm11, r11
00007d55df7dec83  movq xmm12, xmm12
00007d55df7dec88  vmovaps [rsp+0x50], xmm12
00007d55df7dec8e  movq xmm12, xmm12
00007d55df7dec93  movaps [r15+0x170], xmm12
00007d55df7dec9b  movq xmm11, xmm11
00007d55df7deca0  vmovaps [rsp+0x60], xmm11
00007d55df7deca6  movq xmm11, xmm11
00007d55df7decab  movaps [r15+0x160], xmm11
00007d55df7decb3  mov r14, [r13+rax*1]
00007d55df7decb8  vmovq xmm12, r14
00007d55df7decbd  vpbroadcastq xmm12, xmm12
00007d55df7decc2  lea r14, [rax+0x08]
00007d55df7decc6  mov rax, [r13+r14*1]
00007d55df7deccb  movq xmm11, rax
00007d55df7decd0  movaps [r15+0x230], xmm11
00007d55df7decd8  mov rax, [r15+0xF8]
00007d55df7decdf  lea r14, [rax+0x50]
00007d55df7dece3  movups xmm11, [r13+r14*1]
00007d55df7dece9  lea r14, [rax+0x60]
00007d55df7deced  movups xmm10, [r13+r14*1]
00007d55df7decf3  lea r14, [rax+0x30]
00007d55df7decf7  movups xmm9, [r13+r14*1]
00007d55df7decfd  mov r14, [r15+0x50]
00007d55df7ded01  mov [r15+0x60], r14
00007d55df7ded05  mov qword ptr [r15+0x58], 0x40
00007d55df7ded0d  movaps xmm8, xmm12
00007d55df7ded11  mulpd xmm8, xmm15
00007d55df7ded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007d55df7ded1c  ptest xmm7, xmm7
00007d55df7ded21  jnz 0x00007D55DF7DFB4A
00007d55df7ded27  movq xmm15, qword ptr [r15+0x230]
00007d55df7ded30  vmovaps [rsp+0x70], xmm15
00007d55df7ded36  vpermilpd xmm15, xmm15, 0x00
00007d55df7ded3c  movaps xmm7, xmm9
00007d55df7ded40  mulpd xmm7, xmm15
00007d55df7ded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007d55df7ded4a  ptest xmm6, xmm6
00007d55df7ded4f  jnz 0x00007D55DF7DFC8E
00007d55df7ded55  vxorps xmm15, xmm15, xmm15
00007d55df7ded5a  vpbroadcastq xmm15, xmm15
00007d55df7ded5f  movaps xmm9, xmm12
00007d55df7ded63  mulpd xmm9, xmm10
00007d55df7ded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007d55df7ded6e  ptest xmm6, xmm6
00007d55df7ded73  jnz 0x00007D55DF7DFDD0
00007d55df7ded79  movaps xmm10, xmm12
00007d55df7ded7d  mulpd xmm10, xmm11
00007d55df7ded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007d55df7ded88  ptest xmm6, xmm6
00007d55df7ded8d  jnz 0x00007D55DF7DFF14
00007d55df7ded93  movaps xmm11, [r15+0x1F0]
00007d55df7ded9b  movaps xmm6, xmm12
00007d55df7ded9f  mulpd xmm6, xmm11
00007d55df7deda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007d55df7deda9  ptest xmm5, xmm5
00007d55df7dedae  jnz 0x00007D55DF7E0058
00007d55df7dedb4  movaps xmm12, [r15+0x2A0]
00007d55df7dedbc  vmovaps [rsp+0x80], xmm12
00007d55df7dedc5  vmovaps xmm11, [rsp+0x80]
00007d55df7dedce  por xmm12, xmm11
00007d55df7dedd3  movaps xmm11, [r15+0x250]
00007d55df7deddb  vmovaps [rsp+0x80], xmm11
00007d55df7dede4  vmovaps xmm5, [rsp+0x80]
00007d55df7deded  por xmm11, xmm5
00007d55df7dedf2  vmovaps xmm4, [rsp+0x70]
00007d55df7dedf8  vpermilpd xmm4, xmm4, 0x00
00007d55df7dedfe  movaps xmm3, xmm5
00007d55df7dee01  mulpd xmm3, xmm4
00007d55df7dee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007d55df7dee0a  ptest xmm2, xmm2
00007d55df7dee0f  jnz 0x00007D55DF7E019A
00007d55df7dee15  mov [rsp+0x80], rax
00007d55df7dee1d  xor eax, eax
00007d55df7dee1f  mov r12d, 0x40
00007d55df7dee25  mov r11d, 0x200
00007d55df7dee2b  cmp r12, r11
00007d55df7dee2e  cmc
00007d55df7dee2f  lahf
00007d55df7dee30  seto al
00007d55df7dee33  mov [r15+0x108], eax
00007d55df7dee3a  movaps xmm5, xmm8
00007d55df7dee3e  addpd xmm5, xmm15
00007d55df7dee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007d55df7dee48  ptest xmm4, xmm4
00007d55df7dee4d  jnz 0x00007D55DF7E02DA
00007d55df7dee53  movaps xmm8, [r15+0x1B0]
00007d55df7dee5b  movaps xmm4, xmm9
00007d55df7dee5f  addpd xmm4, xmm8
00007d55df7dee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007d55df7dee69  ptest xmm2, xmm2
00007d55df7dee6e  jnz 0x00007D55DF7E041C
00007d55df7dee74  movaps xmm9, xmm10
00007d55df7dee78  addpd xmm9, xmm8
00007d55df7dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007d55df7dee83  ptest xmm2, xmm2
00007d55df7dee88  jnz 0x00007D55DF7E055E
00007d55df7dee8e  movaps xmm10, [r15+0x2F0]
00007d55df7dee96  vmovaps [rsp+0x90], xmm10
00007d55df7dee9f  vmovaps xmm8, [rsp+0x90]
00007d55df7deea8  por xmm10, xmm8
00007d55df7deead  movaps xmm8, [r15+0x2E0]
00007d55df7deeb5  vmovaps [rsp+0x90], xmm8
00007d55df7deebe  vmovaps xmm2, [rsp+0x90]
00007d55df7deec7  por xmm8, xmm2
00007d55df7deecc  movaps xmm2, [r15+0x2D0]
00007d55df7deed4  vmovaps [rsp+0x90], xmm2
00007d55df7deedd  vmovaps [rsp+0xA0], xmm1
00007d55df7deee6  vmovaps xmm1, [rsp+0x90]
00007d55df7deeef  por xmm2, xmm1
00007d55df7deef3  movaps xmm1, [r15+0x200]
00007d55df7deefb  vmovaps [rsp+0x90], xmm1
00007d55df7def04  vmovaps [rsp+0xB0], xmm15
00007d55df7def0d  vmovaps xmm15, [rsp+0x90]
00007d55df7def16  por xmm1, xmm15
00007d55df7def1b  movaps xmm15, [r15+0x1C0]
00007d55df7def23  vmovaps [rsp+0x90], xmm15
00007d55df7def2c  vmovaps [rsp+0xC0], xmm1
00007d55df7def35  vmovaps xmm1, [rsp+0x90]
00007d55df7def3e  por xmm15, xmm1
00007d55df7def43  movaps xmm1, [r15+0x190]
00007d55df7def4b  vmovaps [rsp+0x90], xmm1
00007d55df7def54  vmovaps [rsp+0xD0], xmm15
00007d55df7def5d  vmovaps xmm15, [rsp+0x90]
00007d55df7def66  por xmm1, xmm15
00007d55df7def6b  movaps xmm15, [r15+0x300]
00007d55df7def73  vmovaps [rsp+0x90], xmm15
00007d55df7def7c  vmovaps [rsp+0xE0], xmm1
00007d55df7def85  vmovaps xmm1, [rsp+0x90]
00007d55df7def8e  por xmm15, xmm1
00007d55df7def93  mov rax, [rsp+0x80]
00007d55df7def9b  lea r12, [rax+0xA0]
00007d55df7defa2  movups xmm1, [r13+r12*1]
00007d55df7defa8  lea r12, [rax+0xB0]
00007d55df7defaf  vmovaps [rsp+0x80], xmm1
00007d55df7defb8  movups xmm1, [r13+r12*1]
00007d55df7defbe  vmovaps [rsp+0x90], xmm1
00007d55df7defc7  vmovaps [rsp+0xF0], xmm15
00007d55df7defd0  vmovaps xmm15, [rsp+0xB0]
00007d55df7defd9  vmovaps [rsp+0xB0], xmm14
00007d55df7defe2  movaps xmm1, xmm6
00007d55df7defe5  addpd xmm1, xmm15
00007d55df7defea  vcmppd xmm14, xmm1, xmm1, 0x03
00007d55df7defef  ptest xmm14, xmm14
00007d55df7deff5  jnz 0x00007D55DF7E06B6
00007d55df7deffb  lea r12, [rax+0xF0]
00007d55df7df002  movups xmm15, [r13+r12*1]
00007d55df7df008  movaps xmm14, xmm4
00007d55df7df00c  addpd xmm14, xmm3
00007d55df7df011  vcmppd xmm6, xmm14, xmm14, 0x03
00007d55df7df017  ptest xmm6, xmm6
00007d55df7df01c  jnz 0x00007D55DF7E0801
00007d55df7df022  movaps xmm6, xmm9
00007d55df7df026  addpd xmm6, xmm7
00007d55df7df02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007d55df7df02f  ptest xmm4, xmm4
00007d55df7df034  jnz 0x00007D55DF7E0943
00007d55df7df03a  vmovaps xmm9, [rsp+0x70]
00007d55df7df040  vpermilpd xmm9, xmm9, 0x00
00007d55df7df046  vmovaps xmm4, [rsp+0x90]
00007d55df7df04f  movaps xmm7, xmm4
00007d55df7df052  mulpd xmm7, xmm9
00007d55df7df057  vcmppd xmm3, xmm7, xmm7, 0x03
00007d55df7df05c  ptest xmm3, xmm3
00007d55df7df061  jnz 0x00007D55DF7E0A84
00007d55df7df067  vmovaps xmm9, [rsp+0x50]
00007d55df7df06d  vpermilpd xmm9, xmm9, 0x00
00007d55df7df073  movaps xmm4, xmm15
00007d55df7df077  mulpd xmm4, xmm9
00007d55df7df07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007d55df7df081  ptest xmm3, xmm3
00007d55df7df086  jnz 0x00007D55DF7E0BC5
00007d55df7df08c  lea r12, [rax+0xE0]
00007d55df7df093  movups xmm15, [r13+r12*1]
00007d55df7df099  vmovaps xmm9, [rsp+0x70]
00007d55df7df09f  vpermilpd xmm9, xmm9, 0x00
00007d55df7df0a5  vmovaps [rsp+0x70], xmm1
00007d55df7df0ab  vmovaps xmm1, [rsp+0x80]
00007d55df7df0b4  vmovaps [rsp+0x80], xmm15
00007d55df7df0bd  movaps xmm3, xmm1
00007d55df7df0c0  mulpd xmm3, xmm9
00007d55df7df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007d55df7df0ca  ptest xmm15, xmm15
00007d55df7df0d0  jnz 0x00007D55DF7E0D11
00007d55df7df0d6  vmovaps xmm1, [rsp+0xF0]
00007d55df7df0df  vmovaps xmm15, [rsp+0xF0]
00007d55df7df0e8  por xmm1, xmm15
00007d55df7df0ed  movaps [r15+0x300], xmm1
00007d55df7df0f5  vmovaps xmm15, [rsp+0xE0]
00007d55df7df0fe  vmovaps xmm9, [rsp+0xE0]
00007d55df7df107  por xmm15, xmm9
00007d55df7df10c  movaps [r15+0x190], xmm15
00007d55df7df114  vmovaps xmm9, [rsp+0x50]
00007d55df7df11a  vpermilpd xmm9, xmm9, 0x00
00007d55df7df120  vmovaps [rsp+0x90], xmm1
00007d55df7df129  vmovaps [rsp+0xE0], xmm15
00007d55df7df132  vmovaps xmm15, [rsp+0x80]
00007d55df7df13b  vmovaps [rsp+0x80], xmm14
00007d55df7df144  movaps xmm1, xmm15
00007d55df7df148  mulpd xmm1, xmm9
00007d55df7df14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007d55df7df152  ptest xmm14, xmm14
00007d55df7df158  jnz 0x00007D55DF7E0E52
00007d55df7df15e  lea r12, [rax+0x90]
00007d55df7df165  movups xmm15, [r13+r12*1]
00007d55df7df16b  vmovaps xmm14, [rsp+0xD0]
00007d55df7df174  vmovaps xmm9, [rsp+0xD0]
00007d55df7df17d  por xmm14, xmm9
00007d55df7df182  movaps [r15+0x1C0], xmm14
00007d55df7df18a  vmovaps xmm9, [rsp+0xC0]
00007d55df7df193  vmovaps [rsp+0xD0], xmm1
00007d55df7df19c  vmovaps xmm1, [rsp+0xC0]
00007d55df7df1a5  por xmm9, xmm1
00007d55df7df1aa  movaps [r15+0x200], xmm9
00007d55df7df1b2  vmovaps [rsp+0xC0], xmm2
00007d55df7df1bb  vmovaps xmm1, [rsp+0xC0]
00007d55df7df1c4  por xmm2, xmm1
00007d55df7df1c8  movaps [r15+0x2D0], xmm2
00007d55df7df1d0  vmovaps [rsp+0xC0], xmm8
00007d55df7df1d9  vmovaps xmm1, [rsp+0xC0]
00007d55df7df1e2  por xmm8, xmm1
00007d55df7df1e7  movaps [r15+0x2E0], xmm8
00007d55df7df1ef  vmovaps [rsp+0xC0], xmm15
00007d55df7df1f8  movaps xmm1, xmm5
00007d55df7df1fb  addpd xmm1, xmm7
00007d55df7df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007d55df7df204  ptest xmm15, xmm15
00007d55df7df20a  jnz 0x00007D55DF7E0F9E
00007d55df7df210  vmovaps xmm15, [rsp+0x50]
00007d55df7df216  vpermilpd xmm15, xmm15, 0x00
00007d55df7df21c  vmovaps xmm5, [rsp+0xC0]
00007d55df7df225  vmovaps [rsp+0xC0], xmm1
00007d55df7df22e  movaps xmm7, xmm5
00007d55df7df231  mulpd xmm7, xmm15
00007d55df7df236  vcmppd xmm1, xmm7, xmm7, 0x03
00007d55df7df23b  ptest xmm1, xmm1
00007d55df7df240  jnz 0x00007D55DF7E10DE
00007d55df7df246  lea r12, [rax+0x80]
00007d55df7df24d  movups xmm1, [r13+r12*1]
00007d55df7df253  vmovaps xmm5, [rsp+0x70]
00007d55df7df259  vmovaps [rsp+0x70], xmm1
00007d55df7df25f  movaps xmm15, xmm5
00007d55df7df263  addpd xmm15, xmm3
00007d55df7df268  vcmppd xmm1, xmm15, xmm15, 0x03
00007d55df7df26e  ptest xmm1, xmm1
00007d55df7df273  jnz 0x00007D55DF7E1229
00007d55df7df279  vmovaps xmm5, [rsp+0x80]
00007d55df7df282  movaps xmm1, xmm5
00007d55df7df285  addpd xmm1, xmm4
00007d55df7df289  vcmppd xmm3, xmm1, xmm1, 0x03
00007d55df7df28e  ptest xmm3, xmm3
00007d55df7df293  jnz 0x00007D55DF7E136B
00007d55df7df299  vmovaps [rsp+0x80], xmm10
00007d55df7df2a2  vmovaps xmm5, [rsp+0x80]
00007d55df7df2ab  por xmm10, xmm5
00007d55df7df2b0  movaps [r15+0x2F0], xmm10
00007d55df7df2b8  vmovaps xmm5, [rsp+0x50]
00007d55df7df2be  vpermilpd xmm5, xmm5, 0x00
00007d55df7df2c4  vmovaps xmm3, [rsp+0x70]
00007d55df7df2ca  vmovaps [rsp+0x50], xmm1
00007d55df7df2d0  movaps xmm4, xmm3
00007d55df7df2d3  mulpd xmm4, xmm5
00007d55df7df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007d55df7df2dc  ptest xmm1, xmm1
00007d55df7df2e1  jnz 0x00007D55DF7E14AB
00007d55df7df2e7  lea r12, [rax+0xD0]
00007d55df7df2ee  movups xmm1, [r13+r12*1]
00007d55df7df2f4  vmovaps xmm3, [rsp+0xD0]
00007d55df7df2fd  vmovaps [rsp+0x70], xmm1
00007d55df7df303  movaps xmm5, xmm6
00007d55df7df306  addpd xmm5, xmm3
00007d55df7df30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007d55df7df30f  ptest xmm1, xmm1
00007d55df7df314  jnz 0x00007D55DF7E15F5
00007d55df7df31a  vmovaps xmm1, [rsp+0x60]
00007d55df7df320  vpermilpd xmm1, xmm1, 0x00
00007d55df7df326  movaps xmm6, xmm9
00007d55df7df32a  mulpd xmm6, xmm1
00007d55df7df32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007d55df7df333  ptest xmm3, xmm3
00007d55df7df338  jnz 0x00007D55DF7E1735
00007d55df7df33e  movaps [r15+0x260], xmm6
00007d55df7df346  vxorps xmm1, xmm1, xmm1
00007d55df7df34a  vpbroadcastq xmm1, xmm1
00007d55df7df34f  movaps [r15+0x1B0], xmm1
00007d55df7df357  vmovaps xmm1, [rsp+0x60]
00007d55df7df35d  vpermilpd xmm1, xmm1, 0x00
00007d55df7df363  vmovaps xmm3, [rsp+0x70]
00007d55df7df369  vmovaps [rsp+0x70], xmm15
00007d55df7df36f  movaps xmm9, xmm3
00007d55df7df373  mulpd xmm9, xmm1
00007d55df7df378  vcmppd xmm15, xmm9, xmm9, 0x03
00007d55df7df37e  ptest xmm15, xmm15
00007d55df7df384  jnz 0x00007D55DF7E1876
00007d55df7df38a  lea r12, [rax+0xC0]
00007d55df7df391  movups xmm1, [r13+r12*1]
00007d55df7df397  vmovaps xmm3, [rsp+0xC0]
00007d55df7df3a0  vmovaps [rsp+0x80], xmm1
00007d55df7df3a9  movaps xmm15, xmm3
00007d55df7df3ad  addpd xmm15, xmm7
00007d55df7df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007d55df7df3b8  ptest xmm1, xmm1
00007d55df7df3bd  jnz 0x00007D55DF7E19C2
00007d55df7df3c3  vmovaps [rsp+0xC0], xmm13
00007d55df7df3cc  vmovaps xmm1, [rsp+0xC0]
00007d55df7df3d5  por xmm13, xmm1
00007d55df7df3da  movaps [r15+0x270], xmm13
00007d55df7df3e2  vmovaps xmm1, [rsp+0xB0]
00007d55df7df3eb  vmovaps xmm7, [rsp+0xB0]
00007d55df7df3f4  por xmm1, xmm7
00007d55df7df3f8  movaps [r15+0x1A0], xmm1
00007d55df7df400  vmovaps xmm1, [rsp+0x60]
00007d55df7df406  vpermilpd xmm1, xmm1, 0x00
00007d55df7df40c  vmovaps [rsp+0xB0], xmm1
00007d55df7df415  vmovaps xmm1, [rsp+0x80]
00007d55df7df41e  vmovaps [rsp+0x80], xmm15
00007d55df7df427  vmovaps xmm15, [rsp+0xB0]
00007d55df7df430  vmovaps [rsp+0xB0], xmm14
00007d55df7df439  movaps xmm3, xmm1
00007d55df7df43c  mulpd xmm3, xmm15
00007d55df7df441  vcmppd xmm14, xmm3, xmm3, 0x03
00007d55df7df446  ptest xmm14, xmm14
00007d55df7df44c  jnz 0x00007D55DF7E1B04
00007d55df7df452  lea r12, [rax+0x20]
00007d55df7df456  movups xmm1, [r13+r12*1]
00007d55df7df45c  movaps [r15+0x110], xmm1
00007d55df7df464  vmovaps xmm14, [rsp+0x70]
00007d55df7df46a  vmovaps [rsp+0x70], xmm1
00007d55df7df470  movaps xmm15, xmm14
00007d55df7df474  addpd xmm15, xmm4
00007d55df7df479  vcmppd xmm1, xmm15, xmm15, 0x03
00007d55df7df47f  ptest xmm1, xmm1
00007d55df7df484  jnz 0x00007D55DF7E1C4F
00007d55df7df48a  vmovaps xmm1, [rsp+0x60]
00007d55df7df490  vpermilpd xmm1, xmm1, 0x00
00007d55df7df496  movaps xmm14, xmm2
00007d55df7df49a  mulpd xmm14, xmm1
00007d55df7df49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007d55df7df4a5  ptest xmm4, xmm4
00007d55df7df4aa  jnz 0x00007D55DF7E1D92
00007d55df7df4b0  vmovaps xmm4, [rsp+0x50]
00007d55df7df4b6  movaps xmm1, xmm4
00007d55df7df4b9  addpd xmm1, xmm9
00007d55df7df4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007d55df7df4c3  ptest xmm2, xmm2
00007d55df7df4c8  jnz 0x00007D55DF7E1ED4
00007d55df7df4ce  vmovaps xmm9, [rsp+0x30]
00007d55df7df4d4  vpermilpd xmm9, xmm9, 0x00
00007d55df7df4da  vmovaps xmm2, [rsp+0x70]
00007d55df7df4e0  vmovaps [rsp+0x50], xmm1
00007d55df7df4e6  movaps xmm4, xmm2
00007d55df7df4e9  mulpd xmm4, xmm9
00007d55df7df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007d55df7df4f3  ptest xmm1, xmm1
00007d55df7df4f8  jnz 0x00007D55DF7E2015
00007d55df7df4fe  vmovaps xmm1, [rsp+0x30]
00007d55df7df504  vpermilpd xmm1, xmm1, 0x00
00007d55df7df50a  vmovaps xmm2, [rsp+0x90]
00007d55df7df513  vmovaps [rsp+0x60], xmm15
00007d55df7df519  movaps xmm9, xmm2
00007d55df7df51d  mulpd xmm9, xmm1
00007d55df7df522  vcmppd xmm15, xmm9, xmm9, 0x03
00007d55df7df528  ptest xmm15, xmm15
00007d55df7df52e  jnz 0x00007D55DF7E2156
00007d55df7df534  vmovaps xmm15, [rsp+0x80]
00007d55df7df53d  movaps xmm1, xmm15
00007d55df7df541  addpd xmm1, xmm6
00007d55df7df545  vcmppd xmm2, xmm1, xmm1, 0x03
00007d55df7df54a  ptest xmm2, xmm2
00007d55df7df54f  jnz 0x00007D55DF7E2298
00007d55df7df555  movaps xmm15, xmm5
00007d55df7df559  addpd xmm15, xmm3
00007d55df7df55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007d55df7df564  ptest xmm6, xmm6
00007d55df7df569  jnz 0x00007D55DF7E23D9
00007d55df7df56f  vmovaps xmm6, [rsp+0x30]
00007d55df7df575  vpermilpd xmm6, xmm6, 0x00
00007d55df7df57b  movaps xmm5, xmm8
00007d55df7df57f  mulpd xmm5, xmm6
00007d55df7df583  vcmppd xmm3, xmm5, xmm5, 0x03
00007d55df7df588  ptest xmm3, xmm3
00007d55df7df58d  jnz 0x00007D55DF7E251B
00007d55df7df593  vmovaps xmm8, [rsp+0x30]
00007d55df7df599  vpermilpd xmm8, xmm8, 0x00
00007d55df7df59f  movaps xmm6, xmm10
00007d55df7df5a3  mulpd xmm6, xmm8
00007d55df7df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007d55df7df5ad  ptest xmm3, xmm3
00007d55df7df5b2  jnz 0x00007D55DF7E265C
00007d55df7df5b8  vmovaps xmm8, [rsp+0x60]
00007d55df7df5be  movaps xmm10, xmm8
00007d55df7df5c2  addpd xmm10, xmm14
00007d55df7df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007d55df7df5cd  ptest xmm3, xmm3
00007d55df7df5d2  jnz 0x00007D55DF7E279E
00007d55df7df5d8  vmovaps xmm8, [rsp+0x50]
00007d55df7df5de  movaps xmm14, xmm8
00007d55df7df5e2  addpd xmm14, xmm4
00007d55df7df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007d55df7df5ed  ptest xmm3, xmm3
00007d55df7df5f2  jnz 0x00007D55DF7E28E2
00007d55df7df5f8  vmovaps xmm8, [rsp+0x40]
00007d55df7df5fe  vpermilpd xmm8, xmm8, 0x00
00007d55df7df604  movaps xmm4, xmm13
00007d55df7df608  mulpd xmm4, xmm8
00007d55df7df60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007d55df7df612  ptest xmm3, xmm3
00007d55df7df617  jnz 0x00007D55DF7E2A25
00007d55df7df61d  movaps xmm13, xmm15
00007d55df7df621  addpd xmm13, xmm9
00007d55df7df626  vcmppd xmm8, xmm13, xmm13, 0x03
00007d55df7df62c  ptest xmm8, xmm8
00007d55df7df632  jnz 0x00007D55DF7E2B67
00007d55df7df638  movaps xmm15, xmm1
00007d55df7df63c  addpd xmm15, xmm5
00007d55df7df641  vcmppd xmm9, xmm15, xmm15, 0x03
00007d55df7df647  ptest xmm9, xmm9
00007d55df7df64d  jnz 0x00007D55DF7E2CAB
00007d55df7df653  vmovaps [rsp+0x30], xmm11
00007d55df7df659  vmovaps xmm1, [rsp+0x30]
00007d55df7df65f  por xmm11, xmm1
00007d55df7df664  movaps [r15+0x250], xmm11
00007d55df7df66c  vmovaps [rsp+0x30], xmm12
00007d55df7df672  vmovaps xmm1, [rsp+0x30]
00007d55df7df678  por xmm12, xmm1
00007d55df7df67d  movaps [r15+0x2A0], xmm12
00007d55df7df685  vmovaps xmm1, [rsp+0xA0]
00007d55df7df68e  vmovaps xmm11, [rsp+0xA0]
00007d55df7df697  por xmm1, xmm11
00007d55df7df69c  movaps [r15+0x1D0], xmm1
00007d55df7df6a4  lea r12, [rax+0x40]
00007d55df7df6a8  movups xmm1, [r13+r12*1]
00007d55df7df6ae  movaps [r15+0x2C0], xmm1
00007d55df7df6b6  vmovaps xmm11, [rsp+0x40]
00007d55df7df6bc  vpermilpd xmm11, xmm11, 0x00
00007d55df7df6c2  vmovaps xmm8, [rsp+0xE0]
00007d55df7df6cb  movaps xmm9, xmm8
00007d55df7df6cf  mulpd xmm9, xmm11
00007d55df7df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007d55df7df6da  ptest xmm5, xmm5
00007d55df7df6df  jnz 0x00007D55DF7E2DF7
00007d55df7df6e5  movaps xmm11, xmm10
00007d55df7df6e9  addpd xmm11, xmm6
00007d55df7df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007d55df7df6f4  ptest xmm8, xmm8
00007d55df7df6fa  jnz 0x00007D55DF7E2F3B
00007d55df7df700  movaps xmm10, xmm14
00007d55df7df704  addpd xmm10, xmm4
00007d55df7df709  vcmppd xmm8, xmm10, xmm10, 0x03
00007d55df7df70f  ptest xmm8, xmm8
00007d55df7df715  jnz 0x00007D55DF7E307E
00007d55df7df71b  vmovaps xmm14, [rsp+0x40]
00007d55df7df721  vpermilpd xmm14, xmm14, 0x00
00007d55df7df727  movaps xmm8, xmm1
00007d55df7df72b  mulpd xmm8, xmm14
00007d55df7df730  vcmppd xmm6, xmm8, xmm8, 0x03
00007d55df7df736  ptest xmm6, xmm6
00007d55df7df73b  jnz 0x00007D55DF7E31C1
00007d55df7df741  movaps xmm1, [r15+0x2B0]
00007d55df7df749  vmovaps xmm14, [rsp+0x40]
00007d55df7df74f  vpermilpd xmm14, xmm14, 0x00
00007d55df7df755  movaps xmm6, xmm1
00007d55df7df758  mulpd xmm6, xmm14
00007d55df7df75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007d55df7df762  ptest xmm5, xmm5
00007d55df7df767  jnz 0x00007D55DF7E3304
00007d55df7df76d  vmovaps xmm1, [rsp+0x10]
00007d55df7df773  vpermilpd xmm1, xmm1, 0x00
00007d55df7df779  movaps xmm14, xmm12
00007d55df7df77d  mulpd xmm14, xmm1
00007d55df7df782  vcmppd xmm5, xmm14, xmm14, 0x03
00007d55df7df788  ptest xmm5, xmm5
00007d55df7df78d  jnz 0x00007D55DF7E3445
00007d55df7df793  movaps xmm1, xmm13
00007d55df7df797  addpd xmm1, xmm9
00007d55df7df79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007d55df7df7a1  ptest xmm12, xmm12
00007d55df7df7a7  jnz 0x00007D55DF7E3588
00007d55df7df7ad  vmovaps xmm13, [rsp+0x10]
00007d55df7df7b3  vpermilpd xmm13, xmm13, 0x00
00007d55df7df7b9  movaps xmm12, xmm7
00007d55df7df7bd  mulpd xmm12, xmm13
00007d55df7df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007d55df7df7c8  ptest xmm9, xmm9
00007d55df7df7ce  jnz 0x00007D55DF7E36CA
00007d55df7df7d4  movaps xmm13, xmm15
00007d55df7df7d8  addpd xmm13, xmm8
00007d55df7df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007d55df7df7e3  ptest xmm9, xmm9
00007d55df7df7e9  jnz 0x00007D55DF7E380D
00007d55df7df7ef  movaps xmm15, [r15+0x290]
00007d55df7df7f7  vmovaps xmm9, [rsp+0x10]
00007d55df7df7fd  vpermilpd xmm9, xmm9, 0x00
00007d55df7df803  movaps xmm8, xmm15
00007d55df7df807  mulpd xmm8, xmm9
00007d55df7df80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007d55df7df812  ptest xmm7, xmm7
00007d55df7df817  jnz 0x00007D55DF7E3951
00007d55df7df81d  movaps xmm15, xmm11
00007d55df7df821  addpd xmm15, xmm6
00007d55df7df826  vcmppd xmm9, xmm15, xmm15, 0x03
00007d55df7df82c  ptest xmm9, xmm9
00007d55df7df832  jnz 0x00007D55DF7E3A95
00007d55df7df838  movaps xmm11, [r15+0x1E0]
00007d55df7df840  vmovaps xmm9, [rsp+0x10]
00007d55df7df846  vpermilpd xmm9, xmm9, 0x00
00007d55df7df84c  movaps xmm7, xmm11
00007d55df7df850  mulpd xmm7, xmm9
00007d55df7df855  vcmppd xmm6, xmm7, xmm7, 0x03
00007d55df7df85a  ptest xmm6, xmm6
00007d55df7df85f  jnz 0x00007D55DF7E3BD8
00007d55df7df865  movaps xmm11, xmm10
00007d55df7df869  addpd xmm11, xmm14
00007d55df7df86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007d55df7df874  ptest xmm9, xmm9
00007d55df7df87a  jnz 0x00007D55DF7E3D1A
00007d55df7df880  lea r12, [rax+0x70]
00007d55df7df884  movups xmm14, [r13+r12*1]
00007d55df7df88a  movaps [r15+0x240], xmm14
00007d55df7df892  movaps xmm10, xmm1
00007d55df7df896  addpd xmm10, xmm12
00007d55df7df89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007d55df7df8a1  ptest xmm9, xmm9
00007d55df7df8a7  jnz 0x00007D55DF7E3E68
00007d55df7df8ad  movaps [r15+0x170], xmm10
00007d55df7df8b5  vmovaps xmm1, [rsp+0x20]
00007d55df7df8bb  vpermilpd xmm1, xmm1, 0x00
00007d55df7df8c1  movaps xmm12, xmm14
00007d55df7df8c5  mulpd xmm12, xmm1
00007d55df7df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007d55df7df8d0  ptest xmm9, xmm9
00007d55df7df8d6  jnz 0x00007D55DF7E3FAB
00007d55df7df8dc  vmovaps xmm1, [rsp+0x20]
00007d55df7df8e2  vpermilpd xmm1, xmm1, 0x00
00007d55df7df8e8  vmovaps xmm9, [rsp+0xB0]
00007d55df7df8f1  movaps xmm14, xmm9
00007d55df7df8f5  mulpd xmm14, xmm1
00007d55df7df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007d55df7df900  ptest xmm6, xmm6
00007d55df7df905  jnz 0x00007D55DF7E40EE
00007d55df7df90b  movaps [r15+0x180], xmm14
00007d55df7df913  movaps xmm1, xmm13
00007d55df7df917  addpd xmm1, xmm8
00007d55df7df91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007d55df7df921  ptest xmm9, xmm9
00007d55df7df927  jnz 0x00007D55DF7E4231
00007d55df7df92d  movaps [r15+0x210], xmm1
00007d55df7df935  movups xmm13, [r13+rax*1]
00007d55df7df93b  lea r12, [rax+0x10]
00007d55df7df93f  movups xmm9, [r13+r12*1]
00007d55df7df945  movaps [r15+0x230], xmm9
00007d55df7df94d  movaps xmm8, xmm15
00007d55df7df951  addpd xmm8, xmm7
00007d55df7df956  vcmppd xmm6, xmm8, xmm8, 0x03
00007d55df7df95c  ptest xmm6, xmm6
00007d55df7df961  jnz 0x00007D55DF7E4387
00007d55df7df967  movaps [r15+0x130], xmm8
00007d55df7df96f  vmovaps xmm15, [rsp+0x20]
00007d55df7df975  vpermilpd xmm15, xmm15, 0x00
00007d55df7df97b  movaps xmm7, xmm9
00007d55df7df97f  mulpd xmm7, xmm15
00007d55df7df984  vcmppd xmm6, xmm7, xmm7, 0x03
00007d55df7df989  ptest xmm6, xmm6
00007d55df7df98e  jnz 0x00007D55DF7E44CA
00007d55df7df994  movaps [r15+0x220], xmm7
00007d55df7df99c  vmovaps xmm15, [rsp+0x20]
00007d55df7df9a2  vpermilpd xmm15, xmm15, 0x00
00007d55df7df9a8  movaps xmm9, xmm13
00007d55df7df9ac  mulpd xmm9, xmm15
00007d55df7df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007d55df7df9b7  ptest xmm6, xmm6
00007d55df7df9bc  jnz 0x00007D55DF7E460C
00007d55df7df9c2  movaps xmm15, xmm11
00007d55df7df9c6  addpd xmm15, xmm12
00007d55df7df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007d55df7df9d1  ptest xmm13, xmm13
00007d55df7df9d7  jnz 0x00007D55DF7E4750
00007d55df7df9dd  movaps [r15+0x140], xmm15
00007d55df7df9e5  movaps xmm13, xmm10
00007d55df7df9e9  addpd xmm13, xmm14
00007d55df7df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007d55df7df9f4  ptest xmm12, xmm12
00007d55df7df9fa  jnz 0x00007D55DF7E4894
00007d55df7dfa00  movaps [r15+0x150], xmm13
00007d55df7dfa08  movaps xmm14, xmm1
00007d55df7dfa0c  addpd xmm14, xmm7
00007d55df7dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007d55df7dfa17  ptest xmm12, xmm12
00007d55df7dfa1d  jnz 0x00007D55DF7E49D8
00007d55df7dfa23  movaps [r15+0x160], xmm14
00007d55df7dfa2b  movaps xmm1, xmm8
00007d55df7dfa2f  addpd xmm1, xmm9
00007d55df7dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007d55df7dfa39  ptest xmm12, xmm12
00007d55df7dfa3f  jnz 0x00007D55DF7E4B1A
00007d55df7dfa45  movaps [r15+0x120], xmm1
00007d55df7dfa4d  movups [r13+r14*1], xmm15
00007d55df7dfa53  lea rax, [r14+0x10]
00007d55df7dfa57  movups [r13+rax*1], xmm13
00007d55df7dfa5d  lea rax, [r14+0x20]
00007d55df7dfa61  movups [r13+rax*1], xmm14
00007d55df7dfa67  lea rax, [r14+0x30]
00007d55df7dfa6b  movups [r13+rax*1], xmm1
00007d55df7dfa71  mov eax, [r15+0x108]
00007d55df7dfa78  sahf
00007d55df7dfa79  jnz 0x00007D55DF7DFAAB
00007d55df7dfa7b  cmp dword ptr [r15+0x318], 0x00
00007d55df7dfa83  jz 0x00007D55DF7DEAE0
00007d55df7dfa89  nop [rax+rax*1], ax
00007d55df7dfa92  nop [rax+rax*1], eax
00007d55df7dfa9a  mov eax, 0x4106D0
00007d55df7dfa9f  mov [r15+0x100], rax
00007d55df7dfaa6  jmp 0x00007D55DF5FE110
00007d55df7dfaab  cmp dword ptr [r15+0x318], 0x00
00007d55df7dfab3  jz 0x00007D55DF7D89C0
00007d55df7dfab9  nop [rax+rax*1], ax
00007d55df7dfac2  nop [rax+rax*1], eax
00007d55df7dfaca  mov eax, 0x410504
00007d55df7dfacf  mov [r15+0x100], rax
00007d55df7dfad6  jmp 0x00007D55DF5FE110
00007d55df7dfadb  int3
00007d55df7dfadc  call 0x00007D55DF6E27E0
00007d55df7dfae1  jmp 0x00007D55DF7DEBBF
00007d55df7dfae6  call 0x00007D55DF6E1570
00007d55df7dfaeb  jmp 0x00007D55DF7DEBC8
00007d55df7dfaf0  call 0x00007D55DF6E27E0
00007d55df7dfaf5  jmp 0x00007D55DF7DEC24
00007d55df7dfafa  call 0x00007D55DF6E1570
00007d55df7dfaff  jmp 0x00007D55DF7DEC2D
00007d55df7dfb04  call 0x00007D55DF6E27E0
00007d55df7dfb09  jmp 0x00007D55DF7DEC70
00007d55df7dfb0e  call 0x00007D55DF6E1570
00007d55df7dfb13  jmp 0x00007D55DF7DEC79
00007d55df7dfb18  call 0x00007D55DF60DC20
00007d55df7dfb1d  jmp 0x00007D55DF7DECB8
00007d55df7dfb22  call 0x00007D55DF6D59C0
00007d55df7dfb27  jmp 0x00007D55DF7DECCB
00007d55df7dfb2c  call 0x00007D55DF6E0E30
00007d55df7dfb31  jmp 0x00007D55DF7DECE9
00007d55df7dfb36  call 0x00007D55DF6DFBC0
00007d55df7dfb3b  jmp 0x00007D55DF7DECF3
00007d55df7dfb40  call 0x00007D55DF6DE950
00007d55df7dfb45  jmp 0x00007D55DF7DECFD
00007d55df7dfb4a  sub rsp, 0x08
00007d55df7dfb4e  push rax
00007d55df7dfb4f  push rcx
00007d55df7dfb50  push rdx
00007d55df7dfb51  push rdi
00007d55df7dfb52  push rsi
00007d55df7dfb53  push r8
00007d55df7dfb55  push r9
00007d55df7dfb57  push r10
00007d55df7dfb59  push r11
00007d55df7dfb5b  sub rsp, 0xF0
00007d55df7dfb62  vmovaps [rsp], xmm0
00007d55df7dfb67  vmovaps [rsp+0x10], xmm1
00007d55df7dfb6d  vmovaps [rsp+0x20], xmm2
00007d55df7dfb73  vmovaps [rsp+0x30], xmm3
00007d55df7dfb79  vmovaps [rsp+0x40], xmm4
00007d55df7dfb7f  vmovaps [rsp+0x50], xmm5
00007d55df7dfb85  vmovaps [rsp+0x60], xmm6
00007d55df7dfb8b  vmovaps [rsp+0x70], xmm7
00007d55df7dfb91  vmovaps [rsp+0x80], xmm9
00007d55df7dfb9a  vmovaps [rsp+0x90], xmm10
00007d55df7dfba3  vmovaps [rsp+0xA0], xmm11
00007d55df7dfbac  vmovaps [rsp+0xB0], xmm12
00007d55df7dfbb5  vmovaps [rsp+0xC0], xmm13
00007d55df7dfbbe  vmovaps [rsp+0xD0], xmm14
00007d55df7dfbc7  vmovaps [rsp+0xE0], xmm15
00007d55df7dfbd0  sub rsp, 0x30
00007d55df7dfbd4  movaps [rsp], xmm8
00007d55df7dfbd9  movaps [rsp+0x10], xmm12
00007d55df7dfbdf  movaps [rsp+0x20], xmm15
00007d55df7dfbe5  lea rdi, [rsp]
00007d55df7dfbe9  mov esi, 0x00
00007d55df7dfbee  mov rax, 0x5BB8433D8530
00007d55df7dfbf8  call rax
00007d55df7dfbfa  movaps xmm8, [rsp]
00007d55df7dfbff  add rsp, 0x30
00007d55df7dfc03  vmovaps xmm0, [rsp]
00007d55df7dfc08  vmovaps xmm1, [rsp+0x10]
00007d55df7dfc0e  vmovaps xmm2, [rsp+0x20]
00007d55df7dfc14  vmovaps xmm3, [rsp+0x30]
00007d55df7dfc1a  vmovaps xmm4, [rsp+0x40]
00007d55df7dfc20  vmovaps xmm5, [rsp+0x50]
00007d55df7dfc26  vmovaps xmm6, [rsp+0x60]
00007d55df7dfc2c  vmovaps xmm7, [rsp+0x70]
00007d55df7dfc32  vmovaps xmm9, [rsp+0x80]
00007d55df7dfc3b  vmovaps xmm10, [rsp+0x90]
00007d55df7dfc44  vmovaps xmm11, [rsp+0xA0]
00007d55df7dfc4d  vmovaps xmm12, [rsp+0xB0]
00007d55df7dfc56  vmovaps xmm13, [rsp+0xC0]
00007d55df7dfc5f  vmovaps xmm14, [rsp+0xD0]
00007d55df7dfc68  vmovaps xmm15, [rsp+0xE0]
00007d55df7dfc71  add rsp, 0xF0
00007d55df7dfc78  pop r11
00007d55df7dfc7a  pop r10
00007d55df7dfc7c  pop r9
00007d55df7dfc7e  pop r8
00007d55df7dfc80  pop rsi
00007d55df7dfc81  pop rdi
00007d55df7dfc82  pop rdx
00007d55df7dfc83  pop rcx
00007d55df7dfc84  pop rax
00007d55df7dfc85  add rsp, 0x08
00007d55df7dfc89  jmp 0x00007D55DF7DED27
00007d55df7dfc8e  sub rsp, 0x08
00007d55df7dfc92  push rax
00007d55df7dfc93  push rcx
00007d55df7dfc94  push rdx
00007d55df7dfc95  push rdi
00007d55df7dfc96  push rsi
00007d55df7dfc97  push r8
00007d55df7dfc99  push r9
00007d55df7dfc9b  push r10
00007d55df7dfc9d  push r11
00007d55df7dfc9f  sub rsp, 0xF0
00007d55df7dfca6  vmovaps [rsp], xmm0
00007d55df7dfcab  vmovaps [rsp+0x10], xmm1
00007d55df7dfcb1  vmovaps [rsp+0x20], xmm2
00007d55df7dfcb7  vmovaps [rsp+0x30], xmm3
00007d55df7dfcbd  vmovaps [rsp+0x40], xmm4
00007d55df7dfcc3  vmovaps [rsp+0x50], xmm5
00007d55df7dfcc9  vmovaps [rsp+0x60], xmm6
00007d55df7dfccf  vmovaps [rsp+0x70], xmm8
00007d55df7dfcd5  vmovaps [rsp+0x80], xmm9
00007d55df7dfcde  vmovaps [rsp+0x90], xmm10
00007d55df7dfce7  vmovaps [rsp+0xA0], xmm11
00007d55df7dfcf0  vmovaps [rsp+0xB0], xmm12
00007d55df7dfcf9  vmovaps [rsp+0xC0], xmm13
00007d55df7dfd02  vmovaps [rsp+0xD0], xmm14
00007d55df7dfd0b  vmovaps [rsp+0xE0], xmm15
00007d55df7dfd14  sub rsp, 0x30
00007d55df7dfd18  movaps [rsp], xmm7
00007d55df7dfd1c  movaps [rsp+0x10], xmm9
00007d55df7dfd22  movaps [rsp+0x20], xmm15
00007d55df7dfd28  lea rdi, [rsp]
00007d55df7dfd2c  mov esi, 0x00
00007d55df7dfd31  mov rax, 0x5BB8433D8530
00007d55df7dfd3b  call rax
00007d55df7dfd3d  movaps xmm7, [rsp]
00007d55df7dfd41  add rsp, 0x30
00007d55df7dfd45  vmovaps xmm0, [rsp]
00007d55df7dfd4a  vmovaps xmm1, [rsp+0x10]
00007d55df7dfd50  vmovaps xmm2, [rsp+0x20]
00007d55df7dfd56  vmovaps xmm3, [rsp+0x30]
00007d55df7dfd5c  vmovaps xmm4, [rsp+0x40]
00007d55df7dfd62  vmovaps xmm5, [rsp+0x50]
00007d55df7dfd68  vmovaps xmm6, [rsp+0x60]
00007d55df7dfd6e  vmovaps xmm8, [rsp+0x70]
00007d55df7dfd74  vmovaps xmm9, [rsp+0x80]
00007d55df7dfd7d  vmovaps xmm10, [rsp+0x90]
00007d55df7dfd86  vmovaps xmm11, [rsp+0xA0]
00007d55df7dfd8f  vmovaps xmm12, [rsp+0xB0]
00007d55df7dfd98  vmovaps xmm13, [rsp+0xC0]
00007d55df7dfda1  vmovaps xmm14, [rsp+0xD0]
00007d55df7dfdaa  vmovaps xmm15, [rsp+0xE0]
00007d55df7dfdb3  add rsp, 0xF0
00007d55df7dfdba  pop r11
00007d55df7dfdbc  pop r10
00007d55df7dfdbe  pop r9
00007d55df7dfdc0  pop r8
00007d55df7dfdc2  pop rsi
00007d55df7dfdc3  pop rdi
00007d55df7dfdc4  pop rdx
00007d55df7dfdc5  pop rcx
00007d55df7dfdc6  pop rax
00007d55df7dfdc7  add rsp, 0x08
00007d55df7dfdcb  jmp 0x00007D55DF7DED55
00007d55df7dfdd0  sub rsp, 0x08
00007d55df7dfdd4  push rax
00007d55df7dfdd5  push rcx
00007d55df7dfdd6  push rdx
00007d55df7dfdd7  push rdi
00007d55df7dfdd8  push rsi
00007d55df7dfdd9  push r8
00007d55df7dfddb  push r9
00007d55df7dfddd  push r10
00007d55df7dfddf  push r11
00007d55df7dfde1  sub rsp, 0xF0
00007d55df7dfde8  vmovaps [rsp], xmm0
00007d55df7dfded  vmovaps [rsp+0x10], xmm1
00007d55df7dfdf3  vmovaps [rsp+0x20], xmm2
00007d55df7dfdf9  vmovaps [rsp+0x30], xmm3
00007d55df7dfdff  vmovaps [rsp+0x40], xmm4
00007d55df7dfe05  vmovaps [rsp+0x50], xmm5
00007d55df7dfe0b  vmovaps [rsp+0x60], xmm6
00007d55df7dfe11  vmovaps [rsp+0x70], xmm7
00007d55df7dfe17  vmovaps [rsp+0x80], xmm8
00007d55df7dfe20  vmovaps [rsp+0x90], xmm10
00007d55df7dfe29  vmovaps [rsp+0xA0], xmm11
00007d55df7dfe32  vmovaps [rsp+0xB0], xmm12
00007d55df7dfe3b  vmovaps [rsp+0xC0], xmm13
00007d55df7dfe44  vmovaps [rsp+0xD0], xmm14
00007d55df7dfe4d  vmovaps [rsp+0xE0], xmm15
00007d55df7dfe56  sub rsp, 0x30
00007d55df7dfe5a  movaps [rsp], xmm9
00007d55df7dfe5f  movaps [rsp+0x10], xmm12
00007d55df7dfe65  movaps [rsp+0x20], xmm10
00007d55df7dfe6b  lea rdi, [rsp]
00007d55df7dfe6f  mov esi, 0x00
00007d55df7dfe74  mov rax, 0x5BB8433D8530
00007d55df7dfe7e  call rax
00007d55df7dfe80  movaps xmm9, [rsp]
00007d55df7dfe85  add rsp, 0x30
00007d55df7dfe89  vmovaps xmm0, [rsp]
00007d55df7dfe8e  vmovaps xmm1, [rsp+0x10]
00007d55df7dfe94  vmovaps xmm2, [rsp+0x20]
00007d55df7dfe9a  vmovaps xmm3, [rsp+0x30]
00007d55df7dfea0  vmovaps xmm4, [rsp+0x40]
00007d55df7dfea6  vmovaps xmm5, [rsp+0x50]
00007d55df7dfeac  vmovaps xmm6, [rsp+0x60]
00007d55df7dfeb2  vmovaps xmm7, [rsp+0x70]
00007d55df7dfeb8  vmovaps xmm8, [rsp+0x80]
00007d55df7dfec1  vmovaps xmm10, [rsp+0x90]
00007d55df7dfeca  vmovaps xmm11, [rsp+0xA0]
00007d55df7dfed3  vmovaps xmm12, [rsp+0xB0]
00007d55df7dfedc  vmovaps xmm13, [rsp+0xC0]
00007d55df7dfee5  vmovaps xmm14, [rsp+0xD0]
00007d55df7dfeee  vmovaps xmm15, [rsp+0xE0]
00007d55df7dfef7  add rsp, 0xF0
00007d55df7dfefe  pop r11
00007d55df7dff00  pop r10
00007d55df7dff02  pop r9
00007d55df7dff04  pop r8
00007d55df7dff06  pop rsi
00007d55df7dff07  pop rdi
00007d55df7dff08  pop rdx
00007d55df7dff09  pop rcx
00007d55df7dff0a  pop rax
00007d55df7dff0b  add rsp, 0x08
00007d55df7dff0f  jmp 0x00007D55DF7DED79
00007d55df7dff14  sub rsp, 0x08
00007d55df7dff18  push rax
00007d55df7dff19  push rcx
00007d55df7dff1a  push rdx
00007d55df7dff1b  push rdi
00007d55df7dff1c  push rsi
00007d55df7dff1d  push r8
00007d55df7dff1f  push r9
00007d55df7dff21  push r10
00007d55df7dff23  push r11
00007d55df7dff25  sub rsp, 0xF0
00007d55df7dff2c  vmovaps [rsp], xmm0
00007d55df7dff31  vmovaps [rsp+0x10], xmm1
00007d55df7dff37  vmovaps [rsp+0x20], xmm2
00007d55df7dff3d  vmovaps [rsp+0x30], xmm3
00007d55df7dff43  vmovaps [rsp+0x40], xmm4
00007d55df7dff49  vmovaps [rsp+0x50], xmm5
00007d55df7dff4f  vmovaps [rsp+0x60], xmm6
00007d55df7dff55  vmovaps [rsp+0x70], xmm7
00007d55df7dff5b  vmovaps [rsp+0x80], xmm8
00007d55df7dff64  vmovaps [rsp+0x90], xmm9
00007d55df7dff6d  vmovaps [rsp+0xA0], xmm11
00007d55df7dff76  vmovaps [rsp+0xB0], xmm12
00007d55df7dff7f  vmovaps [rsp+0xC0], xmm13
00007d55df7dff88  vmovaps [rsp+0xD0], xmm14
00007d55df7dff91  vmovaps [rsp+0xE0], xmm15
00007d55df7dff9a  sub rsp, 0x30
00007d55df7dff9e  movaps [rsp], xmm10
00007d55df7dffa3  movaps [rsp+0x10], xmm12
00007d55df7dffa9  movaps [rsp+0x20], xmm11
00007d55df7dffaf  lea rdi, [rsp]
00007d55df7dffb3  mov esi, 0x00
00007d55df7dffb8  mov rax, 0x5BB8433D8530
00007d55df7dffc2  call rax
00007d55df7dffc4  movaps xmm10, [rsp]
00007d55df7dffc9  add rsp, 0x30
00007d55df7dffcd  vmovaps xmm0, [rsp]
00007d55df7dffd2  vmovaps xmm1, [rsp+0x10]
00007d55df7dffd8  vmovaps xmm2, [rsp+0x20]
00007d55df7dffde  vmovaps xmm3, [rsp+0x30]
00007d55df7dffe4  vmovaps xmm4, [rsp+0x40]
00007d55df7dffea  vmovaps xmm5, [rsp+0x50]
00007d55df7dfff0  vmovaps xmm6, [rsp+0x60]
00007d55df7dfff6  vmovaps xmm7, [rsp+0x70]
00007d55df7dfffc  vmovaps xmm8, [rsp+0x80]
00007d55df7e0005  vmovaps xmm9, [rsp+0x90]
00007d55df7e000e  vmovaps xmm11, [rsp+0xA0]
00007d55df7e0017  vmovaps xmm12, [rsp+0xB0]
00007d55df7e0020  vmovaps xmm13, [rsp+0xC0]
00007d55df7e0029  vmovaps xmm14, [rsp+0xD0]
00007d55df7e0032  vmovaps xmm15, [rsp+0xE0]
00007d55df7e003b  add rsp, 0xF0
00007d55df7e0042  pop r11
00007d55df7e0044  pop r10
00007d55df7e0046  pop r9
00007d55df7e0048  pop r8
00007d55df7e004a  pop rsi
00007d55df7e004b  pop rdi
00007d55df7e004c  pop rdx
00007d55df7e004d  pop rcx
00007d55df7e004e  pop rax
00007d55df7e004f  add rsp, 0x08
00007d55df7e0053  jmp 0x00007D55DF7DED93
00007d55df7e0058  sub rsp, 0x08
00007d55df7e005c  push rax
00007d55df7e005d  push rcx
00007d55df7e005e  push rdx
00007d55df7e005f  push rdi
00007d55df7e0060  push rsi
00007d55df7e0061  push r8
00007d55df7e0063  push r9
00007d55df7e0065  push r10
00007d55df7e0067  push r11
00007d55df7e0069  sub rsp, 0xF0
00007d55df7e0070  vmovaps [rsp], xmm0
00007d55df7e0075  vmovaps [rsp+0x10], xmm1
00007d55df7e007b  vmovaps [rsp+0x20], xmm2
00007d55df7e0081  vmovaps [rsp+0x30], xmm3
00007d55df7e0087  vmovaps [rsp+0x40], xmm4
00007d55df7e008d  vmovaps [rsp+0x50], xmm5
00007d55df7e0093  vmovaps [rsp+0x60], xmm7
00007d55df7e0099  vmovaps [rsp+0x70], xmm8
00007d55df7e009f  vmovaps [rsp+0x80], xmm9
00007d55df7e00a8  vmovaps [rsp+0x90], xmm10
00007d55df7e00b1  vmovaps [rsp+0xA0], xmm11
00007d55df7e00ba  vmovaps [rsp+0xB0], xmm12
00007d55df7e00c3  vmovaps [rsp+0xC0], xmm13
00007d55df7e00cc  vmovaps [rsp+0xD0], xmm14
00007d55df7e00d5  vmovaps [rsp+0xE0], xmm15
00007d55df7e00de  sub rsp, 0x30
00007d55df7e00e2  movaps [rsp], xmm6
00007d55df7e00e6  movaps [rsp+0x10], xmm12
00007d55df7e00ec  movaps [rsp+0x20], xmm11
00007d55df7e00f2  lea rdi, [rsp]
00007d55df7e00f6  mov esi, 0x00
00007d55df7e00fb  mov rax, 0x5BB8433D8530
00007d55df7e0105  call rax
00007d55df7e0107  movaps xmm6, [rsp]
00007d55df7e010b  add rsp, 0x30
00007d55df7e010f  vmovaps xmm0, [rsp]
00007d55df7e0114  vmovaps xmm1, [rsp+0x10]
00007d55df7e011a  vmovaps xmm2, [rsp+0x20]
00007d55df7e0120  vmovaps xmm3, [rsp+0x30]
00007d55df7e0126  vmovaps xmm4, [rsp+0x40]
00007d55df7e012c  vmovaps xmm5, [rsp+0x50]
00007d55df7e0132  vmovaps xmm7, [rsp+0x60]
00007d55df7e0138  vmovaps xmm8, [rsp+0x70]
00007d55df7e013e  vmovaps xmm9, [rsp+0x80]
00007d55df7e0147  vmovaps xmm10, [rsp+0x90]
00007d55df7e0150  vmovaps xmm11, [rsp+0xA0]
00007d55df7e0159  vmovaps xmm12, [rsp+0xB0]
00007d55df7e0162  vmovaps xmm13, [rsp+0xC0]
00007d55df7e016b  vmovaps xmm14, [rsp+0xD0]
00007d55df7e0174  vmovaps xmm15, [rsp+0xE0]
00007d55df7e017d  add rsp, 0xF0
00007d55df7e0184  pop r11
00007d55df7e0186  pop r10
00007d55df7e0188  pop r9
00007d55df7e018a  pop r8
00007d55df7e018c  pop rsi
00007d55df7e018d  pop rdi
00007d55df7e018e  pop rdx
00007d55df7e018f  pop rcx
00007d55df7e0190  pop rax
00007d55df7e0191  add rsp, 0x08
00007d55df7e0195  jmp 0x00007D55DF7DEDB4
00007d55df7e019a  sub rsp, 0x08
00007d55df7e019e  push rax
00007d55df7e019f  push rcx
00007d55df7e01a0  push rdx
00007d55df7e01a1  push rdi
00007d55df7e01a2  push rsi
00007d55df7e01a3  push r8
00007d55df7e01a5  push r9
00007d55df7e01a7  push r10
00007d55df7e01a9  push r11
00007d55df7e01ab  sub rsp, 0xF0
00007d55df7e01b2  vmovaps [rsp], xmm0
00007d55df7e01b7  vmovaps [rsp+0x10], xmm1
00007d55df7e01bd  vmovaps [rsp+0x20], xmm2
00007d55df7e01c3  vmovaps [rsp+0x30], xmm4
00007d55df7e01c9  vmovaps [rsp+0x40], xmm5
00007d55df7e01cf  vmovaps [rsp+0x50], xmm6
00007d55df7e01d5  vmovaps [rsp+0x60], xmm7
00007d55df7e01db  vmovaps [rsp+0x70], xmm8
00007d55df7e01e1  vmovaps [rsp+0x80], xmm9
00007d55df7e01ea  vmovaps [rsp+0x90], xmm10
00007d55df7e01f3  vmovaps [rsp+0xA0], xmm11
00007d55df7e01fc  vmovaps [rsp+0xB0], xmm12
00007d55df7e0205  vmovaps [rsp+0xC0], xmm13
00007d55df7e020e  vmovaps [rsp+0xD0], xmm14
00007d55df7e0217  vmovaps [rsp+0xE0], xmm15
00007d55df7e0220  sub rsp, 0x30
00007d55df7e0224  movaps [rsp], xmm3
00007d55df7e0228  movaps [rsp+0x10], xmm5
00007d55df7e022d  movaps [rsp+0x20], xmm4
00007d55df7e0232  lea rdi, [rsp]
00007d55df7e0236  mov esi, 0x00
00007d55df7e023b  mov rax, 0x5BB8433D8530
00007d55df7e0245  call rax
00007d55df7e0247  movaps xmm3, [rsp]
00007d55df7e024b  add rsp, 0x30
00007d55df7e024f  vmovaps xmm0, [rsp]
00007d55df7e0254  vmovaps xmm1, [rsp+0x10]
00007d55df7e025a  vmovaps xmm2, [rsp+0x20]
00007d55df7e0260  vmovaps xmm4, [rsp+0x30]
00007d55df7e0266  vmovaps xmm5, [rsp+0x40]
00007d55df7e026c  vmovaps xmm6, [rsp+0x50]
00007d55df7e0272  vmovaps xmm7, [rsp+0x60]
00007d55df7e0278  vmovaps xmm8, [rsp+0x70]
00007d55df7e027e  vmovaps xmm9, [rsp+0x80]
00007d55df7e0287  vmovaps xmm10, [rsp+0x90]
00007d55df7e0290  vmovaps xmm11, [rsp+0xA0]
00007d55df7e0299  vmovaps xmm12, [rsp+0xB0]
00007d55df7e02a2  vmovaps xmm13, [rsp+0xC0]
00007d55df7e02ab  vmovaps xmm14, [rsp+0xD0]
00007d55df7e02b4  vmovaps xmm15, [rsp+0xE0]
00007d55df7e02bd  add rsp, 0xF0
00007d55df7e02c4  pop r11
00007d55df7e02c6  pop r10
00007d55df7e02c8  pop r9
00007d55df7e02ca  pop r8
00007d55df7e02cc  pop rsi
00007d55df7e02cd  pop rdi
00007d55df7e02ce  pop rdx
00007d55df7e02cf  pop rcx
00007d55df7e02d0  pop rax
00007d55df7e02d1  add rsp, 0x08
00007d55df7e02d5  jmp 0x00007D55DF7DEE15
00007d55df7e02da  sub rsp, 0x08
00007d55df7e02de  push rax
00007d55df7e02df  push rcx
00007d55df7e02e0  push rdx
00007d55df7e02e1  push rdi
00007d55df7e02e2  push rsi
00007d55df7e02e3  push r8
00007d55df7e02e5  push r9
00007d55df7e02e7  push r10
00007d55df7e02e9  push r11
00007d55df7e02eb  sub rsp, 0xF0
00007d55df7e02f2  vmovaps [rsp], xmm0
00007d55df7e02f7  vmovaps [rsp+0x10], xmm1
00007d55df7e02fd  vmovaps [rsp+0x20], xmm2
00007d55df7e0303  vmovaps [rsp+0x30], xmm3
00007d55df7e0309  vmovaps [rsp+0x40], xmm4
00007d55df7e030f  vmovaps [rsp+0x50], xmm6
00007d55df7e0315  vmovaps [rsp+0x60], xmm7
00007d55df7e031b  vmovaps [rsp+0x70], xmm8
00007d55df7e0321  vmovaps [rsp+0x80], xmm9
00007d55df7e032a  vmovaps [rsp+0x90], xmm10
00007d55df7e0333  vmovaps [rsp+0xA0], xmm11
00007d55df7e033c  vmovaps [rsp+0xB0], xmm12
00007d55df7e0345  vmovaps [rsp+0xC0], xmm13
00007d55df7e034e  vmovaps [rsp+0xD0], xmm14
00007d55df7e0357  vmovaps [rsp+0xE0], xmm15
00007d55df7e0360  sub rsp, 0x30
00007d55df7e0364  movaps [rsp], xmm5
00007d55df7e0368  movaps [rsp+0x10], xmm8
00007d55df7e036e  movaps [rsp+0x20], xmm15
00007d55df7e0374  lea rdi, [rsp]
00007d55df7e0378  mov esi, 0x00
00007d55df7e037d  mov rax, 0x5BB8433D8530
00007d55df7e0387  call rax
00007d55df7e0389  movaps xmm5, [rsp]
00007d55df7e038d  add rsp, 0x30
00007d55df7e0391  vmovaps xmm0, [rsp]
00007d55df7e0396  vmovaps xmm1, [rsp+0x10]
00007d55df7e039c  vmovaps xmm2, [rsp+0x20]
00007d55df7e03a2  vmovaps xmm3, [rsp+0x30]
00007d55df7e03a8  vmovaps xmm4, [rsp+0x40]
00007d55df7e03ae  vmovaps xmm6, [rsp+0x50]
00007d55df7e03b4  vmovaps xmm7, [rsp+0x60]
00007d55df7e03ba  vmovaps xmm8, [rsp+0x70]
00007d55df7e03c0  vmovaps xmm9, [rsp+0x80]
00007d55df7e03c9  vmovaps xmm10, [rsp+0x90]
00007d55df7e03d2  vmovaps xmm11, [rsp+0xA0]
00007d55df7e03db  vmovaps xmm12, [rsp+0xB0]
00007d55df7e03e4  vmovaps xmm13, [rsp+0xC0]
00007d55df7e03ed  vmovaps xmm14, [rsp+0xD0]
00007d55df7e03f6  vmovaps xmm15, [rsp+0xE0]
00007d55df7e03ff  add rsp, 0xF0
00007d55df7e0406  pop r11
00007d55df7e0408  pop r10
00007d55df7e040a  pop r9
00007d55df7e040c  pop r8
00007d55df7e040e  pop rsi
00007d55df7e040f  pop rdi
00007d55df7e0410  pop rdx
00007d55df7e0411  pop rcx
00007d55df7e0412  pop rax
00007d55df7e0413  add rsp, 0x08
00007d55df7e0417  jmp 0x00007D55DF7DEE53
00007d55df7e041c  sub rsp, 0x08
00007d55df7e0420  push rax
00007d55df7e0421  push rcx
00007d55df7e0422  push rdx
00007d55df7e0423  push rdi
00007d55df7e0424  push rsi
00007d55df7e0425  push r8
00007d55df7e0427  push r9
00007d55df7e0429  push r10
00007d55df7e042b  push r11
00007d55df7e042d  sub rsp, 0xF0
00007d55df7e0434  vmovaps [rsp], xmm0
00007d55df7e0439  vmovaps [rsp+0x10], xmm1
00007d55df7e043f  vmovaps [rsp+0x20], xmm2
00007d55df7e0445  vmovaps [rsp+0x30], xmm3
00007d55df7e044b  vmovaps [rsp+0x40], xmm5
00007d55df7e0451  vmovaps [rsp+0x50], xmm6
00007d55df7e0457  vmovaps [rsp+0x60], xmm7
00007d55df7e045d  vmovaps [rsp+0x70], xmm8
00007d55df7e0463  vmovaps [rsp+0x80], xmm9
00007d55df7e046c  vmovaps [rsp+0x90], xmm10
00007d55df7e0475  vmovaps [rsp+0xA0], xmm11
00007d55df7e047e  vmovaps [rsp+0xB0], xmm12
00007d55df7e0487  vmovaps [rsp+0xC0], xmm13
00007d55df7e0490  vmovaps [rsp+0xD0], xmm14
00007d55df7e0499  vmovaps [rsp+0xE0], xmm15
00007d55df7e04a2  sub rsp, 0x30
00007d55df7e04a6  movaps [rsp], xmm4
00007d55df7e04aa  movaps [rsp+0x10], xmm9
00007d55df7e04b0  movaps [rsp+0x20], xmm8
00007d55df7e04b6  lea rdi, [rsp]
00007d55df7e04ba  mov esi, 0x00
00007d55df7e04bf  mov rax, 0x5BB8433D8530
00007d55df7e04c9  call rax
00007d55df7e04cb  movaps xmm4, [rsp]
00007d55df7e04cf  add rsp, 0x30
00007d55df7e04d3  vmovaps xmm0, [rsp]
00007d55df7e04d8  vmovaps xmm1, [rsp+0x10]
00007d55df7e04de  vmovaps xmm2, [rsp+0x20]
00007d55df7e04e4  vmovaps xmm3, [rsp+0x30]
00007d55df7e04ea  vmovaps xmm5, [rsp+0x40]
00007d55df7e04f0  vmovaps xmm6, [rsp+0x50]
00007d55df7e04f6  vmovaps xmm7, [rsp+0x60]
00007d55df7e04fc  vmovaps xmm8, [rsp+0x70]
00007d55df7e0502  vmovaps xmm9, [rsp+0x80]
00007d55df7e050b  vmovaps xmm10, [rsp+0x90]
00007d55df7e0514  vmovaps xmm11, [rsp+0xA0]
00007d55df7e051d  vmovaps xmm12, [rsp+0xB0]
00007d55df7e0526  vmovaps xmm13, [rsp+0xC0]
00007d55df7e052f  vmovaps xmm14, [rsp+0xD0]
00007d55df7e0538  vmovaps xmm15, [rsp+0xE0]
00007d55df7e0541  add rsp, 0xF0
00007d55df7e0548  pop r11
00007d55df7e054a  pop r10
00007d55df7e054c  pop r9
00007d55df7e054e  pop r8
00007d55df7e0550  pop rsi
00007d55df7e0551  pop rdi
00007d55df7e0552  pop rdx
00007d55df7e0553  pop rcx
00007d55df7e0554  pop rax
00007d55df7e0555  add rsp, 0x08
00007d55df7e0559  jmp 0x00007D55DF7DEE74
00007d55df7e055e  sub rsp, 0x08
00007d55df7e0562  push rax
00007d55df7e0563  push rcx
00007d55df7e0564  push rdx
00007d55df7e0565  push rdi
00007d55df7e0566  push rsi
00007d55df7e0567  push r8
00007d55df7e0569  push r9
00007d55df7e056b  push r10
00007d55df7e056d  push r11
00007d55df7e056f  sub rsp, 0xF0
00007d55df7e0576  vmovaps [rsp], xmm0
00007d55df7e057b  vmovaps [rsp+0x10], xmm1
00007d55df7e0581  vmovaps [rsp+0x20], xmm2
00007d55df7e0587  vmovaps [rsp+0x30], xmm3
00007d55df7e058d  vmovaps [rsp+0x40], xmm4
00007d55df7e0593  vmovaps [rsp+0x50], xmm5
00007d55df7e0599  vmovaps [rsp+0x60], xmm6
00007d55df7e059f  vmovaps [rsp+0x70], xmm7
00007d55df7e05a5  vmovaps [rsp+0x80], xmm8
00007d55df7e05ae  vmovaps [rsp+0x90], xmm10
00007d55df7e05b7  vmovaps [rsp+0xA0], xmm11
00007d55df7e05c0  vmovaps [rsp+0xB0], xmm12
00007d55df7e05c9  vmovaps [rsp+0xC0], xmm13
00007d55df7e05d2  vmovaps [rsp+0xD0], xmm14
00007d55df7e05db  vmovaps [rsp+0xE0], xmm15
00007d55df7e05e4  sub rsp, 0x30
00007d55df7e05e8  movaps [rsp], xmm9
00007d55df7e05ed  movaps [rsp+0x10], xmm10
00007d55df7e05f3  movaps [rsp+0x20], xmm8
00007d55df7e05f9  lea rdi, [rsp]
00007d55df7e05fd  mov esi, 0x00
00007d55df7e0602  mov rax, 0x5BB8433D8530
00007d55df7e060c  call rax
00007d55df7e060e  movaps xmm9, [rsp]
00007d55df7e0613  add rsp, 0x30
00007d55df7e0617  vmovaps xmm0, [rsp]
00007d55df7e061c  vmovaps xmm1, [rsp+0x10]
00007d55df7e0622  vmovaps xmm2, [rsp+0x20]
00007d55df7e0628  vmovaps xmm3, [rsp+0x30]
00007d55df7e062e  vmovaps xmm4, [rsp+0x40]
00007d55df7e0634  vmovaps xmm5, [rsp+0x50]
00007d55df7e063a  vmovaps xmm6, [rsp+0x60]
00007d55df7e0640  vmovaps xmm7, [rsp+0x70]
00007d55df7e0646  vmovaps xmm8, [rsp+0x80]
00007d55df7e064f  vmovaps xmm10, [rsp+0x90]
00007d55df7e0658  vmovaps xmm11, [rsp+0xA0]
00007d55df7e0661  vmovaps xmm12, [rsp+0xB0]
00007d55df7e066a  vmovaps xmm13, [rsp+0xC0]
00007d55df7e0673  vmovaps xmm14, [rsp+0xD0]
00007d55df7e067c  vmovaps xmm15, [rsp+0xE0]
00007d55df7e0685  add rsp, 0xF0
00007d55df7e068c  pop r11
00007d55df7e068e  pop r10
00007d55df7e0690  pop r9
00007d55df7e0692  pop r8
00007d55df7e0694  pop rsi
00007d55df7e0695  pop rdi
00007d55df7e0696  pop rdx
00007d55df7e0697  pop rcx
00007d55df7e0698  pop rax
00007d55df7e0699  add rsp, 0x08
00007d55df7e069d  jmp 0x00007D55DF7DEE8E
00007d55df7e06a2  call 0x00007D55DF6B52F0
00007d55df7e06a7  jmp 0x00007D55DF7DEFA8
00007d55df7e06ac  call 0x00007D55DF6B52F0
00007d55df7e06b1  jmp 0x00007D55DF7DEFBE
00007d55df7e06b6  sub rsp, 0x08
00007d55df7e06ba  push rax
00007d55df7e06bb  push rcx
00007d55df7e06bc  push rdx
00007d55df7e06bd  push rdi
00007d55df7e06be  push rsi
00007d55df7e06bf  push r8
00007d55df7e06c1  push r9
00007d55df7e06c3  push r10
00007d55df7e06c5  push r11
00007d55df7e06c7  sub rsp, 0xF0
00007d55df7e06ce  vmovaps [rsp], xmm0
00007d55df7e06d3  vmovaps [rsp+0x10], xmm2
00007d55df7e06d9  vmovaps [rsp+0x20], xmm3
00007d55df7e06df  vmovaps [rsp+0x30], xmm4
00007d55df7e06e5  vmovaps [rsp+0x40], xmm5
00007d55df7e06eb  vmovaps [rsp+0x50], xmm6
00007d55df7e06f1  vmovaps [rsp+0x60], xmm7
00007d55df7e06f7  vmovaps [rsp+0x70], xmm8
00007d55df7e06fd  vmovaps [rsp+0x80], xmm9
00007d55df7e0706  vmovaps [rsp+0x90], xmm10
00007d55df7e070f  vmovaps [rsp+0xA0], xmm11
00007d55df7e0718  vmovaps [rsp+0xB0], xmm12
00007d55df7e0721  vmovaps [rsp+0xC0], xmm13
00007d55df7e072a  vmovaps [rsp+0xD0], xmm14
00007d55df7e0733  vmovaps [rsp+0xE0], xmm15
00007d55df7e073c  sub rsp, 0x30
00007d55df7e0740  movaps [rsp], xmm1
00007d55df7e0744  movaps [rsp+0x10], xmm6
00007d55df7e0749  movaps [rsp+0x20], xmm15
00007d55df7e074f  lea rdi, [rsp]
00007d55df7e0753  mov esi, 0x00
00007d55df7e0758  mov rax, 0x5BB8433D8530
00007d55df7e0762  call rax
00007d55df7e0764  movaps xmm1, [rsp]
00007d55df7e0768  add rsp, 0x30
00007d55df7e076c  vmovaps xmm0, [rsp]
00007d55df7e0771  vmovaps xmm2, [rsp+0x10]
00007d55df7e0777  vmovaps xmm3, [rsp+0x20]
00007d55df7e077d  vmovaps xmm4, [rsp+0x30]
00007d55df7e0783  vmovaps xmm5, [rsp+0x40]
00007d55df7e0789  vmovaps xmm6, [rsp+0x50]
00007d55df7e078f  vmovaps xmm7, [rsp+0x60]
00007d55df7e0795  vmovaps xmm8, [rsp+0x70]
00007d55df7e079b  vmovaps xmm9, [rsp+0x80]
00007d55df7e07a4  vmovaps xmm10, [rsp+0x90]
00007d55df7e07ad  vmovaps xmm11, [rsp+0xA0]
00007d55df7e07b6  vmovaps xmm12, [rsp+0xB0]
00007d55df7e07bf  vmovaps xmm13, [rsp+0xC0]
00007d55df7e07c8  vmovaps xmm14, [rsp+0xD0]
00007d55df7e07d1  vmovaps xmm15, [rsp+0xE0]
00007d55df7e07da  add rsp, 0xF0
00007d55df7e07e1  pop r11
00007d55df7e07e3  pop r10
00007d55df7e07e5  pop r9
00007d55df7e07e7  pop r8
00007d55df7e07e9  pop rsi
00007d55df7e07ea  pop rdi
00007d55df7e07eb  pop rdx
00007d55df7e07ec  pop rcx
00007d55df7e07ed  pop rax
00007d55df7e07ee  add rsp, 0x08
00007d55df7e07f2  jmp 0x00007D55DF7DEFFB
00007d55df7e07f7  call 0x00007D55DF6C4620
00007d55df7e07fc  jmp 0x00007D55DF7DF008
00007d55df7e0801  sub rsp, 0x08
00007d55df7e0805  push rax
00007d55df7e0806  push rcx
00007d55df7e0807  push rdx
00007d55df7e0808  push rdi
00007d55df7e0809  push rsi
00007d55df7e080a  push r8
00007d55df7e080c  push r9
00007d55df7e080e  push r10
00007d55df7e0810  push r11
00007d55df7e0812  sub rsp, 0xF0
00007d55df7e0819  vmovaps [rsp], xmm0
00007d55df7e081e  vmovaps [rsp+0x10], xmm1
00007d55df7e0824  vmovaps [rsp+0x20], xmm2
00007d55df7e082a  vmovaps [rsp+0x30], xmm3
00007d55df7e0830  vmovaps [rsp+0x40], xmm4
00007d55df7e0836  vmovaps [rsp+0x50], xmm5
00007d55df7e083c  vmovaps [rsp+0x60], xmm6
00007d55df7e0842  vmovaps [rsp+0x70], xmm7
00007d55df7e0848  vmovaps [rsp+0x80], xmm8
00007d55df7e0851  vmovaps [rsp+0x90], xmm9
00007d55df7e085a  vmovaps [rsp+0xA0], xmm10
00007d55df7e0863  vmovaps [rsp+0xB0], xmm11
00007d55df7e086c  vmovaps [rsp+0xC0], xmm12
00007d55df7e0875  vmovaps [rsp+0xD0], xmm13
00007d55df7e087e  vmovaps [rsp+0xE0], xmm15
00007d55df7e0887  sub rsp, 0x30
00007d55df7e088b  movaps [rsp], xmm14
00007d55df7e0890  movaps [rsp+0x10], xmm4
00007d55df7e0895  movaps [rsp+0x20], xmm3
00007d55df7e089a  lea rdi, [rsp]
00007d55df7e089e  mov esi, 0x00
00007d55df7e08a3  mov rax, 0x5BB8433D8530
00007d55df7e08ad  call rax
00007d55df7e08af  movaps xmm14, [rsp]
00007d55df7e08b4  add rsp, 0x30
00007d55df7e08b8  vmovaps xmm0, [rsp]
00007d55df7e08bd  vmovaps xmm1, [rsp+0x10]
00007d55df7e08c3  vmovaps xmm2, [rsp+0x20]
00007d55df7e08c9  vmovaps xmm3, [rsp+0x30]
00007d55df7e08cf  vmovaps xmm4, [rsp+0x40]
00007d55df7e08d5  vmovaps xmm5, [rsp+0x50]
00007d55df7e08db  vmovaps xmm6, [rsp+0x60]
00007d55df7e08e1  vmovaps xmm7, [rsp+0x70]
00007d55df7e08e7  vmovaps xmm8, [rsp+0x80]
00007d55df7e08f0  vmovaps xmm9, [rsp+0x90]
00007d55df7e08f9  vmovaps xmm10, [rsp+0xA0]
00007d55df7e0902  vmovaps xmm11, [rsp+0xB0]
00007d55df7e090b  vmovaps xmm12, [rsp+0xC0]
00007d55df7e0914  vmovaps xmm13, [rsp+0xD0]
00007d55df7e091d  vmovaps xmm15, [rsp+0xE0]
00007d55df7e0926  add rsp, 0xF0
00007d55df7e092d  pop r11
00007d55df7e092f  pop r10
00007d55df7e0931  pop r9
00007d55df7e0933  pop r8
00007d55df7e0935  pop rsi
00007d55df7e0936  pop rdi
00007d55df7e0937  pop rdx
00007d55df7e0938  pop rcx
00007d55df7e0939  pop rax
00007d55df7e093a  add rsp, 0x08
00007d55df7e093e  jmp 0x00007D55DF7DF022
00007d55df7e0943  sub rsp, 0x08
00007d55df7e0947  push rax
00007d55df7e0948  push rcx
00007d55df7e0949  push rdx
00007d55df7e094a  push rdi
00007d55df7e094b  push rsi
00007d55df7e094c  push r8
00007d55df7e094e  push r9
00007d55df7e0950  push r10
00007d55df7e0952  push r11
00007d55df7e0954  sub rsp, 0xF0
00007d55df7e095b  vmovaps [rsp], xmm0
00007d55df7e0960  vmovaps [rsp+0x10], xmm1
00007d55df7e0966  vmovaps [rsp+0x20], xmm2
00007d55df7e096c  vmovaps [rsp+0x30], xmm3
00007d55df7e0972  vmovaps [rsp+0x40], xmm4
00007d55df7e0978  vmovaps [rsp+0x50], xmm5
00007d55df7e097e  vmovaps [rsp+0x60], xmm7
00007d55df7e0984  vmovaps [rsp+0x70], xmm8
00007d55df7e098a  vmovaps [rsp+0x80], xmm9
00007d55df7e0993  vmovaps [rsp+0x90], xmm10
00007d55df7e099c  vmovaps [rsp+0xA0], xmm11
00007d55df7e09a5  vmovaps [rsp+0xB0], xmm12
00007d55df7e09ae  vmovaps [rsp+0xC0], xmm13
00007d55df7e09b7  vmovaps [rsp+0xD0], xmm14
00007d55df7e09c0  vmovaps [rsp+0xE0], xmm15
00007d55df7e09c9  sub rsp, 0x30
00007d55df7e09cd  movaps [rsp], xmm6
00007d55df7e09d1  movaps [rsp+0x10], xmm9
00007d55df7e09d7  movaps [rsp+0x20], xmm7
00007d55df7e09dc  lea rdi, [rsp]
00007d55df7e09e0  mov esi, 0x00
00007d55df7e09e5  mov rax, 0x5BB8433D8530
00007d55df7e09ef  call rax
00007d55df7e09f1  movaps xmm6, [rsp]
00007d55df7e09f5  add rsp, 0x30
00007d55df7e09f9  vmovaps xmm0, [rsp]
00007d55df7e09fe  vmovaps xmm1, [rsp+0x10]
00007d55df7e0a04  vmovaps xmm2, [rsp+0x20]
00007d55df7e0a0a  vmovaps xmm3, [rsp+0x30]
00007d55df7e0a10  vmovaps xmm4, [rsp+0x40]
00007d55df7e0a16  vmovaps xmm5, [rsp+0x50]
00007d55df7e0a1c  vmovaps xmm7, [rsp+0x60]
00007d55df7e0a22  vmovaps xmm8, [rsp+0x70]
00007d55df7e0a28  vmovaps xmm9, [rsp+0x80]
00007d55df7e0a31  vmovaps xmm10, [rsp+0x90]
00007d55df7e0a3a  vmovaps xmm11, [rsp+0xA0]
00007d55df7e0a43  vmovaps xmm12, [rsp+0xB0]
00007d55df7e0a4c  vmovaps xmm13, [rsp+0xC0]
00007d55df7e0a55  vmovaps xmm14, [rsp+0xD0]
00007d55df7e0a5e  vmovaps xmm15, [rsp+0xE0]
00007d55df7e0a67  add rsp, 0xF0
00007d55df7e0a6e  pop r11
00007d55df7e0a70  pop r10
00007d55df7e0a72  pop r9
00007d55df7e0a74  pop r8
00007d55df7e0a76  pop rsi
00007d55df7e0a77  pop rdi
00007d55df7e0a78  pop rdx
00007d55df7e0a79  pop rcx
00007d55df7e0a7a  pop rax
00007d55df7e0a7b  add rsp, 0x08
00007d55df7e0a7f  jmp 0x00007D55DF7DF03A
00007d55df7e0a84  sub rsp, 0x08
00007d55df7e0a88  push rax
00007d55df7e0a89  push rcx
00007d55df7e0a8a  push rdx
00007d55df7e0a8b  push rdi
00007d55df7e0a8c  push rsi
00007d55df7e0a8d  push r8
00007d55df7e0a8f  push r9
00007d55df7e0a91  push r10
00007d55df7e0a93  push r11
00007d55df7e0a95  sub rsp, 0xF0
00007d55df7e0a9c  vmovaps [rsp], xmm0
00007d55df7e0aa1  vmovaps [rsp+0x10], xmm1
00007d55df7e0aa7  vmovaps [rsp+0x20], xmm2
00007d55df7e0aad  vmovaps [rsp+0x30], xmm3
00007d55df7e0ab3  vmovaps [rsp+0x40], xmm4
00007d55df7e0ab9  vmovaps [rsp+0x50], xmm5
00007d55df7e0abf  vmovaps [rsp+0x60], xmm6
00007d55df7e0ac5  vmovaps [rsp+0x70], xmm8
00007d55df7e0acb  vmovaps [rsp+0x80], xmm9
00007d55df7e0ad4  vmovaps [rsp+0x90], xmm10
00007d55df7e0add  vmovaps [rsp+0xA0], xmm11
00007d55df7e0ae6  vmovaps [rsp+0xB0], xmm12
00007d55df7e0aef  vmovaps [rsp+0xC0], xmm13
00007d55df7e0af8  vmovaps [rsp+0xD0], xmm14
00007d55df7e0b01  vmovaps [rsp+0xE0], xmm15
00007d55df7e0b0a  sub rsp, 0x30
00007d55df7e0b0e  movaps [rsp], xmm7
00007d55df7e0b12  movaps [rsp+0x10], xmm4
00007d55df7e0b17  movaps [rsp+0x20], xmm9
00007d55df7e0b1d  lea rdi, [rsp]
00007d55df7e0b21  mov esi, 0x00
00007d55df7e0b26  mov rax, 0x5BB8433D8530
00007d55df7e0b30  call rax
00007d55df7e0b32  movaps xmm7, [rsp]
00007d55df7e0b36  add rsp, 0x30
00007d55df7e0b3a  vmovaps xmm0, [rsp]
00007d55df7e0b3f  vmovaps xmm1, [rsp+0x10]
00007d55df7e0b45  vmovaps xmm2, [rsp+0x20]
00007d55df7e0b4b  vmovaps xmm3, [rsp+0x30]
00007d55df7e0b51  vmovaps xmm4, [rsp+0x40]
00007d55df7e0b57  vmovaps xmm5, [rsp+0x50]
00007d55df7e0b5d  vmovaps xmm6, [rsp+0x60]
00007d55df7e0b63  vmovaps xmm8, [rsp+0x70]
00007d55df7e0b69  vmovaps xmm9, [rsp+0x80]
00007d55df7e0b72  vmovaps xmm10, [rsp+0x90]
00007d55df7e0b7b  vmovaps xmm11, [rsp+0xA0]
00007d55df7e0b84  vmovaps xmm12, [rsp+0xB0]
00007d55df7e0b8d  vmovaps xmm13, [rsp+0xC0]
00007d55df7e0b96  vmovaps xmm14, [rsp+0xD0]
00007d55df7e0b9f  vmovaps xmm15, [rsp+0xE0]
00007d55df7e0ba8  add rsp, 0xF0
00007d55df7e0baf  pop r11
00007d55df7e0bb1  pop r10
00007d55df7e0bb3  pop r9
00007d55df7e0bb5  pop r8
00007d55df7e0bb7  pop rsi
00007d55df7e0bb8  pop rdi
00007d55df7e0bb9  pop rdx
00007d55df7e0bba  pop rcx
00007d55df7e0bbb  pop rax
00007d55df7e0bbc  add rsp, 0x08
00007d55df7e0bc0  jmp 0x00007D55DF7DF067
00007d55df7e0bc5  sub rsp, 0x08
00007d55df7e0bc9  push rax
00007d55df7e0bca  push rcx
00007d55df7e0bcb  push rdx
00007d55df7e0bcc  push rdi
00007d55df7e0bcd  push rsi
00007d55df7e0bce  push r8
00007d55df7e0bd0  push r9
00007d55df7e0bd2  push r10
00007d55df7e0bd4  push r11
00007d55df7e0bd6  sub rsp, 0xF0
00007d55df7e0bdd  vmovaps [rsp], xmm0
00007d55df7e0be2  vmovaps [rsp+0x10], xmm1
00007d55df7e0be8  vmovaps [rsp+0x20], xmm2
00007d55df7e0bee  vmovaps [rsp+0x30], xmm3
00007d55df7e0bf4  vmovaps [rsp+0x40], xmm5
00007d55df7e0bfa  vmovaps [rsp+0x50], xmm6
00007d55df7e0c00  vmovaps [rsp+0x60], xmm7
00007d55df7e0c06  vmovaps [rsp+0x70], xmm8
00007d55df7e0c0c  vmovaps [rsp+0x80], xmm9
00007d55df7e0c15  vmovaps [rsp+0x90], xmm10
00007d55df7e0c1e  vmovaps [rsp+0xA0], xmm11
00007d55df7e0c27  vmovaps [rsp+0xB0], xmm12
00007d55df7e0c30  vmovaps [rsp+0xC0], xmm13
00007d55df7e0c39  vmovaps [rsp+0xD0], xmm14
00007d55df7e0c42  vmovaps [rsp+0xE0], xmm15
00007d55df7e0c4b  sub rsp, 0x30
00007d55df7e0c4f  movaps [rsp], xmm4
00007d55df7e0c53  movaps [rsp+0x10], xmm15
00007d55df7e0c59  movaps [rsp+0x20], xmm9
00007d55df7e0c5f  lea rdi, [rsp]
00007d55df7e0c63  mov esi, 0x00
00007d55df7e0c68  mov rax, 0x5BB8433D8530
00007d55df7e0c72  call rax
00007d55df7e0c74  movaps xmm4, [rsp]
00007d55df7e0c78  add rsp, 0x30
00007d55df7e0c7c  vmovaps xmm0, [rsp]
00007d55df7e0c81  vmovaps xmm1, [rsp+0x10]
00007d55df7e0c87  vmovaps xmm2, [rsp+0x20]
00007d55df7e0c8d  vmovaps xmm3, [rsp+0x30]
00007d55df7e0c93  vmovaps xmm5, [rsp+0x40]
00007d55df7e0c99  vmovaps xmm6, [rsp+0x50]
00007d55df7e0c9f  vmovaps xmm7, [rsp+0x60]
00007d55df7e0ca5  vmovaps xmm8, [rsp+0x70]
00007d55df7e0cab  vmovaps xmm9, [rsp+0x80]
00007d55df7e0cb4  vmovaps xmm10, [rsp+0x90]
00007d55df7e0cbd  vmovaps xmm11, [rsp+0xA0]
00007d55df7e0cc6  vmovaps xmm12, [rsp+0xB0]
00007d55df7e0ccf  vmovaps xmm13, [rsp+0xC0]
00007d55df7e0cd8  vmovaps xmm14, [rsp+0xD0]
00007d55df7e0ce1  vmovaps xmm15, [rsp+0xE0]
00007d55df7e0cea  add rsp, 0xF0
00007d55df7e0cf1  pop r11
00007d55df7e0cf3  pop r10
00007d55df7e0cf5  pop r9
00007d55df7e0cf7  pop r8
00007d55df7e0cf9  pop rsi
00007d55df7e0cfa  pop rdi
00007d55df7e0cfb  pop rdx
00007d55df7e0cfc  pop rcx
00007d55df7e0cfd  pop rax
00007d55df7e0cfe  add rsp, 0x08
00007d55df7e0d02  jmp 0x00007D55DF7DF08C
00007d55df7e0d07  call 0x00007D55DF6C4620
00007d55df7e0d0c  jmp 0x00007D55DF7DF099
00007d55df7e0d11  sub rsp, 0x08
00007d55df7e0d15  push rax
00007d55df7e0d16  push rcx
00007d55df7e0d17  push rdx
00007d55df7e0d18  push rdi
00007d55df7e0d19  push rsi
00007d55df7e0d1a  push r8
00007d55df7e0d1c  push r9
00007d55df7e0d1e  push r10
00007d55df7e0d20  push r11
00007d55df7e0d22  sub rsp, 0xF0
00007d55df7e0d29  vmovaps [rsp], xmm0
00007d55df7e0d2e  vmovaps [rsp+0x10], xmm1
00007d55df7e0d34  vmovaps [rsp+0x20], xmm2
00007d55df7e0d3a  vmovaps [rsp+0x30], xmm4
00007d55df7e0d40  vmovaps [rsp+0x40], xmm5
00007d55df7e0d46  vmovaps [rsp+0x50], xmm6
00007d55df7e0d4c  vmovaps [rsp+0x60], xmm7
00007d55df7e0d52  vmovaps [rsp+0x70], xmm8
00007d55df7e0d58  vmovaps [rsp+0x80], xmm9
00007d55df7e0d61  vmovaps [rsp+0x90], xmm10
00007d55df7e0d6a  vmovaps [rsp+0xA0], xmm11
00007d55df7e0d73  vmovaps [rsp+0xB0], xmm12
00007d55df7e0d7c  vmovaps [rsp+0xC0], xmm13
00007d55df7e0d85  vmovaps [rsp+0xD0], xmm14
00007d55df7e0d8e  vmovaps [rsp+0xE0], xmm15
00007d55df7e0d97  sub rsp, 0x30
00007d55df7e0d9b  movaps [rsp], xmm3
00007d55df7e0d9f  movaps [rsp+0x10], xmm1
00007d55df7e0da4  movaps [rsp+0x20], xmm9
00007d55df7e0daa  lea rdi, [rsp]
00007d55df7e0dae  mov esi, 0x00
00007d55df7e0db3  mov rax, 0x5BB8433D8530
00007d55df7e0dbd  call rax
00007d55df7e0dbf  movaps xmm3, [rsp]
00007d55df7e0dc3  add rsp, 0x30
00007d55df7e0dc7  vmovaps xmm0, [rsp]
00007d55df7e0dcc  vmovaps xmm1, [rsp+0x10]
00007d55df7e0dd2  vmovaps xmm2, [rsp+0x20]
00007d55df7e0dd8  vmovaps xmm4, [rsp+0x30]
00007d55df7e0dde  vmovaps xmm5, [rsp+0x40]
00007d55df7e0de4  vmovaps xmm6, [rsp+0x50]
00007d55df7e0dea  vmovaps xmm7, [rsp+0x60]
00007d55df7e0df0  vmovaps xmm8, [rsp+0x70]
00007d55df7e0df6  vmovaps xmm9, [rsp+0x80]
00007d55df7e0dff  vmovaps xmm10, [rsp+0x90]
00007d55df7e0e08  vmovaps xmm11, [rsp+0xA0]
00007d55df7e0e11  vmovaps xmm12, [rsp+0xB0]
00007d55df7e0e1a  vmovaps xmm13, [rsp+0xC0]
00007d55df7e0e23  vmovaps xmm14, [rsp+0xD0]
00007d55df7e0e2c  vmovaps xmm15, [rsp+0xE0]
00007d55df7e0e35  add rsp, 0xF0
00007d55df7e0e3c  pop r11
00007d55df7e0e3e  pop r10
00007d55df7e0e40  pop r9
00007d55df7e0e42  pop r8
00007d55df7e0e44  pop rsi
00007d55df7e0e45  pop rdi
00007d55df7e0e46  pop rdx
00007d55df7e0e47  pop rcx
00007d55df7e0e48  pop rax
00007d55df7e0e49  add rsp, 0x08
00007d55df7e0e4d  jmp 0x00007D55DF7DF0D6
00007d55df7e0e52  sub rsp, 0x08
00007d55df7e0e56  push rax
00007d55df7e0e57  push rcx
00007d55df7e0e58  push rdx
00007d55df7e0e59  push rdi
00007d55df7e0e5a  push rsi
00007d55df7e0e5b  push r8
00007d55df7e0e5d  push r9
00007d55df7e0e5f  push r10
00007d55df7e0e61  push r11
00007d55df7e0e63  sub rsp, 0xF0
00007d55df7e0e6a  vmovaps [rsp], xmm0
00007d55df7e0e6f  vmovaps [rsp+0x10], xmm2
00007d55df7e0e75  vmovaps [rsp+0x20], xmm3
00007d55df7e0e7b  vmovaps [rsp+0x30], xmm4
00007d55df7e0e81  vmovaps [rsp+0x40], xmm5
00007d55df7e0e87  vmovaps [rsp+0x50], xmm6
00007d55df7e0e8d  vmovaps [rsp+0x60], xmm7
00007d55df7e0e93  vmovaps [rsp+0x70], xmm8
00007d55df7e0e99  vmovaps [rsp+0x80], xmm9
00007d55df7e0ea2  vmovaps [rsp+0x90], xmm10
00007d55df7e0eab  vmovaps [rsp+0xA0], xmm11
00007d55df7e0eb4  vmovaps [rsp+0xB0], xmm12
00007d55df7e0ebd  vmovaps [rsp+0xC0], xmm13
00007d55df7e0ec6  vmovaps [rsp+0xD0], xmm14
00007d55df7e0ecf  vmovaps [rsp+0xE0], xmm15
00007d55df7e0ed8  sub rsp, 0x30
00007d55df7e0edc  movaps [rsp], xmm1
00007d55df7e0ee0  movaps [rsp+0x10], xmm15
00007d55df7e0ee6  movaps [rsp+0x20], xmm9
00007d55df7e0eec  lea rdi, [rsp]
00007d55df7e0ef0  mov esi, 0x00
00007d55df7e0ef5  mov rax, 0x5BB8433D8530
00007d55df7e0eff  call rax
00007d55df7e0f01  movaps xmm1, [rsp]
00007d55df7e0f05  add rsp, 0x30
00007d55df7e0f09  vmovaps xmm0, [rsp]
00007d55df7e0f0e  vmovaps xmm2, [rsp+0x10]
00007d55df7e0f14  vmovaps xmm3, [rsp+0x20]
00007d55df7e0f1a  vmovaps xmm4, [rsp+0x30]
00007d55df7e0f20  vmovaps xmm5, [rsp+0x40]
00007d55df7e0f26  vmovaps xmm6, [rsp+0x50]
00007d55df7e0f2c  vmovaps xmm7, [rsp+0x60]
00007d55df7e0f32  vmovaps xmm8, [rsp+0x70]
00007d55df7e0f38  vmovaps xmm9, [rsp+0x80]
00007d55df7e0f41  vmovaps xmm10, [rsp+0x90]
00007d55df7e0f4a  vmovaps xmm11, [rsp+0xA0]
00007d55df7e0f53  vmovaps xmm12, [rsp+0xB0]
00007d55df7e0f5c  vmovaps xmm13, [rsp+0xC0]
00007d55df7e0f65  vmovaps xmm14, [rsp+0xD0]
00007d55df7e0f6e  vmovaps xmm15, [rsp+0xE0]
00007d55df7e0f77  add rsp, 0xF0
00007d55df7e0f7e  pop r11
00007d55df7e0f80  pop r10
00007d55df7e0f82  pop r9
00007d55df7e0f84  pop r8
00007d55df7e0f86  pop rsi
00007d55df7e0f87  pop rdi
00007d55df7e0f88  pop rdx
00007d55df7e0f89  pop rcx
00007d55df7e0f8a  pop rax
00007d55df7e0f8b  add rsp, 0x08
00007d55df7e0f8f  jmp 0x00007D55DF7DF15E
00007d55df7e0f94  call 0x00007D55DF6C4620
00007d55df7e0f99  jmp 0x00007D55DF7DF16B
00007d55df7e0f9e  sub rsp, 0x08
00007d55df7e0fa2  push rax
00007d55df7e0fa3  push rcx
00007d55df7e0fa4  push rdx
00007d55df7e0fa5  push rdi
00007d55df7e0fa6  push rsi
00007d55df7e0fa7  push r8
00007d55df7e0fa9  push r9
00007d55df7e0fab  push r10
00007d55df7e0fad  push r11
00007d55df7e0faf  sub rsp, 0xF0
00007d55df7e0fb6  vmovaps [rsp], xmm0
00007d55df7e0fbb  vmovaps [rsp+0x10], xmm2
00007d55df7e0fc1  vmovaps [rsp+0x20], xmm3
00007d55df7e0fc7  vmovaps [rsp+0x30], xmm4
00007d55df7e0fcd  vmovaps [rsp+0x40], xmm5
00007d55df7e0fd3  vmovaps [rsp+0x50], xmm6
00007d55df7e0fd9  vmovaps [rsp+0x60], xmm7
00007d55df7e0fdf  vmovaps [rsp+0x70], xmm8
00007d55df7e0fe5  vmovaps [rsp+0x80], xmm9
00007d55df7e0fee  vmovaps [rsp+0x90], xmm10
00007d55df7e0ff7  vmovaps [rsp+0xA0], xmm11
00007d55df7e1000  vmovaps [rsp+0xB0], xmm12
00007d55df7e1009  vmovaps [rsp+0xC0], xmm13
00007d55df7e1012  vmovaps [rsp+0xD0], xmm14
00007d55df7e101b  vmovaps [rsp+0xE0], xmm15
00007d55df7e1024  sub rsp, 0x30
00007d55df7e1028  movaps [rsp], xmm1
00007d55df7e102c  movaps [rsp+0x10], xmm5
00007d55df7e1031  movaps [rsp+0x20], xmm7
00007d55df7e1036  lea rdi, [rsp]
00007d55df7e103a  mov esi, 0x00
00007d55df7e103f  mov rax, 0x5BB8433D8530
00007d55df7e1049  call rax
00007d55df7e104b  movaps xmm1, [rsp]
00007d55df7e104f  add rsp, 0x30
00007d55df7e1053  vmovaps xmm0, [rsp]
00007d55df7e1058  vmovaps xmm2, [rsp+0x10]
00007d55df7e105e  vmovaps xmm3, [rsp+0x20]
00007d55df7e1064  vmovaps xmm4, [rsp+0x30]
00007d55df7e106a  vmovaps xmm5, [rsp+0x40]
00007d55df7e1070  vmovaps xmm6, [rsp+0x50]
00007d55df7e1076  vmovaps xmm7, [rsp+0x60]
00007d55df7e107c  vmovaps xmm8, [rsp+0x70]
00007d55df7e1082  vmovaps xmm9, [rsp+0x80]
00007d55df7e108b  vmovaps xmm10, [rsp+0x90]
00007d55df7e1094  vmovaps xmm11, [rsp+0xA0]
00007d55df7e109d  vmovaps xmm12, [rsp+0xB0]
00007d55df7e10a6  vmovaps xmm13, [rsp+0xC0]
00007d55df7e10af  vmovaps xmm14, [rsp+0xD0]
00007d55df7e10b8  vmovaps xmm15, [rsp+0xE0]
00007d55df7e10c1  add rsp, 0xF0
00007d55df7e10c8  pop r11
00007d55df7e10ca  pop r10
00007d55df7e10cc  pop r9
00007d55df7e10ce  pop r8
00007d55df7e10d0  pop rsi
00007d55df7e10d1  pop rdi
00007d55df7e10d2  pop rdx
00007d55df7e10d3  pop rcx
00007d55df7e10d4  pop rax
00007d55df7e10d5  add rsp, 0x08
00007d55df7e10d9  jmp 0x00007D55DF7DF210
00007d55df7e10de  sub rsp, 0x08
00007d55df7e10e2  push rax
00007d55df7e10e3  push rcx
00007d55df7e10e4  push rdx
00007d55df7e10e5  push rdi
00007d55df7e10e6  push rsi
00007d55df7e10e7  push r8
00007d55df7e10e9  push r9
00007d55df7e10eb  push r10
00007d55df7e10ed  push r11
00007d55df7e10ef  sub rsp, 0xF0
00007d55df7e10f6  vmovaps [rsp], xmm0
00007d55df7e10fb  vmovaps [rsp+0x10], xmm1
00007d55df7e1101  vmovaps [rsp+0x20], xmm2
00007d55df7e1107  vmovaps [rsp+0x30], xmm3
00007d55df7e110d  vmovaps [rsp+0x40], xmm4
00007d55df7e1113  vmovaps [rsp+0x50], xmm5
00007d55df7e1119  vmovaps [rsp+0x60], xmm6
00007d55df7e111f  vmovaps [rsp+0x70], xmm8
00007d55df7e1125  vmovaps [rsp+0x80], xmm9
00007d55df7e112e  vmovaps [rsp+0x90], xmm10
00007d55df7e1137  vmovaps [rsp+0xA0], xmm11
00007d55df7e1140  vmovaps [rsp+0xB0], xmm12
00007d55df7e1149  vmovaps [rsp+0xC0], xmm13
00007d55df7e1152  vmovaps [rsp+0xD0], xmm14
00007d55df7e115b  vmovaps [rsp+0xE0], xmm15
00007d55df7e1164  sub rsp, 0x30
00007d55df7e1168  movaps [rsp], xmm7
00007d55df7e116c  movaps [rsp+0x10], xmm5
00007d55df7e1171  movaps [rsp+0x20], xmm15
00007d55df7e1177  lea rdi, [rsp]
00007d55df7e117b  mov esi, 0x00
00007d55df7e1180  mov rax, 0x5BB8433D8530
00007d55df7e118a  call rax
00007d55df7e118c  movaps xmm7, [rsp]
00007d55df7e1190  add rsp, 0x30
00007d55df7e1194  vmovaps xmm0, [rsp]
00007d55df7e1199  vmovaps xmm1, [rsp+0x10]
00007d55df7e119f  vmovaps xmm2, [rsp+0x20]
00007d55df7e11a5  vmovaps xmm3, [rsp+0x30]
00007d55df7e11ab  vmovaps xmm4, [rsp+0x40]
00007d55df7e11b1  vmovaps xmm5, [rsp+0x50]
00007d55df7e11b7  vmovaps xmm6, [rsp+0x60]
00007d55df7e11bd  vmovaps xmm8, [rsp+0x70]
00007d55df7e11c3  vmovaps xmm9, [rsp+0x80]
00007d55df7e11cc  vmovaps xmm10, [rsp+0x90]
00007d55df7e11d5  vmovaps xmm11, [rsp+0xA0]
00007d55df7e11de  vmovaps xmm12, [rsp+0xB0]
00007d55df7e11e7  vmovaps xmm13, [rsp+0xC0]
00007d55df7e11f0  vmovaps xmm14, [rsp+0xD0]
00007d55df7e11f9  vmovaps xmm15, [rsp+0xE0]
00007d55df7e1202  add rsp, 0xF0
00007d55df7e1209  pop r11
00007d55df7e120b  pop r10
00007d55df7e120d  pop r9
00007d55df7e120f  pop r8
00007d55df7e1211  pop rsi
00007d55df7e1212  pop rdi
00007d55df7e1213  pop rdx
00007d55df7e1214  pop rcx
00007d55df7e1215  pop rax
00007d55df7e1216  add rsp, 0x08
00007d55df7e121a  jmp 0x00007D55DF7DF246
00007d55df7e121f  call 0x00007D55DF6B52F0
00007d55df7e1224  jmp 0x00007D55DF7DF253
00007d55df7e1229  sub rsp, 0x08
00007d55df7e122d  push rax
00007d55df7e122e  push rcx
00007d55df7e122f  push rdx
00007d55df7e1230  push rdi
00007d55df7e1231  push rsi
00007d55df7e1232  push r8
00007d55df7e1234  push r9
00007d55df7e1236  push r10
00007d55df7e1238  push r11
00007d55df7e123a  sub rsp, 0xF0
00007d55df7e1241  vmovaps [rsp], xmm0
00007d55df7e1246  vmovaps [rsp+0x10], xmm1
00007d55df7e124c  vmovaps [rsp+0x20], xmm2
00007d55df7e1252  vmovaps [rsp+0x30], xmm3
00007d55df7e1258  vmovaps [rsp+0x40], xmm4
00007d55df7e125e  vmovaps [rsp+0x50], xmm5
00007d55df7e1264  vmovaps [rsp+0x60], xmm6
00007d55df7e126a  vmovaps [rsp+0x70], xmm7
00007d55df7e1270  vmovaps [rsp+0x80], xmm8
00007d55df7e1279  vmovaps [rsp+0x90], xmm9
00007d55df7e1282  vmovaps [rsp+0xA0], xmm10
00007d55df7e128b  vmovaps [rsp+0xB0], xmm11
00007d55df7e1294  vmovaps [rsp+0xC0], xmm12
00007d55df7e129d  vmovaps [rsp+0xD0], xmm13
00007d55df7e12a6  vmovaps [rsp+0xE0], xmm14
00007d55df7e12af  sub rsp, 0x30
00007d55df7e12b3  movaps [rsp], xmm15
00007d55df7e12b8  movaps [rsp+0x10], xmm5
00007d55df7e12bd  movaps [rsp+0x20], xmm3
00007d55df7e12c2  lea rdi, [rsp]
00007d55df7e12c6  mov esi, 0x00
00007d55df7e12cb  mov rax, 0x5BB8433D8530
00007d55df7e12d5  call rax
00007d55df7e12d7  movaps xmm15, [rsp]
00007d55df7e12dc  add rsp, 0x30
00007d55df7e12e0  vmovaps xmm0, [rsp]
00007d55df7e12e5  vmovaps xmm1, [rsp+0x10]
00007d55df7e12eb  vmovaps xmm2, [rsp+0x20]
00007d55df7e12f1  vmovaps xmm3, [rsp+0x30]
00007d55df7e12f7  vmovaps xmm4, [rsp+0x40]
00007d55df7e12fd  vmovaps xmm5, [rsp+0x50]
00007d55df7e1303  vmovaps xmm6, [rsp+0x60]
00007d55df7e1309  vmovaps xmm7, [rsp+0x70]
00007d55df7e130f  vmovaps xmm8, [rsp+0x80]
00007d55df7e1318  vmovaps xmm9, [rsp+0x90]
00007d55df7e1321  vmovaps xmm10, [rsp+0xA0]
00007d55df7e132a  vmovaps xmm11, [rsp+0xB0]
00007d55df7e1333  vmovaps xmm12, [rsp+0xC0]
00007d55df7e133c  vmovaps xmm13, [rsp+0xD0]
00007d55df7e1345  vmovaps xmm14, [rsp+0xE0]
00007d55df7e134e  add rsp, 0xF0
00007d55df7e1355  pop r11
00007d55df7e1357  pop r10
00007d55df7e1359  pop r9
00007d55df7e135b  pop r8
00007d55df7e135d  pop rsi
00007d55df7e135e  pop rdi
00007d55df7e135f  pop rdx
00007d55df7e1360  pop rcx
00007d55df7e1361  pop rax
00007d55df7e1362  add rsp, 0x08
00007d55df7e1366  jmp 0x00007D55DF7DF279
00007d55df7e136b  sub rsp, 0x08
00007d55df7e136f  push rax
00007d55df7e1370  push rcx
00007d55df7e1371  push rdx
00007d55df7e1372  push rdi
00007d55df7e1373  push rsi
00007d55df7e1374  push r8
00007d55df7e1376  push r9
00007d55df7e1378  push r10
00007d55df7e137a  push r11
00007d55df7e137c  sub rsp, 0xF0
00007d55df7e1383  vmovaps [rsp], xmm0
00007d55df7e1388  vmovaps [rsp+0x10], xmm2
00007d55df7e138e  vmovaps [rsp+0x20], xmm3
00007d55df7e1394  vmovaps [rsp+0x30], xmm4
00007d55df7e139a  vmovaps [rsp+0x40], xmm5
00007d55df7e13a0  vmovaps [rsp+0x50], xmm6
00007d55df7e13a6  vmovaps [rsp+0x60], xmm7
00007d55df7e13ac  vmovaps [rsp+0x70], xmm8
00007d55df7e13b2  vmovaps [rsp+0x80], xmm9
00007d55df7e13bb  vmovaps [rsp+0x90], xmm10
00007d55df7e13c4  vmovaps [rsp+0xA0], xmm11
00007d55df7e13cd  vmovaps [rsp+0xB0], xmm12
00007d55df7e13d6  vmovaps [rsp+0xC0], xmm13
00007d55df7e13df  vmovaps [rsp+0xD0], xmm14
00007d55df7e13e8  vmovaps [rsp+0xE0], xmm15
00007d55df7e13f1  sub rsp, 0x30
00007d55df7e13f5  movaps [rsp], xmm1
00007d55df7e13f9  movaps [rsp+0x10], xmm5
00007d55df7e13fe  movaps [rsp+0x20], xmm4
00007d55df7e1403  lea rdi, [rsp]
00007d55df7e1407  mov esi, 0x00
00007d55df7e140c  mov rax, 0x5BB8433D8530
00007d55df7e1416  call rax
00007d55df7e1418  movaps xmm1, [rsp]
00007d55df7e141c  add rsp, 0x30
00007d55df7e1420  vmovaps xmm0, [rsp]
00007d55df7e1425  vmovaps xmm2, [rsp+0x10]
00007d55df7e142b  vmovaps xmm3, [rsp+0x20]
00007d55df7e1431  vmovaps xmm4, [rsp+0x30]
00007d55df7e1437  vmovaps xmm5, [rsp+0x40]
00007d55df7e143d  vmovaps xmm6, [rsp+0x50]
00007d55df7e1443  vmovaps xmm7, [rsp+0x60]
00007d55df7e1449  vmovaps xmm8, [rsp+0x70]
00007d55df7e144f  vmovaps xmm9, [rsp+0x80]
00007d55df7e1458  vmovaps xmm10, [rsp+0x90]
00007d55df7e1461  vmovaps xmm11, [rsp+0xA0]
00007d55df7e146a  vmovaps xmm12, [rsp+0xB0]
00007d55df7e1473  vmovaps xmm13, [rsp+0xC0]
00007d55df7e147c  vmovaps xmm14, [rsp+0xD0]
00007d55df7e1485  vmovaps xmm15, [rsp+0xE0]
00007d55df7e148e  add rsp, 0xF0
00007d55df7e1495  pop r11
00007d55df7e1497  pop r10
00007d55df7e1499  pop r9
00007d55df7e149b  pop r8
00007d55df7e149d  pop rsi
00007d55df7e149e  pop rdi
00007d55df7e149f  pop rdx
00007d55df7e14a0  pop rcx
00007d55df7e14a1  pop rax
00007d55df7e14a2  add rsp, 0x08
00007d55df7e14a6  jmp 0x00007D55DF7DF299
00007d55df7e14ab  sub rsp, 0x08
00007d55df7e14af  push rax
00007d55df7e14b0  push rcx
00007d55df7e14b1  push rdx
00007d55df7e14b2  push rdi
00007d55df7e14b3  push rsi
00007d55df7e14b4  push r8
00007d55df7e14b6  push r9
00007d55df7e14b8  push r10
00007d55df7e14ba  push r11
00007d55df7e14bc  sub rsp, 0xF0
00007d55df7e14c3  vmovaps [rsp], xmm0
00007d55df7e14c8  vmovaps [rsp+0x10], xmm1
00007d55df7e14ce  vmovaps [rsp+0x20], xmm2
00007d55df7e14d4  vmovaps [rsp+0x30], xmm3
00007d55df7e14da  vmovaps [rsp+0x40], xmm5
00007d55df7e14e0  vmovaps [rsp+0x50], xmm6
00007d55df7e14e6  vmovaps [rsp+0x60], xmm7
00007d55df7e14ec  vmovaps [rsp+0x70], xmm8
00007d55df7e14f2  vmovaps [rsp+0x80], xmm9
00007d55df7e14fb  vmovaps [rsp+0x90], xmm10
00007d55df7e1504  vmovaps [rsp+0xA0], xmm11
00007d55df7e150d  vmovaps [rsp+0xB0], xmm12
00007d55df7e1516  vmovaps [rsp+0xC0], xmm13
00007d55df7e151f  vmovaps [rsp+0xD0], xmm14
00007d55df7e1528  vmovaps [rsp+0xE0], xmm15
00007d55df7e1531  sub rsp, 0x30
00007d55df7e1535  movaps [rsp], xmm4
00007d55df7e1539  movaps [rsp+0x10], xmm3
00007d55df7e153e  movaps [rsp+0x20], xmm5
00007d55df7e1543  lea rdi, [rsp]
00007d55df7e1547  mov esi, 0x00
00007d55df7e154c  mov rax, 0x5BB8433D8530
00007d55df7e1556  call rax
00007d55df7e1558  movaps xmm4, [rsp]
00007d55df7e155c  add rsp, 0x30
00007d55df7e1560  vmovaps xmm0, [rsp]
00007d55df7e1565  vmovaps xmm1, [rsp+0x10]
00007d55df7e156b  vmovaps xmm2, [rsp+0x20]
00007d55df7e1571  vmovaps xmm3, [rsp+0x30]
00007d55df7e1577  vmovaps xmm5, [rsp+0x40]
00007d55df7e157d  vmovaps xmm6, [rsp+0x50]
00007d55df7e1583  vmovaps xmm7, [rsp+0x60]
00007d55df7e1589  vmovaps xmm8, [rsp+0x70]
00007d55df7e158f  vmovaps xmm9, [rsp+0x80]
00007d55df7e1598  vmovaps xmm10, [rsp+0x90]
00007d55df7e15a1  vmovaps xmm11, [rsp+0xA0]
00007d55df7e15aa  vmovaps xmm12, [rsp+0xB0]
00007d55df7e15b3  vmovaps xmm13, [rsp+0xC0]
00007d55df7e15bc  vmovaps xmm14, [rsp+0xD0]
00007d55df7e15c5  vmovaps xmm15, [rsp+0xE0]
00007d55df7e15ce  add rsp, 0xF0
00007d55df7e15d5  pop r11
00007d55df7e15d7  pop r10
00007d55df7e15d9  pop r9
00007d55df7e15db  pop r8
00007d55df7e15dd  pop rsi
00007d55df7e15de  pop rdi
00007d55df7e15df  pop rdx
00007d55df7e15e0  pop rcx
00007d55df7e15e1  pop rax
00007d55df7e15e2  add rsp, 0x08
00007d55df7e15e6  jmp 0x00007D55DF7DF2E7
00007d55df7e15eb  call 0x00007D55DF6B52F0
00007d55df7e15f0  jmp 0x00007D55DF7DF2F4
00007d55df7e15f5  sub rsp, 0x08
00007d55df7e15f9  push rax
00007d55df7e15fa  push rcx
00007d55df7e15fb  push rdx
00007d55df7e15fc  push rdi
00007d55df7e15fd  push rsi
00007d55df7e15fe  push r8
00007d55df7e1600  push r9
00007d55df7e1602  push r10
00007d55df7e1604  push r11
00007d55df7e1606  sub rsp, 0xF0
00007d55df7e160d  vmovaps [rsp], xmm0
00007d55df7e1612  vmovaps [rsp+0x10], xmm1
00007d55df7e1618  vmovaps [rsp+0x20], xmm2
00007d55df7e161e  vmovaps [rsp+0x30], xmm3
00007d55df7e1624  vmovaps [rsp+0x40], xmm4
00007d55df7e162a  vmovaps [rsp+0x50], xmm6
00007d55df7e1630  vmovaps [rsp+0x60], xmm7
00007d55df7e1636  vmovaps [rsp+0x70], xmm8
00007d55df7e163c  vmovaps [rsp+0x80], xmm9
00007d55df7e1645  vmovaps [rsp+0x90], xmm10
00007d55df7e164e  vmovaps [rsp+0xA0], xmm11
00007d55df7e1657  vmovaps [rsp+0xB0], xmm12
00007d55df7e1660  vmovaps [rsp+0xC0], xmm13
00007d55df7e1669  vmovaps [rsp+0xD0], xmm14
00007d55df7e1672  vmovaps [rsp+0xE0], xmm15
00007d55df7e167b  sub rsp, 0x30
00007d55df7e167f  movaps [rsp], xmm5
00007d55df7e1683  movaps [rsp+0x10], xmm6
00007d55df7e1688  movaps [rsp+0x20], xmm3
00007d55df7e168d  lea rdi, [rsp]
00007d55df7e1691  mov esi, 0x00
00007d55df7e1696  mov rax, 0x5BB8433D8530
00007d55df7e16a0  call rax
00007d55df7e16a2  movaps xmm5, [rsp]
00007d55df7e16a6  add rsp, 0x30
00007d55df7e16aa  vmovaps xmm0, [rsp]
00007d55df7e16af  vmovaps xmm1, [rsp+0x10]
00007d55df7e16b5  vmovaps xmm2, [rsp+0x20]
00007d55df7e16bb  vmovaps xmm3, [rsp+0x30]
00007d55df7e16c1  vmovaps xmm4, [rsp+0x40]
00007d55df7e16c7  vmovaps xmm6, [rsp+0x50]
00007d55df7e16cd  vmovaps xmm7, [rsp+0x60]
00007d55df7e16d3  vmovaps xmm8, [rsp+0x70]
00007d55df7e16d9  vmovaps xmm9, [rsp+0x80]
00007d55df7e16e2  vmovaps xmm10, [rsp+0x90]
00007d55df7e16eb  vmovaps xmm11, [rsp+0xA0]
00007d55df7e16f4  vmovaps xmm12, [rsp+0xB0]
00007d55df7e16fd  vmovaps xmm13, [rsp+0xC0]
00007d55df7e1706  vmovaps xmm14, [rsp+0xD0]
00007d55df7e170f  vmovaps xmm15, [rsp+0xE0]
00007d55df7e1718  add rsp, 0xF0
00007d55df7e171f  pop r11
00007d55df7e1721  pop r10
00007d55df7e1723  pop r9
00007d55df7e1725  pop r8
00007d55df7e1727  pop rsi
00007d55df7e1728  pop rdi
00007d55df7e1729  pop rdx
00007d55df7e172a  pop rcx
00007d55df7e172b  pop rax
00007d55df7e172c  add rsp, 0x08
00007d55df7e1730  jmp 0x00007D55DF7DF31A
00007d55df7e1735  sub rsp, 0x08
00007d55df7e1739  push rax
00007d55df7e173a  push rcx
00007d55df7e173b  push rdx
00007d55df7e173c  push rdi
00007d55df7e173d  push rsi
00007d55df7e173e  push r8
00007d55df7e1740  push r9
00007d55df7e1742  push r10
00007d55df7e1744  push r11
00007d55df7e1746  sub rsp, 0xF0
00007d55df7e174d  vmovaps [rsp], xmm0
00007d55df7e1752  vmovaps [rsp+0x10], xmm1
00007d55df7e1758  vmovaps [rsp+0x20], xmm2
00007d55df7e175e  vmovaps [rsp+0x30], xmm3
00007d55df7e1764  vmovaps [rsp+0x40], xmm4
00007d55df7e176a  vmovaps [rsp+0x50], xmm5
00007d55df7e1770  vmovaps [rsp+0x60], xmm7
00007d55df7e1776  vmovaps [rsp+0x70], xmm8
00007d55df7e177c  vmovaps [rsp+0x80], xmm9
00007d55df7e1785  vmovaps [rsp+0x90], xmm10
00007d55df7e178e  vmovaps [rsp+0xA0], xmm11
00007d55df7e1797  vmovaps [rsp+0xB0], xmm12
00007d55df7e17a0  vmovaps [rsp+0xC0], xmm13
00007d55df7e17a9  vmovaps [rsp+0xD0], xmm14
00007d55df7e17b2  vmovaps [rsp+0xE0], xmm15
00007d55df7e17bb  sub rsp, 0x30
00007d55df7e17bf  movaps [rsp], xmm6
00007d55df7e17c3  movaps [rsp+0x10], xmm9
00007d55df7e17c9  movaps [rsp+0x20], xmm1
00007d55df7e17ce  lea rdi, [rsp]
00007d55df7e17d2  mov esi, 0x00
00007d55df7e17d7  mov rax, 0x5BB8433D8530
00007d55df7e17e1  call rax
00007d55df7e17e3  movaps xmm6, [rsp]
00007d55df7e17e7  add rsp, 0x30
00007d55df7e17eb  vmovaps xmm0, [rsp]
00007d55df7e17f0  vmovaps xmm1, [rsp+0x10]
00007d55df7e17f6  vmovaps xmm2, [rsp+0x20]
00007d55df7e17fc  vmovaps xmm3, [rsp+0x30]
00007d55df7e1802  vmovaps xmm4, [rsp+0x40]
00007d55df7e1808  vmovaps xmm5, [rsp+0x50]
00007d55df7e180e  vmovaps xmm7, [rsp+0x60]
00007d55df7e1814  vmovaps xmm8, [rsp+0x70]
00007d55df7e181a  vmovaps xmm9, [rsp+0x80]
00007d55df7e1823  vmovaps xmm10, [rsp+0x90]
00007d55df7e182c  vmovaps xmm11, [rsp+0xA0]
00007d55df7e1835  vmovaps xmm12, [rsp+0xB0]
00007d55df7e183e  vmovaps xmm13, [rsp+0xC0]
00007d55df7e1847  vmovaps xmm14, [rsp+0xD0]
00007d55df7e1850  vmovaps xmm15, [rsp+0xE0]
00007d55df7e1859  add rsp, 0xF0
00007d55df7e1860  pop r11
00007d55df7e1862  pop r10
00007d55df7e1864  pop r9
00007d55df7e1866  pop r8
00007d55df7e1868  pop rsi
00007d55df7e1869  pop rdi
00007d55df7e186a  pop rdx
00007d55df7e186b  pop rcx
00007d55df7e186c  pop rax
00007d55df7e186d  add rsp, 0x08
00007d55df7e1871  jmp 0x00007D55DF7DF33E
00007d55df7e1876  sub rsp, 0x08
00007d55df7e187a  push rax
00007d55df7e187b  push rcx
00007d55df7e187c  push rdx
00007d55df7e187d  push rdi
00007d55df7e187e  push rsi
00007d55df7e187f  push r8
00007d55df7e1881  push r9
00007d55df7e1883  push r10
00007d55df7e1885  push r11
00007d55df7e1887  sub rsp, 0xF0
00007d55df7e188e  vmovaps [rsp], xmm0
00007d55df7e1893  vmovaps [rsp+0x10], xmm1
00007d55df7e1899  vmovaps [rsp+0x20], xmm2
00007d55df7e189f  vmovaps [rsp+0x30], xmm3
00007d55df7e18a5  vmovaps [rsp+0x40], xmm4
00007d55df7e18ab  vmovaps [rsp+0x50], xmm5
00007d55df7e18b1  vmovaps [rsp+0x60], xmm6
00007d55df7e18b7  vmovaps [rsp+0x70], xmm7
00007d55df7e18bd  vmovaps [rsp+0x80], xmm8
00007d55df7e18c6  vmovaps [rsp+0x90], xmm10
00007d55df7e18cf  vmovaps [rsp+0xA0], xmm11
00007d55df7e18d8  vmovaps [rsp+0xB0], xmm12
00007d55df7e18e1  vmovaps [rsp+0xC0], xmm13
00007d55df7e18ea  vmovaps [rsp+0xD0], xmm14
00007d55df7e18f3  vmovaps [rsp+0xE0], xmm15
00007d55df7e18fc  sub rsp, 0x30
00007d55df7e1900  movaps [rsp], xmm9
00007d55df7e1905  movaps [rsp+0x10], xmm3
00007d55df7e190a  movaps [rsp+0x20], xmm1
00007d55df7e190f  lea rdi, [rsp]
00007d55df7e1913  mov esi, 0x00
00007d55df7e1918  mov rax, 0x5BB8433D8530
00007d55df7e1922  call rax
00007d55df7e1924  movaps xmm9, [rsp]
00007d55df7e1929  add rsp, 0x30
00007d55df7e192d  vmovaps xmm0, [rsp]
00007d55df7e1932  vmovaps xmm1, [rsp+0x10]
00007d55df7e1938  vmovaps xmm2, [rsp+0x20]
00007d55df7e193e  vmovaps xmm3, [rsp+0x30]
00007d55df7e1944  vmovaps xmm4, [rsp+0x40]
00007d55df7e194a  vmovaps xmm5, [rsp+0x50]
00007d55df7e1950  vmovaps xmm6, [rsp+0x60]
00007d55df7e1956  vmovaps xmm7, [rsp+0x70]
00007d55df7e195c  vmovaps xmm8, [rsp+0x80]
00007d55df7e1965  vmovaps xmm10, [rsp+0x90]
00007d55df7e196e  vmovaps xmm11, [rsp+0xA0]
00007d55df7e1977  vmovaps xmm12, [rsp+0xB0]
00007d55df7e1980  vmovaps xmm13, [rsp+0xC0]
00007d55df7e1989  vmovaps xmm14, [rsp+0xD0]
00007d55df7e1992  vmovaps xmm15, [rsp+0xE0]
00007d55df7e199b  add rsp, 0xF0
00007d55df7e19a2  pop r11
00007d55df7e19a4  pop r10
00007d55df7e19a6  pop r9
00007d55df7e19a8  pop r8
00007d55df7e19aa  pop rsi
00007d55df7e19ab  pop rdi
00007d55df7e19ac  pop rdx
00007d55df7e19ad  pop rcx
00007d55df7e19ae  pop rax
00007d55df7e19af  add rsp, 0x08
00007d55df7e19b3  jmp 0x00007D55DF7DF38A
00007d55df7e19b8  call 0x00007D55DF6B52F0
00007d55df7e19bd  jmp 0x00007D55DF7DF397
00007d55df7e19c2  sub rsp, 0x08
00007d55df7e19c6  push rax
00007d55df7e19c7  push rcx
00007d55df7e19c8  push rdx
00007d55df7e19c9  push rdi
00007d55df7e19ca  push rsi
00007d55df7e19cb  push r8
00007d55df7e19cd  push r9
00007d55df7e19cf  push r10
00007d55df7e19d1  push r11
00007d55df7e19d3  sub rsp, 0xF0
00007d55df7e19da  vmovaps [rsp], xmm0
00007d55df7e19df  vmovaps [rsp+0x10], xmm1
00007d55df7e19e5  vmovaps [rsp+0x20], xmm2
00007d55df7e19eb  vmovaps [rsp+0x30], xmm3
00007d55df7e19f1  vmovaps [rsp+0x40], xmm4
00007d55df7e19f7  vmovaps [rsp+0x50], xmm5
00007d55df7e19fd  vmovaps [rsp+0x60], xmm6
00007d55df7e1a03  vmovaps [rsp+0x70], xmm7
00007d55df7e1a09  vmovaps [rsp+0x80], xmm8
00007d55df7e1a12  vmovaps [rsp+0x90], xmm9
00007d55df7e1a1b  vmovaps [rsp+0xA0], xmm10
00007d55df7e1a24  vmovaps [rsp+0xB0], xmm11
00007d55df7e1a2d  vmovaps [rsp+0xC0], xmm12
00007d55df7e1a36  vmovaps [rsp+0xD0], xmm13
00007d55df7e1a3f  vmovaps [rsp+0xE0], xmm14
00007d55df7e1a48  sub rsp, 0x30
00007d55df7e1a4c  movaps [rsp], xmm15
00007d55df7e1a51  movaps [rsp+0x10], xmm3
00007d55df7e1a56  movaps [rsp+0x20], xmm7
00007d55df7e1a5b  lea rdi, [rsp]
00007d55df7e1a5f  mov esi, 0x00
00007d55df7e1a64  mov rax, 0x5BB8433D8530
00007d55df7e1a6e  call rax
00007d55df7e1a70  movaps xmm15, [rsp]
00007d55df7e1a75  add rsp, 0x30
00007d55df7e1a79  vmovaps xmm0, [rsp]
00007d55df7e1a7e  vmovaps xmm1, [rsp+0x10]
00007d55df7e1a84  vmovaps xmm2, [rsp+0x20]
00007d55df7e1a8a  vmovaps xmm3, [rsp+0x30]
00007d55df7e1a90  vmovaps xmm4, [rsp+0x40]
00007d55df7e1a96  vmovaps xmm5, [rsp+0x50]
00007d55df7e1a9c  vmovaps xmm6, [rsp+0x60]
00007d55df7e1aa2  vmovaps xmm7, [rsp+0x70]
00007d55df7e1aa8  vmovaps xmm8, [rsp+0x80]
00007d55df7e1ab1  vmovaps xmm9, [rsp+0x90]
00007d55df7e1aba  vmovaps xmm10, [rsp+0xA0]
00007d55df7e1ac3  vmovaps xmm11, [rsp+0xB0]
00007d55df7e1acc  vmovaps xmm12, [rsp+0xC0]
00007d55df7e1ad5  vmovaps xmm13, [rsp+0xD0]
00007d55df7e1ade  vmovaps xmm14, [rsp+0xE0]
00007d55df7e1ae7  add rsp, 0xF0
00007d55df7e1aee  pop r11
00007d55df7e1af0  pop r10
00007d55df7e1af2  pop r9
00007d55df7e1af4  pop r8
00007d55df7e1af6  pop rsi
00007d55df7e1af7  pop rdi
00007d55df7e1af8  pop rdx
00007d55df7e1af9  pop rcx
00007d55df7e1afa  pop rax
00007d55df7e1afb  add rsp, 0x08
00007d55df7e1aff  jmp 0x00007D55DF7DF3C3
00007d55df7e1b04  sub rsp, 0x08
00007d55df7e1b08  push rax
00007d55df7e1b09  push rcx
00007d55df7e1b0a  push rdx
00007d55df7e1b0b  push rdi
00007d55df7e1b0c  push rsi
00007d55df7e1b0d  push r8
00007d55df7e1b0f  push r9
00007d55df7e1b11  push r10
00007d55df7e1b13  push r11
00007d55df7e1b15  sub rsp, 0xF0
00007d55df7e1b1c  vmovaps [rsp], xmm0
00007d55df7e1b21  vmovaps [rsp+0x10], xmm1
00007d55df7e1b27  vmovaps [rsp+0x20], xmm2
00007d55df7e1b2d  vmovaps [rsp+0x30], xmm4
00007d55df7e1b33  vmovaps [rsp+0x40], xmm5
00007d55df7e1b39  vmovaps [rsp+0x50], xmm6
00007d55df7e1b3f  vmovaps [rsp+0x60], xmm7
00007d55df7e1b45  vmovaps [rsp+0x70], xmm8
00007d55df7e1b4b  vmovaps [rsp+0x80], xmm9
00007d55df7e1b54  vmovaps [rsp+0x90], xmm10
00007d55df7e1b5d  vmovaps [rsp+0xA0], xmm11
00007d55df7e1b66  vmovaps [rsp+0xB0], xmm12
00007d55df7e1b6f  vmovaps [rsp+0xC0], xmm13
00007d55df7e1b78  vmovaps [rsp+0xD0], xmm14
00007d55df7e1b81  vmovaps [rsp+0xE0], xmm15
00007d55df7e1b8a  sub rsp, 0x30
00007d55df7e1b8e  movaps [rsp], xmm3
00007d55df7e1b92  movaps [rsp+0x10], xmm1
00007d55df7e1b97  movaps [rsp+0x20], xmm15
00007d55df7e1b9d  lea rdi, [rsp]
00007d55df7e1ba1  mov esi, 0x00
00007d55df7e1ba6  mov rax, 0x5BB8433D8530
00007d55df7e1bb0  call rax
00007d55df7e1bb2  movaps xmm3, [rsp]
00007d55df7e1bb6  add rsp, 0x30
00007d55df7e1bba  vmovaps xmm0, [rsp]
00007d55df7e1bbf  vmovaps xmm1, [rsp+0x10]
00007d55df7e1bc5  vmovaps xmm2, [rsp+0x20]
00007d55df7e1bcb  vmovaps xmm4, [rsp+0x30]
00007d55df7e1bd1  vmovaps xmm5, [rsp+0x40]
00007d55df7e1bd7  vmovaps xmm6, [rsp+0x50]
00007d55df7e1bdd  vmovaps xmm7, [rsp+0x60]
00007d55df7e1be3  vmovaps xmm8, [rsp+0x70]
00007d55df7e1be9  vmovaps xmm9, [rsp+0x80]
00007d55df7e1bf2  vmovaps xmm10, [rsp+0x90]
00007d55df7e1bfb  vmovaps xmm11, [rsp+0xA0]
00007d55df7e1c04  vmovaps xmm12, [rsp+0xB0]
00007d55df7e1c0d  vmovaps xmm13, [rsp+0xC0]
00007d55df7e1c16  vmovaps xmm14, [rsp+0xD0]
00007d55df7e1c1f  vmovaps xmm15, [rsp+0xE0]
00007d55df7e1c28  add rsp, 0xF0
00007d55df7e1c2f  pop r11
00007d55df7e1c31  pop r10
00007d55df7e1c33  pop r9
00007d55df7e1c35  pop r8
00007d55df7e1c37  pop rsi
00007d55df7e1c38  pop rdi
00007d55df7e1c39  pop rdx
00007d55df7e1c3a  pop rcx
00007d55df7e1c3b  pop rax
00007d55df7e1c3c  add rsp, 0x08
00007d55df7e1c40  jmp 0x00007D55DF7DF452
00007d55df7e1c45  call 0x00007D55DF6B52F0
00007d55df7e1c4a  jmp 0x00007D55DF7DF45C
00007d55df7e1c4f  sub rsp, 0x08
00007d55df7e1c53  push rax
00007d55df7e1c54  push rcx
00007d55df7e1c55  push rdx
00007d55df7e1c56  push rdi
00007d55df7e1c57  push rsi
00007d55df7e1c58  push r8
00007d55df7e1c5a  push r9
00007d55df7e1c5c  push r10
00007d55df7e1c5e  push r11
00007d55df7e1c60  sub rsp, 0xF0
00007d55df7e1c67  vmovaps [rsp], xmm0
00007d55df7e1c6c  vmovaps [rsp+0x10], xmm1
00007d55df7e1c72  vmovaps [rsp+0x20], xmm2
00007d55df7e1c78  vmovaps [rsp+0x30], xmm3
00007d55df7e1c7e  vmovaps [rsp+0x40], xmm4
00007d55df7e1c84  vmovaps [rsp+0x50], xmm5
00007d55df7e1c8a  vmovaps [rsp+0x60], xmm6
00007d55df7e1c90  vmovaps [rsp+0x70], xmm7
00007d55df7e1c96  vmovaps [rsp+0x80], xmm8
00007d55df7e1c9f  vmovaps [rsp+0x90], xmm9
00007d55df7e1ca8  vmovaps [rsp+0xA0], xmm10
00007d55df7e1cb1  vmovaps [rsp+0xB0], xmm11
00007d55df7e1cba  vmovaps [rsp+0xC0], xmm12
00007d55df7e1cc3  vmovaps [rsp+0xD0], xmm13
00007d55df7e1ccc  vmovaps [rsp+0xE0], xmm14
00007d55df7e1cd5  sub rsp, 0x30
00007d55df7e1cd9  movaps [rsp], xmm15
00007d55df7e1cde  movaps [rsp+0x10], xmm14
00007d55df7e1ce4  movaps [rsp+0x20], xmm4
00007d55df7e1ce9  lea rdi, [rsp]
00007d55df7e1ced  mov esi, 0x00
00007d55df7e1cf2  mov rax, 0x5BB8433D8530
00007d55df7e1cfc  call rax
00007d55df7e1cfe  movaps xmm15, [rsp]
00007d55df7e1d03  add rsp, 0x30
00007d55df7e1d07  vmovaps xmm0, [rsp]
00007d55df7e1d0c  vmovaps xmm1, [rsp+0x10]
00007d55df7e1d12  vmovaps xmm2, [rsp+0x20]
00007d55df7e1d18  vmovaps xmm3, [rsp+0x30]
00007d55df7e1d1e  vmovaps xmm4, [rsp+0x40]
00007d55df7e1d24  vmovaps xmm5, [rsp+0x50]
00007d55df7e1d2a  vmovaps xmm6, [rsp+0x60]
00007d55df7e1d30  vmovaps xmm7, [rsp+0x70]
00007d55df7e1d36  vmovaps xmm8, [rsp+0x80]
00007d55df7e1d3f  vmovaps xmm9, [rsp+0x90]
00007d55df7e1d48  vmovaps xmm10, [rsp+0xA0]
00007d55df7e1d51  vmovaps xmm11, [rsp+0xB0]
00007d55df7e1d5a  vmovaps xmm12, [rsp+0xC0]
00007d55df7e1d63  vmovaps xmm13, [rsp+0xD0]
00007d55df7e1d6c  vmovaps xmm14, [rsp+0xE0]
00007d55df7e1d75  add rsp, 0xF0
00007d55df7e1d7c  pop r11
00007d55df7e1d7e  pop r10
00007d55df7e1d80  pop r9
00007d55df7e1d82  pop r8
00007d55df7e1d84  pop rsi
00007d55df7e1d85  pop rdi
00007d55df7e1d86  pop rdx
00007d55df7e1d87  pop rcx
00007d55df7e1d88  pop rax
00007d55df7e1d89  add rsp, 0x08
00007d55df7e1d8d  jmp 0x00007D55DF7DF48A
00007d55df7e1d92  sub rsp, 0x08
00007d55df7e1d96  push rax
00007d55df7e1d97  push rcx
00007d55df7e1d98  push rdx
00007d55df7e1d99  push rdi
00007d55df7e1d9a  push rsi
00007d55df7e1d9b  push r8
00007d55df7e1d9d  push r9
00007d55df7e1d9f  push r10
00007d55df7e1da1  push r11
00007d55df7e1da3  sub rsp, 0xF0
00007d55df7e1daa  vmovaps [rsp], xmm0
00007d55df7e1daf  vmovaps [rsp+0x10], xmm1
00007d55df7e1db5  vmovaps [rsp+0x20], xmm2
00007d55df7e1dbb  vmovaps [rsp+0x30], xmm3
00007d55df7e1dc1  vmovaps [rsp+0x40], xmm4
00007d55df7e1dc7  vmovaps [rsp+0x50], xmm5
00007d55df7e1dcd  vmovaps [rsp+0x60], xmm6
00007d55df7e1dd3  vmovaps [rsp+0x70], xmm7
00007d55df7e1dd9  vmovaps [rsp+0x80], xmm8
00007d55df7e1de2  vmovaps [rsp+0x90], xmm9
00007d55df7e1deb  vmovaps [rsp+0xA0], xmm10
00007d55df7e1df4  vmovaps [rsp+0xB0], xmm11
00007d55df7e1dfd  vmovaps [rsp+0xC0], xmm12
00007d55df7e1e06  vmovaps [rsp+0xD0], xmm13
00007d55df7e1e0f  vmovaps [rsp+0xE0], xmm15
00007d55df7e1e18  sub rsp, 0x30
00007d55df7e1e1c  movaps [rsp], xmm14
00007d55df7e1e21  movaps [rsp+0x10], xmm2
00007d55df7e1e26  movaps [rsp+0x20], xmm1
00007d55df7e1e2b  lea rdi, [rsp]
00007d55df7e1e2f  mov esi, 0x00
00007d55df7e1e34  mov rax, 0x5BB8433D8530
00007d55df7e1e3e  call rax
00007d55df7e1e40  movaps xmm14, [rsp]
00007d55df7e1e45  add rsp, 0x30
00007d55df7e1e49  vmovaps xmm0, [rsp]
00007d55df7e1e4e  vmovaps xmm1, [rsp+0x10]
00007d55df7e1e54  vmovaps xmm2, [rsp+0x20]
00007d55df7e1e5a  vmovaps xmm3, [rsp+0x30]
00007d55df7e1e60  vmovaps xmm4, [rsp+0x40]
00007d55df7e1e66  vmovaps xmm5, [rsp+0x50]
00007d55df7e1e6c  vmovaps xmm6, [rsp+0x60]
00007d55df7e1e72  vmovaps xmm7, [rsp+0x70]
00007d55df7e1e78  vmovaps xmm8, [rsp+0x80]
00007d55df7e1e81  vmovaps xmm9, [rsp+0x90]
00007d55df7e1e8a  vmovaps xmm10, [rsp+0xA0]
00007d55df7e1e93  vmovaps xmm11, [rsp+0xB0]
00007d55df7e1e9c  vmovaps xmm12, [rsp+0xC0]
00007d55df7e1ea5  vmovaps xmm13, [rsp+0xD0]
00007d55df7e1eae  vmovaps xmm15, [rsp+0xE0]
00007d55df7e1eb7  add rsp, 0xF0
00007d55df7e1ebe  pop r11
00007d55df7e1ec0  pop r10
00007d55df7e1ec2  pop r9
00007d55df7e1ec4  pop r8
00007d55df7e1ec6  pop rsi
00007d55df7e1ec7  pop rdi
00007d55df7e1ec8  pop rdx
00007d55df7e1ec9  pop rcx
00007d55df7e1eca  pop rax
00007d55df7e1ecb  add rsp, 0x08
00007d55df7e1ecf  jmp 0x00007D55DF7DF4B0
00007d55df7e1ed4  sub rsp, 0x08
00007d55df7e1ed8  push rax
00007d55df7e1ed9  push rcx
00007d55df7e1eda  push rdx
00007d55df7e1edb  push rdi
00007d55df7e1edc  push rsi
00007d55df7e1edd  push r8
00007d55df7e1edf  push r9
00007d55df7e1ee1  push r10
00007d55df7e1ee3  push r11
00007d55df7e1ee5  sub rsp, 0xF0
00007d55df7e1eec  vmovaps [rsp], xmm0
00007d55df7e1ef1  vmovaps [rsp+0x10], xmm2
00007d55df7e1ef7  vmovaps [rsp+0x20], xmm3
00007d55df7e1efd  vmovaps [rsp+0x30], xmm4
00007d55df7e1f03  vmovaps [rsp+0x40], xmm5
00007d55df7e1f09  vmovaps [rsp+0x50], xmm6
00007d55df7e1f0f  vmovaps [rsp+0x60], xmm7
00007d55df7e1f15  vmovaps [rsp+0x70], xmm8
00007d55df7e1f1b  vmovaps [rsp+0x80], xmm9
00007d55df7e1f24  vmovaps [rsp+0x90], xmm10
00007d55df7e1f2d  vmovaps [rsp+0xA0], xmm11
00007d55df7e1f36  vmovaps [rsp+0xB0], xmm12
00007d55df7e1f3f  vmovaps [rsp+0xC0], xmm13
00007d55df7e1f48  vmovaps [rsp+0xD0], xmm14
00007d55df7e1f51  vmovaps [rsp+0xE0], xmm15
00007d55df7e1f5a  sub rsp, 0x30
00007d55df7e1f5e  movaps [rsp], xmm1
00007d55df7e1f62  movaps [rsp+0x10], xmm4
00007d55df7e1f67  movaps [rsp+0x20], xmm9
00007d55df7e1f6d  lea rdi, [rsp]
00007d55df7e1f71  mov esi, 0x00
00007d55df7e1f76  mov rax, 0x5BB8433D8530
00007d55df7e1f80  call rax
00007d55df7e1f82  movaps xmm1, [rsp]
00007d55df7e1f86  add rsp, 0x30
00007d55df7e1f8a  vmovaps xmm0, [rsp]
00007d55df7e1f8f  vmovaps xmm2, [rsp+0x10]
00007d55df7e1f95  vmovaps xmm3, [rsp+0x20]
00007d55df7e1f9b  vmovaps xmm4, [rsp+0x30]
00007d55df7e1fa1  vmovaps xmm5, [rsp+0x40]
00007d55df7e1fa7  vmovaps xmm6, [rsp+0x50]
00007d55df7e1fad  vmovaps xmm7, [rsp+0x60]
00007d55df7e1fb3  vmovaps xmm8, [rsp+0x70]
00007d55df7e1fb9  vmovaps xmm9, [rsp+0x80]
00007d55df7e1fc2  vmovaps xmm10, [rsp+0x90]
00007d55df7e1fcb  vmovaps xmm11, [rsp+0xA0]
00007d55df7e1fd4  vmovaps xmm12, [rsp+0xB0]
00007d55df7e1fdd  vmovaps xmm13, [rsp+0xC0]
00007d55df7e1fe6  vmovaps xmm14, [rsp+0xD0]
00007d55df7e1fef  vmovaps xmm15, [rsp+0xE0]
00007d55df7e1ff8  add rsp, 0xF0
00007d55df7e1fff  pop r11
00007d55df7e2001  pop r10
00007d55df7e2003  pop r9
00007d55df7e2005  pop r8
00007d55df7e2007  pop rsi
00007d55df7e2008  pop rdi
00007d55df7e2009  pop rdx
00007d55df7e200a  pop rcx
00007d55df7e200b  pop rax
00007d55df7e200c  add rsp, 0x08
00007d55df7e2010  jmp 0x00007D55DF7DF4CE
00007d55df7e2015  sub rsp, 0x08
00007d55df7e2019  push rax
00007d55df7e201a  push rcx
00007d55df7e201b  push rdx
00007d55df7e201c  push rdi
00007d55df7e201d  push rsi
00007d55df7e201e  push r8
00007d55df7e2020  push r9
00007d55df7e2022  push r10
00007d55df7e2024  push r11
00007d55df7e2026  sub rsp, 0xF0
00007d55df7e202d  vmovaps [rsp], xmm0
00007d55df7e2032  vmovaps [rsp+0x10], xmm1
00007d55df7e2038  vmovaps [rsp+0x20], xmm2
00007d55df7e203e  vmovaps [rsp+0x30], xmm3
00007d55df7e2044  vmovaps [rsp+0x40], xmm5
00007d55df7e204a  vmovaps [rsp+0x50], xmm6
00007d55df7e2050  vmovaps [rsp+0x60], xmm7
00007d55df7e2056  vmovaps [rsp+0x70], xmm8
00007d55df7e205c  vmovaps [rsp+0x80], xmm9
00007d55df7e2065  vmovaps [rsp+0x90], xmm10
00007d55df7e206e  vmovaps [rsp+0xA0], xmm11
00007d55df7e2077  vmovaps [rsp+0xB0], xmm12
00007d55df7e2080  vmovaps [rsp+0xC0], xmm13
00007d55df7e2089  vmovaps [rsp+0xD0], xmm14
00007d55df7e2092  vmovaps [rsp+0xE0], xmm15
00007d55df7e209b  sub rsp, 0x30
00007d55df7e209f  movaps [rsp], xmm4
00007d55df7e20a3  movaps [rsp+0x10], xmm2
00007d55df7e20a8  movaps [rsp+0x20], xmm9
00007d55df7e20ae  lea rdi, [rsp]
00007d55df7e20b2  mov esi, 0x00
00007d55df7e20b7  mov rax, 0x5BB8433D8530
00007d55df7e20c1  call rax
00007d55df7e20c3  movaps xmm4, [rsp]
00007d55df7e20c7  add rsp, 0x30
00007d55df7e20cb  vmovaps xmm0, [rsp]
00007d55df7e20d0  vmovaps xmm1, [rsp+0x10]
00007d55df7e20d6  vmovaps xmm2, [rsp+0x20]
00007d55df7e20dc  vmovaps xmm3, [rsp+0x30]
00007d55df7e20e2  vmovaps xmm5, [rsp+0x40]
00007d55df7e20e8  vmovaps xmm6, [rsp+0x50]
00007d55df7e20ee  vmovaps xmm7, [rsp+0x60]
00007d55df7e20f4  vmovaps xmm8, [rsp+0x70]
00007d55df7e20fa  vmovaps xmm9, [rsp+0x80]
00007d55df7e2103  vmovaps xmm10, [rsp+0x90]
00007d55df7e210c  vmovaps xmm11, [rsp+0xA0]
00007d55df7e2115  vmovaps xmm12, [rsp+0xB0]
00007d55df7e211e  vmovaps xmm13, [rsp+0xC0]
00007d55df7e2127  vmovaps xmm14, [rsp+0xD0]
00007d55df7e2130  vmovaps xmm15, [rsp+0xE0]
00007d55df7e2139  add rsp, 0xF0
00007d55df7e2140  pop r11
00007d55df7e2142  pop r10
00007d55df7e2144  pop r9
00007d55df7e2146  pop r8
00007d55df7e2148  pop rsi
00007d55df7e2149  pop rdi
00007d55df7e214a  pop rdx
00007d55df7e214b  pop rcx
00007d55df7e214c  pop rax
00007d55df7e214d  add rsp, 0x08
00007d55df7e2151  jmp 0x00007D55DF7DF4FE
00007d55df7e2156  sub rsp, 0x08
00007d55df7e215a  push rax
00007d55df7e215b  push rcx
00007d55df7e215c  push rdx
00007d55df7e215d  push rdi
00007d55df7e215e  push rsi
00007d55df7e215f  push r8
00007d55df7e2161  push r9
00007d55df7e2163  push r10
00007d55df7e2165  push r11
00007d55df7e2167  sub rsp, 0xF0
00007d55df7e216e  vmovaps [rsp], xmm0
00007d55df7e2173  vmovaps [rsp+0x10], xmm1
00007d55df7e2179  vmovaps [rsp+0x20], xmm2
00007d55df7e217f  vmovaps [rsp+0x30], xmm3
00007d55df7e2185  vmovaps [rsp+0x40], xmm4
00007d55df7e218b  vmovaps [rsp+0x50], xmm5
00007d55df7e2191  vmovaps [rsp+0x60], xmm6
00007d55df7e2197  vmovaps [rsp+0x70], xmm7
00007d55df7e219d  vmovaps [rsp+0x80], xmm8
00007d55df7e21a6  vmovaps [rsp+0x90], xmm10
00007d55df7e21af  vmovaps [rsp+0xA0], xmm11
00007d55df7e21b8  vmovaps [rsp+0xB0], xmm12
00007d55df7e21c1  vmovaps [rsp+0xC0], xmm13
00007d55df7e21ca  vmovaps [rsp+0xD0], xmm14
00007d55df7e21d3  vmovaps [rsp+0xE0], xmm15
00007d55df7e21dc  sub rsp, 0x30
00007d55df7e21e0  movaps [rsp], xmm9
00007d55df7e21e5  movaps [rsp+0x10], xmm2
00007d55df7e21ea  movaps [rsp+0x20], xmm1
00007d55df7e21ef  lea rdi, [rsp]
00007d55df7e21f3  mov esi, 0x00
00007d55df7e21f8  mov rax, 0x5BB8433D8530
00007d55df7e2202  call rax
00007d55df7e2204  movaps xmm9, [rsp]
00007d55df7e2209  add rsp, 0x30
00007d55df7e220d  vmovaps xmm0, [rsp]
00007d55df7e2212  vmovaps xmm1, [rsp+0x10]
00007d55df7e2218  vmovaps xmm2, [rsp+0x20]
00007d55df7e221e  vmovaps xmm3, [rsp+0x30]
00007d55df7e2224  vmovaps xmm4, [rsp+0x40]
00007d55df7e222a  vmovaps xmm5, [rsp+0x50]
00007d55df7e2230  vmovaps xmm6, [rsp+0x60]
00007d55df7e2236  vmovaps xmm7, [rsp+0x70]
00007d55df7e223c  vmovaps xmm8, [rsp+0x80]
00007d55df7e2245  vmovaps xmm10, [rsp+0x90]
00007d55df7e224e  vmovaps xmm11, [rsp+0xA0]
00007d55df7e2257  vmovaps xmm12, [rsp+0xB0]
00007d55df7e2260  vmovaps xmm13, [rsp+0xC0]
00007d55df7e2269  vmovaps xmm14, [rsp+0xD0]
00007d55df7e2272  vmovaps xmm15, [rsp+0xE0]
00007d55df7e227b  add rsp, 0xF0
00007d55df7e2282  pop r11
00007d55df7e2284  pop r10
00007d55df7e2286  pop r9
00007d55df7e2288  pop r8
00007d55df7e228a  pop rsi
00007d55df7e228b  pop rdi
00007d55df7e228c  pop rdx
00007d55df7e228d  pop rcx
00007d55df7e228e  pop rax
00007d55df7e228f  add rsp, 0x08
00007d55df7e2293  jmp 0x00007D55DF7DF534
00007d55df7e2298  sub rsp, 0x08
00007d55df7e229c  push rax
00007d55df7e229d  push rcx
00007d55df7e229e  push rdx
00007d55df7e229f  push rdi
00007d55df7e22a0  push rsi
00007d55df7e22a1  push r8
00007d55df7e22a3  push r9
00007d55df7e22a5  push r10
00007d55df7e22a7  push r11
00007d55df7e22a9  sub rsp, 0xF0
00007d55df7e22b0  vmovaps [rsp], xmm0
00007d55df7e22b5  vmovaps [rsp+0x10], xmm2
00007d55df7e22bb  vmovaps [rsp+0x20], xmm3
00007d55df7e22c1  vmovaps [rsp+0x30], xmm4
00007d55df7e22c7  vmovaps [rsp+0x40], xmm5
00007d55df7e22cd  vmovaps [rsp+0x50], xmm6
00007d55df7e22d3  vmovaps [rsp+0x60], xmm7
00007d55df7e22d9  vmovaps [rsp+0x70], xmm8
00007d55df7e22df  vmovaps [rsp+0x80], xmm9
00007d55df7e22e8  vmovaps [rsp+0x90], xmm10
00007d55df7e22f1  vmovaps [rsp+0xA0], xmm11
00007d55df7e22fa  vmovaps [rsp+0xB0], xmm12
00007d55df7e2303  vmovaps [rsp+0xC0], xmm13
00007d55df7e230c  vmovaps [rsp+0xD0], xmm14
00007d55df7e2315  vmovaps [rsp+0xE0], xmm15
00007d55df7e231e  sub rsp, 0x30
00007d55df7e2322  movaps [rsp], xmm1
00007d55df7e2326  movaps [rsp+0x10], xmm15
00007d55df7e232c  movaps [rsp+0x20], xmm6
00007d55df7e2331  lea rdi, [rsp]
00007d55df7e2335  mov esi, 0x00
00007d55df7e233a  mov rax, 0x5BB8433D8530
00007d55df7e2344  call rax
00007d55df7e2346  movaps xmm1, [rsp]
00007d55df7e234a  add rsp, 0x30
00007d55df7e234e  vmovaps xmm0, [rsp]
00007d55df7e2353  vmovaps xmm2, [rsp+0x10]
00007d55df7e2359  vmovaps xmm3, [rsp+0x20]
00007d55df7e235f  vmovaps xmm4, [rsp+0x30]
00007d55df7e2365  vmovaps xmm5, [rsp+0x40]
00007d55df7e236b  vmovaps xmm6, [rsp+0x50]
00007d55df7e2371  vmovaps xmm7, [rsp+0x60]
00007d55df7e2377  vmovaps xmm8, [rsp+0x70]
00007d55df7e237d  vmovaps xmm9, [rsp+0x80]
00007d55df7e2386  vmovaps xmm10, [rsp+0x90]
00007d55df7e238f  vmovaps xmm11, [rsp+0xA0]
00007d55df7e2398  vmovaps xmm12, [rsp+0xB0]
00007d55df7e23a1  vmovaps xmm13, [rsp+0xC0]
00007d55df7e23aa  vmovaps xmm14, [rsp+0xD0]
00007d55df7e23b3  vmovaps xmm15, [rsp+0xE0]
00007d55df7e23bc  add rsp, 0xF0
00007d55df7e23c3  pop r11
00007d55df7e23c5  pop r10
00007d55df7e23c7  pop r9
00007d55df7e23c9  pop r8
00007d55df7e23cb  pop rsi
00007d55df7e23cc  pop rdi
00007d55df7e23cd  pop rdx
00007d55df7e23ce  pop rcx
00007d55df7e23cf  pop rax
00007d55df7e23d0  add rsp, 0x08
00007d55df7e23d4  jmp 0x00007D55DF7DF555
00007d55df7e23d9  sub rsp, 0x08
00007d55df7e23dd  push rax
00007d55df7e23de  push rcx
00007d55df7e23df  push rdx
00007d55df7e23e0  push rdi
00007d55df7e23e1  push rsi
00007d55df7e23e2  push r8
00007d55df7e23e4  push r9
00007d55df7e23e6  push r10
00007d55df7e23e8  push r11
00007d55df7e23ea  sub rsp, 0xF0
00007d55df7e23f1  vmovaps [rsp], xmm0
00007d55df7e23f6  vmovaps [rsp+0x10], xmm1
00007d55df7e23fc  vmovaps [rsp+0x20], xmm2
00007d55df7e2402  vmovaps [rsp+0x30], xmm3
00007d55df7e2408  vmovaps [rsp+0x40], xmm4
00007d55df7e240e  vmovaps [rsp+0x50], xmm5
00007d55df7e2414  vmovaps [rsp+0x60], xmm6
00007d55df7e241a  vmovaps [rsp+0x70], xmm7
00007d55df7e2420  vmovaps [rsp+0x80], xmm8
00007d55df7e2429  vmovaps [rsp+0x90], xmm9
00007d55df7e2432  vmovaps [rsp+0xA0], xmm10
00007d55df7e243b  vmovaps [rsp+0xB0], xmm11
00007d55df7e2444  vmovaps [rsp+0xC0], xmm12
00007d55df7e244d  vmovaps [rsp+0xD0], xmm13
00007d55df7e2456  vmovaps [rsp+0xE0], xmm14
00007d55df7e245f  sub rsp, 0x30
00007d55df7e2463  movaps [rsp], xmm15
00007d55df7e2468  movaps [rsp+0x10], xmm5
00007d55df7e246d  movaps [rsp+0x20], xmm3
00007d55df7e2472  lea rdi, [rsp]
00007d55df7e2476  mov esi, 0x00
00007d55df7e247b  mov rax, 0x5BB8433D8530
00007d55df7e2485  call rax
00007d55df7e2487  movaps xmm15, [rsp]
00007d55df7e248c  add rsp, 0x30
00007d55df7e2490  vmovaps xmm0, [rsp]
00007d55df7e2495  vmovaps xmm1, [rsp+0x10]
00007d55df7e249b  vmovaps xmm2, [rsp+0x20]
00007d55df7e24a1  vmovaps xmm3, [rsp+0x30]
00007d55df7e24a7  vmovaps xmm4, [rsp+0x40]
00007d55df7e24ad  vmovaps xmm5, [rsp+0x50]
00007d55df7e24b3  vmovaps xmm6, [rsp+0x60]
00007d55df7e24b9  vmovaps xmm7, [rsp+0x70]
00007d55df7e24bf  vmovaps xmm8, [rsp+0x80]
00007d55df7e24c8  vmovaps xmm9, [rsp+0x90]
00007d55df7e24d1  vmovaps xmm10, [rsp+0xA0]
00007d55df7e24da  vmovaps xmm11, [rsp+0xB0]
00007d55df7e24e3  vmovaps xmm12, [rsp+0xC0]
00007d55df7e24ec  vmovaps xmm13, [rsp+0xD0]
00007d55df7e24f5  vmovaps xmm14, [rsp+0xE0]
00007d55df7e24fe  add rsp, 0xF0
00007d55df7e2505  pop r11
00007d55df7e2507  pop r10
00007d55df7e2509  pop r9
00007d55df7e250b  pop r8
00007d55df7e250d  pop rsi
00007d55df7e250e  pop rdi
00007d55df7e250f  pop rdx
00007d55df7e2510  pop rcx
00007d55df7e2511  pop rax
00007d55df7e2512  add rsp, 0x08
00007d55df7e2516  jmp 0x00007D55DF7DF56F
00007d55df7e251b  sub rsp, 0x08
00007d55df7e251f  push rax
00007d55df7e2520  push rcx
00007d55df7e2521  push rdx
00007d55df7e2522  push rdi
00007d55df7e2523  push rsi
00007d55df7e2524  push r8
00007d55df7e2526  push r9
00007d55df7e2528  push r10
00007d55df7e252a  push r11
00007d55df7e252c  sub rsp, 0xF0
00007d55df7e2533  vmovaps [rsp], xmm0
00007d55df7e2538  vmovaps [rsp+0x10], xmm1
00007d55df7e253e  vmovaps [rsp+0x20], xmm2
00007d55df7e2544  vmovaps [rsp+0x30], xmm3
00007d55df7e254a  vmovaps [rsp+0x40], xmm4
00007d55df7e2550  vmovaps [rsp+0x50], xmm6
00007d55df7e2556  vmovaps [rsp+0x60], xmm7
00007d55df7e255c  vmovaps [rsp+0x70], xmm8
00007d55df7e2562  vmovaps [rsp+0x80], xmm9
00007d55df7e256b  vmovaps [rsp+0x90], xmm10
00007d55df7e2574  vmovaps [rsp+0xA0], xmm11
00007d55df7e257d  vmovaps [rsp+0xB0], xmm12
00007d55df7e2586  vmovaps [rsp+0xC0], xmm13
00007d55df7e258f  vmovaps [rsp+0xD0], xmm14
00007d55df7e2598  vmovaps [rsp+0xE0], xmm15
00007d55df7e25a1  sub rsp, 0x30
00007d55df7e25a5  movaps [rsp], xmm5
00007d55df7e25a9  movaps [rsp+0x10], xmm8
00007d55df7e25af  movaps [rsp+0x20], xmm6
00007d55df7e25b4  lea rdi, [rsp]
00007d55df7e25b8  mov esi, 0x00
00007d55df7e25bd  mov rax, 0x5BB8433D8530
00007d55df7e25c7  call rax
00007d55df7e25c9  movaps xmm5, [rsp]
00007d55df7e25cd  add rsp, 0x30
00007d55df7e25d1  vmovaps xmm0, [rsp]
00007d55df7e25d6  vmovaps xmm1, [rsp+0x10]
00007d55df7e25dc  vmovaps xmm2, [rsp+0x20]
00007d55df7e25e2  vmovaps xmm3, [rsp+0x30]
00007d55df7e25e8  vmovaps xmm4, [rsp+0x40]
00007d55df7e25ee  vmovaps xmm6, [rsp+0x50]
00007d55df7e25f4  vmovaps xmm7, [rsp+0x60]
00007d55df7e25fa  vmovaps xmm8, [rsp+0x70]
00007d55df7e2600  vmovaps xmm9, [rsp+0x80]
00007d55df7e2609  vmovaps xmm10, [rsp+0x90]
00007d55df7e2612  vmovaps xmm11, [rsp+0xA0]
00007d55df7e261b  vmovaps xmm12, [rsp+0xB0]
00007d55df7e2624  vmovaps xmm13, [rsp+0xC0]
00007d55df7e262d  vmovaps xmm14, [rsp+0xD0]
00007d55df7e2636  vmovaps xmm15, [rsp+0xE0]
00007d55df7e263f  add rsp, 0xF0
00007d55df7e2646  pop r11
00007d55df7e2648  pop r10
00007d55df7e264a  pop r9
00007d55df7e264c  pop r8
00007d55df7e264e  pop rsi
00007d55df7e264f  pop rdi
00007d55df7e2650  pop rdx
00007d55df7e2651  pop rcx
00007d55df7e2652  pop rax
00007d55df7e2653  add rsp, 0x08
00007d55df7e2657  jmp 0x00007D55DF7DF593
00007d55df7e265c  sub rsp, 0x08
00007d55df7e2660  push rax
00007d55df7e2661  push rcx
00007d55df7e2662  push rdx
00007d55df7e2663  push rdi
00007d55df7e2664  push rsi
00007d55df7e2665  push r8
00007d55df7e2667  push r9
00007d55df7e2669  push r10
00007d55df7e266b  push r11
00007d55df7e266d  sub rsp, 0xF0
00007d55df7e2674  vmovaps [rsp], xmm0
00007d55df7e2679  vmovaps [rsp+0x10], xmm1
00007d55df7e267f  vmovaps [rsp+0x20], xmm2
00007d55df7e2685  vmovaps [rsp+0x30], xmm3
00007d55df7e268b  vmovaps [rsp+0x40], xmm4
00007d55df7e2691  vmovaps [rsp+0x50], xmm5
00007d55df7e2697  vmovaps [rsp+0x60], xmm7
00007d55df7e269d  vmovaps [rsp+0x70], xmm8
00007d55df7e26a3  vmovaps [rsp+0x80], xmm9
00007d55df7e26ac  vmovaps [rsp+0x90], xmm10
00007d55df7e26b5  vmovaps [rsp+0xA0], xmm11
00007d55df7e26be  vmovaps [rsp+0xB0], xmm12
00007d55df7e26c7  vmovaps [rsp+0xC0], xmm13
00007d55df7e26d0  vmovaps [rsp+0xD0], xmm14
00007d55df7e26d9  vmovaps [rsp+0xE0], xmm15
00007d55df7e26e2  sub rsp, 0x30
00007d55df7e26e6  movaps [rsp], xmm6
00007d55df7e26ea  movaps [rsp+0x10], xmm10
00007d55df7e26f0  movaps [rsp+0x20], xmm8
00007d55df7e26f6  lea rdi, [rsp]
00007d55df7e26fa  mov esi, 0x00
00007d55df7e26ff  mov rax, 0x5BB8433D8530
00007d55df7e2709  call rax
00007d55df7e270b  movaps xmm6, [rsp]
00007d55df7e270f  add rsp, 0x30
00007d55df7e2713  vmovaps xmm0, [rsp]
00007d55df7e2718  vmovaps xmm1, [rsp+0x10]
00007d55df7e271e  vmovaps xmm2, [rsp+0x20]
00007d55df7e2724  vmovaps xmm3, [rsp+0x30]
00007d55df7e272a  vmovaps xmm4, [rsp+0x40]
00007d55df7e2730  vmovaps xmm5, [rsp+0x50]
00007d55df7e2736  vmovaps xmm7, [rsp+0x60]
00007d55df7e273c  vmovaps xmm8, [rsp+0x70]
00007d55df7e2742  vmovaps xmm9, [rsp+0x80]
00007d55df7e274b  vmovaps xmm10, [rsp+0x90]
00007d55df7e2754  vmovaps xmm11, [rsp+0xA0]
00007d55df7e275d  vmovaps xmm12, [rsp+0xB0]
00007d55df7e2766  vmovaps xmm13, [rsp+0xC0]
00007d55df7e276f  vmovaps xmm14, [rsp+0xD0]
00007d55df7e2778  vmovaps xmm15, [rsp+0xE0]
00007d55df7e2781  add rsp, 0xF0
00007d55df7e2788  pop r11
00007d55df7e278a  pop r10
00007d55df7e278c  pop r9
00007d55df7e278e  pop r8
00007d55df7e2790  pop rsi
00007d55df7e2791  pop rdi
00007d55df7e2792  pop rdx
00007d55df7e2793  pop rcx
00007d55df7e2794  pop rax
00007d55df7e2795  add rsp, 0x08
00007d55df7e2799  jmp 0x00007D55DF7DF5B8
00007d55df7e279e  sub rsp, 0x08
00007d55df7e27a2  push rax
00007d55df7e27a3  push rcx
00007d55df7e27a4  push rdx
00007d55df7e27a5  push rdi
00007d55df7e27a6  push rsi
00007d55df7e27a7  push r8
00007d55df7e27a9  push r9
00007d55df7e27ab  push r10
00007d55df7e27ad  push r11
00007d55df7e27af  sub rsp, 0xF0
00007d55df7e27b6  vmovaps [rsp], xmm0
00007d55df7e27bb  vmovaps [rsp+0x10], xmm1
00007d55df7e27c1  vmovaps [rsp+0x20], xmm2
00007d55df7e27c7  vmovaps [rsp+0x30], xmm3
00007d55df7e27cd  vmovaps [rsp+0x40], xmm4
00007d55df7e27d3  vmovaps [rsp+0x50], xmm5
00007d55df7e27d9  vmovaps [rsp+0x60], xmm6
00007d55df7e27df  vmovaps [rsp+0x70], xmm7
00007d55df7e27e5  vmovaps [rsp+0x80], xmm8
00007d55df7e27ee  vmovaps [rsp+0x90], xmm9
00007d55df7e27f7  vmovaps [rsp+0xA0], xmm11
00007d55df7e2800  vmovaps [rsp+0xB0], xmm12
00007d55df7e2809  vmovaps [rsp+0xC0], xmm13
00007d55df7e2812  vmovaps [rsp+0xD0], xmm14
00007d55df7e281b  vmovaps [rsp+0xE0], xmm15
00007d55df7e2824  sub rsp, 0x30
00007d55df7e2828  movaps [rsp], xmm10
00007d55df7e282d  movaps [rsp+0x10], xmm8
00007d55df7e2833  movaps [rsp+0x20], xmm14
00007d55df7e2839  lea rdi, [rsp]
00007d55df7e283d  mov esi, 0x00
00007d55df7e2842  mov rax, 0x5BB8433D8530
00007d55df7e284c  call rax
00007d55df7e284e  movaps xmm10, [rsp]
00007d55df7e2853  add rsp, 0x30
00007d55df7e2857  vmovaps xmm0, [rsp]
00007d55df7e285c  vmovaps xmm1, [rsp+0x10]
00007d55df7e2862  vmovaps xmm2, [rsp+0x20]
00007d55df7e2868  vmovaps xmm3, [rsp+0x30]
00007d55df7e286e  vmovaps xmm4, [rsp+0x40]
00007d55df7e2874  vmovaps xmm5, [rsp+0x50]
00007d55df7e287a  vmovaps xmm6, [rsp+0x60]
00007d55df7e2880  vmovaps xmm7, [rsp+0x70]
00007d55df7e2886  vmovaps xmm8, [rsp+0x80]
00007d55df7e288f  vmovaps xmm9, [rsp+0x90]
00007d55df7e2898  vmovaps xmm11, [rsp+0xA0]
00007d55df7e28a1  vmovaps xmm12, [rsp+0xB0]
00007d55df7e28aa  vmovaps xmm13, [rsp+0xC0]
00007d55df7e28b3  vmovaps xmm14, [rsp+0xD0]
00007d55df7e28bc  vmovaps xmm15, [rsp+0xE0]
00007d55df7e28c5  add rsp, 0xF0
00007d55df7e28cc  pop r11
00007d55df7e28ce  pop r10
00007d55df7e28d0  pop r9
00007d55df7e28d2  pop r8
00007d55df7e28d4  pop rsi
00007d55df7e28d5  pop rdi
00007d55df7e28d6  pop rdx
00007d55df7e28d7  pop rcx
00007d55df7e28d8  pop rax
00007d55df7e28d9  add rsp, 0x08
00007d55df7e28dd  jmp 0x00007D55DF7DF5D8
00007d55df7e28e2  sub rsp, 0x08
00007d55df7e28e6  push rax
00007d55df7e28e7  push rcx
00007d55df7e28e8  push rdx
00007d55df7e28e9  push rdi
00007d55df7e28ea  push rsi
00007d55df7e28eb  push r8
00007d55df7e28ed  push r9
00007d55df7e28ef  push r10
00007d55df7e28f1  push r11
00007d55df7e28f3  sub rsp, 0xF0
00007d55df7e28fa  vmovaps [rsp], xmm0
00007d55df7e28ff  vmovaps [rsp+0x10], xmm1
00007d55df7e2905  vmovaps [rsp+0x20], xmm2
00007d55df7e290b  vmovaps [rsp+0x30], xmm3
00007d55df7e2911  vmovaps [rsp+0x40], xmm4
00007d55df7e2917  vmovaps [rsp+0x50], xmm5
00007d55df7e291d  vmovaps [rsp+0x60], xmm6
00007d55df7e2923  vmovaps [rsp+0x70], xmm7
00007d55df7e2929  vmovaps [rsp+0x80], xmm8
00007d55df7e2932  vmovaps [rsp+0x90], xmm9
00007d55df7e293b  vmovaps [rsp+0xA0], xmm10
00007d55df7e2944  vmovaps [rsp+0xB0], xmm11
00007d55df7e294d  vmovaps [rsp+0xC0], xmm12
00007d55df7e2956  vmovaps [rsp+0xD0], xmm13
00007d55df7e295f  vmovaps [rsp+0xE0], xmm15
00007d55df7e2968  sub rsp, 0x30
00007d55df7e296c  movaps [rsp], xmm14
00007d55df7e2971  movaps [rsp+0x10], xmm8
00007d55df7e2977  movaps [rsp+0x20], xmm4
00007d55df7e297c  lea rdi, [rsp]
00007d55df7e2980  mov esi, 0x00
00007d55df7e2985  mov rax, 0x5BB8433D8530
00007d55df7e298f  call rax
00007d55df7e2991  movaps xmm14, [rsp]
00007d55df7e2996  add rsp, 0x30
00007d55df7e299a  vmovaps xmm0, [rsp]
00007d55df7e299f  vmovaps xmm1, [rsp+0x10]
00007d55df7e29a5  vmovaps xmm2, [rsp+0x20]
00007d55df7e29ab  vmovaps xmm3, [rsp+0x30]
00007d55df7e29b1  vmovaps xmm4, [rsp+0x40]
00007d55df7e29b7  vmovaps xmm5, [rsp+0x50]
00007d55df7e29bd  vmovaps xmm6, [rsp+0x60]
00007d55df7e29c3  vmovaps xmm7, [rsp+0x70]
00007d55df7e29c9  vmovaps xmm8, [rsp+0x80]
00007d55df7e29d2  vmovaps xmm9, [rsp+0x90]
00007d55df7e29db  vmovaps xmm10, [rsp+0xA0]
00007d55df7e29e4  vmovaps xmm11, [rsp+0xB0]
00007d55df7e29ed  vmovaps xmm12, [rsp+0xC0]
00007d55df7e29f6  vmovaps xmm13, [rsp+0xD0]
00007d55df7e29ff  vmovaps xmm15, [rsp+0xE0]
00007d55df7e2a08  add rsp, 0xF0
00007d55df7e2a0f  pop r11
00007d55df7e2a11  pop r10
00007d55df7e2a13  pop r9
00007d55df7e2a15  pop r8
00007d55df7e2a17  pop rsi
00007d55df7e2a18  pop rdi
00007d55df7e2a19  pop rdx
00007d55df7e2a1a  pop rcx
00007d55df7e2a1b  pop rax
00007d55df7e2a1c  add rsp, 0x08
00007d55df7e2a20  jmp 0x00007D55DF7DF5F8
00007d55df7e2a25  sub rsp, 0x08
00007d55df7e2a29  push rax
00007d55df7e2a2a  push rcx
00007d55df7e2a2b  push rdx
00007d55df7e2a2c  push rdi
00007d55df7e2a2d  push rsi
00007d55df7e2a2e  push r8
00007d55df7e2a30  push r9
00007d55df7e2a32  push r10
00007d55df7e2a34  push r11
00007d55df7e2a36  sub rsp, 0xF0
00007d55df7e2a3d  vmovaps [rsp], xmm0
00007d55df7e2a42  vmovaps [rsp+0x10], xmm1
00007d55df7e2a48  vmovaps [rsp+0x20], xmm2
00007d55df7e2a4e  vmovaps [rsp+0x30], xmm3
00007d55df7e2a54  vmovaps [rsp+0x40], xmm5
00007d55df7e2a5a  vmovaps [rsp+0x50], xmm6
00007d55df7e2a60  vmovaps [rsp+0x60], xmm7
00007d55df7e2a66  vmovaps [rsp+0x70], xmm8
00007d55df7e2a6c  vmovaps [rsp+0x80], xmm9
00007d55df7e2a75  vmovaps [rsp+0x90], xmm10
00007d55df7e2a7e  vmovaps [rsp+0xA0], xmm11
00007d55df7e2a87  vmovaps [rsp+0xB0], xmm12
00007d55df7e2a90  vmovaps [rsp+0xC0], xmm13
00007d55df7e2a99  vmovaps [rsp+0xD0], xmm14
00007d55df7e2aa2  vmovaps [rsp+0xE0], xmm15
00007d55df7e2aab  sub rsp, 0x30
00007d55df7e2aaf  movaps [rsp], xmm4
00007d55df7e2ab3  movaps [rsp+0x10], xmm13
00007d55df7e2ab9  movaps [rsp+0x20], xmm8
00007d55df7e2abf  lea rdi, [rsp]
00007d55df7e2ac3  mov esi, 0x00
00007d55df7e2ac8  mov rax, 0x5BB8433D8530
00007d55df7e2ad2  call rax
00007d55df7e2ad4  movaps xmm4, [rsp]
00007d55df7e2ad8  add rsp, 0x30
00007d55df7e2adc  vmovaps xmm0, [rsp]
00007d55df7e2ae1  vmovaps xmm1, [rsp+0x10]
00007d55df7e2ae7  vmovaps xmm2, [rsp+0x20]
00007d55df7e2aed  vmovaps xmm3, [rsp+0x30]
00007d55df7e2af3  vmovaps xmm5, [rsp+0x40]
00007d55df7e2af9  vmovaps xmm6, [rsp+0x50]
00007d55df7e2aff  vmovaps xmm7, [rsp+0x60]
00007d55df7e2b05  vmovaps xmm8, [rsp+0x70]
00007d55df7e2b0b  vmovaps xmm9, [rsp+0x80]
00007d55df7e2b14  vmovaps xmm10, [rsp+0x90]
00007d55df7e2b1d  vmovaps xmm11, [rsp+0xA0]
00007d55df7e2b26  vmovaps xmm12, [rsp+0xB0]
00007d55df7e2b2f  vmovaps xmm13, [rsp+0xC0]
00007d55df7e2b38  vmovaps xmm14, [rsp+0xD0]
00007d55df7e2b41  vmovaps xmm15, [rsp+0xE0]
00007d55df7e2b4a  add rsp, 0xF0
00007d55df7e2b51  pop r11
00007d55df7e2b53  pop r10
00007d55df7e2b55  pop r9
00007d55df7e2b57  pop r8
00007d55df7e2b59  pop rsi
00007d55df7e2b5a  pop rdi
00007d55df7e2b5b  pop rdx
00007d55df7e2b5c  pop rcx
00007d55df7e2b5d  pop rax
00007d55df7e2b5e  add rsp, 0x08
00007d55df7e2b62  jmp 0x00007D55DF7DF61D
00007d55df7e2b67  sub rsp, 0x08
00007d55df7e2b6b  push rax
00007d55df7e2b6c  push rcx
00007d55df7e2b6d  push rdx
00007d55df7e2b6e  push rdi
00007d55df7e2b6f  push rsi
00007d55df7e2b70  push r8
00007d55df7e2b72  push r9
00007d55df7e2b74  push r10
00007d55df7e2b76  push r11
00007d55df7e2b78  sub rsp, 0xF0
00007d55df7e2b7f  vmovaps [rsp], xmm0
00007d55df7e2b84  vmovaps [rsp+0x10], xmm1
00007d55df7e2b8a  vmovaps [rsp+0x20], xmm2
00007d55df7e2b90  vmovaps [rsp+0x30], xmm3
00007d55df7e2b96  vmovaps [rsp+0x40], xmm4
00007d55df7e2b9c  vmovaps [rsp+0x50], xmm5
00007d55df7e2ba2  vmovaps [rsp+0x60], xmm6
00007d55df7e2ba8  vmovaps [rsp+0x70], xmm7
00007d55df7e2bae  vmovaps [rsp+0x80], xmm8
00007d55df7e2bb7  vmovaps [rsp+0x90], xmm9
00007d55df7e2bc0  vmovaps [rsp+0xA0], xmm10
00007d55df7e2bc9  vmovaps [rsp+0xB0], xmm11
00007d55df7e2bd2  vmovaps [rsp+0xC0], xmm12
00007d55df7e2bdb  vmovaps [rsp+0xD0], xmm14
00007d55df7e2be4  vmovaps [rsp+0xE0], xmm15
00007d55df7e2bed  sub rsp, 0x30
00007d55df7e2bf1  movaps [rsp], xmm13
00007d55df7e2bf6  movaps [rsp+0x10], xmm15
00007d55df7e2bfc  movaps [rsp+0x20], xmm9
00007d55df7e2c02  lea rdi, [rsp]
00007d55df7e2c06  mov esi, 0x00
00007d55df7e2c0b  mov rax, 0x5BB8433D8530
00007d55df7e2c15  call rax
00007d55df7e2c17  movaps xmm13, [rsp]
00007d55df7e2c1c  add rsp, 0x30
00007d55df7e2c20  vmovaps xmm0, [rsp]
00007d55df7e2c25  vmovaps xmm1, [rsp+0x10]
00007d55df7e2c2b  vmovaps xmm2, [rsp+0x20]
00007d55df7e2c31  vmovaps xmm3, [rsp+0x30]
00007d55df7e2c37  vmovaps xmm4, [rsp+0x40]
00007d55df7e2c3d  vmovaps xmm5, [rsp+0x50]
00007d55df7e2c43  vmovaps xmm6, [rsp+0x60]
00007d55df7e2c49  vmovaps xmm7, [rsp+0x70]
00007d55df7e2c4f  vmovaps xmm8, [rsp+0x80]
00007d55df7e2c58  vmovaps xmm9, [rsp+0x90]
00007d55df7e2c61  vmovaps xmm10, [rsp+0xA0]
00007d55df7e2c6a  vmovaps xmm11, [rsp+0xB0]
00007d55df7e2c73  vmovaps xmm12, [rsp+0xC0]
00007d55df7e2c7c  vmovaps xmm14, [rsp+0xD0]
00007d55df7e2c85  vmovaps xmm15, [rsp+0xE0]
00007d55df7e2c8e  add rsp, 0xF0
00007d55df7e2c95  pop r11
00007d55df7e2c97  pop r10
00007d55df7e2c99  pop r9
00007d55df7e2c9b  pop r8
00007d55df7e2c9d  pop rsi
00007d55df7e2c9e  pop rdi
00007d55df7e2c9f  pop rdx
00007d55df7e2ca0  pop rcx
00007d55df7e2ca1  pop rax
00007d55df7e2ca2  add rsp, 0x08
00007d55df7e2ca6  jmp 0x00007D55DF7DF638
00007d55df7e2cab  sub rsp, 0x08
00007d55df7e2caf  push rax
00007d55df7e2cb0  push rcx
00007d55df7e2cb1  push rdx
00007d55df7e2cb2  push rdi
00007d55df7e2cb3  push rsi
00007d55df7e2cb4  push r8
00007d55df7e2cb6  push r9
00007d55df7e2cb8  push r10
00007d55df7e2cba  push r11
00007d55df7e2cbc  sub rsp, 0xF0
00007d55df7e2cc3  vmovaps [rsp], xmm0
00007d55df7e2cc8  vmovaps [rsp+0x10], xmm1
00007d55df7e2cce  vmovaps [rsp+0x20], xmm2
00007d55df7e2cd4  vmovaps [rsp+0x30], xmm3
00007d55df7e2cda  vmovaps [rsp+0x40], xmm4
00007d55df7e2ce0  vmovaps [rsp+0x50], xmm5
00007d55df7e2ce6  vmovaps [rsp+0x60], xmm6
00007d55df7e2cec  vmovaps [rsp+0x70], xmm7
00007d55df7e2cf2  vmovaps [rsp+0x80], xmm8
00007d55df7e2cfb  vmovaps [rsp+0x90], xmm9
00007d55df7e2d04  vmovaps [rsp+0xA0], xmm10
00007d55df7e2d0d  vmovaps [rsp+0xB0], xmm11
00007d55df7e2d16  vmovaps [rsp+0xC0], xmm12
00007d55df7e2d1f  vmovaps [rsp+0xD0], xmm13
00007d55df7e2d28  vmovaps [rsp+0xE0], xmm14
00007d55df7e2d31  sub rsp, 0x30
00007d55df7e2d35  movaps [rsp], xmm15
00007d55df7e2d3a  movaps [rsp+0x10], xmm1
00007d55df7e2d3f  movaps [rsp+0x20], xmm5
00007d55df7e2d44  lea rdi, [rsp]
00007d55df7e2d48  mov esi, 0x00
00007d55df7e2d4d  mov rax, 0x5BB8433D8530
00007d55df7e2d57  call rax
00007d55df7e2d59  movaps xmm15, [rsp]
00007d55df7e2d5e  add rsp, 0x30
00007d55df7e2d62  vmovaps xmm0, [rsp]
00007d55df7e2d67  vmovaps xmm1, [rsp+0x10]
00007d55df7e2d6d  vmovaps xmm2, [rsp+0x20]
00007d55df7e2d73  vmovaps xmm3, [rsp+0x30]
00007d55df7e2d79  vmovaps xmm4, [rsp+0x40]
00007d55df7e2d7f  vmovaps xmm5, [rsp+0x50]
00007d55df7e2d85  vmovaps xmm6, [rsp+0x60]
00007d55df7e2d8b  vmovaps xmm7, [rsp+0x70]
00007d55df7e2d91  vmovaps xmm8, [rsp+0x80]
00007d55df7e2d9a  vmovaps xmm9, [rsp+0x90]
00007d55df7e2da3  vmovaps xmm10, [rsp+0xA0]
00007d55df7e2dac  vmovaps xmm11, [rsp+0xB0]
00007d55df7e2db5  vmovaps xmm12, [rsp+0xC0]
00007d55df7e2dbe  vmovaps xmm13, [rsp+0xD0]
00007d55df7e2dc7  vmovaps xmm14, [rsp+0xE0]
00007d55df7e2dd0  add rsp, 0xF0
00007d55df7e2dd7  pop r11
00007d55df7e2dd9  pop r10
00007d55df7e2ddb  pop r9
00007d55df7e2ddd  pop r8
00007d55df7e2ddf  pop rsi
00007d55df7e2de0  pop rdi
00007d55df7e2de1  pop rdx
00007d55df7e2de2  pop rcx
00007d55df7e2de3  pop rax
00007d55df7e2de4  add rsp, 0x08
00007d55df7e2de8  jmp 0x00007D55DF7DF653
00007d55df7e2ded  call 0x00007D55DF6B52F0
00007d55df7e2df2  jmp 0x00007D55DF7DF6AE
00007d55df7e2df7  sub rsp, 0x08
00007d55df7e2dfb  push rax
00007d55df7e2dfc  push rcx
00007d55df7e2dfd  push rdx
00007d55df7e2dfe  push rdi
00007d55df7e2dff  push rsi
00007d55df7e2e00  push r8
00007d55df7e2e02  push r9
00007d55df7e2e04  push r10
00007d55df7e2e06  push r11
00007d55df7e2e08  sub rsp, 0xF0
00007d55df7e2e0f  vmovaps [rsp], xmm0
00007d55df7e2e14  vmovaps [rsp+0x10], xmm1
00007d55df7e2e1a  vmovaps [rsp+0x20], xmm2
00007d55df7e2e20  vmovaps [rsp+0x30], xmm3
00007d55df7e2e26  vmovaps [rsp+0x40], xmm4
00007d55df7e2e2c  vmovaps [rsp+0x50], xmm5
00007d55df7e2e32  vmovaps [rsp+0x60], xmm6
00007d55df7e2e38  vmovaps [rsp+0x70], xmm7
00007d55df7e2e3e  vmovaps [rsp+0x80], xmm8
00007d55df7e2e47  vmovaps [rsp+0x90], xmm10
00007d55df7e2e50  vmovaps [rsp+0xA0], xmm11
00007d55df7e2e59  vmovaps [rsp+0xB0], xmm12
00007d55df7e2e62  vmovaps [rsp+0xC0], xmm13
00007d55df7e2e6b  vmovaps [rsp+0xD0], xmm14
00007d55df7e2e74  vmovaps [rsp+0xE0], xmm15
00007d55df7e2e7d  sub rsp, 0x30
00007d55df7e2e81  movaps [rsp], xmm9
00007d55df7e2e86  movaps [rsp+0x10], xmm8
00007d55df7e2e8c  movaps [rsp+0x20], xmm11
00007d55df7e2e92  lea rdi, [rsp]
00007d55df7e2e96  mov esi, 0x00
00007d55df7e2e9b  mov rax, 0x5BB8433D8530
00007d55df7e2ea5  call rax
00007d55df7e2ea7  movaps xmm9, [rsp]
00007d55df7e2eac  add rsp, 0x30
00007d55df7e2eb0  vmovaps xmm0, [rsp]
00007d55df7e2eb5  vmovaps xmm1, [rsp+0x10]
00007d55df7e2ebb  vmovaps xmm2, [rsp+0x20]
00007d55df7e2ec1  vmovaps xmm3, [rsp+0x30]
00007d55df7e2ec7  vmovaps xmm4, [rsp+0x40]
00007d55df7e2ecd  vmovaps xmm5, [rsp+0x50]
00007d55df7e2ed3  vmovaps xmm6, [rsp+0x60]
00007d55df7e2ed9  vmovaps xmm7, [rsp+0x70]
00007d55df7e2edf  vmovaps xmm8, [rsp+0x80]
00007d55df7e2ee8  vmovaps xmm10, [rsp+0x90]
00007d55df7e2ef1  vmovaps xmm11, [rsp+0xA0]
00007d55df7e2efa  vmovaps xmm12, [rsp+0xB0]
00007d55df7e2f03  vmovaps xmm13, [rsp+0xC0]
00007d55df7e2f0c  vmovaps xmm14, [rsp+0xD0]
00007d55df7e2f15  vmovaps xmm15, [rsp+0xE0]
00007d55df7e2f1e  add rsp, 0xF0
00007d55df7e2f25  pop r11
00007d55df7e2f27  pop r10
00007d55df7e2f29  pop r9
00007d55df7e2f2b  pop r8
00007d55df7e2f2d  pop rsi
00007d55df7e2f2e  pop rdi
00007d55df7e2f2f  pop rdx
00007d55df7e2f30  pop rcx
00007d55df7e2f31  pop rax
00007d55df7e2f32  add rsp, 0x08
00007d55df7e2f36  jmp 0x00007D55DF7DF6E5
00007d55df7e2f3b  sub rsp, 0x08
00007d55df7e2f3f  push rax
00007d55df7e2f40  push rcx
00007d55df7e2f41  push rdx
00007d55df7e2f42  push rdi
00007d55df7e2f43  push rsi
00007d55df7e2f44  push r8
00007d55df7e2f46  push r9
00007d55df7e2f48  push r10
00007d55df7e2f4a  push r11
00007d55df7e2f4c  sub rsp, 0xF0
00007d55df7e2f53  vmovaps [rsp], xmm0
00007d55df7e2f58  vmovaps [rsp+0x10], xmm1
00007d55df7e2f5e  vmovaps [rsp+0x20], xmm2
00007d55df7e2f64  vmovaps [rsp+0x30], xmm3
00007d55df7e2f6a  vmovaps [rsp+0x40], xmm4
00007d55df7e2f70  vmovaps [rsp+0x50], xmm5
00007d55df7e2f76  vmovaps [rsp+0x60], xmm6
00007d55df7e2f7c  vmovaps [rsp+0x70], xmm7
00007d55df7e2f82  vmovaps [rsp+0x80], xmm8
00007d55df7e2f8b  vmovaps [rsp+0x90], xmm9
00007d55df7e2f94  vmovaps [rsp+0xA0], xmm10
00007d55df7e2f9d  vmovaps [rsp+0xB0], xmm12
00007d55df7e2fa6  vmovaps [rsp+0xC0], xmm13
00007d55df7e2faf  vmovaps [rsp+0xD0], xmm14
00007d55df7e2fb8  vmovaps [rsp+0xE0], xmm15
00007d55df7e2fc1  sub rsp, 0x30
00007d55df7e2fc5  movaps [rsp], xmm11
00007d55df7e2fca  movaps [rsp+0x10], xmm10
00007d55df7e2fd0  movaps [rsp+0x20], xmm6
00007d55df7e2fd5  lea rdi, [rsp]
00007d55df7e2fd9  mov esi, 0x00
00007d55df7e2fde  mov rax, 0x5BB8433D8530
00007d55df7e2fe8  call rax
00007d55df7e2fea  movaps xmm11, [rsp]
00007d55df7e2fef  add rsp, 0x30
00007d55df7e2ff3  vmovaps xmm0, [rsp]
00007d55df7e2ff8  vmovaps xmm1, [rsp+0x10]
00007d55df7e2ffe  vmovaps xmm2, [rsp+0x20]
00007d55df7e3004  vmovaps xmm3, [rsp+0x30]
00007d55df7e300a  vmovaps xmm4, [rsp+0x40]
00007d55df7e3010  vmovaps xmm5, [rsp+0x50]
00007d55df7e3016  vmovaps xmm6, [rsp+0x60]
00007d55df7e301c  vmovaps xmm7, [rsp+0x70]
00007d55df7e3022  vmovaps xmm8, [rsp+0x80]
00007d55df7e302b  vmovaps xmm9, [rsp+0x90]
00007d55df7e3034  vmovaps xmm10, [rsp+0xA0]
00007d55df7e303d  vmovaps xmm12, [rsp+0xB0]
00007d55df7e3046  vmovaps xmm13, [rsp+0xC0]
00007d55df7e304f  vmovaps xmm14, [rsp+0xD0]
00007d55df7e3058  vmovaps xmm15, [rsp+0xE0]
00007d55df7e3061  add rsp, 0xF0
00007d55df7e3068  pop r11
00007d55df7e306a  pop r10
00007d55df7e306c  pop r9
00007d55df7e306e  pop r8
00007d55df7e3070  pop rsi
00007d55df7e3071  pop rdi
00007d55df7e3072  pop rdx
00007d55df7e3073  pop rcx
00007d55df7e3074  pop rax
00007d55df7e3075  add rsp, 0x08
00007d55df7e3079  jmp 0x00007D55DF7DF700
00007d55df7e307e  sub rsp, 0x08
00007d55df7e3082  push rax
00007d55df7e3083  push rcx
00007d55df7e3084  push rdx
00007d55df7e3085  push rdi
00007d55df7e3086  push rsi
00007d55df7e3087  push r8
00007d55df7e3089  push r9
00007d55df7e308b  push r10
00007d55df7e308d  push r11
00007d55df7e308f  sub rsp, 0xF0
00007d55df7e3096  vmovaps [rsp], xmm0
00007d55df7e309b  vmovaps [rsp+0x10], xmm1
00007d55df7e30a1  vmovaps [rsp+0x20], xmm2
00007d55df7e30a7  vmovaps [rsp+0x30], xmm3
00007d55df7e30ad  vmovaps [rsp+0x40], xmm4
00007d55df7e30b3  vmovaps [rsp+0x50], xmm5
00007d55df7e30b9  vmovaps [rsp+0x60], xmm6
00007d55df7e30bf  vmovaps [rsp+0x70], xmm7
00007d55df7e30c5  vmovaps [rsp+0x80], xmm8
00007d55df7e30ce  vmovaps [rsp+0x90], xmm9
00007d55df7e30d7  vmovaps [rsp+0xA0], xmm11
00007d55df7e30e0  vmovaps [rsp+0xB0], xmm12
00007d55df7e30e9  vmovaps [rsp+0xC0], xmm13
00007d55df7e30f2  vmovaps [rsp+0xD0], xmm14
00007d55df7e30fb  vmovaps [rsp+0xE0], xmm15
00007d55df7e3104  sub rsp, 0x30
00007d55df7e3108  movaps [rsp], xmm10
00007d55df7e310d  movaps [rsp+0x10], xmm14
00007d55df7e3113  movaps [rsp+0x20], xmm4
00007d55df7e3118  lea rdi, [rsp]
00007d55df7e311c  mov esi, 0x00
00007d55df7e3121  mov rax, 0x5BB8433D8530
00007d55df7e312b  call rax
00007d55df7e312d  movaps xmm10, [rsp]
00007d55df7e3132  add rsp, 0x30
00007d55df7e3136  vmovaps xmm0, [rsp]
00007d55df7e313b  vmovaps xmm1, [rsp+0x10]
00007d55df7e3141  vmovaps xmm2, [rsp+0x20]
00007d55df7e3147  vmovaps xmm3, [rsp+0x30]
00007d55df7e314d  vmovaps xmm4, [rsp+0x40]
00007d55df7e3153  vmovaps xmm5, [rsp+0x50]
00007d55df7e3159  vmovaps xmm6, [rsp+0x60]
00007d55df7e315f  vmovaps xmm7, [rsp+0x70]
00007d55df7e3165  vmovaps xmm8, [rsp+0x80]
00007d55df7e316e  vmovaps xmm9, [rsp+0x90]
00007d55df7e3177  vmovaps xmm11, [rsp+0xA0]
00007d55df7e3180  vmovaps xmm12, [rsp+0xB0]
00007d55df7e3189  vmovaps xmm13, [rsp+0xC0]
00007d55df7e3192  vmovaps xmm14, [rsp+0xD0]
00007d55df7e319b  vmovaps xmm15, [rsp+0xE0]
00007d55df7e31a4  add rsp, 0xF0
00007d55df7e31ab  pop r11
00007d55df7e31ad  pop r10
00007d55df7e31af  pop r9
00007d55df7e31b1  pop r8
00007d55df7e31b3  pop rsi
00007d55df7e31b4  pop rdi
00007d55df7e31b5  pop rdx
00007d55df7e31b6  pop rcx
00007d55df7e31b7  pop rax
00007d55df7e31b8  add rsp, 0x08
00007d55df7e31bc  jmp 0x00007D55DF7DF71B
00007d55df7e31c1  sub rsp, 0x08
00007d55df7e31c5  push rax
00007d55df7e31c6  push rcx
00007d55df7e31c7  push rdx
00007d55df7e31c8  push rdi
00007d55df7e31c9  push rsi
00007d55df7e31ca  push r8
00007d55df7e31cc  push r9
00007d55df7e31ce  push r10
00007d55df7e31d0  push r11
00007d55df7e31d2  sub rsp, 0xF0
00007d55df7e31d9  vmovaps [rsp], xmm0
00007d55df7e31de  vmovaps [rsp+0x10], xmm1
00007d55df7e31e4  vmovaps [rsp+0x20], xmm2
00007d55df7e31ea  vmovaps [rsp+0x30], xmm3
00007d55df7e31f0  vmovaps [rsp+0x40], xmm4
00007d55df7e31f6  vmovaps [rsp+0x50], xmm5
00007d55df7e31fc  vmovaps [rsp+0x60], xmm6
00007d55df7e3202  vmovaps [rsp+0x70], xmm7
00007d55df7e3208  vmovaps [rsp+0x80], xmm9
00007d55df7e3211  vmovaps [rsp+0x90], xmm10
00007d55df7e321a  vmovaps [rsp+0xA0], xmm11
00007d55df7e3223  vmovaps [rsp+0xB0], xmm12
00007d55df7e322c  vmovaps [rsp+0xC0], xmm13
00007d55df7e3235  vmovaps [rsp+0xD0], xmm14
00007d55df7e323e  vmovaps [rsp+0xE0], xmm15
00007d55df7e3247  sub rsp, 0x30
00007d55df7e324b  movaps [rsp], xmm8
00007d55df7e3250  movaps [rsp+0x10], xmm1
00007d55df7e3255  movaps [rsp+0x20], xmm14
00007d55df7e325b  lea rdi, [rsp]
00007d55df7e325f  mov esi, 0x00
00007d55df7e3264  mov rax, 0x5BB8433D8530
00007d55df7e326e  call rax
00007d55df7e3270  movaps xmm8, [rsp]
00007d55df7e3275  add rsp, 0x30
00007d55df7e3279  vmovaps xmm0, [rsp]
00007d55df7e327e  vmovaps xmm1, [rsp+0x10]
00007d55df7e3284  vmovaps xmm2, [rsp+0x20]
00007d55df7e328a  vmovaps xmm3, [rsp+0x30]
00007d55df7e3290  vmovaps xmm4, [rsp+0x40]
00007d55df7e3296  vmovaps xmm5, [rsp+0x50]
00007d55df7e329c  vmovaps xmm6, [rsp+0x60]
00007d55df7e32a2  vmovaps xmm7, [rsp+0x70]
00007d55df7e32a8  vmovaps xmm9, [rsp+0x80]
00007d55df7e32b1  vmovaps xmm10, [rsp+0x90]
00007d55df7e32ba  vmovaps xmm11, [rsp+0xA0]
00007d55df7e32c3  vmovaps xmm12, [rsp+0xB0]
00007d55df7e32cc  vmovaps xmm13, [rsp+0xC0]
00007d55df7e32d5  vmovaps xmm14, [rsp+0xD0]
00007d55df7e32de  vmovaps xmm15, [rsp+0xE0]
00007d55df7e32e7  add rsp, 0xF0
00007d55df7e32ee  pop r11
00007d55df7e32f0  pop r10
00007d55df7e32f2  pop r9
00007d55df7e32f4  pop r8
00007d55df7e32f6  pop rsi
00007d55df7e32f7  pop rdi
00007d55df7e32f8  pop rdx
00007d55df7e32f9  pop rcx
00007d55df7e32fa  pop rax
00007d55df7e32fb  add rsp, 0x08
00007d55df7e32ff  jmp 0x00007D55DF7DF741
00007d55df7e3304  sub rsp, 0x08
00007d55df7e3308  push rax
00007d55df7e3309  push rcx
00007d55df7e330a  push rdx
00007d55df7e330b  push rdi
00007d55df7e330c  push rsi
00007d55df7e330d  push r8
00007d55df7e330f  push r9
00007d55df7e3311  push r10
00007d55df7e3313  push r11
00007d55df7e3315  sub rsp, 0xF0
00007d55df7e331c  vmovaps [rsp], xmm0
00007d55df7e3321  vmovaps [rsp+0x10], xmm1
00007d55df7e3327  vmovaps [rsp+0x20], xmm2
00007d55df7e332d  vmovaps [rsp+0x30], xmm3
00007d55df7e3333  vmovaps [rsp+0x40], xmm4
00007d55df7e3339  vmovaps [rsp+0x50], xmm5
00007d55df7e333f  vmovaps [rsp+0x60], xmm7
00007d55df7e3345  vmovaps [rsp+0x70], xmm8
00007d55df7e334b  vmovaps [rsp+0x80], xmm9
00007d55df7e3354  vmovaps [rsp+0x90], xmm10
00007d55df7e335d  vmovaps [rsp+0xA0], xmm11
00007d55df7e3366  vmovaps [rsp+0xB0], xmm12
00007d55df7e336f  vmovaps [rsp+0xC0], xmm13
00007d55df7e3378  vmovaps [rsp+0xD0], xmm14
00007d55df7e3381  vmovaps [rsp+0xE0], xmm15
00007d55df7e338a  sub rsp, 0x30
00007d55df7e338e  movaps [rsp], xmm6
00007d55df7e3392  movaps [rsp+0x10], xmm1
00007d55df7e3397  movaps [rsp+0x20], xmm14
00007d55df7e339d  lea rdi, [rsp]
00007d55df7e33a1  mov esi, 0x00
00007d55df7e33a6  mov rax, 0x5BB8433D8530
00007d55df7e33b0  call rax
00007d55df7e33b2  movaps xmm6, [rsp]
00007d55df7e33b6  add rsp, 0x30
00007d55df7e33ba  vmovaps xmm0, [rsp]
00007d55df7e33bf  vmovaps xmm1, [rsp+0x10]
00007d55df7e33c5  vmovaps xmm2, [rsp+0x20]
00007d55df7e33cb  vmovaps xmm3, [rsp+0x30]
00007d55df7e33d1  vmovaps xmm4, [rsp+0x40]
00007d55df7e33d7  vmovaps xmm5, [rsp+0x50]
00007d55df7e33dd  vmovaps xmm7, [rsp+0x60]
00007d55df7e33e3  vmovaps xmm8, [rsp+0x70]
00007d55df7e33e9  vmovaps xmm9, [rsp+0x80]
00007d55df7e33f2  vmovaps xmm10, [rsp+0x90]
00007d55df7e33fb  vmovaps xmm11, [rsp+0xA0]
00007d55df7e3404  vmovaps xmm12, [rsp+0xB0]
00007d55df7e340d  vmovaps xmm13, [rsp+0xC0]
00007d55df7e3416  vmovaps xmm14, [rsp+0xD0]
00007d55df7e341f  vmovaps xmm15, [rsp+0xE0]
00007d55df7e3428  add rsp, 0xF0
00007d55df7e342f  pop r11
00007d55df7e3431  pop r10
00007d55df7e3433  pop r9
00007d55df7e3435  pop r8
00007d55df7e3437  pop rsi
00007d55df7e3438  pop rdi
00007d55df7e3439  pop rdx
00007d55df7e343a  pop rcx
00007d55df7e343b  pop rax
00007d55df7e343c  add rsp, 0x08
00007d55df7e3440  jmp 0x00007D55DF7DF76D
00007d55df7e3445  sub rsp, 0x08
00007d55df7e3449  push rax
00007d55df7e344a  push rcx
00007d55df7e344b  push rdx
00007d55df7e344c  push rdi
00007d55df7e344d  push rsi
00007d55df7e344e  push r8
00007d55df7e3450  push r9
00007d55df7e3452  push r10
00007d55df7e3454  push r11
00007d55df7e3456  sub rsp, 0xF0
00007d55df7e345d  vmovaps [rsp], xmm0
00007d55df7e3462  vmovaps [rsp+0x10], xmm1
00007d55df7e3468  vmovaps [rsp+0x20], xmm2
00007d55df7e346e  vmovaps [rsp+0x30], xmm3
00007d55df7e3474  vmovaps [rsp+0x40], xmm4
00007d55df7e347a  vmovaps [rsp+0x50], xmm5
00007d55df7e3480  vmovaps [rsp+0x60], xmm6
00007d55df7e3486  vmovaps [rsp+0x70], xmm7
00007d55df7e348c  vmovaps [rsp+0x80], xmm8
00007d55df7e3495  vmovaps [rsp+0x90], xmm9
00007d55df7e349e  vmovaps [rsp+0xA0], xmm10
00007d55df7e34a7  vmovaps [rsp+0xB0], xmm11
00007d55df7e34b0  vmovaps [rsp+0xC0], xmm12
00007d55df7e34b9  vmovaps [rsp+0xD0], xmm13
00007d55df7e34c2  vmovaps [rsp+0xE0], xmm15
00007d55df7e34cb  sub rsp, 0x30
00007d55df7e34cf  movaps [rsp], xmm14
00007d55df7e34d4  movaps [rsp+0x10], xmm12
00007d55df7e34da  movaps [rsp+0x20], xmm1
00007d55df7e34df  lea rdi, [rsp]
00007d55df7e34e3  mov esi, 0x00
00007d55df7e34e8  mov rax, 0x5BB8433D8530
00007d55df7e34f2  call rax
00007d55df7e34f4  movaps xmm14, [rsp]
00007d55df7e34f9  add rsp, 0x30
00007d55df7e34fd  vmovaps xmm0, [rsp]
00007d55df7e3502  vmovaps xmm1, [rsp+0x10]
00007d55df7e3508  vmovaps xmm2, [rsp+0x20]
00007d55df7e350e  vmovaps xmm3, [rsp+0x30]
00007d55df7e3514  vmovaps xmm4, [rsp+0x40]
00007d55df7e351a  vmovaps xmm5, [rsp+0x50]
00007d55df7e3520  vmovaps xmm6, [rsp+0x60]
00007d55df7e3526  vmovaps xmm7, [rsp+0x70]
00007d55df7e352c  vmovaps xmm8, [rsp+0x80]
00007d55df7e3535  vmovaps xmm9, [rsp+0x90]
00007d55df7e353e  vmovaps xmm10, [rsp+0xA0]
00007d55df7e3547  vmovaps xmm11, [rsp+0xB0]
00007d55df7e3550  vmovaps xmm12, [rsp+0xC0]
00007d55df7e3559  vmovaps xmm13, [rsp+0xD0]
00007d55df7e3562  vmovaps xmm15, [rsp+0xE0]
00007d55df7e356b  add rsp, 0xF0
00007d55df7e3572  pop r11
00007d55df7e3574  pop r10
00007d55df7e3576  pop r9
00007d55df7e3578  pop r8
00007d55df7e357a  pop rsi
00007d55df7e357b  pop rdi
00007d55df7e357c  pop rdx
00007d55df7e357d  pop rcx
00007d55df7e357e  pop rax
00007d55df7e357f  add rsp, 0x08
00007d55df7e3583  jmp 0x00007D55DF7DF793
00007d55df7e3588  sub rsp, 0x08
00007d55df7e358c  push rax
00007d55df7e358d  push rcx
00007d55df7e358e  push rdx
00007d55df7e358f  push rdi
00007d55df7e3590  push rsi
00007d55df7e3591  push r8
00007d55df7e3593  push r9
00007d55df7e3595  push r10
00007d55df7e3597  push r11
00007d55df7e3599  sub rsp, 0xF0
00007d55df7e35a0  vmovaps [rsp], xmm0
00007d55df7e35a5  vmovaps [rsp+0x10], xmm2
00007d55df7e35ab  vmovaps [rsp+0x20], xmm3
00007d55df7e35b1  vmovaps [rsp+0x30], xmm4
00007d55df7e35b7  vmovaps [rsp+0x40], xmm5
00007d55df7e35bd  vmovaps [rsp+0x50], xmm6
00007d55df7e35c3  vmovaps [rsp+0x60], xmm7
00007d55df7e35c9  vmovaps [rsp+0x70], xmm8
00007d55df7e35cf  vmovaps [rsp+0x80], xmm9
00007d55df7e35d8  vmovaps [rsp+0x90], xmm10
00007d55df7e35e1  vmovaps [rsp+0xA0], xmm11
00007d55df7e35ea  vmovaps [rsp+0xB0], xmm12
00007d55df7e35f3  vmovaps [rsp+0xC0], xmm13
00007d55df7e35fc  vmovaps [rsp+0xD0], xmm14
00007d55df7e3605  vmovaps [rsp+0xE0], xmm15
00007d55df7e360e  sub rsp, 0x30
00007d55df7e3612  movaps [rsp], xmm1
00007d55df7e3616  movaps [rsp+0x10], xmm13
00007d55df7e361c  movaps [rsp+0x20], xmm9
00007d55df7e3622  lea rdi, [rsp]
00007d55df7e3626  mov esi, 0x00
00007d55df7e362b  mov rax, 0x5BB8433D8530
00007d55df7e3635  call rax
00007d55df7e3637  movaps xmm1, [rsp]
00007d55df7e363b  add rsp, 0x30
00007d55df7e363f  vmovaps xmm0, [rsp]
00007d55df7e3644  vmovaps xmm2, [rsp+0x10]
00007d55df7e364a  vmovaps xmm3, [rsp+0x20]
00007d55df7e3650  vmovaps xmm4, [rsp+0x30]
00007d55df7e3656  vmovaps xmm5, [rsp+0x40]
00007d55df7e365c  vmovaps xmm6, [rsp+0x50]
00007d55df7e3662  vmovaps xmm7, [rsp+0x60]
00007d55df7e3668  vmovaps xmm8, [rsp+0x70]
00007d55df7e366e  vmovaps xmm9, [rsp+0x80]
00007d55df7e3677  vmovaps xmm10, [rsp+0x90]
00007d55df7e3680  vmovaps xmm11, [rsp+0xA0]
00007d55df7e3689  vmovaps xmm12, [rsp+0xB0]
00007d55df7e3692  vmovaps xmm13, [rsp+0xC0]
00007d55df7e369b  vmovaps xmm14, [rsp+0xD0]
00007d55df7e36a4  vmovaps xmm15, [rsp+0xE0]
00007d55df7e36ad  add rsp, 0xF0
00007d55df7e36b4  pop r11
00007d55df7e36b6  pop r10
00007d55df7e36b8  pop r9
00007d55df7e36ba  pop r8
00007d55df7e36bc  pop rsi
00007d55df7e36bd  pop rdi
00007d55df7e36be  pop rdx
00007d55df7e36bf  pop rcx
00007d55df7e36c0  pop rax
00007d55df7e36c1  add rsp, 0x08
00007d55df7e36c5  jmp 0x00007D55DF7DF7AD
00007d55df7e36ca  sub rsp, 0x08
00007d55df7e36ce  push rax
00007d55df7e36cf  push rcx
00007d55df7e36d0  push rdx
00007d55df7e36d1  push rdi
00007d55df7e36d2  push rsi
00007d55df7e36d3  push r8
00007d55df7e36d5  push r9
00007d55df7e36d7  push r10
00007d55df7e36d9  push r11
00007d55df7e36db  sub rsp, 0xF0
00007d55df7e36e2  vmovaps [rsp], xmm0
00007d55df7e36e7  vmovaps [rsp+0x10], xmm1
00007d55df7e36ed  vmovaps [rsp+0x20], xmm2
00007d55df7e36f3  vmovaps [rsp+0x30], xmm3
00007d55df7e36f9  vmovaps [rsp+0x40], xmm4
00007d55df7e36ff  vmovaps [rsp+0x50], xmm5
00007d55df7e3705  vmovaps [rsp+0x60], xmm6
00007d55df7e370b  vmovaps [rsp+0x70], xmm7
00007d55df7e3711  vmovaps [rsp+0x80], xmm8
00007d55df7e371a  vmovaps [rsp+0x90], xmm9
00007d55df7e3723  vmovaps [rsp+0xA0], xmm10
00007d55df7e372c  vmovaps [rsp+0xB0], xmm11
00007d55df7e3735  vmovaps [rsp+0xC0], xmm13
00007d55df7e373e  vmovaps [rsp+0xD0], xmm14
00007d55df7e3747  vmovaps [rsp+0xE0], xmm15
00007d55df7e3750  sub rsp, 0x30
00007d55df7e3754  movaps [rsp], xmm12
00007d55df7e3759  movaps [rsp+0x10], xmm7
00007d55df7e375e  movaps [rsp+0x20], xmm13
00007d55df7e3764  lea rdi, [rsp]
00007d55df7e3768  mov esi, 0x00
00007d55df7e376d  mov rax, 0x5BB8433D8530
00007d55df7e3777  call rax
00007d55df7e3779  movaps xmm12, [rsp]
00007d55df7e377e  add rsp, 0x30
00007d55df7e3782  vmovaps xmm0, [rsp]
00007d55df7e3787  vmovaps xmm1, [rsp+0x10]
00007d55df7e378d  vmovaps xmm2, [rsp+0x20]
00007d55df7e3793  vmovaps xmm3, [rsp+0x30]
00007d55df7e3799  vmovaps xmm4, [rsp+0x40]
00007d55df7e379f  vmovaps xmm5, [rsp+0x50]
00007d55df7e37a5  vmovaps xmm6, [rsp+0x60]
00007d55df7e37ab  vmovaps xmm7, [rsp+0x70]
00007d55df7e37b1  vmovaps xmm8, [rsp+0x80]
00007d55df7e37ba  vmovaps xmm9, [rsp+0x90]
00007d55df7e37c3  vmovaps xmm10, [rsp+0xA0]
00007d55df7e37cc  vmovaps xmm11, [rsp+0xB0]
00007d55df7e37d5  vmovaps xmm13, [rsp+0xC0]
00007d55df7e37de  vmovaps xmm14, [rsp+0xD0]
00007d55df7e37e7  vmovaps xmm15, [rsp+0xE0]
00007d55df7e37f0  add rsp, 0xF0
00007d55df7e37f7  pop r11
00007d55df7e37f9  pop r10
00007d55df7e37fb  pop r9
00007d55df7e37fd  pop r8
00007d55df7e37ff  pop rsi
00007d55df7e3800  pop rdi
00007d55df7e3801  pop rdx
00007d55df7e3802  pop rcx
00007d55df7e3803  pop rax
00007d55df7e3804  add rsp, 0x08
00007d55df7e3808  jmp 0x00007D55DF7DF7D4
00007d55df7e380d  sub rsp, 0x08
00007d55df7e3811  push rax
00007d55df7e3812  push rcx
00007d55df7e3813  push rdx
00007d55df7e3814  push rdi
00007d55df7e3815  push rsi
00007d55df7e3816  push r8
00007d55df7e3818  push r9
00007d55df7e381a  push r10
00007d55df7e381c  push r11
00007d55df7e381e  sub rsp, 0xF0
00007d55df7e3825  vmovaps [rsp], xmm0
00007d55df7e382a  vmovaps [rsp+0x10], xmm1
00007d55df7e3830  vmovaps [rsp+0x20], xmm2
00007d55df7e3836  vmovaps [rsp+0x30], xmm3
00007d55df7e383c  vmovaps [rsp+0x40], xmm4
00007d55df7e3842  vmovaps [rsp+0x50], xmm5
00007d55df7e3848  vmovaps [rsp+0x60], xmm6
00007d55df7e384e  vmovaps [rsp+0x70], xmm7
00007d55df7e3854  vmovaps [rsp+0x80], xmm8
00007d55df7e385d  vmovaps [rsp+0x90], xmm9
00007d55df7e3866  vmovaps [rsp+0xA0], xmm10
00007d55df7e386f  vmovaps [rsp+0xB0], xmm11
00007d55df7e3878  vmovaps [rsp+0xC0], xmm12
00007d55df7e3881  vmovaps [rsp+0xD0], xmm14
00007d55df7e388a  vmovaps [rsp+0xE0], xmm15
00007d55df7e3893  sub rsp, 0x30
00007d55df7e3897  movaps [rsp], xmm13
00007d55df7e389c  movaps [rsp+0x10], xmm15
00007d55df7e38a2  movaps [rsp+0x20], xmm8
00007d55df7e38a8  lea rdi, [rsp]
00007d55df7e38ac  mov esi, 0x00
00007d55df7e38b1  mov rax, 0x5BB8433D8530
00007d55df7e38bb  call rax
00007d55df7e38bd  movaps xmm13, [rsp]
00007d55df7e38c2  add rsp, 0x30
00007d55df7e38c6  vmovaps xmm0, [rsp]
00007d55df7e38cb  vmovaps xmm1, [rsp+0x10]
00007d55df7e38d1  vmovaps xmm2, [rsp+0x20]
00007d55df7e38d7  vmovaps xmm3, [rsp+0x30]
00007d55df7e38dd  vmovaps xmm4, [rsp+0x40]
00007d55df7e38e3  vmovaps xmm5, [rsp+0x50]
00007d55df7e38e9  vmovaps xmm6, [rsp+0x60]
00007d55df7e38ef  vmovaps xmm7, [rsp+0x70]
00007d55df7e38f5  vmovaps xmm8, [rsp+0x80]
00007d55df7e38fe  vmovaps xmm9, [rsp+0x90]
00007d55df7e3907  vmovaps xmm10, [rsp+0xA0]
00007d55df7e3910  vmovaps xmm11, [rsp+0xB0]
00007d55df7e3919  vmovaps xmm12, [rsp+0xC0]
00007d55df7e3922  vmovaps xmm14, [rsp+0xD0]
00007d55df7e392b  vmovaps xmm15, [rsp+0xE0]
00007d55df7e3934  add rsp, 0xF0
00007d55df7e393b  pop r11
00007d55df7e393d  pop r10
00007d55df7e393f  pop r9
00007d55df7e3941  pop r8
00007d55df7e3943  pop rsi
00007d55df7e3944  pop rdi
00007d55df7e3945  pop rdx
00007d55df7e3946  pop rcx
00007d55df7e3947  pop rax
00007d55df7e3948  add rsp, 0x08
00007d55df7e394c  jmp 0x00007D55DF7DF7EF
00007d55df7e3951  sub rsp, 0x08
00007d55df7e3955  push rax
00007d55df7e3956  push rcx
00007d55df7e3957  push rdx
00007d55df7e3958  push rdi
00007d55df7e3959  push rsi
00007d55df7e395a  push r8
00007d55df7e395c  push r9
00007d55df7e395e  push r10
00007d55df7e3960  push r11
00007d55df7e3962  sub rsp, 0xF0
00007d55df7e3969  vmovaps [rsp], xmm0
00007d55df7e396e  vmovaps [rsp+0x10], xmm1
00007d55df7e3974  vmovaps [rsp+0x20], xmm2
00007d55df7e397a  vmovaps [rsp+0x30], xmm3
00007d55df7e3980  vmovaps [rsp+0x40], xmm4
00007d55df7e3986  vmovaps [rsp+0x50], xmm5
00007d55df7e398c  vmovaps [rsp+0x60], xmm6
00007d55df7e3992  vmovaps [rsp+0x70], xmm7
00007d55df7e3998  vmovaps [rsp+0x80], xmm9
00007d55df7e39a1  vmovaps [rsp+0x90], xmm10
00007d55df7e39aa  vmovaps [rsp+0xA0], xmm11
00007d55df7e39b3  vmovaps [rsp+0xB0], xmm12
00007d55df7e39bc  vmovaps [rsp+0xC0], xmm13
00007d55df7e39c5  vmovaps [rsp+0xD0], xmm14
00007d55df7e39ce  vmovaps [rsp+0xE0], xmm15
00007d55df7e39d7  sub rsp, 0x30
00007d55df7e39db  movaps [rsp], xmm8
00007d55df7e39e0  movaps [rsp+0x10], xmm15
00007d55df7e39e6  movaps [rsp+0x20], xmm9
00007d55df7e39ec  lea rdi, [rsp]
00007d55df7e39f0  mov esi, 0x00
00007d55df7e39f5  mov rax, 0x5BB8433D8530
00007d55df7e39ff  call rax
00007d55df7e3a01  movaps xmm8, [rsp]
00007d55df7e3a06  add rsp, 0x30
00007d55df7e3a0a  vmovaps xmm0, [rsp]
00007d55df7e3a0f  vmovaps xmm1, [rsp+0x10]
00007d55df7e3a15  vmovaps xmm2, [rsp+0x20]
00007d55df7e3a1b  vmovaps xmm3, [rsp+0x30]
00007d55df7e3a21  vmovaps xmm4, [rsp+0x40]
00007d55df7e3a27  vmovaps xmm5, [rsp+0x50]
00007d55df7e3a2d  vmovaps xmm6, [rsp+0x60]
00007d55df7e3a33  vmovaps xmm7, [rsp+0x70]
00007d55df7e3a39  vmovaps xmm9, [rsp+0x80]
00007d55df7e3a42  vmovaps xmm10, [rsp+0x90]
00007d55df7e3a4b  vmovaps xmm11, [rsp+0xA0]
00007d55df7e3a54  vmovaps xmm12, [rsp+0xB0]
00007d55df7e3a5d  vmovaps xmm13, [rsp+0xC0]
00007d55df7e3a66  vmovaps xmm14, [rsp+0xD0]
00007d55df7e3a6f  vmovaps xmm15, [rsp+0xE0]
00007d55df7e3a78  add rsp, 0xF0
00007d55df7e3a7f  pop r11
00007d55df7e3a81  pop r10
00007d55df7e3a83  pop r9
00007d55df7e3a85  pop r8
00007d55df7e3a87  pop rsi
00007d55df7e3a88  pop rdi
00007d55df7e3a89  pop rdx
00007d55df7e3a8a  pop rcx
00007d55df7e3a8b  pop rax
00007d55df7e3a8c  add rsp, 0x08
00007d55df7e3a90  jmp 0x00007D55DF7DF81D
00007d55df7e3a95  sub rsp, 0x08
00007d55df7e3a99  push rax
00007d55df7e3a9a  push rcx
00007d55df7e3a9b  push rdx
00007d55df7e3a9c  push rdi
00007d55df7e3a9d  push rsi
00007d55df7e3a9e  push r8
00007d55df7e3aa0  push r9
00007d55df7e3aa2  push r10
00007d55df7e3aa4  push r11
00007d55df7e3aa6  sub rsp, 0xF0
00007d55df7e3aad  vmovaps [rsp], xmm0
00007d55df7e3ab2  vmovaps [rsp+0x10], xmm1
00007d55df7e3ab8  vmovaps [rsp+0x20], xmm2
00007d55df7e3abe  vmovaps [rsp+0x30], xmm3
00007d55df7e3ac4  vmovaps [rsp+0x40], xmm4
00007d55df7e3aca  vmovaps [rsp+0x50], xmm5
00007d55df7e3ad0  vmovaps [rsp+0x60], xmm6
00007d55df7e3ad6  vmovaps [rsp+0x70], xmm7
00007d55df7e3adc  vmovaps [rsp+0x80], xmm8
00007d55df7e3ae5  vmovaps [rsp+0x90], xmm9
00007d55df7e3aee  vmovaps [rsp+0xA0], xmm10
00007d55df7e3af7  vmovaps [rsp+0xB0], xmm11
00007d55df7e3b00  vmovaps [rsp+0xC0], xmm12
00007d55df7e3b09  vmovaps [rsp+0xD0], xmm13
00007d55df7e3b12  vmovaps [rsp+0xE0], xmm14
00007d55df7e3b1b  sub rsp, 0x30
00007d55df7e3b1f  movaps [rsp], xmm15
00007d55df7e3b24  movaps [rsp+0x10], xmm11
00007d55df7e3b2a  movaps [rsp+0x20], xmm6
00007d55df7e3b2f  lea rdi, [rsp]
00007d55df7e3b33  mov esi, 0x00
00007d55df7e3b38  mov rax, 0x5BB8433D8530
00007d55df7e3b42  call rax
00007d55df7e3b44  movaps xmm15, [rsp]
00007d55df7e3b49  add rsp, 0x30
00007d55df7e3b4d  vmovaps xmm0, [rsp]
00007d55df7e3b52  vmovaps xmm1, [rsp+0x10]
00007d55df7e3b58  vmovaps xmm2, [rsp+0x20]
00007d55df7e3b5e  vmovaps xmm3, [rsp+0x30]
00007d55df7e3b64  vmovaps xmm4, [rsp+0x40]
00007d55df7e3b6a  vmovaps xmm5, [rsp+0x50]
00007d55df7e3b70  vmovaps xmm6, [rsp+0x60]
00007d55df7e3b76  vmovaps xmm7, [rsp+0x70]
00007d55df7e3b7c  vmovaps xmm8, [rsp+0x80]
00007d55df7e3b85  vmovaps xmm9, [rsp+0x90]
00007d55df7e3b8e  vmovaps xmm10, [rsp+0xA0]
00007d55df7e3b97  vmovaps xmm11, [rsp+0xB0]
00007d55df7e3ba0  vmovaps xmm12, [rsp+0xC0]
00007d55df7e3ba9  vmovaps xmm13, [rsp+0xD0]
00007d55df7e3bb2  vmovaps xmm14, [rsp+0xE0]
00007d55df7e3bbb  add rsp, 0xF0
00007d55df7e3bc2  pop r11
00007d55df7e3bc4  pop r10
00007d55df7e3bc6  pop r9
00007d55df7e3bc8  pop r8
00007d55df7e3bca  pop rsi
00007d55df7e3bcb  pop rdi
00007d55df7e3bcc  pop rdx
00007d55df7e3bcd  pop rcx
00007d55df7e3bce  pop rax
00007d55df7e3bcf  add rsp, 0x08
00007d55df7e3bd3  jmp 0x00007D55DF7DF838
00007d55df7e3bd8  sub rsp, 0x08
00007d55df7e3bdc  push rax
00007d55df7e3bdd  push rcx
00007d55df7e3bde  push rdx
00007d55df7e3bdf  push rdi
00007d55df7e3be0  push rsi
00007d55df7e3be1  push r8
00007d55df7e3be3  push r9
00007d55df7e3be5  push r10
00007d55df7e3be7  push r11
00007d55df7e3be9  sub rsp, 0xF0
00007d55df7e3bf0  vmovaps [rsp], xmm0
00007d55df7e3bf5  vmovaps [rsp+0x10], xmm1
00007d55df7e3bfb  vmovaps [rsp+0x20], xmm2
00007d55df7e3c01  vmovaps [rsp+0x30], xmm3
00007d55df7e3c07  vmovaps [rsp+0x40], xmm4
00007d55df7e3c0d  vmovaps [rsp+0x50], xmm5
00007d55df7e3c13  vmovaps [rsp+0x60], xmm6
00007d55df7e3c19  vmovaps [rsp+0x70], xmm8
00007d55df7e3c1f  vmovaps [rsp+0x80], xmm9
00007d55df7e3c28  vmovaps [rsp+0x90], xmm10
00007d55df7e3c31  vmovaps [rsp+0xA0], xmm11
00007d55df7e3c3a  vmovaps [rsp+0xB0], xmm12
00007d55df7e3c43  vmovaps [rsp+0xC0], xmm13
00007d55df7e3c4c  vmovaps [rsp+0xD0], xmm14
00007d55df7e3c55  vmovaps [rsp+0xE0], xmm15
00007d55df7e3c5e  sub rsp, 0x30
00007d55df7e3c62  movaps [rsp], xmm7
00007d55df7e3c66  movaps [rsp+0x10], xmm11
00007d55df7e3c6c  movaps [rsp+0x20], xmm9
00007d55df7e3c72  lea rdi, [rsp]
00007d55df7e3c76  mov esi, 0x00
00007d55df7e3c7b  mov rax, 0x5BB8433D8530
00007d55df7e3c85  call rax
00007d55df7e3c87  movaps xmm7, [rsp]
00007d55df7e3c8b  add rsp, 0x30
00007d55df7e3c8f  vmovaps xmm0, [rsp]
00007d55df7e3c94  vmovaps xmm1, [rsp+0x10]
00007d55df7e3c9a  vmovaps xmm2, [rsp+0x20]
00007d55df7e3ca0  vmovaps xmm3, [rsp+0x30]
00007d55df7e3ca6  vmovaps xmm4, [rsp+0x40]
00007d55df7e3cac  vmovaps xmm5, [rsp+0x50]
00007d55df7e3cb2  vmovaps xmm6, [rsp+0x60]
00007d55df7e3cb8  vmovaps xmm8, [rsp+0x70]
00007d55df7e3cbe  vmovaps xmm9, [rsp+0x80]
00007d55df7e3cc7  vmovaps xmm10, [rsp+0x90]
00007d55df7e3cd0  vmovaps xmm11, [rsp+0xA0]
00007d55df7e3cd9  vmovaps xmm12, [rsp+0xB0]
00007d55df7e3ce2  vmovaps xmm13, [rsp+0xC0]
00007d55df7e3ceb  vmovaps xmm14, [rsp+0xD0]
00007d55df7e3cf4  vmovaps xmm15, [rsp+0xE0]
00007d55df7e3cfd  add rsp, 0xF0
00007d55df7e3d04  pop r11
00007d55df7e3d06  pop r10
00007d55df7e3d08  pop r9
00007d55df7e3d0a  pop r8
00007d55df7e3d0c  pop rsi
00007d55df7e3d0d  pop rdi
00007d55df7e3d0e  pop rdx
00007d55df7e3d0f  pop rcx
00007d55df7e3d10  pop rax
00007d55df7e3d11  add rsp, 0x08
00007d55df7e3d15  jmp 0x00007D55DF7DF865
00007d55df7e3d1a  sub rsp, 0x08
00007d55df7e3d1e  push rax
00007d55df7e3d1f  push rcx
00007d55df7e3d20  push rdx
00007d55df7e3d21  push rdi
00007d55df7e3d22  push rsi
00007d55df7e3d23  push r8
00007d55df7e3d25  push r9
00007d55df7e3d27  push r10
00007d55df7e3d29  push r11
00007d55df7e3d2b  sub rsp, 0xF0
00007d55df7e3d32  vmovaps [rsp], xmm0
00007d55df7e3d37  vmovaps [rsp+0x10], xmm1
00007d55df7e3d3d  vmovaps [rsp+0x20], xmm2
00007d55df7e3d43  vmovaps [rsp+0x30], xmm3
00007d55df7e3d49  vmovaps [rsp+0x40], xmm4
00007d55df7e3d4f  vmovaps [rsp+0x50], xmm5
00007d55df7e3d55  vmovaps [rsp+0x60], xmm6
00007d55df7e3d5b  vmovaps [rsp+0x70], xmm7
00007d55df7e3d61  vmovaps [rsp+0x80], xmm8
00007d55df7e3d6a  vmovaps [rsp+0x90], xmm9
00007d55df7e3d73  vmovaps [rsp+0xA0], xmm10
00007d55df7e3d7c  vmovaps [rsp+0xB0], xmm12
00007d55df7e3d85  vmovaps [rsp+0xC0], xmm13
00007d55df7e3d8e  vmovaps [rsp+0xD0], xmm14
00007d55df7e3d97  vmovaps [rsp+0xE0], xmm15
00007d55df7e3da0  sub rsp, 0x30
00007d55df7e3da4  movaps [rsp], xmm11
00007d55df7e3da9  movaps [rsp+0x10], xmm10
00007d55df7e3daf  movaps [rsp+0x20], xmm14
00007d55df7e3db5  lea rdi, [rsp]
00007d55df7e3db9  mov esi, 0x00
00007d55df7e3dbe  mov rax, 0x5BB8433D8530
00007d55df7e3dc8  call rax
00007d55df7e3dca  movaps xmm11, [rsp]
00007d55df7e3dcf  add rsp, 0x30
00007d55df7e3dd3  vmovaps xmm0, [rsp]
00007d55df7e3dd8  vmovaps xmm1, [rsp+0x10]
00007d55df7e3dde  vmovaps xmm2, [rsp+0x20]
00007d55df7e3de4  vmovaps xmm3, [rsp+0x30]
00007d55df7e3dea  vmovaps xmm4, [rsp+0x40]
00007d55df7e3df0  vmovaps xmm5, [rsp+0x50]
00007d55df7e3df6  vmovaps xmm6, [rsp+0x60]
00007d55df7e3dfc  vmovaps xmm7, [rsp+0x70]
00007d55df7e3e02  vmovaps xmm8, [rsp+0x80]
00007d55df7e3e0b  vmovaps xmm9, [rsp+0x90]
00007d55df7e3e14  vmovaps xmm10, [rsp+0xA0]
00007d55df7e3e1d  vmovaps xmm12, [rsp+0xB0]
00007d55df7e3e26  vmovaps xmm13, [rsp+0xC0]
00007d55df7e3e2f  vmovaps xmm14, [rsp+0xD0]
00007d55df7e3e38  vmovaps xmm15, [rsp+0xE0]
00007d55df7e3e41  add rsp, 0xF0
00007d55df7e3e48  pop r11
00007d55df7e3e4a  pop r10
00007d55df7e3e4c  pop r9
00007d55df7e3e4e  pop r8
00007d55df7e3e50  pop rsi
00007d55df7e3e51  pop rdi
00007d55df7e3e52  pop rdx
00007d55df7e3e53  pop rcx
00007d55df7e3e54  pop rax
00007d55df7e3e55  add rsp, 0x08
00007d55df7e3e59  jmp 0x00007D55DF7DF880
00007d55df7e3e5e  call 0x00007D55DF6C33A0
00007d55df7e3e63  jmp 0x00007D55DF7DF88A
00007d55df7e3e68  sub rsp, 0x08
00007d55df7e3e6c  push rax
00007d55df7e3e6d  push rcx
00007d55df7e3e6e  push rdx
00007d55df7e3e6f  push rdi
00007d55df7e3e70  push rsi
00007d55df7e3e71  push r8
00007d55df7e3e73  push r9
00007d55df7e3e75  push r10
00007d55df7e3e77  push r11
00007d55df7e3e79  sub rsp, 0xF0
00007d55df7e3e80  vmovaps [rsp], xmm0
00007d55df7e3e85  vmovaps [rsp+0x10], xmm1
00007d55df7e3e8b  vmovaps [rsp+0x20], xmm2
00007d55df7e3e91  vmovaps [rsp+0x30], xmm3
00007d55df7e3e97  vmovaps [rsp+0x40], xmm4
00007d55df7e3e9d  vmovaps [rsp+0x50], xmm5
00007d55df7e3ea3  vmovaps [rsp+0x60], xmm6
00007d55df7e3ea9  vmovaps [rsp+0x70], xmm7
00007d55df7e3eaf  vmovaps [rsp+0x80], xmm8
00007d55df7e3eb8  vmovaps [rsp+0x90], xmm9
00007d55df7e3ec1  vmovaps [rsp+0xA0], xmm11
00007d55df7e3eca  vmovaps [rsp+0xB0], xmm12
00007d55df7e3ed3  vmovaps [rsp+0xC0], xmm13
00007d55df7e3edc  vmovaps [rsp+0xD0], xmm14
00007d55df7e3ee5  vmovaps [rsp+0xE0], xmm15
00007d55df7e3eee  sub rsp, 0x30
00007d55df7e3ef2  movaps [rsp], xmm10
00007d55df7e3ef7  movaps [rsp+0x10], xmm1
00007d55df7e3efc  movaps [rsp+0x20], xmm12
00007d55df7e3f02  lea rdi, [rsp]
00007d55df7e3f06  mov esi, 0x00
00007d55df7e3f0b  mov rax, 0x5BB8433D8530
00007d55df7e3f15  call rax
00007d55df7e3f17  movaps xmm10, [rsp]
00007d55df7e3f1c  add rsp, 0x30
00007d55df7e3f20  vmovaps xmm0, [rsp]
00007d55df7e3f25  vmovaps xmm1, [rsp+0x10]
00007d55df7e3f2b  vmovaps xmm2, [rsp+0x20]
00007d55df7e3f31  vmovaps xmm3, [rsp+0x30]
00007d55df7e3f37  vmovaps xmm4, [rsp+0x40]
00007d55df7e3f3d  vmovaps xmm5, [rsp+0x50]
00007d55df7e3f43  vmovaps xmm6, [rsp+0x60]
00007d55df7e3f49  vmovaps xmm7, [rsp+0x70]
00007d55df7e3f4f  vmovaps xmm8, [rsp+0x80]
00007d55df7e3f58  vmovaps xmm9, [rsp+0x90]
00007d55df7e3f61  vmovaps xmm11, [rsp+0xA0]
00007d55df7e3f6a  vmovaps xmm12, [rsp+0xB0]
00007d55df7e3f73  vmovaps xmm13, [rsp+0xC0]
00007d55df7e3f7c  vmovaps xmm14, [rsp+0xD0]
00007d55df7e3f85  vmovaps xmm15, [rsp+0xE0]
00007d55df7e3f8e  add rsp, 0xF0
00007d55df7e3f95  pop r11
00007d55df7e3f97  pop r10
00007d55df7e3f99  pop r9
00007d55df7e3f9b  pop r8
00007d55df7e3f9d  pop rsi
00007d55df7e3f9e  pop rdi
00007d55df7e3f9f  pop rdx
00007d55df7e3fa0  pop rcx
00007d55df7e3fa1  pop rax
00007d55df7e3fa2  add rsp, 0x08
00007d55df7e3fa6  jmp 0x00007D55DF7DF8AD
00007d55df7e3fab  sub rsp, 0x08
00007d55df7e3faf  push rax
00007d55df7e3fb0  push rcx
00007d55df7e3fb1  push rdx
00007d55df7e3fb2  push rdi
00007d55df7e3fb3  push rsi
00007d55df7e3fb4  push r8
00007d55df7e3fb6  push r9
00007d55df7e3fb8  push r10
00007d55df7e3fba  push r11
00007d55df7e3fbc  sub rsp, 0xF0
00007d55df7e3fc3  vmovaps [rsp], xmm0
00007d55df7e3fc8  vmovaps [rsp+0x10], xmm1
00007d55df7e3fce  vmovaps [rsp+0x20], xmm2
00007d55df7e3fd4  vmovaps [rsp+0x30], xmm3
00007d55df7e3fda  vmovaps [rsp+0x40], xmm4
00007d55df7e3fe0  vmovaps [rsp+0x50], xmm5
00007d55df7e3fe6  vmovaps [rsp+0x60], xmm6
00007d55df7e3fec  vmovaps [rsp+0x70], xmm7
00007d55df7e3ff2  vmovaps [rsp+0x80], xmm8
00007d55df7e3ffb  vmovaps [rsp+0x90], xmm9
00007d55df7e4004  vmovaps [rsp+0xA0], xmm10
00007d55df7e400d  vmovaps [rsp+0xB0], xmm11
00007d55df7e4016  vmovaps [rsp+0xC0], xmm13
00007d55df7e401f  vmovaps [rsp+0xD0], xmm14
00007d55df7e4028  vmovaps [rsp+0xE0], xmm15
00007d55df7e4031  sub rsp, 0x30
00007d55df7e4035  movaps [rsp], xmm12
00007d55df7e403a  movaps [rsp+0x10], xmm14
00007d55df7e4040  movaps [rsp+0x20], xmm1
00007d55df7e4045  lea rdi, [rsp]
00007d55df7e4049  mov esi, 0x00
00007d55df7e404e  mov rax, 0x5BB8433D8530
00007d55df7e4058  call rax
00007d55df7e405a  movaps xmm12, [rsp]
00007d55df7e405f  add rsp, 0x30
00007d55df7e4063  vmovaps xmm0, [rsp]
00007d55df7e4068  vmovaps xmm1, [rsp+0x10]
00007d55df7e406e  vmovaps xmm2, [rsp+0x20]
00007d55df7e4074  vmovaps xmm3, [rsp+0x30]
00007d55df7e407a  vmovaps xmm4, [rsp+0x40]
00007d55df7e4080  vmovaps xmm5, [rsp+0x50]
00007d55df7e4086  vmovaps xmm6, [rsp+0x60]
00007d55df7e408c  vmovaps xmm7, [rsp+0x70]
00007d55df7e4092  vmovaps xmm8, [rsp+0x80]
00007d55df7e409b  vmovaps xmm9, [rsp+0x90]
00007d55df7e40a4  vmovaps xmm10, [rsp+0xA0]
00007d55df7e40ad  vmovaps xmm11, [rsp+0xB0]
00007d55df7e40b6  vmovaps xmm13, [rsp+0xC0]
00007d55df7e40bf  vmovaps xmm14, [rsp+0xD0]
00007d55df7e40c8  vmovaps xmm15, [rsp+0xE0]
00007d55df7e40d1  add rsp, 0xF0
00007d55df7e40d8  pop r11
00007d55df7e40da  pop r10
00007d55df7e40dc  pop r9
00007d55df7e40de  pop r8
00007d55df7e40e0  pop rsi
00007d55df7e40e1  pop rdi
00007d55df7e40e2  pop rdx
00007d55df7e40e3  pop rcx
00007d55df7e40e4  pop rax
00007d55df7e40e5  add rsp, 0x08
00007d55df7e40e9  jmp 0x00007D55DF7DF8DC
00007d55df7e40ee  sub rsp, 0x08
00007d55df7e40f2  push rax
00007d55df7e40f3  push rcx
00007d55df7e40f4  push rdx
00007d55df7e40f5  push rdi
00007d55df7e40f6  push rsi
00007d55df7e40f7  push r8
00007d55df7e40f9  push r9
00007d55df7e40fb  push r10
00007d55df7e40fd  push r11
00007d55df7e40ff  sub rsp, 0xF0
00007d55df7e4106  vmovaps [rsp], xmm0
00007d55df7e410b  vmovaps [rsp+0x10], xmm1
00007d55df7e4111  vmovaps [rsp+0x20], xmm2
00007d55df7e4117  vmovaps [rsp+0x30], xmm3
00007d55df7e411d  vmovaps [rsp+0x40], xmm4
00007d55df7e4123  vmovaps [rsp+0x50], xmm5
00007d55df7e4129  vmovaps [rsp+0x60], xmm6
00007d55df7e412f  vmovaps [rsp+0x70], xmm7
00007d55df7e4135  vmovaps [rsp+0x80], xmm8
00007d55df7e413e  vmovaps [rsp+0x90], xmm9
00007d55df7e4147  vmovaps [rsp+0xA0], xmm10
00007d55df7e4150  vmovaps [rsp+0xB0], xmm11
00007d55df7e4159  vmovaps [rsp+0xC0], xmm12
00007d55df7e4162  vmovaps [rsp+0xD0], xmm13
00007d55df7e416b  vmovaps [rsp+0xE0], xmm15
00007d55df7e4174  sub rsp, 0x30
00007d55df7e4178  movaps [rsp], xmm14
00007d55df7e417d  movaps [rsp+0x10], xmm9
00007d55df7e4183  movaps [rsp+0x20], xmm1
00007d55df7e4188  lea rdi, [rsp]
00007d55df7e418c  mov esi, 0x00
00007d55df7e4191  mov rax, 0x5BB8433D8530
00007d55df7e419b  call rax
00007d55df7e419d  movaps xmm14, [rsp]
00007d55df7e41a2  add rsp, 0x30
00007d55df7e41a6  vmovaps xmm0, [rsp]
00007d55df7e41ab  vmovaps xmm1, [rsp+0x10]
00007d55df7e41b1  vmovaps xmm2, [rsp+0x20]
00007d55df7e41b7  vmovaps xmm3, [rsp+0x30]
00007d55df7e41bd  vmovaps xmm4, [rsp+0x40]
00007d55df7e41c3  vmovaps xmm5, [rsp+0x50]
00007d55df7e41c9  vmovaps xmm6, [rsp+0x60]
00007d55df7e41cf  vmovaps xmm7, [rsp+0x70]
00007d55df7e41d5  vmovaps xmm8, [rsp+0x80]
00007d55df7e41de  vmovaps xmm9, [rsp+0x90]
00007d55df7e41e7  vmovaps xmm10, [rsp+0xA0]
00007d55df7e41f0  vmovaps xmm11, [rsp+0xB0]
00007d55df7e41f9  vmovaps xmm12, [rsp+0xC0]
00007d55df7e4202  vmovaps xmm13, [rsp+0xD0]
00007d55df7e420b  vmovaps xmm15, [rsp+0xE0]
00007d55df7e4214  add rsp, 0xF0
00007d55df7e421b  pop r11
00007d55df7e421d  pop r10
00007d55df7e421f  pop r9
00007d55df7e4221  pop r8
00007d55df7e4223  pop rsi
00007d55df7e4224  pop rdi
00007d55df7e4225  pop rdx
00007d55df7e4226  pop rcx
00007d55df7e4227  pop rax
00007d55df7e4228  add rsp, 0x08
00007d55df7e422c  jmp 0x00007D55DF7DF90B
00007d55df7e4231  sub rsp, 0x08
00007d55df7e4235  push rax
00007d55df7e4236  push rcx
00007d55df7e4237  push rdx
00007d55df7e4238  push rdi
00007d55df7e4239  push rsi
00007d55df7e423a  push r8
00007d55df7e423c  push r9
00007d55df7e423e  push r10
00007d55df7e4240  push r11
00007d55df7e4242  sub rsp, 0xF0
00007d55df7e4249  vmovaps [rsp], xmm0
00007d55df7e424e  vmovaps [rsp+0x10], xmm2
00007d55df7e4254  vmovaps [rsp+0x20], xmm3
00007d55df7e425a  vmovaps [rsp+0x30], xmm4
00007d55df7e4260  vmovaps [rsp+0x40], xmm5
00007d55df7e4266  vmovaps [rsp+0x50], xmm6
00007d55df7e426c  vmovaps [rsp+0x60], xmm7
00007d55df7e4272  vmovaps [rsp+0x70], xmm8
00007d55df7e4278  vmovaps [rsp+0x80], xmm9
00007d55df7e4281  vmovaps [rsp+0x90], xmm10
00007d55df7e428a  vmovaps [rsp+0xA0], xmm11
00007d55df7e4293  vmovaps [rsp+0xB0], xmm12
00007d55df7e429c  vmovaps [rsp+0xC0], xmm13
00007d55df7e42a5  vmovaps [rsp+0xD0], xmm14
00007d55df7e42ae  vmovaps [rsp+0xE0], xmm15
00007d55df7e42b7  sub rsp, 0x30
00007d55df7e42bb  movaps [rsp], xmm1
00007d55df7e42bf  movaps [rsp+0x10], xmm13
00007d55df7e42c5  movaps [rsp+0x20], xmm8
00007d55df7e42cb  lea rdi, [rsp]
00007d55df7e42cf  mov esi, 0x00
00007d55df7e42d4  mov rax, 0x5BB8433D8530
00007d55df7e42de  call rax
00007d55df7e42e0  movaps xmm1, [rsp]
00007d55df7e42e4  add rsp, 0x30
00007d55df7e42e8  vmovaps xmm0, [rsp]
00007d55df7e42ed  vmovaps xmm2, [rsp+0x10]
00007d55df7e42f3  vmovaps xmm3, [rsp+0x20]
00007d55df7e42f9  vmovaps xmm4, [rsp+0x30]
00007d55df7e42ff  vmovaps xmm5, [rsp+0x40]
00007d55df7e4305  vmovaps xmm6, [rsp+0x50]
00007d55df7e430b  vmovaps xmm7, [rsp+0x60]
00007d55df7e4311  vmovaps xmm8, [rsp+0x70]
00007d55df7e4317  vmovaps xmm9, [rsp+0x80]
00007d55df7e4320  vmovaps xmm10, [rsp+0x90]
00007d55df7e4329  vmovaps xmm11, [rsp+0xA0]
00007d55df7e4332  vmovaps xmm12, [rsp+0xB0]
00007d55df7e433b  vmovaps xmm13, [rsp+0xC0]
00007d55df7e4344  vmovaps xmm14, [rsp+0xD0]
00007d55df7e434d  vmovaps xmm15, [rsp+0xE0]
00007d55df7e4356  add rsp, 0xF0
00007d55df7e435d  pop r11
00007d55df7e435f  pop r10
00007d55df7e4361  pop r9
00007d55df7e4363  pop r8
00007d55df7e4365  pop rsi
00007d55df7e4366  pop rdi
00007d55df7e4367  pop rdx
00007d55df7e4368  pop rcx
00007d55df7e4369  pop rax
00007d55df7e436a  add rsp, 0x08
00007d55df7e436e  jmp 0x00007D55DF7DF92D
00007d55df7e4373  call 0x00007D55DF60C260
00007d55df7e4378  jmp 0x00007D55DF7DF93B
00007d55df7e437d  call 0x00007D55DF6BD750
00007d55df7e4382  jmp 0x00007D55DF7DF945
00007d55df7e4387  sub rsp, 0x08
00007d55df7e438b  push rax
00007d55df7e438c  push rcx
00007d55df7e438d  push rdx
00007d55df7e438e  push rdi
00007d55df7e438f  push rsi
00007d55df7e4390  push r8
00007d55df7e4392  push r9
00007d55df7e4394  push r10
00007d55df7e4396  push r11
00007d55df7e4398  sub rsp, 0xF0
00007d55df7e439f  vmovaps [rsp], xmm0
00007d55df7e43a4  vmovaps [rsp+0x10], xmm1
00007d55df7e43aa  vmovaps [rsp+0x20], xmm2
00007d55df7e43b0  vmovaps [rsp+0x30], xmm3
00007d55df7e43b6  vmovaps [rsp+0x40], xmm4
00007d55df7e43bc  vmovaps [rsp+0x50], xmm5
00007d55df7e43c2  vmovaps [rsp+0x60], xmm6
00007d55df7e43c8  vmovaps [rsp+0x70], xmm7
00007d55df7e43ce  vmovaps [rsp+0x80], xmm9
00007d55df7e43d7  vmovaps [rsp+0x90], xmm10
00007d55df7e43e0  vmovaps [rsp+0xA0], xmm11
00007d55df7e43e9  vmovaps [rsp+0xB0], xmm12
00007d55df7e43f2  vmovaps [rsp+0xC0], xmm13
00007d55df7e43fb  vmovaps [rsp+0xD0], xmm14
00007d55df7e4404  vmovaps [rsp+0xE0], xmm15
00007d55df7e440d  sub rsp, 0x30
00007d55df7e4411  movaps [rsp], xmm8
00007d55df7e4416  movaps [rsp+0x10], xmm15
00007d55df7e441c  movaps [rsp+0x20], xmm7
00007d55df7e4421  lea rdi, [rsp]
00007d55df7e4425  mov esi, 0x00
00007d55df7e442a  mov rax, 0x5BB8433D8530
00007d55df7e4434  call rax
00007d55df7e4436  movaps xmm8, [rsp]
00007d55df7e443b  add rsp, 0x30
00007d55df7e443f  vmovaps xmm0, [rsp]
00007d55df7e4444  vmovaps xmm1, [rsp+0x10]
00007d55df7e444a  vmovaps xmm2, [rsp+0x20]
00007d55df7e4450  vmovaps xmm3, [rsp+0x30]
00007d55df7e4456  vmovaps xmm4, [rsp+0x40]
00007d55df7e445c  vmovaps xmm5, [rsp+0x50]
00007d55df7e4462  vmovaps xmm6, [rsp+0x60]
00007d55df7e4468  vmovaps xmm7, [rsp+0x70]
00007d55df7e446e  vmovaps xmm9, [rsp+0x80]
00007d55df7e4477  vmovaps xmm10, [rsp+0x90]
00007d55df7e4480  vmovaps xmm11, [rsp+0xA0]
00007d55df7e4489  vmovaps xmm12, [rsp+0xB0]
00007d55df7e4492  vmovaps xmm13, [rsp+0xC0]
00007d55df7e449b  vmovaps xmm14, [rsp+0xD0]
00007d55df7e44a4  vmovaps xmm15, [rsp+0xE0]
00007d55df7e44ad  add rsp, 0xF0
00007d55df7e44b4  pop r11
00007d55df7e44b6  pop r10
00007d55df7e44b8  pop r9
00007d55df7e44ba  pop r8
00007d55df7e44bc  pop rsi
00007d55df7e44bd  pop rdi
00007d55df7e44be  pop rdx
00007d55df7e44bf  pop rcx
00007d55df7e44c0  pop rax
00007d55df7e44c1  add rsp, 0x08
00007d55df7e44c5  jmp 0x00007D55DF7DF967
00007d55df7e44ca  sub rsp, 0x08
00007d55df7e44ce  push rax
00007d55df7e44cf  push rcx
00007d55df7e44d0  push rdx
00007d55df7e44d1  push rdi
00007d55df7e44d2  push rsi
00007d55df7e44d3  push r8
00007d55df7e44d5  push r9
00007d55df7e44d7  push r10
00007d55df7e44d9  push r11
00007d55df7e44db  sub rsp, 0xF0
00007d55df7e44e2  vmovaps [rsp], xmm0
00007d55df7e44e7  vmovaps [rsp+0x10], xmm1
00007d55df7e44ed  vmovaps [rsp+0x20], xmm2
00007d55df7e44f3  vmovaps [rsp+0x30], xmm3
00007d55df7e44f9  vmovaps [rsp+0x40], xmm4
00007d55df7e44ff  vmovaps [rsp+0x50], xmm5
00007d55df7e4505  vmovaps [rsp+0x60], xmm6
00007d55df7e450b  vmovaps [rsp+0x70], xmm8
00007d55df7e4511  vmovaps [rsp+0x80], xmm9
00007d55df7e451a  vmovaps [rsp+0x90], xmm10
00007d55df7e4523  vmovaps [rsp+0xA0], xmm11
00007d55df7e452c  vmovaps [rsp+0xB0], xmm12
00007d55df7e4535  vmovaps [rsp+0xC0], xmm13
00007d55df7e453e  vmovaps [rsp+0xD0], xmm14
00007d55df7e4547  vmovaps [rsp+0xE0], xmm15
00007d55df7e4550  sub rsp, 0x30
00007d55df7e4554  movaps [rsp], xmm7
00007d55df7e4558  movaps [rsp+0x10], xmm9
00007d55df7e455e  movaps [rsp+0x20], xmm15
00007d55df7e4564  lea rdi, [rsp]
00007d55df7e4568  mov esi, 0x00
00007d55df7e456d  mov rax, 0x5BB8433D8530
00007d55df7e4577  call rax
00007d55df7e4579  movaps xmm7, [rsp]
00007d55df7e457d  add rsp, 0x30
00007d55df7e4581  vmovaps xmm0, [rsp]
00007d55df7e4586  vmovaps xmm1, [rsp+0x10]
00007d55df7e458c  vmovaps xmm2, [rsp+0x20]
00007d55df7e4592  vmovaps xmm3, [rsp+0x30]
00007d55df7e4598  vmovaps xmm4, [rsp+0x40]
00007d55df7e459e  vmovaps xmm5, [rsp+0x50]
00007d55df7e45a4  vmovaps xmm6, [rsp+0x60]
00007d55df7e45aa  vmovaps xmm8, [rsp+0x70]
00007d55df7e45b0  vmovaps xmm9, [rsp+0x80]
00007d55df7e45b9  vmovaps xmm10, [rsp+0x90]
00007d55df7e45c2  vmovaps xmm11, [rsp+0xA0]
00007d55df7e45cb  vmovaps xmm12, [rsp+0xB0]
00007d55df7e45d4  vmovaps xmm13, [rsp+0xC0]
00007d55df7e45dd  vmovaps xmm14, [rsp+0xD0]
00007d55df7e45e6  vmovaps xmm15, [rsp+0xE0]
00007d55df7e45ef  add rsp, 0xF0
00007d55df7e45f6  pop r11
00007d55df7e45f8  pop r10
00007d55df7e45fa  pop r9
00007d55df7e45fc  pop r8
00007d55df7e45fe  pop rsi
00007d55df7e45ff  pop rdi
00007d55df7e4600  pop rdx
00007d55df7e4601  pop rcx
00007d55df7e4602  pop rax
00007d55df7e4603  add rsp, 0x08
00007d55df7e4607  jmp 0x00007D55DF7DF994
00007d55df7e460c  sub rsp, 0x08
00007d55df7e4610  push rax
00007d55df7e4611  push rcx
00007d55df7e4612  push rdx
00007d55df7e4613  push rdi
00007d55df7e4614  push rsi
00007d55df7e4615  push r8
00007d55df7e4617  push r9
00007d55df7e4619  push r10
00007d55df7e461b  push r11
00007d55df7e461d  sub rsp, 0xF0
00007d55df7e4624  vmovaps [rsp], xmm0
00007d55df7e4629  vmovaps [rsp+0x10], xmm1
00007d55df7e462f  vmovaps [rsp+0x20], xmm2
00007d55df7e4635  vmovaps [rsp+0x30], xmm3
00007d55df7e463b  vmovaps [rsp+0x40], xmm4
00007d55df7e4641  vmovaps [rsp+0x50], xmm5
00007d55df7e4647  vmovaps [rsp+0x60], xmm6
00007d55df7e464d  vmovaps [rsp+0x70], xmm7
00007d55df7e4653  vmovaps [rsp+0x80], xmm8
00007d55df7e465c  vmovaps [rsp+0x90], xmm10
00007d55df7e4665  vmovaps [rsp+0xA0], xmm11
00007d55df7e466e  vmovaps [rsp+0xB0], xmm12
00007d55df7e4677  vmovaps [rsp+0xC0], xmm13
00007d55df7e4680  vmovaps [rsp+0xD0], xmm14
00007d55df7e4689  vmovaps [rsp+0xE0], xmm15
00007d55df7e4692  sub rsp, 0x30
00007d55df7e4696  movaps [rsp], xmm9
00007d55df7e469b  movaps [rsp+0x10], xmm13
00007d55df7e46a1  movaps [rsp+0x20], xmm15
00007d55df7e46a7  lea rdi, [rsp]
00007d55df7e46ab  mov esi, 0x00
00007d55df7e46b0  mov rax, 0x5BB8433D8530
00007d55df7e46ba  call rax
00007d55df7e46bc  movaps xmm9, [rsp]
00007d55df7e46c1  add rsp, 0x30
00007d55df7e46c5  vmovaps xmm0, [rsp]
00007d55df7e46ca  vmovaps xmm1, [rsp+0x10]
00007d55df7e46d0  vmovaps xmm2, [rsp+0x20]
00007d55df7e46d6  vmovaps xmm3, [rsp+0x30]
00007d55df7e46dc  vmovaps xmm4, [rsp+0x40]
00007d55df7e46e2  vmovaps xmm5, [rsp+0x50]
00007d55df7e46e8  vmovaps xmm6, [rsp+0x60]
00007d55df7e46ee  vmovaps xmm7, [rsp+0x70]
00007d55df7e46f4  vmovaps xmm8, [rsp+0x80]
00007d55df7e46fd  vmovaps xmm10, [rsp+0x90]
00007d55df7e4706  vmovaps xmm11, [rsp+0xA0]
00007d55df7e470f  vmovaps xmm12, [rsp+0xB0]
00007d55df7e4718  vmovaps xmm13, [rsp+0xC0]
00007d55df7e4721  vmovaps xmm14, [rsp+0xD0]
00007d55df7e472a  vmovaps xmm15, [rsp+0xE0]
00007d55df7e4733  add rsp, 0xF0
00007d55df7e473a  pop r11
00007d55df7e473c  pop r10
00007d55df7e473e  pop r9
00007d55df7e4740  pop r8
00007d55df7e4742  pop rsi
00007d55df7e4743  pop rdi
00007d55df7e4744  pop rdx
00007d55df7e4745  pop rcx
00007d55df7e4746  pop rax
00007d55df7e4747  add rsp, 0x08
00007d55df7e474b  jmp 0x00007D55DF7DF9C2
00007d55df7e4750  sub rsp, 0x08
00007d55df7e4754  push rax
00007d55df7e4755  push rcx
00007d55df7e4756  push rdx
00007d55df7e4757  push rdi
00007d55df7e4758  push rsi
00007d55df7e4759  push r8
00007d55df7e475b  push r9
00007d55df7e475d  push r10
00007d55df7e475f  push r11
00007d55df7e4761  sub rsp, 0xF0
00007d55df7e4768  vmovaps [rsp], xmm0
00007d55df7e476d  vmovaps [rsp+0x10], xmm1
00007d55df7e4773  vmovaps [rsp+0x20], xmm2
00007d55df7e4779  vmovaps [rsp+0x30], xmm3
00007d55df7e477f  vmovaps [rsp+0x40], xmm4
00007d55df7e4785  vmovaps [rsp+0x50], xmm5
00007d55df7e478b  vmovaps [rsp+0x60], xmm6
00007d55df7e4791  vmovaps [rsp+0x70], xmm7
00007d55df7e4797  vmovaps [rsp+0x80], xmm8
00007d55df7e47a0  vmovaps [rsp+0x90], xmm9
00007d55df7e47a9  vmovaps [rsp+0xA0], xmm10
00007d55df7e47b2  vmovaps [rsp+0xB0], xmm11
00007d55df7e47bb  vmovaps [rsp+0xC0], xmm12
00007d55df7e47c4  vmovaps [rsp+0xD0], xmm13
00007d55df7e47cd  vmovaps [rsp+0xE0], xmm14
00007d55df7e47d6  sub rsp, 0x30
00007d55df7e47da  movaps [rsp], xmm15
00007d55df7e47df  movaps [rsp+0x10], xmm11
00007d55df7e47e5  movaps [rsp+0x20], xmm12
00007d55df7e47eb  lea rdi, [rsp]
00007d55df7e47ef  mov esi, 0x00
00007d55df7e47f4  mov rax, 0x5BB8433D8530
00007d55df7e47fe  call rax
00007d55df7e4800  movaps xmm15, [rsp]
00007d55df7e4805  add rsp, 0x30
00007d55df7e4809  vmovaps xmm0, [rsp]
00007d55df7e480e  vmovaps xmm1, [rsp+0x10]
00007d55df7e4814  vmovaps xmm2, [rsp+0x20]
00007d55df7e481a  vmovaps xmm3, [rsp+0x30]
00007d55df7e4820  vmovaps xmm4, [rsp+0x40]
00007d55df7e4826  vmovaps xmm5, [rsp+0x50]
00007d55df7e482c  vmovaps xmm6, [rsp+0x60]
00007d55df7e4832  vmovaps xmm7, [rsp+0x70]
00007d55df7e4838  vmovaps xmm8, [rsp+0x80]
00007d55df7e4841  vmovaps xmm9, [rsp+0x90]
00007d55df7e484a  vmovaps xmm10, [rsp+0xA0]
00007d55df7e4853  vmovaps xmm11, [rsp+0xB0]
00007d55df7e485c  vmovaps xmm12, [rsp+0xC0]
00007d55df7e4865  vmovaps xmm13, [rsp+0xD0]
00007d55df7e486e  vmovaps xmm14, [rsp+0xE0]
00007d55df7e4877  add rsp, 0xF0
00007d55df7e487e  pop r11
00007d55df7e4880  pop r10
00007d55df7e4882  pop r9
00007d55df7e4884  pop r8
00007d55df7e4886  pop rsi
00007d55df7e4887  pop rdi
00007d55df7e4888  pop rdx
00007d55df7e4889  pop rcx
00007d55df7e488a  pop rax
00007d55df7e488b  add rsp, 0x08
00007d55df7e488f  jmp 0x00007D55DF7DF9DD
00007d55df7e4894  sub rsp, 0x08
00007d55df7e4898  push rax
00007d55df7e4899  push rcx
00007d55df7e489a  push rdx
00007d55df7e489b  push rdi
00007d55df7e489c  push rsi
00007d55df7e489d  push r8
00007d55df7e489f  push r9
00007d55df7e48a1  push r10
00007d55df7e48a3  push r11
00007d55df7e48a5  sub rsp, 0xF0
00007d55df7e48ac  vmovaps [rsp], xmm0
00007d55df7e48b1  vmovaps [rsp+0x10], xmm1
00007d55df7e48b7  vmovaps [rsp+0x20], xmm2
00007d55df7e48bd  vmovaps [rsp+0x30], xmm3
00007d55df7e48c3  vmovaps [rsp+0x40], xmm4
00007d55df7e48c9  vmovaps [rsp+0x50], xmm5
00007d55df7e48cf  vmovaps [rsp+0x60], xmm6
00007d55df7e48d5  vmovaps [rsp+0x70], xmm7
00007d55df7e48db  vmovaps [rsp+0x80], xmm8
00007d55df7e48e4  vmovaps [rsp+0x90], xmm9
00007d55df7e48ed  vmovaps [rsp+0xA0], xmm10
00007d55df7e48f6  vmovaps [rsp+0xB0], xmm11
00007d55df7e48ff  vmovaps [rsp+0xC0], xmm12
00007d55df7e4908  vmovaps [rsp+0xD0], xmm14
00007d55df7e4911  vmovaps [rsp+0xE0], xmm15
00007d55df7e491a  sub rsp, 0x30
00007d55df7e491e  movaps [rsp], xmm13
00007d55df7e4923  movaps [rsp+0x10], xmm10
00007d55df7e4929  movaps [rsp+0x20], xmm14
00007d55df7e492f  lea rdi, [rsp]
00007d55df7e4933  mov esi, 0x00
00007d55df7e4938  mov rax, 0x5BB8433D8530
00007d55df7e4942  call rax
00007d55df7e4944  movaps xmm13, [rsp]
00007d55df7e4949  add rsp, 0x30
00007d55df7e494d  vmovaps xmm0, [rsp]
00007d55df7e4952  vmovaps xmm1, [rsp+0x10]
00007d55df7e4958  vmovaps xmm2, [rsp+0x20]
00007d55df7e495e  vmovaps xmm3, [rsp+0x30]
00007d55df7e4964  vmovaps xmm4, [rsp+0x40]
00007d55df7e496a  vmovaps xmm5, [rsp+0x50]
00007d55df7e4970  vmovaps xmm6, [rsp+0x60]
00007d55df7e4976  vmovaps xmm7, [rsp+0x70]
00007d55df7e497c  vmovaps xmm8, [rsp+0x80]
00007d55df7e4985  vmovaps xmm9, [rsp+0x90]
00007d55df7e498e  vmovaps xmm10, [rsp+0xA0]
00007d55df7e4997  vmovaps xmm11, [rsp+0xB0]
00007d55df7e49a0  vmovaps xmm12, [rsp+0xC0]
00007d55df7e49a9  vmovaps xmm14, [rsp+0xD0]
00007d55df7e49b2  vmovaps xmm15, [rsp+0xE0]
00007d55df7e49bb  add rsp, 0xF0
00007d55df7e49c2  pop r11
00007d55df7e49c4  pop r10
00007d55df7e49c6  pop r9
00007d55df7e49c8  pop r8
00007d55df7e49ca  pop rsi
00007d55df7e49cb  pop rdi
00007d55df7e49cc  pop rdx
00007d55df7e49cd  pop rcx
00007d55df7e49ce  pop rax
00007d55df7e49cf  add rsp, 0x08
00007d55df7e49d3  jmp 0x00007D55DF7DFA00
00007d55df7e49d8  sub rsp, 0x08
00007d55df7e49dc  push rax
00007d55df7e49dd  push rcx
00007d55df7e49de  push rdx
00007d55df7e49df  push rdi
00007d55df7e49e0  push rsi
00007d55df7e49e1  push r8
00007d55df7e49e3  push r9
00007d55df7e49e5  push r10
00007d55df7e49e7  push r11
00007d55df7e49e9  sub rsp, 0xF0
00007d55df7e49f0  vmovaps [rsp], xmm0
00007d55df7e49f5  vmovaps [rsp+0x10], xmm1
00007d55df7e49fb  vmovaps [rsp+0x20], xmm2
00007d55df7e4a01  vmovaps [rsp+0x30], xmm3
00007d55df7e4a07  vmovaps [rsp+0x40], xmm4
00007d55df7e4a0d  vmovaps [rsp+0x50], xmm5
00007d55df7e4a13  vmovaps [rsp+0x60], xmm6
00007d55df7e4a19  vmovaps [rsp+0x70], xmm7
00007d55df7e4a1f  vmovaps [rsp+0x80], xmm8
00007d55df7e4a28  vmovaps [rsp+0x90], xmm9
00007d55df7e4a31  vmovaps [rsp+0xA0], xmm10
00007d55df7e4a3a  vmovaps [rsp+0xB0], xmm11
00007d55df7e4a43  vmovaps [rsp+0xC0], xmm12
00007d55df7e4a4c  vmovaps [rsp+0xD0], xmm13
00007d55df7e4a55  vmovaps [rsp+0xE0], xmm15
00007d55df7e4a5e  sub rsp, 0x30
00007d55df7e4a62  movaps [rsp], xmm14
00007d55df7e4a67  movaps [rsp+0x10], xmm1
00007d55df7e4a6c  movaps [rsp+0x20], xmm7
00007d55df7e4a71  lea rdi, [rsp]
00007d55df7e4a75  mov esi, 0x00
00007d55df7e4a7a  mov rax, 0x5BB8433D8530
00007d55df7e4a84  call rax
00007d55df7e4a86  movaps xmm14, [rsp]
00007d55df7e4a8b  add rsp, 0x30
00007d55df7e4a8f  vmovaps xmm0, [rsp]
00007d55df7e4a94  vmovaps xmm1, [rsp+0x10]
00007d55df7e4a9a  vmovaps xmm2, [rsp+0x20]
00007d55df7e4aa0  vmovaps xmm3, [rsp+0x30]
00007d55df7e4aa6  vmovaps xmm4, [rsp+0x40]
00007d55df7e4aac  vmovaps xmm5, [rsp+0x50]
00007d55df7e4ab2  vmovaps xmm6, [rsp+0x60]
00007d55df7e4ab8  vmovaps xmm7, [rsp+0x70]
00007d55df7e4abe  vmovaps xmm8, [rsp+0x80]
00007d55df7e4ac7  vmovaps xmm9, [rsp+0x90]
00007d55df7e4ad0  vmovaps xmm10, [rsp+0xA0]
00007d55df7e4ad9  vmovaps xmm11, [rsp+0xB0]
00007d55df7e4ae2  vmovaps xmm12, [rsp+0xC0]
00007d55df7e4aeb  vmovaps xmm13, [rsp+0xD0]
00007d55df7e4af4  vmovaps xmm15, [rsp+0xE0]
00007d55df7e4afd  add rsp, 0xF0
00007d55df7e4b04  pop r11
00007d55df7e4b06  pop r10
00007d55df7e4b08  pop r9
00007d55df7e4b0a  pop r8
00007d55df7e4b0c  pop rsi
00007d55df7e4b0d  pop rdi
00007d55df7e4b0e  pop rdx
00007d55df7e4b0f  pop rcx
00007d55df7e4b10  pop rax
00007d55df7e4b11  add rsp, 0x08
00007d55df7e4b15  jmp 0x00007D55DF7DFA23
00007d55df7e4b1a  sub rsp, 0x08
00007d55df7e4b1e  push rax
00007d55df7e4b1f  push rcx
00007d55df7e4b20  push rdx
00007d55df7e4b21  push rdi
00007d55df7e4b22  push rsi
00007d55df7e4b23  push r8
00007d55df7e4b25  push r9
00007d55df7e4b27  push r10
00007d55df7e4b29  push r11
00007d55df7e4b2b  sub rsp, 0xF0
00007d55df7e4b32  vmovaps [rsp], xmm0
00007d55df7e4b37  vmovaps [rsp+0x10], xmm2
00007d55df7e4b3d  vmovaps [rsp+0x20], xmm3
00007d55df7e4b43  vmovaps [rsp+0x30], xmm4
00007d55df7e4b49  vmovaps [rsp+0x40], xmm5
00007d55df7e4b4f  vmovaps [rsp+0x50], xmm6
00007d55df7e4b55  vmovaps [rsp+0x60], xmm7
00007d55df7e4b5b  vmovaps [rsp+0x70], xmm8
00007d55df7e4b61  vmovaps [rsp+0x80], xmm9
00007d55df7e4b6a  vmovaps [rsp+0x90], xmm10
00007d55df7e4b73  vmovaps [rsp+0xA0], xmm11
00007d55df7e4b7c  vmovaps [rsp+0xB0], xmm12
00007d55df7e4b85  vmovaps [rsp+0xC0], xmm13
00007d55df7e4b8e  vmovaps [rsp+0xD0], xmm14
00007d55df7e4b97  vmovaps [rsp+0xE0], xmm15
00007d55df7e4ba0  sub rsp, 0x30
00007d55df7e4ba4  movaps [rsp], xmm1
00007d55df7e4ba8  movaps [rsp+0x10], xmm8
00007d55df7e4bae  movaps [rsp+0x20], xmm9
00007d55df7e4bb4  lea rdi, [rsp]
00007d55df7e4bb8  mov esi, 0x00
00007d55df7e4bbd  mov rax, 0x5BB8433D8530
00007d55df7e4bc7  call rax
00007d55df7e4bc9  movaps xmm1, [rsp]
00007d55df7e4bcd  add rsp, 0x30
00007d55df7e4bd1  vmovaps xmm0, [rsp]
00007d55df7e4bd6  vmovaps xmm2, [rsp+0x10]
00007d55df7e4bdc  vmovaps xmm3, [rsp+0x20]
00007d55df7e4be2  vmovaps xmm4, [rsp+0x30]
00007d55df7e4be8  vmovaps xmm5, [rsp+0x40]
00007d55df7e4bee  vmovaps xmm6, [rsp+0x50]
00007d55df7e4bf4  vmovaps xmm7, [rsp+0x60]
00007d55df7e4bfa  vmovaps xmm8, [rsp+0x70]
00007d55df7e4c00  vmovaps xmm9, [rsp+0x80]
00007d55df7e4c09  vmovaps xmm10, [rsp+0x90]
00007d55df7e4c12  vmovaps xmm11, [rsp+0xA0]
00007d55df7e4c1b  vmovaps xmm12, [rsp+0xB0]
00007d55df7e4c24  vmovaps xmm13, [rsp+0xC0]
00007d55df7e4c2d  vmovaps xmm14, [rsp+0xD0]
00007d55df7e4c36  vmovaps xmm15, [rsp+0xE0]
00007d55df7e4c3f  add rsp, 0xF0
00007d55df7e4c46  pop r11
00007d55df7e4c48  pop r10
00007d55df7e4c4a  pop r9
00007d55df7e4c4c  pop r8
00007d55df7e4c4e  pop rsi
00007d55df7e4c4f  pop rdi
00007d55df7e4c50  pop rdx
00007d55df7e4c51  pop rcx
00007d55df7e4c52  pop rax
00007d55df7e4c53  add rsp, 0x08
00007d55df7e4c57  jmp 0x00007D55DF7DFA45
00007d55df7e4c5c  call 0x00007D55DF6E5940
00007d55df7e4c61  jmp 0x00007D55DF7DFA53
00007d55df7e4c66  call 0x00007D55DF60C380
00007d55df7e4c6b  jmp 0x00007D55DF7DFA5D
00007d55df7e4c70  call 0x00007D55DF60D600
00007d55df7e4c75  jmp 0x00007D55DF7DFA67
00007d55df7e4c7a  call 0x00007D55DF5FF540
00007d55df7e4c7f  jmp 0x00007D55DF7DFA71
00007d55df7e4c84  int3
00007d55df7e4c85  nop [rax+rax*1], ax
00007d55df7e4c8e  nop
00007d55df7e4c90  mov qword ptr [r15+0x40], 0x430000
00007d55df7e4c98  mov eax, 0x430CC0
00007d55df7e4c9d  mov r14, [r13+rax*1]
00007d55df7e4ca2  movq xmm1, r14
00007d55df7e4ca7  mov rax, [r15+0x50]
00007d55df7e4cab  movups xmm15, [r13+rax*1]
00007d55df7e4cb1  movaps [r15+0x120], xmm15
00007d55df7e4cb9  mov qword ptr [r15+0x48], 0x10
00007d55df7e4cc1  xor eax, eax
00007d55df7e4cc3  mov r14d, 0x10
00007d55df7e4cc9  mov r12d, 0x200
00007d55df7e4ccf  cmp r14, r12
00007d55df7e4cd2  cmc
00007d55df7e4cd3  lahf
00007d55df7e4cd4  seto al
00007d55df7e4cd7  mov [r15+0x108], eax
00007d55df7e4cde  pextrq rax, xmm15, 0x01
00007d55df7e4ce5  movq xmm14, rax
00007d55df7e4cea  movaps [r15+0x130], xmm14
00007d55df7e4cf2  movq rax, xmm1
00007d55df7e4cf7  movq r14, xmm15
00007d55df7e4cfc  vmovq xmm1, rax
00007d55df7e4d01  vmovq xmm15, r14
00007d55df7e4d06  movaps xmm13, xmm1
00007d55df7e4d0a  addsd xmm13, xmm15
00007d55df7e4d0f  ucomisd xmm13, xmm13
00007d55df7e4d14  jp 0x00007D55DF7E4DD3
00007d55df7e4d1a  movq xmm13, xmm13
00007d55df7e4d1f  movq rax, xmm13
00007d55df7e4d24  movq r14, xmm14
00007d55df7e4d29  vmovq xmm1, rax
00007d55df7e4d2e  vmovq xmm15, r14
00007d55df7e4d33  movaps xmm14, xmm1
00007d55df7e4d37  addsd xmm14, xmm15
00007d55df7e4d3c  ucomisd xmm14, xmm14
00007d55df7e4d41  jp 0x00007D55DF7E4E1B
00007d55df7e4d47  movq xmm14, xmm14
00007d55df7e4d4c  movaps [r15+0x110], xmm14
00007d55df7e4d54  mov eax, [r15+0x108]
00007d55df7e4d5b  sahf
00007d55df7e4d5c  jnz 0x00007D55DF7E4D8E
00007d55df7e4d5e  cmp dword ptr [r15+0x318], 0x00
00007d55df7e4d66  jz 0x00007D55DF7E5030
00007d55df7e4d6c  nop [rax+rax*1], ax
00007d55df7e4d75  nop [rax+rax*1], eax
00007d55df7e4d7d  mov eax, 0x410704
00007d55df7e4d82  mov [r15+0x100], rax
00007d55df7e4d89  jmp 0x00007D55DF5FE110
00007d55df7e4d8e  cmp dword ptr [r15+0x318], 0x00
00007d55df7e4d96  jz 0x00007D55DF7E4E70
00007d55df7e4d9c  nop [rax+rax*1], ax
00007d55df7e4da5  nop [rax+rax*1], eax
00007d55df7e4dad  mov eax, 0x4106E8
00007d55df7e4db2  mov [r15+0x100], rax
00007d55df7e4db9  jmp 0x00007D55DF5FE110
00007d55df7e4dbe  int3
00007d55df7e4dbf  call 0x00007D55DF60DC20
00007d55df7e4dc4  jmp 0x00007D55DF7E4CA2
00007d55df7e4dc9  call 0x00007D55DF60E760
00007d55df7e4dce  jmp 0x00007D55DF7E4CB1
00007d55df7e4dd3  ucomisd xmm1, xmm15
00007d55df7e4dd8  jp 0x00007D55DF7E4DE7
00007d55df7e4dda  movaps xmm13, [0x00007D55DF3FE060]
00007d55df7e4de2  jmp 0x00007D55DF7E4D1A
00007d55df7e4de7  vxorps xmm0, xmm1, xmm15
00007d55df7e4dec  pextrw eax, xmm0, 0x03
00007d55df7e4df1  and eax, 0x7FF8
00007d55df7e4df6  cmp eax, 0x08
00007d55df7e4df9  jnz 0x00007D55DF7E4D1A
00007d55df7e4dff  movq rax, xmm15
00007d55df7e4e04  shl rax, 0x0D
00007d55df7e4e08  jbe 0x00007D55DF7E4D1A
00007d55df7e4e0e  vorps xmm13, xmm15, [0x00007D55DF3FE070]
00007d55df7e4e16  jmp 0x00007D55DF7E4D1A
00007d55df7e4e1b  ucomisd xmm1, xmm15
00007d55df7e4e20  jp 0x00007D55DF7E4E2F
00007d55df7e4e22  movaps xmm14, [0x00007D55DF3FE060]
00007d55df7e4e2a  jmp 0x00007D55DF7E4D47
00007d55df7e4e2f  vxorps xmm0, xmm1, xmm15
00007d55df7e4e34  pextrw eax, xmm0, 0x03
00007d55df7e4e39  and eax, 0x7FF8
00007d55df7e4e3e  cmp eax, 0x08
00007d55df7e4e41  jnz 0x00007D55DF7E4D47
00007d55df7e4e47  movq rax, xmm15
00007d55df7e4e4c  shl rax, 0x0D
00007d55df7e4e50  jbe 0x00007D55DF7E4D47
00007d55df7e4e56  vorps xmm14, xmm15, [0x00007D55DF3FE070]
00007d55df7e4e5e  jmp 0x00007D55DF7E4D47
00007d55df7e4e63  int3
00007d55df7e4e64  nop [rax+rax*1], ax
00007d55df7e4e6d  nop [rax], eax
00007d55df7e4e70  mov rax, [r15+0x48]
00007d55df7e4e74  mov r14, [r15+0x50]
00007d55df7e4e78  lea r12, [r14+rax*1]
00007d55df7e4e7c  movups xmm1, [r13+r12*1]
00007d55df7e4e82  movaps [r15+0x120], xmm1
00007d55df7e4e8a  lea r14, [rax+0x10]
00007d55df7e4e8e  mov [r15+0x48], r14
00007d55df7e4e92  xor eax, eax
00007d55df7e4e94  mov r12d, 0x200
00007d55df7e4e9a  cmp r14, r12
00007d55df7e4e9d  cmc
00007d55df7e4e9e  lahf
00007d55df7e4e9f  seto al
00007d55df7e4ea2  mov [r15+0x108], eax
00007d55df7e4ea9  pextrq rax, xmm1, 0x01
00007d55df7e4eb0  movq xmm15, rax
00007d55df7e4eb5  movaps [r15+0x130], xmm15
00007d55df7e4ebd  movaps xmm14, [r15+0x110]
00007d55df7e4ec5  movq rax, xmm14
00007d55df7e4eca  movq r14, xmm1
00007d55df7e4ecf  vmovq xmm1, rax
00007d55df7e4ed4  vmovq xmm14, r14
00007d55df7e4ed9  movaps xmm13, xmm1
00007d55df7e4edd  addsd xmm13, xmm14
00007d55df7e4ee2  ucomisd xmm13, xmm13
00007d55df7e4ee7  jp 0x00007D55DF7E4F9C
00007d55df7e4eed  movq xmm13, xmm13
00007d55df7e4ef2  movq rax, xmm13
00007d55df7e4ef7  movq r14, xmm15
00007d55df7e4efc  vmovq xmm1, rax
00007d55df7e4f01  vmovq xmm15, r14
00007d55df7e4f06  movaps xmm14, xmm1
00007d55df7e4f0a  addsd xmm14, xmm15
00007d55df7e4f0f  ucomisd xmm14, xmm14
00007d55df7e4f14  jp 0x00007D55DF7E4FE4
00007d55df7e4f1a  movq xmm14, xmm14
00007d55df7e4f1f  movaps [r15+0x110], xmm14
00007d55df7e4f27  mov eax, [r15+0x108]
00007d55df7e4f2e  sahf
00007d55df7e4f2f  jnz 0x00007D55DF7E4F61
00007d55df7e4f31  cmp dword ptr [r15+0x318], 0x00
00007d55df7e4f39  jz 0x00007D55DF7E5030
00007d55df7e4f3f  nop [rax+rax*1], ax
00007d55df7e4f48  nop [rax+rax*1], eax
00007d55df7e4f50  mov eax, 0x410704
00007d55df7e4f55  mov [r15+0x100], rax
00007d55df7e4f5c  jmp 0x00007D55DF5FE110
00007d55df7e4f61  cmp dword ptr [r15+0x318], 0x00
00007d55df7e4f69  jz 0x00007D55DF7E4E70
00007d55df7e4f6f  nop [rax+rax*1], ax
00007d55df7e4f78  nop [rax+rax*1], eax
00007d55df7e4f80  mov eax, 0x4106E8
00007d55df7e4f85  mov [r15+0x100], rax
00007d55df7e4f8c  jmp 0x00007D55DF5FE110
00007d55df7e4f91  int3
00007d55df7e4f92  call 0x00007D55DF6B52F0
00007d55df7e4f97  jmp 0x00007D55DF7E4E82
00007d55df7e4f9c  ucomisd xmm1, xmm14
00007d55df7e4fa1  jp 0x00007D55DF7E4FB0
00007d55df7e4fa3  movaps xmm13, [0x00007D55DF3FE060]
00007d55df7e4fab  jmp 0x00007D55DF7E4EED
00007d55df7e4fb0  vxorps xmm0, xmm1, xmm14
00007d55df7e4fb5  pextrw eax, xmm0, 0x03
00007d55df7e4fba  and eax, 0x7FF8
00007d55df7e4fbf  cmp eax, 0x08
00007d55df7e4fc2  jnz 0x00007D55DF7E4EED
00007d55df7e4fc8  movq rax, xmm14
00007d55df7e4fcd  shl rax, 0x0D
00007d55df7e4fd1  jbe 0x00007D55DF7E4EED
00007d55df7e4fd7  vorps xmm13, xmm14, [0x00007D55DF3FE070]
00007d55df7e4fdf  jmp 0x00007D55DF7E4EED
00007d55df7e4fe4  ucomisd xmm1, xmm15
00007d55df7e4fe9  jp 0x00007D55DF7E4FF8
00007d55df7e4feb  movaps xmm14, [0x00007D55DF3FE060]
00007d55df7e4ff3  jmp 0x00007D55DF7E4F1A
00007d55df7e4ff8  vxorps xmm0, xmm1, xmm15
00007d55df7e4ffd  pextrw eax, xmm0, 0x03
00007d55df7e5002  and eax, 0x7FF8
00007d55df7e5007  cmp eax, 0x08
00007d55df7e500a  jnz 0x00007D55DF7E4F1A
00007d55df7e5010  movq rax, xmm15
00007d55df7e5015  shl rax, 0x0D
00007d55df7e5019  jbe 0x00007D55DF7E4F1A
00007d55df7e501f  vorps xmm14, xmm15, [0x00007D55DF3FE070]
00007d55df7e5027  jmp 0x00007D55DF7E4F1A
00007d55df7e502c  int3
00007d55df7e502d  nop [rax], eax
00007d55df7e5030  mov rax, [r15+0xF8]
00007d55df7e5037  lea r14, [rax+0x1D0]
00007d55df7e503e  mov r12, [r13+r14*1]
00007d55df7e5043  lea r14, [rax+0x1D8]
00007d55df7e504a  mov r11, [r13+r14*1]
00007d55df7e504f  mov [r15+0xA0], r12
00007d55df7e5056  mov [r15+0x98], r11
00007d55df7e505d  mov r14, [r15+0x40]
00007d55df7e5061  lea r12, [r14+0xCC0]
00007d55df7e5068  movaps xmm1, [r15+0x110]
00007d55df7e5070  movq r14, xmm1
00007d55df7e5075  mov [r13+r12*1], r14
00007d55df7e507a  lea r14, [rax+0x1C0]
00007d55df7e5081  mov r12, [r13+r14*1]
00007d55df7e5086  lea r14, [rax+0x1C8]
00007d55df7e508d  mov r11, [r13+r14*1]
00007d55df7e5092  mov [r15+0xE8], r12
00007d55df7e5099  mov [r15+0xF0], r11
00007d55df7e50a0  lea r14, [rax+0x1B0]
00007d55df7e50a7  mov r12, [r13+r14*1]
00007d55df7e50ac  lea r14, [rax+0x1B8]
00007d55df7e50b3  mov r10, [r13+r14*1]
00007d55df7e50b8  movq xmm1, r12
00007d55df7e50bd  movq xmm15, r10
00007d55df7e50c2  movq xmm1, xmm1
00007d55df7e50c6  movq xmm1, xmm1
00007d55df7e50ca  movaps [r15+0x1A0], xmm1
00007d55df7e50d2  movq xmm15, xmm15
00007d55df7e50d7  movq xmm15, xmm15
00007d55df7e50dc  movaps [r15+0x190], xmm15
00007d55df7e50e4  lea r14, [rax+0x1A0]
00007d55df7e50eb  mov r12, [r13+r14*1]
00007d55df7e50f0  lea r14, [rax+0x1A8]
00007d55df7e50f7  mov r10, [r13+r14*1]
00007d55df7e50fc  movq xmm1, r12
00007d55df7e5101  movq xmm15, r10
00007d55df7e5106  movq xmm1, xmm1
00007d55df7e510a  movq xmm1, xmm1
00007d55df7e510e  movaps [r15+0x1C0], xmm1
00007d55df7e5116  movq xmm15, xmm15
00007d55df7e511b  movq xmm15, xmm15
00007d55df7e5120  movaps [r15+0x1B0], xmm15
00007d55df7e5128  lea r14, [rax+0x190]
00007d55df7e512f  mov r12, [r13+r14*1]
00007d55df7e5134  lea r14, [rax+0x198]
00007d55df7e513b  mov r10, [r13+r14*1]
00007d55df7e5140  movq xmm1, r12
00007d55df7e5145  movq xmm15, r10
00007d55df7e514a  movq xmm1, xmm1
00007d55df7e514e  movq xmm1, xmm1
00007d55df7e5152  movaps [r15+0x1E0], xmm1
00007d55df7e515a  movq xmm15, xmm15
00007d55df7e515f  movq xmm15, xmm15
00007d55df7e5164  movaps [r15+0x1D0], xmm15
00007d55df7e516c  lea r14, [rax+0x180]
00007d55df7e5173  mov r12, [r13+r14*1]
00007d55df7e5178  lea r14, [rax+0x188]
00007d55df7e517f  mov r10, [r13+r14*1]
00007d55df7e5184  movq xmm1, r12
00007d55df7e5189  movq xmm15, r10
00007d55df7e518e  movq xmm1, xmm1
00007d55df7e5192  movq xmm1, xmm1
00007d55df7e5196  movaps [r15+0x200], xmm1
00007d55df7e519e  movq xmm15, xmm15
00007d55df7e51a3  movq xmm15, xmm15
00007d55df7e51a8  movaps [r15+0x1F0], xmm15
00007d55df7e51b0  lea r14, [rax+0x1E0]
00007d55df7e51b7  mov [r15+0xF8], r14
00007d55df7e51be  mov [r15+0x100], r11
00007d55df7e51c5  jmp 0x00007D55DF7CE5C0
00007d55df7e51ca  int3
00007d55df7e51cb  call 0x00007D55DF6E27E0
00007d55df7e51d0  jmp 0x00007D55DF7E5043
00007d55df7e51d5  call 0x00007D55DF6E1570
00007d55df7e51da  jmp 0x00007D55DF7E504F
00007d55df7e51df  call 0x00007D55DF6C3FE0
00007d55df7e51e4  jmp 0x00007D55DF7E507A
00007d55df7e51e9  call 0x00007D55DF6E27E0
00007d55df7e51ee  jmp 0x00007D55DF7E5086
00007d55df7e51f3  call 0x00007D55DF6E1570
00007d55df7e51f8  jmp 0x00007D55DF7E5092
00007d55df7e51fd  call 0x00007D55DF6E27E0
00007d55df7e5202  jmp 0x00007D55DF7E50AC
00007d55df7e5207  call 0x00007D55DF6E0300
00007d55df7e520c  jmp 0x00007D55DF7E50B8
00007d55df7e5211  call 0x00007D55DF6E27E0
00007d55df7e5216  jmp 0x00007D55DF7E50F0
00007d55df7e521b  call 0x00007D55DF6E0300
00007d55df7e5220  jmp 0x00007D55DF7E50FC
00007d55df7e5225  call 0x00007D55DF6E27E0
00007d55df7e522a  jmp 0x00007D55DF7E5134
00007d55df7e522f  call 0x00007D55DF6E0300
00007d55df7e5234  jmp 0x00007D55DF7E5140
00007d55df7e5239  call 0x00007D55DF6E27E0
00007d55df7e523e  jmp 0x00007D55DF7E5178
00007d55df7e5243  call 0x00007D55DF6E0300
00007d55df7e5248  jmp 0x00007D55DF7E5184
00007d55df7e524d  int3
00007d55df7e524e  nop
00007d55df7e5250  mov qword ptr [r15+0x100], 0x04
00007d55df7e525b  mov esi, 0x00
00007d55df7e5260  mov edx, 0x09
00007d55df7e5265  mov rdi, 0x7FFDAA3FC2D0
00007d55df7e526f  mov rax, 0x5BB84326B970
00007d55df7e5279  call rax
00007d55df7e527b  cmp dword ptr [r15+0x318], 0x00
00007d55df7e5283  jnz 0x00007D55DF5FE110
00007d55df7e5289  jmp 0x00007D55DF5FE0A0
00007d55df7e528e  int3
00007d55df7e528f  int3
