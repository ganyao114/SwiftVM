
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute/baseline/0/0.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13,QWORD PTR [r12+0xf8]
   8:	mov    r14,r13
   b:	sub    r14,0x1e0
  12:	mov    QWORD PTR [r12+0xf8],r14
  1a:	mov    r13d,0x420000
  20:	mov    QWORD PTR [r12+0x40],r13
  25:	mov    r13d,0x420000
  2b:	mov    QWORD PTR [r12+0x48],r13
  30:	mov    r13,r14
  33:	add    r13,0x1d0
  3a:	mov    r14,r13
  3d:	add    r14,0x8
  41:	mov    r15,QWORD PTR [r12+0xa0]
  49:	mov    rbp,QWORD PTR [r12+0x98]
  51:	mov    QWORD PTR [r13+0x0],r15
  55:	mov    r13d,0x0
  5b:	mov    DWORD PTR [r12+0x32c],r13d
  63:	mov    QWORD PTR [r14],rbp
  66:	mov    r13d,0x0
  6c:	mov    DWORD PTR [r12+0x32c],r13d
  74:	mov    r13d,0x420aa0
  7a:	movdqu xmm2,XMMWORD PTR [r13+0x0]
  80:	movdqa xmm0,xmm2
  84:	movdqu XMMWORD PTR [r12+0x110],xmm0
  8e:	mov    r13d,0x420000
  94:	mov    QWORD PTR [r12+0x40],r13
  99:	mov    r13d,0x420a30
  9f:	movdqu xmm3,XMMWORD PTR [r13+0x0]
  a5:	movdqa xmm0,xmm3
  a9:	movdqu XMMWORD PTR [r12+0x120],xmm0
  b3:	mov    r13d,0x420000
  b9:	mov    QWORD PTR [r12+0x48],r13
  be:	mov    r13d,0x420ac0
  c4:	movdqu xmm4,XMMWORD PTR [r13+0x0]
  ca:	movdqa xmm0,xmm4
  ce:	movdqu XMMWORD PTR [r12+0x130],xmm0
  d8:	mov    r13d,0x420000
  de:	mov    QWORD PTR [r12+0x40],r13
  e3:	mov    r13d,0x420a60
  e9:	movdqu xmm5,XMMWORD PTR [r13+0x0]
  ef:	movdqa xmm0,xmm5
  f3:	movdqu XMMWORD PTR [r12+0x140],xmm0
  fd:	mov    r13d,0x430000
 103:	mov    QWORD PTR [r12+0x98],r13
 10b:	mov    r13d,0x430000
 111:	mov    r14,r13
 114:	add    r14,0xcd0
 11b:	mov    QWORD PTR [r12+0x98],r14
 123:	mov    r13,QWORD PTR [r12+0x40]
 128:	mov    r15,r13
 12b:	add    r15,0xad0
 132:	movdqu xmm6,XMMWORD PTR [r15]
 137:	movdqa xmm0,xmm6
 13b:	movdqu XMMWORD PTR [r12+0x150],xmm0
 145:	mov    r13d,0x420000
 14b:	mov    QWORD PTR [r12+0x40],r13
 150:	mov    r13,r14
 153:	add    r13,0x10
 157:	movdqu XMMWORD PTR [r14],xmm2
 15c:	mov    r15d,0x0
 162:	mov    DWORD PTR [r12+0x32c],r15d
 16a:	movdqu XMMWORD PTR [r13+0x0],xmm3
 170:	mov    r13d,0x0
 176:	mov    DWORD PTR [r12+0x32c],r13d
 17e:	mov    r13,r14
 181:	add    r13,0x20
 185:	mov    r15,r13
 188:	add    r15,0x10
 18c:	movdqu XMMWORD PTR [r13+0x0],xmm4
 192:	mov    r13d,0x0
 198:	mov    DWORD PTR [r12+0x32c],r13d
 1a0:	movdqu XMMWORD PTR [r15],xmm5
 1a5:	mov    r13d,0x0
 1ab:	mov    DWORD PTR [r12+0x32c],r13d
 1b3:	mov    r13d,0x420a20
 1b9:	movdqu xmm4,XMMWORD PTR [r13+0x0]
 1bf:	movdqa xmm0,xmm4
 1c3:	movdqu XMMWORD PTR [r12+0x130],xmm0
 1cd:	mov    r13d,0x420000
 1d3:	mov    QWORD PTR [r12+0x40],r13
 1d8:	mov    r13d,0x420a10
 1de:	movdqu xmm5,XMMWORD PTR [r13+0x0]
 1e4:	movdqa xmm0,xmm5
 1e8:	movdqu XMMWORD PTR [r12+0x140],xmm0
 1f2:	mov    r13d,0x420000
 1f8:	mov    QWORD PTR [r12+0x40],r13
 1fd:	mov    r13,r14
 200:	add    r13,0x100
 207:	mov    r15,r13
 20a:	add    r15,0x10
 20e:	movdqu XMMWORD PTR [r13+0x0],xmm2
 214:	mov    r13d,0x0
 21a:	mov    DWORD PTR [r12+0x32c],r13d
 222:	movdqu XMMWORD PTR [r15],xmm3
 227:	mov    r13d,0x0
 22d:	mov    DWORD PTR [r12+0x32c],r13d
 235:	mov    r13,r14
 238:	add    r13,0x40
 23c:	mov    r14,r13
 23f:	add    r14,0x10
 243:	movdqu XMMWORD PTR [r13+0x0],xmm6
 249:	mov    r13d,0x0
 24f:	mov    DWORD PTR [r12+0x32c],r13d
 257:	movdqu XMMWORD PTR [r14],xmm4
 25c:	mov    r13d,0x0
 262:	mov    DWORD PTR [r12+0x32c],r13d
 26a:	mov    r13d,0x420a00
 270:	movdqu xmm2,XMMWORD PTR [r13+0x0]
 276:	movdqa xmm0,xmm2
 27a:	movdqu XMMWORD PTR [r12+0x130],xmm0
 284:	mov    r13d,0x420000
 28a:	mov    QWORD PTR [r12+0x40],r13
 28f:	mov    r13d,0x420a70
 295:	movdqu xmm3,XMMWORD PTR [r13+0x0]
 29b:	movdqa xmm0,xmm3
 29f:	movdqu XMMWORD PTR [r12+0x150],xmm0
 2a9:	mov    r13d,0x420000
 2af:	mov    QWORD PTR [r12+0x40],r13
 2b4:	mov    r13d,0xf8d3
 2ba:	mov    QWORD PTR [r12+0x48],r13
 2bf:	mov    r13,QWORD PTR [r12+0x98]
 2c7:	mov    r14,r13
 2ca:	add    r14,0x60
 2ce:	mov    r15,r14
 2d1:	add    r15,0x10
 2d5:	movdqu XMMWORD PTR [r14],xmm5
 2da:	mov    r14d,0x0
 2e0:	mov    DWORD PTR [r12+0x32c],r14d
 2e8:	movdqu XMMWORD PTR [r15],xmm2
 2ed:	mov    r14d,0x0
 2f3:	mov    DWORD PTR [r12+0x32c],r14d
 2fb:	mov    r14d,0x420a80
 301:	movdqu xmm2,XMMWORD PTR [r14]
 306:	movdqa xmm0,xmm2
 30a:	movdqu XMMWORD PTR [r12+0x130],xmm0
 314:	mov    r14d,0x420000
 31a:	mov    QWORD PTR [r12+0x40],r14
 31f:	mov    r14d,0x420a50
 325:	movdqu xmm2,XMMWORD PTR [r14]
 32a:	movdqa xmm0,xmm2
 32e:	movdqu XMMWORD PTR [r12+0x140],xmm0
 338:	mov    r14d,0x420000
 33e:	mov    QWORD PTR [r12+0x40],r14
 343:	mov    r14d,0xf8d3
 349:	mov    r15d,0x421d
 34f:	and    r15d,0xffff
 356:	mov    rax,r14
 359:	movabs rcx,0xffffffff0000ffff
 363:	and    rax,rcx
 366:	mov    rdx,r15
 369:	shl    rdx,0x10
 36d:	mov    ecx,0xffff0000
 372:	and    rdx,rcx
 375:	or     rax,rdx
 378:	mov    ebp,eax
 37a:	mov    QWORD PTR [r12+0x48],rbp
 37f:	mov    r14,r13
 382:	add    r14,0x80
 389:	mov    r15,r14
 38c:	add    r15,0x10
 390:	movdqu xmm0,XMMWORD PTR [r12+0x130]
 39a:	movdqa xmm2,xmm0
 39e:	movdqu XMMWORD PTR [r14],xmm3
 3a3:	mov    r14d,0x0
 3a9:	mov    DWORD PTR [r12+0x32c],r14d
 3b1:	movdqu XMMWORD PTR [r15],xmm2
 3b6:	mov    r14d,0x0
 3bc:	mov    DWORD PTR [r12+0x32c],r14d
 3c4:	mov    r14d,0x420af0
 3ca:	movdqu xmm2,XMMWORD PTR [r14]
 3cf:	movdqa xmm0,xmm2
 3d3:	movdqu XMMWORD PTR [r12+0x130],xmm0
 3dd:	mov    r14d,0x420000
 3e3:	mov    QWORD PTR [r12+0x40],r14
 3e8:	mov    r14d,0x420b00
 3ee:	movdqu xmm3,XMMWORD PTR [r14]
 3f3:	movdqa xmm0,xmm3
 3f7:	movdqu XMMWORD PTR [r12+0x150],xmm0
 401:	mov    r14d,0x420000
 407:	mov    QWORD PTR [r12+0x40],r14
 40c:	mov    r14d,0x3e8
 412:	mov    QWORD PTR [r12+0xa0],r14
 41a:	mov    r14,r13
 41d:	add    r14,0xa0
 424:	mov    r13,r14
 427:	add    r13,0x10
 42b:	movdqu xmm0,XMMWORD PTR [r12+0x140]
 435:	movdqa xmm3,xmm0
 439:	movdqu XMMWORD PTR [r14],xmm3
 43e:	mov    r14d,0x0
 444:	mov    DWORD PTR [r12+0x32c],r14d
 44c:	movdqu XMMWORD PTR [r13+0x0],xmm2
 452:	mov    r13d,0x0
 458:	mov    DWORD PTR [r12+0x32c],r13d
 460:	mov    r13,QWORD PTR [r12+0x40]
 465:	mov    r14,r13
 468:	add    r14,0xae0
 46f:	movdqu xmm2,XMMWORD PTR [r14]
 474:	movdqa xmm0,xmm2
 478:	movdqu XMMWORD PTR [r12+0x130],xmm0
 482:	mov    r13d,0x420000
 488:	mov    QWORD PTR [r12+0x40],r13
 48d:	mov    r13d,0x420a90
 493:	movdqu xmm2,XMMWORD PTR [r13+0x0]
 499:	movdqa xmm0,xmm2
 49d:	movdqu XMMWORD PTR [r12+0x140],xmm0
 4a7:	mov    r13d,0x420000
 4ad:	mov    QWORD PTR [r12+0x40],r13
 4b2:	mov    r13,QWORD PTR [r12+0xf8]
 4ba:	mov    r14,r13
 4bd:	add    r14,0x180
 4c4:	mov    r13,r14
 4c7:	add    r13,0x8
 4cb:	mov    r15,QWORD PTR [r12+0x200]
 4d3:	mov    rbp,QWORD PTR [r12+0x1f0]
 4db:	mov    QWORD PTR [r14],r15
 4de:	mov    r14d,0x0
 4e4:	mov    DWORD PTR [r12+0x32c],r14d
 4ec:	mov    QWORD PTR [r13+0x0],rbp
 4f0:	mov    r13d,0x0
 4f6:	mov    DWORD PTR [r12+0x32c],r13d
 4fe:	mov    r13,QWORD PTR [r12+0x98]
 506:	mov    r14,r13
 509:	add    r14,0xc0
 510:	mov    r15,r14
 513:	add    r15,0x10
 517:	movdqu xmm0,XMMWORD PTR [r12+0x150]
 521:	movdqa xmm2,xmm0
 525:	movdqu xmm0,XMMWORD PTR [r12+0x130]
 52f:	movdqa xmm3,xmm0
 533:	movdqu XMMWORD PTR [r14],xmm2
 538:	mov    r14d,0x0
 53e:	mov    DWORD PTR [r12+0x32c],r14d
 546:	movdqu XMMWORD PTR [r15],xmm3
 54b:	mov    r14d,0x0
 551:	mov    DWORD PTR [r12+0x32c],r14d
 559:	mov    r14d,0x420ab0
 55f:	movdqu xmm2,XMMWORD PTR [r14]
 564:	movdqa xmm0,xmm2
 568:	movdqu XMMWORD PTR [r12+0x130],xmm0
 572:	mov    r14d,0x420000
 578:	mov    QWORD PTR [r12+0x40],r14
 57d:	mov    r14d,0x420b18
 583:	mov    r15,QWORD PTR [r14]
 586:	mov    r14d,0x0
 58c:	mov    QWORD PTR [r12+0x110],r15
 594:	mov    QWORD PTR [r12+0x118],r14
 59c:	mov    r14d,0x420b20
 5a2:	mov    QWORD PTR [r12+0x40],r14
 5a7:	mov    r14,r13
 5aa:	add    r14,0xe0
 5b1:	mov    rbp,r14
 5b4:	add    rbp,0x10
 5b8:	movdqu xmm0,XMMWORD PTR [r12+0x140]
 5c2:	movdqa xmm3,xmm0
 5c6:	movdqu XMMWORD PTR [r14],xmm3
 5cb:	mov    r14d,0x0
 5d1:	mov    DWORD PTR [r12+0x32c],r14d
 5d9:	movdqu XMMWORD PTR [rbp+0x0],xmm2
 5de:	mov    r14d,0x0
 5e4:	mov    DWORD PTR [r12+0x32c],r14d
 5ec:	mov    r14d,0x420b80
 5f2:	movdqu xmm2,XMMWORD PTR [r14]
 5f7:	movdqa xmm0,xmm2
 5fb:	movdqu XMMWORD PTR [r12+0x130],xmm0
 605:	mov    r14,r13
 608:	add    r14,0x120
 60f:	mov    QWORD PTR [r14],r15
 612:	mov    r13d,0x0
 618:	mov    DWORD PTR [r12+0x32c],r13d
 620:	mov    r13d,0x420b60
 626:	mov    r14d,0x420b70
 62c:	movdqu xmm3,XMMWORD PTR [r13+0x0]
 632:	movdqu xmm4,XMMWORD PTR [r14]
 637:	movdqa xmm0,xmm3
 63b:	movdqu XMMWORD PTR [r12+0x120],xmm0
 645:	movdqa xmm0,xmm4
 649:	movdqu XMMWORD PTR [r12+0x110],xmm0
 653:	mov    r13,QWORD PTR [r12+0xf8]
 65b:	mov    r14,r13
 65e:	add    r14,0x160
 665:	movdqu XMMWORD PTR [r14],xmm2
 66a:	mov    r14d,0x0
 670:	mov    DWORD PTR [r12+0x32c],r14d
 678:	mov    r14,r13
 67b:	add    r14,0x190
 682:	mov    r15,r14
 685:	add    r15,0x8
 689:	mov    rbp,QWORD PTR [r12+0x1e0]
 691:	mov    r8,QWORD PTR [r12+0x1d0]
 699:	mov    QWORD PTR [r14],rbp
 69c:	mov    r14d,0x0
 6a2:	mov    DWORD PTR [r12+0x32c],r14d
 6aa:	mov    QWORD PTR [r15],r8
 6ad:	mov    r14d,0x0
 6b3:	mov    DWORD PTR [r12+0x32c],r14d
 6bb:	mov    r14,r13
 6be:	add    r14,0x140
 6c5:	mov    r15,r14
 6c8:	add    r15,0x10
 6cc:	movdqu XMMWORD PTR [r14],xmm3
 6d1:	mov    r14d,0x0
 6d7:	mov    DWORD PTR [r12+0x32c],r14d
 6df:	movdqu XMMWORD PTR [r15],xmm4
 6e4:	mov    r14d,0x0
 6ea:	mov    DWORD PTR [r12+0x32c],r14d
 6f2:	mov    r14d,0x420b20
 6f8:	mov    r15d,0x420b30
 6fe:	movdqu xmm2,XMMWORD PTR [r14]
 703:	movdqu xmm3,XMMWORD PTR [r15]
 708:	movdqa xmm0,xmm2
 70c:	movdqu XMMWORD PTR [r12+0x110],xmm0
 716:	movdqa xmm0,xmm3
 71a:	movdqu XMMWORD PTR [r12+0x120],xmm0
 724:	mov    r14,r13
 727:	add    r14,0x1a0
 72e:	mov    r15,r14
 731:	add    r15,0x8
 735:	mov    rbp,QWORD PTR [r12+0x1c0]
 73d:	mov    r8,QWORD PTR [r12+0x1b0]
 745:	mov    QWORD PTR [r14],rbp
 748:	mov    r14d,0x0
 74e:	mov    DWORD PTR [r12+0x32c],r14d
 756:	mov    QWORD PTR [r15],r8
 759:	mov    r14d,0x0
 75f:	mov    DWORD PTR [r12+0x32c],r14d
 767:	mov    r14,r13
 76a:	add    r14,0x1b0
 771:	mov    r15,r14
 774:	add    r15,0x8
 778:	mov    rbp,QWORD PTR [r12+0x1a0]
 780:	mov    r8,QWORD PTR [r12+0x190]
 788:	mov    QWORD PTR [r14],rbp
 78b:	mov    r14d,0x0
 791:	mov    DWORD PTR [r12+0x32c],r14d
 799:	mov    QWORD PTR [r15],r8
 79c:	mov    r14d,0x0
 7a2:	mov    DWORD PTR [r12+0x32c],r14d
 7aa:	mov    r14,r13
 7ad:	add    r14,0x100
 7b4:	mov    r13,r14
 7b7:	add    r13,0x10
 7bb:	movdqu xmm0,XMMWORD PTR [r12+0x110]
 7c5:	movdqa xmm2,xmm0
 7c9:	movdqu xmm0,XMMWORD PTR [r12+0x120]
 7d3:	movdqa xmm3,xmm0
 7d7:	movdqu XMMWORD PTR [r14],xmm2
 7dc:	mov    r14d,0x0
 7e2:	mov    DWORD PTR [r12+0x32c],r14d
 7ea:	movdqu XMMWORD PTR [r13+0x0],xmm3
 7f0:	mov    r13d,0x0
 7f6:	mov    DWORD PTR [r12+0x32c],r13d
 7fe:	mov    r13,QWORD PTR [r12+0x40]
 803:	mov    r14,r13
 806:	add    r14,0x20
 80a:	mov    r13,r14
 80d:	add    r13,0x10
 811:	movdqu xmm2,XMMWORD PTR [r14]
 816:	movdqu xmm3,XMMWORD PTR [r13+0x0]
 81c:	movdqa xmm0,xmm2
 820:	movdqu XMMWORD PTR [r12+0x110],xmm0
 82a:	movdqa xmm0,xmm3
 82e:	movdqu XMMWORD PTR [r12+0x130],xmm0
 838:	mov    r13,QWORD PTR [r12+0xf8]
 840:	mov    r14,r13
 843:	add    r14,0x1c0
 84a:	mov    r15,r14
 84d:	add    r15,0x8
 851:	mov    rbp,QWORD PTR [r12+0xe8]
 859:	mov    r8,QWORD PTR [r12+0xf0]
 861:	mov    QWORD PTR [r14],rbp
 864:	mov    r14d,0x0
 86a:	mov    DWORD PTR [r12+0x32c],r14d
 872:	mov    QWORD PTR [r15],r8
 875:	mov    r14d,0x0
 87b:	mov    DWORD PTR [r12+0x32c],r14d
 883:	mov    r14,QWORD PTR [r12+0x98]
 88b:	mov    r15,r14
 88e:	add    r15,0x128
 895:	mov    ebp,DWORD PTR [r12+0x48]
 89a:	mov    DWORD PTR [r15],ebp
 89d:	mov    r15d,0x0
 8a3:	mov    DWORD PTR [r12+0x32c],r15d
 8ab:	mov    r15,r13
 8ae:	add    r15,0x120
 8b5:	mov    rbp,r15
 8b8:	add    rbp,0x10
 8bc:	movdqu xmm0,XMMWORD PTR [r12+0x110]
 8c6:	movdqa xmm2,xmm0
 8ca:	movdqu XMMWORD PTR [r15],xmm2
 8cf:	mov    r15d,0x0
 8d5:	mov    DWORD PTR [r12+0x32c],r15d
 8dd:	movdqu XMMWORD PTR [rbp+0x0],xmm3
 8e2:	mov    r15d,0x0
 8e8:	mov    DWORD PTR [r12+0x32c],r15d
 8f0:	mov    r15,r13
 8f3:	add    r15,0x100
 8fa:	mov    QWORD PTR [r12],r15
 8fe:	mov    r13d,0x0
 904:	mov    rcx,r14
 907:	mov    r15,r13
 90a:	or     r15,rcx
 90d:	mov    QWORD PTR [r12+0x8],r15
 912:	mov    r13d,0x12c
 918:	mov    QWORD PTR [r12+0x10],r13
 91d:	mov    r13d,0x410284
 923:	mov    QWORD PTR [r12+0xf0],r13
 92b:	mov    r13d,0x410728
 931:	mov    QWORD PTR [r12+0x100],r13
 939:	mov    QWORD PTR [r12+0x108],rbx
 941:	mov    edi,0x410728
 946:	mov    QWORD PTR [r12+0x100],rdi
 94e:	xchg   ax,ax
 950:	jmp    QWORD PTR [rip+0x2]        # 0x958
 956:	xchg   ax,ax
 958:	sub    cl,0x8f
 95b:	(bad)
 95c:	fidiv  WORD PTR [rax+rax*1+0x0]
 960:	push   0xffffffffde068fe9
 965:	je     0x967
 967:	add    BYTE PTR [rcx-0x45],cl
 96a:	jo     0x9bf
 96c:	rex.X (bad)
 96e:	cdq
 96f:	pop    rbx
 970:	add    BYTE PTR [rax],al
 972:	jmp    r11
 975:	nop
 976:	nop
 977:	nop
