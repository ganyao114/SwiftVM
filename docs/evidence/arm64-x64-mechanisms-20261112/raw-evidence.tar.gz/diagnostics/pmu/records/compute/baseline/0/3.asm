
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute/baseline/0/3.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13,QWORD PTR [r12+0xf8]
   8:	mov    r14,r13
   b:	add    r14,0x168
  12:	mov    r15,QWORD PTR [r14]
  15:	mov    QWORD PTR [r12+0x40],r15
  1a:	mov    r14,r13
  1d:	add    r14,0x178
  24:	mov    r13d,0x0
  2a:	mov    BYTE PTR [r14],r13b
  2d:	mov    r13d,0x0
  33:	mov    DWORD PTR [r12+0x32c],r13d
  3b:	mov    r13,r15
  3e:	sub    r13,0x38
  42:	pushf
  43:	pop    rdx
  44:	mov    r10d,edx
  47:	and    r10d,0xc0
  4e:	shl    r10d,0x18
  52:	mov    r11d,edx
  55:	and    r11d,0x1
  59:	shl    r11d,0x1d
  5d:	or     r10d,r11d
  60:	mov    r11d,edx
  63:	and    r11d,0x800
  6a:	shl    r11d,0x11
  6e:	or     r10d,r11d
  71:	mov    r11d,0xf0000000
  77:	and    r11,r10
  7a:	movabs rsi,0xffffffff0fffffff
  84:	and    rbx,rsi
  87:	or     rbx,r11
  8a:	btc    rbx,0x1d
  8f:	test   ebx,0x40000000
  95:	jne    0x12d
  9b:	jmp    0xa0
  a0:	mov    r13,QWORD PTR [r12+0xf8]
  a8:	mov    r14,r13
  ab:	add    r14,0x100
  b2:	mov    QWORD PTR [r12],r14
  b6:	mov    r14,r13
  b9:	add    r14,0x178
  c0:	mov    QWORD PTR [r12+0x8],r14
  c5:	mov    r13d,0x1
  cb:	mov    QWORD PTR [r12+0x10],r13
  d0:	mov    r13d,0x4102c8
  d6:	mov    QWORD PTR [r12+0xf0],r13
  de:	mov    r13d,0x410728
  e4:	mov    QWORD PTR [r12+0x100],r13
  ec:	mov    QWORD PTR [r12+0x108],rbx
  f4:	mov    edi,0x410728
  f9:	mov    QWORD PTR [r12+0x100],rdi
 101:	nop    DWORD PTR [rax+0x0]
 108:	jmp    QWORD PTR [rip+0x2]        # 0x110
 10e:	xchg   ax,ax
 110:	sub    cl,0x8f
 113:	(bad)
 114:	fidiv  WORD PTR [rax+rax*1+0x0]
 118:	loopne 0x139
 11a:	nop
 11b:	(bad)
 11c:	fidiv  WORD PTR [rax+rax*1+0x0]
 120:	movabs r11,0x5b9960425370
 12a:	jmp    r11
 12d:	mov    r13,QWORD PTR [r12+0x98]
 135:	mov    r14,r13
 138:	ror    r14,0x3d
 13c:	mov    r13,r14
 13f:	and    r13,0xfffffffffffffff8
 143:	mov    QWORD PTR [r12+0x40],r13
 148:	mov    r14,QWORD PTR [r12+0xf8]
 150:	mov    r15,r14
 153:	add    r15,0x100
 15a:	mov    QWORD PTR [r12],r15
 15e:	mov    r15,r14
 161:	add    r15,0x170
 168:	mov    QWORD PTR [r12+0x8],r15
 16d:	mov    r15d,0x8
 173:	mov    QWORD PTR [r12+0x10],r15
 178:	movabs rcx,0xff00ff00ff00ff
 182:	mov    r15,r13
 185:	and    r15,rcx
 188:	mov    rbp,r15
 18b:	shl    rbp,0x8
 18f:	movabs rcx,0xff00ff00ff00ff00
 199:	mov    r15,r13
 19c:	and    r15,rcx
 19f:	mov    r13,r15
 1a2:	shr    r13,0x8
 1a6:	mov    rcx,rbp
 1a9:	mov    r15,r13
 1ac:	or     r15,rcx
 1af:	movabs rcx,0xffff0000ffff
 1b9:	mov    r13,r15
 1bc:	and    r13,rcx
 1bf:	mov    rbp,r13
 1c2:	shl    rbp,0x10
 1c6:	movabs rcx,0xffff0000ffff0000
 1d0:	mov    r13,r15
 1d3:	and    r13,rcx
 1d6:	mov    r15,r13
 1d9:	shr    r15,0x10
 1dd:	mov    rcx,rbp
 1e0:	mov    r13,r15
 1e3:	or     r13,rcx
 1e6:	mov    r15,r13
 1e9:	shl    r15,0x20
 1ed:	mov    rbp,r13
 1f0:	shr    rbp,0x20
 1f4:	mov    rcx,r15
 1f7:	mov    r13,rbp
 1fa:	or     r13,rcx
 1fd:	mov    QWORD PTR [r12+0x40],r13
 202:	mov    r15,r14
 205:	add    r15,0x170
 20c:	mov    QWORD PTR [r15],r13
 20f:	mov    r13d,0x0
 215:	mov    DWORD PTR [r12+0x32c],r13d
 21d:	mov    r13d,0x4102f0
 223:	mov    QWORD PTR [r12+0xf0],r13
 22b:	mov    r13d,0x410728
 231:	mov    QWORD PTR [r12+0x100],r13
 239:	mov    QWORD PTR [r12+0x108],rbx
 241:	mov    edi,0x410728
 246:	mov    QWORD PTR [r12+0x100],rdi
 24e:	xchg   ax,ax
 250:	jmp    QWORD PTR [rip+0x2]        # 0x258
 256:	xchg   ax,ax
 258:	sub    cl,0x8f
 25b:	(bad)
 25c:	fidiv  WORD PTR [rax+rax*1+0x0]
 260:	sub    BYTE PTR [rcx],ah
 262:	nop
 263:	(bad)
 264:	fidiv  WORD PTR [rax+rax*1+0x0]
 268:	movabs r11,0x5b9960425370
 272:	jmp    r11
 275:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 280:	jmp    0xa0
 285:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
 290:	jmp    0x12d
 295:	nop
 296:	nop
 297:	nop
