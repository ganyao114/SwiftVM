
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute/baseline/0/5.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	sub    rsp,0x10
   4:	mov    r13,QWORD PTR [r12+0xf8]
   c:	mov    r14,r13
   f:	add    r14,0x100
  16:	mov    r15d,DWORD PTR [r14]
  19:	mov    QWORD PTR [r12+0x40],r15
  1e:	mov    r14,r13
  21:	add    r14,0x104
  28:	mov    ebp,DWORD PTR [r14]
  2b:	mov    QWORD PTR [r12+0x50],rbp
  30:	mov    r14d,0x430c90
  36:	mov    QWORD PTR [r12+0x48],r14
  3b:	mov    r14,r13
  3e:	add    r14,0x108
  45:	mov    r8d,DWORD PTR [r14]
  48:	mov    QWORD PTR [r12+0x58],r8
  4d:	mov    r14,r13
  50:	add    r14,0x10c
  57:	mov    r13d,DWORD PTR [r14]
  5a:	mov    QWORD PTR [r12+0x60],r13
  5f:	movabs rcx,0xff00ff00ff00ff
  69:	mov    r13,r15
  6c:	and    r13,rcx
  6f:	mov    r14,r13
  72:	shl    r14,0x8
  76:	movabs rcx,0xff00ff00ff00ff00
  80:	mov    r13,r15
  83:	and    r13,rcx
  86:	mov    r15,r13
  89:	shr    r15,0x8
  8d:	mov    rcx,r14
  90:	mov    r13,r15
  93:	or     r13,rcx
  96:	movabs rcx,0xffff0000ffff
  a0:	mov    r14,r13
  a3:	and    r14,rcx
  a6:	mov    r15,r14
  a9:	shl    r15,0x10
  ad:	movabs rcx,0xffff0000ffff0000
  b7:	mov    r14,r13
  ba:	and    r14,rcx
  bd:	mov    r13,r14
  c0:	shr    r13,0x10
  c4:	mov    rcx,r15
  c7:	mov    r14,r13
  ca:	or     r14,rcx
  cd:	mov    ecx,0xffffffff
  d2:	mov    r13,r14
  d5:	and    r13,rcx
  d8:	mov    QWORD PTR [r12+0x40],r13
  dd:	movabs rcx,0xff00ff00ff00ff
  e7:	mov    r14,rbp
  ea:	and    r14,rcx
  ed:	mov    r15,r14
  f0:	shl    r15,0x8
  f4:	movabs rcx,0xff00ff00ff00ff00
  fe:	mov    r14,rbp
 101:	and    r14,rcx
 104:	mov    rbp,r14
 107:	shr    rbp,0x8
 10b:	mov    rcx,r15
 10e:	mov    r14,rbp
 111:	or     r14,rcx
 114:	movabs rcx,0xffff0000ffff
 11e:	mov    r15,r14
 121:	and    r15,rcx
 124:	mov    rbp,r15
 127:	shl    rbp,0x10
 12b:	movabs rcx,0xffff0000ffff0000
 135:	mov    r15,r14
 138:	and    r15,rcx
 13b:	mov    r14,r15
 13e:	shr    r14,0x10
 142:	mov    rcx,rbp
 145:	mov    r15,r14
 148:	or     r15,rcx
 14b:	mov    ecx,0xffffffff
 150:	mov    r14,r15
 153:	and    r14,rcx
 156:	mov    QWORD PTR [r12+0x50],r14
 15b:	mov    r15d,0x0
 161:	mov    QWORD PTR [r12+0xa0],r15
 169:	mov    r15d,0x430c90
 16f:	mov    ebp,0x430c94
 174:	mov    rax,r13
 177:	mov    eax,eax
 179:	mov    r8d,eax
 17c:	mov    rax,r14
 17f:	mov    eax,eax
 181:	mov    r13d,eax
 184:	mov    DWORD PTR [r15],r8d
 187:	mov    r14d,0x0
 18d:	mov    DWORD PTR [r12+0x32c],r14d
 195:	mov    DWORD PTR [rbp+0x0],r13d
 199:	mov    r13d,0x0
 19f:	mov    DWORD PTR [r12+0x32c],r13d
 1a7:	mov    r13d,DWORD PTR [r12+0x58]
 1ac:	movabs rcx,0xff00ff00ff00ff
 1b6:	mov    r14,r13
 1b9:	and    r14,rcx
 1bc:	mov    r15,r14
 1bf:	shl    r15,0x8
 1c3:	movabs rcx,0xff00ff00ff00ff00
 1cd:	mov    r14,r13
 1d0:	and    r14,rcx
 1d3:	mov    r13,r14
 1d6:	shr    r13,0x8
 1da:	mov    rcx,r15
 1dd:	mov    r14,r13
 1e0:	or     r14,rcx
 1e3:	movabs rcx,0xffff0000ffff
 1ed:	mov    r13,r14
 1f0:	and    r13,rcx
 1f3:	mov    r15,r13
 1f6:	shl    r15,0x10
 1fa:	movabs rcx,0xffff0000ffff0000
 204:	mov    r13,r14
 207:	and    r13,rcx
 20a:	mov    r14,r13
 20d:	shr    r14,0x10
 211:	mov    rcx,r15
 214:	mov    r13,r14
 217:	or     r13,rcx
 21a:	mov    ecx,0xffffffff
 21f:	mov    r14,r13
 222:	and    r14,rcx
 225:	mov    QWORD PTR [r12+0x40],r14
 22a:	mov    r13,QWORD PTR [r12+0xf8]
 232:	mov    r15,r13
 235:	add    r15,0x110
 23c:	mov    ebp,DWORD PTR [r15]
 23f:	mov    QWORD PTR [r12+0x50],rbp
 244:	mov    r15d,DWORD PTR [r12+0x60]
 249:	movabs rcx,0xff00ff00ff00ff
 253:	mov    rbp,r15
 256:	and    rbp,rcx
 259:	mov    r8,rbp
 25c:	shl    r8,0x8
 260:	movabs rcx,0xff00ff00ff00ff00
 26a:	mov    rbp,r15
 26d:	and    rbp,rcx
 270:	mov    r15,rbp
 273:	shr    r15,0x8
 277:	mov    rcx,r8
 27a:	mov    rbp,r15
 27d:	or     rbp,rcx
 280:	movabs rcx,0xffff0000ffff
 28a:	mov    r15,rbp
 28d:	and    r15,rcx
 290:	mov    r8,r15
 293:	shl    r8,0x10
 297:	movabs rcx,0xffff0000ffff0000
 2a1:	mov    r15,rbp
 2a4:	and    r15,rcx
 2a7:	mov    rbp,r15
 2aa:	shr    rbp,0x10
 2ae:	mov    rcx,r8
 2b1:	mov    r15,rbp
 2b4:	or     r15,rcx
 2b7:	mov    ecx,0xffffffff
 2bc:	mov    rbp,r15
 2bf:	and    rbp,rcx
 2c2:	mov    QWORD PTR [r12+0x58],rbp
 2c7:	mov    r15,r13
 2ca:	add    r15,0x114
 2d1:	mov    r13d,DWORD PTR [r15]
 2d4:	mov    QWORD PTR [r12+0x60],r13
 2d9:	mov    r13d,0x430000
 2df:	mov    QWORD PTR [r12+0x98],r13
 2e7:	mov    r13d,0x430000
 2ed:	mov    r15,r13
 2f0:	add    r15,0xdfc
 2f7:	mov    QWORD PTR [r12+0x98],r15
 2ff:	mov    r13,QWORD PTR [r12+0x48]
 304:	mov    r15,r13
 307:	add    r15,0x8
 30b:	mov    r13,r15
 30e:	add    r13,0x4
 312:	mov    rax,r14
 315:	mov    eax,eax
 317:	mov    r8d,eax
 31a:	mov    rax,rbp
 31d:	mov    eax,eax
 31f:	mov    r14d,eax
 322:	mov    DWORD PTR [r15],r8d
 325:	mov    r15d,0x0
 32b:	mov    DWORD PTR [r12+0x32c],r15d
 333:	mov    DWORD PTR [r13+0x0],r14d
 337:	mov    r13d,0x0
 33d:	mov    DWORD PTR [r12+0x32c],r13d
 345:	mov    r13d,DWORD PTR [r12+0x50]
 34a:	movabs rcx,0xff00ff00ff00ff
 354:	mov    r14,r13
 357:	and    r14,rcx
 35a:	mov    r15,r14
 35d:	shl    r15,0x8
 361:	movabs rcx,0xff00ff00ff00ff00
 36b:	mov    r14,r13
 36e:	and    r14,rcx
 371:	mov    r13,r14
 374:	shr    r13,0x8
 378:	mov    rcx,r15
 37b:	mov    r14,r13
 37e:	or     r14,rcx
 381:	movabs rcx,0xffff0000ffff
 38b:	mov    r13,r14
 38e:	and    r13,rcx
 391:	mov    r15,r13
 394:	shl    r15,0x10
 398:	movabs rcx,0xffff0000ffff0000
 3a2:	mov    r13,r14
 3a5:	and    r13,rcx
 3a8:	mov    r14,r13
 3ab:	shr    r14,0x10
 3af:	mov    rcx,r15
 3b2:	mov    r13,r14
 3b5:	or     r13,rcx
 3b8:	mov    ecx,0xffffffff
 3bd:	mov    r14,r13
 3c0:	and    r14,rcx
 3c3:	mov    QWORD PTR [r12+0x40],r14
 3c8:	mov    r13,QWORD PTR [r12+0xf8]
 3d0:	mov    r15,r13
 3d3:	add    r15,0x118
 3da:	mov    ebp,DWORD PTR [r15]
 3dd:	mov    QWORD PTR [r12+0x50],rbp
 3e2:	mov    r15d,DWORD PTR [r12+0x60]
 3e7:	movabs rcx,0xff00ff00ff00ff
 3f1:	mov    r8,r15
 3f4:	and    r8,rcx
 3f7:	mov    r9,r8
 3fa:	shl    r9,0x8
 3fe:	movabs rcx,0xff00ff00ff00ff00
 408:	mov    r8,r15
 40b:	and    r8,rcx
 40e:	mov    r15,r8
 411:	shr    r15,0x8
 415:	mov    rcx,r9
 418:	mov    r8,r15
 41b:	or     r8,rcx
 41e:	movabs rcx,0xffff0000ffff
 428:	mov    r15,r8
 42b:	and    r15,rcx
 42e:	mov    r9,r15
 431:	shl    r9,0x10
 435:	movabs rcx,0xffff0000ffff0000
 43f:	mov    r15,r8
 442:	and    r15,rcx
 445:	mov    r8,r15
 448:	shr    r8,0x10
 44c:	mov    rcx,r9
 44f:	mov    r15,r8
 452:	or     r15,rcx
 455:	mov    ecx,0xffffffff
 45a:	mov    r8,r15
 45d:	and    r8,rcx
 460:	mov    QWORD PTR [r12+0x58],r8
 465:	mov    r15,r13
 468:	add    r15,0x11c
 46f:	mov    eax,DWORD PTR [r15]
 472:	mov    QWORD PTR [rsp+0x8],rax
 477:	mov    rax,QWORD PTR [rsp+0x8]
 47c:	mov    QWORD PTR [r12+0x60],rax
 481:	mov    rax,QWORD PTR [r12+0x48]
 486:	mov    QWORD PTR [rsp],rax
 48a:	mov    r9,QWORD PTR [rsp]
 48e:	add    r9,0x10
 492:	mov    r15,r9
 495:	add    r15,0x4
 499:	mov    rax,r14
 49c:	mov    eax,eax
 49e:	mov    r13d,eax
 4a1:	mov    rax,r8
 4a4:	mov    eax,eax
 4a6:	mov    r14d,eax
 4a9:	mov    DWORD PTR [r9],r13d
 4ac:	mov    r13d,0x0
 4b2:	mov    DWORD PTR [r12+0x32c],r13d
 4ba:	mov    DWORD PTR [r15],r14d
 4bd:	mov    r13d,0x0
 4c3:	mov    DWORD PTR [r12+0x32c],r13d
 4cb:	movabs rcx,0xff00ff00ff00ff
 4d5:	mov    r13,rbp
 4d8:	and    r13,rcx
 4db:	mov    r14,r13
 4de:	shl    r14,0x8
 4e2:	movabs rcx,0xff00ff00ff00ff00
 4ec:	mov    r13,rbp
 4ef:	and    r13,rcx
 4f2:	mov    r15,r13
 4f5:	shr    r15,0x8
 4f9:	mov    rcx,r14
 4fc:	mov    r13,r15
 4ff:	or     r13,rcx
 502:	movabs rcx,0xffff0000ffff
 50c:	mov    r14,r13
 50f:	and    r14,rcx
 512:	mov    r15,r14
 515:	shl    r15,0x10
 519:	movabs rcx,0xffff0000ffff0000
 523:	mov    r14,r13
 526:	and    r14,rcx
 529:	mov    r13,r14
 52c:	shr    r13,0x10
 530:	mov    rcx,r15
 533:	mov    r14,r13
 536:	or     r14,rcx
 539:	mov    ecx,0xffffffff
 53e:	mov    r13,r14
 541:	and    r13,rcx
 544:	mov    QWORD PTR [r12+0x40],r13
 549:	movabs rcx,0xff00ff00ff00ff
 553:	mov    r14,QWORD PTR [rsp+0x8]
 558:	and    r14,rcx
 55b:	mov    r15,r14
 55e:	shl    r15,0x8
 562:	movabs rcx,0xff00ff00ff00ff00
 56c:	mov    r14,QWORD PTR [rsp+0x8]
 571:	and    r14,rcx
 574:	mov    rbp,r14
 577:	shr    rbp,0x8
 57b:	mov    rcx,r15
 57e:	mov    r14,rbp
 581:	or     r14,rcx
 584:	movabs rcx,0xffff0000ffff
 58e:	mov    r15,r14
 591:	and    r15,rcx
 594:	mov    rbp,r15
 597:	shl    rbp,0x10
 59b:	movabs rcx,0xffff0000ffff0000
 5a5:	mov    r15,r14
 5a8:	and    r15,rcx
 5ab:	mov    r14,r15
 5ae:	shr    r14,0x10
 5b2:	mov    rcx,rbp
 5b5:	mov    r15,r14
 5b8:	or     r15,rcx
 5bb:	mov    ecx,0xffffffff
 5c0:	mov    r14,r15
 5c3:	and    r14,rcx
 5c6:	mov    QWORD PTR [r12+0x50],r14
 5cb:	mov    r15,QWORD PTR [rsp]
 5cf:	add    r15,0x18
 5d3:	mov    rbp,r15
 5d6:	add    rbp,0x4
 5da:	mov    rax,r13
 5dd:	mov    eax,eax
 5df:	mov    r8d,eax
 5e2:	mov    rax,r14
 5e5:	mov    eax,eax
 5e7:	mov    r13d,eax
 5ea:	mov    DWORD PTR [r15],r8d
 5ed:	mov    r14d,0x0
 5f3:	mov    DWORD PTR [r12+0x32c],r14d
 5fb:	mov    DWORD PTR [rbp+0x0],r13d
 5ff:	mov    r13d,0x0
 605:	mov    DWORD PTR [r12+0x32c],r13d
 60d:	mov    r13d,DWORD PTR [r12+0xa0]
 615:	mov    r14d,r13d
 618:	add    r14d,0x11
 61c:	mov    QWORD PTR [r12],r14
 620:	mov    r13d,0x41035c
 626:	mov    QWORD PTR [r12+0xf0],r13
 62e:	mov    r13d,0x4109a4
 634:	mov    QWORD PTR [r12+0x100],r13
 63c:	mov    QWORD PTR [r12+0x108],rbx
 644:	mov    edi,0x4109a4
 649:	mov    QWORD PTR [r12+0x100],rdi
 651:	add    rsp,0x10
 655:	nop    DWORD PTR [rax]
 658:	jmp    QWORD PTR [rip+0x2]        # 0x660
 65e:	xchg   ax,ax
 660:	xor    BYTE PTR [rcx],ch
 662:	nop
 663:	(bad)
 664:	fidiv  WORD PTR [rax+rax*1+0x0]
 668:	and    BYTE PTR [rcx],ch
 66a:	nop
 66b:	(bad)
 66c:	fidiv  WORD PTR [rax+rax*1+0x0]
 670:	movabs r11,0x5b9960425370
 67a:	jmp    r11
 67d:	nop
 67e:	nop
 67f:	nop
