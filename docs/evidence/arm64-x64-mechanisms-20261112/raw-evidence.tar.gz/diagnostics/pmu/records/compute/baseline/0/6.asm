
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-pmu/records/compute/baseline/0/6.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	mov    r13d,DWORD PTR [r12]
   4:	mov    r14d,r13d
   7:	mov    r14d,r14d
   a:	shr    r14d,0x10
   e:	mov    r14d,r14d
  11:	mov    ecx,r14d
  14:	mov    r15d,r13d
  17:	xor    r15,rcx
  1a:	mov    r15d,r15d
  1d:	mov    QWORD PTR [r12+0x40],r15
  22:	mov    r13d,0x352d
  28:	mov    QWORD PTR [r12+0x48],r13
  2d:	mov    r13d,0x352d
  33:	mov    r14d,0x7feb
  39:	and    r14d,0xffff
  40:	mov    rax,r13
  43:	movabs rcx,0xffffffff0000ffff
  4d:	and    rax,rcx
  50:	mov    rdx,r14
  53:	shl    rdx,0x10
  57:	mov    ecx,0xffff0000
  5c:	and    rdx,rcx
  5f:	or     rax,rdx
  62:	mov    ebp,eax
  64:	mov    QWORD PTR [r12+0x48],rbp
  69:	mov    r13d,0x0
  6f:	mov    eax,r15d
  72:	mov    ecx,ebp
  74:	imul   rax,rcx
  78:	mov    r14d,eax
  7b:	mov    ecx,r14d
  7e:	mov    r15d,r13d
  81:	add    r15d,ecx
  84:	mov    QWORD PTR [r12+0x40],r15
  89:	mov    r13d,0xa68b
  8f:	mov    QWORD PTR [r12+0x48],r13
  94:	mov    r13d,0xa68b
  9a:	mov    r14d,0x846c
  a0:	and    r14d,0xffff
  a7:	mov    rax,r13
  aa:	movabs rcx,0xffffffff0000ffff
  b4:	and    rax,rcx
  b7:	mov    rdx,r14
  ba:	shl    rdx,0x10
  be:	mov    ecx,0xffff0000
  c3:	and    rdx,rcx
  c6:	or     rax,rdx
  c9:	mov    ebp,eax
  cb:	mov    QWORD PTR [r12+0x48],rbp
  d0:	mov    r13d,r15d
  d3:	mov    r13d,r13d
  d6:	shr    r13d,0xf
  da:	mov    r13d,r13d
  dd:	mov    ecx,r13d
  e0:	mov    r14d,r15d
  e3:	xor    r14,rcx
  e6:	mov    r14d,r14d
  e9:	mov    QWORD PTR [r12+0x40],r14
  ee:	mov    r13d,0x0
  f4:	mov    eax,r14d
  f7:	mov    ecx,ebp
  f9:	imul   rax,rcx
  fd:	mov    r15d,eax
 100:	mov    ecx,r15d
 103:	mov    r14d,r13d
 106:	add    r14d,ecx
 109:	mov    QWORD PTR [r12+0x40],r14
 10e:	mov    r13d,r14d
 111:	mov    r13d,r13d
 114:	shr    r13d,0x10
 118:	mov    r13d,r13d
 11b:	mov    ecx,r13d
 11e:	mov    r15d,r14d
 121:	xor    r15,rcx
 124:	mov    r15d,r15d
 127:	mov    QWORD PTR [r12],r15
 12b:	cmp    QWORD PTR [r12+0x380],0x0
 134:	je     0x161
 13a:	mov    eax,0x4109c8
 13f:	mov    QWORD PTR [r12+0x100],rax
 147:	mov    QWORD PTR [r12+0x108],rbx
 14f:	mov    eax,0xc
 154:	movabs r11,0x5b99604255f0
 15e:	jmp    r11
 161:	mov    r13,QWORD PTR [r12+0xf0]
 169:	mov    QWORD PTR [r12+0x100],r13
 171:	mov    QWORD PTR [r12+0x108],rbx
 179:	mov    rdi,QWORD PTR [r12+0x100]
 181:	movabs r11,0x5b9960425370
 18b:	jmp    r11
 18e:	nop
 18f:	nop
